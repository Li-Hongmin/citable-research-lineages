# 高斜率双素数网格是精确二分算术图，并有线性真谱隙（候选）

日期：2026-09-30。依赖 [note 826](../notes/826-two-prime-moving-near-farey-mesh-has-explicit-schur-and-spectral-shifts.md) 的固定根、素数标签与亲子边，以及 [note 827](../notes/827-high-slope-two-prime-descendants-force-linear-true-schur-response.md) 的高斜率双素数质量。以下先解决改变联合逆判断的最小问题：第二代槽之间究竟有无算术边？

固定既约 \(x=a/b\in(1,2)\)、\(\alpha>1\)、\(0<\theta<1\)，沿奇素数 \(p\to\infty\) 记 \(H=\log p\)、\(A=\lfloor(p-1)^\theta\rfloor\)、\(S=\lfloor(p-1)/H^\alpha\rfloor\)、\(\mathcal P=\{q\text{ 素数}:A/b<q\le S/a\}\)、\(c_q=(\log q)/\sqrt q\)、\(\tau^2=\sum_{\mathcal P}c_q^2\)。根、孩子和高斜率第二代为
\[
B=\{x\}\cup\{u_q=qx,v_q=q/x:q\in\mathcal P\},\qquad
Z=\{z_{q,r}=xq/r:q,r\in\mathcal P,\ q\ne r,\ z_{q,r}>H/2\},
\quad V=B\cup Z.
\]
令 \(R_B,R_V\) 为根的相应真实 Schur 扣款。则候选结论是
\[
\boxed{\quad
(2-\sqrt{2(1-\theta^2)})H-O(\log H)
\le\lambda_{\min}(A_V)
\le(2-\sqrt{1-\theta^2})H+O(\log H),
\quad}\tag{1}
\]
以及两侧真响应界
\[
\boxed{\quad
\frac{(1-\theta^2)^2}{16}
\le\liminf\frac{R_V-R_B}{H}
\le\limsup\frac{R_V-R_B}{H}
\le\frac{(1-\theta^2)^2}{4(3+\theta^2)}.
 \quad}\tag{2}
\]
这里 (2) 把 note 827 的下界提高一倍，同时给出线性上界。
下文的连续极限进一步把两个首项都精确确定：谱首项由
\((5\Lambda_*-2)\log(\Lambda_*/(\Lambda_*-1))=2\Lambda_*-1\)
在 \((3,4)\) 中的唯一根给出，Schur 首项由式 (12g) 的初等对数函数给出。
这些加强仍是待异源复核的候选结论。

## 第二代内部算术块精确为零

任取 \(z=z_{q,r}\)、\(z'=z_{q',r'}\in Z\)。对比值有
\[
z/z'=\frac{qr'}{rq'}.
\]
分子与分母各为两个素数的乘积，按重数计总素因子数都等于 \(2\)。若这个比值或其倒数是整数，则整数的总素因子数只能为 \(0\)，所以只能等于 \(1\)。不同 \(Z\) 标签不相同，故没有素数幂比值边。对乘积有
\[
zz'=\frac{a^2qq'}{b^2rr'}.
\]
所有 \(q,r,q',r'>a,b\)，且 \((a,b)=1\)、\(b\ge2\)，故分母中的 \(b^2\) 不可能约去；这个乘积不是整数。自环 \(z^2\) 也由同一理由排除。因此 \(C^-_{ZZ}=0\) **精确成立**，无需对 \(Z\) 的斜率作有界假设。

note 826 的素数赋值论证还说明根与 \(Z\) 无算术边，孩子与 \(Z\) 只有
\[
u_q\leftrightarrow z_{q,r}:+c_r,
\qquad v_r\leftrightarrow z_{q,r}:-c_q.
\tag{3}
\]
孩子内部只有 \(u_q\leftrightarrow v_q\) 的 \(-c_{q^2}\)，其范数 \(o(1)\)。把孩子空间记为 \(Y\)，(3) 的 \(Y\)-\(Z\) 块记为 \(T\)，根至孩子行向量为 \(w=(c_q,-c_q)_q\)。不同 \(q\) 的正臂列支持不交，不同 \(r\) 的负臂列支持不交，因此
\[
\|T_+\|^2\le\tau^2,
\qquad \|T_-\|^2\le\tau^2,
\qquad \|T\|^2\le2\tau^2.
\tag{4}
\]

## 真实主压缩的谱

所有槽属于分子不超过 \(S<Q\) 的小分子内区。note 809 的同臂非算术核和 polar 范数在该内区为 \(O(H^{-1})\)。根和孩子的异臂正矩阵对角为 \(O(\Delta)\)；\(Z\) 的斜率大于 \(H/2\)，故其对角也为 \(O(\Delta)\)。由于 \(|V|\ll S^2\)、\(\Delta\asymp p^{-2}\)，该正矩阵在 \(V\) 上的迹及范数均为 \(O(\Delta S^2)=o(1)\)。将孩子内部的 \(o(1)\) 算术边也并入误差，真实压缩为
\[
A_V=d_pI-
\begin{pmatrix}
0&w^*&0\\w&0&T\\0&T^*&0
\end{pmatrix}+E_p,
\qquad d_p=2H+O(1),\quad\|E_p\|=o(1).
\tag{5}
\]
按 \((\{x\}\oplus Z)\oplus Y\) 重排，(5) 的算术矩阵是二分邻接矩阵，其非零奇异块 \(K:Y\to\{x\}\oplus Z\) 作用为 \(Ky=(\langle w,y\rangle,T^*y)\)。所以
\[
\lambda_{\min}(A_V)=d_p-\|K\|+o(1).
\tag{6}
\]
由 \(\|w\|^2=2\tau^2\) 和 (4)，\(\|K\|^2\le\|w\|^2+\|T\|^2\le4\tau^2\)；同时 \(\|K\|\ge\|w\|=\sqrt2\tau\)。最后 \(\tau^2=\tfrac12(1-\theta^2)H^2+O(H\log H)\)，从而 (1) 成立。特别地，整个两代真实主压缩保留正的线性谱隙。
根 Schur 余量是固定根坐标为 \(1\) 时二次型的最小值；由于所有此类向量的范数至少为 \(1\)，它也满足
\[
(A_V)_{xx}-R_V
\ge(2-\sqrt{2(1-\theta^2)})H-O(\log H).
\tag{6a}
\]
所以第二代的线性响应虽真实存在，单个固定根的两代子图仍未把根 Schur 余量压到临界常数级。

## 真 Schur 扣款的双侧线性界

按根、孩子、\(Z\) 分块写 \(A_V=\begin{psmallmatrix}a_0&g^*&h^*\\g&D&J\\h&J^*&F\end{psmallmatrix}\)。由 (5) 有 \(g=-w+o(1)\)、\(h=o(1)\)、\(D=2HI+O(1)\)、\(J=-T+o(1)\)、\(F=2HI+O(1)\)。记 \(F_{\rm eff}=F-J^*D^{-1}J\)。式 (4) 给
\[
F_{\rm eff}\succeq\bigl(2H-\tau^2/H-O(\log H)\bigr)I
=\left(\frac{3+\theta^2}{2}H-O(\log H)\right)I,
\qquad F_{\rm eff}\preceq(2H+O(1))I.
\tag{7}
\]
式 (1) 也直接保证全部相关逆存在。由块逆恒等式，\(R_V-R_B=d^*F_{\rm eff}^{-1}d\)，其中
\[
d=h-J^*D^{-1}g=-\frac{T^*w}{2H}+O(1).
\]
每个二代坐标 \((T^*w)_{q,r}=2c_qc_r\)。note 827 式 (3) 给
\[
\frac{\|d\|^2}{H^2}
\longrightarrow\frac{(1-\theta^2)^2}{8}.
\tag{8}
\]
对 (7) 取逆后代入响应恒等式，得到 (2)。\(\square\)

## 两代模型的精确连续极限（新增候选）

上面的双侧界还可收敛到一个不依赖固定根 \(x\) 和截断指数 \(\alpha\) 的连续算子。置
\[
 d\mu(t)=t\,dt\quad(\theta\le t\le1),\qquad
 m=\mu([\theta,1])=\frac{1-\theta^2}{2},\qquad
 \mathscr H=L^2(\mu)\oplus L^2(\mu).
\]
在 \(\mathscr H\) 上定义
\[
 \mathscr W(f_+,f_-)=\int_\theta^1(f_+(t)-f_-(t))\,d\mu(t),
 \qquad
 (\mathscr S(f_+,f_-))(t,s)=f_+(t)-f_-(s)
 \quad(\theta\le s<t\le1),
\]
其中 \(\mathscr S\) 的值域是三角形上带 \(\mu\otimes\mu\) 测度的 \(L^2\) 空间。令
\(\mathscr K=(\mathscr W,\mathscr S)\)、\(u=(1,-1)\in\mathscr H\)、\(M=\mathscr S^*\mathscr S\)。则更精确的候选结论是
\[
 \boxed{\quad
 \lim_{p\to\infty}\frac{\lambda_{\min}(A_V)}H
 =2-\|\mathscr K\|,\qquad
 \lim_{p\to\infty}\frac{R_V-R_B}{H}
 =\left\langle u,\left(2I-\frac12M\right)^{-1}u\right\rangle-m.
 \quad}\tag{9}
\]
逆存在，因为 \(\|\mathscr S\|^2\le2m=1-\theta^2<1\)。两个极限均由同一个真实算术图产生，不把有限主压缩外推至无限维补空间。

为证明算子范数收敛，先置
\[
 \mu_H=\frac1{H^2}\sum_{q\in\mathcal P}c_q^2\,
 \delta_{\log q/H},\qquad m_H=\mu_H(\mathbb R)=\frac{\tau^2}{H^2}\to m,
 \qquad \varepsilon_H=\frac{\log(H/(2x))}{H}\to0.
\]
定义 \(Z\) 的高斜率条件恰为 \(t_q-t_r>\varepsilon_H\)；充分大时它也排除 \(q=r\)。note 827 式 (3) 所用的加权素数定理给 \(\mu_H\Rightarrow\mu\)。将孩子向量 \(y\) 等距写成
\(f_\pm(t_q)=Hy_{\pm,q}/c_q\)，将第二代向量 \(z\) 等距写成
\(\xi(t_q,t_r)=H^2z_{q,r}/(c_qc_r)\)。于是式 (5) 的有限二分块 \(K/H\) **精确**变成
\[
 f\longmapsto
 \left(\int(f_+-f_-)\,d\mu_H,\quad
 \mathbf1_{t-s>\varepsilon_H}(f_+(t)-f_-(s))\right).
 \tag{10}
\]
不存在从有序素数对到 \(Z\) 的多重计数，因为不同标签给不同槽。

以下说明弱测度极限足以给 (10) 的**算子范数**极限。把 \(\mu_H/m_H\) 和 \(\mu/m\) 分别用分位映射 \(\phi_H:[0,1]\to\mathbb R\)、\(\phi:[0,1]\to[\theta,1]\) 表示。极限测度密度 \(t/m\) 在 \([\theta,1]\) 上连续且有正下界；两端的素数截断也趋于 \(\theta,1\)，所以加权素数定理和分位映射的单调性给 \(\|\phi_H-\phi\|_\infty\to0\)。把离散函数视为各原子分位区间上的阶梯函数后，(10) 作用于这一阶梯子空间。在全部 \(L^2[0,1]^2\) 上延拓同一公式时，它成为
\[
 \widehat{\mathscr K}_H f=\sqrt{m_H}
 \left(\int_0^1(f_+-f_-)\,du,
 \mathbf1_{\phi_H(u)-\phi_H(v)>\varepsilon_H}
 (f_+(u)-f_-(v))\right).
 \tag{11}
\]
阶梯子空间及其正交补在 \(\widehat{\mathscr K}_H^*\widehat{\mathscr K}_H\) 下约化：前者的输出在每个原子矩形上恒定，后者的输出在每个原子矩形上平均为零。正交补上的算子范数至多 \(\sqrt{m_H}\)，而阶梯子空间上的根行 \(\mathscr W_H\) 已有范数 \(\sqrt{2m_H}\)。因此延拓不改变 (10) 的范数。

记 \(\delta_H=2\|\phi_H-\phi\|_\infty+\varepsilon_H\)。式 (11) 与极限公式的指示函数只能在
\(|\phi(u)-\phi(v)|\le\delta_H\) 内不同。因 \(\phi_*du=\mu/m\) 有有界密度，此条带每个水平或竖直截面的测度都是 \(O(\delta_H)\)。用
\(|f_+(u)-f_-(v)|^2\le2|f_+(u)|^2+2|f_-(v)|^2\) 积分，得到
\(\|\widehat{\mathscr K}_H-\widehat{\mathscr K}\|=o(1)\)。这证明 (9) 的谱极限。相同论证给 \(\widehat{\mathscr S}_H\to\widehat{\mathscr S}\) 及根向量的范数收敛；阶梯子空间约化和 \(2I-\mathscr S_H^*\mathscr S_H/2\succeq(2-m_H)I\) 允许连续取逆。式 (5) 除以 \(H\) 的误差范数为 \(O(H^{-1})\)，故其真实 Schur 扣款极限也是 (9)。

连续极限还立即给出比 (1)--(2) 更尖锐的**显式**单侧界。因
\(\|u\|^2=2m\)、\(\mathscr W u=2m\)、\(\|\mathscr S u\|^2=2m^2\)，用 \(u/\|u\|\) 测试 \(\mathscr K^*\mathscr K\) 得
\[
 \|\mathscr K\|^2\ge3m,
 \qquad
 \limsup_{p\to\infty}\frac{\lambda_{\min}(A_V)}H
 \le 2-\sqrt{\frac32(1-\theta^2)}.
 \tag{12}
\]
这表明第二代相对第一代的最低谱位移是严格线性量级；note 826 的近对角二代只有常数位移。

事实上 (9) 的谱常数可由一个**固定的标量方程**确定。以累计质量
\(v=\mu([\theta,t])\in[0,m]\) 作酉坐标，再缩放 \(v=mu\)，可把
\(\mathscr K\) 酉化为 \(\sqrt m\,\mathscr K_1\)，其中 \(\mathscr K_1\) 在
\(L^2(0,1)\oplus L^2(0,1)\) 上由
\[
 \mathscr K_1(f,g)=
 \left(\int_0^1(f-g),\
 \mathbf1_{u>v}(f(u)-g(v))\right)
 \tag{12a}
\]
给出。把第二分量改号为 \(h=-g\)。\(\mathscr K_1^*\mathscr K_1\) 的二次型成为
\[
 \left|\int_0^1(f+h)\right|^2+
 \int_{0<v<u<1}|f(u)+h(v)|^2\,du\,dv.
 \tag{12b}
\]
它是对角乘子 \(\operatorname{diag}(u,1-v)\) 与一个秩一算子、两个
Hilbert--Schmidt Volterra 交叉算子的和，故本性谱位于 \([0,1]\)。
常数试探 \(f=h=1\) 的 Rayleigh 商为 \(3\)，但常数向量不是本征向量，
所以最大本征值 \(\Lambda_*>3\)；由
\(\|\mathscr K_1\|^2\le4\) 又有 \(\Lambda_*\le4\)。

二次型 (12b) 的全部核非负，因此最大本征空间中可取非负向量；
它还与 \((f,h)(u)\mapsto(h(1-u),f(1-u))\) 对易。把非负最大本征向量
与其反射取和，可取 \(h(v)=f(1-v)\)、\(F=\int_0^1 f>0\)。
本征方程的第一分量为
\[
 (\Lambda_*-u)f(u)
 =2F+\int_{1-u}^1 f(t)\,dt.
 \tag{12c}
\]
它给 \(\Lambda_*f(0)=2F\)、
\((\Lambda_*-1)f(1)=3F\)。对 (12c) 求导，置
\(h_0(u)=f(u)+f(1-u)\)，得到
\[
 h_0(u)=\frac{C}{(\Lambda_*-u)(\Lambda_*-1+u)},\qquad
 C=(5\Lambda_*-2)F.
\]
由 \(\int_0^1h_0=2F\) 消去 \(C,F\)，恰得
\[
 \boxed{\quad
 (5\Lambda_*-2)\log\frac{\Lambda_*}{\Lambda_*-1}
 =2\Lambda_*-1,\qquad 3<\Lambda_*<4.
 \quad}\tag{12d}
\]
左减右在 \([3,4]\) 严格递减：其导数为
\(5\log(\lambda/(\lambda-1))-(5\lambda-2)/[\lambda(\lambda-1)]-2
<-2+2/[\lambda(\lambda-1)]<0\)。又
\(\log(3/2)>2/5\)、\(\log(4/3)<1/3\)，故左减右在
\(3\) 处为正、在 \(4\) 处为负。因此 (12d)
在 \((3,4)\) 只有一个根，(9) 的首个极限具体化为
\[
 \boxed{\quad
 \lim_{p\to\infty}\frac{\lambda_{\min}(A_V)}H
 =2-\sqrt{\frac{1-\theta^2}{2}\,\Lambda_*}.
 \quad}\tag{12e}
\]
又由第一代星图的 \(\lambda_{\min}(A_B)/H\to2-\sqrt{2m}\)，得到精确线性谱位移
\[
 \lim_{p\to\infty}\frac{\lambda_{\min}(A_V)-\lambda_{\min}(A_B)}H
 =-\sqrt m\,(\sqrt{\Lambda_*}-\sqrt2)<0.
 \tag{12h}
\]

式 (9) 的 Schur 系数也能写成初等函数。仍在单位累计质量坐标中，令
\(\beta=4/m>8\)、\(L=2\beta-1\)、
\(\ell=\log(\beta/(\beta-1))\)。在改号后的双臂空间，
\(M=mM_1\)，其中
\[
 (M_1(f,h))_+(u)=u f(u)+\int_0^u h(v)\,dv,\qquad
 (M_1(f,h))_-(v)=(1-v)h(v)+\int_v^1 f(u)\,du.
\]
设 \((f,h)=(2I-\frac m2M_1)^{-1}(1,1)\)。正定性与反射对称性
给 \(h(v)=f(1-v)\)。记 \(F=\int_0^1f\)、\(c=2/m\)，则第一分量方程为
\[
 (\beta-u)f(u)-\int_{1-u}^1f(t)\,dt=c.
 \tag{12f}
\]
求导并置 \(h_0(u)=f(u)+f(1-u)\)，与 (12c) 相同地得到
\(h_0(u)=C/[(\beta-u)(\beta-1+u)]\)。
由 (12f) 在 \(u=0,1\) 的值，
\(f(0)=c/\beta\)、\(f(1)=(c+F)/(\beta-1)\)，于是
\(C=cL+\beta F\)。积分 \(h_0\) 得
\(F=C\ell/L\)，故 \(F=c\ell/(1-\beta\ell/L)\)。
由 \(\langle u,(2I-M/2)^{-1}u\rangle=2mF\)，可把 (9) 的第二个极限写成
\[
 \boxed{\quad
 \lim_{p\to\infty}\frac{R_V-R_B}{H}
 =\frac{4L\ell}{L-\beta\ell}-m,\qquad
 m=\frac{1-\theta^2}{2},\quad
 \beta=\frac4m,\quad L=2\beta-1,\quad
 \ell=\log\frac{\beta}{\beta-1}.
 \quad}\tag{12g}
\]
分母严格正：\(\ell<1/(\beta-1)\) 且
\(\beta/[(\beta-1)(2\beta-1)]<1\)。因此这个极限在
\(0<\theta<1\) 的整个范围内有定义。

对 Schur 系数作收敛的 Neumann 展开：
\[
 \left\langle u,\left(2I-\frac12M\right)^{-1}u\right\rangle-m
 =\frac12\sum_{n\ge1}\frac{\langle u,M^n u\rangle}{4^n}.
 \tag{13}
\]
第一项为 \(m^2/4\)。再令 \(v=\mu([\theta,t])=(t^2-\theta^2)/2\)，则
\((Mu)_+(t)=2v\)、\((Mu)_-(t)=-2(m-v)\)，故
\(\|Mu\|^2=\int_0^m[4v^2+4(m-v)^2]\,dv=8m^3/3\)。第二项为 \(m^3/12\)。所有后续项非负，且 \(\mathscr S(Mu)\ne0\)，所以 (2) 的左端可严格加强为
\[
 \boxed{\quad
 \lim_{p\to\infty}\frac{R_V-R_B}{H}
 >\frac{m^2}{4}+\frac{m^3}{12}
 =\frac{(1-\theta^2)^2}{16}
  +\frac{(1-\theta^2)^3}{96}.
 \quad}\tag{14}
\]
这里的严格号来自 (13) 的第三项正值，不要求求出 \(\mathscr K\) 的闭式谱半径。

## 与全部近对角 Farey 槽的联合压缩（新增候选）

令
\[
 \mathcal N_p=\{y=c/d\in\mathcal F_p:c\le Q,\ 1<y<2\},
 \qquad N_0=\mathcal N_p\setminus\{x\},\qquad U=V\cup N_0,
 \quad Q=\lfloor(p-1)/H\rfloor.
\]
这里 \(N_0\) 是 note 822 的**全部**近对角内区槽去掉已经属于 \(V\) 的根，而非挑选的第三代。尽管 \(|N_0|\) 随 \(p\) 以二次量级增长，候选结论为
\[
 \boxed{\quad
 \|A_{V,N_0}\|=O(\sqrt H),\quad
 \lambda_{\min}(A_U)=\lambda_{\min}(A_V)+O(1),\quad
 0\le R_U-R_V=O(1).
 \quad}\tag{15}
\]
因此式 (12e)、(12g) 的两个线性首项在加入全部 \(N_0\) 后保持不变。证明需要保留素数标签；把全部遗漏带只看作一个无符号大块，会丢失下面的常数列度数。

先证明真实非算术误差在**整个**小分子内区 \(I_Q\) 上趋零。note 809 已给同臂核和 polar 算子范数 \(O(H^{-1})\)。note 805 的正异臂核 \(B\succeq0\) 在 \(I_Q\) 的对角是 \(M_\Delta(2\log(c/d))\)，其中 \(\Delta\asymp p^{-2}\)。令 \(h=c-d\ge1\)。由 \(\log(c/d)\gg h/c\gg\Delta\) 及该核的界，
\[
 M_\Delta(2\log(c/d))\ll \Delta\,\frac c h+\Delta .
\]
放弃互素限制并求和，
\[
 \|B_{I_Q}\|\le\operatorname{tr}B_{I_Q}
 \ll \Delta\sum_{c\le Q}\sum_{1\le h<c}\frac c h
 \ll\Delta Q^2\log(2Q)=O(H^{-1}).\tag{16}
\]
故在 \(I_Q\) 的任意主压缩上，都有统一的算子范数式
\(A=d_pI-C^-+O(H^{-1})\)。这一步保留了 \(B\) 的正性和真实数值，未把它任意删掉。

任一 \(t\in(Y\cup Z)\) 满足 \(t>H/2\)。若它与 \(y\in N_0\) 有算术边，必存在整数素数幂 \(n\)，使
\[
 y=t/n,\quad t/2<n<t
 \qquad\text{或}\qquad
 y=n/t,\quad t<n<2t. \tag{17}
\]
每个 \(n\) 至多给一个目标 \(y\)，边的绝对权为
\(c_n=\Lambda(n)/\sqrt n\)。同一 \(t,y\) 不会同时满足两种边：
那将使 \(t^2\) 成为整数素数幂的乘积，而
\(u_q^2,v_q^2,z_{q,r}^2\) 均留下不可约的固定分母。
Chebyshev 的
\(\sum_{\ell\le X}\Lambda(\ell)=O(X)\) 连同高素数幂的平方可和尾，给出对 \(z\ge2\) 一致的
\[
 \sum_{\substack{z/2<n<2z\\n\text{ 为素数幂}}}
 \frac{\Lambda(n)^2}{n}\ll\log(2z).\tag{18}
\]
具体地，在任一 \((X,2X]\) 中，素数贡献至多
\((\log(2X))/X\sum_{p\le2X}\log p=O(\log X)\)；
高次幂共有 \(O(\sqrt X\log X)\) 个，每项至多
\(O(\log^2X/X)\)，故也满足同一上界。
全部 \(t\le O(S)\)，故 \(C^-_{Y\cup Z,N_0}\) 的每一行平方和为 \(O(H)\)。

反方向的**列度数**一致有界。对孩子 \(u_q=aq/b\)、\(v_q=bq/a\)，若式 (17) 的 \(n=q\)，落在 \((1,2)\) 的唯一目标是根 \(x\)，已从 \(N_0\) 删除；\(n=q^j\)、\(j\ge2\) 因 \(n\asymp q\) 不可能。其余 \(n\) 与 \(q\) 互素。于是 \(u_q/n,v_q/n\) 的既约分子分别含唯一的大素数 \(q\)，而 \(n/u_q,n/v_q\) 的既约分母分别含唯一的大素数 \(q\)。固定 \(y\) 后，每一种类型至多确定一个 \(q\) 与一个 \(n\)，故最多四个孩子父节点。

对 \(z_{q,r}=aq/(br)\in Z\)，式 (17) 有
\(r<q\) 且 \(n<2z_{q,r}<q\)（充分大时 \(r\to\infty\)）。
在 \(z_{q,r}/n=aq/(brn)\) 中，约分后的分子含唯一大素数 \(q\)；
在 \(n/z_{q,r}=brn/(aq)\) 中，约分后的分母含唯一大素数 \(q\)。
固定目标 \(y\) 便先固定 \(q\)，再分别固定整数乘积
\(rn=aq/(by)\) 或 \(rn=aqy/b\)。一个整数分解成「素数 \(r\) 乘素数幂 \(n\)」至多有两种方式：若有两个不同素因子，只能选择指数为 \(1\) 的那个作为 \(r\)；两者指数都为 \(1\) 时恰有两种。因此每种符号至多两个 \(Z\) 父节点。连同孩子，每个 \(y\in N_0\) 最多有八个算术父节点。对任意列向量 \(v\)，逐 \(y\) 用 Cauchy--Schwarz，再交换求和并用 (18)，得到
\[
 \|C^-_{N_0,Y\cup Z}v\|^2
 \le8\sum_{t\in Y\cup Z}|v_t|^2
        \sum_{y\in N_0}|C^-(y,t)|^2
 \ll H\|v\|^2. \tag{19}
\]
根与 \(N_0\) 的比值严格小于 \(2\)，只能在乘积为 \(2\) 或 \(3\) 时有算术边；每种至多一个目标，故其交叉行范数为 \(O(1)\)。由 (16)、(19)，证明式 (15) 的第一个断言。

又因 \(y,y'\in(1,2)\) 的算术块只有上述 \(2,3\) 乘积边，
\(A_{N_0}=d_pI+O(1)\)。式 (12e) 与 \(0<m<1/2\) 给
\(d_p-\lambda_{\min}(A_V)\asymp H\) 和
\(\lambda_{\min}(A_V)\gg H\)。在
\(A_U=\begin{psmallmatrix}A_V&J\\J^*&A_{N_0}\end{psmallmatrix}\)
中，\(\|J\|=O(\sqrt H)\)；二块标量谱比较把最低谱值从
\(\lambda_{\min}(A_V)\) 最多降低
\(O(\|J\|^2/H)=O(1)\)，证明式 (15) 的第二个断言。

最后按根、\(W=V\setminus\{x\}\)、\(N_0\) 分块。
由 \(A_V\gg H\) 有
\(\|A_{WW}^{-1}\|=O(H^{-1})\)；
根至 \(W\) 的列范数为 \(O(H)\)，
根至 \(N_0\) 为 \(O(1)\)，
\(\|A_{W,N_0}\|=O(\sqrt H)\)。
故新增 Schur forcing 的范数是 \(O(\sqrt H)\)，而
\[
 A_{N_0}-A_{N_0,W}A_{WW}^{-1}A_{W,N_0}
 \succeq(2H-O(1))I.
\]
精确块逆恒等式使新增根 Schur 扣款非负且至多
\(O(H)/(2H-O(1))=O(1)\)，证明式 (15) 的第三个断言。\(\square\)

## 接入已覆盖的整个 Farey 背景（新增候选）

现在取 note 824 的参数范围，并固定
\(\alpha>1\)、\(\theta=1/3\)、
\(\rho=1/2\)、\(r>2/(1-3/\pi^2)\)。
记其已覆盖的块为
\[
 F=D_A\oplus N\oplus G\oplus E\oplus M_R,\qquad
 R=\lfloor H/2\rfloor,
\]
记 \(\gamma_r=1-2/r-3/\pi^2>0\)、
\(\delta_*=\min\{\gamma_r,\,1-\sqrt5/3\}>0\)。
令 \(X=Y\oplus Z\)，即前述两代网格去掉已在 \(N\) 中的根；
\(X\) 全落于 note 824 的遗漏带
\(A<\operatorname{num}\le S,\ \text{slope}>R\)，且与 \(F,L\) 不交。
候选联合结论为
\[
 \boxed{\quad
 A_{F\oplus X}\succeq(\delta_*-o(1))H I,\qquad
 A_{F\oplus X\oplus L}
 \succeq(\log H-\log\log H-O_{a,b,\alpha,\theta,r}(1))I.
 \quad}\tag{20}
\]
再加入全部阶跃偶极 \(W_p\) 后，谱底仍至少为
\((c_0-o(1))I\)，\(c_0=1+\gamma_E-\log\pi+\delta_0>0\)。
这覆盖了此前背景的**全部** Farey 外区、近对角内区、上分子带、
深高斜率带和适中斜率带，同时加入一个固定根的高斜率双素数孩子与二代网格。

先补两个背景交叉界。对 \(M_R\) 的 \(2\le y\le R\)，若
\(t\in X\) 与 \(y\) 有算术边，由 \(t>H/2\ge R\) 仍只有
\(y=t/n\) 或 \(y=n/t\)，且 \(n\) 落在
\[
 \frac{t}{R}\le n<\frac t2
 \qquad\text{或}\qquad
 2t\le n\le Rt.
\]
两段均在 \([2t/H,Ht/2]\) 内，整个区间的乘法宽度为
\(O(H^2)\)。把它分成 \(O(\log H)\) 个二进制区间，
逐段用 (18) 且 \(t\le O(S)\)，每个 \(t\) 的边权平方和为
\(O(H\log H)\)。式 (15) 的列度数证明也适用：
孩子的 \(n=q\) 只给斜率 \(x<2\) 或 \(1/x<1\)，而
\(n=q^j\)、\(j\ge2\) 大于 \(Rt=O(Hq)\)；
对 \(z_{q,r}\)，有 \(n\le Rz_{q,r}<q\)，因为
\(r\ge A/b\gg H\)。故每个目标至多有八个父节点，Cauchy--Schwarz 给
\[
 \|C^-_{M_R,X}\|=O(\sqrt{H\log H}).\tag{21}
\]
整个 \(I_Q\) 的非算术误差已由 (16) 支付。

对 \(D_A\) 可用更强的素因子排除。每个 \(t\in X\) 的既约分子
严格大于 \(A\)，所以 \(y=nt\) 仍有分子 \(>A\)，
不可能进入 \(D_A\)。若 \(y=t/n\) 的既约分子降至
\(\le A\)，素数幂 \(n\) 必须约去 \(t\) 的分子素因子。
除固定 \(a,b\) 的素因子外，唯一候选是大素数 \(q\)；
对孩子，\(n=q^j\) 只给 \(x,1/x\) 或更小的斜率；
对 \(z_{q,r}\)，要使 \(t/n\ge2\) 有 \(n<t/2<q\)，故
\(q\nmid n\)。若 \(y=n/t\in D_A\)，原分子至少为
\(2\operatorname{num}(t)>2A\)；要把它约到 \(\le A\)，
\(n\) 的素数底也必须约去 \(t\) 分子中的固定素因子或 \(q\)。
底为 \(q\) 时，孩子只给 \(x,1/x\) 或分子 \(>A\) 的更高幂槽；
\(z_{q,r}\) 则给 \(brq^{j-1}/a\)，其既约分子
\(\ge br>A\)。故真正进入 \(D_A\) 的边只能以
\(n=\ell^j\)、\(\ell\mid ab\) 为标签。对固定 \(n\)，
\(t\mapsto t/n\) 与 \(t\mapsto n/t\) 各是部分单射，
矩形算术块的范数至多 \(c_n\)。求和得到
\[
 \|C^-_{D_A,X}\|
 \le 2\sum_{\ell\mid ab\atop \ell\ {\rm prime}}
       \sum_{j\ge1}\frac{\log\ell}{\ell^{j/2}}
 =O_{a,b}(1).\tag{22}
\]
式 (22) 是固定根结构的结论，不适用于整个遗漏带。

对上分子带 \(G=\{S<\operatorname{num}\le Q,\ \text{slope}\ge2\}\)，
因为 \(X\subset I_S\)，note 819 的整块矩形界取
\(\beta=\alpha\)、\(R=S\)，直接给
\(\|C^-_{G,X}\|=O_\alpha(\sqrt{H\log H})\)。
对 polar 外区 \(E\)，note 813 的 \(I_S\)--\(E\) 矩形界及其
非算术、polar 交叉给同阶 \(O_r(\sqrt{H\log H})\)。
这些小交叉**不包括根到孩子**：根 \(x\in N\) 的
\(\|C^-_{x,Y}\|\asymp H\)，必须留在同一个联合块。
在**同一次**删除 note 807 的正异臂矩阵 \(B\) 后，置
\(P=N\oplus X\)、\(C=G\oplus E\oplus M_R\)，
\(A^{\rm red}=A-B\)。
式 (16) 使 \(B_{N\oplus X}=O(H^{-1})\)，而
式 (15) 与式 (1) 的 \(\theta=1/3\) 情形给
\[
 A^{\rm red}_{P}\succeq(2/3-o(1))H I.
 \tag{23}
\]
note 823 对 \(D_A\) 给
\(A^{\rm red}_{D_A}\succeq(4/3-o(1))H I\)，
并给 \(\|A^{\rm red}_{D_A,N}\|\le(2/3+o(1))H\)；
式 (22) 说明新添的 \(D_A\)--\(X\) 交叉仅 \(O_{a,b}(1)\)。
因此 \(D_A\oplus P\) 的标量比较矩阵除以 \(H\) 收敛到
\[
 \begin{pmatrix}4/3&-2/3\\-2/3&2/3\end{pmatrix},
 \qquad
 \lambda_{\min}=1-\sqrt5/3>0. \tag{24}
\]
这个配方保留了根到孩子的 \(H\) 级耦合；
直接把 \(X\) 接到 note 824 的整个 \(F\) 上并声称
\(F\)--\(X=o(H)\) 是错误的。

note 824 在 \(\theta=1/3,\rho=1/2\) 的删正矩阵版
给 \(A^{\rm red}_{C}\succeq(\gamma_r-o(1))H I\)：
这是其 \(F\) 下界的主压缩，因
\(\gamma_r<2-(1+\sqrt5)/3\)。
note 823--824 给 \(D_A\)--\(C\)、\(N\)--\(C\) 交叉 \(o(H)\)；
式 (19)、(21) 与上面的 note 819、813 界给
\(X\)--\(C\) 交叉 \(O(\sqrt{H\log H})=o(H)\)。
二块比较遂给
\(A^{\rm red}_{F\oplus X}\succeq(\delta_*-o(1))H I\)。
恢复 \(B\succeq0\)，证明 (20) 的第一式。

最后，\(X\subset I_S\) 且 \(S<Q/r\)。note 822 的精确约分论证给
\(C^-_{L,X}=0\)，同臂非算术核与 polar 交叉在删除 \(B\) 后仅
\(O_r(1)\)。note 824 已给
\(\|A^{\rm red}_{L,F}\|=O_r(\sqrt H)\)、
\(A^{\rm red}_{L}\succeq
(\log H-\log\log H-O_r(1))I\)。
用刚证明的 \(F\oplus X\) 线性谱隙完成平方，
只从 \(L\) 扣去 \(O(1)\)，证明 (20) 的第二式。
note 806 的全部常值槽--\(W_p\) 真实混合范数为 \(O(1)\)，
note 804 的 \(W_p\) 谱隙为 \(c_0-o(1)\)；
增长的常值槽谱隙只导致 \(o(1)\) 的阶跃 Schur 损失。\(\square\)

## 边界

以上联合结果只加入**一个固定根**的两代素数后代。遗漏带的其余高斜率槽、不同根之间的碰撞、非恒定轮廓及无限维正交补仍未控制；亦没有解决 moving-\(N\) Möbius signed covariance 或 RH。
