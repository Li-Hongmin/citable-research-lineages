# 任意有界末带素数载波选择的加权 Gram 定律

日期：2026-10-02。使用 [scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 式 (9)–(16) 中仅关于**真实素数源管**的统一展开，以及 [scratch 959](959-subexponential-growing-prime-carriers-have-negative-covariance-with-the-full-k2-residual.md) 式 (10) 对完整余项的投影界。与 [scratch 960](960-sparse-resonant-terminal-prime-carriers-force-growing-complement-energy.md) 的单个同余类相比，这里允许任意有界实载波选择，并给出其整个 Gram 形式。两份所引 scratch 与本证明尚未异源复核，故本文不晋级为永久定理，也不构成完整余项均方界或 RH 证明。

## 命题

固定 $0<\gamma<1/4$、非负 $\chi\in C_c^\infty((3/2,8/5))$。令 $H=\lfloor Y^\gamma\rfloor$、$V_Y=(\log Y/\log\log Y)^{1/3}$、$A_Y=Y^3/[H^4(\log Y)^4]$，并记
\[
f(z)=\frac1z\int_1^{11/10}\log(z/x)\,dx>0,
\qquad
P_w(z)=\sum_{r=0}^{B}w_re(rz),
\qquad G_w(N)=\sum_{r=0}^{B}w_rG_r(N).                 \tag{1}
\]
其中 $G_r$ 是 scratch 958–959 的**实际素数源管**，$e(t)=e^{2\pi it}$。存在仅依赖于 $\gamma$ 的固定 $c_*>0$，使对所有整数 $0\le B\le e^{c_*V_Y}$ 与所有实数 $|w_r|\le1$ 一致成立
\[
\boxed{\quad
\|G_w\|_\chi^2
=\left(1+O_{\gamma,\chi}(1/\log Y)\right)
\frac{A_Y}{2\pi^2}\int\chi(z)f(z)^2|P_w(z)|^2\,dz
+o_{\gamma,\chi}(A_Y),\quad}                         \tag{2}
\]
其中 $\|U\|_\chi^2=\sum_N\chi(N/Y)|U_N|^2$；式中的乘性误差意指其绝对值至多为所示主泛函的 $O(1/\log Y)$ 倍，$o(A_Y)$ 对全部权重一致。完整真实 $k=2$ 余项 $\mathcal R_N=\mathcal R_{N,2}$ 还满足
\[
\boxed{\quad
\langle G_w,\mathcal R\rangle_\chi=o_{\gamma,\chi}(A_Y),
\qquad
\langle G_w,\mathcal R-G_w\rangle_\chi
=-\|G_w\|_\chi^2+o_{\gamma,\chi}(A_Y).\quad}       \tag{3}
\]
当 $w_r\in\{0,1\}$ 时，$G_w$ 是互不重复的实际素数源管子和，$\mathcal R-G_w$ 是删去这些实际源项后的补集。若 (2) 中的积分趋于无穷，则 (3) 的负交叉渐近于 $-\|G_w\|_\chi^2$。对一般实权重，(2) 是 Gram 定律，(3) 只是线性测试恒等式，不把 $\mathcal R-G_w$ 称为源项补集。

## 证明

写 $\ell=\log Y$、$A_0=Y/(\pi H^2\ell^2)$，于是 $YA_0^2=A_Y/\pi^2$。scratch 958 式 (9)–(16) 给实际素数源管与确定性密度模型之间的一致估计
\[
G_r(N)=\Re\{e((H+r)z)\mathcal B_{H+r}(z)\}
  +O_\gamma(A_0e^{-c_1V_Y}),\qquad z=N/Y\in[3/2,8/5],\tag{4}
\]
其中 $c_1>0$ 固定，且
\[
\mathcal B_H(z)=A_0f(z)+O_\gamma(A_0/\ell),
\quad \sup_z(|\mathcal B_H(z)|+|\partial_z\mathcal B_H(z)|)
\ll_\gamma A_0,
\quad
\sup_z|\mathcal B_{H+r}(z)-\mathcal B_H(z)|
\ll_\gamma A_0r/H.                                    \tag{5}
\]
最后一个估计直接把 scratch 958 式 (14) 的逐步变差从 $H$ 累加到 $H+r$；$z$ 导数界来自该稿式 (11) 的显式积分，$z$ 始终留在固定紧区间。这里仅用素数短和，没有使用该稿的互素 Möbius 管引理。

记 $b=B+1$。对 $|w_r|\le1$ 加权求和 (4)–(5)，得到逐点的统一近似
\[
G_w(N)=\Re\{e(Hz)\mathcal B_H(z)P_w(z)\}+E_w(z),
\qquad
\|E_w\|_\infty
\ll_\gamma A_0\left(b^2/H+b e^{-c_1V_Y}\right).   \tag{6}
\]
令括号为 $\epsilon_Y$。取 $c_*<c_1/3$，则 $b\epsilon_Y=o(1)$，因为 $b^3/H=Y^{-\gamma+o(1)}$ 且 $b^2e^{-c_1V_Y}\to0$。主波形的上确界至多 $O(A_0b)$，所以 (6) 在加权平方和中造成的绝对误差为
\[
O_{\gamma,\chi}\{YA_0^2(b\epsilon_Y+\epsilon_Y^2)\}=o(A_Y),
\tag{7}
\]
对所有权重一致。

记 $U(z)=\Re\{e(Hz)\mathcal B_H(z)P_w(z)\}$。由 $|P_w|\le b$、$|P_w'|\ll b^2$ 及 (5)，函数 $\chi U^2$ 的变差至多 $O_{\gamma,\chi}(A_0^2b^2(H+b))$。整数求积因此给
\[
\sum_N\chi(N/Y)U(N/Y)^2
=Y\int\chi(z)U(z)^2dz
+O_{\gamma,\chi}(A_0^2b^2(H+b)).                     \tag{8}
\]
末项相对 $YA_0^2$ 是 $O(b^2(H+b)/Y)=o(1)$。展开实部平方：
\[
\int\chi U^2
=\frac12\int\chi|\mathcal B_H|^2|P_w|^2
+\frac12\Re\int\chi(z)e(2Hz)\mathcal B_H(z)^2P_w(z)^2dz.
\tag{9}
\]
后一积分的一次分部积分利用 (5) 与 $|P_w'|\ll b^2$，绝对值至多 $O_{\gamma,\chi}(A_0^2b^3/H)=o(A_0^2)$。由于 $f$ 在 $\operatorname{supp}\chi$ 上有正的固定下界，(5) 还给逐点
\[
|\mathcal B_H(z)|^2
=A_0^2f(z)^2\{1+O_{\gamma,\chi}(1/\ell)\}.
\tag{10}
\]
由 (7)–(10) 和 $YA_0^2=A_Y/\pi^2$ 即得 (2)。上述所有 $o(1)$ 均由 $B\le e^{c_*V_Y}=Y^{o(1)}$ 和固定 $\gamma>0$ 给出，未把任意权重的多项式 $P_w$ 假设为几何和。

scratch 959 式 (10) 对每条实际源管给
$|\langle G_r,\mathcal R\rangle_\chi|
\ll_{\gamma,\chi}A_Ye^{-c_2V_Y}$，其中 $c_2>0$ 固定。再缩小 $c_*<c_2$，逐管加权相加得到 (3) 第一式；第二式是内积的精确展开。若 $w_r\in\{0,1\}$，scratch 959 在式 (10) 后证明：同一分子 $a$ 的相邻素数分母窗中心相距 $\asymp Y/H$，窗长仅 $O(Y/(H\ell))$，故不同 $r$ 的实际源项对充分大 $Y$ 互不重叠。$\square$

## 周期选择的精确共振常数

固定 $q\ge2$ 及一个非零的 $0$–$1$ 周期图案 $(u_0,\ldots,u_{q-1})$。令 $J=J(Y)\to\infty$，$B=q(J+1)-1\le e^{c_*V_Y}$，$w_{qj+s}=u_s$（$0\le j\le J$，$0\le s<q$），并记 $A_u(z)=\sum_{s=0}^{q-1}u_se(sz)$。此时 $P_w(z)=A_u(z)D_J(qz)$。Fejér 核的近似恒等性质与 (2) 给
\[
\boxed{\quad
\|G_w\|_\chi^2
=\left(C_{q,u,\chi}+o_{\gamma,\chi}(1)\right)(J+1)A_Y,
\quad
C_{q,u,\chi}=\frac1{2\pi^2q}
\sum_{\substack{k\in\mathbb Z\\3/2<k/q<8/5}}
\chi(k/q)f(k/q)^2|A_u(k/q)|^2.\quad}               \tag{11}
\]
这里的 $o(1)$ 是相对于 $(J+1)A_Y$；即使常数为零，该式仍只断言 $o((J+1)A_Y)$。若 $C_{q,u,\chi}>0$，则实际选中管与其余**全部真实素数管**也有
\[
\langle G_w,\mathcal F-G_w\rangle_\chi
=-(C_{q,u,\chi}+o(1))(J+1)A_Y,
\qquad \mathcal F=\sum_{r=0}^{B}G_r.                 \tag{12}
\]
确实，scratch 958 式 (2) 的全选管能量给 $\|\mathcal F\|_\chi^2=O(A_Y)$；由 (11) 和 Cauchy–Schwarz，$|\langle G_w,\mathcal F\rangle_\chi|=O(\sqrt{J+1}A_Y)=o((J+1)A_Y)$。式 (3)、(11) 又给同一选中管与完整余项补集的相同负主项。

取 $u_0=1$、其余 $u_s=0$ 即恢复 scratch 960 的固定同余类常数。取所有 $u_s=1$ 时，$A_u(k/q)=0$ 于非整数 $k/q$，而观察窗内无整数，故线性主项为零；这解释全选管的有界能量。更精确地，对全选管在 (2) 中用 $P_w=D_B$ 及 $|D_B(z)|^2\to 2/|1-e(z)|^2$ 的积分弱极限，正好得到 scratch 958 的 $C_{\infty,\chi}=\frac1{4\pi^2}\int\chi(z)f(z)^2/\cos^2(\pi(z-3/2))\,dz$，从而核对了式 (2) 的常数 $1/(2\pi^2)$。式 (11) 对所有固定周期图案给出明确的共振选择规则。它仍只描述一个真实素数源子族及其 signed 补偿，无法界定完整余项的正交补。
