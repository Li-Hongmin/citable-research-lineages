# 完整观察局部环带的任意 gcd 筛选一阶公式

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合系数、[scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 的小模进程短和、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 的大物理 gcd 绝对界，以及 [scratch/907](907-coprime-full-observation-local-ring-has-negative-main-term.md) 的固定 gcd 常数。本稿将固定 gcd 的结论统一到**任意有界 gcd 筛选**，并严格核准所有非互素层在同一近环带对互素负主项的补偿。以下是解析候选，尚未异源复核；误差只有任意对数幂节省，不是 RH 所需的固定幂界。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$。固定实值、非负、非零的 $\psi\in C_c^3((1,2))$，置 $\phi(t)=\psi(t)/t$。取 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的偶、非负带通权 $v=\chi_s^2$，$s>1$，并定义
\[
J_H(k)=\sum_{h\in\mathbb Z}v(h/H)e(-hk/M),\quad
a_m=\frac{c(m)}M\phi(m/M),\quad
L=\left\lfloor\frac{M}{32H}\right\rfloor,\quad
K_0=\left\lfloor\frac{H^3}{\log^2M}\right\rfloor,
\tag{1}
\]
其中 $c(m)$ 为 note 849 式 (10) 的**真实**系数，窗外置 $a_m=0$。设
\[
I_\phi=\int_1^2\phi(t)^2dt,
\qquad
\mathcal J_{M,H}=\frac{I_\phi}{M}
\sum_{K_0<|k|\le L}J_H(k).
\tag{2}
\]
对任何函数 $F:\mathbb N\to\mathbb C$、$|F(g)|\le1$，以及任意固定 $A>0$，一致地有
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\K_0<|m-n|\le L}}
F((m,n))a_ma_nJ_H(m-n)
=\mathcal J_{M,H}\sum_{g\ge1}F(g)C_g
+O_{A,s,\psi}((\log M)^{-A}),
\quad}\tag{3}
\]
其中绝对收敛的常数列为
\[
C_1=\frac{64}{\pi^2}-12,\qquad
C_2=3+\frac6{\pi^2},\qquad
C_g=\begin{cases}
64/(\pi^2g^2),&g\ge3\text{ 为奇数},\\
24/(\pi^2g^2),&g\ge4\text{ 为偶数}.
\end{cases}\tag{4}
\]
这里 $\mathcal J_{M,H}\to\mathcal J_{\psi,v}>0$，其中 $\mathcal J_{\psi,v}$ 是 scratch/907 式 (2) 的常数。因此 (3) 对随 $M,H$ 任意变化的 gcd 集合仍一致成立。尤其
\[
\sum_{\substack{K_0<|m-n|\le L\\(m,n)\ge2}}
a_ma_nJ_H(m-n)
=\left(12-\frac{64}{\pi^2}\right)\mathcal J_{M,H}
+O_A((\log M)^{-A})>0
\tag{5}
\]
对充分大 $M$ 成立；互素层为其相反主项。$g=2$ 层提供
$(3+6/\pi^2)\mathcal J_{M,H}$，其余 $g\ge3$ 层合计提供
$(9-70/\pi^2)\mathcal J_{M,H}$。这是一阶补偿，不能把式 (3) 的对数级误差当作 note 849 式 (15) 所需的 $H^4/M$ 误差。

## 证明

对 $q\ge1$ 和 $0\le T\le L$ 写
\[
\mathcal C_q(T)=
\sum_{\substack{m,n\\|m-n|\le T\\q\mid m,n}}
a_ma_nJ_H(m-n),\qquad
V_T=\frac1M\sum_{|k|\le T}J_H(k).
\tag{6}
\]
先证明下列对任意固定 $B,D>0$、$q\le(\log M)^B$ 一致的式子，$T=L,K_0$：
\[
\mathcal C_q(T)=\kappa_q^2 I_\phi V_T
+O_{B,D,s,\psi}((\log M)^{-D}),
\qquad
\kappa_1=0,\quad\kappa_2=2,\quad
\kappa_q=\begin{cases}3/q,&q\ge3\text{ 奇},\\2/q,&q\ge4\text{ 偶}.
\end{cases}
\tag{7}
\]

设 $g_q(m)$ 是 scratch/870 式 (4) 的周期密度，即
$g_1=0$、$g_2=4\mathbf1_{2\mid m}$，且
$g_q=(4-2\mathbf1_{2\mid m})\mathbf1_{q\mid m}$ 对 $q\ge3$。
它的周期至多 $2q$，均值为 $\kappa_q$。令
$r_q(m)=\mathbf1_{q\mid m}c(m)-g_q(m)$。scratch/870 式 (5)--(7)
所用的长度 $M^{2/3}$ 块估计给出：只要
$M^{2/3+\rho}\le T\le L$，其中 $\rho>0$ 固定，任意
$q\le(\log M)^B$ 及任意长度不超过 $2T$ 的物理区间 $I$ 均有
\[
\left|\sum_{m\in I}r_q(m)\right|
\ll_{B,D,\rho}T(\log M)^{-D}.
\tag{8}
\]
确实，把 $I$ 分成长 $\lfloor M^{2/3}\rfloor$ 的整块和至多两个端块。整块各有任意固定对数幂节省，端块由
$|r_q(m)|\ll\log M$ 给 $O(M^{2/3}\log M)$；因为 $T\ge M^{2/3+\rho}$，后一项也小于 (8) 右侧。

对固定外层 $m$，在 $|m-n|\le T$ 的内层将 $r_q(n)$ 乘以
$\phi(n/M)J_H(m-n)/M$。该权的上确界及总变差都是 $O_{s,\psi}(H/M)$：
$|J_H|\ll H$，$|J_H'|\ll H^2/M$，而 $T\le L\ll M/H$。
对 (8) 作 Abel 求和，内层残差为
$O(H T/(M\log^D M))=O(\log^{-D}M)$。
外层 $\ell^1$ 范数由 note 849 式 (16) 及 $g_q=O(1)$ 统一界为 $O_\psi(1)$。展开二次型，便可在 $\mathcal C_q(T)$ 的两边都将
$\mathbf1_{q\mid m}c(m)$ 换为 $g_q(m)$，费用为
$O(\log^{-D}M)$。

周期误差满足 $\sum_{n\in I}(g_q(n)-\kappa_q)=O(q)$。
再对同一内层权作 Abel 求和，将 $g_q(n)$ 换为 $\kappa_q$ 的费用为 $O(Hq/M)$。
随后把 $\phi(n/M)$ 换为 $\phi(m/M)$ 的费用为
$O(H T^2/M^2)=O(1/H)$。外层的周期 Riemann 求和给
\[
\frac1M\sum_m g_q(m)\phi(m/M)^2
=\kappa_q I_\phi+O_\psi(q/M).
\]
合并即得 (7) 在 $T\ge M^{2/3+\rho}$ 时成立，因为
$Hq/M+1/H$ 均小于任意固定负对数幂。$T=L$ 总在此范围。

对于 $T=K_0$，若 $H\le M^{9/40}$，则 note 849 式 (16) 与
$|J_H|\ll H$ 给**所有 $q$ 同时**适用的无符号界
\[
|\mathcal C_q(K_0)|
\le\sum_{|m-n|\le K_0}|a_ma_nJ_H(m-n)|
\ll\frac{H(K_0+1)\log M}{M}
\ll M^{-1/10}\log M.
\tag{9}
\]
同时 $|I_\phi V_{K_0}|\ll HK_0/M+H/M\ll M^{-1/10}$，故 (7) 仍成立。若 $H>M^{9/40}$，则
$K_0\gg M^{27/40}/\log^2M>M^{2/3+1/240}$，可直接使用 (8) 的证明。这完成 (7)。

对 $T=L,K_0$，逐公共除数计数，连同对角项，统一给
\[
\sum_{q>Q}|\mathcal C_q(T)|
\ll_{s,\psi}\frac{\log^2M}{Q}
+\frac{H\log^3M}{M}
\qquad(2\le Q\le L).
\tag{10}
\]
非对角部分只可能有 $q\mid(m-n)$ 且 $q\le T$。对每个这样的 $q$，$m$ 有 $O(M/q)$ 个候选，固定 $m$ 后 $n$ 有 $O(T/q)$ 个候选；每项的模至多 $O(H\log^2M/M^2)$。故其尾为
$O((HT/M)\log^2M/Q)=O(\log^2M/Q)$。
对角部分按 $\sum_{m\le2M}\tau(m)\ll M\log M$ 过计，得到 (10) 的第二项。这也是 scratch/907 式 (13)--(14) 的估计。
而由 $\kappa_q\ll1/q$ 得
$\sum_{q>Q}\kappa_q^2\ll1/Q$。对任意 $g\ge1$，有限 Möbius 反演于是给
\[
\mathcal B_g(T):=
\sum_{\substack{|m-n|\le T\\(m,n)=g}}a_ma_nJ_H(m-n)
=\sum_{k\ge1}\mu(k)\mathcal C_{gk}(T)
=I_\phi V_T C_g+O_D((\log M)^{-D})
\tag{11}
\]
一致于 $g\le(\log M)^B$，其中 $B,D$ 任意预先固定。
为得到最后的误差精度，先在 (10) 中取 $Q=(\log M)^{B+D+4}$，再把 (7) 的小模范围取为 $q\le Q$，并选比 $2B+2D+8$ 更大的对数节省指数；低 $q$ 求和最多含 $Q$ 项。式 (4) 的 $C_g=\sum_{k\ge1}\mu(k)\kappa_{gk}^2$ 已在 scratch/907 式 (16)、(18) 逐类计算。

现在令 $G=(\log M)^{A+5}$。对 $g\le G$ 在 (11) 取误差指数大于 $2A+10$，再对任意 $|F(g)|\le1$ 求和，误差仍为 $O_A(\log^{-A}M)$。对 $g>G$，scratch/868 式 (2a) 给非对角绝对界
$O_{s,\psi}(\log^2M/G)$；对角由 note 849 式 (16) 给
$O_{s,\psi}(H\log M/M)$。两者均为
$O_A(\log^{-A}M)$。常数主项的尾由 (4) 给
$\sum_{g>G}|C_g|\ll1/G$。因此 (11) 对任意有界 $F$ 统一求和成立，分别取 $T=L,K_0$ 再相减便是 (3)。

最后，Poisson 求和使 $J_H(k)=H\widehat v(Hk/M)$ 加上任意负幂的非零别名误差，在 $|k|\le L$ 一致成立。整数求积于是给
\[
\mathcal J_{M,H}
=I_\phi\int_{HK_0/M<|u|\le HL/M}\widehat v(u)\,du+o(1)
\longrightarrow
I_\phi\int_{-1/32}^{1/32}\widehat v(u)\,du>0.
\tag{12}
\]
正性来自 $v\ge0$、$v\not\equiv0$ 及其支撑 $1/2\le|t|\le4$：当 $|u|\le1/32$ 时，
$\cos(2\pi ut)\ge\cos(\pi/4)>0$。由
$\sum_{g\ge3,\,g\text{ 奇}}g^{-2}=\pi^2/8-1$ 与
$\sum_{g\ge4,\,g\text{ 偶}}g^{-2}=\pi^2/24-1/4$，(4) 的奇、偶尾分别为 $8-64/\pi^2$ 与 $1-6/\pi^2$。加上 $C_1,C_2$ 恰为零；取 $F=\mathbf1_{g\ge2}$ 等便得 (5)。$\square$

## 算术边界

式 (3) 同时覆盖所有随尺度变化的 gcd 切片，表明局部互素负常数不能被当作完整环带的负方向：其余 gcd 层在**同一距离环带**给出相反的正主项。另一方面，该定理的误差 $O_A(\log^{-A}M)$ 在 $H\le M^{1/4-\theta}$ 时仍远大于 $H^4/M$。它没有估计真实二点波动，不能推出 moving-$N$ 门或 RH。
