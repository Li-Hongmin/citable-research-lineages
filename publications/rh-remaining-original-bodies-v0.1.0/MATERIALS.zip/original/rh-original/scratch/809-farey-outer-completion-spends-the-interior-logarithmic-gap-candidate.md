# Farey 外圈补全精确支付内部谱隙的对数主项（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇算子、全 Farey 算术行公式和 Archimedean 压缩，[scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的全族正权 Rayleigh 常数，以及 [scratch 808](808-interior-farey-dipoles-have-a-sharp-growing-spectral-gap-candidate.md) 的内部谱隙。本证明把承重的交叉量直接算出；同模型独立复核未发现承重错误，尚缺异源复核，不晋级永久 note。

## 命题

令奇素数 \(p\to\infty\)，\(H=\log p\)，并取整数 \(Q=Q(p)\) 使
\[
t:=\log(p/Q)\longrightarrow\infty,
\qquad t=o(H).
\tag{1}
\]
采用 note 791 的全 Farey 正交偶极族 \(\mathcal F_p\)，并令
\[
v_p=\sum_{a/b\in\mathcal F_p}\frac{w_{a/b}}{\sqrt{ab}},
\quad v_I=\sum_{a/b\in\mathcal F_Q}\frac{w_{a/b}}{\sqrt{ab}},
\quad v_O=v_p-v_I,
\quad A=\|v_I\|^2,
\quad B=\|v_O\|^2.
\tag{2}
\]
这里 \(A_{p^2,-}\) 是完整真实旧奇算子，但 (2) 的向量仅属于其有限 Farey 主空间。设
\[
c_*:=1+\gamma_E+\log(2/\pi)>0.
\]
则
\[
\boxed{B/A\sim 2t/H\longrightarrow0,}
\tag{3}
\]
并有三个在相同 \(A\) 量纲下的精确渐近：
\[
\boxed{
\begin{aligned}
\langle v_I,A_{p^2,-}v_I\rangle/A&=2t+c_*+o(1),\\
\langle v_I,A_{p^2,-}v_O\rangle/A&=-2t+o(1),\\
\langle v_O,A_{p^2,-}v_O\rangle/A&=2t+o(1).
\end{aligned}}
\tag{4}
\]
特别地，外圈试探向量 \(v_O\) 的真实能量最终为正，而且它对内部向量的 rank-one 变分 Schur 成本满足
\[
\boxed{
\frac{1}{A}
\frac{|\langle v_I,A_{p^2,-}v_O\rangle|^2}
     {\langle v_O,A_{p^2,-}v_O\rangle}
=2t+o(1).}
\tag{5}
\]
故内部正权方向虽然有 \(2t+c_*+o(1)\) 的增长能量，但只用这个**单一外圈方向**消元后便精确降至
\[
\boxed{
\frac1A\left(
\langle v_I,A_{p^2,-}v_I\rangle
-\frac{|\langle v_I,A_{p^2,-}v_O\rangle|^2}
 {\langle v_O,A_{p^2,-}v_O\rangle}
\right)=c_*+o(1).}
\tag{6}
\]
在正交单位基 \((v_I/\sqrt A,v_O/\sqrt B)\) 上，这个二维真实主压缩的两个特征值分别为 \(c_*+o(1)\) 与 \((1+o(1))H\)。这只陈述指定二维空间严格正，不能外推到其正交补。
式 (5)--(6) 是有限二维试探压缩的恒等后果，不预设整个外圈压缩正性或其逆存在。因此它不证明完整 Schur 补有符号，也不证明 RH。

## 范数与两个对角

置 \(h=\log Q=H-t\)。对互素有序对的调和求和及 Möbius 反演给出
\[
\|v_p\|^2=\frac{H^2}{2\zeta(2)}+O(H),
\qquad A=\frac{h^2}{2\zeta(2)}+O(h).
\tag{7}
\]
因 \(t\to\infty\)、\(t=o(H)\)，两者相减后
\[
B=\frac{H^2-h^2}{2\zeta(2)}+O(H)
\sim\frac{Ht}{\zeta(2)},
\qquad A\sim\frac{H^2}{2\zeta(2)},
\]
证明 (3)。注意 \(O(H)\) 相对于 \(Ht\) 确实可忽略，故不能省掉假设 \(t\to\infty\)。

scratch 808 式 (3) 对 (1) 的 \(Q\) 给出
\[
\langle v_I,A_{p^2,-}v_I\rangle/A=2t+c_*+o(1).
\tag{8}
\]
scratch 798 式 (2) 则给完整正权向量
\[
\langle v_p,A_{p^2,-}v_p\rangle/(A+B)=c_*+o(1).
\tag{9}
\]
这两个输入可从同一个精确图核对：\(C_Q\) 或 \(C_p\) 在 \(v\) 上的 Rayleigh 商分别为 \(2h-2\gamma_E+o(1)\) 或 \(2H-2\gamma_E+o(1)\)；相应 Archimedean 商分别为 \(2H+1-\gamma_E+\log(2/\pi)+o(1)\)。对全族的后一个 \(o(1)\)，先把正权质量限制到 \(a,b\le p^\alpha\)，该区域的 Archimedean 非对角行和趋零；外区的相对 \(v^2\) 质量趋于 \(1-\alpha^2\)，再令 \(\alpha\uparrow1\)。polar 投影范数由 note 791 为 \(O(p^{-3/2})\)。这也独立给出 (8)--(9) 所用的常数。

## 精确算术交叉

令 \(\mathcal C_p\) 是 note 791 在 \(\mathcal F_p\) 上的非负算术矩阵，\(\mathcal C_Q\) 为其内部主块。记
\[
M_\Lambda(x)=\sum_{n\le x}\frac{\Lambda(n)}n,
\qquad \varepsilon(x)=M_\Lambda(x)-\log x.
\]
经典素数定理给 \(\varepsilon(x)\to-\gamma_E\)。note 791 式 (14) 对每个 \(x=a/b\in\mathcal F_Q\) 给
\[
\frac{(\mathcal C_pv_p)_{a/b}}{(v_I)_{a/b}}
=2\log(p-1)
+\varepsilon((p-1)/a)+\varepsilon((p-1)/b)
-\Lambda(a)\mathbf1_{b=1}.
\tag{10}
\]
由于 \((p-1)/a\ge (p-1)/(Q-1)\to\infty\)，两个 \(\varepsilon\) 在整个内部族上**一致**趋于 \(-\gamma_E\)。最后一项的加权平均绝对值为
\[
\frac1A\sum_{a<Q}\frac{\Lambda(a)}a
\ll\frac h{h^2}=o(1).
\]
因此
\[
\langle v_I,\mathcal C_pv_p\rangle/A=2H-2\gamma_E+o(1).
\tag{11}
\]
同一行公式取上限 \(Q\)，或 scratch 808 式 (10)，给
\[
\langle v_I,\mathcal C_Qv_I\rangle/A=2h-2\gamma_E+o(1).
\tag{12}
\]
因 \(v_O=v_p-v_I\)，(11)--(12) 相减便得
\[
\boxed{\langle v_I,\mathcal C_pv_O\rangle/A=2t+o(1).}
\tag{13}
\]

对非算术部分，scratch 798 的接触常数和 note 791 的一致压缩意味着在全 Farey 空间上
\(G_{p^2}=(2H+1-\gamma_E+\log(2/\pi))I+E_p\)，\(\|E_p\|=O(1)\)。由于 \(v_I\perp v_O\)，
\[
|\langle v_I,G_{p^2}v_O\rangle|
\le C\sqrt{AB}=o(A)
\tag{14}
\]
由 (3) 可见最后一步成立。polar 压缩在全 Farey 空间的范数为 \(O(p^{-3})\)，也给 \(o(A)\) 的交叉。把 \(A_{p^2,-}=G_{p^2}-\mathcal C_p-2|s\rangle\langle s|\) 与 (13)--(14) 合并，证明 (4) 的第二式。

## 外圈能量与变分商

对 \(v_p=v_I+v_O\) 展开二次型，用 (8)--(9) 和已证交叉式：
\[
\begin{aligned}
\langle v_O,A_{p^2,-}v_O\rangle
&=\langle v_p,A_{p^2,-}v_p\rangle
-\langle v_I,A_{p^2,-}v_I\rangle
-2\langle v_I,A_{p^2,-}v_O\rangle\\
&=(c_*+o(1))(A+B)-(2t+c_*+o(1))A
+(4t+o(1))A\\
&=(2t+o(1))A+c_*B+o(A+B).
\end{aligned}
\tag{15}
\]
由 (3)，\(B=o(A)\)，故 (15) 除以 \(A\) 为 \(2t+o(1)\)，证明 (4) 的第三式及分母最终严格正。

令 \(X=\langle v_I,A_{p^2,-}v_O\rangle\)、\(Y=\langle v_O,A_{p^2,-}v_O\rangle\)。由 (4)，\(X/A=-2t+o(1)\)、\(Y/A=2t+o(1)\)，故
\[
\frac{X^2}{AY}
=\frac{(-2t+o(1))^2}{2t+o(1)}
=2t+o(1).
\]
这证明 (5)，再减去 (4) 第一式即得 (6)。\(\square\)

为核对二维特征值，归一化矩阵的行列式是
\[
\frac YA\frac AB
\left(\frac{\langle v_I,A_{p^2,-}v_I\rangle}{A}
-\frac{X^2}{AY}\right)
=\frac YB(c_*+o(1)).
\]
由 (3)--(4)，\(Y/B=(1+o(1))H\)，故行列式为 \((c_*+o(1))H\)，迹为 \((1+o(1))H\)。较大特征值遂为 \((1+o(1))H\)，较小者为 \(c_*+o(1)\)。

## 边界与下一判断

808 的内部谱隙真实存在，但全 Farey 外圈的一个明确方向已经以同阶 Schur 成本支付了它。对完整局部 Weil 正性作决定性判断，仍须控制有限二维方向以外的外圈与无限维正交补；不能把 (6) 的正数 \(c_*\) 直接当作完整 Schur 下界。这里没有使用或证明真实 moving-\(N\) Möbius covariance 上界。
