# 全 Farey 有理偶极的精确素数幂算术图（待异源复核）

日期：2026-09-29。依赖 [note 788](../notes/788-fractional-half-slots-force-logarithmic-complement-feedback.md) 的真实奇半槽定义与 [scratch 791](791-two-branch-reciprocal-dipole-feedback-candidate.md) 的双支路恒等式。这里只证明固定 \(k=p^2\) 的有限有理槽几何和旧算术矩阵；不假定局部 Weil 正性。

## 命题

令 \(p\ge3\) 为奇素数，\(k=p^2\)、\(\Delta=\frac12\log(1+p^{-2})\)。旧空间是 \(H_k=L^2((1,k),dt/t)\)；以下使用等距坐标 \(u=\log t\in(0,\log k)\)。在此对数坐标上设
\[
\varphi_z=(2\Delta)^{-1/2}
\bigl(1_{(\log z-\Delta,\log z)}-1_{(\log z,\log z+\Delta)}\bigr),
\qquad
w_x=\frac{\varphi_{px}+\varphi_{p/x}}{\sqrt2}.
\tag{1}
\]
令
\[
\mathcal F_p={x=a/b>1:1\le b<a<p,\ (a,b)=1\},
\quad e_p=\varphi_p,
\tag{2}
\]
并以 \(P_p\) 表示整数奇半槽 \(e_m\)、\(2\le m\le p\) 的张成空间正交投影，\(Q_p=I-P_p\)。则：

1. \(\{w_x:x\in\mathcal F_p\}\) 是 \(Q_pH_k^-\) 中的正交单位族。
2. 对旧算术项 \(\mathcal R_k=-\sum_{n\text{ 素数幂}}c_n(T_n+T_n^*)\)，定义
\[
(T_nf)(t)=1_{t\le k/n}f(nt),\qquad
(T_n^*f)(t)=1_{t\ge n}f(t/n),\qquad
c_n=\frac{\Lambda(n)}{\sqrt n}.
\]
在 \(u=\log t\) 下，它们分别把支撑平移 \(-\log n\) 和 \(+\log n\)，没有伸缩槽宽。另定义 \(c_t=0\) 当正有理数 \(t\) 不是整数素数幂。对任意 \(x,y\in\mathcal F_p\)，有精确矩阵公式
\[
\boxed{\langle w_x,\mathcal R_kw_y\rangle
=-c_{x/y}-c_{y/x}-c_{xy}.}
\tag{3}
\]
其中 \(x=y\) 时仍保留可能的 \(-c_{x^2}\) 自环。
3. 根的算术列在该族上为
\[
\boxed{\langle w_x,\mathcal R_ke_p\rangle=-\sqrt2\,c_x.}
\tag{4}
\]
特别地，每个 \(x\in\mathcal F_p\) 的分母、分子都小于 \(p\)，不需要固定 \(\beta<1\)；(3) 是全 Farey 族的精确图，而不是 Archimedean 或完整旧算子的正性结论。

## 证明

旧空间在对数坐标是 \((0,2\log p)\)，反射是 \(u\mapsto2\log p-u\)。它把 \(\varphi_{px}\) 送成 \(-\varphi_{p/x}\)，因此 \(w_x\) 为奇向量。由于 \(x\le p-1\) 且 \(e^\Delta=\sqrt{1+p^{-2}}<p/(p-1)\)，有 \(px e^\Delta<p^2\) 和 \((p/x)e^{-\Delta}>1\)；两偶极的全部半槽都严格位于旧区间内部。它们的中心 \(px\) 与 \(p/x\) 分居 \(p\) 两侧且距离 \(2\log x>2\Delta\)，故 \(\|w_x\|=1\)。

若 \(x=a/b\ne y=c/d\)，同臂中心比为 \(x/y=ad/bc\)，其中正整数 \(ad,bc<p^2\)。因为不相等，\(|ad-bc|\ge1\)，从而
\[
|\log(x/y)|>\log(1+p^{-2})=2\Delta.
\tag{5}
\]
异臂中心比为 \(xy>1\)；每个 \(x=a/b>1\) 满足 \(x\ge1+1/b>1+1/p\)，故 \(\log(xy)>2\Delta\)。不同 \(w_x\) 的物理槽不相交，证明正交归一。

低整数 \(e_m\)（\(2\le m\le p\)）的两个中心是 \(m,p^2/m\)。它与 \(w_x\) 的任意中心比都可写为 \(A/B\)、\(A,B<p^2\)，所以若半槽相交，上述整数间距论证强制两个中心精确相等。四种中心配对只可能给出 \(ma=pb\) 或 \(mb=pa\)。由于 \(a,b<p\) 且 \(p\) 为素数，两式都强制 \(p\mid m\)，故 \(m=p\) 且 \(a=b\)，与 \(x>1\) 矛盾。于是每个 \(w_x\in Q_pH_k^-\)。

对算术平移，\(T_n\) 将支撑中心 \(z\) 移至 \(z/n\)，\(T_n^*\) 将它移至 \(nz\)。任意两个物理中心 \(z,z'\in\{px,p/x,py,p/y\}\) 的比仍可写为 \(A/B\)、\(A,B<p^2\)。若 \(T_n^*\varphi_z\) 与 \(\varphi_{z'}\) 相交，则
\[
|\log(nA/B)|<2\Delta=\log(1+p^{-2})
\quad\Longrightarrow\quad |nA-B|<B/p^2<1.
\tag{6}
\]
整数性迫使 \(nz=z'\)；此时两个完整 \(\varphi\) 精确重合，内积为一。\(T_n\) 给出同一无向边的反向。

两对同臂中心可整槽相接，恰当且仅当 \(x/y=n\) 或 \(y/x=n\)；两对异臂中心可整槽相接，恰当且仅当 \(xy=n\)。每种关系的两次半权配对恰好相加为一。允许两种不同关系同时出现，此时各自的 \(-c_n\) 贡献相加。因此得到 (3)，包括自环。

对根 \(e_p=\varphi_p\)，仅当 \(x=n\) 是整数素数幂时，两个中心 \(p/x,px\) 分别由 \(T_n,T_n^*\) 与根整槽相接；\(w_x\) 的 \(1/\sqrt2\) 归一化使系数为 \(-\sqrt2c_x\)。这证明 (4)。\(\square\)

## 边界

完整 Farey 族虽然算术上精确闭合于 (3)，其 Archimedean 非对角行和在分母达到 \(p\) 时不能由 \(o(1)\) 的间距估计支付；scratch 793--794 的渐近能量论证因此固定 \(\beta<1\) 再取极限。式 (3)--(4) 不判定全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
