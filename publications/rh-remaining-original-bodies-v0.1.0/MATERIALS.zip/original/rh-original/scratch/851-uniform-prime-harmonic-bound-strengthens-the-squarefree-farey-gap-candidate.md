# 去掉素数调和行界的正误差并加强平方自由 Farey 谱隙（待独立复核）

此候选已晋级为 [note 797](../notes/797-uniform-prime-harmonic-bound-strengthens-the-squarefree-farey-gap.md)；以该 note 为权威版本。

日期：2026-09-29。依赖 [note 796](../notes/796-entire-squarefree-two-arm-farey-compression-has-a-uniform-positive-gap.md) 的完整平方自由双臂空间、[note 793](../notes/793-fixed-prime-cylinder-profiles-have-positive-squarefree-two-arm-weil-limits.md) 式 (11b) 的精确行式，以及 [note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的正余项。这里只替换 note 796 的统一素数权界；不修改冻结 SPEC。

## 命题

对所有实数 \(t\ge1\)，令 \(P_5(t)=\sum_{5\le q\le t,\ q\ {\mathrm{prime}}}(\log q)/q\)。则
\[
\boxed{P_5(t)\le\log t.}\tag{1}
\]
因此 note 796 的整个 \(S_p\) 主压缩满足更强的
\[
\boxed{P_{S_p}A_{p^2,-}P_{S_p}\succeq
(\kappa_*-o(1))I_{S_p},\qquad
\kappa_*=1-\gamma_E-\log\pi+\log12+\delta_0>\frac95,}
\tag{2}
\]
其中 \(\delta_0=\log(729/512)-\zeta(3)/8\)。特别地，对充分大的奇素数 \(p\)，整个主压缩的谱底至少为 \(9/5\)。

## 证明统一素数权界

记 \(\psi(N)=\sum_{q^r\le N}\log q\)、\(M(N)=\sum_{q^r\le N}(\log q)/q^r\)。note 796 式 (4) 的二项系数论证对每个整数 \(N\ge2\) 给出
\[
\psi(N)\le\psi(\lceil N/2\rceil)+N\log2.\tag{3}
\]
令 \(N_0=N\)、\(N_{j+1}=\lceil N_j/2\rceil\)，到 \(N_J=1\) 停止。这里 \(J=\lceil\log_2N\rceil\)，且 \(N_j=\lceil N/2^j\rceil<N/2^j+1\)。逐次使用 (3)，由于 \(\psi(1)=0\)，得到
\[
\psi(N)\le(\log2)\sum_{j=0}^{J-1}N_j
<2N\log2+J\log2
\le2N\log2+\log N+\log2.\tag{4}
\]
由 \(\log N!=\sum_{n\le N}\Lambda(n)\lfloor N/n\rfloor\)、\(\lfloor N/n\rfloor\ge N/n-1\)，以及 \(\log N!\le N\log N-N+1+\log N\)，有
\[
M(N)\le\log N+2\log2-1+
\frac{1+2\log N+\log2}{N}.\tag{5}
\]
置 \(c_{23}=(\log2)/2+(\log3)/3\)。函数 \((1+2\log x+\log2)/x\) 在 \(x\ge25\) 递减，而
\[
2\log2-1+\frac{1+2\log25+\log2}{25}
<0.712<c_{23}.\tag{6}
\]
例如 \(0.693147<\log2<0.693148\)、\(1.098612<\log3\) 与 \(\log25<3.218876\) 已足以验证 (6)；这些有理小数界可由 \(\log((1+u)/(1-u))=2\sum_{j\ge0}u^{2j+1}/(2j+1)\) 及几何尾直接取得。因此 \(M(N)\le\log N+c_{23}\) 对所有 \(N\ge25\) 成立。取 \(N=\lfloor t\rfloor\)，删去 \(2,3\) 的首幂并保留其余非负素数幂，得到 \(P_5(t)\le M(N)-c_{23}\le\log N\le\log t\)，只要 \(t\ge25\)。

对 \(1\le t<5\)，\(P_5(t)=0\le\log t\)。对 \(5\le t<25\)，全部可能出现的素数只有 \(5,7,11,13,17,19,23\)，且
\[
P_5(t)\le\sum_{q\in\{5,7,11,13,17,19,23\}}\frac{\log q}{q}
<\frac{33+28+22+20+17+16+14}{100}=\frac32<\log5\le\log t.\tag{7}
\]
式 (7) 的七个逐项有理上界同样由上面的对数级数与几何尾核验。这证明 (1)。

## 谱隙

沿用 note 796 的正权 \(v_{n,m}=(nm)^{-1/2}\)。note 793 式 (11b) 中两个占据素数和非负，而 (1) 给
\[
\frac{(C_{S_p}v)_{n,m}}{v_{n,m}}
\le \log n+\log(X/n)+\log m+\log(Y/m)
=\log X+\log Y.
\]
正权 Schur 检验于是给 \(\|C_{S_p}\|\le\log X+\log Y=2\log p-\log12+o(1)\)。与 note 791 的 \(D_k=2\log p+1-\gamma_E-\log\pi\) 和 note 795 的 \(E_p\succeq(\delta_0-o(1))I\) 合并，即得 (2)。为核对常数，使用 note 796 已列出的 \(\gamma_E<0.60\)、\(\log\pi<1.15\)、\(\log12>2.48\)、\(\delta_0>0.11\)，便有 \(\kappa_*>1.84>9/5\)。\(\square\)

## 边界

式 (1) 在 \(t=1\) 等号成立，因而该**统一标量行界**的误差零已经最优；它不说明谱底 \(\kappa_*\) 最优。(2) 只涉及完整 \(S_p\) 主压缩。全 Farey 压缩的其他方向、无限维旧奇空间的 Schur 反馈、全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 都未由此判定。
