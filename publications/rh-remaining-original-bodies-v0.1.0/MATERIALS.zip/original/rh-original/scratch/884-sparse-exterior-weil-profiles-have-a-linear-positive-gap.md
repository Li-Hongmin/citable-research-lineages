# 槽外稀疏全轮廓在全部充分大尺度保留线性 Weil 正谱隙

日期：2026-10-01。依赖 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽 Archimedean 闭形式和相离核、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇算子素数幂平移约定，以及 [scratch/828 对应的权威 note](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的槽外上臂空间。这里直接估计稀疏槽族上的**完整旧奇 Weil 形式**，包括全部素数幂、polar、任意槽内有限能量轮廓；没有把中心化素数算子单独要求正定。结论未经异源复核，留在 scratch；它不覆盖整个槽外空间或无限维其余补空间。

[旧 scratch](exterior-prime-linear-negative-directions-require-logarithmic-fourier-energy.md) 式 (15) 已提出同一槽族的定性稀疏正性。本稿的增量是仅依赖已编号单槽公式和整数槽距的直接证明，以及显式的 \(p/16\) 支撑范围和 \(3/4\) 线性间隙；不得把定性结论称作首次发现。

## 定理

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)、\(k=p^2\)、\(\ell_p=\log(1+p^{-2})\)。取既约有理数族
\[
\mathcal G_p=\left\{\frac nb:
 \frac{p^{3/2}}8\le n\le\frac{p^{3/2}}4,\quad
 \frac{\sqrt p}{2}\le b\le\sqrt p,\quad(n,b)=1\right\}.
\tag{1}
\]
对 \(x\in\mathcal G_p\)，令上臂槽 \(I_x^+\) 为中心 \(\log(px)\)、长度 \(\ell_p\) 的开区间，下臂槽为关于 \(H\) 的反射。给定任意子集 \(\mathcal S\subset\mathcal G_p\)、\(1\le N=|\mathcal S|\le p/16\)，令 \(V_{\mathcal S}\) 是支撑于这些上下槽且关于 \(u\mapsto2H-u\) 为奇函数的全部 \(L^2\) 轮廓。则对每个 \(f\in V_{\mathcal S}\cap D(Q_W^{H})\)，
\[
\boxed{\qquad
 A_{p^2,-}[f]\ge
 \left(\frac34-o(1)\right)H\,\|f\|_2^2 .
\qquad}\tag{2}
\]
这里 \(o(1)\) 对所有 \(\mathcal S\) 及所有有限能量轮廓一致。特别地，旧奇 Weil 形式在这类任意多达 \(p/16\) 个槽的无限维子空间上严格正；若完整槽外空间出现负方向，其支撑必须涉及超过 \(p/16\) 个上臂槽。后一必要条件只针对以**完整物理槽**计数的支撑，不限制一个轮廓在槽内如何振荡。

## 槽分离与 Archimedean 能量

每个 \(x\in\mathcal G_p\) 满足 \(p/8\le x\le p/2\)。若 \(x=n/b\ne y=n'/b'\)，则 \(nb'\) 与 \(n'b\) 是两个不同正整数，且均不超过 \(p^2/4\)。因此其对数中心间距满足
\[
 |\log(x/y)|\ge\delta_p:=\log(1+4p^{-2})
 =(4+o(1))p^{-2},
 \qquad \ell_p=(1+o(1))p^{-2}.
\tag{3}
\]
特别地各槽两两相离，且 \(\delta_p>\ell_p\)。

在上臂 \(E_{\mathcal S}=\bigcup_{x\in\mathcal S}I_x^+\) 上以
\[
(\mathcal Jg)(u)=
\begin{cases}
g(u)/\sqrt2,&u\in E_{\mathcal S},\\
-g(2H-u)/\sqrt2,&u\in2H-E_{\mathcal S},\\
0,&\text{其余}
\end{cases}
\tag{4}
\]
作等距识别。note 790 的单槽恒等式给每个上臂轮廓及其奇反射的自能量至少 \((2H-C)\) 倍平方范数；上下臂之间的交叉在下文一同估计。不同物理槽的非局部核为 \(-K(d)\)，其中
\[
 K(d)=\frac{e^{-d/2}}{1-e^{-2d}},\qquad
 K(d)\le\frac1{2d}+C\ (d>0).
\tag{5}
\]
两个同臂槽中心相距 \(d>\ell_p\) 时，对应交叉块的算子范数至多 \(\ell_p K(d-\ell_p)\)；这是对两个长度 \(\ell_p\) 的区间先取核的上确界、再用 Cauchy--Schwarz。

固定一槽，把左右两侧其余槽各按距离排序。由 (3)，第 \(j\) 个单侧邻槽距离至少 \(j\delta_p\)。由 (5) 及 \(N\le p/16\)，其同臂交叉块的绝对行和至多
\[
\begin{aligned}
2\sum_{j=1}^{N-1}\ell_p K(j\delta_p-\ell_p)
&\le\sum_{j=1}^{N-1}
       \frac{\ell_p}{j\delta_p-\ell_p}
       +O(N\ell_p)\\
&\le\left(\frac14+o(1)\right)\log N+O(1)
 \le\left(\frac14+o(1)\right)H+O(1).
\end{aligned}\tag{6}
\]
上下异臂的任意两中心距离至少
\(\log(xy)\ge2H-O(1)\)，故每个交叉块为
\(O(\ell_p/p)=O(p^{-3})\)，整行至多 \(O(Np^{-3})=o(1)\)。对块矩阵使用对称 Schur 行和界，结合单槽下界及 (6)，得到
\[
 G_{p^2}[\mathcal Jg]
 \ge\left(\frac74-o(1)\right)H\,\|g\|_2^2 .
\tag{7}
\]
这一估计对槽内轮廓没有常值假设；先在各槽光滑紧支撑轮廓的有限和上成立，再由 note 790 的闭形式核心延拓。

## 素数幂平移的稀疏行界

沿 note 791 记
\(\mathcal R_{p^2}=-\sum_{m\ge2}c_m(T_m+T_m^*)\)，其中
\(c_m=\Lambda(m)/\sqrt m\)，仅素数幂非零。先证**同臂压缩精确为零**。若一个整数平移 \(m\ge2\) 使 \(I_x^+\) 与 \(I_y^+\) 相交，必须
\(|\log(mx/y)|<\ell_p\)。将 \(x=n/b,y=n'/b'\) 代入，分母 \(n'b\le p^2/4\)；两个交叉积为整数，而 \(e^{\ell_p}-1=p^{-2}\)。因此严格相交迫使 \(mx=y\)。设 \(d=(m,b)\)，则已约分的 \(y\) 必有
\(n'=(m/d)n,\ b'=b/d\)。若 \(m/d\ge2\)，则
\(n'\ge2n>p^{3/2}/4\)；若 \(m/d=1\)，则
\(b'\le b/2<\sqrt p/2\)。两者均与 (1) 矛盾。下臂同理。

异臂反射在 \(\mathcal J\) 坐标中给出 note 828 的算子
\[
 (J_mg)(u)=\mathbf1_{E_{\mathcal S}}(2H+\log m-u)
                  g(2H+\log m-u).
\tag{8}
\]
这里的系数可直接核对。取对数坐标下 \((T_mf)(u)=f(u+\log m)\)。同臂块已为零，且 \(\log m>0\)，所以 \(\langle\mathcal Jg,T_m\mathcal Jg\rangle\) 只含下臂到上臂的配对。置 \(v=2H-u\)，两臂的 \(1/\sqrt2\) 与奇反射负号给
\[
\langle\mathcal Jg,T_m\mathcal Jg\rangle
=-\tfrac12\langle g,J_mg\rangle,
\qquad
\langle\mathcal Jg,(T_m+T_m^*)\mathcal Jg\rangle
=-\langle g,J_mg\rangle.
\]
因此 \(\mathcal R_{p^2}\) 的异臂压缩恰为 \(+\sum_m c_mJ_m\)，没有额外的因子二；下文只用其绝对范数。
对一对槽 \(x,y\in\mathcal S\)，(8) 的块非零必须
\(|\log(m/(xy))|<\ell_p\)。允许的整数 \(m\) 落在
\((xy e^{-\ell_p},xy e^{\ell_p})\)，其长度至多
\[
 \frac{p^2}{4}\bigl(e^{\ell_p}-e^{-\ell_p}\bigr)
 =\frac12+o(1)<1 .
\tag{9}
\]
所以每个有序槽对至多对应一个素数幂。若其存在，则
\(p^2/64(1-o(1))\le m\le p^2/4(1+o(1))\)，从而
\[
 c_m\le(16+o(1))\frac Hp .
\tag{10}
\]
每个反射块的算子范数至多一。对 \(N\times N\) 对称块矩阵使用绝对行和 Schur 界，得
\[
 \left\|P_{V_{\mathcal S}}\mathcal R_{p^2}P_{V_{\mathcal S}}\right\|
 \le(16+o(1))\frac{NH}{p}
 \le(1+o(1))H .
\tag{11}
\]
这里已包含全部高次素数幂，无需另把素数密度与高次幂分离。

## polar 与合并

旧奇 polar 向量为 \(s(u)=\sinh((u-H)/2)\)。由奇反射及 (4)，
\[
2|\langle s,\mathcal Jg\rangle|^2
\le4\left(\int_{E_{\mathcal S}}|s(u)|^2\,du\right)\|g\|_2^2.
\]
对 \(u\in I_x^+\)、\(x\le p/2\)，有
\(|s(u)|^2\le(1+o(1))p/8\)。因此
\[
2|\langle s,\mathcal Jg\rangle|^2
\le (1+o(1))\frac{N}{2p}\|g\|_2^2=O(1)\|g\|_2^2 .
\tag{12}
\]
将 \(A_{p^2,-}=G_{p^2}+\mathcal R_{p^2}-2|s\rangle\langle s|\) 与
(7)、(11)、(12) 合并，得到
\[
 A_{p^2,-}[\mathcal Jg]
 \ge\bigl((7/4-1-o(1))H-O(1)\bigr)\|g\|_2^2,
\]
即 (2)。\(\square\)

## 全槽族上的有效参与数必要条件

同一证明不必把 \(N\) 限为 \(p/16\)。对任意非空 \(\mathcal S\subset\mathcal G_p\) 及 \(g=\sum_{x\in\mathcal S}g_x\in L^2(E_{\mathcal S})\)，设 \(N=|\mathcal S|\)。因为 \(|\mathcal G_p|<p^2\) 对充分大 \(p\) 成立，(6) 的计算在全部 \(1\le N<p^2\) 上给出一致行界
\[
G_{p^2}[\mathcal Jg]\ge
\bigl(2H-\tfrac14\log N-C\bigr)\|g\|_2^2.
\tag{13}
\]
这里 \(O(N\ell_p)=O(1)\)，异臂行和 \(O(Np^{-3})=o(1)\)，故误差不随所选槽族增长。

记 \(a_x=\|g_x\|_2\)。每个有序槽对仍至多有一个素数幂反射块，故不经 Schur 行和而直接逐块估计得
\[
|\mathcal R_{p^2}[\mathcal Jg]|
\le(16+o(1))\frac Hp\Bigl(\sum_xa_x\Bigr)^2.
\]
每槽又有 \(\|s\|_{L^2(I_x^+)}^2\le(1+o(1))/(8p)\)，因此
\[
2|\langle s,\mathcal Jg\rangle|^2
\le\frac{1+o(1)}{2p}\Bigl(\sum_xa_x\Bigr)^2.
\]
合并得到对**任意**槽数与轮廓一致的下界
\[
\boxed{\quad
A_{p^2,-}[\mathcal Jg]\ge
\bigl(2H-\tfrac14\log N-C\bigr)\|g\|_2^2
-\left((16+o(1))\frac Hp+\frac{1+o(1)}{2p}\right)
\Bigl(\sum_x\|g_x\|_2\Bigr)^2.
\quad}
\tag{14}
\]
若 \(g\ne0\) 且左侧非正，定义有效槽参与数
\(N_{\rm eff}(g)=(\sum_x\|g_x\|_2)^2/\|g\|_2^2\)。由
\(\log N<2H\) 与 (14)，必有
\[
\boxed{\qquad
N_{\rm eff}(g)\ge\bigl(\tfrac{3}{32}-o(1)\bigr)p,
\qquad |\operatorname{supp}_{\rm slot}g|\ge N_{\rm eff}(g).
\qquad}
\tag{15}
\]
特别地，对任意固定 \(0<\alpha<7/64\)，若 \(N\le\alpha p\)，(14) 与 \(N_{\rm eff}\le N\) 还给
\[
A_{p^2,-}[\mathcal Jg]\ge
\bigl(\tfrac74-16\alpha-o(1)\bigr)H\|g\|_2^2.
\tag{16}
\]
式 (15) 是完整槽外主压缩出现非正方向的 \(\ell^1/\ell^2\) 必要条件，比仅计算非零槽数更细。它不强制固定比例的 \(L^2\) 质量落在大量槽上：极多微小尾槽也可能增大 \(N_{\rm eff}\)。这些结论不估计槽外空间与其余旧奇空间的交叉。

## 连续尺度推广

上述素数假设并未进入任何估计。令 \(X\to\infty\) 沿**任意实数**，置 \(H_X=\log X\)、\(k_X=X^2\)、\(\ell_X=\log(1+X^{-2})\)，并以严格边界定义
\[
\mathcal G_X^\circ=
\left\{\frac nb:\
\frac{X^{3/2}}8<n<\frac{X^{3/2}}4,\quad
\frac{\sqrt X}{2}<b<\sqrt X,\quad(n,b)=1\right\}.
\]
上臂槽仍以 \(\log(Xx)\) 为中心、长 \(\ell_X\)，下臂关于 \(H_X\) 反射。若 \(\mathcal S\subset\mathcal G_X^\circ\) 非空且 \(|\mathcal S|\le X/16\)，则全部有限能量奇轮廓满足
\[
\boxed{\quad A_{X^2,-}[f]\ge
\bigl(\tfrac34-o(1)\bigr)(\log X)\|f\|_2^2.\quad}
\tag{17}
\]
式 (14)--(16) 也逐字适用，只须把 \(p,H\) 换为 \(X,H_X\)。事实上整数交叉积仍至多为 \(X^2/4\)，给出 (3) 的槽距；若同臂平移精确碰撞且 \(d=(m,b)\)，则 \(m/d\ge2\) 强制 \(n'\ge2n>X^{3/2}/4\)，而 \(m/d=1\) 强制 \(b'=b/d\le b/2<\sqrt X/2\)。这两个严格矛盾不要求 \(X\) 为素数或整数。其余 Archimedean、反射整数窗、素数幂权和 polar 界只依赖 \(X\to\infty\) 的尺度，故同一闭形式证明给出 (17)。\(\square\)

## 边界

本定理把 note 828 中的负中心化素数本质谱与真实 Weil 形式区别开：至少在线性稀疏的槽族上，完整 Archimedean 成本严格支付所有素数幂反射及 polar。它没有处理占据 \(\gg p\) 乃至 \(p^2\) 个槽的密集轮廓，也没有控制 \(V_{\mathcal S}\) 与其余旧奇空间的 Schur 反馈。因此局部 Weil 全尺度正性、moving-\(N\) Möbius signed covariance 和 RH 仍开放。
