# 增长 dyadic Weil 压缩隙对应的真实补槽交叉至少为平方根对数级

日期：2026-10-03。依赖 [note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整数整除矩阵和单槽界、[note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的完整 Weil 形式分解，以及 [scratch 973](973-growing-dyadic-odd-union-has-a-full-profile-weil-gap.md) 的 dyadic 槽几何与奇数格张量矩阵。下面仅用这些已写出的解析恒等式，不调用数值计算。结论给出真实 Weil 形式中的一个显式低能量延拓和补槽交叉下界；尚待异源复核，因此只留在 scratch。它不证明或反驳 RH。

常数级 Schur 余项另用 [note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的严格单位轮廓谱隙。

## 定理

固定 $0<\theta<1$ 和非负、非零、实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$。沿奇素数 $p\to\infty$ 取
\[
 H=\log p,\quad R=\lceil\log_2 H\rceil,\quad
 M=\left\lfloor\frac{p^2}{2^{R+1}}\right\rfloor-1,\quad
 N=\left\lfloor\frac{p^2}{2}\right\rfloor-1,\quad
 \ell=\frac{2\theta}{p^2}.                              \tag{1}
\]
令 $I_n$ 为中心 $y_n=H-\log(2n)$、宽度 $\ell$ 的区间，$1\le n\le N$。置
\[
 S=\{2^j a:0\le j\le R,\ a\le M\text{ 为奇数}\},\qquad
 U=\bigcup_{n\in S}I_n,\quad V=\bigcup_{\substack{1\le n\le N\\n\notin S}}I_n,
 \quad L_N=\sum_{n\le N}\frac1n,                           \tag{2}
\]
并令 $b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$，
\[
 F(y_n+t)=\frac{b_\ell(t)}{\sqrt{nL_N}}
 \quad(|t|<\ell/2),\qquad F_U=F\mathbf1_U,\quad F_V=F\mathbf1_V.
                                                                    \tag{3}
\]
则 $F=F_U+F_V$ 属于完整局部 Weil 闭形式域，$\|F\|_2=1$，且
\[
 \|F_V\|_2^2=\frac{R\log2+O(1)}{2H+O(1)},\qquad
 Q_W^H[F]=O_{\theta,\varphi}(1),\qquad
 Q_W^H[F_U]=R\log2+O_{\theta,\varphi}(1),\qquad
 Q_W^H[F_V]=R\log2+O_{\theta,\varphi}(1).           \tag{4}
\]
特别地，记 $Q_W^H(F_U,F_V)$ 为该实闭形式的极化交叉项，则
\[
\boxed{\quad
 Q_W^H(F_U,F_V)
 =-R\log2+O_{\theta,\varphi}(1).
\quad}                                                        \tag{5}
\]
换言之，这两个具体非归一化方向的真实 Weil 压缩矩阵逐项满足
\[
 \begin{pmatrix}
 Q_W^H[F_U]&Q_W^H(F_U,F_V)\\
 Q_W^H(F_U,F_V)&Q_W^H[F_V]
 \end{pmatrix}
 =R\log2\begin{pmatrix}1&-1\\-1&1\end{pmatrix}
  +O_{\theta,\varphi}(1)_{\rm entrywise}.                 \tag{5a}
\]
对充分大 $p$ 有 $Q_W^H[F_V]>0$，所以这一条显式补槽方向的 Schur 扣款精确到有界误差：
\[
\boxed{\quad
 Q_W^H[F_U]-\inf_{t\in\mathbb R}Q_W^H[F_U+tF_V]
 =\frac{Q_W^H(F_U,F_V)^2}{Q_W^H[F_V]}
 =R\log2+O_{\theta,\varphi}(1),
 \qquad t_{\min}=1+O_{\theta,\varphi}(R^{-1}).
\quad}                                                        \tag{5b}
\]
记 $\kappa_\varphi=\int\varphi$、
$C_\varphi=\int_{\mathbb R}\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)$。则被这条补槽方向抵消后的常数极限也存在：
\[
\boxed{\quad
 \lim_{p\to\infty}\inf_{t\in\mathbb R}Q_W^H[F_U+tF_V]
 =\log(1/\theta)+C_\varphi+\gamma-\log(2\pi)
    +\theta\kappa_\varphi^2
 \ge\frac{46}{25}-\log(2\pi)>0.
\quad}                                                        \tag{5c}
\]
因此 $U$ 与显式补槽空间 $V$ 之间的 $L^2$ 归一化交叉范数至少为
\[
\boxed{\quad
 \sup_{\substack{f\in D(Q_W^H),\ \operatorname{supp}f\subset U,\ \|f\|_2=1\\
                    g\in D(Q_W^H),\ \operatorname{supp}g\subset V,\ \|g\|_2=1}}
       |Q_W^H(f,g)|
 \ge (1+o(1))\sqrt{2HR\log2}.
\quad}                                                        \tag{6}
\]
由于 $R\asymp\log H$，该下界为 $\Omega(\sqrt{H\log H})$。式 (5) 是**实际**压缩槽到补槽的负交叉，不是从一般 Schur 不等式推测的量。式 (6) 表明将 dyadic 正隙推广到完整空间时，不能把补槽交叉视为 $o(R)$ 的形式扰动。

## 证明

**几何。** $2^RM\le N$，且 [scratch 973](973-growing-dyadic-odd-union-has-a-full-profile-weil-gap.md) 的中心 $H-\log(2^{R+1}a/2^r)$ 恰等于 $y_n$，其中 $n=2^{R-r}a$；所以 $U$ 正是该稿的 dyadic 并集。最小整数中心间距为 $\log(N/(N-1))=(2+o(1))/p^2>\ell$。$y_N+H=\log(p^2/(2N))>\ell/2$，$H-y_1=\log2>\ell/2$，故所有槽相离并位于 $(-H,H)$。又 $N(e^\ell-1)=\theta+o(1)<1$，所以素数幂位移连结两槽仅在整数指标精确整除时发生。式 (3) 因而是有限个光滑紧支撑函数之和，且每槽 $L^2$ 质量为 $1/(nL_N)$。

**补槽质量。** 写 $S_M=\sum_{a\le M,\ a\text{ 奇}}a^{-1}$。由调和数公式，
\[
 L_N=\log N+\gamma+O(N^{-1})=2H+O(1),\qquad
 S_M=\tfrac12(\log M+\gamma+\log2)+O(M^{-1}).          \tag{7}
\]
集合 $S$ 是不交并，故
\[
 \sum_{n\in S}\frac1n
 =\sum_{j=0}^R2^{-j}S_M
 =(1-2^{-R-1})(\log M+\gamma+\log2)+O(M^{-1}).     \tag{8}
\]
$\log N-\log M=R\log2+o(1)$，且 $2^{-R}H=O(1)$。从 (7)--(8) 得
$L_N-\sum_{n\in S}1/n=R\log2+O(1)$，这给 (4) 的第一式，且 $\|F_U\|_2^2=1-O(R/H)$。

**完整整数格的有界能量。** 对任一由这些槽组成的 $E\subset\{1,\ldots,N\}$，写 $F_E=F\mathbf1_{\cup_{n\in E}I_n}$、$\mu_E=\|F_E\|_2^2$。note 857 式 (5) 的单槽 Fourier--gamma 对角贡献为
\[
 D_\ell\mu_E,\qquad
 D_\ell=\log(1/\ell)+C_\varphi-\log(2\pi)+O_\varphi(\ell).
                                                                    \tag{9}
\]
note 854 的整数整除矩阵 $C_N$ 为非负对称矩阵，其自然权 $n^{-1/2}$ 满足逐行商 $\log N+O(1)$；Schur 检验给
$\|C_N\|\le\log N+C$。同一自然向量的 Rayleigh 商为 $\log N+O(1)$。因此完整 $F$ 的素数幂罚项为 $-\log N+O(1)$，而任意 $F_E$ 的素数幂罚项不小于 $-(\log N+C)\mu_E$。

普通跨槽核为 $-k(|y-z|)$，$k(t)=e^{-t/2}/(1-e^{-2t})>0$。由于固定 $\theta<1$ 留有槽间隙，两个不同槽的积分块至多为 $C_\theta\ell k(|\log(n/m)|)$ 倍相应单位轮廓系数。note 857 式 (6) 的恒等式及求和给
\[
 \frac\ell{L_N}\sum_{n\ne m\le N}
 \frac{k(|\log(n/m)|)}{\sqrt{nm}}
 \ll_\theta \frac{\ell N\log N}{L_N}=O_\theta(1).
                                                                    \tag{10}
\]
因为 $F_E\ge0$ 且 $F_E\le F$ 逐点，任意 $E$ 的普通跨槽项均位于 $[-C_{\theta,\varphi},0]$。polar 项是 $2P_+(F_E)P_-(F_E)\ge0$，同样由 $0\le F_E\le F$ 及 note 857 的矩求和有
\[
 0\le2P_+(F_E)P_-(F_E)
 \le2P_+(F)P_-(F)=O_{\theta,\varphi}(\ell N)=O_{\theta,\varphi}(1).
                                                                    \tag{11}
\]
用 (9)--(11) 和完整自然向量的 prime Rayleigh 商，
\[
 Q_W^H[F]=D_\ell-\log N+O_{\theta,\varphi}(1)
 =\log\frac1{\ell N}+O_{\theta,\varphi}(1)=O_{\theta,\varphi}(1),
                                                                    \tag{12}
\]
因为 $\ell N=\theta+o(1)$。
对完整 $F$ 可把 (12) 的有界余项算到常数。note 857 式 (3)--(4) 的加权素数定理与自然权平均对任意 $N\to\infty$ 给
$Q_{\rm prime}[F]=-\log N+\gamma+o(1)$。同一 note 式 (6) 的整数格恒等式给
\[
 \sum_{n\ne m\le N}\frac{k(|\log(n/m)|)}{\sqrt{nm}}
 =N\log N+O(N).
\]
在相邻槽处 $\ell N\to\theta<1$，所以把双槽积分换成中心核的误差仍按 note 857 的近差 $d^{-2}$ 求和，归一化后为 $O_{\theta,\varphi}(\ell^2N^2/L_N)=o(1)$；远差误差更小。因此
$Q_{\rm ord}[F]=-\kappa_\varphi^2\ell N+o(1)=-\theta\kappa_\varphi^2+o(1)$。
两个极点矩直接求和给
$Q_{\rm pol}[F]=2N\bigl(\int b_\ell(t)e^{t/2}dt\bigr)
\bigl(\int b_\ell(t)e^{-t/2}dt\bigr)
=2\theta\kappa_\varphi^2+o(1)$。于是 (9) 的对角项与这三项合成
\[
 Q_W^H[F]
 =\log(1/\theta)+C_\varphi+\gamma-\log(2\pi)
  +\theta\kappa_\varphi^2+o(1).                       \tag{12a}
\]
这里仅把 note 857 的整数格中心常数 $4$ 换为 $2$，且 $\ell N\to\theta<1$ 使其所有精确整除和中心核误差仍适用。

同样对 $E=\{1,\ldots,N\}\setminus S$，
\[
 Q_W^H[F_V]\ge(D_\ell-\log N-C)\|F_V\|_2^2
 -C_{\theta,\varphi}\ge-C_{\theta,\varphi},              \tag{13}
\]
这先给出 (4) 末式所需的单侧下界；精确主项将在 (17) 后推出。

**dyadic 压缩能量。** 在 $S$ 上，整数 $n=2^j a$ 的素数幂整除矩阵精确分解为奇素数幂的 $C_{\rm odd}(M)\otimes I_{R+1}$ 与同一奇数 $a$ 的 $2$ 幂矩阵 $I\otimes D_R$，见 scratch 973 式 (6)。对自然权 $n^{-1/2}$，奇素数幂的逐行商为
\[
 \sum_{\substack{k\le M/a\\k\text{ 奇}}}\frac{\Lambda(k)}k+\log a
 =\log M+O(1)
\]
；$2$ 幂向内部祖先的逐行商为 $j\log2$，向内部后代的逐行商为 $(\log2)\sum_{1\le d\le R-j}2^{-d}=O(1)$。故完整内部行商是 $\log M+j\log2+O(1)$。以 $1/(2^jaL_N)$ 加权求平均，因 $\sum_{j\ge0}j2^{-j}=2$、$S_M/L_N=O(1)$，得到内部 prime 罚项的精确值
\[
 Q_{\rm prime}[F_U]=-\log M\,\|F_U\|_2^2+O(1).
 \tag{14}
\]
式 (9)--(11) 给普通核与 polar 项各 $O_{\theta,\varphi}(1)$，所以
\[
 Q_W^H[F_U]
 =(D_\ell-\log M)\|F_U\|_2^2+O_{\theta,\varphi}(1)
 =R\log2+O_{\theta,\varphi}(1),                         \tag{14a}
\]
这里用 $\|F_U\|_2^2=1-O(R/H)$ 和 $R^2/H\to0$。这证明 (4) 的第三式；[scratch 973](973-growing-dyadic-odd-union-has-a-full-profile-weil-gap.md) 另对 $U$ 上的任意有限能量轮廓给同主阶谱隙，但 (14a) 只需上述自然权计算。

**直接计算补槽交叉。** 集合 $S$ 对取除数封闭：若 $n=2^ja\in S$ 且 $d\mid n$，则 $d=2^ib$，其中 $i\le j\le R$、$b\mid a\le M$ 为奇数，故 $d\in S$。因此 $S$ 与其补集之间的素数幂边只能从 $S$ 指向补集中的倍数。对 $n=2^ja\in S$，令 $E(n)$ 为该行向补集的自然权比值和。奇素数幂部分精确为
\[
 E_{\rm odd}(n)
 =A_{\rm odd}\!\left(\frac N{2^ja}\right)
  -A_{\rm odd}\!\left(\frac Ma\right),\qquad
 A_{\rm odd}(x)=\sum_{\substack{k\le x\\k\text{ 为奇素数幂}}}\frac{\Lambda(k)}k.
                                                                    \tag{15}
\]
加权素数幂恒等式给 $A_{\rm odd}(x)=\log x+O(1)$，对全部 $x\ge1$ 一致；这是 note 854 的 $\sum_{k\le x}\Lambda(k)/k=\log x+O(1)$ 扣去 $2$ 的幂。因 $N/M=2^R(1+o(1))$，式 (15) 等于 $(R-j)\log2+O(1)$，误差对所有 $j,a$ 一致。$2$ 幂向外边的比值和至多 $(\log2)\sum_{d\ge1}2^{-d}=\log2$。所以
\[
 E(2^ja)=(R-j)\log2+O(1).                            \tag{16}
\]
用 $F_U,F_V$ 的自然权展开精确 prime-shift 双线性交叉，再用 $\sum_{j\ge0}j2^{-j}=2$、(8)，得到
\[
\begin{aligned}
 Q_{\rm prime}(F_U,F_V)
 &=-\frac1{L_N}\sum_{j=0}^R2^{-j}
     \sum_{a\le M,\ a\text{ 奇}}\frac{E(2^ja)}a\\
 &=-R\log2\,\frac{\sum_{n\in S}n^{-1}}{L_N}+O(1)
 =-R\log2+O(1),
\end{aligned}                                                   \tag{17}
\]
因为 $R(1-\|F_U\|_2^2)=O(R^2/H)=o(1)$。式 (10) 控制普通核的 $U$--$V$ 交叉为 $O_{\theta,\varphi}(1)$；式 (11) 同样控制 polar 交叉。不同槽之间没有 (9) 的单槽对角项。故 (17) 给出 (5)，并且明确了主项来自真实的向外素数幂边。再由极化恒等式
$Q_W^H[F]=Q_W^H[F_U]+Q_W^H[F_V]+2Q_W^H(F_U,F_V)$，把 (12)、(14a)、(5) 代入，得到 $Q_W^H[F_V]=R\log2+O_{\theta,\varphi}(1)$，完成 (4) 的末式。

由于 $R\to\infty$，(4) 保证 $Q_W^H[F_V]>0$。对二次多项式 $Q_W^H[F_U+tF_V]$ 配方，结合 (4)--(5)，得到 (5b)。又由 $t_{\min}=1+O(R^{-1})$，
\[
 \inf_tQ_W^H[F_U+tF_V]
 =Q_W^H[F]-Q_W^H[F_V](1-t_{\min})^2
 =Q_W^H[F]+O(R^{-1}).
\]
式 (12a) 给其极限。note 858 式 (1) 给
$C_\varphi+\kappa_\varphi^2+\gamma-\log(2\pi)
\ge46/25-\log(2\pi)$；而 $\kappa_\varphi^2\le1$ 与
$-\log\theta\ge1-\theta$ 给
$-\log\theta-(1-\theta)\kappa_\varphi^2\ge0$，故得到 (5c)。最后以 $\|F_U\|_2=1+o(1)$ 和
$\|F_V\|_2^2=(R\log2+O(1))/(2H+O(1))$ 归一化，得到 (6)。$\square$

## 数学边界

这是完整 Weil 形式的**一个**具体试函数分解。它证明 dyadic 压缩的增长谱隙与同一实际算子中的增长补槽交叉并存；完整向量的 Rayleigh 商仅有界，并没有负方向。式 (5) 不替代完整补空间的 Schur 计算，也不能判定全尺度 Weil 正性。算术侧的 moving-$N$ signed covariance 仍是独立的开放门。
