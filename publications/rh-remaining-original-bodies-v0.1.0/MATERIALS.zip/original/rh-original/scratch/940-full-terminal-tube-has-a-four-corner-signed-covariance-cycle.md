# 完整物理末带的四块 signed covariance 循环

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的逐原始除数精确 Poisson 展开、[note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的完整末带素数主项，以及 [scratch/936](936-logarithmic-quarter-power-collar-for-the-two-endpoint-residual.md) 核对过的 Matomäki--Shao--Tao--Teräväinen 全区间短和输入。[scratch/939](939-same-prime-cancellation-localizes-to-a-vanishing-relative-numerator-window.md) 先在避开 $N/q=3/2$ 的子带发现了邻近分子局部化；下面覆盖 note 845 的**全部** $H<a\le11H/10$。本解析证明尚待异源复核；它不估计完整 moving-$N$ 均方门。

## 定理

固定 $0<\gamma<1/4$，$Y\to\infty$ 沿整数，$H=\lfloor Y^\gamma\rfloor$。沿用 note 845 式 (1)–(2) 的 $\mathcal A,t_a,B_a,I_a,F_{h,q}(N),G_N$，并只在 $3Y/2<N\le8Y/5$ 上取值。$F_{h,q}$ 是 note 801 式 (5) 的**原始除数** $q$、原始谐波 $h$ 的项，包含 $\mu(q)$；因为 $q>Y$ 且 $q<N$，没有第二个原始倍数。置 $W=\lfloor\log\log Y\rfloor$（只考虑充分大 $Y$，使 $1\le W<H/4$），定义
\[
\begin{aligned}
B_N&=\sum_{a\in\mathcal A}\sum_{p\in I_a\cap\mathbb P}
\sum_{|j|\le W}F_{a+j,p}(N),\\
C_N&=\sum_{a\in\mathcal A}\sum_{q\in I_a}
\sum_{|j|\le W}F_{a+j,q}(N),\\
C_{0,N}&=\sum_{a\in\mathcal A}\sum_{q\in I_a}F_{a,q}(N).
\end{aligned}
\tag{1}
\]
这些和不另设 $(h,q)=1$ 限制；它们按原始除数和原始分子切分精确 Poisson 和。$B$ 的每项却有 $0<a+j<p$，所以其既约分母仍为同一个素数 $p$。

对任意固定非负、非零 $\chi\in C_c^\infty((3/2,8/5))$，令 $\langle U,V\rangle_\chi=\sum_N\chi(N/Y)U_NV_N$，并置
\[
\mathcal L(z)=\int_1^{11/10}\log(z/x)\,dx,
\quad\kappa_\chi=\frac1{2\pi^2}
\int_{3/2}^{8/5}\chi(z)\frac{\mathcal L(z)^2}{z^2}\,dz>0,
\quad Q_Y=\|G\|_\chi^2.
\tag{2}
\]
则
\[
Q_Y=(\kappa_\chi+o(1))\frac{Y^3}{H^4(\log Y)^4},
\qquad
\sup_N(|B_N|+|C_N|+|C_{0,N}|)
=o\!\left(\frac{Y}{H^2(\log Y)^2}\right).
\tag{3}
\]
把中央素数、中央非素数、邻近素数、邻近非素数四块写成
\[
G,\qquad E_{\rm pc}=C_0-G,\qquad
E_{\rm np}=B-G,\qquad
E_{\rm nc}=C-B-C_0+G.
\tag{4}
\]
这里“非素数”指原始除数 $q$ 非素数，包含 $\mu(q)=0$ 的零项。四块互不相交，且
\[
\boxed{\quad
\langle G,E_{\rm pc}\rangle_\chi=-Q_Y+o(Q_Y),
\qquad
\langle G,E_{\rm np}\rangle_\chi=-Q_Y+o(Q_Y),
\qquad
\langle G,E_{\rm nc}\rangle_\chi=+Q_Y+o(Q_Y).
\quad}
\tag{5}
\]
因此两个同阶负补偿之间有一个同阶正块；把素数—非素数和中央—邻近分子的负项直接相加，会对同一双指标和重复计数。

## 素数邻近分子和的逐点估计

记 $z=N/Y$、$x_a=a/H$、$e(t)=e^{2\pi it}$、$c_h=4\mathbf1_{2\mid h}-1=1+2(-1)^h$。note 801 式 (5) 与 $\mu(p)=-1$ 给
\[
F_{h,p}(N)=\frac{p}{\pi Nh^2}\log\frac Np
\left(\frac{4\mathbf1_{2\mid h}}{1-4(p/(hN))^2}
-\frac1{1-(p/(hN))^2}\right)
\cos\frac{2\pi hN}{p}.
\tag{6}
\]
一致于 $a\in\mathcal A$ 有 $B_a\asymp Y/(H\log Y)=Y^{1-\gamma+o(1)}$。scratch/936 所核对的原文 Theorem 3.1(i) 与式 (3.11)，在 $q=1$、该固定幂长度上给 $\sum_{n\in I_a}\Lambda(n)=B_a+O_A(B_a/\log^A Y)$；素数高次幂的总 $\Lambda$ 权至多 $O(Y^{1/2}\log Y)$。因此
\[
\#(I_a\cap\mathbb P)
=\frac{B_a}{\log Y}\left(1+O((\log Y)^{-1})\right)
\tag{7}
\]
统一于 $a$。

对 $p\in I_a$、$|j|\le W$，有 $p=aY/H+O(Y/(H\log Y))$、$B_a=aY/(H^2\log Y)+O(1)$、$h=a+j\asymp H$；故式 (6) 的括号为 $c_{a+j}+O(H^{-2})$，并且
\[
\frac{hN}{p}=Hz+\frac{jz}{x_a}
+O((\log Y)^{-1}+H^2/Y),
\qquad
\log\frac Np=\log\frac z{x_a}
+O((H\log Y)^{-1}+H/Y).
\tag{8}
\]
相位替换不需要区分 $N/p$ 是否跨过 $3/2$。逐项取误差绝对值，再用 (7) 求素数和，得到
\[
\begin{aligned}
B_N={}&\frac{Y}{\pi H^3(\log Y)^2z}
\sum_{a\in\mathcal A}\sum_{|j|\le W}
c_{a+j}\log\frac z{x_a}
\cos\left(2\pi Hz+\frac{2\pi jz}{x_a}\right)\\
&+O_\gamma\!\left(\frac{Y}{H^2(\log Y)^2}
\left[\frac{W^2}{H}+\frac{W}{\log Y}\right]\right).
\end{aligned}
\tag{9}
\]
固定 $j$ 时，$x\mapsto\log(z/x)e(jz/x)$ 在 $[1,11/10]$ 上的变差为 $O(1+|j|)$。普通 Riemann 和以及对 $c_{a+j}$ 中 $2(-1)^{a+j}$ 作相邻配对给
\[
\frac1H\sum_{a\in\mathcal A}c_{a+j}
\log\frac z{x_a}e(jz/x_a)
=\int_1^{11/10}\log\frac z x\,e(jz/x)\,dx
+O\!\left(\frac{1+|j|}{H}\right).
\tag{10}
\]
令 $D_W(t)=\sum_{|j|\le W}e(jt)=\sin((2W+1)\pi t)/\sin(\pi t)$。由 (9)–(10)，
\[
B_N=\frac{Y\cos(2\pi Hz)}{\pi H^2(\log Y)^2z}
\int_1^{11/10}\log\frac z x\,D_W(z/x)\,dx
+O_\gamma\!\left(\frac{Y}{H^2(\log Y)^2}
\left[\frac{W^2}{H}+\frac{W}{\log Y}\right]\right).
\tag{11}
\]
在全部 $z\in[3/2,8/5]$、$x\in[1,11/10]$ 上，$z/x\in[15/11,8/5]$，与整数保持固定距离，且 $d(z/x)/dx=-z/x^2$ 远离零。把 $D_W$ 写成上面的正弦商，对积分作一次分部积分，统一得到 $O(W^{-1})$。于是
\[
\sup_N|B_N|\ll_\gamma\frac{Y}{H^2(\log Y)^2}
\left(\frac1W+\frac{W^2}{H}+\frac{W}{\log Y}\right)
=o\!\left(\frac{Y}{H^2(\log Y)^2}\right).
\tag{12}
\]
这个论证在 $N/p=3/2$ 处仍成立：该半整数是原始单项核 $\Phi(p/N)$ 的活动整数切换点，式 (11) 的分子求和只在 $z/x$ 为**整数**时有 Dirichlet 核的主峰。

## 真实 Möbius 完整短管与四块符号

取 $Q_0=\lfloor Y^{2/3}\rfloor$。同一全区间定理对每个长度 $Q_0$ 的区间给 $\sum\mu(q)\ll_A Q_0/\log^A Y$。把 $I_a$ 的任一前缀分为长 $Q_0$ 的完整块和一个余块，后者用 $|\mu|\le1$，得到
\[
\max_{u\in I_a}\left|\sum_{\substack{q\in I_a\\q\le u}}\mu(q)\right|
\ll_A B_a(\log Y)^{-A}+Q_0
\ll_A B_a(\log Y)^{-A}.
\tag{13}
\]
最后一步用 $B_a\gg Y^{3/4}/\log Y$。固定 $a,j,N$ 时，式 (6) 除 $-\mu(q)$ 外的权在 $q\in I_a$ 上的上确界为 $O(H^{-2})$，总变差也为 $O(H^{-2})$：相位 $(a+j)N/q$ 在 $I_a$ 上只变化 $O((a+j)B_a/Y)=O(1/\log Y)$，其他因子更缓。由 (13) 作 Abel 求和，再对 $a,j$ 求和，
\[
\sup_N|C_N|
\ll_A\frac{(W+1)Y}{H^2(\log Y)^{A+1}},
\qquad
\sup_N|C_{0,N}|
\ll_A\frac{Y}{H^2(\log Y)^{A+1}}.
\tag{14}
\]
取 $A>2$ 并结合 (12)，证明 (3) 的点态部分。

note 845 式 (4)、(10)–(15) 的素数主项与光滑权几何和给 $G_N=Y[\pi H^2\log^2Y]^{-1}\mathcal L(z)z^{-1}\cos(2\pi Hz)+o(Y/[H^2\log^2Y])$ 一致于物理窗口，因而得到 (3) 的 $Q_Y$ 渐近及 $\sup_N|G_N|\ll Y/[H^2\log^2Y]$。观察整数数目为 $O(Y)$，由 (3) 的点态小量可得
\[
\langle G,B\rangle_\chi,
\quad\langle G,C\rangle_\chi,
\quad\langle G,C_0\rangle_\chi=o(Q_Y).
\tag{15}
\]
式 (4) 是四个互不相交的原始双指标块；将 (15) 代入即得 (5)。$\square$

## 边界

式 (5) 解释了 note 845 的素数—合数负协方差与 scratch/939 的邻近素数分子负协方差为什么不能相加：第四块的真实非素数邻近分子正协方差大小恰好相同。虽然 (12)–(14) 对此末带的几个特定和给出点态对数级节省，它们没有覆盖完整低分子斜楔的所有分子、除数或管间交叉，也没有得到 $Y^{2+\varepsilon}$ 的完整 signed covariance 上界。
