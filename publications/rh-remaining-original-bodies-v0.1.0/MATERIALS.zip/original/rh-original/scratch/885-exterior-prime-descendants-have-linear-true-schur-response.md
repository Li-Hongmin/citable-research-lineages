# 槽外素数缩放后代产生线性真 Schur 扣款（候选）

日期：2026-10-01。依赖 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽闭形式与相离核、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇算子平移约定，以及 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的全实尺度槽外矩形。这里判定其主压缩与正交补之间最小的一代真实接口。结论未经异源复核，留在 scratch；它不决定完整 Schur 补或 RH。

## 定理

令实数 \(X\to\infty\)，\(H=\log X\)、\(k=X^2\)、\(\ell=\log(1+X^{-2})\)，并取 scratch/884 的严格矩形 \(\mathcal G_X^\circ\)。对 \(z>1\)，设 \(I_z^+\) 以 \(\log(Xz)\) 为中心、长 \(\ell\)，\(I_z^-=2H-I_z^+\)，并置
\[
v_z=\frac{\mathbf1_{I_z^+}-\mathbf1_{I_z^-}}{\sqrt{2\ell}}.
\tag{1}
\]
固定 \(0<\alpha\le1/2\)。对任意 \(x\in\mathcal G_X^\circ\)，令
\[
\mathcal P_\alpha(X)=\{q\text{ 为素数}:5\le q\le X^\alpha\},
\quad W_{X,x,\alpha}=\operatorname{span}\{v_{x/q}:q\in\mathcal P_\alpha(X)\}.
\]
记 \(B=(A_{k,-}[v_{x/q},v_{x/r}])_{q,r}\)、
\(g=(A_{k,-}[v_{x/q},v_x])_q\)。则这些后代为正交单位向量，且 \(W_{X,x,\alpha}\) 与 scratch/884 的**整个**槽外空间正交。下列估计对所有 \(x\in\mathcal G_X^\circ\) 一致：
\[
\boxed{\quad B=2H I+O_{\rm op}(1),\qquad
\left\|g+\left(\frac{\log q}{\sqrt q}\right)_q\right\|_{\ell^2}=o(1).\quad}
\tag{2}
\]
故充分大 \(X\) 时 \(B>0\)，并且其**真实旧形式的有限 Schur 扣款**满足
\[
\boxed{\quad g^*B^{-1}g
=\left(\frac{\alpha^2}{4}+o(1)\right)H.\quad}
\tag{3}
\]
根的自能量为 \(A_{k,-}[v_x]=2H+O(1)\)，故 \(\mathbb Cv_x\oplus W_{X,x,\alpha}\) 仍严格正，但把这一代正交补消去已花费线性数量级。若整个槽外正交补的闭形式严格正，则其对根 \(v_x\) 的逆度量 Schur 扣款至少为 (3)；不得把 scratch/884 的主压缩谱隙直接当作完整旧空间谱隙。

## 槽位置与单槽能量

矩形给 \(X/8<x<X/2\)。当 \(q\ge5\) 时 \(x/q<X/10<X/8\)，而 \(x/q>X^{1-\alpha}/8>1\) 对充分大 \(X\) 成立。因此后代的上下槽在旧区间内、相互反射，且与矩形中全部槽相距至少一个固定对数常数（端点的 \(O(\ell)\) 不影响）。不同素数 \(q\ne r\) 满足
\[
|\log(q/r)|\ge \log(1+X^{-\alpha})\gg\ell,
\]
所以后代两两正交，且都与整个槽外空间正交。

note 790 的常值单槽恒等式和远离镜像臂的 \(-K\) 核给每个根或后代
\[
G_k[v_z]=\log(1/\ell)+1-\log(2\pi)-\gamma_E+o(1)
=2H+C_0+o(1),
\tag{4}
\]
其中 \(C_0=1-\log(2\pi)-\gamma_E\)，且误差对 \(z=x\) 与 \(z=x/q\) 一致。后代任意两条不同同臂槽的中心距至少 \(cX^{-\alpha}\)，故其 Archimedean 块范数至多 \(C\ell X^\alpha=O(X^{\alpha-2})\)。每行至多 \(X^\alpha\) 项，行和为 \(O(X^{2\alpha-2})=o(1)\)。异臂中心距至少 \(2(1-\alpha)H-O(1)\)，对应行和也为 \(o(1)\)。根到后代的同臂块至多 \(C\ell/\sqrt q\)，异臂块更小；这些块组成的根列有 \(\ell^2\) 范数 \(o(1)\)。

每个后代的 polar 投影平方至多 \(C\ell(x/q)\le C/(Xq)\)，故整个后代空间的 polar 压缩范数为 \(O(X^{-1}\sum_{q\le X^\alpha}q^{-1})=o(1)\)；根到后代的 polar 列亦为 \(o(1)\)。

## 算术边与反射误差

旧算术项是 \(\mathcal R_k=-\sum_{m\text{ 素数幂}}c_m(T_m+T_m^*)\)、\(c_m=\Lambda(m)/\sqrt m\)。根 \(x\) 到后代 \(x/q\) 有一条完整同臂 \(m=q\) 边；两个物理臂各贡献半权，故矩阵元恰为 \(-c_q\)。若另一整数 \(m\) 的同臂平移也相交，则 \(|\log(m/q)|<\ell\) 蕴含 \(|m-q|<q(e^\ell-1)=qX^{-2}<1\)，故仍只能是 \(m=q\)。对两个不同后代，同臂相交则类似地迫使 \(mq=r\) 或 \(mr=q\)，与 \(q,r\) 为不同素数矛盾；自槽也无 \(m\ge2\) 同臂边。

异臂槽对 \(z,w\) 只可能由 \(|\log(m/(zw))|<\ell\) 相交。对两个后代，\(zw=x^2/(qr)\le X^2/(4qr)\)，允许整数窗的长度小于 \(1/(2qr)+o(1)<1\)，所以每对至多有一个素数幂；若存在，其权满足
\[
c_m\le(16+o(1))\frac{H\sqrt{qr}}X
\le(16+o(1))H X^{\alpha-1}.
\tag{5}
\]
Chebyshev 素数计数界给后代数 \(\#\mathcal P_\alpha(X)\ll_\alpha X^\alpha/H\)，故异臂算术矩阵的绝对行和为 \(O_\alpha(X^{2\alpha-1})=O(1)\)；当 \(\alpha<1/2\) 时它趋零，在端点 \(\alpha=1/2\) 时仍为一致有界。根到后代的异臂整数窗同样长度小于一，其可能权至多 \(C H\sqrt q/X\)；整列的 \(\ell^2\) 范数至多 \(CHX^{\alpha-1}=o(1)\)。根或后代的异臂自环也已被这些界包含。与 (4) 的 Archimedean 及 polar 估计合并，即得 (2)，并有 \(A_{k,-}[v_x]=2H+O(1)\)。

## Schur 常数

素数定理与分部求和给
\[
\sum_{q\in\mathcal P_\alpha(X)}c_q^2
=\sum_{5\le q\le X^\alpha\atop q\text{ prime}}
\frac{(\log q)^2}{q}
=\left(\frac{\alpha^2}{2}+o(1)\right)H^2.
\tag{6}
\]
由 (2)，\(B^{-1}=(2H)^{-1}I+O_{\rm op}(H^{-2})\)，而 \(\|g\|^2\) 等于 (6) 加 \(o(H^2)\)。代入即得 (3)。根 Schur 枢轴为
\[
A_{k,-}[v_x]-g^*B^{-1}g
=\left(2-\frac{\alpha^2}{4}+o(1)\right)H>0.
\]
这是有限维正块上的真实 Schur 恒等式。若完整正交补也严格正，逆度量变分式在更大空间取上确界，故扣款只能增大。\(\square\)

## 几乎所有槽的规避定理：第一代可延伸到任意固定幂 \(X^\alpha\)

上面的 \(\alpha\le1/2\) 限制只用于把所有可能的异臂素数幂块逐行取绝对值。对**多数**原槽，可在槽内移动半个槽宽的中心，避开全部这类共振。

**命题。** 固定 \(0<\alpha<1\)。除 \(o_\alpha(X^2)\) 个 \(y\in\mathcal G_X^\circ\) 外，每个原槽 \(I_y^+\) 内可选实数中心 \(x_y\) 与宽度 \(w=\ell/2\)。若 \(I_z^{+,w}\) 是以 \(\log(Xz)\) 为中心、长 \(w\) 的区间，\(I_z^{-,w}=2H-I_z^{+,w}\)，定义
\[
e_y=\frac{\mathbf1_{I_{x_y}^{+,w}}-\mathbf1_{I_{x_y}^{-,w}}}{\sqrt{2w}},
\qquad
e_{y,q}=\frac{\mathbf1_{I_{x_y/q}^{+,w}}-\mathbf1_{I_{x_y/q}^{-,w}}}{\sqrt{2w}}
\quad(q\in\mathcal P_\alpha(X)).
\]
则 \(e_y\in V_{\{y\}}\)，所有 \(e_{y,q}\) 两两正交，并与**整个**槽外空间正交；在
\(W_y^\alpha=\operatorname{span}\{e_{y,q}\}\) 上有
\[
\boxed{\quad
(A_{k,-}[e_{y,q},e_{y,r}])_{q,r}
=2H I+O_{\rm op}(1),
\qquad
\left\|(A_{k,-}[e_{y,q},e_y])_q+(c_q)_q\right\|_{\ell^2}=o(1).
\quad}
\tag{7}
\]
因此这一代有限正块对原槽内某个真实轮廓的 Schur 扣款为
\[
\boxed{\qquad R_y^\alpha
=\left(\frac{\alpha^2}{4}+o(1)\right)H.\qquad}
\tag{8}
\]
同一根列还给不要求任何补块正性的交叉形式范数
\[
\sup_{\substack{w\in W_y^\alpha\\\|w\|_2=1}}
|A_{k,-}[e_y,w]|
=\left(\frac\alpha{\sqrt2}+o(1)\right)H.
\tag{8a}
\]
所有误差对这些槽一致。特别地，对任意固定 \(\varepsilon>0\)，几乎所有原槽都存在一个轮廓，其第一代正交补扣款至少为 \((1/4-\varepsilon)H\)。这仍小于根的 \(2H+O(1)\) 自能量，不提供完整算子的负方向。

**证明：可用中心的测度。** 令 \(\mathcal Q=\{1\}\cup\mathcal P_\alpha(X)\)。把候选实中心 \(x\) 限于 \([X/9,X]\)，并将下列共振中心排除：存在 \(q,r\in\mathcal Q\) 和素数幂 \(m\)，使
\[
\left|\log\frac{mqr}{x^2}\right|<\ell.
\tag{9}
\]
记其并集为 \(\mathcal B_X\)。对固定 \(q,r\)，相关 \(m\) 位于
\(m\asymp X^2/(qr)\)，特别地 \(m\gg X^{2(1-\alpha)}\)。Chebyshev 上界连同高次素数幂的初等计数给
\[
\#\{m\text{ 相关素数幂}\}
\ll_\alpha\frac{X^2}{qrH}.
\]
每个 \(m\) 在 (9) 中排除以 \(\sqrt{mqr}\) 为中心、长度 \(O(X\ell)=O(X^{-1})\) 的实区间。因此
\[
|\mathcal B_X|
\ll_\alpha\frac XH
\left(1+\sum_{q\le X^\alpha\atop q\text{ prime}}\frac1q\right)^2
\ll_\alpha\frac{X(\log\log X)^2}{H}=o(X).
\tag{10}
\]

矩形的既约分数数目满足
\[
|\mathcal G_X^\circ|
=\frac{X^2}{16\zeta(2)}+o(X^2).
\tag{11}
\]
这由对每个 \(b\in(\sqrt X/2,\sqrt X)\) 使用
\(\#\{n\in(X^{3/2}/8,X^{3/2}/4):(n,b)=1\}
=(X^{3/2}/8)\varphi(b)/b+O(\tau(b))\)，再求和得到。
对每个 \(y\in\mathcal G_X^\circ\)，取中心候选区间
\[
J_y=(y e^{-\ell/4},y e^{\ell/4}).
\]
Farey 整数交叉积使这些 \(J_y\) 两两相离。每条 \(J_y\) 的长度介于 \(c/X\) 和 \(C/X\)，故由 (11) 可知 \(\sum_y|J_y|\asymp X\)。由 (10)，满足 \(|J_y\cap\mathcal B_X|\ge|J_y|/2\) 的槽至多 \(2|\mathcal B_X|/(c/X)=o(X^2)\)。在其余每个 \(J_y\) 内选 \(x_y\notin\mathcal B_X\)；由于 \(|\log(x_y/y)|<\ell/4\)，以 \(\log(Xx_y)\) 为中心、长度 \(w=\ell/2\) 的子槽完全位于 \(I_y^+\)。这里 \(x_y\) 无需有理：它只指定原有物理槽内的测试轮廓。

**证明：精确星图和能量。** 置 \(z_1=x_y\)、\(z_q=x_y/q\)。因 \(q\ge5\)、\(x_y<X/2+o(X)\)，所有 \(z_q<X/8\)；它们的上下子槽因此与整个槽外空间相离。不同叶的同臂中心距至少 \(cX^{-\alpha}\gg w\)，故叶正交。式 (9) 不成立保证 \(\{e_y,e_{y,q}\}\) 中**所有**异臂素数幂平移块为零，因为任一此类块必须满足 \(|\log(m/(z_qz_r))|<w<\ell\)。同臂平移相交则清除 \(q,r\) 后迫使整数等式 \(mq=r\) 或 \(mr=q\)：非零整数差至少一，而误差小于 \(X^\alpha(e^w-1)=o(1)\)。故唯一算术边是根到叶 \(q\) 的整槽同臂边，权为 \(-c_q\)。

note 790 的单槽等式给每个单位子槽自能量 \(\log(1/w)+O(1)=2H+O(1)\)。叶间同臂 Archimedean 块的绝对行和为 \(O(wX^{2\alpha})=o(1)\)；异臂中心距至少 \(2(1-\alpha)H-O(1)\)，行和也是 \(o(1)\)。polar 压缩范数为 \(O(X^{-1}\sum_{q\le X^\alpha}q^{-1})=o(1)\)，根到叶的 Archimedean 与 polar 列为 \(o_{\ell^2}(1)\)。这证明 (7)。最后素数定理给 \(\sum_{q\in\mathcal P_\alpha(X)}c_q^2=(\alpha^2/2+o(1))H^2\)；与前述逆矩阵展开同样证明 (8)。\(\square\)

## 固定代数的精确平方自由乘法图

前述规避可同时施于所有固定因子层。固定整数 \(d\ge1\) 和 \(0<\alpha<1\)，定义
\[
\mathcal D_{d,\alpha}(X)=\{1\}\cup
\left\{n\le X^\alpha:
 n\text{ 平方自由，所有素因子 }\ge5,\ \Omega(n)\le d\right\}.
\tag{12}
\]
除 \(o_{d,\alpha}(X^2)\) 个 \(y\in\mathcal G_X^\circ\) 外，可在 \(I_y^+\) 内选同样的半宽中心 \(x_y\)，并对每个 \(n\in\mathcal D_{d,\alpha}(X)\) 定义单位奇子槽 \(e_{y,n}\)，其上臂中心为 \(\log(Xx_y/n)\)、宽度 \(w=\ell/2\)。其中 \(e_{y,1}\in V_{\{y\}}\)，而全部 \(n>1\) 的 \(e_{y,n}\) 位于整个槽外空间的正交补。这些向量两两正交，且真实旧奇形式的矩阵满足一致的算子范数渐近
\[
\boxed{\quad
\bigl(A_{k,-}[e_{y,n},e_{y,m}]\bigr)_{n,m\in\mathcal D_{d,\alpha}(X)}
=D_X I-C_{d,\alpha}(X)+o_{\rm op}(1),
\qquad D_X=2H+1-\gamma_E-\log\pi,
\quad}
\tag{13}
\]
其中 \(C_{d,\alpha}(X)\) 是**精确**的平方自由乘法邻接矩阵：当 \(m=nq\) 或 \(n=mq\)，且 \(q\ge5\) 为素数时，相应条目为 \(c_q=(\log q)/\sqrt q\)；其余条目（包括对角）为零。式 (13) 是真实物理 Weil 形式的有限维压缩，不是把 RH 写成一个抽象图的等价判据。

证明中只需把 (9) 的 \(\mathcal Q\) 换成 \(\mathcal D_{d,\alpha}(X)\)。固定 \(d\) 时
\[
\sum_{n\in\mathcal D_{d,\alpha}(X)}\frac1n
\le\sum_{j=0}^d\frac1{j!}
\left(\sum_{5\le q\le X^\alpha\atop q\text{ prime}}\frac1q\right)^j
\ll_{d,\alpha}(\log\log X)^d.
\]
由 (10) 的同一素数幂计数与区间长度估计，坏中心总测度至多
\(O_{d,\alpha}(X(\log\log X)^{2d}/H)=o(X)\)。式 (11) 的两两相离中心区间遂保证除 \(o(X^2)\) 个原槽外均可取好中心。

对好中心，任何两个指标 \(n,m\in\mathcal D_{d,\alpha}(X)\) 的异臂素数幂边都已规避。同臂相交要求 \(|\log(sn/m)|<w\)，\(s\ge2\) 是素数幂；因 \(m\le X^\alpha\)，有 \(|sn-m|<m(e^w-1)<1\)，故 \(sn=m\)。平方自由性迫使 \(s\) 是一个不整除 \(n\) 的素数，于是得到 (13) 的且仅有的算术边。不同指标的对数中心距至少 \(cX^{-\alpha}\)，而节点数至多 \(X^\alpha\)，故同臂 Archimedean 交叉的绝对行和为 \(O(X^{2\alpha-2})=o(1)\)；异臂交叉更小。polar 投影范数为
\(O(X^{-1}\sum_{n\in\mathcal D}n^{-1})=o(1)\)。每个长度 \(w\) 的槽由 note 790 给相同的对角
\(\log(1/w)+1-\log(2\pi)-\gamma_E+o(1)=D_X+o(1)\)，故全部误差在算子范数中趋零，证明 (13)。\(\square\)

这个精确图还给出整个固定层压缩的统一正隙。令 \(v_n=n^{-1/2}>0\)。对任一 \(n\in\mathcal D_{d,\alpha}(X)\)，向下删去素因子的加权行贡献恰为 \(\sum_{q\mid n}\log q=\log n\)；向上增添素因子的贡献至多
\(\sum_{q\le X^\alpha/n,\ q\text{ prime}}(\log q)/q\le\log(X^\alpha/n)+O(1)\)。若 \(\Omega(n)=d\)，向上边只会减少。因此正权 Schur 检验与经典 Mertens 上界给
\[
\boxed{\qquad
\|C_{d,\alpha}(X)\|\le\alpha H+O(1),
\qquad
P_{\mathcal D}A_{k,-}P_{\mathcal D}
\succeq\bigl((2-\alpha)H-O(1)\bigr)I.
\qquad}
\tag{13a}
\]
第二式在上述几乎所有原槽各自选出的有限子空间上成立，常数对槽一致。它说明固定因子代数的无共振同臂图自身有正隙；尚未估计其与其余旧空间的 Schur 反馈。

**二代 Schur 常数。** 固定 \(0<\beta<1/2\)，只取素数 \(5\le q\le X^\beta\) 及其互异双素数乘积 \(qr\)。这是 (12) 的 \(d=2,\alpha=2\beta<1\) 的子图，故对除 \(o_\beta(X^2)\) 个原槽外的某个槽内根轮廓，全部以下计算使用真实旧 Weil 形式。令
\(u=(c_q)_q\)、\(S=\|u\|^2=(\beta^2/2+o(1))H^2\)，并按第一、第二代排列补块。忽略 (13) 的 \(o_{\rm op}(1)\) 后，补块为
\[
B_2=\begin{pmatrix}D_XI&-T\\-T^*&D_XI\end{pmatrix},
\qquad T_{q,\{q,r\}}=c_r,
\quad T_{r,\{q,r\}}=c_q.
\]
直接逐项相乘给
\[
TT^*=S I+uu^*-2\operatorname{diag}(c_q^2),
\qquad \|\operatorname{diag}(c_q^2)\|=O(1).
\tag{14}
\]
因为 \(\|T\|^2=2S+O(1)=(\beta^2+o(1))H^2<D_X^2\)，\(B_2\) 严格正。根仅连第一代，故其两代真 Schur 扣款由 (14) 与一次 Schur 消元得到
\[
\begin{aligned}
R_y^{(2)}
&=u^*\left(D_XI-D_X^{-1}TT^*\right)^{-1}u+o(H)\\
&=\frac{S D_X}{D_X^2-2S}+o(H)
=\boxed{\left(\frac{\beta^2}{4-\beta^2}+o(1)\right)H}.
\end{aligned}
\tag{15}
\]
其中 \(2\operatorname{diag}(c_q^2)/D_X\) 的算子范数为 \(O(H^{-1})\)，不会改变 \(H\) 级主项；(13) 的 \(o_{\rm op}(1)\) 对逆度量的影响更小。只消去同一批第一代时的扣款为 \((\beta^2/4+o(1))H\)，所以第二代的新增主项是
\[
\left(\frac{\beta^4}{4(4-\beta^2)}+o(1)\right)H>0.
\tag{16}
\]
当固定 \(\beta\uparrow1/2\) 时，两代系数趋于 \(1/15\)，第一代系数趋于 \(1/16\)；这个比较不把 \(\beta=1/2\) 纳入 (12) 的量词。

## 边界

本结果证明槽外稀疏主压缩与其正交补的线性级耦合：不移动槽中心时，每个根有 \(H/16\) 的第一代扣款；允许在原槽内选半宽轮廓时，几乎所有槽的扣款可达任意接近 \(H/4\)。固定因子代数的真实压缩具有 (13) 的精确乘法图，二代在一个完整素数带上额外增加 (16) 的线性扣款。它没有给完整补空间的上界、全部因子层的极限，或任意槽内轮廓的反馈。完整全尺度局部 Weil 正性与 moving-\(N\) Möbius signed covariance 仍未判定。
