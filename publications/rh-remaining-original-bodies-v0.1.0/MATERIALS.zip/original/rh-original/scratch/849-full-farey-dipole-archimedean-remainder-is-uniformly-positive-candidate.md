# 全 Farey 阶跃偶极的 Archimedean 余项有一致正下界（候选）

本稿已晋级为 [note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md)，以后者为准。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的全部 Farey 偶极、物理槽间距、相离核及 polar 界。该 note 只给出 Archimedean 压缩相对于 \(D_kI\) 的一致 \(O(1)\) 范数界；这里给出一个显式正的下界。异源复核前留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 \(k=p^2\)、\(\Delta=\frac12\log(1+p^{-2})\)、\(D_k=\log k+1-\gamma_E-\log\pi\)，并沿用 note 791 的 Farey 偶极空间 \(W_p\) 及
\[
P_{W_p}A_{k,-}P_{W_p}=D_kI-C_p+E_p.
\]
令
\[
\boxed{\quad
\delta_0=\log\frac{729}{512}-\frac{\zeta(3)}8>0.
\quad}\tag{1}
\]
则
\[
\boxed{\quad E_p\succeq(\delta_0-o(1))I_{W_p}.\quad}\tag{2}
\]
特别地，全 Farey 阶跃偶极的 Archimedean 余项不会把任何向量的 Rayleigh 商降低到 \(D_k\) 以下。式 (2) 不决定 \(D_kI-C_p+E_p\) 的最低谱值，因为 \(\lambda_{\max}(C_p)=\log k+O(1)\) 的常数项仍未知。

## 两个相离物理偶极的正交叉

在对数坐标，把中心 \(0\) 的物理偶极写成
\[
\varphi_0(s)=(2\Delta)^{-1/2}h_\Delta(s),
\quad
h_\Delta=1_{(-\Delta,0)}-1_{(0,\Delta)},
\quad
H_\Delta(s)=\int_{-\Delta}^s h_\Delta(t)\,dt.
\]
\(H_\Delta\) 是支撑于 \([-\Delta,\Delta]\) 的非负三角形，且 \(\int H_\Delta=\Delta^2\)。若两个物理中心的距离为 \(d\ge2\Delta\)，note 791 式 (11) 给其非局部核 \(-K(|s-t|)\)，其中
\[
K(d)=\frac{e^{-d/2}}{1-e^{-2d}}
=\sum_{j\ge0}e^{-(2j+1/2)d},
\quad K''(d)>0,\quad K'''(d)<0.
\]
记交叉矩阵元为 \(g_\Delta(d)\)。在 \(d>2\Delta\) 先于两变量分部积分，再令 \(d\downarrow2\Delta\)，得到
\[
g_\Delta(d)
=-\frac1{2\Delta}\int h_\Delta(s)h_\Delta(t)K(d+t-s)\,ds\,dt
=\frac1{2\Delta}\int H_\Delta(s)H_\Delta(t)K''(d+t-s)\,ds\,dt
\ge0.
\tag{3}
\]
由 \(K'''<0\)，\(g_\Delta(d)\) 对 \(d\) 递减。接触端点的积分有限，因为原核 \(K(u)\sim1/(2u)\) 的矩形积分有限。

## 相邻常数与行和

在 \(d=2\Delta\) 时，\(K(u)=1/(2u)+O(1)\) 一致适用于 \(0<u\le4\Delta\)。因此 \(O(1)\) 部分归一化后为 \(O(\Delta)\)，而奇异部分可缩放到相邻的单位区间。令
\[
J(a)=\int_0^1\!\int_a^{a+1}\frac{dv\,du}{v-u}
=(a+1)\log(a+1)+(a-1)\log(a-1)-2a\log a
\quad(a\ge1),
\]
其中 \(0\log0=0\)。四个半槽的符号给
\[
g_\Delta(2\Delta)
=-\frac14\bigl(2J(2)-J(1)-J(3)\bigr)+O(\Delta)
=\log\frac{32}{27}+O(\Delta).
\tag{4}
\]
对每个固定整数 \(j\ge2\)，note 791 式 (12) 的双零矩界和 \(K''(u)\sim u^{-3}\) 给
\[
\limsup_{\Delta\downarrow0}g_\Delta(2j\Delta)
\le\frac1{16(j-1)^3}.
\tag{5}
\]
同时 note 791 式 (11) 的全局 \(K''(u)\le C u^{-3}\) 使左侧有可求和的统一上界 \(C/[16(j-1)^3]\)，故支配收敛给
\[
\limsup_{\Delta\downarrow0}
\sum_{j\ge1}g_\Delta(2j\Delta)
\le\log\frac{32}{27}+\frac{\zeta(3)}{16}.
\tag{6}
\]

note 791 式 (9) 证明全部 Farey 物理中心两两相距大于 \(2\Delta\)。将它们按位置排序，任意中心的第 \(j\) 个左邻或右邻至少相距 \(2j\Delta\)；由 (3) 的单调性，其非对角绝对行和至多 \(2\sum_{j\ge1}g_\Delta(2j\Delta)\)。每个物理偶极的对角由 note 791 式 (13) 的单半槽对角及相邻反号半槽接触积分给出
\[
\langle\varphi_z,G_k\varphi_z\rangle
=D_k+\log2+O(\Delta),
\qquad
\langle e_-,G_ke_+\rangle
=-\Delta^{-1}\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=-\log2+O(\Delta).
\tag{7}
\]
Gershgorin 二次型界、(6)--(7) 因而在整个物理中心张成空间给
\[
G_k-D_kI
\succeq
\left(\log2-2\log\frac{32}{27}-\frac{\zeta(3)}8-o(1)\right)I
=(\delta_0-o(1))I.
\tag{8}
\]
note 791 的 \(w_x=(\varphi_{px}+\varphi_{p/x})/\sqrt2\) 是从物理中心空间到 \(W_p\) 的等距压缩，故 (8) 传到 \(W_p\)。此外其 \(\|P_{W_p}s_k\|=O(p^{-3/2})\) 使负 polar 压缩的范数为 \(O(p^{-3})=o(1)\)。这证明 (2)。

最后，\(\log(729/512)=\log(1+217/512)>217/729\)，而 \(\zeta(3)<1+\int_1^\infty t^{-3}dt=3/2\)。所以 \(\delta_0>217/729-3/16>0\)。\(\square\)

## 边界

式 (2) 加强了 full Farey **阶跃偶极主压缩**的 Archimedean 部分，不适用于每槽任意轮廓，也不控制完整旧奇算子在 \(W_p^\perp\) 中的 Schur 反馈。算术谱半径的常数项仍可决定主压缩符号；本结果不证明全尺度 Weil 正性或 RH。
