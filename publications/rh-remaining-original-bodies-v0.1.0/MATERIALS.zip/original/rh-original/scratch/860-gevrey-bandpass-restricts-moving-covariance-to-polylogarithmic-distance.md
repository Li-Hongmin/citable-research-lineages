# Gevrey 带通将真实 moving covariance 的远差截止压到近对数尺度

日期：2026-10-01。接 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (1)--(12)。本稿只改进其中远差支付 (11)，不估计留下的 Möbius signed covariance，也不证明 RH。

## 定理

固定任意 $s>1$。可在 [scratch/858](858-exact-bandpass-observation-removes-lower-frequency-leakage.md) 中选取实偶权 $0\le\chi_s\le1$，使其支撑在 $1/2\le|t|\le4$、在 $1\le|t|\le2$ 上等于 $1$，并满足
\[
 \| (\chi_s^2)^{(n)}\|_\infty\le C_s^{n+1}(n!)^s\qquad(n\ge0).
 \tag{1}
\]
令 $w_H(h)=\chi_s(h/H)^2$，$W=M/H$，$J_H(r)=\sum_hw_H(h)e(-hr/M)$。对任意固定 $B>0$，存在 $C_{s,B}>0$，使 scratch/859 的远差截止可取
\[
 K_{s,B}=C_{s,B}\frac MH(\log M)^s
 \tag{2}
\]
而仍有
\[
 \sum_{\substack{m,n\\|m-n|>K_{s,B}}}B(m)B(n)|J_H(m-n)|
 =O_{s,B,\psi}(M^{-B}).
 \tag{3}
\]
这里 $B(m)=\sum_{d>D}|b_d(m)|$ 沿用 scratch/859。结论在 $Y^{1/5}\le H\le Y^{1/4}$ 一致成立。特别地，任意固定 $\delta>0$，取 $s=1+\delta$ 且在 (2)--(3) 中取 $B=2$ 后，式 (12) 中 $|m-n|\le(M/H)M^\sigma$ 可收紧成
\[
 |m-n|\le C_{\delta,2}(M/H)(\log M)^{1+\delta},
 \tag{4}
\]
且目标量级的等价性保持；近差截止、除数条件和剩余 Möbius 符号和均不变。

## 证明

写 $a=1/(s-1)$，令 $\rho_a(t)=e^{-t^{-a}}$ 当 $t>0$，其余为零。对 $t>0$，在复圆 $|z-t|=\eta_a t$ 上可取足够小的固定 $\eta_a>0$，使 $\Re z^{-a}\ge c_a t^{-a}$。Cauchy 估计给
\[
 |\rho_a^{(n)}(t)|\le n!(\eta_at)^{-n}e^{-c_at^{-a}}.
\]
对 $t>0$ 优化 $t^{-n}e^{-c_at^{-a}}$，并使用 Stirling 的初等双边界，得到
\[
 \|\rho_a^{(n)}\|_\infty\le C_a^{n+1}(n!)^{1+1/a}.
 \tag{5}
\]
延拓在 $t=0$ 光滑，因为任意固定阶导数都趋于零。取 $\theta(t)=\rho_a(t)\rho_a(1-t)$，$Z=\int_0^1\theta(t)dt>0$，再置 $S(t)=Z^{-1}\int_{-\infty}^t\theta(u)du$。乘法的 Leibniz 公式与 $n!\ge k!(n-k)!$ 说明 $\theta$、$S$ 均有阶数 $s$ 的导数界。$S=0$ 于 $t\le0$，$S=1$ 于 $t\ge1$，且 $0\le S\le1$。令
\[
 \chi_s(t)=S(2|t|-1)S((4-|t|)/2).
 \tag{6}
\]
它在零的邻域恒为零，故 $|t|$ 不造成光滑性问题；支撑、平台与取值范围均如定理所述。再用一次 Leibniz 公式便得 (1)。

设 $v=\chi_s^2$。反复分部积分和 (1) 给
\[
 |\widehat v(\xi)|
 \le C_s^{n+1}(n!)^s(2\pi|\xi|)^{-n}
 \le C'_s e^{-c_s|\xi|^{1/s}}.
 \tag{7}
\]
最后一步在 $|\xi|$ 大时取 $n=\lfloor c|\xi|^{1/s}\rfloor$，并用 $n!\le n^n$；有界 $\xi$ 调整常数即可。Poisson 求和于是给
\[
 J_H(r)=H\sum_{j\in\mathbb Z}\widehat v\!\left(H\left(\frac rM+j\right)\right).
 \tag{8}
\]
由于 $\phi=\psi/u$ 紧支撑于 $(1,2)$，存在只依赖 $\psi$ 的 $\kappa>0$，使非零 $B(m)B(n)$ 满足 $|r|=|m-n|\le(1-\kappa)M$。式 (7)--(8) 对 $j=0$ 和 $j\ne0$ 分别给
\[
 |J_H(r)|\le C_{s,\psi}H
 \left[e^{-c_s(|r|/W)^{1/s}}+e^{-c_{s,\psi}H^{1/s}}\right].
 \tag{9}
\]
其中 $j\ne0$ 项的和由 $|r/M+j|\ge\kappa$（$|j|=1$）以及 $|r/M+j|\ge|j|-1$（$|j|\ge2$）控制。取 (2) 中 $C_{s,B}$ 足够大，第一项在 $|r|>K_{s,B}$ 时为 $O(M^{-B-4})$；第二项因 $H\gg M^{1/5}$ 也为 $O_B(M^{-B-4})$。scratch/859 式 (9) 给 $\sum_mB(m)\ll_\psi\log^2M$，所以
\[
 \sum_{|m-n|>K_{s,B}}B(m)B(n)|J_H(m-n)|
 \ll H\log^4M\,M^{-B-4}=O(M^{-B}),
\]
即 (3)。另外 $K_{s,B}/M=C_{s,B}(\log M)^s/H=o(1)$，因此远差截止仍处在同一个支持区间内。scratch/859 对角、小有理比例和近差的支付只使用 $\chi_s$ 的支撑及有界性，故原样适用；由此得到 (4) 与等价性。$\square$

## 边界

这是同一真实算术门的局部化改进。任意固定 $s>1$ 可逼近对数宽度，但 (3) 没有控制 (4) 内的 signed 和；无法由此宣称完整 $k=2$ residual、全尺度局部 Weil 正性或 RH。

## 已支付的对数端点带

另有一段可直接得到**真实 signed 和**的上界。令
\[
 Y^{1/4}/\sqrt{\log(2Y)}\le H\le Y^{1/4},\qquad M=2Y.
\]
[scratch/857](857-log-half-collar-payment-for-the-moving-k2-observation-tail.md) 式 (5) 对当前 $\eta=\chi_s^2$ 给
$\sum_hw_H(h)|\mathcal A_h|^2\ll_{s,\psi}(\log Y)^{-2}$；而此处 $H^4/M\ge c(\log Y)^{-2}$。scratch/859 式 (7)--(10) 支付被剔除项，本文式 (3) 支付远差，所以 (4) 中留下的**实际** $\mu(d)\mu(e)$ signed covariance 满足
\[
 \sum_{\substack{D<d,e\le2M,\ d\nmid e,\ e\nmid d\\
 \max(d/(d,e),e/(d,e))>R}}\mu(d)\mu(e)
 \sum_{\substack{M<m,n<2M\\K_0<|m-n|\le K_{s,2}}}
 b_d(m)\overline{b_e(n)}J_H(m-n)
 \ll_{s,\psi}\frac{H^4}{M}.
 \tag{10}
\]
式 (10) 只是已知对数端点带算术估计在更窄物理距离内的定位；固定幂低频带 $H\le Y^{1/4-\epsilon}$ 仍未支付。
