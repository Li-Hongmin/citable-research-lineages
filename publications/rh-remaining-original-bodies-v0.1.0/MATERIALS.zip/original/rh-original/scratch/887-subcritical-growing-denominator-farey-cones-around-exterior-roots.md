# 外侧根的近对数分母有理锥仍有线性真 Weil 正隙（候选）

后续 [scratch/888](888-all-exterior-rational-cones-below-log-squared-denominators.md) 用逐中心有理入射界取代本稿平均论证，并将范围扩大到每个原槽的 \(B=o((\log X)^2)\)。以下保留推导过程，不作为当前最强陈述。

日期：2026-10-01。依赖 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的实尺度槽族、[scratch/886](886-almost-all-exterior-slots-have-positive-full-integer-descendant-compressions.md) 的连续中心反射块均方法、[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽闭形式，以及 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇算术平移约定。这里直接加入分母为 \(o(\log X/\sqrt{\log\log X})\) 的有理后代及全部槽内轮廓。它扩展的是**同一局部根的有限物理锥**，不是全 Farey 压缩或完整旧空间。证明尚未异源复核，保留在 scratch。

## 陈述

令 \(X\to\infty\) 为实尺度、\(H=\log X\)、\(L_H=\log(H+2)\)、\(k=X^2\)、\(\ell=\log(1+X^{-2})\)、\(w=\ell/2\)。取整数 \(B=B(X)\ge1\)，满足
\[
\delta_{B,H}:=\frac{B\sqrt{L_H}}H\longrightarrow0,
\qquad \Omega_{B,H}:=\sqrt{BH\sqrt{L_H}}=H\sqrt{\delta_{B,H}}=o(H).
\tag{1}
\]
对 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的原槽 \(y\in\mathcal G_X^\circ\)，置 \(N_y=\lfloor y/2\rfloor\)，并定义既约有理指标集
\[
\mathcal R_{y,B}=\{1\}\cup
\left\{r=\frac ab:5\le r\le N_y,\quad
1\le b\le B,\quad (a,b)=1\right\}.
\tag{2}
\]
令 \(J_y=(ye^{-\ell/4},ye^{\ell/4})\)。除至多
\(O(X^2\delta_{B,H}^2)=o(X^2)\) 个 \(y\) 外，可选 \(x_y\in J_y\)，使以 \(\log(Xx_y/r)\) 为上臂中心、宽度 \(w\) 的全部奇反射槽 \(r\in\mathcal R_{y,B}\) 两两正交；\(r=1\) 的槽位于 \(V_{\{y\}}\)，全部 \(r>1\) 的槽与整个 \(V_{\mathcal G_X^\circ}\) 正交。记 \(\mathscr V_{y,B}\) 为这些槽上的**全部有限能量奇轮廓**，则真实旧奇 Weil 闭形式满足
\[
\boxed{\quad
A_{k,-}|_{\mathscr V_{y,B}}
\succeq \bigl(H-O(\Omega_{B,H})\bigr)I
=(1-o(1))H I.
\quad}
\tag{3}
\]
取根的单位常值半宽槽 \(e_{y,1}\)，并令 \(R_{y,B}\) 是将 \(\mathscr V_{y,B}\) 中 \(r>1\) 的**完整轮廓子空间**消去所得真闭形式 Schur 扣款，则对这些槽一致有
\[
\boxed{\quad
\left(\frac14+o(1)\right)H
\le R_{y,B}
\le\left(1-\log2+o(1)\right)H,
\qquad
A_{k,-}[e_{y,1}]-R_{y,B}
\ge(1+\log2-o(1))H.
\quad}
\tag{4}
\]
所以任意满足 (1) 的这类有理后代锥都不能单独消掉根的线性正隙。这个结论不约束更大的分母或其余正交补。

## 平移精确图与轮廓几何

先在每个原槽的候选中心区间使用全域指标集合
\[
\mathcal R_B^*=\{1\}\cup
\left\{a/b:5\le a/b\le X/4, 1\le b\le B, (a,b)=1\right\}.
\]
其节点数 \(M_B\ll B^2X\)。两个不同既约指标 \(a/b,c/d\) 的绝对间距至少 \(1/(bd)\ge B^{-2}\)，因此对指标 \(r,r'\le X/4\)，对数间距至少 \(c/(B^2X)\gg w\)。在实际 \(r\le N_y\) 时，\(x_y/r\ge2e^{-\ell/4}>1\)，且对 \(r\ge5\) 有 \(x_y/r<(1+o(1))X/10<X/8\)。这证明正交性、旧物理区间的内部性及与整个原槽族的正交性。

若素数幂 \(s\) 使两个同臂槽相交，则 \(|\log(sr/r')|<w\)。写 \(r=a/b,r'=c/d\)，有
\[
|sad-cb|<cb(e^w-1)
\le C\frac{B^2}{X}<1.
\]
左边是整数，故必须 \(sr=r'\)，平移后轮廓坐标逐点重合；旧算术边恰为 \(-\Lambda(s)/\sqrt s\) 乘以共同 \(L^2(0,w)\) 恒等算子。没有近似同臂边。

同臂 Archimedean 块使用 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的 \(K(d)\ll1/d+1\)。固定 \(r=a/b\) 和分母 \(d\le B\)，在 \(c/d\ne r\) 的格上，最近两点距 \(r\) 至少 \(1/(bd)\)，其余点的距离按步长 \(1/d\) 增长。因此
\[
\sum_{\substack{r'=c/d\in\mathcal R_B^*\\r'\ne r}}
\frac1{|r-r'|}
\ll B^3+B^2\log(BX).
\tag{5}
\]
因 \(|\log(r/r')|\ge |r-r'|/\max(r,r')\gg|r-r'|/X\)，每个跨槽块范数至多 \(Cw(X/|r-r'|+1)\)。由 (5)，同臂非对角整块的行和为
\(O((B^3+B^2H)/X)=o(1)\)。实际上下臂中心相距至少 \(2\log2-o(1)\)，异臂 Archimedean 行和为 \(O(B^2/X)=o(1)\)。polar 压缩范数至多
\[
O\!\left(wX\sum_{r\in\mathcal R_{y,B}}r^{-1}\right)
=O(B^2H/X)=o(1).
\tag{6}
\]
[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的精确单槽公式又给每个单位常值轮廓对角 \(D_X+o(1)\)、\(D_X=2H+1-\gamma_E-\log\pi\)，以及任意有限能量轮廓的统一局部下界 \(2H-O(1)\)。

## 反射素数幂块的平均平方范数

令 \(F_{r,r'}(x)\) 是一对标签之间整个异臂算术块的算子范数上包络。它只在某个素数幂 \(s\) 满足
\[
\left|\log\frac{srr'}{x^2}\right|<w
\tag{7}
\]
时非零，每个这样的平移部分块范数至多 \(C\Lambda(s)/\sqrt s\)。对固定 \(x,r,r'\)，允许的整数 \(s\) 落在长度 \(O(1/(rr'))\) 的区间，故个数有绝对上界。置 \(T=X^2/(rr')\ge16\)。每个 \(s\le2T\) 允许的 \(x\in[X/9,X]\) 区间长至多 \(Cw\sqrt{srr'}\)。由 Chebyshev 上界与分部求和，
\[
\sum_{s\le2T}\frac{\Lambda(s)^2}{\sqrt s}
\ll\sqrt T\log(2T),
\qquad
\int_{X/9}^{X}F_{r,r'}(x)^2\,dx
\ll\frac{\log(2T)}X.
\tag{8}
\]
这里即使候选 \(x\) 下的物理槽尚未全部落入旧区间，也可把 \(F\) 定义为 (7) 的纯数值包络；实际允许槽上的块范数受它控制。

逐分母对 \(a\le bX/4\) 使用 Stirling 求和可得
\(\sum_{r\in\mathcal R_B^*}\log(X/r)\ll B^2X\)。与 \(M_B\ll B^2X\) 合并，
\[
\sum_{r,r'\in\mathcal R_B^*}
\log\frac{2X^2}{rr'}\ll B^4X^2,
\qquad
\int_{X/9}^{X}\sum_{r,r'}F_{r,r'}(x)^2\,dx
\ll B^4X.
\tag{9}
\]
式 (9) 直接只覆盖 \(B=o(\sqrt H)\)。为推进到 (1)，取
\(S=BH\sqrt{L_H}=\Omega_{B,H}^2\)。在 (1) 下有 \(H\sqrt{L_H}\le S=o(H^2)\)，因此 \(\log(S+2)\ll L_H\)。将异臂算术块按素数幂 \(s\le S\) 与 \(s>S\) 分开。每个固定 \(s\) 的真实平移及其奇空间压缩范数至多绝对常数，故 Chebyshev 界和分部求和直接给低段
\[
\|E_{\le S}\|\ll\sum_{s\le S}\frac{\Lambda(s)}{\sqrt s}
\ll\sqrt S=\Omega_{B,H}.
\tag{9a}
\]
对高段，(8) 仍成立；若第 \((r,r')\) 块出现 \(s>S\)，则 \(T=X^2/(rr')\ge S/2\)。把标签按 \(X/2^{j+1}<r\le X/2^j\) 分箱。第 \(j\) 箱的既约标签数至多 \(CB^2X/2^j\)，而一对箱 \((j,k)\) 中 \(T\asymp2^{j+k}\)、\(\log(2T)\ll1+j+k\)；高段仅在 \(j+k\ge\log_2S-O(1)\) 出现。因此
\[
\begin{aligned}
\int_{X/9}^{X}\sum_{r,r'}F_{r,r'}^{>S}(x)^2\,dx
&\ll B^4X\sum_{n\ge\log_2 S-O(1)}(n+1)^2 2^{-n}\\
&\ll B^4X\frac{\log^2(S+2)}S
\ll B^4X\frac{L_H^2}S.
\end{aligned}
\tag{9b}
\]
以 \(S\) 为高段 Frobenius 范数平方的 Markov 阈值，高段坏中心总测度至多
\(O(B^4XL_H^2/S^2)=O(X\delta_{B,H}^2)\)。原槽的 \(J_y\) 两两相离且长度 \(\gg1/X\)，故至多 \(O(X^2\delta_{B,H}^2)\) 个原槽找不到好中心。对其余 \(y\)，标量高段包络矩阵的 Frobenius 范数至多 \(\sqrt S=\Omega_{B,H}\)。与 (9a) 合并，分块算子的 Cauchy--Schwarz 界给实际异臂算术算子
\[
\|E_{y,B}\|\ll\Omega_{B,H}=o(H).
\tag{10}
\]

## 正权图与 Schur 反馈

记 \(C_{y,B}\) 为精确同臂算术图，边 \(r\leftrightarrow sr\) 的正权为 \(\Lambda(s)/\sqrt s\)。取正权 \(v_r=r^{-1/2}\)。对任一标签 \(r=a/b\)（既约），向上乘以素数幂 \(s\) 的加权行贡献为 \(\Lambda(s)/s\)，其总和
\[
U_r\le\sum_{s\le N_y/r}\frac{\Lambda(s)}s
\le\log(N_y/r)+O(1).
\tag{11}
\]
向下除以 \(s=p^j\) 的加权行贡献为 \(\Lambda(s)\)。若 \(j\le v_p(a)\)，全部这类贡献的总和至多 \(\log a\)；若 \(j>v_p(a)\)，则目标既约分母至少含 \(p^{j-v_p(a)}\)，所以其留在 \(b'\le B\) 的标签集内迫使 \(p^{j-v_p(a)}\le B\)。后一部分至多 \(\Psi(B)=\sum_{s\le B}\Lambda(s)\ll B\)。于是
\[
D_r:=\sum_{s:r/s\in\mathcal R_{y,B}}\Lambda(s)
\le\log a+O(B),
\qquad
\frac{(C_{y,B}v)_r}{v_r}=U_r+D_r
\le\log N_y+O(B).
\tag{12}
\]
第二式还用到 \(\log a-\log r=\log b\le\log B\)。正权 Schur 检验给 \(\|C_{y,B}\|\le\log N_y+O(B)\)。结合单槽、(5)--(6)、(10) 与 \(\log N_y=H+O(1)\)，即得 (3)。

为精确估计根 Schur，删去单位标签 \(1\)，并对每条 \(r\to sr\) 使用 Hilbert 值平方恒等式
\[
\Lambda(s)\left\|\frac{h_r}{\sqrt s}-h_{sr}\right\|^2
=\frac{\Lambda(s)}s\|h_r\|^2+\Lambda(s)\|h_{sr}\|^2
-2\frac{\Lambda(s)}{\sqrt s}\operatorname{Re}\langle h_r,h_{sr}\rangle.
\tag{13}
\]
一般标签的剩余对角至少 \(2H-\log N_y-O(\Omega_{B,H})\)。若 \(r=q\ge5\) 是整数素数幂，则向下到 \(1\) 的边 \(s=q\) 已删除；其余整除 \(q\) 的向下贡献至多 \(\log q-\Lambda(q)\)，而新出现的有界分母目标总贡献至多 \(O(B)\)。因此补空间闭形式有逐坐标下界
\[
\boxed{\quad
B_{y,B}^{\rm prof}\succeq
\bigoplus_{r\in\mathcal R_{y,B}\setminus\{1\}}
\left(2H-\log N_y+
\Lambda(r)\mathbf1_{\{r\text{ 为整数素数幂}\}}
-O(\Omega_{B,H})\right)I_{L^2(0,w)}.
\quad}
\tag{14}
\]
根的同臂列恰为 \(-b\otimes h_0\)，其中 \(h_0\) 是单位常值轮廓、\(b_q=\Lambda(q)/\sqrt q\) 对整数素数幂 \(5\le q\le N_y\) 非零。其余 Archimedean、polar、异臂列的合范数为 \(O(\Omega_{B,H})\)。由 (3) 的 \(H\) 级正隙、(14) 的逆序比较，误差对逆度量是 \(o(H)\)。素数定理及高次素数幂的绝对可和性于是给
\[
R_{y,B}\le
\sum_{\substack{5\le q\le N_y\\q\text{ 素数幂}}}
\frac{\Lambda(q)^2/q}
{2H-\log N_y+\Lambda(q)-O(\Omega_{B,H})}+o(H)
=\int_0^{\log N_y}\frac{u}{2H-\log N_y+u}\,du+o(H)
=(1-\log2+o(1))H.
\tag{15}
\]
下界只保留整数素数 \(5\le q\le N_y\) 的常值槽；它们的补块为 \(2H I+O(\Omega_{B,H})\)，根列平方范数为 \((1/2+o(1))H^2\)，所以逆度量变分给 \(R_{y,B}\ge(1/4+o(1))H\)。根的异臂算术自环至多涉及绝对常数个 \(s\asymp x_y^2\)，每个权为 \(O(H/X)\)；其 polar 自项也为 \(O(X^{-1})\)。单槽公式遂给根自能量 \(2H+O(1)\)，从而得到 (4) 的最后一式。\(\square\)

## 边界

这只证明分母 \(B=o(H/\sqrt{\log H})\) 的有理锥在**几乎所有原槽**上的正压缩及相应根反馈。当前低段三角界为 \(O(\sqrt S)\)，高段 Frobenius 均方给典型范数 \(O(B^2\log S/\sqrt S)\)。若 \(B\asymp H/\sqrt{\log H}\)，同时要求例外中心比例趋零和两段范数均为 \(o(H)\) 已超出这组估计：\(S=o(H^2)\) 使高段的 Markov 界不能达到目标。此处失败的是范数工具，不能推出真实反射块大。进一步推进须利用不同素数幂平移之间的稀疏入射或符号结构。

本稿与 [scratch/816](816-finite-denominator-exterior-layers-force-unbounded-farey-leakage-candidate.md) 的槽外泄漏不矛盾：该稿估计从一个不同的 Farey 正权态向其余旧空间的算术像，本稿不控制当前锥向**锥外**的 Schur 反馈。不能据此推出完整旧奇空间正性、全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
