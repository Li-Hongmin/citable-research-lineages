# 任意移动素数平方筛轮廓的最大整数 Weil 格极限（待独立复核）

日期：2026-10-02。依赖 notes 857--859 的完整 Weil 分解、整数槽几何与单位轮廓谱隙。这里的素数集合可随 $p$ 任意改变，并可为无限集；特别包含真实平方自由指标 $\mu^2(n)$。

## 命题

沿奇素数 $p\to\infty$，置 $M=(p^2-5)/4$、$L=\log M$、$\ell=c/p^2$，其中固定 $0<c<4$。固定实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$，记 $\kappa=\int\varphi$、$C_\varphi=\int\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)$。每个 $p$ 任取素数集合 $\mathcal P_p$，允许为空、有限或无限。定义
\[
 T_p(n)=\prod_{q\in\mathcal P_p}\mathbf1_{q^2\nmid n},\qquad
 \alpha_p=\prod_{q\in\mathcal P_p}(1-q^{-2})\in[\zeta(2)^{-1},1],
 \qquad E_p=2\sum_{q\in\mathcal P_p}\frac{\log q}{q^2-1}.
\tag{1}
\]
令 $W_M=\sum_{n\le M}T_p(n)/n$，在 note 857 的槽 $I_n$ 上取
\[
 f_p(y_n+t)=\frac{T_p(n)}{\sqrt{nW_M}}b_\ell(t),
 \qquad b_\ell(t)=\ell^{-1/2}\varphi(t/\ell).
\]
则 $\|f_p\|_2=1$，且对**所有**随 $p$ 变化的 $\mathcal P_p$ 一致有
\[
 \boxed{Q_W^{\log p}[f_p]
 =\log(4/c)+C_\varphi+\gamma-\log(2\pi)
 +E_p+\frac{c\kappa^2}{4}\alpha_p+o_{c,\varphi}(1).}
\tag{2}
\]
并一致有
\[
 \boxed{Q_W^{\log p}[f_p]\ge46/25-\log(2\pi)-o(1)>0.}
\tag{3}
\]
取 $\mathcal P_p$ 为全体素数即 $T_p(n)=\mu(n)^2$；此时 $\alpha_p=1/\zeta(2)$、$E_p=-2\zeta'(2)/\zeta(2)$。

## 筛密度、调和质量与普通核

固定截断 $B\ge2$，置 $\mathcal P_{p,B}=\mathcal P_p\cap[2,B]$，相应对象记为 $T_B,\alpha_B,W_B$。$T_B$ 是固定模数 $P_B=\prod_{q\in\mathcal P_{p,B}}q^2$ 的周期序列；对给定 $B$ 只有有限个可能子集。初等同余计数一致给
\[
 \sum_{n\le X}T_B(n)=\alpha_BX+O_B(1),
 \qquad W_B(X)=\alpha_B\log X+O_B(1).
\tag{4}
\]
记 $\beta_B=\sum_{q>B}q^{-2}\to0$。由并集上界，
\[
 0\le T_B(n)-T_p(n)
 \le\sum_{q\in\mathcal P_p,\,q>B}\mathbf1_{q^2\mid n},
 \qquad 0\le\alpha_B-\alpha_p\le\beta_B.
\]
因此一致有
\[
 \sum_{n\le X}(T_B-T_p)(n)\le X\beta_B,
 \qquad 0\le W_B(X)-W_M(X)\le(1+\log X)\beta_B.
\tag{5}
\]
先令 $X\to\infty$、再令 $B\to\infty$，式 (4)--(5) 给随集合变化仍一致的
\[
 \sum_{n\le M}T_p(n)=\alpha_pM+o(M),
 \qquad W_M=\alpha_pL+o(L),
 \qquad W_M\asymp L.
\tag{6}
\]

令 $S(T)=\sum_{1\le n<r\le M}T(n)T(r)/(r-n)$。矩阵 $K_{nr}=\mathbf1_{n\ne r}/|n-r|$ 的算子范数为 $O(L)$。由 (5)，
$\|T_B-T_p\|_2^2\le M\beta_B$ 且两序列的平方范数至多 $M$，故
\[
 |S(T_p)-S(T_B)|\ll ML\sqrt{\beta_B}.
\tag{7}
\]
对固定 $B$，周期相关的调和求和如 note 859 式 (9) 给
$S(T_B)=ML\alpha_B^2+O_B(M)$。结合 (5)、(7)，先令 $M\to\infty$、再令 $B\to\infty$，得到
\[
 \boxed{S(T_p)=ML\alpha_p^2+o(ML)}
\tag{8}
\]
对所有 $\mathcal P_p$ 一致。note 856 的第二普通核 $1/(n+r)$ 的总绝对值为 $O(M)$；note 857 的共同槽中心替换误差在 $|T_p|\le1$ 下仍为 $O_{c,\varphi}(1)$，除以 $W_M\asymp L$ 后消失。故普通跨槽项为
\[
 Q_{\rm ord}[f_p]=-(c\kappa^2/4)\alpha_p+o(1).
\tag{9}
\]

## 整除图罚项的可求和高素数尾

note 859 的 ground-state 恒等式给
\[
 \langle g,C_Mg\rangle
 =\sum_{n\le M}\frac{T_p(n)}n[M_1(M/n)+\log n]-\mathcal E_M,
 \qquad g_n=T_p(n)/\sqrt n.
\tag{10}
\]
对 $q\notin\mathcal P_p$，乘以 $q^t$ 不改变 $T_p$；对 $q\in\mathcal P_p$，当 $t\ge2$ 时 $T_p(q^tn)=0$，而 $t=1$ 的差平方恰在 $q\mid n$、$T_p(n)=1$ 时等于一。因此**精确地**
\[
 \mathcal E_M
 =\sum_{q\in\mathcal P_p}(\log q)
 \left[
 \sum_{t\ge2}q^{-t}W_M(M/q^t)
 +q^{-2}W_{p;q}^{(0)}(M/q^2)
 \right],
\tag{11}
\]
其中 $W_M(X)=\sum_{n\le X}T_p(n)/n$，
$W_{p;q}^{(0)}(X)=\sum_{n\le X,\,q\nmid n}T_p(n)/n$；约定 $X<1$ 时和为零。式 (11) 的第二项由 $n=qm$、$q\nmid m$ 直接得到。

固定 $q\in\mathcal P_p$ 时，$T_p(n)\mathbf1_{q\nmid n}$ 的自然密度为
$\alpha_p/(1+1/q)=\alpha_p q/(q+1)$。用与 (4)--(6) 相同的有限截断和 $q^{-2}$ 尾界，对每个固定 $q,t$ 均匀于可能的 $\mathcal P_p$ 得
\[
 \frac{W_M(M/q^t)}L=\alpha_p+o(1),
 \qquad
 \frac{W_{p;q}^{(0)}(M/q^2)}L=\frac{q}{q+1}\alpha_p+o(1).
\tag{12}
\]
而 $W_M(X),W_{p;q}^{(0)}(X)\le1+L$，所以式 (11) 中所有 $q>B$ 项除以 $L$ 后被
$O(\sum_{q>B}(\log q)/q^2)=o_B(1)$ 一致控制；固定 $q$ 的 $t$ 大尾同样由 $\sum_{t>T}q^{-t}$ 支付。有限截断使用 (12) 后，再令 $B,T\to\infty$，得到
\[
 \frac{\mathcal E_M}{L}
 =\alpha_p\sum_{q\in\mathcal P_p}(\log q)
 \left(\sum_{t\ge2}q^{-t}+\frac1{q(q+1)}\right)+o(1)
 =\alpha_p E_p+o(1),
\tag{13}
\]
因为 $\sum_{t\ge2}q^{-t}=1/[q(q-1)]$，两分母之和为 $2/(q^2-1)$。

note 857 的 $M_1(x)=\log x-\gamma+\rho(x)$，其中 $\rho$ 有界且趋零。固定 $A>1$，$n>M/A$ 的调和质量至多 $\log A+O(1)$，除以 $W_M\asymp L$ 后消失；其余以 $\sup_{x\ge A}|\rho(x)|$ 控制。先令 $M\to\infty$ 再令 $A\to\infty$，得
\[
 \boxed{\langle g,C_Mg\rangle/W_M
 =L-\gamma-E_p+o(1)}
\tag{14}
\]
一致于 $\mathcal P_p$。

## 极点与正隙

因为 $T_p$ 为 $0/1$ 值，note 859 的极点两和分别为
$\sum T_p(n)/n=W_M$ 与
$\sum T_p(n)=\alpha_pM+o(M)$。于是
\[
 Q_{\rm pol}[f_p]
 =2m_+m_-\sum_{n\le M}T_p(n)
 =(c\kappa^2/2)\alpha_p+o(1).
\tag{15}
\]
同槽项为
$\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)$；合并 (9)、(14)--(15) 且
$\log(1/\ell)-L\to\log(4/c)$，即得 (2)。

对所有素数集合，
\[
 E_p=2\sum_{q\in\mathcal P_p}\frac{\log q}{q^2-1}
 \ge2\log2\sum_{q\in\mathcal P_p}q^{-2}
 \ge2\log2(1-\alpha_p).
\tag{16}
\]
由 note 858 的 $C_\varphi+\kappa^2\ge46/25-\gamma$，置 $r=c/4\in(0,1)$，式 (2) 减去 $46/25-\log(2\pi)$ 至少为
\[
 (2\log2-\kappa^2)(1-\alpha_p)
 +[-\log r-(1-r)\kappa^2\alpha_p]+o(1)\ge-o(1),
\]
因为 $\kappa^2\le1<2\log2$、$-\log r\ge1-r$。这给 (3)。$\square$

## 范围

本定理跨越任意多个、且可随尺度改变的素数平方排除条件；所有高素数尾由 $\sum_q(\log q)/q^2<\infty$ 支付。它不覆盖一次素数幂符号 $\mu(n)$、任意乘法轮廓、任意槽系数或补空间，也不估计 moving-$N$ 加性 Möbius signed covariance；RH 仍开放。
