# 顶端素数 cofactor 管的平滑 \(q\) 密度与素数幂在目标尺度内支付

日期：2026-10-01。依赖 [scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (23)--(26) 的真实四素数门、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通权，以及 [scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (6) 的非别名核行和。下述结果是无条件的固定幂误差支付，剩余的 \(\Lambda(q)-1\) 双变量门没有估计。独立代理已只读复核式 (1)--(10) 与原门接口并报告 PASS；异源模型复核未做，故留在 scratch。

## 命题

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)，固定非负非零的实函数 \(\psi\in C_c^3((1,2))\)，置 \(\phi(t)=\psi(t)/t\)。取闭区间 \(J=[a,b]\subset(1,2)\)，使 \(\phi>0\) 于 \(J\)，并沿用 scratch/878 的顶端素数管
\[
 A=\{pq\in MJ:p,q\text{ 为素数},\ H/2<q\le H\}.
\]
令 \(w_H\) 为 scratch/860 的实偶带通权。对任意整数权 \(|v_p|\le1\)（真实管取 \(v_p=\mathbf1_{p\ {\rm prime}}\)），定义
\[
\begin{aligned}
 F_{\rm top}(h)
 &=\frac1M\sum_{\substack{p\ge1,\ H/2<q\le H\\q\ {\rm prime},\ pq\in MJ}}
 v_p\,4\log(q/2)\,\phi(pq/M)e(-hpq/M),\\
 F_{\rm cen}(h)
 &=\frac1M\sum_{\substack{p,q\ge1\\H/2<q\le H,\ pq\in MJ}}
 v_p\,W(q)\bigl(\Lambda(q)-1\bigr)
 \phi(pq/M)e(-hpq/M),\\
 W(q)&=4\left(1-\frac{\log2}{\log q}\right).
\end{aligned}\tag{1}
\]
在 \(q>2\) 的当前带上，\(W\) 有界且总变差 \(O(1)\)。一致于全部允许的 \(H\) 与 \(|v_p|\le1\)，有
\[
 \boxed{\qquad
 \sum_h w_H(h)|F_{\rm top}(h)-F_{\rm cen}(h)|^2
 \ll_{s,\psi,J}\frac{\log^4(2H)}H
 \ll_{\varepsilon,s,\psi,J}\frac{H^4}{M}M^\varepsilon
 \quad(\forall\varepsilon>0).
 \qquad}\tag{2}
\]
因此真实顶端素数管的 \(H^4M^{-1+\varepsilon}\) 能量上界与 \(F_{\rm cen}\) 的同类上界双向等价（允许在平方三角不等式中调整 \(\varepsilon\)）。由 scratch/878 式 (26)，同一结论适用于原过滤门中的完整四素数 \(q\ne r\) 交叉的**上界**。式 (2) 实际支付了整个平滑 \(q\) 密度，且未使用 \(p\) 侧的素数分布；未付项精确含真实的 \(\Lambda(q)-1\) 跨 \(p,q\) 关联。

## 证明：精确拆分

在 \(q\) 为素数时，\(\Lambda(q)=\log q\)，所以
\(W(q)\Lambda(q)=4\log(q/2)\)。把 (1) 中的 \(q\) 和扩到全部整数，并分离高次素数幂，得到逐频精确恒等式
\[
 F_{\rm top}=F_{\rm cen}+F_{\rm sm}-F_{\rm pp},
\tag{3}
\]
其中 \(F_{\rm sm}\) 是把 (1) 中 \(W(q)(\Lambda(q)-1)\) 换成 \(W(q)\) 的同一全整数 \(q\) 和，而
\[
 F_{\rm pp}(h)=\frac1M
 \sum_{\substack{p\ge1,\ H/2<q\le H\\q=r^k,\ r\ {\rm prime},\ k\ge2,\ pq\in MJ}}
 v_p W(q)\Lambda(q)\phi(pq/M)e(-hpq/M).
\tag{4}
\]
式 (3) 不把 \(\Lambda\) 当成素数指示；(4) 正是两者的全部差。

## 证明：平滑 \(q\) 密度

置 \(P=M/H\)。若 (1) 中有非零项，则 \(p\asymp_JP\)；在 \(w_H(h)\ne0\) 时 \(|h|\asymp H\)。固定 \(p,h\)，令
\[
 g_p(q)=W(q)\phi(pq/M)\mathbf1_{H/2<q\le H}\mathbf1_{pq\in MJ}.
\]
因为 \(W(q)=O(1)\)、\(W'(q)=O(1/(H\log^2H))\)、\(\phi\in C_c^3\)，且 \(J\) 只产生两个值跳跃，\(g_p\) 的离散总变差及上确界均为 \(O_{\psi,J}(1)\)，统一于 \(p,M,H\)。有限几何和与 Abel 求和因此给
\[
 \left|\sum_q g_p(q)e(-hpq/M)\right|
 \ll_{\psi,J}
 \min\!\left(H,\frac1{\|hp/M\|}\right),
\tag{5}
\]
其中 \(\|x\|\) 为到最近整数的距离；当 \(\|hp/M\|=0\) 时右端按 \(H\) 解释。

为对 \(p\) 求和，注意 \(p\asymp_JP\) 的 \(O(P)\) 个候选使 \(hp/M\) 跨过仅 \(O_{\psi,J}(1)\) 个单位区间，且相邻网格间距 \(|h|/M\asymp1/P\)。在每个单位区间中，把到最近整数的距离分成 \(0\le t\le H^{-1}\) 与
\(j/H<t\le(j+1)/H\)、\(1\le j\le H/2\)。每个宽 \(H^{-1}\) 的小段含 \(O(P/H+1)\) 个网格点，故
\[
 \sum_{p\asymp_JP}
 \min\!\left(H,\frac1{\|hp/M\|}\right)
 \ll_{\psi,J} (P+H)\log(2H)
 \ll_{\psi,J}P\log(2H).
\tag{6}
\]
最后一步用 \(P=M/H\gg H\)。由 \(|v_p|\le1\)、(5)--(6)，逐频
\[
 |F_{\rm sm}(h)|\ll_{\psi,J}\frac{\log(2H)}H.
\]
\(w_H\) 仅支持 \(O(H)\) 个整数频率，故
\[
 \sum_h w_H(h)|F_{\rm sm}(h)|^2
 \ll_{s,\psi,J}\frac{\log^2(2H)}H.
\tag{7}
\]

## 证明：高次素数幂

固定 \(q=r^k\in(H/2,H]\)、\(k\ge2\)。式 (4) 的该 \(q\) 分量写为 \(F_q(h)\)。系数满足 \(|W(q)\Lambda(q)|\ll\log H\)，可取的整数 \(p\) 至多 \(O_J(M/q)\) 个。由 \(pq,p'q\in MJ\) 可知 \(|q(p-p')|\le(b-a)M<M\)；scratch/868 式 (6) 的非别名行和与 \(J_H(0)\ll H\ll M/q\) 给
\[
 \sum_{\substack{k\in\mathbb Z\\|qk|\le(b-a)M}}|J_H(qk)|
 \ll_{s,J}\frac Mq.
\]
展开 \(F_q\) 的频带平方，固定第一行后对第二行取绝对值，遂得
\[
 E_q:=\sum_h w_H(h)|F_q(h)|^2
 \ll_{s,\psi,J}\frac{\log^2(2H)}{q^2}
 \ll_{s,\psi,J}\frac{\log^2(2H)}{H^2}.
\tag{8}
\]
当前带的高次素数幂数目至多
\[
 \#\{r^k\in(H/2,H]:k\ge2\}
 \le\sum_{2\le r\le\sqrt H}\frac{\log H}{\log r}
 \ll\sqrt H\log(2H).
\tag{9}
\]
对频带 \(L^2(w_H)\) 范数使用三角不等式，(8)--(9) 给
\[
 \sum_h w_H(h)|F_{\rm pp}(h)|^2
 \le\left(\sum_{q\ {\rm prime\ power},\,k\ge2}\sqrt{E_q}\right)^2
 \ll_{s,\psi,J}\frac{\log^4(2H)}H.
\tag{10}
\]
由 (3)、(7)、(10) 得 (2) 第一界。又 \(H^5\ge Y=M/2\)，所以 \(H^{-1}\le2H^4/M\)，固定对数幂由 \(M^\varepsilon\) 吸收。这证明 (2) 第二界。\(\square\)

## 边界

式 (2) 是固定幂精度的真实层支付，强于短区间素数定理提供的任意对数幂窗均值。它没有证明 \(F_{\rm cen}\) 的目标界，也没有证明四素数完整上界、完整 moving-\(N\) signed covariance、全尺度局部 Weil 正性或 RH。与 [scratch/880](880-logarithmically-invisible-prime-row-modulation-defeats-the-four-prime-target.md) 的反模型相对照，这里额外使用了同一个 \(p\) 权同时供所有 \(q\) 使用的真实张量结构；下一承重点是 \(\Lambda(q)-1\) 在该张量结构中的带通相关，而非平滑素数密度。
