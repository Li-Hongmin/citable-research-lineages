# 固定周期整数 Weil 格对任意变化的微观槽轮廓保持统一正隙

日期：2026-10-03。依赖 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[note 007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) 的完整 Weil 分解，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除图恒等式，[note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的一槽不等式，以及 [scratch 982](982-fixed-period-slot-profiles-have-positive-weil-compressions.md) 式 (6) 的固定模数素数定理输入。这里取消 scratch 982 对微观轮廓空间固定有限维的限制：槽形可以随素数尺度任意改变。本稿是解析证明草稿，尚未异源复核；它不覆盖模数增长、任意槽序列或格外补空间。

## 定理

固定整数 \(P\ge1\) 和 \(0<\theta<1\)。对每个充分大的奇素数 \(p\)，任意取
\[
T^{(p)}=(T_a)_{a\bmod P},
\qquad T_a\in C_c^\infty((-1/2,1/2);\mathbb C),
\]
不要求这些轮廓来自固定的有限维空间，也不要求不同 \(p\) 的轮廓相关。记
\(v=P^{-1}\sum_{a\bmod P}\|T_a\|_2^2>0\)。令
\[
H=\log p,\quad N=(p^2-3)/2,\quad
L_N=\sum_{n\le N}n^{-1},\quad
\ell=2\theta/p^2,\quad y_n=H-\log(2n),
\]
并在第 \(n\) 个槽置
\[
U_p(y_n+t)=\frac{\ell^{-1/2}T_{n\bmod P}(t/\ell)}
{\sqrt{nL_N}},\qquad |t|<\ell/2,
\tag{1}
\]
其余处为零。则一致于全部上述 \(T^{(p)}\)，
\[
\boxed{\quad
\|U_p\|_2^2=v\left(1+O_P((\log N)^{-1})\right),
\qquad
Q_W^H[U_p]\ge
\left(\frac{46}{25}-\log(2\pi)-o_{P,\theta}(1)\right)v.
\quad}\tag{2}
\]
因此固定 \(P,\theta\) 后，整个由这种周期槽数据组成的
（微观维数不受限制的）真实 Weil 压缩，对充分大 \(p\)
有统一严格正隙。若 \(\theta=1\)，同一结论对所有满足
\(\operatorname{supp}T_a\subset[-\rho/2,\rho/2]\) 的轮廓一致成立，
其中 \(0<\rho<1\) 固定，误差常数可依赖 \(\rho\)。

## 均匀分解

以下隐含常数只依赖固定的 \(P,\theta\)；在端点还可依赖
\(\rho\)。在 \(\mathcal H_P=L^2(-1/2,1/2)^{\mathbb Z/P\mathbb Z}\)
上用均匀余数内积，令 \(\Pi\) 为单位群平均投影，即
scratch 982 式 (1)。正交写成 \(T=T^0+T^1\)，其中
\(T^0=\Pi T\)、\(T^1=(I-\Pi)T\)，并记
\[
l=\|T^0\|_P,\qquad h=\|T^1\|_P,\qquad
v=l^2+h^2,
\]
\[
\kappa_a=\int_{-1/2}^{1/2}T_a,
\quad s=\frac1P\sum_a|\kappa_a|^2,
\quad t=\left|\frac1P\sum_a\kappa_a\right|^2.
\tag{3}
\]
投影与积分交换；若 \(s_0,s_1\) 分别为 \(\Pi\kappa\)
及 \((I-\Pi)\kappa\) 的平方范数，则
\(s=s_0+s_1\)、\(t=|\mathbb E\Pi\kappa|^2\) 且
\(s_1\le h^2\)、\(t\le v\)。

每个轮廓都在单位区间内，故 note 858 的严格一槽不等式
可逐个应用，即使其形状随 \(p\) 改变。设
\(g_N=L_N^{-1}\sum_{n\le N}\|T_{n\bmod P}\|_2^2/n\)、
\(s_N=L_N^{-1}\sum_{n\le N}|\kappa_{n\bmod P}|^2/n\)。
逐同余类调和求和给
\[
g_N=v+O_P(v/L_N),\qquad s_N=s+O_P(v/L_N).
\tag{4}
\]
note 857 的 Fourier--gamma 对角分解及
\(\|\widehat{\ell^{-1/2}T_a(\cdot/\ell)}\|_\infty^2
\le\ell\|T_a\|_1^2\le\ell\|T_a\|_2^2\) 给
\[
Q_{\rm diag}
\ge\left\{\log(1/\ell)+\frac{46}{25}-\gamma
                 -\log(2\pi)\right\}g_N-s_N
       -O(\ell g_N).
\tag{5}
\]
这里的误差是对 Fourier--gamma 可积余项的绝对界。

note 854 式 (12) 对 Hilbert 空间值的 \(T_n\) 逐项成立。
令 \(M_1(x)=\sum_{k\le x}\Lambda(k)/k\)，
\(R(x)=M_1(x)-\log x+\gamma\)。因为 \(R\) 有界且趋于零，
按 \(n\le N/A\) 与 \(n>N/A\) 分割，再在后一段逐余数类
使用调和计数，可得一致于全部 \(T\) 的
\[
\frac1{L_N}\sum_{n\le N}\frac{\|T_n\|_2^2}{n}R(N/n)
=o_P(1)v.
\tag{6}
\]
更具体地，前段绝对值至多
\(\sup_{x\ge A}|R(x)|g_N\)；后段至多
\(O_P((1+\log A)v/L_N)\)，先令 \(N\to\infty\)
再令 \(A\to\infty\) 即得。于是 prime-shift 项精确化为
\[
Q_{\rm prime}=-(\log N-\gamma)g_N+D_N+o_P(1)v,
\tag{7}
\]
其中非负整除图罚项
\[
D_N=\frac1{L_N}\sum_{k\ge2}\frac{\Lambda(k)}k
\sum_{n\le N/k}\frac{\|T_n-T_{kn}\|_2^2}{n}.
\]

对普通跨槽项，\(\theta<1\) 使完整槽之间的距离至少
\(c_\theta\log(r/n)\)（\(n<r\)）；在端点 \(\theta=1\)
改用统一支撑间隙 \(1-\rho\)。由
\(|k'(u)|\ll_\theta u^{-2}\)、\(k(u)=e^{-u/2}/(1-e^{-2u})\)，
以及每槽 \(\|T_a\|_1\le\|T_a\|_2\)，中心核替换的
近差总误差至多
\[
\frac{C_{P,\theta}\ell^2}{L_N}
\sum_{n\le N}n\sum_{d\ge1}d^{-2}\,v
=O_{P,\theta}(v/L_N);
\tag{8}
\]
远差 \(r>2n\) 的误差更小。对复值周期数列 \(\kappa_n\)，
令 \(c_d=P^{-1}\sum_{a\bmod P}
\operatorname{Re}(\kappa_a\overline{\kappa_{a+d}})\)。
其对 \(d\bmod P\) 的平均为 \(t\)，且 \(|c_d|\le s\le v\)。
逐周期求和并对 \(d\) 作调和求和给
\[
\sum_{n<r\le N}\frac{\operatorname{Re}(\kappa_n\overline{\kappa_r})}{r-n}
=N\log N\,t+O_P(Nv),
\quad
\sum_{n<r\le N}
\frac{|\kappa_n\kappa_r|}{n+r}=O_P(Nv).
\tag{9}
\]
结合 note 856 的核恒等式与 \(\ell N\to\theta\)，
\[
Q_{\rm ord}=-\theta t+O_{P,\theta}(v/L_N)+o(v).
\tag{10}
\]
同余类普通计数及调和计数给
\(\sum_{n\le N}\kappa_n=N\mathbb E\kappa+O_P(\sqrt v)\)
和
\(\sum_{n\le N}\kappa_n/n=L_N\mathbb E\kappa+O_P(\sqrt v)\)。
槽内指数矩的误差由 \(|e^{\pm t/2}-1|\ll\ell\) 与
\(\|T_a\|_1\le\|T_a\|_2\) 统一支付。note 007 的
\(2\operatorname{Re}(P_+\overline{P_-})\) 遂给
\[
Q_{\rm pol}=2\theta t+O_{P,\theta}(v/L_N)+o(v).
\tag{11}
\]
式 (10)--(11) 的合量是 \(\theta t+o_{P,\theta}(1)v\)。

## 整除罚项的高低分离

把 \(D_N=D_N^{\rm unit}+D_N^{\rm bad}\)，分别按
\((k,P)=1\) 与 \((k,P)>1\) 分割。每个单位 \(k\) 都保持
\(T^0_{kn}=T^0_n\)，所以 \(D_N^{\rm unit}\) 只作用于
\(T^1\)。对 \(u\in(\mathbb Z/P\mathbb Z)^\times\)，令
\(b_u=P^{-1}\sum_{a\bmod P}\|T^1_a-T^1_{ua}\|_2^2\)。
逐余数调和求和、scratch 982 式 (6) 及一次分部积分给
\[
D_N^{\rm unit}
=\frac1{L_N}\sum_{u}b_u
\sum_{\substack{k\le N\\k\equiv u\pmod P}}
\frac{\Lambda(k)}k\log(N/k)+O_P(h^2)
=\frac{L}{2\varphi(P)}\sum_ub_u+O_P(h^2)
=Lh^2+O_P(h^2),
\tag{12}
\]
其中 \(L=\log N\)，最后一步是有限群平均恒等式
\(\varphi(P)^{-1}\sum_ub_u=2h^2\)。

坏素数幂恰为 \(q^j\) 且 \(q\mid P\)。其总权
\(\sum_{q\mid P,j\ge1}(\log q)q^{-j}\) 有限，故
\(D_N^{\rm bad}(T^i)\ll_P\|T^i\|_P^2\)。
平方差展开及 Cauchy--Schwarz 给
\[
D_N^{\rm bad}(T)
\ge D_N^{\rm bad}(T^0)-C_Plh.
\tag{13}
\]
逐个 \(q^j\) 对固定周期序列作调和平均，又给
\[
D_N^{\rm bad}(T^0)=D_B(T^0)+O_P(l^2/L_N),
\quad B=\{q:q\mid P\},
\tag{14}
\]
其中 \(D_B\) 正是 scratch 981 式 (1) 的赋值态 Dirichlet
形式，截断深度为 \(J_q=\nu_q(P)\)。note 859 的几何测度
方差界应用于标量 \(a\mapsto\int T^0_a\)，给
\[
D_B(T^0)\ge2\log2\,(s_0-t).
\tag{15}
\]

将 (5)、(7)、(10)--(15) 合并，利用
\(\log(1/\ell)-\log N=\log(1/\theta)+o(1)\)
及 (4)，得
\[
\begin{aligned}
Q_W^H[U_p]-\delta v
\ge{}&-\log\theta\,v-(1-\theta)t
 +(2\log2-1)(s_0-t)\\
& +(L-C_P-1)h^2-C_Plh-o_{P,\theta}(1)v.
\end{aligned}\tag{16}
\]
前两项之和非负，因为 \(-\log\theta\ge1-\theta\)
且 \(t\le v\)；第三项非负。由
\((L-C_P-1)h^2-C_Plh\ge-O_P(l^2/L)\)
完成平方，(16) 至少为 \(-o_{P,\theta}(1)v\)。
式 (4) 同时给物理范数极限，证明 (2)。\(\square\)

由 note 004 的 form core 稠密性及 (2) 的轮廓一致常数，
同一下界延拓到每个槽具有有限 Dirichlet 对数能量、
且满足同样周期关系的全部轮廓；光滑性只用于先写分解。

## 边界

这里的模数 \(P\) 固定，但轮廓的频率、支撑位置、有限能量
及线性维数可随 \(p\) 改变；结论控制这个无限维压缩的
Rayleigh 下界。它不估计完整局部 Weil 算子与格外补空间
的 true-Schur 交叉，也不估计 note 849 式 (15) 的真实
moving-\(N\) 三通道 signed covariance。尚未进行异源
证明复核与针对性先例检索，不晋级权威 note。
