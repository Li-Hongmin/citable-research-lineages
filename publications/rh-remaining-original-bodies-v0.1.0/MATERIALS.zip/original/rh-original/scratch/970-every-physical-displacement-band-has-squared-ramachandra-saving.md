# 真实两端点协方差的全部物理位移带获得平方 Ramachandra 节省

日期：2026-10-03。使用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)–(18) 的真实联合系数，以及 [scratch 962](962-true-two-endpoint-near-gram-has-a-double-ramachandra-collar.md) 式 (7)、(13) 的真实短块和目标精度分块公式。本命题把 [scratch 954](954-every-physical-displacement-band-of-the-true-two-endpoint-coefficient-has-subexponential-cancellation.md) 的逐带单次 Ramachandra 节省提高为平方节省，并支付任意平移的薄位移带；尚未异源复核，不作为 RH 或全尺度局部 Weil 正性的证明。

## 命题

固定实值 \(\psi\in C_c^3((1,2))\) 与非负偶函数 \(\eta\in C_c^\infty(\mathbb R)\)，其中 \(\operatorname{supp}\eta\subset\{1/2\le|t|\le4\}\)、\(\eta\ge1\) 于 \(1\le|t|\le2\)。沿用 scratch 962 的真实 \(a_m,K_H\)，令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(V_M=(\log M/\log\log M)^{1/3}\)，并取固定 \(7/12<\vartheta<\rho<3/5\)。存在 \(c_0>0\) 使下述结论成立。令 \(B_M=\lceil M^\rho\rceil\)、\(W=M/H\)、\(\epsilon_M=e^{-c_0V_M}\)。对所有 \(0\le T<U\le M\)，记 \(L=U-T\)，则

\[
\boxed{\quad
\left|\sum_{T<|m-n|\le U}a_ma_nK_H(m-n)\right|
\ll_{\psi,\eta,\vartheta,\rho}
\frac{H\min\{L+B_M,W\}}{M}\epsilon_M^2+\frac{HB_M}{M}.
\quad}                                                     \tag{1}
\]

特别地，整个真实带符号 Gram 在**每个**可移动物理位移带上都有平方 Ramachandra 节省：

\[
\boxed{\quad
\sup_{0\le T<U\le M}
\left|\sum_{T<|m-n|\le U}a_ma_nK_H(m-n)\right|
\ll e^{-2c_0V_M}.
\quad}                                                     \tag{1a}
\]

特别地，固定任意 \(0<b<2c_0\)。若 \(U-T\le H^3e^{bV_M}\)，不论位移带起点 \(T\) 如何随 \(M,H\) 移动，都有某个 \(c_b>0\) 使

\[
\boxed{\quad
\sup_{\substack{0\le T<U\le M\\ U-T\le H^3e^{bV_M}}}
\left|\sum_{T<|m-n|\le U}a_ma_nK_H(m-n)\right|
\ll \frac{H^4}{M}e^{-c_bV_M}.
\quad}                                                     \tag{2}
\]

因此同一目标量级内，任何**单个**长度不超过 \(H^3e^{bV_M}\) 的中距离位移带均已支付，包括中心位于 \(M/H\) 的带；剩余的困难是这些薄带在长度约 \(M/H\) 的区域内如何联合累积。

更一般地，若位移集合是 \(J\) 个两两不交区间 \((T_j,U_j]\) 的并，区间总长度 \(L_{\rm tot}=\sum_j(U_j-T_j)\)，则由 (1) 逐带相加得到

\[
\left|\sum_{|m-n|\in\bigcup_j(T_j,U_j]}a_ma_nK_H(m-n)\right|
\ll \frac{H(L_{\rm tot}+JB_M)}M\epsilon_M^2
+\frac{JHB_M}{M}.                                  \tag{3}
\]

特别是当 \(L_{\rm tot}\le H^3e^{bV_M}\) 且 \(J\le M^\kappa\)，其中 \(0\le\kappa<3/5-\rho\) 固定时，这个并集仍为 \(o(H^4/M)\)。

## 证明

把 \((M,2M)\) 分为 scratch 962 的长度 \(B_M\) 的连续块 \(C_i\)，令 \(x_i\) 为块中心，\(D_i=\sum_{m\in C_i}c(m)\psi(m/M)/(m/M)\)。Ramachandra 短和与 \(\rho>\vartheta\) 给出一致界

\[
|D_i|\ll B_M\epsilon_M.                              \tag{4}
\]

scratch 962 式 (13) 对任意 \(T,U\) 给出

\[
\sum_{T<|m-n|\le U}a_ma_nK_H(m-n)
=\frac1{M^2}\sum_{\substack{i,j\\T<|x_i-x_j|\le U}}
D_iD_jK_H(x_i-x_j)+O(HB_M/M).                           \tag{5}
\]

共有 \(O(M/B_M)\) 个块。固定 \(i\) 时，中心 \(x_j\) 落入 \(T<|x_i-x_j|\le U\) 的 \(j\) 至多 \(O(L/B_M+1)\) 个；末块较短不增加这个数。又 \(\|K_H\|_\infty\ll H\)。把 (4) 代入 (5)，中心块和的绝对值至多

\[
\frac H{M^2}\,O(M/B_M)\,O(L/B_M+1)
\,O(B_M^2\epsilon_M^2)
\ll\frac{H(L+B_M)}M\epsilon_M^2.
\]

还有一个与带宽无关的估计。只有 \(D_i,D_j\ne0\) 的块对需要计入；由 \(\psi\) 紧支撑及 \(B_M=o(M)\)，这些块中心差与 \(\pm M\) 隔开固定比例。note 849 式 (17) 的 Poisson 展开因而对任意固定 \(A>2\) 给

\[
|K_H(x_i-x_j)|\ll_{\psi,\eta,A}
H\left(1+\frac{|x_i-x_j|}{W}\right)^{-A}.
\tag{6}
\]

除至多一个短末块外，中心间距为 \(B_M\)；由于 \(W/B_M\to\infty\)，对每个满足 \(D_i\ne0\) 的 \(i\) 有

\[
\sum_{j:D_j\ne0}|K_H(x_i-x_j)|\ll H(W/B_M+1)\ll HW/B_M.
\tag{7}
\]

将 (7) 与 (4) 代入 (5)，并可直接丢掉带条件，中心块和又至多为

\[
M^{-2}\,O(M/B_M)\,O(B_M^2\epsilon_M^2)\,O(HW/B_M)
\ll (HW/M)\epsilon_M^2=\epsilon_M^2.
\tag{8}
\]

两个中心块界取较小者，再加 (5) 的误差，得到 (1)。又 \(HB_M/M\ll M^{\rho-3/4}\)，是 \(o(e^{-2c_0V_M})\)，故 (1a) 成立。若 \(L\le H^3e^{bV_M}\)，把 (1) 除以 \(H^4/M\)，所得右端为

\[
O\!\left(e^{-(2c_0-b)V_M}
+\frac{B_M}{H^3}\epsilon_M^2
+\frac{B_M}{H^3}\right).                                \tag{9}
\]

由 \(H\gg M^{1/5}\) 及 \(\rho<3/5\)，有 \(B_M/H^3\ll M^{\rho-3/5}\)，它比 \(e^{-cV_M}\) 衰减得更快，对任意固定 \(c>0\) 均如此。取 \(0<c_b<2c_0-b\) 得 (2)。\(\square\)

## 剩余边界

在 \(H\asymp M^{1/5}\) 时，核的主物理宽度 \(M/H\asymp M^{4/5}\)，而 (2) 的薄带宽度是 \(M^{3/5+o(1)}\)。覆盖整个主宽度需要 \(M^{1/5-o(1)}\) 个此类带；逐带使用 (2) 仍不能达到 \(H^4/M\)。式 (2) 只排除一个随 \(M,H\) 移动的薄带单独构成目标量级障碍，不证明不同带之间有相消。此处没有对实际二点 Möbius 相关取得固定幂估计。
