# 任意非负邻近分子权都有真实半整数物理共振

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的精确原始 Poisson 项与 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1)、(6)、(8) 的真实短管及素数计数。本解析结果只排除一种逐分母取绝对值的证明方法；它不估计完整 moving-$N$ 门，也不证明 RH。尚待异源复核。

## 命题

固定 $0<\gamma<1/4$，令 $H=\lfloor Y^\gamma\rfloor$。设整数
$T=T(Y)\to\infty$ 且 $T=o(H)$，取任意非负实权
$w_j\ge0$，支撑于 $|j|<T$，并令
$w_0=1$、$W=\sum_jw_j$。对真实短管 $I_a$ 及 note 801 的真实原始项 $F_{h,p}(N)$，存在固定闭区间
$\mathcal K\Subset(3/2,8/5)$ 与常数 $c_\gamma>0$，使得对充分大 $Y$，至少 $c_\gamma Y$ 个满足 $N/Y\in\mathcal K$ 的整数 $N$ 有

\[
\boxed{\quad
\sum_{H<a\le11H/10}\ \sum_{p\in I_a\cap\mathbb P}
\left|\sum_{|j|<T}w_jF_{a+j,p}(N)\right|
\gg_\gamma\frac{YW}{H^2T(\log Y)^2}.
\quad}
\tag{1}
\]

特别地，对 Fejér 权 $w_j=(1-|j|/T)_+$ 有 $W=T$，所以式 (1) 为
$\gg_\gamma Y/[H^2(\log Y)^2]$。当 $\gamma<1/4$，这比目标点态量纲 $Y^{1/2+\varepsilon}$ 大一个固定幂（取足够小的固定 $\varepsilon>0$）。因此，把邻近分子先作**任意非负加权**、再逐素数分母取绝对值，不能支付这个真实子包；需要保留不同 $a,p$ 之间的带符号抵消。

## 证明

记 $e(v)=e^{2\pi iv}$、$c_h=1+2(-1)^h$，并定义复振幅

\[
\mathcal H_a(u)=\sum_{|j|<T}w_jc_{a+j}e(ju).
\tag{2}
\]

在 $u=3/2$，$e(ju)=(-1)^j$。若 $E=\sum_{j\text{ 偶}}w_j$、$O=\sum_{j\text{ 奇}}w_j$，则 $E+O=W$，并有精确恒等式

\[
\mathcal H_a(3/2)=
\begin{cases}
3E+O\ge W,&a\text{ 偶},\\
-E-3O\le-W,&a\text{ 奇}.
\end{cases}
\quad\Longrightarrow\quad
(-1)^a\mathcal H_a(3/2)\ge W.
\tag{3}
\]

非负权和 $|j|<T$ 还给

\[
|\mathcal H_a(u)-\mathcal H_a(3/2)|
\le6\pi TW|u-3/2|.
\tag{4}
\]

取固定小常数 $c_0>0$，例如 $c_0<1/(100\pi)$。若
$|u-3/2|\le c_0/T$，则 (3)–(4) 表明
$\mathcal H_a(u)$ 距符号 $(-1)^a$ 的实数、绝对值至少 $W$ 的值不到 $W/10$。

取 $\mathcal K=[31/20,79/50]$。对 $z=N/Y\in\mathcal K$，峰点
$x_0=2z/3$ 位于 $(1,11/10)$ 的固定内部。选满足
$|a/H-x_0|\le c_1/T$ 的整数 $a$，其中 $c_1>0$ 取得足够小；这样的 $a$ 有 $\asymp H/T$ 个，且全部落在 $(H,11H/10]$。对每个 $q\in I_a$，note 845 式 (6) 给
$q/Y=a/H+O((H\log Y)^{-1})$。由于 $T=o(H)$，适当缩小 $c_1$ 后，

\[
\left|\frac Nq-\frac32\right|\le\frac{c_0}{T}.
\tag{5}
\]

再置 $x=q/Y$、$u=N/q=z/x$、$t=Hx-a$。真实短管有
$0<t\ll1/\log Y$，而 $au=Hz-tu$，故

\[
\left|\cos(2\pi au)-\cos(2\pi Hz)\right|
\ll1/\log Y.
\tag{6}
\]

在 $\mathcal K$ 的固定比例内，至少固定正比例的整数 $N$ 满足
$|\cos(2\pi HN/Y)|\ge3/4$；这是因为 $H\to\infty$、$H=o(Y)$，一个载波周期内的整数采样渐近均匀。对这些 $N$、上述 $a,q$，(3)–(6) 蕴涵

\[
\left|\Re\left[e(au)\mathcal H_a(u)\right]\right|\ge c_2W
\tag{7}
\]

其中 $c_2>0$ 为绝对常数。注意 (7) 是分子 $j$ 求和后的界，没有对 $j$ 逐项取绝对值。

对素数 $p\in I_a$，精确 Poisson 式写成

\[
F_{a+j,p}(N)
=\frac{p\log(N/p)}{\pi N(a+j)^2}
r_{a+j}\!\left(\frac{p}{(a+j)N}\right)
\cos\frac{2\pi(a+j)N}{p},
\quad
r_h(v)=\frac{4\mathbf1_{2\mid h}}{1-4v^2}-\frac1{1-v^2}.
\tag{8}
\]

这里 $\mu(p)=-1$ 已吸收到正号。由于 $a\asymp H$、$T=o(H)$，一致有
$r_{a+j}(p/((a+j)N))=c_{a+j}+O(H^{-2})$、
$p/(N(a+j)^2)=1/(zxH^2)+O(T/H^3)$。又
$f_z(x)=\log(z/x)/(\pi zx)$ 在所取 $z,x$ 的固定紧集上有正下界。故 (8) 的加权分子和等于

\[
\frac{f_z(x)}{H^2}\Re[e(au)\mathcal H_a(u)]
+O\!\left(\frac{WT}{H^3}+\frac W{H^4}\right).
\tag{9}
\]

由 $T=o(H)$，(7)–(9) 对每个所取素数给

\[
\left|\sum_jw_jF_{a+j,p}(N)\right|\gg\frac W{H^2}.
\tag{10}
\]

最后 note 845 的全区间素数短和在每个真实 $I_a$ 上一致给
$\#(I_a\cap\mathbb P)\asymp B_a/\log Y\asymp Y/[H(\log Y)^2]$。所取 $a$ 有 $\asymp H/T$ 个，故所取素数总数 $\gg Y/[T(\log Y)^2]$。对 (10) 求和即得 (1)。$\square$

## 边界

式 (1) 是绝对质量下界，不能给实际带符号和的下界。[scratch/945](945-fejer-neighbor-packet-cancels-central-prime-source-at-all-polynomial-carriers.md) 对 $T\asymp\sqrt H$ 的真 Möbius 包与素数子包反而给出相对于 $Y/[H^2(\log Y)^2]$ 的消减；两者相容，因为 (1) 中的项跨 $a$ 有符号抵消。这个 no-go 也不排除允许负权的分子组合、完整残差的其他频带或更强的真实算术估计。
