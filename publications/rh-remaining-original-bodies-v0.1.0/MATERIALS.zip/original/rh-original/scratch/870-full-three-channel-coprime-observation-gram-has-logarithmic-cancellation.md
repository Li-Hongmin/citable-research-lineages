# 完整三通道观察 Gram 的物理互素层有任意对数幂相消

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(11) 的真实联合系数、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (6) 的非别名核求和，以及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 已核的 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 3.1(i) 与式 (3.11)。式 (4)--(12) 已经独立代理只读复核；异源模型复核尚缺。结论只在对数级，未证明 RH 所需固定幂门。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实 $\psi\in C_c^3((1,2))$，置 $\phi(t)=\psi(t)/t$。在 $M<m<2M$ 定义
\[
c(m)=2\mathbf1_{2\mid m}\bigl(\Lambda(m/2)-1\bigr)
-4\bigl(\Lambda(m)-1+(\log2)\mu(m)\bigr),
\qquad a_m=M^{-1}c(m)\phi(m/M),
\tag{1}
\]
并在该区间外置 $a_m=0$。取 scratch/860 的固定 $s>1$ 带通权 $w_H(h)=\chi_s(h/H)^2$ 和 $J_H(r)=\sum_hw_H(h)e(-hr/M)$。则对每个固定 $A>0$，一致于所给 $H$，
\[
\boxed{\quad
\mathcal G_\perp(M,H):=
\sum_{\substack{M<m,n<2M\\(m,n)=1}}a_ma_nJ_H(m-n)
=O_{A,s,\psi}\bigl((\log M)^{-A}\bigr).
\quad}\tag{2}
\]
此处保留了完整真实联合系数的两条素数尺度、直接 Möbius 通道及全部交叉项。式 (2) 不推出 $H^4/M$ 的目标固定幂上界。

## 证明

记 $Z_{q,h}=\sum_{M<m<2M,\ q\mid m}a_me(-hm/M)$、$E_q=\sum_hw_H(h)|Z_{q,h}|^2\ge0$。有限除数反演给
\[
\mathcal G_\perp=\sum_{q\ge1}\mu(q)E_q,
\qquad |\mathcal G_\perp|\le\sum_{q\ge1}E_q.
\tag{3}
\]
固定待选 $B>0$，取 $Q=\lfloor(\log M)^B\rfloor$、$L=\lfloor M/(32H)\rfloor$、$B_0=\lfloor M^{2/3}\rfloor$。一致地有 $B_0(\log M)^C=o(L)$，任意固定 $C>0$。

对 $q\le Q$，从 $q\mid m$ 的系数中扣去如下周期密度：
\[
g_1(m)=0,\qquad g_2(m)=4\mathbf1_{2\mid m},\qquad
g_q(m)=(4-2\mathbf1_{2\mid m})\mathbf1_{q\mid m}\quad(3\le q\le Q).
\tag{4}
\]
在 $M<m<2M$ 令 $r_q(m)=\mathbf1_{q\mid m}c(m)-g_q(m)$。当 $q=1$，scratch/862 式 (8) 已给每个长度 $B_0$ 的物理块上 $\sum c(m)=O_C(B_0(\log M)^{-C})$。当 $q=2$，在偶数 $m=2n$ 上精确有
\[
r_2(2n)=2(\Lambda(n)-1)-4\Lambda(2n)-4(\log2)\mu(2n).
\tag{5}
\]
$\Lambda(2n)$ 在当前区间只来自 $2$ 的幂，整段绝对质量 $O(\log^2M)$；$\Lambda(n)-1$ 在长度 $B_0/2+O(1)$ 的整数块由 2023 Theorem 3.1(i) 与式 (3.11) 给任意固定对数幂节省，$\mu(2n)$ 则由同一定理的最大等差进程界支付。

当 $q\ge3$ 时，逐系数有
\[
r_q(m)=\mathbf1_{q\mid m}
\left[2\mathbf1_{2\mid m}\Lambda(m/2)
-4\Lambda(m)-4(\log2)\mu(m)\right].
\tag{6}
\]
在 $M<m<2M$，$q\mid m$ 的 $\Lambda(m)$ 与 $\Lambda(m/2)$ 非零项只可能是固定素数的幂或其两倍；其整段绝对质量一致为 $O(\log^2M)$。余下 $\mu(m)$ 在任意长度 $B_0$ 的物理块及进程 $q\mid m$ 上受 2023 Theorem 3.1(i) 控制，界为 $O_C(B_0(\log M)^{-C})$，且常数与 $q$ 无关。

把 $(M,2M)$ 内任意长度不超过 $L$ 的区间分成完整 $B_0$ 块与至多两个端块。由 $|r_q(m)|\ll\log M$，端块平凡支付；全部素数幂另用整段质量支付。因此，统一于 $q\le Q$，
\[
\sup_{\substack{I\subset(M,2M)\\|I|\le L}}
\left|\sum_{m\in I}r_q(m)\right|
\ll_C L(\log M)^{-C}.
\tag{7}
\]
对 $\phi(m/M)$ 作 Abel 求和，归一化残差在每个长度 $L$ 窗中的和为 $O_{C,\psi}((L/M)(\log M)^{-C})$。由于 $\phi$ 在周期拼接处为零，scratch/862 式 (11) 的周期 Parseval 论证及带通支撑上 $|\sum_{j=0}^{L-1}e(-hj/M)|\gg L$ 给
\[
\sum_hw_H(h)
\left|M^{-1}\sum_mr_q(m)\phi(m/M)e(-hm/M)\right|^2
\ll_{C,s,\psi}(\log M)^{-2C}.
\tag{8}
\]

周期密度本身在该带通内可直接支付。对 $r\le2Q$，Poisson 求和与 $\phi\in C_c^3$ 给
\[
M^{-1}\sum_{r\mid m}\phi(m/M)e(-hm/M)
=\frac1r\sum_{j\in\mathbb Z}\widehat\phi(h+jM/r)
\ll_\psi H^{-3}
\qquad(w_H(h)\ne0),
\tag{9}
\]
因为 $|h|\asymp H\ll M/r$。式 (4) 各是至多两个模数 $r=q,[2,q]$ 的这类和的固定线性组合。平方三角不等式与 (8) 因而给
\[
E_q\ll_{C,s,\psi}(\log M)^{-2C}+H^{-5}
\qquad(q\le Q).
\tag{10}
\]

对 $q>Q$ 取绝对值。由 $\phi$ 紧支撑，存在固定 $\kappa_\psi>0$，使得 $a_ma_n\ne0$ 时 $|m-n|\le(1-\kappa_\psi)M$。由 $|a_m|\ll_\psi\log(2M)/M$ 及 scratch/868 式 (6) 的非别名核和
\[
\sum_{\substack{k\ne0\\|qk|\le(1-\kappa_\psi)M}}|J_H(qk)|\ll_{s,\psi} M/q,
\]
非对角部分至多
\[
\frac{\log^2(2M)}{M^2}\sum_{q>Q}\frac Mq\frac Mq
\ll\frac{\log^2(2M)}Q.
\tag{11}
\]
对角部分由 $\sum_{m\le2M}\tau(m)\ll M\log M$ 至多为
\[
\sum_m|a_m|^2|J_H(0)|\tau(m)
\ll_\psi\frac{H\log^3(2M)}M.
\tag{12}
\]
于是
\[
|\mathcal G_\perp|
\ll Q(\log M)^{-2C}+QH^{-5}
+\frac{\log^2M}{Q}+\frac{H\log^3M}{M}.
\]
给定 $A$，先取 $B>A+3$，再取 $C>B+A$；两个含 $H$ 的幂次项在所给频带小于任意固定负对数幂，遂得 (2)。$\square$

## 边界

式 (2) 比 [scratch/869](869-coprime-direct-source-blocks-have-constant-signs-and-log-cancellation.md) 的直接 Möbius 源估计覆盖更广。按 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的近差绝对支付和 scratch/860 的远差支付，物理互素层在原中距离过滤后至多为 $O_A((\log M)^{-A}+H^4/(M\log^2M))$。在 $H\asymp M^{1/4}$ 时，近差绝对项仍可达 $\log^{-2}M$ 量级；本稿不声称过滤后的任意对数幂界。全频带的 $H^4M^{-1+\varepsilon}$ 固定幂算术门仍开放。
