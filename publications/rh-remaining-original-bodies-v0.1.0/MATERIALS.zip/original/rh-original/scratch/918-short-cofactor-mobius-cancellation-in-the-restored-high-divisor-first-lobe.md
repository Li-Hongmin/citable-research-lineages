# 完整高除数物理行在首个中距离瓣的对数相消

日期：2026-10-02。接 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实高除数系数、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核及 [scratch/917](917-small-physical-gcd-restores-the-complete-high-divisor-gram.md) 的物理行重组。唯一外部输入是 Matomäki--Shao--Tao--Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, *Forum Math. Pi* **11** (2023), e29, Theorem 3.1(i) 的 Möbius 最大进程估计（DOI 10.1017/fmp.2023.28）；本稿从原论文 PDF 的定理及最大进程定义式 (1.4) 核对了量词。首个瓣只有对数节省，但一段扩大后的近差环带达到目标固定幂量级。尚未异源复核；完整算术门仍开放。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实值 $\psi\in C_c^3((1,2))$，$\phi(u)=\psi(u)/u$，并取 scratch/859 的 $D,b_d$ 与 scratch/860 的任一固定 Gevrey 带通权 $w_H,J_H$。置
\[
a_D(m)=\sum_{\substack{d\mid m\\d>D}}\mu(d)b_d(m),
\qquad L=\left\lfloor\frac{M}{32H}\right\rfloor,
\qquad a_D(m)=0\quad(m\notin(M,2M)).
\tag{1}
\]
则对每个固定 $A>0$，一致于整个 $H$ 范围及所有整数区间 $I\subset(M,2M)$、$|I|\le L$，
\[
\boxed{\quad
\left|\sum_{m\in I}a_D(m)\right|
\ll_{A,\psi}\frac LM(\log M)^{-A}.
\quad}\tag{2}
\]
因此首个物理中距离瓣的**完整高除数 Gram**满足
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\|m-n|\le L}}
a_D(m)\overline{a_D(n)}J_H(m-n)
=O_{A,s,\psi}((\log M)^{-A})
\quad}\tag{3}
\]
对每个固定 $A>0$ 一致成立。式 (3) 包含全部高除数源交叉项，并未逐项取绝对值；它不能推出 $H^4M^{-1+\varepsilon}$，因为 $H=Y^\gamma$、$\gamma<1/4$ 时该目标为固定负幂。

此外，令 $G,K_0,\mathfrak S_{\le G}$ 如 scratch/917，并把 $\mathfrak S_{\le G}$ 的物理距离再限于 $K_0<|m-n|\le L$，记为 $\mathfrak S_{\le G}^{\rm first}$。则
\[
\boxed{\quad
\mathfrak S_{\le G}^{\rm first}
=O_{A,s,\psi}((\log M)^{-A})
+O_{s,\psi}\!\left(\frac{H^4}{M\log^2 M}\right).
\quad}\tag{4}
\]
特别地，这一段真实过滤源门一致为 $o(1)$；留下的较远距离瓣仍无固定幂上界。

## 证明

由 scratch/917 式 (4) 与 scratch/859 式 (2)，当 $d\mid m$ 时
\[
b_d(m)=-\frac{\phi(m/M)}M\alpha(m/d),
\qquad |\alpha(k)|\ll\log(2k).
\]
把 $k=m/d$ 作为先求和变量，精确得到
\[
\sum_{m\in I}a_D(m)
=-\frac1M\sum_{k<32H}\alpha(k)
\sum_{\substack{d>D\\kd\in I}}
\mu(d)\phi(kd/M).
\tag{5}
\]
上界 $k<32H$ 来自 $m<2M$ 与 $d>D=\lfloor M/(16H)\rfloor$，故 $d>M/(16H)$。

固定 $k<32H$。式 (5) 的 $d$ 位于 $x\asymp M/k$ 的区间，长度至多 $L/k+O(1)$。取覆盖它的母区间长度 $T_k=\lceil L/k\rceil+2$。常数因子不影响下列统一关系：
\[
x^{5/8}\ll T_k\ll x^{23/24}.
\tag{6}
\]
事实上 $T_k\asymp M/(Hk)$；左端比值的最小幂来自 $H,k\asymp M^{1/4}$，此时
$T_k/x^{5/8}\gg M^{1/32}$。右端因 $H\gg M^{1/5}$ 成立。故原论文 Theorem 3.1(i) 可统一取 $\varepsilon=1/24$：其下限为 $x^{7/12+1/24}=x^{5/8}$，上限为 $x^{1-1/24}=x^{23/24}$。该定理的最大进程范数覆盖母区间中的任意子区间，包括 $d>D$ 的额外截断，给每个固定 $B>0$
\[
\sup_{J\subset\text{母区间}}
\left|\sum_{d\in J}\mu(d)\right|
\ll_B\frac Lk(\log M)^{-B}.
\tag{7}
\]
这里 $\log x\asymp\log M$，且 $L/k\to\infty$，所以取整误差被吸收。

权 $d\mapsto\phi(kd/M)$ 在相应区间上的上确界与总变差之和为 $O_\psi(1)$。对 (7) 作离散 Abel 求和，再用
$\sum_{k<32H}|\alpha(k)|/k\ll\log^2(2M)$，便由 (5) 得到 (2)：先在 (7) 取 $B=A+3$ 即可。

带通核满足
\[
\sup_{|t|\le L}|J_H(t)|\ll_sH,
\qquad
\operatorname{Var}_{[-L,L]}J_H\ll_sH,
\tag{8}
\]
因为非零频率数为 $O(H)$、$|h|\ll H$，所以 $|J_H'|\ll_sH^2/M$，且 $L\ll M/H$。固定 $m$ 后，把 $[m-L,m+L]$ 在 $m$ 处分成两个长度至多 $L$ 的区间；式 (2) 控制各自的全部前缀。再次 Abel 求和，由 (8) 得
\[
\left|\sum_{|m-n|\le L}\overline{a_D(n)}J_H(m-n)\right|
\ll_{A,s,\psi}\frac{HL}{M}(\log M)^{-A}
\ll_{A,s,\psi}(\log M)^{-A}.
\tag{9}
\]
scratch/859 式 (9) 给 $\sum_m|a_D(m)|\le\sum_mB(m)\ll_\psi\log^2M$。把 (9) 乘 $|a_D(m)|$ 后求和，并在 (2) 预先多取两个对数幂，即得 (3)。

最后，在 $|m-n|\le L$ 的区间中，scratch/917 式 (2) 把物理 gcd 不超过 $G$ 的原过滤源项精确合成 $a_D(m)\overline{a_D(n)}J_H(m-n)$。从 (3) 删去非对角的 $(m,n)>G$，scratch/868 式 (2b) 给费用 $O(\log^8M/G)=O(H^3\log^4M/M)$；对角由该稿式 (11) 另付 $O(H\log^5M/M)$。两者都小于任意固定负对数幂。再删去 $|m-n|\le K_0$，scratch/859 式 (10) 的完整高除数绝对费用为 $O(H^4/(M\log^2M))$。这证明 (4)。$\square$

## 固定幂支付的近差前沿

上面的短 cofactor 论证可在较短物理区间运行，因而给实际过滤源门一个**目标量级**的距离扩展。固定
$0<\delta<1/4-7/31$ 与 $B>0$。在
\[
M^{7/31+\delta}\le H\le Y^{1/4},
\qquad T_B=\left\lfloor H^3(\log M)^B\right\rfloor
\tag{10}
\]
中，把 scratch/917 的 $\mathfrak S_{\le G}$ 再限于 $K_0<|m-n|\le T_B$，记为 $\mathfrak S_{\le G}^{\rm near}(T_B)$；把原始 $\mathfrak S$ 作同样距离限制，记为 $\mathfrak S^{\rm near}(T_B)$。充分大 $M$ 时 $K_0<T_B<K_1$，且
\[
\boxed{\quad
\left|\mathfrak S_{\le G}^{\rm near}(T_B)\right|
+\left|\mathfrak S^{\rm near}(T_B)\right|
\ll_{\delta,B,s,\psi}\frac{H^4}{M\log^2 M}.
\quad}\tag{11}
\]
因此，在该 $H$ 范围内，真实过滤高除数门的未付距离可从 $H^3(\log M)^B$ 之后开始；$B$ 可取任意预先固定常数。这个陈述仅支付一段距离，不界定剩余较远瓣。

证明仍从 (5) 出发，只把母区间长度改为 $U_k=\lceil T_B/k\rceil+2$。令 $x\asymp M/k$、$k<32H$。取一个足够小的固定 $\varepsilon=\varepsilon(\delta)>0$，使
\[
2(7/31+\delta)
>(1-7/31-\delta)(7/12+\varepsilon).
\tag{12}
\]
这是可能的，因为 $2(7/31)=(1-7/31)7/12$。最紧的下限出现在 $k\asymp H$；式 (12) 给 $U_k\gg x^{7/12+\varepsilon}$，并有随 $M$ 增长的幂次余量。另一方面 $U_k\ll x^{1-\varepsilon}$，因为 $T_B\le M^{3/4}(\log M)^B$ 且可再选 $\varepsilon<1/8$。原论文 Theorem 3.1(i) 的同一最大进程界及 (5) 的 Abel 求和遂给，对任意固定 $A>0$，
\[
\sup_{|I|\le T_B}\left|\sum_{m\in I}a_D(m)\right|
\ll_{A,\delta,B,\psi}\frac{T_B}{M}(\log M)^{-A}.
\tag{13}
\]
核在 $[-T_B,T_B]$ 上的上确界加总变差为 $O_s(H+H^2T_B/M)$。像 (9) 那样对内层及外层依次求和，吸收 $\sum_m|a_D(m)|\ll\log^2M$，得完整物理近差 Gram
\[
\left|\sum_{|m-n|\le T_B}a_D(m)\overline{a_D(n)}J_H(m-n)\right|
\ll_{A,\delta,B,s,\psi}
\frac{HT_B}{M}\left(1+\frac{HT_B}{M}\right)(\log M)^{-A}.
\tag{14}
\]
由 $H^4/M\ll1$ 与 $HT_B/M\ll(H^4/M)(\log M)^B$，在 (14) 取 $A>2B+4$ 后，右侧是 $O(H^4/(M\log^2M))$。将非对角物理 gcd 限于 $G$ 增加 scratch/868 式 (2b) 的 $O(\log^8M/G)$ 误差，对角另由其式 (11) 支付 $O(H\log^5M/M)$；由 scratch/917 的 $G\gg M\log^4M/H^3$，它们与目标之比分别至多为 $O(\log^6M/H)$、$O(\log^7M/H^3)$，均趋于零。删去 $|m-n|\le K_0$ 再花费 scratch/859 式 (10) 的 $O(H^4/(M\log^2M))$。由 scratch/917 式 (2) 的精确重组得 $\mathfrak S_{\le G}^{\rm near}(T_B)$ 的估计；scratch/917 式 (3) 对大 gcd 的同一绝对支付给 $\mathfrak S^{\rm near}(T_B)$ 的估计。$\square$

## 边界

证明只用每条短 cofactor 的一阶 Möbius 短和。式 (11) 真正支付了一段扩大近差，但对 $T_B<|m-n|\le K_1$ 的中距离带没有给出目标固定幂；在 $H\le M^{7/31}$ 时连本稿的近差扩展也不适用。下一步必须在完整物理行的低 gcd 二点和、或带通远旁瓣中获得固定幂增益；重复一阶对数节省不会填补该差距。
