# 任意固定素因子深度仍不足以由单窗资料推出 moving covariance 幂界

日期：2026-10-02。推广 [scratch/922](922-semiprime-flips-preserve-true-prime-signs-but-defeat-window-only-moving-covariance.md) 的两素因子扰动；使用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合观察系数和 Matomäki–Shao–Tao–Teräväinen, *Forum Math. Pi* **11** (2023), e29, Theorem 3.1(i) 与式 (3.11)。这是一项测试类的严格范围结论，函数不要求乘法，不能作为真实 Möbius 函数或 RH 的反例。尚未异源复核。

## 命题

固定整数 $r\ge2$、实值非负且非零的 $\psi\in C_c^3((1,2))$，置 $\phi(u)=\psi(u)/u$。令偶整数 $M=2Y\to\infty$，
\[
H=\lceil Y^{1/5}\rceil,\quad h_0=\lfloor3H/2\rfloor,\quad
L=\lfloor M/(32H)\rfloor,\quad B=\lfloor M^{71/120}\rfloor,
\quad\delta=e^{-\sqrt{\log M}}.                                      \tag{1}
\]
取非负偶带通权 $w_H(h)=v(h/H)$，其中 $v$ 支撑于 $1/2\le|t|\le4$，且 $v\ge1$ 于 $1\le|t|\le2$；令 $J_H(k)=\sum_hw_H(h)e(-hk/M)$。对 $f:\mathbb N\to\{0,\pm1\}$，定义 $\Lambda_f=f*\log$ 和
\[
c_f(m)=2\mathbf1_{2\mid m}(\Lambda_f(m/2)-1)
-4\bigl(\Lambda_f(m)-1+(\log2)f(m)\bigr),\qquad
A_h(f)=\frac1M\sum_{M<m<2M}c_f(m)\phi(m/M)e(-hm/M).             \tag{2}
\]
对每个充分大的 $M$，存在四个函数 $f_{ab}$，$a,b\in\{0,1\}$，其中 $f_{00}=\mu$，满足：

1. $|f_{ab}(n)|=\mu(n)^2$ 对一切 $n$；当 $n\le M$ 或 $\Omega(n)\le r-1$ 时 $f_{ab}(n)=\mu(n)$；且 $f_{ab}(2u)=-f_{ab}(u)$ 对每个奇数 $u$。特别地，全部真实素数值均保留。
2. $\Lambda_{f_{ab}}(n)=\Lambda(n)$ 对每个 $n<2M$。在 $(M,2M)$ 中，任意固定 $A>0$、任意长度 $B$ 的整数区间 $I$ 满足
   $\sum_{m\in I}c_{f_{ab}}(m)=O_{A,r}(B\log^{-A}M)$；对任意固定 $C>0$、$1<q\le\log^C M$，逐点有 $\mathbf1_{q\mid m}c_{f_{ab}}(m)=\mathbf1_{q\mid m}c_\mu(m)$。
3. 四者中至少一个满足
   \[
   \sum_hw_H(h)|A_h(f_{ab})|^2
   \gg_{r,\psi,v}\frac{\delta^2}{\log^{2r}M}
   \gg\frac{H^4}{M}.                                             \tag{3}
   \]
   对任意预先固定的 $\gamma>0$，四者中至少一个（可以不同）满足
   \[
   \left|\frac1{M^2}
   \sum_{\substack{M<m,n<2M\\H^3(\log M)^\gamma<|m-n|\le L}}
   c_{f_{ab}}(m)c_{f_{ab}}(n)\phi(m/M)\phi(n/M)J_H(m-n)\right|
   \gg_{r,\psi,v,\gamma}\frac{\delta^2}{\log^{2r}M}
   \gg\frac{H^4}{M}.                                             \tag{4}
   \]

这里 $\Omega$ 计重数。因而任意**预先固定**的素因子层真实取值、窗口内精确卷积、平方自由支撑、奇数的 $2$-adic parity、任意对数幂一阶短和及小模整除资料，合起来仍不足以在这类非乘法测试函数上推出目标幂界。

## 每个短块中的 $r$ 素因子数

取 $\theta=1/100$、$\alpha=\theta/(r-1)$。对 $1\le j\le r-1$，令 $\mathcal P_j$ 为素数区间
\[
4jM^\alpha\le p_j\le(4j+1)M^\alpha.                         \tag{5}
\]
这些区间两两不交。对元组 $\boldsymbol p=(p_1,\ldots,p_{r-1})$ 写 $P=\prod_jp_j\asymp_r M^\theta$。若 $I\subset(M,2M)$ 为长度 $B$ 的整数块，则 $Pq\in I$ 的素数 $q$ 位于尺度 $X\asymp_r M/P$、长度 $T=B/P+O(1)$ 的区间。统一于 $\boldsymbol p,I$，
\[
T\gg X^{7/12+1/1000},\qquad T\ll X^{1-1/1000},               \tag{6}
\]
因为关键指数裕量精确为
\[
\frac{71}{120}-\theta-(1-\theta)
\left(\frac7{12}+\frac1{1000}\right)
=\frac{953}{300000}>0.                                         \tag{7}
\]
引用的全区间定理与筛选模型主项，连同素数幂 $O(\sqrt X\log^2M)=o_A(T\log^{-A}M)$ 的费用，给任意固定 $A>0$ 的一致估计
\[
\#\{q\text{ prime}:Pq\in I\}
=\frac{B}{P\log(M/P)}
+O_{A,r}\!\left(\frac{B}{P\log^A M}\right).                    \tag{8}
\]
式 (8) 的对数权由 Abel 求和处理；需要的误差指数可在原定理中预先增大。素数定理又给每个 $j$ 的
\[
\sum_{p_j\in\mathcal P_j}\frac1{p_j}
\sim\frac{\log((4j+1)/(4j))}{\alpha\log M}.
\]
故每个 $B$ 块都有
\[
\#\{s=Pq\in I:p_j\in\mathcal P_j,\ q\text{ prime}\}
\gg_r\frac{B}{\log^rM}.                                        \tag{9}
\]
因为 $q\gg_r M^{1-\theta}$ 远大于所有 $p_j$，而 (5) 的区间互不相交，表示唯一。所有 $s$ 为奇平方自由数，恰有 $r$ 个素因子，且每个素因子都大于任意固定对数幂。

## 扰动、短和与能量

选闭区间 $J\subset(1,2)$，使 $\phi\ge c_\psi>0$ 于 $J$。余弦 $\cos(2\pi h_0x/M)$ 的周期为 $M/h_0\asymp M/H$，而 $L\le M/(32H)$。每个完整周期可选一段长 $L$、余弦处处至少 $1/2$ 的整数格。因此 $MJ$ 中有 $\gg_\psi M/L$ 个互不相交的有利格，每格含 $\gg L/B$ 个完整的全局 $B$ 网格块。

置 $t=\lfloor\delta B/(100\log^rM)\rfloor\to\infty$。由 (9)，每个被选 $B$ 块可取 $2t$ 个不同的 $s$，平分到不交的 $S_1,S_2$。于是每个有利 $L$ 格中 $|S_j\cap C|\gg_{r,\psi}\delta L/\log^rM$，全体 $|S_j|\gg_{r,\psi}\delta M/\log^rM$。任意长度 $B$ 的区间只交两个或至多三个全局网格块，故含 $O(t)$ 个 $S_j$ 元素。

令 $\varepsilon_r=(-1)^r$。当 $a=1$ 时，在 $S_1$ 上把真实值 $\mu(s)=\varepsilon_r$ 翻成 $-\varepsilon_r$；当 $b=1$ 时同样处理 $S_2$。对每个被翻转的奇数 $s$，同时置 $f_{ab}(2s)=-f_{ab}(s)$；其余位置保持 $\mu$。修改只发生在 $s>M$、$2s>2M$，其 $\Omega$ 值分别为 $r,r+1$，所以第 1 项成立。

若 $n<2M$，修改过的 $s$ 只能以 $n=s$ 出现在 $((f_{ab}-\mu)*\log)(n)$，其卷积权是 $\log1=0$；修改过的 $2s$ 不在范围内。因此 $\Lambda_{f_{ab}}(n)=\Lambda(n)$，并在观察窗精确得到
\[
c_{f_{ab}}(m)=c_\mu(m)+8\varepsilon_r(\log2)
\bigl(a\mathbf1_{S_1}(m)+b\mathbf1_{S_2}(m)\bigr).             \tag{10}
\]
真实 $c_\mu$ 的长度 $B$ 短和由同一 2023 定理分别施于 $\mu$、$\Lambda-1$ 和偶数换元后的 $\Lambda-1$，为任意固定负对数幂。式 (10) 的新增短和至多 $O(t)=O(\delta B/\log^rM)$，也小于 $B\log^{-A}M$。各 $s$ 与所有 $1<q\le\log^C M$ 互素，所以小模逐点资料保持。第 2 项成立。

因 $\phi(s/M)\ge c_\psi$ 且有利格上 $\cos(2\pi h_0s/M)\ge1/2$，式 (10) 使
\[
|A_{h_0}(f_{10})-A_{h_0}(f_{00})|
\gg_{r,\psi}\frac{|S_1|}{M}
\gg\frac{\delta}{\log^rM}.
\]
三角不等式及 $w_H(h_0)\ge1$ 给 (3)。

当 $|k|\le L$ 时，所有 $w_H(h)$ 非负、$|h|\le4H$，且 $|2\pi hk/M|\le\pi/4$，故 $J_H(k)\gg_vH>0$。每个有利格的 $S_1\times S_2$ 有 $\gg\delta^2L^2/\log^{2r}M$ 个有序配对，其中距离至多 $T_\gamma=H^3(\log M)^\gamma$ 的至多 $O(|S_1\cap C|T_\gamma)$ 个；删除比例至多
\[
O\!\left(\frac{T_\gamma\log^rM}{\delta L}\right)
=M^{-1/5+o(1)}\to0.                                     \tag{11}
\]
把 (4) 中的两份 $c_f$ 换成指示函数，记所得实对称双线性式为 $\mathcal B_\gamma$。所有 $S_1\times S_2$ 的保留项非负，所以只数同格配对便得
\[
\mathcal B_\gamma(\mathbf1_{S_1},\mathbf1_{S_2})
\gg\frac{H}{M^2}\frac{\delta^2ML}{\log^{2r}M}
\gg\frac{\delta^2}{\log^{2r}M}.                          \tag{12}
\]
式 (10) 的混合二阶差恰是
\[
Q_\gamma(f_{11})-Q_\gamma(f_{10})-Q_\gamma(f_{01})+Q_\gamma(f_{00})
=128(\log2)^2\mathcal B_\gamma(\mathbf1_{S_1},\mathbf1_{S_2}). \tag{13}
\]
四项三角不等式证明 (4)。最后 $H^4/M=M^{-1/5+o(1)}$，而 $\delta^2/\log^{2r}M=M^{-o(1)}$，所以两式严格超过目标。$\square$

## 边界

该构造对每个固定 $r$ 都精确保留更浅的全部真实素因子层，却在第 $r$ 层打破 $f(p_1\cdots p_r)=\prod_i f(p_i)$。更直接地，每个被翻转的 $s$ 满足 $(f*1)(s)=f(s)-\mu(s)=-2\varepsilon_r\ne0$，所以真实的 $\mu*1=\delta_1$ 逐点排除该模型。[scratch/924](924-mobius-inversion-moves-the-full-observation-to-cofactors-at-least-three.md) 将这条真实反演关系代入联合观察，得到另一种精确源表示。结论只排除依赖上述有限层资料的**普遍测试函数推理**；要推进实际门，还须在真实二点和里取得固定幂消去。式 (3)--(4) 本身不给这种估计。
