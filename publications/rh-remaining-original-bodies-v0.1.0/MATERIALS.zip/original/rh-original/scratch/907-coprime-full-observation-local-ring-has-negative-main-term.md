# 完整联合观察系数的物理互素近环带有负常数主项

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合系数、[scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 的互素除数反演和等差进程短和，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通核。下面计算的是**完整物理系数**，不是 [scratch/869](869-coprime-direct-source-blocks-have-constant-signs-and-log-cancellation.md) 的直接源，也不是 [scratch/906](906-three-adic-source-pairing-removes-twelve-divisible-cofactors.md) 的单独 \(k=3/k=1\) 线。证明为解析推导，暂留 scratch；尚无异源复核。

## 定理

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)，取固定实、非负、非零的 \(\psi\in C_c^3((1,2))\)，置 \(\phi(t)=\psi(t)/t\)。沿用 scratch/860 的偶、非负带通权 \(w_H(h)=v(h/H)\)，其中 \(v=\chi_s^2\) 支撑于 \(1/2\le |t|\le4\)，并令
\[
J_H(r)=\sum_h w_H(h)e(-hr/M),\quad
L=\left\lfloor\frac{M}{32H}\right\rfloor,\quad
K_0=\left\lfloor\frac{H^3}{\log^2M}\right\rfloor,\quad
a_m=\frac{c(m)}M\phi(m/M),
\tag{1}
\]
其中 \(c(m)\) 是 note 849 式 (10) 的完整真实系数；窗外置 \(a_m=0\)。定义
\[
\mathcal J_{\psi,v}
=\left(\int_1^2\phi(t)^2\,dt\right)
 \left(\int_{-1/32}^{1/32}\widehat v(\xi)\,d\xi\right)>0.
\tag{2}
\]
则对每个固定 \(A>0\)，一致于整个 \(H\) 范围，
\[
\sum_{\substack{M<m,n<2M\\(m,n)=1\\|m-n|\le L}}
a_ma_nJ_H(m-n)
=\left(\frac{64}{\pi^2}-12\right)\mathcal J_{\psi,v}
+O_{A,s,\psi}((\log M)^{-A}).
\tag{3}
\]
特别地，
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\(m,n)=1\\K_0<|m-n|\le L}}
a_ma_nJ_H(m-n)
=\left(\frac{64}{\pi^2}-12\right)\mathcal J_{\psi,v}+o(1)<0.
\quad}\tag{4}
\]
同一互素层的远旁瓣满足
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\(m,n)=1\\|m-n|>L}}
a_ma_nJ_H(m-n)
=\left(12-\frac{64}{\pi^2}\right)\mathcal J_{\psi,v}
+O_{A,s,\psi}((\log M)^{-A})>0.
\quad}\tag{5}
\]
式 (4)--(5) 是两个固定非零主项之间的补偿，不是 note 849 式 (15) 所需的 \(H^4/M\) 固定幂界。

## 证明

对 \(q\ge1\) 置
\[
F_q(m)=\mathbf1_{q\mid m}a_m,\qquad
\mathcal C_q(L)=\sum_{|m-n|\le L}F_q(m)F_q(n)J_H(m-n).
\tag{6}
\]
有限互素反演给式 (3) 的左侧等于 \(\sum_{q\ge1}\mu(q)\mathcal C_q(L)\)。最简单的算术元是 \(q\) 进程的**周期均值**。scratch/870 式 (4)--(7) 已证明，对任意 \(Q=(\log M)^B\)、任意固定 \(C>0\) 和全部 \(q\le Q\)，可写
\[
\mathbf1_{q\mid m}c(m)=g_q(m)+r_q(m),\qquad
\sup_{|I|\le L}\left|\sum_{m\in I}r_q(m)\right|
\ll_C L(\log M)^{-C},
\tag{7}
\]
其中
\[
g_1=0,\qquad
g_2(m)=4\mathbf1_{2\mid m},\qquad
g_q(m)=(4-2\mathbf1_{2\mid m})\mathbf1_{q\mid m}\quad(q\ge3).
\tag{8}
\]
式 (7) 的承重输入是已在 scratch/862 核对的 2023 年全区间 Möbius 等差进程短和；两条 \(\Lambda\) 通道的素数主项仅在 \(q=1,2\) 存活，\(q\ge3\) 的剩余素数幂整段质量为 \(O(\log^2M)\)。因此 (8) 保留了真实 \(c\) 中全部素数、倍素数、Möbius 及背景的联合均值，而没有把它们逐项当作互不相关的源。

设 \(\kappa_q\) 是 \(g_q\) 在全体整数上的均值。直接数奇偶格给
\[
\kappa_1=0,\qquad \kappa_2=2,\qquad
\kappa_q=
\begin{cases}
3/q,&q\ge3\text{ 奇},\\
2/q,&q\ge4\text{ 偶}.
\end{cases}
\tag{9}
\]
现证明对 \(q\le Q\) 的局部能量估计
\[
\mathcal C_q(L)
=\kappa_q^2\mathcal J_{\psi,v}
+O_{C,s,\psi}((\log M)^{-C})
+O_{s,\psi}\!\left(\frac1H+\frac{Hq}{M}\right).
\tag{10}
\]
首先将 (7) 中的 \(r_q\) 乘 \(\phi(m/M)/M\)。Abel 求和给任意长度不超过 \(L\) 的区间上的归一化部分和
\(O_C((L/M)\log^{-C}M)\)。固定外层物理点 \(m\)，把 \([m-L,m+L]\) 分成两段后再次 Abel 求和；因
\[
\sup_{|r|\le L}|J_H(r)|
+\operatorname{Var}_{[-L,L]}J_H
\ll_s H,\qquad HL/M\asymp1,
\tag{11}
\]
内层含 \(r_q\) 的和为 \(O_C(\log^{-C}M)\)。外层 \(F_q\) 与 \(M^{-1}g_q\phi\) 的 \(\ell^1\) 范数均为 \(O_\psi(1)\)：前者由 note 849 式 (16) 前的 \(\sum|a_m|\ll1\)，后者由 \(g_q=O(1)\)。展开二次型，就可用周期近似替换 \(F_q\)，费用为式 (10) 的第一个误差。

其次 \(g_q\) 的周期至多 \(2q\)，故任意区间内
\(\sum g_q=\kappa_q|I|+O(q)\)。同一 Abel 求和使周期误差的局部卷积至多 \(O(Hq/M)\)。在主项中将 \(\phi((m-r)/M)\) 换成 \(\phi(m/M)\)，其费用为 \(O(HL^2/M^2)=O(H^{-1})\)。Poisson 求和与整数求积给
\[
\frac1M\sum_{|r|\le L}J_H(r)
=\int_{-1/32}^{1/32}\widehat v(\xi)\,d\xi+O_s(H/M+H^{-1}),
\tag{12}
\]
而外层周期 Riemann 求和给
\(M^{-1}\sum_m g_q(m)\phi(m/M)^2
=\kappa_q\int_1^2\phi(t)^2dt+O_\psi(q/M)\)。
这证明 (10)，其误差对所有 \(q\le Q\) 一致。

对 \(q>Q\) 取绝对值。由于 \(|a_m|\ll_\psi\log M/M\)，\(|J_H|\ll_s H\)，非对角上 \(q\mid m-n\) 且 \(|m-n|\le L\)，故
\[
\sum_{q>Q}\left|\mathcal C_q(L)\big|_{m\ne n}\right|
\ll_{s,\psi}\frac{H\log^2M}{M^2}
\sum_{Q<q\le L}\left(\frac Mq+1\right)
\left(\frac Lq+1\right)
\ll_{s,\psi}\frac{\log^2M}{Q}
+\frac{H\log^3M}{M}.
\tag{13}
\]
对角过计由 \(\sum_{m\le2M}\tau(m)\ll M\log M\) 给
\[
\sum_{q>Q}\left|\mathcal C_q(L)\big|_{m=n}\right|
\ll_{s,\psi}\frac{H\log^3M}{M}.
\tag{14}
\]
取 \(B>A+3\)，再于 (10) 取 \(C>B+A+3\)，将 \(q\le Q\) 的误差及 (13)--(14) 相加，得到
\[
\sum_{q\ge1}\mu(q)\mathcal C_q(L)
=\mathcal J_{\psi,v}\sum_{q\ge1}\mu(q)\kappa_q^2
+O_{A,s,\psi}((\log M)^{-A}).
\tag{15}
\]
这里 \(Q/H+HQ^2/M\) 是固定负幂而可吸收，且 \(\sum_{q>Q}\kappa_q^2\ll Q^{-1}\)。

最后令 \(A_{\rm odd}=\sum_{r\text{ 奇}}\mu(r)/r^2
=\prod_{p\text{ 奇}}(1-p^{-2})=8/\pi^2\)。由 (9)，
\[
\begin{aligned}
\sum_{q\ge1}\mu(q)\kappa_q^2
&=-4
+9\sum_{\substack{q\ge3\\q\text{ 奇}}}\frac{\mu(q)}{q^2}
+4\sum_{\substack{q\ge4\\q\text{ 偶}}}\frac{\mu(q)}{q^2}\\
&=-4+9(A_{\rm odd}-1)-(A_{\rm odd}-1)
=\frac{64}{\pi^2}-12.
\end{aligned}\tag{16}
\]
式 (15)--(16) 证明 (3)。作为独立的代数核对，若按高素数、倍素数、周期背景分通道计数，互素近带的非零主常数分别合成 \(-16\)、\(+4\)、\(+64/\pi^2\)，与 (16) 一致。

note 849 式 (16) 给 \(\sum_m|a_m|^2\ll\log M/M\)。Cauchy--Schwarz 与 \(|J_H|\ll H\) 因而给近差绝对成本
\[
\sum_{|m-n|\le K_0}|a_ma_nJ_H(m-n)|
\ll\frac{H(K_0+1)\log M}{M}
\ll\frac{H^4}{M\log M}+\frac{H\log M}{M}=o(1).
\tag{17}
\]
这里 \(K_0/L\ll H^4/(M\log^2M)=o(1)\)，所以环带非空。互素限制只会减小绝对成本，故 (3) 推出 (4)。scratch/870 式 (2) 对**同一个** \(w_H,J_H,c(m)\) 给完整互素 Gram 为 \(O_A(\log^{-A}M)\)。以 (3) 从中扣去 \(|m-n|\le L\) 即得 (5)。最后 \(\mathcal J_{\psi,v}>0\)：在 \(|\xi|\le1/32\) 与 \(\operatorname{supp}v\subset[-4,4]\) 上，
\(\cos(2\pi t\xi)\ge\cos(\pi/4)>0\)，而 \(v\ge0\) 非零、\(\phi\ge0\) 非零。\(64/\pi^2<12\)，故 (4)--(5) 的符号严格。\(\square\)

## 固定物理 gcd 的完整分类

同一证明还给每个**固定**整数 \(g\ge1\) 的精确局部常数。把式 (3) 中 \((m,n)=1\) 改成 \((m,n)=g\)，则其右侧主项改为 \(C_g\mathcal J_{\psi,v}\)，其中
\[
\boxed{\quad
C_g=\sum_{k\ge1}\mu(k)\kappa_{gk}^2
=
\begin{cases}
64/\pi^2-12,&g=1,\\
3+6/\pi^2,&g=2,\\
64/(\pi^2g^2),&g\ge3\text{ 奇},\\
24/(\pi^2g^2),&g\ge4\text{ 偶}.
\end{cases}
\quad}\tag{18}
\]
误差对每个固定 \(g\) 仍为任意负对数幂；同一 gcd 层的远旁瓣常数是 \(-C_g\)。

证明只需在 \(g\mid m,n\) 上用
\(\mathbf1_{(m/g,n/g)=1}=\sum_{k\mid m/g,n/g}\mu(k)\)，再将 (10)--(15) 中的 \(q\) 换成 \(gk\)。对固定 \(g\)，大 \(q\) 尾仍由 (13)--(14) 支付。若 \(g\) 为奇数且至少为 \(3\)，奇、偶 \(k\) 分别给 \(9A_{\rm odd}/g^2\) 与 \(-A_{\rm odd}/g^2\)；若 \(g\ge4\) 为偶数，全部 \(gk\) 都使用 \(\kappa_{gk}=2/(gk)\)。\(g=2\) 时 \(k=1\) 的例外值 \(\kappa_2=2\) 给 \(4\)，其余 \(k\ge2\) 给 \(1/\zeta(2)-1\)。完整固定 gcd 层的带通和仍由 scratch/870 式 (10)--(12) 的同一 \(q=gk\) 反演为任意负对数幂，故远旁瓣取相反常数。直接求和核对
\(\sum_{g\ge1}C_g=0\)，与无 gcd 过滤的 scratch/901 零主项一致；这里的无限和只用于核对常数，不作有限 \(M\) 的极限交换。

## 边界

局部互素环带的负号来自真实联合系数在各物理除数进程上的周期均值；每个固定 gcd 层的远旁瓣支付本层的局部主项。式 (4) 排除把这个近环带单独要求为 \(O(H^4/M)\) 的必要门。式 (18) 是固定 \(g\) 的一阶分类，不给随 \(M\) 增长的全部小 gcd 层之固定幂误差，也不估计完整 moving-\(N\) 均方或全尺度局部 Weil 正性。
