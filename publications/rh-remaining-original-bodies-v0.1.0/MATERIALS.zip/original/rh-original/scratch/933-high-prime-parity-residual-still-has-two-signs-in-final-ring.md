# 大素因子奇偶余项在最终环带仍有常量级正负质量

日期：2026-10-02。依赖 [scratch/932](932-polylog-prime-parity-part-is-below-the-complete-two-arm-gate.md) 的 \(Q=(\log(2M))^2\) 分解、[note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的留存环带，以及 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 已核对的 Matomäki–Shao–Tao–Teräväinen 2023 Theorem 1.1(i)。本稿证明：删去目标精度内可支付的小素数奇偶模型后，真实余项在最终环带仍有同阶正负子质量。子块可能与其他乘子和两臂抵消；本文不估计完整 signed 和，也不证明 RH。尚待独立复核。

## 结论

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)，取
\[
Q=(\log(2M))^2,\quad
\epsilon_Q(u)=(-1)^{\#\{p\le Q:p\mid u\}},\quad
f_Q(u)=\mu(u)^2\epsilon_Q(u),\quad
\nu_Q(u)=\mu(u)-f_Q(u).
\tag{1}
\]
于是 \(\nu_Q(u)\in\{0,\pm2\}\)，且仅在平方自由、具有奇数个 \(p>Q\) 素因子的 \(u\) 上非零。

第一，对任意固定 \(0<c<C<\infty\)，一致于所有整数区间 \(I\subset[cM,CM]\) 且
\[
M^{2/3}\le |I|\le M^{4/5},
\tag{2}
\]
有
\[
\boxed{\quad
\sum_{\substack{u\in I\\u\ {\rm odd}}}\nu_Q(u)=o(|I|),
\qquad
\sum_{\substack{u\in I\\u\ {\rm odd}}}\nu_Q(u)^2
=\frac8{\pi^2}|I|+o(|I|).
\quad}\tag{3}
\]
因此
\[
\#\{u\in I:u\ {\rm odd},\ \nu_Q(u)=2\}
=
\#\{u\in I:u\ {\rm odd},\ \nu_Q(u)=-2\}
=\frac1{\pi^2}|I|+o(|I|).
\tag{4}
\]

第二，固定实函数 \(\psi\in C_c^3((1,2))\)、\(\psi\ge0\)，并取非退化闭区间 \(J\Subset(6/5,2)\) 使 \(\psi\ge c_\psi>0\) 于 \(J\)。令 \(\phi(x)=\psi(x)/x\)、\(\kappa=-4\log(3/2)\)，取固定非负偶 \(\eta\in C_c^\infty(\mathbb R)\)，支撑于 \(1/2\le|t|\le4\)，且 \(\eta\ge1\) 于 \(1\le|t|\le2\)。沿用 note 850 的 \(D,R,G_\natural,T_\natural\) 与完整核 \(G_{u,v}\)。写
\[
L=\left\lfloor\frac{M}{128H}\right\rfloor,\qquad
U_M=\{u\ {\rm odd}:3u/M\in J\},\qquad
U=\frac{M^{1+\delta}}H
\]
（\(\delta>0\) 固定）。在 note 850 式 (18) 的 **同一留存条件**
\[
u,v\in U_M,\quad u\ne v,\quad
(u,v)\le G_\natural,\quad
T_\natural<|3u-3v|\le 3L<U
\tag{5}
\]
下，限制到两边均为真实 cofactor \(3\) 的乘子项，按 \(\nu_Q(u)\nu_Q(v)=\pm4\) 分为 \(\mathcal P^\pm_{M,H}\)。则
\[
\boxed{\quad
\mathcal P^+_{M,H}\gg_{\psi,\eta,J}1,\qquad
\mathcal P^-_{M,H}\ll_{\psi,\eta,J}-1,\qquad
\mathcal P^+_{M,H}+\mathcal P^-_{M,H}=o_{\psi,\eta,J}(1).
\quad}\tag{6}
\]
下界对所述 \(H\) 一致。式 (6) 只属于完整两臂 Gram 的一个真实子项，不是完整留存 signed 和的下界。
事实上，令下文 (10) 的 \(c_Q>0\)、\(\rho=4/\pi^2\)，并置
\[
\mathscr I_{\psi,\eta,J}
=\frac{\kappa^2}{3}
\left(\int_J\phi(x)^2\,dx\right)
\left(\int_{-1/128}^{1/128}\int_{\mathbb R}
\eta(t)\cos(6\pi tz)\,dt\,dz\right)>0,
\tag{6a}
\]
则净和还有更精确的渐近
\[
\boxed{\quad
\mathcal P^+_{M,H}+\mathcal P^-_{M,H}
=\rho^2c_Q^2\mathscr I_{\psi,\eta,J}+o(c_Q^2)
\asymp_{\psi,\eta,J}(\log\log M)^{-4}.
\quad}\tag{6b}
\]

## 区间密度：平方自由与小素数模型

记 \(\rho=4/\pi^2\)。平方因子恒等式
\(\mu^2(n)=\sum_{a^2\mid n}\mu(a)\) 给出一致的奇数平方自由计数
\[
\sum_{\substack{n\in I\\n\ {\rm odd}}}\mu(n)^2
=\rho |I|+O(\sqrt M)
\tag{7}
\]
对 \(I\subset[cM,CM]\) 成立。常数来自
\(\tfrac12\prod_{p\ {\rm odd}}(1-p^{-2})=4/\pi^2\)。

沿用 scratch/932 的乘法函数 \(b_Q\)：在 \(p\le Q\) 处 \(b_Q(p^j)=2(-1)^j\)，在 \(p>Q\) 的正幂处为零，且 \(f_Q=\mu^2*b_Q\)。对固定 \(0<\sigma<1/2\) 记
\[
E_Q(\sigma)=\sum_{d\ge1}\frac{|b_Q(d)|}{d^{1-\sigma}}
\le\exp(C_\sigma Q^\sigma).
\tag{8}
\]
取 \(\sigma=2/5\)。因 \(Q=(\log(2M))^2\)，有 \(E_Q(\sigma)=M^{o(1)}\)。在 \(I\) 中按奇数 \(d\mid n\) 展开卷积，对每个 \(d\le CM\) 用 (7) 的缩放版，得到
\[
\sum_{\substack{n\in I\\n\ {\rm odd}}}f_Q(n)
=\rho |I|\sum_{d\ {\rm odd}}\frac{b_Q(d)}d
+O\!\left(
\sqrt M\sum_{d\le CM}\frac{|b_Q(d)|}{\sqrt d}
+|I|\sum_{d>CM}\frac{|b_Q(d)|}{d}\right).
\tag{9}
\]
由 \(d\le CM\) 时 \(d^{-1/2}\le(CM)^{1/2-\sigma}d^{\sigma-1}\) 与 (8)，误差为
\(O(M^{1-\sigma+o(1)}+|I|M^{-\sigma+o(1)})=o(|I|)\)，因为 \(|I|\ge M^{2/3}\)。主项系数是
\[
c_Q:=\sum_{d\ {\rm odd}}\frac{b_Q(d)}d
=\prod_{\substack{3\le p\le Q\\p\ {\rm prime}}}
\frac{1-p^{-1}}{1+p^{-1}}
\longrightarrow0
\tag{10}
\]
（Euler 的 \(\sum_p1/p=\infty\) 即足够）。故
\[
\sum_{n\in I,\ n\ {\rm odd}}f_Q(n)=o(|I|).
\tag{11}
\]

## 区间密度：高素数奇偶

置 \(g_Q(n)=\mu(n)f_Q(n)=\mu(n)\epsilon_Q(n)\)。定义乘法函数 \(h_Q\) 满足
\(h_Q(1)=1\)、\(h_Q(p^j)=2\) 于 \(p\le Q,j\ge1\)，其余正素数幂处为零。局部生成函数给
\[
(1-x)\left(1+2\sum_{j\ge1}x^j\right)=1+x
\quad(p\le Q),
\]
而 \(p>Q\) 处仍为 \(1-x\)。故
\[
g_Q=\mu*h_Q,\qquad
\sum_{d\ge1}\frac{|h_Q(d)|}{d^{1-\sigma}}=E_Q(\sigma)=M^{o(1)}.
\tag{12}
\]

所引 2023 年定理在固定模数 \(2\) 的奇数进程上给：对任意固定 \(A_0>0\)、\(\varepsilon>0\)，若 \(x^{5/8+\varepsilon}\le B\le x^{1-\varepsilon}\)，则所有长度 \(B\) 的相应短区间 Möbius 和均为
\(O_{A_0,\varepsilon}(B/\log^{A_0}x)\)。直接用于 (2) 给
\[
\sum_{n\in I,\ n\ {\rm odd}}\mu(n)=o(|I|).
\tag{13}
\]
对 \(g_Q=\mu*h_Q\) 再按 \(d\) 分层。取 \(Z=M^{1/20}\)。当 \(d\le Z\) 且 \(d\) 为奇数，缩放后区间的长度为 \(|I|/d\)，位置 \(x\asymp M/d\)。最紧的指数条件在 \(|I|=M^{2/3}\)、\(d=M^{1/20}\)，此时长度指数为 \(2/3-1/20=37/60\)，而位置的 \(5/8+1/100\) 次幂指数为
\[
(1-1/20)(5/8+1/100)=\frac{19}{20}\cdot\frac{127}{200}<\frac{37}{60}.
\tag{14}
\]
上限 \(|I|/d\le (M/d)^{1-1/100}\) 在 (2) 范围亦一致成立。故定理给小 \(d\) 总和
\[
\ll_{A_0}\frac{|I|}{\log^{A_0}M}
\sum_{d\le Z}\frac{|h_Q(d)|}d
\le\frac{|I|E_Q(0)}{\log^{A_0}M}=o(|I|),
\tag{15}
\]
其中 \(E_Q(0)\ll(\log M)^{C}\) 可由
\(\sum_{p\le Q}1/p\le\sum_{n\le Q}1/n\ll\log Q\) 得到，并取足够大的固定 \(A_0\)。

对 \(Z<d\le CM\) 用区间整数计数 \(\ll |I|/d+1\)。Rankin 界与 (12) 给
\[
\ll |I|Z^{-\sigma}E_Q(\sigma)
+(CM)^{1-\sigma}E_Q(\sigma)
\ll |I|M^{-1/50+o(1)}+M^{3/5+o(1)}
=o(|I|).
\tag{16}
\]
(15)--(16) 证明
\[
\sum_{n\in I,\ n\ {\rm odd}}g_Q(n)=o(|I|).
\tag{17}
\]

由 \(\nu_Q=\mu-f_Q\)、\(f_Q^2=\mu^2\)、\(\mu f_Q=g_Q\)，
\[
\nu_Q^2=2\mu^2-2g_Q.
\]
将 (7)、(11)、(13)、(17) 组合，得到 (3)。因为 \(\nu_Q\) 只取 \(0,\pm2\)，解两条线性计数式便得 (4)。

## 留存 cofactor-\(3\) 子块

对 \(u\in U_M\)，有 \(u/M\in J/3\Subset(2/5,2/3)\)：奇臂只允许 cofactor \(3\)，偶臂为空。完整两臂核在此扇区精确为
\[
\mathcal K_h(u)=\frac{\kappa}{M}\phi(3u/M)e(-3hu/M),
\quad
G_{u,v}=\frac{\kappa^2}{M^2}\phi(3u/M)\phi(3v/M)J_H(3(u-v)).
\tag{18}
\]
当 \(u,v\in U_M\)、\(|u-v|\le L\) 时，\(|h|\le4H\) 给
\(|2\pi h\,3(u-v)/M|\le3\pi/16<\pi/2\)。由 \(\eta\ge0\)、偶性及 \(\eta\ge1\) 于 \(1\le|t|\le2\)，
\[
G_{u,v}\gg_{\psi,\eta,J}\frac H{M^2}>0.
\tag{19}
\]

把 \(MJ/3\) 内的整数分成长度 \(L\) 的整格，舍弃最多两个边界格。整格数 \(\asymp_J M/L\)。因 \(L\asymp M/H\in[M^{3/4+o(1)},M^{4/5+o(1)}]\)，(4) 在每格给两种 \(\nu_Q\) 符号各 \((1/\pi^2+o(1))L\) 个。因此同格异指标的同号对、异号对均有 \(\gg L^2\) 个。将 \(\nu_Q(u)\nu_Q(v)=\pm4\)、(19) 以及格数相乘，两种绝对质量都为
\[
\gg \frac H{M^2}\cdot\frac ML\cdot L^2
\asymp \frac{HL}M\asymp1.
\tag{20}
\]

还需核对这些对处于 (5) 的最终环带。先删去 \(|3(u-v)|\le T_\natural\)。每个 \(u\) 至多有 \(O(T_\natural)\) 个这样的 \(v\)，故删除的绝对质量为
\[
O\!\left(\frac{H T_\natural}{M}\right)
=O\!\left(\frac{H^4}{M\log^4(2M)}\right)=o(1).
\tag{21}
\]
再删去 \((u,v)>G_\natural\)。按实际 \(g=(u,v)\) 计数：当 \(g\le L\) 时，活动 \(u=ag\) 有 \(O(M/g)\) 个，且 \(v\ne u,|u-v|\le L\) 对每个 \(u\) 有 \(O(L/g)\) 个；当 \(g>L\) 时无此类不同源对。因 \(|\nu_Q|\le2\)、\(|G_{u,v}|\ll H/M^2\)，删除成本
\[
\ll\frac H{M^2}\sum_{g>G_\natural}^{L}\frac{ML}{g^2}
\ll\frac1{G_\natural}=o(1).
\tag{22}
\]
\(u,v\in U_M\) 已保证 \(u,v>D\)。在 \(g\le G_\natural\) 后，note 850 式 (10) 又保证既约指标 \(a,b>R\)；而 \(3L<U=M^{1+\delta}/H\) 对充分大 \(M\) 成立。因此 (20)--(22) 证明 (6) 的前两个不等式。

最后证明净和为 \(o(1)\)。式 (3) 的第一式还对所有长度 \(B_0=\lceil M^{2/3}\rceil\) 的区间一致成立。任意长度至多 \(2L\) 的奇数源前缀可分为 \(O(L/B_0)\) 个这样的整块及一个不足 \(B_0=o(L)\) 的余段；由 \(|\nu_Q|\le2\)，其和为 \(o(L)\)，一致于前缀。固定 \(u\) 后，\(v\mapsto\phi(3v/M)J_H(3(u-v))\) 在 \(|u-v|\le L\) 上的上确界与总变差均为 \(O_{\psi,\eta}(H)\)：\(|J_H|\ll H\)、\(|J_H'|\ll H^2/M\)、\(LH/M\ll1\)。Abel 求和给内层带权 \(\nu_Q(v)\) 和为 \(o(HL)\)。外层至多有 \(O(M)\) 个 \(u\)、\(|\nu_Q(u)|\le2\)，故由 (18) 得完整近格子块的 signed 和为
\[
o\!\left(\frac{H L}{M}\right)=o(1).
\tag{23}
\]
(21)--(22) 的删项均为 \(o(1)\)，所以留存后的
\(\mathcal P^+_{M,H}+\mathcal P^-_{M,H}=o(1)\)，完成 (6)。证毕。

## 近格子块的对数级净主项及交叉补偿

式 (9)、(13) 的证明还给出比 \(o(|I|)\) 更精确的第一矩。令 \(|I|=B_0=\lceil M^{2/3}\rceil\)。对任意固定 \(A_0>0\)，一致于这些区间，
\[
\begin{aligned}
\sum_{u\in I,\ u\ {\rm odd}}f_Q(u)
&=\rho c_Q B_0
 +O\!\left(M^{3/5+o(1)}+B_0M^{-2/5+o(1)}\right),\\
\sum_{u\in I,\ u\ {\rm odd}}\mu(u)
&=O_{A_0}(B_0\log^{-A_0}M),\\
\sum_{u\in I,\ u\ {\rm odd}}\nu_Q(u)
&=-\rho c_Q B_0
 +O_{A_0}\!\left(B_0\log^{-A_0}M+M^{3/5+o(1)}\right).
\end{aligned}\tag{24}
\]
这里 \(c_Q\) 是 (10) 的 Euler 乘积。Mertens 素数乘积定理给
\[
c_Q=
\frac{\prod_{3\le p\le Q}(1-p^{-1})^2}
{\prod_{3\le p\le Q}(1-p^{-2})}
\sim\frac{\pi^2e^{-2\gamma}}{2(\log Q)^2},
\tag{25}
\]
故任意固定负对数幂及 \(M^{-1/15+o(1)}\) 都是 \(o(c_Q^2)\)。

为把 (24) 用到两点核，给出所需的离散分格论证。设 \(a,b\in\{f_Q,\nu_Q,\mu\}\)，对应每单位整数的奇数源密度分别为
\[
m_f=\rho c_Q,\qquad m_\nu=-\rho c_Q,\qquad m_\mu=0.
\tag{26}
\]
把 \(U_M\) 分成长 \(B_0\) 的整格；不足一格的边界总长 \(O(B_0)\)。由 (24)，每格的 \(a\)、\(b\) 和分别为
\((m_a+O(\varepsilon_M))B_0\)、\((m_b+O(\varepsilon_M))B_0\)，其中
\[
\varepsilon_M\ll_{A_0}\log^{-A_0}M+M^{-1/15+o(1)}
=o(c_Q^2).
\]
在 \(|u-v|\le L\) 的完整双和中，只要一端属于边界残格，其核加权绝对质量为 \(O(B_0/M)\)；跨越 \(|u-v|=L\) 的格对至多 \(O(M/B_0)\) 个，总质量为 \(O(HB_0/M)=O(B_0/L)\)。其他格对可把
\(\phi(3u/M)\phi(3v/M)J_H(3(u-v))\) 换成格中心值：由
\(|J_H|\ll H\)、\(|J_H'|\ll H^2/M\)、\(|\phi'|\ll1\)，归一化总误差为 \(O(B_0/L)\)。对各格的源和使用 (24)，全部格对的归一化绝对核质量为 \(O(1)\)，故相应 bilinear form 与把 \(a,b\) 分别换成常密度 \(m_a,m_b\) 的积分之差为
\[
O(\varepsilon_M+B_0/L)=o(c_Q^2),
\tag{27}
\]
因为 \(B_0/L\ll M^{-1/12+o(1)}\)。

常密度积分令 \(x=3u/M\)、\(z=H(v-u)/M\)。Poisson 或直接黎曼和给
\[
H^{-1}J_H(-3Mz/H)
\longrightarrow\int_{\mathbb R}\eta(t)\cos(6\pi tz)\,dt
\]
一致于 \(|z|\le1/128\)。边界区域只占 \(O(H^{-1})\) 的相对宽度，\(\phi(3v/M)=\phi(x)+O(H^{-1})\)。因此对上述三种序列任取 \(a,b\)，完整 \(|u-v|\le L\) 双和为
\[
m_am_b\,\mathscr I_{\psi,\eta,J}+o(c_Q^2).
\tag{28}
\]
对角的绝对质量 \(O(H/M)=o(c_Q^2)\)。式 (21)--(22) 对所有 \(|a|,|b|\le2\) 仍给
\(O(\log^{-4}M)=o(c_Q^2)\) 的删项，所以 (28) 也成立于 (5) 的最终环带。取 \(a=b=\nu_Q\) 即证 (6b)。更明确地，同一留存 cofactor-\(3\) 块满足
\[
\begin{array}{c|ccc}
 & f_Q&\nu_Q&\mu\\ \hline
f_Q&+\rho^2c_Q^2\mathscr I&-\rho^2c_Q^2\mathscr I&0\\
\nu_Q&-\rho^2c_Q^2\mathscr I&+\rho^2c_Q^2\mathscr I&0\\
\mu&0&0&0
\end{array}
+o(c_Q^2)
\tag{29}
\]
（各格均表示相应有序双和）。这展示了 \(\mu=f_Q+\nu_Q\) 在这个近格子块内的对数级交叉补偿。scratch/932 的**完整频带范数**替换 (16) 不能逐项替换 note 850 式 (18) 的有限位移环带；(29) 给出两者区别的定量实例。

完整频带还强制这项近格交叉由其补集补回。记
\[
\mathfrak B_{\rm all}(a,b)
=\sum_{\substack{D<u,v<2M/3\\u,v\ {\rm odd}}}
a(u)b(v)G_{u,v}
=\sum_h w_H(h)F_h^a\overline{F_h^b},
\tag{30}
\]
并令 \(\mathfrak B_{\rm ring}(a,b)\) 是 (5) 的 cofactor-\(3\) 留存子块，\(\mathfrak B_{\rm out}=\mathfrak B_{\rm all}-\mathfrak B_{\rm ring}\)。scratch/932 式 (3) 在 \(Q=(\log(2M))^2,\sigma=2/5\) 给
\(\|F^{f_Q}\|_{H,\eta}^2\ll M^{-1/25+o(1)}\)，因为 \(H^4/M=O(1)\)。[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (22) 与 [scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (6)--(7) 给 \(\|F^\mu\|_{H,\eta}=o(1)\)，故
\(\|F^{\nu_Q}\|_{H,\eta}=o(1)\)。Cauchy--Schwarz 因而给
\[
\mathfrak B_{\rm all}(f_Q,f_Q)=o(c_Q^2),
\qquad
\mathfrak B_{\rm all}(f_Q,\nu_Q)=o(c_Q^2).
\tag{31}
\]
结合 (29) 可得精确的补集主项
\[
\boxed{\quad
\mathfrak B_{\rm out}(f_Q,f_Q)
=-\rho^2c_Q^2\mathscr I_{\psi,\eta,J}+o(c_Q^2),
\qquad
\mathfrak B_{\rm out}(f_Q,\nu_Q)
=+\rho^2c_Q^2\mathscr I_{\psi,\eta,J}+o(c_Q^2).
\quad}\tag{32}
\]
补集同时含其他位移、乘子及两臂；(32) 不把补偿归因于其中任何一个单独部分。

## 边界

式 (6)、(6b)、(29)、(32) 证明：即使先支付至 \((\log M)^2\) 的全部小素数奇偶模型，剩余的真实大素因子奇偶项在 note 850 的共同因子和位移双截断后仍承载常量级正负质量，其近格子净值为 \(\asymp(\log\log M)^{-4}\)，并与小素数模型有等量负交叉。完整频带已迫使后者在补集中获得反向补偿；孤立近块不能判断完整目标。

note 850 式 (1)、(11)、(15) 的支付只用源系数的绝对上界，故把 \(\mu\) 换成 \(|\nu_Q|\le2\) 后，全部误差至多增大四倍。若 \(\mathfrak C[\nu_Q]\) 表示 \(\nu_Q\) 的完整不同源 Gram 协方差，便有
\[
\mathfrak C[\nu_Q]
=\sum_{\substack{D<u,v<2M/3,\ u,v\ {\rm odd},\ u\ne v\\
(u,v)\le G_\natural}}
\nu_Q(u)\nu_Q(v)G^{(T_\natural,M^{1+\delta}/H]}_{u,v}
+O_{\psi,\eta,\delta}(H^4/M).
\tag{33}
\]
其对角仍由 note 926 式 (8) 的绝对论证支付。于是 scratch/932 的完整频带范数归约与 (33) 一起给出一个合法的新算术目标：控制 **全部** \(\nu_Q\) 留存位移、乘子及两臂的联合 signed 和。式 (29) 表明不能把原 \(\mu\) 的留存和逐项换成 \(\nu_Q\)；必须使用 (33) 对新系数重新缩域。完整 moving-\(N\) signed covariance 仍未解决。
