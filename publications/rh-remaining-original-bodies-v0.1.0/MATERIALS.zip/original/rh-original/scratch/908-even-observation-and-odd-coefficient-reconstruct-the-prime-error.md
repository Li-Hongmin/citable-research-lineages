# 偶数观察与奇数联合系数逐点重建素数误差

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10) 的真实 \(c(n)\) 与 [scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 的 \(q=2\) 例外进程。本稿只作精确算术消元，补充 [scratch/905](905-odd-prime-dilates-give-an-exact-rank-two-cross-scale-frame.md) 的奇素数三线关系；它不给任何新的固定幂估计，亦不证明 RH。

## 逐点恒等式

记 \(\ell=\log2\)，对所有正整数按 note 849 的公式定义
\[
c(n)=2\mathbf1_{2\mid n}\bigl(\Lambda(n/2)-1\bigr)
-4\bigl(\Lambda(n)-1+\ell\mu(n)\bigr).
\tag{1}
\]
则每个 \(n>1\) 都满足
\[
\boxed{\quad
c(2n)+\mathbf1_{2\nmid n}\bigl(c(n)-4\bigr)
=2\bigl(1-\Lambda(n)\bigr).
\quad}\tag{2}
\]
若 \(n>1\) 为奇数，\(\Lambda(2n)=0\)、\(\mu(2n)=-\mu(n)\)，从而
\[
c(n)=4-4\Lambda(n)-4\ell\mu(n),\qquad
c(2n)=2+2\Lambda(n)+4\ell\mu(n);
\]
相加再减 \(4\) 即得 (2)。若 \(n\) 为偶数，\(\mu(2n)=0\)，且 \(\Lambda(2n)=\Lambda(n)\)：两者仅在 \(n\) 为 \(2\) 的幂时非零，并同为 \(\ell\)。于是 \(c(2n)=2-2\Lambda(n)\)，仍得 (2)。唯一例外 \(n=1\) 的左侧为 \(2-4\ell\)，右侧为 \(2\)。

## Dirichlet 与 Fourier 形式

当 \(\Re s>1\)，令 \(x=2^{-s}\)，并定义
\[
C(s)=\sum_{n\ge1}\frac{c(n)}{n^s},\qquad
E(s)=\sum_{\substack{n\ge1\\2\mid n}}\frac{c(n)-4}{n^s}.
\tag{3}
\]
由 \(\sum\Lambda(n)n^{-s}=-\zeta'(s)/\zeta(s)\)、\(\sum\mu(n)n^{-s}=1/\zeta(s)\)，以及
\[
\sum_{2\mid n}\frac{\Lambda(n)}{n^s}
=\frac{\ell x}{1-x},\qquad
\sum_{2\mid n}\frac{\mu(n)}{n^s}
=-\frac{x}{(1-x)\zeta(s)},
\tag{4}
\]
直接得到
\[
C(s)=(4-2x)\left(\frac{\zeta'}{\zeta}(s)+\zeta(s)\right)
-\frac{4\ell}{\zeta(s)},
\tag{5}
\]
\[
E(s)=-2x\left(\frac{\zeta'}{\zeta}(s)+\zeta(s)\right)
-\frac{4\ell x}{1-x}
+\frac{4\ell x}{(1-x)\zeta(s)}.
\tag{6}
\]
所以两个 \(1/\zeta\) 项**严格消去**，留下
\[
\boxed{\quad
C(s)+(2^s-1)E(s)
=2\frac{\zeta'}{\zeta}(s)+2\zeta(s)-4\ell .
\quad}\tag{7}
\]
式 (7) 的 \(n\ge2\) 系数正是 (2)；\(-4\ell\) 是 \(n=1\) 的例外修正。若 \(\rho\) 为 \(\zeta\) 的任意零点，右侧在 \(\rho\) 有留数 \(2\,\operatorname{ord}_{\rho}\zeta\)。因 \(2^s-1\) 在 \(\rho\) 正则，\(C,E\) 不可能同时在 \(\rho\) 正则。对简单零点且 \(1/2\le\Re\rho\le1\)，两留数 \(R_C,R_E\) 满足
\[
R_C+(2^\rho-1)R_E=2,\qquad
\bigl(|R_C|^2+|R_E|^2\bigr)^{1/2}\ge\frac{2}{\sqrt{10}},
\tag{8}
\]
因为 \(|2^\rho-1|\le3\)。这是无共同盲点的**代数**结论，不是两个通道的目标均方上界。

还可在实际观察频带中保留精确性。固定 \(\phi\in C_c^3((1,2))\)，令 \(X\) 足够大，定义
\[
\begin{aligned}
P_h(X)&=\frac1X\sum_n(\Lambda(n)-1)\phi(n/X)e(-hn/X),\\
D_h(X)&=\frac1X\sum_n c(2n)\phi(n/X)e(-hn/X),\\
O_h(X)&=\frac1X\sum_{n\ {\rm odd}}c(n)\phi(n/X)e(-hn/X).
\end{aligned}\tag{9}
\]
式 (2) 逐项给
\[
\boxed{\quad D_h(X)+O_h(X)+2P_h(X)
=\frac4X\sum_{n\ {\rm odd}}\phi(n/X)e(-hn/X).\quad}
\tag{10}
\]
右侧是模 \(2\) 的平滑格。若 \(X^{1/5}\le H\le X^{1/4}\)、\(H/2\le|h|\le4H\)，Poisson 求和及三次分部积分给右侧 \(O_\phi(H^{-3})\)。任何固定非负带通权下，其平方频带能量因而为
\[
O_\phi(H^{-5})=o(H^4/X).
\tag{11}
\]
式 (11) 只支付 (10) 的**指定线性组合**。单独估计 \(D_h\)、\(O_h\) 或素数误差包 \(P_h\) 到 \(H^4/X\)，仍要求未证明的真实算术相消；不能把 (7) 或 (11) 当作 moving-\(N\) covariance 门的证明。

## 决策边界

\(q=2\) 进程中的倍素数主项可与奇数联合系数精确消去 Möbius，但留下完整的 \(\Lambda-1\) 包。故继续只作奇偶或有限倍数的线性配对，不会自行产生所需固定幂；下一步须对实际联合包取得新的频率平均估计，或回到全尺度 Weil 形式寻找独立的正性机制。
