# 固定质量格外层扣款的精确极限（候选）

沿用已证明 note 856 的所有量词、记号和非负光滑共同轮廓。令
$L=\sum_{j\le N}j^{-1}$、$T=\sum_{N<r\le4N}r^{-1}\to\log4$，
$\ell=c/p^2$、$\alpha_p=\ell N\to c/16$、$\kappa=\int\varphi$。
已有 $Q(f,g)/\sqrt L\to-(T_\infty-3\kappa^2c/16)/\sqrt{T_\infty}$，
$T_\infty=\log4$。新候选是
\[
\frac{Q[g]}{L}\longrightarrow
1-\frac{3\kappa^2c}{16\log4}>0,
\tag{A}
\]
从而由二次配方得到**精确**变分扣款
\[
\boxed{\lim_{p\to\infty}
\left(Q[f]-\inf_{t\in\mathbb R}Q[f+tg]\right)
=\log4-\frac{3\kappa^2c}{16}.}
\tag{B}
\]

关键是约化普通核 $k(t)=e^{-t/2}/(1-e^{-2t})$ 在整数对数格上的精确恒等式：
对 $r>s\ge1$，
\[
\frac{k(\log(r/s))}{\sqrt{rs}}
=\frac12\left(\frac1{r-s}+\frac1{r+s}\right).
\tag{C}
\]
故对 $E_N=\{N<r\le4N\}$，
\[
\sum_{\substack{r,s\in E_N\\r\ne s}}
\frac{k(|\log(r/s)|)}{\sqrt{rs}}
=\sum_{N<r<s\le4N}\left(\frac1{s-r}+\frac1{s+r}\right)
=3N\log N+O(N).
\tag{D}
\]
第一和按 $d=s-r$ 为 $3N H_{3N-1}-(3N-1)$；第二和 $O(N)$。

共同槽轮廓的双积分与中心核的替换误差合计 $O(\ell^2N^2)=O_c(1)$：
相邻中心距 $\gg N^{-1}$、$\ell$ 是其足够小的固定比例；
$|k'(t)|\ll t^{-2}$ 且
$|\log(r/s)|\gg |r-s|/N$ 于 $E_N$。故每一异槽块的误差绝对值至多
$C\ell^2/[\sqrt{rs}|\log(r/s)|^2]
\ll C\ell^2N/|r-s|^2$，按差值求和为 $O(\ell^2N^2)$。
于是普通非对角形式
\[
Q_{\rm ord}[g]
=-\frac{\kappa^2\ell}{T}
\bigl(3N\log N+O(N)\bigr)+O_c(1)
=-\frac{3\kappa^2\alpha_p}{T}\log N+O_c(1).
\tag{E}
\]

单槽 Fourier 与光滑余项贡献 $\log(1/\ell)+O_\varphi(1)$；
外层内部只有 $k=2,3$ 的 prime 位移，总算子范数 $O(1)$；
极点自项 $6m_+m_-N=O_c(1)$。因此
$Q[g]=\log(1/\ell)-(3\kappa^2\alpha_p/T)\log N+O_{\varphi,c}(1)$。
$\log(1/\ell)/L\to1$、$\log N/L\to1$ 给 (A)；
note 856 式 (1) 给 $Q(f,g)^2/L\to
(\log4-3\kappa^2c/16)^2/\log4$，与 (A) 相除给 (B)。

须复核 (C) 精确系数、槽内核替换误差、$Q[g]$ 其余项的 $O(1)$，以及 (B) 的正分母。
