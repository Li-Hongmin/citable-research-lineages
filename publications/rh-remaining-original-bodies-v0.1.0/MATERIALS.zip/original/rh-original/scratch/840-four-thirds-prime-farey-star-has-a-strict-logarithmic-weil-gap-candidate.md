# \(4/3\) 的完整素数 Farey 星在真实 Weil 压缩中仍有严格对数谱隙（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确 Farey 算术图与有界 Archimedean 修正，以及 [scratch 839](839-farey-boundary-negative-row-potential-is-paid-on-the-subroot2-compression-candidate.md) 的 \(4/3\) 跨区列。本文检验该列与**全部**素数叶的真实主压缩；尚待异源复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，置 \(k=p^2\)、\(L=\log k\)、\(x_0=4/3\)，并令
\[
\mathcal P_p=\{q\text{ 素数}:5\le q<(p-1)/4\},
\quad y_q=4q/3,
\quad V_p=\operatorname{span}\bigl(\{w_{x_0}\}\cup\{w_{y_q}:q\in\mathcal P_p\}\bigr)
\subset W_p.
\tag{1}
\]
则真实旧奇 Weil 算子在这整个素数星上的最小 Rayleigh 值满足
\[
\boxed{\quad
\lambda_{\min}(P_{V_p}A_{p^2,-}P_{V_p})
=\left(1-\frac1{2\sqrt2}\right)L+O(1)>0.
\quad}
\tag{2}
\]
所以 scratch 839 的 \((1/8+o(1))L\) Schur 反馈是真实的对数代价，却不足以让单代素数星产生负方向。此结论不约束星外子孙、整个 \(W_p\) 或无限维补空间。

## 精确星形算术矩阵

每个 \(y_q\in\mathcal F_p\)，因为 \((4q,3)=1\)、\(4q<p\)、\(4q>3\)。且 \(y_q/x_0=q\)，所以 note 791 式 (4) 给 \(C_p(x_0,y_q)=c_q:=\log q/\sqrt q\)：另外两个参数 \(x_0/y_q=1/q\) 与 \(x_0y_q=16q/9\) 都不是正整数素数幂。

若 \(q\ne r\) 是 \(\mathcal P_p\) 中的素数，\(y_q/y_r=q/r\) 与倒数都不是整数，而 \(y_qy_r=16qr/9\) 因 \(3\nmid qr\) 也不是整数；自环 \(x_0^2=16/9\)、\(y_q^2=16q^2/9\) 同样不是整数。因此在 (1) 的正交基中，算术矩阵**精确**为
\[
P_{V_p}C_pP_{V_p}
=\begin{pmatrix}0&c^*\\c&0\end{pmatrix},
\qquad c=(c_q)_{q\in\mathcal P_p}.
\tag{3}
\]
其非零特征值恰为 \(\pm\|c\|\)。令 \(\theta(x)=\sum_{q\le x,\,q\text{ 素数}}\log q\)，\(\omega(x)=(\log x)^{3/5}(\log\log x)^{-1/5}\)（在充分大的 \(x\) 上）。经典零自由区形式的素数定理给 \(\theta(x)=x+O(xe^{-b\omega(x)})\)；对 \(\int(\log t)/t\,d\theta(t)\) 分部求和时，误差积分 \(\int_3^\infty(1+\log t)e^{-b\omega(t)}dt/t\) 收敛。因此
\[
\|c\|^2
=\sum_{q\in\mathcal P_p}\frac{(\log q)^2}{q}
=\frac12\log^2(p/4)+O(1)
=\frac18L^2+O(L),
\quad
\|c\|=\frac{L}{2\sqrt2}+O(1).
\tag{4}
\]
note 791 式 (6) 在全 \(W_p\) 上的恒等式为
\(A_{p^2,-}=D_kI-C_p+E_p\)，其中 \(D_k=L+1-\gamma_E-\log\pi\)、\(\|E_p\|=O(1)\)。压缩到 \(V_p\) 并由 Weyl 的有界扰动不等式与 (3)--(4) 即得
\[
\lambda_{\min}(P_{V_p}A_{p^2,-}P_{V_p})
=D_k-\|c\|+O(1)
=\left(1-\frac1{2\sqrt2}\right)L+O(1),
\]
证明 (2)。\(\square\)

## 边界

该素数星保留全部 \(q<(p-1)/4\) 的第一代叶，仍只占真实 Farey 图的一部分。note 791 的双素数、三素数及更深因子层可能继续降低能量；(2) 没有证明整个 \(W_p\) 正性，也没有证明全尺度局部 Weil 正性或 RH。
