# Candidate: exact prime-descendant response for fixed near-diagonal Farey roots

Let p tend to infinity through odd primes, P=p-1, H=log p, Q=floor(P/H), A=floor(P^theta), S=floor(P/H^alpha), with fixed 0<theta<1 and alpha>1. Let X={x_i=a_i/b_i:1<x_i<2}, i=1,...,m, be any fixed finite set of distinct reduced rationals. For each i include, for all sufficiently large primes q, the two child families

Y_i^+={q x_i=a_i q/b_i: A<a_i q<=S},
Y_i^-={q/x_i=b_i q/a_i: A<b_i q<=S}.

Let Y be the union. For sufficiently large p the children are distinct reduced Farey slots, all lie in the remaining high-slope middle band U={A<num<=S, slope>floor(H/2)}, and X lies in the near-diagonal block N. Let V_p=span{psi_x:x in X union Y}. Claim:

lambda_min(P_V A_{p^2,-} P_V)=(2-sqrt(1-theta^2)+o(1))H.

Moreover, if A_YY is the true child principal block and A_XY the true mixed block, then its true Schur response is

A_XY A_YY^{-1} A_YX=((1-theta^2)/2+o(1))H I_X,

and the root Schur remainder is ((3+theta^2)/2+o(1))H I_X. These are asymptotic operator equalities on the fixed m-dimensional root space. They do not assert anything about eliminating all of U.

Proof for adversarial review:

1. All q in the child ranges tend to infinity and avoid the finitely many prime factors of a_i b_i, so numerators are respectively a_i q and b_i q. A child from one root/arm can equal a child from another root/arm only if q/q' equals a fixed rational. For sufficiently large primes q,q', this forces q=q' and the same root and arm: same arms then require x_i=x_j, mixed arms require x_i x_j=1, impossible since all roots are >1. Thus Y is a disjoint coordinate family.

2. In the C^-=C_parallel-C_cross arithmetic matrix of note 807, a root x_i connects to its own qx_i child by +c_q and to its own q/x_i child by -c_q, where c_q=(log q)/sqrt q. For sufficiently large q there are no root-to-other-root's-prime-child edges: a putative integer prime-power ratio or product would be q times a fixed rational, which can be a prime power only if the fixed rational is 1. The other possibilities force x_i=x_j or x_i x_j=1 as above. Hence the root-child arithmetic block W has orthogonal rows and

WW^*=diag_i(sum_{A/a_i<q<=S/a_i} (log q)^2/q + sum_{A/b_i<q<=S/b_i} (log q)^2/q)
=(1-theta^2+o(1))H^2 I_X.

Here sums run over primes; the asymptotic follows by PNT/partial summation and log S=H-alpha log H+o(H), log A=theta H+o(H).

3. The child-child arithmetic block has O_X(1) norm. For q!=q', a ratio of two children retains q/q' with q' in the denominator after reducing the fixed rational factors, so cannot be an integer prime power; a product retains two distinct large prime factors q q', so cannot be a prime power. For q=q', same-arm child ratios are x_i/x_j in (1/2,2) and cannot be integer prime powers. Mixed-arm ratios are x_i x_j in (1,4), so only 2 or 3 can occur. Mixed-arm products are q^2 x_i/x_j; for sufficiently large q this is a prime power only if i=j, in which case the weight is c_{q^2}=(log q)/q. Thus the child block is a direct sum over q of matrices of bounded dimension and entries bounded by c_2+c_3+o(1), giving O_X(1). The root-root arithmetic block is O_X(1) too.

4. All slots lie in I_Q (numerator<=S<Q), where the same-arm nonarithmetic kernel and polar term have O(H^-1) norms by note 809. The positive opposite-arm Archimedean matrix B from note 807 has trace at most O_X(Delta * |X union Y|)=o(1), since every slot has slope bounded below by min_i x_i>1, M_Delta(2log x)=O_X(Delta), Delta~1/(2p^2), and |Y|<=O_X(S). Therefore on V_p the true Weil matrix is 2H I-C^-+O_X(1) in operator norm, uniformly in p.

5. In root+child order the leading matrix is 2H I - [0 W; W^* 0]. Its lowest eigenvalue is 2H-||W||. All omitted terms have norm O_X(1), so the first claim follows from step 2. Also A_YY=2H I+O_X(1), hence A_YY^{-1}=(2H)^{-1}I+O_X(H^-2), and A_XY=-W+O_X(1). Multiplying gives the Schur response ((1-theta^2)/2+o(1))H I_X and the stated root remainder.

Please review for false arithmetic-collision claims, an overlooked O(H) archimedean term, and the inverse expansion. Read only directly cited sources; do not edit files or run computations. An invalid theorem is an acceptable verdict.
