# 完整两臂真实源 Gram 的每个物理位移带均有次指数 signed 抵消

日期：2026-10-02。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整两臂核、格距证明和小既约比例计数，[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 短和，以及 [scratch/951](951-the-entire-coprime-two-arm-gram-has-subexponential-signed-cancellation.md) 的增长互素模数引理与分壳变差法。这里把后者从源 $\gcd(u,v)=1$ 扩到**全部真实 gcd 层**，并对任意一个物理位移带一致估计。证明尚待异源复核，故留在 `scratch/`；结果没有固定幂节省，也不证明 RH。

## 定理

沿用 note 850 的 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D=\lfloor M/(32H)\rfloor$、固定 $\psi\in C_c^3((1,2))$、$\phi=\psi/x$、$W(k)$ 与完整奇、偶两臂源核 $\mathcal K_h(u)$。令固定 $\eta\in C_c^\infty(\mathbb R)$ 非负、偶、支撑于 $1/2\le|t|\le4$，并设 $J_H(r)=\sum_h\eta(h/H)e(-hr/M)$。对可任意随 $M,H$ 变化的 $0\le T<U\le M$，在 note 850 的完整不同源 Gram 乘子展开中只保留 $T<|ku-\ell v|\le U$，记其真实 signed 和为
\[
 \mathfrak C_{\rm odd}^{(T,U]}
 =\sum_{\substack{D<u,v<2M/3,\ u,v\ {m odd}\\u\ne v}}
 \frac{\mu(u)\mu(v)}{M^2}
 \sum_{\substack{k,\ell<64H\ \mathrm{active}\\T<|ku-\ell v|\le U}}
 W(k)\overline{W(\ell)}\phi(ku/M)
 \overline{\phi(\ell v/M)}J_H(ku-\ell v).
 \tag{1}
\]
存在固定 $c>0$，使
\[
 \boxed{\quad
 \sup_{0\le T<U\le M}|\mathfrak C_{\rm odd}^{(T,U]}|
 \ll_{\psi,\eta}e^{-cV_M},\qquad
 V_M=(\log M/\log\log M)^{1/3}.
 \quad}\tag{2}
\]
这里包括全部活动乘子、两物理臂、所有实际 gcd 层及 $k=\ell$ 项。$T=0,U=M$ 覆盖所有非零物理位移；精确碰撞 $ku=\ell v$ 不在这个开端点带内，但它们都属下文式 (5) 支付的小既约比例对。因此同一界也适用于把零位移并入任意 $(0,U]$ 带的版本，取 $U=M$ 就恢复 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (C) 的完整协方差次指数界。(2) 额外说明该等级的抵消在**每个任意选取的非零物理位移带**内单独成立。对 $H\asymp M^{1/5}$，目标仍为 $H^4/M\asymp M^{-1/5}$，式 (2) 不支付它。

## 1. 绝对支付大 gcd 与小既约比例

在 note 850 的格距证明中，$R$ 可取任意满足 $64H<R=o(M/H)$ 的量；同一逐 $g,k,\ell$ 计数给
\[
 \sum_{\substack{D<u,v<2M/3,\ u\ne v\\\max(a,b)>R,\ (u,v)>G}}
 |G_{u,v}|
 \ll_{\psi,\eta}\frac{\log^4(2M)}G
       +\frac{H^2\log^4(2M)}M,
 \quad a=\frac u{(u,v)},\ b=\frac v{(u,v)}.
 \tag{3}
\]
式 (3) 的证明只对每个真实乘子项取绝对值，并由
$|J_H(r)|\ll H(1+H|r|/M)^{-2}$、活动 $a$ 的 $O(M/(kg))$ 个格点及 $b$ 的格距和 $O(1+M/(Hg\ell))$ 得到；故同一界适用于 (1) 中的任意位移子集。

取
\[
 R=\lfloor M^{1/3}\rfloor,\qquad
 G=\lceil e^{V_M}\rceil.                              \tag{4}
\]
在本 $H$ 范围内，$R>64H$，$R=o(M/H)$，$G=M^{o(1)}$。对 $\max(a,b)\le R$，note 850 的小既约比例计数给全乘子绝对质量
\[
 \ll_{\psi,\eta}\frac{H\log^2(2M)R}{D}
 \ll\frac{H^2M^{1/3}\log^2(2M)}M
 \ll M^{-1/6}\log^2(2M).                              \tag{5}
\]
式 (3)–(5) 均小于 $e^{-c_1V_M}$，适当固定 $c_1>0$。剩余对的真实 $g=(u,v)\le G$；因 $u,v>D$，其既约 $a,b>D/G\ge M^{3/4-o(1)}>R$，从而 $a=b$ 不可能，且没有精确物理碰撞 $ka=\ell b$（互素性将强迫 $a\mid\ell,b\mid k$，与 $\max(a,b)>R>64H$ 矛盾）。

## 2. 缩放后的固定 gcd 层

只需考虑奇数平方自由 $g\le G$。置 $X=M/g$。写 $u=ga,v=gb$，其中 $a,b$ 奇、$(a,b)=1$、$(ab,g)=1$。真实乘法性给
\[
 \mu(ga)\mu(gb)=\mu(g)^2\mu(a)\mu(b)
 \mathbf1_{(ab,g)=1}.
 \tag{6}
\]
又 $J_H(g(ka-\ell b))=\sum_h\eta(h/H)e(-h(ka-\ell b)/X)$，而 $M^{-2}=g^{-2}X^{-2}$。因此第 $g$ 层是 $g^{-2}$ 倍的尺度 $X$ 互素源双和，窗口为 $D/g<a,b<2X/3$，位移带为
\[
 T/g<|ka-\ell b|\le U/g.                             \tag{7}
\]
所有非零乘子仍有 $k,\ell<64H$，因为原源 $ga,gb>D$。

用 $\mathbf1_{(a,b)=1}=\sum_{d\mid a,b}\mu(d)$，并设 $Z=\lceil e^{V_M}\rceil$。对 $d\le Z$ 且 $(d,g)=1$，写 $a=dA,b=dB$。式 (6) 的源系数在该项内为
\[
 \mu(dA)\mu(dB)
 =\mu(d)^2\mu(A)\mu(B)
 \mathbf1_{(A,d)=1}\mathbf1_{(B,d)=1},
 \tag{8}
\]
加上原条件 $(AB,g)=1$，故固定 $A$ 后的 $B$ 恰受 $(B,2dg)=1$ 限制。$(d,g)>1$ 的项本已为零。此处 $d,g\le e^{V_M}+1$，所以
\[
 q=2dg\le 2e^{2V_M+o(1)}\le M^{1/4}.
 \tag{9}
\]

固定 $g,d,k,\ell,A$，令 $X_B=X/(\ell d)$、$B_0=kA/\ell$。活动物理窗口使 $B$ 位于 $[X_B,2X_B]$，再与源窗口、位移带 (7) 相交。因为 $g,d\le e^{V_M}+1$、$\ell<64H$，
\[
 M^{7/10}\le X_B\le M                              \tag{10}
\]
对所有充分大的 $M$ 一致成立。[scratch/951](951-the-entire-coprime-two-arm-gram-has-subexponential-signed-cancellation.md) 式 (3) 的增长模数短和引理因而适用于每个子区间：取 $\theta=41/64$，有
\[
 \left|\sum_{B\in I}\mu(B)\mathbf1_{(B,2dg)=1}\right|
 \ll |I|e^{-c_0V_M}+X_B^\theta
 \quad(I\subset[X_B,2X_B]).                            \tag{11}
\]
此引理直接由真实 $\mu$ 的 Ramachandra 短和和有限 Euler 因子恒等式证明，不用模 $q$ 的 Dirichlet 特征；其常数对 (9)–(10) 的全部 $g,d,k,\ell$ 一致。

Poisson 求和在实际活动窗口给
\[
 |J_H(gd(kA-\ell B))|
 \ll_{C,\psi,\eta}H(1+H|B-B_0|/X_B)^{-C},
\quad
 \left|\frac d{dB}J_H(gd(kA-\ell B))\right|
 \ll_{C,\psi,\eta}\frac{H^2}{X_B}(1+H|B-B_0|/X_B)^{-C}.
 \tag{12}
\]
非零 Poisson 别名由 $ka d,\ell b d\in X\operatorname{supp}\phi$ 与物理差 $< (1-\sigma_\psi)X$ 排除；(12) 只在真实活动项上使用。按 $|B-B_0|\asymp2^jX_B/H$ 分壳，位移带和源窗口与每个壳相交后至多有固定个区间。用 (11) 对每个前缀分部求和，$\phi(B/X_B)J_H$ 在第 $j$ 壳的上确界及总变差分别为 $O_C(H2^{-jC})$ 和 $O_C(H2^{-j(C-1)})$。取固定 $C>4$ 并求和，得到与带端点一致的
\[
 \left|\sum_{\substack{B\text{ active},\ (B,2dg)=1\\
                T<gd|kA-\ell B|\le U}}
 \mu(B)\overline{\phi(\ell dB/X)}J_H(gd(kA-\ell B))\right|
 \ll H\left(\frac{X_B}{H}e^{-c_0V_M}+X_B^\theta\right).
 \tag{13}
\]

固定 $g,d,k$ 的活动 $A$ 有 $O(X/(kd))$ 个；这里 $X/(kd)\gg M^{3/4-o(1)}$，故无需额外的 $+1$。记
\[
 A_H=\sum_{k<64H}\frac{|W(k)|}k\ll\log^2(2M),
\qquad B_{\theta,H}=\sum_{\ell<64H}\frac{|W(\ell)|}{\ell^\theta}
 \ll H^{1-\theta}\log(2M).
\]
由 (13) 先对 $A$、再对 $k,\ell$ 求和，第 $(g,d)$ 项在**尚未乘** $g^{-2}$ 前至多为
\[
 \ll \frac{A_H^2}{d^2}e^{-c_0V_M}
 +\frac{H X^{\theta-1}A_HB_{\theta,H}}{d^{1+\theta}}.
 \tag{14}
\]
乘 $g^{-2}$ 并对 $g,d\le e^{V_M}+1$ 求和，利用 $X=M/g$，得到
\[
 \ll \log^4(2M)e^{-c_0V_M}
 +H^{2-\theta}M^{\theta-1}\log^3(2M)
 \ll e^{-c_2V_M}.
 \tag{15}
\]
最后一步用 $H\ll M^{1/4}$、$\theta=41/64$，使多项式项至多 $M^{-5/256}\log^3M$；两重 $g,d$ 求和分别由 $\sum g^{-2}d^{-2}$ 与 $\sum g^{-1-\theta}d^{-1-\theta}$ 支付。

## 3. Möbius 反演的大公共除数尾

对每个 $g\le G$，$d>Z$ 的反演项逐项取绝对值，并沿 note 850 的物理格距保留 $\ell$。固定 $d,k,\ell,A$ 的活动 $A$ 有 $O(X/(kd))$ 个，而 $B$ 的核格距和为 $O(1+X/(H\ell d))$。因此在乘 $g^{-2}$ 前，所有 $d>Z$ 的质量至多
\[
 \ll \sum_{Z<d\ll X}
 \left(\frac{A_H^2}{d^2}
 +\frac{H A_HB_H}{X d}\right),
 \qquad B_H=\sum_{\ell<64H}|W(\ell)|\ll H\log(2M).
 \tag{16}
\]
这里无需 $d=(a,b)$，也无需在三角上保留任何 coprimality；带限制只会减少非负绝对和。对 $g\le G$ 再乘 $g^{-2}$ 并求和，由 $X=M/g$ 得
\[
 \ll\frac{\log^4(2M)}Z
 +\frac{H^2\log^4(2M)}M\sum_{g\le G}\frac1g
 \ll e^{-c_3V_M}.
 \tag{17}
\]
第二项是 $M^{-1/2+o(1)}$。合并 (3)、(5)、(15)、(17) 即得 (2)。$\square$

## 回顾与边界

式 (2) 不靠不同物理位移带之间的抵消，也没有从源 $g=1$ 层外推全层：额外条件 $(a b,g)=1$ 在每一层成为真实互素模数 $2dg$，由 (9)–(11) 一致支付。它排除了“完整次指数界只是不同位移带偶然相消”的解释。固定幂门仍要求在 $H\asymp M^{1/5}$ 把 $e^{-cV_M}$ 强化为 $M^{-1/5+o(1)}$，并且必须针对真实 $\mu$ 的二点结构；本定理不提供该强化。
