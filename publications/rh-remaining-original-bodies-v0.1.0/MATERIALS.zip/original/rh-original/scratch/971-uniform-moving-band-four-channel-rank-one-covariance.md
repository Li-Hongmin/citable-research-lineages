# 真实四通道在任意移动位移带上的统一秩一协方差

日期：2026-10-03。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实两端点系数和核、[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4) 的 Ramachandra 短和，以及 [scratch 962](962-true-two-endpoint-near-gram-has-a-double-ramachandra-collar.md) 的物理分块方法。相较 [scratch 901](901-local-middle-distance-four-channel-covariance-has-rank-one-main-term.md) 的固定近带与 [scratch 902](902-local-bandpass-rank-one-main-term-is-repaid-by-each-channel-sidelobe.md) 的固定两段，本命题对**所有可随参数移动的位移带**同时给出四通道矩阵主项。相较 [scratch 970](970-every-physical-displacement-band-has-squared-ramachandra-saving.md)，它还识别各通道的带内主项。证明尚未异源复核，留在 `scratch/`；这不是固定幂算术门或 RH 的证明。

## 命题

固定实值 $\psi\in C_c^3((1,2))$ 与非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，其中 $\operatorname{supp}\eta\subset\{1/2\le |t|\le4\}$。令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$W=M/H$，$V_M=(\log M/\log\log M)^{1/3}$，$\Phi(x)=\psi(x)/x$，以及

\[
K_H(k)=\sum_{h\in\mathbb Z}\eta(h/H)e(-hk/M).
\]

在 $M<m<2M$ 内置

\[
\begin{array}{ll}
f_-(m)=-4\mathbf1_{m=p}\log p,&
f_+(m)=2\mathbf1_{m=2p}\log p,\\
f_0(m)=4-2\mathbf1_{2\mid m},&
f_\mu(m)=-4(\log2)\mu(m),
\end{array}
\qquad
a_m^i=\frac{f_i(m)}M\Phi(m/M),
\quad \kappa=(-4,1,3,0),
\tag{1}
\]

其中 $p$ 表示素数，区间外所有 $a_m^i$ 置零。取固定 $7/12<\vartheta<\rho<3/5$，令 $B=\lceil M^\rho\rceil$。存在 $c_0>0$，使对每一对 $i,j\in\{-,+,0,\mu\}$ 及**所有** $0\le T<U\le M$，一致有

\[
\boxed{\quad
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
=\kappa_i\kappa_j I_\Phi
\int_{T/W<|v|\le U/W}\widehat\eta(v)\,dv
+O_{\psi,\eta,\vartheta,\rho}\!\left(e^{-c_0V_M}+\frac{B}{W}+\frac1H\right),
\quad}
\tag{2}
\]

其中 $I_\Phi=\int_1^2\Phi(x)^2dx$。所以这些协方差作为位移带的有符号测度，在区间差异范数下以统一误差趋于秩一测度 $I_\Phi\kappa\kappa^{\mathsf T}\widehat\eta(v)\,dv$。若 $i=j=\mu$，式 (2) 的 $e^{-c_0V_M}$ 可换成 $e^{-2c_0V_M}$；若其中恰有一个指标为 $\mu$，一般仍只有单次指数。

对薄带还保留其宽度。任取固定 $C>0$，令 $L=U-T\le CW$。直接在两个位移区间上作一次 Abel 求和，得到更精细的统一式

\[
\boxed{\quad
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
=\kappa_i\kappa_j I_\Phi
\int_{T/W<|v|\le U/W}\widehat\eta(v)\,dv
+O_C\!\left(
\frac{HL}{M}e^{-c_0V_M}
+\frac{HM^\vartheta}{M}+\frac{L+H}{M}\right).
\quad}
\tag{2a}
\]

特别对任意固定 $C>0$，所有移动带 $L\le CH^3$ 上均有

\[
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
=\kappa_i\kappa_j I_\Phi
\int_{T/W<|v|\le U/W}\widehat\eta(v)\,dv
+o(H^4/M),
\tag{2b}
\]

误差同时对全部带端点及四通道指标一致。式 (2b) 在**目标量级**识别单条薄带各通道的密度协方差；它没有支付约 $M/H$ 宽的全部物理主带。

更具体地，若固定 $1/5\le\alpha<1/4$、$H\asymp M^\alpha$、$T/W\to t\ge0$，并取 $U-T=\lambda H^3+O(1)$、$\lambda>0$ 固定，则 $H^4/M\to0$，由 (2b) 与 $\widehat\eta$ 连续性得到目标尺度上的确切极限

\[
\frac{M}{H^4}
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
\longrightarrow 2\lambda\kappa_i\kappa_j I_\Phi\widehat\eta(t).
\tag{2c}
\]

还可直接在密度的正交补上保留双端节省。若 $u,v\in\mathbb R^4$ 满足 $u\cdot\kappa=v\cdot\kappa=0$，记 $a_m^u=\sum_i u_i a_m^i$，则对所有移动带一致有

\[
\boxed{\quad
\left|\sum_{T<|m-n|\le U}a_m^u a_n^vK_H(m-n)\right|
\ll \|u\|\,\|v\|\left(e^{-2c_0V_M}+\frac BW\right).
\quad}
\tag{2d}
\]

因此四通道协方差矩阵压到三维空间 $\kappa^\perp$ 后，在**全部**移动位移带上有平方 Ramachandra 节省；完整真实系数是其中一个方向，高次素数幂另由上段支付。

在同样薄带上把 (2b) 的十六个有序通道相加，主项因 $\sum_i\kappa_i=0$ 消失。完整系数与四通道之差仅为高次素数幂，其加权 $\ell^1$ 质量是 $O(M^{-1/2}\log M)$；用 $|K_H|\ll H$、其余通道的 $\ell^1$ 质量 $O(1)$，所补 Gram 为 $O(HM^{-1/2}\log M)=o(H^4/M)$。故完整真实系数在每条 $L\le CH^3$ 的移动带上也为 $o(H^4/M)$；scratch 970 证明了更宽的次指数薄带版本。

式 (2) 的新增内容是**每个**移动带上的四通道主项及其统一误差。完整真实系数的平方节省已由 scratch 970 给出；不能只把 (2) 的四个误差相加就声称得到平方指数。

## 证明

**短块密度。** note 851 式 (4) 对所有长度 $\ell\le M$、起点 $x\asymp M$ 给 $\Lambda-1$ 与 $\mu$ 的短和 $O(\ell e^{-cV_M}+M^\vartheta)$。高次素数幂在整个 $(M,2M)$ 的 $\Lambda$ 质量为 $O(\sqrt M\log M)$；偶素数臂换元 $m=2n$ 后同样成立。缩小 $c>0$ 后，每个长度至多 $B$ 的块的所有前缀均满足

\[
\left|\sum_{m\in I}(f_i(m)-\kappa_i)\right|
\ll |I|e^{-cV_M}+M^\vartheta+\sqrt M\log M
\ll B e^{-c_0V_M}.
\tag{4}
\]

同一输入实际上对任意整数区间 $I\subset(M,2M)$ 给出

\[
\left|\sum_{m\in I}(f_i(m)-\kappa_i)\right|
\ll |I|e^{-c_0V_M}+M^\vartheta;
\tag{4a}
\]

素数幂总质量 $O(\sqrt M\log M)$ 已被 $M^\vartheta$ 吸收。

对 $i=0$，左侧实际为 $O(1)$。最后一步使用 $\rho>\vartheta>7/12>1/2$。对 $\Phi(m/M)$ 离散分部求和，若 $C_q$ 是长度至多 $B$ 的连续块、$x_q$ 是其中心、

\[
D_q^i=\sum_{m\in C_q}f_i(m)\Phi(m/M),
\qquad S_q=\sum_{m\in C_q}\Phi(m/M),
\]

则一致有

\[
D_q^i=\kappa_i S_q+E_q^i,
\qquad |E_q^i|\ll B\epsilon_M,
\qquad \epsilon_M=e^{-c_0V_M}.
\tag{5}
\]

同一短和与 $\Lambda\ge0$ 还给每个整数区间 $I\subset(M,2M)$ 的局部绝对质量

\[
\sum_{m\in I}|f_i(m)\Phi(m/M)|\ll |I|+M^\vartheta,
\qquad
\sum_m|f_i(m)\Phi(m/M)|\ll M.
\tag{6}
\]

**移动带的分块误差。** 对任何两通道 $i,j$，以块中心差替代 $m-n$，并用中心差决定是否属于 $(T,U]$。所得误差一致为

\[
O(HB/M)=O(B/W).
\tag{7}
\]

为核对 (7)，由 Poisson 求和及 $\Phi$ 的紧支撑，沿有贡献的块对上 $m-n$ 与中心差之间的线段，任意固定 $A>2$ 都有

\[
|K_H'(t)|\ll_{A,\psi,\eta}\frac{H^2}{M}(1+|t|/W)^{-A}.
\]

式 (6) 蕴含 $\sup_m\sum_n|f_j(n)\Phi(n/M)|(1+|m-n|/W)^{-A}\ll W$；故替换核的归一化费用至多 $M^{-2}(BH^2/M)\cdot O(MW)=O(B/W)$。若实际差和中心差落在位移带的不同侧，实际差距 $T$ 或 $U$ 至多 $2B$；两条边界条带各有 $O(MB)$ 的绝对配对质量，乘 $\|K_H\|_\infty\ll H$ 并除以 $M^2$，又为 $O(B/W)$。这个论证包括 $T=0$ 和重叠边界。

中心块矩阵的绝对行和满足

\[
\sup_q\sum_r|K_H(x_q-x_r)|\ll HW/B,
\tag{8}
\]

因为非零通道块中心与周期别名隔开固定比例、$W/B\to\infty$，而 $\widehat\eta$ 快速衰减。由块数 $O(M/B)$、$|S_q|\ll B$ 与 (5)、(8)，将 $D_q^iD_r^j$ 换成 $\kappa_i\kappa_jS_qS_r$ 的归一化费用至多 $O(\epsilon_M)$，无论带的位置与宽度如何。再把后者逆向展开成平滑序列 $\Phi(m/M)/M$ 的原始带和，利用同一 (7)，得到

\[
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
=\kappa_i\kappa_j Q_\Phi(T,U)+O(\epsilon_M+B/W),
\tag{9}
\]

其中 $Q_\Phi=M^{-2}\sum_{T<|m-n|\le U}\Phi(m/M)\Phi(n/M)K_H(m-n)$。当 $i=j=\mu$ 时两个块因子都来自 $E$，故 (9) 中 $\epsilon_M$ 可换为 $\epsilon_M^2$。

若 $u,v\perp\kappa$，则 (5) 给对应的两个块和都是 $O(\|u\|B\epsilon_M)$、$O(\|v\|B\epsilon_M)$。用 (8) 对这两个小块和求和，得 $O(\|u\|\|v\|\epsilon_M^2)$；(7) 对线性组合仍为 $O(\|u\|\|v\|B/W)$，证明 (2d)。

对 $L\le CW$ 的薄带可直接绕过分块误差。将 $f_i=\kappa_i+g_i$、$f_j=\kappa_j+g_j$ 展开。固定 $m$ 后，满足 $T<|m-n|\le U$ 的 $n$ 属于至多两个长度 $O(L)$ 的区间。由于 $\|K_H\|_\infty\ll H$、$\|K_H'\|_\infty\ll H^2/M$、$L\le CW$，每个区间上 $n\mapsto\Phi(n/M)K_H(m-n)/M$ 的上确界与总变差之和为 $O_C(H/M)$。由 (4a) 作 Abel 求和，任一含 $g_j(n)$ 的内和为 $O_C(H(L\epsilon_M+M^\vartheta)/M)$。对外层用 $\sum_m|f_i(m)\Phi(m/M)|/M\ll1$；含 $g_i$ 而不含 $g_j$ 的交叉项交换 $m,n$ 后同理。因此

\[
\sum_{T<|m-n|\le U}a_m^ia_n^jK_H(m-n)
=\kappa_i\kappa_j Q_\Phi(T,U)
+O_C\!\left(\frac{HL}{M}\epsilon_M+\frac{HM^\vartheta}{M}\right).
\tag{9a}
\]

**平滑主项。** 对 $k=m-n$，紧支撑及 $\Phi\in C^1$ 给

\[
\frac1M\sum_m\Phi(m/M)\Phi((m-k)/M)
=I_\Phi+O_\psi(|k|/M+1/M).
\tag{10}
\]

有贡献的 $|k|\le(1-\sigma_\psi)M$，故 Poisson 表达在该范围给

\[
K_H(k)=H\widehat\eta(k/W)
+O_{A,\psi,\eta}(H^{1-A})
\]

且任意阶的 $|K_H(k)|\ll H(1+|k|/W)^{-A}$。把 (10) 中的误差按此衰减求和，总费用 $O(1/H)$；非零 Poisson 别名为 $O_A(H^{-A+1})$。最后对 $\widehat\eta$ 作一次统一于区间端点的黎曼求和，步长 $1/W$，误差 $O(1/W)$，得到

\[
Q_\Phi(T,U)
=I_\Phi\int_{T/W<|v|\le U/W}\widehat\eta(v)\,dv
+O_{\psi,\eta}(1/H),
\tag{11}
\]

其中超过 $\Phi$ 物理支撑的积分尾由 Schwartz 衰减吸收。式 (9) 与 (11) 证明 (2)。

对只含 $O(L+1)$ 个整数位移的薄带，可把上述光滑误差局部化。Poisson 衰减在有贡献的区间一致给 $\sup_k (|k|/M)|K_H(k)|\ll1$，因此 (10) 的 $|k|/M$ 误差总计为 $O((L+1)/M)$；整数求积与位移端点的黎曼和误差为 $O(H/M)$。远于 $\Phi$ 支撑的 $\widehat\eta$ 积分尾和 Poisson 非零别名也被 $O((L+H)/M)$ 吸收。由此 (11) 可在任意移动带上改用误差 $O((L+H)/M)$，与 (9a) 合并即得 (2a)。若 $L\le CH^3$，把其误差除以 $H^4/M$，三项分别为 $O_C(e^{-c_0V_M})$、$O(M^\vartheta/H^3)$ 和 $O_C(1/H+H^{-3})$，均趋于零，证明 (2b)。

$\square$

## 边界

式 (2) 说明任意宏观位移带上的常数量级正负交叉，都可先由四通道的平滑密度 $(-4,1,3,0)$ 解释；这种抵消本身不含固定幂 RH 信息。scratch 970 对完整系数的平方节省仍只有 $e^{-2c_0V_M}$。在 $H\asymp M^{1/5}$ 时，note 849 式 (15) 尚需真实二点结构再给 $M^{-1/5+o(1)}$ 级联合节省。

这个边界还可用 [scratch 904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的乘法反模型严格核对。取其补充段的 $f'_{ab}$，并固定 $71/120<\vartheta<\rho<3/5$。该稿式 (20) 与真实 $\mu$ 的 Ramachandra 短和给 $f'_{ab}$ 在**所有**整数区间上的式 (4a) 型估计；窗口内又有 $f'_{ab}*\log=\Lambda$，所以本证明的两个素数通道及密度向量 $\kappa$ 原样保留。故 (2)、(2d) 对该模型仍成立（缩小 $c_0$ 即可）。但 scratch 904 式 (19) 表明其中至少一个模型的完整带通能量 $\gg e^{-2V_M}/\log^2M\gg H^4/M$。因此本稿的整个移动带秩一律和密度正交补平方节省，连同窗口内精确的 von Mangoldt 卷积，都不能作为统一测试类上的固定幂门。反模型改变了高素数上的 $\mu(p)=-1$；真实算术证明必须使用排除这种翻转的信息。
