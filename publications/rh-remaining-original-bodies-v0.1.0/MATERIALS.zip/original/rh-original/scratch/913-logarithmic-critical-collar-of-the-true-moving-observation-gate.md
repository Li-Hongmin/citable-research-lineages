# 真实移动观察门的临界对数频带可无条件支付

日期：2026-10-02。承重输入是 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的精确两端点展开，以及 Matomäki--Shao--Tao--Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, *Forum Math. Pi* **11** (2023), e29, DOI 10.1017/fmp.2023.28 的 Theorem 3.1(i) 和式 (3.11)。后两处已从原论文 PDF 直接核对。本文加强 note 849 式 (22) 的无速率消失，并闭合频率上端的一个随尺度缩小的实际算术门；较低的固定幂频带仍未解决。本稿尚未异源复核，不晋级为权威定理。

## 定理

令 $Y\to\infty$ 沿正整数，$M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$。固定 $\psi\in C_c^3((1,2))$，$\phi(u)=\psi(u)/u$。定义 note 849 的**真实**联合系数及观察和
\[
c(m)=2\mathbf1_{2\mid m}\bigl(\Lambda(m/2)-1\bigr)
 -4\bigl(\Lambda(m)-1+(\log2)\mu(m)\bigr),
\qquad
\mathcal A_h(Y)=\frac1M\sum_{M<m<2M}c(m)\phi(m/M)e(-hm/M).
\tag{1}
\]
固定任何有界、非负、支撑于 $1/2\le |u|\le4$ 的带通权 $\eta$。对每个 $A>0$，一致于上述 $H$，
\[
\boxed{\quad
\sum_{h\in\mathbb Z}\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{A,\psi,\eta}(\log Y)^{-A}.
\quad}\tag{2}
\]
特别地，对每个固定 $C>0$，在
\[
Y^{1/4}(\log Y)^{-C}\le H\le Y^{1/4}
\tag{3}
\]
有
\[
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{C,\psi,\eta}H^4/Y.
\tag{4}
\]
若 $\eta\in C_c^\infty$ 还满足 note 849 式 (12) 的条件，置 $K_0=H^3/(\log M)^2$、$K_1=Y^{1+\delta}/H$，则该 note 式 (15) 的**真实完整系数**中距离 signed Gram 事实上在整个 $Y^{1/5}\le H\le Y^{1/4}$ 上满足
\[
\boxed{\quad
\left|\sum_{K_0<|m-n|\le K_1}a_m\overline{a_n}K_H(m-n)\right|
\ll_{A,\delta,\psi,\eta}(\log Y)^{-A}
\quad\text{for every fixed }A>0,
\quad}\tag{4a}
\]
其中 $a_m=M^{-1}c(m)\phi(m/M)$、$K_H(k)=\sum_h\eta(h/H)e(-hk/M)$。特别地，(4a) 在 (3) 上满足 $O_{C,\delta,\psi,\eta}(H^4/Y)$。若另有 $\eta\ge1$ 于 $1\le|u|\le2$，则 note 849 中原始 $k=2$ residual 的这段 dyadic 观察能量满足
\[
\frac1Y\sum_{H\le|h|\le2H}|S_h|^2\ll_{C,\psi,\eta}Y^2.
\tag{5}
\]
式 (4)--(5) 只覆盖临界对数窄带；固定 $\gamma<1/4$ 的 $H=Y^\gamma$ 仍需要真正的固定幂算术增益。

## 证明

**原文输入及物理映射。** 置 $L=\lfloor M/(32H)\rfloor$，则 $Y^{3/4}/O(1)\le L\le O(Y^{4/5})$。以下母区间长度 $T$ 取 $L$ 或 $\lceil L/2\rceil$。二者均满足原文 Theorem 3.1(i) 的条件 $x^{7/12+\varepsilon}\le T\le x^{1-\varepsilon}$，例如固定 $\varepsilon=1/12$，一致于 $x\in[Y/2,4Y]$。该定理给任意 $D>0$ 的最大进程界
\[
\sup_{I\subset(x,x+T]}\left|\sum_{n\in I}\mu(n)\right|
\ll_D T(\log Y)^{-D},
\quad
\sup_{I\subset(x,x+T]}\left|\sum_{n\in I}(\Lambda(n)-\Lambda^\sharp(n))\right|
\ll_D T(\log Y)^{-D},
\tag{6}
\]
其中 $I$ 可取母区间内的任何整数子区间，而 $\Lambda^\sharp$ 的筛选参数 $R$ 固定在该母区间的 $x$。原文式 (3.11) 的上下筛权证明只用子区间长度与 $x\asymp Y$，故保持同一 $R$，对任何这样的 $I$、$|I|\ge Y^{\varepsilon_0}$（例如固定 $\varepsilon_0=1/3$）及模数 $q=1$ 仍给
\[
\sum_{n\in I}\Lambda^\sharp(n)
=|I|+O\!\left(|I|e^{-(\log Y)^{1/2}}\right).
\tag{7}
\]
若 $|I|<Y^{\varepsilon_0}$，由原文式 (1.1) 的 Cramér--Granville 模型和 Mertens 乘积界，有 $0\le\Lambda^\sharp(n)\ll\log Y$，故
$\sum_{n\in I}|\Lambda^\sharp(n)-1|
\ll Y^{\varepsilon_0}\log Y=o_D(T(\log Y)^{-D})$。因此 (6)--(7) 合起来，对所有这样的 $I$ 一致得到
\[
\left|\sum_{n\in I}(\Lambda(n)-1)\right|
+\left|\sum_{n\in I}\mu(n)\right|
\ll_D T(\log Y)^{-D}.
\tag{8}
\]
这里 $x$ 可在 $[Y/2,4Y]$ 变化，故 (8) 同时适用于 $m$ 与 $m/2$ 两个窗口。

任取 $J\subset(M,2M)$、$|J|\le L$，把直接 $m$ 通道嵌入一个长 $L$ 的母区间；偶数通道先以 $m=2n$ 换元，再嵌入长 $\lceil L/2\rceil$ 的母区间。分别使用 (8)，由 (1) 得
\[
\sup_{\substack{J\subset(M,2M)\\|J|\le L}}
\left|\sum_{m\in J}c(m)\right|
\ll_D L(\log Y)^{-D}.
\tag{9}
\]
也可对 $J$ 的每个前缀使用同一界。对 $\phi(m/M)$ 作一次 Abel 求和，因 $\phi,\phi'$ 有界且 $|J|/M\le L/M<1$，得到
\[
\sup_{|J|\le L}
\left|\frac1M\sum_{m\in J}c(m)\phi(m/M)\right|
\ll_{D,\psi}\frac LM(\log Y)^{-D}.
\tag{10}
\]

将 $a_m=M^{-1}c(m)\phi(m/M)$ 在窗外置零，再记 $b_x=a_{x+M}$，$x\in\mathbb Z/M\mathbb Z$。因 $\phi$ 紧支撑于 $(1,2)$ 且 $L=o(M)$，每个长度 $L$ 的循环窗至多分成两个受 (10) 控制的物理区间，故
\[
\sup_{x\bmod M}\left|\sum_{j=0}^{L-1}b_{x-j}\right|
\ll_{D,\psi}\frac LM(\log Y)^{-D}.
\tag{11}
\]
记 $V_h=\sum_{j=0}^{L-1}e(-hj/M)$。在 $\eta(h/H)\ne0$ 时 $|h|\le4H$、$|h|L/M\le1/8$，几何和公式给 $|V_h|\gg L$。所有这些 $h$ 属于模 $M$ 的不同频率。有限循环群 Parseval 及 (11) 给
\[
\begin{aligned}
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
&\ll_\eta L^{-2}\sum_{h\bmod M}|V_h\mathcal A_h(Y)|^2\\
&=\frac{M}{L^2}\sum_{x\bmod M}
\left|\sum_{j=0}^{L-1}b_{x-j}\right|^2
\ll_{D,\psi,\eta}(\log Y)^{-2D}.
\end{aligned}\tag{12}
\]
取 $D>A/2$ 得 (2)。在 (3) 上，$H^4/Y\gg_C(\log Y)^{-4C}$，所以 (2) 取 $A>4C$ 得 (4)。

**近差段的定量支付。** 当 $Y^{1/5}\le H\le Y^{1/4}$ 时，
$K_0\gg Y^{3/5}/\log^2Y$ 且 $K_0\ll Y^{3/4}/\log^2Y$。因此 $T=\lceil2K_0\rceil+2$ 同样满足原文 Theorem 3.1(i) 的长度范围 $x^{7/12+\varepsilon}\le T\le x^{1-\varepsilon}$，例如取固定 $\varepsilon=1/120$。重复 (6)--(10) 的论证，对每个 $|I|\le2K_0$ 的物理区间有
\[
\left|\sum_{m\in I}a_m\right|
\ll_{D,\psi}\frac{K_0}{M}(\log Y)^{-D}.
\tag{13}
\]
同一上界适用于 $I$ 的每个前缀。核满足 $\sup|K_H|\ll_\eta H$ 和
$|K_H'(u)|\ll_\eta H^2/M$。因 $K_0\le M/(32H)$ 对充分大 $Y$ 成立，其在 $[-K_0,K_0]$ 的总变差为 $O_\eta(H)$。固定外层 $m$，把 (13) 对内层 $n$ 作 Abel 求和，于是
\[
\left|\sum_{|m-n|\le K_0}\overline{a_n}K_H(m-n)\right|
\ll_{D,\psi,\eta}\frac{HK_0}{M}(\log Y)^{-D}.
\tag{14}
\]
由 note 849 式 (16) 的 $\sum_m|a_m|\ll_\psi1$，近差 Gram 的绝对值至多
\[
O_{D,\psi,\eta}\!\left(
\frac{HK_0}{M}(\log Y)^{-D}\right)
=O_{D,\psi,\eta}\!\left(
\frac{H^4}{M}(\log Y)^{-D-2}\right)
=O_{D,\psi,\eta}((\log Y)^{-D-2}).
\tag{15}
\]
note 849 式 (17)--(18) 已证明 $|m-n|>K_1$ 的绝对成本为任意负幂。完整 Gram 是 (2) 的左侧，从中减去 (15) 与远差，得到 (4a)。这里对完整真实 $c$ 的近差使用了均值为零的短和；三通道 $t$ 单独在近差段有非零平滑密度主项，不能把 (4a) 不加修改地移植给 $t$。

最后 note 849 式 (7) 给两端点近似误差
$Y^{-1}\sum_{H\le|h|\le2H}|S_h-T_h|^2\ll Y^2$；式 (9) 给
$Y^{-1}\sum_{H\le|h|\le2H}|T_h|^2\ll (Y^3/H^4)\sum_{H\le|h|\le2H}|\mathcal A_h|^2$。
在 (3) 中，$Y^3/H^4\ll_C Y^2(\log Y)^{4C}$，由 (2) 选择 $A>4C$ 即得 (5)。$\square$

## 数学边界

这是真实 $\Lambda,\mu$ 联合系数的临界对数窄带上界，不依赖三通道的分离估计；所用文献只给任意对数幂，没有给 $H=Y^\gamma$、$\gamma<1/4$ 所需的 $Y^{4\gamma-1}$ 固定幂。note 849 的整段频带门以及全尺度局部 Weil 正性仍未关闭。
