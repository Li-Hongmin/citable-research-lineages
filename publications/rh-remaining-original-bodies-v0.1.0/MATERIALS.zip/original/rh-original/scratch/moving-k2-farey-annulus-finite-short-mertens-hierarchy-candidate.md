# moving \(k=2\) Farey 整环的有限短 Mertens 层级（候选）

> 文献输入修复（2026-09-30）：原版引用的 Motohashi--Ramachandra 指数型短区间误差未从所引原文核实。下文命题 3、5 已改为任意对数幂节省，外部输入为 Matomäki--Shao--Tao--Teräväinen 2023 的全区间最大 Möbius 定理；该定理已核对原 PDF，整条新证明仍待异源复核。

日期：2026-09-30。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5)、[note 832](../notes/832-sloping-numerator-gate-for-moving-k2-farey-residual.md) 的真实斜楔，以及[整环常数乘子归约候选](moving-k2-farey-slope-annulus-collapses-to-short-mertens-increments-candidate.md)。命题 3、5 的外部输入是 Matomäki--Shao--Tao--Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, *Forum Math. Pi* (2023), DOI 10.1017/fmp.2023.28, Theorem 1.1(i)：对每个固定 \(\epsilon,A>0\)、\(x^{5/8+\epsilon}\le H\le x^{1-\epsilon}\)，区间 \((x,x+H]\) 内全部整数等差子进程的 Möbius 和绝对值均为 \(O_{A,\epsilon}(H/\log^A x)\)。已于本日从 Cambridge 原 PDF 核对该定理及其最大进程定义。下面保留真实 Möbius 符号与物理截止；结果尚待异源复核，未证明算术均方目标。

固定 \(4/5<\alpha<1\)，令 \(Y\to\infty\) 沿整数，并置
\[
D=\lfloor Y^\alpha\rfloor,\qquad K=Y/D,\qquad
L=\lfloor Y^{5/6}\rfloor,\qquad
\mathcal B_h(v)=\frac{4\mathbf1_{2\mid h}}{1-4v^2}-\frac1{1-v^2}.
\tag{1}
\]
沿用前一候选的 \(\mathcal V_{D,N}\) 与
\[
\Delta M_{m,h}(N)=\sum_{\substack{mh\le d<(m+1)h\\d\le N-L}}\mu(d)
\qquad(Y<N\le2Y).
\tag{2}
\]
若 \(\Delta M_{m,h}(N)=0\)，下列乘积按零理解。定义
\[
\boxed{\quad
\mathcal W^{\rm rat}_{D,N}=-\frac1{\pi N}
\sum_{D/2<m<D}m\cos\frac{2\pi N}{m}
\sum_{1\le h\le\lceil4K\rceil}
\frac{\mathcal B_h(m/N)}h
\log\frac N{mh}\,\Delta M_{m,h}(N).
\quad}\tag{3}
\]

**命题 1。** 对每个固定 \(4/5<\alpha<1\)，一致于 \(Y<N\le2Y\)，
\[
|\mathcal V_{D,N}-\mathcal W^{\rm rat}_{D,N}|
\ll K\log(2K)+1+K^{-2}\log(2K)
\ll K\log(2K).
\tag{4}
\]
故
\[
\sum_{Y<N\le2Y}|\mathcal V_{D,N}-\mathcal W^{\rm rat}_{D,N}|^2
\ll YK^2\log^2(2K)\ll Y^2\log^2(2Y).
\tag{5}
\]
上一个候选中的 \(\alpha\le5/6\) 限制只用于把有理乘子直接替换成常数；保留 \(\mathcal B_h(m/N)\) 时并不需要该限制。

**证明。** 与前一候选式 (2)--(3) 相同，斜率 \(D/2<d/h\le D\) 的全部原始物理项都属于 note 832 的斜楔：\(h<4K\)、既约分子 \(a\le h<Y^{1/3}\)、既约分母 \(q=a(d/h)>Q=\lfloor Y^{4/5}\rfloor\)，并且在相应的 \(q\)-带中 \(A_j/a\gg a^{2/3}Y^{(5\alpha-4)/3}\to\infty\)。因此从 note 801 式 (5) 可直接使用前一候选的精确原始指标式 (2)。

置 \(s=d/h\)、\(m=\lfloor s\rfloor\)。函数 \(f_N(x)=x\cos(2\pi N/x)\) 在 \(x\asymp D\) 满足 \(|f_N'(x)|\ll K\)。由于每个 \((m,h)\) 至多包含 \(h\) 个整数 \(d\)，\(m\)-数为 \(O(D)\)，\(h\)-数为 \(O(K)\)，将 \(f_N(s)\) 冻结为 \(f_N(m)\) 的逐点总误差为 \(O(K\log(2K))\)。

对充分大的 \(Y\)，\(s/N,m/N\ll K^{-1}\) 且 \(0\le s-m<1\)。直接微分 (1) 得 \(|\mathcal B'_h(v)|\ll v\)（\(0\le v\ll K^{-1}\)，常数不依赖 \(h\)），从而
\[
|\mathcal B_h(s/N)-\mathcal B_h(m/N)|\ll (NK)^{-1}.
\tag{6}
\]
在已冻结相位后，每个原始项去掉 \(1/(\pi N)\) 的误差至多 \(O(D\log(2K)/(hNK))\)。先数 \(d\) 再数 \((m,h)\)，得到总误差
\[
\ll\frac1N\cdot DK\cdot\frac{D\log(2K)}{NK}
\ll K^{-2}\log(2K).
\tag{7}
\]
最后 \(\log(N/d)-\log(N/(mh))=-\log(d/(mh))=O(D^{-1})\)，有理乘子一致有界；同样计数给 \(O(1)\)。斜率下边界的 \(m=\lfloor D/2\rfloor\) 与上边界的 \(m=D\) 至多两行，每行逐项绝对支付 \(O(\log(2K))\)。内部行的斜率限制自动成立，其 \(d\)-和恰为 (2)；非零项自动满足 \(h<4K\)。这证明 (4)。因为 \(K\ll Y^{1/5}\)，平方求和给 (5)。\(\square\)

有理乘子只通过 \(h\) 的奇偶性变化。令
\[
b_{j,h}=4^{j+1}\mathbf1_{2\mid h}-1,
\qquad
P_{J,h}(v)=\sum_{j=0}^{J-1}b_{j,h}v^{2j}
\quad(J\ge1),
\tag{8}
\]
并以 \(P_{J,h}(m/N)\) 代替 (3) 的 \(\mathcal B_h(m/N)\)，所得记为 \(\mathcal W^{(J)}_{D,N}\)。\(J=1\) 正是前一候选的常数乘子模型。

**命题 2。** 对每个固定正整数 \(J\)，
\[
|\mathcal V_{D,N}-\mathcal W^{(J)}_{D,N}|
\ll_J K\log(2K)+\frac{D}{K^{2J}}\log(2K),
\tag{9}
\]
\[
\sum_{Y<N\le2Y}|\mathcal V_{D,N}-\mathcal W^{(J)}_{D,N}|^2
\ll_J Y\log^2(2Y)\left(K^2+\frac{D^2}{K^{4J}}\right).
\tag{10}
\]
特别地，若 \(D\ll K^{4J+1}\)，即对固定幂 \(D=Y^\alpha\) 有
\[
\alpha\le\frac{4J+1}{4J+2},
\tag{11}
\]
则 (10) 为 \(O_J(Y^2\log^2Y)\)。因此任意固定 \(4/5<\alpha<1\) 都有一个**有限**的多项式短增量模型达到目标尺度的双向归约；例如 \(J=1\) 到 \(5/6\)，\(J=2\) 到 \(9/10\)。

**证明。** \(|m/N|\ll K^{-1}\)，所以 (1) 的两条几何级数绝对收敛，且对固定 \(J\) 有
\[
|\mathcal B_h(m/N)-P_{J,h}(m/N)|\ll_J K^{-2J}
\quad\text{一致于 }h.
\tag{12}
\]
每项的 \(m/h\) 权、\(O(h)\) 个 \(d\)、\(O(DK)\) 个 \((m,h)\) 与外部 \(N^{-1}\) 给尾项 \(O_J(DK^{-2J}\log(2K))\)。与命题 1 合并得 (9)--(10)。第二项达到 \(O(Y^2\log^2Y)\) 的条件正是 \(YD^2/K^{4J}\ll Y^2\)，等价于 \(D\ll K^{4J+1}\)。\(\square\)

## 整环全分子的无条件任意对数幂节省

短增量 (2) 虽然远短于现有逐项 Möbius 定理的范围，沿相位宽度 \(B=\lfloor D^2/Y\rfloor\) 对 \(m\) 合并后却成为长区间。对任意整数 \(M,r\ge1\) 有精确恒等式
\[
\sum_{m=M}^{M+r-1}\Delta M_{m,h}(N)
=\sum_{\substack{Mh\le d<(M+r)h\\d\le N-L}}\mu(d).
\tag{13}
\]

**命题 3。** 对每个固定 \(4/5<\alpha<1\) 及任意固定 \(A>0\)，有
\[
\boxed{\quad
\sup_{Y<N\le2Y}|\mathcal V_{D,N}|
\ll_{A,\alpha}\frac{D}{(\log Y)^A}.
\quad}\tag{14}
\]
这是对整环**全部增长分子**的真实 Möbius 任意对数幂节省；其平方和界 \(O_{A,\alpha}(YD^2/\log^A Y)\) 仍超过 \(Y^{2+\varepsilon}\) 的所需幂次。

**证明。** 将 \(D/2<m<D\) 分成 \(O(K)\) 个连续整数块，每块长度至多 \(B\asymp D/K\)。固定 \(h\le\lceil4K\rceil\)。一块中的任意前缀在 (13) 下是 \(d\asymp Dh\) 的单个 Möbius 区间，长度至多 \(Bh\)。而
\[
\frac{Bh}{(Dh)^{5/8+\epsilon_\alpha}}
\gg D^{\beta-5/8-\epsilon_\alpha}h^{3/8-\epsilon_\alpha}\longrightarrow\infty,
\qquad
\frac{Bh}{(Dh)^{1-\epsilon_\alpha}}
\ll Y^{\alpha-1+\epsilon_\alpha}\longrightarrow0,
\tag{15}
\]
这里 \(\beta=2-1/\alpha\in(3/4,1)\)，取 \(0<\epsilon_\alpha<\min\{\beta-5/8,1-\alpha,3/8\}\)。式 (15) 对 \(1\le h\le4K+1\) 和所有块中心一致成立。对长度不足 \(B\) 的块，把它嵌入从同一左端开始、长度为 \(B\) 的整块；上引 2023 定理的最大进程界直接支付其中**每个**前缀，包括移动物理裁剪 \(d\le N-L\)。式 (13) 的整数端点惯例与 \((x,x+H]\) 至多差两个 \(\mu\) 项，亦被该界吸收。因此，对任意固定 \(A>0\)，(13) 的前缀一致为
\[
O_{A,\alpha}\bigl(Bh/(\log Y)^A\bigr).
\tag{16}
\]
对固定 \(N,h\)，(3) 中的 \(m\)-权
\[
g_{N,h}(x)=\frac{x}{h}\cos\frac{2\pi N}{x}
\mathcal B_h(x/N)\log\frac N{xh}
\]
在任一块上的上确界及总变差之和为 \(O(D\log(2K)/h)\)：\(|(x\cos(2\pi N/x))'|\ll K\)，块长 \(B\ll D/K\)，而 \(\mathcal B_h\) 及其导数在 \(x/N\ll K^{-1}\) 有界。Abel 分部求和结合 (16) 给每个 \((h,\text{块})\) 的加权和 \(O_{A,\alpha}(BD\log(2K)/(\log Y)^A)\)。对 \(O(K)\) 块和 \(O(K)\) 个 \(h\) 求和、再乘 (3) 的 \(N^{-1}\asymp(DK)^{-1}\)，得到
\[
|\mathcal W^{\rm rat}_{D,N}|
\ll_{A,\alpha}D\log(2K)/(\log Y)^A.
\tag{17}
\]
命题 1 的 \(O(K\log(2K))\) 误差也被右侧吸收，因为 \(D/K\) 是固定正幂。先以 \(A+1\) 应用 (16)，再吸收 \(\log(2K)\ll\log Y\)，即得 (14)。\(\square\)

## 整环物理 collar 与连续模型

令 \(\mathcal V^{\rm uncut}_{D,N}\) 为前一候选式 (2) 中仅把 \(d\le N-L\) 换成 \(d<N\) 后的原始斜率整环。它在端点上不再等于 note 832 的 \(\mathcal V_N\) 的一部分，但可与真实物理环比较。

**命题 4。** 对每个固定 \(4/5<\alpha<1\)，有
\[
|\mathcal V^{\rm uncut}_{D,N}-\mathcal V_{D,N}|
\ll\frac{L^2}{YK},
\qquad
\sum_{Y<N\le2Y}
|\mathcal V^{\rm uncut}_{D,N}-\mathcal V_{D,N}|^2
\ll\frac{L^4}{YK^2}.
\tag{18}
\]
当 \(\alpha\le5/6\) 时，(18) 的最后一项为 \(O(Y^2)\)，故在此范围可按目标尺度移除物理 collar。
再定义连续移动系数
\[
G_{m,h}(t)=\sum_{\substack{mh\le d<(m+1)h\\d<t}}
\mu(d)\log\frac td,
\quad
\mathcal Z_{D,N}=-\frac1{\pi N}
\sum_{D/2<m<D}m\cos\frac{2\pi N}{m}
\sum_{h\le\lceil4K\rceil}
\frac{\mathcal B_h(m/N)}h G_{m,h}(N).
\tag{19}
\]
对每个 \((m,h)\)，\(G_{m,h}\) 在 \([Y,2Y]\) 上绝对连续，且几乎处处
\[
G'_{m,h}(t)=\frac1t
\sum_{\substack{mh\le d<(m+1)h\\d<t}}\mu(d).
\tag{20}
\]
并有 \(\sup_N|\mathcal V^{\rm uncut}_{D,N}-\mathcal Z_{D,N}|\ll K\log(2K)\)，对全部固定 \(4/5<\alpha<1\) 成立。特别在 \(\alpha\le5/6\) 时，真实整环的目标均方门与具有**无进入原子**的 (19) 双向等价。

**证明。** 对 \(d=N-r\)、\(1\le r<L\)，有 \(d\asymp Y\)、\(\log(N/d)\ll r/Y\)。斜率条件强制 \(d/D\le h<2d/D\)，故 \(h\asymp K\)、\(\sum_h h^{-2}\ll K^{-1}\)。精确核的 \(\mathcal B_h(d/(hN))\) 一致有界。对每个 \(d\) 取绝对值后，其端点贡献至多 \(O(r/(YK))\)；对 \(r<L\) 求和得 (18) 第一式。平方乘 \(O(Y)\) 个 \(N\) 得第二式；当 \(\alpha\le5/6\) 时 \(K\ge Y^{1/6+o(1)}\)，故第二式至多为 \(O(Y^2)\)。

每个新进入的 \(d=t\) 在 (19) 中以 \(\log(t/d)=0\) 开始，故逐有限和直接给绝对连续性和 (20)。从无 collar 的精确原始式冻结 \(s\cos(2\pi N/s)\) 及 \(\mathcal B_h(s/N)\) 时，命题 1 的导数估计原样适用；不冻结对数，故少一个 \(O(1)\) 误差。两行边界仍为 \(O(\log(2K))\)。于是 \(|\mathcal V^{\rm uncut}_{D,N}-\mathcal Z_{D,N}|\ll K\log(2K)\)，其均方也为 \(O(Y^2\log^2Y)\)。\(\square\)

## 相位块的大筛给整环联合均方任意对数幂节省

**命题 5。** 对每个固定 \(4/5<\alpha<1\) 及任意固定 \(A>0\)，真实物理整环满足
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal V_{D,N}|^2
\ll_{A,\alpha}\frac{D^3}{(\log Y)^A}.
\quad}\tag{21}
\]
式 (21) 比命题 3 逐点平方所得的 \(YD^2/\log^A Y\) 少一个 \(K=Y/D\) 因子，覆盖整环全部增长既约分子。它仍超出目标 \(Y^{2+\varepsilon}=D^2K^2Y^\varepsilon\) 一个固定幂 \(D/K^2=Y^{3\alpha-2}\)；不能据此证明 residual 门。

**证明。** 用命题 4 的连续模型 (19)。置 \(B=\lfloor D^2/Y\rfloor\asymp D/K\)。将 \(D/2<m<D\) 分成 \(J\asymp K\) 个连续整数块 \(I_j\)，每块长度介于 \(B/2\) 与 \(2B\)；末尾不足 \(B/2\) 时并入前块。取每块一个整数中心 \(m_j\)，置 \(\vartheta_j=1/m_j\)。不同中心相隔至少 \(B/2\)，所以这些位于 \((0,1)\) 的圆周频率相距
\[
\operatorname{dist}_{\mathbb R/\mathbb Z}(\vartheta_i,\vartheta_j)
\gg B/D^2\asymp Y^{-1}.
\tag{22}
\]
对 \(m\in I_j\)，记 \(\xi_{j,m}=1/m-1/m_j\)，则 \(|\xi_{j,m}|\ll B/D^2\ll Y^{-1}\)。定义绝对连续的块系数
\[
S_j(t)=\sum_{m\in I_j}\sum_{h\le\lceil4K\rceil}
\frac{m}{\pi t h}\mathcal B_h(m/t)G_{m,h}(t)
e(t\xi_{j,m}),
\qquad e(x)=e^{2\pi ix}.
\tag{23}
\]
因为 \(G_{m,h}(t)\) 及其余权均为实数，(19) 精确变成
\(\mathcal Z_{D,N}=-\operatorname{Re}\sum_jS_j(N)e(N\vartheta_j)\)。

下证对所有 \(j\) 和任意固定 \(A>0\) 一致有
\[
|S_j(Y)|+\int_Y^{2Y}|S_j'(t)|\,dt
\ll_{A,\alpha}B/(\log Y)^A.
\tag{24}
\]
固定 \(h\) 与 \(I_j\)。该块任一从左端开始的 \(m\)-前缀，其 \(G_{m,h}(t)\) 之和，由 (19) 正好等于在 \(d\asymp Dh\)、长度至多 \(2Bh\) 的一个区间上求 \(\mu(d)\log(t/d)\)，并在 \(d<t\) 截断。命题 3 式 (15)--(16) 的同一全区间最大进程输入，先对未加权 Möbius 前缀给 \(O_{A,\alpha}(Bh/(\log Y)^A)\)，再对单调的 \(\log(t/d)\) 分部求和，得到
\[
\max_{\text{块内前缀}}
\left|\sum_mG_{m,h}(t)\right|
\ll_{A,\alpha}Bh\log(2K)/(\log Y)^A.
\tag{25}
\]
由 (20)，同样的前缀对 \(G'_{m,h}(t)\) 的和至多 \(O_{A,\alpha}(Bh/[t(\log Y)^A])\)；物理截断 \(d<t\) 保持区间连续。式 (24) 最后以更大的输入对数指数吸收 \(\log(2K)\)。

对 (23) 的固定 \(h\) 权记为
\(w_{j,m,h}(t)=m\mathcal B_h(m/t)e(t\xi_{j,m})/(\pi t h)\)。在 \(m\in I_j\) 上，由 \(m\asymp D\)、\(t\asymp Y\)、\(|t\xi_{j,m}|\ll1\) 及 \(\mathcal B_h,\mathcal B'_h\) 的一致界，直接微分给
\[
\sup_{m\in I_j}|w_{j,m,h}(t)|
+\operatorname{Var}_{m\in I_j}w_{j,m,h}(t)
\ll\frac1{Kh},
\quad
\sup_m|\partial_t w_{j,m,h}(t)|
+\operatorname{Var}_{m\in I_j}\partial_t w_{j,m,h}(t)
\ll\frac1{YKh}.
\tag{26}
\]
第二式中的相位导数是 \(2\pi i\xi_{j,m}=O(Y^{-1})\)，所以不会引入 \(K\) 损失。对 \(m\) 用 Abel 分部求和，将 (25)--(26) 分别用于 \(wG\)、\((\partial_t w)G\)、\(wG'\)，得到固定 \(h\) 的块贡献及其 \(t\)-导数至多
\[
O_{A,\alpha}\left(\frac B K\frac{\log(2K)}{(\log Y)^A}\right),
\qquad
O_{A,\alpha}\left(\frac B{YK}\frac{\log(2K)}{(\log Y)^A}\right).
\tag{27}
\]
对 \(O(K)\) 个 \(h\) 求和并在 \(t\in[Y,2Y]\) 积分，以输入指数 \(A+1\) 得到 (24)。

将 (22)、(24) 代入 note 802 式 (4) 的移动系数间距引理，得到
\[
\begin{aligned}
\|\mathcal Z_{D,\cdot}\|_{\ell^2(Y<N\le2Y)}^2
&\ll\bigl(Y+Y\log(2J)\bigr)
\left(\|S(Y)\|_2+\int_Y^{2Y}\|S'(t)\|_2dt\right)^2\\
&\ll_{A,\alpha}Y\log(2K)\cdot J B^2(\log Y)^{-2A}\\
&\ll_{A,\alpha}D^3\log(2K)(\log Y)^{-2A}.
\end{aligned}
\tag{28}
\]
增大输入 \(A\) 吸收对数。命题 4 给
\[
\|\mathcal V_D-\mathcal Z_D\|_2^2
\ll\frac{L^4}{YK^2}+YK^2\log^2(2K).
\tag{29}
\]
相对于 \(D^3\)，两项分别至多为 \(Y^{1/3-\alpha+o(1)}\) 与 \(Y^{3-5\alpha+o(1)}\)，在全部固定 \(\alpha>4/5\) 下都有固定幂节省，故 (29) 被 (21) 右侧吸收。\(\square\)

**此方法的定量边界。** (24) 给每块 \(S_j\) 的尺度 \(B/(\log Y)^A\)，而目标均方在 (22) 的移动大筛下需要这些块权的联合平方质量至多 \(O(Y/\log K)\)。由于块数 \(J\asymp K\)，相应的块均方根尺度为 \(O(\sqrt D)\)；现有逐块短区间界只有 \(B=D/K\) 乘任意固定对数幂节省，两者相差固定幂 \(\sqrt D/K=Y^{(3\alpha-2)/2+o(1)}\)。改变相位块长度无法消除这个幂次：若取长度 \(B'\le B\)，间距因子 \(D^2/B'\)、块数 \(D/B'\) 与每块的 \(B'^2\) 质量相乘仍为 \(D^3\)；若 \(B'>B\)，块内相位变差至少增加 \(B'/B\)。因此继续此条路线必须取得跨块或跨 \(h\) 的真实 signed covariance，而不能只加强同一种逐块三角估计。

**直接文献边界（2026-09-30）。** 本日核对 Matomäki--Shao--Tao--Teräväinen 2023, Theorem 1.1(i) 的 Cambridge 原 PDF。其全区间最大进程界足以给出 (21) 的任意对数幂节省，且已直接应用到随 \(h\) 伸缩的每个块；它不给 (24) 所需的固定幂联合平方节省。Matomäki--Radziwiłł--Shao--Tao--Teräväinen 2026 的 *Almost all intervals* 定理覆盖更短长度，但允许异常集合；此处无需使用它。

**RH 条件下的尺度校准。** 标准的 RH 后果 \(M(x)=O_\varepsilon(x^{1/2+\varepsilon})\) 可在 (25) 中把 \(Bh/(\log Y)^A\) 换成 \((Dh)^{1/2+\varepsilon}\)。同一 Abel 计算使固定 \(h\) 的 (27) 第一项变为 \(O_\varepsilon(D^{1/2+\varepsilon}h^{-1/2+\varepsilon}K^{-1}\log(2K))\)，求和于 \(h\le4K\) 后得到每块 \(|S_j(Y)|+\int|S'_j|\ll_\varepsilon(D/K)^{1/2}Y^\varepsilon\)。式 (28) 遂给
\[
\sum_{Y<N\le2Y}|\mathcal Z_{D,N}|^2
\ll_\varepsilon YD\,Y^\varepsilon
=\frac{Y^2}{K}Y^\varepsilon
\qquad(4/5<\alpha<1).
\tag{30}
\]
在 \(\alpha>5/6\) 时，RH 也支付单环物理 collar。固定 \(N\) 与 \(N-L<d<N\)，把其原始 Poisson 环项写为 \(\mu(d)w_N(d)\)。命题 4 的逐项估计给 \(\sup_d|w_N(d)|\ll L/(YK)\)。对不含斜率指标的固定 \(h\) 项逐 \(d\) 微分，\(\partial_d[d\log(N/d)/N]=O(Y^{-1})\)、\(\partial_d\cos(2\pi hN/d)=O(h/Y)\)，且 \(\mathcal B_h\) 及其导数一致有界；在 \(h\asymp K\) 上求和得平滑部分的总变差
\[
\ll \frac{L}{YK}+\frac{L^2}{Y^2}.
\]
斜率指标仅在 \(d=Dh/2\) 或 \(d=Dh\) 变化；长度 \(L<D\) 的 \(d\)-区间对每个端点族至多遇到 \(O(1)\) 次，单次跳跃 \(O(L/(YK^2))\)。由于 \(KL/Y\le1+o(1)\)，得到 \(\operatorname{Var}_{N-L<d<N}w_N(d)\ll L/(YK)\)。RH 的 \(M(x)=O_\varepsilon(x^{1/2+\varepsilon})\) 对该区间任一前缀给 \(O_\varepsilon(Y^{1/2+\varepsilon})\)；Abel 分部求和遂得端点差逐点 \(O_\varepsilon(LY^{-1/2+\varepsilon}/K)\)，均方 \(O_\varepsilon(L^2K^{-2}Y^{2\varepsilon})\ll Y^{2+2\varepsilon}\)。结合 \(\alpha\le5/6\) 的无条件支付、(30) 及无 collar 模型误差，可得条件性结论
\[
\mathrm{RH}\quad\Longrightarrow\quad
\sum_{Y<N\le2Y}|\mathcal V_{D,N}|^2
\ll_{\alpha,\varepsilon}Y^{2+\varepsilon}
\qquad(4/5<\alpha<1\text{ 固定}).
\tag{31}
\]
式 (30)--(31) 只校准当前方法所需的算术强度；它们以 RH 为假设，绝非 RH 的证明。

同一计算还能量化所需的 Mertens 指数。若对某个固定 \(1/2\le\sigma<1\) 已知 \(M(x)=O_\varepsilon(x^{\sigma+\varepsilon})\)，则 (25) 的前缀界为 \(O_\varepsilon((Dh)^{\sigma+\varepsilon}\log(2K))\)，(27) 求和于 \(h\) 后每块权为 \(O_\varepsilon(D^\sigma K^{\sigma-1}Y^\varepsilon)\)。移动大筛于是给
\[
\sum_N|\mathcal Z_{D,N}|^2
\ll_{\alpha,\varepsilon}YD^{2\sigma}K^{2\sigma-1}Y^\varepsilon
=Y^{2\sigma+\alpha+\varepsilon}.
\tag{32}
\]
当 \(\sigma\le1-\alpha/2\) 时，(32) 已达目标；\(\alpha\le5/6\) 的 collar 由 (18) 支付，\(\alpha>5/6\) 的 collar 按上段变差论证为 \(O_\varepsilon(Y^{2\sigma+2\alpha-4/3+\varepsilon})=O(Y^{2+\varepsilon})\)。因此任一固定幂环的目标门只需要对应的**条件性**全局 Mertens 指数 \(\sigma\le1-\alpha/2\)；当前无条件零自由区不给这种固定指数。该充分条件仍未证明算术门。

**未决算术门。** (3) 与每个 (8) 的系数仍是随 \(N\) 截断的 \(\Delta M_{m,h}(N)\)。命题 5 的联合均方任意对数幂节省仍未将 \(\sum_N|\mathcal W^{\rm rat}_{D,N}|^2\) 或 \(\sum_N|\mathcal W^{(J)}_{D,N}|^2\) 压至 \(Y^{2+\varepsilon}\)；完整 residual 门、全尺度局部 Weil 正性及 RH 均未证明。
