# 交叉对齐负有理比例的对称互素核心具有目标量级的单侧上界

日期：2026-10-01。将 [scratch/866](866-negative-mobius-cofactor-resonant-cross-covariance-is-paid.md) 的整数比例直接源共振扩展到既约 cofactor 比为 $a/b$ 的**对称互素核心**。使用 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的精确 $b_d(m)$ 与无符号过滤预算，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的远差支付。式 (2) 的共同阈值与共同互素条件强于原 Gram 两侧分别所需的条件，因此本文只给这个真实 signed 子族的**单侧**目标界；不能把负主项删除后当作完整门的上界。精确范围与论证已获独立只读复核；非对称部分见 [scratch/874](874-asymmetric-rational-alignment-reduces-to-coprimality-defects.md)。

## 定理

固定实函数 $\psi\in C_c^3((1,2))$。令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，沿用 scratch/859 的 $D=\lfloor M/(16H)\rfloor$、$b_d(m)$、$R=\lfloor H^2/\log^4(2M)\rfloor$、$K_0=H^3/\log^7(2M)$，以及 scratch/860 的 $w_H,J_H,K_{s,2}$。定义对全部 $k\ge1$ 正的 cofactor 权
\[
\alpha(k)=4\log k-2\mathbf1_{2\mid k}\log(k/2)
+4(\log2)\mathbf1_{k=1}>0.
\tag{1}
\]
对 $(a,b)=1$、$a,b,t\ge1$ 且 $\mu(ab)=-1$，令
\[
U_{a,b,t}=\{u\in\mathbb N:u>D/\min(a,b),\ (u,ab)=1,\ M<abtu<2M\},
\quad
F_{a,b,t,h}=\sum_{u\in U_{a,b,t}}\mu(u)\phi(abtu/M)e(-habtu/M).
\tag{2}
\]
只考虑 $U_{a,b,t}\ne\varnothing$ 的有限三元组。在 scratch/859 式 (12) 的**有序**剩余门中，取全部以下物理项：
\[
d=bu,\qquad e=av,\qquad m=abtu,\qquad n=abtv,
\qquad u,v\in U_{a,b,t},
\tag{3}
\]
并施加原门的 $d\nmid e$、$e\nmid d$、最大约化比例 $>R$、$K_0<|m-n|\le K_{s,2}$。记这些项的 signed 和为 $\mathfrak T^-_{M,H}$。则
\[
\boxed{\quad
\mathfrak T^-_{M,H}
=-\frac1{M^2}\sum_{\substack{(a,b)=1,\ \mu(ab)=-1\\t\ge1}}
\alpha(at)\alpha(bt)\sum_h w_H(h)|F_{a,b,t,h}|^2
+O_{s,\psi}\!\left(
\frac{H^2\log^3(2M)}M
+\frac{H^4}{M\log^2(2M)}+M^{-2}
\right).
\quad}\tag{4}
\]
因此整个子族一致满足
\[
\boxed{\quad
\mathfrak T^-_{M,H}
\ll_{s,\psi}\frac{H^4}{M\log^2(2M)}
=o(H^4/M).
\quad}\tag{5}
\]
式 (5) 是上界，不是绝对值界。$(a,b,t)=(q,1,1)$ 正是 scratch/866 式 (2)；$b=1,t\ge2$ 为新增整数比例，$a,b>1$ 为新增非整数比例。原门中 $bu>D$、$av>D$ 只要求两侧不同阈值；本文的 $u,v>D/\min(a,b)$ 更强，并且还排除了 $u$ 或 $v$ 与 $ab$ 不互素的非零项。这些漏项不能由 (5) 支付。$\mu(ab)=+1$、未对齐源索引及不同物理位置的交叉项也未估计。

## 证明

对 $m=kd$，scratch/859 式 (2) 逐点给
\[
b_d(kd)=-\frac{\alpha(k)}M\phi(kd/M).
\tag{6}
\]
确实 $k=1$ 时仅有直接 $-4\log2$ 项；$k\ge2$ 时 $\alpha(k)=4\log k-2\mathbf1_{2\mid k}\log(k/2)>0$。对 (3)，式 (6) 给
$b_{bu}(abtu)=-\alpha(at)\phi(abtu/M)/M$ 与
$b_{av}(abtv)=-\alpha(bt)\phi(abtv/M)/M$。又 $(u,ab)=(v,ab)=1$、$\mu(ab)=-1$，故
$\mu(bu)\mu(av)=\mu(ab)\mu(u)\mu(v)=-\mu(u)\mu(v)$。

先不施加 (3) 后的剩余门过滤。固定 $(a,b,t)$ 时其有序物理子和精确为
\[
\begin{aligned}
&\sum_{u,v\in U_{a,b,t}}\mu(bu)\mu(av)
b_{bu}(abtu)b_{av}(abtv)J_H(abt(u-v))\\
&\hspace{12mm}=-\frac{\alpha(at)\alpha(bt)}{M^2}
\sum_h w_H(h)|F_{a,b,t,h}|^2\le0.
\end{aligned}\tag{7}
\]
不同 $(a,b,t)$ 的源与物理四元组 $(d,e,m,n)$ 不重叠：若一个四元组属于 (3)，令 $k=m/d$、$l=n/e$，则 $t=(k,l)$、$a=k/t$、$b=l/t$ 唯一确定；$u=d/b$、$v=e/a$ 随之唯一。求和有限，因为 $bu>D$、$m=at\,bu<2M$ 及对称条件强制 $\max(a,b)t<2M/D\ll H$。于是对全部三元组可直接合并 (7)，没有重复计数。

从完整子和删去原门过滤之外的项。由于上段的不重叠性，删除的绝对代价至多是 scratch/859 对**全部**高除数物理项已经证明的预算：对角源由式 (8) 支付，非对角整除源由式 (8a) 支付，合为 $O_\psi(H^2\log^3(2M)/M)$；低约化比例为 $O_\psi(H^4/(M\log^2(2M)))$，近物理差 $|m-n|\le K_0$ 为 $O_\psi(H^4/(M\log^2(2M)))$，远物理差 $|m-n|>K_{s,2}$ 由 scratch/860 为 $O_{s,\psi}(M^{-2})$。合并便得 (4)。各主项非正，而 $H^2\log^3M/M=o(H^4/(M\log^2M))$，所以 (5) 成立。$\square$

这个结论扩展了可单侧支付的实际负共振集合，但不允许从完整 signed 和中独立删去该负集合：它可能正好支付其余正块。完整交叉对齐族的非对称阈值项及互素条件不匹配项还须处理。
