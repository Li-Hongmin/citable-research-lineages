# 多项式素数分数带的真实旧奇压缩只有次线性多个潜在负方向（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的偶极算术图与 Archimedean 估计、[scratch 802](802-higher-prime-power-shifts-have-bounded-cost-in-polynomial-outer-bands.md) 的高次素数幂算子界。本文只给有限主压缩的负指标上界，不证明它全正。

后续的同模型独立复核与加强见 [scratch 804](804-polynomial-prime-fraction-band-negative-index-and-sparse-positivity-candidate.md)：固定比例 \(x\asymp p\) 使全部同臂平移只有 \(O(1)\) 成本，背景谱隙加强为 \(2\log p-O(1)\)。以下保留原候选推导供定位。

## 命题

固定 \(0<\delta<1/2\)、\(0<\theta_-<\theta_+<1\) 和 \(0<A_1<A_2\)。令 \(p\to\infty\) 沿奇素数，\(k=p^2\)，定义
\[
\mathcal X_p=
\left\{\frac qb:
\begin{array}{l}
q\ {\rm prime},\quad A_1p^{1+\delta}<q<A_2p^{1+\delta},\\
b\in\mathbb N,\quad \theta_-p<q/b<\theta_+p
\end{array}\right\},
\qquad Z_p=\operatorname{span}\{w_x:x\in\mathcal X_p\}.
\tag{1}
\]
记 \(M_p=\dim Z_p\)，\(B_p=P_{Z_p}A_{k,-}P_{Z_p}|_{Z_p}\)。则 \(\{w_x\}_{x\in\mathcal X_p}\) 是正交单位族，
\[
M_p\asymp_{\delta,A_1,A_2,\theta_\pm}\frac{p^{1+2\delta}}{\log p},
\tag{2}
\]
且完整真实旧奇主压缩的负指标满足
\[
\boxed{
n_-(B_p)\ll_{\delta,A_1,A_2,\theta_\pm}
\frac{M_p^2}{p^2}
\asymp\frac{p^{4\delta}}{\log^2p}
=o(M_p).}
\tag{3}
\]
更精确地，可写 \(B_p=B_{0,p}+P_p^{\rm prime}\)，其中
\[
B_{0,p}\succeq (2-\delta-o(1))(\log p)I,\qquad
\operatorname{Tr}\bigl((P_p^{\rm prime})^2\bigr)
\ll M_p^2\frac{\log^2p}{p^2}.
\tag{4}
\]
\(P_p^{\rm prime}\) 只含异臂素数平移；(3) 不限制其最大负本征值。
事实上存在 \(E_p\subset Z_p\)，其余维数满足
\[
\boxed{
\operatorname{codim}_{Z_p}E_p\ll M_p^2/p^2,\qquad
B_p|_{E_p}\succeq
\left(\frac{2-\delta}{2}-o(1)\right)(\log p)I.}
\tag{4a}
\]

## 证明

由 (1)，每个分母 \(b\asymp p^\delta\)，且 \(q>b\) 为素数，故 \(q/b\) 已约分。两不同分数 \(q/b,q'/b'\) 的同臂整数对为 \(qb',q'b\ll p^{1+2\delta}=o(p^2)\)。它们不相等时对数距离大于 \(2\Delta=\log(1+p^{-2})\)；异臂中心距离至少 \(2\log(\theta_-p)\gg\Delta\)。所有偶极均完整位于 \((1,k)\)，故它们正交且单位化。

素数定理给 \(\#\{q\} \asymp p^{1+\delta}/\log p\)。对每个此类 \(q\)，(1) 的分母区间
\[
\frac q{\theta_+p}<b<\frac q{\theta_-p}
\]
含 \(\asymp p^\delta\) 个整数，故 (2) 成立。

令 \(H=\log p\)、\(D_k=2H+1-\gamma_E-\log\pi\)。不同物理中心的最小同臂对数间距为 \(\gg p^{-(1+2\delta)}\)，而 \(\Delta\asymp p^{-2}\)。note 791 式 (12) 的双零矩界及中心排序遂给
\[
P_{Z_p}G_kP_{Z_p}=(D_k+\log2)I+o_{\rm op}(1).
\tag{5}
\]
每个偶极的 polar 投影为 \(O(p^{-5/2})\)；由 \(M_p\ll p^{1+2\delta}\) 得 polar 压缩范数 \(o(1)\)。

同臂素数幂关系若非精确，则清除分母后留下非零整数差，但 \(qb',q'b=o(p^2)\) 使 \(2\Delta\) 内的部分重叠不可能。若精确且 \(q\ne q'\)，\(q'/q\) 无法由小于 \(q,q'\) 的 \(b,b'\) 约掉，所以也不可能。对同一 \(q\)，精确同臂图只含 \(b'/b\) 或 \(b/b'\) 为素数幂的边。先令 \(C_p\) **只含其中素数 \(n=\ell\) 的非负权边**。以 \(h_{q,b}=(qb)^{-1/2}\) 作 Schur 检验，舍去实际分母区间的下界只会增大行和，得到
\[
\frac{(C_ph)_{q,b}}{h_{q,b}}
\le\log b+\sum_{n\le B/b}\frac{\Lambda(n)}n
\le\log B+O(1)=\delta H+O(1),
\tag{6}
\]
其中 \(B=\max\{b:x\in\mathcal X_p\}\ll p^\delta\)。于是 \(\|C_p\|\le\delta H+O(1)\)。

全部高次素数幂部分，包括同臂与异臂，由 scratch 802 式 (3) 有 \(O(1)\) 算子范数。将 (5)--(6)、polar 界及这项组成 \(B_{0,p}\)，得到 (4) 的下界。

剩余异臂素数边满足 \(n\asymp p^2\)。对任意 \(x,y\in\mathcal X_p\)，重叠要求 \(|\log(xy/n)|<2\Delta\)。允许的整数 \(n\) 落在长度 \(O_{\theta_\pm}(1)\) 的区间，因此至多 \(O_{\theta_\pm}(1)\) 个；每个权
\(\Lambda(n)/\sqrt n\ll H/p\)，自相关绝对值至多一。所以在正交基 \(\{w_x\}\) 中，
\[
|P_p^{\rm prime}(x,y)|\ll_{\theta_\pm} H/p.
\tag{7}
\]
逐项平方求和给 (4) 的迹界。

最后，若 \(B_p\) 有 \(d\) 维负子空间，则在该空间任意单位向量上
\(\langle v,P_p^{\rm prime}v\rangle\le-(2-\delta-o(1))H\)。
按 min--max，\(P_p^{\rm prime}\) 至少有 \(d\) 个本征值不大于此负阈值。因而
\[
d(2-\delta-o(1))^2H^2
\le\operatorname{Tr}\bigl((P_p^{\rm prime})^2\bigr)
\ll M_p^2H^2/p^2,
\]
即 (3)。再令 \(E_p\) 为 \(P_p^{\rm prime}\) 中本征值大于
\(-\frac12(2-\delta)H\) 的谱子空间。同一迹界给其余维数
\(O(M_p^2/p^2)\)，而 (4) 的 \(B_{0,p}\) 下界给 \(E_p\) 上的 (4a)。\(\square\)

## 可增长窄带的完整主压缩正性

同一证明还给出一个全正范围。令 \(T_p\to\infty\) 且
\[
T_p^2=o(\log p),
\tag{8}
\]
把 (1) 的素数区间改为 \(A_1pT_p<q<A_2pT_p\)，仍要求
\(\theta_-p<q/b<\theta_+p\)，并把相应压缩记为 \(B_p(T_p)\)。
此时 \(b\asymp T_p\)，素数定理给 \(M_p(T_p)\ll pT_p^2/\log p\)。
同臂整数对 \(qb',q'b\ll pT_p^2=o(p^2)\)，所以偶极仍正交，
而 (5) 的 Archimedean 误差为 \(O(T_p^4/p^2)=o(1)\)。
精确同臂图的范数至多 \(\log T_p+O(1)\)；scratch 802 的高次素数幂
仍只有 \(O(1)\)。异臂素数矩阵满足 (7)，故
\[
\|P_p^{\rm prime}\|
\le\|P_p^{\rm prime}\|_{\rm HS}
\ll M_p(T_p)\frac{\log p}{p}
\ll T_p^2.
\]
polar 压缩仍为 \(o(1)\)。于是
\[
\boxed{
B_p(T_p)\succeq
\bigl(2\log p-O(T_p^2+\log T_p+1)\bigr)I
=(2-o(1))(\log p)I>0.}
\tag{9}
\]
式 (9) 是增长到 \(q\asymp pT_p\) 的真实旧奇**主压缩**正性；
完整算子仍可能因这批槽与其正交补的 Schur 反馈而失去正性。

## 边界

对固定 \(\delta>0\) 的多项式带，只有负指标比例趋零，不代表 \(B_p\succeq0\)；一个负方向就足以妨碍全尺度 Weil 正性。式 (9) 虽给增长窄带的全正主压缩，仍未控制其正交补 Schur 反馈。证明留在 scratch，未经过异源复核。

## 极端负方向必须跨越线性多个槽

式 (7) 还给出一个与负指标不同的局部正性结论。存在只依赖固定参数的常数 \(c>0\)，使充分大 \(p\) 时，\(Z_p\) 中任意在至多 \(cp\) 个 \(w_x\) 上有非零坐标的向量 \(v\) 都满足
\[
\boxed{\langle v,B_pv\rangle\ge\frac{2-\delta}{4}(\log p)\|v\|^2.}\tag{10}
\]
相应地，任何满足 \(\langle v,B_pv\rangle\le0\) 的非零向量必有
\[
\boxed{\|v\|_1^2\gg p\|v\|_2^2,\qquad
|\operatorname{supp}v|\gg p.}\tag{11}
\]
这里的 \(\ell^1,\ell^2\) 范数是相对于正交基 \(\{w_x\}\) 的坐标范数。因此所有阶数不超过 \(cp\) 的坐标主子矩阵都有对数量级正谱隙；特别地，固定或少于 \(cp^{1-\delta}\) 个分子素数所生成的整块也有此性质，常数可依赖 (1) 的固定参数。

证明只用 (4) 与 (7)。取 \(g=(2-\delta)/2>0\)，对充分大 \(p\) 有 \(B_{0,p}\succeq g(\log p)I\)。由 (7) 取常数 \(C\) 使 \(|P_p^{\rm prime}(x,y)|\le C(\log p)/p\)。于是任意 \(v\) 满足
\[
\langle v,B_pv\rangle
\ge g(\log p)\|v\|_2^2
-\frac{C\log p}{p}\|v\|_1^2.
\tag{12}
\]
若 \(|\operatorname{supp}v|\le cp\)，Cauchy--Schwarz 给出 \(\|v\|_1^2\le cp\|v\|_2^2\)。取 \(c\le g/(2C)\) 得 (10)，因为 \(g/2=(2-\delta)/4\)。若左侧非正，(12) 反给 \(\|v\|_1^2\ge(g/C)p\|v\|_2^2\)，再用 \(\|v\|_1^2\le|\operatorname{supp}v|\|v\|_2^2\) 得 (11)。每个固定 \(q\) 在 (1) 中只对应 \(O(p^\delta)\) 个分母，故最后一个断言也成立。\(\square\)

这仍是有限主压缩的结论。它把潜在的负本征值归于跨至少线性多个槽的异臂素数有符号相关；它不估计该相关的极端本征值，也不控制 \(Z_p^\perp\) 的 Schur 反馈。
