# 真实 Farey 倒数频率的一分子整带负协方差：候选证明

日期：2026-09-30。此稿依赖 [固定幂短块候选稿](all-fixed-power-farey-block-covariance-down-to-four-fifths-candidate.md) 的全块前缀界与素数能量、[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 式 (12) 的一致互素 Möbius 调和界，以及 [notes 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md)、[833](../notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md) 的真实系数。下述跨块分部求和是新步骤；整条证明尚待异源复核，不晋级永久定理。本文只处理既约分子 \(1\)，不估计完整斜楔 \(\mathcal V_N\) 或证明 RH。

## 命题

固定 \(4/5<\alpha<1\)，取
\[
D=\lfloor Y^\alpha\rfloor,\quad
B=\left\lfloor\frac{D^2}{1000Y}\right\rfloor,\quad
L=\lfloor Y^{5/6}\rfloor,\quad Y<N\le2Y.
\tag{1}
\]
令 \(F_{q,N}=-C_q(N)(\pi N)^{-1}\cos(2\pi N/q)\)，其中 \(C_q(N)\) 是 note 833 式 (1) 的**真实物理裁剪系数**；令
\[
T_{D,N}=\sum_{D/2<q\le D}F_{q,N}.
\tag{2}
\]
则对每个固定 \(A>0\)，
\[
\boxed{\quad
\sum_{Y<N\le2Y}|T_{D,N}|^2
\ll_{\alpha,A}\frac{D^5}{Y^2(\log Y)^A}.
\quad}\tag{3}
\]
进一步，对**每个**长度 \(B\) 的整数块 \(I\subset(D/2,D]\)，写
\(G_{I,N}=\sum_{p\in I,\ p\text{ prime}}F_{p,N}\)，
\(E_I=\sum_NG_{I,N}^2\)，则一致于全部这些块，
\[
E_I\asymp_\alpha\frac{D^6}{Y^3\log^2Y},\qquad
\boxed{\quad
\big|\sum_NG_{I,N}T_{D,N}\big|
\ll_{\alpha,A}\frac{E_I}{(\log Y)^A}.
\quad}\tag{4}
\]
因而整条 dyadic 分母带而非仅同一短块的真实补集都给出
\[
\sum_NG_{I,N}(T_{D,N}-G_{I,N})
=-\bigl(1+O_{\alpha,A}((\log Y)^{-A})\bigr)E_I.
\tag{5}
\]
同一论证覆盖固定 \(c>2\) 的临界常数带 \(D=\lfloor cY^{4/5}\rfloor\)：式 (3) 右端成为 \(O_{c,A}(Y^2(\log Y)^{-A})\)，而 (4)--(5) 对所有完整块成立。这一带全部在 note 832 的 \(q>Y^{4/5}\) 斜楔内。

式 (3) 比逐块点态界再用三角不等式所得 \(O_A(D^4/(Y\log^A Y))\) 少 \(Y/D\) 的幂级因子；但 \(D=Y^\alpha\)、\(\alpha>4/5\) 时其 \(Y\) 指数仍为 \(5\alpha-2>2\)。它不能支付完整 moving-\(N\) 均方门。

## 1. 单块包络及随 \(N\) 的总变差

把 \((D/2,D]\cap\mathbf Z\) 划成相邻的长 \(B\) 块 \(J_j\) 和至多一个尾部短块，左端记 \(t_j\)。尾块的任意前缀是 \((D-B,D]\) 中两个前缀之差；因此固定幂短块候选稿式 (7) 给所有 \(J_j\) 与其前缀一致的
\[
\max_{z\in J_j}\left|\sum_{t_j<q\le z}f_\kappa(q)\right|
\ll_{\alpha,K}\frac{B}{(\log Y)^K}
\qquad(K>0),
\tag{6}
\]
其中 \(f_\kappa(q)=\kappa_q\mu(q)q/\varphi(q)\)。对临界常数带使用该候选稿已经核算的 \(\beta=3/4\) 情形。记 \(e(x)=e^{2\pi i x}\)、\(\delta_{j,q}=1/q-1/t_j\)。全部 \(q\in J_j\) 满足 \(|\delta_{j,q}|\ll B/D^2\ll1/Y\)。

需要一项随移动截止的有界变差估计。设
\[
\eta_Y=e^{-c_\alpha\omega(Y)},\quad
\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5},\quad
\rho_Y=\eta_Y+(\log Y)^2(D/Y)^2+L/Y+(L/Y)^2+DL/Y^2.
\tag{7}
\]
固定 \(\alpha<1\) 时 \(\rho_Y\ll_{\alpha,K}(\log Y)^{-K}\) 对所有固定 \(K\) 成立。固定幂短块候选稿式 (8) 给
\[
\sup_{Y<N\le2Y}|C_q(N)+qf_\kappa(q)|\ll_\alpha q\rho_Y
\qquad(D/2<q\le D).
\tag{8}
\]
还成立离散总变差
\[
\sum_{Y<n<2Y}|C_q(n+1)-C_q(n)|\ll_\alpha q\rho_Y.
\tag{9}
\]
为核对 (9)，先在 cutoff 集合 \(kq\le N-L\) 不变的实 \(N\) 段求导。note 800 式 (12) 对 \(K_0=(N-L)/q\gg Y^{1-\alpha}\) 及奇偶拆分同时给
\[
\sum_{k\le K_0}\frac{\mu(kq)}k=O_\alpha(\eta_Y),\qquad
\sum_{\substack{k\le K_0\\2\mid k}}\frac{\mu(kq)}k=O_\alpha(\eta_Y).
\tag{10}
\]
平方因子 \(q\) 时两和直接为零。对 note 833 式 (1) 的 \(\log(N/kq)\) 求导产生 \(1/N\) 乘 (10)；两个有理括号的导数为 \(O(q^2/N^3)\)，而原始 \(k^{-1}\log(N/kq)\) 和的绝对值至多 \(O((\log Y)^2)\)。因此每个光滑段上
\[
|C'_q(N)|\ll_\alpha \frac qY
\left[\eta_Y+(\log Y)^2(D/Y)^2\right].
\tag{11}
\]
当 \(N\) 越过 \(kq+L\) 时，新添一项的绝对值至多
\[
\frac qk\log\left(1+\frac L{kq}\right)O(1)
\ll\frac{q^2L}{Y^2}.
\tag{12}
\]
这样的 \(k\) 在 \((Y,2Y]\) 中至多 \(Y/q+1\) 个，跳跃总量 \(O(qL/Y)\)。积分 (11) 并加 (12) 即得 (9)。

定义去载波包络
\[
U_j(n)=\sum_{q\in J_j}C_q(n)e(n\delta_{j,q}),
\qquad
\operatorname{Var}U_j=\sum_{Y<n<2Y}|U_j(n+1)-U_j(n)|.
\tag{13}
\]
对任意固定 \(K>0\)，由 (6)--(9) 得
\[
\boxed{\quad \|U_j\|_\infty+\operatorname{Var}U_j
\ll_{\alpha,K}\frac{BD}{(\log Y)^K}=:A_K.\quad}
\tag{14}
\]
详细地，主项 \(-\sum_{q\in J_j}qf_\kappa(q)e(n\delta_{j,q})\) 的权 \(q e(n\delta_{j,q})\) 有上确界 \(O(D)\)、\(q\) 变差 \(O(D+BY/D)=O(D)\)，故 (6) 给其上确界 \(O(BD/\log^K Y)\)。相邻两个 \(n\) 的权之差为 \(q(e(\delta_{j,q})-1)e(n\delta_{j,q})\)，上确界及 \(q\) 变差均为 \(O(B/D)\)；对 \(O(Y)\) 个 \(n\) 求和给 \(O(YB^2/(D\log^K Y))=O(BD/\log^K Y)\)。余项上确界用 (8) 逐 \(q\) 求和为 \(O(BD\rho_Y)\)；其随 \(n\) 的变差用 (9) 与 \(|e(\delta)-1|\ll B/D^2\)，也是 \(O(BD\rho_Y)\)。

对任意长度 \(B\) 的素数块 \(I=(t,t+B]\)，同样定义
\[
V_I(n)=\sum_{p\in I\atop p\text{ prime}}C_p(n)e(n(1/p-1/t)).
\tag{15}
\]
因 \(C_p(n)=5p+o(p)\)、素数数目 \(v_I\asymp B/\log D\)，由 (9) 和 \(|1/p-1/t|\ll1/Y\)，
\[
\|V_I\|_\infty+\operatorname{Var}V_I
\ll_\alpha v_ID\asymp_\alpha\frac{BD}{\log Y}=:A_P.
\tag{16}
\]

## 2. 跨载波分部求和

若两个序列 \(U,V\) 在 \(Y<n\le2Y\) 上满足
\(\|U\|_\infty+\operatorname{Var}U\le A\)、
\(\|V\|_\infty+\operatorname{Var}V\le B_0\)，离散 Abel 求和及几何和界给
\[
\left|\sum_{Y<n\le2Y}\frac{U(n)V(n)}{n^2}e(n\theta)\right|
\ll \frac{AB_0}{Y}
\min\!\left\{1,\frac1{Y\|\theta\|_{\mathbf R/\mathbf Z}}\right\}.
\tag{17}
\]
这里 \(\|UV/n^2\|_\infty+\operatorname{Var}(UV/n^2)\ll AB_0/Y^2\)，而相位部分和 \(\ll\min(Y,1/\|\theta\|)\)。\(\theta=0\) 时第二项按 \(+\infty\) 解释。

将每块余弦拆成正、负指数。载波 \(t_i,t_j\in[D/2,D]\) 的同号配对使用
\(\theta=1/t_i-1/t_j\)，异号配对使用 \(\theta=1/t_i+1/t_j\)。对于相邻长块，\(t_j-t_i=(j-i)B\)，且所有频率都小于 \(1/2\)，所以
\[
\min\left(1,\frac1{Y|1/t_i-1/t_j|}\right)
\ll\min\left(1,\frac{1000}{|i-j|}\right),
\qquad
\min\left(1,\frac1{Y(1/t_i+1/t_j)}\right)
\ll\frac DY.
\tag{18}
\]
尾部短块仍按左端距整数个 \(B\) 的分隔处理。块数 \(M\asymp D/B\asymp Y/D\)；故每一行的权和为
\[
\sum_j\left[
\min\left(1,\frac{1000}{|i-j|}\right)+\frac DY
\right]\ll\log(2M),
\tag{19}
\]
因为 \(MD/Y\asymp1\)。任意滑动素数块 \(I\) 的左端 \(t\) 代替 \(t_i\) 时，同一行和仍为 \(O(\log(2M))\)：至多两个 \(t_j\) 距 \(t\) 小于 \(B\)，其余按距离为 \(mB\) 求和。

由 \(F_{q,n}\) 的实余弦展开、(14)、(17)--(19)，
\[
\sum_n|T_{D,n}|^2
\ll M\frac{A_K^2}{Y}\log(2M)
\ll_{\alpha,K}\frac{D^5}{Y^2(\log Y)^{2K-1}}.
\tag{20}
\]
取 \(K\) 足够大即得 (3)。再由 (16)--(19)，对每个滑动块一致有
\[
\big|\sum_nG_{I,n}T_{D,n}\big|
\ll_{\alpha,K}\frac{A_PA_K}{Y}\log(2M)
\ll_{\alpha,K}\frac{B^2D^2}{Y(\log Y)^K}.
\tag{21}
\]
固定幂短块候选稿给 \(E_I\asymp B^2D^2/(Y\log^2Y)\)；取 \(K>A+2\) 证明 (4)，继而由恒等式 \(\langle G_I,T_D-G_I\rangle=\langle G_I,T_D\rangle-E_I\) 得 (5)。

## 包络法本身不能降低 \(D^5/Y^2\) 幂次

式 (20) 的幂次在只知道包络幅度与总变差 (14) 的抽象层面上不能改善。下面的测试包络仍使用**真实倒数分母载波**，但不是 Möbius 系数。为清楚起见令 \(Y\) 为整数，并取 \(Y^{4/5}\le D\le Y^{1-\delta}\)，其中 \(\delta>0\) 固定。设 \(B=\lfloor D^2/(1000Y)\rfloor\)、\(A_\star=BD\exp[-\sqrt{\log Y}]\)；这个幅度对**每个**固定 \(K>0\) 都有 \(A_\star\ll_K BD/(\log Y)^K\)。取整数集
\[
\mathcal M=\{m:\lceil Y/D\rceil+1\le m\le\lfloor2Y/D\rfloor-1\},
\qquad t_m=\operatorname{round}(Y/m).
\tag{22}
\]
有 \(J:=|\mathcal M|\asymp Y/D\)、\(t_m\in(D/2,D)\)，相邻 \(t_m\) 至少相距 \(\gg D^2/Y\gg B\)，且
\[
\left|\frac1{t_m}-\frac mY\right|\ll\frac1{D^2}.
\tag{23}
\]
这些 \(t_m\) 可作两两不交的长 \(B\) 块左端；中间未选的块包络均取零。给每个选中的载波赋常数包络 \(U_m(N)=A_\star\)（总变差为零）。对应的实信号为
\[
S_N=\frac{A_\star}{N}\sum_{m\in\mathcal M}\cos\frac{2\pi N}{t_m}.
\tag{24}
\]
将 \(1/t_m\) 换成 \(m/Y\) 得 \(S_N^0\)。这些正频率均小于 \(1/2\)，不同 \(m\) 的正负频率在 \(Y\) 个连续整数上正交。因此
\[
\sum_{N=Y+1}^{2Y}|S_N^0|^2
\ge\frac{A_\star^2}{(2Y)^2}\cdot\frac{YJ}{2}
=\frac{A_\star^2J}{8Y}.
\tag{25}
\]
由 (23) 与余弦的 Lipschitz 界，
\[
\|S-S^0\|_{\ell^2_N}
\ll\frac{A_\star\sqrt Y J}{D^2}
=o\!\left(A_\star\sqrt{J/Y}\right),
\tag{26}
\]
因为 \(Y\sqrt J/D^2\asymp Y^{3/2}/D^{5/2}\to0\)。由 (25)--(26)，
\[
\boxed{\quad
\sum_{N=Y+1}^{2Y}|S_N|^2
\gg\frac{A_\star^2J}{Y}
\asymp\frac{D^5}{Y^2}e^{-2\sqrt{\log Y}}.
\quad}\tag{27}
\]
对任意固定 \(\eta>0\)，式 (27) 的右端都大于 \(D^5Y^{-2-\eta}\) 一个趋于无穷的因子。故单凭 (14) 的**任意对数幂**包络界与载波间距，不能推出 \(D^5/Y^2\) 之外的固定幂节省。这个测试只关闭**抽象包络推理**，不说明真实 Möbius 包络饱和 (27)；后者仍须新的算术协方差输入来判断。

## 回顾：真实进展及剩余门

逐块估计之和本来是 \(D^5/(Y^2\log^2Y)\)，确实高于 \(Y^2\) 当 \(\alpha>4/5\)。上面的包络变差给整带真和额外任意对数幂节省，并证明**任意单个素数短块与整条同分子分母带的联合补集**有等量负协方差。它没有证明整带素数和本身有相同量级的能量；不同素数块可相互抵消。因此不能由 (5) 推出整条 \(q\)-带的素数--合数负协方差相对于整带素数能量的渐近式。[后续全斜楔候选稿](sloping-farey-wedge-log-savings-candidate.md) 把同带其他既约分子也纳入对数节省，但仍未支付 \(D^5/Y^2\) 之外的固定幂和跨带作用。式 (27) 表明仅改进本稿的包络正交步骤不可能创造该幂次；下一项决定性任务必须加入真实 Möbius 包络之间的算术协方差。
