# 宏观整数对数割的线性 Weil 补槽交叉

日期：2026-10-03。依赖 [notes 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) 的完整闭形式，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的精确整除矩阵与单槽界，以及 [notes 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)、[858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的自然权极限与轮廓谱隙。本文是解析证明草稿，尚未异源复核，不晋级为权威 note，也不证明或反驳 RH。它将 [scratch 976](976-dyadic-weil-gap-has-a-square-root-logarithmic-complement-coupling.md) 的特定 dyadic 切分放入一个任意整数槽切分的恒等式，并给出更大的宏观交叉。

## 定理

固定 $0<\theta<1$、非负实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$。沿奇素数 $p\to\infty$ 取
\[
 H=\log p,\quad N=\lfloor p^2/2\rfloor-1,\quad
 \ell=2\theta/p^2,\quad L_N=\sum_{n\le N}n^{-1},\quad
 y_n=H-\log(2n),
\]
并在互不相交的槽 $I_n=y_n+(-\ell/2,\ell/2)$ 上定义
\[
 b_\ell(t)=\ell^{-1/2}\varphi(t/\ell),\qquad
 F(y_n+t)=\frac{b_\ell(t)}{\sqrt{nL_N}}\quad(1\le n\le N),
\]
其余处为零。对任意 $E\subset\{1,\ldots,N\}$，令 $F_E$、$F_{E^c}$ 为对应槽限制，并定义精确的整除割边权
\[
 \mathcal C_N(E)=\frac1{L_N}
 \sum_{\substack{n<r\le N,\ n\mid r\\
                \mathbf1_E(n)\ne\mathbf1_E(r)}}
 \frac{\Lambda(r/n)}r.                                      \tag{1}
\]
则以下误差对**所有** $E$ 一致：
\[
 \boxed{Q_W^H[F_E]=\mathcal C_N(E)+O_{\theta,\varphi}(1),\quad
 Q_W^H[F_{E^c}]=\mathcal C_N(E)+O_{\theta,\varphi}(1),\quad
 Q_W^H(F_E,F_{E^c})=-\mathcal C_N(E)+O_{\theta,\varphi}(1).} \tag{2}
\]
并且完整向量有极限
\[
 Q_W^H[F]\longrightarrow
 L_{\theta,\varphi}:=\log(1/\theta)+C_\varphi+\gamma-\log(2\pi)
   +\theta\kappa_\varphi^2
 \ge \frac{46}{25}-\log(2\pi)>0,                         \tag{3}
\]
其中 $\kappa_\varphi=\int\varphi$，
$C_\varphi=\int\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)$。
若 $\mathcal C_N(E)\to\infty$，则
\[
 \inf_{t\in\mathbb R} Q_W^H[F_E+tF_{E^c}]
 =L_{\theta,\varphi}+o(1),\qquad
 t_{\min}=1+O_{\theta,\varphi}(\mathcal C_N(E)^{-1}).       \tag{4}
\]

特别地，对固定 $0<\alpha<1$ 取 $K=\lfloor N^\alpha\rfloor$、
$E=\{1,\ldots,K\}$，则
\[
 \boxed{\mathcal C_N(E)=\alpha(1-\alpha)\log N+O_\alpha(1).} \tag{5}
\]
这个压缩槽并集 $U=\bigcup_{n\le K}I_n$ 的**全部有限能量轮廓**满足
\[
 \boxed{\inf_{0\ne f\in D(Q_W^H),\ \operatorname{supp}f\subset U}
 \frac{Q_W^H[f]}{\|f\|_2^2}
 =(1-\alpha)\log N+O_{\alpha,\theta,\varphi}(1).}       \tag{6}
\]
式 (6) 的下界常数事实上与 $\varphi$ 无关。与此同时，两个实际归一化方向之间的交叉为
\[
 \boxed{Q_W^H\!\left(\frac{F_E}{\|F_E\|_2},
                       \frac{F_{E^c}}{\|F_{E^c}\|_2}\right)
 =-\sqrt{\alpha(1-\alpha)}\log N+O_{\alpha,\theta,\varphi}(1).} \tag{7}
\]
在 $\alpha=1/2$ 时，切分位置 $y_K=O(1)$，其绝对交叉值为 $H+O_{\theta,\varphi}(1)$，而式 (4) 的显式补槽方向支付了 $\frac14\log N+O(1)$ 的 Schur 扣款。
更精确地，若 $G_{N,\alpha}$ 是 $F_E/\|F_E\|_2,F_{E^c}/\|F_{E^c}\|_2$ 的 $2\times2$ Weil 压缩矩阵，其两个本征值满足
\[
 \boxed{\lambda_{\max}(G_{N,\alpha})=\log N+O(1),\qquad
 \lambda_{\min}(G_{N,\alpha})\longrightarrow L_{\theta,\varphi}>0.} \tag{8}
\]

取 [scratch 976](976-dyadic-weil-gap-has-a-square-root-logarithmic-complement-coupling.md) 的 $S=\{2^ja:0\le j\le R,\ a\le M\text{ 奇}\}$、$R=\lceil\log_2H\rceil$ 时，式 (1) 还给
$\mathcal C_N(S)=R\log2+O(1)$，故 (2)--(4) 从另一种整除图恒等式重得该稿的三个能量主项和补槽极限。这是同源解析核对，不能替代异源复核。

## 证明

**几何与形式分解。** 奇素数给 $2N=p^2-3$，所以最外槽满足
$y_N+H=\log(p^2/(p^2-3))>\ell/2$；最内槽距右端为 $\log2>\ell/2$。最小中心间距为 $(1+o(1))/N>\ell$，因为 $\ell N\to\theta<1$。若素数幂平移使两槽相交，则对应整数指标满足 $|r-kn|<N(e^\ell-1)<1$，故 $r=kn$。因此算术部分精确等于 note 854 的整数整除矩阵 $C_N$，没有近错位边。每个 $F_E$ 都是有限个紧支撑光滑函数的和。

记 $v_n=(nL_N)^{-1/2}$、$\mu_E=\|F_E\|_2^2=\sum_{n\in E}(nL_N)^{-1}$，并令
$A(x)=\sum_{k\le x}\Lambda(k)/k$。note 854 的逐行恒等式给
\[
 \frac{(C_Nv)_n}{v_n}=A(N/n)+\log n=\log N+O(1)      \tag{9}
\]
且误差对 $1\le n\le N$ 一致。由于 $C_N$ 对称，
\[
 \langle v_E,C_Nv_E\rangle
 =\sum_{n\in E}v_n(C_Nv)_n-\langle v_E,C_Nv_{E^c}\rangle,
 \qquad
 \langle v_E,C_Nv_{E^c}\rangle=\mathcal C_N(E).        \tag{10}
\]
第二式由单条整除边 $r=kn$ 的权
$v_n(C_N)_{nr}v_r=\Lambda(k)/(rL_N)$ 直接得到；边只计一次，因而极化中没有额外因子 $2$。式 (9)--(10) 给
\[
 Q_{\rm prime}[F_E]=-\log N\,\mu_E+\mathcal C_N(E)+O(\mu_E),
 \qquad Q_{\rm prime}(F_E,F_{E^c})=-\mathcal C_N(E).    \tag{11}
\]

**非算术项的一致支付。** 单槽 Fourier--gamma 项为
\[
 D_\ell\mu_E,
 \qquad D_\ell=\log(1/\ell)+C_\varphi-\log(2\pi)+O_\varphi(\ell),
\]
其中 $D_\ell-\log N=O_{\theta,\varphi}(1)$。note 007 的普通跨槽核为
$-k(|y-z|)$，$k(t)=e^{-t/2}/(1-e^{-2t})>0$。note 857 的整数恒等式
\[
 \sum_{n\ne r\le N}\frac{k(|\log(r/n)|)}{\sqrt{nr}}
 =N\log N+O(N)
\]
及固定槽间隙给完整 $F$ 的普通项绝对值 $O_{\theta,\varphi}(1)$。
因为 $\varphi\ge0$，任何槽子集的普通自项和两个子集间的普通极化项均为非正，其绝对值被完整双和支付，故一致为 $O_{\theta,\varphi}(1)$。对 polar，记
$P_\pm(g)=\int e^{\pm y/2}g(y)dy$；完整 $F$ 的
$2P_+(F)P_-(F)=O_{\theta,\varphi}(\ell N)=O_{\theta,\varphi}(1)$。
由 $0\le F_E,F_{E^c}\le F$，各 polar 自项与极化项也一致有界。
把这些界与 (11) 相加即得 (2)。

为核定 (3) 的常数，使用 $A(x)=\log x-\gamma+o(1)$ 及 note 857 的谐波截尾论证，可将完整自然权的 prime 商加强为 $\log N-\gamma+o(1)$。普通跨槽中心核的主项为 $-\kappa_\varphi^2\ell N+o(1)=-\theta\kappa_\varphi^2+o(1)$；相邻槽的中心替换误差按 $d^{-2}$ 求和为 $O_{\theta,\varphi}(\ell^2N^2/L_N)=o(1)$。两个极点矩直接给 $2N\bigl(\int b_\ell e^{t/2}\bigr)\bigl(\int b_\ell e^{-t/2}\bigr)=2\theta\kappa_\varphi^2+o(1)$。与单槽项合成 (3) 的等号。note 858 给
$C_\varphi+\kappa_\varphi^2+\gamma-\log(2\pi)\ge46/25-\log(2\pi)$；又因 $\kappa_\varphi^2\le1$、$-\log\theta\ge1-\theta$，得到 (3) 的正下界。

若 $\mathcal C_N(E)\to\infty$，式 (2) 表明 $Q_W^H[F_{E^c}]>0$，且
$t_{\min}=-Q_W^H(F_E,F_{E^c})/Q_W^H[F_{E^c}]
=1+O(\mathcal C_N(E)^{-1})$。以 $F=F_E+F_{E^c}$ 配方，
\[
 \inf_t Q_W^H[F_E+tF_{E^c}]
 =Q_W^H[F]-Q_W^H[F_{E^c}](t_{\min}-1)^2
 =Q_W^H[F]+O(\mathcal C_N(E)^{-1}),
\]
证明 (4)。

**宏观割与全轮廓压缩。** 对 $E=\{1,\ldots,K\}$，整除边只能从 $n\le K$ 指向 $r>K$。故由 (1)
\[
 \mathcal C_N(E)
 =\frac1{L_N}\sum_{n\le K}\frac1n
  \{A(N/n)-A(K/n)\}.                                  \tag{12}
\]
一致的初等估计 $A(x)=\log x+O(1)$ 给花括号
$\log(N/K)+O(1)$，对全部 $n\le K$ 一致。又
$\sum_{n\le K}n^{-1}/L_N=\alpha+O_\alpha((\log N)^{-1})$，
$\log(N/K)=(1-\alpha)\log N+O_\alpha(1)$，所以 (5) 成立，且
$\mu_E=\alpha+O_\alpha((\log N)^{-1})$。

对支撑在 $U$ 的任意有限能量 $f$，note 854 的单槽下界、整除矩阵加权 Schur 检验分别给
$\log(1/\ell)-O(1)$ 与 $-\log K-O(1)$。普通跨槽块的 Schur 行和为
$O_\theta(\ell K\log(2K))=o(1)$；polar 的绝对形式范数由
\[
 2\|e^{y/2}\mathbf1_U\|_2\|e^{-y/2}\mathbf1_U\|_2
 \ll \ell K\sqrt{\log(2K)}=o(1)
\]
支付。于是 $Q_W^H[f]\ge(\log(N/K)-O(1))\|f\|_2^2$。
反向取 $F_E/\sqrt{\mu_E}$，由 (2)、(12) 得其 Rayleigh 商
$\mathcal C_N(E)/\mu_E+O(1)=\log(N/K)+O(1)$，证明 (6)。
最后以 $\mu_E=\alpha+O(1/\log N)$、$\mu_{E^c}=1-\alpha+O(1/\log N)$ 对 (2)、(5) 归一化，得到 (7)。$\log N=2H+O(1)$，故 $\alpha=1/2$ 的值为 $-H+O(1)$。

为得 (8)，归一化矩阵的领先项为
\[
 (\log N)
 \begin{pmatrix}
 1-\alpha&-\sqrt{\alpha(1-\alpha)}\\
 -\sqrt{\alpha(1-\alpha)}&\alpha
 \end{pmatrix}+O(1)_{\rm entrywise}.
\]
其领先本征值为 $\log N$ 和 $0$。未归一化矩阵的行列式由 (4) 的配方恰等于
$Q_W^H[F_{E^c}]\inf_tQ_W^H[F_E+tF_{E^c}]
=\mathcal C_N(E)L_{\theta,\varphi}+o(\log N)$。
除以 $\mu_E\mu_{E^c}$ 后，归一化矩阵行列式为
$(\log N)L_{\theta,\varphi}+o(\log N)$；再除以最大本征值便得到最小本征值极限。$\square$

**回代 dyadic 割。** $S$ 对除数封闭。写 $n=2^ja\in S$、$a$ 奇，则向外奇素数幂的行和为
$A_{\rm odd}(N/(2^ja))-A_{\rm odd}(M/a)
=(R-j)\log2+O(1)$，其中
$A_{\rm odd}(x)=\sum_{k\le x,\ k\text{ 奇}}\Lambda(k)/k=\log x+O(1)$，误差对所有 $j,a$ 一致。向外 $2$ 的幂行和至多 $\log2$。因此
\[
 \mathcal C_N(S)
 =\frac1{L_N}\sum_{j=0}^R2^{-j}
   \sum_{a\le M,\ a\text{ 奇}}\frac{(R-j)\log2+O(1)}a
 =R\log2+O(1),
\]
因为 $\sum_{n\in S}1/(nL_N)=1-O(R/H)$、
$\sum_{j\ge0}j2^{-j}<\infty$、$R^2/H\to0$。这也直接核对了 scratch 976 式 (15)--(17) 的因子和误差。

## 数学边界

式 (6) 是逐个压缩空间的真谱隙，式 (7) 是同一实际算子内跨补槽的真交叉。完整自然权方向的 Schur 消去后仍有 (3) 的严格正极限；因此这项结构并不给出负 Weil 见证。式 (2) 只约束共同非负轮廓的自然权切分，不估计整个补空间的 true-Schur 项，也不给出 moving-$N$ Möbius signed covariance 的固定幂上界。
