# 渐近满 Farey 内区的边界流与发散 Schur 反馈（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确算术图、正权行式和一致有界的 Archimedean 压缩，以及 [note 799](../notes/799-full-farey-bulk-compression-has-a-uniform-positive-gap.md) 的内区。常数阶强化还依赖 [scratch 853](853-full-farey-bulk-archimedean-compression-tends-to-log2-candidate.md) 的内区 Archimedean 对角极限。以下结论尚未异源复核，留在 scratch；它只涉及全 Farey **阶跃偶极主压缩**，不是完整旧奇空间的 Schur 判定。

## 命题

沿奇素数 \(p\to\infty\)，置 \(P=p-1\)、\(H=\log p\)。令 \(T=T_p\to\infty\) 且 \(\tau=\log T=o(H)\)，并令 \(Q=\lfloor P/T\rfloor\)、\(\tau_p=\log(P/Q)=\tau+o(1)\)。在 note 791 的全 Farey 空间 \(W_p\) 内，以 \(I=\mathcal F_Q\)、\(R=\mathcal F_P\setminus I\) 分块，并在两块上取自然正权
\[
u_I=\sum_{x=a/b\in I}\frac{w_x}{\sqrt{ab}},
\qquad u_R=\sum_{x=a/b\in R}\frac{w_x}{\sqrt{ab}},
\qquad Z_Q=\|u_I\|^2.
\]
则 \(Z_Q\sim(\log Q)^2/(2\zeta(2))\)、\(\|u_R\|^2/Z_Q=o(1)\)，且真实 Farey 主压缩 \(A_W=P_{W_p}A_{p^2,-}P_{W_p}\) 满足
\[
\boxed{\begin{aligned}
\langle u_I,A_Wu_I\rangle/Z_Q&=2\tau_p+O(1),\\
\langle u_I,A_Wu_R\rangle/Z_Q&=-2\tau_p+o(1),\\
\langle u_R,A_Wu_R\rangle/Z_Q&=2\tau_p+O(1).
\end{aligned}}\tag{1}
\]
若再采纳 scratch 853 的算子范数界，则 (1) 的三项可同时强化为
\[
\boxed{\quad
\frac1{Z_Q}
\begin{pmatrix}
\langle u_I,A_Wu_I\rangle&\langle u_I,A_Wu_R\rangle\\
\langle u_R,A_Wu_I\rangle&\langle u_R,A_Wu_R\rangle
\end{pmatrix}
=
\begin{pmatrix}
2\tau_p+c_*&-2\tau_p\\
-2\tau_p&2\tau_p
\end{pmatrix}+o(1),
\qquad c_*=1+\gamma_E-\log\pi+\log2>0.
\quad}\tag{1a}
\]
这里 \(o(1)\) 对四个矩阵元逐项成立。故该指定二维平面的 Gram 行列式除以 \(Z_Q^2\) 为 \(2c_*\tau_p+o(\tau_p)>0\)，两个对角也为正；在此二维平面内不能得到 Weil 负方向。消去单个边界试探向量 \(u_R\) 时，内区向量的 Schur 余量趋于 \(c_*\)。此判断不控制 \(R\) 内其他向量，更不控制无限维补空间。
特别地，若 \(A_R=P_RA_WP_R\) 严格正，则该主压缩内消去 \(R\) 后的真实 Schur 反馈在 \(u_I/\sqrt{Z_Q}\) 上至少为
\[
\boxed{\quad
\frac1{Z_Q}\langle A_{RI}u_I,A_R^{-1}A_{RI}u_I\rangle
\ge 2\tau_p-O(1).\quad}\tag{2}
\]
取 \(T_p=\log p\) 时右侧按 \(2\log\log p\) 发散，虽然 \(u_R\) 的平方质量相对 \(u_I\) 趋零。因此 note 799 的正常数内区谱隙不能单独支付整个内外 Schur 反馈；需同时保留内区向量自身的 \(2\log\log p\) 边界能量。式 (2) 没有断言 Schur 余量的符号。

## 精确边界流

令 \(C_p\) 是 note 791 的全 Farey 算术矩阵，\(v_x=(ab)^{-1/2}\)。其限制到 \(\mathcal F_Q\) 的主矩阵与把 note 791 精确图式 (4) 的坐标截止 \(P\) 换成 \(Q\) 得到的 \(C_Q\) 相同：每条边只依赖两端的既约比值；其素数幂参数不超过两端分子分母的乘积 \(Q^2<p^2\)。note 791 式 (14) 的逐素数幂计数因而同样给，对 \(x=a/b\in I\)，
\[
\frac{(C_pv)_x}{v_x}=\log a+\log b-\Lambda(a)\mathbf1_{b=1}
+\mathfrak M(P/a)+\mathfrak M(P/b),
\]
\[
\frac{(C_Qv_I)_x}{v_x}=\log a+\log b-\Lambda(a)\mathbf1_{b=1}
+\mathfrak M(Q/a)+\mathfrak M(Q/b),
\qquad \mathfrak M(t)=\sum_{n\le t}\frac{\Lambda(n)}n.
\tag{3}
\]
故跨边界的加权算术流 \(\Phi_{P,Q}=\langle u_I,C_pu_R\rangle\) **精确**等于
\[
\Phi_{P,Q}=\sum_{x=a/b\in I}\frac1{ab}
\left[\mathfrak M(P/a)-\mathfrak M(Q/a)
+\mathfrak M(P/b)-\mathfrak M(Q/b)\right].\tag{4}
\]
写 \(e(t)=\mathfrak M(t)-\log t\to-\gamma_E\)。由于 \(P/a\ge P/Q\ge T\to\infty\)，有 \(e(P/a)=-\gamma_E+o(1)\) 对全部 \(a\le Q\) 一致。另一方面，\(e(Q/a)\) 在调和权下平均趋于 \(-\gamma_E\)：固定 \(M>1\) 时，\(a\le Q/M\) 上一致误差由 \(\sup_{t\ge M}|e(t)+\gamma_E|\) 控制；\(a>Q/M\) 的总权至多 \(O(\log M\log Q)\)，相对 \(Z_Q\asymp(\log Q)^2\) 趋零。先令 \(Q\to\infty\)，再令 \(M\to\infty\)。对 \(b\) 坐标同理。于是由 (4)
\[
\boxed{\quad\Phi_{P,Q}/Z_Q=2\log(P/Q)+o(1)=2\tau_p+o(1).\quad}\tag{5}
\]

## 能量与变分反馈

同一调和平均与 (3) 给
\[
\langle u_I,C_Qu_I\rangle/Z_Q=2\log Q-2\gamma_E+o(1).
\tag{6}
\]
note 791 的 \(A_W=D_pI-C_p+E_p\)、\(D_p=2\log p+O(1)\)、\(\|E_p\|=O(1)\)，使 (6) 立即给 (1) 第一式。由 \(Z_P/Z_Q\to1\) 及 \(\|E_p\|=O(1)\)，非算术内外交叉满足
\[
|\langle u_I,E_pu_R\rangle|/Z_Q
\le \|E_p\|\,\|u_R\|/\|u_I\|=o(1),
\]
故 (5) 给 (1) 第二式。全正权 \(u_I+u_R\) 的算术 Rayleigh 值为 \(2\log P-2\gamma_E+o(1)\)，所以其完整 \(A_W\) 能量除以 \(Z_Q\) 为 \(O(1)\)。展开三项并代入 (1) 的前两式，得到第三式。

若 \(A_R>0\)，在 \(R\) 上以 \(u_R\) 作逆度量变分测试，得到
\[
\langle A_{RI}u_I,A_R^{-1}A_{RI}u_I\rangle
\ge\frac{|\langle u_R,A_{RI}u_I\rangle|^2}{\langle u_R,A_Ru_R\rangle}.
\]
用 (1) 代入并除以 \(Z_Q\)，即得 (2)。\(\square\)

## 常数阶二维平面

以下还使用 scratch 853 的 \(P_IE_pP_I=(\log2)I+o_{\rm op}(1)\)。于是 (6) 与 \(D_p=2\log p+1-\gamma_E-\log\pi\) 给
\[
\langle u_I,A_Wu_I\rangle/Z_Q=2\tau_p+c_*+o(1).
\tag{7}
\]
式 (5) 及 \(\|E_p\|=O(1)\)、\(\|u_R\|^2/Z_Q=o(1)\) 给交叉项 \(-2\tau_p+o(1)\)。对全权向量 \(u_I+u_R\)，同一正权行平均得到算术 Rayleigh 值 \(2\log P-2\gamma_E+o(1)\)。由 scratch 853 的内区对角极限、\(Z_P/Z_Q\to1\) 和 \(\|E_p\|=O(1)\)，其 Archimedean Rayleigh 也趋于 \(\log2\)；故完整能量除以 \(Z_Q\) 为 \(c_*+o(1)\)。展开全权向量能量并代入 (7) 与交叉项，得到边界对角 \(2\tau_p+o(1)\)，即 (1a)。最后
\[
\frac{\langle u_I,A_Wu_I\rangle}{Z_Q}
-\frac{|\langle u_I,A_Wu_R\rangle|^2}
{Z_Q\langle u_R,A_Wu_R\rangle}
=c_*+o(1),
\]
因为 \((2\tau_p+o(1))^2/(2\tau_p+o(1))=2\tau_p+o(1)\)。\(\square\)

## 边界

式 (1) 的三项在 \(2\tau_p\) 主阶上按 \((+,-,+)\) 配平，只把真正决定符号的问题压到常数阶。此结果不控制完整 \(W_p\) 的 Schur 余量，更不控制 \(W_p^\perp\) 的响应、全尺度局部 Weil 正性或 RH。
