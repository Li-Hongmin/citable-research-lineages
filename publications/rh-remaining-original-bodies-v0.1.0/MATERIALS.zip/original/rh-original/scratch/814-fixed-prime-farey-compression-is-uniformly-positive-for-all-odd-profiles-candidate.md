# 固定素数态的全槽轮廓 Farey 压缩一致正性（候选）

日期：2026-09-29。沿用 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇闭形式、[scratch 810](810-fixed-prime-transverse-modes-in-the-full-farey-compression-candidate.md) 的算术近似本征态及 [scratch 812](812-odd-slot-profile-coercivity-and-interior-farey-gap-candidate.md) 的单槽不等式。本文加强 [scratch 813](813-fixed-prime-and-profile-farey-tensor-limit-candidate.md) 的固定轮廓极限：轮廓可随 \(p\) 改变，且无须限制到固定有限维空间。仍只涉及指定主压缩，不控制完整无限维 Schur 反馈。承重依赖尚缺异源复核，故留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(k=p^2\)，固定有限素数集 \(\mathcal P\)。记 \(\mathscr H=L^2_{\rm odd}(0,2)\)，\(\mathfrak b_2\) 为 scratch 812 式 (1) 的闭形式，\(v_{p,S}\) 为 scratch 810 式 (2) 在根加全 Farey 节点上的标量列。按 scratch 813 式 (1) 的物理嵌入，把
\[
F_p(\boldsymbol h)=\sum_{S\subseteq\mathcal P}u_{p,S}^{h_S},
\qquad h_S\in D(\mathfrak b_2)\cap\mathscr H,
\tag{1}
\]
看成真实旧奇形式域中的向量。设
\[
\delta_*=\gamma_E+\log(2/\pi)>0,
\qquad \lambda_S=\sum_{\ell\in S}\frac{\ell+1}{\ell-1}\log\ell.
\]
则存在只依赖固定集合 \(\mathcal P\) 的数列 \(\epsilon_p\to0\)，使所有轮廓族 \(\boldsymbol h\)，包括依赖 \(p\) 的轮廓族，同时满足
\[
\boxed{
\mathfrak a_{p^2,-}[F_p(\boldsymbol h)]
\ge (\delta_*-\epsilon_p)\|F_p(\boldsymbol h)\|^2
+\sum_{S\subseteq\mathcal P}\lambda_S\|v_{p,S}\|^2\|h_S\|^2.
}
\tag{2}
\]
因此整个无限维轮廓子空间 \(\operatorname{Ran}F_p\) 的真实旧奇**形式主压缩**最终严格正，并有统一谱底 \(\ge\delta_*-o(1)\)。量词只允许素数集固定；它不覆盖随 \(p\) 增长的素数态数目、一般槽轮廓或槽外补空间。

更精确地，令 \(J=2^{|\mathcal P|}\)，以 \(V_p:\mathbb C^J\to\ell^2(X_p)\) 的第 \(S\) 列为 \(v_{p,S}\)，并令 \(U_p=V_pG_p^{-1/2}\)。由 (4)，\(U_p^*U_p=I_J\) 对充分大 \(p\) 成立。记 \(\mathcal B_2\) 为 \(\mathfrak b_2\) 的自伴算子。在 \(U_p\otimes I_{\mathscr H}\) 的坐标下，完整旧奇形式的压缩算子满足
\[
\boxed{
(U_p\otimes I)^*A_{p^2,-}(U_p\otimes I)
=\bigoplus_{S\subseteq\mathcal P}
\bigl(\mathcal B_2+\gamma_E-\log\pi+\lambda_S\bigr)
+E_p,\qquad \|E_p\|_{\rm op}\to0.
}
\tag{2a}
\]
这里左侧按闭形式压缩理解，\(E_p\) 是有界自伴算子；于是该压缩在任一非实谱参数处有范数预解式极限。(2) 是其下界后果。

## 证明

把根与全 Farey 节点集合记为 \(X_p\)。各物理槽互不相交，且算术平移只在槽中心精确重合时发生；此时平移保持相对坐标。故物理嵌入将 (1) 等距识别为
\[
F_p=\sum_S v_{p,S}\otimes h_S\in\ell^2(X_p)\otimes\mathscr H,
\quad
\|F_p\|^2=\sum_{S,T}G_p(S,T)\langle h_S,h_T\rangle,
\quad G_p(S,T)=\langle v_{p,S},v_{p,T}\rangle.
\tag{3}
\]
令 \(m_S=\omega_S/(2\zeta(2))>0\)，其中 \(\omega_S\) 取自 scratch 810 式 (4)。其互素调和质量证明给
\[
H^{-2}G_p\longrightarrow\operatorname{diag}(m_S)
\quad\text{于固定有限矩阵的算子范数中}.
\tag{4}
\]
因此当 \(p\) 充分大，存在 \(c_{\mathcal P},C_{\mathcal P}>0\)，使
\[
c_{\mathcal P}H^2\sum_S\|h_S\|^2
\le\|F_p\|^2
\le C_{\mathcal P}H^2\sum_S\|h_S\|^2.
\tag{5}
\]

算术部分在整个轮廓直和上**精确**为 \(-\widetilde C_p\otimes I_{\mathscr H}\)。scratch 810 式 (13) 证明，对每个固定 \(S\)，
\[
\big\|\widetilde C_pv_{p,S}-(2H-2\gamma_E-\lambda_S)v_{p,S}\big\|=o(H).
\tag{6}
\]
因为 \(S\) 只有固定有限多个，Cauchy–Schwarz、(4) 与 (6) 给出对所有 \(\boldsymbol h\) 一致的展开
\[
\langle F_p,(\widetilde C_p\otimes I)F_p\rangle
=(2H-2\gamma_E)\|F_p\|^2
-\sum_S\lambda_S\|v_{p,S}\|^2\|h_S\|^2
+o(H^2)\sum_S\|h_S\|^2.
\tag{7}
\]
式 (7) **保留**完整的 \(2H\|F_p\|^2\)；不同素数态的 \(G_p(S,T)=o(H^2)\) 不能在乘以 \(2H\) 前丢弃。只有固定的 \(\lambda_S\) 所乘交叉质量才可由 (4) 吸收进 \(o(H^2)\)。

核对 Archimedean 误差的轮廓一致性。每个物理槽的奇异部分由 scratch 812 式 (10) 精确给出
\[
\bigl(2H-\gamma_E-\log\pi+o(1)\bigr)\|h\|^2+\mathfrak b_2[h],
\tag{8}
\]
正则 gamma 同槽算子范数为 \(O(p^{-2})\)，与 \(h\) 无关。两个不同物理中心距离 \(d\ge3\Delta\) 时，两轮廓零均值及 \(|K''(d)|\ll d^{-3}\) 给跨槽块范数 \(O(\Delta^3/d^3)\)；\(2\Delta<d<3\Delta\) 时，端点核受 Carleman 算子 \(1/(s+t)\) 控制，块范数 \(O(1)\)。物理中心排序后的全族绝对块行和为 \(O(1)\)。

固定 \(0<\alpha<1\)。从 \(a,b\le p^\alpha\) 的节点至其余不同物理中心的最小距离 \(\gg p^{-1-\alpha}\)。上述块界给内区绝对块行和 \(O(p^{-2(1-\alpha)})=o(1)\)，全族列和仍为 \(O(1)\)；矩形 Schur 检验给内区到全族的非对角算子范数 \(o(1)\)。另一方面，(4) 的调和质量计算在内区给
\[
H^{-2}\big\|P_{\rm out}v_{p,S}\big\|^2
\longrightarrow (1-\alpha^2)m_S.
\tag{9}
\]
由有限个 \(S\)、(5)、(9)，先令 \(p\to\infty\)，再令 \(\alpha\uparrow1\)，得到非对角 Archimedean 形式在 (1) 的所有轮廓上满足统一估计
\[
\big|\mathfrak g_{\rm off}[F_p]\big|
=o(H^2)\sum_S\|h_S\|^2.
\tag{10}
\]
同样，局部反对称给每个归一化槽的 polar 投影界 \(O(p^{-5/2})\)；全族 \(O(p^2)\) 个槽使其总投影范数 \(O(p^{-3/2})\)。polar 二次型因此也满足 (10)。

将 (7) 的负算术项与 (8) 的正对角项相加，两个 \(2H\|F_p\|^2\) **逐项精确抵消**，得到
\[
\mathfrak a_{p^2,-}[F_p]
=(\gamma_E-\log\pi)\|F_p\|^2
+\sum_{x\in X_p}\mathfrak b_2[(F_p)_x]
+\sum_S\lambda_S\|v_{p,S}\|^2\|h_S\|^2
+o(H^2)\sum_S\|h_S\|^2.
\tag{11}
\]
scratch 812 式 (2) 逐节点给 \(\sum_x\mathfrak b_2[(F_p)_x]\ge(\log2)\|F_p\|^2\)。最后以 (5) 将 (11) 的统一误差改写为 \(o(1)\|F_p\|^2\)，即 (2)。\(\square\)

为核对 (2a)，在 \(U_p\) 坐标中单槽奇异形式恰为 \(I_J\otimes\mathfrak b_2\)。式 (10) 及同槽正则 gamma 界把其余 Archimedean 与 polar 误差提升为算子范数 \(o(1)\)。由 (4)、(6) 和 \(G_p^{1/2}/H\to\operatorname{diag}(\sqrt{m_S})\)，算术矩阵给
\[
U_p^*\widetilde C_pU_p
=(2H-2\gamma_E)I_J-\operatorname{diag}(\lambda_S)+o_{\rm op}(1).
\]
它与 (8) 的 \(2H I_J\) 相消，证明 (2a)。有界扰动的 resolvent 恒等式给所述范数预解式收敛。

## 证据边界

本证明审查了 scratch 813 式 (3) 中交叉素数态的 \(2H\) 抵消，并以块算子范数把固定轮廓极限提升到整个 \(\mathscr H\)。scratch 811 的非恒定响应 \(F(t)\) 只有端点对数奇性，属于 \(\mathfrak b_2\) 的形式域；其所见的固定泄漏在这个扩大的共同轮廓空间内表现为 \(\mathcal B_2\) 的非对角矩阵元。[scratch 815](815-half-integer-exterior-slots-detect-fixed-arithmetic-leakage-candidate.md) 另行检出本主压缩之外的固定算术泄漏。真正未控的是节点依赖轮廓和槽外空间的完整 Schur 反馈，(2a) 不给出相应上界。完整局部 Weil 正性及 moving-\(N\) Möbius signed covariance 的 \(Y^{2+\varepsilon}\) 门仍未判定。
