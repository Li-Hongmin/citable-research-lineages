# 普通 Selberg 窗均方严格强于两端点观察频带门

日期：2026-10-02。对象来自 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)–(15)、(26) 与 [scratch 855](855-haar-bandpass-window-for-the-centered-three-channel-gate.md) 的单窗量纲。本稿只裁决普通移动起点均方能否直接支付 $H\asymp Y^{1/5}$；下面的光滑模型不是真实 $\Lambda$–Möbius 系数，不反驳真实算术门或 RH。

## 所需量纲与现有原定理

写 $M=2Y$、$H\asymp M^{1/5}$、$L=\lfloor M/(16H)\rfloor\asymp M^{4/5}$，并将 note 849 的 $a_m=c(m)\psi(m/M)/m$ 看作模 $M$ 序列。该 note 的周期窗口 Parseval 给

\[
 E_H:=\sum_h\eta(h/H)|\mathcal A_h|^2
 \ll \frac{M}{L^2}\sum_{x\bmod M}
 \left|\sum_{j=0}^{L-1}a_{x-j}\right|^2.
 \tag{1}
\]

若对未归一化窗口和 $C_x=\sum_{j<L}c(x-j)$ 在 $x\asymp M$ 的实际支撑区证明

\[
 \sum_x|C_x|^2\ll_\varepsilon M^2H^2M^\varepsilon,
 \tag{2}
\]

则 (1) 可支付 $E_H\ll_\varepsilon H^4M^{-1+\varepsilon}$。为核准光滑权的传递，置 $w_m=\psi(m/M)/m$，在支撑附近有 $|w_m|\ll M^{-1}$、$|w_{m+1}-w_m|\ll M^{-2}$、$|c(m)|\ll\log M$。于是加权窗和等于 $w_xC_x+O(L^2\log M/M^2)$；其平方和误差为 $O(M\log^2M/H^4)$，代入 (1) 后是 $O(\log^2M/H^2)=o(H^4/M)$。式 (2) 要求 $C_x$ 的均方根至多 $H\sqrt M=M^{7/10}$，比窗口长度 $M^{4/5}$ 小 $M^{1/10}$。它是充分条件，没有必要性。

2026-10-02 直接核对两个原文。Cully-Hugill–Dudek, *An explicit mean-value estimate for the PNT in intervals*, arXiv:2206.00433v2, Theorem 1 的 $\theta$ 型均方**明确假设 RH**，不能作无条件输入。Zaccagnini, *Primes in almost all short intervals*, *Acta Arith.* **84** (1998), 225–244, DOI 10.4064/aa-84-3-225-244，首页 Theorem 对 $x^{1/6-\epsilon(x)}\le h\le x$ 给

\[
 J_\pi(x,h):=\int_x^{2x}\left|\pi(t)-\pi(t-h)-\frac h{\log t}\right|^2dt
 \ll \frac{xh^2}{\log^2x}
 \left(\epsilon(x)+\frac{\log\log x}{\log x}\right)^2,
 \tag{3}
\]

其中 $0\le\epsilon(x)\le1/6$、$\epsilon(x)\to0$。在 $h\asymp x^{4/5}$ 可取 $\epsilon(x)=0$；即使忽略将 $\pi$ 改成 $\Lambda$ 以及加入 Möbius 通道的额外问题，乘回 $\log^2x$ 后也只给 $xh^2(\log\log x/\log x)^2=x^{13/5-o(1)}$，而 (2) 要 $x^{12/5+\varepsilon}$。因此该无条件原定理不能直接支付固定幂内点。真实三通道已由 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的 Ramachandra 全区间短和给更强的次指数一阶节省，但仍没有 (2) 的固定幂节省。

原文已存入 ResearchLibrary：[Cully-Hugill–Dudek PDF](../../ResearchLibrary/lib/michaelacullyhugill2023explicit/michaelacullyhugill2023explicit.pdf)、[Zaccagnini PDF](../../ResearchLibrary/lib/zaccagnini1998primes/zaccagnini1998primes.pdf)。

## 光滑复幂模型：普通窗口可失败而目标频带极小

固定 $\rho=\beta+i\tau$，其中 $9/10<\beta<1$、$\tau\in\mathbb R$ 固定；取非负非零 $\phi\in C_c^\infty((1,2))$。定义

\[
 d_{\rho,M}(m)=m^{\rho-1}\phi(m/M),\qquad
 A_{\rho,h}(M)=\sum_m\frac{d_{\rho,M}(m)}m e(-hm/M),
 \tag{4}
\]

并令 $C_{\rho,x}=\sum_{j=0}^{L-1}d_{\rho,M}(x-j)$。则对任意固定的非负、支撑于 $1/2\le |t|\le4$ 的 $\eta$，

\[
 \sum_h\eta(h/H)|A_{\rho,h}(M)|^2
 \ll_{\rho,\phi,\eta,A} M^{2\beta-2}H^{1-2A}
 =o(H^4/M)
 \quad(A=3),                                      \tag{5}
\]

但

\[
 \sum_{x=M}^{2M}|C_{\rho,x}|^2
 \gg_{\rho,\phi} M^{2\beta+1}H^{-2}
 \gg M^2H^2.                                    \tag{6}
\]

证明 (5)：置 $f_\rho(t)=t^{\rho-2}\phi(t)$。Poisson 求和给精确式

\[
 A_{\rho,h}(M)=M^{\rho-1}
 \sum_{k\in\mathbb Z}\widehat f_\rho(h+kM).
 \tag{7}
\]

固定 $\rho$ 时 $f_\rho$ 光滑紧支撑，所以其 Fourier 变换任意阶衰减；在 $h\asymp H=o(M)$ 时 (7) 为 $O_{\rho,\phi,A}(M^{\beta-1}H^{-A})$。频带只有 $O(H)$ 个整数，得 (5)。当 $H\asymp M^{1/5}$、$A=3$ 时，左边至多 $M^{2\beta-3+o(1)}=o(M^{-1/5})$。

证明 (6)：选闭区间 $J\Subset(1,2)$ 使 $\phi\ge c>0$，再缩到内部 $J'\Subset J$。对 $x/M\in J'$，因 $L/M\to0$ 且 $\rho$ 固定，一致有

\[
 C_{\rho,x}
 =Lx^{\rho-1}\phi(x/M)
 \left(1+O_{\rho,\phi}(L/M+L^{-1})\right).
 \tag{8}
\]

这样的整数 $x$ 有 $\asymp M$ 个，因此其平方和至少为 $M L^2M^{2\beta-2}\asymp M^{2\beta+1}/H^2$。与 (2) 的比例为 $M^{2\beta-1}/H^4\asymp M^{2\beta-9/5}\to\infty$，证明 (6)。这里的 $m^{\rho-1}$ 是固定高度复幂的形状；本证明只用其光滑性，不声称它是实际 $c(m)$ 的一项可独立分离的零点贡献。

## 路线边界

普通 Selberg 窗均方有低频要求，(5)–(6) 证明它严格强于本题带通门。已核对的两篇原文也不提供无条件的固定幂窗口界。直接套用普通均方的路线到此关闭；真实待证对象仍是 note 849 式 (15) 的三通道 signed 中距离协方差，或 [scratch 858](858-exact-bandpass-observation-removes-lower-frequency-leakage.md) 的精确带通版本。
