# 相干 Farey 短块的真实带符号协方差剖面（候选）

日期：2026-09-30。本文只处理既约分子 \(1\) 和固定幂分母带，保留 note 833 式 (1) 的真实 Möbius 系数及 \(d\le N-L\) 物理裁剪。承重外部输入是 Heath-Brown 1982 的 \(x^{2/3}\) 素数短区间定理及 Matomäki--Shao--Tao--Teräväinen 2023, Theorem 1.1(i) 的全区间、任意对数幂 Möbius 前缀界；后者的原始定理与对象映射见 note 835。与已有 [两块 Gram 草稿](pairwise-farey-block-gram-candidate.md) 相比，新增内容是任意固定相干宽度的显式连续剖面及任意对数幂的带符号补项误差。以下证明尚待异源复核，故不晋级永久定理。它不给新的 Möbius 固定幂节省，也不给完整 moving-\(N\) 门。

固定 \(4/5<\alpha<1\)、\(c>0\)、\(C>0\)。令 \(Y\to\infty\) 沿整数，
\[
D=\lfloor Y^\alpha\rfloor,\quad H_D=D^2/Y,\quad
B=\lfloor cH_D\rfloor,\quad L=\lfloor Y^{5/6}\rfloor.
\tag{1}
\]
取两个长度 \(B\) 的整数块 \(I=(t,t+B]\)、\(J=(s,s+B]\)，均包含于 \((D/2,D]\)，并假设 \(|s-t|\le C H_D\)。两块可以重叠。记中心
\[
x_I=t+B/2,\quad x_J=s+B/2,\quad
\lambda_I=YB/x_I^2,\quad\lambda_J=YB/x_J^2,\quad
\delta_{IJ}=Y(1/x_I-1/x_J).
\tag{2}
\]
对 \(q\in I\cup J\)，沿用 note 833 式 (1) 的 \(C_q(N)\) 与
\(F_{q,N}=-C_q(N)\cos(2\pi N/q)/(\pi N)\)，定义
\[
G_{I,N}=\sum_{p\in I\atop p\ {m prime}}F_{p,N},\quad
T_{I,N}=\sum_{q\in I}F_{q,N},\quad H_{I,N}=T_{I,N}-G_{I,N},
\tag{3}
\]
对 \(J\) 同理，内积为 \(\langle U,V\rangle=\sum_{Y<N\le2Y}U_NV_N\)。令
\[
\operatorname{sinc}(z)=\frac{\sin z}{z},\quad\operatorname{sinc}(0)=1,
\qquad
\mathscr F(\lambda,\lambda',\delta)
=\int_1^2\frac{\operatorname{sinc}(\pi\lambda u)
\operatorname{sinc}(\pi\lambda'u)\cos(2\pi\delta u)}{u^2}\,du.
\tag{4}
\]

**候选命题。** 以下误差在上述全部块对上一致。置
\(E_0=B^2D^2/(Y\log^2D)\)，则
\[
\boxed{\quad
\langle G_I,G_J\rangle
=\frac{25}{2\pi^2}\frac{B^2x_Ix_J}{Y\log^2D}
\mathscr F(\lambda_I,\lambda_J,\delta_{IJ})+o_{\alpha,c,C}(E_0).
\quad}\tag{5}
\]
并且
\[
\boxed{\quad
\langle G_I,H_J\rangle=-\langle G_I,G_J\rangle+O_A(E_0/(\log Y)^A),
\quad
\langle H_I,H_J\rangle=\langle G_I,G_J\rangle+O_A(E_0/(\log Y)^A),
\quad
\langle T_I,T_J\rangle=O_A(E_0/(\log Y)^A)
\quad}\tag{6}
\]
这里 (6) 对每个固定 \(A>0\) 成立；其隐常数还依赖 \(\alpha,c,C\)。
特别地，自能量的剖面为严格正的
\[
\mathscr F(\lambda_I,\lambda_I,0)
=\int_1^2u^{-2}\operatorname{sinc}^2(\pi\lambda_Iu)\,du>0.
\tag{7}
\]
因 \(\lambda_I\in[c+o(1),4c+o(1)]\)，式 (5) 给 \(\|G_I\|_2^2\asymp_{\alpha,c}E_0\)，而式 (6) 给每个这样的块 \(\langle G_I,H_I\rangle=-(1+o(1))\|G_I\|_2^2\)。跨块主项可正可负：取 \(c=1/1000\) 时，\(\delta_{IJ}=0\) 的剖面为正，\(|\delta_{IJ}-1/4|\le1/100\) 的剖面为负。两种符号来自式 (4) 的相位距离。

## 证明

写 \(f(q)=\mu(q)q/\varphi(q)\)、\(f_o(q)=f(q)\mathbf1_{2\nmid q}\)、\(f_\kappa=f+4f_o\)。note 833 式 (7) 的素数幂核对给 \(f_\kappa=\mu*h_\kappa\) 且 \(\sum_d|h_\kappa(d)|d^{-1/2}<\infty\)。此处 \(B=D^{\beta+o(1)}\)、\(\beta=2-1/\alpha>3/4\)。在卷积指标 \(d\le D^{1/4}\) 上，令 \(x\asymp D/d\)、窗口长 \(B/d\)。取足够小的固定 \(\varepsilon>0\)，有
\[
\frac{B/d}{x^{5/8+\varepsilon}}
\gg D^{\beta-23/32-3\varepsilon/4+o(1)}\to\infty,
\qquad
\frac{B/d}{x^{1-\varepsilon}}
\ll D^{\beta-1+\varepsilon+o(1)}\to0.
\tag{8}
\]
2023 定理的最大进程界因而控制该窗口所有前缀，任意对数幂一致节省。\(d>D^{1/4}\) 的平凡尾由核的半次绝对收敛界控制为
\(O(BD^{-1/8}+D^{1/2})=o(B/\log^A D)\)。因此对每个固定 \(A>0\)，\(I,J\) 内任意前缀均有
\[
\left|\sum f_\kappa(q)\right|\ll_{\alpha,c,A}B/(\log D)^A.
\tag{9}
\]

note 800 的一致互素 Möbius 调和界、note 801 的精确 Poisson 系数及 note 833 的奇偶拆分，连同多倍数端点裁剪的逐项估计（scratch `all-fixed-power-farey-block-covariance-down-to-four-fifths-candidate.md` 式 (3)），给
\[
C_q(N)=-qf_\kappa(q)+O_\alpha(q\rho_Y),\qquad
\rho_Y=e^{-c_\alpha\omega(Y)}+
\log\log(3Y)(D/Y)^2+(L/Y)^2+DL/Y^2,
\tag{10}
\]
其中 \(\rho_Y\ll_{\alpha,A}(\log Y)^{-A}\) 对任意固定 \(A\) 成立，且 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。在任一长度 \(B\) 块上，\(q\mapsto q\cos(2\pi N/q)\) 的上确界加总变差为 \(O_{c}(D)\)，因为 \(BY/D\asymp_c D\)。由 (9)--(10) 与 Abel 分部求和，
\[
\sup_{Y<N\le2Y}(|T_{I,N}|+|T_{J,N}|)
\ll_{\alpha,c,A}\frac{BD}{Y(\log Y)^A}.
\tag{11}
\]
Heath-Brown 定理取指数 \(2/3\)，将长度 \(B\gg D^{3/4}\) 的块分成固定幂长小段，素数幂与不足一段的端部平凡支付，给 \(v_I,v_J\sim B/\log D\) 一致，其中 \(v_I=\#\{p\in I\}\)。对每个这样的素数 \(p\)，(10) 给 \(C_p(N)=5p+o(p)\) 一致。于是
\[
G_{I,N}=-\frac5{\pi N}\sum_{p\in I}p\cos(2\pi N/p)
+o\!\left(\frac{BD}{Y\log D}\right),
\tag{12}
\]
对 \(J\) 同理；由 (11)--(12)，对任意固定 \(A>0\)，先在 (11) 取指数 \(A+1\)，便有 \(\|T_I\|_2+\|T_J\|_2=O_A(\sqrt{E_0}/(\log Y)^A)\)，而 \(\|G_I\|_2+\|G_J\|_2=O(\sqrt{E_0})\)。展开 \(H=T-G\) 并用 Cauchy--Schwarz 即已证明 (6)，只余 (5)。

令 \(K(z)=\int_1^2u^{-2}\cos(2\pi zu)\,du\)。由于 \(|s-t|=O_C(H_D)\)，对 \(p\in I,r\in J\) 有 \(|1/p-1/r|=O_{c,C}(Y^{-1})\)。把余弦乘积拆成差频与和频：差频的整数求积误差为 \(O_{c,C}(Y^{-2})\)；和频 \(1/p+1/r\asymp D^{-1}\) 的几何和与分部求和给 \(O(D/Y^2)\)。故一致有
\[
\sum_{Y<N\le2Y}\frac{\cos(2\pi N/p)\cos(2\pi N/r)}{N^2}
=\frac1{2Y}K\!\left(Y\left(\frac1p-\frac1r\right)\right)
+O_{c,C}(D/Y^2).
\tag{13}
\]
把 (13) 在约 \(B^2/\log^2D\) 个素数对上求和并乘 \(pr\asymp D^2\)，误差相对 \(E_0\) 为 \(O(D/Y)=o(1)\)。式 (12) 的一致余项也只产生 \(o(E_0)\)。因此
\[
\langle G_I,G_J\rangle
=\frac{25}{2\pi^2Y}\sum_{p\in I,r\in J}
pr K\!\left(Y\left(\frac1p-\frac1r\right)\right)+o(E_0).
\tag{14}
\]

在两块中写 \(p=x_I+B u\)、\(r=x_J+Bv\)，其中 \(u,v\in[-1/2,1/2]+O(B^{-1})\)。因为 \(B/D\to0\)，一致地有
\[
Y(1/p-1/r)=\delta_{IJ}-\lambda_Iu+\lambda_Jv+o(1),
\qquad pr=x_Ix_J(1+o(1)).
\tag{15}
\]
每个块内长度 \(B/m\) 的固定比例子段仍满足 \(B/m\gg D^{2/3}\)。Heath-Brown 定理给这些子段的素数数目为 \((1+o(1))B/(m\log D)\)，对全部允许块一致。先固定 \(m\) 做二维 Riemann 和，再令 \(m\to\infty\)，利用 \(K\) 在 (15) 的有界参数范围内一致连续，得到
\[
\sum_{p\in I,r\in J}prK\!\left(Y(1/p-1/r)\right)
=\frac{B^2x_Ix_J}{\log^2D}
\int_{-1/2}^{1/2}\!\int_{-1/2}^{1/2}
K(\delta_{IJ}-\lambda_Iu+\lambda_Jv)\,du\,dv
+o\!\left(\frac{B^2D^2}{\log^2D}\right).
\tag{16}
\]
将 \(K\) 的定义代入，两个中心化均匀积分各等于相应的 \(\operatorname{sinc}\)，二维积分正好是 (4)。式 (14)--(16) 给 (5)。对角式 (7) 的被积函数非负，且不能在整个 \([1,2]\) 恒零，所以严格为正。

最后核对跨块变号断言。\(K(1/4)=\int_1^2u^{-2}\cos(\pi u/2)du\le-3/49\)：余弦在整个积分区间非正，且 \([5/4,7/4]\) 上 \(-\cos(\pi u/2)\ge\sin(\pi/8)>3/8\)、\(u^{-2}\ge16/49\)。又 \(\sup_z|K'(z)|\le2\pi\log2<5\)。当 \(c=1/1000\)，有 \(\lambda_I,\lambda_J\le4/1000+o(1)\)，由 \(|\operatorname{sinc}z-1|\le z^2/6\) 得 \(|\mathscr F(\lambda_I,\lambda_J,\delta)-K(\delta)|<1/1000\) 对大 \(Y\) 成立。因此在 \(|\delta-1/4|\le1/100\) 上，\(\mathscr F<-3/49+1/20+1/1000<0\)。在 \(\delta=0\) 上，两项 sinc 都严格为正，故 \(\mathscr F>0\)。取 \(t\asymp3D/4\)、\(s-t\) 为 \(t^2/(4Y)\) 的最近整数，就能在带内实现后一种负剖面。\(\square\)

## 门槛

式 (5)--(6) 对固定数量的相干短块给出精确真实负协方差。整个 \(q\asymp D\) 带含 \(\asymp Y/D\) 个这样的块；逐块误差和逐块对数节省不足以把完整均方从 \(D^5/Y^2\) 压到 \(Y^{2+\varepsilon}\)。后续承重对象仍是所有块共同的带符号 \(\mu(q)\mu(r)\) 协方差，特别是已支付局部素数能量之后的合数与跨块余量。这里没有证明 RH 或全尺度局部 Weil 正性。
