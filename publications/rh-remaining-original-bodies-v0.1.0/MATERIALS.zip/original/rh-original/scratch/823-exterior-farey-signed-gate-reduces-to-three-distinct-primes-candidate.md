# 薄分母外槽的实际有符号门归约为三个互异素数（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的真实异臂矩阵与 [scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的实际 forcing。本结果直接支付高次素数幂平移以及 819 留下的 `t-t^{pr}` 二次型接口；无需调用 820--821 的候选算子范数界。尚缺异源复核，留在 scratch。它不估计剩余三素数和的符号。

## 命题

令奇素数 \(p\to\infty\)，\(H=\log p\)，并固定
\[
0<\alpha<1,\qquad
0<\beta<\min\left\{\alpha,\frac{1-\alpha}{4}\right\},
\qquad Q=\lfloor p^\alpha\rfloor,\quad B=\lfloor p^\beta\rfloor,
\quad D=p/Q.
\tag{1}
\]
取 818 的 \(\mathcal Y_{p,B}\)、\(N^{\rm opp}_{p,B}\) 与 819 的实际正 forcing \(t\)。对 \(y=m/b\) 置
\[
t^{\rm pr}_{m/b}=\frac1{\sqrt{mb}}
\sum_{\substack{r\mid m,\ r\ {m prime}\\m/r<Q}}\log r,
\qquad r_{m/b}=t_{m/b}-t^{\rm pr}_{m/b}\ge0.
\tag{2}
\]
令 \(P^+(n)\) 为 \(n\) 的最大素因子，约定 \(P^+(1)=1\)。定义有限的有符号三素数和
\[
\begin{aligned}
\mathfrak T_{p,\alpha,\beta}
={}&\sum_{\substack{m/b,\,m'/b'\in\mathcal Y_{p,B}\\
P^+(\gcd(m,m'))\le D}}
\sum_{\substack{r\mid m,\ m/r<Q\\r\ {m prime}}}
\sum_{\substack{s\mid m',\ m'/s<Q\\s\ {m prime}}}
\sum_{\substack{q\ {m prime}\\q\notin\{r,s\}\\
|\log(qbb'/(mm'))|<2\Delta}}
\frac{(\log r)(\log s)(\log q)}{\sqrt{mb\,m'b'\,q}}
R_\Delta\!\left(\left|\log\frac{qbb'}{mm'}\right|\right),
\qquad \Delta=\tfrac12\log(1+p^{-2}).
\end{aligned}
\tag{3}
\]
则有**绝对误差**
\[
\boxed{\quad
\langle t,N^{\rm opp}_{p,B}t\rangle
=\mathfrak T_{p,\alpha,\beta}+o(1).
\quad}
\tag{4}
\]
在 (3) 中事实上 \(q>\max\{m,m'\}\ge\max\{r,s\}\)；写出 \(q\notin\{r,s\}\) 是为了显示剩余三素数确实两两互异。外层条件排除两个目标分子的全部共同大素因子，特别是 \(r=s\)。式 (4) 因而将所需的 \((\log p)^5\) 级有符号下界严格转成一个互异三素数的短移位问题；并未证明这个下界。

例如 \(\alpha=2/3\) 与任意固定 \(0<\beta<1/12\) 满足 (1)。这一区间仍有 819 式 (5) 的正 \(H^4\) forcing 范数主项和非零归一化泄漏。

## 每个矩阵元的绝对包络

对 \(z=yy'<p^2\)，822 的支撑区间长度其实严格小于 \(2\)：
\[
z(e^{2\Delta}-e^{-2\Delta})
<p^2\left(1+p^{-2}-\frac1{1+p^{-2}}\right)
=\frac{2+p^{-2}}{1+p^{-2}}<2.
\tag{5}
\]
所以其中至多有两个整数，更不用说素数幂。对任何贡献项，\(n\asymp z\) 且 \(\Lambda(n)\ll H\)，\(|R_\Delta|\le1\)，从而完整异臂矩阵与各个子矩阵均满足
\[
\boxed{\ |N^{\rm opp}_{p,B}(y,y')|
\ll \frac{H}{\sqrt y\sqrt{y'}}.\ }
\tag{6}
\]
这是逐项绝对界，不假定素数误差有抵消。

## 实际 forcing 的高次素数幂可在二次型中删除

记 \(T=\sum_y t^{\rm pr}_y/\sqrt y\)、\(R=\sum_y r_y/\sqrt y\)。因为 \(F_Q(m)\le\log m\ll H\) 且
\(\sum_{b\le B}\sum_{p\le m<bp}m^{-1}\ll B H\)，有
\[
T\ll B H^2.\tag{7}
\]
下面直接估计 \(R\)。819 式 (8) 的初等素数幂分组给
\[
r_{m/b}=\frac{R_b(m)}{\sqrt{mb}},\quad
R_b(m)\ll H\bigl(E(m)+D^{-1}\bigr)
\quad\text{uniformly in }b,
\tag{8}
\]
其中 \(E(m)=1\) 表示 \(m\) 被某个 \(D<h\le Bp\)、指数至少为二的素数幂 \(h\) 整除；否则 \(E(m)=0\)。为核对 (8)：若 \(\ell\Vert m\)，有贡献必须 \(\ell>D\)，其全部 \(j\ge2\) 项至多 \((\log\ell)/(\ell-1)\ll H/D\)；这样的 \(\ell\) 至多 \(\log m/\log D=O_{\alpha,\beta}(1)\) 个。若 \(v_\ell(m)\ge2\) 且有贡献，精确 forcing 条件 \((m,\ell^j)>D\) 给上述 \(h\mid m\)，全部这类项之和至多 \(2\log m\ll H\)。

指数至少为二的素数幂在 \([1,X]\) 中有 \(O(\sqrt X\log X)\) 个。因此
\[
\sum_{\substack{D<h\le Bp\\h\ {m higher\ prime\ power}}}\frac1h
\ll\frac H{\sqrt D},
\qquad
\#\{h\le Bp:h\ {m higher\ prime\ power}\}
\ll H\sqrt{Bp}.
\tag{9}
\]
又 \(\sum_{p\le m<bp,\ h\mid m}m^{-1}
\le(\log b)/h+1/p\)。去掉互素条件作上界，先对 \(m\)、再对 \(b\) 求和，得到
\[
\boxed{\ R\ll B\left(
\frac{H^3}{\sqrt D}
+H^2\sqrt{\frac Bp}
+\frac{H^2}{D}\right).\ }
\tag{10}
\]
由 (10) 还有 \(R=o(BH^2)\)。故 (6) 与非负性给
\[
\begin{aligned}
\left|\langle t,N^{\rm opp}t\rangle
-\langle t^{\rm pr},N^{\rm opp}t^{\rm pr}\rangle\right|
&\ll H(2TR+R^2)\\
&\ll B^2\left(
\frac{H^6}{\sqrt D}
+H^5\sqrt{\frac Bp}
+\frac{H^5}{D}\right)=o(1).
\end{aligned}
\tag{11}
\]
最后的极限用到 \(4\beta<1-\alpha\) 及 \(\alpha>\beta\)，后两式也给 \(5\beta<1\)。此处 (11) 直接支付 819 所指出的不能仅凭 \(\|r\|=o(1)\) 删除二次型的缺口。

高次素数幂平移还可在本参数区直接计数。有效的 \(n=\ell^j\)、\(j\ge2\) 满足 \(n<p^2+1\)，故这样的 \(n\) 有 \(O(pH)\) 个。固定 \(n,b,b'\) 后，整数
\(\delta=nbb'-mm'\) 满足 \(|\delta|<bb'\le B^2\)，有 \(O(B^2)\) 种选择。每个 \(mm'=nbb'-\delta\) 至多有 \(\tau(nbb'-\delta)\ll_\varepsilon p^\varepsilon\) 个有序因子配对；\(b,b'\) 共 \(O(B^2)\) 对。因此全部高次素数幂重叠项不超过 \(O_\varepsilon(pB^4Hp^\varepsilon)\) 个。实际 (1) 的 forcing 也满足 \(t_{m/b}\ll H/\sqrt{mb}\)：有贡献的素数底数必须整除 \(m\)，而对 \(\ell^v\Vert m\)，\(j\le v\) 的总权至多 \(v\log\ell\)，\(j>v\) 的几何尾至多 \(\log\ell\)，故全部权至多 \(2\log m\)。由 \(m,m'\ge p\)、\(n\gg p^2/B^2\)，每个带 forcing 的矩阵项绝对值至多 \(O(H^3B/p^2)\)，从而
\[
\boxed{\ 
|\langle t,N^{\rm opp,pp}t\rangle|
+|\langle t^{\rm pr},N^{\rm opp,pp}t^{\rm pr}\rangle|
\ll_\varepsilon H^4B^5p^{-1+\varepsilon}=o(1).
\ }
\tag{12}
\]
这里 \(5\beta<1\) 已由 (1) 给出。这个界针对实际 forcing 的二次型，不声称 \(N^{\rm opp,pp}\) 的算子范数趋零。于是
\[
\langle t^{\rm pr},N^{\rm opp}t^{\rm pr}\rangle
=\langle t^{\rm pr},N^{\rm opp,pr}t^{\rm pr}\rangle+o(1).
\tag{12a}
\]
[scratch 824](824-opposite-prime-power-quadratic-cost-vanishes-through-quarter-candidate.md) 利用 \(mm'=nbb'-\delta\) 将单项权重改为 \(1/(nbb')\)，把 (12) 的高次素数幂二次型支付单独推进到全部固定 \(\beta<1/3\)，包括 \(\beta=1/4\)。本命题的较窄参数范围仍由 (11) 中实际 forcing 的高次素数幂**源误差**决定。

## 两种重复素数也消失

因为 \(y,y'\ge p/B\)，每个有效平移素数满足
\[
q>yy'e^{-2\Delta}\ge\frac{p^2}{B^2(1+p^{-2})}>Bp>\max\{m,m'\}
\tag{13}
\]
对充分大的 \(p\) 成立；最后一步使用 \(B^3=o(p)\)，它由 (1) 给出。所以 \(q\) 与两个 forcing 素数自动不同，并且位于比两个目标分子更高的尺度。

再删除更大的公共因子对：若 \(m,m'\) 有共同素数 \(r>D\)，其整块贡献也趋零。对固定 \(r>D\) 定义
\[
U_r=\sum_{\substack{m/b\in\mathcal Y_{p,B}\\r\mid m}}
\frac{F_Q(m)}m.
\]
由 \(F_Q(m)\le\log m\ll H\)，写 \(m=ar\)、忽略区间和互素限制，得到
\(U_r\ll BHr^{-1}\sum_{a\le Bp/r}a^{-1}
\ll BH^2/r\)。由 (6) 及 \(\sum_{r>D}r^{-2}\ll D^{-1}\)，这整个公共大素因子块的绝对值至多
\[
H\sum_{r>D}U_r^2
\ll \frac{B^2H^5}{D}=o(1).
\tag{14}
\]
特别地，\(r=s\) 的项属于此块。展开 (12a)、按 (14) 删除整个公共大素因子块，所得正是 (3)，证明 (4)。\(\square\)

## 与 822 的素数误差直接对接

令 \(\theta(x)=\sum_{q\le x,\ q\ {m prime}}\log q\)，并取
\(f_z(x)=x^{-1/2}R_\Delta(|\log(x/z)|)\)。由 Stieltjes 原子定义，\(N^{\rm opp,pr}(y,y')=\int f_{yy'}\,d\theta\)。置 \(x=ze^s\) 后，连续密度项是 \(\sqrt z\int e^{s/2}R_\Delta(|s|)ds\)。若 \(h_\Delta=(1_{(-\Delta,0)}-1_{(0,\Delta)})/\sqrt{2\Delta}\)，则 \(R_\Delta\) 是它的自相关，而
\[
\int e^{\lambda u}h_\Delta(u)du
=-\frac{4}{\lambda\sqrt{2\Delta}}\sinh^2\!\frac{\lambda\Delta}{2}.
\]
将 \(\lambda=\pm1/2\) 的两个因子相乘，连续密度系数精确为
\(\kappa_\Delta=-32\Delta^{-1}\sinh^4(\Delta/4)\ll p^{-6}\)。这也直接复核了 822 的承重系数。与上面的归约合并，给实际 forcing 的带绝对误差目标形式
\[
\boxed{\ 
\langle t,N^{\rm opp}t\rangle
=\sum_{y,y'\in\mathcal Y_{p,B}}
t^{\rm pr}_y t^{\rm pr}_{y'}
\int f_{yy'}(x)\,d(\theta(x)-x)+o(1).
\ }
\tag{15}
\]
连续密度部分确实为 \(o(1)\)：由
\(|\kappa_\Delta|\ll p^{-6}\) 和
\(\sum_y t^{\rm pr}_y\sqrt y
=\sum_{b,m}F_Q(m)/b\ll HpB\)，其绝对值至多
\(O(H^2B^2p^{-4})\)。式 (15) 未给右端的有符号下界；它标出剩余必须估计的真实算术误差。
再者，\(f_z\) 在两个支撑端点取零且绝对连续，故 Stieltjes 分部积分确实给
\(\int f_z\,d(\theta-x)
=-\int[(\theta(x)-x)-(\theta(z)-z)]f'_z(x)\,dx\)；减去常数合法，因为 \(\int f'_z=0\)。这复核了 822 式 (8)，没有对该单位尺度增量作额外估计。

## 边界

本归约在每个固定 \(0<\beta<\min\{\alpha,(1-\alpha)/4\}\) 上有效，未覆盖 819 的 \(\beta=1/4\) 例子。剩余三素数和有正负重叠瓣，不能由 (4) 推出算子范数、Schur 符号、全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 上界或 RH。
[scratch 825](825-exterior-farey-forcing-needs-order-log-positive-prime-resonance-for-a-negative-two-plane-candidate.md) 进一步核对同一源与 forcing 方向的二维预算：若要由该方向得到负谱，剩余素数二次型必须为正且至少超过一个明确的 \(H\|t^{\rm pr}\|^2\) 阈值；只证明它不太负还不够。

一个直接的方法边界是：若 \((m,b')=1\)，则 \((m,bb')=1\)，固定 \(b,b',m,\delta\) 后，\(qbb'\equiv\delta\pmod m\) 把平移素数限制在模 \(m\) 的一个类。由 \(q=mm'/(bb')+O(1)\) 和 \(m'<b'p\)、\(m\ge p\)，有 \(m/\sqrt q>(1-o(1))\sqrt b\)。对按幂增长的 \(b\)，此模数已超过 \(q\) 的平方根；单独套用平方根水平的素数等差数列均值定理，不能控制这些项。这里没有证明该子族占三素数和的主质量，也没有排除利用联合平均的新方法。
