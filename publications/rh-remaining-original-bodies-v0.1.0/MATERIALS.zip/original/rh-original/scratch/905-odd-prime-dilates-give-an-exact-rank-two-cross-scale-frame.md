# 奇素数倍数线的精确二秩跨尺度算术框架

日期：2026-10-02。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(12)、[scratch/864](864-odd-source-kernel-has-an-exact-blind-interval.md) 的 \(q(2)=0\)，以及 [scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 式 (17)。本稿检验一个具体决策：利用真实的 \(\Lambda(2p)=0\) 并加入 \(2\)、\(3\) 倍观察，能否给 \(k=3\) 与 \(k=1\) 交叉线一个独立的固定幂衰减？结论是这些**线性倍数资料**形成一个精确二秩框架及一个目标量级内的零组合；它们本身没有提供所需的二点协方差上界。本稿是完整的初等推导，尚待异源复核。

## 精确点态恒等式

将 note 849 式 (10) 的真实联合系数定义于所有 \(n>2\)：
\[
c(n)=2\mathbf1_{2\mid n}(\Lambda(n/2)-1)
-4\{\Lambda(n)-1+(\log2)\mu(n)\}.                    \tag{1}
\]
若 \(u>1\) 为奇数、\(q\ge3\) 为不整除 \(u\) 的奇素数，记 \(\ell=\log2\)。由于 \(2u,qu\) 都含两个不同素因子，\(\Lambda(2u)=\Lambda(qu)=0\)；乘法性又给 \(\mu(2u)=\mu(qu)=-\mu(u)\)。代入 (1) 得
\[
\boxed{\begin{aligned}
c(u)&=4-4\Lambda(u)-4\ell\mu(u),\\
c(2u)&=2+2\Lambda(u)+4\ell\mu(u),\\
c(qu)&=4+4\ell\mu(u).
\end{aligned}}                                                   \tag{2}
\]
因此对每个这样的 \(u,q\)，
\[
\boxed{\quad c(u)+2c(2u)-c(qu)=4,\quad
\mu(u)=\frac{c(qu)-4}{4\ell},\quad
\Lambda(u)=\frac{8-c(u)-c(qu)}4.\quad}              \tag{3}
\]
对任意两个均不整除 \(u\) 的奇素数 \(q,r\)，还有 \(c(qu)=c(ru)\)。在共同的互素 \(u\)-支撑上，全部奇素数倍数线重复同一个 \(\mu(u)\) 通道；\(u\) 与 \(2u\) 两线加入后，去掉常数背景的系数矩阵
\[
\begin{pmatrix}-4&-4\ell\\2&4\ell\\0&4\ell\end{pmatrix}
\begin{pmatrix}\Lambda(u)\\\mu(u)\end{pmatrix}                    \tag{4}
\]
秩恰为 \(2\)。这些式子也覆盖非平方自由 \(u\)：此时 \(\mu(u)=0\)，且若 \(u\) 为奇素数幂，\(\Lambda(u)\) 仍按原值保留。条件 \(q\nmid u\) 必须保留，以排除 \(qu\) 为同一素数幂的情形。

对一般乘法 \(f\)（\(f(2)=f(3)=-1\)，\(\Lambda_f=f*\log\)），同样逐项展开且只用 \(f(2u)=f(3u)=-f(u)\)，得到更精确的误差式
\[
c_f(u)+2c_f(2u)-c_f(3u)
=4-8\Lambda_f(2u)+4\Lambda_f(3u).                    \tag{3a}
\]
真实 \(\Lambda\) 在 \(2u,3u\) 均为零，所以 (3) 成立；[scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的高素数翻转则恰在这些窗外合数处产生非零 \(\Lambda_f\)。式 (3a) 把跨窗线性组合所需的算术支撑条件全部显露出来。

## 对观察频带的严格零组合

固定 \(\psi\in C_c^3((1,2))\)，令 \(\varphi(t)=\psi(t)/t\)。对 \(X\to\infty\)、\(j\in\{1,2,3\}\) 及整数 \(h\)，定义同一基底上的跨尺度包
\[
P_h^{(j)}(X)=\frac1X
\sum_{\substack{X<u<2X\\u\equiv1,5\pmod6}}
c(ju)\varphi(u/X)e(-hu/X).                            \tag{5}
\]
这些是三个物理尺度的选定算术子包；不是 note 849 的完整 \(\mathcal A_h\)。由 (3) 对 \(q=3\) 逐点求和，
\[
P_h^{(1)}(X)+2P_h^{(2)}(X)-P_h^{(3)}(X)
=\frac4X\sum_{\substack{u\in\mathbb Z\\u\equiv1,5\pmod6}}
\varphi(u/X)e(-hu/X).                                  \tag{6}
\]
右侧只是一条模 \(6\) 的平滑格。写 \(\widehat\varphi(\xi)=\int\varphi(t)e(-\xi t)dt\)。对两个剩余类用 Poisson 求和，右侧为 \(\frac43\widehat\varphi(h)\) 加非零别名；别名频率与 \(h\) 相距至少 \(X/6\)。若 \(X^{1/5}\le H\le X^{1/4}\)、\(H/2\le|h|\le4H\)，三次分部积分给
\[
|P_h^{(1)}+2P_h^{(2)}-P_h^{(3)}|
\ll_\psi H^{-3}+X^{-3}\ll_\psi H^{-3}.              \tag{7}
\]
这里 (6) 的零频密度为 \(4\cdot(2/6)=4/3\)；(7) 只使用其绝对界。

取 note 849 的任意固定非负偶带通权 \(\eta\)，其支撑在 \(1/2\le|t|\le4\)。于是
\[
\boxed{\quad
\sum_h\eta(h/H)
|P_h^{(1)}+2P_h^{(2)}-P_h^{(3)}|^2
\ll_{\psi,\eta} H^{-5}
=o\!\left(\frac{H^4}{X}\right)
\quad}                                                           \tag{8}
\]
在整个 \(X^{1/5}\le H\le X^{1/4}\) 上一致成立；最后一步因 \(X/H^9\le X^{-4/5}\)。这是实际 \(\mu,\Lambda\) 系数的无条件目标级跨尺度相消，但只针对 (6) 这个精确零组合。

## 决策边界

式 (3) 回答了跨窗 \(\Lambda(2p)=0\) 的最便宜直接检验：\(2\)、\(3\) 倍资料只将 \(\Lambda(u)\) 与 \(\mu(u)\) 分离，并产生 (8) 的代数零组合。特别地，\(P^{(3)}\) 减去平滑背景后就是带权 \(\mu(u)\) 包；(8) 不能分别控制 \(P^{(1)},P^{(2)},P^{(3)}\) 中任何一个，也不能给 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (15) 的固定幂协方差。下一输入仍必须是这些算术包之间的真实二点相消，或作用于完整系数而非该零组合的新机制。全尺度局部 Weil 正性和 RH 均未解决。

具体地，若 \(B_h(X)=X^{-1}\sum_{u\equiv1,5\ (6)}\varphi(u/X)e(-hu/X)\)，则 \(P_h^{(3)}(X)=4B_h(X)+4(\log2)X^{-1}\sum_{u\equiv1,5\ (6)}\mu(u)\varphi(u/X)e(-hu/X)\)。第一项在上述频带为 \(O_\psi(H^{-3})\)；本项目所用的 2023 全区间短和输入对第二项只给任意固定对数幂节省。(8) 没有把它支付到固定幂目标。
