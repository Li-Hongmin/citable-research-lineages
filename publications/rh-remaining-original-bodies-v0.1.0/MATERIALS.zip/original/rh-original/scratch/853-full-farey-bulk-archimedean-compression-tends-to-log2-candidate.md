# 全 Farey 内区 Archimedean 压缩趋于 \(\log2\) 的强化候选

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确 Farey 算术图、正权行恒等式与相离核界，以及 [note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的单偶极接触常数。此处的强化算子范数界尚未异源复核；Claude 只读复核的订阅预检失败，未返回数学意见。

## 定理

沿奇素数 \(p\to\infty\)，取 \(k=p^2\)。令 \(T_p\) 为任意满足 \(T_p\to\infty\)、\(T_p=o(p)\) 的实数序列，并置
\[
Q_p=\left\lfloor\frac{p-1}{T_p}\right\rfloor,
\quad I_p=\left\{a/b\in\mathcal F_p:a,b\le Q_p\right\},
\quad V_p=\operatorname{span}\{w_x:x\in I_p\}.
\]
则在整个内区有算子范数渐近
\[
\boxed{\quad\|P_{V_p}E_pP_{V_p}-(\log2)I_{V_p}\|_{\rm op}=o(1),\quad}
\tag{1}
\]
其中 \(E_p=P_{W_p}A_{p^2,-}P_{W_p}-(D_pI-C_p)\) 沿用 note 791 的定义。因此
\[
\boxed{\quad P_{V_p}A_{p^2,-}P_{V_p}
\succeq\bigl(1+\gamma_E-\log\pi+\log2-o(1)\bigr)I_{V_p}.\quad}
\tag{2}
\]
括号内的极限常数严格为正。内区包含所有既约 \(a,b\le Q_p\)，无平方自由、固定根或柱状轮廓限制。特别地，若 \(T_p=\log p\)，它包含 note 791 自然调和权的渐近全部平方质量；式 (2) 是整个内区的算子下界，而非单个 Rayleigh 商。

## 证明

在 \(\ell^2(\mathcal F_p)\) 记 \(v_{a/b}=(ab)^{-1/2}>0\)。note 791 式 (6) 给
\[
A_W:=P_{W_p}A_{p^2,-}P_{W_p}
=D_pI-C_p+E_p,
\quad D_p=2\log p+1-\gamma_E-\log\pi,
\]
其中 \(C_p\) 是对称逐项非负矩阵。先证明比 note 795 的全 \(W_p\) 下界更尖锐的内区式 (1)。

每个 \(w_{a/b}\) 的两个物理中心分别为 \(pa/b,pb/a\)，其中 \(a,b\le Q_p\)。若两个这样的有理中心比值不同，则其对数距离为 \(|\log(ad/bc)|\)，其中 \(ad,bc\le Q_p^2\) 是不同整数，故距离至少为 \(cQ_p^{-2}\)。全部内区物理中心按对数位置排序后，任一中心的第 \(j\) 个左邻或右邻至少相距 \(cjQ_p^{-2}\)。由于 \(\Delta=\frac12\log(1+p^{-2})\asymp p^{-2}\)，有 \(\Delta Q_p^2=O(T_p^{-2})=o(1)\)。note 791 式 (12) 因而把全部相离 Archimedean 交叉的绝对行和界为
\[
O\!\left(\sum_{j\ge1}\frac{\Delta^3}{(jQ_p^{-2})^3}\right)
=O\!\left((Q_p/p)^6\right)=o(1).
\tag{3}
\]
note 795 式 (7) 的单物理偶极接触能量为 \(D_p+\log2+O(\Delta)\)，误差对中心一致。把物理中心两两等权合成 \(w_x\) 是等距压缩；note 791 式 (5) 的 polar 压缩范数为 \(O(p^{-3})\)。式 (3) 遂给 (1)，且误差实际上为 \(O((Q_p/p)^6+p^{-2})\)。

令 \(r_x=(C_pv)_x/v_x\)。对任意 \(f_x=v_xF_x\)（包括零坐标），对称性给精确基态变换
\[
\langle f,(D_pI-C_p)f\rangle
=\sum_{x\in\mathcal F_p}(D_p-r_x)|f_x|^2
+\frac12\sum_{x,y\in\mathcal F_p}C_p(x,y)v_xv_y|F_x-F_y|^2.
\tag{4}
\]
自环已在 \(r_x\) 内，且边能量非负。此式对只支撑在 \(I_p\) 的 \(f\) 仍在全图求边能量；通往内区外的边被保留并提供非负支付。

记 \(\mathfrak M(t)=\sum_{n\le t}\Lambda(n)/n\)、\(e(t)=\mathfrak M(t)-\log t\)。note 791 式 (14) 逐点给
\[
r_{a/b}=\log a+\log b-\Lambda(a)\mathbf1_{b=1}
+\mathfrak M\!\left(\frac{p-1}{a}\right)
+\mathfrak M\!\left(\frac{p-1}{b}\right).
\]
所以
\[
D_p-r_{a/b}
=1-\gamma_E-\log\pi
+2\log\frac p{p-1}
-e\!\left(\frac{p-1}{a}\right)
-e\!\left(\frac{p-1}{b}\right)
+\Lambda(a)\mathbf1_{b=1}.
\tag{5}
\]
经典素数定理及 \(-\zeta'/\zeta(1+s)=s^{-1}-\gamma_E+O(s)\) 给
\(e(t)\to-\gamma_E\) 当 \(t\to\infty\)。令
\(\varepsilon_p=\sup_{t\ge T_p}|e(t)+\gamma_E|\)，则 \(\varepsilon_p\to0\)。若 \(a,b\le Q_p\)，就有 \((p-1)/a,(p-1)/b\ge T_p\)。式 (5) 与 \(\Lambda(a)\ge0\) 因而给所有内区点一致下界
\[
D_p-r_{a/b}\ge1+\gamma_E-\log\pi-2\varepsilon_p.
\tag{6}
\]
把 (6) 代入 (4)，再加上 (1)，即得 (2)。

为严格判定常数符号，\(\gamma_E>1/2\)、\(\pi<4\)、\(\log4<3/2\)，故 \(1+\gamma_E-\log\pi+\log2>0\)。最后，取 \(T_p=\log p\) 时，note 791 式 (15) 的同一调和质量渐近应用于截止 \(Q_p\)，给
\[
\frac{\sum_{x\in I_p}v_x^2}{\sum_{x\in\mathcal F_p}v_x^2}
=\frac{(\log Q_p)^2+O(\log Q_p)}{(\log p)^2+O(\log p)}\longrightarrow1.
\]
这只陈述内区捕获自然权的平方质量；全 Farey 算子的内外 Schur 反馈仍未控制。\(\square\)

## 边界

若全 Farey 主压缩有负方向，其负性必须涉及 \(\mathcal F_p\setminus I_p\) 及跨区耦合；本定理不证明该补块正定，也不控制 \(W_p\) 以外的无限维旧奇空间。它不推出全尺度局部 Weil 正性或 RH，亦不涉及 moving-\(N\) signed covariance 的最终均方界。
