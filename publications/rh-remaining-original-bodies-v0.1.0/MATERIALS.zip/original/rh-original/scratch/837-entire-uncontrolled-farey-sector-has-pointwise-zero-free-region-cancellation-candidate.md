# 完整未控 Farey 扇区逐点具有零自由区级 Möbius 相消（候选）

日期：2026-09-29。依赖 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 的真实核零自由区界与严格正积分、[scratch 833](833-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff-candidate.md) 的精确 Poisson 公式，以及 [scratch 834](834-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual-candidate.md) 的移动系数。下述逐点加强尚未异源复核，留在 scratch。

## 命题

令 \(Y<N\le2Y\)、\(Q=\lfloor Y^{4/5}\rfloor\)、\(A=\lceil Y^{1/3}\rceil\)、\(H=\log(2Y)\)，并令 \(\mathcal U_N\) 为 834 式 (2) 的真实未控扇区 \(q>Q,1\le a<A\)。存在绝对 \(c>0\)，使
\[
\boxed{\quad
\mathcal U_N\ll NH^2e^{-c\omega(Y)}
=O_B(N/\log^B N)\quad(\forall B>0),
\quad}
\tag{1}
\]
其中 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。把 \(\mu(d)\) 分成素数系数与其余系数，写 \(\mathcal U_N=P_U(N)+C_U(N)\)，则对 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 的严格正数 \(K=\int_0^1\Phi(t)dt\)，逐个 \(N\) 有
\[
\boxed{\quad
P_U(N)=-K\frac N{\log N}+O\!\left(\frac N{\log^2N}\right),
\qquad
C_U(N)=K\frac N{\log N}+O\!\left(\frac N{\log^2N}\right).
\quad}
\tag{2}
\]
因此充分大时每个 \(N\) 都有 \(P_U(N)C_U(N)<0\)，而且
\[
\sum_{Y<N\le2Y}P_U(N)C_U(N)
=-\frac{7K^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\tag{3}
\]
式 (3) 与 834 式 (17) 的主项相同；新增内容是整个未控扇区的逐点估计 (1)--(2)。

## 逐点支付被删频率

完整核 residual 为 \(\mathcal R_{N,2}=\sum_{d<N}\mu(d)\Phi(d/N)\)。由 note 767 式 (9)--(13) 在 \(D=Q\) 的零自由区分部求和，连同 \(d\le Q\) 的绝对界 \(|\Phi(t)|\ll t\log(1/t)\)，可取较小的绝对 \(c>0\) 使
\[
\mathcal R_{N,2}\ll NH^2e^{-c\omega(Y)}.
\tag{4}
\]
事实上低除数只给 \(O(Q^2H/N)=O(Y^{3/5}H)\)，可被右端吸收。

记 \(F_j^{\le Q}(N)\) 为 834 式 (7) 的第 \(j\) 层。其式 (5)--(9) 给出对 \(Y\le t\le2Y\) 一致的
\[
|W_{j,a,q}(t)|\ll4^{j+1}H\frac{q^{2j+1}}{a^{2j+2}}
\qquad(q\le Q).
\]
于是对**每个** \(N\)，直接按系数取绝对值得
\[
|F_j^{\le Q}(N)|
\ll\frac{4^{j+1}H}{Y^{2j+1}}
\sum_{q\le Q}q^{2j+1}
\sum_{a\ge1}a^{-2j-2}
\ll\frac{HQ^2}{Y}\left(\frac{4Q^2}{Y^2}\right)^j.
\]
由于 \(4Q^2/Y^2=o(1)\)，全部低分母频率逐点满足
\[
\mathcal F_N^{q\le Q}\ll HQ^2/Y=O(Y^{3/5}H).
\tag{5}
\]
这一步只用真实 Möbius 谐波系数的统一界，没有把 834 的均方结论误当逐点结论。

对既约分子 \(a\ge A\)，必有原始谐波 \(h\ge A\)。在 833 式 (5) 中，此时两个分母一致离零有绝对距离，且 \(t\log(1/t)\) 有界。每个 \(d<N\) 的这些项绝对和为 \(O(\sum_{h\ge A}h^{-2})=O(A^{-1})\)，故所有 \(a\ge A\) 的项逐点为 \(O(N/A)\)。最后，\(h\ge d\) 的项由 833 式 (17) 逐点合计 \(O(H)\)。因而精确分解给
\[
|\mathcal R_{N,2}-\mathcal U_N|
\ll HQ^2/Y+N/A+H
\ll Y^{2/3}+Y^{3/5}H.
\tag{6}
\]
式 (4)--(6) 证明 (1)，因为任意固定幂 \(Y^{2/3}\) 都小于 \(Ye^{-c\omega(Y)}\)（充分大的 \(Y\)）。

## 素数主项逐点保留

由 note 767 的素数定理分部求和，加上 \(p\le Q\) 的同一小参数绝对界，完整素数部分满足
\[
P_{\rm all}(N):=-\sum_{p<N}\Phi(p/N)
=-K\frac N{\log N}+O\!\left(\frac N{\log^2N}\right).
\tag{7}
\]
对素数 \(d=p\) 且 \(h<p\)，约分后的分母必为 \(q=p\)，分子为 \(a=h\)。因此从 \(P_{\rm all}\) 到 \(P_U\) 删去的只有 \(p\le Q\)、\(h\ge A\) 与 \(h\ge p\) 三类。它们依次由上节的相同绝对界支付为 \(O(Q^2H/N)\)、\(O(N/A)\) 与 \(O(H)\)，均为 \(o(N/\log^2N)\)。于是 (7) 给 (2) 第一式，(1) 与 \(C_U=\mathcal U-P_U\) 给第二式。逐 \(N\) 相乘并用 \(\sum_{Y<N\le2Y}N^2/\log^2N=(7/3)Y^3/\log^2Y+O(Y^3/\log^3Y)\)，得到 (3)。\(\square\)

## 边界

(1) 在均方上只给 \(Y^3H^4e^{-2c\omega(Y)}=Y^{3-o(1)}\) 的上界，尚差接近一整幂；(6) 的逐点绝对余项为 \(Y^{2/3+o(1)}\)，不能取代 834 的 \(Y^{2+\varepsilon}\) 均方缩域。本文没有证明完整 moving-\(N\) signed covariance、全尺度局部 Weil 正性或 RH。
