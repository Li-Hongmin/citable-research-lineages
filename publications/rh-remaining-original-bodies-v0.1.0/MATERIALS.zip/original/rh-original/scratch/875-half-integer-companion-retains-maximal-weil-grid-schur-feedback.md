# 半整数伴随格保留最大整数 Weil 格的 Schur 交叉

日期：2026-10-03。直接测试 [scratch 874](874-linear-logarithmic-fourier-profile-weil-gap.md) 与 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的最大整数格是否可忽略补空间。使用 [note 856](../notes/856-exterior-divisibility-layer-gives-nonzero-weil-variational-feedback.md) 的完整形式交叉约定和普通核恒等式。以下为解析证明草稿，尚待异源复核；并非完整补空间 true-Schur 估计。

## 命题

沿奇素数 \(p\to\infty\)，令 \(H=\log p\)、\(M=(p^2-5)/4\)、\(L_M=\sum_{n\le M}n^{-1}\)。固定非负实单位 \(\varphi\in C_c^\infty((-1/2,1/2))\)，取足够小的固定 \(c>0\)、\(\ell=c/p^2\)、\(b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)\)。对正实数 \(x\) 写 \(y_x=H-\log4-\log x\)。定义 note 857 的自然整数格单位向量
\[
f(y_n+t)=\frac{n^{-1/2}}{\sqrt{L_M}}b_\ell(t)
\quad(1\le n\le M),
\tag{1}
\]
以及半整数伴随格
\[
\mathcal Q_M=\{q=a/2:1\le a\le M,\ a\text{ 为奇数}\},
\quad T_M=\sum_{q\in\mathcal Q_M}\frac1q,
\quad
g(y_q+t)=\frac{q^{-1/2}}{\sqrt{T_M}}b_\ell(t)
\quad(q\in\mathcal Q_M),
\tag{2}
\]
其余处均置零。对充分小的固定 \(c\)，全部槽位于 \((-H,H)\)、彼此相离，故 \(\|f\|_2=\|g\|_2=1\) 且 \(\langle f,g\rangle=0\)。写 \(Q=Q_W^H\)，交叉采用 \(Q[f+tg]=Q[f]+2tQ(f,g)+t^2Q[g]\)。则
\[
\boxed{\quad Q(f,g)=-\log2+O_\varphi(c)+o_{c,\varphi}(1).\quad}
\tag{3}
\]
存在固定 \(c_\varphi>0\)，使每个 \(0<c<c_\varphi\) 还有 \(Q[g]>0\)，并且
\[
Q[g]=\log(4/c)+O_\varphi(1),
\qquad
\boxed{\quad
Q[f]-\inf_{t\in\mathbb R}Q[f+tg]
=\frac{Q(f,g)^2}{Q[g]}\ge\varepsilon_{c,\varphi}>0
\quad}
\tag{4}
\]
对充分大 \(p\) 成立。因而即使最大整数格上已有严格正隙，其到完整局部 Weil 空间的推论仍须支付非零的补空间 Schur 反馈。式 (4) 不断言该反馈足以使完整形式为负。

## 槽几何与精确素数交叉

note 857 已证明整数槽相离且处于 \((-H,H)\)。伴随格有 \(1/2\le q\le M/2\)，故最上中心 \(y_{1/2}=H-\log2<H\)，最下中心满足 \(y_q\ge y_M+\log2>-H+\log2\)。伴随格相邻 \(q\) 相差 \(1\)，它与整数格的实指标距离至少 \(1/2\)。当 \(q\le M/2\) 且 \(n\le M\) 时，任意不同中心的最小对数距离为 \((1+o(1))/M\asymp4/p^2\)。取例如 \(c<1\)，即使宽度 \(\ell\) 小于所有中心距离，因而各槽支撑互不相交。

若某素数幂平移使整数槽 \(n\) 与半整数槽 \(q=a/2\) 重叠，则 \(n/q\) 或 \(q/n\) 与整数素数幂的相对差至多 \(O(\ell)\)。把相应指标乘以该素数幂后，两个候选有理数之差若非零则至少为 \(1/2\)；另一方面它至多为 \(O(\ell M)<1/2\)（再缩小固定 \(c\)）。所以必须精确相等。\(q/n=a/(2n)\) 永非整数；\(n/q=2n/a\) 为整数素数幂当且仅当
\[
n=2^{j-1}a,\qquad j=1+\nu_2(n),
\qquad a\text{ 为 }n\text{ 的奇数部分}.
\tag{5}
\]
因此每个 \(1\le n\le M\) 恰与 \(q=a/2\in\mathcal Q_M\) 构成一条 \(2^j\) 交叉边，没有其他素数幂边。按 note 856 式 (4) 的真实 Weil prime-shift 权，这条边满足
\[
\frac{\Lambda(2^j)}{\sqrt{2^j}}\frac1{\sqrt{nq}}
=\frac{\log2}{n}\quad(q2^j=n).
\]
由此精确地有
\[
Q_{\rm prime}(f,g)
=-\frac{\log2}{\sqrt{L_MT_M}}\sum_{n\le M}\frac1n.
\tag{6}
\]
而
\[
T_M=2\sum_{\substack{a\le M\\a\text{ odd}}}\frac1a
=2L_M-L_{\lfloor M/2\rfloor}
=\log M+\gamma+\log2+o(1),
\]
故 (6) 趋于 \(-\log2\)。

## 普通核与极点项的支付

note 856 式 (7) 的代数恒等式对任意正实指标 \(x\ne y\) 仍成立：
\[
\frac{k(|\log(x/y)|)}{\sqrt{xy}}
=\frac12\left(\frac1{|x-y|}+\frac1{x+y}\right).
\tag{7}
\]
整数与伴随半整数满足 \(|n-q|\ge1/2\)。对每个 \(q\in\mathcal Q_M\)，(7) 的 \(n\le M\) 求和为 \(O(\log(2M))\)；对 \(O(M)\) 个 \(q\) 再求和为 \(O(M\log M)\)。因此普通非算术核的交叉由其前因子 \(\ell/\sqrt{L_MT_M}\) 支付为 \(O_\varphi(c)\)。把双积分替换为中心核的误差可如 note 856 逐差值求和：在距离 \(|n-q|=d+1/2\) 上，导数界给加权误差 \(O_\varphi(\ell^2M/(d+1/2)^2)\)；总和除以 \(\sqrt{L_MT_M}\) 后为 \(O_\varphi(\ell^2M^2/L_M)=o(1)\)。

极点项记 \(m_\pm=\int b_\ell(t)e^{\pm t/2}dt=O_\varphi(\sqrt\ell)\)。由 \(e^{y_x/2}=\sqrt p/(2\sqrt x)\)、\(e^{-y_x/2}=2\sqrt{x/p}\)，两向交叉矩分别至多 \(C_\varphi m_+m_- M\sqrt{L_M/T_M}\) 与 \(C_\varphi m_+m_- M\sqrt{T_M/L_M}\)；因 \(\ell M\to c/4\)，极点交叉为 \(O_\varphi(c)\)。同槽项没有交叉，因为 \(f,g\) 支撑正交。与 (6) 合并证明 (3)。

## 伴随方向的正成本

同槽 Fourier 项对范数一的 \(g\) 为 \(\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)\)。伴随格内部的素数幂边只有奇数 \(k\)，因为两个指标 \(a/2,b/2\) 的比为 \(b/a\)，其中 \(a,b\) 奇。令 \(A_{\rm odd}(x)=\sum_{k\le x,\,k\text{ odd}}\Lambda(k)/k\)；note 854 的加权素数定理及绝对收敛的 \(2\) 的幂尾给 \(A_{\rm odd}(x)=\log x+O(1)\)。完整两臂 prime 罚项满足
\[
\frac2{T_M}\sum_{\substack{a\le M\\a\text{ odd}}}
\frac2a\,A_{\rm odd}(M/a)
=L+O(1).
\tag{8}
\]
最后一步由 \(T(x)=2\sum_{a\le x,\,a\text{ odd}}1/a=\log x+\gamma+\log2+O(x^{-1})\) 及
\[
\sum_{\substack{a\le M\\a\text{ odd}}}
\frac2a\log(M/a)
=\int_1^M\frac{T(x)}x\,dx
=\tfrac12L^2+(\gamma+\log2)L+O(1)
\]
直接得到。伴随格的普通跨槽核由 (7) 给 \(O(M\log M)\) 绝对和，乘 \(\ell/T_M\) 后为 \(O_\varphi(c)\)；中心替换误差为 \(o(1)\)，极点自身为 \(O_\varphi(c)\)。所以
\[
Q[g]=\log(1/\ell)-L+O_\varphi(1)
=\log(4/c)+O_\varphi(1).
\]
取足够小的固定 \(c\) 使 \(Q[g]>0\)，并由 (3) 使 \(|Q(f,g)|\ge(\log2)/2\)。式 (4) 中 \(Q[g]\) 还有固定上界，故对 \(t\) 配方给出统一正的 \(\varepsilon_{c,\varphi}\)。\(\square\)

## 边界

最大整数格确实吸收了 note 856 的外侧整数层；本命题表明分数中心仍产生可测的 \(2\)-adic prime-shift 交叉。这个有限二方向实验不控制整个补空间的下界或 Schur 惯性，也不推断全尺度局部 Weil 正性失败。真实 moving-\(N\) Möbius signed covariance 仍未支付。

## 2026-10-03 精确化：完整二方向极限

以下把上面的 \(O_\varphi(c)\) 项逐一算出。记
\(\kappa=\int\varphi\)、
\(C_\varphi=\int_{\mathbb R}\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)\)。
对每个固定 \(0<c<1\)，沿同一奇素数序列，有
\[
\begin{aligned}
Q[f]&\longrightarrow
F=\log(4/c)+C_\varphi+\gamma-\log(2\pi)+\kappa^2c/4,\\
Q(f,g)&\longrightarrow
B=-\log2+\kappa^2c/4,\\
Q[g]&\longrightarrow
G=\log(4/c)+C_\varphi+\gamma+\log2-\log(2\pi)+\kappa^2c/8.
\end{aligned}\tag{9}
\]
第一行是 note 857 式 (1)；下面只证明新增两行。特别地，这个极限矩阵严格正定，但其 Schur 扣款仍为
\[
\lim_{p\to\infty}\bigl(Q[f]-\inf_tQ[f+tg]\bigr)
=B^2/G>0.\tag{10}
\]
这里的正定性只针对 \(\operatorname{span}\{f,g\}\)，不涉及整个补空间。

设 \(N_*=|\mathcal Q_M|=(M+1)/2\)。普通核恒等式 (7) 给出两个无需素数估计的调和和：
\[
\begin{aligned}
\sum_{q\in\mathcal Q_M}\sum_{n\le M}
\left(\frac1{|n-q|}+\frac1{n+q}\right)
&=M\log M+O(M),\\
\sum_{\substack{q,r\in\mathcal Q_M\\q<r}}
\left(\frac1{r-q}+\frac1{r+q}\right)
&=N_*\log N_*+O(N_*).
\end{aligned}\tag{11}
\]
第一式对每个半整数 \(q\) 分别从两侧求调和和，单行是
\(\log(2+q)+\log(M-q)+O(1)
=2\log M+O(1+|\log(q/M)|)\)；
对 \(N_*\sim M/2\) 行求和便得 \(M\log M+O(M)\)。
第二式的 \(1/(r-q)\) 部分精确为
\(N_*H_{N_*-1}-(N_*-1)\)；各式的第二个倒数和均为 \(O(M)\)。
由上文中心替换误差 \(o(1)\)、\(\ell M\to c/4\) 及
\(L_M,T_M\sim\log M\)，约化普通核的双线性交叉与 \(g\) 自项分别为
\[
Q_{\rm ord}(f,g)\to-\kappa^2c/8,
\qquad Q_{\rm ord}[g]\to-\kappa^2c/8.\tag{12}
\]
第一式有核恒等式中的 \(1/2\)；第二式因 \(q<r\) 的两种有序方向恰好抵消这个 \(1/2\)。

令 \(m_\pm=\int b_\ell(t)e^{\pm t/2}dt\)，则
\(m_+m_-=\kappa^2\ell+o(\ell)\)。四个极点矩精确为
\[
\begin{array}{ll}
p_+(f)=m_+\sqrt{pL_M}/2,
&p_-(f)=2m_-M/\sqrt{pL_M},\\
p_+(g)=m_+\sqrt{pT_M}/2,
&p_-(g)=2m_-N_*/\sqrt{pT_M}.
\end{array}
\]
由 \(Q_{\rm pol}[v]=2p_+(v)p_-(v)\) 的极化，
\[
Q_{\rm pol}(f,g)
=m_+m_-\!\left(N_*\sqrt{L_M/T_M}
+M\sqrt{T_M/L_M}\right)\to3\kappa^2c/8,
\quad
Q_{\rm pol}[g]=2N_*m_+m_-\to\kappa^2c/4.\tag{13}
\]
式 (12)--(13) 给交叉净普通加极点贡献 \(\kappa^2c/4\)。
再合并精确素数交叉 (6)，即得 (9) 第二行。

为算 \(g\) 的素数常数，置 \(D=\gamma+\log2\)。
note 857 的加权素数定理减去所有 \(2\) 的幂给
\(A_{\rm odd}(x)=\log x-D+R(x)\)，其中 \(R\) 有界且趋零。
又 \(T(x)=2\sum_{a\le x,\ a\ {\rm odd}}1/a=\log x+D+O(x^{-1})\)，故
\[
\sum_{\substack{a\le M\\a\ {\rm odd}}}
\frac2a\log(M/a)
=\int_1^M\frac{T(x)}x\,dx
=\tfrac12(\log M)^2+D\log M+O(1).
\]
把 \(R(M/a)\) 按 \(a\le M/A\) 与 \(a>M/A\) 拆开，
先令 \(M\to\infty\) 再令 \(A\to\infty\)，其加权和为
\(o(\log M)\)。因此式 (8) 的完整两臂 prime 罚项精确为
\[
\frac2{T_M}\sum_{\substack{a\le M\\a\ {\rm odd}}}
\frac2a A_{\rm odd}(M/a)
=\log M-D+o(1).\tag{14}
\]
同槽项为 \(\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)\)；
结合 (12)--(14) 与
\(\log(1/\ell)-\log M\to\log(4/c)\)，得到 (9) 第三行。

最后验证正定性，避免把非零 Schur 扣款误读成负方向。
note 858 给
\(C_\varphi+\kappa^2+\gamma\ge46/25\)。
记 \(\delta=46/25-\log(2\pi)>0\)；因
\(\kappa^2\le1\)，且
\(\log(4/c)-1+c/4\) 与
\(\log(4/c)-1+c/8\) 都在 \(0<c<1\) 上递减，
再用 \(\log2>2/3\)，
\[
F\ge2\log2-3/4+\delta>7/12,\qquad
G\ge3\log2-7/8+\delta>9/8.
\]
同时 \(B<0\) 且 \(|B|\le\log2<7/10\)。于是
\((F-1/20)(G-1/20)>(8/15)(43/40)>49/100>B^2\)；
故极限矩阵 \(\left(\begin{smallmatrix}F&B\\B&G\end{smallmatrix}\right)\succeq(1/20)I\)。
又 \(B\le-\log2+1/4<0\)，所以 (10) 严格为正。
此精确化仍是未完成异源复核的解析草稿。

精确边分类不能直接照搬到分母无界的伴随格。若把 \(q=a/r\)
（约分后分母为 \(r\)）与整数槽 \(n\le M\) 比较，则非精确平移
\(n-kq\) 的绝对值只保证至少 \(1/r\)，而槽重叠允许的误差至多
\(M(e^\ell-1)=c/4+o(1)\)。因此 \(c<4/r\) 是同一整数性排除法的
充分条件；固定 \(c>0\) 时，它不覆盖 \(r\to\infty\)。
这正是继续扩大分母层前必须重新估计的近错位 prime-shift 项。
