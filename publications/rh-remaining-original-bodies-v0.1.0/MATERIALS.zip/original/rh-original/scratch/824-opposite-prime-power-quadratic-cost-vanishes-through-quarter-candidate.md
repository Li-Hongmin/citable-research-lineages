# 异臂高次素数幂在真实 forcing 上的二次型支付越过四分之一（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的异臂近共振矩阵与 [scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的真实 forcing。下面只估计指定二次型，适用范围大于 scratch 821 的高次素数幂算子范数范围；尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)，\(H=\log p\)，\(B=\lfloor p^\beta\rfloor\)，固定 \(0<\beta<1/3\)，并取
\[
\mathcal Y_{p,B}
=\{m/b:2\le b\le B,\ p\le m<bp,\ (m,b)=1\},
\qquad \Delta=\tfrac12\log(1+p^{-2}).
\]
将 818 的 \(N^{\rm opp}_{p,B}\) 中平移指标 \(n=\ell^j\)、\(j\ge2\) 的完整部分记为 \(N^{\rm opp,pp}_{p,B}\)。对任意系数列 \(u=(u_{m/b})\) 满足
\[
|u_{m/b}|\le C\frac{H}{\sqrt{mb}}
\quad(m/b\in\mathcal Y_{p,B}),
\tag{1}
\]
以及任意固定 \(\varepsilon>0\)，有
\[
\boxed{\quad
|\langle u,N^{\rm opp,pp}_{p,B}u\rangle|
\ll_{C,\beta,\varepsilon}
H^4 B^3 p^{-1+\varepsilon}=o(1)
\quad}
\tag{2}
\]
其中末步取 \(\varepsilon<1-3\beta\)。只要另选 \(\alpha\) 满足 819 的 \(\beta<\min\{\alpha,1-\alpha\}\)，其实际 \(t\) 和素数 forcing \(t^{\rm pr}\) 都满足 (1)，所以 (2) 对它们成立。特别地，\(\beta=1/4\) 被包含，并对 819 的 \((\alpha,\beta)=(2/3,1/4)\) 实例给出
\[
\langle t,N^{\rm opp}_{p,B}t\rangle
=\langle t,N^{\rm opp,pr}_{p,B}t\rangle+o(1),
\qquad
\frac{\|P_ZA_{p^2,-}v_{p,2/3}\|}{H\|v_{p,2/3}\|}
\longrightarrow\frac{\sqrt{307}}{64}
\quad\text{（819 的 forcing 范数主项）}.
\tag{2a}
\]
本命题不声称该端点的 **算子范数** 趋零，也不估计素数平移的有符号二次型。

## 证明

记 \(y=m/b\)、\(y'=m'/b'\)。任一有效的高次素数幂平移 \(n\) 满足
\[
\left|\log\frac n{yy'}\right|<2\Delta,
\qquad \delta=nbb'-mm',
\qquad |\delta|<bb',
\tag{3}
\]
且
\[
\frac{p^2}{B^2(1+p^{-2})}<n<p^2+1.
\tag{4}
\]
这里 \(|\delta|<bb'\) 来自 \(mm'<bb'p^2\) 与 \(e^{2\Delta}=1+p^{-2}\)；(4) 则用 \(yy'\ge p^2/B^2\)、\(yy'<p^2\)。

固定 \(n,b,b',\delta\) 后，\(mm'=nbb'-\delta\) 的有序正整数解不超过 \(\tau(nbb'-\delta)\)。式 (3)--(4) 给 \(0<nbb'-\delta\ll p^2B^2\)，故标准除数界对任意 \(\varepsilon>0\) 一致给出
\[
\tau(nbb'-\delta)\ll_{\beta,\varepsilon}p^\varepsilon.
\tag{5}
\]
精确乘积关系还给出单项权重的关键节省：因 \(|\delta|<bb'\) 且 \(n\to\infty\)，
\[
\sqrt{mb\,m'b'\,n}
=\sqrt{(nbb'-\delta)bb'n}
\ge \frac{nbb'}{\sqrt2}.
\tag{6}
\]
于是由 (1)、\(|R_\Delta|\le1\) 与 \(\Lambda(n)\le2H+O(1)\)，每个有序因子配对对二次型的绝对贡献至多
\[
\frac{C^2H^2\Lambda(n)}{\sqrt{mb\,m'b'\,n}}
\ll_C\frac{H^3}{nbb'}.
\tag{7}
\]
固定 \(n,b,b'\) 时 (3) 允许的整数 \(\delta\) 不超过 \(2bb'+1\ll bb'\) 个。将 (5)--(7) 相乘，再对 \(2\le b,b'\le B\) 求和，得到
\[
|\langle u,N^{\rm opp,pp}u\rangle|
\ll_{C,\beta,\varepsilon}
H^3B^2p^\varepsilon
\sum_{\substack{n\gg p^2/B^2\\n\le p^2+1,\ n=\ell^j,\ j\ge2}}\frac1n.
\tag{8}
\]
高次素数幂的初等计数界
\(\#\{n\le X:n=\ell^j,j\ge2\}\ll\sqrt X\log(2X)\)
经分部求和给
\[
\sum_{\substack{n\ge p^2/(2B^2)\\n=\ell^j,\ j\ge2}}\frac1n
\ll \frac{HB}{p}.
\tag{9}
\]
把 (9) 代入 (8) 即得 (2)。

为核对真实 forcing 的条件，819 式 (1) 中有贡献的 \(n=\ell^j\) 必须满足 \((m,n)>m/Q>1\)，故 \(\ell\mid m\)。对 \(\ell^v\Vert m\)，\(j\le v\) 的总权至多 \(v\log\ell\)，\(j>v\) 的总权至多 \(\log\ell\)；对 \(\ell\mid m\) 求和给 \(t_{m/b}\le2\log m/\sqrt{mb}\ll H/\sqrt{mb}\)。\(t^{\rm pr}\) 更直接满足此界。\(\square\)

## 边界

式 (2) 是真实 forcing 尺度上的绝对支付，因此可以与 819 的 \(\beta=1/4\) 范数主项合用；它不删除素数平移，也不能把 forcing 泄漏改写成 Schur 成本。\(\beta<1/3\) 来自本证明的 \(B^3/p\) 上界，并未判定真实临界指数。
