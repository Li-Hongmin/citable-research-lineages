# 真实 (k=3,4) 观察交叉无精确碰撞，近碰撞是两仿射 Möbius 相关

日期：2026-10-02。接 [scratch/924](924-mobius-inversion-moves-the-full-observation-to-cofactors-at-least-three.md) 的真实 $\mu*1=\delta_1$ 源核及 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的带通观察。此处只研究完整源展开中的两个指定 cofactor 的交叉块；其他 cofactor 可与它抵消。证明使用 Matomäki–Shao–Tao–Teräväinen 2023 Theorem 3.1(i) 的全区间 Möbius 短和。结论不是完整 moving-$N$ 门的固定幂界，尚未异源复核。

## 精确交叉式与无碰撞

令 $M=2Y$、$H=\lceil Y^{1/5}\rceil$、$\psi\in C_c^3((1,2))$ 为实值非负非零函数，$\phi(u)=\psi(u)/u$。取偶非负权 $w_H(h)=v(h/H)$，其中 $v$ 支撑于 $1/2\le|t|\le4$ 且 $v\ge1$ 于 $1\le|t|\le2$；记
\[
J_H(r)=\sum_hw_H(h)e(-hr/M),\quad
L=\lfloor M/(32H)\rfloor,\quad
T=H^3(\log M)^\gamma\quad(\gamma>0\text{ 固定}).                 \tag{1}
\]
令 $\kappa(3)=-4\log(3/2)$、$\kappa(4)=-2\log2$，并定义两个真实源的 Fourier 包
\[
F_k(h)=\frac{\kappa(k)}M
\sum_{M<kd<2M}\mu(d)\phi(kd/M)e(-hkd/M)
\qquad(k=3,4).                                               \tag{2}
\]
它们在 $T<|m-n|\le L$ 的单向交叉恰为
\[
\boxed{\quad
\mathcal C_{34}(T,L)=\frac{\kappa(3)\kappa(4)}{M^2}
\sum_{\substack{M<3d,4e<2M\\T<|3d-4e|\le L}}
\mu(d)\mu(e)\phi(3d/M)\phi(4e/M)J_H(3d-4e).
\quad}                                                       \tag{3}
\]
若 $3d=4e$，则 $d=4t,e=3t$，所以 $\mu(d)=0$。更强地，任何 $r=3d-4e\equiv0\pmod4$ 都强制 $4\mid d$，这一整类位移对 (3) **逐项为零**。

对 $4\nmid r$，取唯一 $a_r\in\{1,2,3\}$ 使 $3a_r\equiv r\pmod4$，置 $b_r=(3a_r-r)/4\in\mathbb Z$。所有满足 $3d-4e=r$ 的整数解唯一写成
\[
d=4t+a_r,\qquad e=3t+b_r.                                \tag{4}
\]
因此 (3) 的内和按 $r$ 分层后正是受物理窗口限制的
\[
\sum_t\mu(4t+a_r)\mu(3t+b_r)
\phi\!\left(\frac{12t+3a_r}M\right)
\phi\!\left(\frac{12t+4b_r}M\right).                       \tag{5}
\]
两仿射形式的行列式 $4b_r-3a_r=-r$；它们的公因子只可能整除 $r$。无精确碰撞只删除 $4\mid r$ 的层，并不使 (5) 的其余相关恒为零。

## 正负常量块同时存在，净和只有对数界

固定闭区间 $J\subset(1,2)$ 使 $\phi\ge c_\psi>0$ 于 $J$。当 $|r|\le L$ 时，$|h|\le4H$ 给 $|2\pi hr/M|\le\pi/4$，故 $J_H(r)\gg_vH>0$。把 $MJ$ 分成 $\gg_\psi M/L$ 个互不相交的长 $L$ 整数格 $C$。每格的集合
\[
\{d:3d\in C\},\qquad \{e:4e\in C\}
\]
分别是长度 $L/3+O(1)$、$L/4+O(1)$ 的区间。平方自由数的初等区间计数与所引 2023 年全区间短和给，一致于这些格，
\[
\#\{n\in I:\mu(n)=+1\}
=\#\{n\in I:\mu(n)=-1\}
=\frac3{\pi^2}|I|+o(L)                                      \tag{6}
\]
对上述两个 $I$ 都成立：$\sum_{n\in I}\mu(n)^2=(6/\pi^2)|I|+O(\sqrt M)$，而 $\sum_{n\in I}\mu(n)=O_A(L\log^{-A}M)$。区间长度 $\asymp L\asymp M^{4/5}$，满足定理的 $7/12+\varepsilon$ 范围。

故每格既有 $\gg L^2$ 个 $\mu(d)\mu(e)=+1$ 配对，也有 $\gg L^2$ 个 $\mu(d)\mu(e)=-1$ 配对。对每个 $d$，$|3d-4e|\le T$ 的 $e$ 至多 $O(T+1)$ 个；总删除比例 $O(T/L)=M^{-1/5+o(1)}$。因为 $\kappa(3)\kappa(4)>0$、$\phi$ 与 $J_H$ 在所选配对上为正，(3) 中限制到同格且保留 $T<|3d-4e|\le L$ 的正号子块为 $\gg_{\psi,v}1$，负号子块为 $\ll_{\psi,v}-1$。这里的量纲是
\[
\frac{H}{M^2}\frac ML L^2\asymp\frac{HL}{M}\asymp1.  \tag{7}
\]
式 (6) 已自动排除 $4\mid r$ 的零项，因为那时 $\mu(d)=0$。

另一方面，完整的带符号 (3) 对任意固定 $A>0$ 满足
\[
\boxed{\quad\mathcal C_{34}(T,L)=O_{A,\psi,v,\gamma}(\log^{-A}M).\quad} \tag{8}
\]
证明：固定 $d$，允许的 $e$ 是至多两个长度 $O(L)$ 的整数区间，嵌入尺度 $e\asymp M$、长度 $\asymp L$ 的母区间。Theorem 3.1(i) 的最大进程界使其中任意前缀的 $\mu$ 和为 $O_B(L\log^{-B}M)$。权 $e\mapsto\phi(4e/M)J_H(3d-4e)$ 的上确界加总变差为 $O_{\psi,v}(H)$，因为 $|J_H|\ll H$、$|J_H'|\ll H^2/M$ 且 $HL/M\ll1$。Abel 求和给固定 $d$ 的内和 $O_B(HL\log^{-B}M)$；再用 $\sum_{d\asymp M}|\mu(d)|\ll M$ 和 $HL/M\asymp1$，得到 (8)。

式 (7)--(8) 只解释常量级正负块怎样达到**对数级**净相消。要支付 $H^4/M=M^{-1/5+o(1)}$，仍需对 (5) 的加权位移平均给出固定幂界，或在完整 cofactor Gram 中证明与其他交叉项的联合抵消。单独的 $k=3,4$ 交叉既非完整门的必要独立上界，也不能由精确碰撞消失推出目标界。

## 完成同一物理行后，$k=4$ 分支已逐点消失

上述候选路线还有一个更强的真实代数边界。[scratch/863](863-direct-mobius-observation-channel-is-not-a-necessary-standalone-gate.md) 式 (1) 给出：若 $4\mid m$ 且 $m$ 不是 $2$ 的幂，则 $c(m)=2=b(m)$；若 $m=2^j$、$j\ge2$，则 $c(m)-b(m)=-2\log2$。代入 scratch/924 式 (3)，得到整个 $4$ 整除物理行的**精确**源补偿
\[
\boxed{\quad
\sum_{\substack{d\mid m\\m/d\ge3}}\mu(d)\kappa(m/d)
=-2(\log2)\mathbf1_{m=2^j,\ j\ge2}
\qquad(4\mid m).
\quad}                                                       \tag{9}
\]
所以 (3) 的 $k=4$ 项 $\kappa(4)\mu(m/4)$，连同该物理点上其余所有 cofactor 源，除极稀疏的 $2$ 的幂外总和为零。观察窗 $(M,2M)$ 至多含一个 $2$ 的幂；其归一化 Fourier 包逐频为 $O_\psi(M^{-1})$，带通平方和为 $O_{\psi,v}(H/M^2)$。用完整源包的 Parseval 平方范数 $O_\psi(\log M)$ 作 Cauchy--Schwarz，其与所有其他物理行的**完整带通交叉**也为
\[
O_{\psi,v}\!\left(\frac{\sqrt{H\log M}}M\right)
=o(H^4/M).                                                  \tag{10}
\]
因此 $k=3,4$ 的孤立交叉 (3) 即使未获固定幂单独上界，也不是完整观察门的必要条件。其常量级子块由同一 $4e$ 物理行的其他源逐点补偿；继续单独攻击 (5) 不会优先改变真实门的判断。式 (9)--(10) 先完成**全部** cofactor 才成立，不能据此逐项删除 scratch/924 式 (7) 截断后的孤立 $k=4$ 源。完整观察中剩余的承重物理行是奇数和 $v_2(m)=1$ 两类，须保留 [scratch/863](863-direct-mobius-observation-channel-is-not-a-necessary-standalone-gate.md) 的联合双臂。
