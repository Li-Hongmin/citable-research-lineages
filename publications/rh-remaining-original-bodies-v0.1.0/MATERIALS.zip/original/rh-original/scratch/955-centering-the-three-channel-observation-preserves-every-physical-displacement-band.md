# 三通道观察系数补常数 3 后逐物理位移带保持目标精度

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实系数及式 (29)–(31)，以及 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 短和。此为探索证明，尚待异源复核；不证明固定幂算术门或 RH。

## 命题

固定 $\psi\in C_c^3((1,2))$，非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，$\operatorname{supp}\eta\subset\{1/2\le |t|\le4\}$ 且 $\eta\ge1$ 于 $1\le|t|\le2$。令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$\Phi(x)=\psi(x)/x$，以及
\[
 J_H(r)=\sum_{h\in\mathbb Z}\eta(h/H)e(-hr/M),\qquad
 \mathcal Q_H^{(T,U]}(v,w)
 =\sum_{T<|m-n|\le U}v_m\overline{w_n}J_H(m-n),
\tag{1}
\]
其中 $0\le T<U\le M$，所有序列在 $M<m<2M$ 之外置零。令 $c$ 为 note 849 式 (10) 的真实系数，$c_{\rm tri}$ 为其式 (29) 的素数、倍素数和 Möbius 三通道系数，并记
\[
 a_m=\frac{c(m)}M\Phi(m/M),\quad
 t_m=\frac{c_{\rm tri}(m)}M\Phi(m/M),\quad
 t_m^\circ=\frac{c_{\rm tri}(m)+3}{M}\Phi(m/M).
\tag{2}
\]
则一致于所有 $T,U,H$，
\[
 \boxed{\left|\mathcal Q_H^{(T,U]}(a,a)
       -\mathcal Q_H^{(T,U]}(t^\circ,t^\circ)\right|
 \ll_{\psi,\eta}\frac HM+\frac{H\log(2M)}{\sqrt M}
 =o\!\left(\frac{H^4}{M}\right).}
\tag{3}
\]
未补常数的 $t$ **没有**这一逐带性质。取 $\lambda=1/32$、$T=H^3/\log^2M$、$U=\lambda M/H$。若 $\psi\ne0$，则
\[
 \boxed{\mathcal Q_H^{(T,U]}(t,t)
 \longrightarrow C_{\psi,\eta}
 :=18\left(\int_1^2|\Phi(x)|^2\,dx\right)
       \left(\int_0^{\lambda}\widehat\eta(u)\,du\right)>0,}
\tag{4}
\]
更一般地，把式 (2) 的 $c_{\rm tri}$ 改为 $c_{\rm tri}+\alpha$，其中 $\alpha\in\mathbb R$ 固定，其同一位移带二次型极限为 $(\alpha-3)^2C_{\psi,\eta}/9$。所以 $3$ 是使该带主项消失的唯一固定常数中心化。
同一求积对任意固定 $0\le u<v<\infty$ 还给出完整的位移轮廓
\[
 \mathcal Q_H^{(uM/H,vM/H]}(t,t)
 \longrightarrow18\left(\int_1^2|\Phi(x)|^2dx\right)
                   \left(\int_u^v\widehat\eta(s)ds\right).
\tag{4a}
\]
由于 $\eta(0)=0$，Fourier 反演给 $\int_0^\infty\widehat\eta(s)ds=0$；故未中心化三通道在短正位移处的主项，必被其他物理位移的负核轮廓抵消。
而
\[
 \mathcal Q_H^{(T,U]}(a,a)=o(1),\qquad
 \mathcal Q_H^{(T,U]}(t^\circ,t^\circ)=o(1).
\tag{5}
\]
若 $b_m=(4-2\mathbf1_{2\mid m})\Phi(m/M)/M$ 是原式中的确定性背景，则同一带内还成立
\[
 \mathcal Q_H^{(T,U]}(b,b)\to C_{\psi,\eta},\qquad
 2\operatorname{Re}\mathcal Q_H^{(T,U]}(t,b)\to-2C_{\psi,\eta}.
\tag{5a}
\]
这给出完整系数的 $O(1)$ 主项如何精确相消；$P_2$ 素数幂项在此极限中消失。
在 $H\asymp M^{1/5}$ 时，目标 $H^4/M\asymp M^{-1/5}$，所以式 (4) 给出未中心化替换的定量失败。式 (3) 仅是对物理位移裁剪的精确化；中心化后的余门仍缺固定幂 signed 估计。

## 证明

置 $P_2(n)=\Lambda(n)-\mathbf1_{n\text{ prime}}\log n$。note 849 式 (31) 给逐点恒等式
\[
 c(m)-[c_{\rm tri}(m)+3]
 =z(m)+p(m),\quad
 z(m)=1-2\mathbf1_{2\mid m}=-(-1)^m,\quad
 p(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m).
\tag{6}
\]
平方以上的素数幂有总质量 $\sum_{m\asymp M}|p(m)|\ll\sqrt M\log(2M)$，故其加权序列 $p(m)\Phi(m/M)/M$ 的 $\ell^1$ 范数为 $O_\psi(M^{-1/2}\log(2M))$。Chebyshev 上界及 $|\mu|\le1$ 同时给 $\|a\|_1+\|t^\circ\|_1\ll_\psi1$。由 $|J_H|\ll_\eta H$，含一个 $p$ 因子的混合二次项均为 $O_{\psi,\eta}(H M^{-1/2}\log(2M))$。

固定外侧 $m$，在内侧 $n$ 上令
$F_m(n)=\overline{\Phi(n/M)}J_H(m-n)\mathbf1_{T<|m-n|\le U}$。
Poisson 公式
\[
J_H(r)=H\sum_{j\in\mathbb Z}\widehat\eta\bigl(H(r/M+j)\bigr)
\tag{7}
\]
及 $\psi$ 的紧支撑表明，在所有实际 $m,n$ 上，$|m-n|\le(1-\sigma_\psi)M$。对任意固定 $A>3$，非零别名可由 Schwartz 衰减吸收；直接积分 $J_H'$ 与 $\Phi'$，再计入位移带至多四个跳点，得到
\[
 \|F_m\|_\infty+\operatorname{Var}(F_m)\ll_{\psi,\eta}H
 \quad\text{一致于 }m,T,U,H.
\tag{8}
\]
因为 $z(n)$ 的任一前缀和绝对值至多 $1$，离散 Abel 给 $|\sum_n z(n)F_m(n)|\ll H$。除以 $M$ 并用外侧序列的 $\ell^1$ 界，所有含一个 $z$ 的混合项至多 $O(H/M)$；核的 Hermitian 对称性可交换内外侧。展开 $a=t^\circ+(z+p)\Phi/M$，即得 (3)。其相对目标的比至多
\[
 O\!\left(H^{-3}+\frac{\sqrt M\log(2M)}{H^3}\right)
 =O(M^{-1/10}\log(2M))=o(1),
\tag{9}
\]
因为 $H\gg M^{1/5}$。

为证 (4)，先记 $r(m)=c_{\rm tri}(m)+3$。Ramachandra 输入应用于 $c$ 后，对任意整数区间 $I\subset[M,2M]$，任取固定 $1/2<\vartheta<3/5$ 且 $\vartheta>7/12$，有
\[
 \left|\sum_{m\in I}c(m)\right|
 \ll |I|e^{-cV_M}+M^\vartheta,
 \qquad V_M=(\log M/\log\log M)^{1/3}.
\tag{10}
\]
式 (6)、$\sum_I z=O(1)$ 与 $\sum|p|\ll\sqrt M\log M$ 表明 (10) 对 $r$ 也成立。由 (7) 的导数界，以 $W=M/H$ 为第零位移壳、再按 $2^jW$ 分壳；每壳同位移带相交后只有固定个整数区间。相应光滑权的上确界加变差为 $O(H2^{-j(A-1)})$。对 (10) 作离散 Abel，再求几何级数，便有对任意 $\ell^1$ 有界的外侧序列 $v$，
\[
 |\mathcal Q_H^{(T,U]}(r\Phi/M,v)|
 \ll_{\psi,\eta,\vartheta}\|v\|_1
       \bigl(e^{-cV_M}+H M^{\vartheta-1}\bigr).
\tag{11}
\]
特别地，(11) 适用于 $v=r\Phi/M$、$t$、$a$ 和以下平滑序列。写
$s_m=-3\Phi(m/M)/M$，则 $t=r\Phi/M+s$。由 (11)，
\[
\mathcal Q_H^{(T,U]}(t,t)
=\mathcal Q_H^{(T,U]}(s,s)
 +O(e^{-cV_M}+H M^{\vartheta-1}),
\tag{12}
\]
且同理 $\mathcal Q_H^{(T,U]}(a,a)=O(e^{-cV_M}+H M^{\vartheta-1})$；后一式也可直接由 (10) 得到。

在 $T=H^3/\log^2M$、$U=\lambda M/H$ 下，$T/(M/H)\le1/\log^2M$。对 $|k|\le U$，式 (7) 的非零别名为 $O_A(H^{1-A})$。Riemann 求和及 $k/M=O(1/H)$ 给
\[
\sum_n\Phi((n+k)/M)\overline{\Phi(n/M)}
=M\int_1^2|\Phi(x)|^2dx+o(M)
\tag{13}
\]
一致于 $|k|\le U$。再在 $k$ 上作 Riemann 求和，得到
\[
 \mathcal Q_H^{(T,U]}(s,s)
 =18\left(\int_1^2|\Phi(x)|^2dx\right)
   \left(\int_0^\lambda\widehat\eta(u)du\right)+o(1).
\tag{14}
\]
因为 $0\le u\le1/32$、$|t|\le4$ 时 $\cos(2\pi ut)\ge1/\sqrt2$，故 $\widehat\eta(u)>0$。式 (12)–(14) 证明 (4)–(5)。$\square$

式 (5a) 由同一估计立即给出：$b_m=3\Phi(m/M)/M+z(m)\Phi(m/M)/M$，含 $z$ 的混合项由 (8) 支付；$t=s+r\Phi/M$，含 $r$ 的混合项由 (11) 支付。留下的两个平滑序列恰好相反，故自项为 $C_{\psi,\eta}$，交叉项为 $-2C_{\psi,\eta}$。

## 算术边界

补回的常数 $3$ 是 $4-2\mathbf1_{2\mid m}$ 的平均值。整段观察频带的 Fourier 变换会自动消去该光滑背景，但对位移带作硬裁剪时，背景的自协方差保留式 (4) 的正主项；它与三通道背景的交叉项相消。因此以后若逐位移带分析 note 849 式 (15)，可用 $c_{\rm tri}+3$ 作目标精度内的替换，不能直接用 $c_{\rm tri}$。余下的固定幂问题仍是中心化真实素数、倍素数与 Möbius 系数的联合二点抵消。
