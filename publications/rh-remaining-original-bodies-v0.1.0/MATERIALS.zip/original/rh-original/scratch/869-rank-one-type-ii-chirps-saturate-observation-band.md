# 秩一 Type II 系数在观察频带的驻相反模型

日期：2026-10-02。针对 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (9)、(15) 的 \(H=Y^{1/5}\) 频带。这里的因子系数是人为构造的单位模乘性相位，**不是**真实 \(\Lambda,\mu\) 系数；本证明只判定系数无关的 Type II 大筛是否足够。

## 命题

固定非负 \(\psi\in C_c^\infty((1,2))\)，且 \(\psi\not\equiv0\)。沿平方整数 \(Y=N^2\to\infty\)，令 \(H=\lceil Y^{1/5}\rceil\)。存在先固定的 \(0\le u,v\le1\)、\(u,v\in C_c^\infty((1,2))\)、常数 \(\varepsilon,c>0\) 与随 \(Y\) 变化的实数 \(T=2\pi t_*H\)，使
\[
 a_m=u(m/N)m^{iT},\qquad b_n=v(n/N)n^{iT},\qquad
 B_h=\frac1Y\sum_{m,n\ge1}a_mb_n\psi(mn/Y)e(-hmn/Y)
\tag{1}
\]
满足
\[
 |B_h|\ge cH^{-1/2}
 \quad(H\le h\le(1+\varepsilon)H,\ h\in\mathbb Z).
\tag{2}
\]
因此若 \(\eta\ge0\) 且 \(\eta\ge1\) 于 \([1,2]\)，
\[
 \sum_{h\in\mathbb Z}\eta(h/H)|B_h|^2\gg_{\psi,u,v}1,
\tag{3}
\]
而 note 849 式 (15) 在此尺度所需的是 \(H^4/Y=Y^{-1/5+o(1)}\)。即使 Type II 两侧系数各自逐点有界，通用的系数无关均方界也无法支付该频带门。

## 证明

取 \(t_*\in(1,2)\) 使 \(\psi(t_*)>0\)，并在 \(x_*=y_*=\sqrt{t_*}\in(1,\sqrt2)\) 的充分小邻域内取 \(0\le u,v\le1\) 且 \(u(x_*),v(y_*)>0\)，使
\[
 A(t)=\psi(t)\int_0^\infty u(x)v(t/x)\frac{dx}{x}
\tag{4}
\]
在 \(t_*\) 附近的一个闭区间上有 \(A(t)\ge c_0>0\)。选 \(\varepsilon>0\) 足够小，使 \(t_h=t_*H/h\) 对 \(H\le h\le(1+\varepsilon)H\) 都位于此区间内部，且与 \(\operatorname{supp}A\) 的边界相距一个固定正量。

对这些 \(h\)，先将 (1) 的二维整数和换成积分。被求和函数的 \(m\) 导数在 \(m,n\asymp N\) 上为 \(O(H/N)\)，其 \(n\) 导数亦然；两个变量各有 \(O(N)\) 个有效整数点。逐变量使用一阶求积 \(|\sum_{k\in\mathbb Z}F(k)-\int F|\le\int|F'|\)，得到统一误差 \(O(HN)\)。由于 \(Y=N^2\)，变量替换 \(m=Nx,n=Ny,t=xy\) 给
\[
 B_h=e^{iT\log Y}I_h+O(H/\sqrt Y),
 \qquad
 I_h=\int_{\mathbb R}A(t)
 e^{\,2\pi iH[t_*\log t-(h/H)t]}\,dt.
\tag{5}
\]
相位 \(f_h(t)=t_*\log t-(h/H)t\) 在 \(t_h=t_*H/h\) 处有唯一非退化驻点，且
\[
 f_h''(t_h)=-t_*/t_h^2.
\]
固定幅度 \(A\) 与参数 \(h/H\) 均落在紧集内，一维一致驻相给
\[
 I_h=e^{\,2\pi iHf_h(t_h)-i\pi/4}
 \frac{A(t_h)t_h}{\sqrt{Ht_*}}
 +O_{\psi,u,v}(H^{-3/2}).
\tag{6}
\]
式 (4) 的下界故给 \(|I_h|\ge c_1H^{-1/2}\)。因为 \(H/\sqrt Y=Y^{-3/10+o(1)}=o(H^{-1/2})\)，式 (5) 推出 (2)。区间 \([H,(1+\varepsilon)H]\) 含 \(\asymp H\) 个整数，逐项平方即得 (3)。\(\square\)

## 对角质量匹配后的反模型

把 (1) 的第一侧改为 \(\widetilde a_m=a_m/\log Y\)，第二侧不变，并设
\[
 \gamma_Y(k)=\sum_{mn=k}\widetilde a_m b_n,\qquad
 w_Y(k)=Y^{-1}\gamma_Y(k)\psi(k/Y).
\]
则其频带和 \(\widetilde B_h=\sum_k w_Y(k)e(-hk/Y)=B_h/\log Y\) 满足
\[
 \sum_h\eta(h/H)|\widetilde B_h|^2\gg(\log Y)^{-2},
 \qquad
 \sum_k|w_Y(k)|\ll(\log Y)^{-1},\qquad
 \sum_k|w_Y(k)|^2\ll\frac{\log Y}{Y}.
\tag{7}
\]
最后一项与 note 849 式 (16) 的真实系数对角量级相同，而频带能量对每个固定 \(0<\delta<1/5\) 仍大于其目标 \(H^4Y^{-1+\delta}\)。

证明后两个上界时，\(\widetilde a_m,b_n\) 的支撑各含 \(O(N)\) 个整数，故三角不等式给 \(\sum_k|w_Y(k)|\ll 1/\log Y\)。又因 \(|\gamma_Y(k)|\le d(k)/\log Y\)，其中 \(d\) 是约数函数，
\[
 \sum_k|w_Y(k)|^2
 \ll\frac1{Y^2\log^2Y}\sum_{k\le4Y}d(k)^2
 \le\frac1{Y^2\log^2Y}\sum_{k\le4Y}d_4(k)
 \ll\frac{\log Y}{Y}.
\tag{8}
\]
逐素数幂有 \((j+1)^2\le\binom{j+3}{3}\)，所以 \(d(k)^2\le d_4(k)\)；而
\(\sum_{k\le x}d_4(k)\le x(\sum_{n\le x}1/n)^3\ll x\log^3(2x)\)。
第一个下界直接由 (3) 除以 \(\log^2Y\) 得到。沿偶数 \(N\) 可置 \(Y=2Y_{\rm 849}\)，于是此处的 Fourier 周期恰为 note 849 的 \(M=2Y_{\rm 849}\)；用固定光滑权 \(t\psi(t)\) 还可把 \(Y^{-1}\psi(k/Y)\) 精确改写成 \(k^{-1}[t\psi(t)]_{t=k/Y}\)。这只比较通用系数估计，不把 \(\gamma_Y\) 误认成真实 \(c(k)\)。\(\square\)

## 结论的精确边界

此反模型专门排除只依赖因子系数逐点有界、Type II 支撑、note 849 式 (16) 的总质量与对角质量及光滑权的 \(O(Y^\varepsilon H^4/Y)\) 频带估计。其核心是可伪装成共同乘性频率 \(m^{iT}n^{iT}=(mn)^{iT}\) 的秩一相位。它没有给真实 \(c(m)\) 或 Möbius signed covariance 的下界；下一步若走 Type II，必须使用真实算术系数对 \(n^{iT}\) 类驻相载波的排斥或联合消去。
