# 两条 dyadic 观察已构成完整的素数误差–Möbius 线性框架

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10) 的真实系数与 [scratch/908](908-even-observation-and-odd-coefficient-reconstruct-the-prime-error.md) 的素数误差消元。本稿补齐 [scratch/905](905-odd-prime-dilates-give-an-exact-rank-two-cross-scale-frame.md) 的最小秩判断：两条 dyadic 线已经是秩二，第三条奇素数倍数线是线性冗余。以下是精确恒等式和带通范数比较；没有证明任一包的固定幂上界，也不证明 RH。后续 [scratch/910](910-dyadic-frame-and-local-convolution-still-admit-supercritical-prime-flip-models.md) 说明这些线性恒等式本身仍容许超目标反模型，必须另用全域 \(\Lambda=\mu*\log\) 耦合。

## 逐点两行逆矩阵

令 \(\ell=\log2\)，对所有正整数取 note 849 的
\[
c(n)=2\mathbf1_{2\mid n}(\Lambda(n/2)-1)
-4(\Lambda(n)-1+\ell\mu(n)).                    \tag{1}
\]
每个奇数 \(n>1\) 都满足
\[
\begin{pmatrix}c(n)-4\\c(2n)-2\end{pmatrix}
=\begin{pmatrix}-4&-4\ell\\2&4\ell\end{pmatrix}
\begin{pmatrix}\Lambda(n)\\\mu(n)\end{pmatrix},
\qquad \det=-8\ell\ne0.                           \tag{2}
\]
所以
\[
\boxed{\quad
\Lambda(n)=\frac{6-c(n)-c(2n)}2,
\qquad
\mu(n)=\frac{c(n)+2c(2n)-8}{4\ell}.
\quad}                                             \tag{3}
\]
证明只用 \(\Lambda(2n)=0\)、\(\mu(2n)=-\mu(n)\)。对于偶数 \(n>1\)，还有精确式
\[
c(2n)=2-2\Lambda(n).                              \tag{4}
\]
因为 \(\mu(2n)=0\)，且 \(\Lambda(2n)=\Lambda(n)\)：非零时两者都是 \(\log2\)。
若 \(q\ge3\) 是奇素数且 \(q\nmid n\)，则 [scratch/905](905-odd-prime-dilates-give-an-exact-rank-two-cross-scale-frame.md) 的第三线因此可直接写成
\[
c(qn)=4+4\ell\mu(n)=c(n)+2c(2n)-4
\qquad(n>1\text{ 奇}).                              \tag{5}
\]
这里 \(n=1\) 必须排除：\(c(1)=4-4\ell\)、\(c(2)=2\)，并不满足 (2)--(3)。

这也是全部有限 dyadic 滤波的分类。对奇数 \(n>1\) 与 \(k\ge2\)，直接由 (1) 得 \(c(2^kn)=2\)。故任意有限系数 \(u_k\) 满足
\[
\sum_{k\ge0}u_kc(2^kn)
=4u_0+2\sum_{k\ge1}u_k
+(-4u_0+2u_1)\Lambda(n)
+4\ell(u_1-u_0)\mu(n).                         \tag{5a}
\]
消去 \(\mu\) 强制 \(u_1=u_0\)，只剩素数项；消去 \(\Lambda\) 强制 \(u_1=2u_0\)，只剩 Möbius 项。同时消去二者则 \(u_0=u_1=0\)，其余各线全是常数背景。

## 中频带的定量框架

固定 \(\phi\in C_c^3((1,2))\)，\(X\) 充分大，令 \(e(t)=e^{2\pi it}\)，并定义
\[
\begin{aligned}
O_h&=X^{-1}\sum_{n\ {m odd}}c(n)\phi(n/X)e(-hn/X),\\
D_h&=X^{-1}\sum_n c(2n)\phi(n/X)e(-hn/X),\\
P_h&=X^{-1}\sum_n(\Lambda(n)-1)\phi(n/X)e(-hn/X),\\
M_h&=X^{-1}\sum_{n\ {m odd}}\mu(n)\phi(n/X)e(-hn/X).
\end{aligned}                                      \tag{6}
\]
则有**精确**矩阵式
\[
\boxed{\quad
\begin{pmatrix}P_h\\M_h\end{pmatrix}
=\begin{pmatrix}-1/2&-1/2\\(4\ell)^{-1}&(2\ell)^{-1}\end{pmatrix}
\begin{pmatrix}O_h\\D_h\end{pmatrix}
+\begin{pmatrix}R_{P,h}\\R_{M,h}\end{pmatrix},
\qquad \det=-\frac1{8\ell}\ne0,
\quad}                                             \tag{7}
\]
其中，置 \(S_h^{\rm odd/even}=X^{-1}\sum_{n\ {m odd/even}}\phi(n/X)e(-hn/X)\)，
\[
R_{P,h}=2S_h^{\rm odd},\qquad
R_{M,h}=-\frac{S_h^{\rm even}+2S_h^{\rm odd}}\ell
+\frac1X\sum_{k\ge1}\phi(2^k/X)e(-h2^k/X).     \tag{8}
\]
这里第二行最后的和在 \((X,2X)\) 至多含一个非零项。

证明第一行正是 [scratch/908](908-even-observation-and-odd-coefficient-reconstruct-the-prime-error.md) 式 (10)。对第二行，将 (3) 在奇数 \(n\) 上乘 \(X^{-1}\phi(n/X)e(-hn/X)\) 求和，得到
\(4\ell M_h=O_h+2D_h^{\rm odd}-8S_h^{\rm odd}\)。
式 (4) 又给
\[
D_h^{\rm even}=2S_h^{\rm even}
-\frac{2\ell}{X}\sum_{k\ge1}\phi(2^k/X)e(-h2^k/X).
\]
以 \(D_h^{\rm odd}=D_h-D_h^{\rm even}\) 代回即得 (7)--(8)。

若 \(X^{1/5}\le H\le X^{1/4}\) 且 \(H/2\le|h|\le4H\)，Poisson 求和及三次分部积分在奇、偶两个格上都给
（\(\widehat\phi(\xi)=\int\phi(t)e(-\xi t)dt\)）
\[
S_h^{\rm even}=\frac12\sum_{j\in\mathbb Z}\widehat\phi(h+jX/2),
\qquad
S_h^{\rm odd}=\sum_{j\in\mathbb Z}\widehat\phi(h+jX)
-S_h^{\rm even}.
\]
因 \(\widehat\phi(\xi)=O_\phi((1+|\xi|)^{-3})\)，非零别名离 \(h\) 至少 \(X/2-O(H)\)，于是
\[
S_h^{\rm odd},S_h^{\rm even}=O_\phi(H^{-3}),
\qquad
R_{P,h},R_{M,h}=O_\phi(H^{-3}+X^{-1}).             \tag{9}
\]
因此对任意固定、有界、非负且支撑于 \(1/2\le|t|\le4\) 的带通权 \(\eta\)，
\[
\sum_h\eta(h/H)(|R_{P,h}|^2+|R_{M,h}|^2)
\ll_{\phi,\eta}H^{-5}+H/X^2
=o(H^4/X).                                       \tag{10}
\]
由于 (7) 的常数矩阵可逆，带权 \(\ell^2\) 的三角不等式给出双向等价：
\[
\boxed{\quad
\sum_h\eta(h/H)(|O_h|^2+|D_h|^2)\ll H^4/X
\ \Longleftrightarrow\
\sum_h\eta(h/H)(|P_h|^2+|M_h|^2)\ll H^4/X.
\quad}                                             \tag{11}
\]
式 (11) 中的隐含常数可依赖 \(\phi,\eta\)。它只比较**两个 dyadic 观察的联合范数**；note 849 的原始单一完整观察包在同一物理尺度上混合了不同基底尺度，不能由 (11) 单独支付。

## 与窗口内素数翻转反模型的精确分界

考虑 [scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的一类平方自由支撑乘法函数 \(f\)：\(f(n)=\mu(n)\) 于 \(n\le X\)，而 \(X<p<2X\) 的若干素数值可由 \(-1\) 翻为 \(+1\)。置 \(\Lambda_f=f*\log\)，并在 (1) 中以 \(f,\Lambda_f\) 定义 \(c_f\)。对每个翻转素数 \(p\)，逐项计算给
\[
\Lambda_f(p)=\log p,\qquad
\Lambda_f(2p)=2\ell,\qquad
c_f(p)-c_\mu(p)=-8\ell,\qquad
c_f(2p)-c_\mu(2p)=0.                         \tag{12}
\]
因此原本在真实系数成立的两行恒等式对该反模型的缺陷恰为
\[
c_f(p)+c_f(2p)-4-2(1-\Lambda_f(p))=-8\ell. \tag{13}
\]
更一般地，在 \(X<n<2X\) 中该缺陷除翻转素数外处处为零：此窗内的合数只含 \(\le X\) 的素因子，而在 \(2n<4X\) 内能碰到一个被翻转的 \(p>X\) 仅当 \(n=p\)。所以若要求反模型在这一整窗满足真实的 (13) 左侧为零，就强制所有 \(X<p<2X\) 的素数值为 \(-1\)。这准确指出 [scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的窗口资料缺少哪条跨尺度算术约束；它仍未给任何 Fourier 包的固定幂上界。

这个排除还发生在**目标频带量级**，而非仅逐点。取 scratch/904 式 (1)、(9)--(10) 所构造的一组翻转素数 \(S_1\)，令 \(X=M\)、\(H\asymp X^{1/5}\)、\(h_0=\lfloor3H/2\rfloor\)，并令本稿 \(\phi=\psi(t)/t\)。该构造保证 \(\phi(p/X)\ge c_\psi>0\)、\(\cos(2\pi h_0p/X)\ge1/2\) 于 \(p\in S_1\)，且 \(|S_1|\gg\delta_X X/\log X\)，\(\delta_X=e^{-\sqrt{\log X}}\)。定义上述 dyadic 恒等式的 Fourier 缺陷为 \(\Delta_h(f)=D_h(f)+O_h(f)+2P_h(f)-4S_h^{\rm odd}\)。由 (12)--(13)，
\[
\Delta_h(f_{10})=-\frac{8\ell}{X}
\sum_{p\in S_1}\phi(p/X)e(-hp/X),
\quad
\sum_h\eta(h/H)|\Delta_h(f_{10})|^2
\gg_{\psi,\eta}\frac{\delta_X^2}{\log^2X}
\gg\frac{H^4}{X},                                \tag{14}
\]
其中最后一个下界只保留 \(h=h_0\)，并用 \(\eta(h_0/H)\ge1\)。所以 scratch/904 **以 \(f*\log\) 定义全部两尺度系数的特定模型**在新增的 dyadic 约束下有可见的固定幂超目标缺陷。scratch/910 给出仍满足该 dyadic 约束的改型，故不能由这里推出线性框架足以支付真实门。真实 \(f=\mu\) 的 \(\Delta_h\) 则按 (7)--(8) 精确为零，仍需估计非零算术包本身。

## 路线判断

第三条奇素数倍数观察不增加线性秩；两条 dyadic 观察的未知量已经恰是素数误差与奇数 Möbius 包。式 (10) 的目标级误差只来自光滑奇偶格与稀疏的 \(2\) 的幂，并未界定 (11) 任一侧的真实算术范数。继续增加有限倍数线或证明代数零组合，不会代替真实的固定幂 signed covariance 估计。
