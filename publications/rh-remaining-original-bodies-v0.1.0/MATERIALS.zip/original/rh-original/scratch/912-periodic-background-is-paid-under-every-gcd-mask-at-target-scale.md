# 任意 gcd 筛选下完整观察的周期背景在目标量级内可删

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实系数与中距离门、[scratch/872](872-coprime-three-channel-gram-reduces-to-true-primes-and-mobius-at-target-scale.md) 的互素层支付，以及 [scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 的非别名核行和。本稿把互素层的目标量级替换扩展到**任意有界 gcd 筛选**，从而覆盖大 gcd 删项后实际留下的整层。以下是完整解析推导，尚待异源复核；它是算术门的真缩域，不估计留下的三通道 signed covariance，也不证明 RH。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实值 $\psi\in C_c^3((1,2))$，置 $\phi(t)=\psi(t)/t$。取 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的非负偶权 $v=\chi_s^2$，$s>1$，并令
\[
J_H(r)=\sum_{h\in\mathbb Z}v(h/H)e(-hr/M).
\]
在 $M<m<2M$ 定义
\[
\begin{aligned}
c(m)&=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
-4(\Lambda(m)-1+(\log2)\mu(m)),\\
t(m)&=2\mathbf1_{m=2p,\ p\ {\mathrm{prime}}}\log p
-4\mathbf1_{m=p,\ p\ {\mathrm{prime}}}\log p
-4(\log2)\mu(m),\\
a_d(m)&=\frac{d(m)}M\phi(m/M),\qquad d\in\{c,t\},
\end{aligned}\tag{1}
\]
窗外全置零。对任何 $F:\mathbb N\to\mathbb C$、$|F(g)|\le1$，记完整带通 Gram 为
\[
\mathcal G_F[d]=\sum_{m,n}F((m,n))a_d(m)a_d(n)J_H(m-n).
\tag{2}
\]
则有对 $F$ 一致的无条件估计
\[
\boxed{\quad
|\mathcal G_F[c]-\mathcal G_F[t]|
\ll_{s,\psi}
\frac{\log M}{H^2}
+\frac1{H\log^3M}
+\frac{H\log^3M}{M}
+\frac{\log^2M}{\sqrt M}
=o\!\left(\frac{H^4}{M}\right).
\quad}\tag{3}
\]
这里 $F$ 可以随 $M,H$ 任意变化。

固定任意 $\delta>0$，置
$K_0=\lfloor H^3/\log^2M\rfloor$、
$K_1=Y^{1+\delta}/H$。将 (2) 限于
$K_0<|m-n|\le K_1$ 所得的中距离形式记为
$\mathcal R_F[d]$。则同样一致于所有 $|F|\le1$，
\[
\boxed{\qquad
\mathcal R_F[c]-\mathcal R_F[t]
=o\!\left(\frac{H^4}{M}\right).
\qquad}\tag{4}
\]
特别地，令 $F_H(g)=\mathbf1_{g\le H}$。以 $\mathcal R_1[c]$ 表示 [note 849 式 (15)](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 在选择带通权 $\eta=v$ 后的无 gcd 限制真实环带（只作 $M=2Y$ 的记号替换），则对每个 $\varepsilon>0$，
\[
\boxed{\qquad
\mathcal R_1[c]
=\mathcal R_{F_H}[t]
+O_{\varepsilon,s,\psi,\delta}
\left(H^4M^{-1+\varepsilon}\right).
\qquad}\tag{5}
\]
所以真实中频带门在目标指数上可化为：**三通道 $t$，物理 $\gcd(m,n)\le H$，同一中距离环带**。式 (5) 是两个尚待估计的 signed 和之间的目标级比较，不是目标上界本身。

## 证明

按 note 849 式 (31) 作精确分解
\[
c=t+b+p_2,\qquad b(m)=4-2\mathbf1_{2\mid m},
\quad p_2(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m),
\tag{6}
\]
其中 $P_2(n)=\Lambda(n)-\mathbf1_{n\ {\mathrm{prime}}}\log n$。
$p_2$ 仅支撑在高次素数幂及其二倍上，故
$\|a_{p_2}\|_1\ll_\psi M^{-1/2}\log M$。
对 $d\in\{t,b,p_2\}$，$|d(m)|\ll\log M$。紧支撑给非零配对的
$|m-n|\le(1-\kappa_\psi)M$；scratch/868 式 (6) 在 $q=1$ 时，加上 $J_H(0)\ll H$，给每个 $m$ 的非别名绝对行和
$\sum_{n:a_d(n)\ne0}|J_H(m-n)|\ll_{s,\psi}M$。
因此对 $|F|\le1$，所有含至少一个 $p_2$ 的交叉项总量为
\[
O_{s,\psi}(M^{-1/2}\log^2M).
\tag{7}
\]

只须支付 $b$ 与任意 $|d(m)|\ll\log M$ 的交叉项
\[
\mathcal B_F(b,d)
=\sum_{m,n}F((m,n))a_b(m)a_d(n)J_H(m-n).
\tag{8}
\]
设 $\alpha=F*\mu$ 为除数卷积，则
$F((m,n))=\sum_{q\mid m,n}\alpha(q)$，且
$|\alpha(q)|\le\tau(q)$。令
$Q=\lfloor H\log^5M\rfloor$。若 $q\le Q$，写
\[
B_{q,h}=\sum_{q\mid m}a_b(m)e(-hm/M),
\qquad
D_{q,h}=\sum_{q\mid m}a_d(m)e(-hm/M).
\tag{9}
\]
对 $r=q,[2,q]$，Poisson 求和精确给
\[
P_{r,h}:=\frac1M\sum_{r\mid m}\phi(m/M)e(-hm/M)
=\frac1r\sum_{j\in\mathbb Z}\widehat\phi(h+jM/r).
\tag{10}
\]
在 $v(h/H)\ne0$ 时 $H/2\le|h|\le4H$。由于
$r\le2Q$ 且 $rH/M\ll H^2\log^5M/M=o(1)$，
$\widehat\phi(\xi)\ll_\psi(1+|\xi|)^{-3}$ 使 (10) 的
$j=0$ 项及全部非零别名分别至多为
$O_\psi(H^{-3}/r)$ 与
$O_\psi(r^2/M^3)=o(H^{-3}/r)$。
由 $b\mathbf1_{q\mid m}=4\mathbf1_{q\mid m}-2\mathbf1_{[2,q]\mid m}$，遂有
\[
|B_{q,h}|\ll_\psi H^{-3}/q,
\qquad |D_{q,h}|\ll_\psi \log M/q.
\tag{11}
\]
后一个界只用 $q\le Q=o(M)$ 时窗内有 $O(M/q)$ 个 $q$ 的倍数。带通有 $O(H)$ 个整数频率，且
$\sum_{q\ge1}\tau(q)/q^2=\zeta(2)^2<\infty$，所以小模数贡献为
\[
\left|\sum_{q\le Q}\alpha(q)
\sum_hv(h/H)B_{q,h}\overline{D_{q,h}}\right|
\ll_{s,\psi}\frac{\log M}{H^2}.
\tag{12}
\]
这里 $d$ 为实值时 (8) 恰按该 Fourier 式展开；复值 $F$ 只在
$\alpha(q)$ 中出现，不影响估计。

对 $q>Q$ 将 (8) 的对应项展开并取绝对值。
若 $m\ne n$，则 $q\mid(m-n)$，且由紧支撑
$|m-n|\le(1-\kappa_\psi)M$。固定 $q$ 时，$m$ 有
$O(M/q)$ 个候选；scratch/868 式 (6) 给
$\sum_{k\ne0}|J_H(qk)|\ll_{s,\psi}M/q$。
又 $|a_b(m)a_d(n)|\ll_\psi\log M/M^2$。用
$\sum_{q>Q}\tau(q)/q^2\ll(\log Q)/Q$，得非对角尾
\[
\ll_{s,\psi}\log M\sum_{q>Q}\frac{\tau(q)}{q^2}
\ll\frac{\log M\log Q}{Q}
\ll\frac1{H\log^3M}.
\tag{13}
\]
对角尾按
$\sum_{q\mid m}|\alpha(q)|\le\sum_{q\mid m}\tau(q)=d_3(m)$
及 $\sum_{m\le2M}d_3(m)\ll M\log^2M$ 支付为
\[
O_{s,\psi}(H\log^3M/M).
\tag{14}
\]
把 (7)、(12)--(14) 用于 $d=t,b$，展开
$\mathcal G_F[c]-\mathcal G_F[t]$ 即得 (3) 的显式界。
最后 $H^5\gg M$、$H\gg M^{1/5}$；将 (3) 的四项各除以
$H^4/M$，依次至多为
$O(M\log M/H^6)$、$O(M/(H^5\log^3M))$、
$O(\log^3M/H^3)$、$O(M^{1/2}\log^2M/H^4)$，全部一致趋零。

为证明 (4)，note 849 式 (16) 对 $c$ 给
$\sum|a_c|^2\ll\log M/M$，同一素数质量界对 $t$ 也给
$\sum|a_t|^2\ll\log M/M$。对每个 $|k|\le K_0$ 用 Cauchy--Schwarz，并以 $|J_H(k)|\ll H$ 求和，二者的近差绝对成本均为
\[
O_\psi\!\left(\frac{H(K_0+1)\log M}{M}\right)
=O_\psi\!\left(\frac{H^4}{M\log M}
+\frac{H\log M}{M}\right)
=o(H^4/M).
\tag{15}
\]
乘上任何 $|F|\le1$ 不改变此界。对
$|k|>K_1=Y^{1+\delta}/H$，note 849 式 (17)--(18) 的
Poisson 快速衰减、紧支撑非别名条件及
$\|a_c\|_1+\|a_t\|_1\ll1$，给任意固定 $B>0$ 的
$O_B(M^{-B})$ 绝对成本；若 $K_1$ 超过支持直径，这一段为空。完整 Gram 减去近、远两段，(3) 与 (15) 即得 (4)。

最后，对 $t$ 的非对角大 gcd 项重复
scratch/868 式 (2a) 的逐公共除数绝对计数，因为
$|t(m)|\ll\log M$ 且支持相同，得
\[
\sum_{\substack{m\ne n\\(m,n)>H}}
|a_t(m)a_t(n)J_H(m-n)|
\ll_{s,\psi}\log^2M/H.
\tag{16}
\]
由 $H^5\gg M$，(16) 为
$O_\varepsilon(H^4M^{-1+\varepsilon})$。
先在 (4) 取 $F\equiv1$，把 $\mathcal R_1[c]$ 换成
$\mathcal R_1[t]$；再以 (16) 从后者删去大 gcd，得到 (5)。$\square$

## 三通道的物理 gcd 支撑

若进一步固定 $0<\delta<1/5$，则 $K_1=o(M)$。在 (4) 的非对角中距离配对里，任一素数 $m=p>M$ 与不同的 $n\in(M,2M)$ 必有 $(m,n)=1$：若 $p\mid n$，则 $n\ge2p>2M$。任一倍素数 $m=2p$ 满足 $p\in(M/2,M)$；若 $(m,n)\ge3$，则 $p\mid n$，而窗内唯一不同的可能是 $n=3p$，其距离 $p>M/2>K_1$。因此对任何 $|F|\le1$，有**精确**恒等式
\[
\boxed{\quad
\mathcal R_{F\mathbf1_{g\ge3}}[t]
=16(\log2)^2
\sum_{\substack{M<m,n<2M\\K_0<|m-n|\le K_1\\(m,n)\ge3}}
F((m,n))\mu(m)\mu(n)
\frac{\phi(m/M)\phi(n/M)}{M^2}J_H(m-n).
\quad}\tag{17}
\]
这只定位剩余符号：$g\ge3$ 层是纯 Möbius 二点式，素数通道只进入 $g=1,2$。完整 signed 和仍可能在不同 gcd 层之间补偿，不能把 (17) 单独当作必须支付的上界。

## 边界

目标量级上已无需把周期背景、高次素数幂或大物理 gcd 带入剩余二点估计。真正未付的是同一窗口内
$-4(\log p)\mathbf1_{m=p}$、
$2(\log p)\mathbf1_{m=2p}$ 与
$-4(\log2)\mu(m)$ 的联合 signed 协方差，限于
$\gcd(m,n)\le H$ 及 note 849 的中距离。独立估计任何一个子通道不是式 (5) 的必要条件；剩余和的固定幂上界尚未证明。

替换必须保留**完整带通距离**，或保留 (4) 的整个中距离区间；不能只取 $|m-n|\le L$。例如无 gcd 筛选时，[scratch/901](901-local-middle-distance-four-channel-covariance-has-rank-one-main-term.md) 的四通道密度给 $c$ 的该近环带主项为 $0$，而 $t$ 的三个密度之和为 $-4+1+0=-3$，同一近环带主项为 $9\mathcal J_{\psi,v}$。这项差额由更远的带通旁瓣支付，不是 (3)--(5) 的误差。
