# 定量短和与精确双尺度公式不能单独支付完整观察频带

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)–(13)、[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4)–(7)，以及 [scratch/851](851-logarithmic-short-interval-savings-do-not-pay-the-observation-band.md) 的素数支撑调制思想。[scratch/903](903-prime-supported-modulation-defeats-first-moment-control-of-the-post-h3-ring.md) 已对一个截断物理环带作基线极化；这里直接处理**完整非负观察频带**，并保留 note 851 所用的定量 Ramachandra 短和误差。此命题只判定一阶资料的逻辑强度；它不估计真实系数，也不反驳 RH。本稿待异源复核。

## 命题

固定非负、非零的实函数 $\psi\in C_c^3((1,2))$，以及非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，满足 $\eta\ge1$ 于 $1\le |t|\le2$。任取固定 $0<\kappa<1/10$。令 $M=2Y\to\infty$，$H=\lceil Y^{1/5}\rceil$，$h_0=\lceil3H/2\rceil$，$V_M=(\log M/\log\log M)^{1/3}$，$\delta_M=M^{-\kappa}$。在 $M<p<2M$ 的素数上置
\[
 d_\theta(p)=(\log p)\cos(2\pi h_0p/M+\theta),
 \qquad d_\theta(n)=0\quad\text{在其余整数上}.
\tag{1}
\]
存在相位 $\theta_M$，使得对 $\sigma\in\{+1,-1\}$ 定义的非负、素数幂支撑权
\[
 \Lambda_M^\sigma(n)=\Lambda(n)+\sigma\delta_Md_{\theta_M}(n),
 \qquad \mu_M^\sigma(n)=\mu(n),
\tag{2}
\]
具有以下性质：

1. 在 $x\asymp M$ 且 $1\le u\le x$ 的每个区间 $(x,x+u]$ 上，$\Lambda_M^\sigma-1$ 与 $\mu_M^\sigma$ 均满足 note 851 式 (4)–(5) 同型的统一估计
   \[
   \left|\sum_{x<n\le x+u}(\Lambda_M^\sigma(n)-1)\right|
   +\left|\sum_{x<n\le x+u}\mu_M^\sigma(n)\right|
   \ll u e^{-cV_M}+M^{5/8}
   \tag{3}
   \]
   对某个固定 $c>0$ 成立。$\Lambda_M^\sigma$ 与 $\Lambda$ 在 $M<p<2M$ 之外逐点相同；在这些素数上，$\Lambda_M^\sigma(p)=(1+\sigma\delta_M\cos(2\pi h_0p/M+\theta_M))\log p>0$。真实 $\mu$ 与其全部二进关系没有改变。
2. 按 note 849 式 (10) 的**同一精确双尺度公式**，用 $\Lambda_M^\sigma,\mu_M^\sigma$ 定义 $c_M^\sigma(m)$，再令
   \[
   \mathcal A_h^\sigma
   =\sum_{M<m<2M}\frac{c_M^\sigma(m)}m\psi(m/M)e(-hm/M),
   \qquad E_\sigma=\sum_h\eta(h/H)|\mathcal A_h^\sigma|^2.
   \tag{4}
   \]
   则至少有一个 $\sigma\in\{+1,-1\}$ 满足
   \[
   \boxed{\quad E_\sigma\ge c_\psi\delta_M^2
   \gg H^4/M.\quad}
   \tag{5}
   \]
   这里 $c_\psi>0$ 与 $M$ 无关。扰动仅改变观察窗中的高奇素数行；该行 $c_M^\sigma(p)<0$ 对充分大的 $M$ 仍成立，倍素数 $2p$ 通道、$\mu$ 通道及其他行逐点不变。

因此，纵然保留 note 849 的精确双尺度线性组合、全部现用的一阶定量短和、素数幂支撑与高素数系数符号，这些资料仍不蕴含完整频带的 $O(H^4/M)$ 上界。反模型改变了素数处的精确权 $\Lambda(p)=\log p$，因而不保留 $\Lambda=\mu*\log$；真实算术门仍开放。

## 证明

note 851 的 Ramachandra 输入对真实 $\Lambda-1$ 与 $\mu$ 给式 (3) 的右侧，取某个原常数 $c_0>0$。任意长度 $u\ge1$ 的区间与扰动相交时，最多含 $u+1\le2u$ 个整数，所以
\[
 \left|\sum_{x<n\le x+u}\delta_Md_\theta(n)\right|
 \le2u\delta_M\log(2M).
\tag{6}
\]
因 $\delta_M\log(2M)=o(e^{-c_0V_M})$，缩小 $c_0$ 即得 (3)，对 $\sigma,\theta,x,u$ 一致。式 (2) 的支撑、非负性与 $\mu$ 结论均逐点显然。

在 $M<m<2M$，双尺度公式的偶数项只读取 $\Lambda_M^\sigma(m/2)$，而 $m/2<M$，所以该项完全不变。于是
\[
 c_M^\sigma(m)=c(m)-4\sigma\delta_Md_\theta(m).
\tag{7}
\]
设
\[
 D_h(\theta)=\sum_{M<p<2M}\frac{\log p}{p}\psi(p/M)
 \cos(2\pi h_0p/M+\theta)e(-hp/M),
\quad
 P_j=\sum_{M<p<2M}\frac{\log p}{p}\psi(p/M)e(-jp/M).
\]
素数定理及分部求和给
\[
 P_0\longrightarrow C_\psi:=\int_1^2\frac{\psi(t)}t\,dt>0.
\tag{8}
\]
在 $h=h_0$，余弦展开精确给
\[
 D_{h_0}(\theta)=\tfrac12(e^{i\theta}P_0+e^{-i\theta}P_{2h_0}),
\qquad
 \frac1{2\pi}\int_0^{2\pi}|D_{h_0}(\theta)|^2d\theta
 =\tfrac14(|P_0|^2+|P_{2h_0}|^2).
\tag{9}
\]
因此可选 $\theta_M$ 使 $|D_{h_0}(\theta_M)|^2\ge C_\psi^2/16$，且 $\eta(h_0/H)\ge1$，故 $E_D:=\sum_h\eta(h/H)|D_h(\theta_M)|^2\ge C_\psi^2/16$。

由 (7)，$\mathcal A_h^\sigma=\mathcal A_h-4\sigma\delta_MD_h$。频带权非负，平行四边形恒等式给
\[
 E_++E_-=2E_0+32\delta_M^2E_D\ge32\delta_M^2E_D.
\tag{10}
\]
故至少一侧 $E_\sigma\ge16\delta_M^2E_D\ge C_\psi^2\delta_M^2$。由于 $H\asymp M^{1/5}$，$H^4/M\asymp M^{-1/5}$，而 $M^{-2\kappa}/M^{-1/5}=M^{1/5-2\kappa}\to\infty$，得 (5)。最后，$c(p)=-4\log p+O(1)$，扰动相对大小为 $O(\delta_M)$，所以高素数行的负号保持。$\square$

## 边界

式 (5) 是对两组**非真实**素数权的二择一下界；不能推出真实 $E_0$ 的下界。扰动的相对幅度可取任意固定 $M^{-\kappa}$、$\kappa<1/10$，仍不足以被现有短和界识别。它排除了只从当前定量一阶短和与双尺度线性公式推出固定幂界的证明，留下必须使用的精确信息：$\Lambda(p)=\log p$、$\Lambda=\mu*\log$ 及其在目标二点和中的实际符号排列。

这个反模型并未进入 [scratch/924](924-mobius-inversion-moves-the-full-observation-to-cofactors-at-least-three.md) 的真实高源门。该稿式 (3) 将真实 $c-b$ 写成固定光滑 cofactor 核 $\kappa$ 与 $\mu$ 的卷积；在物理素数 $p\in(M,2M)$ 上，$c(p)-b(p)=\kappa(p)$ 是 $d=1$ 的低源项。对**整个**物理窗口求 Fourier 和时，此低源连同其合数位置由 Poisson 求和支付：该稿式 (7) 的逐源证明给 $|\mathcal L_h(1)|\ll_\psi(\log M)H^{-3}$，故其完整带通能量至多 $O_\psi(H^{-5}\log^2M)=o(H^4/M)$。式 (1) 只改素数位置，破坏了同一个光滑 $\kappa$ 的低源关系。因此不能把式 (5) 当作真实高源 signed covariance 的下界或证明障碍。
