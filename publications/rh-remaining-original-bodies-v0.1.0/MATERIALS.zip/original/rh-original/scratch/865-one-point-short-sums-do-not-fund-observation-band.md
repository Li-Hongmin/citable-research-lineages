# 一点短和与对角质量不足以支付观察频带（探索反例）

日期：2026-10-02。对象是 note 849 式 (11)--(16) 的抽象系数界与 note 851 式 (7) 的短和输入。此处构造的 \(c_Y\) 不是实际算术系数，不对真实 Möbius covariance 作反例。

## 精确断言

固定非负、非零 \(\psi\in C_c^\infty((1,2))\)。令
\[
 M=2Y,\qquad H=\lceil Y^{1/5}\rceil,\qquad
 h_0=H,\qquad V_Y=(\log Y/\log\log Y)^{1/3},
 \qquad \varepsilon_Y=e^{-cV_Y}
\]
其中 \(c>0\) 固定。对 \(M<m<2M\) 取实序列
\[
 c_Y(m)=\varepsilon_Y\cos(2\pi h_0m/M),
 \qquad
 a_m=\frac{c_Y(m)}m\psi(m/M),
\]
其余 \(m\) 置零。则 \(|c_Y(m)|\le1\)，对**每个**整数区间 \(J\subset(M,2M)\)，
\[
 \left|\sum_{m\in J}c_Y(m)\right|
 \le\varepsilon_Y |J|,
 \qquad
 \sum_m|a_m|^2\ll_\psi \varepsilon_Y^2/Y
 \ll_\psi \log Y/Y.
\tag{1}
\]
因此它满足比 note 851 式 (7) 更强的每个 \(Q=\lfloor Y^{2/3}\rfloor\)
短块界，也满足 note 849 式 (16) 的对角界。然而
\[
 \left|\sum_m a_m e(-h_0m/M)\right|^2
 \gg_\psi \varepsilon_Y^2
 \gg_A Y^{-A}\quad\text{对每个固定 }A>0,
\tag{2}
\]
特别超过 \(H^4/Y\asymp Y^{-1/5}\)。
任意非负频带权 \(\eta\) 若 \(\eta(1)\ge1\)，其带权能量也至少为式 (2)。

## 证明

式 (1) 第一界逐项取绝对值得到；第二界由
\(m\asymp Y\)、非零项 \(O(Y)\) 个直接得到。令
\(w(m)=\psi(m/M)/m\)。因 \(\psi\) 光滑紧支撑，
Riemann 求和与任意次分部积分分别给
\[
 \sum_m w(m)=I_\psi+O_\psi(M^{-1}),
 \qquad I_\psi=\int_1^2\frac{\psi(u)}u\,du>0,
\]
\[
 \sum_m w(m)e(-2h_0m/M)
 =O_{\psi,A}(h_0^{-A})\qquad(A>0).
\]
写余弦为两个指数后，
\[
 \sum_m a_m e(-h_0m/M)
 =\frac{\varepsilon_Y}{2}
 \left(\sum_mw(m)+\sum_mw(m)e(-2h_0m/M)\right)
 =\frac{\varepsilon_Y I_\psi}{2}+o_\psi(\varepsilon_Y),
\]
证明 (2)。最后 \(V_Y=o(\log Y)\)，故
\(\varepsilon_Y^2/Y^{-1/5}\to\infty\)。

## 决策边界

单独使用 note 851 的一点短和强度、\(|c(m)|\ll\log Y\)
及 note 849 的对角质量，无法推出式 (15) 的固定幂频带界。
必须使用真实 \(\Lambda,\mu\) 系数在不同位置或乘子间的联合约束。
