# 倍素数物理行在真实高除数 Gram 中精确消失

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (2)、(8)--(12) 的真实源系数、原门及绝对过滤预算，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的 \(K=O((M/H)(\log M)^s)=o(M)\) 截止。这里给整个物理类 \(m=2p\) 建立源指标的显式反号配对；它在**已过滤的真实剩余门中也精确保留**。同一机制还删除一族偶数粗糙平方自由物理行，过滤误差仍在目标内。式 (2g)--(2h) 进一步分类任意 \(q\le H\) 的一大素因子物理行，发现 \(4\mid q\) 且奇部大于 \(1\) 的整族非平方自由零行。这给 [scratch/875](875-squarefree-aligned-gram-collapses-to-one-cofactor-with-explicit-prime-log-weight.md) 的对齐和未对齐项一个逐物理点的真实联合抵消。结论只删去这些物理类，尚无异源复核，不证明完整 moving covariance、全尺度局部 Weil 正性或 RH。

## 定理

令 \(M=2Y\)，\(Y^{1/5}\le H\le Y^{1/4}\)，\(D=\lfloor M/(16H)\rfloor\)，固定实 \(\psi\in C_c^3((1,2))\)、\(s>1\)。沿用 scratch/859 的 \(b_d(m),R,K_0\) 和 scratch/860 的 \(w_H,J_H,K=K_{s,2}\)。对 \(M<m<2M\) 定义完整高除数物理系数
\[
a_D(m):=\sum_{\substack{d\mid m\\d>D}}\mu(d)b_d(m).
\tag{1}
\]
对每个充分大的 \(M\) 和每个奇素数 \(p\) 满足 \(M<2p<2M\)，都有精确恒等式
\[
\boxed{\quad a_D(2p)=0.\quad}\tag{2}
\]
更一般地，若 \(q\le H\) 平方自由、\(p\) 为素数且 \(M<pq<2M\)，则以 scratch/875 的 \(A(q)=\sum_{k\mid q}\mu(k)\alpha(k)\) 记
\[
\boxed{\quad
a_D(pq)=\frac{\phi(pq/M)}M\,\mu(q)A(q).
\quad}\tag{2a}
\]
在这一平方自由一大素因子家族中，\(A(q)=0\) 当且仅当 \(q=2\)；式 (2) 是该子族唯一由算术因子造成的零行。
若去掉 \(q\) 平方自由的限制，精确系数为
\[
\boxed{\quad
a_D(pq)=\frac{\phi(pq/M)}M\,\beta(q),
\qquad \beta=\mu*\alpha.
\quad}\tag{2g}
\]
写 \(q=2^a u\)、\(u\) 为奇数、\(\ell=\log2\)，则完整分类为
\[
\boxed{\quad
\beta(2^a u)=
\begin{cases}
4\Lambda(u)+4\ell\mu(u),&a=0,\\
0,&a=1,\ u=1,\\
-2\Lambda(u)-4\ell\mu(u),&a=1,\ u>1,\\
2\ell,&a\ge2,\ u=1,\\
0,&a\ge2,\ u>1.
\end{cases}
\quad}\tag{2h}
\]
其中 \(\Lambda(1)=0\)。故除了 \(q=2\)，算术零行恰是 \(a\ge2,u>1\)，或 \(a\in\{0,1\},u>1\) 且 \(\mu(u)=\Lambda(u)=0\)。特别地，非平方自由 \(q\) 的非零系数只可能出现在纯 \(2\) 幂、奇素数幂 \(r^k\) 或其两倍 \(2r^k\)（\(k\ge2\)）；其余全部精确消失。\(m=4pr\) 对所有满足 \(4r\le H\) 的不同奇素数 \(p,r\) 且 \(M<4pr<2M\) 都是完整高除数 Gram 的精确零行；这族不属于上面的平方自由结论。
另外，若 \(m=p^k\) 或 \(m=2p^k\)、\(k\ge2\) 且 \(M<m<2M\)，则所有 \(\mu(d)\ne0\) 的除数 \(d\mid m\) 均不超过 \(2p\ll\sqrt M<D\)；这些物理行没有高除数源，本来就为零。
还有更大的一族精确零行。令 \(P^-(u)\) 为 \(u>1\) 的最小素因子，并置
\[
\mathcal Z_{M,H}:=
\left\{m=2u\in(M,2M):u>1\text{ 为奇平方自由数},\ 
\frac{2u}{P^-(u)}\le D\right\}.
\tag{2b}
\]
则 \(a_D(m)=0\) 对每个 \(m\in\mathcal Z_{M,H}\) 精确成立；\(2p\) 是其中的素数子族。若在同一个已过滤剩余门中只取 \(m\in\mathcal Z_{M,H}\) 或 \(n\in\mathcal Z_{M,H}\) 的项，记为 \(\mathfrak S_{\mathcal Z}\)，则
\[
\boxed{\quad
|\mathfrak S_{\mathcal Z}|
\ll_{s,\psi}\frac{H^4}{M\log^2(2M)}.
\quad}\tag{2c}
\]
若进一步令
\[
\mathcal Z^{\rm gap}_{M,H}:=
\left\{2u\in\mathcal Z_{M,H}:
\text{每个 }t\mid u\text{ 都满足 }t\le R/4\text{ 或 }t>R\right\},
\tag{2d}
\]
在同一个已过滤剩余门中只取 \(m\in\mathcal Z^{\rm gap}_{M,H}\) 或 \(n\in\mathcal Z^{\rm gap}_{M,H}\) 的项，记为 \(\mathfrak S_{\mathcal Z^{\rm gap}}\)。则与下文的 \(2p\) 类相同，这族**精确为零**：
\[
\boxed{\quad \mathfrak S_{\mathcal Z^{\rm gap}}=0.\quad}\tag{2e}
\]
这族确实超出 \(2p\)：一致于该 \(H\) 范围，至少有 \(\gg M/\log^2M\) 个 \(2pr\in\mathcal Z^{\rm gap}_{M,H}\)，其中 \(p,r\) 为不同奇素数。
这条粗糙条件在 \(2pr\) 族内恰好刻画全部算术零行。具体地，若 \(p<r\) 为不同奇素数、\(M<2pr<2M\)，则
\[
\boxed{\quad
a_D(2pr)=\frac{\phi(2pr/M)}M
\begin{cases}
0,&2r\le D,\\
-4\log p,&r\le D<2r,\\
4\log2-2\log p,&D<r.
\end{cases}
\quad}\tag{2f}
\]
后两段的算术因子都不为零；因此只要 \(\phi(2pr/M)\ne0\)，就有 \(a_D(2pr)=0\) 当且仅当 \(2r\le D\)。
令 \(\mathcal E_M=\{2p:M<2p<2M,\ p\text{ 奇素数}\}\)。在 scratch/859 式 (12) 的真实有序高除数剩余门中，以 scratch/860 的 \(K\) 作为远差截止，仅保留 \(m\in\mathcal E_M\) **或** \(n\in\mathcal E_M\) 的所有项，记所得 signed 和为 \(\mathfrak S_{2p}\)。则一致于所给 \(H\)，
\[
\boxed{\quad \mathfrak S_{2p}=0\quad}
\tag{3}
\]
因此完整剩余门可**精确删除**整个 \(2p\) 物理行列。式 (3) 是保留源指标后由反号配对得到的合计恒等式，并不说这些源项的绝对质量为零。

## 证明

由 scratch/873 式 (1)、(6)，只要 \(d\mid m\)，就有
\(b_d(m)=-M^{-1}\alpha(m/d)\phi(m/M)\)，其中 \(\alpha(1)=\alpha(2)=4\ell\)、\(\ell=\log2\)。若 \(m=2p\in(M,2M)\)，则 \(p>M/2>D\)，而 \(1,2\le D\) 对充分大的 \(M\) 成立。故 (1) 只有 \(d=p,2p\) 两项，并且
\[
\begin{aligned}
a_D(2p)
&=-\frac{\phi(2p/M)}M
\bigl[\mu(p)\alpha(2)+\mu(2p)\alpha(1)\bigr]\\
&=-\frac{\phi(2p/M)}M(-4\ell+4\ell)=0.
\end{aligned}\tag{4}
\]
这证明 (2)，不使用素数分布或 Möbius 均值估计。

对于 (2a)，由 \(q\le H\ll D\) 与 \(p>M/q\ge M/H>D\)，\(pq\) 的高除数恰为 \(d=pt\)、\(t\mid q\)；\(p>q\) 也保证 \(p\nmid q\)。因此
\[
\begin{aligned}
a_D(pq)
&=-\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(pt)\alpha(q/t)\\
&=\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(t)\alpha(q/t)
=\frac{\phi(pq/M)}M\mu(q)
\sum_{k\mid q}\mu(k)\alpha(k),
\end{aligned}\tag{4a}
\]
证明 (2a)。scratch/875 式 (15)--(16) 的计算给：\(A(1)=4\ell\)、\(A(2)=0\)；奇平方自由 \(q>1\) 时 \(A(q)=4\ell-4\Lambda(q)\)；\(q=2z\)、奇平方自由 \(z>1\) 时 \(A(q)=4\ell-2\Lambda(z)\)。奇素数 \(r\ge3\) 不满足 \(\log r=\ell\)，也不满足 \(\log r=2\ell\)（后者要求 \(r=4\)）；其余情形 \(\Lambda=0\)。故 \(A(q)=0\) 唯有 \(q=2\)。

对 (2b)，任何真因子 \(t\mid u\)、\(t<u\)，都满足 \(t\le u/P^-(u)\)，故 \(t,2t\le D\)。而 \(u,2u>D\)，因为 \(u>M/2\)。于是 \(m=2u\) 的高除数中只有 \(d=u,2u\) 可能带非零 Möbius 系数。由 \(u\) 奇且平方自由，\(\mu(2u)=-\mu(u)\)；它们的 cofactor 分别为 \(2,1\)，而 \(\alpha(2)=\alpha(1)\)，所以 \(a_D(2u)=0\)。

对 (2f)，由 \(p<r\) 与 \(pr<M\) 知 \(p<\sqrt M\)，而 \(D\gg M^{3/4}\)。故含 \(p\) 但不含 \(r\) 的除数 \(p,2p\) 均低于 \(D\)；由 \(pr>M/2>D\) 知 \(pr,2pr\) 均为高除数，且它们的 \(1,2\) cofactor 项由 \(\mu(pr)\alpha(2)+\mu(2pr)\alpha(1)=0\) 相消。其余只可能是 \(2r\)（当 \(2r>D\)）和 \(r\)（当 \(r>D\)）。由于 \(\mu(2r)=1\)、\(\mu(r)=-1\)、\(\alpha(p)=4\log p\)、\(\alpha(2p)=4\log2+2\log p\)，直接代入 (1) 得到 (2f)。中间一段非零；末段若为零则 \(p=4\)，与 \(p\) 为奇素数矛盾。

把未过滤的完整高除数 Gram 先按物理点合并，可写为
\[
\mathcal Q_D=\sum_{M<m,n<2M}a_D(m)a_D(n)J_H(m-n).
\tag{5}
\]
式 (2b) 使 \(\mathcal Z_{M,H}\) 的每一完整 Gram 行列为零。过滤后只取这些行列的 signed 和，必等于同一行列被删源项之负值。scratch/859 式 (8)、(8a)、(8b)、(10) 和 scratch/860 式 (3) 对**所有**被删源项的绝对预算合计为
\[
O_{s,\psi}\!\left(\frac{H^2\log^3(2M)}M
+\frac{H^4}{M\log^2(2M)}+M^{-2}\right)
=O_{s,\psi}\!\left(\frac{H^4}{M\log^2(2M)}\right),
\tag{5a}
\]
最后一步使用 \(H\gg M^{1/5}\)。限制到 \(\mathcal Z_{M,H}\) 只会减小绝对预算，证明 (2c)。

现证明 (2e)。固定 \(m=2u\in\mathcal Z^{\rm gap}_{M,H}\) 及剩余门中的物理配对 \(n\)，所以 \(K_0<|m-n|\le K\)。由于 \(u>M/2\) 而 \(K=o(M)\)，充分大 \(M\) 时 \(K<u\)。若 \(u\mid n\)，不同的两个 \(u\) 的倍数 \(m,n\) 相距至少 \(u\)，矛盾。因此 \(u\nmid n\)。由 (2b)，\(m\) 侧仅有 \(d=u,2u\) 两个非零高除数源。固定任意 \(e>D\)、\(e\mid n\)。两种 \(d\) 都不整除 \(e\)，因为它们都含因子 \(u\)；\(e\) 也不整除任一种 \(d\)，因为 \(2u\) 的大于 \(D\) 的除数只有 \(u,2u\)，而它们都不整除 \(n\)。原门的两项整除过滤于是相同。

令 \(g=(u,e)\)、\(t=u/g\)、\(v=e/g\)。由于 \(u\) 为奇数，约化比例随 \(e\) 的奇偶精确为
\[
\begin{array}{c|cc}
&d=u&d=2u\\ \hline
e\text{ 奇}&(t,v)&(2t,v)\\
e\text{ 偶}&(t,v)&(t,v/2)
\end{array}
\tag{5b}
\]
其中每对是 \((d/(d,e),e/(d,e))\)。又 \(e\le n<2M\)、\(u>M/2\)，故 \(v=(e/u)t<4t\)。因为 \(t\mid u\)，式 (2d) 保证 \(t\le R/4\) 或 \(t>R\)。在前一种情形，\(v<4t\le R\)、\(2t\le R\)，(5b) 两列的最大约化比例均不超过 \(R\)；在后一种情形，两列均有约化分子至少 \(t>R\)。因此比例过滤也总是同时保留或同时删除 \(d=u,2u\)。距离过滤只取决于同一 \((m,n)\)，而 (4) 的两个源系数相反。对每个固定 \((n,e)\) 求和即为零，故整个 \(m\) 行精确为零；交换两侧亦然。取满足 \(m\in\mathcal Z^{\rm gap}_{M,H}\) 或 \(n\in\mathcal Z^{\rm gap}_{M,H}\) 的有序项之并集，不会改变这个结论，证明 (2e)。

为核对这不是只有素数的类，取素数 \(p\in[M^{1/3},(9/8)M^{1/3}]\)、\(r\in[(3/5)M^{2/3},(2/3)M^{2/3}]\)。则 \(1.2M\le2pr\le1.5M\)，且 \(p<r\)、\(2pr/P^-(pr)=2r\ll M^{2/3}<D\) 对充分大 \(M\) 在整个 \(H\) 范围成立。由 \(Y=M/2\) 和 \(R=\lfloor H^2/\log^4(2M)\rfloor\)，一致有
\[
M^{2/5}/(C\log^4M)\le R\le CM^{1/2}/\log^4M
\tag{5c}
\]
其中 \(C>0\) 为绝对常数。因此充分大 \(M\) 时 \(1,p\le R/4<R<r,pr\)，恰覆盖 \(u=pr\) 的全部因子 \(1,p,r,pr\)，故 \(2pr\in\mathcal Z^{\rm gap}_{M,H}\)。素数定理在两个固定比例区间分别给 \(\gg M^{1/3}/\log M\) 与 \(\gg M^{2/3}/\log M\) 个素数；因 \(p<r\)，各乘积不同，于是这些额外零行至少有 \(\gg M/\log^2M\) 个。

式 (2) 表明 (5) 中满足 \(m\in\mathcal E_M\) 或 \(n\in\mathcal E_M\) 的每一物理配对在源指标求完后都为零。更强的是源指标的反号配对**不被原门过滤破坏**。固定 \(m=2p\in\mathcal E_M\) 与任一候选 \(n\) 满足 \(K_0<|m-n|\le K\)。因 \(K=o(M)\)、\(p>M/2\)，充分大 \(M\) 时 \(K<p\)。若 \(p\mid n\)，则 \(n\ne m\) 使 \(|m-n|\ge p>K\)，矛盾；所以 \(p\nmid n\)。对每个固定 \(e>D\)、\(e\mid n\)，于是 \(p\nmid e\)，且 \(e>D>2\)。两种 \(m\) 侧源 \(d=p,2p\) 均满足
\[
d\nmid e,\qquad e\nmid d,
\qquad
\frac d{(d,e)}\ge p>R.
\tag{6}
\]
这里 \((p,e)=1\)、\((2p,e)=(2,e)\le2\)，而 \(R\ll H^2=o(M)<p\) 对充分大 \(M\) 成立。故两项的最大约化比例都大于 \(R\)；物理距离过滤只看同一 \((m,n)\)，也完全相同。两项在剩余门中同时出现，且由 (4) 的系数正负相消。这个配对对每个固定 \((n,e)\) 成立，因此所有 \(m\in\mathcal E_M\) 的行精确为零。对 \(n\in\mathcal E_M\) 的列交换两侧同理；行列交集即使重复计入，仍为零。这证明 (3)。\(\square\)

## 对齐源如何被未对齐源支付

取 \(m=2p\in\mathcal E_M\)，再取平方自由 \(n\in(M,2M)\) 且 \((m,n)=1\)。在**未过滤**的高除数物理配对 \((m,n)\) 中，scratch/875 的有理对齐条件 \([m/d,n/e]\mid(m,n)=1\) 强迫 \(d=m,e=n\)。因此该对齐源的系数为
\[
\mu(m)\mu(n)b_m(m)b_n(n)
=\frac{16\ell^2}{M^2}\mu(n)
\phi(m/M)\phi(n/M).
\tag{7}
\]
式 (2) 使同一物理配对的**全部**高除数源合计为零，所以所有未对齐源的合计逐点恰为 (7) 的负值。最直接的一对是把 \(m\) 侧源从 \(d=2p\) 换成 \(d=p\)：两项的 \(\alpha(1),\alpha(2)\) 相同而 Möbius 符号相反；这一抵消对 \(n\) 侧的每一个固定 \(e>D\) 都成立。

若 \((m,n)=2\)，scratch/875 式 (15) 的对齐聚合系数为 \(D_*(2)=0\)，完整源合计亦由 (2) 为零。对实际中距离 \(K_0<|m-n|\le K=o(M)\) 且 \(m\ne n\)，\((m,n)\) 不可能含 \(p\)：否则 \(n\ne m\) 为另一个 \(p\) 的倍数，\(|m-n|\ge p>M/2>K\)。所以平方自由的 \(2p\) 近距离行只遇到上述 \(g=1,2\) 两类。

最后，note 849 式 (29) 的聚合三通道系数在 \(m=2p\) 处是 \(2\log p-4\ell\)，并不为零。两者并不矛盾：低除数 \(d=1,2\) 在这个物理点贡献
\[
-\alpha(2p)+\alpha(p)
=-(4\ell+2\log p)+4\log p
=2\log p-4\ell,
\tag{8}
\]
而高除数贡献由 (2) 为零。scratch/859 对低除数的支付发生在**完整 Fourier 和**中，不能逐物理点应用到任意选取的子族。式 (3) 的真实删除则由源指标反号配对直接完成。

## 任意短 cofactor 的系数分类与过滤后删除

现证明 (2g)--(2h)。若 \(q\le H\) 不要求平方自由、\(p\) 为素数、\(M<pq<2M\)，则 \(q<D\)、\(p>M/H>16D>H\) 对充分大 \(M\) 一致成立。于是 \(pq\) 的所有高除数均为 \(d=pt\)、\(t\mid q\)；因 \(p\nmid q\)，scratch/873 式 (6) 给
\[
\begin{aligned}
a_D(pq)
&=-\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(pt)\alpha(q/t)\\
&=\frac{\phi(pq/M)}M
\sum_{t\mid q}\mu(t)\alpha(q/t).
\end{aligned}\tag{9}
\]
这就是 (2g)，即使 \(\mu(q)=0\) 仍然成立。对奇数 \(v\)，scratch/873 式 (1) 的 \(\alpha\) 精确满足
\[
\alpha(v)=4\log v+4\ell\mathbf1_{v=1},
\qquad
\alpha(2^a v)=2(a+1)\ell+2\log v\quad(a\ge1).
\tag{10}
\]
另一个直接核对来自 \(\alpha(k)=4\log k-2\mathbf1_{2\mid k}\log(k/2)+4\ell\mathbf1_{k=1}\)：由 \(\mu*\log=\Lambda\) 及对偶数项换元，
\[
\boxed{\quad
\beta(q)=4\Lambda(q)-2\mathbf1_{2\mid q}\Lambda(q/2)
+4\ell\mu(q).
\quad}\tag{10a}
\]
这个全整数恒等式也等于 note 849 式 (10) 的算术系数去掉周期背景后的负值；它独立核对下面的分段分类，但不支付其带通均方。
若 \(q=u\) 为奇数，\(\mu*\log=\Lambda\) 与 (10) 立即给
\(\beta(u)=4\Lambda(u)+4\ell\mu(u)\)，包括 \(u=1\)。

若 \(q=2u\)、\(u\) 奇，则按除数 \(t=v,2v\) 成对，\(v\mid u\)，得
\[
\beta(2u)=\sum_{v\mid u}\mu(v)
\{\alpha(2u/v)-\alpha(u/v)\}.
\tag{11}
\]
花括号在 \(u/v=1\) 时为零，在 \(u/v>1\) 时为 \(4\ell-2\log(u/v)\)。若 \(u>1\)，\(\sum_{v\mid u,\,u/v>1}\mu(v)=-\mu(u)\)，并且
\(\sum_{v\mid u}\mu(v)\log(u/v)=\Lambda(u)\)；因此 (11) 等于
\(-4\ell\mu(u)-2\Lambda(u)\)。\(u=1\) 时 (11) 为零。

若 \(q=2^a u\)、\(a\ge2\)、\(u\) 奇，则 (11) 中的同一种成对求和把花括号改为
\(\alpha(2^a u/v)-\alpha(2^{a-1}u/v)=2\ell\)，与 \(v\) 无关。因此
\(\beta(2^a u)=2\ell\sum_{v\mid u}\mu(v)=2\ell\mathbf1_{u=1}\)。这完成 (2h)。在 \(a\le1,u>1\) 两段，若 \(\Lambda(u)>0\)，则 \(u\) 是奇素数幂；当它是素数时，系数分别为 \(4\log(u/2)\) 和 \(2\log(4/u)\)，都不为零，因为奇素数不等于 \(2\) 或 \(4\)；更高素数幂的 \(\mu(u)=0\)，系数也非零。若 \(\Lambda(u)=0\)，系数为非零常数乘 \(\mu(u)\)。所以 (2h) 后的零行分类没有遗漏。

令 \(\mathcal Z^{1P}_{M,H}\) 为全部满足 \(q\le H\)、\(M<pq<2M\)、\(p\) 素数及 \(\beta(q)=0\) 的物理点。\(p>H\) 使其大素因子 \(p\) 唯一；(2g) 说明 \(a_D(m)=0\) 对每个 \(m\in\mathcal Z^{1P}_{M,H}\) 精确成立。更强地，固定这样的 \(m=pq\) 与原门的 \(n\) 且 \(p\nmid n\)，再固定任意 \(e>D\)、\(e\mid n\)。对 \(m\) 侧每个非零源 \(d=pt\)、\(t\mid q\)，有
\[
d\nmid e,\qquad e\nmid d,\qquad
\frac d{(d,e)}\ge p>R.
\tag{12}
\]
第二个整除排除成立，因为 \(d\) 不含 \(p\) 的因子均不超过 \(t\le q<D<e\)。因此源指标过滤逐项全部保留，物理距离过滤对同一 \((m,n)\) 也相同；对 \(d\) 求和正好是 \(a_D(m)b_e(n)=0\)。交换两侧同理。剩下的配对必须共享 \(p\)，其物理 gcd 大于 \(H\)，已由 scratch/868 式 (3) 在 \(O_{\varepsilon}(H^4M^{-1+\varepsilon})\) 内支付。另一个不需区分 gcd 的更尖锐结论直接来自 (5)--(5a)：整个未过滤物理 Gram 在这些行列上为零，故原门仅取 \(m\in\mathcal Z^{1P}_{M,H}\) 或 \(n\in\mathcal Z^{1P}_{M,H}\) 的 signed 和满足
\[
\boxed{\quad
|\mathfrak S_{\mathcal Z^{1P}}|
\ll_{s,\psi}\frac{H^4}{M\log^2(2M)}.
\quad}\tag{13}
\]
这里 (13) 是可删除行列的上界，并不声称所有这类行在已过滤门中逐项为零。

这批非平方自由零行并非稀疏例外。固定 \(J=[a,b]\subset(1,2)\)。取奇素数 \(H/8<r\le H/4\)，于是 \(q=4r\in(H/2,H]\) 且 \(\beta(q)=0\)。素数定理一致给
\(\#\{p\text{ 素数}:4pr\in MJ\}\asymp_J M/(r\log M)\)，而素数调和和给
\(\sum_{H/8<r\le H/4}r^{-1}\asymp1/\log H\)。因 \(p>H>r\)，各物理乘积不同；故这族包含
\[
\boxed{\quad
\#\{4pr\in MJ:p,r\text{ 不同奇素数},\ H/8<r\le H/4\}
\gg_J \frac M{\log^2M}.
\quad}\tag{14}
\]

上述零行有一个精确的高除数截止边界。若 \(q\le32H\)、\(p\) 为素数且 \(M<pq<2M\)，仍有 \(q<D\) 与 \(p>D/2\)，所以含 \(p\) 的除数 \(pt\) 在 \(t\ge2\) 时全部为高除数；仅 \(t=1\) 会在 \(p\le D\) 时被删。因此不论 \(q\) 是否平方自由，
\[
\boxed{\quad
a_D(pq)=\frac{\phi(pq/M)}M
\left[\beta(q)-\mathbf1_{p\le D}\alpha(q)\right]
\qquad(q\le32H).
\quad}\tag{15}
\]
当 \(q\le16H\) 时，\(p>M/q\ge M/(16H)>D\)，(15) 退化为 (2g)。但在 \(16H<4r\le32H\)、\(r\) 为奇素数、\(p\le D\) 时，\(\beta(4r)=0\) 而
\[
\boxed{\quad
a_D(4pr)
=-\frac{6\ell+2\log r}{M}\phi(4pr/M).
\quad}\tag{16}
\]
这个负项恰是被截止删去的 \(d=p\) 源；因此 \(4\mid q\) 的零行不能跨过 \(p=D\) 延伸到整个 \(q\le32H\) 支撑。

该边界也含有固定比例的大族。若 \(J=[a,b]\subset(1,2)\) 且 \(\phi\ge c_\psi>0\) 于 \(J\)，取奇素数 \(4bH<r\le8H\) 与素数 \(p\) 使 \(4pr\in MJ\)。此时 \(q=4r\le32H\)，而 \(p\le bM/(4r)<M/(16H)\)，所以 \(p\le D\)；(16) 严格为负。固定比例区间的素数定理和素数调和和分别给
\(\#\{p:4pr\in MJ\}\asymp_J M/(r\log M)\) 与
\(\sum_{4bH<r\le8H}r^{-1}\asymp_J1/\log H\)。故
\[
\boxed{\quad
\#\{4pr\in MJ:p,r\text{ 不同奇素数},\ 4bH<r\le8H\}
\gg_J\frac M{\log^2M},
\quad}\tag{17}
\]
并且这些行的 \(a_D\) 绝对质量 \(\gg_{\psi,J}1/\log M\)。式 (17) 只说明物理行的真实符号和规模，未给它们与其他行的带通 covariance 上界。

## 边界

\(2p\) 消失来自特殊等式 \(\alpha(1)=\alpha(2)\)。它不能推广为所有偶平方自由物理点的零行；(2h) 分类 \(q\le H\) 的新非平方自由零行，(15)--(17) 表明同一 \(4r\) 族跨过 \(p=D\) 后重新出现负系数。未覆盖的多大素因子及非零 cofactor 物理行仍需联合估计。即使删去 (13) 的零行列，完整高除数 Gram 仍须有 \(O_\varepsilon(H^4M^{-1+\varepsilon})\) 的真实 signed 上界；当前仅有任意对数幂节省。
