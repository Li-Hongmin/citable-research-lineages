# 上指数完整 Farey 分子环的线性谱隙与分母耦合（候选）

日期：2026-09-30。本文只讨论真实旧奇 Weil 算子的有限 Farey 常值槽主压缩。依赖 [note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md) 的有序互素对图及跨素数指数零点余项、[note 807](../notes/807-natural-farey-constant-mode-has-two-thirds-logarithmic-energy.md) 的带符号算术核、[note 809](../notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md) 的小分子非算术界；联合外区时另用 [note 820](../notes/820-dyadic-numerator-annuli-pay-high-slope-interior-corridor.md) 与 [note 822](../notes/822-entire-farey-exterior-joins-near-and-upper-interior-with-growing-gap.md)。主要新增结论是固定 \(\theta\ge8/9\) 时**整个** \(P^\theta<a\le P/H^\alpha\) 分子环的线性谱隙，见 (8)--(10)；分母分割和真实跨块下界见 (1)--(5a)。结论尚未异源复核，故留在 `scratch/`。

令奇素数 \(p\to\infty\)，\(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(\alpha>1\)、\(0<\theta<1\)，置
\[
A=\lfloor P^\theta\rfloor,\qquad S=\lfloor P/H^\alpha\rfloor.
\]
充分大时 \(A<S<Q\)。在正交常值奇槽基 \(\psi_{a/b}\) 中，令
\[
\mathcal L=\operatorname{span}\{\psi_{a/b}: A<a\le S,\ 1\le b\le A,\ (a,b)=1\},
\]
\[
\mathcal U_R=\operatorname{span}\{\psi_{a/b}:A<b<a\le S,\ a/b>R,\ (a,b)=1\},
\]
其中 \(R\ge1\) 任取，特别可取 note 824 的 \(R=\lfloor H/2\rfloor\)。于是 note 824 遗漏的 \(A<a\le S,\ a/b>R\) 恰分为 \(\mathcal L\) 中满足同一斜率条件的子空间与 \(\mathcal U_R\)。

**命题。** 对上述参数，真实主压缩满足
\[
\boxed{\quad P_{\mathcal L}A_{p^2,-}P_{\mathcal L}
\succeq\bigl((1-\theta)H-O_{\alpha,\theta}(\log H)\bigr)I_{\mathcal L}.\quad}\tag{1}
\]
设一维对称素数幂矩阵
\[
K_S(m,n)=c_{m/n}+c_{n/m},\qquad
c_q=\begin{cases}\Lambda(q)/\sqrt q,&q\text{ 为整数素数幂},\\0,&\text{其他情形},\end{cases}
\]
并令 \(\lambda_{A,S}=\|P_{(A,S]}K_SP_{(A,S]}\|\)。则余下分母大于 \(A\) 的块满足
\[
P_{\mathcal U_R}A_{p^2,-}P_{\mathcal U_R}
\succeq\bigl(2H-2\lambda_{A,S}-O_{\alpha,\theta}(\log H)\bigr)I_{\mathcal U_R},\tag{2}
\]
而且
\[
\boxed{\quad
\log(S/A)-O(1)\le\lambda_{A,S}\le\log S+O(1).
\quad}\tag{3}
\]
因此，若能无条件证明 \(\lambda_{A,S}\le(1-\eta)H\) 且固定 \(\eta>0\)，式 (2) 就给 \(\mathcal U_R\) 的 \((2\eta-o(1))H\) 谱隙。式 (3) 表明这种一维方法中的 \(\eta\) 至多为 \(\theta+o(1)\)。这些是各自主压缩的结论；合并两块还须支付其真实跨块。

还有一个可直接合并的背景。固定 \(r>2/(1-3/\pi^2)\)，令 \(G,E,L\) 分别为 [note 822](../notes/822-entire-farey-exterior-joins-near-and-upper-interior-with-growing-gap.md) 的上分子高斜率内区、polar 外区及有界斜率外区，\(\gamma_r=1-2/r-3/\pi^2>0\)。则
\[
P_{\mathcal L\oplus G\oplus E}A_{p^2,-}P_{\mathcal L\oplus G\oplus E}
\succeq\bigl(\min\{1-\theta,\gamma_r\}-o(1)\bigr)H I,\tag{4}
\]
\[
P_{\mathcal L\oplus G\oplus L\oplus E}A_{p^2,-}P_{\mathcal L\oplus G\oplus L\oplus E}
\succeq\bigl(\log H-\log\log H-O_{\alpha,\theta,r}(1)\bigr)I.\tag{5}
\]
加入 note 804 的全部 Farey 阶跃偶极 \(W_p\) 后仍有 \((c_0-o(1))I\) 谱隙。式 (4)--(5) 也适用于将 \(\mathcal L\) 缩成斜率 \(>R\) 的子块。

这两个分母块之间的真实耦合却是线性级。固定 \(R=\lfloor H/2\rfloor\)，令 \(\mathcal L_R\subset\mathcal L\) 再满足 \(a/b>R\)。则
\[
\boxed{\quad
\|P_{\mathcal L_R}A_{p^2,-}P_{\mathcal U_R}\|
\ge\bigl(\sqrt{\theta(1-\theta)}+o(1)\bigr)H.
\quad}\tag{5a}
\]
因此不能把 (1) 与 (2) 仅凭 \(o(H)\) 跨块扰动拼接。

## 证明

note 807 与 note 809 在整个 \(I_Q=\operatorname{span}\{\psi_{a/b}:a\le Q\}\) 上给
\[
A_{I_Q}=(D_p-\log2)I-C^-_{I_Q}-N+B-2hh^*+O(\Delta)I,
\qquad D_p=2H+O(1),\quad B\succeq0,
\]
且 \(\|N\|+2\|h\|^2=O(H^{-1})\)。所以对任何 \(F\subset I_Q\)，只须给出 \(\lambda_{\max}(C^-_F)\) 的上界。

沿 note 803，将 \(\psi_{a/b}\) 反对称、等距地提升到有序互素对 \((a,b),(b,a)\)。有序图中不跨素数指数零点的边，逐项由 \(K_S\otimes I+I\otimes K_S\) 支配；余图在全 Farey 空间的算子范数为 \(O(\log H)\)。该余图界取主压缩后仍成立。由于这些矩阵逐项非负，对任意实或复系数先取绝对值再用算子范数，即可把这一逐项支配转为二次型上界。

记整数集合 \(U_0=(A,S]\)、\(L_0=[1,A]\)。\(\mathcal L\) 的反对称提升支撑于两个**不交**的矩形 \(U_0\times L_0\) 与 \(L_0\times U_0\)。单坐标边不能从一个矩形进入另一个：若只改第一个坐标，共同第二坐标必须同时属于 \(U_0\) 与 \(L_0\)；改第二个坐标亦然。因此单坐标算术压缩分为两块，每块由
\[
K_{U_0,U_0}\otimes I_{L_0}+I_{U_0}\otimes K_{L_0,L_0}
\]
（或其转置）逐项支配，故
\[
\lambda_{\max}(C^-_{\mathcal L})
\le\|K_{U_0,U_0}\|+\|K_{L_0,L_0}\|+O(\log H).\tag{6}
\]
对所有整数 \(n\le X\)，取权 \(v_n=n^{-1/2}\)。逐素数幂计数直接给
\[
\frac{(K_Xv)_n}{v_n}
=\sum_{q\mid n}\Lambda(q)+\sum_{q\le X/n}\frac{\Lambda(q)}q
=\log n+\mathfrak M(X/n)
\le\log X+O(1),\qquad
\mathfrak M(t)=\sum_{q\le t}\frac{\Lambda(q)}q.
\]
正权 Schur 检验及主压缩给 \(\|K_{U_0,U_0}\|\le\log S+O(1)\)、\(\|K_{L_0,L_0}\|\le\log A+O(1)\)。将其代入 (6)，再用 \(D_p=2H+O(1)\)、\(\log A=\theta H+o(1)\)、\(\log S=H-\alpha\log H+o(1)\)，便得 (1)。斜率限制只会进一步取主压缩，所以 (1) 同样适用于遗漏带在 \(\mathcal L\) 内的部分。

对于 \(\mathcal U_R\)，反对称提升全部位于 \(U_0\times U_0\)。同一逐项支配给
\(\lambda_{\max}(C^-_{\mathcal U_R})\le2\lambda_{A,S}+O(\log H)\)，这证明 (2)。式 (3) 的上界已证。为证下界，取 \(v_n=n^{-1/2}\mathbf1_{A<n\le S}\)，则
\[
\|v\|^2=\sum_{A<n\le S}\frac1n=\log(S/A)+O(A^{-1}),
\]
\[
\langle v,K_Sv\rangle
=2\sum_{A<m\le S}\frac1m\,
\mathfrak M(S/m)
=\log^2(S/A)+O(\log(S/A)+1).
\]
第二式由 \(\mathfrak M(t)=\log t+O(1)\) 和积分比较得到。Rayleigh 商至少为 \(\log(S/A)-O(1)\)，完成 (3)。\(\square\)

为证联合式 (4)--(5)，在所有块上只丢去**同一个**正异臂 Archimedean 矩阵 \(B\)。note 820 给删正矩阵后的 \(G\oplus E\) 下界 \((\gamma_r-o(1))H\)。由 note 803 的两个单坐标矩形，\(\mathcal L\) 到 \(G\) 的算术边若不在 \(O(\log H)\) 余图中，就必须把某一坐标从 \(n\le S\) 送到 \(S<m\le Q\)。对该矩形取权 \(j^{-1/2}\)，高侧加权行和至多 \(\log Q\le H\)，低侧加权行和至多
\[
\mathfrak M(Q/n)-\mathfrak M(S/n)
\le\log(Q/S)+O(1)=O_\alpha(\log H).
\]
分别处理两个张量项再相加，得 \(\|C^-_{\mathcal L,G}\|=O_\alpha(\sqrt{H\log H})\)。note 813 对任意 \(I_Q\) 子空间到 \(E\) 的算术交叉给同阶界。内区非算术同臂核与 polar 在整个 \(I_Q\) 上为 \(O(H^{-1})\)，内区到 \(E\) 的两项非算术交叉为 \(O_r(1)\)。因此 \(\mathcal L\) 到 \(G\oplus E\) 的删正矩阵交叉为 \(o(H)\)。它与 (1) 和 \(G\oplus E\) 的下界作二块比较，得到 (4)。

由 \(S<Q/r\)，\(\mathcal L\) 的两个整数坐标都小于 \(Q/r\)，而 \(L\) 的两个坐标都大于 \(Q/r\)。从 \(a/b\in\mathcal L\) 经素数幂乘法、除法或乘积反转所得的既约结果，至少有一个坐标不超过 \(a\) 或 \(b\)，故 \(C^-_{\mathcal L,L}=0\)。note 822 的内外非算术矩形与 polar 界遂给删正矩阵交叉 \(O_r(1)\)。同一 note 给 \(L\) 的删正矩阵下界 \(\log H-\log\log H-O_r(1)\)，及 \(L\) 到 \(G\oplus E\) 的 \(O_r(\sqrt H)\) 交叉。用 (4) 的线性谱隙完成平方，\(L\) 只损失 \(O_{\alpha,\theta,r}(1)\)，证明 (5)。note 806 的全常值槽到 \(W_p\) 混合范数为 \(O(1)\)，note 804 给 \(W_p\succeq(c_0-o(1))I\)；(5) 使最后的 Schur 损失为 \(O(1/\log H)=o(1)\)。\(\square\)

最后证明 (5a)。由 Bertrand 定理取素数 \(a\in(S/2,S]\)，并置 \(B_a=\lfloor(a-1)/R\rfloor\)。充分大时 \(A<B_a<a\)。固定该分子，取两组槽 \(x_b=a/b\)（\(1\le b\le A\)）与 \(y_u=a/u\)（\(A<u\le B_a\)）。前者属于 \(\mathcal L_R\)，后者属于 \(\mathcal U_R\)；由于 \(a\) 是大于所有分母的素数，分数均既约。它们的算术比值为 \(x_b/y_u=u/b\)，而乘积 \(a^2/(bu)\) 不可能是整数，故精确有
\[
C^-(x_b,y_u)=c_{u/b}.
\]
令两侧试探系数分别为 \(b^{-1/2}\) 与 \(u^{-1/2}\)。于是算术矩形的双线性型为
\[
\sum_{b\le A}\frac1b
\sum_{A/b<q\le B_a/b}\frac{\Lambda(q)}q
=\log A\,\log(B_a/A)+O(H),
\]
其中对每个 \(b\le A\) 使用统一的 \(\mathfrak M(t)=\log t+O(1)\)。两侧范数平方分别是 \(\log A+O(1)\) 与 \(\log(B_a/A)+O(1)\)。因此该算术跨块范数至少为
\[
\sqrt{\log A\,\log(B_a/A)}+O(1)
=\bigl(\sqrt{\theta(1-\theta)}+o(1)\bigr)H.
\]
在这些固定分子的槽上，\(x_b,y_u>R\)；note 805 的正异臂 Archimedean 核对角 \(M_\Delta(2\log x)=O(\Delta)\)，且槽数至多 \(B_a=O(p)\)。正性与迹界给它在整个固定分子纤维上的范数 \(O(\Delta B_a)=o(1)\)。note 809 又给同臂非算术核与 polar 扣款在 \(I_Q\) 上合计 \(O(H^{-1})\) 范数。真实 Weil 跨块因此与上述算术矩形只差 \(o(1)\) 范数，证明 (5a)。\(\square\)

## 一维环带的有限大素因子归约

固定 \(0<\varepsilon<1\)，置 \(X=P^\varepsilon\)。将 \(K_{(A,S]}\) 的边按素数幂标签分为 \(q\le X\)、素数 \(q>X\)、以及 \(q>X\) 的高次素数幂。对任意整数区间内的主压缩，\(q\le X\) 的**向上**有向矩阵 \(T_{\le X}(m,mq)=\Lambda(q)/\sqrt q\) 用权 \(v_n=n^{-1/2}\) 满足
\[
\frac{(T_{\le X}v)_m}{v_m}
\le\sum_{q\le X}\frac{\Lambda(q)}q
\le\varepsilon H+O(1),\qquad
\frac{(T_{\le X}^{*}v)_n}{v_n}
\le\sum_{q\mid n}\Lambda(q)=\log n\le H.
\]
矩形 Schur 检验给 \(\|T_{\le X}\|\le(\sqrt\varepsilon+o(1))H\)，故其对称边块范数至多 \((2\sqrt\varepsilon+o(1))H\)。所有高次素数幂 \(q=\ell^j\)、\(j\ge2\) 的向上有向矩阵满足同样的入侧 \(\le H\)，而出侧由收敛和
\(\sum_{\ell}\sum_{j\ge2}\Lambda(\ell)/\ell^j<\infty\) 一致有界。因此其对称块范数为 \(O(\sqrt H)\)。重复计入的 \(q\le X\) 高次幂只会使下式的误差更宽松。

令 \(K^{\mathrm{large}}\) 只保留素数标签 \(q>X\)。唯一分解 \(n=mr\)，其中 \(m\) 的全部素因子 \(\le X\)、\(r\) 的全部素因子 \(>X\)，使 \(K^{\mathrm{large}}_{(A,S]}\) 按 \(m\) 精确直和。每块的 \(r\) 满足 \(A/m<r\le S/m\)，且 \(r\) 的大素因子数（按重数）至多 \(\lfloor1/\varepsilon\rfloor\)。记这些有限层块的最大算子范数为 \(\Lambda_{\varepsilon;A,S}\)。三角不等式于是给严格的一维归约
\[
\boxed{\quad
\lambda_{A,S}
\le\Lambda_{\varepsilon;A,S}
+(2\sqrt\varepsilon+o(1))H.
\quad}\tag{7}
\]
式 (7) 表明，只要某个固定 \(\varepsilon>0\) 的有限大素因子层满足 \(\Lambda_{\varepsilon;A,S}\le(1-2\sqrt\varepsilon-\eta)H\) 且 \(\eta>0\)，就得到式 (2) 所需的线性环带谱亏损。这里还没有证明该有限层上界；特别是 \(\varepsilon\) 变小时层数随 \(1/\varepsilon\) 增长，不能把有限层直接当作已支付。

## 上指数完整分子环的线性谱隙

上面的有向边 Schur 检验不用截断素数时，已经能处理 \(\theta\ge8/9\) 的**完整分子环**。置
\[
\mathcal J=\operatorname{span}\{\psi_{a/b}:A<a\le S,\ 1\le b<a,\ (a,b)=1\},
\qquad c_*:=\frac{5-\sqrt{19}}9>0.
\]
对每个固定 \(\alpha>1\)、\(8/9\le\theta<1\)，有候选下界
\[
\boxed{\quad P_{\mathcal J}A_{p^2,-}P_{\mathcal J}
\succeq(c_*-o_{\alpha,\theta}(1))H I_{\mathcal J}.\quad}\tag{8}
\]
特别地，note 824 遗漏的 \(A<a\le S,\ a/b>\lfloor H/2\rfloor\) 整带是 \(\mathcal J\) 的子空间。对上述固定 \(r\) 及同一 \(G,E,L,W_p\)，还得到
\[
P_{\mathcal J\oplus G\oplus E}A_{p^2,-}P_{\mathcal J\oplus G\oplus E}
\succeq\bigl(\min\{c_*,\gamma_r\}-o(1)\bigr)H I,\tag{9}
\]
\[
P_{\mathcal J\oplus G\oplus L\oplus E}A_{p^2,-}P_{\mathcal J\oplus G\oplus L\oplus E}
\succeq\bigl(\log H-\log\log H-O_{\alpha,\theta,r}(1)\bigr)I.\tag{10}
\]
加入 \(W_p\) 后仍有 \((c_0-o(1))I\) 谱隙。

证明 (8) 时保留整数分割 \(L_0=[1,A]\)、\(U_0=(A,S]\)。把一维 \(K_{U_0,U_0}\) 写成向上有向矩阵 \(T_U\) 与其转置。上述加权出侧行和至多 \(\log(S/A)+O(1)\)，入侧行和至多 \(\log S\)，因此
\[
\lambda_U:=\|K_{U_0,U_0}\|
\le2t,
\qquad t:=\sqrt{(\log S)(\log(S/A)+O(1))}
=(\sqrt{1-\theta}+o(1))H.
\]
同理 \(\lambda_L:=\|K_{L_0,L_0}\|\le\log A+O(1)\)。矩形 \(K_{U_0,L_0}\) 的高侧加权行和至多 \(\log S\)；低侧为
\(\mathfrak M(S/n)-\mathfrak M(A/n)\le\log(S/A)+O(1)\)。故 \(\kappa:=\|K_{U_0,L_0}\|\le t\)。

\(\mathcal J\) 的反对称有序对提升支撑在 \((U_0\times L_0)\sqcup(L_0\times U_0)\sqcup(U_0\times U_0)\)。按 note 803 的单坐标支配，前三块的算术算子范数不超过标量比较矩阵
\[
\begin{pmatrix}
\lambda_U+\lambda_L&0&\kappa\\
0&\lambda_U+\lambda_L&\kappa\\
\kappa&\kappa&2\lambda_U
\end{pmatrix}
+O(\log H)I.
\]
其反对称的前两块组合与第三块解耦；余下二维块的最大特征值由
\[
\begin{pmatrix}
\theta+2\sqrt{1-\theta}&\sqrt{2(1-\theta)}\\
\sqrt{2(1-\theta)}&4\sqrt{1-\theta}
\end{pmatrix}H+o(H)
\]
控制。对 \(\theta\ge8/9\)，此矩阵各非负条目均不超过 \(\theta=8/9\) 的对应条目；在该端点它是
\(\left(\begin{smallmatrix}14/9&\sqrt2/3\\\sqrt2/3&4/3\end{smallmatrix}\right)\)，最大特征值为 \((13+\sqrt{19})H/9=(2-c_*)H\)。前两块的反对称组合本身的特征值至多 \((14/9+o(1))H\)，也小于 \((2-c_*)H\)。加上 note 803 的 \(O(\log H)\) 余图、删去同一个 \(B\succeq0\)，再用 note 809 在 \(I_Q\) 上的 \(O(H^{-1})\) 非算术及 polar 扣款，得到 (8)。

对 (9)--(10)，\(\mathcal J\subset I_S\) 且所有整数坐标 \(\le S\)。所以前文证明 (4)--(5) 时的 \(\mathcal L\to G\) 矩形 \(O(\sqrt{H\log H})\)、\(I_Q\to E\) 界、到 \(L\) 的算术零块及非算术界，全都原样适用于 \(\mathcal J\)。以 (8) 替换 (1)，沿相同的两次 Schur 配方先得 (9)，再得 (10) 和阶跃联合下界。\(\square\)

## 自然权逐行界的障碍

式 (3) 的一维上界不能仅靠自然权 \(v_n=n^{-1/2}\) 的逐行 Schur 检验改善为固定线性亏损。取不超过 \(S\) 的最大 primorial \(n=\prod_{\ell\le y}\ell\)。素数定理给 \(y\asymp H\)，而下一素数为 \(O(H)\)，故 \(S/O(H)<n\le S\)。因为 \(A=P^{\theta+o(1)}\)、\(\theta<1\)，充分大时对每个 \(\ell\mid n\) 都有 \(n/\ell>A\)。于是受限矩阵在该行的自然权比为
\[
\frac{(K_{(A,S]}v)_n}{v_n}
=\sum_{\ell\mid n}\log\ell+\mathfrak M(S/n)
=\log n+\mathfrak M(S/n)
=\log S+O(1).
\]
这里最后一步用 \(\mathfrak M(t)=\log t+O(1)\)。因此自然权的最大逐行比仍为 \(H-O(\log H)\)。它不反驳一维算子的线性谱亏损；它说明若要证明该亏损，须使用比单一自然权逐行界更强的谱论证。

## 边界

式 (8)--(10) 在固定 \(\theta\ge8/9\) 时支付了**整个** \(A<a\le S\) 分子环及其到上分子、整个外区和阶跃槽的联合谱隙；在较小 \(\theta\) 范围，式 (1)、(4)--(5) 只支付分母不超过 \(A\) 的部分。式 (5a) 证明两个分母块之间确有线性级的真实耦合。对 \(\theta<8/9\)，式 (2)--(3) 仍把大分母块的充分条件归结到一维环带谱损失。上述联合下界尚未纳入 \(a\le A\) 的深高斜率块、其余近对角与适中斜率块的共同 Schur 预算；非恒定槽轮廓、无限维补空间及 moving-\(N\) Möbius signed covariance 也仍开放，故本文不证明或反驳 RH。
