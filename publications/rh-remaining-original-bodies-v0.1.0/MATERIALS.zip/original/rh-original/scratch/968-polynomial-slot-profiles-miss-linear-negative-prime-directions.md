# 槽内多项式轮廓无法逼近线性负素数方向

日期：2026-10-02。使用 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的槽外空间及真实素数算子、[note 830](../notes/830-exterior-prime-rayleigh-has-unconditional-main-term.md) 式 (2a) 的有界变差二次型估计。下面直接从该已记录输入证明所需强范数引理，再处理逐槽多项式；不依赖 [槽外强范数候选](exterior-prime-linear-negative-directions-require-logarithmic-fourier-energy.md) 的显式公式路线。本推论尚未异源核验，故保留在 scratch。结论只排除一类轮廓对**线性尺度中心化素数负谱**的逼近，不判断完整 Weil 形式符号。

## 定理候选

令 $p\to\infty$ 沿奇素数，$\mathcal G_p$、相离槽 $I_x^+$、$E_p=\bigcup_{x\in\mathcal G_p}I_x^+$、$R_p$、$K_p$ 如 note 828，并令 $H=\log p$、$L=\log(1+p^{-2})$。对整数 $r\ge0$，定义

\[
\mathcal P_{p,r}
=\{g\in L^2(E_p): g|_{I_x^+}\text{ 是次数至多 }r\text{ 的复多项式，对每个 }x\in\mathcal G_p\},
\tag{1}
\]

$P_{p,r}$ 为其 $L^2(E_p)$ 正交投影。每个固定 $A\ge0$ 都有常数 $c_A,C_A>0$，使对充分大 $p$ 及所有 $0\le r\le p^A$，

\[
\boxed{\quad
\|(R_p-K_p)|_{\mathcal P_{p,r}}\|_{\mathcal P_{p,r}\to L^2(E_p)}
\le C_Ap\exp\!\left[-c_A
\left(\frac{\log p}{\log\log p}\right)^{1/3}\right]
=o_A(p).
\quad}                                                     \tag{2}
\]

特别地，任取固定 $c>0$。若单位向量 $g_p\in L^2(E_p)$ 满足
$\langle g_p,(R_p-K_p)g_p\rangle\le-cp$，则对每个固定 $A\ge0$，

\[
\boxed{\quad
\liminf_{p\to\infty}
\|(I-P_{p,\lfloor p^A\rfloor})g_p\|_2^2
\ge\frac{c}{2C_0}>0,
\quad}                                                     \tag{3}
\]

其中 $C_0$ 是任何使 $\|R_p-K_p\|\le C_0p$ 对充分大 $p$ 成立的绝对常数。量词中的“每个固定 $A$”不能替换为随 $p$ 增长的 $A(p)$ 而沿用同一常数。

## 证明

先给单槽多项式的显式变差成本。若 $q$ 是长为 $L$ 的区间 $I$ 上次数至多 $r$ 的复多项式，则由缩放后的正交 Legendre 展开及 $|P_k(t)|\le1$，

\[
\|q\|_{L^\infty(I)}
\le \frac{r+1}{\sqrt L}\|q\|_{L^2(I)}.
\tag{4}
\]

实多项式的 Markov 不等式在 $[-1,1]$ 为 $\|q'\|_\infty\le r^2\|q\|_\infty$；分别作用于复多项式实部与虚部，再缩放到 $I$，得
$\|q'\|_{L^\infty(I)}\le C r^2L^{-1}\|q\|_{L^\infty(I)}$。
把 $q$ 在 $I$ 外延零并计入两端跳跃，(4) 给

\[
\operatorname{Var}(q\mathbf1_I)
\le 2\|q\|_\infty+\int_I|q'|
\le C(r+1)^3L^{-1/2}\|q\|_{L^2(I)}.
\tag{5}
\]

设 $g\in\mathcal P_{p,r}$，平移后在整条实线上将其零延拓为 $a(v)=g(2H+v)$。note 830 式 (3) 给 $|\mathcal G_p|\le Cp^2$，槽两两相离，且 $L^{-1/2}\asymp p$。对每槽用 (5)，再用 Cauchy–Schwarz，

\[
\operatorname{Var}(a)
\le C(r+1)^3L^{-1/2}
\sum_{x\in\mathcal G_p}\|g\|_{L^2(I_x^+)}
\le C(r+1)^3p^2\|g\|_2.
\tag{6}
\]

为避免把强范数当作未证输入，先从 note 830 式 (2a) 推出它。令 $T_p=R_p-K_p$，仍以 $a$ 表示平移后的全实线零延拓。对任何这样的 BV 轮廓，

\[
\operatorname{Var}(T_pa)
\le Cp^3\bigl(\operatorname{Var}(a)+\|a\|_2\bigr).
\tag{6a}
\]

证明：note 830 式 (3) 给 $V_p=E_p-2H$ 是至多 $Cp^2$ 个相离区间的并。每个素数反射先平移反射 $a$，再乘 $\mathbf1_{V_p}$；因 $\|a\|_\infty\le\operatorname{Var}(a)$（零延拓在紧支撑外为零），每项的变差至多 $Cp^2\operatorname{Var}(a)$。参与素数的权重总和由 Chebyshev 界为 $O(p)$，所以反射和的变差至多 $Cp^3\operatorname{Var}(a)$。秩一项在 $V_p$ 上是 $p e^{v/2}\int_{V_p}e^{w/2}a(w)\,dw$；$V_p$ 落在固定紧区间，积分至多 $C\|a\|_2$，而 $e^{v/2}\mathbf1_{V_p}$ 的变差为 $O(p^2)$。这证明 (6a)。

固定 $B>0$，令 $\|a\|_2=1$、$\operatorname{Var}(a)\le p^B$，并置 $V_H=(H/\log H)^{1/3}$。note 830 式 (2a) 对实轮廓给
$|\langle z,T_pz\rangle|\le C_{B'}p e^{-c_{B'}V_H}$
当 $\|z\|_2\le1$、$\operatorname{Var}(z)\le p^{B'}$；复轮廓拆成实部与虚部后有同形界。取 $B'=B+4$、$d_B=c_{B'}/2$。若
$\|T_pa\|_2>p e^{-d_BV_H}$，则单位轮廓 $b=T_pa/\|T_pa\|_2$ 由 (6a) 满足

\[
\operatorname{Var}(b)
\le Cp^{B+2}e^{d_BV_H}
\le p^{B+3}                                             \tag{6b}
\]

对充分大的 $p$ 成立，因为 $V_H=o(\log p)$。因此 $z_\pm=(a\pm b)/2$ 的范数至多 $1$、变差至多 $p^{B'}$。自伴性与极化给

\[
\|T_pa\|_2
=\operatorname{Re}\langle a,T_pb\rangle
=\langle z_+,T_pz_+\rangle-\langle z_-,T_pz_-\rangle
\le 2C_{B'}p e^{-c_{B'}V_H},
\tag{6c}
\]

与所设下界矛盾，因为 $d_B<c_{B'}$。故
$\|T_pa\|_2\le p e^{-d_BV_H}$ 对充分大的 $p$ 一致成立；调整常数可写成 $C_Bp e^{-d_BV_H}$。若 $\|g\|_2=1$、$r\le p^A$，则对固定 $B>2+3A$，(6) 保证 $\operatorname{Var}(a)\le p^B$，强范数引理给 (2)；齐次性覆盖全部 $g$。

为证 (3)，写 $E_p^{\rm prime}=R_p-K_p$、$v=P_{p,r}g_p$、$h=g_p-v$。note 828 的 Chebyshev 粗界给 $\|E_p^{\rm prime}\|\le C_0p$，而 (2) 给 $\|E_p^{\rm prime}v\|=o_A(p)\|v\|$。因此

\[
|\langle g_p,E_p^{\rm prime}g_p\rangle
 -\langle h,E_p^{\rm prime}h\rangle|
\le 2\|E_p^{\rm prime}v\|\,\|g_p\|
=o_A(p).
\tag{7}
\]

由假设与 $|\langle h,E_p^{\rm prime}h\rangle|\le C_0p\|h\|_2^2$，充分大 $p$ 时 $\|h\|_2^2\ge c/(2C_0)$。取 $r=\lfloor p^A\rfloor$ 得 (3)。$\square$

## 边界

式 (2) 控制的是从多项式子空间到**全部**槽内输出的算子范数，比有限矩阵压缩 $P_{p,r}(R_p-K_p)P_{p,r}$ 的谱界强。它说明任何线性负谱方向都必须有固定比例的范数处于每个固定多项式增长阶数的槽内多项式空间之外。式 (3) 没有给这些方向的真实 Archimedean 能量下界；要判定完整 Weil 形式，仍须在同一轮廓上比较该能量与中心化素数项。
