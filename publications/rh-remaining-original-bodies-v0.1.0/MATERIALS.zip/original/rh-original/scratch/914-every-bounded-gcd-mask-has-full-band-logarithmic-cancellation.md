# 任意有界 gcd 筛选的真实完整观察在全带通上有对数相消

日期：2026-10-02。依赖 [scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 式 (4)--(10) 的小公共除数 Fourier 界、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (6) 的非别名核行和、[scratch/911](911-uniform-gcd-masks-classify-the-local-observation-ring.md) 的局部常数，以及 [scratch/912](912-periodic-background-is-paid-under-every-gcd-mask-at-target-scale.md) 的三通道目标级替换。下述合成仍只有任意对数幂节省，不能支付固定幂算术门；尚未异源复核。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实 $\psi\in C_c^3((1,2))$，$\phi(u)=\psi(u)/u$。取 scratch/860 的 $v=\chi_s^2$ 与
\[
J_H(r)=\sum_{h\in\mathbb Z}v(h/H)e(-hr/M),
\qquad a_m=\frac{c(m)}M\phi(m/M),
\tag{1}
\]
其中 $c(m)$ 是 note 849 式 (10) 的真实联合系数，窗外 $a_m=0$。对任意可随 $M,H$ 变化的 $F:\mathbb N\to\mathbb C$，$|F(g)|\le1$，置
\[
G_F[c]=\sum_{m,n}F((m,n))a_ma_nJ_H(m-n).
\tag{2}
\]
那么对每个固定 $A>0$，**一致于所有这样的 $F$**，
\[
\boxed{\quad |G_F[c]|\ll_{A,s,\psi}(\log M)^{-A}.\quad}
\tag{3}
\]
将 $c$ 换成 scratch/912 式 (1) 的真实素数、倍素数、Möbius 三通道系数 $t$，式 (3) 仍成立。
因而对每个固定 $C>0$，在 $M^{1/4}(\log M)^{-C}\le H\le Y^{1/4}$ 的非空临界窄带上，两种系数均一致于所有 $|F|\le1$ 达到 $O_C(H^4/M)$ 的**完整带通**目标量级。

进一步取 scratch/911 的 $K_0=\lfloor H^3/(\log M)^2\rfloor$、$L=\lfloor M/(32H)\rfloor$、$I_\phi=\int_1^2\phi(u)^2du$、
$V_L=M^{-1}\sum_{|r|\le L}J_H(r)$ 与绝对可和的常数 $C_g$。则完整带通中 **$|m-n|>L$ 的远旁瓣** 满足
\[
\boxed{\quad
\sum_{|m-n|>L}F((m,n))a_ma_nJ_H(m-n)
=-I_\phi V_L\sum_{g\ge1}F(g)C_g
+O_{A,s,\psi}((\log M)^{-A}).
\quad}\tag{4}
\]
这是对每个随尺度移动的 gcd 筛选同时成立的距离补偿式。例如固定 $g$ 的局部常数非零时，全带通的净值仍为对数级，远旁瓣给相反的主项。式 (4) 不表示远旁瓣逐项为负，核 $J_H$ 本身变号。

## 证明

令 $\alpha=F*\mu$ 为除数卷积，则 $F((m,n))=\sum_{q\mid m,n}\alpha(q)$ 且 $|\alpha(q)|\le\tau(q)$。定义非负量
\[
E_q=\sum_hv(h/H)
\left|\sum_{q\mid m}a_me(-hm/M)\right|^2.
\tag{5}
\]
有限求和重排给 $G_F[c]=\sum_q\alpha(q)E_q$。取 $Q=\lfloor(\log M)^B\rfloor$，$B$ 稍后选定。scratch/870 式 (10) 对每个 $q\le Q$ 一致给
\[
E_q\ll_{D,s,\psi}(\log M)^{-2D}+H^{-5}
\tag{6}
\]
对任意预先固定的 $D>0$。它从 $q$ 倍数上扣除精确周期密度、用 2023 年 Matomäki--Shao--Tao--Teräväinen 的全区间短和定理支付剩余，再以循环 Parseval 控制频带；周期密度本身由 Poisson 求和支付。这里的 $q=1,2$ 特例也包含在 (6)。由于 $\sum_{q\le Q}\tau(q)\ll Q\log(2Q)$，
\[
\sum_{q\le Q}|\alpha(q)|E_q
\ll Q\log(2Q)\bigl((\log M)^{-2D}+H^{-5}\bigr).
\tag{7}
\]

对 $q>Q$，把 (5) 展开后按物理配对取绝对值。$\phi$ 的紧支撑给 $|m-n|\le(1-\kappa_\psi)M$。在 $m\ne n$ 处，$q\mid(m-n)$，对给定 $q$ 有 $O(M/q)$ 个 $m$，而 scratch/868 式 (6) 给
$\sum_{k\ne0}|J_H(qk)|\ll_{s,\psi}M/q$。因 $|a_m|\ll_\psi\log M/M$，非对角尾至多
\[
\ll_{s,\psi}\log^2M\sum_{q>Q}\frac{\tau(q)}{q^2}
\ll\frac{\log^2M\log(2Q)}Q.
\tag{8}
\]
对角处用 $\sum_{q\mid m}\tau(q)=d_3(m)$、
$\sum_{m\le2M}d_3(m)\ll M\log^2M$ 及 $J_H(0)\ll H$，得
\[
\ll_{s,\psi}\frac{H\log^4M}{M}.
\tag{9}
\]
给定 $A$，先取 $B>A+4$，再取 $D>B+A+4$。在 $H\gg M^{1/5}$、$H\ll M^{1/4}$ 下，(7)--(9) 均为 $O_A((\log M)^{-A})$，证明 (3)。

scratch/912 式 (3) 已无条件给出 $|G_F[c]-G_F[t]|$ 的四项显式界，且它们在本 $H$ 区间内均小于任意固定负对数幂，所以三通道版本随之成立。

最后，scratch/911 的证明式 (11) 对 $T=L$、任意有界 $F$ 统一求和，给
\[
\sum_{|m-n|\le L}F((m,n))a_ma_nJ_H(m-n)
=I_\phi V_L\sum_{g\ge1}F(g)C_g
+O_A((\log M)^{-A}).
\tag{10}
\]
从完整带通式 (3) 减去 (10) 即得 (4)。$\square$

## 算术边界

式 (3)--(4) 说明对数尺度上，任何有界物理 gcd 筛选的局部主项均由同一筛选内的其他距离旁瓣支付。它不界定 note 849 式 (15) 或 scratch/912 式 (5) 所需的 $H^4/M$ 固定幂剩余；当 $H=M^\gamma$、$\gamma<1/4$ 时，任意对数幂仍远大于目标。
