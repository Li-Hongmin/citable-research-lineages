# 候选：深内区到外区的一维算术矩形范数首项尖锐

日期：2026-09-30。依赖 [note 813](../notes/813-deep-interior-and-polar-exterior-joint-farey-gap.md) 式 (8)--(10) 的矩形 Schur 上界。本文只研究其中的非负一维矩阵；不声称带符号 Farey 折叠的实际交叉范数也取到同一首项。

## 命题

沿奇素数 \(p\to\infty\)，置 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(\alpha>1\)，令 \(S=\lfloor P/H^\alpha\rfloor\)、\(L=\{1,\dots,S\}\)、\(U=\{Q+1,\dots,P\}\)，且
\[
K_{U,L}(a,c)=c_{a/c}+c_{c/a},\qquad
c_t=\begin{cases}\Lambda(t)/\sqrt t,&t\text{ 为整数素数幂},\\0,&\text{其他}.\end{cases}
\]
则
\[
\boxed{\quad\|K_{U,L}\|^2=(1+o_\alpha(1))H\log H.\quad}\tag{1}
\]
因此 note 813 中只用此矩形范数与外区统一谱隙的 Schur 步骤，其 \(H\log H\) 首项不能靠改进同一无符号矩形范数而降低。

## 证明

note 813 式 (8)--(10) 直接给上界 \(\|K_{U,L}\|^2\le H(\log H+O(1))\)。为证下界，在 \(L\) 上取 \(v_c=c^{-1/2}\)。因 \(a>Q\ge S\)，只可能有 \(a/c=n\) 为整数素数幂，且
\[
(K_{U,L}v)_a=\frac{T_a}{\sqrt a},\qquad
T_a:=\sum_{\substack{n\mid a\\a/n\le S}}\Lambda(n),
\quad \|v\|^2=\sum_{c\le S}\frac1c=H-\alpha\log H+O_\alpha(1).
\tag{2}
\]
其中 \(\Lambda\) 自动限制 \(n\) 为素数幂。设 \(Z=\lceil P/S\rceil\) 及 \(d_a=\sum_{n\mid a,\ n\le Z}\Lambda(n)\)。精确恒等式 \(\sum_{n\mid a}\Lambda(n)=\log a\) 给 \(T_a\ge\log a-d_a\ge0\)。因此
\[
\sum_{a\in U}\frac{T_a^2}{a}
\ge\sum_{Q<a\le P}\frac{\log^2a}{a}
-2H\sum_{Q<a\le P}\frac{d_a}{a}.
\tag{3}
\]
第一和由积分比较为
\[
\sum_{Q<a\le P}\frac{\log^2a}{a}
=\frac{\log^3P-\log^3Q}{3}+O(1)
=(1+o(1))H^2\log H.
\tag{4}
\]
因为 \(Z=H^{\alpha+o(1)}\ll Q\)，调换两次有限求和并用调和数估计，得到
\[
\begin{aligned}
\sum_{Q<a\le P}\frac{d_a}{a}
&=\sum_{n\le Z}\frac{\Lambda(n)}n
\sum_{Q/n<m\le P/n}\frac1m\\
&\le(\log(P/Q)+O(1))\sum_{n\le Z}\frac{\Lambda(n)}n\\
&=O_\alpha((\log H)^2),
\end{aligned}
\tag{5}
\]
其中只用了统一 Mertens 估计 \(\sum_{n\le Z}\Lambda(n)/n=\log Z+O(1)\)。式 (3)--(5) 给 \(\|K_{U,L}v\|^2\ge(1+o_\alpha(1))H^2\log H\)；除以 (2) 即得 (1)。\(\square\)

## 边界

式 (1) 不判定 \(\|C^-_{E_rI_S}\|\) 的首项，也不判定真实旧奇 Weil 联合压缩在 \(S\) 更靠近 \(Q\) 时的符号。它只关闭“改善同一无符号矩形范数首项”这一局部路线。
