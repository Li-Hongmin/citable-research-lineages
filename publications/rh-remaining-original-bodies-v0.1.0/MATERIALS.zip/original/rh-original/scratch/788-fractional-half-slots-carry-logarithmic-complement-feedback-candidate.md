# 分数指标半槽承载真实旧核的对数级补空间反馈（已独立复核，待晋级）

日期：2026-09-29。依赖 [note 775](../notes/775-a-prime-source-has-logarithmic-arithmetic-coupling-to-the-complement.md) 的补空间反馈问题、[note 777](../notes/777-physical-collar-forcing-has-logarithmic-inverse-response-on-prime-source-bands.md) 的真实旧奇算子、[note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单槽对角及 Archimedean 核，以及 [note 787](../notes/787-farey-spacing-bounds-opposite-arm-arithmetic-operator.md) 的全整数半槽主压缩。本文检验 note 787 尚未支付的正交补，而非替换物理旧核。

## 定理

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)，\(X=\sqrt k=p\)，并令 \(P_X\) 为真实旧奇空间中 \(e_n\)、\(2\le n\le X\) 的张成空间投影，\(Q_X=I-P_X\)。对每个素数幂 \(2\le q<p\)，令 \(g_q\) 是下面定义的分数指标单位奇半槽。则 \(\{g_q\}_{q<p}\) 为 \(Q_XH_k^-\) 中的正交单位族，并且
\[
\boxed{
\|Q_XA_{k,-}e_p\|
\ge\left(\frac1{\sqrt2}+o(1)\right)\log p
=\left(\frac1{2\sqrt2}+o(1)\right)\log k.}
\tag{1}
\]
若完整旧奇算子 \(A_{k,-}\succeq a_kI\)、\(a_k>0\)，则它在 \(Q_XH_k^-\) 上的短块严格正，且
\[
\boxed{
\left\langle Q_XA_{k,-}e_p,
\left(Q_XA_{k,-}Q_X\right)^{-1}Q_XA_{k,-}e_p\right\rangle
\ge\left(\frac18+o(1)\right)\log k.}
\tag{2}
\]
所以 note 786 的全整数低段主压缩虽有 \((1/2)\log k-O(1)\) 正谱隙，其到真实正交补的 Schur 反馈在该端点序列上仍不是有界余项。更强的是，下述 \(g_q\) 与**全部**整数半槽 \(2\le m\le k\) 正交，故 (1)--(2) 对任何包含 \(e_p\)、且只由这些整数半槽张成的投影 \(P\) 仍成立。式 (2) 不判定短算子最终符号。

## 分数指标槽与正交性

沿用 \(\Delta=\frac12\log(1+1/k)\)、\(\tau=\sqrt{k(k+1)}\)、\(F=(2\Delta)^{-1/2}\)。对实数 \(1<r<k\) 定义
\[
J_r^-=(re^{-\Delta},r),\qquad J_r^+=(k/r,\tau/r),
\qquad u_r=F(1_{J_r^-}-1_{J_r^+}).
\tag{3}
\]
若两半槽均在旧区间且不交，则 \(u_r\) 是单位奇向量；整数 \(r=n\) 时 \(u_n=e_n\)。令
\[
g_q=u_{p/q},\qquad c_q=\Lambda(q)/\sqrt q,
\qquad S_p=\sum_{\substack{2\le q<p\\q\text{ 素数幂}}}c_q^2.
\tag{4}
\]
其下臂落在 \((1,p/2]\)，上臂落在 \([2p,k)\)，且两臂均完整位于旧空间。不同 \(g_q\) 的同号臂若相交，则清除分母后会有整数 \(0<|q-r|<\max(q,r)(e^\Delta-1)<1\)，不可能；异号臂由上述支撑范围分离。故 \(\{g_q\}\) 是正交单位族。

对任意整数 \(2\le m\le k\)，\(g_q\) 与 \(e_m\) 的同号臂相交会要求 \(pe^{-\Delta}<qm<pe^\Delta\)。因 \(p(e^\Delta-1)<1\)，唯一可能是 \(qm=p\)，与 \(p\) 为素数、\(2\le q<p\) 矛盾。异号臂相交则精确要求
\[
k<\frac{pm}{q}<k+1
\quad\Longleftrightarrow\quad pq<m<pq+\frac qp,
\]
该开区间不含整数。因此 \(g_q\perp e_m\) 对**全部**整数指标成立，特别地 \(g_q\in Q_XH_k^-\)。

## 算术交叉精确值

记 \(\mathcal R_k=-\sum_{s\text{ 素数幂}}c_s(T_s+T_s^*)\)。由于 \(p/(p/q)=q\)，\(e_p\) 与 \(g_q\) 有一条完整同号平移边：两个同号臂各贡献 \(-c_q/2\)，合计 \(-c_q\)。不存在另一条同号边：任意两形式指标的同号相交，在 \(k=p^2\) 的槽宽下清除分母后仍强制指标比例精确等于整数 \(s\)。异号相交的两种方向分别要求
\[
sk<\frac{p^2}{q}<s(k+1),
\qquad k<s\frac{p^2}{q}<k+1.
\]
前者因 \(p^2/q<k\) 不可能；后者要求整数 \(s\) 严格处于 \(q\) 和 \(q+q/p^2\) 之间，也不可能。因此
\[
\boxed{\langle g_q,\mathcal R_ke_p\rangle=-c_q.}
\tag{5}
\]

对 \(q,r<p\) 两个素数幂，分数指标的乘积 \((p/q)(p/r)=p^2/(qr)<k\)。同样的异号条件要求整数 \(s\in(qr,qr+qr/p^2)\)，故异号算术边全无。同号边只在 \(q/r\) 或 \(r/q\) 是素数幂时出现，系数为负。于是对非负系数 \(c_q\)，
\[
\boxed{\left\langle \sum_qc_qg_q,\mathcal R_k\sum_rc_rg_r\right\rangle\le0.}
\tag{6}
\]

## 完整旧核与变分反馈

令 \(G_k\) 为完整 Archimedean 部分、\(s_k\) 为 polar 向量，\(A_{k,-}=G_k+\mathcal R_k-2|s_k\rangle\langle s_k|\)。note 780 的 \(K(d)\ll1/d\) 给出 \(|\langle g_q,G_ke_p\rangle|\ll\Delta\)；四种半槽配对的对数距离至少为 \(\log2-O(\Delta)\)。此时 \(e_p=F(1_{(-\Delta,0)}-1_{(0,\Delta)})\) 在物理对数坐标中，故 \(\langle s_k,e_p\rangle=-8F\sinh^2(\Delta/4)=O(p^{-3})\)，而 \(\|s_k\|=O(p^{1/2})\)。因此对
\[
g=\sum_{\substack{2\le q<p\\q\text{ 素数幂}}}c_qg_q,
\qquad \|g\|^2=S_p,
\tag{7}
\]
有 \(\langle g,A_{k,-}e_p\rangle=-S_p+o(1)\)：Archimedean 误差至多 \(O(\Delta\sqrt p\log p)=o(1)\)，polar 误差至多 \(O(p^{-5/2}\log p)=o(1)\)。逐 \(g_q\) 投影并用 \(\{g_q\}\) 正交，Archimedean 误差的 \(\ell^2\) 范数为 \(O(\sqrt p\Delta)=o(1)\)，polar 误差范数为 \(O(p^{-5/2})\)。由素数定理及高次素数幂的有界平方质量，
\[
S_p=\left(\frac12+o(1)\right)\log^2p,
\]
这证明 (1)。

对于 \(g\) 的能量，同号不同槽的 Archimedean 交叉非正；异号交叉的对数距离至少为 \(\log4-O(\Delta)\)，故其总正贡献至多 \(O(\Delta(\sum_qc_q)^2)=O(\log^2p/p)=o(1)\)。单槽对角由 note 780 精确为 \(D_k+O(\Delta)\)，\(D_k=\log k+1-\gamma_E-\log\pi\)；自槽异号交叉也包含在上述 \(o(1)\) 中。结合 (6) 和非正 polar 项，
\[
\boxed{\langle g,A_{k,-}g\rangle\le D_kS_p+o(1).}
\tag{8}
\]
若 \(A_{k,-}\succeq a_kI\)、\(a_k>0\)，左边严格为正。这里 \(Q_XA_{k,-}Q_X\) 指在 \(Q_XH_k^-\) 上的闭形式压缩。用 \(g\in Q_XH_k^-\) 在其逆度量变分式中测试，得到
\[
\left\langle Q_XA_{k,-}e_p,(Q_XA_{k,-}Q_X)^{-1}Q_XA_{k,-}e_p\right\rangle
\ge\frac{|\langle g,A_{k,-}e_p\rangle|^2}{\langle g,A_{k,-}g\rangle}
\ge\left(\frac12+o(1)\right)\frac{\log^2p}{\log k}
=\left(\frac18+o(1)\right)\log k.
\]
证明 (2)。这里有限个半槽阶跃函数属于 \(D(A_{k,-})\)，其端点至多产生平方可积的对数奇性；\(P_X\) 有限秩且 \(\operatorname{ran}P_X\subset D(A_{k,-})\)，所以正算子的压缩逆度量变分合法。\(\square\)

## 边界

式 (1) 是真实旧核从 note 787 的整数半槽主空间到其无限维正交补的交叉范数下界；式 (2) 是在完整旧核严格正的条件下，对同一列的真实 Schur 反馈下界。二者都不确定最终物理 collar Schur 符号。全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 仍未判定。
