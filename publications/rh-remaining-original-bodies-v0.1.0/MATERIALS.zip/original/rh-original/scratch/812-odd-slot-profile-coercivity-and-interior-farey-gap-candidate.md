# 局部反对称槽轮廓的解析正下界与内部 Farey 谱隙（候选）

日期：2026-09-29。依赖 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的真实 Archimedean 单槽形式、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的算术图与槽间距，以及 [scratch 808](808-interior-farey-dipoles-have-a-sharp-growing-spectral-gap-candidate.md) 的内部常值偶极范围。以下论证只限局部反对称轮廓的有限族闭形式压缩；同模型独立复核未发现承重错误，尚缺异源复核。

## 命题

在 \((0,2)\) 上定义闭二次型
\[
\mathfrak b_2[h]=\frac14\int_0^2\!\int_0^2
\frac{|h(t)-h(s)|^2}{|t-s|}\,dt\,ds
-\frac12\int_0^2\log(t(2-t))|h(t)|^2dt.
\tag{1}
\]
对每个关于 \(t=1\) 反对称的有限能量轮廓 \(h(2-t)=-h(t)\)，有显式的统一下界
\[
\boxed{\mathfrak b_2[h]\ge(\log2)\|h\|_{L^2(0,2)}^2.}
\tag{2}
\]
因而与 note 791 的临界算术行常数配对后，理想内部单槽的剩余下界是严格正的常数
\[
\delta_*:=\gamma_E+\log(2/\pi)>0.
\tag{3}
\]

更具体地，令奇素数 \(p\to\infty\)、\(k=p^2\)、\(\Delta=\frac12\log(1+p^{-2})\)，并取整数 \(Q=Q(p)\to\infty\) 满足 \(Q/p\to0\)。对每个 \(x\in\mathcal F_Q\)，在 note 791 的两个物理中心 \(px,p/x\) 上放置**相同的局部反对称轮廓** \(h_x\in D(\mathfrak b_2)\)，并按全局奇反射配对。由这些轮廓组成的闭形式子空间记为 \(V_{p,Q}^{\rm oddprof}\)。那么真实完整旧奇算子的形式压缩满足
\[
\boxed{
A_{p^2,-}|_{V_{p,Q}^{\rm oddprof}}
\succeq\bigl(2\log(p/Q)-O(1)\bigr)I.}
\tag{4}
\]
特别地，该**整个局部反对称槽轮廓族**在上述量词下最终严格正，且谱隙趋于无穷。式 (4) 只约束这个主压缩，不约束它与正交补的 Schur 反馈。

## 反对称单槽不等式

令 \(f=h|_{(0,1)}\)，则 \(h(2-t)=-f(t)\)、\(\|h\|_2^2=2\|f\|_2^2\)。将 (1) 的双积分拆成同半槽与跨半槽两部分，得到
\[
\begin{aligned}
\mathfrak b_2[h]
={}&\frac12\int_0^1\!\int_0^1
\frac{|f(t)-f(s)|^2}{|t-s|}\,dt\,ds\\
&+\frac12\int_0^1\!\int_0^1
\frac{|f(t)+f(s)|^2}{2-t-s}\,dt\,ds
-\int_0^1\log(t(2-t))|f(t)|^2dt.
\end{aligned}
\tag{5}
\]
第一个双积分非负。把第二项展开，其对角部分为
\[
\int_0^1|f(t)|^2
\left(\int_0^1\frac{ds}{2-t-s}\right)dt
=\int_0^1\log\frac{2-t}{1-t}|f(t)|^2dt.
\tag{6}
\]
剩下的 Hankel 二次型也非负，因为
\[
\int_0^1\!\int_0^1
\frac{f(t)\overline{f(s)}}{2-t-s}\,dt\,ds
=\int_0^\infty
\left|\int_0^1e^{-u(1-t)}f(t)\,dt\right|^2du\ge0.
\tag{7}
\]
在光滑紧支撑的 \(f\) 上 (5)--(7) 均直接合法。式 (7) 的核在 \(x=1-t,y=1-s\) 下成为有界的 Carleman 核 \(1/(x+y)\)，因此 Hankel 项对 \(L^2\) 连续；再用闭形式的核心逼近延拓。把 (6) 与 (5) 的势相减，位置函数精确化为
\[
\log\frac{2-t}{1-t}-\log(t(2-t))
=-\log(t(1-t))\ge\log4.
\tag{8}
\]
更精确地，若 \(\mathfrak b_1\) 是 note 790 式 (5) 的单槽形式，则 (5)--(8) 给出直接分解
\[
\boxed{\mathfrak b_2[h]
=2\mathfrak b_1[f]
+\int_0^\infty\left|\int_0^1e^{-u(1-t)}f(t)\,dt\right|^2du.}
\tag{8a}
\]
因此 \(\mathfrak b_2[h]\ge(\log4)\|f\|_2^2=(\log2)\|h\|_2^2\)，证明 (2)。由于标准常数满足 \(\gamma_E>\log(\pi/2)\)，(3) 严格正。

## 内部 Farey 局部反对称轮廓压缩

取任一局部反对称轮廓 \(h(t)\) 并使 \(\|h\|_{L^2(0,2)}=1\)。在物理中心 \(z\) 的宽 \(2\Delta\) 槽上，用 \(u=\log z-\Delta+\Delta t\) 定义 \(\phi_z^h(u)=\Delta^{-1/2}h(t)\)。局部反对称使 \(\int\phi_z^h=0\)，且全局反射把 \(\phi_{px}^h\) 送成 \(-\phi_{p/x}^h\)。故
\[
w_x^h=\frac{\phi_{px}^h+\phi_{p/x}^h}{\sqrt2}
\tag{9}
\]
属于旧奇空间。不同 \(x\in\mathcal F_Q\) 的物理槽不相交，所以 \(h=(h_x)_x\mapsto\sum_xw_x^{h_x}\) 是 \(\bigoplus_{x\in\mathcal F_Q}L^2_{\rm odd}(0,2)\) 到 \(V_{p,Q}^{\rm oddprof}\) 的等距同构，形式域逐坐标取 \(D(\mathfrak b_2)\)。

note 790 式 (3)--(5) 对宽 \(2\Delta\) 的整个物理槽给出位置无关的**精确**局部奇异 Archimedean 形式
\[
\bigl(\log(1/\Delta)-\log(2\pi)-\gamma_E\bigr)\|h_x\|_2^2
+\mathfrak b_2[h_x].
\tag{10}
\]
正则 gamma 核在同槽上的范数为 \(O(\Delta)\)。由 \(\log(1/\Delta)=2\log p+\log2+o(1)\) 及 (2)，(10) 的逐槽下界为
\[
\bigl(2\log p+\log(2/\pi)-\gamma_E-o(1)\bigr)\|h_x\|_2^2.
\tag{11}
\]
同一 \(x\) 的两个物理中心以及不同 \(x\) 的物理中心最小间距满足 \(\delta_{p,Q}\gg Q^{-2}\)。两槽轮廓均零均值，note 791 的 \(|K''(d)|\ll d^{-3}\) 与双零矩给任意两个相离槽的交叉块范数 \(O(\Delta^3/d^3)\)。按中心排序后，全部非对角 Archimedean 块的绝对行和为
\[
O\!\left((\Delta/\delta_{p,Q})^3\right)
=O\!\left((Q/p)^6\right)=o(1).
\tag{12}
\]

note 791 的整数间距论证还保证：每个素数幂平移只在两个物理中心**精确重合**时才有压缩矩阵元。平移保持轮廓的相对坐标；由于两个物理中心采用相同的局部反对称轮廓，比值边、乘积边及自环的系数均与常值偶极相同。因此算术压缩精确为
\[
\mathcal R_{p^2}|_{V_{p,Q}^{\rm oddprof}}=-C_Q\otimes I_{L^2_{\rm odd}(0,2)},
\tag{13}
\]
其中 \(C_Q\) 是 note 791 的非负 Farey 算术矩阵在 \(\mathcal F_Q\) 上的主块。其正权行恒等式与经典 \(\sum_{n\le x}\Lambda(n)/n=\log x+O(1)\) 给出 \(\|C_Q\|\le2\log Q+O(1)\)。

最后，\(s_k\) 在这些小槽上是光滑函数；局部反对称的零均值及 \(\sup|s_k'|=O(p^{1/2})\) 给每个槽投影 \(O(p^{1/2}\Delta^{3/2})\)。\(|\mathcal F_Q|=O(Q^2)\) 导致
\[
\|P_{V_{p,Q}^{\rm oddprof}}s_k\|^2
=O(Q^2p\Delta^3)=O(Q^2/p^5)=o(1).
\tag{14}
\]
合并 (11)--(14) 与负 polar 项，得到 (4)。\(\square\)

## 边界

(2) 是完整 Archimedean 单槽形式的无限维反对称轮廓不等式，严格保留了跨半槽 Hankel 正项。式 (4) 将 scratch 808 的内部 Farey 常值偶极增长谱隙扩展到每槽全部有限能量的局部反对称轮廓。它不控制局部偶对称轮廓、外圈 Farey 空间或整个无限维正交补，因此不证明完整局部 Weil 正性或 RH；moving-\(N\) Möbius signed covariance 界也仍未解决。
