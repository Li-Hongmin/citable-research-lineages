# 候选：深分子内区与 polar 主质量外区可联合支付真实算术交叉

日期：2026-09-30。证明草稿，尚待独立复核。依赖 [note 810](../notes/810-three-growing-gap-blocks-cover-all-farey-constant-slots.md) 的固定斜率外区谱隙、[note 809](../notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md) 的全小分子谱隙证明、[note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md) 的有序互素对展开与跨指数零点余项、[note 811](../notes/811-nonarithmetic-cross-blocks-are-paid-in-full-farey-constant-slots.md) 的常值槽核交叉界，以及 [note 806](../notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md) 的全阶跃混合界。

## 命题

沿奇素数 \(p\to\infty\)，记 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定
\[
r>\frac2{1-3/\pi^2},\qquad
\gamma_r=1-\frac2r-\frac3{\pi^2}>0.
\tag{1}
\]
固定 \(\eta>0\)，令整数 \(2\le S_p\le Q\) 满足
\[
L_p:=\log(P/S_p),\qquad
L_p\ge\left(\frac1{\gamma_r}+\eta\right)\log H.
\tag{2}
\]
令 \(I_{S_p}=\operatorname{span}\{\psi_{a/b}:a\le S_p\}\) 为全部斜率的深内区常值奇槽，令 \(E_r=\operatorname{span}\{\psi_{a/b}:a>Q,\ a/b>r\}\) 为 note 810 的 polar 主质量外区。则两块不交，且**保留两块之间真实带符号素数幂边**的联合旧奇 Weil 主压缩满足
\[
\boxed{\quad
P_{I_{S_p}\oplus E_r}A_{p^2,-}P_{I_{S_p}\oplus E_r}
\succeq \bigl(2\eta-o_{r,\eta}(1)\bigr)\log H\,I
\quad}
\tag{3}
\]
对充分大的 \(p\) 成立。进一步，与全部 Farey 阶跃偶极 \(W_p\) 联合后仍有
\[
P_{W_p\oplus I_{S_p}\oplus E_r}A_{p^2,-}
P_{W_p\oplus I_{S_p}\oplus E_r}
\succeq(c_0-o(1))I,
\quad c_0=1+\gamma_E-\log\pi+\delta_0>0.
\tag{4}
\]
特别地，取 \(r=4\)、\(S_p=\lfloor P/H^6\rfloor\) 即满足 (2)：\(\pi>3\) 给 \(\gamma_4=1/2-3/\pi^2>1/6\)，所以 \(6>1/\gamma_4\)。更深的 \(S_p=\lfloor P\exp[-(\log H)^2]\rfloor=p^{1-o(1)}\) 也满足 (2)。

## 内区与外区对角

note 791 式 (14) 的正权行界在完整 Farey 集 \(\mathcal F_{S_p}\) 上给 \(\|C^-_{II}\|\le2\log S_p+O(1)\)。note 809 式 (12) 的同一间距计算因 \(S_p\le Q\) 给 \(\|N_{II}\|=O(H^{-1})\)，其式 (10) 给 \(\|h_I\|^2=O(H^{-1})\)。丢去正的异臂 Archimedean 矩阵后，
\[
A_{II}\succeq
\bigl(2H-2\log S_p-O(1)\bigr)I
=\bigl(2L_p-O(1)\bigr)I.
\tag{5}
\]
note 810 对 \(E_r\) 给
\[
A_{EE}\succeq\bigl(\gamma_rH-O_r(\sqrt H\log H)\bigr)I.
\tag{6}
\]
两式的证明都已将正的异臂 Archimedean 矩阵丢去，因此下文可在整个两块上一次丢去它，包括其交叉条目。

## 真实算术交叉的矩形上界

对 note 803 的有序互素对图，令
\[
(J_-f)_{a,b}=\frac{\operatorname{sgn}(a-b)}{\sqrt2}
f_{\max(a/b,b/a)}.
\]
四种有序配对直接给 \(J_-^*BJ_-=C_{\parallel}-C_{\times}=C^-\)；\(J_-\) 是等距映射。note 803 式 (5)--(6) 把非负有序图 \(B\) 逐项支配为单坐标矩阵 \(K_P\otimes I+I\otimes K_P\) 加跨指数零点余项，后者全图范数为 \(O(\log H)\)。这里 \(K_P(m,n)=c_{m/n}+c_{n/m}\)，\(c_t=\Lambda(t)/\sqrt t\) 于整数素数幂，其他为零。

置 \(L=\{1,\ldots,S_p\}\)、\(U=\{Q+1,\ldots,P\}\)。内区有序端点属于 \(L\times L\)，外区有序端点至少一个坐标属于 \(U\)。单坐标边从 \(L\times L\) 只能到 \((U\times L)\sqcup(L\times U)\)，两块正交；故其矩形范数至多 \(\sqrt2\kappa\)，其中 \(\kappa=\|K_{U,L}\|\)。带符号矩阵的绝对值逐项受上述非负图支配，因而
\[
\|C^-_{EI}\|\le\sqrt2\kappa+O(\log H).
\tag{7}
\]

取一维权 \(v_m=m^{-1/2}\)。对 \(a\in U\)，只有 \(c=a/n\in L\) 的整素数幂除法边，故
\[
\frac{(K_{U,L}v_L)_a}{v_a}
=\sum_{\substack{n\mid a,\ n\text{ 为素数幂}\\a/n\le S_p}}\Lambda(n)
\le\log a\le H.
\tag{8}
\]
对 \(c\in L\)，只有 \(a=cn\in U\) 的乘法边，故
\[
\frac{(K_{L,U}v_U)_c}{v_c}
=\sum_{Q/c<n\le P/c}\frac{\Lambda(n)}n
=M(P/c)-M(Q/c)
\le\log(P/Q)+O(1)=\log H+O(1),
\tag{9}
\]
其中 \(M(t)=\sum_{n\le t}\Lambda(n)/n=\log t+O(1)\) 一致适用于 \(t\ge1\)。矩形加权 Schur 检验给
\[
\kappa^2\le H(\log H+O(1)),
\qquad
\|C^-_{EI}\|\le(\sqrt2+o(1))\sqrt{H\log H}.
\tag{10}
\]

## 核与 polar 交叉，以及配方

把 \(I_{S_p}\) 按 \(x\le r\)、\(x>r\) 拆开。note 811 式 (7) 对前块与 \(E_r\) 给 \(O_r(1)\) 的 \(N\) 混合界；式 (11) 对后块作为 \(J_r\) 的子空间也给 \(O_r(1)\)。因此 \(\|N_{EI}\|=O_r(1)\)。由 \(\|h_I\|^2=O(H^{-1})\)、\(\|h_E\|^2=O(H)\)，polar 交叉范数也为 \(O_r(1)\)。在全局丢去正的异臂 Archimedean 矩阵后，(10) 遂给真实剩余交叉
\[
\|X_{EI}\|\le(\sqrt2+o(1))\sqrt{H\log H}.
\tag{11}
\]

令 \(g_E=\gamma_rH-O_r(\sqrt H\log H)=(\gamma_r-o_r(1))H\)。由 (11)，
\[
\frac{\|X_{EI}\|^2}{g_E}
\le\left(\frac2{\gamma_r}+o_r(1)\right)\log H,
\qquad
\frac{\|X_{EI}\|}{g_E}=O_r\!\left(\sqrt{\frac{\log H}{H}}\right)=o(1).
\tag{12}
\]
对 \(f=f_I+f_E\) 完成平方，并把正的异臂 Archimedean 矩阵全局丢去，得
\[
A[f]\ge
\left(2L_p-O(1)-\frac{\|X_{EI}\|^2}{g_E}\right)\|f_I\|^2
+g_E\left\|f_E+g_E^{-1}X_{EI}f_I\right\|^2.
\tag{13}
\]
式 (2)、(12) 使第一系数至少 \((2\eta-o_{r,\eta}(1))\log H\)；第二系数为 \(\asymp_r H\)。因 (12) 的坐标变换与恒等映射相差 \(o(1)\) 的算子范数，(13) 在原始 \(\|f_I\|^2+\|f_E\|^2\) 范数中仍给 (3)。

note 806 对全常值槽与 \(W_p\) 的真实混合范数给 \(O(1)\)，note 804 给 \(A_{W_p}\succeq(c_0-o(1))I\)。式 (3) 的联合常值槽谱隙趋于无穷；完成平方的阶跃 Schur 损失趋零，证明 (4)。\(\square\)

## 边界

此结果首次对一个增长的深内区与 polar 主质量外区同时保留并支付真实算术交叉。它没有覆盖 \(S_p<a\le Q\) 的临界分子边界层、所有 \(x\le r\) 的高分子槽、剩余常值槽间的联合耦合、槽内其余轮廓或无限维补空间；因此不推出完整常值槽正性、全尺度 Weil 正性或 RH。
