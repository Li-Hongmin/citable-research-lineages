# 真实两端点系数的任意物理位移带均有次指数 signed 抵消

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的式 (10)–(18) 与 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的 Ramachandra 输入。本稿对**完整三通道系数**的每个物理位移带直接估计，不按源 gcd 分层。仍无固定幂节省；待异源复核。

## 定理

固定 $\psi\in C_c^3((1,2))$ 和非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，其中 $\operatorname{supp}\eta\subset\{1/2\le|t|\le4\}$，且 $\eta\ge1$ 于 $1\le|t|\le2$。令 $M=2Y\to\infty$、$Y^{1/5}\le H\le Y^{1/4}$、$V_M=(\log M/\log\log M)^{1/3}$。采用真实系数
\[
c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)-4\{\Lambda(m)-1+(\log2)\mu(m)\},\qquad
a_m=\frac{c(m)}m\psi(m/M),
\tag{1}
\]
并在 $M<m<2M$ 以外置 $a_m=0$。设 $J_H(r)=\sum_h\eta(h/H)e(-hr/M)$。对可随 $M,H$ 任意变化的 $0\le T<U\le M$，置
\[
\mathcal Q_H^{(T,U]}
=\sum_{T<|m-n|\le U}a_m\overline{a_n}J_H(m-n).
\tag{2}
\]
任取固定 $0<\varepsilon<1/60$，令 $\vartheta=7/12+\varepsilon<3/5$。则某个固定 $c>0$ 使
\[
\boxed{\quad
\sup_{0\le T<U\le M}|\mathcal Q_H^{(T,U]}|
\ll_{\psi,\eta,\varepsilon}e^{-cV_M}+H M^{\vartheta-1}.
\quad}\tag{3}
\]
而后一项已严格低于目标：
\[
H M^{\vartheta-1}
\ll_\varepsilon (H^4/M)M^{\vartheta-3/5}
=o(H^4/M)
\tag{4}
\]
一致于整个 $H$ 范围。故 (3) 未付的只有次指数项；在 $H\asymp M^{1/5}$，它仍大于 $H^4/M\asymp M^{-1/5}$。

## 证明

note 851 引用的 Ramachandra 定理允许在幂次余项 $x^{7/12+\varepsilon}$ 中取任意固定 $\varepsilon>0$。将其分别用于 $\Lambda-1$ 与 $\mu$，偶数项以 $m=2n$ 换元，端点取整的 $O(\log M)$ 吸收到 $M^\vartheta$，得到对每个整数区间 $I\subset[M,2M]$ 一致的
\[
\left|\sum_{m\in I}c(m)\right|
\ll_\varepsilon |I|e^{-c_0V_M}+M^\vartheta .
\tag{5}
\]
Chebyshev 一阶质量和 $|\mu|\le1$ 另给 $\sum_m|a_m|\ll_\psi1$。

记 $\Phi(x)=\psi(x)/x$、$W=M/H$。$\Phi$ 紧支撑于 $(1,2)$，所以在 $\Phi(m/M)\Phi(n/M)\ne0$ 的实际区域有 $|m-n|\le(1-\sigma_\psi)M$。Poisson 求和与 $\eta$ 的光滑性对任意固定 $A>3$ 给
\[
|J_H(m-t)|\ll H(1+H|m-t|/M)^{-A},\quad
\left|\frac{d}{dt}J_H(m-t)\right|
\ll \frac{H^2}{M}(1+H|m-t|/M)^{-A},
\tag{6}
\]
只在 $\Phi(t/M)$ 或其导数非零的实际区域使用；非零周期别名距零至少固定倍数的 $H$，可取更高 Fourier 衰减阶数吸收。

固定 $m$，将 $|m-n|\le W$ 作为第零壳，将 $2^{j-1}W<|m-n|\le2^jW$ 作为第 $j$ 壳。每壳与位移带及 $[M,2M]$ 相交，在 $n$ 轴上至多形成四个整数区间，各长 $O(2^jW)$。在每段上设 $f_m(t)=\overline{\Phi(t/M)}J_H(m-t)$。由 (6)，连同带端点的跳跃，
\[
\|f_m\|_\infty+\operatorname{Var}(f_m)
\ll_{\psi,\eta,A} H2^{-j(A-1)}.
\tag{7}
\]
其中 $J_H'$ 的积分至多为 $(2^jW)(H^2/M)2^{-jA}=H2^{-j(A-1)}$，$\Phi'$ 项更小；$\Phi$ 的零值间隙不需另切区间。

任一此类区间的任意前缀由 (5) 至多为
$O_\varepsilon(2^jW e^{-c_0V_M}+M^\vartheta)$。离散 Abel 求和及 (7) 后，对壳求和，因 $A>3$ 有
\[
\left|\sum_{T<|m-n|\le U}c(n)\overline{\Phi(n/M)}J_H(m-n)\right|
\ll M e^{-c_0V_M}+H M^\vartheta .
\tag{8}
\]
该界对 $m,T,U,H$ 一致。内层乘 $M^{-1}$，外层以 $\sum|a_m|\ll1$ 取绝对值，即得 (3)。由 $H\ge Y^{1/5}\asymp M^{1/5}$ 和 $\vartheta<3/5$ 得 (4)。$\square$

## 边界

$T=0,U=M$ 包含所有非对角物理对；对角由 note 849 式 (16) 以 $O(H\log M/M)=o(H^4/M)$ 支付。此定理比 note 851 的总频带界多了**任意物理位移带**的一致性，并将 Ramachandra 幂次余项在目标内单独支付。它没有利用 $\mu$ 的二点结构，故不把 $e^{-cV_M}$ 提升为固定幂。[scratch/953](953-every-displacement-band-of-the-complete-two-arm-source-gram-has-subexponential-cancellation.md) 另处理源分解后的不同源子和；物理带和 (2) 不自动界定该子和。后者逐乘子取绝对值时，即使把短和幂次逼近 $7/12$，在 $H\asymp M^{1/5}$ 仍只到 $M^{-2/15+o(1)}$；式 (4) 显示先精确重组成 $c(m)$ 可支付这项幂次余量，留下真正的次指数主误差。
