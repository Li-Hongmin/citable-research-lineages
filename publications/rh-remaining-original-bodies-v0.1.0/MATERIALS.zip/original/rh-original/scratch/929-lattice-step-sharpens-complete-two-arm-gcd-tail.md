# 保留物理乘子格距后，完整两臂 Gram 的共同因子尾界

日期：2026-10-02。依赖 [scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 的完整奇数源正规形与小既约比例支付、[scratch/928](928-large-gcd-tail-of-the-complete-odd-source-two-arm-gram.md) 式 (4)--(7) 的乘子展开和频带核衰减。本文改进 928 的大共同因子估计；尚未控制留下的小共同因子 signed 和，亦不证明 RH。独立复核后的自足版本见 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md)。

## 命题

沿用 928 的记号：$M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$D=\lfloor M/(32H)\rfloor$，$R=\lfloor H^2/\log^4M\rfloor$，$\psi\in C_c^3((1,2))$，$\phi(x)=\psi(x)/x$，$\eta\in C_c^2(\mathbb R)$ 是固定非负偶函数，$w_H(h)=\eta(h/H)$；$G_{u,v}$ 为 928 式 (1) 的完整奇数源两臂 Gram。令 $g=(u,v)$、$a=u/g$、$b=v/g$。对任意 $G_0\ge1$，

\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd},\ u\ne v\\
\max(a,b)>R,\ g>G_0}} |G_{u,v}|
\ll_{\psi,\eta}
\frac{\log^4(2M)}{G_0}
+\frac{H^2\log^4(2M)}{M}.
\quad}                                                     \tag{1}
\]

特别取
\[
G_\natural=\left\lceil\frac{M\log^4(2M)}{H^4}\right\rceil.
\tag{2}
\]
则 926 式 (9) 的完整不同源 signed 协方差满足
\[
\boxed{\quad
\mathfrak C_{\mathrm{odd}}=
\sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd},\ u\ne v\\
(u,v)\le G_\natural}}
\mu(u)\mu(v)G_{u,v}
+O_{\psi,\eta}(H^4/M).
\quad}                                                     \tag{3}
\]
对充分大的 $M$，式 (3) 的留存对自动有 $a,b>R$。在 $H\asymp M^{1/5}$ 的端点，留存共同因子由 928 的 $O(M^{2/5}\log^2M)$ 缩为 $O(M^{1/5}\log^4M)$；在 $H\asymp M^{1/4}$ 时由 $O(M^{1/4}\log^2M)$ 缩为 $O(\log^4M)$。对数因子未优化。

## 证明

928 式 (4)--(7) 将两臂合成 $k<64H$ 的物理乘子，满足 $|W(k)|\ll\log(2H)$，并给出
\[
|J_H(g(ka-\ell b))|
\ll_{\psi,\eta} H
\left(1+\frac{Hg}{M}|ka-\ell b|\right)^{-2}.
\tag{4}
\]
这里 $kag,\ell bg$ 都在 $M\operatorname{supp}\phi$；紧支撑保证频率核远离非零整数别名。若 $(a,b)=1$ 且 $ka=\ell b$，则 $a\mid\ell$、$b\mid k$，故 $\max(a,b)<64H<R$，与式 (1) 的条件相矛盾。以下可在放宽整数计数时包括精确碰撞，因为只会增大上界。

用到的格距估计是：任意 $x\in\mathbb R$、$s>0$，
\[
\sum_{n\in\mathbb Z}(1+s|x-n|)^{-2}
\ll 1+s^{-1}.
\tag{5}
\]
证明是取最靠近 $x$ 的整数，贡献至多 $1$；其余整数按到 $x$ 的距离排序，每侧第 $j$ 个的距离至少 $j-1/2$，于是用积分比较 $\sum_{j\ge1}(1+s(j-1/2))^{-2}\ll1+s^{-1}$。将 (5) 用于 $x=ka/\ell$、$s=Hg\ell/M$，固定 $g,k,\ell,a$ 后，**保留 $b$ 的格距 $\ell$**，得到
\[
\sum_{b\in\mathbb Z}
\left(1+\frac{Hg}{M}|ka-\ell b|\right)^{-2}
\ll 1+\frac{M}{Hg\ell}.
\tag{6}
\]

因为 $\max(a,b)>R$ 且 $u,v<2M/3$，有 $g<2M/(3R)$。对固定 $g,k$，由 $kag\in M\operatorname{supp}\phi$，$a$ 落在长 $O_\psi(M/(kg))$ 的区间。又 $k<64H$，所以 $M/(kg)\gg R/H\to\infty$；整数 $a$ 的个数亦为 $O_\psi(M/(kg))$。在 928 式 (6) 中先按三角不等式展开乘子，再对固定 $g,k,\ell$ 用 (4)、(6) 求和，得
\[
\begin{aligned}
\sum_{\substack{a,b:\ (a,b)=1,\ ag,bg\ \mathrm{admissible}\\
\max(a,b)>R}}
|\text{$(k,\ell)$ 对 $G_{ag,bg}$ 的贡献}|
&\ll_{\psi,\eta}
\frac{H|W(k)W(\ell)|}{M^2}
\frac{M}{kg}\left(1+\frac{M}{Hg\ell}\right)\\
&=|W(k)W(\ell)|
\left(\frac{H}{Mkg}+\frac1{k\ell g^2}\right).
\end{aligned}                                                \tag{7}
\]
放宽 $b$ 的奇性、互素性及物理窗口均合法；只在真实活动项上使用 (4)。设
\[
A_H=\sum_{k<64H}\frac{|W(k)|}{k}\ll\log^2(2H),
\qquad
B_H=\sum_{k<64H}|W(k)|\ll H\log(2H).
\tag{8}
\]
由 (7) 对 $k,\ell$ 求和，固定 $g$ 的绝对质量至多
\[
\ll_{\psi,\eta}
\frac{A_H^2}{g^2}+\frac{H A_HB_H}{Mg}
\ll_{\psi,\eta}
\frac{\log^4(2H)}{g^2}
+\frac{H^2\log^3(2H)}{Mg}.
\tag{9}
\]
最后仅对 $G_0<g<2M/(3R)$ 求和，使用
$\sum_{g>G_0}g^{-2}\ll G_0^{-1}$ 及
$\sum_{g\le2M/(3R)}g^{-1}\ll\log(2M)$，即得 (1)。

由 926 式 (10)，全部 $\max(a,b)\le R$ 的不同源对绝对贡献为
$O_{\psi,\eta}(H^4/(M\log^2M))$。取 (2) 时，(1) 的首项是 $O(H^4/M)$；第二项也为 $O(H^4/M)$，因为 $H\gg\log^2M$。另外
\[
\frac{D}{G_\natural}
\gg\frac{H^3}{\log^4(2M)}
>R
\tag{10}
\]
对充分大的 $M$ 成立。因此 $g\le G_\natural$、$u,v>D$ 已强迫 $a,b>R$，组合两段绝对支付得到 (3)。$\square$

## 边界

式 (1) 同时覆盖 $k=\ell$ 与 $k\ne\ell$，但 928 式 (13) 对同一乘子的尾项仍更强。指数改进来自 (6) 保留 $\ell$ 格距，并未使用 $\mu$ 的符号。小共同因子层仍含非零物理位移的两仿射 Möbius 相关与频带核的正负瓣；式 (3) 只缩小真正需要 signed 估计的范围。全尺度局部 Weil 正性和 moving-$N$ 目标界仍开放。
