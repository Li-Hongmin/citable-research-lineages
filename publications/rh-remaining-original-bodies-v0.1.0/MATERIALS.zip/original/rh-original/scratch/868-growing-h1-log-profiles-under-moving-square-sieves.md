# 任意移动平方筛下增长 \(H^1\) 对数轮廓的候选正隙

后续 [scratch 874](874-linear-logarithmic-fourier-profile-weil-gap.md) 利用指数权筛求积与可积的加权素数定理余项，把三角多项式子空间的候选频宽从 \(J\asymp\sqrt{\log p}\) 推到 \(J\asymp\log p\)；两项均未异源复核。

日期：2026-10-02。依赖 [note 864](../notes/864-moving-square-sieve-log-profiles-have-finite-dimensional-weil-gap.md)、[note 862](../notes/862-arbitrary-moving-prime-square-sieves-retain-maximal-weil-gap.md) 与 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)。这是对先前固定有限维结论的解析加强；**尚无异源独立复核，不晋级为永久定理**。

沿这些 notes 的奇素数 \(p\)、最大整数格、任意移动素数平方筛及固定 \(0<c<4\)、实单位槽轮廓 \(\varphi\)，记
\[
M=(p^2-5)/4,\quad L=\log M,\quad
\alpha_p=\prod_{q\in\mathcal P_p}(1-q^{-2})
\ge\alpha_0=\zeta(2)^{-1},\quad
\delta=46/25-\log(2\pi)>0.
\]
对复值 \(g\in H^1[0,1]\) 使用连续代表在 \(t_n=\log n/L\) 处取值，令 \(a=\int_0^1g(t)\,dt\)、\(h=g-a\)。把 note 864 的格函数先**不除以**范数 \(\sqrt{W(g)}\)，记其完整 Weil 形式为 \(\mathscr Q(g)\)，平方范数为
\[
W(g)=\sum_{n\le M}\frac{T_p(n)|g(t_n)|^2}{n}.
\]

## 待复核命题

存在只依赖 \(c,\varphi\) 的固定 \(\kappa>0,p_0\)，使一切奇素数 \(p\ge p_0\)、一切筛集合和一切非零 \(g\in H^1[0,1]\) 在
\[
\boxed{\quad \|h'\|_2^2\le\kappa L\|h\|_2^2 \quad}
\tag{1}
\]
下满足 \(W(g)>0\) 与
\[
\boxed{\qquad \mathscr Q(g)/W(g)\ge\delta\alpha_0/16>0.\qquad}
\tag{2}
\]
当 \(h=0\) 时 (1) 自动成立。特别地，若
\[
g_p(t)=a_p+\sum_{1\le |j|\le J_p}c_{j,p}e^{2\pi ijt},
\qquad
J_p\le\frac{\sqrt{\kappa L}}{2\pi},
\tag{3}
\]
则全部系数可随 \(p\) 与筛任意变化；取 \(J_p=\lfloor\sqrt{\kappa L}/(2\pi)\rfloor\) 时，(2) 同时覆盖维数 \(2J_p+1\asymp\sqrt{\log p}\) 的轮廓空间。

## 一致的 \(H^1\) 余项

关键是存在与 \(g,p,\mathcal P_p\) 无关的 \(C\)，使
\[
\begin{aligned}
|W(g)-\alpha_pL\|g\|_2^2|&\le C\|g\|_{H^1}^2,\\
\mathscr Q(g)&=\alpha_pL^2\|g-\bar g\|_2^2+\mathscr E(g),
\qquad |\mathscr E(g)|\le CL\|g\|_{H^1}^2.
\end{aligned}
\tag{4}
\]
下面逐项核准此处较 note 864 强的统一量词。

note 862 的计数式 \(A_p(x)=\alpha_px+O(\sqrt x)\) 对所有移动筛一致。对绝对连续的 \(F\)，对 \(F(\log x/L)/x\) 作 Abel 求和给
\[
\left|
\sum_{n\le M}\frac{T_p(n)}nF(t_n)
-\alpha_pL\int_0^1F(t)\,dt
\right|
\le C\bigl(\|F\|_\infty+\|F'\|_1\bigr).
\tag{5}
\]
确实误差积分分别由 \(\int_1^\infty x^{-3/2}dx\) 及
\(\int_0^1 e^{-Lt/2}|F'(t)|dt\) 控制。对 \(F=|g|^2\)，一维 Sobolev 嵌入及 Cauchy--Schwarz 给右端 \(O(\|g\|_{H^1}^2)\)，证明 (4) 第一式。

由 note 854 的 \(\sum_{k\le x}\Lambda(k)/k=\log x+O(1)\)，note 864 式 (5) 的 Stieltjes 分部积分对所有 \(g\in H^1\) 一致有误差
\[
O(\|g\|_\infty+\|g'\|_1)=O(\|g\|_{H^1}).
\tag{6}
\]
乘外层的 \(\sum T_p(n)|g(t_n)|/n\ll L\|g\|_{H^1}\)，只损失 \(O(L\|g\|_{H^1}^2)\)。note 864 式 (7)--(8) 中将 \(T_p(kn)\) 换为 \(T_p(n)\) 的误差也至多 \(CL\|g\|_\infty^2\)。随后对
\(F(t)=\overline{g(t)}\int_t^1g(s)\,ds\) 用 (5)；它是绝对连续的，且 \(\|F\|_\infty+\|F'\|_1\ll\|g\|_{H^1}^2\)。因此未归一化的素数幂整除二次型为
\[
\alpha_pL^2|\bar g|^2+O(L\|g\|_{H^1}^2).
\tag{7}
\]

同槽 Fourier 项为 \(\log(1/\ell)W(g)+O(W(g))\)，且 \(\log(1/\ell)=L+O_c(1)\)。note 857 的普通跨槽中心核绝对和为 \(O(ML\|g\|_\infty^2)\)，乘 \(\ell\) 后是 \(O(L\|g\|_{H^1}^2)\)；中心替换误差至多 \(O(\ell^2M^2\|g\|_\infty^2)=O(\|g\|_{H^1}^2)\)。两个 polar 矩分别至多 \(L\|g\|_\infty\)、\(M\|g\|_\infty\)，其乘积再乘 \(\ell\) 也是 \(O(L\|g\|_{H^1}^2)\)。合并 (4) 第一式与 (7)，得到 (4) 第二式。上述论证先对 \(C^1\) 函数成立，再由 \(H^1[0,1]\hookrightarrow C^0[0,1]\) 和稠密性延拓；固定 \(p\) 时格函数是有限和。

## 常数模与均值零模的联合支付

\(\mathscr E\) 是 Hermitian 二次型。由 (4) 及极化，其双线性形式满足
\[
|\mathscr E(u,v)|\le CL\|u\|_{H^1}\|v\|_{H^1}.
\tag{8}
\]
note 862 的任意移动筛常数轮廓正隙及 (4) 第一式给充分大 \(p\) 时
\[
\mathscr Q(a)\ge(\delta\alpha_0/4)L|a|^2.
\tag{9}
\]
又因 \(\|h\|_{H^1}^2=\|h\|_2^2+\|h'\|_2^2\)，由 (1)、(4) 及适当小的 \(\kappa\) 得
\[
\mathscr Q(h)\ge(\alpha_0/2)L^2\|h\|_2^2.
\tag{10}
\]
主项 \(\alpha_pL^2\|g-\bar g\|_2^2\) 在常数与均值零空间间没有交叉。由 (8) 和 Young 不等式，
\[
2|\mathscr Q(a,h)|
\le 2CL|a|\sqrt{1+\kappa L}\,\|h\|_2
\le(\alpha_0/4)L^2\|h\|_2^2
+O(\kappa L)|a|^2
\tag{11}
\]
对充分大的 \(L\) 成立。先选 \(\kappa\) 使 (10) 成立，再缩小它使 (11) 中 \(O(\kappa L)|a|^2\) 至多为 \((\delta\alpha_0/8)L|a|^2\)。于是
\[
\mathscr Q(a+h)\ge
(\delta\alpha_0/8)L|a|^2
+(\alpha_0/4)L^2\|h\|_2^2.
\tag{12}
\]
最后 (4) 第一式及同样小的 \(\kappa\) 给
\[
(\alpha_0/2)L\|g\|_2^2\le W(g)\le2L\|g\|_2^2.
\tag{13}
\]
式 (12)--(13) 推出 (2)。对 (3) 的 \(h\)，Parseval 给
\(\|h'\|_2^2\le(2\pi J_p)^2\|h\|_2^2\)，所以 (1) 成立。 \(\square\)

## 边界

式 (2) 只处理上述最大整数格、共同槽轮廓及满足 (1) 的宏观对数调制。它不控制任意槽系数、素数赋值符号、补空间 Schur 反馈或完整 moving-\(N\) signed covariance，也不证明全尺度局部 Weil 正性。承重新增点是 (4) 对全部 \(H^1\) 函数的统一常数，尤其是中心替换与 polar 项；异源复核前保持候选状态。
