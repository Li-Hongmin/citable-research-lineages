# 移动高度零点波包对两端点带通门的驻相门槛

日期：2026-10-03。问题来自
[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md)
式 (9)、(15) 的真实固定幂目标，以及
[scratch 967](967-selberg-window-variance-is-stronger-than-the-k2-bandpass-gate.md)
的**固定高度**复幂光滑模型。下面只是一项解析波包判定：
模型不是实际 $\Lambda$–Möbius 系数，也不主张任何 zeta 零点存在。
解析推导尚未异源复核，故留在 scratch。

## 命题

固定 $1/5\le\gamma<1/4$、$1/2<\beta<1$，
令 $H=M^\gamma$、$M\to\infty$ 沿整数。
固定非负非零 $\phi\in C_c^\infty((1,2))$，
以及非负偶 $\eta\in C_c^\infty(\mathbb R)$，
其支撑包含于 $1/2\le|t|\le4$，且
$\eta\ge1$ 于 $1\le|t|\le2$。
选取 $\phi(x_0)>0$ 的 $x_0\in(1,2)$ 和固定
$t_0\in(1,2)$，令
\[
u_0=x_0t_0,\qquad \tau_M=2\pi u_0H,\qquad
\rho_M=\beta+i\tau_M,\qquad
A_h(M)=\sum_{m\ge1}m^{\rho_M-2}\phi(m/M)e(-hm/M).
\tag{1}
\]
则有精确能量首项
\[
\boxed{\qquad
\sum_{h\in\mathbb Z}\eta(h/H)|A_h(M)|^2
=M^{2\beta-2}\left[
\int_1^2\eta(u_0/x)x^{2\beta-4}\phi(x)^2\,dx+o(1)
\right].
\qquad}\tag{2}
\]
其中积分严格为正。
因此在 note 849 的目标量级 $H^4/M=M^{4\gamma-1}$ 下，
单个这种波包的能量比值为
\[
\asymp M^{\,2\beta-1-4\gamma}.
\tag{3}
\]
当 $\gamma=1/5$ 时，临界实部是 $\beta=9/10$：
$\beta>9/10$ 的单个波包已经超过目标一个固定幂。

## 证明

置 $g_\beta(x)=x^{\beta-2}\phi(x)$ 和
$S_{h,M}(x)=\tau_M\log x-2\pi hx$。
Poisson 求和给
\[
A_h(M)=M^{\rho_M-1}
\sum_{j\in\mathbb Z}
\int_0^\infty g_\beta(x)
\exp\!\left(i\tau_M\log x-2\pi i(h+jM)x\right)dx.
\tag{4}
\]
在 $\eta(h/H)\ne0$ 的 $O(H)$ 个 $h$ 上，$h\asymp H$。
对 $j\ne0$，相位导数的绝对值 $\gg |j|M$，
因为 $\tau_M\asymp H=o(M)$、$x\in\operatorname{supp}\phi$；
重复分部积分后，对任意固定 $A>2$，
所有 $j\ne0$ 的积分合计为 $O_A(M^{-A})$，
一致于这些 $h$。下面计算 $j=0$ 的首项。对 $h>0$
且 $t=h/H$ 落在 $\eta$ 支撑内，唯一可能的驻点是
\[
x_h=\frac{\tau_M}{2\pi h}
=\frac{u_0}{t}.
\]
把 $\phi$ 在 $(1,2)$ 外以零延拓。
在 $t$ 所在的紧集上，均匀驻相展开给
\[
\int g_\beta(x)e^{iS_{h,M}(x)}dx
=g_\beta(x_h)e^{iS_{h,M}(x_h)-i\pi/4}
\sqrt{\frac{2\pi}{\tau_M/x_h^2}}
+O(H^{-3/2}),
\tag{5}
\]
即使 $x_h$ 落在 $\phi$ 支撑外，主项也按零理解；
误差对 $t$ 一致。$h<0$ 时没有驻点，积分为
$O_A(H^{-A})$。结合式 (4) 的别名误差，对正 $h$
平方后得到
\[
\frac{|A_h(M)|^2}{M^{2\beta-2}}
=\frac1H\frac{x_h^{2\beta-3}\phi(x_h)^2}{t}
+O(H^{-2}).
\]
在 $t=h/H$ 上作黎曼求和，随后以 $x=u_0/t$
换元，便得到 (2) 的积分。因为
$u_0/x_0=t_0\in(1,2)$、$\eta(t_0)\ge1$、
$\phi(x_0)>0$，该积分严格为正。
式 (3) 直接相除。$\square$

对实系数情形，单个波包必须与其共轭配对。
若 $r\ne0$ 为固定复数，置
$B_h=rA_h(\rho_M)+\overline r A_h(\overline{\rho_M})$
（第二项按 (1) 将 $\rho_M$ 换为其共轭），
则实值 $\phi$ 给
$A_h(\overline{\rho_M})=\overline{A_{-h}(\rho_M)}$。
正频带只有第一项有驻点，负频带只有第二项有驻点；
由同一非驻相界和 $\eta$ 的偶性，
\[
\sum_h\eta(h/H)|B_h|^2
=2|r|^2M^{2\beta-2}
\left[\int_1^2\eta(u_0/x)x^{2\beta-4}\phi(x)^2dx+o(1)\right].
\tag{5a}
\]
因此一对共轭波包本身不会相互消去；这仍不排除
**不同**零点及真实非极点部分的相消。

## 与真实两端点系数的代数接口

对 note 849 式 (10) 的实际系数 $c(m)$，在 $\Re s>1$ 有
\[
\sum_{m\ge1}\frac{c(m)}{m^s}
=\bigl(4-2^{1-s}\bigr)
\left(\zeta(s)+\frac{\zeta'(s)}{\zeta(s)}\right)
-\frac{4\log2}{\zeta(s)}.
\tag{6}
\]
这里先用 $\sum\Lambda(m)m^{-s}=-\zeta'(s)/\zeta(s)$、
$\sum\mu(m)m^{-s}=1/\zeta(s)$，再把偶数臂换元
$m=2n$；式 (6) 在 $s=1$ 的两个表面极点相消。
若 $\rho$ 是 $\zeta$ 的单零点，则 (6) 在该处的留数是
\[
\bigl(4-2^{1-\rho}\bigr)
-\frac{4\log2}{\zeta'(\rho)}.
\tag{7}
\]
单零点的这一留数消失恰需
$\zeta'(\rho)=4\log2/(4-2^{1-\rho})$。
若 $\rho$ 的重数 $m\ge2$，则 $1/\zeta(s)$
在 $\rho$ 有 $m$ 阶极点，而
$\zeta'(s)/\zeta(s)$ 至多有一阶极点；
式 (6) 的最高阶主系数非零，故这个极点不可能完全消失。
对于留数非零的单零点，若某次合法的 Mellin
轮廓移动拾取这一极点，
其单项恰为留数乘
\[
M^{\rho-1}\int_0^\infty
x^{\rho-2}\psi(x)e(-hx)\,dx.
\tag{8}
\]
式 (1) 在 $\phi=\psi$ 时的 Poisson 主项具有同一积分。
这里没有证明可把实际 $\mathcal A_h$ 一致分解成
一个这样的极点项与更小的余项。
式 (7) 可能自身相消，且不同极点及剩余积分可以相消；
所以 (2) 不能据此变成真实系数的下界。

## 决策边界

固定高度 $\rho$ 的波包随 $h\to\infty$ 非驻相，正是
scratch 967 的快速衰减情形。高度 $\Im\rho\asymp H$
时会在真实观察频带形成 (2) 的驻相能量。
因此若把 note 849 的 prime/Möbius 指数和写成零点项，
**仅对各零点项取绝对值并使用零密度计数**，
不能从“高实部零点很少”推出固定幂带通界：
零密度允许单个实部 $>1/2+2\gamma$ 且留数没有
额外固定幂衰减的项，而 (2) 表明它已超过目标量级。
此结论只裁决这种逐零绝对估计策略；
真实联合系数可能还有极点留数相消、零点间相消或别的算术抵消。
