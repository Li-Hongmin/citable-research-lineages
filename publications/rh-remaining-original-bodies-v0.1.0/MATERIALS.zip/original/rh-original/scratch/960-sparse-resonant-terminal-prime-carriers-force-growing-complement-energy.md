# 稀疏共振的真实末带素数载波迫使补集能量随载波数增长

日期：2026-10-02。依赖 [scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 式 (2)、(9)、(15) 的真实素数源单管一致展开及全选管能量，以及 [scratch 959](959-subexponential-growing-prime-carriers-have-negative-covariance-with-the-full-k2-residual.md) 式 (10) 的完整 \(k=2\) 余项载波投影界。与 958–959 中**全部相邻载波等权相加**时能量保持一管量级不同，本文只取一个固定同余类的真实载波：其相位在观察窗内一个有理点共振，联合能量随载波数增长；未选中的真实素数管已经给予同阶负补偿。证明尚待异源复核，故留在 `scratch/`。这不是完整余项均方界，也不证明 RH。

## 命题

固定 \(0<\gamma<1/4\)，令 \(H=\lfloor Y^\gamma\rfloor\)、\(V_Y=(\log Y/\log\log Y)^{1/3}\)，并取 [scratch 959](959-subexponential-growing-prime-carriers-have-negative-covariance-with-the-full-k2-residual.md) 允许的固定 \(c_*>0\)。令整数 \(B_Y\to\infty\) 满足 \(B_Y\le e^{c_*V_Y}\)。固定非负、非零 \(\chi\in C_c^\infty((3/2,8/5))\)。可选互素整数 \(p,q\)、\(q\ge2\)，使 \(z_0=p/q\in(3/2,8/5)\) 且 \(\chi(z_0)>0\)。置
\[
 J_Y=\lfloor B_Y/q\rfloor,
 \qquad \mathcal G_N=\sum_{j=0}^{J_Y}G_{qj}(N),
 \qquad \mathcal F_N=\sum_{r=0}^{B_Y}G_r(N),
 \qquad A_Y=\frac{Y^3}{H^4(\log Y)^4},
\tag{1}
\]
其中 \(G_r\) 是 note 845、scratch 958–959 的**真实素数源管**，对应观察频率 \(h_r=H+r\)。于是存在 \(c_{\gamma,\chi}>0\) 使
\[
 \boxed{\quad
 c_{\gamma,\chi}J_YA_Y
 \le\sum_N\chi(N/Y)|\mathcal G_N|^2
 \ll_{\gamma,\chi}J_YA_Y,
 \quad}\tag{2}
\]
事实上，令 \(f(z)=z^{-1}\int_1^{11/10}\log(z/x)\,dx\)，能量有正的精确常数：
\[
 \boxed{\quad
 \sum_N\chi(N/Y)|\mathcal G_N|^2
 =\bigl(C_{q,\chi}+o_{\gamma,\chi}(1)\bigr)(J_Y+1)A_Y,
 \quad
 C_{q,\chi}=\frac1{2\pi^2q}
 \sum_{\substack{k\in\mathbb Z\\3/2<k/q<8/5}}
 \chi(k/q)f(k/q)^2>0.
 \quad}\tag{2a}
\]
\[
 \boxed{\quad
 \sum_N\chi(N/Y)\mathcal G_N
       (\mathcal R_{N,2}-\mathcal G_N)
 \le -c_{\gamma,\chi}J_YA_Y,
 \quad}\tag{3}
\]
\[
 \boxed{\quad
 \sum_N\chi(N/Y)|\mathcal R_{N,2}-\mathcal G_N|^2
 \ge c_{\gamma,\chi}J_YA_Y.
 \quad}\tag{4}
\]
所有不等式对充分大 \(Y\) 成立；\(J_Y\to\infty\)。式 (3) 的补集是从完整原始 Poisson 展开中删去式 (1) 所选**实际源项**所得，未对选中项加人工正负权。不同 \(j\) 的同一分子 \(a\) 之素数分母窗中心相距 \(\asymp qY/H\)，而窗长 \(O(Y/(H\log Y))\)，故充分大时这些实际源项互不重复。

更强地，补偿已发生在这一族的**其余真实素数管**中：
\[
 \boxed{\quad
 \langle\mathcal G,\mathcal F-\mathcal G\rangle_\chi
 =-(1-o(1))\|\mathcal G\|_\chi^2
 \le-c_{\gamma,\chi}J_YA_Y,
 \qquad
 \|\mathcal F-\mathcal G\|_\chi^2
 =(C_{q,\chi}+o(1))(J_Y+1)A_Y.
 \quad}\tag{4a}
\]
由 (2a) 可把两处交叉的主项统一写成
\[
 \boxed{\quad
 \langle\mathcal G,\mathcal F-\mathcal G\rangle_\chi
 =\langle\mathcal G,\mathcal R_{\cdot,2}-\mathcal G\rangle_\chi
 +o(J_YA_Y)
 =-(C_{q,\chi}+o(1))(J_Y+1)A_Y.
 \quad}\tag{4b}
\]

## 证明

记 \(z=N/Y\)、\(\ell=\log Y\)、\(A_0=Y/(\pi H^2\ell^2)\)，以及
\[
 f(z)=\frac1z\int_1^{11/10}\log(z/x)\,dx.
\]
在 \([3/2,8/5]\) 上 \(f\) 连续且严格正。scratch 958 式 (9)、(15) 对全部 \(0\le r\le B_Y\) 及整个观察窗一致给
\[
 G_r(N)=A_0f(z)\cos(2\pi(H+r)z)
 +O_\gamma(A_0\epsilon_Y),
 \qquad
 \epsilon_Y=\ell^{-1}+B_Y/H+e^{-c_1V_Y}=o(1),
\tag{5}
\]
其中 \(c_1>0\) 固定。式 (5) 使用 958 的真实素数短和误差，不使用其互素 Möbius 管引理。因 \(B_Y=Y^{o(1)}\)，\(B_Y/H\to0\)。

选足够小的固定 \(\delta>0\)，使 \(\chi(z)\ge\chi(z_0)/2\)、\(f(z)\ge f(z_0)/2\) 于 \(|z-z_0|\le2\delta\)，并使 \(2\pi\delta\le\pi/12\)。考虑短窗
\[
 I_Y=\left[z_0-\frac{\delta}{q(J_Y+1)},
                z_0+\frac{\delta}{q(J_Y+1)}\right].
\tag{6}
\]
由于 \(qz_0=p\in\mathbb Z\)，对 \(z\in I_Y\)、\(0\le j\le J_Y\)，有
\[
 \bigl\|qjz\bigr\|_{\mathbb R/\mathbb Z}
 \le \frac{j\delta}{J_Y+1}<\delta.
\tag{7}
\]
若同时 \(\cos(2\pi Hz)\ge3/4\)，则由 (7) 与 \(2\pi\delta\le\pi/12\)，
\[
 \cos(2\pi(H+qj)z)
 \ge \cos\bigl(\arccos(3/4)+\pi/12\bigr)>1/2.
\tag{8}
\]
把 (5) 对 \(j\) 求和，\(\epsilon_Y=o(1)\) 给这些整数 \(N\) 上的逐点下界
\[
 \mathcal G_N\ge\tfrac18 f(z_0)(J_Y+1)A_0.
\tag{9}
\]

区间 \(I_Y\) 在 \(N\) 变量中的长度为 \(2\delta Y/[q(J_Y+1)]\)。函数 \(\cos(2\pi HN/Y)\) 的周期为 \(Y/H\)，而 \(H/(J_Y+1)\to\infty\)、\(Y/H\to\infty\)。每个完整周期内满足 \(\cos(2\pi HN/Y)\ge3/4\) 的整数占固定正比例，单周期整数取整只产生 \(O(1)\) 误差；删去两个端部不完整周期后，仍有
\[
 \#\{N:N/Y\in I_Y,\ \cos(2\pi HN/Y)\ge3/4\}
 \gg_{q,\delta}\frac{Y}{J_Y+1}.
\tag{10}
\]
在 (10) 的集合上 \(\chi\ge\chi(z_0)/2\)。将 (9) 平方求和，并用 \(YA_0^2=A_Y/\pi^2\)，得到
\[
 \|\mathcal G\|_\chi^2
 :=\sum_N\chi(N/Y)|\mathcal G_N|^2
 \gg_{\gamma,\chi}(J_Y+1)A_Y,
\]
这证明 (2) 的下界。为求 (2a)，不能把 (5) 的 \(O(A_0/\ell)\) 确定性误差逐管相加。使用 scratch 958 式 (10)、(14)、(16) 的精确密度模型
\(\mathscr P_{H+r}(N)=\operatorname{Re}(e((H+r)z)\mathcal B_{H+r}(z))\)。令 \(\epsilon'_Y=\ell^{-1}+B_Y/H=o(1)\)。则
\(\sup_{r,z}|\mathcal B_{H+r}(z)-A_0f(z)|\ll A_0\epsilon'_Y\)，而沿选中子序列的总变差不超过全部相邻序列的总变差 \(O(A_0B_Y/H)\)。对误差序列作离散 Abel，得到
\[
 \left|\sum_{j=0}^{J_Y}
 [\mathcal B_{H+qj}(z)-A_0f(z)]e(qjz)\right|
 \ll A_0\epsilon'_Y\min\!\left(J_Y+1,
  \frac1{\|qz\|_{\mathbb R/\mathbb Z}}\right).
\tag{10a}
\]
其平方在任一固定长度的 \(z\) 区间积分为 \(O_q(A_0^2(\epsilon'_Y)^2(J_Y+1))\)，因为 \(\int_0^1\min(J+1,\|t\|^{-1})^2dt=O(J+1)\)。scratch 958 式 (11) 中逐项对 \(z\) 求导还给 \(\sup_{r,z}|\partial_z\mathcal B_{H+r}(z)|\ll A_0\)。因此密度模型的选中和 \(P(z)\) 满足 \(\|P\|_\infty\ll A_0(J_Y+1)\)、\(\|P'\|_\infty\ll A_0(J_Y+1)(H+B_Y+1)\)。对 \(\chi|P|^2\) 用有界变差整数求积，离散和与 \(Y\) 倍积分的差至多
\(O_{\chi}(A_0^2(J_Y+1)^2(H+B_Y+1))=o(YA_0^2(J_Y+1))\)，因为 \(J_Y(H+B_Y)=Y^{\gamma+o(1)}=o(Y)\)。最后 scratch 958 式 (9) 的真实素数误差逐管为 \(O(A_0e^{-c_1V_Y})\)，其选中和的平方费用至多 \(O(YA_0^2(J_Y+1)^2e^{-2c_1V_Y})=o(J_YA_Y)\)，因为 \(c_*<c_1\)。故真实 \(\mathcal G\) 的加权能量与下列主波形的能量相差 \(o(J_YA_Y)\)：
\[
 A_0f(z)\operatorname{Re}\bigl(e(Hz)D_{J_Y}(qz)\bigr),
 \qquad D_J(t)=\sum_{j=0}^Je(jt).
\tag{10b}
\]
展开实部平方，非振荡项为 \(\frac12A_0^2f(z)^2|D_{J_Y}(qz)|^2\)。振荡项展开后的整数频率为 \(2H+q(j+k)\asymp H\)；\(\chi f^2\) 光滑紧支撑，三次分部积分及整数 Poisson 求和给每个 \((j,k)\) 的离散和 \(O_{\chi,f}(YH^{-3})\)，合计 \(O(YA_0^2(J_Y+1)^2H^{-3})=o(J_YA_Y)\)。非振荡项的整数求积误差也为 \(o(J_YA_Y)\)，因为其上确界和变差至多 \(O_{\chi,f}(A_0^2(J_Y+1)^2qJ_Y)\)，且 \(J_Y^2/Y\to0\)。Fejér 核的近似恒等性质给
\[
 \int_{3/2}^{8/5}\chi(z)f(z)^2|D_{J_Y}(qz)|^2dz
 =\frac{J_Y+1}{q}
 \sum_{3/2<k/q<8/5}\chi(k/q)f(k/q)^2+o(J_Y+1).
\tag{10c}
\]
结合 \(YA_0^2=A_Y/\pi^2\) 得 (2a)，因而也得到 (2) 的上界。

scratch 958 式 (2) 对全部相邻管的等权和给 \(\sum_{3Y/2<N\le8Y/5}|\mathcal F_N|^2=O_\gamma(A_Y)\)。因 \(\chi\) 有界且非负，\(\|\mathcal F\|_\chi^2=O_{\gamma,\chi}(A_Y)\)。于是 Cauchy--Schwarz 和 (2) 给
\[
 |\langle\mathcal G,\mathcal F\rangle_\chi|
 \le \|\mathcal G\|_\chi\|\mathcal F\|_\chi
 =o(\|\mathcal G\|_\chi^2),
\]
因为 \(\|\mathcal G\|_\chi^2\gg J_YA_Y\)、\(J_Y\to\infty\)。展开 \(\mathcal F=(\mathcal F-\mathcal G)+\mathcal G\) 得 (4a) 的交叉式；再用
\(\|\mathcal F-\mathcal G\|_\chi^2=\|\mathcal G\|_\chi^2-2\langle\mathcal G,\mathcal F\rangle_\chi+\|\mathcal F\|_\chi^2\)
及 (2a) 得其精确能量式。此处负交叉**完全在真实素数源族内部**，没有使用 Möbius 管估计。

scratch 959 式 (10) 给每条实际源管与**完整**余项的投影一致界
\[
 \left|\sum_N\chi(N/Y)G_r(N)\mathcal R_{N,2}\right|
 \ll_{\gamma,\chi} A_Ye^{-c_2V_Y}
 \quad(0\le r\le B_Y)
\tag{11}
\]
，其中 \(c_2>0\)。只对选中的 \(J_Y+1\) 条管求和，得到
\[
 |\langle\mathcal G,\mathcal R_{\cdot,2}\rangle_\chi|
 \ll_{\gamma,\chi}(J_Y+1)A_Ye^{-c_2V_Y}
 =o(\|\mathcal G\|_\chi^2).
\tag{12}
\]
于是
\[
 \langle\mathcal G,\mathcal R_{\cdot,2}-\mathcal G\rangle_\chi
 =-\|\mathcal G\|_\chi^2+o(\|\mathcal G\|_\chi^2),
\tag{13}
\]
由 (2) 得 (3)。最后在非负权 \(\chi\) 的半内积中用 Cauchy--Schwarz，
\[
 \|\mathcal R_{\cdot,2}-\mathcal G\|_\chi
 \ge(1-o(1))\|\mathcal G\|_\chi,
\]
再用 (2) 得 (4)。\(\square\)

## 边界

式 (2)–(4a) 将 959 对相邻**全选**载波的有界补偿，改成一个真实稀疏子族上的发散补偿，并定位到未选中的素数管内部。它说明载波 Gram 对选择模式敏感：固定同余类在观察窗内有相干点，而全部相邻等权管的 Dirichlet 核在该窗远离共振。这里的规模仍是 \(J_YA_Y=Y^{3-4\gamma+o(1)}\)，高于 \(Y^{2+\varepsilon}\) 的目标；负协方差与补集能量不能充当完整余项均方上界，更不推出 RH。
