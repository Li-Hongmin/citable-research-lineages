# 槽外重叠权的低零点总质量为次二次量

日期：2026-09-30。沿用 [note 829](../notes/829-exterior-overlap-mellin-weight-zero-free-growing-band.md) 的 \(E_p\)、\(W_p\) 和 \(C(s)\)。这里只估计显式公式中一段增长高度内**全部零点的绝对质量**，不假设 RH，也不估计更高零点。

## 命题

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)。若 \(T_p\to\infty\) 且
\[
T_p^3H^3/p\longrightarrow0,
\tag{1}
\]
则按重数计的全部非平凡零点满足
\[
\boxed{\qquad
\sum_{|\Im\rho|\le T_p}|W_p(\rho)|=o(p^2).
\qquad}
\tag{2}
\]
例如对每个固定 \(\varepsilon>0\)，可取
\(T_p=p^{1/3}/H^{1+\varepsilon}\)。因 note 829 的 \(k_p\asymp p\)，这段零点在真正素数标量差 \(r_p-k_p\) 中的绝对贡献为 \(o(p)\)。式 (2) 不控制 \(|\Im\rho|>T_p\) 的尾项。

## 证明

先把 note 829 式 (8a) 的 Euler 余项延伸到闭条带。对 \(0\le\sigma=\Re s\le1\)、\(|\Im s|\le p\)，在固定比例区间 \([X/8,X/4]\)、\([B/2,B]\) 上分别有
\[
\int |d(v^s)|\ll(1+|s|)X^\sigma,
\qquad
\int |d(v^{-s})|\ll(1+|s|)B^{-\sigma},
\quad X=p^{3/2},\ B=\sqrt p.
\tag{3}
\]
这两个常数在 \(\sigma=0,1\) 也一致，因为积分区间的端点比固定。把 (3) 用于 note 829 式 (6)--(8) 的两次 Euler 求和，并使用其 \(J_L(s)=p^{-2}\{1+O(p^{-2}+|s|^2p^{-4})\}\)，得到绝对常数 \(A\) 使
\[
\boxed{\quad
F_p(s):=p^{-2s}\int_{E_p}e^{su}du
=C(s)+e_p(s),
\qquad |e_p(s)|\le A(1+|s|)p^{-1/2}H
\quad}
\tag{4}
\]
在上述闭条带与高度内成立。这里无需 \(C(s)\) 的下界。

note 829 式 (3) 的两个积分经一次端点分部积分，各为 \(O((1+|\Im s|)^{-1})\)，且常数对 \(0\le\Re s\le1\) 一致。因此
\[
|C(s)|\ll(1+|\Im s|)^{-2},
\qquad
\sum_\rho |C(\rho)|^2<\infty,
\tag{5}
\]
后式由标准零点计数 \(N(T)=O(T\log(2T))\) 得出。每个非平凡零点 \(\rho=\beta+i\gamma\) 满足 \(0<\beta<1\)，所以 \(p^{2\beta-2}\to0\)。由 (5) 的可和控制与逐项收敛，
\[
\sum_\rho p^{2\beta-2}|C(\rho)|^2=o(1).
\tag{6}
\]

式 (1) 保证充分大时 \(T_p<p\)。由 note 829 式 (1)、(4)，以及 \(|a+b|^2\le2|a|^2+2|b|^2\)，
\[
\begin{aligned}
p^{-2}\sum_{|\gamma|\le T_p}|W_p(\rho)|
&\le2\sum_{|\gamma|\le T_p}p^{2\beta-2}|C(\rho)|^2
+2A^2p^{-1}H^2\sum_{|\gamma|\le T_p}(1+|\gamma|)^2\\
&=o(1)+O\!\left(p^{-1}H^2(1+T_p)^3\log(2T_p)\right)
=o(1).
\end{aligned}
\tag{7}
\]
最后一步由 \(\log(2T_p)\ll H\) 和 (1) 得到，证明 (2)。\(\square\)

## 边界

本命题只排除低高度零点对标量误差产生线性 \(p\) 量级的绝对贡献。更高零点的 \(W_p(\rho)\) 同时承载 Farey 槽的微观结构和素数采样误差；(2) 本身不给出 \(r_p-k_p=o(p)\)，更不给出完整局部 Weil 正性或 RH。
