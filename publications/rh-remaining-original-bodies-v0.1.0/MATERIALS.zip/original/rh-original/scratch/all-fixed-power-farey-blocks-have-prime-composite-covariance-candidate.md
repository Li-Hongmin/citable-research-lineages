# 每个固定幂 Farey 短块的素数--合数负协方差：证明候选

日期：2026-09-30。待异源复核；不更动冻结 SPEC。依赖 notes 800、801、832、833 的精确频率与奇偶公式。文献输入有二：

1. D. R. Heath-Brown, *Prime Numbers in Short Intervals and a Generalized Vaughan Identity*, *Can. J. Math.* **34** (1982), 1365–1377, DOI 10.4153/CJM-1982-095-9：首页定理给固定 \(\theta>7/12\) 时 \(\sum_{x-x^\theta<n\le x}\Lambda(n)\sim x^\theta\)。
2. K. Matomäki and J. Teräväinen, *On the Möbius function in all short intervals*, *J. Eur. Math. Soc.* (2022), DOI 10.4171/JEMS/1205，arXiv:1911.09076v2，§2.1 明确记录 Motohashi–Ramachandra 的旧范围：对每个固定 \(\theta>7/12\)，某个 \(c_\theta>0\) 使所有 \(x\) 及 \(H\ge x^\theta\) 满足
   \[
   \sum_{x<n\le x+H}\mu(n)
   \ll_\theta H\exp\!\left[-c_\theta
   \left(\frac{\log x}{\log\log x}\right)^{1/3}\right].
   \tag{A}
   \]
   已于 2026-09-30 从 ResearchLibrary 所存全文直接核对 §2.1；该旧范围比同文 Theorem 1.1 的 \(0.55\) 指数更窄，但误差远强于后者的对数幂。

## 命题

固定 \(5/6<\alpha<1\)。令
\[
D=\lfloor Y^\alpha\rfloor,\quad B=\left\lfloor\frac{D^2}{1000Y}\right\rfloor,\quad
L=\lfloor Y^{5/6}\rfloor.
\tag{1}
\]
对**每个**长度为 \(B\) 的整数块 \(I=(t,t+B]\subset(D/2,D]\)，沿用 note 833 式 (1)，定义 \(G_{I,N}=\sum_{p\in I,\ p\text{ prime}}F_{p,N}\)、\(T_{I,N}=\sum_{q\in I}F_{q,N}\)，\(Y<N\le2Y\)。记 \(v_I=\#\{p\in I:p\text{ prime}\}\)、\(E_I=\sum_NG_{I,N}^2\)。则一致于所有这些 \(I\)，
\[
v_I\sim B/\log D,\qquad
\sup_N|T_{I,N}|=o\!\left(\frac{BD}{Y\log Y}\right),
\tag{2}
\]
\[
E_I\asymp_\alpha \frac{D^6}{Y^3\log^2Y}
\asymp_\alpha\frac{Y^{6\alpha-3}}{\log^2Y},
\tag{3}
\]
\[
\sum_NG_{I,N}(T_{I,N}-G_{I,N})=-(1+o(1))E_I.
\tag{4}
\]
所有原始指标 \(d=kq,h=k,kq\le N-L\) 都位于 note 832 的斜楔 \(\mathcal V_N\)。本命题无条件地将 note 833 的固定幂素数块从“只知必要抵消”推进为**每个**短块内部已有等量真实负协方差；不控制不同块联合的完整 \(\mathcal V_N\) 均方，更不证明 RH。

## 证明：短区间加权 Mertens

记 \(u(x)=(\log x/\log\log x)^{1/3}\)、\(f(q)=\mu(q)q/\varphi(q)\)、\(f_o(q)=f(q)\mathbf1_{2\nmid q}\)、\(f_\kappa=f+4f_o\)。note 833 式 (7) 中给出的精确卷积为 \(f=\mu*h\)、\(f_o=\mu*h_o\)，并证明
\[
\sum_{d\ge1}\frac{|h(d)|+|h_o(d)|}{d^{1/2}}<\infty.
\tag{5}
\]
对 \(x\asymp D\)、\(x^{3/4}\le H\le x/2\)，把
\[
\sum_{x<n\le x+H}(\mu*h)(n)
=\sum_{d\le x+H}h(d)
\sum_{x/d<m\le(x+H)/d}\mu(m)
\tag{6}
\]
在 \(d_0=x^{1/4}\) 分开。对 \(d\le d_0\)，有
\[
\frac{H/d}{(x/d)^{5/8}}
=\frac{H}{x^{5/8}d^{3/8}}\ge x^{1/32},
\]
所以 (A) 可取 \(\theta=5/8\) 一致应用；又 \(x/d\ge x^{3/4}\)，故这段由 (5) 支付为 \(O(H e^{-cu(x)})\)。对 \(d>d_0\)，内和的绝对值至多 \(H/d+1\)。式 (5) 给
\[
H\sum_{d>d_0}\frac{|h(d)|}{d}
+\sum_{d\le x+H}|h(d)|
\ll Hx^{-1/8}+x^{1/2}
\ll H e^{-cu(x)}
\tag{7}
\]
（缩小 \(c>0\)）。对 \(h_o\) 完全相同。因此
\[
\sum_{x<n\le x+H}f_\kappa(n)\ll H e^{-cu(x)}
\qquad(x\asymp D,\ x^{3/4}\le H\le x/2).
\tag{8}
\]
常数及误差在这些 \(x,H\) 上一致。

对固定 \(\alpha>5/6\)，有
\[
B=D^{2-1/\alpha+o(1)}\gg D^{4/5-o(1)}
\quad\text{且}\quad B=o(D).
\tag{9}
\]
令 \(S_t(z)=\sum_{t<q\le z}f_\kappa(q)\)，\(t\le z\le t+B\)。若 \(z-t\ge D^{3/4}\)，(8) 给 \(|S_t(z)|\ll B e^{-cu(D)}\)；若较短，由 \(|f_\kappa(q)|\ll\log\log(3D)\) 得 \(|S_t(z)|\ll D^{3/4}\log\log D\)。由于 \(B/D^{3/4}\) 增长为固定幂，故
\[
\max_{\substack{I\subset(D/2,D]\\|I|=B}}
\max_{t\le z\le t+B}|S_t(z)|
\ll B e^{-cu(D)}+D^{3/4}\log\log D
=o(B/\log D).
\tag{10}
\]

## 证明：频率系数、能量与负协方差

对 \(q\in I\) 有 \(K=N/q\asymp Y^{1-\alpha}\)。note 800 式 (12) 的一致互素 Möbius 调和界、note 801 式 (7) 的精确 Poisson 系数及 note 833 式 (10)--(11) 的奇偶拆分，给
\[
C_q(N)=-qf_\kappa(q)
+O_\alpha\!\left(qe^{-c_\alpha\omega(Y)}
+q\log\log(3Y)(q/N)^2+q^2L/Y^2\right),
\tag{11}
\]
对 \(q,N,I\) 一致；\(q>L\) 保证物理裁剪至多失去一个原始倍数。把 (11) 的误差逐 \(q\) 求和、再除以 \(\pi N\)，相对于 \(BD/(Y\log Y)\) 至多为
\[
O_\alpha\!\left(\log Y e^{-c_\alpha\omega(Y)}
+\log Y\log\log Y(D/Y)^2
+DL\log Y/Y^2\right)=o(1).
\tag{12}
\]
置 \(g_N(z)=z\cos(2\pi N/z)\)。在 \(I\) 上 \(|g_N(t+B)|\ll D\)，且
\[
\operatorname{Var}_Ig_N\ll B(1+Y/D)\ll D.
\]
由 (10) 分部求和，\(\sum_{q\in I}f_\kappa(q)g_N(q)=o(BD/\log Y)\) 对 \(I,N\) 一致。与 (11)--(12) 合并，得到 (2) 的 \(T\) 式。

Heath-Brown 定理取 \(2/3\) 并把长度 \(B\gg D^{3/4}\) 的每个块切成 \(x^{2/3}\) 小段，给 \(\sum_{q\in I}\Lambda(q)=B(1+o(1))\)；素数幂权为 \(O(\sqrt D\log^2D)=o(B)\)。因此 \(v_I\sim B/\log D\)，一致于 \(I\)。

对 \(p\in I\)，(11) 给 \(C_p(N)=5p+o(p)>0\) 一致。任取 \(q_0\in I\)，当 \(Y<N\le2Y\) 且 \(\|N/q_0\|_{\mathbb R/\mathbb Z}\le1/12\) 时，
\[
\left|\frac Np-\frac N{q_0}\right|
\le\frac{2YB}{(D/2)^2}\le \frac8{1000}.
\tag{13}
\]
这类整数 \(N\) 有 \(\gg Y\) 个，因为 \(q_0=o(Y)\)。式 (13) 使所有 \(\cos(2\pi N/p)\) 同号且有统一正下界，故 \(|G_{I,N}|\gg v_ID/Y\)；另一方面全体 \(N\) 上 \(|G_{I,N}|\ll v_ID/Y\)。从而
\[
E_I\asymp \frac{v_I^2D^2}{Y}
\asymp\frac{B^2D^2}{Y\log^2D}
\asymp\frac{D^6}{Y^3\log^2Y},
\tag{14}
\]
一致于 \(I\)。由 (2) 得 \(\|T_I\|_2=o(\|G_I\|_2)\) 一致，故展开 \(\langle G_I,T_I-G_I\rangle\) 即得 (4)。斜楔归属与 note 833 式 (16) 相同，因为 \(q>D/2\gg Y^{5/6}>Y^{4/5}\)、分子 \(1<\min(A,A_j)\)、原始 \(d\le N-L\)。\(\square\)

最薄弱接口：(A) 的强误差是否确实逐起点且逐 \(H\ge x^\theta\) 一致；以及它经 (5)--(7) 传递给 \(f_\kappa\) 时对全部部分长度 \(H\ge D^{3/4}\) 是否无损。
