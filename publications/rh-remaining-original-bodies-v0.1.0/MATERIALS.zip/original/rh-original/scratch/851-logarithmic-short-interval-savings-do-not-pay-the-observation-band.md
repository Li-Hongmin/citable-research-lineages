# 任意对数幂的短区间节省仍不支付观察频带

日期：2026-10-01。此反模型只判定 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (22)--(26) 所用的短区间范数能否单独推出式 (15) 的固定幂目标；不替代真实素数、Möbius 符号或算术协方差。

固定非负非零的 $\psi\in C_c^\infty((1,2))$ 和 note 849 的 $\eta$。
令 $M=2Y$，$H=\lceil Y^{1/5}\rceil$，
$h_0=\lceil3H/2\rceil$，
$\delta_Y=\exp(-\sqrt{\log Y})$，并在 $M<m<2M$ 上置
\[
d_Y(m)=\delta_Y\cos(2\pi h_0m/M),\qquad
A_h(d)=\sum_m\frac{d_Y(m)}m\psi(m/M)e(-hm/M).
\tag{1}
\]
区间外令 $d_Y=0$。对每个固定 $A>0$ 及每个整数区间 $I$，当 $Y$ 充分大时，
\[
\left|\sum_{m\in I}d_Y(m)\right|
\le\delta_Y|I|
\le |I|/(\log Y)^A.
\tag{2}
\]
此外 $|d_Y(m)|\le1$、
$\sum_m|d_Y(m)|/m\ll1$，而归一化序列
$a_m=d_Y(m)\psi(m/M)/m$ 满足
$\sum_m|a_m|^2\ll1/Y$。这些界至少与 note 849 式 (16)、(23)--(25) 所用的无符号和任意对数幂短区间输入同量级。

记 $w_m=\psi(m/M)/m$，$C_\psi=\int_1^2\psi(u)u^{-1}du>0$。余弦展开给
\[
A_{h_0}(d)=\frac{\delta_Y}{2}
\left(\sum_m w_m+\sum_mw_me(-2h_0m/M)\right).
\tag{3}
\]
对 $\varphi(u)=\psi(u)/u$ 作 Poisson 求和，
$\sum_m w_m=C_\psi+O_B(M^{-B})$，
$\sum_mw_me(-2h_0m/M)=O_B(H^{-B})$，对每个固定 $B>0$ 成立。
由于 $H^{-B}=o(\delta_Y)$，实际上只需第二项为 $o(1)$，式 (3) 给
$|A_{h_0}(d)|\ge C_\psi\delta_Y/3$。
又 $1\le h_0/H\le2$ 且 $\eta(h_0/H)\ge1$，故
\[
\sum_h\eta(h/H)|A_h(d)|^2
\ge c_\psi\delta_Y^2
=c_\psi e^{-2\sqrt{\log Y}}
\gg H^4/Y\asymp Y^{-1/5}.
\tag{4}
\]
最后一个比值趋于无穷，因为
$(\log Y)/5-2\sqrt{\log Y}\to\infty$。

因此，即使获得所有短区间上任意固定对数幂的消失以及达到 note 849 的对角质量界，这些数值型输入本身也不能推出目标频带幂次。该反模型包含有意嵌入的频率 $h_0$；真实三通道系数是否有相应模式只能由额外算术结构判定。

## 保留素数支撑的版本

上述结论不依赖稠密支撑。改置
$d_Y^{\rm pr}(m)=\delta_Y\mathbf1_{m\text{ prime}}(\log m)
\cos(2\pi h_0m/M)$。因 $\delta_Y\log(2M)\le(\log Y)^{-A}$
对每个固定 $A$ 最终成立，(2) 对这个素数支撑模型仍成立；
其归一化对角质量由 Chebyshev 界满足
$\sum_m|d_Y^{\rm pr}(m)\psi(m/M)/m|^2\ll\log Y/Y$。

note 835 所引 Heath--Brown 全区间短区间素数定理在
$B=\lfloor Y^{2/3}\rfloor$ 给所有长度 $B$ 的块
$\sum_{p\in I}\log p=B(1+o(1))$，一致于 $I\subset(M,2M)$。
对
$f_h(t)=\psi(t/M)t^{-1}e(-ht/M)$，
$\|f_h\|_\infty\ll Y^{-1}$、
$\|f_h'\|_\infty\ll (1+|h|)Y^{-2}$。
在各块作 Abel 求和并处理末端长度不足 $B$ 的一块，得到对
$h=0,2h_0$ 一致的
\[
\sum_{M<p<2M}(\log p)f_h(p)
=\int_M^{2M}f_h(t)\,dt+o(1).
\tag{5}
\]
这里误差中块内权变化总计
$O(h_0B/Y)=o(1)$，末端块的平凡质量
$O(B\log Y/Y)=o(1)$。式 (5) 的 $h=0$ 主项为 $C_\psi$，
$h=2h_0$ 主项由 Riemann--Lebesgue 引理趋零。
因此 (3)--(4) 的下界同样适用于 $d_Y^{\rm pr}$。
素数支撑、对角界和任意对数幂的区间节省合起来仍不足以支付固定幂频带目标。
