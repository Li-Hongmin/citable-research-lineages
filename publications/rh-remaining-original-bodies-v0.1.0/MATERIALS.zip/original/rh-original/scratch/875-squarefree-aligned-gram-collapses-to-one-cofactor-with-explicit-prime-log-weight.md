# 平方自由物理层的全部有理对齐 Gram 压缩为单一 cofactor 谱和

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实高除数系数与过滤预算、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的远差预算、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 的大物理 gcd 支付，以及 [scratch/874](874-asymmetric-rational-alignment-reduces-to-coprimality-defects.md) 的平方自由观察。这里把**两种 Möbius 比例符号全部保留**，并把三变量 $(a,b,t)$ 的对齐和精确压成单一共同 cofactor $x$ 的谱和。权 $C(x)$ 可写成素数对数的显式式子，且有正有负；本稿不控制所得谱和，亦不证明完整算术门或 RH。式 (3)–(5)、(15)–(17) 已通过独立代理只读复核；新增式 (18)–(19) 尚待独立复核，全文尚未异源复核。

## 定理

固定实 $\psi\in C_c^3((1,2))$、$s>1$；令 $\phi(u)=\psi(u)/u$、$M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，沿用 scratch/859--860 的 $D,R,K_0,w_H,J_H,K=K_{s,2}$，以及 scratch/873 的 $\alpha(k)>0$。记 $\mathfrak C_{M,H}^{\rm sf}$ 为 scratch/859 式 (12) 中满足 $\mu(m)^2=\mu(n)^2=1$ 的全部**有序有理对齐项**之 signed 和；“有理对齐”精确定义为存在 $(a,b)=1$、$a,b,t,u,v\ge1$ 使
\[
d=bu>D,\quad e=av>D,\quad m=abtu,\quad n=abtv,
\tag{1}
\]
并保留原门 $d\nmid e$、$e\nmid d$、最大约化比例 $>R$、$K_0<|m-n|\le K$。令 $\ell=\log2$，对平方自由 $x$ 写
\[
r(x)=\omega(x),\quad L(x)=\log x,\quad
S_2(x)=\sum_{p\mid x}(\log p)^2,
\tag{2}
\]
并定义
\[
C(1)=16\ell^2,
\qquad
C(x)=16(-1)^{r(x)-1}\bigl(S_2(x)-2\ell L(x)\bigr)
\quad(x>1\text{ odd squarefree}),
\tag{3a}
\]
\[
C(2z)=(-1)^{r(z)}
\bigl(12S_2(z)-16\ell^2-16\ell L(z)\bigr)
\quad(z\text{ odd squarefree}).
\tag{3b}
\]
对 $x\le H$ 且平方自由，置
\[
F_{x,h}=\sum_{\substack{M<xu<2M\\(u,x)=1}}
\mu(u)\phi(xu/M)e(-hxu/M).
\tag{4}
\]
则
\[
\boxed{\quad
\mathfrak C_{M,H}^{\rm sf}
=\frac1{M^2}\sum_{\substack{x\le H\\\mu(x)^2=1}}
C(x)\sum_h w_H(h)|F_{x,h}|^2
+O_{s,\psi}\!\left(
\frac{H^4}{M\log^2(2M)}+
\frac{\log^8(2M)}H
\right).
\quad}\tag{5}
\]
因此式 (5) 的误差为 $O_{s,\psi,\varepsilon}(H^4M^{-1+\varepsilon})$。这是实际 signed 对齐子族在目标指数上的归约；$C(1)>0$、$C(2)<0$，不能把整个右侧判为非正，也不能把它从完整 Gram 中独立删除。

## 对齐项压缩

给定有序物理四元组 $(d,e,m,n)$，置 $k=m/d$、$l=n/e$。若它满足 (1)，则 $t=(k,l)$、$a=k/t$、$b=l/t$、$u=d/b$、$v=e/a$ 唯一。因此以下重排不重计。令 $x=abt=[k,l]$，则 $x\mid m,n$。若 $m,n$ 平方自由，$x$ 也平方自由，且 $m=xu,n=xv$ 强迫 $(u,x)=(v,x)=1$；于是
\[
\mu(bu)\mu(av)=\mu(ab)\mu(u)\mu(v).
\tag{6}
\]

先只看 $x\le H$，并暂不施加整除、比例与物理距离过滤。因为 $at,bt\le x\le H$ 且 $m,n>M$，
\[
d=\frac m{at}>\frac MH>16D,
\qquad e=\frac n{bt}>\frac MH>16D.
\tag{7}
\]
所以原高除数阈值对该范围的每种分配都自动满足。对固定平方自由 $x$，每个 $p\mid x$ 恰可分配给 $a,b,t$ 三者之一；所有分配使用同一 $F_{x,h}$。scratch/859 式 (2) 与 scratch/873 式 (6) 给其未过滤合计
\[
\frac1{M^2}\left(
\sum_{\substack{x=abt\\(a,b)=1}}
\mu(ab)\alpha(at)\alpha(bt)
\right)\sum_h w_H(h)|F_{x,h}|^2.
\tag{8}
\]
括号中系数记为 $C_*(x)$，下面证明它就是 (3a)--(3b)。式 (8) 是有限和的**精确恒等式**，没有 Möbius 均值估计。

## 显式权的计算

对奇平方自由 $z$，设 $r=\omega(z)$、$L=\log z$、$S_2=\sum_{p\mid z}(\log p)^2$，并引入形式指数多项式
\[
P_z(X,Y)=\prod_{p\mid z}
\bigl(p^{X+Y}-p^X-p^Y\bigr).
\tag{9}
\]
这里每个因子的三项分别对应 $p$ 分配给 $t,a,b$，负号就是 $\mu(ab)$。乘积法则在 $(0,0)$ 给
\[
P_z(0,0)=(-1)^r,\qquad
\partial_XP_z(0,0)=\partial_YP_z(0,0)=0,
\qquad
\partial_X\partial_YP_z(0,0)=(-1)^{r-1}S_2.
\tag{10}
\]
当 $r=0$ 时最后一项按 $S_2=0$ 解读为零。

若 $x=z>1$ 为奇数，则 $\alpha(k)=4\log k+4\ell\mathbf1_{k=1}$ 对所有 $k\mid z$ 成立。乘积展开中，$4\log(at)\cdot4\log(bt)$ 的合计由 (10) 为 $16(-1)^{r-1}S_2$。只有 $bt=1$ 或 $at=1$ 才出现额外的 $4\ell$；前者强迫 $(a,b,t)=(z,1,1)$，后者为 $(1,z,1)$，两项共给 $32\ell\mu(z)L$。因 $\mu(z)=(-1)^r$，得到 (3a)。$x=1$ 时只有 $(1,1,1)$，故 $C_*(1)=\alpha(1)^2=16\ell^2$。

若 $x=2z$，先分配素数 $2$。当 $2\mid t$ 时，两臂 $at,bt$ 都为偶数，
$\alpha(at)=4\ell+2\log(a_\mathrm{odd}t_\mathrm{odd})$、
$\alpha(bt)=4\ell+2\log(b_\mathrm{odd}t_\mathrm{odd})$；由 (10)，总贡献为
\[
16\ell^2(-1)^r+4(-1)^{r-1}S_2.
\tag{11}
\]
当 $2\mid a$ 时，第一臂为偶数、第二臂为奇数；奇臂的权为 $4\log(bt)+4\ell\mathbf1_{bt=1}$。来自 $4\log(bt)$ 的合计为 $-8(-1)^{r-1}S_2$，而 $bt=1$ 强迫全部奇素数进入 $a$，其额外贡献为
\[
-4\ell(-1)^r(4\ell+2L).
\tag{12}
\]
$2\mid b$ 的贡献相同。把 (11) 与两份 (12) 及其各自的混合对数项相加，正得
\[
C_*(2z)=(-1)^r\bigl(12S_2-16\ell^2-16\ell L\bigr),
\]
即 (3b)。特别地 $C_*(2)=-16\ell^2$，与直接枚举三种分配一致。

## 恢复过滤与大共同 cofactor

在 $x\le H$ 的物理平方自由子族中恢复原门过滤。scratch/859 式 (8) 支付 $d=e$ 对角源，式 (8a) 支付非对角整除源，式 (8b) 支付低约化比例，式 (10) 支付 $|m-n|\le K_0$；其合计为
$O_\psi(H^2\log^3(2M)/M+H^4/(M\log^2(2M)))$。scratch/860 式 (3) 支付 $|m-n|>K$，为 $O_{s,\psi}(M^{-2})$。这些都是全部高除数物理项的绝对上界，限制到本子族仍成立。

若 $x>H$，则 $x\mid(m,n)$，所以 $(m,n)>H$。scratch/868 式 (3) 对**完整**高除数 Gram 的这部分（包括对角）给出 $O_{s,\psi}(\log^8(2M)/H)$ 的绝对界；它也支配本子族。合并上述误差，且 $H^2\log^3M/M+M^{-2}=o(H^4/(M\log^2M))$，证明 (5)。最后 $H^5\ge Y=M/2$，故 $\log^8M/H\ll_\varepsilon H^4M^{-1+\varepsilon}$。$\square$

## 边界

$x=1$ 的 $F_{1,h}$ 是真实 Möbius 指数和，权 $16\log^22$ 为正；$x=2$ 的权为负。式 (3) 揭示平方自由对齐族的符号并不逐 $x$ 一致。式 (5) 也只涉及高除数展开的一个物理子族；[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的三通道替换必须在所有除数项聚合后使用。这里没有把等价式或符号重排当作完整频带门的证明。

## 等价的物理 gcd 系数

还可把 (5) 的主和逐物理点合并。令 $g$ 为平方自由数，$D_*(g)=\sum_{x\mid g}C(x)$。则
\[
\boxed{\quad
D_*(g)=
\begin{cases}
0,&g=2,\\
16(\log p-\ell)^2,&g=p\text{ 为奇素数},\\
4(\log p-2\ell)^2,&g=2p\text{，}p\text{ 为奇素数},\\
16\ell^2,&g=1\text{ 或其余平方自由 }g.
\end{cases}
\quad}\tag{15}
\]
更短的证明是先恢复原始两臂。对平方自由 $g$，每个有序除数对 $k,l\mid g$ 唯一对应 $t=(k,l)$、$a=k/t$、$b=l/t$，且 $x=[k,l]=abt\mid g$。平方自由性给 $\mu(k)\mu(l)=\mu(ab)$，所以
\[
D_*(g)=\sum_{k,l\mid g}\mu(k)\mu(l)\alpha(k)\alpha(l)
=\left(\sum_{k\mid g}\mu(k)\alpha(k)\right)^2.
\tag{16}
\]
若 $g$ 为奇平方自由数，$\alpha(1)=4\ell$、$\alpha(k)=4\log k$ 对奇数 $k>1$，故括号中的和为 $4\ell-4\Lambda(g)$。若 $g=2z$、$z$ 奇平方自由，则把除数写成 $k\mid z$ 与 $2k$，利用 $\alpha(2k)=4\ell+2\log k$，得到括号中的和为
$4\ell(1-\mathbf1_{z=1})-2\Lambda(z)$。平方后即为 (15)。

等价地，令 $g=(m,n)$，则 (5) 可写成
\[
\boxed{\quad
\mathfrak C_{M,H}^{\rm sf}
=\frac1{M^2}
\sum_{\substack{M<m,n<2M\\\mu(m)^2=\mu(n)^2=1\\g=(m,n)\le H}}
\mu(m)\mu(n)\phi(m/M)\phi(n/M)J_H(m-n)D_*(g)
+O_{s,\psi}\!\left(
\frac{H^4}{M\log^2(2M)}+
\frac{\log^8(2M)}H\right).
\quad}\tag{17}
\]
事实上 $F_{x,h}$ 中 $m=xu$ 的 Möbius 因子满足 $\mu(u)=\mu(x)\mu(m)$，故展开 $|F_{x,h}|^2$ 后，对 $g\le H$ 的每对 $(m,n)$，公共 $x\mid g$ 的系数正是 $D_*(g)$。$g>H$ 的这些已重排物理项仍被 scratch/868 式 (3) 的完整高除数绝对界支付。

式 (15) 表明，全部平方自由有理对齐仅在 $g=p,2,2p$ 三类 gcd 上改变基准的 $16\ell^2$ 系数；但 (17) 中的 $\mu(m)\mu(n)J_H(m-n)$ 仍带符号，基准项本身也未在目标固定幂内估计。

## 与真实三通道的逐物理点接口

记 $A(g)=\sum_{k\mid g}\mu(k)\alpha(k)$，仅在平方自由 $g$ 上使用。由 (16)，$D_*(g)=A(g)^2$。对 $M<m<2M$ 的平方自由物理点，[note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (29) 的真实三通道系数满足**逐点恒等式**
\[
\boxed{\quad c_{\rm tri}(m)=-\mu(m)A(m).\quad}\tag{18}
\]
确实，若 $m$ 为奇数，则 $A(m)=4\ell-4\Lambda(m)$；若 $m=2z$ 且 $z>1$ 为奇平方自由数，则 $A(m)=4\ell-2\Lambda(z)$。代入 $\mu(2z)=-\mu(z)$，逐项恢复三通道中的奇素数、倍素数和直接 Möbius 系数。

因此对平方自由 $m,n$、$g=(m,n)$，完整三通道物理配对与 (17) 的对齐配对之差精确为
\[
\boxed{\quad
c_{\rm tri}(m)c_{\rm tri}(n)-\mu(m)\mu(n)D_*(g)
=\mu(m)\mu(n)\bigl[A(m)A(n)-A(g)^2\bigr].
\quad}\tag{19}
\]
在当前物理区间，若 $m,n$ 都既非奇素数也非 $2p$（$p$ 为奇素数），并且 $g\notin\{2,p,2p:p\text{ 为奇素数}\}$，则 $A(m)=A(n)=A(g)=4\ell$，式 (19) **逐物理点为零**。所以这两种平方自由物理配对系数的差只可能出现于真实素数/倍素数物理通道或 $g=2,p,2p$ 的小 gcd 类。这是聚合后系数的比较，不能逐项称为高除数 Gram 的非对齐源和；上述类的 signed 和仍未估计。
