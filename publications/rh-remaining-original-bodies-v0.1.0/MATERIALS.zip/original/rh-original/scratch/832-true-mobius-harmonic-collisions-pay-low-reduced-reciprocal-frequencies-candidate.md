# 真实 Möbius 谐波重合支付低既约倒数频率（候选）

日期：2026-09-29。依赖 [note 760](../notes/760-sharp-log-squared-variation-of-the-full-k2-cofactor-kernel.md) 的真实核 Fourier 展开、[note 762](../notes/762-reciprocal-frequency-spacing-pays-low-divisors-to-four-fifths.md) 的初等频率间距均方引理，以及 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 式 (9) 使用的经典 Möbius 零自由区界。下面给出真实 \(\mu\) 的无条件部分均方估计；证明尚未异源复核，留在 scratch。它不关闭剩余高既约频率门。

## 定理候选

固定 \(4/5<\alpha\le7/8\)，令 \(Y\to\infty\)、\(D=\lfloor Y^\alpha\rfloor\)、
\(Q_0=\lfloor Y^{4/5}\rfloor\)、\(H=\log(2Y)\)。取 note 760 的
\[
\Phi(t)=\log t\sum_{1/t<a<2/t}\sin(2\pi at),
\qquad
L_{N,D}(\mu)=\sum_{d\le D}\mu(d)\Phi(d/N).
\tag{1}
\]
在其 Bernoulli 主项中，只保留 \(h<d\) 且既约频率
\(h/d=a/q\in(0,1)\)、\((a,q)=1\)、\(q\le Q_0\) 的项，记为
\(\mathcal L^{\le Q_0}_{N,D}\)。则
\[
\boxed{\quad
\sum_{Y<N\le2Y}|\mathcal L^{\le Q_0}_{N,D}|^2
\ll_\alpha Y^2H^3.
\quad}
\tag{2}
\]
更精确地，约分 \(h=ka,d=kq\) 后，每个 \(a/q\) 的真实 Möbius 系数
\[
C_{a,q}(N)
=\frac{\mu(q)q}{a^2}
\sum_{\substack{k\le D/q\\(k,q)=1}}
\frac{\mu(k)(1+2(-1)^{ka})}{k}
\log\frac{N}{kq}
\tag{3}
\]
满足对 \(q\le Q_0\)、\(1\le a<q\)、\((a,q)=1\)、\(Y<N\le2Y\) 一致的渐近
\[
\boxed{\quad
C_{a,q}(N)
=\mu(q)\lambda_{a,q}\frac{q^2}{a^2\varphi(q)}
+O_\alpha\!\left(\frac q{a^2}e^{-c_\alpha\omega(Y)}\right),
\quad}
\tag{4}
\]
其中 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)，某个
\(c_\alpha>0\)，并且
\[
\lambda_{a,q}=
\begin{cases}
3,&q\text{ 奇},\ a\text{ 偶},\\
-5,&q\text{ 奇},\ a\text{ 奇},\\
-1,&q\text{ 偶}\quad(\text{此时 }a\text{ 奇}).
\end{cases}
\tag{5}
\]
特别地，同一有理频率的 Möbius 重合消去了原始
\(\log(N/q)\) 系数，却留下 \(1/\zeta(s)\) 在 \(s=1\) 的一阶零点导数。

令 \(\mathcal L^{>Q_0}_{N,D}\) 是同一 Bernoulli 主项中 \(h<d\)、
既约分母 \(q>Q_0\) 的余项。则
\[
\boxed{\quad
\sum_{Y<N\le2Y}
|L_{N,D}(\mu)-\mathcal L^{>Q_0}_{N,D}|^2
\ll_\alpha Y^2H^3.
\quad}
\tag{6}
\]
式 (6) 的无条件内容是：即使原始除数上限已达 \(Y^\alpha>Y^{4/5}\)，
全部 \(q\le Y^{4/5}\) 的既约倒数频率以及高谐波、核余项仍处于
\(Y^{2+\varepsilon}\) 量级。未控部分集中在 \(q>Y^{4/5}\)；
这不是完整 moving-\(N\) 均方门的证明。

## 真实 Möbius 频率系数

note 760 式 (14) 的主项为
\[
-\frac1{\pi N}
\sum_{h\ge1}\frac{b_h}{h^2}
\sum_{d\le D}\mu(d)d\log\frac Nd
\cos\frac{2\pi hN}{d},
\qquad b_h=1+2(-1)^h.
\tag{7}
\]
在 \(h<d\) 中唯一约分 \(h=ka,d=kq\)，其中 \(a<q\)、\((a,q)=1\)、
\(k\le D/q\)。恒等式
\(\mu(kq)=\mu(k)\mu(q)\mathbf1_{(k,q)=1}\) 把 (7) 的
\(a/q\) 系数精确化为 (3)，并给
\[
\mathcal L^{\le Q_0}_{N,D}
=-\frac1{\pi N}
\sum_{q\le Q_0}\sum_{\substack{1\le a<q\\(a,q)=1}}
C_{a,q}(N)\cos\frac{2\pi aN}{q}.
\tag{8}
\]

设 \(K=D/q\)，并定义
\[
\begin{aligned}
S_{a,q}(K)&=\sum_{\substack{k\le K\\(k,q)=1}}
\frac{\mu(k)b_{ka}}k,\\
T_{a,q}(K)&=\sum_{\substack{k\le K\\(k,q)=1}}
\frac{\mu(k)b_{ka}\log k}k.
\end{aligned}
\tag{9}
\]
则 (3) 等于
\[
C_{a,q}(N)=\frac{\mu(q)q}{a^2}
\left[\log(N/q)S_{a,q}(K)-T_{a,q}(K)\right].
\tag{10}
\]
由于 \(\alpha>4/5\)，对所有 \(q\le Q_0\) 有
\(K\ge cY^{\alpha-4/5}\to\infty\)，且此幂下界一致。

## 均匀的 Möbius 调和极限

置
\[
A_q(K)=\sum_{\substack{k\le K\\(k,q)=1}}\frac{\mu(k)}k,
\qquad
B_q(K)=\sum_{\substack{k\le K\\(k,q)=1}}
\frac{\mu(k)\log k}k.
\tag{11}
\]
对任意固定 \(\delta>0\)、\(q\le2Y\)、\(K\ge Y^\delta\)，经典
Vinogradov--Korobov 的 \(M(x)\) 界给某个 \(c_\delta>0\)，使
\[
\boxed{\quad
|A_q(K)|+
\left|B_q(K)+\frac q{\varphi(q)}\right|
\ll_\delta e^{-c_\delta\omega(Y)}.
\quad}
\tag{12}
\]
这里允许缩小 \(c_\delta\) 来吸收固定次幂的 \(\log Y\)。

为完整证明其关于 \(q\) 的一致性，先令
\(A(x)=\sum_{k\le x}\mu(k)/k\)、
\(B(x)=\sum_{k\le x}\mu(k)\log k/k\)。
note 767 式 (9) 的 \(M(x)\ll xe^{-b\omega(x)}\)，经分部求和及
\(1/\zeta(s)=(s-1)+O((s-1)^2)\)，给
\[
A(x)=O(e^{-b'\omega(x)}),\qquad
B(x)=-1+O(e^{-b'\omega(x)})
\quad(x\ge3)
\tag{13}
\]
（再缩小 \(b'>0\) 以吸收对数因子）。
令 \(\mathcal V_q\) 是全部素因子都整除 \(q\) 的正整数集。
Euler 因子的逐素数抵消给精确卷积
\[
\mu(k)\mathbf1_{(k,q)=1}
=\sum_{\substack{vm=k\\v\in\mathcal V_q}}\mu(m).
\tag{14}
\]
故
\[
\begin{aligned}
A_q(K)&=\sum_{\substack{v\le K\\v\in\mathcal V_q}}\frac{A(K/v)}v,\\
B_q(K)&=\sum_{\substack{v\le K\\v\in\mathcal V_q}}
\frac{\log v\,A(K/v)+B(K/v)}v.
\end{aligned}
\tag{15}
\]
全部 \(v\) 的倒数和为 \(q/\varphi(q)\ll\log\log(3q)\)，
而 \(\sum_{v\in\mathcal V_q}(\log v)/v\ll
(q/\varphi(q))\log(2q)\)。对 \(v\le K^{1/2}\)，
\(K/v\ge Y^{\delta/2}\)，由 (13) 与这两个和得到
\(O(H^C e^{-c_\delta\omega(Y)})\) 的总误差。

对 \(v>K^{1/2}\) 使用 Rankin 界：
\[
\sum_{\substack{v>K^{1/2}\\v\in\mathcal V_q}}
\frac{1+\log v}{v}
\le K^{-1/4}
\sum_{v\in\mathcal V_q}\frac{1+\log v}{\sqrt v}
\ll K^{-1/4}H e^{C\sqrt H}.
\tag{16}
\]
最后一步中，
\(\prod_{\ell\mid q}(1-\ell^{-1/2})^{-1}\le e^{C\sqrt H}\)：
若 \(q\) 有 \(r\le H/\log2\) 个不同素因子，按大小排列的第 \(j\) 个
至少为 \(j+1\)，故 \(\sum_{\ell\mid q}\ell^{-1/2}\ll\sqrt H\)；
对该乘积求对数导数再给至多 \(O(H)\) 的附加因子。
因 \(K\ge Y^\delta\)，(16) 为 \(e^{-c_\delta H}\) 量级。
在这段 \(v>K^{1/2}\) 上直接用
\(|A(K/v)|\le1+\log K\) 与
\(|B(K/v)|\ll(1+\log K)^2\)；式 (16) 乘上这个固定次幂后仍为
\(e^{-c_\delta H}\)，因为
\(K^{-1/4}(1+\log K)^2H e^{C\sqrt H}\ll_\delta e^{-c_\delta H}\)
对全部 \(K\ge Y^\delta\) 成立。补回 \(\sum_{v>K}1/v\) 时也由 (16) 直接控制。
将 (13)--(16) 合并，即得 (12)。

现在按 \(q,a\) 的奇偶性处理 \(b_{ka}\)：
\[
(S_{a,q},T_{a,q})=
\begin{cases}
3(A_q,B_q),&q\text{ 奇},\ a\text{ 偶},\\
3(A_q,B_q)-4(A_{2q},B_{2q}),&q\text{ 奇},\ a\text{ 奇},\\
-(A_q,B_q),&q\text{ 偶}.
\end{cases}
\tag{17}
\]
当 \(q\) 奇时 \(2q/\varphi(2q)=2q/\varphi(q)\)。
由 (12)、(17) 得一致地
\[
S_{a,q}(K)=O_\alpha(e^{-c_\alpha\omega(Y)}),\qquad
T_{a,q}(K)
=-\lambda_{a,q}\frac q{\varphi(q)}
+O_\alpha(e^{-c_\alpha\omega(Y)}).
\tag{18}
\]
将 (18) 代入 (10)，并吸收 \(\log(N/q)\ll H\)，证明 (4)。

## 低既约频率均方与其余误差

为处理 (10) 中的 \(\log N\)，定义不依赖 \(N\) 的两组系数
\[
U_{a,q}=\frac{\mu(q)q}{a^2}S_{a,q}(D/q),
\qquad
V_{a,q}=\frac{\mu(q)q}{a^2}
\left[-(\log q)S_{a,q}(D/q)-T_{a,q}(D/q)\right].
\tag{19}
\]
于是 (8) 为 \(-(\pi N)^{-1}\) 乘
\(\log N\sum U_{a,q}\cos(2\pi aN/q)
+\sum V_{a,q}\cos(2\pi aN/q)\)。
由 (18)、\(q/\varphi(q)\ll H\) 与
\(\sum_{a\ge1}a^{-4}<\infty\)，有
\[
\sum_{q\le Q_0}\sum_{a<q}|U_{a,q}|^2
\ll_\alpha Q_0^3e^{-c_\alpha\omega(Y)},
\qquad
\sum_{q\le Q_0}\sum_{a<q}|V_{a,q}|^2
\ll_\alpha H^2Q_0^3.
\tag{20}
\]
不同既约 \(a/q\in(0,1)\)、\(q\le Q_0\) 的圆周间距至少
\(Q_0^{-2}\)，数量至多 \(Q_0^2\)。note 762 式 (4) 的
初等间距均方界给任一固定系数列 \(z_{a,q}\)
\[
\sum_{Y<N\le2Y}
\left|\sum_{q,a}z_{a,q}e(aN/q)\right|^2
\ll (Y+Q_0^2H)\sum_{q,a}|z_{a,q}|^2.
\tag{21}
\]
余弦和是复指数和的实部，故受同一界控制。
以 \(1/N\le1/Y\)、\(\log N\ll H\) 及 (19)--(21) 估计 (8)，
\[
\sum_{Y<N\le2Y}|\mathcal L^{\le Q_0}_{N,D}|^2
\ll_\alpha \frac{Y+Q_0^2H}{Y^2}\,
H^2Q_0^3
\ll_\alpha Y^2H^3,
\tag{22}
\]
因 \(Q_0=Y^{4/5+o(1)}\)。这证明 (2)。

note 762 式 (10) 将 \(h\ge d\) 的 Fourier 尾逐 \(N\) 估为
\(O(DH/Y)\)，其平方和为 \(O(D^2H^2/Y)\)。
note 760 式 (14) 的核展开余项逐 \(N\) 为
\(O(D^4H/Y^3)\)，平方和为 \(O(D^8H^2/Y^5)\)。
由于 \(\alpha\le7/8\)，这两项均为 \(O(Y^2H^2)\)。
因此
\[
L_{N,D}(\mu)
=\mathcal L^{\le Q_0}_{N,D}
+\mathcal L^{>Q_0}_{N,D}
+\text{已支付的 Fourier 尾与核余项},
\]
在 \(Y<N\le2Y\) 的平方范数中由 (2) 支付全部低频和余项，
即得 (6)。\(\square\)

## 边界

\(\alpha>4/5\) 保证每个 \(q\le Q_0\) 的重合次数
\(D/q\ge Y^{\alpha-4/5+o(1)}\)，从而 (12) 可一致使用；
\(\alpha\le7/8\) 只来自当前三次核余项的绝对支付。
高既约分母 \(q>Q_0\) 包含 note 763 的真实小素数值固定后仍可能
相干的原始 \(k=1\) 频率。本结果只把实际高除数层的未控部分
定位到这些频率，没有估计它们的 Möbius signed covariance，
不证明 RH。
