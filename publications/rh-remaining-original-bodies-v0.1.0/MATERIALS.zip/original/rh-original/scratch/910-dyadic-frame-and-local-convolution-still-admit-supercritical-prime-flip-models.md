# 两尺度框架与窗内卷积仍容许超目标素数翻转模型

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的完整物理观察、[scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的高素数集合与 [scratch/909](909-two-dyadic-observations-form-the-complete-prime-mobius-frame.md) 的 dyadic 框架。本稿校正一个路线判断：scratch/909 式 (14) 排除的是将模型系数定义为 \(\Lambda_f=f*\log\) **并在两尺度全域继续使用它**的反模型；若两尺度观察使用真实 \(\Lambda\)，相同的翻转可满足全部 dyadic 线性恒等式。缺少的精确条件是 \(\Lambda_f(2p)=\Lambda(2p)\)。本稿是反模型定理，不是实际 Möbius 门的反例或 RH 证明。

## 定理

固定非负、非零的 \(\psi\in C_c^3((1,2))\)，置 \(\phi(t)=\psi(t)/t\)。沿 scratch/904 的偶整数 \(X=2Y\to\infty\)，令 \(H=\lceil Y^{1/5}\rceil\)、\(h_0=\lfloor3H/2\rfloor\)，取其非负偶带通权 \(\eta\)，在 \(1\le|t|\le2\) 上 \(\eta\ge1\)。存在两个**非真实**乘法函数 \(f_{10},f_{11}\)，平方自由支撑且取值于 \(\{0,\pm1\}\)，使：

1. \(f_{ab}(n)=\mu(n)\) 于 \(n\le X\)，且 \((f_{ab}*\log)(m)=\Lambda(m)\) 于 \(m<2X\)。物理窗 \(X<m<2X\) 内，scratch/904 式 (6) 的任意固定对数幂短和及全部固定对数幂小模整除进程资料仍成立。
2. 若使用**真实** von Mangoldt 函数定义
   \[
   \widetilde c_f(n)=2\mathbf1_{2\mid n}(\Lambda(n/2)-1)
   -4(\Lambda(n)-1+(\log2)f(n)),                    \tag{1}
   \]
   则对所有 \(n>1\) 都有 [scratch/908](908-even-observation-and-odd-coefficient-reconstruct-the-prime-error.md) 式 (2) 的真实 dyadic 恒等式；在共同互素支撑上，[scratch/905](905-odd-prime-dilates-give-an-exact-rank-two-cross-scale-frame.md) 的每条固定奇素数倍数关系也成立。[scratch/909](909-two-dyadic-observations-form-the-complete-prime-mobius-frame.md) 的两行逆矩阵与 Fourier 框架逐字适用，只需把 \(\mu\) 换成 \(f\)。
3. 对两个函数中的至少一个，同一物理观察窗的**模型**带通能量满足
   \[
   \boxed{\quad
   \sum_h\eta(h/H)
   \left|\frac1X\sum_{X<m<2X}
   \widetilde c_f(m)\phi(m/X)e(-hm/X)\right|^2
   \gg_{\psi,\eta}\frac{e^{-2\sqrt{\log X}}}{\log^2X}
   \gg\frac{H^4}{X}.
   \quad}                                           \tag{2}
   \]
   同一个模型还使 note 849 式 (15) 的中距离 signed 环带超过目标量级，见下式 (7)。
   首次必然失配的卷积值出现在翻转素数 \(p\in(X,2X)\) 的下一尺度：
   \[
   (f*\log)(2p)=2\log2\ne0=\Lambda(2p).          \tag{3}
   \]

这里的结论是：dyadic 恒等式、有限倍数线、窗内 \(f*\log=\Lambda\) 与已用一阶短和，即使全部同时保留，也不足以推出对整个测试类统一的 \(H^4/X\) 上界。真实 \(f=\mu\) 在下一尺度还满足 (3) 所缺的卷积条件，故该反模型不判定实际门。

## 证明

取 scratch/904 式 (9)--(10) 的两组不交素数 \(S_1,S_2\subset(X,2X)\)。它们各有 \(\gg\delta_X X/\log X\) 个元素，其中 \(\delta_X=e^{-\sqrt{\log X}}\)，且对每个 \(p\in S_1\cup S_2\) 都有
\[
\phi(p/X)\ge c_\psi>0,
\qquad \cos(2\pi h_0p/X)\ge\tfrac12.              \tag{4}
\]
令 \(f_{10}(p)=+1\) 于 \(S_1\)，\(f_{11}(p)=+1\) 于 \(S_1\cup S_2\)，其余素数一律取 \(-1\)，在素数高次幂上取零并乘法延拓。两函数都与 \(\mu\) 在 \(n\le X\) 一致，且都非真实。若 \(n<2X\)，被翻转的素数 \(p>X\) 只能以 \(n=p\) 出现于卷积 \((f-\mu)*\log\)，而其余因子为 \(1\)，权 \(\log1=0\)。所以 \((f*\log)(n)=\Lambda(n)\) 于整个窗内。于是 (1) 在物理窗 \(X<m<2X\) 与 scratch/904 所用的 \(c_f(m)\) 完全相同；该稿已证明的一阶短和与小模进程资料原样保留。

对奇数 \(n>1\)，因为 \(f(2n)=-f(n)\) 且真实 \(\Lambda(2n)=0\)，有
\[
\widetilde c_f(n)=4-4\Lambda(n)-4\ell f(n),
\quad
\widetilde c_f(2n)=2+2\Lambda(n)+4\ell f(n),
\qquad \ell=\log2.                                  \tag{5}
\]
因此 \(\widetilde c_f(2n)+\widetilde c_f(n)-4=2(1-\Lambda(n))\)。偶数 \(n>1\) 有 \(f(2n)=0\)、\(\Lambda(2n)=\Lambda(n)\)，所以 \(\widetilde c_f(2n)=2-2\Lambda(n)\)，同一恒等式也成立。式 (5) 的系数矩阵与 scratch/909 式 (2) 相同，证明两行逆矩阵及其 Fourier 结论。任一固定奇素数 \(q\) 对充分大的 \(X\) 都未被翻转，故 \(f(q)=-1\)；当 \(q\nmid n\) 时，\(f(qn)=-f(n)\)、\(\Lambda(qn)=0\)，从而第三线 \(\widetilde c_f(qn)=4+4\ell f(n)\) 也由两行给出。

连 scratch/908 式 (7) 的 Dirichlet 消元也没有额外排除力。令 \(F(s)=\sum_{n\ge1}f(n)n^{-s}\)、\(x=2^{-s}\)、\(A(s)=\zeta'(s)/\zeta(s)+\zeta(s)\)，在 \(\Re s>1\) 置 \(\widetilde C_f(s)=\sum\widetilde c_f(n)n^{-s}\) 及 \(\widetilde E_f(s)=\sum_{2\mid n}(\widetilde c_f(n)-4)n^{-s}\)。因 \(f(2n)=-f(n)\) 于奇数 \(n\)、\(f(2n)=0\) 于偶数 \(n\)，偶数部分的 Dirichlet 级数为 \(-xF(s)/(1-x)\)。直接求和得
\[
\widetilde C_f=(4-2x)A-4\ell F,
\quad
\widetilde E_f=-2xA-\frac{4\ell x}{1-x}
+\frac{4\ell x}{1-x}F,
\quad
\widetilde C_f+(2^s-1)\widetilde E_f=2A-4\ell.   \tag{5a}
\]
这里翻转集合有限，若其并集为 \(S\)，则 \(F(s)=\zeta(s)^{-1}\prod_{p\in S}(1+p^{-s})/(1-p^{-s})\) 在 \(\Re s>1\)，并可亚纯延拓。因此该代数消元及其素数误差极点结论对本反模型仍成立。\(F\) 与 \(1/\zeta\) 不同；正是全域卷积条件 \(\Lambda=f*\log\) 在 (3) 处失败。

在物理窗内，\(f_{10}\) 与 \(f_{11}\) 的系数仅在 \(p\in S_2\) 不同：\(p>X\) 的非素数倍数都落在 \(2X\) 之外。若 \(A_h(f)\) 是 (2) 中绝对值内的包，则
\[
A_{h_0}(f_{11})-A_{h_0}(f_{10})
=-\frac{8\ell}{X}\sum_{p\in S_2}
\phi(p/X)e(-h_0p/X).                              \tag{6}
\]
由 (4) 取实部，式 (6) 的模至少为 \(4\ell c_\psi|S_2|/X\gg\delta_X/\log X\)。三角不等式使 \(f_{10},f_{11}\) 至少有一个满足 \(|A_{h_0}(f)|\gg\delta_X/\log X\)，而 \(\eta(h_0/H)\ge1\)，故 (2) 的第一个下界成立。\(H^4/X\asymp X^{-1/5}\)，而 \(e^{-2\sqrt{\log X}}/\log^2X=X^{-o(1)}\)，所以第二个严格超目标比较也成立。

为把此下界接到真正的中距离过滤，固定 \(0<\delta<1/5\)，令 \(K_0=H^3/\log^2X\)、\(K_1=(X/2)^{1+\delta}/H\)、\(a_m(f)=X^{-1}\widetilde c_f(m)\phi(m/X)\)、\(K_H(r)=\sum_h\eta(h/H)e(-hr/X)\)。由于 \(|f|\le1\)，且 \(\widetilde c_f\) 的其余算术部分是真实 \(\Lambda\)，note 849 式 (16) 的 \(\ell^1,\ell^2\) 界对两个模型仍一致成立。该稿式 (14) 的近差绝对支付和式 (17)--(18) 的远差支付于是原样适用，费用分别为 \(O(H^4/(X\log X))\) 与 \(O_B(X^{-B})\)，均为 \(o(\delta_X^2/\log^2X)\)。由完整非负能量 (2) 扣去这两段，对其中同一个 \(f\) 得到
\[
\boxed{\quad
\sum_{K_0<|m-n|\le K_1}a_m(f)a_n(f)K_H(m-n)
\gg_{\psi,\eta,\delta}\frac{\delta_X^2}{\log^2X}
\gg\frac{H^4}{X}.
\quad}                                             \tag{7}
\]
这里保留模型系数的真实符号；(7) 是对 note 849 式 (15) 在这一测试类上的统一推断的反例，不是实际 \(f=\mu\) 的下界。

最后对翻转的 \(p\) 直接展开卷积：\(f(2)=-1\)，故
\[
(f*\log)(2p)=\log(2p)-\log p+f(p)\log2
=\ell(1+f(p))=2\ell,
\]
而真实 \(\Lambda(2p)=0\)，证明 (3)。同一公式说明若强制下一尺度的真实卷积值，则每个此类高素数都必须有 \(f(p)=-1\)，反模型即消失。\(\square\)

这个检测地平线是尖锐的。对任意 \(X<p<2X\)，改变 \(f(p)\) 首次能改变 \((f*\log)(n)\) 的正整数是 \(n=2p\)：\(n=p\) 的对应权为 \(\log1=0\)，而 \(p<n<2p\) 没有 \(p\) 的倍数。因此只知道 \((f*\log)(n)=\Lambda(n)\) 于 \(n<T\) 时，所有 \(p>\max\{X,T/2\}\) 的窗内素数符号仍自由。\(T=4X\) 足以逐个固定窗内全部素数符号；对任意固定 \(\epsilon>0\)，若 \(T\le(4-\epsilon)X\)，素数定理保证充分大 \(X\) 时仍有 \(p\in(T/2,2X)\) 未被检测。这说的是高素数符号的信息范围，并不产生频带能量上界。

## 边界

本稿的 \(\widetilde c_f\) 在 \(2p\) 处使用真实 \(\Lambda\)，故不能冒充由 \(f*\log\) 在所有尺度定义的真实算术系数。它量化了线性跨尺度框架与**全域**卷积结构的区别。目标 [note 849 式 (15)](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 对 \(f=\mu\) 仍完全开放；下一次有效进攻须在同一 signed 二点 Gram 中利用 \(\Lambda(2p)=0=(\mu*\log)(2p)\) 的真耦合，而不能只加更多倍数线或零组合。

支持范围还有一个直接限制：note 849 式 (12) 的 \(a_m\) 仅在 \(X<m<2X\) 非零，故对任意素数 \(p\)，\(a_p a_{2p}=0\)。因此 \(\Lambda(2p)=0\) 不能在该**单窗** Gram 中作为一条 \(p\leftrightarrow2p\) 的直接配对边；它只能通过 \(a_{2p}\) 的系数值（当 \(p<X\)）或跨相邻尺度的关系进入。上段“同一 Gram 中利用”的意思应限于先把该全域关系消元进窗内系数，再估计剩余二点项；单独添加跨窗负相关不是 note 849 式 (15) 的上界。
