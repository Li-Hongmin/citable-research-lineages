# 对数 Fourier 轮廓可增长至 \(o(\log N)\) 的 Weil 正压缩

日期：2026-10-03。依赖 [note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的精确整除图平方差与 [note 859](../notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md) 的固定赋值常数块严格正隙。相比 [scratch 980](980-slowly-growing-log-profile-spaces-remain-weil-positive.md) 的 \(r=o(\sqrt{\log N})\)，这里直接估计非负 prime-shift 平方差，把 Fourier 阶数扩至 \(r=o(\log N)\)。这是局部 Weil 形式的受限压缩定理；尚待异源独立复核，不证明全尺度正性或 RH。

## 定理

沿奇素数 \(p\to\infty\)，置
\[
H=\log p,\quad N=(p^2-5)/4,\quad L=\log N,\quad
L_N=\sum_{n\le N}n^{-1},\quad \ell=c/p^2,\quad 0<c<4,
\quad y_n=H-\log4-\log n,
\]
其中 \(c\) 固定。固定实单位轮廓 \(\varphi\in C_c^\infty((-1/2,1/2))\)，令
\(b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)\)。固定有限素数集 \(B\) 及正整数截断赋值阶数 \(J_q\ge1\)（零阶坐标直接删去），令 \(\mathcal E_B\) 为只依赖
\((\min(\nu_q(n),J_q))_{q\in B}\) 的实函数空间。其内积为
\(\langle F,G\rangle_B=\mathbb E_{\pi_B}(FG)\)，其中各素数赋值依参数 \(\pi_q(j)=(1-q^{-1})q^{-j}\) 分布；空集时 \(\mathcal E_B=\mathbb R\)。

令整数 \(r_p\ge0\) 满足 \(r_p=o(L)\)，并令
\[
V_{r_p}=\operatorname{span}_{\mathbb R}
\{1,\cos(2\pi jx),\sin(2\pi jx):1\le j\le r_p\}.
\]
对 \(u\in\mathcal E_B\otimes V_{r_p}\)，在槽
\(y_n+(-\ell/2,\ell/2)\) 内定义
\[
(\mathcal T_Nu)(y_n+t)
=\frac{u(\boldsymbol\nu(n),\log n/L)}{\sqrt{nL_N}}\,b_\ell(t),
\qquad 1\le n\le N,                                      \tag{1}
\]
槽外置零。则充分大的 \(p\) 上 \(\mathcal T_N\) 单射，且 \(Q_W^H\) 在整个
\(\mathcal T_N(\mathcal E_B\otimes V_{r_p})\) 上严格正。

更定量地，以 \(\mathcal E_B\) 内积在 \(x\) 上积分，唯一分解
\(u(x)=F+w(x)\)、\(F=\int_0^1u(x)dx\)、\(\int_0^1w(x)dx=0\)。存在只依赖固定 \(B,J,c,\varphi\) 的常数 \(C\)，使
\[
\begin{aligned}
\|\mathcal T_Nu\|_2^2
 &=\|u\|_{L^2([0,1];\mathcal E_B)}^2
   +O\!\left(\frac{1+r_p}{L}\|u\|_2^2\right),\\
Q_W^H[\mathcal T_N w]
 &=L\|w\|_2^2+O\bigl((1+r_p)\|w\|_2^2\bigr),\\
|Q_W^H(\mathcal T_NF,\mathcal T_Nw)|
 &\le C\sqrt{1+r_p}\,\|F\|_B\|w\|_2.                 \tag{2}
\end{aligned}
\]
常数块的形式收敛于 note 859 式 (3) 的极限算子 \(\mathscr L_B\)，且
\[
\mathscr L_B\succeq \delta I,\qquad
\delta=46/25-\log(2\pi)>0.                              \tag{3}
\]
因此对充分大的 \(p\)，
\[
Q_W^H[\mathcal T_Nu]
\ge \frac\delta2\|F\|_B^2+\frac L2\|w\|_2^2.        \tag{4}
\]
恰有 \(\dim\mathcal E_B\) 个有界 Rayleigh 本征值趋于
\(\mathscr L_B\) 的本征值，其余均为 \(L(1+o(1))\)。

## 证明

**几何与精确算术分解。** note 859 的槽位、宽度及共同轮廓正是这里的选择；\(N(e^\ell-1)<1\) 使 prime-shift 仅连接整数整除对。note 854 式 (12) 的 ground-state 恒等式，对任意槽系数 \(v_n\) 和 \(g_n=v_n/\sqrt{nL_N}\) 给
\[
\langle g,C_Ng\rangle
=\frac1{L_N}\sum_{n\le N}\frac{d_n|v_n|^2}{n}
-\mathcal D_N(v),
\quad d_n=M_1(N/n)+\log n=L+O(1),                         \tag{5}
\]
\[
\mathcal D_N(v)=\frac1{L_N}\sum_{k\ge2}\frac{\Lambda(k)}k
\sum_{n\le N/k}\frac{|v_n-v_{kn}|^2}{n}\ge0.
\tag{6}
\]
这里 \(k\) 仅为素数幂。note 857 的同槽公式给共同轮廓成本
\(D_\ell=L+O_{c,\varphi}(1)\)。普通跨槽核及 polar 项分别可按自然权绝对求和：若
\(v_n=u(\boldsymbol\nu(n),\log n/L)\)，则其双线性式满足
\[
|Q_{\rm ord}(u,v)|+|Q_{\rm pol}(u,v)|
\le C_{B,c,\varphi}\|u\|_{\infty,B}\|v\|_{\infty,B}. \tag{7}
\]
确实 note 857 的离散 Cauchy 核给
\(\ell L_N^{-1}\sum_{n<r}((r-n)^{-1}+(r+n)^{-1})=O(\ell N)=O(1)\)；两个 polar 矩的自然权乘积同为 \(O(\ell N)\)。固定有限维的赋值范数控制各状态上确界。合并 (5)--(7)，得到
\[
Q_W^H[\mathcal T_Nu]
=\mathcal D_N(u)+\mathcal R_N(u),\qquad
|\mathcal R_N(u,v)|\le C\|u\|_{\infty,B}\|v\|_{\infty,B}, \tag{8}
\]
其中 \(\mathcal R_N\) 包含有界系数 \(D_\ell-d_n\) 的对角项、普通核及 polar；常数独立于 \(N,r_p\)。式 (8) 作为双线性式成立。注意 (8) 单独只给 \(O(1+r_p)\) 的高块误差，低块的精确常数由 note 859 保留。

**双对数测度引理。** 令 \(P=\prod_{q\in B}q^{J_q}\)。对赋值状态 \(\alpha\) 的指标 \(e_\alpha(n)\)，固定模数调和计数给
\[
B_\alpha(s):=\sum_{n\le e^s}\frac{e_\alpha(n)}n
=\pi_B(\alpha)s+O_B(1),
\tag{9}
\]
其中截断最大状态的概率按几何尾合并。删去 \(q\mid P\) 的素数幂后，note 854 的 \(M_1\) 界给
\[
A_B(t):=\sum_{\substack{k\le e^t\\(k,P)=1}}\frac{\Lambda(k)}k
=t+O_B(1).                                                \tag{10}
\]
空集时 (9) 是调和计数、(10) 是全部素数幂。

设 \(z:[0,1]\to\mathcal E_B\) 是连续的 \(H^1\) 函数，并定义
\(K(z)=\|z\|_{\infty,B}^2+\|z\|_2\|z'\|_2\)。由 (9)--(10) 分别作一次 Stieltjes 分部积分，得到精确量纲的误差界
\[
\boxed{\mathcal D_N^{\rm unit}(z)
=L\left(\|z\|_2^2-\left\|\int_0^1z(x)dx\right\|_B^2\right)
 +O_B(K(z)).}                                               \tag{11}
\]
这里 unit 指 (6) 中 \((k,P)=1\) 的素数幂。逐状态证明 (11) 即可：置
\(G(s,t)=|z_\alpha(s/L)-z_\alpha((s+t)/L)|^2\) 于
\(s,t\ge0,s+t\le L\)。固定 \(t\) 时，
\[
\sup_sG+\operatorname{Var}_sG
\ll \|z_\alpha\|_\infty^2
    +\|z_\alpha\|_2\|z_\alpha'\|_2.                 \tag{12}
\]
因 \(\operatorname{Var}_sG\le
2L^{-1}\int|\Delta z|(|z_\alpha'|(s/L)+|z_\alpha'|((s+t)/L))ds\)，Cauchy--Schwarz 给 (12)。以 (9) 把 \(dB_\alpha(s)\) 换成 \(\pi_B(\alpha)ds\) 后，每个 \(t\) 的误差为 (12) 乘固定常数；(10) 给 \(A_B(L)=O(L)\)，故除以 \(L_N\) 的总误差为 \(O_B(K(z))\)。

剩下的积分写成 \(J(t)=\int_0^{L-t}G(s,t)ds\)。直接求导并处理移动上限，得到
\[
\sup_{0\le t\le L}|J(t)|+\operatorname{Var}_{[0,L]}J
\ll L\bigl(\|z_\alpha\|_\infty^2+
                \|z_\alpha\|_2\|z_\alpha'\|_2\bigr). \tag{13}
\]
确实上限项积分至多 \(4L\|z_\alpha\|_\infty^2\)；内部导数逐 \(t\) 用 Cauchy--Schwarz 至多 \(C\|z_\alpha\|_2\|z_\alpha'\|_2\)。用 (10) 把 \(dA_B(t)\) 换成 \(dt\)，再除以 \(L_N\)，费用仍为 \(O_B(K(z))\)。连续双积分严格为
\[
\frac1{L_N}\int_{s+t\le L}
 \|z(s/L)-z((s+t)/L)\|_B^2\,ds\,dt
=L\left(\|z\|_2^2-\left\|\int z\right\|_B^2\right)
 +O(K(z)),
\]
因为 \(L_N=L+O(1)\)。这证明 (11)。

**高模、交叉和范数。** 令 \(w\) 为零均值的 \(\mathcal E_B\)-值三角多项式，最高频率 \(r=r_p\)。Parseval、Cauchy--Schwarz 给
\[
\|w'\|_2\le2\pi r\|w\|_2,
\qquad \|w\|_{\infty,B}^2\le(2r+1)\|w\|_2^2,
\quad K(w)\ll(1+r)\|w\|_2^2.                              \tag{14}
\]
由 (11)，\(\mathcal D_N^{\rm unit}(w)=L\|w\|_2^2+O_B((1+r)\|w\|_2^2)\)。坏素数 \(q\in B\) 的 (6) 部分非负，且用
\(\sum_{q\in B,j\ge1}(\log q)q^{-j}<\infty\) 与 \(\|w\|_\infty^2\) 得
\(0\le\mathcal D_N^{\rm bad}(w)\ll_B(1+r)\|w\|_2^2\)。式 (8) 与 (14) 遂给 (2) 的高块等式。

若 \(F\in\mathcal E_B\) 不依赖 \(x\)，则在任意 unit 边上
\(F(\boldsymbol\nu(n))=F(\boldsymbol\nu(kn))\)，所以
\(\mathcal D_N^{\rm unit}(F,w)=0\) **精确成立**。坏边的低块差与高块差分别由 \(C_B\|F\|_B\)、\(2C_B\|w\|_{\infty,B}\) 控制；各边的总归一化调和权为 \(O_B(1)\)，故
\[
|\mathcal D_N^{\rm bad}(F,w)|
\ll_B\|F\|_B\|w\|_{\infty,B}
\ll_B\sqrt{1+r}\,\|F\|_B\|w\|_2.                  \tag{15}
\]
式 (8) 对余项给相同界，证明 (2) 的交叉式。

为证范数式，(9) 对 \(u(x)\) 的各状态平方作分部积分。三角多项式满足
\(\sup_x\|u(x)\|_B^2+\operatorname{Var}_x\|u(x)\|_B^2
\ll(1+r)\|u\|_2^2\)，后者来自
\(2\int\|u\|_B\|u'\|_B\le4\pi r\|u\|_2^2\)。除以 \(L_N\) 得 (2) 第一式。

**低块和 Schur 配方。** 对常数 \(F\)，note 859 式 (3)--(4) 在完全相同的槽几何给
\[
Q_W^H[\mathcal T_NF]
=\mathscr L_B(F)+o(1)\|F\|_B^2,
\quad \mathscr L_B\succeq\delta I.                          \tag{16}
\]
这是固定有限维上的统一收敛，可由实极化取得。由 (2)、(16)，
\[
Q_W^H[\mathcal T_N(F+w)]
\ge(\delta-o(1))\|F\|_B^2
 +(L-C(1+r))\|w\|_2^2
 -2C\sqrt{1+r}\,\|F\|_B\|w\|_2.
\]
因 \((1+r)/L\to0\)，配方后低块只损失
\(O((1+r)/L)=o(1)\)，高块仍为 \(L(1+o(1))\)。这证明 (4)。同一个块矩阵 Schur 论证、(16) 的固定维低块及范数式，给出本征值结论。\(\square\)

## 边界

此处的 \(r=o(\log N)\) 是整个三角多项式空间的统一结论，比控制单个轮廓更强；有限素数赋值集合、共同微观轮廓及固定 \(c<4\) 仍是限制。证明用的是完整真实 Weil 形式和 prime-shift 的实际整除图，但没有控制槽外 true-Schur 交叉，也没有得到 note 849 式 (15) 的固定幂算术界。
