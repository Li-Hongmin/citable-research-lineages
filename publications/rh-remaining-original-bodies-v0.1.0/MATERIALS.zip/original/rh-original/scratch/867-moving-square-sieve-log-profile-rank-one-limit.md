# 任意移动素数平方筛下的宏观对数轮廓秩一极限

日期：2026-10-02。依赖 [note 862](../notes/862-arbitrary-moving-prime-square-sieves-retain-maximal-weil-gap.md) 的一致平方筛计数与固定轮廓正隙，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除矩阵，以及 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的完整 Weil 格分解。无筛版本另见 [scratch 866](866-macroscopic-log-profiles-have-rank-one-prime-limit.md)。以下为解析证明草稿，尚待独立复核。

## 定理候选

沿奇素数 $p\to\infty$，置 $H=\log p$、$M=(p^2-5)/4$、$L=\log M$、$\ell=c/p^2$，其中 $0<c<4$ 固定。每个 $p$ 任取素数集合 $\mathcal P_p$，允许其为空、有限或无限；写
\[
T_p(n)=\prod_{q\in\mathcal P_p}\mathbf1_{q^2\nmid n},
\qquad \alpha_p=\prod_{q\in\mathcal P_p}(1-q^{-2})
\in[\zeta(2)^{-1},1].
\]
固定非零复值 $g\in C^1([0,1])$、实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$，令 $b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$、$t_n=\log n/L$，并在 note 857 的槽中心 $y_n=H-\log4-\log n$ 处定义
\[
W_{p,g}=\sum_{n\le M}\frac{T_p(n)|g(t_n)|^2}{n},
\qquad
f_{p,g}(y_n+t)=\frac{T_p(n)g(t_n)}{\sqrt{nW_{p,g}}}b_\ell(t)
\quad(|t|<\ell/2),
\]
其余处为零。则对充分大 $p$，$W_{p,g}>0$、$\|f_{p,g}\|_2=1$，且对**所有**随 $p$ 变化的素数集合一致有
\[
\boxed{\quad
Q_W^H[f_{p,g}]
=L\frac{\int_0^1|g(t)-\bar g|^2dt}{\int_0^1|g(t)|^2dt}
+O_{g,c,\varphi}(1),
\qquad \bar g=\int_0^1g(t)dt.
\quad}                                                     \tag{1}
\]
更精确地，若 $v_n=T_p(n)g(t_n)/\sqrt n$，则真实素数幂整除矩阵 $C_M$ 满足一致的
\[
\boxed{\quad
\langle v,C_Mv\rangle=\alpha_pL^2|\bar g|^2+O_g(L),
\qquad
W_{p,g}=\alpha_pL\int_0^1|g|^2+O_g(1).
\quad}                                                     \tag{2}
\]
所以每个固定非常数 $g$ 在此**任意移动平方筛**全族中都有线性增长的严格正 Weil 能量。若 $g$ 为非零常数，式 (1) 只给有界主阶；[note 862](../notes/862-arbitrary-moving-prime-square-sieves-retain-maximal-weil-gap.md) 式 (3) 已给相同量词下的一致严格正隙。因此每个固定非零 $g$，无论是否常数，这整族试函数对充分大 $p$ 一致严格为正。

进一步，任取一个先固定、包含常数函数的有限维复线性空间 $V\subset C^1([0,1])$。则存在 $p_0(V,c,\varphi)$，使对所有奇素数 $p\ge p_0$、所有 $\mathcal P_p$ 及所有非零 $g\in V$，都有
\[
\boxed{\qquad Q_W^H[f_{p,g}]>0.\qquad}                    \tag{2a}
\]
式 (2a) 允许 $g$ 的坐标随 $p$ 任意改变；特别适用于任意固定次数上界的全部多项式轮廓。此结论的证明见末节。

## 移动平方筛的对数尺度分布

note 862 式 (4) 给对所有 $\mathcal P_p$ 一致的
\[
A_p(x):=\sum_{n\le x}T_p(n)=\alpha_px+O(\sqrt x)
\qquad(x\ge1).                                            \tag{3}
\]
对任意固定 $F\in C^1([0,1])$，把 $x\mapsto F(\log x/L)/x$ 与 (3) 作 Abel 求和，得
\[
\boxed{\quad
\sum_{n\le M}\frac{T_p(n)}nF(t_n)
=\alpha_pL\int_0^1F(t)dt
+O_F(1),
\quad}                                                     \tag{4}
\]
其中常数对素数集合一致。确实，边界误差为 $O_F(M^{-1/2})$；积分误差由
\[
\int_1^M\sqrt x\,
\left|\frac{d}{dx}\frac{F(\log x/L)}x\right|dx
\ll\|F\|_\infty+L^{-1}\|F'\|_\infty
\]
控制。取 $F=|g|^2$ 即得 (2) 的第二式，并因 $\alpha_p\ge\zeta(2)^{-1}$、$\int|g|^2>0$ 得到 $W_{p,g}\asymp_gL$，一致于移动筛。

## 素数幂整除图只留秩一主阶

令 $A(x)=\sum_{2\le k\le x}\Lambda(k)/k$。note 854 式 (3) 给 $A(x)=\log x+O(1)$ 对 $x\ge1$ 一致。对 $t\in[0,1]$，Stieltjes 分部积分给
\[
\sum_{2\le k\le e^{L(1-t)}}\frac{\Lambda(k)}k
g\!\left(t+\frac{\log k}{L}\right)
=L\int_t^1g(s)ds+O_g(1),                              \tag{5}
\]
误差对 $t$ 一致，由有界端点和 $g$ 在 $[t,1]$ 上的总变差控制。

整除矩阵的两条对称臂给精确式
\[
\langle v,C_Mv\rangle
=2\operatorname{Re}\sum_{n\le M}\frac{T_p(n)\overline{g(t_n)}}n
\sum_{2\le k\le M/n}\frac{\Lambda(k)}k
T_p(kn)g\!\left(t_n+\frac{\log k}{L}\right).              \tag{6}
\]
可在 (6) 的内和中将 $T_p(kn)$ 替换为 $T_p(n)$，且总误差为 $O_g(L)$，对 $\mathcal P_p$ 一致。为核准这一关键步，令 $k=q^j$ 为素数幂。

若 $q\notin\mathcal P_p$，则 $T_p(q^jn)=T_p(n)$。若 $q\in\mathcal P_p$、$j\ge2$，则 $T_p(q^jn)=0$；相应误差的绝对值至多
\[
2\|g\|_\infty^2
\sum_{q\in\mathcal P_p}(\log q)
\sum_{j\ge2}q^{-j}\sum_{n\le M/q^j}\frac1n
\ll_g L\sum_q(\log q)\sum_{j\ge2}q^{-j}
=O_g(L).                                                \tag{7}
\]
若 $q\in\mathcal P_p$、$j=1$，则 $T_p(n)-T_p(qn)$ 只可能在 $T_p(n)=1$ 且 $q\mid n$ 时非零；放宽到全部 $n=qm$ 得误差至多
\[
2\|g\|_\infty^2
\sum_{q\in\mathcal P_p}\frac{\log q}{q}
\sum_{\substack{n\le M/q\\q\mid n}}\frac1n
\le2\|g\|_\infty^2L
\sum_q\frac{\log q}{q^2}
=O_g(L).                                                \tag{8}
\]
式 (7)--(8) 的素数级数绝对收敛，故移动、无限集合不会改变误差常数。

替换后的 (6) 中 $T_p(n)^2=T_p(n)$。用 (5) 支付内和误差 $O_g(\sum T_p(n)/n)=O_g(L)$，再对
$F(t)=\overline{g(t)}\int_t^1g(s)ds\in C^1([0,1])$ 用 (4)，得到
\[
\langle v,C_Mv\rangle
=2\alpha_pL^2\operatorname{Re}
\int_{0<t<s<1}\overline{g(t)}g(s)dt\,ds+O_g(L).
\]
三角形及其镜像填满单位方形，故两倍实部为 $|\bar g|^2$；这证明 (2) 的第一式。

## 完整 Weil 项

note 857 的槽几何在 $0<c<4$ 下强迫素数幂位移精确对应 $r=kn$，因此 (2) 的整除矩阵项在 Weil 形式中以负号除以 $W_{p,g}$。由 $\alpha_p\ge\zeta(2)^{-1}$，其归一化值一致为
\[
-L\frac{|\bar g|^2}{\int_0^1|g|^2}+O_g(1).         \tag{9}
\]
同槽 Fourier 与光滑余项为 $\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)=L+O_{c,\varphi}(1)$。普通跨槽中心核的绝对值至多 $\|g\|_\infty^2\sum_{n<r}[(r-n)^{-1}+(r+n)^{-1}]\ll_g ML$；它在 Weil 形式中乘 $\ell(\int\varphi)^2/W_{p,g}$，因 $\ell M\to c/4$ 而总共为 $O_{g,c,\varphi}(1)$。note 857 的中心替换误差在 $|T_pg|\le\|g\|_\infty$ 下也一致为 $o(1)$。

极点项的复值两矩公式为
\[
Q_{\rm pol}[f_{p,g}]
=\frac{2m_+m_-}{W_{p,g}}\operatorname{Re}\!\left[
\left(\sum_{n\le M}\frac{T_p(n)g(t_n)}n\right)
\overline{\left(\sum_{n\le M}T_p(n)g(t_n)\right)}\right].
\]
其绝对值由
$|\sum_{n\le M}T_p(n)g(t_n)/n|\ll_gL$、
$|\sum_{n\le M}T_p(n)g(t_n)|\ll_gM$、
$|m_+m_-|\ll_\varphi\ell$ 和 $W_{p,g}\gg_gL$ 控制为 $O_{g,c,\varphi}(1)$。合并上述各式、$\log(1/\ell)=L+O_c(1)$ 及
$\int|g-\bar g|^2=\int|g|^2-|\bar g|^2$，得到 (1)。$\square$

## 固定有限维空间的一致正性

令 $V\subset C^1([0,1])$ 为固定有限维空间，$1\in V$，并将上面的归一化二次型乘回其范数：
\[
\mathscr Q_{p,\mathcal P}(g)=W_{p,g}Q_W^H[f_{p,g}].
\]
它对 $g\in V$ 是 Hermitian 二次型，零向量处按零延拓。上面的每项估计都由 $\|g\|_{C^1}^2$ 控制，而 $V$ 上 $C^1$ 范数与 $L^2[0,1]$ 范数等价；因此 (1) 的证明实际给出**一致的二次型余项**
\[
\mathscr Q_{p,\mathcal P}(g)
=\alpha_pL^2\|g-\bar g\|_{L^2}^2+\mathscr E_{p,\mathcal P}(g),
\qquad |\mathscr E_{p,\mathcal P}(g)|
\le C_{V,c,\varphi}L\|g\|_{L^2}^2,                         \tag{10}
\]
对所有筛集合一致。由 Hermitian 极化，$\mathscr E$ 的双线性形式满足
$|\mathscr E(a,h)|\le C'_{V,c,\varphi}L|a|\|h\|_2$。

将 $g=a+h$ 唯一写成常数 $a=\bar g$ 与 $h\in V$、$\int_0^1h=0$。取 $\delta=46/25-\log(2\pi)>0$、$\alpha_0=\zeta(2)^{-1}$。note 862 的移动筛正隙及 $W_{p,a}\ge(\alpha_0/2)L|a|^2$ 给充分大 $p$ 时
\[
\mathscr Q(a)\ge\frac{\delta\alpha_0}{4}L|a|^2.
\]
式 (10) 对 $h$ 给
$\mathscr Q(h)\ge(\alpha_0L^2-CL)\|h\|_2^2\ge(\alpha_0/2)L^2\|h\|_2^2$。主项在常数与均值零空间之间没有交叉，故
\[
\mathscr Q(a+h)
\ge\frac{\delta\alpha_0}{4}L|a|^2
+\frac{\alpha_0}{2}L^2\|h\|_2^2
-2C'L|a|\|h\|_2.
\]
用 $2C'L|a|\|h\|_2\le(\alpha_0/4)L^2\|h\|_2^2+(4C'^2/\alpha_0)|a|^2$，右侧在充分大 $L$ 时严格正，除非 $a=h=0$。这证明 (2a)。$\square$

## 边界

这是一类随尺度变化的真实平方自由筛与固定宏观对数轮廓的**完整局部 Weil Rayleigh 渐近**。它不提供对所有 $g_p$ 的统一下界：$g_p$ 若向常数靠拢，式 (1) 的 $O_{g,c,\varphi}(1)$ 不能单独保证正性；若在素数赋值或单槽尺度振荡，也不属于命题。格与补空间的 Schur 交叉以及 moving-$N$ Möbius signed covariance 仍开放。
