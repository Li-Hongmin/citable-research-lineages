# 多项式外槽的异臂精确共振在算子范数中消失（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的异臂矩阵，独立于 forcing 系数证明其 \(\delta=0\) 部分可以删去。若与 [scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的 forcing 主项合用，留下的有符号门完全落在 \(\delta\ne0\) 的短移位配对。尚缺异源独立复核，留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，令 \(B=\lfloor p^\beta\rfloor\)，固定 \(0<\beta<1/2\)，并取 scratch 818 的外槽族

\[
\mathcal Y_{p,B}
=\{m/b:2\le b\le B,\ p\le m<bp,\ (m,b)=1\}.
\]

定义异臂算术矩阵的精确共振部分

\[
N^0_{p,B}(y,y')
=
\begin{cases}
\Lambda(yy')/\sqrt{yy'},&yy'\text{ 为整数素数幂},\\
0,&\text{否则}.
\end{cases}
\tag{1}
\]

它正是 scratch 818 式 (4) 中满足 \(\delta=nbb'-mm'=0\) 的项，因为阶跃重叠核满足 \(R_\Delta(0)=1\)。对任意固定 \(\varepsilon>0\)，有

\[
\boxed{\ \|N^0_{p,B}\|_{\rm op}
\ll_{\beta,\varepsilon}
(\log p)^2\,B\,p^{-1+\varepsilon}
\ll p^{-1+\beta+o(1)}=o(1).\ }
\tag{2}
\]

因此对任意目标系数向量 \(u\in\ell^2(\mathcal Y_{p,B})\)，包括 scratch 819 的真实 forcing \(t\)，

\[
|\langle u,N^0_{p,B}u\rangle|
=o(1)\|u\|^2.
\tag{3}
\]

特别地，若取 scratch 819 的 \(t\)，则 \(\|t\|^2=O((\log p)^4)\)，所以 \(\langle t,N^0_{p,B}t\rangle=o((\log p)^4)\)。欲控制 scratch 818 的异臂二次型在 \((\log p)^5\) 尺度上的下界，只需处理 \(0<|\delta|<B^2\) 的真正近共振；精确重合不提供该尺度的正贡献。

## 证明

设 \(y=m/b,y'=m'/b'\in\mathcal Y_{p,B}\)，且 \(yy'=n\) 是整数素数幂。由
\[
n b b'=mm'
\tag{4}
\]
及 \((m,b)=(m',b')=1\)，分别得到 \(b\mid m'\) 与 \(b'\mid m\)。于是写成
\[
m=b'r,\qquad m'=bs,\qquad n=rs.
\tag{5}
\]
因为 \(m,m'\ge p>B^2\ge b,b'\)，有 \(r,s>1\)。又因 \(n=\ell^j\) 是素数幂，必有
\[
r=\ell^i,\qquad s=\ell^{j-i},\qquad 1\le i<j.
\tag{6}
\]
特别地，若 \(b=b'\)，则 \(b\mid m\) 与 \((m,b)=1\) 矛盾；所以 (1) 没有对角元。

固定一行 \(y=m/b\)。满足 (5)--(6) 的 \(b'\) 必为 \(m\) 的一个不超过 \(B\) 的正因子；这样的选择不超过 \(\tau(m)\)。一旦 \(b'\) 固定，\(\ell\) 和 \(i\) 由 \(m/b'=\ell^i\) 唯一确定。允许的 \(s=\ell^{j-i}\) 由 \(m'=bs\in[p,b'p)\) 限制，因而其指数选择至多 \(O(\log(Bp))=O(\log p)\) 个。故该行非零元数不超过 \(O(\tau(m)\log p)\)。

对每个这种非零元，由 \(r=m/b'\ge p/B\)、\(s=m'/b\ge p/B\)，
\[
|N^0_{p,B}(y,y')|
=\frac{\log\ell}{\sqrt{rs}}
\ll_\beta\frac{B\log p}{p}.
\tag{7}
\]
又 \(m<Bp\)，标准除数界 \(\tau(m)\ll_\varepsilon m^\varepsilon\) 给每行绝对和
\[
\sum_{y'}|N^0_{p,B}(y,y')|
\ll_{\beta,\varepsilon}
\frac{B(\log p)^2}{p}\,p^\varepsilon.
\tag{8}
\]
矩阵实对称，故列和同界。Schur 行列和检验得到 (2)；(3) 随即成立。\(\square\)

## 非零移位中与 forcing 素数重合的通道

在 scratch 819 的素数 forcing 展开中，一对目标分子可写为 \(m=aq,\ m'=a'r\)，其中 \(q,r\) 为素数、\(a,a'<Q\)，且 \(q,r>p/Q>B\)。若 \(q=r=\ell\)，而异臂平移指标为 \(n=\ell^j\)、\(j\ge2\)，则
\[
\delta=n b b'-mm'
=\ell^2(\ell^{j-2}bb'-aa').
\]
因 \(|\delta|<B^2<\ell^2\)，只能有 \(\delta=0\)；这部分已由 (2) 统一支付。

更一般地，若额外取 \(1-\alpha>2\beta\)，则 \(q,r>p/Q>B^2\)。只要平移素数幂 \(n\) 的底素数等于 \(q\) 或 \(r\)，相应大素数便整除 \(\delta=n b b'-a a'qr\)。由 \(|\delta|<B^2\) 再次迫使 \(\delta=0\)。所以在这个较薄的参数区，所有剩余非零移位都要求平移素数幂的底素数与两端 forcing 素数不同。此结论只作逐项排除，不估计剩余项之和。

## 边界

(2) 只删除异臂的精确 \(\delta=0\) 边。非零短移位满足 \(|\delta|<mm'/p^2\le B^2\)，其重叠核有正负两瓣；本证明没有对真实 forcing 的该剩余二次型给出下界，也没有推出 Schur 补符号、全尺度局部 Weil 正性或 RH。
