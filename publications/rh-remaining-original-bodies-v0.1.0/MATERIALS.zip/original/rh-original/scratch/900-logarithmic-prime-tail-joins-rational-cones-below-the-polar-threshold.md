# 对数增宽素数带与有理锥的联合正压缩（候选，待异源复核）

日期：2026-10-02。本文沿用 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 的全轮廓有理锥、[scratch/897](897-wide-prime-dilates-create-exact-denominator-stars.md) 的精确分母星图和 [scratch/898](898-wide-prime-band-joins-rational-cones-below-three-sixteenths.md) 的联合 Schur 计算。它将后者的素数上端从 \(P^{3/2}\) 延至 \(P^{3/2}\log P/4\)。关键区别是反射删点仅要求损失 \(o(H^2)\) 的根列平方质量；这足以保持根 Schur 主项。上述上游仍为候选，因此本文也不晋级为定理。

## 命题

令 \(P\to\infty\) 为奇素数，\(H=\log P\)，\(w=\tfrac12\log(1+P^{-2})\)，
\[
T=\frac14P^{3/2}H,\qquad
\mathcal P_P(T)=\{p\text{ prime}:P\le p\le T\}.
\]
对 scratch/898 的有理根集合 \(\mathcal G_P^\circ\) 和每个 \(1\le B\le P^{3/16}\)，取原有理锥 \(\mathscr V_{y,B}\) 及 \(p/y\) 的全部奇槽有限能量轮廓。存在与 \(B\) 无关的 \(\mathcal G_P^\dagger\subset\mathcal G_P^\circ\)，满足
\[
|\mathcal G_P^\circ\setminus\mathcal G_P^\dagger|=o(P^2),
\tag{1}
\]
使对每个 \(y\in\mathcal G_P^\dagger\) 可从 \(\mathcal P_P(T)\) 删去同一组素数，余下物理槽空间记为 \(\mathscr U_y(T)\)。它与所有 \(\mathscr V_{y,B}\) 物理正交，删去的根列平方质量为 \(o(H^2)\)，保留质量满足
\[
\sum_{p\in\mathcal Q_y(T)}\frac{(\log p)^2}{p}
=\left(\frac58+o(1)\right)H^2.
\tag{2}
\]
对全部 \(B\le P^{3/16}\) 一致，真实旧奇闭形式的联合压缩满足
\[
\boxed{\quad A_{P^2,-}\big|_{\mathscr V_{y,B}\oplus\mathscr U_y(T)}
\succeq cH I \quad}
\tag{3}
\]
其中 \(c>0\) 为绝对常数。式 (3) 包含全部素数幂平移、真实奇 polar、Archimedean 核和每槽全部有限能量轮廓。它不控制这组槽外的连续补空间，也不处理 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的 signed covariance。

## 几何删点与根列质量

因 \(T=o(P^2)\)、\(y\asymp P\)，各 \(p/y\) 槽位于旧区间的上臂，且相互不交。scratch/898 中根与锥的物理碰撞、根的次级同臂平移、非根锥与素数槽的同臂事故，均由整数元组的单次有理根命中来删除。把其计数的素数上端改为 \(T\) 后，前三类平均被删根列平方质量分别至多为
\[
O\!\left(\frac{H^2TB_*^2}{P^2}\right),\qquad
O\!\left(\frac{H^2T}{P^2}\right),\qquad
O\!\left(B_*^2\left(\frac{H^3}{P}+\frac{TH}{P^2}\right)\right),
\quad B_*=\lfloor P^{3/16}\rfloor .
\tag{4}
\]
每项都是 \(P^{-1/8}\) 乘至多一个固定对数幂，因而为 \(o(1)\)。第三项使用
\(\sum_{P\le p\le T}(\log p)^2\ll TH\)；第一项允许所有整数元组，因此不依赖素数间距。由 Markov 删去 \(o(P^2)\) 个根后，三类删点对每个留下的根只损失 \(o(1)\) 根列平方质量。删除规则均使用最大 \(B_*\)，故对较小 \(B\) 相同。

接着处理素数槽内部的异臂反射。仍记
\[
c_m=\frac{\Lambda(m)}{\sqrt m},\quad
\widetilde K_y(p,q)=
\sum_{\substack{s\ {\rm 素数幂}\\|\log(pq/(s y^2))|<w}}c_s,\quad
M_y=\sum_{p,q\in\mathcal P_P(T)}c_pc_q\widetilde K_y(p,q).
\tag{5}
\]
若反射窗命中，则 \(s\ll T^2/P^2\ll PH^2\)。固定 \((p,q,s)\) 的允许 \(y\) 区间仍短于 \(1/P\)，而不同原有理根相距严格大于 \(1/P\)，所以每个三元组至多命中一个根。Chebyshev 界及分部求和给
\[
\sum_{y\in\mathcal G_P^\circ}M_y
\le\left(\sum_{p\in\mathcal P_P(T)}c_p\right)^2
\sum_{s\ll T^2/P^2}c_s
\ll T\frac TP
\ll P^2H^2.
\tag{6}
\]
因 \(|\mathcal G_P^\circ|\asymp P^2\)，再舍去 \(O(P^2H^{-1/2})=o(P^2)\) 个根，使 \(M_y\le H^{5/2}\)。对这些根，按 scratch/893 的加权行负载
\[
L_y(p)=\frac{(\widetilde K_yc)_p}{c_p}
\]
删除 \(L_y(p)>H/100\) 的素数。所删平方质量至多
\[
\sum_{L_y(p)>H/100}c_p^2\le\frac{100M_y}{H}
\le100H^{3/2}=o(H^2),
\tag{7}
\]
而保留的全部异臂反射算子范数至多 \(H/100\)。这里采用较高行阈值，所以不声称 scratch/898 式 (3a) 的被删槽直接列 \(o(1)\) 界。

素数定理的加权分部求和给
\[
\sum_{P\le p\le T}\frac{(\log p)^2}{p}
=\frac12(\log^2T-H^2)+o(H^2)
=\left(\frac58+o(1)\right)H^2.
\tag{8}
\]
式 (4)、(7) 后仍有 (2)。素数槽之间相离 Archimedean 核的同臂行和为 \(O(wT\log T)=o(1)\)，异臂行和也为 \(o(1)\)。

## 真实 polar 与联合 Schur 预算

在素数槽上按 [scratch/899](899-high-prime-profile-band-has-polar-scale-centered-negative-direction.md) 式 (2)、(6) 写真实奇 polar。其负秩一算子范数不超过
\[
k_T=\frac{2\sinh(w/2)}y\sum_{P\le p\le T,\ p\ {\rm prime}}p
=\left(\frac16+o(1)\right)\frac{T^2}{P^2yH}
=\left(\frac1{96}+o(1)\right)\frac P y H
\le\left(\frac1{12}+o(1)\right)H ,
\tag{9}
\]
因为 \(y>P/8\)。单槽下界为 \(2H-O(1)\)，故保留的全轮廓素数块 \(F\) 满足
\[
F\succeq\left(2-\frac1{100}-\frac1{12}-o(1)\right)H I
\succeq1.90H I .
\tag{10}
\]
锥的 polar 投影范数平方为 \(O(B_*^2H/P)=o(H^{-1})\)，故新的 polar 跨块范数仍为 \(o(1)\)。scratch/898 的相离 Carleman 跨块界只多至多对数因子，因为 \(wT\log T=o(1)\)；总非算术跨块仍为 \(O(1)\)。非根异臂算术边仍按 scratch/897 的整数窗精确分类，因为 \(TB_*=o(P^2)\)；其分母星图 \(T_{\rm star}\) 满足
\[
\|T_{\rm star}\|^2\le\left(\frac9{512}+o(1)\right)H^2.
\tag{11}
\]

现取锥的完整根轮廓 \(R\)、非根块 \(D\)、根到 \(D\) 的列 \(f\)，以及根到素数块的列 \(g\)。scratch/898 式 (11) 与 (2) 给
\[
D\succeq(1/16-o(1))HI,\quad
f^*D^{-1}f\preceq(5/6+o(1))HI,\quad
\|g\|< (4/5+o(1))H.
\tag{12}
\]
令 \(E=O_{\rm op}(1)\) 为非算术跨块。先消去 \(D\)，所得素数 Schur 块由 (10)--(12) 满足
\[
S=F-(T_{\rm star}+E)D^{-1}(T_{\rm star}+E)^*
\succeq(1.90-9/32-o(1))HI
\succeq1.61HI .
\tag{13}
\]
同一逆序比较和 Cauchy 给
\[
\|(T_{\rm star}+E)D^{-1}f\|
\le\left(\frac{\sqrt{15}}8+o(1)\right)H
<\left(\frac12+o(1)\right)H .
\tag{14}
\]
根到联合补块的真 Schur 扣款遂至多
\[
f^*D^{-1}f+
(g-(T_{\rm star}+E)D^{-1}f)^*S^{-1}
(g-(T_{\rm star}+E)D^{-1}f)
\preceq\left(\frac56+\frac{(13/10)^2}{1.61}+o(1)\right)HI
<1.89HI .
\tag{15}
\]
根单槽自能量为 \(2H+O(1)\)，故根枢轴大于 \(0.11H\)；(12)--(13) 使补块有线性正隙。闭形式配方及有界跨块延拓与 scratch/898 相同，证明 (3)。\(\square\)

## 同一预算的两参数区域

上面的证明实际上给出一个开区域。固定 \(0\le\beta<1/5\)、\(\lambda>0\)，改取 \(B\le P^\beta\) 及素数上端 \(T=\lambda P^{3/2}H\)。定义
\[
d_\beta=1-5\beta,\qquad
F_\beta=1-d_\beta\log\frac{1+d_\beta}{d_\beta},\qquad
s_{\beta,\lambda}
=2-\frac43\lambda^2-\frac{\beta^2}{2d_\beta}.
\tag{16}
\]
若
\[
\boxed{\quad
s_{\beta,\lambda}>0,\qquad
F_\beta+
\frac{\left(\sqrt{5/8}+\beta\sqrt{F_\beta/(2d_\beta)}\right)^2}
{s_{\beta,\lambda}}<2,
\quad}
\tag{17}
\]
则对几乎所有原有理根，经一组与 \(B\) 无关、根列平方质量为 \(o(H^2)\) 的删点后，(3) 对此 \(T\) 和全部 \(B\le P^\beta\) 仍以某个 \(c_{\beta,\lambda}>0\) 成立。

为核对量词，把 (4) 的 \(B_*\) 换成 \(P^\beta\)：最坏项为
\(O(P^{2\beta-1/2}H^3)=o(1)\)，因为 \(\beta<1/5\)。式 (6) 的平均改为 \(O_\lambda(H^2)\)；仍取 \(M_y\le H^{5/2}\)，再以任意固定小 \(\delta H\) 截断行负载，所删质量为 \(O_\delta(H^{3/2})=o(H^2)\)，反射范数至多 \(\delta H\)。式 (9) 的最坏 polar 范数改为 \(((4/3)\lambda^2+o(1))H\)。scratch/891 的非根锥下界与逆响应分别为 \((d_\beta-o(1))H\)、\((F_\beta+o(1))H\)；精确分母星图的范数平方至多 \((\beta^2/2+o(1))H^2\)。因此素数 Schur 块下界为 \((s_{\beta,\lambda}-\delta-o(1))H\)，根扣款上界正是 (17) 左侧乘 \(H\)，另有趋零的 \(\delta\) 扰动。式 (17) 严格，故可先选足够小的固定 \(\delta>0\)，再让 \(P\to\infty\)，完成同一闭形式配方。

两个明确点是 \((\beta,\lambda)=(3/16,1/4)\)，即本稿主命题；以及 \((0,1)\)，即只取整数锥 \(B=1\) 时上端可达 \(P^{3/2}\log P\)。后者有
\[
s_{0,1}=2/3,\qquad
F_0+\frac{5/8}{s_{0,1}}
=1-\log2+\frac{15}{16}<2.
\tag{18}
\]
这只是经过删点的联合压缩；参数区域不是完整局部 Weil 正性的相图。

## 对数幂上端的反向障碍

固定 \(\alpha>1\)，只取 \(T_\alpha=P^{3/2}H^\alpha\le q\le2T_\alpha\) 的素数槽；对充分大 \(P\) 它们仍相离且位于旧上臂。以 scratch/899 的 \(R,\mathcal K\) 定义这族槽的全部算术异臂反射加真实 polar。素数定理直接给
\[
k_\alpha=\|a\|^2
=\left(\frac{P}{2y}+o(1)\right)H^{2\alpha-1}.
\tag{19}
\]
参与的反射素数满足 \(s\asymp T_\alpha^2/y^2\gg PH^{2\alpha}>P\)，故其中心 \(2H+\log s\) 的有理线性无关性仍由唯一分解给出。平方素数的算子范数为
\(\sum_{\ell\asymp \sqrt P H^\alpha,\ \ell\ {\rm prime}}(\log\ell)/\ell=O(1)\)，更高次幂也为 \(O(1)\)；\(\|b\|=O(P^{-1/2})\)。scratch/899 的低频与 Kronecker 调制两个变分方向于是原样给
\[
\inf_{\substack{\|g\|=1\\\iota g\in D(\mathfrak a_{P^2,-})}}
(R-\mathcal K)[g]
\le-\frac12 k_\alpha+O(1),
\qquad
\frac{k_\alpha}{H}\asymp H^{2\alpha-2}\longrightarrow\infty .
\tag{20}
\]
因此把**中心化算术加 polar 单独**下界为 \(-CH\) 的方法，无法越过任何固定的对数幂指数 \(\alpha>1\)。式 (20) 没有控制调制方向的 Archimedean 能量，不是完整 Weil 形式的负方向。

## 边界

\(T\asymp P^{3/2}\log P\) 时真实 polar 的范数已达 \(H\) 级，所以 (9) 的小常数是本论证的必要预算。若把上端换成 \(P^\tau\)、固定 \(3/2<\tau<2\)，[scratch/899](899-high-prime-profile-band-has-polar-scale-centered-negative-direction.md) 表明中心化算术加 polar 可有远超 \(H\) 的负方向，而其调制轮廓的 Archimedean 费用尚未控制。本文只扩大经过删点的联合压缩，不估计完整补空间 Schur 反馈或真实 moving-\(N\) 算术门。
