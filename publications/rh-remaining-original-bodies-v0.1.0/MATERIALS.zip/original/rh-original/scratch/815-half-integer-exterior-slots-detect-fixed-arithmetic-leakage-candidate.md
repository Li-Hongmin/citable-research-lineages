# 半整数外槽检出内部 Farey 正权态的固定算术泄漏（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇素数平移及偶极分离、[scratch 809](809-farey-outer-completion-spends-the-interior-logarithmic-gap-candidate.md) 的内部正权态。本文检出 [scratch 814](814-fixed-prime-farey-compression-is-uniformly-positive-for-all-odd-profiles-candidate.md) 的共同轮廓主压缩之外的一条真实算术响应。尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(k=p^2\)。取整数 \(Q=Q(p)\) 满足
\[
t:=\log(p/Q)\to\infty,\qquad t=o(H),
\tag{1}
\]
并令 \(v_I=\sum_{a/b\in\mathcal F_Q}(ab)^{-1/2}w_{a/b}\)，其中 \(w_x\) 为 note 791 的局部反对称单位偶极。置
\[
\mathcal Y_p=\{m/2:p\le m<2p,\ m\ \text{为奇数}\},
\qquad
Z_p=\operatorname{span}\{w_y:y\in\mathcal Y_p\}.
\tag{2}
\]
这里 \(w_y\) 仍按 note 791 式 (1) 的两臂物理偶极定义，虽 \(y\notin\mathcal F_p\)。则 \(Z_p\subset H_{p^2}^-\) 是正交单位族张成的空间，且 \(Z_p\perp(\mathbb C e_p\oplus W_p)\)。对真实完整旧奇算子有
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|P_{Z_p}A_{p^2,-}v_I\|^2}{\|v_I\|^2}
\ge \frac{\zeta(2)\log2}{4}>0.
}
\tag{3}
\]
因此内部 Farey 正权态向全 Farey 主空间外有固定的**算术**泄漏。它与 scratch 811 的槽内非恒定 Archimedean 响应属于不同的正交检出空间；(3) 本身不是负谱或 Schur 反馈下界。

结合 scratch 811 式 (2) 的槽内响应，令 \(U_p=\mathbb C e_p\oplus W_p\)，并取其中的常数 \(\sigma>0\)，还得到
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|(I-P_{U_p})A_{p^2,-}v_I\|^2}{\|v_I\|^2}
\ge \sigma^2+\frac{\zeta(2)\log2}{4}.
}
\tag{3a}
\]
证明是在任意固定 \(0<\alpha<1\) 上用 scratch 811 的 \(\eta_x\) 检出 \(\sigma^2\alpha^2\)，其支撑与 \(Z_p\) 正交；再令 \(\alpha\uparrow1\)。本式与 (3) 同为候选，不把范数泄漏当作 Schur 成本。

## 外槽分离与精确平移

每个 \(y=m/2\in\mathcal Y_p\) 满足 \(p/2\le y<p\)，其两臂中心 \(py,p/y\) 均合法：因 \(m\le2p-1\)，两端距物理边界的对数距离均 \(\gg p^{-1}\)，大于槽半宽 \(\Delta=\frac12\log(1+p^{-2})\)。不同 \(m\) 相差至少 2，故各 \(w_y\) 两两正交。

若 \(x=a/b\in\mathcal F_p\) 且 \(b\ge2\)，则 \(x\le(p-1)/2<y\)；若 \(b=1\)，则 \(x\) 为整数，与半整数 \(y\) 至少相差 \(1/2\)。这些差在对数坐标中至少为 \(c/p\gg2\Delta\)。异臂中心相距更远，根中心亦然，所以
\[
Z_p\perp(\mathbb C e_p\oplus W_p).
\tag{4}
\]

下面只让 \(A_{p^2,-}\) 作用于 \(v_I\)。任一素数幂平移输出的折叠比值 \(r>1\) 为 \(xn\)、\(x/n\) 或 \(n/x\)。其中 \(x/n\le Q=o(p)\)，与所有 \(y\ge p/2\) 相距很远；可能接近 \(y\) 的 \(xn\) 与 \(n/x\) 的既约分母分别整除源节点的 \(b\) 与 \(a\)，故至多为 \(Q\)。若此类 \(r\ne y=m/2\)，则分数间距给
\[
|r-y|\ge\frac1{2Q},
\qquad
|\log(r/y)|\gg\frac1{pQ}\gg\frac1{p^2}=2\Delta.
\tag{5}
\]
故它与 \(w_y\) 的槽不交。若 \(r=y\)，平移保持完整阶跃轮廓；源偶极两臂具有相同符号，所以每个精确重合贡献均带负系数。特别地，对奇数 \(3\le a<Q\) 与满足 \(p\le aq<2p\) 的素数 \(q\)，
\[
x=a/2\in\mathcal F_Q,\qquad y=aq/2\in\mathcal Y_p,
\qquad
\langle w_y,\mathcal R_{p^2}w_x\rangle
\le-\frac{\log q}{\sqrt q}.
\tag{6}
\]
此处即使同一 \(y\) 接受多个 \((a,q)\)，所有算术贡献仍同号。因此
\[
\|P_{Z_p}\mathcal R_{p^2}v_I\|^2
\ge
\sum_{\substack{3\le a<Q\\a\ {\rm odd}}}
\frac1{2a}
\sum_{\substack{q\ {\rm prime}\\p\le aq<2p}}
\frac{(\log q)^2}{q}.
\tag{7}
\]

## 主项与非算术误差

由素数定理的 Stieltjes 分部求和，当 \(X\to\infty\) 时
\[
\sum_{X\le q<2X}\frac{(\log q)^2}{q}
=(\log2+o(1))\log X.
\tag{8}
\]
(1) 保证全部 \(X=p/a\ge p/Q=e^t\to\infty\)，所以 (8) 对 (7) 中的 \(a\) 一致。记 \(h=\log Q=H-t\)。奇数调和数及其一阶对数矩给
\[
\begin{aligned}
\text{(7) 的右侧}
&\ge(\log2+o(1))
\sum_{\substack{3\le a<Q\\a\ {\rm odd}}}
\frac{H-\log a}{2a}\\
&=(\log2+o(1))
\left(\frac{Hh}{4}-\frac{h^2}{8}+O(H)\right)
=\left(\frac{\log2}{8}+o(1)\right)H^2.
\end{aligned}
\tag{9}
\]
而互素调和质量给
\[
\|v_I\|^2=\frac{h^2}{2\zeta(2)}+O(h)
=\left(\frac1{2\zeta(2)}+o(1)\right)H^2.
\tag{10}
\]

还需核对 (7) 不被 Archimedean 或 polar 项抵消。所有源 \(x\le Q\)，目标 \(y\ge p/2\)，因此源与目标的同臂中心距至少 \(t-\log2\to\infty\)，异臂距离更大。两偶极均零均值；note 791 的核二阶导数界给每个矩阵元
\[
|\langle w_y,G_{p^2}w_x\rangle|
\ll\Delta^3/(t-\log2)^3.
\]
又有 \(\sum_{x\in\mathcal F_Q}(ab)^{-1/2}=O(Q)\)、\(|\mathcal Y_p|=O(p)\)，故
\[
\|P_{Z_p}G_{p^2}v_I\|
\ll p^{1/2}Q\Delta^3/(t-\log2)^3=o(1).
\tag{11}
\]
局部零均值和 \(\sup|s'_{p^2}|=O(p^{1/2})\) 给
\(\|P_{Z_p}s_{p^2}\|=O(p^{-2})\)；
note 791 的全 Farey 投影界又给
\(|\langle s_{p^2},v_I\rangle|=O(Hp^{-3/2})\)。
因此 polar 项在 \(Z_p\) 上的范数也为 \(o(1)\)。由 (7)--(11) 与三角不等式，
\[
\|P_{Z_p}A_{p^2,-}v_I\|^2
\ge\left(\frac{\log2}{8}+o(1)\right)H^2.
\]
除以 (10) 即为 (3)。\(\square\)

## 边界

(3) 是全空间算术耦合的范数下界；[scratch 816](816-finite-denominator-exterior-layers-force-unbounded-farey-leakage-candidate.md) 把分母 2 扩到任意固定有限层，得到归一化泄漏趋于无穷。计算 Schur 成本还需要这些外槽及其余补空间的完整二次型或逆；仅凭泄漏范数不能决定完整旧奇算子的符号。moving-\(N\) Möbius signed covariance 门同样未被触及。
