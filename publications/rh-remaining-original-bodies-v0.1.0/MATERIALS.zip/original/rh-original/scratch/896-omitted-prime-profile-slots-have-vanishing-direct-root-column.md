# 被删素数全轮廓槽对几乎所有根只有消失的直接形式列（候选，待异源复核）

日期：2026-10-01。依赖 [scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md) 的根到素数槽平移分类、[scratch/893](893-average-farey-spacing-pays-upper-prime-schur-block.md) 的反射负载加权删点、[scratch/894](894-almost-all-rational-cones-join-prime-dilates-after-incidence-pruning.md) 的非根锥同臂事故删点，以及 [scratch/895](895-full-prime-profile-blocks-join-almost-all-rational-cones.md) 的全轮廓坐标。上游仍待异源复核。本稿直接问：删去的素数槽是否可能因根的**另一**素数幂平移而保有线性直接强迫？它不估计这些槽的逆或它们与保留空间的间接耦合。

## 命题

沿用 \(X\to\infty\)、\(H=\log X\)、\(w=\frac12\log(1+X^{-2})\)、有理根族 \(\mathcal G_X^\circ\)、素数区间 \(\mathcal P_X=[X^{5/4},X^{3/2}]\cap\mathbb P\)，以及 scratch/894 为每个 \(y\) 和整数 \(1\le B\le X^{1/5}\) 保留的素数标签 \(\mathcal Q_{y,B}\)。存在与 \(B\) 无关的 \(\mathcal G_X^\dagger\subset\mathcal G_X^\circ\)，满足
\[
|\mathcal G_X^\circ\setminus\mathcal G_X^\dagger|
\ll X^2H^{-1/4},
\tag{1}
\]
且对所有 \(y\in\mathcal G_X^\dagger\)、上述全部 \(B\)，被删素数的主平移权与次级平移权分别满足
\[
\boxed{\quad
\sum_{p\in\mathcal P_X\setminus\mathcal Q_{y,B}}\frac{(\log p)^2}{p}
\ll H^{-1/4},
\qquad
\sum_{\substack{p\in\mathcal P_X,\ s\text{ 素数幂}\\
|\log(ps/y^2)|<w}}
\frac{\Lambda(s)^2}{s}
\ll H^{3/2}X^{-1/4}=o(1).
\quad}
\tag{2}
\]
令 \(\mathcal O_{y,B}^{\rm prof}\) 为 \(p\in\mathcal P_X\setminus\mathcal Q_{y,B}\) 的全部有限能量奇轮廓槽的直和；这些素数槽彼此正交，但某些槽可能与有理锥重叠。对根槽任意单位有限能量轮廓 \(h\)，真实旧奇 Weil 形式的直接列一致满足
\[
\boxed{\quad
\sup_{\substack{g\in\mathcal O_{y,B}^{\rm prof}\\\|g\|_2=1}}
|A_{X^2,-}[\iota_y h,g]|
\ll H^{-1/8}=o(1).
\quad}
\tag{3}
\]
式 (3) 只估计根到被删素数槽的**一次形式配对**。若补块逆很大，或被删槽先与保留锥、素数块强烈混合，完整 Schur 扣款仍可显著；式 (3) 不能推出完整旧奇空间正性。

## 主平移权：收紧反射负载删点

scratch/893 式 (11)--(12) 给 \(\sum_{y\in\mathcal G_X^\circ}M_y\ll X^2\)，其中 \(M_y\ge0\) 是全部 \(p,q\in\mathcal P_X\) 的反射根列加权质量。由 Markov，除 \(O(X^2H^{-1/4})\) 个 \(y\) 外，\(M_y\le H^{1/4}\)。该稿保持删点阈值 \(L_y(p)>\sqrt H\)，故对这些根，高反射负载素数的主平移平方质量由其式 (13) 改进为
\[
\sum_{p\in E_y}c_p^2
\le M_y/\sqrt H\le H^{-1/4},
\qquad c_p=\frac{\log p}{\sqrt p}.
\tag{4}
\]
scratch/892 式 (9) 对与锥相交或具有另一根素数幂平移的素数给出一致删质量 \(O(H^2X^{-1/10})\)。scratch/894 式 (8) 令 \(D_y\) 为非根锥同臂事故的加权数，并给
\(\frac1{|\mathcal G_X^\circ|}\sum_yD_y\ll H^2X^{-1/10}=:\eta_X^2\)。除 \(O(\eta_X X^2)\) 个根外，\(D_y\le\eta_X=H X^{-1/20}\)，其事故删点的主平移平方质量亦至多 \(\eta_X\)。三种删除并集于是满足
\[
\sum_{p\notin\mathcal Q_{y,B}}c_p^2
\ll H^{-1/4}+H^2X^{-1/10}+HX^{-1/20}
\ll H^{-1/4}
\tag{5}
\]
对所有 \(B\le X^{1/5}\) 一致；多次删除同一 \(p\) 只使左侧更小。

## 次级平移权的有理根平均

记
\[
Z_y:=\sum_{\substack{p\in\mathcal P_X,\ s\text{ 素数幂}\\
|\log(ps/y^2)|<w}}c_s^2,
\qquad c_s=\frac{\Lambda(s)}{\sqrt s}.
\tag{6}
\]
若该条件成立，\(s\le C X^{3/4}\)。固定 \((p,s)\)，允许的 \(y\) 位于以 \(\sqrt{ps}\) 为中心、长度小于 \(1/X\) 的区间。不同 \(y=n/b\in\mathcal G_X^\circ\) 的间距大于 \(1/X\)，故每个 \((p,s)\) 至多命中一个根。用 \(|\mathcal P_X|\le X^{3/2}\) 和平凡调和界
\(\sum_{s\le CX^{3/4},\ s\text{ 素数幂}}c_s^2
\le C H^2\sum_{n\le CX^{3/4}}n^{-1}\ll H^3\)，得
\[
\sum_{y\in\mathcal G_X^\circ}Z_y
\ll X^{3/2}H^3,
\qquad
\frac1{|\mathcal G_X^\circ|}\sum_yZ_y
\ll H^3X^{-1/2}.
\tag{7}
\]
取 \(\rho_X=H^{3/2}X^{-1/4}\)。Markov 给
\(|\{y:Z_y>\rho_X\}|\ll\rho_X X^2\)。将这一条件与上一节的 \(M_y,D_y\) 条件相交；因 \(\eta_X,\rho_X\ll H^{-1/4}\)，得到 (1)--(2)。

## 对全部被删槽轮廓的实际形式列

对任一 \(p\in\mathcal P_X\)，根到 \(p/y\) 槽的算术配对先有 \(s=p\) 的异臂整槽反射，算子范数为 \(c_p\)。scratch/892 式 (5) 给另一种可能：同臂素数幂 \(s\) 满足 \(|\log(ps/y^2)|<w\)，其部分平移范数至多 \(c_s\)。该 \(s\) 若存在则唯一，因为允许的整数窗长 \(O(s/X^2)<1\)。其余向外平移不碰到 \(p/y\) 槽，异臂平移的整数窗只容 \(s=p\)。故根到所有被删素数槽的算术跨块范数不超过
\[
\left(2\sum_{p\notin\mathcal Q_{y,B}}c_p^2+2Z_y\right)^{1/2}
\ll H^{-1/8}.
\tag{8}
\]
各目标素数槽相互正交，所以这里可对逐槽算子范数作平方和；部分平移对任意根轮廓仍为 \(L^2\) 收缩。根与所有这些目标槽相距至少 \(H/2-O(1)\)。由相离核及槽数 \(\le X^{3/2}\)，Archimedean 跨块范数为 \(o(1)\)；根 polar 投影范数 \(O(X^{-1/2})\)、全部素数槽 polar 投影范数 \(O(1)\)，其跨块也为 \(o(1)\)。与 (8) 合并即得 (3)。\(\square\)

## 边界

本稿只处理固定主素数区间中**未被 scratch/894 保留**的槽。靠近分母指数 \(1/5\) 时，scratch/895 为保持完整锥正隙而主动截去一段 \(p<X^\sigma\)；那段素数有 \(H^2\) 级根列平方质量，不在式 (2)--(3) 的“小直接列”断言内。更广的素数区间、被删槽内部能量及与其他物理槽的间接耦合仍须估计；这些正是完整 Schur 门的实质部分。
