# 倒数双支路使低整数空间的真实补反馈至少达到四分之一对数（待异源复核）

日期：2026-09-29。依赖 [note 788](../notes/788-fractional-half-slots-force-logarithmic-complement-feedback.md) 的分数半槽正交性与真实旧算子、[note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的单槽 Archimedean 能量、[note 789](../notes/789-reciprocal-fraction-half-slot-family-has-positive-compression.md) 的倒数槽位置。此处检验完整低整数空间的补列，不假定局部 Weil 全尺度正性。

## 候选定理

沿奇素数 \(p\to\infty\)，置 \(k=p^2\)、\(L=\log k\)，并令 \(P_p\) 投影到整数奇半槽 \(e_m\)、\(2\le m\le p\) 的张成空间，\(Q_p=I-P_p\)。对素数幂 \(2\le q<p\)，设
\[
g_q=u_{p/q},\qquad h_q=e_{pq},\qquad c_q=\frac{\Lambda(q)}{\sqrt q},
\qquad S_p=\sum_{\substack{q<p\\q\text{ 素数幂}}}c_q^2
=\left(\tfrac18+o(1)\right)L^2.
\]
则 \(\{g_q,h_q\}\) 是 \(Q_pH_k^-\) 中的正交单位族，且
\[
\boxed{\|Q_pA_{k,-}e_p\|\ge\left(\tfrac12+o(1)\right)L.}
\tag{1}
\]
若完整旧奇算子 \(A_{k,-}\succeq a_kI\)、\(a_k>0\)，则其闭形式的 \(Q_p\) 压缩 \(B_{Q,p}\) 严格正，并且
\[
\boxed{\langle Q_pA_{k,-}e_p,B_{Q,p}^{-1}Q_pA_{k,-}e_p\rangle
\ge\left(\tfrac14+o(1)\right)L.}
\tag{2}
\]
这里 \(e_p\) 是根，\(h_q\) 是高整数支路；它在 \(P_p\) 外，却在全部整数半槽的张成空间内。因此 (1)--(2) 只针对低整数投影 \(P_p\)，不能照搬到包含全部整数半槽的投影。

## 双支路恒等式与正交性

沿用 \(\Delta=\frac12\log(1+1/p^2)\)、\(F=(2\Delta)^{-1/2}\)，在物理对数坐标上写
\[
P_r=(\log r-\Delta,\log r),\quad N_r=(\log r,\log r+\Delta),
\quad \varphi_r=F(1_{P_r}-1_{N_r}).
\tag{3}
\]
\(\varphi_r\) 本身不必为奇，但 \(e_p=\varphi_p\)，且对 \(q<p\)
\[
g_q=F(1_{P_{p/q}}-1_{N_{pq}}),\qquad
h_q=F(1_{P_{pq}}-1_{N_{p/q}}),
\quad g_q+h_q=\varphi_{p/q}+\varphi_{pq}.
\tag{4}
\]
所有这些区间严格处于旧空间内部。按原始约定 \(T_qf(t)=f(qt)\)，它将函数支撑中心 \(r\) 移到 \(r/q\)，伴随 \(T_q^*\) 才移到 \(qr\)。这里无边界截断，故 \(T_qe_p=\varphi_{p/q}\)、\(T_q^*e_p=\varphi_{pq}\)，精确地
\[
\boxed{(T_q+T_q^*)e_p=g_q+h_q.}
\tag{5}
\]
\(g_q\) 与全部整数槽正交，由 note 788 已证。对于 \(h_q=e_{pq}\) 与 \(e_m\)、\(m\le p\)，同臂中心相距至少 \(\log q\)；异臂若有交叠，则
\[
\left|\log\frac{qm}{p}\right|<2\Delta
\quad\Longrightarrow\quad
\frac{p}{1+1/p^2}<qm<p+\frac1p.
\]
这个区间仅含整数 \(p\)，但 \(qm=p\) 与 \(p\) 为素数且 \(q,m\ge2\) 矛盾。故 \(h_q\perp P_pH_k^-\)。不同 \(q\) 的 \(g_q,h_q\) 两两正交：同一中心的相邻半槽只接触于端点，不同中心的相对间距至少为 \(1/p\)，而 \(2\Delta=\log(1+1/p^2)<1/p\)。

旧算术项为 \(\mathcal R_k=-\sum_{s\text{ 素数幂}}c_s(T_s+T_s^*)\)。由 (5) 和整数间距，对每个 \(q<p\)，其在 \(g_q,h_q\) 上的根列系数都恰为 \(-c_q\)；其他 \(s\) 不落在这两个槽上。故对
\[
t_p=\sum_{\substack{q<p\\q\text{ 素数幂}}}c_q(g_q+h_q)\in Q_pH_k^-,
\quad \|t_p\|^2=2S_p,
\tag{6}
\]
有 \(\langle t_p,\mathcal R_ke_p\rangle=-2S_p\)。

## 算术能量的符号

令 \(\mathcal C_p=\{p/q,pq:2\le q<p,\ q\text{ 素数幂}\}\)。式 (4) 写成
\(t_p=\sum_{r\in\mathcal C_p}a_r\varphi_r\)，其中 \(a_{p/q}=a_{pq}=c_q>0\)。
任意两个中心的比 \(r/r'=A/B\) 可写成正整数 \(A,B<p^2\) 之比：
同侧是 \(d/e\) 或 \(e/d\)，跨侧是 \(de\) 或 \(1/(de)\)。若向上平移
\(T_s^*\varphi_r\) 与 \(\varphi_{r'}\) 的支撑相交，则
\(|\log(sA/B)|<2\Delta=\log(1+p^{-2})\)，因而
\[
|sA-B|<B/p^2<1.
\]
整数性强制 \(sA=B\)，即 \(sr=r'\)。

当 \(sr=r'\)，\(T_s^*\) 将整个偶极 \(\varphi_r\) 精确送到 \(\varphi_{r'}\)，内积为 \(1\)；向下平移 \(T_s\) 给出同一无向边。因此有精确式
\(\langle t_p,T_st_p\rangle=\sum_{r\in\mathcal C_p:\,sr\in\mathcal C_p}a_ra_{sr}\ge0\)
对每个素数幂 \(s\) 成立，进而
\[
\boxed{\langle t_p,\mathcal R_kt_p\rangle\le0.}
\tag{7}
\]
这里控制的是两支路的**全部**算术交叉，包括 \(p/d\to pe\)；未把这些交叉误当作零。

## Archimedean 上界与变分

记 \(G_k=H_{\rm Leg}+V+c_0-K_\gamma\)，\(D_k=L+1-\gamma_E-\log\pi\)。由 note 780 的位置消去式，每个 \(\varphi_r\) 的两个归一化半槽的自能量之和为 \(D_k+O(\Delta)\)。相邻半槽的非局部交叉满足
\(\Delta^{-1}\int_0^\Delta\int_0^\Delta K(u+v)\,du\,dv=O(1)\)，故
\[G_k[\varphi_r]\le D_k+C.\tag{8}\]
不同中心的同侧距离至少为 \(c|d-e|/p\)，异侧距离至少为 \(\log4-O(\Delta)\)。核界 \(K(v)\ll v^{-1}\) 与 Schur 行和因此给出全部不同中心交叉的算子范数 \(O(\Delta p\log p+p\Delta)=o(1)\)。于是
\[
G_k[t_p]\le(D_k+C+o(1))\|t_p\|^2=2(D_k+C+o(1))S_p.
\tag{9}
\]
polar 项 \(-2|s_k\rangle\langle s_k|\) 非正。联同 (7)，
\[
A_{k,-}[t_p]\le2(D_k+C+o(1))S_p.
\tag{10}
\]
根 \(e_p\) 与 \(\mathcal C_p\) 的距离至少为 \(\log2-O(\Delta)\)，所以
\(|\langle t_p,G_ke_p\rangle|\ll\Delta\sum_qc_q
\le\Delta\sqrt{pS_p}=o(1)\)。note 788 的
\(\langle s_k,e_p\rangle=O(p^{-3})\) 及 \(\|s_k\|=O(p^{1/2})\) 也使 polar 根列为 \(o(1)\)。因此
\[
\langle t_p,A_{k,-}e_p\rangle=-2S_p+o(1).
\tag{11}
\]
由 (6)、(11) 的 Cauchy 不等式，\(\|Q_pA_{k,-}e_p\|\ge(2S_p)^{1/2}+o(1)=(1/2+o(1))L\)，即 (1)。若 \(A_{k,-}\) 严格正，则 \(A[t_p]>0\)，闭形式压缩的逆度量变分给出
\[
\langle Q_pA_{k,-}e_p,B_{Q,p}^{-1}Q_pA_{k,-}e_p\rangle
\ge\frac{|\langle t_p,A_{k,-}e_p\rangle|^2}{A_{k,-}[t_p]}
\ge\frac{(2S_p+o(1))^2}{2(D_k+C+o(1))S_p}
=\left(\tfrac14+o(1)\right)L.
\]
全部阶跃槽有有限的对数形式能量，且 \(e_p\in D(A_{k,-})\)，故上述配对与变分合法。\(\square\)

## 全分母双支路压缩的额外 Hankel 边

上面的下界可与一个无条件的主压缩上界配对。现在允许**全部**整数分母
\(2\le d<p\)，令
\[
 w_d=\frac{u_{p/d}+e_{pd}}{\sqrt2}
 =\frac{\varphi_{p/d}+\varphi_{pd}}{\sqrt2},
 \qquad W_p^{\rm dip}=\operatorname{span}\{w_d:2\le d<p\}.
\tag{12}
\]
同样的整数间距证明 \(\{w_d\}\) 是 \(Q_pH_k^-\) 中的正交单位族。
写 \(B_p^{\rm dip}\) 为真实 \(A_{k,-}\) 在 \(W_p^{\rm dip}\) 上的压缩，
\(f_p^{\rm dip}=P_{W_p^{\rm dip}}A_{k,-}e_p\)。令
\(T_{k,p-1}\) 是 note 786 的同号乘法图，令
\[
H_p(d,e)=c_{de}=\frac{\Lambda(de)}{\sqrt{de}}
\qquad(2\le d,e<p).
\tag{13}
\]
前一节的整槽重合判据给出**精确算术矩阵**
\[
\boxed{\mathcal R_k|_{W_p^{\rm dip}}
 =(T_{k,p-1}-D_kI)-H_p.}
\tag{14}
\]
乘法图项来自两条同侧边 \(p/d\leftrightarrow p/e\)、
\(pd\leftrightarrow pe\)；额外的 \(-H_p\) 来自跨侧
\(p/d\to pe\) 与 \(p/e\to pd\)。式 (14) 包含 \(d=e\) 的
\(-c_{d^2}\) 自环，并没有重复计数。

\(H_p\) 按素数 \(\ell\) 的幂 \(d=\ell^a\) 分块；每块的矩阵为
\((\log\ell)\ell^{-a/2}\ell^{-b/2}\)，故为非负秩一矩阵，且
\[
0\preceq H_p\preceq
\sup_{\ell\ge2}\frac{\log\ell}{\ell-1}\,I\preceq I.
\tag{15}
\]
Archimedean 部分在每个 \(w_d\) 上有 \(D_k+O(1)\) 能量；
相邻两半槽的交叉仅贡献
\(\Delta^{-1}\int_0^\Delta\int_0^\Delta K(u+v)\,du\,dv=O(1)\)。
不同 \(d,e\) 的矩阵绝对行和为 \(O(\Delta p\log p+p\Delta)=o(1)\)。
此外，偶极的两个相邻半槽消去 polar 向量的常值项：
\[
|\langle s_k,w_d\rangle|\ll\Delta^{3/2}\sqrt d,
\qquad \|P_{W_p^{\rm dip}}s_k\|^2
\ll\Delta^3\sum_{d<p}d=O(p^{-4}).
\tag{16}
\]
于是 \(B_p^{\rm dip}=T_{k,p-1}-H_p+E_p\)，其中
\(\|E_p\|=O(1)\)。将 note 786 的逐边平方恒等式、(15) 合并，
保留单位节点缺失带来的 \(\Lambda(d)\) 项，得到
\[
\boxed{B_p^{\rm dip}\succeq
\operatorname{diag}_{2\le d<p}
\bigl(\tfrac12L+\Lambda(d)-C\bigr)
\succeq(\tfrac12L-C)I.}
\tag{17}
\]
所以双支路的**整个全分母主压缩**严格正，无须假定完整旧核正性。

由 (5) 及相同的分离估计，
\(f_p^{\rm dip}=-\sqrt2\,(c_d)_{2\le d<p}+r_p\)，
\(\|r_p\|=o(1)\)。式 (17) 给出逆范数 \(O(L^{-1})\)；
用逆序比较与 note 789 的素数定理积分，得
\[
\boxed{
\left(\tfrac14+o(1)\right)L
\le\langle f_p^{\rm dip},(B_p^{\rm dip})^{-1}f_p^{\rm dip}\rangle
\le\bigl(1-\log2+o(1)\bigr)L.}
\tag{18}
\]
左边用 (6)、(10)--(11) 的同一个试探向量；右边由
\(2\sum_{d\text{ 素数幂}}c_d^2/(\frac12L+\Lambda(d)-C)
=(1-\log2+o(1))L\) 得到。根能量为 \(D_k+O(1)=L+O(1)\)，
所以 \(\mathbb C e_p\oplus W_p^{\rm dip}\) 的真实闭形式压缩也严格正，
根 Schur 枢轴至少为 \((\log2+o(1))L\)。这个上界只作用在
\(W_p^{\rm dip}\) 压缩，不能作为完整 \(Q_p\) 补空间响应的上界。

## 边界

本候选把低整数投影的真实补列下界从 note 788 的 \(\frac18L\) 提升为 \(\frac14L\)，并证明全分母双支路主压缩仍严格正；它没有证明完整旧核正性，也未计算整个 \(Q_p\) 补空间的最优响应。全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 均未判定。
