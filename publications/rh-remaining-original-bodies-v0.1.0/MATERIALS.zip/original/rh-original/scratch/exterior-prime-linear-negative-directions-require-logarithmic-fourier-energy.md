# 槽外素数线性负方向需要超对数 Fourier 能量（候选）

日期：2026-09-30。对象与记号沿用 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的槽集 \(E_p\)、真正素数反射 \(R_p\) 和连续密度秩一项 \(K_p\)。前半命题使用 [note 830](../notes/830-exterior-prime-rayleigh-has-unconditional-main-term.md) 式 (21) 的有界变差轮廓界，将其单一余弦调制族结论推广到**全部**槽内 \(L^2\) 轮廓；末节另用平滑显式公式与 Vinogradov--Korobov 零自由区提出更强的算子范数结论。新证明尚待异源复核，故暂留 scratch。

令 \(H=\log p\)、\(A_H=H^{3/2}/(\log H)^2\)、\(V_p=E_p-2H\)。将 \(g\in L^2(E_p)\) 平移到 \(V_p\)，在全实线零延拓为 \(a(v)=g(2H+v)\)。采用 Fourier 约定 \(\widehat a(\xi)=\int_{\mathbb R}a(v)e^{-i\xi v}\,dv\)，并定义
\[
\mathcal L_p[g]=\int_{\mathbb R}\log(2+|\xi|)|\widehat a(\xi)|^2\,\frac{d\xi}{2\pi}\in[0,\infty].
\tag{1}
\]

**命题。** 存在绝对常数 \(C>0\)，使充分大的奇素数 \(p\) 与每个实值 \(g\in L^2(E_p)\) 满足
\[
\boxed{\quad
\big|\langle g,(R_p-K_p)g\rangle\big|
\le \frac{Cp}{H}\|g\|_2^2
 +Cp\|g\|_2\sqrt{\frac{\mathcal L_p[g]}{A_H}}.
\quad}\tag{2}
\]
右端允许为无穷。相同结论对复值轮廓成立，只需改变 \(C\)。特别地，对任意固定 \(c>0\)，存在 \(c_1(c)>0\)，使每个 \(\|g\|_2=1\) 且
\[
\langle g,(R_p-K_p)g\rangle\le-cp
\]
的轮廓都满足
\[
\boxed{\qquad \mathcal L_p[g]\ge c_1(c)\frac{(\log p)^{3/2}}{(\log\log p)^2}.\qquad}
\tag{3}
\]
因此 note 828 所构造的线性负本质谱不能由有 \(o(A_H)\) 对数 Fourier 能量的单位向量列实现。式 (2) 不是完整 Weil 正性：对 \(\mathcal L_p[g]=O(H)\)，其误差仍大于所需的 \(O(H)\) 算术界。

## 证明

note 830 式 (21) 取 \(M=1\)：存在绝对 \(\kappa_1>0\)，使每个实值 \(b\in L^2(V_p)\) 的全实线零延拓若满足 \(\|b\|_2\le1\) 和
\(\operatorname{Var}(b)\le e^{\kappa_1A_H}\)，就有
\[
|\langle b,(R_p-K_p)b\rangle|\le C_1p/H.
\tag{4}
\]
此处将 \(R_p-K_p\) 通过平移酉共轭到 \(L^2(V_p)\)。

还需一个统一的粗算子界。参与反射的素数 \(m\asymp p^2\)，且 \(\|J_m\|\le1\)。Chebyshev 上界 \(\vartheta(Cp^2)=O(p^2)\) 给
\[
\|R_p\|\le\sum_{m\asymp p^2,\ m\text{ prime}}\frac{\log m}{\sqrt m}=O(p).
\]
note 828 的 \(\|K_p\|=k_p\asymp p\)，所以
\[
\|R_p-K_p\|\le C_0p.
\tag{5}
\]

固定一个偶实函数 \(m\in C_c^\infty(\mathbb R)\)，\(0\le m\le1\)，\(m=1\) 于 \([-1,1]\)，\(\operatorname{supp}m\subset[-2,2]\)。令 \(T=e^{\tau A_H}\)，其中 \(0<\tau<\kappa_1/4\) 为固定常数；令 \(F_T\) 是 Fourier 乘子 \(m(\xi/T)\)。置
\[
b=\mathbf1_{V_p}F_Ta.
\tag{6}
\]
\(b\) 为实值，\(\|b\|_2\le\|a\|_2\)。先取 \(\|a\|_2=1\)。Plancherel 及 \(m(\xi/T)=1\) 于 \(|\xi|\le T\) 给
\[
\|a-b\|_2\le\|a-F_Ta\|_2
\le\left(\frac{\mathcal L_p[g]}{\log(2+T)}\right)^{1/2}
\le\tau^{-1/2}\sqrt{\mathcal L_p[g]/A_H}.
\tag{7}
\]

令 \(f=F_Ta\)。由 Cauchy--Schwarz、Plancherel 和乘子支撑，
\[
\|f\|_\infty\le C\sqrt T,\qquad
\|f'\|_\infty\le CT^{3/2}.
\tag{8}
\]
note 830 式 (3) 给 \(V_p\) 是至多 \(Cp^2\) 个相离区间的并，且 \(|V_p|=O(1)\)。因此乘以指标后的全实线总变差满足
\[
\operatorname{Var}(b)
\le |V_p|\|f'\|_\infty+2Cp^2\|f\|_\infty
\le C(T^{3/2}+p^2T^{1/2}).
\tag{9}
\]
由于 \(A_H/H=H^{1/2}/(\log H)^2\to\infty\) 且 \(3\tau/2<\kappa_1\)，式 (9) 对充分大 \(p\) 小于 \(e^{\kappa_1A_H}\)。故 (4) 适用于 \(b\)。由 (5)、\(\|a\|_2,\|b\|_2\le1\) 与 (7)，
\[
\begin{aligned}
|\langle a,(R_p-K_p)a\rangle|
&\le |\langle b,(R_p-K_p)b\rangle|
 +\|R_p-K_p\|(\|a\|_2+\|b\|_2)\|a-b\|_2\\
&\le C_1p/H+2C_0\tau^{-1/2}p\sqrt{\mathcal L_p[g]/A_H}.
\end{aligned}
\tag{10}
\]
按齐次性得到 (2) 的实值情形。复值时将实部和虚部分别代入；算子有实核，两个二次型相加，\(\mathcal L_p\) 和 \(L^2\) 范数平方也相加，Cauchy--Schwarz 给同形界。

若左边的有符号值不大于 \(-cp\)，则 (2) 与 \(C/H<c/2\) 给 \(\sqrt{\mathcal L_p[g]/A_H}\ge c/(2C)\)，这就是 (3)。\(\square\)

## 与真实 Archimedean 形式的接口

这里把 (3) 的辅助 Fourier 能量接到旧奇 Weil 算子的真实主部。令 \(\mathcal Jg\) 为[槽外全轮廓候选](exterior-all-profiles-continuous-prime-density-cancels-polar-to-bounded-rank-two.md)式 (1) 的奇反射等距嵌入，\(G_{p^2}\) 为 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 式 (3) 的完整 Archimedean 部分。对所有 \(\mathcal L_p[g]<\infty\) 的轮廓，有一个与 \(p,g\) 无关的常数 \(C\)，使
\[
\boxed{\qquad
\big|G_{p^2}[\mathcal Jg]-\mathcal L_p[g]\big|
\le C\|g\|_2^2.
\qquad}\tag{11}
\]
因此，若 \(\|g\|_2=1\) 且 \(\langle g,(R_p-K_p)g\rangle\le-cp\)，则
\[
G_{p^2}[\mathcal Jg]\ge c_1(c)A_H-C.
\tag{12}
\]
这仍远不足以支付一个 \(-cp\) 的素数方向，因为 \(A_H=o(p)\)。

为证明 (11)，置
\(Q_0[f]=\int_{\mathbb R}\log|\xi|\,|\widehat f(\xi)|^2d\xi/(2\pi)\)，其中低频对紧支撑 \(f\) 绝对可积。[note 004](../notes/004-exact-logarithmic-laplacian-normalization.md) 第 1--2 节的 Fourier 归一化与 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 式 (3)--(5) 给出，\(G_{p^2}\) 的 Legendre、势与标量三项恰为 \(Q_0-\log(2\pi)\|\cdot\|_2^2\)。也可直接在一个区间上核对：两形式的非对角奇异核均为 \(-1/(2|u-v|)\)，零延拓的端点 killing 均为 \(-\frac12\log(z(1-z))\)。常数可用归一化区间指标核准：\(Q_0[\Delta^{-1/2}\mathbf1_I]=\log(1/\Delta)+1-\gamma_E\)，而 note 780 式 (4) 的 Legendre、势与标量和为 \(\log(1/\Delta)+1-\gamma_E-\log(2\pi)\)。由 note 790 式 (4)--(5)，这个差与区间位置、宽度和轮廓无关。对不交区间极化后，[note 775](../notes/775-a-prime-source-has-logarithmic-arithmetic-coupling-to-the-complement.md) 式 (13) 给出剩余正则 gamma 核 \(-\rho(|u-v|)\)。该 \(\rho\) 在零点有界且在 \(d\ge1\) 为 \(O(1/d)\)，故全局有界。\(\mathcal Jg\) 的支撑 \(S_p=E_p\cup(2H-E_p)\) 测度为 \(O(1)\)，于是 Schur 或直接 Cauchy--Schwarz 给
\[
G_{p^2}[\mathcal Jg]=Q_0[\mathcal Jg]+O(1)\|g\|_2^2.
\tag{13}
\]

改用 \(w(\xi)=\log(2+|\xi|)\)。在 \(|\xi|\ge1\)，\(|w(\xi)-\log|\xi||\le C\)；在 \(|\xi|<1\)，差为可积的 \(O(1+|\log|\xi||)\)。因 \(|S_p|=O(1)\) 使 \(\|\widehat{\mathcal Jg}\|_\infty\le\|\mathcal Jg\|_1\ll\|g\|_2\)，故
\[
Q_0[\mathcal Jg]
=\int w(\xi)|\widehat{\mathcal Jg}(\xi)|^2\frac{d\xi}{2\pi}
+O(1)\|g\|_2^2.
\tag{14}
\]
在上、下臂各自的自项中，平移与反射不改变 \(w\)-Fourier 能量，\(1/\sqrt2\) 的两个平方权相加恰给 \(\mathcal L_p[g]\)。两臂位于 \(2H+[-\log8+o(1),-\log2+o(1)]\) 与 \([\log2+o(1),\log8+o(1)]\)，相距 \(2H-O(1)\)。由
\[
w(\xi)=\log2+\int_0^\infty e^{-2t}\frac{1-e^{-t|\xi|}}t\,dt
\]
及 Poisson 核 \(\mathcal F^{-1}(e^{-t|\xi|})(d)=t/[\pi(t^2+d^2)]\)，\(w\) 的非对角实空间核为
\[
-\frac1\pi\int_0^\infty\frac{e^{-2t}}{t^2+d^2}\,dt,
\qquad d\ne0,
\]
绝对值至多 \(1/(2\pi d^2)\)。两臂的 \(L^1\) 范数各为 \(O(\|g\|_2)\)，因此其交叉形式为 \(O(H^{-2})\|g\|_2^2\)。连同 (13)--(14) 证明 (11)。上述核计算先对光滑紧支撑轮廓成立，再由 note 004 的闭形式域和 Fourier 范数收敛延拓。

## 任意稀疏槽子集的完整 Weil 压缩正性

**候选定理。** 存在绝对常数 \(\eta,c_*>0\)，使充分大的奇素数 \(p\) 和任意 \(\mathcal S\subset\mathcal G_p\) 满足 \(|\mathcal S|\le\eta p\) 时，旧奇 Weil 形式在
\[
V(\mathcal S)=\mathcal J L^2\!\left(\bigcup_{x\in\mathcal S}I_x^+\right)
\]
的全部有限能量轮廓上有
\[
\boxed{\qquad A_{p^2,-}[f]\ge c_*\log p\,\|f\|_2^2
\quad(f\in V(\mathcal S)\cap D(A_{p^2,-})).\qquad}
\tag{15}
\]
\(\mathcal S\) 可任意散布，不要求其分数有共同分母、相同轮廓或固定有限素数结构。由此，若完整旧奇形式在整个槽外矩形中存在非正方向，则该方向的非零槽数必须超过 \(\eta p\)。这只排除稀疏支撑；整个矩形有 \(\asymp p^2\) 个槽，故 (15) 不推出全尺度局部正性。

**证明。** 记 \(M=|\mathcal S|\)、\(L=\log(1+p^{-2})\) 和 \(E_{\mathcal S}=\bigcup_{x\in\mathcal S}I_x^+\)。由 [note 829](../notes/829-exterior-overlap-mellin-weight-zero-free-growing-band.md) 的相离性，\(s:=|E_{\mathcal S}|=ML\le C\eta/p\)。把任意 \(g\in L^2(E_{\mathcal S})\) 零延拓，Plancherel 与 \(\|g\|_1^2\le s\|g\|_2^2\) 给任意 \(T>0\) 的低频质量界
\[
\int_{|\xi|\le T}|\widehat g(\xi)|^2\frac{d\xi}{2\pi}
\le\frac{Ts}{\pi}\|g\|_2^2.
\tag{16}
\]
取 \(T=p/H\)。对 \(\eta\le1\)，低频质量为 \(O(H^{-1})\|g\|_2^2\)，所以 (1) 及 (11) 给
\[
G_{p^2}[\mathcal Jg]
\ge\left(1-O(H^{-1})\right)\log(2+p/H)\|g\|_2^2-O(1)\|g\|_2^2
\ge(H-O(\log H))\|g\|_2^2.
\tag{17}
\]

对 \(x,y\in\mathcal S\)，若一个真正素数反射 \(J_m\) 从 \(I_x^+\) 到 \(I_y^+\) 有非零块，则两槽中心之和与 \(2H+\log m\) 相距小于 \(L\)，即
\[
xy e^{-L}<m<xy e^L.
\]
由于 \(xy\le p^2/4\) 且 \(e^L-e^{-L}=2p^{-2}+O(p^{-4})\)，这个区间长小于 \(1\)，故至多含一个整数。有关素数均满足 \(m\asymp p^2\)；每个非零块范数至多 \((\log m)/\sqrt m\le CH/p\)。将 \(g=\sum_{x\in\mathcal S}g_x\) 按互不重叠的槽分块，即得
\[
|R_p[g]|
\le\frac{CH}{p}\left(\sum_{x\in\mathcal S}\|g_x\|_2\right)^2
\le\frac{CMH}{p}\|g\|_2^2.
\tag{18}
\]
同样，\(K_p\) 在此子空间的范数为
\[
\|K_p|_{E_{\mathcal S}}\|
=\frac1p\int_{E_{\mathcal S}}e^u\,du
\le C M/p.
\tag{19}
\]
式 (18)--(19) 还给一个与 Archimedean 估计无关的空间必要条件：若单位 \(g\) 的非零轮廓只占 \(M\) 个槽，且 \((R_p-K_p)[g]\le-cp\)，则
\[
\boxed{\qquad M\ge c'(c)\frac{p^2}{\log p}.\qquad}
\tag{20}
\]
因此 note 828 的线性负素数谱方向必须同时具有 (3) 的高 Fourier 成本和 (20) 的广槽支撑；两个条件分别由频率与空间两种直接观测给出。

根据[槽外全轮廓候选](exterior-all-profiles-continuous-prime-density-cancels-polar-to-bounded-rank-two.md)式 (6)，完整压缩是 \(G_{p^2}+R_p-K_p+D_p\)，\(\|D_p\|\le C\)。结合 (11)、(18)--(19) 及全空间粗界 (5)，实际上得到对**任意** \(M\) 的同一 Rayleigh 商估计
\[
\boxed{\quad
A_{p^2,-}[\mathcal Jg]
\ge \mathcal L_p[g]
-C\left(1+\min\!\left\{p,\frac{MH}{p}\right\}\right)\|g\|_2^2
\quad(g\text{ 支撑于 }M\text{ 个槽}).
\quad}\tag{21}
\]
这里 \(K_p\) 的 \(O(M/p)\) 成本已吸收到 \(O(MH/p)\) 中。取固定 \(\eta>0\) 足够小，使 (18) 不超过 \(H/4\)；再取 \(p\) 足够大，使 (17) 的误差及 (19)、\(D_p\) 的 \(O(1)\) 成本不超过 \(H/4\)。于是 (15) 可取例如 \(c_*=1/4\)。\(\square\)

**边界。** (3) 是负谱方向的必要正则性成本，不是该成本足以支付负素数项的证明。欲推出完整局部 Weil 正性，需要在同一轮廓上把中心化素数形式下界提高到 Archimedean 对数能量可支付的量级；式 (2) 仍有 \(p\) 系数。moving-\(N\) Möbius signed covariance 也不由此推出。

## 临界素数重叠图的逐源正交

下面是对 \(M\asymp p^2/H\) 临界支撑的一项精确观察。对 \(x\in\mathcal G_p\)，记 \(P_x\) 为 \(L^2(I_x^+)\) 的投影。参与 \(R_p\) 的整数 \(m\) 全部小于 \(p^2e^L/4\)。对不同整数 \(m<m'\)，
\[
\log(m'/m)\ge\log(1+1/m)
>\log(1+p^{-2})=L
\tag{22}
\]
对充分大 \(p\) 成立。因此固定 \(x\) 时，反射像区间 \((2H+\log m)-I_x^+\) 随 \(m\) 两两相离；再截到 \(E_p\) 后仍相离。于是对任何 \(g_x\in L^2(I_x^+)\) 有**精确的**平方恒等式
\[
\boxed{\quad
\|R_pg_x\|_2^2
=\sum_{m\ {\rm prime}}\frac{\log^2m}{m}\|J_mg_x\|_2^2
\le CH\|g_x\|_2^2.
\quad}\tag{23}
\]
最后一步只用 \(m\asymp p^2\) 和 Chebyshev 上界 \(\vartheta(Cp^2)=O(p^2)\)。故每一个对角块满足 \(P_xR_p^2P_x\preceq CH P_x\)，虽然 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的全算子 \(\|R_p\|\ge c p\)。线性尺度的谱只能来自**不同源槽的交叉项**：若单位 \(g=\sum_xg_x\) 满足 \(\|R_pg\|\ge cp\)，则
\[
\sum_{x\ne y}\operatorname{Re}\langle R_pg_x,R_pg_y\rangle
=\|R_pg\|_2^2-\sum_x\|R_pg_x\|_2^2
\ge c^2p^2-CH.
\tag{24}
\]
式 (24) 定位了所需的跨槽算术协方差；它本身不给上界。

重叠也有一个整数窗表述。若 \(x=n/b\)、\(y=n'/b'\) 是 \(\mathcal G_p\) 的两个既约分数，素数 \(m\) 在 \((x,y)\) 块中出现，当且仅当
\[
\left|\log\frac{mbb'}{nn'}\right|<L.
\tag{25}
\]
此时 \(|mbb'-nn'|<nn'/p^2\le p/16\)。固定 \(x,m,b'\) 后，可能的 \(n'\) 落在
\[
\frac{mbb'}n e^{-L}<n'<\frac{mbb'}n e^L,
\tag{26}
\]
长度为 \(O(p^{-1/2})<1\)，所以至多有一个。特别地，该边要求
\(\|mbb'/n\|_{\mathbb R/\mathbb Z}<1/(4\sqrt p)\)。式 (25)--(26) 把临界重叠精确放在随 \(b'\asymp\sqrt p\) 变化的模 \(n\asymp p^{3/2}\) 窄余数窗中；现有逐槽绝对界与 (23) 均不控制不同 \(x\) 的共振。

### 素数匹配与两素数楔

式 (26) 的「每个分母至多一个目标」可以加强为**所有分母合起来至多一个目标**。不同的 \(y=n'/b'\)、\(z=n''/b''\in\mathcal G_p\) 满足
\[
|\log(y/z)|\ge\log(1+4p^{-2})>2L,
\tag{27}
\]
因为两个不同既约分数的交叉积相差至少一，而两个交叉积都不超过 \(p^2/4\)。若固定 \(x,m\) 的反射同时碰到 \(I_y^+\) 和 \(I_z^+\)，则两个目标中心都与 \(2H+\log m-\log(px)\) 相距小于 \(L\)，违反 (27)。反射的对称性给出固定目标、固定 \(m\) 也至多有一个源槽。因此每个素数 \(m\) 的槽关联是一组互不共顶点的边，允许自环；边上的算子仍可能只映射槽的一个真子区间。

对固定的一对槽 \(x,z\)，式 (25) 的允许区间长度
\(xz(e^L-e^{-L})\le\frac{p^2}{4}(e^L-e^{-L})<1\)，故其边若存在，素数标签 \(m_{xz}\) 唯一。令 \(a_m=(\log m)/\sqrt m\)，并把 \(g_x\) 在 \(I_x^+\) 外延零。对不同源槽 \(x\ne y\)，按目标槽分解内积得到精确恒等式
\[
\boxed{\quad
\langle R_pg_x,R_pg_y\rangle
=\sum_{\substack{z\in\mathcal G_p:\\m_{xz},m_{yz}\ \mathrm{exist}}}
a_{m_{xz}}a_{m_{yz}}
\int_{I_z^+}g_x(C_{m_{xz}}-u)
\overline{g_y(C_{m_{yz}}-u)}\,du,
\qquad C_m=2H+\log m.
\quad}\tag{28}
\]
每项必有 \(m_{xz}\ne m_{yz}\)，否则素数 \(m\) 在目标 \(z\) 上有两个不同源槽，违反匹配性。故 (24) 中的跨源协方差精确由**两种不同素数汇入同一目标槽**的长度二楔组成；它没有同一素数的交叉源对角项。

匹配性本身不给临界界。若 \(g\) 占 \(M\) 个槽，(23) 与 Cauchy--Schwarz 只给
\[
\|R_pg\|_2^2\le M\sum_x\|R_pg_x\|_2^2
\le CHM\|g\|_2^2.
\tag{29}
\]
在 \(M\asymp p^2/H\) 时，(29) 仍允许 \(\|R_pg\|\asymp p\|g\|\)，与 note 828 的线性谱量级一致。要改善完整 Weil 界，必须估计 (28) 中不同素数楔在同一轮廓上的实际相消，或直接证明其 Archimedean 成本足以支付。

这个界限在未中心化的跨源项上确实达到线性谱量级。取 note 828 的非负单位向量 \(g_p=e^{u/2}\mathbf1_{E_p}/\|e^{u/2}\mathbf1_{E_p}\|_2\)。note 830 式 (1) 给 \(\langle g_p,R_pg_p\rangle=k_p+o(p)\)，其中 \(k_p\sim c_0p\)、\(c_0=3\log2/(128\zeta(2))>0\)。因此 Cauchy--Schwarz 与 (23) 严格给
\[
\sum_{x\ne y}\langle R_p(g_p)_x,R_p(g_p)_y\rangle
=\|R_pg_p\|_2^2-\sum_x\|R_p(g_p)_x\|_2^2
\ge(c_0^2+o(1))p^2.
\tag{30}
\]
这里 (28) 的每项都非负，而且都来自两种不同素数。故「只因两素数标签不同便对楔取绝对值上界」不可能把跨源项降到 \(o(p^2)\)；必须同时保留连续密度 \(K_p\) 的中心化，或利用目标轮廓的实际符号与频率。
这个 \(g_p\) 的对数 Fourier 能量却只有 \(O(H)\)：note 830 证明其全实线零延拓的变差为 \(O(p^2)\)；在 (1) 中以 \(T=p^4\) 切分频率，低频由 Plancherel 给 \(O(\log T)\)，高频由 \(|\widehat g_p(\xi)|\le\operatorname{Var}(g_p)/|\xi|\) 给 \(O(p^4\log T/T)=O(H)\)。

中心化在这个自然向量上有一个可直接检验的二次矩。置
\[
\Theta_p(u)=\sum_{m\ {\rm prime}}(\log m)\mathbf1_{E_p}(C_m-u),
\qquad
\mathcal D_p(u)=\Theta_p(u)-\frac{k_p}{p}e^u.
\]
由 \(\|e^{u/2}\mathbf1_{E_p}\|_2^2=pk_p\) 及式 (1) 逐项计算，
\[
\boxed{\quad
((R_p-K_p)g_p)(u)=\sqrt{\frac p{k_p}}\,e^{-u/2}\mathcal D_p(u),
\qquad
\|(R_p-K_p)g_p\|_2^2
=\frac p{k_p}\int_{E_p}e^{-u}|\mathcal D_p(u)|^2\,du.
\quad}\tag{31}
\]
note 830 的标量结论只给
\(k_p^{-1}\int_{E_p}\mathcal D_p(u)\,du=r_p-k_p=o(p)\)，没有给 (31) 的二次矩上界。因此用素数主项把 \(g_p\) 当作近似本征向量，还需一个实际的 moving-window 素数方差估计；标量素数定理不能替代它。

## 平滑显式公式给出强范数升级（新候选）

下述卷积论证比 (2) 更强，也直接支付 (31) 的方差。存在绝对常数 \(C,\kappa>0\)，对充分大奇素数 \(p\) 与每个复值 \(g\in L^2(E_p)\)，有
\[
\boxed{\quad
\|(R_p-K_p)g\|_2
\le \frac{Cp}{H}\|g\|_2
+Cp\sqrt{\frac{\mathcal L_p[g]}{A_H}}.
\quad}\tag{32}
\]
当 \(\mathcal L_p[g]=\infty\) 时右侧按无穷解释。特别地，(2)--(3) 由 Cauchy--Schwarz 得到。更具体地，若全实线零延拓 \(a(v)=g(2H+v)\) 满足 \(\|g\|_2\le1\)、\(\operatorname{Var}(a)\le p^B\)，其中 \(B>0\) 固定，则
\[
\|(R_p-K_p)g\|_2
\ll_B p\exp[-c_B(H/\log H)^{1/3}].
\tag{33}
\]
因此 note 828 的自然单位向量 \(g_p\) 满足
\[
\boxed{\qquad
\|R_pg_p-k_pg_p\|_2
\ll p\exp[-c(H/\log H)^{1/3}]=o(p).
\qquad}\tag{34}
\]
结合 (31)，这还给出真实 moving-window 素数方差
\[
\int_{E_p}e^{-u}|\mathcal D_p(u)|^2\,du
\ll p^2\exp[-c(H/\log H)^{1/3}]
\tag{34a}
\]
（缩小 \(c\) 以吸收平方）。这是自然向量的**范数**近似本征关系；它没有控制与该向量正交的中心化素数谱。

这个结论统一覆盖所有常值槽系数。令
\(C_p=\operatorname{span}\{L^{-1/2}\mathbf1_{I_x^+}:x\in\mathcal G_p\}\)。
任意单位 \(g=\sum_xc_xL^{-1/2}\mathbf1_{I_x^+}\in C_p\) 的零延拓变差满足
\[
\operatorname{Var}(a)
=2L^{-1/2}\sum_x|c_x|
\le2L^{-1/2}\sqrt{|\mathcal G_p|}
\ll p^2.
\]
取 (33) 中任意固定 \(B>2\)，便有从整个常值槽空间到全部槽内 \(L^2\) 输出的统一算子界
\[
\boxed{\qquad
\|(R_p-K_p)|_{C_p}\|_{C_p\to L^2(E_p)}
\ll p\exp[-c(H/\log H)^{1/3}]=o(p).
\qquad}\tag{34b}
\]
此界仍远大于常值槽 Archimedean 间隙的 \(O(H)\) 尺度，故不能据此宣称真实 Weil 压缩正定。
它给线性负方向一个真实的横向必要条件：若 \(\|g\|_2=1\) 且
\(\langle g,(R_p-K_p)g\rangle\le-cp\)（固定 \(c>0\)），则存在 \(c'(c)>0\)，使充分大 \(p\) 满足
\[
\boxed{\qquad \|(I-P_{C_p})g\|_2^2\ge c'(c). \qquad}\tag{34c}
\]
证明只须写 \(g=P_{C_p}g+h\)；(34b) 使含 \(P_{C_p}g\) 的两个交叉项和自项合计为 \(o(p)\)，而粗界 (5) 给 \(|\langle h,(R_p-K_p)h\rangle|\le C_0p\|h\|_2^2\)。因此可取任意 \(c'<c/C_0\) 并让 \(p\) 足够大。
进一步，将常值槽有限压缩 \(P_{C_p}R_pP_{C_p}\) 的本征值按重数降序记为 \(\lambda_1\ge\cdots\ge\lambda_{|\mathcal G_p|}\)，在 \(p\) 的量级上只有一个本征值：
\[
\lambda_1=k_p+o(p),
\qquad \max_{j\ge2}|\lambda_j|=o(p).
\tag{34d}
\]
这里 \(P_{C_p}K_pP_{C_p}\) 的唯一非零本征值为
\(p^{-1}\|P_{C_p}(e^{u/2}\mathbf1_{E_p})\|_2^2=k_p+O(p^{-3})\)：每槽长度 \(L\asymp p^{-2}\)、\(e^{u/2}\asymp p\)，区间均值投影的总平方误差为 \(O(p^{-2})\)。对两个压缩用 (34b) 的算子范数扰动界即得 (34d)。
由 (23) 的逐源对角 \(O(H)\) 及 (34)，前文 (30) 的下界实际上成为精确主项
\[
\sum_{x\ne y}\langle R_p(g_p)_x,R_p(g_p)_y\rangle
=k_p^2+o(p^2)=(c_0^2+o(1))p^2.
\tag{34e}
\]

**证明。** 取固定的 \(0\le\chi\le1\)、\(\chi\in C_c^\infty(\mathbb R)\)，在所有充分大 \(p\) 的 \(V_p+V_p\) 上恒等于一；这是可能的，因为 \(V_p\) 都落在同一个固定紧区间。令 \(t_m=\log(m/p^2)\)，定义有限符号测度
\[
d\nu_p(t)=
\sum_{m\ {\rm prime}}\frac{\log m}{\sqrt m}\chi(t_m)\delta_{t_m}(dt)
-p e^{t/2}\chi(t)\,dt,
\qquad
(a\star\nu_p)(v)=\int_{\mathbb R}a(t-v)\,d\nu_p(t).
\tag{35}
\]
这里 \(a\) 在 \(V_p\) 外延零。对 \(v\in V_p\)，所有可能非零的 \(a(t-v)\) 都要求 \(t\in V_p+V_p\)，故 \(\chi(t)=1\)。逐项代入 note 828 式 (1) 得到精确算子恒等式
\[
(R_p-K_p)g(2H+v)
=\mathbf1_{V_p}(v)(a\star\nu_p)(v).
\tag{36}
\]
事实上 (35) 的连续项等于
\(p\int e^{(v+w)/2}a(w)\,dw
=p e^{v/2}\int_{V_p}e^{w/2}a(w)\,dw=K_pg(2H+v)\)。
Chebyshev 上界及 \(\chi\) 的固定支撑给 \(\|\nu_p\|_{\rm TV}\ll p\)，从而 \(|\widehat\nu_p(\xi)|\ll p\) 对全部 \(\xi\) 成立。

记 \(F_\chi(z)=\int_{\mathbb R}\chi(t)e^{zt}\,dt\)。它在任意固定实竖带满足
\[
|F_\chi(\sigma+i\tau)|\ll_{\chi,J}(1+|\tau|)^{-J}
\qquad(-1/2\le\sigma\le1/2,\ J\ge0),
\tag{37}
\]
由 \(J\) 次分部积分得到；常数与 \(\xi,p\) 无关。对含全部素数幂的 \(\Lambda\) 求和，权函数
\(x^{-1/2}\chi(\log(x/p^2))e^{-i\xi\log(x/p^2)}\)
的 Mellin 变换恰为 \(p^{2s-1}F_\chi(s-1/2-i\xi)\)。与 note 829 式 (4) 相同的移线论证（这里 \(\chi\) 光滑，竖线衰减任意次）给出绝对收敛的显式公式
\[
\widehat\nu_p(\xi)
=-\sum_\rho p^{2\rho-1}F_\chi(\rho-1/2-i\xi)
-\sum_{j\ge1}p^{-4j-1}F_\chi(-2j-1/2-i\xi)
+O(1).
\tag{38}
\]
\(p,\xi\) 先固定：在 \(\Re s=c>1\) 上以 \(-\zeta'/\zeta(s)\) 乘上述 Mellin 变换，Mellin 反演给全部素数幂和；沿避零高度左移时 (37) 使水平边消失。左边界取避开平凡零点的负奇整数 \(\Re s=-R\)。若 \(\operatorname{supp}\chi\subset[-D,D]\)，该线上 Mellin 因子至多为 \(p^{-2R-1}e^{(R+1/2)D}\) 乘以随 \(R\) 多项式增长、随竖向高度任意次衰减的因子；函数方程给 \(-\zeta'/\zeta\) 至多相应对数增长。因此 \(p^2>e^D\) 时左边界随 \(R\to\infty\) 消失，剩下 \(s=1\)、非平凡零点与平凡零点的留数。其后 (37) 和单位高度零点计数保证零点和绝对收敛，才对 \(\xi\) 取一致上界。
\(O(1)\) 一致于 \(\xi\)：它只用于从 \(\Lambda\) 去掉高次素数幂，模为一的调制不改变 note 830 证明中的平方素数 \(O(1)\) 和更高幂 \(o(1)\) 估计。平凡零点和也一致为 \(O(p^{-5})\)。

由 Riemann--von Mangoldt 的单位高度计数及 (37)，对 \(T\ge3\)、\(|\xi|\le T\)，
\[
\sum_{|\Im\rho|\le2T}|F_\chi(\rho-1/2-i\xi)|
\ll_\chi\log(2T),
\qquad
\sum_{|\Im\rho|>2T}|F_\chi(\rho-1/2-i\xi)|
\ll_\chi T^{-2}\log(2T).
\tag{39}
\]
经典 Vinogradov--Korobov 零自由区使第一和中的全部零点满足
\[
1-\Re\rho\ge
\frac{c_0}{(\log(3T))^{2/3}(\log\log(9T))^{1/3}}
=:\delta_T
\tag{40}
\]
（固定低高度零点通过缩小 \(c_0\) 一并包含）。将 (39)--(40) 代入 (38)，得到
\[
\sup_{|\xi|\le T}|\widehat\nu_p(\xi)|
\ll p\log(2T)e^{-2H\delta_T}
+pT^{-2}\log(2T)+1.
\tag{41}
\]

取 \(T=\exp(\kappa A_H)\)。因为
\(2H\delta_T\ge c\kappa^{-2/3}\log H\) 对充分大 \(p\) 成立，固定 \(\kappa>0\) 足够小即可使 (41) 的右边 \(\ll p/H\)。由 (36)、Plancherel 与
\(\widehat{a\star\nu_p}(\xi)=\widehat a(-\xi)\widehat\nu_p(\xi)\)，以及 \(\log(2+T)\ge\kappa A_H\)，分别控制低、高频：
\[
\begin{aligned}
\|(R_p-K_p)g\|_2
&\le\|a\star\nu_p\|_{L^2(\mathbb R)}\\
&\le \frac{Cp}{H}\|a\|_2
+Cp\left(\int_{|\xi|>T}|\widehat a(\xi)|^2\frac{d\xi}{2\pi}\right)^{1/2}\\
&\le \frac{Cp}{H}\|g\|_2
+Cp\sqrt{\mathcal L_p[g]/A_H}.
\end{aligned}
\]
这证明 (32)。

为证 (33)，改取 \(T=p^{2B+4}\)。此时 (40) 给
\(2H\delta_T\gg_B(H/\log H)^{1/3}\)，故 (41) 的低频界为
\(\ll_B p e^{-c_B(H/\log H)^{1/3}}\)。全实线 BV 分部积分给
\(|\widehat a(\xi)|\le p^B/|\xi|\)，于是高频尾的卷积范数至多
\[
Cp\left(\int_{|\xi|>T}\frac{p^{2B}}{\xi^2}\,d\xi\right)^{1/2}
\ll p^{B+1}/\sqrt T\ll p^{-1}.
\]
合并即得 (33)。note 830 末段已核准 \(g_p\) 的范数为一、变差为 \(O(p^2)\)；取任意固定 \(B>2\) 得 (34)。\(\square\)

**第二条核对路径。** note 830 式 (21) 还可不经 (38) 直接推出 (32) 的强范数形式。对全实线零延拓的 \(a\in BV\)，每个反射后再截到至多 \(Cp^2\) 个槽，使变差至多 \(C(1+p^2)\operatorname{Var}(a)\)；素数权总和为 \(O(p)\)，而秩一 \(K_p a\) 的变差至多 \(Cp^3\|a\|_2\)。故
\[
\operatorname{Var}((R_p-K_p)a)
\le Cp^3(\operatorname{Var}(a)+\|a\|_2).
\tag{42}
\]
固定 \(M=2\) 并取 note 830 式 (21) 的 \(\kappa_M\)。若 \(\|a\|_2\le1\)、\(\operatorname{Var}(a)\le e^{\kappa_M A_H/4}\) 而 \(\|(R_p-K_p)a\|_2\ge p/H\)，则单位向量 \(h=(R_p-K_p)a/\|(R_p-K_p)a\|_2\) 由 (42) 满足
\(\operatorname{Var}(h)\le e^{\kappa_M A_H/2}\) 对充分大 \(p\) 成立，因为 \(H=o(A_H)\)。将 \((a\pm h)/2\) 代入 note 830 式 (21) 并相减，得到
\[
\|(R_p-K_p)a\|_2
=\mathop{\rm Re}\langle a,(R_p-K_p)h\rangle
\ll p/H^2,
\]
与先前的 \(p/H\) 下界矛盾。于是这类 \(a\) 的强范数为 \(O(p/H)\)。对一般有限 \(\mathcal L_p\) 的 \(a\)，使用上文 (6)--(9) 的 Fourier 截断 \(b=\mathbf1_{V_p}F_Ta\)，但把 \(T=e^{\tau A_H}\) 的 \(\tau\) 取得足够小以满足 \(\operatorname{Var}(b)\le e^{\kappa_M A_H/4}\)。再用 \(\|R_p-K_p\|\ll p\) 和 (7) 即得 (32)。复值情形将 note 830 的实二次型界先用于实部和虚部。此路径依赖上游的标量显式公式，但独立核对了从低频到强范数的接口；它不算异源复核。

**绝对零点估计的尺度边界。** 改变 \(T\) 不能仅凭 (41) 把右边降到完整 Weil 门所需的 \(O(H)\)。若 \(3\le T\le p^{1/4}\)，(41) 中保留的高零点绝对尾项 \(pT^{-2}\log(2T)\) 本身大于 \(p^{1/2}\)，因而该**上界表达式**大于 \(H\)。若 \(T\ge p^{1/4}\)，则 \(\log T\ge H/4\)，(40) 中用于估计的 \(\delta_T\ll H^{-2/3}(\log H)^{-1/3}\)，故 (41) 的低零点绝对项满足
\[
p\log(2T)e^{-2H\delta_T}
\ge p\exp[-O((H/\log H)^{1/3})]\gg H.
\tag{43}
\]
所以本证明的两项绝对零点界在任何分界高度都不能同时支付对数级谱隙；(43) 只裁决这套**估计方法**，不提供真实素数算子的下界。进一步推进必须利用零点间的相消、素数对的算术结构，或直接取得同一轮廓上的带符号 Weil 下界。
