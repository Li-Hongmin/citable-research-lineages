# 平方自由外槽在四分之一分母尺度具有真实的互异三素数门（候选）

日期：2026-09-29。依赖 [scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的逐槽 forcing、[scratch 823](823-exterior-farey-signed-gate-reduces-to-three-distinct-primes-candidate.md) 的异臂包络与共同因子支付、[scratch 824](824-opposite-prime-power-quadratic-cost-vanishes-through-quarter-candidate.md) 的高次平移支付，以及 [scratch 825](825-exterior-farey-forcing-needs-order-log-positive-prime-resonance-for-a-negative-two-plane-candidate.md) 的二维 Gram 判据。以下结论留在 scratch，尚缺异源复核；它不估计三素数和的符号。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)，固定
\[
0<\beta<\alpha<\frac12,
\qquad 2\beta<1-\alpha,
\qquad Q=\lfloor p^\alpha\rfloor,
\quad B=\lfloor p^\beta\rfloor,
\quad D=p/Q.
\tag{1}
\]
取 819 的外槽族 \(\mathcal Y_{p,B}\)，并令
\(\mathcal Y^{\rm sf}_{p,B}=\{m/b\in\mathcal Y_{p,B}:\mu^2(m)=1\}\)。以 \(t^{\rm sf}\) 表示实际 forcing \(t\) 限制到该族后延零所得的向量。则对每个平方自由目标有逐槽精确恒等式
\[
t^{\rm sf}_{m/b}=\frac{F_Q(m)}{\sqrt{mb}},
\qquad
F_Q(m)\in\{0,\log r\},
\tag{2}
\]
其中第二种情形的 \(r\mid m\) 是唯一满足 \(r\) 为素数且 \(m/r<Q\) 的素数。

把 [823 式 (3)](823-exterior-farey-signed-gate-reduces-to-three-distinct-primes-candidate.md) 的外层目标对限制到 \(\mathcal Y^{\rm sf}_{p,B}\)，所得有符号和记为 \(\mathfrak T^{\rm sf}_{p,\alpha,\beta}\)。其每个非零项的三个素数 \(r,s,q\) 两两互异，并且
\[
\boxed{\quad
\langle t^{\rm sf},N^{\rm opp}_{p,B}t^{\rm sf}\rangle
=\mathfrak T^{\rm sf}_{p,\alpha,\beta}+o(1).
\quad}
\tag{3}
\]
这里 (3) 的左边使用的是实际 forcing，不需要 \(t-t^{\rm pr}\) 的二次型替换。
若写 \(m=ar\)、\(m'=a's\)，则 \(r,s>Q>\max\{a,a'\}\)；对 \(r\ne s\) 有
\(\gcd(m,m')=\gcd(a,a')<Q<D\)。因此 823 式 (3) 的公共因子条件在本子族中恰好只删除 \(r=s\) 的项。
剩余项的最小算术单元是
\[
0<|\delta|<bb',\qquad \delta=qbb'-aa'rs,
\tag{3a}
\]
其中 \(\delta=0\) 不可能：它将迫使素数 \(q\mid mm'\)，却有 \(q>m,m'\)。

置
\[
\mathfrak c_{\rm sf}
=\prod_{\ell\ {m prime}}
\left(1-\frac2{\ell^2}+\frac1{\ell^3}\right)
\in\left(0,\frac1{\zeta(2)}\right),
\qquad
J_{\rm diag}(\alpha,\beta)
=\frac{\alpha(1-\alpha/2)\beta^2}{2}
+\frac{\alpha\beta^3}{6}.
\tag{4}
\]
则 forcing 仍有严格正的四次对数范数主项：
\[
\boxed{\quad
\|t^{\rm sf}\|^2
=\bigl(\mathfrak c_{\rm sf}J_{\rm diag}(\alpha,\beta)+o(1)\bigr)H^4.
\quad}
\tag{5}
\]

若取 825 的内部向量 \(v_{p,\alpha}\) 和这里的真实外槽向量
\(w^{\rm sf}=\sum_{m/b\in\mathcal Y^{\rm sf}_{p,B}}t^{\rm sf}_{m/b}w_{m/b}\)，并且真实旧奇形式在 \(\operatorname{span}\{v_{p,\alpha},w^{\rm sf}\}\) 上有负方向，则
\[
\boxed{\quad
\frac{\mathfrak T^{\rm sf}_{p,\alpha,\beta}}
{H\|t^{\rm sf}\|^2}
\ge 2-\alpha-3\beta
-\frac{\zeta(2)\mathfrak c_{\rm sf}J_{\rm diag}(\alpha,\beta)}
{\alpha^2(1-\alpha)}-o(1).
\quad}
\tag{6}
\]
例如 \((\alpha,\beta)=(1/3,1/4)\) 满足 (1)，此时
\(J_{\rm diag}=11/1152\)，而 (6) 的右侧常数为
\[
\frac{11}{12}-\frac{33}{256}\zeta(2)\mathfrak c_{\rm sf}
>\frac{605}{768}>0.
\tag{7}
\]
因此四分之一分母尺度已有真实 forcing、正的 \(H^4\) 范数和互异三素数的**精确算术门**，但负方向仍要求该门有正的 \(H^5\) 级主项。

## 证明

若 \(m\) 平方自由，819 式 (1) 中任意有贡献的素数幂 \(n=\ell^j\) 必有 \(\ell\mid m\)，且 \((m,n)=\ell\)。当 \(j\ge2\) 时，两个 forcing 条件分别要求
\[
\ell>m/Q\ge D,
\qquad b\ell^{j-1}<Q.
\]
但 \(\alpha<1/2\) 使 \(D>Q\) 对充分大的 \(p\) 成立，矛盾。故只剩 \(j=1\) 的素数项，得到 (2) 的第一式。若两个不同素数 \(r,s\) 都给出素数项，写 \(m=ars\)。则 \(as=m/r<Q\)、\(ar=m/s<Q\)，于是 \(m=ars<Q^2/a\le Q^2<p\)，与 \(m\ge p\) 矛盾。故 forcing 素数唯一。

由 (1) 中 \(\beta<\alpha\) 和 \(2\beta<1-\alpha\) 得 \(3\beta<1\)，所以 823 式 (13) 的逐项比较给每个有效平移素数 \(q>\max\{m,m'\}\)，特别有 \(q\notin\{r,s\}\)。824 式 (2) 因 \(\beta<1/3\) 将 \(t^{\rm sf}\) 上全部高次素数幂平移的二次型支付为 \(o(1)\)。

若目标分子 \(m,m'\) 有共同素数 \(r>D\)，令
\(U_r^{\rm sf}=\sum_{m/b\in\mathcal Y^{\rm sf}_{p,B},\,r\mid m}F_Q(m)/m\)。823 式 (6) 的逐项包络及同一调和估计给
\[
\left|\text{共同大素因子部分}\right|
\ll H\sum_{r>D}(U_r^{\rm sf})^2
\ll \frac{B^2H^5}{D}=o(1),
\tag{8}
\]
末步正是 \(2\beta<1-\alpha\)。删去这部分便强制 \(r\ne s\)；展开 (2) 后剩余恰为 \(\mathfrak T^{\rm sf}\)，证明 (3)。

为证明 (5)，因 \(r>D>Q>B\) 且平方自由目标的 forcing 素数唯一，平方范数精确写成
\[
\sum_{2\le b\le B}\frac1b
\sum_{\substack{a<Q,\ \mu^2(a)=1\\(a,b)=1}}\frac1a
\sum_{\substack{r\ {m prime}\\p\le ar<bp}}
\frac{(\log r)^2}{r}.
\tag{9}
\]
这里 \(r>a,b\)，故 \(ar\) 平方自由且 \((ar,b)=1\) 恰由 \(\mu^2(a)=1\)、\((a,b)=1\) 保证。素数定理在 \(r\ge p/Q\to\infty\) 上一致给出 819 式 (13) 的素数加权 Riemann 和。

剩余双调和和的局部密度可直接计算。对一个素数 \(\ell\)，允许的情形是 \(\ell\nmid a\)（对 \(b\) 不限），或 \(v_\ell(a)=1\) 且 \(\ell\nmid b\)；在双调和对数尺度上的密度为
\[
\left(1-\frac1\ell\right)
+\left(\frac1\ell-\frac1{\ell^2}\right)
\left(1-\frac1\ell\right)
=1-\frac2{\ell^2}+\frac1{\ell^3}.
\tag{10}
\]
对有限个素数，用整除条件的有限容斥和一、二维调和 Riemann 和得到其局部因子的乘积。对 \(\ell>M\)，不合条件的双调和质量至多来自 \(\ell^2\mid a\) 或 \(\ell\mid a,b\)；除以 \(H^2\) 后，其总量由
\(O(\sum_{\ell>M}\ell^{-2})\) 控制，一致趋零。因此对任意有界连续的对数尺度测试函数，双调和测度收敛到 \(\mathfrak c_{\rm sf}\,du\,dv\)。把 819 式 (13) 的素数积分接上，即得 (5)；(10) 的每个局部因子均严格小于 \(1-1/\ell^2\)，故 \(0<\mathfrak c_{\rm sf}<1/\zeta(2)\)。

最后，825 式 (6) 的同臂上界对其 forcing 支撑的任意子集仍成立，824 已支付高次平移，而 819 的真实交叉 forcing 公式限制到本子集仍给
\(\langle v,A_{p^2,-}w^{\rm sf}\rangle=-\|t^{\rm sf}\|^2+o(H^4)\)。内部能量由 825 式 (7) 给出。对该二维 Gram 矩阵作同样的配方，结合 (3)、(5)，得到 (6)。在 \((1/3,1/4)\) 时代入 (4) 得
\(J_{\rm diag}=11/1152\) 与
\(\zeta(2)\mathfrak c_{\rm sf}J_{\rm diag}/[\alpha^2(1-\alpha)]
=(33/256)\zeta(2)\mathfrak c_{\rm sf}\)，证明 (7)。\(\square\)

## 边界

这只改变四分之一分母尺度的一个平方自由外槽子空间；它没有估计 \(\mathfrak T^{\rm sf}\) 的符号，也没有覆盖 819 的 \((\alpha,\beta)=(2/3,1/4)\) 全 forcing。式 (6) 是指定二维平面有负方向的必要条件，不是完整 Schur 成本或全尺度局部 Weil 正性，更不是 RH 证明。
