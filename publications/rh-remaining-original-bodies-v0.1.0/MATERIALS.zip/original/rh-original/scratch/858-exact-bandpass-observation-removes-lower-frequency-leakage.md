# 观察频带的精确带通核与紧支撑小波的低频泄漏（待独立复核）

**后续推进（2026-10-01）：**[scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 对真实联合系数用 $\Lambda=\mu*\log$ 支付两素数通道的小 Möbius 除数、整个高除数对角及物理近差/远差，把本稿式 (13) 进一步缩为短 cofactor 的实际 $\mu(d)\mu(e)$ 中距离门；该门仍未证明。

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(16)、(29)--(33) 和 [scratch/856](856-smooth-observation-wavelet-removes-haar-high-frequency-loss.md)。以下反模型只判断 scratch/856 式 (12) 作为**单个频带**算术门的强度；它不是实际系数的反例。精确带通恒等式保留实际三通道系数，但没有证明它的算术上界。

## 1. 一个满足全部短区间对数节省的低频反模型

令 $M$ 沿偶整数趋于无穷，$H=\lfloor M^{1/5}\rfloor$、$W=M/H$，$K=\lfloor M^{3/20}\rfloor$，$\delta=1/100$。取 $0\le\varphi\in C_c^\infty((1,2))$ 非零，并令
\[
 c_*(m)=M^{-\delta}\varphi(m/M)\cos(2\pi Km/M),\qquad
 a_*(m)=\frac{\psi(m/M)}m c_*(m),
\tag{1}
\]
其中 $\psi\in C_c^\infty((1,2))$ 取为在 $\varphi$ 的某个正值区间上非零。对任意长度 $B=\lfloor M^{2/3}\rfloor$ 的整数区间 $I$，甚至对任意子区间，都有
\[
 \left|\sum_{m\in I}c_*(m)\right|\ll B M^{-\delta}
 \ll_A B(\log M)^{-A}\qquad(A>0\text{ 固定}).
\tag{2}
\]
并且 $\sum_m|c_*(m)|\ll M$、$\sum_m|c_*(m)|^2\ll M$；这些都不超过 note 849 给实际联合系数使用的无符号质量界。

记 $\mathcal A_h^*=\sum_m a_*(m)e(-hm/M)$。光滑函数 $F(u)=\varphi(u)\psi(u)/u$ 的 Poisson 求和给
\[
 \mathcal A_h^*=\frac{M^{-\delta}}2
 \sum_{n\in\mathbb Z}\{\widehat F(h-K+nM)+\widehat F(h+K+nM)\}.
\tag{3}
\]
当 $H/2\le q(h)\le4H$ 时，$|h\pm K|\gg H$（按周期取代表元）；$F$ 的任意阶 Fourier 衰减说明
\[
 \sum_{H/2\le q(h)\le4H}|\mathcal A_h^*|^2
 \ll_A M^{-2\delta}H^{1-2A}
 =o(H^4/M)
\tag{4}
\]
（例如取 $A=3$）。因此目标单频带远比自然界更小。

现在使用 scratch/856 的**原紧支撑奇小波** $g=(\theta*\theta)'$，即 $T_Wc(x)=\sum_jg(j/W)c(x-j)$。其乘子在 $K/H\to0$ 时满足
\[
 G_W(K)=W\widehat g(K/H)+O_A(W^{1-A}),\qquad
 |G_W(K)|\asymp W K/H,
\tag{5}
\]
因为 $\widehat g(t)=2\pi it\widehat\theta(t)^2$、$\widehat\theta(0)=1$。令 $\mathcal C_K^*=\sum_m c_*(m)e(-Km/M)$。余弦展开和光滑求积给
\[
 \mathcal C_K^*=\tfrac12 M^{1-\delta}
 \left(\int_1^2\varphi(u)\,du+o(1)\right),
 \qquad |\mathcal C_K^*|\gg M^{1-\delta}.
\tag{6}
\]
由于 $\varphi$ 在 $(1,2)$ 内紧支撑、$g$ 支撑于 $(-1/50,1/50)$ 且 $W=o(M)$，在 $M\le x<2M$ 的原卷积与模 $M$ 的周期卷积完全相同。周期 Parseval 的单个 $h=K$ 项于是给
\[
 \sum_{M\le x\le2M+W}|T_Wc_*(x)|^2
 \gg M^{1-2\delta}W^2(K/H)^2
 \asymp M^{3-4/5+3/10-2/100}
 =M^{2.48}.
\tag{7}
\]
scratch/856 式 (12) 在本参数要求 $O_\varepsilon(M^2H^2M^\varepsilon)=O_\varepsilon(M^{2.4+\varepsilon})$；取 $\varepsilon<0.08$，(7) 与之矛盾。这个模型在 $K=M^{3/20}<H$，即 note 849 两端点展开所覆盖的 $H\ge M^{1/5}$ 区间**以下**。故所有已用的短区间任意对数幂节省，加上目标 $H$ 频带界，都不能单独推出 scratch/856 式 (12)。实际 $c$ 可能有额外抵消，此反模型对此不作判断。

同一计算覆盖每个固定 $1/5\le\alpha<1/4$。若 $H=M^{\alpha+o(1)}$、$K=M^{\kappa+o(1)}$、振幅为 $M^{-\delta}$，其中
\[
0<\delta<\tfrac12-2\alpha,
\qquad 3\alpha-\tfrac12+\delta<\kappa<\alpha,
\]
则目标带仍有任意固定幂 Fourier 衰减，而小波物理能量与式 (12) 右侧的比值至少为
$M^{1-6\alpha+2\kappa-2\delta+o(1)}\to\infty$。因此低频泄漏并非 $\alpha=1/5$ 的孤立现象；这个构造的参数窗口恰在 $\alpha\uparrow1/4$ 时闭合。

事实上，这是一条**任意固定紧支撑核的 no-go**。设 $g\in C_c^\infty(\mathbb R)$ 非零且 $\widehat g(0)=0$；由于 $\widehat g$ 是非零整函数，它在 $0$ 处有某个有限消失阶 $r\ge1$，即 $\widehat g(t)=b_rt^r+O(t^{r+1})$、$b_r\ne0$。固定 $1/5\le\alpha<1/4$，选 $\eta,\delta>0$ 使
\[
 \eta<\alpha,\qquad 2r\eta+2\delta<1-4\alpha,
\]
并在 (1) 中改取 $H=M^{\alpha+o(1)}$、$K=M^{\alpha-\eta+o(1)}$。仍有 (2) 的所有对数节省和 (4) 的单带任意幂衰减。Poisson 求和现在给 $|G_W(K)|\asymp W(K/H)^r$；别名因 $\widehat g$ 快速衰减而小于主项任意固定幂。用 (6) 的同一非零 Fourier 系数和周期 Parseval，物理能量至少为
\[
 M^{1-2\delta}W^2(K/H)^{2r}
 =M^{3-2\alpha-2\delta-2r\eta+o(1)}.
\]
它与所需 $M^2H^2=M^{2+2\alpha+o(1)}$ 的比值为
$M^{1-4\alpha-2\delta-2r\eta+o(1)}\to\infty$。紧支撑只用于保证原卷积与周期卷积在内区一致；$g$ 不必为奇函数。这个 no-go 排除的是**固定核且只知道单个 $H$ 频带和现有对数短和资料**时的等强门，不排除实际 $c$ 有额外抵消，也不处理随 $M$ 改变形状的核。

## 2. 精确带通的 Schwartz 核

取实偶函数 $\chi\in C_c^\infty(\mathbb R)$，$0\le\chi\le1$，其支撑包含于 $\{1/2\le|t|\le4\}$，并在 $1\le|t|\le2$ 上等于 $1$。令 $g_\chi=\mathcal F^{-1}\chi$，于是 $g_\chi$ 为实偶 Schwartz 函数。令 $M=2Y$、$M^{1/5}\le H\le M^{1/4}$、$W=M/H>8$。把任意支撑于 $M<m<2M$ 的序列 $a_m$ 按模 $M$ 看作 $b_x=a_{x+M}$，并定义周期卷积
\[
 (T_W^\chi b)(x)=\sum_{j\in\mathbb Z}g_\chi(j/W)b_{x-j},
 \qquad \mathcal A_h=\sum_{x\bmod M}b_xe(-hx/M).
\tag{8}
\]
Poisson 求和及 $W>8$ 给**无别名的精确乘子**
\[
 \sum_{j\in\mathbb Z}g_\chi(j/W)e(-hj/M)
 =W\sum_{k\in\mathbb Z}\chi((h+kM)/H)
 =W\chi(q(h)/H).
\tag{9}
\]
其中 $q(h)=\min(h,M-h)$，$0\le h<M$。于是周期 Parseval 给
\[
 \boxed{\quad
 \sum_{x\bmod M}|T_W^\chi b(x)|^2
 =\frac{W^2}{M}\sum_{h\bmod M}
 \chi(q(h)/H)^2|\mathcal A_h|^2.
 \quad}\tag{10}
\]
特别地，$H\le q(h)\le2H$ 的自然门
$\sum|\mathcal A_h|^2\ll H^4/M$ 由 (10) 的物理门
$\sum_x|T_W^\chi b(x)|^2\ll H^2$ 直接支付；反向则只需要相邻的 $H/2\le q(h)\le4H$ 频带。式 (10) 对 $q(h)<H/2$ 和 $q(h)>4H$ 的所有 Fourier 数据**严格为零**，所以没有式 (7) 的低频损失。代价是 $g_\chi$ 具有快速衰减的空间尾。

空间尾在当前量级可任意压低。令
\[
 Q_W^\chi(k)=\sum_{j\bmod M}v_W(j)v_W(j+k),\qquad
 v_W(j)=\sum_{\ell\in\mathbb Z}g_\chi((j+\ell M)/W).
\tag{11}
\]
对每个 $A>0$，Schwartz 卷积给
\[
 |Q_W^\chi(k)|\ll_{A,\chi}W(1+q(k)/W)^{-A},
 \qquad \widehat Q_W^\chi(h)=W^2\chi(q(h)/H)^2\ge0.
\tag{12}
\]
这正是 (10) 的带符号算术协方差核。若 $a_m=c(m)\psi(m/M)/m$ 为 note 849 的**真实联合系数**，则其 $\ell^1$ 与 $\ell^2$ 界 (16) 给：

* $|m-n|\le K_0:=H^3/\log^2M$ 的贡献绝对值为 $O_\psi(H^2/\log M)$；
* 对任意固定 $0<\tau<1/5$，$|m-n|>W M^\tau$ 的贡献可用 (12) 及 $\sum|a_m|\ll1$ 压成 $O_B(M^{-B})$，只须把 $A$ 取得足够大。这里 $\psi$ 的紧支撑使跨周期端点的最小圆周距离也有固定倍数 $M$。

精确带通仍保留 note 849 的三通道化。由 (9) 在 $h=0,M/2$ 处取值，
\[
\sum_jg_\chi(j/W)=\sum_j(-1)^jg_\chi(j/W)=0.
\tag{12a}
\]
将 note 849 式 (31) 的 $c-c_{\rm tri}=4-2\mathbf1_{2\mid m}+q(m)$ 代入，平滑权 $w_m=\psi(m/M)/m$ 的常数格与偶格主项被 (12a) 精确消去。因为 $\sum_j|g_\chi(j/W)||j|\ll W^2$、$|w_{m+1}-w_m|\ll M^{-2}$，其残差的周期平方和为 $O(M/H^4)$。高次素数幂由 note 849 式 (33)、$\|g_\chi\|_\infty\ll1$ 给周期平方和 $O(\log^2M)$。故
\[
\sum_{x\bmod M}|T_W^\chi(a-a^{\rm tri})(x)|^2
\ll_{\psi,\chi}M/H^4+\log^2M=o(H^2).
\tag{12b}
\]
所以替代核没有丢失素数 $p$、倍素数 $2p$、Möbius 三通道的精确目标量级。

因此对任意固定 $0<\tau<1/5$，(10) 的未付部分严格限于
\[
 \boxed{\quad
 \sum_{\substack{m,n\\K_0<|m-n|\le WM^\tau}}
 a_m\overline{a_n}Q_W^\chi(m-n)
 \ll_\varepsilon H^2M^\varepsilon.
 \quad}\tag{13}
\]
这是一道**单频带精确匹配**的真实 signed covariance 门；(13) 尚未证明。式 (5)--(7) 只关闭原紧支撑小波作为此单频带最便宜门的选择，不关闭实际算术命题，也不决定 RH。

精确带通后的算术不足已由 [scratch/851](851-logarithmic-short-interval-savings-do-not-pay-the-observation-band.md) 的同带反模型判定；这里的新增区分是：scratch/856 的紧支撑核还会受到**带外低频**影响，而 (9)--(13) 精确去除了这一额外要求。

## 3. 回顾

scratch/856 的式 (9) 在“全部 dyadic 自然频带已经成立”的假设下仍然正确；反模型 (1) 正是违反了更低的 $K$ 频带界。当前 $H\ge M^{1/5}$ 的工作只检验一个频带时，应使用 (10) 而非把紧支撑小波的充分条件 (12) 当作等强目标。下一项真正需要的新输入仍是 (13) 中素数 $p$、倍素数 $2p$ 与 Möbius 的联合算术抵消。
