# 真实末带中央 Poisson 管的非零周期模达到五分之一次幂目标

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的精确原始谐波、[note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1)、(7) 的真实末带，以及 Priyamvad Srivastav, *Log-free bounds on exponential sums over primes*, arXiv:2505.07803v2, Theorem 1 的 $q=1$ Möbius 界。该定理的 $|\delta|\le X^{3/10}$ 范围与式 (1.4) 的有界系数已于 2026-10-02 从原文 HTML 核对；[scratch/941](941-centered-moving-comb-mobius-window-has-critical-power-bound.md) 是相同机制的硬指标模型。以下是针对**真实** Poisson 权的解析证明，尚待异源复核；零模未受固定幂控制，因而不证明完整 moving-$N$ 门或 RH。

## 命题

令 $Y\to\infty$ 沿整数，$H$ 为满足 $Y^{1/5}\le H\le Y^{1/4}$ 的整数，$\mathcal A=\{a\in\mathbb Z:H<a\le11H/10\}$，$t_a,B_a,I_a$ 如 note 845 式 (1)。对整数 $3Y/2<N\le8Y/5$，置 $z=N/Y$，并以 note 801 的原始除数 $q$、谐波 $a$ 的精确项 $F_{a,q}(N)$ 定义
\[
C_{0,N}=\sum_{a\in\mathcal A}\sum_{q\in I_a}F_{a,q}(N).
\tag{1}
\]
这里 $F_{a,q}$ 包含 $\mu(q)$，不限制 $(a,q)=1$。定义明确的零模
\[
\mathcal M_{Y,H}(N)
=-\frac{J_{Y,H}(z)}{\pi zH^2}
\sum_{Y<q\le11Y/10}\mu(q)\log\frac{zY}{q},
\qquad
J_{Y,H}(z)=\int_0^{1/\log Y}
\cos(2\pi Hz-2\pi zu)\,du.
\tag{2}
\]
则对每个固定 $\varepsilon>0$，一致于 $H$ 与所取 $N$，
\[
\boxed{\quad
C_{0,N}=\mathcal M_{Y,H}(N)
+O_\varepsilon(Y^{1/2+\varepsilon}).
\quad}
\tag{3}
\]
因此真实末带中央分子管的**非零二周期模**已达点态平方根量纲。式 (2) 的零模仍含固定比例区间上的真实带对数权 Möbius 和；单靠本命题不能将 (3) 升级为 $C_{0,N}=O_\varepsilon(Y^{1/2+\varepsilon})$。

## 从真实短管到二周期单元

写 $x=q/Y$、$t=Hx-a$。对 $q\in I_a$，因为 $q>\lfloor aY/H\rfloor$ 且 $B_a<Y/H$，有 $a=\lfloor Hx\rfloor$、$0<t<1$。note 801 式 (5) 给出精确公式
\[
F_{a,q}(N)=-\mu(q)\frac{x}{\pi z a^2}
\log\frac z x\,r_a\!\left(\frac{x}{az}\right)
\cos\left(2\pi Hz-\frac{2\pi tz}{x}\right),
\quad
r_a(v)=\frac{4\mathbf1_{2\mid a}}{1-4v^2}
-\frac1{1-v^2}.
\tag{4}
\]
置 $c_a=4\mathbf1_{2\mid a}-1=1+2(-1)^a$、$f_z(x)=\log(z/x)/(\pi zx)$。由于 $x,z\asymp1$、$a\asymp H$、$t<1$，一致有
\[
\frac{x}{\pi za^2}\log\frac z x\,r_a(x/(az))
=\frac{c_a f_z(x)}{H^2}+O(H^{-3}).
\tag{5}
\]
真实短管共有 $O(Y/\log Y)$ 个整数 $q$，所以用 (5) 替换 (4) 的总误差为 $O(Y/H^3)$。

令 $L(x)=x/\log Y$。原始上端 $q\le t_a+B_a$ 在变量 $t=Hx-a$ 中位于
\[
t\le\frac{a}{H\log Y}+O(H/Y).
\tag{6}
\]
因为 $x=(a+t)/H$、且在任一短管或模型短窗中 $t=O(1/\log Y)$，(6) 与 $t<L(x)$ 的端点相差
$O(H/Y+1/(H\log^2Y))$。每个 $a$ 至多因此改变
$O(1+Y/(H^2\log^2Y))$ 个整数 $q$。再把 $a\in\mathcal A$ 的限制换成 $Y<q\le11Y/10$，只在两端长 $O(Y/H)$ 的整数带发生差别。故真实管与模型管的对称差有 $O(Y/H)$ 个 $q$；每项主权为 $O(H^{-2})$，几何替换误差也为 $O(Y/H^3)$。

在 $Y<q\le11Y/10$ 置 $x_q=q/Y$，并对 $y\in\mathbb R$ 定义周期为 $2$ 的单元函数
\[
V_{x,z}(y)=
c_{\lfloor y\rfloor}\,
\mathbf1_{\,0<\{y\}<L(x)}
\cos\left(2\pi Hz-\frac{2\pi z\{y\}}x\right).
\tag{7}
\]
于是 (4)–(6) 给出
\[
C_{0,N}=-\frac1{H^2}
\sum_{Y<q\le11Y/10}\mu(q)f_z(x_q)
V_{x_q,z}(Hx_q)
+O(Y/H^3).
\tag{8}
\]
由于 $H\ge Y^{1/5}$，$Y/H^3\le Y^{2/5}$，已低于 (3) 的目标误差。

## 二周期 Fourier 系数与零模

对 $k\in\mathbb Z$，以基 $e(ky/2)$ 展开 (7)。把 $y\in[0,2)$ 分成两个单位格，利用 $c_0=3,c_1=-1$，得到
\[
\widehat V_k(x,z)
=d_k\int_0^{L(x)}
\cos\left(2\pi Hz-\frac{2\pi zt}{x}\right)
e(-kt/2)\,dt,
\qquad
d_k=\frac{3-(-1)^k}{2}\in\{1,2\}.
\tag{9}
\]
特别地，$d_0=1$，且换元 $u=t/x$ 给
\[
f_z(x)\widehat V_0(x,z)
=\frac{\log(z/x)}{\pi z}
\int_0^{1/\log Y}
\cos(2\pi Hz-2\pi zu)\,du.
\tag{10}
\]
将 (10) 代回 (8)，$k=0$ 的贡献正是 (2)。

为控制其余模，取固定非负 $C_c^\infty((-1,1))$、积分为 $1$ 的 $\rho$，在周期 $2$ 上用宽度 $\sigma$ 的核平滑 (7)。平滑只改变 $y$ 到某个整数或到某个整数加 $L(x)$ 的距离不超过 $\sigma$ 的点，且差的绝对值为 $O(1)$。对 $y=Hx_q$，这些整数 $q$ 满足
\[
\left\|\frac{Hq}{Y}\right\|\le\sigma
\quad\text{或}\quad
\left\|\frac{(H-1/\log Y)q}{Y}\right\|\le\sigma.
\tag{11}
\]
两种线性相位在 $q\asymp Y$ 的固定比例区间内各跨过 $O(H)$ 个整数，每个 $\sigma$ 邻域含 $O(\sigma Y/H+1)$ 个 $q$，故硬边界替换在 (8) 中的误差为
\[
O\!\left(\frac{\sigma Y+H}{H^2}\right).
\tag{12}
\]
平滑后的第 $k$ 个系数为 $\widehat\rho(\sigma k/2)\widehat V_k(x,z)$；零模不变。

## 非零模的加性估计

令固定 $0<\vartheta<1/200$，并取
\[
K=\left\lfloor\frac{Y^{3/10-\vartheta}}{2H}\right\rfloor,
\qquad \sigma=\frac{Y^\vartheta}{K}.
\tag{13}
\]
于是 $K\gg Y^{1/20-\vartheta}$、$\sigma=o(1/\log Y)$、$\sigma K=Y^\vartheta$。在 $1\le|k|\le K$ 上，Srivastav Theorem 1 取 $q=1$、$\eta=1/10$；把加性频率加一个整数即可取其有理中心 $a/q=1/1$。原文式 (1.4) 的 $\mathscr G_{1/10}(u,u)$ 在 $0\le u\le3/10$ 有界。对 $X\asymp Y$ 的任一前缀及频率
\[
\alpha=\frac{kH}{2Y}
\quad\text{或}\quad
\alpha=\frac{k(H-1/\log Y)}{2Y},
\tag{14}
\]
有 $|X\alpha|\asymp|k|H\le Y^{3/10-\vartheta}$，因此
\[
\left|\sum_{n\le X}\mu(n)e(n\alpha)\right|
\ll\frac{Y}{\sqrt{|k|H}}.
\tag{15}
\]
对有限多个 $1\le|k|\le8$，式 (9) 及 $x\in[1,11/10]$ 给 $f_z(x)\widehat V_k(x,z)$ 一致有界变差；Abel 求和与 (15) 使每个模至多为 $O(Y/\sqrt H)$。

对 $|k|\ge9$，将 (9) 中的余弦拆成两指数，精确得到
\[
\widehat V_k(x,z)=\frac{d_k}{2}
\sum_{s=\pm1}e(sHz)
\frac{1-e(-(k/2+s z/x)L(x))}
{2\pi i(k/2+s z/x)}.
\tag{16}
\]
在此 $|k/2+s z/x|\gg|k|$，且其倒数作为 $x$ 的函数上确界与总变差均为 $O(1/|k|)$，统一于 $z$。式 (16) 的“$1$”项乘上 $e(kHx/2)$ 后频率为 (14) 的第一种；端点指数项因 $L(x)=x/\log Y$，有
\[
e(kHx/2)e(-(k/2+s z/x)L(x))
=e\!\left(\frac{k(H-1/\log Y)x}{2}\right)e(-s z/\log Y),
\tag{17}
\]
频率为 (14) 的第二种，末因子不依赖 $x$。把 $f_z(x)/(k/2+s z/x)$ 作为有界变差权，对 (15) 作 Abel 求和，故每个 $9\le|k|\le K$ 的贡献为
$O(Y/(\sqrt H\,|k|^{3/2}))$。求和得到全部 $0<|k|\le K$ 的贡献为 $O(Y/\sqrt H)$。

对 $|k|>K$，式 (9) 分部积分给 $|\widehat V_k|\ll1/|k|$；平滑乘子满足 $|\widehat\rho(\sigma k/2)|\ll_{\rho,A}(1+\sigma|k|)^{-A}$。对 $q$ 用 $|\mu(q)|\le1$，绝对求 Fourier 尾，得任意固定 $A>1$ 的界 $O_A(Y(\sigma K)^{-A})=O_A(Y^{1-A\vartheta})$。

综合 (8)、(10)、(12) 及非零模估计，
\[
|C_{0,N}-\mathcal M_{Y,H}(N)|
\ll_{\vartheta,A}\frac{Y}{H^3}
+\frac{Y}{H^{5/2}}
+\frac{\sigma Y+H+Y^{1-A\vartheta}}{H^2}.
\tag{18}
\]
由 (13)，$\sigma Y\ll H Y^{7/10+2\vartheta}$；在 $H\ge Y^{1/5}$ 时，
$Y/H^{5/2}\le Y^{1/2}$，$\sigma Y/H^2\ll Y^{1/2+2\vartheta}$，$Y/H^3\le Y^{2/5}$。取 $A\vartheta>1/10$ 则 $Y^{1-A\vartheta}/H^2\le Y^{1/2}$，且 $H/H^2$ 更小。对给定 $\varepsilon$ 先取 $\vartheta<\varepsilon/4$，便得 (3)。$\square$

## 固定载波族的秩一算术余项

固定有限个整数 $r$，令 $H_r=H+r$，并要求这些 $H_r$ 均在定理的范围内。各管都按 note 845 式 (1) 将参数 $H$ 换成 $H_r$；记其真实中央原始除数和为 $C_{0,r}(N)$。式 (2) 的带对数权 Möbius 和
\[
S_Y(z)=\sum_{Y<q\le11Y/10}\mu(q)\log\frac{zY}{q}
\tag{19}
\]
与 $r$ 无关。因此 (3) 对固定有限族一致给
\[
C_{0,r}(N)=-\frac{J_{Y,H_r}(z)}{\pi zH_r^2}S_Y(z)
+O_{\varepsilon,r}(Y^{1/2+\varepsilon}).
\tag{20}
\]
特别地，对任意关于 $z$ 有界、并满足
$\sum_r w_r(z)J_{Y,H_r}(z)/H_r^2=0$ 的固定有限组权，逐 $N$ 有
\[
\sum_r w_r(N/Y)C_{0,r}(N)
=O_{\varepsilon,w}(Y^{1/2+\varepsilon}).
\tag{21}
\]
这是真实末带原始除数和的固定幂横向消元：在固定载波族中，当前推导留下的障碍至多是同一个 $S_Y(z)$ 所张成的一个方向。它没有控制随 $Y$ 增长的载波族或其他分子。

例如令 $v_r(z)=J_{Y,H+r}(z)/(H+r)^2$，$r=0,1$。在任意固定紧集 $\mathcal K\Subset(3/2,8/5)$ 上，
$J_{Y,h}(z)=[\sin(\pi z/\log Y)/(\pi z)]\cos(2\pi hz-\pi z/\log Y)$，而 $\sin(2\pi z)$ 在 $\mathcal K$ 上远离零，所以 $v_0(z)^2+v_1(z)^2>0$ 且二者不能同时接近零到低于其共同的 $H^{-4}(\log Y)^{-2}$ 量级。因此下面的系数一致有界，且 (21) 给出真实两载波的归一化消元：
\[
\boxed{\quad
\frac{v_1(z)C_{0,0}(N)-v_0(z)C_{0,1}(N)}
{\sqrt{v_0(z)^2+v_1(z)^2}}
=O_{\mathcal K,\varepsilon}(Y^{1/2+\varepsilon}),
\qquad z=N/Y\in\mathcal K.
\quad}
\tag{22}
\]
把 (22) 对 $O(Y)$ 个观测整数平方求和，并把点态指数先取为 $\varepsilon/2$，得到这一真实、非零的两载波组合的目标量纲均方界
\[
\sum_{\substack{3Y/2<N\le8Y/5\\N/Y\in\mathcal K}}
\left|\frac{v_1(N/Y)C_{0,0}(N)-v_0(N/Y)C_{0,1}(N)}
{\sqrt{v_0(N/Y)^2+v_1(N/Y)^2}}\right|^2
\ll_{\mathcal K,\varepsilon}Y^{2+\varepsilon}.
\tag{23}
\]

## 边界

这是真实 $F_{a,q}(N)$ 的固定幂非零模支付，较 scratch/941 的几何模型更接近算术门；但 (2) 的零模是全区间 Möbius 和乘一个 $O(1/(H^2\log Y))$ 的光滑系数。已知零自由区只给它次幂级节省；除非它在其他分子或分母块中抵消，式 (3) 单独不关闭完整均方。式 (3) 不适用于 note 845 另设 $(a,q)=1$ 的既约子管，也没有处理不同载波之间的联合协方差。
