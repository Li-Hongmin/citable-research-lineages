# 全部负 Möbius cofactor 的共振交叉协方差在目标量级内可支付

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实高除数核与绝对误差预算，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的远差截止。本稿给出一整族真实 $\mu(d)\mu(e)$ 交叉项的**单侧目标上界**，无需短区间 Möbius 定理；论证仍待异源复核，暂不晋级永久 note。其余非共振 signed covariance 仍未证明。

令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 为固定实函数，$\phi(t)=\psi(t)/t$。沿用 scratch/859 的 $D=\lfloor M/(16H)\rfloor$、$b_d(m)$、$R=\lfloor H^2/\log^4(2M)\rfloor$、$K_0=H^3/\log^7(2M)$，以及 scratch/860 固定 $s>1$ 的 $w_H,J_H$ 和 $K_{s,2}=C_{s,2}(M/H)(\log M)^s$。置
\[
 \mathcal Q=\{q\ge2:\mu(q)=-1\},\qquad
 a(q)=4\log q-2\mathbf1_{2\mid q}\log(q/2)>0.
\]
对每个 $q\in\mathcal Q$ 令
\[
 U_q=\{u\in\mathbb N:u>D,\ (u,q)=1,\ M<qu<2M\},
 \qquad
 F_{q,h}=\sum_{u\in U_q}\mu(u)\phi(qu/M)e(-hqu/M).
 \tag{1}
\]
只有 $q<2M/D\ll H$ 的 $U_q$ 非空。考虑 scratch/859 式 (12) 中如下**有序物理子和**：$d=u$、$e=qv$、$m=qu$、$n=qv$，其中 $q\in\mathcal Q$、$u,v\in U_q$；仅保留式 (12) 原有的 $d\nmid e$、$e\nmid d$、最大约化比例 $>R$ 与 $K_0<|m-n|\le K_{s,2}$ 条件。记它为 $\mathfrak T_{M,H}$。则
\[
 \boxed{\quad
 \mathfrak T_{M,H}
 =-\frac{4\log2}{M^2}\sum_{q\in\mathcal Q}a(q)
 \sum_h w_H(h)|F_{q,h}|^2
 +O_{s,\psi}\!\left(
 \frac{H^2\log^3(2M)}M
 +\frac{H^4}{M\log^2(2M)}+M^{-2}\right).
 \quad}\tag{2}
\]
特别地，该真实剩余门的整个负 cofactor 共振子族满足
\[
 \boxed{\quad
 \mathfrak T_{M,H}
 \ll_{s,\psi}\frac{H^4}{M\log^2(2M)}
 =o(H^4/M).
 \quad}\tag{3}
\]
式 (3) 是**单侧**上界；主项可为负，不能将其改写成 $|\mathfrak T_{M,H}|$ 的上界。反向有序子和也满足同一结论，二者合并的主项是 (2) 的两倍。

## 证明

先不加式 (12) 的整除、约化比例或物理距离过滤。对 $u\in U_q$，scratch/859 式 (2) 在 $m=qu$ 给
\[
 b_u(qu)=\frac{\phi(qu/M)}M
 \left[2\mathbf1_{2\mid q}\log(q/2)-4\log q\right]
 =-\frac{a(q)}M\phi(qu/M).
 \tag{4}
\]
又 $qv>M$，故 $b_{qv}(qv)=-4(\log2)M^{-1}\phi(qv/M)$。由 $(q,v)=1$ 与 $\mu(q)=-1$，真实 Möbius 乘法性给 $\mu(qv)=-\mu(v)$。因此完整有序子和精确为
\[
 \begin{aligned}
 \mathfrak T^{\rm full}_{M,H}
 &=\sum_{q\in\mathcal Q}\sum_{u,v\in U_q}\mu(u)\mu(qv)
 b_u(qu)b_{qv}(qv)J_H(q(u-v))\\
 &=-\frac{4\log2}{M^2}
 \sum_{q\in\mathcal Q}a(q)\sum_h w_H(h)|F_{q,h}|^2\le0.
 \end{aligned}
 \tag{5}
\]
不同 $q$ 的选定物理项不重叠，因为 $q=m/d$ 由 $d,m$ 唯一确定。式 (5) 保留的是实际 $\mu$ 符号，而非替代模型。

现在从 (5) 删除不满足剩余门过滤的项。scratch/859 式 (8a)、(8b) 的**证明**以 $|J_H|\ll H$ 和 $\|b_d\|_1\ll\log(2M)/d$ 直接对所有物理项取绝对值；因此它们对本子族中整除配对及最大约化比例 $\le R$ 的删除代价分别至多
\[
 O_\psi(H^2\log^3(2M)/M),
 \qquad O_\psi(H^4/(M\log^2(2M))).
 \tag{6}
\]
这些界不需要先把 $m,n$ 求和成 $\mathcal G_{d,e}$。scratch/859 式 (9)--(10) 用 $B(m)=\sum_{d>D}|b_d(m)|$ 对**全部**物理近差给绝对界 $O_\psi(H^4/(M\log^2(2M)))$；故删去 $|qu-qv|\le K_0$ 的代价不超过此量。scratch/860 式 (3) 对全部 $|m-n|>K_{s,2}$ 给 $O_{s,\psi}(M^{-2})$。把四项删除代价相加即得 (2)。

主项 (5) 非正。又 $H\gg M^{1/5}$，所以 $H^2\log^3M/M=o(H^4/(M\log^2M))$；式 (3) 随之成立。$\square$

## 边界

这个支付覆盖所有满足 (1) 的 $\mu(q)=-1$ cofactor 与其同倍数直接源的交叉项，源 $u$ 不受奇偶限制；它包括全部奇素数、$q=2$ 及奇数个不同素因子的平方自由合数，并包含 [scratch/865](865-true-k3-k1-mobius-cross-arm-has-constant-opposite-sign-blocks.md) 的 $q=3$ 共振部分。它不覆盖 $e$ 接近 $qu$ 但不等于 $qv$ 的非共振邻点；$\mu(q)=+1$ 的 cofactor 在同一精确分解中给**正** Gram，也未支付。其余源配对、完整 moving-$N$ 均方、全尺度局部 Weil 正性及 RH 仍开放。

更准确地，若把 (1) 的定义延伸到全部 $\mu(q)^2=1$ 的 $q\ge2$，并对同一物理子族记过滤后总和为 $\mathfrak T^{\rm sf}_{M,H}$，上述证明逐字给
\[
 \mathfrak T^{\rm sf}_{M,H}
 =\frac{4\log2}{M^2}
 \sum_{\substack{q\ge2\\\mu(q)^2=1}}
 \mu(q)a(q)\sum_h w_H(h)|F_{q,h}|^2
 +O_{s,\psi}\!\left(
 \frac{H^2\log^3(2M)}M+
 \frac{H^4}{M\log^2(2M)}+M^{-2}\right).
 \tag{7}
\]
式 (7) 精确指出这套共振支付的下一道算术门是 $\mu(q)=+1$ 的正谱质量与 $\mu(q)=-1$ 的负谱质量之间的真实跨 cofactor 平衡；它不是这一平衡的上界。尤其不能从 (3) 推出删除 $\mathfrak T_{M,H}$ 后的余项也满足目标，负主项可能正是其他正块所需的补偿。偶数 $q$ 的选定直接源在 scratch/864 的奇数源配对中还会与另一个 cofactor 项点态抵消，故 (3) 也不能单独当作完整奇数源核的估计。

固定最小的正 cofactor $15=3\cdot5$，这个平衡还可作**真实系数的精确分解**。在 (1) 的记号下定义
\[
 A_h=\sum_{\substack{u\in U_3\\5\nmid u}}
 \mu(u)\phi(3u/M)e(-3hu/M),\qquad
 B_h=\sum_{\substack{u\in U_5\\3\nmid u}}
 \mu(u)\phi(5u/M)e(-5hu/M),\qquad C_h=F_{15,h}.
\]
充分大 $M$ 时，若 $u=5v\in U_3$ 且 $\mu(u)\ne0$，则 $(v,15)=1$、$15v\in(M,2M)$，且 $v>M/15>D$；故 $v\in U_{15}$、$\mu(u)=-\mu(v)$。对 $U_5$ 中 $u=3v$ 同理。因此对**每个** $h$，
\[
 F_{3,h}=A_h-C_h,\qquad F_{5,h}=B_h-C_h.
 \tag{8}
\]
由 $a(15)=a(3)+a(5)=4\log15$，式 (7) 中 $q=3,5,15$ 三项在每个频率上精确化为
\[
 \boxed{\quad
 -a(3)|F_{3,h}|^2-a(5)|F_{5,h}|^2+a(15)|F_{15,h}|^2
 =-a(3)|A_h|^2-a(5)|B_h|^2
 +2\operatorname{Re}\bigl[(a(3)A_h+a(5)B_h)\overline{C_h}\bigr].
 \quad}\tag{9}
\]
所以 $q=15$ 的独立正平方质量在这三条真实倍数臂中完全消去；未付项是 $A_h,B_h$ 与 $C_h$ 的混合 signed covariance。式 (9) 没有给该混合项的固定幂上界，也没有包含其他 $q$ 或非共振物理项。

同一消去有一个有限素数集的精确形式。固定奇素数集 $S$，记 $P=\prod_{p\in S}p$。把当前窗中的奇数平方自由 $m$ 按 $T=\{p\in S:p\mid m\}$ 分组，令
\[
 X_{T,h}=\sum_{\substack{M<m<2M,\ m\text{ odd},\mu(m)^2=1\\
 \{p\in S:p\mid m\}=T}}
 \mu(m)\phi(m/M)e(-hm/M).
\]
对非空 $R\subseteq S$，取 $q_R=\prod_{p\in R}p$，并将 $F_{q_R,h}$ 限制到上述奇数平方自由物理点，记为 $F^{\rm odd}_{R,h}$。因 $P$ 固定、$M/P>D$ 对充分大 $M$ 成立，式 (1) 的高除数条件不会删去任何这些点。乘法性于是给
\[
 F^{\rm odd}_{R,h}=\mu(q_R)\sum_{T\supseteq R}X_{T,h}.
\]
展开平方并用 $4\log q_R=4\sum_{p\in R}\log p$，得到对每个 $h$ 的**精确素因子交集式**
\[
 \boxed{\quad
 \sum_{\varnothing\ne R\subseteq S}
 \mu(q_R)\,4\log q_R\,|F^{\rm odd}_{R,h}|^2
 =-4\sum_{p\in S}(\log p)
 \sum_{\substack{T,U\subseteq S\\T\cap U=\{p\}}}
 X_{T,h}\overline{X_{U,h}}.
 \quad}\tag{10}
\]
右侧按 $T,U$ 有序求和；同一素数 $p$ 是交集的唯一元素。证明中的系数恒等式是
$\sum_{\varnothing\ne R\subseteq I}(-1)^{|R|}\sum_{p\in R}\log p
=-\log p$ 当 $I=\{p\}$，而 $|I|\ne1$ 时为零。式 (10) 表明全部多素因子共同交集项精确消失，剩余的是**恰共享一个指定素数**的因子类别协方差；其符号未定，尚不能支付全门。
这里 $S$ 必须固定；让 $S$ 随 $M$ 增长会重新遇到 $m/q>D$ 的截断边界。

单靠 (8) 的包含关系不能推出三项之和非正：形式 Fourier 数据 $A_h=B_h=C_h\ne0$ 使 $F_{3,h}=F_{5,h}=0$，左侧为 $a(15)|C_h|^2>0$。这只否定**纯代数逐频主导不等式**，并不声称真实 $\mu$ 产生这样的完整频带数据。
