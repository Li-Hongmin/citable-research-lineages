# 两素数混合比偶极把低整数补反馈候选下界推进到三分之一对数（待异源复核）

日期：2026-09-29。沿用 [scratch 791](791-two-branch-reciprocal-dipole-feedback-candidate.md) 的物理偶极记号、[note 775](../notes/775-a-prime-source-has-logarithmic-arithmetic-coupling-to-the-complement.md) 的原始平移约定，以及 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的位置无关单槽能量。此处仍研究 \(k=p^2\) 上真实旧奇算子的低整数正交补；不把条件性 Schur 反馈视为 RH 结论。

## 候选命题

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(L=\log k\)，\(P_p\) 是整数半槽 \(e_m\)、\(2\le m\le p\) 的正交投影，\(Q_p=I-P_p\)。若完整旧奇算子 \(A_{k,-}\succeq a_kI\)、\(a_k>0\)，则
\[
\boxed{\left\langle Q_pA_{k,-}e_p,
(Q_pA_{k,-}Q_p)^{-1}Q_pA_{k,-}e_p\right\rangle
\ge\left(\tfrac13+o(1)\right)\log k.}
\tag{1}
\]
压缩逆按闭形式理解；式 (1) 不要求已知完整旧核正性，只陈述在它严格正的端点上必需支付的反馈。它改进 scratch 791 的 \(\frac14\log k\) 候选下界。

## 有理中心的精确分离

固定 \(0<\beta<1\)，置 \(P=p^\beta\)，只用素数 \(q,r\le P\)。沿 scratch 791 的 \(\Delta=\frac12\log(1+1/p^2)\)、\(F=(2\Delta)^{-1/2}\)，定义偶极
\[
\varphi_z=F\bigl(1_{(\log z-\Delta,\log z)}
-1_{(\log z,\log z+\Delta)}\bigr),
\qquad
w_x=\frac{\varphi_{px}+\varphi_{p/x}}{\sqrt2}
\quad(x>1).
\tag{2}
\]
令 \(\mathcal X=\{q:q\le P\text{ 素数}\}\cup
\{q/r:r<q\le P\text{ 不同素数}\}\)。每个 \(x\in\mathcal X\) 是既约分数 \(a/b>1\)，其中 \(a,b\le P\)。它的两个中心处于旧区间内部；\(w_x\) 是单位奇向量。

对两个不同的既约比 \(x=a/b,y=c/d\)（包括把某个比换成倒数），不相同的物理中心满足
\[
|\log(x/y)|=|\log(ad/bc)|\ge c_0/P^2,
\tag{3}
\]
因为 \(ad-bc\) 是非零整数且 \(ad,bc\le P^2\)。将中心 \(p\) 也加入时，最小间距至少 \(c_0/P\)：混合比满足 \(q/r\ge1+1/P\)。由于 \(2\Delta\asymp p^{-2}=o(P^{-2})\)，全部 \(w_x\) 两两正交。

它们也在 \(Q_pH_k^-\)。对于 \(w_{a/b}\) 与低整数 \(e_m\)、\(m\le p\)，唯一可能的近重合关系可写成 \(ma\approx pb\)（或其倒数形式）。若精确相等，\(p\) 为素数、\(a,b<p\)、\((a,b)=1\) 强制 \(m=p,a=b\)，与 \(a>b\) 矛盾；否则两个整数至少差一，使中心对数距离 \(\gg1/(pP)\gg\Delta\)。其他臂的位置更远。因此 \(w_x\perp P_pH_k^-\)。

更一般地，按原始约定 \(T_sf(t)=f(st)\)，向上移动支撑的是 \(T_s^*\)。对任意整数 \(s\ge2\) 和上述任意两个物理中心 \(z,z'\)，写 \(z/z'=A/B\)，其中 \(A,B\) 是不超过 \(P^2\) 的正整数。若 \(T_s^*\varphi_z\) 与 \(\varphi_{z'}\) 相交，则 \(|\log(sA/B)|<2\Delta=\log(1+p^{-2})\)，从而
\[
|sA-B|<B/p^2\le P^2/p^2<1.
\]
整数性强制 \(sA=B\)，即 \(sz=z'\)；此时 \(T_s^*\varphi_z=\varphi_{z'}\)。\(T_s\) 给出同一无向边的反向。特别地，对 \(\mathcal X\) 上非负系数的任意向量，完整算术二次型非正；不会有部分重叠产生的正交叉。

## 两条父边和试探能量

记 \(c_q=\Lambda(q)/\sqrt q=(\log q)/\sqrt q\)，其中以下 \(q\) 只取素数。对 \(r<q\le P\)，整槽平移分别给出
\[
\boxed{\langle w_{q/r},\mathcal R_kw_q\rangle=-c_r,
\qquad
\langle w_{q/r},\mathcal R_kw_r\rangle=-c_q.}
\tag{4}
\]
第一条来自中心 \(p(q/r)\to pq\) 与 \(p/q\to p/(q/r)\) 的反向配对；第二条来自 \(p/r\to p(q/r)\) 与 \(p/(q/r)\to pr\)。除这些父边外的算术边对下述正系数试探向量只给非正能量。

设
\[
S=\sum_{q\le P\atop q\text{ 素数}}c_q^2,
\quad U=\sum_{r<q\le P\atop q,r\text{ 素数}}c_q^2c_r^2,
\quad t_{p,\beta}=\sum_{q\le P}c_qw_q
+\frac2L\sum_{r<q\le P}c_qc_rw_{q/r}.
\tag{5}
\]
由正交性，\(\|t_{p,\beta}\|^2=S+4U/L^2\)。素数定理及高次项不存在给出
\[
S=\left(\frac{\beta^2}{8}+o(1)\right)L^2,
\qquad
U=\frac12S^2+O(1),
\tag{6}
\]
其中 \(\sum_qc_q^4<\infty\)。由 (4)，在算术能量中只保留两条父边已给出
\[
\mathcal R_k[t_{p,\beta}]\le-\frac{8U}{L}.
\tag{7}
\]

对完整 Archimedean 部分 \(G_k\)，每个偶极的两个半槽自能量之和为
\(D_k+O(\Delta)\)，\(D_k=L+1-\gamma_E-\log\pi\)；同一偶极的相邻半槽交叉为 \(O(1)\)。同一 \(w_x\) 的两个中心至少相隔 \(\gg1/P\)，故额外交叉为 \(o(1)\)。不同物理中心按 (3) 排序后，最小间距 \(\gg P^{-2}\)；核 \(K(v)\ll1/v\) 与 Schur 行和给出 off-diagonal 范数
\(O(\Delta P^2\log(2P))=o(1)\)。因此
\[
G_k[t_{p,\beta}]\le (L+C)\|t_{p,\beta}\|^2.
\tag{8}
\]
polar 二次型非正，(5)、(7)--(8) 遂给出
\[
\boxed{A_{k,-}[t_{p,\beta}]
\le (L+C)\left(S+\frac{4U}{L^2}\right)-\frac{8U}{L}
=LS-\frac{4U}{L}+O(L^2).}
\tag{9}
\]

根的算术像只落在第一层：\(e_p=\varphi_p\)，而原始平移约定给出
\((T_q+T_q^*)e_p=\varphi_{p/q}+\varphi_{pq}=\sqrt2w_q\)，故
\(\langle w_q,\mathcal R_ke_p\rangle=-\sqrt2 c_q\)。混合比 \(q/r\) 不能等于整数平移 \(s\) 或其倒数，所以相应系数为零。根中心到第一层距离至少 \(\log2-O(\Delta)\)，到混合层至少 \(c/P\)；逐列核界及 \(O(P^2)\) 个混合节点给出 Archimedean 根列的 \(\ell^2\) 范数 \(O(\Delta P^2)=o(1)\)。note 788 的 \(\langle s_k,e_p\rangle=O(p^{-3})\) 与 \(\|s_k\|=O(p^{1/2})\) 使 polar 根列也为 \(o(1)\)。由 \(\|t_{p,\beta}\|=O(L)\)，
\[
\boxed{\langle t_{p,\beta},A_{k,-}e_p\rangle
=-\sqrt2 S+o(1).}
\tag{10}
\]

## 变分下界与边界

各偶极是有限个紧支撑阶跃函数，其对数形式能量有限；note 788 已核对 \(e_p\in D(A_{k,-})\)。因此根配对和闭形式变分合法。若完整 \(A_{k,-}\) 严格正，则 \(t_{p,\beta}\in D(\mathfrak a_k)\cap Q_pH_k^-\) 可用于压缩逆度量变分；(9) 的分母为正。令 \(\alpha=\beta^2/8\)。由 (6)、(9)--(10)，对每个固定 \(0<\beta<1\) 得到
\[
\frac{|\langle t_{p,\beta},A_{k,-}e_p\rangle|^2}
{A_{k,-}[t_{p,\beta}]}
\ge\left(\frac{2\alpha}{1-2\alpha}+o(1)\right)L
=\left(\frac{\beta^2}{4-\beta^2}+o(1)\right)L.
\tag{11}
\]
先固定 \(\beta<1\) 再令 \(p\to\infty\)，最后令 \(\beta\uparrow1\)，便对任意 \(\eta>0\) 得充分大的正旧核端点的反馈至少为 \((1/3-\eta)L\)，即 (1) 的渐近表述。这里没有把 \(\beta\) 设为随 \(p\) 趋近于 \(1\) 的变量。

这个两层试探族仍只位于真实 \(Q_p\) 的有限维子空间；它不控制完整逆响应上界，也不足以耗尽根对角 \((1+o(1))L\)。全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 仍未判定。
