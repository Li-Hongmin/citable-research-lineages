# 固定深度 dyadic 奇数格的完整局部 Weil 压缩有统一正极限

日期：2026-10-03。依赖 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的完整 Weil 形式分解、[note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的槽轮廓谱隙，以及 [scratch 875](875-half-integer-companion-retains-maximal-weil-grid-schur-feedback.md) 的半整数交叉核。本文计算 dyadic 奇数格的精确极限矩阵，再以统一误差把自然权子空间的正性推进到 $2^R=o(p^2)$ 的深度。解析证明尚未异源复核，故留在 scratch；任意槽权及无限维补空间均不在结论内。全槽权与轮廓的增长深度结论另见 [scratch 973](973-growing-dyadic-odd-union-has-a-full-profile-weil-gap.md)。

## 定理候选

固定整数 $R\ge0$、实数 $C>2^R$、$0<x<2^{-R}$，以及非负实函数 $\varphi\in C_c^\infty((-1/2,1/2))$，$\|\varphi\|_2=1$。令奇素数 $p\to\infty$，并置
\[
H=\log p,\quad M=\left\lfloor\frac{p^2}{C}\right\rfloor-1,\quad
\ell=\frac{Cx}{p^2},\quad
S_M=\sum_{\substack{a\le M\\a\ {\rm odd}}}\frac1a,\quad
b_\ell(t)=\ell^{-1/2}\varphi(t/\ell).
\]
对 $0\le r\le R$ 与奇数 $1\le a\le M$，记
\[
y_{r,a}=H-\log C-\log(a/2^r),\qquad
v_r(y_{r,a}+t)=\frac{b_\ell(t)}{\sqrt{aS_M}},
\]
在这些槽外令 $v_r=0$。写 $\lambda=\log2$、$\kappa=\int\varphi$，并用 note 857 的 $C_\varphi=\int\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)$。充分大 $p$ 时，$v_0,\ldots,v_R$ 是支撑于 $(-H,H)$ 的正交单位向量。完整 Weil 形式压缩矩阵逐项收敛到实对称矩阵 $G_R=(g_{rs})$，其中
\[
\boxed{\begin{aligned}
g_{rr}&=\log(1/x)+C_\varphi+\gamma+\lambda-\log(2\pi)
             +\frac{\kappa^2x}{2},\\
g_{rs}&=-\lambda\,2^{-|r-s|/2}
             +\frac{\kappa^2x}{2}\,2^{|r-s|/2}
             \qquad(r\ne s).
\end{aligned}}                                                    \tag{1}
\]
在全部上述参数下，
\[
\boxed{\qquad G_R\succeq\frac1{10}I_{R+1}.\qquad}                  \tag{2}
\]
下界常数与 $R,C,x,\varphi$ 无关；逐项收敛所需的 $p$ 下界允许依赖这些固定参数。式 (2) 只判定这一有限维真实 Weil 压缩，不推出全尺度局部 Weil 正性或 RH。

## 几何与精确素数幂边

最小指标 $q=a/2^r$ 是 $2^{-R}$，故最高中心 $H-\log(C/2^R)<H$。最大指标是 $M$，而
\[
y_{0,M}+H=\log\frac{p^2}{CM}>\frac C{p^2}>\ell/2.
\]
不同指标的差至少为 $2^{-R}$；其对数中心间距渐近至少为 $2^{-R}/M>Cx/p^2=\ell$。所以全部槽相离，且 $\|v_r\|_2^2=S_M^{-1}\sum_{a\ {\rm odd}\le M}a^{-1}=1$。

若两个槽受素数幂平移 $\log k$ 后相交，相关指标 $q,q'$ 满足
\[
|q'-kq|\le M(e^\ell-1)=x+o(1)<2^{-R}.
\]
左侧若不为零，则因 $q,q'$ 的分母均整除 $2^R$ 而至少为 $2^{-R}$，矛盾。因此所有素数幂边都精确满足 $q'=kq$ 或反向关系。同一 $r$ 内只可能有奇素数幂边。若 $r>s$，跨格比例为 $q_s/q_r=2^{r-s}b/a$，其中 $a,b$ 均奇；它是整数素数幂当且仅当 $a=b$，此时幂为 $2^{r-s}$。

令 $D=\gamma+\lambda$ 与 $A_{\rm odd}(z)=\sum_{k\le z,\ k\ {\rm odd}}\Lambda(k)/k$。由 note 857 的加权素数定理扣去所有 $2$ 的幂，
\[
A_{\rm odd}(z)=\log z-D+o(1),\quad
S_M=\tfrac12(\log M+D)+o(1),\quad
\sum_{a\ {\rm odd}\le M}\frac{\log(M/a)}a
=\tfrac14(\log M)^2+\tfrac D2\log M+O(1).
\]
把 $a>M/A$ 的调和质量先截去，再令 $A\to\infty$，得到
\[
\frac2{S_M}\sum_{a\ {\rm odd}\le M}\frac{A_{\rm odd}(M/a)}a
=\log M-D+o(1).                                                   \tag{3}
\]
故每条对角线的 prime-shift 贡献是 $-\log M+D+o(1)$。跨格唯一的 $2^{|r-s|}$ 边给出精确贡献
\[
Q_{\rm prime}(v_r,v_s)
=-\frac{\Lambda(2^{|r-s|})}{2^{|r-s|/2}}
  \sum_{a\ {\rm odd}\le M}\frac1{aS_M}
=-\lambda\,2^{-|r-s|/2}.                                         \tag{4}
\]

## 普通核与 polar 项

单槽 Fourier 项对每个 $v_r$ 是 $\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)$。置 $q_{r,a}=a/2^r$、$T_r=2^rS_M$；同一个槽系数也等于 $q_{r,a}^{-1/2}/\sqrt{T_r}$。note 856 的普通核恒等式对任意不同的正指标成立：
\[
\frac{k(|\log(q/q')|)}{\sqrt{qq'}}
=\frac12\left(\frac1{|q-q'|}+\frac1{q+q'}\right).                 \tag{5}
\]
奇数间距为 $2$，因而对角格的无序倒距离和为
\[
\sum_{\substack{a<b\le M\\a,b\ {\rm odd}}}
\frac1{|q_{r,a}-q_{r,b}|}
=2^r\left(\frac M4\log M+O(M)\right).                            \tag{6}
\]
对应的 $1/(q+q')$ 和为 $O_R(M)$。完整形式包含两个有序方向，故
\[
Q_{\rm ord}[v_r]\longrightarrow-\frac{\kappa^2x}{2}.              \tag{7}
\]
若 $r>s$、$d=r-s$，则 $|q_{r,a}-q_{s,b}|=2^{-r}|a-2^db|$。对 $T=2^db\in(1,M)$，分别在 $T$ 左右把奇数 $a$ 写成 $T\pm(2j+1)$；由奇数调和和公式，内和为
$\log M+O(1+|\log(T/M)|+|\log(1-T/M)|)$。这两个对数在 $T/M\in(0,1)$ 可积，故对所有这类奇数 $b$ 求和的误差为 $O_R(M)$。当 $T>M$ 时，内和为 $O(1+\log(T/(T-M)))$，其端点奇性同样可积；这部分总计也是 $O_R(M)$。于是
\[
\sum_{a,b\ {\rm odd}\le M}\frac1{|q_{r,a}-q_{s,b}|}
=M2^{s-1}\log M+O_R(M),                                          \tag{8}
\]
而 $1/(q_{r,a}+q_{s,b})$ 的双和为 $O_R(M)$。因 $\sqrt{T_rT_s}=2^{(r+s)/2}S_M$，(5)、(8) 给
\[
Q_{\rm ord}(v_r,v_s)\longrightarrow
  -\frac{\kappa^2x}{2}\,2^{-d/2}.                                \tag{9}
\]
固定 $R,x$ 时，最小有理间距为 $2^{-R}$，且槽宽与对数中心间距之比严格小于一。两个槽的双积分与中心核值乘 $\kappa^2\ell$ 的差，由中值定理至多为 $O_\varphi(\ell^2\sup|k'|)$。在可比的指标 $q,q'$ 上，乘槽系数后有 $|k'|/\sqrt{qq'}\ll_R M/|q-q'|^2$；每行沿有理格差值求和为 $O_R(M)$，共 $O_R(M)$ 行。不可比的指标上 $k'$ 有界，而槽系数绝对双和为 $O_R(M)$。除以 $T_r$ 或 $\sqrt{T_rT_s}\asymp_R S_M$，(7)、(9) 的归一化误差为 $O_{R,C,x,\varphi}(\ell^2M^2/S_M)=o(1)$。

记 $N_M=\#\{a\le M:a\ {\rm odd}\}=M/2+O(1)$ 与 $m_\pm=\int b_\ell(t)e^{\pm t/2}dt$。实值轮廓给 $m_+m_-=\kappa^2\ell+o(\ell)$。两 polar 矩为
\[
P_+(v_r)=m_+\sqrt{p/C}\,\sqrt{T_r},\qquad
P_-(v_r)=m_-\sqrt{C/p}\,N_M/\sqrt{T_r}.
\]
完整 polar 形式为 $2P_+P_-$，故
\[
Q_{\rm pol}[v_r]\to\kappa^2x,\qquad
Q_{\rm pol}(v_r,v_s)\to
  \frac{\kappa^2x}{2}\left(2^{d/2}+2^{-d/2}\right).               \tag{10}
\]
将单槽、(3)--(4)、(7)、(9)--(10) 相加，使用 $\ell M\to x$ 以及 $\log(1/\ell)-\log M\to\log(1/x)$，得到 (1)。
作为系数核对，取 $R=1,C=4,x=c/4$：$r=1$ 的对角元恰是 scratch 875 式 (9) 的半整数格极限 $G$。

## 全部固定深度的正定性

note 858 给 $C_\varphi+\kappa^2+\gamma\ge46/25$。置 $\delta=46/25-\log(2\pi)>0$、$t=2^{-1/2}$。式 (1) 的对角元满足
\[
g_{rr}\ge \log(1/x)+\lambda+\delta-1+x/2.                        \tag{11}
\]
右端在 $0<x\le1$ 上严格递减。若 $d=|r-s|\le R$，则
\[
\frac{\kappa^2x}{2}\,2^{d/2}
<\frac12\,2^{-d/2}<\lambda\,2^{-d/2},
\]
所以所有非对角元严格为负，且 $|g_{rs}|\le\lambda t^d$。

当 $R=0$，(11) 给 $g_{00}\ge\lambda-1/2+\delta>0.19$。当 $R\ge1$，(11) 给共同对角下界
\[
g_{rr}>(R+1)\lambda-1+\delta+2^{-R-1}.                           \tag{12}
\]
对 $R=1,2,3,4,5$，最大非对角行和分别不超过
\[
\lambda t,\quad 2\lambda t,\quad
\lambda(2t+t^2),\quad
\lambda(2t+2t^2),\quad
\lambda(2t+2t^2+t^3).
\]
用 $0.69<\lambda<0.7$、$t<0.71$ 代入 (12)，五个对角优势依次严格大于 $0.13,0.20,0.47,0.78,1.20$。对 $R\ge6$，任意行的非对角绝对和小于
$2\lambda\sum_{d\ge1}t^d=2\lambda(\sqrt2+1)<3.39$，
而 (12) 大于 $7(0.69)-1=3.83$。实对称矩阵的 Gershgorin 不等式遂给 (2)。$\square$

## 增长至近最大深度的正子空间

固定 $0<\theta<1$ 与上述实单位轮廓 $\varphi$。令 $R=R(p)$ 为非负整数，满足
$2^R=o(p^2)$，等价地，$R\le2\log_2p-\omega(1)$。在前面的构造中取
\[
C=2^{R+1},\qquad x=\theta\,2^{-R},\qquad
\ell=\frac{2\theta}{p^2},\qquad
M=\left\lfloor\frac{p^2}{2^{R+1}}\right\rfloor-1.
\]
于是 $R+1$ 可以趋近 $2\log_2p$，同时 $M\to\infty$。对充分大 $p$，这些实际试函数满足更强的维数相关下界
\[
\boxed{\qquad
\sum_{r,s=0}^{R}z_rz_sQ_W^{\log p}(v_r,v_s)
\ge\frac{R+1}{40}\sum_{r=0}^{R}z_r^2
\quad\text{对所有 }z\in\mathbb R^{R+1}.
\qquad}                                                        \tag{13}
\]

先加强 (2)。上面的对角优势计算在 $R=0,1,2,3,4,5$ 分别给出大于
$0.19,0.13,0.20,0.47,0.78,1.20$ 的最小特征值下界，各自大于
$(R+1)/20$；对 $R\ge6$，同一下界大于
$0.69(R+1)-4.39>(R+1)/20$。因此对所有允许的 $R,x$，
\[
G_R\succeq\frac{R+1}{20}I.                                    \tag{13a}
\]
下面把固定 $R$ 的误差写成一致界。几何上最高中心恒为 $H-\log2$，
最小中心间距至少为 $(2+o(1))/p^2$，与槽宽 $2\theta/p^2$ 有固定比例的间隙。
又 $M(e^\ell-1)=\theta2^{-R}(1+o(1))<2^{-R}$，其中 $o(1)$
只需 $M\to\infty$；故精确素数幂边分类对当前全部深度仍成立。

令 $L=\log M\to\infty$。由经典素数定理的零自由区误差，$A_{\rm odd}(z)-\log z+D$ 在 $z\ge1$ 有界，且在 $z\ge\exp(\sqrt L)$ 为 $O(e^{-bL^{1/4}})$，其中 $b>0$ 固定。式 (3) 的调和平均在 $a\le M\exp(-\sqrt L)$ 上因而有此误差；其余 $a$ 的调和质量为 $O(\sqrt L)$，除以 $S_M\asymp L$ 后为 $O(L^{-1/2})$。两条显式奇数调和公式自身的误差是 $O(L^{-1})$，故全部 prime 对角元相对 (1) 的误差一致为 $O(L^{-1/2})$；跨格 prime 项仍精确。

对 $1\le d\le R$，置 $n=2^d$。按 (8) 的奇数调和求和、保留两端不足整格的项，
可得到对 $n,M$ 一致的版本
\[
\sum_{a,b\ {\rm odd}\le M}\frac1{|a-nb|}
=\frac{M}{2^{d+1}}L
+O\!\left(\frac{M(1+d)}{2^d}+L\right),\qquad
\sum_{a,b\ {\rm odd}\le M}\frac1{a+nb}
\ll\frac{M(1+d)}{2^d}+L.                                    \tag{14}
\]
若 $n\le M$，第一式的主项来自 $nb\le M$ 的 $M/(2n)+O(1)$ 个奇数 $b$；
逐行奇数调和和为
$L+O(1+|\log(nb/M)|+|\log(1-nb/M)|)$，
两端误差求和为 $O(M/n+L)$。对 $nb>M$，
把 $b\le 2M/n$ 与 $b>2M/n$ 分开：前者的对数端点奇性可积，
后者逐行是 $O(M/(nb))$，合计 $O(M(1+\log n)/n+L)$。
当 $n>M$ 时，所有行都属于后者或至多一个端点行，直接得 $O(L)$；
这也解释了 (14) 的 $+L$，此时写出的主项并非相对渐近式。
第二式在 $nb\le M$ 与其补集分别用
$\log(1+M/(nb))$ 和 $M/(nb)$ 求和。把 (14) 乘以 (5) 中的
$\ell2^r/\sqrt{T_rT_s}\asymp x\,2^{d/2}/(ML)$，其误差为
$O(x(1+d)2^{-d/2}/L+x2^{d/2}/M)=O(L^{-1})$，
对所有 $r,s\le R$ 一致；对角普通核的误差也是 $O(L^{-1})$。

中心核替换也一致：所有指标属于网格 $2^{-R}\mathbb Z$，每一行的倒距离平方和为 $O(2^{2R})$。用 (5) 下方的导数界，任意矩阵元的归一化替换误差至多
\[
O_\varphi\!\left(\frac{\ell^2M^2\,2^{2R}}L\right)
=O_\varphi(\theta^2/L).
\]
单槽 Fourier 与 polar 项的剩余误差为
$O_\varphi(p^{-2}2^{R/2})=o(L^{-1})$，因为 $2^R=o(p^2)$。
故实际压缩矩阵 $Q_p$ 与按当前 $R,x$ 写出的 (1) 满足
\[
\max_{r,s\le R}|(Q_p)_{rs}-(G_R)_{rs}|
\ll_{\theta,\varphi}L^{-1/2},\qquad
\|Q_p-G_R\|\ll_{\theta,\varphi}(R+1)L^{-1/2}.
\]
由于 $L\to\infty$，右端小于 $(R+1)/40$；与 (13a) 合并得到 (13)。
$\square$

## 范围

在几何所允许的全部固定宽度 $x<2^{-R}$ 上，任意固定个 dyadic
奇数格之间的 $2$ 的幂交叉都不足以制造负 Weil 方向；式 (13)
还覆盖 $2^R=o(p^2)$ 的增长深度，并已支付其普通核误差及排除近错位素数幂边。
结论仅限上述共同轮廓、自然权的特定正子空间，不控制任意槽系数、
其无限维补空间的 true-Schur 反馈或全尺度 Weil 正性。
真实 moving-$N$ Möbius signed covariance 也没有从本矩阵获得固定幂上界。
