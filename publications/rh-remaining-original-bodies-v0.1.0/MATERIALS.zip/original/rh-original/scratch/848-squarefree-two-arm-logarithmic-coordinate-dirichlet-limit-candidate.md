# 平方自由双臂 Farey 图的对数坐标 Dirichlet 极限（候选）

本稿已晋级为 [note 794](../notes/794-squarefree-two-arm-logarithmic-coordinate-dirichlet-limit.md)，以后者为准。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实 Weil 压缩与算术图、[note 792](../notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md) 的调和质量及平均缺失权、[scratch 846](846-squarefree-two-arm-perron-vector-has-a-positive-weil-rayleigh-limit-candidate.md) 的平方自由行式。以下判定固定宏观对数轮廓的主阶能量；异源复核前留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，令 \(H=\log p\)、\(k=p^2\)，并沿用 note 792 的 \(\mathcal N_p\)、\(x_{n,m}\) 与 \(w_{x_{n,m}}\)。对非零 Lipschitz 函数 \(F:[0,1]^2\to\mathbb C\)，置
\[
U_{p,F}=\sum_{(n,m)\in\mathcal N_p}
\frac{F(\log n/H,\log m/H)}{\sqrt{nm}}w_{x_{n,m}}.
\tag{1}
\]
定义 \(P_1F(\xi,\eta)=\int_0^1F(s,\eta)\,ds\)、\(P_2F(\xi,\eta)=\int_0^1F(\xi,t)\,dt\)。则
\[
\boxed{\quad
\lim_{p\to\infty}
\frac{\langle U_{p,F},A_{p^2,-}U_{p,F}\rangle}
{H\|U_{p,F}\|^2}
=\frac{\|F-P_1F\|_2^2+\|F-P_2F\|_2^2}{\|F\|_2^2}.
\quad}\tag{2}
\]
右端算子为 \(2I-P_1-P_2\)。其谱值只有 \(0,1,2\)：常数函数的值为 \(0\)，仅依赖一个坐标且均值为零的函数值为 \(1\)，两个坐标各自均值为零的函数值为 \(2\)。因此任意固定非恒定 \(F\) 的真实 Weil Rayleigh 值是一个严格正的 \(H\) 倍量；恒定 \(F\) 的下一阶严格正常数由修正后的 scratch 846 给出。

## 调和极限及有界项

记 \(v_{n,m}=(nm)^{-1/2}\)、\(Z_p=\sum_{(n,m)\in\mathcal N_p}v_{n,m}^2\)。note 792 式 (4) 对截止 \(p^\xi,p^\eta\) 也成立；对每个 \(\xi,\eta>0\)，
\[
\frac1{Z_p}\sum_{\substack{(n,m)\in\mathcal N_p\\
\log n/H\le\xi,\ \log m/H\le\eta}}v_{n,m}^2
\longrightarrow\min(\xi,1)\min(\eta,1).
\tag{3}
\]
边界无极限质量，故这两个对数坐标的调和概率测度弱收敛于 \([0,1]^2\) 上的 Lebesgue 测度。特别地
\[
\|U_{p,F}\|^2/Z_p\longrightarrow\|F\|_2^2>0.
\tag{4}
\]

写 \(C_{S_p}\) 为 note 791 的算术矩阵在 \(S_p\) 上的主压缩，\(r_{n,m}=(C_{S_p}v)_{n,m}/v_{n,m}\)。scratch 846 式 (2) 与 \(P_5(t)-\log t=O(1)\) 对 \(t\ge1\) 一致给
\[
|r_{n,m}-(\log X+\log Y)|\le C+3F_0(nm),
\quad F_0(a)=\sum_{q\mid a}\frac{\log q}{q},
\quad X=(p-1)/4,\ Y=(p-1)/3.
\tag{5}
\]
note 792 式 (6) 给 \(Z_p^{-1}\sum v^2F_0(nm)=O(1)\)。因为 \(F\) 有界，\(D_k-(\log X+\log Y)=O(1)\)，基态变换中的行势平均只为 \(O_F(1)\)。note 791 的 \(\|E_p\|=O(1)\) 也只贡献 \(O_F(1)\) 的 Rayleigh 值。二者除以 \(H\) 后均消失。

## 素数边的连续极限

由 scratch 846 的边分类，改变 \(n\) 的 \(q\) 加删边，在基态变换的无向边能量中精确贡献
\[
\sum_{(n,m)\in\mathcal N_p}\frac1{nm}
\sum_{\substack{q\ge5\ \text{ prime}\\q\nmid nm,\ nq\le X}}
\frac{\log q}{q}
\left|F\!\left(\frac{\log(nq)}H,\frac{\log m}H\right)
-F\!\left(\frac{\log n}H,\frac{\log m}H\right)\right|^2.
\tag{6}
\]
改变 \(m\) 的边给坐标互换的同式。对 \(q\) 的互素限制可在 \(H Z_p\) 的尺度下删去：差的绝对值至多 \(4\|F\|_\infty^2\sum v^2F_0(nm)=O_F(Z_p)\)。\(q^2\) 换臂边的绝对能量同样由 \(F_0(nm)\) 控制为 \(O_F(Z_p)\)，故均不影响 (2)。

令 \(a_q=(\log q)/q\)。经典 Mertens 估计 \(\sum_{5\le q\le t}a_q=\log t+O(1)\) 对 \(t\ge1\) 一致。因此素数的对数位置测度满足
\[
\frac1H\sum_{5\le q\le p}a_q\,\delta_{\log q/H}
\Longrightarrow ds\big|_{[0,1]},
\tag{7}
\]
且其分布函数与 Lebesgue 分布函数的差一致为 \(O(H^{-1})\)。由于 \(F\) 是 Lipschitz 的，把 (6) 内和除以 \(H\) 后，一致趋于
\[
\int_0^{1-\xi}|F(\xi+s,\eta)-F(\xi,\eta)|^2\,ds,
\qquad \xi=\log n/H,\quad\eta=\log m/H.
\tag{8}
\]
这里 \(\log X/H=1+O(H^{-1})\)，所以截止 \(q\le X/n\) 与 (8) 的上限差在一致误差内。结合 (3)，\(n\) 臂的归一化能量极限为
\[
\int_0^1\!\int_0^1\!\int_0^{1-\xi}
|F(\xi+s,\eta)-F(\xi,\eta)|^2\,ds\,d\xi\,d\eta
=\|F-P_1F\|_2^2.
\tag{9}
\]
最后等式把 \(\xi+s\) 换成第二个坐标 \(\xi'\)，再用
\(\int_{0\le\xi<\xi'\le1}|g(\xi')-g(\xi)|^2d\xi d\xi'
=\int_0^1|g-\int g|^2d\xi\)。\(m\) 臂同理给 \(\|F-P_2F\|_2^2\)。基态变换、(4)--(9) 证明 (2)。\(\square\)

## 边界

定理只固定 \(F\) 再令 \(p\to\infty\)。它不对随 \(p\) 变化并在常数轮廓附近收缩的向量给统一谱隙，也不控制固定小素数的常数级修正、家族外的 Farey 向量或完整旧奇算子的 Schur 反馈。其严格正结论因此不能外推为全尺度 Weil 正性或 RH。
