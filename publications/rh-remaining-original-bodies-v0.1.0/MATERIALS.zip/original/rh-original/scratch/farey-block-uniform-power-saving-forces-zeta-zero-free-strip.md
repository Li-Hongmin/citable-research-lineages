# 固定幂 Farey 块的统一前缀消去强迫 ζ 零自由带

依赖：[块族算子抵消候选](farey-block-operator-cancellation-candidate.md) 式 (3)--(7) 的块法量纲与[分母次幂推进候选](moving-farey-subpower-denominator-extension-candidate.md) 式 (4) 的真实分子 \(a=1\) 系数。这里只判断一种**逐块统一前缀输入**的算术强度，不声称该输入已成立，也不限制可能的跨块 signed covariance 方法。

固定 \(4/5<\alpha<1\)，令
\[
\beta=2-\frac1\alpha,\qquad
\eta=\frac{5\alpha-4}{2\alpha}\in(0,1/2),\qquad
B_D=\left\lfloor\frac{D^\beta}{1000}\right\rfloor.
\tag{1}
\]
对每个整数 \(q\ge1\)，定义
\[
f(q)=\mu(q)\frac q{\varphi(q)},\qquad
b(q)=-f(q)-4f(q)\mathbf1_{2\nmid q}.
\tag{2}
\]
这正是既约分子 \(a=1\) 的首阶 Poisson 系数 \(b_1(q)\)。

**命题。** 假设对每个 \(\varepsilon>0\)，存在 \(C_{\alpha,\varepsilon}\)，使所有充分大的整数 \(D\)、所有满足 \(D/2\le t\le D-B_D\) 的整数 \(t\)，以及所有 \(t\le z\le t+B_D\)，都有
\[
\left|\sum_{t<q\le z}b(q)\right|
\le C_{\alpha,\varepsilon}B_DD^{-\eta+\varepsilon}.
\tag{3}
\]
则
\[
\sum_{q\le x}b(q)=O_{\alpha,\varepsilon}(x^{1-\eta+\varepsilon})
\quad\text{对每个 }\varepsilon>0,
\tag{4}
\]
并且 \(\zeta(s)\) 在 \(\Re s>1-\eta=(4-3\alpha)/(2\alpha)\) 无零。若式 (3) 对一列趋于 \(1\) 的 \(\alpha<1\) 分别成立，则 RH 成立。反过来，RH 蕴含每个固定 \(4/5<\alpha<1\) 的式 (3)。因此，沿任意 \(\alpha\uparrow1\) 的整族统一前缀命题与 RH 等价；这个等价性本身不是 RH 的证明。

**证明。** 在 \((D/2,D]\) 中铺设长 \(B_D\) 的连续整数块。每个完整块取式 (3) 的 \(z=t+B_D\)；余下不足一块的右端段可嵌入以 \(D\) 为右端点的长 \(B_D\) 块，并写成两个前缀之差。于是该 dyadic 段及其任意初段的 \(b\)-和都是
\[
O_{\alpha,\varepsilon}\!\left(
\left(1+\frac D{B_D}\right)B_DD^{-\eta+\varepsilon}
\right)
=O_{\alpha,\varepsilon}(D^{1-\eta+\varepsilon}).
\]
对 dyadic 段求和即得 (4)。

在 \(\Re s>1\)，由平方自由 Euler 因子及奇数限制，
\[
\sum_{q\ge1}\frac{b(q)}{q^s}
=-\bigl(5-2^{1-s}\bigr)
\prod_{p>2}\left(1-\frac p{p-1}p^{-s}\right).
\tag{5}
\]
因此
\[
\zeta(s)\sum_{q\ge1}\frac{b(q)}{q^s}
=J(s):=-\frac{5-2^{1-s}}{1-2^{-s}}
\prod_{p>2}
\frac{1-\frac p{p-1}p^{-s}}{1-p^{-s}}.
\tag{6}
\]
乘积每个因子与 \(1\) 的差为 \(O_\sigma(p^{-1-\sigma})\)，所以 \(J\) 在 \(\Re s>1/2\) 局部一致收敛且解析。它在那里无零：\(5-2^{1-s}\ne0\)，分母均不为零，而对 \(p\ge3\) 及 \(\sigma>1/2\)，
\[
\left|\frac p{p-1}p^{-s}\right|<\frac{\sqrt p}{p-1}<1.
\]
由 (4) 的分部求和，式 (5) 左侧的 Dirichlet 级数在 \(\Re s>1-\eta\) 解析。恒等式 (6) 因解析延拓仍成立。如果该区域有 \(\zeta(\rho)=0\)，则 (6) 迫使 \(J(\rho)=0\)，矛盾。对一列 \(\alpha\uparrow1\)，\(1-\eta(\alpha)\downarrow1/2\)；结合 ζ 的函数方程与已知非平凡零点对称性，即得 RH。

为证明逆向，(6) 中 \(J(s)\) 的 Euler 乘积是 \(\sum_{d\ge1}h(d)d^{-s}\)，且对每个 \(\sigma>0\) 均绝对收敛：在素数 \(2\) 处，
\[
-\frac{5-2^{1-s}}{1-2^{-s}}
=-5-3\sum_{j\ge1}2^{-js};
\]
在每个 \(p>2\) 处，因子为 \(1-\sum_{j\ge1}p^{-js}/(p-1)\)，其绝对系数乘积收敛，因为 \(\sum_p p^{-1-\sigma}<\infty\)。所以 \(b=\mu*h\)。RH 的经典等价推论 \(M(x)=\sum_{n\le x}\mu(n)\ll_\varepsilon x^{1/2+\varepsilon}\) 因而给
\[
\sum_{q\le x}b(q)
\ll_\varepsilon x^{1/2+\varepsilon}
\sum_{d\ge1}\frac{|h(d)|}{d^{1/2+\varepsilon}}
\ll_\varepsilon x^{1/2+\varepsilon}.
\]
任一式 (3) 的前缀是两个这样的部分和之差。由
\[
B_DD^{-\eta}\asymp D^{\beta-\eta},
\qquad \beta-\eta=\frac{2-\alpha}{2\alpha}>\frac12
\quad(\alpha<1),
\]
它满足式 (3) 的任意给定 \(\varepsilon>0\)。\(\square\)

**与块法的精确关系。** 令 \(D=Y^\alpha\)，则 \(B_D\asymp D^2/Y\)。块中心大筛的当前上界有量纲 \(D^5Y^{-2}\epsilon_Y^2\)（忽略对数），其中式 (3) 对应 \(\epsilon_Y\ll D^{-\eta+\varepsilon}=Y^{-(5\alpha-4)/2+\alpha\varepsilon}\)。这正达到 \(Y^{2+o(1)}\) 所需的固定幂节省。因此用这样的**统一前缀估计**补齐全部固定幂块，沿所有 \(\alpha\uparrow1\) 将回到 RH 等价输入。该结论不说明真实 Möbius 块不能通过跨块或跨分子抵消被支付。

## 所有固定分子都有同一零点门

上述现象不限于 \(a=1\)。对固定整数 \(a\ge1\)，取次幂推进候选式 (4) 的
\(g_a(q)=\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1}\) 与 \(b_a(q)\)，并令
\(B_a(s)=\sum_{q\ge1}b_a(q)q^{-s}\)。在 \(\Re s>1\) 写
\[
B_a(s)=\frac{J_a(s)}{\zeta(s)},\qquad
R_p(s)=\frac{1-\frac p{p-1}p^{-s}}{1-p^{-s}}.
\tag{7}
\]
若 \(a\) 为偶数，由于 \((a,q)=1\) 强制 \(q\) 为奇数，
\[
J_a(s)=3
\prod_{p\mid a}(1-p^{-s})^{-1}
\prod_{p\nmid a}R_p(s).
\tag{8}
\]
若 \(a\) 为奇数，按 \(q\) 的奇偶拆分得
\[
J_a(s)=
-\frac{5-2^{1-s}}{1-2^{-s}}
\prod_{\substack{p\mid a\\p>2}}(1-p^{-s})^{-1}
\prod_{\substack{p\nmid a\\p>2}}R_p(s).
\tag{9}
\]
在 \(\Re s>1/2\)，所有 \(J_a\) 解析且无零。证明是逐因子的：当 \(p>2\) 时
\(|p^{1-s}/(p-1)|<1\)；偶数 \(a\) 的 \(p=2\) 因子只在有限乘积中；奇数 \(a\)
的 \(5-2^{1-s}\) 也不为零。无限乘积局部一致收敛，因为
\(R_p(s)-1=O_\sigma(p^{-1-\sigma})\)。此外 \(J_a\) 和 \(1/J_a\) 都是
在每条 \(\Re s=\sigma>1/2\) 绝对收敛的 Dirichlet 级数：
\(R_p^{-1}=(1-p^{-s})/(1-\frac p{p-1}p^{-s})\) 的局部幂级数收敛，
其非零次绝对系数之和为 \(O_\sigma(p^{-1-\sigma})\)；
式 (8)--(9) 中其余素因子仅有有限多个。

因此对**每个固定** \(a\)，存在 \(h_a,k_a\)，其
\(\sum_n(|h_a(n)|+|k_a(n)|)n^{-\sigma}<\infty\) 对每个 \(\sigma>1/2\) 成立，并且
\[
b_a=\mu*h_a,\qquad \mu=b_a*k_a.
\tag{10}
\]
经典 \(M(x)=O_\varepsilon(x^{1/2+\varepsilon})\) 与
\(\sum_{q\le x}b_a(q)=O_{a,\varepsilon}(x^{1/2+\varepsilon})\)
遂双向等价于 RH。特别地，把逐块统一前缀法从 \(a=1\) 换到另一个**固定**分子，
不会去掉它的 \(\zeta\) 零点门。式 (10) 不给跨分子、跨块联合能量的上界。
