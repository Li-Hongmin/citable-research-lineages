# 完整观察与高除数 Gram 的大物理 gcd 可绝对支付

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(11) 的真实联合系数、[scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (2)、(9) 的高除数系数和除数均值，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 式 (9) 的带通核衰减。本稿同时处理原始联合观察 Gram 与其完整高除数展开的物理配对，不限于 [scratch/867](867-squarefree-resonance-reduces-to-prime-gcd-covariance.md) 的共振子族。论证留在 scratch，尚未异源复核；小物理 gcd 的真实 signed covariance 仍未估计。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D=\lfloor M/(16H)\rfloor$，固定 $s>1$、实 $\psi\in C_c^3((1,2))$，取 scratch/860 的 $w_H,J_H$。设
\[
 a_m=\frac{c(m)}M\phi(m/M),\qquad
B(m)=\sum_{d>D}|b_d(m)|,
\qquad J_H(r)=\sum_h w_H(h)e(-hr/M),
\tag{1}
\]
其中 $c(m)$ 是 note 849 的真实联合系数、$b_d(m)$ 是 scratch/859 的高除数系数；两种权在 $\phi(m/M)=0$ 时均为零。对每个 $2\le T\le M$，有一致的**无符号**界
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\m\ne n,\ (m,n)>T}}
|a_m a_n J_H(m-n)|
\ll_{s,\psi}\frac{\log^2(2M)}T.
\quad}\tag{2a}
\]
同样，对完整高除数展开而非仅其共振子族，有
\[
\boxed{\quad
\sum_{\substack{M<m,n<2M\\m\ne n,\ (m,n)>T}}
B(m)B(n)|J_H(m-n)|
\ll_{s,\psi}\frac{\log^8(2M)}T.
\quad}\tag{2b}
\]
连同各自的对角界，取 $T=H$ 后，(2a) 的完整观察误差为 $O(\log^2(2M)/H)$，(2b) 的高除数展开误差为
\[
\sum_{\substack{M<m,n<2M\\(m,n)>H}}
B(m)B(n)|J_H(m-n)|
\ll_{s,\psi}\frac{\log^8(2M)}H
\ll_{s,\psi,\varepsilon}H^4M^{-1+\varepsilon}
\quad(\varepsilon>0).
\tag{3}
\]
因此 note 849 式 (13) 的完整观察 Gram，以及 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (12) 的真实 $\mu(d)\mu(e)$ 剩余门，均可在目标幂次误差内再限制为**物理点** $\gcd(m,n)\le H$。这里的 gcd 是 $m,n$ 的 gcd，不是源索引 $d,e$ 的 gcd；对其余小 gcd 项没有作符号估计。

## 证明

由 note 849 式 (10)，$c(m)$ 只含 $\Lambda(m/2)$、$\Lambda(m)$、$\mu(m)$ 与常数，故 $|c(m)|\ll\log(2M)$、$|a_m|\ll_\psi\log(2M)/M$。若 $g\mid(m,n)$、$m\ne n$ 且 $a_ma_n\ne0$，则 $g\le|m-n|\le(1-\kappa_\psi)M$。给定这样的 $g$，$m$ 的候选数为 $O(M/g)$，而 $m-n=gk$；下文式 (6) 的核求和为 $O(M/g)$。按所有公共除数 $g>T$ 过计，直接得到
\[
\sum_{\substack{m\ne n\\(m,n)>T}}|a_m a_nJ_H(m-n)|
\ll_{s,\psi}\frac{\log^2(2M)}{M^2}
\sum_{g>T}\frac Mg\frac Mg
\ll_{s,\psi}\frac{\log^2(2M)}T,
\tag{2c}
\]
即 (2a)。这里始终保留 $a_m a_n$ 的紧支撑，故式 (6) 的非别名核界适用。其对角量至多为 $H\sum_m|a_m|^2\ll_\psi H\log^2(2M)/M$。

下证高除数的 (2b)。

scratch/859 式 (9) 给出
\[
B(m)\ll_\psi\frac{\log(2M)}M\tau(m),
\qquad
\sum_{n\le X}\tau(n)^2\ll X\log^3(2X).
\tag{4}
\]
后一界也可由 $\tau(n)^2\le d_4(n)$ 及四重除数均值直接得到。$\tau(ga)\le\tau(g)\tau(a)$ 对所有正整数成立。

因 $\phi$ 紧支撑于 $(1,2)$，存在固定 $\kappa_\psi>0$，使任意 $B(m)B(n)\ne0$ 满足 $|m-n|\le(1-\kappa_\psi)M$。写 $W=M/H$。scratch/860 式 (9) 给
\[
|J_H(r)|\ll_{s,\psi}H
\left(e^{-c_s(|r|/W)^{1/s}}+e^{-c_{s,\psi}H^{1/s}}\right)
\quad(|r|\le(1-\kappa_\psi)M).
\tag{5}
\]
对任意整数 $g\ge1$，以单调函数积分比较第一项，并注意 $|gk|\le M$ 时 $k$ 至多有 $O(M/g)$ 个，得到
\[
\sum_{\substack{k\in\mathbb Z\setminus\{0\}\\|gk|\le(1-\kappa_\psi)M}}
|J_H(gk)|
\ll_{s,\psi}H\frac Wg
+H e^{-c_{s,\psi}H^{1/s}}\frac Mg
\ll_{s,\psi}\frac Mg.
\tag{6}
\]
最后一步只用 $H\gg M^{1/5}$。这一步须排除 $k=0$；对角另在下文处理。

若 $(m,n)>T$ 且 $m\ne n$，至少有一个公共除数 $g>T$；按全部这样的 $g$ 求和只会增加无符号上界。令 $m=ga,n=gb$。保留原支撑给出的 $|g(a-b)|\le(1-\kappa_\psi)M$，故对非对角项只需 $g\le(1-\kappa_\psi)M$。由 (4) 和 $a,b\le2M/g$，(2b) 左侧不超过
\[
\frac{\log^2(2M)}{M^2}
\sum_{T<g\le(1-\kappa_\psi)M}\tau(g)^2
\sum_{\substack{a,b\le2M/g\\a\ne b\\|g(a-b)|\le(1-\kappa_\psi)M}}
\tau(a)\tau(b)|J_H(g(a-b))|.
\tag{7}
\]
对固定非零 $k=a-b$，Cauchy--Schwarz 与 (4) 给
\[
\sum_{\substack{a,b\le2M/g\\a-b=k}}\tau(a)\tau(b)
\le\sum_{a\le2M/g}\tau(a)^2
\ll\frac Mg\log^3(2M).
\tag{8}
\]
将 (6)、(8) 代入 (7)，得到
\[
\text{(7)}\ll_{s,\psi}\log^5(2M)
\sum_{g>T}\frac{\tau(g)^2}{g^2}.
\tag{9}
\]
再对 (4) 的平方除数均值分部求和，
\[
\sum_{g>T}\frac{\tau(g)^2}{g^2}
\ll\frac{\log^3(2T)}T.
\tag{10}
\]
式 (9)--(10) 即 (2b)。

对角 $m=n$ 的全部绝对质量已由 scratch/859 式 (9) 与 $J_H(0)\ll H$ 支付为
\[
\sum_mB(m)^2|J_H(0)|
\ll_\psi\frac{H\log^5(2M)}M.
\tag{11}
\]
因为 $H\le Y^{1/4}$，(11) 是 $O(\log^8(2M)/H)$。取 $T=H$ 合并 (2b)、(11)，得到 (3)；(2a) 的对角更小。$H^5\ge Y=M/2$ 保证 $H^{-1}\le2H^4/M$，固定对数幂由 $M^\varepsilon$ 吸收。

最后，scratch/859 式 (12) 中每个带符号物理项的绝对值均被 $B(m)B(n)|J_H(m-n)|$ 支配；因此删除 $(m,n)>H$ 的总成本至多 (3)，与源索引的整除、约化比例和物理距离过滤是否已施加无关。$\square$

## 决策边界

这个结果把 [scratch/867](867-squarefree-resonance-reduces-to-prime-gcd-covariance.md) 的大 gcd 支付从平方自由共振切片扩展到**完整观察系数与高除数 Gram**，只使用真实系数的绝对上包络及带通核衰减。它仍不支付小 gcd 的中距离配对：尤其 [scratch/861](861-prime-prime-block-survives-the-true-high-divisor-observation-gate.md) 的 $\gg\log^{-2}M$ 正素数块全部满足 $\gcd(m,n)=1$，而 [scratch/865](865-true-k3-k1-mobius-cross-arm-has-constant-opposite-sign-blocks.md) 的常量级异号补偿也存活。因此 (3) 是目标量级的真删项，不是完整门的证明；后续的第一个未付 gcd 类应为 $1$，而非单独的 $3$。
