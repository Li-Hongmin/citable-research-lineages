# 真实末带 Fejér 子包在五分之一次幂归约为单一半整数奇胞 Möbius 梳

日期：2026-10-02。沿用 [scratch/943](943-nearby-terminal-poisson-packet-has-one-dirichlet-weighted-mertens-mode.md) 式 (1)、(4)、(22)–(23) 的真实原始 Poisson 项、物理短管与 Fejér 权；精确来源为 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 和 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1)。本稿只作解析归约，尚待异源复核。它不证明下面的奇胞 Möbius 和具有目标均方，也不证明完整 moving-$N$ 门或 RH。

## 命题

令 $Y\to\infty$ 沿整数，$Y^{1/5}\le H\le Y^{1/4}$ 为整数，
\[
T=\left\lceil\frac{Y^{1/2}}{H^2}\right\rceil,\qquad
z=N/Y\in(3/2,8/5],\qquad x_q=q/Y,
\quad
f_z(x)=\frac{\log(z/x)}{\pi z x},\qquad L(x)=\frac{x}{\log Y}.
\tag{1}
\]
对 $Y<q\le11Y/10$，置 $a_q=\lfloor Hx_q\rfloor$、$t_q=\{Hx_q\}$、$u_q=z/x_q=N/q$。令 $P_{T,H}(N)$ 是 scratch/943 式 (22) 的**真实物理 Poisson 子包**，不附加互素掩码。定义显式奇胞 Möbius 梳
\[
\mathcal O_{T,H}(N)
=-\frac{2}{H^2}\sum_{Y<q\le11Y/10}
\mu(q)f_z(x_q)(-1)^{a_q}
\mathbf1_{\,0<t_q<L(x_q)}
\mathsf F_T(u_q+1/2)
\cos(2\pi Hz-2\pi t_qu_q).
\tag{2}
\]
这里 $\mathsf F_T(v)=T^{-1}(\sin(\pi Tv)/\sin(\pi v))^2$，在整数处取连续值 $T$。则一致于所取 $H,N$，
\[
\boxed{\quad
P_{T,H}(N)=\mathcal O_{T,H}(N)+O(Y^{1/2}).
\quad}
\tag{3}
\]
因而对每个固定 $\varepsilon>0$，该真实 Fejér 子包的 $\sum_N|P_{T,H}(N)|^2\ll_\varepsilon Y^{2+\varepsilon}$ 与同一界用于 (2) 等价；此处“等价”仅指两个明确子包相差已支付的 $O(Y^2)$ 均方，不是 RH 证明。对 $H\ge Y^{2/9}$，scratch/943 式 (29) 已支付 (2)；$Y^{1/5}\le H<Y^{2/9}$ 是这个 Fejér 机制剩余的明确奇胞算术区。

## Fejér 导数的离散质量

在任意固定长度的实区间上，Fejér 核满足
\[
\|\mathsf F_T\|_{L^1}\ll1,\qquad
\|\mathsf F_T'\|_{L^1}\ll T,\qquad
\|\mathsf F_T''\|_{L^1}\ll T^2.
\tag{4}
\]
第一式由周期积分 $\int_0^1\mathsf F_T=1$ 与非负性得到。后两式直接对
$T^{-1}\sin^2(\pi Tv)/\sin^2(\pi v)$ 求导：在距整数 $d\le T^{-1}$ 的区间，用有限 Fourier 展开有
$|\mathsf F_T^{(r)}|\ll T^{r+1}$；在 $d>T^{-1}$ 上，分母逐次求导所得项的积分对 $r=1,2$ 分别为 $O(T)$、$O(T^2)$。这些界也适用于平移 $v\mapsto v+1/2$。

对 $q\asymp Y$，映射 $x=q/Y\mapsto u=z/x$ 在固定比例区间上单调，且导数和逆导数一致有界。对绝对连续函数的等距格点 Riemann 和使用总变差，(4) 因而给
\[
\sum_{q\asymp Y}
\left|\mathsf F_T'(zY/q+\beta)\right|
\ll YT+T^2,\qquad
\sum_{q\asymp Y}\mathsf F_T(zY/q+\beta)
\ll Y+T
\quad(\beta=0,1/2).
\tag{5}
\]
例如第一式的积分部分是 $Y\int|\mathsf F_T'(z/x+\beta)|dx\ll YT$；离散误差至多
$\operatorname{Var}_x|\mathsf F_T'(z/x+\beta)|
\le\int|\mathsf F_T''(z/x+\beta)|\,|d(z/x)|\ll T^2$。

## 保留分子求和的真实振幅误差

对真实管 $q\in I_a$，记 $x=q/Y$、$t=Hx-a$、$u=z/x$、$h=a+j=Hx+(j-t)$。因 $T\le H/4$，有 $h\asymp H$。note 801 的精确振幅中
$r_h(x/(hz))=c_h+O(H^{-2})$，其中 $c_h=1+2(-1)^h$。对 $s=j-t$ 作带一致余项的 Taylor 展开，
\[
\frac{x}{h^2}
=\frac1{xH^2}-\frac{2s}{x^2H^3}
+O\!\left(\frac{s^2}{H^4}\right).
\tag{6}
\]
将 (6) 乘上 $w_{j,T}c_{a+j}\cos(2\pi Hz+2\pi(j-t)u)$ 后再对 $|j|<T$ 求和，不能逐 $j$ 取绝对值。由
\[
\sum_jw_{j,T}c_{a+j}e(ju)
=\mathsf F_T(u)+2(-1)^a\mathsf F_T(u+1/2),\qquad
\sum_jj\,w_{j,T}c_{a+j}e(ju)
=\frac{\mathsf F_T'(u)+2(-1)^a\mathsf F_T'(u+1/2)}{2\pi i},
\tag{7}
\]
一阶振幅误差的每 $q$ 绝对值至多
\[
\frac{C}{H^3}\left(
|\mathsf F_T'(u)|+2|\mathsf F_T'(u+1/2)|
+t[\mathsf F_T(u)+2\mathsf F_T(u+1/2)]
\right).
\tag{8}
\]
二阶余项每 $q$ 至多 $O(T^3/H^4)$，因为
$\sum_{|j|<T}w_{j,T}(j-t)^2\ll T^3$。$r_h-c_h$ 的余项每 $q$ 至多 $O(T/H^4)$。全部真实短管属于 $q\asymp Y$，且 $t=O(1/\log Y)$；由 (5) 对 (8) 求和，真实管内用 $c_hf_z(x)/H^2$ 代替精确振幅的总误差为
\[
\ll\frac{YT+T^2+(Y+T)/\log Y}{H^3}
+\frac{YT^3}{H^4}
\ll\frac{YT}{H^3}+\frac{YT^3}{H^4}.
\tag{9}
\]
这里 $|\mu(q)|\le1$，没有借用 Möbius 相消。

scratch/943 式 (6)–(7) 已证明真实 $I_a$ 与模型窗
$Y<q\le11Y/10,\ 0<\{Hq/Y\}<x_q/\log Y$
的对称差有 $O(Y/H)$ 个 $q$。每个差异格点的完整 Fejér 分子主权由 (7) 至多为 $O(T/H^2)$，故几何替换再付 $O(YT/H^3)$。记所得模型为 $M_{T,H}(N)$，合并 (9) 得
\[
P_{T,H}(N)=M_{T,H}(N)
+O\!\left(\frac{YT}{H^3}+\frac{YT^3}{H^4}\right).
\tag{10}
\]
由于 $T\asymp Y^{1/2}/H^2$，在 $H\ge Y^{1/5}$ 时两项分别至多
$Y^{3/2}/H^5\le Y^{1/2}$ 与 $Y^{5/2}/H^{10}\le Y^{1/2}$。

## 偶部分逐项支付，留下奇胞梳

式 (7) 的首式把模型精确分为 (2) 和偶部分
\[
M^{\rm even}_{T,H}(N)
=-\frac1{H^2}\sum_{Y<q\le11Y/10}
\mu(q)f_z(x_q)\mathbf1_{\,0<t_q<L(x_q)}
\mathsf F_T(u_q)\cos(2\pi Hz-2\pi t_qu_q).
\tag{11}
\]
所取 $u_q\in[15/11,8/5]$ 与整数有固定间距，故 (23) 给
$\mathsf F_T(u_q)\ll T^{-1}$。用 $|f_z|\ll1$、$|\mu|\le1$ 和至多 $O(Y)$ 个 $q$，得到
\[
|M^{\rm even}_{T,H}(N)|\ll\frac{Y}{H^2T}\le Y^{1/2}.
\tag{12}
\]
式 (10)–(12) 证明 (3)。对 $O(Y)$ 个观测整数取平方，误差的均方为 $O(Y^2)$，证明所述子包均方等价。$\square$

## 算术边界

式 (2) 的 Fejér 因子在 $u_q=3/2$、即 $q=2N/3$ 附近高为 $T$、主宽约 $Y/T$；奇胞因子 $(-1)^{\lfloor Hq/Y\rfloor}$ 在该带内约交替 $H/T$ 次。以 scratch/943 的 Srivastav 全前缀界单独作有界变差 Abel 求和，得到的仍是 $O(TY/H^{5/2})$，在 $H=Y^{1/5}$、$T=Y^{1/10}$ 时为 $Y^{3/5}$，比目标点态量纲多 $Y^{1/10}$。项目已核对的 Matomäki–Shao–Tao–Teräväinen 全区间短和对该长度只给任意对数幂节省，也未提供所需固定幂。这里需要的是对真实 $\mu(q)$、移动中心 $2N/3$ 和奇胞调制的联合相消；式 (3) 本身没有给它。
