# Farey 槽外互素矩形承载正比例的 polar 质量（候选）

日期：2026-09-30。沿 [note 805](../notes/805-dense-farey-constant-slots-have-attraction-and-positive-joint-compression.md) 的全宽常值奇槽及 [note 808](../notes/808-full-farey-constant-polar-projection-has-positive-logarithmic-energy.md) 的 polar 向量约定。这里只计算物理支撑与 polar 投影；未估计这个新空间上的完整 Weil 主压缩或 Schur 补，结论尚待独立复核。

令奇素数 \(p\to\infty\)，\(H=\log p\)，
\(L=\log(1+p^{-2})\)。对 \(1<z<p\) 定义
\[
q_y(u)=L^{-1/2}\mathbf1_{|u-\log y|<L/2},\qquad
\psi_z=\frac{q_{pz}-q_{p/z}}{\sqrt2},\qquad
s_{p^2}(u)=\sinh\!\left(\frac{u-H}{2}\right)
\quad(0<u<2H).
\tag{1}
\]
取如下互素整数矩形中的既约分数：
\[
\mathcal G_p=\left\{z=\frac nb:\
\frac{p^{3/2}}8\le n\le\frac{p^{3/2}}4,
\quad\frac{\sqrt p}{2}\le b\le\sqrt p,
\quad(n,b)=1\right\},\qquad
U_p^{\rm ext}=\operatorname{span}\{\psi_z:z\in\mathcal G_p\}.
\tag{2}
\]
所有 \(z\) 落在 \([p/8,p/2]\)，故上下两臂完整位于物理区间，
且对充分大 \(p\) 有既约分子 \(n>p-1\)，不属于全 Farey 集。

## 命题

\(\{\psi_z:z\in\mathcal G_p\}\) 是正交单位族，
其全部物理支撑与全 Farey 槽的全部物理支撑不交。
因此 \(U_p^{\rm ext}\) 正交于全 Farey 槽的**任意有限能量轮廓**空间。
此外
\[
\boxed{\quad
\|P_{U_p^{\rm ext}}s_{p^2}\|^2
\sim\frac{3\log2}{256\zeta(2)}\,p.
\quad}\tag{3}
\]
而整个旧奇物理区间中的 \(\|s_{p^2}\|^2=\sinh H-H\sim p/2\)。
所以一个固定的槽外互素矩形就承载 polar 向量平方质量的
正比例；把 [note 808](../notes/808-full-farey-constant-polar-projection-has-positive-logarithmic-energy.md)
的 Farey 投影 \(O(H)\) 延伸为整个槽外补空间的界会漏掉这一项。

## 支撑分离

若 \(z=n/b\ne z'=n'/b'\) 属于 (2)，既约性使
\(|nb'-n'b|\ge1\)，而
\(\max(nb',n'b)\le p^2/4\)。因此
\[
|\log(z/z')|
\ge\log(1+4p^{-2})
>L.
\tag{4}
\]
相同既约分数只来自同一 \((n,b)\)。异臂中心距离至少
\(2\log(p/8)\gg L\)，所以新族支撑两两不交。

再令 \(x=a/d>1\) 为任意 Farey 分数，\(a<p\)。
若 \(|\log(x/z)|\ge1\)，同臂中心相隔已远大于 \(L\)；
否则 \(x>z/e\ge p/(8e)\)，故 \(d<8e\)，特别 \(d\le21\)。
由于 \(n>p>a\)，既约的 \(n/b\) 不可能等于 \(a/d\)。
整数行列式 \(|nd-ab|\ge1\)，并有
\(\max(nd,ab)\ll p^{3/2}\)，于是
\[
|\log(z/x)|\gg p^{-3/2}\gg L.
\tag{5}
\]
下臂与下臂的距离相同；新族上臂与 Farey 下臂的距离
为 \(\log(zx)\ge\log z\gg H\)，反向亦然。
这证明新族与全 Farey 槽支撑不交。

## polar 投影与互素加权计数

由 (1) 的奇反射，直接积分给
\[
\langle s_{p^2},\psi_z\rangle
=\sqrt{2L}\,\sinh\!\left(\frac{\log z}{2}\right)
\frac{\sinh(L/4)}{L/4},
\qquad
|\langle s_{p^2},\psi_z\rangle|^2
=\frac L2 z\,(1+O(p^{-1}+L^2))
\quad(z\in\mathcal G_p).
\tag{6}
\]
所需互素加权和为
\[
\sum_{z=n/b\in\mathcal G_p}\frac nb
\sim\frac1{\zeta(2)}
\left(\int_{p^{3/2}/8}^{p^{3/2}/4}t\,dt\right)
\left(\int_{\sqrt p/2}^{\sqrt p}\frac{dt}{t}\right)
=\frac{3\log2}{128\zeta(2)}p^3.
\tag{7}
\]
为核对 (7) 的互素限制，用
\(\mathbf1_{(n,b)=1}=\sum_{d\mid n,b}\mu(d)\)。
固定 \(d\)，置 \(n=dk,b=dm\)，则 \(n/b=k/m\)；
\(k\)-和的主项为
\(\frac{3p^3}{128d^2}\)，\(m\)-和的主项为
\(\log2\)。因 \(\sum_{d\ge1}\mu(d)/d^2=1/\zeta(2)\)，
且平方根长度的 \(b\)-区间与 \(p^{3/2}\) 长度的
\(n\)-区间使取整总误差为 \(o(p^3)\)，得到 (7)。
最后将 (6)--(7) 与 \(L=p^{-2}+O(p^{-4})\) 合并，
得到 (3)。\(\square\)

## 素数幂与 polar 的精确主项抵消

这个矩形还把槽外的下一道算术门显露为一个移动短窗。
令 \(\mathcal R_{p^2}=-\sum_{m\ge2}\Lambda(m)m^{-1/2}
(T_m+T_m^*)\) 为旧奇算子的素数幂部分，并置
\(\tau_L(t)=(1-|t|/L)_+\)。在 \(U_p^{\rm ext}\) 的
正交基 (2) 上，**同臂素数幂矩阵恒为零**，异臂部分精确为
\[
\boxed{\quad
\langle\psi_x,\mathcal R_{p^2}\psi_y\rangle
=\sum_{m\ge2}\frac{\Lambda(m)}{\sqrt m}
\tau_L\!\left(\log\frac{m}{xy}\right)
\qquad(x,y\in\mathcal G_p).
\quad}\tag{8}
\]
式 (8) 中实际只有 \(m\asymp p^2\) 且
\(|m-xy|<1/4\) 的素数幂可能贡献：因为
\(xy\le p^2/4\)、\(e^L-1=p^{-2}\)。
所以每个矩阵条目至多采样一个整数。

先核对同臂为零。若一个整数素数幂 \(m\ge2\) 的平移使
两个同臂槽相交，则因 \(x/y\in[1/4,4]\)，充分大 \(p\)
时 \(m\le4\)，且对应的整数中心交叉积
\(A=m n' b\)、\(B=n b'\) 满足 \(\max(A,B)\le p^2\)。
相交要求 \(|\log(A/B)|<L=\log(1+p^{-2})\)，
因此整数 \(|A-B|<1\)，只能 \(x=my\)。
但若 \(y=n'/b'\) 已约分，令 \(d=(m,b')\)，
则 \(my=(mn'/d)/(b'/d)\)。当 \(m/d\ge2\) 时新分子
大于矩形上界；当 \(m/d=1\) 时新分母小于矩形下界。
两种情况都不在 (2)。异臂的两个完整区间平移恰有
三角重叠 \(\tau_L\)，其负号与 \(\mathcal R_{p^2}\) 的
负号相消；两种反射配对的半权相加为一，得到 (8)。

用连续素数密度 \(dt\) 替代式 (8) 的 \(d\Psi(t)\)，得到
\[
K_L^{\rm cont}(x,y)
:=\int_0^\infty t^{-1/2}
\tau_L\!\left(\log\frac{t}{xy}\right)dt
=L\left(\frac{\sinh(L/4)}{L/4}\right)^2\sqrt{xy}.
\tag{9}
\]
事实上令 \(t=xy e^u\)，则中间积分为
\(\sqrt{xy}\int_{-L}^Le^{u/2}(1-|u|/L)du\)，
而后一积分精确等于
\(16\sinh^2(L/4)/L\)，即 (9) 的系数。
取向量 \(a_x=\sqrt x\)、\(b_x=x^{-1/2}\)，
再记 \(S_L=\sinh(L/4)/(L/4)\)。式 (6) 使
\(h_x:=\langle s_{p^2},\psi_x\rangle
=\sqrt{L/2}\,S_L(a_x-b_x)\)。于是
\[
\boxed{\quad
K_L^{\rm cont}-2hh^*
=LS_L^2(ab^*+ba^*-bb^*),
\qquad
\|K_L^{\rm cont}-2hh^*\|=O(1).
\quad}\tag{10}
\]
这里 \(\|a\|^2\ll p^3\)、\(\|b\|^2\ll p\)、
\(L\asymp p^{-2}\)，直接给最后的统一范数界。
因此负 polar 的 \(\asymp p\) 算子量级被**连续素数密度**
的异臂主项精确抵消到有界秩二余项；真实未付的是
\[
\mathcal E_p^{\rm mov}(x,y)
=\int_0^\infty t^{-1/2}
\tau_L\!\left(\log\frac{t}{xy}\right)
d(\Psi(t)-t),
\quad \Psi(t)=\sum_{m\le t}\Lambda(m).
\tag{11}
\]
式 (8)--(11) 是旧核的素数幂与 polar 部分在这一槽外矩形上的精确分解，
不是 \(\mathcal E_p^{\rm mov}\) 的谱界。
确切地，在 (2) 的正交坐标中有
\[
\boxed{\quad
P_{U_p^{\rm ext}}
(\mathcal R_{p^2}-2|s_{p^2}\rangle\langle s_{p^2}|)
P_{U_p^{\rm ext}}
=\mathcal E_p^{\rm mov}
+LS_L^2(ab^*+ba^*-bb^*),
\quad}\tag{12}
\]
其中第二项的秩至多二、算子范数一致有界。

## 真实主压缩的有限谱门

令 \(G_{p^2}\) 是旧奇算子的 Archimedean 部分，
并把它压到 (2) 的正交基。note 805 式 (8)--(10) 的
常值槽公式在这个相离有理族上原样成立：对角为
\((2H+O(1))I\)，不同同臂槽给负矩阵 \(-N\)，
异臂给矩阵 \(B\)，其中
\(N(x,y)=M_{L/2}(|\log(x/y)|)\ge0\) 于 \(x\ne y\)。
在 (4) 的排序中，第 \(j\) 个左右邻距至少
\(j\delta_p\)，\(\delta_p=\log(1+4p^{-2})\)。
由 note 805 式 (8) 的
\(M_{L/2}(d)\le L/[2(d-L)]+CL\) 及
\(L/\delta_p=1/4+O(p^{-2})\)，最大绝对行和满足
\[
\|N\|\le\sum_{j\le|\mathcal G_p|}
\frac{L}{j\delta_p-L}+O(|\mathcal G_p|L)
\le\frac14\log|\mathcal G_p|+O(1)
\le\frac H2+O(1).
\tag{13}
\]
又 \(xy\asymp p^2\)，故 \(B(x,y)\ll L/p\)、
\(\|B\|=O(p^{-1})\)。于是
\[
\boxed{\quad
\left(\frac32H-O(1)\right)I
\preceq P_{U_p^{\rm ext}}G_{p^2}P_{U_p^{\rm ext}}
\preceq\left(\frac52H+O(1)\right)I.
\quad}\tag{14}
\]
把 (12) 与 (14) 合并，完整真实主压缩
\(A_{U_p^{\rm ext}}=P_{U_p^{\rm ext}}A_{p^2,-}P_{U_p^{\rm ext}}\)
满足精确分解
\[
A_{U_p^{\rm ext}}
=P_{U_p^{\rm ext}}G_{p^2}P_{U_p^{\rm ext}}
+\mathcal E_p^{\rm mov}
+LS_L^2(ab^*+ba^*-bb^*),
\tag{15}
\]
从而
\[
\boxed{\quad
\lambda_{\min}(\mathcal E_p^{\rm mov})
+\frac32H-O(1)
\le\lambda_{\min}(A_{U_p^{\rm ext}})
\le\lambda_{\min}(\mathcal E_p^{\rm mov})
+\frac52H+O(1).
\quad}\tag{16}
\]
例如若能证明 \(\lambda_{\min}(\mathcal E_p^{\rm mov})
\ge-(\frac32-\eta)H\) 对某个固定 \(\eta>0\)，则
此**整个外部矩形**的真实主压缩有增长谱隙。
反向若 \(\lambda_{\min}(\mathcal E_p^{\rm mov})
\le-(\frac52+\eta)H\)，则该主压缩有负方向。
目前两种情形都没有算术证据；有限矩形也不代替完整物理补空间。

## 边界

式 (3) 定位了槽外 polar 质量；式 (10)--(16) 把相同量级的
素数幂主项和剩余移动短窗差精确分开。尚未控制
\(\mathcal E_p^{\rm mov}\) 的谱，
以及这个矩形与 Farey 槽和其余物理补空间的交叉。
故这些恒等式不判定真实 Weil 算子的符号，也不证明或反驳 RH。
