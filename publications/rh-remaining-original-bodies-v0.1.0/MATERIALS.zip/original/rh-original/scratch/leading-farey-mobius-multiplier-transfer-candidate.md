# 固定 Farey 分子首阶 moving 均方的可逆 Möbius 乘子转移

依赖：[统一前缀零自由带草稿](farey-block-uniform-power-saving-forces-zeta-zero-free-strip.md) 式 (7)--(10) 的 Euler 乘子及[精确 Poisson 核](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (7)--(9) 的首阶系数。本文只处理固定分子 \(a\) 的首阶模型，保留**整数** moving-\(N\) 采样。此稿尚待独立复核。

固定整数 \(a\ge1\)、\(0<\kappa\le1\)。对序列 \(c(q)\)、实数 \(x>0,D\ge1\)，置
\[
T_c^{(a)}(x;D)
=\frac1x\sum_{D/2<q\le D}q\,c(q)e(ax/q),
\qquad e(u)=e^{2\pi i u},
\tag{1}
\]
并在 \(Y\ge2,\ 1\le D\le Y^\kappa\) 定义
\[
\mathcal E_c^{(a)}(Y,D)
=\sum_{\substack{N\in\mathbb Z\\Y<N\le2Y}}
|T_c^{(a)}(N;D)|^2.
\tag{2}
\]
允许实数 \(Y\) 仅为使 \(Y/d\) 的缩放无歧义；若只假设整数 \(Y\) 的门，
取 \(\lceil Y\rceil\) 并以 \(|T_c^{(a)}(N;D)|\ll_{a,\delta}Y^{1+\delta}\)
支付至多一个漏掉的端点，就得到同样的实数 \(Y\) 门。
令 \(b_a(q)\) 为前引草稿式 (7)--(9) 的系数：偶 \(a\) 时
\(b_a=3\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1}\)；奇 \(a\) 时
\(b_a=-g_a-4g_a\mathbf1_{2\nmid q}\)，其中
\(g_a(q)=\mu(q)q\varphi(q)^{-1}\mathbf1_{(a,q)=1}\)。

**命题。** 对每个固定 \(a,\kappa\)，以下两项等价：
\[
\forall\varepsilon>0,\quad
\mathcal E_{\mu}^{(a)}(Y,D)
\ll_{a,\kappa,\varepsilon}Y^{2+\varepsilon}
\quad\text{一致于 }Y\ge2,\ 1\le D\le Y^\kappa;
\tag{3}
\]
\[
\forall\varepsilon>0,\quad
\mathcal E_{b_a}^{(a)}(Y,D)
\ll_{a,\kappa,\varepsilon}Y^{2+\varepsilon}
\quad\text{在同一区域一致}.
\tag{4}
\]
同一结论对把式 (1) 的 \(e(ax/q)\) 换成
\(\cos(2\pi ax/q)\) 的实模型成立。因此在所有 \(D\le Y^\kappa\)
的固定分子首阶 band 上，\(q/\varphi(q)\) 与精确奇偶系数既不增加也不消除
\(Y^{2+\varepsilon}\) 算术门。式 (3)--(4) 都尚未证明；本命题仅证明它们之间的转移。

**证明。** 先给一个采样引理。设 \(c=\mu\) 或 \(c=b_a\)。对任意
\(\delta>0\)，有 \(|c(q)|\ll_{a,\delta}q^\delta\)。若
\(X\ge2,\ 1\le E\le X\) 且 \(x\in[X-1,2X+1]\)，式 (1) 直接微分给
\[
\left|\frac{\partial}{\partial x}T_c^{(a)}(x;E)\right|
\le
\frac1{x^2}\sum_{q\asymp E}q|c(q)|
+\frac{2\pi a}{x}\sum_{q\asymp E}|c(q)|
\ll_{a,\delta}X^\delta .
\tag{5}
\]
这里 \(X-1\ge X/2\)；若 \(1\le X<2\)，直接用式 (1) 的有限项平凡界。

令 \(d\ge1,\ X=Y/d\ge1,\ E=D/d\le X^\kappa\)。把整数 \(N\in(Y,2Y]\)
按 \(N\bmod d\) 分组，并写 \(N/d=m+\theta\)，\(m\in\mathbb Z\)、
\(0\le\theta<1\)。由 (5)，
\[
T_c^{(a)}(N/d;E)=T_c^{(a)}(m;E)+O_{a,\delta}(X^\delta).
\tag{6}
\]
对所有这些 \(m\)，除了至多一个位于 \([X-1,X]\) 的整数以外，
\(X<m\le2X\)。若已知 \(c\) 满足 (3) 或 (4) 中对应的均方门（取指数
\(\varepsilon/2\)），这个边界整数由式 (1) 的
\(|T_c^{(a)}(m;E)|\ll_{a,\delta}X^{1+\delta}\) 支付。每个 \(m\)
至多出现 \(d\) 次。取 \(0<\delta<\varepsilon/4\)，得到
\[
\sum_{Y<N\le2Y}|T_c^{(a)}(N/d;D/d)|^2
\ll_{a,\kappa,\varepsilon}
dX^{2+\varepsilon/2}+Y X^{2\delta}.
\tag{7}
\]
当 \(X<2\) 时，平凡界同样给 (7)。

由前引草稿式 (10)，存在 \(h_a,k_a\) 满足
\[
b_a=\mu*h_a,\qquad \mu=b_a*k_a,\qquad
\sum_{d\ge1}\frac{|h_a(d)|+|k_a(d)|}{d^\sigma}<\infty
\quad(\sigma>1/2).
\tag{8}
\]
设 \(c=\mu,\ c'=b_a,\ v=h_a\)，或 \(c=b_a,\ c'=\mu,\ v=k_a\)。
因 \(q=dm\) 和 \(D/d\le(Y/d)^\kappa\)，式 (1) 有**逐 \(N\) 精确恒等式**
\[
T_{c'}^{(a)}(N;D)
=\sum_{d\le D}v(d)\,T_c^{(a)}(N/d;D/d).
\tag{9}
\]
对 (9) 用 Minkowski 和 (7)，令
\(\sigma=1/2+\varepsilon/8\)，可得
\[
\begin{aligned}
\mathcal E_{c'}^{(a)}(Y,D)^{1/2}
&\ll
Y^{1+\varepsilon/4}
\sum_{d\le D}|v(d)|d^{-1/2-\varepsilon/4}
+\sqrt Y\,Y^\delta
\sum_{d\le D}|v(d)|d^{-\delta}\\
&\ll_{a,\kappa,\varepsilon}
Y^{1+\varepsilon/4}
+Y^{1/2+\delta}D^{\sigma-\delta}
\ll Y^{1+\varepsilon/4}.
\end{aligned}
\tag{10}
\]
末步用 \(D\le Y^\kappa\le Y\)、\(\delta<\varepsilon/8\) 和 (8)。
平方后得到 \(O(Y^{2+\varepsilon/2})\)，从而得到所要求的
\(O(Y^{2+\varepsilon})\)。两个方向完全相同。余弦模型的卷积恒等式及
式 (5) 导数界也完全相同，证毕。 \(\square\)

**适用边界。** 真实 \(F_{a,q,N}\) 的同频系数还依赖 \(N\)；
note 800 在 \(N/q\) 为固定幂时将它写为
\(qb_a(q)/a^2\) 加上次幂误差，但对固定 \(\kappa>4/5\)，把该误差直接放进大筛
仍可能超过 \(Y^{2+\varepsilon}\)。因此单靠首阶乘子等价不能转移真实同频系数；
下节将用原始 \(k\)-和另证条件性转移。它也没有估计 \(\sum_a\) 的跨分子 Gram，
或证明式 (3)、式 (4)、RH。

## 纯 Möbius band 门对完整同频 Poisson 核的条件性转移

上述误差无需先作点态主项近似。固定 \(a\) 与 \(0<\kappa<1\)，在
\(1\le D\le Y^\kappa\) 中定义 note 801 式 (7) 的**完整、未裁剪**
固定分子 band：
\[
\mathcal F_{a,D}(N)=
-\frac1{\pi N}\sum_{\substack{D/2<q\le D\\a<q,\ (a,q)=1}}
\frac{\mu(q)q}{a^2}\cos\frac{2\pi aN}{q}
\sum_{\substack{kq<N\\(k,q)=1}}
\frac{\mu(k)}k\log\frac{N}{kq}
\left[
\frac{4\mathbf1_{2\mid ka}}{1-4q^2/(a^2N^2)}
-\frac1{1-q^2/(a^2N^2)}
\right].
\tag{11}
\]
第二个求和属于前面 \(q\)-求和的被乘系数。括号内的两个分母在
\(D\le Y^\kappa\) 上最终一致远离零。

**条件性命题。** 若纯 Möbius 的**实余弦版本**满足式 (3)
（复指数版本也足够），则对每个
\(\varepsilon>0\)，
\[
\sum_{Y<N\le2Y}|\mathcal F_{a,D}(N)|^2
\ll_{a,\kappa,\varepsilon}Y^{2+\varepsilon}
\quad\text{一致于 }1\le D\le Y^\kappa.
\tag{12}
\]
这只把一个固定 \(a\) 的完整 moving 同频 band 化为纯 \(\mu\) 门；
它不估计不同 band 或不同分子的合并 Gram。

**证明。** 若 \(D\le2a\)，式 (11) 只有固定个 \(q\)，逐项的
\(\sum_{kq<N}k^{-1}\log(N/kq)\ll\log^2(2Y)\) 给
\(\mathcal F_{a,D}(N)\ll_a\log^2(2Y)/Y\)，故 (12) 平凡成立。
以下取 \(D>2a\)，于是带内 \(a<q\) 自动成立。
对整数 \(m\ge1\)，记
\(c_m(q)=\mu(q)\mathbf1_{(m,q)=1}\)。其 Dirichlet 乘子为
\[
\sum_{q\ge1}\frac{c_m(q)}{q^s}
=\frac1{\zeta(s)}
\prod_{p\mid m}(1-p^{-s})^{-1},
\qquad
L_\sigma(m):=\prod_{p\mid m}(1-p^{-\sigma})^{-1}.
\tag{13}
\]
以下将 \(T_c^{(a)}\) 取为式 (1) 的余弦版本；其卷积恒等式与导数界
与复指数版相同。将上面 (5)--(10) 的单向证明用于
\(c_m=\mu*h_m\)，其中
\(\sum_d|h_m(d)|d^{-\sigma}=L_\sigma(m)\)。输入式 (3) 取指数
\(2+2\tau\)，\(\sigma=1/2+\tau\)，导数误差取
\(\delta=\tau/2\)。不丢掉 \(m\) 的依赖即得
\[
\left\|T_{c_m}^{(a)}(\cdot;E)\right\|_{\ell^2(Y<N\le2Y)}
\ll_{a,\kappa,\tau}Y^{1+\tau}L_\sigma(m)
\quad(E\le Y^\kappa).
\tag{14}
\]
确实，主项是
\(Y^{1+\tau}\sum_d|h_m(d)|d^{-1/2-\tau}\)；
采样误差至多
\(\sqrt Y\,Y^\delta\sum_{d\le E}|h_m(d)|d^{-\delta}
\le Y^{1+\tau}L_\sigma(m)\)。
对 \(m\le4aY\)，由 \(p_j\ge j+1\) 与
\(\omega(m)\ll\log m\)，
\[
L_\sigma(m)
\le\exp\!\bigl(O_\sigma((\log(2m))^{1-\sigma})\bigr)
=Y^{o(1)}
\tag{15}
\]
一致成立。

对固定 \(Q\le D\)，把 \(1\le q\le Q\) 分成至多
\(O(\log(2Y))\) 个形如 \(E/2<q\le E\) 的 dyadic band。
每个 \(E\le D\le Y^\kappa\)，故 (14) 与 Minkowski 给
\[
\left\|
\frac1N\sum_{q\le Q}q\,c_m(q)\cos(2\pi aN/q)
\right\|_2
\ll Y^{1+\tau}L_\sigma(m)\log(2Y).
\tag{16}
\]
对任意整数 \(j\ge0\)，对固定截止 \(Q\) 作 Abel 分部求和，把
\(q^{2j}\) 插入 (16)。因 \(q^{2j}\) 在 \([1,D]\) 的上确界及总变差
均至多 \(D^{2j}\)，得到
\[
\sup_{Q\le D}
\left\|\frac1N\sum_{q\le Q}q^{2j+1}c_m(q)\cos(2\pi aN/q)\right\|_2
\ll D^{2j}Y^{1+\tau}L_\sigma(m)\log(2Y).
\tag{17}
\]
限制到 \(D/2<q\le Q\) 只是两个前缀之差，仍满足 (17)。

在 (11) 中按 \(k\) 交换有限求和。两个互素条件合为
\((ak,q)=1\)，因而内层 \(q\)-系数是 \(c_{ak}(q)\)。
又对 \(kq<N\) 有精确恒等式
\[
\log(N/kq)=\int_{kq}^{N}\frac{dt}{t},
\tag{18}
\]
而
\[
\frac{4\mathbf1_{2\mid ka}}{1-4v^2}
-\frac1{1-v^2}
=\sum_{j\ge0}(4^{j+1}\mathbf1_{2\mid ka}-1)v^{2j},
\qquad v=\frac{q}{aN}.
\tag{19}
\]
固定 \(k,j,t\) 后，(18) 的 \(q\)-条件就是固定截止
\(D/2<q\le\min(D,t/k)\)；\(N>t\) 只删去一部分 \(N\)，
所以 (17) 仍可用于其 \(\ell^2_N\) 范数。
相关 \(k\) 至多 \(4Y/D\)，而 \(t\) 的积分长度满足
\(\int_{kD/2}^{2Y}dt/t\ll\log(2Y)\)。
从 \(N^{-2j}\le Y^{-2j}\)、(15)、(17)--(19) 与
\(\sum_{k\le4Y/D}k^{-1}\ll\log(2Y)\)，得到
\[
\|\mathcal F_{a,D}\|_2
\ll_{a,\kappa,\tau}
Y^{1+\tau+o(1)}\log^3(2Y)
\sum_{j\ge0}
\left(\frac{4D^2}{a^2Y^2}\right)^j.
\tag{20}
\]
因 \(\kappa<1\)，最后的几何和一致有界。给定目标
\(\varepsilon>0\)，先取 \(0<\tau<\varepsilon/8\)，再把
\(Y^{o(1)}\log^3Y\) 吸收到 \(Y^{\varepsilon/8}\)；
平方即得 (12)。\(\square\)

**剩余真实门。** 式 (12) 假设了尚未证明的纯 \(\mu\)
all-band 均方 (3)。其价值在于完整同频系数的移动截止、互素条件、
对数权和有理乘子都无需另设独立猜想；若攻克 (3)，这些部分可按上证支付。
对固定 \(a,\kappa<1\)，至多 \(O(\log Y)\) 条 band 的合并也可由
Minkowski 支付。增长的分子 \(a\)、靠近完整截止的 \(q>Y^\kappa\)，
以及纯 \(\mu\) 门 (3) 本身仍需额外估计。
