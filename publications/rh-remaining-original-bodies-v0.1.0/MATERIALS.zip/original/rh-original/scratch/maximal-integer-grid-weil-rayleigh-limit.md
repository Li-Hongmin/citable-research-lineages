# 最大整除格自然试函数的完整 Weil 极限（候选）

令 $p\to\infty$ 沿奇素数，$H=\log p$，
$M=(p^2-5)/4$（整数），固定 $0<c<4$、$\ell=c/p^2$，
$y_n=H-\log4-\log n$、$I_n=(y_n-\ell/2,y_n+\ell/2)$。
固定实值 $\varphi\in C_c^\infty((-1/2,1/2))$、$\|\varphi\|_2=1$；
不必要求其非负。记 $\kappa=\int\varphi$ 与
\[
C_\varphi=\int_{\mathbb R}\log|\xi|\,
|\widehat\varphi(\xi)|^2\frac{d\xi}{2\pi},
\quad b_\ell(t)=\ell^{-1/2}\varphi(t/\ell),
\quad L_M=\sum_{n\le M}n^{-1}.
\]
在 $I_n$ 上定义单位实函数
$F(y_n+t)=n^{-1/2}b_\ell(t)/\sqrt{L_M}$，其余为零。

候选精确极限：
\[
\boxed{\quad
\lim_{p\to\infty}Q_W^H[F]
=\log(4/c)+C_\varphi+\gamma-\log(2\pi)
+\frac{c\kappa^2}{4}.
\quad}\tag{A}
\]
因而若存在固定 $0<c<4$ 和光滑轮廓使右侧为负，就得到 RH 的严格反例。
对固定轮廓，右侧对 $c<4$ 严格递减，因为
$\partial_c=-1/c+\kappa^2/4<0$（$\kappa^2\le1$）。
所以该具体自然试函数族有负方向，当且仅当
\[
C_\varphi+\kappa^2<\log(2\pi)-\gamma
\tag{B}
\]
对某个固定实光滑单位轮廓成立；这是待判定的单位区间变分问题。

证明：$p^2-4M=5$，所以
$y_M+H=\log(p^2/(4M))\ge5/p^2$，大于 $\ell/2$；
最小中心距为 $\log(M/(M-1))=(4+o(1))/p^2>\ell$。
若 prime shift 连接 $I_n,I_r$，则
$|r-kn|\le M(e^\ell-1)=c/4+o(1)<1$，故 $r=kn$。

对整除矩阵 $C_M$，自然权 $v_n=n^{-1/2}$ 的逐行恒等式为
$(C_Mv)_n/v_n=M_1(M/n)+\log n$，其中
$M_1(x)=\sum_{k\le x}\Lambda(k)/k=\log x-\gamma+o(1)$。
该渐近式由素数定理与 $-\zeta'/\zeta(s)$ 在 $s=1$ 的 Laurent 常数给出。
调和平均中 $n\le M/A$ 的质量比例趋 $1$（先固定 $A$，再 $M\to\infty$），
$n>M/A$ 的调和质量为 $O(\log A)$；故
\[
\langle v,C_Mv\rangle/\|v\|_2^2
=\log M-\gamma+o(1).
\tag{1}
\]

单槽 Fourier 主部及常数项为
$\log(1/\ell)+C_\varphi-\log(2\pi)$；同槽光滑余项为 $O(\ell)$。
对约化普通核 $k(t)=e^{-t/2}/(1-e^{-2t})$，已有精确恒等式
\[
\frac{k(\log(r/n))}{\sqrt{nr}}
=\frac12\left(\frac1{r-n}+\frac1{r+n}\right)
\quad(r>n).
\]
因此
\[
\sum_{\substack{n,r\le M\\n\ne r}}
\frac{k(|\log(r/n)|)}{\sqrt{nr}}
=M\log M+O(M).
\tag{2}
\]
槽内偏移造成的加权总误差为 $O(\ell^2M^2)=O_c(1)$：
对 $n<r\le2n$ 按 $d=r-n$ 用
$|k'|\ll|\log(r/n)|^{-2}$，单对误差
$O(\ell^2 n/d^2)$，求和为 $O(\ell^2 M^2)$；
对 $r>2n$，$k'$ 有界，加权双和为 $O(\ell^2 M)$。
除以 $L_M$ 后趋零。因此
\[
Q_{\rm ord}[F]
=-\frac{\kappa^2\ell}{L_M}
\bigl(M\log M+O(M)\bigr)+o(1)
=-\frac{c\kappa^2}{4}+o(1).
\tag{3}
\]

令 $m_\pm=\int b_\ell(t)e^{\pm t/2}dt
=\kappa\sqrt\ell+O_\varphi(\ell^{3/2})$。
极点项精确为 $2m_+m_-M$，故
\[
Q_{\rm pol}[F]=\frac{c\kappa^2}{2}+o(1).
\tag{4}
\]
将 (1),(3),(4) 与 Fourier 项合并，
$\log(1/\ell)-\log M\to\log(4/c)$，得到 (A)。

独立复核重点：prime Rayleigh 的常数 $-\gamma$；
全格 $n$ 很小时偏移误差；smooth remainder 的完整计入；
式 (B) 的当且仅当仅针对该试函数族的极限符号。
