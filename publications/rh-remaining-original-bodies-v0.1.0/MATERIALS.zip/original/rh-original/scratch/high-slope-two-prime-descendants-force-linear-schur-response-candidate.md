# 高斜率双素数后代给固定根带来线性真 Schur 响应（候选）

日期：2026-09-30。对象与符号沿用 [note 826](../notes/826-two-prime-moving-near-farey-mesh-has-explicit-schur-and-spectral-shifts.md)，但把第二代近对角条件改为 \(z_{q,r}=xq/r>H/2\)。这正落在 note 824 尚未纳入的 \(A<\operatorname{num}\le S\)、高斜率常值奇槽带。依赖 [note 809](../notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md) 的整个 \(I_Q\) 真压缩正性、[note 807](../notes/807-natural-farey-constant-mode-has-two-thirds-logarithmic-energy.md) 的全 Farey 带符号算术范数。尚待独立复核。

固定既约 \(x=a/b\in(1,2)\)、\(\alpha>1\)、\(0<\theta<1\)。令 \(p\to\infty\) 沿奇素数，\(H=\log p\)、\(A=\lfloor(p-1)^\theta\rfloor\)、\(S=\lfloor(p-1)/H^\alpha\rfloor\)，\(\mathcal P=\{q\text{ 素数}:A/b<q\le S/a\}\)、\(c_q=(\log q)/\sqrt q\)。取根与第一代 \(B=\{x\}\cup\{u_q=qx,v_q=q/x:q\in\mathcal P\}\)，高斜率第二代
\[
Z^{\rm hi}=\{z_{q,r}=xq/r:q,r\in\mathcal P,\ q\ne r,\ xq/r>H/2\},
\qquad V^{\rm hi}=B\cup Z^{\rm hi}.
\]
所有槽的分子至多 \(S<Q=\lfloor(p-1)/H\rfloor\)，故属于 note 809 的整个小分子内区 \(I_Q\)。令 \(R_B\) 和 \(R_{V^{\rm hi}}\) 分别为消去第一代和第一、二代后固定根的**真实** Schur 扣款。note 809 的正性使两者对充分大 \(p\) 均有定义。候选定理是
\[
\boxed{\quad\liminf_{p\to\infty}
\frac{R_{V^{\rm hi}}-R_B}{H}
\ge\frac{(1-\theta^2)^2}{32}>0.\quad}
\tag{1}
\]
因此把近对角第二代扩展到真正遗漏的高斜率第二代时，新增 Schur 响应从 note 826 的常数级变为至少线性级。

## 精确两亲子边与双素数质量

大素数 \(q,r>a,b\) 使 \(aq/(br)\) 已约分；不同有序对不碰撞，也不与第一代或根碰撞。note 826 的素数赋值论证与 \(z\) 的大小无关，故根到 \(Z^{\rm hi}\) 没有算术边，而 \(u_q\leftrightarrow z_{q,r}\) 有 \(+c_r\) 比值边，\(v_r\leftrightarrow z_{q,r}\) 有 \(-c_q\) 乘积边，无其他第一、二代算术边。记这块为 \(T\)，根到孩子的行向量为 \(w=(c_q,-c_q)_q\)。每个二代坐标于是满足
\[
(T^*w)_{q,r}=2c_qc_r,
\qquad \|T^*w\|^2=4\Sigma_{\rm hi},
\quad \Sigma_{\rm hi}:=
\sum_{\substack{q,r\in\mathcal P\\xq/r>H/2}}c_q^2c_r^2.
\tag{2}
\]
素数定理与分部求和给加权对数坐标的弱极限
\[
\frac1{H^2}\sum_{q\in\mathcal P}c_q^2
f\!\left(\frac{\log q}{H}\right)
\longrightarrow\int_\theta^1 t f(t)\,dt
\]
对每个连续 \(f\) 成立。因为 \(\log(H/(2x))/H\to0\)，双素数约束在极限中恰为 \(s<t\)，其边界的乘积极限测度为零。因此
\[
\frac{\Sigma_{\rm hi}}{H^4}
\longrightarrow
\int_\theta^1t\int_\theta^t s\,ds\,dt
=\frac{(1-\theta^2)^2}{8}.
\tag{3}
\]

## 真 Schur 扣款的下界

把 \(A_{V^{\rm hi}}\) 按根、孩子、二代写为
\[
\begin{pmatrix}a_0&g^*&h^*\\g&D&J\\h&J^*&F\end{pmatrix}.
\]
note 809 的整个 \(I_Q\) 非算术同臂核与 polar 范数为 \(O(H^{-1})\)。二代全是 \(z>H/2\)，所以 note 805 的异臂正矩阵迹至多 \(O(\Delta|V^{\rm hi}|)=O(H^{-2\alpha})=o(1)\)，\(\Delta\asymp p^{-2}\)。加上孩子间 \(u_q\!\leftrightarrow v_q\) 的 \(o(1)\) 范数，可得
\[
g=-w+o(1),\quad h=o(1),\quad
D=2H I+O(1),\quad J=-T+o(1),
\quad \|T\|=O(H).
\tag{4}
\]
最后的范数由每个正臂列的平方和 \(\sum_r c_r^2=O(H^2)\)、不同 \(q\) 列支持不交，以及负臂的同样估计得到。

对 \(F\) 只需**上**算子界。note 807 的带符号算术图被非负全图逐项支配，后者以权 \(v_{a/b}=(ab)^{-1/2}\) 作 Schur 检验有 \(\|C^-_{I_QI_Q}\|\le2H+O(1)\)。非算术项在 \(V^{\rm hi}\) 上为 \(o(1)\)，故
\[
F\preceq(4H+O(1))I.
\tag{5}
\]
因为 \(A_{I_Q}\succeq(2\log H-O(1))I\)（note 809），孩子加二代块正定；因此 \(D>0\) 且 \(F-J^*D^{-1}J>0\)。Schur 增量恒等式与 (5) 给
\[
\begin{aligned}
R_{V^{\rm hi}}-R_B
&=(h-J^*D^{-1}g)^*(F-J^*D^{-1}J)^{-1}(h-J^*D^{-1}g)\\
&\ge\frac{\|h-J^*D^{-1}g\|^2}{4H+O(1)}.
\end{aligned}\tag{6}
\]
由 (4)、\(\|w\|=O(H)\)、\(\|T\|=O(H)\) 有
\[
h-J^*D^{-1}g
=-\frac{T^*w}{2H}+O(1),
\qquad
\|h-J^*D^{-1}g\|^2
=\frac{\Sigma_{\rm hi}}{H^2}+o(H^2).
\tag{7}
\]
将 (3)、(7) 代入 (6)，证明 (1)。\(\square\)

## 边界

(1) 是整个真实 \(V^{\rm hi}\) 主压缩中的**下**响应界，依赖 note 809 保证可逆，却没有上界或完整遗漏带的谱底。即使把二代都纳入，其他根、更多后代、非恒定轮廓、无限维补空间及 moving-\(N\) Möbius signed covariance 仍未支付；此结论不证明或反驳 RH。
