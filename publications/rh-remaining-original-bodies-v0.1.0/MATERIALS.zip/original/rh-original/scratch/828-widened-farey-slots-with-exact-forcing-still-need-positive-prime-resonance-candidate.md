# 保持精确 forcing 的加宽 Farey 槽仍需正素数近共振（候选）

日期：2026-09-29。依赖 [scratch 817](817-polynomial-denominator-exterior-slots-have-logarithmic-farey-leakage-candidate.md) 的源--目标有理间距、[scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的 forcing 范数、[scratch 824](824-opposite-prime-power-quadratic-cost-vanishes-through-quarter-candidate.md) 的乘积计数、[scratch 825](825-exterior-farey-forcing-needs-order-log-positive-prime-resonance-for-a-negative-two-plane-candidate.md) 的二维 Gram 预算，以及 [scratch 827](827-narrow-farey-dipoles-remove-opposite-resonances-but-raise-the-diagonal-candidate.md) 的任意槽宽自对角。只分析 \((\alpha,\beta)=(2/3,1/4)\) 的同宽偶极二维平面；尚缺异源复核，留在 scratch。

## 命题

令 \(p\to\infty\) 沿奇素数、\(H=\log p\)，固定
\[
\frac{23}{12}<\kappa\le2,
\qquad \eta_p=p^{-\kappa},
\quad Q=\lfloor p^{2/3}\rfloor,
\quad B=\lfloor p^{1/4}\rfloor.
\tag{1}
\]
把 817--819 的所有归一化双半槽偶极改为共同半槽宽度 \(\eta_p\)，保留同一内部系数 \(1/\sqrt{ab}\) 和外槽族 \(\mathcal Y_{p,B}\)。记所得内部向量为 \(v_\kappa\)，以 819 的**同一素数 forcing 系数** \(t^{\rm pr}_{m/b}\) 组成外向量 \(w_\kappa\)。令 \(N^{\rm opp,pr}_{\kappa}\) 为新槽宽重叠核 \(R_{\eta_p}\) 下的异臂素数平移矩阵。则
\[
\|t^{\rm pr}\|^2
=\left(\frac{307}{18432\zeta(2)}+o(1)\right)H^4,
\qquad
\langle v_\kappa,A_{p^2,-}w_\kappa\rangle
=-\|t^{\rm pr}\|^2+o(H^4),
\tag{2}
\]
而新槽宽下高次素数幂异臂平移在该 forcing 上仍满足
\[
\boxed{\quad
|\langle t^{\rm pr},N^{\rm opp,pp}_{\kappa}t^{\rm pr}\rangle|
\ll_{\kappa,\varepsilon}
H^4B^3p^{1-\kappa+\varepsilon}=o(1)
\quad}
\tag{3}
\]
（取 \(\varepsilon<\kappa-7/4\)）。

若真实旧奇形式在 \(\operatorname{span}\{v_\kappa,w_\kappa\}\) 上对无穷多个 \(p\) 有负方向，则这些 \(p\) 必满足
\[
\boxed{\quad
\frac{\langle t^{\rm pr},N^{\rm opp,pr}_{\kappa}t^{\rm pr}\rangle}
{H\|t^{\rm pr}\|^2}
\ge \kappa-\frac{17}{12}
-\frac{2(307/18432)}{(4/9)(\kappa-4/3)}-o(1)
>\frac{2663}{7168}-o(1).
\quad}
\tag{4}
\]
当 \(\kappa=2\) 时，(4) 的阈值是 825 的 \(11573/24576\)；当 \(\kappa\downarrow23/12\) 时，右侧严格趋向 \(2663/7168>0\)。因此在**整数间距已足以保持精确源--目标 forcing**的整个加宽范围内，这个二维方向仍离不开正的 \(H^5\) 级素数近共振。

## 精确交叉边与自对角

源 \(x=a/b\in\mathcal F_Q\) 经素数幂平移后的既约分母至多 \(Q\)，目标 \(y=m/b'\in\mathcal Y_{p,B}\) 的分母至多 \(B\)。817 式 (5) 的整数间距给任何非精确中心匹配
\[
|\log(r/y)|\gg\frac1{pBQ}
=p^{-23/12+o(1)}.
\tag{5}
\]
由 \(\kappa>23/12\)，这大于 \(2\eta_p\) 对充分大的 \(p\) 成立。故算术源--目标边仍只有完整重合，819 式 (1)--(3) 的逐槽 forcing 与高次源误差原样成立，证明 (2) 的交叉式及范数式。目标之间的对数间距 \(\gg1/(pB^2)=p^{-3/2+o(1)}\)，内部源之间的对数间距 \(\gg Q^{-2}=p^{-4/3+o(1)}\)；两者均远大于 \(\eta_p\)。同臂算术边仍只能精确重合，其矩阵仍是 818 的 \(C^{\rm same}\)。

note 780 式 (4) 与相邻反号半槽的接触常数给每个偶极自对角 \(\kappa H+O(1)\)。相离 Archimedean 核的双零矩界和上述间距给内部、外部非对角的 \(o(1)\) 算子误差；源--目标中心相距 \(\gg H\)，其非算术投影仍为 \(o(1)\)。因此 808 的算术 Rayleigh 主项未变，而对角由原来的 \(2H+O(1)\) 改为 \(\kappa H+O(1)\)：
\[
\langle v_\kappa,A_{p^2,-}v_\kappa\rangle
=\left(\frac{(4/9)(\kappa/2-2/3)}{\zeta(2)}+o(1)\right)H^3
=\left(\frac{(2/9)(\kappa-4/3)}{\zeta(2)}+o(1)\right)H^3>0.
\tag{6}
\]
825 式 (6) 的 forcing 支撑同臂界为 \((17/12)H+O(1)\)，故
\[
\langle w_\kappa,A_{p^2,-}w_\kappa\rangle
\ge\left(\kappa-\frac{17}{12}+o(1)\right)
H\|t^{\rm pr}\|^2
-\langle t^{\rm pr},N^{\rm opp,pr}_{\kappa}t^{\rm pr}\rangle,
\tag{7}
\]
其中高次平移由下段支付。

## 高次平移与 Gram 阈值

若素数幂 \(n=\ell^j\)、\(j\ge2\) 参与异臂重叠，置整数
\(d=nbb'-mm'\)。新槽宽给 \(|d|\ll\eta_pmm'\ll bb'p^{2-\kappa}\)，且
\(n\gg p^2/B^2\)、\(n\ll p^2\)。固定 \(n,b,b',d\) 后，\(mm'=nbb'-d\) 的有序因子配对仍至多 \(p^\varepsilon\) 个；单项 forcing 权重由 824 式 (6)--(7) 仍至多 \(O(H^3/(nbb'))\)。固定 \(n,b,b'\) 的整数 \(d\) 至多 \(O(bb'p^{2-\kappa})\) 个。因此 824 式 (8)--(9) 的同一求和多出因子 \(p^{2-\kappa}\)，得
\[
|\langle t^{\rm pr},N^{\rm opp,pp}_{\kappa}t^{\rm pr}\rangle|
\ll H^3B^2p^{2-\kappa+\varepsilon}
\sum_{\substack{n\gg p^2/B^2\\n\ll p^2,\ n=\ell^j,\ j\ge2}}\frac1n
\ll H^4B^3p^{1-\kappa+\varepsilon},
\]
即 (3)。当 \(B=p^{1/4+o(1)}\)、\(\kappa>23/12\) 时，\(B^3p^{1-\kappa}=p^{7/4-\kappa+o(1)}=o(1)\)。

若二维平面有负方向，源对角 (6) 严格正，故目标对角小于交叉平方除以源对角。由 (2)、(6) 得该商为
\[
\left(\frac{2J}{\alpha^2(\kappa-2\alpha)}+o(1)\right)
H\|t^{\rm pr}\|^2,
\qquad J=307/18432,\quad\alpha=2/3.
\]
与 (7) 合并得 (4) 的第一不等式。函数
\(f(\kappa)=\kappa-17/12-2J/[(4/9)(\kappa-4/3)]\)
在 \(\kappa>23/12\) 上严格递增；在左端的极限为
\[
\frac12-\frac{921}{7168}=\frac{2663}{7168}>0.
\]
这证明 (4)。\(\square\)

## 边界

\(\kappa>23/12\) 是本证明用整数间距保证精确 forcing 的**充分范围**，不是所有可能槽形的必要边界。此范围内的异臂素数窗口长度至多 \(O(p^{2-\kappa})=O(p^{1/12-\epsilon_\kappa})\)，而 (4) 没有估计窗口内素数的有符号分布。此处只给负方向的必要门槛，不能由正门槛推出二维平面、完整旧奇算子或 RH 的正性。
