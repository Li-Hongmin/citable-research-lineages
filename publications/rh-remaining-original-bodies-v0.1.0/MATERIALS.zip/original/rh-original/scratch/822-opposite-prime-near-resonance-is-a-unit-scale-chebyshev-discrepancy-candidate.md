# 异臂素数近共振的连续主项是消失的秩一矩阵（候选）

日期：2026-09-29。承接 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的异臂阶跃重叠核与 [scratch 821](821-exterior-opposite-prime-power-compression-vanishes-below-quarter-candidate.md) 的高次素数幂支付。以下是**精确比较恒等式**：它删除连续素数密度的贡献，未估计剩余的有符号素数误差。尚缺异源独立复核，留在 scratch。

## 命题

令 \(p\to\infty\) 沿奇素数，\(\Delta=\frac12\log(1+p^{-2})\)，\(B=\lfloor p^\beta\rfloor\)，固定 \(0<\beta<1/2\)，并取 scratch 818 的外槽族 \(\mathcal Y_{p,B}\)。只保留平移指标 \(n=q\) 为素数的异臂矩阵 \(N^{\rm opp,pr}_{p,B}\)。令
\[
\theta(x)=\sum_{q\le x,\ q\ {\rm prime}}\log q,\qquad
f_z(x)=x^{-1/2}R_\Delta\!\left(\left|\log\frac{x}{z}\right|\right),
\qquad z=yy'.
\]
则每个矩阵元有精确分解
\[
\boxed{\ N^{\rm opp,pr}_{p,B}(y,y')
=\kappa_\Delta\sqrt y\,\sqrt{y'}
+\int_0^\infty f_{yy'}(x)\,d(\theta(x)-x),\ }
\tag{1}
\]
其中
\[
\boxed{\ \kappa_\Delta
=-\frac{32}{\Delta}\sinh^4\!\frac{\Delta}{4}
=-\frac{\Delta^3}{8}+O(\Delta^5)<0.\ }
\tag{2}
\]
连续主项的矩阵 \(S_{p,B}(y,y')=\kappa_\Delta\sqrt y\sqrt{y'}\) 为负秩一，并满足
\[
\boxed{\ \|S_{p,B}\|_{\rm op}
=|\kappa_\Delta|\sum_{y\in\mathcal Y_{p,B}}y
\ll\frac{B^2}{p^4}=o(1).\ }
\tag{3}
\]
因此在 \(\beta<1/4\) 时，结合 scratch 821，
\[
N^{\rm opp}_{p,B}
=\left(\int f_{yy'}\,d(\theta-\mathrm{id})\right)_{y,y'}
+o_{\rm op}(1).
\tag{4}
\]
式 (4) 的剩余矩阵由长度小于 \(2+o(1)\) 的素数窗口决定；本式不给它的算子范数或实际 forcing 二次型的符号。

## 证明

令归一化阶跃偶极
\[
h_\Delta(u)=\frac{1_{(-\Delta,0)}(u)-1_{(0,\Delta)}(u)}
{\sqrt{2\Delta}}.
\]
scratch 818 式 (5) 正是它的自相关
\[
R_\Delta(|s|)
=\int_{\mathbb R}h_\Delta(u)h_\Delta(u+s)\,du.
\tag{5}
\]
由 \(\theta\) 的 Stieltjes 原子定义，素数矩阵元就是 \(\int f_z\,d\theta\)。将 \(d\theta=dx+d(\theta-x)\) 拆开，剩下计算 \(\int f_z(x)\,dx\)。

置 \(x=ze^s\)，则
\[
\int_0^\infty f_z(x)\,dx
=\sqrt z\int_{\mathbb R}e^{s/2}R_\Delta(|s|)\,ds.
\tag{6}
\]
对任意实数 \(\lambda\)，自相关的双重积分给
\[
\int_{\mathbb R}e^{\lambda s}R_\Delta(|s|)\,ds
=A_\Delta(\lambda)A_\Delta(-\lambda),
\quad
A_\Delta(\lambda)=\int_{\mathbb R}h_\Delta(u)e^{\lambda u}\,du
=-\frac{4}{\lambda\sqrt{2\Delta}}
\sinh^2\!\frac{\lambda\Delta}{2}.
\tag{7}
\]
代入 \(\lambda=1/2\) 即得 (2)，再由 (6) 得 (1)。由于 \(|\mathcal Y_{p,B}|=O(pB^2)\) 且 \(y<p\)，有 \(\sum_y y=O(p^2B^2)\)；\(\Delta\asymp p^{-2}\) 遂给 (3)。scratch 821 在 \(\beta<1/4\) 给高次素数幂异臂矩阵 \(o_{\rm op}(1)\)，故 (4) 成立。\(\square\)

## 单位尺度边界

\(f_z\) 支撑于 \((ze^{-2\Delta},ze^{2\Delta})\)，其长度为
\[
z(e^{2\Delta}-e^{-2\Delta})<2+o(1)
\qquad(z=yy'<p^2).
\]
由于 \(f_z\) 连续、在两个端点为零，Stieltjes 分部积分把 (1) 的剩余项精确写为
\[
-\int_{ze^{-2\Delta}}^{ze^{2\Delta}}
\bigl[(\theta(x)-x)-(\theta(z)-z)\bigr]f'_z(x)\,dx.
\tag{8}
\]
因此全局素数定理的 \(\theta(x)\sim x\) 主项已经被 (3) 支付；待证的是移动的单位尺度增量在真实 Farey forcing 权下的**联合有符号抵消**。(8) 本身不构成该抵消估计，更不能推出 Schur 符号、全尺度局部 Weil 正性、moving-\(N\) Möbius 协方差目标或 RH。
