# 真实高除数观察门内的无条件负补偿

日期：2026-10-01。接 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md)、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 与 [scratch/861](861-prime-prime-block-survives-the-true-high-divisor-observation-gate.md)。本稿的外部输入直接核自 K. Matomäki, X. Shao, T. Tao, J. Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, *Forum Math. Pi* **11** (2023), e29, DOI 10.1017/fmp.2023.28，Theorem 3.1(i) 与式 (3.11)；本地原 PDF 为 `[local archival reference]`。它把 [scratch/857](857-log-half-collar-payment-for-the-moving-k2-observation-tail.md) 所用的一位对数素数节省升级为任意固定对数幂。这里的负补偿是**无条件**的，却仍远弱于固定幂的 RH 门。完整推导留在 scratch，尚待异源复核。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 固定，$\mathcal A_h$ 如 scratch/859 式 (1)。对 scratch/860 的任意固定 $s>1$ 带通权 $w_H(h)=\chi_s(h/H)^2$，每个固定 $A>0$ 均有一致估计
\[
 \boxed{\quad
 \sum_hw_H(h)|\mathcal A_h|^2
 \ll_{A,s,\psi}(\log M)^{-A}.
 \quad}\tag{1}
\]
令 $\mathfrak S_{M,H}^{(s)}$ 为 scratch/859 式 (12) 的真实 $\mu(d)\mu(e)$ signed 和，但将其远差截止替换为 scratch/860 的 $K_{s,2}=C_{s,2}(M/H)(\log M)^s$。对任意固定 $0<\vartheta<1/20$，在非空范围
\[
 Y^{1/5}\le H\le Y^{1/4-\vartheta}
 \tag{2}
\]
均有，对每个固定 $A>0$，
\[
 \boxed{\quad
 \mathfrak S_{M,H}^{(s)}=O_{A,s,\psi,\vartheta}((\log M)^{-A}).
 \quad}\tag{3}
\]
若进一步 $\psi\ge0$ 且非零，并令 $\mathfrak P_{M,H}$ 为 scratch/861 式 (1) 的同一剩余门内素数—素数正子块，写 $\mathfrak C_{M,H}=\mathfrak S_{M,H}^{(s)}-\mathfrak P_{M,H}$，则在 (2) 中成立下式；更一般地，只要 $Y^{1/5}\le H\le Y^{1/4}$ 且 $H^4/M\to0$，下式仍成立：
\[
 \boxed{\quad
 \mathfrak C_{M,H}=-\mathfrak P_{M,H}+o((\log M)^{-2}),
 \qquad
 \mathfrak P_{M,H}\gg_{s,\psi}(\log M)^{-2}.
 \quad}\tag{4}
\]
所以 $\mathfrak C_{M,H}<0$ 对充分大 $M$ 成立，并且该真实中距离、高除数、大约化比例余门内发生大小至少为 $c_{s,\psi}/\log^2M$ 的负补偿。

还可在**全部** $Y^{1/5}\le H\le Y^{1/4}$ 上得到同样的无条件负补偿，只需把无符号支付的两个对数参数收紧为
\[
 R_*:=\left\lfloor H^2/(\log(2M))^6\right\rfloor,
 \qquad K_{0,*}:=H^3/(\log(2M))^9.
 \tag{4a}
\]
令 $\mathfrak S^*_{M,H}$ 为 scratch/859 式 (12) 中以 $R_*,K_{0,*},K_{s,2}$ 代替 $R,K_0,K_1$ 的和，令 $\mathfrak P^*_{M,H}$ 为 scratch/861 式 (1) 中以 $K_{0,*}$ 代替 $K_0$ 的素数块。则一致于全带，
\[
 \boxed{\quad
 \mathfrak S^*_{M,H}=O_{s,\psi}((\log M)^{-4}),
 \qquad \mathfrak P^*_{M,H}\gg_{s,\psi}(\log M)^{-2},
 \qquad
 \mathfrak S^*_{M,H}-\mathfrak P^*_{M,H}
 =-\mathfrak P^*_{M,H}+O_{s,\psi}((\log M)^{-4}).
 \quad}\tag{4b}
\]
这里 $\psi\ge0$ 且非零只用于素数块的正性；$\mathfrak S^*$ 的上界适用于任意固定 $\psi$。

另一个直接推论是：任意固定 $C>0$，(1) 达到频带目标 $\sum_hw_H(h)|\mathcal A_h|^2\ll H^4/M$ 于
\[
 Y^{1/4}/(\log Y)^C\le H\le Y^{1/4}.
 \tag{5}
\]
这推进 [scratch/857](857-log-half-collar-payment-for-the-moving-k2-observation-tail.md) 的对数 collar，但不进入任意固定幂低于 $1/4$ 的区域。

按 [note 847](../notes/847-quarter-power-observation-fourier-tail-for-full-k2-residual.md) 的 $S_h(Y),q(h)$，(5) 还给出任意固定 $C>0$ 的完整高观察尾
\[
 \frac1Y\sum_{q(h)\ge\lceil Y^{1/4}/(\log Y)^C\rceil}|S_h(Y)|^2
 \ll_{C,\psi}Y^2\log(2Y).
 \tag{5a}
\]

## 证明：全区间短和输入

上述论文式 (1.1) 的素数近似量为 $\Lambda^\sharp(n)=P(R)\varphi(P(R))^{-1}\mathbf1_{(n,P(R))=1}$，其中 $R=\exp((\log x)^{1/10})$。Theorem 3.1(i) 在任意 $x^{7/12+\epsilon}\le T\le x^{1-\epsilon}$ 的区间 $(x,x+T]$ 给出，对任意固定 $A>0$，
\[
 \sup_{P\subset(x,x+T]}\left|\sum_{n\in P}\mu(n)\right|
 \ll_{A,\epsilon}T(\log x)^{-A},
 \qquad
 \sup_{P\subset(x,x+T]}\left|\sum_{n\in P}(\Lambda(n)-\Lambda^\sharp(n))\right|
 \ll_{A,\epsilon}T(\log x)^{-A},
 \tag{6}
\]
其中 $P$ 遍历整数等差进程，特别包含整个区间及其前缀。该文式 (3.11) 对 $T\ge x^\epsilon$ 给 $\sum_{x<n\le x+T}\Lambda^\sharp(n)=T+O_\epsilon(T e^{-(\log x)^{1/2}})$（取模数 $q=1$）。合并可得
\[
 \sum_{x<n\le x+T}(\Lambda(n)-1)
 \ll_{A,\epsilon}T(\log x)^{-A},
 \qquad
 \sum_{x<n\le x+T}\mu(n)
 \ll_{A,\epsilon}T(\log x)^{-A}.
 \tag{7}
\]
这里只对**长度恰为 $T$ 的整块**使用 (7)，因此不需要为任意短前缀额外解释 $\Lambda^\sharp$ 的主项。

置 $B_0=\lfloor M^{2/3}\rfloor$。当 $x\asymp M$、$T=B_0$ 或 $B_0/2+O(1)$ 时，取固定小 $\epsilon<1/24$，(7) 的全部长度假设均满足。对 $c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)-4(\Lambda(m)-1+(\log2)\mu(m))$，偶格换元把任意长度 $B_0$ 的 $m$ 整块变成长度 $B_0/2+O(1)$ 的整数块；两个端点的 $O(1)$ 取整误差至多 $O(\log M)$。所以每个 $I\subset(M,2M)$、$|I|=B_0$ 满足
\[
 \left|\sum_{m\in I}c(m)\right|
 \ll_A B_0(\log M)^{-A}.
 \tag{8}
\]

取 $L=\lfloor M/(32H)\rfloor$，则 $L\gg M^{3/4}$ 且 $B_0\log^K M=o(L)$ 对每个固定 $K$ 成立。把任意长度不超过 $L$ 的区间分成长度 $B_0$ 的整块和至多两个端块；端块由 $|c(m)|\ll\log M$ 平凡支付。式 (8) 因而给，对每个固定 $A>0$，
\[
 \sup_{\substack{I\subset(M,2M)\\|I|\le L}}
 \left|\sum_{m\in I}c(m)\right|
 \ll_A L(\log M)^{-A}.
 \tag{9}
\]
令 $a_m=M^{-1}c(m)\phi(m/M)$，则 $\mathcal A_h=\sum_ma_me(-hm/M)$，且 $\phi$ 的相邻差为 $O_\psi(M^{-1})$。对 (9) 作离散 Abel 求和，得到
\[
 \sup_{|I|\le L}\left|\sum_{m\in I}a_m\right|
 \ll_{A,\psi}\frac LM(\log M)^{-A}.
 \tag{10}
\]
由于 $\phi$ 紧支撑于 $(1,2)$、$L=o(M)$，(10) 同样适用于周期群 $\mathbb Z/M\mathbb Z$ 的每个长度 $L$ 窗。记 $V_h=\sum_{j=0}^{L-1}e(-hj/M)$。当 $w_H(h)\ne0$ 时 $|h|\le4H$、$|h|L/M\le1/8$，故 $|V_h|\gg L$。周期 Parseval 给
\[
 \sum_hw_H(h)|\mathcal A_h|^2
 \ll_s \frac1{L^2}\sum_{h\bmod M}|V_h\mathcal A_h|^2
 =\frac{M}{L^2}\sum_{x\bmod M}
 \left|\sum_{j=0}^{L-1}a_{x-j}\right|^2
 \ll_{A,s,\psi}(\log M)^{-2A}.
 \tag{11}
\]
重命名 $2A$ 证明 (1)。

## 证明：剩余门与负补偿

scratch/859 式 (3) 的逐频误差平方和由其式 (7) 为 $O(H^{-5}\log^4M)=O(M^{-1}\log^4M)$，故高除数 Gram $\sum_hw_H(h)|\sum_{d>D}\mu(d)\mathcal K_h(d)|^2$ 也满足 (1) 的任意对数幂界。scratch/859 式 (8)、(8a)、(8b)、(10) 支付的绝对值总量为
\[
 O_\psi\!\left(\frac{H^2\log^3M}{M}
 +\frac{H^4}{M\log^2M}\right),
 \tag{12}
\]
scratch/860 式 (3) 在 $B=2$ 时支付剩余远差 $O(M^{-2})$。在 (2) 范围，$H^4/M\ll M^{-4\vartheta}$；(12) 因而小于任意固定负对数幂。扣除这些项证明 (3)。更一般地，若 $H^4/M\to0$，则 (12) 为 $o((\log M)^{-2})$；高除数 Gram 由 (1) 为 $o((\log M)^{-2})$，所以 $\mathfrak S_{M,H}^{(s)}=o((\log M)^{-2})$。scratch/861 的 (2) 给 $\mathfrak P_{M,H}\gg(\log M)^{-2}$，遂得 (4)。

对 (4a) 的扩大余门，scratch/859 式 (8b) 的同一求和给小约化比例绝对量 $O(H^2R_*\log^2M/M)=O(H^4/(M\log^4M))$；其式 (9)--(10) 给新近差绝对量 $O(HK_{0,*}\log^5M/M)=O(H^4/(M\log^4M))$。对角、整除线仍为 $O(H^2\log^3M/M)$，远差仍为 $O(M^{-2})$。因 $H^4/M\ll1$，这些量合计 $O(\log^{-4}M)$；(1) 与 scratch/859 式 (7) 使高除数 Gram 本身为 $O(\log^{-5}M)$。scratch/861 的同格素数计数对更小的 $K_{0,*}$ 原样成立，且 $R_*<R$ 使比例条件仍满足。故 (4b) 成立。

在 (5) 范围，$H^4/M\gg_C(\log M)^{-4C}$；(1) 取 $A>4C$ 即得频带目标。$\square$

为证 (5a)，将 $Y^{1/4}/(\log Y)^C\le q(h)<Y^{1/4}$ 分成 $O_C(\log\log Y)$ 个 dyadic 带。note 849 式 (7)、(9) 与 (1) 使每带的归一化能量至多
$O(Y^3H^{-4}(\log Y)^{-A}+Y^3H^{-5}+H^5/Y)$。取 $A>4C+2$ 后，对这些带求和为 $O_{C,\psi}(Y^2)$；最低带的第二项为 $O(Y^{7/4}(\log Y)^{5C})=o(Y^2/\log\log Y)$。$q(h)\ge Y^{1/4}$ 的部分由 note 847 式 (2) 为 $O_\psi(Y^2\log Y)$，合并即得 (5a)。

## 明确来自 Möbius 异号的常数量级负块

式 (4b) 所需的负补偿可以在余门内直接看到，无需先从整段频带能量推断。仍取 $\psi\ge0$ 且非零，并选闭区间 $J\subset(1,2)$ 使 $\phi\ge c_\psi>0$。把 $MJ$ 划成长度 $L=\lfloor M/(32H)\rfloor$ 的完整整数格，忽略两端不足 $L$ 的部分。设 $\mathfrak X_{M,H}$ 为以下有序配对的 Gram 和：$d,e$ 位于同一完整格，$\mu(d)\mu(e)=-1$，$K_{0,*}<|d-e|\le L$，且 $\max(d/(d,e),e/(d,e))>R_*$。则 $d,e>M$，且这些配对均在 $\mathfrak S^*_{M,H}$ 内；一致于 $Y^{1/5}\le H\le Y^{1/4}$，
\[
 \boxed{\quad \mathfrak X_{M,H}\le-c_\psi<0.\quad}\tag{13}
\]
这里每个求和项的负号直接来自真实 $\mu(d)\mu(e)=-1$，因为本段的 $J_H(d-e)$ 严格为正。

证明如下。对任意完整格 $I\subset MJ$，初等平方自由计数给
\[
 \sum_{n\in I}\mu(n)^2=\frac{L}{\zeta(2)}+O(\sqrt M).
\]
式 (6) 的 Möbius 短和在 $L\asymp M/H$、$M^{3/4}\ll L\ll M^{4/5}$ 给 $\sum_{n\in I}\mu(n)=O_A(L\log^{-A}M)$。所以每个格内都有
\[
 \#\{n\in I:\mu(n)=+1\}
 =\#\{n\in I:\mu(n)=-1\}+o(L)
 =\frac{L}{2\zeta(2)}+o(L),
 \tag{14}
\]
对全部格一致。因而每格有 $\gg L^2$ 个有序异号配对；扣除 $|d-e|\le K_{0,*}$ 的至多 $O(LK_{0,*})=o(L^2)$ 对后仍有 $\gg L^2$ 对。这里 $K_{0,*}/L\ll H^4/(M\log^9M)=o(1)$。完整格数为 $\asymp_\psi M/L\asymp H$。

对任意 $d\in(M,2M)$，scratch/859 式 (2) 实际简化为
\[
 b_d(m)=-\frac{4\log2}{M}\phi(d/M)\mathbf1_{m=d},
 \tag{15}
\]
因为支撑内唯一的 $d$ 倍数是 $m=d$，其对数权为零；$2d>2M$。同格配对满足 $|d-e|\le L$，故 scratch/861 式 (5) 给 $J_H(d-e)\gg H$。每个异号项于是至多为 $-c_{\psi,s}H/M^2$；由 (14) 汇总全部格，未加约化比例限制的异号和至多为 $-c'_{\psi,s}<0$。最后，被 $\max(d/(d,e),e/(d,e))\le R_*$ 排除的异号项，其绝对总量由上文证明 (4b) 的小比例界至多为 $O(\log^{-4}M)=o(1)$。所以保留项仍满足 (13)。$\square$

## 边界

式 (4) 是实际 Möbius 高除数 Gram 中的无条件负补偿，说明保留的大约化比例与中距离配对中确有非平凡符号结构。式 (3) 的任意对数幂上界不等于 $O_\epsilon(H^4M^{-1+\epsilon})$：当 $H\le Y^{1/4-\vartheta}$ 时，后者是固定负幂。故本稿不证明完整 moving-$N$ 门、全尺度局部 Weil 正性或 RH。
