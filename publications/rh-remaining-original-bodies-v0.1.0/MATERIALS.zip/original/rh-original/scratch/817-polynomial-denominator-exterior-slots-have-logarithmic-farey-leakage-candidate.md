# 多项式分母外槽给出完整旧奇算子的对数级 Farey 泄漏（候选）

日期：2026-09-29。加强 [scratch 816](816-finite-denominator-exterior-layers-force-unbounded-farey-leakage-candidate.md) 的先固定分母层结论：在显式比例截断内，外槽分母可随 \(p\) 按幂次增长，归一化算术泄漏达到 \(\log p\) 量级。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇平移、相离核与 polar 界。只给完整算子的交叉块范数下界，不给 Schur 成本或 RH 结论。尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(k=p^2\)，固定
\[
0<\beta<\min\{\alpha,\,1-\alpha,\,1/2\}<1,
\qquad
Q=\lfloor p^\alpha\rfloor,\quad B=\lfloor p^\beta\rfloor.
\tag{1}
\]
采用 note 791 的旧奇偶极，置
\[
v_{p,\alpha}
=\sum_{a/b\in\mathcal F_Q}\frac{w_{a/b}}{\sqrt{ab}},
\quad
U_p=\mathbb C e_p\oplus W_p,
\quad
\mathcal Y_{p,B}
=\left\{\frac mb:2\le b\le B,\ p\le m<bp,\ (m,b)=1\right\},
\quad
Z_{p,B}=\operatorname{span}\{w_y:y\in\mathcal Y_{p,B}\}.
\tag{2}
\]
如 [scratch 811](811-farey-low-modes-have-a-fixed-transverse-full-space-leakage-candidate.md) 的定义域核对，每个阶跃偶极在 Archimedean 算子作用后至多有局部对数奇性，故有限和 \(v_{p,\alpha}\in D(A_{p^2,-})\)。下述全空间投影是 \(L^2\) 投影。对充分大 \(p\)，\(\{w_y\}_{y\in\mathcal Y_{p,B}}\) 是 \(U_p^\perp\cap H_{p^2}^-\) 中的正交单位族，并有真实完整旧奇算子的定量下界
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|P_{Z_{p,B}}A_{p^2,-}v_{p,\alpha}\|^2}
     {H^2\|v_{p,\alpha}\|^2}
\ge
\frac{2(1-\alpha/2)}{\alpha^2}
\left(\frac{\alpha\beta^2}{2}-\frac{\beta^3}{3}\right)>0.
}
\tag{3}
\]
特别取 \(\alpha=2/3,\ \beta=1/4\)，右侧等于 \(3/64\)，故
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|(I-P_{U_p})A_{p^2,-}v_{p,2/3}\|}
     {(\log p)\|v_{p,2/3}\|}
\ge\frac{\sqrt3}{8}.
}
\tag{4}
\]
还可固定 \(\alpha=1/2\) 后让 \(\beta\uparrow1/2\)（先对每个固定 \(\beta\) 取 \(p\to\infty\)）：(3) 的右侧趋于 \(1/8\)。故对每个 \(\eta>0\)，有一个固定的外槽指数 \(\beta<1/2\)，使相应归一化泄漏的下极限至少为 \(1/(2\sqrt2)-\eta\)。
这比 scratch 816 的无速率发散更强，但试探向量只支撑到 \(p^\alpha\)；其自身的主压缩能量仍有 [scratch 808](808-interior-farey-dipoles-have-a-sharp-growing-spectral-gap-candidate.md) 所给的正 \(2(1-\alpha)H+O(1)\) 谱隙。

## 几何与精确算术系数

由 \(B^2/p=p^{2\beta-1}\to0\)，两个不同既约目标 \(y,y'\in\mathcal Y_{p,B}\) 的绝对差至少 \(1/B^2\)，对数中心差至少 \(\gg1/(pB^2)\gg2\Delta\)，其中 \(\Delta=\frac12\log(1+p^{-2})\)。每个目标满足 \(p/B\le y<p\)，且其离物理端点的对数距离至少 \(\gg1/(pB)\gg\Delta\)。故目标偶极合法且两两正交。

若 \(x=a'/b'\in\mathcal F_p\) 与 \(y=m/b\in\mathcal Y_{p,B}\)，则 \(b'\ge b\) 时 \(x\le(p-1)/b'<p/b\le y\)，差至少 \(1/b\)；\(b'<b\) 时既约分数间距至少 \(1/(bb')\ge1/B^2\)。所以目标与所有 \(U_p\) 槽相离，仍由 \(B^2/p\to0\) 保证 \(Z_{p,B}\subset U_p^\perp\)。

源 \(x=a/b\in\mathcal F_Q\) 满足 \(x\le Q\)，而目标 \(y\ge p/B\)。由 \(BQ/p=p^{\alpha+\beta-1}\to0\)，目标比源大很多。素数幂平移折叠后若为 \(x/n\)，便远离目标；其余可能接近目标的 \(xn,n/x\) 的既约分母至多为源节点的 \(b,a\le Q\)。若输出比值 \(r\ne y=m/b_0\)，则
\[
|\log(r/y)|\gg\frac1{pB Q}\gg\frac1{p^2}=2\Delta.
\tag{5}
\]
所以算术投影仍只计精确整槽重合。所有源系数为正，旧算术项的系数为负，故没有符号抵消。选择 \(2\le b\le B\)、\(b<a<Q\)、\((a,b)=1\) 及素数 \(p\le aq<bp\)，则 \(q\ge p/Q=p^{1-\alpha}>B\)（由 \(\beta<1-\alpha\)），目标 \(y=aq/b\) 既约且位于外槽。两臂合计给矩阵元 \(-\log q/\sqrt q\)。因此
\[
\|P_{Z_{p,B}}\mathcal R_{p^2}v_{p,\alpha}\|^2
\ge
\sum_{2\le b\le B}\ \sum_{\substack{b<a<Q\\(a,b)=1}}
\frac1{ab}
\sum_{\substack{q\ {\rm prime}\\p\le aq<bp}}
\frac{(\log q)^2}{q}.
\tag{6}
\]
同一外槽接受多个源时，负贡献相加，平方交叉项非负。

## 对数尺度积分

记 \(u=\log a/H\)、\(v=\log b/H\)。素数定理的 Stieltjes 分部求和，对 \(a<Q\)、\(b\le B\) 一致给出
\[
\frac1{H^2}
\sum_{\substack{q\ {\rm prime}\\p/a\le q<bp/a}}
\frac{(\log q)^2}{q}
=
\int_{1-u}^{1-u+v}w\,dw+o(1)
=(1-u)v+\frac{v^2}{2}+o(1).
\tag{7}
\]
一致性来自 \(p/a\ge p^{1-\alpha}\to\infty\)；若 \(\theta(x)=\sum_{q\le x}\log q\)，则 \(\sup_{x\ge p^{1-\alpha}}|\theta(x)/x-1|\to0\)，分部求和的误差为 \(o(H^2)\)，对 \(b\le p^\beta\) 一致。

互素对数调和质量满足：任意有界连续 \(f\) 在
\(\mathcal D_{\alpha,\beta}=\{(u,v):0<v<\beta,\ v<u<\alpha\}\) 上有
\[
\frac1{H^2}
\sum_{\substack{b<a<Q,\ b\le B\\(a,b)=1}}
\frac{f(\log a/H,\log b/H)}{ab}
\longrightarrow
\frac1{\zeta(2)}
\int_{\mathcal D_{\alpha,\beta}}f(u,v)\,du\,dv.
\tag{8}
\]
证明是先以 \(\mathbf1_{(a,b)=1}=\sum_{d\mid(a,b)}\mu(d)\) 展开。每个固定 \(d\) 的内和是两重调和 Riemann 和，极限为 (8) 右侧的积分乘 \(1/d^2\)；尾 \(d>D\) 由 \(\sum_{d>D}d^{-2}\) 一致控制，再令 \(D\to\infty\)。

将 (7)--(8) 作用于 (6)，得到
\[
\liminf_{p\to\infty}
\frac{\|P_{Z_{p,B}}\mathcal R_{p^2}v_{p,\alpha}\|^2}{H^4}
\ge \frac{I_{\alpha,\beta}}{\zeta(2)},
\quad
I_{\alpha,\beta}
=\int_0^\beta\int_v^\alpha
\left((1-u)v+\frac{v^2}{2}\right)du\,dv
=\left(1-\frac\alpha2\right)
\left(\frac{\alpha\beta^2}{2}-\frac{\beta^3}{3}\right).
\tag{9}
\]
同一调和求和给
\[
\|v_{p,\alpha}\|^2
=\frac{\alpha^2H^2}{2\zeta(2)}+O(H).
\tag{10}
\]

## 非算术项

全部源 \(x\le Q\)，全部目标 \(y\ge p/B\)，故同臂中心距至少
\((1-\alpha-\beta)H+O(1)\to\infty\)，异臂更大。两偶极零均值和 note 791 的 \(|K''(d)|\ll d^{-3}\) 给每个 Archimedean 矩阵元 \(O(\Delta^3/H^3)\)。源系数绝对和为 \(O(Q)\)，目标个数为 \(O(pB^2)\)，故
\[
\|P_{Z_{p,B}}G_{p^2}v_{p,\alpha}\|
\ll p^{1/2}B Q\,\Delta^3/H^3=o(1).
\tag{11}
\]
每个目标偶极的 polar 投影为 \(O(p^{-5/2})\)，所以
\(\|P_{Z_{p,B}}s_{p^2}\|=O(Bp^{-2})\)；
note 791 的全 Farey 投影界给
\(|\langle s_{p^2},v_{p,\alpha}\rangle|=O(Hp^{-3/2})\)。
polar 对 (11) 也只添 \(o(1)\)。因此完整 \(A_{p^2,-}\) 在 \(Z_{p,B}\) 的投影与 (6) 的算术项相差 \(o(1)\) 范数。结合 (9)--(10) 即得 (3)；代入 \((2/3,1/4)\) 得 (4)。\(\square\)

## 边界

(3) 检出完整旧奇算子在一组明确外槽上的 \(\Omega(\log p)\) 归一化交叉块。它不等于 Schur 逆响应：目标外槽自身可能也有 \(\log p\) 量级能量及其他耦合。特别是两个目标 \(y=m/b,\ y'=m'/b'\) 的**异臂**素数幂平移只需满足
\[
|n b b'-m m'|<m m'/p^2\le B^2
\]
便可能发生近重叠；\(B\) 按幂次增长时不能把它替换成精确边。局部阶跃偶极相隔 \(s\ge0\) 的归一化重叠为
\[
R_\Delta(s)=
\begin{cases}
1-3s/(2\Delta),&0\le s\le\Delta,\\
s/(2\Delta)-1,&\Delta\le s\le2\Delta,\\
0,&s\ge2\Delta,
\end{cases}
\qquad \int_0^{2\Delta}R_\Delta(s)\,ds=0.
\]
事实上，同臂的有理间距仍迫使精确重合，故目标空间的算术矩阵元具有明确的两部分：
\[
\langle w_y,\mathcal R_{p^2}w_{y'}\rangle
=-c_{y/y'}-c_{y'/y}
-\!\!\sum_{\substack{n\ {\rm prime\ power}\\
|\log(n/(yy'))|<2\Delta}}
\frac{\Lambda(n)}{\sqrt n}\,
R_\Delta\!\left(\left|\log\frac{n}{yy'}\right|\right),
\qquad y,y'\in\mathcal Y_{p,B},
\]
其中 \(c_r\) 按 note 791 的约定取值。两臂配对各给半权；同臂非精确重合由 \(B^2/p\to0\) 排除。
重叠核本身变号，实际算术矩阵元的符号取决于位移；仅凭图几何不能以逐项负号控制目标空间的能量。主压缩的正增长谱隙与检出的交叉块同阶，仍须处理这些近共振和实际补空间成本后才能判断符号；moving-\(N\) Möbius signed covariance 的 \(Y^{2+\varepsilon}\) 门同样未解决。
