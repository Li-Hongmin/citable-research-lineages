# 物理互素层在目标量级内精确缩到真实素数与 Möbius 三通道

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (29)--(32) 的真实三通道分解、[scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 式 (6) 的非别名核和，以及 [scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 的互素除数反演。这里证明周期背景和高次素数幂经过物理 gcd $1$ 限制后仍在**无 $M^\varepsilon$ 损失的目标量级**内可删；结论及四项误差已完成独立代理只读复核。剩余真实三通道的固定幂上界仍未证明。

## 定理

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实 $\psi\in C_c^3((1,2))$、$\phi(t)=\psi(t)/t$，使用 scratch/860 的非负偶带通 $w_H$ 与核 $J_H$。对任何实系数序列 $d(m)$，记
\[
\mathcal G_\perp[d]=\sum_{\substack{M<m,n<2M\\(m,n)=1}}
\frac{d(m)d(n)}{M^2}\phi(m/M)\phi(n/M)J_H(m-n).
\tag{1}
\]
令 $c(m)$ 为 note 849 式 (10) 的完整真实系数，而
\[
c_{\rm tri}(m)=
2\mathbf1_{m=2p\text{，}p\text{ 素数}}\log p
-4\mathbf1_{m=p\text{，}p\text{ 素数}}\log p
-4(\log2)\mu(m)
\tag{2}
\]
是 note 849 式 (29) 的三通道系数。则一致于上述 $H$，
\[
\boxed{\quad
\left|\mathcal G_\perp[c]-\mathcal G_\perp[c_{\rm tri}]\right|
\ll_{s,\psi}
\frac{\log^2(2M)}{H^2}
+\frac1{H\log^3(2M)}
+\frac{H\log^2(2M)}M
+\frac{\log^2(2M)}{\sqrt M}
=o_{s,\psi}\!\left(\frac{H^4}{M}\right).
\quad}\tag{3}
\]
因而物理互素层的 $O_\varepsilon(H^4M^{-1+\varepsilon})$ 固定幂问题可在目标量级内直接改为 (2) 的**真实**素数、倍素数与 Möbius 系数；这一步没有对三通道之间的 signed covariance 作上界。

## 证明

写 $b(m)=4-2\mathbf1_{2\mid m}$，$P_2(n)=\Lambda(n)-\mathbf1_{n\text{ 素数}}\log n$。note 849 式 (31) 的逐点恒等式为
\[
c(m)-c_{\rm tri}(m)=b(m)+p_2(m),
\qquad p_2(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m).
\tag{4}
\]
这里所需的核界也可直接证明。令 $v=\chi_s^2$，Poisson 求和给 $J_H(r)=H\sum_{j\in\mathbb Z}\widehat v(H(r/M+j))$。因 $v\in C_c^\infty$，对任意 $A>2$ 及 $|r|\le(1-\kappa_\psi)M$ 有
\[
|J_H(r)|\ll_{A,s,\psi}H\left[(1+H|r|/M)^{-A}+H^{-A}\right].
\]
对 $r=qk\ne0$ 在上述非别名范围求和，单调积分比较两项均给
$\sum_{k\ne0,\,|qk|\le(1-\kappa_\psi)M}|J_H(qk)|\ll_{s,\psi}M/q$；另有 $|J_H(0)|\ll_s H$。下文只使用这些界。

在 $(M,2M)$ 中，$p_2$ 非零只可能来自 $p^k$ 或 $2p^k$、$k\ge2$。这些整数合计 $O(\sqrt M)$ 个，且 $|p_2(m)|\ll\log(2M)$。因此对权 $a_{p_2}(m)=M^{-1}p_2(m)\phi(m/M)$，
\[
\sum_m|a_{p_2}(m)|\ll_\psi M^{-1/2}\log(2M).
\tag{5}
\]
任取 $|d(m)|\ll\log(2M)$。由 $\phi$ 紧支撑，非零物理配对满足 $|m-n|\le(1-\kappa_\psi)M$；scratch/868 式 (6) 取 $q=1$，连同 $J_H(0)\ll H\ll M$，给对每个 $m$ 的核绝对行和 $\sum_n|J_H(m-n)|\ll_{s,\psi}M$。故即使不施加互素限制，
\[
\sum_{m,n}|a_{p_2}(m)|
\left|\frac{d(n)}M\phi(n/M)J_H(m-n)\right|
\ll_{s,\psi}M^{-1/2}\log^2(2M).
\tag{6}
\]
这支付所有含至少一个 $p_2$ 的二次型交叉项。

下面支付周期背景 $b$ 与任意 $|d(m)|\ll\log(2M)$ 的互素交叉项。令 $Q=\lfloor H(\log(2M))^4\rfloor$。对 $q\ge1$ 设
\[
B_{q,h}=\frac1M\sum_{q\mid m}b(m)\phi(m/M)e(-hm/M),
\qquad
D_{q,h}=\frac1M\sum_{q\mid m}d(m)\phi(m/M)e(-hm/M).
\tag{7}
\]
互素除数反演给交叉项 $\mathcal B_\perp(b,d)=\sum_{q\ge1}\mu(q)\sum_hw_H(h)B_{q,h}\overline{D_{q,h}}$。对 $q\le Q$，$b(m)\mathbf1_{q\mid m}=4\mathbf1_{q\mid m}-2\mathbf1_{[2,q]\mid m}$，模数至多 $2Q$。由于 $H(2Q)/M=o(1)$，Poisson 求和及 $\phi\in C_c^3$ 如 scratch/870 式 (9) 给
\[
|B_{q,h}|\ll_\psi H^{-3}
\quad(w_H(h)\ne0,q\le Q).
\tag{8}
\]
而倍数平凡计数给 $|D_{q,h}|\ll_\psi\log(2M)/q$，因为 $Q=o(M)$。频带含 $O(H)$ 个整数，故
\[
\sum_{q\le Q}\sum_hw_H(h)|B_{q,h}D_{q,h}|
\ll_{s,\psi}H^{-2}\log(2M)\log(2Q)
\ll_{s,\psi}H^{-2}\log^2(2M).
\tag{9}
\]

对 $q>Q$ 把交叉项展开成物理配对并取绝对值。非对角处 $q\mid m,n$ 意味着 $q\mid m-n$；保持支撑约束，scratch/868 式 (6) 及每个 $q$ 有 $O(M/q)$ 个候选 $m$，给
\[
\sum_{q>Q}\sum_{\substack{m\ne n\\q\mid m,n}}
\left|\frac{b(m)d(n)}{M^2}\phi(m/M)\phi(n/M)J_H(m-n)\right|
\ll_{s,\psi}\frac{\log(2M)}Q
\ll\frac1{H\log^3(2M)}.
\tag{10}
\]
对角处按 $\sum_{m\le2M}\tau(m)\ll M\log(2M)$ 得
\[
\sum_{q>Q}\sum_{q\mid m}
\left|\frac{b(m)d(m)}{M^2}\phi(m/M)^2J_H(0)\right|
\ll_{s,\psi}\frac{H\log^2(2M)}M.
\tag{11}
\]
式 (9)--(11) 对 $d=c_{\rm tri}$、$d=b$ 均适用。展开 $c=c_{\rm tri}+b+p_2$，由 (6) 支付全部 $p_2$ 项，再由 (9)--(11) 支付两条 $b$ 交叉项及 $b$ 自项，即得式 (3) 的绝对值界。

最后，$H^5\gg M$ 且 $H\gg M^{1/5}$。将 (3) 右侧逐项除以 $H^4/M$：四项依次为 $O(MH^{-6}\log^2M)$、$O(MH^{-5}\log^{-3}M)$、$O(H^{-3}\log^2M)$、$O(M^{1/2}H^{-4}\log^2M)$，均趋零且关于 $H$ 一致。$\square$

此结果只删去 gcd $1$ 层中可由平滑性与稀疏性支付的系数。剩余 $c_{\rm tri}$ 仍包含真实三通道的全部难点；它的互素 Gram 即使有任意对数幂上界，也没有得到 $H^4/M$ 的固定幂上界。
