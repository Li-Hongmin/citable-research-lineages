# 完整两臂源核的奇平方自由支撑可达目标频带量级（待异源复核）

日期：2026-10-03。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂核。这里把真实源系数 $\mu(u)$ 换为 $\mu(u)^2$，证明其频带平方和具有目标幂次；真实 Möbius 符号仍未支付。

## 命题

沿整数 $Y\to\infty$，令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$、$D=\lfloor M/(32H)\rfloor$。固定 $\psi\in C_c^3((1,2))$、$\phi(x)=\psi(x)/x$，以及固定非负 $\eta\in C_c^\infty(\mathbb R)$，支撑于 $1/2\le|t|\le4$。沿用 note 850 的完整奇数源权 $W(k)$ 与核
\[
\mathcal K_h(u)=\frac1M\sum_{\substack{k\ge3\\M<ku<2M}}
W(k)\phi(ku/M)e(-hku/M).
\]
定义去符号的平方自由源包
\[
\mathcal B_h^{\rm sf}(M)=
\sum_{\substack{D<u<2M/3\\u\text{ 奇}}}\mu(u)^2\mathcal K_h(u).
\tag{1}
\]
则一致于上述 $H$，
\[
\boxed{\quad
\sum_{h\in\mathbb Z}\eta(h/H)
|\mathcal B_h^{\rm sf}(M)|^2
\ll_{\psi,\eta}\frac{H^4}{M}\log^4(2M).
\quad}\tag{2}
\]
特别对每个 $\varepsilon>0$，左侧为 $O_{\varepsilon,\psi,\eta}(H^4M^{-1+\varepsilon})$。式 (2) 同时覆盖 note 850 的奇、偶两个乘子臂及真实硬截断 $u>D$。

## 证明

奇平方自由整数的计数函数满足
\[
F(x):=\sum_{\substack{u\le x\\u\text{ 奇}}}\mu(u)^2
=\delta x+O(\sqrt x),\qquad
\delta=\frac12\sum_{d\text{ 奇}}\frac{\mu(d)}{d^2}
=\frac4{\pi^2}.
\tag{3}
\]
这由 $\mu^2(u)=\sum_{d^2\mid u}\mu(d)$、奇数计数 $z/2+O(1)$ 和 $\sum_{d>\sqrt x}d^{-2}\ll x^{-1/2}$ 直接给出。

交换 (1) 中的有限 $u,k$ 和。因 $u>D$、$ku<2M$，活动乘子满足 $3\le k<2M/D\ll H$；而对 $k\ge3$，$ku<2M$ 已蕴含 $u<2M/3$。定义 $x_k=kD/M$ 及
\[
I_k(h)=\int_{x>x_k}\phi(x)e(-hx)\,dx.
\]
在 $k$ 固定时，对 (3) 作 Stieltjes 分部积分。活动 $u$ 均在 $[M/k,2M/k]$ 内，$\phi(ku/M)e(-hku/M)$ 的上确界为 $O_\psi(1)$、总变差为 $O_\psi(1+|h|)$。故一致于 $|h|\asymp H$，
\[
\sum_{\substack{u>D\\u\text{ 奇}}}
\mu(u)^2\phi(ku/M)e(-hku/M)
=\delta\frac{M}{k}I_k(h)
+O_\psi\!\left((1+|h|)\sqrt{\frac Mk}\right).
\tag{4}
\]
这里即使 $u>D$ 的硬边界落在活动区间内部，令 $E(t)=F(t)-\delta t$ 后 Stieltjes 分部积分会出现 $-E(D)\phi(kD/M)e(-hkD/M)$；由于活动时 $D\le2M/k$，它为 $O_\psi(\sqrt{M/k})$，已包含在 (4) 中。

由 $W$ 的定义，$|W(k)|\ll\log(2k)$，所以
\[
\sum_{k<2M/D}\frac{|W(k)|}{k}\ll\log^2(2H),
\qquad
\sum_{k<2M/D}\frac{|W(k)|}{\sqrt k}
\ll\sqrt H\log(2H).
\tag{5}
\]
把 (4) 乘 $W(k)/M$ 并对 $k$ 求和，误差是
\[
O_\psi\!\left(\frac{(1+|h|)\sqrt H}{\sqrt M}\log(2H)\right)
=O_\psi\!\left(\frac{H^{3/2}}{\sqrt M}\log(2H)\right).
\tag{6}
\]

若 $k\le M/D$，则 $x_k\le1$，$I_k(h)$ 为完整 $\widehat\phi(h)$；三次分部积分给 $|I_k(h)|\ll_\psi |h|^{-3}$。若 $M/D<k<2M/D$，则 $x_k\in(1,2)$，一次分部积分一致给 $|I_k(h)|\ll_\psi |h|^{-1}$。后一区间 $k$ 的比值小于 $2$，故其 $\sum |W(k)|/k\ll\log(2H)$。综上，在 $H/2\le|h|\le4H$，
\[
|\mathcal B_h^{\rm sf}(M)|
\ll_\psi
\frac{\log^2(2H)}{H^3}
+\frac{\log(2H)}H
+\frac{H^{3/2}\log(2H)}{\sqrt M}.
\tag{7}
\]
频带含 $O_\eta(H)$ 个整数，$\eta$ 有界。平方求和得到
\[
\sum_h\eta(h/H)|\mathcal B_h^{\rm sf}|^2
\ll_{\psi,\eta}
\frac{\log^4(2H)}{H^5}
+\frac{\log^2(2H)}H
+\frac{H^4\log^2(2H)}M.
\tag{8}
\]
因 $H^5\ge Y=M/2$，第二项至多 $O(H^4\log^2(2M)/M)$；第一项亦被 (2) 的右侧吸收。这证明 (2)。$\square$

## 含义与边界

这是一项完整两臂、真实裁剪的**无条件固定幂频带估计**，但其系数为 $\mu^2$ 而非 $\mu$。它证明平方自由支撑及奇数限制本身不产生当前的固定幂缺口；把 $\mu(u)$ 写成平方自由支撑乘以 Liouville 符号后，未付的是符号对 $k$、$h$ 和移动源区间的联合抵消。式 (2) 不控制任何含实际 $\mu(u)$ 的交叉项，不能与完整源包的平方作单调比较，也不推出 note 849 式 (15) 或 RH。

同一逐乘子 Abel 论证的门槛可以精确量化：若把 (3) 的误差 $O(x^{1/2})$ 改为 $O(x^\theta)$，$1/2\le\theta<1$，则 (6) 的一般形式为
\[
O_\psi\!\left(M^{\theta-1}H^{2-\theta}\log(2H)\right),
\]
其频带平方和为 $O(M^{2\theta-2}H^{5-2\theta}\log^2(2H))$。相对目标 $H^4/M$ 的幂次比是 $(M/H)^{2\theta-1}$。因此**这套逐乘子绝对 Abel 论证**恰在平方根指数 $\theta=1/2$ 达标；把实际 $\mu$ 代入时需要平方根级的奇数 Möbius 部分和，不能由现有次指数节省替代。这个计算只给该证明方法的阈值，不证明真实源包必须逐乘子支付。
