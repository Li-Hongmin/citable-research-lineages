# 中央素数与端点非素数的真实 moving 协方差有负的 \(Y^{5/2}/\log^2Y\) 主项（候选）

日期：2026-09-29。依赖 [note 767](../notes/767-cubic-over-log-squared-covariance-in-the-actual-high-divisor-gate.md) 的真实素数通道主项及 \(K>0\)、[note 760](../notes/760-sharp-log-squared-variation-of-the-full-k2-cofactor-kernel.md) 的核变差、[note 730](../notes/730-k2-high-divisor-endpoint-layer-is-a-boundary-free-two-frequency-mobius-kernel.md) 的端点核。这里给出真实 \(\mu\) 的一个跨层有符号估计；不控制完整高除数均方。本证明仍在 scratch，尚未异源复核。

## 定理候选

令 \(Y\to\infty\) 沿整数，\(D=\lfloor Y^{4/5}\rfloor\)、\(W=\lfloor Y^{5/6}\rfloor\)，并记
\[
 \Phi(t)=\log t\sum_{1/t<a<2/t}\sin(2\pi at),
 \qquad K=\int_0^1\Phi(t)dt>0.
\]
对 \(Y<N\le2Y\) 定义中央素数通道、端点全通道、端点素数通道及端点非素数通道
\[
 \begin{aligned}
 P_N&=-\sum_{D<p<N-W}\Phi(p/N),\\
 E_N&=\sum_{N-W\le d<N}\mu(d)\Phi(d/N),\\
 Q_N&=-\sum_{N-W\le p<N}\Phi(p/N),\\
 R_N&=E_N-Q_N.
 \end{aligned}
\tag{1}
\]
素数变量均只取素数。另记中央全通道 \(B_N=\sum_{D<d<N-W}\mu(d)\Phi(d/N)\) 与中央非素数通道 \(C_N=B_N-P_N\)。则
\[
 \boxed{
 \sum_{Y<N\le2Y}P_NQ_N
 =\frac{4\pi K\log2}{3}\frac{W^3}{\log^2Y}
 +O\!\left(\frac{W^3}{\log^3Y}\right),}
\tag{2}
\]
而实际 Möbius 端点层与中央素数通道满足对每个固定 \(A>0\) 的
\[
 \boxed{\sum_{Y<N\le2Y}P_NE_N
 =o_A\!\left(\frac{W^3}{\log^A Y}\right).}
\tag{3}
\]
因此保留 \(\mu(p)=-1\) 与端点非素数真实符号时，
\[
 \boxed{
 \sum_{Y<N\le2Y}P_NR_N
 =-\frac{4\pi K\log2}{3}\frac{W^3}{\log^2Y}
 +O\!\left(\frac{W^3}{\log^3Y}\right).}
\tag{4}
\]
因为 \(W^3=Y^{5/2}(1+o(1))\)，(4) 是真实高除数门内部的超二次负交叉量。它抵消 (2) 的正量至每个固定对数阶，但 (3) 仍远弱于 \(O(Y^{2+\varepsilon})\)，故不证明完整 covariance 门。

更完整地，四个真实通道的有序交叉矩阵具有秩一主项：
\[
 \boxed{
 \sum_{Y<N\le2Y}
 \begin{pmatrix}P_NQ_N&P_NR_N\\ C_NQ_N&C_NR_N\end{pmatrix}
 =\frac{4\pi K\log2}{3}\frac{W^3}{\log^2Y}
 \begin{pmatrix}1&-1\\-1&1\end{pmatrix}
 +O_{\rm entry}\!\left(\frac{W^3}{\log^3Y}\right).}
\tag{4a}
\]
因此正、负大项在中央全通道与端点全通道相乘时彼此抵消；矩阵项本身不能逐项视作 \(O(Y^{2+\varepsilon})\)。

**宏观 product 位移的固定 \(a=2\) 子通道。** 令 \(I=[13/16,7/8]\) 并置 \(K_I=\int_I\Phi(t)dt>0\)、\(P_N^I=-\sum_{p/N\in I}\Phi(p/N)\)。则同样有
\[
 \boxed{\sum_{Y<N\le2Y}P_N^I R_N
 =-\frac{4\pi K_I\log2}{3}\frac{W^3}{\log^2Y}
 +O\!\left(\frac{W^3}{\log^3Y}\right).}
\tag{4b}
\]
此处每个非零配对都只有 \(a=2\) cofactor，中央 product \(n=2p\) 与端点 product \(m=2d\) 满足 \(m-n\ge Y/8\) 对充分大 \(Y\) 成立。因此 (4b) 的负量完全来自**固定比例远隔**的真实 product 配对。

## 端点素数的主项

在 \(h=N-d\le W=o(Y)\) 上，note 730 的精确公式为
\[
 \Phi((N-h)/N)=L(h/N),\qquad
 L(u)=\log\frac1{1-u}\sin(4\pi u)
 =4\pi u^2+O(u^3).
\tag{5}
\]
因此 \(Q_N\le0\)，并且由 Chebyshev 的 \(\pi(2Y)\ll Y/\log Y\)，交换 \(N,p\) 的有限和后可得
\[
 \sum_{Y<N\le2Y}|Q_N|
 \ll \frac{Y}{\log Y}\sum_{h\le W}\frac{h^2}{Y^2}
 \ll\frac{W^3}{Y\log Y}.
\tag{6}
\]
note 767 的素数主项与 scratch 805 的 collar 删去界给出一致的
\[
 P_N=-K\frac N{\log N}+O\!\left(\frac Y{\log^2Y}\right).
\tag{7}
\]
(6) 使 (7) 的误差对 \(\sum P_NQ_N\) 至多贡献 \(O(W^3/\log^3Y)\)。其主项为
\[
 K\sum_{\substack{Y<N\le2Y\\N-W\le p<N}}
 \frac N{\log N}L((N-p)/N).
\tag{8}
\]
令 \(N=p+h\)。除 \(p\) 距 \(Y\) 或 \(2Y\) 至多 \(W\) 的边界外，\(1\le h\le W\) 可全部取到。边界项的绝对值由至多 \(O(W)\) 个整数 \(p\) 及 (5) 界为 \(O(W^4/(Y\log Y))=O(W^3/\log^3Y)\)。在内部，(5) 与 \(W=o(Y)\) 给出一致渐近
\[
 \sum_{h\le W}\frac{p+h}{\log(p+h)}L\!\left(\frac h{p+h}\right)
 =\frac{4\pi W^3}{3p\log Y}
 \left(1+O\!\left(\frac1W+\frac WY+\frac1{\log Y}\right)\right).
\tag{9}
\]
素数定理的分部求和形式给出
\[
 \sum_{Y<p\le2Y}\frac1p
 =\frac{\log2}{\log Y}+O(\log^{-2}Y).
\tag{10}
\]
将 (9)--(10) 代回 (8)，得到 (2)。

## Möbius 端点与中央素数的总交叉

经典 Vinogradov--Korobov 上界给出某个 \(c>0\)，使
\[
 \sup_{Y-W\le x\le2Y}|M(x)|
 \ll Y e^{-c\omega(Y)},\qquad
 M(x)=\sum_{d\le x}\mu(d),\quad
 \omega(Y)=\frac{(\log Y)^{3/5}}{(\log\log Y)^{1/5}}.
\tag{11}
\]
把 \(E_N\) 的 \(d=N-h\) 展开并交换有限和，得到
\[
 \sum_{Y<N\le2Y}P_NE_N
 =\sum_{Y-W<d<2Y}\mu(d)G(d),
\quad
 G(d):=\sum_{h=1}^{W}
 \mathbf1_{Y<d+h\le2Y}P_{d+h}L\!\left(\frac h{d+h}\right).
\tag{12}
\]
为对 \(G\) 作离散 Abel 求和，只需两个粗界。note 728 的绝对核和给出 \(\sup_{Y<N\le2Y}|P_N|\ll Y\)。note 760 在实际 \(D/(2Y)\le t\le1\) 上给出 \(\operatorname{Var}\Phi\ll\log^2Y\)。对每个素数 \(p\)，序列 \(N\mapsto\mathbf1_{D<p<N-W}\Phi(p/N)\) 的总变差至多 \(O(\log^2Y)\)；素数不超过 \(2Y\) 个，故
\[
 \operatorname{Var}_{Y<N\le2Y}P_N\ll Y\log^2Y.
\tag{13}
\]
对固定 \(h\le W\)，由 (5) 及 \(L'(u)=O(u)\) 当 \(u\le W/Y\) 可得
\[
 \sup_{Y<N\le2Y}|L(h/N)|
 +\operatorname{Var}_{Y<N\le2Y}L(h/N)
 \ll h^2/Y^2.
\tag{14}
\]
把区间指示函数在 \(N=Y,2Y\) 的两次跳跃计入后，(12)--(14) 的离散乘积变差不等式给出
\[
 \sup_d|G(d)|\ll W^3/Y,
 \qquad \operatorname{Var}_d G\ll W^3\log^2Y/Y.
\tag{15}
\]
注意 \(G\) 的支撑包含于 \((Y-W,2Y)\)，故离散 Abel 公式和 (11) 给出
\[
 \left|\sum_d\mu(d)G(d)\right|
 \ll \sup_{Y-W\le x\le2Y}|M(x)|
 \bigl(\sup|G|+\operatorname{Var}G\bigr)
 \ll W^3e^{-c\omega(Y)}\log^2Y.
\tag{16}
\]
该量为 \(o_A(W^3/\log^A Y)\) 对每个固定 \(A>0\)，证明 (3)。再由 \(R_N=E_N-Q_N\)，(2)--(3) 直接证明 (4)。\(\square\)

最后证明 (4a) 中剩余两格。note 767 的 \(H_D(N):=\sum_{D<d<N}\mu(d)\Phi(d/N)=o_A(Y/\log^A Y)\) 对每个固定 \(A>0\) 及全部 \(Y<N\le2Y\) 一致成立，而 \(B_N=H_D(N)-E_N\)。scratch 805 给出 \(\sup_N|E_N|\ll W^3/Y^2\) 和 \(\sum_N E_N^2\ll W^6/Y^3=O(Y^2)\)；上面的 (6) 给出 \(\sum_N|Q_N|\ll W^3/(Y\log Y)\)。所以，对每个固定 \(A>0\)，
\[
 \begin{aligned}
 \sum_N B_NE_N
 &=\sum_N H_D(N)E_N-\sum_N E_N^2
 =o_A(W^3/\log^A Y),\\
 \sum_N B_NQ_N
 &=\sum_N H_D(N)Q_N-\sum_N E_NQ_N
 =o_A(W^3/\log^A Y).
 \end{aligned}
\]
这里 \(|\sum_N E_NQ_N|\ll(W^3/Y^2)(W^3/(Y\log Y))=O(Y^2/\log Y)\)，与 \(\sum E_N^2\) 一样均比 \(W^3/\log^A Y\) 小任意固定对数幂。由 \(C_N=B_N-P_N\)、\(R_N=E_N-Q_N\)，这两式与 (2)--(3) 给出 (4a)。\(\square\)

对 (4b)，在固定区间 \(I\subset(3/4,1)\) 上仅有 \(a=2\) cofactor，且 \(\log t<0\)、\(\sin(4\pi t)<0\)，故 \(K_I>0\)。对 \(\Phi(t)\mathbf1_I(t)\) 作素数定理的 Stieltjes 分部求和，得到一致的 \(P_N^I=-K_I N/\log N+O(Y/\log^2Y)\)。这个固定 BV 核使 \(\operatorname{Var}_N P_N^I\ll Y\)，所以 (12)--(16) 对 \(P_N^I\) 原样成立；(8)--(10) 只需把 \(K\) 换为 \(K_I\)。这证明 (4b)。若 \(p/N\le7/8\) 而 \(d\ge N-W\)，则 \(2(d-p)\ge2(N/8-W)\ge Y/8\) 对充分大 \(Y\) 成立，给出 product 位移断言。\(\square\)

## 边界

(4a)--(4b) 只确定指定跨层通道在对数主尺度上的有符号结构。真正完整的 \(\sum_N|H_{N,2}^{>D}|^2\) 还含各层自身及所有其余 cross；这些项可能在更高精度继续抵消。(16) 的零自由区节省强于任意对数，却仍不足以支付 \(Y^{1/2}\) 的幂差。它不能作为 RH、全尺度局部 Weil 正性或完整 moving-\(N\) covariance 上界的证据。
