# 全轮廓素数平移块加入几乎所有有理锥（候选，待异源复核）

日期：2026-10-01。沿用 [scratch/894](894-almost-all-rational-cones-join-prime-dilates-after-incidence-pruning.md) 的良好有理根集合、素数标签删点和完整锥结论，但把每个保留素数槽的常值向量扩展为**全部有限能量奇轮廓**。单槽闭形式以 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 式 (4)--(7) 为准，平移与反射符号按 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 及 [scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md)。以下为依赖上游候选稿的完整推导，尚未异源复核，不能视作 RH 证明。

后续 [scratch/896](896-omitted-prime-profile-slots-have-vanishing-direct-root-column.md) 对略小的良好根集合证明：删去的主素数区间槽连同可能的次级素数幂平移，其**直接**根形式列范数为 \(o(1)\)。

## 命题

置 \(H=\log X\)、\(w=\frac12\log(1+X^{-2})\)。取 scratch/894 的 \(\mathcal G_X^*\subset\mathcal G_X^\circ\)，满足
\(|\mathcal G_X^\circ\setminus\mathcal G_X^*|\ll X^2/\sqrt H\)。对 \(y\in\mathcal G_X^*\)、整数 \(1\le B\le X^{1/5}\)，令 \(\mathcal Q_{y,B}\) 为 scratch/894 留下的素数标签，\(\mathcal U_{y,B}^{\rm prof}\) 为这些 \(p/y\) 槽中**所有**有限能量奇轮廓的闭形式直和。则 \(\mathcal U_{y,B}^{\rm prof}\perp\mathscr V_{y,B}\)，并有统一闭形式下界
\[
\boxed{\quad
A_{X^2,-}|_{\mathcal U_{y,B}^{\rm prof}}
\succeq(2H-C\sqrt H)I.
\quad}
\tag{1}
\]
锥的全部非根槽与此空间的算术跨块精确为零，剩余非算术跨块的算子范数为 \(O(1)\)。

对固定 \(\sigma\in[5/4,3/2)\)，记 \(\mathcal U_{y,B}^{\rm prof,(\sigma)}\) 只保留 \(p\ge X^\sigma\) 的标签，并置
\[
d_\sigma=\frac{9/4-\sigma^2}{4}>0.
\]
根常值槽 \(e_{y,1}\) 到该**全轮廓**素数块的真受限 Schur 扣款满足
\[
\boxed{\quad
\langle f^{\rm prof}_{y,B,\sigma},
(A|_{\mathcal U_{y,B}^{\rm prof,(\sigma)}})^{-1}
f^{\rm prof}_{y,B,\sigma}\rangle
=(d_\sigma+o(1))H.
\quad}
\tag{2}
\]
更一般地，若根槽单位轮廓 \(h_X\in D(\mathfrak b)\) 的缩放单槽能量满足 \(\mathfrak b[h_X]=o(H)\)，则以 \(\iota_y h_X\) 替代 \(e_{y,1}\) 时，(2) 的右侧仍为 \((d_\sigma+o(1))H\)；该误差在 \(\mathfrak b[h_X]/H\to0\) 的统一族上成立。
此外，若固定 \(0<\alpha<1/5\)、\(B\le X^\alpha\)，并选 \(\sigma\) 使 \(d_\sigma<1-5\alpha\)，则**两个槽族的全部有限能量轮廓**形成的联合压缩有线性正谱隙：
\[
\boxed{\quad
A_{X^2,-}|_{\mathscr V_{y,B}\oplus\mathcal U_{y,B}^{\rm prof,(\sigma)}}
\succeq c_{\alpha,\sigma}H I.
\quad}
\tag{3}
\]
特别地，\(\alpha<53/320\) 时可取 \(\sigma=5/4\)，保留素数区间 \([X^{5/4},X^{3/2}]\) 的 \((11/32+o(1))H^2\) 根列平方质量；任意固定 \(\alpha<1/5\) 可取一个靠近 \(3/2\) 的固定 \(\sigma\)。删点只损失该平方质量的 \(o(H^2)\)，不是保留每个素数标签。

## 全轮廓素数块的闭形式下界

对每个素数槽使用上臂局部坐标 \(t\in(0,w)\)，把任意轮廓记作 \(g_p\in D(\mathfrak b)\subset L^2(0,w)\)。scratch/892 的槽距给不同 \(p,q\) 的正交直和；固定 \(X\) 只有有限多个槽，note 790 的形式核心使它们的有限直和为闭形式域。note 790 式 (4)--(5) 对每一单位轮廓给 \(2H-O(1)\) 的 Archimedean 自能量。不同素数槽的同臂算术平移为零：若 \(s\ge2\) 是整数素数幂且两个槽相交，\(|\log(sp/q)|<w\) 迫使 \(|sp-q|<1\)，从而 \(q=sp\)，与两者均为素数矛盾。

相离 Archimedean 核的同臂绝对块行和 \(O(HX^{-1/2})\)，异臂行和 \(O(X^{-3/4})\)，均与轮廓无关，正是 scratch/893 式 (5) 的槽距估计。polar 在这些槽的投影满足 \(\|P_{\mathcal U^{\rm prof}}s_k\|^2\ll w\sum_{p\in\mathcal P_X}p/y=O(1)\)。剩下的异臂算术块对 \((p,q)\) 的轮廓算子是一个或多个范数至多一的部分反射，绝对块范数受 scratch/893 式 (8) 的 \(\widetilde K_y(p,q)\) 控制。该稿的加权行负载删点使每个留下的 \(p\) 满足
\[
\frac{\sum_q\widetilde K_y(p,q)c_q}{c_p}\le\sqrt H,
\qquad c_p=\frac{\log p}{\sqrt p}.
\tag{4}
\]
对 Hilbert 空间值轮廓 \((g_p)\) 作正权块 Schur 检验，异臂算术范数因此至多 \(\sqrt H\)。再删去 scratch/894 中有非根同臂跨块的素数只会降低非负行负载。与单槽下界、非对角和 polar 界合并得 (1)。由有界跨槽项扰动 note 790 的闭形式直和，(1) 从光滑核心延拓到所有有限能量轮廓。

## 根的精确反射列及全轮廓响应

设根上臂轮廓为 \(h\in L^2(0,w)\)，令 \((Jh)(t)=h(w-t)\)。若 \(p\in\mathcal Q_{y,B}\)，scratch/892 式 (5) 已删除根到该槽的其他素数幂平移；\(T_p\) 把根上臂送到目标下臂，\(T_p^*\) 把根下臂送到目标上臂。上下两臂各有半权且带相反的奇符号，于是对任意目标轮廓 \(g_p\)，**两项之和**精确给
\[
\mathcal R_{X^2}[\iota_y h,\iota_{p/y}g_p]
=c_p\langle Jh,g_p\rangle,
\qquad
\|T_{y,B,\sigma}h\|^2
=\sum_{p\in\mathcal Q_{y,B},\ p\ge X^\sigma}c_p^2\|h\|^2,
\tag{5}
\]
其中 \(T_{y,B,\sigma}h=(c_pJh)_p\)、\(\iota\) 表示奇槽等距嵌入。注意目标轮廓已扩展后，根的算术列作用在**整个**根轮廓空间上；只有把目标限为常值轮廓时它才退化为常值平均的秩一配对。

根与素数槽相距至少 \(H/2-O(1)\)，故相离 Archimedean 根列的 \(\ell^2\) 块范数为 \(o(1)\)；根 polar 投影平方为 \(O(X^{-1})\)，目标 polar 投影范数为 \(O(1)\)，亦给 \(o(1)\)。对根常值 \(h_0=w^{-1/2}\mathbf1_{(0,w)}\)，真实列因此为 \((c_ph_0)_p+o_{\oplus L^2}(1)\)。scratch/892 的初始碰撞删除、scratch/893 的反射负载删点和 scratch/894 的同臂事故删点合计只损失 \(o(H^2)\) 平方质量；素数定理遂给
\[
S_\sigma:=\sum_{p\in\mathcal Q_{y,B},\ p\ge X^\sigma}c_p^2
=\left(\frac{9/4-\sigma^2}{2}+o(1)\right)H^2.
\tag{6}
\]
由 (1)，(2) 的左侧至多为 \((S_\sigma+o(H^2))/(2H-C\sqrt H)=(d_\sigma+o(1))H\)。反向只在全轮廓空间中的常值向量 \(g=(c_ph_0)_p\) 上试探：其根配对为 \(S_\sigma+o(H^2)\)，而 scratch/893 的常值素数压缩及 (4) 给 \(A[g]\le(2H+C\sqrt H)S_\sigma\)。逆度量变分给至少 \((d_\sigma+o(1))H\)，证明 (2)。

对任意所述 \(h_X\) 改取 \(g=(c_pJh_X)_p\)。反射 \(J\) 保持 note 790 式 (5) 的 \(\mathfrak b\)，故单槽自能量与 (4) 的算术范数给
\(A[g]\le S_\sigma(2H+C\sqrt H+\mathfrak b[h_X])=(2H+o(H))S_\sigma\)。式 (5) 及非算术根列 \(o(1)\) 给根配对 \(S_\sigma+o(H^2)\)。同一逆度量变分下界与 (1) 的上界相合，证明轮廓推广。

## 与完整轮廓有理锥联合

scratch/894 的整数间距删点和 scratch/893 的分子整除论证只看槽支撑，故对 \(\mathcal U^{\rm prof}\) 的任意轮廓，全部非根锥槽的同臂与异臂算术交叉仍精确为零。scratch/894 式 (9)--(10) 的 Carleman 近邻界本已针对任意轮廓，给非算术跨块算子范数 \(O(1)\)。因此完整锥到 \(\mathcal U_{y,B}^{\rm prof,(\sigma)}\) 的形式跨块可写成
\[
C_{y,B,\sigma}^*=T_{y,B,\sigma}P_{\rm root}+E_{y,B,\sigma},
\qquad \|E_{y,B,\sigma}\|=O(1),
\tag{7}
\]
其中 \(P_{\rm root}\) 取锥的整个根槽轮廓，而 \(T\) 为 (5) 的等距反射列。令 \(F=A|_{\mathcal U_{y,B}^{\rm prof,(\sigma)}}\)。由 (1)、(5)--(6)，
\[
F^{-1}\preceq(2H-C\sqrt H)^{-1}I,
\qquad \|T\|^2=S_\sigma,
\]
且 \(\|F^{-1/2}E\|=O(H^{-1/2})\)。于是 \(C F^{-1}C^*\) 的算子范数至多 \((d_\sigma+o(1))H\)。scratch/891 对**整个**锥有 \(A|_{\mathscr V_{y,B}}\succeq(1-5\alpha-o(1))H I\)，故 \(d_\sigma<1-5\alpha\) 使消去 \(\mathcal U^{\rm prof,(\sigma)}\) 后的完整锥仍有线性正隙。又 \(F\succeq(2H-C\sqrt H)I\) 且 \(\|F^{-1}C^*\|=O(1)\)，闭形式配方给 (3)。\(\square\)

## 边界

此稿把 scratch/894 的素数块从每槽一个常值方向扩展到每槽全部有限能量轮廓，并保留同一根常值 Schur 首项与完整锥联合正隙。它仍只覆盖经过删点的有限素数槽族及几乎所有有理根，不能控制被删槽、其他物理位置或完整旧奇空间。特别是全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 和 RH 均未由此判定。
