# 全 Farey 阶跃偶极主压缩的统一正谱隙（候选）

此候选已晋级为 [note 804](../notes/804-full-farey-step-dipole-compression-has-uniform-positive-gap.md)；以该 note 为权威版本。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确正权图与有界 Archimedean 压缩、[note 795](../notes/795-full-farey-dipole-archimedean-remainder-is-uniformly-positive.md) 的全 Farey Archimedean 下界，以及 [note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md) 的有序互素对分解与外区谱隙。以下全空间强化尚待异源复核，暂留 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 \(k=p^2\)，沿 note 791 的全部 Farey 偶极空间 \(W_p\) 记
\[
A_W=P_{W_p}A_{p^2,-}P_{W_p}=D_pI-C_p+E_p,\qquad
D_p=2\log p+1-\gamma_E-\log\pi .
\]
令 \(\delta_0=\log(729/512)-\zeta(3)/8\)。则**整个**全 Farey 主压缩满足
\[
\boxed{\quad A_W\succeq
\bigl(1+\gamma_E-\log\pi+\delta_0-o(1)\bigr)I_{W_p}.\quad}\tag{1}
\]
极限常数严格正。这把 note 799 的内区谱隙扩展至所有既约 \(1\le b<a<p\) 的阶跃偶极，以及所有这些偶极的线性组合；不消去 \(W_p^\perp\)。

## 有界势与正图拉普拉斯

设 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)、\(\tau=\log(P/Q)\sim\log H\)。在 \(\ell^2(\mathcal F_P)\) 取正权 \(v_{a/b}=(ab)^{-1/2}\)，记 \(r_x=(C_pv)_x/v_x\)。note 791 式 (14) 精确给
\[
r_{a/b}=2\log P+e(P/a)+e(P/b)-\Lambda(a)\mathbf1_{b=1},
\qquad e(t)=\sum_{n\le t}\frac{\Lambda(n)}n-\log t .
\tag{2}
\]
经典 Mertens 估计给 \(\sup_{t\ge1}|e(t)|<\infty\)，且 \(e(t)\to-\gamma_E\)。定义
\[
L_0=\operatorname{diag}(r)-C_p,\qquad
\widetilde r_{a/b}=r_{a/b}+\Lambda(a)\mathbf1_{b=1}
=2\log P+e(P/a)+e(P/b),\qquad
\widetilde L=\operatorname{diag}(\widetilde r)-C_p .
\tag{3}
\]
精确基态变换给
\[
\langle f,L_0f\rangle
=\frac12\sum_{x,y}C_p(x,y)v_xv_y
\left|\frac{f_x}{v_x}-\frac{f_y}{v_y}\right|^2\ge0 .
\tag{4}
\]
因此 \(\widetilde L=L_0+\operatorname{diag}(\Lambda(a)\mathbf1_{b=1})\succeq0\)。把真实压缩写为
\[
A_W=\widetilde L+\operatorname{diag}(V)+E_p,
\qquad
V_{a/b}=D_p-\widetilde r_{a/b}
=1-\gamma_E-\log\pi+2\log(p/P)-e(P/a)-e(P/b).
\tag{5}
\]
这里 \(V\) 在全部 Farey 点上一致有界。令
\[
I=\{a/b\in\mathcal F_P:a\le Q\},\qquad R=\mathcal F_P\setminus I .
\]
因 \(a>b\)，\(I\) 也即 \(a,b\le Q\)。在 \(I\) 上 \(P/a,P/b\ge P/Q\to\infty\)，故
\[
V_x+\delta_0\ge c_0-o(1),\qquad
c_0=1+\gamma_E-\log\pi+\delta_0>0;
\tag{6}
\]
在 \(R\) 上存在绝对常数 \(M>0\) 使 \(V_x+\delta_0\ge-M\)。note 795 的全空间下界 \(E_p\succeq(\delta_0-o(1))I\) 因而给
\[
\langle f,A_Wf\rangle
\ge\langle f,\widetilde Lf\rangle
+(c_0-o(1))\|f_I\|^2-M\|f_R\|^2 .
\tag{7}
\]

## 外区 Dirichlet 谱隙与内外耦合

note 803 的有序互素对证明把 \(C_p\) 等距压成一个矩阵；该矩阵的同臂部分逐项受单整数乘法矩阵 \(K_P\otimes I+I\otimes K_P\) 支配，跨臂余项有独立范数界。对 \(L=\{1,\ldots,Q\}\)、\(U=\{Q+1,\ldots,P\}\)，其承重块界为
\[
\|K_{UU}\|\ll\sqrt H\log H,\quad
\|K_{LL}\|\le\log Q+O(1),\quad
\|K_{LU}\|\ll\sqrt{H(\tau+1)},\quad
\|B_{\rm cross}\|\ll\log H .
\tag{8}
\]
外区对应的有序点是
\((U\times L)\sqcup(L\times U)\sqcup(U\times U)\)，所以 note 803 已得
\[
\|C_{RR}\|\le H+O(\sqrt H\log H).
\tag{9}
\]
内区对应 \(L\times L\)。单坐标移动不可能从 \(L\times L\) 一步到 \(U\times U\)；它到前两块的矩形范数各至多 \(\|K_{LU}\|\)。把这两个目标块纵向叠合，并加入跨臂余项，得到新的交叉估计
\[
\boxed{\quad
\|C_{RI}\|
\le\sqrt2\|K_{LU}\|+\|B_{\rm cross}\|
\ll\sqrt{H(\tau+1)}+\log H
=O(\sqrt{H\log H}).\quad}
\tag{10}
\]
式 (10) 对约分点的压缩仍成立：若非负矩阵逐项被展开矩阵支配，其矩形算子范数也被支配。

由 (2)--(3)，\(\widetilde r_x=2H+O(1)\) 对全部 \(x\) 一致。故 (9) 给
\[
\widetilde L_{RR}
=\operatorname{diag}(\widetilde r_R)-C_{RR}
\succeq\lambda_p I_R,\qquad
\lambda_p=H-O(\sqrt H\log H)\sim H.
\tag{11}
\]
同时 \(\widetilde L_{RI}=-C_{RI}\)。令
\[
T_p=\widetilde L_{RR}^{-1}C_{RI},\qquad
\eta_p=\|T_p\|\le\frac{\|C_{RI}\|}{\lambda_p}
\ll\sqrt{\frac{\log H}{H}}=o(1).
\tag{12}
\]

## 完成平方

对 \(f=(x,y)\in I\oplus R\)，置 \(z=y-T_px\)。由于 \(\widetilde L\succeq0\)、\(\widetilde L_{RR}\succ0\)，其真 Schur 余量非负，故
\[
\langle f,\widetilde Lf\rangle
\ge\langle z,\widetilde L_{RR}z\rangle
\ge\lambda_p\|z\|^2 .
\tag{13}
\]
又 \(\|y\|^2\le2\|z\|^2+2\eta_p^2\|x\|^2\)，将 (13) 代入 (7) 得
\[
\langle f,A_Wf\rangle
\ge\bigl(c_0-o(1)-2M\eta_p^2\bigr)\|x\|^2
+(\lambda_p-2M)\|z\|^2 .
\tag{14}
\]
另一方面
\[
\|f\|^2\le(1+2\eta_p^2)\|x\|^2+2\|z\|^2 .
\tag{15}
\]
由 \(\eta_p=o(1)\) 与 \(\lambda_p\to\infty\)，(14)--(15) 给 (1)。常数 \(c_0>0\) 已由 note 799 的显式常数界判定。 \(\square\)

## 边界

此证明对全 Farey **阶跃偶极主压缩**给 Loewner 下界，因此涵盖任意 Farey 系数轮廓。它没有证明原旧奇算子在 \(W_p^\perp\) 的正性，也没有上界控制消去该无限维补空间的 Schur 反馈；因此全尺度局部 Weil 正性及 RH 仍未判定。
