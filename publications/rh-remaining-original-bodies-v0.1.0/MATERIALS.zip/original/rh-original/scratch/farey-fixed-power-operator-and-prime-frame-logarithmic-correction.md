# 固定幂 Farey 块族的对数算子界与固定密度负协方差（更正候选）

日期：2026-09-30。更正 [旧整族算子稿](farey-block-operator-cancellation-candidate.md) 及其下游 [固定密度素数框架稿](constant-density-farey-prime-frame-candidate.md) 的量化输入。[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 所核对的 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 1.1(i) 给**任意固定对数幂**节省；它不提供两份旧稿所写的 \(e^{-c(\log Y/\log\log Y)^{1/3}}\)。旧稿依赖该次幂率的结论撤回。本稿给固定 \(4/5<\alpha<1\) 的可证明替代，保留 note 833 的真实 \(\mu\) 系数及物理裁剪。整条证明尚待异源复核，暂存 scratch。

令 \(Y\to\infty\) 沿整数，固定 \(4/5<\alpha<1\)，并置
\[
D=\lfloor Y^\alpha\rfloor,\qquad
B=\left\lfloor\frac{D^2}{1000Y}\right\rfloor,\qquad
L=\lfloor Y^{5/6}\rfloor,\qquad
E_*=\frac{B^2D^2}{Y\log^2D}.
\tag{1}
\]
对 \(q\in(D/2,D]\) 使用 [note 833](../notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md) 式 (1) 的
\(F_{q,N}=-C_q(N)\cos(2\pi N/q)/(\pi N)\)，其中原始倍数截止为 \(kq\le N-L\)。对连续整数块 \(I\subset(D/2,D]\) 记 \(T_{I,N}=\sum_{q\in I}F_{q,N}\)、\(G_{I,N}=\sum_{p\in I,\ p\mathrm{\ prime}}F_{p,N}\)、\(H_I=T_I-G_I\)。
下文复内积约定为 \(\langle U,V\rangle=\sum_{Y<N\le2Y}U_N\overline{V_N}\)。

**候选命题 1（真正的算子量化）。** 对任意两两不交、长度在 \([B/2,B]\) 内的块族 \(\{I_j\}\) 和任意复权 \(w=(w_j)\)，每个固定 \(A>0\) 都有
\[
\boxed{\quad
\left\|\sum_jw_jT_{I_j}\right\|_{\ell^2(Y<N\le2Y)}^2
\ll_{\alpha,A}E_*(\log Y)^{-A}\sum_j|w_j|^2.
\quad}\tag{2}
\]
把整带分成这样的相邻块并令 \(w_j=1\)，得到
\[
\left\|\sum_{D/2<q\le D}F_{q,\cdot}\right\|_2^2
\ll_{\alpha,A}\frac{D^5}{Y^2(\log Y)^A}.
\tag{3}
\]
此处对数指数可任意增大，但 (2)--(3) **没有固定幂节省**。

**候选命题 2（固定密度真实负协方差）。** 存在一个充分大的固定整数 \(s\)，取
\(t_j=\lfloor D/2\rfloor+jsB\)，保留 \(t_j+B\le3D/4\) 的块
\(I_j=(t_j,t_j+B]\)，块数 \(M\asymp_sY/D\)。对同一个复权列 \(w\) 写 \(G_w=\sum_jw_jG_{I_j}\)、\(T_w=\sum_jw_jT_{I_j}\)、\(H_w=T_w-G_w\)。有常数 \(0<c_s<C_s<\infty\)，使
\[
\boxed{\quad
c_sE_*\|w\|_2^2\le\|G_w\|_2^2\le C_sE_*\|w\|_2^2,
\qquad
\operatorname{Re}\langle G_w,H_w\rangle
=-\|G_w\|_2^2+O_{\alpha,s,A}\!\left(\frac{\|G_w\|_2^2}{(\log Y)^A}\right).
\quad}\tag{4}
\]
对 \(w_j=1\)，\(\|G_w\|_2^2\asymp_{\alpha,s}D^5/(Y^2\log^2Y)\)。令 \(T_{\rm band}=\sum_{D/2<q\le D}F_{q,\cdot}\)。式 (3) 还给
\[
\boxed{\quad
\langle G_w,T_{\rm band}-G_w\rangle
=-\|G_w\|_2^2
+O_{\alpha,s,A}\!\left(\frac{\|G_w\|_2^2}{(\log Y)^A}\right).
\quad}\tag{5}
\]
这是固定比例短块组成的素数源与**整个同分子分母带补集**之间的真实负协方差。其大小超过 \(Y^2\) 当 \(\alpha>4/5\)，但完整带 (3) 仍超出目标 \(Y^{2+\varepsilon}\)。

## 1. 任意对数幂的算子界

令 \(f_\kappa(q)=\kappa_q\mu(q)q/\varphi(q)\)，其中奇 \(q\) 的 \(\kappa_q=5\)、偶 \(q\) 的 \(\kappa_q=1\)。note 835 的加权卷积证明给 \(f_\kappa=\mu*h_\kappa\)、\(\sum_d|h_\kappa(d)|d^{-1/2}<\infty\)。本范围的 \(B=D^{\beta+o(1)}\)、\(\beta=2-1/\alpha>3/4\)。在卷积指标 \(d\le D^{1/4}\) 上，长度 \(B/d\) 相对于起点 \(x\asymp D/d\) 满足
\[
\frac{B/d}{x^{5/8+\varepsilon}}
\gg D^{\beta-23/32-3\varepsilon/4+o(1)}\to\infty,
\qquad
\frac{B/d}{x^{1-\varepsilon}}\ll D^{\beta-1+\varepsilon+o(1)}\to0
\tag{6}
\]
（固定取足够小的 \(\varepsilon>0\)）。2023 定理直接控制整个窗口内任意前缀；\(d>D^{1/4}\) 的平凡尾为 \(O(BD^{-1/8}+D^{1/2})\)。短块可嵌入带内的长 \(B\) 块并写成两个前缀之差。因此对每个固定 \(K>0\)，一致于所有 \(I_j\)，
\[
\max_{z\in I_j}\left|\sum_{q\in I_j,\ q\le z}f_\kappa(q)\right|
\ll_{\alpha,K}B/(\log Y)^K.
\tag{7}
\]

先取首阶复相位模型
\[
U_N=\frac1N\sum_jw_j\sum_{q\in I_j}qf_\kappa(q)e(N/q),
\qquad e(x)=e^{2\pi ix}.
\tag{8}
\]
记 \(v_{j,q}=1/q-1/t_j\)；\(|v_{j,q}|\le4B/D^2\)。对 \(m\ge0\)，Abel 求和 (7) 应用于 \(x(1/x-1/t_j)^m\)，给
\[
\left|\sum_{q\in I_j}qf_\kappa(q)v_{j,q}^m\right|
\ll_{\alpha,K}
\frac{BD(m+1)}{(\log Y)^K}
\left(\frac{4B}{D^2}\right)^m.
\tag{9}
\]
左端载波 \(1/t_j\) 两两圆周相距至少 \(B/(2D^2)\asymp Y^{-1}\)。note 762 式 (4) 的固定系数间距界、指数级数、Minkowski 及 \(YB/D^2\le1/1000\) 于是给
\[
\|U\|_2^2
\ll_{\alpha,K}
\frac{B^2D^2}{Y(\log Y)^{2K-1}}\|w\|_2^2.
\tag{10}
\]
对 \(e(-N/q)\) 完全相同，故余弦首阶模型也满足 (10)。

必须保留真实系数的误差。令 \(C_q^{\rm full}(t)\) 把 note 833 的物理截止换成 \(kq<t\)，并置 \(R_q(t)=C_q^{\rm full}(t)+qf_\kappa(q)\)。[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 的一致互素调和界和 note 833 的奇偶式给，在 \(Y\le t\le2Y\)、\(q\asymp D\) 上，
\[
|R_q(t)|+Y|R'_q(t)|\ll_\alpha D\delta_Y,
\quad
\delta_Y=e^{-c_\alpha\omega(Y)}+(D/Y)^2\log\log(3Y),
\quad \omega(Y)=\frac{(\log Y)^{3/5}}{(\log\log Y)^{1/5}}.
\tag{11}
\]
导数几乎处处存在：每个新进入的 \(kq=t\) 项带零对数权，所以 \(R_q\) 绝对连续；导数是相应互素调和部分和除以 \(t\)，外加 \(O((q/t)^2/t)\) 的有理乘子导数。对频率 \(1/q\) 使用 [note 802](../notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md) 式 (4) 的移动权间距引理，其圆周间距至少 \(D^{-2}\)。对正负余弦频率各用一次，得到
\[
\left\|\sum_j\frac{w_j}{\pi N}
\sum_{q\in I_j}R_q(N)\cos(2\pi N/q)\right\|_2^2
\ll_\alpha\frac{BD^4\delta_Y^2\log(2Y)}{Y^2}\|w\|_2^2.
\tag{12}
\]
由于 \(D^2/(BY)\asymp1000\)，式 (12) 相对 \(E_*\) 的倍率为 \(O(\delta_Y^2\log^3Y)\)，小于任意固定对数负幂。

物理裁剪 \(kq\le N-L\) 相对 \(kq<N\) 至多删除 \(L/q+1\) 项。逐项 \(\log(N/kq)\ll L/Y\)、\(k^{-1}\ll q/Y\)，故
\[
|C_q(N)-C_q^{\rm full}(N)|
\ll(qL^2+q^2L)/Y^2
\ll DL(L+D)/Y^2.
\tag{13}
\]
每块至多 \(B\) 个 \(q\)，总块数至多 \(O(D/B)\)；先逐块取绝对值，再对 \(w\) 用 Cauchy--Schwarz，得到裁剪误差均方相对 \(E_*\|w\|_2^2\) 至多
\[
O\!\left(\frac{L^2(L+D)^2\log^2Y}{DY^3}\right)
\ll Y^{-1/3}\log^2Y.
\tag{14}
\]
将 (10)、(12)、(14) 合并并在 (7) 取足够大的 \(K\)，即得任意指定 \(A\) 的 (2)。整带含 \(O(D/B)=O(Y/D)\) 个块，乘上 \(E_*\) 即为 (3)，对数指数再调大两位即可。\(\square\)

## 2. 素数框架与真实负协方差

对命题 2 的块，令 \(A_j=\sum_{p\in I_j}p\)。Heath-Brown 的 \(x^{2/3}\) 素数短区间定理适用于 \(B\gg D^{3/4}\)，故 \(A_j\asymp BD/\log D\) 对所有 \(j\) 一致。频率 \(\{\pm1/t_j\}\pmod1\) 的最小圆周间距 \(\rho\ge sB/D^2\sim s/(1000Y)\)。为直接给出双侧框架，取三角窗
\[
\tau_R(n)=R^{-1}\#\{(u,v):0\le u,v<R,\ u+v=n\}.
\tag{15}
\]
它非负，\(\sum_n\tau_R(n)=R\)，且
\(|\sum_n\tau_R(n)e(n\theta)|\le\min\{R,(4R\|\theta\|^2)^{-1}\}\)。按圆周距离排序，任意一行的非对角绝对和为 \(O((R\rho^2)^{-1})\)。固定选 \(s\) 充分大，使这个量在 \(R\asymp Y\) 时小于 \(Y/10\)。用 \(R=\lfloor Y/2\rfloor\) 的平移三角窗给区间 \((Y,2Y]\) 内的下界，用 \(R=Y\) 且在该区间处处 \(\ge1/3\) 的平移窗给上界，Gershgorin 于是给所有复系数 \(z_{j,\pm}\) 的
\[
cY\sum_{j,\pm}|z_{j,\pm}|^2
\le\sum_{Y<N\le2Y}\left|\sum_{j,\pm}z_{j,\pm}e(\pm N/t_j)\right|^2
\le CY\sum_{j,\pm}|z_{j,\pm}|^2.
\tag{16}
\]
把 \(s\) 取到使 \(Y\rho\ge1000\)，上述行和估计可取 (16) 的下、上系数为 \(2Y/5\)、\(3Y\)。取 \(z_{j,\pm}=w_jA_j/2\)，再用 \(Y<N\le2Y\)，中心余弦模型 \(P_N=\sum_jw_jA_j\cos(2\pi N/t_j)\) 满足
\[
\frac1{20Y}\sum_j|w_jA_j|^2
\le\|P_N/N\|_2^2
\le\frac3{2Y}\sum_j|w_jA_j|^2.
\tag{17}
\]

对 \(p\in I_j\)，\(|1/p-1/t_j|\le4B/D^2\)。展开
\(e(\pm N/p)=e(\pm N/t_j)\sum_{m\ge0}(\pm2\pi iN(1/p-1/t_j))^m/m!\)。第 \(m\) 个矩系数满足 \(|\sum_{p\in I_j}p(1/p-1/t_j)^m|\le A_j(4B/D^2)^m\)。每个矩向量用 (16) 的 \(3Y\) 上界，除以 \(N\ge Y\)，再以 Minkowski 求和，两个指数各给不超过
\[
\sqrt{\frac3Y}\left(e^{16\pi YB/D^2}-1\right)
\left(\sum_j|w_jA_j|^2\right)^{1/2}
<\frac1{10\sqrt Y}\left(\sum_j|w_jA_j|^2\right)^{1/2}.
\tag{18}
\]
余弦误差是两指数误差的半和，也满足 (18)。式 (17) 的下界系数为 \(1/\sqrt{20Y}>1/(10\sqrt Y)\)，故真实素数相位仍有双侧 \(\asymp E_*\|w\|_2^2\) 界。

由 (11)--(12) 限制到素数集，同频误差对任意 \(w\) 的范数是 \(o(\sqrt{E_*}\|w\|_2)\)；(13)--(14) 的裁剪也一样。对素数 \(p\)，\(-pf_\kappa(p)=5p^2/(p-1)=5p+O(1)\)；剩余 \(O(1)\) 系数由 \(\sum_j|w_j|\le\sqrt M\|w\|_2\) 和 \(p\)-数 \(O(B)\) 平凡支付，也是 \(o(\sqrt{E_*}\|w\|_2)\)。所以 \(G_w\) 满足 (4) 左侧双边框架。

式 (2) 对选中块给 \(\|T_w\|_2\ll_{\alpha,s,A}\sqrt{E_*}(\log Y)^{-A}\|w\|_2\)，在 (2) 使用两倍对数指数即可。于是由 \(H_w=T_w-G_w\) 与 Cauchy--Schwarz，得 (4) 的协方差。令 \(w_j=1\)，有 \(M E_*\asymp_sD^5/(Y^2\log^2D)\)。整带上界 (3) 使 \(\|T_{\rm band}\|_2/\|G_w\|_2\ll_{\alpha,s,A}(\log Y)^{-A}\)，再次展开 \(\langle G_w,T_{\rm band}-G_w\rangle\)，得到 (5)。\(\square\)

## 剩余算术门

本稿把旧次幂表述修正为文献真正支持的任意对数幂，并保持固定密度素数源的全带负协方差。其正能量 \(D^5/(Y^2\log^2Y)\) 在 \(D=Y^\alpha\)、\(\alpha>4/5\) 时高于 \(Y^2\)，而 (3) 仍只有对数节省。要完成 moving-\(N\) 门，必须证明固定幂节省或更强的跨带、跨分子真实 signed cancellation；(2)--(5) 均不提供它。全尺度局部 Weil 正性和 RH 仍未判定。
