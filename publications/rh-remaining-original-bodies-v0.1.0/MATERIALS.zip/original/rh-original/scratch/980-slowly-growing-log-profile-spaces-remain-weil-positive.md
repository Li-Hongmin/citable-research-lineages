# 缓慢增长的整数对数轮廓空间仍保持 Weil 正性

日期：2026-10-03。依赖 [scratch 978](978-macroscopic-log-profiles-have-rank-one-weil-limit.md) 的 BV 误差方法、[scratch 979](979-fixed-valuation-and-macroscopic-profiles-have-positive-weil-compression.md) 的固定赋值常数块，以及 [notes 859](../notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md)、[858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的严格谱隙。本稿为解析证明草稿，尚未异源复核；它不证明全尺度 Weil 正性、moving-\(N\) 协方差门或 RH。

## 命题

固定 \(0<\theta<1\)、非负实单位轮廓
\(\varphi\in C_c^\infty((-1/2,1/2))\)，以及 scratch 979 中的有限素数赋值空间
\(\mathcal E_B\)。仍令
\[
H=\log p,\quad N=\lfloor p^2/2\rfloor-1,\quad L=\log N,\quad
\ell=2\theta/p^2
\]
沿奇素数 \(p\to\infty\)，并使用该稿式 (1) 的线性槽映射
\(\mathcal T_N\)。

对每个 \(p\)，令 \(V_p\subset\mathrm{BV}([0,1])\) 是包含常数 \(1\)
的实线性空间，其到 \(L^2[0,1]\) 的映射单射；可以令维数随 \(p\) 增长。
定义
\[
K_p=\sup_{0\ne f\in V_p}
\frac{\|f\|_\infty+\operatorname{Var}_{[0,1]}f}{\|f\|_{L^2[0,1]}}.
\tag{1}
\]
若 \(K_p=o(\sqrt L)\)，则充分大 \(p\) 时，真实局部 Weil 形式在
\(\mathcal T_N(\mathcal E_B\otimes V_p)\) 上严格为正。
更具体地，把任意
\(u\in\mathcal E_B\otimes V_p\) 唯一写为
\[
u(x)=F+w(x),\qquad F=\int_0^1u(x)\,dx,\qquad
\int_0^1w(x)\,dx=0.
\]
记 \(\|w\|_2^2=\int_0^1\|w(x)\|_B^2dx\)。则充分大 \(p\) 时一致有
\[
\boxed{\quad
Q_W^H[\mathcal T_Nu]\ge
\frac{\delta}{2}\|F\|_B^2+\frac L2\|w\|_2^2,\qquad
\delta=\frac{46}{25}-\log(2\pi)>0.
\quad}\tag{2}
\]
此外，物理范数满足
\(\|\mathcal T_Nu\|_{L^2}^2=(1+o(1))\|u\|_2^2\)，误差对整个随
\(p\) 变化的空间一致。因此其最低 Rayleigh 商最终至少为
\(\delta/2+o(1)\)。更精确地，恰有 \(\dim\mathcal E_B\) 个低
Rayleigh 本征值收敛到 scratch 979 式 (4) 的正算子本征值；
其余本征值一致为 \(L(1+o(1))\)。

一个明确的增长族是
\[
V_p=\operatorname{span}_{\mathbb R}
\{1,\cos(2\pi jx),\sin(2\pi jx):1\le j\le r_p\},
\qquad r_p=o(\sqrt{\log N}).
\tag{3}
\]
所以即使对数尺度 Fourier 模数无界增长，(3) 的整个张量压缩仍严格为正。

## 证明

先保留 scratch 979 首阶推导中的 BV 范数，而不使用固定空间
\(V\) 上的范数等价。对任何 \(F,G\in\mathcal E_B\) 与
\(f,g\in\mathrm{BV}([0,1])\)，固定模数的同余类调和计数给
\[
\sum_{n\le e^t}\frac{F(\boldsymbol\nu(n))G(\boldsymbol\nu(n))}{n}
=\langle F,G\rangle_Bt+
O_B(\|F\|_B\|G\|_B)\qquad(t\ge0).
\tag{4}
\]
素数 \(q\notin B\) 的素数幂测度满足
\(\sum_{q^a\le e^t,q\notin B}(\log q)q^{-a}
=t+O_B(1)\)。对内外两层依次作 Stieltjes 分部积分，正如
scratch 978 式 (7)--(10)。写 \(x_n=\log n/L\)，第一层给
\[
\sum_{\substack{k\le N/n\\ k=q^a,\ q\notin B}}
 \frac{\Lambda(k)}k\,g(x_n+\log k/L)
=L\int_{x_n}^1g(y)\,dy+O_B(\|g\|_{\rm BV}).
\]
第二层对
\(h(x)=f(x)\int_x^1g(y)dy\) 使用 (4)，并用
\(\|h\|_{\rm BV}\ll\|f\|_{\rm BV}\|g\|_{\rm BV}\)，得到一侧
整除边的未归一化主项
\[
L^2\langle F,G\rangle_B\int_0^1 f(x)\int_x^1g(y)\,dy\,dx
+O_B(L\|F\|_B\|G\|_B\|f\|_{\rm BV}\|g\|_{\rm BV}).
\]
另一侧边给反向三角积分；两者合并、再除以
\(L_N=L+O(1)\)，恰是 (5) 中的秩一 prime 主项及有界误差。
式 (4) 的有界累计误差每层只付出测试函数的上确界与总变差。
有限个 \(q\in B\) 的整除边按
\(\sum_{q\in B}\sum_{a\ge1}(\log q)q^{-a}<\infty\) 取绝对值。
单槽项与 scratch 978 相同；普通跨槽核及两个极点矩可由自然权
绝对和乘 \(\|f\|_\infty\|g\|_\infty\) 支付。由于
\(\mathcal E_B\) 固定有限维，所有系数的上确界受其
\(\pi_B\)-范数控制。故有与 \(p,f,g\) 无关的 \(C_B>0\)，使
\[
\begin{aligned}
\left|\langle\mathcal T_N(F,f),\mathcal T_N(G,g)\rangle
 -\langle F,G\rangle_B\int_0^1fg\right|
&\le {C_B\over L}\|F\|_B\|G\|_B\|f\|_{\rm BV}\|g\|_{\rm BV},\\
\left|Q_W^H(\mathcal T_N(F,f),\mathcal T_N(G,g))
 -L\langle F,G\rangle_B
 \left(\int_0^1fg-\int_0^1f\int_0^1g\right)\right|
&\le C_B\|F\|_B\|G\|_B\|f\|_{\rm BV}\|g\|_{\rm BV}.
\end{aligned}\tag{5}
\]
这正是 scratch 979 式 (2)--(3) 的**全 BV 一致版本**；常数
\(C_B\) 也依赖固定的 \(\theta,\varphi\)。

在 \(\mathcal E_B\) 取固定正交基，将 (5) 对各坐标相加。若
\(\|u\|_2^2=\int\|u(x)\|_B^2dx\)，则对
\(\mathcal E_B\otimes V_p\) 的任意向量，(1) 与有限坐标数给
\[
\bigl|\|\mathcal T_Nu\|_{L^2}^2-\|u\|_2^2\bigr|
\le C_BK_p^2L^{-1}\|u\|_2^2.
\tag{6}
\]
这证明槽映射最终单射及所述物理范数等价。

对常数块，scratch 979 式 (4)--(5) 给一个固定的正二次型
\(\mathscr L_B\)，满足
\[
Q_W^H[\mathcal T_N(F,1)]
=\mathscr L_B(F)+o(1)\|F\|_B^2,\qquad
\mathscr L_B(F)\ge\delta\|F\|_B^2.
\tag{7}
\]
式 (5) 的首阶算子是 \(L(I-P_{\mathbf1})\)。由于 \(w\) 的均值为零，
其高块与低高交叉分别满足
\[
Q_W^H[\mathcal T_Nw]\ge(L-C_BK_p^2)\|w\|_2^2,\qquad
|Q_W^H(\mathcal T_N(F,1),\mathcal T_Nw)|
\le C_BK_p\|F\|_B\|w\|_2.
\tag{8}
\]
这里 \(w\) 的每个坐标都在 \(V_p\)，所以 (1) 可逐坐标应用。
对充分大 \(p\)，(7) 的第一项至少为
\(3\delta\|F\|_B^2/4\)。由
\[
2C_BK_p\|F\|_B\|w\|_2
\le {\delta\over4}\|F\|_B^2
+{4C_B^2K_p^2\over\delta}\|w\|_2^2
\]
以及 \(K_p^2=o(L)\)，得到 (2)。
在连续系数内积下，高块为 \(LI+O_B(K_p^2)\)，低高交叉为
\(O_B(K_p)\)，低块由 (7) 收敛到 \(\mathscr L_B\)。对任意有界谱参数，
高块的逆为 \(O(L^{-1})\)，故低块 Schur 修正为
\(O_B(K_p^2/L)=o(1)\)。低块维数固定，于是恰有
\(\dim\mathcal E_B\) 个有界本征值收敛到 \(\mathscr L_B\) 的谱；
其余均为 \(L(1+o(1))\)。由 (6)，物理 Gram 是
\(I+O_B(K_p^2/L)\)；同一广义特征值论证给出所述物理
Rayleigh 本征值结论。

最后，对 (3) 的三角多项式，Cauchy--Schwarz 给
\(\|f\|_\infty\le\sqrt{2r_p+1}\|f\|_2\)，而 Parseval 给
\(\operatorname{Var}f\le\int_0^1|f'|
\le2\pi r_p\|f\|_2\)。故
\(K_p\le\sqrt{2r_p+1}+2\pi r_p=o(\sqrt L)\)。\(\square\)

## 边界

本命题是**受限整数槽压缩**的增长复杂度定理；其条件约束整个
\(V_p\) 的 BV 到 \(L^2\) 嵌入常数，并非只约束单个候选向量。
它既不控制槽外补空间的 true-Schur 扣款，也不估计 note 849
式 (15) 的真实素数、倍素数、Möbius signed covariance。
