# 每个五分之一次幂以下有理锥仍漏出线性素数列（待异源复核）

日期：2026-10-01。依赖 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 的锥定义与正隙、[scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的实尺度原槽，以及 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md)、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的旧奇闭形式和平移约定。[note 775](../notes/775-a-prime-source-has-logarithmic-arithmetic-coupling-to-the-complement.md) 已对另一 source 投影证明对数级泄漏；这里直接判定 scratch/891 的每个正锥到其正交补的算术列是否可当作 \(o(\log X)\) 扰动。结果是候选证明，尚无异源复核；它不估计补空间逆或 RH。

## 命题

沿用 scratch/891 的 \(X\to\infty\)、\(H=\log X\)、\(k=X^2\)、\(w=\tfrac12\log(1+X^{-2})\)、每个 \(y\in\mathcal G_X^\circ\) 及任意整数 \(1\le B\le X^{1/5}\)。以 \(e_{y,1}\) 表示根的单位常值奇槽，\(\mathscr V_{y,B}\) 表示包含全部槽内有限能量轮廓的有理锥。

存在由真正素数槽组成、与 \(\mathscr V_{y,B}\) 正交的有限维空间 \(W_{y,B}\)，其正交单位基记为 \(e_{p/y}\)，使真实旧奇 Weil 闭形式满足，对全部 \(y,B\) 一致地
\[
\boxed{\quad
\sup_{\substack{g\in W_{y,B}\\\|g\|_2=1}}
|A_{X^2,-}[e_{y,1},g]|
=\left(\sqrt{\frac{11}{32}}+o(1)\right)H.
\quad}
\tag{1}
\]
因此即使 scratch/891 的锥压缩对每个固定 \(B\le X^\alpha,\ \alpha<1/5\) 有线性正隙，锥到其完整正交补的**形式交叉范数**仍至少为 \((\sqrt{11/32}+o(1))H\)。式 (1) 本身既不是 Schur 扣款下界，也不判定完整旧奇算子的符号。

## 素数槽与锥的分离

令
\[
\mathcal P_X=\{p\text{ 为素数}:X^{5/4}\le p\le X^{3/2}\},
\qquad z_p=p/y.
\tag{2}
\]
对充分大 \(X\)，由 \(X/8<y<X/2\) 有 \(2X^{1/4}<z_p<8X^{1/2}<X\)。以 \(\log(Xz_p)\) 为中心取长度 \(w\) 的上臂槽及奇反射，单位常值向量记为 \(e_{z_p}\)。不同 \(p,q\in\mathcal P_X\) 满足
\[
|\log(p/q)|\gg X^{-3/2}\gg w,
\]
所以所有 \(e_{z_p}\) 正交且范数为一；它们的阶跃轮廓有有限旧形式能量。

若 \(e_{z_p}\) 与锥的 \(r=a/b\ge5,\ b\le B\) 槽相交，则
\[
\left|\log\frac{pr}{y^2}\right|<w.
\tag{3}
\]
固定 \(r\)，允许的整数 \(p\) 落在 \((y^2e^{-w}/r,y^2e^w/r)\)，其长度小于 \(1/(4r)<1\)，故至多一个。式 (3) 又强迫 \(r\ll X^{3/4}\)，而这类既约标签的总数至多
\[
\sum_{b\le B}O(bX^{3/4})=O(B^2X^{3/4}).
\tag{4}
\]
根 \(r=1\) 与所有 \(z_p\) 相距至少 \(\tfrac14H-O(1)\)，无需删除。

还须删除可能与根的**另一**素数幂平移重合的 \(p\)。若一个 \(s\le y\) 的整数素数幂使根的下降臂碰到 \(e_{z_p}\)，则
\[
\left|\log\frac{ps}{y^2}\right|<w.
\tag{5}
\]
这里 \(s\ll X^{3/4}\)；固定整数 \(s\)，允许的整数 \(p\) 区间长度小于 \(1/(4s)<1\)，故这种 \(p\) 至多 \(O(X^{3/4})\) 个。根的上臂向外平移只能使用 \(s<X/y=O(1)\)，其上臂物理点 \(Xsy\asymp X^2\)，与目标上臂物理点 \(Xz_p\ll X^{3/2}\) 不相交。

令 \(\mathcal P_{y,B}^\circ\) 为删去 (3) 或 (5) 的素数后的集合，置
\[
W_{y,B}=\operatorname{span}\{e_{z_p}:p\in\mathcal P_{y,B}^\circ\}.
\tag{6}
\]
式 (3)--(4) 说明 \(W_{y,B}\perp\mathscr V_{y,B}\)，对该锥的**任意**有限能量轮廓成立；(5) 则使下节的算术根列只有一项。

## 真算术列与其平方质量

在对数坐标中，旧算术项为
\[
\mathcal R_k=-\sum_{s\text{ 素数幂}}
\frac{\Lambda(s)}{\sqrt s}(T_s+T_s^*).
\]
根的上、下臂分别带正、负号。对 \(p>y\)，\(T_p\) 把根上臂移到目标下臂，\(T_p^*\) 把根下臂移到目标上臂；两次半权配对都带正号。因此对 \(p\in\mathcal P_{y,B}^\circ\)，由 (5) 排除的其他下降平移及上节的向外平移之外，精确有
\[
\mathcal R_k[e_{y,1},e_{z_p}]
=\frac{\log p}{\sqrt p}.
\tag{7}
\]
其余 \(s>y\) 若也碰到这个槽，必须 \(|\log(s/p)|<w\)；允许的整数 \(s\) 区间长 \(p(e^w-e^{-w})\ll X^{-1/2}<1\)，故只能 \(s=p\)。槽宽保持不变，所以 (7) 没有轮廓截断误差。

素数定理的 Stieltjes 分部求和给
\[
\sum_{p\in\mathcal P_X}\frac{(\log p)^2}{p}
=\left(\frac{11}{32}+o(1)\right)H^2.
\tag{8}
\]
每个被删除的 \(p\ge X^{5/4}\) 对该和至多贡献 \(O(H^2X^{-5/4})\)；由 (4)--(5) 及 \(B\le X^{1/5}\)，删除总质量至多
\[
O\!\left(H^2X^{-5/4}(B^2X^{3/4}+X^{3/4})\right)
=O(H^2X^{-1/10})=o(H^2).
\tag{9}
\]
因此 (8) 对 \(\mathcal P_{y,B}^\circ\) 仍一致成立。

## 非算术列

根与目标的同臂对数距离至少 \(\tfrac12H-O(1)\)，异臂距离至少 \(\tfrac54H-O(1)\)。相离 Archimedean 核 \(K(d)=e^{-d/2}/(1-e^{-2d})\) 使每个归一化槽交叉至多 \(O(w e^{-H/4})\)；即使以 \(|\mathcal P_X|\le X^{3/2}\) 的平凡界求 \(\ell^2\)，整列仍为 \(o(1)\)。

奇 polar 向量 \(s_k(u)=\sinh((u-H)/2)\) 满足
\[
|\langle s_k,e_{y,1}\rangle|^2\ll wy\ll X^{-1},
\qquad
\sum_{p\in\mathcal P_{y,B}^\circ}
|\langle s_k,e_{z_p}\rangle|^2
\ll w\sum_{p\le X^{3/2}}\frac p y=O(1).
\]
所以负秩一 polar 的根列也为 \(O(X^{-1/2})=o(1)\)。由 (7)--(9)，真实 \(A_{X^2,-}\) 的 \(W_{y,B}\) 根列平方范数为 \((11/32+o(1))H^2\)。其基正交，逆用 Cauchy--Schwarz 取最大配对即得 (1)。\(\square\)

## 边界

式 (1) 只排除以 \(o(H)\) 交叉范数把 scratch/891 的正锥直接接到完整旧空间的方法。即使交叉列为 \(H\) 级，补空间也可能有足够正的能量支付 Schur 扣款；这里没有对它求逆或推断负谱。它也不改善 moving-\(N\) Möbius signed covariance 的目标均方界。
