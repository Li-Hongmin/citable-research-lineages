# 每个 Farey 分母纤维的半对数 Weil 谱隙与跨分母承重（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 式 (4)、(6)、(7)。本稿给出直接正权证明；写入永久 note 前须异源复核。

## 陈述

沿奇素数 \(p\to\infty\)，令 \(k=p^2\)、\(H=\log p\)、\(L=2H\)。对 \(1\le b<p\)，设
\[
\mathcal F_p(b)=\{a/b:b<a<p,\ (a,b)=1\},\qquad
W_p(b)=\operatorname{span}\{w_{a/b}:a/b\in\mathcal F_p(b)\}.
\]
空纤维不参与谱值陈述。存在与 \(p,b\) 无关的常数 \(C\)，使每个非空纤维满足
\[
\boxed{\quad P_{W_p(b)}A_{p^2,-}P_{W_p(b)}\succeq (H-C)I.\quad} \tag{1}
\]
对每个固定 \(b\ge1\)，并有
\[
\boxed{\quad
\lambda_{\min}\bigl(P_{W_p(b)}A_{p^2,-}P_{W_p(b)}|_{W_p(b)}\bigr)
=H+O_b(1).\quad} \tag{2}
\]
将 note 791 的 \(C_p\) 分解为同分母块对角矩阵 \(C_p^{\parallel}\) 和跨分母矩阵 \(C_p^{\times}\)，则
\[
\|C_p^{\parallel}\|=H+O(1),\qquad
\|C_p^{\times}\|\ge H-O(1). \tag{3}
\]
若归一化 \(u_p\in W_p\) 的真实 Weil Rayleigh 值 \(\langle u_p,A_{p^2,-}u_p\rangle\) 有界，则
\[
\langle u_p,C_p^{\times}u_p\rangle\ge H-O(1). \tag{4}
\]
因此任何使完整 Farey 主压缩达到临界常数量级的向量都必须使用跨分母边。(1) 特别覆盖 [scratch 842](842-three-generation-squarefree-farey-graph-has-a-hermite-gap-candidate.md) 的分母 \(3\) 平方自由图及其任意后代；第四代 Hermite 粗界失效不代表真实第四代失去正谱隙。

## 证明

记 \(c_t=\Lambda(t)/\sqrt t\)（仅对整数素数幂非零），\(M(t)=\sum_{q^r\le t}(\log q)/q^r\)。note 791 使用的经典 Mertens 估计给出
\[
M(t)=\log t+O(1)\qquad(t\ge1), \tag{5}
\]
其中常数绝对。由 note 791 式 (4)，在固定分母 \(b\ge2\) 内，\((a/b)(a'/b)=aa'/b^2\) 因 \((aa',b)=1\) 而不是整数，故算术边只有比值 \(a/a'\) 为整数素数幂的情况。以正权 \(v_a=a^{-1/2}\) 检验。加边 \(a\mapsto aq^r<p\) 须 \(q\nmid b\)，其加权行贡献为 \((\log q)/q^r\)；删边 \(a\mapsto a/q^r>b\) 的贡献为 \(\log q\)。故精确地
\[
\frac{(C_p^{(b)}v)_a}{v_a}
=\sum_{\substack{q^r\mid a\\a/q^r>b}}\log q
+\sum_{\substack{q^r\le(p-1)/a\\q\nmid b}}\frac{\log q}{q^r}
\le \log a+M((p-1)/a)
\le H+O(1). \tag{6}
\]
第一和不超过 \(\sum_{q\mid a}v_q(a)\log q=\log a\)。对 \(b=1\)，比值边仍满足 (6) 的上界；另有乘积边，仅当 \(a=q^r\) 且 \(a'=q^s\) 同为某一素数的幂才出现。其对正权行比的总贡献（包括可能的自环）为
\[
\sum_{\substack{s\ge1\\q^s<p}}
c_{q^{r+s}}\frac{v_{q^s}}{v_{q^r}}
=\sum_{\substack{s\ge1\\q^s<p}}\frac{\log q}{q^s}
\le\frac{\log q}{q-1}=O(1). \tag{7}
\]
比值边和乘积边即便通往同一节点也按 note 791 的矩阵定义相加；(7) 因此没有漏掉重边。所有 \(C_p^{(b)}\) 对称、逐项非负，正权 Schur 检验由 (6)--(7) 得
\[
\|C_p^{(b)}\|\le H+O(1) \tag{8}
\]
且常数与 \(b\) 无关。note 791 式 (6) 在整个 \(W_p\) 上给 \(A_{p^2,-}=D_kI-C_p+E_p\)，其中 \(D_k=L+O(1)\)、\(\|E_p\|=O(1)\)。将其压缩到纤维即得 (1)。

为证明固定 \(b\) 的匹配上界，取固定 \(a_0=b+1\)，并令
\[
\mathcal N_{p,b}=\{n\ge1:(n,b)=1,\ a_0n<p\},
\qquad Q=(p-1)/a_0.
\]
对应 \(a_0n/b\) 构成纤维的诱导子图。记其仅含比值边的矩阵为 \(C_{\mathcal N}^{\mathrm{ratio}}\)；当 \(b\ge2\) 时它就是全部诱导矩阵，当 \(b=1\) 时它是逐项非负的子矩阵。对正权 \(z_n=n^{-1/2}\)，直接计数得到逐行恒等式
\[
\frac{(C_{\mathcal N}^{\mathrm{ratio}}z)_n}{z_n}
=\log n+M_b(Q/n),\qquad
M_b(t)=\sum_{\substack{q^r\le t\\q\nmid b}}\frac{\log q}{q^r}. \tag{9}
\]
这里删去 \(q^r\mid n\) 的每条边贡献 \(\log q\)，加上 \(q^r\) 的每条边贡献 \((\log q)/q^r\)；因 \((n,b)=1\)，所有这些目标仍在子图。对固定 \(b\)，从 (5) 减去有限个 \(q\mid b\) 的几何级数可得 \(M_b(t)=\log t+O_b(1)\)，对所有 \(t\ge1\) 一致。因此 (9) 为 \(\log Q+O_b(1)=H+O_b(1)\)。以 \(z\) 作 Rayleigh 向量得到 \(\lambda_{\max}(C_p^{(b)})\ge H-O_b(1)\)；与 (8) 合并，\(\lambda_{\max}(C_p^{(b)})=H+O_b(1)\)。对 \(b=1\)，子图多出的乘积边非负，故同一下界仍成立。再使用 \(\|E_p\|=O(1)\) 得 (2)。

各分母纤维互相正交，故 (8) 给 \(\|C_p^{\parallel}\|\le H+O(1)\)，而固定 \(b=1\) 的下界给反向不等式。note 791 式 (7) 给 \(\|C_p\|=L+O(1)\)；三角不等式遂给 (3)。最后若 \(\|u_p\|=1\) 且 \(\langle u_p,A_{p^2,-}u_p\rangle=O(1)\)，则
\[
\langle u_p,C_pu_p\rangle
=D_k+\langle u_p,E_pu_p\rangle
-\langle u_p,A_{p^2,-}u_p\rangle
=L+O(1).
\]
减去 \(\langle u_p,C_p^{\parallel}u_p\rangle\le H+O(1)\) 得 (4)。\(\square\)

## 边界

同分母纤维自身有严格正谱隙，跨分母边对完整 Farey 临界向量的算术贡献至少为半个主对数。这不控制跨分母边的符号结构、完整旧奇算子的 Schur 反馈、moving-\(N\) Möbius signed covariance，也不证明 RH。
