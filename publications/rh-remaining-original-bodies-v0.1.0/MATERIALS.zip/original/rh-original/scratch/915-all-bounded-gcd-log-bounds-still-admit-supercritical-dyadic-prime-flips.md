# 全部有界 gcd 筛选的对数界仍容许超目标 dyadic 素数翻转

日期：2026-10-02。依赖 [scratch/914](914-every-bounded-gcd-mask-has-full-band-logarithmic-cancellation.md) 的任意 gcd 筛选全带通对数界、[scratch/904](904-window-exact-multiplicative-prime-flips-defeat-the-post-h3-gate.md) 的高素数集合，以及 [scratch/910](910-dyadic-frame-and-local-convolution-still-admit-supercritical-prime-flip-models.md) 的两个非真实 dyadic 模型及其超目标能量。下面是对**这组新假设**的反模型定理，不是实际 Möbius 门的反例，也不反驳 RH。仍留在 scratch，尚未异源复核。

## 命题

固定非负、非零的实函数 $\psi\in C_c^3((1,2))$，置 $\phi(u)=\psi(u)/u$。取 scratch/860 的 $v=\chi_s^2$，故 $v\ge0$、支撑于 $1/2\le|u|\le4$、在 $1\le|u|\le2$ 等于 $1$。沿偶整数 $M=2Y\to\infty$，令 $H=\lceil Y^{1/5}\rceil$、$\delta_M=e^{-\sqrt{\log M}}$，并写
\[
J_H(r)=\sum_hv(h/H)e(-hr/M),\qquad
a_f(m)=\frac{\widetilde c_f(m)}M\phi(m/M),
\tag{1}
\]
其中 $\widetilde c_f$ 是 scratch/910 式 (1) 中使用**真实** $\Lambda$ 与乘法函数 $f$ 的观察系数，窗外置零。存在两个不同于 $\mu$ 的平方自由支撑乘法函数 $f_{10},f_{11}$，取值于 $\{0,\pm1\}$，满足：

1. 它们在 $n\le M$ 等于 $\mu$；$f*\log=\Lambda$ 在 $n<2M$ 精确成立；$\widetilde c_f$ 的 dyadic 两行恒等式及其有限倍数关系逐点成立，如 scratch/910 所证。
2. 对**任意**可随 $M,H$ 变化的 $F:\mathbb N\to\mathbb C$、$|F(g)|\le1$，以及每个固定 $A>0$，二者都满足
   \[
   \boxed{\quad
   \left|\sum_{m,n}F((m,n))a_f(m)a_f(n)J_H(m-n)\right|
   \ll_{A,s,\psi}(\log M)^{-A}.
   \quad}\tag{2}
   \]
   隐常数对两个模型与全部 $F$ 一致。
3. 二者中至少有一个却满足
   \[
   \boxed{\quad
   \sum_hv(h/H)\left|\sum_ma_f(m)e(-hm/M)\right|^2
   \gg_{s,\psi}\frac{\delta_M^2}{\log^2M}
   \gg\frac{H^4}{M}.
   \quad}\tag{3}
   \]

因此，即使给出完整带通上**全部移动 gcd 筛选**的任意对数幂估计，并加入窗口内的卷积关系和全部 dyadic 线性框架，仍不能从这些资料统一推出 $H^4/M$ 固定幂界。该反模型在翻转素数 $p\in(M,2M)$ 的下一尺度违反 $\Lambda(2p)=(f*\log)(2p)$；真实 $f=\mu$ 满足这条全域关系。式 (2) 绝不表示实际目标 (3) 失败。

## 证明

取 scratch/904 式 (9)--(10) 的不交高素数集 $S_1,S_2\subset(M,2M)$。它们各有 $|S_j|\asymp_\psi\delta_M M/\log M$ 个元素。按 scratch/910 定义 $f_{10}$ 为在 $S_1$ 翻转素数值、$f_{11}$ 为在 $S_1\cup S_2$ 翻转素数值的乘法函数，其余素数值取 $-1$，高次素数幂取零。scratch/910 已逐点证明第一项，并因 $S_2$ 在同一观察频率 $h_0$ 上相干而证明第三项：两模型的 Fourier 包之差在该频率的模长至少为 $\gg\delta_M/\log M$，由三角不等式和 $v(h_0/H)=1$ 得 (3)。这些结论对当前 $v=\chi_s^2$ 适用，因为证明只使用上述支撑、非负性和平台条件。

证明 (2) 只需定量稳定性。在物理窗 $M<m<2M$，scratch/910 式 (5)--(6) 与 scratch/904 式 (11) 给
\[
\widetilde c_f(m)-c_\mu(m)
=-8(\log2)\mathbf1_{S_f}(m),
\qquad S_{f_{10}}=S_1,\quad S_{f_{11}}=S_1\cup S_2.
\tag{4}
\]
置 $a=a_\mu$、$d=a_f-a$。由 $|S_f|\ll_\psi\delta_M M/\log M$，有
\[
\|d\|_1\ll_\psi\frac{\delta_M}{\log M},
\qquad \|d\|_\infty\ll_\psi M^{-1},
\qquad \|a\|_\infty\ll_\psi\frac{\log M}{M}.
\tag{5}
\]
因 $\phi$ 紧支撑，所有非零配对满足 $|m-n|\le(1-\kappa_\psi)M$。scratch/868 式 (6) 在 $q=1$ 时给非对角绝对核行和 $O_{s,\psi}(M)$，而 $|J_H(0)|\ll_s H\ll M$；所以
\[
\sup_{m\in\operatorname{supp}(a)\cup\operatorname{supp}(d)}\sum_{n:\,a_n\ne0}|J_H(m-n)|\ll_{s,\psi}M,
\quad
\sup_{m\in\operatorname{supp}(a)\cup\operatorname{supp}(d)}\sum_{n:\,d_n\ne0}|J_H(m-n)|\ll_{s,\psi}M.
\tag{6}
\]
两式都只在同一紧支撑物理窗口内使用；第二式的 $n$ 集合是该窗口的子集。将 $a_f=a+d$ 展开，对任意 $|F|\le1$ 逐项取绝对值，用 (5)--(6) 得
\[
\begin{aligned}
|G_F[a_f]-G_F[a]|
&\le 2\sum_m|d_m|\sum_n|a_nJ_H(m-n)|
  +\sum_m|d_m|\sum_n|d_nJ_H(m-n)|\\
&\ll_{s,\psi}\|d\|_1\bigl(M\|a\|_\infty+M\|d\|_\infty\bigr)
\ll_{s,\psi}\delta_M.
\end{aligned}\tag{7}
\]
其中 $G_F[x]=\sum_{m,n}F((m,n))x_mx_nJ_H(m-n)$；$F$ 是否复值不影响绝对估计。scratch/914 式 (3) 已给真实 $a=a_\mu$ 的 $\sup_{|F|\le1}|G_F[a]|\ll_A(\log M)^{-A}$。因为 $\delta_M=o_A((\log M)^{-A})$ 对每个固定 $A$，式 (7) 蕴含 (2)。$\square$

## 决策边界

全体 gcd 筛选的对数相消是稳定的一阶资料；它对 $M^{-o(1)}$ 级、却大于 $H^4/M$ 的高素数扰动失明。继续增添这类筛选不会排除本模型。下一项能改变路线的真实算术观测必须在使用同一 signed Gram 的同时具体利用窗外 $\Lambda(2p)=0=(\mu*\log)(2p)$ 的耦合，或者给出别的固定幂二点机制；单纯增加 dyadic 线性恒等式已由 scratch/910 排除。

后续 [scratch/916](916-prime-flip-impulse-response-and-sharp-observation-delay.md) 给出这条卷积约束的精确脉冲响应：$\Lambda(2p)=0$ 只逐点排除翻转，而联合观察 $c$ 在 $2p$ 对卷积缺陷完全失明，直到 $3p$ 才再次可见。因此不能把该约束本身当作单窗 Gram 的负交叉估计；所需固定幂二点界仍须另证。
