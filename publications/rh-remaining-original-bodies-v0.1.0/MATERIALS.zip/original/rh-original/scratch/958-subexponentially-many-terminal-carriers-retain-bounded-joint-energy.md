# 次指数多条物理末带载波仍保持一管量级的联合能量

日期：2026-10-02。依赖 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的真实物理末带核、[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的已核对 Ramachandra 短和，以及 [scratch 951](951-the-entire-coprime-two-arm-gram-has-subexponential-signed-cancellation.md) 式 (3) 的增长互素模数短和引理。此稿把 [scratch 957](957-a-growing-equal-weight-terminal-carrier-family-has-bounded-joint-energy.md) 的 $R=o(\log Y)$ 推进到 $R\le e^{cV_Y}$；极限常数与 [scratch 956](956-terminal-carrier-gram-has-exponentially-small-growing-section-eigenvalues.md) 式 (1c) 的固定 Gram 推导相同。承重的 scratch 951 引理和本稿均未异源复核，暂不晋级永久定理。仍未支付完整 moving-$N$ 均方或证明 RH。

## 命题

固定 $0<\gamma<1/4$，令 $H=\lfloor Y^\gamma\rfloor$、$V_Y=(\log Y/\log\log Y)^{1/3}$。存在只依赖 $\gamma$ 的 $c_*>0$，使任意整数函数
\[
 R(Y)\to\infty,\qquad R(Y)\le e^{c_*V_Y}
\tag{1}
\]
及 $h_r=H+r$、$0\le r\le R$ 均满足 [scratch 957](957-a-growing-equal-weight-terminal-carrier-family-has-bounded-joint-energy.md) 式 (2)–(5) 的全部结论，**常数 $C_\infty$ 与 $\kappa_0$ 不变**。特别地，若 $G_r$ 是 note 845 的真实素数源管、$T_r$ 是同管全部互素 Möbius 分母源，置 $A_Y=Y^3/[H^4(\log Y)^4]$，则
\[
 \sum_{3Y/2<N\le8Y/5}\left|\sum_{r=0}^R G_r(N)\right|^2
 =(C_\infty+o(1))A_Y,
\quad
 \sum_{r=0}^R\sum_NG_r(N)^2=(R+1)(\kappa_0+o(1))A_Y,
\tag{2}
\]
\[
 \sup_N\left|\sum_{r=0}^RT_r(N)\right|
 =o\!\left(\frac{Y}{H^2(\log Y)^2}\right).
\tag{3}
\]
相应的不同真实频率源交叉质量与素数源—合数补集交叉质量，分别由展开 (2) 及 scratch 957 式 (4)–(5) 精确给出。本结果仍是一个物理末带子族的 signed cancellation，不是完整斜楔或全尺度 Weil 正性。

## 1. 保留完整相位的素数密度模型

下文所有 $o(1)$ 沿预先选定的 (1) 中 $R(Y)$ 取极限；$O_\gamma$ 常数对 $h\in[H,H+R]$、$a$、$N$ 一致。置 $\ell=\log Y$、$z=N/Y\in[3/2,8/5]$、$A_0=Y/(\pi H^2\ell^2)$。由于 $R=Y^{o(1)}$，有 $R/H\to0$。对 $h<a\le11h/10$，令
\[
 q_0=\frac{aY}{h},\qquad b=\frac{aY}{h^2\ell},\qquad
 t=\lfloor q_0\rfloor,\qquad B=\left\lfloor\frac{t^2}{aY\ell}\right\rfloor.
\tag{4}
\]
则 $t=q_0+O(1)$、$B=b+O(1)$、$B\asymp Y/(H\ell)$。沿用 note 845 式 (7) 的精确有理乘子
\[
 r_a(v)=\frac{4\mathbf1_{2\mid a}}{1-4v^2}-\frac1{1-v^2},
 \qquad c_a=r_a(0)=1+2(-1)^a.
\]
定义不作相位 Taylor 展开的确定性模型
\[
 \mathscr P_h(N)=\operatorname{Re}
 \sum_{h<a\le11h/10}
 \int_{q_0}^{q_0+b}
 \frac{q}{\pi a^2N}\log\frac Nq\,
 r_a\!\left(\frac q{aN}\right)
 e\!\left(\frac{aN}{q}\right)
 \frac{dq}{\log q},
 \qquad e(x)=e^{2\pi ix}.
\tag{5}
\]

固定 $h,a,N$，记 (5) 的非振荡权与相位乘积为 $W(q)$，不含 $1/\log q$。在 $q\in[t,t+B]$ 上，$q\asymp Y$、$a\asymp H$、$N\asymp Y$，故
\[
 \|W\|_\infty+\operatorname{Var}_{[t,t+B]}W\ll_\gamma H^{-2}.
\tag{6}
\]
确实除相位外的因子大小为 $O(H^{-2})$；相位导数 $|\partial_q(aN/q)|\ll H/Y$，乘区间长 $B\ll Y/(H\ell)$ 仅花 $O(1/\ell)$，其余因子的相对变化更小。因而 $W(q)/\log q$ 的上确界加变差为 $O_\gamma(H^{-2}/\ell)$。

把素数和写为 $\sum_{n\in(t,t+B]}\Lambda(n)W(n)/\log n$ 减去 $p^k$、$k\ge2$ 的项。取固定 $7/12<\vartheta<3/5$；note 851 的 Ramachandra 输入对任意前缀给
\[
 \sup_{u\in[t,t+B]}
 \left|\sum_{t<n\le u}(\Lambda(n)-1)\right|
 \ll B e^{-c_0V_Y}+Y^\vartheta.
\tag{7}
\]
离散 Abel、(6) 和单位步长求积把加权和换为 (5) 中同一实际区间的积分，误差每个 $a$ 至多
\[
 O_\gamma\!\left(\frac{B e^{-c_0V_Y}+Y^\vartheta+1}{H^2\ell}
          +\frac{\sqrt Y\ell}{H^2}\right).
\tag{8}
\]
末项来自整个 $q\asymp Y$ 区域内高次素数幂至多 $O(\sqrt Y\ell)$ 的平凡计数上界，乘 $\|W\|_\infty$；用全区间质量作每个 $a$ 的上界虽粗，仍足够。由 (4)，把积分端点从 $t,t+B$ 改为 $q_0,q_0+b$ 只再花 $O(H^{-2}/\ell)$。对 $O(H)$ 个 $a$ 求和，并以 $A_0\asymp B/(H\ell)$ 归一化，得某个固定 $\delta_\gamma>0$ 使
\[
 \sup_{h,N}|G_h(N)-\mathscr P_h(N)|
 \ll_\gamma A_0\left(e^{-c_0V_Y}+Y^{-\delta_\gamma}\right)
 \ll_\gamma A_0e^{-c_1V_Y},
\tag{9}
\]
其中 $0<c_1<c_0$ 固定。多项式误差的两个承重指数分别是
$1-\gamma-\vartheta>0$ 与 $1/2-\gamma>0$；所有对数因子由固定负幂吸收。

## 2. 去掉载波后振幅的有界变差

在 (5) 中以 $q=q_0(1+u/(h\ell))$、$0\le u\le1$ 换元，令 $x=a/h$。得到**精确**分解
\[
 \mathscr P_h(N)=\operatorname{Re}\bigl(e(hz)\mathcal B_h(z)\bigr),
 \qquad \mathcal B_h(z)=\sum_{h<a\le11h/10}\mathcal B_{h,a}(z),
\tag{10}
\]
其中
\[
 \begin{aligned}
 \mathcal B_{h,a}(z)=\frac{Y}{\pi h^3z\ell}
 \int_0^1&\frac{(1+s)\log[z/(x(1+s))]}{\log[xY(1+s)]}
 r_a\!\left(\frac{1+s}{hz}\right)\\
 &\times e\!\left(\frac{hz}{1+s}-hz\right)du,
 \qquad s=\frac{u}{h\ell}.
 \end{aligned}
\tag{11}
\]
此处相位余差精确为
\[
 \frac{hz}{1+s}-hz=-\frac{zu}{\ell(1+s)},
\tag{12}
\]
它对 $h$ 的导数为 $O_\gamma(H^{-2}\ell^{-2})$，没有原始载波的 $O(1)$ 变化。在 $h\asymp H$、$x\in[1,11/10]$、$z\in[3/2,8/5]$ 上，(11) 的分母 $\log[xY(1+s)]\asymp\ell$，有一致界
\[
 |\mathcal B_{h,a}(z)|\ll_\gamma A_0/H,
 \qquad
 \left|\partial_h\mathcal B_{h,a}(z)\right|_{a\ {m fixed}}
 \ll_\gamma A_0/H^2.
\tag{13}
\]
第二式由 $h^{-3}$、$x=a/h$、$s=u/(h\ell)$、$r_a((1+s)/(hz))$ 及 (12) 逐项微分得到；其分母始终远离零。

当整数 $h$ 增加 $1$ 时，$h<a\le11h/10$ 至多失去一个并增加两个整数 $a$。对留在两集合中的 $O(H)$ 个 $a$ 用 (13) 的导数界，对进出的 $O(1)$ 个 $a$ 用其上确界，遂得
\[
 \sup_{h,z}|\mathcal B_h(z)|\ll_\gamma A_0,
 \qquad
 \sum_{h=H}^{H+R-1}|\mathcal B_{h+1}(z)-\mathcal B_h(z)|
 \ll_\gamma A_0R/H.
\tag{14}
\]
另一方面，在 (11) 中用 $s=O((H\ell)^{-1})$、
$\log[xY(1+s)]=\ell+O(1)$、
$r_a((1+s)/(hz))=c_a+O(H^{-2})$ 及 (12) 的 $O(1/\ell)$ 相位余差，逐项积分后再以奇偶配对和 Riemann 求和处理 $a$，得到
\[
 \mathcal B_h(z)
 =\frac{Y}{\pi h^2\ell^2}\frac{\mathcal L(z)}z
 +O_\gamma(A_0/\ell+A_0/H),
 \quad
 \mathcal L(z)=\int_1^{11/10}\log(z/x)dx.
\tag{15}
\]
因 $h/H=1+O(R/H)$，记 $f(z)=\mathcal L(z)/z$，(15) 与 (14) 蕴含
\[
 \sup_{h,z}|\mathcal B_h(z)-A_0f(z)|
 \ll_\gamma A_0(\ell^{-1}+R/H).
\tag{16}
\]
对 $z\in[3/2,8/5]$，$|1-e(z)|\ge2\cos(\pi/10)>0$。把 (16) 中的误差幅度作为离散 Abel 权，使用 (14) 的总变差及几何级数，得到**不花 $R$ 因子**的
\[
 \sum_{h=H}^{H+R}\mathscr P_h(N)
 =A_0f(z)\operatorname{Re}\bigl(e(Hz)D_R(z)\bigr)
 +O_\gamma\!\left(A_0(\ell^{-1}+R/H)\right),
 \quad D_R(z)=\sum_{r=0}^Re(rz).
\tag{17}
\]
将 (9) 对 $R+1$ 个 $h$ 求和，再取
$c_*<c_1$，条件 (1) 使 $R e^{-c_1V_Y}=o(1)$。因 $R/H\to0$，遂有一致的真实源波形展开
\[
 \boxed{\quad
 \sum_{r=0}^RG_r(N)
 =A_0f(z)\operatorname{Re}\bigl(e(Hz)D_R(z)\bigr)+o_\gamma(A_0).
 \quad}\tag{18}
\]

## 3. 完整 Möbius 管与增长族能量

对 $a\asymp H<Y^{1/4}$，$q\asymp Y$、长度 $B\asymp Y/(H\ell)$，scratch 951 式 (3) 取互素模数 $a$、尺度 $X\asymp Y$，一致给任意前缀
\[
 \left|\sum_{t<n\le u}\mu(n)\mathbf1_{(n,a)=1}\right|
 \ll B e^{-c_2V_Y}+Y^{41/64},
 \quad t\le u\le t+B.
\tag{19}
\]
note 845 的精确单源权（不含 $\mu$）在 $[t,t+B]$ 上的上确界加变差为 $O_\gamma(H^{-2})$，故 Abel 求和并对 $O(H)$ 个 $a$ 相加，得到
\[
 \sup_{h,N}|T_h(N)|
 \ll_\gamma \frac{B}{H}e^{-c_2V_Y}+\frac{Y^{41/64}}H
 \ll_\gamma A_0e^{-c_3V_Y}
\tag{20}
\]
（取较小固定 $c_3>0$；因 $B/H\asymp A_0\ell$ 且
$\gamma+41/64-1<0$，对数与固定负幂均可吸收）。缩小 $c_*$ 使其同时小于 $c_1,c_3$，便有
\[
 \sup_N\left|\sum_{r=0}^RT_r(N)\right|
 \le(R+1)A_0e^{-c_3V_Y}=o(A_0),
\]
即 (3)。

式 (18) 的误差在整个观察窗一致，且 $|D_R(z)|\le\sec(\pi/10)$。因此平方后的总误差为 $o(YA_0^2)=o(A_Y)$。展开主项平方，频率 $2H+O(R)$ 的项由离散分部求和支付；因为 $R=Y^{o(1)}$，其 $O(R^2/H)$ 误差趋零。余下 $|D_R(z)|^2$ 的 Riemann 和按 scratch 957 式 (17)–(18) 处理；$R\to\infty$ 时 Riemann--Lebesgue 给相同的 $C_\infty$。逐管对角式由 (9)、(15) 的单管展开和 $h/H=1+o(1)$ 一致得到。最后 $\langle\sum G_r,\sum(T_r-G_r)\rangle=\langle\sum G_r,\sum T_r\rangle-\|\sum G_r\|_2^2$，前项由 (3) 与 Cauchy--Schwarz 为 $o(A_Y)$。这样证明 (2) 与全部引用结论。$\square$

## 边界

式 (17) 表明逐管 $1/\log Y$ 的确定性相位误差在载波方向具有有界变差，不能按绝对值乘 $R$。目前可累加的实际误差是 (9)、(20) 的次指数短和项，它限制 $R\le e^{c_*V_Y}=Y^{o(1)}$。延伸到固定幂条数需要对真实素数偏差及互素 Möbius 偏差在载波方向取得新的联合 signed 估计；即使达到那一步，这个末带子族也不能替代完整 moving-$N$ 协方差门。

更直接地，对**确定性素数密度模型** (5)，式 (13)–(17) 根本不使用短和估计，对任意 $R\to\infty$、$R=o(H^{1/2})$ 均成立。此时 $R/H\to0$ 且平方后的高载波误差 $R^2/H\to0$，故同一证明严格给出
\[
 \sum_{3Y/2<N\le8Y/5}
 \left|\sum_{h=H}^{H+R}\mathscr P_h(N)\right|^2
 =(C_\infty+o(1))A_Y>0.
\tag{21}
\]
特别地，任取固定 $0<\delta<\gamma/2$，$R=\lfloor Y^\delta\rfloor$ 是固定幂增长的载波数，但 (21) 的确定性联合能量仍停在 $A_Y=Y^{3-4\gamma+o(1)}$。因此“只把等权相邻载波数增至固定幂、同时保持现有平滑密度近似”即使完全成功，也不会支付 $Y^{2+\varepsilon}$ 的完整余项门；下一项有决策价值的任务必须估计与此正主项相抵的真实补集或完整物理余项，而不是继续优化载波数量。
