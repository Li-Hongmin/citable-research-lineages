# 任意对数幂短和不推出互素层或完整观察门的固定幂界

日期：2026-10-01。本文只关闭一种推理方式：把 [scratch/870](870-full-three-channel-coprime-observation-gram-has-logarithmic-cancellation.md) 式 (4)、(7) 的周期密度与任意固定对数幂短和当作黑箱，继续使用周期 Parseval，不能由此推出互素层或完整频带的固定幂估计。以下命题，包括互素层极限与三点极化，已完成独立代理只读复核。构造系数不是实际的 $c(m)$；真实三通道算术门仍开放。

## 命题

固定非负非零的实 $\psi\in C_c^3((1,2))$，置 $\phi(t)=\psi(t)/t$，令 $M=2Y$、$H=\lceil Y^{1/5}\rceil$、$B_0=\lfloor M^{2/3}\rfloor$、$L=\lfloor M/(32H)\rfloor$。沿用 scratch/870 的真实 $c(m)$、周期密度 $g_q(m)$ 及带通权 $w_H$。存在两组实系数 $c_M^+(m),c_M^-(m)$，对每个充分大的 $M$，其中至少一个符号（可随 $M$ 变化）满足
\[
\sum_h w_H(h)\left|
 \frac1M\sum_{M<m<2M}c_M^\pm(m)\phi(m/M)e(-hm/M)
\right|^2\gg_\psi e^{-2\sqrt{\log M}}
\gg_\psi M^{-1/5+\varepsilon}
\tag{1}
\]
对任意固定 $0<\varepsilon<1/5$ 和充分大 $M$。两组却同时满足 $|c_M^\pm(m)|\ll\log M$，而且对每个固定 $B,C>0$、$q\le(\log M)^B$、任意 $I\subset(M,2M)$ 且 $|I|\le L$，都有
\[
\left|\sum_{m\in I}\bigl({\bf1}_{q\mid m}c_M^\pm(m)-g_q(m)\bigr)\right|
\ll_{B,C,\psi}L(\log M)^{-C}.
\tag{2}
\]
因此 scratch/870 的小模周期密度、全部固定对数幂一阶短和、系数上界与带通 Parseval 本身不能支付 $H^4/M\asymp M^{-1/5}$。还须利用 $c(m)$ 的真实二点算术结构，或取得强于这些黑箱输入的估计。

## 证明

取 $\delta_M=e^{-\sqrt{\log M}}$、$h_0=\lfloor3H/2\rfloor$，并设
\[
c_M^\pm(m)=c(m)\pm\delta_M\cos(2\pi h_0m/M),
\qquad M<m<2M.
\tag{3}
\]
两组的系数上界直接成立。对任意 $q,I$，新增扰动的短和绝对值至多 $\delta_M(|I|+1)\ll\delta_M L$；由于对每个固定 $C$ 都有 $\delta_M\ll_C(\log M)^{-C}$，scratch/870 式 (7) 立即给 (2)。同样的结论对长度 $B_0$ 的块成立，所以式 (3) 保留了该证明使用的全部一阶输入。

记 $A_h$ 为真实 $c$ 的归一化 Fourier 和，$F_h$ 为式 (3) 中余弦扰动去掉 $\delta_M$ 后的归一化 Fourier 和。由带通平台，充分大 $M$ 时 $w_H(h_0)=1$。在 $h=h_0$，
\[
F_{h_0}=
\frac1{2M}\sum_m\phi(m/M)
+\frac1{2M}\sum_m\phi(m/M)e(-2h_0m/M)
=\frac12\int_1^2\phi(t)\,dt+o_\psi(1).
\tag{4}
\]
第一和是 Riemann 和；第二和由 $\phi\in C_c^3$ 的 Poisson 求和为 $O_\psi(h_0^{-3})$，因为 $h_0\to\infty$ 且 $h_0=o(M)$。故 $|F_{h_0}|\ge c_\psi>0$。平行四边形恒等式给
\[
\frac{|A_{h_0}+\delta_MF_{h_0}|^2+
|A_{h_0}-\delta_MF_{h_0}|^2}{2}
=|A_{h_0}|^2+\delta_M^2|F_{h_0}|^2
\ge c_\psi^2\delta_M^2.
\tag{5}
\]
因此两组中至少一组的整个非负频带能量满足 (1) 的首个下界。最后，$\log(H^4/M)=-(1/5+o(1))\log M$，而 $\log\delta_M^2=-2\sqrt{\log M}=o(\log M)$；遂有 $\delta_M^2/(H^4/M)\to\infty$，并得到 (1) 的第二个下界。$\square$

这个反例仅针对一阶估计黑箱。式 (3) 的扰动破坏了真实 $\Lambda$、$\mu$ 恒等式，所以它不能反驳真实观察门，也不能推出 RH 的真伪。

## 互素层的加强

令 $f_M(m)=\cos(2\pi h_0m/M)$，将 scratch/870 的互素 Gram 记为 $\mathcal G_\perp[b]$，其中输入系数 $b(m)$ 对应权 $M^{-1}b(m)\phi(m/M)$。则此波形有**确定的正极限**
\[
\boxed{\quad
\mathcal G_\perp[f_M]
\longrightarrow\frac1{2\zeta(2)}\int_1^2\phi(t)^2\,dt>0.
\quad}\tag{6}
\]
因此三组 $c_M^0=c$、$c_M^+$、$c_M^-$ 全部满足式 (2) 的一阶输入，但对每个充分大的 $M$ 至少一组（可随 $M$ 变化）满足
\[
\boxed{\quad
\max_{\sigma\in\{0,+,-\}}|\mathcal G_\perp[c_M^\sigma]|
\gg_\psi e^{-2\sqrt{\log M}}
\gg_\psi M^{-1/5+\varepsilon}.
\quad}\tag{7}
\]
这说明式 (2) 的小模一阶输入同样不能将 scratch/870 的互素层对数界升级到目标固定幂。式 (7) 是反模型断言，不是对真实 $c$ 的下界。

证明 (6)。对 $q\ge1$，沿用 scratch/870 的 $E_q$，但以 $f_M$ 代替 $c$。固定 $q$ 时，Poisson 求和给
\[
Z_{q,h}[f_M]
=\frac1{2q}\bigl[\widehat\phi(h-h_0)+\widehat\phi(h+h_0)\bigr]
+O_{q,\psi}(M^{-3})
\quad(w_H(h)\ne0).
\tag{8}
\]
因 $h_0/H\to3/2$、$w_H=1$ 于两处中心附近，$\widehat\phi(k)=O_\psi((1+|k|)^{-3})$，两峰相距 $2h_0\to\infty$，故离散支配收敛与 Parseval 给
\[
E_q[f_M]\longrightarrow
\frac1{2q^2}\sum_{k\in\mathbb Z}|\widehat\phi(k)|^2
=\frac1{2q^2}\int_1^2\phi(t)^2\,dt.
\tag{9}
\]
对 $q>Q$，$|f_M|\le1$，scratch/870 式 (11)--(12) 的同一非别名核估计给
\[
\sum_{q>Q}E_q[f_M]\ll_{s,\psi}Q^{-1}+H\log(2M)/M.
\tag{10}
\]
先对固定 $Q$ 用互素除数反演与 (9)，再由 (10) 令 $Q\to\infty$，并用 $\sum_{q\ge1}\mu(q)/q^2=1/\zeta(2)$，即得 (6)。

证明 (7)。二次型的极化恒等式逐 $M$ 给
\[
\mathcal G_\perp[c_M^+]
+\mathcal G_\perp[c_M^-]
-2\mathcal G_\perp[c_M^0]
=2\delta_M^2\mathcal G_\perp[f_M].
\tag{11}
\]
式 (6) 使右侧绝对值 $\gg_\psi\delta_M^2$，故左侧三个数至少一个的绝对值 $\gg_\psi\delta_M^2$。式 (1) 的幂次比较及三组均满足 (2) 完成证明。$\square$
