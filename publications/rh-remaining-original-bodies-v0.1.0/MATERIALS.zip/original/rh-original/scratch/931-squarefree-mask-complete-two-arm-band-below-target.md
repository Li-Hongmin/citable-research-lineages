# 完整两臂源的平方自由掩码在目标频带以下

日期：2026-10-02。沿用 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整两臂核。以下是辅助算术模型的解析估计，不把真实源系数 \(\mu\) 替换成 \(\mu^2\) 来推断 RH；尚待独立复核。

## 命题

令 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(D=\lfloor M/(32H)\rfloor\)，固定 \(\psi\in C_c^3((1,2))\)，\(\phi(x)=\psi(x)/x\)。对奇数 \(t\ge3\) 置
\[
W(t)=-4\log(t/2),\qquad W(2t)=2\log(t/4),
\]
其余正整数处 \(W=0\)。令
\[
\mathcal K_h(u)=\frac1M\sum_{\substack{k\ge3\\M<ku<2M}}
W(k)\phi(ku/M)e(-hku/M),\qquad
F_h^{\rm sf}=\sum_{\substack{D<u<2M/3\\u\ {\rm odd}}}
\mu(u)^2\mathcal K_h(u).
\]
若 \(w_H(h)=\eta(h/H)\)，其中 \(\eta\) 为固定有界非负函数，支撑于 \(1/2\le|t|\le4\)，则
\[
\boxed{\quad
\sum_h w_H(h)|F_h^{\rm sf}|^2
\ll_{\psi,\eta}
\frac{H^3\log^2(2M)}M+H^{-5}\log^4(2M)
=o\!\left(\frac{H^4}M\right).
\quad} \tag{1}
\]
这里保留奇数源的全部奇、偶物理臂与全部活动 cofactor。式 (1) 是平方自由掩码模型的界；真实 \(\mu\) 的完整带符号协方差仍未控制。

## 证明

选一个固定的 \(\chi\in C_c^\infty([0,128))\)，使 \(\chi(x)=1\) 于 \(0\le x\le64\)。令 \(\mathcal K_h^\chi(u)\) 为 \(\mathcal K_h(u)\) 的 cofactor 求和中另乘 \(\chi(k/H)\) 所得的核。若 \(u>D\)，则 \(u>M/(32H)\)，所有活动 \(k<2M/u<64H\)，所以 \(\mathcal K_h^\chi(u)=\mathcal K_h(u)\) 精确成立。解除源的下截断，记
\(\widetilde F_h^{\rm sf}=\sum_{u\ge1,\ u\ {\rm odd}}\mu(u)^2\mathcal K_h^\chi(u)\)。交换有限和得到
\[
\widetilde F_h^{\rm sf}
=\frac1M\sum_{k<128H}\chi(k/H)W(k)S(M/k,h),\qquad
S(X,h)=\sum_{u\ {\rm odd}}\mu(u)^2\phi(u/X)e(-hu/X).
\tag{2}
\]
非零活动项有 \(k\ge3\)、\(ku<2M\)，所以式 (2) 的 \(u<2M/3\) 自动满足。

对奇数 \(u\) 用平方因子恒等式 \(\mu(u)^2=\sum_{d^2\mid u}\mu(d)\)，写 \(u=d^2v\)。于是
\[
S(X,h)=\sum_{\substack{d\le\sqrt{2X}\\d\ {\rm odd}}}
\mu(d)\sum_{v\ {\rm odd}}
\phi(v/Z_d)e(-hv/Z_d),\qquad Z_d=X/d^2.
\tag{3}
\]
取 Fourier 约定 \(\widehat\phi(\xi)=\int\phi(x)e(-\xi x)\,dx\)。奇数格 Poisson 公式为
\[
\sum_{v\ {\rm odd}}\phi(v/Z)e(-hv/Z)
=\frac Z2\sum_{j\in\mathbb Z}(-1)^j\widehat\phi(h+jZ/2).
\tag{4}
\]
由于 \(\phi\in C_c^3((1,2))\)，有 \(|\widehat\phi(\xi)|\ll_\psi(1+|\xi|)^{-3}\)。当 \(Z\ge32H\) 且 \(H/2\le|h|\le4H\) 时，\(j=0\) 的频率模长至少 \(H/2\)，其他别名的模长至少 \(4H|j|\)。故 (4) 的绝对值为 \(O_\psi(ZH^{-3})\)。对 \(d^2\le X/(32H)\) 求和，此部分由 \(\sum d^{-2}<\infty\) 控制为 \(O_\psi(XH^{-3})\)。

其余 \(d\) 直接数 \(v\)：因 \(\phi\) 支撑于 \((1,2)\)，内和至多 \(O_\psi(X/d^2+1)\)。由 \(d>\sqrt{X/(32H)}\)、\(d\le\sqrt{2X}\) 得
\[
\sum_{\sqrt{X/(32H)}<d\le\sqrt{2X}}
\left(\frac X{d^2}+1\right)
\ll\sqrt{XH}+\sqrt X\ll\sqrt{XH}.
\]
因此一致于式 (2) 的 \(X=M/k\)，
\[
S(X,h)\ll_\psi XH^{-3}+\sqrt{XH}.
\tag{5}
\]
又 \(|W(k)|\ll\log(2k)\)，所以
\[
\sum_{k<128H}\frac{|W(k)|}{k}\ll\log^2(2H),\qquad
\sum_{k<128H}\frac{|W(k)|}{\sqrt k}\ll\sqrt H\log(2H).
\]
将 (5) 代入 (2)，得
\[
|\widetilde F_h^{\rm sf}|
\ll_\psi H^{-3}\log^2(2H)
+\frac H{\sqrt M}\log(2H).
\tag{6}
\]

最后核对低源修正。对每个奇数 \(u\le D\)，奇臂 cofactor 的尺度 \(X_o=M/u\ge32H\)，偶臂奇 cofactor 的尺度 \(X_e=M/(2u)\ge16H\)。若 \(\chi(k/H)\phi(ku/M)\ne0\)，则奇臂有 \(X_o<128H\)，偶臂有 \(X_e<64H\)。因此在变量 \(x=t/X_o\) 或 \(x=t/X_e\) 中，截断因子 \(\chi(X_ox/H)\) 或 \(\chi(2X_ex/H)\) 的前三阶导数一致有界。与 (4) 相同的奇数格 Poisson 公式可用于两臂这些截断后的 \(\phi\) 与 \((\log x)\phi(x)\)；所有别名在 \(H/2\le|h|\le4H\) 离零 \(\gg H\)。两臂的对数系数为 \(O(\log(2M))\)，故
\[
|\mathcal K_h^\chi(u)|\ll_{\psi,\chi}\frac{\log(2M)}{uH^3}.
\tag{7}
\]
此界不使用 \(\mu\) 的符号，因而
\[
|F_h^{\rm sf}-\widetilde F_h^{\rm sf}|
\le\sum_{u\le D}|\mathcal K_h^\chi(u)|
\ll_{\psi,\chi}H^{-3}\log^2(2M).
\tag{8}
\]
频带只含 \(O_\eta(H)\) 个整数 \(h\)，且 \(w_H(h)\ll_\eta1\)。由 (6)--(8) 平方求和得 (1) 的不等式。再用 \(H\gg M^{1/5}\)：
\[
\frac{H^3\log^2(2M)/M}{H^4/M}
=\frac{\log^2(2M)}H\to0,
\qquad
\frac{H^{-5}\log^4(2M)}{H^4/M}
=\frac{M\log^4(2M)}{H^9}\to0.
\]
证毕。

## 增长周期的统一版本

上述估计允许随尺度增长的周期调制。设 \(q\ge1\)，\(\omega:\mathbb Z\to\mathbb C\) 以 \(q\) 为周期且 \(|\omega|\le1\)，并将 \(F_h^{\rm sf}\) 中的 \(\mu(u)^2\) 换成 \(\mu(u)^2\omega(u)\)，记所得包为 \(F_{h,\omega}^{\rm sf}\)。则一致于所有这样的 \(\omega\) 及 \(1\le q\le H/\log^3(2M)\)，
\[
\boxed{\quad
\sum_h w_H(h)|F_{h,\omega}^{\rm sf}|^2
\ll_{\psi,\eta}
q\left(\frac{H^3\log^2(2M)}M+H^{-5}\log^4(2M)\right)
=o\!\left(\frac{H^4}M\right).
\quad} \tag{9}
\]

证明只需改写 (3)--(5)。对固定奇数 \(d\)，令
\(P=\operatorname{lcm}(2,q)\le2q\)、
\(b_d(v)=\mathbf1_{v\ {\rm odd}}\omega(d^2v)\)。这是模 \(P\) 的周期函数。其离散 Fourier 展开
\[
b_d(v)=\sum_{j=0}^{P-1}c_{d,j}e(jv/P)
\]
满足
\(\sum_j|c_{d,j}|^2=P^{-1}\sum_{v\bmod P}|b_d(v)|^2\le1\)，所以
\(\sum_j|c_{d,j}|\le\sqrt P\)。对每个 \(j\) 作整数格 Poisson 求和。若 \(Z=X/d^2\ge16PH\)，则在 \(H/2\le|h|\le4H\) 中，所有频率 \(h+Z(n-j/P)\) 距零 \(\gg H\)；唯一可能取 \(n=j=0\) 的频率就是 \(h\)，也至少为 \(H/2\)。对 \(n\) 求三次 Fourier 衰减并对 \(j\) 使用上述 \(\ell^1\) 界，得到
\[
\left|\sum_v b_d(v)\phi(v/Z)e(-hv/Z)\right|
\ll_\psi\sqrt P\,ZH^{-3}. \tag{10}
\]
其余 \(d>\sqrt{X/(16PH)}\) 用 \(|b_d|\le1\) 直接计数，贡献
\(O(\sqrt{PXH})\)。在所述 \(q,H\) 范围内，对所有 \(k<128H\) 都有
\(X/(16PH)\gg M/H^3\to\infty\)，故这些分段合法。于是
\[
S_\omega(X,h)\ll_\psi
\sqrt q\left(XH^{-3}+\sqrt{XH}\right). \tag{11}
\]
按 (2) 对 \(k\) 求和，得到 (6) 的右侧乘 \(\sqrt q\)。低源修正仍由 (7)--(8) 控制，因为 \(|\omega|\le1\)。平方后对 \(O(H)\) 个频率求和，即得 (9) 的不等式。最后第二项对目标的比至多 \(\log^{-1}(2M)\)；第一项的比至多
\[
\frac{qM\log^4(2M)}{H^9}
\le\frac{M\log(2M)}{H^8}\longrightarrow0
\]
（因 \(H\gg M^{1/5}\)），故有一致的 \(o\) 界。

## 真实 Möbius 源的小素数奇偶分离

取绝对常数 \(C_0\) 使 Chebyshev 的初等界
\(\vartheta(x)=\sum_{p\le x}\log p\le C_0x\) 对 \(x\ge2\) 成立，并置
\[
Q=\left\lfloor\frac{\log H}{2C_0}\right\rfloor,\qquad
q_Q=\prod_{p\le Q}p,\qquad
\epsilon_Q(u)=(-1)^{\#\{p\le Q:p\mid u\}}.
\tag{12}
\]
则 \(\epsilon_Q\) 以 \(q_Q\) 为周期，\(|\epsilon_Q|=1\)，且
\(q_Q\le H^{1/2}\le H/\log^3(2M)\) 对充分大 \(M\) 成立。对所有整数 \(u\)，令
\[
\nu_Q(u)=-2\mu(u)^2\epsilon_Q(u)
\mathbf1_{\#\{p>Q:p\mid u\}\ {\rm odd}}.
\tag{13}
\]
平方自由数的 Möbius 符号是其全部不同素因子数的奇偶性，因此有逐点恒等式
\[
\boxed{\quad\mu(u)=\mu(u)^2\epsilon_Q(u)+\nu_Q(u).\quad}
\tag{14}
\]
令 \(F_h^\mu\)、\(F_h^{\nu_Q}\) 分别为命题中同一完整两臂核对 \(\mu(u)\)、\(\nu_Q(u)\) 的源包，且以
\(\|F\|_{H,\eta}^2=\sum_h w_H(h)|F_h|^2\) 记频带范数。由 (9)、(14)，
\[
\boxed{\quad
\|F^\mu-F^{\nu_Q}\|_{H,\eta}
=o\!\left(\frac{H^2}{\sqrt M}\right).
\quad}\tag{15}
\]
于是 \(\|F^\mu\|_{H,\eta}^2=O(H^4/M)\) 当且仅当
\(\|F^{\nu_Q}\|_{H,\eta}^2=O(H^4/M)\)。这里的等价只在目标范数界下使用三角不等式；式 (15) 本身不声称两个未经控制的能量之差为 \(o(H^4/M)\)。

进一步，[scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (6)--(7) 已将 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合观察包 \(\mathcal A_h(Y)\) 与 \(F_h^\mu\) 在此频带上的差支付到 \(o(H^4/M)\) 的平方范数。因此
\[
\|\mathcal A(Y)-F^{\nu_Q}\|_{H,\eta}
=o\!\left(\frac{H^2}{\sqrt M}\right).
\tag{16}
\]
这把原始双端点观察门直接缩到 \(\nu_Q\)，但仍只是一项已证明误差的归约。

式 (13) 把仍需估计的真实源明确定位于大于 \(Q\asymp\log M\) 的素因子数为奇数的平方自由整数。它没有减少到固定素因子层；这类整数仍包含随 \(M\) 增长的素因子深度。

## 与真实门的关系

式 (1) 与 (9) 对完整两臂核给出平方自由指示及其中等周期调制的固定幂基线，证明使用 \(\mu^2=\sum_{d^2\mid n}\mu(d)\) 的平方因子展开。式 (15) 将它用于真实 \(\mu\) 的小素数奇偶分离，但没有估计 \(\nu_Q\) 的完整带符号协方差，也不支付 note 850 式 (18) 的留存和。下一步仍须保留跨乘子及两臂补偿，对大素因子奇偶余项证明固定幂节省。
