# Farey 低谱模向完整旧奇空间泄漏固定的槽内轮廓（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确算术平移和 Farey 间距、[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的完整 Archimedean 单槽形式，以及 [scratch 810](810-fixed-prime-transverse-modes-in-the-full-farey-compression-candidate.md) 的有限主压缩低谱模。以下只做解析推导；同模型独立复核未发现承重错误，尚缺异源复核，故留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(k=p^2\)、\(L=2\log p\)、\(\Delta=\frac12\log(1+p^{-2})\)，并采用 note 791 的根补全 Farey 空间
\[
U_p=\mathbb C e_p\oplus W_p,\qquad
W_p=\operatorname{span}\{w_x:x\in\mathcal F_p\}.
\]
定义 \(0<t<1\) 上的显式函数
\[
F(t)=\frac12\log\frac{2-t}{t}-\log(1-t),
\qquad m=\int_0^1F(t)\,dt=1+\log2,
\qquad \sigma^2=\int_0^1|F(t)-m|^2dt>0.
\tag{1}
\]
对任意固定 \(0<\alpha<1\)，记 \(I_{p,\alpha}=\mathcal F_{\lfloor p^\alpha\rfloor}\)，\(P_I\) 为 \(U_p\) 上相应 Farey 坐标投影。存在 \(U_p^\perp\cap H_k^-\) 中的正交单位族 \(\{\eta_x:x\in I_{p,\alpha}\}\) 及将 \(w_x\mapsto\eta_x\) 的等距映射 \(J_{p,\alpha}\)，使真实完整旧奇算子满足
\[
\boxed{
\left\|P_{Z_{p,\alpha}}A_{k,-}|_{U_p}
-\sigma J_{p,\alpha}P_I\right\|_{U_p\to Z_{p,\alpha}}
\longrightarrow0,
\quad Z_{p,\alpha}=\operatorname{span}\{\eta_x:x\in I_{p,\alpha}\}.}
\tag{2}
\]
这里 \(U_p\subset D(A_{k,-})\)，所以 (2) 是有限维定义域上的强算子交叉块。特别地，scratch 810 的每个固定有限素数集 \(S\) 的向量 \(u_{p,S}\) 满足
\[
\boxed{
\liminf_{p\to\infty}
\frac{\|(I-P_{U_p})A_{k,-}u_{p,S}\|}{\|u_{p,S}\|}
\ge\sigma>0.}
\tag{3}
\]
因此 scratch 810 的有限主压缩近似本征向量不是完整旧奇算子的范数近似本征向量；该判断不要求完整算子正性。

## 单个物理偶极的局部响应

在 \(u=\log t\in(0,L)\) 坐标中，令 \(u_0=\log z\) 为任意合法物理中心，并记 note 791 的单位偶极
\[
\varphi_z(u)=(2\Delta)^{-1/2}
\bigl(1_{(u_0-\Delta,u_0)}(u)-1_{(u_0,u_0+\Delta)}(u)\bigr).
\tag{4}
\]
置 \(\psi(t)=(F(t)-m)/\sigma\)，在同一两半槽上定义
\[
\eta_z(u)=\frac1{\sqrt{2\Delta}}
\begin{cases}
\psi(t),&u=u_0-\Delta+\Delta t,\quad0<t<1,\\
-\psi(1-t),&u=u_0+\Delta t,\quad0<t<1,\\
0,&\text{其他 }u.
\end{cases}
\tag{5}
\]
因为 \(\int_0^1\psi=0\)、\(\int_0^1|\psi|^2=1\)，\(\|\eta_z\|=1\) 且 \(\langle\eta_z,\varphi_z\rangle=0\)。两者均关于 \(u_0\) 反对称。

下面核对 \(\sigma\) 是完整 Archimedean 算子的一个真实非对角矩阵元。将 note 790 式 (3)--(5) 用在宽度 \(2\Delta\) 的整个区间 \((u_0-\Delta,u_0+\Delta)\)，并以 \(t=(u-u_0+\Delta)/\Delta\in(0,2)\) 缩放。Legendre 项的位置因子与势 \(V\) **逐点抵消**；余下的局部形式是一个标量乘恒等算子加
\[
\mathfrak b_2[h]
=\frac14\int_0^2\!\int_0^2
\frac{|h(t)-h(s)|^2}{|t-s|}\,dt\,ds
-\frac12\int_0^2\log(t(2-t))|h(t)|^2dt.
\tag{6}
\]
对应的局部算子作用为
\[
(\mathcal B_2h)(t)
=\frac12\int_0^2\frac{h(t)-h(s)}{|t-s|}\,ds
-\frac12\log(t(2-t))h(t).
\tag{7}
\]
对 \(h=1_{(0,1)}-1_{(1,2)}\)，式 (7) 在 \(0<t<1\) 等于
\[
\log\frac{2-t}{1-t}-\frac12\log(t(2-t))
=F(t),
\tag{8}
\]
在右半槽则由反射给出 \(-F(2-t)\)。常数标量与 \(\eta_z\perp\varphi_z\) 正交；完整正则 gamma 核在两半槽间的矩阵元为 \(O(\Delta)\)，因为其核在原点有界。因此
\[
\boxed{\langle\eta_z,G_k\varphi_z\rangle=\sigma+O(\Delta)}
\tag{9}
\]
与位置无关。这里 (7)--(8) 先对支撑内的光滑测试函数由形式极化得到，再以 \(\varphi_z\in D(G_k)\) 及 \(F\in L^2(0,1)\) 延拓；\(\eta_z\) 只须属于 \(L^2\)。

## Farey 横向族与算术精确消失

对 \(x\in I_{p,\alpha}\)，采用 note 791 的两臂中心 \(px,p/x\)，置
\[
\eta_x=\frac{\eta_{px}+\eta_{p/x}}{\sqrt2}.
\tag{10}
\]
全局奇反射把 \(\eta_{px}\) 送到 \(-\eta_{p/x}\)，故 \(\eta_x\in H_k^-\)。note 791 的全 Farey 物理半槽互不相交；(5) 又逐槽正交于 (4)。所以 \(\{\eta_x\}_{x\in I_{p,\alpha}}\) 正交单位化，且与 \(U_p\) 正交。

若一个素数幂平移 \(T_n\) 或 \(T_n^*\) 将 \(U_p\) 的一个物理半槽送得与 \(\eta_x\) 的支撑相交，note 791 式 (10) 的整数间距证明强迫两个中心**精确重合**；根 \(e_p\) 的情形也由同一个清除分母论证给出。重合时，平移保留 (4) 的完整阶跃轮廓，而 (5) 与之正交。因此
\[
\boxed{P_{Z_{p,\alpha}}\mathcal R_k|_{U_p}=0}
\tag{11}
\]
是精确恒等式，而非渐近估计。

## 远槽估计与完整交叉块

两个不同物理中心相距 \(d\ge3\Delta\) 时，相离 Archimedean 核为 \(-K(d)\)，且 \(|K''(d)|\ll d^{-3}\)（note 791 式 (11)）。\(\eta_z\) 与 \(\varphi_z\) 各自零均值、支撑长度 \(2\Delta\)、单位范数；在双变量各消去一次常数项，或各取一次紧支撑原函数并分部积分，得到
\[
|\langle\eta_z,G_k\varphi_{z'}\rangle|
\ll\Delta^3/d^3.
\tag{12}
\]
对于内区 \(x=a/b\)、\(a,b\le p^\alpha\)，任意**不同**的全 Farey 物理中心与 \(x\) 的中心距离至少为 \(\delta_{p,\alpha}\gg p^{-1-\alpha}\)：同臂由 \(|ad-bc|\ge1\)、\(bc\le p^{1+\alpha}\) 得到，异臂由 \(x,y>1\) 得到；根中心距离更大。所有物理中心又至少相隔 \(2\Delta\)。把中心排序并用 (12) 求和，内区目标行的绝对和满足
\[
O\!\left((\Delta/\delta_{p,\alpha})^2\right)
=O\!\left(p^{-2(1-\alpha)}\right)=o(1).
\tag{13}
\]
全族来源列的绝对和由 note 791 的一致有界行和控制为 \(O(1)\)；对称的核估计同样适用于 \(\eta\)--\(\varphi\) 配对。式 (9) 在 \(w_x,\eta_x\) 的两个相同中心各给半权；同一 \(x\) 的两臂相互作用也落入 (13)。矩形 Schur 检验遂给误差范数 \(O(p^{-(1-\alpha)})=o(1)\)，即
\[
\left\|P_{Z_{p,\alpha}}G_k|_{U_p}
-\sigma J_{p,\alpha}P_I\right\|=o(1).
\tag{14}
\]
note 791 给 \(\|P_{U_p}s_k\|=O(p^{-3/2})\)，而 \(\|s_k\|=O(p^{1/2})\)，所以 polar 交叉块范数为 \(O(p^{-1})\)。把 (11)、(14) 与 \(A_{k,-}=G_k+\mathcal R_k-2|s_k\rangle\langle s_k|\) 合并，证明 (2)。

最后，scratch 810 式 (4) 及固定素数态的内区调和密度给
\[
\frac{\|P_Iu_{p,S}\|}{\|u_{p,S}\|}\longrightarrow\alpha.
\]
用 (2) 得 \(\liminf\|(I-P_{U_p})A_{k,-}u_{p,S}\|/\|u_{p,S}\|\ge\sigma\alpha\)，再令 \(\alpha\uparrow1\)，证明 (3)。\(\square\)

## 边界

式 (2) 精确指出有限 Farey 压缩遗漏了一个与 \(p\) 无关的槽内 Archimedean 响应；它不提供该无限维补空间的逆能量，也不判定完整 Schur 补的符号。后续 [scratch 812](812-odd-slot-profile-coercivity-and-interior-farey-gap-candidate.md) 证明内部 \(Q/p\to0\) 的整族局部反对称轮廓仍有增长谱隙，所以这里的泄漏本身不构成负方向。真实 moving-\(N\) Möbius signed covariance 与 RH 均仍未解决。
