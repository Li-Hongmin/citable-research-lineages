# 三通道观察频带的 Haar 滑动窗门与零频障碍（待异源复核）

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(18)、(29)--(33)，以及 [scratch/853](853-centered-prime-arms-blockwise-replacement-draft.md) 的奇偶格中心化。本稿给出一个可直接检验的紧支撑 signed covariance 充分条件，不声称已达到该条件或证明 RH。

**后续路线校正：**[scratch/856](856-smooth-observation-wavelet-removes-haar-high-frequency-loss.md) 构造了 $h\asymp Y^{1/4}$ 的反模型：本稿 Haar 充分门在 $H=Y^{1/5}$ 会比该频带目标额外多要求 $Y^{1/10-o(1)}$。以下恒等式和充分蕴含仍真；当前应优先使用 scratch/856 的平滑小波门检验真实算术协方差。

## 频带的二窗观测

令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$L=2\lfloor M/(32H)\rfloor$（故 $L$ 为偶数）。把
\[
 a_m=\frac{c(m)}m\psi(m/M),\qquad
 \mathcal A_h=\sum_m a_m e(-hm/M)
\]
按 $m\pmod M$ 看成周期序列；$c$、$\psi$ 如 note 849。令
\[
 D_La(x)=\sum_{j=0}^{L-1}a_{x-j}
          -\sum_{j=L}^{2L-1}a_{x-j},\qquad x\pmod M.
\tag{1}
\]
取 note 849 的非负频带权 $\eta$，其支撑满足 $1/2\le|h|/H\le4$。则
\[
 \boxed{\quad
 \sum_h\eta(h/H)|\mathcal A_h|^2
 \ll_\eta \frac{M}{L^2}\sum_{x\bmod M}|D_La(x)|^2.
 \quad}\tag{2}
\]
特别地，若对每个 $\varepsilon>0$ 能证明真实算术窗门
\[
 \boxed{\quad
 \sum_{x\bmod M}|D_La(x)|^2
 \ll_{\varepsilon,\psi} H^2Y^\varepsilon,
 \quad}\tag{3}
\]
则 note 849 式 (15) 所需的整个频带上界
$\sum_h\eta(h/H)|\mathcal A_h|^2\ll_\varepsilon H^4Y^{-1+\varepsilon}$ 随之成立。(3) 尚未证明；(2) 是单向充分条件，不能把它称作原频带门的等价式。

证明设 $B_h=\sum_{j=0}^{L-1}e(-hj/M)$。式 (1) 的离散 Fourier 乘子恰为
\[
 \widehat{D_La}(h)=B_h(1-e(-hL/M))\mathcal A_h.\tag{4}
\]
当 $\eta(h/H)\ne0$ 时，对充分大的 $Y$ 有 $|h|L/M\in[1/33,1/4]$。几何和公式及 $\sin(\pi t)\ge2t$（$0\le t\le1/2$）给
$|B_h|\gg L$，$|1-e(-hL/M)|\gg1$，常数均一致；$M$ 足够大时整数取整不影响界。对 (4) 用周期 Parseval 即得 (2)。又 $M/L^2\asymp H^2/Y$，故 (3) 蕴含所述目标。$\square$

这个窗门是一个明确的紧支撑 signed Gram。写 $T_L(k)=(L-|k|)_+$，则
\[
 \sum_x|D_La(x)|^2
 =\sum_{m,n}a_m\overline{a_n}\,Q_L(m-n),\qquad
 Q_L(k)=2T_L(k)-T_L(k-L)-T_L(k+L).\tag{5}
\]
当 $|k|\le L$ 时 $Q_L(k)=2L-3|k|$；当 $L\le|k|\le2L$ 时
$Q_L(k)=|k|-2L$；更远处为零。若按模 $M$ 写差，应取此核的周期化；由于 $a_m$ 的支撑紧嵌于一个长度 $M$ 的周期且 $2L=o(M)$，在实际非零配对上无非零别名。核虽逐点有负值，整体二次型因 (1) 为非负。

令 $K_0=H^3/\log^2(2Y)$。note 849 式 (16) 给
$\sum_m|a_m|^2\ll\log(2Y)/Y$。由 $|Q_L(k)|\le2L$、
$\sum_m|a_{m+k}a_m|\le\sum_m|a_m|^2$，
\[
 \left|\sum_{|m-n|\le K_0}a_m\overline{a_n}Q_L(m-n)\right|
 \ll LK_0\frac{\log(2Y)}Y
 \ll\frac{H^2}{\log(2Y)}.\tag{5a}
\]
因为 $K_0< L$ 且 $Q_L$ 支撑于 $|k|<2L$，(3) 在其自身量级内等价于只控制
\[
 \sum_{K_0<|m-n|<2L}a_m\overline{a_n}Q_L(m-n)
 \ll_\varepsilon H^2Y^\varepsilon.\tag{5b}
\]
这里的“等价”只相对于 Haar 窗门 (3)；它仍是原频带门的充分条件。

偶数窗长还使未加权的真实算术对象完全没有平滑或奇偶背景。令
$\Psi(t)=\sum_{1\le n\le t}\Lambda(n)$、$M_\mu(t)=\sum_{1\le n\le t}\mu(n)$，并对整数 $x>2L$ 直接把式 (1) 作用于在所有正整数上按 note 849 式 (10) 定义的 $c(m)$。则逐 $x$ 精确有
\[
\begin{aligned}
D_Lc(x)={}&2\{\Psi(x/2)-2\Psi((x-L)/2)+\Psi((x-2L)/2)\}\\
&-4\{\Psi(x)-2\Psi(x-L)+\Psi(x-2L)\}\\
&-4(\log2)\{M_\mu(x)-2M_\mu(x-L)+M_\mu(x-2L)\}.
\end{aligned}\tag{5c}
\]
确实，任意序列 $f$ 的两窗差是其部分和 $F$ 的二阶差
$F(x)-2F(x-L)+F(x-2L)$；$c$ 的常数背景被二阶差消去，偶格背景因 $L$ 为偶数也被精确消去。式 (5c) 只把待证协方差写成两个尺度的 Chebyshev 二阶差与一个 Mertens 二阶差的**联合**能量，不能分别给三项取绝对值。

式 (5c) 还能直接用作一个不带光滑权的充分算术门。若对所有固定 $\varepsilon>0$ 有
\[
 \boxed{\quad
 \sum_{2Y\le x\le4Y+2L}|D_Lc(x)|^2
 \ll_\varepsilon Y^2H^2Y^\varepsilon,
 \quad}\tag{5d}
\]
则 (3) 对任意固定 $\psi\in C_c^3((1,2))$ 成立。证明写 $a_m=w_mc(m)$，全局零延拓的 $w_m=\psi(m/M)/m$ 满足
$\|w\|_\infty\ll M^{-1}$、$|w_{m+1}-w_m|\ll M^{-2}$。逐 $x$ 有
\[
 D_La(x)=w_xD_Lc(x)
 +\sum_{j=0}^{2L-1}q_j\{w_{x-j}-w_x\}c(x-j),
 \quad q_j=\begin{cases}1&j<L,\\-1&j\ge L.\end{cases}\tag{5e}
\]
因为 $|c(n)|\ll\log(2Y)$ 于有关的 $n\asymp Y$，第二项逐点
$\ll L^2\log(2Y)/M^2$，只在 $O(M)$ 个 $x$ 上非零，其平方和
$\ll M\log^2(2Y)/H^4=o(H^2)$。第一项平方和由 (5d) 至多为
$O(H^2Y^\varepsilon)$。这证明 (5d) 确实支付原频带，且待证部分就是 (5c) 的真实联合二阶差。$\square$

## 精确地只留下三通道

令 $a_m^{\rm tri}=c_{\rm tri}(m)\psi(m/M)/m$，$c_{\rm tri}$ 如 note 849 式 (29)。则在上述范围内
\[
 \boxed{\quad
 \sum_{x\bmod M}|D_L(a-a^{\rm tri})(x)|^2
 \ll_\psi \frac{M}{H^4}+\log^2(2Y)
 =o(H^2).
 \quad}\tag{6}
\]
因此 (3) 的任意 $Y^\varepsilon$ 版本对 $a$ 与 $a^{\rm tri}$ 双向等价；可把待估窗门直接写成素数 $p$、倍素数 $2p$ 与 $\mu$ 的联合 signed covariance。

为证明 (6)，写 $w_m=\psi(m/M)/m=M^{-1}\varphi(m/M)$。note 849 式 (31) 给
$a-a^{\rm tri}=w[3+(-1)^{m+1}+q(m)]$，其中
$q(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m)$。
$|w_m|\ll M^{-1}$、$|w_{m+1}-w_m|\ll M^{-2}$。
对平滑的 $3w$，式 (1) 中逐项配对相隔 $L$ 的两窗，得
$|D_L(3w)(x)|\ll L^2/M^2$，所以其平方和
$\ll M L^4/M^4\ll M/H^4$。
任一长度 $L$ 区间上，交替加权和由 Abel 求和界为
$O(M^{-1}+L/M^2)=O(M^{-1})$；两窗之差的平方和为 $O(M^{-1})$。
由 note 849 式 (33)，$\sum_m|w_mq(m)|\ll M^{-1/2}\log(2M)$。
因此对每个 $x$ 有 $|D_L(wq)(x)|\le\sum_m|w_mq(m)|$，平方后对 $M$ 个 $x$ 求和为 $O(\log^2M)$。三项合并即得 (6)，因为 $M/H^6\to0$ 且 $\log^2M/H^2\to0$。用三角不等式比较两种 $D_L$ 范数，得到目标窗门的双向蕴含。$\square$

## 为何普通单窗均方是更强的零频命题

这不是针对已证明的 note 849 式 (26) 的反例，而是定位一种可能的加强方式。将 $c(m)$ 在所有正整数上按 note 849 式 (10) 定义，令 $C(X)=\sum_{m\le X}c(m)$。设 $L_X=\lfloor X^{4/5}\rfloor$。如果有人通过普通单窗能量企图得到 (3) 的对应原始量级，并证明对每个 $\varepsilon>0$、所有足够大整数 $X$ 都有
\[
 \sum_{x=X}^{2X-1}\left|\sum_{j=1}^{L_X}c(x+j)\right|^2
 \ll_\varepsilon X^{12/5+\varepsilon},\tag{7}
\]
那么必有
\[
 C(X)\ll_\varepsilon X^{9/10+\varepsilon}.\tag{8}
\]
事实上，记内窗和为 $U_x$。交换求和后，每个
$X+L_X<n\le2X$ 在 $\sum_{x=X}^{2X-1}U_x$ 中恰出现 $L_X$ 次，只有两端各 $O(L_X)$ 个整数的重数不同。因为 $|c(n)|\ll\log(2n)$，
\[
 \sum_{x=X}^{2X-1}U_x
 =L_X[C(2X)-C(X)]+O(L_X^2\log(2X)).\tag{9}
\]
Cauchy--Schwarz 与 (7) 给左侧 $\ll X^{17/10+\varepsilon/2}$；除以 $L_X\asymp X^{4/5}$ 得
$C(2X)-C(X)\ll X^{9/10+\varepsilon}+X^{4/5}\log X$。对任意整数 $X$ 反复二分并处理至多一格的取整误差，即得 (8)。

式 (8) 甚至带来明确的零点门。对 $\Re s>1$，Dirichlet 级数为
\[
 \sum_{m\ge1}\frac{c(m)}{m^s}
 =(4-2^{1-s})\left(\frac{\zeta'(s)}{\zeta(s)}+\zeta(s)\right)
 -\frac{4\log2}{\zeta(s)}.\tag{10}
\]
由 (8) 的部分求和，左侧在 $\Re s>9/10$ 全纯。于是此半平面的任何 $\zeta$ 零点都必须是单零点，并满足
\[
 \boxed{\quad
 \zeta'(\rho)=\frac{4\log2}{4-2^{1-\rho}}.
 \quad}\tag{11}
\]
重零点会在 $1/\zeta$ 项产生无法由 $\zeta'/\zeta$ 抵消的高阶极点；单零点的留数为
$(4-2^{1-\rho})-4\log2/\zeta'(\rho)$。分母在 $\Re\rho>9/10$ 不为零。式 (11) 是必要条件，不排除这样的例外零点，更不是 RH 的证明。

Haar 二窗差在 Fourier 侧有因子 $1-e(-hL/M)$，精确消去 $h=0$。因此 (7)--(11) 的**直接零频前缀蕴含**不适用于 (3)；这不意味着 Haar 窗门已变容易。未付核心仍是式 (5) 中真实三通道在跨度 $L\asymp Y^{4/5}$ 内的带符号协方差。
例如把算术系数临时换成常数 $c(m)=1$，则未加权的二窗差恒为零，平滑权 $w_m$ 下其平方和由上面的估计为 $O(M/H^4)=o(H^2)$，但全局部分和是 $C(X)=\lfloor X\rfloor$。这直接证明 Haar 门不蕴含 (8) 那样的前缀幂界。

在 $H=Y^{1/5}$ 时，当前全区间短区间定理只给每个长度 $L\asymp Y^{4/5}$ 的 $c$ 窗口和 $o(L)$；逐窗代入 (5d) 仅得 $o(YL^2)=o(Y^{13/5})$，而 (5d) 要求 $Y^{12/5+\varepsilon}$。缺少的是频率平均下固定 $Y^{1/5}$ 幂次的真实算术节省，不是零频中心化或核的符号选择。
