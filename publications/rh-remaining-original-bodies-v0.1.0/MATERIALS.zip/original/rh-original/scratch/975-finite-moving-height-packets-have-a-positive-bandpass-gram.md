# 有限移动高度波包的带通 Gram 严格正定

日期：2026-10-03。承接 [scratch 974](974-moving-height-zero-packet-tests-the-k2-bandpass-threshold.md) 的单波包驻相计算。这里的系数是复幂模型，不是 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实三通道系数。结论只排除有限个模型波包互相消去；真实零点显式公式的余项和随高度增长的零点族仍未控制。

## 定理

固定 $1/5\le\gamma<1/4$、$1/2<\beta<1$，令 $H=M^\gamma$，$M\to\infty$ 沿整数。取实非零 $\phi\in C_c^\infty((1,2))$，以及非负偶函数 $\eta\in C_c^\infty(\mathbb R)$，满足
$\operatorname{supp}\eta\subset\{t:1/2\le|t|\le4\}$。令 $u_1,\ldots,u_J>0$ 属于同一个固定紧区间 $U\Subset(0,\infty)$，且 $\operatorname{diam}U<1/2$。同一个 $u$ 可以重复；每个不同的 $u$ 都要求
\[
 I_u:=\int_1^2\eta(u/x)x^{2\beta-4}\phi(x)^2\,dx>0.       \tag{1}
\]
取固定实数 $\lambda_j$，要求同一个 $u$ 组内的 $\lambda_j$ 两两不同，并定义
\[
 \tau_{j,M}=2\pi u_jH+\lambda_j,\qquad
 A_{j,h}(M)=\sum_{m\ge1}m^{\beta-2+i\tau_{j,M}}
       \phi(m/M)e(-hm/M),\quad e(x)=e^{2\pi ix}.             \tag{2}
\]
则对任意 $r=(r_1,\ldots,r_J)\in\mathbb C^J$，一致地有
\[
\boxed{\begin{aligned}
 &\sum_{h\in\mathbb Z}\eta(h/H)
       \left|\sum_{j=1}^Jr_jA_{j,h}(M)\right|^2\\
 &=M^{2\beta-2}\left\{
   \sum_{u\in\{u_1,\ldots,u_J\}}
      \int_1^2\eta(u/x)x^{2\beta-4}\phi(x)^2
      \left|\sum_{j:u_j=u}r_j e^{i\lambda_j\log(Mx)}\right|^2dx
   +o(1)\|r\|_2^2\right\}.
\end{aligned}}                                                    \tag{3}
\]
这里 $o(1)$ 表示一个绝对值至多 $o(1)\|r\|_2^2$ 的实误差，依赖固定的 $\phi,\eta,u_j,\lambda_j,\beta$。尤其存在固定 $c>0$，使充分大 $M$ 时
\[
 \sum_h\eta(h/H)\left|\sum_jr_jA_{j,h}(M)\right|^2
 \ge cM^{2\beta-2}\sum_j|r_j|^2.                            \tag{4}
\]
在 $H=M^{1/5}$、$\beta>9/10$ 时，任意一个非零的固定有限组合都比 note 849 的目标 $H^4/M$ 大一个固定幂。式 (4) 同时容许同一归一化高度内相差固定数量的高度 $\lambda_j$，并不要求这些高度之间的间隔随 $H$ 增长。

## 证明

把 $\phi$ 零延拓至正实线。Poisson 求和后，式 (2) 等于
\[
 M^{\beta-1+i\tau_{j,M}}
 \sum_{k\in\mathbb Z}\int_0^\infty
 x^{\beta-2+i\lambda_j}\phi(x)
 e^{iH\Phi_{u_j,t}(x)}e(-kMx)\,dx,
 \quad t=h/H,\quad
 \Phi_{u,t}(x)=2\pi u\log x-2\pi tx.                     \tag{5}
\]
在 $\eta(h/H)\ne0$ 时，$|h|\asymp H=o(M)$。对 $k\ne0$，式 (5) 的相位导数绝对值为 $\gg |k|M$；重复分部积分使所有这些别名之和为 $O_A(M^{-A})$，对相关 $h$ 一致。

若 $h<0$，$k=0$ 项没有驻点，重复分部积分给 $O_A(H^{-A})$。若 $h>0$，置 $x_{u,t}=u/t$，并把含 $\phi(x_{u,t})$ 的式子在支撑外理解为零。相位二阶导数在驻点为 $-2\pi u/x_{u,t}^2$。带参数的一维驻相公式一致给
\[
 A_{j,h}(M)=M^{\beta-1+i\tau_{j,M}}
 \left[
 H^{-1/2}u_j^{-1/2}x_{u_j,t}^{\beta-1+i\lambda_j}
 \phi(x_{u_j,t})e^{iH\Phi_{u_j}(t)-i\pi/4}
 +O(H^{-3/2})\right],                                      \tag{6}
\]
其中 $\Phi_u(t)=2\pi u(\log(u/t)-1)$。$u_j$ 属于固定有限集、$t$ 属于 $[1/2,4]$，故误差一致。式 (5) 的别名误差已吸收到 (6)；$H=M^\gamma$ 保证 $M^{-A}=O(H^{-3/2})$，只须取足够大的固定 $A$。

将 (6) 代入左侧。主项与误差的交叉及误差平方在 $O(H)$ 个频率上合计为 $O(M^{2\beta-2}H^{-1}\|r\|_2^2)$。若 $u_j=u_k=u$，其主项相位相同；$H^{-1}\sum_{h>0}$ 是黎曼和。以 $t=u/x$ 换元后，该组的所有 Gram 项恰收敛到式 (3) 中的积分，误差为 $O(M^{2\beta-2}H^{-1}\|r\|_2^2)$。

若 $u_j\ne u_k$，其主项交叉和除以 $M^{2\beta-2}$ 为
\[
 \frac1H\sum_{h>0}b_{jk}(h/H)
 e^{iH(\Phi_{u_j}-\Phi_{u_k})(h/H)},                      \tag{7}
\]
其中 $b_{jk}$ 是固定光滑紧支撑函数；因 $J$ 有限，其范数一致有界。写 $\delta=u_j-u_k$。相邻 $h$ 的相位增量为
\[
 -2\pi\delta H\log(1+1/h)
 =-2\pi\delta/t+O(H^{-1}),
\]
它随 $h$ 单调变化。由 $0<|\delta|<1/2$ 和 $1/2\le t\le4$，其到 $2\pi\mathbb Z$ 的距离有只依赖这一固定配对的正下界。对几何和作一次离散分部求和（或用一阶导数指数和引理），(7) 的未除以 $H$ 的和为 $O_{j,k}(1)$；再对光滑的 $b_{jk}$ 分部求和，得到 (7) 为 $O_{j,k}(H^{-1})$。这证明 (3)。

最后，对每个固定 $u$，式 (1) 的非负连续密度在某个开区间严格为正。若
$\int\eta(u/x)x^{2\beta-4}\phi(x)^2|\sum_{j:u_j=u}z_jx^{i\lambda_j}|^2dx=0$，则有限指数多项式 $\sum_jz_je^{i\lambda_j y}$ 在一个 $y=\log x$ 开区间上恒零；对它在一点连续求导 $0,\ldots,J_u-1$ 次，频率互异的 Vandermonde 矩阵可逆，故所有 $z_j=0$。所以每组 Gram 矩阵严格正定。式 (3) 中的 $M^{i\lambda_j}$ 只是各组的对角酉变换，最小特征值不随 $M$ 变化。组数有限且异组交叉为 $o(1)$，于是得到统一的 (4)。$\square$

## 与真实算术门的接口

scratch 974 式 (6)--(8) 只给实际 $c(m)$ 的 Dirichlet 级数、单零点留数及**条件性的**单项波包形式。式 (4) 把“有限个零点项可能恰好互相抵消”的范围缩小为：它们不能单独抵消，无论其归一化高度不同，还是同组高度相差固定量。不过实际显式公式中可能同时有随 $H$ 增长的许多零点、重零点项和轮廓余项；目前没有把它们与此有限 Gram 分离的统一估计。因此本文不推出 note 849 式 (15)、零点无禁区、全尺度局部 Weil 正性或 RH。
