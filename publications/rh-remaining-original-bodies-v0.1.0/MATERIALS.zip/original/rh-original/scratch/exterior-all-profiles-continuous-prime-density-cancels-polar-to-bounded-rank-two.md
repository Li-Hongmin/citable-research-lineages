# 槽外所有奇轮廓的连续素数密度与 polar 只差有界秩二项

日期：2026-09-30。空间与支撑沿用[槽外素数幂压缩](exterior-moving-prime-power-block-has-bounded-operator-norm.md)，常值槽计算沿用[槽外互素矩形候选](exterior-coprime-rectangle-carries-positive-fraction-of-polar-mass-candidate.md)式 (8)–(15)，任意轮廓的单槽 Archimedean 形式沿用[note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 式 (3)–(5)。本结论给出精确核分解、统一 Archimedean 下界和剩余素数谱门；尚未经过异源复核。

令 \(H=\log p\)，令 \(E_p=\bigcup_{x\in\mathcal G_p}I_x^+\subset(H,2H)\) 为上臂支撑，\(V_p^{\rm ext}\) 为对应的全部奇 \(L^2\) 轮廓。酉同构
\[
\mathcal J:L^2(E_p)\longrightarrow V_p^{\rm ext},\qquad
(\mathcal Jg)(u)=
\begin{cases}
g(u)/\sqrt2,&u\in E_p,\\
-g(2H-u)/\sqrt2,&u\in2H-E_p,\\
0,&\text{其余}
\end{cases}
\tag{1}
\]
固定上下臂的奇反射符号。记
\[
\mathsf A(g)=\int_{E_p}e^{u/2}g(u)\,du,
\qquad
\mathsf B(g)=\int_{E_p}e^{-u/2}g(u)\,du.
\tag{2}
\]

**命题。** 把旧算子的异臂素数幂移位 \(\sum_m\Lambda(m)m^{-1/2}\) 中的 \(d\Psi(t)\) 替换为连续密度 \(dt\)，在 \(L^2(E_p)\) 上所得二次型恰为
\[
K_p^{\rm cont}[g]=e^{-H}|\mathsf A(g)|^2.
\tag{3}
\]
旧 polar 向量 \(s_{p^2}(u)=\sinh((u-H)/2)\) 的压缩满足
\[
2|\langle s_{p^2},\mathcal Jg\rangle|^2
=\left|e^{-H/2}\mathsf A(g)-e^{H/2}\mathsf B(g)\right|^2.
\tag{4}
\]
因此连续素数密度与负 polar 的合形式为
\[
\boxed{\quad
K_p^{\rm cont}[g]-2|\langle s_{p^2},\mathcal Jg\rangle|^2
=2\operatorname{Re}\bigl(\mathsf A(g)\overline{\mathsf B(g)}\bigr)
-e^H|\mathsf B(g)|^2.
\quad}
\tag{5}
\]
其算子秩至多二、范数 \(O(1)\)，对 \(g\) 的槽内轮廓没有限制。

若 \(\mathcal R_{p^2}^{\rm prime}\) 只含真正素数移位，则[槽外素数幂压缩](exterior-moving-prime-power-block-has-bounded-operator-norm.md)的 (1) 与 (5) 合并给整个 \(V_p^{\rm ext}\) 上的精确归约：在 \(V_p^{\rm ext}\) 与旧 Weil 闭形式域的交上，按二次型意义有
\[
P_VA_{p^2,-}P_V
=P_VG_{p^2}P_V
+P_V\mathcal R_{p^2}^{\rm prime}P_V
-\mathcal J K_p^{\rm cont}\mathcal J^*
+D_p,
\qquad \|D_p\|_{\rm op}=O(1).
\tag{6}
\]
这里的 \(D_p\) 是延拓至全部 \(V_p^{\rm ext}\) 的有界自伴算子；它同时包含高次素数幂及 (5)，而两者均无已知有利符号。未付的算术门是真正素数移位与 (3) 的差，在**所有**槽内轮廓上的谱界。

**Archimedean 下界。** 在同一闭形式域上还成立
\[
\boxed{\quad
G_{p^2}[f]\ge\bigl((\tfrac{15}{8}-\tfrac{9}{32\zeta(2)})H-O(\log H)\bigr)\|f\|_2^2
\qquad(f\in V_p^{\rm ext}\cap D(G_{p^2})).
\quad}
\tag{6a}
\]
因而若真正素数的中心化算子
\(\mathcal E_p^{\rm prime,V}
=P_V\mathcal R_{p^2}^{\rm prime}P_V-\mathcal J K_p^{\rm cont}\mathcal J^*\)
满足 \(\mathcal E_p^{\rm prime,V}\succeq-(\tfrac{15}{8}-\tfrac{9}{32\zeta(2)}-\eta)H I\) 对某固定 \(\eta>0\)，则整个 \(V_p^{\rm ext}\) 的真实 Weil 形式有 \(\eta H-O(\log H)\) 谱隙。当前没有证明该素数谱界。

## 证明

对于 \(g\in L^2(E_p)\)，\(f=\mathcal Jg\) 的下臂取上臂反射的负值。令 \(T_t f(u)=f(u+\log t)\) 并仅保留上下臂间的交叉。对实值 \(g\) 先作计算；复值情形由极化给出。\(T_t+T_t^*\) 的两种反射配对与 \(\mathcal J\) 的两个 \(1/\sqrt2\) 因子相消，旧算术项的负号再与下臂函数的负号相消。其连续版本因而为
\[
\int_0^\infty t^{-1/2}
\int_{E_p}g(w)g(2H-w+\log t)
\mathbf1_{E_p}(2H-w+\log t)\,dw\,dt.
\tag{7}
\]
令 \(v=2H-w+\log t\)。由于 \(v,w\in E_p\) 且上下臂远离，\(t=e^{v+w-2H}>2\) 对充分大 \(p\) 恒成立；所以 (7) 的积分区间与实际算术移位 \(t\ge2\) 一致。变量替换给
\[
t^{-1/2}dt=e^{(v+w-2H)/2}dv
=e^{-H}e^{v/2}e^{w/2}dv.
\]
Fubini 遂把 (7) 化为 \(e^{-H}(\int_{E_p}e^{u/2}g(u)du)^2\)，证明 (3)。

另一方面 \(s_{p^2}(2H-u)=-s_{p^2}(u)\)，故
\[
\langle s_{p^2},\mathcal Jg\rangle
=\sqrt2\int_{E_p}\sinh((u-H)/2)g(u)du
=\frac1{\sqrt2}\left(e^{-H/2}\mathsf A(g)-e^{H/2}\mathsf B(g)\right),
\]
得到 (4)–(5)。

最后 \(E_p\) 由至多 \(O(p^2)\) 个长度 \(L\asymp p^{-2}\) 的相离槽组成，故 \(|E_p|=O(1)\)。所有 \(u\in E_p\) 满足 \(e^u=px\asymp p^2\)，因而 Cauchy–Schwarz 给
\[
\|\mathsf A\|\le\left(\int_{E_p}e^u du\right)^{1/2}=O(p),
\quad
\|\mathsf B\|\le\left(\int_{E_p}e^{-u}du\right)^{1/2}=O(p^{-1}).
\]
式 (5) 的算子范数至多
\(2\|\mathsf A\|\|\mathsf B\|+e^H\|\mathsf B\|^2=O(1)\)，秩至多二。全轮廓高次素数幂压缩的 \(O(1)\) 界由上游 note 给出，组装即得 (6)。\(\square\)

作为系数核对，对上臂归一化常值槽 \(q_{px}\)，置 \(S_L=\sinh(L/4)/(L/4)\)，直接积分给
\(\mathsf A(q_{px})=\sqrt L\,p^{1/2}x^{1/2}S_L\)、
\(\mathsf B(q_{px})=\sqrt L\,p^{-1/2}x^{-1/2}S_L\)。式 (3)、(4) 于是分别成为候选式 (9)、(10) 的矩阵系数，确认全轮廓归一化与常值槽归一化一致。

## 任意轮廓的 Archimedean 下界

note 790 式 (4) 对任一长度 \(L\) 的物理槽 \(I\) 及其任意有限能量轮廓 \(\phi\) 给出位置一致的恒等式
\[
(H_{\rm Leg}+V+c_0)[\phi]
=\bigl(\log(1/L)-\log(2\pi)-\gamma_E\bigr)\|\phi\|_2^2
+\mathfrak b[\phi_I],
\]
其中 \(\mathfrak b\ge\log2\,I\)，正则 gamma 单槽项的绝对值为 \(O(L)\|\phi\|^2\)。因为 \(L=\log(1+p^{-2})\) 且 \(\log(1/L)=2H+O(p^{-2})\)，每个单槽的完整 \(G_{p^2}\) 自能量至少为 \((2H-C)\|\phi\|^2\)，与槽位置和轮廓无关。奇反射配对只是这两个相同自能量的半权和，故在 \(V_p^{\rm ext}\) 的槽直和坐标中，自对角仍至少为 \((2H-C)I\)。

不同物理槽的完整非局部核为 note 790 使用的 \(-K(d)\)，其中 \(K(d)=e^{-d/2}/(1-e^{-2d})\)。两条长度 \(L\) 槽、中心相距 \(d>L\) 的交叉块，按 Cauchy–Schwarz 的算子范数至多 \(L K(d-L)\le L/[2(d-L)]+CL\)。同臂中心的最小对数间距为 \(\delta_p=\log(1+4p^{-2})\)。固定 \(x\)，取近邻分界 \(T_0=H^2/\sqrt p\)。每个分母 \(b'\in[\sqrt p/2,\sqrt p]\) 在 \(|y-x|\le T_0\) 的每侧有至多 \(T_0b'+1\) 个分子 \(n'\)，故每侧邻点数为 \(O(pT_0+\sqrt p)=O(\sqrt p H^2)\)。第 \(j\) 个单侧邻点的对数距离至少 \(j\delta_p\)，两侧 Schur 行和至多
\[
\sum_{j\le C\sqrt p H^2}\frac{L}{j\delta_p-L}
+O(\sqrt p H^2L)
=\frac18H+O(\log H).
\tag{8}
\]

再计 \(t=|y-x|>T_0\) 的远邻。固定分母 \(b'\) 后，保留既约条件 \((n',b')=1\) 的区间计数为
\(2T\varphi(b')+O(\tau(b'))\)，其中端点和矩形分子范围只会减少数量。标准 Möbius 求和给
\(\sum_{\sqrt p/2\le b'\le\sqrt p}\varphi(b')=\frac{3}{8\zeta(2)}p+O(\sqrt p\log p)\) 及
\(\sum_{b'\le\sqrt p}\tau(b')=O(\sqrt p\log p)\)。因此对 \(T_0\le T\le p\) 有一致计数
\[
N_x(T):=\#\{y\in\mathcal G_p:T_0<|y-x|\le T\}
\le\frac{3}{4\zeta(2)}pT+O(\sqrt p\log p\,(T+1)).
\tag{9}
\]
分部求和遂给
\(\sum_{|y-x|>T_0}|y-x|^{-1}
\le\frac{3}{4\zeta(2)}p\log(p/T_0)+O(p)\)；这里 (9) 的两个误差经积分分别贡献 \(O(\sqrt p H^2)\) 和 \(O(p/H)\)，均被 \(O(p)\) 吸收。又因 \(x,y\le p/2\)，\(|\log(x/y)|\ge2|x-y|/p\)。在 \(|x-y|>T_0\) 上 \(L/|\log(x/y)|=O((pT_0)^{-1})=o(H^{-1})\)，所以每块范数至多
\((1+o(H^{-1}))Lp/(4|x-y|)+O(L)\)。远邻的行和因此至多
\[
\frac{Lp}{4}\left(\frac{3}{4\zeta(2)}p\log(p/T_0)+O(p)\right)
+O(|\mathcal G_p|L)
=\frac{9}{32\zeta(2)}H+O(\log H).
\tag{10}
\]
式 (8)、(10) 表明整个同臂非对角块的算子范数至多 \((\frac18+\frac{9}{32\zeta(2)})H+O(\log H)\)。异臂任意两中心相距 \(\log(xy)\asymp2H\)，所以每块范数为 \(O(L/p)\)，而 \(|\mathcal G_p|=O(p^2)\)；整块范数为 \(O(p^{-1})\)。从 \((2H-C)I\) 自对角扣除这些交叉项，得到 (6a)。证明先在每槽光滑紧支撑轮廓的有限和上成立；note 790 的闭形式核心和有界交叉论证将其延伸到全部有限能量轮廓。\(\square\)

## 边界

式 (6a) 已估计 \(P_VG_{p^2}P_V\) 的全轮廓谱底。[note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 进一步证明，本稿式 (6a) 后提出的独立中心化素数下界对全部槽轮廓为假：其谱底至多为负的 \(cp\) 量级。高频轮廓的 Archimedean 成本及 \(V_p^{\rm ext}\) 与其余物理补空间的交叉仍未支付。因此这里不证明全尺度局部 Weil 正性或 RH。
