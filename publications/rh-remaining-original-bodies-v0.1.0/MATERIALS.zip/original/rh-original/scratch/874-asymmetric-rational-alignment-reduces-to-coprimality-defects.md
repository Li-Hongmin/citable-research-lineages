# 全部负有理比例对齐项的阈值差可支付；剩余为互素缺陷谱量

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的真实高除数 Gram 及绝对过滤预算、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的远差预算。它修正 [scratch/873](873-cross-aligned-negative-rational-cofactor-resonances-have-a-one-sided-target-bound.md) 的范围：原门两侧阈值不相同。下面证明阈值差本身低于目标量级，并将**完整**负有理比例对齐族归约成三个真实谱平方量。互素缺陷平方量尚无目标上界；因此本文不支付整个族，也不证明完整 moving covariance、局部 Weil 正性或 RH。式 (3)–(4)、(13)–(14) 已通过独立代理只读复核，尚未异源复核。

## 定理

固定实函数 $\psi\in C_c^3((1,2))$ 及 $s>1$。令 $\phi(u)=\psi(u)/u$、$M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，沿用 scratch/859 的
\[
D=\left\lfloor\frac{M}{16H}\right\rfloor,\quad
R=\left\lfloor\frac{H^2}{\log^4(2M)}\right\rfloor,\quad
K_0=\frac{H^3}{\log^7(2M)},
\]
以及 scratch/860 的 $w_H,J_H$ 与 $K=K_{s,2}=C_{s,2}(M/H)(\log M)^s$。令 $\alpha(k)$ 为 scratch/873 式 (1)。记 $\mathfrak A^-_{M,H}$ 为 scratch/859 式 (12) 中如下全部**有序**物理项的 signed 和：
\[
\begin{gathered}
(a,b)=1,\quad \mu(ab)=-1,\quad t,u,v\ge1,\\
d=bu>D,\quad e=av>D,\quad m=abtu,\quad n=abtv,
\end{gathered}\tag{1}
\]
并保留原门的 $d\nmid e$、$e\nmid d$、最大约化比例 $>R$、$K_0<|m-n|\le K$。零 Möbius 项允许写入求和，贡献自然为零。

对每个 $(a,b,t)$ 令 $x=abt$、$T=D/\min(a,b)$，以及
\[
\begin{aligned}
U_{a,b,t}&=\{u\in\mathbb N:u>T,\ M<xu<2M\},\\
G_{b,h}&=\sum_{u\in U_{a,b,t}}\mu(u){\bf1}_{(u,b)=1}
\phi(xu/M)e(-hxu/M),\\
G_{a,h}&=\sum_{u\in U_{a,b,t}}\mu(u){\bf1}_{(u,a)=1}
\phi(xu/M)e(-hxu/M).
\end{aligned}\tag{2}
\]
下标 $a,b$ 指此固定三元组；只有非空 $U_{a,b,t}$ 的项进入下式。则
\[
\boxed{\quad
\mathfrak A^-_{M,H}=
\frac1{2M^2}\sum_{\substack{(a,b)=1,\ \mu(ab)=-1\\t\ge1}}
\alpha(at)\alpha(bt)\sum_h w_H(h)
\bigl(|G_{b,h}-G_{a,h}|^2-|G_{b,h}|^2-|G_{a,h}|^2\bigr)
+O_{s,\psi}\!\left(\frac{H^4}{M\log^2(2M)}\right).
\quad}\tag{3}
\]
特别地，令 $\mathfrak B_{M,H}$ 为 (1) 中仅满足 $d,e>D$、$M<m,n<2M$、$|m-n|\le K$，但未必满足共同阈值 $u,v>T$ 的物理项绝对质量。则其中**因两侧阈值不相同而漏出共同阈值的部分**满足
\[
\boxed{\quad
\mathfrak B^{\rm threshold}_{M,H}
\ll_{s,\psi}H^{-2}\log^{2s+3}(2M)
=o\!\left(\frac{H^4}{M\log^2(2M)}\right).
\quad}\tag{4}
\]
因此完整负对齐族的一个充分单侧目标条件，是 (3) 中的加权互素缺陷平方和
$M^{-2}\sum\alpha(at)\alpha(bt)\sum_hw_H|G_b-G_a|^2
\ll H^4M^{-1+\varepsilon}$。本文未证明此条件，也不能从负平方项中删去它。

## 证明

给定一个 (1) 中的四元组，$k=m/d$、$l=n/e$ 确定
$t=(k,l)$、$a=k/t$、$b=l/t$，再由 $u=d/b$、$v=e/a$ 恢复源索引。因此各三元组在有序物理项上不重复。由 $d,e>D$ 与 $m,n<2M$ 有
$at,bt<2M/D\ll H$，所以求和有限。

先证明 (4)。由 $a,b$ 对称性，只写 $a\ge b$。原门源阈值是 $u>D/b$、$v>D/a$，共同阈值为 $T=D/b$。漏项必有 $v\le D/b<u$。令 $q=at$、$x=abt=qb$；于是
\[
n=xv\le qD<m=xu,
\qquad |m-n|\le K.
\tag{5}
\]
因 $M<m,n<2M$，式 (5) 迫使 $qD\in[M-K,2M+K]$。这里 $D\asymp M/H$ 且 $K=o(M)$，故 $q\asymp H$。两个物理点都在 $qD$ 附近长度 $2K$ 的区间内；固定 $q,t,b$ 时，整数 $u,v$ 的候选对数至多
\[
O\!\left(1+\frac{K}{qb}\right)^2
=O\!\left(\frac{K^2}{q^2b^2}\right).
\tag{6}
\]
最后一个等号在此参数域一致成立：$b\le a=q/t\le q\ll H$，而 $K/(qb)\gg M/H^3\to\infty$。由 scratch/859 式 (2)，每个物理项的绝对值至多
$O_{\psi}(H\log^2(2M)/M^2)$。忽略互素条件和 Möbius 零点只会增大上界。给定 $q$，有 $t\mid q$、$a=q/t$、$1\le b\le a$。用 $\sum_{b\ge1}b^{-2}<\infty$ 及 $\sum_{q\asymp H}\tau(q)\ll H\log(2H)$，得到
\[
\begin{aligned}
\mathfrak B^{\rm threshold}_{M,H}
&\ll_{s,\psi}\frac{H\log^2(2M)}{M^2}K^2
\sum_{q\asymp H}\frac{\tau(q)}{q^2}\\
&\ll_{s,\psi}\frac{K^2\log^3(2M)}{M^2}
\ll_{s,\psi}H^{-2}\log^{2s+3}(2M).
\end{aligned}\tag{7}
\]
另一取向 $b>a$ 同理。与 $H^4/(M\log^2M)$ 比较，(7) 的比值至多
$O(M\log^{2s+5}M/H^6)=O(M^{-1/5}\log^{2s+5}M)=o(1)$，证明 (4)。

现在把原门过滤暂时全部撤去，并只取 $u,v\in U_{a,b,t}$。对固定 $(a,b,t)$，scratch/859 式 (2) 给
\[
b_{bu}(xu)=-\frac{\alpha(at)}M\phi(xu/M),\qquad
b_{av}(xv)=-\frac{\alpha(bt)}M\phi(xv/M).
\tag{8}
\]
因为 $\mu(ab)=-1$，$a,b$ 都平方自由，且
\[
\mu(bu)=\mu(b)\mu(u){\bf1}_{(u,b)=1},\qquad
\mu(av)=\mu(a)\mu(v){\bf1}_{(v,a)=1},\qquad
\mu(a)\mu(b)=-1.
\tag{9}
\]
故该三元组的未过滤子和精确是
\[
-\frac{\alpha(at)\alpha(bt)}{M^2}
\sum_h w_H(h)G_{b,h}\overline{G_{a,h}}.
\tag{10}
\]
$\psi$ 为实函数且 $w_H$ 为实偶权，所以 $G_{b,-h}=\overline{G_{b,h}}$、$G_{a,-h}=\overline{G_{a,h}}$；式 (10) 为实数。用
$-2\operatorname{Re}(z\bar w)=|z-w|^2-|z|^2-|w|^2$，即得 (3) 的主项。

最后恢复过滤。scratch/859 式 (8)、(8a)、(8b)、(10) 分别对**全部**高除数物理项给出对角与非对角整除关系合计
$O(H^2\log^3(2M)/M)$、低约化比例和近物理差各
$O(H^4/(M\log^2(2M)))$ 的绝对预算；scratch/860 式 (3) 对 $|m-n|>K$ 给 $O(M^{-2})$。这些预算可用于共同阈值子族。原门与共同阈值子族之间尚有不等阈值漏项，已由 (4) 支付。又
$H^2\log^3M/M+M^{-2}=o(H^4/(M\log^2M))$，于是总误差为 (3) 所示。$\square$

## 最小未付元

式 (2) 给
\[
G_{b,h}-G_{a,h}=\sum_{u\in U_{a,b,t}}\mu(u)
\bigl({\bf1}_{(u,b)=1}-{\bf1}_{(u,a)=1}\bigr)
\phi(xu/M)e(-hxu/M).
\tag{11}
\]
所以剩余的正谱量完全来自两个源模数的互素条件差。最简单的实例是 $(a,b,t)=(3,1,1)$：此时 $T=D$、$x=3$，并有精确恒等式
\[
G_{1,h}-G_{3,h}
=-\sum_{\substack{v>D/3,\ (v,3)=1\\M<9v<2M}}
\mu(v)\phi(9v/M)e(-9hv/M).
\tag{12}
\]
这是真实 Möbius 短 cofactor 的观察频带谱量。式 (12) 只是明确未付量，不能用 scratch/873 的负平方核心界代替它。

## 平方自由物理层的完整单侧界

把 $\mathfrak A^-_{M,H}$ 再限制为 $\mu(m)^2=\mu(n)^2=1$，记为 $\mathfrak A^-_{M,H,\mathrm{sf}}$。对每个 $(a,b,t)$，定义
\[
F^{\mathrm{sf}}_{a,b,t,h}
=\sum_{\substack{u\in U_{a,b,t}\\\mu(xu)^2=1}}
\mu(u)\phi(xu/M)e(-hxu/M),\qquad x=abt.
\tag{13}
\]
若 $\mu(xu)^2=1$，则 $(u,x)=1$，特别是 $(u,a)=(u,b)=1$；同样适用于 $v$。因此在这个物理层上，式 (9) 两侧的互素指示同为 $1$，共同阈值的未过滤子和是一个负平方。式 (4) 与 scratch/859--860 的绝对预算在限制子族后仍成立，故
\[
\boxed{\quad
\mathfrak A^-_{M,H,\mathrm{sf}}
=-\frac1{M^2}\sum_{\substack{(a,b)=1,\ \mu(ab)=-1\\t\ge1}}
\alpha(at)\alpha(bt)\sum_h w_H(h)
|F^{\mathrm{sf}}_{a,b,t,h}|^2
+O_{s,\psi}\!\left(\frac{H^4}{M\log^2(2M)}\right)
\ll_{s,\psi}\frac{H^4}{M\log^2(2M)}.
\quad}\tag{14}
\]
这支付了**平方自由物理层的全部负有理比例对齐项**，不限于 scratch/873 的共同互素核心。

反过来，式 (11) 中每个非零差项都满足某个素数 $p\mid(u,ab)$，从而 $p^2\mid xu$。所以互素缺陷完全落在非平方自由物理点。由 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (29)--(30)，完整观察系数可在目标量级内换成仅支持平方自由物理点的三通道系数；但该替换是对**所有除数项先聚合后的 Fourier 和**作出的。它不能逐项套在 (1) 的所选对齐子族上，不能由 (14) 推出未限制的 $\mathfrak A^-_{M,H}$ 或完整 signed Gram 的目标界。
