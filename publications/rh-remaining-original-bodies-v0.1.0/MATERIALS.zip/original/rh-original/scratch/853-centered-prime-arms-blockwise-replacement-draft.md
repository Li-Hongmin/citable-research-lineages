# 两条素数臂的逐臂中心化与逐块替换（待异源复核）

依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的记号、式 (29)--(33) 及 [冻结 SPEC](../SPEC-2026-09-24-moving-covariance.md)。以下式号接续 note 849；异源复核未完成，暂不晋级。

## 两条素数臂的逐臂中心化

在同一单格变量 $m$ 中，还可把 (29) 的两条素数臂分别减去各自
相对于整数格的平滑密度。定义
\[
c_\circ(m)=
-4\bigl(\mathbf1_{m=p\text{ for a prime }p}\log p-1\bigr)
+\bigl(2\mathbf1_{m=2p\text{ for a prime }p}\log p-1\bigr)
-4(\log2)\mu(m),
\qquad
\mathcal A_h^\circ=
\sum_{M<m<2M}\frac{c_\circ(m)}m
\psi(m/M)e(-hm/M).
\tag{34}
\]
第一素数臂的整数格平均为 $-4$，第二素数臂的平均为 $+1$；
两臂的合计平滑密度为 $-3$，故 $c_\circ=c_{\rm tri}+3$。
与完整 (10) 比较，逐系数精确得到
\[
c(m)-c_\circ(m)
=1-2\mathbf1_{2\mid m}
+2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m).
\tag{35}
\]
这里留下的非素数幂背景只是交替奇偶序列。由于 $M=2Y$，
Poisson 求和给它在低观察频率上的精确别名式
\[
\sum_m(1-2\mathbf1_{2\mid m})w(m)e(-hm/M)
=-\sum_{j\in\mathbb Z}\widehat\varphi(h-Y+2jY).
\tag{36}
\]
当 $\eta(h/H)\ne0$ 且 $Y^{1/5}\le H\le Y^{1/4}$ 时，
$|h|\le4H=o(Y)$，所以 (36) 的每个 Fourier 参数距零至少
$Y-4H\asymp Y$。因 $\varphi\in C_c^3$，(36) 一致为
$O_\psi(Y^{-3})$。式 (33) 对两项高次素数幂仍给逐频
$O_\psi(Y^{-1/2}\log(2Y))$。因此
\[
\boxed{\quad
\sum_h\eta(h/H)|\mathcal A_h-\mathcal A_h^\circ|^2
\ll_{\psi,\eta}
\frac{H\log^2(2Y)}Y+\frac H{Y^6}
=o\!\left(\frac{H^4}Y\right).
\quad}
\tag{37}
\]
所以 (15) 的整个频带目标也等价于 $\mathcal A_h^\circ$ 的目标。
仅凭 (37) 不能先截取距离块再作替换；尤其直接以
$c_{\rm tri}$ 代 $c$ 会丢失平滑密度 $+3$ 的跨块抵消。

实际上，**逐臂中心化**还允许对固定个距离区间作合法替换。
记
$a_m^\circ=c_\circ(m)\psi(m/M)/m$，
并令 $E\subset\mathbb Z$ 是至多 $J$ 个整数区间的并，
其中 $J$ 固定、各区间端点可随 $Y,H$ 移动。则一致有
\[
\boxed{\quad
\left|
\sum_{m-n\in E}
\bigl(a_m\overline{a_n}
-a_m^\circ\overline{a_n^\circ}\bigr)K_H(m-n)
\right|
\ll_{\psi,\eta,J}
\frac{H^2}{Y}+\frac{H\log(2Y)}{\sqrt Y}
=o\!\left(\frac{H^4}Y\right).
\quad}
\tag{38}
\]
因此 (15) 的中距离环带，也可逐块等价地改用
$a_m^\circ\overline{a_n^\circ}$。这个结论专指固定个连续距离区间；
对任意零散选出的距离集合，下面的交替求和界不再适用。

证明令 $b(m)=1-2\mathbf1_{2\mid m}=(-1)^{m+1}$，
$q(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m)$，
则由 (35) 有 $a_m-a_m^\circ=w(m)(b(m)+q(m))$。
式 (33) 与 $|w(m)|\ll Y^{-1}$ 给
\[
\sum_m|w(m)q(m)|\ll Y^{-1/2}\log(2Y),
\qquad
\sum_m|a_m^\circ|+\sum_m|w(m)b(m)|\ll1.
\tag{39}
\]
$|K_H(k)|\ll H$，所以所有含 $q$ 的交叉项及自项，总计至多
$O_{\psi,\eta}(H\log(2Y)/\sqrt Y)$。

剩下只须处理 $b$。对固定 $n$，把
$f_n(m)=w(m)K_H(m-n)\mathbf1_{m-n\in E}$ 视为整数列。
由 $\psi\in C_c^3$，
$|w(m)|\ll Y^{-1}$、
$|w(m+1)-w(m)|\ll Y^{-2}$；又由 (12)，
\[
|K_H(k)|\ll H,\qquad
|K_H(k+1)-K_H(k)|
\le\sum_h\eta(h/H)|e(-h/M)-1|
\ll H^2/M.
\tag{40}
\]
$w$ 的支撑长度为 $O(Y)$，而 $E$ 至多造成 $2J$ 个额外端点。
因此 $\sup_m|f_n(m)|+\operatorname{Var}_{m\in\mathbb Z}f_n(m)
\ll_{\psi,\eta,J}H^2/Y$，对 $n$ 一致。
交替序列 $b(m)$ 的任意前缀和绝对值至多一；离散 Abel 求和遂给
$|\sum_m b(m)f_n(m)|\ll H^2/Y$。
若 $b$ 位于 $n$ 列，交换 $m,n$ 并把 $E$ 换成同样由至多
$J$ 个区间组成的 $-E$，得到相同界。
外层与 $a^\circ$ 或 $wb$ 配对时使用 (39) 的 $\ell^1$ 界，
得到所有含 $b$ 的项为 $O(H^2/Y)$，证明 (38) 的不等式。
最后 $H^{-2}\to0$，
$\sqrt Y\log(2Y)/H^3\to0$ 在 $H\ge Y^{1/5}$ 上一致，
故 (38) 的末个 $o$ 成立。$\square$

## 奇偶格各自中心化的精确版本

还有一项完全精确的改写，省去先剔除素数幂的步骤。对 $M<m<2M$ 令
\[
c_{\mathrm{pc}}(m)=c(m)-4(-1)^m.
\tag{41}
\]
由 note 849 式 (10) 逐奇偶格展开，得到
\[
c_{\mathrm{pc}}(m)=
\begin{cases}
-4\bigl(\Lambda(m)-2\bigr)-4(\log2)\mu(m),
&m\text{ 为奇数},\\
2\bigl(\Lambda(m/2)-1\bigr)-4\Lambda(m)-4(\log2)\mu(m),
&m\text{ 为偶数}.
\end{cases}
\tag{42}
\]
奇格上 $\Lambda$ 的平滑密度为 $2$，偶格上
$\Lambda(m/2)$ 的平滑密度为 $1$；式 (42) 因而将两条素数臂
分别在其原生格上中心化。偶格的 $\Lambda(m)$ 在当前范围仅来自
$2$ 的高次幂，可再按 note 849 式 (33) 支付。

若 $a_m^{\mathrm{pc}}=c_{\mathrm{pc}}(m)\psi(m/M)/m$，
$E$ 为至多 $J$ 个距离区间的并，则前述交替求和证明在
$q=0$ 的情形直接给
\[
\left|\sum_{m-n\in E}
\bigl(a_m\overline{a_n}
-a_m^{\mathrm{pc}}\overline{a_n^{\mathrm{pc}}}\bigr)
K_H(m-n)\right|
\ll_{\psi,\eta,J}\frac{H^2}{Y}
=o(H^4/Y).
\tag{43}
\]
这一步只用 $c-c_{\mathrm{pc}}=4(-1)^m$、$\sum|a_m|\ll1$
及 $K_H$ 的离散变差界，未使用素数或 Möbius 短区间定理。
因此真实未付项可直接取为式 (42) 两条各自在奇偶格中心化的
von Mangoldt 通道与完整 Möbius 通道的联合 signed Gram。
