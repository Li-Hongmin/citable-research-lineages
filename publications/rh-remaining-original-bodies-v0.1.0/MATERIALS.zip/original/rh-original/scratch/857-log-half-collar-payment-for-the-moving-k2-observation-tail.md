# 完整移动 $k=2$ 余项的四分之一次幂除以平方根对数观察尾（待异源复核）

日期：2026-10-01。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (1)、(7)--(11)、(23)--(26) 和 [note 847](../notes/847-quarter-power-observation-fourier-tail-for-full-k2-residual.md) 的高频尾。外部输入：D. R. Heath-Brown, *Prime Numbers in Short Intervals and a Generalized Vaughan Identity*, *Can. J. Math.* **34** (1982), 1365--1377, DOI 10.4153/CJM-1982-095-9；2026-10-01 直接读取 Cambridge 原 PDF，p. 1369 式 (10) 与 p. 1377 结论给 $\sum_{x-y<n\le x}\Lambda(n)=y+O(y/\log x)$，一致覆盖 $y\asymp x^{2/3}$（所需指数严格大于 $7/12$）。Möbius 输入仍为 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 核对的 Matomäki--Shao--Tao--Teräväinen 2023 全区间最大进程定理。本结果只是无条件的对数尺度高频推进，不证明低频算术门或 RH。

**目标量纲校正：**note 847 式 (2) 对任意 $H$ 已给 $Y^3\log Y/H^4$；取本稿的 $H_*$ 便是 $Y^2\log^3Y=Y^{2+o(1)}$。故本稿仅将该 polylog collar 的显式对数损失从三次降到一次，**不推进 RH 所需的固定幂截止**。其方法价值限于核对素数输入的量化强度；不应作为下一条主攻路线或永久结果晋级。

## 定理

令 $Y\to\infty$ 沿整数，$\psi\in C_c^3((1,2))$ 固定，
$W_N=\psi(N/Y)\mathcal R_{N,2}$，并按 note 847 定义其长度 $Y$ 的离散 Fourier 系数 $S_h(Y)$ 及 $q(h)=\min(h,Y-h)$。置
\[
 H_*(Y)=\left\lceil\frac{Y^{1/4}}{\sqrt{\log(2Y)}}\right\rceil.
\]
则无条件地有
\[
 \boxed{\quad
 \frac1Y\sum_{\substack{0\le h<Y\\q(h)\ge H_*(Y)}}|S_h(Y)|^2
 \ll_\psi Y^2\log(2Y).
 \quad}\tag{1}
\]
相较 note 847 在同一截止直接给的 $Y^2\log^3Y$，这里把显式上界改为 $Y^2\log Y$；二者都属于 $Y^{2+\varepsilon}$ 量级，未改变固定幂低频门。

## 一条固定频带的定量算术估计

取 $Y^{1/5}\le H\le Y^{1/4}$，令 $M=2Y$、$B=\lfloor Y^{2/3}\rfloor$、$L=\lfloor Y/(16H)\rfloor$，并沿用 note 849 的
\[
 c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
 -4(\Lambda(m)-1+(\log2)\mu(m)),
 \quad a_m=\frac{c(m)}m\psi(m/M),
 \quad \mathcal A_h=\sum_m a_me(-hm/M).
\]
对充分大 $Y$，$B\log^2Y=o(L)$，因为 $L\gg Y^{3/4}$。Heath-Brown 的上述 $O(B/\log Y)$ 定量短区间式适用于任意起点 $x\asymp Y$ 的长度 $B$ 整块，也适用于偶格项缩放后的长度 $B/2$ 整块。note 835 的 Möbius 定理给长度 $B$ 整块的 $O_A(B/\log^A Y)$ 界，且给所有前缀。常数背景与奇偶计数在整块上的误差为 $O(1)$。因此对任意长度 $B$ 的整块 $I\subset(M,2M)$，
\[
 \left|\sum_{m\in I}c(m)\right|\ll B/\log Y.
\tag{2}
\]
这里 $B/2$ 及端点取整改变素数短区间长度至多 $O(1)$，只产生 $O(\log Y)$ 误差，已被 (2) 吸收。

任意长度至多 $L$ 的整数区间 $I\subset(M,2M)$ 可分成长度 $B$ 的整块和至多两个不足 $B$ 的端块。端块以 $|c(m)|\ll\log Y$ 支付；因为 $B\log^2Y=o(L)$，得到对**所有**此类区间的统一界
\[
 \sup_{|I|\le L}\left|\sum_{m\in I}c(m)\right|
 \ll L/\log Y.
\tag{3}
\]
若 $w(m)=\psi(m/M)/m$，则 $|w|\ll Y^{-1}$、$|w(m+1)-w(m)|\ll Y^{-2}$。对 (3) 作一次离散 Abel 求和，得到
\[
 \sup_{|I|\le L}\left|\sum_{m\in I}a_m\right|
 \ll_\psi L/(Y\log Y).
\tag{4}
\]
由于 $\psi$ 紧支撑于 $(1,2)$，长度 $L=o(Y)$ 的周期窗穿过拼接点时仅经过零值区；(4) 也适用于 $\mathbb Z/M\mathbb Z$ 的每个长度 $L$ 窗。

note 849 式 (26) 的几何和及周期 Parseval 因而给，对其固定非负频带权 $\eta$，
\[
 \boxed{\quad
 \sum_h\eta(h/H)|\mathcal A_h(Y)|^2
 \ll_{\psi,\eta}\frac{M}{L^2}\sum_{x\bmod M}
 \left|\sum_{j=0}^{L-1}a_{x-j}\right|^2
 \ll_{\psi,\eta}\frac1{\log^2Y}.
 \quad}\tag{5}
\]
取 $S_h=T_h+E_h$ 为 note 849 式 (1) 的两端点主项与误差。其式 (7)、(9) 与 (5) 给
\[
 \frac1Y\sum_{H\le|h|<2H}|S_h(Y)|^2
 \ll_\psi
 \frac{Y^3}{H^4\log^2Y}
 +\frac{Y^3}{H^5}+\frac{H^5}{Y}.
\tag{6}
\]
这里 $H\le Y^{1/4}$ 保证 $|h|<2H<Y/2$，可直接调用 note 849 的展开。

## 频带拼接

对 $H\ge H_*$ 且 $H\le Y^{1/4}$，(6) 的首项至多 $Y^2$；第二项在 $H=H_*$ 最大，为
$Y^{7/4}(\log Y)^{5/2}=o(Y^2)$；第三项更小。因此每个这样的 dyadic 频带贡献 $O_\psi(Y^2)$。从 $H_*$ 到 $Y^{1/4}$ 只有 $O(\log\log Y)$ 条频带，总计 $O_\psi(Y^2\log\log Y)$。对 $q(h)\ge\lceil Y^{1/4}\rceil$ 使用 note 847 式 (2)，贡献 $O_\psi(Y^2\log(2Y))$。合并即得 (1)。$\square$

## 边界

式 (5) 是一个真正的算术对数节省，来自原始素数短区间定理的显式一位对数误差及 Möbius 全区间短和；它只在 $H^4/Y\ge(\log Y)^{-2}$ 的四分之一次幂对数 collar 足以支付目标。向 $H=Y^{1/4-\delta}$ 移动时，$H^4/Y=Y^{-4\delta}$，任何固定对数幂都不足以完成 note 849 式 (15)。新的未付频带仍须真实三通道 signed covariance 的固定幂节省，不能由这条高频推进外推为 RH。
