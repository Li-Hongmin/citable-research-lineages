# 全部多项式载波上的真实 Fejér 邻近分子包与中央素数源负协方差

日期：2026-10-02。沿用 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1)、(2) 的真实物理短管和中央素数源，以及 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的精确原始 Poisson 项。Fejér 导数的离散质量证明见 [scratch/944](944-true-terminal-fejer-packet-reduces-to-one-half-integer-parity-mobius-comb.md) 式 (4)–(8)；下面重新列出实际用到的估计。[scratch/940](940-full-terminal-tube-has-a-four-corner-signed-covariance-cycle.md) 已对 $\log\log Y$ 宽的未加权邻近分子给出四块协方差循环，本文新增的是 $T\asymp\sqrt H$ 的多项式宽度、非负 Fejér 分子权。外部输入是 Matomäki–Shao–Tao–Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, *Forum Math. Pi* **11** (2023), e29, DOI 10.1017/fmp.2023.28, Theorem 1.1(i) 与式 (1.4)。2026-10-02 从 ResearchLibrary 中的发表版全文核对：其最大进程界取常数 nilsequence，包含区间内所有前缀，并在长度 $X^{5/8+\eta}\le B\le X^{1-\eta}$ 时给任意固定对数幂节省。本解析证明尚待异源复核；它不估计未经加权的完整残差，也不证明 RH。

## 命题

固定 $0<\gamma<1/4$，令 $Y\to\infty$ 沿整数，$H=\lfloor Y^\gamma\rfloor$，
$T=\lfloor\sqrt H\rfloor$，$w_{j,T}=(1-|j|/T)_+$。对
$H<a\le11H/10$ 定义
$t_a=\lfloor aY/H\rfloor$、
$B_a=\lfloor t_a^2/(aY\log Y)\rfloor$、
$I_a=(t_a,t_a+B_a]\cap\mathbb Z$。对 $3Y/2<N\le8Y/5$，令

\[
P_{T,H}(N)=\sum_{H<a\le11H/10}\ \sum_{q\in I_a}\ \sum_{|j|<T}
w_{j,T}F_{a+j,q}(N),
\tag{1}
\]

其中 $F_{h,q}$ 是下式 (4) 所写的 note 845 原始物理项；这里不加 $(a+j,q)=1$ 掩码。令
$G_N=\sum_a\sum_{p\in I_a\cap\mathbb P}F_{a,p}(N)$，与 note 845 式 (2) 相同。则对每个固定 $A>0$，一致于所取 $N$，

\[
\boxed{\quad
|P_{T,H}(N)|\ll_{\gamma,A}
\frac{Y}{H^2(\log Y)^A}+\frac{Y}{H^{5/2}}.
\quad}
\tag{2}
\]

因此 $\|P_{T,H}\|_2=o_\gamma(\|G\|_2)$，而 $E_{T,N}=P_{T,H}(N)-G_N$ 满足真实原始 Poisson 项的 signed covariance 渐近式

\[
\boxed{\quad
\sum_{3Y/2<N\le8Y/5}G_NE_{T,N}
=-(\kappa+o_\gamma(1))\frac{Y^3}{H^4(\log Y)^4},
\quad}
\tag{3}
\]

其中 $\kappa>0$ 是 note 845 式 (3) 的显式积分。由于 $\gamma<1/4$，该负协方差的绝对值超过 $Y^{2+\epsilon_\gamma}$（适当固定 $\epsilon_\gamma>0$）。与 note 845 的单一中央分子管不同，$E_T$ 含中央非素数项及 $|j|<T$ 的全部带权邻近分子，且每项均为真实物理 Poisson 项。

## 精确短管上的 Fejér 分解

记 $x=q/Y$、$z=N/Y$、$u=z/x=N/q$、$t=Hx-a$、
$f_z(x)=\log(z/x)/(\pi zx)$、$c_h=1+2(-1)^h$。由 note 845 式 (6)，对充分大 $Y$，每个 $q\in I_a$ 都有
$a=\lfloor Hx\rfloor$、$0<t\ll1/\log Y$、$x\in(1,11/10+o(1))$。将上端 $11/10+o(1)$ 吸收到一个固定的略大闭区间即可；下文所有 $u$ 与整数仍保持固定距离。
note 801 的精确项为

\[
F_{a+j,q}(N)=-\mu(q)\frac{x\log(z/x)}{\pi z(a+j)^2}
r_{a+j}\!\left(\frac{x}{(a+j)z}\right)
\cos\bigl(2\pi Hz+2\pi(j-t)u\bigr),
\quad
r_h(v)=\frac{4\mathbf1_{2\mid h}}{1-4v^2}-\frac1{1-v^2}.
\tag{4}
\]

由于 $T\le H/4$、$a+j\asymp H$，有 $r_{a+j}(x/((a+j)z))=c_{a+j}+O(H^{-2})$。把 $s=j-t$ 代入

\[
\frac{x}{(a+j)^2}
=\frac1{xH^2}-\frac{2s}{x^2H^3}
+O\!\left(\frac{s^2}{H^4}\right).
\tag{5}
\]

Fejér 核 $\mathsf F_T(v)=\sum_jw_{j,T}e(jv)$ 满足
$\|\mathsf F_T\|_1\ll1$、$\|\mathsf F_T'\|_1\ll T$、
$\|\mathsf F_T''\|_1\ll T^2$，并且

\[
\sum_jw_{j,T}c_{a+j}e(ju)
=\mathsf F_T(u)+2(-1)^a\mathsf F_T(u+1/2),
\quad
\sum_jj w_{j,T}c_{a+j}e(ju)
=\frac{\mathsf F_T'(u)+2(-1)^a\mathsf F_T'(u+1/2)}{2\pi i}.
\tag{6}
\]

因 $q\asymp Y$ 且 $x\mapsto z/x$ 是双 Lipschitz 映射，对全部相关整数 $q$ 的 Riemann 求和及总变差给

\[
\sum_q\left|\mathsf F_T'(N/q+\beta)\right|\ll YT+T^2,
\quad
\sum_q\mathsf F_T(N/q+\beta)\ll Y+T,
\qquad \beta\in\{0,1/2\}.
\tag{7}
\]

将 (5) 保留到分子 $j$ 求和之后再用 (6)–(7)，一次项的总绝对误差为
$O((YT+T^2+(Y+T)/\log Y)/H^3)$；二次余项由
$\sum_jw_{j,T}(j-t)^2\ll T^3$ 给 $O(YT^3/H^4)$；$r_h-c_h$ 给 $O(YT/H^4)$。这里仅用 $|\mu(q)|\le1$，并始终保留真实 $I_a$，没有几何窗口替换。取 $T=\lfloor\sqrt H\rfloor$ 后，上述总误差为 $O(Y/H^{5/2})$。由 (6) 的首式及 $Hz-tu=au$，得

\[
P_{T,H}(N)=P^{\rm even}_{T,H}(N)+P^{\rm odd}_{T,H}(N)
+O(Y/H^{5/2}),
\tag{8}
\]

\[
\begin{aligned}
P^{\rm even}_{T,H}(N)&=-H^{-2}\sum_a\sum_{q\in I_a}
\mu(q)f_z(x)\mathsf F_T(u)\cos(2\pi au),\\
P^{\rm odd}_{T,H}(N)&=-2H^{-2}\sum_a(-1)^a\sum_{q\in I_a}
\mu(q)f_z(x)\mathsf F_T(u+1/2)\cos(2\pi au).
\end{aligned}
\tag{9}
\]

所取 $u$ 距整数有固定间隔，故 $\mathsf F_T(u)\ll T^{-1}$。用 $\#\bigcup_a I_a\ll Y$，

\[
|P^{\rm even}_{T,H}(N)|\ll\frac{Y}{H^2T}
\ll\frac{Y}{H^{5/2}}.
\tag{10}
\]

## 真 Möbius 奇胞的逐管对数消减

note 845 式 (6) 给 $B_a\asymp Y/(H\log Y)$、$t_a\asymp Y$。取固定
$0<\eta<\min\{\gamma/2,(3/8-\gamma)/2\}$，则对充分大 $Y$，
$t_a^{5/8+\eta}\le B_a\le t_a^{1-\eta}$，一致于全部 $a$。上述 2023 年定理的常数 nilsequence 特例及最大进程定义因此给任意固定 $R>0$ 的统一前缀界

\[
\max_{v\in I_a}\left|\sum_{\substack{q\in I_a\\q\le v}}\mu(q)\right|
\ll_{\gamma,R}\frac{B_a}{(\log Y)^R}.
\tag{11}
\]

设 $J_a=[t_a/Y,(t_a+B_a)/Y]$ 为包含 $I_a/Y$ 的闭区间，$g(x)=\mathsf F_T(z/x+1/2)\ge0$、
$K_a(x)=f_z(x)g(x)\cos(2\pi az/x)$。由 Fejér 核的积分、总变差及 $x\mapsto z/x$ 的有界双 Lipschitz 常数，

\[
\int_{1}^{6/5}g(x)\,dx\ll1,
\qquad \operatorname{Var}_{[1,6/5]}g\ll T.
\tag{12}
\]

每个 $J_a$ 均位于单独的 $a$ 胞左端、长度 $O((H\log Y)^{-1})$。从各 $J_a$ 选取一个达到 $g$ 最大值的点，这些点间距至少 $1/(2H)$。对每个选定点取长 $1/(4H)$ 的互不相交小区间；点值至多为该区间平均值加该区间内的变差。把这些不等式相加，(12) 给

\[
\sum_a\sup_{J_a}g
\ll H\int_{1}^{6/5}g(x)\,dx+\operatorname{Var}g
\ll H+T\ll H.
\tag{13}
\]

各 $J_a$ 互不相交，故 $\sum_a\operatorname{Var}_{J_a}g\le\operatorname{Var}g\ll T$。
此外 $f_z,f_z'$ 一致有界，而 $a\asymp H$、$|J_a|\ll(H\log Y)^{-1}$ 蕴涵
$\operatorname{Var}_{J_a}\cos(2\pi az/x)\ll1/\log Y$。乘积变差不等式遂给

\[
\sum_a\left(\sup_{J_a}|K_a|+\operatorname{Var}_{J_a}K_a\right)
\ll H+T\ll H.
\tag{14}
\]

对 (9) 的每个 $a$ 使用 (11) 作 Abel 求和，再由
$\max_aB_a\ll Y/(H\log Y)$ 和 (14)，得到

\[
|P^{\rm odd}_{T,H}(N)|
\ll_{\gamma,R}\frac1{H^2}
\frac{Y}{H(\log Y)^{R+1}}(H+T)
\ll_{\gamma,R}\frac{Y}{H^2(\log Y)^{R+1}}.
\tag{15}
\]

任取 $R>A$，(8)、(10)、(15) 即得 (2)。

## 协方差

note 845 式 (5) 给
$\|G\|_2^2\sim\kappa Y^3/[H^4(\log Y)^4]$。由 (2) 取 $A>3$，并用观测整数只有 $O(Y)$ 个，

\[
\frac{\|P_{T,H}\|_2}{\|G\|_2}
\ll_{\gamma,A}(\log Y)^{2-A}
+\frac{(\log Y)^2}{\sqrt H}=o_\gamma(1).
\tag{16}
\]

于是 $\langle G,P-G\rangle=-\|G\|_2^2+o(\|G\|_2^2)$，即 (3)。$\square$

## 多项式宽度的四块协方差循环

把 (1) 中 $q$ 限为素数所得的包记为 $\mathcal B_{T,N}$，并记
$C_{0,N}=\sum_a\sum_{q\in I_a}F_{a,q}(N)$。下面还成立

\[
\sup_N\bigl(|\mathcal B_{T,N}|+|C_{0,N}|\bigr)
=o_\gamma\!\left(\frac{Y}{H^2(\log Y)^2}\right).
\tag{17}
\]

对 $C_0$，直接在每个 $I_a$ 上用 (11)；式 (4) 中 $j=0$ 的非 $\mu$ 权在该短管上的上确界和总变差均为 $O(H^{-2})$，所以
$|C_{0,N}|\ll_{\gamma,R}Y/[H^2(\log Y)^{R+1}]$。

对 $\mathcal B_T$，先作 (8) 的 Fejér 分解。素数子集的同一幅度误差仍为 $O(Y/H^{5/2})$；偶部分由 (10) 已有 $O(Y/H^{5/2})$。只须处理奇部分。note 845 使用的 Heath–Brown 短区间素数定理对所有起点 $x\asymp Y$ 和长度 $Q=\lfloor Y^{2/3}\rfloor$ 一致成立。把 $I_a$ 的任一前缀分为长 $Q$ 的完整块和一个尾块，并除以 $\log Y$；由 $B_a\asymp Y^{1-\gamma}/\log Y\gg Q(\log Y)^3$，尾块的平凡界及素数幂均可忽略。于是存在 $\epsilon_Y\to0$，一致于 $a$ 与 $v\in I_a$，

\[
\left|\#\{p\in I_a:p\le v\}
-\frac{v-t_a}{\log Y}\right|
\le\epsilon_Y\frac{B_a}{\log Y}.
\tag{18}
\]

对上文 $K_a$ 作 Abel 求和，(18)、(14) 说明以密度 $1/\log Y$ 的连续积分代替奇部分中的素数和，其总误差在乘 $H^{-2}$ 之前为
$o(Y/(\log Y)^2)$。连续主项为

\[
\frac{Y}{\log Y}\sum_a(-1)^a\int_{J_a}K_a(x)\,dx.
\tag{19}
\]

式 (12)–(14) 的更精细版本是
$\sum_a\operatorname{Var}_{J_a}K_a\ll T+H/\log Y$：$g$ 的变差贡献 $O(T)$，而 $f_z$ 与余弦在各短管上的变化分别为 $O((H\log Y)^{-1})$、$O((\log Y)^{-1})$，它们乘 $\sum_a\sup_{J_a}g\ll H+T$。因此，把每个积分换为 $|J_a|K_a(a/H)$ 的总误差为

\[
\ll \frac1{H\log Y}\left(T+\frac H{\log Y}\right)
=o(1/\log Y).
\tag{20}
\]

又有 $|J_a|=a/(H^2\log Y)+O(Y^{-1})$。在 $x_a=a/H$ 处，
$\cos(2\pi az/x_a)=\cos(2\pi Hz)$，故替换后的交错主和为

\[
\frac{\cos(2\pi Hz)}{\pi zH\log Y}
\sum_a(-1)^a\log(z/x_a)\mathsf F_T(z/x_a+1/2)
+O((H+T)/Y).
\tag{21}
\]

相邻奇偶配对把 (21) 中的和界为其被采样函数的上确界加总变差，均为 $O(T)$。因此 (21) 为
$O(T/(H\log Y))+O(H/Y)=o(1/\log Y)$。式 (19) 遂为 $o(Y/(\log Y)^2)$；连同偶部分及幅度误差，证明 (17)。

定义三个互不相交的补块

\[
E_{\rm pc}=C_0-G,
\qquad E_{\rm np}=\mathcal B_T-G,
\qquad E_{\rm nc}=P_{T,H}-\mathcal B_T-C_0+G.
\tag{22}
\]

由 (2)、(17) 和 note 845 的 $Q_Y=\|G\|_2^2$ 渐近，Cauchy–Schwarz 给

\[
\langle G,E_{\rm pc}\rangle=-Q_Y+o(Q_Y),
\qquad
\langle G,E_{\rm np}\rangle=-Q_Y+o(Q_Y),
\qquad
\langle G,E_{\rm nc}\rangle=+Q_Y+o(Q_Y).
\tag{23}
\]

这把 scratch/940 的四块循环从 $\log\log Y$ 个未加权邻近分子扩展到 $T\asymp\sqrt H$ 的非负 Fejér 权；邻近素数与邻近非素数的贡献会互相补偿，不能把两个负项相加后当成完整残差的改善。$\square$

## 精确边界

事实上上述估计保留任意整数 $1\le T\le H/4$ 时给出

\[
|P_{T,H}(N)|\ll_{\gamma,A}
\frac{Y}{H^2(\log Y)^A}
+\frac{Y}{H^2T}+\frac{YT}{H^3}+\frac{YT^3}{H^4}.
\tag{24}
\]

取 $T\asymp\sqrt H$ 同时平衡后三项的主要幂次。特别地，$H=Y^{1/5+o(1)}$ 时，式 (24) 的算术对数项仍为 $Y^{3/5-o(1)}$，比目标 $Y^{1/2+\varepsilon}$ 多一个固定幂；证明负协方差所需的 $o(Y/(H^2\log^2Y))$ 则已经满足。本结果没有控制其余原始谐波、未经 Fejér 加权的分子和或完整 $k=2$ residual。相比 [scratch/943](943-nearby-terminal-poisson-packet-has-one-dirichlet-weighted-mertens-mode.md) 在 $H\ge Y^{2/9}$ 的目标量纲点态界，本证明只获得足以推出 (3) 的对数级抑制，但覆盖全部固定 $0<\gamma<1/4$。本节四块循环表明，负协方差本身仍不足以判定所需的完整 signed Gram 上界。
