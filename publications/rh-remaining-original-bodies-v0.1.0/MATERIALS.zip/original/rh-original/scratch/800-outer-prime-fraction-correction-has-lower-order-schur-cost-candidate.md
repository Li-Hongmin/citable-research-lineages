# 外层素数分数泄漏可作低阶 Schur 修正（候选）

日期：2026-09-29。依赖 [scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的根补全 Farey 谱模、[scratch 799](799-outer-prime-fraction-arithmetic-leakage-candidate.md) 的外层泄漏，以及 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇算子。本文只研究一批明确的外层槽；不把局部消元延伸为完整补空间结论。

## 命题

令 \(p\to\infty\) 沿奇素数，\(k=p^2\)、\(H=\log p\)，\(u_p\) 如 scratch 798，\(Z_p=Z_{p,\beta,Q}\) 如 scratch 799。固定
\[
0<\beta<1,\qquad 1<Q<2,
\qquad c_Q=1-4\left(\log Q-1+\frac1Q\right)>0.
\tag{1}
\]
写 \(B_p=P_{Z_p}A_{k,-}P_{Z_p}|_{Z_p}\)（有限维形式压缩），\(f_p=P_{Z_p}A_{k,-}u_p\)。则
\[
\boxed{
\begin{aligned}
\lambda_{\min}(B_p)&=(2-\beta)H+O_{\beta,Q}(\log\log p)>0,\\
\|B_p\|&\le(2+\beta)H+O_{\beta,Q}(\log\log p),\\
c_Q\sqrt{\beta\log Q}&\le\liminf\frac{\|f_p\|}{H}
\le\limsup\frac{\|f_p\|}{H}\le\sqrt{\beta\log Q}.
\end{aligned}}
\tag{2}
\]
唯一的外层最小能量修正 \(z_p=-B_p^{-1}f_p\in Z_p\) 满足
\[
P_{Z_p}A_{k,-}(u_p+z_p)=0,
\qquad \|z_p\|=\Theta_{\beta,Q}(1),
\qquad \frac{\|z_p\|}{\|u_p\|}=O_{\beta,Q}(H^{-1}).
\tag{3}
\]
其 Schur 能量成本 \(E_p=\langle f_p,B_p^{-1}f_p\rangle\) 有显式界
\[
\boxed{
\frac{c_Q^2\beta\log Q}{2+\beta}
\le\liminf\frac{E_p}{H}
\le\limsup\frac{E_p}{H}
\le\frac{\beta\log Q}{2-\beta}.}
\tag{4}
\]
因此 \(A_{k,-}[u_p+z_p]=A_{k,-}[u_p]-\Theta(H)>0\) 对充分大 \(p\) 成立，且
\[
\frac{A_{k,-}[u_p+z_p]}{\|u_p+z_p\|^2}
\longrightarrow c_*=1+\gamma_E+\log(2/\pi)>0.
\tag{5}
\]
这批外层槽确实造成 scratch 799 的常数级相对残差，却能够以相对范数 \(O(H^{-1})\)、相对能量 \(O(H^{-1})\) 消去该投影。式 (5) 不控制 \((\mathbb Cu_p\oplus Z_p)^\perp\) 上的残差或完整旧算子的谱底。

## 外层压缩的算术图

令 \(B=\lfloor p^\beta\rfloor\)，\(x=q/b\)、\(x'=q'/b'\) 遍历 \(Z_p\) 的指标，其中 \(p<q,q'<Qp\) 为素数、\(2\le b,b'\le B\)。note 791 的偶极归一化、自相关 \(\rho_\Delta\) 与 scratch 799 式 (5) 适用；\(\Delta=\frac12\log(1+p^{-2})\)。先把精确平移与部分重叠分开。

同臂近匹配的有理数对为 \(qb',q'b\)，二者都至多 \(Qp^{1+\beta}=o(p^2)\)。清除分母后，若非精确相等，则任何整数平移留下的非零整数差至少为一，超过槽的相对容差。因此同臂只能有精确算术边。若 \(q\ne q'\)，\(qb'/(q'b)\) 及其倒数都不是整数：\(q'\nmid qb'\)、\(q\nmid q'b\)。若 \(q=q'\)，仅留下 \(b'/b\) 或 \(b/b'\) 是素数幂的分母链边。其非负权矩阵记为 \(C_B\)，不同的 \(q\) 之间没有该类边。

异臂近匹配要求 \(qq'/(bb')\) 接近素数幂 \(n\)。精确等式 \(qq'=nbb'\) 不可能：\(q,q'>B\) 迫使 \(n\) 包含 \(q,q'\)；当 \(q\ne q'\) 时这不是素数幂，当 \(q=q'\) 时它迫使 \(n=q^r\)、\(bb'=q^{2-r}\le1\)，与 \(b,b'\ge2\) 矛盾。部分重叠令
\[
r=qq'-nbb'\ne0,
\qquad \left|\log\frac{qq'}{nbb'}\right|<2\Delta.
\tag{6}
\]
由 \(qq'<Q^2p^2\)、\(2\Delta=\log(1+p^{-2})\)，对充分大 \(p\) 有 \(|r|<Q^2+o(1)<4\)，所以 \(r\in\{-3,-2,-1,1,2,3\}\)。scratch 799 式 (5) 给出 \(|\rho_\Delta(s)|\le1\)。令 \(P_B\) 为对应的有符号算术矩阵；每条边的绝对值至多 \(c_n\)。

以严格正权 \(h_{q,b}=(qb)^{-1/2}\) 作 Schur 检验。分母链的每行满足
\[
\frac{(C_Bh)_{q,b}}{h_{q,b}}
\le\sum_{\substack{n\mid b\\n\ge2}}\Lambda(n)
+\sum_{2\le n\le B/b}\frac{\Lambda(n)}n
\le\log b+M(B/b)
\le\log B+O(1)=\beta H+O(1).
\tag{7}
\]
这里 \(M(t)=\sum_{n\le t}\Lambda(n)/n=\log t+O(1)\)；删去缺失的分母 \(1\) 只会使左边变小。反向取 \(v_b=b^{-1/2}\) 在任一个 \(q\) 块上作 Rayleigh 测试，精确行比为
\[
\frac{(C_Bv)_b}{v_b}=\log b-\Lambda(b)+M(B/b)=\log B-\Lambda(b)+O(1).
\]
由于 \(\sum_{b\le B}\Lambda(b)/b=\log B+O(1)\)、\(\sum_{2\le b\le B}1/b=\log B+O(1)\)，其 Rayleigh 商为 \(\log B+O(1)\)。结合 (7)，
\[
\lambda_{\max}(C_B)=\log B+O(1)=\beta H+O(1).
\tag{7a}
\]

固定 \(r\in\{-3,-2,-1,1,2,3\}\)。在 (6) 中，给定素数 \(q'\) 后必须有 \(b\mid qq'-r\)，且 \(m=(qq'-r)/b=nb'\)。舍去 \(b'\le B\) 的限制，用 \(\sum_{n\mid m}\Lambda(n)=\log m\) 与 \(m=(qq'-r)/b\)，得到该 \(r\) 的绝对加权行和至多
\[
\begin{aligned}
\frac{(|P_{B,r}|h)_{q,b}}{h_{q,b}}
&\le(1+o(1))
\sum_{\substack{p<q'<Qp\ {\rm prime}\\ b\mid qq'-r}}
\frac b{q'}\log\frac{qq'-r}{b}\\
&\le(2H+O(1))b
\sum_{\substack{p<q'<Qp\ {\rm prime}\\q'\equiv rq^{-1}\ (\mathrm{mod}\ b)}}\frac1{q'}
\ll_{\beta,Q}\frac b{\varphi(b)}.
\end{aligned}
\tag{8}
\]
倒数 \(q^{-1}\pmod b\) 存在，因为 \(q>b\) 为素数。若 \((r,b)>1\)，该剩余类没有 \(q'>p>b\) 的素数；否则 Brun--Titchmarsh 定理给
\[
\pi(Qp;b,rq^{-1})\le\frac{2Qp}{\varphi(b)\log(Qp/b)}
\ll_{\beta,Q}\frac p{\varphi(b)H},
\]
其中 \(\varphi\) 是 Euler 函数，且 \(b\le p^\beta\)。再用 \(q'>p\) 得 (8)。对六个 \(r\) 相加，并用 \(b/\varphi(b)\ll\log\log(3b)\) 与绝对值矩阵的加权 Schur 检验，
\[
\|P_B\|\ll_{\beta,Q}\log\log p,
\qquad \|C_B\|=\beta H+O(1).
\tag{9}
\]

不同外层中心之间的同臂有理距离至少为 \(c p^{-(1+\beta)}\)，异臂距离至少为 \(2(1-\beta)H\)，故 note 791 式 (12) 与中心排序给 \(P_{Z_p}G_kP_{Z_p}=(D_k+\log2)I+o_{\rm op}(1)\)，其中 \(D_k=2H+1-\gamma_E-\log\pi\)。由偶极零均值及 \(\|s_k'\|_\infty=O(p^{1/2})\)，每个 \(\langle s_k,w_{q/b}\rangle=O(p^{-5/2})\)；\(|Z_p|=O(p^{1+\beta})\) 使 polar 压缩范数为 \(o(1)\)。由 (7a)、(9) 与自伴矩阵谱扰动界，\(\lambda_{\min}(B_p)=D_k+\log2-\lambda_{\max}(C_B)+O_{\beta,Q}(\log\log p)\)；三角不等式同时给范数上界。这证明 (2) 的前两式。

## 交叉项与消元

对固定 \(x=q/b\)，与内层 \(u_p\) 的唯一精确算术边是 \(w_b\) 经 \(n=q\) 的乘积边，贡献 \(-c_q/\sqrt b=-\log q/\sqrt{qb}\)。确实，若 \(y=a/d\in\mathcal F_p\)，精确比例 \(x/y=n\) 将迫使 \(n=q^j\)、\(d=q^{j-1}ab\)，与 \(d<a\) 矛盾；\(y/x=n\) 将迫使 \(q\mid ab\)，不可能；精确乘积 \(xy=n\) 则迫使 \(n=q\)、\(a=bd\)，即 \(y=b\)。根 \(e_p\) 没有算术重叠。

scratch 799 式 (6)--(10) 支付全部非精确交叉，且它们在当前 \(Q<2\) 下均为非负修正。因此一致地
\[
-\frac{\log q}{\sqrt{qb}}
\le\langle w_{q/b},\mathcal R_ku_p\rangle
\le-\left(c_Q-o(1)\right)\frac H{\sqrt{qb}}.
\tag{10}
\]
scratch 799 式 (12) 及其 polar 界给 \(\|f_p-P_{Z_p}\mathcal R_ku_p\|=o(H)\)。素数定理与调和和给
\[
\sum_{p<q<Qp}\frac1q\sum_{2\le b\le B}\frac1b
=\beta\log Q+o(1),
\tag{11}
\]
从而 (10) 逐坐标平方后证明 (2) 的交叉范数界。

由 (1)--(2)，\(B_p>0\)，所以有限维配方给
\[
A_{k,-}[u_p+z]
=A_{k,-}[u_p]-\langle f_p,B_p^{-1}f_p\rangle
+\langle z+B_p^{-1}f_p,B_p(z+B_p^{-1}f_p)\rangle
\quad(z\in Z_p).
\tag{12}
\]
式 (4) 由 \(\|f_p\|^2/\|B_p\|\le E_p\le\|f_p\|^2/\lambda_{\min}(B_p)\) 得到；同样，\(\|f_p\|/\|B_p\|\le\|z_p\|\le\|f_p\|/\lambda_{\min}(B_p)\) 给 (3)。scratch 798 证明 \(\|u_p\|^2=H^2/(2\zeta(2))+O(H)\) 与 \(A_{k,-}[u_p]/\|u_p\|^2\to c_*>0\)。因 \(u_p\perp Z_p\)、\(E_p=\Theta(H)\)、\(\|z_p\|=\Theta(1)\)，(5) 随之成立。\(\square\)

## 边界

本结果只把 scratch 799 的选定外层泄漏投影消去。其他外层分数、槽内横向轮廓以及完整正交补的 Schur 反馈均未受 (9) 控制；不能从 (5) 推出全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。候选证明尚未经过异源复核，故暂不晋级永久 note。
