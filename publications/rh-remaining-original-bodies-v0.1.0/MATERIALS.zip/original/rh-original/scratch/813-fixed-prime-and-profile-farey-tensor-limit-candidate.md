# 临界全 Farey 图的固定素数与槽轮廓张量极限（候选）

日期：2026-09-29。依赖 [scratch 810](810-fixed-prime-transverse-modes-in-the-full-farey-compression-candidate.md) 的固定素数算术谱模、[scratch 812](812-odd-slot-profile-coercivity-and-interior-farey-gap-candidate.md) 的局部反对称轮廓不等式、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇算子及精确 Farey 图。以下结论涉及任意**固定有限**的素数集与轮廓空间；尚待独立复核，不晋级永久 note。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(k=p^2\)、\(\Delta=\frac12\log(1+p^{-2})\)。设 \(\mathscr H=L^2_{\rm odd}(0,2)\)，即 \(h(2-t)=-h(t)\)，并取 scratch 812 的闭形式 \(\mathfrak b_2\)。对 \(h\in D(\mathfrak b_2)\) 和合法物理中心 \(z\)，定义
\[
\phi_z^h(u)=\Delta^{-1/2}h\!\left(\frac{u-\log z+\Delta}{\Delta}\right)
\mathbf1_{|u-\log z|<\Delta},
\quad w_x^h=\frac{\phi_{px}^h+\phi_{p/x}^h}{\sqrt2}.
\tag{1}
\]
根轮廓为 \(e_p^h=\phi_p^h\)。局部反对称保证 \(w_x^h,e_p^h\in H_k^-\)。固定有限素数集 \(\mathcal P\)，对 \(S\subseteq\mathcal P\) 取 scratch 810 的 \(G_S(a,b)=\prod_{\ell\in S}(\mathbf1_{\ell\nmid ab}-(\ell-1)/(\ell+1))\)，并置
\[
u_{p,S}^h=\frac{G_S(1,1)}{\sqrt2}e_p^h
+\sum_{a/b\in\mathcal F_p}\frac{G_S(a,b)}{\sqrt{ab}}w_{a/b}^h,
\quad \lambda_S=\sum_{\ell\in S}\frac{\ell+1}{\ell-1}\log\ell,
\quad \omega_S=\prod_{\ell\in S}\frac{2(\ell-1)}{(\ell+1)^2}.
\tag{2}
\]
空积为一。对任何固定 \(S,T\subseteq\mathcal P\) 与固定 \(h,g\in D(\mathfrak b_2)\)，有**真实完整旧奇二次型**的极限
\[
\boxed{
\frac{2\zeta(2)}{H^2}\,
\mathfrak a_{p^2,-}[u_{p,S}^h,u_{p,T}^g]
\longrightarrow
\mathbf1_{S=T}\,\omega_S
\left[
\mathfrak b_2[h,g]
+\bigl(\gamma_E-\log\pi+\lambda_S\bigr)\langle h,g\rangle
\right].}
\tag{3}
\]
相应内积的同一缩放极限为
\[
\frac{2\zeta(2)}{H^2}
\langle u_{p,S}^h,u_{p,T}^g\rangle
\longrightarrow\mathbf1_{S=T}\,\omega_S\langle h,g\rangle.
\tag{4}
\]
由 scratch 812 的 \(\mathfrak b_2\succeq(\log2)I\)，每个极限块均满足
\[
\boxed{
\mathfrak b_2+(\gamma_E-\log\pi+\lambda_S)I
\succeq(\delta_*+\lambda_S)I,
\qquad \delta_*=\gamma_E+\log(2/\pi)>0.}
\tag{5}
\]
因此，对任意固定有限素数集和任意固定有限维轮廓子空间，所有这些 \(u_{p,S}^h\) 张成的真实旧奇**主压缩**在充分大 \(p\) 时严格正。这个结论允许 \(a,b\) 一直到 \(p-1\)。本式只给固定轮廓的逐点极限；[scratch 814](814-fixed-prime-farey-compression-is-uniformly-positive-for-all-odd-profiles-candidate.md) 进一步给出全部局部反对称轮廓上的一致结论，固定素数集的量词仍保留。

特别地，令 \(h_0=2^{-1/2}(1_{(0,1)}-1_{(1,2)})\)。scratch 811 的局部响应说明 \(h_0\) 不是 \(\mathfrak b_2\) 的本征轮廓，因此
\[
\log2\le\inf_{\substack{h\in D(\mathfrak b_2)\cap\mathscr H\\\|h\|=1}}
\mathfrak b_2[h]
<\mathfrak b_2[h_0]=1+\log2.
\tag{6}
\]
故 [scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的常值偶极极限 \(c_*=1+\gamma_E+\log(2/\pi)\) 在**固定共同轮廓的变分族**中可严格降低，但 (5) 保证这一族的极限仍为正。

## 调和质量与算术张量化

所有 Farey 物理槽两两分离，故任意 \(h,g\in\mathscr H\) 满足
\[
\langle w_x^h,w_y^g\rangle=\mathbf1_{x=y}\langle h,g\rangle,
\quad \langle e_p^h,w_y^g\rangle=0,
\quad \langle e_p^h,e_p^g\rangle=\langle h,g\rangle.
\tag{7}
\]
固定素数态的互素调和质量渐近独立，scratch 810 式 (4) 给
\[
\frac{2\zeta(2)}{H^2}
\sum_{a/b\in\mathcal F_p}\frac{G_S(a,b)G_T(a,b)}{ab}
\longrightarrow \mathbf1_{S=T}\omega_S.
\tag{8}
\]
根的固定质量除以 \(H^2\) 消失；(7)--(8) 证明 (4)。

对算术项，任一素数幂平移与另一 Farey 物理槽相交时必精确重合，且平移保留相对轮廓坐标。局部反对称使两臂的轮廓相同，所以包括乘积边、自环和根边在内的全部算术压缩**精确**为 scratch 798 的根补全矩阵 \(-\widetilde C_p\otimes I_{\mathscr H}\)。记 \(v_{p,S}\) 为 (2) 的根加 Farey 标量系数列。scratch 810 式 (13) 给
\[
\frac{\|\widetilde C_pv_{p,S}-(2H-2\gamma_E-\lambda_S)v_{p,S}\|}
{\|v_{p,S}\|}\longrightarrow0.
\tag{9}
\]
因此对任意固定 \(S,T,h,g\)，算术二次型等于
\[
-(2H-2\gamma_E-\lambda_T)
\langle v_{p,S},v_{p,T}\rangle\langle h,g\rangle
+o(H^2).
\tag{10}
\]
此处即使 \(S\ne T\)，也必须保留 (10) 的 \(2H\) 项，直到与 Archimedean 对角相消；仅用 (8) 不足以单独令它消失。

## Archimedean 与 polar 项

scratch 812 式 (10) 对每个物理槽给出共同的局部形式
\[
\bigl(2H-\gamma_E-\log\pi+o(1)\bigr)\langle h,g\rangle
+\mathfrak b_2[h,g].
\tag{11}
\]
根与每个 Farey 轮廓均适用。正则 gamma 的同槽误差是 \(O(\Delta)\)。对不同物理中心，由局部反对称的零均值和 note 791 的核二阶导数界，若中心距 \(d\ge3\Delta\)，其交叉块范数为 \(O(\Delta^3/d^3)\)。近邻 \(2\Delta<d<3\Delta\) 的核经端点变量化为 Carleman 型 \(1/(s+t)\)，故块范数一致 \(O(1)\)。中心排序使整个全 Farey 非对角块的算子范数为 \(O(1)\)。

固定 \(0<\alpha<1\) 时，从 \(a,b\le p^\alpha\) 的中心到任何**不同**的全族中心，间距至少 \(\gg p^{-1-\alpha}\)；矩形 Schur 检验给这部分非对角块范数 \(o(1)\)。而由 (8)，每个固定 \(S\) 的外区系数平方质量占全体的比例，先取 \(p\to\infty\) 后至多 \(O_S(1-\alpha^2)\)。先取 \(p\to\infty\)，再令 \(\alpha\uparrow1\)，便得所有固定 \(S,T,h,g\) 的 Archimedean 非对角二次型为 \(o(H^2)\)。因此 (11) 乘以系数内积，正是完整 Archimedean 二次型的主项。

极点项同样为 \(o(H^2)\)：对每个局部反对称单位轮廓，零均值和 \(\sup|s_k'|=O(p^{1/2})\) 给 \(|\langle s_k,\phi_z^h\rangle|\ll_h p^{1/2}\Delta^{3/2}\)；全族 \(O(p^2)\) 个槽的投影范数为 \(O_h(p^{-3/2})\)，故其在 (2) 的向量上的归一化形式贡献趋零。

将 (10) 与 (11) 的 \(2H\) 主项相消，再用 (8)，得到 (3)。

## 严格降低常值轮廓

在 scratch 811 的记号中，\(\mathcal B_2h_0\) 的左半槽值为 \(F(t)/\sqrt2\)，右半槽为反射负值；\(F\) 非常数且属于 \(L^2(0,1)\)。于是存在光滑、紧支撑、局部反对称的 \(g\in D(\mathfrak b_2)\)，满足 \(\langle g,h_0\rangle=0\) 且 \(\mathfrak b_2[g,h_0]\ne0\)。取实参数 \(\varepsilon\) 的符号使 \(2\varepsilon\operatorname{Re}\mathfrak b_2[g,h_0]<0\)；\(h_0+\varepsilon g\) 的 Rayleigh 商在充分小非零 \(\varepsilon\) 时严格小于 \(\mathfrak b_2[h_0]=1+\log2\)。这与 (2) 共同证明 (6)。\(\square\)

## 边界

式 (3)--(5) 排除**固定**素数态和固定有限维槽轮廓在临界全 Farey 图中给出负主压缩方向；scratch 814 将轮廓限制去掉。两者均不控制素数态数目随 \(p\) 增长、节点依赖的轮廓与无限维正交补的 Schur 反馈。式 (6) 只降低了一个正的 Rayleigh 极限，不是 RH 证明。真实 moving-\(N\) Möbius signed covariance 的 \(Y^{2+\varepsilon}\) 上界仍未证明。
