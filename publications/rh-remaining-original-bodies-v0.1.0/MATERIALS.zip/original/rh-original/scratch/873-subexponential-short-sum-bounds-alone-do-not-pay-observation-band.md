# 次指数全区间短和界本身不支付观察频带固定幂门

日期：2026-10-03。针对 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 的短和输入与 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (15) 的固定幂目标。这是**非算术系数反模型**，不反驳真实 \(\Lambda\)--\(\mu\) 系数或 RH。解析证明尚待异源复核。

## 命题

固定任意 \(c>0\)，令 \(V_Y=(\log Y/\log\log Y)^{1/3}\)、\(\delta_Y=e^{-cV_Y}\)、\(M=2Y\)、\(H=\lceil Y^{1/5}\rceil\)。取非负、非零 \(\psi\in C_c^\infty((1,2))\)，并沿 note 849 的非负偶频带 \(\eta\ge1\) 于 \(1\le|t|\le2\)。存在先固定的 \(t_*\in(1,2)\) 和 \(\varepsilon>0\)，使实系数
\[
c_Y(m)=\delta_Y\cos\!\left(2\pi t_*H\log(m/M)\right)
\quad(M<m<2M),
\qquad
a_m=\frac{c_Y(m)}m\psi(m/M)
\tag{1}
\]
满足下列三项，且常数不依赖 \(Y\)：
\[
\sup_{J\subset(M,2M)}\left|\sum_{m\in J}c_Y(m)\right|
\le\delta_Y|J\cap\mathbb Z|,
\qquad
\sum_m|a_m|\ll_\psi1,
\qquad
\sum_m|a_m|^2\ll_\psi\frac{\log(2Y)}Y.
\tag{2}
\]
这里 \(J\) 遍历任意整数区间；第一式尤其强于 note 851 式 (7) 对长度 \(Y^{2/3}\) 的短块所得的 \(O(Qe^{-cV_Y})\) 形式。另一方面，对全部整数 \(H\le h\le(1+\varepsilon)H\)，
\[
\left|\sum_m a_me(-hm/M)\right|
\gg_{\psi} \delta_YH^{-1/2},
\qquad
\boxed{\quad
\sum_h\eta(h/H)\left|\sum_m a_me(-hm/M)\right|^2
\gg_{\psi,\eta}\delta_Y^2.
\quad}
\tag{3}
\]
由于对每个固定 \(0<\epsilon<1/5\) 都有
\(e^{-2cV_Y}\gg Y^{-1/5+\epsilon}=H^4Y^{-1+\epsilon+o(1)}\)，式 (2) 的**全部移动短区间界加上 note 849 式 (16) 的两个质量界**，仍不能推出式 (15) 的目标。真实系数的证明必须额外使用其算术符号或跨通道结构。

## 证明

置 \(\varphi(t)=\psi(t)/t\)，取 \(t_*\) 使 \(\varphi(t_*)>0\)。第一式由 \(|c_Y(m)|\le\delta_Y\) 逐项得到；另两式由 \(|a_m|\ll_\psi\delta_Y/M\) 及支撑内 \(O(M)\) 个整数得到，甚至分别为 \(O_\psi(\delta_Y)\)、\(O_\psi(\delta_Y^2/M)\)。

令 \(T=2\pi t_*H\)。把余弦写成两支指数。一次求积给对 \(h\asymp H\) 一致的
\[
\sum_m a_me(-hm/M)
=\frac{\delta_Y}{2}\bigl(I_h^++I_h^-\bigr)
+O_\psi(\delta_YH/M),
\qquad
I_h^\pm=\int_1^2\varphi(t)
e^{\,\pm iT\log t-2\pi iht}\,dt.
\tag{4}
\]
确实，整数求和的被积函数 \(M^{-1}\varphi(m/M)e^{\pm iT\log(m/M)-2\pi ihm/M}\) 的导数在长 \(O(M)\) 的支撑上为 \(O_\psi(H/M^2)\)，故总求积误差为 \(O_\psi(H/M)\)。

当 \(h\in[H,(1+\varepsilon)H]\) 时，\(I_h^+\) 的相位是 \(2\pi H[t_*\log t-(h/H)t]\)，唯一非退化驻点 \(t_h=t_*H/h\)。先固定充分小的 \(\varepsilon\)，使所有 \(t_h\) 落在 \(\varphi\) 严格为正的一个固定闭区间。统一驻相公式给
\[
I_h^+=e^{i\theta_h-i\pi/4}
\frac{\varphi(t_h)t_h}{\sqrt{Ht_*}}
+O_\psi(H^{-3/2}),
\qquad |I_h^+|\gg_\psi H^{-1/2}.
\tag{5}
\]
\(I_h^-\) 的相位导数为 \(-T/t-2\pi h\)，在支撑上一致为 \(\asymp-H\)；分部积分给 \(I_h^-=O_\psi(H^{-1})\)。又 \(H/M=O(Y^{-4/5})=o(H^{-1/2})\)，故 (4)--(5) 推出 (3) 的逐频下界。该区间含 \(\asymp H\) 个整数 \(h\)，且 \(\eta(h/H)\ge1\)，平方求和即得 (3)。\(\square\)

## 边界

本模型通过把一个驻相波的振幅降为 \(e^{-cV_Y}\)，精确饱和 note 851 从一致短和界得到的次指数频带量级；它没有保留 \(\mu\) 的乘法性或真实 \(\Lambda\) 系数。它关闭的是“只从这些短和上界、点态界和质量界推出固定幂”这一逻辑推断，不关闭 moving-\(N\) signed covariance 的真实算术路线。
