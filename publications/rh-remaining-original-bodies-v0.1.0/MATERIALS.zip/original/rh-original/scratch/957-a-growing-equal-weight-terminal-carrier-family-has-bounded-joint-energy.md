# 增长等权末带载波族的真实素数源联合能量保持有界

日期：2026-10-02。依赖 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的真实末带源公式、素数和 Möbius 短区间输入，以及 [note 846](../notes/846-terminal-carrier-prime-source-signed-cross-gram.md) 的载波定义。[scratch 956](956-terminal-carrier-gram-has-exponentially-small-growing-section-eigenvalues.md) 只处理先固定载波数后的极限 Gram；本文把误差写成对缓慢增长载波数一致的形式。后续 [scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 保留完整素数密度相位，将本稿的 $R=o(\log Y)$ 推进到次指数规模。此为探索证明，尚待异源复核；不证明完整 moving-$N$ 算术门或 RH。

以下 $o(1)$ 均沿任意预先选定的满足 (1) 的函数 $R(Y)$ 取极限；所有显示为 $O_\gamma$ 的常数对该范围内的 $h,r,a,N$ 一致。

## 定理

固定 $0<\gamma<1/4$，令 $Y\to\infty$ 沿整数，$H=\lfloor Y^\gamma\rfloor$。取任意整数函数 $R=R(Y)$ 满足
\[
 R\to\infty,\qquad R=o(\log Y),
\tag{1}
\]
并对 $0\le r\le R$ 置 $h_r=H+r$。按 note 845 式 (1)–(2) 以 $h_r$ 替换 $H$，在同一物理观察窗 $3Y/2<N\le8Y/5$ 定义真实素数源管 $G_r(N)$、全部互素 Möbius 分母管 $T_r(N)$。令
\[
 G^{(R)}(N)=\sum_{r=0}^R G_r(N),\qquad
 T^{(R)}(N)=\sum_{r=0}^R T_r(N),\qquad
 A_Y=\frac{Y^3}{H^4(\log Y)^4},
\]
\[
 \mathcal L(z)=\int_1^{11/10}\log(z/x)\,dx,\quad
 w(z)=\frac{\mathcal L(z)^2}{z^2},\quad
 \kappa_0=\frac1{2\pi^2}\int_{3/2}^{8/5}w(z)\,dz.
\]
则
\[
 \boxed{\quad
 \sum_{3Y/2<N\le8Y/5}|G^{(R)}(N)|^2
 =(C_\infty+o_\gamma(1))A_Y,
 \quad C_\infty:=\frac1{4\pi^2}\int_{3/2}^{8/5}
 \frac{w(z)}{\cos^2(\pi(z-3/2))}\,dz>0.
 \quad}\tag{2}
\]
与此同时，逐管对角质量为
\[
 \sum_{r=0}^R\sum_{3Y/2<N\le8Y/5}G_r(N)^2
 =(R+1)(\kappa_0+o_\gamma(1))A_Y.
\tag{3}
\]
所以全部不同载波的真实 signed cross Gram 为
\[
 \sum_{\substack{0\le r,s\le R\\r\ne s}}
 \sum_N G_r(N)G_s(N)
 =-(R+1)(\kappa_0+o_\gamma(1))A_Y
   +(C_\infty+o_\gamma(1))A_Y.
\tag{4}
\]
完整 Möbius 管联合仍满足
\[
 \sup_{3Y/2<N\le8Y/5}|T^{(R)}(N)|
 =o_\gamma\!\left(\frac{Y}{H^2(\log Y)^2}\right),
\quad
 \sum_NG^{(R)}(N)(T^{(R)}(N)-G^{(R)}(N))
 =-(C_\infty+o_\gamma(1))A_Y.
\tag{5}
\]
这些 $R+1$ 条管使用不同的既约频率，见证明。式 (2) 的联合主规模仍为 $A_Y=Y^{3-4\gamma+o(1)}$，高于 $Y^{2+\varepsilon}$ 的目标；本定理量化真实源间的抵消，不支付完整余项门。

## 一致素数源展开

以下估计对所有 $h\in[H,H+R]$、$h<a\le11h/10$、$N/Y=z\in[3/2,8/5]$ 一致。写
\[
 t_{h,a}=\lfloor aY/h\rfloor,\quad
 B_{h,a}=\left\lfloor\frac{t_{h,a}^2}{aY\log Y}\right\rfloor,
 \quad I_{h,a}=(t_{h,a},t_{h,a}+B_{h,a}]\cap\mathbb Z.
\]
由 $h\asymp H$、$a\asymp h$，
\[
 t_{h,a}=aY/h+O(1),\quad
 B_{h,a}=\frac{aY}{h^2\log Y}+O(1)
 \asymp_\gamma\frac{Y}{H\log Y},
 \quad\frac{B_{h,a}}{t_{h,a}}=O\!\left(\frac1{H\log Y}\right).
\tag{6}
\]
固定 $7/12<\vartheta<3/5$。note 851 已核对的 Ramachandra 定理应用于所有这些素数区间，给
\[
 \sum_{n\in I_{h,a}}\Lambda(n)
 =B_{h,a}+O\!\left(B_{h,a}e^{-cV_Y}+Y^\vartheta\right),
 \qquad V_Y=(\log Y/\log\log Y)^{1/3}.
\tag{7}
\]
高次素数幂在整个 $n\asymp Y$ 区域的 $\Lambda$ 质量为 $O(\sqrt Y\log Y)$。又 $B_{h,a}\gg Y^{1-\gamma}/\log Y$、$1-\gamma>3/4$，所以 $Y^\vartheta/B_{h,a}$ 和该素数幂质量除以 $B_{h,a}$ 均为固定负幂；$e^{-cV_Y}=o(1/\log Y)$。区间内 $\log p=\log Y+O(1)$，因此
\[
 \#\{p\in I_{h,a}:p\text{ prime}\}
 =\frac{B_{h,a}}{\log Y}
  \left(1+O_\gamma\!\left(\frac1{\log Y}\right)\right)
\tag{8}
\]
对全部 $h,a$ 一致。

note 845 式 (7) 的**精确**单源公式在素数 $p\in I_{h,a}$ 上为
\[
 F_{a,p}(N)=\frac{p}{\pi a^2N}\log\frac Np\,
 \left(c_a+O(H^{-2})\right)\cos\frac{2\pi aN}{p},
 \qquad c_a=4\mathbf1_{2\mid a}-1=1+2(-1)^a.
\tag{9}
\]
式 (6) 给 $p=aY/h+O(B_{h,a}+1)$，由此
\[
 \frac{aN}{p}=hz+O_\gamma(1/\log Y),\qquad
 \log\frac Np=\log\frac{zh}{a}+O_\gamma(1/(H\log Y)),
\tag{10}
\]
并且每个 $a$ 的素数权主因子满足
\[
 \frac{p}{a^2N}\frac{B_{h,a}}{\log Y}
 =\frac{Y}{z h^3(\log Y)^2}
   \left(1+O_\gamma(1/\log Y)\right).
\tag{11}
\]
把 (8)–(11) 代入 $G_h(N)=\sum_a\sum_{p\in I_{h,a}}F_{a,p}(N)$，并以相邻奇偶配对及 Riemann 求和处理
\[
 \frac1h\sum_{h<a\le11h/10}c_a\log(zh/a)
 =\mathcal L(z)+O_\gamma(1/h),
\tag{12}
\]
得到显式一致展开
\[
 \boxed{\quad
 G_h(N)=\frac{Y}{\pi h^2(\log Y)^2}
 \frac{\mathcal L(z)}z\cos(2\pi hz)
 +O_\gamma\!\left(\frac{Y}{H^2(\log Y)^3}\right).
 \quad}\tag{13}
\]
所有误差在 $h\in[H,H+R]$ 上共用同一常数，不依赖 $r$。

## 增长载波求和与能量

令 $f(z)=\mathcal L(z)/z$、$D_R(z)=\sum_{r=0}^Re^{2\pi irz}$、
$A_0=Y/[\pi H^2(\log Y)^2]$。由于 $h_r^{-2}=H^{-2}(1+O(r/H))$，(13) 给
\[
 G^{(R)}(N)
 =A_0 f(z)\operatorname{Re}\bigl(e^{2\pi iHz}D_R(z)\bigr)
 +O_\gamma\!\left(A_0\left(\frac{R+1}{\log Y}+\frac{R^2}{H}\right)\right).
\tag{14}
\]
式 (1) 使误差为 $o(A_0)$。在 $z\in[3/2,8/5]$，
$|1-e^{2\pi iz}|=2\cos(\pi(z-3/2))\ge2\cos(\pi/10)$，故几何和给
\[
 |D_R(z)|\le\sec(\pi/10)
\tag{15}
\]
一致于 $R,z$。所以 (14) 的主项也逐点为 $O_\gamma(A_0)$。
这里先把**单管波形**相加再取平方；若先把固定 $(r,s)$ 的 Gram 误差逐对相加，会无谓损失 $R^2$，不足以覆盖条件 (1) 的全部范围。

对 (14) 平方并在 $N$ 上求和，统一 $o(A_0)$ 误差给 $o(YA_0^2)=o(A_Y)$。主项平方满足
\[
 \bigl[\operatorname{Re}(e^{2\pi iHz}D_R(z))\bigr]^2
 =\tfrac12|D_R(z)|^2
 +\tfrac12\operatorname{Re}(e^{4\pi iHz}D_R(z)^2).
\tag{16}
\]
展开第二项的 $O(R^2)$ 个整数频率，均为 $2H+O(R)\asymp H$；对每项以固定光滑权 $f^2$ 作离散分部求和，归一化贡献为 $O_\gamma(R^2/H+R^2/Y)=o(1)$。第一项的离散 Riemann 求积误差也为 $O_\gamma(R^2/Y)=o(1)$。因此
\[
 \frac1{YA_0^2}\sum_N|G^{(R)}(N)|^2
 =\frac12\int_{3/2}^{8/5}w(z)|D_R(z)|^2dz+o_\gamma(1).
\tag{17}
\]
几何和给
\[
 |D_R(z)|^2
 =\frac{2-2\cos(2\pi(R+1)z)}{|1-e^{2\pi iz}|^2}.
\tag{18}
\]
分母在观察区间严格远离零；因 $R\to\infty$，Riemann--Lebesgue 引理使 (18) 的振荡积分趋零，故 (17) 的右端趋于
$\int w(z)/|1-e^{2\pi iz}|^2dz$。代入
$YA_0^2=A_Y/\pi^2$ 及 $|1-e^{2\pi iz}|^2=4\cos^2(\pi(z-3/2))$，即得 (2)。

同一一致展开 (13) 对每个 $h_r$ 的平方，使用一次离散分部求和处理 $2h_r$ 频率，给
\[
 \sum_NG_r(N)^2
 =(\kappa_0+O_\gamma(1/\log Y+R/H+H^{-1}))A_Y
\tag{19}
\]
一致于 $0\le r\le R$。求和即得 (3)，再由
$\|\sum_rG_r\|_2^2-\sum_r\|G_r\|_2^2$
得到 (4)。

## 完整 Möbius 管与频率不重叠

note 845 式 (12)–(14) 的 Möbius 全前缀估计对 $h\in[H,H+R]$ 也一致：式 (6) 使所有分母区间的长度保持 $Y^{1-\gamma+o(1)}$，可用同一 $5/8+\varepsilon$ 短区间定理；其 $K(a)$ 平均界 $\sum_{h<a\le11h/10}K(a)/a\ll1$ 对每个 $h$ 共用常数。于是对任意固定 $M>0$，
\[
 \sup_N|T_r(N)|
 \ll_{\gamma,M}\frac{Y}{H^2(\log Y)^{M+1}}
 \quad(0\le r\le R).
\tag{20}
\]
取 $M=3$ 并用 $R=o(\log Y)$，得
$\sup_N|T^{(R)}(N)|\ll A_0(R+1)/\log^2Y=o(A_0)$。
由 (2) 的 $\|G^{(R)}\|_2\asymp A_Y^{1/2}$ 与 Cauchy--Schwarz，
$|\langle G^{(R)},T^{(R)}\rangle|=o(A_Y)$，证明 (5)。

最后，同一 $a$ 在两个不同 $h_r,h_s$ 的分母中心相距
\[
 \left|\frac{aY}{h_r}-\frac{aY}{h_s}\right|
 \asymp\frac{Y|r-s|}{H},
\]
而各自 $B_{h,a}\asymp Y/(H\log Y)$，故对 $r\ne s$ 的区间不交；不同 $a$ 的既约分数 $a/q$ 由既约表示的唯一性也不可能相同。素数分母因 $p>Y\gg a$ 自动与 $a$ 互素。所以式 (4) 是不同真实 Farey 频率的交叉 Gram，而非重复计数。$\square$

## 边界

增长条件 $R=o(\log Y)$ 来自素数相位在每个 $I_{h,a}$ 内的 $O(1/\log Y)$ 变化及逐管主项的统一误差；在此条件下总误差仍为 $o(A_0)$。把 $R$ 推到固定幂规模需要重新利用管间联合相消，不能把 (13) 的绝对误差逐管相加。即使 (2) 将增长族的素数源联合能量压到一管量级，(5) 的真实合数补集仍承载必要的负协方差，完整 moving-$N$ 均方和全尺度局部 Weil 正性仍未证明。
