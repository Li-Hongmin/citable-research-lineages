# 候选：中间小分母尾仍有临界阶的真实算术跨块范数

日期：2026-09-30。待独立复核。沿 notes 807、813--816 的常值奇槽和带符号素数幂矩阵记号，令 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(r>2/(1-3/\pi^2)\)，取 \(A_p\to\infty\)、\(A_p=o((\log H)^2)\)，置 \(T=\lceil Q/A_p\rceil\)。任选固定 \(\alpha>1+1/\gamma_r\)，令 \(S=\lfloor P/H^\alpha\rfloor\)。note 816 未覆盖的内区尾为 \(M_p=\{\psi_{a/b}:S<a\le Q,\ b<T\}\)，并令 \(E_r=\{\psi_{c/d}:c>Q,\ c/d>r\}\)。则存在只依赖 \(r\) 的 \(c_r>0\)，使
\[
\boxed{\quad
c_rH\log H\le\|C^-_{E_rM_p}\|^2\le(2+o_r(1))H\log H.
\quad}\tag{1}
\]
更精确地，令 \(\mathcal E'_r=\{c/d:rQ<c\le P,\ Q/2<d\le Q,\ (c,d)=1\}\)，并取下文 (2) 的自然权向量 \(f\)，则
\[
\boxed{\quad
\frac{\|P_{\mathcal E'_r}C^-f\|^2}{\|f\|^2}
=(1+o_r(1))H\log H.
\quad}\tag{1a}
\]
因此 note 815--816 遗漏的槽数比例趋零，并不使其真实算术跨块范数低阶。式 (1)--(1a) 只判定一个粗 Schur 策略的极限，不给完整 Weil 二次型的负方向。

## 算术支撑精确隔离

令 \(B=T-1\)，充分大时 \(1\le B<Q/2\)、\(S<Q/2\) 且 \(Z=P/B\asymp H A_p\)、\(\log Z=O(\log H)=o(H)\)。在输入槽上定义非负向量
\[
f_{a/b}=\begin{cases}(ab)^{-1/2},&Q/2<a\le Q,\ 1\le b\le B,\ (a,b)=1,\\0,&\text{其他}.
\end{cases}\tag{2}
\]
其支撑包含于 \(M_p\)，并且
\[
\|f\|^2\le
\left(\sum_{Q/2<a\le Q}\frac1a\right)
\left(\sum_{b\le B}\frac1b\right)
\ll H.\tag{3}
\]

取输出 \(y=c/d\)，其中 \(rQ<c\le P\)、\(Q/2<d\le Q\)、\((c,d)=1\)，故 \(y\in E_r\)。若输入 \(x=a/b\) 在 (2) 的支撑上，同臂比 \(y/x=bc/(ad)\) 不可能是整数：由 \((c,d)=1\) 将强迫 \(d\mid b\)，与 \(b<d\) 矛盾。同样 \(x/y=ad/(bc)\) 若是整数，则 \((c,d)=1\) 强迫 \(c\mid a\)，与 \(c>a\) 矛盾。若异臂乘积 \(xy=ac/(bd)\) 是整数，则 \((c,d)=1\) 强迫 \(d\mid a\)。由于 \(Q/2<a,d\le Q\)，只能 \(a=d\)。因此 note 807 的 \(C^-=C_{\parallel}-C_{\times}\) 在这些输入输出上没有正的同臂项，且
\[
(C^-f)_{c/d}=-\frac{L_B(c)}{\sqrt{cd}},\qquad
L_B(c)=\sum_{\substack{q\mid c,\ q\text{ 为素数幂}\\ c/q\le B}}\Lambda(q).
\tag{4}
\]
这里 (4) 为精确式：每个允许的 \(q\) 唯一对应输入 \(d/(c/q)\)，且 \((c,d)=1\) 自动保证其既约。

## 大因子对数质量与互素输出

置 \(S_Z(c)=\sum_{q\mid c,\ q\le Z}\Lambda(q)\)，其中 \(q\) 遍历素数幂。因为 \(\sum_{q\mid c}\Lambda(q)=\log c\)，且 \(q>Z=P/B\) 对 \(c\le P\) 强制 \(c/q<B\)，故
\[
L_B(c)\ge\log c-S_Z(c).\tag{5}
\]
在 \(R=rQ\) 至 \(P\) 的整数上取调和权。交换求和并用
\(\sum_{R/q<m\le P/q}m^{-1}\le\log(P/R)+O(q/R)\)，得到
\[
\sum_{R<c\le P}\frac{S_Z(c)}c
\le\sum_{q\le Z}\frac{\Lambda(q)}q
\left(\log\frac PR+O\!\left(\frac qR\right)\right)
\ll(\log H)(\log Z)+\frac1R\sum_{q\le Z}\Lambda(q)
\ll(\log H)^2+\frac ZR\ll(\log H)^2.
\tag{6}
\]
这里用到 \(\sum_{q\le Z}\Lambda(q)\ll Z\)；因 \(Z\asymp HA_p\) 且 \(R\asymp P/H\)，\(Z/R\) 比任意固定对数幂都小。于是 \(S_Z(c)>H/4\) 的 \(c\) 的调和质量至多 \(O((\log H)^2/H)=o(\log H)\)。

此外初等恒等式 \(\varphi(c)/c=\sum_{e\mid c}\mu(e)/e\) 和部分求和给
\[
\sum_{R<c\le P}\frac1c=\log\frac PR+o(1)=\log H+O_r(1),
\quad
\sum_{R<c\le P}\frac{\varphi(c)}{c^2}
=\frac6{\pi^2}\log\frac PR+o(1).
\tag{7}
\]
由于 \(0\le\varphi(c)/c\le1\) 且 \(6/\pi^2>1/2\)，式 (7) 表明满足 \(\varphi(c)/c\ge1/4\) 的 \(c\) 有 \(\gg_r\log H\) 的调和质量。移去 (6) 的坏集后，仍有一集 \(\mathcal G\subset(R,P]\)，满足
\[
\sum_{c\in\mathcal G}\frac1c\gg_r\log H,
\quad \frac{\varphi(c)}c\ge\frac14,
\quad S_Z(c)\le H/4,
\quad L_B(c)\ge H/2,
\tag{8}
\]
最后一式使用 \(\log c\ge\log(rQ)=H-O_r(\log H)\) 与 (5)。

对每个 \(c\le P\)，Möbius 反演给均匀的互素分母调和质量
\[
\sum_{\substack{Q/2<d\le Q\\(d,c)=1}}\frac1d
=(\log2)\frac{\varphi(c)}c
+O\!\left(\frac{\tau(c)}Q\right)
=(\log2)\frac{\varphi(c)}c+o(1),
\tag{9}
\]
其中 \(\tau(c)\le2\sqrt c\le2\sqrt P\)、\(Q\asymp P/H\)。在 \(c\in\mathcal G\) 上，(9) 一致大于正绝对常数。由 (4)、(8)--(9)，
\[
\|P_{E_r}C^-f\|^2
\ge\sum_{c\in\mathcal G}\frac{L_B(c)^2}{c}
\sum_{\substack{Q/2<d\le Q\\(d,c)=1}}\frac1d
\gg_r H^2\log H.
\tag{10}
\]
式 (3) 与 (10) 给 (1) 的下界。上界由 \(M_p\subset I_Q\) 及 note 813 式 (7)--(10)，或 note 814 式 (1)，对整个 \(I_Q\to E_r\) 的 \((2+o_r(1))H\log H\) 范数平方界给出。\(\square\)

## 自然权向量的精确首项

对每个 \(b\le B<Q/2\)，与 (9) 相同的 Möbius 反演给
\[
\sum_{\substack{Q/2<a\le Q\\(a,b)=1}}\frac1a
=(\log2)\frac{\varphi(b)}b+O\!\left(\frac{\tau(b)}Q\right).
\tag{11}
\]
由 \(\sum_{b\le B}\varphi(b)/b^2=(6/\pi^2)\log B+O(1)\)、\(\sum_{b\le B}\tau(b)/b\ll\sqrt B\) 及 \(\log B=(1+o(1))H\)，得到
\[
\|f\|^2
=\left(\frac6{\pi^2}\log2+o(1)\right)H.
\tag{12}
\]

记 (4) 在 \(\mathcal E'_r\) 上的精确输出平方为 \(F\)。由 (9) 的一致误差、\(L_B(c)\le\log c\le H\)、\(\tau(c)/Q=o(1)\) 及 \(\sum_{R<c\le P}c^{-1}\ll\log H\)，有
\[
F=(\log2)\sum_{R<c\le P}\frac{\varphi(c)}{c^2}L_B(c)^2
+o(H^2\log H).\tag{13}
\]
式 (5)--(6) 又给
\[
0\le H-L_B(c)\ll_r\log H+S_Z(c),
\qquad
\sum_{R<c\le P}\frac{H-L_B(c)}c\ll_r(\log H)^2.
\tag{14}
\]
因 \(0\le L_B(c)\le H\)，有 \(H^2-L_B(c)^2\le2H(H-L_B(c))\)。结合 (7)、(13)--(14)，
\[
F=\left(\frac6{\pi^2}\log2+o_r(1)\right)H^2\log H.
\tag{15}
\]
式 (12) 与 (15) 相除即得 (1a)。\(\square\)

## 边界

式 (1) 是算术跨块的范数命题。输入 (2) 在真实 Weil 主压缩中还拥有自身的算术 Dirichlet 能量；外区也有正谱隙，因此不能把 (10) 单独解释为负方向。要纳入整个 \(M_p\)，仍需带符号平方项、源位置能量或真实外区逆响应；moving-\(N\) Möbius signed covariance、无限维补空间和 RH 均未解决。
