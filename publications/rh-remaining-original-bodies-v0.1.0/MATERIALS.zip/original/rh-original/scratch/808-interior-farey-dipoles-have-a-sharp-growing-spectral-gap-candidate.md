# 内部 Farey 偶极真实主压缩的增长谱隙（候选）

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的精确算术图、行恒等式及相离偶极核估计，以及 [scratch 798](798-farey-critical-weight-rayleigh-constant-candidate.md) 的接触半槽常数。这里给出后一个常数的直接核算。独立同模型复核已检查算术截断、Archimedean 误差和 Mertens 常数，未发现承重错误；异源复核尚缺，故留在 scratch。结论只涉及真实旧奇算子的有限主压缩；不判定其正交补或 RH。

## 定理候选

令奇素数 \(p\to\infty\)，\(k=p^2\)，\(L=\log k=2\log p\)。取整数 \(Q=Q(p)\) 满足 \(Q\to\infty\)、\(Q/p\to0\)，并令
\[
\mathcal F_Q=\{a/b>1:1\le b<a<Q,\ (a,b)=1\},
\qquad W_{p,Q}=\operatorname{span}\{w_x:x\in\mathcal F_Q\},
\]
其中 \(w_x\) 是 note 791 式 (1) 的归一化真实奇偶极。令 \(B_{p,Q}\) 为真实旧奇算子 \(A_{k,-}\) 在 \(W_{p,Q}\) 上的主压缩。则
\[
\boxed{\lambda_{\min}(B_{p,Q})=2\log(p/Q)+O(1).}\tag{1}
\]
特别地，\(B_{p,Q}\succ0\) 对充分大的 \(p\) 成立，且最低谱值趋于正无穷。这对任意缓慢发散的 \(p/Q\) 也成立，例如 \(Q=p/\log\log p\)。因此 Farey 偶极族内的有界或负谱方向若存在，不能完全支撑在分子、分母均为 \(o(p)\) 的统一截断内。

同一估计还给出一个固定比例版本：存在绝对常数 \(c>0\)，使 \(Q=\lfloor cp\rfloor\) 时 \(B_{p,Q}\succeq I\) 对所有充分大的奇素数 \(p\) 成立。这里不要求 \(Q/p\to0\)；从下文的下界
\(\lambda_{\min}(B_{p,Q})\ge2\log(p/Q)-O(1)-O((Q/p)^6)\)
先选足够小的固定 \(c\) 即得。因此可能的非正方向至少要进入分子或分母为 \(\ge cp\) 的宏观外圈；这仍只是主压缩的支撑限制。

更精确地，若 \(C_Q(x,y)=c_{x/y}+c_{y/x}+c_{xy}\)，\(c_t=\Lambda(t)/\sqrt t\) 当 \(t\) 为整数素数幂、否则为零，则
\[
\boxed{B_{p,Q}=\bigl(L+1-\gamma_E+\log(2/\pi)\bigr)I-C_Q+E_{p,Q},
\qquad \|E_{p,Q}\|\ll (Q/p)^6+p^{-2}.}\tag{2}
\]
同一个正权向量 \(v_{a/b}=(ab)^{-1/2}\) 给出
\[
\frac{\langle v,B_{p,Q}v\rangle}{\|v\|^2}
=2\log(p/Q)+1+\gamma_E+\log(2/\pi)+o(1).\tag{3}
\]

## 核的完整主压缩

置 \(\Delta=\frac12\log(1+p^{-2})\)。当 \(Q/p\to0\) 时，note 791 的分离证明原样适用于 \(\mathcal F_Q\)：每个偶极的两臂位于旧区间中，不同物理中心的比可写为两个不超过 \(Q^2\) 的整数之比，故不同中心的对数距离至少
\[
\delta_Q:=\log(1+Q^{-2})\gg Q^{-2}\gg\Delta.\tag{4}
\]
因而 \(\{w_x\}\) 是正交单位族。任意素数幂平移使两槽相交时，清除分母后的两个不同整数相差至少一，而容差小于 \(Q^2/p^2<1\)；故相交必须是精确整槽重合。note 791 式 (4) 遂给算术主压缩恰为 \(-C_Q\)，不含近重叠余项。

相离物理偶极的 Archimedean 交叉满足 note 791 式 (12)：中心距为 \(d\) 时绝对值至多 \(C\Delta^3/d^3\)。把全部物理中心按对数坐标排序，由 (4)，任一中心的第 \(j\) 个左右邻距至少 \(j\delta_Q\)。故全部非对角的绝对行和为
\[
O\!\left(\sum_{j\ge1}\frac{\Delta^3}{(j\delta_Q)^3}\right)
=O\!\left((Q/p)^6\right).\tag{5}
\]
同一 \(w_x\) 的两个反射臂相距至少 \(2\log(1+1/Q)\gg Q^{-1}\)，它们的交叉也被 (5) 吸收。

为确定对角常数，对一个归一化双半槽 \(\varphi_z\)，两个单半槽的共同自能量由 note 780 为
\(D_k+O(\Delta)\)，其中 \(D_k=L+1-\gamma_E-\log\pi\)。反号相邻半槽的交叉由相离核
\(K(t)=e^{-t/2}/(1-e^{-2t})=(2t)^{-1}+O(1)\) 给出
\[
\frac1\Delta\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=\log2+O(\Delta).\tag{6}
\]
故每个 \(w_x\) 的 Archimedean 对角为
\(D_k+\log2+O(\Delta+(Q/p)^6)\)。由 (5) 及 Schur 行和界，
\[
\left\|P_{W_{p,Q}}G_kP_{W_{p,Q}}-(D_k+\log2)I\right\|
\ll (Q/p)^6+p^{-2}.\tag{7}
\]
note 791 式 (5) 对全 Farey 族给出 \(\|P_{W_p}s_k\|=O(p^{-3/2})\)，限制到子族不会增大该范数，所以 polar 压缩的范数为 \(O(p^{-3})\)。式 (7) 与精确算术图证明 (2)。

## 算术谱的两侧估计

note 791 式 (14) 的推导只使用分子、分母的统一上限，故把该上限换成 \(Q\) 后，对正权 \(v_{a/b}=(ab)^{-1/2}\) 有精确行公式
\[
\frac{(C_Qv)_{a/b}}{v_{a/b}}
=\log a+\log b-\Lambda(a)\mathbf1_{b=1}
+M\!\left(\frac{Q-1}{a}\right)
+M\!\left(\frac{Q-1}{b}\right),
\quad M(t)=\sum_{n\le t}\frac{\Lambda(n)}n.\tag{8}
\]
经典估计 \(M(t)\le\log t+O(1)\) 一致地给出
\[
\frac{(C_Qv)_{a/b}}{v_{a/b}}\le2\log(Q-1)+O(1).
\]
因 \(C_Q\) 为对称非负矩阵，正权 Schur 检验给
\[
\|C_Q\|\le2\log Q+O(1).\tag{9}
\]

反向以同一 \(v\) 作 Rayleigh 测试。写 \(H=\log Q\)、\(\varepsilon(t)=M(t)-\log t\)。素数定理及 \(-\zeta'/\zeta\) 在 \(1\) 的 Laurent 常数给出 \(\varepsilon(t)\to-\gamma_E\)，并且 \(\varepsilon\) 有界。Möbius 反演给
\[
\|v\|^2=\frac{H^2}{2\zeta(2)}+O(H).
\]
对任意固定 \(0<\alpha<1\)，限制到 \(a,b\le Q^\alpha\) 后，两个 \(\varepsilon\) 一致趋于 \(-\gamma_E\)，且这一区域的 \(v^2\) 质量占比趋于 \(\alpha^2\)。外区由 \(\varepsilon\) 有界，先令 \(Q\to\infty\) 再令 \(\alpha\uparrow1\)，其影响消失。式 (8) 的单位节点删项之平均为
\(\sum_{a<Q}\Lambda(a)/a\,/\|v\|^2=O(H^{-1})\)。因此
\[
\frac{\langle v,C_Qv\rangle}{\|v\|^2}
=2\log Q-2\gamma_E+o(1).\tag{10}
\]

由 (2)、(9) 得
\(\lambda_{\min}(B_{p,Q})\ge L-2\log Q-O(1)\)；由 (2)、(10) 的试探向量得
\(\lambda_{\min}(B_{p,Q})\le L-2\log Q+1+\gamma_E+\log(2/\pi)+o(1)\)。两侧合并为 (1)，并同时证明 (3)。\(\square\)

## 边界

这里的 \(o(p)\) 是统一的分子、分母截断；不能推出每个满足 \(a,b=o(p)\) 的随 \(p\) 变化向量都有统一正性，也不能把主压缩正性提升为完整 \(A_{k,-}\) 正性。临界外圈和整个正交补的 Schur 反馈仍未控制。完整 moving-\(N\) Möbius 协方差门亦未受到 (1) 的估计。
