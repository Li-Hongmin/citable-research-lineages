# 平方自由有理对齐的整个 cofactor 谱有任意固定对数幂节省

日期：2026-10-01。依赖 [scratch/875](875-squarefree-aligned-gram-collapses-to-one-cofactor-with-explicit-prime-log-weight.md) 式 (3)--(5)、[scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的非别名核界，以及 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (6) 已核对的 Matomäki--Shao--Tao--Teräväinen 2023 全区间最大进程定理。这里证明平方自由对齐谱的对数级上界，并在真实高除数直接素数源中定位核负瓣补偿。本稿已完成逐式自检，尚无异源复核，故留在 scratch。所获节省仍是对数级；本文不证明观察频带的固定幂门、moving-\(N\) covariance、全尺度局部 Weil 正性或 RH。

## 定理

令 \(M=2Y\) 为整数，\(Y^{1/5}\le H\le Y^{1/4}\)，固定实 \(\psi\in C_c^3((1,2))\)、\(s>1\)，并取 scratch/875 的 \(\phi=\psi/u\)、\(C(x)\)、\(F_{x,h}\) 与非负带通权 \(w_H\)。置
\[
E_x:=\frac1{M^2}\sum_h w_H(h)|F_{x,h}|^2\ge0
\qquad(x\le H,\ \mu(x)^2=1).
\tag{1}
\]
则对每个固定 \(A>0\)，一致于该 \(H\) 范围，
\[
\boxed{\quad
\sum_{\substack{x\le H\\\mu(x)^2=1}}|C(x)|E_x
\ll_{A,s,\psi}(\log M)^{-A}.
\quad}\tag{2}
\]
特别地，scratch/875 式 (5) 中的**已过滤**平方自由有理对齐和满足
\[
|\mathfrak C_{M,H}^{\rm sf}|
\ll_{A,s,\psi}(\log M)^{-A}
+O_{s,\psi}\!\left(
\frac{H^4}{M\log^2(2M)}+\frac{\log^8(2M)}H\right).
\tag{3}
\]
若再固定 \(0<\theta<1/20\) 并限于 \(H\le Y^{1/4-\theta}\)，则式 (3) 的两个误差均小于任意固定负对数幂，因此
\[
\boxed{\quad
\mathfrak C_{M,H}^{\rm sf}
=O_{A,s,\psi,\theta}((\log M)^{-A})
\quad( Y^{1/5}\le H\le Y^{1/4-\theta}).
\quad}\tag{4}
\]
式 (2) 比带符号相消更强：每个 cofactor 的谱平方在求和时乘以 \(|C(x)|\)，没有利用不同 \(x\) 之间的抵消。它不达到 \(H^4M^{-1+\varepsilon}\) 在固定幂内区的量级。

## 证明

对平方自由 \(x\)，由 \(\mu(xu)=\mu(x)\mu(u)\mathbf1_{(u,x)=1}\) 得
\[
F_{x,h}=\mu(x)
\sum_{\substack{M<m<2M\\x\mid m}}
\mu(m)\phi(m/M)e(-hm/M).
\tag{5}
\]
因此 \(E_x\) 正是模数 \(x\) 的 Möbius 倍数进程的非负频带能量。由 scratch/875 式 (3a)--(3b) 与
\(S_2(x)\le(\log x)^2\)，一致有
\[
|C(x)|\ll (\log(2x))^2.
\tag{6}
\]

先处理小 \(x\)。令 \(L=\lfloor M/(32H)\rfloor\)、\(B=\lfloor M^{2/3}\rfloor\)。由 scratch/862 式 (6)，对每个固定 \(K>0\)，每个长度 \(B\) 的物理整数块及其中的任意整数等差进程 \(P\)，有
\(\sum_{m\in P}\mu(m)\ll_K B(\log M)^{-K}\)，常数不依赖进程模数。特别可取 \(P=\{m:x\mid m\}\)。把任意长度至多 \(L\) 的区间分成长度 \(B\) 的整块与至多两个端块，端块以 \(|\mu|\le1\) 支付。因为 \(B(\log M)^K=o(L)\) 对每个固定 \(K\) 一致成立，故
\[
\sup_{\substack{I\subset(M,2M)\\|I|\le L}}
\left|\sum_{\substack{m\in I\\x\mid m}}\mu(m)\right|
\ll_K L(\log M)^{-K}
\qquad(x\ge1).
\tag{7}
\]
对固定光滑权 \(\phi(m/M)\) 作 Abel 求和，令
\(a_x(m)=M^{-1}\mathbf1_{x\mid m}\mu(m)\phi(m/M)\)，便得到每个长至多 \(L\) 的窗口中
\[
\left|\sum_{m\in I}a_x(m)\right|
\ll_{K,\psi}\frac LM(\log M)^{-K}.
\tag{8}
\]
\(\phi\) 的紧支撑保证按模 \(M\) 周期化后跨接缝的窗口也满足 (8)。若 \(w_H(h)\ne0\)，则 \(H/2\le|h|\le4H\)，因而
\(V_h:=\sum_{j=0}^{L-1}e(-hj/M)\) 满足 \(|V_h|\gg L\)。周期 Parseval 及 (8) 给出
\[
E_x
\ll_s\frac{M}{L^2}
\sum_{t\bmod M}\left|\sum_{j=0}^{L-1}a_x(t-j)\right|^2
\ll_{K,s,\psi}(\log M)^{-2K}
\qquad(x\ge1).
\tag{9}
\]
这里 (9) 本身对所有 \(x\) 一致，但直接对 \(x\le H\) 求和会损失 \(H\)；下面对大 \(x\) 改用物理配对计数。

将 (1) 展开，并取物理配对的绝对值。scratch/860 的核及 scratch/868 式 (6) 给，在 \(\phi(m/M)\phi(n/M)\ne0\) 的非别名范围，
\[
|J_H(0)|\ll_s H,
\qquad
\sum_{\substack{k\ne0\\|xk|\le(1-\kappa_\psi)M}}
|J_H(xk)|\ll_{s,\psi}M/x.
\tag{10}
\]
当 \(x\le H\ll M\) 时，\((M,2M)\) 中 \(x\) 的倍数至多 \(O(M/x)\) 个。因此对每个这样的平方自由 \(x\)，对角与非对角分别给
\[
E_x\ll_{s,\psi}\frac{H}{Mx}+\frac1{x^2}.
\tag{11}
\]

取 \(Q=\lfloor(\log M)^D\rfloor\)，其中 \(D>A+3\) 固定；充分大 \(M\) 时 \(2\le Q<H\)。由 (6)、(9)，选择 \(K\) 足够大，有
\[
\sum_{x\le Q}|C(x)|E_x
\ll_{K,s,\psi}Q(\log(2Q))^2(\log M)^{-2K}
\ll_{A,s,\psi}(\log M)^{-A}.
\tag{12}
\]
由 (6)、(11) 和积分比较，尾部满足
\[
\begin{aligned}
\sum_{Q<x\le H}|C(x)|E_x
&\ll_{s,\psi}\sum_{x>Q}\frac{\log^2(2x)}{x^2}
+\frac HM\sum_{x\le H}\frac{\log^2(2x)}x\\
&\ll_{s,\psi}
\frac{\log^2(2Q)}Q+\frac HM\log^3(2H)
\ll_{A,s,\psi}(\log M)^{-A}.
\end{aligned}\tag{13}
\]
合并 (12)--(13) 证明 (2)。式 (3) 由 scratch/875 式 (5) 的已证明过滤预算立即得到。固定 \(\theta>0\) 时 \(H^4/M\ll M^{-4\theta}\)、\(H^{-1}\ll M^{-1/5}\)，从而式 (4) 成立。\(\square\)

## 对 scratch/875 式 (18)--(19) 的逐点核对

这里独立从 \(\alpha\) 的定义复算新接口，不借用上述频带估计。对大于 \(1\) 的奇平方自由 \(g\)，\(\alpha(1)=4\ell\)、\(\alpha(k)=4\log k\)（奇 \(k>1\)），而 \(\sum_{k\mid g}\mu(k)\log k=-\Lambda(g)\)，所以
\[
A(g)=4\ell-4\Lambda(g).
\tag{14}
\]
对 \(g=2z\)、\(z\) 奇且平方自由，把成对除数 \(k,2k\) 相减。\(k=1\) 的差为零；\(k>1\) 时 \(\alpha(k)-\alpha(2k)=2\log k-4\ell\)，故
\[
A(2)=0,
\qquad A(2z)=4\ell-2\Lambda(z)\quad(z>1).
\tag{15}
\]
代入 note 849 式 (29)：奇素数 \(p\) 的 \(-\mu(p)A(p)=-4\log p+4\ell\)，\(2p\) 的 \(-\mu(2p)A(2p)=2\log p-4\ell\)；其他当前物理区间内的平方自由数都给 \(-4\ell\mu(m)\)。这逐类证明 scratch/875 式 (18)。再以其已核对的 \(D_*(g)=A(g)^2\) 相减，式 (19) 立即成立。式 (14)--(15) 也确认差的支撑条件：若两个物理点都不属于奇素数或 \(2p\)，且 \(g=(m,n)\) 不属于 \(2,p,2p\)，则 \(A(m)=A(n)=A(g)=4\ell\)。这只是逐物理点的**聚合系数**恒等式；高除数截断后的单个源项不满足同一逐点相消。

## 例外素数系数的近距离盒有正常数极限

这一节加上 \(\psi\ge0\)、\(\psi\not\equiv0\)。取闭区间 \(J\subset(1,2)\)，使 \(\phi>0\) 于 \(J\)。令 \(L=\lfloor M/(32H)\rfloor\)，把 \(MJ\) 分成完整的长度 \(L\) 整数盒，舍弃两端余段。定义真实系数差的有序素数盒和
\[
\mathcal E^{\rm box}_{pp}:=\frac1{M^2}
\sum_{\substack{p,q\text{ 为奇素数}\text{位于 }MJ\text{ 的同一完整盒}\\
p\ne q,\ K_0<|p-q|\le L}}
\phi(p/M)\phi(q/M)J_H(p-q)
\{c_{\rm tri}(p)c_{\rm tri}(q)-D_*(1)\},
\tag{16}
\]
其中 \(K_0=H^3/\log^7(2M)\)。沿用 scratch/869 式 (2a) 的
\[
A_v=\int_0^1\!\int_0^1
\widehat v((u-v)/32)\,du\,dv>0,
\qquad v=\chi_s^2.
\tag{17}
\]
则在整个 \(Y^{1/5}\le H\le Y^{1/4}\) 范围一致有
\[
\boxed{\quad
\mathcal E^{\rm box}_{pp}
\longrightarrow \frac{A_v}{2}\int_J\phi(t)^2\,dt>0.
\quad}\tag{18}
\]
尤其这一真实物理子块远大于固定幂内区的 \(H^4/M\) 目标，故 scratch/875 式 (19) 的例外支撑不能按绝对质量当作误差删除。

证明如下。对不同的大奇素数 \(p,q\)，\((p,q)=1\)，所以 \(D_*(1)=16\ell^2\)；由式 (14) 与 note 849 式 (29)，
\[
c_{\rm tri}(p)c_{\rm tri}(q)-D_*(1)
=16\{\log p\log q-\ell(\log p+\log q)\}
=16\log^2M+O(\log M)
\tag{19}
\]
在 \(p,q\in MJ\) 上一致成立。scratch/862 式 (6)--(7) 的任意对数幂素数短区间定理用于长度 \(B=\lfloor M^{2/3}\rfloor\) 的整块；任意长度不超过 \(L\) 的前缀以整块加至多两个端块分割。因为 \(B\log^K M=o(L)\)，可得每个完整盒 \(I\) 及其任意前缀 \(I'\) 一致满足
\[
\sum_{n\in I'}\Lambda(n)=|I'|+o(L).
\tag{20}
\]
素数高次幂在 \((M,2M)\) 的总 \(\Lambda\) 质量为 \(O(\sqrt M\log M)=o(L)\)，且盒内 \(\log p=\log M+O(1)\)。因此，若 \(u_p\in[0,1]\) 是 \(p\) 在其盒内的归一化位置，每个盒的测度
\[
\frac{\log M}{L}\sum_{p\in I}\delta_{u_p}
\quad\Longrightarrow\quad du
\tag{21}
\]
对盒号及 \(H\) 一致地弱收敛；式 (20) 对全部前缀一致足以推出这一点。

scratch/860 式 (8) 的 Poisson 公式在同盒的 \(|p-q|\le L\) 上给
\[
\frac{J_H(p-q)}H
=\widehat v\!\left(\frac{u_p-u_q}{32}\right)+o(1)
\tag{22}
\]
一致成立，因为 \(HL/M\to1/32\)，非零别名随 \(H\to\infty\) 消失。由 \(\phi\in C^1\) 及 \(L/M\to0\)，盒内 \(\phi(p/M)\) 可一致换为盒左端的 \(\phi(t_I)\)，误差 \(o(1)\)。式 (19)、(21)--(22) 说明每个盒对 (16) 的贡献为
\[
\frac{16HL^2}{M^2}\,\phi(t_I)^2 A_v
+o\!\left(\frac{HL^2}{M^2}\right)
\tag{23}
\]
且误差在全部盒上一致。对角 \(p=q\) 的总量为 \(O(H\log M/M)=o(1)\)。被 \(|p-q|\le K_0\) 删除的总量至多
\[
O\!\left(\frac{H\log^2M}{M^2}
\frac M{\log M}(K_0+1)\right)
=O\!\left(\frac{H^4}{M\log^6M}+\frac{H\log M}{M}\right)=o(1).
\tag{24}
\]
最后 \(HL/M\to1/32\)，而完整盒的 Riemann 和满足
\(\sum_I(L/M)\phi(t_I)^2\to\int_J\phi(t)^2dt\)。将 (23) 求和并用 (24)，得 (18)。\(A_v>0\) 可直接由 \(v\ge0\) 及 \(|2\pi t(u-v)/32|\le\pi/4\)（\(|t|\le4\)）得到。\(\square\)

式 (18) 是例外差的一个**正子块**，不是完整差的下界；盒外配对及 \(J_H\) 的负瓣可以抵消它。它也不是高除数 Gram 中某组非对齐源的单独恒等式，因为式 (19) 在所有除数系数聚合后才成立。

## 奇素数通道自身给出等量负补偿

令
\[
P(m)=2\mathbf1_{m=2p\text{，}p\text{ 素数}}\log p
-4\mathbf1_{m=p\text{，}p\text{ 素数}}\log p,
\qquad
\mathcal P_h=\frac1M\sum_{M<m<2M}P(m)\phi(m/M)e(-hm/M).
\tag{25}
\]
把 \(P=P_{\rm odd}+P_2\) 按 (25) 的奇素数项与 \(2p\) 项拆开，记相应 Fourier 和为 \(\mathcal P_h^{\rm odd},\mathcal P_h^2\)。对任意固定实 \(\psi\in C_c^3((1,2))\)，两条通道**分别**满足
\[
\boxed{\quad
\sum_h w_H(h)
\bigl(|\mathcal P_h^{\rm odd}|^2+|\mathcal P_h^2|^2\bigr)
\ll_{A,s,\psi}(\log M)^{-A}
\qquad(\forall A>0).
\quad}\tag{26}
\]
由平方三角不等式，完整两通道 \(\sum_hw_H|\mathcal P_h|^2\) 也满足 (26) 的上界。证明只用 scratch/862 已使用的同一原始短区间定理。令
\(P_\Lambda(m)=2\mathbf1_{2\mid m}\Lambda(m/2)-4\Lambda(m)\)、
\(b(m)=4-2\mathbf1_{2\mid m}\)。于是
\[
P_\Lambda(m)+b(m)
=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
-4(\Lambda(m)-1).
\tag{27}
\]
对 \(m\asymp M\) 的每个长度 \(B=\lfloor M^{2/3}\rfloor\) 的整块，scratch/862 式 (7) 及偶格换元使 (27) **右边的两项各自**的和为 \(O_A(B\log^{-A}M)\)。如式 (7)--(9) 分成整块、支付端块、对 \(\phi\) 作 Abel 求和并用周期 Parseval，得到
\[
\sum_h w_H(h)\left(
\left|\frac1M\sum_m{-4}(\Lambda(m)-1)
\phi(m/M)e(-hm/M)\right|^2
+\left|\frac1M\sum_m2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
\phi(m/M)e(-hm/M)\right|^2\right)
\ll_{A,s,\psi}(\log M)^{-A}.
\tag{28}
\]
对两条通道各自的周期背景 \(4\) 与 \(-2\mathbf1_{2\mid m}\)，note 849 式 (32) 的 Poisson 公式分别给每个带通 \(h\) 的 Fourier 振幅 \(O_\psi(H^{-3})\)，故各自的频带能量为 \(O_\psi(H^{-5})\)。而 \(P_\Lambda-P\) 的每条通道只由高次素数幂构成；note 849 式 (33) 给逐频振幅 \(O_\psi(M^{-1/2}\log M)\)，其频带能量为 \(O_{s,\psi}(H\log^2M/M)\)。这些项都小于任意固定负对数幂。分别用频带 \(\ell^2\) 三角不等式，证明 (26)。

在上一节的非负 \(\psi\) 与 \(J\) 下，令 \(\mathcal P^{\rm box}_{pp}\) 为 (16) 中以 \(P(p)P(q)=16\log p\log q\) 代替大括号所得的同盒素数和。两者之差含的系数只为 \(16\ell(\log p+\log q)\)。式 (21) 给每个完整盒一致的素数数目 \(O(L/\log M)\)，完整盒总数为 \(O(H)\)；再用 \(|J_H(r)|\ll H\) 与 \(HL/M\asymp1\)，得到
\[
\mathcal P^{\rm box}_{pp}-\mathcal E^{\rm box}_{pp}=O_{s,\psi}(1/\log M).
\tag{29}
\]
式 (18) 因而给 \(\mathcal P^{\rm box}_{pp}\to c_J:=\tfrac12A_v\int_J\phi^2>0\)。把 (26) 中的**奇素数单通道**展开为全部有序奇素数配对的 Gram，并减去这个真实近距离素数盒，得到无条件的实际负补偿极限
\[
\boxed{\quad
\sum_h w_H(h)|\mathcal P_h^{\rm odd}|^2
-\mathcal P^{\rm box}_{pp}
\longrightarrow -c_J.
\quad}\tag{30}
\]
负贡献只来自盒外的**奇素数—奇素数配对**。在 \(\psi\ge0\) 下，其算术系数及 \(\phi(p/M)\phi(q/M)\) 非负，所以负号必来自 \(J_H(p-q)<0\) 的物理距离。正常数的素数—素数盒因此无需 Möbius 或 \(2p\) 通道支付；要取得固定幂目标，仍须在 (26) 的任意对数级之下进一步控制真实三通道的联合能量。

还可把负贡献定位在一个真实距离环带。令 \(K=K_{s,2}=C_{s,2}(M/H)(\log M)^s\)，并令
\[
\mathcal N_{pp}:=\frac1{M^2}
\sum_{\substack{M<p,q<2M\text{ 为奇素数}\\
M/(16H)<|p-q|\le K}}
16\log p\log q\,\phi(p/M)\phi(q/M)J_H(p-q).
\tag{31}
\]
则一致于整段 \(H\) 有
\[
\boxed{\quad \mathcal N_{pp}\le-c_J+o_{s,\psi}(1).\quad}\tag{32}
\]
事实上，\(|r|\le M/(16H)\) 时，\(|h|\le4H\) 使所有余弦相位绝对值不超过 \(\pi/2\)，所以 \(J_H(r)\ge0\)；这段的所有奇素数配对都非负，且包含 (30) 的正盒。\(|r|>K\) 的部分由 scratch/860 式 (9) 及 \(\sum_p(\log p)/M\ll1\) 绝对支付为 \(o(1)\)。再用 (26) 的奇素数单通道能量趋零，便得 (32)。这个环带负号来自带通核的真实负瓣；它仍只给常数量级的补偿，不是完整三通道的固定幂估计。

## 真实高除数直接素数源也在自身内部对消

上一节的 \(P_{\rm odd}(p)=-4\log p\) 是所有除数聚合后的观察系数。现在回到 scratch/859 式 (2) 的**真实高除数源**：若 \(p\in(M,2M)\) 为奇素数，则只有 \(d=m=p\)，并有
\[
\mu(p)b_p(p)=\frac{4\ell}{M}\phi(p/M).
\tag{33}
\]
因此直接素数源的 Fourier 和为
\(D_h=(4\ell/M)\sum_{M<p<2M}\phi(p/M)e(-hp/M)\)。它单独满足
\[
\boxed{\quad
\sum_hw_H(h)|D_h|^2
\ll_{A,s,\psi}(\log M)^{-A}
\qquad(\forall A>0).
\quad}\tag{34}
\]
为证明 (34)，对 \(m\asymp M\) 用
\[
\mathbf1_{m\text{ 素数}}
=\frac{\Lambda(m)}{\log m}
-\sum_{k\ge2,\ m=p^k}\frac1k.
\tag{35}
\]
高次素数幂在 \((M,2M)\) 中至多 \(O(\sqrt M\log M)\) 个，归一化后给逐频 \(O_\psi(M^{-1/2}\log M)\) 的误差，频带能量为固定负幂。把 \(\Lambda(m)/\log m\) 分成 \((\Lambda(m)-1)/\log m+1/\log m\)。前者由 scratch/862 式 (7) 在长度 \(B=M^{2/3}\) 的整块上任意对数幂相消，再如式 (7)--(9) 对光滑权 \(\phi(m/M)/\log m\) 作 Abel 求和和周期 Parseval；后者的三阶导数在 \(m/M\) 坐标上一致为 \(O_\psi(1/\log M)\)，由 Poisson 求和给带通逐频 \(O_\psi(H^{-3}/\log M)\)。平方三角不等式证明 (34)。

仍取上一节的 \(\psi\ge0\) 与 \(J\)。令 \(\mathcal D^{\rm box}_{pp}\) 为 (16) 同一有序近距离素数盒，但以真实直接源系数 \(16\ell^2\) 取代大括号。由式 (21)--(23)，或直接用 \(\log p\log q=\log^2M+O(\log M)\)，得到精确渐近
\[
\boxed{\quad
(\log M)^2\mathcal D^{\rm box}_{pp}
\longrightarrow
c_J^{\rm dir}:=\frac{\ell^2A_v}{2}\int_J\phi(t)^2\,dt>0.
\quad}\tag{36}
\]
这个盒中的 \(d=p,e=q,m=p,n=q\) 满足 scratch/859 式 (12) 的真实高除数、互不整除、大约化比例和 \(K_0<|m-n|\le K_{s,2}\) 四重门；式 (36) 将 scratch/861 的正下界加强为一条指定盒族的精确主项。

定义同一真实直接素数源在核变号环带的和
\[
\mathcal N^{\rm dir}_{pp}:=\frac{16\ell^2}{M^2}
\sum_{\substack{M<p,q<2M\text{ 为奇素数}\\
M/(16H)<|p-q|\le K}}
\phi(p/M)\phi(q/M)J_H(p-q).
\tag{37}
\]
则 (34)、(36) 给出
\[
\boxed{\quad
\mathcal N^{\rm dir}_{pp}
\le-\frac{c_J^{\rm dir}+o_{s,\psi}(1)}{\log^2M}.
\quad}\tag{38}
\]
确实，\(|p-q|\le M/(16H)\) 的核非负并包含 (36) 的盒，而 \(|p-q|>K\) 的绝对质量由 scratch/860 式 (9) 与 \(\sum_p M^{-1}\ll1\) 给 \(o(\log^{-2}M)\)。全频带的直接素数能量 (34) 是 \(o(\log^{-2}M)\)；从中扣除非负近段与可忽略远段便得 (38)。在 \(\psi\ge0\) 下，(37) 的算术系数均非负，所以这一负量完全来自 \(J_H\) 的负瓣。它是高除数原 Gram 内的实际子和，不是聚合后系数的替代物；仍不足以支付完整门的 \(H^4/M\) 固定幂目标。

## 固定幂边界

式 (9) 使用的全区间 Möbius 进程短和可节省任意固定对数幂，但这里没有得到对 \(x=1\) 等小 cofactor 的固定负幂频带能量。式 (11) 使 \(x>Q\) 的尾部任意对数级可付；若要求 \(H^4/M\) 的固定幂目标，取 \(Q\) 为多对数仍不够。式 (2) 也不能从完整高除数 Gram 中单独删除这个 signed 子和，因为它可能抵消未对齐部分。
