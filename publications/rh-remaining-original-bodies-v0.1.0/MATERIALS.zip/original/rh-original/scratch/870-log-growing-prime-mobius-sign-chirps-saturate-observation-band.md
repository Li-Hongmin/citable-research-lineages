# 对数增长素数集的 Möbius 符号仍允许观察频带驻相

日期：2026-10-02。加强 [note 865](../notes/865-rank-one-type-ii-chirps-saturate-observation-band.md) 的 Type II 反模型，并与 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (16) 的质量量级比较。**尚未独立复核，留在 scratch。** 系数保留平方自由支撑、乘法性与全部 \(q\le c\log N\) 素数上的真实 Möbius 翻转，但其余素数处仍为人为相位，故不是 \(\mu\)。

## 固定素数集的待复核定理

固定有限素数集 \(P\)、非负非零 \(\psi\in C_c^\infty((1,2))\)。沿平方整数 \(Y=N^2\to\infty\)，置 \(H=\lceil Y^{1/5}\rceil\)。存在先固定的 \(0\le u,v\le1\)、\(u,v\in C_c^\infty((1,2))\)、\(t_*\in(1,2)\) 与常数 \(c,\varepsilon>0\)，使以下构造成立。令 \(T=2\pi t_*H\)，定义完全乘性单位模函数
\[
\chi_{T,P}(q)=
\begin{cases}
-q^{-iT},&q\in P,\\
1,&q\notin P
\end{cases}
\qquad(q\text{ 为素数}),
\]
再定义乘性平方自由系数
\[
f_{T,P}(n)=\mu^2(n)\chi_{T,P}(n)n^{iT}.
\tag{1}
\]
它满足 \(|f_{T,P}(n)|=\mu^2(n)\)，且对每个 \(q\in P\) 有
\[
f_{T,P}(qn)=
\begin{cases}
-f_{T,P}(n),&q\nmid n,\\
0,&q\mid n.
\end{cases}
\tag{2}
\]
特别地，\(f_{T,P}(q)=-1=\mu(q)\) 对全部 \(q\in P\) 成立；若 \(n\) 的每个素因子都属于 \(P\)，则 \(f_{T,P}(n)=\mu(n)\)。
置 \(a_m=u(m/N)f_{T,P}(m)\)、\(b_n=v(n/N)f_{T,P}(n)\) 与
\[
B_h^P=\frac1Y\sum_{m,n\ge1}
a_mb_n\psi(mn/Y)e(-hmn/Y).
\tag{3}
\]
则全部整数 \(H\le h\le(1+\varepsilon)H\) 满足
\[
\boxed{\quad |B_h^P|\ge cH^{-1/2},\qquad
\sum_h\eta(h/H)|B_h^P|^2\gg_{P,\psi,u,v}1 \quad}
\tag{4}
\]
只要 \(\eta\ge0\) 且在 \([1,2]\) 上至少为 \(1\)。

将第一因子 \(a_m\) 除以 \(\log Y\)，令所得乘积系数为
\(\gamma_Y(k)=\sum_{mn=k}(a_m/\log Y)b_n\)、
\(w_Y(k)=Y^{-1}\gamma_Y(k)\psi(k/Y)\)。则
每个非零乘积项都有共同相位 \(\chi_{T,P}(k)k^{iT}\)，因为
\(f_{T,P}(m)f_{T,P}(n)=\mu^2(m)\mu^2(n)\chi_{T,P}(mn)(mn)^{iT}\)；
因而卷积内部没有人为的因子化相消。并有
\[
\boxed{\quad
\sum_k|w_Y(k)|\ll(\log Y)^{-1},\qquad
\sum_k|w_Y(k)|^2\ll\frac{\log Y}{Y},\qquad
\sum_h\eta(h/H)\left|\sum_kw_Y(k)e(-hk/Y)\right|^2
\gg(\log Y)^{-2}.
\quad}
\tag{5}
\]
尽管前两个上界分别强于和匹配 note 849 式 (16)，最后一项对任意固定 \(0<\delta<1/5\) 都大于目标 \(H^4Y^{-1+\delta}\)。

## 固定素数局部符号的求积引理

令 \(\rho=\zeta(2)^{-1}\)。对每个 \(q\in P\) 任取 \(|z_q|=1\)，设
\[
\omega_{\mathbf z}(m)=\mu^2(m)\prod_{\substack{q\in P\\q\mid m}}z_q,
\qquad
\kappa_{\mathbf z}=\rho\prod_{q\in P}\frac{q+z_q}{q+1}.
\]
若 \(1\le H\le N\)，\(F\in C_c^2(\mathbb R)\) 支撑于固定的
\([aN,bN]\subset(0,\infty)\)，且
\[
\|F^{(j)}\|_\infty\le C_j(H/N)^j
\qquad(j=0,1,2),
\tag{6}
\]
则有对全部 \(\mathbf z\) 一致的
\[
\boxed{\quad
\sum_{m\ge1}\omega_{\mathbf z}(m)F(m)
=\kappa_{\mathbf z}\int_{\mathbb R}F(x)\,dx
+O_{a,b,C_j}(Q_P3^{|P|}\sqrt{NH}),
\quad}
\tag{7}
\]
这里 \(Q_P=\prod_{q\in P}q\)；空积取 \(1\)。此显式误差对随 \(N\) 变化的 \(P\) 仍成立。

证明把局部权展开为
\[
\prod_{\substack{q\in P\\q\mid m}}z_q
=\sum_{S\subseteq P}
\left(\prod_{q\in S}(z_q-1)\right)
\mathbf1_{Q_S\mid m},
\qquad Q_S=\prod_{q\in S}q.
\]
固定 \(S\)，用 \(\mu^2(m)=\sum_{d^2\mid m}\mu(d)\)。设
\(L_S(d)=\operatorname{lcm}(d^2,Q_S)\)。此时内和是
\(\sum_{L_S(d)\mid m}F(m)\)，且
\(d^2\le L_S(d)\le Q_Sd^2\)。取
\(D=\lfloor\sqrt{N/H}\rfloor\)。对 \(d\le D\)，Poisson 求和的零频为
\(L_S(d)^{-1}\int F\)，非零频使用
\(|\widehat F(\xi)|\le\|F''\|_1/(2\pi|\xi|)^2
\ll H^2/(N|\xi|^2)\)，误差至多
\[
\frac1{L_S(d)}
\sum_{\ell\ne0}\left|\widehat F(\ell/L_S(d))\right|
\ll\frac{H^2L_S(d)}N
\ll_P\frac{H^2d^2}N.
\tag{8}
\]
对 \(d\le D\) 求和是 \(O(Q_SH^2D^3/N)=O(Q_S\sqrt{NH})\)。
对 \(d>D\) 的原和取绝对值，因支撑在 \([aN,bN]\) 内，至多
\[
\sum_{D<d\le\sqrt{bN}}
\left(\frac{bN}{d^2}+1\right)
\ll N/D+\sqrt N\ll\sqrt{NH}.
\tag{9}
\]
补齐零频密度级数的尾亦至多 \(N\sum_{d>D}d^{-2}\ll\sqrt{NH}\)。
因此该 \(S\) 的密度是
\[
\delta_S=\sum_{d\ge1}\frac{\mu(d)}{L_S(d)}
=\rho\prod_{q\in S}\frac1{q+1}.
\tag{10}
\]
式 (10) 逐素数计算：若 \(q\in S\)，局部因子为
\(q^{-1}-q^{-2}\)，相对 \(\rho\) 的
\(1-q^{-2}\) 因子恰为 \(1/(q+1)\)；其余素数因子不变。
最后对 \(S\subseteq P\) 求和，得到
\[
\sum_{S\subseteq P}
\delta_S\prod_{q\in S}(z_q-1)
=\rho\prod_{q\in P}\left(1+\frac{z_q-1}{q+1}\right)
=\kappa_{\mathbf z}.
\]
由于 \(\sum_{S\subseteq P}\prod_{q\in S}|z_q-1|\le3^{|P|}\) 且 \(Q_S\le Q_P\)，合并误差至多 \(O(Q_P3^{|P|}\sqrt{NH})\)，证明 (7)。\(\square\)

## 两次求积与驻相

取 \(z_q=-q^{-iT}\) 后，
\[
\kappa_{T,P}
=\rho\prod_{q\in P}\frac{q-q^{-iT}}{q+1},
\qquad
|\kappa_{T,P}|
\ge \rho\prod_{q\in P}\frac{q-1}{q+1}>0.
\tag{11}
\]
对 (3) 中固定 \(n\asymp N\) 的 \(m\) 变量，将平方自由和局部素数权留给 (7)，其余置
\[
F_n(m)=u(m/N)m^{iT}\psi(mn/Y)e(-hmn/Y).
\]
由 \(T,h\asymp H\) 与 \(m,n\asymp N\)，乘积求导给
\(\|F_n^{(j)}\|_\infty\ll_j(H/N)^j\)（\(j\le2\)），一致于指定的 \(h,n\)。第一次用 (7)，再对 \(n\) 变量用 (7)；第二次的函数
\[
G(n)=v(n/N)n^{iT}\int_{\mathbb R}F_n(m)\,dm
\]
满足 \(\|G^{(j)}\|_\infty\ll_j N(H/N)^j\)。两次误差在除以 \(Y=N^2\) 后各为 \(O(Q_P3^{|P|}\sqrt{H/N})\)，所以
\[
B_h^P
=\kappa_{T,P}^{\,2}e^{iT\log Y}I_h
+O(Q_P3^{|P|}\sqrt{H/N}),
\tag{12}
\]
其中 \(I_h\) 正是 note 865 式 (5) 的驻相积分。选 \(t_*,u,v,\varepsilon\) 如该 note，使振幅在驻点
\(t_h=t_*H/h\) 处一致严格为正，便有
\(|I_h|\gg H^{-1/2}\)。因 \(H=N^{2/5+o(1)}\)，
\[
\sqrt{H/N}=N^{-3/10+o(1)}=o(H^{-1/2}).
\]
由 (11)--(12) 得 (4)。

式 (5) 的频带下界由 (4) 除以 \(\log^2Y\) 得到。质量上界只用
\(|a_m|,|b_n|\le1\)、各有 \(O(N)\) 个支撑点及
\(|\gamma_Y(k)|\le d(k)/\log Y\)。逐素数幂
\((j+1)^2\le\binom{j+3}{3}\) 给 \(d(k)^2\le d_4(k)\)，而
\(\sum_{k\le4Y}d_4(k)\ll Y\log^3Y\)，故得 (5)。沿偶数 \(N\) 取模型的 \(Y=2Y_{\rm 849}\)，则 Fourier 周期与 note 849 的 \(M=2Y_{\rm 849}\) 精确一致，且 \(H\asymp Y_{\rm 849}^{1/5}\) 仍在其频带范围内；把固定权 \(\psi(t)\) 换为 \(t\psi(t)\)，也使 \(Y^{-1}\psi(k/Y)\) 精确写为 \(k^{-1}[t\psi(t)]_{t=k/Y}\)。\(\square\)

## 对数增长的素数集合

取 \(P_N=\{q\text{ 为素数}:q\le R_N\}\)，其中
\(R_N=\lfloor c_0\log N\rfloor\)。存在绝对常数 \(c_0>0\)，使上述构造对这族**增长**的素数集合仍满足
\[
\boxed{\quad
|B_h^{P_N}|\gg H^{-1/2}(\log N)^{-4}
\quad(H\le h\le(1+\varepsilon)H).
\quad}
\tag{13}
\]
因此若将第一因子除以 \(\log Y\)，式 (5) 的两个质量上界保持不变，而频带能量有下界
\[
\boxed{\quad
\sum_h\eta(h/H)\left|\sum_kw_Y(k)e(-hk/Y)\right|^2
\gg(\log Y)^{-10}.
\quad}
\tag{14}
\]
此量仍大于每个 \(H^4Y^{-1+\delta}\)、\(0<\delta<1/5\)。

证明只需把 (7)、(11)、(12) 中的 \(P\) 取为 \(P_N\)。Chebyshev 的初等上界
\(\sum_{q\le R}\log q\le C_0R\) 给
\[
Q_{P_N}3^{|P_N|}
\le\exp((C_0+\log3)R_N)
\le N^{Cc_0},\qquad C=C_0+\log3.
\tag{15}
\]
另一方面，每个 \((q-1)/(q+1)<1\)，把素数乘积补上
\(2\le j\le R_N\) 的全部整数因子只会减小它，故
\[
|\kappa_{T,P_N}|
\ge\rho\prod_{q\le R_N}\frac{q-1}{q+1}
\ge\rho\prod_{j=2}^{R_N}\frac{j-1}{j+1}
=\frac{2\rho}{R_N(R_N+1)}
\gg(\log N)^{-2}.
\tag{16}
\]
由 (12) 与驻相，主项至少为
\(\gg H^{-1/2}(\log N)^{-4}\)，误差由 (15) 至多为
\(N^{Cc_0}\sqrt{H/N}\)。由于
\[
\frac{N^{Cc_0}\sqrt{H/N}}
{H^{-1/2}(\log N)^{-4}}
=N^{Cc_0-1/10+o(1)}(\log N)^4\longrightarrow0
\]
只要取 \(Cc_0<1/20\)，便得 (13)。区间含 \(\asymp H\) 个整数频率，故未缩放能量为 \(\gg(\log N)^{-8}\)；除以 \(\log^2Y\) 得 (14)。\(\square\)

## 同一模型已有移动区间幂节省

对上述 \(P_N\)、\(T=2\pi t_*H\)，其底层系数还满足
\[
\boxed{\quad
\sup_{N\le A<B\le2N}
\left|\sum_{A<n\le B}f_{T,P_N}(n)\right|
\ll N^{3/4}.
\quad}
\tag{17}
\]
这是随 \(N\) 改变的系数在长度 \(N\) 的因子带内，对**所有移动整数区间**的一致估计。

若 \(B-A<2L_0\)，其中 \(L_0=N/H\)，平凡界已给 \(O(L_0)\)。
否则在 \((A,B)\) 内选光滑权 \(w\)，使 \(0\le w\le1\)、
\(w=1\) 于 \([A+L_0,B-L_0]\)、两端过渡各长至多 \(L_0\)，并满足
\(\|w^{(j)}\|_\infty\ll_j L_0^{-j}\)。置 \(F(x)=w(x)x^{iT}\)；
因 \(T\asymp H\)、\(x\asymp N\) 且 \(L_0^{-1}=H/N\)，式 (6) 对它成立。
用 (7) 及分部积分得到
\[
\begin{aligned}
\left|\sum_{n\ge1}f_{T,P_N}(n)w(n)\right|
&\le|\kappa_{T,P_N}|\left|\int F(x)\,dx\right|
+O(Q_{P_N}3^{|P_N|}\sqrt{NH})\\
&\ll N/T+Q_{P_N}3^{|P_N|}\sqrt{NH}.
\end{aligned}
\tag{18}
\]
其中 \(\int F=-(1+iT)^{-1}\int w'(x)x^{1+iT}dx\)，且
\(\int|w'|\ll1\)。锐截断与光滑权只在两段长度 \(L_0\) 的过渡区不同，故再损失 \(O(L_0)\)。由 \(H=N^{2/5+o(1)}\)、(15) 与 \(Cc_0<1/20\)，总界为
\[
O\!\left(N^{3/5+o(1)}+N^{7/10+Cc_0+o(1)}\right)
=O(N^{3/4}),
\]
证明 (17)。对 \(u(m/N)f_{T,P_N}(m)\)、\(v(n/N)f_{T,P_N}(n)\) 再作一次 Abel 求和，因 \(u,v\) 的总变差固定，同一 \(O(N^{3/4})\) 上界也适用于两个实际 Type II 因子的全部移动区间。它在观察相位的单个周期 \(N/H=N^{3/5+o(1)}\) 上仍可能比区间长度大，因而与 (13) 的驻相不矛盾。\(\square\)

## 边界

直至 \(q\le c_0\log N\) 的全部素数，\(\mu(qn)=-\mu(n)\)、平方自由支撑、乘法性、逐点有界及正确对角量级可以同时保留，频带却仍违反所需固定幂界。真正缺失的是更大素数处的真实符号及其与两条 \(\Lambda\) 通道的联合消去。此构造不反驳真实 moving-\(N\) Möbius signed covariance，更不反驳 RH。
