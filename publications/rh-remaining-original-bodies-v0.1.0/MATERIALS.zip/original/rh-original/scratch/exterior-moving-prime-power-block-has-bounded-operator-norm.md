# 槽外矩形的高次素数幂压缩在所有奇轮廓上有界

日期：2026-09-30。沿用[槽外互素矩形候选](exterior-coprime-rectangle-carries-positive-fraction-of-polar-mass-candidate.md)式 (1)、(2) 的宽度 \(L=\log(1+p^{-2})\) 与既约分数集合 \(\mathcal G_p\)。本结论只处理旧 Weil 算子的算术素数幂部分；尚未经过异源复核。

令 \(I_x^+\)、\(I_x^-\) 分别为以 \(\log(px)\)、\(\log(p/x)\) 为中心、长度 \(L\) 的开区间，其中 \(x\in\mathcal G_p\)。令 \(V_p^{\rm ext}\) 为 \(L^2(0,2\log p)\) 中所有关于 \(u\mapsto2\log p-u\) 为奇函数、且支撑在
\(\bigcup_{x\in\mathcal G_p}(I_x^+\cup I_x^-)\) 内的闭子空间。它包含候选的常值槽空间 \(U_p^{\rm ext}\)，并允许每槽任意 \(L^2\) 轮廓。记 \(P_V\) 为投影到 \(V_p^{\rm ext}\)。

对素数幂 \(m\) 置 \(c_m=\Lambda(m)/\sqrt m\)，算术算子为
\(\mathcal R_{p^2}=-\sum_m c_m(T_m+T_m^*)\)。令
\(\mathcal R_{p^2}^{\rm pp}\) 只取 \(m=\ell^r,r\ge2\)，并以 \(r=2\) 与 \(r\ge3\) 分块。

**命题。** 沿奇素数 \(p\to\infty\)，有绝对常数 \(C\) 使
\[
\boxed{\quad
\|P_V\mathcal R_{p^2}^{\rm pp}P_V\|_{\rm op}\le C,
\qquad
\|P_V\mathcal R_{p^2}^{(r\ge3)}P_V\|_{\rm op}
\ll(\log p)p^{-1/3}=o(1).
\quad}
\tag{1}
\]
因而候选式 (8) 的常值槽素数幂矩阵若按真正素数与高次幂分开，高次幂块有一致有界的算子范数。候选式 (9)、(10)、(15) 遂给
\[
A_{U_p^{\rm ext}}
=P_{U_p^{\rm ext}}G_{p^2}P_{U_p^{\rm ext}}
+R_p^{\rm prime}-K_p^{\rm cont}+D_p,
\qquad \|D_p\|_{\rm op}=O(1),
\tag{2}
\]
其中 \(R_p^{\rm prime}\) 只含素数 \(m\)，\(K_p^{\rm cont}\) 是候选式 (9) 的连续主项。这里 \(D_p\) 无已知有利符号；式 (2) 不给出真正素数短窗的谱下界。

## 证明

不同 \(x=n/b,y=n'/b'\in\mathcal G_p\) 的分数中心相离，且 \(x,y\in[p/8,p/2]\)。算术位移 \(T_m,T_m^*\) 在对数坐标中移动 \(\log m\)。若它使两个**同臂**槽的支撑相交，则在适当交换 \(x,y\) 后
\[
\left|\log\frac{mx}{y}\right|<L,
\qquad 2\le m\le4
\tag{3}
\]
对充分大的 \(p\) 成立。把 \(x,y\) 写成既约分数，式 (3) 的分子分母交叉积都是整数且至多 \(p^2\)；由于 \(e^L-1=p^{-2}\)，严格相交迫使两交叉积相等。因此 \(mx=y\) 恰好成立。若 \(x=n/b\)，令 \(d=(m,b)\)，则 \(mx=(mn/d)/(b/d)\) 已约分。当 \(m/d\ge2\)，其分子超过矩形上界；当 \(m/d=1\)，其分母低于矩形下界。两者均与 \(y\in\mathcal G_p\) 矛盾。故所有同臂算术压缩为零；论证仅用支撑，不依赖槽内轮廓。

若位移使一上一下两个槽相交，其中心比为 \(xy\)，所以
\[
\left|\log\frac m{xy}\right|<L,
\qquad \frac{p^2}{64}e^{-L}<m<\frac{p^2}{4}e^L.
\tag{4}
\]
特别地，唯一有关的素数幂位于固定比例带 \(m\asymp p^2\)。每个 \(T_m\) 是 \(L^2\) 上的部分平移，故 \(\|T_m\|\le1\)、\(\|T_m+T_m^*\|\le2\)；压缩不会增大范数。于是任意一组有关素数幂 \(\mathscr M\) 满足
\[
\left\|P_V\sum_{m\in\mathscr M}c_m(T_m+T_m^*)P_V\right\|_{\rm op}
\le2\sum_{\substack{m\in\mathscr M\\m\asymp p^2}}\frac{\Lambda(m)}{\sqrt m}.
\tag{5}
\]
对于平方 \(m=\ell^2\asymp p^2\)，有 \(\ell\asymp p\)；Chebyshev 素数上界及分部求和给
\[
\sum_{\substack{\ell\text{ 素数}\\\ell\asymp p}}
\frac{\log\ell}{\ell}=O(1).
\tag{6}
\]
指数 \(r\ge3\) 的素数幂 \(m\asymp p^2\) 至多 \(O(p^{2/3})\) 个，每个权重 \(\Lambda(m)/\sqrt m\ll(\log p)/p\)，故总权重为 \(O((\log p)p^{-1/3})\)。式 (5) 给 (1)。对 \(U_p^{\rm ext}\subset V_p^{\rm ext}\) 再压缩，并用候选式 (9)、(10)、(15) 的精确分解，得到 (2)。\(\square\)

## 剩余算术门

[精确碰撞引理](exterior-rectangle-exact-prime-power-collisions-are-negligible.md)进一步给 \(m=xy\) 子块的范数 \(O((\log p)/p)\)。对真正素数 \(m\)，精确乘积甚至不可能：该引理中的整数分解 \(m=uv\) 有 \(u,v\ge p/8>1\)。所以式 (2) 中真正未付的是素数与两个槽中心乘积**接近但不相等**的移动短窗。

在自然极向量 \(e_x=\sqrt{x/\sum_y y}\) 上，连续主项精确为
\[
\langle e,K_p^{\rm cont}e\rangle
=L\left(\frac{\sinh(L/4)}{L/4}\right)^2
\sum_{x\in\mathcal G_p}x
\sim\frac{3\log2}{128\zeta(2)}p.
\tag{7}
\]
式 (1) 说明高次素数幂只改变此标量及整个谱的 \(O(1)\) 项；要在候选式 (16) 的 \(\log p\) 尺度上决定符号，必须估计真正素数短窗的带符号谱。现有点态素数定理误差直接绝对分部积分不能给出该谱界。
