# 四分之五以上固定幂 Farey 短块族的真实 Möbius 算子抵消（待异源复核）

> **量化更正（2026-09-30）：** 本稿把 note 835 的短区间 Möbius 输入误用为 \(e^{-c(\log Y/\log\log Y)^{1/3}}\) 节省；已核对的 Matomäki--Shao--Tao--Teräväinen 2023 定理只给任意固定对数幂。下文所有以该次幂率为结论的式 (1)--(2)、(11)--(15) 均不再作为已证候选使用。固定 \(4/5<\alpha<1\) 的完整对数幂修正版见 [更正候选](farey-fixed-power-operator-and-prime-frame-logarithmic-correction.md)。

依赖：[note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 的统一短区间加权 Mertens 界、[四分之五延伸候选](farey-prime-composite-block-covariance-down-to-four-fifths-candidate.md) 式 (6) 的多倍数 collar 界、[note 800](../notes/800-true-mobius-harmonic-collisions-pay-low-reduced-reciprocal-frequencies.md) 式 (12) 的互素 Möbius 调和界、[note 833](../notes/833-prime-composite-covariance-within-a-moving-farey-denominator-block.md) 式 (1) 的真实频率系数、[note 802](../notes/802-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual.md) 式 (4) 的移动权间距均方引理。此稿只处理既约分子 \(1\)、固定幂分母带。

固定 \(4/5<\alpha<1\)，令 \(D=\lfloor Y^\alpha\rfloor\)、\(B=\lfloor D^2/(1000Y)\rfloor\)、\(L=\lfloor Y^{5/6}\rfloor\)，并取任意两两不交的整数块 \(I_j=(t_j,t_j+\ell_j]\subset(D/2,D]\)，其中 \(B/2\le\ell_j\le B\)。沿用 note 833 式 (1) 的真实物理裁剪频率和 \(T_{I_j,N}=\sum_{q\in I_j}F_{q,N}\)，其中 \(Y<N\le2Y\)。

**候选定理。** 存在 \(c_\alpha>0\)，使每个复权列 \((w_j)\) 都满足
\[
\boxed{\quad
\sum_{Y<N\le2Y}\left|\sum_jw_jT_{I_j,N}\right|^2
\ll_\alpha
\frac{B^2D^2}{Y\log^2D}
\exp\!\left[-c_\alpha
\left(\frac{\log Y}{\log\log Y}\right)^{1/3}\right]
\sum_j|w_j|^2.
\quad}\tag{1}
\]
因此，将整数区间 \((D/2,D]\) 分成长度介于 \(B/2\) 与 \(B\) 的相邻块，取 \(w_j=1\)，得到完整既约分子 \(1\) 的分母带界
\[
\sum_{Y<N\le2Y}\left|\sum_{D/2<q\le D}F_{q,N}\right|^2
\ll_\alpha
\frac{D^5}{Y^2\log^2D}
\exp\!\left[-c_\alpha
\left(\frac{\log Y}{\log\log Y}\right)^{1/3}\right].
\tag{2}
\]
这比逐块三角不等式的 \(o(D^4/(Y\log^2D))\) 少一个块数因子 \(Y/D\)，并在 note 762 的无符号 \(D^5/Y^2\) 量纲上获得真实 Möbius 的次幂节省。因 \(D/2>Y^{4/5}\) 对充分大的 \(Y\) 成立、分子 \(1<A_j\)、原始 \(kq\le N-L\)，式 (2) 的每项均属于 note 832 的 \(\mathcal V_N\)。固定 \(\alpha>4/5\) 时 (2) 的幂 \(5\alpha-2>2\)，仍不证明目标 \(Y^{2+\varepsilon}\) 门；剩余分子及不同分母带也未由 (1) 控制。

## 证明

写 \(f_\kappa(q)=\kappa_q\mu(q)q/\varphi(q)\)，其中奇 \(q\) 时 \(\kappa_q=5\)、偶 \(q\) 时 \(\kappa_q=1\)，并记 \(u(x)=(\log x/\log\log x)^{1/3}\)。note 835 式 (8) 对长于 \(D^{3/4}\) 的任意前缀给 \(O(Be^{-cu(D)})\)，短前缀用 \(|f_\kappa(q)|\ll\log\log(3D)\) 给 \(O(D^{3/4}\log\log D)\)。故每个上述块的全部部分和满足
\[
\sup_{t_j\le z\le t_j+\ell_j}\left|\sum_{t_j<q\le z}f_\kappa(q)\right|
\le B\epsilon_Y,
\quad
\epsilon_Y\ll_\alpha
e^{-c(\log D/\log\log D)^{1/3}}
+\frac{D^{3/4}\log\log D}{B}.
\tag{3}
\]
因为 \(B=D^{2-1/\alpha+o(1)}\) 且 \(\alpha>4/5\)，第二项为 \(D^{-\delta_\alpha}\log\log D\)，其中 \(\delta_\alpha=5/4-1/\alpha>0\)；故 \(\epsilon_Y\ll_\alpha e^{-c_\alpha(\log Y/\log\log Y)^{1/3}}\)。

先估计不含同频系数误差的模型
\[
U_N=\frac1N\sum_jw_j\sum_{q\in I_j}qf_\kappa(q)e(N/q),
\qquad e(x)=e^{2\pi ix}.
\tag{4}
\]
令 \(v_{j,q}=1/q-1/t_j\)，则 \(|v_{j,q}|\le4B/D^2\)。对 \(m\ge0\) 置
\[
A_{j,m}=\sum_{q\in I_j}qf_\kappa(q)v_{j,q}^m.
\]
函数 \(x(1/x-1/t_j)^m\) 在 \([t_j,t_j+\ell_j]\) 上的上确界加总变差至多
\(C(m+1)D(4B/D^2)^m\)。由 (3) 分部求和，
\[
|A_{j,m}|\ll\epsilon_YBD(m+1)(4B/D^2)^m
\qquad\text{对所有 }j,m.\tag{5}
\]
指数级数绝对收敛，并给
\[
U_N=\frac1N\sum_{m\ge0}\frac{(2\pi iN)^m}{m!}
\sum_jw_jA_{j,m}e(N/t_j).
\tag{6}
\]
不同块左端点至少相隔 \(B/2\)，所以 \(1/t_j\pmod1\) 的圆周间距至少 \(B/(2D^2)\)。又 \(D^2/B\asymp Y\)，note 762 式 (4) 的初等大筛给
\[
\left\|\sum_jw_jA_{j,m}e(N/t_j)\right\|_{\ell^2_N}
\ll\sqrt{Y\log(2Y)}\,
\epsilon_YBD(m+1)(4B/D^2)^m\|w\|_{\ell^2_j}.
\]
对 (6) 用 Minkowski，\(N\le2Y\)、\(N^{-1}\le Y^{-1}\) 以及 \(YB/D^2\le1/1000\)，得到
\[
\|U\|_2^2\ll
\epsilon_Y^2\log(2Y)\frac{B^2D^2}{Y}\|w\|_2^2.
\tag{7}
\]
实余弦模型是 \(U\) 与其负频率版本的半和，对两组频率分别用同一估计即可。

下面支付真实同频系数。令 \(C_q^{\rm full}(t)\) 是 note 833 式 (1) 中只保留 \(kq<t\)、尚未施加 \(kq\le t-L\) 的系数，置
\(R_q(t)=C_q^{\rm full}(t)+qf_\kappa(q)\)。对 \(q\in(D/2,D]\)、\(Y\le t\le2Y\)，有一致界
\[
|R_q(t)|\ll_\alpha D\delta_Y,
\qquad |R'_q(t)|\ll_\alpha\frac{D\delta_Y}{Y}\quad\text{a.e.},
\quad
\delta_Y=e^{-c_\alpha\omega(Y)}
+(D/Y)^2\log\log(3Y),
\tag{8}
\]
其中 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)。为核对导数，令
\[
M_q(t)=\sum_{\substack{kq<t\\(k,q)=1}}\frac{\mu(k)}k
\log\frac{t}{kq},\qquad
M_{2q}(t)=\sum_{\substack{kq<t\\(k,2q)=1}}\frac{\mu(k)}k
\log\frac{t}{kq}.
\]
在 \(M_{2q}\) 中，下标 \(2q\) 只限制互素性，截止仍为 \(k<t/q\)。note 800 式 (12) 可用模数 \(q\) 与 \(2q\)、同一个 \(K=t/q\)；它在 \(t/q\gg Y^{1-\alpha}\) 上给
\(M_q(t)=q/\varphi(q)+O(e^{-c\omega(Y)})\) 与
\(M_{2q}(t)=2q/\varphi(q)+O(e^{-c\omega(Y)})\)（后式仅在 \(q\) 为奇数时使用），缩小 \(c\) 以吸收 \(\log Y\)。两函数在每个 \(kq=t\) 连续，因为新进入项的对数权为零；几乎处处的导数分别是相应互素 \(\sum\mu(k)/k\) 除以 \(t\)，故为 \(O(e^{-c\omega(Y)}/t)\)。当 \(q\) 奇时，note 833 式 (1) 的偶 \(k\) 部分等于 \(M_q-M_{2q}\)；当 \(q\) 偶时它为空。代入两个有理乘子
\(4/(1-4q^2/t^2)\)、\(1/(1-q^2/t^2)\)，并用其导数为 \(O((q/t)^2/t)\) 及 \(q/\varphi(q)\ll\log\log(3Y)\)，得到 (8)。每个 \(R_q\) 都绝对连续。

对 \(q\) 取 \(w_jR_q(t)/(\pi t)\) 作为移动大筛权。由于不同整数 \(q\le D\) 的频率 \(1/q\pmod1\) 至少相隔 \(D^{-2}\)，式 (8) 与 note 802 式 (4) 给同频误差的 \(\ell^2_N\) 范数平方
\[
\ll_\alpha (Y+D^2\log(2D))
\frac{BD^2\delta_Y^2}{Y^2}\|w\|_2^2
\ll_\alpha\frac{BD^4}{Y^2}\delta_Y^2\log(2Y)\|w\|_2^2.
\tag{9}
\]
余弦的正负指数分别估计。

最后，当 \(q<L\) 时物理裁剪可删去多个原始 \(k\)。四分之五延伸候选式 (6) 的逐项界对全部 \(q\asymp D\) 一致给
\[
|C_q(N)-C_q^{\rm full}(N)|
\ll \frac{qL^2+q^2L}{Y^2}
\ll \frac{DL(L+D)}{Y^2}.
\]
每个 \(N\) 上先对每块的 \(B\) 项取绝对值，再对块权用 Cauchy–Schwarz；块数 \(M\ll D/B\asymp Y/D\)，于是裁剪误差平方和
\[
\ll Y\,M\,B^2\left(\frac{DL(L+D)}{Y^3}\right)^2\|w\|_2^2
\ll\frac{B^2D^2}{Y\log^2D}\,
\frac{L^2(L+D)^2\log^2D}{DY^3}\|w\|_2^2.
\tag{10}
\]
由于 \(Y^{4/5}\ll D\le Y\)、\(L\asymp Y^{5/6}\)，
\[
\frac{L^2(L+D)^2}{DY^3}
\ll \frac{L^4}{DY^3}+\frac{L^3}{Y^3}+\frac{DL^2}{Y^3}
\ll Y^{-7/15}+Y^{-1/2}+Y^{-1/3}
\ll Y^{-1/3}.
\]

把 (7)、(9)、(10) 与 \(F_{q,N}=-C_q(N)\cos(2\pi N/q)/(\pi N)\) 合并。以
\(E_*=B^2D^2/(Y\log^2D)\) 归一，三部分的倍率分别为
\[
O(\epsilon_Y^2\log^3Y),\qquad
O\!\left(\frac{D^2}{BY}\delta_Y^2\log^3Y\right),\qquad
O\!\left(\frac{L^2(L+D)^2\log^2Y}{DY^3}\right).
\]
因 \(D^2/(BY)\asymp1\) 且固定 \(\alpha<1\)，三者之和至多
\(\exp[-c_\alpha(\log Y/\log\log Y)^{1/3}]\)，再缩小 \(c_\alpha\) 即得 (1)。令 \(K=D-\lfloor D/2\rfloor\)，取 \(M=\lceil K/B\rceil\) 个相邻块并把 \(K\) 个整数尽量均分；因 \(K/B\to\infty\)，每块长度介于 \(B/2\) 与 \(B\)，且 \(M\ll D/B\)。取全部 \(w_j=1\)，式 (1) 即给 (2)。\(\square\)

## 均匀贴近四分之五的分子一支付

固定 \(0<\eta<1/5\)，令 \(Q=\lfloor Y^{4/5}\rfloor\)、\(U=u(Y)\)。
式 (1)--(2) 其实对全部整数 \(2Q\le D\le Y^{1-\eta}\) 一致成立，
只须把式 (3) 的短前缀阈值从 \(D^{3/4}\) 改为 \(D^{2/3}\)。
现给出该处所需的短区间引理，以避免把固定 \(\alpha\) 的常数误当成均匀常数：
\[
\sum_{x<q\le x+H}f_\kappa(q)
\ll H e^{-c u(x)}
\qquad(x^{2/3}\le H\le x/2),
\tag{11}
\]
其中 \(c>0\) 为绝对常数。沿用 note 835 式 (5)--(7) 的
\(f_\kappa=\mu*(h+4h_o)\) 与
\(\sum_d(|h(d)|+|h_o(d)|)/\sqrt d<\infty\)。在卷积指标
\(d_0=x^{1/10}\) 分开：\(d\le d_0\) 时
\[
\frac{H/d}{(x/d)^{5/8}}
\ge x^{2/3-5/8-(3/8)(1/10)}=x^{1/240},
\]
故 note 835 引用的短区间 Möbius 定理以固定指数 \(5/8\)
一致适用；\(d>d_0\) 的绝对尾为
\(O(Hx^{-1/20}+x^{1/2})=O(He^{-cu(x)})\)。
低 \(d\) 部分亦为 \(O(He^{-cu(x)})\)，证明 (11)。

对 \(x\asymp D\) 与块内前缀用 (11)，短于 \(D^{2/3}\) 的前缀
用平凡界，得到
\[
\epsilon_Y\ll e^{-cU}
+\frac{D^{2/3}\log\log(3D)}B
\ll e^{-c'U},
\qquad
\frac{D^{2/3}}B\ll\frac{Y}{D^{4/3}}\ll Y^{-1/15}.
\tag{12}
\]
这里 \(D\ge2Q\) 且 \(D\le Y^{1-\eta}\) 保证
\(u(D)\asymp U\) 及 note 800 的 \(N/q\ge Y^\eta\)
一致调和界。式 (8) 中的
\(\delta_Y\ll_\eta e^{-c_\eta\omega(Y)}+Y^{-2\eta}\log\log Y\)
也一致小于 \(e^{-c' U}\)；式 (10) 的 collar 预算不依赖
\(\alpha\)。故 (4)--(10) 原封不动地证明存在 \(c_\eta>0\)，使
\[
\sum_{Y<N\le2Y}
\left|\sum_{D/2<q\le D}F_{q,N}\right|^2
\ll_\eta \frac{D^5}{Y^2\log^2D}e^{-c_\eta U}
\qquad(2Q\le D\le Y^{1-\eta}).
\tag{13}
\]

取 \(\eta=1/10\)，再取固定 \(0<\varkappa<c_\eta/10\)，置
\(Q_1=\lfloor Qe^{\varkappa U}\rfloor\)。将
\(Q<q\le Q_1\) 分成 \(O(1+U)\) 个倍增带，逐带应用
式 (13) 与 Minkowski。最后一条不满带用式 (1) 支付长度
\(B/2\) 至 \(B\) 的完整块；剩余不足 \(B\) 个 \(q\) 由
\(|F_{q,N}|\ll D\log^2(2Y)/Y\) 逐项支付，其均方至多
\(O(D^6Y^{-3}\log^4Y)=Y^{9/5+o(1)}\)。由于每条带的
\(D\le2Q_1\le Y^{9/10}\)，其余部分总计至多
\[
O\!\left(
Y^2(1+U)^2e^{(5\varkappa-c_\eta)U}
\right)=O(Y^2).
\]
因此完整真实物理裁剪的分子 \(1\) 满足
\[
\boxed{\quad
\sum_{Y<N\le2Y}
\left|\sum_{Q<q\le Q_1}F_{q,N}\right|^2
\ll Y^2.
\quad}\tag{14}
\]
这只支付增长窄带中的分子 \(1\)；其他分子、固定幂深区及完整
moving-\(N\) 算术门仍开放。更精确地，若
\(\mathcal V_N^{\rm new}=\mathcal V_N-
\sum_{Q<q\le Q_1}F_{q,N}\)，则 note 832 式 (2)、(14)
和三角不等式给
\[
\sum_{Y<N\le2Y}|\mathcal R_{N,2}-\mathcal V_N^{\rm new}|^2
\ll Y^2\log^7(2Y).
\tag{15}
\]
式 (11)--(15) 仍待异源复核；这项缩域没有给出
\(\mathcal V_N^{\rm new}\) 的目标上界。
