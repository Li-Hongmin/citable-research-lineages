# 槽外素数负谱调制的完整 Weil 成本是对数频率

日期：2026-10-02。沿用 [note 828](../notes/828-exterior-prime-hankel-centered-spectrum-has-linear-negative-tail.md) 的真素数反射、[note 830](../notes/830-exterior-prime-rayleigh-has-unconditional-main-term.md) 的自然 Rayleigh 主项、[note 004](../notes/004-exact-logarithmic-laplacian-normalization.md) 的 Fourier 归一化，以及[槽外全轮廓分解](exterior-all-profiles-continuous-prime-density-cancels-polar-to-bounded-rank-two.md)式 (6)。本稿尚待异源复核，故只留在 scratch。

## 命题

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)，\(E_p,\mathcal G_p,R_p,K_p,\mathcal J\) 如上述来源。置
\[
g_p(u)=\frac{e^{u/2}\mathbf1_{E_p}(u)}{\|e^{u/2}\mathbf1_{E_p}\|_2},\qquad
g_{p,t}(u)=\sqrt2\,g_p(u)\cos(tu),\qquad
f_{p,t}=\mathcal Jg_{p,t}.
\]
对每个参与的真素数 \(m\)，令
\[
C_m=2H+\log m,\qquad
b_{p,m}=\frac{\log m}{\sqrt m}
\int_{E_p}g_p(u)g_p(C_m-u)\,du\ge0,
\qquad r_p=\sum_m b_{p,m}.
\tag{1}
\]
则对全部实数 \(t\ge p^4\)，有对 \(p,t\) 一致的完整旧奇 Weil 形式渐近式
\[
\boxed{\quad
A_{p^2,-}[f_{p,t}]
=\log t+\sum_m b_{p,m}\cos(tC_m)+O(1).
\quad}\tag{2}
\]
这里 \(\|f_{p,t}\|_2^2=1+O(p^2/t)\)，\(f_{p,t}\) 属于完整闭形式域。进一步，note 830 给
\[
r_p=\left(\frac{3\log2}{128\zeta(2)}+o(1)\right)p.
\tag{3}
\]
所以存在绝对 \(C>0\)，使 \(t\ge\exp(r_p+C)\) 时 \(A_{p^2,-}[f_{p,t}]>0\)。反向，若某个固定 \(0<\varepsilon<1/2\) 下存在 \(p\to\infty\)、\(p^4\le t_p\le\exp((1-2\varepsilon)r_p)\) 使所有参与的 \(m\) 都满足
\[
\cos(t_p C_m)\le-1+\varepsilon,
\tag{4}
\]
则 \(A_{p^2,-}[f_{p,t_p}]\le-\varepsilon r_p+O(1)<0\)，从而这些具体测试函数将反驳 RH。式 (4) 的**有限频率同时相位条件尚未证明**；Kronecker 定理只给某些趋于无穷的 \(t\)，没有本命题所需的上界。

## Fourier 成本

记 \(L=\log(1+p^{-2})\)。\(E_p\) 是 \(O(p^2)\) 个相离的长度 \(L\) 槽之并，且 \(|E_p|=O(1)\)。由 (3) 的较弱结论 \(k_p=\|e^{u/2}\mathbf1_{E_p}\|_2^2/p\asymp p\)，在 \(E_p\) 上 \(e^{u/2}\asymp p\)，故
\[
\|g_p\|_2=1,\quad \|g_p\|_1+\|g_p\|_\infty\ll1,
\quad \operatorname{Var}_{\mathbb R}(g_p)\ll p^2.
\tag{5}
\]
零延拓计入所有槽端点跳跃。按 \(\widehat g(\xi)=\int g(u)e^{-i\xi u}du\)，BV 分部积分及 (5) 给 \(|\widehat g_p(\xi)|\ll\min(1,p^2/|\xi|)\)。以 \(p^4\) 分开积分并用 Plancherel，得到
\[
\frac1{2\pi}\int_{\mathbb R}\log(1+|\xi|)|\widehat g_p(\xi)|^2d\xi\ll H.
\tag{6}
\]
更精确地，令 \(\{x_j\}\) 为 \(E_p\) 的全部槽端点，\(\alpha_j\) 为 \(g_p\) 在这些点的跳跃。note 829 的分数间距给
\[
\#\{x_j\}=O(p^2),\qquad |\alpha_j|\ll1,\qquad
|x_j-x_k|\gg p^{-2}\quad(j\ne k).
\tag{6a}
\]
在槽内部 \(g'_p=g_p/2\)，故分布导数满足
\[
i\xi\widehat g_p(\xi)
=\sum_j\alpha_j e^{-i\xi x_j}
+\widehat{g'_p\mathbf1_{E_p}}(\xi),
\qquad \|g'_p\mathbf1_{E_p}\|_1\ll1.
\tag{6b}
\]
展开平方、逐对积分及按端点次序求调和级数，任意 \(R\ge C p^2H\) 都有
\[
\begin{aligned}
\int_R^{2R}\left|\sum_j\alpha_j e^{-i\xi x_j}\right|^2d\xi
&\ll R\sum_j|\alpha_j|^2+
\sum_{j\ne k}\frac{|\alpha_j\alpha_k|}{|x_j-x_k|}\\
&\ll Rp^2+p^4H\ll Rp^2.
\end{aligned}
\tag{6c}
\]
负频率相同。以 dyadic 区间求和，得到对 \(T\ge Cp^2H\)
\[
\int_{|\xi|>T}|\widehat g_p(\xi)|^2d\xi\ll\frac{p^2}{T},
\qquad
\int_{|\xi|\le T}|\xi|\,|\widehat g_p(\xi)|^2d\xi
\ll p^2H+p^2\log(2T).
\tag{6d}
\]
其关于 \(u\mapsto2H-u\) 反射后的下臂函数满足同一界。

对 \(q(\xi)=\log(1+|\xi|)\)，三角不等式给
\[
|q(\xi)-q(t)|\le q(\xi-t),\qquad
|q(\xi)-q(t)|\le q(\xi+t),\quad t\ge0.
\tag{7}
\]
相应不等式分别用于频率 \(+t\)、\(-t\) 的分量。把积分按 \(|\xi\mp t|\le t/2\) 和其补集分开：前者由 (6d) 的截断一阶矩和 \(|q(\xi)-q(t)|\ll|\xi\mp t|/t\) 控制；后者由 (6d) 的尾界逐 dyadic 壳控制。于是每个调制分量的加权误差至多 \(O(p^2\log(2t)/t)\)。事实上 \(f_{p,t}\) 是上下两臂函数各乘 \(e^{itu},e^{-itu}\) 的四项有限和；下臂相位 \(e^{\pm2iHt}\) 的模为一。展开 Fourier 能量，以 \(2|zw|\le|z|^2+|w|^2\) 支付交叉项，得
\[
\frac1{2\pi}\int q(\xi)|\widehat f_{p,t}(\xi)|^2d\xi
=\log(1+t)\|f_{p,t}\|_2^2
+O\!\left(\frac{p^2\log(2t)}t\right).
\tag{8}
\]
由于 \(\|f_{p,t}\|_1\ll1\)，在 \(|\xi|<1\) 可用 \(|\widehat f_{p,t}|\ll1\) 积分 \(|\log|\xi||\)；在 \(|\xi|\ge1\)，\(q(\xi)-\log|\xi|\le\log2\)。因此 (8) 把 \(q\) 换为 \(\log|\xi|\) 只改变 \(O(1)\)。

为直接核对 (9) 的常数与核，令 \(\mathcal L[f]=(2\pi)^{-1}\int\log|\xi|\,|\widehat f(\xi)|^2d\xi\)，\(\tau_r f(u)=f(u-r)\)。Fourier 恒等式
\[
\log|\xi|=\int_0^1\frac{1-\cos(r\xi)}r\,dr
-\gamma_E-\int_1^\infty\frac{\cos(r\xi)}r\,dr
\]
对紧支撑有限对数能量函数，先在余弦积分中加入 \(e^{-\epsilon r}\)，再令 \(\epsilon\downarrow0\)，给
\[
\mathcal L[f]=\frac12\int_0^1\frac{\|f-\tau_r f\|_2^2}{r}\,dr
-\gamma_E\|f\|_2^2
-\int_1^\infty\frac{\operatorname{Re}\langle f,\tau_r f\rangle}{r}\,dr.
\tag{8a}
\]
若 \(f\) 只支撑在长度 \(\Delta<1\) 的单槽 \(I=(\ell,\ell+\Delta)\)，最后的相关积分为零。将 \(0<r<\Delta\) 的平移差按两槽内重叠和两端越界部分拆开、再按 \(h(z)=\sqrt\Delta f(\ell+\Delta z)\) 缩放，精确得到
\[
\mathcal L[f]
=\bigl(\log(1/\Delta)-\gamma_E\bigr)\|h\|_2^2
+\frac14\int_0^1\!\int_0^1\frac{|h(z)-h(w)|^2}{|z-w|}\,dz\,dw
-\frac12\int_0^1\log(z(1-z))|h(z)|^2dz.
\tag{8b}
\]
这与 note 790 式 (4) 比较，说明 \(H_{\rm Leg}+V+c_0\) 的每个单槽自形式**精确等于** \(\mathcal L-\log(2\pi)I\)。对两个相离槽，\(\mathcal L\) 的算子交叉核是 \(-1/(2d)\)，\(d=|u-v|\)，而 note 780 给 \(H_{\rm Leg}+V+c_0\) 的交叉核 \(-K(d)\)，
\[
K(d)=\frac{e^{-d/2}}{1-e^{-2d}},\qquad
\sup_{d>0}\left|K(d)-\frac1{2d}\right|<\infty.
\tag{8c}
\]
正则 gamma 核 \(\rho\) 亦在 \([0,\infty)\) 有界。这里只在 \(E_p\cup(2H-E_p)\) 上压缩，其总测度为 \(O(1)\)。对有界核作 Schur 检验遂给
\[
\left|G_{p^2}[f]-\frac1{2\pi}\int\log|\xi|\,|\widehat f(\xi)|^2d\xi\right|
\ll\|f\|_2^2
\qquad(\operatorname{supp}f\subset E_p\cup(2H-E_p)).
\tag{9}
\]
又因 \(g_p^2\) 的零延拓总变差为 \(O(p^2)\)，分部积分给
\[
\|f_{p,t}\|_2^2=\|g_{p,t}\|_2^2
=1+\int g_p(u)^2\cos(2tu)du=1+O(p^2/t).
\tag{10}
\]
对 \(t\ge p^4\)，\(p^2\log t/t=O(1)\)，所以 (8)--(10) 合成
\[
G_{p^2}[f_{p,t}]=\log t+O(1).
\tag{11}
\]

## 真素数相位和与余项

式 (1) 的 \(m\) 只落在 \(m\asymp p^2\) 的固定比例带；Chebyshev 上界给
\[
\sum_m\frac{\log m}{\sqrt m}\ll p.
\tag{12}
\]
余弦积公式把真实反射项精确写为
\[
R_p[g_{p,t}]
=\sum_m b_{p,m}\cos(tC_m)
+\sum_m\frac{\log m}{\sqrt m}
\int g_p(u)g_p(C_m-u)\cos(t(2u-C_m))du.
\tag{13}
\]
由 (5) 与 BV 乘积法则，后一积分的被积函数在整条实线上总变差至多 \(O(p^2)\)，对每个 \(m\) 一致。再用 (12) 与分部积分，(13) 的末项为 \(O(p^3/t)\)。

同时 \(e^{u/2}g_p(u)\) 的零延拓总变差为 \(O(p^3)\)，所以
\[
K_p[g_{p,t}]=p^{-1}\left|\sqrt2\int e^{u/2}g_p(u)\cos(tu)du\right|^2
\ll p^5/t^2.
\tag{14}
\]
槽外全轮廓分解式 (6) 的 \(D_p\) 在该奇空间压缩上的范数为 \(O(1)\)。式 (11)、(13)--(14) 因此给更细的
\[
A_{p^2,-}[f_{p,t}]
=\log t+\sum_m b_{p,m}\cos(tC_m)
+O\!\left(1+\frac{p^3}{t}+\frac{p^5}{t^2}\right).
\tag{15}
\]
当 \(t\ge p^4\) 即为 (2)。零延拓阶跃函数具有有限对数 Fourier 能量，(6)--(8) 已直接证明 \(f_{p,t}\) 属于闭形式域；note 004 的光滑核心还能把任何严格负值逼近为光滑紧支撑测试函数。

## 调制参数中的密度一正性

同一组真实素数权还给出一个无条件的参数平均结论。令
\[
F_p(t)=\sum_m b_{p,m}\cos(tC_m).
\]
对任意实区间 \(I\) 长度为 \(T>0\)，有
\[
\boxed{\quad
\int_I |F_p(t)|^2dt\ll TH+p^2H^2.
\quad}\tag{16}
\]
因而对 \(T\ge p^4\)，在 \([T,2T]\) 中使完整形式严格为负的参数集满足
\[
\boxed{\quad
\frac1T\left|\{t\in[T,2T]:A_{p^2,-}[f_{p,t}]<0\}\right|
\ll \frac{H}{(\log T)^2}\le\frac{C}{H}.
\quad}\tag{17}
\]
这里 \(|\cdot|\) 表示 Lebesgue 测度。对 \(T\ge e^{r_p+C}\)，式 (2) 更给该集合为空；(17) 对未被此平凡上界排除的频率尤其有用。

证明 (16)。Cauchy--Schwarz 及 \(m\asymp p^2\) 给 \(b_{p,m}\ll H/p\)，而 (12) 给 \(\sum_m b_{p,m}=r_p\ll p\)。因此
\[
\sum_m b_{p,m}^2\ll H.
\tag{18}
\]
不同参与素数 \(m,n\) 满足
\(|C_m-C_n|=|\log(m/n)|\gg |m-n|/p^2\)。
对每个固定 \(m\)，用 \(b_{p,n}\ll H/p\) 和整数调和和，有
\[
\sum_{n\ne m}\frac{b_{p,n}}{|C_m-C_n|}
\ll p^2\frac Hp\sum_{1\le j\ll p^2}\frac1j
\ll pH^2.
\]
再乘 \(b_{p,m}\) 求和，全部差频交叉积分的绝对值至多 \(O(p^2H^2)\)。另一方面 \(C_m+C_n\gg H\)，故全部和频交叉积分至多
\(O(r_p^2/H)=O(p^2/H)\)。
将 \(2\cos(tC_m)\cos(tC_n)=\cos(t(C_m-C_n))+\cos(t(C_m+C_n))\) 在 \(I\) 上积分，差频对角由 (18) 至多 \(O(TH)\)，证明 (16)。

若 \(t\in[T,2T]\)、\(T\ge p^4\) 且完整形式为负，则由 (2)
\(F_p(t)\le-\log T+O(1)\le-\tfrac12\log T\)。
Chebyshev 测度不等式、(16) 及 \(p^2H^2\ll TH\) 给 (17)。这只限制例外频率的测度；任何单个可能的负方向仍未被排除。

## 边界

式 (2) 直接支付 note 828 的负号调制在同一方向上的 Archimedean 频率成本。它说明固定 \(p\) 的负本质谱序列在完整 Weil 形式中最终转正，同时给出可能反例必须满足的有限频率相位条件。它没有构造满足 (4) 的 \(t_p\)，也不控制非调制槽轮廓或完整补空间；因此既不证明也不反驳 RH。note 830 的低变差界另外排除本族在 \(t\le\exp(\kappa H^{3/2}/(\log H)^2)\) 内出现固定线性量级的中心化负谱，但仍未覆盖 (4) 的整个有限频率范围。
