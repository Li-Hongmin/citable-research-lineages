# 顶端四素数门的两侧平滑密度在目标尺度内支付

日期：2026-10-01。依赖 [scratch/881](881-top-prime-cofactor-tube-pays-its-smooth-q-density-at-target-scale.md) 对 \(q\) 侧平滑密度与素数幂的无条件支付、[scratch/878](878-prime-cofactor-tube-self-cancels-through-bandpass-sidelobes.md) 式 (23)--(26) 对原过滤门的精确比较，以及 [scratch/868](868-large-physical-gcd-is-paid-in-the-full-observation-gram.md) 的非别名核行和。本稿进一步支付 \(p\) 侧平滑密度与素数幂，留下双中心化的 \((\Lambda(p)-1)(\Lambda(q)-1)\) 带通形式。独立代理已只读复核精确拆分、误差界及原门接口并报告 PASS；异源模型复核未做，故留在 scratch。它没有证明所剩双线性形式的目标上界或 RH。

## 命题

沿用 scratch/881 的 \(M=2Y\)、\(Y^{1/5}\le H\le Y^{1/4}\)、\(J=[a,b]\subset(1,2)\)、\(\phi\)、\(W(q)=4(1-\log2/\log q)\)、\(w_H\) 与真实顶端素数管
\[
 F_{\rm top}(h)=\frac1M
 \sum_{\substack{p,q\ {\rm prime}\\H/2<q\le H,\ pq\in MJ}}
 4\log(q/2)\phi(pq/M)e(-hpq/M).
\tag{1}
\]
定义双中心化的真实算术和
\[
 F_{\rm bil}(h)=\frac1M
 \sum_{\substack{p,q\ge1\\H/2<q\le H,\ pq\in MJ}}
 \frac{W(q)}{\log p}
 \bigl(\Lambda(q)-1\bigr)\bigl(\Lambda(p)-1\bigr)
 \phi(pq/M)e(-hpq/M).
\tag{2}
\]
这里所有非零项有 \(p\asymp M/H\gg2\)，所以 \(1/\log p\) 定义良好。则一致于整个 \(H\) 范围，
\[
 \boxed{\qquad
 \sum_h w_H(h)|F_{\rm top}(h)-F_{\rm bil}(h)|^2
 \ll_{s,\psi,J}\frac{\log^4(2M)}H
 \ll_{\varepsilon,s,\psi,J}H^4M^{-1+\varepsilon}
 \quad(\forall\varepsilon>0).
 \qquad}\tag{3}
\]
特别地，scratch/878 式 (24) 的真实顶端管完整能量达到 \(H^4M^{-1+\varepsilon}\) 当且仅当 (2) 的能量达到同类界；结合其式 (26)，原过滤门四素数 \(q\ne r\) 交叉的上界也与 (2) 的界处于同一目标尺度。这只支付了两侧的一变量密度及素数幂；(2) 仍可能含全部未解的固定幂算术难度。

## 精确拆分

令 \(F_{\rm cen}\)、\(F_{\rm sm}^{q}\)、\(F_{\rm pp}^{q}\) 如 scratch/881 式 (1)、(3)--(4)，但固定 \(p\) 权为 \(\mathbf1_{p\ {\rm prime}}\)。于是逐频
\[
 F_{\rm top}=F_{\rm cen}+F_{\rm sm}^{q}-F_{\rm pp}^{q},
\quad
 \sum_hw_H(h)\bigl(|F_{\rm sm}^{q}(h)|^2+|F_{\rm pp}^{q}(h)|^2\bigr)
 \ll\frac{\log^4(2H)}H.
\tag{4}
\]
对 \(p>2\) 置 \(U(p)=1/\log p\)。逐整数精确有
\[
 \mathbf1_{p\ {\rm prime}}
 =U(p)\bigl(\Lambda(p)-1\bigr)+U(p)
 -U(p)\Lambda(p)\mathbf1_{p=r^k,\ r\ {\rm prime},\ k\ge2}.
\tag{5}
\]
事实上素数上右边为 \(U(p)\Lambda(p)=1\)；非素数幂合数上前两项相消；在高次素数幂上末项恰删去 \(U(p)\Lambda(p)=1/k\)。将 (5) 代入 \(F_{\rm cen}\) 的 \(p\) 和，得
\[
 F_{\rm cen}=F_{\rm bil}+F_{\rm sm}^{p}-F_{\rm pp}^{p},
\tag{6}
\]
其中
\[
\begin{aligned}
 F_{\rm sm}^{p}(h)
 &=\frac1M\sum_{\substack{p,q\ge1\\H/2<q\le H,\ pq\in MJ}}
 \frac{W(q)}{\log p}(\Lambda(q)-1)
 \phi(pq/M)e(-hpq/M),\\
 F_{\rm pp}^{p}(h)
 &=\frac1M\sum_{\substack{p=r^k,\ k\ge2,\ q\ge1\\H/2<q\le H,\ pq\in MJ}}
 \frac{W(q)\Lambda(p)}{\log p}(\Lambda(q)-1)
 \phi(pq/M)e(-hpq/M).
\end{aligned}\tag{7}
\]
因此 (4)、(6)--(7) 是不带误差的有限和恒等式；只需估计 \(F_{\rm sm}^{p}\)、\(F_{\rm pp}^{p}\)。

## \(p\) 侧平滑密度

固定 \(q\in(H/2,H]\)，非零 \(p\) 位于 \(p\asymp_JP\)、\(P=M/H\)。令
\[
 g_q(p)=\frac{\phi(pq/M)}{\log p}\mathbf1_{pq\in MJ}.
\]
由于 \(\phi\in C_c^3\)、\(q/M\asymp1/P\)、\(\log p\asymp\log P\)，而 \(J\) 只贡献两个跳点，\(g_q\) 的离散上确界及总变差都为 \(O_{\psi,J}(1/\log P)\)。有限几何和与 Abel 求和给
\[
 \left|\sum_p g_q(p)e(-hpq/M)\right|
 \ll_{\psi,J}\frac1{\log P}
 \min\!\left(P,\frac1{\|hq/M\|}\right).
\tag{8}
\]
当 \(w_H(h)\ne0\) 时 \(|h|\asymp H\)、\(q\asymp H\)，所以 \(0<|hq/M|\ll H^2/M=o(1)\)；又 \(M/(|h|q)\ll P\)。因此 (8) 为
\[
 O_{\psi,J}\!\left(\frac{M}{|h|q\log P}\right).
\]
用 \(|W(q)|\ll1\) 及 Chebyshev 界
\(\sum_{H/2<q\le H}(\Lambda(q)+1)/q\ll1\)，得
\[
 |F_{\rm sm}^{p}(h)|
 \ll_{\psi,J}\frac1{|h|\log P}
 \ll_{\psi,J}\frac1{H\log M}.
\]
频带含 \(O(H)\) 个 \(h\)，故
\[
 \sum_hw_H(h)|F_{\rm sm}^{p}(h)|^2
 \ll_{s,\psi,J}\frac1{H\log^2M}.
\tag{9}
\]

## \(p\) 侧素数幂

在 \(p\asymp_JP\) 的范围，高次素数幂至多 \(O(\sqrt P\log(2P))\) 个，且对每个有 \(0<\Lambda(p)/\log p\le1\)。固定一个这样的 \(p\)，由 \(|W(q)|\ll1\)、\(|\phi|\ll1\) 与 Chebyshev 界
\(\sum_{q\le H}(\Lambda(q)+1)\ll H\)，式 (7) 中的 \(q\) 和绝对值为 \(O_{\psi,J}(H)\)。所以逐频
\[
 |F_{\rm pp}^{p}(h)|
 \ll_{\psi,J}\frac{\sqrt P\,H\log(2P)}M
 =\frac{\log(2P)}{\sqrt P}.
\]
平方后对 \(O(H)\) 个带通频率求和，
\[
 \sum_hw_H(h)|F_{\rm pp}^{p}(h)|^2
 \ll_{s,\psi,J}\frac{H\log^2(2P)}P
 =\frac{H^2\log^2(2P)}M
 \ll\frac{\log^2(2M)}H,
\tag{10}
\]
最后一步使用 \(H^3\ll M\)。

由 (4)、(6)、(9)--(10) 的平方三角不等式得到 (3) 第一界；\(H^5\ge Y=M/2\) 使固定对数幂被 \(M^\varepsilon H^4/M\) 支付。\(F_{\rm top}\) 与 \(F_{\rm bil}\) 的带通 \(L^2\) 范数因而相差至多目标量级的平方根，证明 (3) 中的双向量级断言。scratch/878 式 (26) 再把完整能量与原过滤门四素数交叉在 \(O(H^4/M)\) 内比较。\(\square\)

## 边界

本稿没有对 (2) 使用短区间素数定理：两侧密度由有限几何和直接支付，高次素数幂由稀疏性支付。剩余的 \((\Lambda(q)-1)(\Lambda(p)-1)\) 是真正的双素数涨落，不能从 scratch/880 所保留的逐 \(q\) 边际短和或单 \(q\) 能量直接控制。若要推进四素数整管的固定幂上界，下一次决定性观测应是 (2) 的跨 \(p,q\) 带通平均，而不是继续估计已支付的一变量层。完整 moving-\(N\) covariance、全尺度局部 Weil 正性与 RH 仍开放。
