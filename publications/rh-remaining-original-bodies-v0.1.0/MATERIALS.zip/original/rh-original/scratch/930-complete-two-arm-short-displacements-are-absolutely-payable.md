# 完整两臂源 Gram 的极小非零物理位移可绝对支付

日期：2026-10-02。沿用 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整奇数源两臂核、频带权、$M,H,D,R,G_\natural$。本文仅对展开后的物理位移作绝对计数，不单独估计较大位移的 signed 和。独立复核后的合并证明已写入 note 850 式 (11)--(18)。

## 命题

对 $T\ge1$，将 note 850 中 $G_{u,v}$ 的 $k,\ell$ 展开限制于 $0<|ku-\ell v|\le T$，记为 $G^{\le T}_{u,v}$。则在 $M$ 充分大时，
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd},\ u\ne v\\
g=(u,v),\ \max(u/g,v/g)>R}}
|G^{\le T}_{u,v}|
\ll_{\psi,\eta}
\frac{H(T+H)\log^4(2M)}{M}.
\quad}                                                     \tag{1}
\]
事实上右侧还控制限制内所有乘子项的绝对值之和。取
\[
T_\natural=\frac{H^3}{\log^4(2M)},
\qquad
G_\natural=\left\lceil\frac{M\log^4(2M)}{H^4}\right\rceil.
\tag{2}
\]
由 $H\gg\log^2M$，式 (1) 在 $T=T_\natural$ 时为 $O_{\psi,\eta}(H^4/M)$。故 note 850 的完整不同源 signed 协方差满足
\[
\boxed{\quad
\mathfrak C_{\mathrm{odd}}
=\sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd},\ u\ne v\\
(u,v)\le G_\natural}}
\mu(u)\mu(v)G^{>T_\natural}_{u,v}
+O_{\psi,\eta}(H^4/M),
\quad}                                                     \tag{3}
\]
其中 $G^{>T}=G-G^{\le T}$；在这个留存区，所有活动乘子项均有 $ku-\ell v\ne0$，且 $a,b>R$。特别是任何**固定非零**物理位移层都已包含在绝对支付区。若写 $r=ka-\ell b$，则留存项还满足
\[
|r|>\frac{T_\natural}{G_\natural}
\ge\frac{H^7}{2M\log^8(2M)}\longrightarrow\infty.
\tag{3a}
\]
所以任何固定既约位移 $r$ 也最终被支付；真正剩余的是长度随 $M$ 增长的位移平均。

## 证明

记 $g=(u,v)$、$a=u/g$、$b=v/g$。高既约比例 $\max(a,b)>R$ 与 $u,v<2M/3$ 给 $g<2M/(3R)$。如 note 850 式 (7) 前所证，固定 $g,k$ 的活动 $a$ 至多 $O_\psi(M/(kg))$ 个；$M/(kg)\gg R/H\to\infty$ 吸收了整数计数中的 $+1$。

对固定 $g,k,\ell,a$，条件 $|g(ka-\ell b)|\le T$ 将整数 $b$ 限在长 $2T/(g\ell)$ 的区间内，故至多 $O(1+T/(g\ell))$ 个。放宽奇性、互素性与 $b$ 的物理窗口合法。又 $|J_H(r)|\le\sum_h\eta(h/H)\ll_\eta H$，所以固定 $g,k,\ell$ 的全部受限乘子项绝对质量至多
\[
\frac{H|W(k)W(\ell)|}{M^2}
\frac{M}{kg}\left(1+\frac{T}{g\ell}\right)
=|W(k)W(\ell)|
\left(\frac{H}{Mkg}+\frac{HT}{Mk\ell g^2}\right).
\tag{4}
\]
note 850 式 (8) 给
$A_H=\sum_{k<64H}|W(k)|/k\ll\log^2(2H)$ 与
$B_H=\sum_{k<64H}|W(k)|\ll H\log(2H)$。对 $k,\ell$ 求和，再对 $g<2M/(3R)$ 求和，由
$\sum_{g\le2M/(3R)}g^{-1}\ll\log(2M)$ 和
$\sum_{g\ge1}g^{-2}\ll1$，得到
\[
\sum_{g,k,\ell}\text{式 (4) 右侧}
\ll\frac{H A_HB_H\log(2M)}M
+\frac{HT A_H^2}M
\ll\frac{H^2\log^4(2M)}M
+\frac{HT\log^4(2M)}M.
\]
这证明 (1)。

note 850 式 (3) 已把 $g>G_\natural$ 及小既约比例对支付到 $O(H^4/M)$。在留存区 $g\le G_\natural$，note 850 式 (10) 保证 $a,b>R$，故可再用 (1) 去掉 $G^{\le T_\natural}$，得到 (3)。若 $ka=\ell b$ 且 $(a,b)=1$，则 $a\mid\ell$、$b\mid k$，从而 $\max(a,b)<64H<R$；所以留存区无精确碰撞。$\square$

## 光滑频带下的远位移绝对支付

若进一步取 note 849 所用的 $\eta\in C_c^\infty$，则对任意固定 $\delta,B>0$，令 $U=M^{1+\delta}/H$，有
\[
\boxed{\quad
\sum_{\substack{D<u,v<2M/3,\ u,v\ \mathrm{odd},\ u\ne v\\
\max(a,b)>R}}
\sum_{\substack{k,\ell<64H\ \mathrm{active}\\|ku-\ell v|>U}}
\left|\frac{W(k)W(\ell)}{M^2}
\phi(ku/M)\overline{\phi(\ell v/M)}J_H(ku-\ell v)\right|
\ll_{\psi,\eta,\delta,B}M^{-B}.
\quad}                                                     \tag{5}
\]
于是对该光滑频带，式 (3) 可再将 $G^{>T_\natural}$ 换成仅含
$T_\natural<|ku-\ell v|\le M^{1+\delta}/H$ 的乘子和，仍只花 $O(H^4/M)$ 误差。

证明取任意 $A>2$。真实活动项远离非零 Poisson 别名，故
$|J_H(x)|\ll_{A,\psi,\eta}H(1+H|x|/M)^{-A}$。
置 $Q=HU/M=M^\delta$，按
$2^jU<|g(ka-\ell b)|\le2^{j+1}U$ 分壳。固定 $g,k,\ell,a$，第 $j$ 壳的整数 $b$ 至多
$O(1+2^jU/(g\ell))$ 个，而活动 $a$ 至多 $O(M/(kg))$ 个。因此同一 $g,k,\ell$ 的远位移绝对质量至多
\[
\begin{aligned}
&\ll |W(k)W(\ell)|
\sum_{j\ge0}
\left(\frac{H}{Mkg}+\frac{H2^jU}{Mk\ell g^2}\right)
(2^jQ)^{-A}\\
&\ll |W(k)W(\ell)|
\left(\frac{H Q^{-A}}{Mkg}
+\frac{Q^{1-A}}{k\ell g^2}\right).
\end{aligned}                                                \tag{6}
\]
对 $k,\ell,g$ 使用式 (1) 证明中的 $A_H,B_H$ 与两项 $g$ 和，得到
\[
\ll_{A,\psi,\eta}
\frac{H^2\log^4(2M)}M Q^{-A}
+\log^4(2M)Q^{1-A}.
\tag{7}
\]
因 $Q=M^\delta$，任意指定 $B$ 均可由充分大的固定 $A$ 使 (7) 为 $O(M^{-B})$。$\square$

## 边界

式 (3) 是真实完整源 Gram 的双截断；光滑频带下式 (5) 还给出远端支付。两者都没有取得留存位移带的 signed 固定幂节省。对单个固定 $r=ka-\ell b$ 的 Chowla 型相关逐项求界不是本门所需的最小任务；较大位移的加权联合平均仍可包含无法逐项控制的二仿射相关。不能把这些截断当作 RH 或全尺度局部 Weil 正性的证明。
