# 平方自由双臂图的固定素数柱状轮廓有可解的正 Weil 极限（候选）

本稿已晋级为 [note 793](../notes/793-fixed-prime-cylinder-profiles-have-positive-squarefree-two-arm-weil-limits.md)，以后者为准。

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实旧奇压缩和相离核、[note 792](../notes/792-a-single-squarefree-two-arm-farey-family-has-critical-arithmetic-radius.md) 的平方自由双臂家族与调和质量。本文只讨论固定有限多个素数的轮廓；异源复核前保留在 scratch。

## 命题

沿奇素数 \(p\to\infty\)，取 note 792 的 \(\mathcal N_p,S_p,k=p^2\)。固定有限素数集 \(B\subset\{q\ge5\}\)。对每个 \((n,m)\in\mathcal N_p\)，记 \(\sigma_q(n,m)\in\{0,+,-\}\) 分别表示 \(q\nmid nm,q\mid n,q\mid m\)，并令 \(h:\{0,+,-\}^B\to\mathbb C\) 为非零且与 \(p\) 无关的函数。定义
\[
u_{p,h}=\sum_{(n,m)\in\mathcal N_p}
\frac{h((\sigma_q(n,m))_{q\in B})}{\sqrt{nm}}w_{x_{n,m}},
\quad a_q=\frac{\log q}{q},
\quad \pi_q(0)=\frac q{q+2},\quad
\pi_q(+)=\pi_q(-)=\frac1{q+2},\quad
\pi_B=\bigotimes_{q\in B}\pi_q.
\tag{1}
\]
置
\[
B_0=1-\gamma_E-\log\pi+\log24-2\beta_5>0,
\qquad F_\infty=\sum_{q\ge5}\frac{2a_q}{q+2},
\tag{2}
\]
其中 \(\beta_5=\lim_{t\to\infty}(P_5(t)-\log t)\)、\(P_5(t)=\sum_{5\le q\le t,\ q\ {\rm prime}}a_q\)，且
\[
\beta_5=-\gamma_E-\sum_q\sum_{r\ge2}\frac{\log q}{q^r}
-\frac{\log2}{2}-\frac{\log3}{3}<0.
\]
对只在 \(q\) 坐标不同的 \(\sigma\)，写 \(h_{\sigma_{\ne q},s}\) 为 \(q\) 状态 \(s\) 下的值，定义
\[
\begin{aligned}
\mathcal E_q(h)=\frac{a_q}{q+2}
\sum_{\sigma_{\ne q}}\pi_{B\setminus\{q\}}(\sigma_{\ne q})
\bigl[&|h_{\sigma_{\ne q},+}|^2+|h_{\sigma_{\ne q},-}|^2\\
&+q|h_{\sigma_{\ne q},0}-h_{\sigma_{\ne q},+}|^2
+q|h_{\sigma_{\ne q},0}-h_{\sigma_{\ne q},-}|^2
+|h_{\sigma_{\ne q},+}-h_{\sigma_{\ne q},-}|^2\bigr].
\end{aligned}\tag{3}
\]
则真实 Weil Rayleigh 商有极限
\[
\boxed{\quad
\lim_{p\to\infty}\frac{\langle u_{p,h},A_{p^2,-}u_{p,h}\rangle}{\|u_{p,h}\|^2}
=B_0+\sum_{q\notin B}\frac{2a_q}{q+2}
+\frac{\sum_{q\in B}\mathcal E_q(h)}{\|h\|_{L^2(\pi_B)}^2}.
\quad}\tag{4}
\]
特别地，该极限至少为 \(B_0>0\)，对每个固定有限柱状轮廓都严格正。

这个有限维问题可精确最小化。令
\[
\lambda_q=\frac{a_q}{2}
\bigl(q+3-\sqrt{q^2+6q+1}\bigr)>0.
\tag{5}
\]
则
\[
\boxed{\quad
\inf_{h\ne0}\lim_{p\to\infty}
\frac{\langle u_{p,h},A_{p^2,-}u_{p,h}\rangle}{\|u_{p,h}\|^2}
=B_0+\sum_{q\notin B}\frac{2a_q}{q+2}
+\sum_{q\in B}\lambda_q.
\quad}\tag{6}
\]
沿有限集 \(B\uparrow\{q\ge5\}\)，右端递减至严格正的
\[
B_0+\sum_{q\ge5}\lambda_q>0.
\tag{7}
\]
自然权 \(h\equiv1\) 的极限为 \(B_0+F_\infty\)，但它并非这个有限维问题的最小向量。仅调整 \(q=5\)，取 \(h(0)=1\)、\(h(+)=h(-)=(\sqrt{14}-2)/2\)，便把其极限严格降低
\[
\frac{\log5}{5}\left(\sqrt{14}-\frac{26}{7}\right)>0.
\tag{8}
\]

## 调和极限与算术势

note 792 的二变量 Euler 积及调和卷积证明：对固定有限 \(B\)，状态向量的加权质量在归一化后趋于 \(\pi_B\)。具体地，固定状态 \(\sigma\) 对应的局部 Euler 因子是每个 \(q\in B\) 的 \(1,q^{-s},q^{-t}\) 之一；在 \((s,t)=(1,1)\) 除以原因子 \(1+2/q\) 即给 (1) 的三个概率。因此
\[
\|u_{p,h}\|^2
\sim\mathfrak c\log X\log Y\,\|h\|_{L^2(\pi_B)}^2,
\qquad X=(p-1)/4,\quad Y=(p-1)/3.
\tag{9}
\]
这也给有限多个素数状态的渐近独立性。对任意固定 \(h\)，\(|h|^2\) 有界、(9) 的右侧严格正；其调和质量集中于 \(4n,3m\le Q=\lfloor p/\log p\rfloor\)。在内区，不同物理 Farey 中心的对数间距 \(d\gg Q^{-2}\)，由 note 791 式 (12) 的 \(O(\Delta^3/d^3)\)、\(\Delta\asymp p^{-2}\)，非对角行和为 \(O(\Delta^3Q^6)=o(1)\)；同一 \(w_x\) 的两中心交叉及 polar 压缩亦为 \(o(1)\)。但 note 791 式 (13) 的 \(D_k+O(\Delta)\) 是单半槽对角。对归一化左右半槽 \(e_-,e_+\)，相离核 \(K(d)=1/(2d)+O(1)\) 给
\[
\langle e_-,G_ke_+\rangle
=-\Delta^{-1}\int_0^\Delta\!\int_0^\Delta K(s+t)\,ds\,dt
=-\log2+O(\Delta).
\]
故每个物理偶极的对角为 \(D_k+\log2+o(1)\)。用 note 791 的全局 \(\|E_p\|=O(1)\) 支付内区外的 \(o(1)\) 调和质量，得到
\[
\frac{\langle u_{p,h},E_pu_{p,h}\rangle}{\|u_{p,h}\|^2}
\longrightarrow\log2.
\tag{10}
\]

令 \(v_{n,m}=(nm)^{-1/2}\)、\(r_{n,m}=(C_{S_p}v)_{n,m}/v_{n,m}\)。note 791 式 (4) 的素数边在原始比值 \(4n/(3m)\) 中只改变一个 \(q\ge5\) 指数 \(0\leftrightarrow\pm1\)；其 \(q^2\) 边使 \(+1\leftrightarrow-1\)。折回到大于一的 Farey 标签只互换比值边与乘积边，固定的 \(2,3\) 赋值排除额外边。逐项计数得到精确行比
\[
\begin{aligned}
r_{n,m}={}&\log n+\log m+P_5(X/n)+P_5(Y/m)\\
&-\sum_{\substack{q\mid nm\\q\le X/n}}a_q
-\sum_{\substack{q\mid nm\\q\le Y/m}}a_q
+\sum_{\substack{q\mid n\\mq\le Y}}a_q
+\sum_{\substack{q\mid m\\nq\le X}}a_q.
\end{aligned}
\tag{11a}
\]
两个换臂和恰好抵消对方坐标的排除项，所以行比亦精确等于
\[
r_{n,m}=
\left(\log n+P_5(X/n)-\sum_{\substack{q\mid n\\q\le X/n}}a_q\right)
+\left(\log m+P_5(Y/m)-\sum_{\substack{q\mid m\\q\le Y/m}}a_q\right).
\tag{11b}
\]
在任何固定状态 \(\sigma\) 的调和平均下，素数定理给
\[
\log n+P_5(X/n)=\log X+\beta_5+o_{\rm av}(1),
\quad
\log m+P_5(Y/m)=\log Y+\beta_5+o_{\rm av}(1).
\tag{11}
\]
对固定 \(q\) 的截止，调和概率趋于一；(11b) 中占据 \(q\) 的净行比为 \(-a_q\)。对 \(q\notin B\)，条件占据概率趋于 \(2/(q+2)\)。尾部可用 \(\Pr_{|h|^2v^2}(q\mid nm)\ll_h1/q\) 和 \(\sum_q a_q/q<\infty\) 支配。因此
\[
\frac{\sum_{n,m}|h(\sigma)|^2v_{n,m}^2r_{n,m}}
{\|u_{p,h}\|^2}
=\log X+\log Y+2\beta_5
-\sum_{q\notin B}\frac{2a_q}{q+2}
-\frac{\sum_{q\in B}a_q\,\mathbb E_{\pi_B}(|h|^2\mathbf1_{\sigma_q\ne0})}
{\|h\|_{L^2(\pi_B)}^2}+o(1).
\tag{12}
\]

## 边能量与有限维谱

对 \(f=v h(\sigma)\)，scratch 839 式 (1) 的精确基态变换写为
\[
\langle f,(D_kI-C_{S_p})f\rangle
=\sum_{n,m}(D_k-r_{n,m})|f_{n,m}|^2
+\frac12\sum_{i,j}C_{S_p}(i,j)v_iv_j|h(\sigma_i)-h(\sigma_j)|^2.
\tag{13}
\]
若一条边不改变 \(B\) 中的状态，其边能量为零；能改变状态 \(q\in B\) 的边仅为 \(0\leftrightarrow+\)、\(0\leftrightarrow-\) 的 \(q\) 边及 \(+\leftrightarrow-\) 的 \(q^2\) 换臂边。固定其他素数状态和剩余 \((n,m)\)，在端点截止之外，这三种无向边相对于空状态调和权的 conductance 依次为 \(a_q,a_q,a_q/q\)。截止层在 (9) 的调和质量中占比趋零，故 (13) 的归一化边能量趋于 (3) 中三个差平方项除以 \(\|h\|^2\)。式 (12) 的占据势给 (3) 中前两个平方项。再用 \(D_k-(\log X+\log Y)=1-\gamma_E-\log\pi+\log12+o(1)\) 与 (10)，得到 (4)。

局部形式 (3) 是各 \(q\) 坐标上非负自伴矩阵的形式和。单个 \(q\) 的反对称向量 \((0,1,-1)\) 的广义特征值为 \(a_q(q+3)\)。对称子空间 \((g_0,g_+,g_-)=(s,t,t)\) 上，广义特征方程为
\[
\det\begin{pmatrix}
2q-mq&-2q\\-2q&2(q+1)-2m
\end{pmatrix}=0
\quad\Longleftrightarrow\quad
m^2-(q+3)m+2=0,
\qquad m=\lambda/a_q.
\tag{14}
\]
最低根就是 (5)，其正特征向量满足
\[
\frac ts=\frac{\sqrt{q^2+6q+1}-(q-1)}4.
\tag{15}
\]
有限张量积中，各局部算子作用于不同坐标并可同时对角化，最低特征值相加，证明 (6)。常数向量在每个坐标的局部 Rayleigh 值是 \(2a_q/(q+2)\)，严格大于 \(\lambda_q\)；取 \(q=5\) 得 (8)。最后 \(\lambda_q\asymp(\log q)/q^2\)，故 (7) 收敛，而其严格正性由 \(B_0>0\) 保证。\(\square\)

## 边界

正性只覆盖固定有限素数的柱状轮廓，即使允许任意状态耦合；\(B\) 随 \(p\) 增长、宏观 \(\log n/\log p\) 轮廓、Farey 家族外的方向及完整正交补 Schur 反馈均未受控。式 (8) 表明自然调和权虽有正 Rayleigh 极限，却并非临界算术谱的真实最优轮廓。此结论不判定全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
