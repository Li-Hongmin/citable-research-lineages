# Haar 观察频带的尖锐部分和阈值与真实三通道拼接（待独立复核）

日期：2026-10-03。针对 [note 870](../notes/870-adjacent-window-haar-gate-for-the-three-channel-observation-band.md) 式 (2)、(4) 的真实算术门。前半部分是任意有界序列的确定性阈值；反模型不是实际三通道系数 \(c(n)\)。末节的拼接估计专门使用真实 \(c(n)\) 与 note 851 的已核验短和输入。当前整份草稿尚未异源复核，不晋级为权威 note。

## 定理

设实序列 \(v_n\) 满足 \(S_v(X)=\sum_{n\le X}v_n\ll X^\beta\)，其中 \(0\le\beta\le1\)。沿整数 \(Y\to\infty\)，令 \(M=2Y\)、\(H=\lceil Y^{1/5}\rceil\)、\(L=\lfloor M/(32H)\rfloor\)，在 \(\mathbb Z/M\mathbb Z\) 上取 \(b_x=v_{M+x}\)，并定义
\[
V_v(Y)=\sum_{x\bmod M}\left|
\sum_{j=0}^{L-1}b_{x-j}-\sum_{j=L}^{2L-1}b_{x-j}
\right|^2.
\]
则
\[
V_v(Y)\ll Y^{1+2\beta}.
\tag{1}
\]
若再有 \(|v_n|\le1\)，逐窗口的平凡界还给出
\[
V_v(Y)\ll\min\{Y^{1+2\beta},\,Y^{13/5}\}.
\tag{1a}
\]
特别地，\(\beta\le7/10\) 足以得到 note 870 式 (4) 在这个端点的 \(V_v(Y)\ll H^2Y^2\)。这个指数对只使用全局部分和界的推法是尖锐的：对每个固定 \(\beta>7/10\)，存在单个实序列 \(|v_n|\le1\)、\(S_v(X)\ll_\beta X^\beta\)，以及无限多个 \(Y\to\infty\)，使
\[
V_v(Y)\gg_\beta
\begin{cases}
Y^{1+2\beta},&7/10<\beta\le4/5,\\
Y^{13/5},&4/5\le\beta\le1.
\end{cases}
\tag{2}
\]
所以对适当固定 \(\varepsilon>0\)，这些序列不满足 \(V_v(Y)\ll_\varepsilon H^2Y^{2+\varepsilon}\)。式 (2) 还说明 (1a) 的指数对每个 \(7/10<\beta\le1\) 都取到。尤其 note 869 所导出的 \(X^{9/10+\varepsilon}\) 型全局部分和结论，本身不能支付 note 870 的 Haar 门。

## 证明

任意周期窗口至多在拼接点断成两个普通整数区间；每个区间和都是两个 \(S_v\) 值之差，端点均在 \([M,2M]\)。因此每个长度 \(L\) 的窗和为 \(O(M^\beta)\)，两个窗之差同阶，在 \(M\) 个位置平方求和即得 (1)。当 \(\beta\le7/10\)，有 \(1+2\beta\le12/5\)，而 \(H^2Y^2\asymp Y^{12/5}\)。
若 \(|v_n|\le1\)，两窗差至多 \(2L\ll Y^{4/5}\)，从而另有 \(V_v\ll YL^2\ll Y^{13/5}\)，证明 (1a)。

为证明尖锐性，取 \(X_j=4^j\)、\(Y_j=X_j/2\)、\(H_j=\lceil Y_j^{1/5}\rceil\)、\(L_j=\lfloor X_j/(32H_j)\rfloor\)，只在互不相交的块 \([X_j,2X_j)\cap\mathbb Z\) 上定义
\[
v_n=A_j\cos\left(\frac{2\pi n}{4L_j}\right),
\qquad
A_j=X_j^{\min(\beta,4/5)-4/5},
\tag{3}
\]
其余整数处置零；忽略有限个初始 \(j\) 使 \(L_j\ge1\)。显然 \(|v_n|\le1\)。每块中任意前缀的几何和至多 \(O(L_j)\)，故贡献至多
\(O(A_jL_j)=O(X_j^{\min(\beta,4/5)})\)。各块尺度按 \(4\) 倍增长，先前完整块的总贡献由几何级数控制，因此对全部 \(X\) 有 \(S_v(X)\ll_\beta X^\beta\)。

在 \(Y=Y_j\) 时，note 870 的物理块 \([M,2M)\) 恰为 \([X_j,2X_j)\)，且 \(L=L_j\)。对 \(2L_j\le x<M\)，两个 Haar 窗口均在这一块内。作用于 (3) 的复指数频率 \(1/(4L_j)\) 时，Haar 乘子为
\[
K_{L_j}=\frac{\{1-e(-1/4)\}^2}{1-e(-1/(4L_j))},
\qquad |K_{L_j}|\asymp L_j.
\tag{4}
\]
因此这些 \(x\) 上的输出为振幅 \(\asymp A_jL_j\)、周期 \(4L_j\) 的实正弦波。区间 \([2L_j,M)\) 含 \(\gg M/L_j\) 个完整周期，每周期的平方平均为 \(1/2\)，故
\[
V_v(Y_j)\gg M A_j^2L_j^2
\asymp Y_j^{13/5}A_j^2.
\tag{5}
\]
代入 \(A_j\) 即得 (2)。若 \(7/10<\beta\le4/5\)，式 (2) 与目标 \(Y^{12/5+\varepsilon}\) 之比为 \(Y^{2\beta-7/5-\varepsilon}\)；若 \(\beta\ge4/5\)，比为 \(Y^{1/5-\varepsilon}\)。分别取正的较小 \(\varepsilon\) 便得到所述失败。\(\square\)

## 边界

本定理不估计实际 \(c(n)\)。它只证明一种方法边界：把真实三通道先压成单个全局部分和上界，若所得指数超过 \(7/10\)，就不能仅凭该上界支付 \(H=Y^{1/5}\) 的局部 Haar 均方。下一步仍须直接利用频带、局部相关或真实算术结构。

## 真正观察频带的逐指数尖锐阈值

固定 \(1/5\le\alpha<1/4\)、实非负非零 \(\psi\in C_c^\infty((1,2))\)，沿整数 \(Y\to\infty\) 令 \(M=2Y\)、\(H=\lceil Y^\alpha\rceil\)，并对任意实序列 \(v\) 定义
\[
\mathcal A_h^v(Y)=\sum_{M<m<2M}\frac{v_m}{m}\psi(m/M)e(-hm/M).
\tag{6}
\]
若 \(|v_m|\le1\)、\(S_v(X)\ll X^\beta\)，则 note 870 式 (3) 的同一证明（将其中 \(|c(m)|\ll\log Y\) 换成 \(|v_m|\le1\)）和上面的 (1) 给出，对任意固定的非负偶频带权 \(\eta\)，其中 \(\operatorname{supp}\eta\subset\{1/2\le|t|\le4\}\)，
\[
\sum_h\eta(h/H)|\mathcal A_h^v(Y)|^2
\ll_{\psi,\eta}H^2Y^{2\beta-2}+H^{-2}.
\tag{7}
\]
此式在整个 \(Y^{1/5}\le H\le Y^{1/4}\) 也成立，只需按实际 \(H\) 取 \(L=\lfloor M/(32H)\rfloor\)。在本段固定的 \(H\asymp Y^\alpha\) 上，\(\beta\le1/2+\alpha\) 足以得到 \(O(H^4/Y)\)：第一项用 \(Y^{2\beta-1}\le Y^{2\alpha}\asymp H^2\)，第二项用 \(Y\le H^6\)。特别地，整个频带区间的统一阈值是 \(\beta\le7/10\)。

反向地，对每个固定 \(\beta>1/2+\alpha\)，在 (3) 的构造中只把余弦频率改为
\[
v_n=A_j\cos\!\left(\frac{2\pi H_j n}{X_j}\right)
\quad(X_j\le n<2X_j),
\qquad H_j=\lceil (X_j/2)^\alpha\rceil,
\tag{8}
\]
仍取 \(A_j=X_j^{\min(\beta,1-\alpha)-(1-\alpha)}\)，并在块外置零。因为 \(H_j\) 是整数，每个完整块的余弦和恰好为零；几何级数界把块内任意前缀控制在 \(O(A_jX_j/H_j)=O(X_j^{\min(\beta,1-\alpha)})\)。所以 \(|v_n|\le1\) 且全局 \(S_v(X)\ll_\beta X^\beta\)。在 \(Y_j=X_j/2\)、\(M_j=X_j\)、\(h=H_j\) 时，\(\cos\) 的一个 Fourier 分支恰抵消观察相位。置 \(f(t)=\psi(t)/t\)，Poisson 求和或光滑函数的逐次分部积分给
\[
\begin{aligned}
\mathcal A_{H_j}^v(Y_j)
&=\frac{A_j}{2M_j}\sum_{M_j<m<2M_j}f(m/M_j)
  \{1+e(-2H_jm/M_j)\}\\
&=\frac{A_j}{2}\int_1^2\frac{\psi(t)}t\,dt
  +O_{\psi,B}(A_jH_j^{-B})
\qquad(\forall B>0).
\end{aligned}
\tag{9}
\]
积分严格为正。因此 note 849 实际目标频带中的单个频率已满足
\[
|\mathcal A_{H_j}^v(Y_j)|^2\gg_\psi A_j^2
\asymp Y_j^{2\min(\beta,1-\alpha)-2(1-\alpha)}.
\tag{10}
\]
而 \(H_j^4/Y_j\asymp Y_j^{4\alpha-1}\)。因 \(\alpha<1/4\)，\(1/2+\alpha<1-\alpha\)；对 \(\beta>1/2+\alpha\)，(10) 与此目标之比按固定正幂增长。取充分小的固定 \(\varepsilon>0\)，甚至 \(|\mathcal A_{H_j}^v|^2\not\ll H_j^4Y_j^{-1+\varepsilon}\)。只用全局部分和界、\(|v_n|\le1\) 和平方质量界，无法支付 note 849 的**原始观察频带**。式 (8) 是反模型，不是实际算术序列 \(c(n)\)。在端点 \(\alpha=1/4\) 时，目标为常数量级，\(|v_n|\le1\) 与 Parseval 已给目标上界；故尖锐反模型的断言严格限于 \(\alpha<1/4\)。

同一构造还严格排除仅由 note 851 型**逐区间次指数短和**推得固定幂频带门的推法。固定 \(c_0>0\)，在各块上改取 \(A_j=\exp\{-2c_0(\log Y_j/\log\log Y_j)^{1/3}\}\)。对该块内每个普通整数区间 \(J\)，甚至有 \(|\sum_{m\in J}v_m|\le A_j|J|\)，强于 note 851 式 (8) 中对应尺度的 \(L e^{-c_0V_{Y_j}}+Q\log Y_j\)；同时 \(\sum v_m^2\le M_j\)。但 (9) 给 \(|\mathcal A_{H_j}^v|^2\asymp A_j^2=Y_j^{-o(1)}\)，在每个固定 \(\alpha<1/4\) 都大于 \(H_j^4/Y_j=Y_j^{4\alpha-1}\) 一个固定幂。这个反模型只关闭“逐区间短和 + 二次质量”的抽象推法；它没有利用真实 \(c\) 的乘法结构，因而不否定真实算术门。

## 真实三通道相关的剩余位移（直接由 note 870 导出）

对 note 870 的实际 \(b_x=c(M+x)\)，取
\[
K=\left\lfloor\frac{H^3}{\log^2(2Y)}\right\rfloor,
\qquad Y^{1/5}\le H\le Y^{1/4}.
\]
式 (4a) 的 Haar 自相关权记作 \(r_L(k)\)。由
\(C_b(0)=\sum b_x^2\ll Y\log(2Y)\)、
\(|C_b(k)|\le C_b(0)\)、\(|r_L(k)|\le2L\) 和
\(L\asymp Y/H\)，得到
\[
\begin{aligned}
V_H(Y)
&=2\sum_{K<k<2L}r_L(k)C_b(k)
+O\!\left(\frac{Y^2H^2}{\log(2Y)}
+\frac{Y^2\log(2Y)}H\right)\\
&=2\sum_{K<k<2L}r_L(k)C_b(k)+o(H^2Y^2).
\end{aligned}
\]
因此在 \(H=Y^{1/5}\) 的目标端点，只剩
\(Y^{3/5}/\log^2Y\lesssim k<Y^{4/5}\) 的实际不同指标相关。
这是未估计的 signed 和，不是其上界；它比 note 849 的光滑核门具有严格有限的位移支撑。

### 在 Haar 能量中加性支付背景与高次素数幂

令 \(c_{\rm tri}\) 为 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (29) 的两条真素数臂与 Möbius 臂，\(\delta=c-c_{\rm tri}\)；本节写 \(V_H(v)=\sum_{x\bmod M}|\mathsf H_L(v(M+\cdot))(x)|^2\)。note 849 式 (31) 给 \(\delta=B+P\)，其中 \(B(m)=4-2\mathbf1_{2\mid m}\) 是二周期背景。高次素数幂的绝对质量还可比其式 (33) 稍强地估计为
\[
\sum_{n\le4Y}P_2(n)
=\vartheta(2\sqrt Y)
+O(Y^{1/3}\log(2Y))
\ll\sqrt Y.
\]
这里平方项的总权恰为 \(\vartheta(2\sqrt Y)\)；对每个 \(p\le(4Y)^{1/3}\)，更高幂的总权至多 \(\log(4Y)\)。因此 \(\sum_{M\le m<2M}|P(m)|\ll\sqrt Y\)。常数背景被 Haar 核精确消去，交替背景每个窗口差至多为二，故 \(V_H(B)\ll Y\)。另一方面，Haar 核在周期群上的 \(\ell^2\) 范数为 \(\sqrt{2L}\)；Young 的 \(\ell^1*\ell^2\) 不等式给
\[
V_H(P)\le2L\left(\sum_{M\le m<2M}|P(m)|\right)^2
\ll LY.
\]
所以
\[
V_H(\delta)\ll Y+LY
\ll Y^2H^{-1}.
\tag{10a}
\]
由 \(\sum_{M\le m<2M}|c_{\rm tri}(m)|^2\ll Y\log(2Y)\) 及长度 \(2L\) 的 Young 不等式，\(V_H(c_{\rm tri})\ll Y^3H^{-2}\log(2Y)\)。故平方范数的极化和 Cauchy--Schwarz 给出**加性误差**
\[
\begin{aligned}
|V_H(c)-V_H(c_{\rm tri})|
&\le2\sqrt{V_H(c_{\rm tri})V_H(\delta)}+V_H(\delta)\\
&\ll Y^{5/2}H^{-3/2}\sqrt{\log(2Y)}+Y^2H^{-1}
=o(H^2Y^2)
\end{aligned}
\tag{10b}
\]
一致于 \(Y^{1/5}\le H\le Y^{1/4}\)；首项除以目标量级至多为 \(Y^{-1/5}\sqrt{\log(2Y)}\)。因此真实 Haar 门在**目标量级上的数值**只由这三类系数决定；不需要假定其中任何一个通道的目标均方。式 (10b) 没有估计三通道之间的剩余交叉。

对 \(c_{\rm tri}\) 再用 note 870 式 (4a) 和上节同样的对角、短位移支付，便得到一个只含真素数与 Möbius 系数的紧支撑 signed 接口：
\[
V_H(c)=2\sum_{K<k<2L}r_L(k)
\sum_{x\bmod M}c_{\rm tri}(M+x)c_{\rm tri}(M+(x+k\bmod M))
+o(H^2Y^2).
\tag{10c}
\]
这里 \(r_L(k)=2L-3k\) 于 \(1\le k<L\)，\(r_L(k)=k-2L\) 于 \(L\le k<2L\)，并约定 \(r_L(2L)=0\)。式 (10c) 未给 signed 和的上界；它仅严格移除了对角、短位移、确定性背景与高次素数幂。

### 奇偶符号不能替代跨位移相消

把真素数部分写作 \(P=A+B\)，其中
\[
A(m)=2\mathbf1_{m=2p}\log p\ge0,
\qquad B(m)=-4\mathbf1_{m=p}\log p\le0.
\]
在当前物理块上 \(A\) 只支撑偶数，\(B\) 只支撑奇数；\(M=2Y\) 为偶数，周期折返也保持奇偶。因此对周期自相关 \(C_P(k)=\sum_{x\bmod M}P(M+x)P(M+(x+k\bmod M))\) 有精确符号
\[
C_P(k)=C_A(k)+C_B(k)\ge0\quad(k\text{ 偶}),
\qquad
C_P(k)=C_{A,B}(k)+C_{B,A}(k)\le0\quad(k\text{ 奇}).
\tag{10d}
\]
但这不足以对 (10c) 的真素数部分作单侧上界。取同奇偶符号的周期模型 \(b_x=(-1)^x\)，则 \(C_b(k)=M(-1)^k\)。若 \(L\) 偶，\(\mathsf H_Lb\equiv0\)；若 \(L\) 奇，\(|\mathsf H_Lb|\equiv2\)。所以总 Haar 能量至多 \(4M\)。另一方面，在偶位移 \(2\le k\le L/3\) 上 \(r_L(k)=2L-3k\ge L\) 且 \(C_b(k)=M\)，于是单是相关式中的这些**正项**就有
\[
2\sum_{\substack{2\le k\le L/3\\2\mid k}}r_L(k)C_b(k)
\gg ML^2\asymp Y^3H^{-2}.
\tag{10e}
\]
在 \(H=Y^{1/5}\) 时，(10e) 比目标 \(H^2Y^2\) 大 \(Y^{1/5}\)。所以 (10d) 只能定位奇偶交叉的符号；若用其删去负相关，甚至对能量为零的模型也会丢失固定幂。实际真素数臂与 Möbius 臂仍须在全部相关位移上保留联合相消。

### 同一真实素数臂在两个位移段各有相反的三次阶质量

上述损失并非只存在于交替模型。令 \(B(m)=-4\mathbf1_{m=p}\log p\) 为实际奇素数臂，固定常数 \(5/4<a<b<3/2\) 并置 \(I=[aM,bM]\)。素数定理给 \(\sum_{p\in I}\log p\asymp Y\)。把 \(I\) 分成 \(J=O(M/L)=O(H)\) 个长度至多 \(L/3\) 的相邻格，记 \(W_j=\sum_{p\in I_j}\log p\)。Cauchy--Schwarz 给
\[
\sum_jW_j^2\ge\frac{(\sum_jW_j)^2}{J}\gg\frac{Y^2}{H}.
\]
对角权只有 \(\sum_{p\in I}\log^2p\ll Y\log Y\)。差值不超过 \(K=\lfloor H^3/\log^2(2Y)\rfloor\) 的有序异素数对权至多 \(O(YK\log Y)=o(Y^2/H)\)，因为 \(H^4\le Y\)。故同格、\(K<q-p\le L/3\) 的加权素数对总量 \(\gg Y^2/H\)。这些差值都是偶数，且 \(r_L(q-p)\ge L\)，所以
\[
\sum_{K<k\le L/3}r_L(k)C_B(k)
\gg L\frac{Y^2}{H}
\asymp\frac{Y^3}{H^2}.
\tag{10f}
\]
这里 \(C_B(k)=\sum_{x\bmod M}B(M+x)B(M+(x+k\bmod M))\ge0\) 于偶 \(k\)，且所保留的素数对都不折返。

反向位移段也有真实三次阶贡献。对每个 \(p\in I\)，区间 \((p+L,p+3L/2]\) 仍在 \((M,2M)\)。由于 \(L\asymp Y/H\ge cY^{3/4}\)，[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4)（或其已核验的 Heath-Brown 短区间素数输入）一致给
\[
\sum_{p+L<q\le p+3L/2\atop q\ {m prime}}\log q
=\frac L2+o(L).
\]
在 \(L<k\le3L/2\) 有 \(r_L(k)=k-2L\le-L/2\)。以 \(\sum_{p\in I}\log p\asymp Y\) 求和便得
\[
\sum_{L<k\le3L/2}r_L(k)C_B(k)
\ll- YL^2
\asymp-\frac{Y^3}{H^2}.
\tag{10g}
\]
式 (10f)–(10g) 都发生在 (10c) 的未付位移带内，且只用真实素数；它们没有证明两段主量精确相消。单段估计必然停在 \(Y^3/H^2\)，在 \(H=Y^{1/5}\) 比目标大固定幂。剩余决策性输入是跨位移的**带权素数对误差**以及它与 Möbius 臂的联合相关，而非某一位移段的计数或符号。

实际上，已核验的短区间输入还给同一固定内区源 \(I\) 的**首阶常数**。置
\(\rho(s)=2-3s\) 于 \(0\le s\le1\)，\(\rho(s)=s-2\) 于 \(1\le s\le2\)。由 note 851 式 (4)、高次素数幂总质量 \(O(\sqrt Y)\) 和 \(L\gg Y^{3/4}\)，对 \(p\in I\) 一致有
\[
\sup_{0\le t\le2}
\left|\vartheta(p+tL)-\vartheta(p)-tL\right|=o(L).
\]
因为 \(r_L(k)=L\rho(k/L)\)，一次 Stieltjes 分部求和对任意固定 \(0\le u<v\le2\) 给
\[
\sum_{uL<q-p\le vL\atop q\ {m prime}}
\log q\,r_L(q-p)
=L^2\int_u^v\rho(s)ds+o(L^2)
\quad\text{一致于 }p\in I.
\]
再用 \(\vartheta(I)=|I|+o(Y)\)，得到真实带权素数对渐近式
\[
\boxed{\quad
16\sum_{p\in I\atop p\ {m prime}}\log p
\sum_{uL<q-p\le vL\atop q\ {m prime}}
\log q\,r_L(q-p)
=16|I|L^2\int_u^v\rho(s)ds+o(YL^2).
\quad}
\tag{10h}
\]
这里 \(|I|\) 是实区间长度。积分在 \([0,1/3]\) 等于 \(1/2\)，在 \([1,3/2]\) 等于 \(-3/8\)，而在整个 \([0,2]\) **恰好为零**。因此同一真素数臂的两种三次阶贡献在首阶常数上确实相消；现有输入留下的 \(o(YL^2)\) 误差仍远大于所需 \(O(H^2Y^2)\)。

这个误差还能精确分账。Ramachandra 式 (4) 对任意固定 \(\varepsilon_0>0\) 给 \(\Lambda\) 短和的误差 \(O(u e^{-gV_Y}+Y^{7/12+\varepsilon_0})\)；高次素数幂的 \(O(\sqrt Y)\) 质量已被后一项吸收。于是上述 Stieltjes 分部求和与对源素数的同一定理给 (10h) 一个可核对的余项
\[
O_{I,u,v,\varepsilon_0}\!\left(
YL^2e^{-gV_Y}+Y^{19/12+\varepsilon_0}L
\right).
\tag{10i}
\]
第二项除以目标 \(H^2Y^2\) 至多为
\(O(Y^{7/12+\varepsilon_0}/H^3)\)。取 \(\varepsilon_0<1/60\) 后，因 \(H\ge Y^{1/5}\)，它一致趋零。第一项的比值为 \(\asymp(Y/H^4)e^{-gV_Y}\)，在 \(H=Y^{1/5}\) 时仍是 \(Y^{1/5}e^{-gV_Y}\)，不能由任何固定 \(g>0\) 支付。故对这条真实素数对路线，当前短和定理的**零密度幂次余项已经足够**；欠缺的是跨源素数或跨位移的固定幂 signed cancellation，不能从逐区间的次指数上界推出。

### 在目标量级内付清同一素数臂的一点项

上段的 \(YL^2e^{-gV_Y}\) 是逐源素数取绝对值产生的预算。对完整位移 \(1\le k<2L\) 可先做精确代数消去。令 \(I_{\mathbb Z}=I\cap\mathbb Z=[A,B]\cap\mathbb Z\)、\(\lambda(n)=\Lambda(n)-1\)，并定义真正的中心化二点项
\[
\mathcal Q_I(Y,H)=
\sum_{n\in I_{\mathbb Z}}\sum_{1\le k<2L}
r_L(k)\lambda(n)\lambda(n+k).
\]
则在整个 \(Y^{1/5}\le H\le Y^{1/4}\) 一致有
\[
\boxed{\quad
16\sum_{p\in I\atop p\ {m prime}}\log p
\sum_{p<q<p+2L\atop q\ {m prime}}
\log q\,r_L(q-p)
=16\mathcal Q_I(Y,H)+o(H^2Y^2).
\quad}
\tag{10j}
\]
证明如下。首先把两处真素数权换成 \(\Lambda\)。源或目标高次素数幂的总权为 \(O(\sqrt Y)\)，而对任意固定源，\(\sum_{1\le k<2L}|r_L(k)|\Lambda(n+k)\ll L^2\log Y\)；交换源、目标亦然。因此替换误差为 \(O(\sqrt YL^2\log Y)=o(H^2Y^2)\)。

再把 \(\Lambda=1+\lambda\) 展开。Haar 自相关满足 \(\sum_{1\le k<2L}r_L(k)=-L\)，故纯常数项为 \(-L|I_{\mathbb Z}|=O(YL)\)，源端线性项为 \(-L\sum_{n\in I_{\mathbb Z}}\lambda(n)\)。记 \(S(k)=\sum_{n=A}^{B}\lambda(n+k)\)。目标端线性项按
\[
\sum_{1\le k<2L}r_L(k)S(k)
=-LS(0)
+\sum_{1\le k<2L}r_L(k)
\left\{\sum_{B<m\le B+k}\lambda(m)
-\sum_{A-1<m\le A-1+k}\lambda(m)\right\}
\]
重写。note 851 式 (4) 取其已用的 \(\varepsilon=1/24\)，对全部 \(k\le2L\) 给两个短增量各为 \(O(k e^{-gV_Y}+Y^{5/8})\)，且 \(S(0)=O(Y e^{-gV_Y}+Y^{5/8})\)。由 \(\sum|r_L(k)|\ll L^2\)，所有常数与线性项连同高次素数幂替换误差至多
\[
O\!\left(YL+L^3e^{-gV_Y}+L^2Y^{5/8}
+\sqrt YL^2\log Y\right).
\tag{10k}
\]
四项除以 \(H^2Y^2\) 分别为 \(O(H^{-3})\)、\(O((Y/H^5)e^{-gV_Y})\)、\(O(Y^{5/8}/H^4)\) 与 \(O(Y^{1/2}\log Y/H^4)\)，在给定频带内全部趋零，证明 (10j)。这支付了该真实素数对块的全部一点项；\(\mathcal Q_I\) 是尚未估计的二点 signed covariance，(10j) 不给其目标上界。

## 周期拼接边界可在目标量级内支付

令 \(C(t)=\sum_{n\le t}c(n)\)。对 \(2L\le x<M\)，没有模 \(M\) 的折返，故
\[
\mathsf H_Lb(x)
=C(M+x)-2C(M+x-L)+C(M+x-2L).
\]
其余至多 \(2L\) 个位置各有
\(|\mathsf H_Lb(x)|\le2L\max_{M<m<2M}|c(m)|
\ll L\log(2Y)\)，因此边界能量至多
\[
O(L^3\log^2(2Y))
=O(Y^3H^{-3}\log^2(2Y))
\ll_\varepsilon H^2Y^{2+\varepsilon},
\]
最后一步在整个 \(Y^{1/5}\le H\le Y^{1/4}\) 成立，因为 \(H^5\ge Y\)。
所以 note 870 的周期 Haar 门等价于上述**实际物理区间**上的 \(C\) 二阶差分均方门，误差已无条件支付。将 note 870 式 (4b) 代入，可把未付项逐点写成 \(2E(t/2)-4E(t)-4(\log2)M_\mu(t)\) 的联合二阶差分；这仍无固定幂均方上界。

### 真实 \(c\) 的边界误差实际上为 \(o(H^2Y^2)\)

上面的 \(O_\varepsilon\) 不需要损失固定正幂。令
\(V_Y=(\log Y/\log\log Y)^{1/3}\)、\(Q=\lfloor Y^{2/3}\rfloor\)。
已独立核验的 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (8) 对真实 \(c\) 给出某个固定 \(c_0>0\)：在物理段内任意长度不超过 \(L\) 的普通整数区间 \(J\) 上，
\[
\left|\sum_{m\in J}c(m)\right|
\ll L e^{-c_0V_Y}+Q\log Y.
\tag{11}
\]
若 \(J\) 包含周期块的唯一左端整数 \(m=M\)，额外的 \(O(\log Y)\) 已被 \(Q\log Y\) 吸收。触及周期拼接的每个 Haar 值由至多四个这种普通区间和构成，因而边界能量至多
\[
O\!\left(L^3e^{-2c_0V_Y}+LQ^2\log^2Y\right).
\tag{12}
\]
由于 \(L\asymp Y/H\)、\(H^5\ge Y\)，第一项除以 \(H^2Y^2\) 至多为 \(O(e^{-2c_0V_Y})=o(1)\)；第二项的比值为
\(O(Y^{1/3}H^{-3}\log^2Y)=o(1)\)，在整个 \(Y^{1/5}\le H\le Y^{1/4}\) 一致。因此对真实三通道有精确目标量级上的分解
\[
V_H(Y)=\sum_{2L\le x<M}
\left|C(M+x)-2C(M+x-L)+C(M+x-2L)\right|^2
+o(H^2Y^2).
\tag{13}
\]
式 (13) 支付的只有周期拼接；物理区间内的真实 signed 均方仍未得到 \(O(H^2Y^2)\) 或 \(O_\varepsilon(H^2Y^{2+\varepsilon})\) 上界。

合并 (10b)、(13)，还可把未付的物理表达直接写成三个真算术通道。令 \(\vartheta(t)=\sum_{p\le t}\log p\) 并置
\[
C_{\rm tri}(t)=2\vartheta(t/2)-4\vartheta(t)-4(\log2)M_\mu(t).
\]
物理区间上的差向量 \(\Delta_L^2(C-C_{\rm tri})\) 是周期 \(\mathsf H_L\delta\) 向量的子向量，平方范数至多 \(V_H(\delta)\ll Y^2H^{-1}\)。再以 \(V_H(c_{\rm tri})\ll Y^3H^{-2}\log Y\) 作 Cauchy--Schwarz，得到
\[
\boxed{\quad
V_H(c)=\sum_{2L\le x<M}
\left|\Delta_L^2C_{\rm tri}(M+x)\right|^2
+o(H^2Y^2),\qquad
\Delta_L^2F(t)=F(t)-2F(t-L)+F(t-2L).
\quad}
\tag{15}
\]
式 (15) 是真实素数两臂与 Möbius 臂的精确目标量级接口；它不声称该平方和满足目标上界。

## 三通道的逐项中心化与一点数据的精确边界

下面把 (10j) 的中心化扩展到全部三通道，但不将所得二点相关误认作上界。写
\[
P_1(m)=2\mathbf1_{m=2p}\log p,\quad
P_2(m)=-4\mathbf1_{m=p}\log p,\quad
U(m)=-4(\log2)\mu(m),
\]
其中前两个式子按素数 \(p\) 求值。令 \(\lambda=\Lambda-1\)，并定义
\[
F_1(m)=2\mathbf1_{2\mid m}\lambda(m/2),\qquad
F_2(m)=-4\lambda(m),\qquad F_3(m)=U(m).
\tag{16}
\]
所有序列只在 \(M\le m<2M\) 取值并作模 \(M\) 周期延拓。记
\(\mathcal E_L(f,g)=\sum_{x\bmod M}\mathsf H_Lf(x)\mathsf H_Lg(x)\)。真实系数恰满足
\(c=F_1+F_2+F_3\)。因此
\[
V_H(c)=\sum_{i=1}^3\mathcal E_L(F_i,F_i)
       +2\sum_{1\le i<j\le3}\mathcal E_L(F_i,F_j).
\tag{17}
\]
这是三个自相关和三个交叉相关的**联合**恒等式，不给任一项单独的目标上界。

中心化还可逐个配对地用于真正的素数臂。置 \(P_3=F_3\)，令
\(D_i=F_i-P_i\)。由 note 849 式 (31)，\(D_1\) 是高次素数幂项减去
\(2\mathbf1_{2\mid m}\)，\(D_2\) 是高次素数幂项加上常数 \(4\)。
两种周期背景的 Haar 能量均为 \(O(Y)\)，高次素数幂的总质量为
\(O(\sqrt Y)\)；Young 不等式遂给
\[
\mathcal E_L(D_i,D_i)\ll Y+LY\quad(i=1,2),\qquad D_3=0.
\]
又因 \(\sum_{M\le m<2M}|F_i(m)|^2+|P_i(m)|^2\ll Y\log(2Y)\)，有
\(\mathcal E_L(F_i,F_i)+\mathcal E_L(P_i,P_i)\ll YL^2\log(2Y)\)。
逐项 Cauchy--Schwarz 因而给出，对全部 \(1\le i,j\le3\)，
\[
\mathcal E_L(P_i,P_j)=\mathcal E_L(F_i,F_j)
+O\!\left(YL^{3/2}\sqrt{\log(2Y)}+YL+Y\right)
=\mathcal E_L(F_i,F_j)+o(H^2Y^2).
\tag{18}
\]
最后一步用 \(L\asymp Y/H\) 与 \(H\ge Y^{1/5}\)。因此在**完整周期 Haar 二次型内**，两条素数臂的自配对、互配对、各自与 Möbius 的配对，以及 Möbius 自配对，都能在目标量级内写成 (17) 的中心化二点项；这不把 (10j) 的固定内区、单侧位移公式逐项推广到交叉配对。这里支付的只有背景与高次幂的替换误差；六项的真实 signed 总上界仍未得到。

更强的一点数据反模型说明，连保留真实素数支撑与真实 Möbius 也不能使这个剩余上界从 note 851 的短和定理形式推出。固定
\(H=\lceil Y^{1/5}\rceil\)、\(L=\lfloor M/(32H)\rfloor\)、\(h_0=H\)，记
\(P(n)=\mathbf1_{n\text{ 为素数}}\log n\)。取足够小的固定 \(g>0\)，令
\(a_Y=e^{-gV_Y}\)，并对 \(0\le\theta<2\pi\) 设
\[
\Lambda_\theta(n)=\Lambda(n)+a_Y P(n)
 \cos(2\pi h_0n/M+\theta),
\quad
c_\theta(m)=2\mathbf1_{2\mid m}(\Lambda_\theta(m/2)-1)
-4(\Lambda_\theta(m)-1+(\log2)\mu(m)).
\tag{19}
\]
\(\Lambda_\theta\) 在素数外与真实 \(\Lambda\) 完全相同；在素数上仍非负，且高次素数幂与整个真实 \(\mu\) 完全不变。对 \(x\asymp Y\)、\(1\le u\le x\)，只要区间处于当前物理范围，note 851 式 (4) 和 \(P_2\) 的 \(O(\sqrt Y)\) 总质量给
\[
\left|\sum_{x<n\le x+u}(\Lambda_\theta(n)-1)\right|
\ll u e^{-gV_Y}+Y^{5/8}
\quad\text{一致于 }\theta.
\tag{20}
\]
确实，新增项的绝对值至多
\(a_Y\sum_{x<n\le x+u}P(n)
\ll a_Y(u+u e^{-g_0V_Y}+Y^{5/8})\)，其中 \(g_0>0\) 来自 note 851，取 \(g\le g_0\) 即可。\(\mu\) 的全部一点短和保持原样，且 \(|c_\theta(m)|\ll\log(2Y)\)、\(\sum|c_\theta(m)|^2\ll Y\log(2Y)\)。

令 \(\widehat b_\theta(h_0)=\sum_{M\le m<2M}c_\theta(m)e(-h_0m/M)\)。把余弦拆成两个指数，得到精确式
\[
\widehat b_\theta(h_0)=\widehat b_0(h_0)
+\frac{a_Y}{2}\{e^{i\theta}T_++e^{-i\theta}T_-\},
\]
\[
\begin{aligned}
T_+&=2\sum_{M/2\le n<M}P(n)e(-h_0n/M)
      -4\sum_{M\le m<2M}P(m),\\
T_-&=2\sum_{M/2\le n<M}P(n)e(-3h_0n/M)
      -4\sum_{M\le m<2M}P(m)e(-2h_0m/M).
\end{aligned}
\tag{21}
\]
这里 \(\widehat b_0\) 是真实 \(c\) 的 Fourier 系数。由 note 851 在长度 \(Q=\lfloor Y^{2/3}\rfloor\) 的所有块上的一致短和，将两个区间分块并对相位作 Abel 求和可得，对固定 \(j=1,2,3\)，
\[
\sum_{n\in[M/2,M)\,\text{或}\,[M,2M)}P(n)e(-jh_0n/M)
=O\!\left(M/h_0+Me^{-g_0V_Y}+Q\log Y+\sqrt Y\right)=o(M).
\]
这里 \(h_0Q/M=o(1)\)；常数项由几何和支付，高次素数幂由总质量支付。同一定理在上半区给
\(\sum_{M\le m<2M}P(m)=M+o(M)\)。故
\(T_+=-4M+o(M)\)，\(T_-=o(M)\)。对相位 \(\theta\) 平均消去一次项，得到
\[
\frac1{2\pi}\int_0^{2\pi}|\widehat b_\theta(h_0)|^2d\theta
=|\widehat b_0(h_0)|^2
+\frac{a_Y^2}{4}(|T_+|^2+|T_-|^2)
\ge(4+o(1))a_Y^2M^2.
\tag{22}
\]
因此至少一个 \(\theta\) 满足此 Fourier 下界。Haar 乘子在
\(h_0L/M=1/32+o(1)\) 处大小 \(\asymp L\)，周期 Parseval 给
\[
V_H(c_\theta)\gg\frac{L^2}{M}a_Y^2M^2
\asymp a_Y^2\frac{Y^3}{H^2},\qquad
\frac{V_H(c_\theta)}{H^2Y^2}
\gg Y^{1/5}e^{-2gV_Y}\longrightarrow\infty.
\tag{23}
\]
同一反模型也直接触及 note 849 的**原始观察频带**。取其中任意固定非负、非零的
\(\psi\in C_c^3((1,2))\)，置
\(I_\psi=\int_1^2\psi(t)t^{-1}dt>0\)。把 (21) 的各项乘上
\(\psi(m/M)/m\) 后，上半区的零频素数主项为 \(-4I_\psi+o(1)\)，其余三个非零相位和都为 \(o(1)\)；上述分块估计加光滑分部求和逐项适用。因此相位平均给
\[
\frac1{2\pi}\int_0^{2\pi}
 |\mathcal A_{h_0}^{\theta}(Y)|^2d\theta
\ge(4I_\psi^2+o(1))a_Y^2.
\]
至少一个 \(\theta\) 满足该下界；因 \(\eta(1)\ge1\)，它还使
\(\sum_h\eta(h/H)|\mathcal A_h^{\theta}(Y)|^2\gg_\psi a_Y^2\)，
比 note 849 式 (15) 的 \(H^4/Y\asymp Y^{-1/5}\) 大固定幂。
这是一个随尺度变化的正素数权模型，**不是**真实 \(\Lambda\)，也没有声称真实 Haar 门失败。它严格排除只使用素数支撑、非负性、真实 Möbius、两尺度系数结构、平方质量和 note 851 型全部一点短和的统一证明。要支付 (17) 的真实总和，必须使用固定的素数权 \(\log p\) 与真实 Möbius 之间更精确的二点算术关系，或找到另一种直接频带估计。

## 真实奇素数–Möbius 交叉的素数与合数目标精确补偿

这里得到一项涉及**真实** \(\Lambda,\mu\) 的带符号结论，但仍只是一段位移的子块。沿用 (10f) 的固定内区 \(I=[aM,bM]\)，记 \(\ell=\log2\)、\(J=\lfloor L/3\rfloor\)。把奇素数臂 \(P_2(p)=-4\log p\) 与目标 Möbius 臂 \(U(p+k)=-4\ell\mu(p+k)\) 在 \(1\le k\le J\) 的正 Haar 权上配对：
\[
\mathcal X_I^{\rm all}=16\ell
\sum_{p\in I\atop p\text{ prime}}\log p
\sum_{1\le k\le J}r_L(k)\mu(p+k).
\tag{24}
\]
令 \(\mathcal X_I^{\rm prime}\) 仅保留 \(p+k=q\) 为素数的目标，\(\mathcal X_I^{\rm comp}=\mathcal X_I^{\rm all}-\mathcal X_I^{\rm prime}\) 仅保留 \(p+k\) 为合数且 \(\mu(p+k)\ne0\) 的目标。则一致于 \(Y^{1/5}\le H\le Y^{1/4}\)，
\[
\boxed{\quad
\mathcal X_I^{\rm prime}
=-\frac{8\ell\,|I|L^2}{\log Y}(1+o(1)),\qquad
\mathcal X_I^{\rm comp}
=+\frac{8\ell\,|I|L^2}{\log Y}(1+o(1)),
\quad}
\tag{25}
\]
且对任意固定 \(0<\varepsilon_0<1/60\)，此位移段的完整带符号交叉满足
\[
|\mathcal X_I^{\rm all}|
\ll_{\varepsilon_0} YL^2e^{-gV_Y}+YL Y^{7/12+\varepsilon_0}
=o(YL^2/\log Y).
\tag{26}
\]

证明只用 note 851 已核验的短和式 (4)，其中零密度幂次取上述 \(\varepsilon_0\)。对每个源素数 \(p\in I\)，在 \(k\le J\) 的每个前缀上有
\(\sum_{1\le k\le t}\mu(p+k)
=O(t e^{-gV_Y}+Y^{7/12+\varepsilon_0})\)。由于 \(r_L(k)=2L-3k\) 于本段、\(\|r_L\|_\infty\ll L\)、\(\operatorname{Var}_{[1,J]}r_L\ll L\)，离散 Abel 给内和
\(O(L^2e^{-gV_Y}+LY^{7/12+\varepsilon_0})\)。再用 \(\sum_{p\in I}\log p\ll Y\) 即得 (26)；\(e^{-gV_Y}\log Y\to0\) 且 \(Y^{7/12+\varepsilon_0}\log Y/L\to0\)。

另一方面，note 851 对 \(\Lambda\) 的同一移动区间短和，经 Stieltjes 分部求和并扣除总质量 \(O(\sqrt Y)\) 的高次素数幂，对每个 \(p\in I\) 一致给
\[
\sum_{p<q\le p+J\atop q\text{ prime}}
 (\log q)r_L(q-p)
=L^2\int_0^{1/3}(2-3s)ds+o(L^2)
=\frac{L^2}{2}+o(L^2).
\]
在当前固定比例区间 \(\log q=\log Y+O(1)\)，所以目标素数的无 \(\log q\) 权内和为 \(L^2/(2\log Y)(1+o(1))\)。结合
\(\sum_{p\in I}\log p=|I|+o(Y)\) 和 \(\mu(q)=-1\)，得到 (25) 第一式；第二式由 (26) 相减。
事实上内层结论对**每个** \(p\in I\) 一致：素数目标的 \(\sum_{k\le J}r_L(k)\mu(p+k)\) 为 \(-L^2/(2\log Y)(1+o(1))\)，平方自由合数目标为 \(+L^2/(2\log Y)(1+o(1))\)。因此相同补偿也适用于任何绝对质量受控的源素数权，而不依赖本节特选的 \(\log p\) 权。
一个不经两项相减的核对是逐整数恒等式
\(\mu(n)\mathbf1_{n\text{ composite}}=\mu(n)+\mathbf1_{n\text{ prime}}\)（此处 \(n>1\)）；其短区间主项由素数计数给出，Möbius 余项正是 (26)。
相同论证对任意固定 \(0\le u<v\le2\) 的位移段成立：素数目标主项为
\(-16\ell|I|L^2(\log Y)^{-1}\int_u^v\rho(s)ds\)，合数目标主项为其相反数，两者余项均为 \(o(YL^2/\log Y)\)。整个 \([0,2]\) 上该积分为零，所以这条首阶公式本身不给完整 Haar 交叉的目标上界。

因此在 \(r_L(k)>0\) 的同一真实加性位移段，Möbius 的素数目标给出严格负的 \(Y L^2/\log Y\) 级交叉，而平方自由合数目标给出同阶正补偿。此结论没有估计完整 \(1\le k<2L\) 的混合交叉；(26) 的零密度幂次余项已低于 \(H^2Y^2\)，但次指数项在 \(H=Y^{1/5}\) 仍超出目标 \(Y^{1/5}e^{-gV_Y}\) 倍。

## 两素数臂固定内区交叉的一点项也可支付

上面的 (18) 只处理**完整周期 Haar 二次型**。下面对最容易遗漏奇偶偏置的 \(A\!\)-\(B\) 交叉，证明与 (10j) 同型的**固定内区、单侧位移**公式。令 \(P(n)=\mathbf1_{n\text{ prime}}\log n\)、\(\lambda(n)=\Lambda(n)-1\)，取固定 \(5/4<a<b<3/2\)，并置
\[
I_-=[aM/2,bM/2]\cap\mathbb Z=[A,B]\cap\mathbb Z,
\qquad \mathcal O_L=\{1\le k<2L:k\text{ odd}\}.
\]
则一致于 \(Y^{1/5}\le H\le Y^{1/4}\)，
\[
\boxed{\quad
\sum_{p\in I_-\atop p\text{ prime}}\log p
\sum_{k\in\mathcal O_L}r_L(k)P(2p+k)
=\sum_{n\in I_-}\lambda(n)
\sum_{k\in\mathcal O_L}r_L(k)\lambda(2n+k)
+o(H^2Y^2).
\quad}
\tag{27}
\]
两边乘以 \(-8\) 就是物理序列的 \(A(2p)=2\log p\) 与 \(B(2p+k)=-4P(2p+k)\) 的有序交叉。负位移有同样的结论，反向使用下述端点论证。

先把两处 \(P\) 换成 \(\Lambda\)。源或目标的高次素数幂总权为 \(O(\sqrt Y)\)，对固定源或目标最多有 \(O(L)\) 个另一端指标，每项 \(|r_L|\Lambda\ll L\log Y\)；故替换误差为
\(O(\sqrt YL^2\log Y)=o(H^2Y^2)\)。展开 \(\Lambda=1+\lambda\) 后，关键奇位移权和是
\[
R_o:=\sum_{k\in\mathcal O_L}r_L(k)
=\begin{cases}0,&L\text{ even},\\-1,&L\text{ odd}.
\end{cases}
\tag{28}
\]
这可直接代入 \(r_L\) 的两段公式求和，也可由 Haar 核总和为零及其在交替序列上的乘子平方为 \(0\) 或 \(4\) 推出。纯常数项为 \(|I_-|R_o=O(Y)\)，源线性项为 \(R_o\sum_{n\in I_-}\lambda(n)=O(Y)\)。

目标线性项需要处理 \(2n+k\) 的奇数格偏置。记
\(S(k)=\sum_{n=A}^{B}\lambda(2n+k)\)，只对奇数 \(k=2j+1\) 定义。
对奇数 \(m\)，\(\lambda(m)=1+\lambda_o(m)\)，其中
\(\lambda_o(m)=\Lambda(m)-2\)。因为 \(m\asymp Y\) 的偶数位 \(\Lambda(m)\) 只可能来自 \(2\) 的幂，note 851 式 (4) 蕴含任意奇数格短段上的
\[
\sum_{\substack{x<m\le x+u\\m\text{ odd}}}\lambda_o(m)
\ll u e^{-gV_Y}+Y^{5/8}+\log(2Y).
\tag{29}
\]
特别 \(S(1)=|I_-|+O(Y e^{-gV_Y}+Y^{5/8}+\log Y)=O(Y)\)。当 \(j\ge1\) 时，两个长度为 \(j\) 的奇数格端段一增一减；它们的常数 \(+1\) 恰好相消，所以
\[
S(2j+1)-S(1)
=\sum_{n=B+1}^{B+j}\lambda_o(2n+1)
-\sum_{n=A}^{A+j-1}\lambda_o(2n+1)
\ll j e^{-gV_Y}+Y^{5/8}+\log Y.
\]
由 \(\sum_{k\in\mathcal O_L}|r_L(k)|\ll L^2\)、
\(\sum_{k=2j+1\in\mathcal O_L}|r_L(k)|j\ll L^3\)，目标线性项至多
\[
\left|\sum_{k\in\mathcal O_L}r_L(k)S(k)\right|
\ll Y+L^3e^{-gV_Y}+L^2Y^{5/8}+L^2\log Y.
\]
这些量连同高次幂误差除以 \(H^2Y^2\) 全部趋零：尤其
\(L^3e^{-gV_Y}/(H^2Y^2)\ll(Y/H^5)e^{-gV_Y}=o(1)\)，
\(L^2Y^{5/8}/(H^2Y^2)\ll Y^{5/8}/H^4=o(1)\)。这证明 (27)。它支付的是 \(A\!\)-\(B\) 固定内区交叉的全部一点项；右侧 \(\lambda(n)\lambda(2n+k)\) 的真实二点 signed 上界依然未知。

### 其余三种带素数源的固定内区配对

同样的端点支付还能覆盖下列单侧位移式。记 \(I_+=[aM,bM]\cap\mathbb Z\)，\(I_-\) 如上；等式两侧只写去掉物理通道常数的算术核：
\[
\begin{aligned}
\sum_{p\in I_-\atop p\text{ prime}}\log p
 \sum_{1\le j<L}r_L(2j)P(p+j)
&=\sum_{n\in I_-}\lambda(n)
 \sum_{1\le j<L}r_L(2j)\lambda(n+j)+o(H^2Y^2),\\
\sum_{p\in I_+\atop p\text{ prime}}\log p
 \sum_{1\le k<2L}r_L(k)\mu(p+k)
&=\sum_{n\in I_+}\lambda(n)
 \sum_{1\le k<2L}r_L(k)\mu(n+k)+o(H^2Y^2),\\
\sum_{p\in I_-\atop p\text{ prime}}\log p
 \sum_{1\le k<2L}r_L(k)\mu(2p+k)
&=\sum_{n\in I_-}\lambda(n)
 \sum_{1\le k<2L}r_L(k)\mu(2n+k)+o(H^2Y^2).
\end{aligned}
\tag{30}
\]
第一行是偶素数臂自配对，第二、三行分别是奇、偶素数臂作为源的 Möbius 交叉；Möbius 自配对本来就没有素数一点项。结合 (10j)、(27)，固定内区以素数为源的各类正位移配对均已中心化；反向配对在完整 Haar 二次型内由 (18) 处理。这些二点 signed 和仍未估计。

前两行只需 (10j) 的端点恒等式。第一行把 \(k=2j\) 后使用
\(\sum_{1\le j<L}r_L(2j)=-L+\mathbf1_{L\text{ odd}}=O(L)\)；第二行使用 \(\sum_{1\le k<2L}r_L(k)=-L\)。源与目标素数幂替换误差第一行仍为 \(O(\sqrt YL^2\log Y)\)，第二行的源替换误差为 \(O(\sqrt YL^2)\)。纯常数、源线性和目标线性项合计至多
\[
O\!\left(YL+L^3e^{-gV_Y}+L^2Y^{5/8}
+\sqrt YL^2\log Y\right)=o(H^2Y^2).
\]

第三行需要同样的一点短和在奇、偶格上的版本。记
\(M_o(x,u)=\sum_{x<n\le x+u,\,n\text{ odd}}\mu(n)\)、
\(M(x,u)=\sum_{x<n\le x+u}\mu(n)\)。由
\(\mu(2n)=-\mu(n)\mathbf1_{n\text{ odd}}\) 有精确递推
\[
M_o(x,u)=M(x,u)+M_o(x/2,u/2).
\]
取 \(J_0=\lfloor(\log Y)^{1/2}\rfloor\) 次迭代。对 \(0\le j<J_0\)，起点 \(x/2^j=Y^{1-o(1)}\)，note 851 式 (4) 的 \(V_{x/2^j}\sim V_Y\)；若 \(u/2^j<1\)，对应整数短和以 \(O(1)\) 平凡支付，所有此类项合计 \(O(J_0)\)。其余项满足
\(\sum_j(u/2^j)e^{-g'V_Y}\ll u e^{-g'V_Y}\)、
\(\sum_j(Y/2^j)^{5/8}\ll Y^{5/8}\)。余端按项数至多
\(u/2^{J_0}+1\)；\(O(J_0)\) 也被 \(Y^{5/8}\) 吸收。因此对 \(x\asymp Y\)、\(1\le u\le x\) 的奇格和偶格，均有某个固定 \(g'>0\) 的统一界
\[
|M_o(x,u)|+|M(x,u)-M_o(x,u)|
\ll u e^{-g'V_Y}+Y^{5/8}+1.
\tag{31}
\]
第三行替换源素数幂的代价为 \(O(\sqrt YL^2)\)。展开 \(\Lambda=1+\lambda\) 后，把目标一点项
\(\sum_k r_L(k)\sum_{n=A}^B\mu(2n+k)\) 按 \(k\) 的奇偶分组。每组取 \(k=0\) 或 \(1\) 为基准；基准短和由 (31) 控制，权和分别为 \(O(L)\) 与 \(O(1)\)。组内 \(k\) 每移动两格，两个长度至多 \(L\) 的端段一增一减；(31) 和
\(\sum|r_L(k)|\ll L^2\)、\(\sum|r_L(k)|k\ll L^3\)
给总预算
\[
O\!\left(LY e^{-g'V_Y}+L^3e^{-g'V_Y}
+L^2Y^{5/8}+\sqrt YL^2\right)=o(H^2Y^2).
\]
这证明第三行。以上是固定内区、正位移的精确中心化结论；不能把这六个二点项各自取绝对值后声称支付完整 Haar 门。

## 偶奇相邻配对将完整 Haar 门压到半格

这一节是对**真实完整周期系数** \(c\) 的另一个精确目标量级化简。把 note 870 的 \(L=\lfloor M/(32H)\rfloor\) 向下调整至最近偶数 \(L'=2\lfloor L/2\rfloor=2\ell\)，并令 \(b_x=c(M+x)\)、\(x\bmod M\)。两个 Haar 滤波器的差在每个 \(x\) 只涉及至多三个边界值：
\[
\mathsf H_Lb(x)-\mathsf H_{L-1}b(x)
=2b_{x-L+1}-b_{x-2L+2}-b_{x-2L+1}
\quad(L\text{ odd}).
\]
由 \(|c(m)|\ll\log(2Y)\)、\(\sum_{M\le m<2M}|c(m)|^2\ll Y\log(2Y)\) 与 Young 不等式，
\[
|V_L(c)-V_{L'}(c)|
\ll YL\log^{3/2}(2Y)+Y\log^2(2Y)
=o(H^2Y^2).
\tag{32}
\]
这里 \(V_s(c)=\sum_{x\bmod M}|\mathsf H_s b(x)|^2\)。调整至偶数并不破坏 note 870 的频带传递：仍有 \(L'\asymp M/H\) 且 \(|h|L'/M\) 在支撑 \(H/2\le|h|\le4H\) 上远离零与整数，故其 Fourier 乘子仍为 \(\asymp L'\)。

现在令 \(e_t=b_{2t}\)、\(o_t=b_{2t+1}\)，\(t\bmod Y\)，并把半格 Haar 滤波记作 \(\mathsf H_\ell\)。以下半格序列均先在 \(Y\le n<2Y\) 取值，再按模 \(Y\) 周期化；窗口折返时不能把全局 \(c(n)\) 的区间外数值直接代入。逐项分开偶、奇 \(j\) 得到**精确恒等式**
\[
\begin{aligned}
\mathsf H_{2\ell}b(2t)
 &=\mathsf H_\ell e(t)+\mathsf H_\ell o(t-1),\\
\mathsf H_{2\ell}b(2t+1)
 &=\mathsf H_\ell e(t)+\mathsf H_\ell o(t).
\end{aligned}
\tag{33}
\]
置 \(d_t=e_t+o_t\)、\(w=\mathsf H_\ell d\)、
\(\Delta_t=(\mathsf H_\ell o)(t-1)-(\mathsf H_\ell o)(t)\)。则
\[
V_{2\ell}(c)=2\|w\|_2^2+2\operatorname{Re}\langle w,\Delta\rangle
+\|\Delta\|_2^2,
\qquad
-\Delta_t=o_t-2o_{t-\ell}+o_{t-2\ell}.
\tag{34}
\]
最后的三点端差使 \(\|\Delta\|_2^2\ll Y\log^2(2Y)\)；另一方面
\(\|w\|_2^2\ll YL^2\log(2Y)\)。结合 (32)–(34)，得到
\[
\boxed{\quad
V_L(c)=2\sum_{t\bmod Y}
 \left|\mathsf H_\ell\{c(2(Y+t))+c(2(Y+t)+1)\}\right|^2
+o(H^2Y^2).
\quad}
\tag{35}
\]

半格系数还可把无效背景精确除去。对 \(Y\le n<2Y\)，直接代入 note 849 式 (10)：
\[
c(2n)+c(2n+1)
=6+2\Lambda(n)-4\Lambda(2n)-4\Lambda(2n+1)
-4(\log2)\{\mu(2n)+\mu(2n+1)\}.
\tag{36}
\]
常数 \(6\) 被 Haar 滤波精确消去；\(\Lambda(2n)\ne0\) 只在 \(2n\) 为 \(2\) 的幂时发生，当前半格至多一个指标，故该项的 Haar 能量为 \(O(L\log^2Y)\)。用 (35) 的粗界作 Cauchy--Schwarz，删除它对平方能量的影响为 \(o(H^2Y^2)\)。设
\[
g(n)=2\Lambda(n)-4\Lambda(2n+1)
-4(\log2)\{\mu(2n)+\mu(2n+1)\}.
\tag{37}
\]
则 (35) 等价于
\[
\boxed{\quad V_L(c)=2\sum_{t\bmod Y}
|\mathsf H_\ell g(Y+t)|^2+o(H^2Y^2).
\quad}
\tag{38}
\]
式 (38) 保留全部真实算术符号，并将未付门写在一个半格上；\(\mu(2n)=-\mu(n)\mathbf1_{n\text{ odd}}\) 还可作显式二进制替换。它是目标量级的结构化恒等式，不证明右侧有 \(O_\varepsilon(H^2Y^{2+\varepsilon})\) 上界，也不推出 RH。

同样的相邻配对也直接作用于 note 849 的**原始观察系数**。令
\[
\mathcal G_h(Y)=\sum_{Y\le n<2Y}
\frac{g(n)}{2n}\psi(n/Y)e(-hn/Y),
\tag{39}
\]
其中 \(g\) 为 (37) 的真实半格系数。先以
\(w(m)=\psi(m/M)/m\) 配对 \(m=2n,2n+1\)。由于
\(|w(2n+1)-w(2n)|\ll_\psi Y^{-2}\)、
\(|e(-h/M)-1|\ll|h|/Y\) 且物理块上
\(\sum|c(m)|\ll Y\log(2Y)\)，逐频的配对误差为
\(O_\psi((1+|h|)\log(2Y)/Y)\)。式 (36) 中常数 \(6\) 的光滑非零频 Fourier 和为 \(O_\psi(H^{-3})\)，唯一可能的 \(\Lambda(2n)\) 幂项逐频为 \(O_\psi(\log(2Y)/Y)\)。因此
\[
\boxed{\quad
\sum_h\eta(h/H)|\mathcal A_h(Y)-\mathcal G_h(Y)|^2
\ll_{\psi,\eta}
\frac{H^3\log^2(2Y)}{Y^2}+H^{-5}
=o(H^4/Y).
\quad}
\tag{40}
\]
这里常数 Fourier 和用 \(\psi(t)/t\in C_c^3((1,2))\) 的三次分部积分；\(H\ll Y\) 排除非零周期别名。故 note 849 式 (15) 的真实观察频带界在目标量级上与 \(\mathcal G_h\) 的同一界等价。半格的 \(2n+1\) 素数和 Möbius 项仍含新的仿射二点相关；(40) 只是可控的相邻配对，不是算术上界。

## 增长周期的局部偏置可从 Haar 门中剔除

以下是确定性结论，适用于上面的真实 \(c\)，但**不**估计剔除后的算术均方。它说明固定或适度增长的同余类偏置不能单独造成尚未支付的 Haar 门。

仍令 \(M=2Y\)、\(L=\lfloor M/(32H)\rfloor\)，\(Y^{1/5}\le H\le Y^{1/4}\)。取任意整数 \(1\le P\le M\)，任意普通整数上的 \(P\)-周期实序列 \(v\) 满足 \(\|v\|_\infty\le B\)。只在物理块 \(M\le m<2M\) 取其值，然后**单独**按模 \(M\) 周期化为 \(v_M\)。即使 \(P\nmid M\)，仍有
\[
\boxed{\quad
\|\mathsf H_Lv_M\|_{\ell^2(\mathbb Z/M\mathbb Z)}^2
\le 64MP^2B^2.
\quad}\tag{41}
\]
证明：令 \(\bar v=P^{-1}\sum_{r=0}^{P-1}v(r)\)。任一普通整数区间 \(J\) 的长度为 \(qP+r\)、\(0\le r<P\) 时，\(\sum_Jv-|J|\bar v\) 只来自尾部 \(r\) 项，绝对值至多 \(2PB\)。每个长度 \(L<M/2\) 的周期窗口至多在物理块拼接处断成两个普通区间，因此其和与 \(L\bar v\) 的差至多 \(4PB\)。两个相邻窗口相减给逐点 \(|\mathsf H_Lv_M|\le8PB\)，平方求和即得 (41)。特别地，这一证明无需 \(P\mid L\) 或 \(P\mid M\)。

对真实 \(c\)，在每个模 \(P\) 剩余类上取物理块经验平均 \(v_P(r)\)（空类置零），并置 \(c_P(m)=c(m)-v_P(m)\) 于 \(M\le m<2M\)，之后分别按模 \(M\) 周期化。由于 \(|c(m)|\ll\log(2Y)\)，(41) 与平方范数三角不等式给
\[
\left|\sqrt{V_L(c)}-\sqrt{V_L(c_P)}\right|
\ll \sqrt Y\,P\log(2Y).
\tag{42}
\]
因而只要 \(P\log(2Y)=o(H\sqrt Y)\)，真实 \(V_L(c)\ll_\varepsilon H^2Y^{2+\varepsilon}\) 当且仅当相同目标上界对 \(V_L(c_P)\) 成立。一致可选 \(P\le H\sqrt Y/\log^2(2Y)\)；在 \(H\asymp Y^{1/5}\) 时，该界允许 \(P\) 到 \(Y^{7/10}/\log^2Y\)。这里的“当且仅当”只关于目标**上界**，不声称两个能量之差为 \(o(H^2Y^2)\)。

若需要不预设目标上界的**加性**比较，则对 \(S=\sum_{M\le m<2M}|c(m)|^2\ll Y\log(2Y)\) 用 Young 不等式得 \(\sqrt{V_L(c)}\le2L\sqrt S\)。再由 (41) 极化，
\[
|V_L(c)-V_L(c_P)|
\ll YLP\log^{3/2}(2Y)+YP^2\log^2(2Y).
\tag{43}
\]
所以 \(P\le H^3/\log^2(2Y)\) 时，(43) 为 \(o(H^2Y^2)\)，一致于指定的全部 \(H\)。特别在最低频端可把模数至 \(Y^{3/5}/\log^2Y\) 的经验同余偏置从能量**数值**中剔除。

式 (42) 的周期阈值对一般有界序列在幂次上不能增大。固定 \(H\asymp Y^{1/5}\)，取整数 \(P\asymp H\sqrt Y\) 使 \(L/P\) 距半整数为 \(o(1)\)，并取 \(v(m)=\cos(2\pi m/P)\)。这样的 \(P\) 可由 \(P=\lfloor L/(K+1/2)\rfloor\)、\(K\asymp L/(H\sqrt Y)\) 选出。离周期拼接至少 \(2L\) 的 \(M-2L\asymp Y\) 个位置上，(5) 的同一几何和公式给 \(|\mathsf H_L e(m/P)|\asymp P\)；该区间含 \(\gg Y/P\) 个完整余弦周期，所以 \(V_L(v_M)\gg YP^2\asymp H^2Y^2\)。这是确定性阈值模型，不是对真实 \(c\) 的下界。

逐式复核说明：(25) 的 \(L^2/2\) 来自 \(\int_0^{1/3}(2-3s)\,ds\)；(27) 的奇格权和为 \(0\) 或 \(-1\)，两个移动端段的格点数相同；(30) 的奇格 Möbius 递推在实端点上精确成立；(33) 中偶输入的奇下标必须是 \(o(t-1)\)；(38)、(40) 的半格序列均先在 \([Y,2Y)\) 定义再周期化。这些检查未产生真实联合二点上界，故 (41)–(43) 仅排除周期性一点偏置作为该门的独立来源。

## 完整位移中的素数目标主项低于门槛

式 (25) 在 \(1\le k\le L/3\) 有大于目标量级的两个相反主项。把目标素数扩到 Haar 核的**完整** \(1\le k<2L\) 后，光滑素数密度的贡献却自动低于 \(H^2Y^2\)。这精确定位了该交叉中仍待支付的真实二点部分。

仍取固定内区 \(I=[aM,bM]\)、\(5/4<a<b<3/2\)，并令
\[
\mathcal X_I^{\rm prime,full}
=16(\log2)\sum_{p\in I\atop p\ {m prime}}\log p
 \sum_{1\le k<2L}r_L(k)\mu(p+k)
 \mathbf1_{p+k\ {m prime}}.
\]
用 \(\lambda(n)=\Lambda(n)-1\)，无条件且在整个指定 \(H\) 范围内一致有
\[
\boxed{\quad
\mathcal X_I^{\rm prime,full}
=-16(\log2)\sum_{n\in I\cap\mathbb Z}\lambda(n)
 \sum_{1\le k<2L}r_L(k)
 \frac{\lambda(n+k)}{\log(n+k)}
+o(H^2Y^2).
\quad}\tag{44}
\]
式 (44) 是**完整素数目标子交叉的目标量级中心化**。右侧仍需真实的带符号二点估计；(44) 不给它上界，也不把 (25) 的局部大主项抹掉。

证明先记 \(f(t)=1/\log t\)。素数目标上 \(\mu=-1\)，且高次素数幂在当前物理范围至多 \(O(\sqrt Y)\) 个。因此把 \(\mathbf1_{q\ {m prime}}\) 换成 \(\Lambda(q)/\log q\) 的总误差，按每个目标至多 \(2L\) 个源、\(|r_L|\le2L\)、\(\log p\ll\log Y\)，至多为 \(O(\sqrt YL^2\log Y)=o(H^2Y^2)\)。Haar 核的两个精确矩为
\[
\sum_{1\le k<2L}r_L(k)=-L,
\qquad
\sum_{1\le k<2L}k r_L(k)=-\frac{2L^3+L}{3}.
\tag{45}
\]
第一式由核的总和为零得出。第二式也可直接从一个任意零和有限滤波器 \(h_j\) 的恒等式看出：若 \(r(k)=\sum_jh_jh_{j+k}\)，\(S_t=\sum_{j\le t}h_j\)，则
\(\sum_{k\ge1}kr(k)=\sum_t(\sum_{j\le t}h_j)(\sum_{l>t}h_l)=-\sum_tS_t^2\)。对长度 \(L\) 的 Haar 滤波，前缀依次为 \(1,\ldots,L,L-1,\ldots,1\)，平方和正是 \((2L^3+L)/3\)。这也说明任意非零零和滤波器的单侧一阶相关矩都严格为负。由于 \(p\asymp Y\)、\(|f''(p+k)|\ll(Y^2\log^2Y)^{-1}\) 及 \(\sum k^2|r_L(k)|\ll L^4\)，Taylor 公式给每个源素数一致的
\[
\sum_{1\le k<2L}r_L(k)f(p+k)
=-\frac L{\log p}
+\frac{2L^3+L}{3p\log^2p}
+O\!\left(\frac{L^4}{Y^2\log^2Y}\right).
\tag{46}
\]
由 Chebyshev 的 \(\pi(I)\ll Y/\log Y\)、\(\sum_{p\in I}\log p\ll Y\)，(46) 乘源权后的总量至多
\[
O\!\left(\frac{YL}{\log Y}
+\frac{L^3}{\log^2Y}
+\frac{L^4}{Y\log^2Y}\right)
=o(H^2Y^2),
\tag{47}
\]
其中承重比值为 \(L^3/(H^2Y^2)\asymp Y/H^5\le1\)。于是只须保留目标的 \(\lambda(n+k)f(n+k)\)。

再把源素数权换成 \(\Lambda(n)\)：源高次素数幂的总 \(\Lambda\) 质量 \(O(\sqrt Y)\)，而每个源的内和绝对值 \(O(L^2)\)，故误差 \(O(\sqrt YL^2)=o(H^2Y^2)\)。展开 \(\Lambda=1+\lambda\)。源端的常数项恰为
\[
\sum_{n=A}^{B}\sum_{1\le k<2L}
r_L(k)\lambda(n+k)f(n+k),
\qquad I\cap\mathbb Z=[A,B].
\]
令 \(S_f(k)=\sum_{n=A}^{B}\lambda(n+k)f(n+k)\)。note 851 式 (4) 和离散 Abel 对当前 \(x\asymp Y\)、全部 \(1\le u\le2L\) 给加权短和
\(\sum_{x<m\le x+u}\lambda(m)f(m)
\ll(ue^{-gV_Y}+Y^{5/8})/\log Y\)，其中 \(g>0\) 固定；对 \(S_f(0)\) 同样取 \(u\asymp Y\)。平移求和区间只留下两个移动端段，故
\[
\begin{aligned}
\left|\sum_{1\le k<2L}r_L(k)S_f(k)\right|
&\ll \frac{L(Ye^{-gV_Y}+Y^{5/8})
 +L^3e^{-gV_Y}+L^2Y^{5/8}}{\log Y}\\
&=o(H^2Y^2).
\end{aligned}
\tag{48}
\]
最后一步使用 \(L\asymp Y/H\)、\(H^5\ge Y\)、\(H^4\ge Y^{4/5}\)。合并目标和源两次中心化便得到 (44)。\(\square\)

此子交叉还能按真实素数的奇格支撑作更尖锐的中心化。对奇数 \(n\) 记 \(\lambda_{\rm o}(n)=\Lambda(n)-2\)。充分大时，源素数与目标素数均为奇数，故目标位移必为 \(k=2j\)。于是
\[
\boxed{\quad
\mathcal X_I^{\rm prime,full}
=-16(\log2)
\sum_{\substack{n\in I\cap\mathbb Z\\n\ {m odd}}}
\lambda_{\rm o}(n)
\sum_{1\le j<L}r_L(2j)
\frac{\lambda_{\rm o}(n+2j)}{\log(n+2j)}
+o(H^2Y^2).
\quad}\tag{49}
\]
证明仍先用总质量 \(O(\sqrt Y)\) 支付源、目标高次素数幂，误差 \(O(\sqrt YL^2\log Y)=o(H^2Y^2)\)。对奇数格的目标写 \(\Lambda=2+\lambda_{\rm o}\)。由 (28) 及
\(\sum_{1\le j<L}(2j)|r_L(2j)|\ll L^3\)，每个源 \(n\) 的平滑目标项满足
\[
\sum_{1\le j<L}\frac{2r_L(2j)}{\log(n+2j)}
\ll \frac L{\log Y}+\frac{L^3}{Y\log^2Y};
\]
乘 \(\sum_{n\in I,\,n\ {m odd}}\Lambda(n)\ll Y\) 后为 \(o(H^2Y^2)\)。再把源 \(\Lambda=2+\lambda_{\rm o}\)。源常数 \(2\) 所乘的目标和，按 (29) 的奇格短和界、\(1/\log\) 的离散 Abel 及两个平移端段，至多
\[
O\!\left(\frac{L(Ye^{-gV_Y}+Y^{5/8}+\log Y)
 +L^3e^{-gV_Y}+L^2(Y^{5/8}+\log Y)}{\log Y}\right)
=o(H^2Y^2).
\]
所剩项正是 (49)。这里 \(\lambda_{\rm o}\) 仅在奇数上定义；(49) 没有把 (44) 的全整数 \(\lambda\) 逐项替换，而是重新支付了奇格的密度二与移动端点。\(\square\)

## 素数与平方自由合数目标的联合奇格门

将 (24) 的位移范围改为完整 \(1\le k<2L\)，分别记 \(\mathcal X_I^{\rm all,full}\)、\(\mathcal X_I^{\rm prime,full}\) 与 \(\mathcal X_I^{\rm comp,full}\)；三者仍满足逐项恒等式 \(\mathcal X^{\rm all,full}=\mathcal X^{\rm prime,full}+\mathcal X^{\rm comp,full}\)。定义两个真实中心化二点和
\[
\begin{aligned}
\mathcal P_I&=\sum_{\substack{n\in I\cap\mathbb Z\\n\ {m odd}}}
\lambda_{\rm o}(n)
\sum_{1\le j<L}r_L(2j)
\frac{\lambda_{\rm o}(n+2j)}{\log(n+2j)},\\
\mathcal M_I&=\sum_{\substack{n\in I\cap\mathbb Z\\n\ {m odd}}}
\lambda_{\rm o}(n)
\sum_{1\le j<L}r_L(2j)
\{\mu(n+2j)+\mu(n+2j+1)\}.
\end{aligned}
\tag{50}
\]
则在 \(Y^{1/5}\le H\le Y^{1/4}\) 一致有
\[
\boxed{\quad
\begin{aligned}
\mathcal X_I^{\rm prime,full}&=-16(\log2)\mathcal P_I+o(H^2Y^2),\\
\mathcal X_I^{\rm comp,full}&=16(\log2)(\mathcal P_I+\mathcal M_I)+o(H^2Y^2),\\
\mathcal X_I^{\rm all,full}&=16(\log2)\mathcal M_I+o(H^2Y^2).
\end{aligned}
\quad}\tag{51}
\]
前两式中相反的 \(\mathcal P_I\) 在完整交叉里**代数地消去**；(51) 并未给 \(\mathcal M_I\) 的目标上界。

证明第一式就是 (49)。对第三式，先把奇源素数权 \(\mathbf1_{n\ {m prime}}\log n\) 换成奇数上的 \(\Lambda(n)\)。源高次素数幂的总 \(\Lambda\) 质量为 \(O(\sqrt Y)\)，内层 \(\mu\) 权和绝对值至多 \(O(L^2)\)，故替换只花 \(O(\sqrt YL^2)=o(H^2Y^2)\)。在奇源格上写 \(\Lambda(n)=2+\lambda_{\rm o}(n)\)。常数源 \(2\) 所乘的目标和，按 \(k\) 奇偶分组：\(S(k)=\sum_{n\in I,\,n\ {m odd}}\mu(n+k)\) 对每个固定奇偶类都是一个目标奇格或偶格的移动区间和。两组的 Haar 权和分别为 \(R_o=0\) 或 \(-1\) 与 \(R_e=-L+\mathbf1_{L\text{ odd}}\)，均为 \(O(L)\)。note 851 式 (4) 经 (31) 的二进制递推，给这些基准区间和及每个移动端段
\(O(ue^{-gV_Y}+Y^{5/8}+1)\)。基准区间长 \(O(Y)\)；同奇偶的 \(k\) 移动只改变两个长 \(O(k)\) 的端段。由 \(\sum|r_L(k)|\ll L^2\)、\(\sum k|r_L(k)|\ll L^3\)，常数源的全部贡献至多
\[
O\!\left(LYe^{-gV_Y}+L^3e^{-gV_Y}
+L^2Y^{5/8}+L^2\right)=o(H^2Y^2).
\]
其中 \(L^2\) 吸收端点取整。因而只剩奇数源 \(\lambda_{\rm o}(n)\)。

对该源，单独的 \(k=1\) 项至多 \(O(YL)\)，因为 \(\sum_{n\in I,\,n\ {m odd}}|\lambda_{\rm o}(n)|\ll Y\)。其余位移按 \((2j,2j+1)\) 成对；核的相邻差 \(|r_L(2j+1)-r_L(2j)|\le3\)，所以将一对权改成共同的 \(r_L(2j)\) 只花 \(O(YL)=o(H^2Y^2)\)。所得正是 \(16(\log2)\mathcal M_I\)，证明 (51) 第三式；第二式再由逐项 \(\mathcal X^{\rm comp}=\mathcal X^{\rm all}-\mathcal X^{\rm prime}\) 得到。\(\square\)

这一步也给出明确的方法门槛。令 \(m(t)=\mu(2t+1)+\mu(2t+2)\)，则 \(\mathcal M_I\) 的内和是 \(\sum_jr_L(2j)m((n-1)/2+j)\)；\(m\) 的任意普通短和恰是连续整数上的一个 Möbius 短和。直接应用 note 851 式 (4)，取 \(\theta=7/12+\varepsilon_0<3/5\)，逐源 Abel 与 \(\sum_{n\in I,\,n\ {m odd}}|\lambda_{\rm o}(n)|\ll Y\) 仅给
\[
|\mathcal M_I|
\ll YL^2e^{-gV_Y}+YLY^\theta.
\tag{52}
\]
在 \(H\asymp Y^{1/5}\) 处，第一项与目标 \(H^2Y^2\) 的比为 \(Y^{1/5}e^{-gV_Y}\to\infty\)，第二项已为 \(o(H^2Y^2)\)。因此奇偶配对及完整位移的代数补偿已付清一点项，却没有从现有逐区间短和推出 \(\mathcal M_I\) 的固定幂上界；所需新增输入必须直接控制真实的 \(\lambda_{\rm o}\) 与相邻 Möbius 对的 signed 二点平均，或在完整三通道中再找到额外抵消。

### 在完整三通道 Gram 中的位置

为核对 (51) 是否已支付更大的门，令半格周期序列 \(A(n)=2\Lambda(n)\)、\(B(n)=-4\Lambda(2n+1)\)、\(U(n)=-4(\log2)\{\mu(2n)+\mu(2n+1)\}\)，并记 \(\mathcal E_\ell(F,G)=\sum_{t\bmod Y}(\mathsf H_\ell F)(t)(\mathsf H_\ell G)(t)\)。由 (38) **精确到目标量级**地有
\[
V_L(c)=2\{\mathcal E_\ell(A,A)+\mathcal E_\ell(B,B)
+\mathcal E_\ell(U,U)+2\mathcal E_\ell(A,B)
+2\mathcal E_\ell(A,U)+2\mathcal E_\ell(B,U)\}
+o(H^2Y^2).
\tag{53}
\]
式 (51) 的 \(\mathcal P_I\) 相消只发生在 \(\mathcal E_\ell(B,U)\) 的一个固定内区、单侧位移子块里：把 \(\mu\) 的素数与平方自由合数支撑重新相加，恢复原来的 \(\mu\) 通道。它没有改变 (53) 的数值，也没有提供跨 \(A,B,U\) 的新负项。尤其 (51) 不能被用作 \(V_L(c)\ll H^2Y^{2+\varepsilon}\) 的证明；完整 Gram 还含五类自配对或交叉配对及反向位移、周期边界。上面的 (19)–(23) 更证明：即使保留真实 \(\mu\)、素数支撑与全部已用的一点短和界，同一三通道结构仍容许一个正素数权反模型违反目标。因此不能再从这些输入的代数重排中寻求固定幂节省。下一项可能改变判断的真实输入是直接给 (53) 的**总平方**固定幂上界，或证明其中某个可单独支付的块具有该上界，而不是继续细分 \(\mathcal P_I\) 的素数／合数标签。
