# 观察频带的奇素数近距正块在同一素数通道内自我抵消

日期：2026-10-03。直接使用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (19)--(26) 的核、短区间素数输入与平滑频带。**尚无独立复核，留在 scratch。** 本结果识别其中近距正块的一个真实负补偿来源；[scratch 872](872-mesoscopic-prime-pair-band-limit-and-negative-kernel-annulus.md) 进一步给出固定缩放距离的精确极限与负环带。它们均不支付固定幂目标。

令 \(M=2Y\)，取 note 849 的 \(\psi\ge0\)、\(\psi\not\equiv0\) 和非负偶频带权 \(\eta\)，并设 \(Y^{1/5}\le H\le Y^{1/4}\)。定义**仅奇素数**的系数及 Fourier 和
\[
b_p=-\frac{4\log p}{p}\psi(p/M)
\quad(p\text{ 为奇素数}),\qquad b_m=0\quad(m\text{ 非奇素数}),
\qquad
P_h=\sum_m b_m e(-hm/M).
\tag{1}
\]
记 \(K_H(k)=\sum_h\eta(h/H)e(-hk/M)\)。选闭区间
\(J\subset(1,2)\) 使 \(\psi\ge c_\psi>0\) 于 \(J\)，并令
\(\mathcal P_Y=\{p:p\text{ 为素数},\ p/M\in J\}\)。
沿 note 849 的 \(K_0=H^3/\log^2(2Y)\)，定义同一奇素数通道中的近距正块
\[
\mathcal C_{\rm near}=
\sum_{\substack{p,q\in\mathcal P_Y\\
K_0<|p-q|\le Y/(16H)}}
b_pb_qK_H(p-q).
\tag{2}
\]

## 命题

对上述全部 \(H\) 一致有
\[
\boxed{\quad
\sum_h\eta(h/H)|P_h|^2=o_{\psi,\eta}(1),
\qquad
\mathcal C_{\rm near}\gg_{\psi,\eta}1.
\quad}
\tag{3}
\]
因此若 \(\mathcal C_{\rm rest}\) 为奇素数通道精确 Gram 展开中除 (2) 所列有序对之外的**全部**对，则
\[
\boxed{\quad
\mathcal C_{\rm rest}
=-\mathcal C_{\rm near}+o(1)\le-c_{\psi,\eta}<0
\quad}
\tag{4}
\]
对充分大 \(Y\) 成立。式 (4) 的负项可完全由素数--素数配对及带符号的频带核提供；无需把它归因于 Möbius 通道。

## 证明

置 \(w(m)=\psi(m/M)/m=M^{-1}\varphi(m/M)\)，其中
\(\varphi(t)=\psi(t)/t\in C_c^3((1,2))\)，并令
\(P_2(m)=\Lambda(m)-\mathbf1_{m\text{ prime}}\log m\)。
精确地有
\[
P_h=-4\sum_m(\Lambda(m)-1)w(m)e(-hm/M)
-4\sum_mw(m)e(-hm/M)
+4\sum_mP_2(m)w(m)e(-hm/M).
\tag{5}
\]
note 849 式 (23)--(26) 的证明对单独的 \(\Lambda-1\) 通道适用：
Heath--Brown 的短区间素数定理在长度 \(Y^{2/3}\) 的每个相关区间给
\(\sum(\Lambda-1)=o(Y^{2/3})\)；把长度
\(L=\lfloor Y/(16H)\rfloor\asymp Y/H\) 的移动窗口分成整块及余段，后者的平凡成本
\(O(Y^{2/3}\log Y)=o(L)\)，故所有窗口的加权中心和为
\(o(L/Y)\)。同一窗口 Parseval 步骤 (26) 给 (5) 第一项的频带能量 \(o(1)\)。

式 (5) 第二项由 Poisson 求和和 \(\varphi\in C_c^3\) 在
\(\eta(h/H)\ne0\) 时逐频为 \(O_\psi(H^{-3})\)，其频带能量为 \(O(H^{-5})\)。
note 849 式 (33) 给高次素数幂总质量
\(\sum_{m\le4Y}P_2(m)\ll\sqrt Y\log(2Y)\)，所以第三项逐频为
\(O_\psi(Y^{-1/2}\log Y)\)，能量为
\(O(H\log^2Y/Y)=o(1)\)。三项在加权 \(\ell^2_h\) 中用三角不等式合并，即得 (3) 第一式。

note 849 式 (19)--(21) 对其奇素数系数
\(a_p=[-4\log p+O(1)]w(p)\) 给相同的近距有序对下界。
本处 \(b_p=-4\log p\,w(p)\)；在 \(p\asymp Y\) 上两者同号且
\(b_p/a_p=1+O(1/\log Y)\)。同时 (21) 在 (2) 的距离内给
\(K_H(p-q)>0\)。故原证明逐项适用并得到
\(\mathcal C_{\rm near}\gg1\)，即 (3) 第二式。
最后
\(\sum_h\eta(h/H)|P_h|^2
=\sum_{p,q}b_pb_qK_H(p-q)
=\mathcal C_{\rm near}+\mathcal C_{\rm rest}\)
是精确恒等式；由 (3) 得 (4)。\(\square\)

## 边界

这里的 \(o(1)\) 仍没有 \(H^4/Y\) 所需的固定幂速率。式 (4) 只澄清 note 849 正子块的补偿可发生在**同一奇素数通道**，所以该正子块不能迫使 \(\Lambda\)--\(\mu\) 之间出现目标级负协方差；真实三通道的中距离算术门仍开放。
