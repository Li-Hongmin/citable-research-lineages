# 孤立 cofactor 3 壳中的真实 Möbius 中距离协方差（待异源复核）

日期：2026-10-03。依赖 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 式 (0)、(18) 和 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (C)。本命题只识别完整 signed 和中的一个正子块及其负补偿；它不证明固定幂上界或 RH。

## 命题

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，沿用 note 850 的 $D,R,G_\natural,T_\natural$、$\mathcal K_h(u)$、$G_{u,v}$ 和 $\mathfrak C_{\rm odd}$。固定非负实函数 $\psi\in C_c^3((1,2))$，并假定在某个闭区间 $J\subset(6/5,3/2)$ 上 $\psi>0$；取 note 851 的偶、非负、光滑频带权 $\eta$，满足 $\eta\ge1$ 于 $1\le|t|\le2$。

取闭区间 $I=[\alpha,\beta]\subset(2/5,1/2)$，使 $3I\subset J$，并令
\[
\mathcal S_M=\{u\in MI\cap\mathbb Z:u\text{ 奇数},\ \mu(u)=-1\}.
\]
设 $\mathcal P_{M,H}$ 是所有有序对 $(u,v)\in\mathcal S_M^2$，满足
\[
u\ne v,\qquad (u,v)\le G_\natural,\qquad
T_\natural<3|u-v|\le M/(32H).
\tag{1}
\]
则存在仅依赖于 $I,\psi,\eta$ 的常数 $c>0$，对全部充分大 $M$ 一致于上述 $H$，有
\[
\boxed{\quad
\sum_{(u,v)\in\mathcal P_{M,H}}\mu(u)\mu(v)G_{u,v}\ge c.
\quad}\tag{2}
\]
式 (2) 的每个对都属于 note 850 式 (18) 留下的小共同因子、非零中距离区域。又由 note 851 式 (C)，完整不同源和 $\mathfrak C_{\rm odd}=o(1)$，所以其余有序对的**实际** signed 和满足
\[
\mathfrak C_{\rm odd}-
\sum_{(u,v)\in\mathcal P_{M,H}}\mu(u)\mu(v)G_{u,v}
\le -c+o(1).
\tag{3}
\]
这里的负补偿已经是无条件事实；它仍只有常数量级，未达到 $H^4/M$ 的目标精度。

## 证明

对 $u\in MI$，有 $2<M/u<5/2$ 与 $4<2M/u<5$。在活动条件 $M<ku<2M$ 下，$k$ 只能是 $3,4$；而 note 850 的权 $W(4)=0$。故
\[
\mathcal K_h(u)=\frac{W(3)}M\phi(3u/M)e(-3hu/M),
\quad \phi(x)=\psi(x)/x,
\quad W(3)=-4\log(3/2)\ne0.
\tag{4}
\]
在 $MI$ 上，$\phi(3u/M)\ge c_\psi>0$。因此
\[
G_{u,v}=\frac{W(3)^2}{M^2}\phi(3u/M)\phi(3v/M)
J_H(3(u-v)),\qquad
J_H(r)=\sum_h\eta(h/H)e(-hr/M).
\tag{5}
\]
若 $|r|\le M/(32H)$，则 $|2\pi hr/M|\le\pi/4$ 在 $\eta(h/H)\ne0$ 时成立。偶性和非负性给
\[
J_H(r)=\sum_h\eta(h/H)\cos(2\pi hr/M)
\ge 2^{-1/2}\sum_h\eta(h/H)\gg_\eta H.
\tag{6}
\]
于是 (1) 中每对的 $\mu(u)\mu(v)G_{u,v}$ 至少为 $c_0H/M^2$。

用素数定理的 $\sum_{n\le x}\mu(n)=o(x)$ 可得 $\sum_{n\le x,\ n\text{ 奇}}\mu(n)=o(x)$：后一和 $S(x)$ 满足 $S(x)=M_\mu(x)+S(x/2)$，再按二次幂展开。平方自由筛给
\[
\sum_{n\le x,\ n\text{ 奇}}\mu(n)^2
=\frac x2\sum_{d\text{ 奇}}\frac{\mu(d)}{d^2}+O(\sqrt x)
=\frac{4x}{\pi^2}+O(\sqrt x).
\tag{7}
\]
故 $|\mathcal S_M|=(2/\pi^2)(\beta-\alpha)M+o(M)\gg_I M$。

把 $MI$ 分成 $B=O_I(H)$ 个长度不超过 $L=M/(96H)$ 的格，记每格有 $P_j$ 个 $\mathcal S_M$ 元素。Cauchy--Schwarz 给
\[
\sum_jP_j(P_j-1)\ge |\mathcal S_M|^2/B-|\mathcal S_M|
\gg_I M^2/H.
\tag{8}
\]
这些同格异元对均有 $3|u-v|\le M/(32H)$。其中 $3|u-v|\le T_\natural$ 的有序对至多 $O(M(T_\natural+1))=o(M^2/H)$，因为
$HT_\natural/M=H^4/[M\log^4(2M)]=O(\log^{-4}M)$。

共同因子过大的有序对，也可只用整数计数删去。对每个 $g>G_\natural$，$u\in MI$ 且 $g\mid u$ 至多有 $O(M/g+1)$ 种选择；给定 $u$ 后，同格中 $g\mid v$ 的选择至多 $O(L/g+1)$。对 $g\le M/2$ 求和，得到
\[
\#\{\text{同格对}:(u,v)>G_\natural\}
\ll \frac{ML}{G_\natural}+M\log M+L\log M+M
=o(M^2/H),
\tag{9}
\]
因为 $G_\natural\ge c\log^4M\to\infty$、$L\asymp M/H$ 及 $H\le Y^{1/4}$。由 (8)–(9)，$|\mathcal P_{M,H}|\gg M^2/H$，结合 (5)–(6) 证明 (2)。

最后，对 (1) 中每对有 $u,v\asymp M>D$、$u,v<2M/3$、$g=(u,v)\le G_\natural$；而 $u/g,v/g\gg M/G_\natural\gg R$。此外 $T_\natural<|\Delta|=3|u-v|\le M/(32H)<M^{1+\delta}/H$ 对任意固定 $\delta>0$ 成立。因此它们确实属于 note 850 式 (18) 的留存域。note 851 式 (C) 给 $\mathfrak C_{\rm odd}=O(e^{-2c_1V_Y})=o(1)$；从中减去 (2) 即得 (3)。$\square$

## 边界

此壳保留真实奇数平方自由 Möbius 符号，且 $u,v$ 的共同因子小、既约位移随 $M$ 增长。它证明完整两臂源 Gram 的剩余中距离区域内部必须发生异号补偿；没有识别负补偿的具体乘子、源壳或位移，也没有给出固定幂精度。

这个常数量级子块主要由 $\{\mu=-1\}$ 的正密度与频带核在短距离上的正性产生。它本身并未隔离超出一点密度定理的困难二点算术；因此不能将 (2) 的正下界当作接近 RH 门槛的证据。真正需要控制的是全部符号配对相消后的 $H^4/M$ 余量。
