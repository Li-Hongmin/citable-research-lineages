# 固定素数赋值状态可使用不同槽轮廓且保留严格 Weil 极限隙

日期：2026-10-03。依赖 [notes 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md)、[857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)、[858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md)、[859](../notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md) 的真实 Weil 形式、整数整除图、单位轮廓谱隙和赋值测度。本稿是解析证明草稿，尚未异源复核。它允许赋值状态改变每个槽的**函数形状**，超出 note 859 的标量调制及 [scratch 979](979-fixed-valuation-and-macroscopic-profiles-have-positive-weil-compression.md) 的共同微观轮廓。

## 定理

固定有限素数集 \(B\) 及每个 \(q\in B\) 的截断深度
\(J_q\ge0\)。令 \(\pi_B=\bigotimes_{q\in B}\pi_q\)，
\(\pi_q(j)=(1-q^{-1})q^{-j}\)，作用于完整的赋值空间
\(\mathbb N_0^B\)。取映射
\[
\boldsymbol\Phi:\mathbb N_0^B\longrightarrow
C_c^\infty((-1/2,1/2);\mathbb C)
\]
且它只依赖每个 \(\min(j_q,J_q)\)。其值因而只有有限多种。
记
\[
\begin{gathered}
v=\mathbb E_{\pi_B}\|\Phi_{\mathbf j}\|_2^2,\qquad
\kappa_{\mathbf j}=\int_{-1/2}^{1/2}\Phi_{\mathbf j}(u)\,du,\qquad
\bar\kappa=\mathbb E_{\pi_B}\kappa_{\mathbf j},\\
C[\phi]=\int_{\mathbb R}\log|\xi|\,|\widehat\phi(\xi)|^2
                   \frac{d\xi}{2\pi},\\
D_B[\boldsymbol\Phi]=
\sum_{q\in B}(\log q)\sum_{t\ge1}q^{-t}
\mathbb E_{\pi_B}
\|\Phi_{\mathbf j}-\Phi_{\mathbf j+t\mathbf e_q}\|_2^2 .
\end{gathered}\tag{1}
\]
空素数集按单一状态解释。沿奇素数 \(p\to\infty\)，令
\[
H=\log p,\quad N=(p^2-3)/2,\quad L_N=\sum_{n\le N}n^{-1},
\quad y_n=H-\log(2n),\quad \ell=2\theta/p^2,
\qquad 0<\theta\le1.
\]
在第 \(n\) 个整数槽定义
\[
U_{p,\theta,\boldsymbol\Phi}(y_n+t)=
\frac{\ell^{-1/2}\Phi_{\boldsymbol\nu(n)}(t/\ell)}
     {\sqrt{nL_N}},\qquad |t|<\ell/2,\quad 1\le n\le N,
\tag{2}
\]
其余处为零。这里
\(\boldsymbol\nu(n)=(\nu_q(n))_{q\in B}\)。
则 \(U_{p,\theta,\boldsymbol\Phi}\in C_c^\infty((-H,H))\)，
\(\|U_{p,\theta,\boldsymbol\Phi}\|_2^2\to v\)，而完整局部
Weil 形式的极限为
\[
\boxed{\quad
\lim_{p\to\infty}Q_W^H[U_{p,\theta,\boldsymbol\Phi}]
=\left(\log\frac1\theta+\gamma-\log(2\pi)\right)v
 \mathbb E_{\pi_B} C[\Phi_{\mathbf j}]
 D_B[\boldsymbol\Phi]+\theta|\bar\kappa|^2 .
\quad}\tag{3}
\]
若 \(\boldsymbol\Phi\ne0\) 于 \(\pi_B\)-正测度状态，则 \(v>0\)，且
\[
\boxed{\quad
\lim_{p\to\infty}Q_W^H[U_{p,\theta,\boldsymbol\Phi}]
\ge\delta v,\qquad
\delta=\frac{46}{25}-\log(2\pi)>0 .
\quad}\tag{4}
\]
常数 \(\delta\) 与 \(B,J_q,\theta\) 和各槽轮廓无关。
特别地，对任意固定有限维的这类状态依赖轮廓空间，
其真实 Weil 压缩矩阵充分大 \(p\) 时严格正定，物理
Rayleigh 谱底的下极限至少为 \(\delta\)。

## 证明

**几何。** 对 \(p\ge3\)，有 \(N=(p^2-3)/2\) 且
\(\ell\le2/p^2\)。因为 \(e^t-1<t/(1-t)\) 对 \(0<t<1\) 成立，
\[
N(e^\ell-1)
<N\frac{\ell}{1-\ell}
\le\frac{p^2-3}{p^2-2}<1.\tag{5}
\]
并且 \(\ell N<1\)，故相邻中心间距
\(\log(n/(n-1))>1/n\ge1/N>\ell\)。
外端距边界为
\(y_N+H=\log(p^2/(p^2-3))>3/p^2>\ell/2\)；
内端距边界为 \(\log2>\ell/2\)。所有槽相离且在
\((-H,H)\)。若素数幂平移连接两槽，则
\(|\log(r/(kn))|<\ell\)，由 (5) 与 \(r,kn\) 均为整数可知
\(r=kn\)；反向同理。因此 prime-shift 部分精确等于
note 854 的整数整除矩阵 \(C_N\) 张量微观轮廓恒等算子。
式 (5) 也覆盖 \(\theta=1\)，无需把这个端点仅理解为左极限。

**整除图。** 写 \(T_n=\Phi_{\boldsymbol\nu(n)}\)，视作
\(\mathcal H=L^2(-1/2,1/2)\) 中的向量，并设
\(W_N=\sum_{n\le N}\|T_n\|_{\mathcal H}^2/n\)。
固定截断赋值使 \(T_n\) 为固定模数
\(P=\prod_{q\in B}q^{J_q}\) 的周期向量。
中国剩余定理及逐同余类调和求和给
\[
\frac{W_N}{L_N}\to v,\quad
\frac1{L_N}\sum_{n\le N}\frac{T_n}{n}\to
\mathbb E_{\pi_B}\Phi_{\mathbf j},\quad
\frac1N\sum_{n\le N}T_n\to
\mathbb E_{\pi_B}\Phi_{\mathbf j}.\tag{6}
\]
note 854 式 (12) 是 Hilbert 空间值的纯代数恒等式：
\[
\begin{aligned}
\frac{\langle (n^{-1/2}T_n),C_N(n^{-1/2}T_n)\rangle}{L_N}
={}&\frac1{L_N}\sum_{n\le N}\frac{\|T_n\|^2}{n}
       \{M_1(N/n)+\log n\}\\
&-\frac1{L_N}
\sum_{k\ge2}\frac{\Lambda(k)}k
\sum_{n\le N/k}\frac{\|T_n-T_{kn}\|^2}{n},
\end{aligned}\tag{7}
\]
其中 \(M_1(x)=\sum_{k\le x}\Lambda(k)/k\)。
若 \(k=q^t\)、\(q\notin B\)，则 \(T_{kn}=T_n\)；
其余边的罚项恰来自 \(q\in B\)。由
\(M_1(x)=\log x-\gamma+o(1)\) 及 note 857 的调和截尾，
(7) 第一行是
\((\log N-\gamma)W_N/L_N+o(1)\)。对每个固定 \(q,t\)，
第二行内的调和平均趋于 (1) 的对应期望；
有限个状态的范数有界且 \(\sum_{t\ge1}q^{-t}<\infty\)，
所以截尾后取极限给整个罚项 \(D_B[\boldsymbol\Phi]\)。
Weil 的 prime-shift 项带负号，故
\[
Q_{\rm prime}
=-(\log N-\gamma)\frac{W_N}{L_N}
  +D_B[\boldsymbol\Phi]+o(1).\tag{8}
\]

**单槽与普通核。** note 004 的 Fourier--gamma 符号及
有限种固定轮廓给
\[
Q_{\rm diag}
=\{\log(1/\ell)-\log(2\pi)\}\frac{W_N}{L_N}
 +\frac1{L_N}\sum_{n\le N}\frac{C[T_n]}n+o(1).
\tag{9}
\]
后一项趋于 \(\mathbb E_{\pi_B}C[\Phi_{\mathbf j}]\)。
注意先合并 (8)--(9) 中的共同 \(W_N/L_N\) 再取极限；
这样不会把一个 \(O(1/\log N)\) 的调和密度误差乘
\(\log N\) 遗漏掉。

普通跨槽核为
\(-k(|y-z|)\)，\(k(t)=e^{-t/2}/(1-e^{-2t})\)。
置 \(\kappa_n=\int T_n\)。两个槽的核积分等于
\(\ell\kappa_n\overline{\kappa_r}k(|\log(r/n)|)\)
加中心替换误差。固定有限种轮廓都紧支撑于
\((-1/2,1/2)\)，故即使 \(\theta=1\) 也有一个固定的实际
支撑间隙。具体地，取固定 \(0<\rho<1\)，使所有轮廓的支撑
包含于 \([\!-\rho/2,\rho/2]\)。对 \(n<r\le2n\)，置
\(d=r-n\) 与 \(s=\log(r/n)\)。由 \(s>\ell\) 可知实际
核自变量至少为 \(s-\rho\ell\ge(1-\rho)s\)，所以中心
替换的单对误差在除去 \(L_N\) 前至多
\(O_{\boldsymbol\Phi}(\ell^2 n/d^2)\)。对 \(r>2n\)，
\(s\ge\log2\)，单对误差至多
\(O_{\boldsymbol\Phi}(\ell^2/\sqrt{nr})\)。于是归一化总误差为
\[
O_{\boldsymbol\Phi}\!\left(
\frac{\ell^2}{L_N}
\left\{\sum_{n\le N}n\sum_{d\ge1}d^{-2}
      +\left(\sum_{n\le N}n^{-1/2}\right)^2\right\}\right)
=O_{\boldsymbol\Phi}(\ell^2N^2/L_N)=o(1).
\]
note 859 式 (8)--(9) 的周期相关调和求和应用于
\(\kappa_n\)，得到
\[
Q_{\rm ord}
=-\frac{\ell}{L_N}\sum_{n\ne r\le N}
  \frac{\kappa_n\overline{\kappa_r}}{\sqrt{nr}}\,
  k(|\log(r/n)|)+o(1)
\longrightarrow-\theta|\bar\kappa|^2 .
\tag{10}
\]

**极点项。** 记
\(m_{\pm,n}=\int\ell^{-1/2}T_n(t/\ell)e^{\pm t/2}\,dt
=\sqrt\ell\,\kappa_n+O_{\boldsymbol\Phi}(\ell^{3/2})\)。
因 \(e^{y_n/2}=\sqrt{p/(2n)}\)、
\(e^{-y_n/2}=\sqrt{2n/p}\)，两中心常数在
\(2\operatorname{Re}(P_+\overline{P_-})\) 中相消。
由 (6)，
\[
Q_{\rm pol}\longrightarrow2\ell N|\bar\kappa|^2
\longrightarrow2\theta|\bar\kappa|^2.\tag{11}
\]
把 (8)--(11) 相加，并用
\(\ell N\to\theta\)，即得 (3)。

**严格隙。** note 858 对每个轮廓给
\[
C[T_n]+|\kappa_n|^2+\gamma\|T_n\|^2
\ge\frac{46}{25}\|T_n\|^2.
\]
令 \(s=\mathbb E_{\pi_B}|\kappa_{\mathbf j}|^2\)、
\(t=|\bar\kappa|^2\)；Cauchy--Schwarz 给
\(v\ge s\ge t\)。积分泛函在单位长度区间上的范数为
\(1\)，所以 (1) 的每个差平方至少为对应
\(|\kappa_{\mathbf j}-\kappa_{\mathbf j+u\mathbf e_q}|^2\)。
note 859 式 (12a) 的乘积概率方差不等式于是给
\[
D_B[\boldsymbol\Phi]\ge2\log2\,(s-t).\tag{12}
\]
由 (3)、note 858、(12) 得
\[
\begin{aligned}
\lim Q_W^H[U]-\delta v
&\ge-\log\theta\,v+(2\log2-1)(s-t)
                    -(1-\theta)t\\
&\ge(1-\theta)(v-t)+(2\log2-1)(s-t)\ge0,
\end{aligned}
\]
因为 \(-\log\theta\ge1-\theta\) 对 \(0<\theta\le1\)
成立。这证明 (4)。

固定有限维的状态依赖轮廓空间上，以上每项均可实或复极化；
有限维单位球的 Gram 误差趋零。极限形式由 (4)
支配 \(\delta\) 倍的极限物理 Gram，故真实压缩最终
严格正，且 Rayleigh 谱底有声明的下极限。\(\square\)

## 一个双状态的精确分解

取 \(B=\{2\}\)、\(J_2=1\)，记奇数槽与偶数槽的轮廓
分别为 \(\Phi_0,\Phi_1\)。令
\(a=(\Phi_0+\Phi_1)/2\)、\(b=(\Phi_0-\Phi_1)/2\)，并记
\(\kappa_a=\int a\)。由于两种状态在 \(\pi_2\) 下各有
概率 \(1/2\)，而只有从赋值零态出发的 \(2\)-幂边有非零差，
\[
v=\|a\|_2^2+\|b\|_2^2,\qquad
\mathbb E C[\Phi_{\mathbf j}]=C[a]+C[b],\qquad
D_B=2\log2\,\|b\|_2^2,\qquad
\bar\kappa=\kappa_a.
\]
因此 (3) 恰分解为两个互不耦合的轮廓形式
\[
\lim Q_W^H[U]
=\bigl(C[a]+c_\theta\|a\|_2^2+\theta|\kappa_a|^2\bigr)
 +\bigl(C[b]+(c_\theta+2\log2)\|b\|_2^2\bigr),
\qquad c_\theta=\log(1/\theta)+\gamma-\log(2\pi).
\]
在 \(\theta=1\) 时，note 858 分别给对称块至少
\(\delta\|a\|_2^2\)，反对称块至少
\((\delta+2\log2-1)\|b\|_2^2\)。后一估计只使用
\(|\int b|^2\le\|b\|_2^2\)，并没有假设两个轮廓同形。

## 与增长宏观轮廓的合并

固定一个有限维空间 \(\mathscr M\)，其元素都是上述
赋值状态依赖的微观轮廓向量；允许各状态有不同形状。
令 \(V_p\subset\mathrm{BV}([0,1])\) 包含常数且到
\(L^2[0,1]\) 单射，定义
\[
K_p=\sup_{0\ne f\in V_p}
\frac{\|f\|_\infty+\operatorname{Var}f}{\|f\|_2}.
\]
若 \(K_p=o(\sqrt{\log N})\)，则把 (2) 中的
\(\Phi_{\boldsymbol\nu(n)}\) 换为任意
\(u(\boldsymbol\nu(n),\log n/\log N,\cdot)\)，
\(u\in\mathscr M\otimes V_p\)，所得到的**整个增长空间**
最终仍严格正。其微观状态均值块的 Rayleigh 本征值收敛到
(3) 在 \(\mathscr M\) 上的算子本征值，其他本征值一致为
\(\log N(1+o(1))\)。

证明保留 [scratch 980](980-slowly-growing-log-profile-spaces-remain-weil-positive.md)
的双层 Abel 误差，而把固定标量赋值系数换成
\(\mathscr M\) 的一组固定基。基向量之间的微观
\(L^2\) 内积是固定模数周期序列；在 \(q\notin B\)
的素数幂边上赋值状态不变。因此对宏观 BV 系数
一致得到
\[
Q_W^H[\mathcal U_pu]
=L\left\{
\mathbb E_{\pi_B}\int_0^1\|u_{\mathbf j}(x)\|_2^2dx
-\mathbb E_{\pi_B}
 \left\|\int_0^1u_{\mathbf j}(x)\,dx\right\|_2^2
\right\}
+O_{B,\mathscr M}(K_p^2)\|u\|_2^2,
\tag{13}
\]
及物理 Gram
\(\|\mathcal U_pu\|_{L^2}^2
=(1+O_{B,\mathscr M}(K_p^2/L))\|u\|_2^2\)，
其中 \(L=\log N\)、\(\|u\|_2\) 指 (13) 第一项的
平方根。对宏观常数子空间，(3)--(4) 给低块
极限 \(\ge\delta I\)；对宏观零均值子空间，
(13) 给高块 \(LI+O(K_p^2)\)；
两块交叉只有 \(O(K_p)\)，因为 (13) 的领先项正交。
Schur 扣款 \(O(K_p^2/L)=o(1)\)。
这证明正性及谱分离；各矩阵误差对增长维数一致，
因为 \(\mathscr M\) 固定而 (13) 只使用 \(K_p\)。

## 边界

定理允许每个固定赋值状态使用不同的微观形状，甚至复值轮廓；
每次 \(p\to\infty\) 时状态集、微观轮廓空间与 \(\theta\) 固定。
增长结论仍受宏观 BV 嵌入常数限制。
它不约束任意槽系数或槽外补空间，
也不提供 note 849 式 (15) 的 moving-\(N\) 固定幂协方差。
