# 固定有限素数集的任意有界赋值轮廓保留最大整数格 Weil 正隙（待复核）

日期：2026-10-02。依赖 [note 859](../notes/859-fixed-prime-valuation-profiles-retain-maximal-weil-grid-gap.md) 的完整 Weil 分解、[note 858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的单位轮廓谱隙。本稿使赋值轮廓随 $p$ 变化，且不要求最终常值。

## 命题

固定有限素数集 $B$、$v_0>0$、$0<c<4$，以及实单位函数 $\varphi\in C_c^\infty((-1/2,1/2))$。沿奇素数 $p\to\infty$，置 $H=\log p$、$M=(p^2-5)/4$、$\ell=c/p^2$，并沿用 note 859 的槽 $I_n$、$\kappa=\int\varphi$、$C_\varphi$。每个 $p$ 任取实函数 $F_p:\mathbb N_0^B\to[-1,1]$，不要求彼此相同、截断或乘法分离。令
\[
 \pi_B(\mathbf j)=\prod_{q\in B}(1-q^{-1})q^{-j_q},\quad
 m_p=\mathbb E_{\pi_B}F_p,\quad
 v_p=\mathbb E_{\pi_B}F_p^2\ge v_0,
\]
\[
 D_p=\sum_{q\in B}(\log q)\sum_{t\ge1}q^{-t}
 \mathbb E_{\pi_B}|F_p(\mathbf j)-F_p(\mathbf j+t\mathbf e_q)|^2.
\tag{1}
\]
以 $T_p(n)=F_p((\nu_q(n))_{q\in B})$、$W_M=\sum_{n\le M}T_p(n)^2/n$ 归一化，取
$f_p(y_n+t)=T_p(n)b_\ell(t)/\sqrt{nW_M}$ 于 $I_n$，其余为零。则 $\|f_p\|_2=1$，且对上述全部 $F_p$ **一致**有
\[
 \boxed{Q_W^H[f_p]
 =\log(4/c)+C_\varphi+\gamma-\log(2\pi)
 +\frac{D_p}{v_p}+\frac{c\kappa^2}{4}\frac{m_p^2}{v_p}+o_{B,c,\varphi,v_0}(1).}
\tag{2}
\]
从而同样一致有
\[
 \boxed{Q_W^H[f_p]\ge\frac{46}{25}-\log(2\pi)-o_{B,c,\varphi,v_0}(1)>0}
\tag{3}
\]
对充分大 $p$ 成立。空集 $B$ 退化为 note 857--858，以下只证明非空情形。

## 赋值类的统一求和

记 $Q=\prod_{q\in B}q$、$\omega=\prod_{q\in B}(1-1/q)$、$a(\mathbf j)=\prod_{q\in B}q^{j_q}$。$\boldsymbol\nu_B(n)=\mathbf j$ 当且仅当 $n=a(\mathbf j)r$ 且 $(r,Q)=1$。对所有 $Y\ge1$，初等容斥给
\[
 \sum_{r\le Y,(r,Q)=1}\frac1r=\omega\log Y+O_B(1),\qquad
 \#\{r\le Y:(r,Q)=1\}=\omega Y+O_B(1).
\tag{4}
\]
若 $a=a(\mathbf j)\le X$，把 (4) 用于 $Y=X/a$；若 $a>X$，则左侧相应质量为零而 $\log X\le\log a$。因而对所有 $X\ge1$ 与所有 $\mathbf j$，
\[
 \left|\sum_{n\le X\atop\boldsymbol\nu_B(n)=\mathbf j}\frac1n
 -\frac\omega a\log X\right|
 \ll_B\frac{1+\log a}{a}.
\tag{5}
\]
而 $\sum_{\mathbf j}(1+\log a(\mathbf j))/a(\mathbf j)<\infty$。故对任意 $|G|\le U$，一致有
\[
 \sum_{n\le X}\frac{G(\boldsymbol\nu_B(n))}{n}
 =\log X\,\mathbb E_{\pi_B}G+O_B(U).
\tag{6}
\]
同理计数时，对 $a\le X$ 每类的误差为 $O_B(1)$，类数为 $O_B((1+\log X)^{|B|})$；对 $a>X$，$X\sum_{a>X}a^{-1}\ll_B\sqrt X$，因为 $\sum_{\mathbf j}a(\mathbf j)^{-1/2}<\infty$。因此
\[
 \sum_{n\le X}G(\boldsymbol\nu_B(n))
 =X\,\mathbb E_{\pi_B}G+O_B(U\sqrt X)
\tag{7}
\]
对充分大 $X$ 成立（对有限小 $X$ 放大常数即可）。特别地，
\[
 W_M=v_p\log M+O_B(1),\quad
 \sum_{n\le M}T_p(n)/n=m_p\log M+O_B(1),\quad
 \sum_{n\le M}T_p(n)=m_pM+O_B(\sqrt M).
\tag{8}
\]
因为 $v_p\ge v_0$，$W_M\asymp_{B,v_0}\log M$。

## 整除图罚项

note 859 式 (6) 对任意 $T_p$ 仍精确，因为 $q^t$ 只改变第 $q$ 个赋值；不在 $B$ 的素数幂不改变 $F_p$。置 $\rho(x)=M_1(x)-\log x+\gamma$，其在 $[1,\infty)$ 有界且趋零。对固定 $A>1$，以 $n\le M/A$ 与 $n>M/A$ 分割，后一段的调和质量至多 $\log A+O(1)$。使用 (8)，得到一致的
\[
 \frac1{W_M}\sum_{n\le M}\frac{T_p(n)^2}{n}
 [M_1(M/n)+\log n]
 =\log M-\gamma+o(1).
\tag{9}
\]
对每个 $q\in B,t\ge1$，函数
$G_{q,t}(\mathbf j)=|F_p(\mathbf j)-F_p(\mathbf j+t\mathbf e_q)|^2\le4$。
在 $q^t\le M$ 时，(6) 给
\[
 \sum_{n\le M/q^t}\frac{G_{q,t}(\boldsymbol\nu_B(n))}{n}
 =\log(M/q^t)\,\mathbb E_{\pi_B}G_{q,t}+O_B(1).
\]
对 $q,t$ 以 $(\log q)q^{-t}$ 求和，误差为 $O_B(1)$；用
$\sum_{t\ge1}tq^{-t}<\infty$ 支付 $t\log q$ 修正，用
$\sum_{q\in B}\sum_{q^t>M}(\log q)q^{-t}\ll_BM^{-1}$
支付截尾，即得整除图罚项 $E_M=D_p\log M+O_B(1)$。所以
\[
 \langle g,C_Mg\rangle/W_M
 =\log M-\gamma-D_p/v_p+o_{B,v_0}(1),
\qquad g_n=n^{-1/2}T_p(n).
\tag{10}
\]

## 普通核：截断赋值与谐波相关

设 $b=|B|\ge1$。对每个 $q\in B$，取
\[
 J_q=\left\lfloor\frac{\log\log M}{2b\log q}\right\rfloor,
 \quad P=\prod_{q\in B}q^{J_q}\le(\log M)^{1/2},
 \quad \tau=\sum_{q\in B}q^{-J_q}\ll_B(\log M)^{-1/(2b)}.
\tag{11}
\]
充分大 $M$ 时全部 $J_q\ge1$。定义 $F_p^{(J)}(\mathbf j)=F_p((\min(j_q,J_q))_{q\in B})$、$T_p^{(J)}(n)=F_p^{(J)}(\boldsymbol\nu_B(n))$。后者模 $P$ 周期，$|T_p^{(J)}|\le1$，其周期均值 $m_p^{(J)}$ 满足 $|m_p^{(J)}-m_p|\le2\tau$。又因两序列只在某个 $q^{J_q}\mid n$ 时可能不同，
\[
 \|T_p-T_p^{(J)}\|_{\ell^2(1\le n\le M)}^2
 \le4\sum_{q\in B}\lfloor M/q^{J_q}\rfloor\le4M\tau.
\tag{12}
\]
令 $K_{nr}=\mathbf1_{n\ne r}/|n-r|$。其每行绝对和至多 $2H_{M-1}\ll\log M$，故加权 Schur 给 $\|K\|_{2\to2}\ll\log M$。写
$S(T)=\sum_{n<r\le M}T(n)T(r)/(r-n)=\langle T,KT\rangle/2$，由 (12) 与 $\|T\|_2,\|T^{(J)}\|_2\le\sqrt M$ 得
\[
 |S(T_p)-S(T_p^{(J)})|\ll M\log M\sqrt\tau.
\tag{13}
\]

对任意模 $P$ 周期、绝对值至多 $1$ 的实序列 $u(n)$，周期均值 $m_u$，置 $c_d=P^{-1}\sum_{a\bmod P}u(a)u(a+d)$。$c_d$ 模 $P$ 周期，周期均值为 $m_u^2$，并有
$\sum_{n\le M-d}u(n)u(n+d)=(M-d)c_d+O(P)$。把 $d<P$ 与 $d\ge P$ 分开，在后者对均值零的周期序列 $c_d-m_u^2$ 分部求和，得
\[
 \sum_{d<M}\frac{c_d-m_u^2}{d}=O(1+\log P),
\quad
 S(u)=Mm_u^2\log M+O(M(1+\log P)+P\log M).
\tag{14}
\]
由 (11)--(14) 与 $|m_p^{(J)}-m_p|\le2\tau$，
\[
 S(T_p)=M\log M\,[m_p^2+o_B(1)]
\tag{15}
\]
对全部 $F_p$ 一致。note 856 的第二核 $1/(r+n)$ 的总绝对质量为 $O(M)$；note 857 的共同槽中心核替换误差在 $|T_p|\le1$ 下仍为 $O_{c,\varphi}(1)$。以 $-\kappa^2\ell/W_M$ 乘 (15)，并用 $\ell M\to c/4$、(8)，得
\[
 Q_{\rm ord}[f_p]=-(c\kappa^2/4)m_p^2/v_p+o_{B,c,\varphi,v_0}(1).
\tag{16}
\]

## 极点项与统一正隙

note 859 式 (11) 的极点公式对任意槽系数精确。由 (8) 及
$m_+m_-=\kappa^2\ell+O_\varphi(\ell^2)$，得
$Q_{\rm pol}[f_p]=(c\kappa^2/2)m_p^2/v_p+o_{B,c,\varphi,v_0}(1)$。同槽 Fourier 部分仍为 $\log(1/\ell)+C_\varphi-\log(2\pi)+o_\varphi(1)$。合并 (10)、(16) 与极点项，得 (2)。

note 859 的每坐标方差不等式及乘积测度张量化对任意 $F_p$ 仍成立，故
$D_p\ge2\log2(v_p-m_p^2)$。结合 note 858 的
$C_\varphi+\kappa^2\ge46/25-\gamma$，按 note 859 式 (13) 配方，得 (3)。$\square$

## 范围

在固定有限素数集 $B$ 上，任意随 $p$ 改变、任意赋值深度、任意坐标耦合的有界轮廓，只要调和均方不趋零，均不能在该最大整数格共同槽轮廓族中制造负 Weil 方向。这里仍未控制 $B$ 随 $p$ 增长、集中于极稀少赋值类的轮廓、任意槽系数、完整补空间或 moving-$N$ Möbius signed covariance。

## 加强：Cauchy 自相关的统一常数级余项

上面式 (14) 对一般周期序列成立，但赋值轮廓的周期自相关有额外不变性。以下引理不要求调和均方有正下界。

**引理。**固定有限素数集 $B$。任意充分大的 $M$ 与任意实函数 $F:\mathbb N_0^B\to[-1,1]$，令 $T(n)=F(\boldsymbol\nu_B(n))$、$m=\mathbb E_{\pi_B}F$。则一致有
\[
 \boxed{\sum_{1\le n<r\le M}\frac{T(n)T(r)}{r-n}
 =M\log M\,m^2+O_B(M).}\tag{17}
\]

**证明。**记 $L=\log M$，对每个 $q\in B$ 取 $J_q=\lceil2\log L/\log q\rceil$，并照式 (11) 截断 $F$。此时 $P=\prod q^{J_q}\ll_B L^{2|B|}$，$\tau=\sum q^{-J_q}\le |B|L^{-2}$。式 (12)--(13) 的同一 Schur 论证给
\[
 |S(T)-S(T^{(J)})|\ll_B ML\sqrt\tau\ll_B M,
 \qquad |m-m^{(J)}|\le2\tau.
\tag{18}
\]
若 $B=\varnothing$，$T$ 为常数且式 (17) 由调和数公式直接成立，以下设 $B\ne\varnothing$。

令 $u=T^{(J)}$，$c_d=P^{-1}\sum_{a\bmod P}u(a)u(a+d)$，并记 $v_u=P^{-1}\sum_{a\bmod P}u(a)^2$。关键是 $c_d$ 也只依赖 $\boldsymbol\nu_B(d)$ 的截断值。事实上，若 $d,d'$ 的这些截断赋值相同，则对每个 $q\in B$ 存在模 $q^{J_q}$ 的单位 $z_q$ 使 $d'\equiv z_qd\pmod{q^{J_q}}$；中国剩余定理给模 $P$ 的单位 $z$。变量代换 $a\mapsto za$ 保持 $u(a)$，故 $c_{d'}=c_d$。因此存在 $G$ 使 $c_d=G(\boldsymbol\nu_B(d))$。由 Cauchy--Schwarz，$|G|\le v_u$。对 $d$ 按模 $P$ 取平均时，$a,d$ 独立且均匀，故 $\mathbb E_{\pi_B}G=(m^{(J)})^2$。把式 (6) 用于这个 $G$，得到**不依赖周期 $P$** 的
\[
 \sum_{d<M}\frac{c_d}{d}=(m^{(J)})^2\log M+O_B(v_u).
\tag{19}
\]
又对每个 $d$，不完整周期的乘积绝对和由 Cauchy--Schwarz 至多为 $Pv_u$，故
$\sum_{n\le M-d}u(n)u(n+d)=(M-d)c_d+O(Pv_u)$。于是
\[
 S(u)=M\sum_{d<M}\frac{c_d}{d}-\sum_{d<M}c_d+O(Pv_u\log M)
 =ML(m^{(J)})^2+O_B\bigl(v_u(M+PL)\bigr).
\tag{20}
\]
由于 $PL\ll_B L^{2|B|+1}=o(M)$，式 (18) 与
$ML|(m^{(J)})^2-m^2|\ll ML\tau\ll M$ 合并即得 (17)。$\square$

## 加强：允许调和均方趋零

原命题的 $v_p\ge v_0$ 可改为尺度不变的条件。记
\[
 A_p=\|F_p\|_\infty>0,\qquad
 R_p=\frac{A_p^2}{v_p}\ge1,\qquad L=\log M.
\]
若
\[
 \boxed{R_p(1+\log R_p)=o(L),}\tag{21}
\]
则式 (2) 的统一渐近以及式 (3) 的严格正隙仍成立，$o(1)$ 对满足式 (21) 的任何给定上界速率一致。特别地，任意固定 $0<\varepsilon<1$ 下的 $R_p\le L^{1-\varepsilon}$ 满足条件；这允许归一化后的调和均方低至 $L^{-1+\varepsilon}$。

**证明。**由于 $f_p$ 及 $D_p/v_p,m_p^2/v_p$ 在 $F_p\mapsto F_p/A_p$ 下不变，可以设 $A_p=1$，从而 $v_p=R_p^{-1}$。式 (6)--(8) 的绝对误差仍为 $O_B(1)$ 或 $O_B(\sqrt M)$，且
\[
 W_M=v_pL+O_B(1)=v_pL\bigl(1+O_B(R_p/L)\bigr).
\tag{22}
\]

为控制式 (10) 的除法误差，先估计 $D_p/v_p$。固定 $q\in B$，展开平方并交换非负和，得到
\[
 \frac{D_{p,q}}{\log q}
 \le\frac{2v_p}{q-1}
 +2\sum_{t\ge1}q^{-t}\mathbb E_{\pi_B}|F_p(\mathbf j+t\mathbf e_q)|^2
 =\frac{2v_p}{q-1}
 +2\mathbb E_{\pi_B}[j_qF_p(\mathbf j)^2].
\tag{23}
\]
取 $J=\lceil\log_q(1/v_p)\rceil$。因为 $|F_p|\le1$ 且 $\pi_q$ 是几何分布，
\[
 \mathbb E[j_qF_p^2]
 \le Jv_p+\sum_{j>J}j\pi_q(j)
 \ll_q v_p(1+\log(1/v_p)).
\]
故 $D_p/v_p\ll_B1+\log R_p$。式 (21) 随即保证
\[
 \frac{D_pL+O_B(1)}{W_M}
 =\frac{D_p}{v_p}
 +O_B\!\left(\frac{R_p(1+\log R_p)}{L}\right)
 =\frac{D_p}{v_p}+o(1).
\tag{24}
\]
式 (9) 的素数定理余项也一致趋零：在 $n\le M/A$ 上由
$\sup_{x\ge A}|\rho(x)|$ 控制，在 $n>M/A$ 上的绝对调和质量为
$O(\log A+1)$，除以 $W_M\asymp L/R_p$ 后先令 $M\to\infty$、再令固定的 $A\to\infty$。这里仅用到式 (21) 蕴含 $R_p/L\to0$。

普通核现用式 (17)，再加上 $1/(n+r)$ 核的 $O(M)$ 总质量，便有其中心核和为 $MLm_p^2+O_B(M)$。以 $\kappa^2\ell/W_M$ 乘之，式 (22)、$m_p^2\le v_p$、$\ell M\to c/4$ 给式 (16)，误差为 $O_{B,c,\varphi}(R_p/L)+o(1)$。共同槽的中心核替换误差仍由 $|F_p|\le1$ 一致控制。

极点项仍用式 (8)：两个有限和的乘积为
$m_p^2ML+O_B(|m_p|M+|m_p|L\sqrt M+\sqrt M)$。因 $|m_p|\le\sqrt{v_p}$，乘 $m_+m_-/W_M=O_\varphi(\ell R_p/L)$ 后余项趋零，式 (11) 的极限保持不变。同槽项不依赖系数。由此重得式 (2)，而式 (12a)--(13) 的方差不等式对每个 $F_p$ 原样成立，故式 (3) 也成立。$\square$

式 (17) 是不需密度下界的独立相关估计；式 (21) 是把它与整除图及极点项组合为完整 Weil 极限所需的充分浓度条件。它仍不覆盖 $R_p\asymp\log M$ 或更稀少的赋值轮廓，也不控制任意槽系数和补空间。

## 再加强：对数浓度条件

上节的条件 (21) 不是最强结论。固定 $B,c,\varphi$，仍令 $R_p=\|F_p\|_\infty^2/v_p$、$L=\log M$。若
\[
 \boxed{(1+\log R_p)^2=o(L),}\tag{25}
\]
则式 (2)--(3) 仍成立，且余项对所有满足同一给定 $o(L)$ 上界的轮廓一致。这允许 $v_p/\|F_p\|_\infty^2$ 小至 $\exp[-o(\sqrt{\log M})]$。以下给出全部受稀疏性影响的估计；仍先把 $\|F_p\|_\infty$ 归一为一，写 $v=1/R$、$m=m_p$、$F=F_p$。

令 $U(\mathbf j)=\log a(\mathbf j)=\sum_{q\in B}j_q\log q$。保留式 (5) 的每类误差而不先取 $|G|$ 的上确界，可得到
\[
 \sum_{n\le X}\frac{G(\boldsymbol\nu_B(n))}{n}
 =\log X\,\mathbb E_{\pi_B}G
 +O_B\bigl(\mathbb E_{\pi_B}[(1+U)|G|]\bigr),\qquad X\ge1.
\tag{26}
\]
这对任意有界 $G$ 成立，隐含常数与赋值截断深度无关。由于 $\mathbb E_{\pi_B}e^{U/2}<\infty$，将 $U\le4\log R$ 与其补集分开，并在补集用 $(1+U)^k\le C_ke^{U/4}$，对 $k=0,1,2$ 得
\[
 \mathbb E_{\pi_B}[F^2(1+U)^k]
 \ll_{B,k}v(1+\log R)^k.
\tag{27}
\]
此外 Cauchy--Schwarz 给
$\mathbb E[(1+U)|F|]\ll_B\sqrt v$。故
\[
 W_M=vL+O_B(v(1+\log R)),\quad
 \sum_{n\le M}\frac{T(n)}n=mL+O_B(\sqrt v),\quad
 \sum_{n\le M}T(n)=mM+O_B(\sqrt M).
\tag{28}
\]
式 (25) 蕴含 $W_M\sim vL$、$Mv\to\infty$，甚至 $Mv\gg\sqrt M$。

对整除图罚项 $E_M$，将式 (26) 作用于
$G_{q,t}(\mathbf j)=|F(\mathbf j)-F(\mathbf j+t\mathbf e_q)|^2$。展开平方后，所有误差由 (27) 支付。具体地，含 $F(\mathbf j)^2$ 的项在 $t$ 上由 $\sum_{t\ge1}q^{-t}(1+t)<\infty$ 支付；含 $F(\mathbf j+t\mathbf e_q)^2$ 的项用
$q^{-t}\pi_q(j)=\pi_q(j+t)$ 变元，固定终点 $k=j+t$ 时至多出现 $k_q$ 次，在 $t\log q$ 修正里出现 $\sum_{t\le k_q}t\ll k_q^2$ 次。因为 $k_q\log q\le U(\mathbf k)$，式 (27) 的二阶矩给
\[
 E_M=D_pL+O_B\bigl(v(1+\log R)^2\bigr)
      +O_B(L/M).
\tag{29}
\]
最后一项来自 $q^t>M$ 的几何尾。它除以 $W_M$ 后趋零。式 (23) 与 (27) 还给 $D_p/v\ll_B1+\log R$。因此
\[
 \frac{E_M}{W_M}
 =\frac{D_p}{v}
 +O_B\!\left(\frac{(1+\log R)^2}{L}
                 +\frac1{Mv}\right).
\tag{30}
\]
对式 (9) 中的 $\rho(M/n)$，固定 $A>1$ 后，在 $n\le M/A$ 用 $\sup_{x\ge A}|\rho(x)|$；其余调和质量由两次 (26) 至多为
$v\log A+O_B(v(1+\log R))$。除以 $W_M\sim vL$，先令 $M\to\infty$、再令 $A\to\infty$，该余项一致趋零。故式 (10) 在条件 (25) 下仍成立。

普通核需把 (17) 的绝对 $O(M)$ 改成相对均方的 $O(Mv)$。对每个 $q\in B$ 取
$J_q=\lceil\log_q(RL^2)\rceil$，则
$\tau=\sum q^{-J_q}\le |B|v/L^2$，而
$P=\prod q^{J_q}\ll_B(RL^2)^{|B|}$。式 (25) 蕴含 $PL=o(M)$。式 (7) 对 $F^2$ 及 $(F^{(J)})^2$ 给
$\|T\|_2^2,\|T^{(J)}\|_2^2\ll_B Mv$；这里 $v_J=\mathbb E(F^{(J)})^2\le v+2\tau$，且 $\sqrt M=o(Mv)$。又 $\|T-T^{(J)}\|_2^2\le4M\tau$。用式 (13) 的 Schur 核估计得到
\[
 |S(T)-S(T^{(J)})|\ll_B ML\sqrt{v\tau}\ll_B Mv.
\tag{31}
\]
周期相关仍只依赖截断赋值，故式 (19)--(20) 的 $v_u$ 版本给
$S(T^{(J)})=ML(m^{(J)})^2+O_B(Mv+PvL)$。
又 $|m-m^{(J)}|\le2\tau$，于是
\[
 \boxed{S(T)=MLm^2+O_B(Mv).}\tag{32}
\]
第二普通核 $1/(n+r)$ 也有 $O(Mv)$ 而无需逐项绝对界：取 Schur 权 $n^{-1/2}$，则
$\sum_{r\ge1}(n+r)^{-1}r^{-1/2}\le\pi n^{-1/2}$，故 Hilbert 矩阵的 $\ell^2$ 范数至多 $\pi$，其在 $T$ 上的二次型为 $O(\|T\|_2^2)=O(Mv)$。共同槽中心核替换的近对角误差矩阵每行绝对和为
$O_{c,\varphi}(\ell^2M)=O_{c,\varphi}(M^{-1})$；远对角误差矩阵由
$O_{c,\varphi}(\ell^2/\sqrt{nr})$ 控制，其范数至多
$O_{c,\varphi}(\ell^2L)$。因此替换误差为 $O_{c,\varphi}(v)$，除以 $W_M$ 是 $O(1/L)$。式 (32) 遂给式 (16)，误差为 $o(1)$。

最后，式 (28) 的两个极点和相乘，主项为 $m^2ML$，误差至多
$O_B(|m|M\sqrt v+|m|L\sqrt M+\sqrt{Mv})$。由 $|m|\le\sqrt v$、$Mv\to\infty$，乘 $m_+m_-/W_M=O_\varphi(\ell/(vL))$ 后趋零；分母替换 $W_M\mapsto vL$ 的相对误差由式 (28) 支付。同槽项照旧。由此得到式 (2)。方差下界与单位轮廓谱隙不依赖 $v$，故式 (3) 也成立。$\square$

条件 (25) 仍只是充分条件；在 $\log R\asymp\sqrt L$ 的边界，式 (29) 的二阶赋值矩误差与所求常数项同阶。它不估计这一区域的 Weil 符号。
