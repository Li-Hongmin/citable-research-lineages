# 加宽 Farey 槽的非精确交叉删去高次素数幂后是互异双素数短移位（候选）

日期：2026-09-29。依赖 [scratch 817](817-polynomial-denominator-exterior-slots-have-logarithmic-farey-leakage-candidate.md) 的源和目标族、[scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的素数 forcing，以及 [scratch 829](829-critical-width-farey-near-forcing-is-absolutely-negligible-candidate.md) 式 (6)--(7a) 的整数缺陷公式。以下只估计**非精确源--目标交叉**的高次素数幂，并精确描述剩余素数和；尚未异源复核，留在 scratch。

## 命题

固定 \(7/4<\kappa\le23/12\)，令
\[
H=\log p,\quad Q=\lfloor p^{2/3}\rfloor,\quad
B=\lfloor p^{1/4}\rfloor,\quad \eta=p^{-\kappa},
\quad L=p^{23/12-\kappa},
\tag{1}
\]
其中 \(p\to\infty\) 沿奇素数。取 829 的 \(v_\eta\)、目标素数 forcing 系数
\(t^{\rm pr}_{m/c}=F_Q(m)/\sqrt{mc}\) 与 \(w_\eta=\sum t^{\rm pr}_{m/c}w^{(\eta)}_{m/c}\)。
将非精确源--目标算术交叉 \(E_{\rm near}\) 按移位 \(n\) 是素数或高次素数幂拆成
\(E_{\rm near}^{\rm pr}+E_{\rm near}^{\rm pp}\)。则对任意固定足够小的 \(\varepsilon>0\)，
\[
\boxed{\quad
|E_{\rm near}^{\rm pp}|
\ll_{\kappa,\varepsilon}
H^5p^{19/8-3\kappa/2+\varepsilon}=o(1).
\quad}
\tag{2}
\]
实际上同一估计在 \(19/12<\kappa\le23/12\) 仍给 \(o(1)\)；本文只在 (1) 的范围使用它。

素数余项是如下**精确有符号双素数和**：
\[
\begin{aligned}
\mathfrak B_{p,\kappa}
:={}&-\!\!\!\sum_{\substack{
1\le A,D<Q,\ A\ne D,\ (A,D)=1\\
2\le c\le B,\ h<Q,\ r,q\ {\rm prime}\\
p\le hr<cp,\ (hr,c)=1\\
d=qAc-Dhr\ne0,\quad
|\log(1+d/(Dhr))|<2\eta}}
\frac{(\log r)(\log q)}
{\sqrt{Dhr(Dhr+d)}}
R_\eta\!\left(\left|\log\left(1+\frac d{Dhr}\right)\right|\right),\\
E_{\rm near}&=\mathfrak B_{p,\kappa}+o(1).
\end{aligned}
\tag{3}
\]
每个有效项自动满足 \(q\ne r\)，甚至 \(q\nmid hr\)。因此 (3) 不含重复 forcing 素数或高次移位；它的符号及 \(H^4\) 尺度仍未估计。

更简洁地，沿用 829 式 (2) 的 \(F_Q\) 定义，将自变量从 \(m\) 换成 \(M\)。对 (3) 的**全部非零缺陷**置 \(M=(Dm+d)/c\)，则
\[
\boxed{\quad
\mathfrak B_{p,\kappa}
=-\!\!\sum_{\substack{
1\le D<Q,\ 2\le c\le B,\ p\le m<cp,\ (m,c)=1\\
d\in\mathbb Z\setminus\{0\},\ Dm+d>0,\ c\mid Dm+d\\
(M,D)=1,\quad |\log(1+d/(Dm))|<2\eta}}
\frac{F_Q(m)F_Q(M)}{\sqrt{Dm(Dm+d)}}
R_\eta\!\left(\left|\log\left(1+\frac d{Dm}\right)\right|\right),
\qquad M=\frac{Dm+d}{c}.
\quad}
\tag{3a}
\]
这里 \((M,D)=1\) 是原源互素条件的精确剩余，而非额外假设。

对 \(d=\pm1\) 的两个子和，(3a) 还可**无源互素条件**地精确写成
\[
\boxed{\quad
\mathfrak B_{p,\kappa}^{(d)}
=-\!\!\sum_{\substack{1\le D<Q,\ 2\le c\le B,\ p\le m<cp\\
c\mid Dm+d,\quad
|\log(1+d/(Dm))|<2\eta}}
\frac{F_Q(m)F_Q(M)}
{\sqrt{Dm(Dm+d)}}
R_\eta\!\left(\left|\log\left(1+\frac d{Dm}\right)\right|\right),
\quad M=\frac{Dm+d}{c},\quad d=\pm1.
\quad}
\tag{4}
\]
式 (4) 是两个互素线性形式的大素因子权的短移位相关，而非对一个素数变量使用素数定理即可解决的和。

## 证明高次素数幂的绝对支付

按 829 式 (6)--(7a)，任一非精确边有
\[
d=nAc-Dm\ne0,\qquad
X:=Dm<QBp<p^{23/12},\qquad
\left|\log(1+d/X)\right|<2p^{-\kappa}.
\]
与 829 式 (9) 同理，
\[
1\le|d|\ll L,\qquad X\gg p^\kappa|d|\gg p^\kappa.
\tag{5}
\]
因为 \(A<Q,c\le B\) 且 \(nAc=X+d\asymp X\)，有效移位满足
\[
n\gg\frac{p^\kappa}{QB}
\gg p^{\kappa-11/12}.
\tag{6}
\]
又 \(m<cp\)、\(D<Q\) 给 \(nA\ll Qp\)，所以 \(n\ll Qp\)；这个上界只用于保证下文除数函数的自变量为 \(p^{O(1)}\)。

固定 \(n,A,c,d\) 后，整数关系强制
\[
Dm=cAn-d.
\tag{7}
\]
每个允许的 \(D\) 是右端的正因子，\(m\) 随 \(D\) 唯一确定。标准除数界给这类 \(D\) 至多
\(\tau(cAn-d)\ll_\varepsilon p^\varepsilon\) 个；在有效范围 \(cAn-d= Dm>0\) 且 \(cAn\ll p^{O(1)}\)。
由 829 式 (11)、\(F_Q(m)\le\log m\ll H\)、\(\Lambda(n)\ll H\) 与
\(Dm=cAn-d\asymp cAn\)，每条边的绝对交叉权至多
\[
\ll\frac{H^2}{cAn}.
\tag{8}
\]
因此，只对 \(n=\ell^j,\ j\ge2\) 求和，并放松所有其余限制，有
\[
|E_{\rm near}^{\rm pp}|
\ll_\varepsilon
H^2p^\varepsilon L
\left(\sum_{A<Q}\frac1A\right)
\left(\sum_{c\le B}\frac1c\right)
\sum_{\substack{n\gg p^{\kappa-11/12}\\n=\ell^j,\ j\ge2}}\frac1n.
\tag{9}
\]
高次素数幂的初等计数界
\(\#\{n\le T:n=\ell^j,\ j\ge2\}\ll\sqrt T\log(2T)\)
经分部求和给末和
\(\ll H p^{-(\kappa-11/12)/2}\)。
前两个调和和各为 \(O(H)\)，且 \(L=p^{23/12-\kappa}\)，于是 (9) 恰给
\[
|E_{\rm near}^{\rm pp}|
\ll_{\kappa,\varepsilon}
H^5p^{23/12-\kappa-(\kappa-11/12)/2+\varepsilon}
=H^5p^{19/8-3\kappa/2+\varepsilon}.
\]
在 \(\kappa>7/4\) 时该幂指数严格小于 \(-1/4+\varepsilon\)，故 (2) 成立。

## 素数门的互异性与单位缺陷化简

对任意整数缺陷 \(d\)，置 \(M=(Dm+d)/c\)。恒等式
\[
cM-Dm=d
\tag{10}
\]
逐个给出
\[
\gcd(D,c)\mid d,\qquad
\gcd(m,M)\mid d,\qquad
\gcd(M,D)\mid d,\qquad
\gcd(m,c)\mid d.
\tag{11}
\]
在 (1) 范围，(5) 给 \(|d|\ll p^{23/12-\kappa}\ll p^{1/6}\)。
素数 forcing 中 \(m=hr,\ h<Q\) 使
\(r>m/Q\ge p/Q\gg p^{1/3}\)；素数移位 \(q=n\) 由 (6) 满足
\(q\gg p^{\kappa-11/12}\gg p^{5/6}\)。
因 \(q\mid M\)，(11) 与 \(q>|d|\) 给 \(q\nmid m\)，故 \(q\ne r\)。展开 \(F_Q(m)\) 的每个素数 \(r\)，再取 \(n=q\)，把 829 式 (7a) 的分母用
\(qAc=Dhr+d\) 化为 \(\sqrt{Dhr(Dhr+d)}\)，便是 (3)。

进一步，(6) 与 \(D<Q\) 给 \(q>D\)，故 \(q\nmid D\)。因此
\((M/q,D)=(M,D)\)：源条件 \((A,D)=1\) 对给定 \(D,c,m,d\) 的每个允许素数 \(q\mid M\) 同时成立或同时失败。由 (5) 和 \(m<Bp\) 还有
\(D\gg |d|p^{\kappa-5/4}>|d|\)；若 \(A=D\)，则 \(D\mid M\)，由 (11) 会推出 \(D\mid d\)，矛盾。故 \(A\ne D\) 自动成立。对所有 \(q\mid M\) 且 \(M/q<Q\) 求和正是 \(F_Q(M)\)，证明 (3a)。

当 \(d=\pm1\) 时，(11) 中四对整数均互素；尤其
\((D,c)=(m,M)=(M,D)=1\)。因此 (10) 保证 \((m,c)=1\)，而
\(A=M/q\) 自动与 \(D\) 互素。有效边的 \(D\gg p^{\kappa-5/4}>1\)，所以 \(A=D\) 也不可能。源限制只剩 \(M/q<Q\)，其素数和正是 \(F_Q(M)\)。这逐项证明 (4)。\(\square\)

## 边界

(2) 是非精确**交叉**上的绝对界；819 的精确高次源 forcing 误差仍按原证明处理，目标--目标异臂高次素数幂由 828 在 \(\kappa>7/4\) 的计数支付。[scratch 831](831-dipole-defect-lattice-has-an-exact-positive-fractional-part-bias-candidate.md) 计算了无权完整缺陷格的余量，说明核积分为零不等于整数格逐点抵消。(3)--(4) 没有估计剩余双素数和的符号，也没有控制完整旧奇算子的 Schur 补。它们不证明或反驳全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。

一个直接的素数等差数列接口也超出平方根模数范围：在 \(d=\pm1\) 时，固定 \(m,A,c,d\) 会把 \(q\) 限制为模 \(m\) 的一个类，因为 \(qAc\equiv d\pmod m\) 且 \((Ac,m)=1\)。有效边有 \(q\ll Qp=p^{5/3+o(1)}\)，而 \(m\ge p\)，故 \(m/\sqrt q\gg p^{1/6-o(1)}\)。这只排除逐个固定模 \(m\) 直接套用平方根水平的平均定理；仍可能有利用 \(m,A,c,D,d\) 联合平均的办法。
