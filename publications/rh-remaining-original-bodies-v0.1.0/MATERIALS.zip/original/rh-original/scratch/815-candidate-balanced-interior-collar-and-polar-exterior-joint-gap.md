# 候选：渐近全部平衡内区常值槽可与 polar 外区联合支付真实算术交叉

日期：2026-09-30。证明草稿，尚待独立复核。依赖 [note 809](../notes/809-polar-heavy-farey-exterior-and-small-numerator-slots-have-growing-gaps.md) 的全小分子内区谱隙、[note 810](../notes/810-three-growing-gap-blocks-cover-all-farey-constant-slots.md) 的 polar 外区谱隙、[note 803](../notes/803-farey-exterior-block-has-logarithmic-gap-and-natural-schur-direction-stays-positive.md) 的有序算术图与跨指数零点余项、[note 811](../notes/811-nonarithmetic-cross-blocks-are-paid-in-full-farey-constant-slots.md) 的非算术交叉界，以及 [note 806](../notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md) 的全阶跃混合界。

## 命题

沿奇素数 \(p\to\infty\)，记 \(P=p-1\)、\(H=\log p\)、\(Q=\lfloor P/H\rfloor\)。固定 \(r>2/(1-3/\pi^2)\)，令 \(\gamma_r=1-2/r-3/\pi^2>0\)。任取实数列 \(A_p\to\infty\) 满足 \(A_p=o((\log H)^2)\)，并置 \(T_p=\lceil Q/A_p\rceil\)。令
\[
I^{\rm bal}_{T_p,Q}=\operatorname{span}\{\psi_{a/b}:T_p\le b<a\le Q,\ (a,b)=1\},
\qquad
E_r=\operatorname{span}\{\psi_{a/b}:a>Q,\ a/b>r\}.
\tag{1}
\]
则两空间正交，且**保留真实带符号素数幂交叉**的旧奇 Weil 主压缩满足
\[
\boxed{\quad
P_{I^{\rm bal}_{T_p,Q}\oplus E_r}A_{p^2,-}P_{I^{\rm bal}_{T_p,Q}\oplus E_r}
\succeq(2-o_{r,A_\bullet}(1))\log H\,I.
\quad}\tag{2}
\]
它与全部 Farey 阶跃偶极 \(W_p\) 联合后仍有
\[
P_{W_p\oplus I^{\rm bal}_{T_p,Q}\oplus E_r}A_{p^2,-}P_{W_p\oplus I^{\rm bal}_{T_p,Q}\oplus E_r}
\succeq(c_0-o(1))I,
\qquad c_0=1+\gamma_E-\log\pi+\delta_0>0.
\tag{3}
\]
若 \(I_Q=\operatorname{span}\{\psi_{a/b}:a\le Q\}\)，则
\[
\frac{\dim I^{\rm bal}_{T_p,Q}}{\dim I_Q}\longrightarrow1.
\tag{4}
\]
例如 \(A_p=\log H\) 时保留 \(b\ge Q/\log H\) 的全部内区斜率，不限制 \(a/b\) 为固定常数。

## 真实算术交叉的普通矩形 Schur 界

沿 note 813 的反对称有序对嵌入 \(J_-\) 与 note 803 的非负有序算术图 \(B_{\rm ar}\)，有 \(J_-^*B_{\rm ar}J_-=C^-=C_{\parallel}-C_{\times}\)。内区 (1) 的两个有序端点都在 \(M=\{T_p,\ldots,Q\}\)，外区有序端点至少一个坐标在 \(U=\{Q+1,\ldots,P\}\)。令 \(K(m,n)=c_{m/n}+c_{n/m}\)，其中 \(c_t=\Lambda(t)/\sqrt t\) 于整数素数幂，其他为零，并置 \(\kappa=\|K_{U,M}\|\)。从 \(M\times M\) 出发的单坐标边只进入正交的 \((U\times M)\sqcup(M\times U)\)；跨指数零点余项的全图范数为 \(O(\log H)\)。因此如 note 813 式 (7)，
\[
\|C^-_{E_r,I^{\rm bal}_{T_p,Q}}\|\le\sqrt2\,\kappa+O(\log H).
\tag{5}
\]

用标准素数幂 Mertens 界 \(\sum_{n\le z}\Lambda(n)/n=\log z+O(1)\) 分部求和，得到对所有 \(z\ge1\) 的 \(\sum_{n\le z}\Lambda(n)/\sqrt n\ll\sqrt z\)。对每个输出行 \(u\in U\)，只有 \(u=mn\) 的素数幂边。把 \(n\) 在 \(H\) 处分开，并用 \(\sum_{n\mid u}\Lambda(n)=\log u\le H\)，得到
\[
\sum_{m\in M}K(u,m)
\le\sum_{n\le H}\frac{\Lambda(n)}{\sqrt n}
+H^{-1/2}\sum_{n\mid u}\Lambda(n)
\ll\sqrt H.
\tag{6}
\]
对每个输入列 \(m\in M\)，只有 \(u=mn\in U\)，且 \(P/m\le P/T_p\le(P/Q)A_p\ll HA_p\)。因此
\[
\sum_{u\in U}K(u,m)
\le\sum_{n\le P/m}\frac{\Lambda(n)}{\sqrt n}
\ll\sqrt{HA_p}.
\tag{7}
\]
矩形普通 Schur 检验给
\[
\kappa^2\ll H\sqrt{A_p},
\qquad
\|C^-_{E_r,I^{\rm bal}_{T_p,Q}}\|
\ll\sqrt H\,A_p^{1/4}+\log H.
\tag{8}
\]

## 联合谱隙与维数

note 809 式 (4a)、(13) 在整个 \(I_Q\) 上给 \(g_I=2\log H-O(1)\) 的对角下界，故对子空间 \(I^{\rm bal}_{T_p,Q}\) 也成立。note 810 在 \(E_r\) 上给 \(g_E=\gamma_rH-O_r(\sqrt H\log H)=(\gamma_r-o_r(1))H\)。两式都在完整联合空间上一次丢去正的异臂 Archimedean 矩阵。

把内区 (1) 按 \(x\le r\)、\(x>r\) 拆开。note 811 式 (7) 与 (11) 分别给两个部分到 \(E_r\) 的同臂 Archimedean 核交叉范数 \(O_r(1)\)。note 809 式 (10) 给 \(\|h_{I_Q}\|^2=O(H^{-1})\)，而 note 810 给 \(\|h_{E_r}\|^2=O(H)\)，所以 polar 交叉也为 \(O_r(1)\)。结合 (8)，全局丢去正矩阵后的剩余交叉 \(X\) 满足
\[
\|X\|\ll_r\sqrt H\,A_p^{1/4}+\log H+1,
\qquad
\frac{\|X\|^2}{g_E-g_I}\ll_r\sqrt{A_p}+1=o(\log H).
\tag{9}
\]
对任意两块向量取范数后，下界是标量矩阵 \(\begin{psmallmatrix}g_I&-\|X\|\\-\|X\|&g_E\end{psmallmatrix}\) 的二次型。因 \(g_E>g_I\)，其最低特征值至少为 \(g_I-\|X\|^2/(g_E-g_I)=(2-o_{r,A_\bullet}(1))\log H\)，证明 (2)。note 806 的全常值槽与 \(W_p\) 混合界为 \(O(1)\)，note 804 的 \(W_p\) 谱隙为 \((c_0-o(1))I\)；(2) 的增长谱隙使阶跃 Schur 损失趋零，证明 (3)。

最后 note 809 给 \(\dim I_Q\asymp Q^2\)，而被 (1) 遗漏的内区槽数不超过 \(QT_p=O(Q^2/A_p+Q)\)。因 \(A_p\to\infty\)、\(Q\to\infty\)，遗漏比例趋零，证明 (4)。\(\square\)

## 边界

式 (4) 是**内区自身**的槽数比例，不表示已经覆盖全 Farey 常值槽。尚未合并的内区小分母尾 \(b<T_p\)、外区 \(a>Q,\ a/b\le r\)、剩余常值槽交叉、非恒定槽轮廓与无限维补空间均未控制；因此 (2)--(3) 不推出全尺度局部 Weil 正性或 RH。moving-\(N\) Möbius signed covariance 仍是独立算术门。
