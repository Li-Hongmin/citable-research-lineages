# 三素数有理偶极的第三层补反馈候选下界：\(48/127\)

日期：2026-09-29。依赖 [scratch 793](793-prime-product-ratio-affine-profile-feedback-candidate.md) 的双臂偶极、完整旧奇算子分解和前两层算术父边。这里仍是待异源复核的条件性结果；不判定 RH。

## 命题

沿奇素数 \(p\to\infty\)，令 \(k=p^2\)、\(L=\log k\)，\(P_p\) 投影到真实整数奇半槽 \(e_m\)、\(2\le m\le p\) 的张成空间，\(Q_p=I-P_p\)。若完整旧奇算子 \(A_{k,-}\succeq a_k I\)、\(a_k>0\)，则对每个 \(\eta>0\)，所有充分大的此类端点满足
\[
\boxed{
\left\langle Q_pA_{k,-}e_p,
(Q_pA_{k,-}Q_p)^{-1}Q_pA_{k,-}e_p\right\rangle
\ge\left(\frac{48}{127}-\eta\right)L.}
\tag{1}
\]
这里的逆按闭形式压缩理解。式 (1) 改进 scratch 793 的常值轮廓 \(6/17\) 和仿射轮廓 \(24010/67767\)；仍未达到根对角的 \((1+o(1))L\)。

## 三层有理槽与整槽判据

固定 \(0<\beta<1\)，置 \(P=p^\beta\)，\(\mathcal P=\{q\le P:q\text{ 素数}\}\)。沿 scratch 793 置
\[
\Delta=\tfrac12\log(1+p^{-2}),\quad
\varphi_z=(2\Delta)^{-1/2}
\bigl(1_{(\log z-\Delta,\log z)}-1_{(\log z,\log z+\Delta)}\bigr),\quad
w_x=\frac{\varphi_{px}+\varphi_{p/x}}{\sqrt2}\quad(x>0,\ x\ne1).
\tag{2}
\]
由于 \(w_x=w_{1/x}\)，下述第三层无需区分 \(qr/s\) 是否大于一：
\[
\mathcal X_1=\{q:q\in\mathcal P\},\quad
\mathcal X_-=\{q/r:q,r\in\mathcal P,\ r<q\},\quad
\mathcal X_+=\{qr:q,r\in\mathcal P,\ q<r,\ qr<p\},
\tag{3}
\]
\[
\mathcal X_3=\left\{\max\left(\frac{qr}{s},\frac{s}{qr}\right):
q<r,\ q,r,s\in\mathcal P\text{ 互异},\ qr<p\right\}.
\tag{4}
\]
在 (3)--(4) 中所有 \(x\) 都可写为既约 \(a/b>1\)，满足 \(a<p\)、\(b\le P\)：若 \(qr/s>1\)，分母是 \(s\le P\)；若 \(s/qr>1\)，则 \(qr<s\le P\)，分母是 \(qr<P\)。分子小于 \(p\)。唯一分解保证三个层的指标互不重合，第三层的 \((\{q,r\},s)\) 参数也不重复。

每个 \(w_x\) 的两个中心处于旧物理区间内部且相互分离。不同 \(x=a/b,y=c/d\) 的同臂中心满足
\(|\log(x/y)|=|\log(ad/bc)|\gg1/(pP)\)，因为 \(ad,bc<pP\) 且非零整数差至少一。异臂中心的距离为 \(\log(xy)\gg1/P\)，因为每个 \(x\ge1+1/P\)。于是 (3)--(4) 中全部 \(w_x\) 两两正交。

低整数 \(e_m\)（\(2\le m\le p\)）的中心是 \(m,p^2/m\)。将它们分别与 \(pa/b,pb/a\) 比较，四种精确重合只产生两个整数方程 \(ma=pb\) 或 \(mb=pa\)。由于 \(a,b<p\) 且 \(p\) 是素数，两个方程都迫使 \(p\mid m\)。限制 \(m\le p\) 遂给 \(m=p\)，继而 \(a=b\)，与 \(x>1\) 矛盾。不重合时，可能接近的两种配对通过这两个方程的非零整数差给出至少 \(c/(pP)\) 的对数间距；其余配对由 \(x\ge1+1/P\) 分离。故 \(w_x\perp e_m\)，这些偶极全属 \(Q_pH_k^-\)。

对任意两个参与的物理中心 \(z,z'\)，比值 \(z/z'=A/B\) 可取 \(A,B<p^2\)，包括两臂中心交叉，因为每个 \(a,b<p\)。沿原始约定 \(T_sf(t)=f(st)\)，若 \(T_s^*\varphi_z\) 与 \(\varphi_{z'}\) 相交，则
\[
|\log(sA/B)|<2\Delta=\log(1+p^{-2})
\quad\Longrightarrow\quad |sA-B|<B/p^2<1.
\tag{5}
\]
故 \(sz=z'\)，重合时是完整同向偶极且内积为正。全部算术矩阵元在这些非负系数节点间均非正。

更精确地，定义 \(c_t=\Lambda(t)/\sqrt t\) 当 \(t\ge2\) 为整数素数幂，其他正有理数处令 \(c_t=0\)。对这里任意非根节点 \(x,y>1\)，四个物理中心的同臂与交叉臂整槽配对给出精确公式
\[
\boxed{\langle w_x,\mathcal R_kw_y\rangle
=-c_{x/y}-c_{y/x}-c_{xy}.}
\tag{5a}
\]
该式也适用于 \(x=y\)：若 \(x^2\) 是素数幂，它保留 \(-c_{x^2}\) 自环。根 \(e_p\) 的归一化不同，不纳入 (5a)。

## 第三层的三个父边

令 \(c_n=\Lambda(n)/\sqrt n\)，\(\mathcal R_k=-\sum_{n\text{ 素数幂}}c_n(T_n+T_n^*)\)。对 \(q<r\)、\(s\notin\{q,r\}\)、\(qr<p\)，第三层节点 \(w_{qr/s}\) 有三条完整平移父边：
\[
\boxed{
\langle w_{qr/s},\mathcal R_kw_{q/s}\rangle=-c_r,
\qquad
\langle w_{qr/s},\mathcal R_kw_{r/s}\rangle=-c_q,
\qquad
\langle w_{qr/s},\mathcal R_kw_{qr}\rangle=-c_s.}
\tag{6}
\]
这里 \(w_{q/s}=w_{s/q}\) 若 \(q<s\)；另外两个比值同理。式 (6) 可直接从指数向量看出：\(qr/s=(q/s)r=(r/s)q=(qr)/s\)。无论某个比值是否跨过 \(1\)，双臂中的两次半权整槽配对合为 \(-c_r,-c_q,-c_s\)；若用取倒数表示，乘法关系变为 \(xy=n\)，仍由两次交叉臂配对给出相同系数。互异素数又排除了这些父子对上的第二条素数幂边。

## 试探向量与能量

置
\[
S=\sum_{q\in\mathcal P}c_q^2,
\quad U_-=\sum_{r<q\in\mathcal P}c_q^2c_r^2,
\quad U_+=\sum_{q<r\in\mathcal P,\ qr<p}c_q^2c_r^2,
\quad U=U_-+U_+,
\tag{7}
\]
\[
V=\sum_{\substack{q<r,\ q,r\in\mathcal P\\qr<p}}
\ \sum_{s\in\mathcal P\setminus\{q,r\}}
c_q^2c_r^2c_s^2.
\tag{8}
\]
取前两层常值轮廓及第三层最小对角能量响应
\[
\begin{aligned}
t={}&\sum_{q\in\mathcal P}c_qw_q
+\frac2L\sum_{r<q\in\mathcal P}c_qc_rw_{q/r}
+\frac2L\sum_{q<r\in\mathcal P,\ qr<p}c_qc_rw_{qr}\\
&+\frac6{L^2}
\sum_{\substack{q<r,\ q,r\in\mathcal P\\qr<p}}
\ \sum_{s\in\mathcal P\setminus\{q,r\}}
c_qc_rc_s w_{qr/s}.
\end{aligned}
\tag{9}
\]
其范数平方精确为 \(S+4U/L^2+36V/L^4\)。scratch 793 的前两层父边给出 \(-8U/L\) 的算术能量；每个第三层节点的三条父边使其父节点总驱动为 \(-6c_qc_rc_s/L\)。连同第三层系数 \(6c_qc_rc_s/L^2\)，算术交叉再给 \(-72V/L^3\)。其余所有算术边因系数非负及 (5) 只能降低能量，故
\[
\mathcal R_k[t]\le-\frac{8U}{L}-\frac{72V}{L^3}.
\tag{10}
\]

每个 \(w_x\) 的 Archimedean 自能量至多 \(L+C\)：两个归一化半槽的位置项精确抵消，邻接半槽只产生 \(O(1)\)，而一个 \(w_x\) 的两物理中心相距至少 \(c/P\)。任意不同中心在对数线上相隔 \(c/(pP)\)，数目至多 \(O(pP)\)。由非对角核 \(K(v)\ll1/v\) 与排序后的 Schur 行和，全部非对角算子范数为 \(O(\Delta pP\log(pP))=o_\beta(1)\)。polar 二次型非正。因此
\[
\begin{aligned}
A_{k,-}[t]
&\le(L+C)\left(S+\frac{4U}{L^2}+\frac{36V}{L^4}\right)
-\frac{8U}{L}-\frac{72V}{L^3}\\
&=LS-\frac{4U}{L}-\frac{36V}{L^3}+O_\beta(L^2).
\end{aligned}
\tag{11}
\]

根 \(e_p\) 的算术像在此节点族中仍只落在第一层：\((T_q+T_q^*)e_p=\sqrt2w_q\)，第三层既非整数也非整数倒数。所有非根中心与根至少相距 \(c/P\)，候选节点数至多 \(O(pP)\)；Archimedean 根列范数为 \(O(\Delta P\sqrt{pP})=o_\beta(1)\)。note 788 的 \(\langle s_k,e_p\rangle=O(p^{-3})\)、\(\|s_k\|=O(p^{1/2})\) 同样使 polar 根列为 \(o(1)\)。由 \(\|t\|=O_\beta(L)\)，
\[
\langle t,A_{k,-}e_p\rangle=-\sqrt2S+o(1).
\tag{12}
\]
所有参与的阶跃偶极具有有限的对数形式能量，且 \(e_p\in D(A_{k,-})\)；在假设的严格正端点可用闭形式逆度量变分。

## 主项与 \(48/127\)

由素数定理和 scratch 793 的二维 Stieltjes 极限，先固定 \(\beta<1\)、令 \(p\to\infty\)，再令 \(\beta\uparrow1\)，有
\[
\frac{S}{L^2}\longrightarrow\frac18,
\qquad \frac{U_-}{L^4}\longrightarrow\frac1{128},
\qquad \frac{U_+}{L^4}\longrightarrow\frac1{768},
\qquad \frac{U}{L^4}\longrightarrow\frac7{768}.
\tag{13}
\]
更简单地，(8) 与 (7) 满足
\[
V=U_+S-
\sum_{\substack{q<r,\ q,r\in\mathcal P\\qr<p}}
c_q^2c_r^2(c_q^2+c_r^2).
\tag{14}
\]
由于 \(\sum_qc_q^4<\infty\)，末项为 \(O(S)=O(L^2)\)。因此
\[
\frac{V}{L^6}\longrightarrow
\frac1{768}\cdot\frac18=\frac1{6144}.
\tag{15}
\]
式 (11) 的主系数在 \(\beta\uparrow1\) 时为
\[
\frac18-4\cdot\frac7{768}-36\cdot\frac1{6144}
=\frac{127}{1536}>0.
\tag{16}
\]
在任一充分接近一的固定 \(\beta\) 上，这个系数仍严格正。根配对平方的主系数是 \(2(1/8)^2=1/32\)。逆度量变分、再按上述顺序取极限，给出
\[
\frac{1/32}{127/1536}=\frac{48}{127},
\]
证明候选命题。\(\square\)

## 边界

第三层把有理指数空间中的三条真实素数平移父边同时用于变分；对完整旧核严格正端点，反馈下界由前两层常值轮廓的 \(6/17\) 提高到 \(48/127\)。该条件性下界不控制完整逆响应上界，也不支付根的全部对角。全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 和 RH 均未判定。
