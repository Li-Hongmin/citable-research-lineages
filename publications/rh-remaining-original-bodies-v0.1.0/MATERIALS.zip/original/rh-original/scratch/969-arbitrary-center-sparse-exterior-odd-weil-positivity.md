# 任意槽中心的稀疏外臂上，完整奇 Weil 形式具有对数谱隙

日期：2026-10-02。本草稿已在异源复核后晋级为 [note 852](../notes/852-arbitrary-center-sparse-local-weil-positivity.md)；以下保留初稿供追溯，数学结论以 note 852 为准。

## 定理

令奇素数 $p\to\infty$，$H=\log p$，$L=\log(1+p^{-2})$。在开带

\[
B_p=2H+\bigl(\log(1/8),\log(1/2)\bigr)\subset(H,2H)
\]

内任取 $M$ 个两两不交的开区间 $I_1,\ldots,I_M$，每段长度不超过 $L$；它们的中心可为任意实数。置 $E=\bigcup_j I_j$，$s=|E|\le ML$，并定义奇等距嵌入

\[
(\mathcal Jg)(u)=
\begin{cases}
g(u)/\sqrt2,&u\in E,\\
-g(2H-u)/\sqrt2,&u\in 2H-E,\\
0,&\text{其余},
\end{cases}\qquad g\in L^2(E).
\tag{1}
\]

存在绝对常数 $C$，使对充分大 $p$、每个 $1\le M\le p$ 及每个 $\mathcal Jg$ 属于旧 Weil 闭形式域的轮廓，一致有

\[
\boxed{\quad
A_{p^2,-}[\mathcal Jg]
\ge\left(1-\frac{16M}{p}\right)H\|g\|_2^2
-C\left(1+\frac Mp\right)\|g\|_2^2.
\quad}\tag{2}
\]

更精细地，令 $g_j=g\mathbf1_{I_j}$。不限制 $M$ 时也有支撑测度与有效参与数形式

\[
\boxed{\quad
A_{p^2,-}[\mathcal Jg]
\ge\left(\log\frac1s-C-\frac{ps}{2}\right)\|g\|_2^2
-\frac{16H}{p}\left(\sum_{j=1}^M\|g_j\|_2\right)^2.
\quad}\tag{2a}
\]

特别是 $M\le p$ 时，(2a) 还给比 (2) 尖锐的主项 $2H-\log M$：
$A_{p^2,-}[\mathcal Jg]\ge(2H-\log M-16MH/p-C(1+M/p))\|g\|_2^2$。

特别地，若 $M\le p/32$，则充分大 $p$ 时

\[
\boxed{\qquad A_{p^2,-}[\mathcal Jg]\ge\frac13H\|g\|_2^2.\qquad}\tag{3}
\]

由此，若奇 Weil 形式在这种任意中心的槽族上有非正轮廓，其非零槽数必须超过 $p/32$。式 (3) 只约束该压缩空间，未控制它与整个奇空间的 Schur 交叉。

## 完整形式与 Archimedean 下界

把 $f=\mathcal Jg$ 从 $u\in(0,2H)$ 平移为 $y=u-H\in(-H,H)$，并于全实线零延拓。由 note 004 与 note 007，在闭形式域内精确有

\[
\begin{aligned}
A_{p^2,-}[f]={}&
\int_{\mathbb R}\log|\xi|\,|\widehat f(\xi)|^2\frac{d\xi}{2\pi}
-\log(2\pi)\|f\|_2^2\\
&-\sum_{m\ge2}\frac{\Lambda(m)}{\sqrt m}
\langle f,(T_m+T_m^*)f\rangle
-\iint r_1''(y-z)f(z)\overline{f(y)}\,dz\,dy
-2|\langle\sinh(y/2),f\rangle|^2,
\end{aligned}\tag{4}
\]

其中 $T_m$ 是零延拓后的 $\log m$ 平移，$\Lambda$ 只在素数幂非零，且

\[
r_1''(t)=\frac{e^{-|t|/2}}{1-e^{-2|t|}}-\frac1{2|t|}\quad(t\ne0).
\tag{5}
\]

式 (5) 在零点有有限极限，在无穷处趋零，因此 $C_r:=\sup_{\mathbb R}|r_1''|<\infty$。$f$ 的总支撑测度为 $2s$。由 Cauchy--Schwarz，$|\widehat f(\xi)|^2\le2s\|f\|_2^2$。对任意 $T>0$，Plancherel 与 $\int_{-T}^T\log(T/|\xi|)\,d\xi=2T$ 给出

\[
\int\log|\xi|\,|\widehat f(\xi)|^2\frac{d\xi}{2\pi}
\ge\left(\log T-\frac{2sT}{\pi}\right)\|f\|_2^2.
\tag{6}
\]

取 $T=p$、$\|f\|_2=\|g\|_2$，主部至少为 $(H-2ps/\pi)\|g\|_2^2$。另取 $T=1/s$，主部至少为 $(\log(1/s)-2/\pi)\|g\|_2^2$。式 (5) 的项又满足

\[
\left|\iint r_1''(y-z)f(z)\overline{f(y)}\,dz\,dy\right|
\le C_r\|f\|_1^2\le2C_rs\|g\|_2^2.
\tag{7}
\]

由于 $L\le p^{-2}$ 且 $M\le p$，(6)--(7) 连同 $-\log(2\pi)$ 给出整个非算术、非 polar 部分的统一下界 $(H-C_1)\|g\|_2^2$。这里直接使用完整 Fourier 主部；即使槽几乎相接，也没有逐槽交叉核的间距假设。

## 算术位移：同臂与异臂

同一臂的两点 $u,v\in B_p$ 满足 $e^{|u-v|}<4$，所以发生同臂重叠的整数平移只能有 $2\le m\le4$。平移在 $L^2$ 上为收缩，故同臂算术部分的绝对值不超过

\[
2\sum_{2\le m\le4}\frac{\Lambda(m)}{\sqrt m}\,\|g\|_2^2=O(1)\|g\|_2^2.
\tag{8}
\]

异臂位移在 (1) 的上臂坐标中是带正号的反射。对素数幂 $m$ 令

\[
(J_mg)(u)=\mathbf1_E(2H+\log m-u)g(2H+\log m-u).
\]

与 note 828 的归一化一致，(4) 的异臂算术部分恰为 $\sum_m(\Lambda(m)/\sqrt m)\langle g,J_mg\rangle$。每个 $J_m$ 是部分反射，范数至多一。若它从 $I_j$ 映到 $I_i$，则存在 $u\in I_i,v\in I_j$ 满足 $m=e^{u+v-2H}$，所以

\[
\frac{p^2}{64}<m<\frac{p^2}{4}.
\tag{9}
\]

对固定的有序槽对 $(i,j)$，允许的 $m$ 落在 $\exp(I_i+I_j-2H)$。此区间的对数长度至多 $2L$，上端点至多 $p^2/4$，故其普通长度严格小于

\[
\frac{p^2}{4}(1-e^{-2L})<\frac12.
\tag{10}
\]

于是每个槽对至多有**一个整数**位移，包含所有可能的素数幂。由 (9)，这个位移的权满足

\[
\frac{\Lambda(m)}{\sqrt m}\le\frac{\log m}{\sqrt m}\le\frac{16H}{p}.
\tag{11}
\]

在分块 $L^2(E)=\bigoplus_jL^2(I_j)$ 中，每块的范数至多 $16H/p$。逐块估计二次型给出更细的下界 $-(16H/p)(\sum_j\|g_j\|_2)^2$；对自伴块矩阵用绝对行和 Schur 界，则异臂算术算子的范数不超过 $16MH/p$。同 (8) 合并，

\[
\text{(4) 中算术部分}\ge
-\left(\frac{16MH}{p}+C_2\right)\|g\|_2^2.
\tag{12}
\]

## polar 与闭形式域

在 $E$ 上写 $e^{u-2H}=c\in(1/8,1/2)$。对充分大 $p$，

\[
\left|\sinh\frac{u-H}{2}\right|^2
=\frac14\bigl(pc+(pc)^{-1}-2\bigr)\le\frac p8.
\]

奇反射后，$\|\sinh((u-H)/2)\mathbf1_{E\cup(2H-E)}\|_2^2\le ps/4$。Cauchy--Schwarz 因而给

\[
-2|\langle\sinh(y/2),f\rangle|^2
\ge-\frac{ps}{2}\|g\|_2^2.
\tag{13}
\]

把 (6)--(7)、(12)--(13) 代入精确式 (4)，得到更明确的统一下界

\[
A_{p^2,-}[\mathcal Jg]
\ge\left[H-\frac{16MH}{p}
-\log(2\pi)-C_2
-\frac{2ps}{\pi}-2C_rs-\frac{ps}{2}\right]\|g\|_2^2.
\tag{14}
\]

$s\le ML\le M/p^2$ 推出 (2)，进而推出 (3)。式 (4) 已在 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md) 从光滑测试函数延拓到完整闭形式域；(6) 对任何零延拓 $L^2$ 函数成立，(7)、(12)、(13) 是有界形式估计。因此 (14) 直接适用于 $\mathcal Jg\in D(Q_W^H)$，无须假定每个槽内轮廓光滑，也无须证明逐槽光滑函数是压缩域的核心。$\square$

为得 (2a)，在 (6) 中改取 $T=1/s$，在算术估计中保留逐块的 $\ell^1$ 形式，并用 (13)。因 $s\le|B_p|=\log4$，(7) 至多损失绝对常数；其余常数项也都与 $p,M,E$ 无关。当 $M\le p$ 时，$s\le M/p^2$、$\log(1/s)\ge2H-\log M$，且 $(\sum_j\|g_j\|_2)^2\le M\|g\|_2^2$，得到上述较尖锐的主项。若 $s\le1/p$ 且 $\|g\|_2=1$、$A_{p^2,-}[\mathcal Jg]\le0$，(2a) 还迫使

\[
\left(\sum_j\|g_j\|_2\right)^2
\ge \left(\frac1{16}-O(H^{-1})\right)p.
\tag{15}
\]

式 (15) 是对给定区间分解的有效槽参与数下界；将一个槽人为细分会改变该数，因此它的几何解释必须连同区间分解一起陈述。

## 范围

本定理严格扩展 scratch 884 的几何范围：槽中心可任意靠近，且不要求有理、互素或任何 Farey 间距。证明支付的是至多 $O(p)$ 个槽的全轮廓压缩；当槽数达到 $p^2$ 量级时，逐槽素数行界不够，不能推出全尺度局部 Weil 正性或 RH。moving-$N$ Möbius signed covariance 仍是独立的真实算术门。

同一证明还有固定比例带的形式。取固定 $0<\alpha<\beta<1$、$\kappa>0$，且 $2\kappa\beta^2<1$；把 $B_p$ 换成 $2H+\log(\alpha,\beta)$，把单槽长度上限换成 $\log(1+\kappa p^{-2})$。若 $M\le\eta p$ 且固定 $0<\eta<\alpha/2$，则对全部相应有限能量奇轮廓一致有

\[
A_{p^2,-}[\mathcal Jg]\ge
\left(1-\frac{2\eta}{\alpha}-o(1)\right)H\|g\|_2^2>0.
\]

事实上，单对槽的 $m$ 窗长度至多 $(\beta^2p^2)(1-e^{-2\log(1+\kappa p^{-2})})=2\kappa\beta^2+o(1)<1$；异臂权至多 $(2/\alpha+o(1))H/p$。同臂只涉及 $m\le\beta/\alpha+o(1)$ 的有限个整数，polar 为 $O_{\alpha,\beta,\kappa,\eta}(1)$，而总支撑测度 $O(1/p)$ 给 Fourier 主部 $H-O(1)$。这逐项证明所述推广。
