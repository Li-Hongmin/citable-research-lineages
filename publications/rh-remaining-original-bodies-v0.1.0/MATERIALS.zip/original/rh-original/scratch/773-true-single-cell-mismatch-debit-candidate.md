# 真实单胞 mismatch dual debit 的全 parent 次主项：待独立复核

日期：2026-09-29。依赖 note 771 的小测度单胞下界和 note 772 的增长 parent 矩阵渐近。这里只研究同一个单胞形式 \(\mathfrak b\) 的 source-ground 短算子；不识别完整 Weil harmonic graph 的物理扣款。

## 命题

沿用 note 772 的 \(\mathcal N_{k,m},D_{k,m}^{\rm src},\lambda_m,\widehat r_m,F_m,b_m\)，把槽内正交方向固定为零或继续短化均可。令 \(Q_m=I-|\widehat r_m\rangle\langle\widehat r_m|\)、\(\lambda_m^\perp=Q_m\lambda_m\)、\(V_m=\|\lambda_m^\perp\|^2=F_m-b_m^2\)。定义单胞 mismatch dual debit
\[
\widehat\chi_{k,m}^{\rm src}
=\big\langle\lambda_m^\perp,
 (Q_mD_{k,m}^{\rm src}Q_m|_{\operatorname{ran}Q_m})^{-1}
 \lambda_m^\perp\big\rangle,
\]
并在 \(\dim\operatorname{ran}Q_m=0\) 时置零。则
\[
\boxed{\sum_{m:\mathcal N_{k,m}\ne\varnothing}
\widehat\chi_{k,m}^{\rm src}
=O\!\left(\frac{\log k}{\log\log k}\right)=o(\log k).}
\tag{1}
\]

## 证明

固定 \(A,B>3\)，置 \(m_0=\lceil(\log k)^A\rceil\)、\(m_1=\lfloor k/(\log k)^B\rfloor\)。分三段。

**低 parent：\(m<m_0\)。** 对 \(m\le(\log k)^A\)，置 \(x=k/m\)、\(y=k/(m+1)\)。经典零自由区形式的素数定理
\(\pi(t)=\operatorname{li}(t)+O(t e^{-c(\log t)^{3/5}(\log\log t)^{-1/5}})\)
在这里一致给出
\[
\#\{p:y<p\le x\}\ll\frac{x-y}{\log k}
=\frac{k}{m(m+1)\log k}.
\tag{2}
\]
因为 \(x-y\asymp k/m^2\) 远大于 \(x e^{-c\omega(x)}\)，误差确实一致可吸收。高次素数幂的数目为 \(O(\sqrt k\log k)\)，整除 \(k\) 的素数幂至多 \(O(\log k)\)，都小于 (2) 的右边。因此
\[
M_m=|\mathcal N_{k,m}|\ll\frac{k}{m(m+1)\log k},
\quad
|S_{k,m}|=M_m\frac{w_k}{w_m}
\ll\frac1{m\log k},
\tag{3}
\]
这里用 \(w_k\le1/k\)、\(w_m\ge1/(m+1)\)。note 771 的下界在 \(s=|S|\le C/\log k\) 上一致，故对充分大的 \(k\)
\[
D_{k,m}^{\rm src}\succeq\tfrac12\log\log k\,I,
\qquad
\widehat\chi_{k,m}^{\rm src}\le\frac{2V_m}{\log\log k}.
\tag{4}
\]

为界定 \(\sum_{m<m_0}V_m\)，使用 note 772 的投影恒等式
\[
V_m=\min_c\sum_{n\in\mathcal N_{k,m}}
\frac{(\Lambda(n)-cn)^2}{n}
\]
并取 \(c=T_m/(k/m)\)、\(T_m=\log(k/m)\asymp\log k\)。若 \(p\in\mathcal N_{k,m}\)，由 \(p/(k/m)\in(m/(m+1),1]\) 得
\[
|\Lambda(p)-cp|\ll T_m/m,
\qquad
\sum_{p\in\mathcal N_{k,m}}\frac1p
\ll\frac1{m\log k}
\tag{5}
\]
（第二式由 (2) 及 \(p>k/(m+1)\) 得到）。所以素数部分对 \(V_m\) 的贡献为 \(O(\log k/m^3)\)。对 \(n=p^\ell,\ell\ge2\)，同一测试满足 \(|\Lambda(n)-cn|\ll\log n\)，而
\(\sum_{p,\ell\ge2}(\log p^\ell)^2/p^\ell<\infty\)。从而
\[
\sum_{m<m_0}V_m\ll\log k\sum_{m\ge1}m^{-3}+1\ll\log k.
\tag{6}
\]
由 (4)--(6)，低 parent 的总 debit 为 \(O(\log k/\log\log k)\)。

**中 parent：\(m_0\le m\le m_1\)。** note 772 的矩阵下界给出 \(D_{k,m}^{\rm src}\succeq(1-o(1))L_m I\)，其中 \(L_m=\log(w_m/w_k)\sim T_m\) 一致。该 note 的投影误差估计还给出
\[
\sum_{m_0\le m\le m_1}\frac{V_m}{T_m}=o(1).
\tag{7}
\]
因此这段的 mismatch debit 是 \(o(1)\)。

**高 parent：\(m>m_1\)。** 因 \(m_1\gg\sqrt k\)，每个区间 \((k/(m+1),k/m]\) 的长度小于 \(1\)，含至多一个整数 \(n\)。故 \(Q_m=0\)，这段 debit 恰为零。三段相加证明 (1)。\(\square\)

## 边界

原文粗支付 \(\sum_mV_m/\log2\) 至少由 \(m=1\) 给出 \(\asymp\log k\)；(1) 说明在真实单胞源截口里，若使用精确 mismatch 逆度量，这个粗支付高估一个渐近阶。但 (1) 不控制 aligned 参考扣款，也不推出完整 Weil harmonic graph 或 moving-\(N\) Möbius signed covariance 的上界。
