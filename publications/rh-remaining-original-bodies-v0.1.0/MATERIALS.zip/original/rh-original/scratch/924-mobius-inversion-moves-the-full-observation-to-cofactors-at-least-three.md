# Möbius 反演把真实联合观察精确移到 cofactor 至少为 3 的源

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实系数、[scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的小源 Poisson 支付及 [scratch/864](864-odd-source-kernel-has-an-exact-blind-interval.md) 的 dyadic 消去。这里明确使用真实 $\mu*1=\delta_1$，因此 [scratch/923](923-any-fixed-factor-depth-still-leaves-a-window-only-moving-covariance-countermodel.md) 的非乘法函数不满足本恒等式。结论是精确的源范围压缩，不是 signed covariance 上界；尚未异源复核。

## 精确恒等式

对每个整数 $n>1$，令
\[
c(n)=2\mathbf1_{2\mid n}(\Lambda(n/2)-1)
-4\bigl(\Lambda(n)-1+(\log2)\mu(n)\bigr),
\qquad b(n)=4-2\mathbf1_{2\mid n},                         \tag{1}
\]
并定义固定 cofactor 核
\[
\kappa(1)=\kappa(2)=0,\qquad
\kappa(k)=(-4+2\mathbf1_{2\mid k})\log(k/2)
\quad(k\ge3).                                                \tag{2}
\]
则
\[
\boxed{\quad c(n)=b(n)+\sum_{\substack{d\mid n\\n/d\ge3}}
\mu(d)\kappa(n/d).\quad}                                    \tag{3}
\]
因此在 $M<n<2M$ 的观察窗中，式 (3) 只用 $d\le n/3<2M/3$ 的真实 Möbius 值；当前窗口的 $\mu(n)$ 与所有 cofactor $2$ 的源已被精确消去。核在 $k\ge3$ 严格为负：奇数 $k$ 为 $-4\log(k/2)$，偶数 $k$ 为 $-2\log(k/2)$。

证明只需把 $\Lambda=\mu*\log$ 代入 (1)。因 $n>1$，$\mu*1=\delta_1$ 给
\[
\mu(n)=-\sum_{\substack{d\mid n\\d<n}}\mu(d).              \tag{4}
\]
把 $d<n$ 的项按 $k=n/d\ge2$ 合并：$-4\Lambda(n)$ 给 $-4\log k$，$-4(\log2)\mu(n)$ 经 (4) 给 $+4\log2$，而偶数通道给 $+2\mathbf1_{2\mid k}\log(k/2)$。合计正是 (2)；$k=2$ 时为零。剩余常数是 $b(n)$，证明 (3)。$\square$

独立的 Dirichlet 级数核对是：在 $\Re s>1$，
\[
\sum_{k\ge1}\frac{\kappa(k)}{k^s}
=(4-2^{1-s})\zeta'(s)+4(\log2)(\zeta(s)-1).
\]
把它乘 $1/\zeta(s)$，再加 $b$ 的级数 $(4-2^{1-s})\zeta(s)$，最后把仅在 $n=1$ 的差额 $-4\log2$ 扣除，恰得由 (1) 直接计算的 $c$ 级数 $(4-2^{1-s})(\zeta+\zeta'/\zeta)-4(\log2)/\zeta$。

例如奇素数 $p$ 的式 (3) 只有 $d=1$，给 $c(p)=4-4\log(p/2)$；若 $p$ 为奇素数，$n=2p$ 的 $d=1,2,p$ 三项分别有 cofactor $2p,p,2$，给 $c(2p)=2+2\log p-4\log2$。两式与 note 849 的逐点值相符。

## 频带上只剩 $M/(16H)<d<2M/3$

固定 $\psi\in C_c^3((1,2))$，$\phi(u)=\psi(u)/u$，$M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$。令
\[
\mathcal A_h=\frac1M\sum_{M<m<2M}c(m)\phi(m/M)e(-hm/M),
\quad D=\lfloor M/(16H)\rfloor,                             \tag{5}
\]
\[
\mathcal L_h(d)=\frac1M\sum_{\substack{k\ge3\\M<dk<2M}}
\kappa(k)\phi(dk/M)e(-hdk/M).                               \tag{6}
\]
对 $H/2\le|h|\le4H$，无条件地有
\[
\boxed{\quad
\mathcal A_h=
\sum_{D<d<2M/3}\mu(d)\mathcal L_h(d)
+O_\psi(H^{-3}\log^2M).
\quad}                                                       \tag{7}
\]
对任意有界非负、支撑于此频带的 $w_H(h)=v(h/H)$，误差的带通平方和为
\[
O_{\psi,v}(H^{-5}\log^4M)=o(H^4/M).                       \tag{8}
\]

为证 (7)，把 (3) 代入 (5)。$b(m)$ 是整数格与偶数格上的固定光滑背景，Poisson 求和及 $\phi\in C_c^3$ 使其 Fourier 包为 $O_\psi(H^{-3})$。当 $d\le D$ 时，置 $X=M/d\ge16H-O(1)$；活动 $k$ 满足 $X<k<2X$，因而 $k\ge3$ 且
\[
\kappa(k)=-4\log(k/2)+2\mathbf1_{2\mid k}\log(k/2).
\]
又 $\log(k/2)=\log(X/2)+\log(k/X)$。将奇偶两个整数格分别作 Poisson 求和；$\phi$ 和 $(\log u)\phi(u)$ 的 Fourier 变换均为 $O_\psi((1+|\xi|)^{-3})$。在 $H/2\le|h|\le4H$ 且 $X\ge16H-O(1)$ 时，所有 Poisson 别名距零至少 $\gg H(1+|j|)$，所以
\[
|\mathcal L_h(d)|\ll_\psi\frac{\log M}{dH^3}
\quad(d\le D).
\]
对 $d\le D$ 求和花 $O_\psi(H^{-3}\log^2M)$。式 (3) 已使 $d\ge2M/3$ 的行逐点为零，故得到 (7)。频带含 $O_v(H)$ 个整数，平方后为 (8)；$M/H^9\ll M^{-4/5}$ 保证小于目标。$\square$

## 算术边界

式 (7) 在目标量级内把真实门写成单一的早期 Möbius 序列与显式负 cofactor 核。它使用了排除固定层反模型所缺少的**全部** Möbius 反演关系，但并未估计 $D<d<2M/3$ 上的二点 signed Gram。尤其不能把 (3) 当作 RH 或全尺度局部 Weil 正性的证明。

首个单 cofactor 区间已经说明现有单和估计的量纲。若 $M/2<d<2M/3$，则活动 cofactor 只有 $k=3$，其系数为 $\kappa(3)=-4\log(3/2)$。Srivastav, *Log-free bounds on exponential sums over primes*, arXiv:2505.07803v2 (2026), Corollary 1 适用于此处：把相位 $-3h/M$ 加一个整数，取 $q=a=1$、$\delta=-3hx/M\asymp h$；其 $|\delta|\le x^{4/15}$ 覆盖 $h\le4H\ll M^{1/4}$。经 Abel 求和，该预印本仅给这个区间的归一化 Fourier 和 $O(H^{-1/2})$；对 $O(H)$ 个频率平方求和是 $O(1)$。所需 $H^4/M=M^{-1/5+o(1)}$ 仍少一个固定幂。该预印本已于 2026-10-02 从本地原 PDF 核对；此处只判定该现成上界的适用量纲，不推断真实联合包的下界。
