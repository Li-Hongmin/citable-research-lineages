# 加性 Möbius 界恰遇倒数相位的曲率尺度

日期：2026-09-30。对象是固定 \(4/5<\alpha<1\)、\(D=\lfloor Y^\alpha\rfloor\)、\(Y<N\le2Y\) 下的真实分子 \(1\) 首阶相位 \(e(N/q)\)，\(q\asymp D\)。这里仅判定“分段一次线性化后，对每段使用现有加性 Möbius 前缀界”的方法。算术来源为 Priyamvad Srivastav, *Log-free bounds on exponential sums over primes*, arXiv:2505.07803v2（2026-01-27），Theorem 1 与 Corollary 1；2026-09-30 直接核对原 PDF。其 Corollary 1 对 \(q=1\)、\(\theta=\delta/x\)、\(1\ll|\delta|\le x^{4/15}\) 给
\[
\left|\sum_{n\le x}\mu(n)e(n\theta)\right|
\le \frac{15x}{\sqrt{\max(1,|\delta|/4)}}
\ll\sqrt{\frac{x}{|\theta|}}.
\tag{1}
\]
该文的 \(\mathscr G_\eta\) 系数在 \(\eta=1/15\) 时已由 Corollary 1 统一支付；这里没有让定理中的常数随 \(Y\) 变化。

令
\[
K=Y/D\to\infty,\qquad B_0=D^2/Y=D/K,
\qquad H_0=\sqrt{D^3/Y}=D/\sqrt K=\sqrt{DB_0}.
\tag{2}
\]
任取整数区间 \(I=(t,t+H]\subset(D/2,D]\)，固定中心 \(t\) 并置 \(\phi(x)=N/x\)、\(\theta=\phi'(t)=-N/t^2\)。于是 \(|\theta|\asymp Y/D^2=B_0^{-1}\)，对两端点 \(x\asymp D\) 有 \(|x\theta|\asymp K\)。因为固定 \(\alpha>4/5\) 给 \(K=D^{(1-\alpha)/\alpha+o(1)}\le D^{1/4+o(1)}<x^{4/15}\)，式 (1) 可用于这两个端点。相减便得线性化主和的界
\[
\left|\sum_{q\in I}\mu(q)e\!\left(\phi(t)+\theta(q-t)\right)\right|
\ll H_0.
\tag{3}
\]
另一方面，\(\phi''(x)=2N/x^3\ll Y/D^3=H_0^{-2}\)，故 Taylor 定理与 \(|e(u)-e(v)|\le2\pi|u-v|\) 给
\[
\left|\sum_{q\in I}\mu(q)e(N/q)
-\sum_{q\in I}\mu(q)e\!\left(\phi(t)+\theta(q-t)\right)\right|
\ll\frac{H^3}{H_0^2}.
\tag{4}
\]
合并 (3)--(4) 与平凡界得到
\[
\left|\sum_{q\in I}\mu(q)e(N/q)\right|
\ll\min\!\left\{H,\ H_0+\frac{H^3}{H_0^2}\right\}.
\tag{5}
\]
式 (5) 对任意 \(H\) 都不给 \(o(H)\) 的量纲：若 \(H\ll H_0\)，加性前缀界 \(H_0\) 已不小于区间长度；若 \(H\gg H_0\)，一次线性化误差 \(H^3/H_0^2\) 已超过区间长度；在 \(H\asymp H_0\) 两项均为 \(\asymp H\)。因此直接分段、取绝对值求和不能给完整分母带 \((D/2,D]\) 的固定幂消去。

**边界。** 这个结论只关闭上述具体转移，不排除直接的非线性 Möbius 倒数相位估计、跨段有符号抵消、跨分子相关或完整 moving-\(N\) 均方方法。式 (5) 处理纯 \(\mu(q)\)；真实首阶系数还带 \(q/\varphi(q)\) 与奇偶乘子，故不能把该判断误报成完整协方差的上下界。它没有证明或反驳 RH。
