# 固定上端间隙函数的二维 Weil–RH 检测器（待异源复核）

日期：2026-10-03。依赖 [note 874](../notes/874-upper-gap-weil-cross-realizes-smooth-chebyshev-discrepancy.md) 的完整交叉公式及对角量级、[note 275](../notes/275-cutoff-free-local-weil-positivity-to-log11-half.md) 的小尺度正性。本命题把原 note 的奇素数尺度扩到所有大奇整数，并构造一个 Mellin 变换在右半平面无零的固定光滑间隙函数。所得结论是 RH 的二维判据，**不是** RH 的证明，也没有给出所需二维非负性的无条件证明。

## 定理

固定 $0<\theta<1$ 和实值、非负、非零的 $\varphi\in C_c^\infty((-1/2,1/2))$，$\|\varphi\|_2=1$、$\kappa=\int\varphi>0$。存在一个**固定**、非负、非零的 $w_*\in C_c^\infty((1/2,1))$，其 Mellin 变换
\[
\widetilde w_*(s)=\int_0^\infty w_*(t)t^{s-1}dt
\tag{1}
\]
在 $\Re s>0$ 内无零点。

对每个充分大的奇整数 $q$，令
\[
H_q=\log q,\quad N_q=(q^2-3)/2,\quad
L_q=\sum_{n\le N_q}n^{-1},\quad
\ell_q=2\theta/q^2,\quad y_n=H_q-\log(2n),
\]
并在槽 $y_n+\ell_q(-1/2,1/2)$ 上取
\[
f_q(y_n+\ell_q t)=\frac{\varphi(t)}{\sqrt{\ell_q nL_q}},
\qquad 1\le n\le N_q,
\tag{2}
\]
槽外为零。定义
\[
G_*(v)=-(2e^{-v})^{3/2}w_*'(2e^{-v}),
\qquad g_q(x)=G_*(H_q-x).
\tag{3}
\]
那么，记 $Q_q=Q_W^{H_q}$，有精确判据
\[
\boxed{\quad
\mathrm{RH}\quad\Longleftrightarrow\quad
Q_q[f_q]Q_q[g_q]-Q_q(f_q,g_q)^2\ge0
\quad\text{对所有充分大的奇整数 }q.
\quad}\tag{4}
\]
这里 $w_*,\theta,\varphi$ 在全部尺度上固定；只检验一个二维压缩的行列式。若 RH 为假，则这个同一固定间隙函数在无限多个奇整数尺度上给出负行列式，但本定理没有构造或证明这些负尺度实际存在。

## 固定零自由权的构造

令 $A=(\log2)/2$、$x_0=(\log2)/4$、$a_j=A2^{-j}$（$j\ge1$），故 $\sum_j a_j=A$。令 $U_j$ 独立且均匀分布于 $[0,a_j]$，令 $g$ 为随机变量 $x_0+\sum_{j\ge1}U_j$ 的密度。此分布支撑于
$[x_0,x_0+A]=[(\log2)/4,3(\log2)/4]\subset(0,\log2)$。

其 Fourier 变换是
\[
\widehat g(\xi)=e^{-i\xi x_0}
\prod_{j\ge1}\frac{1-e^{-i\xi a_j}}{i\xi a_j}.
\tag{5}
\]
在实轴上每个因子的模至多一；对任意固定整数 $r\ge1$，前 $r$ 个因子使 $|\widehat g(\xi)|\ll_r(1+|\xi|)^{-r}$。故该紧支撑概率分布有 $C_c^\infty$ 密度 $g\ge0$。取 $w_*(t)=g(-\log t)$，则 $w_*\in C_c^\infty((1/2,1))$ 且非零。

代换 $t=e^{-x}$ 给
\[
\widetilde w_*(s)=
e^{-sx_0}\prod_{j\ge1}
\frac{1-e^{-sa_j}}{sa_j}.
\tag{6}
\]
在 $\Re s>0$，每个因子都非零；且因 $\sum a_j<\infty$，因子与一的差在紧集上一致绝对可和，所以无穷积亦非零。这证明 (1) 的断言。

## 奇整数尺度的 Weil 公式

note 874 的证明中的“$q$ 是素数”实际只用于 $q$ 奇时 $N_q\in\mathbb Z$。格槽下端满足
\[
y_{N_q}+H_q=\log\frac{q^2}{q^2-3}>3/q^2>\ell_q/2,
\]
而相邻中心最小间距 $\log(N_q/(N_q-1))=(2+o(1))/q^2>\ell_q$。若素数幂平移连接两个槽，$|\log(j/(kn))|<\ell_q$ 与 $j\le N_q$ 给 $|j-kn|<N_q(e^{\ell_q}-1)=\theta+o(1)<1$，故 $j=kn$。对固定共同轮廓，素数整除图的对角算术部分甚至可直接写成
\[
Q_{\rm prime}[f_q]
=-\frac2{L_q}\sum_{kn\le N_q}\frac{\Lambda(k)}{kn}
=-\frac2{L_q}\sum_{m\le N_q}\frac{\log m}{m}
=-\log N_q+O(1).
\tag{6a}
\]
这里用 $\sum_{k\mid m}\Lambda(k)=\log m$；它与逐槽 Fourier 对角的 $\log(1/\ell_q)$ 抵消至常数量级，因为 $\ell_qN_q\to\theta$。后续素数定理、求积与极点计算均对一般整数 $N_q$ 成立，不用 $q$ 的素性。因此 note 874 式 (4)、(15)–(16) 对全部充分大奇整数 $q$ 原样成立：
\[
Q_q(f_q,g_q)=
-\frac{\kappa\sqrt{2\theta}}{q\sqrt{L_q}}
E_{w_*}(N_q)
+O_{\theta,\varphi,w_*}(\sqrt{L_q}/q),
\quad
E_w(X)=\sum_{k\ge1}(\Lambda(k)-1)w(k/X),
\tag{7}
\]
\[
Q_q[f_q]=O_{\theta,\varphi}(1),
\qquad Q_q[g_q]=B_*>0,
\tag{8}
\]
其中 $B_*$ 是 note 275 的固定小尺度 Weil 值。

## 判据的两方向

若 RH 成立，Weil 判据使每个 $Q_q$ 在这些紧支撑光滑测试函数上非负；任意二维主子式非负，故 (4) 的右侧成立。

反之，假设 (4) 右侧对所有充分大奇整数成立。因 $B_*>0$ 与 (8)，二阶行列式给 $|Q_q(f_q,g_q)|=O(1)$；再由 (7) 得
\[
E_{w_*}(N_q)=O_{\theta,\varphi,w_*}(q\sqrt{L_q})
=O(\sqrt{N_q\log N_q}).
\tag{9}
\]
相邻奇整数 $q,q+2$ 的参数差为 $N_{q+2}-N_q=2q+2=O(\sqrt{N_q})$。对 $X\asymp N_q$，逐项求导并用 Chebyshev 界 $\sum_{k\le2X}(\Lambda(k)+1)\ll X$，得到
\[
|E_{w_*}'(X)|
\le\frac{C_{w_*}}X\sum_{k\asymp X}(\Lambda(k)+1)
\ll_{w_*}1.
\tag{10}
\]
故任意充分大实数 $X$ 距某个 $N_q$ 为 $O(\sqrt X)$，(9)–(10) 推出
\[
E_{w_*}(X)=O(\sqrt{X\log X})
\qquad(X\to\infty).
\tag{11}
\]

对 $\Re s>1$，Fubini 与 $t=k/X$ 的代换给
\[
\int_0^\infty E_{w_*}(X)X^{-s-1}dX
=\widetilde w_*(s)
\left(-\frac{\zeta'(s)}{\zeta(s)}-\zeta(s)\right).
\tag{12}
\]
式 (11) 使左侧在 $\Re s>1/2$ 全纯。式 (6) 的 $\widetilde w_*$ 在那里无零点；由亚纯函数恒等定理，括号中的函数也须全纯。在 $s=1$，$-\zeta'/\zeta$ 与 $-\zeta$ 的极点留数分别为 $+1$ 与 $-1$，确实相消。若 $\zeta$ 在 $\Re\rho>1/2$ 有零点，该函数的 $-\zeta'/\zeta$ 项在 $\rho$ 有非零留数，而 $-\zeta$ 在 $\rho$ 解析，矛盾。函数方程遂把全部非平凡零点压到临界线，即 RH。$\square$

## 边界

式 (4) 将全尺度局部 Weil 问题中的一个 RH 强度算术门压在一个固定光滑间隙函数与一个明确的二维压缩上；它没有估计该行列式的符号。其反向需要所有充分大奇整数尺度，而 note 874 原来的奇素数稀疏尺度不足以直接用 (10) 的 $O(\sqrt X)$ 插值。不得将这个判据表述为 RH 的证明。
