# 素数乘积、比值偶极与仿射轮廓的补反馈候选下界

日期：2026-09-29。依赖 [scratch 792](792-mixed-prime-rational-dipoles-one-third-feedback-candidate.md) 的原始平移约定、双臂偶极和根列，[note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的位置无关单槽能量。此稿是待异源复核的解析候选；结论仍以完整旧奇算子严格正为条件。

## 命题

沿奇素数 \(p\to\infty\)，置 \(k=p^2\)、\(L=\log k\)，令 \(e_p\)、低整数投影 \(P_p\)、\(Q_p=I-P_p\) 和闭形式旧奇算子 \(A_{k,-}\) 如 scratch 792。对每个 \(\eta>0\)，所有充分大的严格正端点 \(A_{k,-}\succeq a_k I\)、\(a_k>0\) 满足
\[
\boxed{\langle Q_pA_{k,-}e_p,
(Q_pA_{k,-}Q_p)^{-1}Q_pA_{k,-}e_p\rangle
\ge\left(\frac{24010}{67767}-\eta\right)L.}
\tag{1}
\]
这里的逆是 \(Q_p\) 上的闭形式压缩逆。\(24010/67767>6/17\)。这个命题不判定 \(A_{k,-}\) 是否严格正。

## 支撑与算术边

固定 \(0<\beta<1\)，置 \(P=p^\beta\)。对 \(x>1\) 定义
\[
\Delta=\tfrac12\log(1+p^{-2}),\quad
\varphi_z=(2\Delta)^{-1/2}
\left(1_{(\log z-\Delta,\log z)}-1_{(\log z,\log z+\Delta)}\right),
\quad w_x=\frac{\varphi_{px}+\varphi_{p/x}}{\sqrt2}.
\tag{2}
\]
令 \(\mathcal P=\{q\le P:q\text{ 素数}\}\)，并取三个互不相交的指标族
\[
\mathcal X_1=\{q:q\in\mathcal P\},\quad
\mathcal X_-=\{q/r:r<q,\ q,r\in\mathcal P\},\quad
\mathcal X_+=\{qr:q<r,\ q,r\in\mathcal P,\ qr<p\}.
\tag{3}
\]
每个 \(x\in\mathcal X_1\cup\mathcal X_-\cup\mathcal X_+\) 满足 \(1<x<p\)，所以两中心及其宽 \(2\Delta\) 的区间都在旧空间内部，\(w_x\) 是单位奇向量。

这些向量两两正交，并且属于 \(Q_pH_k^-\)。具体地，同侧中心的不同 \(x,y\) 的对数间距至少为 \(c/(pP)\)：素数及乘积之间为 \(\gg1/p\)，两个既约素数比之间为 \(\gg1/P^2\)，整数乘积与比值 \(q/r\) 之间由非零整数 \(ar-q\) 给出 \(\gg1/(pP)\)。异侧中心间距为 \(\log(xy)\gg1/P\)。这都大于 \(2\Delta\)。

对低整数槽，记 \(x=a/b>1\) 为既约分数；这里 \(a<p\)、\(b\le P\)。\(e_m\) 的两个中心为 \(m,p^2/m\)，\(w_x\) 的两个中心为 \(pa/b,pb/a\)。其中 \(pa/b>p\) 或 \(p^2/m\ge p\) 的异侧组合分别有绝对或至少 \(c/P\) 的间距。余下两种可能的重合都等价于 \(ma=pb\)。由于 \(p\nmid a\)、\(2\le m\le p\)，这强制 \(m=p,a=b\)，与 \(x>1\) 矛盾。不相等时，\(|ma-pb|\ge1\)；若两个中心接近，其对数距离至少为 \(c/(pP)\gg2\Delta\)。故 \(w_x\perp e_m\)。特别注意 \(qr<p\) 排除了乘积槽碰到旧空间端点。

写 \(\mathcal R_k=-\sum_{s\text{ 素数幂}}c_s(T_s+T_s^*)\)、\(c_s=\Lambda(s)/\sqrt s\)，原始约定是 \(T_sf(t)=f(st)\)，故向上移中心的是 \(T_s^*\)。对 (3) 中任意两个物理中心 \(z,z'\)，其比 \(z/z'=A/B\) 可取整数 \(A,B<p^2\)：比值与比值的交叉至多涉及 \(P^2\)，乘积与比值至多涉及 \(pP\)，两个乘积的异臂交叉至多涉及 \(p^2\)。若 \(T_s^*\varphi_z\) 与 \(\varphi_{z'}\) 相交，则
\[
|\log(sA/B)|<2\Delta=\log(1+p^{-2})
\quad\Longrightarrow\quad |sA-B|<B/p^2<1.
\tag{4}
\]
因此必须 \(sz=z'\)，此时两个完整偶极精确重合，内积为 \(1\)。\(T_s\) 给出反向边。故任意非负系数试探向量的全部算术能量非正；没有部分重叠造成的正项。

对不同素数 \(r<q\)，比值孩子与乘积孩子都有两条父边：
\[
\begin{aligned}
\langle w_{q/r},\mathcal R_kw_q\rangle&=-c_r,
&\langle w_{q/r},\mathcal R_kw_r\rangle&=-c_q,\\
\langle w_{qr},\mathcal R_kw_q\rangle&=-c_r,
&\langle w_{qr},\mathcal R_kw_r\rangle&=-c_q
\qquad(qr<p).
\end{aligned}
\tag{5}
\]
例如 \(T_r^*\) 将 \(pq\) 移至 \(pqr\)，而其反向边将 \(p/(qr)\) 移至 \(p/q\)；这两次半权配对合为 \(-c_r\)。比值边的中心核对见 scratch 792。其余算术边只会降低下面的非负系数向量的能量。

## 变分能量

令
\[
S=\sum_{q\in\mathcal P}c_q^2,\quad
U_-=\sum_{r<q\in\mathcal P}c_q^2c_r^2,\quad
U_+=\sum_{q<r\in\mathcal P,\ qr<p}c_q^2c_r^2,\quad U=U_-+U_+,
\tag{6}
\]
并取
\[
t=\sum_{q\in\mathcal P}c_qw_q
+\frac2L\sum_{r<q\in\mathcal P}c_qc_rw_{q/r}
+\frac2L\sum_{q<r\in\mathcal P,\ qr<p}c_qc_rw_{qr}\in Q_pH_k^-.
\tag{7}
\]
由正交性 \(\|t\|^2=S+4U/L^2\)。式 (5) 的每个孩子给出两条能量交叉，连同正系数的其他边有
\[
\mathcal R_k[t]\le-\frac{8U}{L}.
\tag{8}
\]

每个 \(w_x\) 的 Archimedean 对角至多 \(D_k+C=L+C'\)，因为两个单半槽的位置项精确抵消，相邻半槽交叉为 \(O(1)\)，而同一 \(w_x\) 的两中心交叉为 \(O(\Delta P)\)。所有不同物理中心在对数线上相隔至少 \(c/(pP)\)；排序后用 \(K(v)\ll1/v\) 作 Schur 行和，非对角算子范数为
\[
O\!\left(\Delta pP\log(2p)\right)
=O\!\left(p^{\beta-1}\log p\right)=o_\beta(1).
\tag{9}
\]
极点二次型非正，故
\[
A_{k,-}[t]\le(L+C)\left(S+\frac{4U}{L^2}\right)-\frac{8U}{L}
=LS-\frac{4U}{L}+O_\beta(L^2).
\tag{10}
\]

根的算术像在 (3) 中仅投到第一层，\((T_q+T_q^*)e_p=\sqrt2w_q\)，因此算术根配对为 \(-\sqrt2S\)。根到各比值中心的距离至少 \(c/P\)；到第一层和乘积层的距离有绝对正下界。逐列核界给出 Archimedean 根列范数 \(O(\Delta P^2+\Delta\sqrt p)=o(1)\)。由 note 788 的 \(\langle s_k,e_p\rangle=O(p^{-3})\)、\(\|s_k\|=O(p^{1/2})\)，极点根列范数也为 \(o(1)\)。\(\|t\|=O(L)\) 于是
\[
\langle t,A_{k,-}e_p\rangle=-\sqrt2S+o(1).
\tag{11}
\]
所有参与的阶跃偶极都有有限对数形式能量，且 \(e_p\in D(A_{k,-})\)；在假设的严格正端点可对闭形式压缩使用逆度量变分。

## 素数主项与系数

置 \(H=\log p=L/2\)。素数定理及 Stieltjes 分部积分表明测度
\[
H^{-2}\sum_{q\le p\atop q\text{ 素数}}
\frac{(\log q)^2}{q}\,\delta_{\log q/H}
\Longrightarrow u\,du\quad\text{于 }[0,1].
\tag{12}
\]
故固定 \(\beta<1\) 时，\(S/L^2\to s_\beta=\beta^2/8\)，\(U_-/L^4\to\beta^4/128\)，而
\[
\frac{U_+}{L^4}\longrightarrow
\frac1{32}\iint_{\substack{0<u,v<\beta\\u+v<1}}uv\,du\,dv.
\tag{13}
\]
边界 \(u+v=1\) 对极限测度为零；对角素数对的 \(\sum c_q^4\) 有界。令 \(\beta\uparrow1\)，则 \(s_\beta\to1/8\)，并且
\[
\frac{U_-}{L^4}\to\frac1{128},\qquad
\frac{U_+}{L^4}\to\frac1{32}\cdot\frac1{24}=\frac1{768},
\qquad \frac{U}{L^4}\to\frac7{768}.
\tag{14}
\]
这表示先固定 \(\beta\)、令 \(p\to\infty\)，最后使 \(\beta\uparrow1\)，没有用随 \(p\) 变化的截断。

对每个固定 \(\beta<1\)，(10) 的主系数严格正：由 \(U_+\le U_-\sim S^2/2\)，有 \(S/L^2-4U/L^4\ge\beta^2(2-\beta^2)/16+o(1)>0\)。根配对 (11) 和变分式给出
\[
\frac{\langle Q_pA_{k,-}e_p,(Q_pA_{k,-}Q_p)^{-1}Q_pA_{k,-}e_p\rangle}{L}
\ge\frac{2(S/L^2)^2}{S/L^2-4U/L^4}+o_\beta(1).
\tag{15}
\]
按 (14) 先取 \(p\to\infty\)、再取 \(\beta\uparrow1\)，右侧趋于
\[
\frac{2(1/8)^2}{1/8-4(7/768)}
=\frac{1/32}{17/192}=\frac6{17},
\]
这先给出 \(6/17\) 的常值轮廓下界。下面使用同一节点族改进它。

## 仿射素数轮廓

令 \(f:[0,1]\to(0,\infty)\) 为固定连续函数，\(u_q=\log q/H\)，并把 (7) 改为
\[
t_f=\sum_{q\in\mathcal P}c_qf(u_q)w_q
+\frac1L\sum_{r<q\in\mathcal P}c_qc_r
\bigl(f(u_q)+f(u_r)\bigr)w_{q/r}
+\frac1L\sum_{q<r\in\mathcal P,\ qr<p}c_qc_r
\bigl(f(u_q)+f(u_r)\bigr)w_{qr}.
\tag{16}
\]
所有系数仍非负。每个孩子的父边和为
\(-c_qc_r(f(u_q)+f(u_r))\)；其在 \(t_f\) 中的系数正好使「\(L\) 倍孩子范数平方 + 父边交叉」等于
\(-c_q^2c_r^2(f(u_q)+f(u_r))^2/L\)。丢掉其他非正算术边、保留同一 \(O(L^2)\) 的 Archimedean 对角误差，便得到
\[
A_{k,-}[t_f]\le
L\sum_{q\in\mathcal P}c_q^2f(u_q)^2
-\frac1L\sum_{r<q\in\mathcal P}c_q^2c_r^2(f(u_q)+f(u_r))^2
-\frac1L\sum_{q<r\in\mathcal P,\ qr<p}c_q^2c_r^2(f(u_q)+f(u_r))^2
+O_f(L^2).
\tag{17}
\]
根配对仍是
\(\langle t_f,A_{k,-}e_p\rangle
=-\sqrt2\sum_{q\in\mathcal P}c_q^2f(u_q)+o(1)\)。由 (12) 和零测度三角边界，先固定 \(\beta<1\)、令 \(p\to\infty\)，再令 \(\beta\uparrow1\)，得到变分系数
\[
C[f]=\frac{4R^2}{8A-I_{\rm full}-I_{\rm tri}},\quad
R=\int_0^1uf(u)\,du,\quad A=\int_0^1uf(u)^2\,du,
\tag{18}
\]
其中
\[
I_{\rm full}=\iint_{(0,1)^2}uv(f(u)+f(v))^2\,du\,dv,
\qquad
I_{\rm tri}=\iint_{u+v<1}uv(f(u)+f(v))^2\,du\,dv.
\tag{19}
\]
分母在以下选定的 \(f\) 处严格为正，故上述两个极限与严格正端点的逆度量变分可依次使用。

取 \(f_\lambda(u)=1+\lambda(1-u)\)、\(\lambda\ge0\)。直接积分给出
\[
R=\tfrac12+\tfrac\lambda6,\quad
A=\tfrac12+\tfrac\lambda3+\tfrac{\lambda^2}{12},\quad
I_{\rm full}=A+2R^2,\quad
I_{\rm tri}=\tfrac16+\tfrac\lambda5+\tfrac{11\lambda^2}{180}.
\tag{20}
\]
因此
\[
C[f_\lambda]
=\frac{(1+\lambda/3)^2}
{17/6+9\lambda/5+7\lambda^2/15}.
\tag{21}
\]
对 \(\lambda\ge0\) 求导，导数的符号与 \(4/15-\lambda\) 相同；在 \(\lambda=4/15\) 得
\[
C[f_{4/15}]=\frac{24010}{67767}.
\tag{22}
\]
对任意 \(\eta>0\)，先选固定的 \(\beta<1\) 使其系数距 (22) 小于 \(\eta/2\)，再取充分大的正端点使误差小于 \(\eta/2\)，便得到 (1)。\(\square\)

## 边界

新增乘积孩子给出一组确定为负的父边，仿射素数轮廓再改进变分系数；(1) 仍是以完整旧核严格正为条件的低整数补空间反馈下界。它没有支付根的全部 \((1+o(1))L\) 对角，也没有给出全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 或 RH。
