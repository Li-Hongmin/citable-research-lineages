# 候选：三块 Farey 常值槽的全部非算术交叉可由增长谱隙支付

日期：2026-09-30。证明草稿，尚待独立复核。依赖 [note 810](../notes/810-three-growing-gap-blocks-cover-all-farey-constant-slots.md) 的三块谱隙及 polar 质量、[note 806](../notes/806-all-bounded-farey-constant-slots-have-loglog-gap-and-positive-joint-compression.md) 的跨界 Hilbert 界与全阶跃混合界，以及 [note 805](../notes/805-dense-farey-constant-slots-have-attraction-and-positive-joint-compression.md) 的核公式。

## 定理

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)、\(Q=\lfloor(p-1)/H\rfloor\)，固定 \(r>2/(1-3/\pi^2)\)，取 note 810 的正交分拆
\[
T_p=B_r\oplus J_r\oplus E_r,
\quad B_r:\ x\le r,
\quad J_r:\ x>r,\ a\le Q,
\quad E_r:\ x>r,\ a>Q.
\tag{1}
\]
沿 note 807 写素数幂矩阵 \(C^-=C_{\parallel}-C_{\times}\)，定义它在三块之间的自伴交叉部分
\[
C^-_{\mathrm{inter}}
=C^--\operatorname{diag}(C^-_{BB},C^-_{JJ},C^-_{EE}),
\tag{2}
\]
这里所有矩阵都压缩到 \(T_p\)。保留完整 Archimedean 核、polar 秩一项及各块内部全部真实素数幂边，只移除块间素数幂边的算子
\[
A_T^{(0)}=P_{T_p}A_{p^2,-}P_{T_p}+C^-_{\mathrm{inter}}
\tag{3}
\]
满足
\[
\boxed{\quad A_T^{(0)}
\succeq\bigl(\log H-\log\log H-O_r(1)\bigr)I_{T_p}.\quad}
\tag{4}
\]
把 (3) 与全阶跃偶极 \(W_p\) 的真实混合块拼接，所得 \(W_p\oplus T_p\) 算子满足
\[
\boxed{\quad A_{W_p\oplus T_p}^{(0)}
\succeq(c_0-o_r(1))I,
\qquad c_0=1+\gamma_E-\log\pi+\delta_0>0.\quad}
\tag{5}
\]
所以在这个完整常值槽分拆中，有限压缩内尚未支付的交叉项可以精确限定为 \(-C^-_{\mathrm{inter}}\)。式 (4)--(5) 不控制这个真实算术交叉，也不控制无限维正交补。

## 两个非算术交叉界

沿 note 807 式 (12) 写完整常值槽 Archimedean 矩阵
\[
P_{T_p}G_{p^2}P_{T_p}
=(D_p-\log2+O(\Delta))I-N+K_{\times},
\quad K_{\times}\succeq0,
\quad N(x,y)=M_\Delta(|\log(x/y)|)\ (x\ne y),
\tag{6}
\]
其中 \(\Delta=\frac12\log(1+p^{-2})\)，\(N(x,x)=0\)。对分界 \(x=r\)，note 806 式 (7)--(10) 的离散 Hilbert 证明仅使用全 Farey 间距 \(>2\Delta\) 和两侧槽数 \(O(p^2)\)，因此对整个无上限 Farey 集仍给
\[
\|N_{B_r,J_r}\|+\|N_{B_r,E_r}\|=O_r(1).
\tag{7}
\]

对 \(J_r,E_r\) 的交织部分另作矩形 Schur 估计。两个不同 \(J_r\) 中心的对数间距至少 \(cQ^{-2}\)，两个不同 \(E_r\) 中心的间距至少 \(r p^{-2}\)。若 \(x=a/b\in E_r\)、\(y=c/d\in J_r\)，则 \(a,d\le p,Q\)、\(b,c\le p,Q\)，且 \(|ad-bc|\ge1\)。因而
\[
|\log(x/y)|\ge\log(1+(pQ)^{-1})\gg(pQ)^{-1}.
\tag{8}
\]
对每个固定 \(x\in E_r\)，把 \(J_r\) 的中心按左右顺序列出。首项距离 \(\gg(pQ)^{-1}\)，以后每一步增加 \(\gg Q^{-2}\)。用 note 805 式 (8) 的
\(M_\Delta(d)\le\Delta/(d-2\Delta)+C\Delta\) 和 \(|J_r|\le Q^2\)，得
\[
\sup_{x\in E_r}\sum_{y\in J_r}N(x,y)
\ll\frac{\Delta}{(pQ)^{-1}}
 +\Delta Q^2\log(2Q)+\Delta Q^2
=O(H^{-1}).
\tag{9}
\]
反向固定 \(y\in J_r\)，利用 \(E_r\) 的 \(r p^{-2}\) 间距及 \(|E_r|\le p^2\)，有
\[
\sup_{y\in J_r}\sum_{x\in E_r}N(x,y)
\ll_r\frac{\Delta}{(pQ)^{-1}}
 +\Delta p^2\log(2p)+\Delta p^2
=O_r(H).
\tag{10}
\]
矩形 Schur 检验将 (9)--(10) 合成
\[
\|N_{J_r,E_r}\|=O_r(1).
\tag{11}
\]

polar 向量记为 \(h=P_{T_p}s_{p^2}=h_B+h_J+h_E\)。note 810 及其上游给
\[
\|h_B\|^2=O_r(1),\qquad
\|h_J\|^2=O(H^{-1}),\qquad
\|h_E\|^2=O(H).
\tag{12}
\]
因此 (7)、(11) 与 \(-2hh^*\) 合并后的三个非算术交叉块范数为
\[
\|X_{BJ}\|=O_r(1),\qquad
\|X_{BE}\|=O_r(\sqrt H),\qquad
\|X_{JE}\|=O_r(1).
\tag{13}
\]
式 (13) 在全局丢去正矩阵 \(K_{\times}\) 后使用，因其所有跨块条目必须连同其对角一起丢去，不能只丢对角。

## 支付交叉并接上阶跃空间

note 810 的三块证明在各块上均已丢去 \(K_{\times}\succeq0\)，故剩余对角下界仍为
\[
g_B=\log H-\log\log H-O_r(1),\quad
g_J=2\log H-O(1),\quad
g_E=\gamma_rH-O_r(\sqrt H\log H),
\quad \gamma_r=1-2/r-3/\pi^2>0.
\tag{14}
\]
取固定 \(M_r\) 使 (13) 的三个范数分别至多 \(M_r,M_r\sqrt H,M_r\)。对任意 \(f=f_B+f_J+f_E\)，三次 Cauchy 不等式分别把 \(BJ,BE,JE\) 交叉支付于 \(g_J\|f_J\|^2/2\)、\(g_E\|f_E\|^2/4\)、\(g_E\|f_E\|^2/4\)。对应从 \(B,J\) 对角扣去的量依次为
\[
O_r(g_J^{-1}),\quad O_r(H/g_E)=O_r(1),\quad O_r(g_E^{-1})=o(1).
\]
余下的三个对角系数分别至少为
\[
g_B-O_r(1),\qquad g_J/2-o(1),\qquad g_E/2.
\]
由于 \(g_J/2=\log H-O(1)\)、\(g_E/2\gg_r H\)，其最小值为 \(\log H-\log\log H-O_r(1)\)，证明 (4)。

note 806 已对全体常值槽证明 \(\|P_{W_p}A_{p^2,-}P_{T_p}\|=O(1)\)，而修改 (3) 只发生于 \(T_p\) 内部。note 804 给 \(A_{W_p}\succeq(c_0-o(1))I\)。由 (4) 的增长谱隙完成平方，\(W_p\) 上的 Schur 损失为 \(O(1/\log H)=o(1)\)，得到 (5)。\(\square\)

## 边界

三块之间的核接触和 polar 大混合都已支付；这没有约束 \(C^-_{\mathrm{inter}}\) 的正向能量。真实 \(W_p\oplus T_p\) 正性仍须证明算术交叉在同一二次型预算下不吞掉 (4)--(5) 的谱隙；即使完成，槽内其余轮廓与无限维补空间仍须另作真 Schur 控制。
