# 观察频率近带的真实素数臂交叉常数与密度抵消（待异源复核）

日期：2026-10-01。沿用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的 $c(m)$、$\psi$、$\eta$ 与 $K_H$，并使用 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 已核对的 Heath--Brown 1982 全区间短区间素数定理和 Matomäki--Shao--Tao--Teräväinen 2023 全区间 Möbius 前缀定理。这里计算真实算术通道在一个近差带内的常数，不给目标固定幂余项，也不证明 RH。

## 命题

固定实值、非负、非零的 $\psi\in C_c^3((1,2))$ 和 note 849 的非负偶函数 $\eta$。
令 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，
$L=\lfloor M/(32H)\rfloor$，$\varphi(u)=\psi(u)/u$。
把式 (10) 的系数精确分为五列：
\[
\begin{array}{ll}
d_P(m)=-4\mathbf1_{m=p\ {m prime}}\log p,&\kappa_P=-4,\\
d_D(m)=2\mathbf1_{m=2p\ {m for\ a\ prime}\ p}\log p,&\kappa_D=1,\\
d_B(m)=4-2\mathbf1_{2\mid m},&\kappa_B=3,\\
d_U(m)=-4(\log2)\mu(m),&\kappa_U=0,\\
d_Q(m)=2\mathbf1_{2\mid m}P_2(m/2)-4P_2(m),&\kappa_Q=0.
\end{array}
\tag{1}
\]
这里 $P_2(n)=\Lambda(n)-\mathbf1_{n=p\ {m prime}}\log p$，
$c=d_P+d_D+d_B+d_U+d_Q$，
$c_{\rm tri}=d_P+d_D+d_U$。
对任意两列 $i,j$，定义有序近带 Gram
\[
G_{ij}^{\rm near}(Y,H)
=\sum_{\substack{M<m,n<2M\\|m-n|\le L}}
\frac{d_i(m)d_j(n)}{mn}
\psi(m/M)\psi(n/M)K_H(m-n).
\tag{2}
\]
则一致于上述 $H$ 区间，
\[
\boxed{\quad
G_{ij}^{\rm near}(Y,H)
=\kappa_i\kappa_j\,C_{\psi,\eta}+o(1),
\qquad
C_{\psi,\eta}
=\left(\int_1^2\varphi(u)^2du\right)
\left(\int_{-1/32}^{1/32}\widehat\eta(t)dt\right)>0.
\quad}
\tag{3}
\]
特别地，真实异尺度素数臂的双向交叉为
$G_{PD}^{\rm near}+G_{DP}^{\rm near}=-8C_{\psi,\eta}+o(1)$；
它确实是带符号负协方差，而非仅由 $K_H$ 变号产生的负贡献。
各主块的常数为
\[
\begin{array}{c|rrrrrr}
\text{块}&PP&DD&BB&PD+DP&PB+BP&DB+BD\\\hline
\text{常数}/C_{\psi,\eta}&16&1&9&-8&-24&6 .
\end{array}
\tag{4}
\]
所有涉及 $U$ 或 $Q$ 的近带交叉均为 $o(1)$。因此
\[
G_{c_{\rm tri},c_{\rm tri}}^{\rm near}
=9C_{\psi,\eta}+o(1),
\qquad
G_{c,c}^{\rm near}=o(1),
\tag{5}
\]
其中 $16+1-8=9$，再加背景后的
$9+9-24+6=0$。这说明近带内可见的素数臂负交叉及其剩余正质量，恰按三条平滑密度
$-4,+1,+3$ 相消。式 (5) 仍没有 $O(H^4/Y)$ 的固定幂误差。

## 局部密度与近带核

记 $W=M/H$。对任一列 $i$，有
\[
\sum_{M<m<2M}|d_i(m)|\ll M,
\qquad
E_i(Y):=\sup_{\substack{I\subset(M,2M)\\|I|\le2L+1}}
\left|\sum_{m\in I}(d_i(m)-\kappa_i)\right|
=o(W).
\tag{6}
\]
第二式对 $B$ 列由奇偶交替给 $O(1)$。对 $P$，把任意 $I$ 分成
$B_0=\lfloor Y^{2/3}\rfloor$ 的整块和一个余块；note 835 的全区间素数定理给每个整块
$\sum_{p\in I_0}\log p=B_0+o(B_0)$，一致于块位置。
余块的平凡贡献为 $O(B_0\log Y)=o(W)$，
因为 $W\gg Y^{3/4}$。于是 $E_P=o(W)$。
偶数格 $m=2p$ 将 $D$ 列归约到相同的素数块论证，并给局部密度 $1$。
对 $U$，note 835 所引的全区间 Möbius 最大前缀估计给整块
$O_A(B_0/\log^A Y)$，余块至多 $O(B_0)=o(W)$。
对 $Q$，note 849 式 (33) 的高次素数幂总质量
$O(\sqrt Y\log Y)=o(W)$。第一式对所有列由 Chebyshev 界、$|\mu|\le1$ 与上述素数幂质量得到。

对 $|k|\le L$，Riemann 求和或 note 849 式 (17) 给一致近似
\[
K_H(k)=H\widehat\eta(Hk/M)+o(H),
\quad |K_H(k)|\ll H,
\quad
\sum_{|k|\le L}|K_H(k+1)-K_H(k)|\ll H.
\tag{7}
\]
最后一界直接由
$|K_H(k+1)-K_H(k)|\le
\sum_h\eta(h/H)|e(-h/M)-1|\ll H^2/M$
和 $L\ll M/H$ 给出。因 $\eta\ge0$、支撑于
$|t|\le4$，当 $|s|\le1/32$ 时
$\widehat\eta(s)=\int\eta(t)\cos(2\pi st)dt
\ge\cos(\pi/4)\int\eta(t)dt>0$。
所以 (3) 的 $C_{\psi,\eta}$ 严格正。

## 近带 Gram 的替换证明

因为 $\psi(m/M)/m=M^{-1}\varphi(m/M)$，(2) 为
\[
M^{-2}\sum_n d_j(n)\varphi(n/M)
\sum_{|m-n|\le L}d_i(m)\varphi(m/M)K_H(m-n).
\tag{8}
\]
固定 $n$，把内层的 $d_i$ 换为 $\kappa_i$。对误差序列
$b_i=d_i-\kappa_i$ 作离散 Abel 求和；式 (7) 与
$\varphi\in C_c^1$ 表明内层权
$\varphi(m/M)K_H(m-n)\mathbf1_{|m-n|\le L}$
的上确界及总变差都为 $O(H)$。式 (6) 因而把内层替换误差界为
$O(E_iH)=o(M)$，对 $n$ 一致。
再由 $\sum_n|d_j(n)|\ll M$，(8) 的总误差为 $o(1)$。

换元 $k=m-n$ 后，替换后的内层是
$\kappa_i\sum_{|k|\le L}\varphi((n+k)/M)K_H(k)$。
因 $|k|/M\ll H^{-1}$、$\varphi$ Lipschitz 且
$\sum_{|k|\le L}|K_H(k)|\ll M$，
它一致等于
\[
\kappa_i\varphi(n/M)\sum_{|k|\le L}K_H(k)+o(M).
\tag{9}
\]
由 (7) 的一致近似及步长 $H/M\to0$，
\[
\frac1M\sum_{|k|\le L}K_H(k)
\longrightarrow\int_{-1/32}^{1/32}\widehat\eta(t)dt.
\tag{10}
\]
最后式 (6) 分成 $O(H)$ 个长度至多 $2L+1$ 的块，再对固定光滑权
$\varphi^2$ 作 Abel 求和，给
$M^{-1}\sum_n d_j(n)\varphi(n/M)^2
\to\kappa_j\int_1^2\varphi(u)^2du$。
将它与 (8)--(10) 合并即得 (3)；线性展开给 (4)--(5)。$\square$

## 边界

这里的素数近差配对跨度为 $M/H\asymp Y^{3/4}$--$Y^{4/5}$，不需要固定差素数对猜想。
局部密度误差只有 $o(W)$，所以 (3)--(5) 只有 $o(1)$ 余项；
目标 $H^4/Y$ 在 $H=Y^{1/5}$ 时为 $Y^{-1/5}$。
要把近带的 $o(1)$ 提升到该固定幂，必须对真实系数取得更强的频率平均或利用超出局部密度的带符号结构。
另须注意：note 849 式 (30) 允许在**整个频带范数**中用
$c_{\rm tri}$ 代替 $c$；式 (5) 证明，在先截取近差带后作同样替换会改变 $9C_{\psi,\eta}+o(1)$ 的主项。频率替换误差不能逐距离块转用。
