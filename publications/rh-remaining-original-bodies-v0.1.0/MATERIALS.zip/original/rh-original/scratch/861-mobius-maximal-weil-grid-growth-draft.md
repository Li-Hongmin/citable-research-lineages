# 真实 Möbius 系数使最大整数 Weil 格的 Rayleigh 值对数发散（待复核）

日期：2026-10-02。依赖 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的槽几何、完整 Weil 分解和普通核中心替换，以及 [note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除矩阵。这里的系数是真实的全素数 Möbius 函数，故不属于 note 859 的固定有限素数赋值轮廓族。

## 命题

沿奇素数 $p\to\infty$，令 $H=\log p$、$M=(p^2-5)/4$、$L=\log M$，固定 $0<c<4$、$\ell=c/p^2$ 与实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$。在 note 857 的槽 $I_n$ 上取
\[
 f_p(y_n+t)=\frac{\mu(n)}{\sqrt{nW_M}}b_\ell(t),
 \qquad W_M=\sum_{n\le M}\frac{\mu(n)^2}{n},
\]
其余处取零。则 $\|f_p\|_2=1$，而完整 Weil 形式满足
\[
 \boxed{Q_W^{\log p}[f_p]=2\log M+O_{c,\varphi}(1).}\tag{1}
\]
特别地，$Q_W^{\log p}[f_p]/\log M\to2$，故这一真实 Möbius signed 方向的 Weil 能量严格为正并发散。隐含常数绝对可依赖固定的 $c,\varphi$，不依赖 $p$。证明只用初等平方自由数计数和 $\sum_{q\le x,\,q\text{ prime}}(\log q)/q=\log x+O(1)$，不使用 moving-$N$ Möbius 协方差估计。

## 平方自由质量

记 $\alpha=1/\zeta(2)=6/\pi^2$。由 $\mu^2(n)=\sum_{d^2\mid n}\mu(d)$ 及绝对收敛的 $\sum_d(1+\log d)/d^2$，
\[
 \sum_{n\le x}\mu(n)^2=\alpha x+O(\sqrt x),
 \qquad
 \sum_{n\le x}\frac{\mu(n)^2}{n}=\alpha\log x+O(1).
\tag{2}
\]
后一式也可由前一式分部求和。尤其 $W_M=\alpha L+O(1)$。

## Prime-shift 项的负主阶

令 $g_n=\mu(n)/\sqrt n$，$C_M$ 为 note 854 式 (2) 的整除矩阵。由于 $\mu(q^tn)=0$ 对 $t\ge2$ 恒成立，而 $\mu(n)\mu(qn)=-\mu(n)^2$ 在 $q\nmid n$ 时成立、在 $q\mid n$ 时乘积为零，得到精确恒等式
\[
 \langle g,C_Mg\rangle
 =-2\sum_{q\le M\atop q\text{ prime}}\frac{\log q}{q}
       \sum_{n\le M/q\atop q\nmid n}\frac{\mu(n)^2}{n}.
\tag{3}
\]
这是整除图上的真实符号相消，不依赖任何未证的加性 Möbius 相关。

记 $\vartheta_1(x)=\sum_{q\le x,\,q\text{ prime}}(\log q)/q$。note 854 式 (3) 中的初等 $M_1(x)=\log x+O(1)$ 与绝对收敛的高次素数幂尾
$\sum_q\sum_{t\ge2}(\log q)/q^t<\infty$ 给
$\vartheta_1(x)=\log x+O(1)$，对所有 $x\ge1$ 一致。交换 (3) 的有限和，先不排除 $q\mid n$，得到
\[
 \sum_{n\le M}\frac{\mu(n)^2}{n}\vartheta_1(M/n)
 =\sum_{n\le M}\frac{\mu(n)^2}{n}\log(M/n)+O(L)
 =\frac{\alpha}{2}L^2+O(L).
\tag{4}
\]
最后一步由
$\log(M/n)=\int_n^Mdt/t$ 和式 (2) 严格推出。排除 $q\mid n$ 的成本至多
\[
 \sum_{q\le M}\frac{\log q}{q}
 \sum_{n\le M\atop q\mid n}\frac{\mu(n)^2}{n}
 \le C L\sum_q\frac{\log q}{q^2}=O(L),
\tag{5}
\]
因为平方自由的 $n$ 若 $q\mid n$，可写为 $qm$，内和至多 $q^{-1}\sum_{m\le M/q}\mu(m)^2/m\ll L/q$。由 (3)--(5)，
\[
 \boxed{\langle g,C_Mg\rangle=-\alpha L^2+O(L),
 \qquad \langle g,C_Mg\rangle/W_M=-L+O(1).}\tag{6}
\]
Weil 形式中 prime-shift 项的符号是负号，所以它贡献 $+L+O(1)$。

## 其余 Weil 项

同槽 Fourier 与光滑余项按 note 857 式 (5) 给
\[
 Q_{\rm same}[f_p]
 =\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)
 =L+O_{c,\varphi}(1).
\tag{7}
\]

普通跨槽中心核由 note 856 式 (7) 化为
\[
 S_1+S_2
 =\sum_{n<r\le M}\mu(n)\mu(r)
 \left(\frac1{r-n}+\frac1{r+n}\right).
\]
矩阵 $K_{nr}=\mathbf1_{n\ne r}/|n-r|$ 的行和至多 $2H_{M-1}=O(L)$，故 $|S_1|\ll L\sum_{n\le M}\mu(n)^2\ll ML$。对 $1/(n+r)$，以 $n^{-1/2}$ 为 Schur 权并用
$\sum_{r\ge1}(n+r)^{-1}r^{-1/2}\le\pi n^{-1/2}$，得 $|S_2|\ll M$。中心核替换误差在 $|\mu(n)|\le1$ 下仍如 note 857 为 $O_{c,\varphi}(1)$，除以 $W_M\asymp L$ 后消失。由于 $\ell M\to c/4$，
\[
 Q_{\rm ord}[f_p]
 =-\frac{\kappa^2\ell}{W_M}(S_1+S_2)+o(1)
 =O_{c,\varphi}(1).
\tag{8}
\]

极点项沿用 note 859 式 (11)。因
$|\sum_{n\le M}\mu(n)/n|\le W_M$、
$|\sum_{n\le M}\mu(n)|\le M$ 及
$m_+m_-=O_\varphi(\ell)$，它的绝对值至多 $O_{c,\varphi}(\ell M)=O_{c,\varphi}(1)$。把 (6)--(8) 与此项相加，即得 (1)。$\square$

## 精确边界

式 (1) 说明，在最大整数格的**共同槽轮廓**中直接使用真实 $\mu(n)$ 作为系数，会使 prime-shift 二次型出现负的 $-\alpha L^2$ 主阶，因而 Weil 形式增加一个 $+L$ 主阶。这没有控制任意槽轮廓或完整补空间，也没有估计 note 732/750 的 moving-$N$ **加性** $\mu(d)\mu(e)$ signed covariance；RH 仍未证明或反驳。
