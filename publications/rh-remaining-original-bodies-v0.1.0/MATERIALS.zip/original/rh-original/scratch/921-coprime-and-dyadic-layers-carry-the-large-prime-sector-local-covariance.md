# 一大素因子扇区的首瓣主项只落在物理 gcd 为 1、2 的层上

日期：2026-10-02。承接 [scratch/917](917-small-physical-gcd-restores-the-complete-high-divisor-gram.md) 的精确源重组、[scratch/918](918-short-cofactor-mobius-cancellation-in-the-restored-high-divisor-first-lobe.md) 的物理短和、[scratch/919](919-positive-density-of-exact-zero-rows-in-the-true-high-divisor-gram.md) 的一大素因子行，以及 [scratch/920](920-one-large-prime-sector-has-a-rank-one-local-high-divisor-covariance.md) 的首瓣矩阵。本文增加一个按**物理 gcd** 的精确分层；使用 Matomäki--Shao--Tao--Teräväinen, *Forum Math. Pi* **11** (2023), e29, Proposition 3.4(i) 的等差进程 Möbius 短和（原论文 PDF 的命题有对模数和剩余类的一致最大值）。结论仍为常数量级，不是 RH 所需的固定幂余项估计；尚未异源复核。

## 命题候选（待异源复核）

令 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定实值非零 $\psi\in C_c^3((1,2))$，$\phi(x)=\psi(x)/x$。沿用 scratch/917 的 $D,a_D,\beta,G$ 和 scratch/920 的一大素因子行 $P_m$、补集 $C_m=a_D(m)-P_m$、首瓣长度 $L=\lfloor M/(32H)\rfloor$、偶非负带通核 $J_H$。置
\[
\ell_{M,H}=\log\!\frac{\log M}{\log(M/H)},\qquad
V_{M,H}=\frac1M\sum_{|r|\le L}J_H(r),\qquad
I_\phi=\int_1^2\phi(x)^2\,dx,
\quad \sigma_P=1,\ \sigma_C=-1.
\tag{1}
\]
对 $U,V\in\{P,C\}$ 与 $g\in\{1,2\}$，定义
\[
Q_{UV}^{[g]}=
\sum_{\substack{M<m,n<2M\\(m,n)=g,\ |m-n|\le L}}
U_m\overline{V_n}J_H(m-n).
\tag{2}
\]
则一致于整个 $H$ 范围，逐项有
\[
\boxed{\quad
Q_{UV}^{[1]}=8\sigma_U\sigma_V\ell_{M,H}^{2}I_\phi V_{M,H}+o(1),
\qquad
Q_{UV}^{[2]}=\sigma_U\sigma_V\ell_{M,H}^{2}I_\phi V_{M,H}+o(1).
\quad}\tag{3}
\]
把 $g\ge3$ 的所有层合在一起，所得首瓣 Gram 为 $o(1)$，逐个 $U,V$ 均成立。因此 scratch/920 的秩一主矩阵按物理 gcd 恰以 $8:1$ 分在互素层和 gcd 为 $2$ 的层上。因 $\ell_{M,H}$ 与 $V_{M,H}$ 都有统一正下界，两个层的 $PP,CC$ 自块为正，$PC,CP$ 交叉块为负。

对 scratch/859 式 (12) 的**原始过滤源门**，按同样的物理行类别和 $(m,n)=g$ 取 $K_0<|m-n|\le L$，式 (3) 仍成立，误差为 $o(1)$。原始门中 $g\ge3$ 的合并首瓣也是 $o(1)$。这些陈述不估计更远距离的固定幂 signed covariance。

## 共同整除的局部密度

对正整数 $k\le H$ 置
\[
\rho_k(x)=\phi(x)\sum_{\substack{q\le H\\k\mid q}}
\frac{\beta(q)}{q\log(Mx/q)},
\quad I_k=\int_1^2\rho_k(x)^2\,dx,
\quad U_m^{(k)}=\mathbf1_{k\mid m}U_m.
\tag{4}
\]
若 $m=pq$ 属于 $P$ 扇区，则 $p>M/H>H\ge k$，故 $k\mid m$ 当且仅当 $k\mid q$。scratch/920 式 (5) 的逐 $q$ 素数短区间证明因此不变，只把 $q$ 限于 $k\mid q$：对任意固定 $A>0$，一致于 $k\le H$、$|I|\le L$，
\[
\sum_{m\in I}P_m^{(k)}
=\frac1M\int_I\rho_k(t/M)\,dt
+O_A\!\left(\frac LM(\log M)^{-A}\right).
\tag{5}
\]
这里统一误差使用 $\sum_{q\le H}|\beta(q)|/q\ll\log M$，并未假设不同 cofactor 独立。

完整高除数行的对应整除短和也为零。事实上 scratch/918 式 (5) 在 $k\mid m$ 的限制下变成
\[
\sum_{\substack{m\in I\\k\mid m}}a_D(m)
=-\frac1M\sum_{t<32H}\alpha(t)
\sum_{\substack{d>D,\ td\in I\\ k/(k,t)\mid d}}
\mu(d)\phi(td/M).
\tag{6}
\]
对每个 $t$，$d\asymp x=M/t$，母区间长 $T_t=\lceil L/t\rceil+2$；scratch/918 式 (6) 已证明 $T_t/x^{5/8}\gg M^{1/32}$，且 $T_t\ll x^{23/24}<x/\log^{20B}x$。原论文 Proposition 3.4(i) 取 $\varepsilon=1/24$、模数 $r=k/(k,t)$ 和剩余类 $a=r$，对长度处于 $[x^{5/8},T_t]$ 的区间一致给
$\sum_{d\equiv0\pmod{k/(k,t)}}\mu(d)=O_B(T_t(\log M)^{-B})$；长度短于 $x^{5/8}$ 时，平凡界 $O(x^{5/8})$ 由上述幂次余量吸收。故此界适用于母区间内的每个子区间，包括 $d>D$ 的端点截断。对 $\phi(td/M)$ 离散 Abel 求和，再用 $\sum_{t<32H}|\alpha(t)|/t\ll\log^2M$，得到一致于 $k\le H$ 的
\[
\sum_{m\in I}\mathbf1_{k\mid m}a_D(m)
=O_A\!\left(\frac LM(\log M)^{-A}\right).
\tag{7}
\]
于是 (5) 对 $C^{(k)}$ 的密度为 $-\rho_k$。

给定任意固定 $B>0$，上述误差一致适用于 $k\le Q=\lfloor(\log M)^B\rfloor$。重复 scratch/920 式 (8)--(9) 的两次 Abel 求和，使用 $\sum|U_m^{(k)}|\le\sum|a_D(m)|\ll\log^2M$、$\sup_{|r|\le L}|J_H(r)|+\operatorname{Var}_{[-L,L]}J_H\ll H$，可得对每个固定 $A,B>0$
\[
\sum_{\substack{|m-n|\le L\\k\mid m,n}}
U_m\overline{V_n}J_H(m-n)
=\sigma_U\sigma_V V_{M,H} I_k
+O_{A,B}((\log M)^{-A})
\quad(k\le Q).
\tag{8}
\]
这里 $\|\rho_k\|_{C^1}\ll1$ 一致，平滑密度在距离 $L$ 内的变化只花 $O(H^{-1})$。

## 密度只留下 $k=1,2$

由 scratch/917 式 (5)，
\[
\beta(q)=4\Lambda(q)-2\mathbf1_{2\mid q}\Lambda(q/2)+4(\log2)\mu(q).
\tag{9}
\]
对固定 $k$，经典素数定理及其 Möbius 零均值定量式给，任意固定 $A>0$，
\[
\sum_{\substack{q\le X\\k\mid q}}\beta(q)
=\kappa_kX+O_{A,k}\!\left(\frac{X}{\log^A(2X)}\right),
\quad
\kappa_1=3,\quad\kappa_2=-1,\quad\kappa_k=0\ (k\ge3).
\tag{10}
\]
确实 $k=1$ 时两条 $\Lambda$ 均值分别为 $4X$ 与 $-X$；$k=2$ 时只有第二条给 $-X$；$k\ge3$ 时，$k\mid q$ 的 $\Lambda(q)$ 只可能取自同一素数的幂，$k\mid2r$ 的 $\Lambda(r)$ 也只可能取自同一素数的幂，合计 $O_k(\log^2X)$。$\sum_{q\le X,k\mid q}\mu(q)=O_{A,k}(X/\log^A(2X))$：若 $k$ 不平方自由，左侧恒零；若 $k$ 平方自由，则写 $q=kt$、$(t,k)=1$，从经典 $\sum_{n\le X}\mu(n)=O_A(X/\log^A(2X))$ 逐个排除 $k$ 的有限个素因子即可得到。

对 (10) 作分部求和，在 $1\le x\le2$ 上一致有
\[
\rho_k(x)=\kappa_k\ell_{M,H}\phi(x)+O_{k,\psi}(1/\log M).
\tag{11}
\]
为控制随 $M$ 增长的 $k$，还需一个可和的上包络。式 (9) 与 $\sum_{n\le X}\Lambda(n)/n\ll\log(2X)$ 给
\[
\sum_{\substack{q\le H\\k\mid q}}\frac{|\beta(q)|}{q}
\ll\frac{\log(2M)}k\qquad(k\ge1).
\tag{12}
\]
其中 $\mu$ 部分是 $k^{-1}\sum_{t\le H/k}t^{-1}$；$\Lambda(q)$ 部分只在 $k=1$ 或 $k$ 为素数幂时非零，后一情形为几何级数 $O((\log k)/k)$；$\Lambda(q/2)$ 用 $k'=k/(k,2)$ 同理处理，且 $k'\ge k/2$。因 $\log(Mx/q)\asymp\log M$，(12) 给 $\|\rho_k\|_\infty\ll_\psi1/k$，从而 $I_k\ll_\psi k^{-2}$。式 (11) 对每个固定 $k\ge3$ 给 $I_k\to0$；被 $k^{-2}$ 支配的级数收敛，故
\[
\sum_{k\ge3}I_k=o(1),\qquad
I_1=9\ell_{M,H}^{2}I_\phi+o(1),\qquad
I_2=\ell_{M,H}^{2}I_\phi+o(1),
\tag{13}
\]
一致于允许的 $H$。一致性可先固定有限的 $k$，用 (11) 的误差，再以 (12) 控制其余 $k$。

## 除数反演的尾与原过滤门

令 $B(m)=\sum_{d>D}|b_d(m)|$。因 $P,C$ 是把 $a_D$ 按物理位置拆开的不相交限制，$|P_m|,|C_m|\le B(m)\ll_\psi (\log M)\tau(m)/M$。对 $Q\ge2$，非对角共同除数尾满足
\[
\sum_{k>Q}
\sum_{\substack{m\ne n,\ k\mid m,n\\|m-n|\le L}}
B(m)B(n)|J_H(m-n)|
\ll_\psi\frac{\log^8(2M)}Q.
\tag{14}
\]
证明只需写 $m=ka,n=kb$。对固定非零 $j=a-b$，$\tau(ka)\le\tau(k)\tau(a)$、Cauchy--Schwarz 和 $\sum_{a\le2M/k}\tau(a)^2\ll(M/k)\log^3(2M)$ 给 $a,b$ 和 $O((M/k)\log^3M)$。因 $|j|\le L/k$、$|J_H(kj)|\ll H$，对该 $k$ 的费用为
$O((HL/M)\log^5M\,\tau(k)^2/k^2)$；求和并用 $HL/M\ll1$、$\sum_{k>Q}\tau(k)^2/k^2\ll\log^3(2Q)/Q$，即得 (14)。对角完整质量由 scratch/859 式 (9) 为 $O(H\log^5M/M)$，乘任意固定对数幂仍为 $o(1)$。

取 $Q=(\log M)^{10}$。对 $(m,n)=1$ 使用 $\mathbf1_{(m,n)=1}=\sum_{k\mid m,n}\mu(k)$；对 $(m,n)=2$ 使用 $\mathbf1_{(m,n)=2}=\sum_{j\mid m/2,n/2}\mu(j)$。式 (14) 支付 $k>Q$ 的尾；式 (8) 在 $k\le2Q$ 可预选任意大的对数节省指数，故有限求和的误差为 $o(1)$。把对角的 $o(1)$ 去掉，再用 (13)，得到
\[
Q_{UV}^{[1]}=\sigma_U\sigma_V V_{M,H}(I_1-I_2+o(1)),
\qquad
Q_{UV}^{[2]}=\sigma_U\sigma_V V_{M,H}(I_2+o(1)),
\]
即 (3)。scratch/920 式 (3) 给未按 gcd 分层的首瓣主项 $V_{M,H}I_1$；两式相减说明 $g\ge3$ 的合并层为 $o(1)$。

最后 $G\ge H\ge2$。scratch/917 式 (2) 在 $(m,n)=1,2$ 的每个物理配对上，把原过滤源项**精确**合成 $U_m\overline{V_n}J_H(m-n)$。从 $|m-n|\le L$ 删去 $|m-n|\le K_0$ 的全部无符号费用由 scratch/859 式 (10) 为 $O(H^4/(M\log^2M))=o(1)$。对 $g\ge3$ 的合并层，$(m,n)>G$ 的原过滤源项由 scratch/917 式 (3) 一次性支付 $O(\log^8M/G)=o(1)$；同样删去近差，便得到原过滤门的其余断言。$\square$

## 共同被 3 整除的下一阶主项

合并的 $g\ge3$ 层为 $o(1)$，但其中一个自然子层不能按目标固定幂量级删除。对 $k=3$，式 (4) 的密度有更精确的一致极限
\[
\boxed{\quad
\rho_3(x)=\frac{3\log3}{2\log M}\phi(x)
+o_\psi((\log M)^{-1})
\quad(1\le x\le2).
\quad}\tag{15}
\]
事实上，$3\mid q$ 的两条素数幂贡献绝对收敛，且
\[
4\sum_{j\ge1}\frac{\log3}{3^j}
-\sum_{j\ge1}\frac{\log3}{3^j}
=\frac32\log3.
\]
第二和来自 $q=2\cdot3^j$。Möbius 项的普通级数 $\sum_{3\mid q}\mu(q)/q$ 收敛且为零：式 (10) 所用的固定模数 Mertens 界保证收敛，而其 Dirichlet 级数
$-3^{-s}(1-3^{-s})^{-1}/\zeta(s)$ 在 $s\downarrow1$ 趋于零。将该级数乘有界、单调且总变差一致有界的
$\log M/\log(Mx/q)$，截到 $q\le H$ 后仍趋于零；先固定有限头部，再对尾部作一次 Abel 求和即可证明，此处一致于 $x\in[1,2]$ 及允许的 $H$。素数幂级数由支配收敛处理，遂得 (15)。

把 (15) 代入 (8)，并在其对数误差中选 $A>3$，得到对四个 $U,V\in\{P,C\}$ 的真实物理首瓣
\[
\boxed{\quad
\sum_{\substack{3\mid m,n\\|m-n|\le L}}
U_m\overline{V_n}J_H(m-n)
=\sigma_U\sigma_V\frac{9(\log3)^2}{4(\log M)^2}
I_\phi V_{M,H}+o((\log M)^{-2}).
\quad}\tag{16}
\]
特别地 $PP$ 自块严格为正，量级恰为 $(\log M)^{-2}$。该共同整除条件是 $(m,n)$ 被 $3$ 整除，未声称恰有 $(m,n)=3$。

式 (16) 的 $PP$ 主项还保留在**原始过滤源门**的 $K_0<|m-n|\le L$ 中。这里 $K_0=\lfloor H^3/\log^7(2M)\rfloor$ 取 scratch/859 的原定义。对任意长 $K_0$ 的物理区间 $I$，Brun--Titchmarsh 给每个 $q\le H$ 的素数数目
$\#\{p:pq\in I\}\ll K_0/(q\log M)$，因为 $K_0/q\gg M^{2/5-o(1)}$；故
\[
\sup_{|I|\le K_0}\sum_{m\in I}|P_m|
\ll_\psi\frac{K_0}{M\log M}
\sum_{q\le H}\frac{|\beta(q)|}{q}
\ll_\psi\frac{K_0}{M}.
\]
用 $\sum|P_m|\ll1$、$|J_H|\ll H$，$PP$ 近差的绝对费用为
$O(HK_0/M)=O(H^4/(M\log^7M))=o((\log M)^{-2})$。scratch/917 式 (2)--(3) 将其余小物理 gcd 的原过滤源项精确重组，而大物理 gcd 的合计误差
$O(\log^8M/G)=O(H^3\log^4M/M)=o((\log M)^{-2})$。因此 (16) 的 $PP$ 式在原过滤源门的这一共同整除 $3$ 子层上亦成立。它显示 $g\ge3$ 的合并 $o(1)$ 不能提升为按子层的目标固定幂删除。

## 每个低共同除数的完整带通补偿

式 (5)、(7) 还确定同一共同整除层的远旁瓣。对 $k\le Q=(\log M)^B$，置
$s_m^{(k)}=\rho_k(m/M)/M$，在物理窗外置零。$U_m^{(k)}-\sigma_U s_m^{(k)}$ 的每个长度 $L$ 循环滑窗和，由 (5)、(7) 为
$O_A((L/M)(\log M)^{-A})$；把连续密度积分换成离散 $s^{(k)}$ 的误差为 $O(M^{-1})$，也被此界吸收，跨窗接缝则至多分成两个物理区间。若 $w_H(h)\ne0$，则 $|h|L/M\le1/8$，长 $L$ 的几何和模长 $\gg L$。具体地，令 $b_m=U_m^{(k)}-\sigma_U s_m^{(k)}$、$F_x=\sum_{j=0}^{L-1}b_{x-j}$（模 $M$），其 Fourier 系数满足 $\widehat F_h=\widehat b_h D_L(h)$，其中 $D_L(h)=\sum_{j=0}^{L-1}e(-hj/M)$。循环 Parseval 给
\[
\sum_{h\bmod M}|\widehat b_h|^2|D_L(h)|^2
=M\sum_{x\bmod M}|F_x|^2
\ll L^2(\log M)^{-2A};
\]
在带通支撑上 $|D_L(h)|\gg L$，所以中心化序列的完整带通能量为 $O_A((\log M)^{-A})$，误差指数可在短窗估计中预先增大。另一方面 $\rho_k\in C_c^3((1,2))$ 且三阶范数对 $k$ 一致有界，三次分部积分使 $s^{(k)}$ 的带通能量为 $O(H^{-5})$。于是正权 $w_H$ 下的 Cauchy--Schwarz 给
\[
\sum_{h}w_H(h)
\left(\sum_{\substack{M<m<2M\\k\mid m}}U_me(-hm/M)\right)
\overline{\left(\sum_{\substack{M<n<2M\\k\mid n}}V_ne(-hn/M)\right)}
=O_{A,B}((\log M)^{-A})
\quad(k\le Q).
\tag{17}
\]

对 $k>Q$ 的非对角共同除数，沿 scratch/868 式 (7)--(10) 的逐 $k$ 证明使用
$\sum_{j\ne0}|J_H(kj)|\ll M/k$，得到总绝对费用
$O(\log^8M/Q)$。对角共同除数总费用至多
\[
\frac{H\log^2M}{M^2}
\sum_{m\le2M}\tau(m)^3
\ll\frac{H\log^9M}{M},
\]
其中 $\tau^3\le d_8$ 逐素数幂成立。取 $Q=(\log M)^{A+12}$、在 (17) 中预选更大的对数指数，再作同于式 (3) 的 Möbius 反演，即得对 $g=1,2$ 和每个 $U,V\in\{P,C\}$ 的完整带通界
\[
\boxed{\quad
\sum_{\substack{(m,n)=g\\M<m,n<2M}}
U_m\overline{V_n}J_H(m-n)
=O_A((\log M)^{-A})
\quad(g=1,2).
\quad}\tag{18}
\]
固定 $k=3$ 时不用反演，式 (17) 直接给共同被 $3$ 整除的完整带通界，同样为任意固定负对数幂。因此从 (3)、(16) 分别减去 (18)、(17)，在同一 gcd 层或同一整除层的**远旁瓣**得到
\[
\begin{aligned}
\sum_{\substack{(m,n)=1\\|m-n|>L}}U_m\overline{V_n}J_H(m-n)
&=-8\sigma_U\sigma_V\ell_{M,H}^{2}I_\phi V_{M,H}+o(1),\\
\sum_{\substack{(m,n)=2\\|m-n|>L}}U_m\overline{V_n}J_H(m-n)
&=-\sigma_U\sigma_V\ell_{M,H}^{2}I_\phi V_{M,H}+o(1),\\
\sum_{\substack{3\mid m,n\\|m-n|>L}}U_m\overline{V_n}J_H(m-n)
&=-\sigma_U\sigma_V\frac{9(\log3)^2}{4(\log M)^2}
I_\phi V_{M,H}+o((\log M)^{-2}).
\end{aligned}\tag{19}
\]
第三行使用 (17) 时取 $A>3$。这些是带符号的距离补偿，不表示旁瓣核逐项有固定符号。

## 边界

式 (3) 说明这一真实高除数扇区的首瓣常数补偿在互素层占八份、gcd 为 $2$ 的层占一份；式 (16)、(19) 又给出共同整除 $3$ 子层的非零下一阶主项及同层旁瓣补偿。低于四分之一次幂的观察频带仍要求 $H^4M^{-1+\varepsilon}$ 的固定幂估计，不能从这里的短和、gcd 分层或任意对数幂误差推出。全尺度局部 Weil 正性和 RH 仍未证明。
