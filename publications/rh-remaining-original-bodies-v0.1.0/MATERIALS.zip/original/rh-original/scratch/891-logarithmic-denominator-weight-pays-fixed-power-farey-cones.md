# 分母对数权重与大分子因子支付外侧有理锥至五分之一次幂（待异源复核）

日期：2026-10-01。本稿修正并加强 [scratch/890](890-bounded-incoming-prime-load-pays-subexponential-farey-denominators.md)：精确有理乘积层内的大素数入边用目标分母的素因子对数支付；低高标签之间的素数幂再用分子中的大完整素因子支付。由此对任意固定 \(\alpha<1/5\) 得到分母 \(B\le X^\alpha\) 的正锥。单槽闭形式采用 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的精确公式；算术平移采用 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的约定。以下是候选证明，尚无异源复核，故不晋级为权威 note。

## 定理

令 \(X\to\infty\) 为实尺度，\(H=\log X\)，\(k=X^2\)，\(w=\tfrac12\log(1+X^{-2})\)。对 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的每个原槽中心 \(y\in\mathcal G_X^\circ\subset(X/8,X/2)\)，令 \(N_y=\lfloor y/2\rfloor\) 和
\[
\mathcal R_{y,B}=\{1\}\cup\left\{a/b:5\le a/b\le N_y,\ (a,b)=1,\ 1\le b\le B\right\},
\qquad 1\le B\le X^{1/5}.
\tag{1}
\]
在中心 \(\log(Xy/r)\) 取长度 \(w\) 的上臂槽及其奇反射，记全部有限能量轮廓的闭形式压缩空间为 \(\mathscr V_{y,B}\)。异臂算术算子 \(E_{y,B}\) 和真实旧奇 Weil 形式满足，对所有 \(y,B\) 一致的绝对常数 \(C\) 有
\[
\boxed{\|E_{y,B}\|\le 3\log B+C\sqrt H,\qquad
A_{X^2,-}|_{\mathscr V_{y,B}}\succeq
\bigl(H-5\log B-C\sqrt H\bigr)I.}
\tag{2}
\]
因此 \(\log B=o(H)\) 时，全部这些压缩有 \((1-o(1))H\) 正隙。对每个固定 \(0<\alpha<1/5\)，在整个 \(B\le X^\alpha\) 范围内，谱隙至少为 \((1-5\alpha-o(1))H\)。式 \(2\) 在 \(B=X^{1/5}\) 的上端点也成立，但该下界在那里只有 \(-O(\sqrt H)\)，不判定端点正性。

令 \(e_{y,1}\) 为根槽的单位常值轮廓，\(R_{y,B}\) 为消去所有 \(r>1\) **完整有限能量轮廓**的真闭形式 Schur 扣款。若 \(\log B=o(H)\)，则
\[
\boxed{\left(\tfrac14+o(1)\right)H\le R_{y,B}
\le(1-\log2+o(1))H,\qquad
A_{X^2,-}[e_{y,1}]-R_{y,B}\ge(1+\log2-o(1))H.}
\tag{3}
\]
更一般地，固定 \(0<\alpha<1/5\) 且 \(B\le X^\alpha\)，对 \(\beta_B=(\log B)/H\in[0,\alpha]\) 令
\[
F(\beta)=1-(1-5\beta)\log\frac{2-5\beta}{1-5\beta}.
\]
则一致有 \(R_{y,B}\le(F(\beta_B)+o(1))H\) 和
\(A_{X^2,-}[e_{y,1}]-R_{y,B}\ge(2-F(\beta_B)-o(1))H\)，而
\(R_{y,B}\ge(\tfrac14+o(1))H\) 保持不变。特别在 \(B=\lfloor X^{1/7}\rfloor\) 时，上界系数为 \(1-\tfrac27\log(9/2)\)，枢轴下界系数为 \(1+\tfrac27\log(9/2)\)。

## 槽几何及同臂成本

根的半宽槽包含于原 \(y\) 槽；所有 \(r\ge5\) 的物理点 \(y/r\le X/10<X/8\)，故新增槽与整个原 \(V_{\mathcal G_X^\circ}\) 正交。又因 \(r\le y/2\)，各新增上臂点 \(y/r\ge2\)，上下臂均位于旧区间内部。

不同既约标签相距至少 \(B^{-2}\)；因 \(r\le X/4\)，其对数中心相距 \(\gg (XB^2)^{-1}\gg w\)。若一个素数幂平移 \(s\ge2\) 使同臂两槽相交，将 \(r=a/b,r'=c/d\) 代入得到整数 \(sad-cb\) 的绝对值 \(O(B^2/X)<1\)，故必有 \(sr=r'\)，两个轮廓坐标精确重合。取上臂轮廓的 \(L^2(0,w)\) 直和坐标，同臂算术块是
\[
-2\mathop{\rm Re}\sum_{r'=sr}\frac{\Lambda(s)}{\sqrt s}\langle h_r,h_{r'}\rangle.
\tag{4}
\]

note 790 的单槽闭形式下界是 \(2H-O(1)\)，与槽位置和有限能量轮廓无关。相离 Archimedean 核满足 \(K(d)\ll d^{-1}+1\)。固定 \(a/b\)，按另一分母 \(d\le B\) 排序：最近的不同有理数距离至少 \(1/(bd)\)，其余相隔至少 \(1/d\)。先对分子、再对 \(d\) 求和，得同臂非对角绝对行和 \(O((B^3+B^2H)/X)=o(1)\)。两臂中心至少相隔 \(2\log2\)，其非算术行和为 \(O(B^2/X)=o(1)\)。奇 polar 的投影范数由每槽的 \(O(wX/r)\) 质量控制，为 \(O(B^2H/X)=o(1)\)。这些估计在 \(B\le X^{1/5}\) 一致，并在单槽形式域的有限直和上延拓到闭形式。

令 \(C_{y,B}\ge0\) 是式 \(4\) 的边权矩阵，取 \(v_{a/b}=(ab)^{-1/2}\)。对每个素数幂 \(s=p^j\)，沿 \(r\mapsto sr\) 约掉分母的前 \(v_p(b)\) 层各付 \(\log p\)，其余层付 \(\log p/p^h\)；沿 \(r\mapsto r/s\) 同理先约掉分子的前 \(v_p(a)\) 层。以 \(M(t)=\sum_{p^j\le t}\Lambda(p^j)/p^j\le\log t+O(1)\) 得逐行
\[
\frac{(Cv)_{a/b}}{v_{a/b}}
\le\log a+\log b+M(N_y/r)+M(B/b)
\le\log N_y+2\log B+O(1).
\tag{5}
\]
因此正权 Schur 检验给 \(\|C_{y,B}\|\le H+2\log B+O(1)\)。

## 精确反射层与低标签

异臂反射边 \((r,r',s)\) 只在
\[
\left|\log\frac{srr'}{y^2}\right|<w
\tag{6}
\]
时存在。固定 \(r\)，置 \(t=sr'\)。其约分后分母至多 \(B\)，而所有可能的 \(t\) 落在长度小于 \(1/(4r)\) 的区间内；不同此类有理数相距至少 \(B^{-2}\)。故一行至多有 \(1+CB^2/r\) 个不同的 \(t\)。若 \(r>B^2\)，该行的 \(t\) 唯一，精确乘积 \(P=rt=srr'\) 唯一。高标签间的边按 \(P\) 分块，且每块在共同槽坐标中恰为
\[
K_P\otimes J_{\delta_P},\qquad
K_P(r,r')=\frac{\Lambda(P/(rr'))}{\sqrt{P/(rr')}}
\mathbf1_{\{P/(rr')\text{ 为整数素数幂}\}},\quad
\delta_P=\log(P/y^2).
\tag{7}
\]
这里沿用前文的 \(L^2(0,w)\) 左端点坐标，部分反射应写为
\[
(J_\delta h)(t)=\mathbf1_{\{0<w-t+\delta<w\}}h(w-t+\delta),
\qquad 0<t<w.
\]
对活跃块有 \(|\delta|<w\)，所以它是非零部分等距，范数恰为一；当 \(\delta=0\) 时就是整槽反射 \(h(w-t)\)。若改用居中坐标 \(z=t-w/2\in(-w/2,w/2)\)，同一算子才写作 \(\mathbf1_{\{|z-\delta|<w/2\}}h(\delta-z)\)。相邻高标签必有同一个 \(P\)，所以 \(\|E^{\rm hi}\|=\max_P\|K_P\|\)。

低标签 \(r\le B^2\) 可忽略，但须逐行证明。对固定 \(t=A/D\)（既约），\(A\ll X^2B\)。若 \(s=p^j\mid A\)，以 \(Z=\log(A+2)\ll H\) 切分，并用 Chebyshev 界及 \(\sum_{p^j\mid A}\Lambda(p^j)=\log A\)，其 \(\Lambda(s)/\sqrt s\) 总和为 \(O(\sqrt H)\)。若 \(j>v_p(A)\)，约分后目标分母含 \(p^{j-v_p(A)}\le B\)。

要估计低行，先保留反射几何给出的更强下限：\(r'=t/s\le X/4\)、\(y\ge X/8\) 强迫 \(s\ge cX/r\)。若 \(j>v_p(A)\)，置 \(h=j-v_p(A)\)，则 \(p^h\le B\)，因此
\[
p^{v_p(A)}=s/p^h\ge cX/(rB)\ge cX/B^3.
\]
在 \(B\le X^{1/5}\) 下，右侧至少为 \(cX^{2/5}\)。不同此类底数 \(p\) 的完整因子 \(p^{v_p(A)}\) 互素、乘积整除 \(A\ll X^2B\)，故只有绝对常数个；每个 \(p\) 的所有允许 \(h\) 的无权 \(\Lambda(p^j)\) 总和至多 \(\log B\)。加上 \(s\mid A\) 的无权质量 \(\log A=O(H)\)，固定 \(t\) 的全部反射边有无权质量 \(O(H)\)，有权质量则为 \(O(H\sqrt{r/X})\)。乘以至多 \(1+CB^2/r\) 个 \(t\)，低标签绝对行和至多
\[
\varepsilon=O\!\left(\frac{HB^2}{\sqrt X}\right)=o(1).
\tag{8}
\]
对高行 \(r>B^2\) 而目标低标签 \(r'\le B^2\)，该行只有一个 \(t\)，且 \(s=t/r'\ge cX/B^2\)。同一大完整因子计数（此时 \(s/p^h\ge cX/B^3\)）给高低块的最大行和
\[
\nu=O\!\left(\frac{HB}{\sqrt X}\right).
\]
按低／高标签分块，低低块范数至多 \(\varepsilon\)，低高块由矩形 Schur 检验至多
\[
\sqrt{\varepsilon\nu}
=O\!\left(\frac{HB^{3/2}}{\sqrt X}\right)=o(1)
\quad(B\le X^{1/5}).
\]
因此
\[
\|E_{y,B}\|\le\max_P\|K_P\|+o(1),
\qquad
\|E_{y,B}P_{\{1\}}\|\le\varepsilon+\sqrt{\varepsilon\nu}=o(1).
\tag{9}
\]
这里 \(P_{\{1\}}\) 是根槽**整个** \(L^2(0,w)\) 轮廓空间的投影；因此也有 \(\|E_{y,B}e_{y,1}\|=o(1)\)。后一项并非只对常值轮廓成立。

## 分母对数权重

固定 \(P\)。对每个固定素数幂 \(s\)，映射 \(r\mapsto P/(sr)\) 是部分置换，故对应矩阵范数至多 \(\Lambda(s)/\sqrt s\)。下列五类边互不重叠且穷尽：

1. \(s=p\le H\)：\(\sum_{p\le H}(\log p)/\sqrt p\ll\sqrt H\)。
2. \(s=p^j, j\ge2, p\le T:=\max(B,H)\)：高次幂 \(j=2\) 的和为 \(\sum_{p\le T}(\log p)/p=\log T+O(1)\)，而 \(j\ge3\) 的和有界，故该类范数至多 \(\log B+O(\sqrt H)\)。
3. 余下 \(s=p, p>H\)，或 \(s=p^j, j\ge2, p>T\)，且 \(p\nmid bb'\)：写 \(P/r=A/D=s(a'/b')\) 为既约分数，便有 \(s\mid A\)。因为 \(A\ll X^2B\)，同上分子整除和界给此类每行总权 \(O(\sqrt H)\)；此类边对称，故范数同阶。
4. 余下 \(s=p, H<p\le B\)，且 \(p\mid b,b'\)：\(v_p(P)=1-v_p(b)-v_p(b')\le-1\)，所以 \(p\mid\operatorname{den}(P)\) 且 \(\operatorname{den}(P)\le B^2\)。此类 \(p\) 至多 \(2\log B/\log H\) 个，逐 \(p\) 部分置换范数之和为 \(O((\log B)/\sqrt H)=O(\sqrt H)\)。
5. 余下 \(s=p, H<p\le B\)，且 \(p\) 恰整除一个端点分母：将边定向到分母含 \(p\) 的目标 \(r'=a'/b'\)，记定向矩阵为 \(T_P\)。固定目标和 \(p\)，来源 \(r=P/(pr')\) 唯一；固定来源和 \(p\)，目标亦唯一。对任意 \(h\)，按目标逐行用权重 \(\log p\) 的 Cauchy：
   \[
   |(T_Ph)_{r'}|^2
   \le\left(\sum_{p\mid b'}\log p\right)
       \sum_{r'\leftarrow_p r}\frac{\log p}{p}|h_r|^2
   \le\log B\sum_{r'\leftarrow_p r}\frac{\log p}{p}|h_r|^2.
   \]
   对目标求和，再按唯一的 “来源、\(p\)” 归并，并用 \(\sum_{p\le B}(\log p)/p\le\log B+O(1)\)，得到
   \[
   \boxed{\|T_P\|^2\le\log B\sum_{H<p\le B}\frac{\log p}{p}
   \le\log B\,(\log B+O(1)).}
   \tag{10}
   \]
   该无向边类的矩阵为 \(T_P+T_P^*\)，范数至多 \(2\|T_P\|\le2\log B+O(1)\)。

注意第 2 类包含 \(B<p\le H\) 的高次幂；漏掉它们会使分类不完整。五类合并得 \(\|K_P\|\le3\log B+O(\sqrt H)\)，再由 \(9\) 证明 \(2\) 的第一式。单槽、\(5\) 及非算术 \(o(1)\) 合并证明 \(2\) 的第二式；对每个固定 \(\alpha<1/5\)，系数 \(1-5\alpha\) 严格为正。

## 根的完整轮廓 Schur 扣款

同臂根列精确等于 \(-b\otimes h_0\)，其中 \(h_0=w^{-1/2}\mathbf1_{(0,w)}\)，\(b_q=\Lambda(q)/\sqrt q\) 仅对整数素数幂 \(5\le q\le N_y\) 非零。非算术根列与反射根列由上式都是 \(o(1)\)。删除根后，对式 \(4\) 每条边以权重 \(v_r\) 配方；在整数素数幂 \(q\) 行，根边原占 \(\Lambda(q)\)。由 \(5\)、\(2\) 得补空间闭形式下界
\[
B_{y,B}^{\rm prof}\succeq
\bigoplus_{r\ne1}
\left(2H-\log N_y+\Lambda(r)\mathbf1_{\{r\text{ 为整数素数幂}\}}
-5\log B-C\sqrt H\right)I.
\tag{11}
\]
这里 \(\Lambda(r)=0\) 若 \(r\) 不是整数素数幂。固定 \(\alpha<1/5\)、令 \(\beta_B=(\log B)/H\le\alpha\)；式 \(11\) 的分母至少为 \((1-5\beta_B)H+\Lambda(q)-O(\sqrt H)\ge(1-5\alpha-o(1))H\)。逆序比较、素数定理及高次素数幂的绝对可和性，在紧参数区间 \(\beta_B\in[0,\alpha]\) 上一致给
\[
R_{y,B}\le
\sum_{5\le q\le N_y\atop q\text{ 素数幂}}
\frac{\Lambda(q)^2/q}{2H-\log N_y-5\log B+\Lambda(q)-O(\sqrt H)}+o(H)
=H\int_0^1\frac{t}{1-5\beta_B+t}\,dt+o(H)
 =\bigl(F(\beta_B)+o(1)\bigr)H.
\tag{12}
\]
这里 \(\log N_y=H+O(1)\) 对全部原槽中心一致。若 \(\log B=o(H)\)，则 \(\beta_B\to0\)、\(F(0)=1-\log2\)，得到 \(3\) 的上界。

反向只在根与整数素数标签上试探。该子空间的不同素数标签之间无同臂边；反射可用 \(B=1\) 的式 \(2\) 单独估计为 \(O(\sqrt H)\)，其余交叉为 \(o(1)\)。素数定理给 \(\sum_{q\le N_y,\ q\text{ prime}}(\log q)^2/q=(\tfrac12+o(1))H^2\)，而素数试探向量的能量为 \((2H+o(H))\) 倍范数平方。逆度量变分得 \(R_{y,B}\ge(\tfrac14+o(1))H\)。根自能量是 \(2H+O(1)\)，于是 \(3\) 及 \(F(\beta_B)\) 的枢轴界成立。\(\square\)

## 边界

所得正性属于每个根的物理有理锥压缩；它没有估计该锥到完整旧奇空间其余部分的 Schur 反馈，也没有处理 moving-\(N\) Möbius signed covariance。因此它尚不推出全尺度局部 Weil 正性或 RH。指数 \(1/5\) 是本稿同臂成本 \(2\log B\) 与反射成本 \(3\log B\) 耗尽 \(H\) 的位置；式 \(2\) 在该端点不给正性，也不能由本稿推断更大指数或全 Farey 空间的正性。

后续 [scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md) 从 \(p>y\) 的真实素数平移构造该锥外的 \(H\) 级形式交叉列；故不能将未知正交补简单地当作小交叉扰动。
