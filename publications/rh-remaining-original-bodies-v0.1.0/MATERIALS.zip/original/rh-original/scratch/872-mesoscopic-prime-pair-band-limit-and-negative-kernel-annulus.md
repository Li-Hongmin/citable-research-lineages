# 中尺度素数对频带极限与同通道负环带

日期：2026-10-03。针对 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (15)、(19)--(22)，加强 [scratch 871](871-odd-prime-observation-band-self-cancels-near-positive-block.md)。这是解析推导，尚待异源独立复核；不把它称为真实 moving-\(N\) 算术门的证明。

固定非负、非零的实函数 \(\psi\in C_c^3((1,2))\)，以及 note 849 的非负偶函数 \(\eta\in C_c^\infty(\mathbb R)\)：其支撑在 \(1/2\le |t|\le4\)，且 \(\eta\ge1\) 于 \(1\le|t|\le2\)。令 \(Y\to\infty\) 沿整数，\(Y^{1/5}\le H\le Y^{1/4}\)，并设
\[
M=2Y,\quad D=M/H,\quad \varphi(t)=\psi(t)/t,\quad
b_p=-\frac4M(\log p)\varphi(p/M)\quad(p\text{ 为奇素数}),
\]
其余 \(b_m=0\)。取 \(e(x)=e^{2\pi i x}\)、\(\widehat\eta(v)=\int\eta(t)e(-tv)\,dt\)，并定义
\[
K_H(k)=\sum_{h\in\mathbb Z}\eta(h/H)e(-hk/M),\qquad
\mathcal C_I(Y,H)=
\sum_{p,q\text{ 奇素数}}b_pb_qK_H(p-q)
\mathbf1_{\{H(p-q)/M\in I\}}.
\tag{1}
\]

## 命题：固定缩放距离的精确极限

对每个固定有界区间 \(I\subset\mathbb R\)，**一致于上述全部 \(H\)** 有
\[
\boxed{\quad
\mathcal C_I(Y,H)
=16\left(\int_1^2\varphi(t)^2\,dt\right)
\left(\int_I\widehat\eta(v)\,dv\right)+o_{\psi,\eta,I}(1).
\quad}
\tag{2}
\]
同一极限也适用于有限个区间的并。这里 \(\widehat\eta\) 实且偶。

由 \(\eta(0)=0\)、Fourier 反演及 \(\widehat\eta(0)=\int\eta>0\)，存在固定 \(0<a<b<\infty\)，使 \(\widehat\eta(v)<0\) 对 \(a\le v\le b\) 成立。于是
\[
\boxed{\quad
\mathcal C_{[a,b]\cup[-b,-a]}(Y,H)
\longrightarrow
32\|\varphi\|_2^2\int_a^b\widehat\eta(v)\,dv<0.
\quad}
\tag{3}
\]
式 (3) 的每个距离 \(aD\le|p-q|\le bD\) 最终都位于 note 849 式 (15) 的中距离环带：\(K_0=H^3/\log^2(2Y)=o(D)\)，且 \(bD<Y^{1+\delta}/H=K_1\) 对任意固定 \(\delta>0\) 及充分大 \(Y\) 成立。由下文的 Poisson 公式，整个环带上 \(K_H(p-q)<0\) 对充分大 \(Y\) 逐项成立。

再令 \(I_0=[-1/32,1/32]\)。由 \(|t|\le4\) 与 \(|v|\le1/32\) 得 \(\cos(2\pi tv)\ge\cos(\pi/4)>0\)，故 \(\widehat\eta(v)>0\) 于 \(I_0\)。从 (2) 删除 \(|p-q|\le K_0\) 只改变 \(o(1)\)，从而
\[
\sum_{\substack{p,q\text{ 奇素数}\\ K_0<|p-q|\le Y/(16H)}}
b_pb_qK_H(p-q)
\longrightarrow
16\|\varphi\|_2^2\int_{-1/32}^{1/32}\widehat\eta(v)\,dv>0.
\tag{4}
\]
若把两次素数求和同时限制于 note 849 式 (19) 的闭区间 \(J\)，同一式成立，只需把 \(\|\varphi\|_2^2\) 换为 \(\int_J\varphi^2\)。证明时离 \(J\) 两端不超过 \(O(D)\) 的外层素数总 \(\log p\) 权至多 \(O(D)\)，其归一化贡献为 \(O(1/H)\)。因此 note 849 的**原近距子块**有此精确正常数极限；一个距离同为 \(\asymp Y/H\) 的负素数对环带也已在单独的奇素数通道中出现。

再记 note 849 式 (29) 的 Möbius 通道为
\[
u_m=-\frac{4\log2}{M}\mu(m)\varphi(m/M),
\qquad
\mathcal X_I=
\sum_{p\text{ 奇素数},m}b_pu_mK_H(p-m)
\mathbf1_{\{H(p-m)/M\in I\}}.
\]
对每个固定有界区间 \(I\)，存在固定 \(c_I>0\)，一致有
\[
\boxed{\qquad |\mathcal X_I|\ll_{\psi,\eta,I}e^{-c_IV_Y},\qquad
\left|\sum_{m,n}u_mu_nK_H(m-n)
\mathbf1_{\{H(m-n)/M\in I\}}\right|
\ll_{\psi,\eta,I}e^{-c_IV_Y}.\qquad}
\tag{4a}
\]
所以 (3)--(4) 的常数量级现象在任意固定缩放距离带内都无需 Möbius 交叉项；真正的 \(\mu\) 信息只能处在比此衰减更精细的量级。

## 完整真实系数的同窗交叉恒等式

令 \(c(m)\) 为 note 849 式 (10) 的**完整**系数，\(a_m=M^{-1}\varphi(m/M)c(m)\)，并置 \(d_m=a_m-b_m\)。对任意两序列 \(r,s\) 记
\[
\mathcal C_I(r,s)=\sum_{m,n}r_ms_nK_H(m-n)
\mathbf1_{\{H(m-n)/M\in I\}}.
\]
对每个固定有界区间 \(I\)，存在 \(c_I>0\)，使
\[
|\mathcal C_I(a,a)|+|\mathcal C_I(b,a)|
\ll_{\psi,\eta,I}e^{-c_IV_Y}.
\tag{4b}
\]
因此由**精确**分解 \(a=b+d\) 与式 (2)，
\[
\begin{aligned}
\mathcal C_I(b,d)
&=-16\|\varphi\|_2^2\int_I\widehat\eta(v)\,dv+o(1),\\
\mathcal C_I(d,d)
&=+16\|\varphi\|_2^2\int_I\widehat\eta(v)\,dv+o(1).
\end{aligned}
\tag{4c}
\]
特别在 \(I_0=[-1/32,1/32]\)，奇素数与其余完整真实系数的交叉项严格为负的常数量级；(4a) 表明其中的奇素数--Möbius 部分只有次指数级。这个同窗负交叉主要记录素数密度与完整系数中 \(\Lambda-1\) 的中心化，并不支付式 (15) 的固定幂余量。

## 证明

Heath--Brown 1982 的全区间短区间素数定理（原始输入及适用范围见 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md)）给出下述直接推论。对任何固定 \(A<B\)，一致于 \(x\asymp Y\) 和本命题的 \(H\)，
\[
\sum_{x+A D<p\le x+B D}\log p=(B-A)D+o(D).
\tag{5}
\]
这里素数幂的总贡献 \(O(\sqrt Y\log(2Y))=o(D)\)；长度 \((B-A)D\gg Y^{3/4}\) 的区间可分成长度 \(Y^{2/3}\) 的整块及一段余块，定理在每个整块一致给相对 \(o(1)\)，余块的平凡 \(O(Y^{2/3}\log Y)=o(D)\)。因此 (5) 对移动端点一致成立。

固定 \(p/M\) 于 \(\varphi\) 的紧支撑内。对任何固定区间 \(I\) 和其上连续函数 \(g\)，把 \(I\) 分成固定个小格，使用 (5)；由于 \(q=p-vD\) 时 \(\varphi(q/M)=\varphi(p/M)+O_{\varphi,I}(1/H)\)，再让小格宽度趋零，得到一致的内和极限
\[
\sum_{q\text{ 奇素数}}(\log q)\varphi(q/M)
g\!\left(\frac{H(p-q)}M\right)
\mathbf1_{\{H(p-q)/M\in I\}}
=D\varphi(p/M)\int_Ig(v)\,dv+o(D).
\tag{6}
\]
区间端点只改动 \(o(D)\)；\(p,q\asymp Y\)，故素数 \(2\) 无影响。

Poisson 求和给
\[
K_H(k)=H\sum_{j\in\mathbb Z}
\widehat\eta\!\left(H\left(\frac{k}{M}+j\right)\right).
\tag{7}
\]
当 \(v=Hk/M\in I\) 且 \(I\) 固定时，非零 \(j\) 的总和为 \(O_{\eta,I,A}(H^{1-A})\)，任意 \(A>1\) 可取。又 \(\sum_p|b_p|\ll1\)，所以 (1) 中把 \(K_H(k)\) 换为 \(H\widehat\eta(v)\) 的误差为 \(o(1)\)。在 (6) 中取 \(g=\widehat\eta\)，再用固定比例区间的素数定理
\[
\sum_{p\text{ 奇素数}}(\log p)\varphi(p/M)^2
=M\int_1^2\varphi(t)^2dt+o(M),
\tag{8}
\]
便有
\[
\mathcal C_I
=\frac{16H}{M^2}
\left[D\int_I\widehat\eta(v)dv+o(D)\right]
\left[M\|\varphi\|_2^2+o(M)\right]+o(1),
\]
由 \(HD=M\) 即得 (2)。

对 (4) 的删去项，用 note 849 式 (16) 同样的估计 \(\sum_p|b_p|^2\ll\log(2Y)/Y\)、\(|K_H(k)|\ll H\) 和每个差值的 Cauchy--Schwarz 界，得到
\[
\left|\sum_{|p-q|\le K_0}b_pb_qK_H(p-q)\right|
\ll HK_0\frac{\log(2Y)}Y
\ll\frac{H^4}{Y\log(2Y)}=o(1).
\]
这也包括对角项。\(\square\)

为证 (4a)，固定 \(I\)，令 \(Q=\lfloor Y^{2/3}\rfloor\)。[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (5) 对每个长度 \(Q\) 的移动区间给 \(\sum\mu=O(Qe^{-cV_Y})\)。将任何长度不超过 \(O_I(D)\) 的区间分为完整 \(Q\) 块及至多两个余块，后者用 \(|\mu|\le1\)，便有
\[
\sup_{\substack{J\subset[M,2M]\\|J|\le C_ID}}
\left|\sum_{m\in J}\mu(m)\right|
\ll_I De^{-cV_Y}+Q,
\qquad V_Y=(\log Y/\log\log Y)^{1/3}.
\tag{9}
\]
这里 \(C_I\) 是足以覆盖 \(I\) 的固定常数。对固定的外层指标 \(p\) 或 \(m\)，\(\varphi(n/M)\widehat\eta(H(x-n)/M)\mathbf1_{\{H(x-n)/M\in I\}}\) 在相应长度 \(C_ID\) 的区间上有一致的 \(O_{\psi,\eta,I}(1)\) 总变差。对 (9) 作 Abel 求和，内层 Möbius 和为 \(O(De^{-cV_Y}+Q)\)，对外层求绝对值的加权质量为 \(O(M)\)。与 (2) 的计算相同，前因子 \(H/M^2\) 使两种交叉和均为 \(O(e^{-cV_Y}+Q/D)\)。由于 \(Q/D\ll Y^{-1/12}\)，Poisson 的非零别名又由 (7) 和 \(\sum|b_p|+\sum|u_m|\ll1\) 支付，缩小 \(c_I\) 即得 (4a)。\(\square\)

式 (4b) 用同一论证，只把内层 \(\mu(m)\) 换成完整 \(c(m)\)。note 851 式 (7) 对每个长度 \(Q=\lfloor Y^{2/3}\rfloor\) 的移动区间给 \(\sum c=O(Qe^{-cV_Y})\)；不满 \(Q\) 的余段由 \(|c(m)|\ll\log Y\) 支付 \(O(Q\log Y)\)。故 (9) 对 \(c\) 的版本为 \(O_I(De^{-cV_Y}+Q\log Y)\)。加权 Abel 求和与 (7) 的非零别名仍适用。外层 \(\sum_m|c(m)|\ll M\) 来自 Chebyshev 界，因此得到 (4b)。式 (4c) 只是 \(d=a-b\) 的双线性展开；对非对称 \(I\)，\(\mathcal C_I(d,d)=\mathcal C_I(a,a)-\mathcal C_I(a,b)-\mathcal C_I(b,a)+\mathcal C_I(b,b)\)，而 \(\mathcal C_I(a,b)=\mathcal C_{-I}(b,a)\)，故也受 (4b) 对 \(-I\) 的估计。\(\square\)

## 整个奇素数通道的独立交叉检查

式 (2) 本身还可重得 [scratch 871](871-odd-prime-observation-band-self-cancels-near-positive-block.md) 的 \(\sum_h\eta(h/H)|P_h|^2=o(1)\)，其中 \(P_h=\sum_pb_pe(-hp/M)\)。事实上，\(\varphi\) 的支撑宽度小于 \(1\)，所以 (7) 在全部活动差值上满足
\[
|K_H(k)|\ll_{A,\psi,\eta}H(1+|Hk/M|)^{-A}+H^{1-A}.
\]
把 \(|H(p-q)/M|\) 分成宽度 \(1\) 的壳；由 (5)，每壳的 \(\sum_{p,q}|b_pb_q|\ll1/H\)，一致于壳位置。故 \(|H(p-q)/M|>B\) 的贡献绝对值至多 \(O_A(B^{1-A}+H^{1-A})\)。在固定 \([-B,B]\) 上用 (2)，再令 \(B\to\infty\)，利用 \(\int_{\mathbb R}\widehat\eta(v)dv=\eta(0)=0\)，得到整个 Gram 和趋零。这个核空间证明不使用 scratch 871 中的窗口 Parseval 步骤。

上述常数量级的负环带由 \(K_H\) 的符号产生；它不能给 note 849 式 (15) 所需的 \(H^4/Y\) 固定幂上界，也不能确定真正依赖大素数处 \(\mu\) 符号的剩余项。
