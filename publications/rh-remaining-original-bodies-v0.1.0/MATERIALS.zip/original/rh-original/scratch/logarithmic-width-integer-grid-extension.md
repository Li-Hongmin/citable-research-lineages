# 整数对数格谱隙延伸至临界对数宽（待复核）

沿用 note 854 的 $H=\log p$、$N=\lfloor p^2/16\rfloor$、$y_n=H-\log4-\log n$，但让共同槽宽满足
$0<\ell\le(100p^2H)^{-1}$。声称对全部有限能量轮廓一致有

$$\lambda(U_p(\ell))=\log(1/\ell)-\log N+O(1).$$

特别取 $\ell=(100p^2H)^{-1}$ 时，$|U_p|\asymp H^{-1}$ 且
$\lambda(U_p)=\log H+O(1)=\log\log p+O(1)$。

证明：$2N\ell<1$，所以 note 854 的整数位移唯一性及精确整除矩阵 $C_N$ 不变，其范数及权 $n^{-1/2}$ 的 Rayleigh 商均为 $\log N+O(1)$。各单槽 Fourier 成本下界为 $\log(1/\ell)-O(1)$，共同缩放光滑轮廓给匹配上界。

普通约化核跨槽行和为 $O(\ell N\log(2N))=O(\ell p^2H)=O(1)$，不再需要 $o(1)$。极点应使用乘积而非两个平方范数之和：由 note 854 的计算，

$$\|e^{y/2}1_U\|_2^2\ll p\ell H,\qquad
\|e^{-y/2}1_U\|_2^2\ll\ell p^3.$$

于是完整 $q_{\rm pol}(f)=2\Re(p_+(f)\overline{p_-(f)})$ 满足

$$|q_{\rm pol}(f)|\le2\|e^{y/2}1_U\|_2\|e^{-y/2}1_U\|_2\|f\|_2^2
\ll\ell p^2\sqrt H\|f\|_2^2=O(H^{-1/2})\|f\|_2^2.$$

同槽光滑余核为 $O(\ell)$；由前述 $O(1)$ 普通跨槽界和 polar 界，可逐项重复 note 854 的上下界。

须核验：普通跨槽块的正负及绝对行和；极点乘积界；$O(1)$ 对所有 $\ell$ 一致；命题对全部闭形式域有效；匹配上界是否有额外宽度相关项。

## 固定质量宽度的上界候选

另取固定 $0<c<1$、$\ell=c/p^2$；$2N\ell<1$ 仍保证精确整除矩阵。使用 note 854 的共同非负光滑轮廓及 $v_n=n^{-1/2}/\sqrt{L_N}$，其中 $L_N=\sum_{n\le N}1/n\asymp H$。主部为 $\log(1/\ell)+O(1)$，算术 Rayleigh 商为 $\log N+O(1)$。

普通核在此特定向量上的绝对交叉至多

$$\frac{C\ell}{L_N}\sum_{n\ne r}\frac1{\sqrt{nr}|\log(n/r)|}\ll\frac{\ell N\log(2N)}{L_N}=O(\ell N)=O_c(1).$$

双重和分 $n<r\le2n$ 与 $r>2n$：近区逐 $n$ 的和为 $O(\log(2n))$；远区逐 $n$ 的和为 $O(\sqrt{N/n})$；总和 $O(N\log N)$。

此特定轮廓的 polar 比其算子范数更小。因 $b_\ell\ge0$ 且 $\int b_\ell=O(\sqrt\ell)$，

$$|p_+(f)|\ll\frac{\sqrt{p\ell}}{\sqrt{L_N}}\sum_{n\le N}\frac1n
\ll\sqrt{p\ell L_N},\qquad
|p_-(f)|\ll\frac{\sqrt{\ell/p}}{\sqrt{L_N}}\sum_{n\le N}1
\ll\frac{N\sqrt{\ell/p}}{\sqrt{L_N}}.$$

故 $|q_{\rm pol}(f)|\ll\ell N=O_c(1)$。因此这个单位试函数满足
$Q_W^H[f]=\log(1/\ell)-\log N+O_c(1)=O_c(1)$，特别是
$\lambda(U_p(c/p^2))\le C_c$。这只限制谱隙的可能增长，不给谱底下界或全尺度正性。

## 整除矩阵的有限阶谱边缘候选

设 $\lambda_1(C_N)\ge\lambda_2(C_N)\ge\cdots$。对每个固定整数 $K\ge1$，声称

$$\lambda_j(C_N)=\log N+O_K(1)\qquad(1\le j\le K).$$

取 $v_n=n^{-1/2}$ 和 $d_n=(C_Nv)_n/v_n=\log N+O(1)$。对任意 $g_n=v_nh_n$，精确的 ground-state transform 为

$$
\sum_nd_n|g_n|^2-\langle g,C_Ng\rangle
=\sum_{k\ge2}\frac{\Lambda(k)}k\sum_{n\le N/k}\frac{|h_n-h_{kn}|^2}{n}.\tag{A}
$$

令 $h_n=F(\nu_2(n))$，其中 $F$ 支撑于 $\{0,\dots,K-1\}$。奇素数幂 $k$ 在 (A) 中给零；只有 $k=2^t$ 剩余。故

$$E\le4\|F\|_\infty^2(\log2)\sum_{t\ge1}2^{-t}H_{\lfloor N/2^t\rfloor}
\ll \|F\|_\infty^2\log N.$$

另一方面每个固定 $0\le j<K$ 有
$\sum_{n\le N,\nu_2(n)=j}1/n=(2^{-j-1}+o(1))\log N$，故
$\|g\|_2^2\gg_K\|F\|_\infty^2\log N$。因此 (A) 与 $d_n=\log N+O(1)$ 给整个 $K$ 维子空间的 Rayleigh 商下界 $\log N-O_K(1)$。Courant--Fischer 与 (4) 给上界，证得断言。

含义：整除矩阵的前任意固定多本征值都在谱顶的 $O_K(1)$ 窗口内，所以不能用一个随 $H$ 增长的简单第一本征值谱隙来支付 $\ell\asymp p^{-2}$ 的普通核交叉。这仍不判定两核合并后的谱底。

## 固定质量宽度的任意固定维近零能量空间（待复核）

取固定 $0<c<1$、$\ell=c/p^2$ 与同一固定非负单位 $b_\ell$。对每个固定 $K$，令 $F$ 支撑于 $\{0,\ldots,K-1\}$，定义
$f_F(y_n+t)=n^{-1/2}F(\nu_2(n))b_\ell(t)$。这些函数构成 $K$ 维空间，且
$\|f_F\|_2^2\gg_K L_N\|F\|_\infty^2$。

上一节的精确 ground-state transform 连同 $d_n=\log N+O(1)$ 给
$\langle f_F,(C_N\otimes I)f_F\rangle
=(\log N+O_K(1))\|f_F\|_2^2$。
Fourier 主部和同槽余核分别是 $(\log(1/\ell)+c_\varphi)\|f_F\|_2^2$、$O(\ell)\|f_F\|_2^2$。
普通跨槽核的绝对值以 $|F|\le\|F\|_\infty$ 和上一节双和估计支付：
$O(\ell N\log N\|F\|_\infty^2)=O_K(\ell N)\|f_F\|_2^2$。
又有
$|p_+(f_F)|\ll\sqrt{p\ell}L_N\|F\|_\infty$、
$|p_-(f_F)|\ll N\sqrt{\ell/p}\|F\|_\infty$，故
$|q_{\rm pol}(f_F)|\ll_K\ell N\|f_F\|_2^2$。
因此整个 $K$ 维空间满足

$$
Q_W^H[f_F]
=\bigl(\log(1/\ell)-\log N+O_{c,K}(1)\bigr)\|f_F\|_2^2
=O_{c,K}(1)\|f_F\|_2^2.
$$

其中 $O_{c,K}(1)$ 在所有非零 $F$ 上一致。这是多维有界能量试空间，不是谱底下界或全尺度正性。
