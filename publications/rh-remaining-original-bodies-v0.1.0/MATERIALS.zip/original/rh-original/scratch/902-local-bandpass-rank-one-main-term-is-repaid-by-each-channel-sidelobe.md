# 局部带通秩一主项由各通道远旁瓣自行偿还（候选）

日期：2026-10-02。沿用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实两端点系数、[scratch/901](901-local-middle-distance-four-channel-covariance-has-rank-one-main-term.md) 的四通道及带通核，并使用 [scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 式 (6)--(8) 已核对的 2023 年全区间短和定理。本文把 901 的局部极限分成极近差、局部环带和远旁瓣，给出任意固定对数幂精度；另用 Brun--Titchmarsh 上界在目标量级内无符号支付 \(|m-n|\le H^3\)。**没有证明剩余固定幂 signed 门、moving-\(N\) 算术门或 RH。**以下证明尚待异源复核。

## 命题

固定实值非负、非零的 \(\psi\in C_c^3((1,2))\)，以及 note 849 的非负偶带通函数 \(\eta\in C_c^\infty(\mathbb R)\)，其支撑在 \(1/2\le |t|\le4\)，并于 \(1\le|t|\le2\) 满足 \(\eta\ge1\)。令
\[
M=2Y,\qquad Y^{1/5}\le H\le Y^{1/4},\qquad
L=\left\lfloor\frac{M}{32H}\right\rfloor,\qquad
K_0=\left\lfloor\frac{H^3}{\log^2M}\right\rfloor,
\quad \varphi(u)=\frac{\psi(u)}u,
\quad K_H(k)=\sum_h\eta(h/H)e(-hk/M).
\tag{1}
\]
四个实序列 \(a^-,a^+,a^0,a^\mu\) 取 scratch/901 式 (2)；\(\kappa=(-4,1,3,0)\)。对任意一组整数距离 \(D\)，置
\[
C_{ij}(D)=\sum_{m,n:\,|m-n|\in D}a_m^ia_n^jK_H(m-n),\qquad
I_\varphi=\int_1^2\varphi(u)^2\,du,
\]
\[
J=I_\varphi\int_{-1/32}^{1/32}\widehat\eta(v)\,dv>0,
\qquad
J_0=I_\varphi\int_{-HK_0/M}^{HK_0/M}\widehat\eta(v)\,dv.
\tag{2}
\]
则对每个固定 \(A>0\)，一致于上述 \(H\) 及所有 \(i,j\in\{-,+,0,\mu\}\)，
\[
\boxed{\begin{aligned}
C_{ij}([0,K_0])&=\kappa_i\kappa_jJ_0+O_A((\log M)^{-A}),\\
C_{ij}([0,L])&=\kappa_i\kappa_jJ+O_A((\log M)^{-A}),\\
C_{ij}((L,\infty))&=-\kappa_i\kappa_jJ+O_A((\log M)^{-A}).
\end{aligned}}\tag{3}
\]
因而原局部环带还有细化式
\[
C_{ij}((K_0,L])
=\kappa_i\kappa_j(J-J_0)+O_A((\log M)^{-A}).
\tag{4}
\]
特别是单独的高素数通道在 \(|m-n|>L\) 的旁瓣中有
\(C_{--}((L,\infty))=-16J+O_A((\log M)^{-A})<0\)；局部高素数正块可以在**同一个通道**的远旁瓣获得常数量级补偿。真实联合系数 \(a_m=c(m)\psi(m/M)/m\) 则满足
\[
\boxed{\quad
\sum_{K_0<|m-n|\le L}a_ma_nK_H(m-n)
=O_A((\log M)^{-A})\quad}\tag{5}
\]
对每个固定 \(A>0\) 一致成立。式 (5) 比 scratch/901 的 \(o(1)\) 定量，但当 \(H\le Y^{1/4-\theta}\) 时仍比 note 849 式 (15) 的 \(H^4Y^{-1+\varepsilon}\) 弱。

## 证明：一阶密度及区间误差

取 \(B=\lfloor M^{2/3}\rfloor\)。scratch/862 式 (6)--(8) 对每个固定 \(A\) 给任意长度 \(B\) 的整数块中 \(\Lambda-1\) 与 \(\mu\) 的 \(O_A(B(\log M)^{-A})\) 和。把 \(\Lambda\) 换成素数上的 \(\log p\) 只产生 \(O(\sqrt M\log M)\) 的全区间素数幂质量。偶数通道以 \(m=2p\) 换元，区间长度成为 \(B/2+O(1)\)；该定理仍适用。对 \(M^{-1}\varphi(m/M)\) 作分部求和，并对常数通道直接数偶数，得到对每个长度 \(B\) 的 \(I\subset(M,2M)\)
\[
\sum_{m\in I}a_m^i
=\frac{\kappa_i}{M}\int_I\varphi(t/M)\,dt
+O_A\!\left(\frac B{M(\log M)^A}\right).
\tag{6}
\]
端点取整、素数幂和加权求积误差均为固定负幂，已吸收到 (6)。此处 \(\kappa_+=1\)：在 \(m=2p\) 坐标，\(2\log p/m\) 乘素数密度 \(1/(2\log p)\) 正好给 \(1/m\)；\(\kappa_0=3\) 来自偶数密度 \(1/2\)，故 \(\sum_i\kappa_i=0\)。

设 \(T\) 满足 \(M^{2/3+\rho}\le T\le2L\)，其中 \(\rho>0\) 固定。把任意长度不超过 \(2T\) 的区间分成整 \(B\) 块及至多两个端块。端块由 \(|a_m^i|\ll\log M/M\) 支付，且 \(B\log M=o(T(\log M)^{-A})\)。因此对所有这样的区间
\[
\left|\sum_{m\in I}a_m^i
-\frac{\kappa_i}{M}\int_I\varphi(t/M)\,dt\right|
\ll_{A,\rho}\frac T{M(\log M)^A}.
\tag{7}
\]
同理，把整段 \((M,2M)\) 分块再对 \(\varphi\) 加一次权，得
\[
\sum_m a_m^i\varphi(m/M)
=\kappa_i I_\varphi+O_A((\log M)^{-A}),
\qquad \sum_m|a_m^i|\ll1,
\qquad \sum_m|a_m^i|^2\ll\frac{\log M}{M}.
\tag{8}
\]

## 证明：近段主项

对 \(0\le T\le L\)，直接微分有限 Fourier 和给
\[
\sup_{|t|\le T}|K_H(t)|
+\operatorname{Var}_{[-T,T]}K_H\ll H,
\tag{9}
\]
因为 \(|K_H'|\ll H^2/M\) 且 \(T\le M/(32H)\)。若 \(T\ge M^{2/3+\rho}\)，固定 \(m\)，以 (7) 的前缀误差对 (9) 作 Abel 求和，得
\[
\sum_{|m-n|\le T}a_n^jK_H(m-n)
=\frac{\kappa_j\varphi(m/M)}M\sum_{|k|\le T}K_H(k)
+O_A\!\left(\frac{HT}{M(\log M)^A}
+\frac{HT^2}{M^2}\right).
\tag{10}
\]
第二误差来自 \(\varphi((m-k)/M)-\varphi(m/M)=O(T/M)\)。在 \(T=L\) 或 \(T=K_0\) 时，\(HT/M\ll1\)、\(HT^2/M^2\ll M^{-c}\) 对某固定 \(c>0\) 一致成立，故误差为任意固定负对数幂。

Poisson 求和以及 \(T\le L\) 给
\[
\frac1M\sum_{|k|\le T}K_H(k)
=\int_{-HT/M}^{HT/M}\widehat\eta(v)\,dv
+O_A((\log M)^{-A}).
\tag{11}
\]
非零别名有任意阶衰减，整数求积误差为 \(O(H/M)\)。把 (10)--(11) 乘以 \(a_m^i\) 求和并用 (8)，得到 \(T=L\) 的 (3) 第二式，因为 \(HL/M=1/32+O(H/M)\)。

对 \(T=K_0\) 分两种情况。若 \(H\le M^{9/40}\)，则 \(H^4/M\le M^{-1/10}\)，由 (8)、\(|K_H|\ll H\) 给近段绝对值
\[
|C_{ij}([0,K_0])|
\ll H(K_0+1)\frac{\log M}M
\ll M^{-1/10}\log M,
\]
同时 \(|J_0|\ll HK_0/M\ll M^{-1/10}\)；二者均小于任意固定负对数幂。若 \(H>M^{9/40}\)，则
\(K_0\gg M^{27/40}/\log^2M\gg M^{2/3+1/240}\)。式 (7)--(11) 可取 \(T=K_0\)，给 (3) 第一式。两种情况合并后 (4) 由相减得到。注意 \(K_0/L\ll1/\log^2M\)，故区间顺序正确。

## 证明：远旁瓣与真实联合系数

先对每个通道证明完整带通协方差为任意对数幂小。令
\(r_m^i=a_m^i-\kappa_i\varphi(m/M)/M\)。取整数窗长 \(L\)；式 (7) 给其每个周期滑动窗之和为 \(O_A((L/M)(\log M)^{-A})\)。\(\varphi\) 的紧支撑保证周期拼接窗经过零值区。带通支撑上 \(|h|L/M\le1/8\)，故窗的几何和模长 \(\gg L\)。周期 Parseval 与滑窗上界推出
\[
\sum_h\eta(h/H)
\left|\sum_m r_m^ie(-hm/M)\right|^2
\ll_A(\log M)^{-A}.
\tag{12}
\]
平滑密度 \(\varphi(m/M)/M\) 的同带 Fourier 能量由三次分部积分为 \(O(H^{-5})\)，也小于任意固定负对数幂。因此各通道自身的完整带通能量都为 \(O_A((\log M)^{-A})\)；\(\eta\ge0\) 与 Cauchy--Schwarz 再给每个混合通道的完整协方差
\[
\sum_{m,n}a_m^ia_n^jK_H(m-n)
=O_A((\log M)^{-A}).
\tag{13}
\]
用 (13) 减去 (3) 第二式，就得到第三式。因 \(J>0\)，\(i=j=-\) 的远旁瓣最终严格为负。

最后 note 849 式 (31)--(33) 给完整真实 \(a=\sum_i a^i+a^{\rm pp}\)，其中高次素数幂余项满足 \(\|a^{\rm pp}\|_1\ll M^{-1/2}\log M\)。任意距离限制下，含该项的 Gram 绝对值由 \(|K_H|\ll H\)、\(\sum_i\|a^i\|_1\ll1\) 界为 \(O(HM^{-1/2}\log M)\)，是固定负幂。由 (4) 对四通道求和，主项为
\((\sum_i\kappa_i)^2(J-J_0)=0\)，故得到 (5)。\(\square\)

## 更大的无符号近差支付

上面的 \(K_0=H^3/\log^2M\) 是为了保留 901 的精细环带坐标。若只问 note 849 式 (15) 的目标上界，其近差截断可无条件扩大。对完整真实系数 \(a_m=c(m)\psi(m/M)/m\)，有
\[
\boxed{\quad
\sum_{|m-n|\le H^3}|a_ma_nK_H(m-n)|
\ll_{\psi,\eta}\frac{H^4}{M}.
\quad}\tag{14}
\]
证明无需 Möbius 符号。置 \(T=H^3\)，则 \(T\gg M^{3/5}\) 且 \(T\ll M^{3/4}\)。Brun--Titchmarsh 短区间上界 \(\pi(x+u)-\pi(x)\ll u/\log u\) 对 \(x\asymp M\)、\(u\asymp T\) 给
\[
\sup_{x\asymp M}\sum_{x<n\le x+2T}\Lambda(n)\ll T.
\tag{15}
\]
这是因为素数权 \(\log p\ll\log M\asymp\log T\)，高次素数幂的**整个**相关区间质量 \(O(\sqrt M\log M)=o(T)\)。对 \(2\mathbf1_{2\mid n}\Lambda(n/2)\) 换元后相同；常数格和 \(\mu\) 由平凡界支付。因此对所有 \(m\in(M,2M)\) 一致有
\[
\sum_{|n-m|\le T}|a_n|\ll_\psi T/M.
\tag{16}
\]
再用 \(\sum_m|a_m|\ll1\)（note 849 式 (16)）与 \(|K_H(k)|\ll_\eta H\)，得到 (14)。对任何更小截断，(14) 的左侧绝对值总和仍是上界。

这个无符号尺度还是尖锐的：如果 \(H^3\le T\le L\)（该区间只在足够低于四分之一次幂的频带非空），则对真正的 \(a_m\) 有
\[
\boxed{\quad
\sum_{|m-n|\le T}|a_ma_nK_H(m-n)|
\asymp_{\psi,\eta}\frac{HT}{M}.
\quad}\tag{17}
\]
上界是 (15)--(16) 对长度 \(2T\) 的同一 Brun--Titchmarsh 论证。下界只取固定闭区间 \(J\subset(1,2)\) 上的素数 \(p,q\)，使 \(\psi\ge c_\psi>0\)。素数定理给 \(P=\#\{p:p/M\in J\}\asymp M/\log M\)。把 \(MJ\) 分成 \(O_J(M/T)\) 个长至多 \(T\) 的格，Cauchy--Schwarz 给同格异素数有序对数
\[
\sum_jP_j(P_j-1)
\ge \frac{P^2}{O_J(M/T)}-P
\gg_\psi\frac{MT}{\log^2M},
\]
因为 \(T\ge H^3\gg M^{3/5}\)。对这些配对，\(|p-q|\le T\le L\) 使 \(K_H(p-q)\gg_\eta H\)（每个 \(|h|\le4H\) 的余弦相位至多 \(\pi/4\)），且 \(|a_p a_q|\gg_\psi\log^2M/M^2\)。相乘即得 (17) 的下界。于是只要 \(T/H^3\to\infty\) 且 \(T\le L\)，逐对取绝对值的费用就超过 \(H^4/M\) 相同的发散因子；更远的近差必须使用符号抵消。

于是 note 849 式 (15) 的未付区间可以从 \(H^3<|m-n|\le Y^{1+\delta}/H\) 开始，近差只花 \(O(H^4/Y)\)。当 \(H\le Y^{1/4-\theta}\) 时，\(H^3/(M/H)\ll Y^{-4\theta}\)，仍留下从 \(H^3\) 到 \(M/H\) 的固定幂长度中距离区间。式 (14) 不适用于 scratch/859 按高除数绝对值展开后的 \(B(m)B(n)\)：那些除数重数带有额外对数代价。

## 带符号对数倍近差支付

现有短和定理还能支付任意固定对数倍的下一段。固定 \(B_1>0\)，置 \(T_{B_1}=\lfloor H^3(\log M)^{B_1}\rfloor\)。对每个固定 \(A>0\)，真实联合系数满足
\[
\left|\sum_{|m-n|\le T_{B_1}}a_ma_nK_H(m-n)\right|
\ll_{A,B_1,\psi,\eta}
\frac{H^4}{M}(\log M)^{2B_1-A}.
\tag{18}
\]
因此取 \(A>2B_1+2\)，左侧为 \(O_{B_1}(H^4/(M\log^2M))\)。这里保留真实符号；(17) 表明逐项绝对值做不到这一点。

证明仍从 scratch/862 式 (6)--(8) 出发，但把整块长度取为 \(B_*=\lfloor M^{71/120}\rfloor\)：指数 \(71/120>7/12\) 落在已核定理范围，且 \(B_*\log^C M=o(H^3)\) 对任意固定 \(C\) 一致成立，因为 \(H^3\gg M^{72/120}\)。该定理给每个 \(B_*\) 块上 \(\sum c(m)=O_A(B_*(\log M)^{-A})\)。对任意长度不超过 \(2T_{B_1}\) 的整数区间，用整块求和和两个平凡端块；在每个整块冻结 \(\varphi/M\)，其变化由 \(\sum_{m\in B_*}|c(m)|\ll B_*\log M\) 支付。这样得到
\[
\sup_{|I|\le2T_{B_1}}
\left|\sum_{m\in I}a_m\right|
\ll_{A,B_1,\psi}\frac{T_{B_1}}{M(\log M)^A}.
\tag{19}
\]
素数幂质量和取整端点也都比右侧小任意固定对数幂。由 \(|K_H|\ll H\)、\(|K_H'|\ll H^2/M\)，其在 \([-T_{B_1},T_{B_1}]\) 上的上确界与总变差之和为 \(O(H(1+HT_{B_1}/M))\)。固定外层 \(m\)，对 (19) 作 Abel 求和，再用 \(\sum_m|a_m|\ll1\)，得到
\[
\left|\sum_{|m-n|\le T_{B_1}}a_ma_nK_H(m-n)\right|
\ll_{A,B_1}\frac{HT_{B_1}}{M}
\left(1+\frac{HT_{B_1}}M\right)(\log M)^{-A}.
\]
因 \(HT_{B_1}/M=(H^4/M)(\log M)^{B_1}+O(H/M)\ll(\log M)^{B_1}\)，这就是 (18)。

所以 note 849 式 (15) 的未付区间可从 \(H^3(\log M)^{B_1}<|m-n|\le Y^{1+\delta}/H\) 开始，任意固定 \(B_1>0\) 均可选择；近差由 (18) 在目标量级内支付。当 \(H\le Y^{1/4-\theta}\) 时，\(H^3(\log M)^{B_1}/(M/H)\ll Y^{-4\theta}(\log M)^{B_1}\to0\)，仍留下固定幂长度的中距离区间。

## 决策边界

式 (3) 表明 901 看到的常数负交叉并非目标固定幂相消的唯一来源：每个非零密度通道自己的远旁瓣已有同量级反号主项。式 (5) 控制的仅是 \(K_0<|m-n|\le M/(32H)\)；式 (14) 把无符号近差推到 \(H^3\)，式 (18) 用真实符号再推任意固定对数倍。剩余中距离一直延伸到 \(Y^{1+\delta}/H\)，仍要求 \(H^4/Y\) 固定幂。现有的全区间一阶短和只提供对数节省，没有支付这道固定幂门。
