# 偶极近重叠的格点抵消与多项式素数尺度截断

日期：2026-09-29。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的偶极、[scratch 799](799-outer-prime-fraction-arithmetic-leakage-candidate.md) 的自相关，以及 [scratch 800](800-outer-prime-fraction-correction-has-lower-order-schur-cost-candidate.md) 的固定比例素数带。这里只判定偶极几何可支付的部分；不假设 RH，不宣称控制真实截断算术矩阵。

## 精确问题

固定 \(0<\delta<1/2\)，取 \(q,q'\asymp p^{1+\delta}\) 为素数，并考虑外层有理指标 \(q/b,q'/b'\) 留在 \(1<x<p\) 的范围。若 \(b,b'\asymp p^\delta\)，异臂素数幂近重叠写成
\[
r=qq'-nbb',\qquad
\left|\log\frac{qq'}{nbb'}\right|<2\Delta,\qquad
\Delta=\tfrac12\log(1+p^{-2}).
\tag{1}
\]
此时 \(U=qq'\asymp p^{2+2\delta}\)、\(R=U/p^2\asymp p^{2\delta}\)，所以 \(|r|\ll R\)。固定比例素数带的 \(r=\pm1,\pm2,\pm3\) 分类在这里不再适用。

## 无权格点抵消

把 scratch 799 式 (5) 的 \(\rho_\Delta\) 在 \([2\Delta,\infty)\) 上置零，并令
\[
F_{p,U}(r)=\rho_\Delta\!\left(\left|\log\frac{U}{U-r}\right|\right)
\quad(U-r>0),\qquad F_{p,U}(r)=0\quad(U-r\le0).
\tag{2}
\]
定义支撑于 \([-1,1]\) 的偶函数
\[
f(t)=
\begin{cases}
1-3|t|,&|t|\le\tfrac12,\\
-1+|t|,&\tfrac12\le|t|\le1,\\
0,&|t|\ge1.
\end{cases}
\tag{3}
\]
则 \(\int_{\mathbb R}f(t)\,dt=0\)。对 \(U\asymp p^{2+2\delta}\)、\(R=U/p^2\)，有一致近似
\[
F_{p,U}(r)=f(r/R)+O(p^{-2})
\quad(|r|\le2R),
\qquad F_{p,U}(r)=f(r/R)=0\quad(|r|>2R)
\tag{4}
\]
对充分大 \(p\) 成立。由此对任意整数 \(b\ge1\) 及任意剩余类 \(a\bmod b\)，
\[
\boxed{
\left|\sum_{\substack{r\in\mathbb Z\\r\equiv a\;(\mathrm{mod}\ b)}}F_{p,U}(r)\right|
\ll \min(1,b/R)+p^{-2}(1+R/b).}
\tag{5}
\]
特别地，当 \(b\asymp p^\delta\) 时，右端为 \(O(p^{-\delta})\)。
同一尺度的绝对值和却满足
\[
\boxed{
\sum_{\substack{r\in\mathbb Z\\r\equiv a\;(\mathrm{mod}\ b)}}|F_{p,U}(r)|
=\frac{2R}{3b}+O\!\left(1+p^{-2}(1+R/b)\right)
\quad(b\le R).}
\tag{5a}
\]
故 \(b\asymp p^\delta\) 时，绝对值和为 \(\asymp p^\delta\)，而 (5) 的有符号和上界为 \(O(p^{-\delta})\)；两种可证明的界相差 \(p^{2\delta}\) 量级。

证明 (4)：在 \(|r|\le2R\) 上，\(|r|/U\ll p^{-2}\)，故
\[
\frac{|\log(U/(U-r))|}{\Delta}
=\frac{2|r|}{R}+O(p^{-2}).
\]
将此代入 \(\rho_\Delta\) 的两段线性公式，即得 (4)；支撑端点的 \(O(p^{-2})\) 偏移仍由 \(f\) 的 Lipschitz 性支付。

证明 (5)：\(f\) 连续、分段线性、紧支撑，其分布二阶导数是有限原子测度，故 Fourier 变换满足 \(|\widehat f(\xi)|\ll(1+|\xi|)^{-2}\)。当 \(b\le R\) 时，对绝对收敛的 Poisson 求和式使用 \(\widehat f(0)=\int f=0\)，得到
\[
\sum_{j\in\mathbb Z} f((a+jb)/R)
=\frac Rb\sum_{m\ne0}
e^{2\pi i ma/b}\widehat f(2\pi mR/b)
\ll b/R.
\]
当 \(b>R\) 时，支撑内只有 \(O(1)\) 个格点，故和为 \(O(1)\)。最后 (4) 的误差只在 \(O(1+R/b)\) 个格点上出现，给 (5)。\(\square\)

为证 (5a)，直接积分 (3) 得 \(\int_{\mathbb R}|f(t)|\,dt=2/3\)。函数 \(|f|\) 的总变差有界，因此模 \(b\) 格点和与 \((R/b)\int|f|\) 相差 \(O(1)\)；再用 (4) 支付其近似误差。\(\square\)

## 真算术截断所在

对固定 \(q,b,q'\)，式 (1) 强制 \(r\equiv qq'\pmod b\)，并置 \(m_r=(qq'-r)/b=nb'\)。若暂时把所有正整数 \(b'=m_r/n\) 都纳入，则
\[
\sum_{n\mid m_r}\Lambda(n)=\log m_r
=\log(U/b)+O(p^{-2}),
\tag{6}
\]
它在 \(r\) 的近重叠窗口中几乎不变。由 (5)、(5a) 直接得到在 \(b\asymp p^\delta\) 时
\[
\boxed{
\sum_{\substack{r\in\mathbb Z,\ U-r>0\\r\equiv U\;(\mathrm{mod}\ b)}}
F_{p,U}(r)\log m_r
=O(Hp^{-\delta}).}
\tag{6a}
\]
求和由 \(F_{p,U}\) 自动限制在其完整支撑上；证明是把 \(\log m_r\) 换成常数 \(\log(U/b)=O(H)\)，其误差至多 \(O(p^{-2}\sum|F_{p,U}|)=O(p^{-2+\delta})\)。

固定 \(\delta<\beta<1-\delta\)，使同臂有理整数对仍小于 \(p^2\)。真实槽要求 \(q'/p<b'<p^\beta\)（并受端点、约分及素数幂平移条件约束）。对应的实际除数权是
\[
L_{q',\beta}(m_r)
=\sum_{\substack{n\mid m_r\\m_r/p^\beta<n<m_r p/q'}}\Lambda(n),
\tag{7}
\]
其中边界取整不影响这里的机制判断。若 \(0<\beta<1\) 且 \(b\asymp p^\delta\)，则 \(m_r\asymp p^{2+\delta}\) 而每个允许的
\[
n>m_r/p^\beta\asymp p^{2+\delta-\beta}>\sqrt{m_r}
\]
对充分大 \(p\) 成立。因此 (7) 中所有非零的素数幂必须属于**同一个素数底数**；若 \(m_r\) 平方自由，(7) 至多有一项。[scratch 802](802-higher-prime-power-shifts-have-bounded-cost-in-polynomial-outer-bands.md) 进一步证明在 \(x=q/b\asymp p\) 的固定比例带上，平方及更高素数幂的整块算子范数仅为 \(O(1)\)。真实主阶遂集中于素数 \(n\) 的有符号相关。它随 \(r\) 以大素因子的位置跳变，不能用 (6) 换成 \(\log m_r\)。因此 (5) 仅支付完整除数权的几何主项；要延伸 scratch 800 的谱隙或消元到 \(q\asymp p^{1+\delta}\)，仍须控制 (7) 的素数部分与 \(\rho_\Delta\) 的有符号相关。局部格点抵消本身不提供全尺度 Weil 正性或 moving-\(N\) Möbius covariance 的目标界。
