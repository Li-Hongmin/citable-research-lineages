# 全平方自由连续轮廓的物理逆响应变分系数严格低于一（待独立复核）

日期：2026-09-29。依赖 [note 777](../notes/777-physical-collar-forcing-has-logarithmic-inverse-response-on-prime-source-bands.md) 的真实 forcing、[note 783](../notes/783-squarefree-factor-layers-form-a-jacobi-response-chain.md) 的固定因子层余项界及 [note 784](../notes/784-logarithmic-prime-profiles-beat-all-constant-squarefree-layers.md) 的连续素数测度。本文将层数推广为任意固定有限值，并判定该整个试探族对同一物理 collar 能保证的最大主系数的上界。

## 定理

固定 \(0<\alpha<3/4\)、整数 \(J\ge1\)，令 \(L=\log k\)。对 \(1\le j\le J\)，置
\[
\Delta_j(\alpha)=\{(t_1,\ldots,t_j):t_i\ge0,\ \sum_i t_i\le\alpha\},\qquad
\mathcal H_j=L^2_{\rm sym}\left(\Delta_j(\alpha),
\frac1{j!}\prod_{i=1}^jt_i\,dt_i\right).
\tag{1}
\]
取固定实值有界连续对称 \(F_j\in\mathcal H_j\)。在 note 782 的真实旧奇半槽上，定义
\[
z_k=\sum_{j=1}^J L^{1-j}
\sum_{\substack{n\le k^\alpha\\n\text{ 平方自由},\ \omega(n)=j}}
\left(\prod_{p\mid n}\frac{\log p}{\sqrt p}\right)
F_j\left(\frac{\log p}{L}:p\mid n\right)e_n.
\tag{2}
\]
对 \(F_j=0\) 的高层允许将 \(J\) 任意增大。定义增加一个素数变量的算子
\[
(C_jF_j)(t_1,\ldots,t_{j+1})
=\sum_{i=1}^{j+1}F_j(t_1,\ldots,\widehat{t_i},\ldots,t_{j+1}),
\tag{3}
\]
并令
\[
\mathcal Q_{\alpha,J}(F)
=\sum_{j=1}^J\|F_j\|_j^2
-2\sum_{j=1}^{J-1}\langle C_jF_j,F_{j+1}\rangle_{j+1}.
\tag{4}
\]
则对全部整数 \(k\to\infty\)，
\[
L^{-3}\langle z_k,A_{k,-}z_k\rangle\longrightarrow
\mathcal Q_{\alpha,J}(F),
\qquad
L^{-2}\langle z_k,b_k\rangle\longrightarrow
\langle1,F_1\rangle_1.
\tag{5}
\]
对所有 \(J\) 与 \(F\)，有统一的严格支付不等式
\[
\boxed{
\mathcal Q_{\alpha,J}(F)
\ge\int_0^\alpha t(1-\alpha+t)|F_1(t)|^2\,dt
 +(1-\alpha)\sum_{j=2}^J\|F_j\|_j^2.}
\tag{6}
\]
因而该整个试探族的逆度量 Rayleigh **保证系数**满足
\[
\boxed{
\frac{|\langle1,F_1\rangle_1|^2}{\mathcal Q_{\alpha,J}(F)}
\le U(\alpha):=\int_0^\alpha\frac{t}{1-\alpha+t}\,dt
=\alpha+(1-\alpha)\log(1-\alpha)<1.}
\tag{7}
\]
特别地，即使先对全部固定有限层数及连续轮廓取上确界、再令 \(\alpha\uparrow3/4\)，也有
\[
\boxed{\sup_{J,\,F\ne0,\,\alpha<3/4}
\frac{|\langle1,F_1\rangle_1|^2}{\mathcal Q_{\alpha,J}(F)}
\le\frac34-\frac14\log4<1.}
\tag{8}
\]
式 (8) 只界定所述半槽试探族可提供的逆响应下界，不给出完整 \(\langle b_k,A_{k,-}^{-1}b_k\rangle\) 的上界。

## 固定因子层的真实算子极限

note 784 的素数测度收敛逐次张量化。对固定 \(j\)，平方自由指标的有序素数元组恰有 \(j!\) 个排列；重复素数的质量相对 \(L^{2j}\) 为低阶，且 \(\sum_i t_i=\alpha\) 对极限测度为零。因此 (2) 的第 \(j\) 层范数除以 \(L^2\) 后趋于 \(\|F_j\|_j^2\)。

同号旧算术平移在两个平方自由指标之间只增添一个不同素数。一个 \((j+1)\)-素数子指标按其 \(j+1\) 个素因子分别产生一个父指标，父指标都在共同截断中。沿 note 783 的精确单边归一化，\(j\) 与 \(j+1\) 层的双线性矩阵元除以 \(L^3\) 后趋于 \(-\langle C_jF_j,F_{j+1}\rangle_{j+1}\)。同层及非相邻层没有同号算术边。

式 (2) 中每个槽的系数均为 \(O_{J,F}(L/\sqrt n)\)。故 note 783 式 (9)–(12) 的同号、异号 archimedean、异号算术及 polar 绝对误差仍为 \(o(1)\)；单槽对角为 \(D_k+O(k^{-1})\)、\(D_k/L\to1\)。这些事实证明 (5) 的能量式。note 777 的 \(\|b_k-b_k^{\rm arith}\|=O(1)\)，而算术 forcing 只占素数幂槽，所以 (5) 的 forcing 式仅由第一层的素数测度给出。

## 边支付恒等式

对每个父指标 \(j\) 与新增变量 \(t=t_i>0\)，逐点应用
\[
2F_j(\widehat{t_i})F_{j+1}(t_1,\ldots,t_{j+1})
\le\frac{|F_j(\widehat{t_i})|^2}{t_i}
 +t_i|F_{j+1}(t_1,\ldots,t_{j+1})|^2.
\tag{9}
\]
在 \(\mathcal H_{j+1}\) 的测度下，对删除位置 \(i\) 求和并积分：父层部分的 \(t_i\) 与分母抵消，剩余的新增变量积分长度为 \(\alpha-E_j\)，\(E_j=\sum_{i=1}^jt_i\)；子层部分的 \(\sum_i t_i\) 正好是 \(E_{j+1}\)。因此
\[
2\langle C_jF_j,F_{j+1}\rangle_{j+1}
\le\langle F_j,(\alpha-E_j)F_j\rangle_j
 +\langle F_{j+1},E_{j+1}F_{j+1}\rangle_{j+1}.
\tag{10}
\]
事实上可保留 (9) 的平方余项。置 \(F_{J+1}=0\)，令
\[
\mathcal D_{\alpha,J}(F)=
\sum_{j=1}^J\frac1{(j+1)!}
\int_{\Delta_{j+1}(\alpha)}\!\prod_{r=1}^{j+1}t_r\,dt_r
\sum_{i=1}^{j+1}
\left|\frac{F_j(\widehat{t_i})}{\sqrt{t_i}}
-\sqrt{t_i}F_{j+1}(t_1,\ldots,t_{j+1})\right|^2.
\]
父层平方项积分为 \(\alpha-E_j\)，子层平方项积分为 \(E_{j+1}\)；第一层没有来自第零层的子项。因此逐项展开得到精确恒等式
\[
\boxed{\mathcal Q_{\alpha,J}(F)
=(1-\alpha)\sum_{j=1}^J\|F_j\|_j^2
+\int_0^\alpha t^2|F_1(t)|^2\,dt
+\mathcal D_{\alpha,J}(F).}
\tag{11}
\]
由于 \(\mathcal D_{\alpha,J}\ge0\)，式 (6) 随之成立。式 (10) 还控制相邻层算子的最大谱值；将每层 \(F_j\) 换成 \((-1)^jF_j\) 会翻转交叉项符号，故其最小谱值也不低于 \(-\alpha\)，算子范数至多为 \(\alpha\)。于是 \(\mathcal Q_{\alpha,J}\ge(1-\alpha)\sum_j\|F_j\|_j^2\)，对层数一致严格正。

最后，对 \(\langle1,F_1\rangle_1=\int_0^\alpha tF_1(t)dt\) 使用权为 \(t(1-\alpha+t)\) 的 Cauchy–Schwarz，即得 (7)。直接积分给出 \(U(\alpha)=\alpha+(1-\alpha)\log(1-\alpha)\)，其导数 \(-\log(1-\alpha)>0\)，故 \(\alpha<3/4\) 时 \(U(\alpha)\le U(3/4)=3/4-(\log4)/4<1\)。证明 (8)。\(\square\)

## 边界

式 (8) 在先固定层数和轮廓、再令 \(k\to\infty\) 的量词下，关闭了通过继续增加此类平方自由半槽因子层来让**同一变分证书**达到直接目标对角主系数 \(1\) 的路线。它不控制 \(J=J(k)\) 的离散余项、\(n>k^{3/4}\) 的异号算术交叉、其他旧空间试探向量，或完整逆响应。moving-\(N\) Möbius signed covariance、完整 Schur 符号和 RH 均未判定。
