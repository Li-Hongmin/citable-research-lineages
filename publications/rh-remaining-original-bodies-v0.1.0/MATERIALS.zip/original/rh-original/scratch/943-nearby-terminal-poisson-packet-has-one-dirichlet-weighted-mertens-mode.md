# 真实末带邻近分子包的非零周期模与一个 Dirichlet 加权 Möbius 零模

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 式 (5) 的精确原始谐波、[note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 式 (1) 的物理短管，以及 [scratch/942](942-real-terminal-poisson-tube-reduces-to-a-weighted-mertens-zero-mode.md) 核对的 Srivastav 加性 Möbius 输入。本文保留所有邻近谐波的真实相位，扩展 scratch/942 的中央分子结论，并支付九分之二次幂以上的 Fejér 加权真实子包。以下是解析候选证明，尚无异源复核；它不证明完整 moving-$N$ 门或 RH。

## 命题

令 $Y\to\infty$ 沿整数，$Y^{1/5}\le H\le Y^{1/4}$，$H$ 为整数，$B>0$ 固定，$1\le W\le(\log Y)^B$ 为整数。按 note 845 式 (1) 定义
$\mathcal A=\{a\in\mathbb Z:H<a\le11H/10\}$、$I_a$。对整数 $3Y/2<N\le8Y/5$，令 $z=N/Y$，并把 note 801 式 (5) 的原始除数 $q$、原始谐波 $h$ 的完整项记为 $F_{h,q}(N)$；不加 $(h,q)=1$ 掩码。置
\[
C_{W,H}(N)=\sum_{a\in\mathcal A}\sum_{q\in I_a}\sum_{|j|\le W}F_{a+j,q}(N),
\qquad
D_W(u)=\sum_{|j|\le W}e(ju).
\tag{1}
\]
这里 $D_W(u)$ 为实数。对所有所取 $q,N$，有 $zY/q\in[15/11,8/5]$，与整数保持固定距离，故 $|D_W(zY/q)|\ll1$ 一致于 $W$。全部项还满足 $0<a+j<q<N-\lfloor Y^{5/6}\rfloor$，确实位于 note 845 的物理末带。写
\[
J_H(z)=\int_0^{1/\log Y}\cos(2\pi Hz-2\pi zu)\,du,
\qquad
S_{W,Y}(z)=\sum_{Y<q\le11Y/10}\mu(q)\log\frac{zY}{q}
D_W\!\left(\frac{zY}{q}\right).
\tag{2}
\]
则对每个固定 $\varepsilon>0$，一致于上述 $H,W,N$，
\[
\boxed{\quad
C_{W,H}(N)=-\frac{J_H(z)}{\pi zH^2}S_{W,Y}(z)
+O_{B,\varepsilon}(Y^{1/2+\varepsilon}).
\quad}
\tag{3}
\]
因此 $W=\lfloor\log\log Y\rfloor$ 的真实邻近分子包，除一个明确的 Dirichlet 加权 Möbius 零模外，非零二周期模已达到目标点态量纲。$W=0$ 时同一证明退化为 scratch/942。

## 真实管与二周期模型

置 $x=q/Y$、$t=Hx-a$、$c_h=4\mathbf1_{2\mid h}-1=1+2(-1)^h$ 和
$f_z(x)=\log(z/x)/(\pi zx)$。对 $q\in I_a$ 有 $a=\lfloor Hx\rfloor$、$0<t=O(1/\log Y)$，且 $|j|\le W=o(H)$。精确 Poisson 式为
\[
F_{a+j,q}(N)=-\mu(q)\frac{x}{\pi z(a+j)^2}
\log\frac z x\,r_{a+j}\!\left(\frac{x}{(a+j)z}\right)
\cos\left(2\pi Hz+\frac{2\pi(j-t)z}{x}\right),
\quad
r_h(v)=\frac{4\mathbf1_{2\mid h}}{1-4v^2}-\frac1{1-v^2}.
\tag{4}
\]
由于 $a+j=Hx+(j-t)$、$x,z\asymp1$、$r_{a+j}(v)=c_{a+j}+O(H^{-2})$，式 (4) 的振幅一致满足
\[
\frac{x}{\pi z(a+j)^2}\log\frac z x\,
r_{a+j}\!\left(\frac{x}{(a+j)z}\right)
=\frac{c_{a+j}f_z(x)}{H^2}
+O\!\left(\frac{W+1}{H^3}\right).
\tag{5}
\]
全部真实短管含 $O(Y/\log Y)$ 个 $q$，故 (5) 对 (1) 的总误差为 $O(W(W+1)Y/H^3)$。

令 $L(x)=x/\log Y$。与 scratch/942 式 (6) 相同，$I_a$ 在 $t$ 坐标的上端为 $a/(H\log Y)+O(H/Y)$；它同 $t<L(x)$ 的端点相差 $O(H/Y+1/(H\log^2Y))$。逐 $a$ 的格点差至多 $O(1+Y/(H^2\log^2Y))$。把 $a\in\mathcal A$ 改为 $Y<q\le11Y/10$ 仅再改变两端总长 $O(Y/H)$ 的整数带。因此真实管与周期模型的对称差为 $O(Y/H)$ 个 $q$，其主权绝对值至多 $O(W/H^2)$。

对任意 $x,z$ 定义周期为 $2$ 的函数
\[
V_{W;x,z}(y)=\mathbf1_{\,0<\{y\}<L(x)}
\sum_{|j|\le W}c_{\lfloor y\rfloor+j}
\cos\left(2\pi Hz+\frac{2\pi(j-\{y\})z}{x}\right).
\tag{6}
\]
于是
\[
C_{W,H}(N)=-\frac1{H^2}
\sum_{Y<q\le11Y/10}\mu(q)f_z(q/Y)
V_{W;q/Y,z}(Hq/Y)
+O\!\left(\frac{(W+1)^2Y}{H^3}\right).
\tag{7}
\]

## 零模

以 $e(ky/2)$ 展开 (6)。把 $y\in[0,2)$ 分为 $m=0,1$ 两个单位格，设
\[
d_{j,k}=\frac{c_j+(-1)^kc_{j+1}}2
=\begin{cases}1,&k\text{ 偶},\\2(-1)^j,&k\text{ 奇}.
\end{cases}
\tag{8}
\]
精确 Fourier 系数为
\[
\widehat V_{W,k}(x,z)=\sum_{|j|\le W}d_{j,k}
\int_0^{L(x)}
\cos\left(2\pi Hz+\frac{2\pi(j-t)z}{x}\right)e(-kt/2)\,dt.
\tag{9}
\]
特别地 $d_{j,0}=1$。把 $j$ 与 $-j$ 配对，再令 $u=t/x$，得
\[
f_z(x)\widehat V_{W,0}(x,z)
=\frac{\log(z/x)}{\pi z}J_H(z)D_W(z/x).
\tag{10}
\]
代回 (7) 后，$k=0$ 的项恰为 (3) 右端的主项；这里没有把 Möbius 和替换为素数密度。

## 非零模

取 $0<\vartheta<1/200$，令
\[
K=\left\lfloor\frac{Y^{3/10-\vartheta}}{2H}\right\rfloor,
\qquad \sigma=Y^\vartheta/K.
\tag{11}
\]
用非负积分为 $1$ 的固定 $C_c^\infty((-1,1))$ 核在周期 $2$ 上平滑 (6)。第 $k$ 个系数乘以 $\widehat\rho(\sigma k/2)$，零模不变。硬函数和平滑函数仅在 $y$ 距整数或整数加 $L(x)$ 不超过 $\sigma$ 时不同；对 $y=Hq/Y$，相关相位分别为 $Hq/Y$ 和 $(H-1/\log Y)q/Y$。它们各跨过 $O(H)$ 个整数，每个 $\sigma$ 邻域含 $O(\sigma Y/H+1)$ 个 $q$。由于 $|V_{W;x,z}|\ll W+1$，(7) 的平滑误差为
\[
O\!\left(\frac{(W+1)(\sigma Y+H)}{H^2}\right).
\tag{12}
\]

Srivastav, *Log-free bounds on exponential sums over primes*, arXiv:2505.07803v2, Theorem 1 的 Möbius 部分允许 $\alpha=a/q+\delta/X$、$q\le X^{2/5-\eta}$、$|\delta|\le X^{1/5+\eta}/q$，并给出 $X/[\delta_0\varphi(q)]^{1/2}$ 乘显式因子 $\mathscr G_\eta(u,u_0)$，其中 $\delta_0=\max(1,|\delta|/4)$。取 $q=1,\eta=1/10$；原文式 (1.4) 的 $\mathscr G_{1/10}(u,u)$ 在 $0\le u\le3/10$ 有界（分母至少 $1/20$）。对 $X\asymp Y$ 的所有前缀和 $1\le|k|\le K$，相位
\[
\alpha_1=\frac{kH}{2Y},\qquad
\alpha_2=\frac{k(H-1/\log Y)}{2Y}
\tag{13}
\]
满足 $|X\alpha_i|\ll |k|H\le Y^{3/10-\vartheta}$，因而
\[
\left|\sum_{n\le X}\mu(n)e(n\alpha_i)\right|
\ll\frac{Y}{\sqrt{|k|H}}.
\tag{14}
\]
可将 $\alpha_i$ 加上整数，使定理的有理中心取 $1/1$；负 $k$ 用共轭或负 $\delta$。对 $0<|k|\le8$，由 (9) 与 $x\in[1,11/10]$，权 $f_z(x)\widehat V_{W,k}(x,z)$ 的上确界和总变差为 $O((W+1)^2)$。Abel 求和后，这些模在除以 $H^2$ 前合计为 $O((W+1)^2Y/\sqrt H)$。

对 $9\le|k|\le K$，(9) 中余弦拆为两指数给出
\[
\widehat V_{W,k}(x,z)=\frac12\sum_{|j|\le W}d_{j,k}
\sum_{s=\pm1}e(sHz+s jz/x)
\frac{1-e(-(k/2+s z/x)L(x))}
{2\pi i(k/2+s z/x)}.
\tag{15}
\]
这里 $|k/2+s z/x|\gg|k|$。对每个 $j,s,k$，$x\mapsto f_z(x)e(sjz/x)/(k/2+s z/x)$ 的上确界与总变差均为 $O((1+|j|)/|k|)$。乘上 $e(kHx/2)$ 后，(15) 的两端相位分别为 $\alpha_1$ 与 $\alpha_2$，因为
\[
e(kHx/2)e(-(k/2+s z/x)L(x))
=e\!\left(\frac{k(H-1/\log Y)x}{2}\right)e(-s z/\log Y).
\tag{16}
\]
最后一因子不依赖 $x$。故 (14) 与 Abel 求和使每个 $j,k$ 的贡献为 $O((1+|j|)Y/(\sqrt H\,|k|^{3/2}))$。求和 $j$ 与 $k$，全部 $0<|k|\le K$ 在除以 $H^2$ 前为 $O((W+1)^2Y/\sqrt H)$。

由 (9) 分部积分，$|\widehat V_{W,k}|\ll(W+1)/|k|$。平滑乘子任意固定 $A>1$ 阶衰减；用 $|\mu|\le1$ 绝对支付 $|k|>K$，在除以 $H^2$ 前为
\[
O_A\!\left((W+1)Y(\sigma K)^{-A}\right)
=O_A((W+1)Y^{1-A\vartheta}).
\tag{17}
\]
合并 (7)、(10)、(12)、(14)–(17)，得到更明确的界
\[
|C_{W,H}(N)+J_H(z)S_{W,Y}(z)/(\pi zH^2)|
\ll_{\vartheta,A}
\frac{(W+1)^2Y}{H^3}
+\frac{(W+1)^2Y}{H^{5/2}}
+\frac{(W+1)(\sigma Y+H+Y^{1-A\vartheta})}{H^2}.
\tag{18}
\]
由 $H\ge Y^{1/5}$，前两项分别至多 $(W+1)^2Y^{2/5}$ 与 $(W+1)^2Y^{1/2}$；由 (11)，$\sigma Y/H^2\ll Y^{1/2+2\vartheta}$。先取 $\vartheta<\varepsilon/8$，再取固定 $A$ 使 $A\vartheta>1/10$，最后用 $W\le(\log Y)^B=Y^{o(1)}$，即得 (3)。$\square$

## 横向消元及边界

同一 $W,Y,z$ 下，$S_{W,Y}(z)$ 与载波 $H$ 无关。因此把 $H$ 换成任意固定有限个 $H+r$（仍在定理范围内），(3) 的未知算术部分在这些真实包中只占一个方向。特别地，若 $v_h(z)=J_h(z)/h^2$，则在每个固定紧集 $\mathcal K\Subset(3/2,8/5)$，相邻两个载波满足
\[
\frac{v_{H+1}(z)C_{W,H}(N)-v_H(z)C_{W,H+1}(N)}
{\sqrt{v_H(z)^2+v_{H+1}(z)^2}}
=O_{B,\mathcal K,\varepsilon}(Y^{1/2+\varepsilon}),
\qquad z=N/Y\in\mathcal K,
\tag{19}
\]
分母非零，因为 $\sin(2\pi z)$ 在 $\mathcal K$ 上远离零。由点态界，对这些 $N$ 的平方和为 $O_{B,\mathcal K,\varepsilon}(Y^{2+\varepsilon})$，其中把点态的 $\varepsilon$ 先取一半。
当 $W\ge1$ 时，相邻载波包可能共用原始 $(h,q)$ 项；式 (19) 是真实线性组合的估计，不能仅据此把它解释为两个不交算术源间的 signed covariance。

自然地把许多相邻载波直接相加，也不会使共同零模的系数恒等消失。精确积分给
$J_h(z)=\sin(\pi z/\log Y)(\pi z)^{-1}
\cos(2\pi hz-\pi z/\log Y)$。令 $M\to\infty$ 且 $[M,2M]$ 落在命题的 $H$ 范围内，固定非退化闭区间 $I\Subset(3/2,8/5)$。对 $r=e(z)$，$|1-r|$ 在 $I$ 上远离零；两次离散分部求和给
\[
\sum_{h=M}^{2M}\frac{r^h}{h^2}
=\frac{M^{-2}r^M-(2M)^{-2}r^{2M+1}}{1-r}
+O_I(M^{-3}).
\tag{20}
\]
把 (20) 代入 $J_h$ 并展开平方；频率 $M$、$2M+1$ 的非对角积分由一次分部积分为 $O_I(M^{-1})$，故
\[
\boxed{\quad
\int_I\left|\sum_{h=M}^{2M}\frac{J_h(z)}{h^2}\right|^2dz
=\left(\frac{17}{32}+o(1)\right)
\frac1{M^4(\log Y)^2}
\int_I\frac{dz}{|1-e(z)|^2}.
\quad}
\tag{21}
\]
因此普通的 dyadic 载波求和只把零模系数降到单管的同一次幂 $M^{-2}(\log Y)^{-1}$，没有代数上的固定幂消元；式 (19) 的横向权重是确实在做投影。

## Fejér 三角权的真实子包在九分之二次幂后全额支付

式 (18) 的证明在最后吸收 $W$ 为多对数之前，事实上对全部 $1\le W\le H/4$ 成立；它只用了 $a+j\asymp H$。同一逐项证明还允许在每个 $j$ 上乘任意不超过 $1$ 的固定实权。取
\[
T=\left\lceil\frac{Y^{1/2}}{H^2}\right\rceil,
\qquad w_{j,T}=\begin{cases}1-|j|/T,&|j|<T,\\0,&|j|\ge T,\end{cases}
\quad
P_{T,H}(N)=\sum_{a\in\mathcal A}\sum_{q\in I_a}
\sum_{|j|<T}w_{j,T}F_{a+j,q}(N).
\tag{22}
\]
若 $Y^{2/9}\le H\le Y^{1/4}$，则 $1\le T\ll Y^{1/18}$ 且 $T\le H/4$ 对充分大 $Y$ 成立。周期零模中的 $D_W$ 被 Fejér 核
\[
\mathsf F_T(u)=\sum_{|j|<T}w_{j,T}e(ju)
=\frac1T\left(\frac{\sin(\pi Tu)}{\sin(\pi u)}\right)^2
\tag{23}
\]
代替。在 $u=zY/q\in[15/11,8/5]$ 上，$0\le\mathsf F_T(u)\ll T^{-1}$，故不使用任何 Möbius 相消也有
\[
\left|\frac{J_H(z)}{\pi zH^2}
\sum_{Y<q\le11Y/10}\mu(q)\log\frac{zY}{q}
\mathsf F_T(zY/q)\right|
\ll\frac{Y}{H^2T\log Y}
\le\frac{Y^{1/2}}{\log Y}.
\tag{24}
\]
式 (18) 中对 $j$ 逐项取绝对值会多损失一个 $T$。以下保留三角权的精确和。令 $u=z/x$；(8)–(9) 对加权包给出
\[
\widehat V^{\rm Fej}_{T,k}(x,z)
=\frac12\sum_{s=\pm1}e(sHz)\,\mathsf B_k(u)
\int_0^{L(x)}e(-(k/2+su)t)\,dt,
\qquad
\mathsf B_k(u)=\begin{cases}
\mathsf F_T(u),&k\text{ 偶},\\
2\mathsf F_T(u+1/2),&k\text{ 奇}.
\end{cases}
\tag{25}
\]
对 $s=-1$ 的奇模，$\mathsf F_T(1/2-u)=\mathsf F_T(u+1/2)$ 用了 Fejér 核的偶性和周期性。它的基本界是 $\sup\mathsf F_T\le T$、$\int_0^1\mathsf F_T=1$ 以及 $\operatorname{Var}_{[0,1]}\mathsf F_T\ll T$。最后一界可直接从 (23) 证明：距整数不超过 $1/T$ 的区间用 Fourier 展开得 $|\mathsf F_T'|\ll T^2$；其余处若 $d=\|u\|_{\mathbb R/\mathbb Z}$，对 (23) 求导得 $|\mathsf F_T'|\ll d^{-2}+(Td^3)^{-1}$，积分均为 $O(T)$。因此 $x\mapsto\mathsf B_k(z/x)$ 的上确界和总变差为 $O(T)$。式 (25) 代替 (15) 作 Abel 求和：$0<|k|\le8$ 的权具有 $O(T)$ 上确界与变差；$9\le|k|\le K$ 的两端权具有 $O(T/|k|)$ 上确界与变差，端点相位仍是 (16)。由 (14) 求和，全部非零低模在除以 $H^2$ 前为 $O(TY/\sqrt H)$。

平滑硬边界时也保留 Fejér 核。由 $c_{m+j}=1+2(-1)^{m+j}$，(6) 的三角加权版在每个 $y=m+t$ 的绝对值至多
$Q_T(x)=\mathsf F_T(z/x)+2\mathsf F_T(z/x+1/2)$。在 $x\asymp1$ 上，$Q_T\ge0$、$\int Q_T(x)\,dx\ll1$、$\operatorname{Var}Q_T\ll T$。对 (12) 的任一边界相位 $H_0q/Y$，其中 $H_0=H$ 或 $H-1/\log Y$，按相邻整数 $m\asymp H$ 把边界格点分簇。每簇至多 $O(\sigma Y/H+1)$ 个 $q$，其 $x=q/Y$ 距 $m/H_0$ 不超过 $\sigma/H_0$。由于这些小区间互不相交，Riemann 和误差由总变差支付，
\[
\sum_{\substack{Y<q\le11Y/10\\\|H_0q/Y\|\le\sigma}}Q_T(q/Y)
\ll(\sigma Y/H+1)
\left(H\int Q_T(x)\,dx+\operatorname{Var}Q_T\right)
\ll\sigma Y+H
\tag{26}
\]
（用 $T\le H/4$）。故 Fejér 子包的硬边界误差是 $O((\sigma Y+H)/H^2)$，没有额外的 $T$。高 Fourier 尾仍由 $|\widehat V^{\rm Fej}_{T,k}|\ll T/|k|$ 支付。几何替换保守地沿用 (7) 的 $O(T^2Y/H^3)$。于是 (18) 对该子包加强为
\[
|P_{T,H}(N)-Z_{T,H}(N)|
\ll_{\vartheta,A}
\frac{T^2Y}{H^3}
+\frac{TY}{H^{5/2}}
+\frac{\sigma Y+H+TY^{1-A\vartheta}}{H^2},
\tag{27}
\]
其中 $Z_{T,H}$ 是 (24) 左端去绝对值后的零模。由 $T\asymp Y^{1/2}/H^2$、$\sigma\ll H Y^{-3/10+2\vartheta}$ 与 $H\ge Y^{2/9}$，各主要误差满足
\[
\frac{T^2Y}{H^3}\ll\frac{Y^2}{H^7}\le Y^{4/9},
\qquad
\frac{TY}{H^{5/2}}\ll\frac{Y^{3/2}}{H^{9/2}}\le Y^{1/2},
\qquad
\frac{\sigma Y}{H^2}\ll\frac{Y^{7/10+2\vartheta}}H
\le Y^{43/90+2\vartheta}.
\tag{28}
\]
此外 $H/H^2\ll1$；高模误差为 $O(TY^{1-A\vartheta}/H^2)\ll Y^{3/2-A\vartheta}/H^4$，取固定 $A\vartheta>1/9$ 后至多 $O(Y^{1/2})$。对任意 $\varepsilon>0$ 先取 $0<\vartheta<\min(1/200,\varepsilon/4)$，则 (24)、(27)–(28) 证明真正物理 Poisson 项的无条件界
\[
\boxed{\quad
P_{T,H}(N)=O_\varepsilon(Y^{1/2+\varepsilon}),
\qquad
\sum_{3Y/2<N\le8Y/5}|P_{T,H}(N)|^2
\ll_\varepsilon Y^{2+\varepsilon}.
\quad}
\tag{29}
\]
均方式把点态指数先取为 $\varepsilon/2$。这支付的是带三角权的真实末带谐波子包；未经加权的相邻分子包与完整残差不能由 (29) 直接推出相同界。
作为实际 signed covariance 推论，固定 $2/9\le\gamma<1/4$，取 $H=\lfloor Y^\gamma\rfloor$；在端点 $\gamma=2/9$ 有 $H\asymp Y^{2/9}$，上述带常数的估计仍适用。令 $G_N$ 是 note 845 式 (2) 的中央真实素数源，并置 $E_{T,N}=P_{T,H}(N)-G_N$。由于 $w_{0,T}=1$，$E_T$ 确实是其余原始 Poisson 项的带符号和。note 845 式 (5) 给 $\|G\|_2^2\sim\kappa Y^3/[H^4(\log Y)^4]$，而 (29) 对任意固定 $\varepsilon>0$ 给 $\|P_{T,H}\|_2^2\ll_\varepsilon Y^{2+\varepsilon}$。取 $\varepsilon<1-4\gamma$，则 $\|P_{T,H}\|_2=o(\|G\|_2)$；Cauchy–Schwarz 因而给
\[
\boxed{\quad
\sum_{3Y/2<N\le8Y/5}G_N E_{T,N}
=-(\kappa+o(1))\frac{Y^3}{H^4(\log Y)^4}.
\quad}
\tag{30}
\]
这是中央素数源与其真实 Fejér 加权补包的超目标量纲负协方差；补包含中央非素数和邻近分子两类，且三角权仍是 (29) 的必要组成。
指数 $2/9$ 来自 (28) 的非零低模成本 $Y^{3/2}/H^{9/2}\le Y^{1/2}$；这里不主张它是其他方法或未经加权问题的尖锐阈值。式 (25) 的奇模因子在 $z/x=3/2$ 的真实物理带内有峰值 $2T$，故 Fejér 零模的逐项小量不能照搬到全部周期模。事实上对任一固定 $z\in(3/2,8/5)$，峰点 $x_0=2z/3$ 位于 $(1,11/10)$，而 $x=11/10$ 处的 $\mathsf F_T(z/x+1/2)=O_z(T^{-1})$；故该奇模因子的总变差至少为 $2T-O_z(T^{-1})$。因此只用全前缀界 (14) 作有界变差 Abel 求和，不能再从式 (25) 的奇模权中免费去掉 $T$；越过 $2/9$ 需针对该移动半整数峰的额外算术相消。

式 (3) 没有控制 $S_{W,Y}(z)$。Fejér 权在零模上的逐项衰减也不属于未加权的 Dirichlet 核：对任意固定非退化区间 $J\Subset(15/11,8/5)$，$D_W(u)=\sin((2W+1)\pi u)/\sin(\pi u)$，故一次振荡积分给
\[
\int_J D_W(u)^2\,du
=\frac12\int_J\frac{du}{\sin^2(\pi u)}+o(1)>0
\qquad(W\to\infty).
\tag{31}
\]
因此未经加权的零模没有符号无关的趋零核界。尽管 $D_W(z/x)$ 作为连续积分核有非驻相抵消，不能在这里把 $\mu(q)$ 当作光滑密度；这种替换不会证明 (3) 中未付的零模，更不能推出完整 residual 的均方门。
