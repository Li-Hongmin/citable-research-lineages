# 最大整数 Weil 格的宏观对数轮廓只有秩一低能主模

日期：2026-10-02。依赖 [note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的整除矩阵与初等加权素数界，以及 [note 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md) 的最大槽几何、完整 Weil 分解和普通核中心替换。以下是解析证明草稿，尚待独立复核。它不控制任意槽系数、随尺度振荡的轮廓、补空间或全尺度局部 Weil 正性。

## 命题

沿奇素数 $p\to\infty$，置 $H=\log p$、$M=(p^2-5)/4$、$L=\log M$、$\ell=c/p^2$，其中 $0<c<4$ 固定。令 $\varphi\in C_c^\infty((-1/2,1/2))$ 为固定实单位轮廓，$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$。对固定非零的复值 $g\in C^1([0,1])$，写
\[
t_n=\frac{\log n}{L},\qquad
W_M(g)=\sum_{n\le M}\frac{|g(t_n)|^2}{n},\qquad
f_{p,g}(y_n+t)=\frac{g(t_n)}{\sqrt{nW_M(g)}}b_\ell(t)
\quad(t\in(-\ell/2,\ell/2)),
\]
其中 $y_n=H-\log4-\log n$，在槽外取零。则 $\|f_{p,g}\|_2=1$，且
\[
\boxed{\quad
Q_W^H[f_{p,g}]
=L\frac{\displaystyle\int_0^1|g(t)-\bar g|^2\,dt}
        {\displaystyle\int_0^1|g(t)|^2\,dt}
+O_{g,c,\varphi}(1),
\qquad \bar g=\int_0^1g(t)\,dt.
\quad}                                                       \tag{1}
\]
特别地，每个固定非常数 $g$ 的完整 Weil Rayleigh 值趋于 $+\infty$。固定常数 $g$ 的主阶为零，其有限极限由 note 857 及 note 858 给出且严格为正。因此，这个最大整数格的全部**固定** $C^1$ 宏观对数轮廓均最终为正。

更精确地，若 $C_M$ 是 note 854 式 (2) 的真实素数幂整除矩阵、$v_{g,n}=g(t_n)/\sqrt n$，则
\[
\boxed{\quad
\langle v_g,C_Mv_g\rangle
=L^2|\bar g|^2+O_g(L),
\qquad W_M(g)=L\int_0^1|g|^2+O_g(1).
\quad}                                                       \tag{2}
\]
式 (2) 经极化表明：在宏观对数轮廓空间中，整除矩阵的 $L^{-2}$ 主极限为函数 $g\mapsto\int_0^1g$ 的秩一 Gram 形式。

## 调和与素数幂测度

对任意 $F\in C^1([0,1])$，分块积分或一次 Abel 求和给
\[
\sum_{n\le M}\frac{F(t_n)}n
=L\int_0^1F(t)\,dt
+O\bigl(\|F\|_\infty+\|F'\|_\infty\bigr).             \tag{3}
\]
确实，将 $F(\log x/L)/x$ 在 $[1,M]$ 上积分并用每个整数单位段的一阶导数控制求和误差，后者由
$\int_1^M x^{-2}(\|F\|_\infty+L^{-1}\|F'\|_\infty)\,dx=O(\|F\|_{C^1})$ 支付。式 (3) 用于 $F=|g|^2$ 即给式 (2) 的第二式。

记 $A(x)=\sum_{2\le k\le x}\Lambda(k)/k$。note 854 式 (3) 的初等恒等式给一致的
\[
A(x)=\log x+O(1)\qquad(x\ge1).                         \tag{4}
\]
因此对任意 $t\in[0,1]$，将 $A(e^{Lr})-Lr=O(1)$ 作 Stieltjes 分部积分，得
\[
\sum_{2\le k\le e^{L(1-t)}}
\frac{\Lambda(k)}k,g\!\left(t+\frac{\log k}{L}\right)
=L\int_0^{1-t}g(t+r)\,dr
+O\bigl(\|g\|_\infty+\|g'\|_\infty\bigr),            \tag{5}
\]
误差一致于 $t,L$：边界项由 $O(1)\|g\|_\infty$ 控制，积分项的总变差至多 $\int_t^1|g'(s)|ds\le\|g'\|_\infty$。

## 整除图的秩一主阶

整除矩阵的两条对称臂给出精确式
\[
\langle v_g,C_Mv_g\rangle
=2\operatorname{Re}\sum_{n\le M}\frac{\overline{g(t_n)}}n
\sum_{2\le k\le M/n}\frac{\Lambda(k)}k
g\!\left(t_n+\frac{\log k}{L}\right).                 \tag{6}
\]
把 (5) 代入 (6)，误差为 $O_g(\sum_{n\le M}1/n)=O_g(L)$。对主项使用 (3)，其中
$F(t)=\overline{g(t)}\int_t^1g(s)ds\in C^1([0,1])$，得到
\[
\langle v_g,C_Mv_g\rangle
=2L^2\operatorname{Re}\int_{0<t<s<1}
\overline{g(t)}g(s)\,dt\,ds+O_g(L).
\]
对双积分交换 $s,t$，对角线测度为零，故它的两倍实部恰为 $|\int_0^1g|^2$。这证明 (2)。

## 完整 Weil 形式的其余项

note 857 的共同槽几何对所有 $n\le M$ 精确强迫素数幂位移只在 $r=kn$ 时出现，故 prime-shift 项是
$-\langle v_g,C_Mv_g\rangle/W_M(g)$。由 (2)，它等于
\[
-L\frac{|\bar g|^2}{\int_0^1|g|^2}+O_g(1).          \tag{7}
\]
同槽 Fourier 与光滑余项之和按 note 857 式 (5) 为
\[
\log(1/\ell)+C_\varphi-\log(2\pi)+o(1)
=L+O_{c,\varphi}(1).                                     \tag{8}
\]

普通跨槽中心核按 note 856 式 (7) 等于 $\sum_{n<r}g(t_n)\overline{g(t_r)}[(r-n)^{-1}+(r+n)^{-1}]$ 的实部，乘上 $-\ell(\int\varphi)^2/W_M(g)$；note 857 的中心替换误差在 $|g|\le\|g\|_\infty$ 下仍为 $o_g(1)$。直接取绝对值有
\[
\sum_{n<r\le M}\frac{|g(t_n)g(t_r)|}{r-n}
\le\|g\|_\infty^2\sum_{d<M}\frac{M-d}{d}
\ll_g ML,
\]
而 $1/(r+n)$ 部分至多 $O_g(M)$。因 $\ell M\to c/4$、$W_M(g)\asymp_g L$，普通项为 $O_{g,c,\varphi}(1)$。

最后，极点项由 note 859 式 (11) 的两矩公式控制。式 (3) 给 $|\sum_{n\le M}g(t_n)/n|=O_g(L)$，平凡界给 $|\sum_{n\le M}g(t_n)|=O_g(M)$；又 $|m_+m_-|\ll_\varphi\ell$。故极点项绝对值至多
$O_{g,\varphi}(\ell LM/W_M(g))=O_{g,c,\varphi}(1)$。把这些界与 (7)--(8) 相加，并用
$\int|g-\bar g|^2=\int|g|^2-|\bar g|^2$，得到 (1)。$\square$

## 边界

式 (1) 只对先固定的 $g,c,\varphi$ 声明有界误差。它没有排除随 $p$ 变化、在素数赋值或细槽尺度上振荡的系数；note 859 的固定 $2$-adic 低能模就是另一种对象。它也没有控制该格与整个局部 Weil 空间的 Schur 交叉，更没有提供 note 849 式 (15) 的 moving-$N$ signed covariance 界。
