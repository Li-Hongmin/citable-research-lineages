# 联合观察核的奇数源配对与精确盲区间

日期：2026-10-01。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(11)、[scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 式 (1)--(7) 与 [scratch/863](863-direct-mobius-observation-channel-is-not-a-necessary-standalone-gate.md)。本稿只对真实联合系数作精确代数压缩；剩余 signed covariance 的固定幂界仍未证明。

令 $M=2Y$、$\phi(t)=\psi(t)/t$，$\psi\in C_c^3((1,2))$，并把 scratch/859 式 (2) 的 $b_d(m)$ 定义于全部 $d\ge1$，在 $d>2M$ 时自然为零。置
\[
 B_u(m)=b_u(m)-b_{2u}(m),\qquad
 \widetilde{\mathcal K}_h(u)=\sum_{M<m<2M}B_u(m)e(-hm/M)
 \quad(u\text{ odd}).
 \tag{1}
\]
由 $\mu(2u)=-\mu(u)$（$u$ 奇）及 $\mu(4v)=0$，对每个整数 $h$ 有**精确**恒等式
\[
 \mathcal A_h=\mathcal B_h+
 \sum_{\substack{u\le2M\\u\text{ odd}}}
 \mu(u)\widetilde{\mathcal K}_h(u),
 \qquad
 \mathcal B_h=\frac1M\sum_{M<m<2M}
 (4-2\mathbf1_{2\mid m})\phi(m/M)e(-hm/M).
 \tag{2}
\]
这里 $\mathcal A_h$ 是 scratch/859 式 (1) 的真实联合观察系数，式 (2) 没有截断误差。

若 $m=ku\in(M,2M)$、$u$ 奇，则
\[
 B_u(ku)=\frac{\phi(ku/M)}M q(k),
 \quad
 q(k)=-4\log k+6\mathbf1_{2\mid k}\log(k/2)
 -2\mathbf1_{4\mid k}\log(k/4)
 -4(\log2)\mathbf1_{k=1}+4(\log2)\mathbf1_{k=2}.
 \tag{3}
\]
含零指示的对数项按零解释。等价地，
\[
 q(1)=-4\log2,\quad q(2)=0,\quad
 q(k)=\begin{cases}
 -4\log k,&k\ge3\text{ odd},\\
 2\log k-6\log2,&k\ge6,\ k\equiv2\pmod4,\\
 -2\log2,&4\mid k.
 \end{cases}
 \tag{4}
\]
式 (3) 由 $b_u-b_{2u}$ 中三个整除指示与两个直接项相减得到；特别是 $q(2)=0$ 同时用了 $\Lambda=\mu*\log$ 的 cofactor $2$ 项与 $\mu(2u)=-\mu(u)$，不能在拆开的单通道中保留。
这只消去**同一个奇数源 $u$** 在 $m=2u$ 的贡献；$c(2u)$ 仍可由 $u$ 的其他除数产生，通常不为零。

另一个代数核对是其 Dirichlet 级数：当 $\Re s>1$，写 $x=2^{-s}$，则
\[
 \sum_{k\ge1}\frac{q(k)}{k^s}
 =(4-6x+2x^2)\zeta'(s)-4(\log2)(1-x),
 \qquad
 \sum_{u\text{ odd}}\frac{\mu(u)}{u^s}
 =\frac1{(1-x)\zeta(s)}.
\]
以 scratch/859 式 (1) 的同一公式把 $c$ 延拓至 $m=1,2$，两式相乘正是 $\sum_{m\ge1}[c(m)-(4-2\mathbf1_{2\mid m})]m^{-s}=(4-2x)\zeta'(s)/\zeta(s)-4(\log2)/\zeta(s)$，独立核对了配对系数及两个直接项的符号。

**精确盲区间。** 对每个奇数 $u$ 满足
\[
 \frac{2M}{3}<u<M,
 \tag{5}
\]
条件 $M<ku<2M$ 只容许 $k=2$：$k=1$ 在窗外，$k\ge3$ 已超过 $2M$。由 $q(2)=0$，
\[
 B_u(m)=0\quad\text{对全部 }m,
 \qquad \widetilde{\mathcal K}_h(u)=0\quad\text{对全部 }h.
 \tag{6}
\]
因此在真实 $\mu$ 的奇数源 Gram 中，这一长度为 $M/3$、含 $\asymp M$ 个奇数索引的区间给出**精确零行零列**。这比单个频带上的小量估计强，但只是算术映射的核，不是对 $\mu$ 的自由变动或 RH 的结论。

在 scratch/859 的频带 $H/2\le|h|\le4H$，令 $D=\lfloor M/(16H)\rfloor$。式 (2) 中 $u\le D/2$ 的两项 $b_u,b_{2u}$ 均属于原证明已由 Poisson 支付的 $d\le D$，而 $\mathcal B_h\ll_\psi H^{-3}$。故
\[
 \mathcal A_h=
 \sum_{\substack{D/2<u\le2M\\u\text{ odd}\\u\notin(2M/3,M)}}
 \mu(u)\widetilde{\mathcal K}_h(u)
 +O_\psi(H^{-3}\log^2M).
 \tag{7}
\]
该误差的带通平方和为 $O_\psi(H^{-5}\log^4M)=o(H^4/M)$，与 scratch/859 式 (7) 同阶。式 (7) 将真实门改写为单一奇数位 signed Gram，并精确移除 (5)；它没有给未付 Gram 的 $O_\varepsilon(H^4M^{-1+\varepsilon})$ 上界。
对素数 $p\in(M,2M)$，仍有 $\widetilde{\mathcal K}_h(p)=-4(\log2)M^{-1}\phi(p/M)e(-hp/M)$；因此 [scratch/861](861-prime-prime-block-survives-the-true-high-divisor-observation-gate.md) 的正素数块原样存活，盲区间的移除并不支付它。

从 (4) 还可读出紧邻盲区间的第一条存活线：若 $M/2<u<2M/3$ 且 $u$ 奇，则窗内只可能有 $k=2,3$，其中 $k=2$ 消失，故
\[
 \widetilde{\mathcal K}_h(u)
 =-\frac{4\log3}{M}\phi(3u/M)e(-3hu/M).
 \tag{8}
\]
下一步的真实算术问题因而可先限定于 (8) 与 $u>M$ 的 $k=1$ 线之间的 signed covariance，同时保留其余存活 cofactor；只估这两条线不能替代完整门。

## 真实素数幂支撑排除盲区间的自由扰动

式 (6) 是线性映射的核；真实 $\mu$ 的乘法性与 $\Lambda$ 的素数幂支撑限制哪些核向量能够由另一套算术系数实现。这个限制在单个观察窗内已有如下初等精确形式。

设 $M$ 为充分大的偶整数，$\sqrt{2M}\le D_0<M/2$。令 $f$ 为平方自由支撑的乘法函数，$f(1)=1$，且 $f(n)=\mu(n)$ 对 $n\le D_0$ 成立。定义 $\Lambda_f=f*\log$。若只要求
\[
 \Lambda_f(pq)=0
 \quad\text{对全部不同素数 }p,q\text{ 满足 }M<pq<2M,
 \tag{9}
\]
则已必有
\[
 f(n)=\mu(n)\quad(1\le n\le M),
 \qquad
 f(n)=\mu(n)\quad(M<n<2M,\ n\text{ 合数}),
 \tag{10}
\]
并且 $\Lambda_f(m)=\Lambda(m)$ 对全部 $m<2M$ 成立。因此 $f$ 与 $\mu$ 在当前窗内只能在 $M<p<2M$ 的素数值上不同。

证明只需先看素数。对 $D_0<p\le M/2$，令 $x=M/p\ge2$。Bertrand 定理应用于 $\lfloor x\rfloor$ 给素数 $q\in(x,2x)$；由 $D_0^2\ge2M$，有 $q<2M/p\le2M/D_0\le D_0<p$，故 $f(q)=-1$，而 $M<pq<2M$。对 $M/2<p<M$，取 $q=2$，同样有 $M<2p<2M$。在两种情形下，
\[
 0=\Lambda_f(pq)
 =\log(pq)+f(p)\log q+f(q)\log p
 =(1+f(p))\log q,
\]
所以 $f(p)=-1$。结合 $p\le D_0$ 的假设，全部 $p<M$ 的素数值均已确定；平方自由支撑与乘法性推出 (10)。若 $m<2M$ 为合数，其每个真因子均小于 $M$，而 $d=m$ 在 $f*\log$ 中的权为 $\log1=0$；若 $m$ 为素数，则 $\Lambda_f(m)=\log m$。这证明 $\Lambda_f=\Lambda$ 于所述范围。$\square$

特别地，记 $\mathcal A_h^{(f)}$ 为以 $f,\Lambda_f$ 代入 scratch/859 式 (1) 的联合系数，$D_h^{(f)}=M^{-1}\sum_{M<m<2M}f(m)\phi(m/M)e(-hm/M)$ 为直接通道。由 (10) 对**每个** $h$ 得
\[
 \boxed{\quad
 \mathcal A_h^{(f)}-\mathcal A_h^{(\mu)}
 =-4(\log2)\bigl(D_h^{(f)}-D_h^{(\mu)}\bigr)
 =-\frac{4\log2}{M}
 \sum_{M<p<2M}(f(p)+1)\phi(p/M)e(-hp/M).
 \quad}\tag{11}
\]
所以 [scratch/863](863-direct-mobius-observation-channel-is-not-a-necessary-standalone-gate.md) 的线性反模型不能同时保留乘法性、真实初始段及观察窗内的半素数素数幂支撑。式 (11) 只控制**两个系数系统之间的差**；它不给真实 $D_h^{(\mu)}$ 或 $\mathcal A_h^{(\mu)}$ 的固定幂上界。
