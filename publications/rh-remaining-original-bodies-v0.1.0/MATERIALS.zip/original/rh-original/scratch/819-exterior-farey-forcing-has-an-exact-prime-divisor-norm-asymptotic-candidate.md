# 多项式外 Farey 槽 forcing 的素数除数公式与精确范数主项（候选）

日期：2026-09-29。承接 [scratch 817](817-polynomial-denominator-exterior-slots-have-logarithmic-farey-leakage-candidate.md) 的真实旧奇外槽投影，并沿用 [scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的外槽几何。本结果计算的是**交叉块 forcing 的完整范数主项**；它不估计外槽自身的异臂近共振矩阵，也不把范数泄漏认作 Schur 成本。尚缺异源独立复核，暂留 scratch。

## 命题

令 \(p\to\infty\) 沿奇素数，\(H=\log p\)，取固定参数

\[
0<\beta<\min\{\alpha,1-\alpha,1/2\},\qquad
Q=\lfloor p^\alpha\rfloor,\quad B=\lfloor p^\beta\rfloor,
\]

并采用 scratch 817 的源向量 \(v_{p,\alpha}\)、目标族 \(\mathcal Y_{p,B}\) 及投影 \(P_Z=P_{Z_{p,B}}\)。定义真实算术 forcing 的正系数列

\[
t_{m/b}:=-\langle w_{m/b},\mathcal R_{p^2}v_{p,\alpha}\rangle,
\qquad m/b\in\mathcal Y_{p,B}.
\]

若 \(g_n(m)=\gcd(m,n)\)，则有逐槽**精确公式**

\[
\boxed{
t_{m/b}=\frac1{\sqrt{mb}}
\sum_{\substack{n\ge2\ \mathrm{prime\ power}\\
\max\{m/g_n(m),\,bn/g_n(m)\}<Q}}
\Lambda(n)\frac{g_n(m)}n.}
\tag{1}
\]

特别地，素数部分为

\[
\boxed{
t^{\rm pr}_{m/b}=\frac{F_Q(m)}{\sqrt{mb}},\qquad
F_Q(m)=\sum_{\substack{q\mid m,\ q\ {\rm prime}\\m/q<Q}}\log q.}
\tag{2}
\]

令 \(r=t-t^{\rm pr}\)，\(D=p/Q\)。有

\[
\boxed{
\|r\|^2\ll_{\alpha,\beta}
H^5D^{-1/2}+H^4\sqrt{B/p}+H^4D^{-2}=o(1).}
\tag{3}
\]

定义两个显式非负常数

\[
\begin{aligned}
J_{\rm diag}(\alpha,\beta)
&=\int_0^\beta\!\int_0^\alpha
\left((1-u)v+\frac{v^2}{2}\right)du\,dv
=\frac{\alpha(1-\alpha/2)\beta^2}{2}
 +\frac{\alpha\beta^3}{6},\\
J_{\rm pair}(\alpha,\beta)
&=\frac12\int_1^{\min(1+\beta,\,2\alpha)}
(1+\beta-s)(2\alpha-s)^2\,ds,
\end{aligned}
\tag{4}
\]

第二个积分在上限不超过 (1) 时定义为零。则

\[
\boxed{
\frac{\|P_ZA_{p^2,-}v_{p,\alpha}\|^2}{H^4}
\longrightarrow
\frac{J_{\rm diag}(\alpha,\beta)+J_{\rm pair}(\alpha,\beta)}{\zeta(2)}.}
\tag{5}
\]

结合 \(\|v_{p,\alpha}\|^2\sim\alpha^2H^2/(2\zeta(2))\)，这也给出归一化泄漏的**极限**

\[
\frac{\|P_ZA_{p^2,-}v_{p,\alpha}\|}{H\|v_{p,\alpha}\|}
\longrightarrow
\frac{\sqrt{2(J_{\rm diag}+J_{\rm pair})}}\alpha.
\tag{6}
\]

例如 \(\alpha=2/3,\ \beta=1/4\) 时，

\[
J_{\rm diag}=\frac1{64},\qquad
J_{\rm pair}=\frac{19}{18432},\qquad
J_{\rm diag}+J_{\rm pair}=\frac{307}{18432},
\]

所以 (6) 的极限为 \(\boxed{\sqrt{307}/64}\)。scratch 817 式 (4) 只给 \(\sqrt3/8\) 的下极限；此处增量来自 \(a<b\) 的合法源槽和同一目标的两个不同素数除数。

## 精确 forcing 与较高素数幂

目标 \(y=m/b\) 满足 \(p\le m<bp\)、\(2\le b\le B\)、\((m,b)=1\)。scratch 817 的分数间距证明说明：任一源 \(x\in\mathcal F_Q\) 经素数幂平移后，只有**整槽中心精确重合**才可能投影到 \(w_y\)。给定平移指标 \(n\)，唯一可能的源是 \(x=\operatorname{fold}(y/n)\)，其中 \(\operatorname{fold}(z)=\max(z,z^{-1})\)。把 \(y/n=m/(bn)\) 约分，既约分子、分母分别为 \(m/g_n(m)\)、\(bn/g_n(m)\)。它属于 \(\mathcal F_Q\) 当且仅当两者都小于 \(Q\)。两臂各给半权，合计矩阵元 \(-\Lambda(n)/\sqrt n\)；源权重为 \(g_n(m)/\sqrt{mbn}\)。这证明 (1)。由于 \(m\ge p>Q\)，(1) 中每项必满足

\[
g_n(m)>m/Q\ge D.\tag{7}
\]

若 \(n=q\) 为素数，(7) 迫使 \(q\mid m\)，于是 \(g_q(m)=q\)。又 \(b\le B<Q\)，剩余条件正是 \(m/q<Q\)；目标既约且 \(b\ge2\)，不会出现源 (1)。这证明 (2)。同时 \(q>m/Q\ge D>B\)，所以这些素数自动与 \(b\) 互素。

为证明 (3)，对固定 \(m\) 将 (1) 中指数至少 \(2\) 的贡献记为 \(R(m)\)，忽略 \(bn/g<Q\) 只会增大它。若 \(\ell\Vert m\)，(7) 要求 \(\ell>D\)，而它的全部较高幂贡献至多

\[
\sum_{j\ge2}(\log\ell)\ell^{1-j}
=\frac{\log\ell}{\ell-1}\ll H/D.
\]

这样的不同 \(\ell\) 至多 \(\log(Bp)/\log D=O_{\alpha,\beta}(1)\) 个。若 \(v_\ell(m)\ge2\) 且该素数有贡献，则 (7) 说明 \(m\) 被某个 \(h=\ell^j>D\)、\(j\ge2\) 整除。把这种 \(m\) 的指示函数记为 \(E(m)\)。所有 \(v_\ell(m)\ge2\) 的贡献之和不超过 \(2\log m\ll H\)：\(j\le v_\ell(m)\) 的部分总和至多 \(\sum_{\ell\mid m}v_\ell(m)\log\ell=\log m\)，\(j>v_\ell(m)\) 的几何尾也至多 \(\sum_{\ell\mid m}\log\ell\le\log m\)。因此

\[
0\le R(m)\ll H\bigl(E(m)+D^{-1}\bigr).\tag{8}
\]

设 \(X=Bp\)。指数至少 (2) 的素数幂 \(h\le X\) 的计数为 \(O(\sqrt X\log X)\)，分部求和给

\[
\sum_{\substack{D<h\le X\\h\text{ 为较高素数幂}}}\frac1h
\ll\frac{\log X}{\sqrt D}.\tag{9}
\]

对每个 \(h\le X\)，按 \(m=hj\) 求调和和，得到

\[
\sum_{p\le m<bp,\ h\mid m}\frac1m
\ll\frac{\log b}{h}+\frac1p.\tag{10}
\]

以 (9)--(10) 对 \(E(m)\) 作并集界，再用

\[
\sum_{b\le B}\frac{\log b}{b}\ll H^2,
\qquad \sum_{b\le B}\frac1b\ll H,
\]

得到

\[
\sum_{b\le B}\frac1b\sum_{p\le m<bp}\frac{E(m)}m
\ll H^3D^{-1/2}+H^2\sqrt{B/p}.
\tag{11}
\]

不带 \(E(m)\) 的同一调和和为 \(O(H^2)\)。由 \(r_{m/b}=R(m)/\sqrt{mb}\)，将 (8)--(11) 相乘即得 (3)。这里为上界而忽略 \((m,b)=1\)；故不依赖筛法。

## 素数 forcing 的范数主项

将 (2) 平方并按是否取到同一素数拆开。对角部分精确为

\[
\mathcal D_p=
\sum_{2\le b\le B}\frac1b
\sum_{\substack{1\le a<Q\\(a,b)=1}}\frac1a
\sum_{\substack{q\ {\rm prime}\\p\le aq<bp}}
\frac{(\log q)^2}{q}.
\tag{12}
\]

这里 \(q\ge p/a\ge D>B\)，故 \((aq,b)=1\) 与 \((a,b)=1\) 等价；源 \(\operatorname{fold}(a/b)\) 的两个分子分母均小于 \(Q\)。由素数定理的加权对数形式与互素双调和 Riemann 和，

\[
\frac{\mathcal D_p}{H^4}
\longrightarrow \frac1{\zeta(2)}
\int_0^\beta\!\int_0^\alpha
\int_{1-u}^{1-u+v}w\,dw\,du\,dv
=\frac{J_{\rm diag}}{\zeta(2)}.
\tag{13}
\]

两个**不同**素数 \(q,r\) 同时除以目标分子时，唯一写法是 \(m=dqr\)。它们的有序交叉和精确为

\[
\mathcal O_p=
\sum_{2\le b\le B}\frac1b
\sum_{\substack{d\ge1\\(d,b)=1}}\frac1d
\sum_{\substack{q\ne r\ {\rm primes}\\
p\le dqr<bp,\ dq<Q,\ dr<Q}}
\frac{(\log q)(\log r)}{qr}.
\tag{14}
\]

条件迫使 \(q,r>p/Q>D>B\)，所以 \((dqr,b)=1\) 仍等价于 \((d,b)=1\)。写 \(\delta=\log d/H\)、\(u=\log q/H\)、\(v=\log r/H\)、\(w=\log b/H\)。基本弱极限为

\[
\frac1H\sum_{q\ {\rm prime}}\frac{\log q}{q}
\delta_{\log q/H}\Longrightarrow du,
\quad
\frac1{H^2}\sum_{(d,b)=1}\frac1{db}
\delta_{(\log d/H,\log b/H)}
\Longrightarrow\frac{d\delta\,dw}{\zeta(2)}.
\tag{15}
\]

第二式在固定指数矩形内成立：展开 \(1_{(d,b)=1}=\sum_{h\mid(d,b)}\mu(h)\)，先固定 \(h\) 求两重调和 Riemann 和，再以 \(\sum_{h>M}h^{-2}\) 控制尾。两素数权测度的乘积极限来自素数定理。式 (14) 的不等式边界是零 Lebesgue 测度；删去 \(q=r\) 不改极限，因为其贡献可用 \(\sum_{q>D}(\log q)^2/q^2=o(1)\) 乘两个 \(O(H)\) 调和和控制。因此

\[
\frac{\mathcal O_p}{H^4}
\longrightarrow\frac1{\zeta(2)}
\int_{\substack{0<w<\beta,\;\delta,u,v>0\\
\delta+u<\alpha,\;\delta+v<\alpha\\
1<\delta+u+v<1+w}}
d\delta\,du\,dv\,dw.
\tag{16}
\]

令 \(s=\delta+u+v\)。固定 \(s\) 时，
\(u,v>s-\alpha\) 且 \(u+v\le s\)，故 \(u,v\) 的截面积为
\((2\alpha-s)^2/2\)（仅 \(s<2\alpha\) 时非零）。而允许的 \(w\) 长度为 \(1+\beta-s\)。于是 (16) 恰是 \(J_{\rm pair}/\zeta(2)\)。

由 \(\|t^{\rm pr}\|^2=\mathcal D_p+\mathcal O_p=O(H^4)\) 及 (3)，
\(\|t\|^2=\|t^{\rm pr}\|^2+o(H^4)\)。scratch 817 的非算术投影估计给
\(\|P_Z(G_{p^2}-2|s_{p^2}\rangle\langle s_{p^2}|)v_{p,\alpha}\|=o(1)\)，故同一主项适用于完整 \(P_ZA_{p^2,-}v_{p,\alpha}\)，证明 (5)。scratch 817 式 (10) 给源范数，遂得 (6)。代入 \(\alpha=2/3,\beta=1/4\) 并直接积分得到上述 \(307/4096\)。\(\square\)

## 边界

式 (5) 是真实完整旧奇算子的外槽**交叉块范数**精确主项。异臂 \(N^{\rm opp}_{p,B}\) 作用在实际 \(t\) 上的有符号二次型仍未估计；特别是 (3) 的 \(o(1)\) 范数误差，未经 \(N^{\rm opp}\) 的算子控制不能自动转化为其二次型误差。不能由 (5) 推出负谱、完整 Schur 成本、全尺度局部 Weil 正性或 RH，也不能代替 moving-\(N\) Möbius signed covariance 的 \(Y^{2+\varepsilon}\) 门。
