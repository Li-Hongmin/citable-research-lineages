# 首个既约分子的素数—非素数负协方差保留全部谐波重合（候选）

日期：2026-09-29。依赖 [scratch 833](833-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff-candidate.md) 式 (5) 的精确 Fourier 公式、[scratch 834](834-moving-cutoff-log-zero-pays-low-farey-frequencies-in-full-k2-residual-candidate.md) 式 (2) 的真实未控扇区，以及 [scratch 835](835-first-primitive-numerator-has-negative-prime-composite-covariance-candidate.md) 式 (10)、(17) 的严格正数 \(K_1\) 和素数主项。本文把 \(h=1\) 扩大到同一既约分子 \(a=1\) 的**全部** \(h=k,d=kq\)；尚待异源复核，留在 scratch。

## 命题

令 \(Y<N\le2Y\)、\(Q=\lfloor Y^{4/5}\rfloor\)、\(H=\log(2Y)\)，并令 \(\mathcal A_1(N)\) 为 833 式 (5) 中 \(h<d<N\)、既约频率 \(h/d=1/q\)、\(q>Q\) 的全部项。将 \(\mu(d)\) 拆成素数系数 \(c^{\rm pr}_p=-1\) 和其余系数，记相应子和为 \(P_1(N)\) 与 \(C_1(N)\)，故 \(\mathcal A_1=P_1+C_1\)。存在绝对常数 \(c>0\)，使
\[
\boxed{\quad
\mathcal A_1(N)\ll N H^2e^{-c\omega(Y)},
\qquad
P_1(N)=-K_1\frac N{\log N}+O\!\left(\frac N{\log^2N}\right),
\quad}
\tag{1}
\]
其中 \(\omega(Y)=(\log Y)^{3/5}(\log\log Y)^{-1/5}\)，且 \(K_1>0\) 由 835 式 (10) 定义。因此
\[
\boxed{\quad
\sum_{Y<N\le2Y}P_1(N)C_1(N)
=-\frac{7K_1^2}{3}\frac{Y^3}{\log^2Y}
+O\!\left(\frac{Y^3}{\log^3Y}\right).
\quad}
\tag{2}
\]
这条负交叉项完全在 834 式 (2) 的 \(q>Y^{4/5},a<Y^{1/3}\) 扇区内，且包含同频率的全部倍数重合；它不控制不同既约分子的交叉项。
更定量地，\(\|P_1+C_1\|_{\ell^2(Y,2Y]}/\|P_1\|_{\ell^2(Y,2Y]}\ll H^3e^{-c\omega(Y)}\)：素数与非素数部分在这个完整分子块中渐近反向对齐。

## 精确分组

在 833 式 (5) 中令 \(h=k,d=kq\)，于是 \(q>Q\)、\(kq<N\)。置
\[
B_k(s)=\frac{4\mathbf1_{2\mid k}}{1-4s^2}-\frac1{1-s^2},
\qquad
u_{k,N}(q)=\frac qN\log\frac N{kq}
B_k(q/N)\cos\frac{2\pi N}{q}.
\tag{3}
\]
因 \(\mu(kq)=\mu(k)\mu(q)\mathbf1_{(k,q)=1}\)，精确地有
\[
\boxed{\quad
\mathcal A_1(N)=-\frac1\pi
\sum_{1\le k<N/Q}\frac{\mu(k)}k
\sum_{\substack{Q<q<N/k\\(q,k)=1}}
\mu(q)u_{k,N}(q).
\quad}
\tag{4}
\]
这里 \(q\) 为整数；若 \(k=1\) 或 \(2\)，(3) 在 \(q=N/k\) 的表面奇性由 \(\log(N/(kq))\) 消去。原和使用严格 \(q<N/k\)，不需要加入端点。
特别地 \(B_1(s)=-1/(1-s^2)\)，所以 (4) 的 \(k=1\) 项逐项等于 835 式 (11) 的 \(\mu(q)f(q/N)\)，固定了符号。

## 带互素条件的统一 Mertens 界

设 \(\mathcal V_k\) 是全部素因子均整除 \(k\) 的正整数集，并记
\(M_k(x)=\sum_{q\le x,(q,k)=1}\mu(q)\)。Euler 因子给出精确卷积式
\[
\mu(n)\mathbf1_{(n,k)=1}
=\sum_{\substack{vm=n\\v\in\mathcal V_k}}\mu(m),
\qquad
M_k(x)=\sum_{\substack{v\le x\\v\in\mathcal V_k}}M(x/v).
\tag{5}
\]
经典零自由区给 \(M(t)\ll t e^{-b\omega(t)}\)。当
\(Q\le x\le2Y\)、\(k\le2Y/Q\) 时，将 (5) 在 \(v=\sqrt x\) 分开。小 \(v\) 部分由
\[
\sum_{v\in\mathcal V_k}v^{-1}=k/\varphi(k)\ll H,
\qquad \omega(\sqrt x)\gg\omega(Y)
\]
给出 \(O(xH e^{-b'\omega(Y)})\)。大 \(v\) 部分用 \(|M(x/v)|\le x/v\) 与 Rankin 界
\[
\sum_{\substack{v>\sqrt x\\v\in\mathcal V_k}}v^{-1}
\le x^{-1/4}\prod_{p\mid k}(1-p^{-1/2})^{-1}
\ll x^{-1/4}e^{C\sqrt H}.
\]
最后一步只需把不同素因子按大小排列，第 \(j\) 个至少为 \(j+1\)，且素因子数至多 \(H/\log2\)。由于 \(x\ge Q=Y^{4/5+o(1)}\)，大 \(v\) 项比 \(e^{-c\omega(Y)}\) 更小。吸收 \(H\) 后得到某个绝对 \(c>0\) 的一致界
\[
\boxed{\quad M_k(x)\ll x e^{-c\omega(Y)}
\qquad(Q\le x\le2Y,\ k\le2Y/Q).\quad}
\tag{6}
\]

## 统一变差与 Abel 求和

令 \(s=q/N\)、\(s_0=Q/N\)，并写
\[
v_k(s)=s\log\frac1{ks}\,B_k(s),
\qquad g_k(s)=v_k(s)\cos\frac{2\pi}{s},
\qquad s_0\le s\le1/k.
\]
对 \(k\ge3\)，整个区间 \(s\le1/3\) 上的两个分母均离零有绝对距离。对 \(k=1\)，\(\log(1/s)/(1-s^2)\) 在 \(s=1\) 光滑延拓；对 \(k=2\)，\(\log(1/(2s))/(1-4s^2)\) 在 \(s=1/2\) 光滑延拓。直接微分后，三个情形统一满足
\[
|v_k(s)|\ll s(1+\log(1/s)),
\qquad |v'_k(s)|\ll1+\log(1/s).
\tag{7}
\]
因此
\[
\sup_{s_0\le s\le1/k}|g_k(s)|
+\operatorname{Var}_{[s_0,1/k]}g_k
\ll1+\int_{s_0}^1\frac{1+\log(1/s)}s\,ds
\ll H^2,
\tag{8}
\]
一致于所有 \(k<N/Q\)。由 (6) 对 (4) 的每个内和作 Stieltjes 分部求和，得
\[
\left|\sum_{\substack{Q<q<N/k\\(q,k)=1}}
\mu(q)u_{k,N}(q)\right|
\ll \frac Nk e^{-c\omega(Y)}H^2.
\tag{9}
\]
式 (4) 外部还有 \(1/k\)，故 \(\sum_{k\ge1}k^{-2}<\infty\) 给 (1) 的第一式。

## 素数与协方差

若 \(d=p\) 为素数且 \(h/d=1/q\)，则 \(h=k=1,q=p\)；素数部分因而正是 835 式 (17) 的 \(P_{>Q}^{(h=1)}\)。该式给 (1) 的第二式。式 (1) 的第一式对任意固定 \(B>0\) 也给 \(\mathcal A_1(N)=O_B(N/\log^B N)\)。取 \(C_1=\mathcal A_1-P_1\)，逐 \(N\) 相乘，并用
\(\sum_{Y<N\le2Y}N^2/\log^2N=(7/3)Y^3/\log^2Y+O(Y^3/\log^3Y)\)，即得 (2)。\(\square\)

## 边界

该结果只说明 \(a=1\) 分子块内部必须发生大负协方差。(1) 单独平方只有 \(\sum_N|\mathcal A_1(N)|^2\ll Y^3H^4e^{-2c\omega(Y)}=Y^{3-o(1)}\) 的上界，尚差接近一整幂；它仍允许不同分子块之间形成远大于目标的正交叉，也不给 \(\sum_N|\mathcal U_N|^2\ll_\varepsilon Y^{2+\varepsilon}\)。它不是 RH、全尺度局部 Weil 正性或完整 moving-\(N\) 门的证明。
