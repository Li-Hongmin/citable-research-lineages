# 次指数增长末带素数载波与完整 k=2 余项的负协方差

日期：2026-10-02。依赖 [note 848](../notes/848-fixed-power-prime-source-cross-covariance-with-full-k2-residual.md) 的完整余项载波投影证明及原始源分解、[note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 短和、[scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 的增长族**素数源波形**展开。本文将 note 848 的对数投影界强化为次指数界，并把其单管负协方差推进到次指数增长管族；证明不使用 scratch 958 中依赖互素短和引理的完整 Möbius 管估计。2026-10-02 又直接复查 K. Ramachandra, *Some problems of analytic number theory*, *Acta Arith.* **31** (1976), 313–324, DOI 10.4064/aa-31-4-313-324，原版第 315–316 页 Main Theorem (10)、Remark 4–5：其中确为全部 $1\le u\le x$ 一致的 $u e^{-c(\log x/\log\log x)^{1/3}}+x^{7/12+\varepsilon}$，且允许 $F=1/\zeta$ 及 $F=-\zeta'/\zeta$。本稿尚未异源复核，故仍留在 `scratch/`。结论不控制完整余项均方，也不证明 RH。

## 定理

固定 $0<\gamma<1/4$，$H=\lfloor Y^\gamma\rfloor$，$V_Y=(\log Y/\log\log Y)^{1/3}$。存在 $c_\gamma>0$，使任意 $h\in[H,2H]$、固定支撑于 $(3/2,8/5)$ 且 $C^3$ 范数一致有界的光滑函数 $\psi$、以及
\[
 \bigl||Y\xi|-h\bigr|\le1/10
\]
都有完整真实余项 $\mathcal R_{N,2}$ 的统一载波投影界
\[
 \boxed{\quad
 \left|\sum_{Y<N\le2Y}\psi(N/Y)e(\xi N)\mathcal R_{N,2}\right|
 \ll_{\gamma,\psi}\frac{Y^2}{H^2}e^{-c_\gamma V_Y}.
 \quad}\tag{1}
\]
这强化 [note 848](../notes/848-fixed-power-prime-source-cross-covariance-with-full-k2-residual.md) 式 (6) 的任意对数幂节省，量词与原始完整余项保持相同。

再固定非负、非零的 $\chi\in C_c^\infty((3/2,8/5))$。取 $R=R(Y)\to\infty$、$R\le e^{c_*V_Y}$，其中 $c_*>0$ 只需小于下文素数源误差与余项投影的两个次指数常数，并按 [scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 定义真实 $G_r$，置
$G^{(R)}_N=\sum_{r=0}^RG_r(N)$、$h_r=H+r$、$A_Y=Y^3/[H^4(\log Y)^4]$。则
\[
 \boxed{\quad
 \sum_N\chi(N/Y)G^{(R)}_N\mathcal R_{N,2}=o_{\gamma,\chi}(A_Y),
 \quad}\tag{2}
\]
\[
 \boxed{\quad
\sum_N\chi(N/Y)G^{(R)}_N
   (\mathcal R_{N,2}-G^{(R)}_N)
=-(C_{\infty,\chi}+o_{\gamma,\chi}(1))A_Y,
 \quad}\tag{3}
\]
其中
\[
 C_{\infty,\chi}
 =\frac1{4\pi^2}\int_{3/2}^{8/5}
 \chi(z)\frac{\mathcal L(z)^2}{z^2\cos^2(\pi(z-3/2))}\,dz>0.
\tag{4}
\]
记 $C_N^{(R)}=\mathcal R_{N,2}-G_N^{(R)}$，则还有
\[
 \sum_N\chi(N/Y)|C_N^{(R)}|^2
 \ge (C_{\infty,\chi}+o_{\gamma,\chi}(1))A_Y.\tag{4a}
\]
这里 (3) 是增长真实素数源与**完整**余项中全部其他项的 signed 负协方差；(4a) 定量说明补集至少承载与素数源相同阶的能量。该量级 $A_Y=Y^{3-4\gamma+o(1)}$ 仍高于 $Y^{2+\varepsilon}$ 目标。

## 证明统一次指数载波投影

沿用 note 848 式 (7)–(10) 的原始核 $f(u,z)$、连续载波权 $K(u)$ 及其变差界。低原始除数 $d\le D_0=\lfloor Y^{3/4}\rfloor$ 的平方和由 note 753 给 $O(Y^2\log^2Y)$，故其投影由 Cauchy--Schwarz 至多 $O_\psi(Y^{3/2}\log Y)$。因为 $\gamma<1/4$，该项与 (1) 右侧之比是 $O(Y^{2\gamma-1/2}\log Y\,e^{c_\gamma V_Y})=o(1)$。

对每条高除数二进制带 $D<d\le2D$、$Y^{3/4}\le D\ll Y$，仍取 note 848 的块长 $B_D=\lfloor D/h\rfloor$（把原式中的 $H$ 换为当前 $h\asymp H$）。取 Ramachandra 指数 $\vartheta=5/8=7/12+1/24$。对每个完整块和任意前缀，note 851 式 (4) 一致给
\[
 \left|\sum_{d\in I,\ d\le v}\mu(d)\right|
 \ll B_D e^{-c_0V_Y}+D^{5/8}.
\tag{5}
\]
最后不完整块写成一个长块的两个前缀，仍适用同界。关键固定幂裕量是
\[
 \frac{D^{5/8}}{B_D}
 \ll\frac h{D^{3/8}}
 \ll Y^{\gamma-9/32}
 \le Y^{-1/32},
\tag{6}
\]
因为 $D\ge Y^{3/4}$、$\gamma<1/4=8/32$。缩小 $c_0>0$ 后，(5) 因而为 $O(B_D e^{-c_1V_Y})$，对全部 $D,h,I,v$ 一致。
这里 $D\asymp Y^\alpha$、$3/4\le\alpha\le1+o(1)$，所以 $(\log D/\log\log D)^{1/3}\gg V_Y$；Ramachandra 界中的次指数因子可统一写成 $e^{-c_0V_Y}$。

note 848 式 (10)、(15) 对块上的 $K$ 给
\[
 \sup|K|+\operatorname{Var}K
 \ll_\psi\frac{Y\ell(D/Y)}{H^2(D/Y)},
 \qquad \ell(u)=1+\log(2/u).
\tag{7}
\]
每条 $D$ 带有 $O(D/B_D)=O(H)$ 个块。由 (5)–(7) 作 Abel 求和，该带贡献至多
\[
 O_\psi\!\left(\frac{Y^2\ell(D/Y)}{H^2}e^{-c_1V_Y}\right).
\tag{8}
\]
带数 $O(\log Y)$，且 $\ell(D/Y)\ll\log Y$；因为 $V_Y/\log\log Y\to\infty$，两个对数因子可吸收进更小的 $e^{-c_2V_Y}$。note 848 式 (17) 的整数观察求积误差仍为 $O_\psi(YH\log^2Y)$，相对 $Y^2/H^2$ 的比是 $O(H^3\log^2Y/Y)=Y^{3\gamma-1+o(1)}$，也吸收到 $e^{-c_2V_Y}$。合并低层、连续高层与采样误差，证明 (1)。负 $\xi$ 由实核与共轭对称处理。$\square$

更明确地，除以 $Y^2/H^2$ 后，三个来源的总误差由
\[
 O_{\gamma,\psi}\!\left(
 Y^{-1/2+2\gamma}\log Y
 +(\log Y)^2\bigl(e^{-c_0V_Y}+Y^{-1/32}\bigr)
 +Y^{-1+3\gamma}(\log Y)^2\right)
\tag{8a}
\]
控制。第一项来自低除数，第二项同时保留短和主误差和 $D^{5/8}$ 余项，第三项来自整数采样；三者在 $0<\gamma<1/4$ 内一致小于 $e^{-c_2V_Y}$（适当缩小 $c_2$）。

## 增长源与完整余项的交叉

固定 $r\le R$。对 note 845 的每个真实素数源 $(a,p)$，note 848 式 (18) 将
$\chi(N/Y)F_{a,p}(N)$ 写为 $a^{-2}\psi_{a,p}(N/Y)\cos(2\pi aN/p)$；其中 $\psi_{a,p}$ 的支撑与 $C^3$ 范数对 $r,a,p$ 一致有界。由 [scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 式 (4)，
$|Ya/p-h_r|=O(1/\log Y)<1/10$，所以 (1) 分别用于正负余弦载波。素数计数的统一界与 note 848 式 (19) 给
\[
 \sum_{a,p\in G_r}a^{-2}
 \ll_\gamma \frac{Y}{H^2(\log Y)^2}
\tag{9}
\]
对全部 $r\le R$ 一致。故
\[
 \left|\sum_N\chi(N/Y)G_r(N)\mathcal R_{N,2}\right|
 \ll_{\gamma,\chi}
 \frac{Y^3}{H^4(\log Y)^2}e^{-c_2V_Y}
 \ll A_Ye^{-c_3V_Y}
\tag{10}
\]
（两个对数因子再次由 $V_Y\gg\log\log Y$ 吸收）。对固定 $a$，相邻 $h$ 的中心 $aY/h$ 间距为 $\asymp Y/H$，而每个素数窗长为 $O(Y/(H\log Y))$；因此这些窗口对不同 $r$ 最终不交，$G^{(R)}$ 确是原始 Poisson 展开中不重复的一个真实子和。令 $c_{\rm p}>0$ 为 scratch 958 式 (9) 的素数源误差指数，选择 $c_*<\min(c_3,c_{\rm p})$，对 $R+1\le e^{c_*V_Y}+1$ 个 $r$ 求和即得 (2)，且下文所需的素数波形余项也是 $o(A_0)$。这里不使用 scratch 958 式 (19)–(20) 的互素短和指数。

[scratch 958](958-subexponentially-many-terminal-carriers-retain-bounded-joint-energy.md) 式 (18) 的**素数源**波形展开在观察窗逐点一致，其证明只用该稿式 (4)–(18) 的素数短和与有界变差，不用式 (19)–(20) 的互素 Möbius 短和。置 $A_0=Y/[\pi H^2(\log Y)^2]$、$f(z)=\mathcal L(z)/z$、$D_R(z)=\sum_{r=0}^Re(rz)$，则一致有 $G_N^{(R)}=A_0f(z)\operatorname{Re}(e(Hz)D_R(z))+o(A_0)$。在 $\operatorname{supp}\chi$ 上，$|1-e(z)|$ 有固定正下界，所以 $D_R=O(1)$、$D_R'=O(R+1)$。整数 Riemann 求和相对 $YA_0^2$ 的误差为 $O((H+R)/Y)=o(1)$。平方的快速项为 $\operatorname{Re}(e(2Hz)D_R(z)^2)$，其积分经一次分部积分为 $O((R+1)^2/H)=o(1)$，因为 $R=Y^{o(1)}$。剩下的
\[
 |D_R(z)|^2=\frac{2-2\cos(2\pi(R+1)z)}{|1-e(z)|^2}
\]
中，振荡项由 Riemann--Lebesgue 引理趋零；又 $|1-e(z)|^2=4\cos^2(\pi(z-3/2))$ 且 $YA_0^2=A_Y/\pi^2$。因此逐项得到
\[
 \sum_N\chi(N/Y)|G^{(R)}_N|^2
 =(C_{\infty,\chi}+o(1))A_Y.
\tag{11}
\]
由 (2) 减去 (11)，得到 (3)。最后，$\chi\ge0$ 使加权内积满足 Cauchy--Schwarz；将 (3) 的平方除以 (11)，便得 (4a)。$\square$

## 边界

式 (1) 仍只是一维载波投影界；以它对全部 $h\asymp H$ 求绝对值再作 Parseval，只得到 note 848 式 (21) 的 $Y^3/H^3$ 量纲附次指数节省，在 $H<Y^{1/4}$ 时仍高于 $Y^{2+\varepsilon}$ 目标。式 (3) 只测试一个特殊的增长素数源方向，不界定完整余项的正交补能量。因此下一项会改变 RH 算术门判断的观测必须是完整频带上的二点 signed 平均，或一个能控制所有遗漏方向的 coercive 机制。
