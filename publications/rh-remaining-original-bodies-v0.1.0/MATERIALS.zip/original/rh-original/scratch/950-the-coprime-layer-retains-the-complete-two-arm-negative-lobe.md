# 完整两臂负核瓣在互素真实源层仍有常量级双符号质量

日期：2026-10-02。沿用 [scratch/949](949-the-complete-two-arm-gevrey-ring-retains-a-macroscopic-negative-lobe.md) 的 Gevrey 权、真实两臂 Gram、单乘子窗口及负瓣；短 Möbius 和只用 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 已核对的 Ramachandra 输入。本稿给出一个完整证明，但尚无异源复核，故留在 `scratch/`。它不估计完整 moving-$N$ signed covariance，也不证明 RH。

## 定理

设 $M=2Y$、$Y^{1/5}\le H\le Y^{1/4}$，固定 $s>1$，取 scratch/949 式 (6a) 的 $\eta$，以及该稿的 $\psi,\phi,J,\kappa,\alpha=1/4,\beta=5/12$ 和
\[
\mathcal U_M=\{u\text{ odd}:3u/M\in J\},\qquad
V_M=(\log M/\log\log M)^{1/3}.
\]
在**完整两臂** $G_{u,v}$ 中，定义互素层
\[
P^{\pm,\mathrm{cop}}_{M,H}=
\sum_{\substack{u,v\in\mathcal U_M,\ (u,v)=1\\
\alpha<3H(v-u)/M<\beta,\ \mu(u)\mu(v)=\pm1}}
\mu(u)\mu(v)G_{u,v}.                                      \tag{1}
\]
置
\[
\delta_{\mathrm{cop}}=\frac14
\prod_{p\ge3}\left(1-\frac3{p^2}+\frac2{p^3}\right)>0,
\qquad
\mathscr N_{\mathrm{cop}}=
\frac{\kappa^2\delta_{\mathrm{cop}}}{9}
\left(\int_J\phi(x)^2\,dx\right)
\left(\int_\alpha^\beta-\widehat\eta(z)\,dz\right)>0.       \tag{2}
\]
则对某个固定 $c>0$，一致于上述 $H$，
\[
P^{+,\mathrm{cop}}_{M,H}+P^{-,\mathrm{cop}}_{M,H}
\ll_{\psi,\eta,J}e^{-cV_M},                                   \tag{3}
\]
并且
\[
P^{+,\mathrm{cop}}_{M,H}=-\frac{\mathscr N_{\mathrm{cop}}}{2}+o(1),
\qquad
P^{-,\mathrm{cop}}_{M,H}=+\frac{\mathscr N_{\mathrm{cop}}}{2}+o(1). \tag{4}
\]
式 (1) 中每个非零 $G_{u,v}$ 都严格为负，且所有对均在 note 850 式 (18) 的完整留存环带内。特别地，负瓣并非由增长的共同因子层制造；单独的 $g=(u,v)=1$ 层已有两种非零 Möbius 符号质量。式 (3) 是这一子层的次指数净抵消，仍远弱于固定幂内点的 $O(H^4/M)$ 完整门。

## 普通短和支付增长模数的互素限制

先证明本稿所需的一阶引理。固定 $0<\vartheta<1$。若 $d\le M^\vartheta$、$q\le2M^\vartheta$、$X=M/d$、$B=\lfloor X^{2/3}\rfloor$，则对任意 $I=(x,x+B]\subset[c_0X,C_0X]$，其中 $c_0,C_0>0$ 固定，有某个只依赖 $\vartheta,c_0,C_0$ 的 $c_1>0$，使
\[
\sum_{n\in I}\mu(n)\mathbf1_{(n,q)=1}
\ll B e^{-c_1V_M}.                                         \tag{5}
\]
常数在 $q,d,x$ 上一致。这里 $q$ 不必平方自由。证明从逐点卷积恒等式开始：
\[
\mu(n)\mathbf1_{(n,q)=1}
=\sum_{\substack{r\mid n\\p\mid r\Rightarrow p\mid q}}\mu(n/r). \tag{6}
\]
事实上，对 $p\mid q$，右侧的局部 Dirichlet 级数为
$(1-p^{-z})(1-p^{-z})^{-1}=1$；对 $p\nmid q$ 则为 $1-p^{-z}$。

记 $\mathcal S(q)=\{r\ge1:p\mid r\Rightarrow p\mid q\}$，
$E_\sigma(q)=\sum_{r\in\mathcal S(q)}r^{-\sigma}
=\prod_{p\mid q}(1-p^{-\sigma})^{-1}$。对每个固定 $0<\sigma<1$，
\[
\log E_\sigma(q)\ll_\sigma(1+\log q)^{1-\sigma},
\qquad \log E_1(q)\ll\log(2+\log q).                       \tag{7}
\]
为见前式，设 $L=\max(3,\log q)$，将 $p\mid q$ 分为 $p\le L$ 与 $p>L$：前者的 $p^{-\sigma}$ 和不超过 $\sum_{n\le L}n^{-\sigma}\ll L^{1-\sigma}$；后者至多有 $\log q/\log L$ 个，每项至多 $L^{-\sigma}$。$\sigma=1$ 时用调和和。这也处理 $p=2$ 的固定因子。因此在本引理的 $q$ 范围内，$E_1(q)=\exp(o(V_M))$；对每个固定 $0<\sigma<1$，$E_\sigma(q)=M^{o(1)}$。两种估计均在 $q,d$ 上一致。

将 (6) 在 $I$ 上求和，先取 $r\le R=X^{1/16}$。此时 $x/r\asymp X/r\ge X^{15/16}$，note 851 式 (4) 对普通 $\mu$ 的 Ramachandra 短和（固定 $\varepsilon=1/24$）给
\[
\sum_{m\in I/r}\mu(m)
\ll (B/r)e^{-c_2V_M}+(X/r)^{5/8}                    \tag{8}
\]
某个固定 $c_2>0$；$V_{x/r}\asymp V_M$，全部常数一致。对 $r\le R$ 求和，由 (7) 得
\[
\ll B e^{-c_2V_M}E_1(q)+X^{5/8}E_{5/8}(q)
\ll B e^{-c_3V_M},                                         \tag{9}
\]
因为 $X\ge M^{1-\vartheta}$ 且第二项与 $B$ 的比至多 $X^{-1/24}M^{o(1)}=M^{-(1-\vartheta)/24+o(1)}$。
对 $r>R$ 用平凡界 $\#(I/r)\le B/r+1$。第一部分至多
$B R^{-1/2}E_{1/2}(q)\ll B X^{-1/32}M^{o(1)}$。第二部分只涉及 $r\ll X$；Rankin 界给
\[
\#\{r\in\mathcal S(q):r\ll X\}
\ll X^{1/8}E_{1/8}(q)=X^{1/8}M^{o(1)}.                         \tag{10}
\]
它们也都小于 $B e^{-c_3V_M}$，适当缩小 $c_3$ 即证明 (5)。特别地，将任意长至多 $C X/H$ 的区间拆为长 $B$ 的整块和至多两个余块，得到统一的
\[
\sup_{|I|\le CX/H}
\left|\sum_{n\in I}\mu(n)\mathbf1_{(n,q)=1}\right|
\ll (X/H)e^{-c_1V_M}+X^{2/3}.                              \tag{11}
\]
式 (11) 对很短的末块仍按同一粗界成立；在下面的自然 gcd 截断 $d\le G_\natural$ 内，还有 $X^{2/3}=o(X/H)$。

## 互素 signed 和

在 $u,v\in\mathcal U_M$ 上只有 $k=\ell=3$ 活动，scratch/949 式 (9) 因此给精确式
\[
G_{u,v}=\frac{\kappa^2}{M^2}
\phi(3u/M)\phi(3v/M)J_H(3(u-v)),
\qquad J_H(r)=\sum_h\eta(h/H)e(-hr/M).                       \tag{12}
\]
记 $W_0=M/H$。当前位移带满足 $v-u\asymp W_0$。由于
$|J_H|\ll H$ 且 $|J_H'|\ll H^2/M$，固定 $u$ 后，作为 $v$ 的权
$\phi(3v/M)J_H(3(u-v))$ 在整个许可区间的上确界与总变差均为 $O(H)$；窗口两端的截断跳跃也计入总变差。

用 $\mathbf1_{(u,v)=1}=\sum_{d\mid u,v}\mu(d)$。先对
$d\le Z:=\max\{\lceil e^{V_M}\rceil,G_\natural\}$ 求和，其中 $G_\natural$ 为 note 850 式 (2)。在本段 $H$ 范围内，$G_\natural\ll M^{1/5}\log^4M=o(M^{1/4})$，故可在 (5) 中固定 $\vartheta=1/4$，覆盖全部 $d\le Z$。只需奇数平方自由 $d$；写 $u=da,v=db$，则
\[
\mu(da)\mu(db)
=\mu(d)^2\mu(a)\mu(b)
\mathbf1_{(a,d)=1}\mathbf1_{(b,d)=1}.                         \tag{13}
\]
对固定 $a$，$b$ 落在长 $O(W_0/d)=O((M/d)/H)$ 的区间，并须满足 $(b,2d)=1$。将 (11) 取 $q=2d,X=M/d$，再作离散分部求和，得内层带权和
\[
\ll H\left(\frac{M}{Hd}e^{-c_1V_M}+(M/d)^{2/3}\right). \tag{14}
\]
$a$ 有 $O(M/d)$ 个选择。由 (12)--(14)，第 $d$ 层 signed 和绝对值至多
\[
\ll \frac{e^{-c_1V_M}}{d^2}
 +\frac{H}{M^{1/3}d^{5/3}}.                              \tag{15}
\]
求和 $d\le Z$ 得 $O(e^{-c_1V_M}+HM^{-1/3})=O(e^{-c_4V_M})$。

剩余 $d>Z$ 可绝对支付。因 $d\mid(v-u)$ 且 $0<v-u\ll W_0$，只需 $d\ll W_0$。固定 $d$ 的候选对至多
$(M/d+1)(W_0/d+1)$ 个，每对 $|G_{u,v}|\ll H/M^2$。于是
\[
\begin{aligned}
\sum_{\substack{u,v\in\mathcal U_M,\ \alpha<3H(v-u)/M<\beta\\
d\mid u,v\text{ for some }d>Z}}|G_{u,v}|
&\ll\frac H{M^2}
\sum_{Z<d\ll W_0}(M/d+1)(W_0/d+1)\\
&\ll Z^{-1}+H\log M/M.                                      \tag{16}
\end{aligned}
\]
式 (16) 以并集上界计数；用于 Möbius 反演余项时，上面的未取并集之和也是同一右侧。由 $Z\ge e^{V_M}$ 及 $H\log M/M=o(e^{-cV_M})$，(15)--(16) 证明 (3)。同时 $Z\ge G_\natural$ 使反演尾项的首项 $Z^{-1}$ 至多为 $O(H^4/(M\log^4M))$；阻止 (3) 达到该固定幂目标的仍是 (9) 的次指数项。

## 互素平方自由质量

由 scratch/949 式 (0)、(10)，当前 $z=3H(v-u)/M\in[\alpha,\beta]$ 上
\[
J_H(3(u-v))=H\widehat\eta(z)+O(H e^{-cH^{1/s}}),
\qquad \widehat\eta(z)\le-c_*<0.                           \tag{17}
\]
因此 (12) 严格为负。为计算
\[
A^{\mathrm{cop}}_{M,H}:=-
\sum_{\substack{u,v\in\mathcal U_M,\ (u,v)=1\\
\alpha<3H(v-u)/M<\beta}}
\mu(u)^2\mu(v)^2G_{u,v},                                    \tag{18}
\]
先固定 $Z_0\ge3$，仅禁止共同素因子 $p\le Z_0$。对固定模数
$2\prod_{3\le p\le Z_0}p$ 的每个剩余类，平方自由数的区间计数为
“局部密度 $\times$ 区间长度 $+O_{Z_0}(\sqrt M)$”：展开
$\mu^2(n)=\sum_{r^2\mid n}\mu(r)$，逐 $r\le\sqrt M$ 数该剩余类即可。利用 (12)、(17) 的有界权及分片总变差，先在 $v$、再在 $u$ 作分部求和；归一化总误差
$O_{Z_0}(H/\sqrt M)=o_{Z_0}(1)$，一致于 $H$。CRT 给两变量的局部密度
\[
\delta_{Z_0}=\frac14
\prod_{3\le p\le Z_0}\left(1-\frac3{p^2}+\frac2{p^3}\right)
\prod_{p>Z_0}\left(1-\frac1{p^2}\right)^2.                 \tag{19}
\]
其中 $p=2$ 的 $1/4$ 强制两数均为奇数；已禁止共同 $p$ 的局部选择为 $(0,0),(1,0),(0,1)$，密度 $(1-1/p)^2(1+2/p)=1-3/p^2+2/p^3$。

从固定小素数条件改为真正互素，若存在共同 $p>Z_0$，则用 (16) 同样的计数（从 $p>Z_0$ 求和）给绝对质量 $O(Z_0^{-1})+o(1)$。先令 $M\to\infty$，再令 $Z_0\to\infty$，可将 (19) 换成 (2) 的 $\delta_{\mathrm{cop}}$。在连续双积分里用 $x=3u/M$、$z=3H(v-u)/M$，Jacobian 为 $M^2/(9H)$；$v-u=O(M/H)=o(M)$，故 $\phi(3v/M)=\phi(x)+o(1)$，$J$ 的两端损失 $o(1)$。由 (17) 得
\[
A^{\mathrm{cop}}_{M,H}\longrightarrow\mathscr N_{\mathrm{cop}}. \tag{20}
\]
又 $P^{+,\mathrm{cop}}+P^{-,\mathrm{cop}}$ 是 (3) 的 signed 和，
$-P^{+,\mathrm{cop}}+P^{-,\mathrm{cop}}=A^{\mathrm{cop}}$。
联立 (3)、(20) 得 (4)。互素对自动满足 note 850 的
$g\le G_\natural$、$\max(a,b)>R$；唯一乘子位移为
$3(v-u)\asymp M/H$，处于 $T_\natural<|\Delta|\le U_{s,B}$，由 scratch/949 的参数核对可知。$\square$

## 边界

这里的固定幂门仍未关闭。证明 (3) 使用的一阶短和只给次指数节省；(4) 是经完整两臂配对后，在一个真实互素源子环带上证明正负算术质量同时存活。完整 signed 和允许这一子环带与其他位移、乘子及两臂继续补偿，故不能从 (4) 推出完整和的下界。
