# 宏观对数槽系数的秩一 Weil 首阶算子

日期：2026-10-03。依赖 [notes 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) 的完整 Weil 闭形式，[note 854](../notes/854-integer-log-lattice-sharp-weil-spectral-gap.md) 的精确整数整除矩阵，以及 [notes 857](../notes/857-maximal-integer-log-grid-exact-weil-rayleigh-limit.md)、[858](../notes/858-unit-interval-logarithmic-form-has-a-strict-rank-one-gap.md) 的自然权常数极限与单位轮廓谱隙。[scratch 977](977-macroscopic-integer-log-cut-has-linear-weil-schur-coupling.md) 的两块割是本定理的一个阶梯系数例子。以下是解析证明草稿，尚未异源复核；它不证明或反驳 RH。

## 定理

固定 $0<\theta<1$ 和非负实单位轮廓 $\varphi\in C_c^\infty((-1/2,1/2))$。沿奇素数 $p\to\infty$ 令
\[
 H=\log p,\quad N=\lfloor p^2/2\rfloor-1,\quad L=\log N,
 \quad L_N=\sum_{n\le N}\frac1n,\quad
 \ell=\frac{2\theta}{p^2},\quad y_n=H-\log(2n),
\]
并置 $b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$。对有界变差函数 $f:[0,1]\to\mathbb C$，在槽 $I_n=y_n+(-\ell/2,\ell/2)$ 上定义
\[
 (\mathcal T_N f)(y_n+t)
 =\frac{f(\log n/L)}{\sqrt{nL_N}}b_\ell(t),
 \qquad 1\le n\le N,                                  \tag{1}
\]
其余处为零。写 $\langle f,g\rangle_0=\int_0^1\overline f g$、
$m_f=\int_0^1 f$，并取
$\|f\|_{\mathrm{BV}}=\|f\|_\infty+\operatorname{Var}_{[0,1]}f$。
则对任意 $f,g\in\mathrm{BV}([0,1])$ 有与 $N$ 无关的双线性误差界
\[
 \boxed{\left|\langle\mathcal T_N f,\mathcal T_N g\rangle
           -\langle f,g\rangle_0\right|
 \ll \frac{\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}}{L},} \tag{2}
\]
\[
 \boxed{\left|Q_W^H(\mathcal T_N f,\mathcal T_N g)
       -L\{\langle f,g\rangle_0-\overline{m_f}m_g\}\right|
 \ll_{\theta,\varphi}\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}.} \tag{3}
\]
这里 $Q_W^H(\cdot,\cdot)$ 按第一变量共轭线性的约定极化。
因此每个固定的零均值 $f\ne0$ 满足
\[
 Q_W^H[\mathcal T_N f]=L\|f\|_2^2+O_{\theta,\varphi,f}(1)>0.
 \tag{4}
\]
更一般地，若 $m_{f_N}=0$、$\|f_N\|_2=1$ 且
$\|f_N\|_{\mathrm{BV}}=o(\sqrt L)$，则
$Q_W^H[\mathcal T_N f_N]=L(1+o(1))$。

若固定有限维空间 $V\subset\mathrm{BV}([0,1])$ 包含常数函数 $1$，且到 $L^2[0,1]$ 的自然映射单射（即 $V$ 不含仅在零测集非零的函数），则对充分大 $p$，$\mathcal T_NV$ 上的真实 Weil 形式严格正。相对于物理 $L^2$ 范数，这个压缩的本征值为
\[
 \boxed{\lambda_1\longrightarrow L_{\theta,\varphi}>0,
 \qquad \lambda_j=L+O_{V,\theta,\varphi}(1)
 \quad(2\le j\le\dim V),}                              \tag{5}
\]
其中
\[
 L_{\theta,\varphi}
 =\log(1/\theta)+C_\varphi+\gamma-\log(2\pi)
  +\theta\kappa_\varphi^2
 \ge 46/25-\log(2\pi)>0,
\]
$\kappa_\varphi=\int\varphi$、
$C_\varphi=\int\log|\xi|\,|\widehat\varphi(\xi)|^2d\xi/(2\pi)$。
所以固定维的宏观对数槽系数变形不能构造负 Weil 方向；式 (3) 的首阶算子是 $I-P_{\mathbf1}$。

## 证明

**几何与两个对数测度。** 与 scratch 977 相同，所有槽相离并位于 $(-H,H)$，而 $N(e^\ell-1)<1$ 使全部素数幂平移边精确满足整数整除。以下只需两个一致有界的累计误差：
\[
 A(u):=\sum_{k\le e^u}\frac{\Lambda(k)}k=u+O(1),
 \qquad
 B(u):=\sum_{n\le e^u}\frac1n=u+O(1)
 \quad(u\ge0).                                             \tag{6}
\]
第一式是 note 854 使用的加权素数幂估计；第二式来自调和数公式。
若 $w$ 在区间 $[a,b]\subset[0,L]$ 上有界变差，由 Stieltjes 分部积分，(6) 蕴含
\[
 \left|\int_{[a,b]}w(u)\,dA(u)-\int_a^bw(u)\,du\right|
 \ll \|w\|_\infty+\operatorname{Var}_{[a,b]}w,          \tag{7}
\]
同式对 $B$ 成立；端点原子也被右端吸收。这个误差对区间位置和长度一致。

**算术部分的秩一极限。** 取 $x_n=\log n/L$。由 note 854 的矩阵条目，记
\[
 S_N(f,g)=\sum_{n\le N}\frac{\overline{f(x_n)}}n
 \sum_{k\le N/n}\frac{\Lambda(k)}k
       g\!\left(x_n+\frac{\log k}{L}\right).
\]
在内层对 (7) 取 $w(u)=g(x_n+u/L)$，其变差至多 $\operatorname{Var}g$，故对所有 $n$ 一致有
\[
 \sum_{k\le N/n}\frac{\Lambda(k)}k
       g\!\left(x_n+\frac{\log k}{L}\right)
 =L\int_{x_n}^1g(y)\,dy+O(\|g\|_{\mathrm{BV}}).    \tag{8}
\]
设 $G(x)=\overline{f(x)}\int_x^1g(y)dy$；它有界变差，且
$\|G\|_{\mathrm{BV}}\ll\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}$。
先将 (8) 代入，再在外层对 (7) 取 $w(u)=G(u/L)$，得到
\[
 S_N(f,g)=L^2\int_0^1\overline{f(x)}\int_x^1g(y)dy\,dx
 +O\!\left(L\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}\right). \tag{9}
\]
对称整除矩阵 $C_N$ 的另一半边是 $\overline{S_N(g,f)}$。由于两个三角域恰拼成 $[0,1]^2$（对角线零测度），
\[
 \langle\mathcal T_N f,C_N\mathcal T_N g\rangle
 =\frac{S_N(f,g)+\overline{S_N(g,f)}}{L_N}
 =L\,\overline{m_f}m_g
 +O\!\left(\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}\right). \tag{10}
\]
左端的记号指共同槽轮廓下的整数系数向量内积；$C_N$ 不作用于轮廓。算术 Weil 项是 (10) 的负值。
作为因子核对，取 $f=\mathbf1_{[0,\alpha)}$、$g=\mathbf1_{[\alpha,1]}$，式 (10) 给交叉算术项 $-\alpha(1-\alpha)L+O(1)$，恰与 scratch 977 的直接割边计数一致；取 $f=g=1$ 则给完整格的 $-L+O(1)$。

**范数与非算术项。** 对 $w(u)=\overline{f(u/L)}g(u/L)$ 应用 $B$ 版 (7)，得
\[
 \sum_{n\le N}\frac{\overline{f(x_n)}g(x_n)}n
 =L\langle f,g\rangle_0
 +O(\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}}).
\]
除以 $L_N=L+O(1)$ 即证 (2)。单槽 Fourier--gamma 项是
\[
 D_\ell\langle\mathcal T_N f,\mathcal T_N g\rangle,
 \quad D_\ell=\log(1/\ell)+C_\varphi-\log(2\pi)+O_\varphi(\ell)
 =L+O_{\theta,\varphi}(1),
\]
故由 (2) 等于 $L\langle f,g\rangle_0+O_{\theta,\varphi}(\|f\|_{\mathrm{BV}}\|g\|_{\mathrm{BV}})$。
普通跨槽核的绝对双和，对 $f=g=1$ 已由 note 857 的离散 Cauchy 核恒等式和固定 $\theta<1$ 的槽间距给出 $O_{\theta,\varphi}(1)$；乘上 $\|f\|_\infty\|g\|_\infty$ 即覆盖任意 $f,g$。两个 polar 矩分别受 $\|f\|_\infty$、$\|g\|_\infty$ 倍的自然权矩控制；其极化项同样为 $O_{\theta,\varphi}(\|f\|_\infty\|g\|_\infty)$。与算术负项 (10) 合并便得到 (3)，进而得到 (4)。若 $\|f_N\|_{\mathrm{BV}}=o(\sqrt L)$，(3) 的误差为 $o(L)$，给出所述序列结论。

**固定维压缩的低本征值。** 取 $V$ 的连续 $L^2[0,1]$ 正交分解
$V=\mathbb C\mathbf1\oplus V_0$，其中 $V_0=\{g\in V:\int g=0\}$。
固定维性与所假定的 $L^2$ 单射使 BV 范数在 $V$ 上受 $L^2$ 范数一致控制。式 (3) 因而给 $V_0$ 块
$L I+O_V(1)$、常数到 $V_0$ 的交叉 $O_V(1)$。对常数方向，note 857 的完整自然权计算（将中心常数 $4$ 改为 $2$，并令 $\ell N\to\theta$）给
\[
 Q_W^H[\mathcal T_N\mathbf1]
 \longrightarrow L_{\theta,\varphi}.
\]
note 858 的单位轮廓谱隙、$\kappa_\varphi^2\le1$ 与 $-\log\theta\ge1-\theta$ 给上面声明的严格正下界。对 $V_0$ 块配方，其给常数方向的 Schur 扣款为 $O_V(L^{-1})$；故真实压缩的最低本征值趋于 $L_{\theta,\varphi}$，其余为 $L+O_V(1)$。最后 (2) 表明 $\mathcal T_N$ 在 $V$ 上的物理 Gram 是 $I+O_V(L^{-1})$，所以换成物理 $L^2$ 归一化只使高本征值改变 $O_V(1)$，低本征值极限不变。这证明 (5)。$\square$

## 边界

式 (3) 是真实局部 Weil 形式上的宏观系数极限，而非 RH 的等价重述。它支付固定维、固定轮廓的宏观 $\log n/\log N$ 变形，并证明任何零均值负方向若仍在此整数格、共同轮廓族内，其 BV 范数至少须达到 $\sqrt{\log N}$ 量级。它不处理增长复杂度的系数空间、随槽改变的轮廓、格外补空间，也不支付 note 849 式 (15) 的真实 moving-$N$ Möbius signed covariance。
