# 同一素数分母的负补偿局部化到相对宽度趋零的邻近分子

日期：2026-10-02。依赖 [note 801](../notes/801-exact-poisson-kernel-pays-low-reduced-frequencies-to-full-cutoff.md) 的逐除数精确 Poisson 展开与 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的末带素数管主项。[scratch/938](938-same-prime-poisson-numerators-cancel-a-terminal-carrier.md) 已证明同分母全部谐波抵消；以下给出更强的分子局部化及完整解析证明。尚待异源复核，不估计完整 moving-$N$ 均方门。

## 命题

沿用 scratch/938 式 (1)–(2) 的 $Y,H,\mathcal A^\star,\mathcal P^\star,G^\star,\chi,\kappa_{\star,\chi}$。每个 $p\in\mathcal P^\star$ 恰落在一个 $I_a$，记该整数为 $a(p)$。对于任意整数 $W=W(Y)$ 满足
\[
2\le W\le H/4,\qquad W\longrightarrow\infty,\qquad W/H\longrightarrow0,
\tag{1}
\]
令 $F_{h,p}(N)$ 是 note 801 式 (5) 中原始除数 $d=p$ 的第 $h$ 个谐波，包含 $\mu(p)=-1$，并置
\[
B_{W,N}=\sum_{p\in\mathcal P^\star}
\sum_{\substack{h\ge1\\|h-a(p)|\le W}}F_{h,p}(N).
\tag{2}
\]
则所有这些 $h$ 都满足 $0<h<p$ 且 $(h,p)=1$，所以其既约分母仍为同一个素数 $p$。进一步有
\[
\boxed{\quad
\langle G^\star,B_W-G^\star\rangle_\chi
=-(\kappa_{\star,\chi}+o(1))
\frac{Y^3}{H^4(\log Y)^4}.
\quad}
\tag{3}
\]
量化地，记 $P^\star=\sum_{p\in\mathcal P^\star}\mu(p)\Phi(p/N)$ 为这些原始素数的全部谐波和，则
\[
\left|\langle G^\star,P^\star-B_W\rangle_\chi\right|
\ll_{\gamma,\chi}
\frac{Y^3}{H^4(\log Y)^4}
\left(W^{-2}+H^{-1}+\frac{H^2}{Y}\right).
\tag{4}
\]
更强地，对同样的 $W$，在整个物理区间 $3Y/2<N\le8Y/5$ 有逐点界
\[
\boxed{\quad
\sup_N|B_{W,N}|
\ll_\gamma\frac{Y}{H^2(\log Y)^2}
\left(\frac1W+\frac{W^2}{H}+\frac{W}{\log Y}\right).
\quad}
\tag{4a}
\]
例如 $W=\lfloor\log\log Y\rfloor$ 已足够；每个素数只保留 $O(\log\log Y)$ 个邻近分子，仍给出与 $G^\star$ 能量同阶的负补偿。这里的补偿仍是一个内积陈述，不能把它与 note 845 的素数—合数补偿相加成完整余项上界。

## 证明

note 845 式 (6)–(11) 限制到 $\mathcal A^\star$ 后给
\[
|\mathcal P^\star|\ll\frac{Y}{(\log Y)^2},\qquad
\sup_N|G_N^\star|\ll\frac{Y}{H^2(\log Y)^2},\qquad
\|G^\star\|_\chi^2
=(\kappa_{\star,\chi}+o(1))
\frac{Y^3}{H^4(\log Y)^4}.
\tag{5}
\]
这里主项逐 $N$ 为
$G_N^\star=Y[\pi H^2(\log Y)^2]^{-1}\mathcal L_\star(z)z^{-1}\cos(2\pi Hz)
+o(Y/[H^2(\log Y)^2])$，$z=N/Y$；奇偶系数的平均为 $1$，再用光滑权和余弦平方的几何和即得 (5) 的能量式。
对 $p\in I_a$，由 $t_a=aY/H+O(1)$、$B_a\ll Y/(H\log Y)$ 与 $a\asymp H$，
\[
\frac{Ya}{p}=H+O((\log Y)^{-1}+H^2/Y)
=H+O((\log Y)^{-1})
\tag{6}
\]
一致成立。同一式适用于 $q\in I_b$。全部 $p,q\in\mathcal P^\star$ 均有 $p,q\asymp Y$、$p,q<N$，并在 $N/Y\in\operatorname{supp}\chi$ 时满足 $1<N/q<3/2$。

先证明 (4)。由 note 801 式 (5)，对任意 $h\ge1$，有
\[
F_{h,q}(N)=h^{-2}C_{h,q}(N/Y)
\cos(2\pi hN/q),
\tag{7}
\]
其中 $C_{h,q}$ 及其任意固定阶导数在 $\operatorname{supp}\chi$ 上一致有界：$q/N\le 11/15+o(1)<3/4$，奇 $h$ 无第一分母，偶 $h\ge2$ 的两个分母均远离零。scratch/938 式 (9) 同时给
$F_{a,p}=a^{-2}A_{a,p}(N/Y)\cos(2\pi aN/p)$，$A_{a,p}$ 的固定阶导数亦一致有界。函数 $\chi A_{a,p}C_{h,q}$ 因而有统一的 $C_c^3$ 界。

对任意这样的 $g$ 和实数 $\vartheta$，三次离散分部求和给
\[
\left|\sum_{N\in\mathbb Z}g(N/Y)e(\vartheta N)\right|
\ll_\chi Y(1+Y\|\vartheta\|_{\mathbb R/\mathbb Z})^{-3}.
\tag{8}
\]
确实，平凡界为 $O(Y)$；三次差分的 $\ell^1$ 范数为 $O(Y^{-2})$，而 $|1-e(\vartheta)|\asymp\|\vartheta\|$，组合即得 (8)。

固定 $p\in I_a,q\in I_b$。先取 $h\le q/3$。由 (6)，当 $|h-b|>W\ge2$ 时
\[
Y\left|\frac ap-\frac hq\right|
\ge c|h-b|,
\qquad
Y\left\|\frac ap+\frac hq\right\|_{\mathbb R/\mathbb Z}
\ge c(H+h).
\tag{9}
\]
第一个常数可统一取正，因为 $Y/q$ 有固定正下界且 (6) 的误差为 $o(1)$。第二式中 $a/p+h/q<1/3+o(1)$，没有整数别名。将两个余弦相乘并用 (8)–(9)，得到
\[
\left|\sum_N\chi(N/Y)F_{a,p}(N)F_{h,q}(N)\right|
\ll\frac{Y}{H^2h^2}
\left[(1+|h-b|)^{-3}+(H+h)^{-3}\right].
\tag{10}
\]
在 $h\le H/2$ 上，式 (10) 对 $h$ 的和为 $O(YH^{-5})$；在 $H/2<h\le2H$ 且 $|h-b|>W$ 上为 $O(YH^{-4}W^{-2}+YH^{-6})$；在 $2H<h\le q/3$ 上为 $O(YH^{-6})$。因此对每个 $(p,q)$，该低谐波带外内积为
\[
\ll \frac{Y}{H^4}\left(W^{-2}+H^{-1}\right).
\tag{11}
\]

对 $h>q/3$ 不需要频率分析。式 (7) 与 $\sum_{h>q/3}h^{-2}\ll q^{-1}$ 给
\[
\sup_N\left|\sum_{q\in\mathcal P^\star}
\sum_{h>q/3}F_{h,q}(N)\right|
\ll\frac{|\mathcal P^\star|}{Y}
\ll(\log Y)^{-2}.
\tag{12}
\]
将 (11) 对 $p,q$ 求和，用 (5) 的素数数目，所得为
$\ll Y^3[H^4(\log Y)^4]^{-1}(W^{-2}+H^{-1})$。将 (12) 与 (5) 的 $\sup|G^\star|$ 相乘并对 $O(Y)$ 个 $N$ 求和，所得为
$\ll Y^2/[H^2(\log Y)^4]$。两者相加即得 (4)。

最后，因 $p\asymp Y$、$a(p)\asymp H\le Y^{1/4}$ 且 $W\le H/4$，式 (2) 的全部 $h$ 满足 $1\le h<p$，故没有 $p\mid h$ 的整数频率。在当前物理窗口，$1<N/q<3/2$，故 $\Phi(q/N)=\log(q/N)\sin(4\pi q/N)$；作为 $N/Y$ 的函数，它及任意固定阶导数对全部 $q\in\mathcal P^\star$ 一致有界。取 $g(z)=\chi(z)A_{a,p}(z)\Phi(q/(Yz))$，并在 (8) 中令 $\vartheta=a/p$；由 (6)，$Y\|a/p\|=H+o(1)$。逐对 $p,q$ 求和及 $a\asymp H$ 给
\[
|\langle G^\star,P^\star\rangle_\chi|
\ll\frac{Y^3}{H^5(\log Y)^4}
=o(\|G^\star\|_\chi^2).
\tag{13}
\]
由 (4) 和 (1)，$\langle G^\star,B_W\rangle_\chi=o(\|G^\star\|_\chi^2)$。展开
$\langle G^\star,B_W-G^\star\rangle_\chi$ 并用 (5)，即得 (3)。$\square$

## 邻近分子和的逐点界

证明 (4a) 需要一个带速率的短区间素数输入。[scratch/936](936-logarithmic-quarter-power-collar-for-the-two-endpoint-residual.md) 已核对 Matomäki--Shao--Tao--Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, arXiv:2204.03754v4, Theorem 3.1(i) 与式 (3.11)：在当前 $B_a=Y^{1-\gamma+o(1)}$ 的固定幂区间内，一致有
\[
\sum_{n\in I_a}\Lambda(n)
=B_a+O_A(B_a(\log Y)^{-A})
\quad(A>0\text{ 固定}).
\tag{14}
\]
由于 $p\asymp Y$ 且素数高次幂在 $I_a$ 内的总 $\Lambda$ 权至多 $O(Y^{1/2}\log Y)=o(B_a(\log Y)^{-A})$，取 $A=2$ 并将 $\log p=\log Y+O(1)$ 代入，得到
\[
\#(I_a\cap\mathbb P)
=\frac{B_a}{\log Y}\left(1+O((\log Y)^{-1})\right)
\tag{15}
\]
一致于 $a\in\mathcal A^\star$。

写 $z=N/Y$、$x_a=a/H$、$j=h-a$，并在 (7) 的精确系数中使用
$p=aY/H+O(Y/(H\log Y))$、$B_a=aY/(H^2\log Y)+O(1)$、$|j|\le W\le H/4$。因 $h\asymp H$，其括号为
$c_{a+j}+O(H^{-2})$，其中 $c_n=4\mathbf1_{2\mid n}-1=1+2(-1)^n$；同时
\[
\frac{hN}{p}=Hz+\frac{jz}{x_a}+O((\log Y)^{-1}+H^2/Y),
\quad
\log\frac Np=\log\frac z{x_a}+O((H\log Y)^{-1}+H/Y).
\tag{16}
\]
把 (15)–(16) 代入 (2)，对每个 $(a,j)$ 的误差先取绝对值，再对 $O(HW)$ 个 $(a,j)$ 求和，得到一致于所取 $N$ 的
\[
\begin{aligned}
B_{W,N}={}&
\frac{Y}{\pi H^3(\log Y)^2z}
\sum_{a\in\mathcal A^\star}\sum_{|j|\le W}
c_{a+j}\log\frac z{x_a}
\cos\left(2\pi Hz+\frac{2\pi jz}{x_a}\right)\\
&+O_\gamma\!\left(\frac{Y}{H^2(\log Y)^2}
\left[\frac{W^2}{H}+\frac{W}{\log Y}\right]\right).
\end{aligned}
\tag{17}
\]
式 (17) 的 $W^2/H$ 项支付 $h^{-2}$ 相对 $a^{-2}$ 的 $O(W/H)$ 偏差及离散 $a$ 求和；$W/\log Y$ 项支付短区间计数与相位替换。$H^2/Y=o((\log Y)^{-1})$ 已吸收。

固定 $j$，函数 $x\mapsto\log(z/x)e(jz/x)$ 在 $x\in[13/12,11/10]$ 的总变差为 $O(1+|j|)$，统一于 $z\in[3/2,8/5]$。Riemann 和及相邻奇偶配对因此给
\[
\frac1H\sum_{a\in\mathcal A^\star}c_{a+j}
\log\frac z{x_a}\,e(jz/x_a)
=\int_{13/12}^{11/10}\log\frac z x\,e(jz/x)\,dx
+O\!\left(\frac{1+|j|}{H}\right).
\tag{18}
\]
把 (18) 对 $|j|\le W$ 求和，再取实部，式 (17) 的主项变为
\[
\frac{Y\cos(2\pi Hz)}{\pi H^2(\log Y)^2z}
\int_{13/12}^{11/10}\log\frac z x\,
D_W(z/x)\,dx,
\qquad D_W(t)=\sum_{j=-W}^{W}e(jt)
=\frac{\sin((2W+1)\pi t)}{\sin(\pi t)}.
\tag{19}
\]
这里 $z/x\in[15/11,96/65]$, 与整数保持固定距离，$\sin(\pi z/x)$ 一致远离零。相位 $z/x$ 对 $x$ 的导数 $-z/x^2$ 也一致远离零；对 (19) 的积分做一次分部积分便得 $O(W^{-1})$，统一于 $z$。与 (17)–(18) 的误差合并，得到 (4a)。$\square$

## 决策边界

## 真实 Möbius 短管的四块符号关系

取 $W=\lfloor\log\log Y\rfloor$，并将 **全部原始除数** $q\in I_a$ 的相同分子窗写为
\[
C_{W,N}=\sum_{a\in\mathcal A^\star}
\sum_{q\in I_a}\sum_{|h-a|\le W}F_{h,q}(N),
\qquad C_{0,N}=\sum_{a\in\mathcal A^\star}\sum_{q\in I_a}F_{a,q}(N).
\tag{20}
\]
这里 $F_{h,q}$ 包含真实 $\mu(q)$；没有添加 $(h,q)=1$ 的条件，因而 (20) 按 **原始除数** 而非既约分母划分。记
\[
Q_Y=\|G^\star\|_\chi^2,
\quad E_{\rm pc}=C_0-G^\star,
\quad E_{\rm np}=B_W-G^\star,
\quad E_{\rm nc}=C_W-B_W-C_0+G^\star.
\tag{21}
\]
下标 pc、np、nc 分别表示非素数原始除数的中央分子、素数原始除数的邻近分子、非素数原始除数的邻近分子。四块是同一个双指标和的互不相交分割。除 (3) 外还有
\[
\boxed{\quad
\langle G^\star,E_{\rm pc}\rangle_\chi=-Q_Y+o(Q_Y),
\qquad
\langle G^\star,E_{\rm np}\rangle_\chi=-Q_Y+o(Q_Y),
\qquad
\langle G^\star,E_{\rm nc}\rangle_\chi=+Q_Y+o(Q_Y).
\quad}
\tag{22}
\]
因此中央素数 $G^\star$ 的正能量与三个其余块的协方差主项按 $+,-,-,+$ 排列；两种负补偿之间确有一块同阶正补偿，不能把两种负项直接相加。

证明只需给 (20) 的完整真实 Möbius 和一个点态界。取 $Q_0=\lfloor Y^{2/3}\rfloor$。[scratch/936](936-logarithmic-quarter-power-collar-for-the-two-endpoint-residual.md) 已核对的 Matomäki--Shao--Tao--Teräväinen 全区间定理对每个长度 $Q_0$ 的区间给 $\sum\mu(n)\ll_A Q_0(\log Y)^{-A}$。把 $I_a$ 的每个前缀分成长 $Q_0$ 的完整块和一个余块，后者用 $|\mu|\le1$，于是对每个固定 $A>0$，
\[
\max_{u\in I_a}\left|\sum_{\substack{q\in I_a\\q\le u}}\mu(q)\right|
\ll_A\frac{B_a}{(\log Y)^A}+Q_0
\ll_A\frac{B_a}{(\log Y)^A}.
\tag{23}
\]
最后一步利用 $B_a\asymp Y/(H\log Y)\gg Y^{3/4}/\log Y$，故 $Q_0/B_a$ 有固定幂节省。对固定 $a,h,N$，式 (7) 除 $\mu(q)$ 外的权在 $q\in I_a$ 上上确界为 $O(H^{-2})$；其相位 $hN/q$ 在此区间的变化为 $O(hB_a/Y)=O((\log Y)^{-1})$，其余因子也有 $O(H^{-2})$ 总变差。对 (23) 作 Abel 求和并对 $a,h$ 求和，得到
\[
\sup_N|C_{W,N}|
\ll_A \frac{2W+1}{(\log Y)^A}
\sum_{a\in\mathcal A^\star}\frac{B_a}{H^2}
\ll_A\frac{(W+1)Y}{H^2(\log Y)^{A+1}}.
\tag{24}
\]
取 $A>2$，$W=\lfloor\log\log Y\rfloor$ 时，式 (24) 对 $C_W,C_0$ 均为 $o(Y/[H^2\log^2Y])$；式 (4a) 对 $B_W$ 也给相同小量。由 (5) 的 $\sup|G^\star|$ 和观测整数 $N$ 有 $O(Y)$ 个，
\[
\langle G^\star,C_W\rangle_\chi,
\ \langle G^\star,C_0\rangle_\chi,
\ \langle G^\star,B_W\rangle_\chi=o(Q_Y).
\tag{25}
\]
将 (21) 代入 (25) 就得到 (22)。$\square$

## 决策边界

与 scratch/938 的全部谐波结论相比，式 (3) 将抵消限定在每个所选分子旁的 $o(H)$ 窗口内，且全部项仍在 $h\ll Y^{1/3}$ 的低分子扇区。式 (4a) 在 $W=\lfloor\log\log Y\rfloor$ 时给逐点的 $o(Y/[H^2\log^2Y])$，但此速率本身仍不足以支付 $Y^{2+\varepsilon}$ 均方目标。式 (22) 明确显示若分别观察素数—非素数与中央—邻近分子两种负协方差，必须同时保留第四块的正协方差；完整门仍须控制不同短管及全部分子、除数的联合平方范数。

[scratch/940](940-full-terminal-tube-has-a-four-corner-signed-covariance-cycle.md) 用逐点分子求和避开了本稿式 (8) 对 $\Phi$ 光滑性的要求，将四块符号关系扩展到 note 845 的整个末带。
