# 中距离局部四通道协方差的秩一主项与精确密度抵消（候选，待异源复核）

日期：2026-10-02。本文沿用 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(12) 的真实两端点系数、观察频率核与中距离环带。外部输入仍是 [note 835](../notes/835-all-fixed-power-farey-blocks-have-prime-composite-covariance.md) 已核对的 Heath--Brown 1982 全区间短区间素数定理和 Matomäki--Shao--Tao--Teräväinen 2023 Theorem 1.1(i) 的全前缀 Möbius 对数节省。下面只求出环带靠近对角的一段中各真实算术通道的**带符号常数**；不提供 note 849 式 (15) 所需的固定幂上界。

## 命题

固定实值非负、非零的 \(\psi\in C_c^3((1,2))\)，以及 note 849 的非负偶函数 \(\eta\in C_c^\infty(\mathbb R)\)：\(\operatorname{supp}\eta\subset\{1/2\le|t|\le4\}\)，且 \(\eta\ge1\) 于 \(1\le|t|\le2\)。令
\[
M=2Y,\quad Y^{1/5}\le H\le Y^{1/4},\quad
L=\frac{M}{32H},\quad
K_0=\frac{H^3}{\log^2(2Y)},\quad
K_H(k)=\sum_{h\in\mathbb Z}\eta(h/H)e(-hk/M),
\quad \varphi(u)=\frac{\psi(u)}u .
\tag{1}
\]
在 \(M<m<2M\) 上定义四个真实系数通道，区间外均为零：
\[
\begin{aligned}
a_m^-&=-\frac{4\log m}{m}\psi(m/M)\mathbf1_{\{m\ {\rm prime}\}},\\
a_m^+&=\frac{2\log(m/2)}m\psi(m/M)\mathbf1_{\{m=2p,\ p\ {\rm prime}\}},\\
a_m^0&=\frac{4-2\mathbf1_{2\mid m}}m\psi(m/M),\\
a_m^\mu&=-\frac{4\log2}{m}\psi(m/M)\mu(m).
\end{aligned}
\tag{2}
\]
这些正是 note 849 式 (29)、(31) 的两类素数、常数背景与 Möbius 项；完整式 (11) 还含高次素数幂。对 \(i,j\in\{-,+,0,\mu\}\) 置
\[
C_{ij}(Y,H)=
\sum_{\substack{m,n\in\mathbb Z\\K_0<|m-n|\le L}}
a_m^i a_n^j K_H(m-n),\qquad
J_{\psi,\eta}=
\left(\int_1^2\varphi(u)^2\,du\right)
\left(\int_{-1/32}^{1/32}\widehat\eta(v)\,dv\right)>0 .
\tag{3}
\]
则在整个所述 \(H\) 区间一致地
\[
\boxed{\quad C_{ij}(Y,H)=\kappa_i\kappa_jJ_{\psi,\eta}+o(1),
\qquad
(\kappa_-,\kappa_+,\kappa_0,\kappa_\mu)=(-4,1,3,0).\quad}
\tag{4}
\]
特别地，奇素数同号块为 \(16J_{\psi,\eta}+o(1)\)，两类素数的两个有序交叉块之和为 \(-8J_{\psi,\eta}+o(1)\)，而两类素数加常数背景的整个局部环带和为
\[
( -4+1+3)^2J_{\psi,\eta}+o(1)=o(1).
\tag{5}
\]
加入 Möbius 通道及真实高次素数幂后，note 849 的完整 \(a_m=c(m)\psi(m/M)/m\) 在同一**局部**环带上的带符号协方差仍为 \(o(1)\)。式 (5) 展示了实际系数的负交叉如何支付正的素数子块；其余中距离及目标固定幂节省仍未控制。

## 统一短块密度

对四个通道分别置 \(\kappa_i\) 如 (4)。取 \(B=\lfloor Y^{2/3}\rfloor\)。下述估计对 \(M<m<2M\) 中任意长度为 \(B\) 的整数块及其每个前缀一致：
\[
\sum_{m\in I}a_m^i
=\frac{\kappa_i}{M}\int_I\varphi(t/M)\,dt
+o(B/M),\qquad i\in\{-,+,0,\mu\}.
\tag{6}
\]
对 \(i=-\)，在 \(m\asymp Y\) 的区间用 Heath--Brown 定理；对 \(i=+\)，换元 \(m=2p\) 后在 \(p\asymp Y\) 使用同一定理。两者的素数幂误差至多 \(O(\sqrt Y\log^2Y)=o(B)\)。为使每个前缀也一致，先以长度约 \(Y^{13/20}\) 的完整小段应用定理，再用 \(O(Y^{13/20}\log Y)=o(B)\) 支付末段；\(13/20>7/12\)。分部求和处理 \(m^{-1}\psi(m/M)\) 的变化。双倍素数的 \(m\)-坐标密度为 \((2\log p)^{-1}\)，恰与 (2) 的 \(2\log p/m\) 配对，给 \(\kappa_+=1\)；高素数给 \(\kappa_-=-4\)。

对 \(i=0\)，偶数格的密度为 \(1/2\)，故 \(4-2\mathbf1_{2\mid m}\) 的平均为 \(3\)，误差由一次整数求积控制。对 \(i=\mu\)，上述 2023 定理取常数 nilsequence，直接给长度 \(B\) 窗口的所有前缀 \(\sum\mu=o(B)\)；分部求和后其密度为零。四种误差均对块位置一致，证明 (6)。

因 \(B\log Y=o(L)\)，将长度至多 \(2L\) 的任意整数区间分成完整 \(B\) 块和两个短端块，(6) 与平凡界 \(|a_m^i|\ll\log Y/M\) 给
\[
\sup_{\substack{I\subset(M,2M)\\|I|\le2L}}
\left|\sum_{m\in I}a_m^i-
\frac{\kappa_i}{M}\int_I\varphi(t/M)\,dt\right|
=o(L/M).
\tag{7}
\]
这里短端块总误差 \(O(B\log Y/M)=o(L/M)\)；即使 \(|I|\ll B\)，右侧仍以最大允许窗口 \(L\) 计，足以供下一步 Abel 求和。

## 核的局部化与秩一极限

把 \(K_H\) 的定义扩展到实数变量。直接逐项微分给
\[
\sup_{|t|\le L}|K_H(t)|\ll H,\qquad
\operatorname{Var}_{[-L,L]}K_H\ll H,
\tag{8}
\]
因为频率 \(|h|\le4H\)、项数 \(O(H)\)、且 \(L\asymp M/H\)。Poisson 求和另给
\[
K_H(t)=H\widehat\eta(Ht/M)+O_A(H^{1-A})
\quad(|t|\le L),
\qquad
\frac1M\int_{-L}^{L}K_H(t)\,dt
=\int_{-1/32}^{1/32}\widehat\eta(v)\,dv+o(1).
\tag{9}
\]
非零别名的任意阶衰减在这一窗口一致；这里不对 \(K_H\) 的远距离符号作任何假设。

固定 \(m\)。用 (7) 的前缀误差对 (8) 作 Abel 求和，并用
\(\varphi((m-t)/M)=\varphi(m/M)+O(L/M)\)，得到对每个 \(j\) 一致的局部卷积式
\[
\sum_{|m-n|\le L}a_n^jK_H(m-n)
=\kappa_j\varphi(m/M)
\int_{-1/32}^{1/32}\widehat\eta(v)\,dv+o(1).
\tag{10}
\]
普通素数定理、整数求积及上述 Möbius 短块估计再给
\[
\sum_m a_m^i\varphi(m/M)
=\kappa_i\int_1^2\varphi(u)^2\,du+o(1),
\qquad
\sum_m|a_m^i|\ll1.
\tag{11}
\]
把 (10) 乘以 \(a_m^i\) 求和，便得到包含 \(|m-n|\le L\) 的 (4)。

最后移去 \(|m-n|\le K_0\)。每个通道有
\(\sum_m|a_m^i|^2\ll\log(2Y)/Y\)。对每个差 \(k\) 用 Cauchy--Schwarz，结合 \(|K_H(k)|\ll H\)，得近差绝对量
\[
\ll H(K_0+1)\frac{\log(2Y)}Y
\ll\frac{H^4}{Y\log(2Y)}=o(1)
\quad(H\le Y^{1/4}).
\tag{12}
\]
故 (4) 在所述环带成立。\(\square\)

为证 (3) 的正性，\(\eta\ge0\)、\(|t|\le4\) 与 \(|v|\le1/32\) 使
\(\cos(2\pi vt)\ge\cos(\pi/4)>0\)，从而 \(\widehat\eta(v)>0\) 于该小区间；\(\varphi\not\equiv0\) 给另一正因子。完整高次素数幂的加权 \(\ell^1\) 质量由 note 849 式 (33) 为 \(O(Y^{-1/2}\log Y)\)；它与任一通道的局部核交叉绝对值至多 \(O(HY^{-1/2}\log Y)=o(1)\)，自身平方更小。因此 (5) 同样适用于完整 \(c(m)\)。

## 边界

局部协方差矩阵的极限是秩一矩阵 \(J_{\psi,\eta}\kappa\kappa^{\mathsf T}\)，而真实系数的四个密度常数恰好相加为零。这个结果仅消去中距离环带的 \(|m-n|\le Y/(16H)\) 部分的**常数量级主项**；note 849 式 (15) 要求的是 \(H^4Y^{-1+\varepsilon}\) 的固定幂量级，在 \(H<Y^{1/4}\) 时严格更强。它不能推出完整 moving-\(N\) 均方门或 RH。
