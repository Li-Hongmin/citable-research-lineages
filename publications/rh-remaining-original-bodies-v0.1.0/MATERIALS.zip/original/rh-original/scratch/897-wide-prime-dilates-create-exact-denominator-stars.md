# 宽素数带与有理锥之间的精确分母星图及线性交叉范数（候选，待异源复核）

日期：2026-10-01。沿用 [scratch/891](891-logarithmic-denominator-weight-pays-fixed-power-farey-cones.md) 的实尺度 \(X\)、\(H=\log X\)、宽 \(w=\frac12\log(1+X^{-2})\) 的全轮廓有理锥，以及 [scratch/892](892-upper-prime-dilates-leak-linearly-outside-every-polynomial-rational-cone.md) 的素数参数 \(z_p=p/y\)。本稿检验把素数带从 \(p\ge X^{5/4}\) 直接下探到 \(p\ge X\) 时，锥的非根槽是否仍与素数槽没有异臂算术边。结果是一个**精确存在的线性跨块**。它修正了已撤回的“宽带仍完全算术解耦”草稿；未经异源复核，不推断 Weil 算子负谱或 RH。

## 命题

令 \(y\in\mathcal G_X^\circ\subset(X/8,X/2)\)，整数 \(1\le B\le X^{1/5}\)，并考虑素数标签
\(\mathcal P_X^{\rm wide}=\{p\text{ prime}:X\le p\le X^{3/2}\}\)。在 \(p/y\) 槽与锥的非根既约标签 \(r=a/b\ge5\)、\(b\le B\)、\(r\le N_y=\lfloor y/2\rfloor\) 之间，全部异臂素数幂平移仅可能由
\[
\boxed{\quad a=p,\qquad s=b\text{ 为素数幂},\qquad r=p/b\quad}
\tag{1}
\]
产生；反过来，每个满足这些条件的 \((p,b)\) 都给一个**整槽精确反射边**，权为 \(+c_b=+\Lambda(b)/\sqrt b\)。根标签 \(r=1\) 另有 \(s=p\) 的主边，不包含在 (1) 中。

设 \(T_{y,B}^{\rm refl}\) 是这些边在标签直和的任意有限能量轮廓上给出的异臂算术双线性块，行标锥非根槽、列标宽带素数槽。置
\[
\mathcal B_{p,y,B}
=\{b\le B:\ b\text{ 为素数幂},\ 5\le p/b\le N_y\}.
\]
则在相应的正交**标签轮廓坐标**中精确有
\[
\boxed{\quad
(T_{y,B}^{\rm refl})^*T_{y,B}^{\rm refl}
=\bigoplus_{p\in\mathcal P_X^{\rm wide}}
\left(\sum_{b\in\mathcal B_{p,y,B}}\frac{\Lambda(b)^2}{b}\right)I_{L^2(0,w)},
\quad}
\tag{2}
\]
其中每条边的轮廓算子是同一个全反射 \(Jh(t)=h(w-t)\)。特别对固定 \(0<\alpha\le1/5\)、\(B=\lfloor X^\alpha\rfloor\)，所有 \(y\in\mathcal G_X^\circ\) 一致地
\[
\boxed{\quad
\|T_{y,B}^{\rm refl}\|
=\left(\frac{\alpha}{\sqrt2}+o(1)\right)H.
\quad}
\tag{3}
\]
式 (2)--(3) 只描述**算术异臂边矩阵**；若某个素数槽与锥物理重叠，二者的标签直和不等于旧 Hilbert 空间的正交直和。对任意删点族，只要它仍保留 \([X,(1+\varepsilon)X]\) 中 \(1-o(1)\) 的主素数平方质量（固定 \(\varepsilon>0\)），式 (3) 的下界仍成立。由此，单靠删除 \(o(H)\) 主平方质量的素数，不能使宽带与锥的异臂算术跨块变成 \(o(H)\)。

## 整数窗与全部边的分类

素数槽的上臂参数是 \(z_p=p/y\)，锥槽的是 \(x_r=y/r\)，故异臂平移 \(s\) 的反射中心必须满足
\[
\left|\log\frac{z_px_r}{s}\right|
=\left|\log\frac{pb}{sa}\right|<w.
\tag{4}
\]
因为 \(p\le X^{3/2}\)、\(b\le X^{1/5}\) 和 \(e^w-1\ll X^{-2}\)，式 (4) 强制
\[
|pb-sa|<pb(e^w-1)\ll X^{-3/10}<1.
\]
两边是整数，所以 \(sa=pb\)。由 \((a,b)=1\) 得 \(a\mid p\)；非根标签有 \(a>1\)，而 \(p\) 为素数，故 \(a=p\)，再由等式得 \(s=b\)。因为 \(s\) 必须是素数幂，必要条件正是 (1)。反向若 \(r=p/b\) 符合锥标签，\(b=s\) 为素数幂，则 \(z_px_r=(p/y)(yb/p)=b\) 精确成立；两个宽 \(w\) 槽的反射完整重合，奇臂的两次半权配对与旧算术负号相乘给 \(+c_bJ\)。这证明分类与符号。

## 星图正交性与尖锐范数

由于 \(b<p\) 且 \(p\) 为素数，\(p/b\) 已既约。若两个边的锥目标相同，即 \(p/b=p'/b'\)，既约分子强迫 \(p=p'\)，再强迫 \(b=b'\)。因此不同 \(p\) 的目标集合互不相交，同一 \(p\) 的不同 \(b\) 也在不同槽。每条边都是 \(+c_bJ\) 且 \(J^*J=I\)；逐列求 \(T^*T\) 即得 (2)。

素数定理和高次素数幂的绝对可和性给
\[
\sum_{\substack{b\le B\\b\text{ 素数幂}}}\frac{\Lambda(b)^2}{b}
=\left(\frac12+o(1)\right)(\log B)^2
\quad(B\to\infty).
\tag{5}
\]
式 (2) 与 (5) 给 (3) 上界。下界对每个 \(y\) 取一枚 \(p\in[X,(1+\varepsilon)X]\)，其存在性由素数定理保证。因 \(N_y\ge X/16-O(1)\)，所有 \(b\ge C_\varepsilon\) 的素数幂均满足 \(p/b\le N_y\)；又 \(B=o(X)\) 使 \(p/b\ge5\) 对 \(b\le B\) 成立。因此该列的平方范数为 (5) 减去有限个 \(b<C_\varepsilon\) 的有界平方质量，证明 (3) 的一致下界。

更一般地，若删去部分素数，而 \([X,(1+\varepsilon)X]\) 中未删素数的 \(\sum c_p^2\) 仍为原带的 \(1-o(1)\) 倍，则至少保留一枚该带素数，前段给出的列下界不变。事实上该短比例带的主平方质量由素数定理为 \(\asymp H\)，故删除 \(o(H)\) 平方质量无法消去全部星心。\(\square\)

## 边界与下一门

精确星图说明：把低端从 \(X^{5/4}\) 推到 \(X\) 时，scratch/893--895 的“非根算术跨块为零”接口失效，且失败量纲为 \(H\)。这些边本身未给 Weil 负方向：星心与孩子槽各有约 \(2H\) 的单槽能量，仍可能共同为正。要保留宽带，须把 (2) 的星图放进真实联合 Schur 预算；或者先截去约 \(p\lesssim XB\) 的低端，再用有理中心平均改善几何删除。两条路线都仍须处理完整旧空间的其余补块。
