# 二项式素数载波组合消去增长族的统一 Gram 谱隙（待异源复核）

日期：2026-10-01。依赖 [note 845](../notes/845-terminal-growing-numerator-farey-tube-negative-prime-composite-covariance.md) 的真实素数源定义及 [note 846](../notes/846-terminal-carrier-prime-source-signed-cross-gram.md) 式 (1)--(2) 的固定有限载波 Gram 极限。本结论只判定该局部观察窗上的 frame 路线，不估计完整 residual 的均方。

## 命题

固定 $0<\gamma<1/4$，$H=\lfloor Y^\gamma\rfloor$。令 $G_r^{(Y)}$ 为 note 846 在 $3Y/2<N\le8Y/5$ 定义的真实素数源，$r=0,1,\ldots$ 固定。对整数 $R\ge1$ 令
\[
 \Gamma_R(Y)=\frac{H^4(\log Y)^4}{Y^3}
 \left(\sum_{3Y/2<N\le8Y/5}G_r^{(Y)}(N)G_s^{(Y)}(N)\right)_{0\le r,s\le R}.
\]
记 $\kappa_0=(2\pi^2)^{-1}\int_{3/2}^{8/5}w(z)\,dz>0$，其中 $w(z)=\mathcal L(z)^2/z^2$ 如 note 846。则对每个固定 $R$，
\[
 \boxed{\quad
 \limsup_{Y\to\infty}\lambda_{\min}(\Gamma_R(Y))
 \le \kappa_0(R+1)\sin^{2R}(\pi/10).
 \quad} \tag{1}
\]
特别地，若 $J(Y)\to\infty$ 且 $J(Y)=o(H)$，并按 note 846 的参数定义真实载波 $G_0^{(Y)},\ldots,G_{J(Y)}^{(Y)}$，则这些归一化 Gram 矩阵不存在与 $Y,J(Y)$ 无关的正 **Gram/Riesz 下界**，哪怕每个固定 $r$ 的对角能量都趋于 $\kappa_0>0$。这不单独否定过完备载波族在另一个信号空间上的分析 frame 下界。

将每条载波乘以 $H^2(\log Y)^2/Y^{3/2}$ 后，对每个固定 $R$ 且足够大的 $Y$，前 $R+1$ 条载波线性独立；其张成空间上的分析 frame 算子与 $\Gamma_R(Y)$ 有相同的非零特征值。因此这些**固定前缀截断族**没有对所有 $R,Y$ 统一的分析 frame 下界；添加额外载波后可能改变该下界。

## 证明

取实系数向量 $x_r=\binom Rr$，$0\le r\le R$。由 note 846 式 (2)，对固定 $R$ 有逐矩阵收敛 $\Gamma_R(Y)\to K_R=(\kappa_{r-s})_{0\le r,s\le R}$。其二次型由 note 846 式 (4a) 直接写成
\[
 x^{\mathsf T}K_Rx
 =\frac1{2\pi^2}\int_{3/2}^{8/5}
 w(z)\left|\sum_{r=0}^R\binom Rr e^{2\pi irz}\right|^2dz
 =\frac1{2\pi^2}\int_{3/2}^{8/5}w(z)|1+e^{2\pi iz}|^{2R}dz. \tag{2}
\]
在 $3/2\le z\le8/5$ 上，$|1+e^{2\pi iz}|=2|\cos(\pi z)|\le2\sin(\pi/10)$。另一方面，Vandermonde 恒等式给
\[
 \|x\|_2^2=\sum_{r=0}^R\binom Rr^2=\binom{2R}R
 \ge\frac{4^R}{R+1}, \tag{3}
\]
最后一个不等式由 Cauchy--Schwarz 直接得到：
$4^R=(\sum_{r=0}^R\binom Rr)^2\le(R+1)\sum_{r=0}^R\binom Rr^2$。Rayleigh 原理将 (2)--(3) 合并，得到
\[
 \lambda_{\min}(K_R)
 \le \frac{x^{\mathsf T}K_Rx}{\|x\|_2^2}
 \le \kappa_0(R+1)\sin^{2R}(\pi/10).
\]
固定维数下特征值随矩阵元素连续，遂得 (1)。

若某增长族有统一下界 $c>0$，则对每个固定 $R$，足够大的 $Y$ 中其前 $R+1$ 条载波的 Gram 也须满足 $\Gamma_R(Y)\succeq cI$。先令 $Y\to\infty$，再令 $R\to\infty$，与 (1) 矛盾。这里没有把固定 $R$ 的渐近误差冒充对增长 $R$ 的一致误差。$\square$

## 直接点态核对与边界

note 845--846 的逐 $N$ 主项对每个固定 $R$ 一致，因此同一向量的素数源组合主项正比于
\[
 \Re\left[e^{2\pi iHN/Y}(1+e^{2\pi iN/Y})^R\right].
\]
它在整个观察窗上的振幅至多为 $(2\sin(\pi/10))^R$，与 Gram 证明的指数衰减相符。这一核对只调用逐点素数源渐近式，独立于矩阵特征值计算。

式 (1) 关闭的是把 note 846 的**固定有限正定性**直接提升为该短观察窗上**任意增长载波族的统一 Gram 谱隙**。它不排除过完备 frame、改变观察窗、载波构造或直接取得真实 $\mu(d)\mu(e)$ 频率平均节省。即使另有统一分析 frame，下界也无法自动补足 note 848 式 (21) 从 $Y^3/H^3$ 到目标 $Y^2$ 的固定幂缺口。

若把 frame 理解为对**整个周期上的低频空间**取分析内积，也有一个单独的定量边界。设 $V_R=\operatorname{span}\{e^{2\pi i(H+r)z}:0\le r\le R\}\subset L^2([1,2])$，取
\[
 f_R(z)=\frac{e^{2\pi iHz}(1+e^{2\pi iz})^R}{\sqrt{\binom{2R}R}}.
\]
正交性给 $\|f_R\|_{L^2([1,2])}=1$，而在 $I=[3/2,8/5]$ 上有
$\|f_R\|_{L^2(I)}^2\le |I|(R+1)\sin^{2R}(\pi/10)$。
因此任意支撑在 $I$ 的分析向量族 $(g_j)$ 满足
\[
 \sum_j|\langle f_R,g_j\rangle|^2
 \le \left(\sum_j\|g_j\|_2^2\right)
 |I|(R+1)\sin^{2R}(\pi/10). \tag{4}
\]
只要总分析向量能量增长慢于 $\sin^{-2R}(\pi/10)/(R+1)$，这个短窗测量对整个 $V_R$ 也没有统一分析 frame 下界。式 (4) 不涉及 $V_R$ 在短窗上的相对范数；若把信号范数也限于 $I$，应使用前面的 Gram/Riesz 结论，不能把两个 frame 命题混同。
