# 真实高除数观察门内仍有正的素数—素数中距离块

日期：2026-10-01。依赖 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的 $b_d,\mathcal K_h,J_H,D,R,K_0$，以及 [scratch/860](860-gevrey-bandpass-restricts-moving-covariance-to-polylogarithmic-distance.md) 的带通权与远差截止。本稿给出已截断的**真实** $\mu(d)\mu(e)$ 协方差中的正子块及目标成立时的必要负补偿；[scratch/862](862-unconditional-negative-compensation-inside-the-high-divisor-observation-gate.md) 随后用 2023 年全区间短和定理在次四分之一次幂带证明了无条件负补偿，仍未证明固定幂目标上界。

## 命题

设 $M=2Y$，$Y^{1/5}\le H\le Y^{1/4}$，$\psi\in C_c^3((1,2))$ 为非负且非零的实函数，$\phi(u)=\psi(u)/u$。取 scratch/860 的 $w_H(h)=\chi_s(h/H)^2$，其中 $s>1$ 固定，$J_H(r)=\sum_hw_H(h)e(-hr/M)$。选闭区间 $J\subset(1,2)$，使 $\phi\ge c_\psi>0$ 于 $J$，并令
\[
 \mathcal P_M=\{p\text{ 为素数}:p/M\in J\},\qquad
 L=\frac{M}{32H}.
\]
定义剩余门中的有序素数子块
\[
 \mathfrak P_{M,H}=
 \sum_{\substack{p,q\in\mathcal P_M,\ p\ne q\\
 K_0<|p-q|\le L}}
 \mu(p)\mu(q)
 \sum_{M<m,n<2M}b_p(m)\overline{b_q(n)}J_H(m-n).
 \tag{1}
\]
则一致于上述 $H$，
\[
 \boxed{\quad \mathfrak P_{M,H}\gg_{s,\psi}(\log M)^{-2}.\quad}
 \tag{2}
\]
式 (1) 的每对 $p,q$ 都满足 scratch/859 式 (12) 的高除数、互不整除、大约化比例条件，且落在 scratch/860 式 (4) 的中距离范围。特别地，对任意固定 $\epsilon>0$，若该剩余门在 $H\le Y^{1/4-\epsilon}$ 满足目标上界 $O_\epsilon(H^4M^{-1+\epsilon'})$ 且取 $\epsilon'<4\epsilon$，那么式 (1) 以外的**同一真实剩余门**必须贡献至多 $-c_{s,\psi}/\log^2M+o(\log^{-2}M)$。

## 证明

若 $p\in\mathcal P_M$，则 $p>M$ 且 $p$ 为充分大的奇素数。scratch/859 式 (2) 中，$m$ 必须是 $p$ 的倍数并位于 $(M,2M)$；唯一可能是 $m=p$。第一项需要 $2p\mid m$，故为零；第二项在 $m=p$ 的对数是 $\log1=0$。于是
\[
 b_p(m)=-\frac{4\log2}{M}\phi(p/M)\mathbf1_{m=p},
 \qquad
 \mu(p)\mathcal K_h(p)=
 \frac{4\log2}{M}\phi(p/M)e(-hp/M).
 \tag{3}
\]
因此 (1) 恰为
\[
 \mathfrak P_{M,H}
 =\frac{16\log^22}{M^2}
 \sum_{\substack{p,q\in\mathcal P_M,\p\ne q\\K_0<|p-q|\le L}}
 \phi(p/M)\phi(q/M)J_H(p-q).
 \tag{4}
\]

$w_H$ 是偶、非负的，而且在 $H\le|h|\le2H$ 等于 $1$，故 $\sum_hw_H(h)\gg H$。若 $|r|\le L$，其支撑上
$|2\pi hr/M|\le2\pi(4H)L/M=\pi/4$；正负 $h$ 成对后得
\[
 J_H(r)=\sum_hw_H(h)\cos(2\pi hr/M)
 \ge2^{-1/2}\sum_hw_H(h)\gg H.
 \tag{5}
\]

素数定理在固定比例区间给 $P:=|\mathcal P_M|\asymp_\psi M/\log M$。把 $MJ$ 分成 $T=O_\psi(H)$ 个长度不超过 $L$ 的连续格，令第 $j$ 格含 $P_j$ 个素数。Cauchy--Schwarz 给同格有序异素数对至少
\[
 \sum_{j=1}^TP_j(P_j-1)
 \ge\frac{P^2}{T}-P
 \gg_\psi\frac{M^2}{H\log^2M}.
 \tag{6}
\]
其中最后一步用 $M/(H\log M)\to\infty$。差距 $|p-q|\le K_0$ 的有序对至多 $P(2K_0+1)$，相对于 (6) 的比例为
\[
 O_\psi\!\left(\frac{HK_0\log M}{M}+\frac{H\log M}{M}\right)
 =O_\psi\!\left(\frac{H^4}{M\log^6M}+\frac{H\log M}{M}\right)=o(1),
 \tag{7}
\]
因为 $K_0=H^3/\log^7(2M)$ 且 $H^4\ll M$。所以 (4)--(7) 与 $\phi\ge c_\psi$ 证明 (2)。

最后，$p,q>M>D$，两不同素数互不整除，$(p,q)=1$，故约化比例的最大分子、分母是 $\max(p,q)>M>R$。又 $K_{s,2}=C_{s,2}(M/H)(\log M)^s>L$ 对充分大 $M$，所以式 (1) 确在缩窄后的剩余门内。若 $H\le Y^{1/4-\epsilon}$，则 $H^4/M\ll M^{-4\epsilon}$，目标上界 $H^4M^{-1+\epsilon'}=o(\log^{-2}M)$ 当 $\epsilon'<4\epsilon$。把门写成 $\mathfrak P_{M,H}$ 加其余项，(2) 迫使所述负补偿。$\square$

## 算术解释与边界

低除数剔除后，大素数处的原始 $-4\log p$ 振幅变成式 (3) 的常数 $4\log2$；即使如此，剩余门中仍有 (2) 的正块。这比 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的未截断素数块更直接地落在当前真实高除数、大约化比例、中距离条件内。式 (2) 只排除对此门逐项取绝对值的证明；负补偿可能来自 $J_H$ 的符号，也可能来自 $\mu(d)\mu(e)$ 的符号，本文未区分。全尺度局部 Weil 正性和 RH 仍开放。
