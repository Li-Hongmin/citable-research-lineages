# 多项式外 Farey 槽压缩的唯一未控块是异臂有符号近共振（候选）

日期：2026-09-29。承接 [scratch 817](817-polynomial-denominator-exterior-slots-have-logarithmic-farey-leakage-candidate.md) 的外槽族与完整旧奇交叉块。依赖 [note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的真实算术平移、相离 Archimedean 核和 polar 界。此处是外槽**主压缩的精确结构分解**；它不估计有符号近共振的谱范数，也不推出 Schur 补的符号。尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)、\(\Delta=\frac12\log(1+p^{-2})\)，并固定 \(0<\beta<1/2\)。取 \(B=\lfloor p^\beta\rfloor\) 与
\[
\mathcal Y_{p,B}
=\left\{\frac mb:2\le b\le B,\ p\le m<bp,\ (m,b)=1\right\},
\quad
Z_{p,B}=\operatorname{span}\{w_y:y\in\mathcal Y_{p,B}\}.
\tag{1}
\]
这些 \(w_y\) 是真实旧奇空间中的正交单位族。令
\[
d_p=2H+1-\gamma_E-\log\pi+\log2,
\qquad
c_r=
\begin{cases}
\Lambda(r)/\sqrt r,&r\text{ 为整数素数幂},\\
0,&\text{其余 }r>0,
\end{cases}
\tag{2}
\]
并定义有限矩阵
\[
C^{\rm same}_{p,B}(y,y')=c_{y/y'}+c_{y'/y},
\tag{3}
\]
\[
N^{\rm opp}_{p,B}(y,y')
=\sum_{\substack{n\ {\rm prime\ power}\\
|\log(n/(yy'))|<2\Delta}}
\frac{\Lambda(n)}{\sqrt n}\,
R_\Delta\!\left(\left|\log\frac{n}{yy'}\right|\right),
\tag{4}
\]
其中
\[
R_\Delta(s)=
\begin{cases}
1-\frac{3s}{2\Delta},&0\le s\le\Delta,\\
\frac{s}{2\Delta}-1,&\Delta\le s\le2\Delta,\\
0,&s\ge2\Delta.
\end{cases}
\tag{5}
\]
则 \(C^{\rm same}_{p,B}\) 是逐项非负对称矩阵，\(N^{\rm opp}_{p,B}\) 是含可变号重叠核的实对称近共振矩阵，而真实旧奇形式在 \(Z_{p,B}\) 上的压缩满足
\[
\boxed{
P_{Z_{p,B}}A_{p^2,-}P_{Z_{p,B}}\big|_{Z_{p,B}}
=d_p I-C^{\rm same}_{p,B}-N^{\rm opp}_{p,B}+E_{p,B},
\qquad \|E_{p,B}\|_{\rm op}=o(1).
}
\tag{6}
\]
式 (6) 的误差只来自 Archimedean 非对角、单槽正则 gamma、自反射臂和 polar 项。不能将 \(N^{\rm opp}\) 删去或按逐项非负处理。

## 精确平移与有符号重叠

两个目标 \(y=m/b,\ y'=m'/b'\) 的同臂中心比为 \(y/y'=m b'/(m'b)\)。若一个素数幂平移使同臂槽相交，则
\[
|\log(n m'b/(m b'))|<2\Delta
\quad\Longrightarrow\quad
|n m'b-m b'|<\frac{m b'}{p^2}
\le \frac{B^2}{p}<1
\tag{7}
\]
对充分大 \(p\) 成立。反向配对相同。因此同臂只保留 \(y/y'\) 或 \(y'/y\) 恰为整数素数幂的完整重合边；两臂各给半权，得到 (3)。

异臂中心比为 \(yy'=mm'/(bb')\)。不要求精确重合；相交的整数条件为
\[
\left|\log\frac{n}{yy'}\right|<2\Delta
\quad\Longrightarrow\quad
|n bb'-mm'|<\frac{mm'}{p^2}<bb'\le B^2.
\tag{8}
\]
将两个归一化的左正右负阶跃槽平移相隔 \(s\) 后，直接按四个半槽的重叠长度相加，得到 (5)。两个反射臂对 (4) 各给半权，合计系数一。故旧算术压缩**精确**为 \(-C^{\rm same}-N^{\rm opp}\)，包括目标自环。因 \(R_\Delta(\Delta)=-1/2\)，核本身变号；式 (8) 并不足以判定 \(N^{\rm opp}\) 的符号或范数。

## Archimedean 与 polar 误差

不同目标的既约分数间距至少 \(1/B^2\)。因所有 \(y<p\)，不同物理中心的对数距至少
\[
\delta_{p,B}\gg\frac1{pB^2}\gg\Delta.
\tag{9}
\]
将物理中心排序后，任一中心的第 \(j\) 个左右邻距至少 \(j\delta_{p,B}\)。两个偶极各零均值；note 791 的 \(|K''(d)|\ll d^{-3}\) 给跨中心块
\(O(\Delta^3/d^3)\)。因此全部非对角 Archimedean 块的绝对行和为
\[
O\!\left(\sum_{j\ge1}\frac{\Delta^3}{(j\delta_{p,B})^3}\right)
=O\!\left(\frac{B^6}{p^3}\right)=o(1).
\tag{10}
\]
每个目标自己的两个反射臂相距 \(2\log y\gg H\)，交叉为 \(o(1)\)；单物理偶极的精确接触能量为 \(d_p+O(p^{-2})\)，见 scratch 798 式 (6)。故整个 Archimedean 压缩为 \(d_p I+o_{\rm op}(1)\)。

每个目标偶极对 \(s_{p^2}\) 的投影是 \(O(p^{-5/2})\)，而目标总数 \(O(pB^2)\)，所以
\[
\|P_{Z_{p,B}}s_{p^2}\|=O(Bp^{-2}),\qquad
\big\|2P_{Z_{p,B}}|s_{p^2}\rangle\langle s_{p^2}|P_{Z_{p,B}}\big\|
=O(B^2p^{-4})=o(1).
\tag{11}
\]
将精确算术部分与 (10)--(11) 合并，即得 (6)。\(\square\)

## 下一道算术门

对 scratch 817 的 forcing 系数向量 \(t=-P_{Z_{p,B}}\mathcal R_{p^2}v_{p,\alpha}\ge0\)，\(C^{\rm same}\) 的二次型非负，因而在 \(A[t]\) 的**上界**中可直接丢弃。能否将已证 \(\|t\|^2\gg H^4\) 转为主阶 Schur 成本，取决于
\[
\boxed{\ \langle t,N^{\rm opp}_{p,B}t\rangle\ \text{的有符号下界。}\ }
\]
\(R_\Delta\) 的零平均不能单独给该下界：素数幂近共振的分布须在实际 \(m,m',b,b'\) 权下控制。此门不同于、也不能代替真实 moving-\(N\) Möbius signed covariance 的 \(Y^{2+\varepsilon}\) 门；两者均未解决。

最简单的整数算术单元是置 \(\delta=n b b'-m m'\)。式 (8) 给 \(|\delta|<B^2\)，而相移精确为
\[
\left|\log\frac{n}{yy'}\right|
=\left|\log\left(1+\frac{\delta}{mm'}\right)\right|.
\]
固定 \(n,b,b',\delta\) 后，目标配对须满足 \(mm'=n b b'-\delta\)。因此所需的有符号估计是素数幂附近、短移位 \(|\delta|<B^2\) 的**加权因子配对**，而非仅仅对 \(n\) 单变量应用素数定理。
