# 观察频带的直接 Möbius 通道不是必要的独立幂门

日期：2026-10-01。接 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 式 (10)--(11) 与 [scratch/859](859-observation-band-localizes-both-prime-channels-to-short-mobius-cofactors.md) 的高除数式。本文给出真实系数的精确 $2$-adic 双臂分解，以及一个保留平方自由支撑、$f(2u)=-f(u)$ 和 $\Lambda_f=f*\log$ 的有界模型。模型只否定“由这些代数关系和联合频带界即可推出直接 $f$ 通道幂界”的推理；它不是对真实 $\mu$ 或 RH 的反例。

## 1. 真实联合系数的奇数双臂

对 $m>2$ 记
\[
 c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
 -4\{\Lambda(m)-1+(\log2)\mu(m)\}.
\]
由于奇数 $u>1$ 满足 $\Lambda(2u)=0$、$\mu(2u)=-\mu(u)$，而 $4\mid m$ 时 $\mu(m)=0$，逐类计算得到**精确**恒等式
\[
 \boxed{\begin{aligned}
 c(m)={}&4-2\mathbf1_{2\mid m}
 -4\mathbf1_{2\nmid m}\,[\Lambda(m)+(\log2)\mu(m)]\\
 &+2\mathbf1_{v_2(m)=1}\,[\Lambda(m/2)+2(\log2)\mu(m/2)]
 -2(\log2)\mathbf1_{m=2^k,\ k\ge2}.
 \end{aligned}}\tag{1}
\]
证明只需四类：奇数 $m$ 给第二项；$m=2u$ 且 $u>1$ 奇数给第三项；$4\mid m$ 且不是 $2$ 的幂时 $c(m)=2$；$m=2^k$、$k\ge2$ 时 $c(m)=2-2\log2$。

因此 note 849 的观察系数在 $M=2Y$、$\phi=\psi/u$ 下，除平滑背景及至多一个落在 $(M,2M)$ 的 $2$ 的幂外，只剩同一奇数 $u$ 的两臂：
\[
 \begin{aligned}
 \mathcal A_h={}&-\frac4M
 \sum_{\substack{M<u<2M\\u\text{ odd}}}
 [\Lambda(u)+(\log2)\mu(u)]\phi(u/M)e(-hu/M)\\
 &+\frac2M
 \sum_{\substack{M/2<u<M\\u\text{ odd}}}
 [\Lambda(u)+2(\log2)\mu(u)]\phi(2u/M)e(-2hu/M)
 +E_h,
 \end{aligned}\tag{2}
\]
其中 $|E_h|\ll_\psi |h|^{-3}+M^{-1}$ 对 $1\le|h|\le M/8$ 成立。前项由 $C_c^3$ 权的 Poisson 衰减支付背景 $4-2\mathbf1_{2\mid m}$；限制 $|h|\le M/8$ 避开偶格在 $M/2$ 的别名。后项来自唯一可能的 $2$ 的幂。因此在 $Y^{1/5}\le H\le Y^{1/4}$，$\sum_{|h|\asymp H}|E_h|^2=o(H^4/M)$。

同一抵消在 scratch/859 的高除数坐标更直接。若 $u$ 为奇数且 $M/2<u<M$，则 $d=u$ 在 $m=2u$ 的 $\Lambda(m)$ cofactor $2$ 项为 $-4\mu(u)\log2$；$d=2u$ 的直接 Möbius 项为 $-4(\log2)\mu(2u)=+4\mu(u)\log2$。两项逐点相消。故单独估计 $d>M$ 的直接 Möbius 臂会删除真实联合式已经拥有的抵消。

## 2. 满足平方自由支撑与奇偶关系的反模型

更一般地，任取奇数 $u\in(2M/3,M)$ 上的系数 $a_u$，置 $f(u)=a_u$、$f(2u)=-a_u$，其余为零，并定义 $\Lambda_f=f*\log$。由于 $3u>2M$，下文 (4)--(5) 的同一计算表明 $2\mathbf1_{2\mid m}\Lambda_f(m/2)-4[\Lambda_f(m)+(\log2)f(m)]=0$ 对**每个** $M<m<2M$ 成立。因此这个有限窗算术映射具有至少 $\asymp M$ 维的精确核；直接臂在核内仍可任意变化。以下选择其中一个保留平方自由支撑的频率见证。

取固定 $0\le\varphi\in C_c^\infty((3/4,7/8))$ 非零，并取固定 $0\le\psi\in C_c^\infty((1,2))$，使 $\phi(t)=\psi(t)/t$ 在 $2\operatorname{supp}\varphi$ 上严格为正。令 $M$ 沿偶整数趋于无穷，$H=\lfloor M^{1/5}\rfloor$，取整数 $h_0\in[H,2H]$。定义实系数 $f_M(n)$：对奇数 $u$，
\[
 f_M(u)=\mu(u)^2\varphi(u/M)
 \cos(4\pi h_0u/M),
 \qquad f_M(2u)=-f_M(u),
 \tag{3}
\]
其余 $n$ 上为零。于是 $|f_M|\le1$，只在平方自由数上非零，并精确保留奇数位的 $2$-adic 符号关系。定义形式卷积 $\Lambda_M=f_M*\log$，再把 (1) 前的 $c$ 定义中 $\mu,\Lambda$ 分别换成 $f_M,\Lambda_M$，记为 $c_M$。

对任意 $M<m<2M$，只有 $u\in(3M/4,7M/8)$ 的倍数 $2u$ 可能落在此区间；$3u>2M$。卷积中 $d=2u$ 的 cofactor 为 $1$，其 $\log1=0$。所以
\[
 \Lambda_M(m)=\begin{cases}(\log2)f_M(u),&m=2u,\\0,&\text{其余},\end{cases}
 \qquad
 \Lambda_M(m/2)=0\quad(2\mid m,\ M<m<2M).
 \tag{4}
\]
对 $m=2u$，$f_M(m)=-f_M(u)$，式 (4) 给 $\Lambda_M(m)+(\log2)f_M(m)=0$；其余 $m$ 这两项也为零。因此
\[
 \boxed{\quad c_M(m)=4-2\mathbf1_{2\mid m}
 \qquad(M<m<2M).\quad}\tag{5}
\]
若 $\mathcal A_h^{(M)}=M^{-1}\sum_{M<m<2M}c_M(m)\phi(m/M)e(-hm/M)$，则 (5) 与 $\phi\in C_c^\infty$ 的 Poisson 求和给 $|\mathcal A_h^{(M)}|\ll_A H^{-A}$，一致于 $H\le|h|\le2H$、任意固定 $A>0$。特别地，联合频带能量为 $o(H^4/M)$。

另一方面，定义直接通道
\[
 D_h^{(M)}=\frac1M\sum_{M<m<2M}
 f_M(m)\phi(m/M)e(-hm/M).
 \tag{6}
\]
在 $h=h_0$，置 $F(x)=\varphi(x)\phi(2x)$，由 (3) 的余弦展开有
\[
 D_{h_0}^{(M)}=-\frac1{2M}
 \sum_{\substack{u\text{ odd}\\3M/4<u<7M/8}}
 \mu(u)^2F(u/M)\{1+e(-4h_0u/M)\}.
 \tag{7}
\]
初等平方自由展开 $\mu(u)^2=\sum_{a^2\mid u}\mu(a)$ 给，对每个固定光滑 $F$，
\[
 \frac1M\sum_{u\text{ odd}}\mu(u)^2F(u/M)
 \longrightarrow\frac4{\pi^2}\int F(x)\,dx,
 \qquad
 \frac1M\sum_{u\text{ odd}}\mu(u)^2F(u/M)e(-4h_0u/M)=o(1).
 \tag{8}
\]
为核准第二式而不借用任何 Möbius 符号抵消，把平方除数 $a\le M^{1/3}$ 与其尾部分开。前者令 $u=a^2v$；因 $u,a,v$ 均为奇数，奇格 Poisson 求和在 $X=M/a^2\ge M^{1/3}$、$4h_0\asymp M^{1/5}$ 下给 $O_A((M/a^2)h_0^{-A})$，在 $a$ 上求和为 $O_A(Mh_0^{-A})$。尾部平凡界为 $O(M^{2/3})$。第一式同法取零频；其主密度是 $(1/2)\sum_{a\text{ odd}}\mu(a)/a^2=4/\pi^2$，余项 $O(M^{-1/3})$。由 (7)--(8)，
\[
 D_{h_0}^{(M)}\longrightarrow
 -\frac2{\pi^2}\int F(x)\,dx\ne0.
 \tag{9}
\]
因此任何在 $h_0$ 取权 $1$ 的带通能量均满足 $\sum_hw_H(h)|D_h^{(M)}|^2\ge c_{\varphi,\psi}>0$，而 $H^4/M\asymp M^{-1/5}\to0$。联合通道在同一模型上远小于目标，直接通道却超过目标固定幂。

### 加入真实 Möbius 初始段

上述反例还能保留随 $M$ 增长的真实初始段。令 $D_0=\lfloor M/(128H)\rfloor$，把 (3) 的 $f_M$ 换成 $g_M$：对每个奇数 $u\le D_0$ 置 $g_M(u)=\mu(u)$、$g_M(2u)=-\mu(u)$；在 (3) 的高层保留原 $f_M(u),f_M(2u)$；其余处置零。两段支撑不交。于是 $g_M(n)=\mu(n)$ 对全部 $n\le D_0$ 成立，$g_M(1)=1$，并且对**所有**奇数 $u$ 都有 $g_M(2u)=-g_M(u)$；$|g_M|\le1$ 且只在平方自由数上非零。
由于 $g_M(1)=1$，它还满足 $\Lambda_{g_M}(p)=\log p$ 对**每个**素数 $p$ 成立，并在 $n\le D_0$ 上满足 $\Lambda_{g_M}(n)=\Lambda(n)$。失去的是窗口内半素数等合数处的素数幂支撑；[scratch/864](864-odd-source-kernel-has-an-exact-blind-interval.md) 式 (9)--(11) 说明，若补回这一支撑及乘法性，模型的自由扰动便被排除。

定义 $\Lambda_{g_M}=g_M*\log$。高层的点态抵消 (4)--(5) 原样保留。新增低层只位于 $d\le2D_0\le M/(64H)$，不出现在 $M<m<2M$ 的直接 $g_M(m)$ 中。对 $\Lambda_{g_M}(m)$ 与 $\Lambda_{g_M}(m/2)$ 的低层贡献逐除数作 Poisson 求和：两个尺度的 $X=M/d,M/(2d)$ 分别至少为 $64H,32H$，而 $|h|\le4H$；故每个 $d$ 的 Fourier 项为 $O_\psi(d^{-1}H^{-3}\log M)$。
具体地，对 $L\in\{M,M/2\}$ 置 $X=L/d$、$F_0(t)=\phi(t)$、$F_1(t)=(\log t)\phi(t)$，归一化的逐除数项精确为
\[
 \frac1L\sum_k(\log k)\phi(k/X)e(-hk/X)
 =\frac1d\sum_{j\in\mathbb Z}
 \bigl[(\log X)\widehat F_0(h+jX)+\widehat F_1(h+jX)\bigr].
\]
$F_0,F_1\in C_c^3((1,2))$ 且 $X\ge32H$，故 $|h+jX|\gg H(1+|j|)$ 于 $H\le|h|\le4H$；这给出上面的逐除数界，两个尺度的归一化因子也因此一致。由 $\sum_{d\le2D_0}d^{-1}\ll\log M$，联合观察系数在 $H\le|h|\le2H$ 仍满足
\[
 |\mathcal A_h^{(g_M)}|\ll_\psi H^{-3}\log^2M,
 \qquad
 \sum_{H\le|h|\le2H}|\mathcal A_h^{(g_M)}|^2
 \ll H^{-5}\log^4M=o(H^4/M).
 \tag{10}
\]
直接通道在观察窗内只看见 (3) 的高层，因此其 $h_0$ 系数仍趋于 (9) 的非零常数。模型即使与真实 $\mu$ 在 $d\le D_0\asymp M^{4/5}$ 完全一致，也不支持把直接臂的幂界从联合界及上述代数、奇偶资料中推出。

## 决策边界

式 (1)--(2) 是真实 $\mu,\Lambda$ 的精确分解。反模型 (3)--(9) 说明，若只利用 $\Lambda=\mu*\log$、平方自由支撑、$|\mu|\le1$ 和 $\mu(2u)=-\mu(u)$，**不能**把直接 Möbius 臂的幂界当作联合频带幂界的必要步骤。模型的奇数位未保留真实 $\mu$ 的全部乘法性，$\Lambda_M$ 也未保留素数幂支撑；因此它不否定利用这两项真实结构另证直接臂上界。当前入口应保留 (2) 的两个 odd-$u$ 联合臂，继续攻实际符号协方差；RH 与全尺度局部 Weil 正性仍开放。
