# 真实两端点 Gram 的近差环带获得双倍 Ramachandra 指数长度

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的真实联合系数与目标式 (15)，以及 [note 851](../notes/851-ramachandra-short-sums-give-a-subexponential-quarter-power-collar.md) 式 (4) 已核对的全长度 Ramachandra 短和。本稿用二维分块同时保留两端的 signed 短和，比 [scratch 902](902-local-bandpass-rank-one-main-term-is-repaid-by-each-channel-sidelobe.md) 式 (18) 的任意对数倍近差和一次 Abel 所得的单次指数长度更深。完整中距离环带、moving-$N$ 均方、全尺度 Weil 正性及 RH 仍未解决。证明尚待异源复核，故留在 `scratch/`。

## 命题

固定实值 $\psi\in C_c^3((1,2))$、非负偶 $\eta\in C_c^\infty(\mathbb R)$，并令 $M=2Y\to\infty$、$Y^{1/5}\le H\le Y^{1/4}$、$V_M=(\log M/\log\log M)^{1/3}$。设
\[
c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)
-4\{\Lambda(m)-1+(\log2)\mu(m)\},
\quad
a_m=\frac{c(m)}m\psi(m/M)\mathbf1_{M<m<2M},
\quad
K_H(k)=\sum_h\eta(h/H)e(-hk/M).                    \tag{1}
\]
取任意固定 $7/12<\vartheta<3/5$。存在 $c_0=c_0(\vartheta)>0$，使每个整数区间 $I\subset(M,2M)$ 满足
\[
\left|\sum_{m\in I}c(m)\right|
\ll_\vartheta |I|e^{-c_0V_M}+M^\vartheta .          \tag{2}
\]
任取固定 $\rho$ 满足 $\vartheta<\rho<3/5$，置 $B_M=\lceil M^\rho\rceil$。对所有 $B_M\le U\le M$，真实带符号近差 Gram 有
\[
\boxed{\quad
\left|\sum_{|m-n|\le U}a_m a_nK_H(m-n)\right|
\ll_{\psi,\eta,\vartheta,\rho}
\frac{HU}{M}e^{-2c_0V_M}
+\frac{HB_M}{M}
+\frac{H^2B_MU}{M^2}.
\quad}                                               \tag{3}
\]
特别地，任取固定 $0<b<2c_0$，令 $U_b=\lfloor H^3e^{bV_M}\rfloor$。则某个 $c_b>0$ 使
\[
\boxed{\quad
\left|\sum_{|m-n|\le U_b}a_ma_nK_H(m-n)\right|
\ll_{\psi,\eta,\vartheta,\rho,b}
\frac{H^4}{M}e^{-c_bV_M}
=o(H^4/M),
\quad}                                               \tag{4}
\]
在整个 $Y^{1/5}\le H\le Y^{1/4}$ 上一致。因而 note 849 式 (15) 的未付物理位移可以从 $|m-n|>U_b$ 开始；当 $H\asymp Y^{1/5}$ 时，$U_b=M^{3/5+o(1)}$，仍远短于核的 $M/H=M^{4/5+o(1)}$ 物理宽度。

## 证明

式 (2) 由 note 851 式 (4) 对 $\Lambda-1$、$\mu$ 分别应用，并对偶数项换元 $m=2n$ 得到；区间端点的 $O(\log M)$ 被 $M^\vartheta$ 吸收。下文写 $\epsilon_M=e^{-c_0V_M}$，$\Phi(t)=\psi(t)/t$，$d_m=c(m)\Phi(m/M)\mathbf1_{M<m<2M}$，于是 $a_m=d_m/M$。Chebyshev 的 $\sum_{n\le2M}\Lambda(n)\ll M$ 与 $|\mu|\le1$ 给
\[
\sum_m|d_m|\ll_\psi M.                           \tag{5}
\]
由 $\Lambda\ge0$ 及 (2)，任意位于 $(M,2M)$ 且长度至多 $L$ 的整数区间 $I$ 还满足
\[
\sum_{m\in I}|d_m|\ll_{\psi,\vartheta}L+M^\vartheta.
\tag{6}
\]
确实，$c$ 的两项 von Mangoldt 质量分别由 $\sum_I\Lambda(m)$ 与 $\sum_{m\in I,2\mid m}\Lambda(m/2)$ 控制；对原尺度及换元后的半尺度使用 note 851 式 (4)，常数与 Möbius 项直接支付。式 (6) 也适用于与窗口端点相交的短区间。

把 $(M,2M)$ 的整数依次分为长度 $B_M$ 的块 $C_i$，末块可较短，并记 $D_i=\sum_{m\in C_i}d_m$。式 (2) 对每块的所有前缀成立，$\Phi$ 的上确界及总变差有界；离散 Abel 给
\[
|D_i|\ll_{\psi,\vartheta}B_M\epsilon_M+M^\vartheta
\ll_{\psi,\vartheta,\rho}B_M\epsilon_M.          \tag{7}
\]
最后一步使用 $\rho>\vartheta$，故 $M^{\vartheta-\rho}e^{c_0V_M}\to0$。式 (6) 同时给每个块及长度 $O(B_M)$ 的边界条带的绝对质量 $O(B_M)$，而长度 $O(U)$ 的区间在 $U\ge B_M$ 时有绝对质量 $O(U)$。

由 $\eta$ 的紧支撑，直接逐项微分得到
\[
\|K_H\|_\infty\ll_\eta H,
\qquad \|K_H'\|_\infty\ll_\eta H^2/M.               \tag{8}
\]
对有序块对 $(C_i,C_j)$，若其中所有 $(m,n)$ 满足 $|m-n|\le U$，称为完整对；若只部分满足，称为边界对。边界对中任意被计入的 $(m,n)$ 都有 $\bigl||m-n|-U\bigr|\le2B_M$，因为两块内的距离振幅至多 $2B_M$。由 (5)–(6)，这些配对的绝对总质量至多 $O(MB_M)$；乘 $|K_H|\ll H$ 并除以 $M^2$，费用为
\[
O_{\psi,\eta}(HB_M/M).                             \tag{9}
\]
这里 $U\ge B_M$，所以没有靠近 $|m-n|=0$ 的边界对。

对完整块对，以两个固定块中心的差 $k_{ij}$ 替代 $m-n$。由 (8) 替换误差至多 $O(H^2B_M/M)$ 乘该配对的绝对质量。所有完整对都位于 $|m-n|\le U$；式 (5)–(6) 给其总质量 $O(MU)$，故归一化替换费用为
\[
O_{\psi,\eta,\vartheta}(H^2B_MU/M^2).            \tag{10}
\]
替换后，完整对的贡献恰为 $M^{-2}\sum_{(i,j)\ \mathrm{完整}}D_iD_jK_H(k_{ij})$。块数为 $O(M/B_M)$；每个块至多与 $O(U/B_M+1)=O(U/B_M)$ 个完整伙伴相交。由 (7)–(8)，该贡献的绝对值至多
\[
\frac{H}{M^2}\frac{MU}{B_M^2}(B_M\epsilon_M)^2
\ll\frac{HU}{M}\epsilon_M^2.                    \tag{11}
\]
式 (9)–(11) 合并即为 (3)。

最后 $U_b=H^3e^{bV_M}+O(1)$ 满足 $B_M\le U_b<M$，因为 $H^3\gg M^{3/5}$、$\rho<3/5$，且 $H^3\ll M^{3/4}$、$e^{bV_M}=M^{o(1)}$。将 (3) 除以 $H^4/M$，三项分别至多
\[
e^{-(2c_0-b)V_M},
\qquad O(M^{\rho-3/5}),
\qquad O(M^{\rho-3/4+o(1)}).                           \tag{12}
\]
后两项均小于 $e^{-c_bV_M}$，只需选 $0<c_b<2c_0-b$，证明 (4)。$\square$

## 完整位移带的目标精度块压缩

上述分块对任何物理位移带还有一个精确到目标量级以内的版本。令 $x_i$ 为块 $C_i$ 的任意固定中心，$D_i$ 仍由 (7) 定义。则一致于所有可随 $M,H$ 变化的 $0\le T<U\le M$，
\[
\boxed{\quad
\sum_{T<|m-n|\le U}a_ma_nK_H(m-n)
=\frac1{M^2}
\sum_{\substack{i,j\\T<|x_i-x_j|\le U}}
D_iD_jK_H(x_i-x_j)
+O_{\psi,\eta,\vartheta,\rho}\!\left(\frac{HB_M}{M}\right).
\quad}                                               \tag{13}
\]
因为 $B_M/H^3\ll M^{\rho-3/5}\to0$，式 (13) 的误差对 note 849 式 (15) 的 $H^4/M$ 目标严格可忽略。它把完整真实算术门压成 $O(M^{1-\rho})$ 个真实短块和之间的 signed 协方差；没有估计右侧。

证明 (13)。由于 $\psi$ 紧支撑于 $(1,2)$，存在 $\kappa_\psi>0$，使 $d_md_n\ne0$ 时 $|m-n|\le(1-\kappa_\psi)M$。又 $B_M=o(M/H)$，所以从 $m-n$ 到 $x_i-x_j$ 的线段仍离非零周期别名至少 $\kappa_\psi M/2$。对 $K_H$ 的 Poisson 表达式逐项微分，Schwartz 衰减给任意固定 $A>2$ 的一致界
\[
|K_H'(t)|\ll_{\eta,A,\psi}
\frac{H^2}{M}\left(1+\frac{H|t|}{M}\right)^{-A}
\quad\text{在上述线段上}.                           \tag{14}
\]
令 $W=M/H$。由 (6)，每个长度 $O(2^jW)$ 的局部区间内的 $|d|$ 质量为 $O(2^jW)$，因为 $W\gg M^{3/4}\gg M^\vartheta$；对 $j\ge0$ 作 dyadic 分壳得到
\[
\sup_m\sum_n|d_n|
\left(1+\frac{|m-n|}{W}\right)^{-A}
\ll_{\psi,\vartheta,A}W.                            \tag{15}
\]
所以不计截断时，用 $K_H(x_i-x_j)$ 替换所有 $K_H(m-n)$ 的归一化绝对费用由 (5)、(14)–(15) 至多
\[
\frac1{M^2}\,O\!\left(B_M\frac{H^2}{M}\right)
\sum_m|d_m|\,O(W)
\ll\frac{HB_M}{M}.                                   \tag{16}
\]
若实际位移 $|m-n|$ 与块中心位移 $|x_i-x_j|$ 在 $(T,U]$ 的归属不同，则它距 $T$ 或 $U$ 至多 $2B_M$。两条边界条带各由 (5)–(6) 承受 $O(MB_M)$ 的绝对配对质量；即使 $T=0$ 或两条条带重叠也如此。用 $|K_H|\ll H$ 归一化，其费用又为 $O(HB_M/M)$。与 (16) 相加得到 (13)。$\square$

## 边界

这里对同一真实 $c$ 在两端各使用一次短和；不是把素数、偶素数及 Möbius 通道分别取绝对值。二维分块中，截断 $|m-n|=U$ 的边界费用和核在块内的变化都由 $B_M<H^3$ 的固定幂裕量支付。结论只扩大已支付的近差长度，没有越过固定幂意义下的 $M^{3/5}$ 到 $M^{4/5}$ 空隙；该空隙仍须全域乘法关系的真实二点 signed 输入。

双倍指数也是仅用 (2) 型一阶资料时的自然边界。为见此，固定非负非零 $\psi$、note 849 的 $\eta\ge1$ 于 $1\le|t|\le2$，令 $H=\lceil Y^{1/5}\rceil$、$h_0=\lfloor3H/2\rfloor$，取人工系数 $c_\alpha(m)=\epsilon_M\cos(2\pi h_0m/M+\alpha)$，$\epsilon_M=e^{-c_0V_M}$。它满足比 (2) 更强的 $|\sum_Ic_\alpha|\le\epsilon_M|I|$ 以及 (5)–(6) 的绝对质量上界。对任意固定 $b>2c_0$，令 $U=\lfloor H^3e^{bV_M}\rfloor$；此时 $U/(M/H)=M^{-1/5+o(1)}\to0$。在 $|k|\le U$ 上，$K_H(k)\gg_\eta H$ 且 $\cos(2\pi h_0k/M)>1/2$。对 $\alpha\in[0,2\pi]$ 平均近差二次型，利用 $\mathbb E_\alpha[c_\alpha(m)c_\alpha(n)]=\frac12\epsilon_M^2\cos(2\pi h_0(m-n)/M)$，并只数 $\psi$ 正的固定子区间中的 $\gg MU$ 个整数对，得到某个 $\alpha$ 满足近差 Gram $\gg\epsilon_M^2HU/M$。它与 $H^4/M$ 之比为 $\gg e^{(b-2c_0)V_M}\to\infty$。此人工序列不是真实算术系数；它只说明继续优化一阶资料的确定性传递不能支付更长的次指数近差。
