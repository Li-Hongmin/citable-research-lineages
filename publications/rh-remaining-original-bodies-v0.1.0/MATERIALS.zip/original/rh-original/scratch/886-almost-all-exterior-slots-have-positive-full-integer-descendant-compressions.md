# 几乎所有槽的线性整数后代与全部轮廓保持真实 Weil 正隙（候选）

日期：2026-10-01。依赖 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的实尺度有理槽族、[scratch/885](885-exterior-prime-descendants-have-linear-true-schur-response.md) 的半宽轮廓与一代 Schur 下界，以及 [note 790](../notes/790-reciprocal-slot-transverse-profile-compression.md) 的单槽闭形式。与 scratch/885 的固定平方自由因子层不同，这里一次纳入 **所有** \(n\le X^\alpha\)、\((n,6)=1\) 的整数后代，包括随 \(X\) 增长的因子层、所有素数幂和槽内全部有限能量轮廓；末节还把截断推到 \(n\le\theta X\)。用均方控制反射共振的块算子范数，不要求所有共振消失。结论尚待异源复核，属于真压缩，不判定完整局部 Weil 算子或 RH。

## 定理

固定 \(0<\alpha<1\)。令实数 \(X\to\infty\)、\(H=\log X\)、\(k=X^2\)、\(\ell=\log(1+X^{-2})\)、\(w=\ell/2\)，并记
\[
\mathcal D_\alpha(X)=\{1\le n\le X^\alpha:(n,6)=1\}.
\tag{1}
\]
对 [scratch/884](884-sparse-exterior-weil-profiles-have-a-linear-positive-gap.md) 的矩形 \(\mathcal G_X^\circ\)，除 \(o_\alpha(X^2)\) 个原槽 \(y\) 外，可取 \(x_y\in J_y=(ye^{-\ell/4},ye^{\ell/4})\)，使每个 \(n\in\mathcal D_\alpha(X)\) 的单位奇半宽槽
\[
e_{y,n}=\frac{\mathbf1_{I_{x_y/n}^{+,w}}-\mathbf1_{I_{x_y/n}^{-,w}}}{\sqrt{2w}}
\tag{2}
\]
属于旧奇闭形式域，且 \(e_{y,1}\in V_{\{y\}}\)，\(e_{y,n}\perp V_{\mathcal G_X^\circ}\) 对全部 \(n>1\) 成立。整个族正交归一。其**真实旧 Weil 形式**矩阵满足对这些槽一致的
\[
\boxed{\quad A_{\mathcal D}=D_X I-C_\alpha+o_{\rm op}(1),\qquad
D_X=2H+1-\gamma_E-\log\pi.\quad}
\tag{3}
\]
这里 \(C_\alpha(n,m)=\Lambda(m/n)/\sqrt{m/n}\) 当 \(m/n\ge2\) 为素数幂，\(C_\alpha(n,m)=\Lambda(n/m)/\sqrt{n/m}\) 对反向边，其余为零。故
\[
\boxed{\quad A_{\mathcal D}\succeq((2-\alpha)H-O_\alpha(1))I>0.\quad}
\tag{4}
\]
更强地，令 \(\mathscr V_{y,\alpha}^{\rm prof}\) 是支撑在 (2) 的全部上下半宽槽、关于 \(u\mapsto2H-u\) 为奇函数的完整有限能量轮廓空间。其闭形式压缩也满足
\[
\boxed{\quad A_{k,-}|_{\mathscr V_{y,\alpha}^{\rm prof}}
\succeq((2-\alpha)H-O_\alpha(1))I.\quad}
\tag{4a}
\]
令 \(\mathscr W_{y,\alpha}^{\rm prof}\) 为其中 \(n>1\) 的完整轮廓补空间。取根的常值半宽槽 \(e_{y,1}\)，对该补空间的闭形式逆度量 Schur 扣款记为 \(R_y^{\rm prof}(\alpha)\)。则
\[
\boxed{\quad
\left(\frac{\alpha^2}{4}+o_\alpha(1)\right)H
\le R_y^{\rm prof}(\alpha)
\le\left[V(\alpha)+o_\alpha(1)\right]H,\quad
V(\alpha)=\alpha-(2-\alpha)\log\frac2{2-\alpha}.\quad}
\tag{5}
\]
特别地，先固定 \(\alpha<1\) 后令 \(X\to\infty\)，再令 \(\alpha\uparrow1\)，下界趋 \(H/4\)，上界趋 \((1-\log2)H\)。这只限制该有限后代族的反馈；其余正交补仍未控制。

## 平均反射块：承重步骤

令 \(x\in[X/9,X]\)。由于 \(n\le X^\alpha\)，所有 \(x/n>X^{1-\alpha}/9>1\) 对充分大 \(X\) 成立。异臂素数幂平移在第 \((n,m)\) 个矩阵元出现，只可能满足
\[
\left|\log\frac{s n m}{x^2}\right|<w,
\qquad s\ge2\text{ 为素数幂}.
\tag{6}
\]
若该条件成立，\(s\asymp X^2/(nm)\)、\(c_s=\Lambda(s)/\sqrt s\ll_\alpha H\sqrt{nm}/X\)。对固定 \(n,m\)，相关素数幂数目至多
\[
O_\alpha\!\left(\frac{X^2}{nmH}\right).
\tag{7}
\]
这是对素数用 Chebyshev 上界、对高次素数幂用 \(O(\sqrt T\log T)\) 计数的结果；因 \(T\gg X^{2(1-\alpha)}\)，后一项也为 \(O_\alpha(T/H)\)。每个 \(s\) 允许的 \(x\) 区间以 \(\sqrt{snm}\) 为中心，长度 \(O(Xw)=O(X^{-1})\)。同时，对固定 \(x,n,m\)，(6) 中的整数 \(s\) 落在长度 \(O(1/(nm))\) 的区间，数目有绝对上界。若 \(F_{nm}(x)\) 是该异臂算术块在两个整槽 \(L^2\) 轮廓间的算子范数，则每个可行素数幂只贡献至多常数多个范数不超过一的部分平移/反射，遂有
\[
\int_{X/9}^{X}F_{nm}(x)^2\,dx
\ll_\alpha \frac{X^2}{nmH}\frac1X
\left(\frac{H\sqrt{nm}}X\right)^2
\ll_\alpha\frac HX.
\tag{8}
\]
把 (8) 对至多 \(X^{2\alpha}\) 对指标求和，得到
\[
\int_{X/9}^{X}\sum_{n,m}F_{nm}(x)^2\,dx
\ll_\alpha H X^{2\alpha-1}.
\tag{9}
\]
取阈值 \(\varepsilon_X=X^{\alpha-1}\to0\)。由 Markov 不等式，\(\sum_{n,m}F_{nm}(x)^2>\varepsilon_X\) 的实中心总测度至多
\[
O_\alpha(HX^\alpha)=o(X).
\tag{10}
\]
矩形各 \(J_y\) 两两相离，且 \(|J_y|\ge c/X\)。若一个 \(J_y\) 无好中心，则它全落在 (10) 的坏集内；故坏原槽数至多 \(O_\alpha(HX^{1+\alpha})=o(X^2)\)。对每个其余 \(y\)，选 \(x_y\in J_y\) 使 \(\sum_{n,m}F_{nm}(x_y)^2\le\varepsilon_X\)。对任意轮廓族 \(h=(h_n)\)，块算子估计与 Cauchy--Schwarz 给异臂算术算子
\[
\|E(x_y)h\|\le\|(F_{nm}(x_y))\|_{\ell^2\to\ell^2}\|h\|
\le\varepsilon_X^{1/2}\|h\|=o(1)\|h\|.
\]

## 其余矩阵元与正隙

\(n\ne m\) 时同臂中心距至少 \(cX^{-\alpha}\gg w\)，故全部 \(e_{y,n}\) 正交。由于 \(n>1\) 且 \((n,6)=1\) 蕴含 \(n\ge5\)，有 \(x_y/n<(1+o(1))X/10<X/8\)，而原矩形所有槽中心大于 \(X/8\)；因此这些后代与整个槽外空间正交。\(x_y\in J_y\) 保证 \(e_{y,1}\) 的半宽槽落在原槽内。

同臂平移槽相交迫使 \(|sn-m|<m(e^w-1)<1\)，所以恰有整数等式 \(sn=m\)；平移后两个半宽槽完全重合，其 Weil 矩阵元是 \(-\Lambda(s)/\sqrt s\)。这包括所有素数幂而不限制因子层。note 790 的单槽公式给共同对角 \(D_X+o(1)\)。不同同臂槽的 Archimedean 行和至多 \(O(X^{2\alpha-2})=o(1)\)；上下异臂距离至少 \(2(1-\alpha)H-O(1)\)，相应行和也是 \(o(1)\)。polar 压缩范数至多
\[
O\!\left(wX\sum_{n\in\mathcal D_\alpha}\frac1n\right)
=O(H/X)=o(1).
\]
加上 (10) 的异臂算术算子界，证明 (3)。对完整轮廓，使用 note 790 的精确单槽闭形式：缩放到 \((0,1)\) 后，局部能量为
\[
\bigl(\log(1/w)-\log(2\pi)-\gamma_E\bigr)\|h_n\|^2+\mathfrak b[h_n],
\qquad \mathfrak b[h_n]\ge(\log2)\|h_n\|^2.
\tag{10a}
\]
因此局部对角至少 \(D_X-(1-\log2)-o(1)\)。同臂算术边在共同槽坐标中精确为 \(-C_\alpha\otimes I_{L^2(0,w)}\)；前述 Archimedean、polar 与异臂块的范数估计对整个轮廓空间不变。下面的加权图界遂同时证明 (4) 与 (4a)。

置 \(v_n=n^{-1/2}\)。在全图 \(C_\alpha\) 的第 \(n\) 行，向下删去素数幂的加权比值和等于 \(\sum_{s\mid n,\,s\text{ 素数幂}}\Lambda(s)=\log n\)；向上添加的和不超过
\(\sum_{s\le X^\alpha/n}\Lambda(s)/s\le\log(X^\alpha/n)+O(1)\)。全部 \(n\) 与 \(s\) 都与 6 互素。正权 Schur 检验给 \(\|C_\alpha\|\le\alpha H+O(1)\)，证明 (4)。

## 根的完整轮廓 Schur 扣款

根只通过同臂素数幂边连接 \(n=s\)；在补轮廓直和坐标中，令 \(h_0\) 为单位常值槽。由上述块算子估计，真实根列可写
\[
g_\alpha=-b\otimes h_0+o_{\oplus L^2}(1),\qquad
b_n=\begin{cases}\Lambda(n)/\sqrt n,&n>1\text{ 为素数幂},\\0,&\text{其他},\end{cases}
\quad\|b\|=O(H).
\tag{11}
\]
对补图逐边配方：对 \(n\to ns\)，
\[
\Lambda(s)\left|\frac{a_n}{\sqrt s}-a_{ns}\right|^2
=\frac{\Lambda(s)}s|a_n|^2+\Lambda(s)|a_{ns}|^2
-2\frac{\Lambda(s)}{\sqrt s}\operatorname{Re}\overline{a_n}a_{ns}.
\]
对完整轮廓，\(a_n\) 在这里取 \(L^2(0,w)\) 值，平方恒等式仍逐边成立。从补图删除单位节点后，\(n\) 的向下和为 \(\log n-\Lambda(n)\mathbf1_{n\text{ 为素数幂}}\)。Mertens 的统一上界 \(\sum_{s\le t}\Lambda(s)/s\le\log t+O(1)\)，连同 (10a) 的固定常数差，遂给真实补闭形式
\[
B_\alpha^{\rm prof}\succeq
\operatorname{diag}\left((2-\alpha)H+\Lambda(n)\mathbf1_{n\text{ 为素数幂}}-O_\alpha(1)\right).
\tag{12}
\]
式 (4a) 的 \(H\) 级正隙与 (11) 的根列误差允许直接使用闭形式的 Loewner 逆序比较；素数定理给
\[
\begin{aligned}
R_y^{\rm prof}(\alpha)
&\le\sum_{\substack{s\le X^\alpha\\s\text{ 素数幂},\ (s,6)=1}}
\frac{\Lambda(s)^2/s}{(2-\alpha)H+\Lambda(s)-O_\alpha(1)}+o(1)\\
&=\int_0^{\alpha H}\frac{u}{(2-\alpha)H+u}\,du+o(H)
=V(\alpha)H+o(H).
\end{aligned}
\tag{13}
\]
高次素数幂在第一行的总贡献是 \(O_\alpha(H^{-1})\)。下界只在补空间保留素数 \(5\le q\le X^\alpha\) 的常值槽：其互相没有同臂边，异臂误差为 \(o_{\rm op}(1)\)，并且
\(\sum_q(\log q)^2/q=(\alpha^2/2+o(1))H^2\)。此星图的真扣款为 \((\alpha^2/4+o(1))H\)；逆度量变分式对增添后代单调，得到 (5)。\(\square\)

## 线性端点：\(n\le\theta X\)

固定 \(0<\theta<1/9\)，以 \(N=\lfloor\theta X\rfloor\) 和
\(\mathcal D_\theta^{\rm lin}(X)=\{1\le n\le N:(n,6)=1\}\)
替换 (1)。则除 \(O_\theta(X^2/H)\) 个原槽外，仍可选 \(x_y\in J_y\)，使这些槽内**全部有限能量轮廓**的真实压缩满足
\[
\boxed{\quad
A_{k,-}|_{\mathscr V_{y,\theta}^{\rm lin,prof}}
\succeq (H-O_\theta(\sqrt H))I,
\qquad
\left(\frac14+o_\theta(1)\right)H
\le R_y^{\rm lin,prof}(\theta)
\le\left(1-\log2+o_\theta(1)\right)H.
\quad}
\tag{14}
\]
这里 \(R_y^{\rm lin,prof}(\theta)\) 是根的单位常值轮廓对全部 \(n>1\) 整数后代轮廓的真闭形式 Schur 扣款。\(\theta<1/9\) 保证在以下整个平均中心区间都有 \(x/n>1\)；它不是一个声称尖锐的端点。

**反射块的端点均方。** 仍令 \(F_{nm}(x)\) 为 (8) 的整个异臂块范数，但此处 \(n,m\le N\)。令 \(T=X^2/(nm)\ge\theta^{-2}\)。对固定 \(x,n,m\)，(6) 中可行整数 \(s\) 的数目仍有绝对上界。每个相关素数幂满足 \(s\le2T\)，所排除的中心 \(x\) 区间长至多 \(Cw\sqrt{snm}\)。Chebyshev 上界、\(\Lambda(s)^2\le(\log(2T))\Lambda(s)\) 和分部求和给
\[
\sum_{s\le2T}\frac{\Lambda(s)^2}{\sqrt s}
\le C\sqrt T\log(2T).
\tag{15}
\]
于是无需对所有素数幂用同一个最坏的 \(H\) 权重，而可逐幂积分：
\[
\int_{X/9}^{X}F_{nm}(x)^2\,dx
\ll w\sqrt{nm}
\sum_{s\le2T}\frac{\Lambda(s)^2}{\sqrt s}
\ll \frac{\log(2T)}{X}.
\tag{16}
\]
由于 \(N\asymp_\theta X\)，Stirling 公式给
\[
\sum_{n,m\le N}\log\frac{2X^2}{nm}
=N^2\log2+2N^2\log X-2N\log(N!)=O_\theta(X^2).
\]
把 (16) 对 \((n,6)=(m,6)=1\) 求和，得到
\[
\int_{X/9}^{X}\sum_{n,m}F_{nm}(x)^2\,dx
\ll_\theta X.
\tag{17}
\]
故 \(\sum F_{nm}(x)^2>H\) 的中心测度为 \(O_\theta(X/H)\)。各 \(J_y\) 相离且长度 \(\gg1/X\)，因此至多 \(O_\theta(X^2/H)\) 个原槽找不到满足 \(\|E(x_y)\|\le\sqrt H\) 的中心。

**完整轮廓及逆响应。** 对选出的中心，所有 \(x_y/n\) 至少为 \((9\theta)^{-1}+o(1)>1\)，而 \(n>1\) 时仍有 \(x_y/n<(1+o(1))X/10<X/8\)，所以物理槽的分离与原槽正交性不变。同臂 Archimedean 块行和由 \(wN^2=O_\theta(1)\) 支付；异臂 Archimedean 行和及 polar 范数为 \(o(1)\)。同臂算术图仍精确，且 \(v_n=n^{-1/2}\) 的行权比至多 \(\log N+O(1)=H+O_\theta(1)\)。单槽完整轮廓下界是 \(2H-O(1)\)。合并 \(\|E\|\le\sqrt H\) 证明 (14) 的正隙。

在 \(n>1\) 的补空间上，逐边平方给对角下界
\(2H-\log N+\Lambda(n)\mathbf1_{n\text{ 为素数幂}}-O_\theta(\sqrt H)\)。根列为 \(-b\otimes h_0+r\)，其中 \(\|b\|=O(H)\)、\(\|r\|=O_\theta(\sqrt H)\)。由补空间的 \(\gg H\) 正隙，\(r\) 对逆度量贡献的交叉项为 \(O_\theta(\sqrt H)=o(H)\)。对素数应用 (13) 的 Stieltjes 积分，但把上限改成 \(\log N=H+O_\theta(1)\)，给
\[
R_y^{\rm lin,prof}(\theta)
\le\int_0^{\log N}\frac{u}{2H-\log N+u}\,du+o(H)
=(1-\log2+o_\theta(1))H.
\]
只保留素数常值后代时，其补块为 \(2H I+O_\theta(\sqrt H)\)，根列的主平方范数为 \((1/2+o(1))H^2\)；逆度量变分给下界 \((1/4+o(1))H\)。\(\square\)

由于根自能量为 \(2H+O(1)\)，(14) 还给消去这个**完整整数轮廓锥**后的真有限 Schur 枢轴
\[
A_{k,-}[e_{y,1}]-R_y^{\rm lin,prof}(\theta)
\ge(1+\log2-o_\theta(1))H.
\tag{18}
\]
这里没有消去锥外的其余旧奇空间。

同一结论还可把固定 \(N=\lfloor\theta X\rfloor\) 换成**每个原槽自身的**
\(N_y=\lfloor y/2\rfloor\)：坏槽数仍为 \(O(X^2/H)\)，(14) 的 \(H-O(\sqrt H)\) 正隙、两端 Schur 系数及 (18) 均一致成立。为避免在平均中心区间讨论尚未位于旧物理空间的槽，对所有 \(1\le n,m\le X/4\) 定义纯数值共振包络
\[
\widetilde F_{nm}(x)=C\sum_{s\text{ 素数幂}}
\frac{\Lambda(s)}{\sqrt s}
\mathbf1_{\{|\log(snm/x^2)|<w\}}.
\tag{19}
\]
每个实际异臂块范数至多为它；(15)--(17) 对 \(\widetilde F\) 逐字成立，且 \(N_{\max}=X/4\) 仍使求和为 \(O(X)\)。因此在除 \(O(X^2/H)\) 个原槽外的每个 \(J_y\) 可选 \(\|\widetilde F(x_y)\|_{\rm HS}\le\sqrt H\) 的中心。对 \(n\le N_y\)，有 \(x_y/n\ge2e^{-\ell/4}-o(1)>1\)；又 \(X/16+O(1)\le N_y\le X/4\)，故 \(\log N_y=H+O(1)\) 一致，前面的图隙及素数 Stieltjes 积分不变。

## 边界

式 (3) 允许少量异臂共振，但证明它们在几乎所有原槽可选中心上的整体块算子范数趋零；在线性端点，该范数只需是 \(o(H)\)，式 (17) 给出 \(O(\sqrt H)\)。这把 scratch/885 的固定代数层扩展到线性多个整数后代及其任意有限能量轮廓。正隙与根 Schur 上界不能外推到全部有理后代、原整数槽以外的轮廓，或完整旧奇正交补。全尺度局部 Weil 正性、moving-\(N\) Möbius signed covariance 与 RH 仍开放。
