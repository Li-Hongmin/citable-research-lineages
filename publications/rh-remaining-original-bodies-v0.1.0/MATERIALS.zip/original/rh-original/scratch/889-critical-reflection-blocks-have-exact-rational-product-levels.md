# 临界分母反射块按精确有理乘积解耦（候选）

后续 [scratch/890](890-bounded-incoming-prime-load-pays-subexponential-farey-denominators.md) 利用本稿的精确乘积层和有界大素数入边数，将反射范数改进为 \(O(\sqrt H+\log(B+2)\sqrt{1+\log(B+2)/\log(H+2)})\)。

日期：2026-10-01。沿用 [scratch/888](888-all-exterior-rational-cones-below-log-squared-denominators.md) 的实尺度 \(X\)、\(H=\log X\)、原槽 \(y\)、分母截断 \(B\)、标签集 \(\mathcal R_{y,B}\)、半宽 \(w=\frac12\log(1+X^{-2})\) 和完整轮廓异臂算术块 \(E_{y,B}\)。这里专看临界范围 \(1\le B\le H^2\)。结论只约化反射块的谱问题，不判定其临界谱范数或完整 Weil 正性。证明尚待异源复核。

## 精确分块

记 \(\mathcal R^{\rm lo}=\{r\in\mathcal R_{y,B}:r\le B^2\}\)、\(\mathcal R^{\rm hi}=\mathcal R_{y,B}\setminus\mathcal R^{\rm lo}\)。存在由有理数 \(P\) 标记的互不相交高标签子集 \(\mathcal R_P\)，以及有限非负对称矩阵
\[
K_P(r,r')=
\begin{cases}
\displaystyle\frac{\Lambda(P/(rr'))}{\sqrt{P/(rr')}} ,
&P/(rr')\text{ 是整数素数幂},\\[4pt]
0,&\text{其他},
\end{cases}
\qquad r,r'\in\mathcal R_P ,
\tag{1}
\]
使得高标签上的完整轮廓反射块精确写成
\[
\boxed{\quad
E_{y,B}^{\rm hi}
=\bigoplus_{P}K_P\otimes J_{\delta_P},
\qquad
\delta_P=\log(P/y^2),\quad |\delta_P|<w.
\quad}
\tag{2}
\]
这里 \(J_{\delta}\) 是同一个 \(L^2(-w/2,w/2)\) 部分反射，
\[
(J_\delta h)(z)=
\mathbf1_{\{|z-\delta|<w/2\}}\,h(\delta-z),
\qquad \|J_\delta\|=1\quad(|\delta|<w).
\tag{3}
\]
因而 \(\|E_{y,B}^{\rm hi}\|=\max_P\|K_P\|\)。可能的 \(P\) 均在 \((y^2e^{-w},y^2e^w)\) 内，约分后分母不超过 \(B^2\)，总数为 \(O(B^4)\)。

低标签行满足 \(\sup_{r\in\mathcal R^{\rm lo}}\sum_{r'}\|E_{rr'}\|\ll (H+B)B^2/\sqrt X\)，全体高标签行满足 \(\sum_{r'}\|E_{rr'}\|\ll\sqrt H+\sqrt B\)。因此矩形 Schur 检验给
\[
\boxed{\quad
\left|\|E_{y,B}\|-\max_P\|K_P\|\right|
\ll \frac{(H+B)B^2}{\sqrt X}
+\left(\frac{(H+B)B^2(\sqrt H+\sqrt B)}{\sqrt X}\right)^{1/2}
=o(1)
\quad}
\tag{4}
\]
对每个 \(y\) 一致。特别地，根 \(r=1\) 的整条异臂算术列范数为 \(o(1)\)，即使 \(B\asymp H^2\)。

## 证明

一个反射边 \((r,r',s)\) 必满足
\[
\left|\log\frac{srr'}{y^2}\right|<w.
\tag{5}
\]
固定 \(r\) 并置 \(t=sr'\)。约分后 \(\operatorname{den}(t)\le B\)，而 \(t\) 落在长度
\[
\frac{y^2}{r}(e^w-e^{-w})
=\frac{y^2}{rX^2\sqrt{1+X^{-2}}}
<\frac1{4r}
\tag{6}
\]
的区间内。不同约分分母至多 \(B\) 的有理数相距至少 \(B^{-2}\)。故 \(r>B^2\) 时，该行的全部反射边有**唯一**的 \(t_r\)，从而有唯一的精确乘积 \(P_r=r t_r=srr'\)。若 \(r,r'>B^2\) 且两者相连，同一边使 \(P_r=P_{r'}\)。把所有非孤立高标签按 \(P_r\) 分组，得到 \(\mathcal R_P\)；孤立点给零块。

对一个固定 \(P\)，每条边的素数幂 \(s=P/(rr')\) 唯一。式 (5) 的槽内偏移只取决于 \(\delta_P=\log(P/y^2)\)：在以各上臂中心为零点的共同坐标 \(z\in(-w/2,w/2)\) 下，奇反射和平移 \(s\) 把轮廓 \(h(z)\) 送到 \(h(\delta_P-z)\)，并截去落在槽外的部分。旧奇算术系数对所有边同为 \(+\Lambda(s)/\sqrt s\)。这证明 (1)--(3)；\(|\delta_P|<w\) 时反射限制在一个非空区间上，故其范数恰为一。

每个 \(P=srr'\) 的约分分母至多 \(B^2\)。式 (5) 中 \(P\) 的允许区间长 \(y^2(e^w-e^{-w})<1/4\)，而不同分母至多 \(B^2\) 的有理数相距至少 \(B^{-4}\)，所以 \(P\) 的数目为 \(O(B^4)\)。

[scratch/888](888-all-exterior-rational-cones-below-log-squared-denominators.md) 式 (9)--(12) 给低行与高行的上述绝对和。把 \(E\) 按 \(\mathcal R^{\rm lo}\oplus\mathcal R^{\rm hi}\) 分块，低低块范数至多低行和；低高块的最大行和至多低行和，最大列和至多高行和，故其范数至多两者乘积的平方根。加上高高块的精确分解，证明 (4)。根属于低标签；其列的 \(\ell^2\) 范数不超过绝对行和，故为 \(o(1)\)。\(\square\)

## 临界块的平方行界

固定 \(P\) 和 \(r\in\mathcal R_P\)。同一列 \(r'\) 至多对应一个 \(s=P/(rr')\)，故
\[
\sum_{r'}K_P(r,r')^2
\le\sum_{\substack{s=p^j\\(P/r)/s\in\mathcal R_{y,B}}}\frac{\Lambda(s)^2}{s}.
\tag{7}
\]
写 \(P/r=A/D\) 既约，则 \(A\le C X^2B\)、\(\log(A+2)\ll H\)。对 \(s\mid A\)，令 \(Z=\log^2(A+2)\)：低段使用 \(\Lambda(s)\le\log Z\) 和 \(M(Z)=\sum_{s\le Z}\Lambda(s)/s\ll\log Z\)，高段使用 \(\sum_{s\mid A}\Lambda(s)=\log A\)，得到
\[
\sum_{s\mid A}\frac{\Lambda(s)^2}{s}
\ll\log^2(H+2)+\frac{\log^2 A}{Z}
\ll\log^2(H+2).
\tag{8}
\]
若 \(s=p^j\) 且 \(j>v_p(A)\)，约分分母限制 \(p^{j-v_p(A)}\le B\)；因此该部分至多
\[
\sum_{p^h\le B}\frac{(\log p)^2}{p^h}
\le \log(B+2)M(B)\ll\log^2(B+2).
\tag{9}
\]
于是
\[
\boxed{\quad
\max_{P,r}\left(\sum_{r'}K_P(r,r')^2\right)^{1/2}
\ll\log(H+2)+\log(B+2)
\ll\log(H+2)\quad(B\le H^2).
\quad}
\tag{10}
\]
式 (10) 说明单个反射星的平方质量远小于 \(H^2\)，但尚不足以界定许多行之间的相干。由 Frobenius 界还知：若某个 \(\|K_P\|\ge cH\)，其非孤立标签数至少为 \(\gg_c H^2/\log^2(H+2)\)。临界问题因此精确落在这些有限乘积层的集体谱，而不落在单行大权重。
