# 两端点余项在四分之一次幂对数邻域内的频带界

日期：2026-10-02。依赖 [note 849](../notes/849-two-endpoint-observation-fourier-expansion-for-full-k2-residual.md) 的式 (1)、(8)、(10)–(12)、(26) 及其记号。外部输入为 Matomäki–Shao–Tao–Teräväinen, *Higher uniformity of arithmetic functions in short intervals I. All intervals*, arXiv:2204.03754v4, Theorem 3.1(i) 和式 (3.11)；2026-10-02 核对原文。以下是解析证明，尚待异源复核。

## 命题

设固定 $\psi\in C_c^3((1,2))$，并令 $\eta\in C_c^\infty(\mathbb R)$ 非负、偶，支撑于 $1/2\le |t|\le4$ 且 $\eta\ge1$ 于 $1\le |t|\le2$。令 $M=2Y$，$Y\to\infty$ 沿整数，$Y^{1/5}\le H\le Y^{1/4}$，并沿用 note 849 的 $\mathcal A_h(Y)$、$S_h$。则对每个固定 $A>0$，一致于该 $H$ 范围，
\[
\boxed{\sum_{h\in\mathbb Z}\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{A,\psi,\eta}(\log Y)^{-A}.}\tag{1}
\]
特别地，对任意固定 $B,D>0$，若
\[
Y^{1/4}(\log Y)^{-B}\le H\le Y^{1/4},\tag{2}
\]
则
\[
\sum_h\eta(h/H)|\mathcal A_h(Y)|^2
\ll_{B,\psi,\eta}\frac{H^4}{Y},\qquad
\frac1Y\sum_{H\le|h|<2H}|S_h|^2
\ll_{B,D,\psi,\eta}Y^2(\log Y)^{-D}.\tag{3}
\]
式 (1) 加强了 note 849 式 (22) 的无速率 $o(1)$。若 $\mathfrak C_{\rm odd}$ 是 [note 850](../notes/850-lattice-spacing-pays-the-complete-two-arm-large-gcd-tail.md) 的完整两臂不同源 Möbius 协方差，则同样有
\[
|\mathfrak C_{\rm odd}|\ll_{A,\psi,\eta}(\log Y)^{-A}
\quad\text{对每个固定 }A>0.\tag{3a}
\]
式 (3) 与 (3a) 在四分之一次幂端点的固定对数宽度达到算术门量纲；它们未给 $H=Y^{1/4-\theta}$（固定 $\theta>0$）的幂次门，也不推出 RH。

## 证明

写 $c(m)=2\mathbf1_{2\mid m}(\Lambda(m/2)-1)-4(\Lambda(m)-1+(\log2)\mu(m))$，并取 $Q=\lfloor Y^{2/3}\rfloor$。先证对任意固定 $A>0$、任意包含于 $(M,2M)$ 的长 $Q$ 整数区间 $I$，
\[
\left|\sum_{m\in I}c(m)\right|\ll_A Q(\log Y)^{-A}.\tag{4}
\]
原文 Theorem 3.1(i) 在 $X^{7/12+\varepsilon}\le H\le X^{1-\varepsilon}$ 的所有区间，对 $\mu$ 与 $\Lambda-\Lambda^\sharp$ 均给任意固定对数幂节省，取模数 $q=1$ 即可；其式 (3.11) 同时给
\[
\sum_{X<n\le X+H}\Lambda^\sharp(n)
=H+O_\varepsilon\!\left(H e^{-(\log X)^{1/2}}\right)
\quad(H\ge X^\varepsilon).
\]
故同一范围内 $\sum(\Lambda(n)-1)\ll_A H(\log X)^{-A}$。式 (4) 的未缩放两项在 $X\asymp Y,H\asymp Q$；偶数项作 $m=2n$ 后在 $X\asymp Y,H\asymp Q/2$。两者均满足定理范围，例如取 $\varepsilon=1/24$；端点取整误差 $O(\log Y)$ 可吸收，得到 (4)。这里没有把原文的 $\Lambda-\Lambda^\sharp$ 误写成 $\Lambda-1$。

令 $L=\lfloor Y/(16H)\rfloor\asymp M/H$。因为 $|c(m)|\ll\log Y$，把任意长度不超过 $L$ 的整数区间分为长 $Q$ 的整块及至多两个余段，由 (4) 得
\[
\sup_{|I|\le L}\left|\sum_{m\in I}c(m)\right|
\ll_A L(\log Y)^{-A}+Q\log Y.\tag{5}
\]
置 $a_m=c(m)\psi(m/M)/m$，在支撑上 $|\psi(m/M)/m|\ll_\psi M^{-1}$，且任意长不超过 $L$ 的区间上的总变差为 $O_\psi(L/M^2)$。对 (5) 作离散 Abel 求和，得到
\[
\sup_{|I|\le L}\left|\sum_{m\in I}a_m\right|
\ll_{A,\psi}\frac{L}{M}(\log Y)^{-A}
+\frac{Q\log Y}{M}.\tag{6}
\]
将 $a_m$ 周期化为模 $M$ 的序列 $b_x=a_{x+M}$。因 $\psi$ 的支撑与两个拼接端点保持固定距离，长度 $L=o(M)$ 的周期窗口至多分成两个满足 (6) 的区间。记 $D_L(h)=\sum_{j=0}^{L-1}e(-hj/M)$；在 $\eta(h/H)\ne0$ 时 $|h|L/M\le1/8$，故 $|D_L(h)|\gg L$，这些 $h$ 在模 $M$ 下互异。周期 Parseval 和 (6) 给
\[
\begin{aligned}
\sum_h\eta(h/H)|\mathcal A_h|^2
&\ll_\eta \frac{M}{L^2}\sum_{x\bmod M}
\left|\sum_{j=0}^{L-1}b_{x-j}\right|^2\\
&\ll_{A,\psi,\eta}
\left((\log Y)^{-A}+\frac{Q\log Y}{L}\right)^2.
\end{aligned}\tag{7}
\]
在 $H\le Y^{1/4}$ 时 $Q/L\ll Y^{-1/12}$，所以 (7) 对任意固定负对数幂成立，证明 (1)。在 (2) 下 $H^4/Y\ge(\log Y)^{-4B}$，从 (1) 选 $A>4B$ 即得 (3) 第一式。

由 note 849 式 (1)、(8)，$S_h=Y^2\mathcal A_h/(2\pi h^2)+E_h$；其式 (7) 给
\[
\frac1Y\sum_{H\le|h|<2H}|E_h|^2
\ll_\psi\frac{Y^3}{H^5}+\frac{H^5}{Y}.\tag{8}
\]
因此 (1) 对任意指定的 $D+4B$ 给主项的归一化能量 $O(Y^2(\log Y)^{-D})$。在 (2) 内，(8) 的第一项至多 $Y^{7/4}(\log Y)^{5B}$，第二项至多 $Y^{1/4}$，均为 $o(Y^2(\log Y)^{-D})$。三角不等式完成 (3)。

为得 (3a)，[scratch/926](926-odd-source-normal-form-for-the-complete-two-arm-observation.md) 式 (6)–(7) 将 $\mathcal A_h$ 换成完整奇数源两臂包，带权平方误差至多 $O(H^{-5}\log^4M+H/M^2)$，在当前范围有任意固定负对数幂。由 (1) 和 $\ell^2$ 三角不等式，该源包的带权能量也为 $O_A((\log Y)^{-A})$。再扣除 scratch/926 式 (8) 的绝对对角界 $O(H^2\log^2(2H)/M)$，即得到 (3a)。$\square$

## 剩余边界

推导只用一阶短区间和，因此给出任意对数幂而非固定幂节省。由 note 849 式 (30)，式 (1) 对该文保留真实素数、两倍素数及 Möbius 三通道的 $\mathcal A_h^{\rm tri}$ 也成立，因为替换误差在本 $H$ 范围内有固定幂衰减。它在 $H=Y^{1/4}/(\log Y)^B$ 达到 note 849 的算术门量纲；在任意固定幂内点 $H=Y^{1/4-\theta}$ 仍缺 $Y^{-4\theta}$ 级的真实二点 signed covariance。本文不改变完整 moving-$N$ 门的开放状态。
