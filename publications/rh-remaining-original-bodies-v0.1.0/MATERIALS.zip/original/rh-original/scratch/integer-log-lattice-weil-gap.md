# 整数对数格上完整 Weil 形式的尖锐主阶谱隙（探索稿）

日期：2026-10-02。只读推导，待独立复核。依赖 [note 004](../notes/004-exact-logarithmic-laplacian-normalization.md)、[note 007](../notes/007-indefinite-polar-splitting-and-reduced-markov-form.md)、[note 008](../notes/008-reduced-ground-state-and-odd-spectral-gap.md)。

## 命题

令 $p\to\infty$ 沿奇素数，$H=\log p$，$N=\lfloor p^2/16\rfloor$，$\ell=1/(100p^4)$，$y_n=H-\log4-\log n$，

$$
I_n=(y_n-\ell/2,y_n+\ell/2),\qquad U_p=\bigcup_{1\le n\le N}I_n\subset(-H,H).
$$

记局部 Weil 闭形式在 $U_p$ 上的底为

$$
\lambda(U_p)=\inf_{0\ne f\in D(Q_W^H),\ \operatorname{supp}f\subset U_p}
\frac{Q_W^H[f]}{\|f\|_2^2}.
$$

则

$$
\boxed{\lambda(U_p)=\log(1/\ell)-\log N+O(1)=2H+O(1).}\tag{1}
$$

这对每槽任意有限能量轮廓成立，允许奇偶混合；$U_p$ 的中心贯穿从 $-H+\log4+o(1)$ 到 $H-\log4$ 的全物理区间。它仍只是压缩定理。

## 1. 分片与唯一整数位移

充分大 $p$ 时 $I_n$ 两两不交，最小中心间距至少 $\log(1+1/N)>1/(2N)\gg\ell$。对 $f$ 支撑于 $U_p$，写 $f_n=f\mathbf1_{I_n}$，并用共同局部坐标 $t\in(-\ell/2,\ell/2)$ 写 $\phi_n(t)=f(y_n+t)$。即使原函数仅在闭形式域中，这一分片仍合法。固定 $p$ 后，可在各槽间的正间隙中取光滑截断 $\chi_n$，使其在 $I_n$ 上等于一、在其余槽上等于零，于是 $f_n=\chi_nf$。note 004 的定义域可由高频权 $\log(2+|\xi|)$ 与 $L^2$ 范数刻画；与 Schwartz 函数 $\widehat\chi_n$ 卷积保持这一加权 $L^2$ 空间（用 $\log(2+|\xi+\eta|)\ll\log(2+|\xi|)+\log(2+|\eta|)$），故 $f_n\in D(Q_W^H)$。下面的估计也可先对各槽光滑轮廓证明，再经此分片与闭形式恒等式延拓。

若素数幂位移 $\log k$ 将 $I_n$ 与 $I_r$ 接触，则

$$
|\log(r/(kn))|<\ell\quad\text{或}\quad|\log(n/(kr))|<\ell.
$$

前者使两个整数 $r,kn$ 满足 $|r-kn|<2N\ell<1$，故 $r=kn$；后者同理给 $n=kr$。反过来，每个整除关系给完全重合的平移槽，因为所有槽等宽。故 prime-shift 二次型**精确**为 $\langle\phi,(C_N\otimes I)\phi\rangle$，其中 $C_N$ 是 $\ell^2(\{1,\ldots,N\})$ 上的实对称非负矩阵

$$
(C_N)_{n,r}=\begin{cases}
\Lambda(r/n)/\sqrt{r/n},& n\mid r,\ n<r,\\
\Lambda(n/r)/\sqrt{n/r},& r\mid n,\ r<n,\\
0,&\text{其余}.
\end{cases}\tag{2}
$$

## 2. 整除图范数

取严格正权 $v_n=n^{-1/2}$，记 $M_1(x)=\sum_{k\le x}\Lambda(k)/k$。逐行精确计算给

$$
\frac{(C_Nv)_n}{v_n}
=\sum_{k\le N/n}\frac{\Lambda(k)}k
+\sum_{k\mid n}\Lambda(k)
=M_1(N/n)+\log n
=\log N+O(1).\tag{3}
$$

末式在 $1\le n\le N$ 上一致。这里 $M_1(x)=\log x+O(1)$ 可从恒等式
$\sum_{d\le x}\Lambda(d)\lfloor x/d\rfloor=\log\lfloor x\rfloor!$、Stirling 公式及初等 Chebyshev 界 $\sum_{d\le x}\Lambda(d)=O(x)$ 直接推出。矩阵 $C_N$ 非负且对称，所以加权 Schur 检验与用 $v$ 作 Rayleigh 向量分别给

$$
\boxed{\|C_N\|=\log N+O(1).}\tag{4}
$$

式 (4) 同样是 $C_N\otimes I$ 在全部槽轮廓空间上的范数。

## 3. 单槽成本与非算术交叉

单个 $f_n$ 的支撑测度至多 $\ell$。由 Fourier 约定、$|\widehat f_n(\xi)|^2\le\ell\|f_n\|_2^2$ 取 $T=1/\ell$，

$$
\int\log|\xi|\,|\widehat f_n(\xi)|^2\frac{d\xi}{2\pi}
\ge\left(\log(1/\ell)-\frac1\pi\right)\|f_n\|_2^2.\tag{5}
$$

同一槽内没有非零整数 prime shift；$r_1''$ 有界，故 note 004 的公式给其约化形式
$q_{\rm red}[f_n]\ge(\log(1/\ell)-C_0)\|f_n\|_2^2$，其中 $C_0$ 与 $p,n$ 无关。

不同槽之间，扣除 prime-shift 原子后，note 007 的普通约化核是
$-k(|y-z|)$，$k(t)=e^{-t/2}/(1-e^{-2t})\le C/t$。因为槽长 $\ell\ll|\log(n/r)|$，相应块范数至多 $C\ell/|\log(n/r)|$。统一行和满足

$$
\max_n\sum_{r\ne n}\frac{\ell}{|\log(n/r)|}
\ll\ell N\log(2N)=O(H/p^2)=o(1).\tag{6}
$$

确实在 $n/2\le r\le2n$ 时 $|\log(r/n)|\gg|r-n|/n$，调和和给 $O(n\log(2n))$；其余 $r$ 有 $|\log(r/n)|\ge\log2$，总数至多 $N$。由 Schur 检验，全部普通非算术交叉的算子范数为 $o(1)$。

极点项可能变号，但 $q_{\rm pol}(f)=2\operatorname{Re}(p_+(f)\overline{p_-(f)})$，因此其绝对值至多

$$
\left(\|e^{y/2}\mathbf1_{U_p}\|_2^2+
\|e^{-y/2}\mathbf1_{U_p}\|_2^2\right)\|f\|_2^2.
$$

这里

$$
\|e^{y/2}\mathbf1_{U_p}\|_2^2
\ll p\ell\sum_{n\le N}\frac1n=O(H/p^3),\qquad
\|e^{-y/2}\mathbf1_{U_p}\|_2^2
\ll\frac\ell p\sum_{n\le N}n=O(p^{-1}).\tag{7}
$$

所以 polar 对整个槽空间的范数为 $o(1)$。结合 (2)、(4)--(7)，对全部有限能量 $f$ 有

$$
Q_W^H[f]\ge\bigl(\log(1/\ell)-\log N-O(1)\bigr)\|f\|_2^2.\tag{8}
$$

## 4. 匹配上界

固定非负单位 $\varphi\in C_c^\infty((-1/2,1/2))$，令
$b_\ell(t)=\ell^{-1/2}\varphi(t/\ell)$，以 $\phi_n(t)=v_n b_\ell(t)/\|v\|_{\ell^2}$ 构造 $f\in C_c^\infty(U_p)$。每个单槽的 Fourier 主部精确为

$$
\int\log|\xi|\,|\widehat b_\ell(\xi)|^2\frac{d\xi}{2\pi}
=\log(1/\ell)+c_\varphi,
$$

其中 $c_\varphi$ 固定。式 (6)--(7) 给所有非算术交叉和 polar 为 $o(1)$；(3)--(4) 给该系数向量的算术 Rayleigh 值为 $\log N+O(1)$。因此

$$
Q_W^H[f]\le\log(1/\ell)-\log N+O(1),
$$

与 (8) 合并即证 (1)。$\square$

## 与补空间交叉的直接关系

式 (2) 的根槽 $n=1$ 与素数后代 $p^{1/2}\le q\le p^{3/2}$ 之间的行向量平方范数为

$$
\sum_{p^{1/2}\le q\le p^{3/2}\atop q\text{ prime}}
\frac{(\log q)^2}{q}=H^2+O(H),
$$

其中用 $\sum_{q\le x}(\log q)/q=\log x+O(1)$ 分部求和即可。这些后代位于远离根槽及其关于零点反射的内部位置，所以根槽到其正交补的**真实 Weil 形式交叉**可达 $(1+o(1))H$；式 (1) 证明这类整除星形交叉在整格联合压缩内可由 $4H$ 的逐槽成本支付。因此从 note 853 的孤立正谱隙接向全空间时，不能预设补空间交叉为 $o(H)$，必须保留整除图或等价的真实 Schur 响应。

本定理控制测度 $|U_p|\asymp p^{-2}$ 的特定对数格支撑，不能覆盖全部 $L^2(-H,H)$，也不估计 moving-$N$ Möbius signed covariance；它不推出 RH。
