# 缩窄 Farey 偶极消去异臂近共振，却提高二维负方向的对角代价（候选）

日期：2026-09-29。依赖 [note 780](../notes/780-all-prime-power-half-slots-give-nine-thirty-seconds-logarithmic-physical-inverse-response.md) 的任意槽宽自能量、[note 791](../notes/791-full-farey-dipole-arithmetic-graph-and-bounded-archimedean-compression.md) 的算术平移、[scratch 808](808-interior-farey-dipoles-have-a-sharp-growing-spectral-gap-candidate.md) 的内部正权 Rayleigh、[scratch 818](818-polynomial-exterior-farey-compression-is-a-signed-near-resonance-matrix-candidate.md) 的外槽压缩、[scratch 819](819-exterior-farey-forcing-has-an-exact-prime-divisor-norm-asymptotic-candidate.md) 的 forcing，以及 [scratch 820](820-exact-opposite-arm-exterior-resonances-have-vanishing-operator-norm-candidate.md)、[scratch 825](825-exterior-farey-forcing-needs-order-log-positive-prime-resonance-for-a-negative-two-plane-candidate.md) 的两个界。本结果只涉及显式有限维压缩，尚缺异源复核，留在 scratch。

## 命题

令奇素数 \(p\to\infty\)、\(H=\log p\)，固定 \(0<\beta<1/2\)，取
\[
B=\lfloor p^\beta\rfloor,
\qquad \delta_p=\frac1{4B^2p^2}.
\tag{1}
\]
把 note 791 式 (1) 中的半槽宽度 \(\Delta\) 换成 \(\delta_p\)，所得归一化旧奇偶极记为 \(w_y^{(\delta)}\)，其中 \(y=m/b\) 遍历 818 的外槽族 \(\mathcal Y_{p,B}\)。令 \(Z_{p,B}^{(\delta)}\) 为这些向量的张成空间，\(C^{\rm same}_{p,B}\) 为 818 式 (3) 的精确同臂矩阵。则外槽族仍是正交单位族，并且真实旧奇形式在它上面的压缩满足
\[
P_ZA_{p^2,-}P_Z\big|_Z
=d_{p,\delta}I-C^{\rm same}_{p,B}-N^0_{p,B}+E_{p,B}^{(\delta)},
\qquad \|N^0_{p,B}\|+\|E_{p,B}^{(\delta)}\|=o(1),
\tag{2}
\]
其中 \(N^0_{p,B}\) 正是 scratch 820 的精确 \(\delta=0\) 异臂矩阵，而
\[
d_{p,\delta}
=\log(1/\delta_p)+1-\gamma_E-\log\pi+o(1)
=(2+2\beta)H+O(1).
\tag{3}
\]
特别地，**整个**窄槽外空间有无条件的对数谱隙
\[
\boxed{\quad
\lambda_{\min}\!\left(P_ZA_{p^2,-}P_Z\big|_Z\right)
\ge(1-2\beta)H+O(1)>0
\quad(p\text{ 足够大}).
\quad}
\tag{4}
\]

再固定 \(0<\beta<\min\{\alpha,1-\alpha,1/3\}\)，取 \(Q=\lfloor p^\alpha\rfloor\)，并把 808--819 的内部正权向量与素数 forcing 方向都改用同一窄槽宽度，分别记为 \(v^{(\delta)}_{p,\alpha}\) 和
\(w^{(\delta)}=\sum_{y\in\mathcal Y_{p,B}}t_y^{\rm pr}w_y^{(\delta)}\)。其 forcing 系数 \(t_y^{\rm pr}\) 与 819 式 (2) 完全相同。记 \(J=J_{\rm diag}+J_{\rm pair}\)，则
\[
\begin{aligned}
\langle v^{(\delta)},A_{p^2,-}v^{(\delta)}\rangle
&=\left(\frac{\alpha^2(1+\beta-\alpha)}{\zeta(2)}+o(1)\right)H^3,\\
\langle v^{(\delta)},A_{p^2,-}w^{(\delta)}\rangle
&=-\|t^{\rm pr}\|^2+o(H^4),\\
\langle w^{(\delta)},A_{p^2,-}w^{(\delta)}\rangle
&\ge\bigl(2-\alpha-\beta+o(1)\bigr)H\|t^{\rm pr}\|^2.
\end{aligned}
\tag{5}
\]
由 825 的统一界，
\[
2-\alpha-\beta
-\frac{J}{\alpha^2(1+\beta-\alpha)}
>2\beta+\frac1{18}>0.
\tag{6}
\]
所以 \(A_{p^2,-}\) 在这个**指定的匹配窄槽二维平面**上对充分大的 \(p\) 严格正。槽宽变形虽以几何方式消去全部异臂非精确近共振，却不能用同一个 forcing 平面产生负方向。

## 异臂块为何只剩精确共振

若 \(y=m/b,y'=m'/b'\in\mathcal Y_{p,B}\) 与整数平移 \(n\) 有异臂重叠，写
\(d=nbb'-mm'\in\mathbb Z\)。因 \(mm'<B^2p^2\)，当 \(d\ne0\) 时
\[
\left|\log\frac n{yy'}\right|
=\left|\log\left(1+\frac d{mm'}\right)\right|
\ge\log\left(1+\frac1{B^2p^2}\right)
>\frac1{2B^2p^2}=2\delta_p
\tag{7}
\]
对充分大的 \(p\) 成立。归一化偶极自相关的支撑是 \(|s|<2\delta_p\)，故所有非零短移位**逐项为零**。\(d=0\) 时重叠系数为一，精确矩阵与槽宽无关，正是 820 的 \(N^0\)；该 note 给 \(\|N^0\|=o(1)\)。同臂非精确重叠在原来较宽的 818 槽上已不存在，缩窄后仍不存在。因此旧算术压缩恰为 \(-C^{\rm same}-N^0\)。

不同外槽中心的对数间距至少 \(\gg1/(pB^2)\)，与 \(\delta_p\) 的比为 \(O(p^{-1})\)；note 791 的偶极双零矩核界经中心排序给 Archimedean 非对角的绝对行和 \(O(p^{-3})\)。自反射臂相距至少 \(2\log(p/B)\)，其交叉亦为 \(o(1)\)。note 780 式 (4) 对任意长度为 \(\delta_p\) 的归一化单槽给精确自能量
\(\log(1/\delta_p)+1-\log(2\pi)-\gamma_E\)，相邻反号半槽的接触项为 \(\log2+o(1)\)，得到 (3)。单槽零均值使 polar 压缩随槽宽缩小而更小，故完整非算术误差 \(E^{(\delta)}\) 有 \(o(1)\) 算子范数。这证明 (2)。

## 全外槽谱隙与二维代价

对正权 \(h_{m/b}=(mb)^{-1/2}\)，同臂算术行比至多
\[
S_B(m)+S_B(b),
\qquad S_B(z)=\sum_{\substack{n\le B\\n\ {m prime\ power}}}
\frac{\Lambda(n)(n,z)}n.
\]
825 式 (5) 的逐素数幂估计给
\[
S_B(m)+S_B(b)
\le\log m+\log b+2\log B+O(1)
\le(1+4\beta)H+O(1).
\tag{8}
\]
非负对称矩阵的正权 Schur 检验于是给
\(\|C^{\rm same}\|\le(1+4\beta)H+O(1)\)。结合 (2)--(3) 得 (4)。

内部 Farey 源族的全部精确算术边不随槽宽改变；较窄槽只减少非精确 Archimedean 与 polar 误差。808 的原宽度内部能量为
\(\alpha^2(1-\alpha)H^3/\zeta(2)+o(H^3)\)，而新自对角比原自对角增加
\(2\log B+O(1)=2\beta H+O(1)\)。内部向量范数为
\(\alpha^2H^2/(2\zeta(2))+o(H^2)\)，故新内部能量恰给 (5) 第一式。

源与目标之间的有理中心间距保证只有整槽重合的算术边；等宽缩窄后，其归一化重叠仍为一。因此 819 的逐槽 forcing 公式、\(\|t^{\rm pr}\|^2=(J/\zeta(2)+o(1))H^4\) 以及其非算术投影误差界原样有效，得 (5) 第二式。目标同臂矩阵在 forcing 支撑上的界仍为 825 式 (6) 的
\((\alpha+3\beta)H+O(1)\)；(2) 已将整个异臂块支付为 \(o(1)\)，故 (5) 第三式成立。

令 \(\rho=J/[\alpha^2(1-\alpha)]\) 如 825，并置
\(\rho_\delta=J/[\alpha^2(1+\beta-\alpha)]<\rho\)。825 式 (3b) 给
\(2-\alpha-3\beta-\rho>1/18\)，于是
\(2-\alpha-\beta-\rho_\delta
=(2-\alpha-3\beta-\rho)+2\beta+(\rho-\rho_\delta)
>2\beta+1/18\)，即 (6)。源对角严格正，且 (5)--(6) 使二维 Gram 行列式严格正，完成证明。\(\square\)

## 保留原宽源槽也不能恢复这个二维方向

令 \(\Delta_p=\frac12\log(1+p^{-2})\)，仅把源改回原宽度的
\(v^{(\Delta)}_{p,\alpha}\)，目标仍用上面的窄槽 \(w^{(\delta)}\)。两个同中心、归一化的双半槽满足精确重叠
\[
\langle h_{\Delta_p},h_{\delta_p}\rangle
=\sqrt{\delta_p/\Delta_p}
=\frac{1+o(1)}{\sqrt2 B}.
\tag{9}
\]
非整槽源--目标算术重叠仍被 817 的有理间距排除。两个偶极都零均值，且其物理中心相距 \(\gg H\)；相离核的双重分部积分把每个 Archimedean 交叉界改为
\(O((\Delta_p\delta_p)^{3/2}/H^3)\)，即 817 同宽界的 \((\delta_p/\Delta_p)^{3/2}\) 倍。polar 目标投影也随窄槽缩小，故非算术投影仍为 \(o(1)\) 范数。819 的实际 forcing 满足 \(\|t\|=O(H^2)\)，所以更强地有
\[
\|P_{Z^{(\delta)}}A_{p^2,-}v^{(\Delta)}\|
\le\sqrt{\delta_p/\Delta_p}\,\|t\|+o(1)
=O(H^2/B)+o(1)=o(1).
\tag{10}
\]
特别地，
\[
\langle v^{(\Delta)},A_{p^2,-}w^{(\delta)}\rangle
=-\sqrt{\delta_p/\Delta_p}\,\|t^{\rm pr}\|^2+o(H^2)
=o(H^2).
\tag{11}
\]
原宽源对角为正的 \(\asymp H^3\)，而 (5) 的窄目标对角为正的 \(\asymp H^5\)；(11) 的平方低于二者乘积。因此这个混合宽度的指定二维平面也最终严格正。这里仅比较一个自然的混合宽度方向，不推断整个源--目标块的算子范数。

## 边界

式 (4) 是窄槽**主压缩**的谱隙，不控制其无限维正交补。二维结论只关闭“缩窄槽宽以消去异臂有符号门，并沿用 forcing 方向”这一构造；没有排除其他形状、其他向量或完整旧奇算子的负谱，更不判定全尺度局部 Weil 正性、moving-\(N\) Möbius 协方差或 RH。
