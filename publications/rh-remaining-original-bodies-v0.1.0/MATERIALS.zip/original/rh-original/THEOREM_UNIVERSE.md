# 黎曼猜想定理宇宙

版本：2026-08-16。文献边界：
[`ResearchLibrary/literature-matrix.csv`](../ResearchLibrary/projects/riemann-alternative-routes-2026-08-12/literature-matrix.csv)
中的 79 条 admitted records；本文件只保留会改变证明决策的定理节点。

## 0. 语义

\[
\mathcal U=(V,E,\tau,\sigma),
\tag{U0}
\]

其中

\[
\tau(v)\in
\{\mathrm{Thm},\mathrm{Id},\mathrm{Cond},\mathrm{Open},\mathrm{NoGo},\mathrm{Num}\},
\quad
\sigma(v)=\text{结论的 }N\text{-幂/对数/参数域}.
\tag{U1}
\]

边分为

\[
E\in\{\Rightarrow,\Leftrightarrow,\text{reduces-to},\text{fails-under},\text{controls-only}\}.
\tag{U2}
\]

纳入规则：节点必须提供新机制、精确恒等式、不同估计制度、反例或决定性适用边界。停止规则：
新增文献不再增加上述任一项。故“定理宇宙”是问题相关的概念闭包，不是不可穷尽的数学全集。

## 1. 外层宇宙：RH 的历史坐标

| ID | 坐标 | 已知逻辑 | 当前边界 | 状态 |
|---|---|---|---|---|
| W | Weil 显式公式正性 | 全测试类正性 \(\Leftrightarrow RH\) | 局部压缩正性不能自动传到全尺度 | Thm |
| NB | Nyman--Beurling | \(\chi\in\overline{\mathrm{span}}\{\rho(1/(kx))\}\Leftrightarrow RH\) | compact window 对逃逸尾失明 | Thm |
| BD | Báez--Duarte 整数 dilation | 整数生成集已足够 | 历史自然系数在每个匹配窗口精确为零，却不全局收敛 | Thm + NoGo |
| FF | Franel--Landau/Farey | Farey discrepancy 平方根尺度 \(\Leftrightarrow RH\) | 正 gcd 核只命中 complete-period 分量 | Thm + NoGo |
| DN | de Bruijn--Newman | Rodgers--Tao: \(\Lambda_{DN}\ge0\)；RH \(\Leftrightarrow\Lambda_{DN}=0\) | 剩余是排除正碰撞时间 | Thm + Open |
| JP | Jensen 多项式 | 每个固定次数最终双曲；有 growing wedge | 高次数/低 shift 区仍等同全局困难 | Thm + NoGo |
| SK | screw/Weil kernel | 全局核正性重写 Weil 判据 | zero-shift/global injectivity 未由局部标量正性推出 | Thm + Open |
| PF | Schoenberg \(PF_\infty\) | 提供单侧全正性坐标 | 尚缺从算术因果近似到全 \(PF_\infty\) 的闭合桥 | Cond/Open |
| LK | Li--Keiper | 全部 Li 系数非负 \(\Leftrightarrow RH\) | detector；没有较弱的生成机制 | Thm/Detector |
| HP | Hilbert--Pólya/谱行列式 | 若构造正确自伴算子则推出 RH | 当前模型只给有限/渐近谱信息 | Cond/Open |

```mermaid
flowchart LR
  RH((RH))
  W["Weil positivity"] <--> RH
  NB["Nyman–Beurling"] <--> RH
  FF["Farey–Franel scale"] <--> RH
  DN["Λ_DN=0"] <--> RH
  LK["Li coefficients ≥0"] <--> RH
  BD["integer dilations"] --> NB
  PF["one-sided PF∞"] -. missing bridge .-> W
  SK["screw kernel"] --> W
  HP["selfadjoint spectrum"] -. construction .-> RH
  JP["all Jensen sectors"] -. unclosed low-shift sector .-> RH
```

### 路线裁决

\[
\boxed{
\text{当前主线}=NB/BD\to\text{Selberg taper}\to\text{首 reciprocal shell}.
}
\tag{U3}
\]

理由：这是唯一已经同时具备

\[
\text{历史自然系数}+\text{有限恒等式}+\text{离线零定量放大}+\text{直接数值观测}
\tag{U4}
\]

的路线。其余路线保留为交叉坐标，不作为当前证明主链。

## 2. 主链：从 Selberg shell 到唯一低模原子

| ID | 定理/恒等式 | 精确量纲 | 逻辑状态 | 来源 |
|---|---|---:|---|---|
| S1 | Selberg 首壳有限公式 | \(D_N=A_Ny+M-\{\Psi+J\}/\log N\) | proved | note 064 |
| S2 | 离线零点点态放大 | \(\mathcal E_{N_j}\gg N_j^{2\beta-1}/\log^2N_j\) | proved | note 064 |
| S3 | 离线零点 dyadic 放大 | \(\sum I_N\gg Y^{2\beta+2}\log^{2q-4}Y\) | proved | note 074 |
| C1 | centered-shell 判据 | \(\sum\mathcal J_N\ll Y^{3+\varepsilon}\Rightarrow RH\) | proved | note 080 |
| BV1 | Barban--Vehov/Graham jump energy | \(\|r\|_2^2\ll N/\log N\) | proved/history | notes 065,079 |
| R1 | finite Ramanujan 展开 | \(V_N(n)=\sum_{q\le N}(A_q/q)c_q(n)\) | proved | note 078 |
| R2 | primitive packet | \(\Delta P_q=-c_q/q\) | proved | note 078 |
| R3 | complete-period diagonal | \(NQ_2(N)\ll N^2/\log^2N\) | proved | note 078 |
| D1 | path DST | \(E^{cen}=\sum|\langle r,u_k\rangle|^2/\sigma_k^2\) | proved | note 079 |
| D2 | high-mode disposal | \(k>K_N\Rightarrow E\ll N^2\), \(K_N=\sqrt{N/\log N}\) | proved | note 079 |
| D3 | low-mode quadrature identity | \(\mathcal R_{N,k}=\sum_d\mu(d)\log(N/d)(Q_N/d-Q_{N/d})\) | proved | note 079 |
| D4 | unique sufficient atom | \(\sum_{N\asymp Y}\sum_{k\le K_N}|\mathcal R|^2/k^2\ll Y^{2+\varepsilon}\log^2Y\) | open; implies RH | note 080 |
| D5 | offline-zero localization | D4 左边 \(\gg Y^{2\beta+1}\log^{2q-2}Y\) | proved conditional on off-line zero | note 080 |
| F1 | fixed-mode Mellin multiplier | \([c_k/(s-1)^2-W_k']/\zeta+W_k\zeta'/\zeta+W_k'\) | proved | note 081 |
| F2 | fixed-mode visibility | 每个零点被某个固定 \(k(\rho)\) 的极点看见 | proved | note 081 |
| F3 | fixed-sine family criterion | \(\forall k\) 固定，\(\sum_N|\mathcal R_{N,k}|^2\ll Y^{2+\varepsilon}\Rightarrow RH\) | open premise; implication proved | note 081 |
| N1 | fixed-mode critical scaling | \(M_{2,k}(Y)=Y^{1+o(1)}\) for tested \(k\le16\) | numerical only | note 082 |
| F4 | two-mode determinant implication | \(D=C_1W_2-C_2W_1\ne0\Rightarrow\{1,2\}\) 检出全部零 | proved | note 083 |
| F5 | two-mode zero-free theorem | \(D(s)\ne0\) on \(1/2\le\Re s\le1,\ s\ne1\) | proved; Arb-assisted | note 086 |
| F6 | two-mode RH criterion | \(\sum_N(|\mathcal R_{N,1}|^2+|\mathcal R_{N,2}|^2)\ll Y^{2+\varepsilon}\Rightarrow RH\) | open premise; implication proved | note 086 |
| F7 | two-mode equivalence | RH \(\Leftrightarrow\) F6 的 dyadic mean-square premise | proved | note 087 |
| F8 | finite pure-even detector | \(\exists E\subset2\mathbb N\) finite, \(\operatorname{rank}(W_k,W_k')_{k\in E}=2\) throughout the strip | proved | note 088 |
| F9 | finite even-mode equivalence | RH \(\Leftrightarrow\sum_{k\in E}\sum_N|\mathcal R_{N,k}|^2\ll Y^{2+\varepsilon}\) for some finite even \(E\) | proved equivalence; open premise | note 088 |
| G1 | fixed-k exact Gram | \(\sum_N|\mathcal R|^2=\sum_{d,e}\mu(d)\mu(e)\mathfrak K(d,e)\) | identity | note 084 |
| G2 | divisor truncation | \(d\le Y^{3/4}\) part \(\ll Y^2\log^2Y\); controlling the complementary \(\Delta\)-sum is sufficient | proved | note 084 |
| G3a | high-divisor \(\Delta\)-atom | \(\sum_N|H_{N,k}^{>Y^{3/4}}|^2\ll Y^{2+\varepsilon}\), \(k=1,2\) | open | note 084 |
| G3b | complete-product atom | complete \(g_N\) off-diagonal \(|\mathcal O_k(Y)|\ll Y^{2+\varepsilon}\), \(k=1,2\) | open | note 084 |
| G4 | \(k=1,a=2\) cell Mellin detector | \(\mathrm{RH}\iff\sum_{N\asymp Y}|T_N|^2\ll_\varepsilon Y^{2+\varepsilon}\) | proved; Arb-assisted detector | note 094 |
| G5 | \(k=1,a=2\) moving-scale covariance gate | \(\mathrm{RH}\iff\mathcal C_F(Y)=O_\varepsilon(Y^{2+\varepsilon})\) | proved identity; bound open | note 095 |
| G6 | finite-dilation endpoint rigidity | \(\sum_jc_jF(t/\lambda_j)\) jump-free \(\Leftrightarrow c_j=0\ \forall j\) | proved | note 096 |
| H1 | Hardy-amalgam equivalence | dyadic \(Y^{2+\varepsilon}\iff F_k\in\cap_{\delta>0}H^2(\Re s>1/2+\delta)\) | proved | note 085 |
| H2 | covariant derivative | \(G_k=H_k'\), \(H_k=W_k(\zeta-1)-c_k/(s-1)\) entire | proved | note 085 |

```mermaid
flowchart TD
  Z["ζ(ρ)=0, β>1/2"] --> S3["dyadic Mellin mass"]
  S3 --> C1["centered shell mass"]
  C1 --> D1["path DST"]
  BV1["H⁰ jump bound"] --> D2["high modes paid"]
  D1 --> D2
  D1 --> D3["low-mode quadrature defect"]
  D2 --> D4["only K≈√(N/logN) modes remain"]
  D3 --> D4
  D4 --> RH((RH))
  F1["fixed-k Mellin multiplier"] --> F2["some fixed k detects ρ"]
  F2 --> F3["scalar cutoff means"]
  F3 --> RH
  N1["fixed-k numerics: slope ≈1"] -. "supports premise" .-> F3
  F5["D zero-free on closed half-strip"] --> F4["k=1,2 universal detector"]
  F4 --> F6["two scalar cutoff means"]
  F6 --> RH
  Gamma["zero mode Γ_N"] -. "probe has mean 0; deleted" .-> RH
```

## 3. 算术对象字典

| 对象 | 定义 | 角色 | 不可丢失结构 |
|---|---|---|---|
| \(\lambda_{d,N}\) | \(\mu(d)\log(N/d)/\log N\) | Selberg taper | cutoff 与 Möbius 符号 |
| \(V_N(n)\) | \(\sum_{d\mid n,d\le N}\lambda_{d,N}\) | jump/Barban--Vehov 权 | \(N<n<2N\) 时含 \(\Lambda+\mu\log(n/N)\) |
| \(D_N(y)\) | \(1+\sum\lambda_{d,N}\{y/d\}\) | 首壳 residual | reciprocal dilation |
| \(A_{q,N}\) | \(\mu(q)\check m_q(N/q)/\log N\) | finite Ramanujan 坐标 | 特殊 Möbius 向量 |
| \(P_q\) | primitive Ramanujan packet | \(H^{-1}\) 原函数 | incomplete interval alignment |
| \(r_j\) | \(A_{1,N}-V_N(N+j)\) | path edge | parity-sensitive signs |
| \(\mathcal R_{N,k}\) | \(L\sum r_j\sin(\pi kj/N)\) | unresolved low mode | affine--\(\Lambda\)--Möbius 联合消去 |
| \(\mathcal H_N\) | \(\sum_{k\le K_N}|\mathcal R_{N,k}|^2/k^2\) | growing-mode RH-sufficient 原子 | cutoff \(N\) 均方 |
| \(M_{2,k}(Y)\) | \(Y^{-1}\sum_{N\asymp Y}|\mathcal R_{N,k}|^2\) | 当前最小标量原子 | 必须保留 prime--Möbius 联合消去 |

## 4. 历史定理簇：输入、到达点、缺口

| Cluster | 最强可用输入 | 代入当前原子的最好尺度 | 目标 | 判定 |
|---|---|---:|---:|---|
| Selberg/Barban--Vehov/Graham | jump \(H^0\) | \(E^{cen}\ll N^3/\log N\) | \(N^2\) | 差 \(N/\log N\)；但支付高模 |
| Davenport 1937 II | \(\sup_\alpha|\sum\mu e(n\alpha)|\ll_A N\log^{-A}N\) | \(\mathcal H_N\ll N^2\log^{-A}N\) | \(N^{1+\varepsilon}\log^2N\) | 差一幂 |
| Wei Zhang 2022 | 条件 uniform \(N^{3/4+\varepsilon}\) | 逐模仍至少 \(N^{3/2+\varepsilon}\) 平方 | \(N^{1+\varepsilon}\) | 不够；且条件接近零点输入 |
| Matomäki--Radziwiłł--Tao/Menon | moving interval 平均相对 \(o(1)\)/对数节省 | 原始平方约 \(N^2o(1)\) | \(N^{1+\varepsilon}\) | 差一幂 |
| Davenport--Halberstam/large sieve | well-spaced-point \(N+\delta^{-1}\) | moving frequencies spacing \(Y^{-2}\Rightarrow Y^3\) total | \(Y^{2+\varepsilon}\) | 通用算子差一幂 |
| Hooley Möbius--BDH | \(\sum_{q\le Q}\sum_a|M(x;q,a)|^2\sim(6/\pi^2)xQ\) | 量纲足够 | moving \(N\), divisor-position \(\mu(d)\) | 平均变量错位 |
| BDH/BFI dispersion | progression/modulus average；well-factorable \(q\le x^{4/7-\eta}\) | 量纲潜在足够 | \(d\asymp N\), residue \(-N\) moving | 参数域失配 |
| Gallagher/Bombieri--Iwaniec | hybrid/double large sieve | sampling moving \(\log N\) 或 near-collisions 仍给 \(Y^3\) | \(Y^{2+\varepsilon}\) | 通用估计差一幂 |
| Motohashi Ramanujan large sieve | length + modulus\(^2\) | \(Q=N\Rightarrow N^2\) operator scale | \(N\) | dense modulus barrier |
| Ramaré Farey spectrum | equal-weight moments/eigenvalues | generic \(N+Q^2\) | special Möbius vector | 权不匹配 |
| Coppola--Murty | exact finite Ramanujan coefficients | 提供坐标，不给 primitive bound | — | used identity only |
| Alterman continuous sieve | complete \(H^0\) lcm density | \(Q_1\sim1/\log N\) | incomplete \(H^{-1}\) | 控制错 Sobolev 层 |
| Dedekind/cotangent reciprocity | fixed complete modulus 重排 | exact boundary dictionary | moving balanced mean | 无 aggregate cancellation |
| Bettin--Chandee/Maier--Rassias | unbalanced Kloosterman/cotangent power saving | 主质量区外 | balanced \(d,e\asymp N\) | 参数域失配 |
| Letendre truncation moments | 全 \(z\)-平均 | 首壳 \(z\ge n/2\) 时恒等 \(-\mu(n)\) | cutoff cancellation | 在当前区域退化 |
| Nazarov--Turán | 局部到全局，常数指数依赖项数 | \(\exp(cN)\) | uniform observability | 明确失败 |
| Kanemitsu--Yoshimoto/Franel | complete gcd positive form | 已低阶的 \(Q_2\) | incomplete defect | 命中错误分量 |

## 5. No-go 宇宙

| ID | 被关闭的捷径 | 严格原因 | 可否复活 |
|---|---|---|---|
| X1 | local Weil compression \(\Rightarrow\) finite Nyman Gram | 非零有限 Nyman 向量无有限 Paley--Wiener 尺度 | 只能窗口化并追逃逸尾 |
| X2 | compact residual \(\to0\Rightarrow\) global NB | 历史 \(B_N\) 在匹配窗口已精确为零但全局失败 | 否；需缩放尾 |
| X3 | complete lcm/gcd 正性控制 shell | incomplete boundary 不由 gcd Gram 决定 | 否；需 signed boundary |
| X4 | fixed-gcd \(1/\zeta(s+t)\) anti-diagonal | gcd completion 逐素数精确消去该因子 | 否；该路线错误 |
| X5 | sawtooth cell 端点望远镜 | 共享端点同号相加 \(-A/2-A/2\) | 否 |
| X6 | positivity/耗散 | shell increment 有 parity 双符号 | 需 sign-sensitive bilinear input |
| X7 | fixed-band observability | reciprocal-grid 超振荡；Nazarov 常数指数坏 | 否 |
| X8 | generic primitive frame | primes \(p\in[7N/8,N]\) 同向反例，放大 \(N/\log N\) | 只可能用特殊 Möbius 向量 |
| X9 | circular DFT 删除 affine mode | 闭环缺口精确把该模带回 | 必须用 path DST |
| X10 | 单独估计 \(\Lambda-1\) | 逆差分范数等于 centered PNT error | 已接近 RH 强度 |
| X11 | 单独控制 \(\Gamma_N\) 才能探测零点 | 零点探针 \(W(0)=0\)，严格看不见零模 | 已由 note 080 删除 |
| X12 | 通用 large sieve 直接证明 fixed-mode 均方 | \(\alpha_N=k/(2N)\) 的间距为 \(\asymp Y^{-2}\)，且 \(k=1\) 达到通用算子范数 | 只能利用 Möbius--prime 联合结构 |
| X13 | 标准 Hardy/Bergman 正性直接给临界逐壳界 | 无权 \(A^2_0\) 强一调和对数；临界权使 Green 公式重现无符号项 | 需逐窗/边界项新控制 |

## 6. 当前可攻边

定理 D4 的方括号写为

\[
\Delta_{N,d,k}:=
\frac1d\sum_{j=1}^{N-1}\sin\frac{\pi kj}{N}
-\sum_{N<dm<2N}\sin\frac{\pi k(dm-N)}N.
\tag{U5}
\]

候选机制只有四类：

| Attack | 所需新命题 | 最便宜判别 | 当前优先级 |
|---|---|---|---|
| A | cutoff-\(N\) divisor switching | 对 \(k=1,2\) 控制 \(H_{N,k}^{>Y^{3/4}}\)；\(k=1\) 保留 global--local 联合项 | 截断 \(\Delta\)-Gram | 1 |
| B | \(k\)-平均正交 | 对 \(k^{-2}\) 权直接做双大筛，保留特殊系数 | 检查 \(k=1\) 是否留下超临界块 | 2 |
| C | 多尺度 Euler--Maclaurin | 小 \(d\) 求积误差显式，high \(d\) 转 weighted Mertens | 求最优 split \(d=N/K\) | 3 |
| D | Mellin/zero-explicit cancellation | 联合 \(B_N-1,\mathcal E_{\Lambda},M\)，不分项 | 算出固定 \(k\) Mellin multiplier 的零点阶 | 4 |

当前选择：A。note 086 已把 A 从逐个固定 \(k\) 进一步降为只需 \(k=1,2\) 的两个标量
cutoff 均方。历史
well-spaced-point、hybrid/double large sieve 对任意系数仍停在总量 \(Y^3\)；note 082 则显示
目标的 \(Y^{2+o(1)}\) 尺度伴随 prime--Möbius 强负协方差。因此 A 的精确含义是
Möbius-specific moving-dilation/cutoff Gram，而不是再套一个通用大筛。note 084 的两种坐标必须
分开：high-divisor \(\Delta\)-Gram 与完整 \(g_N\) product off-diagonal 是替代目标，不能同时
删除低除数与 product diagonal。

## 7. 证明完成条件

```mermaid
flowchart TD
  A["展开 k=1,2 cutoff Gram"] --> B{"off-diagonal kernel 有 Y^{-1} 正交?"}
  B -->|yes| C["合并两个模"]
  B -->|no| D["构造 Möbius-compatible obstruction"]
  C --> E["D4"]
  E --> RH((RH))
  D --> F["关闭 A；转 B/C/D"]
```

成功不是新增记录数，而是以下任一项：

\[
\boxed{
\begin{array}{ll}
(i)&\text{证明 D4；}\\
(ii)&\text{证明一个历史定理严格蕴含 D4；}\\
(iii)&\text{给出 A 的严格反例/等强性并转到下一节点；}\\
(iv)&\text{发现比 D4 更弱且仍推出 RH 的可证量。}
\end{array}}
\tag{U6}
\]

当前已四次实现 (iv)：note 080 删除零模 \(\Gamma_N\)，note 081 把增长的低模族降为逐个
固定 \(k\)，note 083 把 universal two-mode 问题压成紧集无零证书，note 086 又严格证明该
证书无零，故现在只需 \(k=1,2\) 的算术均方。该前提仍未证明，故 RH 尚未证明。

## 8. 路线状态叠加层

\[
\begin{aligned}
\mathrm{Active}&=\{064_{\rm Selberg},074,078,079,080,081,082,083,084,085,086,087,088,089,090,273,274,275_{\rm Local\text{-}Weil}\},\\
\mathrm{Support}&=\{\text{精确算子接口、Ramanujan/DST 恒等式、历史均方输入}\},\\
\mathrm{Closed}&=\{\text{有严格反例或量纲障碍的捷径}\},\\
\mathrm{Archive}&=\{\text{被更强区间定理或后续修正完全吸收的节点}\}.
\end{aligned}
\tag{U7}
\]

- Local-Weil 线的当前严格峰值是 note 275：\(A_a>0\) 于
  \(0<a\le\frac12\log11\)。notes 059--061 只反驳若干有限维下模型，不推出真实算子不定。
- notes 273--274 给出端点 \(a=\frac12\log11\) 的 even/odd \(P_{400}\) joint-Schur
  证书；note 275 通过 note 089 的 cutoff-free Loewner--Parseval 尾支付把两个有限
  Schur 证书升级为完整两个 parity 算子正性。
- notes 022、025、028、054--056、064、068 的区间正性均仍真，但已被 note 089 的更大区间吸收。
- notes 041--043 给出一般核/变分/延拓捷径的严格反例；notes 044--053 保留为 averaged
  Pohozaev 支撑链，尚未排除实际零模。
- Nyman--Selberg 线中，064、074、078--086 是当前活跃链；067 的固定-gcd 反对角因子已由
  069 的完整 gcd completion 修正；070、072、073、076、077 分别关闭望远镜、Type-II、Farey、
  普通 cutoff-Fourier 与固定频带可观测性捷径。

## 9. 项目全部 notes 知识索引（96/96）

以下不是按编号取样，而是当前 notes/ 的完整清单。每项保留其已证结论、严格反例或证据边界的合并摘要；承重公式仍以链接全文为准。

### 000--020：算子基础、谱流、prime-free 与首 prime bands

- [接入时的数学边界](notes/000-cutover-2026-08-11.md) — 对引用对话的有界重述；其中未核验主张不构成事实或证明。
- [局部谱底与第一次退化的文献归约](notes/001-local-weil-first-degeneration-literature-reduction.md) — 基于 Suzuki 2026 全文核对后的严格入口与定义域边界。
- [第一次退化及邻接机制的前沿文献图](notes/002-first-degeneration-frontier-map.md) — 截至 2026-08-11 的机制簇、路线关系与可迁移接口。
- [零延拓与全谱单调性](notes/003-zero-extension-and-full-spectrum-monotonicity.md) — 证明完整闭形式定义域嵌套、全部本征值单调不增及负指标单调不减。
- [与 logarithmic Laplacian 的精确归一化](notes/004-exact-logarithmic-laplacian-normalization.md) — 识别 \(D(Q_W^a)=H((-a,a))\)，并给出首次退化零模态的完整弱平移方程。
- [绝对值收缩的显式反例](notes/005-beurling-deny-obstruction-from-sign-changing-kernel.md) — 由非对角核变号证明 \(a>1/6\) 时标准 positivity-preserving 基态路线失效。
- [全谱连续性与 spectral flow](notes/006-norm-resolvent-continuity-and-spectral-flow.md) — 在固定区间建立 norm-resolvent 连续族，证明全部本征值连续，并把 spectral flow 识别为负指标差。
- [极点秩二与奇偶秩一归约路线](notes/006-rank-one-sector-reduction-route.md) — 记录下一阶段的标量 Schur 补主线、约化形式的决定性正性检查及证据边界。
- [M2-R1 finite-shift 正则性定理](notes/007-M2R1-finite-shift-Linfinity-hinge.md) — 把成对 Dirac shifts 改写成正离散跳跃项，证明零模态有界、连续并满足 \(\ell(d)^{1/2}\) 边界阶上界。
- [极点项的签名 \((1,1)\) 分解与约化 Markov 形式](notes/007-indefinite-polar-splitting-and-reduced-markov-form.md) — 纠正正秩二猜想，证明奇扇区为负秩一，并建立约化形式的全尺度绝对值收缩。
- [Collar UCP 与严格域单调归约](notes/008-collar-ucp-and-strict-domain-monotonicity.md) — 证明谱底平台等价于较大区间存在 collar 支撑基态，并把唯一零尺度与立即负穿越归约到 ground-state collar UCP。
- [约化算子的严格正基态与奇扇区谱隙](notes/008-reduced-ground-state-and-odd-spectral-gap.md) — 由纯跳 Dirichlet form 的不可约性证明基态简单、几乎处处严格正且为偶函数，并得到全尺度严格奇扇区谱隙。
- [外侧 logarithmic flux 与平台障碍](notes/009-exterior-log-boundary-flux-obstruction.md) — 计算非零 \(\ell(d)^{1/2}\) 边界系数产生的外侧发散，证明任何谱底平台都强制两个端点主系数为零并满足 Cauchy--Dini 抵消。
- [边界振荡抵消模型](notes/010-boundary-cancellation-model.md) — 构造能量域内达到最优边界振幅但外侧 flux 有界的变号模型，证明边界上界本身不能排除平台。
- [Prime-free collar UCP](notes/011-prime-free-collar-ucp.md) — 用 Archimedean 核的完备指数矩证明无平移空窗上的 UCP，并无条件得到 \(a<\frac12\log2\) 时对任意扩域的严格谱底下降。
- [第一次退化的秩一惯性分类](notes/012-first-degeneration-rank-one-inertia-dichotomy.md) — 完整区分奇偶扇区的可见 Schur 零模态与不可见约化零核，并用 positivity-improving 四维模型证明现有抽象输入不足以排除后者。
- [约化偶谱的显式负阈值](notes/013-explicit-negative-reduced-even-spectrum.md) — 用偶常函数和纯有理误差界证明 \(\mu_1(M_a^+)<-166951/5990400\) 对全部 \(a\ge1/8\) 成立，关闭约化偶谱全尺度非负路线。
- [Prime-free 奇扇区无不可见零核](notes/014-prime-free-odd-schur-reduction.md) — 把奇函数折叠到半区间，证明严格正核差产生 positivity-improving 半群，并在 \(0<a\le\frac12\log2\) 与 \(A_a^-\succeq0\) 下推出 \(M_a^->0\)，从而把奇零模态严格化为单一 Schur 等号。
- [Prime-free 全谱严格尺度流](notes/015-prime-free-strict-spectral-scale-flow.md) — 证明 digamma multiplier 的尺度交换子严格正且有界，从而得到全部约化本征值及奇偶扇区本征值在 \(0<a\le\frac12\log2\) 上严格下降，并给出每条解析谱支的严格负导数。
- [Prime-free 奇扇区的负 killing 障碍与 supersolution 归约](notes/016-odd-killing-obstruction-and-supersolution-reduction.md) — 给出完整奇半区正跳核与 killing 势，构造 \(a=1/3\) 的显式负势反例关闭点态路线，并把全 prime-free 奇正性压缩为端点 \(a=\frac12\log2\) 上的一个 ground-state/Barta 证书。
- [Prime-free 奇扇区的 Yukawa 分解与显式正谱隙](notes/017-prime-free-odd-yukawa-gap.md) — 将 digamma 乘子分为正 Yukawa 项，用 15 个一维 Robin 根与 Arb 有限证书证明 \(A_a^-\succeq0.0102I\) 于 \(0<a\le\frac12\log2\)，从而完全排除 prime-free 奇退化并证明奇 Schur 量严格为正。
- [Prime-free 偶扇区的 Yukawa--Schur 显式谱隙](notes/018-prime-free-even-yukawa-schur-gap.md) — 在 Neumann 基中把偶算子写成一个单负对角算子加正边界秩和，用 20 维 Arb Schur 惯性证书证明 \(A_a^+\succeq1/2000\)，并与奇谱隙合并得到整个 prime-free 局部 Weil 算子一致严格为正。
- [首个 prime band 的精确反射--Schur 正性延伸](notes/019-first-prime-band-exact-reflection-schur-gap.md) — 把唯一活跃的 \(n=2\) shift 精确写成边缘 collar 反射 \(\mp(\log2/\sqrt2)J\)，并以 Yukawa--Schur/Arb 证书证明 \(A_a\succeq5\times10^{-5}I\) 于全部 \(0<a\le0.36\)。
- [首个 prime band 的正谱隙推进至 \(a=2/5\)](notes/020-first-prime-band-gap-to-two-fifths.md) — 扩大精确反射--Yukawa--Schur 证书，证明 \(A_a^+\succeq10^{-6}I\)、\(A_a^-\succeq10^{-4}I\)，从而 \(A_a\succeq10^{-6}I\) 于全部 \(0<a\le2/5\)。

### 021--040：有限秩 Schur、active-prime 图、frame 与 cyclicity

- [Robin deficit 全尾的固定秩归约](notes/021-fixed-rank-robin-deficit-tail-reduction.md) — 证明无限 Yukawa deficit 尾可由固定的 \(m(s+1)\) 维聚合空间和 \(O(K^{-s-3})\) 的显式标量代价控制，消除 Schur 维数随尾截断增长的障碍。
- [首个 prime activation band 的完整严格正性](notes/022-first-prime-band-complete-strict-positivity.md) — 以固定秩 Robin-tail、解析 Arb 矩阵和 dyadic Householder--Cholesky 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log3\)，从而严格排除首次退化发生在整个 \(n=2\) activation band 内。
- [两个素数平移的有限轨道分解](notes/023-two-prime-partial-reflection-orbit-reduction.md) — 在 \(\log3/2\le a\le\log2\) 上把 \(J_{\log2},J_{\log3}\) 的联合轨道严格降为至多四点链，并给出精确纤维逆。
- [Yukawa 谱截断下模型的单调极限与 frame 铰链](notes/024-monotone-yukawa-lower-models-and-frame-hinge.md) — 证明 baseline 模数下模型单调收敛到完整算子，排除算子范数与粗 coercivity 捷径，并把端点正性压缩为统一 Schur/frame 不等式。
- [两素数反射带的完整严格正性推进至 \(a=\log2\)](notes/025-two-prime-band-complete-strict-positivity-to-log2.md) — 把 Archimedean 部分写成 Fourier 对角加正 Yukawa atoms，精确保留 \(n=2,3\) 的联合反射与极点秩一项，并以有限 Feshbach--Arb 证书证明 \(A_a>0\) 于全部 \(0<a\le\log2\)。
- [活跃 prime shifts 的精确奇偶半区压缩](notes/026-exact-parity-compression-of-active-prime-shifts.md) — 对任意 \(d=\log n\) 严格证明半区算子为 \(-\alpha_n(S_d+S_d^*)-\sigma\alpha_nJ_d\)，核准 support、奇偶符号和 prime-power 系数，并识别首个 mixed chamber 的最小接口 \(S_2,J_2,J_3\)。
- [Active-prime graph 的无限稠密轨道反例](notes/027-active-prime-graph-infinite-dense-orbit.md) — 证明在 \(a\ge\log6\) 时，\(\log2,\log3\) translation edges 已包含一个无理圆周旋转，故联合 component 可以无限且稠密；全尺度正确替代仅为 locally finite、至多可数的 orbit graph。
- [首个 mixed chamber 的完整严格正性](notes/028-first-mixed-band-complete-strict-positivity-to-log5-half.md) — 精确保留 \(n=2\) 的 translation--reflection、\(n=3,4\) 的 reflections、有限正 Yukawa atoms 与极点秩一项，以 Arb--Feshbach 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log5\)。
- [Active-prime orbit 坐标与 resolvent 衰减](notes/029-active-prime-orbit-coordinates-and-resolvent-decay.md) — 把固定尺度 orbit 坐标化为两层 \(\mathbf Z^r\)，证明 word-ball 多项式上界，并建立对无限稠密 component 仍成立的 \(L^2\) Neumann/Combes--Thomas support-offdiagonal resolvent 估计。
- [Robin frame 的无权衰减障碍与加权尾定理](notes/030-robin-frame-offdiagonal-obstruction-and-weighted-tail.md) — 证明固定 mode 下不同 Yukawa levels 不发生 \(n-m\) 衰减，并严格建立 \(\sum_{n,j<M}d_{n,j}=O_a(M)\) 与 Schur 大-\(n\) 尾/交叉块界，从而以 \(N(M)/M^2\to\infty\) 把统一 frame 问题缩到有限核心。
- [Partial-reflection resolvent 的尖锐 Sobolev 阈值](notes/031-partial-reflection-resolvent-sobolev-threshold.md) — 显式求逆单个 collar reflection，证明一阶及任意正阶 \(L^2\) commutator 均不有界、Fourier 衰减一般只有临界 \(1/|j-k|\)，而 \(H^s\) domain invariance 的尖锐范围为 \(|s|<1/2\)。
- [聚合 deficit 的临界对数障碍](notes/032-aggregated-deficit-critical-kernel-logarithmic-obstruction.md) — 证明 \(q_{M,j}\asymp_a\log((M+1)/(j+1))\)，从而绝对临界 majorant 增长为 \((\log M)^2\)，即使 Hilbert cancellation 仍增长为 \(\log M\)；统一 frame 必须先精确 Schur 消去低模。
- [Normalized frame 与逃逸负模态](notes/033-normalized-frame-equivalence-and-escaping-negative-modes.md) — 证明 frame 余量乘 \(\|E_M\|\) 与 Yukawa 下模型负谱底渐近等价，并以紧预解式极限的显式反例说明形式单调收敛不能阻止负方向逃向高频；A3 的正确目标因此是负谱子的 collective compactness。
- [统一 Yukawa 高频 coercivity 与无谱逃逸](notes/034-uniform-yukawa-coercivity-and-no-spectral-escape.md) — 从 Robin 边界形式序和 operator-monotone Yukawa 函数推出对数增长的公共高频下界，证明下模型负方向 collective compactness 及负谱底无污染；由此严格关闭 uniform frame 作为独立 RH 捷径的路线。
- [首次退化下 rank-one/PF 刚性的极限](notes/035-first-degeneration-rank-one-rigidity-counterexamples.md) — 两个 positivity-improving 四维族分别实现首次不可见奇零核和双扇区同时可见退化，证明首次性、严格 crossing、PF、谱隙及 cyclicity 都不足以自动选择唯一扇区；结合 note 013 还排除了以偶约化谱底非负选择奇扇区的条件。
- [Zero-cyclicity 的指数矩归约与外侧方程障碍](notes/036-zero-cyclicity-exponential-moment-obstruction.md) — 把 Archimedean 外侧势写成半整数指数矩的解析 Dirichlet 级数，证明任一外侧开区间消失即可推出全部矩消失与 \(u=0\)，同时严格说明内点压缩方程、两个 polar moments 和有限 prime shifts 不提供所需的无限边界数据。
- [Exterior-potential UCP 与 zero-cyclicity 的等价性](notes/037-exterior-potential-ucp-is-equivalent-to-zero-cyclicity.md) — 用全线 Wiener--Hopf 分解识别自由外侧 Hardy 数据，证明外侧势开区间消失、全部指数矩消失与 zero-cyclicity 处于同一难度层级；Fourier、Paley--Wiener、extension 和有限 shifts 本身不能提供更薄的桥梁。
- [Prime reflection 破坏奇半区 Markov/定号路线](notes/038-prime-reflection-destroys-odd-half-markov-ground-state-route.md) — 精确计算 odd half-form 的 translation/reflection 绝对值差，用窄 bumps 证明任一 active reflection 原子压倒连续核并破坏 Markov 收缩；严格连接二点模型进一步显示 \(M^-\ge0\) 不推出 ground state 定号或 polar overlap 非零。
- [Screw-kernel 半正性不推出 injectivity](notes/039-screw-kernel-positivity-does-not-imply-injectivity.md) — 把 \(G_a\) 的严格正性等价为谱测度支撑的 Paley--Wiener uniqueness，构造具有 Suzuki 精确 \(\frac12|t|\log|t|\) 主奇性但在长区间上有核的 PSD screw kernel，并指出 Friedrichs 零模态到普通 \(L^2\) 积分方程之间仍有导数正则性缺口。
- [有限 prime delays 不传播 polar moment](notes/040-finite-prime-delays-do-not-propagate-polar-moments.md) — 证明 translation/reflection algebra 在半整数指数矩上逐坐标作用，区间压缩只增加 collar/exterior source，因而 \(U_0=0\) 不能由任何有限 active-prime delay 恒等式递推为全部矩消失。

### 041--061：边界 UCP、Pohozaev、严格局部正性与 true-Schur

- [一般 Wiener--Hopf/Toeplitz 黑箱不能推出 zero-cyclicity](notes/041-no-general-wiener-hopf-black-box-for-zero-cyclicity.md) — 核对 Titchmarsh、Coburn--Simonenko、truncated Toeplitz 与 analytic-kernel UCP 的假设缺口，并以匹配 Suzuki 主奇性的无限维奇偶核反例排除通用 injectivity 定理。
- [Deficiency \((1,1)\) 不推出 reduced polar-cyclicity](notes/042-deficiency-one-does-not-imply-reduced-polar-cyclicity.md) — 逐域核对 Suzuki defect vectors 与极点向量的错位、\(\lambda=0\) 的循环依赖，并以 simple symmetric 导数算子的显式反例证明 defect cyclicity 即使加交换性和正性仍不能控制 reduced 零核。
- [正径向 jumps 不强迫第二谱层简单或为奇](notes/043-positive-radial-jumps-do-not-force-second-mode-simplicity.md) — 以离散和连续反例关闭 positivity-improving/反射对称到第二谱层的抽象推论，并核对 fractional Pohozaev、complete-Bernstein nodal 理论均不覆盖 finite prime atoms。
- [Renormalized logarithmic Pohozaev 铰链与 prime virial](notes/044-renormalized-log-pohozaev-hinge-and-prime-virial.md) — 由 fractional identity 与 Fourier scaling 锁定候选 boundary trace 常数，证明该 trace 若成立将推出 pure-log 全谱简单，同时精确计算并否定 finite prime virial 的一般符号。
- [完整 joint virial 的驻定性与边界异常项](notes/045-joint-weil-virial-stationarity-and-boundary-anomaly.md) — 逐项计算 Archimedean、prime、smooth remainder 与 polar 的尺度导数，证明半正定零模态上的一切形域切向 virial 必须精确为零，从而把唯一可承重对象压缩为非形域 logarithmic boundary anomaly。
- [直接 dilation 不产生 logarithmic boundary trace](notes/046-direct-dilation-does-not-produce-logarithmic-boundary-trace.md) — 证明 logarithmic 主形式的缩放差商恒为全局 (2\|u\|^2)，与端点系数无关；同时证明临界 (1/\sqrt{\log}) 轮廓对所有固定 prime delays 及 activation 阈值只产生 (o(s)) 端点层，从而把 Pohozaev 路线进一步压缩为本征方程专属的 Green 边界配对。
- [边界 Volterra indicial root 与 Mellin-local 铰链](notes/047-volterra-boundary-indicial-root-and-mellin-local-hinge.md) — 把零模态边界主方程化为 \(2tU-\int^tU\)，证明有界余项下唯一慢模为 \(B/\sqrt t+O(1/t)\)，并核准 finite prime shifts 不改变该 root；剩余最小命题是同尺度 Mellin 环奇异积分的 Dini/Besov 有界性。
- [Mellin-local symbol 与 Whitney--Dini 边界缺口](notes/048-mellin-local-symbol-and-whitney-dini-boundary-gap.md) — 计算同尺度环的精确正 logarithmic symbol，排除所有 regularly-varying 单相位与 Volterra 主部的抵消，并把 trace existence 压成一维边界 uniform Whitney--Dini/weighted coercivity；最新 \(n\ge2\) interior Schauder 理论不覆盖该接口。
- [平均边界 trace 与 dyadic packet coercivity](notes/049-averaged-boundary-trace-and-dyadic-packet-coercivity.md) — 给出平均 trace 等价的 signed Mellin tail 条件，证明平方根权重 commutator 为低阶，并以正 symbol 排除分离 dyadic packet 和频率级联 pseudomodes；唯一剩余项是移动 cutoff 的固定宽度端点 leakage。
- [平均 logarithmic boundary trace 的存在](notes/050-existence-of-the-averaged-logarithmic-boundary-trace.md) — 利用 Mellin-local 算子消去常数及 dyadic 对偶估计，证明 signed tail \(\int^\infty t^{-3/2}\mathcal MU\) 普通收敛，从而对所有临界有界零模态建立 Cesàro/Mellin 平均边界系数；点态升级精确等价于额外的 Tauberian 控制。
- [Averaged trace 控制外侧 flux 但不决定 Pohozaev pairing](notes/051-averaged-trace-controls-exterior-flux-but-not-pohozaev-pairing.md) — 证明平均系数已给出精确外侧 Stieltjes 渐近并可替代点态 trace 排除 collar/platform；同时识别 Green pairing 中独立的 conormal variance，最薄剩余条件为 \(T^{-1}\int_T^{2T}|tZ'|^2\to0\)。
- [Logarithmic 边界模态的 conormal variance 消失](notes/052-vanishing-conormal-variance-for-logarithmic-boundary-modes.md) — 利用 averaged trace、Mellin accretivity 与慢 cutoff commutator，证明实际零模态满足 \(T^{-1}\int_T^{2T}|tZ'|^2\to0\)，从而闭合 smooth Green pairing 的边界正则性接口而无需点态 trace。
- [完整 averaged Weil--Pohozaev 恒等式](notes/053-full-weil-averaged-pohozaev-identity.md) — 组装 weak-prime Pohozaev identity，区分 boundary anomaly 与普通 form stationarity，并把剩余铰链精确压成核专属 virial 严格不等式或零 averaged trace 的 boundary UCP。
- [严格局部 Weil 正性推进到 \(\frac12\log7\)](notes/054-strict-local-weil-positivity-to-log7-half.md) — 精确保留 \(n=2,3,4,5\) prime blocks，以两步 Schur prime 范数界、奇扇区 Arb--LDL 与偶扇区四维 verified Schur 证书证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log7\)。
- [严格局部 Weil 正性推进到 \(\frac12\log8\)](notes/055-strict-local-weil-positivity-to-log8-half.md) — 精确保留 \(n=2,3,4,5,7\) prime blocks，以两步 prime 范数界、五维 verified Schur 及有限正 Yukawa 尾的完整合同 Feshbach 更新证明 \(A_a>0\) 于全部 \(0<a\le\frac12\log8\)。
- [严格局部 Weil 正性推进到 \(\frac12\log9=\log3\)](notes/056-strict-local-weil-positivity-to-log9-half.md) — 以对角加权补空间预解式、PSD recovery 子因子和修正后的 true-Schur 公式 \(U_{\rm eff}=U-XC^{-1}V\)，分别用奇 rank-40 与偶 canonical rank-5 Arb 证书证明 \(A_a>0\) 于全部 \(0<a\le\log3\)。
- [历史文献驱动的因果—全正性证明路线图](notes/057-historical-causal-pf-route-map.md) — 从 Schoenberg 单侧 PF∞、Báez-Duarte–Burnol 整数伸缩因果逼近和 Lagarias–Weil 正性出发，提出先核对整数 dilation Gram 与局部 Weil Schur 增益的精确接口，再决定是否进入全局逼近链；不把等价判据当作证明。
- [正算子有限压缩的 canonical 延拓与 metric Schur 公式](notes/058-canonical-extension-of-positive-compressions.md) — 证明孤立加入 \(PYP\) 一般不是 \(Y\) 的 Loewner 下界，给出 \(YP(PYP)^\dagger PY\) 的合法 canonical 子因子及保留 cross 的 true-Schur 公式；因此此前基于孤立 Yukawa 压缩的 \(\frac12\log10\) 奇、偶候选均不构成正性定理。
- [\(\frac12\log10\) 偶扇区 weighted scalar-complement 的严格不定性](notes/059-log10-even-weighted-scalar-complement-is-indefinite.md) — 以修正后的六个 signed prime jumps、P10 digamma-weighted 七维 tail enclosure 和 256-bit interval LDL 证明固定 \((R,N)=(280,500)\) 的完整 weighted 下模型惯性为 \((5,2,0)\)，从而关闭该下模型路线；不推出原 \(A^+\) 不定。
- [\(\frac12\log10\) 偶扇区 K400 true-complement 下模型的严格不定性](notes/060-log10-even-k400-true-complement-lower-model-is-indefinite.md) — 完整保留补空间的前 120 个真实模及其全部 cross，以联合 covariance 支付余尾；393 维补块严格正，而七维 true Schur 惯性为 \((6,1,0)\)，故 clean K400 下模型惯性为 \((399,1,0)\)。该结果关闭这一更尖锐的固定补空间路线，不推出原算子不定。
- [Nyman--Weil 直接压缩障碍与对数半群桥](notes/060-nyman-weil-paley-wiener-obstruction-and-log-semigroup-bridge.md) — 证明任何非零有限 Nyman 向量的 Mellin 像都不是有限指数型，关闭“dilation Gram = finite local Weil compression”；建立 \(O(e^{-a})\) 窗口 Gram 尾、\(n\mapsto qn\leftrightarrow\tau_{\log q}\) 精确协变，并把整数逼近重写为 Cayley 奇异内半群的广义 Schur 问题。
- [完整 Yukawa atom 的精确 rank-one true-Schur 更新](notes/061-a-full-yukawa-atom-has-an-exact-rank-one-true-schur-update.md) — 证明保留 atom 的全部补空间分量后，其对 K400 Schur 块的合法增益精确为一个 graph-corrected rank-one 项；利用 Parseval 恒等式把无限补空间 cross 化为有限的 \(PB_0r-(PB_0P)Pr\)。192-bit true-Schur 证书进一步证明 scalar K400/N500 加单个 full \(r_{500}\) 后仍有惯性 \((399,1,0)\)，从而严格关闭该单 atom 下模型路线；不推出原偶算子不定。

### 057--090：历史 Nyman--Weil 桥、首壳、Ramanujan 与固定低模

- [Báez--Duarte 精确窗口插值关闭 compact Weil 传递](notes/062-baez-duarte-exact-window-interpolation-closes-compact-weil-transfer.md) — 历史自然逼近 \(B_N\) 在 \((N^{-1},\infty)\) 已精确等于 \(-\chi\)；在匹配 log-window 上该零 residual 解还唯一，故任何正内积都强制选出同一组已知 \(L^2\) 失败的系数。由此关闭窗口 Schur 传递，并把正确对象定位为缩放后的逃逸因果尾与 dual/Hardy 双通道可观测性。
- [Báez--Duarte 逃逸尾的 Mertens 壳分解与首壳非消失](notes/063-baez-duarte-tail-mertens-shell-localization.md) — 把 \(\chi+B_N\) 精确写成 reciprocal Mertens 阶梯，证明任意常数中心化后的第一 dyadic shell 能量具有正 limsup，因而历史自然逼近的失败已局域在 \((1/(2N),1/N]\)；首个 dilation-invariant dual 窗则只保留 \(\gamma(N)\) 一个标量，不能控制该障碍。
- [Selberg 渐消 Möbius 逼近的仿射首壳 RH 判据](notes/064-selberg-affine-first-shell-rh-criterion.md) — 对历史权重 \(\lambda_{k,N}=\mu(k)(1-\log k/\log N)\) 推导第一 reciprocal shell 的精确仿射 \(M,J,\Psi\) 闭式；两个消失矩除去常数与线性干扰，Mellin 组合精确消掉最高阶极点但保留每个 zeta 零点，因而仅需证明该单壳能量趋零即可推出 RH。离线零 \(\beta>1/2\) 反而强制子列下界 \(N^{2\beta-1}/\log^2N\)。
- [偶局部 Weil 算子的严格正性推进到 \(\frac12\log10\)](notes/064-strict-even-local-weil-positivity-to-log10-half.md) — 在同源 scalar K400/N500 无限维下算子中完整加入 \(r_{500},\ldots,r_{539}\)，以 Parseval 保留全部 atom--atom 与 atom--base cross，并用 273→120→7 的 metric-Woodbury/Arb true-Schur 证书证明 \(A_a^+>0\) 于 \(0<a\le\frac12\log10\)。39 项前缀仍严格不定，40 项首次严格为正。
- [Barban--Vehov 的 \(H^{-1}\) 障碍与 incomplete-lcm 边界](notes/065-barban-vehov-hminus1-obstruction-and-weak-mertens-bridge.md) — 把首壳误差识别为经典 Barban--Vehov 除数和的累计中心化误差，证明 Graham 的尖锐 \(H^0\) 二次均值只控制三角核的对角；再以 sawtooth 完整 lcm 周期分解和 Jordan 平方和证明周期主项已为 \(o(N^2)\)，从而把 RH 充分条件精确压成一个 signed incomplete-lcm 边界余项。弱 Mertens 均值可推出所需 \(O(N^2/\log N)\)，但该假设本身已蕴含 RH。
- [incomplete-lcm 边界的 Bernoulli--Dedekind 精确化与平衡区铰链](notes/066-balanced-bernoulli-dedekind-dispersion-hinge.md) — 把双边界余项精确写成 cotangent Fourier 级数、耦合 shift--lcm 的三因子 Bernoulli--Dedekind 差及单壳 Stieltjes 相关；Maier--Rassias 的固定幂节省只覆盖分子分母多项式分离区，而非主导的 balanced near-diagonal 区。非二幂端点全量计算将超过 \(96.6\%\) 的块绝对质量局部到最后八个物理尺度，主块的 reduced balanced 质量超过 \(84.4\%\)，从而把下一新输入锁定为 balanced coupled Dedekind dispersion。
- [平衡物理块的精确缩放与反对角 Möbius 零点](notes/067-balanced-physical-scaling-and-antidiagonal-mobius-zero.md) — 固定 gcd 切片的精确缩放与 Euler 分解；其中 \(1/\zeta(s+t)\) 及 anti-diagonal no-pinch 结论仅属于条件化切片。完整聚合的路线裁决已由 note 069 修正。
- [完整局部 Weil 正性推进到 \(\frac12\log10\)](notes/068-strict-local-weil-positivity-to-log10-half.md) — 对奇扇区保留负 polar、全部无限补空间 cross 与完整 odd Yukawa family，213 项 Parseval--metric-Woodbury/192-bit true-Schur 证书首次严格为正；与偶扇区定理合并得到 \(A_a>0\) 于全部 \(0<a\le\frac12\log10\)，从而 \(a_{\rm deg}>\frac12\log10\)。
- [完整局部 Weil 正性推进到 \(\frac12\log(201/20)\)](notes/089-strict-local-weil-positivity-to-log201over20-half.md) — 对实际 cutoff-free 算子保留 active-prime、负 odd polar 及 full-space Yukawa 的全部 joint cross。joint Parseval covariance 与单调 tail 权重给出无限维 Loewner 下算子；192-bit true-Schur 证书严格得到 \(A_a>0\) 于全部 \(0<a\le\frac12\log(201/20)\)，故 \(a_{\rm deg}>\frac12\log(201/20)\)。这不是全尺度 Weil 正性或 RH 的证明。
- [\(\frac12\log11\) 处 even \(P_{400}\) 主压缩严格正定](notes/090-log11-even-p400-principal-compression-is-strictly-positive.md) — 256-bit interval Cholesky--Schur 证书严格得到 \(P_{400}^+A_{\frac12\log11}^+P_{400}^+>0\)，故固定 \(400\)-维 even 子空间内无负见证。该结果不控制正交补、完整 \(A_{\frac12\log11}^+\) 或 RH。
- [cutoff-free 局部 Weil 正性推进到 \(\frac12\log11\)](notes/275-cutoff-free-local-weil-positivity-to-log11-half.md) — notes 273--274 的 256-bit even/odd \(P_{400}\) joint-Schur 证书，结合 note 089 的 Loewner--Parseval 无限尾支付，严格得到 \(A_a^\pm>0\) 于 \(0<a\le\frac12\log11\)，故 \(a_{\rm deg}>\frac12\log11\)。这仍不是全尺度 Weil 正性或 RH 的证明。
- [2026 自伴行列式声称的算术桥裁决](notes/276-2026-self-adjoint-determinant-claim-does-not-close-the-arithmetic-bridge.md) — 外部自伴 Hilbert--Schmidt 模型的自伴性只约束其自身行列式零点；\(F_K\equiv\xi\) 仍是未证明的算术 target-identification，不能替代 Möbius signed energy/intertwiner。
- [平滑 averaged-Chowla 到固定 Mellin 能量的转移](notes/277-smoothed-averaged-chowla-transfer-only-log-saving.md) — 消失边界的 dyadic cutoff 与 Abel 分部求和把 averaged correlation 输入严格转为 \(E_N(w)\ll N^2\rho(N)+O(N\log N)\)；现有 \(\rho\) 只有对数级，仍不能达到 RH 的 \(N^{1+\varepsilon}\) 门。
- [gcd completion 消去固定切片的反对角因子](notes/069-gcd-completion-cancels-the-fixed-slice-antidiagonal.md) — 完整 gcd 求和逐素数补回 \(+p^{-(s+t)}\)，在物理曲面 \(z=s+t\) 上把局部因子恢复为 \((1-p^{-s})(1-p^{-t})\)。因此完整主积分严格回到 \(1/(\zeta(s)\zeta(t))\) 的一变量 Möbius Gram，并分解成有限 moving Mertens/Riesz cells。Menon 2026 的最新 almost-all short-interval 均方在 \(h\asymp N\) 时仍比所需 \(o(N)\) 平方根尺度差一个 \(N\) 次幂（仅附对数修正）。
- [sawtooth cells 的共享边界同号相加而非望远镜消去](notes/070-sawtooth-cell-boundaries-add-instead-of-telescope.md) — 离散 Abel 公式把相邻差精确写成光滑项减去互不重叠的 jump packets；共享端点为 \(-A/2-A/2=-A\)，不消去。每个完整 cell 同时等于 \(G(v)=A(tN/v)\) 的“积分减梯形求积”，但误差测度仍含 \(-1\) Dirac 原子。固定-\(n\) 平铺只把目标降到 weighted-Mertens 均方；完整 \(n\)-sum 的唯一 telescope 是 \(\mu*1\) 与 \(-\mu*\log=\Lambda\)，输出 \(\log N+\Psi\) 而非零。
- [Selberg 首壳增量的 parity 符号障碍](notes/071-selberg-shell-increment-parity-sign-obstruction.md) — 完整残差化为 \(R_N(y)=yB_N-\Psi(y)+\mathcal A_N(y)-\mathcal A_N(N)\)，其 shell increment \(q_N(n)=\Lambda(n)-\mu(n)\log(N/n)\) 随素因子个数奇偶混号。唯一正核 \(2N-\max(m,n)\) 只是累计 \(H^{-1}\) Gram 本身，不能由 Barban--Vehov 的 \(H^0\) 对角回收缺失次幂。DHJ Polymath 的历史 parity barrier 同样要求 sign-sensitive bilinear input；下一原子转为 \(Q_N(\theta)=\sum q_N(n)e(n\theta)\) 的低频双线性消去。
- [临界低频带退化为有限 weighted-Mertens transforms](notes/072-critical-low-frequency-band-has-no-type-II-oscillation.md) — 固定 high block 中 \(n=dm\) 强制 \(m=O(1)\)，故所谓双线性卷积严格退化为有限个 smooth weighted-Mertens transforms。即使人为分解 \(d=rs\)，在 \(\theta=\xi/N\) 上整个 Type-II box 也只转 \(O(1)\) 圈。保留两个 affine modes 后，正确必要对象是 \(\|P^\perp D_{I,N}\|_2^2=o(N\log^2N)\)；Davenport、Wei Zhang 2022 的条件 uniform bound 与 Menon averaged Chowla 均差一个幂门槛。
- [Farey--Franel 正性只看完整 gcd 分量](notes/073-farey-franel-positivity-sees-the-complete-gcd-component.md) — Kanemitsu--Yoshimoto 的 Franel 公式经特殊 Mertens 向量与 Dedekind 三项关系收缩为 gcd 正核。Selberg shell 则精确为 \(K_N=NG_N/12+E_N\)：Franel 结构命中已经为低阶的 \(Q_2\) exact-resonance 项，不能恢复 \(E_N\) near-resonance；\(N=4\) 的显式二坐标反例已证明相同 gcd 能量可有不同 shell 能量。short Kubert 公式又严格回到 RH-equivalent Mertens 伸缩差。
- [Mellin 极点强迫 dyadic 平均首壳增长](notes/074-mellin-poles-force-dyadic-mean-shell-growth.md) — 把 note 064 的点态子列探针升级为 dyadic \(L^2\) Abel 引理。若 \(\rho=\beta+i\gamma\) 是 \(q\) 重零点，则某子列上平均首壳能量至少为 \(Y^{2\beta-1}(\log Y)^{2q-4}\)；因此只要跨截断参数的 dyadic 平均为 \(Y^{o(1)}\) 即可推出 RH。新目标严格降为 \(\sum_{N\asymp Y}I_N\ll_\varepsilon Y^{3+\varepsilon}\)，而非逐个 \(I_N=o(N^2)\)。\(2^8\le Y\le2^{20}\) 的精确计算进一步给出 \(\overline{\mathcal E}(Y)\approx0.0196/\log^2Y\)，只作路线选择。
- [连续 cutoff 平均分裂为端点与斜率方差](notes/075-continuous-cutoff-average-splits-into-endpoints-and-slope-variance.md) — Letendre 的全截断 Möbius 矩在首壳强制的 \(N\ge n/2\) 区间退化为 \(M(n,N)=-\mu(n)\)；Alterman 的连续筛层仍只控制完整 \(H^0\) lcm 密度。实参数 cutoff 的精确导数与两端点 Poincaré 把新目标分裂为 \(D_y(y),D_{y/2}(y)\) 的平方根均值和一个去平均斜率的显式 PSD Möbius 核；两者用直接估计仍各差一个 \(Y\) 幂。
- [cutoff Fourier 平均保留 Farey near-collisions](notes/076-cutoff-fourier-average-leaves-farey-near-collisions.md) — 对 \(N\) 再平均的精确核只是 \([S(2\Delta)-S(\Delta)]/(2\pi i\Delta)\)。远碰撞衰减，但 \(0<|he-kd|\lesssim de/Y\) 时仍为 \(Y^2\)；尤其 \(h=k=1,d,e\asymp Y\) 的宏观块全部拥挤于此。exact resonance 已由 \(Q_2\) 达标，普通 Farey spacing/large sieve 对非零 near-collisions 仍只给 \(Y^{4+o(1)}\)。
- [reciprocal 单包估计的 RH 等强性与超振荡障碍](notes/077-reciprocal-packet-bound-is-rh-strength-but-fixed-band-observability-fails.md) — 完整证明固定 reciprocal 频带不能把远处局部 \(L^2\) 以统一常数外推到零频；显式 reciprocal-grid 超振荡反例与 Nazarov 1993 的项数指数代价一致。但若单包平方根均方对所有实尺度成立，Möbius 先验、解析 Hölder 传播和几何伸缩自举会把任意 Mertens 幂指数迭代到 \(1/2\)，故该 all-scale 单包命题与 RH 等价，不能作为更弱黑箱。
- [全 Fourier 包的有限 Ramanujan 原函数框架](notes/078-full-fourier-packets-form-a-finite-ramanujan-antiderivative-frame.md) — 先约分全部 \(h/d=a/q\)，聚合系数精确为 \(\mu(q)\check m_q(N/q)/\log N\)，numerator 包形成 primitive sawtooth，其单位格跳跃为 \(-c_q(n)/q\)。因此完整跨 \(h\) 抵消等价于 Barban--Vehov 有限 Ramanujan 展开的离散原函数；Alterman 只控制跳跃的 \(\varphi(q)\)-权 \(H^0\)，而 primitive 原函数带 \(J_2(q)\)-权。新的直接求和加强为 \(Q_2(N)\ll N/\log^2N\)，故完整周期对角为 \(O(N^2/\log^2N)\)。精确中心化把剩余压成零模 \(\Gamma_N\) 与 signed incomplete-frame defect；素数模量族证明一般 frame 界仍损失近一整幂，下一输入必须使用 Möbius 系数与 defect 的联合消去。
- [路径 DST 把中心化 defect 压到平方根多个低模](notes/079-path-dst-reduces-the-centered-defect-to-sqrtN-low-modes.md) — primitive 原函数的路径差分有显式正弦奇异值 \(2\sin(\pi k/2N)\)。Barban--Vehov \(H^0\) 已无条件支付 \(k>\sqrt{N/\log N}\) 的全部能量，故中心化未知量只剩 \(N^{1/2+o(1)}\) 个低模；每个低模又精确等于带 Möbius 权的“全局 \(N\)-格点正弦求积减局部 \(N/d\)-格点求积”。仿射项删除 \(\Lambda\) 连续主项，但分开估计 PNT 误差已接近 RH；真正的新目标是对 cutoff \(N\) 作均方的 \(k^{-2}\)-加权格点求积缺陷。note 080 进一步证明零模 \(\Gamma_N\) 对 RH 探针不必控制。
- [中心化路径能量单独构成 RH 判据](notes/080-centered-path-energy-alone-is-an-rh-criterion.md) — 修正 note 079 对零模的需求判断。Mellin 离线零探针本身有零均值，故严格看不见 \(\Gamma_N\)；中心化首壳方差的 dyadic \(Y^{3+\varepsilon}\) 界已经推出 RH。结合 DST 高频尾，唯一充分条件缩为前 \(\sqrt{N/\log N}\) 模的 \(k^{-2}\)-加权 cutoff 均方 \(\ll Y^{2+\varepsilon}\log^2Y\)。若存在 \(\beta>1/2\) 的零点，超临界质量必定位于这些低模，不能藏在零模或高频。
- [每个离线零都被某个固定正弦模看见](notes/081-every-offline-zero-is-visible-in-one-fixed-sine-mode.md) — 固定 \(k\) 的连续 cutoff 模有精确 Mellin 像 \([c_k/(s-1)^2-W_k'(s)]/\zeta(s)+W_k(s)\zeta'(s)/\zeta(s)+W_k'(s)\)，末项只是 \(n=1\) 端点的整函数。正弦完备性证明每个 \(\zeta\)-零点至少被一个固定 \(k=k(\rho)\) 以非零极点看见。因此无需对增长到 \(\sqrt N\) 的模族作一致估计：只要逐个固定 \(k\) 证明 cutoff dyadic 均方 \(\ll_{k,\varepsilon}Y^{2+\varepsilon}\)，即推出 RH。下一最小元可固定为 \(k=1\) Gram，同时判别是否存在 universal finite detector。
- [固定正弦 cutoff 均方呈临界数值尺度](notes/082-fixed-sine-cutoff-means-have-critical-numerical-scaling.md) — 可复现分层计算显示 \(k\le16\) 的固定模均方呈临界 \(Y^{1+o(1)}\) 尺度，\(k^{-2}\) 加权斜率为 0.9968/1.0256；最大壳上 prime--Möbius residual 的强负相关表明联合消去是承重结构。该节点只生成猜想与机制选择，不晋级为证明。
- [两个正弦模把 universal detection 降为紧集无零性](notes/083-two-sine-modes-reduce-universal-detection-to-compact-nonvanishing.md) — 显式行列式 \(D=C_1W_2-C_2W_1\) 非零即保证 \(k=1,2\) 检出全部离线零；三次分部积分证明右半临界带的高频一致无零，故只剩有限矩形认证。至高度 3000 的可复现数值 argument count 为 0 且归一化间隔充足，但仍严格标作数值证据。
- [固定模 Gram 的两种坐标与高除数截断边界](notes/084-fixed-mode-gram-reduces-to-high-divisor-multiplicative-near-diagonal.md) — divisor 坐标中 \(d\le Y^{3/4}\) 已支付，故控制互补的 high-divisor \(\Delta\)-Gram 足够；product 坐标中完整 \(g_N\) 的对角已支付，故控制其完整 off-diagonal 也足够。二者不能拼接。\(k=2\) 的高除数项是纯短-cofactor 和；\(k=1\) 仍有必须联合保留的 global--local 项。
- [固定模是 Hardy-amalgam 空间中的协变导数](notes/085-fixed-mode-is-a-covariant-derivative-in-hardy-amalgam-space.md) — 临界逐壳尺度的精确函数空间是 Mellin--Laplace 像的 \(W(L^2,\ell^\infty)\)，任意 \(\varepsilon\) 版等价于全部右移半平面 \(H^2\) 的交。整函数导数 \(G_k=H_k'\) 给出新的 ground-state 能量恒等式，同时揭示标准 Bergman 正性与目标尺度错配一个对数。
- [前两个正弦模构成严格的 universal detector](notes/086-first-two-sine-modes-are-a-rigorous-universal-detector.md) — Arb 辅助的辐角原理与显式高频余项证明 \(D(s)\ne0\) 于闭右半临界带（除 \(s=1\) 的已知极点）；故只需 \(k=1,2\) 两个 cutoff dyadic 均方即推出 RH。解析 detector 端已闭合；算术端可选 high-divisor \(\Delta\)-Gram 或完整 \(g_N\) off-diagonal。
- [两正弦 cutoff 均方与 RH 等价](notes/087-two-sine-cutoff-mean-square-is-equivalent-to-rh.md) — RH 下的经典 Mertens 平方根界与 von Koch 素数误差，经零端点窗口分部求和给 \(\mathcal R_{N,k}=N^{1/2+o(1)}\)；结合 note 086 的正向判据，得到仅 \(k=1,2\) 的 dyadic cutoff 均方与 RH 精确等价。
- [存在有限纯偶正弦 universal detector](notes/088-a-finite-pure-even-sine-family-universally-detects-rh.md) — 偶正弦反对称子空间的完备性证明 \((W_{2a},W_{2a}')_{a\ge1}\) 在带内处处秩二；高频渐近、\(s=1\) jet 与紧性给出有限纯偶模子族。故存在完全删除 \(B_NS_{N,k}\) 全局通道的有限偶模 RH 等价式。

### 358--364：Mellin detector 的边界与平凡零点约束

- [\(L=3\) h-对偶系数的单变量闭式](notes/367-l3-h-dual-single-variable-closed-form.md) — 利用四阶 Stirling 卷积的指数闭式，把 h-对偶 Newton 系数压成 \(K(z)\) 的四个有限差分块；这是严格代数接口，尚未闭合全 \(m\) 正性或 Möbius signed-energy 门。

- [Abe v26 轮廓积分的二阶极点缺口](notes/358-abe-v26-dirichlet-contour-proof-has-a-double-pole-residue-gap.md) — 假设的 ζ 零点同时使 \(g\) 为零，\(1/(\zeta g)\) 至少有二阶极点；工作稿遗漏相应的 \(\log x\) 留数项，不能作为 RH 证明。
- [最右零点上确界未必达到](notes/359-almost-periodicity-does-not-attain-the-rightmost-zero-line.md) — almost-periodicity/Rouché 只产生实部逼近上确界的零点序列，不能保证存在达到上确界的“最右零点”。
- [对数伸缩与 Jacobian 伸缩的 detector 障碍](notes/360-log-dilation-preserves-zero-free-strip-only-by-losing-the-mean-zero.md) — 纯伸缩破坏零均值，Jacobian 伸缩虽保均值却被 periodization 的 Mellin 符号排除。
- [Jacobian 伸缩的全参数负性](notes/361-jacobian-stretching-has-a-universal-small-a-negative-tail.md) [notes/362-mellin-sign-obstruction-rules-out-all-jacobian-stretches.md) — 当前 detector 层级的所有 \(a>1\) Jacobian 伸缩均不能保持全半轴非负。
- [正 periodization 的最大左端阶数](notes/363-positive-zero-mean-detectors-have-maximal-left-endpoint-order-two.md) — 左右端阶数均大于二时，\(s=-2\) 平凡零点与正 Mellin 积分矛盾；正 detector 必须保留左端二阶项。
- [平凡零点强迫偶端点残数交替符号](notes/364-trivial-zero-residue-signs-for-positive-periodizations.md) — 若 \(P_V\ge0\) 且在 \(s=-2K\) 前有足够衰减，则 \(v_{2k}\ne0\)、\(\operatorname{sgn}v_{2k}=(-1)^k\)，并有 \(\int P_V(y)y^{2k-1}dy=\zeta'(-2k)v_{2k}\)。这是 detector 的必要条件，不是 RH 证明。
