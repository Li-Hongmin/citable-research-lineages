# DRAFT SPEC candidate (rh) — 2026-09-13 — detector-nyman-beurling
状态：DRAFT，未冻结。上限：S/A（新问题接口，不是旧 SPEC 改版）。

## 主陈述
设 ρ(t)={1/t}，Báez-Duarte 空间 V_N=span{ρ(θ/k):1≤k≤N} ⊂ L²(0,1)，d_N²=dist²(χ_(0,1],V_N)。
（RH ⇔ d_N→0；Burnol 下界 d_N² ≥ (2+γ−log4π)/log N，Báez-Duarte 猜想渐近相等。）
主陈述：finite reciprocal-product/detector kernel K_x(a,b)=P(x/(ab)) 与 Vasyunin 的 Gram 矩阵 ⟨ρ(θ/a),ρ(θ/b)⟩
之间存在显式（与 x 无关的）线性/Mellin 变换关系，使得 RH/repos 中的五个 minimality certificates V_6…V_18
等价于 V_N 中一族显式向量 c^{(N)} 的存在性，且沿该族 ‖χ−Σc_k ρ(θ/k)‖² ≤ (2+γ−log4π+o(1))/log N 无条件成立。
若为真：给出 Báez-Duarte 猜想的构造性上界机制（决定性推进）；若为假：确定 detector kernel 与 NB Gram 矩阵不等价的精确障碍。

## 第一个承重引理（生死检验）
L1：存在显式核变换 T 使 K_x = T[G_N]（G_N = Vasyunin Gram 矩阵），或证明两者的谱不变量（例如最小特征值随 N 的衰减率）在 N≤60 内不一致从而不可能存在有界 T。

## 禁区
不进入 Möbius 幂节省、不扩 detector 参数、不新增有限证书数量、不把有限 PASS 当成功。
