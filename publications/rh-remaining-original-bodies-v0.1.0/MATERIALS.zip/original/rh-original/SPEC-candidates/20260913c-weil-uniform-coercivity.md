# DRAFT SPEC candidate (rh) — 2026-09-13c — weil-uniform-coercivity
状态：DRAFT，未冻结。本线前两候选（Nyman–Beurling detector / Mellin 乘子）均已 NOGO，本候选按规则换工具：不再用 Nyman–Beurling/Mellin 乘子，改用 Weil 显式公式的二次型（Weil positivity）。

## 主陈述（新，S/A 上限）
设 W(f) 为 Weil 分布：W(f)=f̂(0)+f̂(1)−Σ_ρ f̂(ρ)（等价地 = 阿基米德项 − Σ_{p,k} (log p) p^{-k/2}(f(k log p)+f(−k log p)) 的标准显式公式形式）。
对多项式族 V_d(u)=u^a(1−u)^b·(u−c)（本仓库 papers/CONJECTURE-B-EULER-BETA-POSITIVITY.md 的 Euler–Beta 族）定义测试函数 g_{d,λ}(x)=V_d(e^{−|x|/λ})·1_{|x|≤λ·L}（λ>0 为尺度，L 固定截断），令 F_N=span{g_{d,λ_j}: j=1..N}（λ_j 取几何级数）。
主陈述：Weil 二次型 Q(f)=W(f*f~) 在 F_N 上一致强制：存在与 N 无关的 c>0，使 Q(f)≥c‖f‖²_{L²} 对所有 f∈F_N、所有 N 成立。
若成立：由 Weil 判据（RH ⇔ Q≥0 于 C_c^∞），加上 F_N 在支撑受限空间中的稠密性，直接推出 RH 在该支撑范围内的零点无穷性约束（Bombieri 型“受限 Weil positivity”）的定量强化；若 c 与 L 的依赖可控，则是通向 RH 的可迁移新机制。
若为假：给出最小特征值随 N 的衰减律 λ_min(N)~N^{-α} 及其来源（是哪一段素数和/阿基米德项抵消），确定正确的替代边界（即“Weil 型强制只能在 dim ≤ N₀(L) 上成立”）。

## 第一个承重引理（本轮生死检验）
L1：对 L=log 2（无素数项的经典安全区，Weil 正性在此已知成立），F_N 上 Gram 矩阵 Q_{ij}=W(g_i*g̃_j) 的最小特征值在 N=2..16 单调不趋于 0（数值判据：λ_min(16)/λ_min(4) ≥ 1/4）。
- 若 λ_min(N) 呈幂律/指数衰减 → 一致强制在最安全的区域都不成立 → NOGO（不可绕：扩大 L 只增加素数项负贡献）。
- 若 λ_min 稳定 ≥ c>0 → 扩到 L=log 5（含 p=2,3 项）复算一次；仍稳定则 GO，并写下一决定性观测（解析证明 c>0 的路线：阿基米德项在该族上的显式下界）。
- 计算：mpmath 50 位；阿基米德项用 Γ'/Γ 积分显式公式；素数项显式求和。脚本留 scratch/probe-weil-uniform-coercivity/。
- 文献裁决：核 Bombieri (2000) "Remarks on Weil's quadratic functional"、Yoshida、以及 Burnol 关于受限支撑 Weil positivity 的结果；若一致强制在 L≤log 2 已是文献定理，则改判该引理“已知”，仍按 L=log 5 数值决定 GO/NOGO。

## 禁区
不回到 Nyman–Beurling、Mellin 乘子、detector 证书；不扩 log2 strict positivity bundle 的表；不做零点数值扫描替代解析论证。
