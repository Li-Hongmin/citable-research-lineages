# DRAFT SPEC candidate (rh) — 2026-09-13b — mellin-multiplier-forced
状态：DRAFT。这是 detector-nyman-beurling 候选（UNDETERMINED）的强制裁决轮，本轮后必须 GO/NOGO，不再允许 UNDETERMINED。

## 修正后的对象
生成元改为标准 Nyman–Beurling 族 e_k(θ)=ρ(1/(kθ))，ρ(t)={t}，空间 L²(0,∞)（Báez-Duarte 2003）。
Vasyunin Gram 矩阵 G(a,b)=⟨e_a,e_b⟩ 有临界线上的 Mellin 表示，符号含 |ζ(1/2+it)|²/|1/2+it|²（以 Vasyunin/Báez-Duarte 原文精确公式为准，由检验员核对）。
detector kernel K_x(a,b)=P(x/(ab))，P(y)=Σ_{n≤y}V6(n/y)，V6 见 repos/RH papers/CONJECTURE-B-EULER-BETA-POSITIVITY.md。
P 的 Mellin 表示：P(y) 是 Perron 型积分，被积符号为 Vt6(s)·ζ(s)·y^s，其中 Vt6 是多项式 V6 的 Mellin 变换（s 的有理函数，显式可算）。

## 固定的变换 T（不再留白）
T 定义为临界线上的 Mellin 乘子：把 G 的符号 |ζ(1/2+it)|²/|1/2+it|² 换成 K 的符号 Vt6(1/2+it)·ζ(1/2+it)·x^{1/2+it}，即乘子
m_x(t) = Vt6(1/2+it) · x^{1/2+it} · |1/2+it|² / conj(ζ(1/2+it))。
主陈述所需的「有界、与 x 无关地一致」的 T 存在 ⇔ 对每个固定 x，m_x 在 t∈R 上本质有界。

## 第一个承重引理（强制裁决）
L1b：m_x 在 t∈R 上有界 ⇔ Vt6(1/2+it) 在 ζ 的每个非平凡零点 1/2+iγ 处为零（否则 1/conj(ζ) 在 γ 附近爆破）。
检验：显式算出 Vt6(s)，在 γ1=14.1347…、γ2=21.0220… 处求值（mpmath）。
- 若 Vt6(1/2+iγ1)≠0 → T 无界 → 主陈述在此定义下为假 → NOGO（不可绕：任何以 ζ 为符号分母的 Mellin 乘子都在零点爆破；换 V 的次数不改变有理函数在给定点非零的一般性，除非 V 被构造成在所有零点消失，这本身等价于 RH 级别信息）。
- 若恰为零（极不可能）→ 计算 γ1…γ10 全部并报告 GO。
- 若检验员认为 m_x 的定义本身与 K、G 的 Mellin 表示不匹配（例如 K 的表示不是简单乘子），则以「不匹配」为 NOGO 理由，写明精确障碍。

## 禁区
同前：不扩 detector 参数、不新增证书、不进入 Möbius 幂节省。不做 N≤60 谱扫描。
