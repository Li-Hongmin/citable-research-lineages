# Mesoscopic signed Möbius dyadic blocks: a theorem target for the RH arithmetic gate

状态：`TARGET / HIGH RISK`；本文件是突破计划，不是已证明定理。

## 目标命题

令

\[
C_h(X)=\sum_{n\le X-h}\mu(n)\mu(n+h),
\qquad
D_H(X)=\sum_{H\le h<2H}C_h(X).
\]

在固定 (eta>0) 下，目标是在一个真正的中尺度区间证明

\[
\boxed{
D_H(X)\ll_{\varepsilon,\eta}X^{1+\varepsilon}
\quad\text{uniformly for}
\quad X^{o(1)}\ll H\le X^{1-\eta}.}
\]

第一阶段可先固定非平凡区间，例如

\[
X^{1/3+\varepsilon}\le H\le X^{2/3-\varepsilon},
\]

再根据证明机制扩大范围。这里的 (D_H) 保留 signed cancellation；不能先取 (|C_h|) 或正部。

## 为什么它直接连接 RH

Mertens 和的平方恒等式给出

\[
M(X)^2
 =\sum_{n\le X}\mu(n)^2
 +2\sum_{1\le h<X}C_h(X).
\]

按 dyadic (h) 分块后，若 (M(X)^2) 超过平方根尺度，必有某个尺度出现宏观正的 signed block。因此中尺度 (D_H) 估计是把“RH 失败的可能性”压缩到一个可定位算术对象的方式。

但这只是归约，不是 RH 证明：需要同时拼接小移位、终端大移位和中尺度区间的全覆盖，并精确处理端点。

## 已排除或已部分处理的范围

- terminal large shifts 可由反向长度的平凡估计控制；
- 极短移位可由 averaged-Chowla 给出平均的对数级节省；
- all-interval (U^2) 结果改善了量词，但只有对数级速率，不能支付四点平方门所需的 (H^{-1}) 多项式因子；
- Fejér/PSD 正化会丢失跨壳 signed cancellation，并保留零频 Mertens 通道；
- 直接假设 (sum_h|C_h|^2\ll X^{2+\varepsilon}H^{-1}) 存在量纲风险，已有项目诊断显示它可能强于 RH，不能当作自然中间定理。

对应的本地边界记录见 notes 306--307、320--322、350--357。

## 最有希望的机制：异常块的逆定理

直接展开 (D_H) 很快会产生一般四点张量。优先尝试相反方向：

\[
\text{large signed block}
\Longrightarrow
|F_X(\theta)|^2\text{ 在可描述频率集上集中}
\Longrightarrow
\mu\text{ 与低复杂度乘法模型相关}.
\]

候选工具包括 Halász/pretentious distance、零自由区、低模数 progression 上的 Möbius 正交和 major/minor arc 分解。关键是把“异常”转成一个可被现有算术定理排除的结构，而不是把整个问题放大成一般四点 Chowla。

## 第一个可证伪实验

对多个 ((X,H)) 计算 (D_H(X))，并在异常样本上比较 (|F_X(\theta)|^2) 的频率分布：

1. zero-frequency concentration；
2. small-denominator major arcs；
3. 分散的 minor-arc mass；
4. 与 Dirichlet characters 或低复杂度 pretentious 模型的相关。

实验只用于区分逆定理的候选机制，不用于把有限数据外推为 RH 证据。

## 论文进入标准

只有出现以下之一，本文件才升级为正式论文定理：

- 一个固定 (alpha>0) 的非平凡 (H)-区间上首次得到幂级 signed 节省；或
- 一个严格的“异常 dyadic block \(\Rightarrow\) pretentious alternative”逆定理；或
- 一个比现有 averaged-Chowla/U² 对数节省具有明确幂级增益的可复用算术估计。

否则只保留为研究计划，不再新增同类 RH 等价判据。

