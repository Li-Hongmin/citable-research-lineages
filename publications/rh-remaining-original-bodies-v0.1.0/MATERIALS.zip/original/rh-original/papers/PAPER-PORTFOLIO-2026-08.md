# 黎曼猜想项目：论文组合与证据边界

更新日期：2026-08-17。本文档把已有数学结果按“一个独立贡献对应一篇论文”重新编排；它不是新的数学证明，也不把研究计划写成已完成定理。

## 总体裁决

当前项目应拆成两篇可立即进入成稿流程的论文单元，以及一个高风险研究计划：

| 单元 | 独立贡献 | 当前状态 | 论文入口 |
|---|---|---|---|
| A | cutoff-free 无限维 response--Schur 机制，并应用于局部 Weil 算子 | 应用定理已闭合；抽象化表述待成稿 | [THEOREM-A-CUTOFF-FREE-SCHUR.md](THEOREM-A-CUTOFF-FREE-SCHUR.md) |
| B | Euler--beta 正 detector 层级、residue skeleton 与 Newton 层正性 | 全层级 periodization 正性仍未闭合 | [CONJECTURE-B-EULER-BETA-POSITIVITY.md](CONJECTURE-B-EULER-BETA-POSITIVITY.md) |
| C | 中尺度 Möbius signed dyadic block | 目标命题；尚无定理 | [THEOREM-C-MESOSCOPIC-DYADIC-GATE.md](THEOREM-C-MESOSCOPIC-DYADIC-GATE.md) |

优先级按“真正的 RH 信息增益”排列为 C > B > A；按“近期可投稿确定性”排列为 A > B > C。A 应先冻结为论文，B 只有在全 (m) 正性核心闭合后才进入正式投稿，C 不应被包装成现成结果。

## 证据等级

- `PROVED`：有本地定理 note、明确假设和可复核证书；
- `REDUCED`：已压缩为严格的更薄命题，但尚未证明该命题；
- `NO-GO`：已证明某条自然路线不能完成目标；
- `TARGET`：值得攻关的论文级目标，不是项目当前结论。

本轮的关键边界是：

1. 局部 Weil 的 (rac12log11) 正性是有限尺度局部结果，不是全尺度 Weil 正性，也不是 RH。
2. detector 的 (L=2) Newton 层已在更正 q-shift 权重后闭合；自然 Pascal 证明路线仍有三次符号变化，不能误写成 (L=2) 正性反例。
3. Möbius 中尺度块估计仍未得到；普通 averaged Chowla、all-interval (U^2) 对数节省和正化操作都没有支付所需的多项式尺度。
4. 附加战略文本中出现的另一条简式 (V_m) 族与本地 notes 149--150 的权威族不一致。在代数核对完成前，论文 B 只采用本地族，不混用两套定义。

## 文献边界

检索/核验日期：2026-08-17；本轮优先复用了本地 ResearchLibrary 的项目矩阵和已读全文。局部 Weil 的主要外部锚点是 Suzuki 2026（arXiv:2606.09096）；秩一类比使用 Connes--Consani--Moscovici 2025（arXiv:2511.22755），但不把其有限模型直接等同于本项目算子。算术边界使用项目已缓存的 Matomäki--Radziwiłł--Tao、Matomäki--Shao--Tao--Teräväinen 等记录；这些文献只支持已标明的平均/对数级结果，不支持 RH-strength 结论。

## 暂不独立成篇的内容

临界线比例、global screw-kernel、自伴 determinant、更多 Mellin 等价式和 log13 外推暂不列入本组合。它们要么不改变当前三条承重主线的决策，要么仍缺少独立的零集识别、全尺度尾估计或算术桥梁。

