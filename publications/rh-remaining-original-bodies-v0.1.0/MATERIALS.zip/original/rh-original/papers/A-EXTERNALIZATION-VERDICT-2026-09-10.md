# A 线外部化裁决（2026-09-10）

## 决定

本轮在 A/B 中选择 **A（cutoff-free response--Schur 与局部 Weil 正性）**。选择标准仅为
投稿确定性：A 已有完整算子论证的候选证明链，而 B 的 821 行新稿仍须逐式重审 Mellin detector、
精确截断和五层有限证书。该选择不表示 A 的数学影响高于 B。

固定对象与声明范围内的权威 verdict 现为 **GO / ACCEPT（GPT-6 Pro round 5）**。这里的固定对象是
`a=log(11)/2, K=400, N=500, R=280`、双 parity、`F=[500,850)`、`q_f=8000`、
Arb 256-bit；获准的声明仅为 cutoff-free response--Schur 应用、
`A_a^\pm>0` 对 `0<a<=log(11)/2`，以及直接推论 `a_deg>log(11)/2`。这不是对 B、
moving-N、其他阈值、全尺度 Weil 正性、RH 或整稿投稿状态的裁决。

2026-09-10 round 1 已从空缓存重放
固定参数双 parity 无限尾对象并严格通过；round 2 又确认源码矩阵确为 note 089 的 Schur 下界，
但要求补齐目标 Weil 闭形式比较与 checker 失败退出。本轮已将有限核闭形式 Schur 引理、共同核上的
逐块比较、闭包、Parseval 收敛及 Householder 合同识别写入权威 theorem/note，并修复 checker。
round 4 指出的两个可修补接口现已处理：整数余弦／半整数正弦有限 Fourier 组合在包含
完整 \(\mathcal R_{850}\) 的实际目标 Weil form norm 中的稠密性已由直接核比较与 Fourier
权刻画证明；冻结 verifier 已固定 21 个预期相对路径并先检查集合相等、数量与唯一性，再逐项
验哈希。它拒绝空清单和删一项后的 20 项清单。round 5 异源审计已独立核对上述 form-core／闭包接口与
固定清单 verifier，并给出 ACCEPT；因而固定 A 对象及上述声明范围从 REVISE 晋级为 GO / ACCEPT。

## 逐定理新颖性比较

| 本项目候选陈述 | Suzuki 2026, arXiv:2606.09096v2 | Connes--Consani--Moscovici 2025, arXiv:2511.22755 | Chuk 2026, arXiv:2608.24827 | 裁决 |
|---|---|---|---|---|
| 局部闭形式及自伴算子 `A_a` | Theorem 1.1 给出 Friedrichs 实现；Theorem 1.3 给出最低本征值连续性 | Theorem 3.6 给出离散下有界谱 | 使用同一局部 Weil form | 非新；必须引用而非重证为主要贡献 |
| 小尺度正性及基态结构 | Theorem 1.4 只断言充分小 `a`，并给渐近、简单性与偶性 | 提供有限模型及谱三元组框架；未给 `log(11)/2` 阈值 | Theorem 1.2 严格证明全空间 `L=0.8` 的正性 | `log(11)/2 ~= 1.19895` 阈值未被这些定理覆盖 |
| cutoff-free response--Schur 机制 | 未见以完整 Yukawa response family、Parseval covariance 和有限 core Schur 支付无限尾的定理 | 有有限维限制/秩一结构，但不是本项目的 Loewner--Parseval 下算子 | Theorem 1.1 是不同的 frequency-envelope/Legendre finite reduction；正文明确讨论 order-space cross coupling | 可能是可复用的新方法，但需把抽象引理完整证明并与 Chuk Theorem 1.1 明确区分 |
| `A_a^\pm>0` 对所有 `0<a<=log(11)/2` | 未覆盖 | 未覆盖 | Theorem 1.2 为 `L=0.8` 的实偶函数，复函数版本见 Corollary 6.3；§7 撤回旧 `L=1.19` 正性主张 | 若闭形式接口通过异源审计，则阈值贡献仍可能新颖 |
| 首次退化尺度 `a_deg>log(11)/2` | 连续性提供定义背景，不给该下界 | 不给该下界 | 由其 `L=0.8` 结果只给较弱下界 | 是阈值定理的直接推论，不宜作为独立贡献计数 |

检索范围包括上述三篇全文的定理、局部 Weil positivity、compact-window finite reduction、
Schur/cutoff-free/tail 等关键词。该检索足以发现最直接的 2025--2026 竞争结果，但在正式投稿前仍应
由 paper-lib/人工数据库做引用追踪和后向/前向引文复核。

## 证明链审计

候选无限维桥位于 note 089 的式 (7)--(15)：`Q` 块由对角 `T_sigma>0` 控制，完整 response
cross terms 通过 Parseval 恒等式组成 `R_tot=sum U_q U_q^*`，单调权重支付无限尾，最后把正性
降到有限 core Schur 矩阵。这个结构若逐项成立，确实不是把有限压缩补零。

历史阻断（round 1 前）：note 275 当时只引用未版本化的 `scratch/` 结果，没有 log11 双 parity
永久 bundle。该阻断现已由 `computations/bundles/log11-local-weil-positivity-round1/` 关闭；旧的
`log11-even-p400-principal-positivity` 仍只是一份不同对象的有限压缩证书。

## 可复现核验

在主机 `omen`（Python 3.10.12, uv 0.12.3）执行：

1. `log201over20-local-weil-positivity/verify_frozen_results.py`：双 parity 冻结 pivot 检查通过；
2. `log11-even-p400-principal-positivity/verify_frozen_results.py`：有限 even 主压缩检查通过；
3. 两包 `sha256sum -c SHA256SUMS.txt`：log11 even 主压缩包全部通过；log201over20 包有三个承重源码
   哈希不匹配（prime graph、parent generator、sharp checker）；
4. 当前目录及父级不是 Git 工作树，无法核对改动来源、commit 或 push。

以上四项是 round 1 前的历史核验记录，不能描述当前交付状态。round 1 后永久包已经保存双 parity
的源码、逐阶段日志、parent 哈希和最终区间结果，并提供从空 `scratch/` 重生的明确路径；本轮冻结
verifier 进一步绑定实际端点、clean 标记、尾部正下界、置换和全部哈希。冻结检查本身仍不等同于
再次运行大矩阵，但“无重放路径”的旧阻断已经关闭。

## 2026-09-10 round 1 加码结果

永久轻量包见 `computations/bundles/log11-local-weil-positivity-round1/`。even 的 393 维补块和
7 维核心全正，最终 pivot 下端约 `3.6824e-50`；odd 的 394 维补块和 6 维核心全正，最终
pivot 下端约 `3.6435e-45`。这关闭 log11 双 parity 无限维应用证书，不替代余下投稿门。

## 固定 A 对象的晋级条件与终态

A 的固定对象证明与证书接口按以下条件裁决：

1. ~~固化并从空缓存重生 log11 双 parity infinite-tail Schur gate；全部承重下端严格为正。~~ 已完成；
2. ~~有限核 response--Schur 引理写成自足定理，并证明目标闭形式比较、域、闭包与合同对应；~~ 已完成并由 round 5 异源确认；
3. ~~完成 Suzuki 1.1/1.3/1.4、CCM 3.6/5.10、Chuk 1.1/1.2 与 Cor. 6.3 的逐定理比较，确定固定声明的公开边界；~~ 已完成于本 verdict 的逐定理比较；正式稿中的引用编排仍属整稿编辑，不在本次终局裁决内；
4. ~~异源审计 ACCEPT。~~ round 5 已完成。

**终态：固定 A 对象与上述声明范围内 GO / ACCEPT。** 最薄弱但已闭合的一步仍是 note 275
式 (FC) 中圆周能量对零延拓端点 logarithmic killing 项的反向控制；round 5 用端点内区间平均、
`dt/t` 积分及 `1/s <= 1/(s-r)` 独立核对了该控制。剩余边界是：不扩大到 B、moving-N、
`a>log(11)/2`、其他阈值、全尺度 Weil 正性或 RH；本 verdict 也不替代整稿投稿裁决。
