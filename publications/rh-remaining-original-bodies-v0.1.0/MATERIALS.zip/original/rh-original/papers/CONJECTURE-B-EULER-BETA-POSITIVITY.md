# Euler--beta 正 detector 层级：统一正性定理的论文计划

状态：`REDUCED / CONJECTURE`  
证据入口：[note 149](../notes/149-the-positive-detector-hierarchy-has-a-3m-plus-3-degree-pattern.md)、[note 150](../notes/150-universal-euler-operator-form-of-the-positive-detector-hierarchy.md)、[note 162](../notes/162-l1-newton-coefficient-positivity-by-cumulative-binomial-kernel.md)、[note 170](../notes/170-l2-newton-gamma-layer-is-closed.md)、[note 232](../notes/232-l2-pascal-basis-has-a-three-sign-change-obstruction.md)。

## 论文主张（待证明）

采用本地已核验的 detector 族 (V_m)，定义

\[
P_m(y)=\sum_{1\le n\le y}V_m(n/y),\qquad y>1.
\]

目标是证明

\[
\boxed{P_m(y)>0\quad\text{for every }m\ge1, y>1.}
\]

这将给出一个统一的全层级 reciprocal-product 正 kernel，而不是把有限层计算继续推到更大的 (m)。

## 当前权威族与统一 Mellin 结构

本项目目前采用 notes 149--150 的定义：令

\[
H_m(u)=u^2(1-u)^{3m+1},\qquad \Theta=-u\partial_u,
\]

\[
\mathcal D_m=(\Theta-1)\prod_{j=1}^{m-1}(\Theta+2j+1),
\qquad
C_m=(3m+4)\prod_{j=1}^{m-1}(3m+2-2j),
\]

并置

\[
V_m=C_m^{-1}\mathcal D_mH_m.
\]

于是 (deg V_m=3m+3)，且

\[
\widehat V_m(s)=
\frac{(3m+1)!(s-1)}{C_m}
\left[
\prod_{j=1}^{m}(s+2j)
\prod_{k=2m+1}^{3m+3}(s+k)
\right]^{-1}.
\]

这统一给出零均值因子 (s-1)、前 (m) 个 odd residue 的消去结构和固定的 Mellin zero-free skeleton。

附加战略文本中另写了一条 (H_m=u^2(1-u)^{2m+1}) 的简式族。它与上述 (3m+3) 阶族的算子定义、端点阶数和 Mellin 分母目前未完成代数对齐；在独立核对前不进入本论文的主定理。若两者实为归一化/参数重标记，必须先给出逐式等价证明。

## 已闭合的结果

### 1. 次数与 residue skeleton

在自然端点平坦类中，消去前 (m) 个 odd residues、保持零均值和 periodization 非负的首个可能次数为

\[
\deg V_m=3m+3.
\]

notes 149--150 给出相应的统一 Euler--beta 表示及 Mellin 分母。

### 2. 有限层正性证书

精确有理计算已验证 (P_m(y)\ge0) 的有限层范围 (m=1,\ldots,43)。这只是审计证据，不是全 (m) 定理。

### 3. Newton 系数的全 (m) 局部层

正确区分 q-shift 权重后，(L=1) Newton 层的 (gamma_{m,h,1}\ge0) 已对所有 (m) 闭合；(L=2) 层的 (gamma_{m,h,2}\ge0) 也在更正权重并完成 Beta 累计估计后闭合。它们加强了 detector 的代数结构，但尚未推出 (P_m(y)>0) 的全层级 periodization 定理。

## 尚未闭合的真正核心

自然 Bernstein/Pascal 证明路线不能直接使用：note 232 给出严格的三次符号变化。这个 `NO-GO` 只排除“一次变号 + Pascal variation-diminishing”的廉价模板，不否定 (L=2) 的完整正性，更不构成 (P_m) 的反例。

因此论文 B 的最薄核心是寻找一个能吸收三次变号的正锥。优先测试：

1. 把相邻累计量组成二维状态，证明 (2\times2) transfer matrix 保持随 (m,k) 变化的正锥；
2. 对 (L=2) 系数做二阶差分，寻找单符号 forcing；
3. 识别 Hahn/Jacobi/dual-Hahn contiguous relation，并使用离散 Sturm 或 Christoffel--Darboux 正性。

成功标准不是更大的有限 (m) 扫描，而是一个对所有 (m) 的矩阵锥不变性或等价的离散正性定理。

## 与 RH 的边界

即使 (P_m(y)>0) 对所有 (m,y) 成立，也只完成正 detector 的结构层。它不自动给出含 (mu(a)\mu(b)) 符号的 reciprocal-product 二次型平方根估计；固定 detector 的 positive kernel、普通 PSD Gram 或更多 Mellin 等价式都不能替代 arithmetic intertwiner。

## 建议投稿结构

1. 极点消去条件与次数下界；
2. Euler--beta 统一族及 Mellin factorization；
3. finite-(m) exact certificates；
4. (L=1,2) Newton 层全 (m) 正性；
5. 三次变号 no-go；
6. 全 (m) periodization 正性定理（若闭合）；
7. detector 正性与 RH-strength arithmetic gate 的严格区分。

在第 6 节闭合前，本文应保持为研究计划/条件性论文，而不是声称已经完成的正性论文。

