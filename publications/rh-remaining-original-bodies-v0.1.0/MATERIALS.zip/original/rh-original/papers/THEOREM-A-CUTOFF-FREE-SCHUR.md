# Cutoff-free positivity of localized Weil forms through the \(\frac12\log 11\) threshold

状态：`PROVED application / manuscript theoremization pending`  
证据入口：[note 275](../notes/275-cutoff-free-local-weil-positivity-to-log11-half.md)，以及 notes 273--274、089、090。

## 摘要（成稿版）

我们建立一种不截断 response family 的无限维 Schur 证书，并将其应用于局部 Weil 二次型。核心是把完整 Yukawa response family 的发散尾吸收到精确范数差恒等式中，在保留全部 principal--tail cross terms 的前提下，以加权尾支付和有限 core Schur 补构造完整算子的严格正下界。该方法证明局部 Weil 算子两个奇偶扇区在

\[
0<a\le \frac12\log 11
\]

上均严格正，从而首次退化尺度满足 (a_{\rm deg}>\frac12\log11)。结果仍是有限尺度局部 Weil 正性，不推出全尺度 Weil 正性或黎曼猜想。

## 主定理

令 (A_a^\pm) 为当前局部 Weil 自伴算子在 even/odd sector 上的闭形式实现。则

\[
\boxed{A_a^+>0,\qquad A_a^->0
\quad\text{for every }0<a\le\tfrac12\log 11.}
\]

由闭形式域的零延拓与 min--max 单调性，端点证书自动覆盖整个区间；因此

\[
\boxed{A_a>0\quad(0<a\le\tfrac12\log11),\qquad
a_{\rm deg}>\tfrac12\log11.}
\]

## 有限核闭形式 Schur 引理

设 \(\mathcal H=P\mathcal H\oplus Q\mathcal H\)，其中 \(P\) 有限秩；
\(T\) 是 \(Q\mathcal H\) 上的自伴算子且 \(T\ge\tau I>0\)，
\(M=M^*\in\mathcal B(P\mathcal H)\)，
\(C\in\mathcal B(Q\mathcal H,P\mathcal H)\)。在
\(P\mathcal H\oplus D(T^{1/2})\) 上定义

\[
 \ell[x,y]=\langle Mx,x\rangle+2\Re\langle Cy,x\rangle
             +\|T^{1/2}y\|^2.                         \tag{RS1}
\]

则 \(\ell\) 是下有界闭形式，并且

\[
 \ell[x,y]=\|T^{1/2}y+T^{-1/2}C^*x\|^2
 +\langle (M-CT^{-1}C^*)x,x\rangle.                  \tag{RS2}
\]

所以若有限矩阵 \(G\) 满足
\(0<G\preceq M-CT^{-1}C^*\)，则 \(\ell>0\)。

证明只需注意 \(T^{-1/2}C^*\) 有界；(RS2) 先在
\(P\mathcal H\oplus D(T)\) 上展开，再由 form-norm 稠密性延拓。
右端平方范数给出闭性；反之 (RS1) 与右端形式范数等价，因为 \(P\mathcal H\)
有限维。若 \((e_q)\) 对角化 \(T\)，令 \(U_q=Ce_q\)，则

\[
 CT^{-1}C^*=\sum_q\frac{U_qU_q^*}{t_q}.
\]

由于 \(P\mathcal H\) 有限维且 \(C\) 有界，
\(\sum_qU_qU_q^*=CC^*\) 按迹范数收敛。这就是所需的 Parseval
收敛，不需要假定任意可数 atom family 的更强结论。

## 局部 Weil 闭形式的应用

在 \(a_{11}=\frac12\log11\) 固定 parity \(\sigma\) 后，以源码实际使用的
有限 Fourier 线性组合为共同 form core。这里需要的不是由余项正性推出
范数等价，而是如下直接 Fourier-core 引理（完整证明见 note 275）：对
\(I=(-a_{11},a_{11})\) 上的零延拓函数，Chen--Weth 空间范数满足
\[
 \|u\|_{H(I)}^2\asymp
 \sum_k\log(2+|k|)|\widehat u_k|^2.                 \tag{FC}
\]
偶扇区取整数余弦频率；奇扇区取反周期延拓，因而恰是源码的半整数正弦
频率 \((k+\tfrac12)\pi/a_{11}\)。证明把零延拓的近对角核反射到周期／
反周期胞；端点 logarithmic killing weight 与圆周 seam energy 由
\(|r-s|^2\le2|r|^2+2|s|^2\) 及其内区间平均反向估计两向控制。Parseval 后第 \(k\) 个权为
\(2\int_0^\delta(1-\cos(\omega_kt))dt/t
=2\log(2+|k|)+O(1)\)。所以实际 Fourier 截断在 \(H(I)_\sigma\) norm
中收敛。note 004 所核对的 Chen--Weth Theorem 3.1 与 Suzuki Theorem
1.1 给出 Weil form domain 等于 \(H(I)_\sigma\)，且 finite-prime 与光滑
项为 \(L^2\)-有界扰动；共同平移后的 Weil form norm 因而与 (FC) 等价。
下形式的对角权同样为 \(t_k^\sigma=\log(2+|k|)+O(1)\)。故这些有限组合
同时是目标形式与下形式的 form core，包括半整数奇基。此论证直接包含
完整 \(\mathcal R_{850}^\sigma\)，没有假定它自身有界，也没有用它的正性／
单调性声称范数等价。目标形式在此核上逐项写为

\[
 \mathfrak a_{11}^\sigma=D^\sigma+B_0^\sigma+FF^*
 +\mathcal R_{850}^\sigma,\qquad \mathcal R_{850}^\sigma\succeq0,
\]

其中 \(F=(r_{500}^\sigma,\ldots,r_{849}^\sigma)\)。取

\[
\begin{aligned}
M_\sigma&=P(D^\sigma+B_0^\sigma)P+B_FB_F^*,\\
C_\sigma&=PB_0^\sigma Q+B_FV^*,\\
T_\sigma e_q&=(d_q^\sigma-\rho_\sigma)e_q,
\end{aligned}
\]

其中 \(B_F=PF,V=QF\)。active-prime 图界给出
\(B_0^++\rho_+I\succeq0\)；odd 情形把负 polar 的完整范数
\(2(\sinh a_{11}-a_{11})\) 加入 \(\rho_-\)，故同样有
\(B_0^-+\rho_-I\succeq0\)。又因 \(d_q\) 递增且
\(t_{400}^\sigma>0\)，共同核上直接相减得到

\[
 \mathfrak a_{11}^\sigma[x+y]-\ell_\sigma[x,y]
 =\langle Q(B_0^\sigma+\rho_\sigma I)Qy,y\rangle
 +\|V^*y\|^2
 +\mathcal R_{850}^\sigma[x+y]\ge0.                  \tag{A1}
\]

正 atom 余项的单调形式极限保留非负性。更明确地，共同平移使
\(\mathfrak a_b,\ell_b\ge0\) 后，核上 \(\ell_b\le\mathfrak a_b\)。若
\(u_n\) 在核中并于 \(\mathfrak a_b\)-form norm 趋于 \(u\)，则
\(\ell_b[u_n-u_m]\le\mathfrak a_b[u_n-u_m]\to0\)；由 \(\ell_b\) 的闭性，
\(u_n\) 在其 form norm 中趋于同一 \(u\)，取极限即得
\(\ell_b[u]\le\mathfrak a_b[u]\)。这把 (A1) 严格延拓到完整 Weil form
domain；目标比较来自实际形式，而不是应用假设。

令 \(U_q=C_\sigma e_q\)、
\(R_1=\sum_{400\le q<8000}U_qU_q^*\)。权重单调性给出

\[
G_\sigma=M_\sigma-
\sum_{400\le q<8000}\frac{U_qU_q^*}{t_q^\sigma}
-\frac{CC^*-R_1}{t_{8000}^\sigma}
\preceq M_\sigma-C_\sigma T_\sigma^{-1}C_\sigma^*.  \tag{A2}
\]

checker 中 `RTOT=CC*`，并以同一 \(U_q\) 形成 `R1` 和加权 `G1`。
保存的 Householder 依次组成正交矩阵 \(U_H\)；其补块 Cholesky 与核心
LDL 检验的是 \(U_H^*G_\sigma U_H\) 的 Schur 合同，故严格正 pivots
认证的正是 (A2) 的 \(G_\sigma\)。由 (RS2)、(A1)、(A2) 即得完整目标
闭形式严格正。

## 局部 Weil 应用中的关键结构

在 (a_{11}=\frac12\log11) 处，采用完整 (P\)-(Q) 分块，而非把响应尾粗暴截断：

- active-prime graph 给出统一的四步尾控制；
- even/odd sector 分别使用有限的 500--850 Yukawa atom family；
- (q_f=8000) 后的尾由精确 Parseval 差与单调尾支付吸收；
- finite core Schur 补保留 base--atom、atom--atom 及全部 (P\)-(Q) cross；
- 没有截断的是目标算子及 Parseval 支付的无限 Fourier response 尾；
- even 与 odd 的有限维 Cholesky pivots 均有严格 Arb 误差裕量。

永久证书入口为：

```text
computations/bundles/log11-local-weil-positivity-round1/results/
```

## 论文中必须主动解释的旧障碍

固定 (F_{640})、(F_{700}) 或 clean lower model 的不定性，不与本定理矛盾。那些对象是截断/下模型，满足

\[
\underline L_F\preceq A_{a_{11}},
\]

而本方法依靠未截断 response family 的正尾和完整 cross 修复下模型的近核方向。论文应把这一点写成“为什么 cutoff-free 结构是必要的”，而不是把旧负 pivot 隐去。

## 贡献边界与禁止表述

可以声称：

- 一个可复用的无限维 response--Schur 证书机制；
- 局部 Weil 正性的新严格阈值 (rac12\log11)；
- 首次退化尺度的严格下界。

不能声称：

- (a>\frac12\log11) 的正性；
- 全尺度 Weil 正性；
- RH；
- log13 是 log11 方法的直接延伸。

## 投稿结构

1. 局部 Weil 形式与 parity decomposition；
2. response family 与 exact norm-difference identity；
3. cutoff-free weighted tail lemma；
4. abstract finite-core Schur theorem；
5. even/odd log11 certificates；
6. monotone extension to smaller scales；
7. sharpness of the method and scope boundary。
