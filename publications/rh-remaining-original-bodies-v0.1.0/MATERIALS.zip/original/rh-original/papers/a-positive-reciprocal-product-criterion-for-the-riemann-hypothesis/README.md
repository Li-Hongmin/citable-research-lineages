# A Positive Reciprocal-Product Criterion for the Riemann Hypothesis

- Manuscript: a-positive-reciprocal-product-criterion-for-the-riemann-hypothesis.md
- Exact certificate supplement: supplementary-detector-certificates.md
- Deterministic verifier: verify_detector_certificates.py

Reproduce the finite detector certificates in an environment containing
SymPy with

    python3 verify_detector_certificates.py

or, when `uv` is available,

    uv run --with sympy python verify_detector_certificates.py
