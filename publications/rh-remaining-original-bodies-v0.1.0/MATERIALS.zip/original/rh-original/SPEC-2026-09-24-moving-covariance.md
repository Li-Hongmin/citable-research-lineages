# Moving-scale gate: bounded run (2026-09-24)

Main statement: for every epsilon>0 and b=2,4, the integer-scale gates G_b of note 750 hold uniformly in Y; equivalently RH given note 749. Do not assume either.

Route 1: inspect the exact fixed-cell Gram and note 732 covariance. First decisive observation: rigorously test whether a proposed deterministic diagonal/parity decomposition yields an upper bound O_epsilon(Y^{2+epsilon}) without assuming M(x)=O_epsilon(x^{1/2+epsilon}). Go only if every off-diagonal remainder has an independently justified bound of that order; no-go if a specific coherent block invalidates the inequality.

Route 2 (only after route 1 no-go): use note 753 residual identity. First observation: test whether Lambda main term plus mu-log admits an exact cancellation estimate uniformly in moving N. Go only with a proved mean-square bound at target exponent; no-go on a rigorous obstruction to the selected estimate.

Budget: this bounded run ends after route 1 decisive test or an explicitly unidentified hinge; subsequent run requires fresh selection. Forbidden: treat RH equivalence as proof; extrapolate finite numerics; change old SPEC; new cells, full-scale local Weil, public claims, or heavy local computation. Exploratory arguments in scratch only; permanent theorem requires independent check.
