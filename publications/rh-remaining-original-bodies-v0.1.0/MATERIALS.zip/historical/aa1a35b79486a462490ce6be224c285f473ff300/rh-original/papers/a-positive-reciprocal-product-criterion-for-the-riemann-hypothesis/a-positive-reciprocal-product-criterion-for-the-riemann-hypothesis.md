# A Positive Reciprocal-Product Criterion for the Riemann Hypothesis

## Abstract

Define

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}),\qquad y\ge1,
\]

and

\[
T(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P\!\left(\frac{x}{ab}\right).
\]

The Riemann hypothesis is equivalent both to

\[
T(x)\ll_\varepsilon x^{1/2+\varepsilon}
\]

for every \(\varepsilon>0\), and to the corresponding dyadic mean-square
bound. The kernel is entrywise nonnegative and contains no asymptotic
remainder. It is nevertheless highly indefinite: along square primorials
both inertias grow at least as \(\log x/\log\log x\), while on a squarefree
primorial star the centered kernel has exact inertia \((1,m-2,0)\).
We construct minimal degree-six, degree-nine, and degree-twelve nonnegative
detectors which remove respectively the first one, two, and three odd
collective residues. We also give a degree-fifteen detector, minimal in the
same endpoint-flat polynomial class, which removes the first four odd
collective residues; its positivity is certified
by an exact shifted Faulhaber--Bernstein expansion.
An analogous degree-eighteen certificate removes the first five odd residues.
These are equivalent criteria and structural results, not a proof of RH.

## 1. Introduction

Square-root bounds for Möbius sums are classical reformulations of RH. Here
one such bound is converted into a finite reciprocal-product quadratic form
whose entries are nonnegative. The positivity is literal but is not positive
semidefiniteness; the construction therefore isolates, rather than solves,
the required signed cancellation.

Positive Farey quadratic forms give other RH criteria; see Kanemitsu and
Yoshimoto (1996). Their Theorem 3, called Franel's formula in the original
paper, is a nonnegative Farey square identity whose
arithmetic form is a double sum in (M(x/m)M(x/n)(m,n)^2/(mn)). It therefore
provides the closest positive-quadratic precedent, but not the
(a,b\leq\sqrt x), (x/(ab)) kernel below. More precisely, in the notation of
Báez--Duarte's Theorem 3.1, take
\(F(t)=t^{-1}V(1/t)\) and \(\phi(t)=tF'(t)\). Then direct calculation gives
\(G_\phi(x)=U_V(x)/x\) (and
\(\widehat\phi(s)=sK_V(s+1)\), with the corresponding Mellin convention).
Thus the pointwise detector equivalence here is a special case of that general
Möbius-convolution theorem and makes no new contribution. Liflandsky's
unconditional implication from the stated no-\(\varepsilon\) discrete-Laplace
bound to RH has a converse only under RH together with his simple-zero and
growth hypotheses. Verjovsky's \(L^p\) and local Fourier-moment criteria use
Fourier-polynomial derivative control to pass from a moment to persistent
peaks, not a general \(L^2\)-to-pointwise principle. None of these analytic
mechanisms is claimed here as new. Statistical aspects of the Möbius sequence
were studied by Good and Churchhouse (1968).

A full-text comparison completed on 11 September 2026 against those closest
criterion, Farey, and Möbius-convolution precedents did not locate the exact
kernel (3.2), the finite identity (4.2)--(4.4), or the five certified
residue-removing detectors of Section 8. Accordingly the novelty claim of this
paper is restricted to those exact finite structures and their inertia and
minimality consequences. The detector theorem itself, the equivalence
(M(x)=O_\varepsilon(x^{1/2+\varepsilon})\Longleftrightarrow RH), and the
general use of Mellin transforms are background. This is a bounded priority
statement, not an assertion that all RH criteria have been exhaustively
classified.

## 2. A zero-free Mellin detector

Let \(W\in BV(0,\infty)\) be supported in \((0,B]\) after zero extension.
Set

\[
U_W(x)=\sum_{n\ge1}\mu(n)W(n/x),\qquad
K_W(s)=\int_0^\infty W(t)t^{s-1}\,dt.
\]

For \(\Re s>1\), absolute convergence and \(t=n/x\) give

\[
\int_0^\infty U_W(x)x^{-s-1}\,dx
=\frac{K_W(s)}{\zeta(s)}.
\tag{2.1}
\]

**Detector theorem.** If

\[
K_W(s)\ne0\qquad(1/2<\Re s<1),
\tag{2.2}
\]

then RH is equivalent to

\[
\forall\varepsilon>0,\qquad
\int_Y^{2Y}|U_W(x)|^2\,dx
\ll_{W,\varepsilon}Y^{2+\varepsilon}
\qquad(Y\ge1).
\tag{2.3}
\]

**Proof.** RH gives

\[
M(X)=\sum_{n\le X}\mu(n)
=O_\delta(X^{1/2+\delta})
\]

for every \(\delta>0\). Abel summation, including all jumps in the total
variation of \(W\), yields

\[
|U_W(x)|\ll_W\sup_{n\le Bx}|M(n)|
\ll_{W,\delta}x^{1/2+\delta}.
\]

Taking \(\delta=\varepsilon/2\) proves (2.3).

Conversely, fix \(\sigma_0>1/2\) and choose
\(0<\varepsilon<2\sigma_0-1\). Dyadic summation gives

\[
\int_{1/B}^{\infty}|U_W(x)|^2x^{-2\sigma_0-1}\,dx<\infty.
\]

If \(\Re s>\sigma_0\), Cauchy–Schwarz with the additional factor
\(x^{-(\Re s-\sigma_0)}\) makes the left side of (2.1) absolutely convergent,
locally uniformly in \(s\). Since \(\sigma_0>1/2\) is arbitrary, it is
holomorphic on \(\Re s>1/2\). With \(Z(s)=(s-1)\zeta(s)\), continuation of

\[
Z(s)\int_0^\infty U_W(x)x^{-s-1}\,dx=(s-1)K_W(s)
\]

shows that a zero of \(\zeta\) in \(1/2<\Re s<1\) would force a zero of
\(K_W\) there, with at least the same multiplicity. This contradicts
(2.2). The classical zero-free half-plane \(\Re s\ge1\), the functional
equation, and the symmetry \(\rho\mapsto1-\overline\rho\) put every
nontrivial zero on the critical line. ∎

## 3. The endpoint-flat kernel

Define

\[
V(u)=
\begin{cases}
-2u+6u^2-4u^3,&0<u<1,\\
0,&\text{otherwise}.
\end{cases}
\]

Its zero extension is continuous and of bounded variation,
\(V(0+)=V(1-)=0\), and \(\int_0^1V=0\). Moreover,

\[
K_V(s)
=-\frac2{s+1}+\frac6{s+2}-\frac4{s+3}
=\frac{2(s-1)}{(s+1)(s+2)(s+3)},
\tag{3.1}
\]

which is zero-free in \(1/2<\Re s<1\).

**Faulhaber factorization.** For \(y\ge1\),

\[
\sum_{c\le y}V(c/y)=P(y)\ge0.
\tag{3.2}
\]

Indeed, writing \(N=\lfloor y\rfloor\) and \(r=\{y\}\), the first three
power-sum formulas give

\[
\sum_{c\le y}V(c/y)
=-\frac{N(N+1)}y
+\frac{N(N+1)(2N+1)}{y^2}
-\frac{N^2(N+1)^2}{y^3}.
\]

After factoring \(N(N+1)/y^3\), the remaining polynomial is

\[
-y^2+(2N+1)y-N(N+1)=r(1-r).
\]

## 4. Exact truncation and the RH criterion

For real \(x\ge1\), put

\[
\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}.
\]

For every integer \(n\le x\),

\[
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n).
\tag{4.1}
\]

To prove this, set \(z=\sqrt x\) and
\(r=\delta-\nu_x*1\). Then \(r(m)=0\) for every integer \(m\le z\).
If \(n\le z^2\), every factorization \(n=ab\) has \(a\le z\) or
\(b\le z\); hence \((r*r)(n)=0\). Since \(\mu*1=\delta\),

\[
0=(\mu*r*r)(n)
=\mu(n)-2\nu_x(n)+(\nu_x*\nu_x*1)(n).
\]

Let

\[
U(x)=\sum_n\mu(n)V(n/x).
\]

Multiplying (4.1) by \(V(n/x)\), summing, and using (3.2) gives

\[
U(x)=2A(x)-T(x),
\qquad
A(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x).
\tag{4.2}
\]

There is no endpoint term because \(V(1)=0\). If
\(N=\lfloor\sqrt x\rfloor\), then

\[
|A(x)|
\le
\frac2x\sum_{n\le N}n
+\frac6{x^2}\sum_{n\le N}n^2
+\frac4{x^3}\sum_{n\le N}n^3
\le12.
\tag{4.3}
\]

Consequently,

\[
\boxed{|T(x)+U(x)|\le24\qquad(x\ge1).}
\tag{4.4}
\]

**Main theorem.** The following are equivalent:

1. RH;
2. for every \(\varepsilon>0\),
   \[
   T(x)\ll_\varepsilon x^{1/2+\varepsilon}\qquad(x\ge1);
   \]
3. for every \(\varepsilon>0\),
   \[
   \int_Y^{2Y}|T(x)|^2\,dx
   \ll_\varepsilon Y^{2+\varepsilon}\qquad(Y\ge1).
   \]

The detector theorem gives the mean-square equivalence for \(U\). More
precisely, (4.4) and \(|a+b|^2\leq2|a|^2+2|b|^2\) give

\[
\int_Y^{2Y}|T(x)|^2\,dx
\leq2\int_Y^{2Y}|U(x)|^2\,dx+O(Y)
\]

and, in the reverse direction,

\[
\int_Y^{2Y}|U(x)|^2\,dx
\leq2\int_Y^{2Y}|T(x)|^2\,dx+O(Y).
\]

Thus the bounded error transfers the required estimate in both directions.
RH also gives the pointwise bound for \(U\)
by Abel summation. Conversely, for a desired dyadic exponent \(\eta>0\),
apply the pointwise bound with \(\varepsilon=\eta/2\), square and integrate.

The quantifier “for every \(\varepsilon>0\)” is essential. The pointwise
and mean-square versions are separately equivalent through RH; no general
\(L^2\)-to-pointwise implication is asserted.

The proof-bearing identity is (4.1). Its quantifiers are: for every real
(x\geq1) and every integer (n\leq x), with the cutoff in \(\nu_x\)
depending on that same (x). After multiplication by (V(n/x)), the support
condition and (V(1)=0) justify the finite rearrangement into (4.2); no
limiting interchange or asymptotic Euler summation occurs. Thus the theorem
is an equivalence of an unproved family of estimates with RH, not an estimate
for (T) and not a proof of RH.

## 5. Spectral geometry

For \(1\le a,b\le\sqrt x\), write

\[
K_x(a,b)=P(x/(ab)),\qquad
C_x(a,b)=K_x(a,b)-\frac{ab}{6x}.
\]

The entrywise nonnegative matrix \(K_x\) is not generally positive
semidefinite. For every \(k\ge1\), the indices \((3k,2k)\) at
\(x=9k^2\) give the principal block

\[
\begin{pmatrix}
0&4/27\\
4/27&8/81
\end{pmatrix},
\qquad
\det=-\frac{16}{729}.
\tag{5.1}
\]

The indefiniteness has growing rank. Let \(p_1<\cdots<p_m\) be the first
\(m\) primes, \(Q=p_m^\#\), and \(x=Q^2\). For \(m\ge3\), on the indices

\[
a_k=p_k,\qquad b_k=p_k^2,
\]

all cross-block products divide \(Q^2\), so their kernel entries vanish.
The resulting principal submatrix is

\[
\bigoplus_{k=1}^m
\begin{pmatrix}0&c_k\\c_k&d_k\end{pmatrix},
\qquad c_k>0,\ d_k\ge0.
\]

Every block has one eigenvalue of each sign. Since \(C_x\) is obtained
there by subtracting a rank-one positive semidefinite matrix,

\[
n_\pm(K_x)\ge m,\qquad
n_-(C_x)\ge m,\qquad
n_+(C_x)\ge m-1.
\tag{5.2}
\]

As \(\log x=(2+o(1))m\log m\), both inertias grow at least as
\(\log x/\log\log x\) along this subsequence.

## 6. Exact squarefree centered inertia

Let \(x=p_m^\#\) and take the squarefree indices
\(a_j=2p_j\), \(2\le j\le m\). For \(m\ge6\), the corresponding
principal matrices satisfy

\[
\boxed{
(n_+,n_-,n_0)(K)
=(n_+,n_-,n_0)(C)
=(1,m-2,0).}
\tag{6.1}
\]

Indeed, with \(D_{jj}=p_j/\sqrt x\), the half-integer formula for \(P\)
and the diagonal calculation give

\[
K=D(J-E)D,
\qquad
C=D\left(\frac13J-E\right)D,
\tag{6.2}
\]

where \(J=\mathbf1\mathbf1^T\) and

\[
E_{ij}=\frac{4p_i^2p_j^2}{x^2}\quad(i\ne j),\qquad
E_{jj}=1-4y_jP(y_j),\qquad
y_j=\frac{x}{4p_j^2}.
\tag{6.3}
\]

Since \(P\ge0\), these entries satisfy

\[
1\ge E_{jj}>p_m^{-2},\qquad
\sum_{k\ne j}E_{jk}<p_m^{-2},
\tag{6.4}
\]

so \(E\succ0\) by strict diagonal dominance. To verify the diagonal bound,
write \(y_j=N_j+r_j\). Since \(x/(2p_j)\) is odd and not divisible by
\(p_j\), one has \(d_j:=1-2r_j=k_j/p_j\), where \(k_j\) is a nonzero
even integer with \(2\le |k_j|\le p_j-1\). Direct substitution in \(P\)
gives

\[
E_{jj}
=d_j^2-\frac{(1-d_j^2)d_j}{y_j}
 +\frac{(1-d_j^2)^2}{4y_j^2}
\ge \frac{k_j^2}{p_j^2}-\frac{4|k_j|p_j}{x}.
\]

For \(|k_j|=2\), this is exactly
\(4/p_j^2-8p_j/x\). If \(|k_j|>2\), the same lower bound follows from

\[
\frac{k_j^2-4}{p_j^2}
\ge\frac{4p_j(|k_j|-2)}{x},
\]

which is equivalent to \(x(|k_j|+2)\ge4p_j^3\). This holds because
\(|k_j|+2\ge6\), \(p_j\le p_m\), and \(x>(8/3)p_m^3\). Consequently

\[
E_{jj}\ge \frac4{p_j^2}-\frac{8p_j}{x}>p_m^{-2}.
\]

For the off-diagonal sum,

\[
\sum_{k\ne j}E_{jk}
\le\frac{4(m-2)p_m^4}{x^2}<p_m^{-2}.
\]

The last inequalities reduce to \(x>(8/3)p_m^3\) and
\(x^2>4(m-2)p_m^6\). They hold at \(m=6\). For the induction step, put
\(p=p_m\), \(p'=p_{m+1}\), and use Bertrand's bound \(p'<2p\):
\(p^3>p'^2\) and \((m-2)p^2>16(m-1)\) for \(m\ge6\). Multiplication
by \(p'\) preserves both inequalities. Put \(n=m-1\) and
\(q=\mathbf1^TE^{-1}\mathbf1\). Congruence by
\(E^{-1/2}\) turns the middle matrix for \(C\) into

\[
\frac13uu^T-I,\qquad u=E^{-1/2}\mathbf1.
\]

It has \(n-1\) negative eigenvalues, while the remaining sign is that of
\(q/3-1\). Cauchy–Schwarz and (6.4) give

\[
q\ge\frac{n^2}{\mathbf1^TE\mathbf1}
>\frac{n}{1+p_m^{-2}}
\ge\frac5{1+13^{-2}}>3.
\]

This proves (6.1) for \(C\); replacing \(1/3\) by \(1\) proves it for
\(K\).

## 7. Low-degree positivity cone

For

\[
V(u)=\sum_{k=1}^d v_ku^k,\qquad
V(0)=V(1)=\int_0^1V(u)\,du=0,
\]

put \(P_V(y)=\sum_{c\le y}V(c/y)\). For \(d=3\),

\[
P_V(y)\ge0\quad(y\ge1)
\iff v_3\le0.
\tag{7.1}
\]

For \(d=4\), the endpoint and mean constraints give

\[
v_1=\frac{v_3}{2}+\frac{4v_4}{5},
\qquad
v_2=-\frac{3v_3}{2}-\frac{9v_4}{5},
\]

and the exact classification is

\[
\boxed{
P_V(y)\ge0\quad(y\ge1)
\iff
v_4\ge0,\qquad
v_3\le-\frac{12}{5}v_4.}
\tag{7.2}
\]

Necessity follows from

\[
P_V(N)=\frac{v_4(N^2-1)}{30N^3}
\]

and the \(N=1,\ r\downarrow0\) boundary. For sufficiency write
\(v_4=w\ge0\), \(v_3=-12w/5-t\), \(t\ge0\). With \(y=N+r\), the
numerator of \(60P_V(N+r)(N+r)^4/[N(N+1)]\) becomes

\[
15tr(N+r)(1-r)
+w\bigl(2(N-1)+6r^2(3-2r)\bigr)\ge0.
\]

Thus endpoint flatness alone does not imply positivity. For example,

\[
V(u)=-\frac45u+\frac95u^2-u^4
\]

has zero endpoints and zero mean, but

\[
P_V(N)=-\frac{N^2-1}{30N^3}<0\qquad(N\ge2).
\]

## 8. A hierarchy of positive residue-removing detectors

The cubic kernel contains the collective term

\[
\frac1{6x}\left(\sum_{a\le\sqrt x}a\mu(a)\right)^2,
\]

coming from the \(s=-1\) Mellin residue. This term is not forced by
entrywise kernel positivity.

We first record the finite endpoint lemma used for the minimality statements.
Fix \(1\le\ell\le5\). Suppose that \(V\) is a real polynomial with zero
endpoints and zero mean, that

\[
[u]V=[u^3]V=\cdots=[u^{2\ell-1}]V=0,
\qquad P_V(y)\ge0\quad(y\ge1).
\]

For \(y=N+r\), shifted Euler--Faulhaber summation gives

\[
P_V(N+r)=
\sum_{k\ge1}
\frac{B_k(1-r)V^{(k-1)}(1)-B_kV^{(k-1)}(0)}
{k!(N+r)^{k-1}}.
\tag{8.0}
\]

For \(2\le k\le2\ell+1\), the lower-endpoint term vanishes: when \(k\)
is even this follows from the displayed odd-coefficient conditions, and
when \(k>1\) is odd it follows from \(B_k=0\). Each of the finitely many
Bernoulli polynomials \(B_k(1-r)\), \(2\le k\le11\), changes sign on
\(0<r<1\). Therefore the first nonzero upper-endpoint derivative would make
(8.0) negative for a fixed \(r\) and all sufficiently large \(N\). Hence

\[
u^2(1-u)^{2\ell+1}\mid V.
\tag{8.0a}
\]

This conclusion is finite and exact; it makes no assertion about an infinite
detector hierarchy.

Now let

\[
V_6(u)=u^2(1-u)^3(7u-3)
=-3u^2+16u^3-30u^4+24u^5-7u^6.
\tag{8.1}
\]

Then

\[
K_{V_6}(s)
=\frac{24(s-1)}
{(s+2)(s+3)(s+4)(s+5)(s+6)},
\tag{8.2}
\]

so the detector remains zero-free in \(1/2<\Re s<1\), while
\(\operatorname{Res}_{s=-1}K_{V_6}=0\).

If \(y=N+r\), \(N=\lfloor y\rfloor\ge1\), \(0\le r<1\), its exact
Faulhaber kernel is

\[
P_{V_6}(N+r)
=\frac{N(N+1)}{6(N+r)^6}
\left\{
(N-1)[1-6r^2(1-r)^2]+3r^3(4-3r)
\right\}.
\tag{8.3}
\]

Both terms in braces are nonnegative because
\(r^2(1-r)^2\le1/16\). Hence \(P_{V_6}(y)\ge0\) on the entire half-line.
The same exact truncation proof gives another positive reciprocal-product
criterion for RH, now with transfer error \(O(x^{-1/2})\), because
\(V_6(u)=O(u^2)\) at zero.

To state the residue decompositions, write

\[
S_j(z)=\sum_{n\le z}n^j\mu(n).
\]

If \(V(u)=\sum_{j=1}^d v_ju^j\), (8.0) gives the exact collective
decomposition

\[
P_V(y)=\sum_{j=1}^d v_j\zeta(-j)y^{-j}+R_V(y),
\qquad
R_V(y)=\sum_{j=1}^d
\frac{V^{(j)}(1)}{(j+1)!}B_{j+1}(1-\{y\})y^{-j}.
\]

Accordingly, for the reciprocal-product form
\(T_V(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P_V(x/(ab))\), define

\[
T_V^{(0)}(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)
R_V\!\left(\frac{x}{ab}\right),
\]

so that
\[
T_V(x)=\sum_{j=1}^d v_j\zeta(-j)x^{-j}S_j(\sqrt x)^2
+T_V^{(0)}(x).
\]
The Bernoulli factors in \(R_V\) have zero mean as functions of the
fractional part. This periodic zero-mean fact does not provide any arithmetic
mean-square control of \(T_V^{(0)}\).

The remaining nonzero polynomial residues are

\[
T_{V_6}(x)
=\frac{2S_3(\sqrt x)^2}{15x^3}
-\frac{2S_5(\sqrt x)^2}{21x^5}
+T_{V_6}^{(0)}(x).
\tag{8.4}
\]

Thus the collective skeleton moves from \((S_1,S_3)\) to \((S_3,S_5)\).
Degree six is minimal. Indeed, if \(P_V\ge0\),
\(V(0)=V(1)=\int_0^1V=0\), and \(V'(0)=0\), the first two
Euler–Faulhaber coefficients change sign as functions of the fractional
shift. Positivity therefore forces

\[
V'(1)=V''(1)=0.
\]

Consequently \(u^2(1-u)^3\mid V\). In degree at most five this gives
\(V=c\,u^2(1-u)^3\), whose integral is \(c/60\); zero mean forces
\(c=0\). Formula (8.1) is the first nonzero possibility.

The next level is also explicit and sharp. Define

\[
V_9(u)=u^2(1-u)^5(20u^2-5u-1).
\tag{8.5}
\]

Then

\[
K_{V_9}(s)=
\frac{1680(s-1)}
{(s+2)(s+4)(s+5)(s+6)(s+7)(s+8)(s+9)}.
\tag{8.6}
\]

Thus both \(s=-1\) and \(s=-3\) residues disappear, while the critical
strip remains zero-free. If \(y=N+r\), \(m=N-1\), the exact kernel has the
form

\[
P_{V_9}(N+r)
=\frac{N(N+1)}{6(N+r)^9}Q_N(r),
\tag{8.7}
\]

where, in the Bernstein basis
\(\beta_{k,7}(r)=\binom7k r^k(1-r)^{7-k}\),

\[
Q_N(r)=
\sum_{k=0}^7
\left(c_k^{(0)}+mc_k^{(1)}+m^2c_k^{(2)}\right)\beta_{k,7}(r),
\tag{8.8}
\]

with

\[
\begin{aligned}
c^{(0)}&=(0,0,0,0,0,2,9,18),\\
c^{(1)}&=(3,6,28/3,12,12,32/3,12,15),\\
c^{(2)}&=(3,3,10/3,4,4,10/3,3,3).
\end{aligned}
\tag{8.9}
\]

Every coefficient is nonnegative, proving \(P_{V_9}(y)\ge0\) on the
whole half-line. Its collective skeleton begins two odd residues later:

\[
T_{V_9}(x)
=\frac{5S_5(\sqrt x)^2}{9x^5}
-\frac{14S_7(\sqrt x)^2}{15x^7}
+\frac{5S_9(\sqrt x)^2}{33x^9}
+T_{V_9}^{(0)}(x).
\tag{8.10}
\]

Degree nine is minimal. If \(v_1=v_3=0\), shifted Euler–Faulhaber
asymptotics and the sign changes of \(B_2,B_3,B_4,B_5\) force

\[
u^2(1-u)^5\mid V.
\]

In degree at most eight, the remaining conditions \(v_3=0\) and
\(\int_0^1V=0\) force \(V=0\). Formula (8.5) is the first nonzero
possibility.

The third level continues the same sharp degree progression. Let

\[
V_{12}(u)=u^2(1-u)^7(91u^3-3u^2-7u-1).
\tag{8.11}
\]

Then

\[
K_{V_{12}}(s)=
\frac{403200(s-1)}
{(s+2)(s+4)(s+6)(s+7)(s+8)(s+9)(s+10)(s+11)(s+12)}.
\tag{8.12}
\]

An exact degree-ten Bernstein expansion, with coefficients polynomial in
\(m=N-1\) in the nonnegative falling-factorial basis

\[
1,\qquad m,\qquad m(m-1),\qquad m(m-1)(m-2),
\]

has only nonnegative rational coefficients; Supplementary Table S1 records
the complete array. Hence \(P_{V_{12}}(y)\ge0\) for every \(y\ge1\). Its first three odd
residues vanish, and

\[
T_{V_{12}}(x)
=\frac{112S_7(\sqrt x)^2}{15x^7}
-\frac{800S_9(\sqrt x)^2}{33x^9}
+\frac{11056S_{11}(\sqrt x)^2}{819x^{11}}
+T_{V_{12}}^{(0)}(x).
\tag{8.13}
\]

The shifted Euler–Faulhaber argument now forces
\(u^2(1-u)^7\mid V\). The constraints \(v_3=v_5=0\) and zero mean
then rule out every nonzero polynomial of degree at most eleven. Thus
degree twelve is minimal.

The next four-residue construction is already available in degree fifteen.
Let

\[
V_{15}(u)=u^2(1-u)^9
\bigl(1024u^4+207u^3-57u^2-27u-3\bigr).
\tag{8.14}
\]

Direct Beta integration gives

\[
K_{V_{15}}(s)=
\frac{415134720(s-1)}
{(s+2)(s+4)(s+6)(s+8)(s+9)(s+10)(s+11)(s+12)
(s+13)(s+14)(s+15)},
\tag{8.15}
\]

where the denominator in (8.15) is the product of the displayed linear
factors. Thus the Mellin detector is zero-free in the critical strip, and
\(v_1=v_3=v_5=v_7=0\), together with \(\int_0^1V_{15}=0\).

For \(y=N+r\), \(N=\lfloor y\rfloor\ge1\), \(0\le r<1\), exact shifted
Faulhaber summation gives

\[
P_{V_{15}}(N+r)=
\frac{N(N+1)}{(N+r)^{15}}Q_N(r).
\tag{8.16}
\]

The degree-thirteen Bernstein coefficients of \(Q_N\), expressed in the
falling-factorial basis \(1,m,m^{\underline2},m^{\underline3},m^{\underline4}\)
with \(m=N-1\), are all nonnegative rational numbers; Supplementary Table S2
records the complete array. Hence \(P_{V_{15}}(y)\ge0\) for every real \(y\ge1\),
not merely at integer arguments. The resulting exact reciprocal-product
form satisfies

\[
T_{V_{15}}(x)=
\frac{416S_9(\sqrt x)^2}{x^9}
-\frac{243232S_{11}(\sqrt x)^2}{105x^{11}}
+\frac{2912S_{13}(\sqrt x)^2}{x^{13}}
-\frac{115744S_{15}(\sqrt x)^2}{255x^{15}}
+T_{V_{15}}^{(0)}(x),
\tag{8.17}
\]

where the periodic coefficients in \(T_{V_{15}}^{(0)}\) have zero mean.
The shifted Euler--Faulhaber sign argument forces
\(u^2(1-u)^9\mid V\) under these four residue constraints and positivity;
the remaining degree-at-most-fourteen quotient is killed by the three moment
conditions and zero mean. Thus degree fifteen is minimal in this natural
endpoint-flat polynomial class. The exact shifted Faulhaber convention and
the minimality matrices are independently checked by the supplementary
verifier.

The same construction continues one level further. The degree-eighteen
detector

\[
V_{18}(u)=\frac{u^2(1-u)^{11}}{8151}
\bigl(8151u^5+3645u^4+198u^3-262u^2-77u-7\bigr)
\tag{8.18}
\]

has \(v_1=v_3=v_5=v_7=v_9=0\), zero mean, and a zero-free Mellin transform
with denominator factors \(s+2,s+4,s+6,s+8,s+10,s+11,\ldots,s+18\).
Its complete all-half-line Bernstein certificate is given in Supplementary
Table S3. Thus the positive detector hierarchy reaches five removed odd
residues, while the same signed quadratic-form obstruction remains.

The five-residue level is also minimal in the same class. Positivity and the
five odd-moment constraints force \(u^2(1-u)^{11}\mid V\). If
\(\deg V\le17\), the quotient has degree at most four; the four remaining
odd-coefficient conditions and zero mean form a full-rank \(5\times5\)
rational system. Hence the quotient is zero. The degree-eighteen polynomial
above spans the first nonzero direction. The system and its rank are checked
in the supplementary verifier.

The conjectural continuation to every residue level is not used anywhere in
this paper. In particular, no all-level periodization conjecture is assumed
in the main theorem or in any of the five finite certificates.

## 9. Scope after prior-art comparison

The closest precedents separate into three classes. Classical Mertens,
Riesz--Hardy--Littlewood, and general Möbius-convolution criteria already
supply the analytic paradigm (K(s)/\zeta(s)) and growth conditions equivalent
to RH. Farey criteria supply genuinely nonnegative quadratic quantities and
exact double arithmetic expressions, but their variables are Farey
discrepancies or (M(x/m)) with a gcd kernel, rather than a finite Möbius
vector with an (x/(ab)) kernel. The 2026 discrete-Laplace and local-Fourier
criteria use different kernels and do not imply (3.2), (4.4), or the Section 8
finite certificates.

The contribution that survives this comparison is therefore narrow: the
exact positive reciprocal-product kernel, its exact bounded-error transfer to
a zero-free compact Mellin detector, the stated inertia results, and the five
finite residue-removing detectors with minimality in the specified
endpoint-flat polynomial class. No general “universal detector” novelty is
claimed, and no infinite detector hierarchy is proved.

## 10. Discussion

The main theorem replaces a one-dimensional Möbius detector by an exact
finite quadratic form with entrywise nonnegative kernel. The growing
inertia shows why this is not a positivity proof of RH. On genuine
squarefree Möbius support, a single collective positive mode is surrounded
by a codimension-one negative space. Section 8 shows that positivity allows
the first five RH-strength collective residues to be removed by explicit
detectors, with minimality proved in the stated class for all five levels.
Higher odd moments and the centered remainder remain. The unresolved problem
is therefore to control this highly indefinite form on the particular Möbius vector
while preserving cancellation between its collective and centered parts.

## References

1. I. J. Good and R. F. Churchhouse, “The Riemann hypothesis and
   pseudorandom features of the Möbius sequence,” *Math. Comp.* **22**
   (1968), 857–861. DOI: 10.1090/S0025-5718-1968-0240062-8.
2. S. Kanemitsu and M. Yoshimoto, “Farey series and the Riemann
   hypothesis,” *Acta Arith.* **75** (1996), 351–374.
   DOI: 10.4064/aa-75-4-351-374.
3. L. Báez-Duarte, “Möbius-convolutions and the Riemann hypothesis,”
   arXiv:math/0504402 (2005).
4. S. Liflandsky, “Explicit formula for the discrete Laplace transform of the
   Möbius function, related special functions, and a criterion for the Riemann
   hypothesis,” arXiv:2607.09797v3 (2026).
5. A. Verjovsky, “How Random Is the Möbius Function? Smoothing, Probability,
   and the Riemann Hypothesis,” arXiv:2607.25002v2 (2026).

## Supplementary material

The file supplementary-detector-certificates.md contains the exact rational
certificate tables for degrees twelve, fifteen, and eighteen. The script
verify_detector_certificates.py reconstructs all five detectors from their
definitions, verifies their Mellin transforms and moment cancellations,
recomputes the shifted Faulhaber--Bernstein certificates, and checks the five
minimality matrix ranks. Run

    python3 verify_detector_certificates.py

The verifier requires SymPy. In an environment with `uv`, the isolated
equivalent command is

    uv run --with sympy python verify_detector_certificates.py
