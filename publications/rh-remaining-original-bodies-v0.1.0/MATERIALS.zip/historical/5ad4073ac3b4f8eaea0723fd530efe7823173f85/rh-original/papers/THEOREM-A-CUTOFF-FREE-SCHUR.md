# Cutoff-free positivity of localized Weil forms through the \(\frac12\log 11\) threshold

状态：`PROVED application / manuscript theoremization pending`  
证据入口：[note 275](../notes/275-cutoff-free-local-weil-positivity-to-log11-half.md)，以及 notes 273--274、089、090。

## 摘要（成稿版）

我们建立一种不截断 response family 的无限维 Schur 证书，并将其应用于局部 Weil 二次型。核心是把完整 Yukawa response family 的发散尾吸收到精确范数差恒等式中，在保留全部 principal--tail cross terms 的前提下，以加权尾支付和有限 core Schur 补构造完整算子的严格正下界。该方法证明局部 Weil 算子两个奇偶扇区在

\[
0<a\le \frac12\log 11
\]

上均严格正，从而首次退化尺度满足 (a_{\rm deg}>\frac12\log11)。结果仍是有限尺度局部 Weil 正性，不推出全尺度 Weil 正性或黎曼猜想。

## 主定理

令 (A_a^\pm) 为当前局部 Weil 自伴算子在 even/odd sector 上的闭形式实现。则

\[
\boxed{A_a^+>0,\qquad A_a^->0
\quad\text{for every }0<a\le\tfrac12\log 11.}
\]

由闭形式域的零延拓与 min--max 单调性，端点证书自动覆盖整个区间；因此

\[
\boxed{A_a>0\quad(0<a\le\tfrac12\log11),\qquad
a_{\rm deg}>\tfrac12\log11.}
\]

## 方法定理应如何抽象

论文应先给出一个 response--Schur 引理，再给出局部 Weil 应用。抽象引理的输入应明确列为：

1. 一个闭形式 coercive baseline；
2. 可数 response family (g_j)；
3. response family 的 exact norm-difference/Parseval 恒等式；
4. 有限 core correction space；
5. 带权可求和的 response tail；
6. 补空间严格下界与有限 core Schur 补严格正性。

结论是：

\[
\text{finite response--Schur certificate}
\Longrightarrow
\text{full infinite-dimensional positivity}.
\]

这里的抽象版本必须在成稿时逐项证明；当前已经闭合的是它在局部 Weil 数据上的应用，而不是任意闭形式的自动定理。

## 局部 Weil 应用中的关键结构

在 (a_{11}=\frac12\log11) 处，采用完整 (P\)-(Q) 分块，而非把响应尾粗暴截断：

- active-prime graph 给出统一的四步尾控制；
- even/odd sector 分别使用完整 500--850 Yukawa response family；
- (q_f=8000) 后的尾由精确 Parseval 差与单调尾支付吸收；
- finite core Schur 补保留 base--atom、atom--atom 及全部 (P\)-(Q) cross；
- even 与 odd 的有限维 Cholesky pivots 均有严格 Arb 误差裕量。

证书入口为：

```text
scratch/log11_even_K400_N500_clean_sharp_family_500_850_full393_q8000_arb_256.npz
scratch/log11_odd_K400_N500_clean_sharp_family_500_850_full394_q8000_arb_256.npz
```

## 论文中必须主动解释的旧障碍

固定 (F_{640})、(F_{700}) 或 clean lower model 的不定性，不与本定理矛盾。那些对象是截断/下模型，满足

\[
\underline L_F\preceq A_{a_{11}},
\]

而本方法依靠未截断 response family 的正尾和完整 cross 修复下模型的近核方向。论文应把这一点写成“为什么 cutoff-free 结构是必要的”，而不是把旧负 pivot 隐去。

## 贡献边界与禁止表述

可以声称：

- 一个可复用的无限维 response--Schur 证书机制；
- 局部 Weil 正性的新严格阈值 (rac12\log11)；
- 首次退化尺度的严格下界。

不能声称：

- (a>\frac12\log11) 的正性；
- 全尺度 Weil 正性；
- RH；
- log13 是 log11 方法的直接延伸。

## 投稿结构

1. 局部 Weil 形式与 parity decomposition；
2. response family 与 exact norm-difference identity；
3. cutoff-free weighted tail lemma；
4. abstract finite-core Schur theorem；
5. even/odd log11 certificates；
6. monotone extension to smaller scales；
7. sharpness of the method and scope boundary。

