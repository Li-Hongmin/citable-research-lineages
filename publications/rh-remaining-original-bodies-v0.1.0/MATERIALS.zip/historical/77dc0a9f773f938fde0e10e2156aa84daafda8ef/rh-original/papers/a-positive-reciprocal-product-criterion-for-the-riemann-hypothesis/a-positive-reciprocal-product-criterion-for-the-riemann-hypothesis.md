# A Positive Reciprocal-Product Criterion for the Riemann Hypothesis

## Abstract

Define

\[
P(y)=
\frac{\lfloor y\rfloor(\lfloor y\rfloor+1)}{y^3}
\{y\}(1-\{y\}),\qquad y\ge1,
\]

and

\[
T(x)=\sum_{a,b\le\sqrt x}\mu(a)\mu(b)P\!\left(\frac{x}{ab}\right).
\]

The Riemann hypothesis is equivalent both to

\[
T(x)\ll_\varepsilon x^{1/2+\varepsilon}
\]

for every \(\varepsilon>0\), and to the corresponding dyadic mean-square
bound. The kernel is entrywise nonnegative and contains no asymptotic
remainder. It is nevertheless highly indefinite: along square primorials
both inertias grow at least as \(\log x/\log\log x\), while on a squarefree
primorial star the centered kernel has exact inertia \((1,m-2,0)\).
These are equivalent criteria and structural results, not a proof of RH.

## 1. Introduction

Square-root bounds for Möbius sums are classical reformulations of RH. Here
one such bound is converted into a finite reciprocal-product quadratic form
whose entries are nonnegative. The positivity is literal but is not positive
semidefiniteness; the construction therefore isolates, rather than solves,
the required signed cancellation.

Positive Farey quadratic forms give other RH criteria; see Kanemitsu and
Yoshimoto (1996). Statistical aspects of the Möbius sequence were studied by
Good and Churchhouse (1968). A targeted search completed on 14 August 2026
did not locate the kernel or exact double Möbius identity below. This bounded
search statement is not an absolute priority claim.

## 2. A zero-free Mellin detector

Let \(W\in BV(0,\infty)\) be supported in \((0,B]\) after zero extension.
Set

\[
U_W(x)=\sum_{n\ge1}\mu(n)W(n/x),\qquad
K_W(s)=\int_0^\infty W(t)t^{s-1}\,dt.
\]

For \(\Re s>1\), absolute convergence and \(t=n/x\) give

\[
\int_0^\infty U_W(x)x^{-s-1}\,dx
=\frac{K_W(s)}{\zeta(s)}.
\tag{2.1}
\]

**Detector theorem.** If

\[
K_W(s)\ne0\qquad(1/2<\Re s<1),
\tag{2.2}
\]

then RH is equivalent to

\[
\forall\varepsilon>0,\qquad
\int_Y^{2Y}|U_W(x)|^2\,dx
\ll_{W,\varepsilon}Y^{2+\varepsilon}
\qquad(Y\ge1).
\tag{2.3}
\]

**Proof.** RH gives

\[
M(X)=\sum_{n\le X}\mu(n)
=O_\delta(X^{1/2+\delta})
\]

for every \(\delta>0\). Abel summation, including all jumps in the total
variation of \(W\), yields

\[
|U_W(x)|\ll_W\sup_{n\le Bx}|M(n)|
\ll_{W,\delta}x^{1/2+\delta}.
\]

Taking \(\delta=\varepsilon/2\) proves (2.3).

Conversely, fix \(\sigma>1/2\) and choose
\(0<\varepsilon<2\sigma-1\). Dyadic summation gives

\[
\int_{1/B}^{\infty}|U_W(x)|^2x^{-2\sigma-1}\,dx<\infty.
\]

Cauchy–Schwarz makes the left side of (2.1), as a function of \(s\),
holomorphic on \(\Re s>1/2\). With \(Z(s)=(s-1)\zeta(s)\), continuation of

\[
Z(s)\int_0^\infty U_W(x)x^{-s-1}\,dx=(s-1)K_W(s)
\]

shows that a zero of \(\zeta\) in \(1/2<\Re s<1\) would force a zero of
\(K_W\) there, with at least the same multiplicity. This contradicts
(2.2). The classical zero-free half-plane \(\Re s\ge1\), the functional
equation, and the symmetry \(\rho\mapsto1-\overline\rho\) put every
nontrivial zero on the critical line. ∎

## 3. The endpoint-flat kernel

Define

\[
V(u)=
\begin{cases}
-2u+6u^2-4u^3,&0<u<1,\\
0,&\text{otherwise}.
\end{cases}
\]

Its zero extension is continuous and of bounded variation,
\(V(0+)=V(1-)=0\), and \(\int_0^1V=0\). Moreover,

\[
K_V(s)
=-\frac2{s+1}+\frac6{s+2}-\frac4{s+3}
=\frac{2(s-1)}{(s+1)(s+2)(s+3)},
\tag{3.1}
\]

which is zero-free in \(1/2<\Re s<1\).

**Faulhaber factorization.** For \(y\ge1\),

\[
\sum_{c\le y}V(c/y)=P(y)\ge0.
\tag{3.2}
\]

Indeed, writing \(N=\lfloor y\rfloor\) and \(r=\{y\}\), the first three
power-sum formulas give

\[
\sum_{c\le y}V(c/y)
=-\frac{N(N+1)}y
+\frac{N(N+1)(2N+1)}{y^2}
-\frac{N^2(N+1)^2}{y^3}.
\]

After factoring \(N(N+1)/y^3\), the remaining polynomial is

\[
-y^2+(2N+1)y-N(N+1)=r(1-r).
\]

## 4. Exact truncation and the RH criterion

For real \(x\ge1\), put

\[
\nu_x(n)=\mu(n)\mathbf1_{n\le\sqrt x}.
\]

For every integer \(n\le x\),

\[
\mu(n)=2\nu_x(n)-(\nu_x*\nu_x*1)(n).
\tag{4.1}
\]

To prove this, set \(z=\sqrt x\) and
\(r=\delta-\nu_x*1\). Then \(r(m)=0\) for every integer \(m\le z\).
If \(n\le z^2\), every factorization \(n=ab\) has \(a\le z\) or
\(b\le z\); hence \((r*r)(n)=0\). Since \(\mu*1=\delta\),

\[
0=(\mu*r*r)(n)
=\mu(n)-2\nu_x(n)+(\nu_x*\nu_x*1)(n).
\]

Let

\[
U(x)=\sum_n\mu(n)V(n/x).
\]

Multiplying (4.1) by \(V(n/x)\), summing, and using (3.2) gives

\[
U(x)=2A(x)-T(x),
\qquad
A(x)=\sum_{n\le\sqrt x}\mu(n)V(n/x).
\tag{4.2}
\]

There is no endpoint term because \(V(1)=0\). If
\(N=\lfloor\sqrt x\rfloor\), then

\[
|A(x)|
\le
\frac2x\sum_{n\le N}n
+\frac6{x^2}\sum_{n\le N}n^2
+\frac4{x^3}\sum_{n\le N}n^3
\le12.
\tag{4.3}
\]

Consequently,

\[
\boxed{|T(x)+U(x)|\le24\qquad(x\ge1).}
\tag{4.4}
\]

**Main theorem.** The following are equivalent:

1. RH;
2. for every \(\varepsilon>0\),
   \[
   T(x)\ll_\varepsilon x^{1/2+\varepsilon}\qquad(x\ge1);
   \]
3. for every \(\varepsilon>0\),
   \[
   \int_Y^{2Y}|T(x)|^2\,dx
   \ll_\varepsilon Y^{2+\varepsilon}\qquad(Y\ge1).
   \]

The detector theorem gives the mean-square equivalence for \(U\), and
(4.4) transfers it in both directions; the bounded error contributes only
\(O(Y)\) to the squared norm. RH also gives the pointwise bound for \(U\)
by Abel summation. Conversely, for a desired dyadic exponent \(\eta>0\),
apply the pointwise bound with \(\varepsilon=\eta/2\), square and integrate.

The quantifier “for every \(\varepsilon>0\)” is essential. The pointwise
and mean-square versions are separately equivalent through RH; no general
\(L^2\)-to-pointwise implication is asserted.

## 5. Spectral geometry

For \(1\le a,b\le\sqrt x\), write

\[
K_x(a,b)=P(x/(ab)),\qquad
C_x(a,b)=K_x(a,b)-\frac{ab}{6x}.
\]

The entrywise nonnegative matrix \(K_x\) is not generally positive
semidefinite. For every \(k\ge1\), the indices \((3k,2k)\) at
\(x=9k^2\) give the principal block

\[
\begin{pmatrix}
0&4/27\\
4/27&8/81
\end{pmatrix},
\qquad
\det=-\frac{16}{729}.
\tag{5.1}
\]

The indefiniteness has growing rank. Let \(p_1<\cdots<p_m\) be the first
\(m\) primes, \(Q=p_m^\#\), and \(x=Q^2\). On the indices

\[
a_k=p_k,\qquad b_k=p_k^2,
\]

all cross-block products divide \(Q^2\), so their kernel entries vanish.
The resulting principal submatrix is

\[
\bigoplus_{k=1}^m
\begin{pmatrix}0&c_k\\c_k&d_k\end{pmatrix},
\qquad c_k>0,\ d_k\ge0.
\]

Every block has one eigenvalue of each sign. Since \(C_x\) is obtained
there by subtracting a rank-one positive semidefinite matrix,

\[
n_\pm(K_x)\ge m,\qquad
n_-(C_x)\ge m,\qquad
n_+(C_x)\ge m-1.
\tag{5.2}
\]

As \(\log x=(2+o(1))m\log m\), both inertias grow at least as
\(\log x/\log\log x\) along this subsequence.

## 6. Exact squarefree centered inertia

Let \(x=p_m^\#\) and take the squarefree indices
\(a_j=2p_j\), \(2\le j\le m\). For \(m\ge6\), the corresponding
principal matrices satisfy

\[
\boxed{
(n_+,n_-,n_0)(K)
=(n_+,n_-,n_0)(C)
=(1,m-2,0).}
\tag{6.1}
\]

Indeed, with \(D_{jj}=p_j/\sqrt x\), the half-integer formula for \(P\)
and the diagonal calculation give

\[
K=D(J-E)D,
\qquad
C=D\left(\frac13J-E\right)D,
\tag{6.2}
\]

where \(J=\mathbf1\mathbf1^T\), \(E\succ0\),

\[
0<E_{jj}\le1,\qquad
\sum_{k\ne j}E_{jk}<p_m^{-2}.
\tag{6.3}
\]

Put \(n=m-1\) and \(q=\mathbf1^TE^{-1}\mathbf1\). Congruence by
\(E^{-1/2}\) turns the middle matrix for \(C\) into

\[
\frac13uu^T-I,\qquad u=E^{-1/2}\mathbf1.
\]

It has \(n-1\) negative eigenvalues, while the remaining sign is that of
\(q/3-1\). Cauchy–Schwarz and (6.3) give

\[
q\ge\frac{n^2}{\mathbf1^TE\mathbf1}
>\frac{n}{1+p_m^{-2}}
\ge\frac5{1+13^{-2}}>3.
\]

This proves (6.1) for \(C\); replacing \(1/3\) by \(1\) proves it for
\(K\).

## 7. Low-degree positivity cone

For

\[
V(u)=\sum_{k=1}^d v_ku^k,\qquad
V(0)=V(1)=\int_0^1V(u)\,du=0,
\]

put \(P_V(y)=\sum_{c\le y}V(c/y)\). For \(d=3\),

\[
P_V(y)\ge0\quad(y\ge1)
\iff v_3\le0.
\tag{7.1}
\]

For \(d=4\), the endpoint and mean constraints give

\[
v_1=\frac{v_3}{2}+\frac{4v_4}{5},
\qquad
v_2=-\frac{3v_3}{2}-\frac{9v_4}{5},
\]

and the exact classification is

\[
\boxed{
P_V(y)\ge0\quad(y\ge1)
\iff
v_4\ge0,\qquad
v_3\le-\frac{12}{5}v_4.}
\tag{7.2}
\]

Necessity follows from

\[
P_V(N)=\frac{v_4(N^2-1)}{30N^3}
\]

and the \(N=1,\ r\downarrow0\) boundary. For sufficiency write
\(v_4=w\ge0\), \(v_3=-12w/5-t\), \(t\ge0\). With \(y=N+r\), the
numerator of \(60P_V(N+r)(N+r)^4/[N(N+1)]\) becomes

\[
15tr(N+r)(1-r)
+w\bigl(2(N-1)+6r^2(3-2r)\bigr)\ge0.
\]

Thus endpoint flatness alone does not imply positivity. For example,

\[
V(u)=-\frac45u+\frac95u^2-u^4
\]

has zero endpoints and zero mean, but

\[
P_V(N)=-\frac{N^2-1}{30N^3}<0\qquad(N\ge2).
\]

## 8. Discussion

The main theorem replaces a one-dimensional Möbius detector by an exact
finite quadratic form with entrywise nonnegative kernel. The growing
inertia shows why this is not a positivity proof of RH. On genuine
squarefree Möbius support, a single collective positive mode is surrounded
by a codimension-one negative space. The unresolved problem is therefore
to control this highly indefinite form on the particular Möbius vector
while preserving cancellation between its collective and centered parts.

## References

1. I. J. Good and R. F. Churchhouse, “The Riemann hypothesis and
   pseudorandom features of the Möbius sequence,” *Math. Comp.* **22**
   (1968), 857–861. DOI: 10.1090/S0025-5718-1968-0240062-8.
2. S. Kanemitsu and M. Yoshimoto, “Farey series and the Riemann
   hypothesis,” *Acta Arith.* **75** (1996), 351–374.
   DOI: 10.4064/aa-75-4-351-374.
