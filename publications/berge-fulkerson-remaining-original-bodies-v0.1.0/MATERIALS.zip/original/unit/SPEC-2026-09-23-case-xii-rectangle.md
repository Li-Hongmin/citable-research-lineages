# Case-XII full-PM synchronized rectangle — bounded run (frozen 2026-09-23)

Main statement: for every rooted cubic five-pole with complete perfect-matching closure having exact Case-XII boundary support and the fixed Note-101 rows, at least one of the sixteen Note-104 contexts has the full-mask, same-K, prescribed-core, target-phase intersection of Note 109. A genuine counterexample requires complete PM enumeration and support certification; otherwise report the exact surviving boundary.

R1: Verify whether the proposed synchronized rectangle follows from actual graph-induced closure, not merely selected rows. First decisive observation: independently replay one small genuine pole's complete PM masks and evaluate all defined contexts; GO only with an all-orders argument, NOGO only with certified exact-Case-XII pole.
R2: Analyze the universal residual-component parity and full-mask coupling for one fixed context. First decisive observation: prove a cross-carrier identity or give an actual cubic-pole failure of that mechanism; close only that mechanism when it fails.
R3: If neither settles, test the least eligible exact-support candidate via authorized scheduler enumeration with a complete coverage certificate. GO/NOGO as above; finite nonhits are only order bounds.

Budget: three bounded pulses, no more than seven days. No local bulk enumeration, no inference from selected matchings, no OMEN/CBA, no public release or submission. Mathematical partial results remain scratch until independent verification.
