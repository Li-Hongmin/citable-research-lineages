# Actual full-closure carrier-fixed fibre

This bundle verifies the fixed cubic-pole counterexample in
[Note 088](../../../notes/088-full-perfect-matching-closure-does-not-force-global-avoider-carrier-entry.md).

`verify_actual_carrier_fixed_fibre.py` is a pure-standard-library verifier.
It hardcodes the thirteen-vertex pole, independently enumerates its complete
31-perfect-matching family, checks the displayed six-matching BF cover, and
exhausts every state-14 decomposition of the fixed \(S\)-half-load.  It asserts
that the oriented class-1 carrier fibre is the singleton \(\{M_0\}\), while
the complete class also contains the avoiding matching \(M_1\).

## Omen reproduction

Run one process:

```bash
python3 verify_actual_carrier_fixed_fibre.py
```

Environment: Python 3.10.12.  The frozen Omen run ended with
`ACTUAL_FULL_CLOSURE_CARRIER_FIXED_FIBRE_VERIFIED`; wall time was 0.03
seconds and peak resident memory was 10,496 kB.

Source SHA256:
`dbf51c6c5d9dfc5d7342faebc93cf02e7c2a8d6f2d0dd5668f328ddd99df44a1`.

## Scope

This is one fixed simple connected cubic five-pole, not an order census.
The program verifies complete PM closure for the carrier fibre and one
literal BF cover; the independent Note 007 certificate separately verifies
all 177 BF covers and the complete 40-type census.  The pole has an
all-terminal cover and forbidden \(T\)--\(T\) types, so it is not an
exact-Case-XII counterexample.
