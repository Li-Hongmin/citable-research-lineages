#!/usr/bin/env python3
"""Verify the fixed Note-007 carrier-fibre counterexample."""

import json


N = 13
PROPER = (
    (0, 2), (0, 11), (1, 11), (1, 12), (2, 12),
    (3, 9), (3, 10), (4, 8), (4, 9), (5, 7),
    (5, 8), (5, 11), (6, 7), (6, 10), (6, 12),
    (7, 9), (8, 10),
)
TERMINALS = tuple(range(5))
N_PROPER = len(PROPER)
N_EDGES = N_PROPER + len(TERMINALS)
ALL_VERTICES = (1 << N) - 1
NONTERMINALS = ALL_VERTICES ^ sum(1 << v for v in TERMINALS)


def graph_checks():
    assert len(PROPER) == len(set(PROPER))
    degrees = [0] * N
    adjacency = [[] for _ in range(N)]
    for u, v in PROPER:
        assert u != v
        degrees[u] += 1
        degrees[v] += 1
        adjacency[u].append(v)
        adjacency[v].append(u)
    for terminal in TERMINALS:
        degrees[terminal] += 1
    assert degrees == [3] * N
    seen = {0}
    stack = [0]
    while stack:
        for neighbour in adjacency[stack.pop()]:
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    assert len(seen) == N


def enumerate_perfect_matchings():
    endpoint_masks = tuple((1 << u) | (1 << v) for u, v in PROPER)
    occupied = [-1] * (1 << N_PROPER)
    occupied[0] = 0
    matchings = []
    for proper_mask in range(1 << N_PROPER):
        if proper_mask:
            low = proper_mask & -proper_mask
            edge = low.bit_length() - 1
            previous = proper_mask ^ low
            used = occupied[previous]
            endpoints = endpoint_masks[edge]
            if used < 0 or used & endpoints:
                continue
            used |= endpoints
            occupied[proper_mask] = used
        else:
            used = 0
        uncovered = ALL_VERTICES ^ used
        if uncovered & NONTERMINALS:
            continue
        semiedges = sum(
            1 << (N_PROPER + position)
            for position, terminal in enumerate(TERMINALS)
            if uncovered & (1 << terminal)
        )
        matchings.append(proper_mask | semiedges)
    assert len(matchings) == len(set(matchings)) == 31
    return tuple(sorted(matchings))


def boundary(matching):
    return (matching >> N_PROPER) & 0b11111


def vector(matching):
    return tuple((matching >> edge) & 1 for edge in range(N_EDGES))


def vector_sum(matchings):
    vectors = [vector(matching) for matching in matchings]
    return tuple(sum(v[edge] for v in vectors) for edge in range(N_EDGES))


def expected_matching(proper_ids, boundary_positions):
    mask = sum(1 << edge for edge in proper_ids)
    mask |= sum(1 << (N_PROPER + position - 1) for position in boundary_positions)
    return mask


def main():
    graph_checks()
    matchings = enumerate_perfect_matchings()
    expected = {
        0: expected_matching((2, 4, 6, 8, 10, 12), (1,)),
        1: expected_matching((2, 4, 5, 7, 9, 13), (1,)),
        4: expected_matching((0, 6, 7, 11, 14, 15), (2,)),
        9: expected_matching((0, 3, 8, 11, 12, 16), (4,)),
        25: expected_matching((1, 5, 9, 14, 16), (2, 3, 5)),
        29: expected_matching((1, 3, 10, 13, 15), (3, 4, 5)),
    }
    assert all(matchings[index] == matching for index, matching in expected.items())

    cover_indices = (0, 1, 4, 9, 25, 29)
    cover = tuple(matchings[index] for index in cover_indices)
    assert vector_sum(cover) == (2,) * N_EDGES
    assert [boundary(matching) for matching in cover] == [1, 1, 2, 8, 22, 28]

    half_indices = (25, 0, 9)
    half_load = vector_sum(tuple(matchings[index] for index in half_indices))
    assert half_load == (
        1, 1, 1, 1, 1, 1, 1, 0, 2, 1, 1, 1, 2, 0, 1, 0, 2,
        1, 1, 1, 1, 1,
    )

    class_1 = tuple(m for m in matchings if boundary(m) == 0b00001)
    class_4 = tuple(m for m in matchings if boundary(m) == 0b01000)
    triple_235 = tuple(m for m in matchings if boundary(m) == 0b10110)
    assert class_1 == (matchings[0], matchings[1])
    decompositions = [
        (q, p1, p4)
        for q in triple_235 for p1 in class_1 for p4 in class_4
        if vector_sum((q, p1, p4)) == half_load
    ]
    assert decompositions == [(matchings[25], matchings[0], matchings[9])]

    target_edge = 6
    assert matchings[0] >> target_edge & 1
    assert matchings[4] >> target_edge & 1
    assert not (matchings[1] >> target_edge & 1)
    assert matchings[1] in cover

    print(json.dumps({
        "vertices": N,
        "proper_edges": N_PROPER,
        "perfect_matchings": len(matchings),
        "cover_indices": cover_indices,
        "cover_boundaries": [1, 1, 2, 4, 235, 345],
        "half_indices": half_indices,
        "half_state": 14,
        "target_edge_id": target_edge,
        "target_edge": PROPER[target_edge],
        "carrier_decompositions": [[25, 0, 9]],
        "class_1_indices": [0, 1],
        "class_1_global_avoider": 1,
    }, indent=2, sort_keys=True))
    print("ACTUAL_FULL_CLOSURE_CARRIER_FIXED_FIBRE_VERIFIED")


if __name__ == "__main__":
    main()
