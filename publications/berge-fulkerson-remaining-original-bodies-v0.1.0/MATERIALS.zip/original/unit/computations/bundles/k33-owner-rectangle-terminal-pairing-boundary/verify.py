#!/usr/bin/env python3
"""Classify universal balances in the four-row K3,3 rectangle core.

This is a finite closure check for the single candidate specified in the
current pulse.  The four positive rows share literal singleton matchings
A,C,D and otherwise have private identities.  A ternary coordinate denotes
one K4 component: every matching chooses one of its three perfect matchings,
and a designated BF row is valid exactly when each symbol occurs twice.

The script enumerates every ternary assignment satisfying all four row
balances, then asks whether any available A/TT boundary tuple is valid for
every assignment and whether any two distinct matching pairs have universally
equal incidence sums.  A universal relation cannot be removed by adjoining
more K4 separator coordinates; a non-universal relation can.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations_with_replacement, product


IDS = (
    "A", "C", "D",
    "q24_0", "r15_0", "B_0",
    "q24_1", "r15_1", "B_1",
    "q13_0", "r45_0", "X_0",
    "q13_1", "r45_1", "X_1",
)

ROWS = (
    ("A", "C", "D", "q24_0", "r15_0", "B_0"),
    ("A", "C", "D", "q24_1", "r15_1", "B_1"),
    ("A", "C", "D", "q13_0", "r45_0", "X_0"),
    ("A", "C", "D", "q13_1", "r45_1", "X_1"),
)

BOUNDARY = {
    "A": (1,), "B_0": (2,), "B_1": (2,),
    "X_0": (3,), "X_1": (3,), "C": (4,), "D": (5,),
    "q24_0": (1, 3, 5), "q24_1": (1, 3, 5),
    "r15_0": (2, 3, 4), "r15_1": (2, 3, 4),
    "q13_0": (2, 4, 5), "q13_1": (2, 4, 5),
    "r45_0": (1, 2, 3), "r45_1": (1, 2, 3),
}

SINGLETON = {
    1: ("A",), 2: ("B_0", "B_1"), 3: ("X_0", "X_1"),
    4: ("C",), 5: ("D",),
}
T_TRIPLE = {
    (1, 5): ("r15_0", "r15_1"),
    (4, 5): ("r45_0", "r45_1"),
}


def permutation_matching(word):
    return frozenset((i, int(value)) for i, value in enumerate(word))


K33 = frozenset(product(range(3), repeat=2))
K33_LOCAL = {
    name: permutation_matching(word)
    for name, word in {
        "A": "012", "C": "120", "D": "201",
        "B_0": "012", "B_1": "120",
        "X_0": "021", "X_1": "102", "Y": "210",
    }.items()
}


def balanced_six(values):
    return sorted(values) == [0, 0, 1, 1, 2, 2]


def capacity_five(values):
    counts = Counter(values)
    return max(counts.values(), default=0) <= 2


def assignments():
    """Generate all assignments without a 3^15 ambient scan."""
    triples = tuple(product(range(3), repeat=3))
    for owner_values in triples:
        needed = Counter({0: 2, 1: 2, 2: 2})
        needed.subtract(owner_values)
        if min(needed.values()) < 0:
            continue
        carrier_values = tuple(
            value_tuple for value_tuple in triples
            if Counter(value_tuple) == +needed
        )
        for four in product(carrier_values, repeat=4):
            values = dict(zip(("A", "C", "D"), owner_values))
            for row, chosen in zip(ROWS, four):
                values.update(zip(row[3:], chosen))
            assert all(balanced_six([values[x] for x in row]) for row in ROWS)
            yield values


def pair_signature(values, pair):
    return tuple(sorted((values[pair[0]], values[pair[1]])))


def boundary_pair(pair):
    return tuple(sorted((BOUNDARY[pair[0]], BOUNDARY[pair[1]])))


def main():
    # Choose the companion phases so that the bichromatic pairs controlling
    # pi_B and pi_X are closed inside the K3,3 block.  The cut/attachment edge
    # is (0,2); only the other companion (D or Y) uses it.
    local_carrier_rows = (
        ("C", "D", "B_0"),
        ("A", "D", "B_1"),
        ("X_1", "Y", "X_0"),
        ("X_0", "Y", "X_1"),
    )
    for row in local_carrier_rows:
        counts = Counter(edge for name in row for edge in K33_LOCAL[name])
        assert all(counts[edge] == 1 for edge in K33)
    pairing_pairs = (
        ("C", "B_0"), ("A", "B_1"),
        ("X_1", "X_0"), ("X_0", "X_1"),
    )
    for left, right in pairing_pairs:
        difference = K33_LOCAL[left] ^ K33_LOCAL[right]
        assert (0, 2) not in difference
        degree = Counter(vertex for edge in difference for vertex in ((0, edge[0]), (1, edge[1])))
        assert degree and set(degree.values()) == {2}

    all_assignments = tuple(assignments())
    assert len(all_assignments) == 9234

    a_tuples = tuple(
        ("A", b, x, "C", "D")
        for b in SINGLETON[2] for x in SINGLETON[3]
    )
    universal_a = tuple(
        row for row in a_tuples
        if all(capacity_five([values[x] for x in row])
               for values in all_assignments)
    )

    tt_tuples = []
    for left, right in combinations_with_replacement(sorted(T_TRIPLE), 2):
        singleton_slots = left + right
        singleton_choices = product(*(SINGLETON[i] for i in singleton_slots))
        for q in T_TRIPLE[left]:
            for r in T_TRIPLE[right]:
                for singles in singleton_choices:
                    tt_tuples.append((q, r) + tuple(singles))
                singleton_choices = product(*(SINGLETON[i] for i in singleton_slots))
    # Remove exact duplicate multisets caused by repeated singleton slots.
    tt_tuples = tuple(sorted({tuple(sorted(row)) for row in tt_tuples}))
    universal_tt = tuple(
        row for row in tt_tuples
        if all(balanced_six([values[x] for x in row])
               for values in all_assignments)
    )

    pairs = tuple(combinations_with_replacement(IDS, 2))
    signatures = {
        pair: tuple(pair_signature(values, pair) for values in all_assignments)
        for pair in pairs
    }
    buckets = defaultdict(list)
    for pair, signature in signatures.items():
        buckets[signature].append(pair)
    equalities = []
    boundary_changing = []
    for bucket in buckets.values():
        if len(bucket) < 2:
            continue
        for i, left in enumerate(bucket):
            for right in bucket[i + 1:]:
                record = (left, right)
                equalities.append(record)
                if boundary_pair(left) != boundary_pair(right):
                    boundary_changing.append(record)

    print("assignments", len(all_assignments))
    print("K33_local_carrier_rows", local_carrier_rows)
    print("K33_pairing_components_closed", pairing_pairs)
    print("A_candidates", len(a_tuples), "universal", universal_a)
    print("TT_candidates", len(tt_tuples), "universal", universal_tt)
    print("universal_pair_equalities", len(equalities))
    print("boundary_changing_pair_equalities", len(boundary_changing))
    for left, right in boundary_changing:
        print("EQUAL", left, boundary_pair(left), "=", right, boundary_pair(right))
    print("K33_CORE_UNIVERSAL_BALANCES_CLASSIFIED")


if __name__ == "__main__":
    main()

