# $K_{3,3}$ owner-rectangle terminal-pairing boundary

This bundle supports [Note 098](../../../notes/098-exact-no-tt-terminal-pairings-do-not-break-the-k33-owner-rectangle.md).  It checks the four explicit $K_{3,3}$ carrier decompositions and exhausts all balanced $K_4$ coordinates for the four repeated-star rows.

Run from the repository root:

```bash
python3 units/berge-fulkerson/computations/bundles/k33-owner-rectangle-terminal-pairing-boundary/verify.py
```

The final line must be

```text
K33_CORE_UNIVERSAL_BALANCES_CLASSIFIED
```

`expected-output.txt` is the frozen stdout of the final Omen run.  That run used Python 3.10.12, one process, a 1 GiB virtual-memory cap, 0.32 seconds wall time and 93,696 KiB maximum resident memory.  The calculation classifies one fixed four-row core; it is not a graph search or a census of five-poles.
