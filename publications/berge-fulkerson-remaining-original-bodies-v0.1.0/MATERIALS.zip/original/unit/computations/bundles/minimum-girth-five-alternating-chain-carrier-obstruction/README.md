# Minimum girth-five alternating-chain carrier obstruction

This bundle verifies the finite part of
[Note 089](../../../notes/089-girth-five-single-carrier-saturation-does-not-force-fibre-flexibility.md).
It exhausts the prescribed path-plus-perfect-matching alternating-chain
family through its first short-cycle-free member, constructs the resulting
cubic five-pole, enumerates its complete perfect-matching family, and checks
the two complementary half-loads and the carrier-fixed/global-avoider
certificate.

The scope is only this alternating-chain family.  The calculation neither
enumerates all cubic two-poles nor asserts that the resulting pole has exact
Case-XII forty-type support.

## Reproduction

The frozen source was run in one Python process on host `omen`:

```bash
python3 -u search_girth5_alternating_chain_carrier.py \
  --max-m 6 --json result.json
```

The final marker is

```text
GIRTH5_ALTERNATING_CHAIN_CARRIER_CERTIFICATE_FOUND
```

The captured `/usr/bin/time -v` record reports 0.03 seconds wall time and
12,032 kB maximum resident memory.

## SHA-256

```text
db25c9de5771c70e49c75f084015981119335f553c7fa7fc83622ac524f68f3a  search_girth5_alternating_chain_carrier.py
a549c665d57b4fced5f6cd349ca3f472cd4c5878912bf3d7349c8516af60b1fa  result.json
f86c72c326c49a6d1525509eacd25dae6b79bf4b61291e46f2aeb8653c7fbe4f  omen-run.log
```
