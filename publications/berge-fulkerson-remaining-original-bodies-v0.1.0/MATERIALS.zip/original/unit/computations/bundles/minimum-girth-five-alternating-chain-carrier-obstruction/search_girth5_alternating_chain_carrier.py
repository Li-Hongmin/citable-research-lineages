#!/usr/bin/env python3
"""Exhaust the prescribed alternating-chain family through its first witness."""

import argparse
import json
from collections import defaultdict, deque
from pathlib import Path

S = {(0, 2), (0, 3), (1, 3), (1, 4), (2, 4)}
STATE13 = (0, 2)
TERMINAL_ORDER = (1, 3, 5, 2, 4)


def b_matchings(vertices):
    path = {v: set() for v in vertices}
    for u, v in zip(vertices, vertices[1:]):
        path[u].add(v)
        path[v].add(u)

    def short_path(u, v):
        queue = deque([(u, 0)])
        seen = {u}
        while queue:
            x, d = queue.popleft()
            if d == 3:
                continue
            for y in path[x]:
                if y == v:
                    return True
                if y not in seen:
                    seen.add(y)
                    queue.append((y, d + 1))
        return False

    def rec(unmatched, chosen):
        if not unmatched:
            yield tuple(chosen)
            return
        u = unmatched[0]
        for j in range(1, len(unmatched)):
            v = unmatched[j]
            if short_path(u, v):
                continue
            path[u].add(v)
            path[v].add(u)
            chosen.append((u, v))
            yield from rec(unmatched[1:j] + unmatched[j + 1:], chosen)
            chosen.pop()
            path[u].remove(v)
            path[v].remove(u)

    yield from rec(tuple(vertices), [])


def pole(m, b_edges):
    z = tuple(range(5, 5 + 2 * m))
    a_edges = tuple((z[i], z[i + 1]) for i in range(0, 2 * m, 2))
    c_edges = ((0, z[0]),) + tuple(
        (z[i], z[i + 1]) for i in range(1, 2 * m - 1, 2)
    ) + ((z[-1], 1),)
    outer = ((1, 2), (2, 3), (3, 4), (0, 4))
    terminals = [None] * 5
    for vertex, label in enumerate(TERMINAL_ORDER):
        terminals[label - 1] = vertex
    norm = lambda edges: tuple(tuple(sorted(e)) for e in edges)
    return {"vertices": tuple(range(5 + 2 * m)),
            "proper": norm(outer + a_edges + c_edges + tuple(b_edges)),
            "terminals": tuple(terminals), "a": norm(a_edges),
            "b": norm(b_edges), "c": norm(c_edges)}


def graph_girth(vertices, edges):
    graph = {v: set() for v in vertices}
    for u, v in edges:
        graph[u].add(v)
        graph[v].add(u)
    best = 10**9
    for removed_u, removed_v in edges:
        queue = deque([(removed_u, 0)])
        seen = {removed_u}
        while queue:
            u, d = queue.popleft()
            for v in graph[u]:
                if {u, v} == {removed_u, removed_v}:
                    continue
                if v == removed_v:
                    best = min(best, d + 2)
                    queue.clear()
                    break
                if v not in seen:
                    seen.add(v)
                    queue.append((v, d + 1))
    return best


def validate(data):
    assert len(data["proper"]) == len(set(data["proper"]))
    degree = {v: 0 for v in data["vertices"]}
    for u, v in data["proper"]:
        assert u != v
        degree[u] += 1
        degree[v] += 1
    for v in data["terminals"]:
        degree[v] += 1
    assert set(degree.values()) == {3}
    return graph_girth(data["vertices"], data["proper"])


def perfect_matchings(data):
    ends = list(data["proper"]) + [(v, None) for v in data["terminals"]]
    incident = {v: [] for v in data["vertices"]}
    for edge, (u, v) in enumerate(ends):
        incident[u].append((edge, v))
        if v is not None:
            incident[v].append((edge, u))
    answer = []

    def rec(open_vertices, mask):
        if not open_vertices:
            answer.append(mask)
            return
        u = min(open_vertices)
        for edge, v in incident[u]:
            if v is not None and v not in open_vertices:
                continue
            remaining = open_vertices - {u}
            if v is not None:
                remaining.remove(v)
            rec(remaining, mask | (1 << edge))

    rec(set(data["vertices"]), 0)
    return tuple(sorted(answer))


def decomposition_groups(pms, proper_count, target):
    edge_count = proper_count + 5
    vectors = tuple(tuple((pm >> e) & 1 for e in range(edge_count)) for pm in pms)
    boundary = tuple((pm >> proper_count) & 31 for pm in pms)
    classes = defaultdict(list)
    for i, mask in enumerate(boundary):
        classes[mask].append(i)
    groups = {}
    for i in range(5):
        for j in range(i + 1, 5):
            state = (i, j)
            ds = []
            for q in classes[31 ^ (1 << i) ^ (1 << j)]:
                for p_i in classes[1 << i]:
                    for p_j in classes[1 << j]:
                        d = (q, p_i, p_j)
                        load = tuple(sum(vectors[p][e] for p in d)
                                     for e in range(edge_count))
                        if load == target:
                            ds.append(d)
            if ds:
                groups[state] = tuple(ds)
    return groups, vectors, boundary


def pm_record(data, pms, index):
    proper_count = len(data["proper"])
    ids = [e for e in range(proper_count) if pms[index] >> e & 1]
    return {"index": index, "proper_edge_ids": ids,
            "proper_edges": [list(data["proper"][e]) for e in ids],
            "boundary": [i + 1 for i in range(5)
                         if pms[index] >> (proper_count + i) & 1]}


def check(m, b_edges):
    data = pole(m, b_edges)
    if validate(data) < 5:
        return None
    edge_index = {edge: i for i, edge in enumerate(data["proper"])}
    a_ids = tuple(edge_index[e] for e in data["a"])
    b_ids = tuple(edge_index[e] for e in data["b"])
    a_load = tuple(2 if e in a_ids else 0 if e in b_ids else 1
                   for e in range(len(data["proper"]))) + (1,) * 5
    b_load = tuple(2 - x for x in a_load)
    pms = perfect_matchings(data)
    a_groups, vectors, boundaries = decomposition_groups(pms, len(data["proper"]), a_load)
    if set(a_groups) != S:
        return None
    b_groups, _, _ = decomposition_groups(pms, len(data["proper"]), b_load)
    fibre = tuple(sorted({d[1] for d in a_groups[STATE13]}))
    for edge in a_ids:
        if not all(vectors[p][edge] for p in fibre):
            continue
        a_options = [d for d in a_groups[STATE13] if vectors[d[2]][edge]]
        b_options = []
        for state, ds in b_groups.items():
            if 0 not in state:
                continue
            role = 1 if state[0] == 0 else 2
            b_options.extend((state != STATE13, state, d, d[role]) for d in ds
                             if not vectors[d[role]][edge])
        if not a_options or not b_options:
            continue
        a_witness = min(a_options)
        _, b_state, b_witness, avoider = min(b_options)
        row = a_witness + b_witness
        assert tuple(sum(vectors[p][e] for p in row) for e in range(len(a_load))) == (2,) * len(a_load)
        overload = tuple(p for p in a_witness if boundaries[p].bit_count() == 1
                         and vectors[p][edge])
        assert {boundaries[p].bit_length() - 1 for p in overload} == {0, 2}
        rec = lambda p: pm_record(data, pms, p)
        return {"m": m, "order": len(data["vertices"]),
                "girth": validate(data), "terminal_cyclic_order": list(TERMINAL_ORDER),
                "proper_edges": [list(e) for e in data["proper"]],
                "terminal_vertices_by_label": list(data["terminals"]),
                "a_edges": [list(e) for e in data["a"]],
                "b_edges": [list(e) for e in data["b"]],
                "common_c_edges": [list(e) for e in data["c"]],
                "a_load": list(a_load), "b_load": list(b_load),
                "perfect_matching_count": len(pms),
                "a_all_decompositions_by_state": {
                    "".join(str(x + 1) for x in state): [[rec(p) for p in d] for d in ds]
                    for state, ds in sorted(a_groups.items())},
                "b_complete_state_set": ["".join(str(x + 1) for x in state)
                                         for state in sorted(b_groups)],
                "a_state13_witness": [rec(p) for p in a_witness],
                "a_state13_class1_fibre": [rec(p) for p in fibre],
                "fixed_overload_edge_id": edge,
                "fixed_overload_edge": list(data["proper"][edge]),
                "row_overload_users": [rec(p) for p in overload],
                "b_avoider_state": "".join(str(x + 1) for x in b_state),
                "b_complementary_witness": [rec(p) for p in b_witness],
                "b_same_class_global_avoider": rec(avoider),
                "bf_row": [rec(p) for p in row]}
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-m", type=int, default=6)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    stats, certificate = [], None
    for m in range(2, args.max_m + 1):
        vertices = tuple(range(5, 5 + 2 * m))
        count = 0
        for pairing in b_matchings(vertices):
            count += 1
            certificate = check(m, pairing)
            if certificate:
                break
        stats.append({"m": m, "short_cycle_free_pairings_seen": count})
        if certificate:
            break
    result = {"status": "found" if certificate else "none_in_range",
              "searched_m_range": [2, args.max_m], "statistics": stats,
              "certificate": certificate}
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    summary = dict(result)
    if certificate:
        summary["certificate"] = {k: certificate[k] for k in (
            "m", "order", "girth", "b_edges", "perfect_matching_count",
            "b_complete_state_set", "fixed_overload_edge_id",
            "fixed_overload_edge", "b_avoider_state")}
        summary["certificate"]["a_state_set"] = sorted(certificate["a_all_decompositions_by_state"])
        summary["certificate"]["fibre_indices"] = [p["index"] for p in certificate["a_state13_class1_fibre"]]
        summary["certificate"]["avoider_index"] = certificate["b_same_class_global_avoider"]["index"]
    print(json.dumps(summary, indent=2, sort_keys=True))
    print("GIRTH5_ALTERNATING_CHAIN_CARRIER_CERTIFICATE_FOUND" if certificate
          else "NO_GIRTH5_ALTERNATING_CHAIN_CARRIER_CERTIFICATE_IN_RANGE")


if __name__ == "__main__":
    main()
