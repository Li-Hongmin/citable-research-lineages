#!/usr/bin/env python3
"""Read-only verifier for carrier-fixed coordinates in the Note 085 model."""

import argparse
import importlib.util
import json
from itertools import combinations
from pathlib import Path


SEMIEDGE_COUNT = 5


def load_module(path):
    spec = importlib.util.spec_from_file_location("note085_model", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def vector_sum(vectors, tokens):
    width = len(next(iter(vectors.values())))
    return tuple(sum(vectors[token][i] for token in tokens) for i in range(width))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("model_script", type=Path)
    args = parser.parse_args()

    payload = json.loads(args.input_json.read_text())
    module = load_module(args.model_script)
    builder = module.ModelBuilder().build()
    vectors = {
        token: tuple(int(bit) for bit in bits)
        for token, bits in payload["vectors"].items()
    }
    assert payload["status"] == "common_binary_countermodel"
    assert payload["tokens"] == len(vectors) == 125
    assert payload["coordinates"] == 48
    assert set(vectors) == set(builder.kind)

    classes = {
        i: tuple(token for token in sorted(vectors)
                 if builder.kind[token] == "singleton" and builder.boundary[token] == i)
        for i in range(1, 6)
    }
    fixed_sets = {
        i: tuple(c for c in range(SEMIEDGE_COUNT, 48)
                 if all(vectors[token][c] for token in tokens))
        for i, tokens in classes.items()
    }
    assert all(not fixed_sets[i] for i in range(1, 6))
    assert all(not (set(fixed_sets[i]) & set(fixed_sets[j]))
               for i, j in combinations(range(1, 6), 2))

    tested = []
    carrier_fixed = []
    for row_index, ((state, t_state), _) in enumerate(module.LITERAL_SEEDS.items()):
        row = builder.st_base[(state, t_state)]
        left = tuple(row[:3])
        half_load = vector_sum(vectors, left)
        triple_pool = tuple(token for token in sorted(vectors)
                            if builder.kind[token] == "triple"
                            and builder.boundary[token] == state)
        first, second = state
        decompositions = [
            (q, p, r)
            for q in triple_pool for p in classes[first] for r in classes[second]
            if vector_sum(vectors, (q, p, r)) == half_load
        ]
        assert decompositions
        singleton_occurrences = [token for token in left
                                 if builder.kind[token] == "singleton"]
        row_singletons = [token for token in row
                          if builder.kind[token] == "singleton"]
        for source in singleton_occurrences:
            source_class = builder.boundary[source]
            role = 1 if source_class == first else 2
            for coordinate in range(SEMIEDGE_COUNT, 48):
                if not vectors[source][coordinate]:
                    continue
                users = [token for token in row_singletons
                         if vectors[token][coordinate]]
                if len({builder.boundary[token] for token in users}) < 2:
                    continue
                avoiders = [token for token in classes[source_class]
                            if not vectors[token][coordinate]]
                assert avoiders
                fibre = sorted({decomposition[role] for decomposition in decompositions})
                record = {
                    "row_index": row_index,
                    "row": f"{state}-{t_state}",
                    "left_tokens": list(left),
                    "half_load": "".join(map(str, half_load)),
                    "coordinate": coordinate,
                    "coordinate_name": payload["coordinate_names"][coordinate],
                    "source": source,
                    "source_class": source_class,
                    "row_singleton_users": users,
                    "global_avoiders": avoiders,
                    "decompositions": [list(item) for item in decompositions],
                    "source_class_carrier_fibre": fibre,
                }
                tested.append(record)
                if all(vectors[token][coordinate] for token in fibre):
                    carrier_fixed.append(record)

    carrier_fixed.sort(key=lambda item: (
        len(item["decompositions"]), len(item["source_class_carrier_fibre"]),
        item["row_index"], item["coordinate"], item["source_class"],
    ))
    assert len(tested) == 75
    assert len(carrier_fixed) == 41
    witness = carrier_fixed[0]
    assert witness["row"] == "(1, 4)-(2, 3)"
    assert witness["left_tokens"] == ["q14", "A", "C"]
    assert witness["coordinate"] == 29
    assert witness["coordinate_name"] == "overload:ACXY"
    assert witness["source"] == "A" and witness["source_class"] == 1
    assert witness["source_class_carrier_fibre"] == [
        "A", "transport:(2, 4):(2, 3):b0"
    ]
    assert "transport:(2, 4):(2, 3):b1" in witness["global_avoiders"]

    print(json.dumps({
        "tokens": len(vectors),
        "coordinates": payload["coordinates"],
        "global_class_fixed_sets": fixed_sets,
        "tested_cases": len(tested),
        "carrier_fixed_cases": len(carrier_fixed),
        "witness": witness,
    }, indent=2, sort_keys=True))
    print("GLOBAL_FLEXIBILITY_DOES_NOT_FORCE_CARRIER_ENTRY_VERIFIED")


if __name__ == "__main__":
    main()
