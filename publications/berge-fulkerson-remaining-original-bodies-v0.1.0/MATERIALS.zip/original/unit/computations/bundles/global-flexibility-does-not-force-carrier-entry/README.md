# Global class flexibility does not force carrier entry

This bundle verifies the fixed common-binary countermodel used in
[Note 087](../../../notes/087-carrier-entry-is-residual-parity-and-is-not-forced-by-global-class-flexibility.md).

`check_carrier_fixed_coordinates.py` reads, but does not modify or
resynthesize, the frozen 125-token model of the
[Note 085 bundle](../joint-carrier-common-binary-countermodel/README.md).  It
enumerates all same-state three-token decompositions of the four canonical
pivot half-loads.  It asserts empty global proper-coordinate fixed sets,
75 relevant singleton/overload cases, 41 carrier-fixed cases, and the
explicit \((14,23)\), coordinate-29 witness in Note 087.

## Omen reproduction

From this bundle directory, run one process:

```bash
python3 check_carrier_fixed_coordinates.py \
  ../joint-carrier-common-binary-countermodel/joint_carrier_common_binary_result.json \
  ../joint-carrier-common-binary-countermodel/synthesize_joint_carrier_guard_model.py
```

Environment: Python 3.10.12 and Z3 5.1.0.  The frozen Omen run ended with
`GLOBAL_FLEXIBILITY_DOES_NOT_FORCE_CARRIER_ENTRY_VERIFIED`; wall time was
0.13 seconds and peak resident memory was 20,900 kB.

Source SHA256:
`109c48862a5af145583f0818c6acd88bdaab4f8935510fea88670a0483a51245`.

## Scope

This exhausts decompositions inside one fixed common-binary token pool.  It
does not search or represent cubic graphs, alternating components, or a
graph-induced full perfect-matching closure.  The residual parity criterion
in Note 087 is analytic and does not depend on this calculation.
