#!/usr/bin/env python3
"""Targeted order-nine search for one exact-negative common carrier.

The base B colouring fixes the terminal-copy loads (1,2,2,1,1).  For each
colour, all remaining vertex stubs are paired.  The resulting uncoloured
copy-multigraph is classified by its complete proper three-edge-colouring
relation, stopping a configuration as soon as an A or TT pattern appears.
If a B/X exact-negative carrier appears, its complementary A+C+D load is
tested for a consistent embedding in a simple connected cubic five-pole.
"""

from collections import Counter, defaultdict
from itertools import product
import json


ORDER = 9
S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}
B_PATTERN = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
X_PATTERN = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
TERMINAL = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5}
TERMINAL_COLOURS = {
    0: {0},
    1: {1, 2},
    2: {0, 1},
    3: {1},
    4: {0},
}
TERMINAL_OWNER = {1: 0, 4: 1, 5: 2}


def pairings(vertices):
    vertices = tuple(vertices)
    if not vertices:
        yield tuple()
        return
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        rest = vertices[1:index] + vertices[index + 1:]
        for following in pairings(rest):
            yield tuple(sorted(((min(first, second), max(first, second)), *following)))


def configurations():
    internal_by_colour = {
        colour: tuple(
            vertex for vertex in range(ORDER)
            if colour not in TERMINAL_COLOURS.get(vertex, set())
        )
        for colour in range(3)
    }
    raw = 1
    pairing_families = []
    for colour in range(3):
        family = tuple(pairings(internal_by_colour[colour]))
        pairing_families.append(family)
        raw *= len(family)
    seen = set()
    for selected in product(*pairing_families):
        edges = tuple(sorted(edge for matching in selected for edge in matching))
        multiplicity = Counter(edges)
        if max(multiplicity.values()) > 2 or edges in seen:
            continue
        seen.add(edges)
        yield raw, edges


def support_connected(proper_edges):
    adjacency = {vertex: set() for vertex in range(ORDER)}
    for u, v in proper_edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in adjacency[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    return len(seen) == ORDER


def bridge_free(proper_edges):
    edges = tuple(sorted(set(proper_edges)))
    for removed in edges:
        if not support_connected(edge for edge in edges if edge != removed):
            return False
    return True


def negative_category(pattern):
    sizes = sorted(map(len, pattern))
    if sizes == [1, 1, 5]:
        return "A"
    assert sizes == [1, 3, 3]
    states = tuple(sorted(
        tuple(sorted(set(range(1, 6)) - set(boundary)))
        for boundary in pattern if len(boundary) == 3
    ))
    return "TT" if all(state in T for state in states) else None


def relation_without_forbidden(edges):
    """Return the full relation, or None immediately after the first A/TT."""
    used = [set() for _ in range(ORDER)]
    colours = [-1] * len(edges)
    patterns = set()
    b_matchings = set()
    x_matchings = set()
    rows = set()
    forbidden = None
    leaves = 0

    def record():
        nonlocal forbidden, leaves
        leaves += 1
        boundary = {colour: [] for colour in range(3)}
        objects = {colour: set() for colour in range(3)}
        for edge, colour in zip(edges, colours):
            objects[colour].add(edge)
        for vertex, terminal in TERMINAL.items():
            missing = tuple(colour for colour in range(3) if colour not in used[vertex])
            expected = 2 if terminal in (2, 3) else 1
            assert len(missing) == expected
            for colour in missing:
                boundary[colour].append(terminal)
                objects[colour].add(("s", terminal))
        boundary = {colour: tuple(sorted(values)) for colour, values in boundary.items()}
        pattern = tuple(sorted(boundary.values()))
        category = negative_category(pattern)
        if category is not None:
            forbidden = {"category": category, "pattern": pattern}
            return
        patterns.add(pattern)
        row = tuple(sorted(
            ((boundary[colour], frozenset(objects[colour])) for colour in range(3)),
            key=lambda item: item[0],
        ))
        rows.add(row)
        if pattern == B_PATTERN:
            b_matchings.update(
                frozenset(objects[colour])
                for colour in range(3) if boundary[colour] == (2,)
            )
        if pattern == X_PATTERN:
            x_matchings.update(
                frozenset(objects[colour])
                for colour in range(3) if boundary[colour] == (3,)
            )

    def rec(index):
        if forbidden is not None:
            return
        if index == len(edges):
            record()
            return
        u, v = edges[index]
        options = (0,) if index == 0 else range(3)
        for colour in options:
            if colour in used[u] or colour in used[v]:
                continue
            if index and edges[index] == edges[index - 1] and colour <= colours[index - 1]:
                continue
            colours[index] = colour
            used[u].add(colour)
            used[v].add(colour)
            rec(index + 1)
            used[u].remove(colour)
            used[v].remove(colour)
            colours[index] = -1
            if forbidden is not None:
                return

    rec(0)
    if forbidden is not None:
        return None, forbidden, leaves
    assert b_matchings
    return {
        "patterns": patterns,
        "B": b_matchings,
        "X": x_matchings,
        "rows": rows,
        "labelled_leaves": leaves,
    }, None, leaves


def perfect_pairing(vertices, forbidden_edges):
    vertices = tuple(sorted(vertices))
    if not vertices:
        return tuple()
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        edge = (first, second)
        if edge in forbidden_edges:
            continue
        rest = vertices[1:index] + vertices[index + 1:]
        following = perfect_pairing(rest, forbidden_edges)
        if following is not None:
            return (edge, *following)
    return None


def complementary_embedding(edges):
    """Find one owner-consistent simple connected cubic five-pole."""
    multiplicity = Counter(edges)
    proper_support = set(multiplicity)
    incident = defaultdict(list)
    for edge, count in multiplicity.items():
        u, v = edge
        incident[u].append((edge, count))
        incident[v].append((edge, count))
    for vertex, terminal in TERMINAL.items():
        count = 2 if terminal in (2, 3) else 1
        incident[vertex].append((("s", terminal), count))
    assert all(sum(count for _, count in incident[vertex]) == 3
               for vertex in range(ORDER))

    single_proper = tuple(sorted(edge for edge, count in multiplicity.items() if count == 1))
    for values in product(range(3), repeat=len(single_proper)):
        owner = dict(zip(single_proper, values))
        owner.update({("s", terminal): value
                      for terminal, value in TERMINAL_OWNER.items()})
        deficits = defaultdict(list)
        valid = True
        for vertex in range(ORDER):
            local = incident[vertex]
            profile = sorted(count for _, count in local)
            if profile == [1, 1, 1]:
                if {owner[obj] for obj, _ in local} != {0, 1, 2}:
                    valid = False
                    break
            else:
                assert profile == [1, 2]
                single = next(obj for obj, count in local if count == 1)
                deficits[owner[single]].append(vertex)
        if not valid or any(len(vertices) % 2 for vertices in deficits.values()):
            continue
        invisible = []
        for colour in range(3):
            selected = perfect_pairing(deficits[colour], proper_support)
            if selected is None:
                valid = False
                break
            invisible.extend(selected)
        if not valid:
            continue
        underlying = tuple(sorted((*proper_support, *invisible)))
        if len(set(underlying)) != len(underlying) or not support_connected(underlying):
            continue
        assert len(underlying) == (3 * ORDER - len(TERMINAL)) // 2
        degrees = Counter()
        for u, v in underlying:
            assert u != v
            degrees[u] += 1
            degrees[v] += 1
        for vertex in TERMINAL:
            degrees[vertex] += 1
        assert all(degrees[vertex] == 3 for vertex in range(ORDER))

        fixed = [set() for _ in range(3)]
        for obj, colour in owner.items():
            fixed[colour].add(obj)
        for edge in invisible:
            missing_owner = next(
                colour for colour, vertices in deficits.items()
                if edge[0] in vertices
            )
            for colour in range(3):
                if colour != missing_owner:
                    fixed[colour].add(edge)

        for colour in range(3):
            degrees = Counter()
            for obj in fixed[colour]:
                if obj[0] == "s":
                    vertex = next(v for v, terminal in TERMINAL.items()
                                  if terminal == obj[1])
                    degrees[vertex] += 1
                else:
                    u, v = obj
                    degrees[u] += 1
                    degrees[v] += 1
            assert all(degrees[vertex] == 1 for vertex in range(ORDER))
        return {
            "owners": owner,
            "invisible_edges": tuple(sorted(invisible)),
            "underlying_proper_edges": underlying,
            "underlying_connected": True,
            "underlying_bridge_free": bridge_free(underlying),
            "fixed_matchings": tuple(frozenset(matching) for matching in fixed),
        }
    return None


def printable_object(obj):
    if obj[0] == "s":
        return f"s{obj[1]}"
    return f"{obj[0]}-{obj[1]}"


def printable_matching(matching):
    return tuple(sorted(printable_object(obj) for obj in matching))


def printable_row(row):
    return tuple(
        {
            "boundary": boundary,
            "matching": printable_matching(matching),
        }
        for boundary, matching in row
    )


def main():
    counts = Counter()
    raw_total = None
    first_exact = None
    first_embedded = None
    leaves = 0
    for raw, edges in configurations():
        raw_total = raw
        counts["distinct_configurations"] += 1
        counts["K_support_connected" if support_connected(edges)
               else "K_support_disconnected"] += 1
        relation, forbidden, local_leaves = relation_without_forbidden(edges)
        leaves += local_leaves
        if forbidden is not None:
            counts[f"rejected_by_{forbidden['category']}"] += 1
            continue
        counts["exact_negative"] += 1
        if not relation["X"]:
            counts["exact_negative_without_X"] += 1
            continue
        counts["exact_negative_with_BX"] += 1
        embedding = complementary_embedding(edges)
        record = {
            "copy_edges": tuple(tuple(edge) for edge in edges),
            "object_multiplicity": tuple(
                (tuple(edge), count) for edge, count in sorted(Counter(edges).items())
            ),
            "K_support_connected": support_connected(edges),
            "patterns": tuple(sorted(relation["patterns"])),
            "colouring_orbits": len(relation["rows"]),
            "labelled_colourings_with_first_edge_zero": relation["labelled_leaves"],
            "three_matching_decompositions": tuple(sorted(
                (printable_row(row) for row in relation["rows"]),
                key=lambda row: tuple(item["boundary"] for item in row),
            )),
            "B": tuple(sorted(printable_matching(matching) for matching in relation["B"])),
            "X": tuple(sorted(printable_matching(matching) for matching in relation["X"])),
            "complementary_embedding": None,
        }
        if first_exact is None:
            first_exact = record
        if embedding is None:
            counts["BX_without_owner_embedding"] += 1
            continue
        counts["BX_with_owner_embedding"] += 1
        record["complementary_embedding"] = {
            "owners": tuple(sorted(
                (printable_object(obj), colour)
                for obj, colour in embedding["owners"].items()
            )),
            "invisible_edges": embedding["invisible_edges"],
            "underlying_proper_edges": embedding["underlying_proper_edges"],
            "underlying_connected": embedding["underlying_connected"],
            "underlying_bridge_free": embedding["underlying_bridge_free"],
            "fixed_matchings": tuple(
                printable_matching(matching)
                for matching in embedding["fixed_matchings"]
            ),
        }
        # There is one B matching and one X matching in the frozen witness.
        assert len(relation["B"]) == len(relation["X"]) == 1
        b_matching = next(iter(relation["B"]))
        x_matching = next(iter(relation["X"]))
        common = b_matching & x_matching
        bad_phase = frozenset(
            obj for obj, colour in embedding["owners"].items()
            if colour in (0, 1)
        )
        record["complementary_embedding"].update({
            "B_intersection_X": printable_matching(common),
            "A_symmetric_difference_C_on_K": printable_matching(bad_phase),
            "overload_intersection": printable_matching(common & bad_phase),
        })
        expected_edges = {
            (0, 3), (0, 7), (1, 5), (2, 8), (3, 6),
            (4, 6), (4, 7), (5, 6), (5, 8), (7, 8),
        }
        expected_patterns = {
            tuple(sorted(pattern)) for pattern in (
                ((1, 3, 5), (2, 3, 4), (2,)),
                ((2, 3, 5), (2, 3, 4), (1,)),
                ((2, 3, 5), (1, 3, 4), (2,)),
                ((2, 4, 5), (1, 2, 3), (3,)),
                ((2, 3, 5), (1, 2, 3), (4,)),
                ((2, 3, 5), (1, 2, 4), (3,)),
            )
        }
        assert set(edges) == expected_edges
        assert relation["patterns"] == expected_patterns
        assert len(relation["rows"]) == 6
        assert common == {(0, 3)}
        assert embedding["owners"][(0, 3)] == 2
        assert not common & bad_phase
        underlying_objects = set(embedding["underlying_proper_edges"]) | {
            ("s", terminal) for terminal in range(1, 6)
        }
        for row in relation["rows"]:
            load = Counter()
            for matching in (*embedding["fixed_matchings"],
                             *(matching for _, matching in row)):
                load.update(matching)
            assert set(load) == underlying_objects
            assert set(load.values()) == {2}
        first_embedded = record
        break

    assert raw_total == 23625
    print(json.dumps({
        "order": ORDER,
        "raw_fixed_B_pairing_triples": raw_total,
        "counts_before_stop": dict(sorted(counts.items())),
        "colouring_leaves_visited": leaves,
        "first_exact_negative_BX": first_exact,
        "first_owner_embedded_BX": first_embedded,
    }, indent=2, sort_keys=True))
    print("ORDER9_CONFIGURATION_CARRIER_SCAN_OK")


if __name__ == "__main__":
    main()
