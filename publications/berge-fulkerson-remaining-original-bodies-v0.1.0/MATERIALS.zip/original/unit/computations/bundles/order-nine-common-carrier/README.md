# Order-nine common-carrier certificate

This bundle verifies the explicit carrier in
[Note 096](../../../notes/096-a-real-common-carrier-does-not-force-a-or-tt.md).
It deterministically enumerates the complete proper three-edge-colouring
relation, checks the two required singleton projections, rejects every
all-terminal and TT carrier state, and verifies one owner-consistent
embedding in a simple connected cubic five-pole.

Run from the repository root:

```bash
python3 units/berge-fulkerson/computations/bundles/order-nine-common-carrier/verify.py
```

The final line must be

```text
ORDER9_CONFIGURATION_CARRIER_SCAN_OK
```

`expected-output.txt` is the frozen output of the final Omen run.  That run
used Python 3.10.12, one process, a 1 GiB virtual-memory cap, 0.29 seconds
wall time and 11.52 MiB maximum resident memory.  The program performs a
targeted construction search and stops at the first explicit carrier; its
prefix counts are not an order-nine census.
