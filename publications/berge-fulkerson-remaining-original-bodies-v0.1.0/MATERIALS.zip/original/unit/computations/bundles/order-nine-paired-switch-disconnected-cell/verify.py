#!/usr/bin/env python3
"""Independent stdlib verification of the minimum paired-switch example."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import product


ORDER = 9
PROPER = (
    (0, 2), (0, 3), (1, 5), (1, 6), (2, 4), (3, 8),
    (4, 7), (5, 7), (5, 8), (6, 7), (6, 8),
)
SEMIEDGES = tuple((f"s{position}", position - 1) for position in range(1, 6))
EDGE_OBJECTS = tuple((f"e{index}", endpoints) for index, endpoints in enumerate(PROPER)) + tuple(
    (name, (vertex,)) for name, vertex in SEMIEDGES
)
ENDPOINTS = dict(EDGE_OBJECTS)

S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
CELL = ((1, 3), (1, 3))


def frozen(items):
    return frozenset(items.split())


# The six matchings occurring in the three [13] rows.
NAMED = {
    "A": frozen("e0 e10 e7 s2 s4 s5"),
    "A1": frozen("e0 e8 e9 s2 s4 s5"),
    "B": frozen("e1 e3 e6 e8 s3"),
    "B1": frozen("e1 e10 e2 e6 s3"),
    "C": frozen("e2 e4 e5 e9 s1"),
    "C1": frozen("e3 e4 e5 e7 s1"),
}
EXPECTED_ROWS = frozenset((
    tuple(sorted((NAMED["A"], NAMED["A"], NAMED["B"], NAMED["B"], NAMED["C"], NAMED["C"]), key=sorted)),
    tuple(sorted(NAMED.values(), key=sorted)),
    tuple(sorted((NAMED["A1"], NAMED["A1"], NAMED["B1"], NAMED["B1"], NAMED["C1"], NAMED["C1"]), key=sorted)),
))


def enumerate_matchings():
    incident = defaultdict(list)
    for edge, endpoints in EDGE_OBJECTS:
        for vertex in endpoints:
            incident[vertex].append(edge)
    used = [False] * ORDER
    chosen = []
    answer = set()

    def recurse():
        try:
            vertex = next(i for i, value in enumerate(used) if not value)
        except StopIteration:
            answer.add(frozenset(chosen))
            return
        for edge in incident[vertex]:
            vertices = ENDPOINTS[edge]
            if any(used[v] for v in vertices):
                continue
            for v in vertices:
                used[v] = True
            chosen.append(edge)
            recurse()
            chosen.pop()
            for v in vertices:
                used[v] = False

    recurse()
    return frozenset(answer)


def boundary(matching):
    return tuple(sorted(int(edge[1:]) for edge in matching if edge.startswith("s")))


def enumerate_cell_rows(matchings):
    classes = defaultdict(list)
    for matching in matchings:
        classes[boundary(matching)].append(matching)
    for family in classes.values():
        family.sort(key=sorted)
    slots = ((2, 4, 5), (2, 4, 5), (1,), (3,), (1,), (3,))
    rows = set()
    for row in product(*(classes[slot] for slot in slots)):
        if all(sum(edge in matching for matching in row) == 2
               for edge in ENDPOINTS):
            rows.add(tuple(sorted(row, key=sorted)))
    return frozenset(rows)


def proper_cycles(first, second):
    proper = {
        edge for edge in first ^ second if edge.startswith("e")
    }
    incident = defaultdict(list)
    for edge in proper:
        for vertex in ENDPOINTS[edge]:
            incident[vertex].append(edge)
    unseen = set(proper)
    cycles = []
    while unseen:
        seed = unseen.pop()
        component = {seed}
        queue = [seed]
        while queue:
            edge = queue.pop()
            for vertex in ENDPOINTS[edge]:
                for following in incident[vertex]:
                    if following in unseen:
                        unseen.remove(following)
                        component.add(following)
                        queue.append(following)
        degrees = Counter(vertex for edge in component for vertex in ENDPOINTS[edge])
        if all(value == 2 for value in degrees.values()):
            cycles.append(frozenset(component))
    return tuple(cycles)


def switch_adjacency(rows, matchings):
    adjacency = {row: set() for row in rows}
    for row in rows:
        for left in range(6):
            for right in range(left + 1, 6):
                for cycle in proper_cycles(row[left], row[right]):
                    changed = list(row)
                    changed[left] = row[left] ^ cycle
                    changed[right] = row[right] ^ cycle
                    assert changed[left] in matchings and changed[right] in matchings
                    target = tuple(sorted(changed, key=sorted))
                    if target in rows and target != row:
                        adjacency[row].add(target)
                        adjacency[target].add(row)
    return adjacency


def tait_states():
    incident = defaultdict(list)
    for edge, endpoints in EDGE_OBJECTS:
        for vertex in endpoints:
            incident[vertex].append(edge)
    edges = tuple(ENDPOINTS)
    assignment = {}
    used = {vertex: set() for vertex in range(ORDER)}
    root_edges = tuple(sorted(incident[0]))
    for colour, edge in enumerate(root_edges):
        assignment[edge] = colour
        for vertex in ENDPOINTS[edge]:
            used[vertex].add(colour)
    states = set()

    def recurse():
        unassigned = [edge for edge in edges if edge not in assignment]
        if not unassigned:
            by_colour = {colour: [] for colour in range(3)}
            for position in range(1, 6):
                by_colour[assignment[f"s{position}"]].append(position)
            lonely = sorted(values[0] for values in by_colour.values() if len(values) == 1)
            assert len(lonely) == 2
            states.add(tuple(lonely))
            return
        edge = min(
            unassigned,
            key=lambda item: len(set(range(3)) - set().union(
                *(used[v] for v in ENDPOINTS[item])
            )),
        )
        domain = set(range(3)) - set().union(*(used[v] for v in ENDPOINTS[edge]))
        for colour in domain:
            assignment[edge] = colour
            for vertex in ENDPOINTS[edge]:
                used[vertex].add(colour)
            recurse()
            for vertex in ENDPOINTS[edge]:
                used[vertex].remove(colour)
            del assignment[edge]

    recurse()
    return frozenset(states)


def main():
    degrees = Counter(vertex for _, endpoints in EDGE_OBJECTS for vertex in endpoints)
    assert all(degrees[vertex] == 3 for vertex in range(ORDER))
    graph = defaultdict(set)
    for u, v in PROPER:
        graph[u].add(v)
        graph[v].add(u)
    reached = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in graph[vertex] - reached:
            reached.add(neighbour)
            stack.append(neighbour)
    assert len(reached) == ORDER
    assert tait_states() == S

    matchings = enumerate_matchings()
    assert len(matchings) == 22 and set(NAMED.values()) <= matchings
    rows = enumerate_cell_rows(matchings)
    assert rows == EXPECTED_ROWS
    adjacency = switch_adjacency(rows, matchings)
    assert all(not neighbours for neighbours in adjacency.values())

    witnesses = tuple(
        tuple(next(name for name, matching in NAMED.items() if matching == item) for item in row)
        for row in sorted(rows, key=lambda row: tuple(map(sorted, row)))
    )
    print({
        "order": ORDER,
        "proper_edges": PROPER,
        "exact_Tait_states": tuple(sorted(S)),
        "perfect_matchings": len(matchings),
        "cell": "[13]",
        "actual_BF_rows": len(rows),
        "paired_switch_edges": 0,
        "component_sizes": (1, 1, 1),
        "row_witnesses": witnesses,
        "named_matching_edge_objects": {name: tuple(sorted(value)) for name, value in NAMED.items()},
    })
    print("ORDER9_PAIRED_SWITCH_DISCONNECTED_CELL_VERIFIED")


if __name__ == "__main__":
    main()

