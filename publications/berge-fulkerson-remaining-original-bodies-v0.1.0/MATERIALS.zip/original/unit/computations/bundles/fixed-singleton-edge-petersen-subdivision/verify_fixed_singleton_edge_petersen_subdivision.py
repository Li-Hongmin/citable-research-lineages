#!/usr/bin/env python3
"""Verify the Petersen-subdivision fixed-singleton-edge example."""

from itertools import combinations
import json


J_EDGES = {
    frozenset(e)
    for e in (
        ("0", "a"), ("a", "3"), ("1", "b"), ("b", "4"),
        ("0", "u"), ("u", "4"), ("1", "w"), ("w", "3"),
        ("2", "5"), ("0", "5"), ("1", "5"), ("2", "3"),
        ("2", "4"), ("a", "b"), ("u", "w"),
    )
}

SUBDIVISIONS = {
    frozenset(("0", "5")): "t1",
    frozenset(("1", "5")): "t2",
    frozenset(("2", "3")): "t3",
    frozenset(("2", "4")): "t4",
    frozenset(("u", "w")): "v",
}


def subdivided_edges():
    edges = set()
    for edge in J_EDGES:
        if edge in SUBDIVISIONS:
            x, y = tuple(edge)
            t = SUBDIVISIONS[edge]
            edges.add(frozenset((x, t)))
            edges.add(frozenset((t, y)))
        else:
            edges.add(edge)
    return edges


def adjacency(vertices, edges):
    adj = {v: set() for v in vertices}
    for edge in edges:
        x, y = tuple(edge)
        adj[x].add(y)
        adj[y].add(x)
    return adj


def components(vertices, edges):
    adj = adjacency(vertices, edges)
    unseen = set(vertices)
    out = []
    while unseen:
        start = next(iter(unseen))
        stack = [start]
        seen = {start}
        unseen.remove(start)
        while stack:
            x = stack.pop()
            for y in adj[x]:
                if y in unseen:
                    unseen.remove(y)
                    seen.add(y)
                    stack.append(y)
        out.append(seen)
    return out


def perfect_matchings(vertices, edges):
    adj = adjacency(vertices, edges)

    def rec(unmatched):
        if not unmatched:
            yield frozenset()
            return
        x = min(unmatched)
        for y in sorted(adj[x] & unmatched):
            edge = frozenset((x, y))
            for rest in rec(unmatched - {x, y}):
                yield rest | {edge}

    return list(rec(set(vertices)))


def has_cycle(vertices, edges):
    if not vertices:
        return False
    comps = components(vertices, edges)
    return len(edges) >= len(vertices) - len(comps) + 1


def girth(vertices, edges):
    adj = adjacency(vertices, edges)
    best = len(vertices) + 1
    for root in vertices:
        distance = {root: 0}
        parent = {root: None}
        queue = [root]
        for x in queue:
            for y in adj[x]:
                if y not in distance:
                    distance[y] = distance[x] + 1
                    parent[y] = x
                    queue.append(y)
                elif parent[x] != y:
                    best = min(best, distance[x] + distance[y] + 1)
    return best


def main():
    proper_edges = subdivided_edges()
    vertices = set().union(*proper_edges)
    terminals = ("t1", "t2", "t3", "t4", "v")
    fixed = frozenset(("a", "b"))

    adj = adjacency(vertices, proper_edges)
    assert len(vertices) == 15 and len(proper_edges) == 20
    assert len(components(vertices, proper_edges)) == 1
    assert girth(vertices, proper_edges) == 5
    assert all(len(adj[x]) == (2 if x in terminals else 3) for x in vertices)
    assert all(len(components(vertices, proper_edges - {edge})) == 1 for edge in proper_edges)

    two_cuts = []
    for cut in combinations(proper_edges, 2):
        comps = components(vertices, proper_edges - set(cut))
        if len(comps) > 1:
            shores = sorted((sorted(c) for c in comps), key=lambda c: (len(c), c))
            two_cuts.append((cut, shores))
    assert len(two_cuts) == 5
    assert all(len(shores) == 2 and len(shores[0]) == 1 and shores[0][0] in terminals
               for _, shores in two_cuts)
    assert all(fixed not in cut for cut, _ in two_cuts)

    class_matchings = {}
    fixed_intersections = {}
    for terminal in terminals:
        kept_vertices = vertices - {terminal}
        kept_edges = {e for e in proper_edges if terminal not in e}
        matchings = perfect_matchings(kept_vertices, kept_edges)
        assert matchings
        class_matchings[terminal] = len(matchings)
        intersection = set.intersection(*(set(m) for m in matchings))
        fixed_intersections[terminal] = sorted("-".join(sorted(e)) for e in intersection)

    assert class_matchings == {"t1": 5, "t2": 5, "t3": 5, "t4": 5, "v": 2}
    assert fixed_intersections == {
        "t1": [], "t2": [], "t3": [], "t4": [], "v": ["a-b"]
    }

    cycle = tuple(f"c{i}" for i in range(5))
    closed_edges = set(proper_edges)
    closed_edges.update(frozenset((cycle[i], cycle[(i + 1) % 5])) for i in range(5))
    closed_edges.update(frozenset((terminals[i], cycle[i])) for i in range(5))
    closed_vertices = vertices | set(cycle)
    closed_adj = adjacency(closed_vertices, closed_edges)
    assert all(len(closed_adj[x]) == 3 for x in closed_vertices)
    assert len(components(closed_vertices, closed_edges)) == 1
    assert girth(closed_vertices, closed_edges) == 5

    ordered = sorted(closed_vertices)
    root = ordered[0]
    others = [vtx for vtx in ordered if vtx != root]
    cyclic_cut_minimum = len(closed_edges)
    cyclic_cut_witness = None
    for mask in range(1 << len(others)):
        shore = {root}
        shore.update(others[i] for i in range(len(others)) if mask & (1 << i))
        other = closed_vertices - shore
        if not other:
            continue
        cut = {e for e in closed_edges if len(e & shore) == 1}
        if len(cut) >= cyclic_cut_minimum:
            continue
        inside = {e for e in closed_edges if e <= shore}
        outside = {e for e in closed_edges if e <= other}
        if has_cycle(shore, inside) and has_cycle(other, outside):
            cyclic_cut_minimum = len(cut)
            cyclic_cut_witness = sorted("-".join(sorted(e)) for e in cut)
    assert cyclic_cut_minimum == 5

    print(json.dumps({
        "proper_vertices": len(vertices),
        "proper_edges": len(proper_edges),
        "girth": girth(vertices, proper_edges),
        "proper_two_cuts": len(two_cuts),
        "singleton_class_pm_counts": class_matchings,
        "singleton_class_fixed_proper_edges": fixed_intersections,
        "closed_vertices": len(closed_vertices),
        "closed_edges": len(closed_edges),
        "closed_cyclic_edge_connectivity": cyclic_cut_minimum,
        "closed_minimum_cyclic_cut": cyclic_cut_witness,
    }, indent=2, sort_keys=True))
    print("PETERSEN_SUBDIVISION_FIXED_SINGLETON_EDGE_VERIFIED")


if __name__ == "__main__":
    main()
