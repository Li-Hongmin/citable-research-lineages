# Fixed singleton edge in a Petersen-subdivision pole

This bundle verifies the finite graph statements used by
[Note 086](../../../notes/086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md).

## Frozen program

`verify_fixed_singleton_edge_petersen_subdivision.py` constructs the
fifteen-vertex pole directly from the Petersen graph, enumerates all proper
two-edge cuts and all five singleton perfect-matching classes, then closes
the semiedges with a fresh five-cycle and exhausts all vertex shores of the
twenty-vertex cubic graph.

It asserts:

- simple cubic incidence, connectedness, bridgelessness and girth five;
- exactly five proper two-edge cuts, each isolating one terminal vertex;
- singleton-class sizes \((5,5,5,5,2)\);
- fixed-edge sets \((\varnothing,\varnothing,\varnothing,\varnothing,\{ab\})\);
- cyclic edge-connectivity five after the specified five-cycle closure.

## Omen reproduction

The frozen source was run in one Python process on host `omen`:

```bash
python3 verify_fixed_singleton_edge_petersen_subdivision.py
```

Environment: Python 3.10.12.  The run ended with
`PETERSEN_SUBDIVISION_FIXED_SINGLETON_EDGE_VERIFIED`; wall time was 2.33
seconds and peak resident memory was 9,984 kB.

Source SHA256:
`67065e2cd00e15060570bcfd00eb19bec1681f609274653490193cf1f4725344`.

## Scope

This is an exhaustive verification of one fixed pole and one specified
five-cycle closure, not an order census.  The example is not asserted to
have exact Case-XII BF support.  The Tutte-barrier characterization and the
class-exclusivity theorem in Note 086 are analytic and do not depend on this
enumeration.
