#!/usr/bin/env python3
"""Verify the saturated-BC common local-trivalent countermodel."""

from collections import defaultdict
from itertools import product


V = tuple(range(5))
I = (0, 1, 2)
T = ((0, 1), (0, 4), (1, 2), (2, 3), (3, 4))
SIG = {
    "A": (2, 1, 0, 0, 1), "B": (0, 2, 0, 1, 0),
    "C": (1, 0, 1, 2, 1), "D": (0, 0, 0, 1, 2),
    "P3": (1, 0, 2, 1, 1), "P5": (1, 1, 0, 0, 2),
    "X": (0, 0, 2, 0, 0), "Y": (1, 1, 2, 0, 0),
    "p13_1": (2, 1, 0, 0, 1), "p13_3": (1, 0, 2, 1, 1),
    "p24_2": (1, 2, 1, 0, 1), "p24_4": (1, 0, 0, 2, 1),
    "p25_2": (1, 2, 1, 1, 1), "p25_5": (1, 1, 0, 0, 2),
    "q13": (1, 2, 1, 2, 2), "q14": (1, 2, 2, 1, 2),
    "q24": (2, 1, 2, 1, 2), "q25": (2, 0, 2, 2, 1),
    "q25b": (2, 1, 2, 2, 1), "q35": (2, 2, 1, 2, 1),
    "r23": (2, 1, 1, 2, 2), "r34": (2, 2, 1, 0, 2),
}
ROWS = (
    ("r23", "B", "X", "q13", "p13_1", "p13_3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "p25_5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("q25b", "r34", "B", "Y", "C", "D"),
)


def boundary(signature):
    return frozenset(v for v in V if signature[v] == 2)


def is_cover(row):
    return all(
        sum(SIG[name][v] == incidence for name in row) == 2
        for v in V for incidence in I
    )


def signature_cover(row):
    return all(
        sum(signature[v] == incidence for signature in row) == 2
        for v in V for incidence in I
    )


def sep(companion, source, target):
    return all(source[v] == target[v] or companion[v] == target[v] for v in V)


def main():
    assert all(is_cover(row) for row in ROWS)
    assert SIG["X"] != SIG["Y"]
    family = tuple(sorted(set(SIG.values())))
    assert len(family) == 19

    classes = defaultdict(list)
    for signature in family:
        classes[boundary(signature)].append(signature)

    assert frozenset(V) not in classes
    tt_witnesses = []
    for left_index, left in enumerate(T):
        for right in T[left_index:]:
            families = (
                classes[frozenset(set(V) - set(left))],
                classes[frozenset(set(V) - set(right))],
                *(classes[frozenset((position,))] for position in left + right),
            )
            for row in product(*families):
                if signature_cover(row):
                    tt_witnesses.append((left, right, row))
    assert not tt_witnesses

    fixed = (SIG["r23"], SIG["B"], SIG["X"])
    carrier_rows = []
    for row in product(
        classes[frozenset(set(V) - {2, 4})],
        classes[frozenset({2})],
        classes[frozenset({4})],
    ):
        if signature_cover((*fixed, *row)):
            carrier_rows.append(row)
    assert len(carrier_rows) == 1

    projection3 = {row[1] for row in carrier_rows}
    projection5 = {row[2] for row in carrier_rows}
    assert SIG["Y"] not in projection3 and SIG["D"] not in projection5
    assert not any(
        sep(companion, source, SIG["Y"])
        for source in projection3 for companion in fixed
    )
    assert not any(
        sep(companion, source, SIG["D"])
        for source in projection5 for companion in fixed
    )

    print({
        "vertices": len(V),
        "named_occurrences": len(SIG),
        "distinct_signatures": len(family),
        "saturation_rows": len(ROWS) - 1,
        "actual_BC_rows": 1,
        "selected_TT_witnesses": len(tt_witnesses),
        "all_terminal_signature_present": False,
        "distinct_state35_decompositions": len(carrier_rows),
        "both_endpoint_intersections_empty": True,
        "proper_stubs_globally_paired": False,
    })
    print("VERTEX_PARTITION_SATURATED_BC_EMPTY_VERIFIED")


if __name__ == "__main__":
    main()
