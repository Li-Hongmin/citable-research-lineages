# Saturated-\(BC\) local trivalent countermodel

Run from the AIMath root:

    python3 units/berge-fulkerson/computations/bundles/saturated-bc-local-trivalent-countermodel/verify.py

The verifier uses only the Python standard library.  It checks the six row
balances, the nineteen distinct selected signatures, absence of every
selected \(T\)--\(T\) row with repetitions allowed, absence of an
all-terminal signature, and simultaneous failure of both endpoint
projections.  The final marker is

    VERTEX_PARTITION_SATURATED_BC_EMPTY_VERIFIED

The construction is a common local trivalent incidence system, not a cubic
five-pole: its proper incidence stubs are deliberately not paired into graph
edges.
