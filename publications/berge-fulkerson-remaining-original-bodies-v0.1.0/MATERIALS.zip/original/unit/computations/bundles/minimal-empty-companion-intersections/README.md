# Minimal empty companion intersections

This bundle verifies the two computed statements used by
[Note 084](../../../notes/084-minimal-empty-companion-intersections-and-the-no-a-double-hit-criterion.md).

## Frozen programs

- `verify_triangle_label_c6_countermodel.py` constructs the fixed
  eighteen-vertex cubic graph, enumerates its full perfect-matching family,
  and asserts the BF row, the triangle phase labels, failure of every
  nonempty partial-flip absorption, girth five, edge-connectivity three,
  and cyclic edge-connectivity five.
- `check_disjoint_labels_local_c6.py` is a Z3 local-incidence calculation.
  It checks all 30 ordered adjacent disjoint-label assignments under the
  four pivot rows, three target overloads, and the one-component no-A
  double-hit condition.  It is not a graph-realizability calculation.

Source SHA256 values:

```text
ad49f0cdf38c9705876bdb73365a04835742e184d2e61cae0246bdfc8ff3da17  verify_triangle_label_c6_countermodel.py
dfe8d28409c3a9a9686aea33b9e82da4c197c7b8bcf940005f1648cb178bc3ee  check_disjoint_labels_local_c6.py
```

## Omen reproduction

The frozen sources were run on host `omen` with one Python process each:

```bash
python3 verify_triangle_label_c6_countermodel.py
python3 check_disjoint_labels_local_c6.py
```

Environment: Python 3.10.12; the second program uses Z3 5.1.0.

The triangle verifier ended with
`TRIANGLE_LABEL_C6_COUNTERMODEL_VERIFIED`; wall time was 0.29 seconds and
peak resident memory was 9,984 kB.  The local disjoint-label verifier ended
with `DISJOINT_LABELS_LOCAL_C6_CHECKED`; wall time was 1.35 seconds and peak
resident memory was 51,352 kB.

The disjoint-pair realization in an actual cyclically five-edge-connected
cubic graph is separately frozen in the
[Note 083 bundle](../cyclically-five-connected-empty-phase-intersection/README.md).

## Scope

The triangle program proves a fixed common-cubic-row countermodel, not an
exact-Case-XII five-pole.  The Z3 program proves only local feasibility.
Neither program searches graph orders or claims a Case-XII counterexample.
