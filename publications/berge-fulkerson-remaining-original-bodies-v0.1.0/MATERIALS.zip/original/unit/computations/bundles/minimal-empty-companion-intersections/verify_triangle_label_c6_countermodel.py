#!/usr/bin/env python3
"""Verify the frozen 18-vertex triangle-label BF row; intended for Omen."""

from itertools import combinations


def vertex(block: int, node: int, bit: int) -> int:
    return 6 * block + 2 * node + bit


def edge(u: int, v: int) -> tuple[int, int]:
    assert u != v
    return (u, v) if u < v else (v, u)


VERTICES = tuple(range(18))
P_EDGES = {
    edge(vertex(c, i, 0), vertex(c, i, 1))
    for c in range(3)
    for i in range(3)
}
Y_EDGES = {
    edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))
    for c in range(3)
    for i in range(3)
}
THIRD_EDGES = {
    edge(vertex(0, 0, 0), vertex(1, 0, 0)),
    edge(vertex(2, 0, 0), vertex(0, 2, 1)),
    edge(vertex(1, 2, 1), vertex(2, 2, 1)),
    edge(vertex(0, 0, 1), vertex(1, 1, 0)),
    edge(vertex(0, 1, 0), vertex(2, 0, 1)),
    edge(vertex(0, 1, 1), vertex(1, 2, 0)),
    edge(vertex(0, 2, 0), vertex(2, 1, 1)),
    edge(vertex(1, 0, 1), vertex(2, 1, 0)),
    edge(vertex(1, 1, 1), vertex(2, 2, 0)),
}
EDGES = P_EDGES | Y_EDGES | THIRD_EDGES

OMEGA = frozenset(range(5))
Y_LABELS = (
    frozenset((1, 2)),
    frozenset((1, 3)),
    frozenset((2, 3)),
)


def adjacency(edges: set[tuple[int, int]]) -> dict[int, set[int]]:
    result = {v: set() for v in VERTICES}
    for u, v in edges:
        result[u].add(v)
        result[v].add(u)
    return result


def component_sets(edges: set[tuple[int, int]]) -> list[set[int]]:
    adj = adjacency(edges)
    unseen = set(VERTICES)
    result = []
    while unseen:
        start = min(unseen)
        component = {start}
        todo = [start]
        unseen.remove(start)
        while todo:
            u = todo.pop()
            for v in adj[u] & unseen:
                unseen.remove(v)
                component.add(v)
                todo.append(v)
        result.append(component)
    return result


def is_connected(edges: set[tuple[int, int]]) -> bool:
    return len(component_sets(edges)) == 1


def has_cycle(component: set[int], edges: set[tuple[int, int]]) -> bool:
    internal_edges = sum(u in component and v in component for u, v in edges)
    return internal_edges >= len(component)


def girth(edges: set[tuple[int, int]]) -> int:
    adj = adjacency(edges)
    best = len(VERTICES) + 1
    for removed_u, removed_v in edges:
        distance = {removed_u: 0}
        todo = [removed_u]
        for u in todo:
            for v in adj[u]:
                if edge(u, v) == edge(removed_u, removed_v) or v in distance:
                    continue
                distance[v] = distance[u] + 1
                todo.append(v)
        if removed_v in distance:
            best = min(best, distance[removed_v] + 1)
    return best


def edge_connectivity() -> int:
    edge_list = sorted(EDGES)
    for size in range(1, 5):
        if any(not is_connected(EDGES - set(removed)) for removed in combinations(edge_list, size)):
            return size
    raise AssertionError("no edge cut of size at most four")


def cyclic_edge_connectivity() -> int:
    edge_list = sorted(EDGES)
    for size in range(1, 7):
        for removed in combinations(edge_list, size):
            remainder = EDGES - set(removed)
            components = component_sets(remainder)
            if len(components) > 1 and sum(has_cycle(c, remainder) for c in components) >= 2:
                return size
    raise AssertionError("no cyclic cut of size at most six")


def is_perfect_matching(matching: set[tuple[int, int]]) -> bool:
    degrees = {v: 0 for v in VERTICES}
    for u, v in matching:
        degrees[u] += 1
        degrees[v] += 1
    return matching <= EDGES and set(degrees.values()) == {1}


def enumerate_perfect_matchings() -> set[frozenset[tuple[int, int]]]:
    adj = adjacency(EDGES)
    results: set[frozenset[tuple[int, int]]] = set()

    def visit(unmatched: frozenset[int], chosen: tuple[tuple[int, int], ...]) -> None:
        if not unmatched:
            results.add(frozenset(chosen))
            return
        u = min(unmatched)
        for v in sorted(adj[u] & unmatched):
            visit(unmatched - {u, v}, chosen + (edge(u, v),))

    visit(frozenset(VERTICES), ())
    return results


def stub_label(block: int, node: int, bit: int) -> frozenset[int]:
    del block
    y_index = (node - 1) % 3 if bit == 0 else node
    return OMEGA - {0} - Y_LABELS[y_index]


def main() -> None:
    assert len(EDGES) == 27
    assert len(P_EDGES) == len(Y_EDGES) == len(THIRD_EDGES) == 9
    assert not (P_EDGES & Y_EDGES or P_EDGES & THIRD_EDGES or Y_EDGES & THIRD_EDGES)
    assert is_connected(EDGES)
    assert {len(adjacency(EDGES)[v]) for v in VERTICES} == {3}

    labels: dict[tuple[int, int], frozenset[int]] = {e: frozenset((0,)) for e in P_EDGES}
    for c in range(3):
        for i in range(3):
            labels[edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))] = Y_LABELS[i]
    for u, v in THIRD_EDGES:
        uc, ur = divmod(u, 6)
        ui, ub = divmod(ur, 2)
        vc, vr = divmod(v, 6)
        vi, vb = divmod(vr, 2)
        assert stub_label(uc, ui, ub) == stub_label(vc, vi, vb)
        labels[edge(u, v)] = stub_label(uc, ui, ub)

    companions = [{e for e, label in labels.items() if a in label} for a in OMEGA]
    assert is_perfect_matching(P_EDGES)
    assert is_perfect_matching(Y_EDGES)
    assert all(is_perfect_matching(matching) for matching in companions)
    assert len({frozenset(matching) for matching in companions}) == 5
    assert all((e in P_EDGES) + sum(e in matching for matching in companions) == 2 for e in EDGES)

    perfect_matchings = enumerate_perfect_matchings()
    assert frozenset(P_EDGES) in perfect_matchings
    assert frozenset(Y_EDGES) in perfect_matchings
    assert all(frozenset(matching) in perfect_matchings for matching in companions)

    components = component_sets(P_EDGES | Y_EDGES)
    assert len(components) == 3 and {len(component) for component in components} == {6}
    intersections = []
    pairwise_intersections = []
    for c in range(3):
        cycle_labels = [
            labels[edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))]
            for i in range(3)
        ]
        intersections.append(set.intersection(*(set(label) for label in cycle_labels)))
        pairwise_intersections.append([
            set(cycle_labels[i]) & set(cycle_labels[j]) for i, j in combinations(range(3), 2)
        ])
        cycle_edges = {
            edge(vertex(c, i, bit), vertex(c, i, 1 - bit))
            for i in range(3)
            for bit in (0,)
        } | {
            edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))
            for i in range(3)
        }
        y_phase = {
            edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))
            for i in range(3)
        }
        assert all(matching & cycle_edges != y_phase for matching in companions)
    assert all(not intersection for intersection in intersections)
    assert all(all(intersection for intersection in row) for row in pairwise_intersections)

    for mask in range(1, 1 << 3):
        partial_flip = set(P_EDGES)
        for c in range(3):
            if mask & (1 << c):
                block_p = {edge(vertex(c, i, 0), vertex(c, i, 1)) for i in range(3)}
                block_y = {
                    edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))
                    for i in range(3)
                }
                partial_flip = (partial_flip - block_p) | block_y
        assert is_perfect_matching(partial_flip)
        for matching in companions:
            forced_load = {
                e: int(e in matching) + int(e in P_EDGES) - int(e in partial_flip)
                for e in EDGES
            }
            forced_partner = {e for e, load in forced_load.items() if load == 1}
            assert not (
                set(forced_load.values()) <= {0, 1}
                and is_perfect_matching(forced_partner)
            )

    graph_girth = girth(EDGES)
    connectivity = edge_connectivity()
    cyclic_connectivity = cyclic_edge_connectivity()
    assert graph_girth == 5
    assert connectivity == 3
    assert cyclic_connectivity == 5
    print(f"vertices=18 edges=27 perfect_matchings={len(perfect_matchings)}")
    print(f"girth={graph_girth} edge_connectivity={connectivity} cyclic_edge_connectivity={cyclic_connectivity}")
    print(f"distinct_companions={len({frozenset(matching) for matching in companions})}")
    print(f"cycle_label_intersections={intersections}")
    print(f"cycle_pairwise_intersections={pairwise_intersections}")
    print("TRIANGLE_LABEL_C6_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
