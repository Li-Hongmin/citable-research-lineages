#!/usr/bin/env python3
"""Check frozen adjacent disjoint desired-phase labels on one formal C6 component.

This is a local cubic-incidence CSP, not a graph search.  Each named matching
chooses a matching of the C6 vertices, using a third-edge stub at every vertex
not covered by a cycle edge.  The four repeated-star rows and the anchored
(35,23) target row must double-cover every local edge object.  The exact
no-A cube-hitting consequence is imposed locally by requiring the anchor
double-hit set D2 to meet both phases of the component.
"""

from collections import Counter
from itertools import combinations

from z3 import And, Bool, If, Or, Solver, Sum, is_true, sat


CYCLE = ("p0", "y0", "p1", "y1", "p2", "y2")
ENDS = {
    "p0": (0, 1), "y0": (1, 2), "p1": (2, 3),
    "y1": (3, 4), "p2": (4, 5), "y2": (5, 0),
}
STUBS = tuple(f"s{i}" for i in range(6))
OBJECTS = CYCLE + STUBS
P_EDGES = ("p0", "p1", "p2")
Y_EDGES = ("y0", "y1", "y2")

ROWS = (
    ("q13", "r45", "A", "X", "C", "D"),
    ("q14", "r23", "A", "B", "X", "C"),
    ("q24", "r15", "A", "B", "C", "D"),
    ("q25", "r34", "B", "Y", "C", "D"),
    ("q35", "r23", "B", "X", "P3", "P5"),
)
TARGETS = (
    ("B", "D", "X", "Y"),
    ("A", "C", "X", "Y"),
    ("A", "B", "D", "Y"),
)
ANCHORS = ("A", "B", "C", "D")
NAMES = tuple(sorted(set().union(*map(set, ROWS))))
COMPANIONS = ("q35", "r23", "B", "X", "P5")


def local_patterns():
    result = []
    for size in range(4):
        for selected in combinations(CYCLE, size):
            covered = [vertex for edge in selected for vertex in ENDS[edge]]
            if len(set(covered)) != len(covered):
                continue
            pattern = set(selected)
            pattern.update(f"s{vertex}" for vertex in range(6) if vertex not in covered)
            result.append(frozenset(pattern))
    assert len(result) == 18
    return tuple(result)


PATTERNS = local_patterns()
P_PHASE = frozenset(P_EDGES)
Y_PHASE = frozenset(Y_EDGES)
assert P_PHASE in PATTERNS and Y_PHASE in PATTERNS


def hit_sum(use, names, item):
    return Sum(*(If(use[(name, item)], 1, 0) for name in names))


def build_solver():
    use = {
        (name, item): Bool(f"use_{name}_{item}")
        for name in NAMES for item in OBJECTS
    }
    solver = Solver()
    for name in NAMES:
        solver.add(Or(*(
            And(*(use[(name, item)] == (item in pattern) for item in OBJECTS))
            for pattern in PATTERNS
        )))
    for item in OBJECTS:
        for row in ROWS:
            solver.add(hit_sum(use, row, item) == 2)
        solver.add(hit_sum(use, ANCHORS, item) <= 2)
    for item in OBJECTS:
        solver.add(use[("P3", item)] == (item in P_PHASE))
        solver.add(use[("Y", item)] == (item in Y_PHASE))
    for target in TARGETS:
        solver.add(Or(*(hit_sum(use, target, item) >= 3 for item in OBJECTS)))

    # With one P3/Y component and no common edge, no A forces every endpoint
    # phase to hit D2.  This is the strongest component-local consequence of
    # the full partial-flip cube.
    solver.add(Or(*(hit_sum(use, ANCHORS, item) == 2 for item in P_EDGES)))
    solver.add(Or(*(hit_sum(use, ANCHORS, item) == 2 for item in Y_EDGES)))
    return solver, use


def selected_pattern(model, use, name):
    return tuple(item for item in OBJECTS if is_true(model.eval(use[(name, item)])))


def main():
    solver, use = build_solver()
    records = []
    failed = []
    by_unused = Counter()
    examples = {}
    for first in combinations(COMPANIONS, 2):
        remaining = tuple(name for name in COMPANIONS if name not in first)
        for second in combinations(remaining, 2):
            unused = next(name for name in COMPANIONS if name not in first + second)
            solver.push()
            for name in COMPANIONS:
                solver.add(use[(name, "y0")] == (name in first))
                solver.add(use[(name, "y1")] == (name in second))
            status = solver.check()
            if status == sat:
                model = solver.model()
                by_unused[unused] += 1
                record = {
                    "y0_label": first,
                    "y1_label": second,
                    "unused": unused,
                    "unused_on_middle_p1": is_true(
                        model.eval(use[(unused, "p1")])
                    ),
                    "D2_P_phase": tuple(
                        item for item in P_EDGES
                        if model.eval(hit_sum(use, ANCHORS, item)).as_long() == 2
                    ),
                    "D2_Y_phase": tuple(
                        item for item in Y_EDGES
                        if model.eval(hit_sum(use, ANCHORS, item)).as_long() == 2
                    ),
                    "patterns": {
                        name: selected_pattern(model, use, name)
                        for name in NAMES
                    },
                    "overloads": {
                        "".join(target): tuple(
                            item for item in OBJECTS
                            if sum(
                                is_true(model.eval(use[(name, item)]))
                                for name in target
                            ) >= 3
                        )
                        for target in TARGETS
                    },
                }
                records.append(record)
                examples.setdefault(unused, record)
            else:
                failed.append({
                    "y0_label": first,
                    "y1_label": second,
                    "unused": unused,
                })
            solver.pop()

    assert len(records) == 24
    assert len(failed) == 6
    assert by_unused == Counter({"B": 6, "P5": 4, "X": 4, "q35": 4, "r23": 6})
    assert all(record["unused_on_middle_p1"] for record in records)
    print({
        "local_patterns": len(PATTERNS),
        "ordered_disjoint_label_pairs": 30,
        "satisfiable": len(records),
        "satisfiable_by_unused_fifth_role": dict(sorted(by_unused.items())),
        "incompatible_label_pairs": failed,
        "all_force_unused_role_on_middle_P_edge": True,
        "examples": examples,
    })
    print("DISJOINT_LABELS_LOCAL_C6_CHECKED")


if __name__ == "__main__":
    main()
