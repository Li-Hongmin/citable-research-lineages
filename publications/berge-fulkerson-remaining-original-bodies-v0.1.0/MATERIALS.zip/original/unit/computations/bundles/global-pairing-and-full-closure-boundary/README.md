# Global pairing and full-closure boundary

This bundle supports [Note 102](../../../notes/102-global-pairing-does-not-force-an-anchored-quadratic-but-closure-creates-an-a-cover.md).

It contains two calculations on one fixed set of nineteen selected matching
identities.

1. `solve_note101_global_stub_pairing.py` constructs the connected
   67-vertex cubic five-pole multigraph and writes
   `note101_global_stub_pairing_result.json`.
2. `check_note101_global_multigraph_closure.py` quantifies over actual
   perfect matchings of that fixed multigraph.  It first proves the two
   fixed state-35 endpoint projections empty and then finds an all-terminal
   (A)-cover, writing `note101_global_multigraph_closure_result.json`.

Run on `omen` from this directory:

```bash
python3 solve_note101_global_stub_pairing.py
python3 check_note101_global_multigraph_closure.py
```

The first terminal marker is

```text
NOTE101_GLOBAL_STUB_PAIRING_DECIDED
```

and the decisive closure marker is

```text
NOTE101_MULTIGRAPH_A_WITNESS
```

The frozen runs used Ubuntu Python 3.10.12.  The pairing constructor uses
only the standard library.  The closure checker used Z3 5.1.0, one process,
a 1-GiB virtual-memory limit and a 240-second outer timeout.  Its decisive
run took 0.14 seconds and 54,528 KiB maximum RSS.  The pairing construction
took 1.91 seconds and 17,152 KiB maximum RSS.

Frozen SHA-256 values:

```text
88c106cc8f0e9304e643a369c3e36fdda236a6dee6bb7381e7c229722819054c  solve_note101_global_stub_pairing.py
36ec05b108fcbf43596e648c640fee88ef6624f005577ffb2d76b19c19e73fbf  note101_global_stub_pairing_result.json
64b53578b767aebee14c076ee592912b9a8b44a5d04a3c094de32640137df741  note101_global_stub_pairing_omen_run.log
e582fa2eadb956fd062d4cfa55fe62934837c82cbc253bed33e6cd325687c1f6  check_note101_global_multigraph_closure.py
50dbc06e52b90a3a482e26652cdbfaa103f77cc2de050993aebbd0934ed029ce  note101_global_multigraph_closure_result.json
b2e2291d4c19c383030c7156d86b743188cfdf013a737dfbfbf02f7432d0fbf6  note101_global_multigraph_closure_omen_run.log
```

The output JSON contains five literal singleton perfect matchings and their
load-one all-terminal complement.  The checker verifies every vertex degree
and exact load two on all 103 edge objects before emitting the marker.

Scope: this is one fixed multigraph pairing.  It is a selected-family
countermodel followed by a full-closure repair, not an exact-Case-XII pole.
