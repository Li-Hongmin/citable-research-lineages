#!/usr/bin/env python3
"""Decide the global proper-stub pairing obstruction left by Note 101.

The 22 coordinates are the named matching occurrences in Note 101, while
equal words are one matching identity and must receive the same local colour.
A block is one incidence of a legal trivalent vertex.  Thus it contains two
occurrences in each of the six BF rows.  An allowed star is a partition of all
22 occurrences into three such blocks.

Over GF(2), proper stubs can be paired globally iff the five prescribed
terminal blocks lie in the span of allowed-star incidence vectors.  This
script enumerates that finite system, solves it with a witness, and (when
feasible) emits an explicit vertex multiset whose nonterminal block counts
are all even.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
import hashlib
from itertools import product
import json
from pathlib import Path


LABEL_WORDS = (
    ("A", "21001"),
    ("B", "02010"),
    ("C", "10121"),
    ("D", "00012"),
    ("P3", "10211"),
    ("P5", "11002"),
    ("X", "00200"),
    ("Y", "11200"),
    ("p1_13", "21001"),
    ("p3_13", "10211"),
    ("p2_24", "12101"),
    ("p4_24", "10021"),
    ("p2_25", "12111"),
    ("p5_25", "11002"),
    ("q13", "12122"),
    ("q14", "12212"),
    ("q24", "21212"),
    ("q25", "20221"),
    ("q25prime", "21221"),
    ("q35", "22121"),
    ("r23", "21122"),
    ("r34", "22102"),
)

ROWS = (
    ("r23", "B", "X", "q13", "p1_13", "p3_13"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p2_24", "p4_24"),
    ("r23", "B", "X", "q25", "p2_25", "p5_25"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("q25prime", "r34", "B", "Y", "C", "D"),
)


def xor_indices(bits: int):
    while bits:
        low = bits & -bits
        yield low.bit_length() - 1
        bits ^= low


def main() -> None:
    labels = tuple(label for label, _ in LABEL_WORDS)
    words = tuple(word for _, word in LABEL_WORDS)
    label_index = {label: i for i, label in enumerate(labels)}
    distinct_words = tuple(dict.fromkeys(words))
    word_index = {word: i for i, word in enumerate(distinct_words)}
    identity_of_label = tuple(word_index[word] for word in words)
    signature = {label: tuple(map(int, word)) for label, word in LABEL_WORDS}
    assert len(labels) == 22 and len(distinct_words) == 19

    row_masks = tuple(
        sum(1 << label_index[label] for label in row) for row in ROWS
    )
    omega = (1 << len(labels)) - 1

    # Each identity mask expands to all of its named occurrence positions.
    identity_label_masks = [0] * len(distinct_words)
    for pos, identity in enumerate(identity_of_label):
        identity_label_masks[identity] |= 1 << pos

    blocks = []
    for identity_subset in range(1 << len(distinct_words)):
        label_mask = 0
        for identity in xor_indices(identity_subset):
            label_mask |= identity_label_masks[identity]
        if all((label_mask & row).bit_count() == 2 for row in row_masks):
            blocks.append(label_mask)
    block_set = set(blocks)
    block_index = {block: i for i, block in enumerate(blocks)}

    # Unique unordered allowed partitions.
    partitions = []
    for i, first in enumerate(blocks):
        remaining = omega ^ first
        for j in range(i + 1, len(blocks)):
            second = blocks[j]
            if second & first:
                continue
            third = remaining ^ second
            k = block_index.get(third)
            if k is not None and j < k:
                partitions.append((i, j, k))

    # The five prescribed terminal columns are incidence 2 at the original
    # five local vertices.
    terminal_masks = []
    original_partitions = []
    for vertex in range(5):
        colour_masks = []
        for colour in range(3):
            mask = sum(
                1 << pos for pos, word in enumerate(words)
                if int(word[vertex]) == colour
            )
            assert mask in block_set
            colour_masks.append(mask)
        assert (colour_masks[0] | colour_masks[1] | colour_masks[2]) == omega
        assert not (colour_masks[0] & colour_masks[1])
        original_partitions.append(tuple(sorted(block_index[m] for m in colour_masks)))
        terminal_masks.append(colour_masks[2])

    target = 0
    for mask in terminal_masks:
        target ^= 1 << block_index[mask]
    assert target.bit_count() == 5

    partition_vectors = tuple(
        sum(1 << block for block in partition) for partition in partitions
    )

    # The target has odd Hamming weight, so every representation uses an odd
    # number of stars.  Test the only possibilities below five (one or three)
    # directly before accepting a longer Gaussian witness.
    vector_to_partition = {vector: i for i, vector in enumerate(partition_vectors)}
    short_witness = None
    if target in vector_to_partition:
        short_witness = (vector_to_partition[target],)
    else:
        for i, first in enumerate(partition_vectors):
            for j in range(i + 1, len(partition_vectors)):
                third = target ^ first ^ partition_vectors[j]
                k = vector_to_partition.get(third)
                if k is not None and j < k:
                    short_witness = (i, j, k)
                    break
            if short_witness is not None:
                break

    # Gaussian elimination over block coordinates.  Trace each basis row by
    # a bitset over the allowed partitions so a positive result is explicit.
    basis: dict[int, tuple[int, int]] = {}
    target_reduced = target
    target_trace = 0
    reached_at = None
    for p_index, partition in enumerate(partitions):
        vector = sum(1 << block for block in partition)
        trace = 1 << p_index
        while vector:
            pivot = vector.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = (vector, trace)
                break
            old_vector, old_trace = basis[pivot]
            vector ^= old_vector
            trace ^= old_trace

        # Incrementally reduce target against the current echelon basis.
        while target_reduced:
            pivot = target_reduced.bit_length() - 1
            if pivot not in basis:
                break
            old_vector, old_trace = basis[pivot]
            target_reduced ^= old_vector
            target_trace ^= old_trace
        if target_reduced == 0:
            reached_at = p_index
            break

    feasible = target_reduced == 0
    witness_partition_indices = tuple(xor_indices(target_trace)) if feasible else ()
    if short_witness is not None:
        feasible = True
        witness_partition_indices = short_witness
    if short_witness is None and feasible:
        assert all(i <= reached_at for i in witness_partition_indices)
    if feasible:
        check = 0
        for p_index in witness_partition_indices:
            check ^= partition_vectors[p_index]
        assert check == target

    # Add one copy of each original terminal star, but mark its colour-2 block
    # as a semiedge.  Adding the same five stars as internal vertices plus the
    # target-span witness makes every proper block count even.  Equal copies
    # cancel mod 2, so remove duplicate internal stars in pairs.
    internal_partition_parity = Counter(witness_partition_indices)
    partition_lookup = {partition: i for i, partition in enumerate(partitions)}
    original_partition_indices = [partition_lookup[p] for p in original_partitions]
    for p_index in original_partition_indices:
        internal_partition_parity[p_index] += 1
    internal_partition_indices = sorted(
        p_index for p_index, count in internal_partition_parity.items() if count % 2
    ) if feasible else []

    # Directly minimize the actual internal vertices.  Their syndrome is the
    # parity of the ten proper stubs on the five prescribed terminal stars.
    # It has even weight, so test depths two and four.  The recursive pivot on
    # a currently odd block is exhaustive: every remaining solution contains
    # that block an odd number of times and hence contains a candidate star.
    proper_target = target
    for p_index in original_partition_indices:
        proper_target ^= partition_vectors[p_index]
    assert proper_target.bit_count() == 10
    partitions_at_block = [[] for _ in blocks]
    for p_index, partition in enumerate(partitions):
        for block in partition:
            partitions_at_block[block].append(p_index)

    def fixed_depth_xor_witness(syndrome: int, depth: int):
        failed = set()

        def visit(current: int, remaining: int, chosen: tuple[int, ...]):
            if remaining == 0:
                return chosen if current == 0 else None
            if current == 0:
                return None
            # Each remaining star toggles only three coordinates.
            if current.bit_count() > 3 * remaining:
                return None
            state = (current, remaining, tuple(sorted(chosen)))
            if state in failed:
                return None
            odd_blocks = tuple(xor_indices(current))
            pivot = min(
                odd_blocks,
                key=lambda block: sum(
                    p_index not in chosen for p_index in partitions_at_block[block]
                ),
            )
            for p_index in partitions_at_block[pivot]:
                if p_index in chosen:
                    continue
                answer = visit(
                    current ^ partition_vectors[p_index],
                    remaining - 1,
                    chosen + (p_index,),
                )
                if answer is not None:
                    return answer
            failed.add(state)
            return None

        return visit(syndrome, depth, ())

    direct_internal_witness = None
    if feasible:
        for depth in (2, 4):
            direct_internal_witness = fixed_depth_xor_witness(proper_target, depth)
            if direct_internal_witness is not None:
                internal_partition_indices = sorted(direct_internal_witness)
                break

    vertices = []
    terminal_blocks = []
    if feasible:
        for vertex, partition in enumerate(original_partitions):
            terminal_block = block_index[terminal_masks[vertex]]
            vertices.append({
                "kind": "terminal",
                "blocks": list(partition),
                "terminal_block": terminal_block,
            })
            terminal_blocks.append(terminal_block)
        for p_index in internal_partition_indices:
            vertices.append({
                "kind": "internal",
                "blocks": list(partitions[p_index]),
                "terminal_block": None,
            })

    proper_stubs = defaultdict(list)
    if feasible:
        for vertex, record in enumerate(vertices):
            for block in record["blocks"]:
                if record["kind"] == "terminal" and block == record["terminal_block"]:
                    continue
                proper_stubs[block].append(vertex)
        assert all(len(stubs) % 2 == 0 for stubs in proper_stubs.values())

    # Pair equal-column stubs while avoiding loops.  A star has three distinct
    # blocks, hence a block occurs at most once at a vertex and consecutive
    # pairing is loop-free.  Then improve connectivity by 2-switches within a
    # block type whenever possible.
    edges = []
    edge_blocks = []
    if feasible:
        for block, stubs in sorted(proper_stubs.items()):
            for offset in range(0, len(stubs), 2):
                left, right = stubs[offset:offset + 2]
                assert left != right
                edges.append([left, right])
                edge_blocks.append(block)

        def components():
            adjacency = [[] for _ in vertices]
            for edge_index, (left, right) in enumerate(edges):
                adjacency[left].append((right, edge_index))
                adjacency[right].append((left, edge_index))
            seen = set()
            answer = []
            for start in range(len(vertices)):
                if start in seen:
                    continue
                queue = [start]
                seen.add(start)
                component = []
                while queue:
                    here = queue.pop()
                    component.append(here)
                    for there, _ in adjacency[here]:
                        if there not in seen:
                            seen.add(there)
                            queue.append(there)
                answer.append(component)
            return answer

        # A same-block 2-switch preserves every selected matching.  Greedily
        # join components if a block has one edge in each of two components.
        changed = True
        while changed:
            changed = False
            comps = components()
            comp_of = {vertex: c for c, comp in enumerate(comps) for vertex in comp}
            by_block_comp = defaultdict(dict)
            for edge_index, ((left, right), block) in enumerate(zip(edges, edge_blocks)):
                assert comp_of[left] == comp_of[right]
                by_block_comp[block].setdefault(comp_of[left], edge_index)
            for block, choices in by_block_comp.items():
                if len(choices) < 2:
                    continue
                first_comp, second_comp = list(choices)[:2]
                first_edge = choices[first_comp]
                second_edge = choices[second_comp]
                a, b = edges[first_edge]
                c, d = edges[second_edge]
                edges[first_edge] = [a, c]
                edges[second_edge] = [b, d]
                changed = True
                break

    final_components = []
    if feasible:
        adjacency = [[] for _ in vertices]
        for left, right in edges:
            adjacency[left].append(right)
            adjacency[right].append(left)
        seen = set()
        for start in range(len(vertices)):
            if start in seen:
                continue
            queue = [start]
            seen.add(start)
            comp = []
            while queue:
                here = queue.pop()
                comp.append(here)
                for there in adjacency[here]:
                    if there not in seen:
                        seen.add(there)
                        queue.append(there)
            final_components.append(sorted(comp))

    # Retain Note 101's selected-support exclusions.  These depend only on the
    # five prescribed terminal stars, which occur literally as vertices 0..4.
    boundary_classes = defaultdict(list)
    for word in distinct_words:
        word_tuple = tuple(map(int, word))
        boundary = frozenset(
            vertex for vertex, value in enumerate(word_tuple) if value == 2
        )
        boundary_classes[boundary].append(word_tuple)

    def signature_cover(row):
        return all(
            sum(word[vertex] == incidence for word in row) == 2
            for vertex in range(5) for incidence in range(3)
        )

    cycle_pairs = ((0, 1), (0, 4), (1, 2), (2, 3), (3, 4))
    tt_witnesses = []
    for left_index, left in enumerate(cycle_pairs):
        for right in cycle_pairs[left_index:]:
            families = (
                boundary_classes[frozenset(set(range(5)) - set(left))],
                boundary_classes[frozenset(set(range(5)) - set(right))],
                *(boundary_classes[frozenset((position,))]
                  for position in left + right),
            )
            for row in product(*families):
                if signature_cover(row):
                    tt_witnesses.append((left, right, row))
    assert not tt_witnesses
    assert frozenset(range(5)) not in boundary_classes

    fixed = (signature["r23"], signature["B"], signature["X"])
    carrier_rows = []
    for row in product(
        boundary_classes[frozenset(set(range(5)) - {2, 4})],
        boundary_classes[frozenset({2})],
        boundary_classes[frozenset({4})],
    ):
        if signature_cover((*fixed, *row)):
            carrier_rows.append(row)
    assert len(carrier_rows) == 1

    def sep(companion, source, destination):
        return all(
            source[vertex] == destination[vertex]
            or companion[vertex] == destination[vertex]
            for vertex in range(5)
        )

    projection3 = {row[1] for row in carrier_rows}
    projection5 = {row[2] for row in carrier_rows}
    assert signature["Y"] not in projection3
    assert signature["D"] not in projection5
    assert not any(
        sep(companion, source, signature["Y"])
        for source in projection3 for companion in fixed
    )
    assert not any(
        sep(companion, source, signature["D"])
        for source in projection5 for companion in fixed
    )

    # Verify that each of the 19 identities is a perfect matching of the
    # constructed five-pole: once at every vertex, and consistently on edges.
    if feasible:
        assert len(final_components) == 1
        degrees = Counter()
        for left, right in edges:
            assert left != right
            degrees[left] += 1
            degrees[right] += 1
        for vertex, record in enumerate(vertices):
            degrees[vertex] += int(record["kind"] == "terminal")
        assert all(degrees[vertex] == 3 for vertex in range(len(vertices)))

        # Every displayed row covers every graph edge and semiedge twice.
        for row_mask in row_masks:
            assert all(
                (blocks[block] & row_mask).bit_count() == 2
                for block in proper_stubs
            )
            assert all(
                (terminal_masks[vertex] & row_mask).bit_count() == 2
                for vertex in range(5)
            )

        for identity, word in enumerate(distinct_words):
            covered = Counter()
            for record in vertices:
                selected = 0
                for block in record["blocks"]:
                    if blocks[block] & identity_label_masks[identity]:
                        selected += 1
                assert selected == 1
            for (left, right), block in zip(edges, edge_blocks):
                bit = bool(blocks[block] & identity_label_masks[identity])
                left_has = block in vertices[left]["blocks"]
                right_has = block in vertices[right]["blocks"]
                assert left_has and right_has
                if bit:
                    covered[left] += 1
                    covered[right] += 1
            for vertex, terminal_mask in enumerate(terminal_masks):
                if terminal_mask & identity_label_masks[identity]:
                    covered[vertex] += 1
            assert all(covered[vertex] == 1 for vertex in range(len(vertices)))

    def block_string(block_index_value: int) -> str:
        mask = blocks[block_index_value]
        return format(mask, f"0{len(labels)}b")[::-1]

    record = {
        "labels": labels,
        "distinct_matching_identities": len(distinct_words),
        "valid_blocks": len(blocks),
        "allowed_partitions": len(partitions),
        "span_rank_at_stop": len(basis),
        "target_terminal_blocks": [block_index[mask] for mask in terminal_masks],
        "target_terminal_columns": [block_string(block_index[mask]) for mask in terminal_masks],
        "feasible": feasible,
        "span_witness_partition_indices": witness_partition_indices,
        "span_witness_size": len(witness_partition_indices),
        "internal_partition_indices": internal_partition_indices,
        "direct_internal_witness": direct_internal_witness,
        "vertices": vertices,
        "proper_edges": [
            {"ends": edge, "block": block, "column": block_string(block)}
            for edge, block in zip(edges, edge_blocks)
        ],
        "components": final_components,
        "selected_all_terminal_matching_present": False,
        "selected_tt_witnesses": len(tt_witnesses),
        "both_endpoint_intersections_empty": True,
    }
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    output = Path(__file__).with_name("note101_global_stub_pairing_result.json")
    output.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")

    print(f"valid_blocks={len(blocks)}")
    print(f"allowed_partitions={len(partitions)}")
    print(f"feasible={feasible}")
    if feasible:
        print(f"span_witness_size={len(witness_partition_indices)}")
        print(f"vertices={len(vertices)} proper_edges={len(edges)} components={len(final_components)}")
        print(f"order_parity={len(vertices) % 2}")
    print(f"result={output}")
    print("NOTE101_GLOBAL_STUB_PAIRING_DECIDED")


if __name__ == "__main__":
    main()
