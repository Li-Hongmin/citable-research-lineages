#!/usr/bin/env python3
"""Early forbidden-witness closure test for the frozen Note-101 multigraph.

Parallel proper edges remain distinct edge objects.  The fixed graph is read
from ``note101_global_stub_pairing_result.json``.  Exact SAT queries search
graph-induced perfect matchings, first for either Note-093 endpoint
intersection, then for an A cover, and then for any T--T cover.  Only if all
three forbidden families are proved absent does the script spend remaining
time on the positive Case-XII support and Tait-state queries.

There is one fixed graph, no order scan, random search, or CEGAR loop.
"""

from __future__ import annotations

import gc
import hashlib
import json
import time
from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement
from pathlib import Path

from z3 import Bool, Implies, Not, Or, PbEq, PbLe, Solver, is_true, sat, unknown


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
OUTPUT = HERE / "note101_global_multigraph_closure_result.json"
TERMINALS = tuple(range(5))
PAIR_SET = tuple(combinations(TERMINALS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(PAIR_SET) - set(S))
TARGET_TYPES = tuple(
    list(combinations_with_replacement(sorted(S), 2))
    + sorted(tuple(sorted((s, t))) for s in S for t in T)
)


def boundary_for_pair(pair):
    return frozenset(set(TERMINALS) - set(pair))


def slots_for_type(kind):
    first, second = kind
    return (
        boundary_for_pair(first), boundary_for_pair(second),
        frozenset((first[0],)), frozenset((first[1],)),
        frozenset((second[0],)), frozenset((second[1],)),
    )


class FixedMultigraph:
    def __init__(self, record):
        self.n = len(record["vertices"])
        self.edges = tuple(tuple(item["ends"]) for item in record["proper_edges"])
        self.m = len(self.edges)
        self.object_count = self.m + len(TERMINALS)
        self.incident = [[] for _ in range(self.n)]
        for edge, (left, right) in enumerate(self.edges):
            assert left != right
            self.incident[left].append(edge)
            self.incident[right].append(edge)
        assert all(
            len(self.incident[v]) + int(v in TERMINALS) == 3
            for v in range(self.n)
        )
        self.labels = tuple(record["labels"])
        self.label_index = {label: i for i, label in enumerate(self.labels)}
        self.edge_columns = tuple(item["column"] for item in record["proper_edges"])
        self.terminal_columns = tuple(record["target_terminal_columns"])

    def selected_matching(self, label):
        position = self.label_index[label]
        chosen = [e for e, column in enumerate(self.edge_columns)
                  if column[position] == "1"]
        chosen.extend(
            self.m + terminal
            for terminal, column in enumerate(self.terminal_columns)
            if column[position] == "1"
        )
        return tuple(chosen)

    def matching_vars(self, solver, name, boundary):
        values = tuple(Bool(f"{name}_e{edge}") for edge in range(self.m))
        for vertex in range(self.n):
            target = 0 if vertex in TERMINALS and vertex in boundary else 1
            solver.add(PbEq([(values[e], 1) for e in self.incident[vertex]], target))
        return values

    def extract_matching(self, model, values, boundary):
        chosen = [e for e, value in enumerate(values) if is_true(model.eval(value))]
        chosen.extend(self.m + terminal for terminal in sorted(boundary))
        answer = tuple(chosen)
        self.verify_matching(answer, boundary)
        return answer

    def verify_matching(self, matching, boundary):
        degree = [0] * self.n
        for obj in matching:
            if obj < self.m:
                left, right = self.edges[obj]
                degree[left] += 1
                degree[right] += 1
            else:
                terminal = obj - self.m
                assert terminal in TERMINALS
                degree[terminal] += 1
        assert degree == [1] * self.n
        actual_boundary = frozenset(obj - self.m for obj in matching if obj >= self.m)
        assert actual_boundary == boundary


def remaining_ms(deadline):
    return max(1, int(1000 * (deadline - time.monotonic() - 3.0)))


def checked_solve(solver, deadline):
    left = remaining_ms(deadline)
    if left <= 1:
        return unknown, "global_deadline"
    solver.set(timeout=left)
    result = solver.check()
    return result, solver.reason_unknown() if result == unknown else None


def vector(matching, object_count):
    out = [0] * object_count
    for edge in matching:
        out[edge] = 1
    return tuple(out)


def verify_double_cover(matchings, object_count):
    load = [0] * object_count
    for matching in matchings:
        for edge in matching:
            load[edge] += 1
    assert load == [2] * object_count


def endpoint_query(graph, selected, deadline):
    fixed_names = ("r23", "B", "X")
    fixed = tuple(selected[name] for name in fixed_names)
    fixed_vectors = {name: vector(selected[name], graph.object_count)
                     for name in fixed_names}
    targets = {name: vector(selected[name], graph.object_count)
               for name in ("Y", "D")}
    residual = [2 - sum(edge in matching for matching in fixed)
                for edge in range(graph.object_count)]
    assert set(residual) <= {0, 1, 2}

    solver = Solver()
    q = graph.matching_vars(solver, "endpoint_q35", boundary_for_pair((2, 4)))
    p3 = graph.matching_vars(solver, "endpoint_p3", frozenset((2,)))
    p5 = graph.matching_vars(solver, "endpoint_p5", frozenset((4,)))
    for edge in range(graph.m):
        solver.add(PbEq([(q[edge], 1), (p3[edge], 1), (p5[edge], 1)], residual[edge]))

    choices = []
    route_records = []
    for endpoint, source, target_name in (("Y", p3, "Y"), ("D", p5, "D")):
        target = targets[target_name]
        for companion in ("entry", *fixed_names):
            choice = Bool(f"route_{endpoint}_{companion}")
            choices.append(choice)
            route_records.append((choice, endpoint, companion, source, target))
            for edge in range(graph.m):
                constrained = companion == "entry" or (
                    fixed_vectors[companion][edge] != target[edge]
                )
                if constrained:
                    solver.add(Implies(choice, source[edge] if target[edge] else Not(source[edge])))
    solver.add(Or(*choices))
    result, reason = checked_solve(solver, deadline)
    if result != sat:
        del solver
        gc.collect()
        return {"status": str(result), "reason": reason}

    model = solver.model()
    q_m = graph.extract_matching(model, q, boundary_for_pair((2, 4)))
    p3_m = graph.extract_matching(model, p3, frozenset((2,)))
    p5_m = graph.extract_matching(model, p5, frozenset((4,)))
    verify_double_cover((*fixed, q_m, p3_m, p5_m), graph.object_count)
    selected_route = next(record for record in route_records
                          if is_true(model.eval(record[0])))
    _, endpoint, companion, source, target = selected_route
    source_matching = p3_m if endpoint == "Y" else p5_m
    target_matching = selected[endpoint]
    if companion == "entry":
        assert source_matching == target_matching
    else:
        companion_set = set(selected[companion])
        source_set, target_set = set(source_matching), set(target_matching)
        assert (target_set - source_set) <= companion_set
        assert not companion_set.intersection(source_set - target_set)
    return {
        "status": "sat", "endpoint": endpoint, "companion": companion,
        "fixed": {name: list(selected[name]) for name in fixed_names},
        "q35": list(q_m), "source": list(source_matching),
        "target": list(target_matching),
    }


def a_query(graph, deadline):
    solver = Solver()
    variables = [graph.matching_vars(solver, f"a_p{terminal}", frozenset((terminal,)))
                 for terminal in TERMINALS]
    for edge in range(graph.m):
        solver.add(PbLe([(values[edge], 1) for values in variables], 2))
    result, reason = checked_solve(solver, deadline)
    if result != sat:
        del solver
        gc.collect()
        return {"status": str(result), "reason": reason}
    model = solver.model()
    singletons = tuple(
        graph.extract_matching(model, variables[t], frozenset((t,)))
        for t in TERMINALS
    )
    load = [sum(edge in matching for matching in singletons)
            for edge in range(graph.object_count)]
    assert set(load) <= {1, 2}
    all_terminal = tuple(edge for edge, value in enumerate(load) if value == 1)
    graph.verify_matching(all_terminal, frozenset(TERMINALS))
    verify_double_cover((*singletons, all_terminal), graph.object_count)
    return {"status": "sat", "singletons": [list(item) for item in singletons],
            "all_terminal": list(all_terminal)}


def tt_query(graph, deadline):
    kinds = tuple(combinations_with_replacement(sorted(T), 2))
    solver = Solver()
    selectors = tuple(Bool(f"tt_kind_{index}") for index in range(len(kinds)))
    solver.add(PbEq([(selector, 1) for selector in selectors], 1))
    variables = [tuple(Bool(f"tt_slot{slot}_e{edge}") for edge in range(graph.m))
                 for slot in range(6)]
    for kind_index, kind in enumerate(kinds):
        for slot, boundary in enumerate(slots_for_type(kind)):
            for vertex in range(graph.n):
                target = 0 if vertex in TERMINALS and vertex in boundary else 1
                solver.add(Implies(
                    selectors[kind_index],
                    PbEq([(variables[slot][e], 1) for e in graph.incident[vertex]], target),
                ))
    for edge in range(graph.m):
        solver.add(PbEq([(variables[slot][edge], 1) for slot in range(6)], 2))
    result, reason = checked_solve(solver, deadline)
    if result != sat:
        del solver
        gc.collect()
        return {"status": str(result), "reason": reason}
    model = solver.model()
    kind_index = next(i for i, selector in enumerate(selectors)
                      if is_true(model.eval(selector)))
    kind = kinds[kind_index]
    matchings = tuple(
        graph.extract_matching(model, variables[slot], boundary)
        for slot, boundary in enumerate(slots_for_type(kind))
    )
    verify_double_cover(matchings, graph.object_count)
    return {"status": "sat", "kind": kind,
            "matchings": [list(item) for item in matchings]}


def type_query(graph, kind, prefix, deadline):
    solver = Solver()
    boundaries = slots_for_type(kind)
    variables = [graph.matching_vars(solver, f"{prefix}_slot{slot}", boundary)
                 for slot, boundary in enumerate(boundaries)]
    for edge in range(graph.m):
        solver.add(PbEq([(variables[slot][edge], 1) for slot in range(6)], 2))
    result, reason = checked_solve(solver, deadline)
    if result != sat:
        del solver
        gc.collect()
        return {"status": str(result), "reason": reason}
    model = solver.model()
    matchings = tuple(graph.extract_matching(model, variables[slot], boundary)
                      for slot, boundary in enumerate(boundaries))
    verify_double_cover(matchings, graph.object_count)
    del solver
    gc.collect()
    return {"status": "sat", "matchings": [list(item) for item in matchings]}


def tait_query(graph, state, prefix, deadline):
    boundaries = (frozenset((state[0],)), frozenset((state[1],)),
                  boundary_for_pair(state))
    solver = Solver()
    variables = [graph.matching_vars(solver, f"{prefix}_slot{slot}", boundary)
                 for slot, boundary in enumerate(boundaries)]
    for edge in range(graph.m):
        solver.add(PbEq([(variables[slot][edge], 1) for slot in range(3)], 1))
    result, reason = checked_solve(solver, deadline)
    if result != sat:
        del solver
        gc.collect()
        return {"status": str(result), "reason": reason}
    model = solver.model()
    matchings = tuple(graph.extract_matching(model, variables[slot], boundary)
                      for slot, boundary in enumerate(boundaries))
    load = [sum(edge in matching for matching in matchings)
            for edge in range(graph.object_count)]
    assert load == [1] * graph.object_count
    return {"status": "sat", "matchings": [list(item) for item in matchings]}


def emit(record):
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps(record, sort_keys=True))


def main():
    started = time.monotonic()
    deadline = started + 220.0
    input_record = json.loads(INPUT.read_text())
    graph = FixedMultigraph(input_record)
    selected = {label: graph.selected_matching(label) for label in graph.labels}
    for label, matching in selected.items():
        position = graph.label_index[label]
        boundary = frozenset(t for t, column in enumerate(graph.terminal_columns)
                             if column[position] == "1")
        graph.verify_matching(matching, boundary)

    base = {
        "input_record_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        "order": graph.n, "proper_edge_objects": graph.m,
        "parallel_endpoint_pairs": [list(pair) for pair, count in
                                    Counter(graph.edges).items() if count > 1],
        "queries": {},
    }

    endpoint = endpoint_query(graph, selected, deadline)
    base["queries"]["endpoint"] = endpoint
    if endpoint["status"] == "sat":
        base.update(status="forbidden_endpoint_intersection",
                    elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_ENDPOINT_WITNESS")
        return
    if endpoint["status"] == "unknown":
        base.update(status="unknown_at_endpoint", elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_CLOSURE_UNKNOWN")
        return

    a_result = a_query(graph, deadline)
    base["queries"]["A"] = a_result
    if a_result["status"] == "sat":
        base.update(status="forbidden_A", elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_A_WITNESS")
        return
    if a_result["status"] == "unknown":
        base.update(status="unknown_at_A", elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_CLOSURE_UNKNOWN")
        return

    tt_result = tt_query(graph, deadline)
    base["queries"]["TT"] = tt_result
    if tt_result["status"] == "sat":
        base.update(status="forbidden_TT", elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_TT_WITNESS")
        return
    if tt_result["status"] == "unknown":
        base.update(status="unknown_at_TT", elapsed_s=time.monotonic() - started)
        emit(base)
        print("NOTE101_MULTIGRAPH_CLOSURE_UNKNOWN")
        return

    positive = {}
    for index, kind in enumerate(TARGET_TYPES):
        result = type_query(graph, kind, f"positive_{index}", deadline)
        positive[str(kind)] = result
        if result["status"] != "sat":
            base["queries"]["positive_support"] = positive
            base.update(
                status=("missing_positive_type" if result["status"] == "unsat"
                        else "unknown_at_positive_support"),
                first_nonpositive_type=kind,
                elapsed_s=time.monotonic() - started,
            )
            emit(base)
            print("NOTE101_MULTIGRAPH_NOT_EXACT_CASE_XII" if result["status"] == "unsat"
                  else "NOTE101_MULTIGRAPH_CLOSURE_UNKNOWN")
            return
    base["queries"]["positive_support"] = positive

    tait = {}
    for index, state in enumerate(sorted(S)):
        result = tait_query(graph, state, f"tait_{index}", deadline)
        tait[str(state)] = result
        if result["status"] != "sat":
            base["queries"]["S_tait_states"] = tait
            base.update(
                status=("missing_S_tait_state" if result["status"] == "unsat"
                        else "unknown_at_S_tait_states"),
                first_nonpositive_tait_state=state,
                elapsed_s=time.monotonic() - started,
            )
            emit(base)
            print("NOTE101_MULTIGRAPH_NOT_EXACT_CASE_XII" if result["status"] == "unsat"
                  else "NOTE101_MULTIGRAPH_CLOSURE_UNKNOWN")
            return
    base["queries"]["S_tait_states"] = tait
    base.update(status="real_exact_case_xii_note082_counterexample_candidate",
                elapsed_s=time.monotonic() - started)
    emit(base)
    print("NOTE101_MULTIGRAPH_REAL_COUNTEREXAMPLE_CANDIDATE")


if __name__ == "__main__":
    main()
