#!/usr/bin/env python3
"""Test literal pivot cubic factorizations in the frozen Note-085 model."""

import argparse
import importlib.util
import json
from pathlib import Path


def load_module(path):
    spec = importlib.util.spec_from_file_location("note085", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def combine(vectors, terms):
    return tuple(sum(coefficient * vectors[token][i]
                     for token, coefficient in terms.items())
                 for i in range(len(next(iter(vectors.values())))))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model_json", type=Path)
    parser.add_argument("model_script", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    payload = json.loads(args.model_json.read_text())
    module = load_module(args.model_script)
    builder = module.ModelBuilder().build()
    vectors = {token: tuple(map(int, bits))
               for token, bits in payload["vectors"].items()}

    relations = (
        {
            "name": "relation_1",
            "left": {"q13": 1, "r45": 1, "D": 1},
            "right": {"q14": 1, "r23": 1, "B": 1},
            "factor": {"r45": 1, "D": 1, "q14": -1},
            "factor_kind": "singleton", "factor_boundary": 1,
            "move_1_left": ("r45", "D"),
            "move_1_right_fixed": "q14",
            "move_2_left_fixed": "q13",
            "move_2_right": ("B", "r23"),
        },
        {
            "name": "relation_2",
            "left": {"q14": 1, "r23": 1, "X": 1},
            "right": {"q24": 1, "r15": 1, "D": 1},
            "factor": {"q14": 1, "r23": 1, "q24": -1},
            "factor_kind": "triple", "factor_boundary": (1, 3),
            "move_1_left": ("q14", "r23"),
            "move_1_right_fixed": "q24",
            "move_2_left_fixed": "X",
            "move_2_right": ("D", "r15"),
        },
        {
            "name": "relation_3",
            "left": {"q24": 1, "r15": 1, "A": 1},
            "right": {"q25": 1, "r34": 1, "Y": 1},
            "factor": {"q24": 1, "r15": 1, "q25": -1},
            "factor_kind": "triple", "factor_boundary": (1, 4),
            "move_1_left": ("q24", "r15"),
            "move_1_right_fixed": "q25",
            "move_2_left_fixed": "A",
            "move_2_right": ("Y", "r34"),
        },
    )

    forced = []
    for target in builder.targets:
        if target["name"] not in ("BDXY", "ACXY"):
            continue
        row = target["row"]
        for replacement_index, replacement in enumerate(target["replacements"]):
            old, new = replacement["old"], replacement["new"]
            companions = list(row)
            companions.remove(old)
            for companion in companions:
                forced.append({
                    "label": f"{target['name']}:endpoint:{replacement_index}:{companion}",
                    "kind": builder.kind[companion],
                    "boundary": builder.boundary[companion],
                    "vector": combine(vectors, {companion: 1, old: 1, new: -1}),
                })
        old0, old1 = target["sources"]
        new0, new1 = target["desired"]
        forced.extend((
            {"label": f"{target['name']}:forced-intermediate:0",
             "kind": "singleton", "boundary": builder.boundary[old0],
             "vector": combine(vectors, {new0: 1, new1: 1, old1: -1})},
            {"label": f"{target['name']}:forced-intermediate:1",
             "kind": "singleton", "boundary": builder.boundary[old1],
             "vector": combine(vectors, {new0: 1, new1: 1, old0: -1})},
        ))

    report = []
    factor_vectors = {}
    for relation in relations:
        assert combine(vectors, relation["left"]) == combine(vectors, relation["right"])
        factor = combine(vectors, relation["factor"])
        binary = set(factor) <= {0, 1}
        matching_tokens = [token for token, vector in vectors.items()
                           if vector == factor
                           and builder.kind[token] == relation["factor_kind"]
                           and builder.boundary[token] == relation["factor_boundary"]]
        target_collisions = [item["label"] for item in forced
                             if item["kind"] == relation["factor_kind"]
                             and item["boundary"] == relation["factor_boundary"]
                             and item["vector"] == factor]
        report.append({
            "name": relation["name"],
            "factor_vector": "".join(map(str, factor)),
            "factor_binary": binary,
            "already_actual_tokens": matching_tokens,
            "anchored_target_forced_vector_collisions": target_collisions,
        })
        factor_vectors[relation["name"]] = factor

    # Add only the binary factor of relation 1 to the frozen exact-40 token
    # pool.  This is not synthesis: all 48 coordinates stay fixed.  Check
    # that the one-token extension still admits no T-loop or TT BF row.
    factor_name = "factor:relation_1:A_prime"
    factor = factor_vectors["relation_1"]
    assert set(factor) <= {0, 1}
    builder.singleton(factor_name, 1)
    augmented_vectors = dict(vectors)
    augmented_vectors[factor_name] = factor
    frozen_synth = module.CoordinateSynthesizer(builder)
    frozen_synth.columns = [
        frozenset(token for token, vector in augmented_vectors.items()
                  if vector[index])
        for index in range(len(factor))
    ]
    frozen_synth.column_names = [f"frozen:{index}" for index in range(len(factor))]
    forbidden = module.evaluate_forbidden(frozen_synth)
    enabled_forbidden = {
        str(key): value for key, value in forbidden.items() if value is not None
    }

    result = {
        "status": "frozen_note085_pivot_factorization_audit",
        "coordinates": len(next(iter(vectors.values()))),
        "relations": report,
        "anchored_forced_vectors_checked": len(forced),
        "one_token_extension": {
            "token": factor_name,
            "kind": "singleton",
            "boundary": 1,
            "preserves_no_Tloop_TT": not enabled_forbidden,
            "enabled_forbidden_types": enabled_forbidden,
            "preserves_no_A": True,
            "reason_no_A": "the token pool still has no all-terminal token",
            "anchored_endpoint_or_forced_collisions": report[0][
                "anchored_target_forced_vector_collisions"
            ],
        },
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    print("NOTE085_PIVOT_QUADRATIC_FACTORIZATIONS_AUDITED")


if __name__ == "__main__":
    main()
