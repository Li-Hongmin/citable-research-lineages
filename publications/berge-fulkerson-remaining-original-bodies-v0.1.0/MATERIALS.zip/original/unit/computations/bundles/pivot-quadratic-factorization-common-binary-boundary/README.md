# Pivot quadratic factorization common-binary boundary

This bundle verifies the one-token extension used in
[Note 092](../../../notes/092-one-pivot-quadratic-factorization-does-not-force-an-anchored-two-splice-fibre.md).
It reads the frozen common-binary model from the
[Note 085 bundle](../joint-carrier-common-binary-countermodel/README.md),
checks the three pivot cubic relations, adjoins the displayed binary factor
for the first relation, and reevaluates the forbidden boundary types and all
genuinely anchored Note-082 forced vectors.

## Files

- `audit_note085_pivot_quadratic_factorizations.py` is the deterministic
  checker.
- `note085_pivot_quadratic_factorization_result.json` is the fixed result.
- `note085_pivot_quadratic_factorization_omen_run.log` records stdout,
  timing, peak memory, and exit status from Omen.

SHA256:

```text
9b08d2bd607a8416dbd7ca99eab390009df8cebd187f52083dc35168d74591c2  audit_note085_pivot_quadratic_factorizations.py
f18e7645b12feb36bfe8b776d1c5ac8debcbb69656636eac59d6f4c36aab660f  note085_pivot_quadratic_factorization_result.json
8b8a083365bdaf559cb7d614d8c9360a8ca4bae0d923ceaf5d8e01eb8cd417fd  note085_pivot_quadratic_factorization_omen_run.log
```

Frozen dependencies from the Note 085 bundle:

```text
bf7bb4b4ce5e3662f18bc044b50b454380f9d2a38b3fe24fb6872972b3dc7d8f  synthesize_joint_carrier_guard_model.py
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
```

## Reproduction on Omen

Environment: Python 3.10.12 and Z3 5.1.0.  Run one process from this bundle,
passing the two frozen Note 085 dependencies:

```bash
python3 -u audit_note085_pivot_quadratic_factorizations.py \
  ../joint-carrier-common-binary-countermodel/joint_carrier_common_binary_result.json \
  ../joint-carrier-common-binary-countermodel/synthesize_joint_carrier_guard_model.py \
  --json result.json
```

The frozen run printed
`NOTE085_PIVOT_QUADRATIC_FACTORIZATIONS_AUDITED`, exited zero, took 0.39
seconds, and used 52,992 kB peak resident memory.

## Scope

The check is exhaustive for forbidden six-token decompositions and the
twenty-four anchored forced vectors in this fixed common-binary system.  It
does not search graphs.  The model has no common cubic vertex partition and
is not graph-induced full perfect-matching closure, so it is not a real
Case-XII pole.
