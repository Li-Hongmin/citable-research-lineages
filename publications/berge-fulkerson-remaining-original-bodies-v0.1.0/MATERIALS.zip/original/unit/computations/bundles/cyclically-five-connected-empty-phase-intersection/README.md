# Cyclically five-connected empty phase intersection

This bundle verifies the eighteen-vertex graph in
[Note 083](../../../notes/083-cyclic-five-connectivity-does-not-force-one-row-companion-alignment.md).
It checks simplicity, connectedness, cubicity, girth five, edge-connectivity
three, cyclic edge-connectivity five, the complete set of $24$ perfect
matchings, the six-occurrence row identity, the three alternating
six-cycles, and the empty companion-label intersection on each cycle.

Run on Omen with one process:

```bash
python3 verify.py
```

The final marker is `C6_COMPANION_LABEL_COUNTERMODEL_VERIFIED`.  The
promoted Omen run on 2026-09-05 used Python 3.10.12, took 0.22 seconds,
and had peak RSS 9,472 KB.  Its source SHA-256 was
`fafecddc258683e9d69c38b65a28db95051ff22676842a32a42f7cf864693806`.
