#!/usr/bin/env python3
"""Verify the 18-vertex C6 companion-label countermodel from first principles."""

from itertools import combinations


def vertex(block: int, node: int, bit: int) -> int:
    return 6 * block + 2 * node + bit


def edge(u: int, v: int) -> tuple[int, int]:
    assert u != v
    return (u, v) if u < v else (v, u)


VERTICES = tuple(range(18))
P_EDGES = {
    edge(vertex(c, i, 0), vertex(c, i, 1))
    for c in range(3)
    for i in range(3)
}
Y_EDGES = {
    edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))
    for c in range(3)
    for i in range(3)
}
THIRD_EDGES = {
    edge(vertex(0, 0, 0), vertex(1, 0, 0)),
    edge(vertex(2, 0, 0), vertex(0, 2, 1)),
    edge(vertex(1, 2, 1), vertex(2, 2, 1)),
    edge(vertex(0, 0, 1), vertex(1, 1, 0)),
    edge(vertex(0, 1, 0), vertex(1, 2, 0)),
    edge(vertex(0, 1, 1), vertex(2, 0, 1)),
    edge(vertex(0, 2, 0), vertex(2, 1, 1)),
    edge(vertex(1, 0, 1), vertex(2, 1, 0)),
    edge(vertex(1, 1, 1), vertex(2, 2, 0)),
}
EDGES = P_EDGES | Y_EDGES | THIRD_EDGES

OMEGA = frozenset(range(5))
Y_LABELS = (
    frozenset((1, 2)),
    frozenset((1, 2)),
    frozenset((3, 4)),
)


def adjacency(edges: set[tuple[int, int]]) -> dict[int, set[int]]:
    result = {v: set() for v in VERTICES}
    for u, v in edges:
        result[u].add(v)
        result[v].add(u)
    return result


def is_connected(edges: set[tuple[int, int]]) -> bool:
    adj = adjacency(edges)
    seen = {0}
    todo = [0]
    while todo:
        u = todo.pop()
        for v in adj[u] - seen:
            seen.add(v)
            todo.append(v)
    return len(seen) == len(VERTICES)


def girth(edges: set[tuple[int, int]]) -> int:
    adj = adjacency(edges)
    best = len(VERTICES) + 1
    for removed_u, removed_v in edges:
        distance = {removed_u: 0}
        todo = [removed_u]
        for u in todo:
            for v in adj[u]:
                if edge(u, v) == edge(removed_u, removed_v) or v in distance:
                    continue
                distance[v] = distance[u] + 1
                todo.append(v)
        if removed_v in distance:
            best = min(best, distance[removed_v] + 1)
    return best


def is_perfect_matching(matching: set[tuple[int, int]]) -> bool:
    degrees = {v: 0 for v in VERTICES}
    for u, v in matching:
        degrees[u] += 1
        degrees[v] += 1
    return matching <= EDGES and set(degrees.values()) == {1}


def enumerate_perfect_matchings() -> set[frozenset[tuple[int, int]]]:
    adj = adjacency(EDGES)
    results: set[frozenset[tuple[int, int]]] = set()

    def visit(unmatched: frozenset[int], chosen: tuple[tuple[int, int], ...]) -> None:
        if not unmatched:
            results.add(frozenset(chosen))
            return
        u = min(unmatched)
        for v in sorted(adj[u] & unmatched):
            visit(unmatched - {u, v}, chosen + (edge(u, v),))

    visit(frozenset(VERTICES), ())
    return results


def connected_after_removing(removed: tuple[tuple[int, int], ...]) -> bool:
    return is_connected(EDGES - set(removed))


def component_sets(edges: set[tuple[int, int]]) -> list[set[int]]:
    adj = adjacency(edges)
    unseen = set(VERTICES)
    result = []
    while unseen:
        start = min(unseen)
        component = {start}
        todo = [start]
        unseen.remove(start)
        while todo:
            u = todo.pop()
            for v in adj[u] & unseen:
                unseen.remove(v)
                component.add(v)
                todo.append(v)
        result.append(component)
    return result


def has_cycle(component: set[int], edges: set[tuple[int, int]]) -> bool:
    internal_edges = sum(u in component and v in component for u, v in edges)
    return internal_edges >= len(component)


def cyclic_edge_connectivity() -> int:
    edge_list = sorted(EDGES)
    for size in range(1, 7):
        for removed in combinations(edge_list, size):
            remainder = EDGES - set(removed)
            components = component_sets(remainder)
            if len(components) > 1 and sum(has_cycle(c, remainder) for c in components) >= 2:
                return size
    raise AssertionError("no cyclic cut of size at most six")


def stub_label(block: int, node: int, bit: int) -> frozenset[int]:
    y_index = (node - 1) % 3 if bit == 0 else node
    return OMEGA - {0} - Y_LABELS[y_index]


def main() -> None:
    assert len(EDGES) == 27
    assert len(P_EDGES) == len(Y_EDGES) == len(THIRD_EDGES) == 9
    assert not (P_EDGES & Y_EDGES or P_EDGES & THIRD_EDGES or Y_EDGES & THIRD_EDGES)

    adj = adjacency(EDGES)
    assert is_connected(EDGES)
    assert {len(adj[v]) for v in VERTICES} == {3}
    assert girth(EDGES) == 5
    assert all(connected_after_removing(removed) for size in (1, 2) for removed in combinations(EDGES, size))
    edge_connectivity = 3
    cyclic_connectivity = cyclic_edge_connectivity()

    labels: dict[tuple[int, int], frozenset[int]] = {}
    for e in P_EDGES:
        labels[e] = frozenset((0,))
    for c in range(3):
        for i in range(3):
            labels[edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))] = Y_LABELS[i]
    for u, v in THIRD_EDGES:
        uc, ur = divmod(u, 6)
        ui, ub = divmod(ur, 2)
        vc, vr = divmod(v, 6)
        vi, vb = divmod(vr, 2)
        assert stub_label(uc, ui, ub) == stub_label(vc, vi, vb)
        labels[edge(u, v)] = stub_label(uc, ui, ub)

    companions = [{e for e, label in labels.items() if j in label} for j in OMEGA]
    assert is_perfect_matching(P_EDGES)
    assert is_perfect_matching(Y_EDGES)
    assert all(is_perfect_matching(matching) for matching in companions)
    assert all((e in P_EDGES) + sum(e in matching for matching in companions) == 2 for e in EDGES)

    perfect_matchings = enumerate_perfect_matchings()
    assert frozenset(P_EDGES) in perfect_matchings
    assert frozenset(Y_EDGES) in perfect_matchings
    assert all(frozenset(matching) in perfect_matchings for matching in companions)

    difference_components = component_sets(P_EDGES | Y_EDGES)
    assert len(difference_components) == 3
    assert {frozenset(component) for component in difference_components} == {
        frozenset(vertex(c, i, bit) for i in range(3) for bit in range(2))
        for c in range(3)
    }
    assert all(len(component) == 6 and has_cycle(component, P_EDGES | Y_EDGES) for component in difference_components)

    intersections = []
    for c in range(3):
        cycle_labels = [
            labels[edge(vertex(c, i, 1), vertex(c, (i + 1) % 3, 0))]
            for i in range(3)
        ]
        intersection = set.intersection(*(set(label) for label in cycle_labels))
        intersections.append(intersection)
        assert not intersection
    assert all((matching & (P_EDGES | Y_EDGES)) != Y_EDGES for matching in companions)

    print(f"vertices={len(VERTICES)} edges={len(EDGES)} perfect_matchings={len(perfect_matchings)}")
    print(f"girth=5 edge_connectivity={edge_connectivity} cyclic_edge_connectivity={cyclic_connectivity}")
    print(f"difference_components={[len(component) for component in difference_components]}")
    print(f"cycle_label_intersections={intersections}")
    print("C6_COMPANION_LABEL_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
