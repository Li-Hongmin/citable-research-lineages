# Joint-carrier common-binary countermodel

This bundle verifies the abstract countermodel in
[Note 085](../../../notes/085-common-binary-incidence-does-not-force-a-two-step-carrier-section.md).

## Contents

- `synthesize_joint_carrier_guard_model.py` deterministically constructs the
  common token system, synthesizes legal binary coordinates, eliminates every
  forbidden \(T\)-loop/\(T\)--\(T\) decomposition, and separates every
  endpoint and forced-intermediate expression.
- `joint_carrier_common_binary_result.json` contains the 125 frozen token
  vectors on 48 coordinates and the compact verification counts.
- `joint_carrier_common_binary_omen_run.log` is the stdout and resource log
  from the frozen Omen run.

SHA256:

```text
bf7bb4b4ce5e3662f18bc044b50b454380f9d2a38b3fe24fb6872972b3dc7d8f  synthesize_joint_carrier_guard_model.py
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
2fe5786af1dcdbafbd506b48de35630cc4ed85323b0f0f2cdd932d1928e42473  joint_carrier_common_binary_omen_run.log
```

## Reproduction on Omen

Environment: Python 3.10.12 and Z3 5.1.0.  From this directory run one
process:

```bash
python3 -u synthesize_joint_carrier_guard_model.py \
  --max-guard-rounds 1000 --json result.json
```

The frozen run terminated with exit status zero, printed
`JOINT_CARRIER_COMMON_BINARY_COUNTERMODEL_VERIFIED`, took 2.53 seconds, and
used 56,832 kB peak resident memory.  One legal guard coordinate was needed;
no membership-separator coordinate was needed.

## Scope

The computation is exhaustive over forbidden six-token decompositions of
the fixed common token pool.  It does not search graphs.  The model has no
common cubic vertex partition and is not closed under a graph-induced full
perfect-matching family, so it is not a Case-XII pole.
