#!/usr/bin/env python3
"""Synthesize the frozen common-binary exact-40 joint carrier countermodel.

This is deliberately below real-pole level: the coordinates are common
binary edge-incidence vectors, but no common cubic vertex partition is
imposed. The designated BF rows include the Note-055 columns, both
Note-057 transports, the four literal pivot rows, and three anchored target
rows. Each target replacement has a complete formal two-component flip
cube. CEGAR adds legal coordinates until all T-loop/T--T rows and all
target pair-sum memberships are separated.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path

from z3 import Bool, If, Int, Solver, Sum, is_true, sat


S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
POSITIONS = tuple(range(1, 6))
LITERAL_BOUNDARY = {"A": 1, "B": 2, "C": 4, "D": 5, "X": 3, "Y": 3}
LITERAL_SEEDS = {
    ((1, 3), (4, 5)): (("q13", "A", "X"), ("r45", "C", "D")),
    ((1, 4), (2, 3)): (("q14", "A", "C"), ("r23", "B", "X")),
    ((2, 4), (1, 5)): (("q24", "B", "C"), ("r15", "A", "D")),
    ((2, 5), (3, 4)): (("q25", "B", "D"), ("r34", "Y", "C")),
}
OVERLAPS = {
    ((1, 3), (1, 2)): (1, 3, 2, 5),
    ((2, 4), (2, 3)): (2, 4, 3, 1),
    ((3, 5), (3, 4)): (3, 5, 4, 2),
    ((1, 4), (4, 5)): (4, 1, 5, 3),
    ((2, 5), (1, 5)): (5, 2, 1, 4),
}


class ModelBuilder:
    def __init__(self):
        self.kind = {}
        self.boundary = {}
        self.rows = []
        self.row_names = []
        self.cube_relations = []
        self.st_base = {}
        self.t_halves = {}
        self.targets = []

    def singleton(self, name, position):
        self.kind.setdefault(name, "singleton")
        self.boundary.setdefault(name, position)
        assert self.kind[name] == "singleton" and self.boundary[name] == position
        return name

    def triple(self, name, state):
        state = tuple(sorted(state))
        self.kind.setdefault(name, "triple")
        self.boundary.setdefault(name, state)
        assert self.kind[name] == "triple" and self.boundary[name] == state
        return name

    def add_row(self, name, tokens):
        tokens = tuple(tokens)
        terminal_load = Counter()
        for token in tokens:
            if self.kind[token] == "singleton":
                terminal_load[self.boundary[token]] += 1
            else:
                state = self.boundary[token]
                for position in POSITIONS:
                    if position not in state:
                        terminal_load[position] += 1
        assert len(tokens) == 6
        assert all(terminal_load[position] == 2 for position in POSITIONS)
        self.row_names.append(name)
        self.rows.append(tokens)
        return tokens

    def build(self):
        for name, position in LITERAL_BOUNDARY.items():
            self.singleton(name, position)

        for state in T:
            literal = next(
                (right for (s, t), (_, right) in LITERAL_SEEDS.items() if t == state),
                None,
            )
            if literal is not None:
                self.triple(literal[0], state)
                self.singleton(literal[1], state[0])
                self.singleton(literal[2], state[1])
                self.t_halves[state] = literal
            elif state == (1, 2):
                self.t_halves[state] = (self.triple("r12", state), "A", "B")
            else:
                raise AssertionError(state)

        st_halves = {}
        for s in S:
            for t in T:
                literal = LITERAL_SEEDS.get((s, t))
                if literal is not None:
                    left, right = literal
                    self.triple(left[0], s)
                    self.singleton(left[1], s[0])
                    self.singleton(left[2], s[1])
                    assert right == self.t_halves[t]
                else:
                    left = (
                        self.triple(f"Q{s}@{t}", s),
                        self.singleton(f"p{s}@{t}:{s[0]}", s[0]),
                        self.singleton(f"p{s}@{t}:{s[1]}", s[1]),
                    )
                st_halves[(s, t)] = left
                row = self.add_row(f"ST:{s}:{t}:base", left + self.t_halves[t])
                self.st_base[(s, t)] = row

        s_halves = {}
        for s in S:
            s_halves[s] = (
                self.triple(f"QS{s}", s),
                self.singleton(f"ps{s}:{s[0]}", s[0]),
                self.singleton(f"ps{s}:{s[1]}", s[1]),
            )
        for first, second in combinations_with_replacement(S, 2):
            self.add_row(
                f"SS:{first}:{second}", s_halves[first] + s_halves[second]
            )

        for (s, t), (i, a, j, b) in OVERLAPS.items():
            left = st_halves[(s, t)]
            right = self.t_halves[t]
            p_i0 = next(token for token in left[1:] if self.boundary[token] == i)
            p_a = next(token for token in left[1:] if self.boundary[token] == a)
            p_i1 = next(token for token in right[1:] if self.boundary[token] == i)
            p_j = next(token for token in right[1:] if self.boundary[token] == j)
            target_s = tuple(sorted((a, b)))
            for branch, retained_i in enumerate((p_i1, p_i0)):
                p_b = self.singleton(f"transport:{s}:{t}:b{branch}", b)
                q = self.triple(f"transport:{s}:{t}:q{branch}", target_s)
                self.add_row(
                    f"transport:{s}:{t}:{branch}",
                    (q, right[0], p_a, p_b, retained_i, p_j),
                )

        target_specs = (
            ("BDXY", (3, 5), (2, 3), ("Y", "D"),
             (("A", "B", "C", "D"), ("A", "B", "X", "C"))),
            ("ACXY", (1, 3), (3, 4), ("A", "X"),
             (("B", "Y", "C", "D"), ("A", "B", "C", "D"))),
            ("ABDY", (3, 5), (1, 2), ("Y", "D"),
             (("A", "B", "C", "D"), ("A", "B", "X", "C"))),
        )
        for target_name, s, t, desired, anchors in target_specs:
            row = self.st_base[(s, t)]
            source = row[1:3]
            assert tuple(self.boundary[token] for token in source) == s
            assert tuple(self.boundary[token] for token in desired) == s
            replacements = []
            for index, (old, new, anchor_names) in enumerate(
                zip(source, desired, anchors)
            ):
                z0 = self.singleton(
                    f"cube:{target_name}:{index}:z0", self.boundary[old]
                )
                z1 = self.singleton(
                    f"cube:{target_name}:{index}:z1", self.boundary[old]
                )
                self.cube_relations.append((old, new, z0, z1))
                replacements.append({
                    "old": old, "new": new, "z0": z0, "z1": z1,
                    "anchors": anchor_names,
                })
            self.targets.append({
                "name": target_name,
                "row": row,
                "sources": source,
                "desired": desired,
                "replacements": replacements,
            })
        return self


def token_sum(bits, tokens):
    counts = Counter(tokens)
    return Sum(*(multiplicity * If(bits[token], 1, 0)
                 for token, multiplicity in counts.items()))


class CoordinateSynthesizer:
    def __init__(self, builder):
        self.builder = builder
        self.tokens = tuple(sorted(builder.kind))
        self.columns = []
        self.column_names = []

    def legal_solver(self):
        bits = {token: Bool(f"x_{index}") for index, token in enumerate(self.tokens)}
        solver = Solver()
        for row in self.builder.rows:
            solver.add(token_sum(bits, row) == 2)
        for old, new, z0, z1 in self.builder.cube_relations:
            solver.add(
                If(bits[z0], 1, 0) + If(bits[z1], 1, 0)
                == If(bits[old], 1, 0) + If(bits[new], 1, 0)
            )
        return solver, bits

    def add_from_model(self, name, bits, model):
        column = frozenset(
            token for token in self.tokens if is_true(model.eval(bits[token]))
        )
        assert all(sum(token in column for token in row) == 2
                   for row in self.builder.rows)
        if column not in self.columns:
            self.column_names.append(name)
            self.columns.append(column)
        return column

    def add_signature(self, name, fixed=None, require=None):
        fixed = fixed or {}
        solver, bits = self.legal_solver()
        for token, value in fixed.items():
            solver.add(bits[token] == value)
        if require is not None:
            require(solver, bits)
        if solver.check() != sat:
            return None
        return self.add_from_model(name, bits, solver.model())

    def add_terminal_columns(self):
        for position in POSITIONS:
            fixed = {}
            for token in self.tokens:
                if self.builder.kind[token] == "singleton":
                    fixed[token] = self.builder.boundary[token] == position
                else:
                    fixed[token] = position not in self.builder.boundary[token]
            assert self.add_signature(f"terminal:{position}", fixed=fixed) is not None

    def add_cube_component_columns(self):
        for index, (old, new, z0, z1) in enumerate(self.builder.cube_relations):
            patterns = (
                (1, 0, 0, 1), (0, 1, 1, 0),
                (1, 0, 1, 0), (0, 1, 0, 1),
            )
            for pattern_index, pattern in enumerate(patterns):
                fixed = dict(zip((old, new, z0, z1), map(bool, pattern)))
                assert self.add_signature(
                    f"cube:{index}:pattern:{pattern_index}", fixed=fixed
                ) is not None, (index, pattern)

    def add_overloads(self):
        target_singletons = {
            "BDXY": ("B", "D", "X", "Y"),
            "ACXY": ("A", "C", "X", "Y"),
            "ABDY": ("A", "B", "D", "Y"),
        }
        for name, tokens in target_singletons.items():
            def require(solver, bits, tokens=tokens):
                solver.add(token_sum(bits, tokens) >= 3)
            assert self.add_signature(f"overload:{name}", require=require) is not None

    def add_d2_hitting(self):
        for target in self.builder.targets:
            for replacement in target["replacements"]:
                anchors = replacement["anchors"]
                for member in (
                    replacement["old"], replacement["new"],
                    replacement["z0"], replacement["z1"],
                ):
                    def require(solver, bits, anchors=anchors, member=member):
                        solver.add(token_sum(bits, anchors) == 2)
                        solver.add(bits[member])
                    assert self.add_signature(
                        f"D2:{target['name']}:{member}", require=require
                    ) is not None, (target["name"], member, anchors)

    def forbidden_candidate(self, first, second):
        allowed = []
        required_singletons = Counter(first + second)
        for token in self.tokens:
            if self.builder.kind[token] == "triple":
                if self.builder.boundary[token] in (first, second):
                    allowed.append(token)
            elif required_singletons[self.builder.boundary[token]]:
                allowed.append(token)
        multiplicity = {token: Int(f"m_{index}") for index, token in enumerate(allowed)}
        solver = Solver()
        for value in multiplicity.values():
            solver.add(value >= 0, value <= 2)
        for state in set((first, second)):
            terms = [
                multiplicity[token] for token in allowed
                if self.builder.kind[token] == "triple"
                and self.builder.boundary[token] == state
            ]
            solver.add(Sum(*terms) == (2 if first == second else 1))
        for position, count in required_singletons.items():
            terms = [
                multiplicity[token] for token in allowed
                if self.builder.kind[token] == "singleton"
                and self.builder.boundary[token] == position
            ]
            solver.add(Sum(*terms) == count)
        for column in self.columns:
            solver.add(Sum(*(
                value for token, value in multiplicity.items() if token in column
            )) == 2)
        if solver.check() != sat:
            return None
        model = solver.model()
        return {
            token: model.eval(value).as_long()
            for token, value in multiplicity.items()
            if model.eval(value).as_long()
        }

    def separate_candidate(self, name, candidate):
        solver, bits = self.legal_solver()
        solver.add(Sum(*(
            multiplicity * If(bits[token], 1, 0)
            for token, multiplicity in candidate.items()
        )) != 2)
        if solver.check() != sat:
            return None
        return self.add_from_model(name, bits, solver.model())

    def eliminate_forbidden_support(self, max_rounds):
        forbidden_types = tuple(combinations_with_replacement(T, 2))
        rounds = []
        for round_number in range(max_rounds):
            found = None
            for first, second in forbidden_types:
                candidate = self.forbidden_candidate(first, second)
                if candidate is not None:
                    found = (first, second, candidate)
                    break
            if found is None:
                return rounds
            first, second, candidate = found
            column = self.separate_candidate(
                f"guard:{round_number}:{first}:{second}", candidate
            )
            if column is None:
                raise RuntimeError({
                    "kind": "forced_forbidden_row",
                    "type": (first, second),
                    "candidate": candidate,
                    "guard_rounds": len(rounds),
                })
            rounds.append({
                "type": (first, second),
                "candidate": tuple(sorted(candidate.items())),
                "column_size": len(column),
            })
        raise RuntimeError({"kind": "guard_round_limit", "rounds": max_rounds})

    def vectors(self):
        return {
            token: tuple(token in column for column in self.columns)
            for token in self.tokens
        }

    def separate_vector_membership(self, label, expression, boundary, kind):
        candidates = [
            token for token in self.tokens
            if self.builder.boundary[token] == boundary
            and self.builder.kind[token] == kind
        ]
        added = 0
        for candidate in candidates:
            vectors = self.vectors()
            rhs = tuple(
                sum(coefficient * vectors[token][i]
                    for token, coefficient in expression.items())
                for i in range(len(self.columns))
            )
            if vectors[candidate] != rhs:
                continue
            solver, bits = self.legal_solver()
            solver.add(
                If(bits[candidate], 1, 0)
                != Sum(*(coefficient * If(bits[token], 1, 0)
                         for token, coefficient in expression.items()))
            )
            if solver.check() != sat:
                raise RuntimeError({
                    "kind": "forced_vector_membership",
                    "label": label,
                    "candidate": candidate,
                    "expression": expression,
                })
            self.add_from_model(f"membership:{label}:{candidate}", bits, solver.model())
            added += 1
        return added

    def eliminate_target_memberships(self):
        report = {}
        for target in self.builder.targets:
            row = target["row"]
            target_added = 0
            for replacement_index, replacement in enumerate(target["replacements"]):
                old = replacement["old"]
                new = replacement["new"]
                companions = list(row)
                companions.remove(old)
                for companion in companions:
                    target_added += self.separate_vector_membership(
                        f"{target['name']}:endpoint:{replacement_index}:{companion}",
                        {companion: 1, old: 1, new: -1},
                        self.builder.boundary[companion],
                        self.builder.kind[companion],
                    )
            old0, old1 = target["sources"]
            new0, new1 = target["desired"]
            target_added += self.separate_vector_membership(
                f"{target['name']}:forced-intermediate:0",
                {new0: 1, new1: 1, old1: -1},
                self.builder.boundary[old0],
                "singleton",
            )
            target_added += self.separate_vector_membership(
                f"{target['name']}:forced-intermediate:1",
                {new0: 1, new1: 1, old0: -1},
                self.builder.boundary[old1],
                "singleton",
            )
            report[target["name"]] = target_added
        return report


def evaluate_forbidden(synth):
    return {
        (first, second): synth.forbidden_candidate(first, second)
        for first, second in combinations_with_replacement(T, 2)
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-guard-rounds", type=int, default=1000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    builder = ModelBuilder().build()
    synth = CoordinateSynthesizer(builder)
    synth.add_terminal_columns()
    synth.add_cube_component_columns()
    synth.add_overloads()
    synth.add_d2_hitting()
    guard_rounds = synth.eliminate_forbidden_support(args.max_guard_rounds)
    membership_columns = synth.eliminate_target_memberships()
    assert all(value is None for value in evaluate_forbidden(synth).values())
    assert len(builder.rows) == 50
    assert len(builder.cube_relations) == 6
    assert membership_columns == {target["name"]: 0 for target in builder.targets}

    for target in builder.targets:
        for replacement in target["replacements"]:
            anchors = replacement["anchors"]
            for member in (
                replacement["old"], replacement["new"],
                replacement["z0"], replacement["z1"],
            ):
                assert any(
                    member in column
                    and sum(token in column for token in anchors) == 2
                    for column in synth.columns
                )
    payload = {
        "status": "common_binary_countermodel",
        "tokens": len(synth.tokens),
        "designated_rows": len(builder.rows),
        "SS_cells": 15,
        "ST_cells": 25,
        "note057_transport_rows": 10,
        "cube_relations": len(builder.cube_relations),
        "cube_members_per_relation": 4,
        "coordinates": len(synth.columns),
        "guard_rounds": len(guard_rounds),
        "membership_separator_columns": membership_columns,
        "forbidden_Tloop_TT": 0,
        "A_tokens": 0,
        "literal_target_overloads": 3,
        "D2_cube_hitting": True,
        "sequential_endpoint_memberships": 0,
        "forced_intermediate_memberships": 0,
        "missing_real_pole_axiom": "common cubic vertex partition and its full PM closure",
        "coordinate_names": synth.column_names,
        "guard_records": guard_rounds,
        "vectors": {
            token: "".join("1" if token in column else "0" for column in synth.columns)
            for token in synth.tokens
        },
    }
    if args.json:
        args.json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    compact = {
        key: value for key, value in payload.items()
        if key not in ("coordinate_names", "guard_records", "vectors")
    }
    print(json.dumps(compact, indent=2, sort_keys=True))
    print("JOINT_CARRIER_COMMON_BINARY_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
