# Canonical triple-hit local-incidence boundary

This bundle verifies the finite local statement used in
[Note 073](../../../notes/073-local-trivalent-incidence-does-not-force-the-six-singleton-gate.md).
For the canonical failed pivot star, it enumerates every binary proper-edge
signature having load two on the four designated BF rows, identifies the
eight possible three-singleton hit patterns, and verifies that every pattern
extends to a partition into three legal signatures at a trivalent vertex.

Run on Omen with one process:

```bash
python3 verify.py
```

The final line is

```text
CANONICAL_TRIPLE_HIT_LOCAL_BOUNDARY_VERIFIED
```

The script uses only the Python standard library.  The promoted run on
2026-09-04 used Python 3.14, took 0.03 seconds, and had peak RSS 9,216 KB.
Its output is frozen in [`omen-run.log`](omen-run.log).
