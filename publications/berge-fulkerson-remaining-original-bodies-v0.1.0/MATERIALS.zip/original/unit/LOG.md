# F5 run-to-verdict — 2026-09-13

脉冲 1/5（R1）：五线调色板及带根轨道的有限分类。
结果：五线集合单轨道；固定调色板有 3 个点轨道、6 个有序星轨道。
证据：notes/110-fano-five-line-rooted-orbits.md；computations/fano-r1-20260913/{classification.json,verify_geometry.py}。
最薄弱一步：真实图的重新着色未纳入轨道分类。
下一命题：真实指定边五线着色的自同构二和是否总成功。

脉冲 2/5（R1）：给定真实五线着色能否一律仅靠自同构作五线二和。
结果：否；十顶点图两份的指定边要求不同点轨道对齐，最小线并集 6。
证据：notes/111-fixed-fano-colorings-can-block-two-sums.md；computations/fano-r1-20260913/{graph.json,check_graph.py}。
最薄弱一步：所得二和实际有一线重着色，不是 R1 NOGO 或 F5 反例。
下一命题：非平凡三和的固定着色自同构版本是否也失败。

脉冲 3/5（R1）：非平凡三和的给定五线着色能否一律仅靠自同构拼接。
结果：否；删除十顶点 H 的不同类型顶点，指定端口约束的最小并集为 6。
证据：notes/112-fixed-fano-colorings-can-block-three-sums.md；computations/fano-r1-20260913/check_graph.py（独立枚举）。
最薄弱一步：十八顶点三和仍有一线着色；R1 完整重着色判据未失败。
下一命题：一侧一线着色时的有限接口及二和、三和保持性。

脉冲 4/5（R1）：一线源对至多五线目标的全部指定点/星接口。
结果：728 个点接口、2394 个星接口全部可延拓；得到一侧三边可着色的二和、三和保持定理。
证据：notes/113-one-line-factors-preserve-fano-five-line-sums.md；computations/fano-r1-20260913/verify_interface.py（独立构造）。
最薄弱一步：两侧均非三边可着色时的全着色接口交集未控制。
下一命题：完整两极/三极五线着色的有限轨道交集是否给出精确拼接判据。

脉冲 5/5（R1）：完整两极／三极边界的有限轨道接口与拼接判据。
结果：3／9 个轨道；真实全着色支持相交当且仅当拼接图有 F5 着色。
证据：notes/114-fano-sum-exact-boundary-support-reduction.md；computations/fano-r1-20260913/verify_profiles.py；终态报告 notes/115-fano-five-lines-budget-verdict.md。
最薄弱一步：实际 F5 因子的完整支持是否必相交仍未决，R1 无 GO/NOGO。
下一命题：实际两极三位／三极九位支持的相交性，保留全部重着色与端口顺序。
TERMINAL: BUDGET
