# D5 tree-exchange Helly boundary

## Decision

This pulse attacks only the remaining real-incidence implication for the
Case-XII D5 gate.  Notes 047, 042 and 021 were read first.  The path-toggle
transfer of 047 is used below; the common-vector, integer-load and formal
exchange countermodels of 042 and 021 are not reused as arguments.

The Case-XII assumptions still do **not** yield a proof of a four-of-five
natural join, and no real pole with the complete forty-type support and all
five joins empty was constructed.  The exact unresolved arrow remains

\[
 \text{one common cubic perfect-matching family}
 +\text{ complete Case-XII support}
 \;\Longrightarrow\; ?\;
 \text{one D5 four-cell join}.                 \tag{D5}
\]

The non-tautological positive result in this pulse is a matching-level Helly
criterion.  It is an additional hypothesis on an actual pole, not a claim
that Case XII supplies the hypothesis.

## The exact pivot fibre

Let

\[
 S=\{13,14,24,25,35\},\qquad
 \mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

Use the actual singleton relations after the transfer in Note 047 (the same
relations may equivalently be taken on the five disjoint S--S cells).  Fix a
four-cell set

\[
 J=\mathcal D_5\setminus\{d_0\},
\]

an anchor cell \(a\in J\), and an actual witness tuple
\(x\in\widehat\Pi_a\).  Let \(m=m(a)\) be the unique terminal missing from
the anchor scope.  For every \(d\in J\setminus\{a\}\), define the actual
extension fibre

\[
 E_d(x)=\{P\in\mathcal P_m:\text{ some witness in }\widehat\Pi_d
 \text{ agrees with }x\text{ on }U_a\cap U_d
 \text{ and uses }P\text{ at }m\}.                 \tag{1}
\]

The pivot identity is exact:

\[
 x\text{ extends to a tuple in }\bigcap_{d\in J}\Pi_d
 \quad\Longleftrightarrow\quad
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing .    \tag{2}
\]

This is an equality of sets of actual perfect matchings of one pole.  No
edge-load relaxation is involved.

## Actual exchange graph and Helly criterion

For a terminal (m), let \(X_m(H)\) be the graph whose vertices are the
actual matchings in \(\mathcal P_m\), with an edge \(P\!\sim\!P'\) when
\(P\triangle P'\) is one proper alternating cycle.  Every same-boundary
matching difference is a disjoint union of proper alternating cycles, so
flipping its components gives paths in (X_m(H)).  This is the genuine
single-cycle exchange graph, not a formal vector graph.

The following criterion is sufficient for (D5).

**Tree-exchange Helly condition.**  For at least one choice of
\((J,a,x)\),

1. \(X_m(H)\) is a tree;
2. each of the three fibres \(E_d(x)\) is a connected nonempty subtree of
   \(X_m(H)\);
3. the three subtrees are pairwise intersecting.

Under these three conditions, the three fibres have a common vertex.  Indeed,
finite subtrees of a tree satisfy the Helly property: if three subtrees had
empty total intersection, the unique paths joining a pair of them would have
to separate the third, contradicting pairwise intersection.  Applying (2)
gives a common five-singleton tuple in the four cylinders of (J).  The
standard four-cell load argument then gives the forbidden
\(A=(12345)\) BF cover.  Thus

\[
 \boxed{\text{tree-exchange Helly condition}\Longrightarrow\text{D5 join}\Longrightarrow A.}
\]

The condition is not comparable with UE2 as a bare logical package: it allows
non-singleton fibres, but it adds the tree and connected-subtree hypotheses
that UE2 does not require.  Its value is that the required agreement is only
pairwise, with the final three-way intersection supplied by an actual
matching-exchange Helly theorem.  It is also different from 3ER: no unique
three-coordinate projection is assumed; exchange connectivity and subtree
convexity replace uniqueness.

## Why the Case-XII hypotheses do not prove the criterion

Complete forty-type support gives nonemptiness of each individual cell only.
The forbidden A, T-loop and T--T types determine the endpoint-pairing column
in the 047 path-toggle table, hence transfer each D5 S--T relation to one
disjoint S--S relation.  They do not imply any of the three new requirements:

* the actual singleton exchange graph \(X_m(H)\) can contain commuting
  cycle-flip loops;
* a pivot fibre can be disconnected inside \(X_m(H)\), because a change of
  the missing singleton may be absorbed by simultaneous changes of the two
  triple matchings;
* pairwise intersections of the three pivot fibres are a cross-cell witness
  reuse assertion, absent from support nonemptiness.

The exact same-cell and adjacent-cell subtraction identities are respectively

\[
 (\chi_{Q'_u}-\chi_{Q_u})+(\chi_{Q'_v}-\chi_{Q_v})
 +(\chi_{P'_j}-\chi_{P_j})=0,
\]

and the corresponding path/cycle identity with the two distinct singleton
endpoints.  These are real alternating-cycle/path certificates, but they do
not force connectivity or pairwise intersection of the fibres.  Notes 042 and
021 already show that aggregate or formal exchange data cannot perform this
quantifier exchange; this pulse adds no such model.

## Four-value stop

* **Analytic proof of (D5):** not obtained.
* **Real exact-40 Case-XII pole violating (D5):** not obtained.
* **Sharp additional condition:** obtained — the tree-exchange Helly
  condition above, which is entirely phrased using actual singleton PMs and
  alternating-cycle exchanges of one cubic pole.
* **Current status:** strictly unresolved at the remaining pairwise
  fibre-overlap/convexity arrow.  No order expansion, abstract relation/load
  model, route audit, or repeated census was used.

Any future positive proof must derive either this criterion (or a broader
median/convex exchange analogue) from the negative T/TT support, while any
negative result must realize all forty Case-XII types in one genuine pole and
violate all five four-cell joins.
