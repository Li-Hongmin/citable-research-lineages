# D5 saturated-edge blocker and alternating-path carrier boundary

## Scope

This note isolates one necessary condition at the remaining real-incidence
gate.  It uses one actual D5 completion on one cubic five-pole; no relation
model, order scan, or aggregate relaxation is used.  The statement is useful
whether or not the pole is Tait-colourable.

Write a D5 cell as (d_m), where its four singleton classes are
(U_m=[5]\setminus{m}).  An actual witness consists of

\[
  Q,Q'\,,\qquad (P_i)_{i\in U_m},
  \qquad
  \chi_Q+\chi_{Q'}+\sum_{i\in U_m}\chi_{P_i}=2\mathbf 1 .
  \tag{1}
\]

Here (Q,Q') are the two triple-boundary matchings after the standard D5
transfer to the corresponding disjoint S--S cell.  Define the singleton
load and saturated set

\[
  \ell_e=\sum_{i\in U_m}\chi_{P_i}(e),
  \qquad F=\{e:\ell_e=2\}.
  \tag{2}
\]

Equation (1) gives (ell_e\le 2) and (Q,Q') avoid (F).

## Saturated-set blocker lemma

Let (mathcal P_m) be the actual singleton-boundary perfect matchings using
semiedge (m).  If some (P\inmathcal P_m) avoids (F), then the five
singleton matchings

\[
  (P_i)_{i\in U_m},P
\]

have every proper-edge load at most two.  At an internal cubic vertex the
five incidences sum to five, so the three proper-edge loads are exactly
((2,2,1)).  At every terminal the semiedge has load one and the two proper
edges have load two.  Hence the load-one edges form a perfect matching
(P_0), and

\[
  P_0,P_1,P_2,P_3,P_4,P_5
\]

is an A-type Berge--Fulkerson cover.  Consequently, in an A-free pole,

\[
  \boxed{F\text{ meets every actual }P\in\mathcal P_m.}
  \tag{3}
\]

This is a genuine matching-preclusion statement.  It is stronger than saying
that the selected five singleton vectors have no common extension: (F) is a
literal proper-edge blocker for one complete singleton class.

## Local shape of (F)

The set (F) contains no semiedge.  At the terminal (v_m), all four
selected singleton matchings cover (v_m) through proper edges, so both
proper edges incident with (v_m) lie in (F).  At each other terminal, one
singleton uses its semiedge and the other three use proper edges; exactly one
of the two proper edges is in (F).  At an internal vertex the four proper
loads are either ((2,2,0)) or ((2,1,1)), up to order.  Thus

\[
  d_F(v_m)=2,\qquad d_F(v_i)=1 (i\ne m),\qquad
  d_F(v)\in\{1,2\}\text{ internally}.
  \tag{4}
\]

Any D5 witness in an A-free pole therefore carries a blocker with the shape
(4), in addition to (3).  A proper-edge cycle component of (F) is not
forbidden by (4); the blocker is not automatically a cut.

## Alternating-path carrier refinement

Fix a witness (1), and choose (P\in\mathcal P_m) minimizing
(|P\cap F|).  By (3), this minimum is positive.  For (R\in\{Q,Q'\}),
the symmetric difference (P\triangle R) has exactly one boundary path: the
common semiedge (m) cancels, and the two remaining boundary semiedges in
the triple class of (R) are its endpoints; all other components are proper
even alternating cycles.  Since (R\cap F=\varnothing), flipping any cycle
component that contains an edge of (P\cap F) would produce another member
of (mathcal P_m) with strictly smaller (F)-intersection.  Therefore every
F-edge used by this minimizing (P) lies on the unique boundary path in
(P\triangle R).  This holds for both (R=Q) and (R=Q'):

\[
  \boxed{
  \varnothing\ne P\cap F
  \subseteq L(P,Q)\cap L(P,Q'),
  }
  \tag{5}
\]

where (L(P,R)) denotes the unique proper alternating path after deleting
the common semiedge (m).

Thus failure of the A-extension is not an arbitrary set-system obstruction:
it forces a literal alternating carrier.  Any proof of the D5 join must now
exclude (5), or show that the five carriers arising from the five D5 cells
can be synchronized into one common singleton tuple.

## Rigid two-edge corollary

There is a useful small obstruction to a proposed blocker proof.  Suppose a
fixed pair (B=\{a,b\}) of proper edges has the following *class-rigid*
property: every (P\in\mathcal P_i) uses exactly one edge of (B), and the
same edge is used for all (P\in\mathcal P_i).  If all five D5 cells are
present, this is impossible.  Indeed, in every D5 witness the four singleton
occurrences contribute four incidences on (B), already equal to the target
load (2+2); the two triple matchings avoid (B), and exactly two of the four
classes must choose (a).  Writing (c_i\in\{0,1\}) for the rigid choice,

\[
  \sum_{i\ne m}c_i=2\qquad(m=1,\ldots,5).
  \tag{6}
\]

Subtracting two equations gives (c_i=c_j) for all (i,j), while (6) then
requires (4c_i=2), impossible.  Hence any two-edge blocker compatible with
all five D5 supports must have at least one non-rigid singleton class (or fail
the exact-one hypothesis).  The existing balanced blockers satisfy this
necessary flexibility; this corollary does not prove the D5 join.

## Four-value decision

* **General D5 witness-reuse proof:** not obtained.  The quantifier exchange
  remains open even after (3)--(5).
* **Real exact-40 pole violating the join:** none supplied.  A real pole with
  exact Case-XII support and all five D5 joins empty is still unknown.
* **Load-bearing necessary boundary:** every D5 witness in an A-free pole
  induces a literal blocker (3) with local shape (4), and a minimum blocker
  carrier satisfies (5).  A class-rigid balanced two-edge blocker is
  incompatible with all five D5 cells by (6).
* **Remaining thin interface:** derive a blocker-to-T-loop/T--T implication
  from (3)--(5), or prove that the five actual carrier systems synchronize to
  a four-cell cylinder join.  Common incidence and alternating-cycle closure
  alone have not supplied that step.

This is a strict boundary result, not a Case-XII exclusion.
