#!/usr/bin/env python3
"""Targeted carrier audit for D5 saturation blockers on one real pole.

This is deliberately not a census.  It uses the frozen order-13 simple
connected cubic five-pole with all S--T cells and no A-cover.  For every
actual D5 six-matching witness it computes the saturated proper-edge set F,
then checks the minimum-F singleton in the omitted class and the alternating
path carrier in each of the two triple differences.

The output tests only the blocker/carrier refinement from
d5-saturated-blocker-carrier-boundary-20260901.md.  It does not test a
general Case-XII implication.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from itertools import combinations, product
from pathlib import Path
import importlib.util
import json
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
KEMPE = ROOT / "units/berge-fulkerson/scratch/worker-kempe"
FROZEN_PATH = KEMPE / "verify_cubic_all_ss_realization.py"
JOINT_PATH = KEMPE / "exact_st_joint_audit.py"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


FROZEN = load("d5_carrier_frozen", FROZEN_PATH)
JOINT = load("d5_carrier_joint", JOINT_PATH)

S = JOINT.S
T = JOINT.T
ALL_ST = tuple(sorted(tuple(sorted((s, t))) for s in S for t in T))
D5 = tuple(sorted(
    kind for kind in ALL_ST
    if set(kind[0]).isdisjoint(kind[1])
))


def all_witnesses(kind, data):
    """Return every actual six-PM witness for one D5 cell."""
    edges, _, _, _, classes, _ = data
    first, second = kind
    first_family = classes[JOINT.complement(first)]
    second_family = classes[JOINT.complement(second)]
    if first == second:
        bases = (
            (q0, q1)
            for i, q0 in enumerate(first_family)
            for q1 in first_family[i:]
        )
    else:
        bases = product(first_family, second_family)
    slots = tuple(first + second)
    records = []
    for q0, q1 in bases:
        load = [0] * len(edges)
        for matching in (q0, q1):
            for edge in matching:
                load[edge] += 1
        if any(value > 2 for value in load):
            continue
        for singleton_tuple in product(*(classes[(i,)] for i in slots)):
            trial = load[:]
            for matching in singleton_tuple:
                for edge in matching:
                    trial[edge] += 1
            if all(value == 2 for value in trial):
                records.append((q0, q1, slots, singleton_tuple))
    return tuple(records)


def edge_components(F, edges, edge_vertices, n):
    """Components and degrees of a proper-edge set."""
    graph = {v: set() for v in range(n)}
    for edge_id in F:
        endpoints = edge_vertices[edges[edge_id]]
        if len(endpoints) != 2:
            raise AssertionError("semiedge in F")
        u, v = endpoints
        graph[u].add(v)
        graph[v].add(u)
    unseen = set(graph)
    components = []
    while unseen:
        root = min(unseen)
        seen = {root}
        queue = deque([root])
        while queue:
            u = queue.popleft()
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    queue.append(v)
        unseen -= seen
        component_edges = tuple(sorted(
            edge_id for edge_id in F
            if set(edge_vertices[edges[edge_id]]) <= seen
        ))
        degrees = tuple(sorted(len(graph[v]) for v in seen))
        components.append({
            "vertices": tuple(sorted(seen)),
            "edges": component_edges,
            "edge_count": len(component_edges),
            "vertex_count": len(seen),
            "is_cycle": len(component_edges) == len(seen),
            "degree_multiset": degrees,
        })
    return tuple(sorted(components, key=lambda row: row["vertices"]))


def alternating_components(first, second, edges, edge_vertices, edge_position):
    """Components of first △ second, with proper and boundary edges."""
    symmetric = set(first) ^ set(second)
    graph = defaultdict(set)
    terminal_labels = defaultdict(set)
    for edge_id in symmetric:
        edge = edges[edge_id]
        endpoints = edge_vertices[edge]
        if len(endpoints) == 2:
            u, v = endpoints
            graph[("v", u)].add(("v", v))
            graph[("v", v)].add(("v", u))
        elif len(endpoints) == 1:
            u = endpoints[0]
            terminal = ("t", edge_position[edge])
            graph[("v", u)].add(terminal)
            graph[terminal].add(("v", u))
            terminal_labels[terminal].add(edge_id)
        else:
            raise AssertionError(endpoints)
    unseen = set(graph)
    output = []
    while unseen:
        root = min(unseen, key=str)
        seen = {root}
        stack = [root]
        while stack:
            u = stack.pop()
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        unseen -= seen
        proper = tuple(sorted(
            edge_id for edge_id in symmetric
            if len(edge_vertices[edges[edge_id]]) == 2
            and all(("v", x) in seen for x in edge_vertices[edges[edge_id]])
        ))
        terminals = tuple(sorted(
            node[1] for node in seen if node[0] == "t"
        ))
        boundary_edges = tuple(sorted(
            edge_id for edge_id in symmetric
            if len(edge_vertices[edges[edge_id]]) == 1
            and ("t", edge_position[edges[edge_id]]) in seen
        ))
        output.append({
            "proper_edges": proper,
            "terminals": terminals,
            "boundary_edges": boundary_edges,
            "is_boundary_path": len(terminals) == 2,
        })
    return tuple(sorted(output, key=lambda row: (row["terminals"], row["proper_edges"])))


def inspect_witness(record, missing, data):
    q0, q1, slots, singleton_tuple = record
    edges, edge_vertices, edge_position, _, classes, _ = data
    load = [0] * len(edges)
    for matching in singleton_tuple:
        for edge in matching:
            load[edge] += 1
    F = frozenset(edge for edge, value in enumerate(load) if value == 2)
    if any(len(edge_vertices[edges[e]]) != 2 for e in F):
        raise AssertionError("saturated set contains semiedge")
    omitted_family = classes[(missing,)]
    intersections = tuple(sorted(
        (len(set(matching) & F), matching)
        for matching in omitted_family
    ))
    minimum = intersections[0][0]
    minimizers = tuple(matching for value, matching in intersections if value == minimum)
    blockers = all(value > 0 for value, _ in intersections)
    f_components = edge_components(F, edges, edge_vertices, 13)
    paths0 = alternating_components(q0, minimizers[0], edges, edge_vertices, edge_position)
    paths1 = alternating_components(q1, minimizers[0], edges, edge_vertices, edge_position)
    carriers0 = tuple(row for row in paths0 if row["is_boundary_path"])
    carriers1 = tuple(row for row in paths1 if row["is_boundary_path"])
    if len(carriers0) != 1 or len(carriers1) != 1:
        raise AssertionError((missing, carriers0, carriers1))
    carrier0 = set(carriers0[0]["proper_edges"])
    carrier1 = set(carriers1[0]["proper_edges"])
    f_intersection = set(minimizers[0]) & F
    carrier_ok = f_intersection <= carrier0 and f_intersection <= carrier1
    return {
        "missing": missing,
        "slots": slots,
        "F": tuple(sorted(F)),
        "F_size": len(F),
        "F_components": f_components,
        "omitted_class_size": len(omitted_family),
        "minimum_F_intersection": minimum,
        "minimum_matching_count": len(minimizers),
        "blocker": blockers,
        "carrier0_terminals": carriers0[0]["terminals"],
        "carrier1_terminals": carriers1[0]["terminals"],
        "carrier0_length": len(carrier0),
        "carrier1_length": len(carrier1),
        "carrier_F_intersection_size": len(f_intersection & carrier0 & carrier1),
        "carrier_inclusion_holds": carrier_ok,
    }


def audit(edges):
    pole = JOINT.base.legacy.Pole(n=13, proper_edges=tuple(edges))
    data = JOINT.matching_data(pole)
    edge_list, edge_vertices, _, _, classes, pm_count = data
    all_rows = []
    cell_summary = {}
    for cell in D5:
        missing = tuple(set(range(1, 6)) - set(cell[0]) - set(cell[1]))
        assert len(missing) == 1
        m = missing[0]
        rows = [inspect_witness(record, m, data) for record in all_witnesses(cell, data)]
        all_rows.extend(rows)
        cell_summary[str(cell)] = {
            "missing": m,
            "witnesses": len(rows),
            "blockers": sum(row["blocker"] for row in rows),
            "nonblockers": sum(not row["blocker"] for row in rows),
            "carrier_inclusion_failures": sum(
                not row["carrier_inclusion_holds"] for row in rows
            ),
            "F_component_count": dict(Counter(
                len(row["F_components"]) for row in rows
            )),
            "F_cycle_component_count": dict(Counter(
                sum(part["is_cycle"] for part in row["F_components"])
                for row in rows
            )),
            "minimum_F_intersection": dict(Counter(
                row["minimum_F_intersection"] for row in rows
            )),
        }
    assert all(row["blocker"] for row in all_rows)
    assert all(row["carrier_inclusion_holds"] for row in all_rows)
    component_shapes = Counter()
    for row in all_rows:
        shape = tuple(
            (part["vertex_count"], part["edge_count"], part["is_cycle"])
            for part in row["F_components"]
        )
        component_shapes[shape] += 1
    return {
        "perfect_matchings": pm_count,
        "D5_cells": len(D5),
        "total_witnesses": len(all_rows),
        "all_blockers": True,
        "all_carrier_inclusions": True,
        "cell_summary": cell_summary,
        "F_component_shapes": {
            str(shape): count for shape, count in sorted(component_shapes.items(), key=str)
        },
        "F_size_distribution": dict(Counter(row["F_size"] for row in all_rows)),
        "minimum_intersection_distribution": dict(
            Counter(row["minimum_F_intersection"] for row in all_rows)
        ),
        "carrier_length_pairs": dict(
            (str(pair), count)
            for pair, count in Counter(
                (row["carrier0_length"], row["carrier1_length"])
                for row in all_rows
            ).items()
        ),
        "carrier_F_intersection_distribution": dict(
            Counter(row["carrier_F_intersection_size"] for row in all_rows)
        ),
    }


def main():
    result = {"all_st_no_a": audit(FROZEN.PROPER_EDGES)}
    print(json.dumps(result, indent=2, sort_keys=True))
    print("D5_CARRIER_AUDIT_OK")


if __name__ == "__main__":
    main()
