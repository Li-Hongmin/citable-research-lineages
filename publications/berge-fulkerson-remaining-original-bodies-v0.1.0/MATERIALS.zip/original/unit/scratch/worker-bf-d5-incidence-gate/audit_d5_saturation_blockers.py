#!/usr/bin/env python3
"""Targeted diagnostic for D5 saturation blockers on the two frozen poles.

This is not a census.  It enumerates every actual D5 S--T witness on the two
order-13 boundary poles already used in the pivot audit, computes the four-
singleton saturation set F, and records whether F meets every matching in the
omitted singleton class.  The run is intended to test the new blocker lemma
and expose the smallest local shapes; all computation is to be run on omen.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
JOINT_PATH = ROOT / "units/berge-fulkerson/scratch/worker-kempe/exact_st_joint_audit.py"
FROZEN_PATH = ROOT / "units/berge-fulkerson/scratch/worker-kempe/verify_cubic_all_ss_realization.py"
GATE_PATH = ROOT / "units/berge-fulkerson/scratch/worker-bf-5cut-common-incidence/verify_c5_fibre_and_disjoint_four_gate.py"


def load(name: str, path: Path):
    spec = spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


JOINT = load("d5_blocker_joint", JOINT_PATH)
FROZEN = load("d5_blocker_frozen", FROZEN_PATH)
GATE = load("d5_blocker_gate", GATE_PATH)


def components(vertices, edges):
    adjacency = {v: [] for v in vertices}
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    unseen = set(vertices)
    result = []
    while unseen:
        root = min(unseen)
        seen = {root}
        queue = deque([root])
        while queue:
            u = queue.popleft()
            for v in adjacency[u]:
                if v not in seen:
                    seen.add(v)
                    queue.append(v)
        unseen -= seen
        result.append(frozenset(seen))
    return tuple(result)


def all_witnesses(kind, classes, edge_count):
    first, second = kind
    first_family = classes[JOINT.complement(first)]
    second_family = classes[JOINT.complement(second)]
    if first == second:
        bases = ((q0, q1) for i, q0 in enumerate(first_family)
                 for q1 in first_family[i:])
    else:
        bases = product(first_family, second_family)
    slots = tuple(first + second)
    records = []
    for q0, q1 in bases:
        load = [0] * edge_count
        for matching in (q0, q1):
            for edge in matching:
                load[edge] += 1
        if any(value > 2 for value in load):
            continue
        for singleton_tuple in product(*(classes[(position,)] for position in slots)):
            trial = list(load)
            for matching in singleton_tuple:
                for edge in matching:
                    trial[edge] += 1
            if all(value == 2 for value in trial):
                records.append((q0, q1, slots, singleton_tuple))
    return tuple(records)


def audit(edges):
    pole = GATE.load_existing_interface().loop_interface.pole(edges)
    data = JOINT.matching_data(pole)
    edge_list, edge_vertices, _, _, classes, pm_count = data
    edge_count = len(edge_list)
    edge_set = set(range(edge_count))
    out = {"perfect_matchings": pm_count, "cells": {}}
    for cell in GATE.D5:
        first, second = cell
        missing = tuple(set(range(1, 6)) - set(first) - set(second))
        assert len(missing) == 1
        m = missing[0]
        records = all_witnesses(cell, classes, edge_count)
        rows = []
        shape = Counter()
        blockers = 0
        for q0, q1, slots, singleton_tuple in records:
            load = [0] * edge_count
            for matching in singleton_tuple:
                for edge in matching:
                    load[edge] += 1
            assert max(load, default=0) <= 2
            F = frozenset(edge for edge, value in enumerate(load) if value == 2)
            hit = all(F & set(matching) for matching in classes[(m,)])
            if hit:
                blockers += 1
            proper_F = [edge_vertices[edge_list[e]] for e in F
                        if len(edge_vertices[edge_list[e]]) == 2]
            assert len(proper_F) == len(F)
            degree = Counter()
            for u, v in proper_F:
                degree[u] += 1
                degree[v] += 1
            # A singleton semiedge has load one in its own class and zero in
            # the other four classes, so it cannot lie in F.  Keep the guard
            # explicit because the common edge table also stores semiedges.
            comps = components(range(pole.n), proper_F)
            shape_key = (
                len(F),
                tuple(sorted(degree[v] for v in range(pole.n))),
                tuple(sorted(len(c) for c in comps)),
                hit,
            )
            shape[shape_key] += 1
            rows.append({"F_size": len(F), "blocker": hit})
        out["cells"][str(cell)] = {
            "missing": m,
            "witnesses": len(records),
            "blockers": blockers,
            "nonblockers": len(records) - blockers,
            "shape_counts": {str(k): v for k, v in sorted(shape.items(), key=str)},
        }
    return out


def main():
    interface = GATE.load_existing_interface()
    records = {
        "exact_s_c10": audit(interface.loop_interface.C10_EDGES),
        "all_st_no_a": audit(interface.loop_interface.ALL_SS_EDGES),
    }
    print(records)
    print("D5_SATURATION_BLOCKER_AUDIT_OK")


if __name__ == "__main__":
    main()
