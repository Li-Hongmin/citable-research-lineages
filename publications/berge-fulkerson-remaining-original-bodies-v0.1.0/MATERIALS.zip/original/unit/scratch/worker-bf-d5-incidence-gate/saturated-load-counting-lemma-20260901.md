# Saturated-load counting and the common zero-edge core

For a D5 six-matching witness, let `P_i` (i != m) be its four singleton
matchings and let `ell_e` be their proper-edge load. Set

```text
F={e: ell_e=2},   Z={e: ell_e=0}.
```

There are `m=(3n-5)/2` proper edges in an n-vertex cubic five-pole, and each
singleton matching uses `(n-1)/2` proper edges. Thus

```text
|E_1|+2|F|=2(n-1),
|Z|+|E_1|+|F|=(3n-5)/2,
```

so

```text
|F|=(n+1)/2+|Z|.
```

In particular every blocker has at least `(n+1)/2` edges. The local shape of
the four singleton loads gives a sharper interpretation: an internal vertex
has `d_F=2` exactly when its third proper edge has load zero, and otherwise
`d_F=1`. Terminals have the prescribed degrees

```text
d_F(v_m)=2,   d_F(v_i)=1 (i != m).
```

Consequently every edge of `Z` joins two internal `d_F=2` vertices, and the
edges of `Z` form a matching. The number of internal degree-two vertices is
`2|Z|`.

For the triple matchings `Q,Q'` in the witness, `Q,Q'` avoid `F`. The exact
double-cover equation gives the stronger edgewise statement on proper edges:

```text
ell_e=0  iff e is in both Q and Q',
ell_e=1  iff e is in exactly one of Q,Q',
ell_e=2  iff e is in neither Q nor Q'.
```

Thus, at each internal d_F=2 vertex their only non-F proper edge is the
unique zero-load edge, and in fact

```text
Z = (Q intersection Q') intersection E_proper.
```

Therefore the two terminal paths in `Q triangle Q'` avoid the common zero-edge
matching `Z`. This is a purely local counting/incidence lemma; it does not
imply a four-cell join. The missing step is to synchronize the five common
zero-edge matchings/carriers using the absence of T-loops and T--T types.
