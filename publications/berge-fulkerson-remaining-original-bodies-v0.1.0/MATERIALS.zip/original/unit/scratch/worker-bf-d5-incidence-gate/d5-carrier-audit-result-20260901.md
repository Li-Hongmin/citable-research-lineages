# Omen D5 blocker/carrier audit (2026-09-01)

## Scope

This is one fixed-instance probe of the matching-level D5 gate.  It uses the
frozen order-13 simple connected cubic five-pole with all 25 S--T cells and
no A-cover.  It does not scan poles, enlarge the order, or use an abstract
relation/load model.

The script enumerates every actual six-perfect-matching witness in the five
disjoint D5 cells.  For each witness it forms

\[
F=\{e:\text{the four singleton matchings use }e\text{ twice}\},
\]

then checks the omitted singleton class for a minimum-intersection matching
and checks whether its two symmetric differences with the triple matchings
have the required unique boundary carriers.

## Result

The pole has 37 perfect matchings and 113 D5 witnesses in total.  All 113
saturated sets are genuine blockers of the omitted singleton class.  Every
`F` is acyclic: it is a path forest with 3--5 components and size 8, 9, or
10 (counts 67, 33, 13).  A minimum-intersection omitted singleton uses two
`F`-edges in 102 witnesses and three in 11 witnesses.

For every witness, the minimum matching's proper `F`-edges lie in the unique
boundary path of both symmetric differences with the two triple matchings.
Thus the carrier inclusion from the analytic blocker lemma holds in all
113/113 cases.  Carrier-length pairs are

```text
(5,5): 9, (7,5): 8, (7,7): 55,
(7,9): 7, (9,3): 18, (9,5): 16.
```

The finite probe therefore supports, but does not prove, the general
blocker/carrier refinement.  It does not produce a D5 join, a T-loop/T--T
contradiction, or a real exact-40 Case-XII pole.  The arbitrary-blocker
implication remains unresolved.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-incidence-gate/audit_d5_carriers_20260901.py
```

The same command was run in the bounded Omen tmux session
`d5-carrier-20260901`; the remote log is

```text
[local archival reference]
```

The terminal marker is `D5_CARRIER_AUDIT_OK`.
