# Real common-incidence boundary for the D5 blocker/carrier arrow

## Decision

The blocker/carrier consequences (3)--(5) do **not** imply a D5 four-cell
join, even on one genuine simple connected cubic five-pole.  The fixed pole
below has no A-cover and all five D5 cells, but all five four-of-five D5
cylinder joins are empty while every actual D5 witness satisfies the literal
blocker and carrier conditions.  It has extra T-loop/T--T support, so this is
not a Case-XII counterexample.  It proves that the missing no-T-loop/no-T--T
hypothesis must enter through an additional cross-cell argument; it cannot be
silently inferred from (3)--(5).

## Fixed real pole

The proper edges (terminals are 0,...,4 with their semiedges) are

```text
(0,7),(0,11),(1,5),(1,7),(2,9),(2,10),(3,8),(3,11),
(4,8),(4,10),(5,6),(5,9),(6,7),(6,12),(8,9),(10,12),(11,12).
```

An independent complete perfect-matching enumeration gives 34 perfect
matchings, no `(12345)` A-cover, all 55 pair-type supports, and empty joins
for all five D5 four-cell families.

## Blocker/carrier audit

For every actual six-matching witness in each of the five D5 S--T cells (63
witnesses total), form the saturated proper-edge set

```text
F={e: the four singleton matchings use e twice}.
```

Every one of the 63 sets F meets every matching in the omitted singleton
class, and the minimum-intersection omitted matching has all of its F-edges
in the unique boundary path of both triple differences.  Thus the exact
conclusions

```text
F hits every omitted-class matching,
P∩F != empty,
P∩F subset L(P,Q) intersection L(P,Q')
```

hold for all witnesses, while the D5 joins remain empty.

The F sets are all acyclic path forests, with sizes 7,8,9 occurring 18,37,8
times.  Minimum intersections have sizes 1,2,3 occurring 58,3,2 times.
The audit also records zero carrier-inclusion failures and zero cycle
components.

## Omen reproduction

The targeted computation was run on Omen (single fixed pole; no census,
random search, or order expansion) and ended with

```text
FIRST_SYNTHESIS_BLOCKER_CARRIER_AUDIT_OK
```

Source verifier:

```text
units/berge-fulkerson/scratch/worker-bf-d5-incidence-gate/
audit_first_synthesis_blocker_carriers.py
```

The complete-matching/pole facts are independently frozen by
`worker-bf-real-synthesis/verify_first_model_independent.py`, whose marker is
`FIRST_SYNTHESIS_MODEL_INDEPENDENTLY_VERIFIED`.

## Exact logical boundary

The tested implication is therefore false:

```text
one common cubic PM family + no A + all D5 witnesses + (3)--(5)
  => a D5 join.
```

The remaining target is strictly narrower:

```text
exact 40-type Case XII support
  => a D5 join,
```

and the only unused input in this boundary is the absence of T-loops and
T--T types.  A successful proof must show that the carrier patterns from
different D5 cells force one of those forbidden types unless they
synchronize to a join.  The present pole does not test that final implication
because its complete support is all 55 pair types.
