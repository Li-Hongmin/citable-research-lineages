# D5 witness saturation is a singleton-class blocker

## Scope

Fix a disjoint D5 cell after the exact path-toggle transfer to the
corresponding disjoint (S)--(S) cell.  Let (m) be the omitted terminal
position and let

\[
 (P_i)_{i\ne m},\qquad P_i\in\mathcal P_i,
\]

be the four actual singleton perfect matchings in one six-matching witness.
Write

\[
 \ell(e)=\sum_{i\ne m}\chi_{P_i}(e),
 \qquad
 F=\{e:\ell(e)=2\}.
\]

The two triple matchings in the witness are nonnegative in the edge-load
equation, so (ell(e)\le2) for every edge.

## Blocker lemma

If some (P\in\mathcal P_m) avoids (F), then the five singleton matchings
\((P_i)_{i=1}^5) have edge load at most two.  At every internal cubic vertex
the five incidences sum to five, hence the three incident loads are
\((2,2,1)).  The load-one edges form a perfect matching, and together with
the five (P_i) give the forbidden (A=(12345)) cover.

Therefore, in any (A)-free pole with the relevant D5 witness,

\[
 \boxed{F\text{ meets every matching in }\mathcal P_m.}
\]

This is an actual perfect-matching statement: (F) is a blocker for one
singleton boundary class, not an aggregate-load surrogate.

## Forced local shape

At the omitted terminal (m), both proper incident edges lie in (F), because
every (P_i) with (i\ne m) uses both proper incidences there.  At each other
terminal exactly one proper incident edge lies in (F).  At an internal cubic
vertex the (F)-degree is one or two, corresponding respectively to local
four-matching load profiles ((2,1,1)) and ((2,2,0)).  Thus (F) is a
maximum-degree-two proper-edge subgraph with prescribed terminal contacts.

## Balanced two-edge subcase

Suppose (F=B=\{a,b\}) is a class-rigid balanced blocker: every singleton
matching in every class uses exactly one of (a,b), with the same choice for
all matchings in that class.  A D5 witness omitting (m) has four singleton
occurrences, so its four occurrences already contribute four incidences on
(B); both triple matchings avoid (B).  Consequently exactly two of the
four singleton classes in every D5 witness use (a) (and the other two use
(b)).

If this same class-rigid (B) were forced for every omitted coordinate
(m), there would be bits (c_i\in\{0,1\}) satisfying

\[
 \sum_{i\ne m}c_i=2\qquad(m=1,\ldots,5).
\]

Subtracting two equations gives (c_i=c_j) for all (i,j), after which
(4c_i=2), impossible.  Hence an (A)-free exact-40 candidate cannot have
one globally class-rigid balanced blocker governing all five D5 witnesses.

## Four-value status

The blocker lemma and the balanced-rigidity obstruction are proved.  They do
not yet show that an arbitrary blocker produces a (T)-loop/(T!-!T) type,
nor do they prove a common singleton tuple.  The remaining D5 arrow is:

\[
 \text{exact Case-XII support and no }A,T\text{-loop},T\!\text{-}T
 \Longrightarrow
 \text{some D5 witness has a non-blocking }F
 \text{ or a cross-cell blocker incompatibility}.
\]

No real exact-40 pole or general proof is obtained in this pulse.
