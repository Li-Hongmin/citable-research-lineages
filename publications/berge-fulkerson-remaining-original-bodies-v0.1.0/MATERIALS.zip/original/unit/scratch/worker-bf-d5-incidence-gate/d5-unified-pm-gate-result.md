# Unified PM gate for Case XII: pentagon versus D5 join

## Scope and decision

This pulse attacks one question only: can the complete exact Case-XII BF
support, together with the absence of T-loops and T--T types, force either a
singleton compatibility pentagon or a D5 four-cell join on one real cubic
5-pole?  No new graph census, route parity, aggregate-load model, or formal
vector model is used.

The answer remains **strictly unresolved**.  No analytic implication was
obtained, and no simple connected cubic 5-pole realizing all forty Case-XII
types while violating every D5 join was constructed.

The decisive branch distinction is:

* If the singleton Tait state set is exactly
  (S=\{13,14,24,25,35\}), a compatibility pentagon is a possible target,
  but ordinary exact-(S) incidence does not force it (the genuine order-13
  (C_{10}) pole is the known boundary).
* In the Tait-empty branch, no singleton compatibility pentagon can exist at
  all: every edge of such a pentagon would be a disjoint pair of singleton
  perfect matchings and hence a Tait state.  Therefore a proof covering the
  published Case-XII hypothesis uniformly cannot rely on pentagon selection;
  it must force a D5 join (or an equivalent capacity/A-cover mechanism).

This is a logical narrowing, not a Case-XII exclusion.

## Matching-level transfer and D5 target

Set

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and let

\[
 \mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For (d=(s,t)\in\mathcal D_5), a witness consists of actual perfect
matchings (Q_s,Q_t) in the two triple-boundary classes and one actual
singleton matching (P_i) for every (i\in s\cup t), satisfying

\[
 \chi_{Q_s}+\chi_{Q_t}+\sum_{i\in s\cup t}\chi_{P_i}=2\mathbf 1. 
\tag{1}
\]

The two triple matchings have two terminal-path components in their
symmetric difference.  Under the no-(A), no-T-loop and no-T--T support
assumptions, the endpoint pairing cannot be the A or T--T pairing.  Toggling
one path in both triple matchings therefore gives the corresponding
disjoint S--S cell, with the **same four singleton matchings**.  This is the
actual matching transfer of Note 047, not a boundary-label replacement.

Consequently the desired D5 assertion is

\[
 \exists d_0\in\mathcal D_5:
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing,                 	ag{2}
\]

where (Pi_d) is the five-coordinate cylinder of the four-singleton
witness relation.  A tuple in (2) has edge load at most two; the load-one
edges form the sixth matching and give the forbidden (A=(12345)) cover.

## Why the pentagon alternative is not uniform

For singleton classes (mathcal P_i), write

\[
 R_{ij}=\{(P_i,P_j):P_i\cap P_j=\varnothing\}.
\]

If (P_1,\ldots,P_5) form the complementary pentagon, then every proper
edge occurs in at most two of them, and the usual cubic local count produces
an (A)-cover.  Thus a pentagon is already forbidden in a Case-XII pole.

However, in the Tait-empty branch every (R_{ij}) is empty.  Indeed, one
edge of any (R_{ij}) is exactly a two-colour Tait state.  The published
Case-XII support does not assert that its side is 3-edge-colourable, so this
branch cannot be discarded.  In the exact-(S) branch, the known (C_{10})
matching-holonomy pole has all five S state relations but no lifted
pentagon; its extra BF support includes (A), so it is a boundary rather
than an exact Case-XII pole.  Hence neither “all S states” nor “no forbidden
BF types” has yet supplied a pentagon theorem.

## A sharp actual-PM sufficient condition for the unified gate

The remaining D5 target can be reduced to one genuine singleton fibre.  Fix
one four-cell family (J=\mathcal D_5\setminus\{d_0\}), an anchor
(a\in J), and an actual witness tuple (x\in\widehat\Pi_a).  Let (m) be
the unique terminal absent from the anchor scope.  For every other cell
(d\in J\setminus\{a\}), define

\[
 E_d(x)=\{P\in\mathcal P_m:
 \text{some witness in }\widehat\Pi_d\text{ agrees with }x
 \text{ on the common singleton slots and uses }P\text{ at }m\}.
 \tag{3}

Then, by direct coordinate restriction,

\[
 x\text{ extends to a tuple in }\bigcap_{d\in J}\Pi_d
 \iff \bigcap_{d\ne a}E_d(x)\ne\varnothing.               \tag{4}
\]

Define the actual exchange graph (X_m) on (mathcal P_m) by joining two
matchings when their symmetric difference is one proper alternating cycle.
Every same-boundary difference is a disjoint union of such cycles, so all
vertices are connected by genuine cycle flips.

The following is a sufficient, non-tautological matching condition:

> For some (J,a,x), (X_m) is a tree; each of the three sets (E_d(x))
> is a nonempty connected subtree; and these three subtrees intersect
> pairwise.

Finite subtrees of a tree obey Helly, so (4) gives the D5 join and hence the
forbidden (A)-cover.  This condition also applies in the Tait-empty branch,
where a singleton pentagon is unavailable.  It uses only actual PMs and
alternating-cycle exchanges of one common pole.

The exact Case-XII hypotheses currently provide neither pairwise fibre
intersection nor exchange-convexity/tree structure.  A change of the missing
singleton can be absorbed by simultaneous changes of the two triple
matchings, as witnessed by the genuine same-cell and cross-cell cycle/path
identities; no T-loop/T--T contradiction has been derived from those
identities.

## Four-value stop

* **Proof of the unified implication:** not obtained.
* **Real exact-40 counterexample:** not obtained.
* **承重附加条件:** the actual-PM tree-exchange Helly condition above; in the
  exact-(S) branch, a separately established compatible pentagon would also
  suffice, while it is impossible in the Tait-empty branch.
* **Status:** strict unresolved at the smallest common-incidence arrow:
  
  \[
  \text{no T-loop/T--T} \, + \, \text{all Case-XII cells}
  \Longrightarrow
  \text{pairwise D5 fibre overlap or convexity}. 
  \]

Any claimed S-level proof must handle the Tait-empty branch explicitly and
must use common cubic perfect-matching incidence beyond support labels or
aggregate edge equations.

