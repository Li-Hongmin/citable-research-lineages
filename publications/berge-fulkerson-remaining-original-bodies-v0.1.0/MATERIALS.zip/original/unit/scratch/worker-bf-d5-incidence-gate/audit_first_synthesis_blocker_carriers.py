#!/usr/bin/env python3
"""Targeted blocker/carrier audit on the frozen first joint-synthesis pole.

This is a single fixed real cubic five-pole (34 PMs, no A, all 55 pair
support); it is not a census.  We reuse the blocker/carrier routines and
replace only the edge list, to test whether (3)--(5) by themselves force a
D5 join even when the negative T-loop/TT hypotheses are not imposed.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PATH = HERE / "audit_d5_carriers_20260901.py"
spec = importlib.util.spec_from_file_location("carrier", PATH)
assert spec is not None and spec.loader is not None
carrier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(carrier)

EDGES = (
    (0, 7), (0, 11), (1, 5), (1, 7), (2, 9), (2, 10), (3, 8),
    (3, 11), (4, 8), (4, 10), (5, 6), (5, 9), (6, 7), (6, 12),
    (8, 9), (10, 12), (11, 12),
)

def main():
    result = carrier.audit(EDGES)
    # The targeted pole is independently known to have no A and all 55
    # pair-type support; assert only the local audit facts here.
    assert result["all_blockers"]
    assert result["all_carrier_inclusions"]
    print(json.dumps(result, indent=2, sort_keys=True))
    print("FIRST_SYNTHESIS_BLOCKER_CARRIER_AUDIT_OK")

if __name__ == "__main__":
    main()
