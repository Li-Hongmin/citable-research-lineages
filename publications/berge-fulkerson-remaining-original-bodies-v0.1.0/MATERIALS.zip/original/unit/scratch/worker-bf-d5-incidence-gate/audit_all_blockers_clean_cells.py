#!/usr/bin/env python3
"""Enumerate every D5 saturation blocker on the frozen order-13 poles.

This is a deliberately small decision probe.  For each actual six-matching
witness in a disjoint D5 cell, form the saturated proper-edge set

    F = {e : four singleton matchings use e twice}.

The blocker lemma says that, in an A-free pole, F must meet every matching in
the omitted singleton class.  We then classify the distinct F's and test a
candidate consequence: does each blocker coincide with a T-clean obstruction,
meaning that at least one of the 25 positive S--T cells has no witness whose
T endpoint avoids a T-loop partition?  The pole is not required to satisfy
exact Case-XII support; this script only measures the common-incidence
mechanism on the two frozen boundary examples.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations_with_replacement, product
from pathlib import Path
import importlib.util
import json
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
KEMPE = ROOT / "units/berge-fulkerson/scratch/worker-kempe"
FROZEN_PATH = KEMPE / "verify_cubic_all_ss_realization.py"
JOINT_PATH = KEMPE / "exact_st_joint_audit.py"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


JOINT = load("all_blockers_joint", JOINT_PATH)
FROZEN = load("all_blockers_frozen", FROZEN_PATH)

S = JOINT.S
T = JOINT.T
ALL_ST = tuple(sorted(tuple(sorted((s, t))) for s in S for t in T))
D5 = tuple(sorted(
    kind for kind in ALL_ST
    if set(kind[0]).isdisjoint(kind[1])
))


def all_witnesses(kind, data):
    """Return (q0,q1,slots,singletons) for every exact six-PM witness."""
    edges, _, _, _, classes, _ = data
    first, second = kind
    first_family = classes[JOINT.complement(first)]
    second_family = classes[JOINT.complement(second)]
    if first == second:
        triples = combinations_with_replacement(first_family, 2)
    else:
        triples = product(first_family, second_family)
    slots = tuple(first + second)
    out = []
    for q0, q1 in triples:
        base_load = [0] * len(edges)
        for matching in (q0, q1):
            for edge in matching:
                base_load[edge] += 1
        if any(value > 2 for value in base_load):
            continue
        for singleton_tuple in product(*(classes[(i,)] for i in slots)):
            load = base_load[:]
            for matching in singleton_tuple:
                for edge in matching:
                    load[edge] += 1
            if all(value == 2 for value in load):
                out.append((q0, q1, slots, singleton_tuple))
    return tuple(out)


def t_clean(record, t, data):
    """Whether the T-end of a witness avoids a T-loop partition."""
    q0, q1, slots, singleton_tuple = record
    edges, _, _, _, classes, _ = data
    boundary_of = {
        matching: key
        for key, family in classes.items()
        for matching in family
    }
    target_class = JOINT.complement(t)
    q_candidates = [q for q in (q0, q1) if boundary_of[q] == target_class]
    by_slot = {
        position: matching
        for position, matching in zip(slots, singleton_tuple)
    }
    all_edges = set(range(len(edges)))
    for q in q_candidates:
        p_i, p_j = by_slot[t[0]], by_slot[t[1]]
        q_set, pi_set, pj_set = set(q), set(p_i), set(p_j)
        if (
            q_set.isdisjoint(pi_set)
            and q_set.isdisjoint(pj_set)
            and pi_set.isdisjoint(pj_set)
            and q_set | pi_set | pj_set == all_edges
        ):
            return False
    return True


def components(F, edge_list, edge_vertices):
    graph = defaultdict(set)
    for edge in F:
        endpoints = edge_vertices[edge_list[edge]]
        assert len(endpoints) == 2
        u, v = endpoints
        graph[u].add(v)
        graph[v].add(u)
    seen = set()
    sizes = []
    cycles = 0
    for vertex in graph:
        if vertex in seen:
            continue
        stack = [vertex]
        seen.add(vertex)
        vertices = []
        edge_count = 0
        while stack:
            u = stack.pop()
            vertices.append(u)
            edge_count += len(graph[u])
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        edge_count //= 2
        sizes.append(len(vertices))
        if edge_count == len(vertices):
            cycles += 1
    return tuple(sorted(sizes)), cycles


def audit(name, edges):
    pole = FROZEN.joint.base.legacy.Pole(n=13, proper_edges=edges)
    data = JOINT.matching_data(pole)
    edge_list, edge_vertices, _, _, classes, pm_count = data
    witnesses_by_cell = {kind: all_witnesses(kind, data) for kind in ALL_ST}
    clean_counts = {
        kind: sum(
            t_clean(record, next(pair for pair in kind if pair in T), data)
            for record in witnesses_by_cell[kind]
        )
        for kind in ALL_ST
    }
    blockers = defaultdict(lambda: {"witnesses": 0, "cells": set(), "missing": set()})
    blocker_rows = []
    for cell in D5:
        missing = tuple(set(range(1, 6)) - set(cell[0]) - set(cell[1]))
        assert len(missing) == 1
        m = missing[0]
        for record in witnesses_by_cell[cell]:
            _, _, slots, singleton_tuple = record
            load = [0] * len(edge_list)
            for matching in singleton_tuple:
                for edge in matching:
                    load[edge] += 1
            F = frozenset(edge for edge, value in enumerate(load) if value == 2)
            assert all(len(edge_vertices[edge_list[e]]) == 2 for e in F)
            blocker = all(F & set(matching) for matching in classes[(m,)])
            key = tuple(sorted(F))
            row = blockers[key]
            row["witnesses"] += 1
            row["cells"].add(cell)
            row["missing"].add(m)
            blocker_rows.append((key, cell, blocker))

    distinct = []
    for key, row in sorted(blockers.items()):
        F = frozenset(key)
        zero_clean = tuple(sorted(
            str(kind) for kind, count in clean_counts.items() if count == 0
        ))
        degrees = Counter()
        for edge in F:
            u, v = edge_vertices[edge_list[edge]]
            degrees[u] += 1
            degrees[v] += 1
        comp_sizes, cycle_count = components(F, edge_list, edge_vertices)
        distinct.append({
            "F": list(key),
            "edge_names": [edge_list[e] for e in key],
            "witnesses": row["witnesses"],
            "cells": [str(cell) for cell in sorted(row["cells"])],
            "omitted_positions": sorted(row["missing"]),
            "is_blocker_all_recorded_omitted_classes": all(
                hit for candidate, _, hit in blocker_rows if candidate == key
            ),
            "F_size": len(F),
            "degree_multiset": sorted(degrees.values()),
            "component_vertex_sizes": list(comp_sizes),
            "cycle_components": cycle_count,
            "zero_clean_ST_cells": list(zero_clean),
        })

    return {
        "perfect_matchings": pm_count,
        "D5_witness_counts": {str(cell): len(witnesses_by_cell[cell]) for cell in D5},
        "ST_clean_witness_counts": {str(kind): clean_counts[kind] for kind in ALL_ST},
        "distinct_blocker_sets": distinct,
        "blocker_count": len(distinct),
        "all_blocker_records_hit_omitted_class": all(hit for _, _, hit in blocker_rows),
        "candidate_every_blocker_has_zero_clean_cell": all(
            row["zero_clean_ST_cells"] for row in distinct
        ),
    }


def main():
    records = {
        "all_st_no_a": audit("all_st_no_a", FROZEN.PROPER_EDGES),
    }
    print(json.dumps(records, indent=2, sort_keys=True))
    print("D5_ALL_BLOCKERS_CLEAN_CELL_AUDIT_OK")


if __name__ == "__main__":
    main()
