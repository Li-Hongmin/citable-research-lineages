# All D5 saturation blockers on the frozen all-ℙ pole

This is a fixed-instance probe of the remaining D5 incidence interface.  It
enumerates every actual six-matching witness in the order-13 pole with all
25 (S\)--(T) cells and no (A)-cover, then deduplicates the saturated
proper-edge sets

\[
F=\{e:\text{the four singleton matchings in the witness use }e\text{ twice}\}.
\]

## Result

The pole has 37 perfect matchings and D5 witness counts

\[
(25,32,22,16,18)
\]

in the order
\((12)(35),(13)(45),(14)(23),(15)(24),(25)(34)\).  There are 9 distinct
saturation sets (F), all of which meet every matching in the omitted
singleton class, as required by the blocker lemma.  Their sizes are

\[
8,8,8,8,8,9,9,9,10,
\]

and every one is acyclic (all components are paths).  Thus this pole gives a
real common-incidence boundary in which the blockers are larger than the
balanced two-edge blockers; it does not yield a general blocker
classification.

For every one of the 25 positive (S\)--(T) cells there is at least one
T-clean witness in this pole.  Consequently the tested implication

\[
\text{every D5 blocker}\Longrightarrow\text{some positive cell has no
T-clean witness}
\]

is **false even on this fixed pole**.  This does not contradict the exact-40
question: the pole has additional (T)-loops and (T\)--(T) types.  It only
closes the proposed shortcut from a blocker to a cell-wise clean-witness
failure.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-incidence-gate/audit_all_blockers_clean_cells.py
```

The same script was run on `omen` in tmux (`d5-all-blockers-20260901`) and
ended with `D5_ALL_BLOCKERS_CLEAN_CELL_AUDIT_OK`.
