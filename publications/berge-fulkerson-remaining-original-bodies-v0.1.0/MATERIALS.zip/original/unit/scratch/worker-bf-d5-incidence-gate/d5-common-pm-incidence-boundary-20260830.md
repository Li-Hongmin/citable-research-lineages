# D5 common-PM incidence gate: exact pivot boundary

## Question

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and let

\[
 \mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For a real simple connected cubic five-pole `H`, write
\(\widehat\Pi_d\) for the set of four-tuples of *actual* singleton-boundary
perfect matchings occurring in a six-matching witness for the cell
\(d=(s,t)\).  The missing singleton coordinate is filled arbitrarily to
obtain the five-coordinate cylinder \(\Pi_d\).

The pulse asks whether complete Case-XII support (all 25 `S--T` cells, all
15 `S--S` cells and the five `S` loops, with no `A`, `T` loop or `T--T`
type) forces

\[
 \exists d_0\in\mathcal D_5:
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing. \tag{G}
\]

This is an incidence question on one common cubic pole, not a support flag
or an aggregate edge-load question.

## Exact transfer to the five disjoint S--S cells

For every `d` in `\mathcal D_5`, the symmetric difference of the two
triple-boundary matchings in a witness has two terminal paths, with possible
proper alternating cycles.  Toggling either terminal path in both triple
matchings preserves the four singleton matchings.  The endpoint calculation
gives

\[
\begin{array}{c|ccc}
\text{pair of missing pairs}&\text{pairing 1}&\text{pairing 2}&\text{pairing 3}\\
\hline
 S\text{--}T\text{ disjoint}&A,A&S\text{--}S,S\text{--}S&T\text{--}T,T\text{--}T\\
 S\text{--}S\text{ disjoint}&A,A&S\text{--}T,S\text{--}T&T\text{--}T,T\text{--}T.
\end{array}
\]

Under the negative Case-XII support assumptions, the forbidden columns cannot
occur.  Consequently the actual singleton relations are equal, cell by
cell, under

\[
\begin{array}{c|c}
 (13,45)&(14,35)\\
 (14,23)&(13,24)\\
 (24,15)&(14,25)\\
 (25,34)&(24,35)\\
 (35,12)&(13,25).
\end{array} \tag{1}
\]

Thus (G) is equivalent to a four-of-five join of the five disjoint `S--S`
relations.  This uses only symmetric differences of actual perfect
matchings; no abstract relation or parity replacement is made.

## Exact one-anchor pivot reduction

Fix one four-cell family
\(J=\mathcal D_5\setminus\{d_0\}\), an anchor cell \(a\in J\), and
an actual tuple \(x\in\widehat\Pi_a\).  For each other cell
\(d\in J\setminus\{a\}\), let

\[
 E_d(x)=\{P\in\mathcal P_{m(a)}:
   \text{some }y\in\widehat\Pi_d\text{ agrees with }x
   \text{ on }U_a\cap U_d,\;y_{m(a)}=P\}, \tag{2}
\]

where \(U_d\) is the four-element singleton support of `d` and
\(m(a)=[5]\setminus U_a\).  The missing coordinate of the anchor is exactly
the coordinate present in every other cell.  Therefore the matching-level
equivalence is

\[
 x\text{ extends to a tuple in }\bigcap_{d\in J}\Pi_d
 \quad\Longleftrightarrow\quad
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing. \tag{3}
\]

This is an exact reduction, not a relaxation.  If the three fibres in (2)
are singletons, then (3) is equivalent to the equality graph of their three
unique matching values being connected, i.e. to at least two agreement edges.
Call this the **UE2 condition**.

The UE2 condition is a genuinely thin sufficient condition: it fixes one
anchor and two actual singleton-matching equalities, rather than one common
matching in every triple class or a rectangular witness for all 25 cells.

## Why a join gives A

For any tuple in a four-cell join, every proper edge belongs to at most two
of the five singleton matchings.  Indeed, the four chosen endpoint unions
cover every three-subset of `[5]`; if an edge occurred in three singleton
matchings with positions `i,j,r`, choose a cell whose union contains
`{i,j,r}`.  Its two triple matchings could not reduce the singleton load.

At an internal cubic vertex the five singleton incidences have total load
five.  With three edge loads each at most two, the local profile is
`(2,2,1)`.  The load-one edges therefore form a perfect matching `P_0`, and
`P_0,P_1,\ldots,P_5` is the forbidden all-boundary `(12345)` cover.

## Blossom/alternating-cycle obstruction

The cubic matching axioms do not identify the three sets in (2).  If two
witnesses for the same cell agree in the other three singleton slots, then
subtracting their six-matching equations gives

\[
 (\chi_{Q'_s}-\chi_{Q_s})+
 (\chi_{Q'_t}-\chi_{Q_t})+
 (\chi_{P'}-\chi_P)=0. \tag{4}
\]

Every term is a signed union of proper alternating cycles.  Hence a change
of the missing singleton matching can be absorbed by simultaneous changes of
the two triple matchings.  This is the precise local mechanism preventing a
formal Helly argument.  It is realized by actual cubic poles, so the words
“same pole” and “alternating-cycle closure” alone do not rule it out.

## Frozen real boundary

The deterministic audit

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/audit_d5_pivot_extension_boundary.py
```

uses the complete perfect-matching families of two fixed order-13 poles.  It
reports

* exact-`S` C10 pole: 31 perfect matchings, D5 cylinder sizes
  `(12,6,8,8,6)`, and no anchor that extends separately to all three other
  cells;
* connected all-`S--T`, no-`A` pole: 37 perfect matchings, cylinder sizes
  `(96,110,96,72,125)`, 16 anchor stars extending separately to all three
  cells, all 16 with singleton extension fibres, with equality-edge counts
  `9` cases at zero and `7` at one, and none at two or more.

The second pole is a real common-cubic-incidence boundary, but its complete
closure also contains all five `T` loops and all ten `T--T` types.  It is not
a Case-XII pole.  It shows that actual perfect-matchings, full closure and
connected exchange do not by themselves force UE2.

## Decision

No proof of (G) and no real pole with exact forty-type Case-XII support were
obtained.  The proposition is therefore **strictly unresolved** at the
permitted incidence/blossom interface.  The sharpest non-tautological local
condition isolated here is UE2; once it holds, (3) gives the D5 join and the
load-one construction gives `A`.

Any further positive step must use the absence of `T` loops and `T--T` types
to forbid the concrete cycle absorption (4) across the three pivot fibres.
Any negative step must realize the complete forty-type support in one actual
bridge-free, girth-five pole (which would be a genuine Berge--Fulkerson
counterexample after gluing the `C_5` side).  Neither is supplied here.

