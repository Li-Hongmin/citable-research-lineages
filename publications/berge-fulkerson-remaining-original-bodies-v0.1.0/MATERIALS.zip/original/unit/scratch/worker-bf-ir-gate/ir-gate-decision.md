# The Case-XII D5 intersection gate remains open

## Scope and decision

This pulse attacks only the following real-pole implication.  Let (H) be a
simple connected cubic 5-pole with distinct terminals, girth at least five,
and the Case-XII support

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

namely the five S-loops, all fifteen S--S types, and all
twenty-five S--T types, with no A=(12345), T-loop, or
T--T type.  For the five disjoint S--T cells

\[
 \mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\},
\]

let \(\widehat\Pi_d\) be the relation of four-tuples of actual singleton
perfect matchings that complete some actual pair of triple matchings in cell
\(d\).  The desired gate is

\[
 \exists d_0\in\mathcal D_5:\quad
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing,                 \tag{G}
\]

where \(\Pi_d\) is the five-coordinate cylinder obtained from
\(\widehat\Pi_d\) by leaving the unique missing terminal arbitrary.

No proof of (G) and no real pole satisfying the complete forty-type support
with (G) false were obtained.  The exact unresolved implication is therefore
still at the common singleton-fibre join; the present result is a strict
reduction to the disjoint (S\)-(S\) pentagon below.

## A real matching-level transfer

For every \(d=(s,t)\in\mathcal D_5\), the two triple matching boundaries are
the complements of \(s\) and \(t\).  Their symmetric difference has two
terminal paths with endpoints \(s\cup t\), together with possible proper
even cycles.  Toggling either terminal path in both triple matchings leaves
the sum of their edge-incidence vectors unchanged, hence leaves the same
four singleton matchings as a valid double-cover completion.

The endpoint pairing table is exhaustive:

\[
\begin{array}{c|ccc}
\text{original triple classes}&\text{pairing 1}&\text{pairing 2}&\text{pairing 3}\\ \hline
S\text{-}T\text{ disjoint}&(A,A)&(S\text{-}S,S\text{-}S)&(T\text{-}T,T\text{-}T)\\
S\text{-}S\text{ disjoint}&(A,A)&(S\text{-}T,S\text{-}T)&(T\text{-}T,T\text{-}T).
\end{array}
\]

Under the Case-XII negative support, the (A) and (T\)-(T) alternatives
cannot occur.  Thus a witness in a disjoint (S\)-(T) cell has the unique
remaining pairing and toggles to a witness in the corresponding disjoint
(S\)-(S) cell, with precisely the same singleton tuple.  The converse
toggle is identical.  Therefore, as actual relations (not type flags),

\[
\begin{array}{c|c}
d\in\mathcal D_5&\phi(d)\text{ (disjoint }S\text{-}S\text{ cell})\\ \hline
(13,45)&(14,35)\\
(14,23)&(13,24)\\
(24,15)&(14,25)\\
(25,34)&(24,35)\\
(35,12)&(13,25)
\end{array}
\qquad
\widehat\Pi_d=\widehat\Sigma_{\phi(d)}.                 \tag{1}
\]

The five relations on the right are the five edges of the disjointness
pentagon on (S).  Equation (1) is the only new implication available from
the forbidden (A/T\!T) types; it does not identify witnesses in different
cells.

## The load implication once a four-way join exists

Any four members of \(\mathcal D_5\) have endpoint unions containing every
three-subset of \([5]\).  If (G) holds, and (e) belonged to three chosen
singleton matchings, one of the four six-matching equations would have
singleton load at least three on (e), impossible.  Hence every proper edge
has singleton load at most two.  At each internal cubic vertex the five
singleton matchings contribute total load five over three incident edges, so
the loads are \((2,2,1)\).  The load-one edges form a sixth perfect matching;
all five semiedges have load one, so this is an (A=(12345)) cover.  Thus

\[
 (G)\Longrightarrow A,
\]

and a Case-XII pole must fail (G) for all five omitted cells.

## A strict sufficient incidence condition

For a selected four-cell set \(J=\mathcal D_5\setminus\{d_0\}\), define

\[
 \mathcal W_i(J)=
 \bigcup_{d\in J,\ i\in s(d)\cup t(d)}
 \pi_i(\widehat\Pi_d),
\]

where \(\pi_i\) records the actual singleton matching at terminal (i).
The following *D5 coordinate-rigidity* condition is sufficient:

\[
 |\mathcal W_i(J)|=1\quad\text{for every }i\in[5].      \tag{CR}
\]

Indeed, choose any witness tuple from each nonempty \(\widehat\Pi_d\),
(d\in J).  Condition (CR) forces all tuples to use the same matching
(P_i) whenever coordinate (i) occurs.  Their union is therefore a
well-defined five-tuple in every cylinder \(\Pi_d), proving (G) and hence
the forbidden (A)-cover.  No fixed triple matching is required.

A graph-level, easier-to-state sufficient hypothesis is the special case
that, for each (i), the union of singleton matchings appearing in all five
disjoint-cell witnesses is a singleton.  This is strictly stronger than
cellwise support and isolates exactly the missing witness-reuse assertion.

## What remains unproved

Case-XII support supplies only

\[
 \widehat\Pi_d\ne\varnothing\quad(d\in\mathcal D_5),
\]

and (1) transfers this nonemptiness to five disjoint (S\)-(S) relations.
Neither statement implies (CR), a three-coordinate projection rigidity
condition, or the four-way natural join.  Girth, bridge-freeness, and the
classified terminal-tree cuts constrain the host pole but provide no
quantifier exchange between two different six-matching witnesses.  The
existing abstract relation countermodel is not used as a pole result, and no
new-order census or random search is part of this decision.

Consequently the pulse stops at the precise statement

\[
\boxed{\text{real common cubic incidence}+\text{exact forty-type support}
\ \Longrightarrow\ ?\ \text{D5 four-way join}.}
\]

The gate remains **undecided**.  The smallest next theorem would be a genuine
singleton-fibre rigidity/Helly result for the five disjoint (S\)-(S\)
relations (or a real pole satisfying all forty support types and violating
all five joins).  The transfer verifier is
`units/berge-fulkerson/scratch/worker-bf-d5-join-proof/verify_d5_ss_transfer.py`
and ends with `D5_SS_TRANSFER_TABLE_VERIFIED`.
