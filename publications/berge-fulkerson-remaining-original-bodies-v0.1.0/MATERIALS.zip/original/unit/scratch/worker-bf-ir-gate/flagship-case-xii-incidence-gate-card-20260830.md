# BF flagship gate: real Case-XII witness reuse

**Date:** 2026-08-30  
**Status:** frozen decision card; the implication is open.

## Target proposition

Let (H) be the five-pole on the non-(C_5) side of a genuine
cycle-separating 5-cut in a minimum Berge--Fulkerson counterexample.  Put

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\},
\]

and let (L_{\mathrm{XII}}) be the exact forty-type Case-XII support:
five (S)-loops, all fifteen (S\)--(S) pair types, and all twenty-five
(S\)--(T) types, with no (A=(12345)), no (T)-loop, and no (T\)--(T)
type.

For (d=(s,t)) in

\[
D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\},
\]

let \(\widehat\Pi_d\) be the set of four-tuples of **actual singleton
perfect matchings** occurring in a six-matching witness for (d).  Let
\(\Pi_d\) be its five-coordinate cylinder, with the missing singleton
coordinate left free.

The flagship gate is

\[
\boxed{
L_{\mathrm{XII}}\text{ on one real cubic pole}
\Longrightarrow
\exists J\subseteq D_5, |J|=4,
\bigcap_{d\in J}\Pi_d\ne\varnothing .
}
\tag{G-XII}
\]

The statement includes both the Tait-empty and exact-(S) branches.  It is
not allowed to assume that (H) is Tait-colourable.

## Already proved consequence

For every (d\in D_5), the forbidden (A), (T)-loop and (T\)--(T)
columns force the actual path-toggle transfer to the corresponding
disjoint (S\)--(S) cell.  Thus the five (D_5) relations may be taken
from either side of the transfer without changing their four singleton
matchings.

If the four-cylinder intersection in (G-XII) exists, every proper edge is
used by at most two of the five singleton matchings.  At each cubic vertex
the singleton loads therefore are ((2,2,1)); the load-one edges form a
sixth perfect matching, and the six matchings give the forbidden
\(A=(12345)\) cover.  Hence (G-XII) contradicts exact Case XII.

## Exact remaining arrow

The unproved step is only the witness-reuse implication

\[
\widehat\Pi_d\ne\varnothing\quad(d\in D_5)
\Longrightarrow
\exists J,\ |J|=4,\ \bigcap_{d\in J}\Pi_d\ne\varnothing .
\tag{W}
\]

For an anchor tuple (x\in\widehat\Pi_a), (W) is equivalent to the
intersection of three actual extension fibres in one singleton class:

\[
\bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing .
\]

The tree-exchange Helly condition (the relevant singleton exchange graph is
a tree and the three fibres are pairwise-intersecting connected subtrees)
is a sufficient additional hypothesis, not a consequence currently known
from (L_{\mathrm{XII}}).

## Evidence boundaries

The following do **not** prove (G-XII):

* nonempty support of each cell;
* class-quotient or active-(W(H)) connectivity;
* integer edge-load identities or parity;
* abstract common-vector models;
* the exact-(S) pentagon alone, since the Tait-empty branch has no such
  pentagon.

Known real poles with extra (T)-loops or (T\)--(T) types are boundaries,
not counterexamples to (G-XII).  A valid negative result must realize the
complete forty-type support on one real pole and fail every four-cell join.

## Four-valued stopping rule

Each proof pulse must stop at the first of:

1. a proof of (G-XII);
2. a real exact-forty-type pole violating (G-XII);
3. a rigorously load-bearing additional condition;
4. a strict unresolved result showing the next missing incidence statement.

No higher-order census, route-label audit, aggregate load model, or literature
branch is part of this gate.
