# Reverse construction at the exact-40 Case-XII gate

## Target

The construction target is one real simple connected bridgeless cubic
5-pole \(H\) whose complete actual BF support is exactly the Case-XII set

\[
 \{[s]:s\in S\}\ \cup\ \binom{S}{2}\ \cup\ (S\times T),
\]

where

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

In particular, \(H\) must have no \(A=(12345)\), no \(T\)-loop and no
\(T\)--\(T\) type.  The desired negative instance would additionally have
all five D5 four-cell cylinder joins empty, where

\[
 \mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

Only actual perfect-matchings of one pole count as a construction.  Formal
relation or edge-load models are not used.

## Fixed real near-miss

The existing order-13 all-\(S\)--\(T\) pole is a genuine common-incidence
boundary:

* 37 perfect matchings;
* all 25 \(S\)--\(T\) cells are realized;
* no independent \(A\)-cover;
* all five tested D5 joins are empty (the standard four-cell projections
  have sizes \(25,96,96,72\) and empty intersection).

Its complete closure nevertheless has all five \(T\)-loops and all ten
\(T\)--\(T\) types, and its Tait state set is \(K_5\), not \(S\).  Therefore
it is not an exact-40 Case-XII pole and is not a counterexample to the
target proposition.  The frozen verifiers are:

    python3 units/berge-fulkerson/scratch/worker-kempe/verify_cubic_all_ss_realization.py
    python3 units/berge-fulkerson/scratch/worker-real-exact-s-no-a/four_cell_common_singleton_interface.py

They end with CUBIC_ALL_SS_REALIZATION_VERIFIED and
FOUR_CELL_COMMON_SINGLETON_INTERFACE_OK.

This near-miss isolates the construction bottleneck: removing the extra
\(T\)-loop/\(T\)--\(T\) support while preserving all \(S\)--\(T\) witnesses,
the absence of \(A\), and the empty D5 joins.  Independent Taitable
two-pole edge replacements cannot perform this filtering, since every parent
BF cover lifts through such replacements and the parent boundary support is
retained.

## Actual-incidence obstruction

For one D5 cell \(d=(s,t)\), an actual witness is

\[
 \chi_{Q_s}+\chi_{Q_t}+
 \sum_{i\in s\cup t}\chi_{P_i}=2\mathbf 1.
\]

Exact support says only that at least one such witness exists for each
positive cell.  Empty joins require that no four cells reuse a common
five-tuple \((P_1,\ldots,P_5)\).  Thus a candidate pole must realize all
forty boundary types while making the singleton fibres fail this reuse
condition.  The existing near-miss shows that common cubic vertex
incidence, genuine alternating-cycle exchanges, and complete PM closure
alone do not prevent this failure; its extra \(T\)-types are the only
missing exact-support restriction.

The thinnest load-bearing additional condition is a **loop-to-\(W\) common
incidence section**.  In the pentagon order

\[
 (v_0,v_1,v_2,v_3,v_4)=(1,4,2,5,3),
\]

let \(P_{v_k}\) be singleton matchings such that every adjacent pair belongs
to the actual relation induced by the \(S\)-loop BF witnesses.  Then each
proper edge occurs in at most two of the five \(P_i\), so the load-one edges
form a sixth perfect matching and give \(A=(12345)\).  Hence any exact-40
pole with no \(A\) must fail this common section.  Coordinate-rigidity,
3ER, UE2, or tree-exchange Helly are stronger sufficient ways to force the
same section or a D5 join.

## Four-value decision

* Exact-40 real pole with all five D5 joins empty: **not constructed**.
* Proof that such a pole cannot exist: **not obtained**.
* Strict actual-PM obstruction/condition: **obtained** — filtering the
  extra \(T\)-loop/\(T\)--\(T\) types while defeating the loop-to-\(W\)
  common section is the minimal remaining interface.
* Overall status: **precisely unresolved** at real singleton-fibre
  transport.

No higher-order census, abstract countermodel, or route-parity argument is
part of this decision.

**REVERSE_EXACT_40_POLE_CONSTRUCTION_BOUNDARY_UNRESOLVED**
