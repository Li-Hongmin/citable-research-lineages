# One-2-switch boundary for the exact-40 D5 construction

**Date:** 2026-09-01  
**Scope:** bounded constructive probe only; no graph census and no claim in
arbitrary order.

## Question

Can a real simple connected cubic 5-pole with exact Case-XII support be
obtained by a single proper-edge 2-switch from one of the two frozen
order-13 poles?

The target is the complete 40-type Case-XII support (five (S)-loops, ten
off-diagonal (S)--(S) types, and all twenty-five (S)--(T) types), with
no (A=(12345)) cover.  For every target candidate we would then test the
five D5 four-cell joins.

## Construction neighbourhood

The two seeds are:

* the order-13 exact-(S) C10 pole (`C10_EDGES`), and
* the order-13 all-(S)--(T), no-(A) pole (`ALL_SS_EDGES`).

For each seed, choose two distinct proper edges and replace
((a,b),(c,d)) by one of ((a,c),(b,d)) or ((a,d),(b,c)).  Duplicate edge
sets are removed.  The resulting pole is retained only if it is simple,
connected, cubic after the five fixed semiedges, and has no proper-edge
bridge.

## Exact result

All computations use the complete actual perfect-matching incidence routine
(`exact_st_joint_audit.pole_record`), not a boundary-only or load-only model.
The support is canonicalised under all (5!) terminal relabellings before
comparison with the Case-XII target.

| quantity | value |
|---|---:|
| unique 2-switches generated (both seeds) | 486 |
| simple connected proper-bridgeless candidates | 320 |
| exact-40 candidates with no (A) | 0 |

The run therefore stops before D5 projection computation: there is no
candidate in this neighbourhood on which a D5 counterexample could be
tested.  A near-target ranking gives minimum symmetric-difference distance
14 from the target (support size 54) among the no-(A) candidates; this is a
diagnostic only, not a relaxation of the exact target.

This is a strict local construction boundary.  It neither proves that a real
exact-40 pole cannot exist nor constructs a Case-XII counterexample.  In
particular, a two-switch composition, a non-edge-switch operation, and
higher-order poles remain outside the scope.

## Reproduction

From the project root, the source script is:

```text
python3 units/berge-fulkerson/scratch/worker-bf-ir-gate/probe_local_2switch_exact40_d5.py
```

For the bounded run, the script and its dependencies were copied to Omen and
executed in a tmux session.  The authoritative remote log is:

```text
[local archival reference]
```

Its final lines are:

```text
{'two_switches_tested': 486, 'valid_simple_connected_bridgeless': 320,
 'exact40_no_A': 0, 'records': []}
NO_EXACT40_POLE_IN_LOCAL_2SWITCH_NEIGHBOURHOOD
```

The first run independently gave the same three counts.  No permanent note
is modified by this boundary result.
