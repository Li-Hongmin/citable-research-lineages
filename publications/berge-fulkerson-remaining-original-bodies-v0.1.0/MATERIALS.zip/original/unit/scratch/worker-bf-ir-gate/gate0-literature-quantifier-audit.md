# Gate 0 literature and quantifier audit

Audit date: 2026-08-29.  Scope: only the implication from a minimum
Berge--Fulkerson counterexample to the exact Case-XII boundary support.  No
new graph enumeration or retrieval behind access controls was used.

## Source records

The admitted local records are:

* `[local archival reference]`
  (Máčajová--Mazzuoccolo, Proc. AMS 148 (2020), DOI
  `10.1090/proc/15057`).
* `[local archival reference]`
  (Máčajová--Mazzuoccolo--Tabarelli, Ars Math. Contemp. 26 (2026), DOI
  `10.26493/1855-3974.3409.c13`).

The bibliographic/cache records are
`units/berge-fulkerson/scratch/worker-verify/case_xii_literature_records.json`.

## What the primary sources actually imply

The 2020 paper defines BF-colouring of a cubic multipole and identifies it
with six perfect matchings with edge-load two (Definition 2.1, pp. 4644--45).
Theorem 1.2 (p. 4643) states that a minimum counterexample is a cyclically
5-edge-connected snark.  This does **not** assert cyclic connectivity exactly
5; a cyclically 6-edge-connected branch remains possible.

The 2026 paper defines the 56 ordered 5-pole BF boundary types (Definition
4.1, pp. 9--10).  Its Section 4.3, pp. 13--17, considers a minimum
cyclically 5-edge-connected counterexample with a cycle-separating 5-cut and
computes the 13 possible disjoint pairs of exact admissible BF-type graphs.
Proposition 4.4 (p. 17) says that, up to exchanging sides, both 5-poles have
exactly the BF types displayed in one of Cases I--XIII; in Cases I--XII the
other side is a 5-cycle.

The Appendix, pp. 19--21, gives the decisive Case-XII quantifier.  Its fixed
5-cycle side is

``R* = K5[T] + loops on T + (12345) loop``

for `T={12,15,23,34,45}`.  The Case-XII `L*` list (p. 21) is exactly

``[s] (s in S),  K5[S],  K5,5[S,T]``

with `S={13,14,24,25,35}`.  Thus it has 5 S-loops, 10 S--S edges, and 25
S--T edges (40 types total), and has no `(12345)` type, no T-loop, and no
T--T type.  This is exact admissible **BF support**, not a statement about
the set of 3-edge-colourings of `L`.

## Tait-empty branch

There is no missing Tait-colourability case in the Case-XII support
reduction.  In the discussion following Lemma 4.3 (pp. 14--16), the paper
proves only the one-way statement that if `L` is 3-edge-colourable then its
candidate cases are XII or XIII, and Proposition 4.4 explicitly records
non-3-edge-colourability only for Cases I--XI (and for `R` in XIII).  It makes
no 3-edge-colourability assertion for `L` in XII.  Therefore an `L` with no
Tait colouring is still included whenever its exact BF-type graph is the
Case-XII `L*` list.

For the D5 argument, each admissible `(s)(t)` BF type is already an actual
six-matching BF-colouring of the same 5-pole.  Its two triple colour classes
and four singleton classes define the required matching-level relation.  No
Tait state set is needed.  Consequently D5 must be formulated from exact BF
support plus common perfect-matching incidence; restricting it to
`Tait(L)=S` would incorrectly omit the Tait-empty branch.

## Four-valued decision

| Claim | Decision | Boundary |
|---|---|---|
| A minimum counterexample with a cycle-separating 5-cut, in the cyclically-5 but not cyclically-6 branch, has a Case-XII side with exact 40-type support (when the 13-case alternative is XII). | **已覆盖** | 2026 Proposition 4.4 + Case-XII Appendix list; this is conditional on selecting Case XII. |
| Every minimum BF counterexample is thereby reduced to an exact-40 pole. | **缺分支** | The cyclically-6-connected branch has no cycle-separating 5-cut and is not covered by Proposition 4.4. |
| D5 applies to Case XII regardless of whether `L` is Tait-colourable. | **已覆盖** | It uses the exact BF support and actual six matching classes; no exact-S Tait hypothesis is justified by the paper. |
| An arbitrary real cubic 5-pole with the 40-type support is automatically a minimum-counterexample cut side. | **需附加条件** | Need a minimum host `G`, cubic/bridgeless hypotheses, cyclically 5-edge-connected and not cyclically 6-connected, a cycle-separating 5-cut, and the Case-XII side identification. |
| Girth five is required as an independent D5 premise. | **不需要（在该分支中为推论）** | `R=C5` in Cases I--XII gives `g(G)=5` (Prop. 4.4); D5 itself only needs the exact BF support. |

Hence Gate 0 is **closed for the cyclic-5, 5-cut Case-XII branch**, including
the Tait-empty `L` branch, but it is **not a global reduction of all minimum
counterexamples**.  The remaining global branch is cyclic connectivity at
least six.

This audit does not decide the D5 four-way join itself.
