# Gate 0: the cyclically-≥6 branch

**Audit date:** 2026-08-30.  **Scope:** only the implication from a
minimum-order Berge–Fulkerson counterexample with cyclic connectivity at least
six to either a BF cover or a reduction to a cycle-separating 5-cut.  No new
graph generation, higher-order census, route/load experiment, or broad
literature search is used.

## Decision

The result is **strictly unclassified / undecided**.  The available structure
does not produce a BF cover and does not force a cycle-separating 5-cut.  The
weakest useful additional hypothesis is either

\[
\lambda_c(G)=5\quad\text{for every minimum BF counterexample }G,
\tag{C5-min}
\]

or a theorem directly proving BF for the cyclically-6-connected branch.  The
first is exactly the missing reduction; it is not supplied by the current
cyclic-connectivity theorem.

## What the cached primary sources say

Máčajová–Mazzuoccolo, *Proc. AMS* 148 (2020), Theorem 1.2, proves only

\[
\lambda_c(G)\ge 5
\]

for a minimum counterexample.  The sentence immediately following the theorem
explicitly leaves cyclic connectivity 5 **or 6** (under the Jaeger–Swart
conjecture).  It does not assert \(\lambda_c(G)=5\).

The 2026 Máčajová–Mazzuoccolo–Tabarelli Proposition 4.4 applies only
after a cycle-separating 5-cut is present (equivalently, in the exact-5 branch
of a graph already known to be cyclically at least 5-connected).  Therefore
its (R=C_5) and Case-XII 40-type conclusions cannot be applied when
\(\lambda_c(G)\ge6\) and no such cut exists.

The Jaeger–Swart conjecture does not repair this gap: it concerns the
nonexistence of snarks with cyclic connectivity greater than six, so even if
assumed it leaves the exact-six branch.  The cached 2025 construction of
cyclically-6-connected strictly critical snarks confirms that this graph
class is not vacuous (without saying anything about their BF status).

## Why a cyclically-6 graph does not collapse to the 5-cut interface

For a vertex set \(X\), let \(C=\delta(X)\), \(k=|C|\), and
\(m_M(X)=|M\cap C|\).  Cubicity and the matching equation give

\[
3|X|=2|E(X)|+k,\qquad
|X|=2|M\cap E(X)|+m_M(X),
\]

so

\[
m_M(X)\equiv |X|\equiv k\pmod 2.                 \tag{1}
\]

For six matchings forming a BF cover,

\[
\sum_{r=1}^6m_{M_r}(X)=2k.                         \tag{2}
\]

At a cyclic 6-cut, (1)–(2) allow, for example,

\[
(m_{M_r}(X))_{r=1}^6=(2,2,2,2,2,2)
\quad\text{or}\quad(0,2,2,2,2,4).
\]

Thus parity and the BF edge-load equation neither force a 5-cut nor determine
one of the 5-pole boundary types.  They also do not construct the six global
perfect matchings.

If \(\lambda_c(G)\ge6\), every cut of size at most five has at least one
acyclic shore.  A connected acyclic shore with boundary size \(k\) is a cubic
tree and satisfies

\[
|X|=k-2.
\]

Consequently the only possible small shores have orders 1, 2, or 3 for
\(k=3,4,5\), respectively.  These are trivial tree cuts, not
cycle-separating 5-cuts.  Suppressing or replacing such a tree changes the
matching boundary relation; no BF-lifting theorem in the current material
shows that minimality preserves a counterexample or creates a 5-cut.  Hence
the tree-cut observation is a structural boundary, not a reduction.

## Correct global implication

Let \(E_5\) denote the assertion that all 13 MMT exact-5 boundary cases are
impossible for a minimum counterexample, and let \(C5\text{-min}\) be (C5-min).
Then

\[
E_5\;\land\;(C5\text{-min})
\Longrightarrow \text{the Berge–Fulkerson conjecture}.       \tag{3}
\]

Indeed, Theorem 1.2 gives \(\lambda_c\ge5\); (C5-min) makes it exactly 5,
after which MMT Proposition 4.4 supplies one of the 13 cases.  Without
(C5-min), the cyclically-≥6 branch is untouched.  Excluding only Case XII
would therefore not be a global BF proof: the exact-5 cases
I, II, IV, V, VII, VIII, IX, X, XI remain in the current project reduction,
and the cyclically-≥6 branch remains separate.

## Minimal corrected theorem target

The D5 theorem should be advertised as a **conditional exact-5 Case-XII
exclusion**:

\[
\mathcal C(L)=\mathcal L_{\mathrm{XII}}
\Longrightarrow
\text{a D5 four-cell join}\Longrightarrow A,
\]

where the first arrow is the unresolved incidence theorem and
\(\mathcal L_{\mathrm{XII}}\) is the exact 40-type BF support supplied by MMT.
It says nothing about a cyclically-6-connected minimum counterexample.  A
separate cyclic-6 theorem (BF directly, or a valid reduction to a
cycle-separating 5-cut) is required before any S-level BF claim is justified.

## Reproducible evidence

Primary cached PDF:

`[local archival reference]`

Relevant project decisions (read-only cross-checks):

* `units/berge-fulkerson/scratch/worker-cyclic6/p6-cyclic6-matching-cut-gate.md`
* `units/berge-fulkerson/scratch/worker-cyclic6/bf-cyclic6-decision-search-20260829.md`
* `units/berge-fulkerson/scratch/worker-mmtt-global-closure/mmtt-global-closure-gate.md`
* `[local archival reference]`

The source theorem can be checked without any experiment by running:

```sh
pdftotext -layout \
  [local archival reference] \
  [local archival reference]
rg -n -C 4 'Theorem 1.2|cyclic connectivity 5 or 6' [local archival reference]
```
