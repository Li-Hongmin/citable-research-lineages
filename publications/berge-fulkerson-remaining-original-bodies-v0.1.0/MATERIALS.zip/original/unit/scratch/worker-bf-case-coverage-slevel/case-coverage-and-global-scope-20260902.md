# Exact five-cut case coverage and the global Berge--Fulkerson scope

**Decision date:** 2026-09-02.  This is a narrow literature/quantifier
check, not a graph enumeration.  The source papers were read from the local
ResearchLibrary copies:

* E. Máčajová and G. Mazzuoccolo, *Reduction of the Berge--Fulkerson
  conjecture to cyclically 5-edge-connected snarks*, Proc. Amer. Math. Soc.
  **148** (2020), 4643--4652, DOI [10.1090/proc/15057], Theorem 1.2 and
  Proposition 2.2.
* E. Máčajová, G. Mazzuoccolo and G. Tabarelli, *Cycle separating cuts in
  possible counterexamples to the cycle double cover and the Berge-Fulkerson
  conjectures*, Ars Math. Contemp. **26** (2026), #P2.03, DOI
  [10.26493/1855-3974.3409.c13], Section 4.3, Proposition 4.4 and Appendix.

The project exclusions below are conditional on the published Appendix's
13-pair transcription and on its ordered semiedge convention.  “Strictly
excluded” means that the project has a necessary-condition obstruction to an
actual cubic 5-pole having the *exact* support listed for that case; it does
not mean that the source papers themselves proved the exclusion.

## 1. What the source papers cover

Write λ_c(G) for cyclic edge-connectivity and let (M) be a minimum-order
Berge--Fulkerson counterexample, if one exists.

* Máčajová--Mazzuoccolo (2020), Theorem 1.2, proves
  \[
  M\text{ exists}\Longrightarrow M\text{ is a cyclically
  5-edge-connected snark},
  \]
  i.e. \(\lambda_c(M)\geq 5\).  This is **not** the assertion
  \(\lambda_c(M)=5\).
* In Section 4.3 and Proposition 4.4, Máčajová--Mazzuoccolo--Tabarelli
  (2026) analyze the case in which such an (M) is *not* cyclically
  6-edge-connected.  Then a cycle-separating 5-cut exists, and the two
  ordered cubic 5-poles have one of exactly 13 disjoint support pairs,
  labelled I--XIII in the Appendix.  In cases I--XII the (R)-side may be
  chosen as the 5-cycle support; in I--XI the (L)-side is non-3-edge-
  colourable, while Case XII is only the case in which this is not ruled out.
  In Case XIII the (R)-side is non-3-edge-colourable.

Thus the source-level implication is

\[
 \mathrm{BF\ counterexample}
 \Longrightarrow
 \bigl[\lambda_c(M)\geq 6\bigr]
 \ \lor\ \bigvee_{J=\mathrm I}^{\mathrm{XIII}}\!J .
 \tag{1}
\]

The 13 alternatives are a classification of a possible **minimum
counterexample's cut**, not a classification of all cubic 5-poles.

## 2. Current project status of the 13 cases

| MMT case | Current status | Project evidence and exact scope |
|---|---|---|
| I | **Strictly excluded** | Permanent Note 048: stabilizer-complete global Kempe-action GFP has an empty supported fibre. Conditional on the Appendix transcription; rules out an actual pole with exact (H_{\rm I}). |
| II | **Strictly excluded** | Permanent Note 049: the exact (H_{\rm II}) GFP has empty fibres. Same conditional scope. |
| III | **Strictly excluded** | Permanent Note 046: simultaneous disjoint-pair Kempe routing contradicts the exact (L^*_{\rm III}) support. |
| IV | **Route closed; globally unresolved** | Permanent Note 050: all 294 locally coherent signatures and all 32 types survive the global-action gate. This is non-decisiveness of that abstraction, not a realization theorem. |
| V | **Strictly excluded** | Permanent Note 051: the exact (H_{\rm V}) GFP fibre over ([14]) is empty. |
| VI | **Strictly excluded** | Permanent Note 046: the same disjoint-pair routing obstruction as Case III. |
| VII | **Strictly excluded** | Permanent Note 052: exact (H_{\rm VII}) GFP fibres over ([14]) and ([35]) are empty. |
| VIII | **Strictly excluded** | Permanent Note 053: twelve supported (H_{\rm VIII}) fibres are empty at the stabilizer-complete GFP. |
| IX | **Route closed; globally unresolved** | The stabilizer-complete GFP leaves all 37 supported fibres nonempty (scratch certificate `worker-mmtt-case-ix-global-action`). Survival does not prove a pole exists. |
| X | **Strictly excluded** | Permanent Note 054: six supported (H_{\rm X}) fibres are empty at the GFP. |
| XI | **Not promoted; globally unresolved** | A scratch Omen GFP certificate leaves all 39 types alive after one deletion round (136 signatures removed), but no permanent note or README claim promotes it. Under the requested permanent-note/README evidence gate it remains unresolved; even the scratch result is only non-decisive, not a realization theorem. |
| XII | **Still unresolved** | Notes 011, 015, 019, 043, 047 and 055 close several routing/load/local-reduction routes, but no theorem excludes an actual exact Case-XII pole and no real Case-XII counterexample pair has been constructed. The remaining issue is common perfect-matching incidence across the five saturated carrier columns (Note 055). |
| XIII | **Strictly excluded** | Permanent Note 046: the (R^*) type ((12345)) and the three possible single-pair routings force a forbidden exact-support type. |

The word “route closed” is deliberately method-specific: it says that the
specified finite global Kempe-action gate is already non-decisive.  It does
not say that the case is mathematically consistent or realized by a pole.
With only permanent notes and the README counted, the 12-case partition is

\[
\begin{array}{c|l}
\text{strict exclusions (8)}&\mathrm{I,II,III,V,VI,VII,VIII,X},\\
\text{promoted route closures (2)}&\mathrm{IV,IX},\\
\text{still unresolved (2)}&\mathrm{XI,XII}.
\end{array}
\]

If internal scratch certificates are also counted as project evidence, the
Case-XI GFP result moves XI from the last row to the route-closure row,
giving 8/3/1 for Cases I--XII.  This maturity distinction does not alter the
global implication below: XI is not excluded.  Case XII is separated because
it is the active matching-incidence interface rather than merely a finished
GFP experiment.

If “the 12 cases” means only MMT Cases I--XII (with XIII treated separately),
the internal-evidence partition (counting the scratch XI certificate) is

\[
\begin{array}{c|l}
\text{strict exclusions (8)}&\mathrm{I,II,III,V,VI,VII,VIII,X},\\
\text{same-action route closures (3)}&\mathrm{IV,IX,XI},\\
\text{remaining unresolved case (1)}&\mathrm{XII}.
\end{array}
\]

Including XIII, the internal-evidence partition is 9 strict exclusions, 3
route closures, and 1 unresolved Case XII.  Under the permanent-note/README
gate requested for this audit, it is 9 strict exclusions, 2 promoted route
closures, and 2 unresolved cases (XI and XII).

## 3. Consequence for a purported Case-XII theorem

Combining the source implication (1) with the strict project exclusions gives
only

\[
 \mathrm{BF\ counterexample}
 \Longrightarrow
 \bigl[\lambda_c(M)\geq6\bigr]
 \ \lor\ \mathrm{IV}\ \lor\ \mathrm{IX}\ \lor\ \mathrm{XI}\ \lor\ \mathrm{XII}.
 \tag{2}
\]

Therefore a proof that Case XII is impossible would improve (2) to

\[
 \mathrm{BF\ counterexample}
 \Longrightarrow
 \bigl[\lambda_c(M)\geq6\bigr]
 \ \lor\ \mathrm{IV}\ \lor\ \mathrm{IX}\ \lor\ \mathrm{XI},
 \tag{3}
\]

not to a contradiction.  Even a proof excluding all 13 exact-5 cases would
only imply \(\lambda_c(M)\geq6\).  A separate theorem for the cyclically-6-connected
branch (or a theorem ruling out a minimum counterexample there) is still
required for the full Berge--Fulkerson conjecture.  The Jaeger--Swart
statement quoted by the 2026 paper concerns connectivity **greater than 6**;
it does not close the connectivity-6 branch.

## 4. Level of a general proof versus a real counterexample

*A general exact-Case-XII pole-exclusion theorem.*  If proved with the actual
common perfect-matching incidence of one simple connected cubic 5-pole and
with all quantifiers in the MMT support definition, it is a major theorem for
the cycle-separating-5-cut branch (roughly an A+/S− result in the present
program).  It is not, by itself, a solution of the Berge--Fulkerson
conjecture: (3) still contains IV, IX, XI and the λ_c≥6 branch.

*An actual exact-Case-XII 5-pole.*  A single pole realizing the 40-type
Case-XII support and no ((12345)) type would refute a proposed
non-realizability lemma and close the current proof route, but would not be a
Berge--Fulkerson counterexample.  To obtain a negative S-level resolution one
must construct a full bridgeless cubic graph (for example, a valid glued pair
of exact support poles) and prove that no six perfect matchings double-cover
its edges.  Pole realizability alone is therefore A+/S−, not a solution.

*An actual full non-BF graph.*  A verified bridgeless cubic graph with no
Berge--Fulkerson cover would settle the conjecture negatively and would be
S-level.  This is a much stronger object than a pole, and minimum-counterexample
classification is not needed to certify the negative answer once such a graph
is checked.

## 5. Quantifier and evidence risks

1. “Minimum counterexample” is conditional on existence; every MMT reduction
   is a necessary condition for such an (M), not an assertion that a pole or
   a case is realized.
2. “Cyclically 5-edge-connected” means λ_c≥5.  The 2026 13-case theorem is
   invoked only when λ_c is not at least 6 (hence exactly 5), not for the
   cyclically-6-connected branch.
3. The project GFP certificates prove impossibility of **exact** support sets
   under the stated boundary labelling.  Survival of an over-approximate GFP
   is only consistency with the necessary routing constraints.
4. The project exclusions are conditional on the MMT Appendix's 13-pair
   transcription, color/semiedge ordering, and stabilizer-complete relabelling;
   they should not be attributed to MMT as source theorems.
5. Case XII's phrase “not ruled out as 3-edge-colourable” does not assert that
   its (L)-side is 3-edge-colourable.  Both the Tait-empty and exact-(S)
   branches require separate treatment.
6. A pole support calculation is not automatically a whole-graph BF result:
   terminal gluing, simplicity/bridgelessness, and the correspondence between
   common boundary types and whole-graph BF colourings must all be verified.

## Decision

The accurate current headline is:

> The project has conditionally eliminated 9 of MMT's 13 exact
> cycle-separating-5-cut support cases.  At permanent-note/README maturity,
> the promoted global-action route is closed for IV and IX; XI has only a
> scratch-level non-decisive certificate, and XII remains the main
> matching-incidence interface.  Excluding Case XII alone is a decisive
> **subproblem** result, not an S-level solution of the Berge--Fulkerson
> conjecture.

The next S-level gate is consequently either (i) a theorem covering the four
remaining exact-5 cases together with the cyclically-6-connected branch, or
(ii) a fully verified bridgeless cubic counterexample.  No further claim is
licensed by the current Case-XII pole or finite no-hit data.
