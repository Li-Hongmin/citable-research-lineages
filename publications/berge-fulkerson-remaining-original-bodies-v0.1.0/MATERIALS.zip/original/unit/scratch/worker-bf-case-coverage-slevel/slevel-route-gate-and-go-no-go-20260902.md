# S-level route gate: Case XII versus the cyclically-six branch

**Decision date:** 2026-09-02.  This is a route decision, not a new census.
All computation mentioned below was already run on Omen; no new enumeration is
authorized by this note.

## The main proposition and its exact decomposition

Let \(\mathsf{BF}\) denote the Berge--Fulkerson conjecture, and let \(M\) be
a minimum counterexample if one exists.  The two source papers give

\[
\mathsf{BF}\text{ fails}
\Longrightarrow
\bigl[\lambda_c(M)\geq 6\bigr]\ \lor\
\bigl[\lambda_c(M)=5\text{ and one of MMT I--XIII occurs}\bigr].
\tag{G}
\]

Here 2020 Theorem 1.2 supplies \(\lambda_c(M)\geq5\); 2026 Proposition 4.4
supplies the 13 alternatives only when \(M\) is not cyclically
6-edge-connected, hence when \(\lambda_c(M)=5\).  The alternatives are exact
ordered 5-pole support pairs up to the paper's terminal permutations.

The actual S-level positive target is therefore the conjunction of two
independent gates:

\[
\begin{aligned}
J_5:\;&\text{no minimum counterexample has any of the remaining exact
  5-cut supports};\\
J_{\ge6}:\;&\text{no minimum counterexample has }\lambda_c(M)\geq6.
\end{aligned}
\]

\[
\boxed{J_5\ \land\ J_{\ge6}\Longrightarrow\mathsf{BF}.}\tag{S}
\]

At the current project level, strict boundary-action exclusions reduce
\(J_5\) to the exact-5 cases IV, IX, XI and XII.  Thus proving Case XII alone
would leave IV, IX and XI in (G); it cannot establish (S).

## The thinnest unresolved interfaces

### Case XII (five-cut gate)

Under the exact Case-XII support (the 40 positive types and no
\((12345)\), \(T\)-loop or \(T\)--\(T\) type), Note 055 proves column
saturation: the five \(S\)-loops and five disjoint \(S\)-\(T\) seed cells
generate all 40 positive cells.  The only missing implication is the
cross-column singleton-fibre join

\[
\tag{D5}
\text{five actual saturated carrier columns}
\Longrightarrow
\text{a four-column common singleton tuple}
\Longrightarrow (12345)\text{ cover}.
\]

The words “actual” and “common” are essential: each column is a family of
perfect matchings in the same cubic 5-pole, and nonempty columns need not
reuse a singleton matching.  Load equations, abstract quotient connectivity,
route parity, and finite GFP survival do not prove (D5).

### Cyclically-six gate

For a cycle-separating 6-cut with ordered six-poles \(H_X,H_Y\), define
\(\mathcal R(H)\) as the actual six-matching boundary-incidence relation.
The exact gluing lemma is

\[
\mathsf{BF}(G)\Longleftrightarrow
\exists\rho_X\in\mathcal R(H_X),\rho_Y\in\mathcal R(H_Y),\pi\in S_6:
\rho_X=\pi\rho_Y .
\tag{O6}
\]

The thinnest positive gate at \(\lambda_c(M)=6\) is therefore a theorem that
forces (O6) for the two actual shores of a minimum counterexample.  Minimality
of capped shores currently gives only
\(\forall p\,\exists\rho_p\in\mathcal R(H)\cap\operatorname{Fix}(p)\), not
the cross-shore \(\exists\rho_X,\rho_Y,\pi\) in (O6).  If
\(\lambda_c(M)>6\), there is no cycle-separating 6-cut to which (O6) can be
applied; one needs a direct BF theorem or a theorem excluding a minimum
counterexample with \(\lambda_c>6\).

Consequently Case XII and the cyclically-six branch cannot presently be
merged through a shared local lemma.  A purported bridge
\(\lambda_c\geq6\Rightarrow\) “a Case-XII 5-pole exists” is false as a
quantifier move: a graph with connectivity \(>6\) has no such separating
5-cut.  The only valid merge is the conjunction (S), with separate proofs of
\(J_5\) and \(J_{\geq6}\).

## Omen observations and a genuinely falsifiable next test

The completed Omen probe
units/berge-fulkerson/scratch/worker-omen-case-xii/recheck-20260902 tested the
cheapest real Case-XII counterexample target: order 15, girth at least 5,
545 augmented graphs and 15 degree-\((5,3^{15})\) candidates.  It found zero
exact-40/no-\(A\) poles.  This is finite no-hit evidence only; it is neither an
all-order proof nor an UNSAT certificate.

The next bounded test with decision value is one of the following, chosen
before running it:

* **Five-cut hit test:** a shared-graph/shared-perfect-matching Omen model for
  one fixed order, requiring exact Case-XII support, no \(A\), and the complete
  D5 incidence constraints.  A model followed by a pure independent PM
  verifier is a real pole-level counterexample to (D5).  Only after a valid
  \(C_5\) shore is glued and the whole graph is proved bridgeless does it become
  a negative BF result.
* **Six-cut hit test:** a shared-incidence Omen model for two real six-poles
  requiring \(\mathcal R(H_X)\cap\pi\mathcal R(H_Y)=\varnothing\) for every
  \(\pi\in S_6\), followed by a bridgeless-gluing check.  A hit is a genuine
  O6 boundary countermodel; a positive overlap is only negative evidence.

Existing Omen six-pole theta and fixed-seed probes found no disjoint relation
pair, while existing Case-XII CEGAR runs ended in unknown or round_limit.
Those statuses must not be relabelled as UNSAT.

### 2026-09-02 bounded discriminators (frozen)

The predeclared common-incidence D5 probe at nominal order \(13\), with two
matching slots per singleton/triple class and all five four-column joins
forbidden, ran on Omen for 600.028 seconds. It returned `unknown` with no
model and no CEGAR round; see
`worker-bf-joint-incidence-omen/d5-k2-shared-pm-bounded-unknown-20260902.md`.
This is not bounded UNSAT and does not justify increasing the pool size.

The predeclared actual-incidence O6 probe at order \(18\) ran on Omen for its
five-minute budget and emitted no complete candidate row. It is therefore
also `unknown`, not a bounded no-hit; see
`worker-cyclic6/omen-order18-random-20260902-result.md`. Both probes are
frozen, so no order or pool escalation follows from them.

The high-connectivity reduction is now explicit: for a \(2\)-factor \(F\) of
a cyclically at least \(6\)-edge-connected cubic graph \(G\), the multigraph
\(H=G+E(F)\) is a \(5\)-edge-connected \(5\)-regular graph with only trivial
\(5\)-cuts; a class-1 decomposition of \(H\) would project to a BF cover of
\(G\).  The required class-1 statement is the open \(m(5)=5\) problem (also
open for the underlying-cubic subclass), so this is a bridge, not a closure.

## Five-step execution sequence and gates

1. **Freeze the logical target.**  Record (G), \(J_5\), \(J_{\geq6}\), (D5)
   and (O6); verify that no Case-XII statement is being applied to
   \(\lambda_c>5\).
2. **Finish the five-cut proof leaf.**  Attack (D5) using only common
   perfect-matching incidence. The within-column, endpoint-transfer and
   cycle-subtraction routes are now closed; the only live arrow is
   cross-column singleton synchronization. Stop immediately at a general
   proof, a real exact-40/no-\(A\) pole, a sharp extra hypothesis, or a
   certified route failure.
3. **Run at most one Omen discriminator for the surviving leaf.**  A
   complete model plus independent verifier is a hit; unknown, round_limit,
   or a bounded no-hit is unresolved and does not justify an order increase.
4. **Treat the high-connectivity gate separately.**  Prove O6 at
   \(\lambda_c=6\) and separately close \(\lambda_c>6\), or exhibit a real
   disjoint six-pole pair.  Do not infer either from Case XII.
5. **Go/no-go for an S-level BF claim.**  Go only if both \(J_5\) (all four
   residual exact-5 cases, not XII alone) and \(J_{\geq6}\) are proved, or if
   a fully verified bridgeless cubic non-BF graph is constructed.  Otherwise
   freeze the result as a strict subproblem theorem or route boundary and
   stop.

## Level decision

An all-order proof of (D5) would be a major exact-5-branch theorem (A+/S− in
the current program), but not a solution of \(\mathsf{BF}\).  A real
exact-Case-XII 5-pole would refute pole non-realizability and close (D5), but
also would not by itself refute \(\mathsf{BF}\).  A verified full bridgeless
cubic graph with no six-matching double cover, or a proof of both gates in
(S), is the S-level event.
