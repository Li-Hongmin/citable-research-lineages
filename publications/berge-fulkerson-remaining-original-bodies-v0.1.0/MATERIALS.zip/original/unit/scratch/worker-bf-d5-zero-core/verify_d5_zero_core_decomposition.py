#!/usr/bin/env python3
"""Verify the D5 zero-core/carrierless-cycle decomposition.

This is a fixed-instance check, not a pole census.  It uses complete
perfect-matching families of two already frozen order-13 poles and checks
only the identities stated in d5-zero-core-carrier-decomposition-20260901.md.
No graph generation, SAT/CEGAR, random search, or abstract load model is
used.
"""

from __future__ import annotations

from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
UNIT = PROJECT / "units" / "berge-fulkerson"
KEMPE = UNIT / "scratch" / "worker-kempe"
REAL = UNIT / "scratch" / "worker-real-exact-s-no-a"
COMMON = UNIT / "scratch" / "worker-bf-common-section"


def load(name: str, path: Path):
    spec = spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


JOINT = load("zero_core_joint", KEMPE / "exact_st_joint_audit.py")
LOOP = load("zero_core_loop", REAL / "audit_loop_incidence_interface.py")
PROBE = load("zero_core_probe", COMMON / "ss_fibre_forbidden_probe.py")
FIRST = load(
    "zero_core_first",
    UNIT / "scratch" / "worker-bf-d5-incidence-gate"
    / "audit_first_synthesis_blocker_carriers.py",
)


S = tuple(sorted(JOINT.S))
SS = tuple(sorted(
    (u, v)
    for i, u in enumerate(S)
    for v in S[i:]
    if u != v and set(u).isdisjoint(v)
))


def proper_edges(data):
    edges, edge_vertices, _, _, _, _ = data
    return {
        index for index, edge in enumerate(edges)
        if len(edge_vertices[edge]) == 2
    }


def graph_components(edge_ids, data):
    """Return (vertices, edge_ids) components of a proper edge set."""
    edges, edge_vertices, _, _, _, _ = data
    adjacency = defaultdict(set)
    for index in edge_ids:
        endpoints = edge_vertices[edges[index]]
        if len(endpoints) != 2:
            raise AssertionError(("nonproper", index, endpoints))
        u, v = endpoints
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(adjacency)
    output = []
    while unseen:
        root = min(unseen)
        seen = {root}
        stack = [root]
        while stack:
            u = stack.pop()
            for v in adjacency[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        unseen -= seen
        component_edges = frozenset(
            index for index in edge_ids
            if set(edge_vertices[edges[index]]) <= seen
        )
        output.append((frozenset(seen), component_edges))
    return tuple(output)


def defect_components(matches, data):
    """Return proper defect components and their local matching loads."""
    edges, edge_vertices, _, _, _, _ = data
    load = [0] * len(edges)
    for matching in matches:
        for index in matching:
            load[index] += 1
    defect = frozenset(
        index for index, value in enumerate(load)
        if value != 1
    )
    proper = set(proper_edges(data))
    if not defect <= proper:
        raise AssertionError(("semiedge defect", defect - proper))
    rows = []
    for vertices, component in graph_components(defect, data):
        if len(component) != len(vertices):
            raise AssertionError(("defect not cycle", vertices, component))
        values = [load[index] for index in component]
        if sorted(values).count(0) != sorted(values).count(2):
            raise AssertionError(("nonalternating defect", values))
        if any(value not in (0, 2) for value in values):
            raise AssertionError(("bad defect value", values))
        twos = frozenset(index for index in component if load[index] == 2)
        carriers = tuple(
            position for position, matching in enumerate(matches)
            if twos <= set(matching)
        )
        rows.append((vertices, component, twos, carriers, load))
    return tuple(rows)


def check_one_pole(name, proper):
    pole = LOOP.pole(proper)
    data = JOINT.matching_data(pole)
    edges, edge_vertices, edge_position, _, _, pm_count = data
    proper_set = proper_edges(data)
    checked = 0
    robust = 0
    carrierless_components = 0

    for cell in SS:
        records = PROBE.all_witnesses(data, cell)
        for record in records:
            q_u, q_v, slots, singleton = record
            selected_load = [0] * len(edges)
            for matching in singleton:
                for index in matching:
                    selected_load[index] += 1
            if any(value > 2 for value in selected_load):
                raise AssertionError(("singleton load", name, cell))
            F = frozenset(
                index for index, value in enumerate(selected_load)
                if value == 2
            )
            Z = frozenset(
                index for index, value in enumerate(selected_load)
                if value == 0 and index in proper_set
            )
            if not Z <= proper_set or not F <= proper_set:
                raise AssertionError(("F/Z semiedge", name, cell))
            q_intersection = frozenset(set(q_u) & set(q_v))
            q_union_proper = frozenset(
                index for index in (set(q_u) | set(q_v))
                if index in proper_set
            )
            if Z != (q_intersection & proper_set):
                raise AssertionError(("Z identity", name, cell))
            if frozenset(proper_set - set(F)) != q_union_proper:
                raise AssertionError(("K identity", name, cell))

            # K is exactly the isolated common-edge pieces plus the proper
            # symmetric-difference components.
            K_components = graph_components(proper_set - set(F), data)
            for _, component in K_components:
                if component & Z and component != (component & Z):
                    raise AssertionError(("Z not isolated", name, cell, component, Z))
                if component <= Z and len(component) != 1:
                    raise AssertionError(("Z component size", name, cell, component))

            path_parts = [
                part for part in PROBE.sym_components(q_u, q_v, data)
                if len(part["terminals"]) == 2
            ]
            if len(path_parts) != 2:
                raise AssertionError(("boundary path count", name, cell, path_parts))
            cycle_parts = [
                part for part in PROBE.sym_components(q_u, q_v, data)
                if not part["terminals"]
            ]
            if any(len(part["proper"]) % 2 for part in cycle_parts):
                raise AssertionError(("odd alternating cycle", name, cell))

            halves = PROBE.transferred_t_halves(record, cell, data)
            if len(halves) != 2:
                raise AssertionError(("toggle count", name, cell, halves))
            both_st = all(part["outcome"] == "ST" for part in halves)
            if both_st:
                robust += 1
                u, v = cell
                for part in path_parts:
                    terminals = set(part["terminals"])
                    if len(terminals & set(u)) != 1:
                        raise AssertionError(
                            ("noncross path", name, cell, terminals)
                        )
                    if len(part["proper"]) % 2:
                        raise AssertionError(("odd path length", name, cell))

            # The separation C cap Z = empty and the F hit are checked for
            # every carrierless component, whether or not this pole has the
            # global no-T-loop property.
            for part in halves:
                if part["outcome"] != "ST":
                    continue
                t_pair = tuple(part["t_pair"])
                index_by_position = {
                    position: singleton[slots.index(position)]
                    for position in slots
                }
                t_matches = (
                    part["r_t"],
                    index_by_position[t_pair[0]],
                    index_by_position[t_pair[1]],
                )
                for _, component, _, carriers, load in defect_components(
                    t_matches, data
                ):
                    if carriers:
                        continue
                    carrierless_components += 1
                    if component & Z:
                        raise AssertionError(("carrierless meets Z", name, cell))
                    if not component & F:
                        raise AssertionError(("carrierless misses F", name, cell))
                    if len(component) < 6:
                        raise AssertionError(("short carrierless cycle", name, cell))
            checked += 1

    return {
        "pole": name,
        "perfect_matchings": pm_count,
        "SS_witnesses": checked,
        "both_ST_transfers": robust,
        "carrierless_components_checked": carrierless_components,
    }


def main():
    results = (
        check_one_pole("all_ST_no_A_boundary", LOOP.ALL_SS_EDGES),
        check_one_pole("first_synthesis_no_A_boundary", FIRST.EDGES),
    )
    print(results)
    print("D5_ZERO_CORE_DECOMPOSITION_VERIFIED")


if __name__ == "__main__":
    main()
