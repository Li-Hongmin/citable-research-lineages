#!/usr/bin/env python3
"""Pure-standard-library check of the D5 zero-core decomposition.

The two hard-coded order-13 poles are already frozen real incidence
boundaries. This verifier independently enumerates their perfect matchings;
it does not import the project matching code, networkx, SAT, or a census.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations, product


S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(
    pair for pair in combinations(range(1, 6), 2) if pair not in S
)
PAIRS = tuple(combinations(range(1, 6), 2))
SS_CELLS = tuple(sorted(
    (u, v)
    for i, u in enumerate(sorted(S))
    for v in sorted(S)[i + 1:]
    if set(u).isdisjoint(v)
))

POLES = {
    # The 37-PM all-(S--T), no-A boundary pole.
    "all_ST_no_A_boundary": (
        (0, 8), (0, 11), (1, 7), (1, 9), (2, 9), (2, 12),
        (3, 10), (3, 12), (4, 10), (4, 11), (5, 7), (5, 8),
        (5, 9), (6, 8), (6, 11), (6, 12), (7, 10),
    ),
    # The 34-PM first-synthesis no-A boundary pole.
    "first_synthesis_no_A_boundary": (
        (0, 7), (0, 11), (1, 5), (1, 7), (2, 9), (2, 10),
        (3, 8), (3, 11), (4, 8), (4, 10), (5, 6), (5, 9),
        (6, 7), (6, 12), (8, 9), (10, 12), (11, 12),
    ),
}


def edge_table(proper):
    edges = tuple(("p", u, v) for u, v in proper)
    edges += tuple(("s", position, position - 1) for position in range(1, 6))
    incident = {vertex: [] for vertex in range(13)}
    for index, edge in enumerate(edges):
        if edge[0] == "p":
            _, u, v = edge
            incident[u].append(index)
            incident[v].append(index)
        else:
            _, _, vertex = edge
            incident[vertex].append(index)
    return edges, incident


def enumerate_matchings(proper):
    edges, incident = edge_table(proper)
    out = set()

    def visit(uncovered, chosen):
        if not uncovered:
            out.add(frozenset(chosen))
            return
        vertex = min(uncovered)
        for index in incident[vertex]:
            edge = edges[index]
            if edge[0] == "p":
                endpoints = {edge[1], edge[2]}
            else:
                endpoints = {edge[2]}
            if endpoints <= uncovered:
                visit(uncovered - endpoints, chosen + (index,))

    visit(frozenset(range(13)), tuple())
    return edges, incident, tuple(sorted(out, key=lambda m: tuple(sorted(m))))


def boundary(matching, edges):
    return frozenset(
        edges[index][1] for index in matching if edges[index][0] == "s"
    )


def classes(matchings, edges):
    result = defaultdict(list)
    for matching in matchings:
        result[tuple(sorted(boundary(matching, edges)))].append(matching)
    return result


def complement(pair):
    return tuple(sorted(set(range(1, 6)) - set(pair)))


def all_witnesses(data, cell):
    edges, _, matchings, by_boundary = data
    u, v = cell
    first = by_boundary[complement(u)]
    second = by_boundary[complement(v)]
    slots = tuple(sorted(set(u) | set(v)))
    out = []
    for q_u in first:
        for q_v in second:
            base = [0] * len(edges)
            for q in (q_u, q_v):
                for index in q:
                    base[index] += 1
            if max(base, default=0) > 2:
                continue
            for singleton in product(*(by_boundary[(i,)] for i in slots)):
                load = base[:]
                for p in singleton:
                    for index in p:
                        load[index] += 1
                if all(value == 2 for value in load):
                    out.append((q_u, q_v, slots, singleton))
    return tuple(out)


def symmetric_components(first, second, data):
    edges, _, _, _ = data
    symmetric = set(first) ^ set(second)
    adjacency = defaultdict(set)
    labels = {}
    for index in symmetric:
        edge = edges[index]
        if edge[0] == "p":
            _, u, v = edge
            a, b = ("v", u), ("v", v)
            adjacency[a].add(b)
            adjacency[b].add(a)
            labels[frozenset((a, b))] = index
        else:
            _, position, vertex = edge
            a, b = ("v", vertex), ("t", position)
            adjacency[a].add(b)
            adjacency[b].add(a)
            labels[frozenset((a, b))] = index
    unseen = set(adjacency)
    out = []
    while unseen:
        root = min(unseen, key=str)
        seen = {root}
        stack = [root]
        while stack:
            vertex = stack.pop()
            for other in adjacency[vertex]:
                if other not in seen:
                    seen.add(other)
                    stack.append(other)
        unseen -= seen
        proper = frozenset(
            index for edge_key, index in labels.items()
            if edge_key <= seen and edges[index][0] == "p"
        )
        terminals = tuple(sorted(node[1] for node in seen if node[0] == "t"))
        boundary_edges = frozenset(
            index for edge_key, index in labels.items()
            if edge_key <= seen and edges[index][0] == "s"
        )
        out.append({
            "proper": proper,
            "terminals": terminals,
            "boundary": boundary_edges,
        })
    return tuple(out)


def defect_components(matches, data):
    edges, _, _, _ = data
    load = [0] * len(edges)
    for matching in matches:
        for index in matching:
            load[index] += 1
    defect = frozenset(
        index for index, value in enumerate(load)
        if value != 1
    )
    if any(edges[index][0] != "p" for index in defect):
        raise AssertionError("semiedge defect")
    parts = []
    for vertices, component in graph_components(defect, data):
        if len(vertices) != len(component):
            raise AssertionError("defect component is not a cycle")
        if any(load[index] not in (0, 2) for index in component):
            raise AssertionError("nonbinary defect load")
        if sum(load[index] == 0 for index in component) != sum(
            load[index] == 2 for index in component
        ):
            raise AssertionError("nonalternating defect")
        twos = frozenset(index for index in component if load[index] == 2)
        carriers = tuple(
            position for position, matching in enumerate(matches)
            if twos <= set(matching)
        )
        parts.append((vertices, component, carriers, load))
    return tuple(parts)


def graph_components(edge_ids, data):
    edges, _, _, _ = data
    adjacency = defaultdict(set)
    for index in edge_ids:
        _, u, v = edges[index]
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(adjacency)
    out = []
    while unseen:
        root = min(unseen)
        seen = {root}
        stack = [root]
        while stack:
            vertex = stack.pop()
            for other in adjacency[vertex]:
                if other not in seen:
                    seen.add(other)
                    stack.append(other)
        unseen -= seen
        component = frozenset(
            index for index in edge_ids
            if {edges[index][1], edges[index][2]} <= seen
        )
        out.append((frozenset(seen), component))
    return tuple(out)


def transferred_halves(record, cell, data):
    q_u, q_v, slots, singleton = record
    edges, _, _, by_boundary = data
    by_matching = {
        matching: key
        for key, family in by_boundary.items()
        for matching in family
    }
    out = []
    for part in symmetric_components(q_u, q_v, data):
        if len(part["terminals"]) != 2:
            continue
        path = part["proper"] | part["boundary"]
        q_u_new = frozenset(set(q_u) ^ set(path))
        q_v_new = frozenset(set(q_v) ^ set(path))
        pair_u = tuple(complement(by_matching[q_u_new]))
        pair_v = tuple(complement(by_matching[q_v_new]))
        if pair_u in S and pair_v in T:
            t_pair, r = pair_v, q_v_new
            outcome = "ST"
        elif pair_v in S and pair_u in T:
            t_pair, r = pair_u, q_u_new
            outcome = "ST"
        elif pair_u in S and pair_v in S:
            t_pair, r, outcome = None, None, "SS"
        elif pair_u in T and pair_v in T:
            t_pair, r, outcome = None, None, "TT"
        else:
            t_pair, r, outcome = None, None, "A"
        out.append((outcome, t_pair, r, part["terminals"]))
    return tuple(out)


def check_pole(name, proper):
    edges, incident, matchings = enumerate_matchings(proper)
    by_boundary = classes(matchings, edges)
    data = (edges, incident, matchings, by_boundary)
    proper_set = {
        index for index, edge in enumerate(edges) if edge[0] == "p"
    }
    witnesses = 0
    both_st = 0
    carrierless = 0
    for cell in SS_CELLS:
        for record in all_witnesses(data, cell):
            q_u, q_v, slots, singleton = record
            load = [0] * len(edges)
            for matching in singleton:
                for index in matching:
                    load[index] += 1
            F = frozenset(
                index for index, value in enumerate(load)
                if value == 2
            )
            Z = frozenset(
                index for index, value in enumerate(load)
                if value == 0 and index in proper_set
            )
            if F - proper_set or Z - proper_set:
                raise AssertionError("F/Z semiedge")
            q_intersection = frozenset(set(q_u) & set(q_v))
            q_union = frozenset(
                index for index in set(q_u) | set(q_v)
                if index in proper_set
            )
            if Z != (q_intersection & proper_set):
                raise AssertionError("Z identity")
            if frozenset(proper_set - F) != q_union:
                raise AssertionError("K identity")
            parts = symmetric_components(q_u, q_v, data)
            paths = [part for part in parts if len(part["terminals"]) == 2]
            if len(paths) != 2:
                raise AssertionError("two boundary paths")
            for component in graph_components(proper_set - F, data):
                _, component_edges = component
                if component_edges & Z:
                    if component_edges <= Z and len(component_edges) == 1:
                        continue
                    raise AssertionError("Z is not isolated in K")
            halves = transferred_halves(record, cell, data)
            if len(halves) != 2:
                raise AssertionError("two toggles")
            if all(part[0] == "ST" for part in halves):
                both_st += 1
                u, v = cell
                for part in paths:
                    terminals = set(part["terminals"])
                    if len(terminals & set(u)) != 1:
                        raise AssertionError("noncross path")
                    if len(part["proper"]) % 2:
                        raise AssertionError("odd proper path length")
            index_by_position = {
                position: singleton[slots.index(position)]
                for position in slots
            }
            for outcome, t_pair, r, _ in halves:
                if outcome != "ST":
                    continue
                matches = (
                    r,
                    index_by_position[t_pair[0]],
                    index_by_position[t_pair[1]],
                )
                for _, component, carriers, defect_load in defect_components(
                    matches, data
                ):
                    if carriers:
                        continue
                    carrierless += 1
                    if component & Z:
                        raise AssertionError("carrierless meets Z")
                    if not component & F:
                        raise AssertionError("carrierless misses F")
                    if len(component) < 6:
                        raise AssertionError("short carrierless cycle")
            witnesses += 1
    return {
        "pole": name,
        "perfect_matchings": len(matchings),
        "SS_witnesses": witnesses,
        "both_ST_transfers": both_st,
        "carrierless_components_checked": carrierless,
    }


def main():
    results = tuple(check_pole(name, proper) for name, proper in POLES.items())
    print(results)
    print("D5_ZERO_CORE_STDLIB_VERIFIED")


if __name__ == "__main__":
    main()
