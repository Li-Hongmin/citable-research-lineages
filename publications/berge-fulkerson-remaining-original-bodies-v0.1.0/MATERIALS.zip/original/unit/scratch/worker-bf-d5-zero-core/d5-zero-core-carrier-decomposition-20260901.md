# D5 zero-edge core and carrierless-cycle boundary

## Scope and four-value decision

This note isolates the exact consequence of the saturated singleton load in
one disjoint D5 witness. It is an incidence statement for one cubic
five-pole; no aggregate relaxation, boundary-only relation, order census, or
new pole construction is used.

The conclusion is a route boundary, not a Case-XII proof or a real
counterexample. In the exact Case-XII setting it gives a rigid decomposition
of the proper complement of the saturated set and places every carrierless
defect cycle away from the common zero-edge matching. The remaining step is
cross-cell synchronization as the omitted terminal m varies; none of the
identities below identifies the five singleton choices.

## Convention

The five semiedges are s_1,...,s_5, incident with terminal vertices
v_1,...,v_5. A boundary pair ab denotes the class whose matching uses the
semiedges at the complementary three positions [5]\{a,b}; a singleton P_i
uses s_i. This is the project convention in exact_st_joint_audit.py.

Take a disjoint D5 cell and apply the standard terminal-path transfer to its
disjoint S--S partner. Write the transferred pair as u,v in S, with
u cap v = empty and u union v = [5]\{m}. An actual witness is

    (Q_u,Q_v; P_i (i != m)),
    chi(Q_u) + chi(Q_v) + sum_(i != m) chi(P_i) = 2*1.       (1)

The path transfer toggles one alternating terminal path in both triple
matchings. It preserves the singleton tuple, the edge-load equation, and
Q_u cap Q_v on proper edges, so all statements below can equivalently be
read on the original D5 witness.

For a proper edge e set

    ell(e) = sum_(i != m) chi(P_i)(e),
    F = {e : ell(e)=2},       Z = {e : ell(e)=0}.           (2)

Equation (1) gives

    chi(Q_u)(e) + chi(Q_v)(e) = 2 - ell(e),                 (3)

and hence

    ell=0: both Q's use e;   ell=1: exactly one;   ell=2: neither. (4)

In particular

    E_proper(H) minus F = (Q_u union Q_v) cap E_proper,
    Z = (Q_u cap Q_v) cap E_proper.                         (5)

## The zero-edge core decomposition

Let K be the proper-edge graph H-F. At a nonterminal internal vertex the
four singleton matchings give total incidence four. Since every proper
singleton load is at most two, its load profile is (2,1,1) or (2,2,0).
Therefore d_F is 1 or 2, and d_K is 2 or 1, respectively. At the omitted
terminal v_m every selected P_i uses a proper edge, so its two proper loads
are (2,2); hence d_F(v_m)=2 and d_K(v_m)=0. At v_i, i != m, three selected
singletons use proper edges (the fourth uses s_i), so the proper profile is
(2,1); hence d_F(v_i)=1 and d_K(v_i)=1.

Every Z-edge joins two nonterminal d_F=2 vertices. At such a vertex the
profile (2,2,0) has a unique zero-load edge, so no two Z-edges meet: Z is a
matching. Its endpoints have K-degree one, so each Z-edge is an isolated
component of K. The remaining
edges of K are the proper part of the symmetric difference Q_u delta Q_v.
The symmetric difference
has exactly four semiedge endpoints, at positions u union v, and therefore
consists of two terminal paths and proper even alternating cycles.

Now impose the negative Case-XII support assumptions for this transferred
witness: no A-type and no T--T type. A path whose two endpoints both lie in
u or both in v would toggle the two matching labels to the A,A column. Of
the two cross pairings, one is the S--S column and one is the T--T column.
Thus, when both path toggles are the allowed S--T transfers, each path joins
one endpoint of u to one endpoint of v. At its two semiedge ends the
alternating colours are different, so its proper length is even and its
vertex count is odd. Consequently:

> **Zero-core decomposition.** Under the allowed S--T path-transfer
> condition, K is the disjoint union of isolated Z-edges, two odd-order
> u--v terminal paths, and proper even alternating cycles.

This is stronger than merely saying that Z is a matching. It also explains
the saturated blocker: after v_m is covered by s_m, the two odd terminal
paths cannot each be matched inside K.

## Carrierless cycles after transfer

For either terminal-path toggle, let R be the resulting triple matching whose
boundary pair is in T, and let a,b be the two positions of that T-pair. The
corresponding T-half is R,P_a,P_b. Its proper defect set

    C = {e : chi(R)(e) + chi(P_a)(e) + chi(P_b)(e) != 1}

is a union of even cycles with alternating loads 0,2. Under the no-T-loop
assumption at least one component is carrierless: if every component had one
of R,P_a,P_b as a carrier of all its load-two edges, flipping those carriers
on the disjoint components would make the three matchings edge-disjoint and
produce the forbidden T-loop.

For every carrierless component C_0:

1. C_0 cap Z is empty. A Z-edge belongs to both Q_u,Q_v, is unaffected by
   a path toggle, and is therefore in R. All selected P_i avoid it because
   ell=0. Its T-half load is consequently one.

2. C_0 cap F is nonempty. On a carrierless component all three pair labels
   among R,P_a,P_b occur on load-two edges. In particular one load-two edge
   is used by both P_a and P_b. Since these are among the four selected
   singleton matchings and ell <= 2, that edge lies in F.

The component has at least three load-two edges (all three pair labels occur),
so its alternating length is at least six. In exact Case XII, each of the two
allowed path transfers therefore supplies a proper even cycle C_0 of length
at least six with

    C_0 cap Z = empty,       C_0 cap F != empty.            (6)

## What this does not synchronize

For each of the five D5 cells, the argument produces its own omitted position
m, singleton choices P_i (i != m), saturated set F_m, zero matching Z_m, two
odd terminal paths, and carrierless cycles C_(m,1), C_(m,2). The edge-load
identities do not imply

    Z_1 = ... = Z_5,   F_1 = ... = F_5,
    or P_i^(m) = P_i^(m') .

Nor do they imply that the cycles C_(m,j) share a common alternating
exchange. A four-cell cylinder join requires one common five-tuple of actual
singleton perfect matchings; it is a cross-cell witness-reuse statement, not
an edgewise consequence of (3)--(6). Existing genuine no-A poles with extra
T-loop/T--T support realize the blocker/carrier pattern while all five joins
are empty, so the missing negative-support implication cannot be silently
omitted.

## Four-value status

* Proof of exact Case XII => D5 join: not obtained.
* Real exact-40 Case-XII counterexample: not obtained.
* Sharp additional theorem: (3)--(6), the zero-core decomposition and the
  carrierless-cycle separation; it is valid for one actual witness and
  exposes the exact data a synchronization theorem must couple.
* Route status: closed at the current saturated-load/carrierless-cycle
  interface. The thinnest remaining arrow is

    negative exact BF support across all five cells
      => cross-m synchronization of (F_m,Z_m,C_(m,j)),

  which remains unproved and has no real exact-40 counterexample.

## Finite check

The companion verifier verify_d5_zero_core_stdlib.py independently enumerates
all perfect matchings using only the Python standard library and checks every
qualifying witness in two frozen real poles (one 37-PM all-S--T pole and one
34-PM no-A pole). It ends with the marker
D5_ZERO_CORE_STDLIB_VERIFIED. The poles do not satisfy exact Case XII; they
deliberately serve as incidence boundaries with extra forbidden support.
