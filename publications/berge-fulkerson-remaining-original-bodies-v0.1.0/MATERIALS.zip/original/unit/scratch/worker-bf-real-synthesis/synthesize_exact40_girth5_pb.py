#!/usr/bin/env python3
"""Girth-five wrapper for the bounded exact-40 joint synthesis pulse.

This reuses the shared graph/perfect-matching CEGAR driver and adds the
local consequences of the published Case-XII girth-five normalization:
the proper graph contains no triangle and no 4-cycle.  It is intentionally
only a bounded synthesis experiment; a round limit is not an UNSAT proof.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_joint_pb_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
BASE_BUILD_SOLVER = BASE.build_solver


def build_solver(n: int):
    solver, x, edges, witness_vars = BASE_BUILD_SOLVER(n)
    edge_var = {edge: x[edge] for edge in edges}

    # A Case-XII full graph can be normalized to girth five.  Any proper
    # triangle or proper 4-cycle in this pole would survive the apex/gluing
    # construction, so forbid both locally.
    from itertools import combinations
    from z3 import Not, Or

    for a, b, c in combinations(range(n), 3):
        tri = ((a, b), (a, c), (b, c))
        solver.add(Or(*(Not(edge_var[e]) for e in tri)))
    for a, b, c, d in combinations(range(n), 4):
        for cycle in (
            ((a, b), (b, c), (c, d), (a, d)),
            ((a, b), (b, d), (c, d), (a, c)),
            ((a, c), (b, c), (b, d), (a, d)),
        ):
            solver.add(Or(*(Not(edge_var[e]) for e in cycle)))
    return solver, x, edges, witness_vars


# The base run() resolves build_solver in its own module globals.
BASE.build_solver = build_solver


if __name__ == "__main__":
    BASE.main()
