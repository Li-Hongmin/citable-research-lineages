# Omen exact-​S/no-​A synthesis pulse (2026-09-01)

## Decision target

Test the narrower conjectural bridge

\[
\operatorname{Tait}(H)=S
\quad\Longrightarrow\quad
H\text{ has an }A=(12345)\text{ BF cover}
\]

at order (n=15).  The solver encodes five actual three-colour Tait
decompositions, one for each

\[
S=\{(0,2),(0,3),(1,3),(1,4),(2,4)\},
\]

on a common cubic five-pole.  Complete matching enumeration then lazily
blocks extra Tait states, an (A)-cover, disconnected graphs, and bridges.

## Reproduction

Omen directory:
`[local archival reference]`.

```text
python3 -u synthesize_exact_s_no_a_pb.py --n 15 --max-rounds 80 \
  --timeout-ms 300000 --json exact_s_no_a_n15.json
```

Source fingerprints:

```text
synthesize_exact_s_no_a_pb.py
33f3fc0af8f849fe0b30e821fec81f89e3b1127554410f6fb9bcb9ab8e92024e
synthesize_exact40_joint_pb.py (base)
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

## Result

All 80 solver rounds were SAT; the run ended with
`EXACT_S_NO_A_SYNTHESIS_ROUND_LIMIT`.  No real exact-​S/no-​A pole and no
UNSAT certificate was obtained.

The complete evaluator found 23 rounds with exactly five Tait states; all 23
had an (A)-cover.  The remaining 12 rounds without an (A)-cover had extra
Tait states (six to ten states), so they were not exact-​S candidates.  The
other 45 rounds had both an extra Tait state and an (A)-cover.  Thus this
bounded pulse found no counterexample to the exact-​S capacity bridge, but
it does not prove the bridge in arbitrary order.

This is a sharper finite boundary than exact-40 synthesis because it tests
the five-state hypothesis directly; the unresolved all-order issue remains
the common matching-incidence/rounding theorem.
