#!/usr/bin/env python3
"""Bounded common-PM-pool synthesis for a real Case-XII five-pole.

All 40 positive Case-XII boundary types use one common finite pool of actual
perfect-matching vectors.  For each boundary class (five singleton classes
and ten triple classes) there are K pool slots; every six-matching cover for a
positive type selects one slot in each of its six positions, and the selected
vectors must have proper-edge load exactly two.  The complete matching family
of each candidate graph is then enumerated and CEGAR blockers are added for
extra support, an A-cover, and D5 four-cell joins.

This is a bounded incidence strengthening, not a proof: a real pole can have
more than K vectors in a class, and a round limit is unresolved.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import combinations
from pathlib import Path

from z3 import Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_base_for_shared_case_xii", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

TERMINALS = BASE.TERMINALS
TARGET_TYPES = tuple(BASE.TARGET_TYPES)


def boundary_name(boundary: frozenset[int]) -> str:
    return "_".join(map(str, sorted(boundary)))


def build_solver(n: int, pool_size: int):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(PbEq([(value, 1) for value in incident], target))
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    # One common pool for every boundary class appearing in Case XII.
    boundaries = {frozenset((i,)) for i in TERMINALS}
    for kind in TARGET_TYPES:
        boundaries.add(BASE.boundary_for_pair(kind[0]))
        boundaries.add(BASE.boundary_for_pair(kind[1]))
    boundaries = tuple(sorted(boundaries, key=lambda b: (len(b), tuple(sorted(b)))))

    y = {}
    for boundary in boundaries:
        bname = boundary_name(boundary)
        for slot in range(pool_size):
            for edge in edges:
                y[(boundary, slot, edge)] = Bool(
                    f"y_{bname}_{slot}_{edge[0]}_{edge[1]}"
                )
            # Each slot is an actual PM of the same graph.
            for edge in edges:
                solver.add(Or(Not(y[(boundary, slot, edge)]), x[edge]))
            for v in range(n):
                terms = [(y[(boundary, slot, edge)], 1)
                         for edge in edges if v in edge]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))

    # For every positive type, select a pool vector in each of its six slots.
    # The w variables linearize selector AND pool incidence at each edge.
    for type_index, kind in enumerate(TARGET_TYPES):
        slot_boundaries = BASE.slots_for_type(kind)
        selectors = {}
        for position, boundary in enumerate(slot_boundaries):
            choices = []
            for slot in range(pool_size):
                z = Bool(f"z_{type_index}_{position}_{slot}")
                selectors[(position, slot)] = z
                choices.append((z, 1))
            solver.add(PbEq(choices, 1))

        for edge in edges:
            load_terms = []
            for position, boundary in enumerate(slot_boundaries):
                for slot in range(pool_size):
                    z = selectors[(position, slot)]
                    yy = y[(boundary, slot, edge)]
                    w = Bool(
                        f"w_{type_index}_{position}_{slot}_{edge[0]}_{edge[1]}"
                    )
                    solver.add(Or(Not(w), z))
                    solver.add(Or(Not(w), yy))
                    solver.add(Or(Not(z), Not(yy), w))
                    load_terms.append((w, 1))
            solver.add(PbLe(load_terms, 2))
            solver.add(Or(Not(x[edge]), PbEq(load_terms, 2)))

    return solver, x, edges


def evaluate(n: int, proper_edges):
    edge_count = len(proper_edges)
    matchings, classes = BASE.matching_classes(n, proper_edges)
    support = {}
    witnesses = {}
    for kind in BASE.ALL_TYPES:
        witness = BASE.find_cover(kind, classes, edge_count)
        if witness is not None:
            support[kind] = True
            witnesses[kind] = witness
    a_witness = BASE.find_a_cover(classes, edge_count)
    projections = {cell: BASE.cell_projection(cell, classes, edge_count)
                   for cell in BASE.D5}
    joins = []
    join_data = []
    for omitted in BASE.D5:
        common = set.intersection(*(set(projections[cell])
                                    for cell in BASE.D5 if cell != omitted))
        if common:
            singleton_tuple = min(common, key=str)
            completions = tuple(
                (cell, projections[cell][singleton_tuple])
                for cell in BASE.D5 if cell != omitted
            )
            union = set()
            for matching in singleton_tuple:
                union.update(proper_edges[edge] for edge in matching
                             if edge < edge_count)
            for _, pair in completions:
                for matching in pair:
                    union.update(proper_edges[edge] for edge in matching
                                 if edge < edge_count)
            joins.append(True)
            join_data.append((omitted, frozenset(union)))
        else:
            joins.append(False)
    return {
        "matchings": matchings,
        "classes": classes,
        "support": frozenset(support),
        "witnesses": witnesses,
        "a_witness": a_witness,
        "joins": tuple(joins),
        "join_data": tuple(join_data),
    }


def certificate(n: int, proper_edges, result, pool_size: int):
    return {
        "n": n,
        "pool_size": pool_size,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "target_support": result["support"] == frozenset(TARGET_TYPES),
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
    }


def run(n: int, pool_size: int, max_rounds: int, timeout_ms: int,
        out_path: Path | None):
    solver, x, edges = build_solver(n, pool_size)
    target_set = frozenset(TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("SHARED_CASE_XII_POOL_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("SHARED_CASE_XII_POOL_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var, model_completion=True))))
        result = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge)})

        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for omitted, union in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = certificate(n, proper_edges, result, pool_size)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and result["a_witness"] is None
                and not any(result["joins"])):
            payload = {"status": "real_exact40_shared_pool",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACT40_SHARED_POOL_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("SHARED_CASE_XII_POOL_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--pool-size", type=int, default=2)
    parser.add_argument("--max-rounds", type=int, default=20)
    parser.add_argument("--timeout-ms", type=int, default=300000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    if args.pool_size < 1:
        raise SystemExit("pool-size must be positive")
    run(args.n, args.pool_size, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
