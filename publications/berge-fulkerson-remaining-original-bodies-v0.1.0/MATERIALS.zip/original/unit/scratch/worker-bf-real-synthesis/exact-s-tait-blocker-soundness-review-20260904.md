# Sound graph clauses for an exact-\(S\) Tait CEGAR

## Scope and notation

Fix the vertex set and the five terminal vertices.  The Boolean variable
\(x_e\), for every potential proper edge \(e\), says that \(e\) is present.
Every feasible solver assignment satisfies

\[
 \deg_x(v)=
 \begin{cases}
 2,&v\text{ is a terminal vertex},\\
 3,&v\text{ is not a terminal vertex}.
 \end{cases}                                                    \tag{1}
\]

The terminal semiedges are fixed and are not graph variables.  A pole
perfect matching includes one incidence at every vertex.  A Tait colouring
is a triple of pairwise edge-disjoint pole perfect matchings.

This note audits only the soundness and direction of lazy graph clauses.  It
does not make a bounded synthesis result into an all-order statement.

## 1. Blocking one concrete three-matching colouring

Let \(G_0\) be a feasible simple cubic five-pole, and let
\(\mathcal C=(M_1,M_2,M_3)\) be one concrete Tait colouring of \(G_0\).  Put

\[
 U=\bigcup_{r=1}^3 (M_r\cap E_{\rm proper}),\qquad
 F=\mathcal E_{\rm potential}\setminus U.                       \tag{2}
\]

### Exact-colouring blocker

Among arbitrary graph assignments, this fixed triple is a Tait colouring of
the whole graph exactly when all edges of \(U\) are present and all edges of
\(F\) are absent.  The exact negation is therefore

\[
 \boxed{
   \bigvee_{e\in U}\neg x_e\;\vee\;
   \bigvee_{f\in F}x_f
 } .                                                             \tag{3}
\]

In Z3 notation:

```python
used = frozenset(
    proper_edges[i]
    for matching in (m1, m2, m3)
    for i in matching
    if i < len(proper_edges)
)
clause = Or(
    *[Not(x[e]) for e in used],
    *[x[e] for e in edges if e not in used],
)
solver.add(clause)
```

The signs matter.  A used edge invalidates the colouring when it is deleted,
so its literal is \(\neg x_e\).  A currently missing edge invalidates the
fixed full colouring when it is added, so its literal is \(x_f\).  The
clauses \(\bigvee_{e\in U}x_e\) or
\(\bigvee_{f\in F}\neg x_f\) are already true on \(G_0\) and block nothing.

### Simplification in the present cubic encoding

Because the three matchings are pairwise disjoint and each covers every
vertex once, they use all three incidences at every vertex.  Hence

\[
 U=E_{\rm proper}(G_0).                                         \tag{4}
\]

Moreover, under (1), any feasible graph containing every edge of \(U\) has
already saturated the prescribed proper degree of every vertex.  It cannot
add an edge of \(F\).  Thus on the current feasible domain (3) is equivalent
to the shorter clause

\[
 \boxed{\bigvee_{e\in U}\neg x_e}.                              \tag{5}
\]

This is exactly `clause_for_union`.  It is sound here.  Outside the fixed
degree domain, (5) is stronger than the exact blocker and can incorrectly
discard a supergraph that retains \(U\) but adds an uncoloured edge; (3) is
the robust formulation if the degree encoding is later changed.

Notice that (5), with all three colour classes in \(U\), is only a labelled
whole-graph no-good: every Tait colouring partitions the whole cubic pole.

## 2. The stronger two-singleton-state blocker

For a boundary state \(t=ij\), let \(P_i\) and \(P_j\) be concrete perfect
matchings with singleton boundaries \(\{i\}\) and \(\{j\}\), respectively,
and suppose they are edge-disjoint.  Let

\[
 U_2=(P_i\cup P_j)\cap E_{\rm proper}.                           \tag{6}
\]

### Complement lemma

In every feasible cubic five-pole containing all edges of \(U_2\), the two
fixed matchings still cover two distinct incidences at every vertex.  The
unique remaining incidence at each vertex forms a third perfect matching.
At the boundary its semiedges are precisely the three terminals outside
\(\{i,j\}\).  Consequently the graph has Tait state \(ij\), although its
third matching need not be the third matching of \(G_0\).

It follows that

\[
 \boxed{\bigvee_{e\in U_2}\neg x_e}                              \tag{7}
\]

is a sound CEGAR clause for excluding this concrete *pair witness* to the
unwanted state.  It intentionally excludes more than one concrete
three-matching colouring: changing or replacing only the complementary
third matching does not remove the unwanted state.  Adding a missing edge
while retaining \(U_2\) also does not help inside the cubic domain; the
degree constraints merely force a different complementary matching.

Thus the pair-union direction used by
`synthesize_exact40_tait_blocked.py` is mathematically sound.  Checking only
proper-edge disjointness is also sufficient there: the two singleton
boundaries use distinct fixed semiedges.

The clause would cease to be sound if the solver admitted noncubic graphs or
if the stored partial matchings failed to cover every vertex.  Its proof uses
both facts essentially.

## 3. The current driver is Tait-empty, not exact-\(S\)

The current driver enumerates pair clauses only for states in `BASE.T`, but
then records an error whenever `result["tait_states"]` is nonempty and accepts
only when `not result["tait_states"]`.  Therefore it seeks a Tait-empty pole.
It does **not** implement

\[
 \operatorname{Tait}(G)=S.                                     \tag{8}
\]

For exact-\(S\), the negative test and acceptance condition must instead be

```python
states = set(result["tait_states"])
extra_states = states - set(BASE.S)  # equivalently states & BASE.T
if extra_states:
    # add all sound pair-union clauses for these T states
    ...

if (not bad
        and states == set(BASE.S)
        and result["support"] == target_set
        and result["a_witness"] is None
        and not any(result["joins"])):
    ...
```

One may add clauses for all currently existing `BASE.T` pairs, as the driver
already does; the important correction is not to classify surviving
\(S\)-states as errors.

## 4. Forty positive BF types do not guarantee the five positive Tait states

`TARGET_TYPES` contains the five \(S\)-loops \((s)(s)\), but an arbitrary
BF witness for such a loop has slots

\[
 Q,Q',P_i,P_j,P'_i,P'_j.                                       \tag{9}
\]

The exact double-cover equations do not imply
\(Q=Q'\), \(P_i=P'_i\), or \(P_j=P'_j\).  A general loop witness need not be
a doubled Tait colouring.  Hence the forty existential target BF witnesses
alone do **not** imply \(S\subseteq\operatorname{Tait}(G)\).

There is a lossless way to enforce the five positive states using the
already allocated loop-witness variables.  For every \(s=(i,j)\in S\), let
`kind=(s,s)`.  Impose, on every potential proper edge,

```python
for s in S:
    kind = (s, s)
    for e in edges:
        solver.add(witness_vars[(kind, 0)][e]
                   == witness_vars[(kind, 1)][e])
        solver.add(witness_vars[(kind, 2)][e]
                   == witness_vars[(kind, 4)][e])
        solver.add(witness_vars[(kind, 3)][e]
                   == witness_vars[(kind, 5)][e])
```

The paired slots have the same fixed semiedge boundary, so proper-edge
equality is equality of the full pole matchings.  Dividing the loop's exact
double-cover equation by two then says that the three distinct matchings
partition every edge: they are a Tait colouring of state \(s\).

This strengthening is lossless for the intended graph class.  If a graph has
Tait state \(s\), doubling its three colour classes is a valid witness for
the target loop \((s)(s)\); the existential loop variables may choose that
witness.  Dedicated three-matching variables would be equivalent but larger.

The current worktree already contains precisely these equalities in
`synthesize_exact40_joint_pb.py` (the `Exact-S positive gate` immediately
after the six-slot load equations).  Thus the present base solver *does*
force \(S\subseteq\operatorname{Tait}(G)\), but this comes from the added
equalities, not from the forty target-type constraints by themselves.

Combining these five doubled-loop equalities with the sound pair-union
blockers for all \(t\in T\) gives the exact condition

\[
 \operatorname{Tait}(G)=S.                                     \tag{10}
\]

## 5. Audit decision

* Full-triple `union-edge` deletion has the correct negative-literal
  direction and is sound under the fixed cubic degree constraints, but it is
  merely a whole-graph no-good.
* The existing two-singleton union clause is also sound and stronger: any
  cubic completion retaining that pair still has the unwanted state.
* Adding a missing edge invalidates one fixed full triple, but does not remove
  a fixed disjoint singleton pair as a witness to the same boundary state.
* The current exact-40 Tait-blocked driver asks for no Tait states at all.
  Its acceptance test must be corrected for exact-\(S\).
* The forty target BF witnesses do not automatically supply the five positive
  \(S\)-states.  Doubled-loop equalities are a sound, lossless encoding of
  those positive states, and the current base solver already includes them.

There is also an operational consequence of combining the two current
files.  Since the base positive gate guarantees at least the five \(S\)
states, the condition `if result["tait_states"]:` in the Tait-blocked driver
is always true.  Once all \(T\)-pair witnesses have been removed, that branch
can append `bad` without adding any new Tait clause, while the acceptance
condition `not result["tait_states"]` remains impossible.  The exact-\(S\)
fix is therefore required for both semantics and CEGAR progress.
