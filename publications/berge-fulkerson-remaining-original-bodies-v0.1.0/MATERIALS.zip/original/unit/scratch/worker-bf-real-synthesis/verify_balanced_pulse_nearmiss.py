#!/usr/bin/env python3
"""Pure-stdlib check of the first Omen balanced-pulse models.

The checker reads the first-round graph and selected two-edge blocker from the
two Omen JSON certificates.  It independently enumerates all perfect
matchings, recomputes ordinary BF support, singleton Tait states, the A-cover
test, D5 joins, and the complete-family balanced-blocker condition.  It does
not import z3, networkx, or the synthesis driver.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path


TERMINALS = tuple(range(5))
PAIR_SET = tuple(itertools.combinations(TERMINALS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(PAIR_SET) - set(S))
ALL_TYPES = tuple(itertools.combinations_with_replacement(PAIR_SET, 2))
D5 = tuple(sorted((s, t) for s in S for t in T if set(s).isdisjoint(t)))


def boundary_for_pair(pair):
    return frozenset(set(TERMINALS) - set(pair))


def enumerate_matchings(n, proper_edges):
    edge_count = len(proper_edges)
    adjacency = {v: [] for v in range(n)}
    for index, (u, v) in enumerate(proper_edges):
        adjacency[u].append((v, index))
        adjacency[v].append((u, index))
    used = [False] * n
    chosen = []
    out = []

    def rec():
        try:
            u = next(v for v in range(n) if not used[v])
        except StopIteration:
            out.append(tuple(sorted(chosen)))
            return
        used[u] = True
        if u in TERMINALS:
            chosen.append(edge_count + u)
            rec()
            chosen.pop()
        for v, index in adjacency[u]:
            if used[v]:
                continue
            used[v] = True
            chosen.append(index)
            rec()
            chosen.pop()
            used[v] = False
        used[u] = False

    rec()
    return tuple(sorted(set(out)))


def matching_classes(n, proper_edges):
    matchings = enumerate_matchings(n, proper_edges)
    edge_count = len(proper_edges)
    classes = defaultdict(list)
    for matching in matchings:
        boundary = frozenset(index - edge_count for index in matching
                             if index >= edge_count)
        classes[boundary].append(matching)
    return matchings, classes


def find_cover(kind, classes, edge_count):
    first, second = kind
    families = [classes.get(boundary_for_pair(first), ()),
                classes.get(boundary_for_pair(second), ())]
    slots = tuple(first + second)
    families.extend(classes.get(frozenset((i,)), ()) for i in slots)
    if any(not family for family in families):
        return None
    selected = [None] * 6
    load = [0] * edge_count
    order = sorted(range(6), key=lambda i: len(families[i]))

    def rec(k):
        if k == 6:
            return tuple(selected)
        slot = order[k]
        for matching in families[slot]:
            if any(index < edge_count and load[index] >= 2
                   for index in matching):
                continue
            for index in matching:
                if index < edge_count:
                    load[index] += 1
            selected[slot] = matching
            answer = rec(k + 1)
            if answer is not None:
                return answer
            for index in matching:
                if index < edge_count:
                    load[index] -= 1
        return None

    return rec(0)


def find_a_cover(classes, edge_count):
    families = [classes.get(frozenset((i,)), ()) for i in TERMINALS]
    if any(not family for family in families):
        return None
    selected = [None] * 5
    load = [0] * edge_count
    order = sorted(range(5), key=lambda i: len(families[i]))

    def rec(k):
        if k == 5:
            return tuple(selected)
        slot = order[k]
        for matching in families[slot]:
            if any(index < edge_count and load[index] >= 2
                   for index in matching):
                continue
            for index in matching:
                if index < edge_count:
                    load[index] += 1
            selected[slot] = matching
            answer = rec(k + 1)
            if answer is not None:
                return answer
            for index in matching:
                if index < edge_count:
                    load[index] -= 1
        return None

    return rec(0)


def cell_projection(cell, classes, edge_count):
    first, second = cell
    singleton_families = [classes.get(frozenset((i,)), ())
                          for i in TERMINALS]
    left = classes.get(boundary_for_pair(first), ())
    right = classes.get(boundary_for_pair(second), ())
    output = {}
    for singleton_tuple in itertools.product(*singleton_families):
        load = [0] * edge_count
        for slot in first + second:
            for index in singleton_tuple[slot]:
                if index < edge_count:
                    load[index] += 1
        if any(value > 2 for value in load):
            continue
        for q_left in left:
            trial = load[:]
            if any(index < edge_count and trial[index] >= 2
                   for index in q_left):
                continue
            for index in q_left:
                if index < edge_count:
                    trial[index] += 1
            for q_right in right:
                if all(index >= edge_count
                       or trial[index] + (index in q_right) == 2
                       for index in range(edge_count)):
                    output[singleton_tuple] = (q_left, q_right)
                    break
            if singleton_tuple in output:
                break
    return output


def tait_states(matchings, classes, edge_count):
    all_objects = set(range(edge_count + len(TERMINALS)))
    matching_set = {frozenset(matching) for matching in matchings}
    states = set()
    for i, j in PAIR_SET:
        for left in classes.get(frozenset((i,)), ()):
            left_set = set(left)
            for right in classes.get(frozenset((j,)), ()):
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    states.add((i, j))
                    break
            if (i, j) in states:
                break
    return tuple(sorted(states))


def balanced_violations(classes, blocker, proper_edges):
    edge_count = len(proper_edges)
    bad = []
    for i in TERMINALS:
        for matching in classes.get(frozenset((i,)), ()):
            weight = sum(proper_edges[index] in blocker
                         for index in matching if index < edge_count)
            if weight != 1:
                bad.append(("singleton", i, weight))
    for pair in PAIR_SET:
        for matching in classes.get(boundary_for_pair(pair), ()):
            weight = sum(proper_edges[index] in blocker
                         for index in matching if index < edge_count)
            if weight != 0:
                bad.append(("triple", pair, weight))
    return tuple(bad)


def verify(path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    cert = payload["rounds"][0]["certificate"]
    n = cert["n"]
    proper_edges = tuple(tuple(edge) for edge in cert["proper_edges"])
    blocker = {tuple(edge) for edge in cert["selected_blocker"]}
    assert len(blocker) == 2 and all(edge in proper_edges for edge in blocker)
    degree = [0] * n
    for u, v in proper_edges:
        assert u != v
        degree[u] += 1
        degree[v] += 1
    assert degree[:5] == [2] * 5 and degree[5:] == [3] * (n - 5)
    matchings, classes = matching_classes(n, proper_edges)
    edge_count = len(proper_edges)
    support = {kind for kind in ALL_TYPES
               if find_cover(kind, classes, edge_count) is not None}
    states = tait_states(matchings, classes, edge_count)
    projections = {cell: cell_projection(cell, classes, edge_count)
                   for cell in D5}
    joins = []
    for omitted in D5:
        common = set.intersection(*(set(projections[cell])
                                    for cell in D5 if cell != omitted))
        joins.append(bool(common))
    violations = balanced_violations(classes, blocker, proper_edges)
    has_a = find_a_cover(classes, edge_count) is not None

    assert len(matchings) == cert["matching_count"]
    assert len(support) == cert["support_size"]
    assert len(states) == len(cert["tait_states"])
    assert has_a == cert["has_A"]
    assert tuple(joins) == tuple(cert["d5_join_flags"])
    assert (not violations) == cert["balanced_complete_family"]
    print({"path": str(path), "pm": len(matchings),
           "support": len(support), "tait_states": len(states),
           "has_A": has_a, "joins": joins,
           "balanced_violations": len(violations),
           "blocker": sorted(blocker)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("json", nargs="+", type=Path)
    args = parser.parse_args()
    for path in args.json:
        verify(path)
    print("BALANCED_PULSE_NEARMISS_VERIFIED")


if __name__ == "__main__":
    main()
