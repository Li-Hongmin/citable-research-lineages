# Case-IV exact support forces the Tait-empty branch

Let (H) be a cubic 5-pole whose complete BF support is the exact
32-type Case-IV set.  The only supported singleton-loop types are


\[
[13],
[24],
[25].
\]

If (H) has a proper 3-edge-colouring with lonely pair (r), doubling its
three colour classes gives a BF cover of loop type ([r]).  Therefore any
Tait state must lie in ({13,24,25}).

The standard two-colour Kempe-chain boundary lemma says that from a Tait
state (r), the two neighbours of (r) in the complementary pentagon

\[
13-14-24-25-35-13
\]

are also Tait states (switch the two bichromatic components joining the
lonely terminal pair to the three terminals of the third colour).  Each such
state again gives a doubled loop BF cover.  But every member of
({13,24,25}) has a neighbour in ({14,35}), whose loop types are absent
from Case IV:

\[
N(13)=\{14,35\},quad N(24)=\{14,25\},quad
N(25)=\{24,35\}.
\]

Hence no Tait state can occur:

\[
\boxed{\operatorname{Tait}(H)=\varnothing.}
\]

This is only a branch reduction.  It does not exclude a Tait-empty exact
Case-IV pole, and it does not prove the missing four-cell singleton join.
The Omen exact-32 pulse in the neighbouring result file found no model at
order 13 but ended at `round_limit`, so the all-order question remains open.

