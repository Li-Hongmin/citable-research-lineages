#!/usr/bin/env python3
"""Synthesize the Note-058 binary conflict pattern on one real 5-pole.

The fixed order ``n`` graph is one simple cubic 5-pole with semiedges at
vertices 0,...,4.  Ten shared singleton perfect matchings encode the tokens
0_i,1_i.  Each of the five cyclic A5 rows is imposed together with the two
D5 completions supplied by the row transport theorem.  Complete matching
enumeration then lazily excludes A, every T-loop/T--T type, disconnected
graphs, and every four-of-five D5 join.

SAT is a genuine P1 witness.  UNSAT applies only to the fixed order.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from pathlib import Path

from z3 import Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("binary_conflict_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

# (duplicated i, S partner a, T partner j, transported b, bit(a), bit(j)).
ROWS = (
    (0, 2, 1, 4, 0, 0),
    (1, 3, 2, 0, 0, 1),
    (2, 4, 3, 1, 0, 1),
    (3, 0, 4, 2, 0, 1),
    (4, 1, 0, 3, 1, 1),
)


def pair(u, v):
    return tuple(sorted((u, v)))


def guarded_add(solver, constraint, guard=None):
    solver.add(constraint if guard is None else Or(Not(guard), constraint))


def add_matching(solver, x, edges, name, boundary, guard=None, enabled=True):
    y = {edge: Bool(f"{name}_{edge[0]}_{edge[1]}") for edge in edges}
    if not enabled:
        return y
    for edge in edges:
        guarded_add(solver, Or(Not(y[edge]), x[edge]), guard)
    for vertex in range(max(max(edge) for edge in edges) + 1):
        terms = [(y[edge], 1) for edge in edges if vertex in edge]
        target = 1 - int(vertex in boundary)
        guarded_add(solver, PbEq(terms, target), guard)
    return y


def add_cover(solver, x, edges, vectors, guard=None, enabled=True):
    if not enabled:
        return
    for edge in edges:
        terms = [(vector[edge], 1) for vector in vectors]
        guarded_add(solver, PbLe(terms, 2), guard)
        guarded_add(solver, Or(Not(x[edge]), PbEq(terms, 2)), guard)


def build_solver(n, assumption_mode=False, disabled=frozenset()):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()
    group_names = (["cubic", "token_pm", "distinct"]
                   + [f"{kind}_{row}" for row in range(5)
                      for kind in ("a5", "d0", "d1")])
    guards = {name: Bool(f"assume_{name}") for name in group_names} if assumption_mode else {}
    active = lambda name: assumption_mode or name not in disabled
    for vertex in range(n):
        target = 2 if vertex in BASE.TERMINALS else 3
        if active("cubic"):
            guarded_add(solver,
                        PbEq([(x[edge], 1) for edge in edges if vertex in edge], target),
                        guards.get("cubic"))
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    vectors = {}
    boundaries = {}
    for position in BASE.TERMINALS:
        for bit in (0, 1):
            name = f"p_{position}_{bit}"
            boundary = frozenset((position,))
            vectors[name] = add_matching(solver, x, edges, name, boundary,
                                         guards.get("token_pm"), active("token_pm"))
            boundaries[name] = boundary
        if active("distinct"):
            guarded_add(solver, Or([vectors[f"p_{position}_0"][edge]
                                    != vectors[f"p_{position}_1"][edge]
                                    for edge in edges]), guards.get("distinct"))

    covers = []
    for row, (i, a, j, b, abit, jbit) in enumerate(ROWS):
        roles = {
            "qs": BASE.boundary_for_pair(pair(i, a)),
            "rt": BASE.boundary_for_pair(pair(i, j)),
            "qd0": BASE.boundary_for_pair(pair(a, b)),
            "qd1": BASE.boundary_for_pair(pair(a, b)),
        }
        for role, boundary in roles.items():
            name = f"r_{row}_{role}"
            role_guard = {
                "qs": guards.get(f"a5_{row}"),
                "rt": (Or(guards[f"a5_{row}"], guards[f"d0_{row}"], guards[f"d1_{row}"])
                       if assumption_mode else None),
                "qd0": guards.get(f"d0_{row}"),
                "qd1": guards.get(f"d1_{row}"),
            }[role]
            role_groups = {
                "qs": (f"a5_{row}",),
                "rt": (f"a5_{row}", f"d0_{row}", f"d1_{row}"),
                "qd0": (f"d0_{row}",),
                "qd1": (f"d1_{row}",),
            }[role]
            role_enabled = assumption_mode or any(active(group) for group in role_groups)
            vectors[name] = add_matching(solver, x, edges, name, boundary,
                                         role_guard, role_enabled)
            boundaries[name] = boundary

        fixed_a = f"p_{a}_{abit}"
        fixed_j = f"p_{j}_{jbit}"
        a5 = (f"r_{row}_qs", f"r_{row}_rt", f"p_{i}_1", fixed_a,
              f"p_{i}_0", fixed_j)
        d0 = (f"r_{row}_qd0", f"r_{row}_rt", fixed_a, f"p_{b}_0",
              f"p_{i}_0", fixed_j)
        d1 = (f"r_{row}_qd1", f"r_{row}_rt", fixed_a, f"p_{b}_1",
              f"p_{i}_1", fixed_j)
        for kind, names in (("A5", a5), ("D5-0", d0), ("D5-1", d1)):
            group = {"A5": "a5", "D5-0": "d0", "D5-1": "d1"}[kind]
            add_cover(solver, x, edges, tuple(vectors[name] for name in names),
                      guards.get(f"{group}_{row}"), active(f"{group}_{row}"))
            covers.append((row, kind, names))
    return solver, x, edges, vectors, boundaries, tuple(covers), guards


def audit_assumption_core(n, only=None):
    names = (["cubic", "token_pm", "distinct"]
             + [f"{kind}_{row}" for row in range(5)
                for kind in ("a5", "d0", "d1")])

    def check(disabled=()):
        solver, _, _, _, _, _, _ = build_solver(n, disabled=frozenset(disabled))
        solver.set(timeout=30000)
        status = solver.check()
        return {"status": str(status), "reason": solver.reason_unknown()
                if status == unknown else None}

    deletion_sets = {
        "without_cubic": ("cubic",),
        "without_token_pm": ("token_pm",),
        "without_distinct": ("distinct",),
        "without_all_a5": tuple(name for name in names if name.startswith("a5_")),
        "without_all_d0": tuple(name for name in names if name.startswith("d0_")),
        "without_all_d1": tuple(name for name in names if name.startswith("d1_")),
    }
    deletion_sets.update({
        f"without_row_{row}": (f"a5_{row}", f"d0_{row}", f"d1_{row}")
        for row in range(5)
    })
    deletion_sets.update({
        f"without_d1_row_{row}": (f"d1_{row}",)
        for row in range(5)
    })
    deletion_sets["only_all_a5"] = tuple(
        name for name in names if name.startswith(("d0_", "d1_")))
    deletion_sets["only_row_0"] = tuple(
        name for name in names
        if name.startswith(("a5_", "d0_", "d1_")) and not name.endswith("_0"))
    deletion_sets["only_a5_row_0"] = tuple(
        name for name in names
        if name.startswith(("a5_", "d0_", "d1_")) and name != "a5_0")
    if only:
        disabled = () if only == "full" else deletion_sets[only]
        result = check(disabled)
        print(json.dumps({"case": only, **result}, sort_keys=True), flush=True)
        return {"n": n, only: result}

    output = {"n": n, "full": check()}
    print(json.dumps({"case": "full", **output["full"]}, sort_keys=True), flush=True)
    output["deletions"] = {}
    for label, groups in deletion_sets.items():
        output["deletions"][label] = check(groups)
        print(json.dumps({"case": label, **output["deletions"][label]},
                         sort_keys=True), flush=True)
    print(json.dumps(output, indent=2, sort_keys=True))
    print("BINARY_CONFLICT_ASSUMPTION_CORE_AUDITED")
    return output


def decode_model(model, proper_edges, vectors, boundaries):
    edge_index = {edge: index for index, edge in enumerate(proper_edges)}
    edge_count = len(proper_edges)
    decoded = {}
    for name, vector in vectors.items():
        matching = [edge_index[edge] for edge in proper_edges
                    if bool(model.eval(vector[edge], model_completion=True))]
        matching.extend(edge_count + terminal for terminal in boundaries[name])
        decoded[name] = tuple(sorted(matching))
    return decoded


def verify_encoded(result, proper_edges, decoded, boundaries, covers):
    edge_count = len(proper_edges)
    for name, matching in decoded.items():
        assert matching in result["classes"][boundaries[name]]
    for _, _, names in covers:
        load = [0] * edge_count
        for name in names:
            for edge in decoded[name]:
                if edge < edge_count:
                    load[edge] += 1
        assert load == [2] * edge_count
    for position in BASE.TERMINALS:
        assert decoded[f"p_{position}_0"] != decoded[f"p_{position}_1"]


def matching_edges(matching, proper_edges):
    return [list(proper_edges[index]) for index in matching if index < len(proper_edges)]


def certificate(n, proper_edges, result, decoded, covers):
    used = sorted({name for _, _, names in covers for name in names})
    return {
        "n": n,
        "proper_edges": [list(edge) for edge in proper_edges],
        "matching_count": len(result["matchings"]),
        "support_size": len(result["support"]),
        "has_A": result["a_witness"] is not None,
        "forbidden_T_types": [str(kind) for kind in sorted(
            result["support"] & set(BASE.FORBIDDEN_TYPES), key=str)],
        "d5_join_flags": list(result["joins"]),
        "matching_vectors": {name: matching_edges(decoded[name], proper_edges)
                             for name in used},
        "covers": [{"row": row, "kind": kind, "matchings": list(names)}
                   for row, kind, names in covers],
    }


def run(n, max_rounds, timeout_ms, out_path):
    solver, x, edges, vectors, boundaries, covers, _ = build_solver(n)
    forbidden = set(BASE.FORBIDDEN_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            break
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            break

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, variable in x.items()
                                    if bool(model.eval(variable, model_completion=True))))
        result = BASE.evaluate(n, proper_edges)
        decoded = decode_model(model, proper_edges, vectors, boundaries)
        verify_encoded(result, proper_edges, decoded, boundaries, covers)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda item: (len(item), tuple(sorted(item))))
            crossing = [x[edge] for edge in edges
                        if (edge[0] in side) ^ (edge[1] in side)]
            solver.add(Or(crossing))
            bad.append({"kind": "disconnected", "side": sorted(side)})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] & forbidden, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = certificate(n, proper_edges, result, decoded, covers)
        rounds.append({"round": round_no, "bad": bad,
                       "summary": {key: cert[key] for key in (
                           "matching_count", "support_size", "has_A",
                           "forbidden_T_types", "d5_join_flags")}})
        print(json.dumps(rounds[-1], sort_keys=True), flush=True)
        if not bad:
            payload = {"status": "real_binary_conflict_p1", "rounds": rounds,
                       "certificate": cert, "elapsed_s": time.time() - started}
            print("REAL_BINARY_CONFLICT_P1_SYNTHESIZED", flush=True)
            break
    else:
        payload = {"status": "round_limit", "rounds": rounds,
                   "elapsed_s": time.time() - started}

    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps({"status": payload["status"],
                      "elapsed_s": payload["elapsed_s"]}, sort_keys=True))
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=120)
    parser.add_argument("--timeout-ms", type=int, default=300000)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--core-audit", action="store_true")
    parser.add_argument("--core-case", choices=(
        "full", "without_cubic", "without_token_pm", "without_distinct",
        "without_all_a5", "without_all_d0", "without_all_d1",
        *(f"without_row_{row}" for row in range(5)),
        *(f"without_d1_row_{row}" for row in range(5)),
        "only_all_a5", "only_row_0", "only_a5_row_0",
    ))
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    if args.core_audit:
        audit_assumption_core(args.n, args.core_case)
    else:
        run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
