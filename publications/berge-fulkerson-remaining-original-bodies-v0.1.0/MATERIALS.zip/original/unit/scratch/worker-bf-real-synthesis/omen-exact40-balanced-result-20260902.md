# Balanced two-edge blocker: common-incidence synthesis pulse

## Target

This pulse tests the narrow branch (P_{\mathrm{balanced}}): one common
simple cubic 5-pole carries direct six-perfect-matching witnesses for all 40
Case-XII positive types, while a single shared pair (B) of proper edges is a
balanced Farkas blocker.  The complete perfect-matching family is required to
satisfy

\[
 |P\cap B|=1\quad(P\in\mathcal P_i,\ i=1,\ldots,5),
 \qquad |Q\cap B|=0\quad(Q\in\mathcal Q_{ij},\ ij\in\binom{[5]}2).
\]

The target additionally asks for exact singleton Tait set (S), no
(A=(12345)) cover, and empty D5 four-cell joins.  The graph and all
positive six-matching vectors are shared; this is not a private witness or
load-only model.  Violating PMs in the complete closure are blocked with a
clause containing both the selected (B)-edges and the PM's graph edges.

Source: `synthesize_exact40_balanced.py` (SHA-256
`ff528642a3229b9d1ca66fa7f229496a7d6dc7da8014f15527e9c2eedb30e8b8`).

## Omen order 13

```text
python3 -u synthesize_exact40_balanced.py --n 13 --max-rounds 8 \
  --timeout-ms 60000 --json result_n13.json
```

Status: `round_limit`, 8 rounds, 37.40 s.  The first seven models had a
complete-family balanced blocker, no A-cover, all five D5 joins empty, but
support size 54--55 and 9--10 Tait states.  The eighth model had five
complete-family blocker violations.  No exact-40 model was returned.

JSON SHA-256: `ae51576598d2fcdcd19f1d49c574f749008deb010d5f4b8dd154496e5711fafd`.
Log SHA-256: `725cd464211e0d34b57f016a9372ea8a8867f14c1ac87d17c1f2e8a8276307b8`.

## Omen order 15

```text
python3 -u synthesize_exact40_balanced.py --n 15 --max-rounds 4 \
  --timeout-ms 60000 --json result_n15.json
```

The first model (51 PMs) had (B=\{(0,10),(1,14)\}), complete-family
balanced blocker, support 55, all ten Tait states, no A-cover, and all D5
joins empty.  The second Z3 query returned `unknown` after the 60 s solver
limit; total wall time was 78.85 s.  No exact-40 model or UNSAT certificate
was obtained.

JSON SHA-256: `2f3a2afe5fbd3f3c6919faa62700d1bad4d8c2c1ac8d15d1ebaf0b2eb604f723`.
Log SHA-256: `c6c4dacb6218ecc5b4812a6af7857ecc42913e8b24d37884352dbb6edd7606e4`.

## Four-value decision

* Real exact-40/no-A/join-free balanced pole: **not found**.
* Strict UNSAT or general proof: **not obtained**.
* Exact status: **bounded unresolved** (order 13 round limit; order 15
  solver unknown).  The pulse does establish a genuine near-miss boundary:
  complete common PM incidence can realize a balanced two-edge blocker,
  no-A, and empty joins while extra support/Tait states remain.

The data do not justify an order increase or an all-order conclusion.  Any
future target model still requires an independent complete PM verifier.

## Omen order-13 rerun (2026-09-02b)

To distinguish a short CEGAR truncation from a persistent local boundary, the
same common-incidence encoding was run once more at the single minimum order
with twelve rounds (60 s solver limit per round), in detached tmux session
`d5_balanced_n13_20260902b` on Omen.  The run ended at the prescribed round
limit after 46.46 s; no order-15 or auxiliary pulse was started.

All twelve returned graphs had nine or ten singleton Tait states and support
size 54 or 55; none had an (A)-cover and every D5 join flag was false.  The
complete-family balanced blocker held in 11/12 rounds (one model had five
blocker violations and was excluded).  Thus no exact-40 balanced pole was
found, and the run is **bounded unresolved**, not UNSAT.  The first-round
model was independently checked by the pure-standard-library verifier:

```text
pm=36, support=55, tait_states=10, has_A=False,
joins=[False, False, False, False, False], balanced_violations=0,
blocker=[(4,6),(6,12)]
BALANCED_PULSE_NEARMISS_VERIFIED
```

The preserved Omen artifacts are `omen-exact40-balanced-n13-20260902b.json`
and `.log`; their SHA-256 hashes are respectively
`4dcfaef30bb18f35e64e4d92eaf491f6e9f255d86130daca7a17c86a53224a41` and
`03c46ef250d50735a7e2514a5b708c120f0c9d0e00886b653a4ef672aa1fa1ef`.

## Independent near-miss check

The first model in each JSON was independently re-evaluated by the pure
standard-library checker
`verify_balanced_pulse_nearmiss.py` (SHA-256
`60e7264217c2c8f3544f9a4c12ac3a6000d6e3494097ea1a88c0a3f5018037e4`):

```text
python3 units/berge-fulkerson/scratch/worker-bf-real-synthesis/verify_balanced_pulse_nearmiss.py \
  units/berge-fulkerson/scratch/worker-bf-real-synthesis/omen-exact40-balanced-n13-20260902.json \
  units/berge-fulkerson/scratch/worker-bf-real-synthesis/omen-exact40-balanced-n15-20260902.json \
  units/berge-fulkerson/scratch/worker-bf-real-synthesis/omen-exact40-balanced-n13-20260902b.json
```

It ends with `BALANCED_PULSE_NEARMISS_VERIFIED` and reproduces, for both
models, 55 support types, all ten Tait states, no A-cover, empty joins, and
zero complete-family blocker violations.
