# Omen K=1 shared-pool boundary (2026-09-01)

## Decision target

Test the deliberately stronger condition that every singleton and triple
boundary class has exactly one common perfect-matching slot, while retaining
the 40 positive Case-XII support equations.  The complete evaluator would
also reject extra support, an `(A)` cover, and D5 joins.

This is an additional `K=1` condition, not the unrestricted Case-XII
problem.  A model would have been a genuine pole; UNSAT only closes this
stronger shared-pool route.

## Omen run

The byte-for-byte sources were:

```text
synthesize_exact40_shared_pool.py       5e5d89d21829eacbde35b654c677648196c54a5b3525b7e840c520d5e969f9d5
synthesize_exact40_joint_pb.py          aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

Command on Omen:

```text
python3 -u synthesize_exact40_shared_pool.py --n 13 --pool-size 1 \\
  --max-rounds 30 --timeout-ms 120000 --json case_xii_shared_k1_n13.json
```

The solver returned `unsat` before the first CEGAR round in 0.5526635647 s.
The JSON digest is
`981e692d7fad37fbf2924b17ccbed33ce58353b5a2166f0cbfebacaa21235dc9`.

## Analytic reason for the boundary

Let `P_i` be the unique singleton matching in class `i` and `Q_s` the unique
triple matching for an `S` pair `s={i,j}`.  The positive S-loop equation is

```text
chi(Q_s) + chi(P_i) + chi(P_j) = 1
```

on every proper edge, so these three matchings form a Tait colouring.  Let
`t={k,l}` be the unique T pair disjoint from `s`.  The positive D5 S--T
equation subtracts the S-loop equation and gives

```text
chi(Q_t) + chi(P_k) + chi(P_l) = 1.
```

Thus the same K=1 assumptions force the forbidden T-loop `[t]`.  Every T
pair is disjoint from one S pair, so the contradiction is immediate.  This
explains the Omen UNSAT without relying on a graph search.

## Four-value status

* unrestricted Case-XII: unresolved;
* real counterexample: none;
* sharp additional condition: `K=1` shared boundary fibres are impossible;
* route status: close the K=1 route and do not increase its order/rounds.

