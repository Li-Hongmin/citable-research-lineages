#!/usr/bin/env python3
"""Small semantic and n=13 smoke check for the exact-S Tait gate."""

from __future__ import annotations

import importlib.util
import io
from contextlib import redirect_stdout
from pathlib import Path


HERE = Path(__file__).resolve().parent


def load(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    if spec is None or spec.loader is None:
        raise RuntimeError(filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


BASE = load("exact_s_gate_base", "synthesize_exact40_joint_pb.py")
BLOCKED = load("exact_s_gate_blocked", "synthesize_exact40_tait_blocked.py")


def check_five_cycle_semantics():
    # A labelled C5 whose proper edges are S has exactly the five target
    # boundary states; the complementary labelled C5 has exactly T.
    result_s = BASE.evaluate(5, tuple(sorted(BASE.S)))
    result_t = BASE.evaluate(5, tuple(sorted(BASE.T)))
    assert result_s["tait_states"] == BASE.S
    assert result_t["tait_states"] == BASE.T

    # The companion must generate blockers only for states explicitly passed
    # to it.  In particular target S states are not accidentally made bad.
    assert not BLOCKED.tait_pair_unions(
        result_s["tait_witnesses"], tuple(sorted(BASE.S)), set()
    )
    blockers = BLOCKED.tait_pair_unions(
        result_t["tait_witnesses"], tuple(sorted(BASE.T)), BASE.T
    )
    assert {state for state, _ in blockers} == BASE.T
    assert all(union for _, union in blockers)


def check_n13_positive_encoding():
    with redirect_stdout(io.StringIO()):
        payload = BLOCKED.run(13, max_rounds=1, timeout_ms=5000,
                              out_path=None)
    assert payload["status"] == "round_limit"
    record = payload["rounds"][0]
    states = {tuple(state) for state in record["certificate"]["tait_states"]}
    assert BASE.S <= states <= set(BASE.PAIR_SET)
    reports = [bad for bad in record["bad"] if bad["kind"] == "extra_tait"]
    extra = states - BASE.S
    assert bool(reports) == bool(extra)
    if reports:
        assert {tuple(state) for state in reports[0]["states"]} == extra


if __name__ == "__main__":
    check_five_cycle_semantics()
    check_n13_positive_encoding()
    print("EXACT_S_TAIT_GATE_SMOKE_OK")
