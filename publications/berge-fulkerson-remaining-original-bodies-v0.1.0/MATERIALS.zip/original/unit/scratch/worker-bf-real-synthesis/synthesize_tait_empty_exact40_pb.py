#!/usr/bin/env python3
"""Tait-empty exact-40 synthesis pulse.

This is a deliberately narrow wrapper around ``synthesize_exact40_joint_pb``.
In addition to the common six-perfect-matching incidence equations, every
singleton matching vector selected for the 40 positive Case-XII witnesses is
required to intersect every selected singleton vector from a different
terminal class on at least one proper edge.  A genuine Tait-empty pole has
this property for *all* singleton perfect matchings, so the constraint is a
sound necessary condition for that branch.  It is not claimed sufficient:
the evaluator still discovers unrepresented perfect matchings and lazily
blocks any extra support, A-cover, T-loop/T--T type, or D5 join.

The run is a bounded SAT/CEGAR experiment.  ``round_limit`` or ``unknown``
is an encoding boundary, never an UNSAT proof.
"""

from __future__ import annotations

import importlib.util
from itertools import combinations
from pathlib import Path

from z3 import And, Or


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_joint_pb_base_tait_empty", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
BASE_BUILD_SOLVER = BASE.build_solver


def build_solver(n: int):
    solver, x, edges, witness_vars = BASE_BUILD_SOLVER(n)

    # Collect selected singleton vectors by their terminal class.  The full
    # condition for a Tait-empty pole would compare *all* such slots, but that
    # creates a very large SAT encoding.  We use one deterministic canonical
    # slot per class: pairwise intersection of these five actual PMs is still
    # a sound necessary condition, and gives a cheap first discriminator.
    by_terminal = {i: [] for i in BASE.TERMINALS}
    for (kind, slot), y in witness_vars.items():
        boundary = BASE.slots_for_type(kind)[slot]
        if len(boundary) == 1:
            terminal = next(iter(boundary))
            by_terminal[terminal].append(y)

    # Two singleton PMs with distinct semiedge terminals are disjoint iff
    # their proper-edge supports are disjoint.  Tait-empty therefore implies
    # that at least one proper edge is selected by each pair.  Use a compact
    # disjunction of conjunctions; all y variables are already constrained to
    # be subedges of the common graph x.
    if any(not slots for slots in by_terminal.values()):
        raise RuntimeError("missing canonical singleton slot")
    canonical = {terminal: slots[0] for terminal, slots in by_terminal.items()}
    for left, right in combinations(BASE.TERMINALS, 2):
        y_left = canonical[left]
        y_right = canonical[right]
        solver.add(Or(*(And(y_left[e], y_right[e]) for e in edges)))

    return solver, x, edges, witness_vars


BASE.build_solver = build_solver


if __name__ == "__main__":
    BASE.main()
