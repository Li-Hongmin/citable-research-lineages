#!/usr/bin/env python3
"""Bounded synthesis for an exact-S, no-A cubic five-pole.

The target is deliberately narrower than Case XII: one common simple cubic
five-pole must realize the five singleton-pair Tait states

    S = {(0,2),(0,3),(1,3),(1,4),(2,4)}

and must have no other Tait state and no all-terminal (A=(12345)) BF cover.
For each state in S the three colour classes are encoded as actual perfect
matchings of the same graph, with proper-edge load exactly one.  The evaluator
enumerates the complete matching family and lazily blocks extra Tait states,
disconnected/bridged graphs, and A-covers.  A target model is therefore a
genuine exact-S/no-A pole, but a round limit is only an unresolved bounded
result.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import combinations
from pathlib import Path

from z3 import Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_base_for_exact_s", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

TERMINALS = BASE.TERMINALS
S_STATES = tuple(sorted(BASE.S))


def build_solver(n: int):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(PbEq([(value, 1) for value in incident], target))

    # Remove one harmless vertex-label symmetry, as in the exact-40 driver.
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    tait_vars = {}
    for si, state in enumerate(S_STATES):
        boundaries = (
            frozenset((state[0],)),
            frozenset((state[1],)),
            frozenset(set(TERMINALS) - set(state)),
        )
        colour_slots = []
        for ci, boundary in enumerate(boundaries):
            y = {edge: Bool(f"t_{si}_{ci}_{edge[0]}_{edge[1]}")
                 for edge in edges}
            colour_slots.append(y)
            for edge in edges:
                solver.add(Or(Not(y[edge]), x[edge]))
            for v in range(n):
                terms = [(y[e], 1) for e in edges if v in e]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))
        for edge in edges:
            # The three colour classes partition every present proper edge;
            # y -> x already forces absent edges to have load zero.
            terms = [(colour_slots[ci][edge], 1) for ci in range(3)]
            solver.add(PbLe(terms, 1))
            solver.add(Or(Not(x[edge]), PbEq(terms, 1)))
        tait_vars[state] = colour_slots

    return solver, x, edges, tait_vars


def tait_states(n: int, proper_edges):
    """Enumerate all concrete singleton-pair Tait states of one pole."""
    matchings, classes = BASE.matching_classes(n, proper_edges)
    matching_set = {frozenset(matching) for matching in matchings}
    edge_count = len(proper_edges)
    all_objects = set(range(edge_count + len(TERMINALS)))
    states = set()
    for first, second in combinations(TERMINALS, 2):
        first_family = classes.get(frozenset((first,)), ())
        second_family = classes.get(frozenset((second,)), ())
        for left in first_family:
            left_set = set(left)
            for right in second_family:
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    states.add((first, second))
    return tuple(sorted(states)), matchings, classes


def graph_certificate(n: int, proper_edges, states, matchings, result):
    return {
        "n": n,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(matchings),
        "class_sizes": {str(sorted(k)): len(v)
                        for k, v in sorted(result.items(), key=str)},
        "tait_states": [list(state) for state in states],
        "tait_state_count": len(states),
        "has_A": result.get("a_witness") is not None,
    }


def evaluate(n: int, proper_edges):
    states, matchings, classes = tait_states(n, proper_edges)
    a_witness = BASE.find_a_cover(classes, len(proper_edges))
    return {
        "states": states,
        "matchings": matchings,
        "classes": classes,
        "a_witness": a_witness,
    }


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, _ = build_solver(n)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT_S_NO_A_SYNTHESIS_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT_S_NO_A_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var,
                                                       model_completion=True))))
        result = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge)})

        extra_states = set(result["states"]) - set(S_STATES)
        if extra_states:
            # Block this concrete graph; its extra states are recomputed from
            # the complete matching family, not from the encoded witnesses.
            solver.add(BASE.clause_for_union(x, edges, frozenset(proper_edges)))
            bad.append({"kind": "extra_tait", "states": [list(s) for s in sorted(extra_states)]})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, result["states"],
                                result["matchings"], result["classes"])
        cert["has_A"] = result["a_witness"] is not None
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if not bad and set(result["states"]) == set(S_STATES) and result["a_witness"] is None:
            payload = {"status": "real_exact_s_no_a", "rounds": rounds,
                       "certificate": cert, "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACT_S_NO_A_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("EXACT_S_NO_A_SYNTHESIS_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=15)
    parser.add_argument("--max-rounds", type=int, default=80)
    parser.add_argument("--timeout-ms", type=int, default=300000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
