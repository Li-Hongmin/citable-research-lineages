# The Note-058 binary transport pattern fails at orders 13 and 15

## Exact tested statement

Use ten shared singleton perfect matchings (P_i^0,P_i^1), (i\in[5]).
For each of the five cyclic rows in Note 058, require one actual A5
six-perfect-matching double cover with the two repeated-(i) matchings and
the two prescribed fixed-coordinate tokens.  Also require the two actual D5
double covers furnished by Note 057, with transported pairs

\[
(P_i^0,P_{i-1}^0),\qquad (P_i^1,P_{i-1}^1).
\]

All matching vectors live on one common simple cubic 5-pole.  The encoding
allows arbitrary additional perfect matchings and additional completions;
it does not assert that a row has only one witness or that a singleton class
has only two perfect matchings.

## Fixed-order decision

The common graph/perfect-matching PB formula is UNSAT for both (n=13) and
(n=15).  These answers occur before complete-family evaluation, so the
no-A, no-T-loop, no-T--T, connectedness, and D5-join lazy gates are never
invoked.  Thus the exact Note-058 binary transport realization cannot be a
P1 witness at either tested order.

This is not an UNSAT result for general P1.  In particular, it does not
exclude five A5 covers and empty joins with larger or non-binary singleton
fibres, different transported token identifications, or another order.

## Deletion boundary at (n=13)

The following grouped deletions distinguish the source of UNSAT.

| retained/removed condition | result |
|---|---:|
| full positive binary transport formula | UNSAT |
| remove explicit cubic degree equations | UNSAT |
| allow (P_i^0=P_i^1) | UNSAT |
| remove all bit-1 transported D5 covers | UNSAT |
| remove all bit-0 transported D5 covers | UNSAT |
| remove row 0 entirely | UNSAT |
| retain all five A5 covers but no transported D5 covers | SAT |
| retain only row 0, including both transported covers | SAT |
| retain only the row-0 A5 cover | SAT |
| remove actual-PM constraints on the ten tokens | UNKNOWN after 30 s |
| remove all A5 covers while retaining transports | UNKNOWN after 30 s |

Therefore the contradiction is not caused by token distinctness, by asking
for both transported points, or by separately imposed graph degrees.  It
appears only when several rows share actual perfect-matching incidences and
the A5 witnesses are tied to at least one transported D5 branch.  The two
UNKNOWN relaxations are not mathematical conclusions.

## Reproduction

Source:

```text
units/berge-fulkerson/scratch/worker-bf-real-synthesis/synthesize_binary_conflict_p1.py
SHA-256 c9ad3f91819b8289cf6eb40dd1a0a228a958b263d020e0c1be811f5a67c1ea3f
```

Omen directory:

```text
[local archival reference]
```

The fixed-order positive queries were:

```text
python3 synthesize_binary_conflict_p1.py --n 13 --max-rounds 1 --timeout-ms 30000
python3 synthesize_binary_conflict_p1.py --n 15 --max-rounds 1 --timeout-ms 300000
```

They returned UNSAT in 0.11 s and 0.15 s respectively.  No remote process
was left running.
