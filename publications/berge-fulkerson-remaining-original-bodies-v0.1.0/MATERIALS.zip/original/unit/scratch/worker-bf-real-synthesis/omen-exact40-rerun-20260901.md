# Omen fixed-order exact-40 common-incidence pulse

This directory records one bounded (n=13) CEGAR run.  The target is a
single simple connected cubic five-pole whose common perfect-matching
incidence realizes exactly the 40 Case-XII types, with no (A)-cover, no
(T)-loop or (T)--(T) type, and no D5 four-cell join.

The baseline source is `synthesize_exact40_joint.py` (SHA-256 recorded on
the Omen host).  The pulse uses the minimal batch-lazy variant
`synthesize_exact40_joint_batch.py`, which changes only CEGAR bookkeeping:
all extra types and all currently witnessed D5 joins are blocked in one
round.  The six-vector common-PM constraints and graph constraints are
unchanged.  `verify_first_model_independent.py` is a pure-stdlib verifier for
the previously observed 34-PM model and is copied unchanged for comparison;
if a new model is returned, a new pure-stdlib verifier is required before any
claim of realization.

Scope: fixed internal order (n=13), fixed five terminal labels 0--4;
no order-15 or higher search, random search, or abstract load model.

The authoritative run command is:

```text
python3 -u synthesize_exact40_joint_batch.py --n 13 --max-rounds 20 --timeout-ms 600000 --json exact40_batch.json
```

The raw output is `exact40_batch.log`; source hashes and the final status are
recorded on the same Omen host.  A timeout/`unknown` is not an UNSAT result.
