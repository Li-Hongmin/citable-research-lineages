# Omen canonical-singleton Tait-empty pulse (2026-09-01)

## Decision target

Test the cheapest necessary incidence condition for a Tait-empty exact-40
Case-XII pole: one canonical singleton PM from each of the five terminal
classes must pairwise intersect on a proper edge.  The wrapper adds these ten
intersection clauses to the common cubic five-pole / six-PM encoding.  The
condition is necessary, not sufficient, because the other singleton PMs and
the full perfect-matching closure are checked only by the evaluator.

## Reproduction

Omen host: `omen`; directory:
`[local archival reference]`.

```text
python3 -u synthesize_tait_empty_exact40_pb.py --n 13 --max-rounds 30 \
  --timeout-ms 300000 --json tait_empty_exact40_n13_canonical.json
```

Wrapper SHA-256:
`d695c2c41d7194a2632ead9b650751cb8080a3dc09b3b1b1d149bb9f9a226f7a`.
Base SHA-256:
`aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804`.

## Result

The run finished in 26.08 s with
`SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY` after 30 SAT rounds.  It did
not return an exact-40 model and did not obtain an UNSAT certificate.  The
evaluated supports had sizes 52 (4 rounds), 53 (1), 54 (2), and 55 (23);
22 rounds had an `(A)` cover and 8 did not.  Fourteen concrete D5 joins were
found and lazily blocked.  No round satisfied the target exact-40/no-A/no-
join conditions.

The canonical five intersection clauses therefore do not distinguish the
Tait-empty branch at this order.  This is only a bounded encoding boundary;
it is neither a proof of impossibility nor a real counterexample.  The full
all-singleton version was abandoned after a four-minute construction with no
first model, as it was materially less efficient and added no decision value.
