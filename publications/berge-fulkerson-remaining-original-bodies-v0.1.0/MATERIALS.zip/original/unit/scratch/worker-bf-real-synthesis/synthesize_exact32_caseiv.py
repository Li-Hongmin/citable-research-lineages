#!/usr/bin/env python3
"""Bounded shared-incidence synthesis pulse for MMT Case IV.

This is a thin wrapper around ``synthesize_exact40_joint_pb.py``.  The
underlying encoding keeps one simple cubic five-pole and common matching
vectors for every positive type, while lazily blocking complete-support
violations.  Here the positive target is the exact 32-type MMT Case-IV set:
20 S--T types with T=45 deleted, nine off-diagonal S--S types, and the three
S loops [13],[24],[25].  A round limit is unknown, never an UNSAT claim.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact32_caseiv_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

# Exact MMT Case IV support, in the same shifted terminal labels as BASE.
IV_S_LOOPS = {((0, 2), (0, 2)), ((1, 3), (1, 3)), ((1, 4), (1, 4))}
IV_SS = {
    tuple(sorted((a, b)))
    for a in BASE.S
    for b in BASE.S
    if a < b and tuple(sorted((a, b))) != ((0, 3), (2, 4))
}
IV_ST = {
    tuple(sorted((s, t)))
    for s in BASE.S
    for t in BASE.T
    if t != (3, 4)
}
TARGET_TYPES = tuple(sorted(IV_S_LOOPS | IV_SS | IV_ST))
ALL_TYPES = tuple(__import__("itertools").combinations_with_replacement(BASE.PAIR_SET, 2))
FORBIDDEN_TYPES = tuple(kind for kind in ALL_TYPES if kind not in set(TARGET_TYPES))

BASE.TARGET_TYPES = TARGET_TYPES
BASE.ALL_TYPES = ALL_TYPES
BASE.FORBIDDEN_TYPES = FORBIDDEN_TYPES
BASE.D5 = tuple(sorted((s, t) for s, t in IV_ST if set(s).isdisjoint(t)))


def graph_certificate(n, proper_edges, result):
    return {
        "n": n,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "class_sizes": {str(sorted(k)): len(v)
                        for k, v in sorted(result["classes"].items(), key=str)},
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "target_support": result["support"] == frozenset(TARGET_TYPES),
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
    }


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, _ = BASE.build_solver(n)
    target_set = set(TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if str(status) == "unknown":
            rounds.append({"round": round_no, "status": "unknown"})
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
            return payload
        if str(status) != "sat":
            rounds.append({"round": round_no, "status": "unsat"})
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var, model_completion=True))))
        result = BASE.evaluate(n, proper_edges)
        bad = []
        if len(BASE.connected_components(n, proper_edges)) != 1:
            comps = BASE.connected_components(n, proper_edges)
            side = min(comps, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(BASE.Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side),
                        "crossing_count": len(crossing)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge and
                                     ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(BASE.Or([x[e] for e in crossing]))
                else:
                    solver.add(BASE.Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge),
                            "side": sorted(side)})
        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})
        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})
        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, result)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))
        if not bad and result["support"] == frozenset(TARGET_TYPES) \
                and result["a_witness"] is None and not any(result["joins"]):
            payload = {"status": "real_exact32_joinfree", "rounds": rounds,
                       "certificate": cert, "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
            print("REAL_EXACT32_CASEIV_D5_JOINFREE_SYNTHESIZED")
            return payload
    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("CASEIV_SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=80)
    parser.add_argument("--timeout-ms", type=int, default=120000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
