# Case-IV real-pole probe (2026-09-02)

## Scope

This is a bounded probe only for a simple connected cubic 5-pole of order
`n=13` whose *complete* perfect-matching closure has exactly the 32 MMT
Case-IV support types (three S-loops, nine S--S off-diagonal types, and the
20 S--T types with the `(45)` column deleted), with no `A`, no T-loops or
T--T types, and no D5 four-cell join.

The synthesis encoding uses one common graph and matching-incidence vectors
for all positive target cells; forbidden support, A, connectivity/bridge,
and D5-join clauses are added from complete matching enumeration. Therefore
an accepted model would be a genuine shared-incidence pole, not an abstract
support model.

## Omen short rerun

Remote directory:

```text
[local archival reference]
```

Command:

```text
python3 -u synthesize_exact32_caseiv.py --n 13 --max-rounds 8 \
  --timeout-ms 30000 --json exact32_caseiv_n13_short_20260902.json
```

JSON SHA-256:

```text
77ce151b09e45ef23e291ecc32ecbc8526e5c9f76d72d8a12d518a9fcf2832d4
```

The process exited normally (`EXIT:0`) with
`CASEIV_SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY`.

Across the eight SAT rounds:

* support sizes: `55,45,52,55,55,55,45,55`;
* exact 32 target hits: `0`;
* no-A candidates: `3`;
* empty D5-join flags: `4`.

The run is therefore **bounded-unresolved**. It is neither an exact-32
real pole nor an UNSAT certificate. Together with the earlier 100-round
run, it gives only a finite synthesis boundary; it does not decide Case IV.

## Decision

Stop this branch at the bounded-unresolved boundary. Do not infer a
Case-IV theorem or a Berge--Fulkerson counterexample from these runs.
Any future decisive step must strengthen the shared perfect-matching
incidence encoding or produce a direct analytic obstruction.
