# Omen exact-S + full S--T support pulse (2026-09-01)

## Decision target

Test one narrow branch of the real-incidence problem at order 15: a common
simple cubic 5-pole must carry all five Tait states

\[
S=\{13,14,24,25,35\},
\]

and direct six-perfect-matching witnesses for all 25 S--T types.  The
complete evaluator then blocks extra Tait states, an A-cover, every BF type
outside the 40 Case-XII types, bridges/disconnection, and concrete D5 joins.

This is a bounded CEGAR synthesis.  A returned target would be a real
exact-S/full-S--T/no-A pole (and, if no forbidden type survived, a genuine
Case-XII pole).  A round limit is not UNSAT.

## Omen run

Remote directory:

```text
[local archival reference]
```

Command:

```text
python3 -u synthesize_exact_s_st_no_a.py --n 15 --max-rounds 12 \\
  --timeout-ms 180000 --json exact_s_st_no_a_n15.json
```

Source hashes:

```text
synthesize_exact_s_st_no_a.py       d5558af0cf384429ee55a5306f291462889a6465fed30842634152ed317797be
synthesize_exact40_joint_pb.py      aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

## Result

The run used 12 satisfiable rounds and ended with
`EXACT_S_ST_NO_A_ROUND_LIMIT` after 17.75 seconds.  No UNSAT certificate and
no target model were obtained.  Every round had all 25 S--T types (by direct
construction), but the complete evaluator found extra Tait states and an
A-cover.  The support sizes were 53--55; the first five rounds had all ten
Tait states, and the remaining rounds had nine or ten.  No round reached the
exact-S/no-A gate.

The pulse therefore supplies a finite boundary only: adding all 25 S--T
witnesses to the exact-S synthesis object did not produce an exact-S/no-A
candidate in this 12-round order-15 search.  It neither proves the exact-S
bridge nor decides the full Case-XII proposition, and does not authorize
increasing the order or round count without a new encoding.

Raw artifacts copied locally:

* `omen-exact-s-st-no-a-n15-20260901.json`
* `omen-exact-s-st-no-a-n15-20260901.log`

