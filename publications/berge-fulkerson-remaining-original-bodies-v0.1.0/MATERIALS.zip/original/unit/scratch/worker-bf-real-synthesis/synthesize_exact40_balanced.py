#!/usr/bin/env python3
"""Bounded real-incidence synthesis for the balanced two-edge blocker branch.

The base object carries six perfect-matching incidence vectors for every one
of the forty Case-XII positive types on a single cubic five-pole.  This pulse
adds a *shared, selected* pair B of proper graph edges.  Every encoded
singleton slot must use exactly one B-edge and every encoded triple slot must
use none.  After a model is obtained, the complete matching family is
enumerated and the same condition is checked for every singleton and triple
class; violating concrete matchings are excluded with graph+B clauses.

The target remains deliberately narrow: exact forty support, no extra Tait
states, no A-cover, and no D5 join.  ``unknown`` and round limits are finite
encoding boundaries, never UNSAT claims.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import combinations
from pathlib import Path

from z3 import And, Bool, Not, Or, PbEq, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_balanced_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)


def build_solver(n: int):
    solver, x, edges, witness_vars = BASE.build_solver(n)
    # A is a selected unordered pair of potential proper edges.  The selector
    # is shared by all forty witness families, so this is not a private
    # blocker per completion.
    b = {edge: Bool(f"bal_b_{edge[0]}_{edge[1]}") for edge in edges}
    solver.add(PbEq([(b[edge], 1) for edge in edges], 2))
    for edge in edges:
        solver.add(Or(Not(b[edge]), x[edge]))

    # Linearise z = b AND y for each encoded PM slot.  Singleton boundary
    # slots must have B-load one; triple boundary slots must have B-load zero.
    for kind in BASE.TARGET_TYPES:
        boundaries = BASE.slots_for_type(kind)
        for si, boundary in enumerate(boundaries):
            y = witness_vars[(kind, si)]
            z = {
                edge: Bool(f"bal_z_{kind}_{si}_{edge[0]}_{edge[1]}")
                for edge in edges
            }
            for edge in edges:
                # z <-> (b & y)
                solver.add(Or(Not(z[edge]), b[edge]))
                solver.add(Or(Not(z[edge]), y[edge]))
                solver.add(Or(Not(b[edge]), Not(y[edge]), z[edge]))
            target = 1 if len(boundary) == 1 else 0
            solver.add(PbEq([(z[edge], 1) for edge in edges], target))
    return solver, x, edges, b


def selected_edges(model, variables):
    return tuple(sorted(edge for edge, var in variables.items()
                        if bool(model.eval(var, model_completion=True))))


def matching_weight(matching, blocker, proper_edges):
    edge_count = len(proper_edges)
    return sum(proper_edges[index] in blocker
               for index in matching if index < edge_count)


def blocker_violations(result, blocker, proper_edges):
    """Return all concrete PMs violating the balanced blocker identity."""
    rows = []
    classes = result["classes"]
    # Every singleton class must use exactly one selected B edge.
    for i in BASE.TERMINALS:
        for matching in classes.get(frozenset((i,)), ()):
            weight = matching_weight(matching, blocker, proper_edges)
            if weight != 1:
                rows.append(("singleton", (i,), matching, weight))
    # Every triple-boundary class (equivalently every pair label) must avoid B.
    for pair in BASE.PAIR_SET:
        boundary = BASE.boundary_for_pair(pair)
        for matching in classes.get(boundary, ()):
            weight = matching_weight(matching, blocker, proper_edges)
            if weight != 0:
                rows.append(("triple", pair, matching, weight))
    return tuple(rows)


def blocker_clause(solver, x, b, edges, blocker, matching, proper_edges):
    """Exclude (selected B, graph containing matching) from future models."""
    terms = [Not(b[edge]) for edge in blocker]
    edge_count = len(proper_edges)
    terms.extend(Not(x[proper_edges[index]]) for index in matching
                 if index < edge_count)
    if not terms:
        raise RuntimeError("empty balanced-blocker clause")
    solver.add(Or(terms))


def graph_certificate(n, proper_edges, result, blocker, violations, tait_pairs):
    return {
        "n": n,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "class_sizes": {
            str(sorted(k)): len(v)
            for k, v in sorted(result["classes"].items(), key=str)
        },
        "selected_blocker": [list(e) for e in blocker],
        "balanced_complete_family": not violations,
        "balanced_violation_count": len(violations),
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "tait_states": [list(s) for s in sorted(result["tait_states"])],
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
        "balanced_blocker_clauses": len(tait_pairs),
    }


def evaluate(n, proper_edges):
    result = BASE.evaluate(n, proper_edges)
    # Enumerate exact singleton-pair Tait states for reporting and exact-S
    # gating.  This uses the same complete matching closure as BASE.evaluate.
    matching_set = {frozenset(m) for m in result["matchings"]}
    edge_count = len(proper_edges)
    all_objects = set(range(edge_count + len(BASE.TERMINALS)))
    states = set()
    for i, j in combinations(BASE.TERMINALS, 2):
        for left in result["classes"].get(frozenset((i,)), ()):
            left_set = set(left)
            for right in result["classes"].get(frozenset((j,)), ()):
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    states.add((i, j))
                    break
            if (i, j) in states:
                break
    result["tait_states"] = tuple(sorted(states))
    return result


def all_unwanted_tait_pair_unions(classes, proper_edges):
    """Concrete clauses needed to remove every current T-state pair."""
    out = []
    edge_count = len(proper_edges)
    for state in sorted(BASE.T):
        i, j = state
        left_family = classes.get(frozenset((i,)), ())
        right_family = classes.get(frozenset((j,)), ())
        for left in left_family:
            lp = {edge for edge in left if edge < edge_count}
            for right in right_family:
                rp = {edge for edge in right if edge < edge_count}
                if lp & rp:
                    continue
                union = frozenset(proper_edges[k] for k in lp | rp)
                if union:
                    out.append((state, union))
    seen = set()
    unique = []
    for state, union in out:
        key = tuple(sorted(union))
        if key not in seen:
            seen.add(key)
            unique.append((state, union))
    return tuple(unique)


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, b = build_solver(n)
    target_set = set(BASE.TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT40_BALANCED_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT40_BALANCED_UNSAT")
            return payload

        model = solver.model()
        proper_edges = selected_edges(model, x)
        blocker = selected_edges(model, b)
        result = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge),
                            "side": sorted(side)})

        violations = blocker_violations(result, blocker, proper_edges)
        for _, _, matching, _ in violations:
            blocker_clause(solver, x, b, edges, blocker, matching, proper_edges)
        if violations:
            bad.append({"kind": "balanced_family_violation",
                        "count": len(violations),
                        "kinds": sorted({row[0] for row in violations})})

        tait_pairs = all_unwanted_tait_pair_unions(result["classes"], proper_edges)
        for _, union in tait_pairs:
            solver.add(BASE.clause_for_union(x, edges, union))
        if result["tait_states"]:
            bad.append({"kind": "extra_tait",
                        "states": [list(s) for s in result["tait_states"]],
                        "pair_clauses": len(tait_pairs)})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, result, blocker,
                                 violations, tait_pairs)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and not result["tait_states"]
                and result["a_witness"] is None
                and not any(result["joins"])
                and not violations):
            payload = {"status": "real_exact40_balanced_joinfree",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACT40_BALANCED_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("EXACT40_BALANCED_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=10)
    parser.add_argument("--timeout-ms", type=int, default=60000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    raise SystemExit(main())
