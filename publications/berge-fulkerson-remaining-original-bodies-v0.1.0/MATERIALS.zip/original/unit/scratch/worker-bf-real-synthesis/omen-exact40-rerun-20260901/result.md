# Fixed-order (n=13) exact-40 common-incidence CEGAR

## Decision

The bounded synthesis did **not** distinguish a real exact-40 pole from
infeasibility.  Its final status is `unknown`, caused by the Z3 timeout in
round 1.  This is neither an UNSAT certificate nor a real-pole result.

The first model (round 0) had 31 complete pole perfect matchings and all 55
ordinary boundary types.  It had an (A=(12345))-cover, so it was rejected by
the intended target.  The independent verifier for the previously frozen
34-PM model still passes; that model has all 55 types, no (A), and five empty
D5 joins, but has extra forbidden types and therefore is not exact-40.

## Omen run

Host directory:

```text
[local archival reference]
```

tmux session: `d5-exact40-batch-20260901`  
Command:

```text
python3 -u synthesize_exact40_joint_batch.py --n 13 --max-rounds 20 --timeout-ms 600000 --json exact40_batch.json
```

The run started at 2026-09-01T07:21:40+09:00 and ended after 600.69 s.  The
round-1 Z3 check returned `unknown`; no model JSON was produced.  The complete
raw log, command log, and `/usr/bin/time -v` statistics are retained in the
Omen directory and copied beside this file.

## Encoding change

`synthesize_exact40_joint_batch.py` differs from the baseline only by adding
all currently enumerated extra-type blockers and all currently enumerated D5
join blockers in each CEGAR round, instead of one of each.  The six matching
vectors remain proper-edge variables of the same graph and their exact
double-cover equations are unchanged.  A pseudo-Boolean variant
`synthesize_exact40_joint_pb.py` was compiled and its solver object built, but
was not run after the batch run returned `unknown` (the pulse was then
stopped, as required).

## Hashes

```text
de6a8e8f6c01714df01c600807675fb17176347993ed238c648cc86a0ff1df0a  synthesize_exact40_joint.py
fa435cfabcf502dacf0f938e5ce63c97a8422ae707f87d31c27570a4e9a5102c  synthesize_exact40_joint_batch.py
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804  synthesize_exact40_joint_pb.py
e8e580cb2507fa16febe485524b04e3fa52ec01d041c2ae3d8e3ad04e5c61d01  verify_first_model_independent.py
```

The pure-stdlib verifier ended with
`FIRST_SYNTHESIS_MODEL_INDEPENDENTLY_VERIFIED` (34 PMs, 55 ordinary types,
no A-cover, five empty D5 joins).  This verifies the retained reference model,
not the timed-out CEGAR query.

## Scope boundary

Only fixed order (n=13) was used.  No order-15-or-higher search, random
search, abstract load model, or permanent-note edit was performed.  The
decision value of this pulse is that the batch-lazy common-incidence encoding
remains computationally unresolved at this order; the bottleneck is the
round-1 Z3 query after 16 extra-type blockers were added, not the independent
pole evaluator.
