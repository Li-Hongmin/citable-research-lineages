#!/usr/bin/env python3
"""Pure-stdlib independent check of the first joint-synthesis model.

This verifier intentionally does not import the Z3 synthesis program or any
project matching routine.  It freezes the 17 proper edges printed by round 0,
recursively enumerates every pole perfect matching, recomputes all 55 BF
boundary types, the A-cover test, and the five D5 four-cell joins.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations, combinations_with_replacement, product


N = 13
TERMINALS = tuple(range(5))
EDGES = (
    (0, 7), (0, 11), (1, 5), (1, 7), (2, 9), (2, 10), (3, 8),
    (3, 11), (4, 8), (4, 10), (5, 6), (5, 9), (6, 7), (6, 12),
    (8, 9), (10, 12), (11, 12),
)
M = len(EDGES)
PAIR_SET = tuple(combinations(TERMINALS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(PAIR_SET) - set(S))
ALL_TYPES = tuple(combinations_with_replacement(PAIR_SET, 2))
D5 = tuple(sorted((s, t) for s in S for t in T if set(s).isdisjoint(t)))


def complement(pair):
    return frozenset(set(TERMINALS) - set(pair))


def matching_boundary(matching):
    return frozenset(edge - M for edge in matching if edge >= M)


def enumerate_pm():
    adj = {v: [] for v in range(N)}
    for i, (u, v) in enumerate(EDGES):
        adj[u].append((v, i))
        adj[v].append((u, i))
    used = [False] * N
    chosen = []
    out = []

    def rec():
        try:
            u = next(v for v in range(N) if not used[v])
        except StopIteration:
            out.append(tuple(sorted(chosen)))
            return
        used[u] = True
        if u in TERMINALS:
            chosen.append(M + u)
            rec()
            chosen.pop()
        for v, edge in adj[u]:
            if used[v]:
                continue
            used[v] = True
            chosen.append(edge)
            rec()
            chosen.pop()
            used[v] = False
        used[u] = False

    rec()
    return tuple(sorted(set(out)))


def load_cover(chosen):
    load = [0] * M
    for matching in chosen:
        for edge in matching:
            if edge < M:
                load[edge] += 1
                if load[edge] > 2:
                    return None
    return load


def find_cover(kind, classes):
    first, second = kind
    families = [classes[complement(first)], classes[complement(second)]]
    families += [classes[frozenset((i,))] for i in first + second]
    if any(not family for family in families):
        return None
    order = sorted(range(6), key=lambda i: len(families[i]))
    chosen = [None] * 6
    load = [0] * M

    def rec(k):
        if k == 6:
            return tuple(chosen)
        slot = order[k]
        for matching in families[slot]:
            if any(edge < M and load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                if edge < M:
                    load[edge] += 1
            chosen[slot] = matching
            result = rec(k + 1)
            if result is not None:
                return result
            for edge in matching:
                if edge < M:
                    load[edge] -= 1
        return None

    return rec(0)


def find_a(classes):
    families = [classes[frozenset((i,))] for i in TERMINALS]
    if any(not family for family in families):
        return None
    order = sorted(range(5), key=lambda i: len(families[i]))
    chosen = [None] * 5
    load = [0] * M

    def rec(k):
        if k == 5:
            return tuple(chosen)
        slot = order[k]
        for matching in families[slot]:
            if any(edge < M and load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                if edge < M:
                    load[edge] += 1
            chosen[slot] = matching
            result = rec(k + 1)
            if result is not None:
                return result
            for edge in matching:
                if edge < M:
                    load[edge] -= 1
        return None

    return rec(0)


def projection(cell, classes):
    first, second = cell
    singleton = [classes[frozenset((i,))] for i in TERMINALS]
    left = classes[complement(first)]
    right = classes[complement(second)]
    out = {}
    for tuple_pm in product(*singleton):
        load = [0] * M
        for position in first + second:
            for edge in tuple_pm[position]:
                if edge < M:
                    load[edge] += 1
        if max(load, default=0) > 2:
            continue
        for q in left:
            trial = load[:]
            if any(edge < M and trial[edge] >= 2 for edge in q):
                continue
            for edge in q:
                if edge < M:
                    trial[edge] += 1
            for r in right:
                if all(edge >= M or trial[edge] + (edge in r) == 2 for edge in range(M)):
                    out[tuple_pm] = (q, r)
                    break
            if tuple_pm in out:
                break
    return out


def main():
    matchings = enumerate_pm()
    classes = defaultdict(list)
    for matching in matchings:
        classes[matching_boundary(matching)].append(matching)
    for key in classes:
        classes[key].sort()
    support = {}
    witnesses = {}
    for kind in ALL_TYPES:
        witness = find_cover(kind, classes)
        if witness is not None:
            support[kind] = witness
    a = find_a(classes)
    projections = {cell: projection(cell, classes) for cell in D5}
    joins = []
    for omitted in D5:
        common = set.intersection(*(set(projections[c]) for c in D5 if c != omitted))
        joins.append(bool(common))
    target = set(combinations_with_replacement(sorted(S), 2)) | {
        tuple(sorted((s, t))) for s in S for t in T
    }
    print({
        "proper_edges": EDGES,
        "perfect_matchings": len(matchings),
        "class_sizes": {tuple(sorted(k)): len(v) for k, v in sorted(classes.items(), key=str)},
        "support": len(support),
        "target_support": sum(kind in target for kind in support),
        "has_A": a is not None,
        "d5_joins": joins,
    })
    assert len(matchings) == 34
    assert set(support) == set(ALL_TYPES)
    assert len(target & set(support)) == 40
    assert a is None
    assert joins == [False] * 5
    print("FIRST_SYNTHESIS_MODEL_INDEPENDENTLY_VERIFIED")


if __name__ == "__main__":
    main()
