# Exact-S Tait gate for the order-13 joint synthesis

## Implemented gate

The common-incidence PB model now forces every target state

\[
S=\{02,03,13,14,24\}
\]

directly.  For the target loop type \((s,s)\), its six matching slots are
constrained to be

\[
(Q,Q,P_i,P_j,P_i,P_j).
\]

Together with exact double load, the three distinct slots partition every
proper edge; their fixed semiedge boundaries partition the terminals.  They
therefore form a Tait colouring of state \(s=ij\).  Conversely, any graph
with state \(s\) can choose its doubled Tait colouring for this loop witness,
so this strengthening does not remove any exact-\(S\) graph.

For every returned candidate, the evaluator enumerates the complete perfect
matching family and all actual Tait colourings.  For each forbidden state in
\(T=\binom{[5]}2\setminus S\), it adds a graph clause deleting at least one
proper edge from the two singleton matchings of every concrete Tait witness.
This is sound: if a later cubic pole retained both matchings, the unique
unused incidence at each vertex would again form the complementary third
matching, so the forbidden state would remain.

Acceptance now requires the complete evaluated Tait state set to equal
\(S\), in addition to exact 40-type BF support, no \(A\)-cover, and five empty
D5 joins.

## Minimal checks

```text
uv run --python 3.12 --with z3-solver python \
  units/berge-fulkerson/scratch/worker-bf-real-synthesis/test_exact_s_tait_gate.py
```

The marker is `EXACT_S_TAIT_GATE_SMOKE_OK`.  The test checks the state
semantics on the two complementary labelled five-cycles and solves one
order-13 base model, verifying that all five positive states are present.

A one-round order-13 pulse completed in under one second after solving.  Its
candidate had all five target states plus four forbidden states; the driver
added six concrete singleton-pair blockers and stopped at the requested round
limit.  This is only a smoke test, not a search result.

## Bounded Omen pulse

The corrected driver was copied byte-for-byte to Omen and run once at order
13 with 20 CEGAR rounds and a 60-second limit per solver query.  It reached
the prescribed round limit after 15.945 seconds.  No candidate had exact
Tait set (S) or exact 40-type support.  Across the 20 returned common-
incidence graphs, support sizes were 52--55 and the number of forbidden Tait
states was 3--5; all five required states were present.  The closest final
model had 52 support types and three forbidden Tait states.  This is bounded
unresolved evidence, not an UNSAT result.

Remote artifacts:

```text
[local archival reference]
SHA-256 9f58e285dc89d7e988145a32add3c4a09b07a1bcf270e54fe6aa11163cd9f1c8
[local archival reference]
SHA-256 34ef77f223b8d2a892f7cbe0fbcacf34a233b93504a43687bfcd3f3b0ccb19fd
```

## Quantifier and incompleteness boundary

For each accepted candidate graph, exact-\(S\) is checked exhaustively over
its complete perfect-matching family.  The synthesis itself is bounded to
the fixed order 13, fixed distinct terminal labels 0 through 4, the chosen
vertex-symmetry break, solver timeout, and round limit.  `unknown` or
`round_limit` proves neither nonexistence at order 13 nor any all-order
statement.  The lazy blockers are sound but need not converge within a given
finite run.  Any positive candidate still requires an independent frozen
certificate before it can support a mathematical claim.
