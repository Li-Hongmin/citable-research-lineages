# Omen exact-Case-IV shared-incidence synthesis pulse (2026-09-01)

## Scope

This pulse asks for a real order-13 cubic 5-pole whose complete BF support is
exactly the 32-type Mácajová--Mazzuoccolo--Tabarelli Case-IV set, with no
`A`, no `T` loop, no `T--T` type, and with all four Case-IV disjoint-cell
joins empty.  The encoding keeps one graph and one set of matching vectors
for every positive type; negative support and joins are blocked lazily from
complete matching enumeration.  Thus a model would be a genuine shared
incidence witness.  A round limit is unknown, not an UNSAT certificate.

The positive target in shifted labels is

* 3 S loops `[13],[24],[25]`;
* 9 off-diagonal S--S types, omitting `(14)(35)`;
* all 20 S--T types except the five with T pair `(45)`.

The four D5 cells are the disjoint S--T cells that remain after deleting
`(13)(45)`.

## Omen run

Source files and SHA-256 values:

```text
b06925a33c40e0410af18c93e842c1c6da44cb5ea2a10a060f201df53dc992c1  synthesize_exact32_caseiv.py
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804  synthesize_exact40_joint_pb.py
```

Detached run directory:

```text
[local archival reference]
```

Command:

```text
python3 -u synthesize_exact32_caseiv.py --n 13 --max-rounds 100 \
  --timeout-ms 300000 --json exact32_caseiv_n13.json
```

## Result

All 100 solver calls were SAT and the run ended with
`CASEIV_SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY`.  No exact-32 model and
no UNSAT certificate was obtained.

Across the 100 evaluated graphs:

* support sizes ranged from 45 to 55 (20 rounds had size 45);
* the exact 32-type target was hit in 0 rounds;
* 40 rounds had no A-cover, but still had support size at least 45;
* all four join flags were empty in 24 rounds, while other rounds had one or
  more joins.

This is a finite synthesis boundary only.  It does not exclude Case IV and
does not construct a counterexample.  The local global-Kempe action pulse
for Case IV is also non-distinguishing, so any decisive argument must use a
stronger whole-pole incidence theorem or an exact-support construction.

