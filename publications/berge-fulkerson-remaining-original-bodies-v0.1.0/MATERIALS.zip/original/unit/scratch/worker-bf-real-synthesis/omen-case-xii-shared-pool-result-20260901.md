# Case-XII common PM-pool Omen pulse (2026-09-01)

## Decision target

Test a stronger common-incidence encoding for a real Case-XII pole.  All 40
positive types (15 (S\)-(S) types and 25 (S\)-(T) types) select their six
matching occurrences from one common pool: (K=2) slots for each of the five
singleton boundary classes and ten triple boundary classes.  Each pool slot
is constrained to be an actual perfect matching of the same simple cubic
five-pole; each selected six-tuple has proper-edge load exactly two.  The
complete matching family is re-enumerated for every SAT graph, with lazy
blockers for extra support, (A), and D5 joins.

This is a bounded pool-size test.  It is not an all-order statement, and a
solver timeout is not UNSAT.

## Omen run

Source `synthesize_exact40_shared_pool.py` SHA-256:

```text
5e5d89d21829eacbde35b654c677648196c54a5b3525b7e840c520d5e969f9d5
```

Base engine `synthesize_exact40_joint_pb.py` SHA-256:

```text
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

Command on Omen (detached tmux):

```text
python3 -u synthesize_exact40_shared_pool.py --n 13 --pool-size 2 \\
  --max-rounds 20 --timeout-ms 300000 --json case_xii_shared_k2_n13.json
```

Remote directory:
`[local archival reference]`.

## Result

Round 0 was SAT and produced a connected 13-vertex graph with 34 complete
perfect matchings and support size 52.  It had an (A)-cover and all five D5
join flags were false; the 12 visible forbidden types and the (A)-cover were
blocked.  The next solver call returned `unknown` after 300 s.  No exact-40
model, real counterexample, or UNSAT certificate was obtained.

The strengthened common-pool encoding is therefore computationally
unresolved at the first CEGAR refinement.  This pulse does not justify
increasing the order or pool size: the present bottleneck is the solver's
post-blocker search, not a mathematical counterexample.  A future decisive
experiment would need a structural reduction of the negative-support
constraints or a new analytic common-incidence theorem.

Local raw JSON:
`omen-case-xii-shared-pool-k2-n13-20260901.json` (SHA-256
`349241e16975c26dd12f07d8b49c0e2720da1ab275ff3f4f0658a8eb1ec4e048`).

