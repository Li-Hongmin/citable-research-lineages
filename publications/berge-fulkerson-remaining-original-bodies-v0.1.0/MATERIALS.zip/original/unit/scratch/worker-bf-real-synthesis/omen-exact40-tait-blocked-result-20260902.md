# Exact-40 real-incidence pulse with complete unwanted-Tait blocking

## Decision target

This pulse attacks the remaining real-pole negative branch: one common simple
connected cubic 5-pole carrying direct six-perfect-matching witnesses for all
40 Case-XII types, with no extra singleton Tait state, no (A=(12345))
cover, and no D5 four-cell join.  It is a bounded synthesis, not a census.

The base common-incidence constraints are those of
`synthesize_exact40_joint_pb.py`.  The strengthening is graph-level: for
each returned graph, every concrete edge-disjoint pair of singleton-boundary
perfect matchings in each unwanted (T)-state is enumerated, and a clause
removing at least one edge of that pair's union is added.  Thus the next model
cannot keep the same unwanted Tait state by merely choosing a different pair.

## Omen runs

The source is
`synthesize_exact40_tait_blocked.py` (SHA-256
`d4b4e11682aded1c0fb33ce368f6a562c12bbe186aa8d1e71953a238a94f053b`).

Commands (detached on host `omen`):

```text
python3 -u synthesize_exact40_tait_blocked.py --n 13 --max-rounds 12 \
  --timeout-ms 60000 --json result_n13.json
python3 -u synthesize_exact40_tait_blocked.py --n 15 --max-rounds 8 \
  --timeout-ms 60000 --json result_n15.json
```

### Order 13

12 rounds, 14.60 s, status `round_limit`.
Every model had support size 54--55 and all ten or nine singleton Tait
states; every recorded model had an (A)-cover.  No target model occurred.

JSON SHA-256: `91c01faa2b001b8d3ce0527c3db49e46b82e0ac534dd4379684d3ba58428b023`.
Log SHA-256: `10d86f119525ab573b9410d5dc5444f2f3141fde577ef664895a18a1254e7327`.

### Order 15

8 rounds, 35.32 s, status `round_limit`.
Every model had support size 53--55 and nine or ten singleton Tait states;
every recorded model had an (A)-cover.  No target model occurred.

JSON SHA-256: `d41fa58b0cffdb31e0c8c7202cff8d6fac05b27a7615a7198f3cfa09e1ddaecb`.
Log SHA-256: `36146e702b4e9f3eac8235c704c913674323754500766537cf1cb5ad28341dc9`.

## Four-value decision

* Real exact-40/no-(A)/join-free pole: **not found**.
* UNSAT or general proof: **not obtained**.
* Status: **bounded unresolved**.  The strengthened common-incidence encoding
  still does not decide the D5 join implication at orders 13 or 15.

These finite runs do not justify an all-order statement or an order increase.
No independent mathematical verifier is required for a negative/round-limit
result; any future positive target would require a fresh independent
perfect-matching certificate before being accepted.
