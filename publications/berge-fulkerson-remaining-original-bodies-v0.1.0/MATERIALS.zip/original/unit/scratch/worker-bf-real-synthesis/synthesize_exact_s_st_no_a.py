#!/usr/bin/env python3
"""Bounded exact-S + full S--T support synthesis.

This is a deliberately narrow Omen pulse.  The graph is one common simple
cubic five-pole.  Five actual Tait decompositions force the complete Tait
state set to contain S; the evaluator lazily blocks any extra state, an
all-terminal A-cover, forbidden BF types, bridges, and concrete D5 joins.
In addition, all 25 S--T types receive direct six-perfect-matching vectors
from the same graph.  A returned target is therefore a real exact-S pole with
full S--T support and no A; if its forbidden support is also absent it is a
Case-XII counterexample.  A timeout/round limit is only a bounded result.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import combinations
from pathlib import Path

from z3 import Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_base_for_exact_s_st", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

TERMINALS = BASE.TERMINALS
S_STATES = tuple(sorted(BASE.S))
ST_TYPES = tuple(sorted(tuple(sorted((s, t))) for s in S_STATES for t in BASE.T))
TARGET_TYPES = set(BASE.TARGET_TYPES)


def build_solver(n: int):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(PbEq([(value, 1) for value in incident], target))
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    # Five concrete Tait decompositions.  Each of the three vectors is an
    # actual PM of the same graph and the three proper-edge loads are one.
    for si, state in enumerate(S_STATES):
        boundaries = (
            frozenset((state[0],)),
            frozenset((state[1],)),
            frozenset(set(TERMINALS) - set(state)),
        )
        slots = []
        for ci, boundary in enumerate(boundaries):
            y = {edge: Bool(f"t_{si}_{ci}_{edge[0]}_{edge[1]}") for edge in edges}
            slots.append(y)
            for edge in edges:
                solver.add(Or(Not(y[edge]), x[edge]))
            for v in range(n):
                terms = [(y[e], 1) for e in edges if v in e]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))
        for edge in edges:
            load = [(slots[ci][edge], 1) for ci in range(3)]
            solver.add(PbLe(load, 1))
            solver.add(Or(Not(x[edge]), PbEq(load, 1)))

    # Direct common-PM incidence for all 25 S--T types.  This does not assert
    # exclusivity; complete enumeration below checks the full support.
    for ti, kind in enumerate(ST_TYPES):
        first, second = kind
        boundaries = BASE.slots_for_type(kind)
        slots = []
        for si, boundary in enumerate(boundaries):
            y = {edge: Bool(f"st_{ti}_{si}_{edge[0]}_{edge[1]}") for edge in edges}
            slots.append(y)
            for edge in edges:
                solver.add(Or(Not(y[edge]), x[edge]))
            for v in range(n):
                terms = [(y[e], 1) for e in edges if v in e]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))
        for edge in edges:
            load = [(slot[edge], 1) for slot in slots]
            solver.add(PbLe(load, 2))
            solver.add(Or(Not(x[edge]), PbEq(load, 2)))

    return solver, x, edges


def tait_states(n: int, proper_edges):
    matchings, classes = BASE.matching_classes(n, proper_edges)
    matching_set = {frozenset(m) for m in matchings}
    edge_count = len(proper_edges)
    all_objects = set(range(edge_count + len(TERMINALS)))
    states = set()
    for first, second in combinations(TERMINALS, 2):
        for left in classes.get(frozenset((first,)), ()):
            left_set = set(left)
            for right in classes.get(frozenset((second,)), ()):
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    states.add((first, second))
    return tuple(sorted(states)), matchings, classes


def evaluate(n: int, proper_edges):
    states, matchings, classes = tait_states(n, proper_edges)
    result = BASE.evaluate(n, proper_edges)
    result.update({"states": states, "matchings": matchings, "classes": classes})
    return result


def graph_certificate(n: int, proper_edges, result):
    cert = BASE.graph_certificate(n, proper_edges, result)
    cert.update({
        "tait_states": [list(s) for s in result["states"]],
        "tait_state_count": len(result["states"]),
        "st_support_count": len(set(result["support"]) & set(ST_TYPES)),
    })
    return cert


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges = build_solver(n)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT_S_ST_NO_A_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT_S_ST_NO_A_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var, model_completion=True))))
        result = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge)})

        extra_states = set(result["states"]) - set(S_STATES)
        if extra_states:
            solver.add(BASE.clause_for_union(x, edges, frozenset(proper_edges)))
            bad.append({"kind": "extra_tait", "states": [list(s)
                        for s in sorted(extra_states)]})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] - TARGET_TYPES, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, result)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and set(result["states"]) == set(S_STATES)
                and result["support"] == frozenset(TARGET_TYPES)
                and result["a_witness"] is None
                and not any(result["joins"])):
            payload = {"status": "real_exact_s_st_no_a_joinfree",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACT_S_ST_NO_A_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("EXACT_S_ST_NO_A_ROUND_LIMIT")
    return payload


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=15)
    parser.add_argument("--max-rounds", type=int, default=20)
    parser.add_argument("--timeout-ms", type=int, default=180000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)
