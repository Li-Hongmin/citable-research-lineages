# Omen girth-five exact-40 synthesis pulse (2026-09-01)

## Scope

This is a bounded strengthening of the joint graph/perfect-matching CEGAR
encoding in `synthesize_exact40_joint_pb.py`.  It fixes order (n=15),
requires the common six-matching incidence equations for all 40 positive
Case-XII types, and adds the local consequence of a girth-five normalization:
the proper graph has no triangle and no 4-cycle.  The evaluator still lazily
blocks an (A)-cover, extra support types, and concrete D5 joins.  It is not
a census and does not constitute an UNSAT proof when the round limit is
reached.

## Omen run

The source wrapper is
`synthesize_exact40_girth5_pb.py`; its SHA-256 is
`d51174d3da91d4e6c4cb7b82082199f968e33917bd13354e3f3163d628ba15af` and the
base-source SHA-256 is
`aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804`.  The
detached run was:

```text
ssh omen
cd [local archival reference]
python3 -u synthesize_exact40_girth5_pb.py --n 15 --max-rounds 100 \
  --timeout-ms 300000 --json exact40_girth5_n15.json
```

The run took 84.57 seconds and ended with
`SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY` after 100 satisfiable rounds.

## Result

No exact-40 model was returned, and no UNSAT certificate was obtained.  All
five D5 join flags were empty in every recorded round.  The support sizes
over the 100 models ranged from 53 to 55 (the target size is 40); 16 rounds
had no (A=(12345)) cover, but their support sizes were 53--55.  Thus the
strengthened girth-five pulse finds no Case-XII counterexample at order 15,
but leaves the real exact-40 implication unresolved.

The decision value is a finite boundary only: the remaining obstruction is
not removed by local girth-five constraints, so a successful proof must still
use common perfect-matching incidence across the five D5 cells (or construct
an exact-40 pole by another mechanism).
