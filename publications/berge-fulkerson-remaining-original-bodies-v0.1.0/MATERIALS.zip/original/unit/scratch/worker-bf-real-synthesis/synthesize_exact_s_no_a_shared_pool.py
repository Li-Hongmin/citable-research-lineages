#!/usr/bin/env python3
"""Bounded shared-PM-pool synthesis for an exact-S/no-A five-pole.

This pulse strengthens the earlier exact-S CEGAR encoding in one specific
way: the five Tait decompositions do not receive fifteen unrelated matching
vectors.  Instead, every singleton boundary class and every triple class used
by S is represented by a small common pool of K actual matching vectors, and
each of the five S states selects one vector from that pool.  The selected
vectors are required to partition every present proper edge.

The pool is only a bounded incidence relaxation: a real pole may have more
than K matching vectors in a boundary class.  Therefore UNSAT/timeout is not
an all-order conclusion.  A returned model is evaluated against the complete
matching family and is accepted only if it is a genuine exact-S/no-A pole.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from collections import defaultdict
from itertools import combinations
from pathlib import Path

from z3 import Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_base_for_shared_pool", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

TERMINALS = BASE.TERMINALS
S_STATES = tuple(sorted(BASE.S))


def boundary_for_pair(pair: tuple[int, int]) -> frozenset[int]:
    return frozenset(set(TERMINALS) - set(pair))


def boundary_name(boundary: frozenset[int]) -> str:
    return "_".join(map(str, sorted(boundary)))


def build_solver(n: int, pool_size: int):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    # One simple cubic five-pole, with semiedges fixed at 0,...,4.
    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(PbEq([(value, 1) for value in incident], target))
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    # Shared pool: five singleton classes and five S-triple classes.
    pool_boundaries = [frozenset((i,)) for i in TERMINALS]
    pool_boundaries += [boundary_for_pair(state) for state in S_STATES]
    pool_boundaries = tuple(dict.fromkeys(pool_boundaries))
    y = {}
    for boundary in pool_boundaries:
        bname = boundary_name(boundary)
        for slot in range(pool_size):
            for edge in edges:
                var = Bool(f"y_{bname}_{slot}_{edge[0]}_{edge[1]}")
                y[(boundary, slot, edge)] = var
            # Every pool vector is an actual PM of the common graph.
            for edge in edges:
                solver.add(Or(Not(y[(boundary, slot, edge)]), x[edge]))
            for v in range(n):
                terms = [(y[(boundary, slot, edge)], 1)
                         for edge in edges if v in edge]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))

    # State selectors and linearized selector*matching incidences.
    for state_index, state in enumerate(S_STATES):
        classes = (frozenset((state[0],)), frozenset((state[1],)),
                   boundary_for_pair(state))
        selectors = {}
        for class_index, boundary in enumerate(classes):
            slots = []
            for slot in range(pool_size):
                z = Bool(f"z_{state_index}_{class_index}_{slot}")
                selectors[(class_index, slot)] = z
                slots.append((z, 1))
            solver.add(PbEq(slots, 1))

        for edge in edges:
            selected_load = []
            for class_index, boundary in enumerate(classes):
                for slot in range(pool_size):
                    z = selectors[(class_index, slot)]
                    w = Bool(
                        f"w_{state_index}_{class_index}_{slot}_{edge[0]}_{edge[1]}"
                    )
                    yy = y[(boundary, slot, edge)]
                    # w = z AND yy.
                    solver.add(Or(Not(w), z))
                    solver.add(Or(Not(w), yy))
                    solver.add(Or(Not(z), Not(yy), w))
                    selected_load.append((w, 1))
            solver.add(PbLe(selected_load, 1))
            solver.add(Or(Not(x[edge]), PbEq(selected_load, 1)))

    return solver, x, edges


def graph_certificate(n: int, proper_edges, states, matchings, has_a, pool_size):
    return {
        "n": n,
        "pool_size": pool_size,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(matchings),
        "tait_states": [list(state) for state in states],
        "tait_state_count": len(states),
        "has_A": has_a,
    }


def evaluate(n: int, proper_edges):
    matchings, classes = BASE.matching_classes(n, proper_edges)
    states = set()
    matching_set = {frozenset(m) for m in matchings}
    all_objects = set(range(len(proper_edges) + len(TERMINALS)))
    for first, second in combinations(TERMINALS, 2):
        for left in classes.get(frozenset((first,)), ()):
            left_set = set(left)
            for right in classes.get(frozenset((second,)), ()):
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    states.add((first, second))
    a_witness = BASE.find_a_cover(classes, len(proper_edges))
    return tuple(sorted(states)), matchings, classes, a_witness


def run(n: int, pool_size: int, max_rounds: int, timeout_ms: int,
        out_path: Path | None):
    solver, x, edges = build_solver(n, pool_size)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("SHARED_POOL_EXACT_S_NO_A_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("SHARED_POOL_EXACT_S_NO_A_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var, model_completion=True))))
        states, matchings, classes, a_witness = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge)})

        extra_states = set(states) - set(S_STATES)
        if extra_states:
            solver.add(BASE.clause_for_union(x, edges, frozenset(proper_edges)))
            bad.append({"kind": "extra_tait", "states": [list(s)
                         for s in sorted(extra_states)]})

        if a_witness is not None:
            union = BASE.forbidden_union(a_witness, proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, states, matchings,
                                 a_witness is not None, pool_size)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and set(states) == set(S_STATES)
                and a_witness is None):
            payload = {"status": "real_exact_s_no_a_shared_pool",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACT_S_NO_A_SHARED_POOL_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("SHARED_POOL_EXACT_S_NO_A_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=15)
    parser.add_argument("--pool-size", type=int, default=2)
    parser.add_argument("--max-rounds", type=int, default=40)
    parser.add_argument("--timeout-ms", type=int, default=300000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    if args.pool_size < 1:
        raise SystemExit("pool-size must be positive")
    run(args.n, args.pool_size, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
