#!/usr/bin/env python3
"""Extract the blocker twist behind T-state pentagons in saved near misses."""

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
VERIFY = HERE / "verify_balanced_pulse_nearmiss.py"
SPEC = importlib.util.spec_from_file_location("balanced_verify", VERIFY)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(VERIFY)
V = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(V)

DEFAULT_INPUTS = (
    HERE / "omen-exact40-balanced-n13-20260902b.json",
    HERE / "omen-exact40-balanced-n15-20260902.json",
)


def components(indices, proper_edges):
    incident = defaultdict(list)
    for index in indices:
        u, v = proper_edges[index]
        incident[u].append(index)
        incident[v].append(index)
    assert all(len(row) == 2 for row in incident.values())
    unseen = set(indices)
    out = []
    while unseen:
        stack = [next(iter(unseen))]
        component = set()
        while stack:
            index = stack.pop()
            if index not in unseen:
                continue
            unseen.remove(index)
            component.add(index)
            u, v = proper_edges[index]
            stack.extend(candidate for vertex in (u, v)
                         for candidate in incident[vertex]
                         if candidate in unseen)
        out.append(frozenset(component))
    return tuple(sorted(out, key=lambda row: (len(row), tuple(sorted(row)))))


def tait_records(matchings, classes, edge_count):
    matching_id = {matching: index for index, matching in enumerate(matchings)}
    matching_lookup = {frozenset(matching): matching for matching in matchings}
    all_objects = set(range(edge_count + len(V.TERMINALS)))
    records = {state: [] for state in V.PAIR_SET}
    for i, j in V.PAIR_SET:
        for left in classes.get(frozenset((i,)), ()):
            for right in classes.get(frozenset((j,)), ()):
                if set(left) & set(right):
                    continue
                third = frozenset(all_objects - set(left) - set(right))
                if third in matching_lookup:
                    records[(i, j)].append((matching_id[left], matching_id[right],
                                            matching_id[matching_lookup[third]]))
    return records


def side(matching, blocker_indices):
    hits = [index in matching for index in blocker_indices]
    assert sum(hits) == 1
    return hits.index(True)


def selected_by_class(choice, states):
    rows = {i: [] for i in V.TERMINALS}
    for (i, j), (left, right, _) in zip(states, choice):
        rows[i].append(left)
        rows[j].append(right)
    return rows


def switch_certificate(left, right, matchings, blocker_indices, proper_edges):
    difference = frozenset(set(matchings[left]) ^ set(matchings[right]))
    assert all(index < len(proper_edges) for index in difference)
    parts = components(difference, proper_edges)
    blocker_part = [part for part in parts
                    if set(blocker_indices).issubset(part)]
    assert len(blocker_part) == 1
    return {
        "matching_ids": [left, right],
        "component_lengths": [len(part) for part in parts],
        "blocker_cycle": [list(proper_edges[index])
                          for index in sorted(blocker_part[0])],
    }


def best_t_pentagon(records, matchings, blocker_indices, proper_edges):
    states = tuple(sorted(V.T))
    if any(not records[state] for state in states):
        return None
    best = None
    best_payload = None
    parity_counts = set()
    for choice in itertools.product(*(records[state] for state in states)):
        rows = selected_by_class(choice, states)
        switches = []
        singleton_ids = set()
        for terminal, pair in rows.items():
            assert len(pair) == 2
            singleton_ids.update(pair)
            if side(matchings[pair[0]], blocker_indices) != side(
                    matchings[pair[1]], blocker_indices):
                switches.append((terminal, pair[0], pair[1]))
        parity_counts.add(len(switches) % 2)
        switch_data = [switch_certificate(left, right, matchings,
                                          blocker_indices, proper_edges)
                       for _, left, right in switches]
        key = (len(switches), len(singleton_ids),
               sum(len(row["blocker_cycle"]) for row in switch_data), choice)
        if best is None or key < best:
            best = key
            best_payload = {
                "states": [[i + 1, j + 1] for i, j in states],
                "coloring_matching_ids": [list(row) for row in choice],
                "distinct_singleton_matchings": len(singleton_ids),
                "switches": [dict(terminal=terminal + 1, **data)
                             for (terminal, _, _), data in zip(switches,
                                                               switch_data)],
            }
    assert parity_counts == {1}
    return best_payload


def analyze_certificate(certificate):
    n = certificate["n"]
    proper_edges = tuple(tuple(edge) for edge in certificate["proper_edges"])
    blocker = tuple(tuple(edge) for edge in certificate["selected_blocker"])
    blocker_indices = tuple(proper_edges.index(edge) for edge in blocker)
    degree = [0] * n
    adjacency = [[] for _ in range(n)]
    for u, v in proper_edges:
        assert u != v
        degree[u] += 1
        degree[v] += 1
        adjacency[u].append(v)
        adjacency[v].append(u)
    assert degree[:5] == [2] * 5 and degree[5:] == [3] * (n - 5)
    reached = {0}
    stack = [0]
    while stack:
        for v in adjacency[stack.pop()]:
            if v not in reached:
                reached.add(v)
                stack.append(v)
    assert len(reached) == n
    matchings, classes = V.matching_classes(n, proper_edges)
    edge_count = len(proper_edges)
    assert not V.balanced_violations(classes, set(blocker), proper_edges)
    support = {kind for kind in V.ALL_TYPES
               if V.find_cover(kind, classes, edge_count) is not None}
    assert len(support) == certificate["support_size"]
    assert V.find_a_cover(classes, edge_count) is None
    projections = {cell: V.cell_projection(cell, classes, edge_count)
                   for cell in V.D5}
    joins = [bool(set.intersection(*(set(projections[cell])
                                    for cell in V.D5 if cell != omitted)))
             for omitted in V.D5]
    assert joins == certificate["d5_join_flags"] == [False] * 5
    records = tait_records(matchings, classes, edge_count)
    states = tuple(state for state in V.PAIR_SET if records[state])
    assert [list(state) for state in states] == certificate["tait_states"]

    # Complete-family balancedness forces both blocker edges onto the same
    # alternating component whenever a same-class PM pair changes side.
    opposite_pairs = 0
    blocker_cycle_lengths = set()
    for terminal in V.TERMINALS:
        family = classes.get(frozenset((terminal,)), ())
        ids = {matching: index for index, matching in enumerate(matchings)}
        for left, right in itertools.combinations(family, 2):
            if side(left, blocker_indices) == side(right, blocker_indices):
                continue
            opposite_pairs += 1
            data = switch_certificate(ids[left], ids[right], matchings,
                                      blocker_indices, proper_edges)
            blocker_cycle_lengths.add(len(data["blocker_cycle"]))

    present_t = sorted(set(states) & set(V.T))
    present_t_loops = sorted(state for state in V.T
                             if (state, state) in support)
    assert present_t_loops == present_t
    return {
        "n": n,
        "proper_edges": [list(edge) for edge in proper_edges],
        "blocker": [list(edge) for edge in blocker],
        "matching_count": len(matchings),
        "support_size": certificate["support_size"],
        "missing_pair_types": [str(kind) for kind in V.ALL_TYPES
                               if kind not in support],
        "tait_states": [[i + 1, j + 1] for i, j in states],
        "extra_t_states": [[i + 1, j + 1] for i, j in present_t],
        "t_loop_support": [[i + 1, j + 1] for i, j in present_t_loops],
        "tait_coloring_counts": {
            f"{i + 1}{j + 1}": len(records[(i, j)]) for i, j in V.PAIR_SET
        },
        "opposite_side_same_class_pairs": opposite_pairs,
        "blocker_cycle_lengths": sorted(blocker_cycle_lengths),
        "minimum_t_pentagon": best_t_pentagon(
            records, matchings, blocker_indices, proper_edges),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("json", nargs="*", type=Path,
                        default=list(DEFAULT_INPUTS))
    args = parser.parse_args()
    seen = set()
    rows = []
    for path in args.json:
        payload = json.loads(path.read_text(encoding="utf-8"))
        for round_row in payload["rounds"]:
            certificate = round_row["certificate"]
            key = (tuple(map(tuple, certificate["proper_edges"])),
                   tuple(map(tuple, certificate["selected_blocker"])))
            if key in seen or certificate["balanced_violation_count"]:
                continue
            seen.add(key)
            row = analyze_certificate(certificate)
            row["source"] = path.name
            row["round"] = round_row["round"]
            rows.append(row)

    full = [row for row in rows if len(row["extra_t_states"]) == 5]
    partial = [row for row in rows if len(row["extra_t_states"]) < 5]
    assert len(full) == 11 and len(partial) == 1
    assert {len(row["minimum_t_pentagon"]["switches"]) for row in full} == {1, 3}
    assert {row["minimum_t_pentagon"]["distinct_singleton_matchings"]
            for row in full} == {7, 8, 9}
    assert partial[0]["support_size"] == 54
    assert partial[0]["extra_t_states"] == [[1, 2], [1, 5], [3, 4], [4, 5]]
    print(json.dumps({"full_t_pentagons": len(full),
                      "partial_t_sets": len(partial),
                      "rows": rows}, indent=2, sort_keys=True))
    print("BALANCED_NEARMISS_TAIT_TWIST_VERIFIED")


if __name__ == "__main__":
    main()
