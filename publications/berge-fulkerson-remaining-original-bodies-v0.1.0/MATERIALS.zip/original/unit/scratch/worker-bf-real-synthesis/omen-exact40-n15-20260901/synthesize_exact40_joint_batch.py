#!/usr/bin/env python3
"""Bounded joint graph/PM synthesis for a real Case-XII pole.

This is a CEGAR-style *single* constraint object, rather than a graph census.
For a fixed odd order ``n`` the Boolean variables ``x[u,v]`` describe one
simple cubic five-pole (the five semiedges are fixed at vertices 0,...,4).
For each of the 40 Case-XII boundary types, six further matching incidence
vectors are encoded directly.  They are required to be perfect matchings of
the same graph and to have edge load exactly two.  A model is therefore a
genuine common graph/perfect-matching incidence witness for all positive
types.

The universal negative conditions (no A, no T-loops/TT, no extra BF type, and
empty D5 four-cell joins) are added lazily from a complete perfect-matching
enumeration of each model.  Every lazy clause is a clause in the same graph
variables: it deletes the particular actual matching cover (or graph cut)
which was found.  Thus this is a bounded synthesis object with shared
incidence, not a post-hoc host scan.  A result is accepted only after a fresh
independent evaluator sees exactly the 40 support types and five empty joins.

Scope is deliberately narrow: n=13 and distinct terminals fixed to 0..4 by
vertex relabelling.  ``unknown``/timeout is a coding boundary, not UNSAT.
All expensive execution is intended for the Omen tmux host.
"""

from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path

from z3 import And, Bool, If, Int, Not, Or, Solver, Sum, sat, unknown


TERMINALS = tuple(range(5))
PAIR_SET = tuple(combinations(TERMINALS, 2))
# S={13,14,24,25,35} after the harmless 1->0 shift used throughout this file.
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(PAIR_SET) - set(S))
TARGET_TYPES = tuple(
    list(combinations_with_replacement(sorted(S), 2))
    + sorted(tuple(sorted((s, t))) for s in S for t in T)
)
ALL_TYPES = tuple(combinations_with_replacement(PAIR_SET, 2))
FORBIDDEN_TYPES = tuple(kind for kind in ALL_TYPES if kind not in TARGET_TYPES)
D5 = tuple(sorted((s, t) for s in S for t in T if set(s).isdisjoint(t)))
PHI = {
    ((0, 2), (3, 4)): ((0, 3), (1, 4)),
    ((0, 3), (1, 2)): ((0, 2), (1, 3)),
    ((1, 3), (0, 4)): ((0, 3), (1, 4)),
    ((1, 4), (2, 3)): ((1, 3), (2, 4)),
    ((2, 4), (0, 1)): ((0, 2), (1, 4)),
}


def edge_key(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def all_proper_edges(n: int) -> tuple[tuple[int, int], ...]:
    return tuple(combinations(range(n), 2))


def type_name(kind) -> str:
    if kind == ("A",):
        return "A"
    return str(kind)


def boundary_for_pair(pair: tuple[int, int]) -> frozenset[int]:
    return frozenset(set(TERMINALS) - set(pair))


def slots_for_type(kind):
    first, second = kind
    # Two triple-boundary slots followed by four singleton-boundary slots.
    return (boundary_for_pair(first), boundary_for_pair(second),
            frozenset((first[0],)), frozenset((first[1],)),
            frozenset((second[0],)), frozenset((second[1],)))


def build_solver(n: int):
    edges = all_proper_edges(n)
    edge_index = {edge: i for i, edge in enumerate(edges)}
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    # Proper degree is 2 at the five fixed semiedge terminals and 3 elsewhere.
    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(Sum([If(value, 1, 0) for value in incident]) == target)

    # Remove the largest residual vertex-label symmetry.  Every n=13 pole has
    # an edge between two nonterminals, so labels 5,6 can be chosen on one.
    if n >= 7:
        solver.add(x[edge_key(5, 6)])

    # Direct common-PM incidence vectors for all positive Case-XII types.
    witness_vars = {}
    for ti, kind in enumerate(TARGET_TYPES):
        boundaries = slots_for_type(kind)
        slot_vars = []
        for si, boundary in enumerate(boundaries):
            y = {edge: Bool(f"y_{ti}_{si}_{edge[0]}_{edge[1]}")
                 for edge in edges}
            slot_vars.append(y)
            witness_vars[(kind, si)] = y
            for edge in edges:
                solver.add(Or(Not(y[edge]), x[edge]))
            for v in range(n):
                terms = [If(y[e], 1, 0) for e in edges if v in e]
                if v in TERMINALS:
                    terms.append(1 if v in boundary else 0)
                solver.add(Sum(terms) == 1)
        # The six proper-edge vectors have exact double-cover load.  Semiedge
        # load is automatically two from the boundary pattern of each type.
        for edge in edges:
            # Potential complete-graph edges which are absent from the
            # synthesized pole must have load zero; present edges have load
            # two.  (Using ``== 2`` unconditionally would accidentally demand
            # a double cover of all absent potential edges.)
            solver.add(Sum([If(y[edge], 1, 0) for y in slot_vars])
                       == 2 * If(x[edge], 1, 0))

    return solver, x, edges, witness_vars


def graph_edges(model, x):
    return tuple(sorted(edge for edge, var in x.items() if model.eval(var, model_completion=True)))


def enumerate_matchings(n: int, proper_edges: tuple[tuple[int, int], ...]):
    """Enumerate all perfect matchings of the five-pole.

    A matching is represented by proper-edge indices followed by semiedge
    indices ``len(proper_edges)+terminal``.  The five semiedges are fixed at
    terminals 0,...,4.
    """
    edge_index = {edge: i for i, edge in enumerate(proper_edges)}
    adjacency = {v: [] for v in range(n)}
    for edge, i in edge_index.items():
        u, v = edge
        adjacency[u].append((v, i))
        adjacency[v].append((u, i))
    out = []
    used = [False] * n
    chosen = []

    def rec():
        try:
            u = next(v for v in range(n) if not used[v])
        except StopIteration:
            out.append(tuple(sorted(chosen)))
            return
        used[u] = True
        if u in TERMINALS:
            chosen.append(len(proper_edges) + u)
            rec()
            chosen.pop()
        for v, i in adjacency[u]:
            if used[v]:
                continue
            used[v] = True
            chosen.append(i)
            rec()
            chosen.pop()
            used[v] = False
        used[u] = False

    rec()
    return tuple(sorted(set(out)))


def matching_boundary(matching, proper_count):
    return frozenset(i - proper_count for i in matching if i >= proper_count)


def matching_classes(n, proper_edges):
    matchings = enumerate_matchings(n, proper_edges)
    classes = defaultdict(list)
    for matching in matchings:
        classes[matching_boundary(matching, len(proper_edges))].append(matching)
    for key in classes:
        classes[key].sort()
    return tuple(matchings), classes


def edge_load_ok(chosen, edge_count):
    load = [0] * edge_count
    for matching in chosen:
        for edge in matching:
            if edge >= edge_count:
                continue
            load[edge] += 1
            if load[edge] > 2:
                return False
    return load


def find_cover(kind, classes, edge_count):
    """Return one actual six-PM cover witness for ``kind``, if present."""
    first, second = kind
    classes_for = [classes[boundary_for_pair(first)],
                   classes[boundary_for_pair(second)]]
    singleton_slots = tuple(first + second)
    classes_for.extend(classes[frozenset((i,))] for i in singleton_slots)
    if any(not family for family in classes_for):
        return None
    selected = []
    load = [0] * edge_count

    # Order by family size while preserving the six slot labels in output.
    order = sorted(range(6), key=lambda i: len(classes_for[i]))

    def rec(k):
        if k == 6:
            return tuple(selected[i] for i in range(6))
        slot = order[k]
        for matching in classes_for[slot]:
            if any(edge < edge_count and load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                if edge < edge_count:
                    load[edge] += 1
            selected[slot] = matching
            result = rec(k + 1)
            if result is not None:
                return result
            for edge in matching:
                if edge < edge_count:
                    load[edge] -= 1
        return None

    selected.extend([None] * 6)
    return rec(0)


def find_a_cover(classes, edge_count):
    families = [classes[frozenset((i,))] for i in TERMINALS]
    if any(not family for family in families):
        return None
    selected = [None] * 5
    load = [0] * edge_count
    order = sorted(range(5), key=lambda i: len(families[i]))

    def rec(k):
        if k == 5:
            return tuple(selected)
        slot = order[k]
        for matching in families[slot]:
            if any(edge < edge_count and load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                if edge < edge_count:
                    load[edge] += 1
            selected[slot] = matching
            result = rec(k + 1)
            if result is not None:
                return result
            for edge in matching:
                if edge < edge_count:
                    load[edge] -= 1
        return None

    return rec(0)


def cell_projection(cell, classes, edge_count):
    """Map a D5 cell to its actual singleton-PM tuples and one completion."""
    first, second = cell
    families = [classes[frozenset((i,))] for i in TERMINALS]
    left_family = classes[boundary_for_pair(first)]
    right_family = classes[boundary_for_pair(second)]
    output = {}
    for singleton_tuple in product(*families):
        load = [0] * edge_count
        for position in first + second:
            for edge in singleton_tuple[position]:
                if edge < edge_count:
                    load[edge] += 1
        if any(value > 2 for value in load):
            continue
        for left in left_family:
            trial = load[:]
            if any(edge < edge_count and trial[edge] >= 2 for edge in left):
                continue
            for edge in left:
                if edge < edge_count:
                    trial[edge] += 1
            for right in right_family:
                if all((edge >= edge_count) or trial[edge] + (edge in right) == 2
                       for edge in range(edge_count)):
                    output[singleton_tuple] = (left, right)
                    break
            if singleton_tuple in output:
                break
    return output


def forbidden_union(witness, proper_edges):
    """Translate evaluator-local matching indices to graph edge keys."""
    edge_count = len(proper_edges)
    return frozenset(proper_edges[edge] for matching in witness for edge in matching
                     if edge < edge_count)


def evaluate(n, proper_edges):
    edge_count = len(proper_edges)
    matchings, classes = matching_classes(n, proper_edges)
    support = {}
    witnesses = {}
    for kind in ALL_TYPES:
        witness = find_cover(kind, classes, edge_count)
        if witness is not None:
            support[kind] = True
            witnesses[kind] = witness
    a_witness = find_a_cover(classes, edge_count)
    projections = {cell: cell_projection(cell, classes, edge_count) for cell in D5}
    joins = []
    join_data = []
    for omitted in D5:
        common = set.intersection(*(set(projections[cell]) for cell in D5 if cell != omitted))
        if common:
            singleton_tuple = min(common, key=str)
            completions = tuple(
                (cell, projections[cell][singleton_tuple])
                for cell in D5 if cell != omitted
            )
            union = set()
            for matching in singleton_tuple:
                union.update(proper_edges[edge] for edge in matching if edge < edge_count)
            for _, pair in completions:
                for matching in pair:
                    union.update(proper_edges[edge] for edge in matching if edge < edge_count)
            joins.append(True)
            join_data.append((omitted, frozenset(union), singleton_tuple, completions))
        else:
            joins.append(False)
    return {
        "matchings": matchings,
        "classes": classes,
        "support": frozenset(support),
        "witnesses": witnesses,
        "a_witness": a_witness,
        "joins": tuple(joins),
        "join_data": tuple(join_data),
    }


def connected_components(n, proper_edges):
    graph = {v: set() for v in range(n)}
    for u, v in proper_edges:
        graph[u].add(v)
        graph[v].add(u)
    unseen = set(graph)
    components = []
    while unseen:
        root = min(unseen)
        seen = {root}
        stack = [root]
        while stack:
            u = stack.pop()
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        unseen -= seen
        components.append(frozenset(seen))
    return tuple(components)


def bridge_cuts(n, proper_edges):
    """Return (bridge, one-side) for every proper-edge bridge."""
    out = []
    edge_set = set(proper_edges)
    for bridge in proper_edges:
        rest = edge_set - {bridge}
        comps = connected_components(n, tuple(rest))
        if len(comps) > 1:
            side = min(comps, key=lambda c: (len(c), tuple(sorted(c))))
            out.append((bridge, side))
    return tuple(out)


def clause_for_union(x, edges, union):
    terms = [Not(x[e]) for e in edges if e in union]
    if not terms:
        raise RuntimeError("empty blocker union")
    return Or(terms)


def graph_certificate(n, proper_edges, result):
    return {
        "n": n,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "class_sizes": {str(sorted(k)): len(v) for k, v in sorted(result["classes"].items(), key=str)},
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "target_support": len(result["support"] & set(TARGET_TYPES)) == 40,
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
    }


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, _ = build_solver(n)
    target_set = set(TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        # z3py returns a CheckSatResult object; use equality rather than
        # identity here, otherwise a timeout ``unknown`` is misreported as an
        # UNSAT proof.
        if status == unknown:
            rounds.append({"round": round_no, "status": "unknown"})
            payload = {"status": "unknown", "rounds": rounds, "elapsed_s": time.time() - started}
            print(json.dumps(payload, indent=2, sort_keys=True))
            return payload
        if status != sat:
            rounds.append({"round": round_no, "status": "unsat"})
            payload = {"status": "unsat", "rounds": rounds, "elapsed_s": time.time() - started}
            print(json.dumps(payload, indent=2, sort_keys=True))
            return payload
        model = solver.model()
        proper_edges = tuple(edge for edge, var in x.items()
                             if bool(model.eval(var, model_completion=True)))
        proper_edges = tuple(sorted(proper_edges))
        result = evaluate(n, proper_edges)
        bad = []
        if len(connected_components(n, proper_edges)) != 1:
            comps = connected_components(n, proper_edges)
            side = min(comps, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side), "crossing_count": len(crossing)})
        else:
            bridges = bridge_cuts(n, proper_edges)
            for bridge, side in bridges:
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge), "side": sorted(side)})
        if result["a_witness"] is not None:
            union = forbidden_union(result["a_witness"], proper_edges)
            solver.add(clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})
        # Batch all currently visible extra support types.  The original
        # driver intentionally added only one forbidden-type clause per
        # round; for this fixed n=13 pulse that causes the next SAT call to
        # rediscover the other extra types one by one.  Every clause below is
        # sound: it excludes only the concrete six-PM cover just enumerated.
        for kind in sorted(result["support"] - target_set, key=str):
            union = forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind), "union_size": len(union)})
        # Likewise block every currently witnessed D5 join.  A join witness
        # is a concrete common singleton tuple plus five concrete triple
        # completions; removing one edge of its union is a valid graph-level
        # blocker and avoids re-solving the same five-cell join in later
        # rounds.
        for omitted, union, _, _ in result["join_data"]:
            solver.add(clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted), "union_size": len(union)})
        cert = graph_certificate(n, proper_edges, result)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))
        if (not bad and result["support"] == target_set
                and result["a_witness"] is None and not any(result["joins"])):
            payload = {"status": "real_exact40_joinfree", "rounds": rounds,
                       "certificate": cert, "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            print("REAL_EXACT40_D5_JOINFREE_SYNTHESIZED")
            return payload
    payload = {"status": "round_limit", "rounds": rounds, "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("SYNTHESIS_ROUND_LIMIT_OR_ENCODING_BOUNDARY")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=80)
    parser.add_argument("--timeout-ms", type=int, default=120000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
