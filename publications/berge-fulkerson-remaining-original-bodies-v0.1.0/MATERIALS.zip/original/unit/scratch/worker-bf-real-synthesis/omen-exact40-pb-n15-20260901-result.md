# Omen PB-CEGAR pulse at order 15

This bounded synthesis encodes one common simple cubic 5-pole on 15 internal
vertices and direct perfect-matching incidence vectors for the 40 positive
Case-XII types.  The complete matching evaluator lazily adds blockers for
the (A=(12345)) cover, extra ordinary support types, and D5 joins.

Command on Omen:

```text
python3 -u synthesize_exact40_joint_pb.py --n 15 --max-rounds 20 \
  --timeout-ms 120000 --json exact40_pb_n15.json
```

The source SHA-256 is
`aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804`.
The run took 39.05 seconds.  All 20 rounds were satisfiable and the final
status was `round_limit`; no UNSAT certificate and no real exact-40 model was
found.

Round summaries (matching count, ordinary support count, A-cover, D5 join
flags) were:

```text
0  47 55 True  [False, True, False, False, False]
1  41 54 True  [False, False, True, False, False]
2  44 55 True  [False, False, False, False, False]
3  44 55 True  [False, False, False, False, False]
4  45 55 True  [False, False, False, False, False]
5  50 55 True  [False, False, False, False, False]
6  49 55 True  [False, False, False, False, False]
7  51 55 True  [False, False, False, True, False]
8  48 55 False [False, False, False, False, False]
9  46 55 True  [False, False, False, False, False]
10 42 55 True [False, False, True, False, True]
11 44 55 True [False, False, False, False, False]
12 47 55 True [False, False, False, False, False]
13 46 55 True [False, False, False, False, False]
14 49 55 True [False, False, False, False, False]
15 47 55 True [False, False, False, False, False]
16 47 55 True [False, False, False, False, False]
17 44 55 True [False, False, False, False, False]
18 44 55 True [False, False, False, False, False]
19 47 55 True [False, False, False, False, False]
```

Round 8 is informative but not a Case-XII candidate: it has no A-cover and
all five D5 joins empty, yet it still has all 55 ordinary types rather than
the required 40.  The correct decision is therefore **bounded unresolved**.
It does not support an all-order claim, a real counterexample, or an UNSAT
proof.  Omen artifacts are in
`[local archival reference]`.
