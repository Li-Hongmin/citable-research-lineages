# Balanced near misses contain an odd blocker twist, not one fixed generator

## Scope and question

This note uses only the saved order-13 and order-15 candidates in
`omen-exact40-balanced-n13-20260902b.json` and
`omen-exact40-balanced-n15-20260902.json`.  It does not run synthesis or
increase the order.

Write

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and let the selected balanced blocker be \(B=\{a,b\}\).  The complete
perfect-matching family satisfies

\[
 |P\cap B|=1 \quad(P\text{ singleton}),\qquad
 |Q\cap B|=0 \quad(Q\text{ triple}).
\]

The question is whether the five unwanted states in \(T\) arise from one
common local perfect-matching or edge template.

## Exact finite result

After deduplication and removal of the one candidate whose complete family
violates balancedness, there are twelve saved candidates: eleven contain all
five states in \(T\), while one order-13 candidate contains only

\[
 \{12,15,34,45\}.
\]

The latter is a sharp finite boundary: it is connected and cubic, has a
complete-family balanced blocker, no \(A\)-cover and five empty \(D_5\)
joins, but support size 54 rather than 55.  Its unique missing pair type is

\[
 (23)(23),
\]

and its unique missing Tait state is \(23\).  Thus the conjunction

\[
 \text{no-}A+\text{empty }D_5\text{ joins}+\text{balanced blocker}
\]

does **not** force all five unwanted states even inside the saved real
candidate family.

For each of the eleven full \(T\)-pentagons, the script chooses one actual
Tait colouring for each edge of \(T\), first minimizing the number of
blocker-side switches and then the number of distinct singleton perfect
matchings.  The minimum numbers of distinct singleton matchings are

\[
 7^1,\qquad 8^7,\qquad 9^3.
\]

Ten candidates admit a minimum selection with one blocker-side switch.  One
order-13 candidate requires three.  The switching class is not fixed, and the
blocker-containing alternating-cycle lengths occurring in the complete
families are

\[
 4,6,8,10,12,14.
\]

Hence there is no common fixed PM set, terminal class, cycle length or
single-switch edge template shared by these candidates.

## The common analytic mechanism

There is nevertheless one exact necessary mechanism.

**Odd blocker-twist lemma.**  Suppose a cubic 5-pole has the complete-family
balanced property above and contains all five Tait states of the odd cycle
\(T\).  Choose one Tait colouring for every edge \(ij\in T\), and denote its
two singleton colour classes by \(P_i^{ij},P_j^{ij}\).  Then:

1. the two singleton matchings in every chosen colouring use opposite edges
   of \(B\);
2. an odd number of terminal classes use opposite blocker sides in their two
   incident chosen colourings;
3. at every such class, the two same-boundary singleton matchings differ on
   a proper alternating-cycle component containing both \(a\) and \(b\).

For (1), the triple matching avoids \(B\), while the three colour matchings
partition all edge objects.  Thus the two singleton matchings cover different
members of \(B\).  Walking around the odd cycle \(T\) proves (2).  For (3),
the symmetric difference of two same-boundary perfect matchings is a disjoint
union of proper even alternating cycles.  If \(a\) and \(b\) belonged to
different components, flipping only the component through one of them would
produce another singleton perfect matching with blocker load zero or two,
contradicting complete-family balancedness.

The verifier checks this component claim for every opposite-side same-class
PM pair in all twelve candidates.  It also checks that every possible choice
of five Tait colourings has an odd number of switches.

This lemma explains the shared *shape* of an already existing
\(T\)-pentagon.  It does not derive a state in \(T\) from no-\(A\), empty
joins and balancedness.  Therefore the proposed causal route remains
undistinguished; the stronger claim that one fixed local pattern produces all
five states is closed by the saved candidates.

## Reproduction

From the AIMath root:

```text
python3 units/berge-fulkerson/scratch/worker-bf-real-synthesis/analyze_balanced_nearmiss_tait_twist.py
```

The final line is

```text
BALANCED_NEARMISS_TAIT_TWIST_VERIFIED
```

The output contains the complete Tait-colouring PM triples and one optimized
pentagon certificate for every candidate.

## Driver caveat

The saved graphs and the analysis above are valid independently of the
synthesis stopping condition.  However, `synthesize_exact40_balanced.py`
currently labels every nonempty `tait_states` set as `extra_tait` and requires
that set to be empty for success.  Its stated target is exact \(S\), so the
gate should compare the full state set with \(S\), not with the empty set.
As written, the driver cannot report a genuine exact-\(S\) success.  This is
an implementation boundary, not a mathematical nonexistence result.
