from synthesize_exact40_joint import build_solver
from z3 import Not

n = 13
old = (
    (0, 8), (0, 11), (1, 7), (1, 9), (2, 9), (2, 12), (3, 10),
    (3, 12), (4, 10), (4, 11), (5, 7), (5, 8), (5, 9), (6, 8),
    (6, 11), (6, 12), (7, 10),
)
# Preserve terminals; relabel nonterminals so old edge (5,7) becomes (5,6).
mp = {5: 5, 7: 6, 6: 7, 8: 8, 9: 9, 10: 10, 11: 11, 12: 12}
edges = tuple(sorted(tuple(sorted((mp.get(u, u), mp.get(v, v)))) for u, v in old))
s, x, all_edges, _ = build_solver(n)
for e in all_edges:
    s.add(x[e] if e in edges else Not(x[e]))
# The round-0 model from the synthesis log; its forbidden cover used all 17
# edges, so the CEGAR blocker is ``at least one of these absent``.
round0 = (
    (0, 7), (0, 11), (1, 5), (1, 7), (2, 9), (2, 10), (3, 8), (3, 11),
    (4, 8), (4, 10), (5, 6), (5, 9), (6, 7), (6, 12), (8, 9), (10, 12),
    (11, 12),
)
s.add(__import__('z3').Or([Not(x[e]) for e in round0]))
s.set(timeout=120000)
status = s.check()
print('check', status)
