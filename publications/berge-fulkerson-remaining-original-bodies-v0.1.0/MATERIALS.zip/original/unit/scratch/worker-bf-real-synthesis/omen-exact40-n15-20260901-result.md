# Omen n=15 exact-40 CEGAR pulse (2026-09-01)

This bounded synthesis encoded one common simple cubic 5-pole on 15 internal
vertices together with the six proper-edge perfect-matching vectors for every
positive Case-XII type.  The complete matching evaluator then lazily blocked
the first model's concrete (A=(12345)) cover and all 16 visible forbidden
ordinary types.  The run used Omen Python 3.10.12 and Z3 5.1.0:

```text
python3 -u synthesize_exact40_joint_batch.py --n 15 --max-rounds 3 \
  --timeout-ms 300000 --json exact40_n15_batch.json
```

Round 0 was satisfiable, with a connected 15-vertex graph having 50 perfect
matchings, all 55 ordinary boundary types, an (A)-cover, and all five D5
joins empty.  After adding the concrete blockers, round 1 returned
`unknown` at the 300-second solver limit.  No exact-40/no-(A) model was
produced.

This is neither an UNSAT certificate nor a real pole.  It only says that the
current n=15 common-incidence encoding did not decide the target within the
bounded run.  No further round or adjacent order is authorized by this
pulse.

Source: `synthesize_exact40_joint_batch.py` (SHA-256
`fa435cfabcf502dacf0f938e5ce63c97a8422ae707f87d31c27570a4e9a5102c`).
Raw stdout SHA-256:
`488e638369bb51c6ee89ffbe2184c6da9478bb09fea7339e7b6a21eb074ab4d4`.
