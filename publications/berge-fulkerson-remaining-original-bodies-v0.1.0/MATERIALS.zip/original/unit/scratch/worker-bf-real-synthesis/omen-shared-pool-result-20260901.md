# Shared-PM-pool Omen pulse (2026-09-01)

## Decision target

Test whether a common finite pool of actual perfect-matching vectors changes
the bounded search for a real exact-(S), no-(A) cubic five-pole.  For each
of the five (S=\{13,14,24,25,35\}) Tait states, the singleton and triple
vectors are selected from the same pool (pool size (K)); selected vectors
must partition every present proper edge.  The complete matching family is
then re-enumerated and extra Tait states and (A=(12345)) covers are blocked
lazily.

This is a bounded incidence strengthening, not an all-order theorem: a real
pole may have more than (K) vectors in a boundary class, and a round limit
is not UNSAT.

## Omen runs

Source: `synthesize_exact_s_no_a_shared_pool.py` (SHA-256
`3eee8492aa7a02a23e906625ad5fea0aeacca1a57d6c70d8f2a9b442179483ac`), with
base engine `synthesize_exact40_joint_pb.py` (SHA-256
`aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804`).

Both runs used detached tmux sessions on Omen, order (n=15), 40 CEGAR
rounds, and a 300 s per-call timeout:

```text
python3 -u synthesize_exact_s_no_a_shared_pool.py --n 15 --pool-size 2 \\
  --max-rounds 40 --timeout-ms 300000 --json shared_pool_n15.json
python3 -u synthesize_exact_s_no_a_shared_pool.py --n 15 --pool-size 3 \\
  --max-rounds 40 --timeout-ms 300000 --json shared_pool_k3_n15.json
```

The remote directory is
`[local archival reference]`.

## Result

* (K=2): all 40 rounds were SAT and ended at `round_limit`.  Every
  evaluated graph had 8--10 Tait states, so none was exact-(S).  Twenty-five
  rounds had no (A)-cover but still had extra Tait states; 15 had both an
  extra state and an (A)-cover.
* (K=3): all 40 rounds were SAT and ended at `round_limit`.  State counts
  were (5,6,7,8,9,10) (one round had exactly the five (S) states), but that
  exact-(S) round had an (A)-cover.  The remaining 39 rounds had an extra
  Tait state and/or an (A)-cover; no exact-(S)/no-(A) pole was returned.

Thus a common pool of size at most three does not produce a real
exact-(S)/no-(A) counterexample at order 15.  This is only a finite
encoding boundary; it neither proves the exact-(S\Rightarrow A) bridge nor
rules out larger boundary fibres.  The next useful step must add a genuinely
new incidence or exchange constraint, not merely increase (K) or (n).

Raw JSON certificates copied locally:

* `omen-shared-pool-k2-n15-20260901.json` (SHA-256
  `178935a7dd7087e777bac1f4f4c52db4c1b1a54251c63582ae2973ebfab105c8`)
* `omen-shared-pool-k3-n15-20260901.json` (SHA-256
  `8ec13ff9cec637be2d22e83eb7a93eaf616a5c030a0ba6ac95105907c2ba8289`)

