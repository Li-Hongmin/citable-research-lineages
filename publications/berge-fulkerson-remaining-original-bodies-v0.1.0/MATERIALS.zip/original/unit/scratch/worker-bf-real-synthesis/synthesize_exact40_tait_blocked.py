#!/usr/bin/env python3
"""CEGAR synthesis with exact exclusion of unwanted singleton Tait states.

This is a narrow companion to ``synthesize_exact40_joint_pb.py``.  The base
solver already puts forty positive Case-XII six-matching witnesses on one
common cubic graph.  At each model we additionally enumerate *all* concrete
edge-disjoint pairs of singleton-boundary perfect matchings in every
``T``-state and add one graph clause for each pair.  Thus a subsequent model
cannot merely replace one witness of an unwanted Tait state by another.  The
remaining negative BF conditions (A, extra support types and D5 joins) are
handled by the audited base CEGAR evaluator.

This remains bounded synthesis: ``unknown``/round limit is not a theorem.
The purpose is only to make the real common-incidence gate sharper at the
lowest useful cost; no abstract incidence or load-only relaxation is used.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from pathlib import Path

from z3 import Or, sat, unknown


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("exact40_tait_blocked_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)


def tait_pair_unions(tait_witnesses, proper_edges, states):
    """Return every certified singleton-pair union for given Tait states.

    A clause excluding each returned union is equivalent, for the current
    complete graph encoding, to requiring that no edge-disjoint pair in that
    boundary state survive in a later model.  We enumerate all pairs rather
    than blocking only one representative, which is the key strengthening
    over the existing exact-40 pulse.
    """
    out = []
    for state in sorted(states):
        for witness in tait_witnesses.get(state, ()):
            union = BASE.tait_pair_union(witness, proper_edges)
            if union:
                out.append((state, union))
    # Deduplicate unions: distinct boundary pairs may induce the same graph
    # clause, and duplicate clauses only inflate the SAT instance.
    seen = set()
    unique = []
    for state, union in out:
        key = tuple(sorted(union))
        if key in seen:
            continue
        seen.add(key)
        unique.append((state, union))
    return tuple(unique)


def graph_certificate(n, proper_edges, result, tait_block_count):
    cert = {
        "n": n,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "class_sizes": {
            str(sorted(k)): len(v)
            for k, v in sorted(result["classes"].items(), key=str)
        },
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "tait_states": [list(s) for s in sorted(result["tait_states"])],
        "exact_tait_S": set(result["tait_states"]) == set(BASE.S),
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
        "tait_block_clauses": tait_block_count,
    }
    return cert


def evaluate(n, proper_edges):
    return BASE.evaluate(n, proper_edges)


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, _ = BASE.build_solver(n)
    target_set = set(BASE.TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT40_TAIT_BLOCKED_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("EXACT40_TAIT_BLOCKED_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var, model_completion=True))))
        result = evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side),
                        "crossing_count": len(crossing)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(x[bridge] == False)
                bad.append({"kind": "bridge", "bridge": list(bridge),
                            "side": sorted(side)})

        # Exact Tait-set gate: the base PB object forces every state in S via
        # doubled loop witnesses.  Lazily block only the actually present
        # forbidden states T=PAIR_SET-S; target states must remain.
        missing_states = set(BASE.S) - set(result["tait_states"])
        if missing_states:
            raise RuntimeError(
                "positive Tait-state encoding mismatch: missing "
                + repr(sorted(missing_states))
            )
        extra_states = set(result["tait_states"]) - set(BASE.S)
        tait_pairs = tait_pair_unions(
            result["tait_witnesses"], proper_edges, extra_states
        )
        for state, union in tait_pairs:
            solver.add(BASE.clause_for_union(x, edges, union))
        if extra_states:
            bad.append({"kind": "extra_tait",
                        "states": [list(s) for s in sorted(extra_states)],
                        "pair_clauses": len(tait_pairs)})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = graph_certificate(n, proper_edges, result, len(tait_pairs))
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and set(result["tait_states"]) == set(BASE.S)
                and result["a_witness"] is None
                and not any(result["joins"])):
            payload = {"status": "real_exacts_exact40_joinfree", "rounds": rounds,
                       "certificate": cert, "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_EXACTS_EXACT40_TAIT_BLOCKED_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("EXACT40_TAIT_BLOCKED_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=20)
    parser.add_argument("--timeout-ms", type=int, default=60000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    raise SystemExit(main())
