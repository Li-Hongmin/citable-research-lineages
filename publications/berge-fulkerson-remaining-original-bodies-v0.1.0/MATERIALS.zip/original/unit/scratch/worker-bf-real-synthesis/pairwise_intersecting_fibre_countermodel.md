# Pairwise-intersecting singleton fibres do not force a common section

This is a deliberately incidence-level (not cubic-pole) obstruction to the
proposed shortcut for Cases IV/IX/XI.

Take five singleton fibres
\(\mathcal P_i=\{P_i^0,P_i^1\}\), with all ten objects pairwise
intersecting as edge sets.  (For example, put a distinct dummy edge
\(e_{ij}^{ab}\) in both \(P_i^a\) and \(P_j^b\), for every unordered pair
of objects; add private edges to make all vectors the same cardinality.)
No disjointness or support condition is violated by this construction.

For four cells impose the nonempty two-point transport relations
\[
R_1: x_1=x_2,\quad R_2:x_2=x_3,\quad R_3:x_3=x_4,
\quad R_4:x_4=1-x_1,
\]
where \(x_i\in\{0,1\}\) selects \(P_i^{x_i}\).  Every row has two
solutions, and every selected pair of singleton vectors intersects, but the
intersection of the four row relations is empty: the first three imply
\(x_1=x_4\), contradicting the fourth.

Thus the Tait-empty consequence “distinct singleton classes are pairwise
intersecting” is strictly weaker than a common fixed-singleton section.  Any
proof of the latter must use additional structure beyond pairwise PM
intersection, such as the fact that all row relations arise from the same
six-vector load equations on one cubic vertex set (or a genuine exchange/
Helly theorem for those equations).
