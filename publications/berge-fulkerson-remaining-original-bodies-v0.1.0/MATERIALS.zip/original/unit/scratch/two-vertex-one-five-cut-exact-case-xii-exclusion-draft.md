# The two-vertex one-five-cut exact Case-XII profile is impossible (draft)

This provisional analytic proof awaits an independent check. It uses the genuine connector of [Note 204](../notes/204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md), the perfect-matching routes of [Notes 205](../notes/205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md) and [206](../notes/206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md), and half-load saturation from [Note 055](../notes/055-half-load-column-saturation-and-case-xii-compression.md). The authoritative Case-XII support is [Figure 7 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) of Máčajová–Mazzuoccolo–Tabarelli (2026).

**Claim.** In the connected deficient-core, minimum-host setting of Note 204, no exact-Case-XII five-pole has a smallest maximum Tutte barrier of two vertices whose odd components are one five-cut shore containing the internal mark \(e\) and three singleton shores. This excludes that precise profile at every order. It does not exclude the other Tutte-barrier profiles or prove the Berge–Fulkerson conjecture.

By [Notes 206–208](../notes/208-only-a-private-rim-e-neighbour-pair-remains-in-the-two-vertex-connector.md), only the neighbour pair \(\{b,f\}\) for \(e\) in the allowed missing-pair pentagon \(S\) remains, up to reflection. Its two cyclic orders are
\[
\begin{array}{c|c|c}
 &S&T\\\hline
\mathrm I&e-b-a-c-f-e&\{ea,ec,af,bc,bf\}\\
\mathrm {II}&e-b-c-a-f-e&\{ea,ec,ab,bf,cf\}.
\end{array}                                                    \tag{1}
\]
Exact Case XII contains every \(S\)--\(T\) pair and forbids every \(T\)--\(T\) pair, including loops.

## Common half-load constraint

Let \(D\) be a three-perfect-matching half-load with one terminal occurrence at each label and \(\varnothing\ne\mathcal R(D)\subseteq S\). Note 055 gives \(\mathcal R(D)=S\). Decompose \(D=X+Y+Z\) at state \(eb\), where \(X\) is the triple, \(Y\) singleton-\(b\), and \(Z\) singleton-\(e\). By Note 205, \(X\) uses \(b:w_1,u_1w_0,u_2w_2\) outside the shore \(C\), and its one selected shore endpoint is reached through \(e\).

The terminal-\(b\) path of \(X\triangle Y\) must end at \(f\), since switching it changes \(eb\) to the only other \(S\)-edge incident with \(e\), namely \(ef\). At \(w_1\), \(Y\) can use \(f:w_1\) or \(u_1w_1\). The former gives the short exterior \(b\)--\(f\) path. In the latter case, \(Y\) cannot use \(a:w_0\) or \(c:w_2\), which would end the path at forbidden \(ea\) or \(ec\). It must therefore use \(u_2w_0,f:w_2\), giving the long exterior path
\[
b-w_1-u_1-w_0-u_2-w_2-t_f-f.                         \tag{2}
\]
Switching gives an \(ef\)-triple \(X'_L\) with exterior \(f:w_1,u_1w_0,u_2w_2\), or \(X'_R\) with exterior \(f:w_2,u_1w_1,u_2w_0\), respectively. Both satisfy \(X'|_C=X|_C\).

Use the ten exhaustive singleton-\(e\) routes \(L0,\ldots,L4,R0,\ldots,R4\) of Note 206, equation (3). In the exterior of \(X\triangle Z\), let \(a_0,c_0\) be the shore ports reached from terminals \(a,c\). Define \(a_L,c_L,a_R,c_R\) analogously for \(X'_L\triangle Z,X'_R\triangle Z\). Tracing the exterior alternating paths gives
\[
\begin{array}{c|cc|cc|cc}
Z&a_0&c_0&a_L&c_L&a_R&c_R\\\hline
L0&a&c&a&c&a&c\\
L1&a&h_1&a&h_1&a&h_1\\
L2&a&h_2&a&h_2&a&h_2\\
L3&h_1&c&h_1&c&h_1&c\\
L4&h_1&h_2&h_1&h_2&h_2&h_1\\
R0&a&c&a&c&a&c\\
R1&a&c&a&c&a&c\\
R2&a&c&a&c&a&c\\
R3&b&c&h_2&c&h_2&c\\
R4&h_1&c&h_1&c&h_2&c.
\end{array}                                                    \tag{3}
\]
Here \(h_i=u_iv_i\), and the entries denote distinct port **edges** even if their endpoints in \(C\) coincide. For example, route \(L4\) sends the \(a,c\) paths of \(X\triangle Z\) to \(h_1,h_2\); after the long switch they go to \(h_2,h_1\).

The restrictions to \(C\) of \(X\triangle Z\) and \(X'\triangle Z\) are identical. They therefore pair the internal \(e\)-port with the same one of the three other shore ports. In form I, the \(e\)-terminal path must end at \(a\) for \(eb\), then \(c\) for \(ef\), so \(a_0=c_L\) or \(a_0=c_R\). In form II, it must end at \(c\), then \(a\), so \(c_0=a_L\) or \(c_0=a_R\). Table (3) permits only \(Z=L4\) and the long \(b\)--\(f\) switch \(X'_R\), in either form.

Thus every such \(S\)-only half-load has the following exterior matching routes:
\[
\begin{array}{c|l}
X&b:w_1,\ u_1w_0,\ u_2w_2;\quad e\text{ enters }C\\
Y&u_1w_1,\ u_2w_0,\ f:w_2;\quad a,c\text{ enter }C\\
Z&f:w_1,\ a:w_0,\ c:w_2,\ h_1,h_2;\quad b\text{ enters }C.
\end{array}                                                    \tag{4}
\]
Every connector edge and marked half-edge of \(a,b,c,f\) has \(D\)-load one. We will use four of them:
\[
q=t_fw_1,\qquad p=t_bx_b,\qquad h_1=u_1v_1,\qquad h_2=u_2v_2,
\qquad D(q)=D(p)=D(h_1)=D(h_2)=1.                    \tag{5}
\]
The edge \(p\) is the shore-side half of mark \(b\). Formula (5) holds for *any* half-load with a nonempty state set contained in \(S\), irrespective of its complementary half.

## Form I: the required \((eb)(af)\) row

Take an actual row of type \((eb)(af)\) and write its two halves as \(X+Y+Z\) and \(U+V+W\). Here \(U\) is the \(af\)-triple, \(V\) singleton-\(a\), and \(W\) singleton-\(f\). The first half has \(\mathcal R=S\): a \(T\)-state in it would combine with the complementary \(af\in T\) state to give a forbidden \(T\)--\(T\) row. It therefore has (4), and the complementary half also loads every exterior edge once.

The \(af\)-triple has exactly four exterior routes:
\[
\begin{array}{c|l}
a\text{ enters }C& f:w_1,u_1w_0,u_2w_2\quad\text{or}\quad f:w_2,u_1w_1,u_2w_0\\
a:w_0& f:w_1,h_1,u_2w_2\quad\text{or}\quad f:w_2,u_1w_1,h_2.
\end{array}                                                    \tag{6}
\]
If \(U\) uses \(f:w_1\), the \(b\)--\(f\) component of \(X\triangle U\) is wholly exterior and goes through \(w_1\). Switch these two triples and regroup the six occurrences as
\[
D_{ef}=X'+Z+W,\qquad D_{ab}=U'+Y+V,\qquad
D_{ef}+D_{ab}=2\mathbf1.                              \tag{7}
\]
Both displayed states belong to \(S\). Yet \(X'\) and \(Z\) both use \(q\), while \(W\) uses terminal \(f\), so \(D_{ef}(q)=2\) and \(D_{ab}(q)=0\). By (5), each half has a \(T\)-state; their union is a forbidden genuine \(T\)--\(T\) row.

If \(U\) uses \(a\) entering \(C\) and \(f:w_2\), the \(b\)--\(f\) component is the long exterior path, and (7) again applies. Complementary unit load forces \(W\) to use \(a:w_0\), since \(U\) uses the shore half of \(a\) and \(V\) uses terminal \(a\). If \(W\) uses \(p\), then \(D_{ef}(p)=2\). Otherwise \(W\) uses \(b:w_1\); with \(w_0,w_1\) occupied, \(W\) must use \(h_1\), giving \(D_{ef}(h_1)=2\). The complementary half has load zero on the same edge. Formula (5) again forces a forbidden \(T\)--\(T\) row.

If \(U\) uses \(a:w_0,f:w_2,u_1w_1,h_2\), then \(X\triangle U\) has the wholly exterior \(a\)--\(b\) component \(a-w_0-u_1-w_1-b\). Switching it and regrouping gives states \(ea,bf\), both in \(T\) for form I. This is forbidden directly. Form I is impossible.

## Form II: the required \((eb)(cf)\) row

Take an actual \((eb)(cf)\) row with complementary \(cf\)-triple \(U\), singleton-\(c\) matching \(V\), and singleton-\(f\) matching \(W\). The \(cf\)-triple has precisely four exterior routes:
\[
\begin{array}{c|l}
c\text{ enters }C&f:w_1,u_1w_0,u_2w_2\quad\text{or}\quad f:w_2,u_1w_1,u_2w_0\\
c:w_2&f:w_1,h_1,u_2w_0\quad\text{or}\quad f:w_1,u_1w_0,h_2.
\end{array}                                                    \tag{8}
\]
For any of the three \(f:w_1\) routes, switch the exterior \(b\)--\(f\) component of \(X\triangle U\) through \(w_1\) and regroup:
\[
D_{ef}=X'+Z+W,\qquad D_{bc}=U'+Y+V,\qquad
D_{ef}+D_{bc}=2\mathbf1.                              \tag{9}
\]
Both displayed states lie in \(S\). As before, \(X'\) and \(Z\) both use \(q\), so the two half-loads there are \(2,0\). Formula (5) forces a forbidden \(T\)--\(T\) row.

In the remaining route, \(U\) has \(c\) entering \(C\) and \(f:w_2\). Switch \(X,U\) along the long exterior \(b\)--\(f\) path and use (9). Complementary unit load forces \(W\) to use \(c:w_2\), because \(U\) uses the shore half of \(c\) and \(V\) has terminal \(c\). If \(W\) uses \(p\), then \(D_{ef}(p)=2\). Otherwise it uses \(b:w_1\). If it also avoided \(h_1,h_2\), its already occupied vertices \(w_1,w_2\) would force it to use both \(u_1w_0\) and \(u_2w_0\), impossible in one perfect matching. Hence \(W\) uses \(h_1\) or \(h_2\), which \(Z\) also uses. The two half-loads have values \(2,0\) on that edge, and (5) again gives a forbidden \(T\)--\(T\) row. Form II is impossible. \(\square\)

The argument uses actual full perfect matchings and all-orders edge loads. It makes no assumption about uniqueness of shore deletion matchings.
