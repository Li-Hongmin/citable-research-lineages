# Case-XII canonical transport holonomy：反例与正确边界

本页只记录本轮可复核叶子；不修改永久 note。

## 1. 一般恒等式

沿补五边形

\[
v_0v_1v_2v_3v_4v_0=1,4,2,5,3,1
\]

令 \(E_t=R_{v_t v_{t+1}}\)。对 \((P,Q)\in E_t\)，令 \(C\) 为
\(P\cup Q\) 的边补；在 \(P\cup C\) 中从 semiedge \(v_t\) 出发的
alternating path 上交换 \(P,C\)，得到

\[
f_t(P,Q)=(Q,P')\in E_{t+1}.
\]

反向操作不是下一个 forward transport \(f_{t+1}\)。准确地说，定义
\(b_t:E_{t+1}\to E_t\)：从 \((Q,P')\) 出发，在 \(P'\) 与其补色的同一
alternating path（端点为 \(v_{t+2},v_t\)）上交换回来，然后恢复次序。则

\[
b_t=f_t^{-1}.
\]

因此单步可逆并不蕴含五步复合

\[
h_t=f_{t+4}f_{t+3}f_{t+2}f_{t+1}f_t:E_t\to E_t
\]

为 involution。能够一般证明的循环型关系只有循环基点改变时的共轭：

\[
h_{t+1}=f_t h_t f_t^{-1}.
\]

所以五个基点的 holonomy 有相同 cycle type 和 sign；反向绕行给出
\(h_t^{-1}\)。这些恒等式均不强制 \(h_t^2=1\)。

## 2. 十一阶真实三循环反例

取内部顶点 \(0,\ldots,10\)，semiedge \(s_i\) 接在顶点 \(i-1\)
（\(i=1,\ldots,5\)）。把下列 proper edges 按顺序记为
\(e_0,\ldots,e_{13}\)：

\[
\begin{split}
&(0,2),(0,3),(1,7),(1,9),(2,4),(3,10),(4,8),\\
&(5,7),(5,9),(5,10),(6,8),(6,9),(6,10),(7,8).
\end{split}
\]

这是 simple connected cubic 5-pole，五个 semiedge 位于不同顶点。
它共有 27 个 perfect matchings，其中 singleton-boundary matchings 恰为
下列 13 个；最后一个 \(M_{12}\) 不参加任何 Tait relation：

\[
\begin{array}{c|l|c}
&\text{edges}&\text{boundary}\\ \hline
M_0&e_0,e_{10},e_2,e_5,e_8,s_5&5\\
M_1&e_0,e_{10},e_3,e_5,e_7,s_5&5\\
M_2&e_0,e_{11},e_2,e_6,e_9,s_4&4\\
M_3&e_0,e_{12},e_2,e_6,e_8,s_4&4\\
M_4&e_0,e_{12},e_3,e_6,e_7,s_4&4\\
M_5&e_1,e_{11},e_{13},e_4,e_9,s_2&2\\
M_6&e_1,e_{11},e_2,e_6,e_9,s_3&3\\
M_7&e_1,e_{12},e_{13},e_4,e_8,s_2&2\\
M_8&e_1,e_{12},e_2,e_6,e_8,s_3&3\\
M_9&e_1,e_{12},e_3,e_6,e_7,s_3&3\\
M_{10}&e_{10},e_2,e_4,e_5,e_8,s_1&1\\
M_{11}&e_{10},e_3,e_4,e_5,e_7,s_1&1\\
M_{12}&e_0,e_{11},e_5,e_6,e_7,s_2&2
\end{array}
\]

直接比较交集可得，跨不同 boundary classes 的全部 disjoint pairs 只出现于

\[
\{13,14,24,25,35\},
\]

每个 relation 的大小都为 3。因此全部 Tait lonely-pair states 恰为 Case-XII
补五边形。

按上述 alternating-path 规则逐步 transport，\(E_0=R_{14}\) 的三个元素
形成以下轨道（每一箭头依次为 \(f_0,f_1,f_2,f_3,f_4\)）：

\[
\begin{aligned}
(M_{10},M_4)&\to(M_4,M_5)\to(M_5,M_1)\to(M_1,M_6)
 \to(M_6,M_{11})\to(M_{11},M_2),\\
(M_{11},M_2)&\to(M_2,M_7)\to(M_7,M_1)\to(M_1,M_8)
 \to(M_8,M_{11})\to(M_{11},M_3),\\
(M_{11},M_3)&\to(M_3,M_5)\to(M_5,M_0)\to(M_0,M_9)
 \to(M_9,M_{10})\to(M_{10},M_4).
\end{aligned}
\]

故

\[
h_0=((M_{10},M_4)\ (M_{11},M_2)\ (M_{11},M_3))
\]

是三循环，尤其 \(h_0^2\ne 1\)。这是 matching-derived system，且来自真实
cubic 5-pole，而不只是抽象 layered graph。

## 3. 对错误等价的修正

此 pole 仍有 compatible pentagon，例如

\[
M_{10}\sim M_4\sim M_5\sim M_0\sim M_9\sim M_{10}.
\]

但 canonical \(h_0\) 没有不动点：上述 pentagon 在 relation
\((M_4,M_5)\) 之后选择 \((M_5,M_0)\)，而 canonical \(f_1\) 强制选择
\((M_5,M_1)\)。因此：

\[
h_0\text{ 有不动点}\Longrightarrow\text{存在 compatible pentagon},
\]

逆命题为假。永久 note 001 中 relational composition
\(R_{31}\circ R_{53}\circ R_{25}\circ R_{42}\circ R_{14}\) 的 fixed-point
表述仍然正确；应修正的是 note 002 把 deterministic canonical transport
的 fixed point 与 Pentagon-selection 等同的句子。

## 4. sign、cycle type 与最小边界

对十一阶全部 41 个 \(D_5\)-quotient Case-XII branches，canonical \(h\) 的
cycle-type 分布为

\[
\begin{array}{c|rrrrrr}
\text{cycle type}&(1)&(1,1)&(2)&(2,2)&(3)&(4)\\ \hline
\text{branches}&15&7&12&4&2&1.
\end{array}
\]

三循环为偶置换而四循环为奇置换，所以不存在“所有真实 matching-derived
holonomy 都为偶置换”或“都为奇置换”的 universal sign restriction。
同一表也排除了 universal fixed-point 或 involution 限制。

其中四循环（奇置换）可由另一个显式十一阶 pole 实现；其 proper edges 为

\[
\begin{split}
&(0,2),(0,3),(1,5),(1,6),(2,4),(3,10),(4,8),\\
&(5,8),(5,9),(6,9),(6,10),(7,8),(7,9),(7,10),
\end{split}
\]

semiedge 仍按 \(s_i\) 接在 \(i-1\)。复现程序对这个 pole 给出 cycle type
\((4)\)，与上面的显式三循环共同排除任何固定的 sign。

在相同的 simple、connected、五个 terminal 互异假设下，对内部阶数
\(n=5,7,9\) 的完备枚举分别给出

\[
\begin{array}{c|c}
n&\text{cycle-type distribution}\\ \hline
5&(1):1\\
7&(1):10\\
9&(1):600,\ (1,1):60,\ (2):120.
\end{array}
\]

故十一阶是该结构类中 canonical holonomy 非 involution 的最小阶；这只是
一个有限最小性结论，不是任意结构假设下的分类定理。

复现入口：`scratch/compute_transport_cycle_types.py`。该程序重新生成全部
十一阶 branches，验证每个 \(f_t\) 为双射并输出 cycle types；九阶以下数据
使用同一文件中的 `holonomy_data` 结合已有完备生成器得到。
