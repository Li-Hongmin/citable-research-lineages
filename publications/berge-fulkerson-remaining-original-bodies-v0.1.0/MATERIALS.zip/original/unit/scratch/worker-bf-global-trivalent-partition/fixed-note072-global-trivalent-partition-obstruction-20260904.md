# The fixed Note 072 certificate has no global trivalent partition

## Statement

Consider the fixed symbolic common-incidence certificate of Note 072,
including its twelve-coordinate star factor, the thirty-six private
\(\binom{[6]}2\) factors, the two final split coordinates, and the five
boundary semiedges.  There is no grouping of its edge incidences into
three-element vertex blocks such that every matching vector selects exactly
one member of every block.

This is an impossibility result for that fixed certificate only.  It does not
exclude another exact-BF-40 failed-star binary-incidence system from admitting
a common trivalent realization.

## Fourteen-token projection

Project every edge coordinate to the fourteen matching identities in the
star factor

\[
 \{a_1,a_2,a_4,a_5,x,y,q_A,r_{45},q_B,r_{23},q_C,r_{15},q_D,r_{34}\}.
\]

Every Cartesian-product proper coordinate projects to one of the twelve
star columns \(C_1,\ldots,C_{12}\).  The two final proper coordinates project
to

\[
 A=\{a_1,a_4,y\},\qquad B=\{a_2,a_5,x\},
\]

and semiedge \(s_j\) projects to the star identities whose boundary contains
\(j\).  Hence every trivalent vertex block must consist of three members of
this nineteen-type projected family whose supports are pairwise disjoint and
whose union is the full fourteen-token set.

Now use the first blocker column

\[
 C_1=\{a_2,a_5,r_{23},r_{45}\}.
\]

Among all other projected edge types, the only ones disjoint from \(C_1\)
are

\[
\begin{aligned}
 C_3&=\{a_1,r_{15},r_{34},x,y\},\\
 C_9&=\{a_1,a_4,q_D\},\\
 A&=\{a_1,a_4,y\}.
\end{aligned}
\]

No two of these can cover the ten-token complement of \(C_1\); indeed their
sizes are \(5,3,3\), and every pair also intersects.  Therefore no projected
vertex block contains \(C_1\).  Every full product coordinate with star
component \(C_1\) is consequently unplaceable in a trivalent incidence
system.

These coordinates are neither zero nor redundant duplicates.  Their star
support is nonempty, and changing any private-factor pair changes the full
matching-incidence vector.  Thus deleting zero or repeated coordinate types
does not remove the obstruction without changing the certificate's matching
vectors.

The fixed certificate already retains its failed pivot star and exact forty
BF row equations by Note 072.  The contradiction occurs before either
property needs to be weakened: the unchanged binary vectors themselves have
no common trivalent vertex partition.

## Finite check

The script

```text
units/berge-fulkerson/scratch/worker-bf-global-trivalent-partition/check_fixed_note072_star_projection.py
```

enumerates all projected legal vertex triples and also solves the resulting
integer exact-cover equations.  There are only three legal projected types,

\[
 (C_4,C_7,C_{10}),\quad(C_4,C_7,C_{11}),\quad(C_{12},A,B),
\]

so \(C_1\) and eleven other positive-demand projected types are uncovered.
The Omen run used one process in detached session
`fixed_note072_projection2` under a 2 GiB virtual-memory limit.  Its output is

```text
[local archival reference]
```

and ends with exact-cover status `unsat`.

## Boundary

The fixed Note 072 product construction cannot be upgraded to common global
trivalent incidence.  The failed-star abstract-countermodel route therefore
needs a new column family, not a repartition of this certificate.  No claim is
made about all exact-BF-40 failed-star incidence systems or about real cubic
5-poles.
