#!/usr/bin/env python3
"""Necessary star-token projection of a trivalent Note 072 realization."""

from itertools import combinations_with_replacement
from z3 import Int, Solver, Sum, sat

from search_fixed_note072_trivalent_trade import (
    P, STAR_BOUNDARY, STAR_COLUMNS, STAR_NAMES, STAR_SPLITS,
)


def main():
    product_multiplicity = 15 ** 36
    names = tuple(f"C{i + 1}" for i in range(len(STAR_COLUMNS))) + (
        "A", "B", "s1", "s2", "s3", "s4", "s5",
    )
    supports = [set(column) for column in STAR_COLUMNS]
    supports.extend(map(set, STAR_SPLITS))
    supports.extend(
        {name for name in STAR_NAMES if terminal in STAR_BOUNDARY[name]}
        for terminal in P
    )
    demand = [2 * product_multiplicity] * len(STAR_COLUMNS) + [2, 2] + [1] * 5

    legal = []
    for triple in combinations_with_replacement(range(len(names)), 3):
        if all(sum(token in supports[index] for index in triple) == 1
               for token in STAR_NAMES):
            legal.append(triple)

    variables = [Int(f"x{i}") for i in range(len(legal))]
    solver = Solver()
    solver.set(timeout=5 * 60 * 1000)
    solver.add(*(variable >= 0 for variable in variables))
    for coordinate in range(len(names)):
        solver.add(Sum(
            variables[index] * triple.count(coordinate)
            for index, triple in enumerate(legal)
        ) == demand[coordinate])

    print("projected_types", len(names))
    print("legal_vertex_types", len(legal))
    print("legal_vertices", tuple(tuple(names[i] for i in triple) for triple in legal))
    blocker = 0  # C1 is neither zero nor one of the duplicated C10/C11 types.
    blocker_complement = set(STAR_NAMES) - supports[blocker]
    disjoint_candidates = tuple(
        names[index] for index, support in enumerate(supports)
        if index != blocker and support.isdisjoint(supports[blocker])
    )
    print("C1_support", tuple(sorted(supports[blocker])))
    print("C1_complement_size", len(blocker_complement))
    print("C1_disjoint_candidates", disjoint_candidates)
    print("C1_disjoint_candidate_sizes", tuple(
        len(supports[names.index(name)]) for name in disjoint_candidates
    ))
    assert disjoint_candidates == ("C3", "C9", "A")
    assert max(
        len(supports[names.index(left)] | supports[names.index(right)])
        for left, right in combinations_with_replacement(disjoint_candidates, 2)
        if left != right
    ) < len(blocker_complement)
    result = solver.check()
    print("status", result)
    if result == sat:
        model = solver.model()
        used = [
            (tuple(names[i] for i in legal[index]), model.eval(variable).as_long())
            for index, variable in enumerate(variables)
            if model.eval(variable).as_long()
        ]
        print("used_vertex_types", used)
        print("FIXED_NOTE072_STAR_PROJECTION_SAT")
    elif str(result) == "unsat":
        # Human-readable incidence obstruction: which coordinate types occur
        # in no legal projected vertex at all.
        covered = {index for triple in legal for index in triple}
        print("uncovered_positive_types", tuple(
            names[index] for index, value in enumerate(demand)
            if value and index not in covered
        ))
        print("FIXED_NOTE072_STAR_PROJECTION_UNSAT")
    else:
        print("FIXED_NOTE072_STAR_PROJECTION_UNKNOWN")


if __name__ == "__main__":
    main()
