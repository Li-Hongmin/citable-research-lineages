#!/usr/bin/env python3
"""Search one finite trivalent trade for the symbolic Note 072 certificate."""

from itertools import combinations, combinations_with_replacement
from z3 import And, Distinct, If, Int, Or, Solver, Sum, sat


P = tuple(range(1, 6))
S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
STAR_CELLS = {
    tuple(sorted(cell)) for cell in (
        ((1, 3), (4, 5)), ((1, 4), (2, 3)),
        ((2, 4), (1, 5)), ((2, 5), (3, 4)),
    )
}

STAR_NAMES = (
    "a1", "a2", "a4", "a5", "x", "y",
    "qA", "r45", "qB", "r23", "qC", "r15", "qD", "r34",
)
STAR_BOUNDARY = {
    "a1": {1}, "a2": {2}, "a4": {4}, "a5": {5},
    "x": {3}, "y": {3},
    "qA": {2, 4, 5}, "r45": {1, 2, 3},
    "qB": {2, 3, 5}, "r23": {1, 4, 5},
    "qC": {1, 3, 5}, "r15": {2, 3, 4},
    "qD": {1, 3, 4}, "r34": {1, 2, 5},
}
STAR_COLUMNS = (
    {"a2", "a5", "r23", "r45"},
    {"a4", "r15", "r23", "r45", "y"},
    {"a1", "r15", "r34", "x", "y"},
    {"a5", "r15", "r23", "r34", "x"},
    {"a5", "x", "qB", "qC", "r34"},
    {"a5", "x", "qB", "qC", "qD"},
    {"a4", "r45", "qB", "qC", "qD"},
    {"a2", "a4", "qA"},
    {"a1", "a4", "qD"},
    {"a1", "a2", "y", "qA"},
    {"a1", "a2", "y", "qA"},
    {"qA", "r45", "qB", "r23", "qC", "r15", "qD", "r34"},
)
STAR_SPLITS = (
    {"a1", "a4", "y"},
    {"a2", "a5", "x"},
)

# Nine replacement vertices: two endpoints of each split proper edge, then
# the five terminal vertices.  Their third-incidence support is K[r].
RIGHT_NAMES = ("A0", "A1", "B0", "B1", "T1", "T2", "T3", "T4", "T5")
EDGE_COUNT = 9


def private_factors():
    positive = set(combinations_with_replacement(S, 2))
    positive.update((s, t) for s in S for t in T)
    return tuple(sorted(positive - STAR_CELLS))


def add_factor(solver, prefix, supports, missing_sets, resolution_groups):
    """Add local labels for nine trade edges and a complete resolution."""
    label_count = len(supports)
    labels = [Int(f"{prefix}_e{e}") for e in range(EDGE_COUNT)]
    for label in labels:
        solver.add(And(label >= 0, label < label_count))

    # The selected three old triples are three orbits of one local resolution.
    solver.add(Distinct(labels))
    for group in range(3):
        group_labels = labels[3 * group:3 * group + 3]
        for token in range(len(supports[0])):
            solver.add(Sum([
                If(Or(*[And(label == value, supports[value][token])
                        for value in range(label_count)]), 1, 0)
                for label in group_labels
            ]) == 1)

    # Complete the local resolution.  This proves that the three removed
    # product orbits lie in an explicit partition of the whole product set.
    extra = [Int(f"{prefix}_x{i}") for i in range(3 * (resolution_groups - 3))]
    for label in extra:
        solver.add(And(label >= 0, label < label_count))
    solver.add(Distinct(*(labels + extra)))
    for group in range(resolution_groups - 3):
        group_labels = extra[3 * group:3 * group + 3]
        for token in range(len(supports[0])):
            solver.add(Sum([
                If(Or(*[And(label == value, supports[value][token])
                        for value in range(label_count)]), 1, 0)
                for label in group_labels
            ]) == 1)

    return labels, extra


def selected(label, supports, token):
    return Or(*[
        And(label == value, supports[value][token])
        for value in range(len(supports))
    ])


def main():
    solver = Solver()
    solver.set(timeout=20 * 60 * 1000)

    # incidence[e][r] says product coordinate e is incident with new vertex r.
    incidence = [[Int(f"i_{e}_{r}") for r in range(9)] for e in range(9)]
    for e in range(9):
        for r in range(9):
            solver.add(Or(incidence[e][r] == 0, incidence[e][r] == 1))
        solver.add(Sum(incidence[e]) == 2)
    for r in range(9):
        solver.add(Sum(incidence[e][r] for e in range(9)) == 2)
    # No loop: the two incidences of one proper coordinate go to two vertices.
    # Symmetry break one endpoint of the first coordinate.
    solver.add(incidence[0][0] == 1)

    all_factor_data = []

    star_supports = tuple(
        tuple(name in column for name in STAR_NAMES) for column in STAR_COLUMNS
    )
    star_missing = []
    for r in range(9):
        if r < 2:
            missing = STAR_SPLITS[0]
        elif r < 4:
            missing = STAR_SPLITS[1]
        else:
            missing = {name for name in STAR_NAMES if r - 3 in STAR_BOUNDARY[name]}
        star_missing.append(tuple(name in missing for name in STAR_NAMES))
    labels, extra = add_factor(solver, "star", star_supports, star_missing, 4)
    all_factor_data.append(("star", labels, extra, star_supports, star_missing))

    for factor_index, (left, right) in enumerate(private_factors()):
        # Tokens: two triple occurrences, then the four singleton occurrences.
        boundaries = (
            set(P) - set(left), set(P) - set(right),
            {left[0]}, {left[1]}, {right[0]}, {right[1]},
        )
        pair_values = tuple(combinations(range(6), 2))
        supports = tuple(
            tuple(token in pair for token in range(6)) for pair in pair_values
        )
        missing_sets = []
        for r in range(9):
            if r < 2:
                missing = {2, 3}
            elif r < 4:
                missing = {4, 5}
            else:
                terminal = r - 3
                missing = {token for token, boundary in enumerate(boundaries)
                           if terminal in boundary}
            assert len(missing) == 2
            missing_sets.append(tuple(token in missing for token in range(6)))
        labels, extra = add_factor(
            solver, f"f{factor_index}", supports, missing_sets, 5
        )
        all_factor_data.append(
            (f"{left}-{right}", labels, extra, supports, missing_sets)
        )

    # At each new vertex and in every factor, the two incident product
    # coordinates partition the complement of the third-incidence support.
    for _, labels, _, supports, missing_sets in all_factor_data:
        for r in range(9):
            for token, missing in enumerate(missing_sets[r]):
                solver.add(Sum([
                    If(And(incidence[e][r] == 1,
                           selected(labels[e], supports, token)), 1, 0)
                    for e in range(9)
                ]) == (0 if missing else 1))

    result = solver.check()
    print("status", result)
    if result != sat:
        print("FIXED_NOTE072_TRIVALENT_TRADE_UNDECIDED_OR_UNSAT")
        return

    model = solver.model()
    endpoints = []
    for e in range(9):
        endpoints.append(tuple(r for r in range(9)
                               if model.eval(incidence[e][r]).as_long()))
    print("right_names", RIGHT_NAMES)
    print("trade_endpoints", endpoints)
    for name, labels, extra, _, _ in all_factor_data:
        chosen = tuple(model.eval(label).as_long() for label in labels)
        completion = tuple(model.eval(label).as_long() for label in extra)
        print("factor", name, "trade", chosen, "resolution_tail", completion)
    print("FIXED_NOTE072_TRIVALENT_TRADE_SAT")


if __name__ == "__main__":
    main()
