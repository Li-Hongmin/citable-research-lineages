# Companion endpoint routes for a one-cycle third-matching exchange

This is a disposable controller derivation following Note 039.

Let

\[
(P,R,Q),\qquad(P',R',Q')
\]

be two Tait triples of the same cubic graph or pole.  Assume \(P,P'\)
have the same singleton boundary and \(R,R'\) have the same singleton
boundary.  Put

\[
C=Q\triangle Q',\qquad
D_P=P\triangle P',\qquad
D_R=R\triangle R'.
\]

## Companion-route identity

Because both triples partition the full edge set,

\[
P\triangle R\triangle Q
=P'\triangle R'\triangle Q'=E.
\]

Consequently

\[
\boxed{D_P\triangle D_R=C.} \tag{1}
\]

Both \(D_P,D_R\) are internal even subgraphs.  Equation (1) gives the
edgewise statements

\[
D_P\setminus C=D_R\setminus C=:Z, \tag{2}
\]

and

\[
(D_P\cap C)\mathbin{\dot\cup}(D_R\cap C)=C. \tag{3}
\]

Thus the nonlocal part of a one-role endpoint exchange is not arbitrary:
it occurs identically in the companion role.

## Single-cycle normal form

Assume \(C\) is one internal cycle.  At a vertex outside \(C\), \(Z\)
has degree zero or two.  At a vertex of \(C\), cubicity gives
\(\deg_Z\in\{0,1\}\).  Hence \(Z\) is a vertex-disjoint union of internal
cycles and paths whose distinct endpoints lie on \(C\).

Every cycle component \(W\) of \(Z\) is an ordinary internal Kempe cycle:
outside \(C\), the old and new endpoint colours are exchanged on \(W\)
in both roles.  Replacing

\[
(P',R')\longmapsto(P'\triangle W,R'\triangle W)
\]

keeps \(Q'\), all boundary data, and the Tait partition fixed, while
removing \(W\) from both \(D_P,D_R\).  Repeating gives a normalized
representative in which \(Z\) consists only of vertex-disjoint paths
pairing vertices of \(C\).

At a nonendpoint of \(Z\), one of \(D_P,D_R\) uses both incident
\(C\)-edges and the other uses neither.  At an endpoint of \(Z\), each
uses one incident \(C\)-edge.  Therefore the \(C\)-edge assignment
switches exactly at the endpoints of \(Z\).  Given the path linkage
\(Z\), there are precisely two complementary phase assignments on
\(C\), corresponding to interchanging the endpoint roles.

Thus every normalized one-cycle transition is encoded by

1. a vertex-disjoint external linkage \(Z\) between an even subset of
   vertices of \(C\); and
2. one binary phase on \(C\).

This is an exact reduction of the endpoint-routing datum required by
Note 039.

## The first one-role repair from Note 039

For the displayed order-seventeen repair,

\[
\begin{aligned}
C&=\{e_7,e_8,e_9,e_{11},e_{12},e_{15}\},\\
D_P&=\{e_2,e_3,e_8,e_{11},e_{12},e_{15}\}.
\end{aligned}
\]

Equation (1) forces

\[
D_R=C\triangle D_P
=\{e_2,e_3,e_7,e_9\}.
\]

With the stored proper-edge ordering,

\[
e_2=1\,5,\quad e_3=1\,7,
\]

so the common external route is the path

\[
Z=5-1-7
\]

joining two vertices of the third-matching cycle

\[
C=5-6-7-8-9-15-5.
\]

The selected role uses the complementary \(C\)-arc
\(5-15-9-8-7\), giving its six-cycle \(D_P\); the companion role uses
the arc \(5-6-7\), giving its four-cycle \(D_R\).

## Exact boundary

The identity does not by itself prove radius-one capacity rounding.
The signed update still depends on which endpoint route is selected and
on the old multiplicities along its two alternating halves.  What it
does prove is that the extra data missing from a \(C\)-local description
is a constrained external linkage, not an arbitrary perfect-matching
symmetric difference.

A general positive theorem may now be stated as an endpoint-linkage
selection problem: choose a realizable normalized \(Z\) and one of its
two phases so that the signed multiplicity conditions of Note 039(4)--(5)
hold.  Any approach recording only \(C\) and local exits, but not this
linkage, remains incomplete.
