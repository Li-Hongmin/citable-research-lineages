# Cross-column D5 join: half-load saturation leaves one synchronization gate

## Scope

Fix

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Let \(H\) be one simple connected cubic \(5\)-pole.  Assume that no
\(T\)-loop and no \(T\)--\(T\) Berge--Fulkerson type is present.  For each
\(t\in T\), assume that an actual \(S\)--\(T\) witness has been split as

\[
 A_t=Q_s+P_i+P_j,
 \qquad 2\mathbf 1-A_t=R_t+P_k+P_\ell,
 \]

and that the decomposition-state set
\(\mathcal R(A_t)\) is the saturated set \(S\).  The question is whether
these hypotheses force a four-of-five D5 singleton-cylinder join.

This note only uses actual perfect matchings and their alternating
cycle/path differences.  It does not introduce a load-only relation model,
scan graph orders, or search literature.

## What the hypotheses do prove

For a fixed \(t\), \(A_t\) is a genuine load-two complement pair.  If a
decomposition of \(A_t\) had state \(r\in T\), combining it with the fixed
decomposition of \(2\mathbf1-A_t\) would give a forbidden \(T\)-loop when
\(r=t\), or a forbidden \(T\)--\(T\) type when \(r\ne t\).  Hence

\[
 \mathcal R(A_t)\cap T=\varnothing.
\]

The given state \(s\in S\) and the five-state Kempe closure then give

\[
 \mathcal R(A_t)=S.
\]

Keeping the \(T\)-half fixed while varying the five decompositions of \(A_t\)
therefore saturates the entire \(S\times\{t\}\) support column.  Repeating
this independently for the five \(t\)'s yields five actual carrier columns,
but it yields no equality between their load vectors \(A_t\), their
singleton fibres, or their alternating paths.

## Exact location of the missing quantifier

For the D5 cell \(d_t=(s_t,t)\), let

\[
 \widehat\Pi_t\subseteq\prod_{i\ne m(t)}\mathcal P_i
\]

be the actual four-singleton witness relation (after the standard
\(S\)--\(T\) to disjoint \(S\)--\(S\) path toggle), and let \(\Pi_t\) be its
five-coordinate cylinder.  A four-cell join asks for some

\[
 \bigcap_{t\ne t_0}\Pi_t\ne\varnothing .
\]

The saturation statement says only that each \(\widehat\Pi_t\) is nonempty
(indeed, that the *other* four rows in its carrier rectangle are
nonempty).  It does not identify a tuple in two different
\(\widehat\Pi_t\)'s.  If two witnesses in different columns are subtracted,
the result is a sum of signed proper alternating cycles, together with the
two terminal alternating paths from the triple matchings.  The cubic vertex
equations give only the edgewise cancellation identity

\[
 (\chi_{Q'_s}-\chi_{Q_s})+(\chi_{Q'_t}-\chi_{Q_t})
 +\sum_i(\chi_{P'_i}-\chi_{P_i})=0,
\]

with the repeated singleton slots kept as distinct occurrences.  Nothing in
this identity forces any common \(P_i\) across columns.  A change in the
missing singleton can be absorbed by the two triple differences on proper
alternating components.  Thus the only implication still needed is exactly

\[
 \text{five saturated actual carrier columns}
 \Longrightarrow
 \text{one four-column singleton join},
\]

and no within-column Kempe argument supplies it.

## Strict weaker sufficient condition (for reference)

The following additional condition is sufficient and is strictly weaker
than requiring a rectangular section of all twenty-five cells.  Choose a
four-cell set \(J\), an anchor \(a\in J\), and an actual anchor tuple
\(x\in\widehat\Pi_a\).  Let \(m\) be the missing coordinate of \(a\), and
for each \(d\in J\setminus\{a\}\) define the actual extension fibre

\[
 E_d(x)=\{P\in\mathcal P_m:
 \text{some }y\in\widehat\Pi_d\text{ agrees with }x
 \text{ on }U_a\cap U_d\text{ and uses }P\text{ at }m\}.
\]

If the three \(E_d(x)\) are nonempty connected subtrees of the genuine
single-cycle exchange graph on \(\mathcal P_m\), and that exchange graph is
a tree, then pairwise intersection of the three fibres implies their common
intersection by the tree Helly property.  The pivot identity

\[
 x\text{ extends through all four cells}
 \Longleftrightarrow
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing
\]

then gives the D5 join.  The usual four-cell load argument yields the
\(A=(12345)\) cover.  This is an actual-PM condition, but pairwise fibre
intersection and exchange convexity are not consequences of half-load
saturation.

## Four-value decision

* General proof of the cross-column implication: **not obtained**.
* Real cubic-pole counterexample satisfying the stated hypotheses: **not
  obtained**.
* What is established here is **route closure**: no-\(T\)-loop/no-\(T\)--\(T\)
  plus \(\mathcal R(A_t)=S\) spends all available within-column Kempe information
  and does not identify any cross-column singleton-fibre values in the
  displayed incidence equations.

The statement therefore remains undecided at the real-pole level.  Any
positive proof must add a cross-column incidence theorem (for example the
tree-exchange/Helly condition above, or an equivalent witness-reuse lemma);
any negative result must realize all five carrier columns in one genuine pole
and make every four-cell join empty.

## Why the natural carrier holonomy is not the missing theorem

There is a genuine matching-level holonomy inside one saturated carrier,
but its quantifiers stop one level too early.  For a fixed half-load \(A\)
with \(\mathcal R(A)=S\), let

\[
 \mathcal D_{ij}(A)=\{(Q_{ij},P_i,P_j):
 A=\chi_{Q_{ij}}+\chi_{P_i}+\chi_{P_j}\}
 \qquad(ij\in S).
\]

If \(ij,kj\) are the two members of \(S\) containing \(j\), switching the
triple/singleton bichromatic terminal path in the cubic multigraph \(H_A\)
maps a member of \(\mathcal D_{ij}(A)\) to one of
\(\mathcal D_{kj}(A)\) while leaving the actual matching \(P_j\) unchanged.
The switch is reversible.  Allowing the independent proper alternating
cycles gives the full matching relation

\[
 K_j(A)\subseteq \mathcal D_{ij}(A)\times\mathcal D_{kj}(A)
\]

of adjacent decompositions which share the same actual singleton matching
at \(j\).  Going once around the \(S\)-pentagon gives a relational holonomy.
A fixed point is exactly a coherent five-state decomposition of this one
load, with one singleton value reused at each adjacent pair of states.
Indeed, after the common colour class \(P_j\) is removed from \(H_A\), the
remaining degree-two multigraph has only alternating terminal paths and
proper even cycles.  Two decompositions with the same \(P_j\) differ
precisely by interchanging the other two colours on a selection of these
components.  The boundary change \(ij\to kj\) forces the unique
\(i\)--\(k\) terminal path and leaves the proper cycles free.

This fixed point is **not** the D5 join condition.  The five Case-XII
columns may have five different loads \(A_t\).  A fixed point for each
\(K(A_t)\) produces five carrier-dependent singleton tuples, but gives no
equality between a tuple belonging to \(A_t\) and one belonging to
\(A_{t'}\).  It also says nothing about the fixed singleton matchings in
the complementary \(T\)-halves.  Conversely, a four-column D5 join may use
four different loads and therefore need not determine a fixed point in any
single carrier holonomy.  Thus the two assertions are not equivalent, and
the within-carrier fixed-point condition cannot be promoted as the missing
cross-column theorem.

The exact fixed-point object at the correct quantifier level is instead the
pivot intersection already displayed above: after an anchor tuple is fixed,

\[
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing .
\]

This is necessary and sufficient for an anchored four-column join.  In the
unique-extension case it is equivalent to two agreement edges connecting
the three extension values.  Under the tree-exchange hypotheses it follows
from pairwise intersection by the tree Helly property.  Those are strict
additional conditions on *cross-column actual matching equality*; neither
is implied by carrier saturation or by its holonomy.

Accordingly the within-carrier Kempe/holonomy route is exhausted.  The
remaining real-pole question is exactly whether the universal absence of
\(T\)-loops and \(T\)--\(T\) covers forces the pivot intersection for at
least one four-column family.  No proof or genuine-pole counterexample to
that implication is presently obtained.
