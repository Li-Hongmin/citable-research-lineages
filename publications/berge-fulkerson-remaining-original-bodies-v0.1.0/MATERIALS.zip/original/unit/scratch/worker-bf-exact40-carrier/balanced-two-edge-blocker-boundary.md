# Balanced two-edge blocker: a real clean-witness boundary

## Decision

This pulse does **not** prove or refute the real exact-40 Case-XII
implication.  It supplies a sharper fixed real-incidence boundary.  In the
order-13 all-
`S--T` pole from `verify_cubic_all_ss_realization.py`, each of two literal
two-edge sets is a balanced blocker for the *complete* perfect-matching
family, and the blocker forces three positive `S--T` cells to have no
Tait-clean witness.  The pole has all 25 positive cells and no `A` cover, but
its Tait state set is `K_5`, so extra `T`-loop and `T--T` fibres remain.  It is
therefore not an exact-40 pole.

## Balanced blocker identity

With the standard edge table, put

\[
B_1=\{e10,e2\}=\{(5,7),(1,7)\},\qquad
B_2=\{e6,e8\}=\{(3,10),(4,10)\}.
\]

The complete 37-PM closure satisfies, for each \(r\in\{1,2\}\),

\[
 |P\cap B_r|=1\quad(P\in\mathcal P_i,;i=1,\ldots,5),
\qquad
 |Q\cap B_r|=0\quad(Q\in\mathcal Q_{ij},;ij\in\binom{[5]}2).
\tag{1}
\]

Thus each \(B_r\) gives the exact two-edge Farkas inequality

\[
\sum_i\min_{P\in\mathcal P_i}|P\cap B_r|=5>4=2|B_r|.
\tag{2}
\]

Moreover, in any six-matching witness of any positive Case-XII type, the
four singleton occurrences contribute at least four incidences on \(B_r\),
while the target double cover contributes exactly four.  By (1), equality
is forced: every singleton occurrence uses exactly one blocker edge and both
triple occurrences avoid the blocker.  This is a genuine common-PM
incidence statement, not an aggregate load relaxation.

## Clean-witness census on the fixed pole

For each of the 25 actual `S--T` cells, all six-PM witnesses in the complete
37-PM family were enumerated.  A witness is called clean at its `T` endpoint
if it contains no triple

\[
P_i+P_j+Q_t=\mathbf 1,
\qquad t=ij\in T,
\tag{3}
\]

with the two singleton occurrences at the endpoints of `t`.  Equation (3)
would double to a forbidden `T`-loop.  For **both** \(B_1\) and \(B_2\),

\[
\begin{array}{c|c|c}
\text{cell}&\text{all witnesses}&\text{clean witnesses}\\ \hline
(12)(25)&3&0\\
(23)(24)&3&0\\
(24)(34)&3&0
\end{array}
\]

and every other 22 cells has at least one clean witness (the full positive
support is 25/25).  Hence this real pole exhibits the exact mechanism

\[
\text{balanced blocker}\;\Longrightarrow\;
\text{some positive cell has no Tait-clean witness},
\]

but only as a fixed instance.  The mechanism is witnessed by the same
actual PM identities across all cells; no formal vector or private-witness
model is used.

## Remaining exact-40 interface

In a genuine exact-40 pole, no `T` loop exists, so every positive `S--T`
witness must be clean.  The fixed calculation therefore isolates the
unproved implication needed to exclude a balanced blocker:

\[
\text{exact-40 support} + \text{balanced blocker}
\Longrightarrow
\text{one of the 25 cells is non-clean}.
\tag{4}
\]

No argument deriving (4) from common cubic vertex incidence is known.  The
fixed pole cannot serve as a counterexample to (4), because it is not
exact-40.  Thus the correct four-valued decision for this pulse is:

* no general proof;
* no real exact-40 counterexample;
* a sharp fixed-instance blocker/clean-witness boundary;
* the remaining interface is (4), not another order census.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-exact40-carrier/balanced_two_edge_blocker_clean_boundary.py
```

The terminal line is

```text
BALANCED_TWO_EDGE_BLOCKER_CLEAN_BOUNDARY_VERIFIED
```
