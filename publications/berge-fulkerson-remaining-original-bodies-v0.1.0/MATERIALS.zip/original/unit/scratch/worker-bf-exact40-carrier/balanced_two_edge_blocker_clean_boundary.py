#!/usr/bin/env python3
"""Fixed real boundary for the balanced two-edge-blocker route.

This is deliberately a one-pole calculation.  It uses the order-13
all-S--T pole from ``verify_cubic_all_ss_realization.py`` and enumerates the
complete perfect-matching family.  The two disjoint proper edge pairs are
literal balanced blockers: every singleton PM uses exactly one of the two
edges and every triple PM uses neither.  All 25 S--T cells are present.

For each S--T witness we then test whether its T-end triple PM together with
the two singleton occurrences at the T endpoints is itself a Tait partition.
The three cells reported with zero clean witnesses are a finite, genuine
common-incidence boundary for the exact-40 question.  The pole is not
exact-S (its Tait state set is K5), so this is not a Case-XII counterexample.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations_with_replacement, product
from pathlib import Path
import importlib.util
import sys


ROOT = Path(__file__).resolve().parents[4]
SHARED = ROOT / "units/berge-fulkerson/scratch/worker-kempe"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


JOINT = load("balanced_blocker_joint", SHARED / "exact_st_joint_audit.py")
FROZEN = load("balanced_blocker_frozen", SHARED / "verify_cubic_all_ss_realization.py")

S = JOINT.S
T = JOINT.T
ALL_TYPES = tuple(sorted(JOINT.PAIR_TYPES))
POSITIVE_TYPES = tuple(
    kind
    for kind in ALL_TYPES
    if (kind[0] == kind[1] and kind[0] in S)
    or (kind[0] != kind[1] and (kind[0] in S or kind[1] in S))
)

# Edge indices in JOINT's lexicographically sorted edge table.  These are the
# two literal blockers (e10,e2) and (e6,e8), written as edge-table indices.
BLOCKERS = ((2, 9), (13, 15))


def normalized_data():
    pole = FROZEN.check_pole()
    raw = JOINT.matching_data(pole)
    edges, edge_vertices, edge_position, incidence, raw_classes, pm_count = raw
    classes = {key: tuple(frozenset(m) for m in value) for key, value in raw_classes.items()}
    boundary_of = {
        matching: key
        for key, family in classes.items()
        for matching in family
    }
    return pole, edges, edge_vertices, edge_position, incidence, classes, boundary_of, pm_count


def all_witnesses(kind, classes, edge_count):
    """Return records (q0,q1,slots,singletons) for one boundary type."""
    first, second = kind
    first_family = classes[JOINT.complement(first)]
    second_family = classes[JOINT.complement(second)]
    triples = (
        combinations_with_replacement(first_family, 2)
        if first == second
        else product(first_family, second_family)
    )
    slots = list(first + second)
    records = []
    for q0, q1 in triples:
        base_load = Counter(q0)
        base_load.update(q1)
        if any(value > 2 for value in base_load.values()):
            continue
        for singleton_tuple in product(*(classes[(i,)] for i in slots)):
            load = base_load.copy()
            for matching in singleton_tuple:
                load.update(matching)
            if all(load[edge] == 2 for edge in range(edge_count)):
                records.append((q0, q1, tuple(slots), singleton_tuple))
    return tuple(records)


def has_tait_triple(record, t, boundary_of, all_edges):
    """Whether a witness contains a Tait partition at its T endpoint."""
    q0, q1, slots, singletons = record
    target_class = JOINT.complement(t)
    q_candidates = [q for q in (q0, q1) if boundary_of[q] == target_class]
    choices = [
        [m for position, m in zip(slots, singletons) if position == i]
        for i in t
    ]
    for q in q_candidates:
        for p_i, p_j in product(*choices):
            if (
                q.isdisjoint(p_i)
                and q.isdisjoint(p_j)
                and p_i.isdisjoint(p_j)
                and set(q) | set(p_i) | set(p_j) == all_edges
            ):
                return True
    return False


def main():
    _, edges, _, _, _, classes, boundary_of, pm_count = normalized_data()
    edge_count = len(edges)
    all_edges = set(range(edge_count))
    assert pm_count == 37
    assert set(POSITIVE_TYPES) == set(
        kind
        for kind in ALL_TYPES
        if (kind[0] == kind[1] and kind[0] in S)
        or (kind[0] != kind[1] and (kind[0] in S or kind[1] in S))
    )

    records_by_type = {kind: all_witnesses(kind, classes, edge_count) for kind in ALL_TYPES}
    st_types = tuple(sorted(tuple(sorted((s, t))) for s in S for t in T))
    assert all(records_by_type[kind] for kind in st_types)

    output = {
        "perfect_matchings": pm_count,
        "singleton_class_sizes": [len(classes[(i,)]) for i in range(1, 6)],
        "blockers": [],
    }

    for blocker in BLOCKERS:
        B = set(blocker)
        singleton_weight_sets = {
            i: sorted({sum(edge in matching for edge in B) for matching in classes[(i,)]})
            for i in range(1, 6)
        }
        triple_weight_sets = {
            pair: sorted({
                sum(edge in matching for edge in B)
                for matching in classes[JOINT.complement(pair)]
            })
            for pair in JOINT.PAIR_SET
        }
        assert all(weights == [1] for weights in singleton_weight_sets.values())
        assert all(weights == [0] for weights in triple_weight_sets.values())

        cell_rows = []
        for kind in st_types:
            first, second = kind
            t = second if second in T else first
            witnesses = records_by_type[kind]
            # The balanced blocker forces this for every witness, not merely
            # for a selected witness: four singleton contributions already
            # meet the total load 4 on B, while both triples avoid B.
            for q0, q1, slots, singleton_tuple in witnesses:
                assert all(sum(edge in m for edge in B) == 1 for m in singleton_tuple)
                assert sum(edge in q0 for edge in B) == 0
                assert sum(edge in q1 for edge in B) == 0
            nonclean = sum(
                has_tait_triple(record, t, boundary_of, all_edges)
                for record in witnesses
            )
            cell_rows.append({
                "type": JOINT.human(kind),
                "witnesses": len(witnesses),
                "tait_clean_witnesses": len(witnesses) - nonclean,
                "nonclean_witnesses": nonclean,
            })
        assert sum(row["tait_clean_witnesses"] == 0 for row in cell_rows) == 3
        output["blockers"].append({
            "edge_table_indices": list(blocker),
            "edge_names": [edges[index] for index in blocker],
            "singleton_weight_sets": singleton_weight_sets,
            "triple_weight_sets": {
                str(pair): weights for pair, weights in triple_weight_sets.items()
            },
            "zero_clean_cells": [
                row["type"] for row in cell_rows if row["tait_clean_witnesses"] == 0
            ],
            "cells": cell_rows,
        })

    # The frozen pole is a genuine near miss: full positive S--T support and
    # no A-cover, but it has all Tait states and therefore extra forbidden BF
    # fibres.  Record this explicitly so the certificate cannot be mistaken
    # for an exact-40 counterexample.
    output["full_ST_support"] = len(
        {kind for kind in st_types if records_by_type[kind]}
    )
    output["has_A_cover"] = JOINT.capacity_witness(
        (edges, {i: list(v) for i, v in classes.items() if len(i) == 1},
         None, None, classes, pm_count)
    ) is not None
    output["tait_states"] = sorted(FROZEN.joint.base.legacy.enumerate_tait_states(FROZEN.check_pole()))
    assert output["full_ST_support"] == 25
    assert not output["has_A_cover"]
    assert len(output["tait_states"]) == 10

    print(output)
    print("BALANCED_TWO_EDGE_BLOCKER_CLEAN_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
