# The seven-cut one-shore quota and its two-vertex connector (draft)

The all-orders complementary whole-host seven-pole quota below is
recorded in [Note 211](../notes/211-the-seven-cut-complement-has-only-one-and-three-port-matchings.md).

This analytic reduction is in the connected deficient-core, minimum-host, exact-Case-XII setting of [Note 169](../notes/169-minimal-tutte-barrier-has-three-odd-shore-profiles.md). It concerns the normalized Tutte-barrier profile with one odd component \(C\) whose \(J\)-cut has seven edges and contains no internal marked edge; the remaining odd components are singletons. It does not assert that this profile occurs.

**Provisional all-orders conclusion.** When the smallest maximum barrier has two vertices, its one-seven-cut-shore profile is impossible under full exact Case-XII support. The three relative pentagon placements \(k=2,1,0\) are all excluded below using actual six-matching rows, fixed complete shore matchings, and alternating-path switches. The last \(k=0\) route closes by comparing the same shore restriction in two decompositions of one \(S\)-only half-load. The two-vertex five-cut and two-five-cut profiles, larger barriers, and the perfectly matchable \(F\) branch are not covered. These analytic exclusions have not yet had an independent check.

**All-orders matching quota.** Let \(U\) be a smallest maximum barrier, \(q=|U|+2\) the number of odd components of \(F-U\), and \(\lambda_K(N)\) the number of edges of a perfect matching \(N\) covering vertices of odd component \(K\) from outside \(F[K]\). Then every triple-boundary matching has
\[
\lambda_K(N)=1\quad\text{for every odd component }K.       \tag{1}
\]
Every singleton-boundary matching has
\[
\lambda_C(N)=3,\qquad
\lambda_K(N)=1\quad(K\ne C).                                \tag{2}
\]

Indeed, each \(u\in U\) is matched to an odd component. Each active mark chooses one endpoint in an odd component because all marks join distinct components. Thus the sum of the \(\lambda_K\) is \(|U|+2\) for a triple-boundary matching and \(|U|+4\) for a singleton-boundary matching. Each \(\lambda_K\) is a positive odd integer. There are \(|U|+2\) components, so the first sum forces (1), and the second has one extra two. A singleton component consists of one vertex and cannot have three matching incidences; hence the extra two belongs to \(C\), proving (2). In an actual six-matching BF row, the cut of \(C\) consequently receives two one-hit and four three-hit occurrences, totalling \(14=2|\delta_J(C)|\).

**Complementary whole-host seven-pole.** Open the seven-edge cut
of \(C\) in the complete minimum host \(G\), leaving the original
opposite pentagon on the other side, and call that side \(E(C)\).
This is a different seven-pole from the original Case-XII side.
Put \(k=|U|\). In a perfect matching of \(E(C)\), let \(b\)
count its selected cut semiedges, \(a\) those at \(U\)-vertices,
and \(h\) the edges from marked subdivision vertices to the
original pentagon. The \(k-a\) other \(U\)-vertices and the
\(5-(b-a)-h\) marked subdivision vertices matched into the core
must cover exactly the \(k+1\) singleton odd components of
\(F-U\), once each. Therefore
\[
\boxed{b+h=4.}                                             \tag{C}
\]
Both \(b,h\) are positive odd integers, so \((b,h)=(1,3)\) or
\((3,1)\). In particular \(E(C)\) has **no matching with five or
seven cut ports**. Any actual six-matching BF row on this seven-pole
must have four triple-boundary and two singleton-boundary occurrences:
their fourteen terminal loads give \(n_1+3n_3=14\) and
\(n_1+n_3=6\). This is an all-orders single-matching/row quota on
the alternative whole-host shore, not a BF support classification
or an exclusion of the seven-cut profile at \(|U|\ge3\).

**Two-vertex connector.** Suppose \(|U|=2\). Write \(U=\{u_1,u_2\}\). Since each \(u_i\) meets three distinct odd components, it sends at most one unmarked edge into \(C\), so \(r=|E_F(U,C)|\le2\). The seven-edge \(J\)-cut of \(C\) uses at most all five marked edges, hence \(r\ge2\). Thus \(r=2\), one from each \(u_i\), and all five marks cross from \(C\) to the three singleton components.

The four remaining \(U\)-singleton incidences distribute as \((2,1,1)\). Each singleton has at least one such incidence: otherwise all three of its core edges would be marked, contrary to [Note 157](../notes/157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md). Each has at most two, one from each \(u_i\). Call the shared singleton \(w_0\), and the private ones \(w_1,w_2\), with \(u_iw_i\in F\). The unmarked exterior is exactly the path
\[
w_1-u_1-w_0-u_2-w_2,                                      \tag{3}
\]
plus \(h_i=u_iv_i\) into \(C\), with \(v_1\ne v_2\) by girth five. Up to relabelling, mark \(a\) joins \(w_0\) to \(C\); marks \(b,d\) join \(w_1\) to \(C\); and marks \(c,e\) join \(w_2\) to \(C\). No marked edge joins two exterior singletons or lies in \(C\).

**Exact triple-boundary criterion for this connector.** Let \(I_x=1\) when \(F[C]-x\) has a perfect matching. Put \(I_a,I_b,I_c,I_d,I_e\) for the five marked \(C\)-endpoints and \(H_i=I_{v_i}\). A triple state \(ij\) means that \(i,j\) are the two missing terminals. Its complete support is
\[
\begin{array}{c|c}
\text{missing pair}&\text{state exists iff}\\\hline
bd&I_b\lor I_d\\
ce&I_c\lor I_e\\
ax,\ x\in\{b,d\}&I_a\lor I_x\lor H_1\\
ay,\ y\in\{c,e\}&I_a\lor I_y\lor H_2\\
xy,\ x\in\{b,d\},\ y\in\{c,e\}
&I_x\lor I_y\lor H_1\lor H_2.
\end{array}                                                 \tag{4}
\]
Every listed alternative is realized by extending a matching of \(F[C]\) after deleting the corresponding shore vertex. There are no other alternatives, by (1): a triple matching exposes exactly one vertex of \(C\). For \(bd\), one mark selects \(w_1\) and the other enters \(C\); the remaining exterior path is matched by \(u_1w_0,u_2w_2\). The \(ce\) case is symmetric. For \(ax\) with \(x\) at \(w_1\), selecting \(a\) into \(C\), \(x\) into the exterior gives \(u_1w_0,u_2w_2\); reversing those choices gives \(u_1w_1,u_2w_2\); selecting both exterior endpoints gives \(h_1,u_2w_2\). The \(ay\) routes are reflected. For \(xy\) on opposite private singletons, choosing exactly one shore endpoint gives one of the two path matchings; choosing both exterior endpoints leaves the three vertices \(u_1,w_0,u_2\), which are matched by either \(h_1,u_2w_0\) or \(u_1w_0,h_2\).

The ten triple states therefore depend only on the seven one-vertex deletion predicates in (4). Complete triple support is weaker than an actual BF row: the four singleton-boundary matchings of every row must each meet \(C\) at three ports by (2), with all proper edge loads exactly two. This is the next full-closure interface.

**Exact singleton-boundary route criterion.** Let \(t\) be the unique terminal used by a singleton-boundary matching, and \(A_t=\{a,b,c,d,e\}\setminus\{t\}\) its four active marks. Choose \(E\subseteq A_t\) to select exterior endpoints, with at most one chosen mark at each of \(w_0,w_1,w_2\), and choose \(H\subseteq\{h_1,h_2\}\). The complete list of exterior matchings is
\[
\begin{array}{c|c|c}
H&\text{locations of marks in }E&\text{remaining unmarked exterior edge(s)}\\\hline
\varnothing&\{w_0\}&u_1w_1,\ u_2w_2\\
\varnothing&\{w_1\}&u_1w_0,\ u_2w_2\\
\varnothing&\{w_2\}&u_1w_1,\ u_2w_0\\
\{h_1\}&\{w_0,w_1\}&u_2w_2\\
\{h_1\}&\{w_1,w_2\}&u_2w_0\\
\{h_2\}&\{w_0,w_2\}&u_1w_1\\
\{h_2\}&\{w_1,w_2\}&u_1w_0\\
\{h_1,h_2\}&\{w_0,w_1,w_2\}&\varnothing.
\end{array}                                                    \tag{5}
\]
For each row the three selected shore port **edges** are
\[
Q=(A_t\setminus E)\cup H.                              \tag{6}
\]
The singleton matching exists with this exterior route if and only if the three \(C\)-endpoints of \(Q\) are distinct and \(F[C]\) after deleting those endpoints has a perfect matching. Necessity follows from (2) and matching the five exterior path vertices; sufficiency follows by adjoining that shore-deletion matching. No singleton route outside (5) exists: if \(|H|=\ell\), equation (2) forces \(|E|=1+\ell\), and the five-vertex path then leaves exactly the unmarked edges displayed.

In an actual six-matching BF row, let \(\tau(g)\in\{0,1,2\}\) count how many of its two triple occurrences use a given shore port \(g\) among the seven cut edges. Its four singleton occurrences must use that port exactly \(2-\tau(g)\) times. Thus the complete row constraint is a coupling of the two one-deletion routes (4) with four three-deletion routes (5) at **each** of seven specific edges, plus the internal edges of \(F[C]\); triple-state existence alone does not satisfy it.

**Endpoint-load gate for every pentagon placement.** Let \(D\) be any three-matching half-load with one terminal occurrence at each label and \(\varnothing\ne\mathcal R(D)\subseteq S\), where \(S\) is any allowed missing-pair five-cycle. [Note 055](../notes/055-half-load-column-saturation-and-case-xii-compression.md) gives \(\mathcal R(D)=S\). More generally, at any core vertex incident with two distinct marked edges \(p,q\) and one unmarked edge \(g\), the independence number \(\alpha(C_5)=2\) gives an \(S\)-state disjoint from \(\{p,q\}\). Its triple matching uses terminals \(p,q\), so that matching must use \(g\). Thus \(D(g)>0\). At \(w_1,w_2\), this gives
\[
\varnothing\ne\mathcal R(D)\subseteq S
\quad\Longrightarrow\quad D(w_1u_1)>0\quad\text{and}\quad D(u_2w_2)>0.
\]
This conclusion concerns the **same complete half-load** across its five decompositions. If two complementary half-loads both have an \(S\)-state, but one has zero load on \(w_1u_1\) and the other zero load on \(u_2w_2\), each must also have a \(T\)-state. Their two \(T\)-decompositions then form a forbidden actual BF row.

**Three relative pentagon placements.** Relabellings of the exterior quotient exchange \(b,d\), exchange \(c,e\), and reflect the path while exchanging the two private pairs; the attachments in \(C\) are relabelled along with their marks. The twelve Hamilton cycles \(S\) on the five marks split into three orbits, indexed by
\[
k=|S\cap\{bd,ce\}|\in\{0,1,2\}.                      \tag{7}
\]
Representatives are
\[
\begin{array}{c|c}
k&S\\\hline
0&a-b-c-d-e-a\\
1&a-c-d-b-e-a\\
2&a-b-d-c-e-a.
\end{array}                                                    \tag{8}
\]
Each orbit has four cycles: four cycles contain both disjoint edges \(bd,ce\), four contain exactly one, and four contain neither. This reduces the full-closure test to three relative orders; the \(k=2\) order is excluded below by a fixed-shore pairing contradiction.

**A genuine cross-triple restriction in the \(k=2\) placement.** Fix the representative \(S=a-b-d-c-e-a\). The positive Case-XII cell \((bd)(ce)\) contains an actual BF row. In any such row, its \(bd\)-triple chooses exactly one exterior mark \(x\in\{b,d\}\) at \(w_1\), and its \(ce\)-triple chooses exactly one \(y\in\{c,e\}\) at \(w_2\). Their unmarked exterior path matchings are \(u_1w_0,u_2w_2\) and \(u_1w_1,u_2w_0\), respectively. Hence their symmetric difference has the wholly exterior alternating terminal path
\[
x-w_1-u_1-w_0-u_2-w_2-y.                           \tag{9}
\]
Switching the two triples along (9) and regrouping the original four singleton occurrences yields the following two BF states:
\[
\begin{array}{c|c|c}
(x,y)&\text{new missing pairs}&\text{support status}\\\hline
(b,c)&cd,\ be&S,\ T\\
(b,e)&de,\ bc&T,\ T\\
(d,c)&bc,\ de&T,\ T\\
(d,e)&be,\ cd&T,\ S.
\end{array}                                                   \tag{10}
\]
Thus the forbidden \(T\)--\(T\) support forces \((x,y)=(b,c)\) or \((d,e)\) in **every** actual \((bd)(ce)\) row. The surviving choices require the same-shore comparison below.

The same orientation constraint holds for the \(k=1\) representative \(S=a-c-d-b-e-a\): there \((bd)(ce)\) is a required \(S\)--\(T\) cell, \(bc,de\in T\), and the two crossed choices in (10) again create forbidden \(T\)--\(T\) rows. Its parallel choices give \(cd,be\in S\). No \((bd)(ce)\) row is required in the \(k=0\) representative because both of those states belong to \(T\).

In each of the \(k=1,2\) representatives, an \(S\)-preserving quotient relabelling exchanges the two surviving parallel choices. For \(k=1\), exchange \(b\leftrightarrow d\) and \(c\leftrightarrow e\); for \(k=2\), reflect the path with \(b\leftrightarrow e\), \(d\leftrightarrow c\). Thus a further analysis of this cell may take \((x,y)=(b,c)\) without losing a relative placement.

**The \(k=2\) placement is impossible at every order.** Fix \(S=a-b-d-c-e-a\), and use the preceding symmetry to take \((x,y)=(b,c)\) in a required actual \((bd)(ce)\) row. Write \(X\) for its \(bd\)-triple, \(U\) for its \(ce\)-triple, and \(Y,Z,V,W\) for its singleton-\(b,d,c,e\) matchings. Thus \(X\) selects \(b:w_1\), enters \(C\) through \(d\), and uses \(u_1w_0,u_2w_2\); \(U\) selects \(c:w_2\), enters \(C\) through \(e\), and uses \(u_1w_1,u_2w_0\). Switch the wholly exterior \(b\)--\(c\) component of \(X\triangle U\) to obtain \(X'\) at \(cd\in S\) and \(U'\) at \(be\in T\). Regroup as
\[
D_{cd}=X'+Z+V,\qquad D_{be}=U'+Y+W,
\qquad D_{cd}+D_{be}=2\mathbf1.
\]
Exact negative support makes \(\mathcal R(D_{cd})\subseteq S\). At \(w_2\), \(V\) has terminal \(c\), so it uses either \(e:w_2\) or \(u_2w_2\). The former makes the \(c\)-terminal component of \(X'\triangle V\) end at \(e\), producing \(de\in T\). Hence \(V\) uses \(u_2w_2\). At \(w_0\), it cannot use \(u_2w_0\) because \(u_2\) is occupied; if it used \(a:w_0\), the same component would end at \(a\), producing \(ad\in T\). Thus \(V\) uses \(u_1w_0\) and selects either \(b:w_1\) or \(d:w_1\). In the *original* \(ce\)-half, the \(c\)-terminal component of \(U\triangle V\) is now the wholly exterior path through \(w_2,u_2,w_0,u_1,w_1\) ending at \(b\) or \(d\). It produces \(be\) or \(de\), both in \(T\). Therefore the complementary original \(bd\)-half \(X+Y+Z\) must satisfy \(\mathcal R(X+Y+Z)\subseteq S\).

The edge \(u_2w_2\) is saturated by \(X,V\). At \(w_2\), \(U\) uses \(c:w_2\), while \(W\) has terminal \(e\) and cannot use \(e:w_2\); hence \(W\) also uses \(c:w_2\), and \(Y,Z\) both use \(e:w_2\). The triple \(X\) and its switched version \(X'\) have **identical complete matchings on \(C\)**, and \(Z\) is unchanged. In the exterior of \(X\triangle Z\), terminal \(c\) reaches the shore port \(c\) directly. Since the original \(bd\)-half is \(S\)-only, its singleton-\(d\) switch must change \(bd\) to \(ab\); the \(d\)-terminal path therefore ends at \(a\). It enters \(C\) through \(d\) and leaves through some port \(q\ne c\), because the separate \(c\)-terminal exterior path already uses port \(c\). Thus the shore restriction of \(X\triangle Z\) pairs \(d\) with \(q\).

In the exterior of \(X'\triangle Z\), terminal \(e\) reaches shore port \(c\) along \(e-t_e-w_2-t_c-c_C\). Since \(D_{cd}\) is \(S\)-only, its singleton-\(d\) switch must change \(cd\) to \(ce\); hence the same shore restriction must pair \(d\) with \(c\). This contradicts \(q\ne c\). Port **edges** are distinguished even if their shore endpoints coincide. Therefore no exact-Case-XII pole with this two-vertex seven-cut connector has \(k=2\). The next argument also excludes \(k=1\).

**The \(k=1\) placement forces one singleton-\(d\) route.** Fix \(S=a-c-d-b-e-a\) and a required actual \((bd)(ce)\) row. By the symmetry above, take its \(bd\)-triple \(X\) to select \(b:w_1\) and its \(ce\)-triple \(U\) to select \(c:w_2\). Name the singleton-\(b,d,c,e\) matchings \(Y,Z,V,W\). The original \(bd\)-half \(X+Y+Z\) is \(S\)-only because its complementary \(ce\)-half has a \(T\)-state. Therefore the \(b\)-terminal path of \(X\triangle Y\) must end at \(c\). At \(w_1\), either \(Y\) uses \(d:w_1\), or it uses \(u_1w_1\); in the latter case the required endpoint forces \(u_2w_0,c:w_2\) as well.

Switch \(X,U\) along their wholly exterior \(b\)--\(c\) path, obtaining \(X'\) at \(cd\in S\) and \(U'\) at \(be\in S\). Regroup the six occurrences into \(D_{cd}=X'+Z+V\) and \(D_{be}=U'+Y+W\). If \(Y\) uses \(d:w_1\), the \(b\)-terminal path of \(U'\triangle Y\) ends at \(d\), giving \(de\in T\). If \(Y\) uses \(u_1w_1,u_2w_0,c:w_2\), that path ends at \(c\), giving \(ce\in T\). Hence \(D_{be}\) has a \(T\)-state in either case and \(\mathcal R(D_{cd})\subseteq S\).

The singleton-\(c\) matching \(V\) cannot use \(e:w_2\): with \(X'\) it would create the forbidden \(de\) state. It therefore uses \(u_2w_2\). At \(w_0\), using \(a:w_0\) would make the same terminal path end at \(a\), creating \(ad\in T\); \(u_2w_0\) is unavailable because \(V\) already uses \(u_2w_2\). Thus \(V\) uses \(u_1w_0\). Now \(X,V\) saturate \(u_2w_2\); \(U\) uses \(c:w_2\), and \(W\) has terminal \(e\), so \(W\) also uses \(c:w_2\). The other singleton matchings \(Y,Z\) both use \(e:w_2\). In particular, the wholly exterior \(b\)--\(c\) route of \(Y\) is impossible, and \(Y\) uses \(d:w_1\).

With \(Z\) at \(e:w_2\), the saturated path edges \(u_1w_0,u_2w_2\) leave exactly four exterior routes for this singleton-\(d\) matching. The table gives the shore port reached from terminal \(e\) in the exterior of \(X\triangle Z\), and from terminal \(a\) in the exterior of \(X'\triangle Z\):
\[
\begin{array}{c|l|c|c}
&Z\text{ exterior route}&e\text{ with }X&a\text{ with }X'\\\hline
P&e:w_2,\ u_1w_1,u_2w_0&b&a\\
A&a:w_0,e:w_2,\ u_1w_1,h_2&h_2&h_2\\
B&a:w_0,b:w_1,e:w_2,\ h_1,h_2&h_2&h_2\\
Q&b:w_1,e:w_2,\ h_1,u_2w_0&h_1&a.
\end{array}
\]
The shore restrictions of \(X\triangle Z\) and \(X'\triangle Z\) coincide, because the \(b\)--\(c\) switch did not touch \(C\). In the original \(S\)-only \(bd\)-half, the singleton-\(d\) switch must end at \(e\), changing \(bd\) to \(be\). In the new \(S\)-only \(cd\)-half, it must end at \(a\), changing \(cd\) to \(ac\). Thus the two displayed exterior paths must reach the same shore port. Routes \(P,Q\) are impossible; only \(A,B\) pass this pairing test. Route \(B\) also fails: \(X\) uses \(u_1w_0\), \(V\) uses \(u_1w_0\), \(Z\) uses \(b:w_1\), and \(Y\) uses \(d:w_1\), so none of \(X,Y,Z\) can use \(u_1w_1\). This contradicts the endpoint-load gate for their \(S\)-only half-load. Therefore every exact row of this orientation forces the unique exterior route
\[
Z:\quad a:w_0,e:w_2,\ u_1w_1,h_2.
\]
Its three shore ports are \(b,c,h_2\); their endpoints must be distinct, and deleting them from \(F[C]\) must leave a perfect matching. This forced route supplies the final two-switch contradiction below.

**The \(k=1\) placement is impossible at every order.** The preceding forced routes already suffice; no choice of the remaining shore matchings can repair them. In particular, \(Y\) uses \(d:w_1\), while \(Z\) uses \(a:w_0,e:w_2,u_1w_1,h_2\). Since \(A=X+Y+Z\) is \(S\)-only and its state is \(bd\), the alternating path of \(X\triangle Z\) from singleton terminal \(d\) must end at \(e\): among pairs replacing \(d\) in \(bd\), only \(be\) lies in \(S\). The exterior segment from \(e\) reaches shore port \(h_2\), so this path enters \(C\) at the \(d\)-port, leaves at \(h_2\), and then traverses \(h_2,u_2w_2,e:w_2\). In particular it avoids \(w_1\) and the exterior half-edge \(b:w_1\).

Switch \(X,Z\) along that entire \(d\)--\(e\) path, obtaining full perfect matchings \(X_1,Z_1\) with
\[
X_1+Y+Z_1=A,\qquad
\partial X_1=\{a,c,d\},\quad \partial Z_1=\{e\}.
\]
Thus \(X_1\) is the triple of state \(be\in S\). It still uses \(b:w_1\); the unchanged singleton-\(b\) matching \(Y\) uses \(d:w_1\). Their symmetric difference therefore has the **wholly exterior** component
\[
b-t_b-w_1-t_d-d.
\]
Switch \(X_1,Y\) along this component. The resulting triple \(X_2\) has boundary \(\{a,b,c\}\), hence state \(de\in T\), while the resulting singleton \(Y_2\) has boundary \(\{d\}\). Consequently \(A=X_2+Y_2+Z_1\) has a genuine \(T\)-decomposition. Its unchanged complementary half \(U+V+W\) has state \(ce\in T\). The six full matchings therefore form a forbidden actual \((de)(ce)\) BF row, contradicting exact Case XII. This closes \(k=1\) and leaves only \(k=0\) for the two-vertex seven-cut connector.

**The required seed orientations for \(k=0\).** Let \(S=a-b-c-d-e-a\), and take any actual required \((ab)(ce)\) row. Its \(ce\)-triple \(U\) selects exactly one of \(c,e\), say \(y\), at \(w_2\), and uses \(u_1w_1,u_2w_0\). Its \(ab\)-triple \(X\) has exactly three exterior routes: \(b:w_1\) with \(a\) entering \(C\), using \(u_1w_0,u_2w_2\); \(a:w_0\) with \(b\) entering \(C\), using \(u_1w_1,u_2w_2\); or \(a:w_0,b:w_1,h_1,u_2w_2\). In the first route, \(X\triangle U\) has the entirely exterior alternating path \(b-w_1-u_1-w_0-u_2-w_2-y\). In either route selecting \(a:w_0\), it has the entirely exterior path \(a-w_0-u_2-w_2-y\). Switching and regrouping the four unchanged singleton matchings gives
\[
\begin{array}{c|c|c}
\text{selected exterior mark of }X&y&\text{new pair states}\\\hline
b&c&ac,be\in T\\
b&e&ae,bc\in S\\
a&c&bc,ae\in S\\
a&e&be,ac\in T.
\end{array}                                                    \tag{11}
\]
Consequently every exact-Case-XII row of this seed must select either \(b\) in \(X\) and \(e\) in \(U\), or \(a\) in \(X\) and \(c\) in \(U\). This uses the full six-matching row and its forbidden \(T\)--\(T\) support, but does not distinguish the two surviving orientations. The third \(ab\) route selects both \(a,b\) outside; its \(a\)--\(y\) component gives the same last two lines of (11).

**The wholly exterior \(b\)--\(e\) return is impossible.** In the surviving \(b/e\) orientation, name the singleton-\(a,b,c,e\) matchings \(Y,Z,V,W\), respectively. Suppose \(Z\) uses the route \(e:w_2,u_1w_1,u_2w_0\), so the \(b\)-terminal component of \(X\triangle Z\) is the wholly exterior \(b\)--\(e\) path. The \(ce\)-triple \(U\) uses those same three exterior edges, loading each twice with \(Z\). Consequently none of \(Y,V,W\) uses them. At \(w_0\), \(Y\) must use \(u_1w_0\), because its terminal is \(a\); then \(V,W\) both use \(a:w_0\). At \(u_1\), this forces \(V,W\) both to use \(h_1\). At \(w_2\), the \(e\)-half is saturated by \(U,Z\), and \(V\) has terminal \(c\), so \(V\) must use \(u_2w_2\). As \(X\) also uses \(u_2w_2\), the matchings \(Y,W\) both use \(c:w_2\) and \(h_2\).

Now switch \(X,U\) along their exterior \(b\)--\(e\) path, obtaining triples \(X'\) at \(ae\in S\) and \(U'\) at \(bc\in S\). The complementary half-loads are \(X'+Y+W\) and \(U'+Z+V\). Since \(W\) uses \(c:w_2\), the \(e\)-terminal component of \(X'\triangle W\) ends at \(c\), giving \(ac\in T\). Since \(Z\) uses \(e:w_2,u_1w_1,u_2w_0\), the \(b\)-terminal component of \(U'\triangle Z\) follows the same long exterior path to \(e\), giving \(ce\in T\). Recolouring these two components yields a genuine forbidden \((ac)(ce)\) BF row. Therefore, in any exact-Case-XII \((ab)(ce)\) row with the \(b/e\) orientation, the singleton-\(b\) return toward \(e\) must enter the shore; the wholly exterior route is excluded at every order.

**The wholly exterior \(a\)--\(c\) return is impossible.** In the other surviving orientation, \(X\) selects \(a:w_0\) and \(U\) selects \(c:w_2\). The triple \(X\) always uses \(u_2w_2\), and \(U\) uses \(u_2w_0\). Suppose the singleton-\(a\) matching \(Y\) uses \(u_2w_0,c:w_2\), so the \(a\)-terminal component of \(X\triangle Y\) is wholly exterior and ends at \(c\). The edges \(u_2w_0,c:w_2\) are now saturated by \(U,Y\). The singleton-\(e\) matching \(W\) cannot use \(e:w_2\), and \(c:w_2\) is saturated, so \(W\) uses \(u_2w_2\). This saturates \(u_2w_2\) with \(X\), forcing the singleton-\(b,c\) matchings \(Z,V\) to use \(e:w_2\) and \(h_2\).

Switch \(X,U\) along their exterior \(a\)--\(c\) path. The resulting triples \(X',U'\) have states \(bc,ae\in S\), and give complementary half-loads \(X'+Z+V\) and \(U'+Y+W\). In \(X'\triangle V\), the short exterior \(c\)--\(e\) path through \(w_2\) changes \(bc\) to \(be\in T\), since \(V\) uses \(e:w_2\). In \(U'\triangle Y\), the original exterior \(a\)--\(c\) path changes \(ae\) to \(ce\in T\). Thus the six actual matchings yield forbidden \((be)(ce)\) support. This argument covers both \(ab\)-triple routes selecting \(a:w_0\), including the route that also selects \(b:w_1\). In an exact row of this orientation, the required singleton-\(a\) return toward \(c\) must enter the shore.

**The remaining \(b/e\) seed has one singleton-\(b\) route.** Suppose an exact row uses \(X:b:w_1,a\) into \(C\) and \(U:e:w_2,c\) into \(C\). Since its \(ab\)-half is \(S\)-only, the \(b\)-terminal component of \(X\triangle Z\) must end at \(e\). At \(w_1\), \(Z\) cannot use \(d:w_1\), which would end this component at \(d\); it uses \(u_1w_1\). At \(w_0\), choosing \(u_2w_0\) would end the component at \(c\) or take the excluded wholly exterior route to \(e\). Thus \(Z\) uses \(a:w_0\). Its only three exterior completions are
\[
\begin{array}{c|l}
Z_0&a:w_0,\ u_1w_1,u_2w_2\\
Z_c&a:w_0,\ c:w_2,\ u_1w_1,h_2\\
Z_e&a:w_0,\ e:w_2,\ u_1w_1,h_2.
\end{array}
\]
After the \(b\)--\(e\) switch of \(X,U\), the new \(bc\)-triple \(U'\) uses \(b:w_1,u_1w_0,u_2w_2\). In each displayed route, \(U'\triangle Z\) has the wholly exterior \(b\)--\(a\) path through \(w_1,u_1,w_0\); hence \(U'+Z+V\) has the forbidden state \(ac\in T\). Its complementary half \(X'+Y+W\), initially at \(ae\in S\), must therefore have \(\mathcal R\subseteq S\). The endpoint-load gate forces positive \(u_2w_2\)-load in that half.

Route \(Z_0\) saturates \(u_2w_2\) with \(X\), leaving zero load in \(X'+Y+W\). In route \(Z_e\), \(U,Z\) saturate \(e:w_2\); because \(V\) has terminal \(c\), it must use \(u_2w_2\), saturating that edge with \(X\) and again leaving zero in \(X'+Y+W\). Both routes are impossible. Thus every exact row of this orientation forces
\[
Z:\quad a:w_0,\ c:w_2,\ u_1w_1,h_2.
\]
In particular, the three shore endpoints of \(d,e,h_2\) are distinct and their deletion from \(F[C]\) has a perfect matching. Furthermore \(W\), whose terminal is \(e\), cannot use \(c:w_2\): after the cross-triple switch, \(X'\triangle W\) would have the short exterior \(e\)--\(c\) path and give \(ac\in T\) in the supposedly \(S\)-only half. Hence \(W\) uses \(u_2w_2\). Edge loads then force \(V\) to use \(e:w_2\) and \(Y\) to use \(c:w_2\). These are necessary routes for one actual full row; no shore matching identity has been assumed.

The same full shore matching of \(X\) occurs in \(X'\), since their switch was wholly exterior. The saturated original \(ab\)-half requires the \(a\)-terminal path of \(X\triangle Y\) to end at \(c\); the \(S\)-only \(ae\)-half requires the \(a\)-terminal path of \(X'\triangle Y\) to end at \(d\). Because \(Y\) has terminal \(a\), uses \(c:w_2\), and cannot use the already saturated edges \(u_1w_1,u_2w_2\), it has just two exterior route shapes: \(u_1w_0,h_2\) or \(u_2w_0,h_1\), each with either \(b:w_1\) or \(d:w_1\). In the first shape, the \(c\)-path of \(X\triangle Y\) reaches shore port \(h_2\); in the second it reaches \(h_1\). The \(d\)-path of \(X'\triangle Y\) reaches that same port exactly when \(Y\) uses \(d:w_1\); if it uses \(b:w_1\), the \(d\)-path reaches the distinct shore port \(d\). Since the restriction to \(C\) of the two symmetric differences is identical, \(Y\) must use \(d:w_1\) in either shape.

**Both remaining \(b/e\) routes produce forbidden full rows.** Write \(A=X+Y+Z\), which is \(S\)-only because \(U+V+W\) has state \(ce\in T\). The preceding paragraph leaves two routes for singleton-\(a\) matching \(Y\):
\[
\begin{array}{c|l}
I&d:w_1,\ c:w_2,\ u_1w_0,\ h_2\\
II&d:w_1,\ c:w_2,\ u_2w_0,\ h_1 .
\end{array}
\]
In both, the singleton-\(b\) matching \(Z\) has the forced route \(a:w_0,c:w_2,u_1w_1,h_2\).

In route \(I\), the \(a\)-terminal component of \(X\triangle Y\) must end at \(c\), since \(ab\to bc\) is its only \(S\)-preserving move. Its exterior part runs from the \(h_2\)-port through \(u_2w_2,c:w_2\), while its other end enters \(C\) through \(a\). Switch \(X,Y\) along the complete \(a\)--\(c\) path. The resulting triple \(X_1\) has state \(bc\), terminal boundary \(\{a,d,e\}\), and still uses \(b:w_1,u_1w_0\). Therefore \(X_1\triangle Z\) contains the wholly exterior component
\[
b-t_b-w_1-u_1-w_0-t_a-a.
\]
Switching that component changes \(bc\) to \(ac\in T\). The two switches retain the full load \(A\), so combining this \(T\)-decomposition with the unchanged \(ce\)-half gives a forbidden actual \((ac)(ce)\) BF row.

In route \(II\), the \(b\)-terminal component of \(X\triangle Z\) must end at \(e\), since \(ab\to ae\) is its only \(S\)-preserving move. Its exterior part runs through \(b:w_1,u_1w_1,u_1w_0,a:w_0\) to the \(a\)-port, while its other end is the \(e\)-port. Switch \(X,Z\) along the complete \(b\)--\(e\) path. The resulting triple \(X_1\) has state \(ae\), terminal boundary \(\{b,c,d\}\), retains \(u_2w_2\), and gains \(a:w_0\). Since \(Y\) uses \(u_2w_0,c:w_2\), the difference \(X_1\triangle Y\) contains the wholly exterior component
\[
a-t_a-w_0-u_2-w_2-t_c-c.
\]
Switching it changes \(ae\) to \(ce\in T\). Together with the unchanged \(ce\)-half this is a forbidden actual \([ce]\) BF row. Thus the \(b/e\) seed orientation is impossible at every order. Any exact pole in the \(k=0\) placement must realize the required \((ab)(ce)\) cell only with \(X\) selecting \(a:w_0\), \(U\) selecting \(c:w_2\), and its singleton-\(a\) return entering the shore.

**First forced edge in the surviving \(a/c\) orientation.** Here \(X\) uses \(a:w_0,u_2w_2\). The singleton-\(a\) matching \(Y\) must match \(w_0\) by \(u_1w_0\) or \(u_2w_0\). In the latter case the \(a\)-terminal component of \(X\triangle Y\) follows \(a:w_0,u_2w_0,u_2w_2\) to \(w_2\). Ending at \(e\) would change state \(ab\) to \(be\in T\); ending at \(c\) gives the wholly exterior \(a\)--\(c\) return already excluded above. Thus \(Y\) uses \(u_1w_0\). If \(X\) takes its \(a:w_0,u_1w_1,u_2w_2\) route, \(Y\) must further use \(b:w_1\): choosing \(d:w_1\) would make the \(a\)-terminal path end at \(d\) and produce \(bd\in T\).

**The \(a\)-only \(ab\)-triple route is impossible.** Suppose \(X\) uses \(a:w_0,u_1w_1,u_2w_2\) and enters \(C\) through \(b\). By the preceding paragraph \(Y\) uses \(u_1w_0,b:w_1\). The \(ce\)-triple \(U\) also uses \(u_1w_1\), so that edge is saturated. The singleton-\(b\) matching \(Z\) must therefore use \(d:w_1\). Its vertex \(u_1\) is matched either by \(u_1w_0\) or by \(h_1\).

Switch \(X,U\) along their wholly exterior \(a\)--\(c\) path. The resulting \(X'\) has state \(bc\), uses \(c:w_2,u_1w_1,u_2w_0\), and has exactly the same full matching on \(C\) as \(X\). The complementary half containing the new \(ae\)-triple \(U'\) also contains \(Y,W\). It has a \(T\)-state: \(U'\) uses \(a:w_0,u_1w_1\), while \(Y\) uses \(u_1w_0,b:w_1\), so \(U'\triangle Y\) has the wholly exterior \(a\)--\(b\) component and changes \(ae\) to \(be\in T\). Hence \(D_{bc}=X'+Z+V\) must be \(S\)-only.

In the original \(S\)-only half \(X+Y+Z\), the singleton-\(b\) path of \(X\triangle Z\) must end at \(e\), changing \(ab\) to \(ae\). In \(D_{bc}\), that of \(X'\triangle Z\) must end at \(d\), changing \(bc\) to \(cd\). Both differences have the **same complete shore restriction** \(X|_C\triangle Z|_C\). Compare the shore ports reached by the two exterior paths. If \(Z\) uses \(h_1\), the \(d\)-path with \(X'\) reaches \(h_1\), whereas the \(e\)-path with \(X\) reaches \(e\), \(a\), or \(h_2\), never \(h_1\). Thus \(Z\) uses \(u_1w_0\). It cannot then use \(u_2w_0\), so at \(u_2\) it uses \(u_2w_2\) or \(h_2\). In the first case the \(d\)-path with \(X'\) reaches shore port \(c\), while the \(e\)-path with \(X\) reaches \(e\). Thus \(Z\) uses \(h_2\). At \(w_2\) it selects \(c:w_2\) or \(e:w_2\). The \(d\)-path with \(X'\) now reaches \(h_2\); the \(e\)-path with \(X\) reaches \(e\) if \(Z\) selects \(c:w_2\), and \(h_2\) if it selects \(e:w_2\). The common shore pairing therefore forces the unique route
\[
Z:\quad d:w_1,\ e:w_2,\ u_1w_0,\ h_2 .
\]

The \(b\)--\(e\) path of \(X\triangle Z\) consequently enters \(C\) at \(b\), leaves at \(h_2\), then follows \(h_2,u_2w_2,e:w_2\). It avoids \(a:w_0,u_1w_1\). Switch \(X,Z\) along this path. The new triple \(X_1\) has state \(ae\in S\), terminal boundary \(\{b,c,d\}\), and still uses \(a:w_0,u_1w_1\). The unchanged \(Y\) uses \(u_1w_0,b:w_1\), so \(X_1\triangle Y\) has the wholly exterior component
\[
a-t_a-w_0-u_1-w_1-t_b-b.
\]
Switching it changes \(ae\) to \(be\in T\). Since the two switches preserve the original half-load and its complement retains \(ce\in T\), they give a forbidden actual \((be)(ce)\) BF row. Thus the \(a\)-only route is excluded, leaving only the \(ab\)-triple route selecting both \(a:w_0,b:w_1\) in the \(k=0\) seed.

**The remaining route fixes the next saturated half.** Let \(X\) now select \(a:w_0,b:w_1,h_1,u_2w_2\), and let \(U\) select \(c:w_2,u_1w_1,u_2w_0\). The original \(S\)-only half \(A=X+Y+Z\) realizes \(ae\in S\); its \(ae\)-triple has both \(b,d\) terminal, so it uses \(u_1w_1\). Neither \(X\) nor \(Y\) uses this edge, because \(Y\) was just forced to \(u_1w_0\). Hence singleton-\(b\) matching \(Z\) uses \(u_1w_1\).

Switch \(X,U\) along their wholly exterior \(a\)--\(c\) path. The new triples \(X'\) and \(U'\) have states \(bc\) and \(ae\), respectively; \(X'|_C=X|_C\), and their complementary halves are \(D_{bc}=X'+Z+V\) and \(D_{ae}=U'+Y+W\). If \(Y\) used \(b:w_1\), then \(U'\triangle Y\) would have the wholly exterior \(a\)--\(b\) path through \(w_0,u_1,w_1\), giving \(be\in T\) in \(D_{ae}\). Thus \(D_{bc}\) would be \(S\)-only.

But in the original \(S\)-only half the \(b\)-terminal path of \(X\triangle Z\) must end at \(e\), whereas in an \(S\)-only \(D_{bc}\) the corresponding path of \(X'\triangle Z\) must end at \(d\). In both differences its \(b\)-end enters \(C\) through \(h_1\): it follows \(b:w_1,u_1w_1,h_1\), using \(b:w_1,h_1\) from \(X\) or \(X'\) and \(u_1w_1\) from \(Z\). The \(e\)-end with \(X\) reaches one of the shore ports \(e,a,h_2\), according as \(Z\) selects \(e\) in \(C\), selects \(e:w_2\) with \(u_2w_0\), or selects \(e:w_2\) with \(h_2\). The \(d\)-end with \(X'\) reaches port \(d\), since \(Z\) uses \(d\) in \(C\). These are distinct port edges. The common full shore restriction \(X|_C\triangle Z|_C=X'|_C\triangle Z|_C\) cannot pair \(h_1\) with both. Therefore \(Y\) uses \(d:w_1\).

For that remaining \(Y\)-route, \(D_{bc}\) has a \(T\)-state: its singleton-\(b\) switch cannot end at \(d\), the only \(S\)-preserving endpoint. Exact negative support consequently forces \(D_{ae}\) to be \(S\)-only. This is a constraint on one actual full row and one full half-load; the next argument closes that row without identifying masks from another required cell.

**The last \(k=0\) route is impossible.** In \(D_{ae}=U'+Y+W\), the triple \(U'\) uses \(a:w_0,u_1w_1,u_2w_2\), enters \(C\) through \(e\), and has boundary \(\{b,c,d\}\). The singleton-\(a\) matching \(Y\) uses \(u_1w_0,d:w_1\). Thus \(U'\triangle Y\) has the wholly exterior \(a\)--\(d\) component
\[
a-t_a-w_0-u_1-w_1-t_d-d.
\]
Switch it to obtain a triple \(U_1\) of state \(de\in S\), with boundary \(\{a,b,c\}\) and exterior edges \(d:w_1,u_1w_0,u_2w_2\). Crucially \(U_1|_C=U'|_C\): both matchings enter \(C\) only through the \(e\)-port. The singleton-\(e\) matching \(W\) is unchanged. Since \(D_{ae}\) is \(S\)-only, the \(e\)-terminal path of \(U'\triangle W\) must end at \(b\), changing \(ae\) to \(ab\); that of \(U_1\triangle W\) must end at \(c\), changing \(de\) to \(cd\). In both comparisons the \(e\)-end enters \(C\) through the same \(e\)-port, so the \(b\)-end and \(c\)-end must reach the same other shore **port edge**.

The edge \(u_1w_1\) is saturated by \(U,Z\), so \(W\) uses \(b:w_1\) or \(d:w_1\). If it uses \(d:w_1\), its \(b\)-end with \(U'\) reaches the \(b\)-port directly. Its \(c\)-end with \(U_1\) reaches \(c\) directly if \(W\) selects \(c\) in \(C\), reaches \(h_2\) if it selects \(c:w_2,h_2\), or reaches \(h_1\) if it selects \(c:w_2,u_2w_0\); it never reaches \(b\). Thus \(W\) uses \(b:w_1\). Its \(b\)-end with \(U'\) then follows \(b:w_1,u_1w_1\) and reaches port \(a\) if \(W\) uses \(u_1w_0\), or \(h_1\) if \(W\) uses \(h_1\). In the former case \(W\) cannot use \(u_2w_0\), and its \(c\)-end with \(U_1\) reaches only \(c\) or \(h_2\), never \(a\). Hence \(W\) uses \(h_1\). The \(c\)-end must now reach \(h_1\), forcing \(W\) to select \(c:w_2,u_2w_0\); the exterior path continues through \(U_1\)'s \(u_1w_0\) to \(W\)'s \(h_1\). In full,
\[
W:\quad b:w_1,\ c:w_2,\ u_2w_0,\ h_1;
\qquad W\text{ enters }C\text{ through }a,d,h_1 .
\]

The original \(ce\)-triple \(U\) also uses \(c:w_2,u_2w_0\), so these two edges are saturated in the six-matching row. The singleton-\(a\) matching \(Y\) therefore takes \(c\) into \(C\). The singleton-\(b\) matching \(Z\) uses \(u_1w_1\) and cannot use \(u_2w_0\); at \(w_0\) it must use \(a:w_0\). Return to the original \(S\)-only half \(A=X+Y+Z\). The \(a\)-terminal path of \(X\triangle Y\) must end at \(c\), changing \(ab\) to \(bc\). Its exterior ends reach shore ports \(h_1\) and \(c\): from \(a\) it traverses \(a:w_0,u_1w_0,h_1\), while \(Y\) uses the \(c\)-port. Switch this complete \(a\)--\(c\) path. The resulting triple \(X_1\) has state \(bc\in S\), boundary \(\{a,d,e\}\), and still uses \(b:w_1,u_1w_0\). But \(Z\) uses \(u_1w_1,a:w_0\), so \(X_1\triangle Z\) has the wholly exterior component
\[
b-t_b-w_1-u_1-w_0-t_a-a.
\]
Switching it changes \(bc\) to \(ac\in T\). The two switches leave \(A\) fixed and its complementary \(ce\)-half unchanged, giving a forbidden actual \((ac)(ce)\) BF row. This excludes the last \(k=0\) route. Together with the \(k=1,2\) arguments, no two-vertex one-seven-cut-shore connector can occur in a minimum-host full exact-Case-XII pole, at any shore order.

**A genuine order-17 row in the \(k=0\) placement.** For \(S=a-b-c-d-e-a\), the required disjoint seed \((ab)(ce)\) need not fail at the exterior connector. Here is a complete real-pole witness. Take the exterior path (3) and a shore seven-cycle
\[
z_e-z_b-z_2-z_d-z_a-z_c-z_1-z_e.                   \tag{12}
\]
Join \(u_i\) to \(z_i\) by \(h_i\). Subdivide and open the five marked edges \(w_0z_a,w_1z_b,w_2z_c,w_1z_d,w_2z_e\). The opened pole has \(5+7+5=17\) vertices. It is simple and connected; every proper edge lies on a cycle. Its girth is six. A cycle using at least four shore--exterior links has length at least six, since only \(h_1,h_2\) have length one and all five marked links have length two. A two-link cycle has length equal to the two link lengths plus the distances between their endpoints in the shore cycle and exterior path. Links at the same or adjacent exterior vertices have shore endpoints at distance at least two; every other pair has exterior distance at least two, except \(h_1,h_2\), whose shore endpoints are at distance three. These bounds give length at least six in every case. The cycle \(w_1-t_b-z_b-z_2-z_d-t_d-w_1\) attains length six.

Write \(m_C=t_mz_m\) for a marked shore half and \(m_i=t_mw_i\) for its exterior half. The following are six **full perfect matchings**; the boundary column lists their selected terminal semiedges. Every unlisted marked subdivision vertex is covered by one of the selected marked halves.
\[
\begin{array}{c|c|l|l|l}
 &\partial&\text{marked halves}&\text{exterior unmarked}&\text{shore-cycle edges}\\\hline
X&c,d,e&a_C,b_1&u_1w_0,u_2w_2&z_ez_b,z_2z_d,z_cz_1\\
U&a,b,d&c_C,e_2&u_1w_1,u_2w_0&z_1z_e,z_bz_2,z_dz_a\\
Y&a&b_C,c_2,d_1,e_C&u_1w_0,h_2&z_dz_a,z_cz_1\\
Z&b&a_C,c_C,d_1,e_2&u_2w_0,h_1&z_ez_b,z_2z_d\\
V&c&a_0,b_1,d_C,e_C&u_2w_2,h_1&z_bz_2,z_az_c\\
W&e&a_0,b_C,c_2,d_C&u_1w_1,h_2&z_az_c,z_1z_e .
\end{array}                                                    \tag{13}
\]
The exterior path edges have owners \((U,W),(X,Y),(U,Z),(X,V)\) in path order; \(h_1,h_2\) have owners \((Z,V),(Y,W)\). The seven shore-cycle edges in (12) have owner pairs \((X,Z),(U,V),(X,Z),(U,Y),(V,W),(X,Y),(U,W)\), in cyclic order. Each marked half and each terminal semiedge likewise has exactly two owners by (13). Thus (13) is a genuine BF row of type \((ab)(ce)\), not a formal port assignment.

This pole does **not** have exact Case-XII support. Switch its two triples \(X,U\) along the exterior \(b\)--\(e\) path
\[
b-t_b-w_1-u_1-w_0-u_2-w_2-t_e-e,
\]
giving \(X'\) at \(ae\) and \(U'\) at \(bc\). Regroup the unchanged six occurrences into \(D_{ae}=X'+Y+W\) and \(D_{bc}=U'+Z+V\). The first half has zero load on \(u_2w_2\), and the second has zero load on \(w_1u_1\), so the endpoint-load gate already proves that they each have a \(T\)-state and yield a forbidden \(T\)--\(T\) row. Their precise forbidden states can also be read directly: in \(X'\triangle W\), the terminal-\(e\) path is \(e-t_e-w_2-t_c-c\), giving \(ac\in T\); in \(U'\triangle V\), the terminal-\(c\) path is
\[
c-t_c-z_c-z_a-z_d-t_d-d,
\]
so \(D_{bc}\) also has the forbidden \(bd\in T\) state. Choosing these two decompositions gives an actual forbidden \((ac)(bd)\) BF row. The example proves the precise local boundary: a girth-six, bridge-free, order-17 connector can realize the required seed with complete edge loads, while its full perfect-matching closure restores a forbidden Case-XII type.
