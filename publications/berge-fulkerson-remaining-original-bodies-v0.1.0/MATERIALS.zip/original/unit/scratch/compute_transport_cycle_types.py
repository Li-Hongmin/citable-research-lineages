#!/usr/bin/env python3
"""Explore Kempe-transport holonomy on the retained order-11 Case-XII poles.

This is disposable research code.  It reuses the exhaustive augmented-graph
generation from the promoted order-11 bundle, but computes the actual forward
transport maps and their cycle types.
"""

from __future__ import annotations

import importlib.util
import itertools
import subprocess
import sys
from collections import Counter
from pathlib import Path

import networkx as nx


ROOT = Path(__file__).resolve().parents[3]
BUNDLE = ROOT / "units/berge-fulkerson/computations/bundles/case-xii-order-11"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


legacy = load("case_xii_legacy_transport", BUNDLE / "case_xii_pentagon_audit.py")
audit = load("case_xii_n11_transport", BUNDLE / "case_xii_n11_geng_audit.py")


def alternating_component(pole, left, complement, start_position):
    edge_data, info, incidence = legacy.incidence(pole)
    allowed = set(left) | set(complement)
    start = f"s{start_position}"
    if start not in left:
        raise AssertionError("start semiedge is not in the left matching")
    component = {start}
    stack = [start]
    while stack:
        edge = stack.pop()
        for vertex in info[edge][0]:
            for neighbour_edge in incidence[vertex]:
                if neighbour_edge in allowed and neighbour_edge not in component:
                    component.add(neighbour_edge)
                    stack.append(neighbour_edge)
    return frozenset(component)


def transport(pole, pair, t):
    order = legacy.PENTAGON_ORDER
    p, q = pair
    all_edges = frozenset(eid for eid, _, _ in pole.edge_data())
    complement = all_edges - p - q
    component = alternating_component(pole, p, complement, order[t])
    p_prime = frozenset((p - component) | (complement & component))
    expected = order[(t + 2) % 5]
    boundary = legacy.boundary_set(
        p_prime, {eid: position for eid, _, position in pole.edge_data()}
    )
    if boundary != frozenset({expected}):
        raise AssertionError((t, boundary, expected))
    return q, p_prime


def relations(pole):
    matchings, _, edge_position, _ = legacy.enumerate_perfect_matchings(pole)
    singleton = {i: [] for i in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    order = legacy.PENTAGON_ORDER
    result = []
    for a, b in zip(order, order[1:] + order[:1]):
        result.append(tuple((p, q) for p in singleton[a] for q in singleton[b]
                            if p.isdisjoint(q)))
    return tuple(result)


def cycle_type(permutation):
    seen = set()
    cycles = []
    for start in permutation:
        if start in seen:
            continue
        current = start
        length = 0
        while current not in seen:
            seen.add(current)
            length += 1
            current = permutation[current]
        cycles.append(length)
    return tuple(sorted(cycles))


def holonomy_data(pole):
    rels = relations(pole)
    current = {pair: pair for pair in rels[0]}
    maps = []
    for t in range(5):
        step = {pair: transport(pole, pair, t) for pair in rels[t]}
        if set(step.values()) != set(rels[(t + 1) % 5]):
            raise AssertionError(f"transport {t} is not a bijection")
        maps.append(step)
        current = {start: step[value] for start, value in current.items()}
    permutation = current
    return rels, maps, permutation, cycle_type(permutation)


def run():
    proc = subprocess.Popen(
        ["geng", "-q", "-c", "-d3", "-D5", "12", "19"],
        stdout=subprocess.PIPE,
        text=True,
    )
    if proc.stdout is None:
        raise RuntimeError("cannot read geng output")
    distribution = Counter()
    examples = {}
    retained = 0
    for line in proc.stdout:
        graph = nx.from_graph6_bytes(line.strip().encode("ascii"))
        degrees = Counter(dict(graph.degree()).values())
        if degrees != Counter({3: 11, 5: 1}):
            continue
        apex = next(v for v, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        neighbours = tuple(graph.neighbors(apex))
        for mapping in audit.boundary_label_representatives(neighbours):
            pole = audit.pole_from_augmented(legacy, graph, apex, mapping)
            if legacy.enumerate_tait_states(pole) != legacy.S_DIAGONALS:
                continue
            retained += 1
            rels, maps, permutation, kind = holonomy_data(pole)
            distribution[kind] += 1
            if kind not in examples:
                examples[kind] = {
                    "graph6": line.strip(),
                    "mapping": mapping,
                    "proper_edges": pole.proper_edges,
                    "relation_size": len(rels[0]),
                    "fixed_points": sum(permutation[x] == x for x in permutation),
                    "is_involution": all(permutation[permutation[x]] == x for x in permutation),
                }
    returncode = proc.wait()
    if returncode:
        raise RuntimeError(f"geng failed: {returncode}")
    print(f"retained={retained}")
    print("cycle_type_distribution=")
    for kind, count in sorted(distribution.items()):
        print(f"  {kind}: {count}")
    print("examples=")
    for kind, data in sorted(examples.items()):
        print(f"  {kind}: {data}")


if __name__ == "__main__":
    run()
