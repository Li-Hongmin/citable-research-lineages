# Case XII synchronized rectangle: bounded run, 2026-09-24

Status: **unresolved for genuine exact-Case-XII poles**. This is scratch, not an independently checked theorem or a promoted note. The frozen `SPEC-2026-09-23-case-xii-rectangle.md` and existing notes were not changed.

## Exact quantifier reduction (R2)

Fix one of the four endpoint roles of Notes 104 and 109, with anchored load $K$, target $T$, and a full-mask opposite-carrier operative witness $W$ eligible for that role. For $a\in\{\mathrm{ent},0,1,2\}$, Note 104 defines $\mathcal C_a(T)$, and **$T\in\mathcal C_a(T)$ for every $a$**: the empty alternating-cycle union is allowed. The Note-109 conditions for a triple $(P,N,W)$ are

\[
P\in\mathcal C_a(T),\qquad K=P+N+W,\qquad N+P-T\in\mathcal P(G).
\]

The last mask is forced by the other two:

\[
N+P-T=K-W-T. \tag{1}
\]

It does not depend on $P$ or $a$. If a non-entry triple exists, replace it by $P'=T,\ N'=K-W-T$, keeping the same $K,W$ and the same opposite-carrier full-mask identity. Then $K=P'+N'+W$, $P'\in\mathcal C_{\mathrm{ent}}(T)$, and the phase condition is trivial. Conversely an entry triple is one of the sixteen. Thus the frozen **existential** sixteen-context rectangle is equivalent to one of four entry tests, provided the prescribed opposite witness is the same role-based $W$ when the source matching is reset to $T$. That is how Notes 104 and 109 state the full-mask requirement; no extra $P\ne T$ or $P$-dependent rule for $W$ appears there.

Since each $K$ has incident degree three, Note 106 further gives the exact entry test

\[
\exists W\in\mathcal O_r:\quad \chi_T+\chi_W\le K,
\tag{2}
\]

where $\mathcal O_r$ is the prescribed opposite operative full-mask fibre for endpoint role $r\in\{Y,D,A,X\}$. Nonnegativity makes $K-T-W$ an actual perfect matching. If the leakage pair has either a singleton or a triple occurrence eligible as $W$, (1)--(2) apply separately to each full-mask choice. No choice of opposite-role convention restores a distinct existential phase gate.

This reduction does **not** prove (2) from exact support. It shows that Note 109's phase obstruction concerns a *specified nontrivial switch from a specified $P$*, while its frozen existence statement is a common-$K$ pair-domination question. It also does not establish the intended Note-093 projection or the dependent second splice.

## Pulse 1: one small genuine pole, full PM replay (R1)

`pulse1_order11.py` independently enumerates all perfect matchings of the fixed simple connected 11-vertex pole of Note 080 from its edge list. It obtains **24 complete masks**, checks the four literal BF rows on every proper edge and semiedge, and evaluates all sixteen Note-104 cores. For the opposite operative set it permits both residual companion roles (singleton and complementary triple), so the checked set contains either possible prescribed $W$ role. Every core contains only its target. The opposite state-13 fibre of $K_{34}$ and state-35 fibre of $K_{23}$ are empty; the other two literal opposite pairs have no common-$K$ completion. All sixteen tests are empty in this weaker pole.

The $Y$ entry does have a leakage decomposition $K_{23}=Y+q_{13}+A$, but $A$ is absent from the required opposite $K_{34}$ fibre. This separates leakage-state availability from a shared full-mask witness. The pole has no class-$q_{35}$ perfect matching, hence lacks exact Case-XII positive support and the saturated Note-101 state-35 row. This is **not** a NOGO counterexample to the main statement.

## Pulse 2: real wrong phase with four literal rows (R2)

`pulse2_four_rows_cube.py` forms a 19-vertex simple connected cubic five-pole by a two-sum of the Note-080 pole along edge $(0,8)$ with a cube along edge $(15,16)$. The five terminal labels remain at vertices $0,\ldots,4$. The cube factors used for each named matching are

| Factor | Matching identities |
|---|---|
| $T_0$ | $r_{45},X,B,q_{24}$ |
| $T_1$ | $Y$ |
| $P_0$ | $q_{25}$ |
| $P_1$ | $q_{13},C,q_{14},r_{15}$ |
| $V$ | $A,D,r_{23},r_{34}$ |

Here $T_0,T_1$ use one phase of a front-face four-cycle; $P_0,P_1$ use the other; $V$ is the vertical perfect matching. The subscript records the back-face choice. The four Note-080 literal rows each double-cover every edge object after lifting. Independent first-uncovered-vertex recursion gives **120 complete perfect matchings** of the resulting pole.

In the $Y$ role take target $T=Y\times T_1$, source $P=Y\times P_1$, $N=q_{13}\times P_1$, and $W=A\times V$. The fixed half is $H=r_{23}\times V+B\times T_0+X\times T_0$. On the front-face four-cycle, $P=N$ use the $P$-phase, $T=X=B$ use the $T$-phase, and $r_{23}=W$ use vertical incidences. Consequently $K=2\mathbf1-H=P+N+W$ edgewise, and $P\triangle T$ is precisely that proper four-cycle in the $(X,T)$ agreement region. Yet $N+P-T$ has coefficients $2$ on the $P$-phase and $-1$ on the $T$-phase. This is an actual cubic-pole failure of automatic target-phase forcing for a fixed $K,W,P$, strengthening Note 108's symbolic local separation under the four literal rows.

It does **not** meet the synchronized rectangle hypotheses: class $q_{35}$ (boundary $\{1,2,4\}$) is absent from the complete 120-PM family, and $W=A\times V$ is not in the prescribed opposite $K_{34}$ state-13 operative fibre. It neither disproves (2) under exact support nor rules out a different eligible triple in a genuine Case-XII pole.

## Pulse 3 and stopping boundary (R3)

Note 100 excludes simple connected distinct-terminal proper-bridgeless exact-Case-XII poles through order 15, so order 17 is the first *unexcluded order in that class*, not a supplied candidate. The explicit 17-vertex exact-$S$ pole of Note 030 has a capacity-two singleton transversal and therefore an all-terminal BF cover; it is not eligible. The local environment has no scheduler command (`sbatch`, `qsub`, `bsub`, or `flux`), and this run forbids remote access and bulk local enumeration. No authorized scheduler coverage certificate or exact-support candidate was available, so R3 could not make a finite-order assertion. No order-17 search was started.

**Precise remaining claim.** For every real pole with complete exact-Case-XII BF support and the stipulated fixed Note-101 rows, at least one of the four target roles must admit a *prescribed opposite operative full mask* $W$ jointly dominated with its target $T$ by the role's anchored $K$, as in (2). This implication is neither proved nor refuted. Its weakest step is the simultaneous full-mask entry into one anchored carrier; boundary support, local row equations, and residual component swaps supply separate projections but no common $(T,W)$ pair. A genuine negative verdict still requires an exact-support real pole and complete PM/support certification.
