"""One-pole full-PM replay of the Note-080 literal rows and rectangle contexts."""

from collections import Counter
from pathlib import Path
import runpy


source = runpy.run_path(str(Path(__file__).resolve().parents[2] / "computations/bundles/irreducible-failed-star-nonoverload-counterexamples/verify_order11_repeated.py"))
edges = tuple(source["PROPER"]) + tuple((v,) for v in range(5))
incident = tuple(tuple(i for i, e in enumerate(edges) if v in e) for v in range(11))
all_edges = range(len(edges))


def enumerate_pm(uncovered, chosen=0):
    if not uncovered:
        yield chosen
        return
    v = min(uncovered)
    for i in incident[v]:
        e = edges[i]
        if all(u in uncovered for u in e):
            yield from enumerate_pm(uncovered.difference(e), chosen | (1 << i))


pm = tuple(sorted(enumerate_pm(frozenset(range(11)))))
assert len(pm) == len(set(pm))
pm_set = set(pm)


def bits(mask):
    return tuple((mask >> i) & 1 for i in range(len(edges)))


def boundary(mask):
    return frozenset(v + 1 for v in range(5) if mask & (1 << (14 + v)))


def vector(name):
    used = set(source["MATCHINGS"][name]) | {(v,) for v in source["BOUNDARY"][name]}
    return sum(1 << i for i, e in enumerate(edges) if e in used)


named = {name: vector(name) for name in source["MATCHINGS"]}
assert all(mask in pm_set for mask in named.values())
assert all(all(sum(bits(named[name])[i] for name in row) == 2 for i in all_edges) for row in source["ROWS"])
loads = {
    "23": tuple(2 - sum(bits(named[name])[i] for name in ("r23", "B", "X")) for i in all_edges),
    "34": tuple(2 - sum(bits(named[name])[i] for name in ("r34", "Y", "C")) for i in all_edges),
}


def subtract(load, *masks):
    residue = tuple(load[i] - sum((m >> i) & 1 for m in masks) for i in all_edges)
    if all(x in (0, 1) for x in residue):
        mask = sum(x << i for i, x in enumerate(residue))
        if mask in pm_set:
            return mask
    return None


def opposite_companions(load, first, second):
    out = set()
    for u in pm:
        if boundary(u) != frozenset((first,)):
            continue
        for v in pm:
            if boundary(v) != frozenset((second,)):
                continue
            q = subtract(load, u, v)
            if q is not None:
                out.update((v, q))
    return out


opposite = {
    "Y": opposite_companions(loads["34"], 3, 1),
    "D": {named["B"], named["q25"]},
    "A": {named["C"], named["q14"]},
    "X": opposite_companions(loads["23"], 3, 5),
}
contexts = (
    ("23", "Y", ("r23", "B", "X"), 1),
    ("23", "D", ("r23", "B", "X"), 2),
    ("34", "A", ("r34", "Y", "C"), 4),
    ("34", "X", ("r34", "Y", "C"), 5),
)


def in_core(p, target, anchor):
    return ((target & ~p) & ~anchor) == 0 and ((p & ~target) & anchor) == 0


report = []
for carrier, target_name, anchors, leak in contexts:
    target = named[target_name]
    for anchor_name in (None,) + anchors:
        anchor = named[anchor_name] if anchor_name else None
        core = [p for p in pm if boundary(p) == boundary(target) and (p == target if anchor is None else in_core(p, target, anchor))]
        same_k = []
        aligned = []
        for p in core:
            for w in opposite[target_name]:
                n = subtract(loads[carrier], p, w)
                if n is None or boundary(n) != frozenset(range(1, 6)) - (boundary(p) | boundary(w)):
                    continue
                same_k.append((p, n, w))
                if subtract(tuple(bits(n)[i] + bits(p)[i] for i in all_edges), target) is not None:
                    aligned.append((p, n, w))
        report.append((target_name, anchor_name or "entry", len(core), len(opposite[target_name]), len(same_k), len(aligned)))

print("perfect_matchings", len(pm), "boundary_counts", dict(sorted(Counter(tuple(sorted(boundary(m))) for m in pm).items())))
print("contexts: target, anchor, core_size, opposite_size, same_K_triples, target_phase_triples")
for item in report:
    print(*item)
print("wrong_phase_examples", [
    (t, a, total, aligned) for t, a, _, _, total, aligned in report
    if total > aligned
])
for carrier, target_name, _, leak in contexts:
    target = named[target_name]
    free_leak = [w for w in pm if boundary(w) == frozenset((leak,)) and subtract(loads[carrier], target, w) is not None]
    print("entry_leakage_without_opposite_identity", target_name, len(free_leak))
    if target_name == "Y" and free_leak:
        w = free_leak[0]
        n = subtract(loads[carrier], target, w)
        print("Y_entry_leak_names", [k for k, m in named.items() if m == w], [k for k, m in named.items() if m == n])
        for chosen_g in ("r23", "B", "X"):
            choices = [edges[i] for i in range(14) if not ((named[chosen_g] | w) >> i) & 1]
            print("cube_attachment_edges_if_G", chosen_g, choices)
