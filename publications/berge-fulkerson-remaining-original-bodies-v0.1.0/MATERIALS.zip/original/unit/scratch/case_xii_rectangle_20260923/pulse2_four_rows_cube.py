"""Real 19-vertex four-row pole with a fixed-W wrong phase in the Y context."""

from collections import Counter
from pathlib import Path
import runpy


source = runpy.run_path(str(Path(__file__).resolve().parents[2] / "computations/bundles/irreducible-failed-star-nonoverload-counterexamples/verify_order11_repeated.py"))
front_t = {(11, 12), (13, 14)}
front_p = {(12, 13), (11, 14)}
back_0 = {(16, 17), (15, 18)}
back_1 = {(15, 16), (17, 18)}
vertical = {(11, 15), (12, 16), (13, 17), (14, 18)}
factors = {
    "T0": front_t | back_0,
    "T1": front_t | back_1,
    "P0": front_p | back_0,
    "P1": front_p | back_1,
    "V": vertical,
}
factor_of = {
    "q13": "P1", "r45": "T0", "A": "V", "X": "T0",
    "C": "P1", "D": "V", "q14": "P1", "r23": "V",
    "B": "T0", "q24": "T0", "r15": "P1", "q25": "P0",
    "r34": "V", "Y": "T1",
}
old_edges = set(source["PROPER"])
cube_edges = front_t | front_p | back_0 | back_1 | vertical
proper = tuple(sorted((old_edges - {(0, 8)}) | (cube_edges - {(15, 16)}) | {(0, 15), (8, 16)}))
objects = proper + tuple((v,) for v in range(5))
edge_index = {e: i for i, e in enumerate(objects)}
incident = tuple(tuple(i for i, e in enumerate(objects) if v in e) for v in range(19))


def enumerate_pm(uncovered, mask=0):
    if not uncovered:
        yield mask
        return
    v = min(uncovered)
    for i in incident[v]:
        if all(u in uncovered for u in objects[i]):
            yield from enumerate_pm(uncovered.difference(objects[i]), mask | (1 << i))


pm = set(enumerate_pm(frozenset(range(19))))


def lift(name, factor):
    base = set(source["MATCHINGS"][name]) | {(v,) for v in source["BOUNDARY"][name]}
    factor = set(factors[factor])
    through = (0, 8) in base
    assert through == ((15, 16) in factor)
    base.discard((0, 8))
    factor.discard((15, 16))
    if through:
        base.update({(0, 15), (8, 16)})
    used = base | factor
    mask = sum(1 << edge_index[e] for e in used)
    assert mask in pm
    return mask


named = {name: lift(name, factor) for name, factor in factor_of.items()}
P = lift("Y", "P1")
T = named["Y"]
L, F, G = (named[name] for name in ("X", "B", "r23"))
N, W = named["q13"], named["A"]
assert all(sum((named[name] >> i) & 1 for name in row) == 2 for row in source["ROWS"] for i in range(len(objects)))
assert all(sum((m >> i) & 1 for m in (L, F, G, P, N, W)) == 2 for i in range(len(objects)))
assert ((T & ~P) & ~L) == 0 and ((P & ~T) & L) == 0
assert {objects[i] for i in range(len(objects)) if ((P ^ T) >> i) & 1} == front_t | front_p
assert any(((P >> i) & 1) + ((N >> i) & 1) - ((T >> i) & 1) not in (0, 1) for i in range(len(objects)))

degree = Counter(v for e in proper for v in e)
assert all(degree[v] + (v < 5) == 3 for v in range(19))
assert len(set(proper)) == len(proper)
seen = {0}
while True:
    expanded = seen | {v for u, v in proper if u in seen} | {u for u, v in proper if v in seen}
    if expanded == seen:
        break
    seen = expanded
assert len(seen) == 19


def boundary(mask):
    return frozenset(v + 1 for v in range(5) if mask & (1 << (len(proper) + v)))


assert not any(boundary(m) == {1, 2, 4} for m in pm)
k34 = tuple(2 - sum((named[name] >> i) & 1 for name in ("r34", "Y", "C")) for i in range(len(objects)))
assert not any(
    all(k34[i] - ((W >> i) & 1) - ((m >> i) & 1) in (0, 1) for i in range(len(objects)))
    and sum((k34[i] - ((W >> i) & 1) - ((m >> i) & 1)) << i for i in range(len(objects))) in pm
    for m in pm if boundary(m) == {3}
)

print("order", 19, "complete_perfect_matchings", len(pm), "proper_edges", len(proper))
print("four_literal_rows", True, "same_K_fixed_W", True, "agreement_core_X", True)
print("source_minus_target_cycle", sorted(front_t | front_p))
print("target_phase_binary", False, "q35_class_present", False, "W_in_opposite_K34_fibre", False)
