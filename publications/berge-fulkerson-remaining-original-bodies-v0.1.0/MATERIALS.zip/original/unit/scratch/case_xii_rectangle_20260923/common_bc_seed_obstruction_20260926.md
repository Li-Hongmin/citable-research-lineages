# Common-\(B,C\) seed: pair-load criterion and a real-pole obstruction

This bounded pulse does **not** decide whether complete exact Case-XII support forces the seed \((*)\). It identifies the exact remaining intersection under the negative support assumptions and verifies a smaller genuine cubic-pole obstruction. The latter has two required positive cells and no all-terminal cover, but has a forbidden \(T\)-loop; it is therefore not an exact Case-XII pole.

Write \(\mathcal P_i\) for the **complete actual** singleton-boundary matching class and \(\mathcal Q_{ij}\) for the complete triple-boundary class with boundary \([5]\setminus\{i,j\}\). Every mask includes proper edges and semiedges. The two seed rows are
\[
 A+B+X+C+q_{14}+r_{23}=2\mathbf1,\qquad
 B+Y+C+D+q'_{25}+r_{34}=2\mathbf1,                 \tag{1}
\]
with \(A,B,X,Y,C,D\) in singleton classes \(1,2,3,3,4,5\), respectively. In particular, \(q'_{25}\) is independent of the \(q_{25}\) later obtained by saturating the first column.

## Exact pair-load intersection

Let \(\mathcal L\) and \(\mathcal R\) be the complete actual row relations for the left and right equations in (1), and set
\[
 \Lambda_L=\{B+C:(A,B,X,C,q_{14},r_{23})\in\mathcal L\},\qquad
 \Lambda_R=\{B+C:(B,Y,C,D,q'_{25},r_{34})\in\mathcal R\}.       \tag{2}
\]
Then, **without any support hypothesis**,
\[
 \text{a common-\(B,C\) seed exists}
 \quad\Longleftrightarrow\quad \Lambda_L\cap\Lambda_R\ne\varnothing. \tag{3}
\]
For the reverse implication, choose one row on each side with the same complete edge-load vector \(B+C\). Replace the right row's \(B,C\) by the two actual masks from the left row. Its six-edge-load sum is unchanged, so both rows now use literally the same \(B,C\). This is equality of full edge-load vectors, not equality of boundary classes or of selected occurrence names.

There is also a singleton-only form of (2) under the **complete** negative support conditions. For an integral degree-two residual \(R\), let \(\operatorname{Even}(R)\) mean that every coefficient is nonnegative and every closed component of its edge-copy multigraph is even. Doubled proper edges count as two-cycles. If the full BF support has neither an all-terminal type nor any \(T\)--\(T\) type, then
\[
\begin{aligned}
\Lambda_L=\{B+C:\ &A\in\mathcal P_1,\ B\in\mathcal P_2,
 X\in\mathcal P_3,\ C\in\mathcal P_4,\\[-2pt]
&\operatorname{Even}(2\mathbf1-A-B-X-C)\},\\
\Lambda_R=\{B+C:\ &B\in\mathcal P_2,\ Y\in\mathcal P_3,
 C\in\mathcal P_4,\ D\in\mathcal P_5,\\[-2pt]
&\operatorname{Even}(2\mathbf1-B-Y-C-D)\}.             \tag{4}
\end{aligned}
\]
Necessity follows because the respective residuals in (1) are sums of two actual perfect matchings. For sufficiency, consider the left residual. It has one copy of semiedges \(1,2,3,4\), two copies of semiedge \(5\), degree two at every internal vertex, and only even closed components. Two-colour its edge copies alternately. The two copies of semiedge \(5\) get different colours. Every resulting perfect matching has odd boundary cardinality because the pole has odd order. The other four semiedges form two residual paths. One path with equal-coloured endpoints and one with opposite-coloured endpoints would give even boundary cardinalities. If both paths had equal-coloured endpoints, choosing their phases to put all four endpoints in one colour would make an all-terminal BF row together with \(A,B,X,C\). Thus both paths have opposite-coloured endpoints.

For the endpoint set \(\{1,2,3,4\}\), the three partitions into two pairs are \(12|34\), \(13|24\), and \(14|23\). A two-path residual with opposite endpoint colours admits exactly the two triple-matching decompositions *other than its path pairing*. The partition \(12|34\) is \(T\)--\(T\); its availability would make a forbidden BF row with the fixed quartet. Hence the paths must pair \(12|34\), and the desired \(q_{14}+r_{23}\) decomposition exists. For the right residual the endpoints are \(\{2,3,4,5\}\), the unique \(T\)--\(T\) partition is \(23|45\), and the same argument supplies \(q'_{25}+r_{34}\). This proves (4) using complete graph-induced matching closure. The unproved exact-support step is \(\Lambda_L\cap\Lambda_R\ne\varnothing\).

## Seven-vertex actual cubic pole

Let the proper graph be three internally disjoint \(u\)-\(v\) paths
\[
u-a-v,\qquad u-b-c-v,\qquad u-d-e-v.
\]
Put semiedges \(s_1,s_2,s_3,s_4,s_5\) at \(b,d,c,a,e\), respectively. Number proper edges
\(e_0=ua,e_1=av,e_2=ub,e_3=bc,e_4=cv,e_5=ud,e_6=de,e_7=ev\).
The pole is simple, connected, proper-bridgeless, has five distinct terminals, and has girth five.

The following is its **entire** perfect-matching family; the last column is the boundary mask.

| Mask | Proper edges | Boundary | Mask | Proper edges | Boundary |
|---|---|---|---|---|---|
| \(M_0\) | 0,4,6 | 1 | \(M_7\) | 2,7 | 234 |
| \(M_1\) | 0,3,7 | 2 | \(M_8\) | 1,3,5 | 5 |
| \(M_2\) | 2,4,6 | 4 | \(M_9\) | 0,4 | 125 |
| \(M_3\) | 3,5,7 | 4 | \(M_{10}\) | 4,5 | 145 |
| \(M_4\) | 1,2,6 | 3 | \(M_{11}\) | 2,4 | 245 |
| \(M_5\) | 0,7 | 123 | \(M_{12}\) | 1,5 | 135 |
| \(M_6\) | 5,7 | 134 | \(M_{13}\) | 1,2 | 235 |

For completeness, a matching must select one proper edge at each of \(u,v\). Of the nine ordered choices, \((ua,av)\) is impossible because both meet \(a\). For the other eight, in the order \((ua,cv),(ua,ev),(ub,av),(ub,cv),(ub,ev),(ud,av),(ud,cv),(ud,ev)\), the number of completions is \(2,2,2,2,1,2,1,2\). These are exactly the fourteen masks above, so the following claim is about complete PM closure.

Both required positive cells occur, with actual full-mask BF rows
\[
\begin{aligned}
 M_0+M_1+M_4+M_3+M_{13}+M_{10}&=2\mathbf1
 &&[(14)(23)],\\
 M_1+M_4+M_2+M_8+M_6+M_9&=2\mathbf1
 &&[(25)(34)].                                  \tag{5}
\end{aligned}
\]
Their proper-edge and semiedge loads are both exactly two. In the first row \((A,B,X,C,q_{14},r_{23})=(M_0,M_1,M_4,M_3,M_{13},M_{10})\); in the second \((B,Y,C,D,q'_{25},r_{34})=(M_1,M_4,M_2,M_8,M_6,M_9)\).

The complete singleton classes needed in (1) are
\(\mathcal P_1=\{M_0\},\mathcal P_2=\{M_1\},\mathcal P_3=\{M_4\},\mathcal P_4=\{M_2,M_3\},\mathcal P_5=\{M_8\}\).
If the left row uses \(C=M_2\), then \(A+B+X+C\) has load three on \(e_6=de\), from \(M_0,M_4,M_2\). If the right row uses \(C=M_3\), then \(B+Y+C+D\) has load three on \(e_3=bc\), from \(M_1,M_3,M_8\). No nonnegative triple-matching completion can undo either overload. Therefore
\[
 \Lambda_L=\{M_1+M_3\},\qquad
 \Lambda_R=\{M_1+M_2\},\qquad
 \Lambda_L\cap\Lambda_R=\varnothing.               \tag{6}
\]
The complete family has no all-terminal perfect matching: selecting all five semiedges leaves \(u,v\) unmatched, and \(uv\) is absent. Hence it has no all-terminal BF cover. It **does** have forbidden \(T\)--\(T\) support:
\[
M_1+M_4+M_2+M_8+M_{10}+M_5=2\mathbf1
\quad[(23)(45)].                                      \tag{7}
\]
It also has a forbidden \(T\)-loop: \(M_1+M_4+M_{10}=\mathbf1\), so doubling this three-matching colouring gives type \([23]\), with \(23\in T\). These explicit rows identify why the example does not refute the exact Case-XII implication; it also does not supply all required positive cells.

## Boundary reached

Complete PM closure, the two relevant positive cells, and absence of all-terminal covers do not force \((*)\), even in a simple connected bridge-free girth-five cubic pole. Exact Case-XII support adds all forty positive types and excludes every \(T\)-loop and \(T\)--\(T\) type. Under those additional negative exclusions, (4) shows that terminal pairing of the two triple masks ceases to be an independent issue; the remaining question is whether the two **complete singleton pair-load spectra** in (4) intersect. This pulse proves neither that intersection nor an exact-support counterexample. No graph-order scan or bulk local enumeration was run.
