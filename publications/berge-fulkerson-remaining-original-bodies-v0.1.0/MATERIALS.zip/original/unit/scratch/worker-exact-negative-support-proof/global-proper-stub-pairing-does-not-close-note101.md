# Global proper-stub pairing does not close the Note 101 countermodel

The remaining selected-family implication after Note 101 is false, even for
a connected cubic five-pole multigraph.  Pairing all proper stubs by their
common 22-occurrence columns does not force a selected all-terminal cover, a
selected (T)--(T) cover, or either endpoint quadratic.

This is a statement about the displayed selected perfect matchings.  It does
not control the complete perfect-matching closure of the resulting graph.

## Parity reduction

Keep the 22 named occurrences of Note 101 and identify the three repeated
matching identities

\[
 A=p^1_{13},\qquad P_3=p^3_{13},\qquad P_5=p^5_{25}.
\]

A legal incidence block is a subset of the 22 positions which contains
exactly two positions in each of the six BF rows and is constant on each of
the nineteen matching identities.  A legal trivalent star is a partition of
all 22 positions into three legal blocks.  The finite system has

\[
 719\text{ blocks},\qquad 4194\text{ unordered legal stars}.
\]

Let (e_b) denote the GF(2) coordinate of a block (b), and let

\[
 W=\operatorname{span}_{\mathbf F_2}
 \{e_b+e_c+e_d:\{b,c,d\}\text{ is a legal star}\}.
\]

For the five original terminal blocks (b_1,\ldots,b_5), the exact global
pairing condition is

\[
 e_{b_1}+\cdots+e_{b_5}\in W.                    \tag{1}
\]

Indeed, the two proper blocks of any chosen terminal star contribute its
three-block star vector plus its terminal coordinate.  Changing the chosen
terminal completion adds another generator of (W), so (1) is independent
of those choices.  Internal vertices contribute precisely the generators of
(W).

The Omen calculation finds (1) feasible.  Gaussian elimination reaches rank
706 and returns an explicit 59-star representation of the five-terminal
syndrome.  Combining it with the five original terminal stars and cancelling
duplicate internal stars modulo two gives 62 internal vertices.  Together
with the five terminal vertices this yields a 67-vertex construction.

No representation by one or three stars exists for the terminal syndrome.
Equivalently, the shortest possibilities below five have been exhausted.
For the actual ten-proper-stub syndrome, no representation by two or four
internal stars exists.  These bounded nonexistence statements are not a
global minimality claim for the 67-vertex construction.

## Explicit globally paired model

The JSON certificate specifies all vertices by their three block indices and
all proper edges by their two endpoints and common 22-bit column.  It has

\[
 |V|=67,\qquad |E_{\rm proper}|=98,
\]

plus five labelled semiedges.  Thus (3|V|=2|E_{\rm proper}|+5).  Direct
verification gives:

- the graph is connected and loopless;
- every vertex has total degree three;
- it has two parallel-edge pairs, so the object is a multigraph rather than
  a simple graph;
- each of the nineteen distinct selected identities is a genuine perfect
  matching of this common graph;
- each of the six displayed rows covers every proper edge and semiedge
  exactly twice;
- terminal boundary classes are exactly those of the five original Note 101
  coordinates;
- exhaustive selected-family testing gives no all-terminal matching and no
  (T)--(T) cover;
- the unique state-35 carrier decomposition and both empty endpoint
  projections remain unchanged.

The last point is also immediate structurally.  Any global endpoint
quadratic would restrict to a vertexwise equality on the five original
terminal vertices, but Note 101 already falsifies every such equality there.

## Consequence and remaining boundary

Therefore common local trivalence plus global equality-column pairing into
one connected cubic five-pole multigraph still does not imply the desired
anchored quadratic or selected forbidden support.  The next positive
statement must use at least one condition absent here:

1. simplicity of the common graph; or
2. the complete graph-induced perfect-matching closure and its additional BF
   rows.

The calculation does **not** show that the complete closure of this
67-vertex multigraph is exact Case XII.  Extra perfect matchings may create an
all-terminal cover, a (T)--(T) cover, or a usable endpoint splice.  No
closure enumeration was attempted.

## Reproduction

The calculation was run on host `omen` with Python 3.10.12:

```text
cd [local archival reference]
/usr/bin/time -v python3 solve_note101_global_stub_pairing.py
```

It used 17,152 KiB maximum resident memory and 1.91 seconds wall time.  The
terminal marker is

```text
NOTE101_GLOBAL_STUB_PAIRING_DECIDED
```

Local frozen files:

- `solve_note101_global_stub_pairing.py`
- `note101_global_stub_pairing_result.json`
- `note101_global_stub_pairing_omen_run.log`

SHA-256:

```text
88c106cc8f0e9304e643a369c3e36fdda236a6dee6bb7381e7c229722819054c  solve_note101_global_stub_pairing.py
36ec05b108fcbf43596e648c640fee88ef6624f005577ffb2d76b19c19e73fbf  note101_global_stub_pairing_result.json
64b53578b767aebee14c076ee592912b9a8b44a5d04a3c094de32640137df741  note101_global_stub_pairing_omen_run.log
```
