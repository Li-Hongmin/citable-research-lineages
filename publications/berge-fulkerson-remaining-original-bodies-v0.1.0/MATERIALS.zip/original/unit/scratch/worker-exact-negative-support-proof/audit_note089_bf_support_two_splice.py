#!/usr/bin/env python3
"""Audit BF support and Note-082 dependent two-splice fibres for Note 089."""

import argparse
import importlib.util
import json
from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path

S = {(0, 2), (0, 3), (1, 3), (1, 4), (2, 4)}
STATES = tuple(combinations(range(5), 2))
T = set(STATES) - S


def load_module(path):
    spec = importlib.util.spec_from_file_location("chain", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def add(vectors, indices):
    return tuple(sum(vectors[i][e] for i in indices)
                 for e in range(len(vectors[0])))


def state_name(state):
    return "".join(str(i + 1) for i in state)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    parser.add_argument("chain_script", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    frozen = json.loads(args.certificate.read_text())["certificate"]
    chain = load_module(args.chain_script)
    data = {
        "vertices": tuple(range(frozen["order"])),
        "proper": tuple(tuple(edge) for edge in frozen["proper_edges"]),
        "terminals": tuple(frozen["terminal_vertices_by_label"]),
    }
    pms = chain.perfect_matchings(data)
    assert len(pms) == frozen["perfect_matching_count"] == 57
    proper_count = len(data["proper"])
    edge_count = proper_count + 5
    vectors = tuple(tuple((pm >> e) & 1 for e in range(edge_count)) for pm in pms)
    boundary = tuple((pm >> proper_count) & 31 for pm in pms)
    classes = defaultdict(list)
    for index, mask in enumerate(boundary):
        classes[mask].append(index)

    groups = {state: defaultdict(list) for state in STATES}
    for state in STATES:
        i, j = state
        for q in classes[31 ^ (1 << i) ^ (1 << j)]:
            for p_i in classes[1 << i]:
                for p_j in classes[1 << j]:
                    decomposition = (q, p_i, p_j)
                    groups[state][add(vectors, decomposition)].append(decomposition)

    tait = {state for state in STATES if (1,) * edge_count in groups[state]}
    support = set()
    cell_rows = {}
    for left, right in combinations_with_replacement(STATES, 2):
        rows = set()
        for load, left_ds in groups[left].items():
            complement = tuple(2 - value for value in load)
            if min(complement) < 0:
                continue
            for left_d in left_ds:
                for right_d in groups[right].get(complement, ()):
                    rows.add((left_d[0], right_d[0], left_d[1], left_d[2],
                              right_d[1], right_d[2]))
        if rows:
            support.add((left, right))
            cell_rows[(left, right)] = tuple(sorted(rows))

    a_witness = None
    for row in product(classes[31], *(classes[1 << i] for i in range(5))):
        if add(vectors, row) == (2,) * edge_count:
            a_witness = row
            break

    ss = {pair for pair in support if pair[0] in S and pair[1] in S}
    tt = {pair for pair in support if pair[0] in T and pair[1] in T}
    st = support - ss - tt
    required_ss = set(combinations_with_replacement(sorted(S), 2))
    required_st = {tuple(sorted((s, t))) for s in S for t in T}

    # An edge in this row graph is one whole-difference paired splice:
    # exactly two occurrence positions change and their incidence-vector sum
    # is preserved.  Same-boundary positions guarantee a proper alternating
    # symmetric difference.
    total_st_rows = 0
    dependent_tests = 0
    nonempty_tests = 0
    first_nonempty = None
    cell_audit = {}
    for s in sorted(S):
        for t in sorted(T):
            cell = tuple(sorted((s, t)))
            rows = cell_rows.get(cell, ())
            if not rows:
                cell_audit[f"{state_name(s)}-{state_name(t)}"] = {
                    "rows": 0, "dependent_tests": 0, "nonempty": 0}
                continue
            # Reorient every row so slots 0,2,3 belong to s and 1,4,5 to t.
            if cell[0] != s:
                rows = tuple(sorted((r[1], r[0], r[4], r[5], r[2], r[3])
                                    for r in rows))
            row_set = set(rows)
            adjacency = {row: set() for row in rows}
            pair_sum = defaultdict(list)
            for row in rows:
                for left, right in combinations(range(6), 2):
                    key = (left, right,
                           tuple(vectors[row[left]][e] + vectors[row[right]][e]
                                 for e in range(edge_count)))
                    pair_sum[key].append(row)
            for (left, right, _), candidates in pair_sum.items():
                for first in candidates:
                    for second in candidates:
                        changed = [i for i in range(6) if first[i] != second[i]]
                        if changed == [left, right]:
                            adjacency[first].add(second)

            row_tests = 0
            row_nonempty = 0
            for source in rows:
                distance = {source: 0}
                parent = {source: None}
                queue = deque([source])
                while queue:
                    row = queue.popleft()
                    if distance[row] == 2:
                        continue
                    for following in adjacency[row]:
                        if following not in distance:
                            distance[following] = distance[row] + 1
                            parent[following] = row
                            queue.append(following)
                for replace in combinations((2, 3, 4, 5), 2):
                    anchors = tuple(i for i in (2, 3, 4, 5) if i not in replace)
                    desired_pairs = {
                        (target[replace[0]], target[replace[1]])
                        for target in rows
                        if all(target[i] == source[i] for i in anchors)
                        and any(target[i] != source[i] for i in replace)
                    }
                    for desired in desired_pairs:
                        row_tests += 1
                        targets = [target for target in rows
                                   if all(target[i] == source[i] for i in anchors)
                                   and (target[replace[0]], target[replace[1]]) == desired]
                        reachable = [target for target in targets
                                     if distance.get(target, 3) <= 2]
                        if not reachable:
                            continue
                        row_nonempty += 1
                        if first_nonempty is None:
                            finish = min(reachable, key=lambda r: (distance[r], r))
                            path = []
                            cursor = finish
                            while cursor is not None:
                                path.append(cursor)
                                cursor = parent[cursor]
                            path.reverse()
                            first_nonempty = {
                                "cell": [state_name(s), state_name(t)],
                                "replace_slots": list(replace),
                                "anchor_slots": list(anchors),
                                "source": list(source),
                                "desired_pair": list(desired),
                                "target_fibre_size": len(targets),
                                "distance": distance[finish],
                                "path": [list(row) for row in path],
                                "splice_slots": [
                                    [i for i in range(6) if path[k - 1][i] != path[k][i]]
                                    for k in range(1, len(path))],
                            }
            total_st_rows += len(rows)
            dependent_tests += row_tests
            nonempty_tests += row_nonempty
            cell_audit[f"{state_name(s)}-{state_name(t)}"] = {
                "rows": len(rows), "dependent_tests": row_tests,
                "nonempty": row_nonempty,
                "splice_graph_edges": sum(map(len, adjacency.values())) // 2}

    profile = {
        "tait_states": [state_name(state) for state in sorted(tait)],
        "SS": len(ss), "ST": len(st), "TT": len(tt), "A": a_witness is not None,
        "missing_SS": [f"{state_name(a)}-{state_name(b)}"
                       for a, b in sorted(required_ss - ss)],
        "missing_ST": [f"{state_name(a)}-{state_name(b)}"
                       for a, b in sorted(required_st - st)],
        "forbidden_TT": [f"{state_name(a)}-{state_name(b)}"
                         for a, b in sorted(tt)],
        "supported_pair_types": [f"{state_name(a)}-{state_name(b)}"
                                 for a, b in sorted(support)],
    }
    if tait != S:
        first_failure = "exact_tait_set_S"
    elif ss != required_ss:
        first_failure = "all_15_SS_types"
    elif st != required_st:
        first_failure = "all_25_ST_types"
    elif tt:
        first_failure = "no_TT_types"
    elif a_witness is not None:
        first_failure = "no_all_terminal_A_cover"
    else:
        first_failure = None

    result = {
        "status": ("dependent_two_splice_fibre_nonempty" if nonempty_tests
                   else "no_actual_ST_rows" if total_st_rows == 0
                   else "all_dependent_two_splice_fibres_empty"),
        "order": frozen["order"], "perfect_matchings": len(pms),
        "boundary_profile": profile,
        "first_failed_exact_case_xii_hypothesis": first_failure,
        "all_terminal_A_witness": list(a_witness) if a_witness else None,
        "actual_ordered_ST_rows": total_st_rows,
        "dependent_fibre_tests": dependent_tests,
        "nonempty_dependent_fibres": nonempty_tests,
        "first_nonempty": first_nonempty,
        "cell_audit": cell_audit,
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = dict(result)
    compact.pop("cell_audit")
    print(json.dumps(compact, indent=2, sort_keys=True))
    print("NOTE089_BF_SUPPORT_TWO_SPLICE_AUDITED")


if __name__ == "__main__":
    main()
