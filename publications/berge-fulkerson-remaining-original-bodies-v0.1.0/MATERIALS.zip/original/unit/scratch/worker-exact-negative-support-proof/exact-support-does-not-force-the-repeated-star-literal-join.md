# Exact support does not yet force the repeated-star literal join

Let \(\mathcal R_i\) be the complete actual row families of the four
Note-074 pivot cells, with singleton coordinates displayed as

\[
\begin{array}{c|c}
\mathcal R_1&(A,X,C,D)\quad (13,45),\\
\mathcal R_2&(A,B,X,C)\quad (14,23),\\
\mathcal R_3&(A,B,C,D)\quad (24,15),\\
\mathcal R_4&(B,Y,C,D)\quad (25,34).
\end{array}                                                     \tag{1}
\]

Here the letters denote actual perfect-matching identities, not merely
their singleton boundary classes, and

\[
\partial(A,B,C,D,X,Y)=(1,2,4,5,3,3).
\]

Assume that all four families are nonempty and that the complete BF support
is the exact Case-XII set: the fifteen \(S\)--\(S\) types and the twenty-five
\(S\)--\(T\) types occur, while the all-terminal type, all \(T\)--\(T\)
types, and all \(T\)-loops are absent.

These assumptions do not presently prove that the four relations in (1)
have a common literal section.  The unresolved statement is a lossless-join
property of actual perfect-matching identities, strictly stronger than
nonemptiness of the four boundary-type fibres.  No real exact-Case-XII pole
violating the property is known, so this is an information boundary rather
than a counterexample to the actual-pole implication.

## The first exact identity gate

Define

\[
\begin{aligned}
J_{31}=\{(A,B,C,D,X):{}&
 (A,B,C,D)\in\mathcal R_3,\\
 & (A,X,C,D)\in\mathcal R_1\}.
                                                               \tag{2}
\end{aligned}
\]

For an element of \(J_{31}\), put

\[
L_2(A,B,C,X)=2\mathbf1-A-B-C-X.                  \tag{3}
\]

Extension by an \(\mathcal R_2\)-row with the same literal identities is
equivalent to the actual factorization

\[
\boxed{
L_2(A,B,C,X)=q_{14}+r_{23}
}
                                                               \tag{4}
\]

for triple-boundary perfect matchings of the indicated states.  Thus the
first three-row join is nonempty exactly when

\[
J_{312}:=\{(A,B,C,D,X)\in J_{31}:
             L_2(A,B,C,X)\in
             \mathcal P_{\overline{14}}+
             \mathcal P_{\overline{23}}\}
\ne\varnothing.                                                \tag{5}
\]

This is the first gate in the fixed Note-024 diagnosis.  That pole has
eight elements of \(J_{31}\), but \(J_{312}=\varnothing\), despite all four
row families being nonempty.  It also has no all-terminal BF cover.  Hence
absence of the \(A\)-type alone does not force (4).  The example is not
exact-\(S\), because it has \(T\)-loops and \(T\)--\(T\) types, so it does
not settle the actual exact-Case-XII statement.

## Why excluding \(T\)--\(T\) types does not create (4)

There are two logically earlier ways for (4) to fail.  First, the literal
quartet \(A+B+C+X\) may have an edge of load three, so (3) is not
nonnegative.  In that case there is no residual on which the absence of a
\(T\)--\(T\) decomposition can act.

Second, even when (3) is a nonnegative degree-two residual, its component
parities need not admit the prescribed \(14\mid23\) colouring.  For
example, suppose its closed components are even and its two terminal paths
are odd, geometrically paired as \(13\mid24\).  Then the allowed
\(S\)--\(S\) factorization \(13\mid24\) exists, while both the target
\(S\)--\(T\) factorization \(14\mid23\) and the forbidden \(T\)--\(T\)
factorization \(12\mid34\) fail.  This local residual configuration is
therefore compatible with no \(T\)--\(T\) support but still violates (4).
It is not asserted here that this local configuration extends to an exact
Case-XII pole.

Absence of \(T\)-loops supplies pairwise intersection restrictions on
singleton perfect matchings whose boundary pair lies in \(T\).  Such
restrictions neither make (3) nonnegative nor choose a two-colouring of all
its components.  Absence of the all-terminal type likewise excludes a
different six-matching factorization; it does not name one companion
occurrence in (4).

## Complete closure does not align an arbitrary \(\mathcal R_2\)-row

Choose any existing row

\[
(q'_{14},r'_{23},A',B',X',C')\in\mathcal R_2.     \tag{6}
\]

The same-boundary differences \(A\triangle A'\), \(B\triangle B'\),
\(X\triangle X'\), and \(C\triangle C'\) are unions of proper alternating
cycles.  Complete perfect-matching closure guarantees the matchings obtained
after a specified cycle flip.  It does not preserve the double-cover load
of (6).  By the Note-082 criterion, each prescribed replacement requires a
particular companion occurrence to carry the target phase on every component
of the corresponding difference.

The Note-093 negative-support conclusions do not supply this occurrence:
they exclude all-terminal and \(T\)--\(T\) exits from a flip cube but do not
force the required cube-to-row phase intersection.  Consequently they do
not align even one prescribed coordinate of (6), and a fortiori do not
align all four coordinates to \((A,B,X,C)\).

Note 094 gives a genuine positive identity-preserving transfer only under a
physical equality of two residual copy-multigraphs for the same actual
class-3 matching.  From a pair in \(J_{31}\), cancellation of the common
letters gives only the aggregate load identity

\[
q_{24}+r_{15}+B=q_{13}+r_{45}+X.                  \tag{7}
\]

Equation (7) is not the common physical residual hypothesis of Note 094 and
does not imply (4).  Thus the common-residual theorem does not close this
join automatically.

## The complete sharp join condition

After (5), the last row requires a further literal section.  A repeated-star
selection exists exactly when there are

\[
(A,B,C,D,X)\in J_{312},\qquad Y\ne X,             \tag{8}
\]

and actual triple-boundary perfect matchings satisfying

\[
2\mathbf1-B-Y-C-D=q_{25}+r_{34}.                  \tag{9}
\]

Equivalently, the constrained natural join

\[
\mathcal R_1\Join\mathcal R_3\Join
\mathcal R_2\Join\mathcal R_4\bigm|_{X\ne Y}
\]

must be nonempty.  Conditions (5) and (8)--(9) are necessary and sufficient;
they expose the two actual-identity sections hidden by the four independent
support existentials.

The first new theorem needed is therefore already precise: exact negative
support would have to imply that at least one element of \(J_{31}\) satisfies
the mixed literal factorization (4).  One sufficient mechanism would be a
Note-082 component-aligned replacement sequence producing that factorization,
but such a sequence is not asserted to be necessary.  A full repeated-star
theorem must additionally force (9) with a class-3 identity \(Y\ne X\).
Neither conclusion is supplied by Notes 074, 082, 093, or 094.  The
actual-pole implication remains undecided at this literal
identity-compatibility gate.
