# Four empty projection certificates need a cross-endpoint occurrence section

Assume the two literal-anchored carrier families of Note 093, common cubic
incidence, the full perfect-matching family, and exact Case-XII negative
support.  Suppose all four projection intersections in Note 093(10) are
empty.  This does not by itself combine the four failures into a forbidden
all-terminal or \(T\)--\(T\) row.  The missing datum is an actual
perfect-matching identity which moves from one endpoint fibre into a
variable occurrence of another fibre.

## Agreement-region form of `Sep`

For a perfect matching \(M\) and an internal cubic vertex \(v\), write
\(M(v)\) for its selected incident edge.  For a companion \(L\) and a
target \(\widehat P\), define

\[
 \operatorname{Agr}(L,\widehat P)
   =\{v:L(v)=\widehat P(v)\},\qquad
 \operatorname{Blk}(L,\widehat P)
   =V\setminus\operatorname{Agr}(L,\widehat P).       \tag{1}
\]

Then

\[
 \operatorname{Sep}(L;P,\widehat P)
 \quad\Longleftrightarrow\quad
 V(P\mathbin\triangle\widehat P)
       \subseteq\operatorname{Agr}(L,\widehat P).     \tag{2}
\]

Indeed, at every vertex where \(P(v)\ne\widehat P(v)\), the edge
\(\widehat P(v)\) lies in \(\widehat P\setminus P\).  The `Sep` condition
therefore forces \(L(v)=\widehat P(v)\), and this simultaneously prevents
\(L\) from using \(P(v)\in P\setminus\widehat P\).  Conversely these local
equalities give both inclusions in the definition of `Sep`.  Because
\(P\) and \(\widehat P\) have the same boundary, their symmetric difference
is a disjoint union of proper alternating cycles, all lying in the
agreement region in (2).

Consequently, for one endpoint role with fixed half
\(H=(L_0,L_1,L_2)\), the empty projection test says precisely that

\[
 \widehat P\notin\mathcal F_i(K;j),\qquad
 \forall P\in\mathcal F_i(K;j)\ \forall a\in\{0,1,2\}:
 V(P\triangle\widehat P)\cap
 \operatorname{Blk}(L_a,\widehat P)\ne\varnothing.   \tag{3}
\]

The disjoint-pair and triangle certificates of Note 084 are the
occurrence-label versions of (3).  In particular, (3) is three row-local
blocking statements for each projected source matching; it is not an
identity between blockers belonging to different rows.

## Why the four certificates do not add

There are three distinct operations in the available hypotheses.

1. A row equation partitions the fixed load \(2\mathbf1\) into six actual
   matching occurrences.
2. Full perfect-matching closure says that a forced vector such as
   \(N+P-\widehat P\) belongs to the family when it is coordinatewise
   \(0/1\).
3. A projection records that a particular matching identity actually
   occurs in a specified three-matching decomposition of a carrier load.

Only the first and third operations contain occurrence information.
Closure in item 2 creates an actual matching identity but does not place
that identity into any prescribed carrier decomposition.  Likewise the
sets \(\operatorname{Blk}(L_a,\widehat P)\) in (3) have different \(L_a\),
different targets, and generally different source matchings.  Their union
or intersection is not a new row equation.

Combining the two endpoint failures inside one carrier does not change
this.  Each replacement is boundary preserving.  Even if both endpoint
replacements were possible, the two triple-boundary states of the row
would be unchanged, so the result would remain in the same allowed
\(S\)--\(T\) cell.  It would not become an all-terminal or \(T\)--\(T\)
row.

Nor can two rows from the \(23\)- and \(34\)-carrier families simply be
added and cancelled.  Their sum has load \(4\mathbf1\).  To reduce it to a
new six-occurrence double cover, a negative occurrence must cancel an
identical actual perfect-matching occurrence, or an independently proved
equal-load factorization must replace it.  Equations (3) supply neither.
The shared literal names \(X\) and \(Y\) are fixed-half occurrences; they
are not variable carrier occurrences, and the relevant empty projection
tests say exactly that the desired literal does not enter its required
projection.

Thus four empty-intersection certificates can coexist without any
well-defined operation that adds them.  Cubicity makes each individual
`Sep` test local as in (2), but it does not identify the matching selected
in two different row fibres.

## The unavoidable first cross-endpoint identity

This missing identity can be stated without introducing a new abstract
binary model.  For an endpoint occurrence
\(h=(R,P,\widehat P)\), let \(\mathcal C_h\) be the full partial-flip cube of
\(P\triangle\widehat P\), and define its occurrence-level output set

\[
 \operatorname{Out}(h)=
 \left\{
  N+P-P^I:
  N\in R\setminus\{P\},\ P^I\in\mathcal C_h,
  \ N+P-P^I\in\{0,1\}^{E}
 \right\}.                                             \tag{4}
\]

Every member of (4) is an actual perfect matching by full closure.  For an
endpoint family \(g\), let \(\operatorname{Act}(g)\) be the set of actual
matching identities occurring in any operative position of its rows over
all carrier colourings: both the three fixed-half companions and the three
variable carrier positions are included.  A genuinely cross-carrier
derivation by the
replacement/closure calculus of Notes 084, 091, and 093 must have a first
step at which an identity produced on one side occurs in an operative slot
on another side.  Therefore it necessarily satisfies

\[
 \boxed{
 \exists h,g\text{ from different carrier families}:\qquad
 \operatorname{Out}(h)\cap\operatorname{Act}(g)\ne\varnothing .
 }                                                       \tag{5}
\]

The necessity of (5) in this occurrence-preserving calculus is a
first-crossing argument.  Before the first such identity, every row
substitution and every partial flip remains tagged by its original
endpoint fibre.  Row-local operations preserve its triple-boundary type
and cannot merge two tags.  The first operation which uses information
from two endpoint fibres must therefore identify one actual output
matching with one operative occurrence in the other fibre, which is exactly
(5).

There is only one way to bypass a rank-one identity such as (5) when rows
are literally added and cancelled: one must supply a higher-rank balanced
load relation.  After cancelling all identical occurrences, it has the
form

\[
 \sum_{a=1}^{r}\chi_{M_a}
   =\sum_{b=1}^{r}\chi_{N_b},\qquad r\ge2.         \tag{5'}
\]

Here the two multisets touch different endpoint fibres and neither side
contains an occurrence from the other.  Equation (5') is unavoidable:
without it, equality of the two edge-load sums permits only literal
occurrence cancellation, reducing to (5).  Conversely, (5') is new
cross-endpoint information, not a consequence of an empty-intersection
certificate.  Full perfect-matching closure asserts the existence of
individual \(0/1\) vectors; it does not assert any prescribed equality of
sums such as (5').  Thus the exact first-crossing alternative for an
arbitrary algebraic row combination is **(5) or (5')**.

For the two Note 093 carrier families, boundary classes sharpen the
rank-one alternative (5).  Across all fixed and variable positions, their
only common singleton boundary class is \(3\), and their triple states are
different.  Hence the only possible cross-family operative identity has
singleton class \(3\).  Any rank-one cross-family proof must in particular
establish, in one direction or the
other,

\[
 \operatorname{Out}_{23}^{(3)}
       \cap\operatorname{Act}_{34}^{(3)}\ne\varnothing
 \quad\text{or}\quad
 \operatorname{Out}_{34}^{(3)}
       \cap\operatorname{Act}_{23}^{(3)}\ne\varnothing .       \tag{6}
\]

Condition (6) is necessary, not sufficient.  After the bridge, the same
occurrence chain must still reach one of the two forbidden sinks:

\[
 M\cap D_{2,g}=\varnothing                       \tag{7}
\]

for an all-terminal complement, or

\[
 2\mathbf1-B_{t,g}=M+Q_u+P_j,qquad u\in T,      \tag{8}
\]

for a \(T\)--\(T\) row.  Equations (5)--(8), with (5') as the only
higher-rank bypass, are the precise cross-endpoint occurrence section which
a combined contradiction would need.  Note 084 supplies only the local
blockers (3), Note 091 supplies the partial-flip cubes and sign tests, and
Note 093 quantifies all carrier colourings; none of them forces (5), (5'),
or (6).

## Decision

The four empty Note 093 projection intersections do not presently imply a
forbidden \(A\) or \(TT\) row, even when they belong to one common cubic
full-perfect-matching closure.  This is not a real exact-Case-XII
counterexample: no such pole is known.  It is an exact route boundary.
Any occurrence-preserving proof that the four certificates combine must
first produce the class-\(3\) cross-carrier occurrence identity (6), or a
more general first-crossing identity (5), and then show that the resulting
occurrence chain reaches (7) or (8).  A proof by adding whole row equations
must instead exhibit the explicit cross-fibre balanced relation (5') and
the same forbidden sink.  More agreement-region blockers, edge hits, or
anonymous positive rows provide neither kind of crossing datum.
