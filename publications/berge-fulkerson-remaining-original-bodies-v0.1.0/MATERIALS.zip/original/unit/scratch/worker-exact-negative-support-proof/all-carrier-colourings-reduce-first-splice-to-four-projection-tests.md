# All carrier colourings reduce the first-splice question to four projection tests

Consider only the two literal row families

\[
\begin{aligned}
\mathcal A_{23}:&\quad
 q+r_{23}+B+X+P_3+P_5=2\mathbf1,\\
\mathcal A_{34}:&\quad
 q'+r_{34}+Y+C+P_1+P'_3=2\mathbf1.               \tag{1}
\end{aligned}
\]

The four proposed first replacements are

\[
P_3\to Y,\qquad P_5\to D,\qquad
P_1\to A,\qquad P'_3\to X.                       \tag{2}
\]

This note uses the complete families of actual decompositions of the two
fixed complementary half-load carriers.  It does not use the pivot cubic
relations.  The result is an exact carrier-level countercondition.  The
available hypotheses do not eliminate it, and no real exact-Case-XII pole
is known which realizes it.

## Fixed halves and their complete colouring fibres

Put

\[
\begin{aligned}
H_{23}&=\chi_{r_{23}}+\chi_B+\chi_X,
&K_{23}&=2\mathbf1-H_{23},\\
H_{34}&=\chi_{r_{34}}+\chi_Y+\chi_C,
&K_{34}&=2\mathbf1-H_{34}.                       \tag{3}
\end{aligned}
\]

Both \(K_{23}\) and \(K_{34}\) are degree-three integral load
multigraphs.  Let

\[
\begin{aligned}
\mathcal D_{35}(K_{23})
 &=\{(q,P_3,P_5):
       \chi_q+\chi_{P_3}+\chi_{P_5}=K_{23}\},\\
\mathcal D_{13}(K_{34})
 &=\{(q',P_1,P'_3):
       \chi_{q'}+\chi_{P_1}+\chi_{P'_3}=K_{34}\}               \tag{4}
\end{aligned}
\]

be their complete oriented decomposition families.  Equivalently, these
are all proper three-edge-colourings of the load multigraphs with the
displayed terminal colours.  There is no compatibility condition between
the two halves beyond (3): every member of \(\mathcal D_{35}(K_{23})\),
together with the fixed labelled occurrences
\((r_{23},B,X)\), is a row of \(\mathcal A_{23}\), and every row of
\(\mathcal A_{23}\) arises this way.  The analogous statement holds for
\(\mathcal A_{34}\).

For an oriented state-\(ij\) carrier \(K\), write

\[
\mathcal F_i(K;j)=
 \{P_i:\ (Q,P_i,P_j)\in\mathcal D_{ij}(K)}       \tag{5}
\]

for its complete class-\(i\) projection.  Thus all actual carrier
colourings, including every boundary-preserving Kempe orbit, contribute to
the set (5).

## Internal companions are exactly carrier entry

For same-boundary perfect matchings \(P,\widehat P\), define

\[
\operatorname{Sep}(N;P,\widehat P)
\iff
\widehat P\setminus P\subseteq N
\quad\text{and}\quad
N\cap(P\setminus\widehat P)=\varnothing.          \tag{6}
\]

This is equivalent to

\[
N'=N+P-\widehat P                                \tag{7}
\]

being a perfect matching.  Fix a decomposition

\[
K=Q+P_i+P_j.                                     \tag{8}
\]

If a companion internal to \(K\), namely \(Q\) or \(P_j\), satisfies
(6) for \(P_i\to\widehat P_i\), then replacing the two participating
occurrences by \(\widehat P_i,N'\) gives another oriented decomposition
of the same carrier \(K\).  Hence

\[
\text{an internal companion works}
\quad\Longrightarrow\quad
\widehat P_i\in\mathcal F_i(K;j).                 \tag{9}
\]

Conversely, if \(\widehat P_i\in\mathcal F_i(K;j)\), choose a row whose
class-\(i\) occurrence is already \(\widehat P_i\).  The replacement is
degenerate, and the intersection over its empty desired-phase edge family
is nonempty.  This convention is exactly the degenerate case included in
Note 082.  Therefore, after taking the union over **all** actual rows,

\[
\boxed{
\text{some internal-companion first splice exists}
\iff \widehat P_i\in\mathcal F_i(K;j).
}                                                               \tag{10}
\]

If one insists that the replacement be nontrivial, the right side of
(10) must be replaced by the exact one-Kempe-adjacency condition: an
oriented decomposition containing \(P_i\ne\widehat P_i\) and one
containing \(\widehat P_i\) share their third occurrence pointwise.  This
qualification does not affect the present first-splice disjunction, which
allows the Note-082 degenerate case.

## The exact contribution of the fixed half

Let \(H=(L_0,L_1,L_2)\) be the three occurrence-labelled perfect
matchings in the fixed half.  For a desired literal \(\widehat P_i\), put

\[
\mathcal G_H(\widehat P_i)=
 \{\widehat P_i\}\ \cup
 \bigcup_{a=0}^2
 \{P\in\mathcal P_i:
       \operatorname{Sep}(L_a;P,\widehat P_i)\}.                \tag{11}
\]

Then the complete first-splice condition for the fixed carrier is

\[
\boxed{
\exists\text{ actual row with a nonempty companion intersection}
\iff
\mathcal F_i(K;j)\cap\mathcal G_H(\widehat P_i)\ne\varnothing.
}                                                               \tag{12}
\]

Indeed, membership through the first set in (11) is (10).  Membership
through one of the other three sets gives a successful companion in the
fixed half.  Conversely, every companion is either one of the two other
occurrences of the carrier decomposition, covered by (10), or one of the
three fixed occurrences, covered directly by (11).  This exhausts the
five possible row companions.

Notice that a fixed-half splice changes the two half-loads, so it is not a
Kempe move of \(K\).  Its existence depends only on the carrier projection
\(\mathcal F_i(K;j)\) and the three pointwise fixed matching vectors; it
does not depend on which triple decomposition completes a given \(P_i\).

## The fourfold carrier-level countercondition

Apply (12) to (1)--(2).  All four first-splice intersections are empty if
and only if

\[
\begin{aligned}
\mathcal F_3(K_{23};5)&\cap
 \mathcal G_{(r_{23},B,X)}(Y)=\varnothing,\\
\mathcal F_5(K_{23};3)&\cap
 \mathcal G_{(r_{23},B,X)}(D)=\varnothing,\\
\mathcal F_1(K_{34};3)&\cap
 \mathcal G_{(r_{34},Y,C)}(A)=\varnothing,\\
\mathcal F_3(K_{34};1)&\cap
 \mathcal G_{(r_{34},Y,C)}(X)=\varnothing.        \tag{13}
\end{aligned}
\]

Equivalently, for each of the four endpoints:

1. the desired literal matching does not occur in the relevant oriented
   carrier fibre; and
2. every matching which does occur in that projection fails the
   \(\operatorname{Sep}\) test against each of the three fixed-half
   occurrences.

Equation (13) is strictly sharper than saying that one displayed source
row has an empty label intersection.  It quantifies over every actual
three-edge-colouring of the fixed carrier and all five companion positions.

There is an equivalent edge-label form.  In each actual row and for each
desired-phase edge of \(P\triangle\widehat P\), label the edge by the two
other occurrence positions using it.  Under (13), every one of the four
label families in every relevant row has empty total intersection.  By the
two-set classification, it therefore contains an inclusion-minimal core of
one of the forms

\[
\{\{a,b\},\{c,d\}\},
\qquad
\{\{a,b\},\{a,c\},\{b,c\}\}.                   \tag{14}
\]

Conversely, such an empty core in every row for all four replacements
implies (13).  Thus (13)--(14) are the precise carrier-level
countercondition requested in the pulse.

## What the Kempe action does and does not add

A boundary-preserving two-colour Kempe switch moves between vertices of
\(\mathcal D_{ij}(K)\).  Switches involving the class-\(i\) colour enlarge
or move within the projection \(\mathcal F_i(K;j)\); switches avoiding it
leave the source matching \(P_i\) unchanged.  An internal-companion splice
is itself exactly a two-colour exchange, possibly on a union of alternating
components, which fixes the third occurrence.  Hence the complete Kempe
action is already accounted for by (10)--(12).

It does not exchange the quantifiers in a companion-label obstruction.
Different colouring vertices may have different cores (14), and a Kempe
edge imposes no requirement that the same companion position survive all
desired-phase labels at either endpoint.  Nor does Kempe connectivity force
an externally prescribed perfect matching such as \(Y,D,A,X\) to belong
to the projection (5).  Finally, a successful fixed-half splice leaves the
carrier \(K\), so no orbit theorem internal to \(K\) can create it without
the separate sign condition in (11).

Exact Case-XII column saturation ensures the relevant carrier states have
actual decompositions, but it does not identify their singleton
occurrences with the four prescribed literals.  The known negative support
conditions likewise do not force any intersection in (13) to be nonempty.
Thus the complete colouring and Kempe data reduce the problem exactly to
(13); they do not prove its negation.

## Decision boundary

No general proof of the four-endpoint disjunction follows from the fixed
half-load colourings and their Kempe action.  There is also no real
exact-Case-XII repeated-extension pole known to satisfy (13), so (13) is
not a real counterexample.

The pulse therefore stops at a strict boundary: a positive proof must show
that at least one of the four carrier projections meets its corresponding
set (11).  In concrete terms, it must force either literal entry into one
oriented carrier fibre or one cross-half \(\operatorname{Sep}\) sign test.
Arguments which only add more carrier colourings or relate them by Kempe
switches, without forcing one of these four incidences, leave the exact
countercondition unchanged.
