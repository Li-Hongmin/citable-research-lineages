# The full closure of the Note 101 global multigraph immediately creates an A cover

## Fixed object and decision

Consider the frozen 67-vertex connected cubic five-pole multigraph in
`note101_global_stub_pairing_result.json`.  Its 98 proper edges are treated as
distinct edge objects; in particular, the two parallel endpoint pairs
\((0,5)\) and \((1,62)\) are not identified.  The five semiedges have object
indices 98 through 102.

The selected nineteen perfect matchings satisfy the six Note 101 rows, have
no selected A or T--T cover, and retain the two empty state-35 endpoint
intersections.  The question was whether these properties survive closure
under every perfect matching of the fixed multigraph.

They do not.  The graph-induced closure contains a concrete A cover.  Hence
this multigraph is not exact Case XII and is not a real Note 082
counterexample candidate.

## Exact early-witness queries

The first query quantified over all graph-induced perfect matchings
\((q_{35},P_3,P_5)\) satisfying

\[
q_{35}+P_3+P_5
=2\mathbf 1-(r_{23}+B+X).
\]

It asked simultaneously whether \(P_3\) enters the literal \(Y\) fibre or
has a Note 093 `Sep` companion in \(\{r_{23},B,X\}\), or whether the analogous
condition holds for \(P_5\to D\).  This finite query is UNSAT.  Thus both
endpoint intersections remain empty even in the complete matching closure
of this fixed multigraph.

The next query chose five graph-induced perfect matchings with singleton
boundaries \(0,1,2,3,4\), requiring every proper edge object to have load at
most two.  It is SAT.  The five singleton matchings are recorded literally
in `note101_global_multigraph_closure_result.json`.  If their load is \(m\),
the extracted sixth matching is

\[
P_*=\{e:m(e)=1\}.
\]

It has boundary \(\{0,1,2,3,4\}\), namely all five semiedges, and its edge
objects are

```text
2,21,23,24,26,37,39,40,41,44,45,46,47,48,51,53,56,65,
68,70,72,73,74,75,77,81,89,93,95,96,97,98,99,100,101,102.
```

The checker independently verifies that each of the six listed edge-object
sets meets every vertex exactly once and that their total load is exactly
two on all 103 edge objects.  This is therefore a genuine BF A-cover witness,
not merely a boundary-signature solution.

The local cubic count also explains why the complement is forced.  At every
nonterminal vertex, five matching incidences distributed with load at most
two over three incident edge objects have multiplicities \((2,2,1)\).  At a
terminal vertex its singleton semiedge has load one and the two proper edge
objects each have load two.  Hence the load-one objects form the displayed
all-terminal perfect matching.

Because the forbidden A witness is decisive, no T--T query and no complete
positive-support classification was run.  Their values remain undetermined
and are irrelevant to rejecting this candidate.

## Reproduction and scope

The only closure run was performed on `omen` in

```text
[local archival reference]
```

using Python 3.10.12, Z3 5.1.0, one process, a 1-GiB virtual-memory limit,
and a 240-second outer timeout.  It terminated with

```text
NOTE101_MULTIGRAPH_A_WITNESS
```

after 0.14 seconds wall time with maximum RSS 54,528 KiB.  No process remained
afterward.  Frozen SHA-256 values are

```text
e582fa2eadb956fd062d4cfa55fe62934837c82cbc253bed33e6cd325687c1f6  check_note101_global_multigraph_closure.py
36ec05b108fcbf43596e648c640fee88ef6624f005577ffb2d76b19c19e73fbf  note101_global_stub_pairing_result.json
50dbc06e52b90a3a482e26652cdbfaa103f77cc2de050993aebbd0934ed029ce  note101_global_multigraph_closure_result.json
b2e2291d4c19c383030c7156d86b743188cfdf013a737dfbfbf02f7432d0fbf6  note101_global_multigraph_closure_omen_run.log
```

This rejects only the frozen 67-vertex multigraph realization.  It does not
prove that every global pairing of the Note 101 signatures acquires an A
cover, and it does not decide whether some simple cubic five-pole can realize
the same selected antecedent while avoiding all forbidden closure types.
