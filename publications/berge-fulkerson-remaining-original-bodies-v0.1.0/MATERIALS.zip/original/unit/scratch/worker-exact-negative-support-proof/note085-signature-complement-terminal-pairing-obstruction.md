# Terminal pairing blocks the legal-complement lift of Note 085

The 48 frozen Note 085 signatures can each be completed individually to a
legal trivalent signature triple after new signatures are allowed.  The
simultaneous terminal pairing required by the proposed 91-vertex multigraph
lift is nevertheless impossible.

## Individual legal complements

For a frozen signature \(c\in\{0,1\}^{125}\), call \(d,e\) a legal
complement pair when

\[
 c+d+e=\mathbf1                                      \tag{1}
\]

tokenwise, each of \(d,e\) has load two on all fifty designated BF rows,
and each satisfies all six formal cube relations from Note 085.  Omen solves
this finite binary system separately for every frozen coordinate.  All
48 coordinates admit a pair \((d,e)\).  Thus the earlier fact that no three
*frozen* signatures form a vertex is not an obstruction once new legal
signatures are permitted.

## The terminal obstruction

For the five terminal signatures \(c_1,\ldots,c_5\), the proposed lift needs
ten complement halfedges

\[
 d_1,e_1,\ldots,d_5,e_5
\]

to be paired into five proper edges.  The two halfedges of each proper edge
must carry the same signature.

This joint pairing is impossible for a boundary reason that does not depend
on the internal row or cube equations.  A triple token with state \(ij\)
uses the three terminal semiedges outside \(\{i,j\}\) and uses neither
terminal semiedge \(i\) nor \(j\).  At each of the latter two terminal
vertices, equation (1) forces exactly one complement halfedge to be selected.
At each of the other three terminal vertices, the selected terminal semiedge
forces both complement halfedges to be absent.  Hence the selected proper
edge must join terminal vertices \(i\) and \(j\).

Consequently every distinct triple state \(ij\) present in the token pool
forces a terminal proper edge with endpoint pair \(ij\).  The 125-token
Note 085 pool contains tokens of all ten states

\[
 \binom{[5]}2
 =\{12,13,14,15,23,24,25,34,35,45\}.               \tag{2}
\]

These require all ten distinct endpoint pairs of \(K_5\).  But the ten
complement halfedges form only five proper edges, so they realize at most
five endpoint pairs.  This contradiction proves joint UNSAT.

The edge-count certificate is already supported on any six distinct states;
for example

\[
 \{13,14,24,25,35,12\}.                            \tag{3}
\]

They require six distinct terminal edges while only five are available.
This six-state certificate is sharp for the counting obstruction: deleting
any one demand leaves only five prescribed endpoint pairs, which the count
alone no longer excludes.  No claim is made that every such five-state
subsystem satisfies the additional row and cube equations.

## Consequence

The exact finite lift requested from the frozen Note 085 system is UNSAT.
The failure is not an individually uncompletable frozen signature:
all 48 individual complement systems are satisfiable.  It occurs precisely
when the ten terminal complement halfedges are required to pair within the
five terminal vertex types.

Therefore the prescribed construction cannot produce the proposed
91-vertex cubic multigraph five-pole.  No vertex certificate, edge pairing,
or subsequent perfect-matching verification exists for this construction.
This does not rule out a different trivalent lift that changes the base
signatures or permits a different global pairing architecture; both are
outside the finite problem considered here.

## Omen reproduction

The calculation reads only the frozen JSON and its deterministic Note 085
row/cube constructor:

```text
python3 -u lift_note085_by_signature_complements.py \
  joint_carrier_common_binary_result.json \
  synthesize_joint_carrier_guard_model.py \
  --timeout-ms 300000 --json result.json
```

The frozen hashes are

```text
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
bf7bb4b4ce5e3662f18bc044b50b454380f9d2a38b3fe24fb6872972b3dc7d8f  synthesize_joint_carrier_guard_model.py
1b865e22ffe4aa622c63da18b9405280ea7aaa8b0b1787b436f166373e67b461  lift_note085_by_signature_complements.py
4d13ae1cb1a33adb16b59e30628eb90c716b9ec3ada7fcf7446869ef7793dcac  note085_signature_complement_lift_result.json
412b159af09cee55b6209549db72decd63f5bcb79b46d07bda41d695f1f5203c  note085_signature_complement_lift_omen_run.log
```

One Python 3.10.12 process on Omen finished in 4.04 seconds with peak
resident memory 80,180 kB and exit status zero.  It returned

```text
individual_complements = 48
status = terminal_joint_pairing_unsat
NOTE085_TRIVALENT_MULTIGRAPH_LIFT_UNSAT
```
