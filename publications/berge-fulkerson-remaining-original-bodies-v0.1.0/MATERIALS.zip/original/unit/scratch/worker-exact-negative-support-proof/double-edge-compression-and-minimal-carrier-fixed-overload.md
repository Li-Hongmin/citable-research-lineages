# Double-edge compression and a minimum carrier-fixed overload

Let \(A\) be a three-perfect-matching half-load of a cubic 5-pole \(H\).
Replace every original edge \(f\) by \(A(f)\) labelled copies; the resulting
load multigraph \(H_A\) is cubic and its proper 3-edge-colourings are exactly
the decompositions of \(A\) into three perfect matchings.

Suppose that an original proper edge \(e=uv\) has \(A(e)=2\), and that in a
state \(s=ia\) decomposition both singleton matchings \(P_i,P_a\) use
\(e\).  The two copies of \(e\) in \(H_A\) therefore receive the singleton
colours \(i,a\); call them the double-edge block.

## Compression equivalence

At each of \(u,v\), the two parallel copies consume two incidences.  Let the
third incidences be \(ux\) and \(vy\).  In the standard terminal-free case
these are proper edges.  Delete \(u,v\) and the double block, and replace
\(ux,vy\) by one edge

\[
  r=xy.                                           \tag{1}
\]

Call the compressed cubic 5-pole \(K\).  The current colouring shows that
\(x\ne y\): the two outside edges have the same third colour and hence could
not meet at one vertex.

Every proper 3-edge-colouring of \(H_A\) assigns distinct colours to the two
parallel copies.  Its two outside edges must receive the common third
colour.  Compression therefore gives a proper colouring of \(K\), with
\(r\) in that third colour.  Conversely, every colouring of \(K\) lifts in
exactly two ways, by assigning the other two colours to the two copies of
\(e\).  Terminal colours are unchanged, so the state is preserved.

In a fixed oriented state \(ia\), name the colours by their boundary
classes: colour \(i\) has singleton boundary \(i\), colour \(a\) has
singleton boundary \(a\), and colour \(q\) has triple boundary
\([5]\setminus\{i,a\}\).  The compression correspondence gives

\[
\begin{split}
 &\text{the class-}i\text{ matching avoids the original edge }e\\
 &\qquad\Longleftrightarrow
 \text{the two block copies have colours }a,q\\
 &\qquad\Longleftrightarrow
 r\text{ has colour }i\text{ in the compressed colouring}.  \tag{2}
\end{split}
\]

Thus the proposed equivalence is exact, with two qualifications: it is a
statement about colourings of the fixed load multigraph, not arbitrary
perfect matchings of \(H\); and the usual proper-edge formulation assumes
the block is terminal-free.  If exactly one third incidence is a semiedge,
the same suppression gives a replacement semiedge with its boundary label.
If both are semiedges, suppression does not produce a cubic 5-pole with a
proper replacement edge, so the original formulation is not defined without
an additional boundary convention.

## The 5-cycle does not force the replacement colour

Let \(K\) be the 5-cycle pole: attach one labelled semiedge at every vertex
of a proper 5-cycle.  Put the terminal labels in cyclic order

\[
  1,3,5,2,4.
\]

Its state set is exactly

\[
  S=\{13,35,25,24,14\}.                         \tag{3}
\]

Indeed, in every proper 3-edge-colouring the two singleton-colour terminals
are adjacent on the odd cycle, and conversely every adjacent pair occurs.

Fix the state \(s=13\), and let \(r\) be the cycle edge joining terminals
1 and 3.  In every oriented state-13 colouring, the semiedges at its ends
have singleton colours 1 and 3.  Properness forces \(r\) to have the third,
triple-boundary colour \(q\).  In particular,

\[
  \mathcal R(K)=S
  \quad\not\Longrightarrow\quad
  \text{a state-13 colouring with }r\text{ coloured }1.       \tag{4}
\]

So the state set alone cannot force the colouring required by (2).

## A seven-vertex half-load with global flexibility

The preceding obstruction can be lifted to a genuine half-load while also
making the singleton class globally flexible.  Replace \(r=xy\) in the
underlying pole by

\[
  x-u,\qquad e=uv,\qquad g=uv,\qquad v-y,        \tag{5}
\]

where \(e,g\) are two distinct parallel proper edges.  The resulting
loopless cubic multigraph 5-pole \(H\) has seven vertices.

Lift the state-13 colouring of \(K\) to three perfect matchings as follows:

- the triple matching uses both outside edges \(xu,vy\);
- the class-1 and class-3 matchings both use the original edge \(e\);
- all other choices agree with the colouring of \(K\).

Their sum is a half-load \(A\) with

\[
  A(e)=2,\qquad A(g)=0.                          \tag{6}
\]

The load graph \(H_A\) is precisely the double-edge expansion of \(K\), so
its state set is still exactly \(S\).  By (2) and (4), every state-13
decomposition of this fixed \(A\) has its class-1 matching use \(e\).

Nevertheless class 1 is globally flexible in the full pole.  Replacing
\(e\) by its parallel mate \(g\) in the displayed class-1 perfect matching
gives a same-boundary perfect matching avoiding \(e\).  It cannot enter
\(A\), for the immediate support reason \(A(g)=0\).  The same observation
applies to class 3.

This example even lies in a literal BF row.  Define the complementary
half-load \(B=2\mathbf1-A\).  On the block it has

\[
  B(e)=0,\qquad B(g)=2,
\]

and elsewhere it has the same unit loads as \(A\).  The same three
colour classes, with \(g\) replacing \(e\) in the two singleton matchings,
decompose \(B\).  Hence \(A+B=2\mathbf1\) is an actual loop-type BF cover
of state \((13)(13)\).

The example is order-minimal in the loopless multigraph category under the
terminal-free compression setup: the compressed pole needs five distinct
terminal vertices, and expanding one proper replacement edge by a
two-vertex double block gives order at least seven.  It is not simple and is
not asserted to have exact-40 support.

## Boundary isolated

Compression proves that carrier-fixedness of \(e\) is exactly a
prescribed-edge-colour obstruction in the compressed load pole.  The
condition \(\mathcal R(K)=S\) records which terminal states occur but does
not record which colours can be placed on \(r\) inside one oriented state.
Even global same-class flexibility in \(H\), and even an actual complementary
BF half-load, do not repair this loss: an avoiding matching may be forced to
use an edge outside the support of \(A\).

Thus any positive exact-Case-XII argument needs a genuinely fibre-level
statement forcing the prescribed colour of \(r\), or equivalently forcing
an \(e\)-avoiding matching inside the fixed oriented carrier.  State
saturation alone is strictly insufficient.
