# Carrier entry is exactly a residual parity problem

Let \(H\) be a loopless cubic 5-pole and fix a half-load

\[
  A=\chi_{Q_s}+\chi_{P_i}+\chi_{P_a},           \tag{1}
\]

where \(s=ia\), \(Q_s\) has triple boundary
\(U=[5]\setminus\{i,a\}\), and \(P_i,P_a\) have singleton boundaries
\(i,a\).  Thus \(A\) has incident degree three at every vertex and load
one on every terminal semiedge.  In a BF row, \(A+(2\mathbf1-A)=2\mathbf1\),
so every edge load of \(A\) is at most two.

Suppose that \(P_i'\) is another perfect matching with singleton boundary
\(i\).  We determine exactly when it enters the same carrier \(A\) at the
same state \(s\), meaning that there are actual perfect matchings
\(Q_s',P_a'\) such that

\[
  A=\chi_{P_i'}+\chi_{Q_s'}+\chi_{P_a'}.        \tag{2}
\]

## Residual criterion

Put

\[
  D=A-\chi_{P_i'}.                              \tag{3}
\]

If \(D\ge0\), replace each proper edge or semiedge \(f\) by \(D(f)\)
labelled copies.  At every vertex the residual degree is

\[
  3-1=2.                                        \tag{4}
\]

At the terminals,

\[
  D(i)=0,\qquad D(j)=1\quad(j\ne i).            \tag{5}
\]

Hence the residual multigraph is a disjoint union of closed cycles and two
paths whose four semiedge endpoints are

\[
  \{a\}\mathbin{\dot\cup}U.                    \tag{6}
\]

Copies are counted separately, so two copies of one proper edge form a
2-cycle.

The decomposition (2) exists if and only if all of the following hold:

1. **Nonnegativity:** \(D(f)\in\{0,1,2\}\) for every edge and semiedge;
   equivalently, \(P_i'\) uses no edge outside the support of \(A\).
2. **Closed components:** every closed residual cycle has even length.
3. **Terminal paths:** the path joining \(a\) to one terminal of \(U\) has
   even proper-edge length, and the path joining the remaining two terminals
   of \(U\) has odd proper-edge length.

This is the one-subtracted-matching analogue of Note 078.

## Proof and exact boundary colours

Colour copies belonging to \(Q_s'\) red and copies belonging to \(P_a'\)
blue.  At each vertex the two residual incidences must have opposite
colours.  Consequently colours alternate along every residual component,
so every closed component is even.

The terminal colours are forced:

\[
  a\text{ is blue},\qquad
  j\in U\text{ is red},\qquad
  i\text{ has no residual semiedge}.             \tag{7}
\]

If a terminal path contains \(k\) proper-edge copies and its endpoint
colour bits are \(c_0,c_1\), with red \(=0\) and blue \(=1\), alternation
gives

\[
  c_0\mathbin\oplus c_1\equiv k+1\pmod2.       \tag{8}
\]

Thus the blue--red path from \(a\) has even proper length, while the
red--red path between the remaining two members of \(U\) has odd proper
length.  This proves necessity.

Conversely, alternately colour each even closed component.  Start each
terminal path with its forced colour from (7); the parity condition gives
the correct colour at the other end.  Each colour now has one incidence at
every vertex.  If a proper edge has two residual copies, alternation gives
them opposite colours, so neither matching uses an original edge twice.
The red and blue edge sets are therefore the required perfect matchings
\(Q_s'\) and \(P_a'\).  Distinct components have independent initial
colours, and there is no further compatibility condition.

## What exact-40 saturation supplies

For a fixed carrier \(A\), define the oriented state fibre

\[
 \mathcal F_i(A;a)=
 \{P\in\mathcal P_i:
   A-P\text{ satisfies conditions 1--3 above}\}.              \tag{9}
\]

Equivalently, \(P\in\mathcal F_i(A;a)\) exactly when \(P\) occurs as the
class-\(i\) singleton in a state-\(ia\) decomposition of this particular
half-load \(A\).  The displayed decomposition (1) shows that this fibre is
nonempty.

Note 055, using the absence of \(T\)-loops and \(T\)--\(T\) types, proves
that the *state set* of \(A\) is all of \(S\).  It does not say that an
arbitrary matching from class \(i\) belongs to (9), nor that the fibre (9)
contains more than the currently displayed matching at its orientation.

Note 057 literally transports three singleton occurrences from an
overlapping row into a disjoint row, but it does not preserve \(A\) when the
two repeated class-\(i\) occurrences are interchanged.  Its paired-cycle
cube preserves the sum of the two switched occurrences across the whole BF
row; it does not insert one arbitrary \(P_i'\) into the fixed half-load (1).

Note 086 gives only global class flexibility:

\[
  \exists P_i'\in\mathcal P_i\quad e\notin P_i'.               \tag{10}
\]

It imposes none of the three carrier-entry conditions.  Such a matching may
use an edge with \(A(f)=0\), may leave an odd closed residual cycle, or may
induce the wrong terminal-path parity.  The exact-40/no-\(A\)/no-\(TT\)
support assumptions used by Notes 055 and 057 constrain which carrier
states occur, but the stated theorems do not constrain these residuals for
an arbitrary member of \(\mathcal P_i\).  The absence of the all-terminal
\(A\)-type is not used in the carrier-saturation or row-transport arguments,
and none of the four authoritative inputs derives from it an additional
condition on the residual (3).

## Decision and minimal unproved condition

The four authoritative notes do not force an \(e\)-avoiding matching to
enter the same carrier.  They also provide no real exact-40 counterexample,
so the universal carrier-entry statement remains undecided.

The precise missing assertion is

\[
  \exists i\text{ supplied by Note 086 such that}\qquad
  \mathcal F_i(A;a)\not\subseteq\{P:e\in P\}.                 \tag{11}
\]

In words, global class flexibility must descend to flexibility inside the
fixed oriented carrier fibre.  By the criterion above, (11) is equivalent
to finding an \(e\)-avoiding \(P_i'\) that simultaneously avoids support
escape, odd residual cycles, and the wrong terminal-path parity.  This is
strictly stronger than the conclusions of Notes 055, 057 and 086 and is the
minimal carrier-entry condition needed before any companion-phase argument
can begin.
