# Positive-cell transports do not align the repeated-star targets

Let the four literal repeated-star rows be

\[
\begin{array}{c|c|c}
\text{cell}&S\text{-half}&T\text{-half}\\ \hline
(13,45)&q_{13}+A+X&r_{45}+C+D\\
(14,23)&q_{14}+A+C&r_{23}+B+X\\
(24,15)&q_{24}+B+C&r_{15}+A+D\\
(25,34)&q_{25}+B+D&r_{34}+Y+C.
\end{array}                                         \tag{1}
\]

Here (A,B,C,D,X,Y) have singleton boundaries
(1,2,4,5,3,3).  Assume exact Case-XII support.  Notes 055 and 057
produce genuine additional witnesses, but their quantifiers preserve one
carrier half-load.  This note identifies exactly which of those witnesses
can interact with the three overloaded literal targets.

## The four anchored carrier columns

For each displayed (T)-half (H_t), Note 055 says that its complement

\[
 K_t=2\mathbf1-H_t
\]

has a decomposition at every state in (S).  Thus the four literal rows
anchor four saturated columns while preserving the following actual
matching triples:

\[
\begin{array}{c|c}
t& H_t\\ \hline
45&r_{45}+C+D\\
23&r_{23}+B+X\\
15&r_{15}+A+D\\
34&r_{34}+Y+C.
\end{array}                                         \tag{2}
\]

The fifth column (t=12) exists by exact support but has no literal
repeated-star anchor.  Write one of its carrier halves as

\[
 H_{12}=r_{12}+P_1^{12}+P_2^{12};                  \tag{3}
\]

exact support does not identify (P_1^{12},P_2^{12}) with (A,B).

## The three target cells

The target (BDXY) has cell ((35,23)).  Saturating the *specific*
(t=23) carrier in (2) gives a witness

\[
 q_{35}^{23}+r_{23}+B+X+P_3^{23}+P_5^{23}
   =2\mathbf1.                                     \tag{4}
\]

It literally reuses (B,X), but the theorem supplies no equality

\[
 P_3^{23}=Y,\qquad P_5^{23}=D.                    \tag{5}
\]

Similarly, (ACXY) has cell ((13,34)), and the anchored (t=34)
carrier gives

\[
 q_{13}^{34}+r_{34}+Y+C+P_1^{34}+P_3^{34}
   =2\mathbf1,                                     \tag{6}
\]

with (Y,C) literal but without the forced identifications

\[
 P_1^{34}=A,\qquad P_3^{34}=X.                    \tag{7}
\]

The third target (ABDY) is the disjoint cell ((35,12)).  Saturating
(3) gives

\[
 q_{35}^{12}+r_{12}+P_1^{12}+P_2^{12}
       +P_3^{12}+P_5^{12}=2\mathbf1.               \tag{8}
\]

None of its four singleton entries is forced to be (A,B,Y,D).

The boundary multiset of (ABDY) has one further positive pairing, the
(S)--(S) cell ((13,25)).  Write one witness as

\[
 q_{13}^{*}+q_{25}^{*}+P_1^{*}+P_2^{*}+P_3^{*}+P_5^{*}
   =2\mathbf1.                                     \tag{9}
\]

Its third pairing is the forbidden (T)--(T) cell ((15,23)).  Thus
precisely four positive cells have the singleton boundary multisets of the
three targets: ((35,23)), ((13,34)), ((35,12)), and
((13,25)).  The last supplies a second arbitrary four-coordinate fibre for
(ABDY), but again does not identify its entries with (A,B,Y,D).  All
other positive cells can supply more perfect matchings in the same
singleton classes, but support nonemptiness does not identify any of them
with a literal member of the repeated star.

## What the Note-057 transports add

The five overlap-to-disjoint transports of Note 057 are

\[
\begin{array}{c|c}
(13,12)&(35,12)\\
(24,23)&(14,23)\\
(35,34)&(25,34)\\
(14,45)&(13,45)\\
(25,15)&(24,15).
\end{array}                                         \tag{10}
\]

Every arrow stays inside one fixed (T)-column and preserves its actual
(T)-half.  The first arrow gives two versions of (8) which reuse three
singleton matchings from one ((13,12)) witness, but those three matchings
are still the private entries of the unanchored (t=12) carrier.  The
remaining four arrows enter the four literal cells in (1), but the theorem
does not say that the transported endpoint in a cell equals its independently
given literal witness.

The two overlap targets ((35,23)) and ((13,34)) are not sources in
(10).  Their elementary state switch remains in an overlapping cell of the
same column rather than entering a disjoint (D_5) cell.  Thus (10) supplies
no additional literal coordinate in (4) or (6).

Most importantly, neither Note 055 nor Note 057 moves a matching from one
carrier load (K_t) to another.  Same-boundary matchings arising in two
columns may coincide in a real pole, but the transport conclusions do not
force that coincidence and do not compare their alternating-component
phases.

## Exact additional compatibility condition

Any one of the following literal carrier alignments would contradict the
assumed overload, because it would make the corresponding target a genuine
BF cover:

\[
\begin{array}{c|c}
(35,23)&(P_3^{23},P_5^{23})=(Y,D)\\
(13,34)&(P_1^{34},P_3^{34})=(A,X)\\
(35,12)&(P_1^{12},P_2^{12},P_3^{12},P_5^{12})=(A,B,Y,D).
\end{array}                                         \tag{11}
\]

A weaker sufficient condition is the component-aligned version: in one of
(4), (6), (8), or (9), the nonliteral singleton entries can be replaced by the
displayed literal entries, while companions in the same six-matching row
are switched so that on every component

\[
 N\cap(P\triangle P')=P\cap(P\triangle P').       \tag{12}
\]

Then the row sum remains (2\mathbf1), giving the forbidden literal target
despite its load-three edge.

Equations (11)--(12), not mere positive-cell nonemptiness, are the exact
new compatibility required from the complete perfect-matching family.
Column saturation supplies (4), (6), and (8), while (S)--(S) support
supplies (9).  Row transport supplies the within-column paired alternatives
in (10); neither theorem supplies (11) or (12).

The absence of the (A)-type says that the relevant four-column common
singleton sections do not exist.  It does not select literal entries in a
single carrier or align the phases of two carriers.  Hence it does not fill
the gap above without a further cross-carrier theorem.

This leaves the real-pole implication undecided.  The remaining positive
problem is to derive one instance of (11) or (12) from common edge incidence,
complete perfect-matching closure, and the Note-019 irreducibility
conditions.  No graph order or census is involved in this boundary.
