# No-\(A\) and no-\(TT\) do not yet force a fixed-half phase star

Fix an actual saturated \(t=23\) column in one cubic five-pole:

\[
H_{23}=r_{23}+B+X,\qquad
K_{23}=2\mathbf1-H_{23},
\tag{1}
\]

and suppose

\[
\mathcal R(K_{23})=S.
\tag{2}
\]

For the repeated-star literals \(Y\in\mathcal P_3\) and
\(D\in\mathcal P_5\), the question is whether global absence of the
all-terminal type, \(T\)-loops and \(T\)--\(T\) types forces an actual
cross-column square

\[
L+P_3=L'+Y
\quad\text{or}\quad
L+P_5=L'+D,
\qquad L\in\{r_{23},B,X\}.
\tag{3}
\]

The present axioms do not distinguish this implication. They reduce it to
one new coupling statement between two structures on the same alternating
cycles:

- no-\(A\) gives a phase-insensitive double-hit by the target anchor load;
- (3) requires one fixed matching occurrence to carry the desired phase on
  every component.

Both irreducible failures of the stronger all-companion condition occur in
actual cubic double-cover rows, and the first condition is compatible with
both. Failure for the three fixed-half companions is weaker still, since a
desired-phase edge may be covered only by the two carrier occurrences. The
no-\(TT\) condition does not connect them because it restricts a partial
flip only after that flip already belongs to a carrier decomposition.

No real exact-Case-XII pole realizing simultaneous failure is known, so
this is an exact unresolved boundary, not a real counterexample.

## Exact phase-star form of the desired square

Choose

\[
(Q,P_3,P_5)\in\mathcal D_{35}(K_{23}).
\tag{4}
\]

Write

\[
P_3\mathbin\triangle Y=C_1\mathbin{\dot\cup}\cdots
\mathbin{\dot\cup}C_k.
\]

On every \(Y\)-phase edge \(e\), exactly two of the five other row
occurrences

\[
\Omega=\{Q,r_{23},B,X,P_5\}
\]

contain \(e\). Let \(\lambda(e)\subset\Omega\) be this two-element label.
For the fixed half put

\[
\lambda_{\rm fix}(e)=\lambda(e)\cap\{r_{23},B,X\}.
\tag{5}
\]

For \(L\in\{r_{23},B,X\}\), matching incidence around each alternating
component gives

\[
L+P_3-Y\text{ is a perfect matching}
\iff
L\in\bigcap_{e\in Y\setminus P_3}\lambda_{\rm fix}(e).
\tag{6}
\]

Indeed, membership on every inserted \(Y\)-phase edge forces \(L\) to
avoid the adjacent deleted \(P_3\)-phase edges; the converse is the
componentwise \(\operatorname{Sep}\) test of Note 082. Full
perfect-matching closure adds no further condition once the vector is
\(0/1\).

Taking all state-\(35\) decompositions, the first square in (3) exists
exactly when

\[
\exists P_3\in\mathcal F_3(K_{23};5):
\quad
\bigcap_{e\in Y\setminus P_3}\lambda_{\rm fix}(e)
\ne\varnothing.
\tag{7}
\]

There is an identical criterion for \(P_5,D\). Thus the target assertion is
exactly the existence of a **fixed-half phase star** for at least one of the
two endpoint families.

## What no-\(A\) says on the same cycles

Let \(W\) be the four target singleton anchors and

\[
D_2=\{e:W(e)=2\}.
\]

For every partial flip \(P_3^I\) obtained by independently choosing the
phase on the components \(C_i\), no-\(A\) implies

\[
P_3^I\cap D_2\ne\varnothing.
\tag{8}
\]

Writing \(F=P_3\cap Y\), \(P_i=P_3\cap C_i\), and
\(Y_i=Y\cap C_i\), condition (8) is equivalent to

\[
D_2\cap F\ne\varnothing
\quad\text{or}\quad
\exists i:
D_2\cap P_i\ne\varnothing
\ \text{and}\
D_2\cap Y_i\ne\varnothing.
\tag{9}
\]

This is the exact double-hit criterion. It refers only to the union
\(D_2\), not to which one of \(r_{23},B,X\) contains an edge. In
particular, (9) is unchanged if the two companion labels on different
\(Y\)-phase edges are redistributed while preserving row load two.

By contrast, (7) asks that the *same occurrence name* lie in every label.
The logical forms are

\[
\exists\text{ a phase hit by }D_2
\qquad\text{versus}\qquad
\exists L\ \forall e,\ L\in\lambda_{\rm fix}(e).
\tag{10}
\]

There is no quantifier conversion between them.

## What no-\(TT\) adds

For a partial flip \(P_3^I\), no-\(TT\) says:

\[
\bigl(P_3^I\text{ occurs in a decomposition of }K_{23}\bigr)
\Longrightarrow
\bigl(\text{its carrier state lies in }S\bigr).
\tag{11}
\]

Equation (2) includes all actual decompositions and all their Kempe
switches, so (11) is already fully enforced. It does not assert the
antecedent for any prescribed \(P_3^I\), and it does not identify an
occurrence in the fixed half. If no phase star exists, (11) supplies no new
edge label. The same statements apply to \(P_5^I,D\).

Therefore no-\(A\) closes the avoiding exit of the partial-flip cube and
no-\(TT\) closes a forbidden carrier-entry exit, but neither opens the
row-companion exit (7).

## The exact obstruction shapes survive

Each fixed label in (5) is a subset of the three-element set
\(\{r_{23},B,X\}\), of size at most two. If the intersection in (7) is
empty, an inclusion-minimal obstruction has one of the following forms:

\[
\{\varnothing\},\qquad
\{U,V\}\ (U,V\ne\varnothing,\ U\cap V=\varnothing),\qquad
\{\{r,B\},\{r,X\},\{B,X\}\}.
\tag{12}
\]

The first form means that one desired-phase edge is covered only by the two
carrier occurrences. The second includes a singleton label disjoint from
one or two other fixed roles. The third is the unique pairwise-intersecting
failure. For the full five-companion labels, the corresponding disjoint-pair
and triangle obstructions are both realized by actual perfect matchings in
simple cubic double-cover rows. Complete partial-flip closure does not
change these cores.

The strongest one-component instance of the double-hit condition (9) is
compatible with both label obstructions: its two phase hits may be placed
without selecting a common companion name. Consequently no Helly,
pairwise-intersection, alternating-cycle-connectivity or cube-hitting
argument proves (7).

This compatibility is within one actual occurrence-labelled row and its
alternating components. It does not treat positive cells as independent
and does not replace the fixed half by separate witnesses. What is still
missing for a real counterexample is simultaneous embedding of this
component pattern into a pole whose *complete* BF support satisfies the
global negative assumptions.

## Minimum additional condition

The exact necessary and sufficient extra condition is that at least one
endpoint family has a fixed-half phase star:

\[
\begin{aligned}
&\exists P_3\in\mathcal F_3(K_{23};5),\
L\in\{r_{23},B,X\}:\
\operatorname{Sep}(L;P_3,Y),\\
\text{or }\
&\exists P_5\in\mathcal F_5(K_{23};3),\
L\in\{r_{23},B,X\}:\
\operatorname{Sep}(L;P_5,D).
\end{aligned}
\tag{13}
\]

Equivalently, one of the forced vectors

\[
L+P_3-Y,\qquad L+P_5-D
\]

must be \(0/1\). This is precisely the cross-column occurrence square (3).

A non-tautological sufficient version is: for some projected endpoint, its
fixed-half label family has none of the three irreducible cores in (12).
By the classification, its total intersection is then nonempty. To derive
this from exact Case XII, one
needs a new cross-column theorem tying the no-\(A\) double-hit set \(D_2\)
to the *identity* of its fixed-half owners—for example, forcing all
desired-phase double hits to carry one common occurrence \(L\). Edge
hitting without owner identity is insufficient.

## Decision

No general proof or real counterexample follows from the current
assumptions. The current axioms are exactly unseparated at the implication

\[
\text{double-hit plus allowed carrier state}
\quad\Longrightarrow\quad
\text{fixed-half phase star}.
\]

The left side forgets companion identity, while the right side is entirely
an identity-coherence assertion across alternating components. This is the
minimum additional cross-column condition that can change the decision.
