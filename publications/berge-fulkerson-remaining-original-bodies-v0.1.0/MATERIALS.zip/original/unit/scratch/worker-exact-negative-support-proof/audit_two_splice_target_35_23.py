#!/usr/bin/env python3
"""Audit two paired-component splices toward the literal (35,23) target.

Only the frozen order-11 repeated-star pole and the frozen order-19 pole of
Note 081 are used.  No graph is generated or modified.
"""

from __future__ import annotations

import ast
from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path
from runpy import run_path


ROOT = Path(__file__).resolve().parents[2]
ORDER11_PATH = (
    ROOT / "scratch/worker-irreducible-nonoverload/"
    "verify_order11_repeated_star_irreducible_counterexample.py"
)
ORDER19_PATH = (
    ROOT / "computations/bundles/guarded-repeated-star-selected-pm-countermodel/"
    "verify.py"
)
ORDER13_PATH = ROOT / "scratch/worker-verify/independent_n13_bf_certificate.py"
ORDER13_ALL_SS_PATH = ROOT / "scratch/worker-kempe/verify_cubic_all_ss_realization.py"
POSITIONS = tuple(range(1, 6))
STATES = tuple(combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(STATES) - S
CELL = ((3, 5), (2, 3))
SLOTS = ((1, 2, 4), (1, 4, 5), (2,), (3,), (3,), (5,))


def complement(state):
    return tuple(sorted(set(POSITIONS) - set(state)))


def enumerate_matchings(order, proper):
    adjacency = {vertex: [] for vertex in range(order)}
    for edge in proper:
        u, v = edge
        adjacency[u].append((v, edge))
        adjacency[v].append((u, edge))
    used = [False] * order
    chosen = []
    answer = set()

    def recurse():
        try:
            vertex = next(i for i, value in enumerate(used) if not value)
        except StopIteration:
            answer.add(frozenset(chosen))
            return
        used[vertex] = True
        if vertex < 5:
            chosen.append(f"s{vertex}")
            recurse()
            chosen.pop()
        for neighbour, edge in adjacency[vertex]:
            if used[neighbour]:
                continue
            used[neighbour] = True
            chosen.append(edge)
            recurse()
            chosen.pop()
            used[neighbour] = False
        used[vertex] = False

    recurse()
    return tuple(answer)


def boundary(matching):
    return tuple(
        index + 1 for index in range(5) if f"s{index}" in matching
    )


def matching_key(matching, object_index):
    return sum(1 << object_index[edge] for edge in matching)


def is_cover(row, objects, load):
    counts = Counter(edge for matching in row for edge in matching)
    return all(counts[edge] == load for edge in objects)


def proper_cycle_components(first, second, proper):
    difference = (first ^ second) & proper
    incident = defaultdict(list)
    for edge in difference:
        u, v = edge
        incident[u].append(edge)
        incident[v].append(edge)
    unseen = set(difference)
    cycles = []
    while unseen:
        seed = unseen.pop()
        component = {seed}
        queue = [seed]
        while queue:
            edge = queue.pop()
            for vertex in edge:
                for following in incident[vertex]:
                    if following in unseen:
                        unseen.remove(following)
                        component.add(following)
                        queue.append(following)
        degrees = Counter(vertex for edge in component for vertex in edge)
        if all(degree == 2 for degree in degrees.values()):
            cycles.append(frozenset(component))
    return tuple(cycles)


def load_instance(name):
    if name == "order11":
        data = run_path(ORDER11_PATH)
        order = data["N"]
        proper = tuple(data["PROPER"])
        named = {
            role: frozenset(data["objects"](role))
            for role in data["BOUNDARY"]
        }
    elif name == "order19":
        data = run_path(ORDER19_PATH)
        order = data["N"]
        proper = tuple(data["PROPER"])
        named = {
            role: frozenset(data["guarded_objects"](role))
            for role in data["BASE_BOUNDARY"]
        }
    elif name == "order13":
        data = run_path(ORDER13_PATH)
        order = data["N"]
        proper = tuple(data["PROPER"])
        integer_family = data["enumerate_perfect_matchings"]()
        edge_objects = proper + tuple(f"s{i}" for i in range(5))
        family = tuple(
            frozenset(
                edge_objects[index]
                for index in range(len(edge_objects))
                if matching & (1 << index)
            )
            for matching in integer_family
        )
        objects = frozenset(edge_objects)
        object_index = {
            edge: index for index, edge in enumerate(sorted(objects, key=str))
        }
        family = tuple(sorted(
            family, key=lambda matching: matching_key(matching, object_index)
        ))
        return order, frozenset(proper), objects, family, {}, object_index
    elif name == "order13-all-ss":
        syntax = ast.parse(ORDER13_ALL_SS_PATH.read_text())
        assignment = next(
            node for node in syntax.body
            if isinstance(node, ast.Assign)
            and any(
                isinstance(target, ast.Name) and target.id == "PROPER_EDGES"
                for target in node.targets
            )
        )
        order = 13
        proper = tuple(ast.literal_eval(assignment.value))
        named = {}
    else:
        raise ValueError(name)
    family = enumerate_matchings(order, proper)
    objects = frozenset(proper) | frozenset(f"s{i}" for i in range(5))
    object_index = {edge: index for index, edge in enumerate(sorted(objects, key=str))}
    family = tuple(sorted(family, key=lambda matching: matching_key(matching, object_index)))
    assert set(named.values()) <= set(family)
    return order, frozenset(proper), objects, family, named, object_index


def cell_completion_pairs(classes, objects, left, right, singleton_by_position):
    singles = tuple(singleton_by_position[position] for position in left + right)
    return tuple(
        (first, second)
        for first, second in product(classes[complement(left)], classes[complement(right)])
        if is_cover((first, second, *singles), objects, 2)
    )


def classify_boundary(family, objects):
    classes = defaultdict(list)
    for matching in family:
        classes[boundary(matching)].append(matching)

    tait = set()
    for state in STATES:
        rows = product(
            classes[complement(state)],
            *(classes[(position,)] for position in state),
        )
        if any(is_cover(row, objects, 1) for row in rows):
            tait.add(state)

    support = set()
    for left, right in combinations_with_replacement(STATES, 2):
        rows = product(
            classes[complement(left)],
            classes[complement(right)],
            *(classes[(position,)] for position in left + right),
        )
        if any(is_cover(row, objects, 2) for row in rows):
            support.add((left, right))
    a_type = any(
        is_cover(row, objects, 2)
        for row in product(classes[POSITIONS], *(classes[(i,)] for i in POSITIONS))
    )
    ss = {pair for pair in support if pair[0] in S and pair[1] in S}
    tt = {pair for pair in support if pair[0] in T and pair[1] in T}
    st = support - ss - tt
    required_ss = set(combinations_with_replacement(sorted(S), 2))
    required_st = {
        tuple(sorted((left, right))) for left in S for right in T
    }
    return classes, {
        "tait_states": tuple(sorted(tait)),
        "SS": len(ss),
        "ST": len(st),
        "TT": len(tt),
        "A": a_type,
        "missing_SS": len(required_ss - ss),
        "missing_ST": len(required_st - st),
        "forbidden_TT_present": len(tt),
        "missing_SS_types": tuple(sorted(required_ss - ss)),
        "missing_ST_types": tuple(sorted(required_st - st)),
        "forbidden_TT_types": tuple(sorted(tt)),
    }


def enumerate_cell_rows(classes, objects):
    return tuple(
        row for row in product(*(classes[slot] for slot in SLOTS))
        if is_cover(row, objects, 2)
    )


def build_splice_graph(rows, family, proper):
    row_set = set(rows)
    family_set = set(family)
    adjacency = {row: set() for row in rows}
    edge_labels = {}
    for row in rows:
        for left in range(6):
            for right in range(left + 1, 6):
                for cycle in proper_cycle_components(row[left], row[right], proper):
                    changed = list(row)
                    changed[left] = row[left] ^ cycle
                    changed[right] = row[right] ^ cycle
                    assert changed[left] in family_set and changed[right] in family_set
                    target = tuple(changed)
                    assert target in row_set
                    if target == row:
                        continue
                    adjacency[row].add(target)
                    adjacency[target].add(row)
                    key = tuple(sorted((row, target), key=repr))
                    edge_labels.setdefault(key, (left, right, cycle))
    return adjacency, edge_labels


def build_union_splice_graph(rows, family, proper):
    """Allow one splice to toggle any nonempty union of cycle components."""
    row_set = set(rows)
    family_set = set(family)
    adjacency = {row: set() for row in rows}
    edge_labels = {}
    for row in rows:
        for left in range(6):
            for right in range(left + 1, 6):
                cycles = proper_cycle_components(row[left], row[right], proper)
                for subset_mask in range(1, 1 << len(cycles)):
                    selected = tuple(
                        cycles[index]
                        for index in range(len(cycles))
                        if subset_mask & (1 << index)
                    )
                    switched = frozenset().union(*selected)
                    changed = list(row)
                    changed[left] = row[left] ^ switched
                    changed[right] = row[right] ^ switched
                    assert changed[left] in family_set and changed[right] in family_set
                    target = tuple(changed)
                    assert target in row_set
                    if target == row:
                        continue
                    adjacency[row].add(target)
                    adjacency[target].add(row)
                    key = tuple(sorted((row, target), key=repr))
                    edge_labels.setdefault(
                        key, (left, right, switched, len(selected))
                    )
    return adjacency, edge_labels


def components(adjacency):
    unseen = set(adjacency)
    sizes = []
    while unseen:
        seed = unseen.pop()
        reached = {seed}
        queue = [seed]
        while queue:
            row = queue.pop()
            for neighbour in adjacency[row]:
                if neighbour not in reached:
                    reached.add(neighbour)
                    unseen.discard(neighbour)
                    queue.append(neighbour)
        sizes.append(len(reached))
    return tuple(sorted(sizes, reverse=True))


def all_pair_distances(adjacency):
    distribution = Counter()
    diameter = 0
    ordered_rows = tuple(sorted(adjacency, key=repr))
    row_index = {row: index for index, row in enumerate(ordered_rows)}
    for source_index, source in enumerate(ordered_rows):
        distance = {source: 0}
        queue = deque((source,))
        while queue:
            row = queue.popleft()
            for neighbour in adjacency[row]:
                if neighbour not in distance:
                    distance[neighbour] = distance[row] + 1
                    queue.append(neighbour)
        for target, value in distance.items():
            if row_index[target] > source_index:
                distribution[value] += 1
                diameter = max(diameter, value)
    return diameter, dict(sorted(distribution.items()))


def shortest_path(adjacency, starts, targets):
    target_set = set(targets)
    queue = deque(starts)
    parent = {start: None for start in starts}
    if target_set & set(starts):
        finish = next(iter(target_set & set(starts)))
    else:
        finish = None
    while queue and finish is None:
        row = queue.popleft()
        for neighbour in adjacency[row]:
            if neighbour in parent:
                continue
            parent[neighbour] = row
            if neighbour in target_set:
                finish = neighbour
                break
            queue.append(neighbour)
    if finish is None:
        return None
    path = []
    while finish is not None:
        path.append(finish)
        finish = parent[finish]
    return tuple(reversed(path))


def audit(name):
    order, proper, objects, family, named, object_index = load_instance(name)
    classes, boundary_profile = classify_boundary(family, objects)
    rows = enumerate_cell_rows(classes, objects)
    adjacency, edge_labels = build_splice_graph(rows, family, proper)
    anchored = tuple(
        row for row in rows
        if row[1] == named["r23"]
        and row[2] == named["B"]
        and row[3] == named["X"]
    )
    exact_targets = tuple(
        row for row in rows
        if row[2] == named["B"]
        and row[3] == named["X"]
        and row[4] == named["Y"]
        and row[5] == named["D"]
    )
    pair_targets = tuple(
        row for row in rows
        if row[4] == named["Y"] and row[5] == named["D"]
    )
    exact_path = shortest_path(adjacency, anchored, exact_targets)
    pair_path = shortest_path(adjacency, anchored, pair_targets)
    matching_id = {matching: f"M{index:02d}" for index, matching in enumerate(family)}

    def compact_row(row):
        return tuple(matching_id[matching] for matching in row)

    def compact_path(path):
        if path is None:
            return None
        output = []
        for index, row in enumerate(path):
            item = {"row": compact_row(row)}
            if index:
                key = tuple(sorted((path[index - 1], row), key=repr))
                left, right, cycle = edge_labels[key]
                item["splice_slots"] = (left, right)
                item["cycle_length"] = len(cycle)
            output.append(item)
        return tuple(output)

    anchor_distances = []
    for anchor in anchored:
        path = shortest_path(adjacency, (anchor,), exact_targets)
        anchor_distances.append(None if path is None else len(path) - 1)

    assert named["B"] != named["D"] and named["X"] != named["Y"]
    literal_target_load = Counter(
        edge for role in ("B", "X", "Y", "D") for edge in named[role]
    )
    overloaded = tuple(sorted(
        (
            (edge, load)
            for edge, load in literal_target_load.items()
            if load > 2
        ),
        key=lambda item: str(item[0]),
    ))
    assert overloaded
    assert not exact_targets

    return {
        "instance": name,
        "order": order,
        "perfect_matchings": len(family),
        "boundary_profile": boundary_profile,
        "cell": CELL,
        "ordered_cell_rows": len(rows),
        "splice_graph_edges": sum(map(len, adjacency.values())) // 2,
        "splice_component_sizes": components(adjacency),
        "anchored_rows": len(anchored),
        "anchored_row_ids": tuple(compact_row(row) for row in anchored),
        "literal_target_overloads": overloaded,
        "exact_target_fibre": len(exact_targets),
        "pair_only_target_fibre": len(pair_targets),
        "anchor_to_exact_target_distances": tuple(anchor_distances),
        "minimum_exact_target_distance": None if exact_path is None else len(exact_path) - 1,
        "minimum_pair_only_distance": None if pair_path is None else len(pair_path) - 1,
        "within_two_exact": exact_path is not None and len(exact_path) <= 3,
        "within_two_pair_only": pair_path is not None and len(pair_path) <= 3,
        "shortest_exact_path": compact_path(exact_path),
        "shortest_pair_only_path": compact_path(pair_path),
    }


def audit_repeated_stars(instance_name):
    order, proper, objects, family, _, object_index = load_instance(instance_name)
    classes, boundary_profile = classify_boundary(family, objects)
    rows = enumerate_cell_rows(classes, objects)
    adjacency, edge_labels = build_splice_graph(rows, family, proper)
    union_adjacency, union_edge_labels = build_union_splice_graph(
        rows, family, proper
    )
    matching_id = {matching: f"M{index:02d}" for index, matching in enumerate(family)}

    cell_edge_data = []
    seen_cell_edges = set()
    for source, neighbours in adjacency.items():
        for target in neighbours:
            key = tuple(sorted((source, target), key=repr))
            if key in seen_cell_edges:
                continue
            seen_cell_edges.add(key)
            left, right, cycle = edge_labels[key]
            cell_edge_data.append({
                "source": tuple(matching_id[item] for item in source),
                "target": tuple(matching_id[item] for item in target),
                "splice_slots": (left, right),
                "cycle": tuple(sorted(cycle)),
            })
    graph_diameter, all_pair_distance_distribution = all_pair_distances(adjacency)
    splice_type_distribution = Counter(
        (entry["splice_slots"], len(entry["cycle"])) for entry in cell_edge_data
    )

    actual_pair_tests = 0
    actual_pair_within_two = 0
    actual_pair_beyond_two = 0
    actual_pair_unreachable = 0
    actual_pair_distances = Counter()
    first_actual_pair_failure = None
    actual_pair_failures = []
    for source in rows:
        desired_pairs = {
            (target[4], target[5])
            for target in rows
            if target[2] == source[2]
            and target[3] == source[3]
            and target[4] != source[3]
            and (target[4], target[5]) != (source[4], source[5])
        }
        for desired in desired_pairs:
            actual_pair_tests += 1
            target_fibre = tuple(
                target for target in rows
                if target[2] == source[2]
                and target[3] == source[3]
                and (target[4], target[5]) == desired
            )
            path = shortest_path(adjacency, (source,), target_fibre)
            distance = None if path is None else len(path) - 1
            if distance is None:
                actual_pair_unreachable += 1
            elif distance <= 2:
                actual_pair_within_two += 1
                actual_pair_distances[distance] += 1
            else:
                actual_pair_beyond_two += 1
                actual_pair_distances[distance] += 1
            if (distance is None or distance > 2) and first_actual_pair_failure is None:
                first_actual_pair_failure = {
                    "source": tuple(matching_id[item] for item in source),
                    "desired_Y_D": tuple(matching_id[item] for item in desired),
                    "target_fibre_size": len(target_fibre),
                    "distance": distance,
                    "path": None if path is None else tuple(
                        tuple(matching_id[item] for item in row) for row in path
                    ),
                }
            if distance is None or distance > 2:
                failure = {
                    "source": tuple(matching_id[item] for item in source),
                    "desired_Y_D": tuple(matching_id[item] for item in desired),
                    "target_fibre_size": len(target_fibre),
                    "distance": distance,
                    "path": None if path is None else tuple(
                        tuple(matching_id[item] for item in row) for row in path
                    ),
                    "path_splices": None if path is None else tuple(
                        {
                            "slots": edge_labels[tuple(sorted(
                                (path[index - 1], path[index]), key=repr
                            ))][0:2],
                            "cycle": tuple(sorted(edge_labels[tuple(sorted(
                                (path[index - 1], path[index]), key=repr
                            ))][2])),
                        }
                        for index in range(1, len(path))
                    ),
                }
                actual_pair_failures.append(failure)

    union_pair_tests = 0
    union_pair_within_two = 0
    union_pair_beyond_two = 0
    union_pair_unreachable = 0
    union_pair_distances = Counter()
    union_pair_failures = []
    for source in rows:
        desired_pairs = {
            (target[4], target[5])
            for target in rows
            if target[2] == source[2]
            and target[3] == source[3]
            and target[4] != source[3]
            and (target[4], target[5]) != (source[4], source[5])
        }
        for desired in desired_pairs:
            union_pair_tests += 1
            target_fibre = tuple(
                target for target in rows
                if target[2] == source[2]
                and target[3] == source[3]
                and (target[4], target[5]) == desired
            )
            path = shortest_path(union_adjacency, (source,), target_fibre)
            distance = None if path is None else len(path) - 1
            if distance is None:
                union_pair_unreachable += 1
            elif distance <= 2:
                union_pair_within_two += 1
                union_pair_distances[distance] += 1
            else:
                union_pair_beyond_two += 1
                union_pair_distances[distance] += 1
            if distance is None or distance > 2:
                union_pair_failures.append({
                    "source": tuple(matching_id[item] for item in source),
                    "desired_Y_D": tuple(matching_id[item] for item in desired),
                    "distance": distance,
                })

    stars = 0
    carrier_choices = 0
    anchored_tests = 0
    anchorless_carriers = 0
    target_fibre_empty = 0
    within_two = 0
    reachable_beyond_two = 0
    unreachable = 0
    distance_counts = Counter()
    first_failure = None
    first_success = None

    for A, B, C, D, X, Y in product(
        classes[(1,)], classes[(2,)], classes[(4,)], classes[(5,)],
        classes[(3,)], classes[(3,)],
    ):
        if X == Y:
            continue
        singleton = {1: A, 2: B, 3: X, 4: C, 5: D}
        row13_45 = cell_completion_pairs(
            classes, objects, (1, 3), (4, 5), singleton
        )
        row14_23 = cell_completion_pairs(
            classes, objects, (1, 4), (2, 3), singleton
        )
        row24_15 = cell_completion_pairs(
            classes, objects, (2, 4), (1, 5), singleton
        )
        singleton_last = dict(singleton)
        singleton_last[3] = Y
        row25_34 = cell_completion_pairs(
            classes, objects, (2, 5), (3, 4), singleton_last
        )
        if not (row13_45 and row14_23 and row24_15 and row25_34):
            continue
        stars += 1

        exact_targets = tuple(
            row for row in rows
            if row[2] == B and row[3] == X and row[4] == Y and row[5] == D
        )
        for _, r23 in row14_23:
            carrier_choices += 1
            anchored = tuple(
                row for row in rows
                if row[1] == r23 and row[2] == B and row[3] == X
            )
            if not anchored:
                anchorless_carriers += 1
                continue
            for anchor in anchored:
                anchored_tests += 1
                path = shortest_path(adjacency, (anchor,), exact_targets)
                distance = None if path is None else len(path) - 1
                if not exact_targets:
                    target_fibre_empty += 1
                if distance is None:
                    unreachable += 1
                    outcome = "unreachable"
                elif distance <= 2:
                    within_two += 1
                    distance_counts[distance] += 1
                    outcome = "within_two"
                else:
                    reachable_beyond_two += 1
                    distance_counts[distance] += 1
                    outcome = "beyond_two"

                record = {
                    "roles": {
                        role: matching_id[matching]
                        for role, matching in zip("ABCDXY", (A, B, C, D, X, Y))
                    },
                    "r23": matching_id[r23],
                    "anchor": tuple(matching_id[item] for item in anchor),
                    "target_fibre_size": len(exact_targets),
                    "distance": distance,
                    "outcome": outcome,
                }
                if path is not None:
                    record["path"] = tuple(
                        tuple(matching_id[item] for item in row) for row in path
                    )
                    record["path_splices"] = tuple(
                        (
                            edge_labels[tuple(sorted((path[index - 1], path[index]), key=repr))][0:2],
                            len(edge_labels[tuple(sorted((path[index - 1], path[index]), key=repr))][2]),
                        )
                        for index in range(1, len(path))
                    )
                if outcome == "within_two" and first_success is None:
                    first_success = record
                if outcome != "within_two" and first_failure is None:
                    first_failure = record

    assert anchored_tests == within_two + reachable_beyond_two + unreachable
    return {
        "instance": instance_name,
        "order": order,
        "perfect_matchings": len(family),
        "boundary_profile": boundary_profile,
        "cell": CELL,
        "ordered_cell_rows": len(rows),
        "splice_graph_edges": sum(map(len, adjacency.values())) // 2,
        "splice_component_sizes": components(adjacency),
        "splice_graph_diameter": graph_diameter,
        "all_pair_distance_distribution": all_pair_distance_distribution,
        "splice_type_distribution": tuple(sorted(splice_type_distribution.items())),
        "actual_anchored_pair_tests": actual_pair_tests,
        "actual_anchored_pair_within_two": actual_pair_within_two,
        "actual_anchored_pair_beyond_two": actual_pair_beyond_two,
        "actual_anchored_pair_unreachable": actual_pair_unreachable,
        "actual_anchored_pair_distance_distribution": dict(sorted(actual_pair_distances.items())),
        "first_actual_anchored_pair_failure": first_actual_pair_failure,
        "actual_anchored_pair_failures": tuple(actual_pair_failures),
        "union_splice_graph_edges": sum(map(len, union_adjacency.values())) // 2,
        "union_splice_component_sizes": components(union_adjacency),
        "union_anchored_pair_tests": union_pair_tests,
        "union_anchored_pair_within_two": union_pair_within_two,
        "union_anchored_pair_beyond_two": union_pair_beyond_two,
        "union_anchored_pair_unreachable": union_pair_unreachable,
        "union_anchored_pair_distance_distribution": dict(sorted(union_pair_distances.items())),
        "union_anchored_pair_failures": tuple(union_pair_failures),
        "cell_rows": tuple(
            tuple(matching_id[item] for item in row) for row in rows
        ),
        "cell_splice_edges": tuple(cell_edge_data),
        "cell_matching_edges": {
            matching_id[matching]: tuple(sorted(matching, key=str))
            for matching in {item for row in rows for item in row}
        },
        "distinct_repeated_stars": stars,
        "anchored_carrier_choices": carrier_choices,
        "anchorless_carrier_choices": anchorless_carriers,
        "anchored_row_tests": anchored_tests,
        "target_fibre_empty_tests": target_fibre_empty,
        "within_two": within_two,
        "reachable_beyond_two": reachable_beyond_two,
        "unreachable": unreachable,
        "distance_distribution": dict(sorted(distance_counts.items())),
        "first_within_two": first_success,
        "first_failure": first_failure,
    }


def main():
    reports = (
        audit("order11"),
        audit_repeated_stars("order13"),
        audit_repeated_stars("order13-all-ss"),
        audit("order19"),
    )
    print({"reports": reports})
    print("TWO_SPLICE_TARGET_35_23_AUDITED")


if __name__ == "__main__":
    main()
