# Repeated-star mixed-quartet nonoverload is a fibre-avoidance condition

Consider two actual pivot rows in one simple cubic five-pole,

\[
\begin{aligned}
R_3&=(q_{24},r_{15},A,B,C,D),\\
R_1&=(q_{13},r_{45},A,X,C,D),                    \tag{1}
\end{aligned}
\]

sharing the literal singleton identities \(A,C,D\).  Their singleton
boundaries are

\[
\partial(A,B,C,D,X)=(1,2,4,5,3).
\]

Put

\[
W=A+B+C+D,qquad D_2=\{e:W(e)=2\},               \tag{2}
\]

and let

\[
T=A+B+C+X                                          \tag{3}
\]

be the mixed quartet whose nonnegativity is needed before an
\((14,23)\) residual can be considered.  The two rows in (1) imply

\[
W\le2\mathbf1,qquad A+X+C+D\le2\mathbf1.        \tag{4}
\]

The exact local conclusion is

\[
\boxed{
T\le2\mathbf1
\iff
X\cap B\cap(A\mathbin\triangle C)=\varnothing.
}                                                  \tag{5}
\]

Under absence of the all-terminal BF type this is equivalently

\[
\boxed{
\varnothing\ne X\cap D_2\subseteq B\cap D.
}                                                  \tag{6}
\]

Thus the proposed existential nonoverload statement is exactly a
fibre-avoidance statement.  Notes 079--094 do not presently force it in a
real exact-Case-XII pole.  No such pole violating it is known, so the
actual-pole implication remains undecided at the condition below rather
than being refuted.

## Classification of every possible overload edge

Fix an edge object \(e\), and abbreviate the five zero-one incidences by
\(a,b,c,d,x\).  If \(T(e)\ge3\), then (4) gives

\[
a+b+c+d\le2,qquad a+x+c+d\le2.                  \tag{7}
\]

If \(d=1\), the two inequalities leave too few of \(a,b,c,x\) to make
\(a+b+c+x\ge3\).  Hence \(d=0\).  Put \(s=a+c\).  Conditions (7) become

\[
s+b\le2,qquad s+x\le2,qquad s+b+x\ge3.         \tag{8}
\]

The only solution is

\[
s=1,qquad b=x=1.                                 \tag{9}
\]

Consequently every overload has load exactly three and has one of the two
signatures

\[
ABX,qquad BCX.                                   \tag{10}
\]

Conversely either signature overloads (3), proving (5).

There is a useful equivalent description through \(D_2\).  If
\(e\in X\cap D_2\), then the second inequality in (4) gives
\(a+c+d\le1\), while \(a+b+c+d=2\).  Therefore \(b=1\) and exactly one of
\(a,c,d\) is one.  The only possibilities are

\[
ABX,qquad BCX,qquad BDX.                        \tag{11}
\]

The first two are exactly the overload signatures (10); \(BDX\) is safe
for (3).  This proves

\[
T\le2\mathbf1
\iff
X\cap D_2\subseteq B\cap D.                     \tag{12}
\]

## What absence of the all-terminal type adds

Let \(P\) be any actual singleton-class-3 perfect matching.  If
\(P\cap D_2=\varnothing\), then

\[
W+P\le2\mathbf1.                                 \tag{13}
\]

At every internal cubic vertex the five matching occurrences in \(W+P\)
have total incident load five.  Under (13) the three incident edge loads
must be \((2,2,1)\).  Moreover the five singleton semiedges occur once
each.  Hence

\[
Z=2\mathbf1-W-P                                   \tag{14}
\]

is an actual all-terminal perfect matching, and \(A,B,C,D,P,Z\) is an
all-terminal BF cover.  Therefore exact negative support implies

\[
P\cap D_2\ne\varnothing
\quad\text{for every }P\in\mathcal P_3.           \tag{15}
\]

Applying (15) to \(X\) turns (12) into (6).  This is the full direct
consequence of no \(A\) at the nonoverload gate.  It forces a double-load
hit but does not decide whether that hit is bad \((ABX,BCX)\) or safe
\((BDX)\).

Absence of the \(T\)-loop \([23]\) only requires \(B\cap X\ne\varnothing\).
Both the bad signatures in (10) and the safe signature \(BDX\) satisfy
that requirement.  The no-loop condition therefore does not distinguish
the alternatives in (11).  If a bad signature occurs, the prospective
mixed residual is already negative at that edge; absence of a
\(T\)--\(T\) factorization has no residual on which to act.  Thus no
\(T\)--\(T\) supplies no direct local exclusion of (10).

## The exact fibre condition

For fixed actual identities \(A,C,D\), define the two literal row fibres

\[
\begin{aligned}
\mathcal B_{ACD}
 &=\{B\in\mathcal P_2:
       (q_{24},r_{15},A,B,C,D)\text{ is a BF row for some }q_{24},r_{15}\},\\
\mathcal X_{ACD}
 &=\{X\in\mathcal P_3:
       (q_{13},r_{45},A,X,C,D)\text{ is a BF row for some }q_{13},r_{45}\}.
                                                               \tag{16}
\end{aligned}
\]

All \(J_{31}\) choices over this common triple are precisely the pairs
\((B,X)\in\mathcal B_{ACD}\times\mathcal X_{ACD}\).  By (5), a
nonoverloaded choice exists if and only if

\[
\boxed{
\exists A,C,D\ \exists B\in\mathcal B_{ACD}\
\exists X\in\mathcal X_{ACD}:\quad
X\cap B\cap(A\mathbin\triangle C)=\varnothing.
}                                                  \tag{17}
\]

Under no \(A\), the same condition can be written

\[
\exists A,C,D,B,X:\quad
\varnothing\ne X\cap D_2(A,B,C,D)\subseteq B\cap D.           \tag{18}
\]

This is the minimum missing condition for the present leaf.  It involves
only the first nonoverload gate and makes no assertion about a subsequent
residual colouring or splice.

## Why full closure and class flexibility do not yet give (17)

At a bad edge of type \(ABX\) or \(BCX\), both singleton classes 2 and 3
use the edge.  The class-fixed-edge exclusivity of Note 086 implies that
at least one of those two complete singleton classes contains a matching
avoiding that particular edge.  This is only the quantifier

\[
\forall e\in E_{\mathrm{bad}}\quad
\exists P_e\text{ in a relevant global singleton class}:e\notin P_e.
                                                               \tag{19}
\]

Condition (17) instead requires one pair of matchings in the two fixed
literal fibres to avoid all bad incidences simultaneously.  Even the
stronger collection of edgewise statements

\[
\forall e\in E_{\mathrm{bad}}\quad
\exists X_e\in\mathcal X_{ACD}:e\notin X_e       \tag{20}
\]

does not exchange quantifiers to give one
\(X\in\mathcal X_{ACD}\) with
\(X\cap E_{\mathrm{bad}}=\varnothing\).

Complete perfect-matching closure contains every global avoider and every
same-boundary matching obtained by a proper alternating-cycle exchange.
It does not say that the avoider remains in \(\mathcal B_{ACD}\) or
\(\mathcal X_{ACD}\), because membership in those sets also requires the
same literal \(A,C,D\) row identities.  Notes 087--090 isolate exactly this
separation between global class flexibility and fixed-carrier or fixed-row
fibre flexibility.  Their real-pole examples are not exact Case XII, while
their exact-support incidence models are not common cubic full closures;
therefore they establish the information boundary but not a real
counterexample to (17).

The fixed Note-024 diagnosis is consistent with the same boundary: it has
eight \(J_{31}\) choices and no all-terminal cover, but none extends to an
\(R_2\) row.  Its recorded diagnosis does not separate nonoverload from the
later residual factorization, and the pole has forbidden \(T\)-support, so
it cannot decide (17) under exact Case XII.

## Decision

The proposed general nonoverload lemma is not proved by the present
hypotheses, and no actual exact-Case-XII counterexample is known.  What is
proved is the sharp reduction (5)--(6): every failure is a bad cross-fibre
intersection of type \(ABX\) or \(BCX\), whereas no \(A\) merely forces
one of the three hits in (11).  A positive theorem must force the safe
fibre section (17), equivalently (18).  Additional information that only
produces edgewise global avoiders, without keeping the literal
\(A,C,D\) row fibre, cannot settle this nonoverload gate.
