# One actual pivot quadratic factorization does not force an anchored two-splice fibre

The frozen Note-085 common-binary exact-forty system has 125 matching tokens
on 48 binary coordinates.  Keep all its designated rows and literal token
identities, and add one class-1 singleton token \(A'\) with incidence vector

\[
 100000000010111111111110111110111111111111111111.
\]

This vector is forced by the first pivot cubic relation:

\[
 A'=r_{45}+D-q_{14}=B+r_{23}-q_{13}.              \tag{1}
\]

It is coordinatewise binary.  Hence the first cubic relation has the two
actual pair-sum moves

\[
 (r_{45},D,q_{13})
 \longleftrightarrow(A',q_{14},q_{13})
 \longleftrightarrow(B,q_{14},r_{23}).            \tag{2}
\]

No token in the original pool has the vector in (1), so one new token is
necessary and sufficient to realize this factorization in the frozen
coordinate system.  The analogous forced intermediate vectors for the
second and third cubic relations are not binary.

The addition does not change any of the four literal pivot rows, the 25
designated \(S\)--\(T\) rows, the 15 designated \(S\)--\(S\) rows, the
transport rows, or the six literal target endpoint identities.  Exhaustive
integer decomposition on the fixed 48 coordinates still finds no
\(T\)-loop or \(T\)--\(T\) BF row.  There remains no all-terminal token, so
an \(A=(12345)\) cover is impossible.  Thus the common-binary boundary
support remains exactly the forty Case-XII pair types with the same exact
negative support.

For the two genuinely literal-anchored targets \(BDXY\) and \(ACXY\), the
six endpoint replacements have twenty current-companion forced vectors,
and the two targets have four forced-intermediate vectors.  The original
Note-085 pool realizes none of these twenty-four vectors.  The new vector
\(A'\) is unequal to every one of them.  Consequently the one-token
extension still has

\[
 \text{sequential anchored fibres}=\varnothing,
 \qquad
 \text{forced-intermediate anchored fibres}=\varnothing.       \tag{3}
\]

Equations (1)--(3) give a strict occurrence-level countermodel to

\[
 \text{one actual pivot quadratic factorization}
 \Longrightarrow
 \text{some anchored Note-082 dependent fibre is nonempty}.    \tag{4}
\]

The countermodel is not a real cubic five-pole.  Its 48 coordinates have no
common trivalent vertex partition and its 126-token pool is not the full
perfect-matching closure induced by such a partition.  Therefore it does
not refute (4) under the real exact-Case-XII hypothesis.  It isolates the
missing condition: a positive theorem must couple quadratic components of
different toric fibres using the common cubic vertex partition and its
graph-induced complete matching family.  Literal identity reuse and one
quadratically connected pivot relation alone do not provide that
cross-fibre coupling.

The deterministic read-only checker is
`audit_note085_pivot_quadratic_factorizations.py`; it does not synthesize or
modify coordinates.
