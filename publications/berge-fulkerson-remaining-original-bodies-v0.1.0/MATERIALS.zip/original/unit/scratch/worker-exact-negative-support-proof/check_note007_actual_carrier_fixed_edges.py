#!/usr/bin/env python3
"""Check carrier-fixed proper edges in the fixed Note-007 13-vertex pole.

The graph, all perfect matchings, and all BF covers are supplied by the
independent frozen Note-007 verifier.  This script searches no other graph.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path


S_STATES = {
    (0, 2),  # 13
    (0, 3),  # 14
    (1, 3),  # 24
    (1, 4),  # 25
    (2, 4),  # 35
}
T_STATES = {
    (0, 1),  # 12
    (0, 4),  # 15
    (1, 2),  # 23
    (2, 3),  # 34
    (3, 4),  # 45
}


def load_module(path):
    spec = importlib.util.spec_from_file_location("note007_verifier", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_vector(matching, edge_count):
    return tuple((matching >> edge) & 1 for edge in range(edge_count))


def vector_sum(vectors, indices):
    return tuple(sum(vectors[index][edge] for index in indices)
                 for edge in range(len(vectors[0])))


def contained_as_multiset(part, whole):
    part_count = Counter(part)
    whole_count = Counter(whole)
    return all(part_count[index] <= whole_count[index] for index in part_count)


def matching_record(module, matchings, index):
    matching = matchings[index]
    proper = [edge for edge in range(module.N_PROPER) if matching >> edge & 1]
    boundary = [position + 1 for position in range(5)
                if matching >> (module.N_PROPER + position) & 1]
    return {
        "index": index,
        "proper_edge_ids": proper,
        "proper_edges": [list(module.PROPER[edge]) for edge in proper],
        "boundary": boundary,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("note007_script", type=Path)
    parser.add_argument("--require-s-to-t", action="store_true")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    module = load_module(args.note007_script)
    module.graph_checks()
    matchings = module.enumerate_perfect_matchings()
    covers = module.enumerate_bf_covers(matchings)
    assert len(matchings) == 31
    assert len(covers) == 177
    vectors = tuple(load_vector(matching, module.N_EDGES) for matching in matchings)
    boundaries = tuple(module.boundary_mask(matching) for matching in matchings)

    singleton_classes = {
        position: tuple(index for index, boundary in enumerate(boundaries)
                        if boundary == 1 << position)
        for position in range(5)
    }
    fixed_sets = {
        position: tuple(
            edge for edge in range(module.N_PROPER)
            if all(vectors[index][edge] for index in indices)
        )
        for position, indices in singleton_classes.items()
    }

    # Exhaust all PM decompositions of every state/half-load, independently
    # of which decomposition first appears inside a BF cover.
    decomposition_groups = defaultdict(list)
    for first, second in combinations(range(5), 2):
        triple_boundary = 0b11111 ^ (1 << first) ^ (1 << second)
        triples = [index for index, boundary in enumerate(boundaries)
                   if boundary == triple_boundary]
        for q in triples:
            for p_first in singleton_classes[first]:
                for p_second in singleton_classes[second]:
                    decomposition = (q, p_first, p_second)
                    load = vector_sum(vectors, decomposition)
                    decomposition_groups[(first, second, load)].append(decomposition)

    # Extract every actual (3+1+1) half occurring in each complete BF row.
    actual_halves = []
    for cover_index, cover in enumerate(covers):
        seen = set()
        for occurrences in combinations(range(6), 3):
            chosen = tuple(cover[position] for position in occurrences)
            kinds = sorted(boundaries[index].bit_count() for index in chosen)
            if kinds != [1, 1, 3]:
                continue
            q = next(index for index in chosen if boundaries[index].bit_count() == 3)
            singles = [index for index in chosen if boundaries[index].bit_count() == 1]
            first = boundaries[singles[0]].bit_length() - 1
            second = boundaries[singles[1]].bit_length() - 1
            if first == second:
                continue
            if first > second:
                first, second = second, first
                singles.reverse()
            if boundaries[q] != (0b11111 ^ (1 << first) ^ (1 << second)):
                continue
            decomposition = (q, singles[0], singles[1])
            load = vector_sum(vectors, decomposition)
            key = (first, second, load)
            assert decomposition in decomposition_groups[key]
            complement = tuple((Counter(cover) - Counter(decomposition)).elements())
            assert len(complement) == 3
            complement_kinds = sorted(boundaries[index].bit_count()
                                      for index in complement)
            assert complement_kinds == [1, 1, 3]
            complement_singles = [
                boundaries[index].bit_length() - 1
                for index in complement
                if boundaries[index].bit_count() == 1
            ]
            assert len(complement_singles) == 2
            complement_state = tuple(sorted(complement_singles))
            record_key = (cover_index, decomposition, key)
            if record_key in seen:
                continue
            seen.add(record_key)
            actual_halves.append({
                "cover_index": cover_index,
                "cover": tuple(cover),
                "decomposition": decomposition,
                "first": first,
                "second": second,
                "load": load,
                "complement_state": complement_state,
            })

    candidate_by_key = {}
    for half in actual_halves:
        cover = half["cover"]
        first, second, load = half["first"], half["second"], half["load"]
        if args.require_s_to_t:
            if (first, second) not in S_STATES:
                continue
            if half["complement_state"] not in T_STATES:
                continue
        group = decomposition_groups[(first, second, load)]
        for source_class, role in ((first, 1), (second, 2)):
            source = half["decomposition"][role]
            other_class = second if source_class == first else first
            fibre = sorted({decomposition[role] for decomposition in group})
            for edge in range(module.N_PROPER):
                if not vectors[source][edge]:
                    continue
                row_singleton_users = [
                    index for index in cover
                    if boundaries[index].bit_count() == 1 and vectors[index][edge]
                ]
                row_user_classes = {
                    boundaries[index].bit_length() - 1
                    for index in row_singleton_users
                }
                if len(row_user_classes) < 2:
                    continue
                global_avoiders = [index for index in singleton_classes[source_class]
                                   if not vectors[index][edge]]
                if not global_avoiders:
                    continue
                carrier_fixed = all(vectors[index][edge] for index in fibre)
                key = (half["cover_index"], first, second,
                       half["complement_state"], load, source_class, edge)
                current = candidate_by_key.get(key)
                if current is None or half["decomposition"] < current["witness_decomposition"]:
                    candidate_by_key[key] = {
                        "cover_index": half["cover_index"],
                        "cover": cover,
                        "state": (first, second),
                        "complement_state": half["complement_state"],
                        "oriented_source_class": source_class,
                        "other_half_class": other_class,
                        "edge": edge,
                        "witness_decomposition": half["decomposition"],
                        "half_load": load,
                        "row_singleton_users": sorted(set(row_singleton_users)),
                        "global_avoiders": global_avoiders,
                        "carrier_decompositions": tuple(sorted(set(group))),
                        "oriented_carrier_fibre": fibre,
                        "carrier_fixed": carrier_fixed,
                    }

    candidates = tuple(candidate_by_key.values())
    counterexamples = [case for case in candidates if case["carrier_fixed"]]
    counterexamples.sort(key=lambda case: (
        len(case["carrier_decompositions"]), len(case["oriented_carrier_fibre"]),
        case["cover_index"], case["state"], case["oriented_source_class"],
        case["edge"],
    ))

    def case_record(case):
        return {
            "cover_index": case["cover_index"],
            "cover": [matching_record(module, matchings, index) for index in case["cover"]],
            "state_1_based": [position + 1 for position in case["state"]],
            "complement_state_1_based": [
                position + 1 for position in case["complement_state"]
            ],
            "oriented_source_class_1_based": case["oriented_source_class"] + 1,
            "other_half_class_1_based": case["other_half_class"] + 1,
            "proper_edge_id": case["edge"],
            "proper_edge": list(module.PROPER[case["edge"]]),
            "witness_decomposition": [
                matching_record(module, matchings, index)
                for index in case["witness_decomposition"]
            ],
            "half_load": list(case["half_load"]),
            "row_singleton_users": [
                matching_record(module, matchings, index)
                for index in case["row_singleton_users"]
            ],
            "global_avoiders": [
                matching_record(module, matchings, index)
                for index in case["global_avoiders"]
            ],
            "carrier_decomposition_count": len(case["carrier_decompositions"]),
            "carrier_decompositions": [
                [matching_record(module, matchings, index) for index in decomposition]
                for decomposition in case["carrier_decompositions"]
            ],
            "oriented_carrier_fibre": [
                matching_record(module, matchings, index)
                for index in case["oriented_carrier_fibre"]
            ],
        }

    if args.require_s_to_t:
        status = ("actual_s_to_t_carrier_fixed_counterexample" if counterexamples
                  else "fixed_note007_has_no_s_to_t_carrier_fixed_counterexample")
    else:
        status = ("actual_carrier_fixed_counterexample" if counterexamples
                  else "fixed_note007_has_no_carrier_fixed_counterexample")
    result = {
        "status": status,
        "vertices": module.N,
        "proper_edges": module.N_PROPER,
        "semiedges": len(module.TERMINALS),
        "perfect_matchings": len(matchings),
        "bf_covers": len(covers),
        "require_s_to_t": args.require_s_to_t,
        "singleton_class_sizes": {
            str(position + 1): len(indices)
            for position, indices in singleton_classes.items()
        },
        "global_class_fixed_sets": {
            str(position + 1): list(edges) for position, edges in fixed_sets.items()
        },
        "actual_oriented_half_occurrences": len(actual_halves),
        "eligible_row_half_edge_cases": len(candidates),
        "carrier_fixed_cases": len(counterexamples),
        "minimal_counterexample": case_record(counterexamples[0]) if counterexamples else None,
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key != "minimal_counterexample"}
    if counterexamples:
        minimum = result["minimal_counterexample"]
        compact["minimal_counterexample_summary"] = {
            "cover_index": minimum["cover_index"],
            "state_1_based": minimum["state_1_based"],
            "complement_state_1_based": minimum["complement_state_1_based"],
            "oriented_source_class_1_based": minimum["oriented_source_class_1_based"],
            "proper_edge_id": minimum["proper_edge_id"],
            "proper_edge": minimum["proper_edge"],
            "carrier_decomposition_count": minimum["carrier_decomposition_count"],
            "oriented_carrier_fibre_indices": [
                record["index"] for record in minimum["oriented_carrier_fibre"]
            ],
            "global_avoider_indices": [
                record["index"] for record in minimum["global_avoiders"]
            ],
        }
    print(json.dumps(compact, indent=2, sort_keys=True))
    if counterexamples and args.require_s_to_t:
        print("NOTE007_ACTUAL_S_TO_T_CARRIER_FIXED_COUNTEREXAMPLE_FOUND")
    elif counterexamples:
        print("NOTE007_ACTUAL_CARRIER_FIXED_COUNTEREXAMPLE_FOUND")
    elif args.require_s_to_t:
        print("NOTE007_NO_ACTUAL_S_TO_T_CARRIER_FIXED_COUNTEREXAMPLE")
    else:
        print("NOTE007_NO_ACTUAL_CARRIER_FIXED_COUNTEREXAMPLE")


if __name__ == "__main__":
    main()
