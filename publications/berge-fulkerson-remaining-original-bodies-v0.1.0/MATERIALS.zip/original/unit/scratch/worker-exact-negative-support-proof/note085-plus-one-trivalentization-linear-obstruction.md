# One added proper coordinate cannot trivalentize the Note 085 signatures

Fix the 125 binary token vectors on the 48 coordinates of Note 085.  The
first five coordinates are terminal semiedges and the other 43 are proper
edges.  We ask whether one arbitrary new proper-edge coordinate can make the
resulting halfedges the incidences of cubic vertices.  The new coordinate is
not required to duplicate any old coordinate.

For a token $M$, let

- $b_M\in\{1,3\}$ be its weight on the five terminal coordinates;
- $w_M$ be its weight on the 43 old proper coordinates; and
- $x_M\in\{0,1\}$ be its bit on the new proper coordinate.

There are

\[
  5+2\cdot 43+2=93=3\cdot31
\]

halfedge copies after the addition.  If they can be partitioned into 31
cubic vertex triples, and each token represents a perfect matching, then
each triple contains that token on exactly one of its three halfedges.
Consequently the total number of halfedge copies containing $M$ must be
31.  Counting the terminal coordinate once and every proper coordinate
twice gives the necessary equation

\[
  b_M+2w_M+2x_M=31. \tag{1}
\]

Thus a singleton-boundary token must have

\[
  (w_M,x_M)=(15,0)\quad\text{or}\quad(14,1),
\]

whereas a triple-boundary token must have

\[
  (w_M,x_M)=(14,0)\quad\text{or}\quad(13,1).
\]

The frozen Note 085 data violate (1) for 120 of the 125 tokens.  For the
simplest witness, token `A` has $b_A=1$ and $w_A=5$, so its old halfedge
occurrence count is $1+2\cdot5=11$; one new proper coordinate can raise
this only to 13, not 31.  In the opposite direction, token `B` has
$b_B=1,w_B=33$, hence already occurs 67 times and the addition cannot
decrease its count.

Only the following five tokens individually satisfy (1):

| token | $b_M$ | $w_M$ | forced $x_M$ |
|---|---:|---:|---:|
| `C` | 1 | 15 | 0 |
| `p(1, 4)@(1, 5):1` | 1 | 14 | 1 |
| `p(2, 5)@(1, 5):5` | 1 | 15 | 0 |
| `p(3, 5)@(1, 5):3` | 1 | 14 | 1 |
| `transport:(2, 4):(2, 3):b1` | 1 | 14 | 1 |

No triple-boundary token satisfies it.  Since a single failed token is
already fatal, no choice of the new signature can satisfy all tokens, and
therefore no partition into 31 cubic vertex triples exists.

## Scope

Equation (1) is a general per-token linear necessary condition for this
trivalentization problem.  Applied to the fixed Note 085 vectors, it gives a
decisive impossibility proof before any triple-partition constraints are
considered.  It does not claim that every common-binary exact-40 model fails
trivalent realizability, does not determine how many additional coordinates
would be needed, and does not address existence of a real Case-XII pole.

## Verification

The standard-library verifier reads the frozen Note 085 JSON and recomputes
all $(b_M,w_M)$ profiles and the forced new bits:

```bash
python3 units/berge-fulkerson/scratch/worker-exact-negative-support-proof/audit_note085_trivalent_linear_invariants.py \
  units/berge-fulkerson/computations/bundles/joint-carrier-common-binary-countermodel/joint_carrier_common_binary_result.json
```

It reports 120 failures and terminates with
`NOTE085_PLUS_ONE_TRIVALENTIZATION_LINEARLY_IMPOSSIBLE`.  The frozen Omen run
used one process, about 9.25 MiB peak resident memory, and 0.02 seconds; no
perfect matchings or triple partitions were enumerated.
