# A global singleton-class avoider need not enter an actual carrier fibre

The fixed thirteen-vertex pole of Note 007 contains an actual BF row whose
oriented carrier fibre fixes a proper edge even though the complete global
singleton class contains a perfect matching avoiding that edge.  The
calculation uses all 31 perfect matchings and all 177 BF covers of the fixed
pole.

This is a genuine cubic-pole/full-PM phenomenon, but it is not an
exact-Case-XII counterexample: the Note 007 pole has an all-terminal cover
and forbidden \(T\)--\(T\) types.

## The fixed row

Number the 17 proper edges as in the Note 007 verifier.  In particular,

\[
 e_6=(3,10).                                     \tag{1}
\]

Let \(M_j\) denote perfect matching index \(j\) in the verifier's sorted
31-matching list.  BF cover index 3 is

\[
 R=(M_0,M_1,M_4,M_9,M_{25},M_{29}).             \tag{2}
\]

Its boundary classes are respectively

\[
 1, 1, 2, 4, 235, 345.                     \tag{3}
\]

Thus (2) splits into the oriented state-12 half

\[
 A=M_{29}+M_0+M_4                              \tag{4}
\]

and the complementary state-14 half

\[
 2\mathbf1-A=M_{25}+M_1+M_9.                   \tag{5}
\]

The complete 22-edge load vector of (4), with the 17 proper edges followed
by the five semiedges, is

\[
 A=(1,1,1,1,1,0,2,1,1,0,2,1,1,1,1,2,0;
       1,1,1,1,1).                               \tag{6}
\]

Both singleton occurrences \(M_0\in\mathcal P_1\) and
\(M_4\in\mathcal P_2\) use \(e_6\).  Hence two different singleton classes
in the actual BF row use the target proper edge.

Their proper-edge sets are

\[
\begin{aligned}
M_0={}&\{2,4,6,8,10,12\},\\
M_4={}&\{0,6,7,11,14,15\}.                       \tag{7}
\end{aligned}
\]

## The complete oriented carrier fibre

Define

\[
 \mathcal F_1(A;2)=
 \{P_1:\exists Q_{12},P_2, Q_{12}+P_1+P_2=A\}, \tag{8}
\]

where all matchings range over the complete 31-PM family of the fixed pole.
Exhausting every triple-boundary-345 matching, every class-1 matching, and
every class-2 matching gives exactly one decomposition:

\[
 (Q_{12},P_1,P_2)=(M_{29},M_0,M_4).             \tag{9}
\]

Consequently

\[
 \mathcal F_1(A;2)=\{M_0\},
 \qquad e_6\in M_0.                              \tag{10}
\]

The singleton class \(\mathcal P_1\) nevertheless has two members.  Its
other member is

\[
 M_1=\{2,4,5,7,9,13\},                          \tag{11}
\]

which avoids \(e_6\).  Indeed, this global avoider already occurs in the
same BF row (2), but in the complementary carrier (5).  Therefore

\[
 e_6\notin F_1,
 \qquad
 e_6\in\bigcap_{P\in\mathcal F_1(A;2)}P.         \tag{12}
\]

This is the requested strict separation between global class avoidance and
fixed oriented-carrier avoidance in an actual pole with complete PM closure.

## Exhaustiveness and scope

The fixed-pole enumeration finds 478 actual oriented half occurrences among
the 177 BF covers.  After requiring a row edge to be used by singleton
occurrences from two different classes and the oriented source class to have
a global avoider, there are 2,488 row/half/edge cases.  Of these, 1,760 have
a carrier-fixed oriented fibre.  The certificate above is first under the
deterministic ordering by number of carrier decompositions, fibre size,
cover index, state, orientation, and edge; its carrier has the minimum
possible one decomposition.

The five global class-fixed proper-edge sets are

\[
 F_1=\{2,4\},\quad F_2=\varnothing,\quad
 F_3=\{1,3\},\quad F_4=F_5=\{0\}.                \tag{13}
\]

Thus the stronger optional condition that all five fixed sets be empty does
not hold, and the overlap \(F_4\cap F_5\) reflects the fact that this pole
does not have exact Case-XII support.  The chosen edge \(e_6\) is not in
\(F_1\), so (12) is unaffected.

The example disproves the standalone inference

\[
 \text{global same-class avoider}
 \Longrightarrow
 \text{avoider inside a fixed oriented carrier}.                \tag{14}
\]

It does not disprove a theorem that also uses exact-40/no-\(A\)/no-\(TT\),
since Note 007 has only 17 \(S\)--\(T\) types, has seven forbidden
\(T\)--\(T\) types, and has an all-terminal cover.  Any positive Case-XII
argument must therefore use those exact negative and missing-positive types
to move the global avoider into the needed carrier; cubic incidence and full
PM closure alone do not do so.

## Reproduction

The verifier imports the frozen Note 007 graph and matching enumerator,
recomputes all 31 PMs and 177 BF covers, and independently exhausts all
carrier decompositions:

```text
python3 -u check_note007_actual_carrier_fixed_edges.py \
  independent_n13_bf_certificate.py --json result.json
```

Hashes are

```text
2cd38df5eb0a96d83143e5bba16629e0ee3698d190e0f1fa8166d454e3eff25e  independent_n13_bf_certificate.py
4d5d6ead538fa8ac33fb04f3cb0996a24ab52d465be5fdda8d84b5ce03f30e63  check_note007_actual_carrier_fixed_edges.py
0524c2ae0b31ccda595f09d8f3d8b4251dc1e78ea464a79ebbc730c8b080e353  note007_actual_carrier_fixed_result.json
e2d2804393229cd2f580ef01233a02f0d9798565aee6ae176369cc0c3ba5fd41  note007_actual_carrier_fixed_omen_run.log
```

One Python 3.10.12 process on Omen finished in 0.09 seconds, used 19,340 kB
peak resident memory, and exited zero with marker

```text
NOTE007_ACTUAL_CARRIER_FIXED_COUNTEREXAMPLE_FOUND
```
