# Disjoint desired-phase labels do not close the exact-Case-XII alignment gate

Fix the anchored row

\[
 q_{35}+r_{23}+B+X+P_3+P_5=2\mathbf 1                 \tag{1}
\]

from Note 082.  The five companions of \(P_3\) in this row are

\[
 \Omega=\{q_{35},r_{23},B,X,P_5\}.
\]

On every \(Y\)-phase edge of \(P_3\triangle Y\), its label is the
two-subset of \(\Omega\) using that edge.  Suppose two such labels are
disjoint.  Even after adding exact Case-XII pair support, the four literal
pivot rows, all three target overloads, and the full partial-flip cube, this
condition does not force a forbidden cover or a Note-082 pair-sum
membership by component-local reasoning.

The exact missing condition is a phase-separability property of the
double-hit set of the four anchors.

## What the disjoint labels prove

If two desired-phase edges have disjoint labels, then

\[
 \bigcap_{e\in Y\cap(P_3\triangle Y)}L(e)=\varnothing.
\]

Therefore no occurrence \(N\in\Omega\) satisfies

\[
 N+P_3-Y\in\mathcal P_{\partial N}.                 \tag{2}
\]

Thus the disjoint-label certificate does not help prove the Note-082
endpoint membership: it directly certifies its failure in the current row.
If the two edges lie in different components, the same argument blocks every
partial flip containing both components.  Flips containing only one of them
may have a partner, but two different partners do not combine into the one
companion required by (2).

## The exact no-\(A\) consequence

Put

\[
 W=A+B+C+D,\qquad D_2=\{e:W(e)=2\}.                \tag{3}
\]

The literal pivot row containing \(A,B,C,D\) gives \(W\le2\).  Write

\[
 P_3\triangle Y=C_1\mathbin{\dot\cup}\cdots
                    \mathbin{\dot\cup}C_k,
\qquad
 P^I=P_3\triangle\mathop{\triangle}_{i\in I}C_i.   \tag{4}
\]

Every \(P^I\) is an actual singleton-boundary perfect matching in the
complete matching closure.  If \(P^I\cap D_2=\varnothing\), then
\(W+P^I\le2\).  At each cubic vertex the five matching incidences have
total load five, so the three incident edge loads are necessarily
\((2,2,1)\).  The load-one objects consequently form a perfect matching

\[
 Z=2\mathbf 1-W-P^I.                               \tag{5}
\]

The five singleton matchings \(A,B,P^I,C,D\) use the five different
semiedges, so \(Z\) uses all five semiedges.  Equation (5) is therefore an
\(A=(12345)\) BF cover.  It follows that

\[
 \text{no \(A\)-cover}\quad\Longrightarrow\quad
 P^I\cap D_2\ne\varnothing\quad\text{for every }I. \tag{6}
\]

This cube-hitting condition has an exact component form.  Put
\(F=P_3\cap Y\), and write

\[
 P_i=P_3\cap C_i,\qquad Y_i=Y\cap C_i.
\]

Then

\[
\begin{split}
 &P^I\cap D_2\ne\varnothing\quad\text{for every }I\\
 &\qquad\Longleftrightarrow\qquad
 D_2\cap F\ne\varnothing
 \quad\text{or}\quad
 \exists i:\ D_2\cap P_i\ne\varnothing
                 \text{ and }D_2\cap Y_i\ne\varnothing.       \tag{7}
\end{split}
\]

Indeed, either condition on the right hits every phase choice.  Conversely,
if \(D_2\) misses \(F\) and, on each component, misses at least one of the
two phases, choose a missed phase independently on every component.  The
resulting \(P^I\) avoids \(D_2\).

Consequently the sharp additional hypothesis at this layer is

\[
\boxed{
 D_2\cap(P_3\cap Y)=\varnothing,\qquad
 \forall i,\quad
 D_2\cap P_i=\varnothing\ \text{or}\ D_2\cap Y_i=\varnothing.
}                                                   \tag{8}
\]

Condition (8) is necessary and sufficient for the partial-flip cube to
contain a member producing the forbidden \(A\)-cover by (5).  It is not
merely sufficient.  The two disjoint companion labels impose neither clause
of (8).

## Adjacent certificate edges on one six-cycle

There is one extra local fact when the two certificate edges are adjacent
\(Y\)-phase edges of one alternating six-cycle.  If their labels are
\(\{a,b\}\) and \(\{c,d\}\), the four companions occupy the two desired
edges.  At the intervening \(P_3\)-edge, the fifth companion
\(e\in\Omega-\{a,b,c,d\}\) is forced: \(P_3\) and \(e\) are precisely its
two row occurrences.

This fact does not conflict with the boundary roles or the pivot reuse.  A
complete local cubic-incidence check used the eighteen possible matching
patterns of a six-cycle with one third-edge stub at each vertex.  It imposed:

1. all four literal repeated-star rows;
2. the anchored row (1);
3. all three literal target overloads;
4. adjacent disjoint labels on two \(Y\)-edges; and
5. the strongest one-component consequence of (6), namely that \(D_2\)
   hits both the \(P_3\)-phase and the \(Y\)-phase.

Of the thirty ordered disjoint-label assignments, twenty-four are feasible.
More importantly, every possible fifth role occurs:

\[
\begin{array}{c|ccccc}
\text{fifth role}&B&P_5&X&q_{35}&r_{23}\\ \hline
\text{feasible assignments}&6&4&4&4&6.
\end{array}                                        \tag{9}
\]

Hence neither singleton/triple boundary role nor membership in the shared
pivot row excludes the forced fifth companion.

One explicit local witness has

\[
 L(y_0)=\{q_{35},r_{23}\},\qquad
 L(y_1)=\{B,X\},
\]

so \(P_5\) is forced on the intervening edge \(p_1\).  Its relevant local
patterns are

\[
\begin{array}{c|l}
A,D&y_0,p_2,s_0,s_3\\
B&p_0,y_1,s_2,s_5\\
C,P_5,r_{15}&p_1,y_2,s_1,s_4\\
X&y_1,y_2,s_1,s_2\\
Y&y_0,y_1,y_2\\
P_3&p_0,p_1,p_2\\
q_{35}&y_0,s_0,s_3,s_4,s_5\\
r_{23}&y_0,p_2,s_0,s_3 .
\end{array}                                        \tag{10}
\]

The remaining pivot triple patterns are recorded in the verifier.  In this
witness

\[
 D_2\cap P_3=\{p_2\},\qquad D_2\cap Y=\{y_0\},     \tag{11}
\]

and the three target overloads occur respectively on
\(y_1,y_2,y_0\).  Thus the second alternative in (7) holds: no-\(A\)'s
required cube hitting coexists with the disjoint labels.

## Remaining boundary

Exact positive pair support supplies other BF rows existentially.  It does
not require those rows to contain \(P^I\), and absence of \(T\)-loops or
\(T\)--\(T\) types can reject a residual decomposition only after such a
decomposition exists.  Hence these type flags do not turn the disjoint
labels into (2) or (8).

The restricted decision is therefore that the disjoint-label hypothesis and
the partial-flip cube do not supply either (2) or (8).  The explicit
six-cycle witness shows that all component-local incidence consequences of
the four pivots, the three overloads, and the no-\(A\) cube-hitting condition
remain consistent.  Exact Case-XII support flags concern additional global
rows and add no further component equation unless one proves that one of
those rows reuses a particular \(P^I\).

This is therefore a strict information boundary and not a logical
countermodel to all the real-pole hypotheses.  A positive theorem must
use a genuinely global fact forcing (8), or else a cross-row matching reuse
that yields (2) for one target despite the displayed row's empty label
intersection.  When the certificate edges lie on different components or
are nonadjacent on one component, even the forced-fifth conclusion is lost,
so those cases are strictly weaker and remain inside the same boundary.

## Reproduction

The finite local verifier is check_disjoint_labels_local_c6.py in this
directory.  It is a local CSP, not a graph or order search.  On Omen, one
Python 3.10.12 process with Z3 5.1.0 took 1.35 seconds, used 51,236 kB peak
resident memory, exited zero, and ended with
DISJOINT_LABELS_LOCAL_C6_CHECKED.
