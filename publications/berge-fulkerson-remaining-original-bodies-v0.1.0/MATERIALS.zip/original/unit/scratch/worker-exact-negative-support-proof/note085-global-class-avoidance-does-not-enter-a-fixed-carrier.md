# Global class avoidance does not enter a fixed carrier half-load

The frozen Note 085 common-binary system gives a strict abstract
counterexample to the implication from an empty global class-fixed set to
avoidance inside one prescribed carrier half-load.  No token, coordinate,
or positive pair row is changed.

This is not a real-pole counterexample: the model still lacks a common cubic
vertex incidence and graph-induced full perfect-matching closure.

## Carrier fibres

For a state \(s=ia\) and a three-token half-load \(L\), define its fixed-pool
decomposition fibre by

\[
 \mathcal D_s(L)=
 \left\{(Q_s,P_i,P_a):
   \chi_{Q_s}+\chi_{P_i}+\chi_{P_a}=L\right\},   \tag{1}
\]

where all three tokens must belong to the frozen 125-token pool and have the
displayed boundary classes.  Let \(\pi_i\mathcal D_s(L)\) be the set of
class-\(i\) singleton tokens appearing in these decompositions.

Globally, the proper-coordinate fixed sets of all five singleton classes in
the Note 085 pool are empty:

\[
 F_1=F_2=F_3=F_4=F_5=\varnothing.               \tag{2}
\]

Thus every proper coordinate used by a singleton token has some avoiding
token in the same global class.  Equation (2) does not persist after fixing
one carrier half-load.

## A minimal explicit carrier-fixed coordinate

Take the canonical \((14,23)\) pivot row and its left half

\[
 L=\chi_{q_{14}}+\chi_A+\chi_C.                 \tag{3}
\]

Here \(A\) has singleton class 1 and \(C\) has singleton class 4.  In the
frozen coordinate order, the complete half-load is

```text
111111111111101010000001010102111101111111111110
```

and its only entry equal to two is coordinate

\[
 e=29,\qquad\text{named `overload:ACXY`}.        \tag{4}
\]

Both \(A\) and \(C\) use \(e\), so (4) is a literal proper overload inside
the left half.

Exhausting every state-14 triple token, every class-1 singleton token, and
every class-4 singleton token in the fixed pool yields exactly two
decompositions of \(L\):

\[
\begin{aligned}
 L={}&\chi_{q_{14}}+\chi_A+\chi_C,\\
   ={}&\chi_{\operatorname{transport}(24,23):q0}
      +\chi_{\operatorname{transport}(24,23):b0}
      +\chi_{p(24)@(23):4}.                       \tag{5}
\end{aligned}
\]

The token names in the frozen certificate are respectively

```text
transport:(2, 4):(2, 3):q0
transport:(2, 4):(2, 3):b0
p(2, 4)@(2, 3):4
```

The class-1 carrier projection is therefore

\[
 \pi_1\mathcal D_{14}(L)
 =\{A,\operatorname{transport}(24,23):b0\}.       \tag{6}
\]

Both tokens in (6) use coordinate 29.  Hence \(e\) is fixed in this carrier
fibre.

On the other hand,

\[
 \operatorname{transport}(24,23):b1\in\mathcal M_1
\]

is a frozen class-1 token avoiding coordinate 29.  Ten further class-1
avoiders also exist.  Thus

\[
 e\notin F_1,
 \qquad
 e\in\bigcap_{P\in\pi_1\mathcal D_{14}(L)}P.      \tag{7}
\]

Equations (3)--(7) are the requested complete separation between global and
carrier-local fixedness.

## Exhaustive fixed-data scope

Across the four canonical pivot rows, 75 left-singleton/proper-overload
cases satisfy the same input conditions: the chosen left singleton uses the
coordinate, another singleton class in the row also uses it, and the global
class contains an avoiding token.  Forty-one of those 75 cases are
carrier-fixed.  The certificate above is minimal under the deterministic
ordering by number of decompositions, carrier-fibre size, pivot row, and
coordinate: its half-load has two decompositions and its class-1 projection
has two tokens.

Therefore the frozen model proves the strict common-binary non-implication

\[
\begin{split}
&F_i=\varnothing
 +\text{ a canonical carrier containing }P_i
 +e\in P_i\\
&\quad+\text{another singleton class using }e
\end{split}
\not\Longrightarrow
\exists (Q_s',P_i',P_a')\in\mathcal D_s(L)
\text{ with }e\notin P_i'.                       \tag{8}
\]

This closes an inference that uses only global class-exclusivity and fixed
binary half-load equations.  It does not decide whether the complete
perfect-matching family of one cubic exact-Case-XII pole forces a suitable
replacement, since its alternating-cycle switches can leave the chosen
carrier half-load and enter a different actual carrier.

## Reproduction

The read-only verifier uses only the frozen Note 085 JSON and deterministic
row constructor:

```text
python3 -u check_note085_carrier_fixed_coordinates.py \
  joint_carrier_common_binary_result.json \
  synthesize_joint_carrier_guard_model.py \
  --json result.json
```

Hashes are

```text
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
bf7bb4b4ce5e3662f18bc044b50b454380f9d2a38b3fe24fb6872972b3dc7d8f  synthesize_joint_carrier_guard_model.py
19219175884f51bbc58e5ef7f3aa347f77c4d4ad3779826b207324546d316f32  check_note085_carrier_fixed_coordinates.py
661793f13b89d9fd9d9b0589ca0709f194d68a95cb105db80370d7a688958f3e  note085_carrier_fixed_result.json
619245e59cea745f011adc9a78cf8a80c3105813061a5aa122470289d43f2083  note085_carrier_fixed_omen_run.log
```

One Python 3.10.12 process on Omen finished in 0.14 seconds, used 20,736 kB
peak resident memory, and exited zero with marker

```text
NOTE085_CARRIER_FIXED_COORDINATE_COUNTERMODEL
```
