#!/usr/bin/env python3
"""Read-only test for carrier-fixed coordinates in the frozen Note 085 data."""

from __future__ import annotations

import argparse
import importlib.util
import json
from itertools import combinations
from pathlib import Path


SEMIEDGE_COUNT = 5


def load_module(path):
    spec = importlib.util.spec_from_file_location("note085_model", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def vector_sum(vectors, tokens):
    return tuple(sum(vectors[token][coordinate] for token in tokens)
                 for coordinate in range(len(next(iter(vectors.values())))))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("model_script", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    payload = json.loads(args.input_json.read_text())
    module = load_module(args.model_script)
    builder = module.ModelBuilder().build()
    vectors = {
        token: tuple(int(bit) for bit in bits)
        for token, bits in payload["vectors"].items()
    }
    assert payload["status"] == "common_binary_countermodel"
    assert payload["tokens"] == len(vectors) == 125
    assert payload["coordinates"] == 48
    assert set(vectors) == set(builder.kind)

    singleton_classes = {
        position: tuple(
            token for token in sorted(vectors)
            if builder.kind[token] == "singleton"
            and builder.boundary[token] == position
        )
        for position in range(1, 6)
    }
    fixed_sets = {
        position: tuple(
            coordinate for coordinate in range(SEMIEDGE_COUNT, 48)
            if all(vectors[token][coordinate] for token in tokens)
        )
        for position, tokens in singleton_classes.items()
    }
    assert all(not (set(fixed_sets[i]) & set(fixed_sets[j]))
               for i, j in combinations(range(1, 6), 2))

    tested = []
    counterexamples = []
    for row_index, ((state, t_state), _) in enumerate(module.LITERAL_SEEDS.items()):
        row = builder.st_base[(state, t_state)]
        left = tuple(row[:3])
        triple_occurrences = [token for token in left
                              if builder.kind[token] == "triple"]
        singleton_occurrences = [token for token in left
                                 if builder.kind[token] == "singleton"]
        assert len(triple_occurrences) == 1 and len(singleton_occurrences) == 2
        assert builder.boundary[triple_occurrences[0]] == state
        assert sorted(builder.boundary[token] for token in singleton_occurrences) == list(state)
        half_load = vector_sum(vectors, left)

        triple_pool = tuple(
            token for token in sorted(vectors)
            if builder.kind[token] == "triple" and builder.boundary[token] == state
        )
        class_first, class_second = state
        all_decompositions = []
        for q in triple_pool:
            for p_first in singleton_classes[class_first]:
                for p_second in singleton_classes[class_second]:
                    decomposition = (q, p_first, p_second)
                    if vector_sum(vectors, decomposition) == half_load:
                        all_decompositions.append(decomposition)
        assert all_decompositions
        assert any(set(decomposition) == set(left) for decomposition in all_decompositions)

        full_row_singletons = [token for token in row
                               if builder.kind[token] == "singleton"]
        for source in singleton_occurrences:
            source_class = builder.boundary[source]
            other_class = next(position for position in state if position != source_class)
            role_index = 1 if source_class == class_first else 2
            for coordinate in range(SEMIEDGE_COUNT, 48):
                if not vectors[source][coordinate]:
                    continue
                row_users = [token for token in full_row_singletons
                             if vectors[token][coordinate]]
                if len({builder.boundary[token] for token in row_users}) < 2:
                    continue
                global_avoiders = [
                    token for token in singleton_classes[source_class]
                    if not vectors[token][coordinate]
                ]
                assert global_avoiders
                fibre_tokens = sorted({decomposition[role_index]
                                       for decomposition in all_decompositions})
                carrier_fixed = all(vectors[token][coordinate] for token in fibre_tokens)
                record = {
                    "row_index": row_index,
                    "row": f"{state}-{t_state}",
                    "row_tokens": list(row),
                    "left_tokens": list(left),
                    "state": list(state),
                    "half_load": "".join(map(str, half_load)),
                    "coordinate": coordinate,
                    "coordinate_name": payload["coordinate_names"][coordinate],
                    "half_load_at_coordinate": half_load[coordinate],
                    "source": source,
                    "source_class": source_class,
                    "other_class": other_class,
                    "row_singleton_users": row_users,
                    "global_avoiders": global_avoiders,
                    "decomposition_count": len(all_decompositions),
                    "decompositions": [list(decomposition)
                                       for decomposition in all_decompositions],
                    "source_class_carrier_fibre": fibre_tokens,
                    "carrier_fixed": carrier_fixed,
                }
                tested.append(record)
                if carrier_fixed:
                    counterexamples.append(record)

    counterexamples.sort(key=lambda item: (
        item["decomposition_count"], len(item["source_class_carrier_fibre"]),
        item["row_index"], item["coordinate"], item["source_class"],
    ))
    status = (
        "strict_common_binary_carrier_fixed_countermodel"
        if counterexamples else "fixed_data_has_no_carrier_fixed_counterexample"
    )
    result = {
        "status": status,
        "tokens": len(vectors),
        "coordinates": payload["coordinates"],
        "canonical_pivot_rows": len(module.LITERAL_SEEDS),
        "class_fixed_sets": {str(position): list(values)
                             for position, values in fixed_sets.items()},
        "tested_left_singleton_overload_cases": len(tested),
        "carrier_fixed_cases": len(counterexamples),
        "minimal_counterexample": counterexamples[0] if counterexamples else None,
        "all_counterexamples": counterexamples,
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key not in ("minimal_counterexample", "all_counterexamples")}
    if counterexamples:
        compact["minimal_counterexample_summary"] = {
            key: counterexamples[0][key]
            for key in (
                "row", "left_tokens", "coordinate", "coordinate_name",
                "half_load_at_coordinate", "source", "source_class",
                "row_singleton_users", "global_avoiders",
                "decomposition_count", "source_class_carrier_fibre",
            )
        }
    print(json.dumps(compact, indent=2, sort_keys=True))
    if counterexamples:
        print("NOTE085_CARRIER_FIXED_COORDINATE_COUNTERMODEL")
    else:
        print("NOTE085_NO_CARRIER_FIXED_COORDINATE_COUNTERMODEL")


if __name__ == "__main__":
    main()
