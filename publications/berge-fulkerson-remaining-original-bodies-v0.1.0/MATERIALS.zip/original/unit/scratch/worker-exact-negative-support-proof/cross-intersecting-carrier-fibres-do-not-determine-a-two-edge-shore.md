# Cross-intersecting carrier fibres do not determine a two-edge shore

Fix a simple connected cubic five-pole \(H\), singleton perfect matchings
\(A\in\mathcal P_1\), \(C\in\mathcal P_4\),
\(D\in\mathcal P_5\), and

\[
K=2\mathbf1-A-C-D.
\tag{1}
\]

Assume that both actual carrier fibres

\[
\begin{aligned}
\mathcal B(K)&=\{B\in\mathcal P_2:
K=q_{24}+r_{15}+B\},\\
\mathcal X(K)&=\{X\in\mathcal P_3:
K=q_{13}+r_{45}+X\}
\end{aligned}
\tag{2}
\]

are nonempty, that every actual three-matching decomposition of \(K\)
completed by \(A,C,D\) has no \(T\)-loop or \(T\)--\(T\) boundary type, and
that

\[
B\cap X\cap(A\mathbin\triangle C)\ne\varnothing
\qquad
(B,X)\in\mathcal B(K)\times\mathcal X(K).
\tag{3}
\]

These hypotheses do not presently force a proper two-edge-sum factor. The
precise unresolved step is not another carrier-colouring statement: it is a
localization statement from the spanning copy-multigraph \(K\) to a
terminal-free vertex shore of the support graph \(H\).

No real pole satisfying all the displayed hypotheses and lacking the
required shore is supplied here, so this is not a counterexample to the
proposed implication. Conversely, the implication is not proved by the
stated data. The exact sufficient structural addition is given below.

## What the hypotheses determine

At every internal vertex of \(H\), each of \(A,C,D\) uses one incident edge
object. Hence the total copy-degree of \(K\) is

\[
6-3=3.
\]

Thus \(K\) is a cubic copy-multigraph on the full vertex set of \(H\), with
edge multiplicities in \(\{0,1,2\}\). Every equality

\[
K=Q+R+P
\tag{4}
\]

in (2) is a genuine three-edge-colouring of this copy-multigraph, with
prescribed boundary colours. The assumption about all actual
decompositions is therefore complete information about the relevant
boundary-labelled three-edge-colouring relation of \(K\).

Put

\[
P=A\mathbin\triangle C
\]

and take traces on its unit-load owner edges:

\[
\mathscr B=\{B\cap P:B\in\mathcal B(K)\},\qquad
\mathscr X=\{X\cap P:X\in\mathcal X(K)\}.
\tag{5}
\]

Equation (3) says exactly that \(\mathscr B,\mathscr X\) are
cross-intersecting. Same-fibre Kempe moves replace one colour along closed
alternating components of \(K\); knowing all such moves still gives only
the colouring graph of \(K\).

None of (1)--(5) identifies a proper vertex subset \(U\subset V(H)\), says
that the bad owner edges lie in \(H[U]\), or bounds
\(\lvert\delta_H(U)\rvert\). This is essential because \(K\) is generally
spanning and is not a subgraph component of \(H\): load-zero and load-two
edges of \(K\) still belong to the support graph, and the matching
decompositions do not delete their incidences from \(H\).

## Why the \(K_{3,3}\) rectangle does not supply the cut

The owner rectangle of Note 097 gives

\[
\mathcal B_{\rm loc}=\{012,120\},\qquad
\mathcal X_{\rm loc}=\{021,102\}
\tag{6}
\]

on a \(K_{3,3}\) colour block. Every cross pair in (6) has one bad
\(A/C\)-owned common edge, while both row and column differences are genuine
alternating six-cycles and every cross difference is an alternating
four-cycle. The underlying \(K_{3,3}\) is 3-edge-connected and has no
two-edge cut.

Consequently cross-intersection, absence of a fixed row or column edge,
complete local Kempe-component data and common cubic incidence do not
produce a two-edge separator even on the model colour block. Note 098 shows
that the exact no-\(TT\) terminal pairings can be imposed independently of
these internal cycles.

This is a strict analytic countermodel to the *carrier-colouring-to-cut
step*, but not to the full pole statement: the selected relation (6) has
not been realized as the complete graph-induced fibres of a pole satisfying
all assumptions above. That missing realization is exactly why the real
implication remains undecided.

## Exact additional shore condition

The minimum graph-structural datum needed to invoke Note 099 is the
following common-shore localization.

There is a nonempty proper vertex set \(U\subset V(H)\) such that

1. \(U\) is terminal-free;
2. \(\delta_H(U)=\{\alpha,\beta\}\);
3. after cutting \(\alpha,\beta\) at their ends in \(U\) and joining the two
   resulting degree-two incidences by an edge \(f\), the completed graph
   \(J\) is a closed simple cubic graph;
4. the restrictions to \(U\) of one actual decomposition (4), with the two
   port incidences completed by \(f\), are three one-factors of \(J\).

Condition 4 is exactly a 3-edge-colouring of \(J\). Conditions 1--3 identify
\(H\) as

\[
H=H_0\oplus_{e,f}J
\tag{7}
\]

for the graph obtained by contracting the shore to the edge \(e\).
Note 099 then preserves complete BF support, Tait states and every literal
dependent two-splice fibre, so the shore can be removed.

If it is already known independently that the completed shore \(J\) is
3-edge-colourable, condition 4 is redundant. Conversely, without conditions
1--2 there is no two-sum factor to which Note 099 can apply, regardless of
how many carrier colourings or Kempe components are known.

## Sharp stopping boundary

The proposed implication therefore separates into two logically different
claims:

\[
\begin{array}{c}
\text{complete negative carrier relation and (3)}
\\[1mm]\Downarrow\quad\text{unknown}\\[1mm]
\text{common-shore localization 1--4}
\\[1mm]\Downarrow\quad\text{Note 099}\\[1mm]
\text{strict descent}.
\end{array}
\]

The second arrow is proved. The first is not a consequence of the local
\(K_{3,3}\) owner rectangle, complete carrier colourings, or their Kempe
components. Settling it requires a new theorem coupling the copy loads
\(K=2\mathbf1-A-C-D\) to vertex cuts of the original support graph \(H\),
or a genuine pole realizing the full cross-intersecting relation without
such a cut. More carrier-state analysis alone does not distinguish these
possibilities.
