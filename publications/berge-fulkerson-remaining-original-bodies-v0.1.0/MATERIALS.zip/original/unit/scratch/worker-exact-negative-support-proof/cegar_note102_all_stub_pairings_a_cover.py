#!/usr/bin/env python3
"""CEGAR for A-covers over every loopless pairing of the fixed 67 stars.

Outer choices are perfect pairings inside each repeated occurrence-column.
The inner problem is the exact 15-colour owner-pair formulation of an A-cover.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations
import json
from pathlib import Path
import time

from z3 import Bool, Or, PbEq, Solver, is_true, sat, unsat


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
OUTPUT = HERE / "note102_all_pairings_a_cover_cegar_result.json"
TIME_LIMIT = 220.0
ROUND_LIMIT = 2000


def perfect_pairings(items):
    items = tuple(items)
    if not items:
        yield ()
        return
    first = items[0]
    for index in range(1, len(items)):
        second = items[index]
        rest = items[1:index] + items[index + 1:]
        for tail in perfect_pairings(rest):
            yield ((first, second),) + tail


def inner_a_cover(n, terminal_stubs, pairing):
    owner_pairs = tuple(combinations(range(6), 2))
    incident = [[] for _ in range(n)]
    for edge, (left, right) in enumerate(pairing):
        incident[left[0]].append(edge)
        incident[right[0]].append(edge)

    solver = Solver()
    colour = {
        (edge, pair_index): Bool(f"e{edge}_c{pair_index}")
        for edge in range(len(pairing)) for pair_index in range(len(owner_pairs))
    }
    for edge in range(len(pairing)):
        solver.add(PbEq([(colour[edge, p], 1) for p in range(len(owner_pairs))], 1))

    for vertex in range(n):
        if vertex < 5:
            forbidden = {vertex, 5}
            for label in range(6):
                target = 0 if label in forbidden else 1
                solver.add(PbEq([
                    (colour[edge, p], 1)
                    for edge in incident[vertex]
                    for p, pair in enumerate(owner_pairs) if label in pair
                ], target))
        else:
            for label in range(6):
                solver.add(PbEq([
                    (colour[edge, p], 1)
                    for edge in incident[vertex]
                    for p, pair in enumerate(owner_pairs) if label in pair
                ], 1))

    result = solver.check()
    if result != sat:
        return result, None
    model = solver.model()
    edge_colours = []
    for edge in range(len(pairing)):
        selected = [p for p in range(len(owner_pairs))
                    if is_true(model.eval(colour[edge, p]))]
        assert len(selected) == 1
        edge_colours.append(selected[0])

    # Return the 6-bit owner vector at every proper stub.
    stub_usage = {}
    for edge, (left, right) in enumerate(pairing):
        pair = owner_pairs[edge_colours[edge]]
        usage = sum(1 << label for label in pair)
        stub_usage[left] = usage
        stub_usage[right] = usage
    return result, stub_usage


def main():
    started = time.monotonic()
    record = json.loads(INPUT.read_text())
    vertices = record["vertices"]
    n = len(vertices)

    by_block = defaultdict(list)
    terminal_stubs = {}
    for vertex, item in enumerate(vertices):
        for local, block in enumerate(item["blocks"]):
            stub = (vertex, local, block)
            if item["kind"] == "terminal" and block == item["terminal_block"]:
                terminal_stubs[vertex] = stub
            else:
                by_block[block].append(stub)
    assert set(terminal_stubs) == set(range(5))
    assert sum(map(len, by_block.values())) == 196
    assert all(len({stub[0] for stub in stubs}) == len(stubs)
               for stubs in by_block.values())

    groups = []
    fixed_pairs = []
    for block, stubs in sorted(by_block.items()):
        configs = tuple(perfect_pairings(stubs))
        if len(configs) == 1:
            fixed_pairs.extend(configs[0])
        else:
            groups.append((block, configs))
    assert len(groups) == 13
    pairing_space = 1
    for _, configs in groups:
        pairing_space *= len(configs)
    assert pairing_space == 6_975_163_125

    outer = Solver()
    choose = {}
    for group, (_, configs) in enumerate(groups):
        for config in range(len(configs)):
            choose[group, config] = Bool(f"g{group}_p{config}")
        outer.add(PbEq([(choose[group, c], 1) for c in range(len(configs))], 1))

    rounds = []
    status = "round_limit"
    counterexample = None
    for round_index in range(ROUND_LIMIT):
        if time.monotonic() - started > TIME_LIMIT:
            status = "time_limit"
            break
        outer_result = outer.check()
        if outer_result == unsat:
            status = "all_pairings_have_A"
            break
        assert outer_result == sat
        outer_model = outer.model()
        selected_configs = []
        pairing = list(fixed_pairs)
        for group, (_, configs) in enumerate(groups):
            config = next(c for c in range(len(configs))
                          if is_true(outer_model.eval(choose[group, c])))
            selected_configs.append(config)
            pairing.extend(configs[config])
        assert len(pairing) == 98

        inner_result, usage = inner_a_cover(n, terminal_stubs, pairing)
        if inner_result == unsat:
            status = "no_A_pairing"
            counterexample = selected_configs
            break
        assert inner_result == sat

        incompatible_literals = []
        compatible_counts = []
        for group, (_, configs) in enumerate(groups):
            compatible = []
            for config, pairs in enumerate(configs):
                if all(usage[left] == usage[right] for left, right in pairs):
                    compatible.append(config)
                else:
                    incompatible_literals.append(choose[group, config])
            compatible_counts.append(len(compatible))
        # The current witness remains a valid A-cover exactly on the Cartesian
        # product of compatible configurations.  Exclude that whole product.
        assert incompatible_literals
        outer.add(Or(*incompatible_literals))
        covered = 1
        for count in compatible_counts:
            covered *= count
        rounds.append({
            "round": round_index,
            "selected_configs": selected_configs,
            "compatible_config_counts": compatible_counts,
            "pairings_covered_by_witness": covered,
        })

    result = {
        "status": status,
        "pairing_space": pairing_space,
        "nontrivial_column_groups": len(groups),
        "rounds": len(rounds),
        "counterexample_configs": counterexample,
        "elapsed_s": time.monotonic() - started,
        "last_rounds": rounds[-10:],
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, sort_keys=True))
    print("NOTE102_ALL_PAIRINGS_A_COVER_CEGAR_STOPPED")


if __name__ == "__main__":
    main()
