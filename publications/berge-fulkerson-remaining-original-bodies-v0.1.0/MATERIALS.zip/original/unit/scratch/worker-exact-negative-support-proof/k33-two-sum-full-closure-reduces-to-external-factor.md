# Full closure of the \(K_{3,3}\) owner block reduces to the external factor

Fix the two-edge sum

\[
H=H_0\oplus_{e,f}K_{3,3}
\]

of Note 076, and use the owner assignment of Notes 097--098. For the
attachment used there, \(f=(0,2)\), so the six one-factors, written as
permutations, have \(f\)-bits

\[
\begin{array}{c|cccccc}
P&012&021&102&120&201&210\\ \hline
\mathbf 1_{f\in P}&0&0&0&0&1&1.
\end{array}
\tag{1}
\]

The full perfect-matching closure destroys the *isolated local* \(2\times2\)
rectangle of Note 097, but it does not force any of the proposed *global*
exits. More precisely:

1. the complete BF boundary support and Tait state set of \(H\) equal those
   of \(H_0\), so the block creates no all-terminal or \(T\)--\(T\) cover;
2. a globally safe fixed-carrier \(B\times X\) choice exists in \(H\) if
   and only if the corresponding exterior fixed fibre has a safe choice in
   \(H_0\);
3. every Note082 aligned splice in \(H\) projects to aligned splices in both
   factors. In particular the \(K_{3,3}\) factor cannot repair an empty
   external phase intersection.

Consequently the owner block plus graph-induced closure does not decide the
proposed four-way alternative. It reduces it to the corresponding
external-factor statement, which remains undecided in the exact-Case-XII
class. On the other hand, any exact-Case-XII pole which genuinely has this
two-sum decomposition has a smaller exact-Case-XII factor. Thus a
minimum-order exact-Case-XII pole cannot contain such a separable
\(K_{3,3}\) block.

## What full closure does locally

The fixed owner factors are

\[
A=012,\qquad C=120,\qquad D=201,
\tag{2}
\]

so only \(D\) uses \(f\). In all four rows displayed in Note 098, the
carrier triple has bit pattern

\[
(q,r,B)=(0,1,0),\qquad (q,r,X)=(0,1,0).
\tag{3}
\]

For every one-factor \(P\) avoiding \(f\), \(K_{3,3}-P\) is a six-cycle. Its
two alternating one-factors consist of one factor avoiding \(f\) and one
factor using \(f\). Hence the same exterior occurrences can be spliced with
all four locally compatible choices

\[
\mathcal B_f=\mathcal X_f=\{012,021,102,120\}.
\tag{4}
\]

This follows from the unique perfect-matching splice of Note 076 and does
not require a new graph search. In particular the full local fibres contain
the disjoint ordered pairs

\[
(012,120),\ (120,012),\ (021,102),\ (102,021).
\tag{5}
\]

Thus the four bad cells in the displayed rectangle are not closed under all
perfect matchings of the inserted factor: closure supplies a choice which is
safe *inside the gadget*.

This local fact is not a global safe-section theorem. Let

\[
J_H(B,X)=B\cap X\cap(A\mathbin\triangle C).
\]

Projection of the five matchings to both factors gives corresponding sets
\(J_0\) and \(J_K\). Away from the splice edges, \(J_H\) is their disjoint
union. If the distinguished edge belongs to the factor intersection, it is
replaced by the two cut edges, and it belongs simultaneously on both factor
sides because all splice bits agree. Therefore

\[
J_H(B,X)=\varnothing
\quad\Longleftrightarrow\quad
J_0(B_0,X_0)=\varnothing
\ \text{and}\
J_K(B_K,X_K)=\varnothing.
\tag{6}
\]

Equation (5) can satisfy the second conjunct, but cannot affect the first.
Conversely, every exterior safe pair can be given a gadget-safe lift. The
four possible distinguished-bit pairs for \((B,X)\) admit, respectively,
the following local choices:

\[
\begin{array}{c|c}
(\mathbf1_{e\in B_0},\mathbf1_{e\in X_0})&(B_K,X_K)\\ \hline
(0,0)&(012,120)\\
(0,1)&(012,201)\\
(1,0)&(201,012)\\
(1,1)&(201,210).
\end{array}
\tag{7}
\]

Each pair is disjoint except the last, whose sole common edge is \(f\);
because \(A_K\) and \(C_K\) both avoid \(f\), this common edge is
\(D\)-owned and safe. The complementary two one-factors have exactly the
distinguished bits required by the two triple slots, so the rows splice.
Thus safe-section existence is exactly inherited from the exterior factor,
not created by the block.

The terminal pairings

\[
\pi_B=(2\,1)(3\,5),\qquad
\pi_X=(3\,4)(2\,5)
\]

only concern external terminal-path components and do not imply the first
conjunct, as already isolated in Note 098.

## Factorization of the Note082 alignment test

Let \(P,\widehat P,N\) be perfect matchings of \(H\), with unique factor
projections

\[
(P_0,P_K),\quad(\widehat P_0,\widehat P_K),\quad(N_0,N_K).
\]

By Note 082,

\[
\operatorname{Align}_H(N;P\to\widehat P)
\]

is equivalent to the signed incidence vector

\[
N'=N+P-\widehat P
\tag{8}
\]

being a perfect matching of \(H\). Define on the two factors

\[
N'_0=N_0+P_0-\widehat P_0,
\qquad
N'_K=N_K+P_K-\widehat P_K.
\tag{9}
\]

If (8) is a perfect matching, unique two-sum projection shows that both
vectors in (9) are perfect matchings. Conversely, suppose both vectors in
(9) are perfect matchings. Their distinguished-edge bits agree, since

\[
\mathbf1_{e\in N'_0}
=\mathbf1_{e\in N_0}+\mathbf1_{e\in P_0}
 -\mathbf1_{e\in\widehat P_0}
=\mathbf1_{f\in N_K}+\mathbf1_{f\in P_K}
 -\mathbf1_{f\in\widehat P_K}
=\mathbf1_{f\in N'_K}.
\tag{10}
\]

They therefore splice to (8). Hence

\[
\boxed{
\operatorname{Align}_H(N;P\to\widehat P)
\iff
\operatorname{Align}_{H_0}(N_0;P_0\to\widehat P_0)
\ \land\
\operatorname{Align}_{K}(N_K;P_K\to\widehat P_K).}
\tag{11}
\]

The same argument applies at each stage of a sequential two-splice and to
the forced-intermediate branch of Note 082. Every successful global chain
therefore projects to a chain of length at most two in \(H_0\). Local
\(K_{3,3}\) phases add a conjunct; they never turn a failed external
intersection into a successful one.

## Exact-support reducibility

Note 076 proves, for every BF boundary type \(b\),

\[
b\in\operatorname{BFsupp}(H)
\iff b\in\operatorname{BFsupp}(H_0),
\qquad
\operatorname{TaitStates}(H)=\operatorname{TaitStates}(H_0).
\tag{12}
\]

Thus if \(H\) has exact Case-XII support, then \(H_0\) has the same exact
support, including absence of the all-terminal and all \(T\)--\(T\) types.
Since \(H_0\) has six fewer vertices, a minimum-order pole in that class is
two-sum-irreducible with respect to \(K_{3,3}\).

This is the sharp conclusion available from Notes 076, 082 and 095--098.
It neither constructs an exact-Case-XII pole nor proves that the external
fixed-carrier safe section or dependent two-splice fibre exists.
