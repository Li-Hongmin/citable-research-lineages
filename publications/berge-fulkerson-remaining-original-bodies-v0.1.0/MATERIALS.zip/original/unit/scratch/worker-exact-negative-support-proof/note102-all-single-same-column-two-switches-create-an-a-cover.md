# Every single same-column two-switch of the Note 102 multigraph creates an A cover

## Neighbourhood

Let \(H_0\) be the frozen 67-vertex cubic five-pole multigraph of Note 102.
Its 98 proper edge objects are grouped by their common 22-bit selected-family
incidence column.  The group-size distribution is

\[
67\cdot 1,qquad 9\cdot 2,qquad 3\cdot 3,qquad 1\cdot 4.
\]

Consequently there are

\[
9\binom22+3\binom32+\binom42=24
\]

unordered pairs of proper edges in one column.  The two edges of such a pair
have four distinct endpoints, because one column occurs at most once at a
trivalent vertex.  Replacing their present pairing by either of the other two
pairings therefore gives 48 raw single-two-switch candidates.

Canonicalization by the multiset of triples

\[
(\text{22-bit column},\text{left endpoint},\text{right endpoint})
\]

leaves 48 distinct candidates.  All 48 are loopless, connected and cubic.
All retain exactly nineteen selected perfect-matching identities, and direct
edge-object checking verifies each of the six selected BF rows.  Thus no
candidate is lost through a failure of the designated Note 101 data.

None of these 48 candidates is simple.  Forty have two parallel endpoint
pairs, six have one, and two have three.  This count is descriptive only;
parallel proper edges remain distinct objects throughout the matching
queries.

## Complete-closure classification

For each candidate, the first exact full-closure query chooses five actual
perfect matchings \(M_i\), with singleton boundary \(i\), subject to proper
edge-object load at most two.  Every one of the 48 queries is satisfiable.
Each returned \(M_i\) contains 34 edge objects: 33 proper edges and its one
semiedge.

Let \(m(e)=\sum_i\chi_{M_i}(e)\).  Cubicity and the load bound force local
multiplicities \((2,2,1)\) at every nonterminal vertex; at terminal \(i\),
the semiedge has load one and the two proper incidences have load two.  Hence

\[
M_*=\{e:m(e)=1\}
\]

is an all-terminal perfect matching.  In every candidate it has 36 edge
objects: 31 proper edges and all five semiedges.  The checker verifies
directly, rather than relying only on the local count, that

\[
M_0+M_1+M_2+M_3+M_4+M_*=2\mathbf 1
\]

on all 103 edge objects.  Thus the complete classification is

\[
48\text{ candidates}=48\text{ repaired by forbidden A support}.
\]

The scan stops at this first forbidden family for every candidate.  No TT,
fixed-state-35 endpoint, positive-40-support or Tait query is needed, and no
such unrun query is assigned a value.  In particular, the neighbourhood
contains no exact-Case-XII / Note-082 counterexample candidate.

## Exact boundary

This is an exhaustive statement only for one same-column two-switch from the
particular pairing \(H_0\).  It does not cover two or more switches, a
different initial global pairing of the Note 101 columns, or an arbitrary
simple cubic realization.  Since none of the 48 neighbours is simple, it
also gives no one-step simple candidate.  The weakest remaining quantifier is
therefore not another edge pair in this neighbourhood, but a larger pairing
change or an independently constrained full-closure synthesis.

## Reproduction

The single scan ran on `omen` in

```text
[local archival reference]
```

under Python 3.10.12 and Z3 5.1.0, with one process, a 1-GiB virtual-memory
limit and a 240-second outer timeout.  It terminated with

```text
NOTE102_TWO_SWITCH_CLOSURE_NEIGHBOURHOOD_COMPLETE
```

after 2.27 seconds wall time, using 58,112 KiB maximum RSS.  The exact result
record contains the switch source, canonical hash and explicit six-matching
A witness for every candidate.

SHA-256 values are

```text
4edafec6657cf0304fab737e34d8b19ea11133daa82fdadca11e1955a308363a  scan_note102_same_column_two_switch_closure.py
e582fa2eadb956fd062d4cfa55fe62934837c82cbc253bed33e6cd325687c1f6  check_note101_global_multigraph_closure.py
36ec05b108fcbf43596e648c640fee88ef6624f005577ffb2d76b19c19e73fbf  note101_global_stub_pairing_result.json
a87baa5e700c3e626e7db60ed58aa7e91c49b65369916dd944e6fa7c3b7746a3  note102_same_column_two_switch_closure_result.json
d1c7ead73debabda1369485f7c7e75f34f4648ec559a03052601c2700fcfbcce  note102_same_column_two_switch_closure_omen_run.log
```
