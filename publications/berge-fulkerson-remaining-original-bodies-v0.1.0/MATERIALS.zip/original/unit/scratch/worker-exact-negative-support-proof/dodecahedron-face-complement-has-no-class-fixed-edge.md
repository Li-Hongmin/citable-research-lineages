# The dodecahedral five-cut side has no singleton-class fixed edge

Consider the generalized Petersen graph \(G(10,2)\), which is the
dodecahedral graph.  Delete one of its two inner 5-cycles and replace the
five cut spokes by semiedges on the remaining side.  Denote the resulting
5-pole by \(H\).

This fixed strong candidate does not refute the class-fixed-edge statement.
Every singleton perfect-matching class is nonempty, but no proper edge is
contained in all members of any singleton class.

## Structure of the fixed pole

Write the outer cycle as

\[
 u_0u_1\cdots u_9u_0
\]

and retain the odd inner cycle

\[
 v_1v_3v_5v_7v_9v_1
\]

together with the five spokes \(u_iv_i\) for odd \(i\).  The semiedges are
attached at the five distinct vertices

\[
 u_0,u_2,u_4,u_6,u_8.
\]

Thus \(H\) has 15 vertices, 20 proper edges, and five semiedges.  Direct
verification gives:

* the proper graph is simple and connected;
* its girth is five;
* it has no bridge;
* its only five proper 2-edge-cuts isolate one of the five one-vertex
  terminal trees;
* restoring the deleted inner 5-cycle gives \(G(10,2)\), whose cyclic edge
  connectivity is exactly five.

In particular, this is a side of a genuine cyclic 5-edge-cut and has no
non-terminal-tree proper 2-edge-cut.

## Complete singleton-class calculation

The pole has 41 perfect matchings in total.  For each terminal
\(i\in\{0,1,2,3,4\}\), the singleton class \(\mathcal P_i\) has exactly five
members.  Exhaustive enumeration gives

\[
 \bigcap_{P\in\mathcal P_i} P=\varnothing
 \qquad(i=0,1,2,3,4),                            \tag{1}
\]

where the intersection is over proper edges.  Hence not only is there no
class-fixed edge outside the terminal-tree cuts; there is no class-fixed
proper edge at all.

The conclusion is limited to this one fixed pole.  It neither proves nor
disproves the general class-fixed-edge statement under the stated strong
structural assumptions, and the stopping rule forbids moving to another
graph family or order.

## Exact remaining barrier

There is nevertheless a sharp general formulation of what any future
class-fixed-edge example must contain.  Fix terminal vertex \(t_i\), and
let

\[
 K_i=H-t_i.
\]

Selecting the semiedge at \(t_i\) identifies \(\mathcal P_i\) with the
perfect matchings of \(K_i\).  Therefore a proper edge \(e\) is fixed in
\(\mathcal P_i\) exactly when

\[
 K_i\text{ has a perfect matching, but }K_i-e\text{ does not}.       \tag{2}
\]

By Tutte's theorem, (2) is equivalent to the existence of
\(X\subseteq V(K_i)\) such that

\[
 o(K_i-X)=|X|,
 \qquad
 o(K_i-e-X)=|X|+2.                              \tag{3}
\]

Indeed, factorizability of \(K_i\) gives the first inequality
\(o(K_i-X)\le |X|\), while non-factorizability of \(K_i-e\), together with
parity, gives \(o(K_i-e-X)\ge |X|+2\).  Deleting one edge can increase the
number of odd components by at most two, so both inequalities must be equalities.
Equivalently, \(e\) is a bridge of an even component of \(K_i-X\) and its
deletion splits that component into two odd components.

Thus a singleton-class fixed edge requires a genuine matching barrier after
the terminal vertex is deleted.  Girth five, bridge-freeness of \(H\),
cyclic 5-edge-connectivity of a closure, and absence of non-terminal-tree
2-edge-cuts do not by themselves display such a barrier.  The fixed
dodecahedral side has none, as witnessed by (1).

## Reproduction

The pure-standard-library verifier constructs only this pole, enumerates its
complete perfect-matching family, checks every proper 1- and 2-edge cut, and
streamingly verifies the cyclic edge connectivity of the fixed 20-vertex
closure:

```text
python3 -u check_dodecahedron_face_complement_fixed_singleton_edge.py \
  --json result.json
```

Frozen hashes are

```text
42745b6c6c62a5d4078dfcacf9f7f7a019a07be2188abd9aae3622b28fa5b5c4  check_dodecahedron_face_complement_fixed_singleton_edge.py
cc6a72577330f2c3f5a082cafc821a8f556bac8e41c0e4566bd8b5161fc98ce4  dodecahedron_face_complement_fixed_edge_result.json
aff2e6c1047630287aac089d1f15205690c04bdc29287dc8cef6d70bc2b407da  dodecahedron_face_complement_fixed_edge_omen_run.log
```

On Omen, one Python 3.10.12 process finished in 4.48 seconds, used 12,288 kB
peak resident memory, and exited zero with marker

```text
DODECAHEDRON_FACE_COMPLEMENT_NO_STRONG_FIXED_EDGE
```
