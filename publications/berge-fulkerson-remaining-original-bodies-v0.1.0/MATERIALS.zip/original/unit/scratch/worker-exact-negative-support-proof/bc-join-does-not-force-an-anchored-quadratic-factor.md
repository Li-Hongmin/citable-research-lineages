# A pointwise \(BC\)-join does not force an anchored quadratic factor

Fix one saturated \(t=23\) half

\[
H_{23}=r_{23}+B+X,\qquad K_{23}=2\mathbf1-H_{23},
\tag{1}
\]

and suppose the same actual pole contains the pointwise rows

\[
\begin{aligned}
q_{14}+A+C+r_{23}+B+X&=2\mathbf1,\\
q_{25}+r_{34}+B+Y+C+D&=2\mathbf1.
\end{aligned}
\tag{2}
\]

Thus \(K_{23}=q_{14}+A+C\), and the second row is the actual \(BC\)-join.
Assume also that the column is \(S\)-saturated and that no all-terminal,
\(T\)-loop or \(T\)--\(T\) BF row exists.

The pointwise \(BC\)-join still does not force, at the common-trivalent
row-equation level, either projection

\[
\mathcal F_3(K_{23};5)\cap\mathcal G_{H_{23}}(Y),
\qquad
\mathcal F_5(K_{23};3)\cap\mathcal G_{H_{23}}(D)
\tag{3}
\]

to be nonempty. The obstruction is no longer independent-cell
non-reuse: both rows in (2) really share the same occurrences \(B,C\).
After cancellation they supply one quartic trade, but not an anchored
quadratic factor of that trade.

The construction below uses two actual cubic \(K_4\) coordinate components
and genuine one-factors on each. It is therefore a strict common-trivalent
row-level countermodel. It is not the complete perfect-matching family of
one connected cubic five-pole, so the real graph-induced implication remains
open.

## The quartic trade left by the join

Cancelling the pointwise occurrences \(B,C\) in (2) gives

\[
q_{14}+A+r_{23}+X
=q_{25}+r_{34}+Y+D.
\tag{4}
\]

The terminal coordinates balance:

\[
\begin{array}{c|ccccc}
 &1&2&3&4&5\\ \hline
q_{14}+A+r_{23}+X&2&1&2&1&2,\\
q_{25}+r_{34}+Y+D&2&1&2&1&2.
\end{array}
\]

Thus boundary classes do not split (4). A desired rank-one square would be
an additional factorization such as

\[
L+P_3=L'+Y
\quad\text{or}\quad
L+P_5=L'+D,
\qquad L\in\{r_{23},B,X\},
\tag{5}
\]

where

\[
K_{23}=q_{35}+P_3+P_5.
\tag{6}
\]

Equation (4) alone does not contain (5).

## Two genuine cubic coordinates

On a copy of \(K_4\), denote its three pairwise edge-disjoint one-factors by
\(F_0,F_1,F_2\). A matching token is assigned one symbol
\(0,1,2\), meaning that it restricts to the corresponding \(F_i\).
A six-token row double-covers this \(K_4\) exactly when each symbol occurs
twice.

Use two copies of \(K_4\), so every token receives an ordered pair of
symbols. Assign

\[
\begin{array}{c|ccccccccccccc}
M&r_{23}&B&X&q_{14}&A&C&q_{35}&P_3&P_5&q_{25}&r_{34}&Y&D\\ \hline
c_1(M)&0&0&1&1&2&2&2&1&2&0&1&2&1\\
c_2(M)&0&0&1&1&2&2&2&2&1&0&1&1&2.
\end{array}
\tag{7}
\]

The state-\(14\) row in (2) has symbol word

\[
(1,2,2,0,0,1)
\]

in both coordinates. The state-\(35\) row formed from (1) and (6) has
symbol words

\[
(2,1,2,0,0,1),\qquad
(2,2,1,0,0,1),
\]

and the \(BC\)-join row has words

\[
(0,1,0,2,2,1),\qquad
(0,1,0,1,2,2).
\]

Each word contains \(0,1,2\) twice. Hence every displayed equation is an
actual double-cover equation on both common cubic coordinate components.
The occurrences \(B,C\) are literally the same tokens in the two rows of
(2), not merely tokens with the same boundary labels.

For each of the other three states in \(S\), add a carrier triple whose
symbol multiset in each coordinate is

\[
\{1,2,2\}.
\tag{8}
\]

This is exactly the complement of the fixed-half multiset
\(\{0,0,1\}\), so every added state forms a BF row with the same
\(H_{23}\). Carrier Kempe switches may be included by retaining one token
and exchanging the other two within the same load; every resulting triple
still has (8). Thus the hidden cubic coordinates are compatible with the
complete saturated five-state row graph, not just the two rows displayed
above.

## Both anchored squares are blocked

Any pair-sum equality of actual matchings must preserve the multiset of
\(K_4\) one-factor symbols in each coordinate, because
\(F_0,F_1,F_2\) are pairwise edge-disjoint.

In the first coordinate,

\[
c_1(P_3)=1,\qquad c_1(Y)=2,
\]

whereas every fixed-half occurrence \(L\in\{r_{23},B,X\}\) has symbol
\(0\) or \(1\). Therefore the left side of

\[
L+P_3=L'+Y
\]

has symbol multiset contained in \(\{0,1\}\), while the right side contains
the symbol \(2\). No choice of \(L'\) can make the equality hold.

In the second coordinate,

\[
c_2(P_5)=1,\qquad c_2(D)=2,
\]

and again every fixed-half \(L\) has symbol \(0\) or \(1\). Hence

\[
L+P_5=L'+D
\]

is impossible for every \(L,L'\).

Thus the two coordinates independently exclude the two alternatives in
(5), while all fixed-half, saturation and \(BC\)-join row balances remain
valid.

## Incorporating the support assumptions

The model retains only rows with the prescribed \(S\)--\(S\) and
\(S\)--\(T\) boundary types and declares no all-terminal, \(T\)-loop or
\(T\)--\(T\) row. These negative flags do not conflict with (7): they are
boundary-support exclusions, whereas the two \(K_4\) coordinates only add
necessary equal-sum constraints to rows already declared.

Here boundary support is part of the row relation: an undeclared six-token
tuple is not asserted to be a cover. Thus this is a countermodel to
derivations from the displayed row identities together with the negative
support predicates. It is not a binary-incidence claim that the two
\(K_4\) coordinates alone exclude every undeclared six-token sum.
Nevertheless, no argument using only common trivalent row balance,
pointwise \(BC\) reuse, the saturated carrier row graph and those support
predicates can derive (5).

What the model does not provide is a single connected support graph whose
entire graph-induced perfect-matching family is exactly the declared token
pool. That remaining full-closure condition is the only place where the
proposed implication could still be forced.

## Exact additional condition

The quartic trade (4) must admit an **anchored quadratic factorization**
through the state-\(35\) row. Concretely, one needs at least one actual
intermediate matching \(L'\) and one fixed-half occurrence \(L\) satisfying
one equality in (5). By complete closure this is equivalent to one forced
vector

\[
L+P_3-Y
\quad\text{or}\quad
L+P_5-D
\tag{9}
\]

being \(0/1\).

In alternating-component language, (9) says that one fixed occurrence
carries the desired phase on every component of
\(P_3\triangle Y\) or \(P_5\triangle D\). In toric language, the quartic
binomial (4), together with the internal carrier trades connecting states
\(14\) and \(35\), must have a quadratic factor whose one endpoint is
anchored at \(Y\) or \(D\) and whose other endpoint lies in the fixed half.

This factorization is strictly stronger than the existence of (4). It is
also exactly the first-splice projection criterion of Note 093.

## Decision

The actual pointwise \(BC\)-join supplies a genuine rank-four equality but
does not algebraically force a rank-one paired square. The two-\(K_4\)
common-trivalent model proves that all displayed hypotheses short of one
connected graph-induced full-PM closure are compatible with failure of both
projections. Hence the \(BC\)-join is still insufficient at the row level.
The real cubic-pole question is reduced to whether its complete
perfect-matching toric relations necessarily factor (4) through one of the
anchored quadratics (5).
