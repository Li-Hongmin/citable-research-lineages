# A carrier empty intersection has an agreement-region obstruction-tree certificate

Fix one endpoint test from Note 093.  Thus \(K\) is an integral
degree-three half-load carrier, \(H=(L_0,L_1,L_2)\) is its fixed
complementary half, the relevant oriented state is \(ij\), and
\(\widehat P\in\mathcal P_i\) is the prescribed literal endpoint.  The
problem is to certify

\[
\mathcal F_i(K;j)\cap\mathcal G_H(\widehat P)=\varnothing,      \tag{1}
\]

where

\[
\begin{aligned}
\mathcal F_i(K;j)
 &=\{P\in\mathcal P_i:K-P
       \text{ decomposes into the required }Q_{ij}+P_j\},\\
\mathcal G_H(\widehat P)
 &=\{\widehat P\}\cup
   \bigcup_{a=0}^2
   \{P\in\mathcal P_i:
          \operatorname{Sep}(L_a;P,\widehat P)\}.               \tag{2}
\end{aligned}
\]

There is a finite graph-theoretic certificate equivalent to (1).  Its
candidate objects are perfect matchings of three agreement regions.  A
finite edge-branching tree covers them by Tutte barriers or by the three
exact residual failures of Notes 078 and 087.  A single odd cycle, terminal
path, Tutte set, or alternating cocycle is not generally equivalent to
(1); different agreement-region matchings can require different leaves.

## Pointwise form of the separation condition

At an internal vertex \(v\), write \(M(v)\) for the incidence edge object
chosen there by a perfect matching \(M\).  Parallel edge objects remain
distinct.  Then

\[
\boxed{
\operatorname{Sep}(L;P,\widehat P)
\iff
P(v)=\widehat P(v)
\quad\text{whenever }L(v)\ne\widehat P(v).
}                                                               \tag{3}
\]

For the forward implication, if both
\(L(v)\ne\widehat P(v)\) and \(P(v)\ne\widehat P(v)\), then the
edge \(\widehat P(v)\) belongs to \(\widehat P\setminus P\) but not to
\(L\), contradicting the first inclusion in

\[
\operatorname{Sep}(L;P,\widehat P)
\iff
\widehat P\setminus P\subseteq L,
\quad L\cap(P\setminus\widehat P)=\varnothing.                  \tag{4}
\]

Conversely, suppose the right side of (3) holds.  At every vertex where
\(P\) differs from \(\widehat P\), one has
\(L(v)=\widehat P(v)\).  Thus \(L\) contains the entire
\(\widehat P\)-phase and, because it is a matching, avoids the opposite
\(P\)-phase.  This is (4).

Since \(P\) and \(\widehat P\) have the same singleton boundary,
\(P\mathbin\triangle\widehat P\) contains no semiedge and is a disjoint
union of proper even alternating cycles.  Equation (3) is equivalently

\[
P\mathbin\triangle\widehat P
\text{ is a union of proper alternating cycles wholly contained in the
agreement vertices of }L\text{ and }\widehat P.                 \tag{5}
\]

This agreement formulation, rather than the components of
\(L\mathbin\triangle\widehat P\), is essential.  In particular, when
\(L=\widehat P\), every same-boundary perfect matching satisfies (4).

## Agreement-region perfect matchings

Let

\[
F_L=L\cap\widehat P\cap E_{\rm proper}                         \tag{6}
\]

be the set of common proper edge objects and let \(A_L\) be the set of
their endpoints.  Define \(J_L\) to be the proper-edge graph induced by
\(A_L\), retaining parallel edge objects and excluding semiedges.  The
edges of \(F_L\) form one perfect matching of \(J_L\).

For \(M\in\operatorname{PM}(J_L)\), define

\[
P_L(M)=
 \bigl(\widehat P\setminus E(J_L)\bigr)\cup M.                  \tag{7}
\]

Then

\[
\boxed{
\{P\in\mathcal P_i:
   \operatorname{Sep}(L;P,\widehat P)\}
=\{P_L(M):M\in\operatorname{PM}(J_L)\}.
}                                                               \tag{8}
\]

Indeed, a vertex lies in \(A_L\) exactly when the common incidence of
\(L\) and \(\widehat P\) is a proper edge.  Proper common edges do not
cross from \(A_L\) to its complement.  By (3), any differing cycle is
contained in \(A_L\), and its replacement phase gives a perfect matching
of \(J_L\).  Conversely, substituting any perfect matching \(M\) of
\(J_L\) changes \(\widehat P\) only at agreement vertices and therefore
satisfies (3).

Semiedges require no extra case.  The class-\(i\) semiedge of
\(\widehat P\) is fixed in every member of \(\mathcal P_i\); its terminal
vertex is outside \(A_L\).  A terminal vertex in \(A_L\) cannot use its
semiedge in \(M\), because \(J_L\) contains proper edges only.  If
\(L=\widehat P\), then \(A_L\) is the whole proper skeleton after deleting
the class-\(i\) terminal vertex, and (8) recovers the complete singleton
class.  Repeated row occurrences likewise cause no problem: occurrence
labels distinguish positions, while (6) compares their actual edge
objects.

Every family in (8) contains \(\widehat P\), corresponding to
\(M=F_L\).  Hence

\[
\mathcal G_H(\widehat P)
=\bigcup_{a=0}^2
 \{P_{L_a}(M):M\in\operatorname{PM}(J_{L_a})\}.                 \tag{9}
\]

This is the exact finite graph reduction of the fixed-half sign set.

## Residual obstruction attached to one candidate

For \(M\in\operatorname{PM}(J_L)\), put

\[
D_{L,M}=K-P_L(M).                                                 \tag{10}
\]

The incident degree is two at every internal vertex.  By Note 087,

\[
P_L(M)\notin\mathcal F_i(K;j)                                  \tag{11}
\]

if and only if one of the following finite graph witnesses exists.

1. **Support witness.**  An edge \(e\in P_L(M)\) has \(K(e)=0\), so
   \(D_{L,M}(e)=-1\).
2. **Odd residual cycle.**  After nonnegativity holds, the residual copy
   multigraph of \(D_{L,M}\) has a closed component of odd length.
3. **Wrong terminal path.**  After nonnegativity holds, a residual terminal
   path has forced endpoint colour bits \(c_0,c_1\) and proper-copy length
   \(m\) satisfying
   \[
   c_0\mathbin\oplus c_1\not\equiv m+1\pmod2.                  \tag{12}
   \]

If none occurs, alternating the residual components produces the required
\(Q_{ij}\) and \(P_j\).  There is therefore no hidden fourth obstruction.

## Finite obstruction trees

A node of an **agreement-region obstruction tree** for \((K,L,\widehat P)\)
carries two sets \((E^+,E^-)\) of forced and forbidden proper edges of
\(J_L\).  Its candidate matchings are

\[
\operatorname{PM}(J_L;E^+,E^-)=
\{M\in\operatorname{PM}(J_L):E^+\subseteq M,
                               M\cap E^-=\varnothing\}.         \tag{13}
\]

At an internal node choose an undecided edge \(e\).  Its two children add
\(e\) respectively to \(E^+\) and \(E^-\).  Thus every candidate matching
follows exactly one branch.

A leaf is certified in one of two ways.

1. **Tutte leaf.**  The forced edges are not disjoint, or after deleting
   their endpoints and all forbidden edges the remaining graph
   \(J_{L,E^+,E^-}\) has a set \(U\) with
   \[
   o(J_{L,E^+,E^-}-U)>|U|.                                     \tag{14}
   \]
   Then no perfect matching extends that branch.
2. **Residual leaf.**  One support edge, odd residual copy-cycle, or wrong
   terminal copy-path from the preceding section is specified, and the
   membership decisions in \((E^+,E^-)\) force it to occur for every
   matching extending the branch.

The tree is valid when every leaf has one of these certificates.  It is
finite: one may branch on all edges of \(J_L\).  A fully decided branch
either is not a perfect matching, in which case the corresponding reduced
graph has a Tutte barrier, or determines one matching \(M\), in which case
(11) supplies a residual witness whenever (1) holds.

## Obstruction-tree alternative theorem

For each fixed companion \(L_a\), let \(\mathcal T_a\) be an
agreement-region obstruction tree as above.  Then

\[
\boxed{
\mathcal F_i(K;j)\cap\mathcal G_H(\widehat P)=\varnothing
\iff
\text{valid trees }\mathcal T_0,\mathcal T_1,\mathcal T_2
\text{ exist.}
}                                                               \tag{15}
\]

If the three trees exist, every matching in each family (8) ends either at
a branch containing no perfect matching or at a branch with an exact
residual failure.  Equations (9)--(11) then prove (1).

Conversely, assume (1).  For each \(L_a\), branch on all edges of
\(J_{L_a}\).  Attach a Tutte barrier to every branch which cannot extend
to a perfect matching.  Every remaining leaf specifies a matching \(M\),
and (1), (9), and Note 087 supply one of the three residual witnesses.
The resulting finite trees prove the reverse implication.

This is an alternative certificate in the literal sense: its existence is
strictly equivalent to the empty intersection, and every leaf is a finite
graph object.  The tree may be exponentially large.  No polynomial bound
or single-obstruction theorem is claimed.

## Combination across the four Note-093 endpoints

Apply (15) to

\[
\begin{array}{c|c|c|c}
\text{source role}&K&H&\widehat P\\ \hline
P_3\to Y&K_{23}&(r_{23},B,X)&Y\\
P_5\to D&K_{23}&(r_{23},B,X)&D\\
P_1\to A&K_{34}&(r_{34},Y,C)&A\\
P'_3\to X&K_{34}&(r_{34},Y,C)&X.
\end{array}                                                       \tag{16}
\]

All four Note-093 intersections are empty if and only if the resulting
twelve agreement-region trees are valid.  Shared physical edges and the
literal occurrences \(A,B,C,D,X,Y,r_{23},r_{34}\) retain the same labels
in all trees.  Therefore the twelve-tree family is directly composable:
a positive Case-XII proof may seek a contradiction among their labelled
Tutte and residual leaves.

## Exact information which cannot be discarded

The candidate family (8) is not generated by independently flipping the
components of \(L\mathbin\triangle\widehat P\).  The difference cycles of
\(P\) and \(\widehat P\) lie instead in the **agreement** region and can
use arbitrary proper edges of its induced graph.  When
\(L=\widehat P\), this distinction is maximal: the candidate family is the
whole singleton class.

Accordingly, any certificate intended for cross-endpoint use must retain
at least:

1. the occurrence label of the fixed companion \(L_a\);
2. physical edge-object identity, including parallel edges;
3. the agreement graph \(J_{L_a}\) and the actual matching decisions along
   each branch;
4. residual edge-copy identity and oriented terminal roles; and
5. the common literal identities shared by the four endpoint tests.

Keeping only an alternating-cycle parity, an unlabelled Tutte barrier, or
the type of residual failure loses which actual occurrence lies in
\(\mathcal G_H(\widehat P)\) and cannot be combined across the four
endpoints.  The branching data are precisely the extra occurrence
information needed to make the alternative exact.

## Boundary of the result

The theorem supplies a finite, graph-theoretic, cross-endpoint certificate
for one empty intersection and for simultaneous fourfold failure.  It does
not prove that the twelve trees are incompatible with real exact-Case-XII
negative support, and it supplies no real counterexample.

Thus the analytic pulse stops at an exact compression boundary: the
unstructured perfect-matching quantifier in Note 093 can be replaced by
agreement-region matching trees with Tutte/residual leaves, but not by one
unlabelled parity obstruction.  The remaining positive theorem would have
to exclude the simultaneous twelve-tree certificate using the shared
literal and physical-edge labels.
