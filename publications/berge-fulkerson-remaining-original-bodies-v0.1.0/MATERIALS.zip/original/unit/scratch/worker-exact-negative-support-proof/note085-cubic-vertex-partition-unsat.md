# The frozen Note 085 signatures contain no cubic vertex

Let \(c_e\in\{0,1\}^{125}\) be the incidence signature of coordinate \(e\)
in the frozen Note 085 countermodel.  Coordinates \(0,\ldots,4\) are the
five semiedges and coordinates \(5,\ldots,47\) are the 43 proper edges.

Copying one proper coordinate repairs the handshake parity: the resulting
halfedge multiset has

\[
 5+2\cdot 43+2=93=3\cdot31
\]

members.  Nevertheless it cannot be partitioned into cubic vertices.  The
obstruction is already local and is independent of the coordinate selected
for copying.

## Local obstruction

If three halfedges with signatures \(c_i,c_j,c_k\) are incident with one
cubic vertex, every one of the 125 proposed perfect matchings must use
exactly one of them.  Hence necessarily

\[
 c_i+c_j+c_k=\mathbf1                         \tag{1}
\]

coordinatewise over the 125 tokens.  Repeated indices are allowed in (1),
so the test also covers vertices incident with multiple halfedges carrying
the same frozen signature.

For binary signatures, (1) is equivalent to the three 125-bit supports
being pairwise disjoint and having union equal to the full token set.  The
frozen computation checks all

\[
 \binom{48+3-1}{3}=19{,}600
\]

unordered triples with repetition.  None satisfies (1).  Thus the model
has zero legal cubic vertex types.  In particular, it cannot form even one
cubic vertex, and therefore cannot form the requested 31-vertex partition
for any choice of duplicated proper coordinate or any pairing of proper
halfedges.

This proves UNSAT for the exact finite question posed.  An edge-pairing
certificate cannot arise because the preceding vertex condition already
fails.

## Scope

The result concerns only the 125 vectors and 48 signatures frozen in the
Note 085 bundle.  It does not show that every common-binary exact-40 model
fails trivalent realizability, and it does not decide the existence of a
real Case-XII pole.  It sharpens the missing real-pole axiom for this
particular certificate: the failure is not merely lack of full
perfect-matching closure; its coordinate system does not contain a single
trivalent complement triple.

## Reproduction

The verifier reads only the frozen JSON and uses the above exhaustive local
test before presenting the global exact-cover constraints:

```text
python3 -u partition_note085_signatures_into_cubic_vertices.py \
  joint_carrier_common_binary_result.json \
  --timeout-ms 300000 --json result.json
```

The input and frozen artifacts have SHA-256 hashes

```text
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
78c45b70cfef3f524b4798241c416699797cb9c022ed87c8b0b12f41379719bd  partition_note085_signatures_into_cubic_vertices.py
96536c23e3150924349446c381983976b970e6576f986005c56012e3b4c02ec4  note085_cubic_vertex_partition_result.json
ec86d2ebf6d2cb43107714c5cfb25422eb52e88f49d7b1dec47be4ecedc529b6  note085_cubic_vertex_partition_omen_run.log
```

On Omen, one Python 3.10.12 process used 44,544 kB peak resident memory and
finished in 0.07 seconds with exit status zero.  Its terminal marker was

```text
NOTE085_CUBIC_VERTEX_PARTITION_UNSAT
```
