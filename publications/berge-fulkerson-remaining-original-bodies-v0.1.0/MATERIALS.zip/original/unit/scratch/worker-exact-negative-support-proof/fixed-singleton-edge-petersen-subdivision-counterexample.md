# A proper edge outside every terminal-tree cut can be fixed in a singleton class

Let \(H\) be a cubic 5-pole whose five semiedges have distinct incident
vertices \(v_1,\ldots,v_5\).  Write \(\bar H\) for its proper-edge skeleton,
and let \(\mathcal P_i\) be the perfect matchings of the pole whose boundary
is the singleton \(i\).

The proposed implication

\[
 e\in P\in\mathcal P_i,\qquad
 e\text{ outside every terminal-tree proper 2-cut}
 \quad\Longrightarrow\quad
 \exists P'\in\mathcal P_i\ (e\notin P')
\]

is false, even when \(H\) is simple, connected, bridge-free and of girth at
least five, and every proper 2-cut isolates one terminal vertex.

## Singleton boundary as a vertex-deleted matching problem

There is a direct bijection

\[
 \mathcal P_i\longleftrightarrow
 \operatorname{PM}(\bar H-v_i).                 \tag{1}
\]

Indeed, deleting the semiedge \(i\) from a member of \(\mathcal P_i\) and
then deleting its already covered incident vertex \(v_i\) leaves a perfect
matching of \(\bar H-v_i\).  Conversely, a perfect matching of
\(\bar H-v_i\) covers every other terminal vertex by a proper edge; adding
semiedge \(i\) therefore gives a pole perfect matching with singleton
boundary \(i\).

Put \(G=\bar H-v_i\), and suppose that a perfect matching \(P\) of \(G\)
contains a proper edge \(e\).  Then

\[
 e\text{ belongs to every perfect matching of }G
 \quad\Longleftrightarrow\quad
 G-e\text{ has no perfect matching}.            \tag{2}
\]

This is also equivalent to saying that \(e\) lies on no \(P\)-alternating
cycle.

The exact Tutte form of the obstruction is useful.  Since \(P-e\) misses
only the ends of \(e\), a nonfactorizable \(G-e\) has deficiency exactly
two.  Hence there is \(S\subseteq V(G)\) such that

\[
 o(G-e-S)=|S|+2.                                \tag{3}
\]

Because \(G\) itself has a perfect matching, Tutte's theorem gives
\(o(G-S)\le |S|\).  Adding the single edge \(e\) can reduce the number of
odd components by at most two, so equality is forced:

\[
 o(G-S)=|S|.                                    \tag{4}
\]

Moreover, the two ends of \(e\) lie in two distinct odd components of
\(G-e-S\), and \(e\) merges precisely those components into one even
component of \(G-S\).  Conversely, (3) alone violates Tutte for \(G-e\),
so this is an exact barrier characterization of a fixed edge.

## The Petersen-subdivision pole

Define a ten-vertex cubic graph \(J\) on

\[
 \{0,1,2,3,4,5,a,b,u,w\}
\]

with edges

\[
\begin{split}
 E(J)=\{&0a,a3,1b,b4,0u,u4,1w,w3,25,05,15,23,24,ab,uw\}.
\end{split}                                     \tag{5}
\]

It consists of the disjoint 5-cycles

\[
 a-b-1-w-3-a,\qquad 0-u-4-2-5-0
\]

joined by the matching

\[
 a0,\quad b4,\quad 15,\quad wu,\quad 32.
\]

The matching has the usual step-two order, so \(J\) is the Petersen graph.
In particular, it is simple, 3-edge-connected and has girth five.

Form \(\bar H\) by subdividing the following five edges once:

\[
 05,\quad 15,\quad 23,\quad 24,\quad uw,
\]

and call the new vertices respectively

\[
 t_1,t_2,t_3,t_4,v.
\]

Attach one semiedge to each of these five vertices.  This gives a simple
15-vertex cubic 5-pole \(H\), with terminal vertices
\(t_1,t_2,t_3,t_4,v\).  Subdivision preserves connectedness,
bridgelessness and the girth lower bound.

Every proper 2-edge-cut of \(\bar H\) consists of the two halves of one
subdivided Petersen edge and isolates its unique subdivision vertex.  To
see this, suppress the five degree-two terminal vertices.  Any other
2-edge-cut would map to a cut of at most two edges in the 3-edge-connected
graph \(J\).  Thus all proper 2-cuts are precisely the allowed one-vertex
terminal-tree cuts.

Take \(i\) to be the semiedge at \(v\), and take

\[
 e=ab.
\]

The edge \(e\) is an unsubdivided Petersen edge, so it belongs to no proper
2-cut of \(\bar H\).  Nevertheless it is fixed in \(\mathcal P_i\).

Indeed, after deleting \(v\), the following seven edges form a perfect
matching of \(G=\bar H-v\):

\[
 ab,\quad 0u,\quad 3w,\quad 5t_1,\quad 1t_2,
 \quad 2t_3,\quad 4t_4.                         \tag{6}
\]

Adding the semiedge at \(v\) gives a member of \(\mathcal P_i\) containing
\(e\).

On the other hand, in \(G-e\) the eight vertices

\[
 D=\{a,b,u,w,t_1,t_2,t_3,t_4\}
\]

form an independent set, and all their neighbours lie in

\[
 S=\{0,1,2,3,4,5\}.
\]

A perfect matching would have to match all eight vertices of \(D\) to
distinct vertices of the six-element set \(S\), which is impossible.
Equivalently,

\[
 o(G-e-S)=8=|S|+2,                              \tag{7}
\]

so (7) is the explicit deficiency-two Tutte barrier.  By (1)--(2), every
matching in \(\mathcal P_i\) contains \(ab\).

## Translation back to the cut structure

The general barrier calculation also explains why excluding only cuts that
contain \(e\) cannot work.  Let the \(|S|+2\) odd components in (3) be
\(Q_1,\ldots,Q_{|S|+2}\).  Their total proper boundary in \(H\) satisfies

\[
 \sum_j |\delta_{\bar H}(Q_j)|\le 3|S|+4:       \tag{8}
\]

there are at most \(3|S|\) incidences through \(S\), two incidences of
\(e\), and the two proper edges incident with the deleted terminal \(v_i\).
If \(H\) is bridge-free, every summand is at least two.  Since all summands
other than those equal to two are at least three, (8) forces at least two
of the odd components to be shores of proper 2-cuts.  Under the precise
Case-XII cut classification, such an odd shore is either the one-vertex
terminal tree itself or the complement of an allowed two-vertex terminal
tree.  At most one of the pairwise disjoint \(Q_j\) can be a large
complement shore, so at least one is a singleton terminal tree.  The count
does not force either component joined by \(e\) to be small.  In the
explicit example, the four vertices \(t_1,t_2,t_3,t_4\) are boundary-two
singleton components, while the two components joined by \(e\) are
\(a\) and \(b\).

Thus the sharp surviving criterion is not the location of \(e\) in the
proper-cut structure.  For a fixed \(P\in\mathcal P_i\) containing \(e\),
the following are equivalent:

1. some \(P'\in\mathcal P_i\) avoids \(e\);
2. \(\bar H-v_i-e\) has a perfect matching;
3. no set \(S\) satisfies the deficiency-two barrier (3);
4. \(e\) lies on a \(P\)-alternating cycle in \(\bar H-v_i\).

Any positive Case-XII argument must exclude this global barrier or force the
alternating cycle.  Bridge-freeness, girth five, the exact allowed form of
proper 2-cuts, and the assumption that \(e\) itself lies in none of those
cuts do not suffice.
