# Four projection failures are sixteen restricted residual obstructions

## Statement and scope

Let (G) be one loopless cubic five-pole and let (mathcal P(G)) be its
complete graph-induced perfect-matching family.  Fix the two anchored carrier
loads of Note 093,

\[
 K_{23}=2\mathbf1-r_{23}-B-X,
 \qquad
 K_{34}=2\mathbf1-r_{34}-Y-C,
\]

and all four endpoint data

\[
\begin{array}{c|c|c|c}
K&H&\widehat P&(i,j)\\ \hline
K_{23}&(r_{23},B,X)&Y&(3,5)\\
K_{23}&(r_{23},B,X)&D&(5,3)\\
K_{34}&(r_{34},Y,C)&A&(1,3)\\
K_{34}&(r_{34},Y,C)&X&(3,1).
\end{array}                                                     \tag{1}
\]

Here (i) is the singleton class being replaced and (j) is the other
singleton colour in the carrier.  The four projection tests of Note 093 can
be stripped of every general perfect-matching-closure quantifier.  They are
exactly sixteen finite restricted-residual selector problems, four companion
choices for each row of (1).

This reduction does not prove that one selector succeeds under exact
Case-XII support.  It identifies the common-incidence proposition still
missing from such a proof.

## Restricted flip families

For one row (eta=(K,H,\widehat P;i,j)) of (1), write
(H=(L_0,L_1,L_2)).  For (a=0,1,2), let

\[
 U_a=V_{\mathrm{pr}=}(L_a,\widehat P)
\]

be the vertices at which (L_a) and (widehat P) choose the same proper
incidence.  Define

\[
 \mathcal C_a(\widehat P)=
 \{P\in\mathcal P_i(G):
 P=\widehat P\text{ outside }U_a,
 \ P\triangle\widehat P\text{ is a union of proper alternating cycles in }
 G[U_a]\}.                                                     \tag{2}
\]

Also put

\[
 \mathcal C_{\mathrm{ent}}(\widehat P)=\{\widehat P\}.        \tag{3}
\]

Note 093's agreement-region lemma gives, without loss in either direction,

\[
 \mathcal G_H(\widehat P)
 =\bigcup_{a\in\{\mathrm{ent},0,1,2\}}
   \mathcal C_a(\widehat P).                                  \tag{4}
\]

The families in (2) are concrete perfect-matching families of induced
agreement cores with the matching outside the core fixed pointwise.  Thus
they already include every permitted component flip; no additional Kempe or
ordinary exchange closure enlarges (4).

## Exact residual criterion

For (P\in\mathcal C_a(\widehat P)), put

\[
 D_P=K-\chi_P.                                                  \tag{5}
\]

Call (P) **carrier-good** for ((K;i,j)) when:

1. (D_P(e)\in\{0,1,2\}) for every proper edge and semiedge;
2. every closed component of the degree-two copy-multigraph represented by
   (D_P) has even length;
3. every terminal path has the endpoint-colour parity prescribed by a
   triple-boundary matching of state (ij) and a singleton matching of
   class (j).

The proof of the residual criterion in Note 078 applies verbatim to the two
prescribed remaining colours.  Alternately colouring the copy-components
shows

\[
 P\text{ is carrier-good}
 \iff
 D_P=\chi_Q+\chi_{P_j}
\]

for actual perfect matchings (Q,P_j) of the required boundaries.  Hence

\[
 \mathcal F_i(K;j)
 =\{P\in\mathcal P_i(G):P\text{ is carrier-good for }(K;i,j)\}. \tag{6}
\]

Combining (4) and (6) gives the exact form of one projection test:

\[
\boxed{
 \mathcal F_i(K;j)\cap\mathcal G_H(\widehat P)\ne\varnothing
 \iff
 \exists a\in\{\mathrm{ent},0,1,2\}\ 
 \exists P\in\mathcal C_a(\widehat P):
 P\text{ is carrier-good}.}
                                                                  \tag{7}
\]

Consequently all four Note-093 tests fail if and only if every one of the
sixteen families in (7) is covered by the following three obstructions:

- an edge with (P(e)=1>K(e));
- an odd closed component of (D_P);
- a terminal path of (D_P) with the wrong prescribed parity.             \tag{8}

Equation (8) is the thinnest common-incidence statement left by the four
projection failures.  It contains no abstract support, free witness, or
unquantified closure variable.

## Why exchange closure does not contradict (8)

For a fixed singleton boundary, the complete matching exchange graph is
connected: two perfect matchings differ by proper alternating cycles.
This does not imply (7).  The restricted family
(mathcal C_a(\widehat P)) permits only cycles contained in one specified
agreement core.  The carrier projection permits precisely those matchings
whose *matching-dependent* residual (5) passes all three tests above.
Neither family is closed under an arbitrary edge of the full exchange graph.

In particular, an exchange path from (widehat P) to an independently
known member of (mathcal F_i(K;j)) may leave the agreement core before its
residual becomes colourable.  Connectedness supplies no intermediate vertex
in the intersection.  The same defect remains after taking every partial
flip cube: the cube controls which phases of (P\triangle\widehat P) are
available, whereas (8) depends on how those phases alter the components of
(K-P).

## Why a direct Tutte or Farkas argument stops

For each fixed (a), the members of (mathcal C_a(\widehat P)) are
perfect matchings of an induced agreement core with fixed exterior data.
That family is nonempty because it contains the restriction of
(widehat P).  Thus an ordinary Tutte barrier for absence of a perfect
matching in the core cannot prove (7).

The missing condition is imposed after choosing that perfect matching:
closed residual components must be even and terminal paths must have the
right phase.  The support and component decomposition of (K-P) change with
(P).  These parity requirements are not consequences of the vertex and
odd-cut inequalities for (P), and a linear Farkas separation of the
matching polytope sees neither the parity of a newly formed residual cycle
nor which terminals it connects.  A successful barrier proof would
therefore need a new *joint* theorem for a perfect matching of the agreement
core and an alternating two-colouring of its complementary residual; it
cannot be an ordinary Tutte barrier for either object separately.

## Exact contribution of no-(A) and no-(TT)

For the four singleton anchors associated with one endpoint, no-(A) gives
the Note-084 cube condition

\[
 \forall I\quad P^I\cap D_2\ne\varnothing.                     \tag{9}
\]

The witnessing edge may depend on the cube vertex (I).  Equation (9)
does not say that one restricted (P^I) makes (K-P^I) nonnegative, and it
does not constrain the parity or terminal pairing of that residual.

No-(TT) acts only after a residual decomposition exists: it forbids the
decomposition when its two boundary states are both in (T), or forces an
allowed orientation in the common-residual situation of Note 094.  It
cannot create a decomposition when every candidate in (7) has one of the
obstructions (8).  The forty positive support statements independently
supply nonempty carrier projections, but they do not place one of their
actual singleton identities in a restricted family (2).

Thus the available hypotheses have the incompatible quantifier forms

\[
 \forall I\ \exists e_I\quad\text{and}\quad
 \forall\text{ positive cells }c\ \exists R_c,
\]

whereas (7) requires one common actual matching (P), one agreement core,
and one carrier residual simultaneously.

## Decision boundary

The target implication

\[
 \text{complete forty positive types}+	ext{no-}A+	ext{no-}TT
 \Longrightarrow
 \text{one of the four projections is nonempty}
\]

remains undecided for a real cubic five-pole.  No cited real graph satisfies
the antecedent and all four failures: Note 102 escapes through (A), while
the selected systems of Notes 101--102 do not impose exact negative support
on their complete closure.

The exact remaining proposition is the **restricted residual selector
property**:

> Under the common full-PM incidence and exact Case-XII negative support,
> the sixteen restricted families in (7) cannot all be covered by the three
> matching-dependent residual obstructions in (8).

This is strictly thinner than the original carrier statement: carrier
colourings, closure membership and paired-splice algebra have been removed,
leaving only one agreement-core perfect matching coupled to one degree-two
residual parity system.  Proving this selector property proves a first
Note-082 entry.  Refuting it in one real exact-Case-XII pole refutes the
four-projection claim.  Existing no-(A)/no-(TT), exchange-connectivity,
Tutte and linear-separation information does not decide it.
