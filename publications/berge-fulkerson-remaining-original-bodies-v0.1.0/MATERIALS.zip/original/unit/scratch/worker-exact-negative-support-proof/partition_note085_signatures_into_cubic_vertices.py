#!/usr/bin/env python3
"""Test whether the frozen Note-085 columns admit one cubic vertex partition.

Coordinates 0,...,4 are semiedges.  Every other coordinate contributes two
halfedges, except for exactly one chosen proper coordinate, which is copied
and therefore contributes four.  A vertex is a triple of halfedges whose
125-bit signatures sum pointwise to one.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from itertools import combinations_with_replacement
from pathlib import Path

from z3 import If, Int, Solver, Sum, sat, unknown


SEMIEDGE_COUNT = 5


def zsum(terms):
    terms = list(terms)
    return Sum(*terms) if terms else 0


def load_columns(path):
    payload = json.loads(path.read_text())
    vectors = payload["vectors"]
    token_names = tuple(sorted(vectors))
    coordinate_count = payload["coordinates"]
    assert coordinate_count == 48
    assert len(token_names) == payload["tokens"] == 125
    assert payload["coordinate_names"][:5] == [
        "terminal:1", "terminal:2", "terminal:3", "terminal:4", "terminal:5"
    ]
    assert all(len(vectors[token]) == coordinate_count for token in token_names)

    columns = []
    for coordinate in range(coordinate_count):
        mask = 0
        for token_index, token in enumerate(token_names):
            if vectors[token][coordinate] == "1":
                mask |= 1 << token_index
            else:
                assert vectors[token][coordinate] == "0"
        columns.append(mask)
    return payload, token_names, tuple(columns)


def legal_vertex_types(columns, token_count):
    all_tokens = (1 << token_count) - 1
    legal = []
    for triple in combinations_with_replacement(range(len(columns)), 3):
        a, b, c = map(columns.__getitem__, triple)
        if (a & b) or (a & c) or (b & c):
            continue
        if (a | b | c) == all_tokens:
            legal.append(triple)
    return tuple(legal)


def solve_partition(columns, legal, timeout_ms):
    coordinate_count = len(columns)
    counts = [Int(f"vertex_type_{index}") for index in range(len(legal))]
    duplicated = [Int(f"duplicate_{coordinate}")
                  for coordinate in range(SEMIEDGE_COUNT, coordinate_count)]
    solver = Solver()
    solver.set(timeout=timeout_ms)
    for value in counts:
        solver.add(value >= 0)
    for value in duplicated:
        solver.add(value >= 0, value <= 1)
    solver.add(zsum(duplicated) == 1)

    incidence = [[] for _ in range(coordinate_count)]
    for type_index, triple in enumerate(legal):
        for coordinate, multiplicity in Counter(triple).items():
            incidence[coordinate].append(multiplicity * counts[type_index])
    for coordinate in range(coordinate_count):
        if coordinate < SEMIEDGE_COUNT:
            demand = 1
        else:
            demand = 2 + 2 * duplicated[coordinate - SEMIEDGE_COUNT]
        solver.add(zsum(incidence[coordinate]) == demand)
    solver.add(zsum(counts) == 31)

    status = solver.check()
    if status == unknown:
        return "unknown", solver.reason_unknown(), None
    if status != sat:
        return "unsat", None, None
    model = solver.model()
    duplicate_coordinate = next(
        coordinate for coordinate in range(SEMIEDGE_COUNT, coordinate_count)
        if model.eval(duplicated[coordinate - SEMIEDGE_COUNT]).as_long() == 1
    )
    selected = []
    for type_index, triple in enumerate(legal):
        multiplicity = model.eval(counts[type_index]).as_long()
        selected.extend([triple] * multiplicity)
    assert len(selected) == 31
    return "sat", None, (duplicate_coordinate, tuple(selected))


def expand_certificate(columns, duplicate_coordinate, selected, token_count):
    demand = [1 if c < SEMIEDGE_COUNT else 2 for c in range(len(columns))]
    demand[duplicate_coordinate] += 2
    used = [0] * len(columns)
    vertices = []
    halfedge_vertex = {}
    for vertex, triple in enumerate(selected):
        expanded = []
        for coordinate in triple:
            copy = used[coordinate]
            used[coordinate] += 1
            halfedge = (coordinate, copy)
            assert halfedge not in halfedge_vertex
            halfedge_vertex[halfedge] = vertex
            expanded.append(halfedge)
        vertices.append(tuple(expanded))
    assert used == demand

    edge_pairing = {}
    for coordinate in range(SEMIEDGE_COUNT, len(columns)):
        copies = list(range(demand[coordinate]))
        if coordinate != duplicate_coordinate:
            pairings = [((copies[0], copies[1]),)]
        else:
            a, b, c, d = copies
            pairings = [
                ((a, b), (c, d)),
                ((a, c), (b, d)),
                ((a, d), (b, c)),
            ]
        chosen = next(
            pairing for pairing in pairings
            if all(halfedge_vertex[(coordinate, x)]
                   != halfedge_vertex[(coordinate, y)] for x, y in pairing)
        )
        edge_pairing[coordinate] = chosen

    all_tokens = (1 << token_count) - 1
    for triple in selected:
        a, b, c = map(columns.__getitem__, triple)
        assert not (a & b or a & c or b & c)
        assert (a | b | c) == all_tokens

    token_edges = []
    for token_index in range(token_count):
        matching = []
        for coordinate in range(len(columns)):
            if not ((columns[coordinate] >> token_index) & 1):
                continue
            if coordinate < SEMIEDGE_COUNT:
                matching.append(("semi", coordinate))
            else:
                for edge_index in range(len(edge_pairing[coordinate])):
                    matching.append(("proper", coordinate, edge_index))
        covered = [0] * len(vertices)
        for edge in matching:
            if edge[0] == "semi":
                halfedges = ((edge[1], 0),)
            else:
                coordinate, edge_index = edge[1], edge[2]
                x, y = edge_pairing[coordinate][edge_index]
                halfedges = ((coordinate, x), (coordinate, y))
            for halfedge in halfedges:
                covered[halfedge_vertex[halfedge]] += 1
        assert covered == [1] * len(vertices)
        token_edges.append(matching)

    adjacency = [set() for _ in vertices]
    for coordinate, pairing in edge_pairing.items():
        for x, y in pairing:
            u = halfedge_vertex[(coordinate, x)]
            v = halfedge_vertex[(coordinate, y)]
            adjacency[u].add(v)
            adjacency[v].add(u)
    seen = set()
    components = []
    for start in range(len(vertices)):
        if start in seen:
            continue
        component = []
        queue = deque([start])
        seen.add(start)
        while queue:
            vertex = queue.popleft()
            component.append(vertex)
            for neighbour in adjacency[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        components.append(tuple(sorted(component)))

    terminal_vertices = [halfedge_vertex[(coordinate, 0)]
                         for coordinate in range(SEMIEDGE_COUNT)]
    return {
        "duplicate_coordinate": duplicate_coordinate,
        "vertices": [
            [[coordinate, copy] for coordinate, copy in triple]
            for triple in vertices
        ],
        "edge_pairing": {
            str(coordinate): [[[coordinate, x], [coordinate, y]] for x, y in pairing]
            for coordinate, pairing in edge_pairing.items()
        },
        "terminal_vertices": terminal_vertices,
        "connected_components": [list(component) for component in components],
        "token_edge_counts": [len(matching) for matching in token_edges],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    payload, token_names, columns = load_columns(args.input_json)
    legal = legal_vertex_types(columns, len(token_names))
    status, reason, solution = solve_partition(columns, legal, args.timeout_ms)
    result = {
        "status": status,
        "source_status": payload["status"],
        "tokens": len(token_names),
        "coordinates": len(columns),
        "semiedges": SEMIEDGE_COUNT,
        "proper_coordinates_before_duplication": len(columns) - SEMIEDGE_COUNT,
        "legal_vertex_types": len(legal),
        "solver_reason_unknown": reason,
    }
    if solution is not None:
        duplicate_coordinate, selected = solution
        result.update(expand_certificate(
            columns, duplicate_coordinate, selected, len(token_names)
        ))
        result["perfect_matchings_verified"] = len(token_names)
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key not in ("vertices", "edge_pairing", "token_edge_counts")}
    print(json.dumps(compact, indent=2, sort_keys=True))
    if status == "sat":
        print("NOTE085_CUBIC_VERTEX_PARTITION_SAT")
    elif status == "unsat":
        print("NOTE085_CUBIC_VERTEX_PARTITION_UNSAT")
    else:
        print("NOTE085_CUBIC_VERTEX_PARTITION_UNKNOWN")


if __name__ == "__main__":
    main()
