# Exact pairing CEGAR remains undecided after 3,482 A witnesses

## Fixed pairing space

Keep the sixty-seven local stars and five terminal incidences of Note 102
pointwise fixed.  A proper stub may only be paired with another stub having
the same 22-bit selected-family incidence column, and loops are forbidden.
The eighty proper block classes have stub multiplicities

\[
2^{67},\qquad 4^9,\qquad 6^3,\qquad 8^1.
\]

Here the exponents count block classes, not numerical powers.  Since every
block occurs at most once at a vertex, all within-block stub pairs join
different vertices.  The exact number of loopless pairings is therefore

\[
(1!!)^{67}(3!!)^{9}(5!!)^{3}(7!!)
=3^9 15^3 105
=6{,}975{,}163{,}125.                             \tag{1}
\]

An outer SAT instance represents this product using 194 potential-pair
variables and one exactly-one pairing equation at every proper stub.  No
connectivity constraint is imposed initially, so an outer UNSAT result
without later connectivity cuts would quantify over all pairings in (1),
not only connected ones.

## Exact A-witness blocking lemma

Fix an A-cover

\[
\mathcal M=(M_0,M_1,M_2,M_3,M_4,M_* )
\]

of one outer pairing.  For every proper stub \(x\), let

\[
\lambda_{\mathcal M}(x)
=\{j:x\text{ is the incidence selected by }M_j\}.
\]

Because the six matchings double-cover every local incidence,
\(\lambda_{\mathcal M}(x)\) is a two-subset of the six occurrence labels.
For another same-column pairing \(\pi\), the fixed vertexwise witness
\(\mathcal M\) remains a graph-induced A-cover if and only if

\[
\lambda_{\mathcal M}(x)=\lambda_{\mathcal M}(y)
\quad\text{for every }\{x,y\}\in\pi.             \tag{2}
\]

Indeed, if (2) holds, each matching selects either both ends or neither end
of every new proper edge.  Its one-incidence condition at every vertex and
its terminal boundary are already fixed by the local stars, so it remains a
perfect matching.  The common two-subset on each paired edge also gives load
two.  Conversely, if some paired stubs have different labels, a matching in
their symmetric difference selects exactly one end of that edge, so this
fixed witness is not graph-induced.

Consequently the exact clause which invalidates \(\mathcal M\) is

\[
\bigvee_{\substack{x,y\text{ in one block}\\
                   \lambda_{\mathcal M}(x)\ne\lambda_{\mathcal M}(y)}}
       \operatorname{pair}_{xy}.                 \tag{3}
\]

Clause (3) is both necessary and sufficient for failure of this particular
witness.  It is not a generic graph no-good and does not discard a pairing
merely because its endpoint list resembles an earlier candidate.

For additional finite checking, if the multiplicities of the distinct
two-subset labels in block \(b\) are \(n_{b,L}\), then the number of all
pairings in (1) preserving this fixed witness is exactly

\[
\prod_b\prod_L (n_{b,L}-1)!!.                    \tag{4}
\]

The result record contains the six literal matchings, every pair-variable ID
in (3), and the value of (4) for each iteration.

## Omen outcome

The bounded run did not decide whether a no-A pairing exists.

- The outer solver produced 3,483 distinct pairing models.
- All 3,483 happened to be connected, so no component-crossing cut was
  added and the outer domain remained all loopless pairings in (1).
- The first 3,482 candidates each had a verified graph-induced A-cover.
  Their exact clauses (3) were added incrementally.
- On candidate 3,483, the inner A query returned
  `unknown(global_deadline)`.  It did not return UNSAT and therefore does not
  certify a no-A graph.
- The outer solver never returned UNSAT.  Hence the clauses do not certify
  that every pairing in (1) contains A.

The 3,482 blocking clauses contain between 56 and 96 potential-pair literals.
Their individual exact survival-set sizes (4) range from 1 to 18,225, have
median 9, and take 21 distinct values.  Thus their union is rigorously known to contain at
least 18,225 pairings; it also contains the 3,482 distinct candidates which
generated the clauses.  The exact cardinality of the overlapping union was
not computed.  In particular, neither 18,225 nor 3,482 may be promoted to a
claim about the number of residual no-A pairings.

The final outer model satisfies all 3,482 accumulated blocking clauses, so
it avoids every previously recorded A witness.  Its own A status remains
unknown solely because the bounded pulse exhausted its internal deadline.
No TT, dependent-fibre, or exact-40-support query was reached.

The median survival set of only nine pairings explains why blindly extending
this CEGAR is not proportionate: its fixed-witness clauses are behaving close
to graph-by-graph exclusion despite the small 194-variable outer formula.
The cheapest next exact discriminator, if a separate pulse is authorized, is
not a longer continuation.  It is one fresh inner-A query on the already
recorded final candidate.  That query received no effective budget here: it
returned `global_deadline` before deciding SAT or UNSAT.  An UNSAT result would
immediately produce a connected loopless no-A pairing; a SAT result would add
only one further low-granularity witness and would be evidence to abandon this
CEGAR representation rather than resume it.

## Scope and reproduction

This is a solver-resource boundary, not a mathematical route closure.  It
provides an exact CEGAR formulation and 3,482 independently checkable
A-cover clauses, but neither a connected no-A pairing nor a universal-A
theorem for the fixed stars.

The only run was performed on `omen` in

```text
[local archival reference]
```

with Python 3.10.12, Z3 5.1.0, one process, a 1-GiB virtual-memory limit, a
220-second internal deadline, and a 240-second outer timeout.  It emitted

```text
NOTE102_ALL_PAIRINGS_UNKNOWN
```

after 217.68 seconds wall time and used 259,200 KiB maximum RSS.  The outer
timeout was not reached and no process remained afterward.

SHA-256 values are

```text
36d07a6c4f62e63ade5e907e418501945be851795ec5087c882774c4ecb2a9e5  cegar_note102_all_same_column_pairings_no_a.py
e582fa2eadb956fd062d4cfa55fe62934837c82cbc253bed33e6cd325687c1f6  check_note101_global_multigraph_closure.py
36ec05b108fcbf43596e648c640fee88ef6624f005577ffb2d76b19c19e73fbf  note101_global_stub_pairing_result.json
0f1b567c34782ef58e0b6de8302ebe98d354d9dab3aea8acf4be84c9cfcf6375  note102_all_same_column_pairings_no_a_result.json
5205901fb02f2018957eaef6051b25a94c57b3edf8a9b43a3bb01108807d1df6  note102_all_same_column_pairings_no_a_omen_run.log
```
