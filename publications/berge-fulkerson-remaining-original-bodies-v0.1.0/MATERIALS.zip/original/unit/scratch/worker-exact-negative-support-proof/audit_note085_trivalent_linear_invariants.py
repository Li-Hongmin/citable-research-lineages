#!/usr/bin/env python3
"""Audit only the additive +1-coordinate trivalentization invariants."""

import json
import sys
from collections import Counter
from itertools import combinations


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: audit_note085_trivalent_linear_invariants.py RESULT.json")
    with open(sys.argv[1], encoding="utf-8") as handle:
        record = json.load(handle)

    vectors = {name: tuple(int(bit) for bit in bits) for name, bits in record["vectors"].items()}
    assert len(vectors) == 125
    assert {len(vector) for vector in vectors.values()} == {48}
    assert record["coordinate_names"][:5] == [f"terminal:{i}" for i in range(1, 6)]

    profiles = Counter()
    new_signature = set()
    failures = []
    valid_tokens = []
    for name, vector in vectors.items():
        boundary_size = sum(vector[:5])
        proper_weight = sum(vector[5:])
        numerator = 31 - boundary_size - 2 * proper_weight
        if numerator % 2:
            failures.append((name, boundary_size, proper_weight, "odd numerator", numerator))
            continue
        new_bit = numerator // 2
        if new_bit not in (0, 1):
            failures.append((name, boundary_size, proper_weight, "new bit", new_bit))
            continue
        profiles[(boundary_size, proper_weight, new_bit)] += 1
        valid_tokens.append((name, boundary_size, proper_weight, new_bit))
        if new_bit:
            new_signature.add(name)

    if failures:
        print(f"valid_profiles={dict(sorted(profiles.items()))}")
        print(f"valid_tokens={valid_tokens}")
        print(f"failure_count={len(failures)}")
        print(f"failures={failures}")
        print("NOTE085_PLUS_ONE_TRIVALENTIZATION_LINEARLY_IMPOSSIBLE")
        return

    signatures = [
        {name for name, vector in vectors.items() if vector[index]}
        for index in range(48)
    ]
    signatures.append(new_signature)
    assert all(signatures)

    halfedges = signatures[:5] + [signature for signature in signatures[5:] for _ in range(2)]
    assert len(halfedges) == 93
    occurrence_counts = {
        name: sum(name in signature for signature in halfedges)
        for name in vectors
    }
    assert set(occurrence_counts.values()) == {31}
    assert sum(len(signature) for signature in halfedges) == 31 * len(vectors)

    terminal_pair_intersections = {
        (i + 1, j + 1): len(signatures[i] & signatures[j])
        for i, j in combinations(range(5), 2)
    }
    assert all(terminal_pair_intersections.values())

    print(f"profiles={dict(sorted(profiles.items()))}")
    print(f"new_signature_size={len(new_signature)}")
    print(f"coordinate_signature_sizes_minmax=({min(map(len, signatures))},{max(map(len, signatures))})")
    print(f"halfedge_copies={len(halfedges)} vertices_if_partitioned={len(halfedges) // 3}")
    print(f"per_token_halfedge_occurrences={set(occurrence_counts.values())}")
    print(f"total_token_slots={sum(len(signature) for signature in halfedges)}")
    print(f"terminal_pair_intersections={terminal_pair_intersections}")
    print("NOTE085_TRIVALENT_LINEAR_INVARIANTS_PASS")


if __name__ == "__main__":
    main()
