#!/usr/bin/env python3
"""Give the last maximum-survival CEGAR candidate a fresh exact A query."""

import json
from pathlib import Path
import time

from check_note101_global_multigraph_closure import FixedMultigraph, a_query


HERE = Path(__file__).resolve().parent
BASE = HERE / "note101_global_stub_pairing_result.json"
CEGAR = HERE / "note102_maximum_survival_pairing_cegar_result.json"
OUTPUT = HERE / "note102_cegar_last_candidate_a_result.json"


def main():
    base = json.loads(BASE.read_text())
    cegar = json.loads(CEGAR.read_text())
    last = cegar["iteration_records"][-1]
    assert last["A_status"] == "unknown" and last["A_feasibility_checks"] == 0
    chosen_ids = set(last["chosen_pair_ids"])
    proper_edges = [
        {"block": item["block"], "column": item["column"], "ends": item["ends"]}
        for item in cegar["potential_pairs"]
        if item["pair_id"] in chosen_ids
    ]
    assert len(proper_edges) == 98
    candidate = dict(base)
    candidate["proper_edges"] = proper_edges
    graph = FixedMultigraph(candidate)
    started = time.monotonic()
    result = a_query(graph, started + 220.0)
    record = {
        "candidate_sha256": last["candidate_sha256"],
        "elapsed_s": time.monotonic() - started,
        "A": result,
        "proper_edges": proper_edges,
    }
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print({"candidate_sha256": last["candidate_sha256"],
           "A_status": result["status"], "elapsed_s": record["elapsed_s"]})
    print("NOTE102_LAST_CANDIDATE_A_DECIDED" if result["status"] != "unknown"
          else "NOTE102_LAST_CANDIDATE_A_UNKNOWN")


if __name__ == "__main__":
    main()
