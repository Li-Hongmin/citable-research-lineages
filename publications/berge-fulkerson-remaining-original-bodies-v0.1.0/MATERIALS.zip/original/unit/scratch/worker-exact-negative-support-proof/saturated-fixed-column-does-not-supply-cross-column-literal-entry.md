# A saturated fixed column does not supply cross-column literal entry

Fix one actual \(t=23\) half

\[
H_{23}=r_{23}+B+X
\]

in a cubic five-pole and put

\[
K_{23}=2\mathbf1-H_{23}.
\tag{1}
\]

Assume that the complete boundary relation of actual three-matching
decompositions of \(K_{23}\) is

\[
\mathcal R(K_{23})=S=\{13,14,24,25,35\},
\tag{2}
\]

and retain all Kempe path and cycle switches between those decompositions.
Let \(Y\in\mathcal P_3\) and \(D\in\mathcal P_5\) be literal matchings from
the repeated-star data. Global all-terminal, \(T\)-loop and \(T\)--\(T\)
BF types are absent.

These assumptions do not, at the matching-identity and component-phase
level, force either of the two first-splice projections

\[
\begin{aligned}
\mathcal F_3(K_{23};5)
  &\cap\mathcal G_{H_{23}}(Y),\\
\mathcal F_5(K_{23};3)
  &\cap\mathcal G_{H_{23}}(D)
\end{aligned}
\tag{3}
\]

to be nonempty. Saturation controls the complete decomposition graph
*inside one fixed carrier*. The desired literals come from another column,
and the hypotheses provide no matching-identity edge from that column into
the carrier graph.

The statement for a real graph-induced complete perfect-matching family
remains undecided. The strict countermodel below is an occurrence- and
component-phase model of the entire fixed column, not a cubic-pole
realization.

## What fixed-half saturation really supplies

For every decomposition

\[
(Q,P_i,P_j)\in\mathcal D_{ij}(K_{23}),
\]

the six occurrences

\[
(r_{23},B,X,Q,P_i,P_j)
\tag{4}
\]

form a BF row. Thus all rows share the *same three pointwise occurrences*
\(r_{23},B,X\), rather than merely the same boundary type.

A Kempe switch in the carrier preserves one colour matching and replaces
the other two. Accordingly two adjacent rows in (4) share four pointwise
occurrences and subtraction produces a genuine pair-sum equality. Hence
the assumptions may give many anchored equality squares and may even make
the five-state carrier row graph connected.

Every endpoint of these squares is nevertheless a matching occurring in a
decomposition of the same load \(K_{23}\). Such squares cannot install
\(Y\) unless

\[
Y\in\mathcal F_3(K_{23};5)
\quad\text{or}\quad
\operatorname{Sep}(L;P_3,Y)
\tag{5}
\]

for some \(P_3\in\mathcal F_3(K_{23};5)\) and
\(L\in\{r_{23},B,X\}\). This is exactly the first intersection in (3).
The analogous alternatives for \(D\) give the second intersection.

Thus complete internal Kempe connectivity does not bridge the missing
cross-column occurrence.

## A strict same-half phase model with both projections empty

Take one occurrence-labelled decomposition of state \(35\),

\[
K_{23}=q_{35}+P_3+P_5.
\tag{6}
\]

Add four more actual decomposition symbols, one for each other state in
\(S\), and close them under the required carrier Kempe switches. Every
resulting BF row is completed by the same literal half \(H_{23}\).
Matching identities retained by a Kempe switch are retained pointwise, so
all internal paired-exchange equations are present.

Choose the state-\(35\) projections to be singleton fibres

\[
\mathcal F_3(K_{23};5)=\{P_3\},
\qquad
\mathcal F_5(K_{23};3)=\{P_5\},
\tag{7}
\]

and take \(Y,D\) to be distinct same-boundary matching symbols outside the
carrier decomposition family. This is compatible with (2): equation (2)
specifies the five boundary states of \(K_{23}\), not every global
class-\(3\) or class-\(5\) matching of the pole.

For \(P_3\triangle Y\), use two proper alternating components. On one
\(Y\)-phase edge let the two row companions be

\[
\{r_{23},B\},
\]

and on a \(Y\)-phase edge of the other component let them be

\[
\{X,q_{35}\}.
\tag{8}
\]

Every such label has size two, exactly as forced by row load two, while
their intersection is empty. Therefore no occurrence in the row (6)
aligns simultaneously on all components of \(P_3\triangle Y\).

For \(P_5\triangle D\), again use two alternating components with
companion labels

\[
\{r_{23},X\},
\qquad
\{B,q_{35}\}.
\tag{9}
\]

Their intersection is also empty. Equations (8)--(9) use the same fixed
occurrences \(r_{23},B,X\) and the same state-\(35\) row; the two failures
are not obtained by treating the five cells as independent witnesses.

To encode the no-all-terminal consequence, give each partial-flip cube a
common anchor edge in the relevant target matching and in its anchor
double-load set. Every cube vertex then hits that double-load set. To encode
no \(T\)-entry, declare the complete carrier relation to be exactly (2);
all partial flips which enter \(K_{23}\) use one of its five allowed
\(S\)-states. Neither condition changes the empty label intersections
(8)--(9).

This supplies a consistent component-label model of:

- one fixed literal half \(H_{23}\);
- the complete five-state decomposition family of \(K_{23}\);
- all internal carrier Kempe switches and their pair-sum identities;
- the known no-\(A\) cube-hitting consequence;
- absence of carrier \(T\)-states; and
- simultaneous failure of both projection tests in (3).

It proves that the listed information has no component-phase implication
forcing (3). It does not assert simultaneous realization by one common
cubic graph.

## The minimum missing cross-column datum

There is no smaller subset of the five internal states which can repair the
logical gap: even the complete family (2) remains internal to \(K_{23}\).
The atomic extra datum is one occurrence-coupled cross-column square.
Precisely, at least one of the following must hold:

\[
\begin{aligned}
&Y\in\mathcal F_3(K_{23};5),\\
&\exists P_3\in\mathcal F_3(K_{23};5),\
  L\in\{r_{23},B,X\}:
  L+P_3=L'+Y
  \quad(L'\text{ an actual perfect matching}),\\
&D\in\mathcal F_5(K_{23};3),\\
&\exists P_5\in\mathcal F_5(K_{23};3),\
  L\in\{r_{23},B,X\}:
  L+P_5=L'+D
  \quad(L'\text{ an actual perfect matching}).
\end{aligned}
\tag{10}
\]

By Note 082, each equality in (10) is equivalent to the relevant
\(\operatorname{Sep}\) condition; by Note 093 their disjunction is exactly
nonemptiness of at least one projection in (3). This condition is
cross-column because it identifies the external literal \(Y\) or \(D\)
with one carrier projection or one fixed-half companion phase.

A stronger but often more usable sufficient hypothesis is a BF row in a
second column which shares four pointwise matching occurrences with one row
of (4) and has \(Y\) or \(D\) in one of its two remaining positions. Row
subtraction then gives the required equality in (10). Merely sharing a
boundary class, or merely having every positive cell, is insufficient.

## Decision

The complete \(S\)-saturated fixed \(t=23\) column and all its internal
Kempe switches do not by themselves force either Note093 endpoint entry.
No-\(A\) and no-\(TT\) close the two forbidden exits of the partial-flip
cubes but do not provide a common current-row companion. The sharp missing
condition is one actual cross-column identity square in (10). Whether the
common cubic full-perfect-matching closure of a real exact-Case-XII pole
must supply such a square remains open.
