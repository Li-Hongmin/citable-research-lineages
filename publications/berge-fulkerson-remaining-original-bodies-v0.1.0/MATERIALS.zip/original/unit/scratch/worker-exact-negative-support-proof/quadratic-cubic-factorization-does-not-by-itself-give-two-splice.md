# One quadratic factorization does not by itself give a dependent two-splice

Consider the four occurrence-labelled pivot rows

\[
\begin{aligned}
R_A&:U_A+A+C+D+X=2\mathbf1,\\
R_B&:U_B+A+B+C+X=2\mathbf1,\\
R_C&:U_C+A+B+C+D=2\mathbf1,\\
R_D&:U_D+B+C+D+Y=2\mathbf1,
\end{aligned}                                                   \tag{1}
\]

where

\[
U_A=q_{13}+r_{45},\quad U_B=q_{14}+r_{23},\quad
U_C=q_{24}+r_{15},\quad U_D=q_{25}+r_{34}.                       \tag{2}
\]

Cancelling the literal occurrences common with the central row gives

\[
\begin{aligned}
U_A+X&=U_C+B, &(C_B)\\
U_B+X&=U_C+D, &(C_D)\\
U_D+Y&=U_C+A. &(C_A)
\end{aligned}                                                    \tag{3}
\]

The singleton boundary classes are

\[
\partial(A,B,C,D,X,Y)=(1,2,4,5,3,3),                            \tag{4}
\]

and the three requested literal quartets are

\[
BDXY,\qquad ACXY,\qquad ABDY.                                   \tag{5}
\]

The question is whether an actual quadratic factorization of at least one
relation in (3), with the required literal identities retained along the
factorization, forces one of the Note-082 sequential or
forced-intermediate fibres for (5) to be nonempty.  It does not follow from
that premise alone.  The missing datum is compatibility of two quadratic
moves inside one target occurrence chain.

## Weakest precise meaning of retaining literal identities

An occurrence-labelled row is a tuple, not an unordered multiset.  A
quadratic move on positions \(i,j\) replaces

\[
(M_i,M_j)\longmapsto(M_i',M_j'),\qquad
M_i+M_j=M_i'+M_j',                                                \tag{6}
\]

and leaves every other occurrence position unchanged.  For a chosen set
\(\Lambda\) of literal anchor occurrences, call a path
**pointwise \(\Lambda\)-preserving** when no move is incident with a
position in \(\Lambda\), and the same actual matching occurrence remains
at each such position at every path vertex.

This is the weakest exact interpretation useful for Note 082.  Merely
requiring each literal matching to occur somewhere in every row is weaker:
two equal or same-boundary tokens may exchange positions, so such setwise
retention does not identify the fixed anchors of the target carrier.

There is a second, logically distinct requirement.  Let an anchored target
datum consist of two fixed literal positions \(L_1,L_2\), two wrong
singleton positions initially occupied by \(P_s,P_t\), and the exact
desired literals \(\widehat P_s,\widehat P_t\).  A path is
**target-aligned** only if

1. \(L_1,L_2\) are pointwise fixed;
2. the two wrong singleton positions are endpoints of the move-incidence
   graph and finish as the exact occurrences
   \(\widehat P_s,\widehat P_t\), not arbitrary same-class matchings;
3. after a first move changes a companion position, any dependent second
   move uses that same updated occurrence position; and
4. after deleting degenerate moves, the two move edges are disjoint or form
   a length-two path, except for the forced-intermediate shape below.

For two moves these conditions are exactly the occurrence part of the
Note-082 classification.  Pair-sum equality supplies the remaining
incidence condition.  In the preparatory branch, the intermediate is not a
free matching: it is forced edgewise by

\[
Z_s=\widehat P_s+\widehat P_t-P_t                              \tag{7}
\]

or the symmetric formula, and the first companion must make

\[
N+P_s-Z_s                                                       \tag{8}
\]

a perfect matching.  Thus pointwise anchor preservation is necessary, but
target alignment is the extra information that actually identifies a
Note-082 fibre.

## Each cubic relation controls only one literal arm

Lifting a factorization of (3) back to (1) pointwise fixes precisely the
literal occurrences cancelled in deriving that relation:

\[
\begin{array}{c|c|c}
\text{relation}&\text{pointwise fixed literals}&
\text{literal arm changed at its endpoints}\\ \hline
C_B&A,C,D&X\leftrightarrow B\\
C_D&A,B,C&X\leftrightarrow D\\
C_A&B,C,D&Y\leftrightarrow A.
\end{array}                                                       \tag{9}
\]

This preservation is stronger than setwise retention, but it still does
not give target alignment.  Every target in (5) requires two specified
wrong singleton positions to be repaired in one row:

\[
\begin{array}{c|c|c}
\text{target}&\text{fixed literal anchors}&\text{required installations}\\
BDXY&B,X&Y,D\\
ACXY&Y,C&A,X\\
ABDY&A,B&Y,D
\end{array}                                                       \tag{10}
\]

The last row additionally needs the literal \(t=12\) reuse identified in
Note 091.  No single row of (9) controls both installations in any row of
(10).  Its quadratic path may update components of \(U_A,U_B,U_C,U_D\),
but those triple occurrences are not thereby identified with the private
companions of a target carrier.  In particular, a companion produced by
the first quadratic step need not be the occurrence used by a second
target splice.

Consequently, even an actual factorization of one cubic relation, lifted
with all its cancelled literals pointwise fixed, supplies at most one arm
substitution.  It does not imply either ordered systems (5)--(7) of
Note 082 or the forced tests (7)--(8) above.

## Minimal formal countermodel

The failure is visible before imposing graph realizability.  Take an
occurrence-rewrite system containing the four rows (1) and the three cubic
equalities (3).  Write \(U_A=q_A+r_A\) and \(U_C=q_C+r_C\).  Add one fresh
occurrence \(Z\) and exactly the two quadratic pair-sum relations

\[
q_A+r_A=q_C+Z,\qquad Z+X=r_C+B.                                 \tag{11}
\]

They give the genuine two-edge quadratic path

\[
(q_A,r_A,X)\longrightarrow(q_C,Z,X)
                    \longrightarrow(q_C,r_C,B),                 \tag{12}
\]

which factors \(C_B\).  Adjoining the same labelled occurrences
\(A,C,D\) to every vertex of (12) makes the lifted path pointwise preserve
all three literals cancelled between \(R_A\) and \(R_C\).

Now give each of the three target-carrier source rows private wrong
singleton and companion occurrences, and include no quadratic pair-sum
edge incident with the two required singleton positions.  Equivalently,
start with the free graded occurrence system and impose only the displayed
cubic relations and the two quadratic generators (11); the private carrier
symbols occur in no degree-two generator.  Then (11)--(12) satisfy the
single-factorization premise, including pointwise literal retention, while
all three target-aligned two-move fibres are empty.

This is a strict logical or toric-rewrite countermodel.  It is not the
perfect-matching incidence semigroup of a common cubic 5-pole, and hence is
not a real exact-Case-XII counterexample.  Its role is narrower: it proves
that a single quadratic factorization and literal retention do not, as a
matter of formal elimination, imply a dependent target fibre.  A theorem
for real poles could still use additional common trivalent-incidence or
full-closure structure not present in this model.

## Exact sufficient strengthening

The premise becomes sufficient only after replacing “one cubic relation
factorizes” by the following target-level condition:

> For at least one anchored target, two actual quadratic pair-sum moves
> embed in one occurrence-labelled six-matching row, fix the target anchor
> occurrences pointwise, cover both wrong singleton positions, end at the
> two specified literal matchings, and reuse the exact updated companion
> occurrence whenever the move graph is a length-two path.  Alternatively,
> the forced intermediate (7) and its forced companion (8) are actual
> perfect matchings.

This is precisely a target-aligned, occurrence-compatible quadratic path
of length at most two.  By the completeness statement of Note 082 it is
equivalent to nonemptiness of the corresponding sequential or
forced-intermediate fibre; it is not a consequence of factorization of one
arm relation in (3).

Therefore the proposed implication is false at the formal
occurrence-rewrite level and undecided at the level of a real common cubic
5-pole.  The sharp remaining interface is not quadratic generation of one
cubic binomial, but compatible reuse of two quadratic moves in one target
carrier.
