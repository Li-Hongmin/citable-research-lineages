# Empty endpoint intersections need a cube-to-row occurrence dichotomy

Consider the two literal-anchored repeated-extension row families and their
four endpoint replacements.  Assume exact Case-XII negative support, all 25
positive \(S\)--\(T\) cells, common cubic incidence, and the full
perfect-matching family.  Suppose that every current-row companion
intersection for all four replacements is empty.

## The two direct forbidden-cover constructions

Fix one endpoint replacement \(P\to\widehat P\), and write

\[
 P\triangle\widehat P=C_1\mathbin{\dot\cup}\cdots
 \mathbin{\dot\cup}C_k.
\]

Full perfect-matching closure contains every partial flip

\[
 P^I=P\triangle\bigtriangleup_{i\in I}C_i.        \tag{1}
\]

Let \(W\) be the sum of the four literal singleton anchors for the target
quartet, and let

\[
 D_2=\{e:W(e)=2\}.                               \tag{2}
\]

There are two direct complement constructions, one for each forbidden
part of exact negative support.

First, if some \(P^I\) avoids \(D_2\), then

\[
 Z=2\mathbf1-W-P^I                               \tag{3}
\]

is an all-terminal perfect matching.  The cubic vertex loads are
\((2,2,1)\), so \(W+P^I+Z=2\mathbf1\) is a forbidden
\(A=(12345)\) cover.  Hence no-\(A\) forces the cube-transversal condition

\[
 P^I\cap D_2\ne\varnothing\qquad\text{for every }I.             \tag{4}
\]

Second, fix the literal anchored \(T\)-half \(B_t\) of the source column
and put

\[
 A_t=2\mathbf1-B_t.                              \tag{5}
\]

Call \(P^I\) *T-entering* if it occurs in a \(T\)-state decomposition of
this same load:

\[
 A_t=P^I+Q_u+P_j,qquad u\in T.                  \tag{6}
\]

Combining (6) with \(B_t\) gives a forbidden \(T\)--\(T\) BF row.
Therefore no \(T\)-loops and no \(T\)--\(T\) types imply

\[
 \text{no member of the cube (1) is T-entering into }A_t.       \tag{7}
\]

Within these two fixed templates, the complements are forced: avoiding
\(D_2\) gives the unique edge-load complement (3), while entering the
fixed carrier in a \(T\)-state gives (6) and hence a \(TT\) row.  This does
not claim that every possible cross-row use of a partial-flip cube has one
of these two forms.

## Why empty row intersections do not activate either construction

For an actual anchored row \(R\) and one of its two endpoint occurrences
\((P,\widehat P)\), define

\[
 \mathsf J_R(P,\widehat P)=
 \{N\in R\setminus\{P\}:
   \operatorname{Sep}(N;P,\widehat P)\}.          \tag{8}
\]

The hypothesis of the present pulse is that (8) is empty for every actual
row in each of the four endpoint families.  This says that no one
*occurrence in one row* carries the complete desired phase of the endpoint
difference.

Condition (4), by contrast, has quantifiers

\[
 \forall I\ \exists e_I\in P^I\cap D_2,          \tag{9}
\]

and (7) says that a particular cube matching does not occur in a particular
three-matching load decomposition.  Neither statement contains a common
row-companion occurrence \(N\).  Full closure makes every \(P^I\) an actual
perfect matching, but it does not put that prescribed matching into a
prescribed BF half-load.  The 25 positive \(S\)--\(T\) cells similarly
provide one row per boundary cell without requiring any selected cube
member to occur in those rows.

Consequently rows from different cells cannot be added and cancelled to
produce (3) or (6) unless one first proves a shared occurrence identity.
The anonymous existential row witnesses supplied by support may use
different singleton matchings in every cell.  Empty local intersections
therefore do not contradict either (4) or (7).

## The minimum falsifiable cross-row obstruction

Let \(\mathcal H\) be the set of all actual endpoint occurrences

\[
 h=(R,P,\widehat P,B_t)
\]

in the two anchored row families: there are four endpoint *roles*, but a
role can have many actual rows and hence many occurrences.  For
\(h\in\mathcal H\), let

\[
\begin{aligned}
 \mathcal C_h&=\{P^I:I\subseteq[k]\},\\
 \mathcal A_h&=\{P^I\in\mathcal C_h:P^I\cap D_{2,h}=\varnothing\},\\
 \mathcal T_h&=\{P^I\in\mathcal C_h:P^I
                    \text{ satisfies (6) for }A_t\},\\
 \mathcal J_h&=\mathsf J_R(P,\widehat P).
\end{aligned}                                                     \tag{10}
\]

The exact obstruction left by the four empty endpoint families for this
three-exit strategy is

\[
\boxed{
 \forall h\in\mathcal H:\qquad
 \mathcal J_h=\varnothing,quad
 \mathcal A_h=\varnothing,quad
 \mathcal T_h=\varnothing.
}                                                               \tag{11}
\]

Each part of (11) is independently checkable in the complete matching and
BF-row family of one real pole.  It is minimal for the proposed strategy:
if \(\mathcal J_h\ne\varnothing\), a legal first paired splice exists; if
\(\mathcal A_h\ne\varnothing\), (3) gives a forbidden \(A\); if
\(\mathcal T_h\ne\varnothing\), (6) gives a forbidden \(TT\).

A positive proof now needs the following real-graph statement.

> **Cube-to-row occurrence dichotomy.**  In a real exact-Case-XII cubic
> five-pole, at least one actual occurrence in the four literal anchored
> endpoint families satisfies
> \[
> \mathcal J_h\ne\varnothing
> \quad\text{or}\quad
> \mathcal A_h\ne\varnothing
> \quad\text{or}\quad
> \mathcal T_h\ne\varnothing.
> \]

Exact negative support would eliminate the last two alternatives and leave
the desired first splice.  The current hypotheses do not prove this
dichotomy, and no real exact-Case-XII pole is available to refute it.
Additional edge hits, independently existing rows, or more partial flips do
not address (11); the missing input must force a prescribed cube matching
to share an actual half-load or a common companion occurrence across rows.
