#!/usr/bin/env python3
"""Decompose Note 102's five new singletons against selected identities.

This is a fixed-certificate calculation: it performs no matching search.
Parallel edges are distinct edge objects throughout.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
BUNDLE = HERE.parents[1] / "computations" / "bundles" / "global-pairing-and-full-closure-boundary"
PAIRING = BUNDLE / "note101_global_stub_pairing_result.json"
CLOSURE = BUNDLE / "note101_global_multigraph_closure_result.json"
OUTPUT = HERE / "note102_a_cover_cycle_decomposition.json"


def boundary(matching, proper_count):
    return tuple(sorted(edge - proper_count for edge in matching if edge >= proper_count))


def cycle_components(edge_ids, edges):
    incident = defaultdict(list)
    for edge in edge_ids:
        left, right = edges[edge]
        incident[left].append(edge)
        incident[right].append(edge)
    assert all(len(items) == 2 for items in incident.values())
    unseen = set(edge_ids)
    answer = []
    while unseen:
        first_edge = min(unseen)
        start = edges[first_edge][0]
        here = start
        previous_edge = None
        vertices = [start]
        component_edges = []
        while True:
            candidates = incident[here]
            edge = candidates[0] if candidates[0] != previous_edge else candidates[1]
            if edge == first_edge and component_edges:
                break
            assert edge in unseen
            unseen.remove(edge)
            component_edges.append(edge)
            left, right = edges[edge]
            there = right if left == here else left
            vertices.append(there)
            previous_edge = edge
            here = there
            if here == start:
                break
        assert vertices[-1] == start
        answer.append({"edges": component_edges, "vertices": vertices})
    return answer


def connected_after_switch(edges, first, second, replacement):
    changed = list(edges)
    changed[first], changed[second] = replacement
    adjacency = defaultdict(list)
    for left, right in changed:
        assert left != right
        adjacency[left].append(right)
        adjacency[right].append(left)
    seen = {0}
    stack = [0]
    while stack:
        here = stack.pop()
        for there in adjacency[here]:
            if there not in seen:
                seen.add(there)
                stack.append(there)
    return len(seen) == max(max(edge) for edge in changed) + 1


def main():
    pairing = json.loads(PAIRING.read_text())
    closure = json.loads(CLOSURE.read_text())
    edges = tuple(tuple(item["ends"]) for item in pairing["proper_edges"])
    columns = tuple(item["column"] for item in pairing["proper_edges"])
    terminal_columns = tuple(pairing["target_terminal_columns"])
    labels = tuple(pairing["labels"])
    label_index = {label: i for i, label in enumerate(labels)}
    proper_count = len(edges)

    def selected(label):
        position = label_index[label]
        chosen = {edge for edge, column in enumerate(columns) if column[position] == "1"}
        chosen.update(
            proper_count + terminal
            for terminal, column in enumerate(terminal_columns)
            if column[position] == "1"
        )
        return frozenset(chosen)

    # Deduplicate the three aliases by their actual edge-object sets.
    selected_by_boundary = defaultdict(dict)
    for label in labels:
        matching = selected(label)
        bdy = boundary(matching, proper_count)
        selected_by_boundary[bdy].setdefault(matching, []).append(label)

    new_singletons = tuple(
        frozenset(item) for item in closure["queries"]["A"]["singletons"]
    )
    report = []
    for terminal, new_matching in enumerate(new_singletons):
        assert boundary(new_matching, proper_count) == (terminal,)
        comparisons = []
        for base, aliases in selected_by_boundary[(terminal,)].items():
            difference = sorted((new_matching ^ base) & set(range(proper_count)))
            components = cycle_components(difference, edges)
            # Along each component, membership alternates between the two PMs.
            for component in components:
                memberships = [edge in new_matching for edge in component["edges"]]
                assert all(memberships[i] != memberships[(i + 1) % len(memberships)]
                           for i in range(len(memberships)))
                component["length"] = len(component["edges"])
                component["columns"] = [columns[edge] for edge in component["edges"]]
                component["new_phase_edges"] = [
                    edge for edge in component["edges"] if edge in new_matching
                ]
            comparisons.append({
                "base_aliases": aliases,
                "symmetric_difference_size": len(difference),
                "components": components,
            })
        comparisons.sort(key=lambda item: (
            item["symmetric_difference_size"], item["base_aliases"]
        ))

        # A matching defined only at the 22-column level must take either all
        # or no edge objects having a given column.  Record every violation.
        by_column = defaultdict(list)
        for edge, column in enumerate(columns):
            by_column[column].append(edge)
        partial_columns = []
        for column, edge_ids in sorted(by_column.items()):
            used = [edge for edge in edge_ids if edge in new_matching]
            if used and len(used) != len(edge_ids):
                partial_columns.append({
                    "column": column,
                    "multiplicity": len(edge_ids),
                    "used": used,
                    "avoided": [edge for edge in edge_ids if edge not in new_matching],
                })

        connected_switch = None
        for partial in partial_columns:
            for used in partial["used"]:
                for avoided in partial["avoided"]:
                    a, b = edges[used]
                    c, d = edges[avoided]
                    assert len({a, b, c, d}) == 4
                    for replacement in (((a, c), (b, d)), ((a, d), (b, c))):
                        if connected_after_switch(edges, used, avoided, replacement):
                            connected_switch = {
                                "column": partial["column"],
                                "used_edge": used,
                                "avoided_edge": avoided,
                                "old_ends": [list(edges[used]), list(edges[avoided])],
                                "new_ends": [list(pair) for pair in replacement],
                            }
                            break
                    if connected_switch is not None:
                        break
                if connected_switch is not None:
                    break
            if connected_switch is not None:
                break
        assert connected_switch is not None
        switched_edges = list(edges)
        switched_edges[connected_switch["used_edge"]] = tuple(connected_switch["new_ends"][0])
        switched_edges[connected_switch["avoided_edge"]] = tuple(connected_switch["new_ends"][1])

        def is_matching_on(edge_list, matching):
            degree = [0] * len(pairing["vertices"])
            for edge in matching:
                if edge < proper_count:
                    left, right = edge_list[edge]
                    degree[left] += 1
                    degree[right] += 1
                else:
                    degree[edge - proper_count] += 1
            return degree == [1] * len(degree)

        assert not is_matching_on(switched_edges, new_matching)
        assert all(
            is_matching_on(switched_edges, selected(label)) for label in labels
        )
        report.append({
            "terminal": terminal,
            "matching": sorted(new_matching),
            "selected_same_boundary_count": len(comparisons),
            "comparisons": comparisons,
            "closest": comparisons[0],
            "partial_columns": partial_columns,
            "connected_column_switch_destroying_this_matching": connected_switch,
        })

    # Column-level statistics for the entire A witness.
    all_terminal = frozenset(closure["queries"]["A"]["all_terminal"])
    witness = (*new_singletons, all_terminal)
    loads = Counter(edge for matching in witness for edge in matching)
    assert all(loads[edge] == 2 for edge in range(proper_count + 5))

    output = {
        "order": len(pairing["vertices"]),
        "proper_edges": proper_count,
        "singletons": report,
        "all_terminal": sorted(all_terminal),
        "all_five_new_singletons_split_some_repeated_column": all(
            item["partial_columns"] for item in report
        ),
    }
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")

    for item in report:
        closest = item["closest"]
        lengths = [component["length"] for component in closest["components"]]
        print(
            f"terminal={item['terminal']} closest={closest['base_aliases']} "
            f"diff={closest['symmetric_difference_size']} cycles={lengths} "
            f"partial_columns={len(item['partial_columns'])}"
        )
    print(f"output={OUTPUT}")
    print("NOTE102_A_COVER_CYCLES_DECOMPOSED")


if __name__ == "__main__":
    main()
