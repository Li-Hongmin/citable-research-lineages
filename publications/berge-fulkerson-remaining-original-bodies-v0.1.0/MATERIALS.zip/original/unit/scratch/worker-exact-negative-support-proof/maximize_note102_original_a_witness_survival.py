#!/usr/bin/env python3
"""Maximize the exact pairing-survival set of an A witness on Note 102 H0.

For one A cover, each proper edge has a two-subset label among the six
matching occurrences.  Within a fixed selected-incidence block, alternative
stub pairings preserve the witness exactly when they pair equal labels.
The resulting block factors are 1, 3, 9, 15, or 105.  Their product is
3^e3 5^e5 7^e7.  Feasible exponent triples are tested in decreasing exact
integer order, so the first SAT model is a globally maximum-survival A
witness; no approximate logarithmic objective is used.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections import Counter, defaultdict
from pathlib import Path

from z3 import And, If, Not, Or, PbEq, Solver, Sum, sat, unknown

from check_note101_global_multigraph_closure import FixedMultigraph, verify_double_cover


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
OUTPUT = HERE / "note102_original_maximum_a_survival_result.json"
TERMINALS = tuple(range(5))


def label_equal(variables, left, right):
    return And(*(variables[slot][left] == variables[slot][right]
                 for slot in range(6)))


def double_factorial_odd(points):
    answer = 1
    for value in range(points - 1, 0, -2):
        answer *= value
    return answer


def emit(record):
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": record["status"],
        "maximum_survival_pairings": record.get("maximum_survival_pairings"),
        "improvement_over_18225": record.get("improvement_over_18225"),
        "feasibility_checks": record.get("feasibility_checks"),
        "elapsed_s": record["elapsed_s"],
    }, sort_keys=True))


def main():
    started = time.monotonic()
    deadline = started + 220.0
    source = json.loads(INPUT.read_text())
    graph = FixedMultigraph(source)
    solver = Solver()
    boundaries = tuple(frozenset((terminal,)) for terminal in TERMINALS) + (
        frozenset(TERMINALS),
    )
    variables = tuple(
        graph.matching_vars(solver, f"A_slot{slot}", boundary)
        for slot, boundary in enumerate(boundaries)
    )
    for edge in range(graph.m):
        solver.add(PbEq([(variables[slot][edge], 1) for slot in range(6)], 2))

    edges_by_block = defaultdict(list)
    for edge, item in enumerate(source["proper_edges"]):
        edges_by_block[item["block"]].append(edge)
    distribution = Counter(len(items) for items in edges_by_block.values())
    assert distribution == Counter({1: 67, 2: 9, 3: 3, 4: 1})

    exp3_terms = []
    exp5_terms = []
    exp7_terms = []
    block_expressions = {}
    for block, edges in sorted(edges_by_block.items()):
        if len(edges) == 1:
            block_expressions[block] = {"edges": edges, "kind": "one"}
            continue
        equality = {
            (i, j): label_equal(variables, edges[i], edges[j])
            for i in range(len(edges)) for j in range(i + 1, len(edges))
        }
        any_equal = Or(*equality.values())
        if len(edges) == 2:
            e3 = If(equality[(0, 1)], 1, 0)
            exp3_terms.append(e3)
            block_expressions[block] = {"edges": edges, "kind": "two"}
            continue
        if len(edges) == 3:
            all_equal = And(equality[(0, 1)], equality[(0, 2)])
            e3 = If(any_equal, 1, 0)
            e5 = If(all_equal, 1, 0)
            exp3_terms.append(e3)
            exp5_terms.append(e5)
            block_expressions[block] = {"edges": edges, "kind": "three"}
            continue
        assert len(edges) == 4
        all_equal = And(equality[(0, 1)], equality[(0, 2)], equality[(0, 3)])
        triple = Or(
            And(equality[(0, 1)], equality[(0, 2)]),
            And(equality[(0, 1)], equality[(0, 3)]),
            And(equality[(0, 2)], equality[(0, 3)]),
            And(equality[(1, 2)], equality[(1, 3)]),
        )
        # Equality of complete six-bit labels is an equivalence relation.
        # A disjoint-pair partition is therefore identified by its two within
        # equalities together with the negation of one cross equality.
        two_pairs = Or(
            And(equality[(0, 1)], equality[(2, 3)], Not(equality[(0, 2)])),
            And(equality[(0, 2)], equality[(1, 3)], Not(equality[(0, 1)])),
            And(equality[(0, 3)], equality[(1, 2)], Not(equality[(0, 1)])),
        )
        e3 = If(two_pairs, 2, If(any_equal, 1, 0))
        e5 = If(triple, 1, 0)
        e7 = If(all_equal, 1, 0)
        exp3_terms.append(e3)
        exp5_terms.append(e5)
        exp7_terms.append(e7)
        block_expressions[block] = {"edges": edges, "kind": "four"}

    exp3 = Sum(*exp3_terms)
    exp5 = Sum(*exp5_terms)
    exp7 = Sum(*exp7_terms)
    triples = sorted(
        [((3 ** e3) * (5 ** e5) * (7 ** e7), e3, e5, e7)
         for e3 in range(15) for e5 in range(5) for e7 in range(2)],
        reverse=True,
    )

    checks = 0
    chosen = None
    reason = None
    for survival, e3, e5, e7 in triples:
        remaining_ms = max(1, int(1000 * (deadline - time.monotonic() - 3.0)))
        if remaining_ms <= 1:
            reason = "global_deadline"
            break
        checks += 1
        solver.push()
        solver.add(exp3 == e3, exp5 == e5, exp7 == e7)
        solver.set(timeout=remaining_ms)
        result = solver.check()
        if result == unknown:
            reason = solver.reason_unknown()
            solver.pop()
            break
        if result == sat:
            chosen = (survival, e3, e5, e7, solver.model())
            solver.pop()
            break
        solver.pop()

    if chosen is None:
        emit({
            "status": "unknown", "reason": reason,
            "feasibility_checks": checks,
            "elapsed_s": time.monotonic() - started,
            "input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        })
        print("NOTE102_MAXIMUM_A_SURVIVAL_UNKNOWN")
        return

    survival, e3, e5, e7, model = chosen
    matchings = tuple(
        graph.extract_matching(model, variables[slot], boundary)
        for slot, boundary in enumerate(boundaries)
    )
    verify_double_cover(matchings, graph.object_count)
    labels = tuple(
        sum(1 << slot for slot, matching in enumerate(matchings) if edge in matching)
        for edge in range(graph.m)
    )
    assert all(label.bit_count() == 2 for label in labels)
    profiles = {}
    verified_product = 1
    for block, edges in sorted(edges_by_block.items()):
        counts = Counter(labels[edge] for edge in edges)
        factor = 1
        for edge_count in counts.values():
            factor *= double_factorial_odd(2 * edge_count)
        verified_product *= factor
        profiles[str(block)] = {
            "edge_objects": edges,
            "label_multiplicities_on_edges": dict(sorted(counts.items())),
            "survival_factor": factor,
        }
    assert verified_product == survival == (3 ** e3) * (5 ** e5) * (7 ** e7)
    emit({
        "status": "optimal_A_witness",
        "input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        "feasibility_checks": checks,
        "maximum_survival_pairings": survival,
        "prime_exponents": {"3": e3, "5": e5, "7": e7},
        "improvement_over_18225": survival / 18_225,
        "one_order_of_magnitude_improvement": survival >= 182_250,
        "matchings": [list(item) for item in matchings],
        "block_profiles": profiles,
        "elapsed_s": time.monotonic() - started,
    })
    print("NOTE102_MAXIMUM_A_SURVIVAL_OPTIMIZED")


if __name__ == "__main__":
    main()
