# Eleven missing cells do not by themselves form an anchored carrier section

Consider the fixed order-nine all-bad carrier with literal rows

\[
\begin{aligned}
R_B&=(q_{24},r_{15},A,B,C,D),\\
R_X&=(q_{13},r_{45},A,X,C,D),
\end{aligned}
\tag{1}
\]

and common carrier

\[
K=2\mathbf1-A-C-D
 =q_{24}+r_{15}+B
 =q_{13}+r_{45}+X.
\tag{2}
\]

Its complete \(K\)-decomposition relation contains six states, has no
carrier \(T\)-loop or \(T\)--\(T\) state, and every actual
\(\mathcal B(K)\times\mathcal X(K)\) choice has bad owner intersection.
The complete pole supporting this carrier already has all fifteen
\(S\)--\(S\) types and fourteen \(S\)--\(T\) cells. The eleven missing
\(S\)--\(T\) cells are

\[
\begin{gathered}
(12)(13),(12)(24),(12)(25),(13)(23),(13)(34),(14)(23),\\
(23)(24),(23)(25),(23)(35),(24)(34),(34)(35).
\end{gathered}
\tag{3}
\]

Adding the existential assertion that every cell in (3) has an actual BF
row does not, by matching-identity and paired-exchange equations alone,
force a safe entry into the fixed carrier. The missing datum is
pointwise occurrence reuse between a new row and (1), not another boundary
type.

This is a strict information-level nonimplication. It is not a real cubic
five-pole counterexample: common cubic vertex incidence and graph-induced
full perfect-matching closure could conceivably force the missing reuse.
No such theorem or real counterexample is obtained from the allowed input.

## The atomic equality needed by a splice

An occurrence-preserving paired exchange between two BF rows fixes four of
their six matching occurrences. Subtracting the two double-cover equations
then gives an equality

\[
P+N=\widehat P+\widehat N.
\tag{4}
\]

Conversely, (4), with all four symbols actual perfect matchings in the
specified occurrence positions, is exactly one paired-exchange square. By
Note 082 it is a legal one-splice precisely when

\[
\widehat N=N+P-\widehat P
\tag{5}
\]

is \(0/1\), equivalently when the required component phases align.
Sequential two-splice requires two such squares sharing the forced updated
occurrence. The forced-intermediate branch requires the corresponding two
forced vectors to be \(0/1\).

A support flag for a cell asserts only

\[
\exists(M_1,\ldots,M_6):
\quad M_1+\cdots+M_6=2\mathbf1
\tag{6}
\]

with the prescribed boundary multiset. It does not identify any \(M_i\)
with an occurrence in (1). Therefore (6) does not imply (4), even when
eleven different boundary labels are asserted.

This is exactly the quantifier mismatch

\[
\forall\text{ cells }c\ \exists R_c
\quad\not\Rightarrow\quad
\exists\text{ one occurrence-coupled section through }R_B,R_X.
\tag{7}
\]

No use of full closure changes the formal implication: closure says that a
forced vector such as (5), once it is \(0/1\), is an actual perfect
matching. It does not make that vector \(0/1\), nor identify a private
witness occurrence with a literal one in (1).

## A free-witness relational countermodel

The failure of implication from identities and paired equalities can be
made formal without inventing graph coordinates. Start with the actual
matching identities and all six \(K\)-decomposition rows of the order-nine
carrier. Retain its all-bad \(\mathcal B(K)\times\mathcal X(K)\) relation.

For each of the eleven cells in (3), and for any still-required
\(S\)--\(S\) cell, adjoin a BF-row symbol

\[
R_c=(M_{c,1},\ldots,M_{c,6})
\]

whose six occurrence identities are new and are not reused in any other
row. Impose the single row relation

\[
\sum_i M_{c,i}=2\mathbf1
\tag{8}
\]

and its prescribed boundary labels. Formally, take the free abelian group
on \(2\mathbf1\) and all matching symbols, modulo precisely the declared
row relations (8). Since each added row owns six private generators, an
equality between sums of at most two matching symbols cannot use its row
relation: a nonzero multiple would put the same nonzero coefficient on all
six private generators. Thus the extension creates no undeclared pair-sum
equality.

Declare no \(A\), \(T\)-loop, or
\(T\)--\(T\) row. Because distinct added rows share no occurrence identity,
no subtraction of two declared rows gives a four-fixed-occurrence square
(4). In particular none changes \(\mathcal B(K)\), \(\mathcal X(K)\), or
their bad cross-intersection.

This relational structure satisfies:

- the literal order-nine carrier rows and their complete six-state carrier
  relation;
- all fifteen \(S\)--\(S\) support flags;
- all twenty-five \(S\)--\(T\) support flags after adding (3);
- absence of \(A\), \(T\)-loops and \(T\)--\(T\) rows;
- every matching-identity equality and paired-exchange equality explicitly
  present in the fixed carrier.

It has no new anchored equality square and hence no Note082 safe carrier
entry. Thus no derivation using only cell nonemptiness, matching names and
paired row subtraction can prove the target implication.

The construction deliberately does not claim that the private row symbols
are the complete perfect-matching family of one cubic graph. Its role is to
locate the exact extra information which a real-pole proof must use.

## Which of the eleven cells can be immediately adjacent?

Only six missing cells share one triple boundary class with one of the two
literal pivot cells:

\[
\begin{array}{c|c}
(15)(24)&(12)(24),(23)(24),(24)(34),\\
(13)(45)&(12)(13),(13)(23),(13)(34).
\end{array}
\tag{9}
\]

The other five cells

\[
(12)(25),(14)(23),(23)(25),(23)(35),(34)(35)
\tag{10}
\]

cannot even participate in a first direct cancellation retaining
\(q_{24}\) or \(q_{13}\). They may matter only through a longer chain of
actual reused matching identities.

Even all six cells in (9) are insufficient as support flags: their
witnesses may use different actual matchings in the common boundary class.
Hence there is no nonempty “minimum carrying subset” of the eleven cells
at the boundary-type level. The empty conclusion persists for every subset,
including the full set.

## The minimum additional condition

The atomic additional hypothesis is an **anchored occurrence square**:
one actual witness in a relevant added cell must reuse four specified
matching occurrences of a current carrier row, so that the two remaining
pairs satisfy (4), with (5) \(0/1\). For a dependent two-splice, two such
squares must share the updated occurrence, or the forced-intermediate
vectors of Note 082 must both be \(0/1\).

Equivalently, in the projection language of Note 093, a first endpoint
entry is exactly

\[
\mathcal F_i(K;j)\cap\mathcal G_H(\widehat P_i)\ne\varnothing.
\tag{11}
\]

For the earlier nonoverload gate, the required fixed-fibre section is
exactly

\[
\exists B'\in\mathcal B(K),\ X'\in\mathcal X(K):
\quad B'\cap X'\cap(A\mathbin\triangle C)=\varnothing.
\tag{12}
\]

Cell support supplies neither (11) nor (12). A genuine proof must therefore
derive an occurrence-coupled square from common cubic vertex incidence and
the graph-induced complete perfect-matching family. Adding more private
positive cells or more uncoupled pair-sum relations cannot do so.

## Decision

The eleven cells do not force the desired entry at the
matching-identity/paired-equality level. They leave the same exact
cube-to-row occurrence gate as Notes 082 and 093. The real cubic-pole
statement remains undecided; the next potentially decisive input is not a
smaller subset of boundary cells but a theorem forcing one anchored
four-occurrence reuse square.
