# Flow linearity produces zeroed A/TT candidates but does not control owner phase

The common-carrier question in
[Note 095](../../notes/095-repeated-star-mixed-quartet-nonoverload-is-a-fibre-avoidance-condition.md)
is not decided by the linear structure of the \(\mathbb F_2^2\)-flow
space.  Two prescribed proper colourings do generate flows with the desired
\(A\) or \(T\)--\(T\) boundary values, but those generated flows may have
zero edges.  The zero set of the canonical \(A\)-boundary flow is exactly
the common singleton-colour class.  Moreover, the flow space of the carrier
does not remember whether a load-one agreement edge has owner phase
\(A,C\), or \(D\).

This leaves the actual cubic-carrier statement undecided.  The exact missing
condition is a nowhere-zero point in an affine boundary-flow class, coupled
to an owner partition realized by the fixed perfect matchings \(A,C,D\).

## Proper colourings as nowhere-zero flows

Put

\[
V=\mathbb F_2^2=\{0,a,b,c\},\qquad c=a+b.
\]

For a cubic copy-multigraph \(K\), a \(V\)-flow is a map
\(\phi:E(K)\to V\) satisfying

\[
\sum_{e\ni v}\phi(e)=0
\]

at every internal vertex.  At a cubic vertex, three nonzero values have
zero sum if and only if they are \(a,b,c\).  Hence nowhere-zero \(V\)-flows
are precisely proper three-edge-colourings, up to the natural action of
\(\operatorname{GL}(V)\cong S_3\).

Let \(f\) be a colouring of type

\[
B=(15\mid24;2)
\]

and \(g\) a colouring of type

\[
X=(13\mid45;3).
\]

Choose the global colour names so that \(c\) is the singleton colour in
both.  Their boundary states are then

\[
\begin{aligned}
f&=(135,234,2),\\
g&=(245,123,3).
\end{aligned}                                                    \tag{1}
\]

At the doubled terminals \(2,3\), the two physical copies may be aligned in
either of the two possible ways.  None of the conclusions below about the
canonical \(A\)-flow depends on that alignment.

## The direct sum and its zero set

The sum

\[
h=f+g                                                        \tag{2}
\]

is a \(V\)-flow, but need not be nowhere zero.  On every edge,

\[
h(e)=0\iff f(e)=g(e).                                        \tag{3}
\]

In particular, terminal \(5\) has colour \(a\) in both states in (1), so
\(h\) already has a zero terminal copy.  Thus the most direct use of
linearity cannot produce another proper colouring.

More generally, \(f+\sigma g\), for
\(\sigma\in\operatorname{GL}(V)\), has zero set

\[
\{e:f(e)=\sigma g(e)\}.                                      \tag{4}
\]

Linearity supplies the flow in (4); it supplies no reason for the displayed
set to be empty.

## A canonical flow with A boundary

For \(r\in\{a,b,c\}\), let

\[
\lambda_r:V\longrightarrow\mathbb F_2
\]

be the nonzero linear functional with kernel \(\{0,r\}\).  Define

\[
F_A=a\,\lambda_c(f)+b\,\lambda_c(g).                          \tag{5}
\]

This is a \(V\)-flow because it is obtained from \(f,g\) by linear maps and
addition.  Its boundary is independent of the alignment at the two doubled
terminals.  The colour \(c\) occurs once at every terminal \(1,\ldots,5\);
the remaining copy at terminal \(2\) has colour \(b\), and the remaining
copy at terminal \(3\) has colour \(a\).  Thus

\[
\partial F_A=(3,2,12345)                                     \tag{6}
\]

in the output-colour order \((a,b,c)\).  This is the \(5+1+1\)
boundary pattern \(A\).

The exact obstruction to \(F_A\) being a proper colouring is

\[
\boxed{
Z(F_A)=
\{e:f(e)=c\}\cap\{e:g(e)=c\}.
}                                                            \tag{7}
\]

Indeed, the two coefficients in (5) are independent, so \(F_A(e)=0\)
exactly when both functionals vanish.  In matching language, (7) is the
literal common part of the singleton-colour matchings \(B\) and \(X\).
Consequently, the two prescribed colourings force an \(A\)-*boundary flow*,
but they do not force an \(A\)-colouring:

\[
F_A\text{ is nowhere zero}
\iff B\cap X=\varnothing.                                    \tag{8}
\]

This is the flow-space form of the familiar common-intersection
obstruction, not a contradiction to negative support.

## The corresponding TT candidates

The same construction isolates every ordered colour cell.  Put

\[
F_{r,s}=a\,\lambda_r(f)+b\,\lambda_s(g)
\qquad(r,s\in\{a,b,c\}).                                     \tag{9}
\]

Then

\[
\boxed{
Z(F_{r,s})=
\{e:f(e)=r\}\cap\{e:g(e)=s\}.
}                                                            \tag{10}
\]

Depending on how the two copies at terminals \(2\) and \(3\) are aligned,
the following members of (9) have \(T\)--\(T\) boundary:

\[
\begin{array}{c|c}
\text{copy alignment at }(2,3)&\text{\(T\)--\(T\) candidates}\\ \hline
(\mathrm{shared},\mathrm{shared})&
F_{c,b}:(12\mid45;2),\quad F_{b,c}:(15\mid34;3)\\
(\mathrm{shared},\mathrm{crossed})&
F_{c,b}:(12\mid45;2)\\
(\mathrm{crossed},\mathrm{shared})&
F_{b,c}:(15\mid34;3)\\
(\mathrm{crossed},\mathrm{crossed})&
F_{b,b}:(15\mid45;5).
\end{array}                                                   \tag{11}
\]

Thus absence of \(T\)--\(T\) again does not contradict flow linearity.  It
only says that each relevant formal candidate in (11) has a nonempty
colour-cell zero set, or that every other flow with the same boundary also
has a zero.

## Affine-coset form of the missing nowhere-zero condition

Let \(\mathcal F(K;V)\) be the full \(V\)-flow space and let
\(\mathcal F_0(K;V)\) be the subspace of flows with zero boundary.  All
flows with the \(A\) boundary in (6) form the affine coset

\[
F_A+\mathcal F_0(K;V).                                       \tag{12}
\]

For an edge copy \(e\), write

\[
H_e=\{\phi\in\mathcal F(K;V):\phi(e)=0\}.
\]

There is an \(A\)-colouring exactly when the coset in (12) contains a point
outside every coordinate kernel:

\[
(F_A+\mathcal F_0(K;V))
\not\subseteq\bigcup_{e\in E(K)}H_e.                          \tag{13}
\]

The assertion that there is no \(A\)-colouring is precisely the reverse
covering relation.  Each \(T\)--\(T\) boundary class has the analogous
affine-coset condition.  A vector-space dimension argument does not prevent
a finite affine subspace from being covered by these coordinate kernels.
One needs graph-specific information which produces a simultaneous
zero-avoiding correction, not merely another linear combination.

## An abstract linear-flow countermodel

The failure of a purely linear implication can be made exact.  Let

\[
E_{\mathrm{grid}}=\{e_{r,s}:r,s\in V\setminus\{0\}\}
\]

and define two nowhere-zero edge vectors by

\[
f(e_{r,s})=r,\qquad g(e_{r,s})=s.                             \tag{14}
\]

Adjoin seven boundary coordinates carrying the values in (1), with any
fixed physical-copy alignment.  On this coordinate set take the full
abstract linear system

\[
\mathcal W=
\{L f+M g:L,M\in\operatorname{End}_{\mathbb F_2}(V)\}.        \tag{15}
\]

It is closed under addition and under every linear change of colour
coordinates.  Its nowhere-zero vectors are exactly

\[
\{L f:L\in\operatorname{GL}(V)\}
\;\cup\;
\{M g:M\in\operatorname{GL}(V)\}.                             \tag{16}
\]

The parametrization in (15) is injective on the grid: if
\(Lr+Ms=0\) for every nonzero \(r,s\), then, with \(r\) fixed, \(Ms\)
is constant on the three nonzero \(s\); linearity forces this constant and
\(M\) to be zero, and then \(L=0\).

To prove (16), now suppose \(L,M\ne0\).  There are nonzero \(r,s\) with
\(Lr=Ms\):

- if both maps are singular, choose nonzero \(r\in\ker L\) and
  \(s\in\ker M\);
- if \(L\) is invertible, choose \(s\) with \(Ms\ne0\) and put
  \(r=L^{-1}Ms\), and similarly with \(L,M\) reversed.

Hence \((Lf+Mg)(e_{r,s})=0\).  If \(M=0\), then \(Lf\) is nowhere zero on
the grid exactly when \(L\) is invertible; the case \(L=0\) is symmetric.
This proves (16).

Global colour changes preserve boundary type, so the only proper
colourings in this abstract system have the original \(B\) or \(X\)
boundary.  In particular, the system contains both prescribed
nowhere-zero vectors but no nowhere-zero \(A\) or \(T\)--\(T\) vector.

The \(3\times3\) joint-colour grid in (14) is compatible with cubic
Kirchhoff equations locally.  On \(K_{3,3}\), index the two vertex classes
by \(i,j\in\mathbb Z/3\mathbb Z\), and colour edge \(ij\) by

\[
f(ij)=i+j,\qquad g(ij)=i+2j
\]

where the displayed expressions are evaluated modulo \(3\), before
identifying the three residues with \(a,b,c\).  Both are proper
three-edge-colourings, and the map \((i,j)\mapsto(f(ij),g(ij))\) is a
bijection onto the nine ordered nonzero colour pairs.  Thus the grid
obstruction is not ruled out merely by the local trivalent flow equation.

The system (15), including its prescribed boundary, is not asserted to be
the full flow space of one cubic five-pole.  It is a countermodel to the
linear-flow implication only.

## Why owner phase is invisible

On a physical edge of carrier load one, the copy is unique.  Therefore
(7) gives

\[
Z(F_A)\cap E_1(K)
=B\cap X\cap E_1(K)
=I(B,X).                                                     \tag{17}
\]

The complement identity

\[
K=2\mathbf1-A-C-D
\]

adds the owner partition

\[
E_1(K)=E_A\mathbin{\dot\cup}E_C\mathbin{\dot\cup}E_D.         \tag{18}
\]

But neither \(K\) nor \(\mathcal F(K;V)\) records which of \(A,C,D\)
owns a load-one edge.  The flow \(F_A\) has value zero on an agreement
edge whether that edge lies in the bad phases \(E_A\cup E_C\) or in the
safe phase \(E_D\).  In the abstract grid, assigning the cell
\(e_{c,c}\) first to \(E_A\) and then to \(E_D\) changes the overload
decision while leaving every flow and every linear relation unchanged.

That last owner assignment is only a formal demonstration of phase
blindness.  For a real carrier, (18) must be induced by three actual
perfect matchings with their prescribed boundary classes.  This is extra
integral incidence information, not a consequence of the carrier flow
space.

## Decision

The simultaneous existence of the \(B\) and \(X\) flows is **not**
forbidden by linear flow-space structure under the assumption that no
\(A\) or \(T\)--\(T\) proper flow exists.  Linearity gives the correct
boundary candidates (5) and (11), but their colour-cell intersections can
be nonempty, making those candidates zeroed flows.

The actual common-cubic-\(K\) statement remains open at two coupled,
nonlinear conditions:

1. **nowhere-zero affine avoidance:** one of the \(A\) or \(T\)--\(T\)
   boundary cosets must escape the union of all zero-coordinate kernels;
2. **owner realizability and phase control:** the partition of load-one
   edges must come from the fixed perfect matchings \(A,C,D\), and the
   singleton agreement cell must be forced away from
   \(E_A\cup E_C\).

Allowing \(f\) and \(g\) to lie in different Kempe components changes none
of this argument.  No reconfiguration connectivity is used.  Consequently,
any positive theorem must add a graphic/global condition linking the
boundary-zero circulation space to the fixed owner partition; flow
linearity, the sum \(f+g\), and its zero set alone do not supply that link.
