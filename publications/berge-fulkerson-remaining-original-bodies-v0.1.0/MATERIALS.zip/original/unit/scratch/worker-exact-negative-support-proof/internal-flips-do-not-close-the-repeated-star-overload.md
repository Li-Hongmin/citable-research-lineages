# Internal alternating-cycle flips do not close the repeated-star overload

Use the repeated-extension identities and targets

\[
 U=\{A,B,C,D,X,Y\},\qquad
 K_1=BDXY,\quad K_2=ACXY,\quad K_3=ABDY.
\]

Assume that a target (K) is overloaded at a proper edge (e).  By the
eight-signature classification of Note 073, exactly three members
(H\subset K) contain (e).

## Flips internal to the overload triple preserve the obstruction

For (P,N\in H), the common edge (e) is absent from
(P\mathbin\triangle N).  Every alternating component of this symmetric
difference is therefore disjoint from (e).  Switching any collection of
such components changes neither matching at (e).  Both resulting
matchings still contain (e).

It follows inductively that every finite sequence of paired switches using
only the three members of (H) leaves all three incidences on (e).  Such
a sequence cannot make (K) edge-nonoverloaded.

The only repeated singleton boundary among the six displayed identities is
that of (X,Y).  A complementary switch of (X,Y) preserves their sum
coordinatewise:

\[
 \chi_X+\chi_Y=\chi_{X'}+\chi_{Y'}.
\]

Hence it preserves the entire load vector of both (BDXY) and (ACXY),
not merely their displayed overload edge.  The cheapest boundary-preserving
closure operation is therefore exactly inert on the first two targets.

## Exact external-companion criterion

Let (K) be any four singleton perfect matchings, let (P\in K), and let

\[
 L_{-P}(f)=\sum_{M\in K\setminus\{P\}}\chi_M(f).
\]

Suppose (N) is another perfect matching and (C) is a proper alternating
cycle component of (P\triangle N).  Then (P'=P\triangle C) has the same
boundary as (P).  Replacing (P) by (P') makes the target
edge-nonoverloaded if and only if

\[
 L_{-P}(f)+\chi_{P'}(f)\le2
 \quad\text{for every edge object }f.              \tag{1}
\]

Equivalently:

1. every old overload edge of (K) lies on (C) in its (P)-phase; and
2. every edge of the incoming (N)-phase (N\cap C) has
   (L_{-P}(f)\le1).

The equivalence is immediate off (C), on the removed (P)-phase, and on
the added (N)-phase.  In the present six-identity setting no edge has
(U)-load above three, so removing the (P)-phase cannot leave a load-three
edge on (C).

There is an equally exact one-cycle test for producing a forbidden
(T)-loop.  Let (Q) be a singleton perfect matching whose boundary forms
a (T)-pair with that of (P).  The switched matching (P') is disjoint
from (Q) precisely when

\[
 P\cap Q\subseteq C
 \quad\text{and}\quad
 Q\cap(N\cap C)=\varnothing.                       \tag{2}
\]

If (2) holds, the unused incidence at each cubic vertex gives the third
perfect matching, and doubling the resulting Tait colouring yields the
forbidden (T)-loop.  Therefore absence of (T)-loops says that every
proper alternating cycle which removes all old (P\)--(Q) intersections
must either leave one outside the cycle or introduce a new one on the
(N)-phase.

## Remaining component-alignment statement

Complete perfect-matching closure guarantees the switched matching once an
alternating component (C) is specified.  It does not guarantee an
external companion (N) and component (C) satisfying (1) or (2).
Accordingly, the unresolved implication is now the following precise
component-alignment statement:

> If the four literal pivot rows occur, all three targets are overloaded,
> and the complete family supports no (T)-loop or (T)--(T) type, then
> for at least one target there are a hitting singleton (P), a perfect
> matching (N) outside its overload triple, and a proper component
> (C\subseteq P\triangle N) satisfying (1), or a finite sequence of such
> aligned replacements whose final target has load at most two.

The Note-019 girth and cut hypotheses have not yet been shown to force this
component.  Conversely, no complete-family pole satisfying the hypotheses
and violating the statement is known.  Thus full closure by itself has not
yet converted the three overload signatures into forbidden support; the
missing datum is the phase of an external companion on a component meeting
the overload edge.
