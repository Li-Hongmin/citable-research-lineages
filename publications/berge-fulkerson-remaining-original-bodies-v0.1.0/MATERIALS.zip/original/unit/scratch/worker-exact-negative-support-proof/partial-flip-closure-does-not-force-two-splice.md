# Partial-flip closure does not force the repeated-extension two-splice gate

This note uses only Notes 055, 057, 072, 073, 078, 082, and 083.  Its
purpose is to test the proposed repeated-extension implication, not to
construct or search for a pole.

Fix the anchored target row

\[
 q+r+B+X+P_3+P_5=2\mathbf 1,                     \tag{1}
\]

where (P_3,Y) have singleton boundary (3), (P_5,D) have singleton
boundary (5), and the two half states are (35) and (23).  Assume the
complete pair support is exact Case XII and that the four literal pivot
rows of the repeated-extension star occur.  The target literal quartet is
(BDXY).

## The complete partial-flip cube

Write

\[
 P_3\mathbin\triangle Y=C_1\mathbin\dot\cup\cdots
                         \mathbin\dot\cup C_k.     \tag{2}
\]

For every (I\subseteq[k]), put

\[
 P^I=P_3\mathbin\triangle\bigtriangleup_{i\in I}C_i. \tag{3}
\]

Each (P^I) is an actual perfect matching of singleton boundary (3): on
each alternating component it independently chooses the (P_3)- or the
(Y)-phase.  Thus complete perfect-matching closure really supplies the
whole (2^k)-vertex cube, with (P^\varnothing=P_3) and
(P^{[k]}=Y).

This fact alone supplies no modified row.  If (N) is one of the other
occurrences in (1), the pair-sum-preserving partner forced by replacing
(P_3) with (P^I) is

\[
 N^I=N+P_3-P^I.                                  \tag{4}
\]

Although (P^I) is always a perfect matching, (N^I) is a perfect matching
if and only if (N) has the (P^I)-phase on every component indexed by
(I).  In particular, the endpoint (I=[k]) gives exactly

\[
 N^{[k]}\in\mathcal P
 \quad\Longleftrightarrow\quad
 \operatorname{Align}(N;P_3\to Y).               \tag{5}
\]

Closure of the singleton cube (3) does not imply membership of any of the
forced vectors (4) in the perfect-matching family.  Note 083 shows that
this failure can occur on every single component of (2), even for an
actual row in a simple cyclically five-edge-connected cubic graph of girth
five.

## The exact unconditional consequence of no (T)-loops

Absence of a (T)-loop does constrain the cube, but in the opposite form
from (5).  Any two edge-disjoint singleton perfect matchings with boundary
pair (t\in T) would, together with the unused perfect matching, give the
forbidden loop ([t]).  Hence every cube member satisfies

\[
 P^I\cap B\ne\varnothing,\qquad
 P^I\cap C\ne\varnothing                         \tag{6}
\]

for every (I), because (23,34\in T).  Here (C) is the literal
boundary-(4) singleton from the pivot star.

There is a precise component interpretation.  Let
(F=P_3\cap Y), and let (M) be any fixed perfect matching.  Then

\[
 \bigl(P^I\cap M\ne\varnothing\text{ for every }I\bigr)
 \quad\Longleftrightarrow\quad
 \left[
 M\cap F\ne\varnothing
 \ \text{or}\ 
 \exists i:\ M\cap(P_3\cap C_i)\ne\varnothing
             \text{ and }M\cap(Y\cap C_i)\ne\varnothing
 \right].                                        \tag{7}
\]

For the reverse implication, if neither alternative on the right holds,
choose independently on each (C_i) a phase avoided by (M); the resulting
(P^I) is disjoint from (M).  Formula (7) shows exactly what (6) says:
(B) and (C) either hit an edge common to (P_3,Y), or are mixed between
the two phases on at least one component.  It does not say that either
matching carries the complete (Y)-phase of any component, much less that
one companion carries it on all components.  Thus the loop prohibition
does not imply (5).

## What the no-(TT) condition says about the cube

Keep the (t=23) half of (1) fixed and write

\[
 H=r+B+X,\qquad K=2\mathbf1-H=q+P_3+P_5.          \tag{8}
\]

Suppose, for some (I), that (P^I) actually occurs in a decomposition of
the *same* carrier load (K).  The other singleton in that decomposition
has some boundary (j\in\{1,2,4,5\}), and the state is (3j).  Since the
opposite shore has the (T)-state (23), exact negative support forces

\[
 K=P^I+Q_{3j}+P_j
 \quad\Longrightarrow\quad j\in\{1,5\}.          \tag{9}
\]

The alternatives (j=2) and (j=4) would give a (T)-loop or a
(T)--(T) row.  By Note 078, the antecedent in (9) requires first that
(P^I\le K) edgewise and then that the degree-two residual
(K-P^I) pass its even-cycle and terminal-path parity tests.

Crucially, the negative support assumptions provide only the implication
(9).  They do not assert its antecedent for any nontrivial (I).  They can
forbid a residual decomposition after it exists, but cannot make
(P^I) lie inside (K), make (K-P^I) decomposable, or make the remaining
singleton equal the literal (D).  Column saturation in Note 055 supplies
all five (S)-states of some decompositions of (K); it does not require
those decompositions to contain a prescribed cube member (P^I).  The
transports in Note 057 likewise preserve one actual carrier half and do
not identify its private singleton entries with (P^I,Y), or (D).

## Decision and the unique missing relation

The stated inputs do not decide the repeated-extension implication.  They
give no general proof that one of the three overloaded targets satisfies a
Note-082 sequential alignment system or its forced-intermediate test, and
Notes 072 and 083 are not real exact-Case-XII counterexamples with all
hypotheses combined.  The correct evidence level is therefore an
information boundary, not a proof, a counterexample, or a logical
independence result for the full hypotheses.

For the fixed first replacement, the unique missing relation is the
cross-occurrence pair-sum membership

\[
 \boxed{\quad
 \exists N\text{ in the current row}:\quad
 N+P_3-Y\in\mathcal P_{\partial N}.
 \quad}                                           \tag{10}
\]

By Note 082, (10) is exactly the endpoint phase intersection (5).  After
one such equality, the same membership equality for (P_5\to D) in the
updated row gives the sequential two-splice conclusion.  The only other
two-splice possibility is the forced intermediate

\[
 Z_3=Y+D-P_5\in\mathcal P_3,qquad
 N+P_3-Z_3\in\mathcal P_{\partial N},              \tag{11}
\]

or its boundary-(5) symmetric version.  Equations (10)--(11) are
equalities between actual matching occurrences in one carrier fibre.  The
partial-flip cube, the type-support flags, and the residual parity
criterion do not couple their quantifiers.

A sufficient additional hypothesis, strictly focused on the carrying
mechanism, is therefore:

> for at least one of the three targets, one of the two ordered endpoint
> pair-sum memberships (10) persists after the first update and supplies
> the analogous membership for the second singleton, or (11) holds.

This is precisely the missing cross-row carrier-section hypothesis.  It
does not require any further graph order, census, or local topology.  Any
future proof must derive this membership from simultaneous reuse of actual
perfect matchings across different Case-XII rows.  The consequences proved
in the cited notes from the cube (3) and the forbidden boundary types do not
yet supply that coupling.
