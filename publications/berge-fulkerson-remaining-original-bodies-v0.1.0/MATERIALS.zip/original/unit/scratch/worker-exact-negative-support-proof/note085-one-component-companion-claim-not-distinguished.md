# Note 085 does not distinguish the one-component companion claim

The frozen Note 085 common-binary object satisfies the class-exclusivity
conclusion of Note 086 and has empty companion incidence fibres for every
same-class edge-removing replacement in every relevant canonical pivot row.
Nevertheless it does not decide the proposed one-component statement,
because it contains no graph or alternating-component relation.

## What the fixed vectors decide

For each singleton boundary class \(i\), let \(\mathcal M_i\) be all frozen
singleton tokens of class \(i\), and define

\[
 F_i=\bigcap_{P\in\mathcal M_i}
      \{e\in\{5,\ldots,47\}:\chi_P(e)=1\}.       \tag{1}
\]

The class sizes are

\[
 (|\mathcal M_1|,\ldots,|\mathcal M_5|)
   =(15,13,21,13,18),                             \tag{2}
\]

and direct evaluation gives

\[
 F_1=F_2=F_3=F_4=F_5=\varnothing.               \tag{3}
\]

Thus the Note 086 pairwise-disjoint conclusion holds in the strongest
possible form.  Every singleton occurrence using a proper coordinate has
some frozen same-class token avoiding that coordinate.

In the four canonical pivot rows there are 62 row-coordinate cases in which
at least two different singleton classes use the same proper coordinate
\(e\).  For each source occurrence \(P\), every same-class token \(P'\)
avoiding \(e\), and every other current-row occurrence \(N\), the fixed
calculation checks all compatible output tokens \(N'\) against

\[
 \chi_{N'}=\chi_N+\chi_P-\chi_{P'}.              \tag{4}
\]

All 62 cases have avoiding replacements, but no test satisfies (4).  Hence
every companion fibre visible in the common binary incidence data is empty.

For example, in

\[
 q_{13}+A+X+r_{45}+C+D=2\mathbf1,                \tag{5}
\]

proper coordinate 29 (`overload:ACXY`) is used by \(A\) of class 1 and
\(C\) of class 4.  There are 21 frozen same-class replacements of these two
occurrences avoiding coordinate 29.  None can be absorbed by any of the five
current companions through (4).

## Why this does not decide the one-component claim

The statement under test does not quantify over arbitrary same-class
replacement tokens.  It requires a replacement of the form

\[
 P'=P\triangle C
\]

for one proper \(P\)-alternating cycle \(C\).  Note 085 supplies only token
vectors and coordinate loads.  It has no common vertex incidence, no graph,
and no decomposition of \(P\triangle P'\) into alternating components.
Consequently the frozen data cannot certify that even one of its avoiding
pairs is a one-component switch.

The fact that (4) fails for every frozen replacement closes the purely
incidence-level absorption route: any one-component pair already present
would also fail.  But declaring a pair to be one-component would add
structure not contained in the fixed object and is forbidden in this pulse.
Thus the correct evidence level is

\[
 \boxed{\text{fixed object does not distinguish the one-component claim}.}
\]

It is neither a strict countermodel nor positive evidence for the real
cubic full-perfect-matching statement.  The missing datum is precisely the
graph-induced alternating-cycle relation and its single-component closure.

## Reproduction

The read-only verifier uses the two frozen Note 085 bundle files and does no
synthesis:

```text
python3 -u check_note085_class_fixed_and_companion_fibres.py \
  joint_carrier_common_binary_result.json \
  synthesize_joint_carrier_guard_model.py \
  --json result.json
```

The decisive raw counts from the first fixed-data run were

```text
class_fixed_sets = {1: [], 2: [], 3: [], 4: [], 5: []}
overloaded_pivot_row_edge_cases = 62
cases_with_some_absorption = 0
cases_with_all_replacement_fibres_empty = 62
```

That Omen run used one Python 3.10.12 process, finished in 0.13 seconds,
used 21,964 kB peak resident memory, and exited zero.  No token, coordinate,
row, graph, or synthesized constraint was added.
