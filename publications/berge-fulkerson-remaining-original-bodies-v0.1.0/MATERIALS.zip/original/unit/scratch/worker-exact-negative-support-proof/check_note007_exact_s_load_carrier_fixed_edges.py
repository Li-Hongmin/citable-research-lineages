#!/usr/bin/env python3
"""Test the exact-S-load carrier-fixed claim on the fixed Note-007 pole.

No graph is generated or searched: the 31 perfect matchings and 177 BF covers
come from the independent frozen Note-007 verifier supplied on the command
line.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path


S_STATES = {
    (0, 2),  # 13
    (0, 3),  # 14
    (1, 3),  # 24
    (1, 4),  # 25
    (2, 4),  # 35
}
T_STATES = {
    (0, 1),  # 12
    (0, 4),  # 15
    (1, 2),  # 23
    (2, 3),  # 34
    (3, 4),  # 45
}


def load_module(path):
    spec = importlib.util.spec_from_file_location("note007_verifier", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_vector(matching, edge_count):
    return tuple((matching >> edge) & 1 for edge in range(edge_count))


def vector_sum(vectors, indices):
    return tuple(sum(vectors[index][edge] for index in indices)
                 for edge in range(len(vectors[0])))


def matching_record(module, matchings, index):
    matching = matchings[index]
    proper = [edge for edge in range(module.N_PROPER) if matching >> edge & 1]
    boundary = [position + 1 for position in range(5)
                if matching >> (module.N_PROPER + position) & 1]
    return {
        "index": index,
        "proper_edge_ids": proper,
        "proper_edges": [list(module.PROPER[edge]) for edge in proper],
        "boundary": boundary,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("note007_script", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    module = load_module(args.note007_script)
    module.graph_checks()
    matchings = module.enumerate_perfect_matchings()
    covers = module.enumerate_bf_covers(matchings)
    assert len(matchings) == 31
    assert len(covers) == 177
    vectors = tuple(load_vector(matching, module.N_EDGES) for matching in matchings)
    boundaries = tuple(module.boundary_mask(matching) for matching in matchings)

    singleton_classes = {
        position: tuple(index for index, boundary in enumerate(boundaries)
                        if boundary == 1 << position)
        for position in range(5)
    }

    decomposition_groups = defaultdict(list)
    states_by_load = defaultdict(set)
    for first, second in combinations(range(5), 2):
        state = (first, second)
        triple_boundary = 0b11111 ^ (1 << first) ^ (1 << second)
        triples = [index for index, boundary in enumerate(boundaries)
                   if boundary == triple_boundary]
        for q in triples:
            for p_first in singleton_classes[first]:
                for p_second in singleton_classes[second]:
                    decomposition = (q, p_first, p_second)
                    load = vector_sum(vectors, decomposition)
                    decomposition_groups[(state, load)].append(decomposition)
                    states_by_load[load].add(state)

    exact_s_loads = {
        load for load, states in states_by_load.items() if states == S_STATES
    }

    actual_halves = []
    for cover_index, cover in enumerate(covers):
        seen = set()
        for occurrences in combinations(range(6), 3):
            chosen = tuple(cover[position] for position in occurrences)
            kinds = sorted(boundaries[index].bit_count() for index in chosen)
            if kinds != [1, 1, 3]:
                continue
            q = next(index for index in chosen
                     if boundaries[index].bit_count() == 3)
            singles = [index for index in chosen
                       if boundaries[index].bit_count() == 1]
            first = boundaries[singles[0]].bit_length() - 1
            second = boundaries[singles[1]].bit_length() - 1
            if first == second:
                continue
            if first > second:
                first, second = second, first
                singles.reverse()
            state = (first, second)
            if boundaries[q] != (0b11111 ^ (1 << first) ^ (1 << second)):
                continue
            decomposition = (q, singles[0], singles[1])
            load = vector_sum(vectors, decomposition)
            assert decomposition in decomposition_groups[(state, load)]

            complement = tuple((Counter(cover) - Counter(decomposition)).elements())
            assert len(complement) == 3
            complement_kinds = sorted(boundaries[index].bit_count()
                                      for index in complement)
            assert complement_kinds == [1, 1, 3]
            complement_singles = [
                boundaries[index].bit_length() - 1
                for index in complement
                if boundaries[index].bit_count() == 1
            ]
            assert len(complement_singles) == 2
            complement_state = tuple(sorted(complement_singles))

            record_key = (cover_index, decomposition, state, load)
            if record_key in seen:
                continue
            seen.add(record_key)
            actual_halves.append({
                "cover_index": cover_index,
                "cover": tuple(cover),
                "decomposition": decomposition,
                "state": state,
                "complement_state": complement_state,
                "load": load,
            })

    candidate_by_key = {}
    for half in actual_halves:
        state = half["state"]
        load = half["load"]
        if state not in S_STATES or half["complement_state"] not in T_STATES:
            continue
        if load not in exact_s_loads:
            continue
        group = decomposition_groups[(state, load)]
        for source_class, role in ((state[0], 1), (state[1], 2)):
            other_class = state[1] if source_class == state[0] else state[0]
            fibre = tuple(sorted({decomposition[role] for decomposition in group}))
            for edge in range(module.N_PROPER):
                if not all(vectors[index][edge] for index in fibre):
                    continue
                row_singleton_users = tuple(sorted({
                    index for index in half["cover"]
                    if boundaries[index].bit_count() == 1 and vectors[index][edge]
                }))
                row_user_classes = {
                    boundaries[index].bit_length() - 1
                    for index in row_singleton_users
                }
                if not any(position != source_class for position in row_user_classes):
                    continue
                global_avoiders = tuple(
                    index for index in singleton_classes[source_class]
                    if not vectors[index][edge]
                )
                if not global_avoiders:
                    continue
                all_state_groups = {
                    s: tuple(sorted(set(decomposition_groups[(s, load)])))
                    for s in sorted(S_STATES)
                }
                total_decompositions = sum(len(value)
                                           for value in all_state_groups.values())
                key = (half["cover_index"], state, load, source_class, edge)
                candidate = {
                    "cover_index": half["cover_index"],
                    "cover": half["cover"],
                    "state": state,
                    "complement_state": half["complement_state"],
                    "load": load,
                    "witness_decomposition": half["decomposition"],
                    "source_class": source_class,
                    "other_class": other_class,
                    "edge": edge,
                    "fibre": fibre,
                    "row_singleton_users": row_singleton_users,
                    "global_avoiders": global_avoiders,
                    "all_state_groups": all_state_groups,
                    "total_decompositions": total_decompositions,
                }
                current = candidate_by_key.get(key)
                if (current is None or
                        candidate["witness_decomposition"] <
                        current["witness_decomposition"]):
                    candidate_by_key[key] = candidate

    candidates = list(candidate_by_key.values())
    candidates.sort(key=lambda case: (
        case["total_decompositions"], len(case["fibre"]),
        case["cover_index"], case["state"], case["source_class"],
        case["edge"], case["witness_decomposition"],
    ))

    def decomposition_record(decomposition):
        return [matching_record(module, matchings, index)
                for index in decomposition]

    def case_record(case):
        return {
            "selection_order": [
                "total_decompositions",
                "oriented_fibre_size",
                "cover_index",
                "state",
                "source_class",
                "proper_edge_id",
                "witness_decomposition",
            ],
            "cover_index": case["cover_index"],
            "cover": [matching_record(module, matchings, index)
                      for index in case["cover"]],
            "load": list(case["load"]),
            "complete_state_set_1_based": [
                [position + 1 for position in state] for state in sorted(S_STATES)
            ],
            "all_decompositions_by_state": {
                "".join(str(position + 1) for position in state): [
                    decomposition_record(decomposition)
                    for decomposition in case["all_state_groups"][state]
                ]
                for state in sorted(S_STATES)
            },
            "total_decomposition_count": case["total_decompositions"],
            "witness_state_1_based": [position + 1
                                      for position in case["state"]],
            "complement_state_1_based": [position + 1
                                         for position in case["complement_state"]],
            "witness_decomposition": decomposition_record(
                case["witness_decomposition"]
            ),
            "oriented_source_class_1_based": case["source_class"] + 1,
            "other_singleton_class_1_based": case["other_class"] + 1,
            "proper_edge_id": case["edge"],
            "proper_edge": list(module.PROPER[case["edge"]]),
            "oriented_fibre": [matching_record(module, matchings, index)
                               for index in case["fibre"]],
            "row_overload_users": [matching_record(module, matchings, index)
                                   for index in case["row_singleton_users"]],
            "global_avoiders": [matching_record(module, matchings, index)
                                for index in case["global_avoiders"]],
        }

    certificate = case_record(candidates[0]) if candidates else None
    result = {
        "status": ("actual_exact_s_load_carrier_fixed_counterexample"
                   if certificate else
                   "fixed_note007_has_no_exact_s_load_carrier_fixed_counterexample"),
        "vertices": module.N,
        "proper_edges": module.N_PROPER,
        "semiedges": len(module.TERMINALS),
        "perfect_matchings": len(matchings),
        "bf_covers": len(covers),
        "distinct_decomposition_loads": len(states_by_load),
        "exact_s_loads": len(exact_s_loads),
        "actual_oriented_half_occurrences": len(actual_halves),
        "qualifying_cases": len(candidates),
        "minimal_certificate": certificate,
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")

    compact = {key: value for key, value in result.items()
               if key != "minimal_certificate"}
    if certificate:
        compact["minimal_certificate_summary"] = {
            "cover_index": certificate["cover_index"],
            "load": certificate["load"],
            "witness_state_1_based": certificate["witness_state_1_based"],
            "complement_state_1_based": certificate["complement_state_1_based"],
            "total_decomposition_count": certificate["total_decomposition_count"],
            "decomposition_counts_by_state": {
                state: len(decompositions)
                for state, decompositions in
                certificate["all_decompositions_by_state"].items()
            },
            "oriented_source_class_1_based":
                certificate["oriented_source_class_1_based"],
            "other_singleton_class_1_based":
                certificate["other_singleton_class_1_based"],
            "proper_edge_id": certificate["proper_edge_id"],
            "proper_edge": certificate["proper_edge"],
            "oriented_fibre_indices": [record["index"]
                                       for record in certificate["oriented_fibre"]],
            "row_overload_user_indices": [
                record["index"] for record in certificate["row_overload_users"]
            ],
            "global_avoider_indices": [record["index"]
                                       for record in certificate["global_avoiders"]],
        }
    print(json.dumps(compact, indent=2, sort_keys=True))
    if certificate:
        print("NOTE007_EXACT_S_LOAD_CARRIER_FIXED_COUNTEREXAMPLE_FOUND")
    else:
        print("NOTE007_NO_EXACT_S_LOAD_CARRIER_FIXED_COUNTEREXAMPLE")


if __name__ == "__main__":
    main()
