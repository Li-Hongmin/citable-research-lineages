# The minimal bad-phase potential has a \(K_{3,3}\) plateau

Fix literal singleton matchings \(A,C,D\), the common carrier

\[
K=2\mathbf1-A-C-D,
\]

and the two oriented decomposition fibres

\[
\begin{aligned}
\mathcal D_B(K)
 &=\{(q_{24},r_{15},B):q_{24}+r_{15}+B=K\},\\
\mathcal D_X(K)
 &=\{(q_{13},r_{45},X):q_{13}+r_{45}+X=K\}.
\end{aligned}                                                \tag{1}
\]

A literal \(J_{31}\) choice is one member of each fibre in (1).  Put

\[
P=A\mathbin\triangle C,\qquad
J(B,X)=B\cap X\cap P,\qquad
\Phi(B,X)=|J(B,X)|.                                         \tag{2}
\]

Because the fibres are finite, \(\Phi\) has a minimum.  Minimality does not
force that minimum to be zero.  The \(K_{3,3}\) owner rectangle of
[Note 097](../../notes/097-a-k33-owner-phase-rectangle-blocks-local-fibre-avoidance.md)
extends to two complete local one-factorizations of the same carrier, and
all four literal choices have \(\Phi=1\).  It is therefore a genuine local
descent plateau.

This does not give an exact-Case-XII pole.  It proves that a descent
argument still needs a global fixed-fibre entry or a boundary-labelled
equal-sum theorem; extremality by itself supplies neither.

## What counts as a legal descent

An arbitrary class-2 perfect matching \(B'\) is not a legal replacement.
To preserve the first literal row with the same \(A,C,D\), it must occur in
an actual decomposition

\[
q'_{24}+r'_{15}+B'=K.                                      \tag{3}
\]

Equivalently, \(B'\) must be the singleton projection of a member of
\(\mathcal D_B(K)\).  Then

\[
q'_{24}+r'_{15}+B'+A+C+D=2\mathbf1,
\]

while the \(X\)-row remains unchanged.  The symmetric condition applies to
an \(X'\)-replacement.  Same boundary class in the full pole, without
(3), does not preserve the literal row fibre.

Let \(B'\) satisfy (3) and put \(R=B\mathbin\triangle B'\).  Since \(B,B'\)
have the same singleton boundary, \(R\) is a disjoint union of proper even
alternating cycles.  The exact change in the bad set is

\[
J(B',X)
=
\bigl(J(B,X)\setminus R\bigr)
\mathbin{\dot\cup}
\bigl((B'\setminus B)\cap X\cap P\bigr).                      \tag{4}
\]

Consequently

\[
\Phi(B',X)-\Phi(B,X)
=
-|J(B,X)\cap R|
+|(B'\setminus B)\cap X\cap P|.                              \tag{5}
\]

Thus a one-sided strict descent exists exactly when

\[
\boxed{
|J(B,X)\cap R|
>
|(B'\setminus B)\cap X\cap P|.
}                                                            \tag{6}
\]

At a globally minimal choice with \(J\ne\varnothing\), all legal
replacements satisfy the reverse weak inequality.  This is the full
consequence of minimizing \(|J|\); it does not identify an equality of two
matching sums or a forbidden boundary type.

The stronger clearing criterion of Note 097,

\[
J(B,X)\subseteq R,\qquad
(B'\setminus B)\cap X\cap P=\varnothing,                     \tag{7}
\]

implies strict descent, but minimality gives no reason for either clause of
(7).

## The local plateau with complete carrier decompositions

On \(K_{3,3}\), use permutation matching notation

\[
M_p=\{(i,p(i)):i=0,1,2\}.
\]

Take the owner factorization

\[
A=M_{012},\qquad C=M_{120},\qquad D=M_{201}.                  \tag{8}
\]

These matchings partition all nine edges, so the local carrier load is
\(\mathbf1\).  Put

\[
\begin{aligned}
B_0&=M_{012},& B_1&=M_{120},\\
X_0&=M_{021},& X_1&=M_{102},& Y&=M_{210}.
\end{aligned}                                                \tag{9}
\]

The same carrier now has two full local colour decompositions

\[
K=B_0+B_1+D=X_0+X_1+Y.                                     \tag{10}
\]

Accordingly either \(B_0\) or \(B_1\) can be designated as the singleton
member of the first local colouring, with the other and \(D\) as
companions.  Likewise either \(X_0\) or \(X_1\) can be designated in the
second local colouring, with the other and \(Y\) as companions.  These are
local restrictions; an ambient five-pole extension must supply the stated
boundary labels outside the block.

The four bad sets are

\[
\begin{array}{c|cc}
 &X_0&X_1\\ \hline
B_0&\{(0,0)\}\subseteq A&\{(2,2)\}\subseteq A\\
B_1&\{(1,2)\}\subseteq C&\{(0,1)\}\subseteq C .
\end{array}                                                   \tag{11}
\]

Hence

\[
\Phi(B_i,X_j)=1
\qquad(i,j\in\{0,1\}).                                      \tag{12}
\]

The row switch \(B_0\leftrightarrow B_1\) and column switch
\(X_0\leftrightarrow X_1\) are alternating six-cycle switches preserving
the carrier decompositions in (10).  They move around all four cells of
(11), but none strictly decreases \(\Phi\).

The plateau also defeats the suggested sharper aggregate potential.  Over
the complete \(2\times2\) rectangle,

\[
\left|
\bigcup_{i,j}J(B_i,X_j)
\right|=4,
\qquad
\sum_{i,j}|J(B_i,X_j)|=4.                                   \tag{13}
\]

Row and column switches merely permute the four singleton bad sets.
Therefore the lexicographic pair “union size, then total multiplicity” is
constant as well.

As in Note 097, cutting the \(D\)-edge \((0,2)\) gives an attachable
two-port block.  The matching \(Y\) also uses this edge, so after cutting
both \(D\) and \(Y\) use the two ports, while the two decompositions in
(10), all internal cubic incidences, and the bad rectangle (11) remain
valid.  This is an attachable local plateau, not a completed negative-
support pole.

## What an equal-sum replacement really says

For any two perfect matchings \(P_0,P_1\), a coordinatewise identity

\[
P_0+P_1=P'_0+P'_1                                      \tag{14}
\]

has a precise component description.  Every doubled common edge belongs
to both matchings on the right.  On each path or even-cycle component of
\(P_0\mathbin\triangle P_1\), the pair \(P'_0,P'_1\) chooses one of the
two alternating phases.  Conversely every independent choice of phase on
the components gives an identity (14); the choices on path components
determine the two new boundary sets.

In particular, if \(P_0\mathbin\triangle P_1\) has only one nontrivial
component, (14) gives only the original unordered pair.  It does not create
a third matching with a prescribed boundary class.

Every \(B_i\mathbin\triangle X_j\) in (11) is a single four-cycle on the
closed block; the row and column differences are single six-cycles.
Thus all local two-occurrence equal-sum alternatives are precisely the
phase swaps already displayed in the plateau, or require an exterior
matching whose boundary label is not determined by the block.

The proposed identity

\[
q_{13}+X=q_{12}+B'                                      \tag{15}
\]

would indeed give a forbidden \((12)(45)\) row after substitution in the
\(X\)-decomposition.  But (14) shows the missing assertion: a component
phase swap of \(q_{13}\mathbin\triangle X\) must produce an actual
triple matching \(q_{12}\) and an actual singleton-class-2 matching
\(B'\) with exactly those boundary labels.  Neither failure of (6) nor
minimality of \(\Phi\) assigns those labels.  A local phase swap may simply
return the original pair or another allowed member of the same plateau.

## Why no-A/no-TT and forty positive cells do not finish the descent

Inside the fixed carrier, no \(A\) implies that every \(B,X\) pair has a
load-one agreement, and no \(T\)-loop \([23]\) implies pairwise
intersection.  The plateau satisfies both consequences, always on an
\(A/C\)-owner edge.

Other absent \(T\)--\(T\) types constrain the terminal pairing of a
specific two-colour component.  They do not label the alternate phases of
all proper cycles in (14) with the boundary classes required in (15).

The forty positive cells supply many actual same-class perfect matchings,
but their five-matching complements may define carriers different from
\(K\).  Unless one of those witnesses satisfies (3), it is not a
competitor in the minimization of \(\Phi\).  Hence a global class avoider
cannot contradict minimality in one literal row fibre.

The \(K_{3,3}\) block is not a model of all forty cells or of their absence
counterparts.  It is a strict obstruction to deriving a descent or a
boundary-labelled equal-sum replacement from local alternating components,
common cubic incidence and the carrier equations alone.

## Exact missing condition and decision

A successful extremal proof needs one of the following genuinely new
statements.

1. **Potential-reducing fibre exchange.**  For every fixed
   \(A,C,D,K\), if a literal choice minimizes \(\Phi\) and has
   \(J\ne\varnothing\), then one of the two oriented decomposition fibres
   contains a replacement satisfying (6).
2. **Boundary-labelled equal-sum forcing.**  If both fibres fail (6), then
   some componentwise phase choice in (14) has the exact boundary labels
   in (15), or the corresponding labels of an all-terminal row.

Either statement excludes the plateau only by using global attachment and
the full witness family.  Neither follows from extremality: the plateau
(11) has positive minimum, has no descending row or column move, and has
only trivial local equal-sum alternatives.

Therefore the proposed minimal-bad-phase descent is not presently proved
by complete perfect-matching closure and exact support.  The actual
exact-Case-XII implication remains undecided.  Its precise remaining
interface is to force a potential-reducing matching to enter the same
literal carrier fibre, or to force a component phase swap to carry the
specific global boundary labels which create \(A\) or \(T\)--\(T\).
No Kempe-connectivity assumption is used.
