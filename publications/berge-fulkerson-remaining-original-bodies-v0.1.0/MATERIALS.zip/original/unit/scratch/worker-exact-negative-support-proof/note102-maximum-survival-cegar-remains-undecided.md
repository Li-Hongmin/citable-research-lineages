# Note 102 maximum-survival CEGAR remains undecided

## Question and fixed scope

For the fixed 67 local stars of Note 102, consider all loopless
same-column pairings of the proper stubs, with the vertices, terminal
blocks, selected 19 perfect matchings, and six rows held fixed.  Does some
pairing have a full graph-induced perfect-matching closure with no
`(12345)` A-cover?

The exact pairing space has size

\[
3^9 15^3 105=6,975,163,125.
\]

This run used the already certified maximum-survival A-cover of the
original pairing as its first exact blocking clause.  For each subsequent
outer candidate, the inner query sought an A-cover maximizing the number
of pairings on which that same six-matching witness survives.  A witness
with proper-stub labels \(\lambda\) survives precisely when every paired
stub pair has equal labels, and is blocked exactly by

\[
\bigvee_{\lambda(x)\ne\lambda(y)} \operatorname{pair}_{xy}.
\]

No order change, random search, or parameter expansion was used.

## Exact outcome

The run stopped with

```text
status = unknown_at_inner_maximum_A
iterations = 652
A blocking clauses = 651
connectivity cuts = 0
elapsed = 217.009534 s
```

The final, 652nd outer candidate is connected.  Its inner query returned
`global_deadline` before performing a feasibility check.  Thus this is not
an inner UNSAT result: the run neither proves that every pairing has an
A-cover nor produces a no-A pairing.

All 651 certified A witnesses, including the seed, have exact survival
counts.  Their minimum, median, and maximum are respectively

\[
2,657,205,\qquad 51,667,875,\qquad 2,325,054,375.
\]

The maximum is one third of the full pairing space, and the median is about
0.741 percent.  The sum of the survival counts is 56,648,428,515, or 8.12
times the whole space.  This is only an overlap-blind upper sum, not a union
count.  Since the outer solver still produced a candidate after all 651
clauses, the survival sets overlap substantially and leave an uncertified
residual region.  Blocking-clause sizes had minimum/median/maximum
4/20/40.

Every tested outer candidate was connected, so the prescribed lazy
component-crossing mechanism was never activated.  The TT, full Note 082
dependent-fibre, and exact-40/Tait tests were also never reached, because
no connected no-A candidate was certified.

## Decision

Maximum-survival witnesses improve the old arbitrary-witness CEGAR sharply:
the seed alone covers 465,010,875 pairings, and the run accumulated only
651 clauses rather than 3,482 arbitrary-witness clauses in a comparable
deadline.  Nevertheless, one bounded run still does not decide the fixed
finite question.  The decisive obstruction is now overlap among large
witness-survival regions, not near-enumeration of tiny survival regions.

Under the stated stopping rule this route is frozen as **undecided**.  No
second run, longer timeout, higher order, or randomized search is justified
by this result alone.

## Reproduction record

The computation ran on Omen as one Python process with `ulimit -v 1048576`
and an external 240-second timeout.  `/usr/bin/time -v` reported 217.17 s
wall time and 92,128 KiB maximum resident set size; exit status was zero.

- Script: `cegar_note102_maximum_survival_pairings_no_a.py`
- Result: `note102_maximum_survival_pairing_cegar_result.json`
- Result-file SHA256: `d17a545538e0e2bf17052f4344a7441ef44aa65fdbd053d8a18c1492ec8c9e1c`
- Marker: `NOTE102_MAXIMUM_SURVIVAL_CEGAR_UNKNOWN`

