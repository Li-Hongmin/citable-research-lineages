# A common class-3 residual forces the \(1\)--\(5\) path transfer

Let \(P\) be one actual class-3 perfect matching and assume

\[
D_{23}(P)=K_{23}-P=K_{34}-P=D_{34}(P)=:D.         \tag{1}
\]

Assume further that

\[
P\in\mathcal F_3(K_{23};5).                       \tag{2}
\]

Thus there are actual perfect matchings \(Q_{35}\) and \(P_5\) with

\[
D=Q_{35}+P_5.                                     \tag{3}
\]

The exact transfer criterion is

\[
\boxed{
P\in\mathcal F_3(K_{34};1)
\iff
\text{terminals \(1\) and \(5\) lie on the same terminal path of
the residual copy-multigraph \(\widetilde D\).}
}                                                               \tag{4}
\]

Moreover, in the exact-Case-XII setting, the absence of \(T\)-loops and
\(T\)--\(T\) rows forces this path condition.  Hence (1)--(2) imply

\[
P\in\mathcal F_3(K_{34};1).                       \tag{5}
\]

This is a genuine positive transfer theorem under the strong physical
residual equality (1).

## Structure of the common residual

Both \(K_{23}\) and \(K_{34}\) have terminal load one at all five
terminals, while \(P\) uses only terminal \(3\).  Therefore \(D\) has one
semiedge copy at each of

\[
\{1,2,4,5\}                                       \tag{6}
\]

and no copy at terminal \(3\).  Its internal degree is two.  Consequently
\(\widetilde D\) is a disjoint union of closed copy-cycles and exactly two
terminal copy-paths pairing the four semiedges in (6).

Equation (3) gives an alternating red/blue colouring of every residual
component.  Take \(Q_{35}\) red and \(P_5\) blue.  The forced terminal bits
are

\[
\begin{array}{c|cccc}
t&1&2&4&5\\ \hline
\beta_{35,5}(t)&0&0&0&1.
\end{array}                                                       \tag{7}
\]

The target decomposition

\[
D=Q_{13}+P_1                                      \tag{8}
\]

would instead have

\[
\begin{array}{c|cccc}
t&1&2&4&5\\ \hline
\beta_{13,1}(t)&1&0&0&0.
\end{array}                                                       \tag{9}
\]

Thus the two boundary prescriptions differ exactly at terminals \(1\) and
\(5\).

## Proof of the path equivalence

For a terminal path with \(m\) proper-edge copies and endpoint bits
\(\beta_s,\beta_t\), the residual alternation criterion is

\[
\beta_s\mathbin\oplus\beta_t\equiv m+1\pmod2.      \tag{10}
\]

All closed components are even because the colouring (3) already exists.

If terminals \(1\) and \(5\) lie on the same residual path, changing from
(7) to (9) toggles both endpoint bits of that path and neither endpoint bit
of the other path.  The two endpoint XOR values in (10) are unchanged.
Hence every terminal path remains compatible and (8) exists.

If terminals \(1\) and \(5\) lie on different residual paths, the change
from (7) to (9) toggles exactly one endpoint bit on each path.  Both XOR
values in (10) are reversed.  Since both paths satisfy (10) under (7),
neither satisfies it under (9).  Therefore (8) does not exist.

This proves (4), including the proper-length parity in both directions.
No assumption of simplicity is used.  Parallel physical edges and repeated
copies are distinguished in \(\widetilde D\); a doubled physical edge
forms a two-cycle when its two copies exhaust the residual degree at its
ends, and is even.  The terminal paths in (10) count proper copies with
multiplicity.

There is also a direct switching proof of the forward implication.  When
\(1\) and \(5\) share a path, exchange the red and blue copies on that
entire path.  The old \(P_5\) occurrence loses semiedge \(5\) and gains
semiedge \(1\), becoming \(P_1\); the old \(Q_{35}\) becomes \(Q_{13}\).
The class-3 occurrence \(P\) is untouched.

## Exact negative support forces the path endpoint

Let the terminal-\(5\) path in the colouring (3) end at

\[
t\in\{1,2,4\}.                                     \tag{11}
\]

Switch the two colours \(Q_{35}\) and \(P_5\) on this one path, leaving
the class-3 matching \(P\) fixed.  The resulting actual decomposition of
\(K_{23}\) has singleton state

\[
3t.                                                \tag{12}
\]

The fixed complementary half

\[
H_{23}=r_{23}+B+X                                  \tag{13}
\]

has \(T\)-state \(23\).  Therefore:

- if \(t=2\), combining (12) with (13) gives the forbidden \(T\)-loop
  \([23]\);
- if \(t=4\), it gives the forbidden \(T\)--\(T\) row \((34)(23)\);
- only \(t=1\) gives the allowed \(S\)-state \(13\).

Exact negative support excludes the first two outcomes.  Hence \(t=1\):
terminals \(1\) and \(5\) lie on the same residual terminal path.  By (4),
the decomposition (8) exists.  Equality (1) implies
\(K_{23}=K_{34}\), so

\[
K_{34}=P+Q_{13}+P_1,
\]

which proves (5).

This argument is the fibre-preserving refinement of the all-\(S\)
carrier-state closure: the bichromatic path switch changes the other
singleton role while retaining the literal class-3 matching \(P\)
pointwise.

## Aggregate residual circuits when the residuals are unequal

The strong equality (1) should be separated from a weaker fact.  Suppose
only that

\[
D_{23}(P)\ge0,\qquad D_{34}(P)\ge0.                \tag{14}
\]

Both residuals have internal degree two and the same four-terminal load
(6).  Colour the copies in
\(D_{34}(P)-D_{23}(P)\) positive and those in the opposite difference
negative.  At every internal vertex the positive and negative incidence
counts agree, and the semiedge differences vanish.  Pair opposite signs at
each vertex.  Following these pairings decomposes the signed difference
into proper closed circuits alternating between removed and inserted edge
copies.

Thus an aggregate, physical-edge-labelled multiplicity transformation

\[
\widetilde D_{23}(P)\rightsquigarrow
\widetilde D_{34}(P)                              \tag{15}
\]

always exists through signed alternating circuits.  It is not automatically
a colour-preserving transformation.

Given a red/blue colouring of the source residual, a chosen circuit pairing
forces an inserted copy at each endpoint to inherit the colour of the
deleted incidence there, because the other residual incidence at that
vertex retains the opposite colour.  The first exact local failure occurs
when one inserted edge copy receives opposite forced colours from its two
endpoints.  This is a colouring cocycle obstruction on the chosen signed
circuit, even though the uncoloured multiplicity switch is valid.

Furthermore, all circuits in (15) are proper and closed because the two
residual terminal loads agree.  A colour-preserving lift of them retains
the terminal bits (7); it cannot by itself change the singleton role from
terminal \(5\) to terminal \(1\).  After any successful aggregate
transport, that role change is still governed by the \(1\)--\(5\)
terminal-path criterion of the target residual.  Hence (15) is strictly
weaker than the oriented transfer proved under (1).

## Decision boundary

Under physical residual equality and one active \(35\)-oriented
decomposition, membership in the \(13\)-oriented fibre is exactly the
\(1\)--\(5\) residual-path condition.  Exact no-\(T\)-loop and
no-\(T\)--\(T\) support forces that condition by a single path switch which
keeps the actual class-3 occurrence \(P\) fixed.

If the residuals are merely nonnegative with the same degrees and terminal
loads, their aggregate signed difference always decomposes into proper
alternating circuits, but lifting that transformation to residual colours
requires an additional edge-copy cocycle condition and still does not
change the terminal roles.  The positive theorem therefore stops sharply
at the physical equality hypothesis (1).
