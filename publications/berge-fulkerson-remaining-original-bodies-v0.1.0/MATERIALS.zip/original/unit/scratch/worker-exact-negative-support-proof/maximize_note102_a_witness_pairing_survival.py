#!/usr/bin/env python3
"""Maximize how many proper-stub pairings share one Note-102 A witness."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path

from z3 import Bool, If, Optimize, Or, PbEq, Sum, is_true, sat


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
OUTPUT = HERE / "note102_maximum_a_witness_survival.json"
PAIRS = tuple(combinations(range(6), 2))


def odd_double_factorial(count):
    answer = 1
    for value in range(count - 1, 0, -2):
        answer *= value
    return answer


def main():
    record = json.loads(INPUT.read_text())
    vertices = record["vertices"]
    stubs = defaultdict(list)
    terminal_blocks = {}
    for vertex, item in enumerate(vertices):
        for block in item["blocks"]:
            if item["kind"] == "terminal" and block == item["terminal_block"]:
                terminal_blocks[vertex] = block
            else:
                stubs[block].append(vertex)
    assert set(terminal_blocks) == set(range(5))
    assert all(len(group) % 2 == 0 for group in stubs.values())

    solver = Optimize()
    label = {
        (block, vertex, pair): Bool(f"b{block}_v{vertex}_p{pair}")
        for block, group in stubs.items()
        for vertex in group
        for pair in range(len(PAIRS))
    }
    for block, group in stubs.items():
        for vertex in group:
            solver.add(PbEq([(label[block, vertex, pair], 1)
                             for pair in range(len(PAIRS))], 1))

    for vertex, item in enumerate(vertices):
        proper = [block for block in item["blocks"]
                  if not (item["kind"] == "terminal"
                          and block == item["terminal_block"])]
        semiedge_owners = {vertex, 5} if item["kind"] == "terminal" else set()
        for owner in range(6):
            solver.add(PbEq([
                (label[block, vertex, pair], 1)
                for block in proper
                for pair, owners in enumerate(PAIRS)
                if owner in owners
            ], 0 if owner in semiedge_owners else 1))

    counts = {}
    exp3_terms, exp5_terms, exp7_terms = [], [], []
    for block, group in stubs.items():
        for pair in range(len(PAIRS)):
            count = Sum([If(label[block, vertex, pair], 1, 0) for vertex in group])
            counts[block, pair] = count
            solver.add(Or(*[count == value for value in range(0, len(group) + 1, 2)]))
            exp3_terms.append(If(count >= 4, 1, 0))
            exp5_terms.append(If(count >= 6, 1, 0))
            exp7_terms.append(If(count >= 8, 1, 0))
    exp3, exp5, exp7 = Sum(exp3_terms), Sum(exp5_terms), Sum(exp7_terms)

    # On the finite exponent box these integer log weights give exactly the
    # same strict ordering as the true products 3^a 5^b 7^c.
    weights = (1_098_612, 1_609_438, 1_945_910)
    profiles = [(a, b, c) for a in range(15) for b in range(5) for c in range(2)]
    assert sorted(profiles, key=lambda x: 3 ** x[0] * 5 ** x[1] * 7 ** x[2]) == sorted(
        profiles, key=lambda x: sum(weight * exponent
                                    for weight, exponent in zip(weights, x))
    )
    handle = solver.maximize(weights[0] * exp3 + weights[1] * exp5 + weights[2] * exp7)
    assert solver.check() == sat
    assert str(handle.lower()) == str(handle.upper())
    model = solver.model()
    exponents = tuple(model.eval(value).as_long() for value in (exp3, exp5, exp7))
    optimum = (3 ** exponents[0] * 5 ** exponents[1] * 7 ** exponents[2], *exponents)

    assignment = {}
    survival = 1
    for block, group in stubs.items():
        selected = {}
        histogram = Counter()
        for vertex in group:
            pair = next(pair for pair in range(len(PAIRS))
                        if is_true(model.eval(label[block, vertex, pair])))
            selected[str(vertex)] = list(PAIRS[pair])
            histogram[pair] += 1
        assert all(count % 2 == 0 for count in histogram.values())
        block_survival = 1
        for count in histogram.values():
            block_survival *= odd_double_factorial(count)
        survival *= block_survival
        assignment[str(block)] = {
            "stub_owner_pairs": selected,
            "owner_pair_counts": {str(PAIRS[pair]): count
                                  for pair, count in sorted(histogram.items())},
            "compatible_pairings": block_survival,
        }
    assert survival == optimum[0]

    OUTPUT.write_text(json.dumps({
        "status": "optimal",
        "optimization_checks": 1,
        "proper_blocks": len(stubs),
        "pairing_space": 6_975_163_125,
        "maximum_survival_pairings": survival,
        "prime_exponents": {"3": optimum[1], "5": optimum[2], "7": optimum[3]},
        "assignment": assignment,
    }, indent=2, sort_keys=True) + "\n")
    print({"optimization_checks": 1, "maximum_survival_pairings": survival,
           "prime_exponents": optimum[1:]})
    print("NOTE102_MAXIMUM_A_WITNESS_SURVIVAL_VERIFIED")


if __name__ == "__main__":
    main()
