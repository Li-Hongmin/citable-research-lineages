# An actual cubic row with empty phase intersection on three alternating hexagons

This note checks only the explicit eighteen-vertex construction supplied
with Note 082.  It is a row-level realizability boundary, not an
exact-Case-XII pole.

## Construction

Let

\[
 V=\{(c,i,j):c,i\in\mathbb Z_3,\ j\in\mathbb Z_2\}.
\]

For every (c,i), add

\[
 p_{c,i}=(c,i,0)(c,i,1),\qquad
 y_{c,i}=(c,i,1)(c,i+1,0).
\]

Thus, for each fixed (c), the (p)- and (y)-edges alternate on a
six-cycle.  Add the following third-edge perfect matching:

\[
\begin{aligned}
 &(0,0,0)(1,0,0),&&(2,0,0)(0,2,1),
 &&(1,2,1)(2,2,1),\\
 &(0,0,1)(1,1,0),&&(0,1,0)(1,2,0),
 &&(0,1,1)(2,0,1),\\
 &(0,2,0)(2,1,1),&&(1,0,1)(2,1,0),
 &&(1,1,1)(2,2,0).
\end{aligned}                                      \tag{1}
\]

The graph is simple and cubic.  Each fixed-(c) six-cycle is induced,
and the third edges connect every pair of the three blocks, so the graph is
connected.

Index five companion occurrences by (0,1,2,3,4).  Label every (p)-edge
by the singleton (\{0\}), and in each block label

\[
 y_{c,0},y_{c,1},y_{c,2}
 \quad\hbox{by}\quad
 \{1,2\},\{1,2\},\{3,4\},                         \tag{2}
\]

respectively.  At a vertex, label the third stub by the complement in
(\{0,1,2,3,4\}) of the labels on its incident (p)- and (y)-edges.
In the order

\[
 (c,0,0),(c,0,1),(c,1,0),(c,1,1),(c,2,0),(c,2,1),
\]

the six stub labels are

\[
 \{1,2\},\{3,4\},\{3,4\},\{3,4\},\{3,4\},\{1,2\}.
                                                               \tag{3}
\]

The first three edges in (1) pair precisely the six stubs labelled
(\{1,2\}); the remaining six pair precisely the twelve stubs labelled
(\{3,4\}).  Hence the two endpoint labels agree on every third edge, so
the stub prescription defines honest edge labels on the whole graph.

## The six actual matching occurrences

Let

\[
 P=\{p_{c,i}:c,i\in\mathbb Z_3\},\qquad
 Y=\{y_{c,i}:c,i\in\mathbb Z_3\}.
\]

For (a\in\{0,1,2,3,4\}), let (N_a) consist of the edges whose label
contains (a).  Then

\[
\begin{aligned}
 N_0&=P,\\
 N_1=N_2&=\{y_{c,0},y_{c,1}:c\in\mathbb Z_3\}
           \cup\{\text{the first three edges of (1)}\},\\
 N_3=N_4&=\{y_{c,2}:c\in\mathbb Z_3\}
           \cup\{\text{the last six edges of (1)}\}.
\end{aligned}                                      \tag{4}
\]

At every vertex the incident label sets partition
(\{0,1,2,3,4\}) into sizes (1,2,2).  Consequently each (N_a) uses
exactly one incident edge at every vertex and is an actual perfect matching
of this one graph.  Notice that the five companion *occurrences* need not
be distinct: (N_0=P), (N_1=N_2), and (N_3=N_4).  This is legitimate for
BF rows, which are multisets of perfect matchings.

Every (p)-edge is used by the displayed occurrence (P) and by (N_0).
Every other edge has a two-element label and is used by exactly the two
corresponding companions.  Therefore, edge by edge,

\[
 \chi_P+\sum_{a=0}^4\chi_{N_a}=2\mathbf 1.         \tag{5}
\]

Thus both the perfect-matching constraints and the exact row-load equations
are realized, rather than merely represented by abstract edge tokens.

## Empty component phase intersections

The matchings (P) and (Y) are disjoint and

\[
 P\mathbin\triangle Y=C_0\mathbin\dot\cup C_1
                         \mathbin\dot\cup C_2,     \tag{6}
\]

where the (C_c) are the three induced alternating six-cycles.  On the
(Y)-phase edges of every (C_c), the companion labels are

\[
 \{1,2\},\quad\{1,2\},\quad\{3,4\},
\]

whose intersection is empty.  Companion (0) occurs on none of these
edges.  Hence for every companion occurrence (N_a) and every block (c),

\[
 N_a\cap C_c\ne Y\cap C_c.                         \tag{7}
\]

In particular no row companion satisfies

\[
 \operatorname{Align}(N_a;P\to Y).
\]

The obstruction already occurs separately on each alternating component,
not only after intersecting labels across the three components.

## Exact conclusion and boundary

The construction strictly refutes the row-level implication

\[
 \begin{gathered}
 \text{simple connected cubic graph}
 +\text{ actual perfect matchings}
 +\text{ exact edge load two}
 \\
 \Longrightarrow
 \text{one current row companion is phase-aligned with }P\to Y.
 \end{gathered}                                    \tag{8}
\]

Equivalently, the two-subset labels in Note 082 have no Helly property even
when all labels arise from perfect matchings of one cubic graph.  Thus any
proof of the Note-082 alignment gate must use information beyond one BF row
and common cubic vertex incidence.

This does **not** give an exact-Case-XII counterexample.  The graph is
closed rather than a five-pole; no Case-XII boundary support, repeated-star
literal rows, three target overloads, absence of (T)-loops/(T)--(T) covers,
or Note-019 irreducibility condition has been imposed.  It also does not
exclude an aligned matching outside the five current row occurrences, nor
does it obstruct a preparatory splice that first imports such a matching
from another BF row.  Consequently it refutes only the one-row alignment
inference, not the full two-splice implication of Note 082 and not Case XII.
