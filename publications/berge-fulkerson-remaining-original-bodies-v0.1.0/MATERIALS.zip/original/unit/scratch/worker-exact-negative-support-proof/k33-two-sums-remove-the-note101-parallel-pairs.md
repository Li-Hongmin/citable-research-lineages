# Two (K_{3,3}) sums remove the Note 101 parallel pairs

Let (H_0) be the 67-vertex connected loopless cubic five-pole constructed
in `note101_global_stub_pairing_result.json`.  Its only parallel pairs have
endpoints

\[
 (0,5)\quad\text{and}\quad(1,62).
\]

Choose one edge (e_1) of the first pair and one edge (e_2) of the second.
For definiteness, in the JSON ordering take the edge of block 0 between
(0,5), and the edge of block 66 between (1,62).  Let (J_1,J_2) be
vertex-disjoint fresh copies of (K_{3,3}), and choose any proper edge
(f_i\in E(J_i)).  Form successively

\[
 H_1=H_0\oplus_{e_1,f_1}J_1,
 \qquad
 H_2=H_1\oplus_{e_2,f_2}J_2.                    \tag{1}
\]

Then (H_2) is a simple connected cubic five-pole, and

\[
 \begin{aligned}
 \operatorname{BFsupp}(H_2)&=\operatorname{BFsupp}(H_0),\\
 \operatorname{TaitStates}(H_2)&=\operatorname{TaitStates}(H_0).
 \end{aligned}                                  \tag{2}
\]

Moreover, every literal one-splice, sequential two-splice and
forced-intermediate fibre of Note 082 exists in (H_2) if and only if the
corresponding fibre exists in (H_0).

## Applicability of Note 099

At the first step, (H_0) is a cubic pole and (e_1) is a proper edge.
The factor (J_1=K_{3,3}) is a closed simple cubic 3-edge-colourable graph.
These are exactly the hypotheses of Note 099.  That theorem does not require
(H_0) to be simple and does not require (e_1) to be the unique edge
between its endpoints.  Its perfect-matching factorization only uses the
two new splice edges separating the even-order closed factor.

The second parallel pair is untouched by the first sum, so (e_2) remains a
proper edge of the cubic pole (H_1).  The same hypotheses apply to
(J_2).  Applying Note 099 twice gives (2) and the two-way preservation of
all Note-082 fibres.

For a simultaneous description, orient the first distinguished edge from
the internal endpoint (5), and the second from the internal endpoint
(62).  Fix a 1-factorization

\[
 E(J_i)=F^i_0\sqcup F^i_1\sqcup F^i_2,
 \qquad f_i\in F^i_0.
\]

For a perfect matching (M) of (H_0), let (c_i(M)\in\{0,1,2\}) record
which edge object of the three-edge star at the chosen endpoint of (e_i)
is used by (M).  The iterated canonical lift attaches

\[
 F^1_{c_1(M)}\quad\text{and}\quad F^2_{c_2(M)}                 \tag{3}
\]

to (M), with the distinguished edges replaced by the splice edges.  In
every BF row each value of each (c_i) occurs twice.  Every pair-sum equality
has the same multiset of (c_i)-values on its two sides.  Hence the single
identity map (3) preserves all six-row double covers and all pair-sum
equalities simultaneously.  Projection through the two cuts proves the
reverse implications.

## Order, boundary and simplicity

Each two-sum with (K_{3,3}) adds all six factor vertices.  On proper edges
it removes (e_i,f_i) and adds the two splice edges, so the net increase is
the nine edges of (K_{3,3}).  Since (H_0) has 67 vertices, 98 proper
edges and five semiedges,

\[
 |V(H_2)|=67+2\cdot6=79,
 \qquad
 |E_{\rm proper}(H_2)|=98+2\cdot9=116.          \tag{4}
\]

Indeed (3\cdot79=2\cdot116+5).  Neither factor has semiedges, and none of
the five original semiedges is changed, so the labelled five-terminal
boundary is pointwise identical to that of (H_0).

Deleting (e_i) leaves its parallel mate, and therefore removes exactly the
corresponding multiplicity-two pair without disconnecting the exterior.
The graph (K_{3,3}-f_i) is connected.  Its vertices are fresh, so each new
splice edge joins an old vertex to a previously disjoint factor vertex and
cannot duplicate an existing edge.  The remaining factor edges are simple,
and the two factors are mutually vertex-disjoint.  Because the certificate
has no loops and no parallel pairs other than the two displayed ones,
(H_2) is simple.  The same observations prove connectedness.  Cubicity is
preserved because every endpoint losing a deleted edge gains exactly one
splice edge.

## Consequence and boundary

The 67-vertex selected-family countermodel therefore has a 79-vertex simple
connected cubic realization with the same selected BF rows and endpoint
failures.  Simplicity alone cannot repair the Note 101 implication.

More strongly, inserting these factors changes none of the *complete* BF
boundary types, Tait states or dependent-fibre existence questions.  What is
unknown for (H_0) remains unknown for (H_2): the complete
perfect-matching closure has not been determined.  The operation also
creates explicit proper two-edge cuts, so it does not supply an
indecomposable or cyclically 5-edge-connected model.
