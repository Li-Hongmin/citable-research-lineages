# A \(K_{3,3}\) owner-phase rectangle blocks the alternating-switch argument

Fix actual singleton perfect matchings \(A,C,D\) and the carrier load

\[
K=2\mathbf1-A-C-D.
\]

For \(B\in\mathcal B(K)\) and \(X\in\mathcal X(K)\), put

\[
P=A\mathbin\triangle C,\qquad
J(B,X)=B\cap X\cap P.                                      \tag{1}
\]

The desired first nonoverload gate is \(J(B,X)=\varnothing\) for some
fixed-carrier pair.  The decomposition of \(P\) and
\(B\mathbin\triangle X\) into their unique boundary paths and proper even
cycles, even when combined with paired cycle switches and common cubic
vertex incidence, does not force this.  A \(K_{3,3}\) component supports a
literal \(2\times2\) cross-intersecting rectangle in which every cell has
one bad \(A/C\)-phase edge.

This is a strict local structural countermodel to the alternating-switch
argument.  It is not a full exact-Case-XII pole: the unresolved global
condition is whether all proper colourings and all forty positive cells can
be realized while the fixed-carrier trace families remain inside such a
rectangle.

## Exact trace formulation

Define the two trace families on the fixed owner support \(P\):

\[
\begin{aligned}
\mathscr B_P(K)&=\{B\cap P:B\in\mathcal B(K)\},\\
\mathscr X_P(K)&=\{X\cap P:X\in\mathcal X(K)\}.
\end{aligned}                                                \tag{2}
\]

The first gate succeeds exactly when these two families have a disjoint
pair:

\[
\exists S\in\mathscr B_P(K),\ T\in\mathscr X_P(K):
S\cap T=\varnothing.                                        \tag{3}
\]

Its exact failure is the cross-intersection condition

\[
\forall S\in\mathscr B_P(K),\ \forall T\in\mathscr X_P(K):
S\cap T\ne\varnothing.                                      \tag{4}
\]

Thus the question is not whether individual edges of \(P\) are avoidable.
It is whether two fixed-carrier trace families can form a cross-intersecting
rectangle without possessing a common fixed edge.

## The paired switches that are automatically inert

The standard symmetric-difference decompositions do not themselves change
the obstruction.

First, exchange \(B\) and \(X\) on any collection of components of
\(B\mathbin\triangle X\).  The unordered pair of incidences on every edge
is unchanged, and hence

\[
B'\cap X'=B\cap X,\qquad J(B',X')=J(B,X).                    \tag{5}
\]

This applies both to proper even-cycle components and, when the boundary
classes are exchanged, to the unique \(2\)-\(3\) path.

Second, exchange \(A\) and \(C\) on any collection of components of
\(A\mathbin\triangle C\).  Their symmetric difference \(P\) is unchanged,
so (1) is unchanged.  Therefore paired switches internal to either of the
two displayed symmetric differences cannot clear a bad phase.

A useful switch must instead replace only one of \(B,X\) by an external
same-carrier matching.  If \(B'\in\mathcal B(K)\), then
\(R=B\mathbin\triangle B'\) is a union of proper even cycles and

\[
J(B',X)
=
\bigl(J(B,X)\setminus R\bigr)
\mathbin{\dot\cup}
\bigl((B'\setminus B)\cap X\cap P\bigr).                      \tag{6}
\]

Consequently \(B'\) clears the phase exactly when

\[
\boxed{
J(B,X)\subseteq R
\quad\text{and}\quad
(B'\setminus B)\cap X\cap P=\varnothing.
}                                                            \tag{7}
\]

There is a symmetric criterion for replacing \(X\).  Complete
perfect-matching closure validates a proposed replacement once such a
same-carrier \(B'\) or \(X'\) is present; it does not by itself produce one
satisfying both phases of (7).

## A cubic owner-realized \(2\times2\) rectangle

Let the two vertex classes of \(K_{3,3}\) be indexed by
\(\{0,1,2\}\).  For a permutation \(p\in S_3\), write

\[
M_p=\{(i,p(i)):i=0,1,2\}.
\]

Choose the three owner matchings

\[
\begin{aligned}
A&=M_{(0,1,2)},\\
C&=M_{(1,2,0)},\\
D&=M_{(2,0,1)}.
\end{aligned}                                                \tag{8}
\]

They are pairwise edge-disjoint and partition all nine edges.  Hence on
this component

\[
2\mathbf1-A-C-D=\mathbf1,                                   \tag{9}
\]

so the induced carrier is the actual simple cubic graph \(K_{3,3}\), with
every edge of load one and with owner partition \(E_A=A\),
\(E_C=C\), \(E_D=D\).

Now take the two row matchings

\[
B_0=M_{(0,1,2)},\qquad B_1=M_{(1,2,0)}
\]

and the two column matchings

\[
X_0=M_{(0,2,1)},\qquad X_1=M_{(1,0,2)}.                       \tag{10}
\]

These are local restrictions on the displayed block.  In a five-pole
extension, matchings with different singleton boundaries must of course
differ on the exterior even when two of their restrictions here coincide.

Their four intersections are

\[
\begin{array}{c|cc}
 &X_0&X_1\\ \hline
B_0&\{(0,0)\}\subseteq E_A&
     \{(2,2)\}\subseteq E_A\\
B_1&\{(1,2)\}\subseteq E_C&
     \{(0,1)\}\subseteq E_C .
\end{array}                                                   \tag{11}
\]

Since \(P=A\mathbin\triangle C=A\cup C\), every cell in (11) has
exactly one bad-phase edge:

\[
J(B_i,X_j)=B_i\cap X_j\ne\varnothing
\qquad(i,j\in\{0,1\}).                                      \tag{12}
\]

Nevertheless neither side has a fixed edge:

\[
B_0\cap B_1=\varnothing,\qquad X_0\cap X_1=\varnothing.       \tag{13}
\]

This is the smallest nontrivial cross-intersecting rectangle which avoids
a common fixed coordinate.

All of the required alternating structure is genuine.  The differences

\[
B_0\mathbin\triangle B_1
\quad\text{and}\quad
X_0\mathbin\triangle X_1
\]

are six-cycles, while every
\(B_i\mathbin\triangle X_j\) is a four-cycle.  Thus the row and column
exchanges are actual paired alternating-cycle switches in one common cubic
graph, and all four switched cells remain bad.

The closed \(K_{3,3}\) is only a convenient presentation of the local
incidence.  To obtain an attachable block, cut the \(D\)-edge \((0,2)\)
into two exterior ports.  None of \(A,C,B_0,B_1,X_0,X_1\) uses that edge,
whereas \(D\) uses it.  After cutting, the former six restrictions avoid
both ports and the \(D\)-restriction uses both.  Every internal vertex
still has exactly one incidence in each matching, the owner identity
remains valid with the two ports \(D\)-owned, and all four intersections
in (11) are unchanged.  Hence the rectangle is compatible with attachment
to a connected ambient carrier; no disconnected \(K_{3,3}\) component is
being assumed.

In a five-pole extension, \(A\mathbin\triangle C\) additionally has its
unique \(1\)-\(4\) path, and \(B_i\mathbin\triangle X_j\) its unique
\(2\)-\(3\) path.  The block contributes only one of the allowed proper
even cycles to each decomposition.  Therefore the path-plus-cycles theorem
does not exclude this local rectangle.  This attachment observation is
not a construction of a full exact-Case-XII extension.

## What exact forty support does and does not add

Exact forty support gives actual witnesses for every positive
\(S\)--\(S\) and \(S\)--\(T\) boundary cell.  It also gives the global
class-fixed-edge exclusivity

\[
F_i\cap F_j=\varnothing\qquad(i\ne j)
\]

from
[Note 086](../../notes/086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md).
The rectangle already satisfies the relevant local analogue in the
strongest form (13), so fixed-edge exclusivity does not break it.

More importantly, a witness in a positive cell supplies a perfect matching
in a singleton boundary class, but need not put that matching in the fixed
literal fibre \(\mathcal B(K)\) or \(\mathcal X(K)\).  Its complementary
five-match load may be a different carrier.  Thus the forty existential
cells can provide global avoiders of each edge in (11) without adding a new
row or column to the fixed-carrier trace rectangle (2).

The no-\(T\)-loop condition for the class pair \(23\) only requires every
actual class-2/class-3 pair to intersect.  Equation (12) satisfies that
requirement inside the displayed carrier fibres.  The no-\(A\) consequence
at the common-carrier gate likewise requires a nonempty load-one agreement;
(12) supplies one, always in a bad owner phase.  Other absent
\(T\)--\(T\) cells constrain endpoint pairings in individual colourings,
not the row-column owner of the four intersections in (11).

This does not assert that the \(K_{3,3}\) rectangle extends to a pole with
exactly the forty Case-XII types.  It proves that the currently stated
alternating-component, paired-switch, common-vertex, owner, and
class-exclusivity facts have no local contradiction.

## The minimal additional condition

To use full positive support, one needs a **fixed-carrier fibre-entry
theorem**, not another global same-class avoider.  In its one-sided,
phase-explicit form, it must guarantee that for some literal pair
\((B,X)\) there is a matching \(B'\in\mathcal B(K)\) satisfying (7), or
symmetrically an \(X'\in\mathcal X(K)\) satisfying the corresponding
condition.

Equivalently, a positive theorem must exclude the bad rectangle cover

\[
\mathscr B_P(K)\times\mathscr X_P(K)
=
\bigcup_{e\in P}
\{S:e\in S\}\times\{T:e\in T\}.                              \tag{14}
\]

The extra statement must be carrier-preserving: an avoiding matching in
the full singleton class is insufficient unless its two companion
matchings also decompose this same \(K\).  It must also be
phase-preserving: removing the old intersections is insufficient if the
incoming phases in (7) create new intersections on \(P\).

No Kempe-connectivity assumption is needed or justified.  The matching
which breaks (14) may lie in a different Kempe component.  What is needed
is existence in the fixed carrier fibre, not a path to it in the
reconfiguration graph.

## Decision

The hypotheses currently extracted from full no-\(A\), no-\(T\)--\(T\),
the forty positive cells, and complete perfect-matching closure do not yet
prove that some \(B,X\) avoid \(A\mathbin\triangle C\).  The
\(K_{3,3}\) rectangle gives a strict common-incidence obstruction to every
argument using only:

1. the path-plus-even-cycle form of the two symmetric differences;
2. paired switches internal to those differences;
3. pairwise intersection and class-fixed-edge exclusivity; and
4. existential positive-cell witnesses without fixed-carrier entry.

The actual exact-Case-XII implication remains undecided.  Its thinnest
remaining interface is (7), or equivalently exclusion of the
fixed-carrier cross-intersection cover (14).  Proving that one of the forty
positive witnesses enters the same carrier with the required incoming
phase would settle this first gate; the present hypotheses do not supply
that identification.
