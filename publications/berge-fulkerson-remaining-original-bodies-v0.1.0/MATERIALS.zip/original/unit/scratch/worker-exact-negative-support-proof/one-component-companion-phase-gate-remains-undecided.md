# The one-component companion-phase gate is not decided by Notes 082/084/085/086

Fix a literal pivot BF row of an exact-40 cubic 5-pole and write it as

\[
  R=P+N_1+\cdots+N_5=2\mathbf 1,                \tag{1}
\]

where \(P\) is a singleton-boundary occurrence using a proper edge \(e\).
Assume that another singleton occurrence in a different boundary class also
uses \(e\).  Note 086 implies that at least one of the represented singleton
classes does not have \(e\) as a class-fixed edge.  The question is whether
one can choose such a current occurrence \(P\), remove \(e\) by one
same-boundary alternating component, and transfer that component to one of
the five current companions.

The four stated notes reduce this to an exact finite-looking phase condition,
but do not force or refute that condition in a real exact-40 pole.

## What follows automatically

Choose an \(e\)-avoiding perfect matching \(Q\) in the boundary class of
\(P\).  Since \(P\) and \(Q\) have the same boundary, their symmetric
difference contains no terminal path:

\[
  P\mathbin\triangle Q=C_1\mathbin{\dot\cup}\cdots
  \mathbin{\dot\cup}C_k,                        \tag{2}
\]

where every \(C_j\) is a proper even alternating cycle.  The edge \(e\)
belongs to one unique component, say \(C_e\).  Put

\[
  P_e=P\mathbin\triangle C_e.                   \tag{3}
\]

Flipping one component of the difference of two perfect matchings again
gives a perfect matching.  Hence \(P_e\) is an actual same-boundary perfect
matching and \(e\notin P_e\).  Thus Note 086 plus full perfect-matching
closure already settles the existence of an \(e\)-removing *one-component*
switch.  Nothing involving terminal linkages remains at this step.

## The only remaining condition

For every desired-phase edge \(f\in P_e\setminus P\), define its label by

\[
  L_f=\{r\in\{1,\ldots,5\}: f\in N_r\}.         \tag{4}
\]

Because (1) has load two and \(P\) does not use \(f\), every \(L_f\) has
size two.  Note 082 gives the exact equivalence

\[
\begin{split}
  N_r'=N_r+P-P_e\text{ is a same-boundary perfect matching}
  \quad\Longleftrightarrow\quad
  r\in\bigcap_{f\in P_e\setminus P}L_f.         \tag{5}
\end{split}
\]

The reverse-phase requirements on \(P\setminus P_e\) need not be added:
if one perfect matching uses every desired-phase edge of the alternating
cycle, vertex incidence forces it to avoid the adjacent old-phase edges.

Consequently the proposed statement is precisely

\[
  \exists\text{ eligible }(P,C_e)
  \quad\text{such that}\quad
  \bigcap_{f\in P_e\setminus P}L_f\ne\varnothing. \tag{6}
\]

## Exact failure certificates

By Note 084, an inclusion-minimal empty subfamily of the two-element labels
in (4) has exactly one of two forms, up to renaming companions:

\[
  \{\{a,b\},\{c,d\}\},                         \tag{7}
\]

or

\[
  \{\{a,b\},\{a,c\},\{b,c\}\}.               \tag{8}
\]

Thus (6) fails exactly when every eligible \(e\)-component supplied by
Note 086 contains a disjoint-pair certificate (7) or a triangle certificate
(8).  This is sharper than saying merely that a companion is missing.

A local cubic-incidence fragment already realizes (7).  On an alternating
4-cycle, label both \(P\)-phase edges by the occurrence pair \(\{P,K\}\),
and label the two desired-phase edges by \(\{a,b\}\) and \(\{c,d\}\).
At each cycle vertex the third incident edge receives the complementary
two-subset, and equal third stubs can be paired.  The three incident labels
then partition the six row occurrences, so every occurrence is locally a
matching and every edge has row load two.  Taking \(e\) on the old phase
makes it used by \(P\) and \(K\), while flipping the cycle removes it from
\(P\).  No current companion absorbs the flip: \(K\) uses the old phase,
\(a,b\) see only the first desired edge, and \(c,d\) see only the second.
The occurrences \(P,K\) can differ on a disjoint boundary part and therefore
represent different singleton classes.  This is a strict local incidence
countermodel, not a five-pole or an exact-40 counterexample.

## What the four notes do and do not add

- **Note 086** makes the set of eligible pairs \((P,C_e)\) nonempty by
  excluding simultaneous class-fixedness.  It gives no information about
  the labels (4).
- **Note 082** proves (5), so complete PM closure guarantees that an aligned
  companion is genuine once found.  Closure does not make the intersection
  nonempty.
- **Note 084** realizes both empty-intersection certificates inside actual
  cubic double-cover rows, even with strong connectivity and all partial
  flips present.  The no-all-terminal consequence only forces a
  \(D_2\)-hit by every partial flip; it does not identify one companion on
  all desired-phase edges.
- **Note 085** imposes all fifty currently used exact-40, pivot, transport,
  overload, cube and separation relations on one common binary incidence
  system while keeping its relevant carrier fibres empty.  It lacks a
  trivalent vertex partition and full graph-induced PM closure, and its
  stated separation audit concerns the designated endpoint replacements,
  not every one-component switch in (3).  It therefore cannot be promoted
  to a counterexample to (6).

The positive S-loop and S--T support statements are existential rows.  None
of Notes 082/084/085/086 supplies a theorem forcing one of those rows to
reuse the particular \(P,P_e\), or one fixed companion identity across all
edges of \(C_e\).  This is precisely the identity coupling that (6) needs.

## Decision and sharp remaining interface

The proposed statement is not decided by the four authoritative inputs.
They prove neither a general theorem nor a real exact-40 counterexample.
The sharp additional condition is that at least one eligible component label
family avoid both certificates (7)--(8), equivalently that (6) hold.  Any
non-tautological proof must derive this from a new cross-row reuse property
of the *complete* perfect-matching family of one cubic pole.  Conversely, a
counterexample must realize (7) or (8) for every Note-086-eligible class and
component while simultaneously retaining exact-40 support and full PM
closure.

The next mathematical uncertainty is therefore not the existence or shape
of the same-boundary exchange: it is whether exact-40 full closure forbids
all irreducible companion-label certificates at once.
