# Exact forty support and cube hitting do not force a two-step carrier section

## Decision

The implication under test is false at the common-binary-incidence level.
There is a single family of binary vectors that simultaneously realizes the
exact forty positive pair types, the literal token reuse in the Note 055/057
rows, the canonical pivots, three target overloads, all six prescribed
two-component flip cubes, and the Note 084 \(D_2\)-hitting condition, while
every prescribed sequential endpoint and forced-intermediate membership
fails.

This is not a cubic five-pole.  The first axiom absent from the model is a
common partition of the coordinates into cubic vertices, together with the
full perfect-matching closure induced by that vertex incidence.  The present
calculation therefore closes the common-binary carrier route and leaves that
single real-pole interface undecided.  No graph order was searched.

## The common binary model

The frozen model has 125 matching tokens represented by vectors in
\(\{0,1\}^{48}\).  Every designated BF row contains six tokens and has load
exactly two in every coordinate.  Its 50 designated rows are:

* all 25 \(S\)--\(T\) rows;
* all 15 unordered \(S\)--\(S\) rows, including the five loops;
* the ten two-branch transport rows from the five Note 057 overlaps.

Thus all forty required pair types are present.  The five rows with a fixed
\(T\)-state reuse the same literal right half, as in Note 055, and each Note
057 transport row reuses the actual token identities prescribed by its source
row.  The four canonical literal pivots are

\[
\begin{array}{c|c}
(13)(45)&(q_{13},A,X; r_{45},C,D)\\
(14)(23)&(q_{14},A,C; r_{23},B,X)\\
(24)(15)&(q_{24},B,C; r_{15},A,D)\\
(25)(34)&(q_{25},B,D; r_{34},Y,C).
\end{array}
\]

There is no five-terminal matching token, so an \((12345)\) row is
impossible.  An exhaustive integer check over the shared token pool finds no
row of any of the 15 unordered \(T\)--\(T\) types, including all five
\(T\)-loops.  Hence the pair support of this model is exactly the required
40 types: 15 \(S\)--\(S\), 25 \(S\)--\(T\), no \(A\), no \(T\)-loop, and no
\(T\)--\(T\).

## The three failed targets

The targets are fixed as follows.

\[
\begin{array}{c|c|c|c}
\text{name}&\text{source cell}&\text{desired replacement}&\text{literal overload}\\
\hline
BDXY&(35)(23)&(Y,D)&B+D+X+Y\ge 3\\
ACXY&(13)(34)&(A,X)&A+C+X+Y\ge 3\\
ABDY&(35)(12)&(Y,D)&A+B+D+Y\ge 3.
\end{array}
\]

For the last target the fixed \(12\)-half is
\((r_{12},A,B)\).  This is a deliberate strengthening in the countermodel,
not a claim that Note 055 forces that literal equality in every pole.

Each target replaces two source singleton tokens.  For every replacement
\(p\rightsquigarrow p'\), two additional tokens \(z_0,z_1\) satisfy

\[
   \chi_{z_0}+\chi_{z_1}=\chi_p+\chi_{p'}
\]

coordinatewise.  All four nonconstant component signatures

\[
(1,0,0,1),\ (0,1,1,0),\ (1,0,1,0),\ (0,1,0,1)
\]

occur for every one of the six relations.  This supplies the complete formal
partial-flip cube required in the test.

For each cube member separately, the model contains a coordinate at which
that member is present and the corresponding four-anchor load is exactly two.
Consequently every cube phase hits the appropriate \(D_2\), which is stronger
than merely requiring one hit somewhere in each target cube.

Finally, all 30 endpoint expressions (two replacements times five companion
tokens times three targets) and all six forced-intermediate expressions were
compared against every token of the required boundary class and kind in the
common pool.  None is a token vector.  Hence none of the three targets admits
the specified Note 082 sequential two-step carrier section.

## What the computation decides

The construction proves the strict non-implication

\[
\begin{split}
&\text{exact 40 support + Note 055/057 token reuse + literal pivots}\\
&\quad+\text{three overloads + prescribed cubes + }D_2\text{-hitting}
\end{split}
\quad\not\Longrightarrow\quad
\text{a Note 082 two-step carrier section}
\]

for shared binary incidence vectors.

It does not decide the corresponding statement for a simple connected cubic
five-pole.  Such a pole requires all token vectors to be perfect matchings of
one common trivalent vertex-incidence system and requires the token pool to be
closed under every perfect matching of that system.  Neither condition is
encoded here.  This is the minimal missing axiom; adding more support labels,
edge-load identities, overload coordinates, or formal flip cubes below this
interface cannot repair the implication.

## Reproduction

The synthesizer and frozen Omen artifacts are:

* `synthesize_joint_carrier_guard_model.py`;
* `joint_carrier_common_binary_result.json`;
* `joint_carrier_common_binary_omen_run.log`.

They have SHA-256 hashes

```text
d145197ad158a05ab5ac0041daede78af767f87f103eeaf757dba3e770f6c8e1  synthesize_joint_carrier_guard_model.py
f303c7b955b3eda37eb49ee0979c778da4f15dd271b738fdcbbc9f25f1bf1880  joint_carrier_common_binary_result.json
e7cb166c6d8dc8fbe4476852c79bc289202edffe363512d95efca064281a67c6  joint_carrier_common_binary_omen_run.log
```

The run used one Python 3.10.12 process with Z3 5.1.0 on `omen`, under a
4 GiB virtual-memory limit:

```text
python3 -u synthesize_joint_carrier_guard_model.py \
  --max-guard-rounds 1000 --json result.json
```

It terminated with exit status zero after 3.07 seconds, used 56,492 kB peak
resident memory, and printed

```text
JOINT_CARRIER_COMMON_BINARY_COUNTERMODEL_VERIFIED
```

Only one lazy guard coordinate was required to eliminate the last forbidden
\(T\)-loop/\(T\)--\(T\) candidate.  No membership-separator coordinate was
needed: the previously installed coordinates already separated all target
expressions.
