#!/usr/bin/env python3
"""Exact CEGAR over every loopless same-column pairing of Note 102.

The outer variables pair the fixed proper stubs inside each 22-bit selected
incidence column.  The inner query asks whether the resulting fixed cubic
multigraph has an A cover.  An A witness labels every proper stub by the
two-subset of its six matchings using that incidence.  The witness survives a
new pairing exactly when every paired pair of stubs has the same label, so
the exact blocking clause is the disjunction of all unequal-label pair
variables.

Disconnected no-A candidates are removed only by necessary component-
crossing cuts.  A connected no-A candidate is then checked for TT, the full
fixed Note-082 dependent fibre (sequential and forced-intermediate cases),
and the exact forty positive types/Tait states.  There is one fixed star
system and no order scan or random search.
"""

from __future__ import annotations

import gc
import hashlib
import json
import time
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from z3 import Bool, Or, PbEq, Solver, is_true, sat, unknown

from check_note101_global_multigraph_closure import (
    FixedMultigraph,
    S,
    TARGET_TYPES,
    a_query,
    checked_solve,
    tait_query,
    tt_query,
    type_query,
    verify_double_cover,
)


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
OUTPUT = HERE / "note102_all_same_column_pairings_no_a_result.json"
ROWS = (
    ("r23", "B", "X", "q13", "p1_13", "p3_13"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p2_24", "p4_24"),
    ("r23", "B", "X", "q25", "p2_25", "p5_25"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("q25prime", "r34", "B", "Y", "C", "D"),
)


def double_factorial_odd(points):
    assert points >= 0 and points % 2 == 0
    answer = 1
    for value in range(points - 1, 0, -2):
        answer *= value
    return answer


def components(n, edges):
    adjacency = [[] for _ in range(n)]
    for left, right in edges:
        adjacency[left].append(right)
        adjacency[right].append(left)
    output = []
    unseen = set(range(n))
    while unseen:
        start = min(unseen)
        unseen.remove(start)
        stack = [start]
        component = []
        while stack:
            here = stack.pop()
            component.append(here)
            for there in adjacency[here]:
                if there in unseen:
                    unseen.remove(there)
                    stack.append(there)
        output.append(tuple(sorted(component)))
    return tuple(sorted(output))


def selected_family_checks(graph):
    selected = {label: graph.selected_matching(label) for label in graph.labels}
    for label, matching in selected.items():
        position = graph.label_index[label]
        boundary = frozenset(
            terminal for terminal, column in enumerate(graph.terminal_columns)
            if column[position] == "1"
        )
        graph.verify_matching(matching, boundary)
    assert len(set(selected.values())) == 19
    for row in ROWS:
        verify_double_cover(tuple(selected[label] for label in row), graph.object_count)
    return selected


def enumerate_matchings(graph, deadline):
    adjacency = [[] for _ in range(graph.n)]
    for edge, (left, right) in enumerate(graph.edges):
        adjacency[left].append((right, edge))
        adjacency[right].append((left, edge))
    used = [False] * graph.n
    chosen = []
    output = []
    calls = 0

    def rec():
        nonlocal calls
        calls += 1
        if calls % 4096 == 0 and time.monotonic() >= deadline - 3.0:
            raise TimeoutError("perfect_matching_enumeration_deadline")
        unused = [vertex for vertex in range(graph.n) if not used[vertex]]
        if not unused:
            output.append(frozenset(chosen))
            return
        vertex = min(
            unused,
            key=lambda v: int(v < 5) + sum(not used[w] for w, _ in adjacency[v]),
        )
        used[vertex] = True
        if vertex < 5:
            chosen.append(graph.m + vertex)
            rec()
            chosen.pop()
        for neighbour, edge in adjacency[vertex]:
            if used[neighbour]:
                continue
            used[neighbour] = True
            chosen.append(edge)
            rec()
            chosen.pop()
            used[neighbour] = False
        used[vertex] = False

    rec()
    family = tuple(sorted(set(output), key=lambda item: tuple(sorted(item))))
    return family, calls


def matching_boundary(matching, proper_count):
    return frozenset(edge - proper_count for edge in matching if edge >= proper_count)


def signed_matching(plus_a, plus_b, minus_c, family_set, object_count):
    values = Counter(plus_a)
    values.update(plus_b)
    values.subtract(minus_c)
    if any(values[edge] not in (0, 1) for edge in range(object_count)):
        return None
    answer = frozenset(edge for edge in range(object_count) if values[edge] == 1)
    return answer if answer in family_set else None


def splice(row, source_position, target, companion_position, family_set, object_count):
    if source_position == companion_position:
        return None
    updated = signed_matching(
        row[companion_position], row[source_position], target,
        family_set, object_count,
    )
    if updated is None:
        return None
    result = list(row)
    result[source_position] = target
    result[companion_position] = updated
    return tuple(result)


def sequential_fibre(row, targets, family_set, object_count):
    original = tuple(row)
    source_positions = (4, 5)
    literal_fixed_positions = (2, 3)
    for order in ((0, 1), (1, 0)):
        first, second = order
        first_position = source_positions[first]
        second_position = source_positions[second]
        if row[first_position] == targets[first]:
            first_steps = [(tuple(row), "already")]
        else:
            first_steps = []
            for companion in range(6):
                changed = splice(
                    row, first_position, targets[first], companion,
                    family_set, object_count,
                )
                if changed is not None:
                    first_steps.append((changed, companion))
        for middle, first_companion in first_steps:
            if middle[second_position] == targets[second]:
                second_steps = [(middle, "already")]
            else:
                second_steps = []
                for companion in range(6):
                    changed = splice(
                        middle, second_position, targets[second], companion,
                        family_set, object_count,
                    )
                    if changed is not None:
                        second_steps.append((changed, companion))
            for final, second_companion in second_steps:
                if any(final[p] != original[p] for p in literal_fixed_positions):
                    continue
                return {
                    "kind": "sequential", "order": order,
                    "first_companion": first_companion,
                    "second_companion": second_companion,
                    "middle": [sorted(item) for item in middle],
                    "final": [sorted(item) for item in final],
                }
    return None


def forced_intermediate_fibre(row, targets, family_set, object_count):
    source_positions = (4, 5)
    for first, other in ((0, 1), (1, 0)):
        intermediate = signed_matching(
            targets[first], targets[other], row[source_positions[other]],
            family_set, object_count,
        )
        if intermediate is None:
            continue
        for triple_position in (0, 1):
            updated = signed_matching(
                row[triple_position], row[source_positions[first]], intermediate,
                family_set, object_count,
            )
            if updated is not None:
                return {
                    "kind": "forced_intermediate",
                    "intermediate_for_source": first,
                    "triple_position": triple_position,
                    "intermediate": sorted(intermediate),
                    "updated_triple": sorted(updated),
                }
    return None


def dependent_fibre_query(graph, selected, deadline):
    try:
        family, calls = enumerate_matchings(graph, deadline)
    except TimeoutError as error:
        return {"status": "unknown", "reason": str(error)}
    family_set = set(family)
    classes = defaultdict(list)
    for matching in family:
        classes[matching_boundary(matching, graph.m)].append(matching)

    fixed = tuple(frozenset(selected[name]) for name in ("r23", "B", "X"))
    targets = tuple(frozenset(selected[name]) for name in ("Y", "D"))
    fixed_load = [sum(edge in matching for matching in fixed)
                  for edge in range(graph.object_count)]
    residual = tuple(2 - value for value in fixed_load)
    decompositions = []
    for p3 in classes[frozenset((2,))]:
        for p5 in classes[frozenset((4,))]:
            if time.monotonic() >= deadline - 3.0:
                return {"status": "unknown", "reason": "dependent_fibre_deadline",
                        "perfect_matchings": len(family), "enumeration_calls": calls}
            partial = [int(edge in p3) + int(edge in p5)
                       for edge in range(graph.object_count)]
            q_values = [residual[edge] - partial[edge]
                        for edge in range(graph.object_count)]
            if any(value not in (0, 1) for value in q_values):
                continue
            q = frozenset(edge for edge, value in enumerate(q_values) if value)
            if q not in family_set or matching_boundary(q, graph.m) != frozenset((0, 1, 3)):
                continue
            decompositions.append((q, p3, p5))

    for q, p3, p5 in decompositions:
        if time.monotonic() >= deadline - 3.0:
            return {"status": "unknown", "reason": "dependent_fibre_deadline",
                    "perfect_matchings": len(family), "enumeration_calls": calls,
                    "state35_decompositions": len(decompositions)}
        row = (q, fixed[0], fixed[1], fixed[2], p3, p5)
        witness = sequential_fibre(row, targets, family_set, graph.object_count)
        if witness is None:
            witness = forced_intermediate_fibre(
                row, targets, family_set, graph.object_count
            )
        if witness is not None:
            return {
                "status": "sat", "perfect_matchings": len(family),
                "enumeration_calls": calls,
                "state35_decompositions": len(decompositions),
                "source_row": [sorted(item) for item in row],
                "witness": witness,
            }
    return {
        "status": "unsat", "perfect_matchings": len(family),
        "enumeration_calls": calls,
        "state35_decompositions": len(decompositions),
    }


def positive_case_xii_query(graph, deadline):
    positive = {}
    for index, kind in enumerate(TARGET_TYPES):
        result = type_query(graph, kind, f"positive_{index}", deadline)
        positive[str(kind)] = result
        if result["status"] != "sat":
            return {
                "status": ("missing_positive_type" if result["status"] == "unsat"
                           else "unknown"),
                "first_type": kind, "queries": positive,
            }
    tait = {}
    for index, state in enumerate(sorted(S)):
        result = tait_query(graph, state, f"tait_{index}", deadline)
        tait[str(state)] = result
        if result["status"] != "sat":
            return {
                "status": ("missing_S_tait_state" if result["status"] == "unsat"
                           else "unknown"),
                "first_state": state, "queries": positive,
                "tait_queries": tait,
            }
    return {"status": "exact_positive_and_tait", "queries": positive,
            "tait_queries": tait}


def emit(record):
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": record["status"],
        "iterations": record["iterations"],
        "a_blocking_clauses": record["a_blocking_clauses"],
        "connectivity_cuts": record["connectivity_cuts"],
        "pairing_space": record["pairing_space"],
        "elapsed_s": record["elapsed_s"],
    }, sort_keys=True))


def main():
    started = time.monotonic()
    deadline = started + 220.0
    base = json.loads(INPUT.read_text())
    vertices = base["vertices"]
    n = len(vertices)

    stubs = defaultdict(list)
    for vertex, record in enumerate(vertices):
        for block in record["blocks"]:
            if record["kind"] == "terminal" and block == record["terminal_block"]:
                continue
            stubs[block].append(vertex)
    assert all(len(items) % 2 == 0 for items in stubs.values())
    assert sum(map(len, stubs.values())) == 196

    block_column = {}
    for item in base["proper_edges"]:
        block = item["block"]
        if block in block_column:
            assert block_column[block] == item["column"]
        block_column[block] = item["column"]
    assert set(block_column) == set(stubs)

    outer = Solver()
    potential = []
    pair_var = {}
    incident_vars = defaultdict(list)
    for block in sorted(stubs):
        assert len(stubs[block]) == len(set(stubs[block]))
        for left, right in combinations(sorted(stubs[block]), 2):
            variable = Bool(f"pair_b{block}_v{left}_v{right}")
            pair_id = len(potential)
            potential.append({
                "pair_id": pair_id, "block": block,
                "column": block_column[block], "ends": [left, right],
            })
            pair_var[(block, left, right)] = variable
            incident_vars[(block, left)].append(variable)
            incident_vars[(block, right)].append(variable)
    assert len(potential) == 194
    for block, vertices_for_block in stubs.items():
        for vertex in vertices_for_block:
            outer.add(PbEq([(value, 1) for value in incident_vars[(block, vertex)]], 1))

    pairing_space = 1
    for vertices_for_block in stubs.values():
        pairing_space *= double_factorial_odd(len(vertices_for_block))
    assert pairing_space == 6_975_163_125

    iterations = []
    a_clauses = 0
    connectivity_cuts = 0
    final_candidate = None
    post_no_a = None
    status = None

    while status is None:
        result, reason = checked_solve(outer, deadline)
        if result == unknown:
            status = "unknown_at_outer"
            post_no_a = {"reason": reason}
            break
        if result != sat:
            status = (
                "all_loopless_pairings_have_A"
                if connectivity_cuts == 0
                else "all_connected_loopless_pairings_have_A"
            )
            break

        model = outer.model()
        chosen = []
        chosen_pair_ids = []
        for item in potential:
            block, left, right = item["block"], *item["ends"]
            if is_true(model.eval(pair_var[(block, left, right)])):
                chosen_pair_ids.append(item["pair_id"])
                chosen.append({
                    "block": block, "column": item["column"],
                    "ends": [left, right],
                })
        assert len(chosen) == 98
        graph_record = dict(base)
        graph_record["proper_edges"] = chosen
        graph = FixedMultigraph(graph_record)
        selected = selected_family_checks(graph)
        graph_components = components(n, graph.edges)
        candidate_hash = hashlib.sha256(
            json.dumps(chosen_pair_ids, separators=(",", ":")).encode()
        ).hexdigest()

        a_result = a_query(graph, deadline)
        iteration = {
            "iteration": len(iterations),
            "candidate_sha256": candidate_hash,
            "chosen_pair_ids": chosen_pair_ids,
            "components": [list(item) for item in graph_components],
            "A_status": a_result["status"],
        }
        if a_result["status"] == "unknown":
            iteration["A_reason"] = a_result.get("reason")
            iterations.append(iteration)
            status = "unknown_at_inner_A"
            break

        if a_result["status"] == "sat":
            six_matchings = tuple(
                frozenset(item) for item in
                (*a_result["singletons"], a_result["all_terminal"])
            )
            stub_label = {}
            for edge, item in enumerate(chosen):
                label = sum(1 << index for index, matching in enumerate(six_matchings)
                            if edge in matching)
                assert label.bit_count() == 2
                block = item["block"]
                for vertex in item["ends"]:
                    stub_label[(block, vertex)] = label
            assert len(stub_label) == 196

            blocking_ids = []
            blocking_vars = []
            for item in potential:
                block, left, right = item["block"], *item["ends"]
                if stub_label[(block, left)] != stub_label[(block, right)]:
                    blocking_ids.append(item["pair_id"])
                    blocking_vars.append(pair_var[(block, left, right)])
            assert not set(chosen_pair_ids).intersection(blocking_ids)

            survival_pairings = 1
            for block, vertices_for_block in stubs.items():
                counts = Counter(stub_label[(block, vertex)]
                                 for vertex in vertices_for_block)
                assert all(count % 2 == 0 for count in counts.values())
                for count in counts.values():
                    survival_pairings *= double_factorial_odd(count)
            outer.add(Or(*blocking_vars) if blocking_vars else False)
            a_clauses += 1
            iteration.update({
                "blocking_pair_ids": blocking_ids,
                "blocking_clause_size": len(blocking_ids),
                "witness_survival_pairings_in_full_space": survival_pairings,
                "A_witness": a_result,
            })
            iterations.append(iteration)
            del graph
            gc.collect()
            continue

        assert a_result["status"] == "unsat"
        iteration["A_witness"] = None
        if len(graph_components) > 1:
            component_of = {
                vertex: index for index, component in enumerate(graph_components)
                for vertex in component
            }
            crossing_ids = []
            crossing_vars = []
            for item in potential:
                left, right = item["ends"]
                if component_of[left] != component_of[right]:
                    crossing_ids.append(item["pair_id"])
                    block = item["block"]
                    crossing_vars.append(pair_var[(block, left, right)])
            assert crossing_vars
            assert not set(chosen_pair_ids).intersection(crossing_ids)
            outer.add(Or(*crossing_vars))
            connectivity_cuts += 1
            iteration.update({
                "disconnected_no_A": True,
                "connectivity_cut_pair_ids": crossing_ids,
            })
            iterations.append(iteration)
            del graph
            gc.collect()
            continue

        iteration["connected_no_A"] = True
        iterations.append(iteration)
        final_candidate = {
            "candidate_sha256": candidate_hash,
            "chosen_pair_ids": chosen_pair_ids,
            "proper_edges": chosen,
        }

        tt_result = tt_query(graph, deadline)
        post_no_a = {"TT": tt_result}
        if tt_result["status"] == "sat":
            status = "connected_no_A_repaired_by_TT"
            break
        if tt_result["status"] == "unknown":
            status = "connected_no_A_unknown_at_TT"
            break

        fibre = dependent_fibre_query(graph, selected, deadline)
        post_no_a["dependent_fibre"] = fibre
        if fibre["status"] == "sat":
            status = "connected_no_A_repaired_by_dependent_fibre"
            break
        if fibre["status"] == "unknown":
            status = "connected_no_A_unknown_at_dependent_fibre"
            break

        positive = positive_case_xii_query(graph, deadline)
        post_no_a["positive_case_xii"] = positive
        if positive["status"] == "exact_positive_and_tait":
            status = "real_exact_case_xii_note082_counterexample_candidate"
        elif positive["status"] == "unknown":
            status = "connected_no_A_unknown_at_positive_case_xii"
        else:
            status = "connected_no_A_but_not_exact_case_xii"

    record = {
        "status": status,
        "input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        "order": n,
        "proper_stub_count": 196,
        "potential_pair_variables": len(potential),
        "pairing_space": pairing_space,
        "outer_domain": ("all_loopless_pairings" if connectivity_cuts == 0
                         else "connected_loopless_pairings_after_lazy_cuts"),
        "blocking_clause_lemma": (
            "A fixed six-matching incidence witness survives exactly when "
            "every selected same-column stub pair has equal six-bit labels; "
            "its negation is the recorded unequal-label OR clause."
        ),
        "iterations": len(iterations),
        "a_blocking_clauses": a_clauses,
        "connectivity_cuts": connectivity_cuts,
        "potential_pairs": potential,
        "iteration_records": iterations,
        "final_candidate": final_candidate,
        "post_no_A": post_no_a,
        "elapsed_s": time.monotonic() - started,
    }
    emit(record)
    if status in ("all_loopless_pairings_have_A",
                  "all_connected_loopless_pairings_have_A"):
        print("NOTE102_ALL_PAIRINGS_FORCE_A")
    elif status == "real_exact_case_xii_note082_counterexample_candidate":
        print("NOTE102_PAIRING_REAL_COUNTEREXAMPLE_CANDIDATE")
    elif status.startswith("unknown") or "_unknown_" in status:
        print("NOTE102_ALL_PAIRINGS_UNKNOWN")
    else:
        print("NOTE102_CONNECTED_NO_A_PAIRING_FOUND")


if __name__ == "__main__":
    main()
