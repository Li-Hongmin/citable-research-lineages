#!/usr/bin/env python3
"""Audit the literal-identity obstruction to arbitrary BF-factor lifts.

This is deliberately an abstract Note-082 normal-form audit, not a graph
search.  It reuses the occurrence/identity enumeration from the earlier K4
check and asks whether a *rigid six-factor BF cover* can be assigned globally
to exterior matching identities.  A rigid cover models the Petersen graph:
its six perfect matchings form its unique BF cover and all unordered pair
sums are distinct.

The script also reconstructs the Petersen perfect matchings to verify those
two rigidity assertions directly.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
import runpy


BASE_PATH = (
    Path(__file__).resolve().parents[1]
    / "worker-exact-irreducible-countermodel"
    / "check_two_splice_three_colour_lifts.py"
)
BASE = runpy.run_path(str(BASE_PATH))


def perfect_matchings(vertices, edges):
    incident = defaultdict(list)
    for index, (u, v) in enumerate(edges):
        incident[u].append((index, v))
        incident[v].append((index, u))

    def rec(unmatched, chosen):
        if not unmatched:
            yield frozenset(chosen)
            return
        u = min(unmatched)
        for edge_index, v in incident[u]:
            if v not in unmatched:
                continue
            yield from rec(
                unmatched - {u, v}, chosen + (edge_index,)
            )

    yield from rec(frozenset(vertices), ())


def verify_petersen_rigidity():
    # Outer 5-cycle, inner 5-star, and five spokes.
    edges = []
    edges.extend((i, (i + 1) % 5) for i in range(5))
    edges.extend((5 + i, 5 + ((i + 2) % 5)) for i in range(5))
    edges.extend((i, 5 + i) for i in range(5))
    matchings = tuple(perfect_matchings(range(10), tuple(edges)))
    assert len(matchings) == 6

    edge_load = Counter(edge for matching in matchings for edge in matching)
    assert set(edge_load.values()) == {2}

    # Every BF multiset of six Petersen perfect matchings is the full set.
    bf_multisets = []
    for choices in combinations(range(11), 5):
        # stars-and-bars: multiplicities summing to six
        cuts = (-1,) + choices + (11,)
        multiplicities = tuple(cuts[i + 1] - cuts[i] - 1 for i in range(6))
        if all(
            sum(multiplicities[m] * (edge in matchings[m]) for m in range(6))
            == 2
            for edge in range(len(edges))
        ):
            bf_multisets.append(multiplicities)
    assert bf_multisets == [(1, 1, 1, 1, 1, 1)]

    pair_sums = {}
    for left in range(6):
        for right in range(left, 6):
            load = tuple(
                int(edge in matchings[left]) + int(edge in matchings[right])
                for edge in range(len(edges))
            )
            assert load not in pair_sums
            pair_sums[load] = (left, right)

    distinguished = 0
    bits = tuple(int(distinguished in matching) for matching in matchings)
    assert sum(bits) == 2
    return bits


def has_rigid_literal_lift(part, bits, identity_rows, replacements, factor_bits):
    """Assign one fixed Petersen factor to every exterior identity."""
    identity_count = len(bits)
    choices = tuple(
        tuple(factor for factor, factor_bit in enumerate(factor_bits)
              if factor_bit == bits[identity])
        for identity in range(identity_count)
    )

    order = tuple(sorted(range(identity_count), key=lambda i: len(choices[i])))
    assignment = [-1] * identity_count

    def partial_ok():
        for row in identity_rows:
            assigned = [assignment[i] for i in row if assignment[i] >= 0]
            if len(assigned) != len(set(assigned)):
                return False
        for old, new in replacements:
            old_values = [assignment[part[token]] for token in old]
            new_values = [assignment[part[token]] for token in new]
            if min(old_values + new_values) >= 0:
                if sorted(old_values) != sorted(new_values):
                    return False
        return True

    def rec(depth):
        if depth == len(order):
            return tuple(assignment)
        identity = order[depth]
        for factor in choices[identity]:
            assignment[identity] = factor
            if partial_ok():
                found = rec(depth + 1)
                if found is not None:
                    return found
        assignment[identity] = -1
        return None

    return rec(0)


def main():
    factor_bits = verify_petersen_rigidity()
    counts = Counter()
    failures = []

    for first_edge in BASE["SPLICE_EDGES"]:
        for second_edge in BASE["SPLICE_EDGES"]:
            if not ({BASE["P3"], BASE["P5"]}
                    <= (set(first_edge) | set(second_edge))):
                continue
            rows = BASE["rows_for_shape"](first_edge, second_edge)
            replacements = BASE["splice_token_pairs"](
                rows, first_edge, second_edge
            )
            for part in BASE["partitions"](10):
                identity_rows = tuple(BASE["identity_row"](row, part) for row in rows)
                if not BASE["boundary_consistent"](part, rows):
                    continue
                if any(max(Counter(row).values()) > 2 for row in identity_rows):
                    continue
                if any(not BASE["valid_pair_replacement"](old, new, part)
                       for old, new in replacements):
                    continue
                identity_replacements = tuple(
                    (tuple(part[token] for token in old),
                     tuple(part[token] for token in new))
                    for old, new in replacements
                )
                if any(sorted(old) == sorted(new)
                       for old, new in identity_replacements):
                    counts["trivial_splice_patterns"] += 1
                    continue
                if not BASE["boundary_realisable"](part, rows, replacements):
                    continue
                if BASE["forces_direct_singleton_pair_equality"](
                    part, identity_rows, replacements
                ):
                    continue
                patterns = tuple(BASE["bit_patterns"](
                    part, identity_rows, replacements
                ))
                if not BASE["incidence_separable"](patterns, max(part) + 1):
                    continue

                for bits in patterns:
                    counts["admissible_bit_patterns"] += 1
                    row_distinct = all(len(set(row)) == 6 for row in identity_rows)
                    degenerate_target = (
                        identity_rows[0][BASE["P3"]]
                        == identity_rows[2][BASE["P3"]]
                        or identity_rows[0][BASE["P5"]]
                        == identity_rows[2][BASE["P5"]]
                    )
                    if row_distinct:
                        counts["row_distinct_patterns"] += 1
                    if degenerate_target:
                        counts["degenerate_target_patterns"] += 1
                    lift = has_rigid_literal_lift(
                        part, bits, identity_rows, replacements, factor_bits
                    )
                    if lift is not None:
                        counts["literal_lifts"] += 1
                        continue
                    counts["literal_failures"] += 1
                    counts[
                        "row_distinct_failures" if row_distinct
                        else "within_row_collision_failures"
                    ] += 1
                    if not degenerate_target:
                        counts["nondegenerate_failures"] += 1
                        if row_distinct:
                            counts["nondegenerate_row_distinct_failures"] += 1
                    failures.append({
                        "shape": (first_edge, second_edge),
                        "partition": part,
                        "rows": identity_rows,
                        "replacements": identity_replacements,
                        "bits": bits,
                        "identity_count": max(part) + 1,
                        "degenerate_target": degenerate_target,
                    })

    failures.sort(key=lambda record: (
        record["identity_count"],
        all(len(set(row)) == 6 for row in record["rows"]),
        record["shape"], record["partition"], record["bits"],
    ))
    print("petersen_factor_bits", factor_bits)
    print("counts", dict(counts))
    print("minimum_failure", failures[0] if failures else None)
    print(
        "minimum_row_distinct_failure",
        next((record for record in failures
              if all(len(set(row)) == 6 for row in record["rows"])), None),
    )
    print(
        "minimum_nondegenerate_failure",
        next((record for record in failures
              if not record["degenerate_target"]), None),
    )
    print(
        "minimum_nondegenerate_row_distinct_failure",
        next((record for record in failures
              if not record["degenerate_target"]
              and all(len(set(row)) == 6 for row in record["rows"])), None),
    )
    print("ARBITRARY_BF_FACTOR_LITERAL_COLLISIONS_AUDITED")


if __name__ == "__main__":
    main()
