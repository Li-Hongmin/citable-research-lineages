# Exact negative support does not yet close the repeated-star overload gate

Consider the repeated-extension identities

\[
 U=\{A,B,C,D,X,Y\}
\]

with singleton boundaries $1,2,4,5,3,3$, respectively, and the four
literal BF rows

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.          \tag{1}
\]

The associated triple-state pairs are

\[
 (13,45),\quad(14,23),\quad(24,15),\quad(25,34).   \tag{2}
\]

Assume throughout that the complete BF support has no $T$-loop and no
$T$--$T$ type.  The question is whether the three target singleton
tuples

\[
 BDXY,\qquad ACXY,\qquad ABDY                       \tag{3}
\]

can all be edge-overloaded.  The observations below isolate exactly why the
currently available negative-support consequences do not decide this.

## What no $T$-loops says about singleton matchings

If singleton-boundary perfect matchings $P_i,P_j$ are edge-disjoint, their
union uses two incidences at every internal cubic vertex.  The unused
incidences form a perfect matching with triple boundary
$[5]\setminus\{i,j\}$.  Doubling these three disjoint perfect matchings
gives the loop type $[ij]$.  Consequently, absence of the five $T$-loops
forces

\[
 A\cap B,\ A\cap D,\ B\cap X,\ B\cap Y,\
 X\cap C,\ Y\cap C,\ C\cap D\ne\varnothing.        \tag{4}
\]

Here the two conditions involving boundary $3$ must hold for both actual
choices $X,Y$.  Condition (4) is a genuine common-perfect-matching
constraint, but it is only pairwise intersection.  None of its seven
intersections contradicts any of the eight possible three-hit signatures
from Note 073.

## Exact residual-pairing consequence of a forbidden $T$--$T$ type

Each quartet in (1) has four distinct terminal ends.  Its nonnegative
residual multigraph from Note 078 therefore has two terminal paths.  Suppose
one partition of the four ends into two pair states is known to decompose
the residual.  The two terminal paths necessarily have the same parity:
one same-colour path and one opposite-colour path would use unequal numbers
of the two residual colours at the four ends.

There are then only two cases.

1. If the two paths have odd proper length, their geometric endpoint
   pairing is the unique feasible state partition.
2. If the two paths have even proper length, the geometric pairing is the
   unique infeasible state partition and the other two partitions are
   feasible.

For the four rows in (1), the known, allowed alternative, and forbidden
partitions are respectively

\[
\begin{array}{c|c|c|c}
\text{quartet}&\text{known }S\!T&\text{allowed }SS&\text{forbidden }TT\\ \hline
AXCD&13|45&14|35&15|34\\
ABXC&14|23&13|24&12|34\\
ABCD&24|15&14|25&12|45\\
BYCD&25|34&24|35&23|45.
\end{array}                                        \tag{5}
\]

Thus no $T$--$T$ support gives, row by row, the exact dichotomy

\[
\begin{cases}
\text{geometric pairing}=ST,\ \text{paths odd},\quad\text{or}\\
\text{geometric pairing}=TT,\ \text{paths even};
\end{cases}                                        \tag{6}
\]

in the second case the displayed $SS$ decomposition also exists.  This is
the full conclusion obtainable from the alternate pairing of one fixed
nonnegative residual.

## Why the three target tuples do not enter (5)

The boundary multiset of $BDXY$ is
$\{2,3,3,5\}$, so its only legal pair-state decomposition is
$23|35$.  Similarly, $ACXY$ has the unique decomposition $13|34$.
There is no second pairing on which a forbidden (T)--(T) hypothesis can
act.

The multiset of $ABDY$ is $\{1,2,3,5\}$ and does have three
partitions:

\[
 12|35\ (ST),\qquad13|25\ (SS),\qquad15|23\ (TT).  \tag{7}
\]

However, if $ABDY$ is overloaded, its residual has value $-1$ on the
overload edge.  Hence the literal quartet fails before the degree-two
residual and its three pairings exist.  The absence of the $15|23$ type
therefore supplies no additional restriction on this tuple.  Positive
support of the $ST$ and $SS$ cells supplies other singleton witnesses,
not the literal identities in (7); moving those witnesses to $A,B,D,Y$
is precisely the unproved companion-alignment step of Note 073.

## Exact remaining arrow

The three overload signatures and the consequences (4)--(6) do not yield a
contradiction by themselves.  What remains to be proved for a real pole is

\[
\begin{gathered}
\text{complete perfect-matching closure of one simple connected cubic pole}
\\
+\ \text{the four literal rows (1)}
+\ \text{no $T$-loop/$TT$}
+\ \text{the Note-019 irreducibility conditions}
\\
\Longrightarrow
\text{one of (3) has no edge of load three}.        \tag{8}
\end{gathered}
\]

Equivalently, if all three overloads occur, one must use a perfect matching
outside the fourteen displayed row identities to construct a forbidden
$T$-loop/$TT$ cover or to replace one literal singleton and cancel its
overload.  Neither the alternate pairing of a fixed pivot residual nor the
pairwise intersections in (4) produce that new matching.

This is an information boundary, not a proof or a real-pole counterexample
to (8).  No order parameter was searched.
