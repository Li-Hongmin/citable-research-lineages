#!/usr/bin/env python3
"""Check class-fixed sets and all incidence companion fibres in Note 085.

This script is read-only with respect to the frozen 125-token, 48-coordinate
model.  It does not synthesize tokens, coordinates, rows, or graph structure.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from itertools import combinations
from pathlib import Path


SEMIEDGE_COUNT = 5


def load_module(path):
    spec = importlib.util.spec_from_file_location("note085_model", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def vector_add_sub(a, b, c):
    return tuple(x + y - z for x, y, z in zip(a, b, c))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("model_script", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    payload = json.loads(args.input_json.read_text())
    module = load_module(args.model_script)
    builder = module.ModelBuilder().build()
    assert payload["status"] == "common_binary_countermodel"
    assert payload["tokens"] == 125 and payload["coordinates"] == 48
    assert len(builder.rows) == 50
    vectors = {
        token: tuple(int(bit) for bit in bits)
        for token, bits in payload["vectors"].items()
    }
    assert set(vectors) == set(builder.kind)

    singleton_classes = {
        position: tuple(
            token for token in sorted(vectors)
            if builder.kind[token] == "singleton"
            and builder.boundary[token] == position
        )
        for position in range(1, 6)
    }
    fixed_sets = {}
    for position, tokens in singleton_classes.items():
        assert tokens
        fixed_sets[position] = tuple(
            coordinate for coordinate in range(SEMIEDGE_COUNT, payload["coordinates"])
            if all(vectors[token][coordinate] for token in tokens)
        )
    fixed_intersections = {
        f"{first},{second}": sorted(set(fixed_sets[first]) & set(fixed_sets[second]))
        for first, second in combinations(range(1, 6), 2)
    }
    assert all(not intersection for intersection in fixed_intersections.values())

    canonical_keys = tuple(builder.LITERAL_SEEDS) if hasattr(builder, "LITERAL_SEEDS") else tuple(module.LITERAL_SEEDS)
    # ModelBuilder stores the corresponding positive ST rows in st_base.
    pivot_rows = {
        f"{s}-{t}": builder.st_base[(s, t)] for s, t in module.LITERAL_SEEDS
    }
    overloaded_cases = []
    empty_all_replacement_cases = []
    absorbable_cases = []
    for row_name, row in pivot_rows.items():
        assert len(row) == 6
        for coordinate in range(SEMIEDGE_COUNT, payload["coordinates"]):
            singleton_users = [
                (occurrence, token, builder.boundary[token])
                for occurrence, token in enumerate(row)
                if builder.kind[token] == "singleton" and vectors[token][coordinate]
            ]
            if len({position for _, _, position in singleton_users}) < 2:
                continue
            case = {
                "row": row_name,
                "row_tokens": list(row),
                "coordinate": coordinate,
                "singleton_users": [
                    {"occurrence": occurrence, "token": token, "class": position}
                    for occurrence, token, position in singleton_users
                ],
                "replacement_tests": [],
            }
            any_replacement = False
            any_absorption = False
            for occurrence, token, position in singleton_users:
                replacements = [
                    replacement for replacement in singleton_classes[position]
                    if replacement != token and not vectors[replacement][coordinate]
                ]
                for replacement in replacements:
                    any_replacement = True
                    absorptions = []
                    for companion_occurrence, companion in enumerate(row):
                        if companion_occurrence == occurrence:
                            continue
                        expression = vector_add_sub(
                            vectors[companion], vectors[token], vectors[replacement]
                        )
                        outputs = [
                            candidate for candidate in vectors
                            if builder.kind[candidate] == builder.kind[companion]
                            and builder.boundary[candidate] == builder.boundary[companion]
                            and vectors[candidate] == expression
                        ]
                        if outputs:
                            absorptions.append({
                                "companion_occurrence": companion_occurrence,
                                "companion": companion,
                                "outputs": sorted(outputs),
                            })
                    if absorptions:
                        any_absorption = True
                    case["replacement_tests"].append({
                        "source_occurrence": occurrence,
                        "source": token,
                        "class": position,
                        "replacement": replacement,
                        "absorptions": absorptions,
                    })
            assert any_replacement, (row_name, coordinate, singleton_users)
            case["replacement_count"] = len(case["replacement_tests"])
            case["absorbable_replacement_count"] = sum(
                bool(test["absorptions"]) for test in case["replacement_tests"]
            )
            overloaded_cases.append(case)
            if not any_absorption:
                empty_all_replacement_cases.append(case)
            else:
                absorbable_cases.append(case)

    # Even when every incidence fibre is empty, the frozen object has no
    # graph/component relation and cannot certify that an avoiding pair is a
    # one-component alternating-cycle switch.  Therefore it does not decide
    # the one-component claim.
    status = "fixed_object_does_not_distinguish_one_component_claim"
    result = {
        "status": status,
        "tokens": len(vectors),
        "coordinates": payload["coordinates"],
        "positive_pair_rows": 40,
        "canonical_pivot_rows": len(pivot_rows),
        "singleton_class_sizes": {
            str(position): len(tokens) for position, tokens in singleton_classes.items()
        },
        "class_fixed_sets": {
            str(position): list(coordinates) for position, coordinates in fixed_sets.items()
        },
        "class_fixed_intersections": fixed_intersections,
        "overloaded_pivot_row_edge_cases": len(overloaded_cases),
        "cases_with_some_absorption": len(absorbable_cases),
        "cases_with_all_replacement_fibres_empty": len(empty_all_replacement_cases),
        "all_relevant_incidence_replacement_fibres_empty": (
            len(empty_all_replacement_cases) == len(overloaded_cases)
        ),
        "empty_case_certificates": empty_all_replacement_cases,
        "absorbable_case_certificates": absorbable_cases,
        "one_component_relation_encoded": False,
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key not in ("empty_case_certificates", "absorbable_case_certificates")}
    print(json.dumps(compact, indent=2, sort_keys=True))
    print("NOTE085_ONE_COMPONENT_CLAIM_NOT_DISTINGUISHED")


if __name__ == "__main__":
    main()
