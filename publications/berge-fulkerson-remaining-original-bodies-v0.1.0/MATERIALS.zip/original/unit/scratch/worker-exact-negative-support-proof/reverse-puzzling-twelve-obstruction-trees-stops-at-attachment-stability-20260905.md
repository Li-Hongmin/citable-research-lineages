# Reverse-puzzling the twelve obstruction trees stops at attachment stability

The proposed counterexample would be a real simple connected cubic
five-pole whose complete BF boundary support is exactly the Case-XII set

\[
 15\;S\text{--}S+25\;S\text{--}T,
\]

with no all-terminal, \(T\)-loop, or \(T\)--\(T\) type, and for which all
four Note-093 carrier projections miss their three agreement-region
families.  The twelve obstruction trees give an exact *verification*
language once a graph and its complete matching family are fixed.  They do
not yet give attachment-stable gadgets from which such a graph can be
assembled in reverse.

## The cheapest reverse construction

For one endpoint \((K,H,\widehat P)\) and one fixed-half occurrence
\(L\in H\), the smallest possible obstruction tree would have one
agreement-region candidate and one residual leaf.

Choose the agreement vertex set so that

\[
 J_L=G[A_L]
\]

has the unique perfect matching

\[
 F_L=L\cap\widehat P\cap E_{\rm proper}.          \tag{1}
\]

Then the only member of the fixed-half preimage is \(\widehat P\).  It can
be excluded from the carrier projection by a support witness: choose an
edge

\[
 e\in\widehat P,\qquad H(e)=2,qquad K(e)=0.       \tag{2}
\]

Now \(K-\widehat P\) is negative on \(e\), so it has no oriented residual
decomposition.  Repeating (1)--(2) for the three fixed occurrences and the
four endpoint roles would formally give twelve one-leaf certificates.

There is no immediate pointwise trivalent contradiction in this template.
The four endpoint targets may use four disjoint support edges, and each
edge can be assigned to the target matching and two fixed-half matching
occurrences without violating the rule that each matching chooses one
incidence at a vertex.  Thus local edge loads alone do not stop the
construction.

## Why these leaves are not composable gadgets

The agreement graph \(J_L\) is the **induced** proper-edge graph on the
vertices where \(L\) and \(\widehat P\) use the same proper incidence.  It
is therefore determined only after all blocks have been attached.  A
connector is not external to this certificate merely because it was
external to the provisional block.

The minimum failure is already visible on four agreement vertices.  Before
attachment, let

\[
 F_L=\{ab,cd\}
\]

be the unique perfect matching of two isolated edges.  If cubic completion
adds the physical edges \(ac\) and \(bd\), the induced agreement graph
becomes the four-cycle with perfect matchings

\[
 \{ab,cd\},\qquad\{ac,bd\}.                       \tag{3}
\]

The second matching in (3) creates a new actual fixed-half preimage
\(P_L(\{ac,bd\})\).  The support obstruction (2) was attached only to
\(\widehat P=P_L(F_L)\); it says nothing about the new residual load.  The
one-leaf tree is no longer valid.

This is not repaired by naming all physical edges inside each provisional
block.  The twelve agreement sets overlap through the common literal
matchings \(A,B,C,D,X,Y,r_{23},r_{34}\).  An attachment edge which is
outside one agreement set can lie inside another.  Hence the twelve
no-chord requirements cannot be enforced independently.

The first common physical condition required by the reverse construction
is the simultaneous attachment-stability system

\[
 \boxed{
 \begin{aligned}
 &G[A_{h,L}]\text{ has exactly the branch matchings certified by }
   \mathcal T_{h,L},\\
 &K_h-P_{L}(M)\text{ retains its designated support, odd-cycle, or
   terminal-path obstruction}\\
 &\hspace{35mm}
   \text{for every }h,L\text{ and every }M\in\operatorname{PM}(G[A_{h,L}]).
 \end{aligned}}
                                                               \tag{4}
\]

Equation (4) is one coupled constraint on the final physical graph, not
twelve independent local constraints.  None of the obstruction-tree
alternatives supplies a finite port signature which guarantees (4) under
cubic attachment.  Treating the leaves as ordinary gadgets therefore
assumes the fact that the completed graph was meant to prove.

## Full-closure leakage is the next gate

Even if one could satisfy (4), it would certify only the four empty
projection intersections for the two displayed carrier loads.  Exact
Case-XII support is a separate statement about the complete matching
closure.  For a final pole \(G\), put

\[
 \mathfrak B(G)=
 \left\{(\partial Q,\partial R):
 \chi_Q+\chi_R+\sum_{a=1}^{4}\chi_{P_a}=2\mathbf1
 \text{ for actual }Q,R,P_a\in\mathcal P(G)\right\}.           \tag{5}
\]

The required equality is the exact forty-type set, not merely containment
of the four pivot rows.  Connecting the provisional blocks changes
\(\mathcal P(G)\): alternating routes which cross connectors can create new
agreement preimages, new carrier decompositions, and forbidden
all-terminal or \(T\)--\(T\) rows.  Conversely, isolating every block can
destroy some of the required 25 \(S\)--\(T\) rows.  The twelve trees impose
no condition on rows with other fixed halves and therefore do not decide
(5).

Support-preserving two-terminal replacements would avoid this leakage, but
then the construction is circular: the completed pole has exact forty
support only if the seed already has exact forty support.  No real seed is
available.  A support-changing connector would require an explicit final
edge set before its complete closure could be checked.

## Decision

No single drawable cubic candidate follows analytically from the twelve
obstruction families.  The cheapest reverse template (1)--(2) fails before
there is a candidate edge set because agreement-region certificates are
not stable under attachment; the precise first unsatisfied common relation
is (4).  Exact full-boundary closure (5) is the next independent gate.

This is not a proof that the requested real pole cannot exist and not a
counterexample.  It is a strict construction boundary: reverse-puzzling
Tutte/residual leaves becomes legitimate only after an attachment theorem
simultaneously preserves all twelve induced agreement graphs and residual
obstructions.  Since no such interface was obtained, there is no justified
candidate to send to Omen, and no computation was run.
