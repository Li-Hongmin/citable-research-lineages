#!/usr/bin/env python3
"""Check one fixed strong 5-pole for a class-fixed proper edge.

The pole is the side obtained from generalized Petersen G(10,2), i.e. the
dodecahedral graph, by deleting the even inner 5-cycle and cutting its five
spokes.  No graph family or graph order is searched.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict, deque
from itertools import combinations
from pathlib import Path


def closed_dodecahedron():
    # Outer vertices u_i are i; inner vertices v_i are 10+i.
    edges = []
    for i in range(10):
        edges.append((i, (i + 1) % 10, f"outer:{i}"))
    for i in range(10):
        a, b = 10 + i, 10 + ((i + 2) % 10)
        if a < b:
            edges.append((a, b, f"inner:{i}-{(i + 2) % 10}"))
        else:
            edges.append((b, a, f"inner:{i}-{(i + 2) % 10}"))
    # The preceding loop lists each inner edge once: step 2 on two C5s.
    assert len({(u, v) for u, v, _ in edges}) == 20
    for i in range(10):
        edges.append((i, 10 + i, f"spoke:{i}"))
    assert len(edges) == 30
    return tuple(range(20)), tuple(edges)


def face_complement_pole():
    # Keep all outer vertices and the odd inner 5-cycle.
    kept_closed = tuple(range(10)) + tuple(10 + i for i in range(1, 10, 2))
    relabel = {vertex: index for index, vertex in enumerate(kept_closed)}
    _, closed_edges = closed_dodecahedron()
    proper = []
    for u, v, name in closed_edges:
        if u in relabel and v in relabel:
            proper.append((relabel[u], relabel[v], name))
    semiedges = []
    for terminal, outer in enumerate(range(0, 10, 2)):
        semiedges.append((relabel[outer], f"semi:{terminal}"))
    assert len(proper) == 20 and len(semiedges) == 5
    return tuple(range(15)), tuple(proper), tuple(semiedges), relabel


def adjacency(vertices, edges, excluded=frozenset()):
    adj = {v: [] for v in vertices}
    for edge_id, (u, v, _) in enumerate(edges):
        if edge_id in excluded:
            continue
        adj[u].append((v, edge_id))
        adj[v].append((u, edge_id))
    return adj


def components(vertices, edges, excluded=frozenset()):
    adj = adjacency(vertices, edges, excluded)
    seen = set()
    result = []
    for start in vertices:
        if start in seen:
            continue
        queue = deque([start])
        seen.add(start)
        component = []
        while queue:
            vertex = queue.popleft()
            component.append(vertex)
            for neighbour, _ in adj[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        result.append(tuple(sorted(component)))
    return tuple(result)


def girth(vertices, edges):
    adj = adjacency(vertices, edges)
    best = None
    for start in vertices:
        distance = {start: 0}
        parent = {start: None}
        queue = deque([start])
        while queue:
            vertex = queue.popleft()
            for neighbour, _ in adj[vertex]:
                if neighbour not in distance:
                    distance[neighbour] = distance[vertex] + 1
                    parent[neighbour] = vertex
                    queue.append(neighbour)
                elif parent[vertex] != neighbour:
                    length = distance[vertex] + distance[neighbour] + 1
                    best = length if best is None else min(best, length)
    return best


def component_is_tree(component, edges, excluded):
    members = set(component)
    edge_count = sum(
        edge_id not in excluded and u in members and v in members
        for edge_id, (u, v, _) in enumerate(edges)
    )
    return edge_count == len(component) - 1


def proper_two_edge_cuts(vertices, edges, terminal_vertices):
    cuts = []
    for first, second in combinations(range(len(edges)), 2):
        excluded = frozenset((first, second))
        comps = components(vertices, edges, excluded)
        if len(comps) == 1:
            continue
        tree_sides = []
        for component in comps:
            terminals = sorted(set(component) & set(terminal_vertices))
            if terminals and component_is_tree(component, edges, excluded):
                tree_sides.append({"vertices": list(component), "terminals": terminals})
        cuts.append({
            "edges": [first, second],
            "component_sizes": [len(component) for component in comps],
            "terminal_tree_sides": tree_sides,
        })
    return cuts


def enumerate_perfect_matchings(vertices, proper, semiedges):
    objects = []
    for edge_id, (u, v, name) in enumerate(proper):
        objects.append((f"p:{edge_id}:{name}", (u, v), edge_id, None))
    for terminal, (vertex, name) in enumerate(semiedges):
        objects.append((f"s:{terminal}:{name}", (vertex,), None, terminal))
    incident = defaultdict(list)
    for object_id, (_, endpoints, _, _) in enumerate(objects):
        for vertex in endpoints:
            incident[vertex].append(object_id)

    results = []

    def rec(uncovered, selected):
        if not uncovered:
            proper_set = frozenset(
                objects[object_id][2] for object_id in selected
                if objects[object_id][2] is not None
            )
            boundary = tuple(sorted(
                objects[object_id][3] for object_id in selected
                if objects[object_id][3] is not None
            ))
            results.append((proper_set, boundary))
            return
        vertex = min(
            uncovered,
            key=lambda v: sum(set(objects[obj][1]) <= uncovered for obj in incident[v]),
        )
        for object_id in incident[vertex]:
            endpoints = set(objects[object_id][1])
            if endpoints <= uncovered:
                rec(uncovered - endpoints, selected + (object_id,))

    rec(frozenset(vertices), tuple())
    assert len(results) == len(set(results))
    return tuple(results)


def induced_contains_cycle(mask, vertex_count, edge_pairs):
    members = [vertex for vertex in range(vertex_count) if mask >> vertex & 1]
    if len(members) < 3:
        return False
    adj = {vertex: [] for vertex in members}
    for u, v in edge_pairs:
        if (mask >> u & 1) and (mask >> v & 1):
            adj[u].append(v)
            adj[v].append(u)
    seen = set()
    for start in members:
        if start in seen:
            continue
        queue = [start]
        seen.add(start)
        vertex_count_component = 0
        degree_sum = 0
        while queue:
            vertex = queue.pop()
            vertex_count_component += 1
            degree_sum += len(adj[vertex])
            for neighbour in adj[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        if degree_sum // 2 >= vertex_count_component:
            return True
    return False


def cyclic_edge_connectivity_at_least_five(vertices, edges):
    assert vertices == tuple(range(len(vertices)))
    edge_pairs = tuple((u, v) for u, v, _ in edges)
    full = (1 << len(vertices)) - 1
    minimum = None
    witness = None
    # Put vertex 0 on one fixed side to avoid testing complementary cuts twice.
    for mask in range(1, full):
        if not (mask & 1):
            continue
        complement = full ^ mask
        if not induced_contains_cycle(mask, len(vertices), edge_pairs):
            continue
        if not induced_contains_cycle(complement, len(vertices), edge_pairs):
            continue
        cut = sum(((mask >> u) & 1) != ((mask >> v) & 1) for u, v in edge_pairs)
        if minimum is None or cut < minimum:
            minimum = cut
            witness = mask
    return minimum, witness


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    vertices, proper, semiedges, _ = face_complement_pole()
    terminal_vertices = tuple(vertex for vertex, _ in semiedges)
    assert len(set(terminal_vertices)) == 5
    assert len({tuple(sorted((u, v))) for u, v, _ in proper}) == len(proper)
    assert len(components(vertices, proper)) == 1
    proper_degree = Counter()
    for u, v, _ in proper:
        proper_degree[u] += 1
        proper_degree[v] += 1
    for vertex, _ in semiedges:
        proper_degree[vertex] += 1
    assert all(proper_degree[vertex] == 3 for vertex in vertices)
    pole_girth = girth(vertices, proper)
    assert pole_girth >= 5
    bridges = [edge_id for edge_id in range(len(proper))
               if len(components(vertices, proper, frozenset((edge_id,)))) > 1]
    assert not bridges

    cuts = proper_two_edge_cuts(vertices, proper, terminal_vertices)
    edges_in_any_two_cut = {
        edge_id for cut in cuts for edge_id in cut["edges"]
    }
    matchings = enumerate_perfect_matchings(vertices, proper, semiedges)
    singleton_classes = {}
    fixed_edges = {}
    strong_fixed = []
    for terminal in range(5):
        members = [proper_set for proper_set, boundary in matchings
                   if boundary == (terminal,)]
        singleton_classes[terminal] = members
        forced = set.intersection(*(set(matching) for matching in members)) if members else set()
        fixed_edges[terminal] = sorted(forced)
        for edge_id in sorted(forced - edges_in_any_two_cut):
            strong_fixed.append((terminal, edge_id))

    closed_vertices, closed_edges = closed_dodecahedron()
    closed_cyclic_connectivity, closed_witness = cyclic_edge_connectivity_at_least_five(
        closed_vertices, closed_edges
    )
    assert closed_cyclic_connectivity >= 5

    result = {
        "status": "strong_fixed_edge_found" if strong_fixed else "fixed_candidate_no_strong_edge",
        "construction": "G(10,2) minus the even inner C5",
        "vertices": len(vertices),
        "proper_edges": len(proper),
        "semiedges": len(semiedges),
        "terminal_vertices": list(terminal_vertices),
        "simple": True,
        "connected": True,
        "girth": pole_girth,
        "bridges": bridges,
        "proper_two_edge_cuts": cuts,
        "singleton_class_sizes": {
            str(terminal): len(members) for terminal, members in singleton_classes.items()
        },
        "fixed_edges_by_class": {
            str(terminal): edge_ids for terminal, edge_ids in fixed_edges.items()
        },
        "strong_fixed_pairs": [
            {
                "terminal_class": terminal,
                "edge_id": edge_id,
                "edge": list(proper[edge_id]),
                "class_matchings": [sorted(matching)
                                    for matching in singleton_classes[terminal]],
            }
            for terminal, edge_id in strong_fixed
        ],
        "all_perfect_matchings": len(matchings),
        "closed_graph": "generalized Petersen G(10,2)",
        "closed_graph_vertices": len(closed_vertices),
        "closed_graph_edges": len(closed_edges),
        "closed_graph_cyclic_edge_connectivity": closed_cyclic_connectivity,
        "closed_graph_min_cut_witness_mask": closed_witness,
        "cut_edges_to_deleted_face": [f"spoke:{i}" for i in range(0, 10, 2)],
        "proper_edge_table": [
            {"id": edge_id, "u": u, "v": v, "name": name}
            for edge_id, (u, v, name) in enumerate(proper)
        ],
    }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key not in ("proper_two_edge_cuts", "strong_fixed_pairs",
                              "proper_edge_table")}
    print(json.dumps(compact, indent=2, sort_keys=True))
    if strong_fixed:
        print("DODECAHEDRON_FACE_COMPLEMENT_STRONG_FIXED_EDGE_FOUND")
    else:
        print("DODECAHEDRON_FACE_COMPLEMENT_NO_STRONG_FIXED_EDGE")


if __name__ == "__main__":
    main()
