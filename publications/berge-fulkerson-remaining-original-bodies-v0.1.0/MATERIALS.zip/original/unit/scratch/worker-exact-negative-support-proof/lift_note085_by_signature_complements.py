#!/usr/bin/env python3
"""Lift the frozen Note-085 signatures to a trivalent multigraph incidence.

For every frozen coordinate c, solve for legal binary signatures d,e with
c+d+e=1 tokenwise.  Jointly choose the ten complements of the five terminal
coordinates so that equal signatures can be paired into proper edges.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter, deque
from pathlib import Path

from z3 import Bool, If, Implies, Solver, Sum, is_true, sat, unknown


SEMIEDGE_COUNT = 5


def zsum(terms):
    terms = list(terms)
    return Sum(*terms) if terms else 0


def load_model_module(path):
    spec = importlib.util.spec_from_file_location("note085_model", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_frozen(path):
    payload = json.loads(path.read_text())
    token_names = tuple(sorted(payload["vectors"]))
    vectors = payload["vectors"]
    coordinate_count = payload["coordinates"]
    assert len(token_names) == payload["tokens"] == 125
    assert coordinate_count == 48
    assert payload["coordinate_names"][:5] == [
        "terminal:1", "terminal:2", "terminal:3", "terminal:4", "terminal:5"
    ]
    columns = []
    for coordinate in range(coordinate_count):
        columns.append(tuple(int(vectors[token][coordinate]) for token in token_names))
    return payload, token_names, tuple(columns)


def token_load(bits, row):
    counts = Counter(row)
    return zsum(
        multiplicity * If(bits[token], 1, 0)
        for token, multiplicity in counts.items()
    )


def add_legal_signature(solver, bits, builder):
    for row in builder.rows:
        solver.add(token_load(bits, row) == 2)
    for old, new, z0, z1 in builder.cube_relations:
        solver.add(
            If(bits[z0], 1, 0) + If(bits[z1], 1, 0)
            == If(bits[old], 1, 0) + If(bits[new], 1, 0)
        )


def model_signature(model, bits, token_names):
    return tuple(1 if is_true(model.eval(bits[token])) else 0 for token in token_names)


def solve_one_complement_pair(builder, token_names, column, coordinate, timeout_ms):
    solver = Solver()
    solver.set(timeout=timeout_ms)
    d = {token: Bool(f"c{coordinate}_d_{index}")
         for index, token in enumerate(token_names)}
    e = {token: Bool(f"c{coordinate}_e_{index}")
         for index, token in enumerate(token_names)}
    for index, token in enumerate(token_names):
        solver.add(
            If(d[token], 1, 0) + If(e[token], 1, 0) == 1 - column[index]
        )
    add_legal_signature(solver, d, builder)
    add_legal_signature(solver, e, builder)
    status = solver.check()
    if status == unknown:
        return "unknown", solver.reason_unknown(), None
    if status != sat:
        return "unsat", None, None
    model = solver.model()
    return "sat", None, (
        model_signature(model, d, token_names),
        model_signature(model, e, token_names),
    )


def solve_terminal_joint_pairing(builder, token_names, columns, timeout_ms):
    solver = Solver()
    solver.set(timeout=timeout_ms)
    slots = []
    for terminal in range(SEMIEDGE_COUNT):
        for side in range(2):
            bits = {token: Bool(f"terminal_{terminal}_{side}_{index}")
                    for index, token in enumerate(token_names)}
            add_legal_signature(solver, bits, builder)
            slots.append(bits)
        d, e = slots[-2:]
        for index, token in enumerate(token_names):
            solver.add(
                If(d[token], 1, 0) + If(e[token], 1, 0)
                == 1 - columns[terminal][index]
            )

    pair = {}
    for first in range(len(slots)):
        for second in range(first + 1, len(slots)):
            variable = Bool(f"pair_{first}_{second}")
            pair[(first, second)] = variable
            for token in token_names:
                solver.add(Implies(variable, slots[first][token] == slots[second][token]))
    for slot in range(len(slots)):
        solver.add(zsum(
            variable for (first, second), variable in pair.items()
            if slot in (first, second)
        ) == 1)

    status = solver.check()
    if status == unknown:
        return "unknown", solver.reason_unknown(), None
    if status != sat:
        return "unsat", None, None
    model = solver.model()
    signatures = tuple(model_signature(model, bits, token_names) for bits in slots)
    pairing = tuple(
        (first, second) for (first, second), variable in pair.items()
        if is_true(model.eval(variable))
    )
    assert len(pairing) == 5
    assert all(signatures[first] == signatures[second] for first, second in pairing)
    return "sat", None, (signatures, pairing)


def signature_string(signature):
    return "".join(map(str, signature))


def verify_signature(signature, builder, token_index):
    assert all(sum(signature[token_index[token]] for token in row) == 2
               for row in builder.rows)
    assert all(
        signature[token_index[z0]] + signature[token_index[z1]]
        == signature[token_index[old]] + signature[token_index[new]]
        for old, new, z0, z1 in builder.cube_relations
    )


def build_multigraph(builder, token_names, frozen, proper_complements,
                     terminal_signatures, terminal_pairing):
    token_index = {token: index for index, token in enumerate(token_names)}
    vertices = []
    edges = []
    edge_signatures = []

    def add_edge(name, signature, endpoints, kind="proper"):
        edge_id = len(edges)
        edges.append({"id": edge_id, "name": name, "kind": kind,
                      "endpoints": list(endpoints)})
        edge_signatures.append(signature)
        return edge_id

    for coordinate in range(SEMIEDGE_COUNT, len(frozen)):
        first_vertex = len(vertices)
        second_vertex = first_vertex + 1
        d, e = proper_complements[coordinate]
        original_edge = add_edge(
            f"frozen:{coordinate}", frozen[coordinate],
            (first_vertex, second_vertex),
        )
        d_edge = add_edge(
            f"complement:{coordinate}:d", d, (first_vertex, second_vertex)
        )
        e_edge = add_edge(
            f"complement:{coordinate}:e", e, (first_vertex, second_vertex)
        )
        vertices.append({"id": first_vertex,
                         "incident_edges": [original_edge, d_edge, e_edge]})
        vertices.append({"id": second_vertex,
                         "incident_edges": [original_edge, d_edge, e_edge]})

    terminal_vertices = []
    terminal_semiedges = []
    terminal_slot_vertex = {}
    for terminal in range(SEMIEDGE_COUNT):
        vertex = len(vertices)
        terminal_vertices.append(vertex)
        semi = add_edge(
            f"semiedge:{terminal}", frozen[terminal], (vertex,), kind="semiedge"
        )
        terminal_semiedges.append(semi)
        vertices.append({"id": vertex, "incident_edges": [semi]})
        terminal_slot_vertex[2 * terminal] = vertex
        terminal_slot_vertex[2 * terminal + 1] = vertex

    for pair_index, (first, second) in enumerate(terminal_pairing):
        assert terminal_signatures[first] == terminal_signatures[second]
        u = terminal_slot_vertex[first]
        v = terminal_slot_vertex[second]
        edge = add_edge(
            f"terminal-complement:{pair_index}", terminal_signatures[first], (u, v)
        )
        vertices[u]["incident_edges"].append(edge)
        vertices[v]["incident_edges"].append(edge)

    assert len(vertices) == 91
    assert len(edges) == 139
    assert sum(edge["kind"] == "proper" for edge in edges) == 134
    assert sum(edge["kind"] == "semiedge" for edge in edges) == 5
    assert all(len(vertex["incident_edges"]) == 3 for vertex in vertices)

    for signature in edge_signatures:
        verify_signature(signature, builder, token_index)
    for row in builder.rows:
        for signature in edge_signatures:
            assert sum(signature[token_index[token]] for token in row) == 2

    token_edge_counts = {}
    for token in token_names:
        selected = [edge["id"] for edge, signature in zip(edges, edge_signatures)
                    if signature[token_index[token]]]
        coverage = [0] * len(vertices)
        for edge_id in selected:
            for vertex in edges[edge_id]["endpoints"]:
                coverage[vertex] += 1
        assert coverage == [1] * len(vertices)
        token_edge_counts[token] = len(selected)

    adjacency = [set() for _ in vertices]
    for edge in edges:
        if len(edge["endpoints"]) == 2:
            u, v = edge["endpoints"]
            adjacency[u].add(v)
            adjacency[v].add(u)
    components = []
    seen = set()
    for start in range(len(vertices)):
        if start in seen:
            continue
        queue = deque([start])
        seen.add(start)
        component = []
        while queue:
            vertex = queue.popleft()
            component.append(vertex)
            for neighbour in adjacency[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        components.append(tuple(sorted(component)))

    augmented_vectors = {
        token: tuple(signature[token_index[token]] for signature in edge_signatures)
        for token in token_names
    }
    return {
        "vertices": vertices,
        "edges": edges,
        "edge_signatures": [signature_string(signature)
                            for signature in edge_signatures],
        "terminal_vertices": terminal_vertices,
        "terminal_semiedges": terminal_semiedges,
        "components": [list(component) for component in components],
        "token_edge_counts": token_edge_counts,
        "augmented_vectors": augmented_vectors,
    }


def verify_negative_support(model_module, builder, frozen):
    synth = model_module.CoordinateSynthesizer(builder)
    synth.columns = [
        frozenset(token for token in synth.tokens
                  if frozen[coordinate][synth.tokens.index(token)])
        for coordinate in range(len(frozen))
    ]
    forbidden = model_module.evaluate_forbidden(synth)
    assert all(candidate is None for candidate in forbidden.values())
    return len(forbidden)


def verify_target_sections_empty(builder, augmented_vectors):
    failed_endpoint = 0
    failed_intermediate = 0
    for target in builder.targets:
        row = target["row"]
        for replacement in target["replacements"]:
            old = replacement["old"]
            new = replacement["new"]
            companions = list(row)
            companions.remove(old)
            for companion in companions:
                expression = tuple(
                    augmented_vectors[companion][i]
                    + augmented_vectors[old][i]
                    - augmented_vectors[new][i]
                    for i in range(len(augmented_vectors[old]))
                )
                candidates = [
                    token for token in augmented_vectors
                    if builder.boundary[token] == builder.boundary[companion]
                    and builder.kind[token] == builder.kind[companion]
                ]
                assert all(augmented_vectors[candidate] != expression
                           for candidate in candidates)
                failed_endpoint += 1
        old0, old1 = target["sources"]
        new0, new1 = target["desired"]
        for old, other_old in ((old0, old1), (old1, old0)):
            expression = tuple(
                augmented_vectors[new0][i] + augmented_vectors[new1][i]
                - augmented_vectors[other_old][i]
                for i in range(len(augmented_vectors[old]))
            )
            candidates = [
                token for token in augmented_vectors
                if builder.boundary[token] == builder.boundary[old]
                and builder.kind[token] == "singleton"
            ]
            assert all(augmented_vectors[candidate] != expression
                       for candidate in candidates)
            failed_intermediate += 1
    assert failed_endpoint == 30 and failed_intermediate == 6
    return failed_endpoint, failed_intermediate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("model_script", type=Path)
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    model_module = load_model_module(args.model_script)
    builder = model_module.ModelBuilder().build()
    payload, token_names, frozen = load_frozen(args.input_json)
    assert set(token_names) == set(builder.kind)

    complement_results = {}
    failures = []
    for coordinate, column in enumerate(frozen):
        status, reason, pair = solve_one_complement_pair(
            builder, token_names, column, coordinate, args.timeout_ms
        )
        if status != "sat":
            failures.append({"coordinate": coordinate, "status": status,
                             "reason": reason})
        else:
            complement_results[coordinate] = pair
    if failures:
        result = {
            "status": "individual_complement_failure",
            "failed_coordinates": failures,
            "minimal_failure_sets": [[item["coordinate"]] for item in failures],
            "successful_coordinates": len(complement_results),
        }
    else:
        terminal_status, terminal_reason, terminal_solution = solve_terminal_joint_pairing(
            builder, token_names, frozen, args.timeout_ms
        )
        if terminal_status != "sat":
            result = {
                "status": "terminal_joint_pairing_" + terminal_status,
                "reason": terminal_reason,
                "individual_complements": len(complement_results),
            }
        else:
            terminal_signatures, terminal_pairing = terminal_solution
            graph = build_multigraph(
                builder, token_names, frozen,
                {coordinate: complement_results[coordinate]
                 for coordinate in range(SEMIEDGE_COUNT, len(frozen))},
                terminal_signatures, terminal_pairing,
            )
            forbidden_types = verify_negative_support(model_module, builder, frozen)
            endpoint, intermediate = verify_target_sections_empty(
                builder, graph["augmented_vectors"]
            )
            result = {
                "status": "sat_trivalent_multigraph_incidence",
                "source_status": payload["status"],
                "tokens_verified_as_perfect_matchings": len(token_names),
                "designated_rows_verified": len(builder.rows),
                "frozen_signatures": len(frozen),
                "individual_complements": len(complement_results),
                "terminal_pairing": [list(pair) for pair in terminal_pairing],
                "terminal_complement_signatures": [
                    signature_string(signature) for signature in terminal_signatures
                ],
                "proper_complements": {
                    str(coordinate): [signature_string(signature) for signature in pair]
                    for coordinate, pair in complement_results.items()
                    if coordinate >= SEMIEDGE_COUNT
                },
                "vertices": len(graph["vertices"]),
                "proper_edges": sum(edge["kind"] == "proper"
                                    for edge in graph["edges"]),
                "semiedges": sum(edge["kind"] == "semiedge"
                                 for edge in graph["edges"]),
                "components": graph["components"],
                "vertex_certificate": graph["vertices"],
                "edge_pairing_certificate": graph["edges"],
                "edge_signatures": graph["edge_signatures"],
                "token_edge_counts": graph["token_edge_counts"],
                "negative_Tloop_TT_types_separated_by_frozen_prefix": forbidden_types,
                "failed_endpoint_memberships": endpoint,
                "failed_forced_intermediate_memberships": intermediate,
                "full_pm_closure_enumerated": False,
            }
    if args.json:
        args.json.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    compact = {key: value for key, value in result.items()
               if key not in (
                   "proper_complements", "terminal_complement_signatures",
                   "vertex_certificate", "edge_pairing_certificate",
                   "edge_signatures", "token_edge_counts", "components",
               )}
    print(json.dumps(compact, indent=2, sort_keys=True))
    if result["status"] == "sat_trivalent_multigraph_incidence":
        print("NOTE085_TRIVALENT_MULTIGRAPH_LIFT_SAT")
    elif "unknown" in result["status"]:
        print("NOTE085_TRIVALENT_MULTIGRAPH_LIFT_UNKNOWN")
    else:
        print("NOTE085_TRIVALENT_MULTIGRAPH_LIFT_UNSAT")


if __name__ == "__main__":
    main()
