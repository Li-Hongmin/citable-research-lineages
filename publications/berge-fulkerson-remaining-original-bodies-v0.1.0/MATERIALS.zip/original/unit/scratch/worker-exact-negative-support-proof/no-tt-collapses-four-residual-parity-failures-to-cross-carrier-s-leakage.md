# No-$TT$ collapses the four residual parity failures to unique cross-carrier $S$-leakages

## Statement

Work in one loopless cubic five-pole with its complete graph-induced
perfect-matching family.  Use the two literal anchored carriers

\[
K_{23}=2\mathbf 1-r_{23}-B-X,
\qquad
K_{34}=2\mathbf 1-r_{34}-Y-C
\]

and the four endpoint tests of Note 093.  Suppose the complete BF support
has no all-terminal type and no $T$--$T$ type, and suppose all four
intersections in Note 093(12) are empty.

For one endpoint write its data as

\[
(K,r_t,\widehat P_i;j),
\]

where $i$ is the boundary class of the restricted candidate, $j$ is
the intended other singleton colour in the carrier, and $t\in T$ is the
fixed triple state.  Let 

\[
\mathcal C_a(\widehat P_i),
\qquad a\in\{\mathrm{ent},0,1,2\},
\]

be the four restricted agreement-core families in the previous
sixteen-selector reduction.  Then every
$P\in\mathcal C_a(\widehat P_i)$ satisfies the full-closure blocker

\[
P\cap D_2(W_i)\ne\varnothing,                    \tag{1}
\]

and lies in exactly one of the following three classes:

1. $P(e)=1>K(e)$ on some edge;
2. $K-P\ge0$, but $K-P$ has an odd closed component;
3. $P$ belongs to one uniquely determined alternate $S$-projection
   
   \[
   P\in\mathcal F_i(K;j').                        \tag{2}
   \]

There is no remaining generic ``wrong terminal parity'' case.  The exact
four alternatives are

\[
\begin{array}{c|c|c|c|c|c}
\widehat P_i&K&t&i&j\text{ intended}&j'\text{ forced leakage}\\ \hline
Y&K_{23}&23&3&5&1\quad(q_{13}+P_1)\\
D&K_{23}&23&5&3&2\quad(q_{25}+P_2)\\
A&K_{34}&34&1&3&4\quad(q_{14}+P_4)\\
X&K_{34}&34&3&1&5\quad(q_{35}+P_5).
\end{array}                                                     \tag{3}
\]

Thus a real four-failure exact-Case-XII pole must cover all sixteen
restricted families by **negative residuals, odd residual cycles, or the
four cross-carrier $S$-leakages in (3)**.  This is strictly sharper than
the three residual obstructions in the earlier reduction.

## The no-$A$ blocker

For the four rows in (3), take respectively

\[
\begin{array}{c|c}
\widehat P_i&W_i\\ \hline
Y&A+B+C+D\\
D&A+B+X+C\\
A&B+Y+C+D\\
X&A+B+C+D.
\end{array}                                                     \tag{4}
\]

Each $W_i$ consists of singleton matchings in the four boundary classes
different from $i$, and each satisfies $W_i\le2\mathbf1$ because it is
the singleton quartet of one of the four literal pivot rows.

If a class-$i$ perfect matching $P$ avoided

\[
D_2(W_i)=\{e:W_i(e)=2\},
\]

then $W_i+P\le2\mathbf1$.  At an internal cubic vertex the five matching
incidences have total load five, so the three incident loads are
$(2,2,1)$.  Across the five terminals each semiedge has load one; at any
one terminal its two proper-edge loads sum to four and are therefore both
two.  Hence the same local conclusion holds.  Therefore

\[
2\mathbf1-W_i-P
\]

is an all-terminal perfect matching.  Together with the five singleton
matchings it gives a forbidden all-terminal BF cover.  Hence (1) holds for
**every** actual class-(i) perfect matching, not merely for the displayed
partial-flip cube.  This is the point where complete perfect-matching
closure and no-$A$ enter the reduction.

Under the usual distinct-terminal hypothesis, this has an equivalent
Tutte form.  After deleting the terminal vertex incident with semiedge
$s_i$, the proper-edge set $D_2(W_i)$ meets every perfect matching of the
remaining even graph.  Thus each row in (4) determines an ordinary Tutte
matching blocker.  That blocker alone does not solve the carrier-entry
problem, because it does not control the parity of $K-P$.

## Boundary classification of a nonnegative residual

Both anchored fixed halves have semiedge load one at every terminal:
$r_{23}$ uses the three semiedges outside $\{2,3\}$, while $B,X$
use semiedges $2,3$, and similarly for $r_{34},Y,C$.  Consequently

\[
K(s_k)=1\qquad(k=1,\ldots,5).                     \tag{5}
\]

For a class-$i$ matching $P$, the residual $D=K-P$ therefore has
semiedge load zero at $i$ and load one at the other four terminals.  If
$D\ge0$ and every closed residual component is even, alternating the two
colours on all paths and cycles decomposes it into two actual perfect
matchings.  Their boundary sizes are odd and sum to four, so one has a
singleton boundary $j\ne i$, while the other uses the remaining three
semiedges and has triple state $ij$.  Hence

\[
D=q_{ij}+P_j                                             \tag{6}
\]

for some $j\ne i$.

Adding (6) to the fixed half gives an actual BF row of boundary type
$(ij)(t)$.  Since $t\in T$, exact no-$TT$ forces $ij\in S$.  For
each $i$ in (3), exactly two choices of $j$ lie in the pentagon

\[
S=\{13,14,24,25,35\}.
\]

One is the intended $j$.  If it occurred, then
$P\in\mathcal F_i(K;j)$, contradicting the assumed empty Note-093
intersection because $P\in\mathcal C_a(\widehat P_i)$.  The other is
the unique $j'$ displayed in (3).  The remaining two values of $j$
give $T$-states and hence forbidden $T$--$T$ rows.  This proves the
three-way classification.

## Cross-carrier form of the remaining leakage

The four surviving states are not arbitrary.  They reproduce the operative
states on the opposite carrier:

* the $Y$-leak $13$ is the intended state of the $X$-endpoint on
  $K_{34}$;
* the $X$-leak $35$ is the intended state of the $Y$-endpoint on
  $K_{23}$;
* the $D$-leak $25$ is the state of the literal decomposition
  $K_{34}=q_{25}+B+D$;
* the $A$-leak $14$ is the state of the literal decomposition
  $K_{23}=q_{14}+A+C$.

Therefore generic terminal parity is no longer the unresolved interface.
Any proof proceeding through these endpoint selectors must now use one of
two mechanisms:

1. rule out the negative and odd-cycle residuals in at least one restricted
   family; or
2. prove that one of the four allowed leakage matchings is forced to agree,
   as an actual perfect-matching identity, with the corresponding opposite
   carrier fibre and its agreement-core phase.

Exact support supplies the four opposite states, but it does not identify
their witnesses with the leaked matchings.  This is a full-PM
cross-carrier identity problem, not another boundary-state or terminal-path
parity problem.  No theorem in Notes 082, 091, 093, 095, 102 or 103 forces
that identity coincidence.  Hence the four-intersection claim remains
undecided, but any counterexample must realize the explicit structure
(1)--(3).

## Scope

This is an analytic reduction.  It does not assert existence of a real
exact-Case-XII pole, does not enter the dependent second splice, and does
not use the three-distinct branch.  No graph search, census, two-sum, or
finite computation is used.
