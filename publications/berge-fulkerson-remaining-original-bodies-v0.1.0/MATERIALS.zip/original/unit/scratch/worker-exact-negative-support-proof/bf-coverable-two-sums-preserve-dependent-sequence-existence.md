# BF-coverable two-sums preserve dependent-sequence existence

## Decision

Let $H_0$ be a cubic pole, let $e$ be a proper edge of $H_0$, and let
$J$ be a closed cubic graph with distinguished proper edge $f$.  Form

\[
H=H_0\oplus_{e,f}J.
\]

If $J$ has a BF cover, then every concrete one-splice, sequential
two-splice, or forced-intermediate Note-082 sequence in $H_0$ has an
occurrencewise corresponding sequence in $H$.  Conversely, every such
sequence in $H$ projects to one in $H_0$.  Thus

\[
\boxed{
  \text{a Note-082 dependent sequence exists in }H
  \iff
  \text{one exists in }H_0 .
}
\tag{1}
\]

Three-edge-colourability of $J$ is not needed for (1).  It is needed in
Note 099 for the strictly stronger assertion that one fixed map on the
complete perfect-matching identities of $H_0$ lifts every row and every
pair equality simultaneously.

## Occurrence transport proof

Fix one ordered BF cover

\[
(F_1,\ldots,F_6)
\tag{2}
\]

of $J$.  Exactly two of its occurrences use $f$.  In the initial BF row
of the given $H_0$-sequence, exactly two occurrences use $e$.  Permute
(2) so that the distinguished-edge bits agree in all six positions.  The
usual two-sum factorization then splices the six occurrence pairs into an
initial BF row of $H$.

Suppose one step of the exterior sequence replaces the two occurrences
$(M,N)$ by $(M',N')$, where

\[
\chi_M+\chi_N=\chi_{M'}+\chi_{N'}.
\tag{3}
\]

Assume the two old positions currently carry $J$-factors $F,G$.  Taking
the $e$-coordinate of (3) gives

\[
\mathbf 1_{e\in M}+\mathbf 1_{e\in N}
=
\mathbf 1_{e\in M'}+\mathbf 1_{e\in N'}.
\tag{4}
\]

For two binary bits, equality of the sums is equality of the two
multisets.  Assign the same two factor occurrences $F,G$, either retained
or exchanged, to $M',N'$ so that the two splice bits again agree
positionwise.  On the $J$-side the new pair has exactly the old pair sum,

\[
\chi_F+\chi_G=\chi_G+\chi_F,
\]

so (3) lifts to an exact pair-sum equality in $H$.  The six $J$-factor
occurrences still form precisely the multiset (2), hence the new six-row is
again a BF cover on the $J$-side.  All unchanged positions retain their
factor occurrences.

Iterating this argument proves every finite occurrence-labelled sequence,
not only the at-most-two-splice list.  In the Note-082 normal forms the
fixed $B,X$ positions are untouched under the overload hypothesis, so
their lifted matching identities are pointwise fixed.  The same argument
also covers the forced-intermediate branch: its two displayed equal-pair
steps are transported successively, and the dynamically obtained factors
define the lifted intermediate $Z$ and the final $Y,D$.

Projection proves the reverse implication in (1).  Every perfect matching
of $H$ has unique factor projections with equal distinguished bits; every
BF row and every pair-sum equality therefore projects factorwise.

## The exact literal-identity boundary

The construction above transports **factor occurrences**, not a global
function

\[
\mathcal M(H_0)\longrightarrow\mathcal M(J).
\tag{5}
\]

If the same exterior perfect matching occurs in two positions, the two
occurrences may carry different $J$-factors and hence become different
perfect matchings of $H$.  This does not obstruct existence of the
transported Note-082 sequence: its six-matching rows and pair equalities remain
literal equations in $H$, and the persistent $B,X$ occurrences retain
their actual lifted identities.  It does obstruct the stronger demand that
all equality coincidences among the $H_0$-matching identities be preserved
by one map (5).

The minimum collision is already one duplicated identity in one row.  In
the anchored notation it may occur as

\[
X=P_3.
\tag{6}
\]

Take $J$ to be the Petersen graph.  It has six perfect matchings; their
full set is its unique six-occurrence BF cover, and the six factors are all
distinct.  Indeed, every edge lies in a unique pair of the six matchings.
If their multiplicities in a BF cover are $x_1,\ldots,x_6$, the edge
equations give $x_i+x_j=2$ for every pair $i<j$, whence all $x_i=1$.
An identity-faithful lift of (6) would have to use the same
$J$-matching in the $X$ and $P_3$ positions, while the projected
$J$-row must use all six distinct factors.  This is impossible.  Thus an
arbitrary BF-coverable factor does **not** give Note 099's global consistent
identity lift.

This collision does not refute (1): assign the two occurrences of the same
exterior matching two different Petersen factors.  Their lifts are distinct
matchings of $H$, but the occurrence-labelled sequence is valid and
projects to the prescribed sequence in $H_0$.

## Conditional consequence for two-edge irreducibility

For a class defined by exact BF boundary support together with absence of
an **isolated occurrence-labelled** Note-082 sequence, (1) does give the
desired reduction.  Suppose a member $H$ has an admissible proper-edge
decomposition $H=H_0\oplus J$, where restoring the two factor edges leaves
$H_0$ in the same structural graph class.  Projection of any BF row of $H$
gives a BF cover of $J$.  The distinguished-bit argument for ordered BF
rows gives

\[
\operatorname{BFsupp}(H)=\operatorname{BFsupp}(H_0).
\tag{7}
\]

By (1), absence of the isolated sequence also descends from $H$ to $H_0$.
Therefore a minimum-order obstruction for this occurrence-labelled property
has no such nontrivial admissible proper-edge two-sum factor.

This does **not yet** establish the same reduction for the full
repeated-star statement which motivated Note 082.  There the singleton
identities $A,B,C,D,X,Y$ are reused pointwise across four precursor BF
rows as well as the dependent sequence.  Rowwise permutation of one BF
cover of $J$ need not give the same factor to a reused identity in all
those rows.  The occurrence transport proof supplies no simultaneous lift
of that larger literal diagram, and the collision (6) is the smallest
version of precisely this loss of identity.  Hence the all-BF-factor
two-edge irreducibility of the full main target remains unproved unless the
target is first shown to depend only on occurrence-labelled sequence
existence.  Note 099 still supplies the required simultaneous lift when
$J$ is three-edge-colourable.

The qualification "admissible" is essential: an arbitrary reverse cut may
create a loop, a parallel edge, or leave another required structural class.
The result also does not preserve Tait state sets when $J$ is not
three-edge-colourable, and it does not supply the global identity map (5).

## Finite semantic check on Omen

The companion script
`audit_arbitrary_bf_factor_literal_collisions.py` independently reconstructs
the six Petersen perfect matchings, verifies that their unique BF multiset
is $(1,1,1,1,1,1)$, and verifies that all unordered two-factor incidence
sums are distinct.  It then exhausts the abstract nontrivial two-splice
occurrence/identity normal forms used by the earlier Note-082 audit.

After removing empty splices and the degenerate targets $P_3=Y$ or
$P_5=D$, it found 612 identity-faithful failures, all containing a repeated
identity within some live six-row.  It found no nondegenerate failure when
all three live rows have six distinct identities.  The minimum
nondegenerate pattern is exactly (6):

\[
\begin{aligned}
R_0&=(0,1,2,3,3,4),\\
R_1&=(5,1,2,3,6,4),\\
R_2&=(7,1,2,3,6,8),
\end{aligned}
\]

with pair replacements

\[
(0,3)\to(5,6),\qquad (5,4)\to(7,8).
\]

This is only a finite check of the identity semantics; the proof of (1) is
the occurrence-transport argument above.  It is not a graph census and the
abstract collision pattern is not asserted to be a realized cubic pole.

The run used one Omen process, Python 3.10.12, and a 1 GiB virtual-memory
cap.  It ended with
`ARBITRARY_BF_FACTOR_LITERAL_COLLISIONS_AUDITED` in 4.87 seconds, with
maximum resident memory 12,988 KiB.  The raw output is
`omen-arbitrary-bf-factor-literal-collision-final.log`.
