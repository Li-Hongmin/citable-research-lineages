#!/usr/bin/env python3
"""Classify every minimum cyclic 5-cut side of the fixed Note 083 graph."""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement, permutations
from pathlib import Path
from runpy import run_path


ROOT = Path(__file__).resolve().parents[2]
BASE = run_path(
    ROOT / "computations/bundles/"
    "cyclically-five-connected-empty-phase-intersection/verify.py"
)
VERTICES = tuple(BASE["VERTICES"])
EDGES = frozenset(BASE["EDGES"])
P = frozenset(BASE["P_EDGES"])
Y = frozenset(BASE["Y_EDGES"])
POSITIONS = tuple(range(1, 6))
PAIR_SET = tuple(combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(PAIR_SET) - S
REQUIRED_SS = frozenset(combinations_with_replacement(sorted(S), 2))
REQUIRED_ST = frozenset(tuple(sorted((s, t))) for s in S for t in T)


def global_companions():
    labels = {}
    for item in P:
        labels[item] = frozenset((0,))
    for c in range(3):
        for i in range(3):
            item = BASE["edge"](
                BASE["vertex"](c, i, 1), BASE["vertex"](c, (i + 1) % 3, 0)
            )
            labels[item] = BASE["Y_LABELS"][i]
    for u, v in BASE["THIRD_EDGES"]:
        uc, ur = divmod(u, 6)
        ui, ub = divmod(ur, 2)
        labels[(u, v)] = BASE["stub_label"](uc, ui, ub)
    return tuple(
        frozenset(item for item, label in labels.items() if index in label)
        for index in range(5)
    )


COMPANIONS = global_companions()


def mixed_phase_matching(blocks):
    """Use the Y phase on ``blocks`` and the P phase elsewhere."""
    return frozenset(
        item
        for block in range(3)
        for item in (BASE["Y_EDGES"] if block in blocks else BASE["P_EDGES"])
        if item[0] // 6 == block and item[1] // 6 == block
    )


MIXED_PHASES = {
    blocks: mixed_phase_matching(frozenset(blocks))
    for size in range(1, 4)
    for blocks in combinations(range(3), size)
}
assert all(len(matching) == 9 for matching in MIXED_PHASES.values())


def induced_edges(side):
    return frozenset(edge for edge in EDGES if edge[0] in side and edge[1] in side)


def connected(side, edges):
    start = min(side)
    reached = {start}
    stack = [start]
    adjacency = {vertex: [] for vertex in side}
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    while stack:
        for neighbour in adjacency[stack.pop()]:
            if neighbour not in reached:
                reached.add(neighbour)
                stack.append(neighbour)
    return reached == set(side)


def contains_cycle(side, edges):
    return len(edges) >= len(side)


def cyclic_five_cuts():
    answer = []
    all_vertices = frozenset(VERTICES)
    for mask in range(1 << (len(VERTICES) - 1)):
        side = frozenset((0,)) | frozenset(
            index + 1
            for index in range(len(VERTICES) - 1)
            if mask & (1 << index)
        )
        other = all_vertices - side
        if not other:
            continue
        cut = tuple(sorted(
            edge for edge in EDGES if (edge[0] in side) != (edge[1] in side)
        ))
        if len(cut) != 5:
            continue
        inside = induced_edges(side)
        outside = induced_edges(other)
        if not (
            connected(side, inside)
            and connected(other, outside)
            and contains_cycle(side, inside)
            and contains_cycle(other, outside)
        ):
            continue
        answer.append((side, other, cut))
    assert len({cut for _, _, cut in answer}) == len(answer)
    return tuple(answer)


def make_pole(side, cut):
    vertices = tuple(sorted(side))
    proper = tuple(sorted(induced_edges(side)))
    cut_index = {edge: index for index, edge in enumerate(cut)}
    edge_objects = proper + tuple(f"s{index}" for index in range(5))
    endpoints = {edge: edge for edge in proper}
    for edge, index in cut_index.items():
        endpoint = edge[0] if edge[0] in side else edge[1]
        endpoints[f"s{index}"] = (endpoint,)
    incident = defaultdict(list)
    for item, ends in endpoints.items():
        for vertex in ends:
            incident[vertex].append(item)
    assert all(len(incident[vertex]) == 3 for vertex in vertices)

    chosen = []
    matchings = set()

    def recurse(uncovered):
        if not uncovered:
            matchings.add(frozenset(chosen))
            return
        vertex = min(uncovered)
        for item in incident[vertex]:
            ends = frozenset(endpoints[item])
            if ends <= uncovered:
                chosen.append(item)
                recurse(uncovered - ends)
                chosen.pop()

    recurse(frozenset(vertices))
    family = tuple(sorted(matchings, key=lambda value: tuple(map(str, sorted(value, key=str)))))
    classes = defaultdict(list)
    for matching in family:
        boundary = tuple(index + 1 for index in range(5) if f"s{index}" in matching)
        classes[boundary].append(matching)
    return vertices, proper, frozenset(edge_objects), endpoints, family, classes


def has_cover(slots, classes, objects, load):
    if any(not classes[slot] for slot in slots):
        return False
    ordered_slots = tuple(sorted(slots, key=lambda slot: len(classes[slot])))
    counts = {item: 0 for item in objects}

    def recurse(index):
        if index == len(ordered_slots):
            return all(value == load for value in counts.values())
        remaining = len(ordered_slots) - index
        if any(value > load or value + remaining < load for value in counts.values()):
            return False
        for matching in classes[ordered_slots[index]]:
            if any(counts[item] == load for item in matching):
                continue
            for item in matching:
                counts[item] += 1
            if recurse(index + 1):
                return True
            for item in matching:
                counts[item] -= 1
        return False

    return recurse(0)


def boundary_data(classes, objects):
    complement = lambda pair: tuple(sorted(set(POSITIONS) - set(pair)))
    tait = set()
    for state in PAIR_SET:
        if has_cover((complement(state), (state[0],), (state[1],)), classes, objects, 1):
            tait.add(state)
    support = set()
    for left, right in combinations_with_replacement(PAIR_SET, 2):
        slots = (
            complement(left), complement(right),
            *((position,) for position in left + right),
        )
        if has_cover(slots, classes, objects, 2):
            support.add((left, right))
    a_type = has_cover(
        (POSITIONS, *((position,) for position in POSITIONS)),
        classes, objects, 2,
    )
    return frozenset(tait), frozenset(support), a_type


def relabel_pair(pair, permutation):
    return tuple(sorted(permutation[position - 1] for position in pair))


def relabel_data(tait, support, permutation):
    new_tait = frozenset(relabel_pair(pair, permutation) for pair in tait)
    new_support = frozenset(
        tuple(sorted((relabel_pair(left, permutation), relabel_pair(right, permutation))))
        for left, right in support
    )
    return new_tait, new_support


def restrict_matching(matching, side, cut):
    output = set()
    for edge in matching:
        left = edge[0] in side
        right = edge[1] in side
        if left and right:
            output.add(edge)
        elif left != right:
            output.add(f"s{cut.index(edge)}")
    return frozenset(output)


def cycle_components(difference, endpoints):
    if any(isinstance(item, str) for item in difference):
        return ()
    adjacency = defaultdict(list)
    for item in difference:
        for vertex in endpoints[item]:
            adjacency[vertex].append(item)
    unseen = set(difference)
    answer = []
    while unseen:
        seed = unseen.pop()
        component = {seed}
        stack = [seed]
        while stack:
            item = stack.pop()
            for vertex in endpoints[item]:
                for following in adjacency[vertex]:
                    if following in unseen:
                        unseen.remove(following)
                        component.add(following)
                        stack.append(following)
        degrees = Counter(vertex for item in component for vertex in endpoints[item])
        if not all(value == 2 for value in degrees.values()):
            return ()
        answer.append(frozenset(component))
    return tuple(answer)


def carrier_data(side, cut, endpoints, family):
    restricted_p = restrict_matching(P, side, cut)
    restricted_companions = tuple(
        restrict_matching(matching, side, cut) for matching in COMPANIONS
    )
    assert {restricted_p, *restricted_companions} <= set(family)
    p_boundary = tuple(sorted(item for item in restricted_p if isinstance(item, str)))
    phases = []
    for blocks, global_phase in MIXED_PHASES.items():
        restricted_phase = restrict_matching(global_phase, side, cut)
        assert restricted_phase in set(family)
        phase_boundary = tuple(sorted(
            item for item in restricted_phase if isinstance(item, str)
        ))
        components = cycle_components(restricted_p ^ restricted_phase, endpoints)
        same_boundary = p_boundary == phase_boundary
        empty_on_every_component = bool(components) and all(
            all(
                (matching & component) != (restricted_phase & component)
                for matching in restricted_companions
            )
            for component in components
        )
        phases.append({
            "Y_blocks": blocks,
            "same_boundary": same_boundary,
            "boundary_size": len(p_boundary),
            "difference_cycle_lengths": tuple(
                sorted(len(component) for component in components)
            ),
            "empty_companion_phase_every_component": empty_on_every_component,
            "carrier": same_boundary and empty_on_every_component,
            "singleton_carrier": (
                same_boundary and len(p_boundary) == 1 and empty_on_every_component
            ),
        })
    return {
        "P_boundary": p_boundary,
        "phase_carriers": tuple(phases),
        "carrier_Y_blocks": tuple(
            phase["Y_blocks"] for phase in phases if phase["carrier"]
        ),
        "singleton_carrier_Y_blocks": tuple(
            phase["Y_blocks"] for phase in phases if phase["singleton_carrier"]
        ),
    }


def side_report(cut_id, orientation, side, cut):
    vertices, proper, objects, endpoints, family, classes = make_pole(side, cut)
    tait, support, a_type = boundary_data(classes, objects)
    carrier = carrier_data(side, cut, endpoints, family)
    exact_permutations = []
    near_permutations = []
    exact_s_permutations = []
    best_score = None
    best = None
    for permutation in permutations(POSITIONS):
        new_tait, new_support = relabel_data(tait, support, permutation)
        ss = frozenset(pair for pair in new_support if pair[0] in S and pair[1] in S)
        tt = frozenset(pair for pair in new_support if pair[0] in T and pair[1] in T)
        st = new_support - ss - tt
        exact = (
            new_tait == S and ss == REQUIRED_SS and st == REQUIRED_ST
            and not tt and not a_type
        )
        near = new_tait == S and not a_type
        if new_tait == S:
            exact_s_permutations.append(permutation)
        if exact:
            exact_permutations.append(permutation)
        if near:
            near_permutations.append(permutation)
        score = (
            len(new_tait ^ S), len(REQUIRED_SS - ss) + len(REQUIRED_ST - st),
            len(tt) + int(a_type),
        )
        if best_score is None or score < best_score:
            best_score = score
            best = {
                "score": score,
                "permutation": permutation,
                "tait_states": tuple(sorted(new_tait)),
                "SS": len(ss), "ST": len(st), "TT": len(tt), "A": a_type,
                "missing_SS": len(REQUIRED_SS - ss),
                "missing_ST": len(REQUIRED_ST - st),
            }
    terminal_vertices = tuple(
        next(iter(endpoints[f"s{index}"])) for index in range(5)
    )
    return {
        "cut": cut_id,
        "cut_edges": cut,
        "orientation": orientation,
        "vertices": tuple(sorted(vertices)),
        "order": len(vertices),
        "proper_edges": len(proper),
        "terminal_vertices_distinct": len(set(terminal_vertices)) == 5,
        "perfect_matchings": len(family),
        "raw_tait_states": tuple(sorted(tait)),
        "raw_support_types": len(support),
        "A": a_type,
        "exact_case_xii_relabellings": tuple(exact_permutations),
        "exact_S_no_A_relabellings": tuple(near_permutations),
        "exact_S_relabellings": tuple(exact_s_permutations),
        "best_case_xii_profile": best,
        "carrier": carrier,
    }


def main():
    cuts = cyclic_five_cuts()
    reports = []
    for cut_id, (left, right, cut) in enumerate(cuts):
        reports.append(side_report(cut_id, 0, left, cut))
        reports.append(side_report(cut_id, 1, right, cut))
    exact = [report for report in reports if report["exact_case_xii_relabellings"]]
    near = [report for report in reports if report["exact_S_no_A_relabellings"]]
    carrier = [
        report for report in reports
        if report["carrier"]["singleton_carrier_Y_blocks"]
    ]
    near_carrier = [
        report for report in near
        if report["carrier"]["singleton_carrier_Y_blocks"]
    ]
    carrier_relations = []
    for report in reports:
        for phase in report["carrier"]["phase_carriers"]:
            if phase["carrier"]:
                carrier_relations.append({
                    "cut": report["cut"],
                    "orientation": report["orientation"],
                    "vertices": report["vertices"],
                    "cut_edges": report["cut_edges"],
                    "Y_blocks": phase["Y_blocks"],
                    "boundary_size": phase["boundary_size"],
                    "singleton": phase["singleton_carrier"],
                    "A": report["A"],
                    "best_case_xii_profile": report["best_case_xii_profile"],
                })
    print({
        "minimum_cyclic_5_cuts": len(cuts),
        "oriented_cut_sides": len(reports),
        "exact_case_xii_sides": len(exact),
        "exact_S_no_A_sides": len(near),
        "singleton_empty_phase_carrier_sides": len(carrier),
        "exact_S_no_A_with_carrier_sides": len(near_carrier),
        "carrier_relations": carrier_relations,
        "reports": reports,
    })
    print("NOTE083_CYCLIC5_CUT_SIDES_AUDITED")


if __name__ == "__main__":
    main()
