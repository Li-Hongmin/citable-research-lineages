# Exact boundary preservation under alternating-chain replacement

Let \(H\) be a loopless cubic 5-pole, let \(r=xy\) be a proper edge, and
let \(H'\) be obtained by replacing \(r\) with the alternating-chain 2-pole
of Note 089.  Write

\[
 E(P)=M_A\mathbin{\dot\cup}M_C\mathbin{\dot\cup}M_B,
\]

where \(M_A,M_B\) are perfect matchings of the \(2m\) internal vertices,
\(M_C\) matches all internal vertices except the two ports, and the two
ports are attached to \(x,y\).

## Perfect-matching compression

Every perfect matching of \(H'\) uses either both attachment edges or
neither.  Indeed, if it uses \(k\) attachments, its internal edges cover
\(2m-k\) vertices, so \(k\) is even.  Compression deletes the internal
matching and sends the two attachment edges to \(r\).  It therefore maps

\[
\begin{array}{c|c}
\text{local behaviour in }H'&\text{behaviour in }H\\ \hline
\text{both attachments}&r\text{ used},\\
\text{no attachment}&r\text{ avoided}.
\end{array}
\]

The map is onto: an \(r\)-using matching lifts with the two attachments and
\(M_C\), while an \(r\)-avoiding matching lifts with either \(M_A\) or
\(M_B\).  It need not be one-to-one, since the 2-pole can have additional
local perfect matchings.

## Exact preservation of Tait and BF boundary support

Compression of a Tait colouring of \(H'\) gives a Tait colouring of \(H\).
The two attachment edges occur in the same colour class by the parity
argument above.  Conversely, a Tait colouring of \(H\) lifts by assigning
\(M_C\) and both attachments to the colour of \(r\), and assigning
\(M_A,M_B\), in either order, to the other two colours.  Terminal colours
are unchanged.  Hence the complete Tait state sets of \(H\) and \(H'\) are
equal.

Now compress a BF cover of \(H'\).  Each attachment edge has total load
two, and every occurrence uses both attachments or neither, so exactly two
of the six compressed matchings use \(r\).  All old edges retain load two;
therefore the compression is a BF cover of \(H\).

Conversely, take a BF cover of \(H\).  Exactly two of its six occurrences
use \(r\).  Lift both with \(M_C\) and the attachments; among the four
\(r\)-avoiding occurrences, lift any two with \(M_A\) and the other two
with \(M_B\).  Every gadget edge then has load two.  Since each matching
keeps its boundary class, this proves equality of the complete BF boundary
supports as sets of boundary types.  It does not assert equality of the
numbers of realizing covers.

Thus claims (i) and (ii) hold, with the qualification that compression is
a surjection with explicit local fibres, not generally a bijection.

## What one triple use supplies

Fix a displayed half

\[
 \mathscr A=(Q,L_i,L_j)
\]

of a BF row and suppose that \(Q\) is the unique occurrence in this half
using \(r\), with \(Q\) the triple-boundary occurrence.  Lift \(Q\) with
\(M_C\) and lift both singleton occurrences with \(M_A\).  In the
complementary half, the BF equation forces one further \(r\)-using
occurrence; lift it with \(M_C\), and lift the two remaining avoiders with
\(M_B\).  This gives a valid local BF lift.  Every edge \(e\in M_A\) has
load two in \(\mathscr A\), and both displayed singleton occurrences use
\(e\).

This displayed fact is weaker than saying that \(e\) is fixed throughout
the complete oriented carrier fibre.  Let \(a\) be the compressed
three-matching load of \(\mathscr A\).  Compression of the load graph gives
the exact equivalence

\[
\begin{split}
 e\text{ is used by every class-}i\text{ member of the oriented fibre}
 \quad\Longleftrightarrow\quad
 r\text{ is never coloured }i\\
 \text{in an oriented decomposition of }a.
\end{split}                                                     \tag{1}
\]

Indeed, the single chain through \(M_C\) has the colour of \(r\), and each
doubled \(M_A\)-edge receives the other two colours.  In particular, both
singleton classes \(i,j\) are fixed on \(e\) if and only if

\[
 r\text{ has the triple colour in every oriented }(i,j)
 \text{ decomposition of }a.                              \tag{2}
\]

The hypothesis in the proposed theorem only supplies one decomposition
with this property.  Condition (2), an oriented triple-rigidity condition,
is the exact additional hypothesis needed for complete carrier-fixedness.

There is a separate boundary obstruction to obtaining a same-class
avoider *inside the complementary half*.  Every occurrence in that half
avoids \(M_A\) under the canonical lift above, but local lifting never
changes a boundary class.  Consequently, the complementary half contains a
class-\(i\) avoider if and only if it already contains an occurrence of
boundary class \(i\).  If avoiders are required for both singleton classes,
its boundary multiset must contain both \(i\) and \(j\).

The universal claim fails already on the base 5-cycle pole.  Take a BF row
formed by two Tait colourings with disjoint states, for example \(13\) and
\(25\), and let \(r\) be the edge between terminals \(1\) and \(3\).  In
the state-\(13\) half, \(r\) is used only by the triple-boundary matching,
and it is triple-rigid.  The canonical lift therefore gives a genuinely
carrier-fixed \(M_A\)-overload.  The complementary state-\(25\) half,
however, contains singleton classes \(2,5\), not \(1,3\).  No internal lift
can turn either occurrence into a class-\(1\) or class-\(3\) matching.
Thus the assertion that the complementary half supplies a same-class
avoider is false.

If “global avoider” is not required to be one of the complementary-half
occurrences, no boundary-overlap hypothesis is needed: the same compressed
singleton \(L_i\) has the alternative lift \(L_i\cup M_B\), which is a
genuine class-\(i\) perfect matching avoiding every edge of \(M_A\).

## Relation to the dependent two-splice fibre

The replacement adds a local phase factor.  In the order-seventeen gadget,
\(M_A\triangle M_B\) is the single internal alternating 12-cycle, so an
\(A\)-lift and a \(B\)-lift of the same compressed matching differ only on
that cycle.  A paired local swap can exchange this phase with another
occurrence while preserving the row load.

This does not decide the dependent two-splice fibre of Note 082.  The
Note-082 conditions concern alignment on the external components of
\(P_3\triangle Y\) and \(P_5\triangle D\).  Alternating-chain replacement
preserves the compressed perfect-matching family and all boundary support,
and its new internal cycle is disjoint from those external differences.
It supplies a freely controlled local factor but no companion phase on an
old component.  Therefore the Note-082 phase-intersection obstruction
survives unchanged.
