# The minimum cyclic five-cut sides of the Note 083 graph are not exact Case XII

Let $G$ be the fixed eighteen-vertex cubic graph of Note 083, with the
three disjoint alternating six-cycles indexed by $0,1,2$.  For a nonempty
$J\subseteq\{0,1,2\}$, let $Y_J$ use the $Y$-phase on the blocks in
$J$ and the $P$-phase on the remaining blocks.  Thus all seven $Y_J$
are perfect matchings of $G$.

The direct classification below is confined to this one graph.  It does not
search other graphs, orders, or expansions.

## Exhaustive cut-side classification

There are exactly seven unordered minimum cyclic five-edge cuts of $G$.
Their fourteen oriented sides are connected cubic five-poles, and all five
terminal vertices are distinct in every side.  For every side, all perfect
matchings were enumerated.  From the complete matching family we computed
the full Tait state set, all fifty-five pair BF types, and the all-terminal
type $A=(12345)$.  All $120$ boundary relabellings were then tested.

No oriented side has either of the following properties:

\[
 \operatorname{Tait}=S,\qquad SS=15,\quad ST=25,\quad TT=0,\quad A=0,
\]

or even the weaker pair

\[
 \operatorname{Tait}=S,\qquad A=0.
\]

The complete numerical census is as follows.  In the last four columns we
give the best Case-XII profile over all boundary relabellings.  The score is

\[
 (\lvert\operatorname{Tait}\mathbin\triangle S\rvert,
   \#\text{missing }SS+ST,
   TT+\mathbf 1_A).
\]

| cut | side | order | PM | $|\mathrm{Tait}|$ | pair support | $A$ | best score | $SS$ | $ST$ | $TT$ |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0 | 5  | 11 | 5  | 15 | 1 | (0,25,1) | 15 | 0  | 0  |
| 0 | 1 | 13 | 32 | 7  | 43 | 0 | (4,6,9)  | 14 | 20 | 9  |
| 1 | 0 | 9  | 18 | 8  | 36 | 0 | (3,10,6) | 15 | 15 | 6  |
| 1 | 1 | 9  | 19 | 6  | 30 | 1 | (3,15,6) | 13 | 12 | 5  |
| 2 | 0 | 13 | 32 | 7  | 50 | 1 | (4,2,13) | 14 | 24 | 12 |
| 2 | 1 | 5  | 11 | 5  | 15 | 1 | (0,25,1) | 15 | 0  | 0  |
| 3 | 0 | 11 | 25 | 9  | 45 | 1 | (4,5,11) | 15 | 20 | 10 |
| 3 | 1 | 7  | 14 | 6  | 26 | 0 | (3,19,5) | 12 | 9  | 5  |
| 4 | 0 | 13 | 33 | 9  | 45 | 1 | (4,5,11) | 15 | 20 | 10 |
| 4 | 1 | 5  | 11 | 5  | 15 | 1 | (0,25,1) | 15 | 0  | 0  |
| 5 | 0 | 13 | 33 | 10 | 55 | 1 | (5,0,16) | 15 | 25 | 15 |
| 5 | 1 | 5  | 11 | 5  | 15 | 1 | (0,25,1) | 15 | 0  | 0  |
| 6 | 0 | 13 | 33 | 7  | 41 | 0 | (2,7,8)  | 15 | 18 | 8  |
| 6 | 1 | 5  | 11 | 5  | 15 | 1 | (0,25,1) | 15 | 0  | 0  |

Exactly five sides can be relabelled to have Tait set $S$.  They are the
five order-five sides.  Each is the elementary five-cycle pole with
$SS=15,ST=TT=0$ and $A=1$.  Thus the first negative-support condition
already fails.

Among the $A=0$ sides, the closest profile is cut 6, side 0, with

\[
 V=\{0,3,4,5,6,7,11,12,13,14,15,16,17\}.
\]

Under the relabelling $(1,3,5,2,4)$, its Tait set is
$S\cup\{12,45\}$, and its BF profile is

\[
 SS=15,\qquad ST=18,\qquad TT=8,\qquad A=0.
\]

It is therefore a sharp no-$A$ near-side, but not an exact-$S$ side.

## Which mixed phases survive a cut

For every side and every nonempty $J$, the restrictions of $P$ and
$Y_J$ were compared.  When they have the same boundary, their proper-edge
symmetric difference was decomposed into cycles and the five Note 083
companions were checked against the $Y_J$-phase on every component.  The
following list contains every nontrivial surviving carrier; each difference
is one six-cycle and has empty companion-phase intersection.

| cut | side | side vertices | $J$ | boundary size | singleton | $A$ | best $(SS,ST,TT)$ |
|---:|---:|---|---|---:|:---:|:---:|---:|
| 0 | 1 | 2,3,4,5,9,10,11,12,13,14,15,16,17 | {2}   | 1 | yes | 0 | 14,20,9 |
| 1 | 0 | 0,1,2,6,7,8,9,10,11                 | {1}   | 1 | yes | 0 | 15,15,6 |
| 1 | 0 | 0,1,2,6,7,8,9,10,11                 | {1,2} | 1 | yes | 0 | 15,15,6 |
| 1 | 1 | 3,4,5,12,13,14,15,16,17             | {2}   | 1 | yes | 1 | 13,12,5 |
| 1 | 1 | 3,4,5,12,13,14,15,16,17             | {1,2} | 1 | yes | 1 | 13,12,5 |
| 2 | 0 | 0,1,2,3,4,5,6,7,8,12,13,14,15       | {0}   | 1 | yes | 1 | 14,24,12 |
| 3 | 0 | 0,1,2,6,7,8,9,10,11,16,17           | {1}   | 1 | yes | 1 | 15,20,10 |
| 4 | 0 | 0,1,2,5,6,7,8,9,10,11,12,16,17      | {1}   | 3 | no  | 1 | 15,20,10 |
| 5 | 0 | 0,1,2,6,7,8,9,10,11,14,15,16,17     | {1}   | 1 | yes | 1 | 15,25,15 |
| 6 | 0 | 0,3,4,5,6,7,11,12,13,14,15,16,17    | {2}   | 3 | no  | 0 | 15,18,8 |

Thus eight oriented sides retain a mixed-phase carrier, six of them in a
singleton boundary class.  There are ten side--$J$ carrier pairs in total,
eight singleton.  Every one of these sides first fails at
$\operatorname{Tait}=S$; none reaches the exact-$S$/no-$A$ interface.

Two singleton-carrier, no-$A$ sides form a small Pareto boundary.  Cut 1,
side 0 has the smallest Tait mismatch:

\[
 \operatorname{Tait}=S\cup\{12,34,45\},\qquad
 (SS,ST,TT,A)=(15,15,6,0),
\]

and carries both $Y_{\{1\}}$ and $Y_{\{1,2\}}$.  Cut 0, side 1 has
more $ST$ support but a larger Tait mismatch:

\[
 \operatorname{Tait}=(S-\{25\})\cup\{23,34,45\},\qquad
 (SS,ST,TT,A)=(14,20,9,0),
\]

and carries $Y_{\{2\}}$.

The full $Y=Y_{\{0,1,2\}}$ cannot survive as a same-boundary carrier for
an elementary reason.  Since $P\cap Y=\varnothing$, their cut-boundary
sets are disjoint; equality would force both to be empty.  Every side has odd
order, because $3|V|=2|E|+5$, so the restriction of a perfect matching
uses an odd, hence nonzero, number of cut edges.  This also explains why the
mixed $Y_J$, rather than full $Y$, is the correct finite test.

## Reproduction and scope

The deterministic standard-library program is
`audit_note083_cyclic5_cut_sides.py` in this directory.  It reads only the
fixed Note 083 graph, enumerates all vertex bipartitions of that graph, and
then performs the matching and BF searches described above.

It was run on `omen` as one Python 3.10.12 process.  The final run took
0.66 seconds, used 12,544 kB peak resident memory, exited with status zero,
and ended with

```text
NOTE083_CYCLIC5_CUT_SIDES_AUDITED
```

This is a complete exclusion only for the seven minimum cyclic five-cuts of
the fixed Note 083 graph.  It gives neither a general obstruction nor a
classification of other cubic graphs.
