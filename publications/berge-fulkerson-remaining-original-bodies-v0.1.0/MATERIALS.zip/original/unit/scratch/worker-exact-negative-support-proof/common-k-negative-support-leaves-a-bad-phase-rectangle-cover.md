# A common carrier leaves a bad-phase rectangle-cover gate

Fix actual singleton perfect matchings \(A,C,D\) of boundary classes
\(1,4,5\) and the common integral load

\[
K=2\mathbf1-A-C-D.                                \tag{1}
\]

Let \(\mathcal B(K)\) be the class-2 singleton projections of all actual
decompositions

\[
K=q_{24}+r_{15}+B,                                \tag{2}
\]

and let \(\mathcal X(K)\) be the class-3 singleton projections of all
actual decompositions

\[
K=q_{13}+r_{45}+X.                                \tag{3}
\]

Thus every pair \((B,X)\in\mathcal B(K)\times\mathcal X(K)\) gives a
literal \(J_{31}\) choice with the same \(A,C,D\).  The question is whether
exact Case-XII negative support forces one such pair to satisfy

\[
A+B+C+X\le2\mathbf1.                              \tag{4}
\]

The common carrier sharpens the question but does not presently decide it.
Its exact form is a cross-intersection problem on the load-one edges of
\(K\).  Exact no \(A\) forces every \(B\)--\(X\) pair to agree on at least
one such edge; nonoverload requires one pair whose agreements all have the
safe \(D\)-phase.  Neither the no-loop condition nor the terminal-path
consequences of no \(T\)--\(T\) force this safe cell.

No real exact-Case-XII carrier violating (4) is known.  The conclusion is
therefore a strict carrier-level information boundary, not a counterexample
to the actual-pole implication.

## The load-one phase partition

Because \(K(e)=2-A(e)-C(e)-D(e)\), every physical edge of load one in
\(K\) is used by exactly one of \(A,C,D\).  Define the disjoint partition

\[
\begin{aligned}
E_A&=\{e:K(e)=1, A(e)=1\},\\
E_C&=\{e:K(e)=1, C(e)=1\},\\
E_D&=\{e:K(e)=1, D(e)=1\},\\
E_1(K)&=E_A\mathbin{\dot\cup}E_C\mathbin{\dot\cup}E_D.
                                                               \tag{5}
\end{aligned}
\]

For \(B\in\mathcal B(K)\) and \(X\in\mathcal X(K)\), put

\[
I(B,X)=B\cap X\cap E_1(K).                        \tag{6}
\]

On a load-one edge of \(K\), the physical copy is unique, so (6) is the
literal agreement set of the two singleton colours.  A load-two edge of
\(K\) has anchor load zero and cannot overload (4); a load-zero edge is
used by neither \(B\) nor \(X\).  Hence the local calculation from the two
pivot rows reduces to

\[
\boxed{
A+B+C+X\le2\mathbf1
\iff
I(B,X)\cap(E_A\cup E_C)=\varnothing.
}                                                  \tag{7}
\]

Indeed, an edge in \(E_A\cap B\cap X\) has signature \(ABX\), and an edge
in \(E_C\cap B\cap X\) has signature \(BCX\); these are the only possible
three-hit signatures.  An edge in \(E_D\cap B\cap X\) has signature
\(BDX\) and contributes only two occurrences to the quartet (4).

## No \(A\) is exactly nonempty load-one agreement

For fixed \(B\in\mathcal B(K)\), put

\[
W_B=A+B+C+D,qquad D_2(B)=\{e:W_B(e)=2\}.          \tag{8}
\]

Equation (2) implies \(W_B\le2\mathbf1\).  If some class-3 singleton
perfect matching \(P\) avoids \(D_2(B)\), then

\[
W_B+P\le2\mathbf1.                                \tag{9}
\]

At every internal cubic vertex the five singleton occurrences have total
incident load five, so (9) forces the incident profile \((2,2,1)\).  The
five semiedges also occur once each.  Therefore

\[
2\mathbf1-W_B-P                                   \tag{10}
\]

is an all-terminal perfect matching, giving a forbidden \(A\)-type BF
cover.  Exact no \(A\) consequently gives

\[
P\cap D_2(B)\ne\varnothing                        \tag{11}
\]

for every actual class-3 matching \(P\).

If \(X\in\mathcal X(K)\), then it is supported by \(K\).  On a load-two
edge of \(K\), the anchor load is zero and \(W_B(e)\le1\); on a load-zero
edge, \(X(e)=0\).  On a load-one edge, \(W_B(e)=2\) exactly when \(B(e)=1\).
Thus

\[
X\cap D_2(B)=I(B,X).                              \tag{12}
\]

Combining (11)--(12), no \(A\) gives the exact common-carrier constraint

\[
\boxed{
I(B,X)\ne\varnothing
\quad\text{for every }(B,X)\in
\mathcal B(K)\times\mathcal X(K).
}                                                  \tag{13}
\]

In particular (13) already implies \(B\cap X\ne\varnothing\), so the
no-\(T\)-loop condition for the pair \(23\) adds no further restriction at
this gate.  By (7) and (13), a safe pair is precisely one satisfying

\[
\varnothing\ne I(B,X)\subseteq E_D.               \tag{14}
\]

## What no \(T\)--\(T\) forces inside each colouring

The common \(K\) does give exact terminal-path information, but it is
internal to one colouring at a time.

Start from (2).  In the bichromatic copy-subgraph \(q_{24}+B\), the four
terminal ends are \(1,2,3,5\).  Let \(t\) be the other end of the path
starting at terminal \(2\).  Switching the two colours on this path gives

\[
\begin{array}{c|c}
t&\text{resulting pair of triple states}\ \hline
1&(14,15),\\
3&(34,15),\\
5&(45,15).
\end{array}                                                     \tag{15}
\]

The first is an allowed \(S\)--\(T\) type; the last two are forbidden
\(T\)--\(T\) types.  Hence exact no \(T\)--\(T\) forces

\[
2\longleftrightarrow1,qquad3\longleftrightarrow5              \tag{16}
\]

in this bichromatic terminal-path pairing.

Similarly, in (3) the bichromatic copy-subgraph \(q_{13}+X\) has terminal
ends \(2,3,4,5\).  Switching the path from terminal \(3\) gives triple
state pairs

\[
\begin{array}{c|c}
t&\text{resulting pair}\ \hline
2&(12,45),\\
4&(14,45),\\
5&(15,45).
\end{array}                                                     \tag{17}
\]

Only the middle type is allowed, so

\[
3\longleftrightarrow4,qquad2\longleftrightarrow5.              \tag{18}
\]

Equations (16) and (18) do not align the two singleton projections.  In
fact the direct switch which would change singleton terminal \(2\) to
terminal \(3\) in (2) is exactly the forbidden middle row \((34,15)\) of
(15).  Thus no \(T\)--\(T\) blocks the most direct \(B\)-to-\(X\) terminal
switch rather than supplying it.

There is no forced two-switch bypass at the boundary level.  After the
allowed switch \(2\leftrightarrow1\) in (15), the colouring has singleton
terminal \(1\) and triple states \((14,15)\).  In the bichromatic union of
that singleton colour with the state-15 colour, pairing terminal \(1\) with
\(2,3,4\) gives respectively

\[
(14,25),qquad(14,35),qquad(14,45),               \tag{19}
\]

which are all allowed \(S\)--\(S\) or \(S\)--\(T\) types.  Negative support
therefore does not choose the \(1\leftrightarrow3\) path which would enter
a class-3 singleton projection.  That projection has triple states
\((14,35)\), not the prescribed \((13,45)\) orientation in
\(\mathcal X(K)\); reaching the latter would require still more information.

Most importantly, (16)--(19) concern terminal components of
\(q_{24}+B\) or \(q_{13}+X\).  The nonoverload condition (7) concerns the
cross-colouring agreement set \(B\cap X\) on load-one physical edges.
Terminal pairing in either colouring places no condition on which phase
\(E_A,E_C,E_D\) labels such an agreement edge.

## The strict carrier-level failure condition

For \(e\in E_1(K)\), define the two fibre sections

\[
\mathcal B_e=\{B\in\mathcal B(K):e\in B\},qquad
\mathcal X_e=\{X\in\mathcal X(K):e\in X\}.        \tag{20}
\]

Equation (13) is exactly the rectangle cover

\[
\mathcal B(K)\times\mathcal X(K)
=\bigcup_{e\in E_1(K)}\mathcal B_e\times\mathcal X_e.          \tag{21}
\]

The desired conclusion holds if and only if at least one cell of this
product is covered only by safe-phase rectangles, equivalently if and only
if

\[
\exists(B,X): I(B,X)\cap(E_A\cup E_C)=\varnothing.              \tag{22}
\]

Its exact failure condition is

\[
\boxed{
\mathcal B(K)\times\mathcal X(K)
=\bigcup_{e\in E_A\cup E_C}\mathcal B_e\times\mathcal X_e.
}                                                               \tag{23}
\]

Thus no \(A\) proves the full rectangle cover (21), while the proposed
nonoverload lemma requires that the strictly smaller bad-phase family in
(23) fail to cover the product.  The no-loop condition is already absorbed
by (21), and the no-\(T\)--\(T\) path constraints (16)--(19) do not
distinguish the three phase classes of (5).

Complete perfect-matching closure adds all valid closed-component Kempe
switches within each colouring.  It does not by itself prevent their two
resulting projection families from satisfying the cross-intersection
condition (23); no theorem in the present chain converts the separate
terminal-component constraints into a restriction on these cross-colouring
rectangles.

## Decision

The shared carrier \(K\) does not close the nonoverload argument with the
currently proved negative-support consequences.  It yields the exact
dichotomy

\[
\text{no }A\Longrightarrow\text{the full cover (21)},
\qquad
\text{nonoverload}\Longleftrightarrow\text{failure of (23)}.   \tag{24}
\]

The real exact-Case-XII implication remains undecided because no actual
carrier satisfying (23) under all hypotheses is known, while no current
Kempe theorem rules (23) out.  The next positive statement would have to be
a bad-phase rectangle-cover exclusion theorem for two oriented singleton
projection fibres of one common cubic load.  Merely proving more terminal
path pairings inside either fibre cannot decide (22).
