# Minimal \(J\) does not determine a boundary-changing two-sum

Let \(H\) be a simple connected cubic five-pole whose BF support is exactly
the forty Case-XII pair types.  Fix two literal pivot rows

\[
\begin{aligned}
R_3&=(q_{24},r_{15},A,B,C,D),\\
R_1&=(q_{13},r_{45},A,X,C,D),
\end{aligned}
\]

sharing the actual singleton identities \(A,C,D\), and put

\[
K=2\mathbf1-A-C-D
 =q_{24}+r_{15}+B
 =q_{13}+r_{45}+X.                                      \tag{1}
\]

Among all actual choices in these two oriented decomposition fibres, let

\[
P=A\mathbin\triangle C,\qquad
J(B,X)=B\cap X\cap P                                   \tag{2}
\]

have minimum cardinality.

If \(J\ne\varnothing\), failure of every same-carrier strict descent does
not presently imply a boundary-changing two-occurrence replacement
producing \(A\) or \(T\)--\(T\).  The two assertions concern independent
parts of the decomposition data:

- descent is controlled by the internal traces of \(B,X\) on \(P\);
- a boundary-changing equal-sum replacement is controlled by the terminal
  path pairing of \(q_{24}\triangle B\) or
  \(q_{13}\triangle X\).

Exact no-\(T\)--\(T\) already fixes both terminal pairings in their allowed
directions.  A positive extremal proof therefore needs a new theorem
coupling internal trace minimality to a change of terminal pairing.  None
of Notes 055, 082, 086, or 093--097 supplies this coupling.

This is an exact information boundary, not a real Case-XII counterexample.

## The full consequence of minimality

A legal replacement \(B'\) must preserve the same literal carrier.  Thus
there must be actual companions satisfying

\[
q'_{24}+r'_{15}+B'=K.                                  \tag{3}
\]

An arbitrary class-2 perfect matching does not qualify.  With
\(R=B\mathbin\triangle B'\), Note 097 gives

\[
J(B',X)
=
\bigl(J(B,X)\setminus R\bigr)
\mathbin{\dot\cup}
\bigl((B'\setminus B)\cap X\cap P\bigr).                  \tag{4}
\]

Hence

\[
|J(B',X)|-|J(B,X)|
=
-|J(B,X)\cap R|
+|(B'\setminus B)\cap X\cap P|.                           \tag{5}
\]

At a minimum with no strict descent, every \(B'\) satisfying (3) obeys

\[
|J(B,X)\cap R|
\le
|(B'\setminus B)\cap X\cap P|,                            \tag{6}
\]

and every legal \(X'\)-replacement obeys the symmetric inequality.
Equations (3) and (6) are the entire output of the extremal argument.  They
mention neither \(q_{13}\), the terminal components of
\(q_{13}\triangle X\), nor the boundary labels of an alternate pair
decomposition.

The stronger lexicographic potential obtained from the union of all bad
rectangles and their total multiplicity is still a function only of the
two trace families on \(P\).  It adds no terminal-pairing datum.

## Equal two-occurrence sums are component-phase choices

Let \(M,N,M',N'\) be actual perfect matchings.  Then

\[
M+N=M'+N'                                             \tag{7}
\]

holds edgewise if and only if:

1. every edge of \(M\cap N\) belongs to both \(M',N'\); and
2. on each path or even-cycle component of
   \(M\mathbin\triangle N\), the pair \(M',N'\) chooses one of the two
   alternating phases.

The path-component choices determine the new boundary classes; cycle
choices change identities without changing boundary.

Apply this to \(q_{13}+X\).  Their four terminal ends are
\(\{2,3,4,5\}\).  Let \(t\) be the other endpoint of the component
starting at the singleton terminal \(3\).  Switching that component gives

\[
\begin{array}{c|c|c}
t&\text{new pair}&\text{BF type after retaining }r_{45},A,C,D\\ \hline
2&q_{12}+B'_2&(12)(45)\quad(T\text{--}T),\\
4&q_{14}+B'_4&(14)(45)\quad(S\text{--}T),\\
5&q_{15}+B'_5&(15)(45)\quad(T\text{--}T).
\end{array}                                                   \tag{8}
\]

Thus a relation of the form

\[
q_{13}+X=q_{12}+B'_2                                  \tag{9}
\]

exists exactly when terminals \(3\) and \(2\) are paired in this
bichromatic decomposition, possibly together with independent closed-cycle
phase choices.

Because the support contains no \(T\)--\(T\) type, the first and third
rows of (8) are impossible.  Therefore every actual \(X\)-decomposition in
the fixed carrier has

\[
\boxed{\pi_X(3)=4,\qquad \pi_X(2)=5.}                     \tag{10}
\]

The first literal row has the analogous table.  The terminal ends of
\(q_{24}+B\) are \(\{1,2,3,5\}\), and switching the path from singleton
terminal \(2\) gives

\[
\begin{array}{c|c|c}
t&\text{new pair}&\text{BF type after retaining }r_{15},A,C,D\\ \hline
1&q_{14}+B'_1&(14)(15)\quad(S\text{--}T),\\
3&q_{34}+B'_3&(34)(15)\quad(T\text{--}T),\\
5&q_{45}+B'_5&(45)(15)\quad(T\text{--}T).
\end{array}                                                   \tag{11}
\]

Exact negative support therefore forces

\[
\boxed{\pi_B(2)=1,\qquad \pi_B(3)=5.}                     \tag{12}
\]

Equations (10) and (12) are obtained before minimizing \(J\).  They show
that the desired one-step \(T\)--\(T\) equal sums are not latent consequences
of closure: exact no-\(T\)--\(T\) selects the unique allowed terminal path
in each colouring.

## Why a \(J\)-minimum does not alter (10) or (12)

The statistic \(J(B,X)\) sees only edges simultaneously used by the two
singleton colours and lying in the fixed owner support
\(A\mathbin\triangle C\).  The endpoint \(t\) in (8), by contrast, is a
component invariant of the pair \(q_{13},X\).  Replacing the two companions
of \(X\) while retaining the same \(X\) can change their internal cycle
phases without changing \(J\); replacing \(X\) legally is constrained only
by the numerical trace inequality (6).

There is therefore no implication of the form

\[
\text{all legal trace changes are nondecreasing}
\Longrightarrow
\pi_X(3)\in\{2,5\}
\quad\text{or}\quad
\pi_B(2)\in\{3,5\}                                    \tag{13}
\]

in the current argument.  The left side is an internal cross-intersection
condition, while the right side is a terminal-component condition.

The local \(K_{3,3}\) carrier of Note 097 makes this independence concrete.
Its \(2\times2\) row-column rectangle has \(|J|=1\) in every cell, genuine
row and column alternating-cycle switches, and no descending move.  Those
cycles are closed and hence carry no terminal endpoints.  An ambient
attachment determines the path pairings (10) and (12) independently of
the internal plateau.  The block is not a full exact-Case-XII extension,
but it rules out any local proof of (13) from common vertex incidence and
alternating-cycle structure.

## What the forty positive cells contribute

Note 055 saturates a column while retaining one actual three-matching
half-load.  Its new decompositions need not preserve the different carrier
\(K\) in (1), nor the literal identities \(A,C,D\).  Consequently it does
not place a new competitor in (3).

Note 086 gives global class-fixed-edge exclusivity.  The \(K_{3,3}\)
rectangle already has no fixed row or column edge, so that conclusion
does not force a descent.

Note 093 identifies the relevant cube-to-row gap: negative support excludes
the all-terminal and \(T\)--\(T\) exits of a partial-flip cube, but does not
force a current-row companion occurrence.  In the present setting this is
exactly the missing transition from (6) to (13).

Note 094 transfers a class-3 occurrence only under equality of two physical
residual copy-multigraphs.  No such residual equality follows from
minimality of \(J\).

Notes 096 and 097 separately show that a real common carrier need not
produce \(A\) or \(T\)--\(T\) colourings and that common cubic owner incidence
admits a nondecreasing trace rectangle.  Neither result couples the
rectangle to the terminal paths.

Thus all forty existential support flags can be present without any
currently proved identification of one of their witnesses with a
decomposition in (3) or with a forbidden phase choice in (8) or (11).

## Why the Note-024 provenance is special

In the fixed Note-024 calculation, every \(J\)-sink has the equality

\[
q_{13}+X=q_{12}+B'
\]

and hence a one-step \((12)(45)\) exit.  But its fixed carrier decomposition
graph explicitly contains two \(T\)--\(T\) vertices.  The equality is the
first row of (8), so its terminal pairing is precisely
\(\pi_X(3)=2\), which exact Case-XII support forbids by (10).

The calculation therefore establishes a special provenance inside a pole
which already has \(T\)--\(T\) support.  It does not show that removing all
\(T\)--\(T\) carrier decompositions forces a same-carrier \(J\)-descent.
The separate Note-024 mismatch calculation also exhibits nearest
single-cycle repairs with pure identity conflict and no local \(A\) or
\(T\)--\(T\)
explanation, confirming that boundary labels are not automatic outputs of
an internal phase repair.

## Sharp missing hypothesis

A descent proof would be completed by the following new
**extremal-to-terminal coupling**:

> For a fixed literal carrier (1), if a minimum-\(J\) choice has
> \(J\ne\varnothing\) and every legal same-carrier replacement satisfies
> (6), then one of the two terminal pairings leaves its allowed direction:
> \[
> \pi_X(3)\in\{2,5\}
> \quad\text{or}\quad
> \pi_B(2)\in\{3,5\},
> \]
> or an analogous component-phase choice produces an all-terminal row.

By (8) and (11), the first two alternatives immediately give a forbidden
\(T\)--\(T\) row while preserving the other four literal occurrences.
Exact Case-XII support would then contradict the assumption of no descent.

Equivalently, one may assume a **boundary-labelled equal-sum forcing**
property: failure of (6) puts a forbidden-boundary decomposition in the
equal-sum class of \(q_{13}+X\), \(q_{24}+B\), or another specified
two-occurrence pair of a literal row.

This hypothesis is sharp at the present interface because an unlabelled
equal-sum relation is insufficient: component swaps always exist, but only
the endpoint pairing determines whether the new occurrences have the
boundary labels needed for \(A\) or \(T\)--\(T\).  It must also preserve
the fixed carrier and the untouched literal occurrences; a row in another
column does not contradict minimality.

## Decision

The proposed extremal implication is not proved by the specified results.
No real exact-Case-XII counterexample is known, so the implication is not
disproved for actual poles.  The exact undecided arrow is (13):

\[
\text{fixed-carrier internal trace minimality}
\quad\Longrightarrow\quad
\text{a forbidden terminal-component phase}.
\]

The forty positive types, full perfect-matching closure, and the known
paired-switch identities do not currently connect these two data.  A proof
must add the extremal-to-terminal coupling above, or an equivalent theorem
forcing a correctly boundary-labelled two-occurrence equality.  Nothing
about residual \(14|23\) or a second splice is needed at this first gate.
