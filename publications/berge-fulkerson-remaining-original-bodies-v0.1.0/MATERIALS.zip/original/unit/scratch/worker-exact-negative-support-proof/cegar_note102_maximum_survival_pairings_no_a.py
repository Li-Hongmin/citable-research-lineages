#!/usr/bin/env python3
"""Compact exact CEGAR using maximum-survival A witnesses.

The outer domain is the full fixed-star same-column loopless pairing space.
It is seeded by the globally maximum-survival A witness of the original H0.
For every subsequent candidate, the inner solver finds a globally
maximum-survival A witness by exact prime-exponent feasibility, rather than
an arbitrary A witness.  Blocking clauses retain the exact unequal-label
form proved in ``cegar_note102_all_same_column_pairings_no_a.py``.
"""

from __future__ import annotations

import gc
import hashlib
import json
import time
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

from z3 import And, Bool, If, Not, Or, PbEq, Solver, Sum, is_true, sat, unknown

from check_note101_global_multigraph_closure import (
    FixedMultigraph,
    checked_solve,
    tt_query,
    verify_double_cover,
)
from cegar_note102_all_same_column_pairings_no_a import (
    components,
    dependent_fibre_query,
    double_factorial_odd,
    positive_case_xii_query,
    selected_family_checks,
)


HERE = Path(__file__).resolve().parent
INPUT = HERE / "note101_global_stub_pairing_result.json"
SEED = HERE / "note102_original_maximum_a_survival_result.json"
OUTPUT = HERE / "note102_maximum_survival_pairing_cegar_result.json"
TERMINALS = tuple(range(5))
EXPONENT_TRIPLES = tuple(sorted(
    [((3 ** e3) * (5 ** e5) * (7 ** e7), e3, e5, e7)
     for e3 in range(15) for e5 in range(5) for e7 in range(2)],
    reverse=True,
))


def label_equal(variables, left, right):
    return And(*(variables[slot][left] == variables[slot][right]
                 for slot in range(6)))


def maximum_a_query(graph, edge_records, deadline):
    solver = Solver()
    boundaries = tuple(frozenset((terminal,)) for terminal in TERMINALS) + (
        frozenset(TERMINALS),
    )
    variables = tuple(
        graph.matching_vars(solver, f"A_slot{slot}", boundary)
        for slot, boundary in enumerate(boundaries)
    )
    for edge in range(graph.m):
        solver.add(PbEq([(variables[slot][edge], 1) for slot in range(6)], 2))

    edges_by_block = defaultdict(list)
    for edge, item in enumerate(edge_records):
        edges_by_block[item["block"]].append(edge)
    assert Counter(map(len, edges_by_block.values())) == Counter({1: 67, 2: 9, 3: 3, 4: 1})

    exp3_terms = []
    exp5_terms = []
    exp7_terms = []
    for edges in edges_by_block.values():
        if len(edges) == 1:
            continue
        equality = {
            (i, j): label_equal(variables, edges[i], edges[j])
            for i in range(len(edges)) for j in range(i + 1, len(edges))
        }
        any_equal = Or(*equality.values())
        if len(edges) == 2:
            exp3_terms.append(If(equality[(0, 1)], 1, 0))
            continue
        if len(edges) == 3:
            all_equal = And(equality[(0, 1)], equality[(0, 2)])
            exp3_terms.append(If(any_equal, 1, 0))
            exp5_terms.append(If(all_equal, 1, 0))
            continue
        assert len(edges) == 4
        all_equal = And(equality[(0, 1)], equality[(0, 2)], equality[(0, 3)])
        triple = Or(
            And(equality[(0, 1)], equality[(0, 2)]),
            And(equality[(0, 1)], equality[(0, 3)]),
            And(equality[(0, 2)], equality[(0, 3)]),
            And(equality[(1, 2)], equality[(1, 3)]),
        )
        two_pairs = Or(
            And(equality[(0, 1)], equality[(2, 3)], Not(equality[(0, 2)])),
            And(equality[(0, 2)], equality[(1, 3)], Not(equality[(0, 1)])),
            And(equality[(0, 3)], equality[(1, 2)], Not(equality[(0, 1)])),
        )
        exp3_terms.append(If(two_pairs, 2, If(any_equal, 1, 0)))
        exp5_terms.append(If(triple, 1, 0))
        exp7_terms.append(If(all_equal, 1, 0))

    exp3 = Sum(*exp3_terms)
    exp5 = Sum(*exp5_terms)
    exp7 = Sum(*exp7_terms)
    checks = 0
    chosen = None
    for survival, e3, e5, e7 in EXPONENT_TRIPLES:
        remaining_ms = max(1, int(1000 * (deadline - time.monotonic() - 3.0)))
        if remaining_ms <= 1:
            return {"status": "unknown", "reason": "global_deadline",
                    "feasibility_checks": checks}
        checks += 1
        solver.push()
        solver.add(exp3 == e3, exp5 == e5, exp7 == e7)
        solver.set(timeout=remaining_ms)
        result = solver.check()
        if result == unknown:
            reason = solver.reason_unknown()
            solver.pop()
            return {"status": "unknown", "reason": reason,
                    "feasibility_checks": checks}
        if result == sat:
            chosen = (survival, e3, e5, e7, solver.model())
            solver.pop()
            break
        solver.pop()
    if chosen is None:
        return {"status": "unsat", "feasibility_checks": checks}

    survival, e3, e5, e7, model = chosen
    matchings = tuple(
        graph.extract_matching(model, variables[slot], boundary)
        for slot, boundary in enumerate(boundaries)
    )
    verify_double_cover(matchings, graph.object_count)
    return {
        "status": "sat", "feasibility_checks": checks,
        "maximum_survival_pairings": survival,
        "prime_exponents": {"3": e3, "5": e5, "7": e7},
        "singletons": [list(item) for item in matchings[:5]],
        "all_terminal": list(matchings[5]),
    }


def witness_clause(potential, pair_var, stubs, edge_records, witness):
    matchings = tuple(
        frozenset(item) for item in
        (*witness["singletons"], witness["all_terminal"])
    )
    stub_label = {}
    for edge, item in enumerate(edge_records):
        label = sum(1 << index for index, matching in enumerate(matchings)
                    if edge in matching)
        assert label.bit_count() == 2
        for vertex in item["ends"]:
            stub_label[(item["block"], vertex)] = label
    assert len(stub_label) == 196

    ids = []
    variables = []
    for item in potential:
        block, left, right = item["block"], *item["ends"]
        if stub_label[(block, left)] != stub_label[(block, right)]:
            ids.append(item["pair_id"])
            variables.append(pair_var[(block, left, right)])

    survival = 1
    for block, vertices in stubs.items():
        counts = Counter(stub_label[(block, vertex)] for vertex in vertices)
        assert all(count % 2 == 0 for count in counts.values())
        for count in counts.values():
            survival *= double_factorial_odd(count)
    return ids, variables, survival


def emit(record):
    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": record["status"], "iterations": record["iterations"],
        "a_blocking_clauses": record["a_blocking_clauses"],
        "connectivity_cuts": record["connectivity_cuts"],
        "pairing_space": record["pairing_space"],
        "elapsed_s": record["elapsed_s"],
    }, sort_keys=True))


def main():
    started = time.monotonic()
    deadline = started + 220.0
    base = json.loads(INPUT.read_text())
    seed = json.loads(SEED.read_text())
    vertices = base["vertices"]
    n = len(vertices)
    stubs = defaultdict(list)
    for vertex, record in enumerate(vertices):
        for block in record["blocks"]:
            if record["kind"] == "terminal" and block == record["terminal_block"]:
                continue
            stubs[block].append(vertex)
    block_column = {}
    for item in base["proper_edges"]:
        block_column[item["block"]] = item["column"]

    outer = Solver()
    potential = []
    pair_var = {}
    incident = defaultdict(list)
    for block in sorted(stubs):
        for left, right in combinations(sorted(stubs[block]), 2):
            value = Bool(f"pair_b{block}_v{left}_v{right}")
            pair_id = len(potential)
            potential.append({"pair_id": pair_id, "block": block,
                              "column": block_column[block], "ends": [left, right]})
            pair_var[(block, left, right)] = value
            incident[(block, left)].append(value)
            incident[(block, right)].append(value)
    assert len(potential) == 194
    for block, vertices_for_block in stubs.items():
        for vertex in vertices_for_block:
            outer.add(PbEq([(value, 1) for value in incident[(block, vertex)]], 1))
    pairing_space = 1
    for vertices_for_block in stubs.values():
        pairing_space *= double_factorial_odd(len(vertices_for_block))
    assert pairing_space == 6_975_163_125

    seed_witness = {
        "singletons": seed["matchings"][:5],
        "all_terminal": seed["matchings"][5],
    }
    seed_ids, seed_vars, seed_survival = witness_clause(
        potential, pair_var, stubs, base["proper_edges"], seed_witness
    )
    assert seed_survival == seed["maximum_survival_pairings"] == 465_010_875
    outer.add(Or(*seed_vars))

    iteration_records = [{
        "kind": "seed_original_H0_maximum_witness",
        "blocking_pair_ids": seed_ids,
        "blocking_clause_size": len(seed_ids),
        "maximum_survival_pairings": seed_survival,
        "A_witness": seed_witness,
    }]
    a_clauses = 1
    connectivity_cuts = 0
    status = None
    final_candidate = None
    post_no_a = None

    while status is None:
        result, reason = checked_solve(outer, deadline)
        if result == unknown:
            status = "unknown_at_outer"
            post_no_a = {"reason": reason}
            break
        if result != sat:
            status = ("all_loopless_pairings_have_A" if connectivity_cuts == 0
                      else "all_connected_loopless_pairings_have_A")
            break

        model = outer.model()
        chosen = []
        chosen_ids = []
        for item in potential:
            block, left, right = item["block"], *item["ends"]
            if is_true(model.eval(pair_var[(block, left, right)])):
                chosen_ids.append(item["pair_id"])
                chosen.append({"block": block, "column": item["column"],
                               "ends": [left, right]})
        assert len(chosen) == 98
        candidate_record = dict(base)
        candidate_record["proper_edges"] = chosen
        graph = FixedMultigraph(candidate_record)
        selected = selected_family_checks(graph)
        graph_components = components(n, graph.edges)
        candidate_hash = hashlib.sha256(
            json.dumps(chosen_ids, separators=(",", ":")).encode()
        ).hexdigest()

        a_result = maximum_a_query(graph, chosen, deadline)
        record = {
            "kind": "candidate", "candidate_sha256": candidate_hash,
            "chosen_pair_ids": chosen_ids,
            "components": [list(item) for item in graph_components],
            "A_status": a_result["status"],
            "A_feasibility_checks": a_result.get("feasibility_checks"),
        }
        if a_result["status"] == "unknown":
            record["A_reason"] = a_result.get("reason")
            iteration_records.append(record)
            status = "unknown_at_inner_maximum_A"
            break
        if a_result["status"] == "sat":
            ids, variables, survival = witness_clause(
                potential, pair_var, stubs, chosen, a_result
            )
            assert survival == a_result["maximum_survival_pairings"]
            assert not set(chosen_ids).intersection(ids)
            outer.add(Or(*variables) if variables else False)
            a_clauses += 1
            record.update({
                "blocking_pair_ids": ids,
                "blocking_clause_size": len(ids),
                "maximum_survival_pairings": survival,
                "prime_exponents": a_result["prime_exponents"],
                "A_witness": {
                    "singletons": a_result["singletons"],
                    "all_terminal": a_result["all_terminal"],
                },
            })
            iteration_records.append(record)
            del graph
            gc.collect()
            continue

        assert a_result["status"] == "unsat"
        if len(graph_components) > 1:
            component_of = {vertex: index for index, component in enumerate(graph_components)
                            for vertex in component}
            crossing_ids = []
            crossing_vars = []
            for item in potential:
                left, right = item["ends"]
                if component_of[left] != component_of[right]:
                    crossing_ids.append(item["pair_id"])
                    crossing_vars.append(pair_var[(item["block"], left, right)])
            outer.add(Or(*crossing_vars))
            connectivity_cuts += 1
            record.update({"disconnected_no_A": True,
                           "connectivity_cut_pair_ids": crossing_ids})
            iteration_records.append(record)
            continue

        record["connected_no_A"] = True
        iteration_records.append(record)
        final_candidate = {"candidate_sha256": candidate_hash,
                           "chosen_pair_ids": chosen_ids, "proper_edges": chosen}
        tt = tt_query(graph, deadline)
        post_no_a = {"TT": tt}
        if tt["status"] == "sat":
            status = "connected_no_A_repaired_by_TT"
            break
        if tt["status"] == "unknown":
            status = "connected_no_A_unknown_at_TT"
            break
        fibre = dependent_fibre_query(graph, selected, deadline)
        post_no_a["dependent_fibre"] = fibre
        if fibre["status"] == "sat":
            status = "connected_no_A_repaired_by_dependent_fibre"
            break
        if fibre["status"] == "unknown":
            status = "connected_no_A_unknown_at_dependent_fibre"
            break
        positive = positive_case_xii_query(graph, deadline)
        post_no_a["positive_case_xii"] = positive
        status = ("real_exact_case_xii_note082_counterexample_candidate"
                  if positive["status"] == "exact_positive_and_tait"
                  else "connected_no_A_unknown_at_positive_case_xii"
                  if positive["status"] == "unknown"
                  else "connected_no_A_but_not_exact_case_xii")

    output = {
        "status": status,
        "input_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        "seed_sha256": hashlib.sha256(SEED.read_bytes()).hexdigest(),
        "pairing_space": pairing_space,
        "potential_pair_variables": len(potential),
        "outer_domain": ("all_loopless_pairings" if connectivity_cuts == 0
                         else "connected_loopless_pairings_after_lazy_cuts"),
        "iterations": len(iteration_records),
        "a_blocking_clauses": a_clauses,
        "connectivity_cuts": connectivity_cuts,
        "potential_pairs": potential,
        "iteration_records": iteration_records,
        "final_candidate": final_candidate,
        "post_no_A": post_no_a,
        "elapsed_s": time.monotonic() - started,
    }
    emit(output)
    if status in ("all_loopless_pairings_have_A",
                  "all_connected_loopless_pairings_have_A"):
        print("NOTE102_MAXIMUM_SURVIVAL_CEGAR_FORCE_A")
    elif status == "real_exact_case_xii_note082_counterexample_candidate":
        print("NOTE102_MAXIMUM_SURVIVAL_REAL_COUNTEREXAMPLE_CANDIDATE")
    elif status.startswith("unknown") or "_unknown_" in status:
        print("NOTE102_MAXIMUM_SURVIVAL_CEGAR_UNKNOWN")
    else:
        print("NOTE102_MAXIMUM_SURVIVAL_CONNECTED_NO_A_FOUND")


if __name__ == "__main__":
    main()
