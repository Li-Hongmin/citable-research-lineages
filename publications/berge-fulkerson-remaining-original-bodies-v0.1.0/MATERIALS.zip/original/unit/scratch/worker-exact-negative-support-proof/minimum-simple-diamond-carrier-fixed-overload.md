# A minimum simple replacement preserves carrier-fixed overload

This note verifies the complete state set of the seven-vertex parallel-edge
example and replaces its parallel pair by the minimum simple cubic 2-pole.
The result is a nine-vertex simple cubic 5-pole with an actual complementary
BF half, state set exactly \(S\), a carrier-fixed overload, and a global
same-class avoiding matching.

## The seven-vertex boundary really has state set exactly \(S\)

Let \(K\) be the 5-cycle pole with terminal labels in cyclic order

\[
  1,3,5,2,4.
\]

Its complete proper-colouring state set is

\[
  \mathcal R(K)=S=\{13,35,25,24,14\}.           \tag{1}
\]

To see completeness, a proper 3-edge-colouring of an odd 5-cycle has cycle
edge-colour multiplicities \(2,2,1\).  The endpoints of the uniquely
coloured cycle edge receive the other two colours on their semiedges, while
the remaining three semiedges receive the unique edge colour.  Hence the
two singleton terminals are adjacent on the boundary cycle.  Conversely,
choosing any boundary edge as the uniquely coloured edge and alternating
the other two colours around the remaining path realizes its endpoint pair.
These five adjacent pairs are exactly (1).

Fix state \(13\), and write \(r=xy\) for the cycle edge whose terminal ends
are labelled 1 and 3.  In every oriented state-13 colouring, the semiedges
at \(x,y\) have singleton colours 1 and 3, so properness forces \(r\) to
have the third colour \(q\).

In the seven-vertex multigraph example, \(r\) is replaced by outside edges
\(xu,vy\) and two parallel original edges \(e,g\) between \(u,v\).  The
half-load \(A\) has

\[
 A(xu)=A(vy)=1,\qquad A(e)=2,\qquad A(g)=0,      \tag{2}
\]

and has load one on every other edge of \(K\).  The load graph \(H_A\)
therefore has two copies of \(e\).  In every colouring of \(H_A\), these
copies have distinct colours and \(xu,vy\) have their common third colour.
Compression gives a colouring of \(K\); every colouring of \(K\) lifts in
exactly two ways. Hence

\[
  \mathcal R(A)=\mathcal R(K)=S.                \tag{3}
\]

For state 13, the outside colour is always \(q\), so both copies of \(e\)
have colours 1 and 3.  The oriented carrier fibres in classes 1 and 3 are
therefore fixed on \(e\).  Globally, either singleton matching can replace
\(e\) by the parallel edge \(g\), so both classes nevertheless have an
\(e\)-avoiding perfect matching.  This confirms all claims about the
parallel-edge boundary without relying on a bounded colouring list.

## The minimum simple cubic 2-pole

Replace the edge \(r=xy\) of \(K\) by a diamond.  Introduce four vertices
\(u,p,q,v\), attach \(x\) to \(u\) and \(v\) to \(y\), and put

\[
 E_{\rm diamond}=\{up,uq,pq,pv,qv\}.            \tag{4}
\]

Thus the internal gadget is \(K_4-uv\), with \(u,v\) as its two degree-two
ports before the outside attachments.  The resulting pole \(H\) is simple,
connected and cubic, has the same five distinct terminal vertices, and has
order nine.

This diamond is the minimum local simple replacement with one attachment at
each end.  With two internal vertices, each port would need two internal
neighbours but only one simple port-to-port edge is available.  With three
vertices, the nonport vertex would require internal degree three in a
three-vertex simple graph, which is impossible.  Four vertices suffice, and
the required internal degree sequence \((2,2,3,3)\) has sum ten; its unique
simple realization is \(K_4\) minus the port-to-port edge.

## Two complementary real half-loads

Lift the oriented state-13 colouring of \(K\) through the diamond as
follows.  Let the triple-colour perfect matching use

\[
  xu,\quad pq,\quad vy,                          \tag{5}
\]

and let each of the singleton-colour matchings 1 and 3 use

\[
  up,\quad qv.                                   \tag{6}
\]

Outside the replacement, retain the corresponding colour class of \(K\).
These are three actual perfect matchings of \(H\).  Their half-load \(A\)
has

\[
\begin{array}{c|ccccc}
f&up&qv&uq&pv&pq\\ \hline
A(f)&2&2&0&0&1,
\end{array}                                      \tag{7}
\]

and \(A(xu)=A(vy)=1\).

Define three further perfect matchings by keeping the triple matching (5)
and replacing (6), in each singleton colour, by

\[
  uq,\quad pv.                                   \tag{8}
\]

Their sum \(B\) satisfies

\[
\begin{array}{c|ccccc}
f&up&qv&uq&pv&pq\\ \hline
B(f)&0&0&2&2&1,
\end{array}                                      \tag{9}
\]

and agrees with unit load \(A=B=1\) on the outside edges, every unchanged
cycle edge, and every semiedge.  Consequently

\[
  A+B=2\mathbf1,                                \tag{10}
\]

so the six displayed matchings form an actual BF cover of loop type
\((13)(13)\).

## Complete decomposition state set of the simple half-load

The load graph \(H_A\) contains two copies of \(up\), two copies of \(qv\),
and one copy each of \(xu,pq,vy\); the edges \(uq,pv\) are absent.  In any
proper 3-edge-colouring:

- the double edge \(up\) forces \(xu\) and \(pq\) to have the same third
  colour;
- the double edge \(qv\) forces \(pq\) and \(vy\) to have the same third
  colour.

Thus \(xu,pq,vy\) have one common colour.  Replacing that three-edge chain
by \(r=xy\) gives a proper colouring of \(K\).  Conversely, every colouring
of \(K\) lifts, independently assigning the other two colours to the two
copies in each double edge.  Therefore

\[
  \mathcal R(A)=\mathcal R(K)=S                 \tag{11}
\]

for the complete, not merely displayed, decomposition family.

In oriented state 13, the replacement edge \(r\) is always triple-coloured.
Hence both double edges in \(H_A\), in particular the two copies of the
original proper edge

\[
  e=up,                                          \tag{12}
\]

receive singleton colours 1 and 3.  Every class-1 occurrence in the
oriented state-13 carrier fibre of \(A\) uses \(e\).

Yet the class-1 matching in (8) is a genuine same-boundary perfect matching
avoiding \(e\).  It lies in the complementary half \(B\), not in \(A\): its
use of \(uq\), where \(A(uq)=0\), already prevents carrier entry.  Thus the
simple example has global class flexibility but carrier-fixed overload.

## Exact boundary

The nine-vertex diamond pole proves, purely analytically, that a single real
half-load may be fully \(S\)-saturated while an oriented singleton fibre is
fixed on an overload edge.  This persists even when the same pole contains
an explicit avoiding matching and the half-load has an actual complementary
three-matching half forming a BF row.

The example is not asserted to have exact-40 full BF support.  Its role is
to close the implication

\[
 \mathcal R(A)=S+\text{global class flexibility}
 \quad\Longrightarrow\quad
 \text{carrier-fibre flexibility},              \tag{13}
\]

which is false even for a minimum local simple replacement.  Any positive
exact-Case-XII theorem must use relations between distinct carriers or the
negative full-support assumptions, not saturation of one carrier alone.
