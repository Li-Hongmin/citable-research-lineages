# A legal first splice does not yet determine an extendible splice chain

This note uses only Notes 082--091.  It concerns one literal-anchored target
in the repeated-extension branch and assumes that at least one legal first
paired splice is already available.  No graph search is used.

## The conditional extension statement

Write the anchored source row as

\[
 R=(q,r,B,X,P_1,P_2),
\]

where \(B,X\) are the pointwise-fixed literal anchors and
\(\widehat P_1,\widehat P_2\) are the desired singleton occurrences.  For
the endpoint order \(1,2\), let

\[
 \mathcal E_{12}=
 \{N\in R\setminus\{P_1\}:
   \operatorname{Sep}(N;P_1,\widehat P_1)\}.       \tag{1}
\]

By Notes 082 and 091, \(N\in\mathcal E_{12}\) is exactly a legal first
splice.  It produces the forced matching

\[
 N'=N+P_1-\widehat P_1                              \tag{2}
\]

and the intermediate row \(R_N\).  If \(N\ne P_2\), put
\(P_2^N=P_2\).  If \(N=P_2\), put

\[
 P_2^N=P_2+P_1-\widehat P_1.                       \tag{3}
\]

Define the continuation fibre

\[
 \mathcal K_{12}(N)=
 \{M\in R_N\setminus\{P_2^N\}:
   \operatorname{Sep}(M;P_2^N,\widehat P_2)\}.     \tag{4}
\]

Define \(\mathcal E_{21}\) and \(\mathcal K_{21}\) by exchanging the two
endpoints.  Finally let \(\Theta_1,\Theta_2\) be the two forced-intermediate
conditions.  Explicitly, \(\Theta_1\) holds when

\[
 Z_1=\widehat P_1+\widehat P_2-P_2                 \tag{5}
\]

is a \(0/1\) vector and some allowed triple occurrence \(N\) makes
\(N+P_1-Z_1\) a \(0/1\) vector; \(\Theta_2\) is symmetric.

The conditional second-step assertion is the following single falsifiable
statement:

\[
\boxed{
 (\mathcal E_{12}\cup\mathcal E_{21}\ne\varnothing)
 \Longrightarrow
 \left[
   \bigvee_{N\in\mathcal E_{12}}
      \mathcal K_{12}(N)\ne\varnothing
   \ \vee\!
   \bigvee_{N\in\mathcal E_{21}}
      \mathcal K_{21}(N)\ne\varnothing
   \ \vee\Theta_1\vee\Theta_2
 \right].
}                                                        \tag{6}
\]

Thus the extra hypothesis in the present pulse says only that the
antecedent of (6) holds.  The desired conclusion requires an *extendible*
member of that nonempty first-step set.

## The exact minimum obstruction

Negating the consequent of (6) gives a complete obstruction:

\[
\begin{aligned}
 &\mathcal K_{12}(N)=\varnothing
       &&\text{for every }N\in\mathcal E_{12},\\
 &\mathcal K_{21}(N)=\varnothing
       &&\text{for every }N\in\mathcal E_{21},\\
 &\neg\Theta_1\quad\text{and}\quad\neg\Theta_2.       \tag{7}
\end{aligned}
\]

There is no further matching-existence condition hidden in (7).  Every
forced vector has the correct incident degree and boundary; common cubic
full-perfect-matching closure says that it belongs to the matching family
exactly when it is coordinatewise \(0/1\).

For a fixed legal first choice \(N\), label every desired-phase edge of
\(P_2^N\triangle\widehat P_2\) by the two other occurrences of \(R_N\)
using that edge.  Note 082 identifies \(\mathcal K_{12}(N)\) with the
intersection of these labels.  By Note 084, every inclusion-minimal
certificate that this intersection is empty is, up to renaming companion
occurrences, exactly one of

\[
 \{\{a,b\},\{c,d\}\},                             \tag{8}
\]

or

\[
 \{\{a,b\},\{a,c\},\{b,c\}\}.                    \tag{9}
\]

The same two cores classify every failed continuation in the reverse
order.  A forced-intermediate branch fails minimally either because the
corresponding \(Z_i\) already has a coordinate outside \(\{0,1\}\), or,
after \(Z_i\) is binary, because all allowed triple companions fail the
same \(\operatorname{Sep}\) sign test.  Equations (7)--(9), together with
these two forced-vector failures, are the precise minimum obstruction after
one legal first splice is assumed.

## Why exact negative support does not currently remove the obstruction

The first splice certifies a sign condition only on
\(P_1\triangle\widehat P_1\).  The continuation fibres (4) are sign
conditions on the generally different symmetric difference
\(P_2^N\triangle\widehat P_2\).  The identity (2) updates one companion,
but supplies no occurrence that has the desired phase on every component
of this second difference.

Absence of the all-terminal type makes every partial-flip cube member meet
the relevant anchor double-load set.  Absence of \(T\)-loops and
\(T\)--\(T\) support forbids certain disjoint pairs and restricts a cube
member after it has entered a carrier.  As emphasized in Notes 084 and
091, these have the forms

\[
 \forall I\ \exists e_I
 \quad\text{and}\quad
 P^I\text{ enters a carrier}\Longrightarrow\text{allowed state}. \tag{10}
\]

Neither statement names a common occurrence \(M\) in the updated row.
Consequently (10) does not make any intersection in (8)--(9) nonempty.
Conditioning on one first-step \(\operatorname{Sep}\) value does not change
this mismatch of occurrence quantifiers.

Notes 083--090 separately rule out deriving the missing common occurrence
from one-row edge labels, cyclic connectivity, partial-flip closure, global
class avoidance, carrier saturation, or an independent alternating-chain
phase.  Note 085 supplies an abstract all-failed system, but its displayed
targets have no legal first step and it lacks common cubic full closure; it
therefore does not refute the conditional statement (6).

## Decision boundary

Notes 082--091 do not prove (6).  They also contain no real exact-Case-XII
pole satisfying its antecedent and violating its consequent, so they do not
disprove it.  The conditional pulse stops at the exact obstruction (7)--(9):
one must prove that at least one legal first companion avoids the two empty-
intersection cores on the second difference, or that one forced-intermediate
vector passes both \(0/1\) sign tests.

This is a cross-difference occurrence theorem, strictly stronger than the
existence of a first splice.  More support rows, edge-hitting conditions, or
independent partial flips that do not couple the same updated occurrence to
the second endpoint cannot establish it.
