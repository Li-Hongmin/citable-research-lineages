# A reverse singleton-companion gate for the full Case-XII matching closure

This is a conditional analytic result awaiting independent verification before promotion to a numbered note. It uses only actual complete perfect matchings and the exact Case-XII **negative** BF support. It neither proves existence nor nonexistence of an exact-Case-XII pole.

Latest conditional boundary in the short-diamond, two-collision, three-visit branch: the normalized second \(q/C\) component collects the two \(Q\) collisions and both return exits (34); a complete closed switch excludes coincident exits (35). A direct \(\bar B=r\) bridge between distinct return exits is also excluded by a full eight-edge switch (35a). With distinct exits and exactly five carrier visits, the closed component needs the middle-end orientation. If its return exits are joined by a single \(UC\) bridge, a further complete \(q/B\) switch excludes a direct \(P\)-traversal of the return and forces \(|R|\ge7\) (36)--(37). If they are joined along a right type-23 strand instead, the literal \(q/B\) route requires further outer-piece \(P\)-exits. If \(L\) is open and the other \(M\)-jump lies on a closed \(q/C\) component, that component needs at least three \(P\)-visits (38). If both jumps lie on the open \(L\), the terminal-\(3\)-tail order forces a new proper \(P\)-visit, while the terminal-\(1\)-tail order without one has three explicit terminal or \(F\)-bridge docking options (39). The terminal-docking phases fail Note 131's common-path criterion in the displayed row. Across their fixed complete singleton fibre, confluence is exactly a containment test on the \(r'\)-phase of the forced \(q'/r'\) path (40a); it must avoid every vertex of the return \(R\), and in either terminal docking it forces a prescribed class-five alternating cycle through both return exits (40)--(42). Under no new proper \(P\)-contact, both far ends cannot dock at the ten-cycle bridge. If one does, a right-type-23 far end must dock at a terminal, whereas a type-13 far end attaches directly to terminal \(3\) by a \(B=C\) edge (43)--(45),(47). A terminal-\(2\) far end on the terminal-\(3\) tail has no Note-131 common path anywhere in the fixed fibre (46). Counting the middle edge \(ef\) also sharpens the conditional \(|M|=5\) order floors to \(27\) for an \(nm=DC\) bridge and \(29\) for an \(nm=UC\) bridge. These surviving dockings, closed \(L\) with more \(P\)-visits, and other short-diamond branches remain unresolved; so does full Case-XII closure.

The latest manual check further excludes the two direct terminal dockings together (43a). A type-13 far end cannot lie on the terminal-\(1\) tail; on the terminal-\(3\) tail it is directly \(B=C\)-adjacent to terminal \(3\), which makes Note 131's common-path set empty in the entire fixed singleton fibre (47)--(48). If the terminal-\(1\)-tail far end itself is terminal \(2\), any fixed-fibre confluence forces its \(C\)-edge to meet the cross-jump and forces that jump into the same class-five phase cycle as both return exits (49). These are conditional analytic deductions, still awaiting independent verification.

A right-type-23 far end directly \(B=r\)-adjacent to terminal \(3\) instead forces a closed type-23 strand \(H\). Switching the **complete** \(C,r\) pair on \(H\) detours the forced \(q/r\) path and changes its canonical class-35 matching by the same \(H\), which is already a closed \(p/D\) component. The terminal pairing is unchanged (50). Original \(J'=5\) forces all internal vertices of \(H\) into the normalized type-12 phase, giving a six-edge floor at girth five. Thus this particular full-matching closure operation cannot eliminate the mixed docking; the exact-support realization question remains open.

The same switch preserves the two external collisions, seven \(P\)-contacts, ten-cycle \(F\), and no-seed pairing in the normalized row, and separately preserves the aligned original \(J'=5\) count after undoing the \(q/B\) normalization (51)--(52). These are two commuting representations, not one row with both \(\bar q,\bar B\) fixed and original \(J'=5\). The terminal-\(3\) edge becomes \(B=C\). A further actual fixed-\(B\) right-row involution changes its local \(B+C\) load from \(2b\) to \(b+d\), removing the endpoint zero-load barrier in the new fibre (53)--(54). In this docking branch \(H\) then becomes a closed \(r\triangle D\) phase, so another complete switch puts \(r\) on the terminal-\(3\) \(B\)-edge (55). The complete masks satisfy the two-path cycle identity (56). The return corridor is shared by an open \(q^{\rm new}\triangle C_4^*\) path and one \(r\triangle D^{\rm final}\) component (59). A terminal-arm trace forces \(G_{45}\) through \(k_a\), and the ten-cycle bridge puts that component on the open \(1\leftrightarrow2\) path (60)--(62). Thus the entire displayed fixed-four-mask fibre fails the common-path criterion, even after repairing the terminal-\(3\) edge. The direct Note-139 companion row also reaches the same first return edge despite its type-12 phase rerouting (63)--(65). More generally, the left and right complete pair-load spectra have a locally balanced row at each of terminals \(1,3,5\), separately (58). The full left-right pair-load intersection and exact-support realization remain open.

A second complete-mask gate below proves that a \(4\to1\) or
\(4\to2\) endpoint in the first Note-129 \(r/\widehat C\) test gives
the literal common \(B,C,Y\) seed; no seed therefore forces
\(4\to5\) in every right row and closed phase (66)--(68).
For the direct terminal-\(3\) docking, the entire first-switch phase
cube has pairing \((1\,2)(4\,5)\) by an edgewise trace (69)--(71).
The Note-139 companion takes the opposite singleton phase on the
theta core (72). Any departure from \((1\,2)(4\,5)\) would require
two new \(B\cap Y\) arm contacts, but the single exterior right
junction permits at most one; this closes its whole first-switch
phase cube as well (74)--(76).
More decisively, applying the general endpoint gate to the full
Note-129 partner makes the original \(r_{34}\triangle C_4\)
terminal pairing a seed test (77). In either surviving aligned
\(J'=5\) right-port pairing, the literal \(r/C\) path joins
\(5\leftrightarrow2\), so the other path joins
\(4\leftrightarrow1\) (78)--(79). Subject to independent checking
of the port classification (17)--(18) and this reverse gate,
the entire aligned six-edge \(J'=5\) short-diamond branch has a
common complete \(B+C\) seed; the earlier no-seed docking analysis
cannot be a realized branch of that normalized profile.
The same crossed-port argument applies to the \((1,2,1,2)\)
owner sequence. The other two six-edge sequences have a direct
\(4\leftrightarrow5\) \(r/C\) core path, leaving exactly
\((2,2,1,1)\) and \((1,1,2,2)\) as candidate no-seed
patterns at aligned \(J'=5\) (80)--(81).

Let \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Assume a cubic five-pole has no all-terminal BF cover and no BF cover of a \(T\)--\(T\) type, including loops. Start with an actual all-\(S\) row obtained by the cross-half switch of [Note 131](../notes/131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md):
\[
p_{35}+B_2+D_5+t_{24}+Y_3+C_4=2\mathbf1.                \tag{1}
\]
Call a proper cycle \(\Gamma\) *reverse-aligned* if it alternates between \(p\) and one of the **three literal singleton occurrences** \(B_2,Y_3,C_4\). This is equivalent to that occurrence owning every non-\(p\) edge of \(\Gamma\).

## Singleton-cycle closure

**Theorem 1.** If there is no common complete \(B_2+C_4\) seed, every reverse-aligned proper cycle \(\Gamma\) preserves the \(5\)-terminal partner of \(p\triangle D\) when it is toggled in \(p\). More generally, toggling any collection of vertex-disjoint reverse-aligned cycles, using a possibly different singleton companion for each cycle, preserves that partner. Under no-seed it therefore remains \(4\).

**Proof.** Switch \(p\) and the chosen singleton companion on each selected cycle. These are genuine matching switches: the cycles are proper and vertex-disjoint, so all six boundaries and the double-cover identity in (1) survive. Write the new triple as \(w_{35}\) and the updated singleton occurrences as \(B'_2,Y'_3,C'_4\). The literal \(D_5,t_{24}\) remain fixed, giving
\[
w_{35}+B'_2+D_5+t_{24}+Y'_3+C'_4=2\mathbf1.          \tag{2}
\]
The open component of \(w\triangle t\) from terminal \(2\) must end at \(3\). If it ended at \(4\), switching that path would produce an all-terminal matching; if it ended at \(5\), the two new triple states would be \(23,45\in T\). Thus the forced \(2\leftrightarrow3\) switch converts (2) into a genuine right \((25)(34)\) row with the same complete \(B',D,Y',C'\) masks. Switching that path back gives \(w+t\) as its cross-half phase. By [Note 136](../notes/136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md), if the \(5\)-terminal path of \(w+D\) ended at \(1\) or \(2\), that right row would give a left row with the *same complete* \(B',C'\) masks. Under no-seed it therefore ends at \(4\). The same argument with the empty set of cycles gives partner \(4\) for \(p+D\). \(\square\)

## A componentwise reverse certificate

Let \(A_{35}\) be any actual matching with \(A\triangle D\) pairing \(5\) with \(1\), and write its difference from \(p\) as disjoint proper even cycles \(A\triangle p=\Gamma_1\sqcup\cdots\sqcup\Gamma_k\). For a non-\(p\) edge \(e\) of a cycle, let \(M(e)\subseteq\{B,Y,C\}\) be the literal singleton occurrences in (1) that own \(e\).

**Theorem 2.** Under no-seed, after discarding every \(\Gamma_i\) whose \(p\)-phase edges are all owned by \(D\), at least one remaining component has
\[
\boxed{\bigcap_{e\in E(\Gamma_i)\cap E(A)}M(e)=\varnothing.}  \tag{3}
\]
Such a component has a \(p\)-phase edge avoided by \(D\), and it can be chosen **pairing-critical** after toggling some other components of \(A\triangle p\) from the \(p\) side. The empty intersection in (3) has a certificate on at most three non-\(p\) edges. If \(A\) is a Tait matching disjoint from \(D\), then every \(M(e)\) is nonempty, so the certificate needs two or three edges.

**Proof.** First toggle **all** reverse-aligned components of \(A\triangle p\) in \(p\), pairing each with a chosen literal singleton. Theorem 1 preserves the \(5\)-partner \(4\) and produces an actual all-\(S\) row. Next toggle, in the new triple matching alone, every remaining component whose \(p\)-phase lies in \(D\). Such a cycle is a closed component of \(A\triangle D\); before this latter toggle, its vertices form isolated doubled \(p+D\) edges, and afterward they form a closed alternating \(A\triangle D\) cycle. It therefore does not touch either open terminal path and keeps the partner \(4\). These toggles preserve matchinghood and boundaries, although the singleton row need not survive the second kind of toggle.

The remaining components have empty singleton-companion intersection and at least one \(p\)-phase edge avoided by \(D\). Toggle them one by one. The final triple matching is \(A\), whose \(5\)-partner with \(D\) is \(1\); hence one of these remaining components changes the partner. It is the required pairing-critical component satisfying (3).

There are only three singleton labels. If the intersection of their subsets is empty, choose for each label one edge whose set misses it; these at most three edges witness emptiness. If \(A\cap D=\varnothing\), a non-\(p\) edge of \(A\triangle p\) cannot be owned by \(D\), and the double-cover row (1) gives it two owners among \(B,t,Y,C\). At most one is \(t\), so \(M(e)\ne\varnothing\). \(\square\)

This is dual to [Note 138](../notes/138-pairing-change-forces-an-unalignable-cycle-with-a-three-edge-owner-certificate.md): that note obstructs aligning the *new* phase of a critical \(U\to p\) cycle with a companion in the original \((35)(34)\) row; (3) obstructs aligning the *old* phase of a \(p\to A\) cycle with a singleton in the cross-half all-\(S\) row. Neither condition alone excludes a genuine exact-support pole.

## Exclusion of a two-edge short-chord witness

Use the \((2,1,2,1)\), three-edge-chord setting of [the open-path and return analysis](open-path-concentration-and-short-chord-return.md): \(J'=5\), the canonical \(P\) bypasses \(\Omega\), and \(p\) uses the two chord-port \(ZY\) edges \(g_x,g_y\). Let \(A=U^{K_s}\), which belongs to a true state-35 Tait triple with \(Z^1,D\) by [Note 149](../notes/149-both-singleton-phases-of-a-short-diamond-have-state-thirtyfive-tait-completions.md). If no common complete seed exists, then
\[
\boxed{\left|(E(p)\cap E(Z))\setminus E(\Theta)\right|\ge3.} \tag{4}
\]

**Proof.** The Tait anchor \(A\) agrees with \(p\) on \(\Omega\), and its only difference from \(p\) in the chord interior is the segment \(g_x,xy,g_y\). Its exterior \(A\)-phase edges are original \(U\)-edges. By [Note 151](../notes/151-five-right-row-junctions-leave-only-common-singleton-critical-edges.md), \(p=U\) at every vertex of an exterior type-12 or type-23 component of \(Z\triangle Y\). Thus an exterior \(A\)-phase edge of \(A\triangle p\) cannot have original owners \(UY\); its only possible original owner pairs are \(Ur\) and \(UC\).

Inspect the literal all-\(S\) row (1) on these three kinds of \(A\)-phase edge. A chord-interior \(rC\) edge has \(q=0,r=1,p=0,t=1\), so its singleton-companion set is \(M=\{C\}\). On an exterior \(Ur\) edge with \(p=0\), the equations \(q+B=U+Z\) and \(p+t=q+r\) force \(q=0,B=t=1\), so \(M=\{B\}\). On an exterior \(UC\) edge with \(p=0\), either \((q,B,t)=(0,1,0)\), giving \(M=\{B,C\}\), or \((q,B,t)=(1,0,1)\), giving \(M=\{C\}\). No other \(A\)-phase edge occurs. Consequently the reverse-uncompanioned component supplied by Theorem 2 must contain an exterior \(Ur\) edge with \(p=0\), since this is the **only** way its companion sets can lose \(C\).

At either endpoint of that \(Ur\) edge the other original owner pairs are \(DC\) and \(ZY\). The literal \(q=0,B=1\) on the \(Ur\) edge forces \(q=Z\) on the incident \(ZY\) edge. Because \(p\le q+r\), while \(p=0\) on \(Ur\), the matching \(p\) must also use that \(ZY\) edge at the endpoint. Thus the \(Ur\) edge forces two distinct exterior \(p\cap Z\) edges, one at each end. They cannot be exactly \(g_x,g_y\): that would make the \(Ur\) edge join their two outside endpoints and create the four-cycle \(g_x,xy,g_y,Ur\), contrary to girth at least five. At least one forced edge is therefore additional to \(g_x,g_y\), proving (4). \(\square\)

The strict gain in (4) is global: it excludes the two chord-port edges as the **entire** external collision set. The forced \(Ur\) edge may share one of their outside endpoints, so this argument proves three, not four, distinct collisions. It does not rule out the same chord cycle when further external collisions change the effect of toggling it from the \(p\) side. The open-path concentration result still puts at least one exterior collision on the \(5\leftrightarrow4\) component of \(q\triangle r\), but does not show that this is the extra edge in (4).

**Three-collision equality profile.** Suppose equality holds in (4) under no-seed. The reverse-uncompanioned critical component of Theorem 2 then contains an exterior \(Ur\) edge whose two forced \(ZY\) edges overlap the chord-port pair in **exactly one** edge. Overlap in zero edges would give four collisions; overlap in two would give a four-cycle. Up to exchanging the chord ends, write the shared port as \(g_x=xs\), the \(Ur\) edge as \(su\), and its other \(ZY\) edge as \(h=uv\). This same component contains the chord segment \(g_x,xy,g_y\), because the shared port is incident to both \(Ur\) and the chord. Thus all three exterior collisions belong to one \(A\triangle p\) component, and \(q\triangle r\) contains the five-edge passage
\[
v\xrightarrow{h=ZY}u\xrightarrow{Ur}s\xrightarrow{g_x=ZY}x
 \xrightarrow{xy=rC}y\xrightarrow{g_y=ZY}t.                 \tag{5}
\]
The owner sequence is \(ZY,Ur,ZY,rC,ZY\). This passage belongs to the **open** \(5\leftrightarrow4\) component \(Q\): if its component were closed, all three external collisions would be on that closed component, contradicting the open-path concentration theorem in [the companion analysis](open-path-concentration-and-short-chord-return.md).

The rest of the critical \(A\triangle p\) component is an alternating path \(R'\) from \(t\) to \(v\). It has no \(Z^1\)-owned \(p\)-edge, so all its \(p\)-phase edges belong to \(D\). Because this is the **only** component with a \(Z^1\)-owned \(p\)-edge, every other \(A\triangle p\) component is a neutral closed \(A\triangle D\) component. If \(R'\) had one edge, the component would be an \(A/Z^1\)-alternating cycle; switching that cycle between the true Tait colours \(A,Z^1\) would keep \(D\) fixed and yield another Tait state-35 colouring. The neutral components would not change the open \(D\)-pairing, contradicting the required \(5\leftrightarrow4\) pairing of \(p+D\). Hence \(R'\) has at least three edges and contains a genuine \(Dr\) edge of the forced \(2\leftrightarrow3\) path \(P\). Each \(A\)-phase edge of this longer return is adjacent to a \(Dr\) edge; the no-extra-junction argument of [the return analysis](open-path-concentration-and-short-chord-return.md) makes its original owner pair \(UC\). The equality case therefore needs an \(A\triangle p\) cycle of length at least eight, carrying the five-edge \(Q\) passage above and a distinct \(P\) passage through the return.

If the equality cycle has its shortest possible length eight, its four non-\(p\) edges have literal singleton-companion sets \(\{C\}\) on the chord's \(rC\) edge, \(\{B\}\) on the exterior \(Ur\) edge, and \(\{B,C\}\) on each of the two \(UC\) edges of the three-edge return. The latter assertion follows because \(q=Z=Y\) at the endpoints \(t,v\) of that return, so \(B=U=C\) on its two \(UC\) edges. The chord \(rC\) and the exterior \(Ur\) edges must lie on the **same component of \(B_2\triangle C_4\)**. If they were on different components, at least one component would be closed, since \(B_2\triangle C_4\) has only one open terminal path. Switch \(B,C\) on that closed component. Exactly one of the two exclusive companion labels on the equality cycle changes; the two \(UC\) edges remain common to \(B,C\). Consequently either the new \(B\) or the new \(C\) owns every non-\(p\) edge of the cycle. A paired switch with \(p\) would produce the Tait-anchor phase up to neutral \(A\triangle D\) cycles, whose \(5\)-partner with the fixed \(D\) is \(1\). Theorem 1 would then give a common complete seed, contradicting no-seed. This same-component requirement is a conditional full-mask linkage gate; it does not identify whether that component is the open \(2\leftrightarrow4\) path or a closed cycle.

The five-junction right network makes that linkage gate explicit. In the \((2,1,2,1)\) pattern, its four junctions on \(\Omega\) are \(v_1,v_2,v_4,v_5\). The type-23 chord strand joins \(v_2\) to \(v_5\); the other type-23 ports of \(v_1,v_4\) leave \(\Omega\). Let \(w\) be the unique exterior right junction. The right network's three active terminal arms have types 13 at terminal \(1\), 23 at terminal \(2\), and 12 at terminal \(4\). Since there are no other junctions, the type-12 port of \(w\) joins terminal \(4\), and its type-13 port joins terminal \(1\). The remaining four type-23 ports—at \(v_1,v_4,w\), and terminal \(2\)—have just three pairings:
\[
(v_1v_4)(w2),\qquad (v_1w)(v_4 2),\qquad (v_4w)(v_1 2). \tag{6}
\]
In the first pairing, the \(B\triangle C\) component through the chord is closed and runs through the exterior type-23 strand \(v_1v_4\). In either other pairing it is the unique open \(2\leftrightarrow4\) component, using both exterior type-23 strands shown. Thus the exterior \(Ur\) edge in a shortest equality cycle must sit on the \(v_1v_4\) strand in the first case or on one of the two indicated open-path strands in the other cases. A separate type-23 cycle or the \(w2\) strand of the first case cannot carry it under no-seed.

## A second companion cycle excludes all three eight-edge pairings

The last three port pairings are **all excluded when the equality cycle has eight edges**. The switch uses \(p\) with the literal \(B_2\), rather than switching \(B_2\) with \(C_4\), so it does not depend on which component of \(B\triangle C\) contains \(rC\) and \(Ur\). This conditional argument has not had an independent check and is retained here rather than promoted to a numbered note.

Retain equality in (4), and suppose \(R'=t-a-b-v\), with successive owner pairs \(UC,Dr,UC\). Number the six phase-cycle edges as in Note 147. In the \((2,1,2,1)\) row they are
\[
e_1=UZ,\quad e_2=rY,\quad e_3=ZC,\quad e_4=UY,\quad
e_5=rZ,\quad e_6=YC,
\]
with \(e_i=v_{i-1}v_i\) and \(v_6=v_0\). The following is a **proper closed alternating component of the actual \(p\triangle B\)**:
\[
\Sigma=x\xrightarrow{p:g_x}s\xrightarrow{B:Ur}u
\xrightarrow{p:h}v\xrightarrow{B:UC}b
\xrightarrow{p:Dr}a\xrightarrow{B:UC}t
\xrightarrow{p:g_y}y\xrightarrow{B:UD}v_5
\xrightarrow{p:e_5}v_4\xrightarrow{B:e_4}v_3
\xrightarrow{p:e_3}v_2\xrightarrow{B:UD}x.             \tag{7}
\]
At \(t,v\), the \(q=Z=Y\) chord-port and extra-collision edges force \(B=U=C\) on the adjacent \(UC\) edges. The \(Ur\) edge belongs to \(B\) by the preceding equality analysis. On the chord ends and the three listed \(\Omega\) edges, \(B=U\), \(p=Z\) before the switch. Thus every label in (7) is literal; no edge of \(\Sigma\) is inferred from a boundary state alone.

Switch the two complete matchings \(p,B\) on \(\Sigma\), obtaining \(\widehat p_{35},\widehat B_2\). The all-\(S\) six-cover (1) survives with \(D,t,Y,C\) fixed. By Theorem 1, no-seed would make \(\widehat p\triangle D\) pair \(5\) with \(4\). Yet \(\widehat p=U\) at every vertex of \(\Theta\): on \(\Omega\) the new phase is \(e_1,e_4\), and on the chord it uses the two \(UD\) end edges. The three edges \(g_x,g_y,h\) were the **entire** exterior \(p\cap Z\) set and all are removed by (7); every added edge has an original \(U\)-owner, so \(\widehat p\cap Z\) has no exterior edge. Outside \(\Theta\), every original row edge is split. Therefore every \(\widehat p\)-phase edge of \(U\triangle\widehat p\) is owned by \(D\); each component is a closed component of \(U\triangle D\). Toggling such components leaves both open \(U\triangle D\) paths unchanged. Thus \(\widehat p\triangle D\) pairs \(5\) with \(1\), a contradiction.

Consequently the eight-edge equality case is impossible under no-seed, in each of the three pairings (6). If equality \(\left|(E(p)\cap E(Z))\setminus E(\Theta)\right|=3\) still occurs, its return \(R'\) has **at least five edges** and the critical \(A\triangle p\) cycle has at least ten edges. More precisely, at least one *interior* \(UC\) edge of \(R'\) is owned by \(q\), rather than by \(B\). Otherwise every \(UC\) edge of \(R'\) would be \(B\)-owned, and replacing the three-edge \(R'\) segment in (7) by the longer alternating \(UC/Dr\) segment would give the same proper \(p/B\) cycle and contradiction. The first and last \(UC\) edges are \(B\)-owned because \(q=Z=Y\) at \(t,v\); hence the first possible phase defect is an interior \(UC\) edge of a five-edge return. Such a \(q\)-owned edge lies on the canonical \(P_{23}=q\triangle p\), since it is absent from \(p\).

The same twelve-cycle gives a stronger count if the displayed eight-edge component occurs with additional exterior collisions. Write \(n=|(p\cap Z)\setminus\Theta|\). Switching (7) removes exactly \(g_x,g_y,h\) and adds no \(Z\)-owned edge, so the new collision count is \(n-3\). By Theorem 1 and the one-edge lemma below, no-seed requires \(n-3\ge2\), or
\[
\boxed{n\ge5\quad\text{whenever this eight-edge component occurs under no-seed}.} \tag{7a}
\]
Thus a fourth collision away from the eight-edge component does not repair it. This numerical conclusion does not assert that the eight-edge component with five or more collisions is realizable.

This eliminates the shortest three-collision connection but does not exclude a longer return with an interior carrier-phase defect, nor does it prove that an exact-Case-XII pole exists. The earlier same-\(B\triangle C\)-component gate remains a correct necessary condition *within the now excluded eight-edge equality case*; it is not a surviving obstruction under no-seed.

The switch argument has a useful one-edge margin. Let \(p^*\) be any actual class-\(35\) matching which agrees with \(U\) at every vertex of \(\Theta\) and has at most **one** exterior edge in \(p^*\cap Z\). Then \(p^*\triangle D\) pairs \(5\) with \(1\). Indeed \(U\triangle p^*\) avoids \(\Theta\), and every new-phase edge outside it is owned by \(D\) or \(Z\). In a pairing-critical alternating cycle, at least two new-phase edges must avoid \(D\): if all but at most one were \(D\)-owned, those edges would link all the old-phase edges into a single \(U+D\) component, leaving the other open component untouched. With at most one \(Z\)-owned new-phase edge in the entire difference, toggle the difference cycles one by one; none can change the terminal pairing. Hence the same contradiction follows whenever a literal \(p/B\) cycle resets \(p\) to \(U\) on \(\Theta\) and leaves at most one exterior \(Z\)-collision. For a four-collision profile, an extra collision away from the displayed \(A\triangle p\) component does not by itself repair the eight-edge case: the switch (7) removes its three collisions and leaves just one.

The associated count does not require an eight-edge \(A\triangle p\) cycle. In the same \((2,1,2,1)\) bypass branch, the core path
\[
K=xv_2\cup e_3\cup e_4\cup e_5\cup v_5y
\]
is \(B,p,B,p,B\)-alternating between the chord's two interior vertices. Let \(\Sigma\) be its full \(p\triangle B\) component. This is either a proper closed cycle or the unique open \(1\leftrightarrow4\) component of \(p\triangle B\). In the closed case, switching the actual \(p,B\) pair on \(\Sigma\) gives \(p^\Sigma=U\) at every vertex of \(\Theta\). Write
\[
n=|(p\cap Z)\setminus\Theta|,\quad
s_p=|\Sigma\cap p\cap Z\setminus\Theta|,\quad
s_B=|\Sigma\cap B\cap Z\setminus\Theta|.
\]
Here \(s_p\ge2\), since \(g_x,g_y\in\Sigma\). Under no-seed, the preceding one-edge lemma and Theorem 1 force the exact necessary inequality
\[
\boxed{n-s_p+s_B\ge2.}                                  \tag{8}
\]
Indeed the left side is precisely \(|(p^\Sigma\cap Z)\setminus\Theta|\). Thus a three-collision profile with a **closed** core \(p\triangle B\) component needs at least one newly introduced \(B\cap Z\) edge on that component, and needs at least two if it removes all three old collisions. The eight-edge cycle (7) has \((n,s_p,s_B)=(3,3,0)\), giving the immediate contradiction above. The remaining full-mask gate is whether this core component is open, or a closed component whose exterior \(B\)-phase introduces enough \(Z\)-collisions to satisfy (8).

At the shortest still possible three-collision return, \(|R'|=5\), the first and last \(UC\) edges are \(B\)-owned, so the single middle \(UC\) edge must be \(q\)-owned. Writing \(R'=t-a-b-c-d-v\), its owner sequence is \(UC,Dr,UC,Dr,UC\), with \(q\) on \(bc\) and \(B\) on \(ta,dv\). The forced open \(P_{23}=q\triangle p\) then contains a five-edge subpath with owner sequence \(ZY,Dr,UC,Dr,ZY\), passing through \(ab,bc,cd\); the two end \(ZY\) edges are the third edges at \(a,d\). The other open \(Q_{54}\) contains the passage (5). Thus a ten-edge equality cycle needs two different open carrier paths with these simultaneous passages. The \(q\)-owned \(UC\) edge \(bc\) also makes \(B=Z\) on the two distinct third edges \(k_b,k_c\) at \(b,c\). Both belong to the core \(p\triangle B\) component \(\Sigma\). If \(\Sigma\) is closed, its switch removes all three old \(p\cap Z\) collisions and introduces at least these two new ones, exactly meeting the minimum forced by (8) at the level of these edges. This is a necessary incidence pattern, not a realizable exact-support example.

## An isolated closed carrier phase cannot support the ten-edge return

Retain the **three-collision, ten-edge** profile of the preceding paragraph. Let \(F\) be the component of \(q\triangle B=U\triangle Z\) containing \(bc\). The carrier identity makes \(q=U,B=Z\) throughout \(F\). On the forced \(2\leftrightarrow3\) component of \(q\triangle B\), however, \(q=Z,B=U\), since switching that component changes \(q\) to \(U\). Thus \(F\) is either the open \(1\leftrightarrow4\) component or a closed component.

**Closed-phase crossing gate.** If \(F\) is closed and the common complete \(B_2+C_4\) seed is absent, then at least **four** vertices of \(F\) have \(q\ne r\). Two are \(b,c\); at least two more lie elsewhere on \(F\). Equivalently, the case in which \(q=r\) at every vertex of \(F\setminus\{b,c\}\) is excluded by actual complete-matching closure.

**Proof.** Suppose the latter case. The matching \(r\) uses the \(Dr\) edges \(ab,cd\) at \(b,c\), while \(q\) uses \(bc\). Switch the complete \(q_{25},B_2\) pair on the proper closed component \(F\), obtaining \(q'_{25},B'_2\) with \(q'+B'=U+Z\) and the same right-row load. At every other vertex of \(F\), \(q=r\); hence the original \(q\triangle r\) has no edge incident with \(F\) there. Its forced open path \(P\) uses \(bc\), and the switched difference \(q'\triangle r=(q\triangle r)\triangle F\) replaces that one edge by the complementary \(b\)-to-\(c\) arc \(F-bc\). Therefore its forced \(2\leftrightarrow3\) path is exactly \(P'=P\triangle F\), and its canonical cross-half matching is unchanged:
\[
q'\triangle E(P')=(q\triangle E(F))\triangle(E(P)\triangle E(F))=p. \tag{9}
\]
The new right row and its forced cross-half switch thus give a genuine all-\(S\) six-cover with the **same** \(p,D,Y,C\) and the new literal \(B'\).

On the return \(R'=t-a-b-c-d-v\), the outside \(UC\) edges \(ta,dv\) remain \(B'\)-owned: they were \(B\)-owned and lie in the \(q=Z\) phase, while \(F\) has the \(q=U\) phase. The middle \(UC\) edge \(bc\) becomes \(B'\)-owned by the switch. The \(Ur\) edge \(su\), the chord's two \(UD\) end edges, and \(e_4=UY\) likewise remain \(B'\)-owned. Consequently \((E(\Gamma)\setminus\{xy\})\cup K\), where \(\Gamma\) is the ten-edge \(A\triangle p\) component and \(K\) is the five-edge core path above, is a proper **fourteen-edge** \(p\triangle B'\) component. Its exterior \(p\)-phase consists of \(g_x,h,g_y\) and the two \(Dr\) edges \(ab,cd\); in particular it removes all three exterior \(p\cap Z\) collisions when \(p,B'\) are switched, while every added edge has an original \(U\)-owner. The new class-\(35\) matching agrees with \(U\) on \(\Theta\) and has no exterior \(Z\)-collision. The original \(U+Z+D+r+Y+C\) row makes its \(5\)-partner with \(D\) equal to \(1\), while Theorem 1 applied to the new all-\(S\) row makes it \(4\), a contradiction.

Finally, a closed alternating \(F\) has an even number of vertices. The vertices where \(q=r\) occur in pairs, as endpoints of common matching edges; hence the number where \(q\ne r\) is even. Since \(b,c\) are two such vertices and the two-vertex case was excluded, at least four are required. \(\square\)

The gate does not say that every closed \(F\) is impossible. Additional \(q\triangle r\) visits to \(F\) may splice the forced path \(P\) with its other components when \(q,B\) are switched, invalidating the identity \(P'=P\triangle F\). The other surviving possibility is that \(F\) is the open \(1\leftrightarrow4\) carrier component, where a boundary-preserving closed switch is unavailable. Neither possibility is an exact-support realization.

There is a shorter junction proof of the first extra visit, and a sharper classification when the closed carrier has exactly four visits. Let \(k_b=b\beta\) and \(k_c=c\gamma\); the far ends \(\beta,\gamma\) are distinct and lie outside \(\Theta\). Since \(q=U,B=Z\) on \(F\), at either far end the original owner pairs are either \(Ur,ZY,DC\) or \(UC,ZY,Dr\). In the first case \(q=r\), and all three pairs \((q,Y),(B,C),(D,r)\) use different incident edges: that vertex is the unique possible exterior right-row junction \(w\). In the second case \(q\ne r\), and the vertex lies on a right-row type-12 strand. Both far ends cannot be of the first kind because \(J'=5\) allows only one exterior junction. Thus an additional \(q\triangle r\) visit to \(F\) is already forced by the junction budget, without using no-seed.

Now suppose \(F\) is closed and exactly four of its vertices have \(q\ne r\). Besides \(b,c\), the other two are the endpoints of one further \(q\)-owned edge \(f\in F\): a common \(q=r\) edge covers its two endpoints together. Both \(\beta\) and \(\gamma\) cannot be among those two endpoints, since \(\beta\gamma=f\) would make the forbidden four-cycle \(b\beta\gamma cb\). Thus exactly one of \(\beta,\gamma\) is the exterior junction \(w\), and the other is an endpoint of \(f\). The matching \(r\) leaves \(F\) at both ends of \(f\); otherwise its internal edge between those two ends would be parallel to the \(q\)-edge \(f\). Accordingly the original \(q\triangle r\) meets \(F\) in precisely the two \(q\)-edges \(bc,f\), each with two external \(r\)-legs.

**Two-open-path exclusion.** The second edge \(f\) cannot lie on the open \(Q_{54}\) component of \(q\triangle r\). If it did, switch the complete \(q,B\) pair on the closed \(F\). The difference \(q'\triangle r=(q\triangle r)\triangle F\) removes \(bc\) from \(P_{23}\) and \(f\) from \(Q_{54}\), and inserts the two arcs of \(F-\{bc,f\}\). Each inserted arc joins an exposed end of \(P\) to an exposed end of \(Q\). The new terminal pairing is therefore crossed: terminal \(2\) pairs with \(4\) or \(5\), never \(3\). The new complete row still has states \((25)(34)\), so the all-terminal and \(T\)--\(T\) exclusions force \(2\leftrightarrow3\), a contradiction. At the four-visit minimum, \(f\) must instead lie on \(P_{23}\) or on a closed \(q\triangle r\) component. With six or more visits, no two-arc conclusion is asserted.

**Closed-component absorption.** Suppose \(f\) lies on a closed \(q\triangle r\) component \(L\). Then the same \(q,B\) switch on \(F\) joins \(L\) to \(P\), replacing the two \(q\)-edges \(bc,f\) by the two arcs of \(F-\{bc,f\}\). Thus the new forced path is
\[
P'=P\triangle F\triangle L,
\quad p'=q'\triangle P'=(q\triangle F)\triangle(P\triangle F\triangle L)=p\triangle L. \tag{10}
\]
If \(L\) avoids \(\Theta\), this also contradicts no-seed. Indeed \(p'=p\) on \(\Theta\) and on the ten-edge component \(\Gamma\), since \(L\) is distinct from \(P,Q\) and avoids the return's outer \(UC\) edges. By Note 151, \(L\) has no exterior \(rZ\) edge: such an edge belongs to a separate closed original type-12 component of \(q\triangle r\), whereas \(L\) contains the \(q\)-owned \(UC\) edge \(f\). Hence switching \(p\) on \(L\) introduces no exterior \(p'\cap Z\) edge. The original three collisions \(g_x,h,g_y\) remain, since they lie on \(Q\).

The new \(B'=B\triangle F\) owns \(bc\), while the outer \(UC\) edges of \(R'\), \(Ur\), the two \(UD\) chord ends, and \(e_4\) retain their \(B'\)-ownership. Therefore \((E(\Gamma)\setminus\{xy\})\cup K\) is again a proper fourteen-edge \(p'\triangle B'\) component. Switching these two complete matchings removes all three exterior \(Z\)-collisions and adds none, and resets the new class-\(35\) mask to \(U\) on \(\Theta\). The original row forces its \(D\)-partner \(1\); the new all-\(S\) row and Theorem 1 force partner \(4\), a contradiction.

**Second visit on the forced path.** The alternative \(f\in P_{23}\) is settled by one additional **closed** phase switch. When \(F\) meets the old forced path \(P\) in exactly the two \(q\)-edges \(bc,f\), switching \(q,B\) on \(F\) reconnects those two passages. The new \(q'\triangle r\) consists of a forced open \(2\leftrightarrow3\) path \(P'\), one new proper closed component \(L'\), and the old untouched components. As edge sets,
\[
P\triangle F=P'\triangle L'.                              \tag{11}
\]
Switch the actual \(q',r\) pair on \(L'\), obtaining \(q''_{25},r''_{34}\). This preserves their complete pair load and the right row; \(P'\) remains its forced open path. Its canonical cross-half triple is
\[
q''\triangle P'=(q\triangle F\triangle L')\triangle P'
=q\triangle P=p.                                           \tag{12}
\]
Thus the genuine new all-\(S\) row has the *same* \(p,D,Y,C\) and the switched \(B'=B\triangle F\). As above, \(B'\) owns every non-\(p\) edge of the fourteen-edge cycle \((E(\Gamma)\setminus\{xy\})\cup K\): \(bc\) has changed from \(q\)- to \(B'\)-ownership, while its other \(UC,Ur,UD,UY\) edges lie off the \(q=U\) component \(F\). Switching \(p,B'\) on that proper cycle removes the three exterior \(p\cap Z\) edges and adds no new one, contradicting Theorem 1 and the original \(U+D\) pairing. Hence \(f\notin P_{23}\) at the four-visit minimum.

**Terminal-arm exit gate.** In this same three-collision profile, the \(q\triangle r\) component containing the three-edge \(\Omega\) arc is necessarily the open \(Q_{54}\). Indeed, the arc is \(e_1e_2e_3\) from \(v_0\) to \(v_3\). These are the two original type-13 terminal-arm junctions: their edges leaving \(\Omega\) have owners \(Dr\), and their arms run to the distinct terminals \(4,5\). At every internal arm vertex the incident owner pairs are \(UC,Dr,ZY\). There \(r\) uses the \(Dr\) edge, while the carrier equality \(q+B=U+Z\) makes \(q\) use either the \(UC\) edge or the \(ZY\) edge. Choosing \(UC\) continues the same \(q\triangle r\) component along the arm; choosing \(ZY\) makes that edge an exterior \(p\cap Z\) collision if the component is distinct from \(P_{23}\), since \(p=q\) on every other component. In the equality profile all such collisions are \(g_x,h,g_y\), and all three belong to \(Q_{54}\) by (5). A closed component through the \(\Omega\) arc is distinct from \(P,Q\), so it has no such exit. It must follow both terminal arms to their boundary semiedges, contradicting closedness. Since \(P\) avoids \(\Omega\), the component is \(Q\).

Consequently the last placement for \(f\) above is also impossible: if \(f\) lies on the \(\Omega\)-arc component, it lies on \(Q\), contrary to the two-open-path exclusion. Under no-seed, a closed \(F\) in the ten-edge, three-collision profile therefore has **at least six** vertices where \(q\ne r\). The only remaining carrier classes at this stage are an open \(1\leftrightarrow4\) \(F\), or such a closed \(F\) with at least six visits. Neither has been proved realizable with full exact-Case-XII support, and neither is excluded here.

## The two singleton phases exclude the entire three-collision profile

The preceding carrier classification can be bypassed. The following argument applies to an **arbitrarily long** opposite-arm return \(R'\), not only the ten-edge critical cycle. It remains a conditional analytic deduction awaiting an independent check.

**Two-phase obstruction.** In the aligned \((2,1,2,1)\), three-edge-chord branch, assume both \(P_{23}\cap\Omega=\varnothing\) **and** that \(P_{23}\) avoids the chord-interior \(q\triangle r\) component, so the canonical \(p\) uses the two chord-port \(ZY\) edges \(g_x,g_y\). Under these hypotheses, absence of a common complete \(B_2+C_4\) seed implies the stronger bound
\[
\boxed{|(E(p)\cap E(Z))\setminus E(\Theta)|\ge4.}       \tag{13}
\]

**Proof.** Equation (4) gives at least three exterior collisions. If there are exactly three, the equality analysis above puts them at \(g_x=xs,h=uv,g_y=yt\) on one critical component \(\Gamma\) of \(A\triangle p\), where \(A=U^{K_s}\). Every other component \(N_i\) of \(A\triangle p\) is a closed component of \(A\triangle D\), since its \(p\)-phase edges all belong to \(D\); their union \(N\) is pairing-neutral and disjoint from \(\Theta\). Thus \(p=A\triangle\Gamma\triangle N\). The return \(R'\) of \(\Gamma\) is a contiguous \(UC/Dr\) segment of the original type-13 terminal arm from \(v_0\); its other \(A\)-phase segments are the core \(rC\) edge \(xy\) and the exterior \(Ur\) edge \(su\). More precisely, the three disjoint segments of \(A\triangle D\) that \(\Gamma\) removes are \(R',xy,su\); it reconnects their six ends by \(xs,yt,uv\).

Let \(a\in\{4,5\}\) be the terminal at the end of the \(v_0\) arm and let \(b\) be the other member of \(\{4,5\}\). By the negative support, the two open \(A\triangle D\) paths pair \(a\) with some \(a'\in\{1,2\}\) and \(b\) with the other terminal \(b'\). Their core routes are
\[
W: a\leadsto v_0\xrightarrow{e_1}v_1\leadsto a',
\qquad
X: b\leadsto v_3\xrightarrow{e_3}v_2\to x\xrightarrow{xy}y
       \to v_5\xrightarrow{e_5}v_4\leadsto b'.             \tag{14}
\]
The return \(R'\) lies on the \(a\)-to-\(v_0\) part of \(W\), and \(xy\) lies on \(X\). The edge \(su\), originally owned by \(Ur\), lies in \(A\triangle D\), but it cannot lie on either type-13 terminal arm, whose edges have owners \(UC,Dr\), or inside \(\Theta\). Therefore it is on the exterior \(v_1\)-to-\(a'\) tail of \(W\), on the exterior \(v_4\)-to-\(b'\) tail of \(X\), or on a closed \(A\triangle D\) component.

Switch the actual right-row pair \(q,Y\) on \(\Omega\). Since \(P\) avoids \(\Omega\), Note 147 gives the actual canonical phase \(p^*=p\triangle\Omega\). Put \(A^*=A\triangle\Omega=U^{K_o}\); Notes 148--149 make it a second actual state-35 Tait anchor with the **same** \(D\)-pairing. Because \(\Gamma\cup N\) is disjoint from \(\Omega\), \(p^*=A^*\triangle\Gamma\triangle N\). Each \(N_i\) is also a closed component of \(A^*\triangle D\), so its switch remains pairing-neutral in both phases. The new open \(A^*\triangle D\) routes are
\[
W^*:a\leadsto v_0\xrightarrow{e_6}v_5\to y\xrightarrow{xy}x
       \to v_2\xrightarrow{e_2}v_1\leadsto a',
\qquad
X^*:b\leadsto v_3\xrightarrow{e_4}v_4\leadsto b'.     \tag{15}
\]
Thus \(R'\) and \(xy\) now lie on the *same* path \(W^*\), while the location of \(su\) in one of the three exterior pieces is unchanged.

Trace the three possible locations of \(su\) after deleting \(R',xy,su\) and inserting \(xs,yt,uv\):

| Location of \(su\) in (14) | Consequence |
|---|---|
| \(v_1\leadsto a'\) tail of \(W\) | In phase 0 the path from \(b\) runs through \(x,s\). If \(s\) is on the \(a'\)-side of \(su\), it ends at \(a'\); otherwise it reaches the far end of \(R'\) and then ends at \(a'\) through \(v,u\) or at \(b'\) through \(t,y\). It never ends at \(a\). |
| A closed component | Phase 1 leaves \(X^*:b\leftrightarrow b'\) untouched, so \(p^*\triangle D\) cannot pair \(a\) with \(b\). |
| \(v_4\leadsto b'\) tail of \(X\) | Phase 0 can pair \(b\) with \(a\) only if \(s\) lies on the \(v_4\)-side of \(su\) and \(t\) lies on the \(a\)-side of \(R'\). In phase 1 the path from \(a\) then follows \(t,y\), the middle of \(W^*\) to \(v\), and \(v,u\) to \(b'\). Hence it pairs \(a\) with \(b'\), not \(b\). |

Both canonical phases would have to pair \(5\) with \(4\) under no-seed by Note 136. In the first row phase 0 already pairs \(5\) with \(1\) or \(2\); in the second row phase 1 retains the original \(5\leftrightarrow1\) pairing; in the third row phase 1 pairs \(5\) with \(2\). Each gives a common complete seed by that note, contrary to no-seed. This proves (13). \(\square\)

The four-visit carrier gate above is consequently vacuous under the no-seed hypothesis in this **chord-bypass** three-collision branch. The smallest still unexcluded collision count there is four. If \(P\) contains the chord passage \(g_x,xy,g_y\), then \(p\) uses \(xy\), not \(g_x,g_y\), and neither (4) nor (13) is asserted. The argument makes no claim that four collisions are realizable in a genuine exact-Case-XII pole.

## The distinct chord-on-P branch at two external collisions

The omission in (13)'s hypotheses matters. Retain the same aligned \((2,1,2,1)\) short diamond and \(P\cap\Omega=\varnothing\), but now suppose the forced \(P_{23}\) **contains** the chord passage \(g_x,xy,g_y\). Then \(p\) uses \(xy\) and agrees with the actual Tait anchor \(A=U^{K_s}\) at every vertex of \(\Theta\). The following is a necessary connection gate, not an exclusion of the branch.

In this section \(s,t,u,v\) name the external detour \(t-s-u-v\); they are newly chosen and are distinct from the far endpoints of the chord-port edges \(g_x,g_y\) used in the preceding bypass analysis.

**Two-collision gate.** Suppose there is no common complete \(B_2+C_4\) seed and exactly two exterior edges belong to \(p\cap Z\). Then both edges lie on the open \(Q_{54}\) component of \(q\triangle r\), and they form one \(ZY,Ur,ZY\) detour. A single pairing-critical component \(\Gamma\) of \(A\triangle p\) contains this detour and an alternating \(UC,Dr,\ldots,Dr,UC\) return \(R\) of at least five edges on one original type-13 terminal arm. At least one interior \(UC\) edge of \(R\) is \(q\)-owned. The \(Ur\) edge lies on the exterior tail of the *opposite* open \(A\triangle D\) path. Moreover, the three-edge \(\Omega\) arc belongs to \(Q\) as well.

**Proof.** The reverse certificate in Theorem 2 supplies a pairing-critical component with empty literal \(\{B,Y,C\}\)-companion intersection. In this branch \(A=p\) on \(\Theta\), and outside \(\Theta\) an \(A\)-phase edge of \(A\triangle p\) has original owner pair \(Ur\) or \(UC\), by the same Note-151 argument used for (4). Its singleton-companion set is respectively \(\{B\}\) or one of \(\{B,C\},\{C\}\). Thus the critical component contains a \(p\)-avoided \(Ur\) edge \(su\) and a \(q\)-owned \(UC\) edge.

At both endpoints of \(su\), the other owner pairs are \(ZY,DC\). The equations \(p+t=q+r\), \(q+B=U+Z\), and matchinghood force \(q=p=Z=Y=1\) on the respective \(ZY\) edges \(h_s=st\), \(h_u=uv\). They are distinct in a simple pole. They exhaust the assumed two exterior collisions, and the \(q\triangle r\) passage \(t\xrightarrow{ZY}s\xrightarrow{Ur}u\xrightarrow{ZY}v\) puts them on one component. Open-path concentration forces one collision onto \(Q\), hence both belong to \(Q\).

The remainder \(R\) of \(\Gamma\) joins \(v\) to \(t\). Its \(p\)-phase edges avoid \(Z^1\), so the genuine Tait partition \((A,Z^1,D)\) makes them \(D\)-edges; its other edges belong to \(A\). Thus \(R\subseteq A\triangle D\). A one-edge return would make \(\Gamma\) a forbidden four-cycle. For a longer return, every \(D\)-owned \(p\)-edge has original owners \(Dr\), because \(p\le q+r\) and \(q=0\) on a \(D\)-edge. Each adjacent \(A\)-edge has owners \(UC\): an \(UY\) edge would create a fifth original junction outside \(\Omega\). Therefore \(R\) follows a single split type-13 \(UC/Dr\) strand. Since \(\Gamma\) changes the terminal pairing, its two removed \(A\triangle D\) segments \(R\) and \(su\) must lie on **different open** components; an untouched open path would otherwise fix the pairing. Junction-free type-13 cycles are closed \(A\triangle D\) components, so \(R\) lies on a terminal arm. The \(Ur\) edge is neither on such an arm nor on \(\Theta\), so it lies on the exterior tail of the other open path.

The two \(UC\) edges at the ends of \(R\) are \(B\)-owned, since \(q\) uses \(h_s,h_u\) at \(t,v\). The empty singleton-companion intersection requires a \(\{C\}\)-only \(UC\) edge, hence an **interior** \(q\)-owned edge of \(R\). Its length is therefore at least five. Finally, a closed \(q\triangle r\) component through the \(\Omega\) arc would have no exterior \(p\cap Z\) edge, since both collisions lie on \(Q\). At each internal vertex of either original type-13 terminal arm, avoiding a \(ZY\) collision forces \(q\) to use the \(UC\) edge; the component would follow an arm to terminal \(4\) or \(5\), contradicting closedness. As \(P\) avoids \(\Omega\), its arc lies on \(Q\). \(\square\)

This gate is consistent with both singleton phases at the level of open-path pairings: the \(Ur\) edge and the return stay on opposite exterior paths when \(\Omega\) is switched. Complete exact-Case-XII matching closure must supply an additional obstruction before the two-collision profile can be excluded.

**The forced path enters the return.** Every interior \(q\)-owned \(UC\) edge of \(R\) lies on the canonical open \(P_{23}\subset q\triangle r\). At the two ends \(t,v\) of \(R\), \(q\) uses \(h_s,h_u\), while \(r\) uses the \(Dr\) arm edge *outside* \(R\); the first and last \(UC\) edges of \(R\) are \(B\)-owned. A \(q\triangle r\) component that uses an interior \(q\)-owned \(UC\) edge must therefore leave the interior of \(R\) through a third \(ZY\) edge at an internal arm vertex. This edge differs from \(h_s,h_u\). If the component were not \(P\), the canonical \(p=q\triangle P\) would retain that \(q=Z=Y\) edge, making a third exterior \(p\cap Z\) collision. Thus the component is \(P\). In particular, the two-collision profile forces \(P\) to traverse both the chord passage and a segment inside the opposite terminal-arm return. This does not alone change either terminal pairing.

**Literal companion linkage.** Under the same two-collision hypotheses, the \(Ur\) edge \(su\) and at least one interior \(q\)-owned \(UC\) edge of \(R\) lie on the **same complete \(B_2\triangle C_4\) component**. Indeed, on \(\Gamma\) the \(Ur\) edge is owned only by \(B\) among \(B,Y,C\); an interior \(q\)-owned \(UC\) edge is owned only by \(C\); all other \(UC\) edges are owned by both \(B,C\). If no component of \(B\triangle C\) contained both exclusive kinds, switch \(B,C\) on selected *closed* components to make either \(B\) or \(C\) own every non-\(p\) edge of \(\Gamma\). The one open \(2\leftrightarrow4\) component fixes the target label when it contains an exclusive edge; every closed component can be set to that target independently. A genuine paired switch of \(p\) with this literal singleton on \(\Gamma\) would give \(A\) up to the neutral closed \(A\triangle D\) components, changing its \(D\)-partner from \(4\) to \(1\) in contradiction with Theorem 1. This locates the still-unresolved edgewise coupling in one actual matching-difference component; it does not show that the component is forbidden by Case-XII support.

**Right-network localization.** The shared \(B\triangle C\) component in the preceding paragraph must be the **open** \(2\leftrightarrow4\) path. Consequently at least one interior \(q\)-owned \(UC\) edge of \(R\) lies on the open \(1\leftrightarrow4\) component of \(q\triangle B=U\triangle Z\). The exterior \(Ur\) edge \(su\) lies on the open \(B\triangle C\) path as well. More precisely, its type-23 strand is one of the following, indexed by the three port pairings (6):
\[
\begin{array}{c|c}
\text{type-23 port pairing}&\text{possible strand containing }su\\\hline
(v_1v_4)(w2)&w2\\
(v_1w)(v_4 2)&v_1w\text{ or }v_4 2\\
(v_4w)(v_1 2)&v_4w\text{ or }v_1 2.
\end{array}                                               \tag{16}
\]

**Proof.** In the right paired network \((q,Y),(B,C),(D,r)\), the edge types on \(\Omega\) are \(12,13,12,12,13,12\) for \(e_1,\ldots,e_6\). Hence its four type-12 junction ports form the two *internal* strands \(v_1e_1v_0e_6v_5\) and \(v_2e_3v_3e_4v_4\). None leaves \(\Omega\). The unique right junction outside \(\Omega\) is \(w\), and the only active type-12 terminal is \(4\). Therefore a type-12 edge outside \(\Theta\) lies either on the strand from \(w\) to terminal \(4\), or on a junction-free closed type-12 cycle.

An exterior \(q\)-owned \(UC\) edge of \(R\) has right type \(12\): its endpoints have original owner triple \(UC,Dr,ZY\) with \(q=U,B=Z,D=r\). If this edge lay on a closed type-12 cycle, that entire cycle would be a closed \(B\triangle C\) component and could not also contain the right type-23 \(Ur\) edge \(su\). The literal companion linkage therefore places at least one such \(UC\) edge on the \(w\)-to-\(4\) strand. Every internal vertex of that strand has the same \(UC,Dr,ZY\) owner triple and \(q=U,B=Z\), so its edges alternate between \(q\)-owned \(UC\) and \(B\)-owned \(ZY\). At terminal \(4\) the semiedge is \(qC\); at \(w\) the type-12 edge is the original \(ZY\) edge, owned there by \(B\). Thus this strand is part of the actual \(q\triangle B\) path beginning at \(4\), which the carrier boundary identities force to end at \(1\). This proves the open \(1\leftrightarrow4\) carrier claim.

The \(B\triangle C\) component through the same strand begins at terminal \(4\), hence is its unique open \(2\leftrightarrow4\) path. By literal companion linkage it also contains \(su\). At either endpoint of \(su\), \(q=Y\) on the incident \(ZY\) edge, \(B=r\) on \(Ur\), and \(D=C\) on \(DC\); thus \(su\) has right type \(23\). The type-23 chord strand \(v_2v_5\) contains only \(UD,rC\) owner pairs and cannot contain \(su\). Following the open \(B\triangle C\) path through the three pairings (6) leaves exactly the exterior type-23 strands listed in (16). \(\square\)

The three rows of (16) are the paired-network possibilities before the closed original phases are used. The following argument excludes the first under exact negative support.

**Closed-phase elimination of the first port pairing.** In fact \((v_1v_4)(w2)\) is impossible under the exact negative support. The argument needs only the normalized aligned \((2,1,2,1)\) six-edge diamond with \(J'=5\); it assumes neither no-seed nor a collision count nor which \(q\triangle r\) component contains the chord. Switch the complete \(U_{35},r_{34}\) pair on **every exterior closed original type-12 component** \(F\) of \(Z\triangle Y\), obtaining \(\widetilde U_{35},\widetilde r_{34}\). These are genuine proper alternating cycles of \(U\triangle r\), so the original six-cover remains actual, with \(Z,D,Y,C\) fixed. At every \(UY,Zr,DC\) vertex of such an \(F\), the new \(\widetilde U\) uses the \(Zr\) edge and \(D\) uses the \(DC\) edge.

Now trace the **original**, unchanged right paired network \((q,Y),(B,C),(D,r)\). Its unique exterior junction \(w\) has original owner triple \(Ur,ZY,DC\) with \(q=U,B=Z\). A nonjunction interior vertex of an exterior right type-23 strand is either an original inactive \(Ur,ZY,DC\) vertex with \(q=Z,B=U\), or an original type-12 \(UY,Zr,DC\) vertex with \(q=U,B=Z\); the other original split strand types give right type-12, type-13, or inactive vertices. At the first kind, \(\widetilde U+D\) follows the right type-23 \(Ur/DC\) pair. At the second kind, it follows the right type-23 \(Zr/DC\) pair after the closed switch. At \(w\), it joins the type-23 \(DC\) edge to the type-13 \(Ur\) edge. Every interior vertex of the exterior right type-13 strand from \(w\) to terminal \(1\) has original owners \(Ur,DY,ZC\), so \(\widetilde U+D\) follows its \(Ur/DY\) edges. Finally, the right type-23 semiedge at terminal \(2\) and the right type-13 semiedge at terminal \(1\) are both \(U\)-owned in the original row and remain \(\widetilde U\)-owned.

If the right type-23 pairing were \((v_1v_4)(w2)\), these traced edges would form one open component of \(\widetilde U\triangle D\) joining terminals \(2\) and \(1\). Switching \(\widetilde U,D\) on it would turn the original \(S\)--\(T\) row into the forbidden \((34)(34)\) \(T\)--\(T\) row. Therefore
\[
\boxed{(v_1v_4)(w2)\text{ cannot occur in an aligned }J'=5\text{ short diamond with exact negative support.}}\tag{17}
\]
There is a Tait-colouring version of the same obstruction. In this \((2,1,2,1)\) pattern, Note 149 gives the actual state-\(35\) Tait triple \((A,Z^1,D)=(U^{K_s},Z\triangle\Omega,D)\). Outside \(\Theta\), \(A=U\) and \(Z^1=Z\), so the same exterior type-12 cycles are proper \(A/Z^1\)-alternating cycles. Switching these two Tait colours on all of them gives \((\widetilde A,\widetilde Z^1,D)\), and the trace above makes \(\widetilde A\triangle D\) join \(1\) to \(2\) if \(w2\) is a strand. Switching this open path would produce a forbidden state-\(34\) Tait colouring. Thus the exclusion also follows from the absence of the \([34]\) loop, without using the other forbidden \(T\)--\(T\) types.

The same trace orients the two surviving pairings. Let \(\tau_0\) be the terminal reached by the original type-13 arm at \(v_0\), and \(\tau_3\) the terminal reached by the arm at \(v_3\), so \(\{\tau_0,\tau_3\}=\{4,5\}\). At \(v_1\), \(\widetilde U+D\) follows the exterior type-23 port through \(e_1\) to \(\tau_0\); at \(v_4\), it follows the other port through \(e_4\) to \(\tau_3\). The mandatory pairing \((1,5)(2,4)\) therefore gives
\[
\boxed{(v_1w)(v_4 2)\Longrightarrow(\tau_0,\tau_3)=(5,4),\qquad
       (v_4w)(v_1 2)\Longrightarrow(\tau_0,\tau_3)=(4,5).}             \tag{18}
\]
This argument uses the full closed original type-12 phases: a single \(UY,Zr,DC\) vertex can divert \(U+D\), but switching all its closed \(U/r\) components restores every exterior right type-23 strand as a \(\widetilde U+D\) route. It leaves the two oriented pairings in (18) undecided. As with the rest of this draft, (17)--(18) await independent verification before promotion to a numbered note.

For the **two-collision** branch, the same phase normalization locates the two pieces of the critical cycle relative to the terminal pairs. On each exterior type-12 component \(F\), Note 151 gives \(p=A=U\) and \(B=Z^1=Z\). Thus \(F\) is simultaneously a closed \(p/B\)-alternating cycle and a closed \(A/Z^1\)-alternating cycle, and it is disjoint from \(\Gamma=A\triangle p\). Switch \(p,B\) on all these \(F\)'s, and switch \(A,Z^1\) on the same \(F\)'s. The resulting actual all-\(S\) row and actual state-\(35\) Tait triple have class-\(35\) masks \(\widetilde p,\widetilde A\) with \(\widetilde A\triangle\widetilde p=\Gamma\) plus the same neutral components as before. Theorem 1 keeps the \(5\)-partner of \(\widetilde p+D\) at \(4\); the Tait state exclusion keeps the \(5\)-partner of \(\widetilde A+D\) at \(1\). Hence \(\Gamma\) remains pairing-critical, so its \(Ur\) edge \(su\) and its terminal-arm return \(R\) still lie on **opposite** open \(\widetilde A\triangle D\) paths. Note 148's \(K_s\) flip replaces the core \(e_4\) connection by a path with the same endpoints \(v_3,v_4\), so \(\widetilde A+D\) has the same exterior port-to-arm routing as \(\widetilde U+D\). In either oriented pairing of (18), the exterior type-23 strand from \(w\) belongs to the \(1\leftrightarrow5\) path and the strand from terminal \(2\) belongs to the \(2\leftrightarrow4\) path. Consequently
\[
\boxed{su\text{ on the }w\text{-strand}\Longrightarrow
R\text{ on the terminal-}4\text{ arm},\qquad
su\text{ on the }2\text{-strand}\Longrightarrow
R\text{ on the terminal-}5\text{ arm}.}                     \tag{19}
\]
This is a necessary location rule for the two surviving connection patterns, not an exclusion of either one.

**Two short \(q/C\) bridges.** Let \(a\) and \(d\) be the first and last internal vertices of the terminal-arm return \(R=t-a-\cdots-d-v\). The first and last \(UC\) edges \(ta,dv\) are both \(B=C\)-owned, while \(q\) uses the \(ZY\) collision edges \(h_s=ts,h_u=vu\) at \(t,v\). Matchinghood therefore makes \(q\) use the third \(ZY\) edges \(k_a,k_d\) at \(a,d\). These are on the forced \(P_{23}\): otherwise \(p=q\) on one of them, contradicting the exact two-collision assumption. Hence the complete \(q\triangle C\) has two literal three-edge passages
\[
h_s\ (Q,\ q)\;-\;ta\ (C)\;-\;k_a\ (P,\ q),
\qquad
k_d\ (P,\ q)\;-\;dv\ (C)\;-\;h_u\ (Q,\ q).               \tag{20}
\]
These passages are pieces of actual complete \(q\triangle C\) components. For a five-edge \(R\), the two \(P\)-exit edges are distinct: an edge \(ad\) would close a forbidden four-cycle with the three-edge internal \(a\)-to-\(d\) part of \(R\). For a longer return they may coincide; then (20) is one five-edge \(Q\)-to-\(P\)-to-\(Q\) passage, and no distinctness is asserted. If one of the displayed \(Q\)-to-\(P\) passages lies on a closed \(q\triangle C\) component whose only \(q\triangle r\) intersections are those two displayed edges, switching that complete \(q,C\) pair crosses the two open \(q\triangle r\) paths and is forbidden. Thus such a closed component requires another separated carrier visit; the unique open \(1\leftrightarrow3\) \(q\triangle C\) component needs no such repair.

**A closed \(q/C\) phase needs a third carrier visit.** Still in the chord-on-\(P\), two-collision branch, inspect the complete matching difference \(q_{25}\triangle C_4\). Its only open component joins terminals \(1,3\). On the six-edge core its edges are exactly \(e_1,e_6,e_5\), a path from \(v_1\) to \(v_4\); \(q=C\) on \(e_3\). At the two interior vertices of the three-edge chord, its local passage is \(g_x,xy,g_y\), since \(q\) owns the \(ZY\) port edges and \(C\) owns the middle \(rC\) edge.

Suppose a **single closed** component \(F\) of \(q\triangle C\) contains both this \(v_1\)-to-\(v_4\) core path and the chord passage. Put \(G=q\triangle r\). The core edge \(e_1\) lies on the open \(Q_{54}\) of \(G\), while \(g_x,xy,g_y\) lie on its open \(P_{23}\). If \(F\cap G\) had just two maximal common path segments, one containing \(e_1\) in \(Q\) and the other containing the chord passage in \(P\), then switching the **complete** \(q,C\) pair on \(F\) would cross the two open terminal paths. Indeed
\[
(q\triangle F)\triangle r=G\triangle F;
\]
this removes the two disjoint common segments and inserts the two complementary arcs of the single cycle \(F\). Each inserted arc joins one exposed \(P\) end to one exposed \(Q\) end. The new \(2\)-terminal path would therefore end at \(4\) or \(5\), rather than \(3\). The former gives a forbidden \(T\)--\(T\) BF row and the latter an all-terminal BF row. Hence
\[
\boxed{F\text{ closed and carrying both core passages}\quad\Longrightarrow\quad
F\cap(q\triangle r)\text{ has at least a third separated common segment}.}\tag{21}
\]
The extra segment may lie on \(P\), on \(Q\), or on a closed \(q\triangle r\) component. It contains a **\(q\)-owned edge outside \(\Theta\)** distinct from \(g_x,g_y\): a common edge of \(q\triangle C\) and \(q\triangle r\) is owned either by \(q\) or by both \(C,r\), while the normalized row has no exterior \(rC\) edge. If the extra segment lies on \(Q\) and has original owners \(ZY\), its \(q\)-edge is one of the two already listed collisions \(h_s,h_u\); any other extra \(ZY\) edge on \(Q\) would violate the assumed collision count. If the \(v_1\)-to-\(v_4\) path and chord passage lie on different \(q\triangle C\) components, (21) makes no assertion.

There is a sharper three-segment boundary. If \(F\cap G\) had exactly three maximal segments and the third lay on one **closed** \(q\triangle r\) component \(L\), the switch would still cross \(P\) and \(Q\). Among three removed segments around the single cycle \(F\), one complementary arc joins a \(P\) end directly to a \(Q\) end. The other \(P,Q\) ends join through the two remaining complementary arcs and the residual path \(L\) after its one segment is removed. Thus a third segment on a closed \(L\) alone cannot repair the forbidden terminal pairing. At exactly three visits, the additional segment must belong to \(P\) or \(Q\); with four or more visits no such conclusion is asserted.

The allowable three-segment placement has an exact orientation condition. Suppose, for example, that \(F\) meets \(P\) in two disjoint segments and \(Q\) in one. Removing the two \(P\) segments leaves two **outer** pieces ending at terminals \(2,3\) and one **middle** piece joining their other exposed ends. The complementary \(F\)-arc directly between the two \(P\) segments must join their two outer ends. Then \(P\)'s terminal ends reconnect through this arc, while \(Q\)'s reconnect through the middle \(P\) piece and the other two \(F\)-arcs. If that direct arc touches a middle end instead, at least one \(P\) terminal connects to a \(Q\) terminal, which is forbidden. The same criterion holds with \(P,Q\) exchanged when \(Q\) has the two visits. Hence a third visit repairs the crossing only in one specified orientation; its mere existence is insufficient.

In the present exact two-collision profile, the **three-segment minimum is even narrower**, but counting the bridges (20) alone does not prove it. An exterior edge shared by \(q\triangle C\) and \(Q\) is a \(q\)-owned \(ZY\) edge: \(q\)-owned \(UC\) is also \(C\)-owned, \(q\)-owned \(Ur\) is also \(r\)-owned, and an exterior \(UY\) edge belongs to a separate closed original type-12 \(q\triangle r\) component. Such a \(ZY\) edge on \(Q\) is one of the two collisions \(h_s,h_u\). Its bridge (20) puts \(k_a\) or \(k_d\) on the same \(q\triangle C\) component. **That edge may equal a chord-port edge \(g_x\) or \(g_y\)** already in the first \(P\)-intersection segment; it need not create a fourth segment.

The actual port placement excludes a third \(Q\) segment at the three-segment minimum. Let \(j\) be the core endpoint whose exterior right type-23 strand ends at terminal \(2\). By (18), \(j=v_4\) in pairing \((v_1w)(v_4 2)\), and \(j=v_1\) in pairing \((v_4w)(v_1 2)\). The \(q\triangle C\) core path leaves \(j\) through its \(DC\) port. It cannot reach terminal \(2\), where neither \(q\) nor \(C\) has a semiedge, without leaving that type-23 strand at a nonjunction vertex. At every such vertex its outgoing \(q\)-edge is also in \(q\triangle r\): it is a \(ZY\) edge in the original inactive \(Ur,ZY,DC\) case or a \(UY\) edge on a closed original type-12 component. If \(F\cap G\) has exactly three maximal segments and the third is on \(Q\), the first such exit must use \(h_s\) or \(h_u\); no earlier \(UY\) or other \(ZY\) exit is available. Thus \(su\) lies on the \(2\)-strand, and (19) puts \(R\), hence \(h_s,h_u\), on the terminal-\(5\) arm of \(Q\).

The complementary \(F\)-arc from the core \(Q\)-segment \(e_1\) to this third \(Q\)-segment starts at the end of \(e_1\) leading through the rest of the core path to \(j\). In the first pairing that end is \(v_0\): \(F\) goes through \(e_6,e_5,v_4\), while \(Q\) reaches \(v_0\) from the terminal-\(5\) arm before traversing \(e_1\). In the second pairing it is \(v_1=j\), while \(Q\) traverses \(e_1\) before reaching the terminal-\(5\) arm at \(v_3\). In either pairing this end of \(e_1\) is a **middle** end between the two \(Q\) visits. The direct \(F\)-arc therefore cannot join their two outer ends, contrary to the necessary orientation condition above. A third visit on a closed \(q\triangle r\) component was already excluded. Consequently, if \(F\cap G\) has exactly three maximal segments, the third lies on \(P\); it is an exterior \(q\)-owned \(ZY\) edge distinct from \(g_x,g_y\), and the two \(P\) visits must satisfy the outer-end orientation condition. More precisely, this edge is incident to the **first vertex after the \(DC\) port at \(j\)** on the right type-23 strand toward terminal \(2\). That vertex must be of original inactive type \(Ur,ZY,DC\); the other possible type \(UY,Zr,DC\) would put its \(q\)-edge on a closed \(q\triangle r\) component. The complementary \(F\)-arc directly joining the two \(P\) segments leaves this new edge at its far endpoint, so that endpoint must be the outer \(P\) end relative to the chord passage. This repair uses (17)--(20) and remains conditional on their independent verification.

**The three-visit cycle has ten edges and forces a pentagon.** Under precisely the preceding three-segment hypotheses, write \(j_2\) for the core port on the right type-23 strand to terminal \(2\), \(j_w\) for the other core port, and \(k=zn\) for the third \(P\)-edge, where \(j_2z\) is the \(DC\) port edge. The component \(F\) cannot pass through \(w\): at \(w\), \(q\triangle C\) leaves its \(DC\) edge along \(q=r=Ur\), then follows the exterior \(Ur/ZC\) corridor through original split type-23 vertices to terminal \(1\). There is no other exterior right junction or core \(ZC\) port at which that corridor can leave. Thus a component containing \(w\) is the open \(1\leftrightarrow3\) component, whereas \(F\) is closed.

The core path must also leave \(j_w\) through its \(DC\) port. Its first exterior vertex cannot be a type-12 \(UY,Zr,DC\) vertex, since its \(q\)-edge would create a fourth intersection on a closed \(q\triangle r\) component. Nor can its \(q\)-owned \(ZY\) edge be \(k\): that would close the core path back through \(j_2z\), leaving the chord on a different \(q\triangle C\) component. The first vertex is therefore an inactive \(Ur,ZY,DC\) vertex \(y_w\) whose \(q\)-edge is one of the chord ports \(g_x,g_y\). Call this edge \(g_w\), and call the other chord port \(g_o\), with far endpoint \(m\).

After \(g_o\), the cycle \(F\) must return to the far endpoint \(n\) of \(k\) without a fourth \(F\cap G\) segment. At either far endpoint the next \(F\)-edge is its \(C\)-edge. If those two \(C\)-edges were not the same edge, the next \(q\)-edge would create a fourth \(G\)-visit; the only \(q=r\) alternative is the corridor through \(w\), which belongs to the open \(q\triangle C\) component. The already used \(g_w\) and \(k\) endpoints cannot be revisited by a simple alternating cycle. Hence \(nm\) is one literal \(C\)-edge, of owner type \(DC\) when \(n,m\) are inactive right type-23 vertices, or \(UC\) when they lie on an original type-13 strand. The entire closed component is the ten-edge cycle
\[
F=(j_wy_w)\;g_w\;(xy)\;g_o\;(mn)\;k\;(zj_2)\;\cup\;
   (j_2\leadsto j_w\text{ through }e_1,e_6,e_5).          \tag{22}
\]
The displayed cyclic order denotes edges, not an assertion that the two chord ports have a prescribed orientation. The outer-end condition above says that \(n,m\), the endpoints of its single \(C\)-bridge \(nm\), must be the two outer ends of the \(P\)-segments.

Girth at least five determines the chord port \(g_w\). If \((v_1w)(v_4 2)\), then \(j_w=v_1\); choosing \(g_x\) would make the four-cycle \(v_1-y_w-x-v_2-v_1\), so \(g_w=g_y\). The remaining edges \(v_1y_w,g_y,yv_5,e_6,e_1\) form a five-cycle. If \((v_4w)(v_1 2)\), then \(j_w=v_4\); choosing \(g_y\) would make the four-cycle \(v_4-y_w-y-v_5-v_4\), so \(g_w=g_x\). Now \(v_4y_w,g_x,xv_2,e_3,e_4\) form a five-cycle. On either pentagon the five edges leaving it have original owners \(rY,Dr,rZ,Ur,rC\) in some order: the **same complete matching \(r_{34}\) owns all five spokes**, while each other occurrence owns exactly one spoke. Thus an aligned short diamond of girth at least six cannot have this exact three-segment closed \(q\triangle C\) return: any such closed component carrying both core and chord passages has at least four separated intersections with \(q\triangle r\). At girth five, (22) and its five-spoke matching are necessary full-mask incidence patterns, not an asserted exact-Case-XII realization.

The six-matchings' restriction to this forced pentagon is **unique once its five spoke labels are fixed**. The colour \(r\) already uses all five spokes and no cycle edge. Each of \(U,Z,D,Y,C\) uses exactly one distinct spoke; deleting that spoke's vertex leaves a four-vertex path, whose perfect matching is unique. Those two path edges are the occurrence's forced cycle edges. Consequently no change confined to the pentagon interior can give a second BF row with the same five complete spoke labels. Any closure argument exploiting this pentagon has to change at least one spoke occurrence and follow the resulting exterior matching component.

**The forced path has an off-decagon middle passage.** Still under (22), the outer-end condition places the \(P_{23}\) middle piece between the inner ends \(z\) and \(y_w\) of its two \(P\)-intersection segments. At each of these vertices the edge of \(P\) leaving the ten-cycle is its original \(Ur\) edge, owned by \(r\) and not by \(q\). Denote its other endpoint by \(z^+\) or \(y^+\), respectively. They are distinct inactive \(Ur,ZY,DC\) vertices on the two different exterior right type-23 strands: \(q\) cannot take the \(Ur\) edge at one endpoint and avoid it at the other, and any original split type-23 endpoint taking the \(ZC\) phase would be another exterior right junction. The forced \(P\) therefore contains the \(q\)-owned \(ZY\) edges \(h_2\) at \(z^+\) and \(h_w\) at \(y^+\).

Neither edge belongs to \(F\). At \(z^+\), the edge \(k\) would be parallel to \(zz^+\); a chord port would make its far endpoint a middle rather than an outer end of the chord segment, or would join the two right type-23 strands into the excluded core-to-core pairing. At \(y^+\), \(g_w\) has already been used at \(y_w\), \(g_o\) would close a cycle inside the simple open path \(P\), and \(k\) would make \(n\) a middle rather than an outer end of its segment. Thus \(h_2,h_w\) are new edges outside the ten-cycle. They may be **the same** edge, joining \(z^+\) to \(y^+\); then the \(P\) middle piece is exactly the three-edge passage
\[
z\xrightarrow{Ur}z^+\xrightarrow{ZY}y^+
 \xrightarrow{Ur}y_w.                                      \tag{23}
\]
Otherwise that middle piece has at least five edges. In either bridge type \(DC\) or \(UC\), the three-visit closed phase forces at least one further \(q\)-owned \(ZY\) edge on \(P\), carried by another complete \(q\triangle C\) component. This edge is switched away in the canonical \(p=q\triangle P\), so its existence does not by itself contradict the two-collision hypothesis.

The complete switch of \(q,C\) on this ten-cycle gives a second actual right row \(q'_{25}+B_2+D_5+r_{34}+Y_3+C'_4=2\mathbf1\). Let \(J''\) be its junction count for \((q',Y),(B,C'),(D,r)\). The four original junctions on \(\Omega\) lose the junctions at \(v_1,v_5\), while \(v_2,v_4\) retain theirs. The two chord-interior vertices and the two first port vertices \(z,y_w\) become junctions. At the bridge endpoints \(n,m\), a \(DC\) bridge converts two original inactive right type-23 vertices into two junctions; a \(UC\) bridge converts two original inactive type-13 vertices into nonjunction type-12 vertices. The exterior junction \(w\) is untouched. Therefore the literal new row has
\[
\boxed{J''=9\quad(nm=DC),\qquad J''=7\quad(nm=UC).}       \tag{24}
\]
The outer-end order in (22) keeps the \(2\leftrightarrow3\) pairing of \(q'\triangle r\), so its forced canonical cross-half row is also actual. Under the global hypothesis \(\Lambda_L\cap\Lambda_R=\varnothing\), its class-\(35\) matching must again pair terminal \(5\) with \(4\) against \(D_5\), now with the changed complete singleton mask \(C'_4\). Thus (24) transfers the unresolved closure test to a higher-junction **complete right row**; the minimal-\(J'=5\) phase rigidity of Note 151 cannot simply be reused for it.

There is a more precise comparison of the two complete cross-half class-\(35\) masks. Let \(M\) be the old \(P_{23}\) middle subpath between \(z\) and \(y_w\), and let \(T\) be the five-edge path from \(z\) through \(j_2,e_5,e_6,e_1,j_w\) to \(y_w\), with the core order reversed in the other port pairing. The new forced \(P'\) keeps the two outer pieces of \(P\) and replaces \(k\cup M\cup(g_w,xy,g_o)\) by the direct \(C\)-bridge \(nm\). Since \(F=T\cup k\cup(g_w,xy,g_o)\cup nm\), the complete masks satisfy
\[
\boxed{p\triangle p'=T\cup M,\qquad |T|=5,\quad |M|\ge3.} \tag{26}
\]
This is one proper even \(p/p'\)-alternating cycle, not merely an equality of terminal states. Its \(p'\)-phase has the two \(DC\) port edges \(j_2z,j_wy_w\), each owned by exactly \(\{D,C\}\) in the original all-\(S\) row (1). It also has \(h_2\) or \(h_w\) on \(M\), an original \(q\)-owned \(ZY\) edge of \(P\), owned by exactly \(\{t_{24},Y\}\) in (1). The two owner pairs are disjoint. Hence this explicitly known cycle is unalignable with **all five** other literal occurrences of the original all-\(S\) row, witnessed by just two edges. Under global no-seed, it must nevertheless be pairing-neutral for \(p\triangle D\), since both actual right rows force the \(5\)-partner to remain \(4\). This separates an owner obstruction from the still-missing pairing-critical obstruction.

This exact three-visit branch also has a direct order floor. The six vertices of \(\Omega\), the two chord-interior vertices, the four exterior vertices \(y_w,z,n,m\) of (22), the two new vertices \(z^+,y^+\) of (23), and \(w\) are fifteen distinct vertices. The two endpoints \(s,u\) of the critical \(Ur\) detour are additional: their incident \(q\)-owned \(ZY\) edges lie on \(Q\), whereas every listed inactive vertex uses a \(ZY\) edge of \(P\); the other listed vertices have different owner triples. The return \(R\) has at least six vertices and can overlap this list only at \(n,m\) when the bridge is \(UC\). Hence the \(DC\)-bridge case has at least \(15+2+6=23\) vertices.

For a \(UC\) bridge, both \(n,m\) lie on one original type-13 strand. If that strand is not \(R\), the six return vertices are all new, giving \(23\) before counting terminal \(2\). If \(nm\subset R\), it is an **interior** \(B=C\)-owned \(UC\) edge: the two outer \(UC\) edges of \(R\) meet the \(Q\)-collisions \(h_s,h_u\), whereas \(n,m\) meet \(P\). The return also needs a distinct interior \(q\)-owned \(UC\) edge by the two-collision gate, so \(R\) has at least four \(UC\) edges, length at least seven, and eight vertices. Allowing its two overlaps \(n,m\) again gives at least \(15+2+8-2=23\). In either \(UC\) subcase its terminal-\(2\) vertex is additional: that vertex has an \(r\)-owned \(Ur\) semiedge; \(z,z^+,y_w,y^+,s,u\) already use \(r\) on proper edges, \(w\) uses \(q=r\) on its \(Ur\) edge while \(q_{25}\) omits terminal \(2\), and the remaining listed vertices have no incident \(Ur\) pair. Thus the \(UC\) count is at least \(24\). Every cubic five-pole has odd order by \(3|V|=2|E_{\rm proper}|+5\). Therefore
\[
\boxed{|V(H)|\ge23\text{ if }nm=DC,\qquad |V(H)|\ge25\text{ if }nm=UC.} \tag{25}
\]
This is an order bound for the stated conditional profile only. It neither proves either threshold is attainable with exact support nor improves the general Case-XII lower bound.

**The three-mask theta trade.** Set \(N=k\cup nm\cup(g_o,xy,g_w)\), regarded as the five-edge path from \(z\) to \(y_w\). The three paths \(T,M,N\) have the same endpoints and disjoint interiors. The interior disjointness of \(M\) from \(F=T\cup N\) follows from the assumed *exactly three* maximal \(F\cap(q\triangle r)\) segments: an extra common vertex of these two two-regular subgraphs in a cubic graph would share an edge and give another segment. All three paths have odd length. Thus they form an odd theta, and the three complete matching changes are exactly its three cycles:
\[
 C\triangle C'=T\cup N=F,\qquad
 p\triangle p'=T\cup M,\qquad
 t\triangle t'=M\cup N.                                      \tag{27}
\]
Here \(t'_{24}=r\triangle P'\) is the literal cross-half partner of \(p'\), while \(t=r\triangle P\). The last equality follows directly from \(P\triangle P'=M\cup N\), not from a hypothetical single-occurrence companion for \(p\triangle p'\). In particular, the two actual all-\(S\) rows have identical complete \(B,D,Y\) masks and satisfy the signed load identity
\[
                 p+t+C=p'+t'+C'.                              \tag{28}
\]
This is a simultaneous three-occurrence repair of the owner-disjoint \(p/p'\) cycle. It verifies that an empty literal companion intersection on that cycle is compatible with actual full-matching row closure. The middle path \(M\) is odd because the \(q/r\)-alternating old \(P\) leaves both \(z\) and \(y_w\) on \(r\)-owned \(Ur\) edges.

The forced pentagon gives a concrete reading of this trade. In either port orientation, its five spokes have original owners \(rY,Ur,rC,rZ,Dr\). The restrictions of the **complete** occurrences to those spokes are

| actual row | five-spoke occurrence | three-spoke occurrences | one-spoke occurrences |
|---|---|---|---|
| old right row | \(r:\{rY,Ur,rC,rZ,Dr\}\) | none | \(q:rZ,\ B:Ur,\ D:Dr,\ Y:rY,\ C:rC\) |
| old all-\(S\) row | none | \(p:\{Ur,rC,rZ\},\ t:\{rY,rZ,Dr\}\) | \(B:Ur,\ D:Dr,\ Y:rY,\ C:rC\) |
| new all-\(S\) row | \(t':\{rY,Ur,rC,rZ,Dr\}\) | none | \(p':rC,\ B:Ur,\ D:Dr,\ Y:rY,\ C':rZ\) |

Thus the theta trade changes the pentagon's six-cover pattern from two three-spoke occurrences to one five-spoke occurrence while keeping every spoke loaded twice. The new forced \(P'\) avoids the pentagon; \(r\) and \(t'\) agree on all five spokes, although their complete masks and outer boundary states differ.

This trade also changes the anchored \(K_{34}\) carrier of Notes 093--109: with \(K_{34}=2\mathbf1-r-Y-C\), the new right row has \(K'_{34}-K_{34}=C-C'\ne0\) on \(F\). It therefore cannot by itself supply a same-\(K\) synchronized rectangle, even though both rows and all three perfect-matching switches are actual.

On \(\Theta\), the new \(p'\triangle D\) has the literal path
\[
v_0\xrightarrow{e_6=p'}v_5\xrightarrow{UD=D}y
\xrightarrow{xy=p'}x\xrightarrow{UD=D}v_2
\xrightarrow{e_3=p'}v_3.                                  \tag{29}
\]
The terminal pairing is **not** determined by this core path alone: the \(D/p'\) continuations outside \(\Theta\) can meet \(M\), including portions of the original type-13 return. Hence (27) does not upgrade the two-edge owner certificate to a pairing-changing cycle or contradict no-seed. The unresolved test is the complete exterior linkage of the three odd arms, particularly whether the forced \(P\)-visit to the return is in \(M\) or in an outer piece of \(P\).

**Exact four-port test when \(|M|=3\).** In the shortest case (23), put \(a=v_0,\ b=v_5,\ c=z^+,\ d=y^+\), and cut the four \(D\)-edges leaving the local \(T\cup M\) gadget at these vertices. Outside the gadget, \(p+D\) and \(p'+D\) have the **same** paths on these four ports and the four terminal ends. Inside, the old \(p+D\) path pairing is \((a,d)(b,c)\) for \((v_1w)(v_4 2)\), or \((a,c)(b,d)\) for \((v_4w)(v_1 2)\). The new \(p'+D\) pairing is \((a,b)(c,d)\) in either case; the two \(DC\) port edges have become doubled and form no open path.

These two local pairings induce *different* terminal pairings if and only if all four ports lead separately to terminal ends in the common exterior. If the exterior connects one pair of ports, the other two ports necessarily join the same pair of terminal ends under either local pairing; if it connects both port pairs, all terminal connections are external. Therefore global no-seed would force at least one exterior \(D/p\)-path joining two of \(a,b,c,d\) in this \(|M|=3\) subcase.

**The required linkage cannot occur in the two-collision profile.** Use the actual state-\(35\) Tait anchor \(A=U^{K_s}\) from the two-collision gate. Its \(A\triangle D\) paths pair \(5\) with \(1\) and \(2\) with \(4\), and \(a=v_0\), \(b=v_5\) lie on different open paths. The critical \(A\triangle p\) cycle removes two \(A/D\) segments: the return \(R\) on one type-13 terminal arm, *between its terminal \(4\) or \(5\) and the corresponding one of \(a,b\)*, and the \(Ur\) edge \(su\) on the opposite path's exterior tail, *between the other one of \(a,b\) and its terminal \(1\) or \(2\)*. Its two \(ZY\) edges cross-connect their four exposed ends. To obtain the no-seed \(5\leftrightarrow4\) pairing, the two arm-side ends must connect. Hence the core-side end of \(R\), containing one of \(a,b\), belongs to the resulting \(1\leftrightarrow2\) path, while the core-side end of \(su\), containing the other, belongs to the \(5\leftrightarrow4\) path. All other \(A\triangle p\) components have \(p\)-phase contained in \(D\), because \(h_s,h_u\) exhaust the exterior \(p\cap Z^1\) edges and \(A=p\) on \(\Theta\); they are closed \(A\triangle D\) components and do not change either open path. Thus \(a,b\) lie on **different** open \(p\triangle D\) paths.

But the two old local connections \((a,d)(b,c)\) or \((a,c)(b,d)\) now lie on these two different open paths. An exterior port-to-port path would either close one of them or join the two into one, both impossible. The four ports therefore lead separately to the four terminal ends, so the new local pairing \((a,b)(c,d)\) *changes* the terminal pairing. This contradicts Note 136, which under no-seed forces both actual all-\(S\) rows to have \(5\leftrightarrow4\). Consequently the exact three-visit branch has
\[
\boxed{|M|\ge5\quad\text{under no common complete }B_2+C_4\text{ seed}.} \tag{30}
\]
This removes the shortest off-decagon return in both \(DC\) and \(UC\) bridge types. Longer \(M\) can meet additional \(D/p\) paths internally, so the four-port argument does not exclude them. The new vertices of a longer \(M\) may lie on the already counted type-13 return \(R\); (30) does not by itself increase the order bounds (25).

The same four-port proof gives a stronger location gate. Apart from its first and last \(Ur\) edges, every \(r\)-edge of \(M\) is either \(Ur\) at an inactive right type-23 vertex or \(Dr\) on an original type-13 strand; an exterior type-12 \(Zr\) edge belongs to a separate closed \(q\triangle r\) component by Note 151 and cannot lie on \(P\). Suppose \(M\) has **no interior \(Ur\) edge**. Then every interior \(r\)-edge of \(M\) is also owned by \(D\). In the old \(p+D\) these edges are doubled, while in the new \(p'+D\) they alternate with the new \(q\)-phase of \(M\) to make one path from \(z^+\) to \(y^+\). There are no further \(D\)-ports inside \(M\). The old and new local four-port pairings are therefore exactly the ones above, for any odd length of \(M\), and the same distinct-open-path contradiction applies. Hence
\[
\boxed{\text{no seed and exactly three }F\cap(q\triangle r)\text{ segments}
\Longrightarrow M\text{ contains an interior }r\text{-owned }Ur\text{ edge}.} \tag{31}
\]
For \(|M|=5\), its unique middle \(r\)-edge must be \(Ur\), not a \(Dr\) edge on the critical type-13 arm. This is an exterior right-strand visit forced by the two-level terminal pairing, not by owner-counting alone.

At that first surviving length, write
\[
M=z\xrightarrow{Ur}c\xrightarrow{ZY}e\xrightarrow{Ur}f
 \xrightarrow{ZY}d_M\xrightarrow{Ur}y_w,\qquad c=z^+,\quad d_M=y^+.
\]
The new \(e,f\) are inactive right type-23 vertices. The old \(p+D\) intersects \(T\cup M\) in three separated local segments: one ending at \(c\), one ending at \(d_M\), and \(e\xrightarrow{Ur}f\). The first two begin at \(a,b\) in one order or the other. The new \(p'+D\) inserts the three complementary connections \(a-b,\ c-e,\ f-d_M\). Since \(a,b\) lie on different old open paths, no-seed requires \(e-f\) to lie on **one of those same two open paths**; one visit to a closed component cannot repair their crossing. If it lies on the path containing the segment ending at \(c\), the direct \(c-e\) connection must join the two *outer* ends of that path's two removed segments. If it lies on the path containing the segment ending at \(d_M\), the direct \(f-d_M\) connection must join its two outer ends. This is the exact remaining orientation gate for the shortest allowable \(M\); the two \(ZY\) edges alone do not establish it.

The right-network strand order alone does **not** locate the needed \(e-f\) visit. An exterior right type-23 strand may pass through an original type-12 vertex with owner pairs \(UY,Zr,DC\). There \(q=p=A=U\) uses \(UY\), while \(D\) uses \(DC\); thus \(p+D\) leaves the right-network \(Zr/DC\) corridor without creating a \(p\cap Z\) collision. This diversion can, however, be removed by an **actual simultaneous closed phase normalization**.

Let \(\mathscr L\) be the union of all exterior original type-12 \(Z\triangle Y\) components. Each is a closed \(q\triangle r\) component by Note 151 and avoids \(P\). It also avoids the ten-cycle \(F\): a vertex of \(F\) on such a component would contribute a common \(q\)-owned \(UY\) edge to \(F\cap(q\triangle r)\) on a closed component, a fourth segment beyond \(e_1,k,(g_w,xy,g_o)\). On \(\mathscr L\), \(q=p=A=U\), \(B=Z^1=Z\), and \(r=Z\). Switch the complete \(q,B\) pair on every component of \(\mathscr L\), and simultaneously switch the Tait pair \(A,Z^1\) on the same components. Call the resulting masks \(\bar q,\bar B,\bar A,\bar Z^1\), and set \(\bar p=\bar q\triangle P\). The switches are proper and preserve both actual six-cover rows and the Tait triple; \(\bar p=p\triangle\mathscr L\), \(\bar A=A\triangle\mathscr L\), so \(\bar A\triangle\bar p=A\triangle p\). They leave \(F,P,P'\), the three-arm theta, and the four local ports untouched. Under no-seed, both \(\bar p+D\) and its switched phase \(\bar p'+D\) still pair \(5\) with \(4\), while the same critical return argument puts \(a,b\) on different open \(\bar p+D\) paths.

At every original type-12 vertex of \(\mathscr L\), now \(\bar p=Zr\) and \(D=DC\), so \(\bar p+D\) follows the original right-network strand. At all other exterior right type-23 vertices it follows the \(Ur/DC\) or \(Ur/YD\) strand, except at \(s,u\), where \(\bar p\) takes the two \(Q\)-collision \(ZY\) edges. Another \(ZY\) exit on a closed \(q\triangle r\) component would be a third exterior \(p\cap Z\) collision in the original phase; a \(ZY\) edge on \(P\) was switched away. Hence the normalized \(\bar p+D\) follows the two open right type-23 strands until the single \(Ur\) edge \(su\) breaks one of them. Its core side and terminal side lie on the two different open \(\bar p+D\) paths; the uncut strand reaches terminal \(1\) or \(2\). A middle \(Ur\) edge \(e-f\) on a closed strand lies on a closed \(\bar p+D\) component. On the uncut strand or the core side of \(su\), it follows the corresponding core-port segment, making that port a *middle* end and failing the outer-end test above. Therefore \(e-f\) must lie beyond \(su\), toward the terminal end of the same cut strand, in this order:
\[
\begin{array}{c|c}
su\text{ on }j_2\to2 & c\ \cdots\ [su]\ \cdots\ e-f\ \cdots\ 2,\\
su\text{ on }j_w\to w & d_M\ \cdots\ [su]\ \cdots\ f-e\ \cdots\ w.
\end{array}                                                   \tag{32}
\]
Here \([su]\) leaves the order of \(s,u\) unspecified. The dots denote possible intervening right-strand vertices. This is a **necessary geometric placement**, not a realization or a contradiction: the two \(ZY\) edges of \(M\) can jump across \(su\) and meet the required outer-end orientation. The normalization is essential; applying this strand trace to the unnormalized \(p+D\) would be invalid at type-12 vertices.

The \(ZY\) jump in (32) also has a girth cost. In the first line, the proper edge \(ce\) closes the right-strand subpath from \(c\) through \(su\) to \(e\); in the second, \(d_Mf\) does the same. On that strand the edges alternate \(DC\) with \(Ur\) or \(Zr\). The portions on either side of the \(Ur\) edge \(su\) each start and end with \(DC\), so each has odd length. If both had length one, the \(ZY\) jump would close a four-cycle. Girth at least five therefore makes one portion at least three edges long, adding **two distinct strand vertices** beyond \(s,u\). There is a separate two-vertex cost already present before this girth argument: the middle \(Ur\) edge \(ef\) makes \(e,f\) new vertices relative to the count in (25). They are different from its counted \(c,d_M,z,y_w,s,u,w,n,m\): the proper \(\bar q\)-edges at \(e,f\) are the two \(M\)-jumps, while those at the listed inactive vertices are the other displayed \(ZY\) edges, and the remaining vertices have different original owner types. The girth vertices lie strictly inside the strand subpath from \(c\) to \(e\) or from \(d_M\) to \(f\), so they are distinct from \(e,f\) as well. When \(nm=UC\), \(n,m\) and the return \(R\) lie on a type-13 strand, while all these new vertices lie on right type-23 strands. The \(|M|=5,\ nm=UC\) subcase consequently has at least \(24+2+2=28\) vertices and, by odd order,
\[
\boxed{|V(H)|\ge29\qquad(|M|=5,\ nm=UC,\text{ no seed}).} \tag{33}
\]
For a \(DC\) bridge, the already counted \(n,m\) are adjacent by their \(DC\) bridge. The two extra positions of a shortest three-edge strand portion are adjacent by an \(Ur\) or \(Zr\) edge, so **both** cannot be \(n,m\). At least one is new relative to (25) and to \(e,f\), giving \(23+2+1=26\), hence odd order at least \(27\). Thus the no-seed, \(|M|=5\) bounds are \(27\) for \(DC\) and \(29\) for \(UC\); they are not asserted for longer \(M\).

**The second complete \(q/C\) component is forced to collect the return exits.** Retain \(|M|=5\), (32), and the normalized \(\bar q,\bar B,\bar p,\bar A\) phase above. Let \(L\) be the component of \(\bar q\triangle C\) containing the middle \(ZY\) edge \(ce\) when \(su\) is on the \(2\)-strand, or \(d_Mf\) when it is on the \(w\)-strand. At each original type-12 vertex the normalization makes \(\bar q=r=Zr\), while \(C=DC\); at every intervening original inactive type-23 vertex \(\bar q=r=Ur\), except at \(s,u\). Hence \(\bar q\triangle C\) follows the original right type-23 strand from one end of that \(ZY\) edge toward \(s\) and from its other end toward \(u\), alternating \(C\)-owned \(DC\) with \(\bar q\)-owned \(Ur\) or \(Zr\). At \(s,u\) it takes the two \(\bar q=q\)-owned edges \(h_s,h_u\). Therefore both \(Q_{54}\) collisions lie on **this same component** \(L\).

Following \(L\) past \(h_s,h_u\) through the \(C\)-owned first and last \(UC\) edges of the return \(R\) reaches its \(\bar q=q\)-owned \(P_{23}\) exits \(k_a,k_d\). Thus
\[
\boxed{\{h_s,h_u,\,ce\text{ or }d_Mf,\,k_a,k_d\}\subseteq E(L).} \tag{34}
\]
The set notation allows \(k_a=k_d\). This component is distinct from the ten-cycle \(F\), whose three \(q\triangle r\) visits are already fixed. If \(k_a\ne k_d\), \(L\) has at least five separated intersections with \(\bar q\triangle r\): the two \(Q\)-edges and the three indicated \(P\)-edges. The component may be open in this distinct-exit case, and additional intersections on its as-yet-untraced continuation are possible.

**The coincident return exits are forbidden by a complete closed switch.** Suppose \(k_a=k_d=ad\). The two strand arcs from the middle \(ZY\) edge to \(h_s,h_u\), followed by \(h_s,ta,ad,dv,h_u\), close one proper alternating \(\bar q/C\) cycle \(L\). It meets \(\bar q\triangle r\) in exactly four isolated edges: the middle \(P\)-edge \(ce\) or \(d_Mf\), the \(P\)-edge \(ad\), and the two \(Q\)-edges \(h_s,h_u\). Along the normalized right strand, \(\bar q=r\) on every intervening \(Ur\) or \(Zr\) edge and \(C\ne r\) on every intervening \(DC\) edge. On the two end \(UC\) edges \(ta,dv\), \(C=1\) and \(r=0\). Thus no unlisted edge of \(L\) lies in \(\bar q\triangle r\).

Switch the two **complete** matchings \(\bar q,C\) on \(L\), obtaining \(\widehat q_{25},\widehat C_4\) and an actual right six-cover row. Write \(G=\bar q\triangle r\). Then \(\widehat q\triangle r=G\triangle L\). On \(Q_{54}\), the two removed edges \(h_s=ts,h_u=uv\) enclose the single \(r\)-edge \(su\), leaving outer pieces at \(t,v\). The two normalized strand arcs of \(L\) join \(s,u\) to the two ends \(c,e\) (or \(d_M,f\)) of the removed middle \(P\)-edge. The unchanged \(su\) therefore reconnects **the two ends of this same \(P\)-edge** through the strand arcs; this is a neutral detour of that edge, independent of where \(ad\) sits along \(P\). The remaining two arcs of \(L\) are exactly \(t-a\) and \(d-v\). They attach the two outer \(Q\) pieces separately to the two sides of the removed \(P\)-edge \(ad\). Since \(ad\) belongs to the open \(P_{23}\), those sides lead to terminals \(2,3\), one on each side. Thus the new terminal pairing crosses \(P\) and \(Q\): terminal \(2\) ends at \(4\) or \(5\), never at \(3\). This is a forbidden \(T\)--\(T\) or all-terminal BF type under the negative Case-XII support. Hence, in this conditional \(|M|=5\) branch,
\[
\boxed{k_a\ne k_d.}                                      \tag{35}
\]
This argument does not require the no-seed assumption beyond the earlier reductions that produced (32); it excludes the coincident-exit subcase by the actual graph-induced matching closure. For distinct exits, the continuation of \(L\) beyond \(k_a,k_d\) is not yet determined, so (35) does not settle the complete Case-XII closure.

**A direct \(\bar B=r\) bridge between the return exits is forbidden.** Let \(A,D_*\) be the far ends of the distinct \(P\)-edges \(k_a=aA,k_d=dD_*\). Suppose they are joined by one proper edge \(A D_*\) owned by both \(\bar B_2\) and \(r_{34}\). Then
\[
K_{Br}=h_s\cup su\cup h_u\cup dv\cup k_d\cup A D_*\cup k_a\cup ta
\]
is a closed alternating component of the **complete** \(\bar q_{25}\triangle\bar B_2\). Indeed its four \(\bar q\)-edges are \(h_s,h_u,k_a,k_d\); its four \(\bar B\)-edges are \(su,dv,A D_*,ta\). In \(G=\bar q\triangle r\), the three-edge path \(h_s\cup su\cup h_u\) is a segment of \(Q_{54}\), while \(k_a\cup A D_*\cup k_d\) is a segment of \(P_{23}\). The two remaining edges \(ta,dv\) are absent from \(G\). Switching \(\bar q,\bar B\) on \(K_{Br}\) therefore deletes one segment from each open path and joins their exposed ends by \(ta,dv\): the new \(2\)-terminal path ends at \(4\) or \(5\), never at \(3\). The switched six-cover is an actual right row, so the forced-path argument of Note 136 forbids either outcome by the all-terminal or \(T\)--\(T\) negative support. Consequently
\[
\boxed{k_a\ne k_d\quad\Longrightarrow\quad
\text{their far ends are not joined by an edge owned by }\bar B=r.} \tag{35a}
\]
This exclusion uses no assumption about whether the \(\bar q/C\) component \(L\) is open or closed and no assumption on its number of \(P\)-visits. It does not forbid a longer \(\bar q/\bar B\) continuation, whose additional intersections with \(P\) or \(Q\) can change the reconnection.

There is also an exact conditional test when \(k_a\ne k_d\). Suppose \(L\) is closed and its **only** intersections with \(G=\bar q\triangle r\) are the five displayed edges \(ce\) or \(d_Mf\), \(h_s,h_u,k_a,k_d\). Replace the first \(P\)-edge by the neutral detour through \(s-u\) as above. The remaining switch cuts \(P\) at \(k_a,k_d\), joins the far ends of those edges by the otherwise \(G\)-disjoint continuation of \(L\), and attaches the two outer \(Q\) pieces to \(a,d\), respectively. The forced \(2\leftrightarrow3\) pairing survives **if and only if** \(a,d\) are the two middle ends of the \(P\) cuts: then the middle \(P\) piece joins the two \(Q\) pieces and the continuation joins the two outer \(P\) pieces. If either \(a\) or \(d\) is an outer \(P\) end, the new pairing crosses \(P,Q\) and is forbidden. This five-visit orientation is a necessary surviving exterior linkage, not a construction of a genuine exact-Case-XII pole.

In this exact five-visit case the \(G\)-free continuation of \(L\) between the far ends of \(k_a,k_d\) has only two possible forms. If a far end is on an original type-13 strand with owners \(UC,Dr,ZY\), the next \(L\)-edge is \(C\)-owned \(UC\). At its other endpoint the next \(\bar q\)-edge must be \(ZY\); to avoid a **new** carrier visit, it must be the *other displayed exit* \(k_d\) or \(k_a\). The continuation is then one literal \(UC\) edge joining the two far ends. Otherwise both far ends lie on a right type-23 strand. There the continuation alternates \(C\)-owned \(DC\) with \(\bar q=r\)-owned \(Ur\), possibly traversing normalized original type-12 vertices with \(\bar q=r=Zr\). It cannot pass through the unique exterior right junction \(w\), because the \(\bar q/C\) route there enters the corridor to terminal \(1\), nor through the theta core already occupied by \(F\). Passing through the terminal-\(2\) vertex as an internal point would use its \(\bar q\)-owned \(ZY\) edge, another \(P\)-visit; that vertex may occur only as one of the two far ends. Hence the two exits must be joined either by one \(UC\) bridge on a type-13 strand or by one \(G\)-free interval of a right type-23 strand. Both remain compatible with the safe middle-end orientation above.

**A literal \(q/B\) switch rules out a direct return in the \(UC\)-bridge form.** Let the far ends of \(k_a,k_d\) be \(A,D_*\), joined by the single \(UC\) edge \(A D_*\) just described; \(D_*\) is a vertex, not the class-five matching \(D_5\). At \(t,a,A,D_*,d,v\), the \(UC\) edges \(ta,A D_*,dv\) are owned by both \(\bar B\) and \(C\), while \(k_a,k_d,h_s,h_u\) are owned by \(\bar q\). At \(s,u\), \(\bar B\) owns \(su\). Hence the eight-edge circuit
\[
K_B=h_s\cup su\cup h_u\cup dv\cup k_d\cup A D_*\cup k_a\cup ta
\]
is a proper closed component of the **complete** \(\bar q\triangle\bar B\). Switch that pair on \(K_B\), keeping the literal \(D_5,r_{34},Y_3,C_4\) masks fixed. In the five-visit safe orientation, write \(P_{a,d}\) for the subpath of \(P_{23}\) between the two middle ends \(a,d\) of its cuts \(k_a,k_d\). The new forced \(2\leftrightarrow3\) path replaces \(k_a\cup P_{a,d}\cup k_d\) by the single edge \(A D_*\); the former \(Q\) path instead uses \(ta\cup P_{a,d}\cup dv\). Thus its canonical cross-half class-\(35\) matching \(p^{B}\) satisfies the complete-mask identity
\[
p^{B}\triangle\bar p
 =h_s\cup su\cup h_u\cup ta\cup P_{a,d}\cup dv.       \tag{36}
\]
If \(P_{a,d}\) were exactly the internal \(a\)-to-\(d\) segment of the original return \(R\), the right side of (36) would be the pairing-critical cycle \(\Gamma\subseteq\bar A\triangle\bar p\) of the two-collision gate. The other \(\bar A\triangle\bar p\) components are closed \(\bar A\triangle D_5\) components and leave its terminal pairing unchanged. Hence \(p^{B}\triangle D_5\) would pair \(5\) with \(1\), contradicting Note 136's forced partner \(4\) for every actual right-row cross-half phase under no common complete \(B_2+C_4\) seed. Consequently this \(UC\)-bridge, closed-five-visit subcase requires \(P_{a,d}\) to leave the interior of \(R\). Equivalently at least one interior \(UC\) edge of \(R\) is \(\bar B\)-owned, while the original two-collision gate already requires another interior \(UC\) edge to be \(\bar q\)-owned. The return therefore has length at least seven:
\[
\boxed{|R|\ge7\quad\text{for a safe closed five-visit }L\text{ with a }UC\text{ bridge and no seed}.} \tag{37}
\]
At the two endpoints of the required \(\bar B\)-owned interior \(UC\) edge, \(\bar q\) uses distinct \(ZY\) edges. The exact two-collision hypothesis places both on \(P\), so an exact-five-visit \(L\) leaves these two additional \(P\)-contacts to other \(\bar q/C\) components. This excludes the shortest five-edge return in the \(UC\)-bridge form; it does not exclude a longer return or the right-type-23 continuation.

Equation (36) also tracks the collision rather than only its count. Relative to the simultaneously normalized Tait singleton \(\bar Z^1\), the two old exterior \(\bar p\cap\bar Z^1\) edges \(h_s,h_u\) disappear from \(p^B\); the new exterior intersections are exactly the \(\bar q\)-owned \(ZY\) edges of \(P_{a,d}\). Thus the \(q/B\) switch transfers the two critical collisions from \(Q\) onto the return detour in \(P\). In the direct-return case the transferred set is empty, giving the contradiction above; a surviving case needs at least the two new exits forced by a \(\bar B\)-owned interior \(UC\) edge.

The other exact-five-visit form does **not** inherit this eight-edge switch. If the far ends of \(k_a,k_d\) are joined by a \(G\)-free interval \(X\) of a right type-23 strand, every edge of \(X\) is owned by \(C\) or by \(\bar q=r\), and none is owned by \(\bar B\). At an inactive right type-23 vertex the three choices are \((\bar q,\bar B,C)=(Ur,ZY,DC)\); at a normalized original type-12 vertex they are \((Zr,UY,DC)\). In contrast, the fixed seven-edge path
\[
J_B=k_a\cup ta\cup h_s\cup su\cup h_u\cup dv\cup k_d
\]
alternates between the complete \(\bar q,\bar B\) masks. A \(\bar q\triangle\bar B\) component containing \(J_B\) must continue at the far ends of \(k_a,k_d\) along their \(\bar B=r\)-owned \(Ur\) edges, which are also on \(G\), rather than along \(X\). Thus the \(UC\)-bridge repair in (36) cannot be copied by substituting the \(DC/Ur/Zr\) interval \(X\). If a far end is the terminal-\(2\) vertex, its \(\bar B\)-semiedge closes this trace at terminal \(2\): \(J_B\) lies on the forced open \(2\leftrightarrow3\) component of \(\bar q\triangle\bar B\), not on a switchable closed component. Otherwise the two exterior \(\bar q/B\) tails and their further \(G\)-visits remain the missing full-mask information.

There is a first forced step on each such tail. If a far end \(A\) is an internal inactive right type-23 vertex, its outgoing \(\bar B=r\)-owned \(Ur\) edge cannot join the two far ends directly: that would close the open \(P\) component through its already existing middle \(a\)-to-\(d\) route. It therefore leads to another \(\bar B=r\) vertex. The right-row \(J'=5\) phase classification excludes a \(\bar q\)-owned exterior \(ZC\) exit there, and the vertex cannot be an original type-12 vertex on an \(Ur\) edge. Hence \(\bar q\) takes a new \(ZY\) edge; by the exact two-collision assumption this edge lies on \(P\), not on \(Q\) or a closed \(G\) component. It cannot be \(h_s\) or \(h_u\), since their \(\bar B\)-owned \(Ur\) edge is the already fixed \(su\). Since \(A\) is an outer end of the \(k_a,k_d\) cuts in the safe orientation, this is an extra \(P\)-visit on an outer piece, beyond the five displayed \(L\)-visits. If both far ends are internal, their extra \(ZY\) edges are distinct: one edge joining the two next vertices would connect the two outer \(P\) pieces to each other and close the same \(P\) component that already joins \(a\) to \(d\). Thus this form requires two additional, distinct outer-piece \(P\) exits, or one if a far end is the terminal-\(2\) vertex. Their full matching-difference components are not determined by the local five-visit geometry.

When both far ends are internal, at least one of these two new outer-piece exits is outside the already specified contiguous \(P\)-block \(W=k\cup M\cup(g_w,xy,g_o)\). The cuts \(k_a,k_d\) lie outside \(W\): they are on the type-13 return, whereas the two \(M\)-jumps join inactive type-23 vertices, and \(L\) is disjoint from \(F\), which contains \(k,g_w,g_o\). Since \(W\) is one contiguous subpath of the simple open \(P\), it can meet at most one of the two outer pieces defined by the distinct cuts \(k_a,k_d\). The other forced \(ZY\) exit is therefore a genuinely additional \(P\)-edge beyond \(W\) and the five contacts of \(L\). This is a full-path cost, not a contradiction with exact negative support: that extra \(q\)-owned edge is switched away in \(\bar p=\bar q\triangle P\).

The two far-end vertices themselves also improve the conditional order count. Neither is one of the vertices listed in (25), the middle vertices \(e,f\), or the internal vertices added for girth in (33): at each far end \(\bar q\) uses \(k_a\) or \(k_d\), while all those listed vertices have already specified, different \(\bar q\)-edges; the girth vertices lie on the other arc of the simple \(\bar q/C\) component \(L\). In the \(DC\)-bridge case, even a possible terminal-\(2\) far end was not counted in (25), so (33)'s pre-parity count \(26\) increases by two and gives \(|V(H)|\ge29\). In the \(UC\)-bridge case terminal \(2\) was counted in (25): two internal far ends give \(28+2\) and hence \(|V(H)|\ge31\), while one terminal-\(2\) far end leaves the general \(|V(H)|\ge29\) bound. These bounds apply only to the closed, exactly-five-visit \(L\) with the safe right-type-23 continuation.

Any further \(L\cap G\) edges on a **closed** \(L\) must lie on \(P\). Indeed \(L\) misses the entire core \(F\), and the only exterior \(q\)-owned \(ZY\) edges on \(Q\) are the two collisions \(h_s,h_u\); an additional one would be a third exterior \(p\cap Z\) edge. On an exterior type-12 component the normalization gives \(\bar q=r\), while every other exterior common \((\bar q\triangle C)\cap G\) edge is a \(\bar q\)-owned \(ZY\) edge. The normalization leaves such an edge unchanged; if it lay on a closed component of \(G\), the original \(p=q\) there would give a third \(p\cap Z\) collision. Thus the unresolved closed case has at least three \(P\)-visits and exactly the two displayed \(Q\)-visits; its extra visits, if any, are on \(P\). If \(L\) is open, it is the unique \(1\leftrightarrow3\) component of \(\bar q\triangle C\). Neither case is excluded by the present switch.

**An open \(L\) forces a second closed component to revisit \(P\).** Suppose \(L=O_{13}\) is open and contains exactly one of the two \(M\)-jump edges \(ce,d_Mf\). Let \(J\) be the \(\bar q\triangle C\) component containing the other jump \(j\). It is closed: \(O_{13}\) is the unique open component, and \(J\ne F,L\). The two ends of \(j\) lie on the separate right type-23 strands heading toward terminal \(2\) and the exterior junction \(w\), respectively. At each end \(J\) follows a \(C\)-owned \(DC\) edge away from the nearby \(F\) port. If the terminal-\(2\) tail follows only \(G\)-free \(DC/(Ur\text{ or }Zr)\) edges, it reaches the terminal-\(2\) vertex, where its next \(\bar q\)-edge is a \(ZY\) edge of \(P\). The \(w\) tail cannot reach \(w\) without a \(\bar q\)-owned \(ZY\) exit, because from \(w\) the same \(\bar q/C\) component would continue to terminal \(1\) and would be open. Any earlier exit on either tail is also a \(\bar q\)-owned \(ZY\) edge of \(P\): a \(Q\) or closed-\(G\) exit would be a third exterior \(p\cap Z\) collision. Thus each tail supplies a \(P\)-visit beyond \(j\).

These two extra visits cannot be the **same** \(ZY\) edge. If they were, \(J\) would have exactly two \(G\)-intersection segments, both on the old \(P\): the jump \(j\subset M\) and that one tail-joining edge outside \(M\). Switch the complete \(\bar q,C\) pair first on the disjoint ten-cycle \(F\). The forced \(P'_{23}\) then uses the direct \(C\)-bridge \(nm\), while the former middle subpath \(M\), including \(j\), lies on the new \(Q'_{54}\): the two remaining arcs of \(F\) join the old \(Q\)-cut at \(e_1\) to the two ends of \(M\). The other contact of \(J\) remains on \(P'\), since it is outside \(M\) and \(F\). The complete \(\bar q^F,C^F\) difference still has \(J\) as a closed component. Switching that pair on \(J\) would now join one exposed \(P'\) end to one exposed \(Q'\) end along each complementary arc of \(J\), crossing the two open terminal paths and giving a forbidden BF type. Hence, under exact negative support,
\[
\boxed{L=O_{13},\ J\ne L\quad\Longrightarrow\quad
J\text{ has at least three distinct }P\text{-visits: }j\text{ and one on each tail}.} \tag{38}
\]
This is a necessary full-closure cost for the open branch. If both \(M\)-jumps belong to the same open \(L\), or if the closed \(J\) has three or more \(P\)-visits, the argument gives no contradiction.

**Order gate when both jumps belong to the open component.** Let \(j_\parallel\) be the \(M\)-jump that encloses \(su\) on its right type-23 strand, and let \(j_\times\) be the other jump, joining the terminal-\(2\) and \(w\) strands. Suppose both belong to the open \(L=O_{13}\). The known passage from \(k_a\) through \(h_s,j_\parallel,h_u\) to \(k_d\) is a subpath of the simple open \(L\). Therefore \(j_\times\) lies on exactly one of its two remaining tails, toward terminal \(1\) or terminal \(3\). Write
\[
E_0=\{k,g_w,g_o,j_\parallel,j_\times,k_a,k_d\}
\]
for the already specified proper \(\bar q\)-owned \(ZY\) edges of \(P_{23}\).

There is a finite port classification when no further proper \(\bar q\)-owned \(ZY\) edge lies on \(P\) outside \(E_0\). If \(j_\times\) lies on the **terminal-\(3\) tail**, the terminal-\(1\) end of \(L\) follows the right type-23 strand from \(w\) toward the \(w\)-side endpoint of \(j_\times\). It must first leave at one of \(k_a,k_d\), since encountering \(j_\times\) first would put that jump on the terminal-\(1\) tail. After the fixed middle passage, the other \(k\)-edge returns to the same strand and continues toward \(j_\times\). Hence the far ends \(A,D_*\) of the two \(k\)-edges occur in order in the open strand interval between \(w\) and \(j_\times\). Their \(\bar B=r\)-owned \(Ur\) edges both point into the interval between them. A direct edge \(A D_*\) is excluded by (35a). At the other end of either \(\bar B=r\) edge, \(\bar q\) owns a \(ZY\) edge of \(P\), because the edge and its incident \(k\)-edge are consecutive on the open \(\bar q\triangle r\) path. The only already specified proper \(ZY\) ports that can lie strictly inside this interval are the bridge ends \(n,m\) of the disjoint ten-cycle \(F\); its ports \(z,y_w\) are closer to the two core junctions, and its chord ports are not on this right type-23 strand. The terminal-\(3\) vertex cannot lie inside the interval: after \(j_\times\), the open \(L\) follows its terminal-\(2\)-strand tail toward terminal \(3\), and without another proper \(ZY\) exit cannot return to the \(w\)-strand. Thus, if no new \(P\)-edge appears, the two distinct \(\bar B=r\) edges must join \(A,D_*\) to \(n,m\), respectively. In particular \(nm\) is a \(DC\) bridge, and the old \(P\) has an \(a\)-to-\(d\) subpath through \(k_a\), these two \(\bar B=r\) edges, the complete contiguous block \(W=k\cup M\cup(g_w,xy,g_o)\), and \(k_d\). In this \(DC\)-bridge case, \(n,m\) lie on right type-23 strands, so none of the already specified \(E_0\) ports lies strictly between \(a\) and \(d\) on the type-13 return \(R\). At each vertex in that interior \(\bar q\) chooses either its incident \(UC\) edge or a proper \(ZY\) edge. Any chosen \(ZY\) edge must lie on \(P\): on \(Q\) or a closed \(\bar q\triangle r\) component it would remain in \(\bar p\cap\bar Z^1\), making a third exterior collision. The no-extra-contact assumption therefore makes every interior \(UC\) edge \(\bar q\)-owned and forces \(P_{a,d}=R_{a,d}\). The two distinct \(a\)-to-\(d\) passages would close the open path \(P\), a contradiction. Thus the terminal-\(3\)-tail order forces an additional proper \(P\)-edge outside \(E_0\), even when both far ends try to dock at \(F\).

If \(j_\times\) lies on the **terminal-\(1\) tail**, its terminal-\(2\)-side strand tail must reach one of the two \(k\) far ends, say \(A\). If \(A\) is not itself the terminal-\(2\) vertex, its outgoing \(\bar B=r\)-owned \(Ur\) edge points toward terminal \(2\). The next \(\bar q\)-edge is on \(P\). With no new proper \(ZY\) edge it must be the terminal-\(3\) semiedge or one of the specified \(ZY\) ports. The other \(k\) far end is excluded by (35a), and the only available specified proper ports on this outward tail are again \(n,m\) if the \(DC\)-bridge ends are placed there. Therefore the no-extra-contact open branch has the necessary alternatives
\[
\boxed{j_\times\text{ on the terminal-}1\text{ tail},\qquad
A=\text{terminal-}2\text{ vertex},\ \text{or }A\xrightarrow{\bar B=r}\text{terminal-}3\text{ vertex},\
\text{or }A\xrightarrow{\bar B=r}\{n,m\}.}                 \tag{39}
\]
The last alternative requires \(nm=DC\), because only then can a bridge end own a right-type-23 \(\bar B=r\) edge. These are necessary incidences, not realizations of the full exact-support closure. An additional proper \(P\)-visit remains the other surviving possibility.

In either **terminal docking** of (39), the fixed seven-edge \(\bar q/\bar B\) passage \(J_B=k_a\cup ta\cup h_s\cup su\cup h_u\cup dv\cup k_d\) lies on the forced open \(2\leftrightarrow3\) component of \(\bar q\triangle\bar B\). If \(A\) is the terminal-\(2\) vertex, the continuation from the other \(k\) far end must reach terminal \(3\); if the \(\bar B=r\) edge from \(A\) reaches terminal \(3\), that continuation must reach terminal \(2\). In these two terminal dockings the literal \(B\)-edges \(ta,dv\subset J_B\) are absent from \(r\), so the unique \(2\leftrightarrow3\) component fails Note 131(9)'s common-path criterion. Its confluence set \(\mathcal F\) is empty **for this row**. This does not imply that the complete \(B_2+C_4\) seed is absent; the criterion is sufficient, not necessary. The \(F\)-dockings in (39) may put \(J_B\) on a closed or different open component and need a separate trace.

The same two edges remain unavailable to the triple colours in every right row of Note 137's **fixed complete** \((\bar B_2,Y_3,C_4)\) fibre. Indeed its triple load is the literal vector \(K=2\mathbf1-\bar B-Y-C\), and \(K(ta)=K(dv)=0\). Thus any right row \(q'_{25}+\bar B_2+D'_5+r'_{34}+Y_3+C_4=2\mathbf1\) has \(q'(ta)=D'(ta)=r'(ta)=q'(dv)=D'(dv)=r'(dv)=0\). Its Note-131 common-path criterion can hold only if the **new** forced \(2\leftrightarrow3\) component of \(q'\triangle\bar B\) avoids both edges. Whether the full fixed fibre forces such a rerouting is not determined by the local open-\(L\) incidence.

Switching the open \(1\leftrightarrow3\) component of \(q\triangle C\) and exchanging the resulting triple and singleton occurrence names gives no new phase mechanism: if \(q\triangle C=O_{13}\sqcup F_1\sqcup\cdots\sqcup F_k\), the resulting triple is \(C\triangle O_{13}=q\triangle(F_1\sqcup\cdots\sqcup F_k)\). It is exactly the simultaneous switch on the **closed** components. Thus the remaining \(q/C\) question is their actual intersection pattern with \(P_{23}\) and \(Q_{54}\), not a further independent open-path transport.

**A zero-load barrier and a forced class-five phase in the fixed fibre.** Keep the open-\(L\), both-jumps, no-new-proper-\(P\)-contact hypotheses of (39), and suppose one of its two terminal dockings occurs. The following is a necessary condition for Note 131(9)'s confluence in *any* right row of the fixed complete \((\bar B_2,Y_3,C_4)\) fibre; it does not assume that such a confluence exists.

There is an exact one-path form of that criterion. For a fixed-fibre right row \(q'_{25}+\bar B_2+D'_5+r'_{34}+Y_3+C_4=2\mathbf1\), let \(P'_{23}\) be the forced open component of \(q'\triangle r'\). Then
\[
\boxed{\text{Note 131(9) holds for this row}
\quad\Longleftrightarrow\quad E(P'_{23})\cap E(r')\subseteq E(\bar B).} \tag{40a}
\]
Indeed every \(\bar B\)-edge has \(K\)-load at most one, so a \(\bar B\cap r'\) edge cannot also belong to \(q'\). A proposed common path therefore lies in \(q'\triangle r'\) and has ends \(2,3\); it must be the whole unique \(P'_{23}\). Conversely, the containment makes \(P'_{23}\) the required \(q'/\bar B\)-alternating path. Thus the fixed-fibre question can be tested on the literal \(r'\)-phase of one forced path, without comparing two independently chosen terminal routes.

For every vertex \(v\), let \(b(v)\) be its unique \(\bar B\)-edge, possibly a semiedge. Define
\[
V_0=\{v:b(v)\in E(Y)\cup E(C)\}.
\]
On an edge common to \(\bar B\) and one of \(Y,C\), the literal triple load \(K=2\mathbf1-\bar B-Y-C\) is zero. The two singleton overlaps cannot occur together in a genuine six-cover row. Consequently, for every decomposition \(K=q'_{25}+D'_5+r'_{34}\), a \(q'\)-alternating path whose other phase lies in \(\bar B\cap r'\) avoids **every vertex of \(V_0\)**: at such a vertex its required \(\bar B\)-edge has zero \(r'\)-load. In particular
\[
\boxed{\text{fixed-fibre Note-131 confluence}\quad\Longrightarrow\quad
\text{its }2\leftrightarrow3\text{ path avoids }V(R),}       \tag{40}
\]
where \(R=t-a-\cdots-d-v\) is the entire original type-13 return, not just \(ta,dv\). Indeed, each vertex of this strand has owner triple \(UC,Dr,ZY\), and \(\bar q+\bar B=U+Z\) makes its \(\bar B\)-edge either \(UC\subseteq C\) or \(ZY\subseteq Y\). The normalization changed only exterior original type-12 components, so this remains true throughout \(R\). The claim is only a necessary barrier: a path avoiding \(V_0\) need not have its remaining \(\bar B\)-edges owned by \(r'\).

Let \(A\) be the \(k_a=aA\) far end selected in (39). In either terminal docking, a successful confluence path must pass through \(A\). If \(A\) is the terminal-\(2\) vertex, the path starts with its \(\bar B=r\) semiedge. If its \(\bar B=r\) edge joins the terminal-\(3\) vertex, the path must use that edge immediately before its final \(q'\) semiedge. At \(A\), taking \(k_a\) as the \(q'\)-edge would enter the forbidden vertex \(a\in V(R)\). Its only other non-\(\bar B\) edge is the \(C\)-owned \(DC\) edge. Since the three incident edges of \(K\) each have load one at \(A\), the full triple colouring is forced there:
\[
\boxed{q'(A)=C(A),\qquad D'(A)=k_a,\qquad
r'(A)=\bar B(A)=r(A).}                              \tag{41}
\]

The forced \(D'\)-phase propagates across the whole interior of \(R\). Under the no-new-contact hypothesis, every interior \(UC\) edge of \(R\) is \(\bar q\)-owned. Otherwise \(\bar q\) takes a \(ZY\) edge at **both** ends of that \(UC\) edge. At most one of these can be the terminal-\(3\) semiedge; hence at least one is proper. It must lie on \(P\) to avoid a third exterior \(\bar p\cap\bar Z^1\) collision, yet no edge of \(E_0\) meets an interior vertex of \(R\). This contradicts no new proper \(P\)-contact. Thus each interior \(UC\) edge has \(K\)-load one, while every \(Dr\) edge of \(R\) has \(K\)-load two. Starting with \(D'(k_a)=1\), matchinghood successively assigns \(q',r'\) to the first \(Dr\) edge, \(D'\) to the next \(UC\) edge, and so on. It ends with \(D'(k_d)=1\). Therefore
\[
\boxed{D'\text{ owns }k_a,k_d\text{ and every interior }UC\text{ edge of }R;
\quad q',r'\text{ both own every interior }Dr\text{ edge}.}       \tag{42}
\]
In particular the \(D_5\triangle D'_5\) component containing \(k_a\) contains one fixed alternating subpath from \(A\) through the interior of \(R\) to the other far end \(D_*\). It is a **proper closed cycle** because \(D,D'\) have the same singleton-\(5\) boundary. Its complementary \(A\)-to-\(D_*\) path starts with the original \(D=C\) edge at \(A\). If \(D_*\) is of right type \(23\), it ends with the other original \(D=C\) edge, on the distinct tail of the open \(\bar q/C\) component \(L\); a direct \(A D_*\) edge would close \(L\). If \(D_*\) is of original type \(13\), it ends with the original \(D=r\) edge, so a single direct \(D\)-edge is impossible by its incompatible owner pair at \(A\). In either case the complementary return has odd length at least three. Hence a fixed-fibre confluence in either terminal docking requires this second, exterior \(D/D'\)-alternating return in addition to the forced return through \(R\). This is a prescribed full-matching phase, not proof that the confluence or a common seed is absent.

**The two far ends cannot both dock at the ten-cycle bridge.** The same no-new-contact hypothesis makes the entire interior \(a\)-to-\(d\) return \(R_{a,d}\) a contiguous subpath of the original forced \(P_{23}=\bar q\triangle r\): its \(UC\) edges belong to \(\bar q\) and its intervening \(Dr\) edges to \(r\). At \(a,d\) this subpath continues through \(k_a,k_d\), so their far ends \(A,D_*\) lie on the two opposite outer pieces of the **same simple open** \(P\). The already established block \(W=k\cup M\cup(g_w,xy,g_o)\) is another contiguous subpath of \(P\), joining its two \(DC\)-bridge ends \(n,m\). If \(A,D_*\) had \(\bar B=r\) edges to \(n,m\) in either order, the two paths
\[
a\leadsto d\text{ along }R_{a,d},\qquad
a-k_a-A-(\bar B=r)-\{n,m\}-W-\{m,n\}-(\bar B=r)-D_*-k_d-d
\]
would be distinct subpaths of the same simple \(P\) with the same ends. This is impossible. Therefore
\[
\boxed{\text{under (39)'s no-new-contact hypothesis, at most one of }A,D_*
\text{ can dock by a }\bar B=r\text{ edge at }n\text{ or }m.}       \tag{43}
\]
One \(F\)-bridge docking and a different continuation of the other far end remain possible; (43) is independent of whether the open \(L\) puts \(j_\times\) on its terminal-\(1\) or terminal-\(3\) tail.

**Two direct terminal dockings cannot coexist.** The same simple-path trace also excludes the case where one of \(A,D_*\) is the terminal-\(2\) vertex and the other's \(\bar B=r\) edge directly meets the terminal-\(3\) vertex. At terminal \(2\), the \(r=\bar B\) semiedge enters the far end and \(\bar q\) takes its \(k\)-edge. At terminal \(3\), the \(r=\bar B\) edge from the other far end is followed by the \(\bar q\) semiedge. As \(R_{a,d}\) is a contiguous \(P\)-subpath, these edges exhaust the unique \(2\leftrightarrow3\) open \(P\)-component:
\[
2\;\xrightarrow{r}\;\{A,D_*\}\;\xrightarrow{k}\;
R_{a,d}\;\xrightarrow{k}\;\{D_*,A\}\;\xrightarrow{r}\;3.
\]
But the separate block \(W=k\cup M\cup(g_w,xy,g_o)\) is also a nonempty contiguous subpath of \(P\), disjoint from this displayed route in the \(|M|=5\) profile. Hence
\[
\boxed{\text{one return far end at terminal }2\text{ and the other directly }
\bar B=r\text{-adjacent to terminal }3\text{ is impossible}.} \tag{43a}
\]
This excludes a pure double terminal docking. A single direct terminal docking may still coexist with one \(F\)-bridge docking or with the type-13 continuation in (47).

There is a sharper finite consequence when exactly one far end docks at \(n\) or \(m\) **and the other far end is on a right type-23 strand** (or is the terminal-\(2\) vertex). The block \(W\) then lies entirely on that far end's outer piece of \(P\). At an internal right type-23 far end, a \(\bar B=r\) step must be followed by a \(\bar q\)-owned \(P\)-edge. All proper edges of \(E_0\) except \(k_a,k_d\) lie on \(W\). A step back into \(W\) would join the two outer pieces of the same simple \(P\). The \(k\)-edges cannot serve as the next edge either: their return ends \(a,d\) have no incident \(\bar B=r\)-owned \(Ur\) edge, and a step to the other far end is excluded by (35a). Under the no-new-contact hypothesis the only remaining continuation is therefore a boundary docking:
\[
\boxed{\text{one }F\text{-bridge docking, other far end of right type }23,
\text{and no new proper }P\text{-contact}
\Longrightarrow\text{the other far end is the terminal-}2\text{ vertex,
or its }\bar B=r\text{ edge meets the terminal-}3\text{ vertex}.}       \tag{44}
\]
The implication does not say that either mixed docking extends to a complete exact-support pole. A type-13 far end has a \(\bar B=C\)-owned \(UC\) continuation instead of the \(\bar B=r\) step; (44) makes no assertion about it.

Within (44)'s right-type-23 subcase, the mixed docking has one further boundary fork. Suppose \(A\) docks by its \(\bar B=r\) edge at \(n\), the argument being symmetric if it docks at \(m\). The forced simple \(P\) then traverses the full contiguous block \(W\) from \(n\) to \(m\). The opposite bridge end \(m\) may itself be the terminal-\(2\) vertex; in that case \(P\) ends there through its \(r=\bar B\) semiedge, and (44) forces the other return far end to be \(\bar B=r\)-adjacent to the terminal-\(3\) vertex. If \(m\) is internal, \(P\) continues through its \(r=\bar B\)-owned \(Ur\) edge. At the other endpoint the following \(\bar q\)-edge lies on \(P\). An original split type-23 endpoint would require a \(\bar q\)-owned exterior \(ZC\) edge, excluded at \(J'=5\) by Note 151; hence a proper next edge would be \(ZY\)-owned. Such an edge would be a new \(ZY\) contact: every proper edge of \(E_0\) is already on \(W\) or is one of the used return exits, and a simple \(P\) cannot revisit either. Therefore the next edge is the terminal-\(3\) semiedge. Now \(r\) already meets terminal \(3\) from \(m\), so the other return far end cannot also dock there and (44) makes it the terminal-\(2\) vertex. Summarizing,
\[
\boxed{\begin{aligned}
&\text{one }F\text{-bridge docking, other far end of right type }23,\\
&\text{no new proper }P\text{-contact}\Longrightarrow\\
&\quad(m=\text{terminal }2,\ D_*\xrightarrow{\bar B=r}\text{terminal }3)\\
&\qquad\text{or }(m\xrightarrow{\bar B=r}\text{terminal }3,\ D_*=\text{terminal }2).
\end{aligned}} \tag{45}
\]
These two mixed port patterns are necessary, not realizations. A terminal-\(2\) bridge end cannot be silently treated as internal: its \(r\)-semiedge is precisely the first case. Whether either pattern admits the prescribed full-fibre phase of (42) or a common seed remains open.

The Note 151 step in (45) uses the **original** right row with \(J'=5\). The normalization switches only original type-12 components, leaving the relevant exterior type-23 edge choice unchanged. The normalized right row may have more than five junctions; no minimal-junction claim is made for it.

**Terminal \(2\) on the terminal-\(3\) tail has no fixed-fibre common path.** The following applies to the second mixed pattern in (45) and also to a pure terminal docking: assume the terminal-\(3\)-tail far end \(D_*\) is the terminal-\(2\) vertex. The terminal-\(1\)-tail far end may dock at \(F\) or directly at the terminal-\(3\) vertex. This does not rule out a common \(B_2+C_4\) seed by another mechanism.

The \(C\)-edge at \(D_*\) starts the terminal-\(3\) tail of the simple open \(L=\bar q\triangle C\). None of the displayed \(E_0\) proper \(ZY\) edges is available on the *interior* of this tail: \(k_a,k_d,j_\parallel\) lie on the middle passage, \(j_\times\) lies on the terminal-\(1\) tail, and \(k,g_w,g_o\) lie on the disjoint closed component \(F\). By the no-new-contact assumption and the exact two-collision hypothesis, \(\bar q\) has no other proper \(ZY\) exit on this tail; an exit on \(Q\) or a closed \(\bar q\triangle r\) component would be a third exterior collision. The tail consequently follows \(C\)-owned \(DC\) edges alternating with \(\bar q=r\)-owned \(Ur\) or normalized \(Zr\) edges until it reaches the terminal-\(3\) vertex. Every interior vertex of that corridor belongs to \(V_0\): its \(\bar B\)-edge is \(ZY\subseteq Y\), or \(UY\subseteq Y\) at a normalized original type-12 vertex.

Any fixed-fibre Note-131 common path starts at the terminal-\(2\) vertex \(D_*\) along its \(\bar B=r\) semiedge. To avoid the return vertex \(d\in V_0\), its \(q'\)-edge there must be the displayed \(C\)-edge by the argument of (41). If that edge reaches an interior corridor vertex, (40) forbids the path. If it reaches terminal \(3\) directly, then \(q'\) cannot own it because its class-\(25\) boundary already forces the terminal-\(3\) semiedge at that vertex. Therefore
\[
\boxed{\begin{aligned}
&D_*=\text{terminal }2\text{ on the terminal-}3\text{ tail}\\
&\Longrightarrow\text{no Note-131(9) path in any fixed }
(\bar B_2,Y_3,C_4)\text{ right fibre}.
\end{aligned}}       \tag{46}
\]
The first mixed pattern, in which the opposite bridge end itself is terminal \(2\), can leave that vertex through a different \(C\)-corridor and is not covered by this barrier. A terminal-\(1\)-tail far end at terminal \(2\) is also outside (46); its opposite far end cannot dock directly at terminal \(3\) by (43a), while a type-13 continuation is treated in (47)--(48). These statements do not settle the full exact-Case-XII closure or the common-seed question.

**A type-13 far end must lie on the terminal-\(3\) tail and attach directly to terminal \(3\).** This is the branch omitted from (44) and also justifies the right-type-23 or terminal-\(2\) alternatives for the terminal-\(1\)-tail far end in (39). Suppose one far end of \(k_a,k_d\) has original incident owners \(UC,Dr,ZY\). The edge \(k_a\) or \(k_d\) is \(\bar q=ZY\), while \(\bar B=C\) use its \(UC\) edge. The corresponding tail of the open \(\bar q/C\) component \(L\) follows that \(UC\) edge. Its continuation cannot lie on \(\Theta\), whose owner list has no exterior \(UC\) port in this pattern, or on the disjoint component \(F\). It also cannot visit the simple middle passage of \(L\) again. At the next original type-13 vertex, \(\bar q\) uses its \(ZY\) edge: it cannot use the entering \(UC\) edge because \(\bar q\) avoids it at the far end, and the carrier equality \(\bar q+\bar B=U+Z\) gives only \(UC\) or \(ZY\) as its local choices. A proper \(ZY\) exit would have to lie on \(P\) by the two-collision condition, but none of the available \(E_0\) edges is incident to an unvisited type-13 vertex on this tail. The no-new-contact condition excludes every other one. The next \(ZY\) edge is therefore a semiedge. Only terminal \(3\) has original owner pair \(ZY\); terminal \(1\) has owner pair \(Ur\). Thus a type-13 far end cannot be on the terminal-\(1\) tail, and if \(D_*\) is on the terminal-\(3\) tail it has one \(UC\) edge directly to the terminal-\(3\) vertex:
\[
\boxed{D_*\text{ of original type }13\text{ on the terminal-}3\text{ tail}
\Longrightarrow D_*\xrightarrow{\bar B=C=UC}\text{the terminal-}3\text{ vertex}.} \tag{47}
\]
This permits a direct \(\bar B\)-continuation of the old \(q/\bar B\) path to terminal \(3\), but its edge has \(K\)-load zero. In fact this terminal incidence decides the fixed-fibre confluence test. In any fixed \((\bar B_2,Y_3,C_4)\) right row, the class-\(25\) matching \(q'\) owns the terminal-\(3\) semiedge. A Note-131 path ending there must use the unique \(\bar B\)-edge at the terminal-\(3\) vertex as its preceding \(r'\)-phase edge, by (40a). Equation (47) makes that edge common to \(\bar B,C\), so \(K\) gives it zero load and no triple matching can own it. Therefore
\[
\boxed{\bar B\cap C\text{ at the terminal-}3\text{ vertex}
\Longrightarrow \mathcal F(q',\bar B,r')=\varnothing
\text{ for every fixed-fibre right row};
\text{ in particular, (47)'s type-13 docking has no such confluence}.} \tag{48}
\]
This endpoint obstruction uses complete fixed singleton masks and is independent of the interior return phase (42). As in (46), it excludes only Note 131's sufficient common-path mechanism; it does not rule out a common \(B_2+C_4\) seed by another mechanism.

**A remaining terminal-\(2\) docking has a one-edge entry gate.** Suppose instead that the terminal-\(1\)-tail far end \(A\) itself is terminal \(2\), while the other far end has a nondirect continuation compatible with (43a). If some right row in the fixed \((\bar B_2,Y_3,C_4)\) fibre satisfies Note 131(9), its path starts at \(A\) along the \(\bar B=r\) semiedge and must take the \(C\)-owned \(DC\) edge \(Ax\), by (40)--(41). The vertex \(x\) cannot be in \(V_0\). Along this terminal-\(1\) tail of the simple open \(L\), every intermediate \(DC/(Ur\text{ or }Zr)\) corridor vertex lies in \(V_0\); \(w\) and the terminal-\(1\) vertex do as well. The terminal-\(3\) vertex cannot occur on a terminal-\(1\) tail of a simple open \(1\leftrightarrow3\) path. No displayed \(ZY\) contact on another component, on the middle passage of \(L\), or on the disjoint ten-cycle \(F\) can be \(x\). Under no new proper \(P\)-contact, the only remaining tail contact is the terminal-\(2\)-strand endpoint of \(j_\times\). At that vertex \(\bar B=r\) owns the \(Ur\) edge and the three edges of \(K\) have load one. The path and matchinghood therefore force
\[
\boxed{A=\text{terminal }2\text{ and fixed-fibre Note-131 confluence}
\Longrightarrow Ax=C=DC\text{ with }x\in V(j_\times),\quad
D'(j_\times)=1.} \tag{49}
\]
Here \(x\) is specifically the endpoint on the terminal-\(2\) strand; the other endpoint lies on the \(w\)-strand. The exterior return of the same proper \(D\triangle D'\) cycle from (42) begins \(A\xrightarrow{D=DC}x\xrightarrow{D'=j_\times}\) and therefore contains \(j_\times\) as well as both \(k\)-exits. This is a necessary complete class-five phase, not an assertion that such a matching extends globally or produces a common seed.

Under the standing no-seed hypothesis, Note 131 already makes every confluence premise in (41)--(42) and (49) false. Those equations identify what a *positive* fixed-fibre repair would require; only the unconditional docking restrictions (43a), (47) and the endpoint obstruction (48) narrow the no-seed geometry here. None decides the full exact Case-XII question.

**A direct right-type-23 terminal-\(3\) docking is a neutral complete phase.** Suppose the terminal-\(3\)-tail far end \(D_*\) is of right type \(23\) and its \(\bar B=r\)-owned \(Ur\) edge is \(b=D_*v_3\), where \(v_3\) is the terminal-\(3\) vertex. Retain the open-\(L\), both-jumps and no-new-proper-\(P\)-contact assumptions. Let \(T\) be the proper \(D_*\)-to-\(v_3\) subpath of the terminal-\(3\) tail of \(L=\bar q\triangle C\), excluding \(k_d\) and the terminal semiedge. It begins and ends with \(C=D\)-owned \(DC\) edges. It has no additional proper \(\bar q\)-owned \(ZY\) exit: the displayed contacts lie on the middle passage, the terminal-\(1\) tail or the disjoint \(F\), and another contact on \(Q\) or a closed \(\bar q\triangle r\) component would violate the two-collision hypothesis. Thus every internal \(\bar q\)-edge of \(T\) is also \(r\)-owned, of type \(Ur\) or normalized \(Zr\).

The direct edge \(b\) is the final \(r\)-edge of the old forced \(P_{23}=\bar q\triangle r\); its other endpoint has the \(\bar q\)-owned terminal-\(3\) semiedge. At every vertex of \(T\cup b\), the two edges of the circuit have owners \(C=D\) and \(r=\bar p\), respectively. On \(T\), the \(r\)-edges are shared by \(\bar q,r\) and avoided by \(P\); on \(b\), \(\bar q=0\) and \(b\subset P\), so \(\bar p=r\) there too. Consequently \(H=T\cup b\) is one proper even component of **both** \(C\triangle r\) and \(\bar p\triangle D\), with \(E(H)\cap E(\bar q\triangle r)=\{b\}\). Switch the complete \(C,r\) pair on \(H\), obtaining \(C^H=C\triangle H\), \(r^H=r\triangle H\). The resulting row keeps the literal \(\bar q,\bar B,D,Y\) masks, and its forced path replaces \(b\) by \(T\). Its canonical cross-half triple is therefore
\[
\boxed{P^H_{23}=P_{23}\triangle H,\qquad
\bar p^H=\bar p\triangle H,\qquad
\operatorname{pairing}(\bar p^H\triangle D)
=\operatorname{pairing}(\bar p\triangle D).} \tag{50}
\]
The final equality holds because \(H\) was already a **closed** \(\bar p\triangle D\) component. In the original right paired network, \(H\) is the entire closed type-23 strand carrying \(b\); a direct terminal-\(3\) docking cannot lie on either open right strand from a core port to \(w\) or terminal \(2\). The switch makes \(C^H\) use \(b=\bar B\) at terminal \(3\), so the new fixed \((\bar B,Y,C^H)\) fibre has the endpoint barrier (48). This exact full-mask switch explains why a direct \(\bar B=r\) docking at terminal \(3\) does not by itself contradict the no-seed pairing gate. It is not a realization of full exact Case XII.

The original \(J'=5\) row leaves only the junction \(w\) outside \(\Omega\). An internal original inactive \(Ur,ZY,DC\) vertex of \(H\) with \(\bar q=r=Ur\) would be another right-row junction, because the normalization leaves that vertex unchanged; \(w\) cannot lie on this closed terminal-\(3\) tail. Hence **every internal vertex of \(H\) is an original type-12 \(UY,Zr,DC\) vertex**, normalized to \(\bar q=r=Zr\). In particular the \(r\)-phase of \(H\) has one \(Ur\) edge \(b\) and otherwise only \(Zr\) edges. For a simple pole of girth at least five, \(H\) cannot be a four-cycle, so it has at least six edges and at least four such original type-12 vertices. This is a conditional order cost, not an existence claim.

The simultaneously normalized Tait anchor \(\bar A\) also agrees with \(r\) on \(H\): on \(b\), \(\bar A=U=r\); on the internal original type-12 \(Zr\) edges, the \(A/Z^1\) normalization makes \(\bar A=Z=r\); on the \(DC\) edges all three masks \(\bar A,\bar p,r\) vanish. Therefore
\[
\boxed{\bar A|_{E(H)}=\bar p|_{E(H)}=r|_{E(H)},\qquad
E(H)\cap E(\bar A\triangle\bar p)=\varnothing.} \tag{51}
\]
The closed strand cannot be the pairing-critical \(\bar A/\bar p\) component demanded by no-seed. Its available \(C/r\) switch is neutral for \(D\) by (50), so an exclusion of this docking must use a different part of the complete matching family.

**The direct \(B=r\) docking has a complete-row normal form.** The switch on \(H\) preserves the data used to enter this branch. It fixes \(\bar q,\bar B,D,Y,\bar A,\bar Z^1\) and the disjoint ten-cycle \(F\), and changes the canonical \(P\) only on \(H\). Since \(H\) has no \(\bar q\)-owned proper \(ZY\) edge, the seven displayed contacts \(E_0\) remain exactly the proper \(\bar q\)-owned \(ZY\) contacts of \(P^H\). On \(H\), both \(\bar p\) and \(\bar p^H\) avoid \(\bar Z^1\): at the two inactive type-23 ends \(\bar Z^1=ZY\), while at the internal normalized type-12 vertices \(\bar Z^1=UY\), disjoint from both the old \(Zr\) phase and the new \(DC\) phase. Thus the two-collision profile is unchanged. The open \(\bar q/C\) component replaces its terminal-\(3\) tail \(T\) by the direct edge \(b\) in \(\bar q/C^H\); both \(M\)-jumps stay on that same open component.

The \(q/B\) normalization is a switch on closed original type-12 \(Z\triangle Y\) components and changes neither \(C,r\) nor the edge set \(H\). It therefore commutes with the \(C/r\) switch on \(H\). Undo that normalization **only when counting the original right-paired network**. Every internal vertex of \(H\) is then inactive: \((q,Y)=(UY,UY)\), \((B,C^H)=(Zr,Zr)\), and \((D,r^H)=(DC,DC)\). The two ends are inactive as well. No other vertex changes paired type, so the original aligned \(J'=5\) count is retained. The all-\(S\) row is retained because \(r+C=r^H+C^H\) edgewise. In contrast, \(E_0,F,\bar p\cap\bar Z^1\), and the terminal pairing in (50) belong to the **normalized** row after the switch. The unnormalized row's canonical \(q\triangle r^H\) path is not claimed to be \(P^H\). These two commuting representations give the replacement rule
\[
\boxed{\begin{gathered}
D_*\xrightarrow{\bar B=r}v_3\quad\leadsto\quad
D_*\xrightarrow{\bar B=C^H}v_3,\\
\text{normalized: same }(\bar q,\bar B,D,Y),\ E_0,\ F,
\ \bar p\cap\bar Z^1\text{ outside }\Theta,
\text{ and }5\text{-partner of }\bar p+D;\\
\text{unnormalized: same original aligned }J'=5.
\end{gathered}} \tag{52}
\]
The left-hand docking is therefore not an independent obstruction under complete matching closure: it has a right-row representative with a \(B=C\) edge at terminal \(3\). This representative has no Note-131 fixed-fibre common path by (48). The replacement does not prove absence of a common seed or exclude a genuine exact-Case-XII pole.

Equivalently, fix the complete \(U,Z,D,Y,q,B\) masks and choose, among the aligned \(J'=5\) right rows reachable by proper \(C/r\) switches, one with the fewest active right-paired edges. The \(q/B\) normalization never changes \(C,r\), so \(H\) is the same proper \(C/r\) cycle before and after that normalization. Such an extremal row cannot display the direct terminal-\(3\) \(B=r\) docking above: the \(H\)-switch leaves all six fixed masks and \(J'\) as stated, but removes every edge of the closed type-23 strand \(H\) from the right paired differences without activating an edge elsewhere. This is a valid minimal-active normal form for this branch, not a proof that every normalized row has a common seed.

**The terminal-\(3\) zero-load barrier is not stable under fixed-\(B\) right-row closure.** The following uses the actual full-mask involution of [Note 129](../notes/129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md), not an abstract boundary relabelling. Work in the normalized switched row above and abbreviate \(C^H,r^H\) by \(C,r\). At the terminal-\(3\) vertex \(v_3\), let \(s_3\) be its semiedge and \(d\) its third incident edge. The three local occurrence pairs are
\[
  s_3:\{\bar q_{25},Y_3\},\qquad
  b:\{\bar B_2,C_4\},\qquad
  d:\{D_5,r_{34}\}.                                      \tag{53}
\]
The first switch in Note 129 sends \(\bar q_{25}+D_5\) to \(q_{24}+C_4^*\) along its forced terminal-\(5\)-to-\(4\) component. Since \(\bar q\) owns \(s_3\) and \(D\) owns \(d\), the vertex \(v_3\) lies on the **other**, terminal-\(3\)-to-\(1\) component; hence \(q_{24}\) still owns \(s_3\) and \(C_4^*\) owns \(d\) there. Exchange the two complete class-four occurrences \(C_4^*,C_4\). The second forced switch sends \(q_{24}+C_4\) to \(q^{\rm new}_{25}+D^{\rm new}_5\) along its terminal-\(4\)-to-\(5\) component. At \(v_3\), \(q_{24}\) still owns \(s_3\) and \(C_4\) owns \(b\), so this vertex is again on the other, terminal-\(3\)-to-\(1\) component. The resulting actual right row fixes the complete \(\bar B_2,Y_3,r_{34}\) masks and has local pairs
\[
  s_3:\{q^{\rm new}_{25},Y_3\},\qquad
  b:\{\bar B_2,D^{\rm new}_5\},\qquad
  d:\{r_{34},C_4^*\}.                                    \tag{54}
\]
Consequently the complete right \(B+C\) spectrum contains two **distinct** vectors in one fixed-\(B\) fibre: their restrictions to \((b,d)\) are \((2,0)\) and \((1,1)\). In the first fibre \(K=2\mathbf1-\bar B-Y-C\) has \(K(b)=0\), giving (48). In the second fibre \(K^*=2\mathbf1-\bar B-Y-C_4^*\) has \(K^*(b)=K^*(d)=K^*(s_3)=1\); the endpoint zero-load obstruction is gone. Its displayed row still fails Note 131(9) at \(v_3\), because \(r_{34}\) owns \(d\) rather than \(\bar B\)'s edge \(b\).

There is an exact smaller phase test if the three complete masks \((q^{\rm new},\bar B,Y,C_4^*)\) are held fixed. Then the residual pair load \(r_{34}+D^{\rm new}_5\) has one open terminal-\(1\)-to-\(2\) component and proper closed alternating components; the terminal-\(5\) semiedge is doubled. A same-boundary decomposition of this **fixed pair load** can put its \(r_{34}\) colour on \(b\) at \(v_3\) if and only if the \(r_{34}\triangle D^{\rm new}_5\) component through \(v_3\) is closed. On an open component, its terminal labels fix the two phases; on a closed component they may be switched. Even in the closed case, the full Note-131 condition additionally requires every \(r\)-phase edge of the forced \(q\triangle r\) terminal path to belong to \(\bar B\), by (40a). Allowing \(q\) to change within the larger fixed-\((\bar B,Y,C_4^*)\) fibre is a separate question.

**The phase test is positive for the particular closed strand \(H\).** In the switched normalized row (53), the terminal-\(3\) vertex starts the \(\bar q_{25}\triangle D_5\) component along the \(D\)-owned edge \(d\). At every internal vertex of \(T\subset H\), \(\bar q\) takes its old \(Zr\) edge and \(D\) takes its \(DC\) edge. The component therefore follows the whole \(T\) to \(D_*\), then takes \(\bar q\)'s return exit \(k_d\). Since the first Note-129 switch is on the *other* terminal-\(5\)-to-\(4\) component, \(q_{24}=\bar q\) and \(C_4^*=D\) on every edge incident with \(H\). After the class-four occurrence exchange, \(q_{24}\) and the old \(C=C^H\) both own each internal \(Zr\) edge of \(H\); they avoid its \(DC\) edges. Their difference uses only the direct edge \(b\) of \(H\), joining the return exit at \(D_*\) to the terminal-\(3\) semiedge at \(v_3\). That edge lies on the terminal-\(1\)-to-\(3\) component, while the second Note-129 switch is forced from \(4\) to \(5\). Hence the second switch also leaves all of \(H\) untouched. In the new right row (54),
\[
q^{\rm new}|_{E(H)}=\bar q|_{E(H)},\qquad
D^{\rm new}|_{E(H)}=C^H|_{E(H)},\qquad
C_4^*|_{E(H)}=D|_{E(H)},
\tag{55}
\]
where the \(C^H\) on the right is the post-\(C/r\)-switch mask of (50), before the abbreviation preceding (53). As \(r^H\) is the complementary phase of \(C^H\) on \(H\), the whole \(H\) is a **closed component of \(r^H\triangle D^{\rm new}\)**. Switch these two complete matchings on \(H\), preserving \((q^{\rm new},\bar B,Y,C_4^*)\) and the complete right-row load. The resulting class-\(34\) triple owns \(b=\bar B\) at \(v_3\), and its forced \(q^{\rm new}\triangle r'\) path again enters terminal \(3\) directly across \(b\). Thus this concrete full-closure sequence removes the endpoint obstruction (48) even with \(\bar B\) fixed. It does **not** establish the full Note-131 path criterion: its \(r'\)-phase on the rest of the forced path may leave \(\bar B\).

The complete-mask algebra isolates the change outside \(H\). Let \(F_{54}\) be the first Note-129 \(\bar q/D\) terminal path from \(5\) to \(4\), and let \(G_{45}\) be its second \(q_{24}/C^H\) terminal path from \(4\) to \(5\). After the last \(r^H/D^{\rm new}\) switch on \(H\), the four changed masks are exactly
\[
\boxed{q^{\rm new}=\bar q\triangle F_{54}\triangle G_{45},\qquad
C_4^*=D\triangle F_{54},\qquad
D^{\rm final}=C\triangle G_{45},\qquad r^{\rm final}=r.} \tag{56}
\]
Here \(C,r\) on the right are the masks **before** the first \(H\)-switch. Both \(F_{54}\) and \(G_{45}\) have the same terminal ends, so their symmetric difference is a union of proper even cycles. Equation (56) shows that repairing the terminal edge with this sequence keeps the original complete \(r\) mask and changes only the closed-cycle phase of \(q\).

**The first return edge defeats this particular three-switch repair.** Let \(\delta_d\) be the original \(Dr\) edge of the type-13 return \(R\) incident with \(d\), the return end of \(k_d=dD_*\). In the original complete right row, \(r(\delta_d)=D(\delta_d)=1\), so \(\bar B(\delta_d)=0\). The first Note-129 \(q/D\) switch avoids \(k_d\): the component through the terminal-\(3\) semiedge follows \(T\), then \(k_d\), while the switched component joins terminals \(5,4\). After the class-four exchange, the second \(q_{24}/C^H\) switch also avoids \(k_d\): its terminal-\(3\) component uses the direct \(b\) edge, then \(k_d\), while the switched component again joins \(4,5\). Hence \(q^{\rm new}(k_d)=1\). The last \(r^H/D^{\rm new}\) switch on \(H\) restores the **entire** old \(r\) mask, since \(r^H=r\triangle H\). At \(D_*\), the forced \(q^{\rm new}\triangle r\) path therefore uses \(b,k_d\); at \(d\), it must continue along \(\delta_d\). In symbols,
\[
\boxed{\delta_d\in E(P^{\rm new}_{23})\cap E(r)
\quad\text{but}\quad \delta_d\notin E(\bar B).}       \tag{57}
\]
This one proper edge violates the exact Note-131 containment (40a), so the displayed three-switch row has no common-path confluence, despite its repaired terminal edge. This says nothing about the common \(B+C\) seed by other rows or mechanisms.

The same edge gives a smaller **fixed-four-mask** decision test. After the three switches, hold \((q^{\rm new},\bar B,Y,C_4^*)\) and thus the complete pair load \(r+D^{\rm final}\) fixed. At \(d\), \(D^{\rm final}\) still uses the old \(C\)-owned \(UC\) edge \(dv\), since neither Note-129 path nor \(H\) changes that vertex on the terminal-\(3\) component. Thus \(\delta_d\) lies in \(r\triangle D^{\rm final}\). If this component is the open terminal-\(1\)-to-\(2\) path, the boundary classes fix its colours in every decomposition of the **fixed** pair load: \(r\) always owns \(\delta_d\). The separate closed component \(H\) may be switched or not, but either phase connects terminal \(3\) to \(D_*\) through \(b\) or \(T\), then through the fixed \(q^{\rm new}\)-edge \(k_d\) and the fixed \(r\)-edge \(\delta_d\). No row in this fixed-\(q^{\rm new}\) pair-load fibre has Note-131 confluence. If the component through \(\delta_d\) is closed, switching it removes \(\delta_d\) from \(r\) and changes the forced path; this is necessary to repair (57) within that fibre, but may leave other non-\(B\) \(r\)-edges on the path. The complete seed may also arise outside this fixed four-mask fibre.

**The return phase is indivisible in this pair-load fibre.** Write \(R_{a,d}\) for the portion of the original type-13 return between the return ends \(a,d\), and let \(\delta_a,\delta_d\) be its first and last \(Dr\) edges. Under the no-new-proper-\(P\)-contact assumption, \(\bar q\) uses every interior \(UC\) edge of \(R_{a,d}\); otherwise it would take an undisplayed proper \(ZY\) exit on \(P\). Thus the original \(\bar q/D\) component through terminal \(3\) follows \(T,k_d\) and then the entire alternating \(Dr/UC\) corridor \(R_{a,d}\). The first Note-129 path \(F_{54}\) avoids it. At every interior vertex of that corridor, \(q_{24}=\bar q=C^H=UC\), so the second path \(G_{45}\) also avoids the interior, regardless of whether it visits the endpoint \(a\). Equation (56) consequently gives
\[
q^{\rm new}=UC,\qquad D^{\rm final}=C=UC,\qquad r=Dr
\quad\text{at every interior vertex of }R_{a,d},
\tag{59}
\]
where the first two equalities denote the incident matching edge, and \(r=Dr\) denotes the alternating incident edge. At \(a,d\), \(r\) still owns \(\delta_a,\delta_d\); \(D^{\rm final}\) uses a different incident edge because the row is a six-cover and \(C_4^*=D\) still owns those old double-loaded \(Dr\) edges. Therefore \(R_{a,d}\) is a contiguous segment of **one** \(r\triangle D^{\rm final}\) component \(\mathscr R\), containing both \(\delta_a\) and \(\delta_d\).

The only same-boundary phases of the fixed pair load \(r+D^{\rm final}\) either leave \(\mathscr R\) unchanged or, if it is closed, switch **all** of it. If \(\mathscr R\) is the open \(1\leftrightarrow2\) component, every \(Dr\) edge of \(R_{a,d}\) remains \(r\)-owned and \(B\)-free, while the terminal-\(3\) \(q/r\) path follows the return from \(k_d\) toward \(a\); the whole fixed-four-mask fibre fails Note 131(9). If \(\mathscr R\) is closed, its switch changes \(r\) to the \(UC\) phase on the interior, where \(q^{\rm new}\) already owns \(UC\); the forced \(q/r\) path can no longer traverse that interior corridor. The exterior connection test below excludes this closed case under the full direct-docking hypotheses.

**The two return-end phases and a second forced path.** The first Note-129 path
\(F_{54}\) avoids not only the interior of \(R_{a,d}\) but also \(k_a\): its other
\(3\leftrightarrow1\) component enters the return through \(k_d\), traverses
\(R_{a,d}\), and leaves through \(k_a\). Thus \(C_4^*=D\) at both return ends.
The second path \(G_{45}\) avoids \(d,k_d\) and the return interior, but may
traverse \(a\). At \(a\), its only possible passage is \(k_a\cup ta\), since
\(q_{24}=k_a\) and \(C^H=ta\) there. The exact incidence after (56) is

| position | \(r=C_4^*\) | \(q^{\rm new}\) | \(D^{\rm final}\) | \(B,Y\) |
|---|---|---|---|---|
| \(a\), \(G_{45}\) avoids \(a\) | \(\delta_a\) | \(k_a\) | \(ta\) | \(ta,k_a\) |
| \(a\), \(G_{45}\) traverses \(a\) | \(\delta_a\) | \(ta\) | \(k_a\) | \(ta,k_a\) |
| \(d\) | \(\delta_d\) | \(k_d\) | \(dv\) | \(dv,k_d\) |
| every interior return vertex | \(Dr\) | \(UC\) | \(UC\) | \(ZY,ZY\) |

The entries name each matching's incident edge; the last column lists the
\(B,Y\) edges in that order. In particular the whole return is simultaneously
a segment of \(r\triangle D^{\rm final}\) and of
\(q^{\rm new}\triangle C_4^*\). The latter is **the open
\(3\leftrightarrow1\) component**: from terminal \(3\), its \(C_4^*=D\)
phase follows the old \(D\)-edges on \(T\), then its \(q^{\rm new}\) phase
uses \(k_d\), followed by \(\delta_d\) and the entire return. Its boundary
classes leave only terminal \(1\) as the other end. This does not determine
the component type of \(\mathscr R\). To decide it, delete the return from
\(r\triangle D^{\rm final}\) and trace the two exterior continuations:
the \(d\)-continuation starts with \(dv\), while the \(a\)-continuation
starts with \(ta\) if \(G_{45}\) avoids \(a\), or \(k_a\) if it traverses
\(a\). The component \(\mathscr R\) is closed exactly when these two
continuations meet; it is the open \(1\leftrightarrow2\) path exactly when
they reach those two terminals. Neither the local table nor Proposition 4.4's
boundary support supplies this exterior full-mask connection. This is a
conditional fixed-fibre statement, not a realization or an exclusion of an
exact-Case-XII pole.

If \(\mathscr R\) is closed and its complete \(r,D^{\rm final}\) colours are
switched, the new \(r'\)-edge at \(d\) is \(dv=B(d)\). At \(a\) it is
\(ta=B(a)\) when \(G_{45}\) avoids \(a\), but it is \(k_a=Y(a)\ne B(a)\)
when \(G_{45}\) traverses \(a\). Hence in the latter branch Note 131(9)
additionally requires the *new* forced \(q^{\rm new}\triangle r'\)
\(2\leftrightarrow3\) path to avoid \(a\). In the former branch both
return ends satisfy the local \(r'\subseteq B\) test. Neither branch
controls the rest of that forced path.

**The forced terminal-arm order selects the \(a\)-phase.** In the present
aligned \((2,1,2,1)\) short diamond of girth at least five, retain
\(|M|=5\), open \(L\), both jumps on \(L\), no new proper
\(P\)-contact, and the direct right-type-23 \(D_*\xrightarrow{B=r}v_3\)
docking. The portion of
\(L=\bar q\triangle C^H\) from \(h_s\) through \(j_\parallel\) to
\(h_u\) uses only right type-23 vertices with \(D=C^H=DC\). It is
therefore also one contiguous \(\bar q\triangle D\) passage. At its
ends \(t,v\), \(D=r\) uses the \(Dr\) edge on the original type-13
terminal arm. On either side of the return, every further internal
vertex of that arm has \(\bar q=UC,D=Dr\): a proper \(\bar q=ZY\)
exit on \(P\) would be a new contact, while one on \(Q\) or a closed
\(\bar q\triangle r\) component would be a third \(p\cap Z\)
collision. Hence the passage, followed from whichever of \(t,v\)
is closer to the arm's terminal \(\tau\in\{4,5\}\), reaches \(\tau\)
without leaving the arm. It is the open \(F_{54}\) component of
\(\bar q\triangle D\).

After switching \(F_{54}\), the \(q_{24}\triangle C^H\) path from the
return end nearer \(\tau\) follows the same terminal-side arm to
\(\tau\): on its internal vertices \(q_{24}=Dr\) and \(C^H=UC\).
If \(v\) were nearer \(\tau\), the component through terminal \(3\)
would reach \(\tau\), because it follows \(T,k_d,dv,v\) before taking
that arm. This contradicts Note 129's forced \(3\leftrightarrow1\)
pairing for \(q_{24}\triangle C^H\). Thus \(t\) is nearer \(\tau\).
The path through \(a,ta,t\) reaches \(\tau\), so it is the forced
\(4\leftrightarrow5\) component \(G_{45}\). In particular,
\[
\boxed{t\text{ is terminal-side of }v,\qquad
       k_a,ta\in E(G_{45}),\qquad
       D^{\rm final}(a)=k_a.}                            \tag{60}
\]
The \(a\)-continuation of \(\mathscr R\) is therefore \(k_a\), not
\(ta\), in this branch. Its \(d\)-continuation is \(dv\).
This determines the local phase. The bridge trace below determines
the component type in this direct-docking branch.

**The bridge forces the return component to be open.** By (39),
(43a), and (45), the other far end \(A\) must dock at one end \(n\)
of the \(DC\) bridge \(nm\), and its opposite end \(m\) is the
terminal-\(2\) vertex. Relabel the two bridge ends so that
\(r=A n\), \(D=C=nm\), \(\bar q(n)=k\), and
\(\bar q(m)=g_o\). The complete \(\bar q\triangle D\) path
through \(n\) takes \(k,nm,g_o\). The core owner sequence
\((UZ,rY,ZC,UY,rZ,YC)\) of Note 146 makes its continuation
independent of the two surviving right-port pairings:
\[
\begin{array}{c|l}
g_o=g_x & g_x,\ UD\text{ to }v_2,\ e_3,\ Dr
                  \text{ into the }v_3\text{ arm},\\
g_o=g_y & g_y,\ UD\text{ to }v_5,\ e_5,\
                  DC\text{ to }y_w,\ g_w=g_x,\
                  UD\text{ to }v_2,\ e_3,\ Dr
                  \text{ into the }v_3\text{ arm}.
\end{array}                                                \tag{61}
\]
If the return \(R\) lies on that arm, its core-side encounter is
\(v\), followed by \(h_u\), the middle \(q/D\) passage, \(h_s\),
and the terminal-side arm beyond \(t\). If \(R\) lies on the
other arm, the \(v_3\) arm has no proper \(\bar q=ZY\) exit:
every such exit would be an undisplayed \(P\)-contact or an extra
\(p\cap Z\) collision. In both cases the path through \(n\)
reaches a terminal in \(\{4,5\}\). It is therefore the forced
\(F_{54}\), not a closed \(\bar q\triangle D\) component.

At \(n,m\), switching \(F_{54}\) makes \(q_{24}=D=nm=C^H\);
the second path \(G_{45}\) avoids both vertices. Equation (56)
then gives \(D^{\rm final}(n)=D^{\rm final}(m)=nm\).
By (60), \(D^{\rm final}(a)=k_a\), and at the far end \(A\)
of \(k_a\) the same \(G_{45}\) switch gives
\(D^{\rm final}(A)=k_a\). Thus \(r\triangle D^{\rm final}\)
contains the literal continuation
\[
\boxed{a\xrightarrow{D^{\rm final}} A
       \xrightarrow{r} n
       \xrightarrow{D^{\rm final}}m
       \xrightarrow{r}\text{terminal }2.}                 \tag{62}
\]
The component \(\mathscr R\) containing the return is therefore
the unique open \(1\leftrightarrow2\) component. In the fixed
\((q^{\rm new},\bar B,Y,C_4^*)\) pair-load fibre its \(r\)-phase
cannot be changed; every return \(Dr\) edge on the forced
\(q/r\) path remains \(B\)-free. Hence this **entire fixed
four-mask fibre** fails Note 131(9), even after the \(H\)-phase
is repaired. Other right fibres and the full common-\(B+C\)
seed remain unclassified.

**The Note-139 singleton companion still reaches the return.** Apply
Note 139's occurrence exchange to the normalized row *after* the
\(C/r\) switch on \(H\), but *before* the Note-129 involution.
Its new actual right row is
\[
q'_{25}+B'_2+D_5+r^H_{34}+Z_3+C^H_4=2\mathbf1,
\qquad q'+B'=U+Y.                                      \tag{63}
\]
Here \(q'\) is obtained by switching the open
\(3\leftrightarrow2\) component of \(U\triangle Y\); the
complete \(D,r^H,C^H\) masks stay fixed. The terminal-\(3\)
end of that component follows the literal edges
\(s_3,b,k_d,dv\): at \(v_3\), \(Y=s_3,U=b\);
at \(D_*\), \(U=b,Y=k_d\); at \(d\),
\(Y=k_d,U=dv\). Consequently
\[
q'(D_*)=q'(d)=k_d,\qquad B'(d)=dv,\qquad
r^H(d)=\delta_d.                                        \tag{64}
\]

At every internal vertex of \(T\subset H\), the original
owners are \(UY,Zr,DC\), so \(U=Y=UY\). The switch
\(U/Y\) avoids that vertex and \(q'=U=UY\) there.
Each such vertex lies on a closed exterior original type-12
component of \(Z\triangle Y\). At all vertices of that
component, \(U=Y=UY\), so \(q'=UY\) throughout it.
On its vertices outside \(H\), \(r^H=r=Zr\);
on its vertices inside \(H\), \(r^H=DC\).
Thus the \(q'\triangle r^H\) edges in the union of \(T\)
and these type-12 phase cycles have degree two at every
internal vertex and only two exposed ends, \(v_3,D_*\).
The terminal-\(3\) component must reach \(D_*\), then
continue through \(k_d,\delta_d\) by (64). Since
\(B'(d)=dv\), \(\delta_d\notin B'\). Therefore
\[
\boxed{\delta_d\in E(P'_{23})\cap E(r^H)\setminus E(B'),
\quad\text{so the direct Note-139 companion row fails
Note 131(9).}}                                           \tag{65}
\]
This argument does not assert \(B'=B\) as a complete mask:
outside the displayed path, the class-two occurrence may
change on other components. It only shows that the
type-12 phase cycles traversed by \(H\) cannot route this
particular right row around the first return edge. It
does not exclude other right rows or a common \(B+C\) seed.

**A second complete-mask endpoint gate.** This statement needs no short
diamond or docking. Let any actual right row satisfy
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1,
\]
with no all-terminal and no \(T\)--\(T\) BF type. Perform the first
Note-129 switch, allowing any closed phases of the same two-colour load:
\[
q_{25}+D_5=q_{24}+\widehat C_4.                    \tag{66}
\]
If the open component of \(r_{34}\triangle\widehat C_4\) from terminal
\(4\) reaches \(2\), switch it to obtain
\(r_{34}+\widehat C_4=r_{23}+\widehat B_2\). Regroup the six literal
occurrences as
\[
(q_{24}+\widehat B_2+C_4)+(r_{23}+B_2+Y_3)=2\mathbf1.
\]
The first half has state \(24\in S\) and the second has state
\(23\in T\). The \(q_{24}\triangle\widehat B_2\) path from \(2\)
must end at \(1\): endpoints \(3,5\) would give first-half states
\(34,45\in T\). Its switch gives \(q_{14}+A_1\), hence an actual
left row with the **original complete** \(B_2,C_4,Y_3\) masks.

If the \(4\)-path instead reaches \(1\), its switch gives
\(r_{34}+\widehat C_4=r_{13}+A_1\). In the resulting actual row,
the \(q_{24}\triangle r_{13}\) path from terminal \(2\) must reach
\(1\). Reaching \(3\) would switch the two triples to states
\(34,12\in T\); reaching \(4\) would produce an all-terminal
matching. Switching the forced \(2\leftrightarrow1\) path gives
\(q_{24}+r_{13}=q_{14}+r_{23}\), again yielding
\[
\boxed{q_{14}+A_1+C_4+r_{23}+B_2+Y_3=2\mathbf1.} \tag{67}
\]
All identities hold on every edge, not only at the terminals. Thus
\[
\boxed{\Lambda_L\cap\Lambda_R=\varnothing
\quad\Longrightarrow\quad
\operatorname{pairing}(r_{34}\triangle\widehat C_4)
\text{ joins }4\leftrightarrow5}                         \tag{68}
\]
for **every** right row and every complete closed phase permitted in
(66). This is a sufficient seed gate in the other two endpoint cases;
the \(4\leftrightarrow5\) outcome does not assert absence of a seed.

**The direct terminal-3 docking selects the \(4\leftrightarrow5\)
outcome without assuming no seed.** Return to the post-\(H\)-switch
normalized row (53), and let \(\widehat C_4=D_5\triangle F_{54}\)
be the specific first Note-129 phase used in (56). The two surviving
right-port pairings (18) and the girth-five port placements (22)
give the following literal \(F_{54}=\bar q\triangle D\) passages.
The entries stop upon entering the two distinct type-13 terminal
arms at core vertices \(v_0,v_3\):

| right-port pairing | from \(m\) to the \(v_3\) arm | from \(n\) to the \(v_0\) arm |
|---|---|---|
| \((v_1w)(v_4 2)\), \(g_o=g_x,g_w=g_y\) | \(g_x,xv_2,e_3\) | \(k,zv_4,e_5,v_5y,g_y,y_wv_1,e_1\) |
| \((v_4w)(v_1 2)\), \(g_o=g_y,g_w=g_x\) | \(g_y,yv_5,e_5,v_4y_w,g_x,xv_2,e_3\) | \(k,zv_1,e_1\) |

The \(m\)-passage continues (61); the \(n\)-passage uses the
other side of the bridge \(nm\). Each row exhibits **both** chord
ports \(g_x,g_y\), including the port reached through \(y_w\).
Consequently \(F_{54}\) contains \(e_1=UZ\) and \(e_3=ZC\)
in both port pairings, and \(\widehat C_4\) owns both edges.
The unchanged \(r^H_{34}\) owns \(e_2=rY\). At the four core
vertices along \(v_0e_1v_1e_2v_2e_3v_3\), these two complete
matchings therefore alternate exactly as
\[
\boxed{v_0\xrightarrow{\widehat C_4:e_1}v_1
\xrightarrow{r^H:e_2}v_2
\xrightarrow{\widehat C_4:e_3}v_3.}                  \tag{69}
\]
At \(v_0,v_3\), \(r^H\) owns the \(Dr\) arm edge. On every
ordinary internal arm vertex traversed by \(F_{54}\),
\(r^H=D=Dr\), while the first switch makes
\(\widehat C_4=\bar q=UC\) on the arm passage. If the return
\(R\) interrupts one arm, (60)--(61) show that \(F_{54}\) uses
\(h_s,h_u\). The \(r^H\triangle\widehat C_4\) passage then
takes the literal detour \(h_s,su,h_u\), with \(r^H\) on \(su\)
and \(\widehat C_4\) on the two outer edges, before continuing
along that arm. This holds whether \(su\) is on the \(w\)-strand
or the terminal-\(2\) strand: \(H\) is disjoint from both and from
the type-13 arms. No further arm exit occurs under the stated
no-new-proper-\(P\)-contact and two-collision assumptions.
The two arms end at terminals \(4,5\), so (69) extends to one
open \(r^H\triangle\widehat C_4\) path joining them. The other
open path joins the remaining terminals \(1,2\):
\[
\boxed{\operatorname{pairing}(r^H_{34}\triangle\widehat C_4)
=(1\,2)(4\,5).}                                      \tag{70}
\]
There is a complete closed-phase consequence. Every vertex of the
displayed \(4\leftrightarrow5\) path belongs to the open component
\(F_{54}\) of \(\bar q\triangle D\). This includes \(v_1,v_2\),
although their connecting \(r^H\)-edge \(e_2\) is outside \(F_{54}\),
and includes \(s,u\), although their connecting \(r^H\)-edge
\(su\) is outside \(F_{54}\). Every proper closed component of
\(\bar q\triangle D\) is vertex-disjoint from \(F_{54}\).
Switching any collection of those components in both complete
matchings changes \(\widehat C_4\) only away from the displayed
\(4\leftrightarrow5\) path, leaving that entire component of
\(r^H\triangle\widehat C_4\) intact. With four terminal ends,
its unchanged partner also fixes the remaining pair. Hence
\[
\boxed{\text{For this fixed post-}\!H\text{ right row, every
closed phase of (66) has pairing }(1\,2)(4\,5).}       \tag{71}
\]
The inverse \(C/r\) switch changes \(r^H\) only on \(H\), which is
disjoint from this \(4\leftrightarrow5\) path, while \(\bar q,D\)
and their first-switch phase cube are unchanged. The same pairing
therefore holds for the corresponding pre-\(H\) normalized right row.
Other complete right rows, including the Note-139 singleton companion,
remain possible outlets. Equation (71) is not a no-seed proof.

**The companion changes the core phase, with one exact exterior test
left.** For the Note-139 row (63), the open \(3\leftrightarrow2\)
component of \(U_{35}\triangle Y_3\) starts at the terminal-\(2\)
vertex \(m\), where \(U\) owns the semiedge and \(Y\) owns
\(g_o\). Its forced route through the short theta core is
\[
\begin{array}{c|l}
g_o=g_x & m,g_x,x,v_2,e_2,v_1,e_1,v_0,e_6,v_5,y,g_y,y_w,\\
g_o=g_y & m,g_y,y,v_5,e_6,v_0,e_1,v_1,e_2,v_2,x,g_x,y_w.
\end{array}                                                \tag{72}
\]
Both routes are \(Y/U\)-alternating and reach the other chord port;
Note 139 forces their eventual other terminal end to be \(3\).
The open switch making \(q'_{25}\) therefore sets \(q'=Y\) at
every vertex on (72). At the remaining two core vertices
\(v_3,v_4\), \(U=Y=e_4\), so \(q'=Y\) on the *entire* theta
core. This is a literal incident-edge identity, unlike the original
aligned choice \(\bar q=Z\) on \(\Omega\).

The same \(U/Y\) path reaches \(n\) through the forced chain
\(s_3,b,k_d,dv,h_u,su,h_s,ta,k_a,An,k\) from (63)--(64);
thus \(q'(n)=q'(z)=k\), while \(q'(m)=g_o\) and
\(q'(y_w)=g_w\). Combining these fixed incidences with (72)
shows that **one** component of \(q'\triangle D\) joins the two
core arm ports \(v_0,v_3\), through the literal bridge \(nm\)
and both chord ports. On the core it uses \(e_6,e_2,e_4\),
whereas the original \(F_{54}\) uses \(e_1,e_3\).
Its continuation along the terminal arms is not determined by this
core trace: the \(U/Y\) open path may take additional \(Y\)-owned
edges on those arms, which the original \(\bar q\)-contact count
does not forbid. Thus (72) does not assign the terminal pairing
of \(r^H\triangle\widehat C'_4\), where
\(\widehat C'_4\) is obtained from the companion's first Note-129
switch. That exterior pairing is the next full-mask test for this
specific companion row, resolved under the same \(J'=5\) hypotheses
below.

There is nevertheless a sharp necessary escape from the same gate.
Assume that the forced \(3\leftrightarrow2\) component of
\(U\triangle Y\) has no **additional** visit to a type-13 arm
vertex where \(\bar q=U=UC\) and \(Y=ZY\), including the
terminal-\(5\) vertex if it has that incidence.
At all vertices on the two traced terminal-arm passages,
\(q'=\bar q\):
off that component \(q'=U=\bar q\), while at the displayed
\(h_s,h_u,k_a,k_d\) contacts the switch sets \(q'=Y=\bar q\).
The connected \(q'\triangle D\) passage of (72) therefore extends
from \(v_0,v_3\) along the original two arms to their distinct
terminals \(4,5\), using the same \(h_s,j_\parallel,h_u\) detour
on the arm with the return. It is the forced open \(F'_{54}\).
After its switch, \(\widehat C'_4\) owns \(e_6,e_4\), while
\(r^H\) owns \(e_5\). The \(r^H\triangle\widehat C'_4\)
path uses the complementary core arc
\[
v_0\xrightarrow{\widehat C'_4:e_6}v_5
\xrightarrow{r^H:e_5}v_4
\xrightarrow{\widehat C'_4:e_4}v_3,                 \tag{73}
\]
then follows the two arms, taking \(h_s,su,h_u\) if necessary.
Every vertex of this \(4\leftrightarrow5\) path lies on
\(F'_{54}\), so all of its first-switch closed phases preserve
the same pairing. Therefore
\[
\boxed{\text{A Note-139 companion phase with }4\to1\text{ or }4\to2
\Longrightarrow\text{the }U/Y\text{ open path visits an additional
ordinary type-13 arm vertex with }\bar q=U=UC,\ Y=ZY.} \tag{74}
\]
At such a vertex the \(ZY\) edge is literally shared by \(B,Y\)
in the original right row; this extra contact is not counted among
the \(\bar q\)-owned \(P\)-contacts. Equation (74) does not prove
that this contact can occur, or that it suffices to change the
pairing. It identifies the first full-mask exterior feature that
would be needed to let the direct Note-139 companion escape (71).

In fact a companion escape needs **at least two distinct** such
proper \(B\cap Y\) edges. The \(U/Y\) open path already has the
specified terminal-\(3\)-to-\(z\) segment through
\(h_u,su,h_s,k_a,k\) and the terminal-\(2\)-to-\(y_w\) segment
through (72); these segments are disjoint parts of one simple open
path. Any further visit to a type-13 terminal arm lies on its
remaining \(z\)-to-\(y_w\) segment. Neither endpoint \(z,y_w\)
is on a type-13 arm, and that segment cannot end at terminal
\(4\) or \(5\). It must enter and leave the arm union by two
distinct \(Y=ZY\) edges. At their arm endpoints \(\bar q=U=UC\),
so the carrier identity \(\bar q+\bar B=U+Z\) makes
\(\bar B=Z=Y\) on both edges. Thus
\[
\boxed{\text{Companion seed outlet via (67)}
\Longrightarrow\text{ at least two new proper }B\cap Y
\text{ arm-contact edges on the same }U\triangle Y
\text{ terminal path}.}                                \tag{75}
\]
The count concerns this one companion mechanism only. Other right
rows can have different identities and paths.

**The one exterior right junction forbids that companion escape.**
In fact the two extra contacts required by (75) cannot both occur
under the standing aligned \(J'=5\) hypotheses. Let
\(\mathscr A\) be the union of the original exterior type-13
strands with owner pairs \(UC,Dr,ZY\), together with the two
post-\(H\) endpoints of \(b\), now of owner type
\(UC^H,Dr^H,ZY\). It includes the two terminal arms and any
closed type-13 component. Before the \(H\)-switch the original
paired network has no junction outside \(\Omega\). Off \(H\)
its owners are unchanged, so a common \(UC^H\) edge at a
type-13 vertex cannot end at a different exterior type without
creating another original junction. On \(H\), the only common
\(UC^H\) edge is \(b\) between the two added endpoints; its
other internal vertices have \(U=Y=UY\) and \(C^H=Zr\).
Thus no **proper** common \(UC^H\) edge can leave
\(\mathscr A\). The terminal-\(4\) \(UC^H\) semiedge
belongs to the other open \(1\leftrightarrow4\) component of
\(U\triangle Y\), so the residual \(3\leftrightarrow2\)
path cannot use it.
A \(Dr^H\) edge is absent
from \(U\triangle Y\). The residual \(z\)-to-\(y_w\) segment
of the open \(U\triangle Y\) path can therefore enter or leave
\(\mathscr A\) only on an undisplayed \(Y=Z\) edge.

At the \(\mathscr A\)-endpoint of such an edge outside the already
traced terminal-\(3\)-to-\(z\) segment, the no-new-proper-
\(P\)-contact and two-collision assumptions make
\(\bar q=U=UC\) and
\(\bar B=Z=Y\). The latter complete matching identity holds
at the other endpoint too. If that endpoint were outside
\(\mathscr A\), then \(D\ne r^H\) there: equality \(D=r^H\),
together with the \(ZY\) edge, would force the third owner
pair \(UC^H\), placing the vertex in \(\mathscr A\). Since
\(\bar q\ne Y\), \(\bar B\ne C^H\), and \(D\ne r^H\)
at the exterior endpoint, it is a junction of the right paired
network \((\bar q,Y),(\bar B,C^H),(D,r^H)\). The \(q/B\)
normalization changes only exterior original type-12 vertices,
where \(U=Y\) and no \(ZY\) edge occurs; at the crossing endpoint
the current row is therefore identical to the unnormalized row.
Equation (52) gives that latter post-\(H\) right network exactly
one junction outside \(\Omega\), namely \(w\). A perfect matching \(Y\)
has only one incident edge at \(w\), so at most one such crossing
edge can exist. The simple residual path has both endpoints
\(z,y_w\) outside \(\mathscr A\), does not revisit the already
traced contacts or theta core, and cannot end on either terminal
arm. Every excursion into \(\mathscr A\) would require two
distinct crossing edges. There is no excursion.

Consequently the extra contacts in (74)--(75) are impossible,
the companion agrees with \(\bar q\) along both traced arms,
and (73) extends to a literal \(4\leftrightarrow5\) path.
Every vertex of this path lies on the companion's open
\(F'_{54}\), so its first-switch closed phases are neutral as in
(71). Therefore the **direct Note-139 companion right row** also
satisfies
\[
\boxed{\operatorname{pairing}
(r^H_{34}\triangle\widehat C'_4)=(1\,2)(4\,5)
\quad\text{for every first-switch closed phase}.}       \tag{76}
\]
This closes the second endpoint gate for these two specific right
rows in the direct-docking branch. It leaves other right rows,
other complete singleton identities, and the full
\(\Lambda_L\cap\Lambda_R\) intersection unresolved.

**The Note-129 partner makes the original \(r/C\) pairing a seed
gate.** The second endpoint gate also applies in reverse to the
full Note-129 involution. From any right row \(R\), its first
switch gives (66); exchange \(\widehat C_4,C_4\) and perform
the second forced \(q_{24}/C_4\) switch to get a partner right
row \(R^I\) with the same complete \(B_2,Y_3,r_{34}\) masks
and class-four singleton \(\widehat C_4\). The first
\(q^{I}_{25}/D^{I}_5\) switch of \(R^I\) reverses that second
path and therefore recovers the **original complete \(C_4\)**.
Applying (67)--(68) to \(R^I\) gives the all-orders implication
\[
\boxed{\operatorname{pairing}(r_{34}\triangle C_4)
\text{ joins }4\leftrightarrow1\text{ or }4\leftrightarrow2
\quad\Longrightarrow\quad \Lambda_L\cap\Lambda_R\ne\varnothing.}
                                                               \tag{77}
\]
In particular no-seed forces \(r_{34}\triangle C_4\) to pair
\((1\,2)(4\,5)\) in **every** actual right row, alongside the
same requirement for \(r_{34}\triangle\widehat C_4\).

This reverse gate appears decisive for the *entire aligned
\((2,1,2,1)\), six-edge, \(J'=5\) short-diamond branch*, before
any return or docking specialization. Work in the original aligned
overlap row \(U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1\)
and its actual right row \(q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1\).
Let \(\tau_0,\tau_3\) be the terminals on the two original
type-13 arms from core vertices \(v_0,v_3\). Their set is
\(\{4,5\}\). The literal \(r_{34}\triangle C_4\) passages
through the short core are
\[
\tau_0\leadsto v_0\xrightarrow{C:e_6}v_5
\xrightarrow{r:e_5}v_4\xrightarrow{C:DC}j_{v_4},
\qquad
\tau_3\leadsto v_3\xrightarrow{C:e_3}v_2
\xrightarrow{r:e_2}v_1\xrightarrow{C:DC}j_{v_1}.
                                                               \tag{78}
\]
On either original type-13 arm, \(r,C\) alternate on the
\(Dr,UC\) edges, so the two displayed passages really start at
the stated terminals, including when a carrier return visits that
arm. On an exterior right type-23 strand, the only nonjunction
vertex types are the original inactive \((Ur,ZY,DC)\) and the
original type-12 \((UY,Zr,DC)\). In both, \(r,C\) follow its
\(Ur/DC\) or \(Zr/DC\) edges. The \(r/C\) passage entering
the strand paired to terminal \(2\) therefore follows it all
the way to the \(r\)-owned terminal-\(2\) semiedge; the unique
exterior right junction \(w\) is on the other strand.

The first right-port pairing \((v_1v_4)(w2)\) was excluded
under exact negative support in (17). For the two survivors,
(18) supplies the forced arm orientations:
\[
\begin{array}{c|c|c}
\text{right type-23 pairing}&\text{port paired to }2
                         &\text{arm on that port in (78)}\\\hline
(v_1w)(v_4 2)&v_4&\tau_0=5,\\
(v_4w)(v_1 2)&v_1&\tau_3=5.
\end{array}
\]
In either case, the **complete** \(r_{34}\triangle C_4\)
has an open path from terminal \(5\) to terminal \(2\).
Its remaining ends \(4,1\) are therefore paired:
\[
\boxed{\operatorname{pairing}(r_{34}\triangle C_4)
=(1\,4)(2\,5).}                                       \tag{79}
\]
Combining (77) and (79) gives a common complete
\(B_2+C_4\) seed (with the partner's class-four mask as the
shared one) in every such aligned short-diamond row, **provided
the port classification and forced orientation (17)--(18) hold**.
This argument uses neither the two-collision equality profile nor
the return geometry. The earlier no-seed deductions made inside
this aligned \(J'=5\) branch are consequently vacuous if the
present reverse gate and (17)--(18) survive independent checking.
Other Case-XII branches and the full conjecture remain open.

**The same crossing argument removes a second six-edge owner
pattern.** Among the four Note-146 sequences, the
\((1,2,1,2)\) pattern has
\[
(e_1,e_2,e_3,e_4,e_5,e_6)
=(rY,ZC,YD,rZ,YC,ZD).
\]
Its original type-13 arms attach at \(v_0,v_3\), with terminals
\(\tau_0,\tau_3\), and its right type-23 chord joins
\(v_1,v_4\). The other two right type-23 ports are \(v_2,v_5\).
The literal core traces, read from the displayed owner pairs and
the \(UC\) arm edges, are
\[
\begin{array}{c|cc}
 &\tau_0\text{ reaches}&\tau_3\text{ reaches}\\\hline
U\triangle D&v_5&v_2\\
r\triangle C&v_2&v_5.
\end{array}                                                \tag{80}
\]
For example, the \(r/C\) trace from the \(v_0\) arm uses
\(e_1,e_2\) before taking the \(Ur\) port at \(v_2\);
the other arm uses \(e_4,e_5\) before the \(Ur\) port
at \(v_5\). The \(U/D\) traces instead use \(e_6\)
and \(e_3\), respectively. At the exterior type-23 vertices,
\(U/D\) follows the same strands after the closed original
type-12 \(U/r\) normalization used in (17), while \(r/C\)
already follows them without that switch.

The port pairing \((v_2v_5)(w2)\) would make the normalized
\(U\triangle D\) join terminal \(1\) to \(2\); switching it
gives a forbidden \((34)(34)\) BF row exactly as in (17).
In either surviving pairing, negative support forces the
\(U/D\) \(5\)-path to end at \(1\) and its \(2\)-path to end
at \(4\). If \(v_2\) is paired to terminal \(2\), (80)
makes \(\tau_3=4,\tau_0=5\); if \(v_5\) is paired to
terminal \(2\), it makes \(\tau_0=4,\tau_3=5\).
The crossed \(r/C\) line in (80) then sends terminal \(5\)
to \(2\) in both cases. Hence (79) and the seed consequence
of (77) hold in this pattern as well.

In the remaining short patterns \((2,2,1,1)\) and
\((1,1,2,2)\), the core \(r/C\) trace directly joins the
two terminal arms: it uses \(e_6,e_5\) in the first and
\(e_1,e_2\) in the second. Their \(r/C\) pairing is already
\((1\,2)(4\,5)\), so (77) gives no seed. Thus, subject to
independent verification of the common strand classification,
\[
\boxed{\text{Aligned six-edge }J'=5\text{ short diamond
with no common }B+C\text{ seed}
\Longrightarrow (\alpha,\beta,\gamma,\delta)
\in\{(2,2,1,1),(1,1,2,2)\}.}                     \tag{81}
\]
This is a restriction on one normalized actual row. It does not
assert that either remaining pattern has a genuine exact-Case-XII
realization or that its full perfect-matching closure lacks a seed.

**The residual class-four phase is nontrivial but pairing-neutral
under no seed.** This is an all-orders consequence of the two
endpoint gates, independent of the diamond. The intermediate
Note-129 row is
\[
(q_{24}+B_2+\widehat C_4)+(r_{34}+Y_3+C_4)=2\mathbf1.
\]
It is an overlapping \((24)(34)\) row at terminal \(4\).
Note 139 and the forbidden \([34]\) Tait state give
\(\widehat C_4\ne C_4\) as complete masks. Write their
nonempty symmetric difference as proper even components
\(\Gamma_1\sqcup\cdots\sqcup\Gamma_k\). For any subset \(I\),
switch the two class-four occurrences on
\(\bigcup_{i\in I}\Gamma_i\). Both resulting class-four masks
remain actual, and the row still has the literal
\(q_{24},B_2,r_{34},Y_3\) masks. Exchanging the two class-four
occurrences if necessary and switching the forced
\(q_{24}/C_4\) terminal \(4\to5\) path produces right rows
with either new class-four mask, while retaining the literal
\(B_2,r_{34},Y_3\) masks. Applying (77) to each right row yields
\[
\boxed{\Lambda_L\cap\Lambda_R=\varnothing
\Longrightarrow\text{ every subphase of }
C_4\triangle\widehat C_4\text{ keeps the }
4\leftrightarrow5\text{ pairing with }r_{34}.}         \tag{82}
\]
The remaining owner patterns \((2,2,1,1)\) and \((1,1,2,2)\)
would therefore need a nonempty complete class-four phase cube
whose every member has this fixed terminal pairing. The condition
does not itself rule out either pattern; it identifies the next
full-mask obstruction to test in those branches.

For the left seed cell of [Note 118](../notes/118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md), equality of complete \(B+C\) loads with the two displayed right vectors has a local necessary form. Its class-\(14\) triple and class-\(3\) singleton both own \(s_3\). If its pair load is \(2b\) at \(v_3\), its class-\(1\) singleton and class-\(23\) triple must both own \(d\); if its pair load is \(b+d\), they must split \(b,d\). The forty positive Case-XII pair types, including the five \(S\)-loops, assert existence of rows, but do not select either of these complete local loads with a globally matching vector: [Note 055](../notes/055-half-load-column-saturation-and-case-xii-compression.md) saturates each carrier separately, while the seed remains the full-vector intersection \(\Lambda_L\cap\Lambda_R\) of Note 118. Equations (53)--(54) provide two actual targets for that intersection, not a proof that it is nonempty or a realizable exact-Case-XII pole.

**Both seed cells always admit a locally balanced \(B+C\) load at terminals \(1,3,5\).** This conclusion no longer assumes the short diamond, the two-collision profile, or any terminal docking. Assume only the negative \(T\)--\(T\) exclusion and the existence of actual left and right rows of Note 118(1). At each terminal \(i\in\{1,3,5\}\), neither \(B_2\) nor \(C_4\) owns the semiedge; let \(b_i,d_i\) be the two proper edges there. If \(B,C\) use different proper edges, their local load is already \(b_i+d_i\). If they coincide on \(b_i\), the row load forces the other two proper-edge occurrences to coincide on \(d_i\).

Apply the **left** fixed-\(C_4,r_{23},X_3\) involution of Note 129: switch the forced \(q_{14}/A_1\) terminal-\(1\)-to-\(2\) path, exchange the two class-\(2\) occurrences, then switch the forced \(q_{24}/B_2\) terminal-\(2\)-to-\(1\) path. The new \(B_2\) is the class-\(2\) matching made from \(A_1\) in the first switch; it is held fixed in the second. If \(B=C=b_i\), its incident edge is \(d_i\) at each of the three vertices:

| terminal \(i\) | semiedge owners in the left row | old \(d_i\) owners when \(B=C=b_i\) | first \(q/A\) path at \(v_i\) | new \(B\)-edge |
|---|---|---|---|---|
| \(1\) | \(A,r\) | \(q,X\) | switched \(1\to2\) path | old \(q=d_i\) |
| \(3\) | \(q,X\) | \(A,r\) | untouched \(3\to5\) path | old \(A=d_i\) |
| \(5\) | \(q,r\) | \(A,X\) | untouched \(3\to5\) path | old \(A=d_i\) |

The resulting left row fixes the complete \(C\) mask and has local \(B+C=b_i+d_i\). Apply the **right** fixed-\(B_2,Y_3,r_{34}\) involution of Note 129: switch the forced \(q_{25}/D_5\) terminal-\(5\)-to-\(4\) path, exchange the two class-\(4\) occurrences, then switch the forced \(q_{24}/C_4\) terminal-\(4\)-to-\(5\) path. The new \(C_4\) is held fixed in the second switch. If \(B=C=b_i\), its incident edge is \(d_i\) for the following reason:

| terminal \(i\) | semiedge owners in the right row | old \(d_i\) owners when \(B=C=b_i\) | first \(q/D\) path at \(v_i\) | new \(C\)-edge |
|---|---|---|---|---|
| \(1\) | \(q,r\) | \(D,Y\) | untouched \(1\to3\) path | old \(D=d_i\) |
| \(3\) | \(q,Y\) | \(D,r\) | untouched \(1\to3\) path | old \(D=d_i\) |
| \(5\) | \(D,r\) | \(q,Y\) | switched \(5\to4\) path | old \(q=d_i\) |

Thus, with \(\pi_i\) denoting restriction to the three edges incident with \(v_i\),
\[
\boxed{(0,1,1)\in\pi_i\Lambda_L(H)\cap\pi_i\Lambda_R(H)
\quad\text{for each }i\in\{1,3,5\}.}                    \tag{58}
\]
The coordinates are \((s_i,b_i,d_i)\). Each terminal may require a **different** left or right row. This is an actual full-mask closure theorem for three separate one-vertex projections; it does not claim a joint three-vertex projection intersection or the complete seed criterion \(\Lambda_L\cap\Lambda_R\ne\varnothing\). All forty positive Case-XII cells give the two required rows, but their other thirty-eight incidences are not used in this proof.
