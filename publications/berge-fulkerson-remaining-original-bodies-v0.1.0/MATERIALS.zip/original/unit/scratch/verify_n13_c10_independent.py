#!/usr/bin/env python3
"""Independent verifier for the explicit 13-vertex matching-relation pole."""

from collections import defaultdict, deque

N = 13
PROPER = (
    (0, 2), (0, 11), (1, 11), (1, 12), (2, 12),
    (3, 9), (3, 10), (4, 8), (4, 9), (5, 7),
    (5, 8), (5, 11), (6, 7), (6, 10), (6, 12),
    (7, 9), (8, 10),
)
S = frozenset({(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)})
ORDER = (1, 4, 2, 5, 3)


def build_edges():
    edges = [(f"e{i}", (u, v), None) for i, (u, v) in enumerate(PROPER)]
    edges += [(f"s{i}", (i - 1,), i) for i in range(1, 6)]
    return edges


EDGES = build_edges()
INC = defaultdict(list)
for eid, ends, boundary in EDGES:
    for vertex in ends:
        INC[vertex].append((eid, ends, boundary))


def graph_checks():
    assert len(set(tuple(sorted(e)) for e in PROPER)) == len(PROPER)
    assert all(u != v for u, v in PROPER)
    assert all(len(INC[v]) == 3 for v in range(N))
    adjacency = defaultdict(list)
    for u, v in PROPER:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen, queue = {0}, deque([0])
    while queue:
        for w in adjacency[queue.popleft()]:
            if w not in seen:
                seen.add(w)
                queue.append(w)
    assert len(seen) == N


def enumerate_matchings():
    output = []

    def search(covered, selected):
        if len(covered) == N:
            output.append(frozenset(selected))
            return
        vertex = next(v for v in range(N) if v not in covered)
        for eid, ends, _ in INC[vertex]:
            if any(v in covered for v in ends):
                continue
            search(covered | set(ends), selected + [eid])

    search(set(), [])
    assert len(output) == len(set(output))
    return tuple(sorted(output, key=lambda m: tuple(sorted(m))))


def boundary(matching):
    return frozenset(int(eid[1:]) for eid in matching if eid.startswith("s"))


def count_layered_five_cycles(relations):
    by_left = []
    for relation in relations:
        adjacency = defaultdict(list)
        for left, right in relation:
            adjacency[left].append(right)
        by_left.append(adjacency)
    count = 0
    for first, second in relations[0]:
        frontier = [(1, second)]
        while frontier:
            layer, current = frontier.pop()
            if layer == 4:
                count += sum(nxt == first for nxt in by_left[layer][current])
            else:
                frontier.extend((layer + 1, nxt) for nxt in by_left[layer][current])
    return count


def main():
    graph_checks()
    matchings = enumerate_matchings()
    singleton = {i: [] for i in range(1, 6)}
    for matching in matchings:
        b = boundary(matching)
        if len(b) == 1:
            singleton[next(iter(b))].append(matching)

    states = set()
    relations = []
    for i in range(1, 6):
        for j in range(i + 1, 6):
            if any(a.isdisjoint(b) for a in singleton[i] for b in singleton[j]):
                states.add((i, j))
    for left, right in zip(ORDER, ORDER[1:] + ORDER[:1]):
        relations.append(tuple(
            (a, b) for a in singleton[left] for b in singleton[right]
            if a.isdisjoint(b)
        ))

    nodes = set()
    adjacency = defaultdict(set)
    for layer, relation in enumerate(relations):
        left_pos, right_pos = ORDER[layer], ORDER[(layer + 1) % 5]
        for left, right in relation:
            u, v = (left_pos, left), (right_pos, right)
            nodes.update((u, v))
            adjacency[u].add(v)
            adjacency[v].add(u)
    seen, queue = {next(iter(nodes))}, deque([next(iter(nodes))])
    while queue:
        for v in adjacency[queue.popleft()]:
            if v not in seen:
                seen.add(v)
                queue.append(v)

    result = {
        "perfect_matchings": len(matchings),
        "singleton_counts": [len(singleton[i]) for i in range(1, 6)],
        "tait_states": sorted(states),
        "relation_sizes": [len(r) for r in relations],
        "layered_nodes": len(nodes),
        "layered_degrees": sorted(len(adjacency[v]) for v in nodes),
        "layered_connected": len(seen) == len(nodes),
        "compatible_pentagons": count_layered_five_cycles(relations),
    }
    print(result)
    assert frozenset(states) == S
    assert result["relation_sizes"] == [2, 2, 2, 2, 2]
    assert result["layered_nodes"] == 10
    assert result["layered_degrees"] == [2] * 10
    assert result["layered_connected"]
    assert result["compatible_pentagons"] == 0
    print("INDEPENDENT_N13_C10_VERIFIED")


if __name__ == "__main__":
    main()
