# Five exterior quotients for a two-vertex, two-five-cut barrier (draft)

The all-orders no-\(L^*\) theorem and its complementary-shore
matching quota are now recorded in [Note 209](../notes/209-a-five-cut-barrier-shore-cannot-have-lstar-support.md).
The repeated derivation below is retained here as the route to the
quotient-specific connector calculations.

Work in the connected deficient-core, minimum-host, full exact-Case-XII setting of [Note 169](../notes/169-minimal-tutte-barrier-has-three-odd-shore-profiles.md). Let the smallest maximum Tutte barrier be \(U=\{u_1,u_2\}\), and suppose \(F-U\) has two nonsingleton odd components \(A,B\), each with a five-edge \(J\)-cut, and two singleton components \(w_1,w_2\). No marked edge lies inside a component or meets \(U\). [Note 170](../notes/170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) gives the complete-matching one-hit/three-hit quota and the two-and-two singleton shore-profile quota for every actual BF row. This draft classifies the exterior quotient before imposing the two cyclic shores' complete matching relations. It does not assert that any quotient realizes exact Case XII.

For \(K\in\{A,B,w_1,w_2\}\), let \(r_K\) be the number of unmarked \(U\)--\(K\) edges. Since \(F\) is connected, \(r_K\ge1\). Each \(u_i\) meets three distinct components by Note 169, so \(r_K\le2\) and
\[
r_A+r_B+r_{w_1}+r_{w_2}=6.
\]
Thus exactly two components have \(r=2\) and two have \(r=1\). Both singleton components cannot have \(r=2\): then \(u_1-w_1-u_2-w_2-u_1\) is a proper four-cycle, contrary to girth at least five. Up to exchanging shores and singletons, the possibilities are
\[
\begin{array}{c|c|c}
 & (r_A,r_B,r_{w_1},r_{w_2}) &\text{unmarked quotient edges}\\\hline
\mathrm I&(2,2,1,1)&u_1A,u_1B,u_1w_1,\ u_2A,u_2B,u_2w_2\\
\mathrm {II}&(2,1,2,1)&u_1A,u_1B,u_1w_1,\ u_2A,u_2w_1,u_2w_2 .
\end{array}                                                    \tag{1}
\]
Here an edge \(u_iA\) names one specific shore port; its endpoint inside \(A\) is not identified with another port endpoint.

Every mark joins two *different* components of \(F-U\). The marked-incidence degrees of the quotient components are \(5-r_A,5-r_B,3-r_{w_1},3-r_{w_2}\). Let \(x\) count \(A\)--\(B\) marks and \(t\) count \(w_1\)--\(w_2\) marks. The core \(J\) is simple, so \(t\in\{0,1\}\).

In type I these four marked degrees are \((3,3,2,2)\). Comparing the total shore and singleton incidences gives \(6-2x=4-2t\), hence \(x=t+1\). If \(t=0\), either each singleton has one mark to each shore, or one has two marks to \(A\) and the other two to \(B\). If \(t=1\), the two remaining singleton marks go to opposite shores and \(x=2\).

In type II the marked degrees are \((3,4,1,2)\). A \(w_1w_2\) mark would form a core triangle with their common neighbour in \(U\), hence a proper four-cycle after subdivision; thus \(t=0\). The degree sum gives \(7-2x=3\), so \(x=2\). After the two \(A B\) marks, \(A\) needs one more marked incidence and \(B\) needs two. The unique mark of \(w_1\) goes either to \(A\), leaving both \(w_2\) marks to \(B\), or to \(B\), leaving one \(w_2\) mark to each shore.

Consequently the complete list of marked **component pairs**, up to the named exchanges, is
\[
\begin{array}{c|l}
\mathrm I_s&AB,\ 2Aw_1,\ 2Bw_2\\
\mathrm I_m&AB,\ Aw_1,\ Bw_1,\ Aw_2,\ Bw_2\\
\mathrm I_r&2AB,\ Aw_1,\ Bw_2,\ w_1w_2\\
\mathrm {II}_A&2AB,\ Aw_1,\ 2Bw_2\\
\mathrm {II}_B&2AB,\ Bw_1,\ Aw_2,\ Bw_2 .
\end{array}                                                    \tag{2}
\]
Multiplicity two in (2) means two distinct marked edges with possibly different vertices in the same shore, never a parallel edge of the simple core. The corresponding five-pole is obtained by subdividing each marked edge and attaching one terminal semiedge there. Equations (1)--(2) classify its exterior incidence, not the internal structure or matching relation of \(A,B\).

There is a sharp order boundary. If \(\beta_C=|E(F[C])|-|C|+1\) is the cycle rank of a shore and \(\rho=\beta_A+\beta_B\), Note 169 gives
\[
|V(H)|=15+2\rho.
\]
[Note 100's exact small-order exclusion](../notes/100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) forces \(\rho\ge1\), while [Note 226's published-order consequence](../notes/226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) strengthens this to \(\rho\ge9\). Thus at least one of the two five-cut shores is cyclic in any putative minimum-host exact-Case-XII realization.

At the first order left by [Note 100's local census](../notes/100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md), \(|V(H)|=17\), one shore has cycle rank one and five vertices, while the other is a three-vertex tree. Girth at least five makes the five-vertex unmarked cyclic shore an ordinary pentagon \(C_5\). Hence every order-17 candidate in this profile has one \(P_3\) shore and one \(C_5\) shore. [Note 226](../notes/226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) now excludes this entire order by the published BF theorem through whole-graph order 36. The local geometry remains: if the \(P_3\) shore is \(A\) in quotient \(\mathrm I_s\), its centre port must be \(u_1A\): [Note 170](../notes/170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) makes the centre port unmarked; the two \(Aw_1\) marks meet the two tree ends, because the centre has no remaining port and \(J\) is simple. Were \(u_1A\) attached to either end, that end, \(u_1\), and \(w_1\) would form a core triangle with one marked edge, a proper four-cycle after subdivision. The symmetric statement holds for a \(P_3\) shore \(B\): its centre port is \(u_2B\).

## The separated double-fork type \(\mathrm I_s\) is impossible

The first type in (2) can be ruled out at **every order**, without assuming
either five-cut shore is a tree or a pentagon.  Work in the whole minimum host
\(G\), obtained by joining the opened Case-XII pole to its opposite pentagon.
Name the two marks from \(A\) to \(w_1\) by \(x,y\), and the single
\(A\)--\(B\) mark by \(z\).  Let \(t_x,t_y,t_z\) be their subdivision
vertices.  Put
\[
    X=V(A)\cup\{u_1,w_1,t_x,t_y\}\subset V(G).
\]
The only edges of \(\delta_G(X)\) are \(u_1B\), \(u_2A\), the \(A\)-half
of \(z\), and the two edges from \(t_x,t_y\) to the opposite pentagon.
Thus \(|\delta_G(X)|=5\).  The induced side \(G[X]\) is connected and has
a cycle: the two internally distinct \(w_1\)--\(A\) routes through
\(t_x,t_y\) meet inside connected \(A\).  The complement is connected
and contains the opposite pentagon.  Since \(|A|=3+2r(A)\ge3\), the
\(X\)-side has at least seven vertices; the complementary side contains
\(B,u_2,w_2\), three remaining subdivision vertices, and the pentagon,
so neither shore is an ordinary five-cycle.

Open this new cycle-separating five-cut and call its \(X\)-side five-pole
\(X^\circ\).  Three of its ports occur at the neighbours
\(u_1,t_x,t_y\) of \(w_1\).  A matching using those three ports leaves
\(w_1\) unmatched.  In particular, \(X^\circ\) has no all-terminal
perfect matching, and it has no triple-boundary perfect matching whose
boundary is precisely these three ports.  Consequently its BF relation
has neither the all-terminal type nor the loop on the pair of the other
two ports.

By [Proposition 4.4 and Figure 7 of Máčajová--Mazzuoccolo--Tabarelli](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf),
this nonpentagonal cycle-separating five-cut of a minimum BF
counterexample must be Case XIII.  Each side must therefore have one of
the two complete Case-XIII relations: \(R^*\) contains the all-terminal
BF type, and \(L^*\) contains every one of the ten loops.  The two
missing types just found rule out both possibilities for \(X^\circ\).
The ten-loop statement uses Figure 7; [Note 165](../notes/165-case-xiii-shore-compositions-exclude-the-disconnected-core.md)
records the \(25/45\) transcription error in the paper's Case-XIII
appendix.
Hence \(\mathrm I_s\) is impossible.  This uses the published full BF
support for the *alternative* five-cut, not a selected matching row of
the original pole.

## No five-cut shore has Case-XIII \(L^*\) support

There is a stronger obstruction shared by all five quotient types in
(2), and in fact by [Note 170's](../notes/170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md)
two-five-cut profile for **any** size of its normalized maximum barrier
\(U\).  Let \(C\) be either five-cut odd component of \(F-U\), open
its five-edge cut in the **whole** minimum host \(G\), and denote the
complementary five-pole by \(E(C)\).  Then
\[
\boxed{E(C)\text{ has no all-terminal perfect matching}.}       \tag{N}
\]

**Proof of (N).**  Write \(k=|U|\).  The barrier has exactly
\(k+2\) odd components.  Let \(r_C\) count the unmarked
\(U\)--\(C\) edges.  The five-edge cut of \(C\) consists of these
\(r_C\) edges and \(5-r_C\) marked edges, because no mark lies
inside a component or meets \(U\).  Suppose a perfect matching of
\(E(C)\) used all five cut semiedges.  It would saturate the
\(r_C\) distinct \(U\)-neighbours of \(C\), leaving at most
\(k-r_C\) barrier vertices available to match the other odd
components.  It would also saturate the subdivision vertices of all
\(5-r_C\) marks incident with \(C\), so none of those marks could
match an endpoint of another component.  Only \(r_C\) of the five
marks remain; each can match at most one endpoint of another odd
component.  Hence at most
\((k-r_C)+r_C=k\) other odd components can receive an external
matching edge.  But there are \(k+1\) odd components besides \(C\),
and each needs at least one external matching edge.  This is
impossible.  The opposite pentagon cannot supply another route to a
core component: all its links enter through one of the same five
marked subdivision vertices.  \(\square\)

Suppose now one of \(A,B\), say \(C\), were cyclic, nonpentagonal,
and of Case-XIII type \(L^*\).  Its five-cut in \(G\) is
cycle-separating; the other side contains the original Case-XII
pentagon and is not itself a pentagon.  Proposition 4.4 therefore
requires the opposite shore \(E(C)\) to have type \(R^*\).
Figure 7's \(R^*\) relation includes an all-terminal BF row, hence an
all-terminal perfect matching, contradicting (N).  Therefore
\[
\boxed{\text{No five-cut shore in the normalized
two-five-cut barrier profile, at any }|U|,
\text{ has }L^*\text{ support}.}                                \tag{L}
\]
This is an all-orders complete-support consequence of a **single
matching impossibility** on an alternative whole-host shore.  It
subsumes the \(I_m\) exclusions below, whose six-slot rows remain as
direct checks of the original connector closure.

Type \(II_A\) has a further consequence.  The three neighbours of
\(w_1\) in \(E(A)\) are exactly its cut-port vertices
\(u_1,u_2,t_x\).  A triple-boundary matching using those three
ports leaves \(w_1\) unmatched.  Thus \(E(A)\) also lacks the BF
loop on the other two ports \(z_1,z_2\).  If \(A\) were cyclic and
nonpentagonal, Proposition 4.4 would require \(A,E(A)\) to be the
\(L^*,R^*\) pair.  Statement (N) prevents \(E(A)=R^*\), while the
missing loop prevents \(E(A)=L^*\).  Hence
\[
\boxed{II_A\text{ in exact Case XII }
\Longrightarrow A\text{ is a three-vertex tree or an ordinary pentagon}.}
                                                               \tag{A}
\]
This does not restrict \(B\) to a small shore and does not eliminate
\(II_A\) itself.

## Two \(L^*\) shores cannot realize \(\mathrm I_m\)

In type \(\mathrm I_m\), name the direct \(A B\) mark \(z\), the
\(A w_1,B w_1\) marks \(x,y\), and the \(A w_2,B w_2\) marks \(p,q\).
The five ports of \(A^\circ\) are \(u_1,u_2,z,x,p\), and those of
\(B^\circ\) are \(u_1,u_2,z,y,q\).  There is an exact gluing gate for
any pair of actual six-slot shore rows.  Let \(U_i^A,U_i^B\) be their
two-slot labels at the ports toward \(u_i\), and write \(X,P,Z_A\)
and \(Y,Q,Z_B\) for their labels at \(x,p,z\) and \(y,q,z\),
respectively.  With \(R_i=[6]\setminus(U_i^A\cup U_i^B)\), they glue
if and only if
\[
 U_i^A\cap U_i^B=\varnothing\ (i=1,2),\qquad
 Z_A\cap Z_B=\varnothing,\qquad
 X\cap Y\subseteq R_1,\quad P\cap Q\subseteq R_2.       \tag{G}
\]
For each \(i\), the same two-set partition argument as in
[Note 172](../notes/172-one-vertex-two-shore-connector-has-one-overlap-gate.md)
partitions \([6]\setminus R_i\) between the two \(w_i\)-mark halves,
avoiding their respective shore-half labels.  This proves sufficiency;
necessity is the slot partition at \(u_i,w_i\) and the subdivided
\(z\)-mark.  In particular, complete shore **BF type relations** suffice
for this quotient because their six slots may be relabelled independently.

Suppose both shores have the complete
Case-XIII \(L^*\) relation.  In particular each has an *actual* BF
loop row on any prescribed pair of its ports.

Here are two pairs of local rows.  Entries give each slot's **shore
boundary**, not just a formal terminal word; the same entry is used
twice in each two-slot block.

| target | slots | \(A^\circ\) boundary | \(B^\circ\) boundary |
|---|---|---|---|
| \([zx]\) | \(1,2\) | \(\{u_1,x,p\}\) | \(\{u_2\}\) |
| | \(3,4\) | \(\{u_2\}\) | \(\{z,y,q\}\) |
| | \(5,6\) | \(\{z\}\) | \(\{u_1\}\) |
| \([yp]\) | \(1,2\) | \(\{z,x,p\}\) | \(\{u_2\}\) |
| | \(3,4\) | \(\{u_1\}\) | \(\{z,y,q\}\) |
| | \(5,6\) | \(\{u_2\}\) | \(\{u_1\}\) |

The first pair uses shore loops \([zu_2]\) and \([u_1u_2]\);
the second uses \([u_1u_2]\) on both shores.  Since the shore rows
are genuine, each shore's internal edges already have load two.  To
check the exterior gluing, let \(R_i\) label \(u_iw_i\), and let
\(D_x,D_y,D_p,D_q\) label the \(w_i\)-side halves of the four
subdivided marks.  The two rows admit these labels:

| target | \(R_1\) | \(R_2\) | \(D_x\) | \(D_y\) | \(D_p\) | \(D_q\) | outer terminal labels \((z,x,y,p,q)\) |
|---|---|---|---|---|---|---|---|
| \([zx]\) | \(34\) | \(56\) | \(56\) | \(12\) | \(34\) | \(12\) | \((12,34,56,56,56)\) |
| \([yp]\) | \(12\) | \(34\) | \(34\) | \(56\) | \(56\) | \(12\) | \((56,56,12,34,56)\) |

Here \(34\) denotes the two-slot set \(\{3,4\}\), etc.  At every
\(u_i,w_i\) and marked subdivision vertex, the three incident labels
partition \([6]\).  In particular the direct \(A B\) half-edge labels
are disjoint.  Thus each table row glues six actual perfect matchings,
with every proper edge and semiedge loaded twice.  In the first row,
slots \(5,6\) have outer boundary \(\{y,p,q\}\) and give \([zx]\);
in the second they have boundary \(\{z,x,q\}\) and give \([yp]\).

The incidence pattern \(\mathrm I_m\) allows exchanging \(A,B\),
which exchanges \((x,p)\) with \((y,q)\), and exchanging
\((u_1,w_1)\) with \((u_2,w_2)\), which exchanges \((x,y)\) with
\((p,q)\).  These are relabellings of the *construction*; no
isomorphism between the two internal shore graphs is required, because
both complete \(L^*\) relations contain every loop.  The two rows
therefore force the six distinct outer loops
\[
    [zx],\ [zy],\ [zp],\ [zq],\ [yp],\ [xq].
\]
Exact Case XII has loops only on the five edges of its allowed
pentagon \(S\), so at least one of these six is forbidden.  Hence
\(\mathrm I_m\) with two \(L^*\) shores is impossible at every order.
This argument uses complete local BF rows and an explicit six-slot
gluing, not a selected family of matching boundaries.

The same slot method excludes **every** mixed \(L^*\)--pentagon
placement.  Let \(A^\circ\) have \(L^*\) support and \(B^\circ\) be an
ordinary pentagon.  First suppose its ports \(u_1,u_2\) are adjacent
on the pentagon.  It then supports the genuine local loop
\([u_1u_2]\), so the two constructions above and their exchange of
the two \(w_i\) force
\([zx],[zp],[yp],[xq]\).  Only one five-cycle on
\(\{z,x,y,p,q\}\) contains these four edges, namely
\(q-x-z-p-y-q\).  In particular \([zy]\) and \([zq]\) are forbidden.

Every pentagon port has two neighbours, so \(z\) has a loop with at
least one of \(u_1,u_2,y,q\).  Two additional genuine gluing rows give
\[
\begin{array}{c|c|c|c|c}
\text{loop on }B^\circ&\text{loop on }A^\circ
 &R_1,R_2&(D_x,D_y,D_p,D_q)&
 (T_z,T_x,T_y,T_p,T_q)\\\hline
[u_1z]&[u_1z]&(12,56)&(34,56,34,12)&(34,56,12,56,56)\\
[zy]&[u_2x]&(56,12)&(12,34,34,56)&(34,56,56,56,12)
\end{array}                                                     \tag{3}
\]
For the first row take \(A\)'s triple slots \(1,2\), singleton
\(u_1\) slots \(3,4\), singleton \(z\) slots \(5,6\);
take \(B\)'s singleton \(z\) slots \(1,2\), triple slots
\(3,4\), singleton \(u_1\) slots \(5,6\).  For the second take
\(A\)'s triple slots \(1,2\), singleton \(x\) slots \(3,4\),
singleton \(u_2\) slots \(5,6\); take \(B\)'s singleton \(y\)
slots \(1,2\), triple slots \(3,4\), singleton \(z\) slots
\(5,6\).  The displayed connector labels partition the six slots at
every connector vertex and marked subdivision vertex.  The first row
gives the outer loop \([zy]\), and the second gives \([zq]\).
Exchanging the two \(w_i\) gives \([u_2z]\mapsto[zq]\) and
\([zq]\mapsto[zy]\).  Whichever neighbour of \(z\) occurs on the
pentagon therefore creates a forbidden loop.  Thus \(\mathrm I_m\)
cannot have such a mixed shore pair when \(u_1,u_2\) are adjacent.

For completeness, three more local-loop transports handle
nonadjacent \(u_1,u_2\).  In all three rows \(A\)'s triple slots are
\(1,2\) and \(B\)'s are \(3,4\).  The columns headed \(A_{34},A_{56}\)
and \(B_{12},B_{56}\) name their respective singleton boundaries;
the pair in either row's first two columns is the displayed local loop.
\[
\begin{array}{c|c|cc|cc|cc|cccc|c}
B\text{ loop}&A\text{ loop}&A_{34}&A_{56}&B_{12}&B_{56}
 &R_1&R_2&D_x&D_y&D_p&D_q&(T_z,T_x,T_y,T_p,T_q)\\\hline
[yq]&[u_2x]&x&u_2&y&q&56&12&12&34&56&34&(56,56,56,34,12)\\
[u_1y]&[u_1z]&u_1&z&y&u_1&12&56&56&34&34&12&(12,34,56,56,56)\\
[u_1q]&[zp]&p&z&q&u_1&34&56&56&12&12&34&(12,34,56,56,56)
\end{array}                                                     \tag{4}
\]
Every local loop in (4) is an actual row: \(A\) has all ten loop
types, while the assumed \(B\) loop is an edge of its port pentagon.
As in (3), the connector labels partition \([6]\) at every exterior
vertex and marked subdivision vertex; the two direct-\(z\) halves
are disjoint.  The first row gives outer \([pq]\); exchanging the
two \(w_i\) gives \([xy]\).  Either of the last two rows gives outer
\([zx]\); their exchanged versions cover \([u_2q]\mapsto[zp]\)
and \([u_2y]\mapsto[zp]\), respectively.

Now suppose \(u_1,u_2\) are nonadjacent on the \(B\)-pentagon.  They
have a unique common neighbour \(c\in\{z,y,q\}\).

If \(c=z\), the pentagon contains \([u_1z],[u_2z],[yq]\).
Rows (3)--(4) and their exchanges force outer
\([zy],[zq],[xy],[pq]\).  Their four edges form the path
\(x-y-z-q-p\), so the only possible allowed loop pentagon is
\(x-y-z-q-p-x\).  The remaining pentagon route is either
\(u_1-y-q-u_2\) or \(u_1-q-y-u_2\).  In either case it contains
\([u_1y]\) or \([u_1q]\); row (4) forces \([zx]\), which is not
on that allowed pentagon.

If \(c=y\), the local loops \([u_1y],[u_2y]\) force outer
\([zx],[zp]\) by (4).  The port \(z\) is adjacent in the
\(B\)-pentagon to one of \(u_1,u_2,q\).  Each of those three loops
forces \([zy]\) or \([zq]\) by (3) and its exchange.  This gives
three different allowed-loop edges incident with \(z\), impossible
in a pentagon.  The case \(c=q\) is the exchange of \(w_1,w_2\).

Thus all relative pentagon port orders are excluded.  The mirror
placement with \(A\) the pentagon follows by exchanging shores;
no isomorphism of their internal graphs is assumed.

The same transports exclude an \(L^*\) shore opposite a three-vertex
tree.  Take \(A^\circ=L^*\), and let \(B^\circ\) be the tree.
By Note 170 its centre port is unmarked; exchange the two \(w_i\)
so it is \(u_1\).  The four local tree loops are exactly the cross
pairs between its two two-port end groups, a partition of
\(\{u_2,z,y,q\}\).  There are three partitions up to exchanging
the ends:
\[
\begin{array}{c|c|c}
\text{end groups}&\text{selected true tree loops}&
 \text{forced outer loops}\\\hline
\{u_2,z\}\mid\{y,q\}&[u_2y],[zy],[zq]&[zp],[zq],[zy]\\
\{u_2,y\}\mid\{z,q\}&[u_2z],[u_2q],[yq]&[zq],[zp],[pq]\\
\{u_2,q\}\mid\{z,y\}&[u_2z],[u_2y],[zq]&[zq],[zp],[zy]
\end{array}                                                     \tag{5}
\]
Every implication in (5) is one of (3)--(4) or its exchange of the
two \(w_i\).  The first and third rows force three allowed-loop edges
incident with \(z\); the second forces the triangle \(z-p-q-z\).
Neither fits inside a five-cycle.  Thus \(\mathrm I_m\) has no
\(L^*\)--tree placement either, and the mirror follows by swapping
the shores.

The two-vertex, two-five-cut profile still has quotient types
\(\mathrm I_m,\mathrm I_r,\mathrm {II}_A,\mathrm {II}_B\), with the
\(L^*\)--\(L^*\), \(L^*\)--pentagon and \(L^*\)--tree shore
pairings removed from \(\mathrm I_m\).  An \(L^*\)--\(R^*\)
pairing and other shore combinations are not decided here.
Their other internal shore relations and the other Tutte-barrier
profiles remain open.

## Two genuine \(R^*\) row transports in \(\mathrm I_m\)

[Note 209](../notes/209-a-five-cut-barrier-shore-cannot-have-lstar-support.md)
removes every \(L^*\) shore from this profile, so the remaining
nonpentagonal cyclic pairing in \(\mathrm I_m\) is \(R^*\)--\(R^*\).
The exact gate (G) gives the following conditional transports from
*actual* overlapping shore BF types.  They apply whenever the stated
type belongs to both complete shore relations, regardless of the
interiors or the relative \(P/Q\) placements.

First suppose both shores support \((u_1u_2)(u_1z)\).  Assign their
six local boundaries as follows:

| slot | \(A^\circ\) boundary | \(B^\circ\) boundary |
|---|---|---|
| 1 | \(\{z,x,p\}\) | \(\{u_2\}\) |
| 2 | \(\{u_2,x,p\}\) | \(\{z\}\) |
| 3 | \(\{u_1\}\) | \(\{z,y,q\}\) |
| 4 | \(\{u_1\}\) | \(\{u_2,y,q\}\) |
| 5 | \(\{u_2\}\) | \(\{u_1\}\) |
| 6 | \(\{z\}\) | \(\{u_1\}\) |

Then \(R_1=12,R_2=36\), and the connector choice
\((D_x,D_y,D_p,D_q)=(34,56,45,12)\) satisfies (G).  The outer
terminal labels are \((T_z,T_x,T_y,T_p,T_q)=(45,56,12,36,56)\),
so the two triple slots \(5,6\) give \((yp)(yz)\).  Swapping the
shore roles gives \((xq)(xz)\).  Swapping the two \(w_i\) gives
the analogous two transports for common type
\((u_1u_2)(u_2z)\).

Second suppose both shores support \((u_1z)(u_2z)\).  Put the
\(A\)-triple boundaries \(\{u_2,x,p\},\{u_1,x,p\}\) in slots
\(1,2\), its singleton \(z\) in \(3,4\), and its singleton
\(u_1,u_2\) in \(5,6\).  Put the \(B\)-singleton \(z\) in
\(1,2\), its triple boundaries
\(\{u_2,y,q\},\{u_1,y,q\}\) in \(3,4\), and its singleton
\(u_2,u_1\) in \(5,6\).  The direct-\(z\) halves are disjoint,
and \(R_1=13,R_2=24\).  Two connector choices are
\[
\begin{array}{c|cccc|ccccc|c}
&D_x&D_y&D_p&D_q&T_z&T_x&T_y&T_p&T_q&\text{outer type}\\\hline
1&45&26&35&16&56&36&15&46&25&(xp)(yq)\\
2&45&26&36&15&56&36&15&45&26&(xq)(yp)
\end{array}.                                                     \tag{R}
\]
At \(u_i,w_i\) and every marked subdivision vertex, the three
two-slot labels partition \([6]\); hence both rows glue genuine
six-perfect-matching covers.  Each case leaves a different outer
disjoint pair.  Thus a common \(R^*\) cross-block type
\((u_1z)(u_2z)\) forces **both** displayed outer types.

These transports alone do not exclude every allowed Case-XII
pentagon.  Indeed, even if **all three** common overlapping types on
\(\{u_1u_2,u_1z,u_2z\}\) were available, the six outer types just
listed are compatible with the allowed loop pentagon
\[
             S=y-p-x-q-z-y.
\]
It contains \(yp,xp,xq,qz,yz\): each of the six forced outer
pair types has at least one state in \(S\).  A single \(R^*\)
shore can support at most two of the three overlapping types,
since its pair relation crosses a two-block partition.  Allowing all
three here only strengthens the failed implication.  This is a
formal support boundary, not a realization by an
\(R^*\)--\(R^*\) graph.  The boundary is nonvacuous for the actual
Figure-7 relation: label \((u_1,u_2,z)=(1,2,3)\) on both
\(R^*\) shores.  Its states \(12,13,23\) have block colours
\(Q,P,Q\), so the two common types \((u_1u_2)(u_1z)\) and
\((u_1z)(u_2z)\) are genuine.  Their four transported outer types
are all allowed by the displayed \(S\).  Other \(R^*\) types may
still force a forbidden outer type; no composite exact-Case-XII
graph is asserted.
The remaining decision must use other \(R^*\) cross-block types,
their coupling through (G), or additional whole-host structure.

## A two-star rectangle in \(\mathrm I_m\)

There is a second exact transport.  Let \(a\in\{z,x,p\}\) be an
\(A\)-port and \(b\in\{z,y,q\}\) a \(B\)-port, with
\((a,b)\ne(z,z)\).  If the *actual* shore relations contain
\((u_1a)(u_2a)\) and \((u_1b)(u_2b)\), respectively, then
\[
                    \boxed{[ab]\text{ is an actual outer BF loop}.}
                                                               \tag{S}
\]
To check all eight possibilities at once, put the \(A\)-triple
boundaries \([5]_A\setminus\{u_1,a\}\) and
\([5]_A\setminus\{u_2,a\}\) in slots \(1,2\), its singleton
\(u_1,u_2\) in \(3,4\), and singleton \(a\) in \(5,6\).
Put the \(B\)-singleton \(u_1,u_2\) in \(1,2\), its triple
boundaries \([5]_B\setminus\{u_1,b\}\) and
\([5]_B\setminus\{u_2,b\}\) in \(3,4\), and singleton
\(b\) in \(5,6\).  Both residual labels in (G) are \(R_1=R_2=56\).
Each \(A\)-marked port has label \(56\) at \(a\) and \(12\)
elsewhere; each \(B\)-marked port has label \(56\) at \(b\) and
\(34\) elsewhere.  At the direct \(z\)-mark these labels are
disjoint exactly when \((a,b)\ne(z,z)\).  At both singletons choose
the \(A\)-mark connector-half label \(34\) and the \(B\)-mark
connector-half label \(12\), so that
\((D_x,D_y,D_p,D_q)=(34,12,34,12)\).  These avoid their respective
shore-half labels, while \(R_i=56\) completes each partition.
Thus (G) holds, and all
six slots glue genuine perfect matchings with load two.  In slots
\(5,6\), neither connector half is used, so precisely the three
outer terminals other than \(a,b\) occur.  These identical triple
slots give (S).  The displayed construction specifies the complete
six-slot row, not just its boundary type.

For a Figure-7 \(R^*\) shore, colour each local missing-pair state
by its \(P/Q\) block.  Write
\[
D_C(u_1,u_2)=\{r\in\{z,\text{the two private ports of }C\}:
 c_C(u_1r)\ne c_C(u_2r)\}.
\]
Its genuine star centres are exactly \(D_C\).  Consequently the
outer allowed loop pentagon \(S\) must contain every distinct
port-pair edge of
\[
               D_A\times D_B\setminus\{(z,z)\}.               \tag{S2}
\]
For the published blocks
\(P=\{13,14,24,35,45\}\) and
\(Q=\{12,15,23,25,34\}\), a direct comparison of the three
states incident with each pair of ports gives
\[
\begin{array}{c|cccccccccc}
u_1u_2&12&13&14&15&23&24&25&34&35&45\\\hline
D_C&3&45&235&\varnothing&145&15&3&2&14&123
\end{array}.                                                   \tag{S4}
\]
Entries such as \(45\) in the second row mean the *set of port
labels* \(\{4,5\}\), not a missing-pair state.  The table is
read after independently relabelling each shore's five ports.
This gives immediate forbidden-placement rules, all independent of
the earlier transports (R).  If both shores have \(z\) and at
least one private port in \(D_C\), the three forced loops on
\(\{z,a,b\}\) form a triangle.  If neither has \(z\), two
private centres on each side force a four-cycle.  If one shore has
all three marked ports in \(D_C\), the other cannot have any
private centre: such a centre would have three forced loop
neighbours.  No triangle, four-cycle, or degree-three vertex can
occur in the allowed loop pentagon.  These rules exclude whole
classes of relative \(R^*\) port placements, but placements with
small or empty \(D_C\) remain.  For example, assigning
\((u_1,u_2)=(1,5)\) on both shores makes both sets empty, so this
rectangle alone imposes no outer loop.  This is a true Figure-7
port placement, not a composite exact-Case-XII graph.

## All three shared-leaf pairs force private-to-private loops

The preceding rectangle uses only the shared leaves \(u_1,u_2\).
For private centres \(a\in\{x,p\}\), \(b\in\{y,q\}\), the
same conclusion holds with **any** distinct shared leaves
\(r,s\in\{u_1,u_2,z\}\):
\[
 A^\circ:(ra)(sa),\quad B^\circ:(rb)(sb)
 \quad\Longrightarrow\quad [ab]\text{ on the outer pole}.       \tag{S5}
\]
For \(r,s=u_1,u_2\), this is (S).  The following table supplies
the other two leaf pairs when \(a=x\).  Put the two \(A\)-triple
boundaries missing \(ra,sa\) in slots \(1,2\), and the two
\(B\)-triple boundaries missing \(rb,sb\) in slots \(3,4\).
The entries in \(A_{3456},B_{1256}\) specify the four singleton
boundaries in the indicated slots.  Port and connector labels
such as \(35\) denote two-slot sets.
\[
\begin{array}{c|c|c|c|c|c}
(a,b)&(r,s)&A_{3456}&B_{1256}&(R_1,R_2)
 &(D_x,D_y,D_p,D_q)\\\hline
(x,y)&(z,u_1)&(z,x,u_1,x)&(z,y,y,u_1)&(24,56)&(35,16,34,12)\\
(x,q)&(z,u_1)&(z,x,u_1,x)&(z,u_1,q,q)&(46,56)&(35,12,34,12)\\
(x,y)&(u_2,z)&(u_2,z,x,x)&(u_2,z,y,y)&(56,56)&(34,12,34,12)\\
(x,q)&(u_2,z)&(u_2,z,x,x)&(u_2,z,q,q)&(56,56)&(34,12,34,12)
\end{array}.                                                   \tag{S6}
\]
In each row, the \(A\)- and \(B\)-labels at the direct \(z\)
mark are disjoint.  At \(u_i,w_i\), the listed \(R_i\) and
connector labels partition all six slots; every subdivision
vertex has its three two-slot labels partitioning them as well.
The outer terminal labels are \(T_a=12,T_b=34\) and
\(T_c=56\) for the other three marks.  Hence slots \(5,6\)
give the claimed loop.  Reflecting the exterior quotient exchanges
\((u_1,u_2,x,p,y,q)\) with
\((u_2,u_1,p,x,q,y)\), giving \(a=p\) and completing (S5).

Call a private port \(a\) *active* if the three Figure-7 colours
\(c_C(u_1a),c_C(u_2a),c_C(za)\) are not all equal.  A nonconstant
binary colouring of three shared labels separates exactly two of
their three pairs.  Two such two-pair sets intersect.  Thus (S5)
forces \([ab]\) for **every** active private \(A\)-port \(a\)
and active private \(B\)-port \(b\).  If both private ports on
both shores were active, these four loops would form the forbidden
four-cycle \(x-y-p-q-x\).  Hence
\[
\boxed{\text{An exact-Case-XII }\mathrm I_m\text{ with two }R^*
\text{ shores requires a private port constant on }
\{u_1,u_2,z\}\text{ on at least one shore}.}                  \tag{S7}
\]
Figure 7 makes the remaining placement explicit.  At local port
labels \(1,3,5\), the four incident state colours split \(2+2\);
at \(2\), the unique \(P\)-edge is \(24\); at \(4\), the unique
\(Q\)-edge is \(34\).  A private port is therefore constant on
the shared three exactly when its ordered label and the *other*
private label are \((2,4)\) or \((4,3)\).  Both private ports
cannot be constant.  This is a necessary relative-port placement,
not an exclusion of the surviving constant-port cases.  In
particular, the \((u_1,u_2,z,x,p)=(1,5,2,3,4)\) and
\((u_1,u_2,z,y,q)=(1,5,2,3,4)\) placement has constant
\(p,q\) but active \(x,y\).  The \((z,u_1)\) row in (S6)
forces \([xy]\) there even though the earlier \(D_A,D_B\)
sets are both empty.  This shows why (S2) alone cannot classify
the outer loops.

## A same-singleton pair gate

The two private marks at one singleton give another useful
three-row contradiction.  Suppose \(A^\circ\) supports
\((u_1u_2)(u_1x)\), \(B^\circ\) supports
\((u_1u_2)(u_1y)\), and the outer relation contains \([xy]\).
The two local pair rows alone force both outer types
\[
                         (xp)(yq),\qquad (xq)(yp).             \tag{P}
\]
Indeed, put \(A\)'s triple boundaries
\(\{z,x,p\},\{u_2,z,p\}\) in slots \(1,2\), its singleton
\(u_1,u_1,u_2,x\) in \(3,4,5,6\), respectively.  Put
\(B\)'s singleton \(u_1,u_1\) in \(1,2\), its triple
boundaries \(\{z,y,q\},\{u_2,z,q\}\) in \(3,4\), and its
singleton \(y,u_2\) in \(5,6\).  The resulting port labels give
\(R_1=56,R_2=13\) and \(T_z=56\).  Both choices below satisfy
the exact gate (G):
\[
\begin{array}{c|cccc|ccccc|c}
 &D_x&D_y&D_p&D_q&T_z&T_x&T_y&T_p&T_q&\text{outer pair}\\\hline
1&34&12&45&26&56&25&46&36&15&(yp)(xq)\\
2&34&12&46&25&56&25&46&35&16&(yq)(xp)
\end{array}.                                                   \tag{P1}
\]
The outer triple slots are \(5,6\) in both rows.  Their two
missing-pair states are the displayed ones; every proper edge has
load two because each input shore row is actual.

No allowed loop pentagon \(S\) can contain \([xy]\) while
admitting both (P) types.  If \(xp\in S\), the \((xq)(yp)\)
row forces \(yp\in S\), making the triangle \(x-y-p-x\).
If \(xp\notin S\), the \((xp)(yq)\) row forces \(yq\in S\),
which saturates \(y\) along with \(xy\).  The other row then
forces \(xq\in S\), making the triangle \(x-y-q-x\).
Thus these three actual types contradict exact Case XII.
Reflecting the quotient gives the analogous gate with
\((u_1u_2)(u_2p)\), \((u_1u_2)(u_2q)\), and \([pq]\).

For \(R^*\) shores, the loop hypothesis follows from (S5)
whenever \(x,y\) are active.  Hence such active ports cannot
simultaneously support the two local pair types in (P).
As a concrete application, give both shores the Figure-7
placement \((u_1,u_2,z)=(1,5,2)\), put \(x=y=3\) in their
respective shores, and put \(p=q=4\).  Both \(x,y\) are active:
their state colours toward \((u_1,u_2,z)\) are \((P,P,Q)\).
Both local pairs in (P) are supported because \(15\in Q\)
and \(13\in P\).  The corresponding relative placement is
therefore impossible.  Other constant-private-port placements
remain open; this is not a classification of \(\mathrm I_m\).

[Note 212](../notes/212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
adds the other private port as a fourth possible leaf in the star
rectangle.  Its genuine six-slot transport forces all four loops
\([xy],[xq],[py],[pq]\) for two complete \(R^*\) shore
relations, closing the \(R^*\)--\(R^*\) combination in
\(\mathrm I_m\).  The preceding conditional gates remain valid
but are no longer the final boundary for that combination.

## The shared-\(U\)-loop gate in \(\mathrm I_r\)

In type \(\mathrm I_r\), name the two \(A B\) marks \(z_1,z_2\),
the \(A w_1\) mark \(x\), the \(B w_2\) mark \(y\), and the
\(w_1w_2\) mark \(f\).  Both shores have two unmarked ports toward
\(u_1,u_2\).  Suppose **each actual shore BF relation contains the
loop \([u_1u_2]\)**.  Independently relabel the six slots of these
genuine local rows as follows:
\[
\begin{array}{c|ccc}
 &1,2&3,4&5,6\\\hline
A^\circ&\{z_1,z_2,x\}&\{u_1\}&\{u_2\}\\
B^\circ&\{u_2\}&\{z_1,z_2,y\}&\{u_1\}
\end{array}.                                                    \tag{7}
\]
The two \(A B\) shore-half labels are disjoint, giving terminal
labels \(T_{z_1}=T_{z_2}=56\).  At \(u_1,u_2\), the labels on
\(u_1w_1,u_2w_2\) are respectively \(R_1=12,R_2=34\).

Let \(D_x,D_y\) label the \(w_1,w_2\)-side halves of \(x,y\), and
let \(F_1,F_2\) label the two halves of \(f\).  The following three
choices all partition \([6]\) at both singleton vertices and at the
subdivision vertex of \(f\):
\[
\begin{array}{c|cccc|ccccc|c}
&D_x&F_1&D_y&F_2&T_{z_1}&T_{z_2}&T_x&T_y&T_f
 &\text{outer loop}\\\hline
1&56&34&56&12&56&56&34&12&56&[xy]\\
2&34&56&56&12&56&56&56&12&34&[yf]\\
3&56&34&12&56&56&56&34&56&12&[xf]
\end{array}.                                                    \tag{8}
\]
All marked subdivision vertices have their two shore/connector
halves and terminal label partitioning \([6]\).  Each slot is
therefore an actual outer perfect matching, and every edge has load
two.  The two outer triple slots are \(5,6\) in all three rows.
Their missing pairs \(xy,yf,xf\) form a triangle, which cannot lie
inside the five-cycle of allowed Case-XII loops.  Consequently
\[
\boxed{\mathrm I_r\text{ in exact Case XII }
\Longrightarrow\text{ at least one shore lacks }[u_1u_2].} \tag{9}
\]
In particular, two \(L^*\) shores are impossible in this quotient;
the same holds for an \(L^*\) shore opposite a pentagon whose two
\(U\)-ports are adjacent, or for two such pentagons.  A three-vertex
tree shore cannot support this particular loop because its centre
port is one of \(u_1,u_2\).  The other shore pairs are not decided by
this gate.

[Note 213](../notes/213-three-star-rectangles-exclude-two-rstar-shores-in-ir.md)
uses all four leaves of the Figure-7 \(R^*\) relation and three
explicit connector templates to force \([xy],[xf],[yf]\) whenever
both shores have complete \(R^*\) support.  Thus the \(R^*\)--\(R^*\)
combination in \(\mathrm I_r\) is also excluded, independently of
the shared-\(U\)-loop gate above.

For \(\mathrm {II}_B\),
[Note 214](../notes/214-three-star-rectangles-exclude-two-rstar-shores-in-iib.md)
gives four-leaf connector templates forcing \([xy],[xq],[yq]\)
for two complete \(R^*\) relations, so this combination is
excluded as well.  Together with (L), the \(\mathrm I_s\)
alternative-cut argument, the \(\mathrm I_m,\mathrm I_r\) results,
and (A) for \(\mathrm {II}_A\), both five-cut shores cannot be
cyclic nonpentagons in any of the five two-vertex quotient types.

[Note 215](../notes/215-an-alternative-five-cut-excludes-the-iia-two-shore-quotient.md)
also excludes the entire \(\mathrm {II}_A\) quotient.  The alternative
five-cut \(X=A\cup\{u_1,u_2,w_1,t_x\}\) in the whole host has
five boundary edges, while \(w_1\)'s three neighbours all carry
cut ports.  Its five-pole lacks both an all-terminal matching and
the loop on its other two ports, contradicting both Case-XIII
relations.  The quotient types still requiring full matching
closure are \(\mathrm I_m,\mathrm I_r,\mathrm {II}_B\).

For one mixed \(\mathrm I_m\) branch,
[Note 216](../notes/216-a-tree-rstar-im-shore-forces-a-single-minority-port-placement.md)
uses the actual tree types and three connector rows.  If the tree
centre is \(u_1\) and its end-port groups are
\(\{u_2,z\}\mid\{x,p\}\), exact Case XII forces
\(c_B(yu_2)=c_B(yz)=c_B(yq)\ne c_B(yu_1)\), leaving only
\((y,u_1)=(2,4),(4,3)\) in the Figure-7 labelling.  The other
tree partition needs full closure.
[Note 217](../notes/217-the-first-tree-rstar-im-end-partition-is-impossible.md)
uses four further actual connector rows to exclude both of these
remaining port placements, closing this first tree end partition.
[Notes 218--220](../notes/220-the-two-rstar-private-ports-agree-at-the-direct-mark.md)
handle the other end partition \(\{u_2,x\}\mid\{z,p\}\):
two actual pair transports and four-loop rectangles force
\(c_B(yz)=c_B(qz)\), leaving the twenty-four necessary relative
orders in Note 220, (4). These are not realizations of exact
Case XII.
[Note 221](../notes/221-a-shared-z-star-forces-an-outer-xz-loop-in-im.md)
eliminates twelve of those orders by a further actual six-slot
loop transport; the other twelve remain only necessary placements.
[Note 222](../notes/222-a-yq-u2z-row-forces-the-forbidden-yq-pz-pair.md)
eliminates four more orders with a genuine outer \((yq)(pz)\)
row, leaving eight necessary orders in this tree--\(R^*\) branch.
They have \(\{y,q\}=\{2,4\},(z,u_2)=(3,1)\) or \((3,5)\),
or \(\{y,q\}=\{3,4\},(z,u_2)=(1,2)\) or \((5,2)\), with
either orientation of \(y,q\). In each, existing genuine loops
force one of the cycles \(p-y-x-q-z-p\) and
\(z-y-x-q-p-z\). Their forbidden-pair sets have the common
states \(yq,xp,xz\). A genuine outer BF pair on two of these
three states, or a forbidden loop in the corresponding cycle,
would close this particular tree end partition.
[Note 223](../notes/223-a-yq-u1y-row-forces-the-forbidden-yq-xz-pair.md)
constructs the actual outer pair \((yq)(xz)\) from local
\((yq)(u_1y)\), excluding six of these eight orders.
[Note 224](../notes/224-the-im-tree-rstar-shore-pair-is-impossible.md)
transports \((yq)(u_1q)\) at the final two orders to
\((yq)(xz)\) as well.
Together with Note 217 and the girth-five four-cycle at the
third tree end partition, this closes every tree--\(R^*\)
shore order in the genuine \(I_m\) quotient.

The first tree--ordinary-pentagon restriction is
[Note 225](../notes/225-a-tree-pentagon-im-shore-cannot-have-the-two-shared-u1-neighbours.md).
For a tree centred at \(u_1\) with ends
\(\{u_2,z\}\mid\{x,p\}\), the pentagon cannot have both
\(u_1u_2\) and \(u_1z\) as port-cycle edges. The two possible
orders are excluded by actual six-slot transports. Other tree--pentagon
orders still require the full connector closure.

The published order-36 BF verification gives a stronger order filter:
[Note 226](../notes/226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md)
proves \(|V(H)|\ge33\) for any connected simple
exact-Case-XII pole, by completing it with the
forbidden pentagon. In the present \(|U|=2\) quotient, this is
\(\rho\ge9\). Thus the tree--pentagon profile and every lower-rank
two-shore profile are absent from a minimum host; the six-slot
results above remain all-orders conditional closure statements.
