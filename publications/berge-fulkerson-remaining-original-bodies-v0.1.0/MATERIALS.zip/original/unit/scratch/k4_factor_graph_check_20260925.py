"""Disposable graph-level check of the proposed four-K4 attachment.

Run: python3 scratch/k4_factor_graph_check_20260925.py
Streams the 4469 port sets; enumerates PMs only on the fixed 16-vertex factor.
"""

import json
from itertools import combinations, combinations_with_replacement
from pathlib import Path
from rectangle_balanced_check_20260924 import (
    NAMES, ROWS, U, V, W, balanced_sets, table_bridges,
)


def edge(a, b):
    return tuple(sorted((a, b)))


def colour(c, offset):
    pairs = (((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2)))
    return frozenset(edge(a + offset, b + offset) for a, b in pairs[c])


def build_factor(sigma, z):
    edges = set(combinations(range(4), 2))
    masks = {name: colour(0 if name in sigma else 1 if name in z else 2, 0)
             for name in NAMES}
    port = (0, 2)
    for offset, tau in ((4, U), (8, W), (12, V)):
        a, b = port
        cuts = {edge(a, offset), edge(b, offset + 1)}
        edges.remove(port)
        edges.update(set(combinations(range(offset, offset + 4), 2))
                     - {edge(offset, offset + 1)})
        edges.update(cuts)
        for name, mask in masks.items():
            if port in mask:
                assert name not in tau
                masks[name] = (mask - {port}) | cuts | {edge(offset + 2, offset + 3)}
            else:
                masks[name] = mask | colour(1 if name in tau else 2, offset)
        port = edge(offset, offset + 2)
    return frozenset(edges), masks


def enumerate_pms(edges, unmatched=frozenset(range(16))):
    if not unmatched:
        yield frozenset()
        return
    vertex = min(unmatched)
    for e in sorted(edges):
        if vertex in e and set(e) <= unmatched:
            for rest in enumerate_pms(edges, unmatched - set(e)):
                yield rest | {e}


def check_extra_identity_example():
    source = (Path(__file__).resolve().parents[1] / "computations/bundles/"
              "global-pairing-and-full-closure-boundary/"
              "note101_global_stub_pairing_result.json")
    data = json.loads(source.read_text())
    aliases = {"r23": "r", "r34": "s", "q25prime": "qp25",
               "p1_13": "p13_1", "p3_13": "p13_3", "p2_24": "p24_2",
               "p4_24": "p24_4", "p2_25": "p25_2", "p5_25": "p25_5"}
    names = [aliases.get(n, n) for n in data["labels"]]
    incidences = [tuple(e["ends"]) for e in data["proper_edges"]]
    assert all(len(set(e)) == 2 for e in incidences)
    incidences += [(v,) for v in range(5)]
    columns = [e["column"] for e in data["proper_edges"]] + data["target_terminal_columns"]
    masks = {n: {i for i, col in enumerate(columns) if col[j] == "1"}
             for j, n in enumerate(names)}
    assert set(names) == NAMES
    assert len(data["vertices"]) == 67 and len(incidences) == 103
    assert all(sum(v in e for e in incidences) == 3 for v in range(67))
    assert all(sum(v in incidences[i] for i in mask) == 1
               for mask in masks.values() for v in range(67))
    assert all(sum(i in masks[n] for n in row) == 2
               for row in ROWS for i in range(103))
    assert masks["A"] == masks["p13_1"]
    assert masks["P3"] == masks["p13_3"]
    assert masks["P5"] == masks["p25_5"]
    print({"extra_identity_example_vertices": 67,
           "all_22_named_masks_are_actual_PM": True,
           "all_six_literal_rows": True, "A_equals_p13_1": True})


def check():
    first = next(balanced_sets())
    graph, _ = build_factor(first, next(table_bridges(first)))
    assert len(graph) == 24
    assert all(sum(v in e for e in graph) == 3 for v in range(16))
    pms = tuple(enumerate_pms(graph))
    assert len(pms) == len(set(pms)) == 13
    bf_count = sum(all(sum(e in pm for pm in row) == 2 for e in graph)
                   for row in combinations_with_replacement(pms, 6))
    assert bf_count == 42

    tested = 0
    for sigma in balanced_sets():
        edges, masks = build_factor(sigma, next(table_bridges(sigma)))
        assert edges == graph
        assert all(mask in pms for mask in masks.values())
        assert {name for name, mask in masks.items() if (0, 1) in mask} == sigma
        assert all(sum(e in masks[name] for name in row) == 2
                   for row in ROWS for e in graph)
        assert {name for name, mask in masks.items() if (5, 7) in mask} == U
        assert {name for name, mask in masks.items() if (13, 15) in mask} == V
        assert 2 - sum((5, 7) in masks[n] for n in ("r", "B", "X", "Y")) == -1
        assert 2 - sum((5, 7) in masks[n] for n in ("r", "B", "X", "D")) == -1
        assert 2 - sum((13, 15) in masks[n] for n in ("s", "Y", "C", "A")) == -1
        assert 2 - sum((13, 15) in masks[n] for n in ("s", "Y", "C", "X")) == -1
        assert masks["q25"] != masks["qp25"]
        # The construction cannot preserve this extra equality from Note 101's
        # particular local countermodel (as distinct from its abstract six rows).
        assert masks["A"] != masks["p13_1"]
        tested += 1
    assert tested == 4469
    print({"factor_vertices": 16, "factor_edges": len(graph),
           "complete_factor_PMs": len(pms), "factor_BF_multisets": bf_count,
           "port_sets_with_all_six_rows_and_four_negative_residuals": tested,
           "same_name_reuse": "preserved", "extra_A_equals_p13_1": "broken"})
    check_extra_identity_example()


if __name__ == "__main__":
    check()
