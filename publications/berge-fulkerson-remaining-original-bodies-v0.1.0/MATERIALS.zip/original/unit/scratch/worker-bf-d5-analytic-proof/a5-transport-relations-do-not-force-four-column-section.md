# A5 transport relations alone do not force a four-column section

## Decision

The five actual row transports of Note 057 do not, as relations, imply a
four-cell common singleton section.  The obstruction already occurs when
every transported relation is the smallest nontrivial alternating-cycle
cube.  Thus any positive theorem must use an additional cross-row incidence
axiom; rowwise alternating-cycle closure is exhausted.

This is a relation-level countermodel, not a cubic-pole counterexample.

## Coordinates and rows

Use the five A5 rows in the order

\[
 (13,12),(24,23),(35,34),(14,45),(25,15).
\]

After transport, row \(i\) has transported coordinates \((i,i-1)\), with
indices modulo five, and two fixed singleton coordinates.  Explicitly the
five D5 rows have coordinate sets

\[
 1235,\quad 1234,\quad 2345,\quad 1345,\quad 1245.
\tag{1}
\]

For every singleton class put

\[
 \mathcal P_i=\{0_i,1_i\}.
\]

The symbols are actual-matching *tokens*: equality means reuse of the same
matching and inequality means two distinct matchings in that boundary class.

## The five local cubes

Let each transported binary relation be the equality cube

\[
 \Theta_i=\{(0_i,0_{i-1}),(1_i,1_{i-1})\}.
\tag{2}
\]

It has exactly the form produced by Note 057.  Namely, take the two repeated
occurrences at \(i\) to be \(0_i,1_i\), take the two newly produced
occurrences at \(i-1\) in the opposite slot order, and the two crossed pairs
in equation (5) of Note 057 are precisely (2).  The involution

\[
 (0_i,0_{i-1})\longleftrightarrow(1_i,1_{i-1})
\]

is the complete one-component alternating-cycle cube.  Hence the model does
not rely on duplicated occurrences or vacuous closure.

Complete these binary relations to four-coordinate row relations by fixing
the other two coordinates as follows:

\[
\begin{array}{c|c|c}
\text{row}&\text{transported relation}&\text{fixed coordinates}\\ \hline
1&x_1=x_5&x_2=0_2,\ x_3=0_3\\
2&x_2=x_1&x_3=1_3,\ x_4=0_4\\
3&x_3=x_2&x_4=1_4,\ x_5=0_5\\
4&x_4=x_3&x_5=1_5,\ x_1=0_1\\
5&x_5=x_4&x_1=1_1,\ x_2=1_2.
\end{array}
\tag{3}
\]

Call these two-element four-coordinate relations
\(\widehat\Pi_1,\ldots,\widehat\Pi_5\), and let \(\Pi_i\) be their
five-coordinate cylinders.

## Every four-way section is empty

The fixed-coordinate conflicts in consecutive row pairs are

\[
\begin{array}{c|c}
\text{rows}&\text{conflicting coordinate}\\ \hline
(1,2)&3\\
(2,3)&4\\
(3,4)&5\\
(4,5)&1\\
(5,1)&2.
\end{array}
\tag{4}
\]

Deleting any one row from a five-cycle leaves at least one of the conflicting
adjacent pairs in (4).  Consequently

\[
 \bigcap_{i\ne i_0}\Pi_i=\varnothing
 \qquad(i_0=1,\ldots,5).
\tag{5}
\]

Thus five nonempty genuine transport cubes do not even force one of the five
four-cell joins.

## Minimality at the nondegenerate-cube level

If every \(\Theta_i\) is required to contain a nontrivial two-point cube,
both of its coordinate projections contain two distinct tokens.  Since the
five transported edges cover all five singleton classes, every
\(\mathcal P_i\) must therefore have size at least two.  The countermodel
uses exactly two tokens in each class and exactly two tuples in every
\(\Theta_i\).  It is minimal simultaneously in total token count and local
relation size under this nondegeneracy requirement.

If duplicated occurrences and zero-dimensional cubes are allowed, a still
smaller degenerate relation model is possible; it carries no additional
mathematical information.

## The missing real-incidence axiom

The countermodel deliberately does not claim that its ten tokens are the
incidence vectors of perfect matchings of one common cubic five-pole.  In a
real pole the same token \(P_i\) used in two rows must be the same global
0--1 edge vector, every row must participate in its six-perfect-matching
equation on the same edge set, and all vectors must satisfy the same cubic
vertex equations.  Note 057 applies those facts inside one row but supplies
no theorem coupling the two fixed occurrences of a singleton class in
different rows.  Model (3) violates exactly the desired reuse: each class is
fixed to opposite tokens in its two fixed rows.

Therefore the missing statement is a cross-row common-incidence/Helly axiom,
for example the following sufficient form:

> Four A5 row witnesses can be chosen so that every singleton token fixed in
> two selected rows is literally the same global perfect matching, and the
> transported cube choices agree with those fixed tokens on their shared
> coordinates.

Under that axiom the chosen tuples are a common section by definition.  It
does not follow from the five separate overlap-cell equations or from
same-boundary alternating-cycle closure.  Proving it from the common cubic
incidence equations, or realizing their failure in one genuine pole, is the
remaining pole-level problem.

No graph scan, support/load model, solver, or literature search is used.
