# Common proper-edge incidence still does not join the A5 transports

## Decision

There is no proof here that a real simple connected cubic five-pole with
complete Case-XII support must have a four-cell D5 singleton section.
However, the obstruction can be pushed strictly beyond abstract relations.
The five A5 equations admit a common 0--1 edge-incidence model in which all
vectors restrict to perfect matchings of the same cubic \(K_4\), all cover
equations hold on one edge universe, and every local transport is generated
by a genuine proper alternating \(C_4\), while all five four-row joins are
empty.  Two real-pole constraints remain unrealized: attachment of the five
boundary semiedges to terminal vertices of one connected cubic pole, and
complete-family exclusion of every \(A\), \(T\)-loop, and \(T\)--\(T\) cover.

This is therefore a strict applicability boundary, not a pole counterexample.

## Common incidence universe

Let \(A,B,C\) be the three perfect matchings of \(K_4\).  They partition
\(E(K_4)\), and \(A\triangle B\) is a proper four-cycle.  Adjoin five formal
boundary coordinates and put

\[
 E=E(K_4)\sqcup\{s_1,\ldots,s_5\}.
\]

For each singleton class define two global vectors \(P_i^0,P_i^1\).  Both
contain \(s_i\); on \(K_4\) use the phases

\[
\begin{array}{c|cc}
i&P_i^0&P_i^1\\ \hline
1&B&A\\
2&A&B\\
3&B&A\\
4&B&A\\
5&B&A.
\end{array}                                                    \tag{1}
\]

Thus every pair \(P_i^0,P_i^1\) is exchanged by the same genuine alternating
cycle \(A\triangle B\).  For every pair \(r\subset[5]\), let \(Q_r\) (and
similarly \(R_r\)) use \(C\) on \(K_4\) and the three formal semiedges whose
indices lie outside \(r\).

## Five exact overlap equations

Use the rows

\[
(13,12),(24,23),(35,34),(14,45),(25,15)
\]

and choose their two fixed singleton vectors as

\[
\begin{array}{c|cc}
\text{row}&P_a&P_j\\ \hline
1&P_3^0&P_2^0\\
2&P_4^0&P_3^1\\
3&P_5^0&P_4^1\\
4&P_1^0&P_5^1\\
5&P_2^1&P_1^1.
\end{array}                                                    \tag{2}
\]

In each row, \(P_i^0+P_i^1=A+B\), and the two vectors in (2) also sum to
\(A+B\) on the core.  Hence

\[
 Q_{ia}+R_{ij}+P_i^0+P_i^1+P_a+P_j=2\mathbf1_E.       \tag{3}
\]

Equation (3) also holds on every boundary coordinate: the two triple vectors
use the complements of \(ia\) and \(ij\), while the singleton occurrences
are \(i,i,a,j\).

## Transport cubes and empty joins

For row \(i\), with transported classes \(i\) and \(b=i-1\) in the cyclic
order, let \(\Theta_i\) consist of the two pairs whose \(K_4\) phases are
opposite.  The two fixed vectors already have opposite phases, so either
transport tuple contributes \(2A+2B\); together with
\(Q_{ab}+R_{ij}=2C\) it is another exact double cover.  Simultaneously
toggling \(A\triangle B\) exchanges the two tuples.  Thus all five
\(\Theta_i\) are nondegenerate actual-incidence one-cycle cubes on the same
cubic core.

Nevertheless, consecutive rows fix opposite global vectors in a common
singleton class:

\[
\begin{array}{c|c|c}
\text{rows}&\text{class}&\text{fixed vectors}\\ \hline
(1,2)&3&P_3^0,P_3^1\\
(2,3)&4&P_4^0,P_4^1\\
(3,4)&5&P_5^0,P_5^1\\
(4,5)&1&P_1^0,P_1^1\\
(5,1)&2&P_2^1,P_2^0.
\end{array}                                                    \tag{4}
\]

Deleting any one row leaves at least one conflicting adjacent pair in (4).
Therefore every four-row cylinder intersection is empty.

## Exact missing hypothesis

This model has one proper-edge universe, global 0--1 vectors, the common
cubic vertex equations on all four vertices of \(K_4\), exact six-vector
double covers, and genuine same-boundary alternating-cycle exchange.  It is
not a five-pole because the five formal semiedges are not incident with five
distinct terminal vertices in the same connected cubic graph.  Consequently
the vectors do not satisfy the terminal-attachment vertex equations of one
real pole.  Moreover, the construction specifies the five positive overlap
rows and their transports; it does not assert that the complete family of
its formal vectors has exactly the forty Case-XII types.  In particular it
is not a model of the global negative support assumptions.

Hence common proper-edge incidence and alternating-cycle closure cannot by
themselves prove the D5 join.  A positive proof must jointly use the missing
common terminal-vertex incidence and complete-family negative support,
together with connectedness, to force cross-row reuse of singleton perfect
matchings.  Whether those full real-pole constraints do so remains undecided.

No solver, graph scan, support/load-only model, or literature search is used.
