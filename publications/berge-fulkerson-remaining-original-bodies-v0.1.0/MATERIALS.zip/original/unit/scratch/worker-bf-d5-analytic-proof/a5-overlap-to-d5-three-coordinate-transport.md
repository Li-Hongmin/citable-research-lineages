# A5 overlap cells induce three-coordinate transports into D5

## Setup

Put

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Assume a real cubic \(5\)-pole has no \(T\)-loop and no \(T\)--\(T\) BF
type.  Use the cyclic five overlapping cells

\[
\mathcal A_5=
\{(13,12),(24,23),(35,34),(14,45),(25,15)\}.          \tag{1}
\]

In the \(i\)-th cell the two boundary pairs share exactly terminal \(i\);
the five \(S\)-classes and five \(T\)-classes both occur once.  The
corresponding disjoint D5 cells are

\[
\mathcal D_5=
\{(35,12),(14,23),(25,34),(13,45),(24,15)\}.          \tag{2}
\]

## Three-coordinate transport theorem

Fix one row of (1).  Write it as

\[
 s=ia\in S,\qquad t=ij\in T,
\]

and let \(s^*=ab\in S\) be the unique state disjoint from \(t\).  The choice
in (1) is precisely such that \(s\) and \(s^*\) share \(a\).  An actual
overlap witness is

\[
 Q_{ia}+R_{ij}+P_i^0+P_i^1+P_a+P_j=2\mathbf1.        \tag{3}
\]

The two occurrences at \(i\) are not identified.  Group (3) into halves

\[
 A=Q_{ia}+P_i^0+P_a,\qquad
 B=R_{ij}+P_i^1+P_j.                                  \tag{4}
\]

Since \(B\) has the \(T\)-state \(ij\), any \(T\)-state decomposition of
\(A\) would combine with this fixed decomposition of \(B\) to give a
forbidden \(T\)-loop or \(T\)--\(T\) cover.  Hence the state set of the
half-load multigraph \(H_A\) is a nonempty subset of \(S\), and Kempe closure
gives all of \(S\).

More is true than mere saturation.  In the colouring of \(H_A\) with state
\(ia\), switch the bichromatic terminal path that starts at \(i\) and does
not use the singleton colour class \(P_a\).  Its other endpoint must be
\(b\): after the switch the state lies in \(S\), and \(ab\) is the unique
other member of \(S\) containing \(a\).  The switch therefore gives an
actual decomposition

\[
 A=Q'_{ab}+P_a+P_b^0                                  \tag{5}
\]

with the **same actual matching \(P_a\)**.  Combining (5) with the fixed
\(B\) gives the D5 witness

\[
 Q'_{ab}+R_{ij}+P_a+P_b^0+P_i^1+P_j=2\mathbf1.        \tag{6}
\]

Thus three singleton matchings in (6), namely
\(P_a,P_i^1,P_j\), are inherited literally from the overlap witness; only
\(P_b^0\) is new.

Interchanging the two \(i\)-occurrences in (4) gives a second complementary
pair and the same argument produces

\[
 Q''_{ab}+R_{ij}+P_a+P_b^1+P_i^0+P_j=2\mathbf1.       \tag{7}
\]

Consequently every A5 witness induces an actual relation

\[
 \Theta_i\subseteq\mathcal P_i\times\mathcal P_b,
\qquad
 (P_i^1,P_b^0),(P_i^0,P_b^1)\in\Theta_i,              \tag{8}
\]

inside its corresponding D5 cell, while two other coordinates
\(P_a,P_j\) remain fixed.

If \(P_i^0\triangle P_i^1\) has several proper alternating-cycle
components, toggling any subset in \(P_i^0\) and the complementary subset in
\(P_i^1\) preserves their incidence sum.  Applying the same forced Kempe
path to every resulting grouping gives the full actual cube relation
\(\Theta_i\).  This is a genuine matching transport, not a load-only
identity.

## What A5 still does not force

Applying the theorem to all five rows of (1) gives five relations
\(\Theta_i\), one entering each D5 cell and one for each repeated singleton
class.  However the five original overlap witnesses are existentially
independent.  The theorem gives no equality between

* the fixed \(P_a,P_j\) belonging to two different rows;
* the carrier half-loads used in two different rows; or
* the values in two different transport relations \(\Theta_i\).

Hence A5 supplies five **local lifted transports**, but not a global section
of them.  A four-cell D5 join follows under the additional, exactly
checkable condition that four of the transported D5 relations admit a
common assignment of their shared singleton coordinates.  In pivot form,
after fixing one transported anchor tuple \(x\), this is precisely

\[
 \bigcap_{d\ne a}E_d(x)\ne\varnothing.                \tag{9}
\]

The present argument does not derive (9).  Alternating-cycle closure proves
the individual cube relations (8), but does not identify their bases across
the five independently chosen overlap witnesses.

## Four-value decision

* General A5-to-D5 join theorem: **not obtained**.
* Real exact-Case-XII pole violating the join: **not obtained**.
* New verifiable theorem: **obtained**--each A5 witness transports three
  literal singleton PMs into its D5 cell and induces the actual two-coordinate
  cube relation (8).
* Exact remaining condition: a four-relation section, equivalently the
  anchored pivot intersection (9).  The A5 route is unresolved only at
  cross-row equality; its within-row alternating-cycle content is exhausted.

No solver, graph generation, order scan, or literature search is used.
