# Half-load factorization saturates every Case-XII S--T column

## Question and decision

Let \(H\) be a cubic \(5\)-pole with distinct semiedges, and put

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Assume that the complete Berge--Fulkerson support of \(H\) has no
\(T\)-loop and no \(T\)--\(T\) type.  This note isolates what those negative
types force inside one actual \(S\)--\(T\) completion.  The conclusion is
stronger than existential support of one cell:

> **Column-saturation theorem.** Every actual completion in a cell
> \((s)(t)\), \(s\in S,t\in T\), extends to actual completions in all five
> cells \((r)(t)\), \(r\in S\), while retaining the same three actual
> matchings in the \(T\)-half and the same two complementary half-loads.

Consequently, under the two negative support assumptions, nonemptiness of
one cell in each of the five \(T\)-columns already implies nonemptiness of
all twenty-five \(S\)--\(T\) cells.  In particular the five D5 cells imply
the whole \(S\times T\) rectangle at the level of support flags.
More generally the \(S\)--\(T\) part of the support must have the form

\[
 S\times T_H\qquad\text{for some }T_H\subseteq T.     \tag{0}
\]

Thus its size is necessarily \(0,5,10,15,20\), or \(25\); partial rows or
columns such as \(17/25\) cannot occur once all \(T\)-loops and
\(T\)--\(T\) cells are absent.

There is a parallel saturation for an \(S\)-loop: one actual loop \([s]\)
generates every \(S\)--\(S\) cell \((r)(s)\), \(r\in S\), using one fixed
half of the loop.  It follows that, once the forbidden \(T\)-loop and
\(T\)--\(T\) types are imposed, the forty positive Case-XII pair types are
forced by only ten seeds: the five \(S\)-loops and the five D5 cells.

This does **not** prove the D5 four-cell singleton join.  The five columns
may use five different half-loads, and even within one saturated column the
five decompositions of its common \(S\)-half need not reuse the same
singleton matching at a repeated terminal.  The remaining arrow is thus
strictly a synchronization problem between five already saturated carrier
columns, not an extraction of a common \(T\)-half inside a column.

## Half-load multigraph

An actual \((s)(t)\) completion can be grouped as

\[
 \underbrace{Q_s+P_i+P_j}_{A}
 +\underbrace{R_t+P_k+P_\ell}_{B}=2\mathbf1,
 \qquad s=ij,\quad t=k\ell .                         \tag{1}
\]

If \(s\cap t\ne\varnothing\), the two singleton occurrences at the common
terminal are kept distinct by their two halves.  Each half has load one on
every semiedge.  At every internal vertex the three incident entries of
\(A\) sum to three, and (1) gives \(0\le A(e)\le2\).  Define the cubic
multigraph \(H_A\) by replacing every proper edge \(e\) of \(H\) by
\(A(e)\) labelled parallel copies; every semiedge remains single.  Thus
\(H_A\) has degree three at every internal vertex.  It need not be connected,
which is harmless below.

A decomposition

\[
 A=M_1+M_2+M_3                                      \tag{2}
\]

into incidence vectors of three perfect matchings of \(H\) is the same as
a proper three-edge-colouring of \(H_A\), after assigning the two copies of
a load-two edge to the two matchings containing that edge.  Conversely a
colour class of \(H_A\), projected onto the underlying edges of \(H\), is a
perfect matching of \(H\).  No colour can use both parallel copies at one
vertex.

Since a cubic \(5\)-pole has an odd number of internal vertices, every
perfect matching uses an odd number of semiedges.  The three colour classes
therefore split the five semiedges as \(3+1+1\).  Let

\[
 \mathcal R(A)\subseteq\binom{[5]}2                 \tag{3}
\]

be the set of the two singleton-terminal positions occurring among all
decompositions (2).  In particular \(s\in\mathcal R(A)\) and
\(t\in\mathcal R(B)\), where \(B=2\mathbf1-A\).

More generally, among all BF types having two \(3+1+1\) halves, the complete
matching-level support factors as a union of rectangles

\[
 \bigcup_A
 \mathcal R(A)\times\mathcal R(2\mathbf1-A).         \tag{4}
\]

Indeed, any cover can be grouped into its two three-matching halves and
gives one rectangle member.  Conversely any decomposition of \(A\) and any
decomposition of its complement sum to \(2\mathbf1\), so they can be
combined freely.  Formula (4) is an exact consequence of the common
perfect-matching family; it is not an aggregate-load relaxation.  It does
not include the separate \(A=(12345)\) boundary type, which is not of
\((r)(r')\) form.

## The five-state Kempe lemma also holds for the half-load multigraph

The following standard closure uses only bichromatic path switches and is
valid with parallel edges and disconnected proper parts.

> **Lemma.** If
> \(\varnothing\ne\mathcal R(A)\subseteq S\), then
> \(\mathcal R(A)=S\).

Choose a colouring with state \(ij\in S\).  Let \(\alpha\) be the colour on
the other three semiedges, and let \(\beta,\gamma\) be the singleton colours
at \(i,j\), respectively.  The \(\alpha\beta\)-component starting at \(i\)
is a terminal path ending at some \(k\notin\{i,j\}\).  Switching that path
changes the state from \(ij\) to \(kj\).  Since every state is assumed to
lie in \(S\), \(kj\) must be the unique other member of \(S\) containing
\(j\).  Similarly an \(\alpha\gamma\)-switch reaches the unique other
member of \(S\) containing \(i\).  Repeating these two moves traverses the
line graph of the pentagon \(S\), which is again a connected \(5\)-cycle.
Hence all five states occur.

## Proof of column saturation

Return to (1), and suppose for contradiction that
\(r\in\mathcal R(A)\cap T\).  Choose any decomposition of \(A\) with state
\(r\), and combine it with the **fixed** actual decomposition

\[
 B=R_t+P_k+P_\ell
\]

from (1).  By \(A+B=2\mathbf1\), these six actual perfect matchings form a
BF cover.  If \(r=t\), its type is the forbidden \(T\)-loop \([t]\); if
\(r\ne t\), its type is the forbidden \(T\)--\(T\) cell \((r)(t)\).
Therefore

\[
 \mathcal R(A)\cap T=\varnothing.
\]

The ten pairs split as \(S\sqcup T\), while \(s\in\mathcal R(A)\), so

\[
 \varnothing\ne\mathcal R(A)\subseteq S.
\]

The Kempe lemma gives \(\mathcal R(A)=S\).  For every \(r=ab\in S\), choose
an actual decomposition

\[
 A=Q_r+P_a^{(r)}+P_b^{(r)}.                           \tag{5}
\]

Combining (5) with the fixed three matchings of \(B\) yields an actual
\((r)(t)\) completion.  Both the \(T\)-half and the two incidence vectors
\(A,B\) are unchanged.  This proves the theorem.

The same argument gives a useful orientation of every complementary
half-load pair that occurs in a support with no \(T\)-loop and no
\(T\)--\(T\) type:

\[
 \boxed{
 \text{at least one of }\mathcal R(A),\mathcal R(2\mathbf1-A)
 \text{ is exactly }S.}                               \tag{6}
\]

If both sides contained a \(T\)-state, their two decompositions would form
a forbidden \(T\)-loop or \(T\)--\(T\) cover.  Hence one side is a nonempty
subset of \(S\), and the lemma applies.

Equivalently, every rectangle in the exact factorization (4) has one shore
equal to \(S\).  Projecting these rectangles to \(S\times T\) proves (0)
without choosing a distinguished witness.

For an \(S\)-loop \([s]\), group its six matching occurrences into two
three-matching halves, each having state \(s\).  By (6), one half, say
\(A\), has \(\mathcal R(A)=S\).  Keeping the actual decomposition of the
other half fixed at state \(s\) and varying the decomposition of \(A\)
produces \((r)(s)\) for every \(r\in S\).  Therefore the five \(S\)-loops
generate all fifteen \(S\)--\(S\) types.  Together with column saturation
of the five D5 cells, this proves the promised support compression:

\[
 \boxed{
 \begin{array}{c}
 \text{no \(T\)-loop and no \(T\)--\(T\),}\\
 \text{five \(S\)-loops + five D5 cells}
 \end{array}
 \Longrightarrow
 \text{all forty positive Case-XII pair types}.}       \tag{6a}
\]

Conversely those ten seed types are among the forty, so (6a) is an
equivalence at the level of positive pair-type support under the fixed
negative assumptions.  The assertion says nothing about the separate
\(A=(12345)\) type, which must still be forbidden independently.

## Exact remaining interface

For a fixed load \(A\) and \(r=ij\in\mathcal R(A)\), let

\[
 \mathcal F_r(A)=\{(P_i,P_j):
 A=Q_r+P_i+P_j\text{ for some }Q_r\}.                 \tag{7}
\]

If a \(T\)-half decomposition \(b=(R_t,P_k,P_\ell)\) has complement \(A\),
then the whole column contributed by this one carrier is the rectangle

\[
 \mathcal F_r(A)\times\{(P_k,P_\ell)\}
 \qquad(r\in S),                                     \tag{8}
\]

with the two same-class occurrences kept distinct in overlapping cells.
Thus exact Case-XII support provides five nonempty saturated columns of the
form (8), one for each \(t\in T\).  It does not identify their loads \(A_t\),
their fixed \(T\)-half singleton pairs, or the values in
\(\mathcal F_r(A_t)\).

Consequently the D5 gate is reduced to

\[
 \boxed{
 \begin{array}{c}
 \text{five saturated complementary-carrier columns, one for each }t\in T
 \\
 \Longrightarrow\ ?\ \text{a four-column common singleton tuple.}
 \end{array}}                                        \tag{9}
\]

Ordinary Kempe closure has now been fully spent: it proves saturation of
each column, but it supplies no equality between singleton colour classes
belonging to two different loads \(A_t\).  Likewise a generic one-edge
delta-matroid exchange cannot supply that equality, since same-boundary
perfect matchings can differ on a proper alternating cycle of length six.
Any further positive proof must couple the five complementary carrier pairs
inside the one underlying cubic pole.  A strict negative result must realize
those five pairs together with the exact forty support and make every
four-column join empty.

## Four-value decision

* General D5 join proof: **not obtained**.
* Real exact-forty counterexample: **not obtained**.
* Strict analytic theorem: **obtained** -- half-load factorization (4),
  one-sided exact-\(S\) orientation (6), automatic saturation of every
  \(S\)--\(T\) column, and the ten-seed support compression (6a).
* Route status: the within-column extraction problem is **closed**.  The
  remaining unresolved quantifier exchange is only across the five
  saturated columns in (9).

No graph enumeration, solver call, or literature search is used.
