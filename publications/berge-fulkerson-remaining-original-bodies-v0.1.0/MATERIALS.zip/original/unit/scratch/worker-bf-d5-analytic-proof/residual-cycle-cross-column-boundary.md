# Residual cycle systems do not synchronize saturated D5 columns

## Exact question

Let \(H\) be one simple connected cubic \(5\)-pole.  For the five
\(T\)-columns of the Case-XII D5 interface, choose complementary
three-matching half-loads

\[
 A_t+B_t=2\mathbf1,\qquad t\in T,
\]

where the \(S\)-side carrier \(A_t\) is saturated:
\(\mathcal R(A_t)=S\).  Does the common cubic incidence of the five load
vectors force a four-column common singleton tuple?

This note tests only the proposed residual-cycle mechanism.  It neither
searches graph orders nor changes the existing D5 relation.

## What cubic incidence really gives between two columns

Put

\[
 D_{tu}=A_t-A_u=B_u-B_t.
\]

Every half-load has value one on each semiedge and total incident load three
at every internal vertex.  Hence \(D_{tu}\) vanishes on the semiedges and,
at every vertex \(v\),

\[
 \sum_{e\ni v}D_{tu}(e)=0.                            \tag{1}
\]

Colour every positive copy of an edge red and every negative copy blue.
Equation (1) says that the red and blue degrees agree at every vertex.
Pairing red and blue half-edges locally and following the pairs decomposes
\(D_{tu}\) into proper closed trails whose signs alternate.  Each trail has
even length.  Thus cross-column residuals always admit an alternating
circuit decomposition.

Two qualifications are essential.

1. The decomposition is not canonical.
2. The residual need not be a vertex-disjoint \(2\)-regular graph.  Each
   individual defect set
   \(\{e:A_t(e)\ne1\}\) is a disjoint union of alternating even cycles, but
   the defect cycles of \(A_t\) and \(A_u\) may cross.  Their difference can
   have red and blue degree two or more at the same vertex and only splits
   after a choice of local pairings.

So the strongest unconditional base-space statement is the balanced
alternating-circuit decomposition above, not a common \(2\)-factor or a
canonical cube coordinate system.

## Why even the zero residual does not identify a singleton fibre

The projection

\[
 \pi_t:(R_t,P_i,P_j)\longmapsto
       \chi_{R_t}+\chi_{P_i}+\chi_{P_j}=B             \tag{2}
\]

from actual \(T\)-state decompositions to half-loads is not injective, even
for a genuine simple connected cubic \(5\)-pole satisfying the negative
\(T\)-support conditions.

The frozen order-\(15\) pole in
worker-proof/verify_exact_s_odd_half_support.py has complete Tait state
set \(S\).  A separate full-perfect-matching audit gives its complete BF
support as the fifteen \(S\)--\(S\) types together with \(A=(12345)\);
in particular it has no \(T\)-loop and no \(T\)--\(T\) type.
For state \(t=45\), the same triple matching

    R = id43 = {e5,e6,e8,e10,e11,e18,s1,s2,s3}

has two decompositions of the **same** half-load:

    (R,P4a,P5a) = (id43,id2,id1),
    (R,P4b,P5b) = (id43,id3,id0).

The singleton values are different and

\[
 P4a\triangle P4b
 =P5a\triangle P5b
 =\{e12,e13,e14,e18\},                                \tag{3}
\]

a proper alternating \(4\)-cycle.  Nevertheless both triples have exactly
the same incidence sum \(B\).  Therefore their cross-load residual is
literally zero:

\[
 B-B=0,                                               \tag{4}
\]

while both singleton coordinates change.

This is a real common-cubic-incidence counterexample to every implication
of the form

\[
 \text{half-loads and their residual alternating circuits}
 \Longrightarrow
 \text{equality of the underlying singleton matchings}. \tag{5}
\]

It is not a Case-XII counterexample: the pole has no \(S\)--\(T\) support.
Its role is narrower and decisive--it shows that the residual base space
forgets exactly the fibre datum needed by the D5 join.  In this example the
complement \(2\mathbf1-B\) is not decomposable; otherwise its decomposition
would combine with the displayed \(T\)-state decomposition and create an
\(S\)--\(T\), \(T\)-loop, or \(T\)--\(T\) type, contrary to the complete
support audit.  Thus the example does not rule out a new theorem that uses
the additional fact that a relevant \(B_t\) has an \(S\)-saturated
decomposable complement \(A_t\).  It rules out only the attempt to recover
the fibre from the residual load and ordinary cubic matching incidence
alone.

## The correct bundle, and the additional structure a proof would need

The five carrier loads form only the base of a decomposition bundle.  Over
a half-load \(B\), the fibre consists of actual triples
\((R_t,P_i,P_j)\) satisfying (2).  Alternating circuits in
\(B-B'\) live in the base; alternating cycles such as (3) can also move
inside one fibre.  Neither kind of circuit supplies a distinguished lift.

Consequently, converting the finite complete-cube UNSAT observations into a
real-pole theorem would require at least both of the following extra facts:

1. **residual liftability:** every selected alternating residual circuit
   between relevant carriers lifts to simultaneous actual matching
   exchanges in the required boundary classes;
2. **flat fibre transport:** the lifted transport is path-independent on
   the singleton coordinates used by the D5 cells (equivalently, its
   holonomy fixes an actual singleton tuple).

Complete symbolic-cube models impose coordinate-complete vector fibres by
construction, but no theorem identifies those coordinates with such a flat
lift in an actual pole.  Actual perfect-matching families need not even be
fibre-faithful: (3)--(4) already give two points over one base load.  Even
injectivity of (2) would not by itself prove the D5 join, because five
distinct carrier loads would still need flat transports between their
fibres.  Thus “unique carrier decomposition” is neither available nor
sufficient.

There is no failure of ordinary cube closure *inside one matching class*.
For two same-boundary perfect matchings \(M,N\), the components of
\(M\triangle N\) are vertex-disjoint proper alternating cycles, and toggling
any subset produces another matching in the same class.  Hence every pair
does generate its own complete Boolean cube.  What is missing is a
**coordinated** cube shared by the several singleton and triple classes and
compatible with the five different carrier loads.  The cycles, dimensions,
and projections of the pairwise cubes can vary from fibre to fibre; (3)
exhibits a nontrivial vertical cube even when the carrier load does not move.
This is why a bounded common-coordinate cube UNSAT cannot be read as a
theorem about arbitrary real PM fibres.

At the exact D5 quantifier level, the sharp sufficient condition remains
the anchored pivot condition.  For an anchor tuple \(x\) and its three
extension fibres \(E_d(x)\), one needs

\[
 \bigcap_d E_d(x)\ne\varnothing.                      \tag{6}
\]

Median/tree exchange plus convexity and pairwise overlap is one genuine
structural way to force (6).  A residual-cycle proof would have to derive
those fibre properties through a flat lift; base-load identities alone
cannot do so.

## Four-value decision

* General four-column join proof: **not obtained**.
* Real exact-forty pole with all joins empty: **not obtained**.
* Strict real boundary: **obtained**--identical half-load and zero residual
  can carry two different actual singleton fibres in a pole with no
  \(T\)-loop or \(T\)--\(T\) support.
* Route status: **closed** for load sums, residual \(2\)-regular systems,
  Farkas expressions depending only on those loads, and complete-cube
  arguments lacking a proved flat lift to actual matching fibres.  A theorem
  coupling fibre transport to the \(S\)-saturated complementary half is not
  refuted and is exactly the remaining possible refinement.

The live mathematical question is therefore not a further identity among
the five \(A_t\).  It is whether exact Case-XII support forces flat
cross-column transport in the decomposition bundle, or directly forces the
pivot intersection (6).
