# Common singleton sections at the real Case-XII interface

## Question

Put

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and let \(H\) be a simple connected cubic 5-pole with five distinct
terminals.  The target hypothesis is that the complete BF-type support of
\(H\) is the published Case-XII set

\[
 \mathcal L_{\rm XII}
 =\{[s]:s\in S\}
  \cup\{(s)(s'):s,s'\in S\}
  \cup\{(s)(t):s\in S,t\in T\},
\tag{XII}
\]

with no \(A=(12345)\) type and no \(T\)--\(T\) type.  The proposed
``common section'' is stronger than the existential support statement: one
wants fixed matchings \(Q_s\) in every triple class \(s\in S\), fixed
matchings \(R_t\) in every triple class \(t\in T\), and one singleton
matching \(P_i\) in each class \(\mathcal P_i\), so that all 25
\(S\)--\(T\) completions use this same singleton family (with the required
repetition at the common terminal when \(s\cap t\ne\varnothing\)).

The support hypothesis only says

\[
 \forall(s,t)\in S\times T\;\exists\text{ a completion witness},
\]

where the witness may use different perfect matchings for every cell.  The
desired assertion is an exchange of quantifiers and therefore requires a
reuse theorem; it is not a consequence of the definition of support.

Equivalently, form the finite witness hypergraph whose vertex parts are the
sets \(\mathcal Q_s\), \(\mathcal R_t\), and \(\mathcal P_i\), and whose
hyperedges are the actual six-matching completions.  The 40-type hypothesis
says that each of the 25 cell projections of this hypergraph is nonempty.
The proposed conclusion asks for a rectangular sub-hypergraph containing one
vertex \(Q_s\) in each S part, one \(R_t\) in each T part, and one \(P_i\) in
each singleton part.  No Helly or rectangularity property for this witness
hypergraph follows from the cubic matching axioms in the permitted data.

## The loop relation bundle

For each terminal position let

\[
 \mathcal P_i=\{P:P\text{ uses exactly semiedge }i\},
\]

and for distinct \(i,j\) let

\[
 R_{ij}=\{(P,Q)\in\mathcal P_i\times\mathcal P_j:P\cap Q=\varnothing\}.
\]

The complementary pentagon has cyclic order

\[
 (v_0,v_1,v_2,v_3,v_4)=(1,4,2,5,3).
\]

Correction on the loop types: a general loop BF witness has two occurrences
in each of three boundary classes and satisfies

\[
 \chi_{Q^0}+\chi_{Q^1}+\chi_{P_i^0}+\chi_{P_i^1}
 +\chi_{P_j^0}+\chi_{P_j^1}=2\mathbf 1. \tag{L0}
\]

The boundary type does **not** identify the two occurrences in a class.
Therefore a loop type does not, by itself, imply
\(R_{ij}\ne\varnothing\).  A disjoint singleton pair follows only from
the special doubled-Tait subcase

\[
 2\chi_{P_i}+2\chi_{P_j}+2\chi_{Q_{ij}}=2\mathbf 1. \tag{L1}
\]

This requires an additional splitting or Tait-colourability theorem.  Even
if all five loops happen to admit the subcase (L1), the resulting nonempty
relations do **not** by themselves give a common choice of one matching in
every layer.  A section is the strictly stronger condition

\[
 P_{v_k}\in\mathcal P_{v_k},\qquad
 (P_{v_k},P_{v_{k+1}})\in R_{v_kv_{k+1}}quad(k\bmod5).
\tag{Sec}
\]

If (Sec) holds, put \(m(e)=|\{k:e\in P_{v_k}\}|\).  The indices of
matchings containing any fixed edge form an independent set of the
pentagon, so \(m(e)\le2\).  At each cubic internal vertex the three incident
multiplicities sum to five, hence are \((2,2,1)\).  The multiplicity-one
edges form a perfect matching \(P_0\), and

\[
 P_0,P_{v_0},\ldots,P_{v_4}
\]

is an \(A=(12345)\) BF cover.  Consequently

\[
 \mathcal C(H)=\mathcal L_{\rm XII}\quad\Longrightarrow\quad
 \text{(Sec) is false}.
\tag{1}
\]

Thus proving that (XII) forces a section would prove that no real pole with
the Case-XII support exists.  It is not an intermediate fact compatible with
the no-\(A\) hypothesis.

## What the permitted real PM data decide

The existing complete-PM certificates give two opposite, rigorous
boundaries.  They use the same cubic-pole perfect-matching incidence rather
than an abstract route model.

### Exact-‘S’ pole: loops without a section

The order-13 C10 pole of Notes 005 and 007 has

\[
 H_{\rm Tait}=S,
\]

and each of its five loop relations has exactly two real relation edges.  The
ten edges form a connected double cover \(C_{10}\to C_5\), so (Sec) has no
solution.  Nevertheless all five loop BF covers exist.  Closing over all 31
perfect matchings adds an \(A\)-cover and 17 actual \(S\)--\(T\) support
types; this pole is therefore not a 40-type Case-XII pole.

This is a real common-cubic-incidence obstruction to the implication

\[
 \text{five genuine Case-XII loops}\Rightarrow\text{common section}.
\]

It also shows that a proof cannot use only the five local equations (L).

### Full \(S\)--\(T\) support without exact-‘S’

The order-13 all-SS pole of Note 024 has 37 perfect matchings and all 25
actual \(S\)--\(T\) completion cells.  Its active matching-level graph is
connected, every disjoint completion has route SS, and no \(A\)-cover exists.
Its Tait state set is instead the whole \(K_5\); the complete closure also
contains the missing \(T\)-loop and \(T\)--\(T\) types.  Hence it is not a
Case-XII pole, but it proves that full \(S\)--\(T\) support, connected actual
PM incidence, and no \(A\) do not force a common section after exact-‘S’ is
removed.

The two rows isolate the missing implication:

\[
\begin{array}{c|c|c|c|c}
\text{pole}&\text{exact-}S&\text{five-loop section}&A&\text{all 25 }S\text{--}T\\ \hline
\text{C10 order 13}&\text{yes}&0&\text{yes}&17\\
\text{all-SS order 13}&\text{no}&\text{not applicable}&\text{no}&25
\end{array}
\]

No permitted real-PM datum supplies a pole satisfying all entries of (XII),
and no implication from those data to (Sec) has been proved.

## Sharp additional condition

The exact condition that would make the proposed route work is a
**loop-to-​completion common-incidence lift**.  Along a spanning set of the
actual \(S\)--\(T\) completion edges and same-class alternating-cycle exchange
edges, singleton witnesses must be transportable while preserving their
terminal positions and all five disjointness relations.  The transported
relation bundle must return to the same singleton choices around every
pentagon cycle (equivalently, it must contain a section (Sec)).  Under this
condition the multiplicity argument above gives an \(A\)-cover immediately.

The fully rectangular version (fixed \(Q_s,R_t,P_i\) for all 25 cells) is
spelled out algebraically in
`worker-bf-common-pm-proof/common-pm-section-boundary.md`; the argument there
does not assume that the pole is Tait-colourable.

A slightly different but useful sufficient condition is already visible in
the ten \(S\)--\(S\) cells.  If fixed \(Q_s\) and fixed \(P_i\) realize all
off-diagonal \(S\)--\(S\) cells with the same singleton family, set

\[
 C_s=\chi_{Q_s}+\sum_{i\in s}\chi_{P_i}.
\]

Each cell gives \(C_s+C_{s'}=2\mathbf 1\).  Since the graph on the five
vertices \(S\) is the complete graph (in particular it contains an odd
cycle), these equations force \(C_s=\mathbf 1\) for every \(s\).  For
\(s=ij\), this yields \(P_i(e)+P_j(e)\le1\) on every edge, and the same
load-one argument produces an \(A\)-cover.  Thus even a same-role
rectangular section for the ten \(S\)--\(S\) cells is incompatible with
Case XII; the full 25-cell rectangle is not needed for the contradiction.

This condition is genuinely stronger than:

* nonempty five loop relations;
* all 25 existential \(S\)--\(T\) cells;
* connectedness of the matching-level graph \(W(H)\);
* coherent route labels, integer loads, or their modular projections.

The C10 pole realizes the first failure (nontrivial holonomy/no section), and
the all-SS pole realizes the second failure once exact-‘S’ is deleted.

## Decision

Within the allowed input and without a new high-order census, the proposition

\[
 \text{real common cubic PM incidence} + (XII)
 \Longrightarrow \text{a common singleton section}
\]

is **not decided**.  There is neither a real 40-type pole nor a proof that
the 40-type support forces a section.  The correct current statement is the
sharp conditional implication

\[
 \text{loop-to-completion common-incidence lift}
 \Longrightarrow (\mathrm{Sec})
 \Longrightarrow A,
\]

so any genuine Case-XII exclusion must establish that lift (or another
common-perfect-matching theorem).  The current data do not justify upgrading
this interface to the S-level BF route.

## Reproduction

The two real-PM boundary checks are reproduced by

```text
python3 units/berge-fulkerson/scratch/worker-real-exact-s-no-a/audit_loop_incidence_interface.py
```

The deterministic terminal line is

```text
LOOP_INCIDENCE_INTERFACE_AUDIT_OK
```

This leaf does not modify permanent notes or perform a new graph census.
