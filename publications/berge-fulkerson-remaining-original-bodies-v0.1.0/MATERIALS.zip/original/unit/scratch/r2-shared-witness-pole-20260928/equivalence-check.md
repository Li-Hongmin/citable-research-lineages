# 式 (13) 的等价性：目标可入每个 core，但对侧见证域尚未定义

2026-09-28。核验对象是 [冻结 SPEC](../../SPEC-2026-09-23-case-xii-rectangle.md) 中的十六上下文，以及 [实际五极笔记](actual-shared-witness-phase-obstruction.md) 的式 (13)。

**结论。** 对任何已经精确定义、且不随待选 \(P,N\) 改变的合法对侧见证域，式 (13) 的消元是正确的：每个 prescribed core 都允许 \(P=T\)，而 \(T+W\le K\) 足以满足已写出的 same-\(K\)、core、完整见证身份和 target-phase 条件。但来源没有指定四个 \(\mathcal O_r\) 究竟是哪几个域，也没有把“operative”的全部资格写成谓词。因此不能把现有式 (13) 无条件认证为冻结命题的等价表述；这里给出有明确定义的修正版，并在这一信息缺口处停止。这不是式 (13) 的反例，也不裁决 exact Case XII。

## 1. 来源确定的载荷、边界与十六个 core

所有匹配都表示同一 loopless cubic five-pole 的完整 \(0/1\) mask，坐标包括 proper edges 和五条有序半边。记

\[
\mathcal P_J(G)=\{M\in\mathcal P(G):\partial M=J\},
\qquad \mathcal P_i=\mathcal P_{\{i\}}.
\]

以下 \(T_r\) 表示目标匹配，不表示 Case-XII 的五个 \(T\)-states。
[Note 104](../../notes/104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md)(1)–(4),(13) 给出

\[
\begin{aligned}
H_{23}&=(r_{23},B,X),&K_{23}&=2\mathbf1-r_{23}-B-X,\\
H_{34}&=(r_{34},Y,C),&K_{34}&=2\mathbf1-r_{34}-Y-C.
\end{aligned}
\]

| 端点 \(r\)／目标 \(T_r\) | 源载荷 \(K_r\) | \(i\)，其中 \(\partial T_r=\{i\}\) | intended partner \(j\) | leakage partner \(j'\) | context 标签 |
|---|---|---|---|---|---|
| \(Y\) | \(K_{23}\) | \(3\) | \(5\) | \(1\) | \(\mathrm{ent},r_{23},B,X\) |
| \(D\) | \(K_{23}\) | \(5\) | \(3\) | \(2\) | \(\mathrm{ent},r_{23},B,X\) |
| \(A\) | \(K_{34}\) | \(1\) | \(3\) | \(4\) | \(\mathrm{ent},r_{34},Y,C\) |
| \(X\) | \(K_{34}\) | \(3\) | \(1\) | \(5\) | \(\mathrm{ent},r_{34},Y,C\) |

对非 entry 标签 \(a\)，令 \(L_a\) 为相应 fixed-half occurrence，
\(U_{r,a}=V_{\mathrm{pr}=}(L_a,T_r)\)，即两者选择同一 proper-edge incidence 的顶点集合。原定义是

\[
\mathcal C_{r,a}(T_r)=
\left\{P\in\mathcal P_i:
P=T_r\text{ outside }U_{r,a},\quad
P\triangle T_r\text{ 是 }G[U_{r,a}]\text{ 内 proper alternating cycles 的并}
\right\}.
\]

没有“至少一个环”或 \(P\ne T_r\) 的限制。取空环集即得

\[
T_r\in\mathcal C_{r,a}(T_r)
\quad\text{对全部十二个非 entry 标签成立};\qquad
\mathcal C_{r,\mathrm{ent}}(T_r)=\{T_r\}.
\tag{E1}
\]

因此这十六个 families 不是互斥分区：目标本身同时属于同一端点的四个 families。
[Note 082](../../notes/082-two-paired-splices-have-an-exact-phase-intersection-criterion.md) 明确允许空 symmetric difference；[Note 109](../../notes/109-perfect-matching-polytope-exchanges-do-not-force-the-shared-witness-intersection.md) 也没有在十二个非 entry contexts 中另加非平凡性条件。

## 2. 对侧完整见证：能精确定义的 projections 与未指定的 operative 域

采用实际五极笔记的角色约定：\(W\) 是泄漏分解中的 singleton 匹配，\(N\) 是 triple 匹配。因此

\[
P\in\mathcal P_i,\qquad W\in\mathcal P_{j'},\qquad
N\in\mathcal P_{[5]\setminus\{i,j'\}}.
\tag{E2}
\]

[Note 093](../../notes/093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)(3)–(4) 已经定义完整 carrier decomposition 及其 projection。把边界也写入定义，即

\[
\begin{aligned}
\mathcal D_{uv}(K)
&=\{(Q,U,V)\in
\mathcal P_{[5]\setminus\{u,v\}}\times\mathcal P_u\times\mathcal P_v:
Q+U+V=K\},\\
\mathcal F_u(K;v)
&=\{U:\exists Q,V\ (Q,U,V)\in\mathcal D_{uv}(K)\}.
\end{aligned}
\tag{E3}
\]

这定义的是完整 masks，而不是仅有相同边界的所有 PM。由 Note 104 的四个 opposite-state 对应关系，可精确写出以下**全 projection 版本**的候选域：

| \(r\) | \(\mathcal O_r^{\mathrm{proj}}\) | 完整的对侧行资格；表中所有量均为 actual PM |
|---|---|---|
| \(Y\) | \(\mathcal F_1(K_{34};3)\) | \(W\in\mathcal P_1\)，存在 \(Q\in\mathcal P_{245},Z\in\mathcal P_3\)，使 \(K_{34}=Q+W+Z\) |
| \(D\) | \(\mathcal F_2(K_{34};5)\) | \(W\in\mathcal P_2\)，存在 \(Q\in\mathcal P_{134},Z\in\mathcal P_5\)，使 \(K_{34}=Q+W+Z\) |
| \(A\) | \(\mathcal F_4(K_{23};1)\) | \(W\in\mathcal P_4\)，存在 \(Q\in\mathcal P_{235},Z\in\mathcal P_1\)，使 \(K_{23}=Q+W+Z\) |
| \(X\) | \(\mathcal F_5(K_{23};3)\) | \(W\in\mathcal P_5\)，存在 \(Q\in\mathcal P_{124},Z\in\mathcal P_3\)，使 \(K_{23}=Q+W+Z\) |

把相应 fixed half 加回，每一行资格都是完整的六 occurrence BF 行。\(W\) 在源分解和此对侧行中必须是同一个完整 mask；表中未要求源 triple \(N\) 等于对侧 triple \(Q\)。这些集合只依赖固定载荷及角色，不依赖 \(P\) 或源 core 标签。

但是，来源没有说应当把 \(\mathcal O_r\) 定义成此表。[Note 101](../../notes/101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md)(1),(2),(6) 另有固定 literal rows：

\[
K_{23}=q_{14}+A+C=q_{35}+P_3+P_5,
\qquad K_{34}=q'_{25}+B+D.
\tag{E4}
\]

如果“prescribed witness”指这些已选 literal occurrences，就会分别要求

\[
\mathcal O_D^{\mathrm{lit}}=\{B\},\qquad
\mathcal O_A^{\mathrm{lit}}=\{C\},\qquad
\mathcal O_X^{\mathrm{lit}}=\{P_5\}.
\tag{E5}
\]

它们分别包含于表中对应的 projections，但来源没有证明相等。对于 \(Y\)，Note 101 的六行根本没有指定 \(K_{34}\) 的 state-13 decomposition 中的某个 literal \(P_1^{34}\)；若要求这种固定 occurrence，还需指定该行及其完整 mask。Note 101 中 \(p^1_{13}=A\) 属于 \(K_{23}\) 的 state-13 行，不能仅凭下标将其视作 \(K_{34}\) 上的指定 witness。

式 (E4) 按 Note 101 使用 \(q'_{25}\)。Note 104 末段写作 \(K_{34}=q_{25}+B+D\)，不能据此认定它与 \(K_{23}\) 固定行中的 \(q_{25}\) 是同一 mask；实际五极笔记也明确区分这两个匹配。

定义缺口是实质性的：Note 104 只说“corresponding operative fibre”，Note 109 只说“the prescribed opposite-carrier operative witness”；Note 093 的 \(\operatorname{Act}(g)\) 表述也没有给出这四个端点的指定集合。直接相关的 [Note 106](../../notes/106-common-k-domination-forces-a-full-perfect-matching-completion.md)、[Note 107](../../notes/107-fixed-row-switches-do-not-preserve-the-shared-witness-context.md)、[Note 108](../../notes/108-residual-completion-identities-do-not-force-the-target-phase.md) 保留了这个未展开的资格。因此全 projection 版本、固定 literal 版本，或只在 \(D,A\) 保留 literal 的混合版本，不能未经说明互相替换。此处与 [codex-audit](codex-audit.md) 指出的定义缺口一致。

## 3. 精确修正版及证明

**命题。** 对上表任一端点 \(r\)，预先给定一个合法对侧见证集合
\(\mathcal O_r\subseteq\mathcal P_{j'}\)，其资格与 \(P,N,a\) 无关，并已包含所要求的对侧行、occurrence 和完整身份限制。对任一 prescribed context \(a\)，定义

\[
\begin{aligned}
\operatorname{Rect}_{r,a}(\mathcal O_r)
\iff\exists\;&P\in\mathcal C_{r,a}(T_r),\quad
N\in\mathcal P_{[5]\setminus\{i,j'\}},\quad W\in\mathcal O_r:\\
&K_r=P+N+W,\qquad
N+P-T_r\in\mathcal P(G).
\end{aligned}
\tag{E6}
\]

在 entry context 中最后一项由 \(P=T_r\) 自动满足，因此 (E6) 与 Note 109 对 entry 的表述一致。则

\[
\boxed{
\operatorname{Rect}_{r,a}(\mathcal O_r)
\iff
\exists W\in\mathcal O_r:\ T_r+W\le K_r.
}
\tag{E7}
\]

**必要性。** 从 (E6) 得

\[
K_r-T_r-W=N+P-T_r\in\mathcal P(G).
\]

右边非负，故逐边有 \(T_r+W\le K_r\)。

**充分性。** 给定右侧的同一个完整 \(W\)，令

\[
P=T_r,\qquad N=K_r-T_r-W.
\tag{E8}
\]

\(N\) 整数且非负。因为固定半行包含三个 actual PM，每个 cubic vertex（含 terminal vertex）的关联载荷满足

\[
\sum_{e\ni v}K_r(e)=2\cdot3-3=3,
\qquad
\sum_{e\ni v}N(e)=3-1-1=1.
\]

于是 \(N\) 在每个顶点恰选择一个 incidence，且每个坐标只能是零或一；使用共同 edge objects 保证两端一致。这是图上的 actual PM，所以属于完整 \(\mathcal P(G)\)。两个固定载荷在每条半边上均为一，故

\[
\partial N=[5]\setminus\{i,j'\},
\]

恰为规定的 leakage triple。由 (E1)，\(P\) 属于指定的那个 core；由 (E8)，same-\(K\) 恒等式成立；\(W\) 及其对侧行见证完全不变。最后

\[
N+P-T_r=N\in\mathcal P(G),
\]

所以 target phase 成立，空差分不留下未检查的分量。证毕。

由此对上述**明确定义的**矩形谓词，有

\[
\bigvee_{r\in\{Y,D,A,X\}}\ \bigvee_a
\operatorname{Rect}_{r,a}(\mathcal O_r)
\iff
\exists r\in\{Y,D,A,X\},\ W\in\mathcal O_r:\ T_r+W\le K_r.
\tag{E9}
\]

例如，取第 2 节逐项定义的 \(\mathcal O_r^{\mathrm{proj}}\)，(E9) 就是一个无歧义的“全 opposite-projection”修正版，包含表中全部对侧行约束。若另外明确规定 literal 子集，证明同样适用。若合法域仅随 context 标签变化，应先写成 \(\mathcal O_{r,a}\)；逐 context 的 (E7) 仍成立，而 (E9) 可用 \(\mathcal O_r=\bigcup_a\mathcal O_{r,a}\)。

这个证明不需要 exact negative support。若仍处在 Note 104 的四个 intended intersections 全空的条件分支，(E8) 进入的是 leakage projection \(\mathcal F_i(K_r;j')\)，不是 intended projection \(\mathcal F_i(K_r;j)\)，因此不能据此声称已取得 intended first splice。Note 104 的全类 blocker 对实际 \(T_r\) 仍然适用；它没有排除 \(T_r\) 属于 core。

## 4. “所有 context 约束”的适用边界

(E7) 检查了来源中已经写成数学条件的所有源侧约束，并在见证集合已经定义的前提下保留其全部对侧资格。它没有证明一个尚未写出的额外关系。

如果“operative”还要求对侧某个指定 row occurrence、第二个 phase、与源 \(P\) 或 \(N\) 同时共享另一个 mask，或某段依赖的二次 splice，那么必须保留相应联合谓词，不能把它压成一个未定义的 \(W\)-集合。具体地，若附加条件是

\[
\mathsf E_{r,a}(P,N,W;\rho),
\]

其中 \(\rho\) 记录对侧行及其 occurrences，则必要方向的 domination 仍成立，但反向构造还必须证明

\[
\mathsf E_{r,a}(T_r,K_r-T_r-W,W;\rho)
\]

对某个合法 \(\rho\) 成立。单独的 \(T_r+W\le K_r\) 不提供这项结论。若 \(\mathsf E\) 只依赖 \(W,\rho\)，它正好可以吸收到 (E7) 的合法见证域中，这是 (E7) 使用的充分条件。更一般的联合关系若也允许目标替换，须另行证明，不能由未定义的“operative”一词推出。

不能把 Note 106 的一般“两个任意 PM 被 \(K\) 联合支配”与本命题混同。这里被支配的一个匹配已经是目标 \(T_r\)，这才使 \(P=T_r\) 同时解决 core 和 phase；一般 pair 的 residual 未必属于目标 core。

已有十七阶例也不是 (E7) 的反例。在其中 \(r=A,W=C\) 时，新增边 \((13,15)\) 上

\[
K_{34}=0,\qquad A=1,\qquad C=0,
\]

故 \(A+C\not\le K_{34}\)。该例展示的是：一个非目标 \(P\) 的 core/shared-witness completion 不蕴含目标对的 domination；它没有满足充分性方向的前提。

## 5. 停止点：冻结表述尚缺的具体信息

要把实际五极笔记原式 (13) 认证为冻结十六上下文的等价式，需在数学定义中补齐以下信息：

1. 对 \(Y,D,A,X\) 逐项确定 witness 域：第 2 节的完整 projections、(E5) 的 literal 子集，还是其他明确子集；若 \(Y\) 要用固定 literal，须指定 \(K_{34}\) 的 state-13 对侧行及其 class-1 mask。
2. 确认指定共享色就是 (E2) 的 singleton \(W\)，并明确对侧资格是否仅要求存在表中的完整 decomposition，还是还固定 \(Q,Z\) 的身份或要求它们与源 \(P,N\) 关联。
3. 写出“operative”是否另含对侧 core、phase 或后续 splice 关系；如有，给出其量词，并说明它在 (E8) 的目标替换下是否保留。

这里不再搜索其他历史材料、不构造五极、不枚举支持，也不替冻结命题选择一种见证域。已经证明的是 (E1) 与 (E7)–(E9)；尚未定义的是原式 (13) 所量化的 \(\mathcal O_r\)。exact-Case-XII 的存在性及冻结主命题的真假均保持未判定。
