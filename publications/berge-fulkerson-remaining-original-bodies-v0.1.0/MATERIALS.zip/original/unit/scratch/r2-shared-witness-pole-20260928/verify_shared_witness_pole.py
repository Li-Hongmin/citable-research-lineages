"""One actual 17-vertex pole: shared opposite witnesses do not force phase.

Standard library only. Enumerates the PMs of two explicitly fixed tiny graphs;
there is no graph census, solver, or BF-support enumeration.
"""

from collections import defaultdict
from itertools import product


PROPER = (
    (0, 8), (0, 11), (1, 7), (1, 9), (2, 9), (2, 12),
    (3, 10), (3, 12), (4, 10), (4, 11), (5, 7), (5, 8),
    (5, 9), (6, 8), (6, 11), (6, 12), (7, 10),
)
EDGES = PROPER + tuple((v,) for v in range(5))


def perfect_matchings(order, edges):
    incident = [[i for i, edge in enumerate(edges) if v in edge]
                for v in range(order)]

    def visit(uncovered, chosen=0):
        if not uncovered:
            yield chosen
            return
        v = min(uncovered)
        for i in incident[v]:
            edge = edges[i]
            if all(u in uncovered for u in edge):
                yield from visit(uncovered.difference(edge), chosen | (1 << i))

    return tuple(sorted(visit(frozenset(range(order)))))


def boundary(mask, edges):
    return frozenset(edge[0] + 1 for i, edge in enumerate(edges)
                     if len(edge) == 1 and mask & (1 << i))


def classes(pm, edges):
    result = defaultdict(list)
    for mask in pm:
        result[boundary(mask, edges)].append(mask)
    return result


def colourings(pm, edges, i, j):
    by_boundary = classes(pm, edges)
    all_edges = (1 << len(edges)) - 1
    return tuple((q, left, right) for q, left, right in product(
        by_boundary[frozenset(range(1, 6)) - {i, j}],
        by_boundary[frozenset((i,))], by_boundary[frozenset((j,))])
        if not (q & left or q & right or left & right)
        and q | left | right == all_edges)


def select_rows():
    pm = perfect_matchings(13, EDGES)
    assert len(pm) == len(set(pm)) == 37
    states = {ij: colourings(pm, EDGES, *ij)
              for ij in ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5),
                         (2, 3), (3, 4))}
    assert all(states.values())
    for (r23, b, x), (qp25, b2, d) in product(states[2, 3], states[2, 5]):
        if b == b2:
            break
    else:
        raise AssertionError("No shared B in this fixed pole")
    for (q14, a, c), (r34, y, c2) in product(states[1, 4], states[3, 4]):
        if c == c2:
            break
    else:
        raise AssertionError("No shared C in this fixed pole")
    named = dict(r23=r23, B=b, X=x, qp25=qp25, D=d,
                 q14=q14, A=a, C=c, r34=r34, Y=y)
    # Retain even the three optional aliases from Note 101's local table.
    choices = ((u, v, w) for u, v, w in product(
        states[1, 3], states[3, 5], states[2, 5])
        if u[1] == a and u[2] == v[1] and v[2] == w[2])
    row13, row35, row25 = next(choices)
    for names, values in (
        (("q13", "p13_1", "p13_3"), row13),
        (("q35", "P3", "P5"), row35),
        (("q25", "p25_2", "p25_5"), row25),
        (("q24", "p24_2", "p24_4"), states[2, 4][0]),
    ):
        named.update(zip(names, values))
    return pm, named


ROWS = (
    ("r23", "B", "X", "q13", "p13_1", "p13_3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "p25_5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("qp25", "r34", "B", "Y", "C", "D"),
)
PORT = (0, 11)
ALPHA = frozenset(((13, 15), (14, 16)))
BETA = frozenset(((13, 16), (14, 15)))
THROUGH = frozenset(((0, 13), (11, 14), (15, 16)))
PATTERNS = {"alpha": ALPHA, "beta": BETA, "through": THROUGH}
ALIASES = (("p13_1", "A"), ("p13_3", "P3"), ("p25_5", "P5"))


def load(masks, edge_count):
    masks = tuple(masks)
    return tuple(sum(mask >> i & 1 for mask in masks) for i in range(edge_count))


def connected(order, edges):
    adjacency = [set() for _ in range(order)]
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen, pending = {0}, [0]
    while pending:
        for v in adjacency[pending.pop()] - seen:
            seen.add(v)
            pending.append(v)
    return len(seen) == order


def main():
    pm, named = select_rows()
    assert all(load((named[x] for x in row), len(EDGES)) == (2,) * len(EDGES)
               for row in ROWS)
    phase = dict(r23="alpha", B="through", X="beta", qp25="beta",
                 D="beta", q14="beta", A="alpha", C="through",
                 r34="alpha", Y="alpha")
    for names in (("q13", "p13_1", "p13_3"),
                  ("q35", "P3", "P5"),
                  ("q25", "p25_2", "p25_5"),
                  ("q24", "p24_2", "p24_4")):
        for left, right in ALIASES:
            if left in phase:
                phase[right] = phase[left]
            if right in phase:
                phase[left] = phase[right]
        for name in names:
            if named[name] >> PROPER.index(PORT) & 1:
                assert phase.get(name, "through") == "through"
                phase[name] = "through"
        unused = [p for p in ("alpha", "beta") if p not in
                  {phase.get(name) for name in names}]
        for name in names:
            if name not in phase:
                phase[name] = unused.pop(0)
        assert set(phase[name] for name in names) == set(PATTERNS)

    proper = tuple(sorted((set(PROPER) - {PORT}) | ALPHA | BETA | THROUGH))
    edges = proper + tuple((v,) for v in range(5))
    index = {edge: i for i, edge in enumerate(edges)}

    def lift(mask, pattern):
        selected = {e for i, e in enumerate(EDGES) if mask >> i & 1}
        assert (PORT in selected) == (pattern == "through")
        selected = (selected - {PORT}) | PATTERNS[pattern]
        return sum(1 << index[e] for e in selected)

    closure = perfect_matchings(17, edges)
    assert len(closure) == len(set(closure))
    lifted_closure = {
        lift(mask, pattern) for mask in pm
        for pattern in (("through",) if mask >> PROPER.index(PORT) & 1
                        else ("alpha", "beta"))
    }
    assert set(closure) == lifted_closure
    assert len(proper) == 23 and len(edges) == 28
    assert all(sum(v in e for e in edges) == 3 for v in range(17))
    assert len(set(proper)) == len(proper) and all(u < v for u, v in proper)
    assert connected(17, proper)
    assert all(connected(17, proper[:i] + proper[i + 1:])
               for i in range(len(proper)))
    actual = {name: lift(mask, phase[name]) for name, mask in named.items()}
    assert all(mask in closure for mask in actual.values())
    assert len(set(actual.values())) == 19
    assert all(load([actual[x] for x in row], len(edges)) == (2,) * len(edges)
               for row in ROWS)
    assert all(actual[left] == actual[right] for left, right in ALIASES)
    assert all(boundary(actual[name], edges) == boundary(mask, EDGES)
               for name, mask in named.items())

    target, source = actual["A"], lift(named["A"], "beta")
    nonleak, witness = actual["q14"], actual["C"]
    anchor = actual["r34"]
    assert source in closure and source != target
    k23 = tuple(2 - x for x in load([actual[x] for x in ("r23", "B", "X")], len(edges)))
    k34 = tuple(2 - x for x in load([actual[x] for x in ("r34", "Y", "C")], len(edges)))
    assert k23 == (1,) * len(edges)
    assert load([target, nonleak, witness], len(edges)) == k23
    assert load([source, nonleak, witness], len(edges)) == k34
    assert boundary(source, edges) == boundary(target, edges) == {1}
    assert boundary(nonleak, edges) == {2, 3, 5}
    assert boundary(witness, edges) == {4}
    assert {e for i, e in enumerate(edges) if (source ^ target) >> i & 1} == ALPHA | BETA
    assert (target & ~source) & ~anchor == 0
    assert (source & ~target) & anchor == 0
    residual = tuple(k34[i] - (witness >> i & 1) - (target >> i & 1)
                     for i in range(len(edges)))
    assert all(residual[index[e]] == -1 for e in ALPHA)
    assert all(residual[index[e]] == 2 for e in BETA)

    # Reconstruct the entire chosen agreement core, not only the selected P.
    core = [mask for mask in closure if boundary(mask, edges) == {1}
            and not ((target & ~mask) & ~anchor)
            and not ((mask & ~target) & anchor)]
    same_k, aligned = [], []
    for candidate in core:
        forced = tuple(k34[i] - (witness >> i & 1) - (candidate >> i & 1)
                       for i in range(len(edges)))
        if all(x in (0, 1) for x in forced):
            companion = sum(x << i for i, x in enumerate(forced))
            assert companion in closure
            same_k.append((candidate, companion))
            if all(x in (0, 1) for x in residual):
                aligned.append((candidate, companion))
    assert (source, nonleak) in same_k and not aligned

    # Explicit forbidden T-loop: the H23 triple partitions every edge.
    assert load([actual[x] for x in ("r23", "B", "X")], len(edges)) == (1,) * len(edges)
    print("base_PM_count", len(pm), "new_PM_count", len(closure))
    print("order", 17, "proper_edges", len(proper), "simple_connected_proper_bridgeless", True)
    print("six_Note101_rows", True, "three_optional_aliases", True, "distinct_named_PMs", len(set(actual.values())))
    print("core_size", len(core), "same_K_fixed_W_pairs", len(same_k), "aligned_pairs", len(aligned))
    print("opposite_shared_masks", ("q14", "C"), "forbidden_T_loop", "[23]")
    print("base_edge_ids", dict(enumerate(PROPER)))
    print("name | base proper edge ids | boundary | extension")
    for name, mask in named.items():
        print(name, tuple(i for i in range(len(PROPER)) if mask >> i & 1),
              tuple(sorted(boundary(mask, EDGES))), phase[name], sep=" | ")
    print("core_base_projections_and_patterns")
    for mask in core:
        print(tuple(i for i, e in enumerate(EDGES) if e != PORT and e in index
                    and mask >> index[e] & 1),
              next(p for p, es in PATTERNS.items() if all(mask >> index[e] & 1 for e in es)))
    print("R2_ACTUAL_SHARED_WITNESS_PHASE_OBSTRUCTION_VERIFIED")


if __name__ == "__main__":
    main()
