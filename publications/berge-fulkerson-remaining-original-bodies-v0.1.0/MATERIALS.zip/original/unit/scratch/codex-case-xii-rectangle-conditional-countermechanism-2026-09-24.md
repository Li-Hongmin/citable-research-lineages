# Frozen Case-XII rectangle: a support-preserving conditional countermechanism

**Verified conditional theorem (2026-09-24).** Let \(\mathfrak X\) be the class of rooted cubic five-poles with complete exact Case-XII BF boundary support and an assignment of the six literal Note-101 rows. Let \(\operatorname{Rect}(G,\rho)\) be the sixteen-context full-PM synchronized rectangle statement in the frozen SPEC. Then

\[
\bigl[\forall(G,\rho)\in\mathfrak X\;\operatorname{Rect}(G,\rho)\bigr]
\quad\Longleftrightarrow\quad \mathfrak X=\varnothing. \tag{1}
\]

This strengthens the four-residual conditional factor result already recorded in `pro-case-xii-factor-2026-09-24.md` to the **full frozen rectangle**. It is not an unconditional counterexample: no member of \(\mathfrak X\) is certified here.

## Verification of the factor premise

Write \(r=r_{23}\), \(s=r_{34}\), and \(q'=q'_{25}\). Use the six Note-101 rows exactly as written there; in particular \(q_{25}\) and \(q'\) are separate names. A set of matching names is *balanced* if it contains two names from each row. The occurrence set of any proper edge in the six rows is balanced.

Replace a proper edge \(uv\) by a \(K_4\) with edge \(01\) deleted, joining \(u\) to \(0\) and \(v\) to \(1\). Every PM of the new pole uses either both cut edges or neither. The first case restricts to an old PM containing \(uv\) and has the unique internal edge \(23\); the second restricts to an old PM avoiding \(uv\) and has either internal pair \(\{02,13\}\) or \(\{03,12\}\). All boundary masks are unchanged. A new BF row restricts to an old BF row because its two cut edges have load two, so the restored \(uv\) has load two. Conversely, in any old BF row exactly two occurrences contain \(uv\); extend these through \(23\), and distribute the other four occurrences two to each internal pair. Hence **the complete BF boundary relation is preserved in both directions**, not merely the six selected rows.

If the port edge has balanced occurrence set \(\sigma\), choose a balanced \(\tau\) disjoint from \(\sigma\). Extend every named matching in \(\sigma\) through \(23\), every name in \(\tau\) through \(\{02,13\}\), and every remaining name through \(\{03,12\}\). Each row uses each of the three internal patterns twice; repeated names receive the same extension. Edge \(02\) is a new port of occurrence set \(\tau\), while edge \(13\) is a second, untouched edge of that set.

The three balanced sets needed below are

\[
\begin{aligned}
U&=\{r,X,Y,D\},\\
W&=\{B,C,p^1_{13},p^2_{24},p^2_{25},P_3\},\\
V&=\{X,A,Y,s,q_{13},q_{24},q_{25},q_{35}\}.
\end{aligned} \tag{2}
\]

Directly in the six rows, \(U\cap W=V\cap W=\varnothing\). For **every** balanced input occurrence set \(\sigma\), there is a balanced \(Z\) disjoint from both \(\sigma\) and \(U\). Here is the checked construction. Put \(H=\{r,B,X\}\) and let \(E_{13},E_{14},E_{24},E_{25},E_{35}\) be the five complementary three-name blocks in the first five rows. If \(c=|\sigma\cap H|\), then \(|\sigma\cap E_{ij}|=2-c\). In each of the four blocks other than \(E_{14}\), choose one unused name when \(B\notin\sigma\), and two unused names when \(B\in\sigma\). Complete \(Z\) by the applicable line:

| Membership in \(\sigma\) | Add to \(Z\) |
|---|---|
| \(B,C\notin\sigma\) | \(B,C\) |
| \(B\notin\sigma, C\in\sigma\) | \(B,h,t\) |
| \(B\in\sigma, C\notin\sigma\) | \(C,h,t\) |
| \(B,C\in\sigma\) | \(q_{14},A,q',s\) |

In the middle lines choose \(h\in\{q_{14},A\}\setminus\sigma\) and \(t\in\{q',s\}\setminus\sigma\). Such choices exist: the first five row quotas leave the required names free in \(E_{14}\), and the sixth-row quota leaves one of \(q',s\) free. In the last line both \(q_{14},A\) and \(q',s\) are free. Inspection gives two names in each row, with no name in \(\sigma\cup U\).

Starting at any proper edge, make four successive insertions with port sets

\[
\sigma\longrightarrow Z\longrightarrow U\longrightarrow W\longrightarrow V. \tag{3}
\]

After the second insertion, retain one of the two \(U\)-edges while using the other as the next port. The final insertion leaves a \(V\)-edge. Thus the new pole has sixteen additional vertices, the same complete BF boundary support, and all six literal rows with every repeated occurrence preserved. On the retained \(U\)-edge \(e\), \(r=X=Y=D=1\) and \(B=0\), so \(R_Y(e)=R_D(e)=-1\). On the \(V\)-edge \(f\), \(s=Y=A=X=1\) and \(C=0\), so \(R_A(f)=R_X(f)=-1\). In particular \(q_{25}(f)=1\) and \(q'(f)=0\).

## Direct implication for the frozen statement

In any of the sixteen contexts with literal target \(\tau\in\{Y,D,A,X\}\), the rectangle equations require actual PMs \(P,N,W\) with \(K=P+N+W\) and \(Q=N+P-\tau\) an actual PM. Therefore

\[
R_\tau=K-\tau=Q+W\geq0. \tag{4}
\]

This implication uses neither first-projection failure nor a convention about which opposite witness is eligible. The four negative coordinates above contradict (4) for all four targets, hence for all sixteen contexts. If \(\mathfrak X\neq\varnothing\), applying the construction to one member produces another member without a rectangle. If \(\mathfrak X=\varnothing\), the universal statement is vacuous. This proves (1).

**Exact remaining existence question:** does any rooted cubic five-pole realize complete exact Case-XII BF support together with the six literal Note-101 rows? The construction does not supply such a base. Its two-edge cuts are allowed by the frozen SPEC; a cyclic-connectivity requirement would define a different class.
