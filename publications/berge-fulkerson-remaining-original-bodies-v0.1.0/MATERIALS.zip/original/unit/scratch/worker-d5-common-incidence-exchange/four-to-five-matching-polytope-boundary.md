# Four singleton classes do not force five: a matching-polytope boundary

## Statement tested

For five labelled classes Π_1,…,Π_5 of perfect matchings, consider

\[
  \operatorname{Cap}(I):\qquad
  \exists (M_i\in\Pi_i)_{i\in I}
  \quad\text{with}\quad
  \sum_{i\in I}\chi_{M_i}\le 2\mathbf 1.
\]

The implication

\[
  \operatorname{Cap}([5]\setminus\{j\})\quad(j=1,\ldots,5)
  \ \Longrightarrow\ \operatorname{Cap}([5])
\tag{F4\to F5}
\]

is false for a common cubic graph, even before imposing terminal-incidence
conditions. Consequently it cannot follow from the individual matching
polytope, Tutte odd-cut inequalities, or local even-cycle exchange alone.

## Explicit common-graph countermodel

Take the cube graph. Let (M_0) and (M_1) be the two horizontal
1-factors: on each of the two square faces choose respectively the pair of
opposite rim edges of type 0 or of type 1. Thus (M_0cap M_1=\varnothing),
and (M_0\triangle M_1) is the disjoint union of two alternating 4-cycles.
Put the same two-element family on every labelled class:

\[
   \Pi_i=\{M_0,M_1\},\qquad i=1,ldots,5.
\]

For any four classes choose (M_0) twice and (M_1) twice. Every edge of
(M_0\cup M_1) then has load 2, and all other cube edges have load 0.
Hence every four-class subfamily is feasible.

For all five classes, let (k) be the number of chosen (M_0)'s. Every
edge of (M_0) has load (k), while every edge of (M_1) has load
(5-k). Capacity two would require simultaneously

\[
  k\le 2,
  \qquad 5-k\le 2,
\]

which is impossible. This is a genuine common-perfect-matching example
(the labels (i) are deliberately not claimed to be five terminal
classes of one 5-pole).

The obstruction persists in the convex relaxation. If class (i) uses
(M_0) with weight (lambda_iin[0,1]), put (t=\sum_ilambda_i). The
two edge families impose (tle2) and (5-tle2), so the global product
of the five matching polytopes is itself infeasible. Every four-factor
product is integral-feasible. Thus even a fractional Helly assertion is
false at this level.

## What the polytope dual says

For arbitrary finite matching families (Pi_i), set

\[
  K_i=\operatorname{conv}\{\chi_M:M\in\Pi_i\},
  \qquad
  Q=\{(x_i):x_i\in K_i, \sum_i x_i\le2\mathbf1\}.
\]

The edge-capacity LP is feasible exactly when (Q\ne\varnothing). Its
Farkas alternative is

\[
  Q=\varnothing
  \Longleftrightarrow
  \exists y\ge0:
  \sum_i \min_{M\inPi_i} y(M)
       >2\sum_e y_e,
\tag{D}
\]

where (y(M)=\sum_{e\in M}y_e). Four-wise feasibility only gives, for each
(j),

\[
  \sum_{i\ne j}\min_{M\inPi_i} y(M)
       \le2\sum_e y_e.
\]

Summing these five inequalities yields at most

\[
  4\sum_i\min_{M\inPi_i} y(M)
       \le10\sum_e y_e,
\]

or a total bound (\le(5/2)\sum_e y_e), not the (2\sum_e y_e) needed
to contradict (D). The dual gap is therefore structural, not a missing
odd-cut inequality. In the cube model a single (y) supported on
(M_0\cup M_1) already witnesses the global LP infeasibility.

## A precise sufficient condition (what would be needed)

The right conditional theorem has two independent hypotheses:

1. **Global fractional section (FR).** There are distributions
   (mu_i) on (Pi_i) such that
   \[
     \sum_i\mathbb E_{mu_i}[\chi_M]\le2\mathbf1.
   \]
2. **Joint integrality (JI).** The coupled polytope (Q) above is integral
   (for example, after an explicit extended formulation its constraint
   matrix is totally unimodular; an integer-decomposition property for the
   five class polytopes also suffices).

Then (Q\ne\varnothing) by (FR), and a vertex of (Q) gives one actual
matching from every class with edge load at most two. Neither (FR) nor
(JI) follows from the five separate matching polytopes. A real cubic-pole
proof must establish them from common terminal incidence, or replace them
by a stronger witness-reuse/Helly statement.

## Scope

The cube construction is a strict matching-polytope/alternating-cycle
boundary, not a Berge--Fulkerson 5-pole counterexample: the five labels are
external class labels, not distinct terminal semiedges. It proves exactly
that Tutte/matching-polytope/Delta-matroid local structure cannot by itself
perform the four-to-five quantifier exchange. Any positive theorem for the
five singleton classes must use additional common 5-pole terminal-incidence
information.
