"""Targeted small-family search for disjoint real six-pole BF relations.

This is deliberately not a census.  It builds a short list of named cubic
graphs, cuts connected vertex shores with six crossing edges and a cycle on
each side, computes the exact six-matching boundary relation of each side,
and checks every boundary-position gluing permutation.  Colour labels are
quotiented by S_6; a relation intersection after this quotient is exactly
the required global relabelling condition.
"""

from __future__ import annotations

from itertools import combinations, permutations
from dataclasses import dataclass

import networkx as nx


PAIRS = tuple(combinations(range(6), 2))
PAIR_INDEX = {pair: i for i, pair in enumerate(PAIRS)}
COLOR_PERMS = tuple(permutations(range(6)))
PAIR_TRANSFORMS = tuple(
    tuple(PAIR_INDEX[tuple(sorted((perm[a], perm[b])))] for a, b in PAIRS)
    for perm in COLOR_PERMS
)
# To canonicalize an ordered signature it is enough to retain colour
# permutations sending its first pair to (0,1): that pair code is 0, the
# lexicographically least possible first entry.  This leaves 48 transforms
# instead of 720 and is an exact reduction, not a heuristic.
NORMALIZERS = {
    first: tuple(transform for transform in PAIR_TRANSFORMS if transform[first] == 0)
    for first in range(len(PAIRS))
}
POSITION_PERMS = tuple(permutations(range(6)))


def canonical(signature):
    return min(
        tuple(transform[pair_code] for pair_code in signature)
        for transform in NORMALIZERS[signature[0]]
    )


@dataclass(frozen=True)
class Pole:
    name: str
    n: int
    proper_edges: tuple[tuple[int, int], ...]
    semiedge_vertices: tuple[int, ...]
    source_graph: str
    shore: tuple[int, ...]
    relation: frozenset[tuple[int, ...]]
    raw_count: int


def exact_relation(proper_edges, semiedge_vertices):
    """Return colour-quotiented ordered boundary signatures and raw count."""
    edges = [tuple(edge) for edge in proper_edges]
    edges.extend((vertex, None) for vertex in semiedge_vertices)
    n = max(max(edge[0], edge[1]) if edge[1] is not None else edge[0]
            for edge in edges) + 1
    incidence = [[] for _ in range(n)]
    for edge_index, (u, v) in enumerate(edges):
        incidence[u].append(edge_index)
        if v is not None:
            incidence[v].append(edge_index)
    assert all(len(incident) == 3 for incident in incidence), (proper_edges, semiedge_vertices)

    values = [None] * len(edges)
    first_semiedge = len(proper_edges)
    values[first_semiedge] = PAIR_INDEX[(0, 1)]
    signatures = set()
    raw_count = 0

    def vertex_ok(vertex):
        assigned = [values[e] for e in incidence[vertex] if values[e] is not None]
        if len(assigned) != len(set(assigned)):
            return False
        return all(
            set(PAIRS[assigned[i]]).isdisjoint(PAIRS[assigned[j]])
            for i in range(len(assigned))
            for j in range(i)
        )

    def edge_candidates(edge_index):
        """Pairs compatible with already assigned labels at both endpoints."""
        u, v = edges[edge_index]
        domains = []
        for vertex in (u, v):
            if vertex is None:
                continue
            assigned = [values[e] for e in incidence[vertex] if values[e] is not None]
            used = set()
            for code in assigned:
                used.update(PAIRS[code])
            if len(assigned) >= 2:
                # Three pairwise-disjoint pairs partition [6], so the last
                # pair is forced whenever it exists.
                remaining = tuple(sorted(set(range(6)) - used))
                domains.append({PAIR_INDEX[remaining]} if len(remaining) == 2 else set())
            else:
                domains.append({code for code, pair in enumerate(PAIRS)
                                if set(pair).isdisjoint(used)})
        if not domains:
            return range(len(PAIRS))
        candidates = set.intersection(*domains)
        return candidates

    def search(remaining):
        nonlocal raw_count
        if remaining == 0:
            raw_count += 1
            boundary = tuple(values[first_semiedge + i] for i in range(6))
            signatures.add(canonical(boundary))
            return
        candidates = [e for e, value in enumerate(values) if value is None]
        edge_index = min(candidates, key=lambda e: len(edge_candidates(e)))
        u, v = edges[edge_index]
        for pair_code in edge_candidates(edge_index):
            values[edge_index] = pair_code
            if vertex_ok(u) and (v is None or vertex_ok(v)):
                search(remaining - 1)
        values[edge_index] = None

    search(len(edges) - 1)
    return frozenset(signatures), raw_count


def connected_cyclic_shores(graph, graph_name):
    """Yield connected, cycle-containing shores with cut exactly six."""
    vertices = tuple(sorted(graph.nodes()))
    # Work with integer labels to keep relation lists compact.
    relabel = {v: i for i, v in enumerate(vertices)}
    graph = nx.relabel_nodes(graph, relabel, copy=True)
    vertices = tuple(sorted(graph.nodes()))
    # X and complement are identified by requiring the first vertex in X.
    first = vertices[0]
    for r in range(1, len(vertices) // 2 + 1):
        for subset in combinations(vertices, r):
            if first not in subset:
                continue
            X = set(subset)
            Y = set(vertices) - X
            cut = [(u, v) if u < v else (v, u)
                   for u, v in graph.edges()
                   if (u in X) != (v in X)]
            if len(cut) != 6:
                continue
            sx = graph.subgraph(X).copy()
            sy = graph.subgraph(Y).copy()
            if not nx.is_connected(sx) or not nx.is_connected(sy):
                continue
            if not nx.cycle_basis(sx) or not nx.cycle_basis(sy):
                continue
            # Produce both orientations: a pair can use either shore.
            for side_name, side in (("X", X), ("Y", Y)):
                outside = set(vertices) - side
                side_order = {v: i for i, v in enumerate(sorted(side))}
                proper = tuple(sorted(
                    (min(side_order[u], side_order[v]),
                     max(side_order[u], side_order[v]))
                    for u, v in graph.edges()
                    if u in side and v in side
                ))
                semis = tuple(sorted(
                    side_order[u if u in side else v]
                    for u, v in cut
                    if (u in side) != (v in side)
                ))
                # Check all vertices have cubic pole degree.
                degree = {v: 0 for v in range(len(side))}
                for u, v in proper:
                    degree[u] += 1
                    degree[v] += 1
                for u in semis:
                    degree[u] += 1
                assert all(d == 3 for d in degree.values())
                yield graph_name, side_name, tuple(sorted(side)), proper, semis


def named_graphs():
    result = []
    result.append(("K4", nx.complete_graph(4)))
    result.append(("K3,3", nx.complete_bipartite_graph(3, 3)))
    result.append(("cube", nx.cubical_graph()))
    result.append(("Petersen", nx.petersen_graph()))
    result.append(("Heawood", nx.heawood_graph()))
    result.append(("Möbius-Kantor", nx.moebius_kantor_graph()))
    for n in (4, 5, 6, 7, 8, 9):
        result.append((f"prism{n}", nx.circular_ladder_graph(n)))
    for n in (4, 5, 6, 7, 8):
        # Möbius ladder on 2n vertices: cycle plus opposite chords.
        g = nx.cycle_graph(2 * n)
        g.add_edges_from((i, i + n) for i in range(n))
        result.append((f"mobius{2*n}", g))
    return result


def relation_intersection(r1, r2, positions):
    reordered = {canonical(tuple(sig[p] for p in positions)) for sig in r2}
    return r1 & reordered


def glued_graph(p1: Pole, p2: Pole, positions):
    """Glue semiedge i of p1 to semiedge positions[i] of p2."""
    n1 = p1.n
    n2 = p2.n
    g = nx.Graph()
    g.add_nodes_from(range(n1 + n2))
    g.add_edges_from(p1.proper_edges)
    g.add_edges_from((n1 + u, n1 + v) for u, v in p2.proper_edges)
    for i, j in enumerate(positions):
        g.add_edge(p1.semiedge_vertices[i], n1 + p2.semiedge_vertices[j])
    return g


def main():
    poles = []
    for graph_name, graph in named_graphs():
        for name, side, shore, proper, semis in connected_cyclic_shores(graph, graph_name):
            # Keep only proper-edge bridgeless poles; this is a strong validity filter.
            side_graph = nx.Graph()
            side_graph.add_nodes_from(shore)
            side_graph.add_edges_from(proper)
            if any(True for _ in nx.bridges(side_graph)):
                continue
            relation, raw = exact_relation(proper, semis)
            n = len(shore)
            poles.append(Pole(f"{graph_name}:{side}:{shore}", n, proper, semis,
                              graph_name, shore, relation, raw))
            print(f"POLE {poles[-1].name} n={len(shore)} proper={len(proper)} raw={raw} orbits={len(relation)}")

    print(f"TOTAL_POLES={len(poles)}")
    # Pair only distinct poles, stopping at first candidate whose all position
    # permutations are relation-disjoint; then test a concrete bridgeless gluing.
    for i, p1 in enumerate(poles):
        for p2 in poles[i:]:
            for positions in POSITION_PERMS:
                overlap = relation_intersection(p1.relation, p2.relation, positions)
                if overlap:
                    continue
                g = glued_graph(p1, p2, positions)
                if nx.is_connected(g) and not list(nx.bridges(g)):
                    print("DISJOINT_BRIDGELESS_PAIR_FOUND")
                    print(p1)
                    print(p2)
                    print("POSITIONS", positions)
                    return
                # A disjoint relation with a bridged closure is still useful
                # as a boundary warning, but not a valid target; report it once.
                print("DISJOINT_RELATION_BUT_GLUE_NOT_BRIDGELESS", p1.name, p2.name, positions)
                break
    print("NO_DISJOINT_BRIDGELESS_PAIR_IN_TARGETED_FAMILY")


if __name__ == "__main__":
    main()
