#!/usr/bin/env python3
"""Targeted deterministic search for a real O6 relation countermodel.

For each requested even order, deterministic ``networkx`` seeds generate a
short list of connected cubic graphs.  Removing a matching of three edges
leaves a genuine cubic six-pole with six distinct semiedge endpoints.  The
actual six-matching V-gate relation is enumerated, and every boundary
correspondence is tested between every retained pair.  A hit is then glued
and checked as a simple connected bridgeless cubic graph with a cyclic
six-cut.

This is not a graph census: it is a bounded, fixed-seed construction search
whose sole objective is to distinguish existence versus nonexistence of a
real disjoint boundary-relations pair.  No parity or rainbow surrogate is
used.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import combinations, permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

import networkx as nx

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("random_o6_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)

POSITION_PERMS = tuple(permutations(range(6)))


@dataclass(frozen=True)
class Candidate:
    name: str
    n: int
    proper: tuple[tuple[int, int], ...]
    boundary: tuple[int, ...]
    relation: frozenset[tuple[int, ...]]
    raw_count: int


def connected(n, edges, removed=None):
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index == removed:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n, edges):
    return connected(n, edges) and all(connected(n, edges, i) for i in range(len(edges)))


def proper_from_host(graph: nx.Graph, removed):
    n = graph.number_of_nodes()
    labels = {v: i for i, v in enumerate(sorted(graph.nodes()))}
    normalized = {tuple(sorted((labels[u], labels[v]))) for u, v in removed}
    all_edges = tuple(tuple(sorted((labels[u], labels[v]))) for u, v in graph.edges())
    proper = tuple(edge for edge in all_edges if edge not in normalized)
    boundary = tuple(v for edge in removed for v in sorted((labels[edge[0]], labels[edge[1]])))
    # The removal ordering must remain tied to the graph's labeled endpoints.
    boundary = tuple(v for edge in removed for v in (labels[edge[0]], labels[edge[1]]))
    assert len(boundary) == 6 and len(set(boundary)) == 6
    return tuple(sorted(proper)), boundary


def glued(left: Candidate, right: Candidate, positions):
    n = left.n
    edges = list(left.proper)
    edges.extend((n + u, n + v) for u, v in right.proper)
    edges.extend((left.boundary[i], n + right.boundary[positions[i]]) for i in range(6))
    return tuple(edges)


def valid_gluing(left, right, positions):
    edges = glued(left, right, positions)
    normalized = tuple(tuple(sorted(edge)) for edge in edges)
    return (
        len(normalized) == len(set(normalized))
        and connected(left.n + right.n, edges)
        and bridgeless(left.n + right.n, edges)
        and all(sum(vertex in edge for edge in normalized) == 3
                for vertex in range(left.n + right.n))
    )


def matching_choices(graph: nx.Graph, limit: int):
    edges = tuple(tuple(sorted(edge)) for edge in graph.edges())
    choices = []
    for triple in combinations(edges, 3):
        endpoints = [v for edge in triple for v in edge]
        if len(set(endpoints)) == 6:
            choices.append(triple)
            if len(choices) >= limit:
                break
    return tuple(choices)


def generate(n: int, samples: int, matching_limit: int):
    result = []
    seen = set()
    for seed in range(samples):
        graph = nx.random_regular_graph(3, n, seed=seed)
        if not connected(n, tuple(graph.edges())):
            continue
        for choice_index, removed in enumerate(matching_choices(graph, matching_limit)):
            proper, boundary = proper_from_host(graph, removed)
            key = (proper, boundary)
            if key in seen:
                continue
            if not connected(n, proper) or not bridgeless(n, proper):
                continue
            # Every port must retain a cycle-containing proper core.  The
            # bridgeless test already implies this for n >= 4.
            relation, raw = ENGINE.exact_relation(proper, boundary)
            if not relation:
                continue
            seen.add(key)
            result.append(Candidate(f"n{n}-seed{seed}-m{choice_index}", n,
                                    proper, boundary, relation, raw))
    return tuple(result)


def minimum_overlap(left, right):
    best = None
    best_positions = None
    for positions in POSITION_PERMS:
        reordered = {ENGINE.canonical(tuple(signature[i] for i in positions))
                     for signature in right.relation}
        overlap = len(left.relation & reordered)
        if best is None or overlap < best:
            best, best_positions = overlap, positions
            if best == 0:
                break
    return best, best_positions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--orders", nargs="+", type=int, default=[10])
    parser.add_argument("--samples", type=int, default=8)
    parser.add_argument("--matching-limit", type=int, default=3)
    args = parser.parse_args()

    candidates = []
    for n in args.orders:
        assert n % 2 == 0 and n >= 6
        candidates.extend(generate(n, args.samples, args.matching_limit))

    rows = []
    hits = []
    for i, left in enumerate(candidates):
        for right in candidates[i:]:
            overlap, positions = minimum_overlap(left, right)
            row = {"left": left.name, "right": right.name,
                   "n": (left.n, right.n), "left_raw": left.raw_count,
                   "right_raw": right.raw_count,
                   "left_relation_orbits": len(left.relation),
                   "right_relation_orbits": len(right.relation),
                   "minimum_overlap": overlap}
            rows.append(row)
            if overlap == 0:
                row = {**row, "positions": positions,
                       "glued_valid": valid_gluing(left, right, positions)}
                hits.append(row)

    minimum = min((row["minimum_overlap"] for row in rows), default=None)
    print({"orders": args.orders, "samples": args.samples,
           "matching_limit": args.matching_limit,
           "candidate_count": len(candidates),
           "candidate_relations": [
               {"name": candidate.name, "n": candidate.n,
                "raw": candidate.raw_count,
                "relation_orbits": len(candidate.relation),
                "boundary": candidate.boundary}
               for candidate in candidates
           ],
           "pair_count": len(rows), "minimum_overlap": minimum,
           "zero_overlap_hits": hits})
    if any(hit["glued_valid"] for hit in hits):
        print("REAL_ACTUAL_O6_COUNTERMODEL_FOUND")
    elif hits:
        print("ZERO_RELATION_OVERLAP_BUT_NO_VALID_GLUE")
    else:
        print("NO_DISJOINT_ACTUAL_RELATIONS_IN_TARGETED_RANDOM_FAMILY")
    print("RANDOM_ACTUAL_O6_TARGETED_PROBE_OK")


if __name__ == "__main__":
    main()
