# Cyclically-6 cut: common-cap rigidity is the sharp remaining condition

## Decision

The six-cut overlap statement remains **strictly undecided**.  Let (G) be a
minimum-order bridgeless cubic BF counterexample and let a cycle-separating
six-cut produce ordered six-poles (H_X,H_Y).  With

\[
\mathcal R(H)=\{\rho=(\rho_1,\ldots,\rho_6):
\rho_j\in\binom{[6]}2\text{ is realised by one actual six-matching
certificate in }H\},
\]

the exact missing implication is

\[
\exists \rho_X\in\mathcal R(H_X),\rho_Y\in\mathcal R(H_Y),\pi\in S_6,
\qquad
\rho_X(j)=\pi(\rho_Y(j))\quad(1\le j\le6). \tag{O6}
\]

No proof of (O6), and no pair of real six-poles with nonempty disjoint
relations modulo a global (S_6)-relabeling, is obtained here.

## Actual common-incidence gluing equivalence

For a certificate (M_1,\ldots,M_6) on a six-pole, every proper edge is in
exactly two (M_i), and (ho_j) records the two labels used by semiedge
(j).  If (O6) holds, relabel the second certificate by (pi) and glue the
two matching systems across the six cut edges.  Every glued cut edge then has
load two, so the result is a BF cover of (G).  Conversely, restriction of a
global BF cover gives (O6).  Thus (O6) is an iff at the level of the same
actual perfect-matching incidence system; it is not merely a parity test.

## What minimality supplies

Let (p=\{\{a_1,b_1\},\{a_2,b_2\},\{a_3,b_3\}\}) be a pairing of the six
boundary positions, and put

\[
\operatorname{Fix}(p)=\{\rho:\rho_{a_r}=\rho_{b_r}\ (r=1,2,3)\}.
\]

Join each paired pair of semiedges by a cap edge.  If the resulting cubic
closure of (H) is bridgeless, it is a smaller graph than (G), so
minimality yields the genuine statement

\[
\exists\rho_p\in\mathcal R(H)\cap\operatorname{Fix}(p). \tag{Cap}
\]

The quantifiers are the obstruction:

\[
\text{(Cap)}\quad\forall p\;\exists\rho_p,
\qquad
\text{(O6)}\quad\exists\rho_X,\rho_Y,\pi.
\]

Neither minimality nor the local cubic gate identifies the certificates
(\rho_p) for different pairings, or identifies a certificate on (H_X) with
one on (H_Y).

## Sharp sufficient strengthening

The weakest direct condition that closes the six-cut route is **common-cap
rigidity**: there is an admissible pairing (p) for both sides such that all
realised (p)-fixed signatures on each side lie in one common (S_6)-orbit.
Then (Cap) supplies (\rho_X,\rho_Y\) in that orbit, and (O6) follows.

A slightly weaker equivalent formulation is simply

\[
\bigl(\mathcal R(H_X)\cap\operatorname{Fix}(p)\bigr)/S_6
\quad\text{and}\quad
\bigl(\mathcal R(H_Y)\cap\operatorname{Fix}(p)\bigr)/S_6
\]

have a common orbit for one pairing (p) whose two cap closures are
bridgeless.  This is a sharp **additional condition**, not a consequence of
cyclic six-connectivity currently proved here.

## Why parity does not close the gap

For every perfect matching (M), the number of cut edges used by (M) has
the parity of the shore order; for six cuts this is even.  A BF cover therefore
only gives six even integers in ([0,6]) summing to (12).  This leaves, for
example, both profiles ((2,2,2,2,2,2)) and ((0,2,2,2,2,4)).  It does not
select a boundary signature or compare the two poles.  The same failure occurs
for the loopless Eulerian boundary multigraph on the six matching labels.

## Status and stopping point

The six-cut branch is therefore **strictly unresolved** at the common actual
perfect-matching boundary relation.  A proof must establish common-cap
rigidity (or another cross-pole incidence theorem) from the whole-graph
minimality hypotheses.  A real pair with disjoint (S_6)-orbit relations
would be a pole-level negative result, but no such pair is supplied here.

No census, abstract load model, or further parity scan is needed to change this
decision.
