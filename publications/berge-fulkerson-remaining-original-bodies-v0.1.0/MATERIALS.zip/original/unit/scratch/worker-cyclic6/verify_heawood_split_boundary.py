"""One real shore showing that a split boundary-pair graph need not imply
cyclic connectivity below six.

The hard-coded host is the Heawood graph.  A displayed 6-cycle is one shore
of a cycle-separating 6-cut, and the complementary shore also contains
cycles.  The host has cyclic edge connectivity six (checked directly over
its 14 vertices).  On the 6-cycle shore, an actual six-matching certificate
has all six boundary pairs equal to {1,2}; its boundary pair multigraph is
therefore disconnected.  The same pole has a cap-fixed certificate for every
one of the 15 boundary pairings, and all capped closures are bridgeless.

This is a single explicit graph/pole check, not a census and not a BF
counterexample.  It closes only the local inference
"split boundary pair multigraph => cyclic cut < 6"; the extra
minimum-counterexample hypothesis remains global.
"""

from __future__ import annotations

from itertools import combinations
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "check_small_sixpole_boundary_overlap.py"
ENGINE = {}
exec(ENGINE_PATH.read_text(), ENGINE)

PAIRS = ENGINE["PAIRS"]


HEAWOOD_EDGES = tuple(
    sorted(
        (
            (0, 1),
            (0, 5),
            (0, 13),
            (1, 2),
            (1, 10),
            (2, 3),
            (2, 7),
            (3, 4),
            (3, 12),
            (4, 5),
            (4, 9),
            (5, 6),
            (6, 7),
            (6, 11),
            (7, 8),
            (8, 9),
            (8, 13),
            (9, 10),
            (10, 11),
            (11, 12),
            (12, 13),
        )
    )
)
SHORE = (0, 5, 4, 9, 8, 13)
COMPLEMENT = tuple(vertex for vertex in range(14) if vertex not in SHORE)
CUT = tuple(
    edge for edge in HEAWOOD_EDGES if (edge[0] in SHORE) != (edge[1] in SHORE)
)
SHORE_EDGES = tuple(
    edge for edge in HEAWOOD_EDGES if edge[0] in SHORE and edge[1] in SHORE
)


def connected(vertices, edges, skip=None):
    """Connectivity with edge multiplicity handled by edge index."""
    vertices = tuple(vertices)
    if not vertices:
        return True
    adjacency = {vertex: [] for vertex in vertices}
    for index, (u, v) in enumerate(edges):
        if index == skip:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {vertices[0]}
    stack = [vertices[0]]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == len(vertices)


def has_cycle(vertices, edges):
    """A connected finite graph has a cycle iff |E| >= |V|."""
    return connected(vertices, edges) and len(edges) >= len(vertices)


def pairings():
    result = []

    def rec(remaining, current):
        if not remaining:
            result.append(tuple(current))
            return
        first = min(remaining)
        for second in sorted(remaining - {first}):
            rec(remaining - {first, second}, current + [(first, second)])

    rec(set(range(6)), [])
    return tuple(result)


def cap_closure_bridgeless(proper_edges, boundary, pairing):
    edges = tuple(proper_edges) + tuple(
        tuple(sorted((boundary[a], boundary[b]))) for a, b in pairing
    )
    return connected(range(6), edges) and all(
        connected(range(6), edges, skip=index) for index in range(len(edges))
    )


def main():
    # Host graph and its cycle-separating six-cut.
    assert len(HEAWOOD_EDGES) == 21
    assert all(
        sum(vertex in edge for edge in HEAWOOD_EDGES) == 3 for vertex in range(14)
    )
    assert connected(range(14), HEAWOOD_EDGES)
    assert all(connected(range(14), HEAWOOD_EDGES, skip=index) for index in range(21))
    assert len(CUT) == 6
    shore_set = set(SHORE)
    comp_set = set(COMPLEMENT)
    assert SHORE_EDGES == ((0, 5), (0, 13), (4, 5), (4, 9), (8, 9), (8, 13))
    complement_edges = tuple(
        edge for edge in HEAWOOD_EDGES if edge[0] in comp_set and edge[1] in comp_set
    )
    assert has_cycle(SHORE, SHORE_EDGES)
    assert connected(COMPLEMENT, complement_edges)
    assert has_cycle(COMPLEMENT, complement_edges)

    # Direct cyclic edge-connectivity check for this one 14-vertex graph.
    # It is enough to inspect one shore from each complementary pair.
    cyclic_cut = 99
    for size in range(1, 8):
        for subset in combinations(range(14), size):
            if 0 not in subset:
                continue
            X = set(subset)
            Y = set(range(14)) - X
            if not connected(X, tuple(edge for edge in HEAWOOD_EDGES if set(edge) <= X)):
                continue
            if not connected(Y, tuple(edge for edge in HEAWOOD_EDGES if set(edge) <= Y)):
                continue
            if not has_cycle(X, tuple(edge for edge in HEAWOOD_EDGES if set(edge) <= X)):
                continue
            if not has_cycle(Y, tuple(edge for edge in HEAWOOD_EDGES if set(edge) <= Y)):
                continue
            cut_size = sum((u in X) != (v in X) for u, v in HEAWOOD_EDGES)
            cyclic_cut = min(cyclic_cut, cut_size)
    assert cyclic_cut == 6

    # Six-cycle pole, independently renumbered in cyclic order.
    pole_edges = tuple((index, (index + 1) % 6) for index in range(6))
    boundary = tuple(range(6))
    signatures, raw_count = ENGINE["relation"](6, pole_edges, boundary)
    assert raw_count == 3354
    assert len(signatures) == 92

    # Explicit actual certificate with boundary pair {0,1} on all six ports.
    # Proper edges alternate {2,3} and {4,5}; every vertex sees a partition of
    # [6], and every edge load is exactly two.
    explicit = (0, 0, 0, 0, 0, 0)
    assert explicit in signatures
    proper_labels = (PAIRS.index((2, 3)), PAIRS.index((4, 5))) * 3
    for vertex in range(6):
        incident = [explicit[vertex]]
        incident.append(proper_labels[(vertex - 1) % 6])
        incident.append(proper_labels[vertex])
        used = set()
        for code in incident:
            pair = set(PAIRS[code])
            assert not used.intersection(pair)
            used.update(pair)
        assert used == set(range(6))
    # Each proper edge carries a two-label incidence pair, and the two
    # alternating pair types each occur on three C6 edges.
    assert all(len(PAIRS[code]) == 2 for code in proper_labels)
    assert all(proper_labels.count(code) == 3 for code in set(proper_labels))

    fixed_counts = []
    for pairing in pairings():
        fixed_counts.append(
            sum(
                all(signature[a] == signature[b] for a, b in pairing)
                for signature in signatures
            )
        )
        assert cap_closure_bridgeless(pole_edges, boundary, pairing)

    assert min(fixed_counts) >= 1
    assert max(fixed_counts) <= 15
    assert set(explicit) == {0}  # six parallel 01 edges: a split pair multigraph

    print(
        {
            "host": "Heawood",
            "host_vertices": 14,
            "cyclic_edge_connectivity": cyclic_cut,
            "shore": SHORE,
            "shore_core": "C6",
            "cut_size": len(CUT),
            "actual_split_signature": "01,01,01,01,01,01",
            "six_pole_raw_certificates": raw_count,
            "signature_orbits": len(signatures),
            "cap_pairing_count": len(fixed_counts),
            "fixed_orbits_per_pairing": tuple(fixed_counts),
            "all_capped_closures_bridgeless": True,
        }
    )
    print("HEAWOOD_SPLIT_BOUNDARY_ROUTE_CLOSED")


if __name__ == "__main__":
    main()
