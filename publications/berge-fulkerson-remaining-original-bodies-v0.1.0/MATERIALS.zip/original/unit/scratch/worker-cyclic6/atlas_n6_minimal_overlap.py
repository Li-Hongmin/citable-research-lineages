#!/usr/bin/env python3
"""Exhaustive order-six core probe for the O6 common-incidence gate.

The graph atlas contains all connected simple six-vertex cores with six
proper edges and maximum degree at most three.  Giving every vertex its
degree deficit as a semiedge yields every unlabelled simple six-pole core of
this minimum order (semiedges may share a vertex).  For each core we compute
the *actual* six-matching V-gate relation, compare every pair under all
boundary-position correspondences, and validate every zero-overlap gluing.

This is a deliberately finite minimum model, not a census of cubic graphs.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from pathlib import Path
import sys

import networkx as nx

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
spec = __import__("importlib.util").util.spec_from_file_location(
    "atlas_n6_relation_engine", ENGINE_PATH
)
assert spec is not None and spec.loader is not None
ENGINE = __import__("importlib.util").util.module_from_spec(spec)
sys.modules[spec.name] = ENGINE
spec.loader.exec_module(ENGINE)

POSITION_PERMS = tuple(permutations(range(6)))


def connected(n: int, edges: tuple[tuple[int, int], ...], deleted: int | None = None) -> bool:
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index == deleted:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    return connected(n, edges) and all(connected(n, edges, i) for i in range(len(edges)))


@dataclass(frozen=True)
class Pole:
    atlas_index: int
    edges: tuple[tuple[int, int], ...]
    boundary: tuple[int, ...]
    relation: frozenset[tuple[int, ...]]
    raw_count: int


def atlas_poles() -> tuple[Pole, ...]:
    poles = []
    for atlas_index, graph in enumerate(nx.graph_atlas_g()):
        if graph.number_of_nodes() != 6 or not nx.is_connected(graph):
            continue
        if max(dict(graph.degree()).values()) > 3:
            continue
        if graph.number_of_edges() != 6:
            continue
        # The graph atlas labels these vertices 0,...,5 for this order, but
        # relabel explicitly so the certificate is independent of atlas order.
        labels = {v: i for i, v in enumerate(sorted(graph.nodes()))}
        edges = tuple(sorted(tuple(sorted((labels[u], labels[v]))) for u, v in graph.edges()))
        boundary = tuple(v for v in range(6) for _ in range(3 - graph.degree(sorted(graph.nodes())[v])))
        assert len(boundary) == 6
        relation, raw = ENGINE.exact_relation(edges, boundary)
        assert relation
        poles.append(Pole(atlas_index, edges, boundary, relation, raw))
    return tuple(poles)


def reordered(relation: frozenset[tuple[int, ...]], positions: tuple[int, ...]):
    return {ENGINE.canonical(tuple(signature[position] for position in positions))
            for signature in relation}


def glued(left: Pole, right: Pole, positions: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    n = 6
    edges = list(left.edges)
    edges.extend((n + u, n + v) for u, v in right.edges)
    edges.extend((left.boundary[i], n + right.boundary[positions[i]]) for i in range(6))
    return tuple(tuple(sorted(edge)) for edge in edges)


def valid_gluing(left: Pole, right: Pole, positions: tuple[int, ...]) -> bool:
    edges = glued(left, right, positions)
    if len(edges) != len(set(edges)) or any(u == v for u, v in edges):
        return False
    if not connected(12, edges) or not bridgeless(12, edges):
        return False
    if any(sum(vertex in edge for edge in edges) != 3 for vertex in range(12)):
        return False
    # Both six-vertex shores have cycle rank one (m=n), so this is a genuine
    # cycle-separating six-cut whenever the cubic gluing is valid.
    return bool(nx.cycle_basis(nx.Graph(left.edges))) and bool(nx.cycle_basis(nx.Graph(
        tuple((u, v) for u, v in right.edges)
    )))


def main() -> None:
    poles = atlas_poles()
    assert len(poles) == 9, len(poles)
    # Canonicalize each pole once for all 720 boundary correspondences.  The
    # direct pair loop otherwise repeats the same color-quotient work for
    # every partner and is needlessly expensive even at this minimum order.
    transformed = {
        id(pole): tuple(
            frozenset(ENGINE.canonical(tuple(signature[position] for position in positions))
                      for signature in pole.relation)
            for positions in POSITION_PERMS
        )
        for pole in poles
    }
    rows = []
    zero = []
    minimum = None
    for i, left in enumerate(poles):
        for j in range(i, len(poles)):
            right = poles[j]
            best = None
            best_positions = None
            for perm_index, positions in enumerate(POSITION_PERMS):
                overlap = len(left.relation & transformed[id(right)][perm_index])
                if best is None or overlap < best:
                    best = overlap
                    best_positions = positions
                    if best == 0:
                        break
            assert best is not None and best_positions is not None
            row = {
                "left": i, "right": j,
                "left_atlas_index": left.atlas_index,
                "right_atlas_index": right.atlas_index,
                "left_raw": left.raw_count,
                "right_raw": right.raw_count,
                "left_orbits": len(left.relation),
                "right_orbits": len(right.relation),
                "minimum_overlap": best,
            }
            rows.append(row)
            if best == 0:
                glued_valid = valid_gluing(left, right, best_positions)
                hit = {**row, "positions": best_positions, "glued_valid": glued_valid}
                zero.append(hit)
                if glued_valid:
                    print("REAL_N6_O6_COUNTERMODEL_FOUND", hit)
                    print({"poles": len(poles), "rows": rows, "zero_overlap": zero})
                    print("ATLAS_N6_MINIMAL_OVERLAP_PROBE_OK")
                    return
            minimum = best if minimum is None else min(minimum, best)
    print({
        "pole_count": len(poles),
        "poles": [
            {"atlas_index": p.atlas_index, "edges": p.edges,
             "boundary": p.boundary, "raw": p.raw_count,
             "relation_orbits": len(p.relation)} for p in poles
        ],
        "pair_count": len(rows),
        "minimum_overlap": minimum,
        "zero_overlap_nonvalid": zero,
    })
    if zero:
        print("ZERO_OVERLAP_ONLY_NONVALID_GLUES")
    else:
        print("NO_DISJOINT_ATLAS_N6_RELATIONS")
    print("ATLAS_N6_MINIMAL_OVERLAP_PROBE_OK")


if __name__ == "__main__":
    main()
