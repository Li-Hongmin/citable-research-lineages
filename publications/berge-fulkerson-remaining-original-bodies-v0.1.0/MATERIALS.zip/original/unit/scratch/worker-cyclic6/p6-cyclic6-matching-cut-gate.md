# P6 gate: what cyclically-\(\ge 6\) gives (and does not give)

**Date.** 2026-08-29.  This note is a decision boundary, not a new census.

## Exact statement and quantifiers

For a bridgeless cubic graph \(G\), write

\[
 \operatorname{BF}(G) :\Longleftrightarrow
 \exists M_1,\ldots ,M_6\in\mathcal M_1(G)\quad
 \sum_{i=1}^6\chi^{M_i}=2\mathbf 1_{E(G)},
\]

where repetitions are allowed.  Let \(\lambda_c(G)\) be cyclic edge
connectivity (the minimum size of a cut whose two shores each contain a
cycle).  P6 asks whether one can prove, using the structure of a minimum
BF counterexample, either

\[
\tag{A} \forall G\;[\lambda_c(G)\ge 6\Rightarrow\operatorname{BF}(G)],
\]

or the weaker minimal-counterexample reduction

\[
\tag{B} \forall G\;[G\text{ is minimum-order and }\neg\operatorname{BF}(G)
   \Rightarrow \lambda_c(G)=5].
\]

The current literature proves neither (A) nor (B).  Máčajová--Mazzuoccolo
(2020), Theorem 1.2, proves only \(\lambda_c(G)\ge5\) for a minimum
counterexample.  Their following paragraph explicitly leaves connectivity 5
or 6 under the Jaeger--Swart conjecture.  The latter concerns
\(\lambda_c>6\), not BF colorings.

The 2026 Máčajová--Mazzuoccolo--Tabarelli 13-case proposition is likewise
conditional on the exact-connectivity-5 branch; it supplies no statement for
\(\lambda_c\ge6\).

## General matching/cut identity

For \(X\subseteq V(G)\), put \(C=\delta(X)\), \(k=|C|\), and for a perfect
matching \(M\) put \(m_M(X)=|M\cap C|\).  Counting incidences in \(X\) gives

\[
 |X|=2|M\cap E(X)|+m_M(X),
 \qquad
 3|X|=2|E(X)|+k.
\]

Hence, for every perfect matching,

\[
 m_M(X)\equiv |X|\equiv k\pmod 2. 
\tag{1}
\]

If \(M_1,\ldots ,M_6\) form a BF cover, summing over the cut gives

\[
 \sum_{i=1}^6m_{M_i}(X)=2k,
 \qquad 0\le m_{M_i}(X)\le k,
 \qquad m_{M_i}(X)\equiv k\pmod2.
\tag{2}
\]

For a cyclic 6-cut, (2) merely says that six even integers in
\([0,6]\) sum to 12.  The vectors

\[
 (2,2,2,2,2,2),
 \qquad (0,2,2,2,2,4)
\]

already satisfy all these equations.  Therefore cut parity and the BF
incidence equation do not force a contradiction, a particular boundary type,
or a 5-cut.  For a 5-cut the entries are odd and sum to 10; this is precisely
the setting where the published 5-cut boundary analysis applies.  No analogous
conclusion follows at \(k=6\).

Consequently, from \(\lambda_c(G)\ge6\) one cannot derive (B) by the general
matching/cut identities: there simply need not be a cyclic cut of size 5, and
(1)--(2) do not manufacture one.  Conversely, these identities do not
construct the six perfect matchings required in (A).

## Literature boundary and non-vacuity

Liu--Hao--Zhang (2021) prove BF only for Kochol's named infinite family of
cyclically-6-connected superposition snarks (and extensions), not for all
cyclically-6-connected snarks.  Mazák--Rajník--Škoviera (2025), Theorem 1.2,
construct cyclically-6-connected strictly critical snarks of every even order
\(n\ge342\), and explicitly note that the \(>6\) Jaeger--Swart conjecture
remains open.  Thus the exact-6 class is nonempty; invoking Jaeger--Swart does
not remove this branch.

## Stopping rule

The cheapest decisive observation is the identity (1)--(2).  Since it leaves
cyclic 6-cuts arithmetically feasible and supplies no 5-cut, the present
evidence supports only:

\[
\boxed{\text{P6 is open: no all-cyclically-6 BF theorem and no reduction to
exact connectivity 5 is available.}}
\]

To advance P6 one needs an additional, genuinely stronger input (for example a
Petersen/normal 5-edge-coloring hypothesis, which is known to imply BF), or a
new theorem specific to minimum counterexamples.  No further census or abstract
label construction is justified by the current decision.

**Reproducibility.**  This note uses only the cited source papers and the two
displayed counting identities; no graph enumeration or random search is used.
