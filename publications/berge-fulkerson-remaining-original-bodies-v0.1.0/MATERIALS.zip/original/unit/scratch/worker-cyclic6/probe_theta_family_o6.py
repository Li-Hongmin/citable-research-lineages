#!/usr/bin/env python3
"""Targeted actual-incidence probe for the O6 six-pole interface.

The candidates are the six simple theta cores whose three branch paths have
lengths summing to nine (the multigraph case (1,1,7) is excluded).  Each of
the six degree-two internal vertices
gets one semiedge, so every candidate is a genuine cubic six-pole.  We
enumerate the *actual* common six-matching boundary relation (the V-gate
edge-pair CSP), compare every pair under all 6! boundary correspondences,
and, when a disjoint pair appears, test the glued cubic graph for
connectedness and bridgelessness.

This is a deliberately named one-family experiment, not a graph census.  A
zero overlap would be a real pole-level O6 countermodel; a positive minimum
is only finite negative evidence.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("theta_o6_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)


LENGTHS = tuple(
    (a, b, c)
    for a in range(1, 10)
    for b in range(a, 10)
    for c in range(b, 10)
    if a + b + c == 9 and not (a == b == 1)
)
POSITION_PERMS = tuple(permutations(range(6)))


def reorder_relation(relation, positions):
    return {ENGINE.canonical(tuple(signature[position] for position in positions))
            for signature in relation}


@dataclass(frozen=True)
class Theta:
    lengths: tuple[int, int, int]
    n: int
    proper: tuple[tuple[int, int], ...]
    boundary: tuple[int, ...]
    relation: frozenset[tuple[int, ...]]
    raw_count: int


def theta(lengths: tuple[int, int, int]) -> tuple[int, tuple[tuple[int, int], ...], tuple[int, ...]]:
    """Build a theta with branch vertices 0,1 and six ordered ports."""
    proper: list[tuple[int, int]] = []
    boundary: list[int] = []
    next_vertex = 2
    for length in lengths:
        previous = 0
        for _ in range(1, length):
            vertex = next_vertex
            next_vertex += 1
            proper.append((previous, vertex))
            boundary.append(vertex)
            previous = vertex
        proper.append((previous, 1))
    assert next_vertex == 8
    assert len(proper) == 9 and len(boundary) == 6
    return next_vertex, tuple(proper), tuple(boundary)


def connected(n: int, edges: tuple[tuple[int, int], ...], deleted: int | None = None) -> bool:
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index == deleted:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    return connected(n, edges) and all(
        connected(n, edges, index) for index in range(len(edges))
    )


def glued(left: Theta, right: Theta, positions: tuple[int, ...]) -> tuple[tuple[int, int], ...]:
    n = left.n
    edges = list(left.proper)
    edges.extend((n + u, n + v) for u, v in right.proper)
    edges.extend((left.boundary[i], n + right.boundary[positions[i]]) for i in range(6))
    return tuple(edges)


def main() -> None:
    assert LENGTHS == ((1, 2, 6), (1, 3, 5), (1, 4, 4),
                       (2, 2, 5), (2, 3, 4), (3, 3, 3))
    candidates: list[Theta] = []
    for lengths in LENGTHS:
        n, proper, boundary = theta(lengths)
        relation, raw = ENGINE.exact_relation(proper, boundary)
        assert raw > 0 and relation
        assert len(proper) == 9 and len(boundary) == 6
        assert bridgeless(n, proper)
        candidates.append(Theta(lengths, n, proper, boundary, relation, raw))

    pair_rows = []
    zero_pairs = []
    for i, left in enumerate(candidates):
        for j in range(i, len(candidates)):
            right = candidates[j]
            minimum = min(
                len(left.relation & reorder_relation(right.relation, positions))
                for positions in POSITION_PERMS
            )
            row = {
                "left": left.lengths,
                "right": right.lengths,
                "left_raw": left.raw_count,
                "right_raw": right.raw_count,
                "left_orbits": len(left.relation),
                "right_orbits": len(right.relation),
                "minimum_overlap": minimum,
            }
            pair_rows.append(row)
            if minimum == 0:
                # Locate one disjoint boundary correspondence and validate the
                # actual cubic gluing rather than stopping at abstract relation
                # disjointness.
                for positions in POSITION_PERMS:
                    if left.relation & reorder_relation(right.relation, positions):
                        continue
                    edges = glued(left, right, positions)
                    valid = connected(16, edges) and bridgeless(16, edges)
                    zero_pairs.append({**row, "positions": positions, "glued_bridgeless": valid})
                    break

    print({
        "theta_lengths": LENGTHS,
        "candidate_count": len(candidates),
        "relations": [
            {"lengths": candidate.lengths, "vertices": candidate.n,
             "raw": candidate.raw_count, "orbits": len(candidate.relation)}
            for candidate in candidates
        ],
        "pair_count": len(pair_rows),
        "minimum_pair_overlap": min(row["minimum_overlap"] for row in pair_rows),
        "zero_overlap_pairs": zero_pairs,
        "pair_rows": pair_rows,
    })
    if zero_pairs:
        assert any(row["glued_bridgeless"] for row in zero_pairs), (
            "zero relation overlap found, but no bridgeless gluing in this family"
        )
        print("REAL_THETA_O6_COUNTERMODEL_FOUND")
    else:
        print("NO_DISJOINT_THETA_RELATION_IN_TARGETED_FAMILY")
    print("THETA_FAMILY_O6_PROBE_OK")


if __name__ == "__main__":
    main()
