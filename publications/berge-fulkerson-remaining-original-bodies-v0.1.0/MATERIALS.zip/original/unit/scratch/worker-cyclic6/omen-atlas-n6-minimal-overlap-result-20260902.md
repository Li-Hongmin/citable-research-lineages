# Omen minimum six-pole overlap probe (2026-09-02)

## Decision target

The exact cyclically-six interface asks whether two real six-poles can have
disjoint actual boundary relations under every port correspondence.  For a
relation (R(H)), the test is

\[
\exists\,\pi\in S_6:\quad R(H_X)\cap \pi R(H_Y)=\varnothing.
\]

A zero overlap followed by a simple, connected, bridgeless cubic gluing would
be a real pole-level countermodel.  Positive overlap is only finite negative
evidence.

## Minimum model and exact computation

The graph atlas was filtered to all connected simple six-vertex graphs with
six proper edges and maximum degree at most three.  There are exactly nine
unlabelled cores.  Giving each vertex its cubic deficit as a semiedge gives
six boundary positions (repeated positions are retained; this is the full
minimum simple-core model, not a parity surrogate).  Each core contains a
cycle.  For every core the actual six-matching V-gate relation was enumerated:
each proper edge and semiedge receives a two-subset of six matching labels,
and the three incident labels at every vertex partition the six labels.

All 45 unordered core pairs (including self-pairs) were compared over all
720 boundary-position permutations.  Every relation was canonicalized under
the global (S_6) color action.  Every zero-overlap candidate, if present,
would additionally be checked for a simple connected bridgeless cubic gluing.

Omen command (detached tmux session `o6-atlas-n6-20260902`):

```text
cd [local archival reference]
python3 -u atlas_n6_minimal_overlap.py > run.log 2>&1
```

The run ended normally with `ATLAS_N6_MINIMAL_OVERLAP_PROBE_OK`.

## Exact output

The nine relation orbit sizes were

```text
40, 42, 61, 59, 40, 42, 65, 73, 92
```

All 45 pairs had positive overlap under every tested correspondence; the
global minimum was exactly **1**.  There were no zero-overlap candidates and
therefore no gluing validation hits.

The archived Omen log is
`units/berge-fulkerson/scratch/worker-cyclic6/omen-atlas-n6-20260902.log`.
Its SHA-256 is
`1aa7be335acd02b02220dbb8b1c35485b5245cef31c7a527ac0a2f93252b20f7`.
The source script SHA-256 is
`6e39b13819a3d69903b30dd4392991f695425b80b65be12f4dadc52584ab682a`.

## Four-value decision

This minimum-order actual-incidence model gives a strict finite negative
result: **no proof, no real counterexample, and no universal overlap theorem**.
It does not close the cyclically-six branch.  The only justified boundary is
that any real disjoint relation pair (if one exists) must use a larger or more
structured six-pole than the nine minimum six-vertex simple cores.  No order
increase is launched from this result.

