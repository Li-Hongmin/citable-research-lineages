# O6 cross-shore actual-incidence probe (2026-09-01)

## Question and quantifiers

For two ordered cubic six-poles (X,Y) obtained by cutting the two shores of
a cycle-separating six-cut, write (mathcal R(X),mathcal R(Y)) for the
ordered six-port signatures of six *actual* matching edge sets, with every
proper edge used exactly twice and every internal vertex covered once by each
matching.  The tested obstruction is

\[
\exists\text{ a boundary correspondence }\sigma\in S_6quad
\mathcal R(X)\cap \sigma\mathcal R(Y)=\varnothing .
\]

A zero overlap after a valid gluing would be a real pole-level O6
countermodel; a positive overlap is only finite negative evidence.

The search never replaces a pole by parity, rainbow, cap-orbit, or load data.

## Omen runs

Both computations were copied to Omen and run in detached `tmux` sessions on
2026-09-01.

* `probe_theta_family_o6.py`, session `theta-o6-final`, log
  `[local archival reference]`, source
  SHA-256 `7243e02795c82e1ad74d07cd992ce56ba02d89c7ff12b709dbafb984f28a0f94`.
  The imported optimized incidence engine was
  `search_small_real_sixpole_disjoint.py`.
* `search_random_actual_o6.py`, session `random-o6-final`, log
  `[local archival reference]`, source
  SHA-256 `ed7a893303627c77cd7bcb43848b7c357ff58dd45939961b2e3e451b98565c18`.

The terminal markers were `THETA_FAMILY_O6_PROBE_OK` and
`RANDOM_ACTUAL_O6_TARGETED_PROBE_OK`.

## Exact finite outputs

### Simple theta family

The six simple theta six-poles have branch-path lengths

\[
(1,2,6),(1,3,5),(1,4,4),(2,2,5),(2,3,4),(3,3,3).
\]

Each has eight internal vertices, nine proper edges, and six distinct
semiedge endpoints.  Actual relation sizes (raw assignments in a first-pair
gauge; colour-orbit signatures) are respectively

\[
(3354,92),(11238,117),(5838,147),(9528,119),
(6900,143),(9672,135).
\]

All 21 unordered pole pairs, including each pole paired with itself, were
checked against all (6!=720) port correspondences.  The minimum number of
common colour-orbit signatures was 6; no pair had zero overlap.  The minimum
table is recorded in the Omen log and generated directly by the script.

### Deterministic random regular-host construction

For four fixed seeds (`0,1,2,3`) at order (n=10), the script generated
connected cubic hosts, removed up to two deterministic vertex-disjoint
three-edge matchings, retained only connected proper-edge-bridgeless
six-poles, and enumerated the actual relations.  Six poles survived.  Their
raw/orbit relation sizes were

\[
9528/119,9528/119,20166/200,11238/117,11238/117,11238/117.
\]

All 21 retained pairs were checked over all 720 port correspondences.  The
minimum overlap was again 6; no zero-overlap pair occurred.  The test was
targeted at relation disjointness, not a census of six-cuts.

## Decision

The tested finite families give no real O6 countermodel:

\[
\boxed{\text{No disjoint actual relation pair in these theta and fixed-seed
order-10 constructions.}}
\]

This does **not** prove the universal cross-shore overlap lemma.  The strict
remaining statement is unchanged:

\[
\text{minimum BF/cyclically-6 structure}
\stackrel{?}{\Longrightarrow}
\mathcal R(X)\cap\sigma\mathcal R(Y)\ne\varnothing.
\]

The next meaningful advance would require either a general argument using the
common cubic vertex incidence of both poles, or a real disjoint pair.  Further
ordinary order scans are not justified by this result.
