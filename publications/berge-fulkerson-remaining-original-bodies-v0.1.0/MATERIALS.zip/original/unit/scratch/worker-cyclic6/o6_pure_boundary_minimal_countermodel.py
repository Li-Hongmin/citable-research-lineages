#!/usr/bin/env python3
"""Minimal pure-boundary countermodel for the six-cut cap condition.

The boundary labels are the 15 two-subsets of six matching labels.  A
signature is an ordered six-tuple of such labels, one for each port.  ``Cap``
requires a signature fixed by every perfect pairing of the six ports.  The
script constructs two (colour-orbit-closed) finite relation sets which both
satisfy Cap but have no common signature after a global S_6 relabelling.

This is intentionally a boundary-only model.  It checks the even colour
degree necessary for a BF boundary signature, but it does not pretend that
the sets are projections of one common cubic V-gate network.  In fact the
constant relation on the left is ruled out as an *exact* pole relation by a
short Kempe-path argument recorded below.
"""

from __future__ import annotations

from itertools import combinations, permutations


COLORS = tuple(range(6))
PORTS = tuple(range(6))
LABELS = tuple(combinations(COLORS, 2))
LABEL_INDEX = {label: i for i, label in enumerate(LABELS)}


def all_pairings():
    """The 15 perfect pairings of the six port positions."""
    result = []

    def rec(remaining, current):
        if not remaining:
            result.append(tuple(current))
            return
        first = min(remaining)
        for second in sorted(remaining - {first}):
            rec(remaining - {first, second}, current + [(first, second)])

    rec(set(PORTS), [])
    return tuple(result)


PAIRINGS = all_pairings()


def fixed(signature, pairing):
    return all(signature[a] == signature[b] for a, b in pairing)


def color_degrees(signature):
    return tuple(sum(color in LABELS[label] for label in signature) for color in COLORS)


def label_transforms():
    transforms = []
    for perm in permutations(COLORS):
        transforms.append(tuple(
            LABEL_INDEX[tuple(sorted((perm[a], perm[b])))]
            for a, b in LABELS
        ))
    return tuple(transforms)


TRANSFORMS = label_transforms()


def orbit(signature):
    return frozenset(
        tuple(transform[label] for label in signature)
        for transform in TRANSFORMS
    )


def orbit_union(signatures):
    answer = set()
    for signature in signatures:
        answer.update(orbit(signature))
    return frozenset(answer)


def cap_ok(relation):
    return all(any(fixed(signature, pairing) for signature in relation)
               for pairing in PAIRINGS)


def relation_orbit_disjoint(left, right):
    """Check disjointness after an arbitrary global colour relabelling."""
    return not any(orbit(signature) & set(right) for signature in left)


def equality_partition(signature):
    blocks = {}
    for position, label in enumerate(signature):
        blocks.setdefault(label, set()).add(position)
    return tuple(sorted((tuple(sorted(block)) for block in blocks.values())))


def four_two_fixed_pair_count(two_block):
    """Number of port pairings fixed by a 4+2 equality pattern."""
    return sum(
        all(set(pair) <= set(two_block) or set(pair).isdisjoint(two_block)
            for pair in pairing)
        for pairing in PAIRINGS
    )


def minimum_four_two_hitting_set():
    """Minimum number of 4+2 position patterns covering all pairings."""
    position_pairs = tuple(combinations(PORTS, 2))
    for size in range(1, len(position_pairs) + 1):
        for chosen in combinations(position_pairs, size):
            if all(any(two_block in pairing for two_block in chosen)
                   for pairing in PAIRINGS):
                return size, chosen
    raise AssertionError("a star is a hitting set")


def kempe_nonrealizability_of_constant_relation():
    """Explain why the exact constant relation cannot be one pole's R(H).

    In a valid cubic six-pole certificate with every boundary label A={0,1},
    inspect the (0,2)-coloured subgraph.  Every internal vertex has degree
    0 or 2 there, while the six boundary semiedge dummies are its six degree-1
    endpoints.  Hence a path component joins two dummies.  Swapping colours
    0 and 2 on that path changes exactly two boundary labels from {0,1} to
    {1,2}, producing a 4+2 signature.  Therefore an exact relation containing
    the constant orbit cannot consist only of constants.
    """
    a = LABEL_INDEX[(0, 1)]
    changed = LABEL_INDEX[(1, 2)]
    signature = (a,) * 6
    witness = (changed, changed, a, a, a, a)
    assert color_degrees(signature) == (6, 6, 0, 0, 0, 0)
    assert color_degrees(witness) == (4, 6, 2, 0, 0, 0)
    assert equality_partition(signature) != equality_partition(witness)
    return signature, witness


def main():
    a = LABEL_INDEX[(0, 1)]
    b = LABEL_INDEX[(2, 3)]  # disjoint from a; this is an S_6-invariant choice

    # One constant signature is enough for every cap pairing.  The second
    # relation uses a star of 4+2 position patterns: every perfect pairing
    # contains exactly one edge incident with port 0.
    left_rep = ((a,) * 6,)
    right_reps = tuple(
        tuple(b if position in (0, i) else a for position in PORTS)
        for i in range(1, 6)
    )
    left = orbit_union(left_rep)
    right = orbit_union(right_reps)

    assert len(PAIRINGS) == 15
    assert len(left) == 15
    assert len(right) == 5 * 90
    assert all(all(value % 2 == 0 for value in color_degrees(sig))
               for sig in left | right)
    assert cap_ok(left)
    assert cap_ok(right)
    assert relation_orbit_disjoint(left, right)

    # Every nonconstant equality pattern is fixed by at most three pairings;
    # 4+2 attains the maximum.  Thus a relation avoiding the constant orbit
    # needs at least five signatures.  The star above is optimal.
    max_nonconstant = 0
    for two_block in combinations(PORTS, 2):
        max_nonconstant = max(max_nonconstant,
                              four_two_fixed_pair_count(two_block))
    assert max_nonconstant == 3
    minimum, hitting_set = minimum_four_two_hitting_set()
    assert minimum == 5
    assert set(hitting_set) == {(0, i) for i in range(1, 6)}

    constant, kempe_witness = kempe_nonrealizability_of_constant_relation()
    assert constant in left
    assert kempe_witness not in left

    print({
        "pairings": len(PAIRINGS),
        "left_relation": "constant equality pattern 6",
        "right_relation": "4+2 equality pattern, star position cover",
        "left_orbit_representatives": len(left_rep),
        "right_orbit_representatives": len(right_reps),
        "left_raw_signatures": len(left),
        "right_raw_signatures": len(right),
        "left_cap": True,
        "right_cap": True,
        "global_S6_overlap": False,
        "minimum_nonconstant_cap_hitting_signatures": minimum,
        "optimal_position_hitting_set": sorted(hitting_set),
        "necessary_even_colour_degrees": True,
        "common_cubic_V_gate_exact_realization": False,
        "nonrealizability_reason": "Kempe path from constant boundary creates a 4+2 signature",
    })
    print("O6_PURE_BOUNDARY_MINIMAL_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
