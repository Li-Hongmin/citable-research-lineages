#!/usr/bin/env python3
"""One explicit real bridgeless six-pole overlap probe (C6 versus theta)."""

from __future__ import annotations

from itertools import permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE = HERE / "check_small_sixpole_boundary_overlap.py"
spec = spec_from_file_location("sixpole_relation", BASE)
assert spec is not None and spec.loader is not None
relation_module = module_from_spec(spec)
spec.loader.exec_module(relation_module)


def theta_126():
    """Theta graph with path lengths 1, 2, 6 and six distinct ports."""
    edges = []
    boundary = []
    next_vertex = 2
    for length in (1, 2, 6):
        previous = 0
        for _ in range(1, length):
            vertex = next_vertex
            next_vertex += 1
            edges.append((previous, vertex))
            boundary.append(vertex)
            previous = vertex
        edges.append((previous, 1))
    assert next_vertex == 8
    assert len(boundary) == 6
    return edges, boundary


def connected(n, edges):
    adjacency = [[] for _ in range(n)]
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def has_bridge(n, edges):
    for removed in range(len(edges)):
        remaining = edges[:removed] + edges[removed + 1 :]
        if not connected(n, remaining):
            return True
    return False


def main():
    c6_edges = [(i, (i + 1) % 6) for i in range(6)]
    c6_boundary = list(range(6))
    theta_edges, theta_boundary = theta_126()
    c6_relation, c6_raw = relation_module.relation(6, c6_edges, c6_boundary)
    theta_relation, theta_raw = relation_module.relation(
        8, theta_edges, theta_boundary
    )
    minimum = min(
        len(c6_relation & relation_module.reordered(theta_relation, positions))
        for positions in permutations(range(6))
    )
    assert (c6_raw, len(c6_relation)) == (3354, 92)
    assert (theta_raw, len(theta_relation)) == (3354, 92)
    assert len(c6_relation & theta_relation) == 92
    assert minimum == 6

    # Glue the two ordered port lists and verify the advertised real host.
    glued_edges = list(c6_edges)
    glued_edges.extend((u + 6, v + 6) for u, v in theta_edges)
    glued_edges.extend((i, theta_boundary[i] + 6) for i in range(6))
    assert len(glued_edges) == len(set(tuple(sorted(edge)) for edge in glued_edges))
    assert connected(14, glued_edges)
    assert not has_bridge(14, glued_edges)
    assert all(
        sum(vertex in edge for edge in glued_edges) == 3 for vertex in range(14)
    )
    print(
        {
            "c6": {"raw": c6_raw, "orbits": len(c6_relation)},
            "theta_126": {"raw": theta_raw, "orbits": len(theta_relation)},
            "direct_intersection": len(c6_relation & theta_relation),
            "minimum_over_boundary_reorderings": minimum,
            "glued_host": {
                "vertices": 14,
                "edges": len(glued_edges),
                "simple": True,
                "connected": True,
                "cubic": True,
                "bridgeless": True,
                "cycle_separating_cut": 6,
            },
        }
    )
    print("BRIDGELESS_SIXPOLE_OVERLAP_PROBE_OK")


if __name__ == "__main__":
    main()
