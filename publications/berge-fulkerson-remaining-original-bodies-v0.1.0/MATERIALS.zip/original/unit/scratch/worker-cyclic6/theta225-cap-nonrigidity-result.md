# One real all-cap six-pole without a pairing-independent cap orbit

## Scope

This is one explicit real six-pole check for the cyclically-6 common-cap
interface.  It is not a census and it does not search for a disjoint pair of
six-pole relations.

Let (H=Theta(2,2,5)) be the simple theta core with endpoints (0,1) and
three internally disjoint (0)--(1) paths of lengths (2,2,5).  The six
internal degree-two vertices carry the ordered semiedges.  The proper core has
8 vertices and 9 edges and is bridgeless.

The verifier
`verify_theta225_cap_nonrigidity.py` enumerates the actual six-matching
incidence assignments: each proper edge and semiedge receives a two-element
subset of the six matching labels, and the three labels at every internal
vertex partition ([6]).  Only a global (S_6) colour quotient is taken.

## Exact output

The pole has 9528 assignments after fixing the first semiedge to ({1,2}),
and 119 ordered boundary-signature orbits.  Every one of the 15 pairings of
the six semiedges has at least one realised cap-fixed orbit; the numbers of
fixed orbits are

\[
(3,1,3,3,1,3,3,3,1,1,3,3,3,1,3).
\]

The proper core and all 15 capped closures are bridgeless.  Nevertheless,
there is no signature orbit whose six boundary entries are all equal.  Thus
all-cap minimality does not force a pairing-independent (constant) cap
signature, even for a simple, connected, proper-edge-bridgeless six-pole.

This is an actual perfect-matching-incidence boundary: the cap-fixed
certificates are restrictions of concrete BF covers of the capped cubic
graphs, not parity or aggregate-load vectors.

## Consequence for the two-side overlap gate

The example does **not** violate the required overlap condition

\[
\exists\rho_X\in\mathcal R(H_X),
\rho_Y\in\mathcal R(H_Y),
\pi\in S_6:
\rho_X(j)=\pi(\rho_Y(j))\quad(1\le j\le6).
\]

It only rules out the stronger shortcut “all cap closures select one
pairing-independent boundary orbit.”  The exact remaining sufficient
condition is common-cap compatibility for one shared pairing (p):

\[
\bigl(\mathcal R(H_X)\cap\operatorname{Fix}(p)\bigr)/S_6
\;\cap\;
\bigl(\mathcal R(H_Y)\cap\operatorname{Fix}(p)\bigr)/S_6
\ne\varnothing.
\]

Minimality supplies nonemptiness of each factor separately, but no equality or
intersection between the two sides.  Therefore the cyclically-6 common-cap
gate remains strictly unresolved.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-cyclic6/verify_theta225_cap_nonrigidity.py
```

Terminal marker: `THETA225_ALL_CAPS_NONRIGID_VERIFIED`.
