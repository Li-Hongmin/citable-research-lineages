# BF cyclically-6 branch: decision search (2026-08-29)

## Decision

The statement

> Every cyclically 6-edge-connected bridgeless cubic graph satisfies the Berge--Fulkerson conjecture

is not covered by a theorem found in the targeted literature search and remains open.  Existing results prove BF only for particular cyclically-6-connected families.  No genuine BF counterexample is known.

The result is a boundary/open case, not a proof and not a counterexample.

## Primary evidence

1. **Reduction of BF minimum counterexamples.**  Máčajová--Mazzuoccolo, *Reduction of the Berge-Fulkerson conjecture to cyclically 5-edge-connected snarks*, Proc. Amer. Math. Soc. **148** (2020), 4643--4652, DOI [10.1090/proc/15057](https://doi.org/10.1090/proc/15057), Theorem 1.2 (p. 4644): a minimum BF counterexample must be cyclically 5-edge-connected.  The paragraph immediately following the theorem says that, if the Jaeger--Swart conjecture holds, a possible BF counterexample has cyclic connectivity **5 or 6**.  Thus the cyclically-6 branch is explicitly left as a final branch, not eliminated.

2. **Only family-level cyclically-6 BF theorem located.**  Liu--Hao--Zhang, *Berge--Fulkerson coloring for some families of superposition snarks*, European J. Combin. **96** (2021), 103344, DOI [10.1016/j.ejc.2021.103344](https://doi.org/10.1016/j.ejc.2021.103344), abstract: BF is verified for Kochol's infinite family \(S_K\) of cyclically 6-edge-connected superposition snarks and larger families; the authors call it the first paper on BF for superposition snarks and cyclically-6-edge-connected snarks.  The quantifier is a named family, not all cyclically-6-connected snarks.

3. **Current structural status.**  Máčajová--Mazzuoccolo--Tabarelli, *Cycle separating cuts in possible counterexamples to the cycle double cover and the Berge--Fulkerson conjectures*, Ars Math. Contemp. **26** (2026), #P2.03, DOI [10.26493/1855-3974.3409.c13](https://doi.org/10.26493/1855-3974.3409.c13), introduction p. 2 and conclusion p. 18: the BF analysis is for the cyclically-5-connected case; it states that cyclic connectivity 5 remains possible.  It gives no all-cyclically-6 BF theorem.

## Jaeger--Swart is a different conjecture

Jaeger--Swart conjectured that no snark has cyclic connectivity **greater than 6** (equivalently, no cyclically-7-edge-connected snark); source: F. Jaeger and T. Swart, “Problem Session, Combinatorics 1979, Part II,” *Ann. Discrete Math.* **9** (1980), p. 305.  This is an existence/structure conjecture about non-3-edge-colourable cubic graphs, not a BF-cover theorem.

Mazák--Rajník--Škoviera, *Strictly critical snarks with girth or cyclic connectivity equal to 6*, Discrete Math. (published version DOI [10.1016/j.disc.2025.114827](https://doi.org/10.1016/j.disc.2025.114827); arXiv:2406.16618), Theorem 1.2, constructs cyclically-6-connected strictly critical snarks of every even order \(n\ge342\).  Their introduction (pp. 3--4) says the >6 Jaeger--Swart conjecture remains open.  Hence exact cyclic connectivity 6 is a nonempty, genuine class; one cannot use Jaeger--Swart to make the BF-6 branch vacuous.

## Distinct conjectures and implications

- **BF:** six (not necessarily distinct) perfect matchings of every bridgeless cubic graph, each edge occurring exactly twice.
- **PCC (Jaeger/Petersen coloring):** every bridgeless cubic graph admits a Petersen \(P_{10}\)-coloring; equivalently a normal 5-edge-colouring (Mazzuoccolo--Mkrtchyan, J. Graph Theory 2018, DOI [10.1002/jgt.22507](https://doi.org/10.1002/jgt.22507), Proposition 1, p. 3).  Petersen coloring implies BF (and CDC), but BF is not thereby proved by cyclic connectivity.
- **CDC:** every bridgeless graph (not only cubic) has a cycle double cover.  It is a different, weaker/general problem; do not substitute a CDC reduction for a BF theorem.
- **Jaeger--Swart:** no non-3-edge-colourable cubic graph of cyclic connectivity >6.  It is not PCC and not BF.

Kochol's *Reduction of the 5-Flow Conjecture to cyclically 6-edge-connected snarks*, J. Combin. Theory B **90** (2004), 139--145, DOI [10.1016/S0095-8956(03)00080-7](https://doi.org/10.1016/S0095-8956(03)00080-7), is a reduction for Tutte's 5-flow conjecture only; it does not imply BF.

## Four-way classification

| Candidate claim | Status |
|---|---|
| All cyclically-6-connected bridgeless cubic graphs are BF-colorable | **Strict open boundary / route not closed by literature** |
| BF for Kochol/Liu--Hao--Zhang superposition families | **Existing theorem (restricted family)** |
| A cyclically-6-connected BF counterexample | **No known real counterexample** |
| Jaeger--Swart elimination of the branch | **Not available; it concerns >6, not 6** |

The direct mathematical interface for the project is therefore still the common perfect-matching incidence/section problem on a hypothetical cyclically-6-connected minimum BF counterexample.  Connectivity alone currently supplies no BF-cover construction.

