# O6 through one common cap: exact three-edge profile criterion

## Scope and decision

Let \(H\) be an ordered cubic six-pole and let

\[
p=\{\{a_1,b_1\},\{a_2,b_2\},\{a_3,b_3\}\}
\]

be a port pairing whose cap closure \(K=H/p\) is admissible. Write
\(f_r\) for the cap edge joining ports \(a_r,b_r\). This note identifies
exactly what a common-cap argument must compare across the two shores of a
cycle-separating six-cut. It uses no graph scan.

The outcome is a strict additional condition and a route closure, not a
general proof of O6. No pair of actual six-poles with disjoint full boundary
relations is produced.

## Cap restriction is an equivariant bijection

For an ordered Berge--Fulkerson cover

\[
\mathcal M=(M_1,\ldots,M_6)
\]

of \(K\), put

\[
A_r(\mathcal M)=\{i:f_r\in M_i\}\in\binom{[6]}2.
\]

Deleting the three cap edges restricts \(\mathcal M\) to a six-matching
certificate of \(H\) whose boundary signature satisfies

\[
\rho_{a_r}=\rho_{b_r}=A_r(\mathcal M),\qquad r=1,2,3. \tag{1}
\]

Conversely, if an actual certificate of \(H\) has a \(p\)-fixed signature,
then joining the two semiedges in each pair turns the six matching edge sets
into six perfect matchings of \(K\). Equation (1) ensures that a matching
uses either both semiedges before capping or the resulting cap edge after
capping. Proper-edge load two is unchanged, and each cap edge has load two.

These two operations are inverse and commute with one global permutation of
the six matching labels. Hence there is an \(S_6\)-equivariant bijection

\[
\operatorname{BF}(K)
\longleftrightarrow
\{\text{actual certificates of \(H\) with signature in }
  \operatorname{Fix}(p)\}. \tag{2}
\]

In particular, no **boundary information relevant to gluing** is lost inside
a fixed cap fibre by recording the three distinguished cap-edge labels: the
six boundary entries are exactly those three labels, each repeated on its
prescribed port pair. Different capped covers can of course have different
proper-edge incidences while inducing the same boundary triple.

## The complete four-number cap profile

For an ordered triple \(A=(A_1,A_2,A_3)\) of two-subsets of \([6]\), define

\[
\tau(A)=
\bigl(
 |A_1\cap A_2|,
 |A_1\cap A_3|,
 |A_2\cap A_3|,
 |A_1\cap A_2\cap A_3|
\bigr). \tag{3}
\]

This is a complete invariant for the global \(S_6\)-orbit of \(A\).
Indeed, the four numbers in (3), together with \(|A_r|=2\), determine the
cardinality of every cell in the Venn diagram of \(A_1,A_2,A_3\), including
the unused-colour cell. Two triples with the same cell cardinalities are
carried to one another by a permutation of the six colours. The converse is
immediate.

Equivalently, the possible profiles are the sixteen labelled-edge isomorphism
types of a three-edge loopless multigraph on at most six colour vertices:

* all three edges distinct: the disjoint matching, one adjacent pair, the
  three-edge path, the triangle, or the three-edge star, with the labelled
  positions distinguished; these give \(1+3+3+2=9\) profiles;
* exactly two edges equal, while the third is disjoint from them or meets
  them in one endpoint, with the repeated pair of positions distinguished;
  these give \(3+3=6\) profiles;
* all three edges equal, giving one profile.

Thus the complete cap-edge orbit universe has size \(16\), not an unbounded
signature space.

Define the actual three-cap spectrum

\[
\Sigma_p(H)=
\{\tau(A_1(\mathcal M),A_2(\mathcal M),A_3(\mathcal M)):
  \mathcal M\text{ is a BF cover of }H/p\}. \tag{4}
\]

By (2)--(3), \(\Sigma_p(H)\) is canonically the quotient

\[
\bigl(\mathcal R(H)\cap\operatorname{Fix}(p)\bigr)/S_6. \tag{5}
\]

## Exact common-cap gluing criterion

Let \(H_X,H_Y\) be the ordered shores of a six-cut and use the same pairing
\(p\) of corresponding port positions on both sides. Then O6 has a solution
inside the \(p\)-fixed fibres if and only if

\[
\boxed{\Sigma_p(H_X)\cap\Sigma_p(H_Y)\ne\varnothing.} \tag{6}
\]

For the forward direction, a common \(p\)-fixed boundary orbit has the same
profile by (3). For the reverse direction, equal profiles give a global
colour permutation aligning the three ordered cap labels, hence all six
boundary entries by (1); the exact six-cut gluing lemma then gives a BF cover
of the host graph.

The rainbow-cap condition is the single profile

\[
(0,0,0,0),
\]

so it is a proper special case of (6). The pairing-independent constant
signature is the single profile

\[
(2,2,2,2),
\]

and is another proper special case.

## What minimality does and does not imply

If both cap closures for \(p\) are bridgeless and smaller than a minimum BF
counterexample, minimality gives only

\[
\Sigma_p(H_X)\ne\varnothing,
\qquad
\Sigma_p(H_Y)\ne\varnothing. \tag{7}
\]

Two nonempty subsets of the sixteen-profile universe need not intersect.
Consequently (7) does not imply (6) without a theorem coupling the two actual
perfect-matching families. Applying (7) for all fifteen pairings still has
the quantifier form

\[
\forall p\ \exists\sigma_X(p),\sigma_Y(p),
\]

not the common-profile assertion required by (6).

The known boundaries show that the most natural attempts to supply this
coupling are genuinely insufficient:

* two real theta six-poles have all cap closures bridgeless and BF-colourable
  but have disjoint sets of pairings supporting the rainbow profile;
* the real \(\Theta(2,2,5)\) pole has all fifteen nonempty cap fibres but no
  pairing-independent constant orbit;
* a genuine cyclically-six Heawood two-shore host has disjoint balanced
  subrelations at its six-cut although its full relations overlap;
* the same Heawood setting supports an inseparable alternating carrier without
  forcing a smaller cyclic cut.

Therefore a proof cannot depend only on shore-local nonemptiness, rainbow or
balanced normalization, a constant cap orbit, or carrier topology. It must
control how balanced and unbalanced certificates in the two complete actual
perfect-matching relations co-vary, sufficiently to force (6) for some common
pairing or to force full O6 overlap without a cap.

## Four-value verdict

* **General O6 theorem:** not proved.
* **Actual full-relation counterexample:** not found; none of the cited real
  examples has disjoint complete relations.
* **Strict additional condition:** proved exactly by (6), with the cap fibre
  compressed to the sixteen profiles (3).
* **Route decision:** shore-local cap minimality and its balanced, rainbow,
  constant-orbit, and carrier refinements are closed. The next thin interface
  is a cross-shore exchange theorem for the complete actual relations, not a
  larger order scan.

This conclusion concerns exact cyclic connectivity six when a
cycle-separating six-cut exists. It says nothing about the
\(\lambda_c>6\) branch. It also does not resolve or assume the open
\(m(5)=5\) problem arising from the separate 5-regular reduction.
