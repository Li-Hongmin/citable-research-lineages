"""Verify the real-pole boundary of the rainbow-cap normalization route.

The two poles are the simple eight-vertex theta cores with path lengths
(1,4,4) and (3,3,3).  Their six degree-two vertices carry one semiedge
each.  We use the exact common perfect-matching incidence engine already
used by ``probe_n8_theta_overlap.py``.

For a boundary pairing p, a p-fixed signature is *rainbow* when the three
repeated two-colour labels are pairwise disjoint.  Equivalently, in the
BF cover of the zero-vertex capped closure, each of the six perfect
matchings uses exactly one of the three cap edges.

The verifier checks that every capped closure on each pole is bridgeless
and BF-colourable, but that the two poles have disjoint sets of pairings
admitting a rainbow cap certificate.  This is not an O6 counterexample:
their full real relations, and many non-rainbow cap fibres, do intersect.
"""

from __future__ import annotations

import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "probe_n8_theta_overlap.py"
SPEC = spec_from_file_location("rainbow_cap_n8_source", SOURCE)
assert SPEC is not None and SPEC.loader is not None
SOURCE_MODULE = module_from_spec(SPEC)
sys.modules[SPEC.name] = SOURCE_MODULE
SPEC.loader.exec_module(SOURCE_MODULE)
ENGINE = SOURCE_MODULE.engine


def pairings(remaining: tuple[int, ...] = tuple(range(6))):
    if not remaining:
        return ((),)
    first = remaining[0]
    result = []
    for index in range(1, len(remaining)):
        second = remaining[index]
        rest = remaining[1:index] + remaining[index + 1 :]
        result.extend(
            ((first, second),) + tail for tail in pairings(rest)
        )
    return tuple(result)


def connected(n: int, edges: tuple[tuple[int, int], ...], skip=None) -> bool:
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index == skip:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    return connected(n, edges) and all(
        connected(n, edges, skip=index) for index in range(len(edges))
    )


def fixed(signature, pairing) -> bool:
    return all(signature[a] == signature[b] for a, b in pairing)


def rainbow(signature, pairing) -> bool:
    if not fixed(signature, pairing):
        return False
    labels = [set(ENGINE.PAIRS[signature[a]]) for a, _ in pairing]
    return len(set().union(*labels)) == 6


def capped_edges(proper, boundary, pairing):
    return tuple(proper) + tuple(
        tuple(sorted((boundary[a], boundary[b]))) for a, b in pairing
    )


def main() -> None:
    names = ((1, 4, 4), (3, 3, 3))
    expected = {
        (1, 4, 4): (5838, 147, frozenset({2, 6, 8, 10, 11, 13})),
        (3, 3, 3): (9672, 135, frozenset({0, 7, 12})),
    }
    all_pairings = pairings()
    assert len(all_pairings) == 15

    relations = {}
    rainbow_supports = {}
    fixed_supports = {}
    for name in names:
        proper, boundary = SOURCE_MODULE.theta(name)
        relation, raw = ENGINE.exact_relation(proper, boundary)
        relations[name] = relation
        assert len(set(boundary)) == 6
        assert bridgeless(8, tuple(proper))

        fixed_support = set()
        rainbow_support = set()
        for index, pairing in enumerate(all_pairings):
            assert bridgeless(
                8, capped_edges(tuple(proper), tuple(boundary), pairing)
            )
            fibre = [signature for signature in relation if fixed(signature, pairing)]
            assert fibre
            fixed_support.add(index)
            if any(rainbow(signature, pairing) for signature in fibre):
                rainbow_support.add(index)

        expected_raw, expected_orbits, expected_rainbow = expected[name]
        assert raw == expected_raw
        assert len(relation) == expected_orbits
        assert fixed_support == set(range(15))
        assert frozenset(rainbow_support) == expected_rainbow
        fixed_supports[name] = frozenset(fixed_support)
        rainbow_supports[name] = frozenset(rainbow_support)

    left, right = names
    assert not (rainbow_supports[left] & rainbow_supports[right])

    # The example closes only the rainbow normalization shortcut.  It is not
    # a counterexample to common-cap overlap or to O6 itself.
    common_relation = relations[left] & relations[right]
    common_cap_pairings = {
        index
        for index, pairing in enumerate(all_pairings)
        if any(fixed(signature, pairing) for signature in common_relation)
    }
    assert len(common_relation) == 47
    assert common_cap_pairings == {0, 1, 2, 3, 5, 6, 9, 11, 12, 13, 14}

    print(
        {
            "poles": names,
            "all_15_caps_bridgeless_and_bf": True,
            "rainbow_pairings_left": tuple(sorted(rainbow_supports[left])),
            "rainbow_pairings_right": tuple(sorted(rainbow_supports[right])),
            "common_rainbow_pairings": (),
            "full_relation_intersection": len(common_relation),
            "common_nonrainbow_cap_pairings": tuple(sorted(common_cap_pairings)),
        }
    )
    print("RAINBOW_CAP_REAL_POLE_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
