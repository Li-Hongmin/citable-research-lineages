#!/usr/bin/env python3
"""Bounded Omen probe for class-2 5-regular graphs.

This is only a discriminator for the broad m(5)=5 gate.  It samples small
simple 5-regular graphs, filters edge-connectivity and nontrivial 5-cuts,
then exactly searches for five edge-disjoint perfect matchings.  A hit is a
strict finite counterexample to the broad 5-graph statement; a no-hit is not
an all-order theorem.
"""

from __future__ import annotations

import argparse
from itertools import combinations
import networkx as nx


def edge_cut(g: nx.Graph, subset: set[int]) -> int:
    return sum((u in subset) != (v in subset) for u, v in g.edges())


def has_nontrivial_5_cut(g: nx.Graph) -> bool:
    n = g.number_of_nodes()
    vertices = tuple(sorted(g.nodes()))
    # A cut and its complement are the same; retain vertex 0 and stop at n/2.
    for size in range(2, n // 2 + 1):
        for rest in combinations(vertices[1:], size - 1):
            subset = {vertices[0], *rest}
            if edge_cut(g, subset) == 5:
                return True
    return False


def perfect_matchings(g: nx.Graph) -> tuple[frozenset[tuple[int, int]], ...]:
    edges = tuple(sorted(tuple(sorted(e)) for e in g.edges()))
    incident = {v: [] for v in g}
    for i, (u, v) in enumerate(edges):
        incident[u].append(i)
        incident[v].append(i)
    result: list[frozenset[tuple[int, int]]] = []

    def rec(unmatched: frozenset[int], chosen: tuple[int, ...]) -> None:
        if not unmatched:
            result.append(frozenset(edges[i] for i in chosen))
            return
        u = min(unmatched)
        for i in incident[u]:
            a, b = edges[i]
            v = b if a == u else a
            if v in unmatched:
                rec(unmatched - {u, v}, chosen + (i,))

    rec(frozenset(g.nodes()), ())
    return tuple(result)


def has_factorization(g: nx.Graph) -> tuple[bool, int]:
    edges = frozenset(tuple(sorted(e)) for e in g.edges())
    pms = perfect_matchings(g)
    by_edge = {e: [] for e in edges}
    for i, pm in enumerate(pms):
        for e in pm:
            by_edge[e].append(i)

    def rec(remaining: frozenset[tuple[int, int]], depth: int) -> bool:
        if not remaining:
            return True
        if depth == 5:
            return False
        pivot = min(remaining, key=lambda e: len(by_edge[e]))
        for i in by_edge[pivot]:
            pm = pms[i]
            if pm <= remaining and rec(remaining - pm, depth + 1):
                return True
        return False

    return rec(edges, 0), len(pms)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--orders", nargs="+", type=int, default=[6, 8, 10, 12])
    ap.add_argument("--samples", type=int, default=200)
    args = ap.parse_args()
    rows = []
    hits = []
    for n in args.orders:
        if n % 2 or n < 6:
            raise SystemExit("orders must be even and >= 6")
        for seed in range(args.samples):
            g = nx.random_regular_graph(5, n, seed=seed + 1009 * n)
            if not nx.is_connected(g):
                continue
            # A simple 5-regular graph is automatically at least 5-edge
            # connected only after this explicit cut check.
            mincut = nx.edge_connectivity(g)
            if mincut < 5:
                continue
            nontrivial = has_nontrivial_5_cut(g)
            fact, pm_count = has_factorization(g)
            row = {"n": n, "seed": seed, "edge_connectivity": mincut,
                   "nontrivial_5_cut": nontrivial,
                   "perfect_matchings": pm_count, "class1": fact}
            rows.append(row)
            if not fact and not nontrivial:
                hits.append(row | {"edges": sorted(tuple(sorted(e)) for e in g.edges())})
    print({"orders": args.orders, "samples": args.samples,
           "tested": len(rows), "class2_no_nontrivial_5cut": len(hits),
           "class1_counts": {n: sum(r["class1"] for r in rows if r["n"] == n)
                             for n in args.orders},
           "hits": hits[:3]})
    if hits:
        print("CLASS2_5REGULAR_HIT")
    else:
        print("NO_CLASS2_5REGULAR_HIT_IN_BOUNDED_SAMPLE")
    print("OMEN_5REGULAR_CLASS2_PROBE_OK")


if __name__ == "__main__":
    main()
