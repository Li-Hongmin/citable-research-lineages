"""Targeted probe for the rainbow-cap carrier obstruction in Heawood.

This is deliberately one fixed cyclically-6-connected cubic graph and one
fixed 28-vertex two-shore gluing, not a graph census.  It enumerates the
Heawood perfect matchings and all six-matching BF cover multisets, verifies a
non-rainbow global minimum of the collision potential, and checks the cyclic
edge connectivity of the fixed gluing by exhaustive deletion of at most five
edges.
"""

from itertools import combinations, combinations_with_replacement


EDGES = tuple(
    sorted(
        (
            (0, 1), (0, 5), (0, 13), (1, 2), (1, 10), (2, 3), (2, 7),
            (3, 4), (3, 12), (4, 5), (4, 9), (5, 6), (6, 7), (6, 11),
            (7, 8), (8, 9), (8, 13), (9, 10), (10, 11), (11, 12),
            (12, 13),
        )
    )
)
CAP = (0, 5, 10)
PORTS = (0, 1, 2, 3, 4, 9)
PAIRING = ((0, 1), (2, 3), (4, 5))
GOOD_GLUE = (0, 1, 3, 2, 4, 5)


def perfect_matchings():
    incident = [[] for _ in range(14)]
    for edge_index, (u, v) in enumerate(EDGES):
        incident[u].append((edge_index, v))
        incident[v].append((edge_index, u))
    result = []

    def rec(unmatched, chosen):
        if not unmatched:
            result.append(frozenset(chosen))
            return
        vertex = min(unmatched)
        for edge_index, neighbour in incident[vertex]:
            if neighbour in unmatched:
                rec(unmatched - {vertex, neighbour}, chosen + [edge_index])

    rec(set(range(14)), [])
    return tuple(result)


def bf_covers(matchings):
    target = (2,) * len(EDGES)
    incidence = [tuple(int(e in matching) for e in range(len(EDGES))) for matching in matchings]
    result = []
    for choice in combinations_with_replacement(range(len(matchings)), 6):
        loads = tuple(sum(incidence[index][edge] for index in choice) for edge in range(len(EDGES)))
        if loads == target:
            result.append(choice)
    return tuple(result)


def components(n, edges, deleted=frozenset()):
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index in deleted:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    result = []
    unseen = set(range(n))
    while unseen:
        start = min(unseen)
        seen = {start}
        stack = [start]
        while stack:
            for vertex in adjacency[stack.pop()]:
                if vertex not in seen:
                    seen.add(vertex)
                    stack.append(vertex)
        unseen -= seen
        result.append(frozenset(seen))
    return tuple(result)


def connected(n, edges):
    return len(components(n, edges)) == 1


def bridgeless(n, edges):
    return connected(n, edges) and all(
        connected(n, tuple(edge for j, edge in enumerate(edges) if j != index))
        for index in range(len(edges))
    )


def potential(matchings, cover, cap):
    degrees = tuple(sum(edge in matchings[index] for edge in cap) for index in cover)
    return sum(degree * (degree - 1) // 2 for degree in degrees), tuple(sorted(degrees, reverse=True))


def cyclic_connectivity_at_least_six(n, edges):
    """Check absence of a cycle-separating edge cut of size at most five."""
    for cut_size in range(1, 6):
        for deleted in combinations(range(len(edges)), cut_size):
            parts = components(n, edges, frozenset(deleted))
            cyclic = 0
            for component in parts:
                internal = sum(u in component and v in component for u, v in edges)
                cyclic += internal >= len(component)
            if cyclic >= 2:
                return False, cut_size, tuple(sorted(tuple(sorted(c)) for c in parts))
    return True, None, None


def doubled_pole(cap, port_permutation):
    proper = tuple(edge for index, edge in enumerate(EDGES) if index not in cap)
    ports = tuple(vertex for edge_index in cap for vertex in EDGES[edge_index])
    second = tuple((u + 14, v + 14) for u, v in proper)
    cut = tuple((ports[index], ports[port_permutation[index]] + 14) for index in range(6))
    return proper + second + cut, ports


def alternating_components(edge_indices):
    adjacency = [[] for _ in range(14)]
    for edge_index in edge_indices:
        u, v = EDGES[edge_index]
        adjacency[u].append((edge_index, v))
        adjacency[v].append((edge_index, u))
    assert all(len(items) in (0, 2) for items in adjacency)
    result = []
    unseen = {vertex for vertex in range(14) if adjacency[vertex]}
    while unseen:
        start = min(unseen)
        vertices = {start}
        component_edges = set()
        stack = [start]
        while stack:
            for edge_index, vertex in adjacency[stack.pop()]:
                component_edges.add(edge_index)
                if vertex not in vertices:
                    vertices.add(vertex)
                    stack.append(vertex)
        unseen -= vertices
        result.append(frozenset(component_edges))
    return tuple(result)


def three_edge_colorable(n, edges):
    """A cubic graph is 3-edge-colourable iff some 1-factor has even 2-factor."""
    incident = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        incident[u].append((index, v))
        incident[v].append((index, u))

    def even_complement(chosen):
        adjacency = [[] for _ in range(n)]
        for index, (u, v) in enumerate(edges):
            if index not in chosen:
                adjacency[u].append(v)
                adjacency[v].append(u)
        seen = set()
        for start in range(n):
            if start in seen:
                continue
            size = 0
            seen.add(start)
            stack = [start]
            while stack:
                size += 1
                for vertex in adjacency[stack.pop()]:
                    if vertex not in seen:
                        seen.add(vertex)
                        stack.append(vertex)
            if size % 2:
                return False
        return True

    def rec(unmatched, chosen):
        if not unmatched:
            return even_complement(frozenset(chosen))
        vertex = min(unmatched)
        return any(
            rec(unmatched - {vertex, neighbour}, chosen + [edge_index])
            for edge_index, neighbour in incident[vertex]
            if neighbour in unmatched
        )

    return rec(set(range(n)), [])


def main():
    assert tuple(EDGES[index] for index in CAP) == ((0, 1), (2, 3), (4, 9))
    assert tuple(vertex for edge_index in CAP for vertex in EDGES[edge_index]) == PORTS

    # The capped graph is Heawood, and its chosen six-pole core is connected
    # and proper-edge-bridgeless.
    proper = tuple(edge for index, edge in enumerate(EDGES) if index not in CAP)
    assert len(proper) == 18
    assert bridgeless(14, proper)
    assert cyclic_connectivity_at_least_six(14, EDGES) == (True, None, None)

    # Exact fixed-cap BF enumeration.  No rainbow cover exists: the global
    # minimum is Phi=1, always with profile 2,1,1,1,1,0.
    matchings = perfect_matchings()
    covers = bf_covers(matchings)
    assert len(matchings) == 24
    assert len(covers) == 148
    minimum = min(potential(matchings, cover, CAP)[0] for cover in covers)
    minimizers = tuple(cover for cover in covers if potential(matchings, cover, CAP)[0] == minimum)
    assert minimum == 1
    assert len(minimizers) == 12
    assert {potential(matchings, cover, CAP)[1] for cover in minimizers} == {
        (2, 1, 1, 1, 1, 0)
    }

    carrier_lengths = []
    for cover in minimizers:
        degrees = tuple(sum(edge in matchings[index] for edge in CAP) for index in cover)
        repeated = degrees.index(2)
        missing = degrees.index(0)
        carried = frozenset(matchings[cover[repeated]] & frozenset(CAP))
        assert len(carried) == 2
        symmetric_difference = matchings[cover[repeated]] ^ matchings[cover[missing]]
        components_ = alternating_components(symmetric_difference)
        carriers = [component for component in components_ if component & carried]
        assert len(carriers) == 1
        assert carried <= carriers[0]
        carrier_lengths.append(len(carriers[0]))
    assert sorted(carrier_lengths) == [6] * 8 + [10] * 4

    # One literal carrier: the first minimizer has repeated colour 0 and
    # missing colour 2.  Their alternating C6 carries cap edges 01 and 23.
    explicit_cover = (0, 5, 10, 15, 19, 20)
    assert minimizers[0] == explicit_cover
    explicit_degrees = tuple(
        sum(edge in matchings[index] for edge in CAP) for index in explicit_cover
    )
    assert explicit_degrees == (2, 1, 0, 1, 1, 1)
    explicit_components = alternating_components(matchings[0] ^ matchings[10])
    carrier = frozenset(EDGES.index(tuple(sorted(edge))) for edge in (
        (0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (0, 5)
    ))
    assert carrier in explicit_components
    assert frozenset(CAP) & carrier == frozenset((0, 5))
    carrier_inside_pole = tuple(EDGES[index] for index in sorted(carrier - frozenset(CAP)))
    assert carrier_inside_pole == ((0, 5), (1, 2), (3, 4), (4, 5))

    # The previous identity gluing really does fail: it has the displayed
    # cyclic 4-cut.  The fixed construction uses GOOD_GLUE instead.
    identity_graph, identity_ports = doubled_pole(CAP, tuple(range(6)))
    assert identity_ports == PORTS
    identity_check = cyclic_connectivity_at_least_six(28, identity_graph)
    assert identity_check[0] is False and identity_check[1] == 4
    assert (1, 2, 15, 16) in identity_check[2]

    # GOOD_GLUE preserves the same cap pairing on both shores, but crosses
    # the middle pair.  Its six inter-shore edges are a cycle-separating
    # 6-cut, and exhaustive deletion proves there is no smaller cyclic cut.
    graph, ports = doubled_pole(CAP, GOOD_GLUE)
    assert ports == PORTS
    assert all({GOOD_GLUE[a], GOOD_GLUE[b]} in ({0, 1}, {2, 3}, {4, 5}) for a, b in PAIRING)
    assert len(graph) == 42 and len(set(graph)) == 42
    assert all(sum(vertex in edge for edge in graph) == 3 for vertex in range(28))
    assert bridgeless(28, graph)
    assert cyclic_connectivity_at_least_six(28, graph) == (True, None, None)
    assert three_edge_colorable(28, graph)
    left = set(range(14))
    cut = tuple(edge for edge in graph if (edge[0] in left) != (edge[1] in left))
    assert cut == ((0, 14), (1, 15), (2, 17), (3, 16), (4, 18), (9, 23))
    assert len(cut) == 6

    print({
        "cap_edges": tuple(EDGES[index] for index in CAP),
        "perfect_matchings": len(matchings),
        "bf_cover_multisets": len(covers),
        "minimum_phi": minimum,
        "minimizers": len(minimizers),
        "minimum_profile": (2, 1, 1, 1, 1, 0),
        "carrier_cycle_lengths": {6: 8, 10: 4},
        "literal_carrier_after_uncapping": "paths 1-2 and 0-5-4-3",
        "identity_gluing": {"cyclic_connectivity_at_least_6": False, "witness_cut": 4},
        "fixed_gluing": GOOD_GLUE,
        "fixed_28_vertex_graph_cyclic_connectivity": 6,
        "proper_cores_bridgeless": True,
        "fixed_graph_three_edge_colourable": True,
    })
    print("HEAWOOD_CARRIER_LINKAGE_LOCAL_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
