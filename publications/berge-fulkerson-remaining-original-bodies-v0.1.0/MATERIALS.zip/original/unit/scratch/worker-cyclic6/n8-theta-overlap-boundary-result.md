# Finite cyclically-6 boundary: all (n=8) theta six-poles overlap

## Scope and exact object class

This is a finite boundary result for the six-cut interface only.  The pole
class is:

* a simple connected cubic six-pole (H);
* exactly six semiedges, at six distinct internal vertices;
* (n=8) internal vertices;
* the proper-edge core (F=H-E_{m semi}) is bridgeless.

For a pole, (mathcal R(H)) denotes the ordered six-semiedge signatures of
actual six-matching incidence certificates, modulo one global (S_6) relabeling
of the six matchings.  For two poles, we check all (6!) permutations of the
boundary positions.  Thus a positive minimum intersection is exactly a
positive answer to the overlap condition for that pair; no parity or
relation-only surrogate is used.

## Why the class is exactly six theta cores

After deleting the six semiedges, each of the six terminal vertices has
proper degree two and the remaining two vertices have proper degree three.
Hence (F) has nine proper edges and degree sequence (2^6,3^2).  Suppressing
the six degree-two vertices gives a connected cubic multigraph on two
degree-three vertices (u,v).  The only alternatives are three (u!-!v)
edges or one loop at each of (u,v) together with one (u!-!v) edge.  In the
second alternative the unique (u!-!v) edge is a bridge of (F), so it is
excluded.  Therefore (F) is a theta graph with three internally disjoint
(u!-!v) paths.  Simplicity permits at most one path of length one.  Since
the three lengths sum to nine, the six and only six unordered possibilities
are

\[
(1,2,6),(1,3,5),(1,4,4),(2,2,5),(2,3,4),(3,3,3).
\]

## Exact incidence enumeration

The script [`probe_n8_theta_overlap.py`](./probe_n8_theta_overlap.py) uses the
exact cubic gate at each internal vertex: every edge receives one of the 15
two-element subsets of ([6]), and the three incident labels must be a
disjoint partition of ([6]).  The first semiedge is fixed to ({1,2}),
which is an exact color-gauge reduction.  The displayed raw count is therefore
the number of assignments in that gauge; the relation is canonicalized under
the remaining color permutations.

The six poles have the following exact counts:

\[
\begin{array}{c|rrrrrr}
\theta(a,b,c)&(1,2,6)&(1,3,5)&(1,4,4)&(2,2,5)&(2,3,4)&(3,3,3)\\
\hline
\text{gauge-fixed assignments}&3354&11238&5838&9528&6900&9672\\
|\mathcal R/S_6|&92&117&147&119&143&135
\end{array}
\]

For every unordered pair (including a pole paired with itself), all 720
boundary-position permutations were tested.  The minimum intersection sizes
are:

\[
\begin{array}{c|rrrrrr}
 &126&135&144&225&234&333\\
\hline
126&6&6&7&6&8&8\\
135&&10&7&6&8&13\\
144&&&12&13&13&11\\
225&&&&7&11&16\\
234&&&&&7&19\\
333&&&&&&25
\end{array}
\]

Every entry is strictly positive.  The script ends with
`N8_THETA_OVERLAP_BOUNDARY_VERIFIED`.

## What this does and does not decide

This closes the six-cut overlap interface for the explicitly quantified
(n=8), simple, distinct-terminal, proper-edge-bridgeless class.  It does not
give a theorem for larger six-poles, does not imply that a general
cyclically-6-connected graph has a BF cover, and does not produce a real
disjoint pair.  In particular, it cannot close the cyclically-6 branch of the
Berge--Fulkerson conjecture.  The next unresolved interface remains common
actual six-matching incidence for larger pole shores; extending the order
without a new decision target is not justified by this finite result.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-cyclic6/probe_n8_theta_overlap.py
```
