#!/usr/bin/env python3
"""Targeted multiset-type audit on explicitly named six-poles.

This extends the small manual family only far enough to test the possible
shortcut ``every bridgeless actual relation contains one common boundary
multiset type``.  It keeps actual V-gate incidence, requires a connected
proper core with no proper bridge and a cycle, and reports no graph census.
"""

from __future__ import annotations

from itertools import combinations, permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("named_multiset_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)

PAIRS = ENGINE.PAIRS
PAIR_INDEX = ENGINE.PAIR_INDEX
COLORS = tuple(range(6))
COLOR_PERMS = tuple(permutations(COLORS))
PAIR_TRANSFORMS = tuple(
    tuple(PAIR_INDEX[tuple(sorted((perm[a], perm[b])))] for a, b in PAIRS)
    for perm in COLOR_PERMS
)


def type_code(signature):
    counts = [0] * len(PAIRS)
    for code in signature:
        counts[code] += 1
    images = []
    for transform in PAIR_TRANSFORMS:
        image = [0] * len(PAIRS)
        for code, count in enumerate(counts):
            image[transform[code]] += count
        images.append(tuple(image))
    return min(images)


def decode_type(code):
    return tuple((PAIRS[index], count) for index, count in enumerate(code) if count)


def connected(n, edges, removed=None):
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index == removed:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def cycle_core(n, edges):
    return connected(n, edges) and len(edges) >= n


def bridgeless(n, edges):
    return connected(n, edges) and all(connected(n, edges, i) for i in range(len(edges)))


def pole_from_edges(n, edges):
    degree = [0] * n
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    semis = tuple(v for v, d in enumerate(degree) for _ in range(3 - d))
    assert len(semis) == 6 and all(d <= 3 for d in degree)
    return tuple(sorted(tuple(sorted(edge)) for edge in edges)), semis


def candidates():
    # Explicitly named proper cores used by previous O6 probes.  All have
    # exactly six deficits; only connected cyclic bridge-free cores survive.
    raw = {
        "C6": (6, [(i, (i + 1) % 6) for i in range(6)]),
        "C4-path2": (6, [(0, 1), (1, 2), (2, 3), (3, 0), (0, 4), (1, 5)]),
        "K33-remove-2star": (6, [(0, 4), (0, 5), (1, 3), (1, 5), (2, 3), (2, 5)]),
        "K33-remove-perfect": (6, [(0, 4), (0, 5), (1, 3), (1, 5), (2, 3), (2, 4)]),
        "K33-star-connected2": (6, [(0, 4), (0, 3), (1, 4), (1, 5), (2, 3), (2, 5)]),
        "K33-star-connected-path": (8, [(0, 3), (0, 6), (6, 7), (7, 4), (1, 4),
                                          (1, 5), (2, 3), (2, 5), (0, 5)]),
        "theta-126": (8, None),
        "theta-135": (8, None),
        "theta-144": (8, None),
        "theta-225": (8, None),
        "theta-234": (8, None),
        "theta-333": (8, None),
    }
    for name in tuple(raw):
        if name.startswith("theta-"):
            lengths = tuple(int(x) for x in name.split("-")[1])
            edges = []
            next_vertex = 2
            for length in lengths:
                previous = 0
                for _ in range(1, length):
                    vertex = next_vertex
                    next_vertex += 1
                    edges.append((previous, vertex))
                    previous = vertex
                edges.append((previous, 1))
            assert next_vertex == 8
            raw[name] = (8, edges)
    for name, (n, edges) in raw.items():
        proper, semis = pole_from_edges(n, edges)
        if not cycle_core(n, proper) or not bridgeless(n, proper):
            continue
        yield name, proper, semis


def main():
    rows = []
    type_sets = {}
    for name, proper, semis in candidates():
        relation, raw = ENGINE.exact_relation(proper, semis)
        types = frozenset(type_code(sig) for sig in relation)
        type_sets[name] = types
        rows.append({"name": name, "raw": raw, "relation_orbits": len(relation),
                     "multiset_types": len(types), "distinct_ports": len(set(semis)) == 6,
                     "semiedges": semis})
    common = set.intersection(*(set(values) for values in type_sets.values()))
    disjoint = []
    names = tuple(type_sets)
    for i, left in enumerate(names):
        for right in names[i + 1:]:
            if not (type_sets[left] & type_sets[right]):
                disjoint.append((left, right))
    print({"rows": rows, "common_type_count": len(common),
           "common_type_representatives": [decode_type(code) for code in sorted(common)],
           "pairwise_disjoint_type_pairs": disjoint})
    if disjoint:
        print("ACTUAL_NAMED_MULTISET_DISJOINTNESS_FOUND")
    else:
        print("NO_DISJOINT_NAMED_MULTISET_TYPES")


if __name__ == "__main__":
    main()
