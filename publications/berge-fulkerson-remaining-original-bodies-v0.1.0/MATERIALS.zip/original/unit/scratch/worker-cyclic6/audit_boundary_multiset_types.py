#!/usr/bin/env python3
"""Inspect actual six-pole boundary *multiset* types.

Port reorderings are allowed in the O6 gluing interface.  Therefore two
signatures can be made equal after a port permutation whenever their
unordered six-edge multisets agree (up to a global S6 colour relabelling).
This script computes those multisets from the actual V-gate incidence
relations of a short, explicitly named family: theta six-poles and the
Heawood C6 shore.  It does not search graphs or replace incidence by a
parity surrogate.

The result is only a diagnostic: a universal multiset type would give a
sharp sufficient condition for O6 in this family; disjoint type sets would
give an actual relation-level route to a countermodel.
"""

from __future__ import annotations

from itertools import permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("boundary_multiset_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)

COLORS = tuple(range(6))
PAIRS = ENGINE.PAIRS
PAIR_INDEX = ENGINE.PAIR_INDEX
COLOR_PERMS = tuple(permutations(COLORS))
PAIR_TRANSFORMS = tuple(
    tuple(PAIR_INDEX[tuple(sorted((perm[a], perm[b])))] for a, b in PAIRS)
    for perm in COLOR_PERMS
)


def multiset_type(signature: tuple[int, ...]) -> tuple[int, ...]:
    """Canonical unordered six-edge multiset under global S6."""
    counts = [0] * len(PAIRS)
    for code in signature:
        counts[code] += 1
    candidates = []
    for transform in PAIR_TRANSFORMS:
        transformed = [0] * len(PAIRS)
        for code, count in enumerate(counts):
            transformed[transform[code]] += count
        candidates.append(tuple(transformed))
    return min(candidates)


def theta(lengths: tuple[int, int, int]):
    proper = []
    boundary = []
    next_vertex = 2
    for length in lengths:
        previous = 0
        for _ in range(1, length):
            vertex = next_vertex
            next_vertex += 1
            proper.append((previous, vertex))
            boundary.append(vertex)
            previous = vertex
        proper.append((previous, 1))
    assert next_vertex == 8 and len(boundary) == 6
    return tuple(proper), tuple(boundary)


def main():
    named = {
        f"theta{lengths}": theta(lengths)
        for lengths in ((1, 1, 7), (1, 2, 6), (1, 3, 5), (1, 4, 4),
                        (2, 2, 5), (2, 3, 4), (3, 3, 3))
    }
    # A six-cycle pole is the 6-cycle with one semiedge at every vertex.
    named["C6"] = (tuple((i, (i + 1) % 6) for i in range(6)), tuple(range(6)))
    # The two theta poles used in the previous cap probe are included as
    # independently ordered variants, not as new graph search candidates.
    named["theta(2,2,5)"] = theta((2, 2, 5))
    named["theta(3,3,3)"] = theta((3, 3, 3))

    type_sets = {}
    rows = []
    for name, (proper, boundary) in named.items():
        relation, raw = ENGINE.exact_relation(proper, boundary)
        types = frozenset(multiset_type(signature) for signature in relation)
        type_sets[name] = types
        rows.append({"name": name, "raw": raw, "signatures": len(relation),
                     "multiset_types": len(types)})

    common = set.intersection(*(set(types) for types in type_sets.values()))
    pairwise_disjoint = []
    names = tuple(type_sets)
    for i, left in enumerate(names):
        for right in names[i + 1:]:
            overlap = type_sets[left] & type_sets[right]
            if not overlap:
                pairwise_disjoint.append((left, right))

    print({"pole_rows": rows,
           "all_family_common_multiset_types": len(common),
           "pairwise_disjoint_type_pairs": pairwise_disjoint,
           "family": names})
    if pairwise_disjoint:
        print("ACTUAL_MULTISET_TYPE_DISJOINTNESS_FOUND")
    else:
        print("NO_DISJOINT_MULTISET_TYPES_IN_TARGETED_FAMILY")


if __name__ == "__main__":
    main()
