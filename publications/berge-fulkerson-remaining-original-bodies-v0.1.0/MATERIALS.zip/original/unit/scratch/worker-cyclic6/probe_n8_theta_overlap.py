"""Finite n=8 real-six-pole overlap boundary.

For a simple connected six-pole with six distinct semiedge vertices and no
proper-edge bridge, order eight forces a theta core.  This script enumerates
the actual six-matching incidence relation of every possible theta length
triple and checks all 6! boundary-position permutations for every unordered
pair (including a pole paired with itself).

The relation engine is the exact cubic (V)-gate search in
``search_small_real_sixpole_disjoint.py``; no parity or relation-only model
is used here.
"""

from __future__ import annotations

import sys
from importlib.util import module_from_spec, spec_from_file_location
from itertools import permutations
from pathlib import Path


HERE = Path(__file__).resolve().parent
ENGINE = HERE / "search_small_real_sixpole_disjoint.py"
spec = spec_from_file_location("sixpole_engine_n8", ENGINE)
assert spec is not None and spec.loader is not None
engine = module_from_spec(spec)
# dataclass in the engine expects its module to be registered during import.
sys.modules[spec.name] = engine
spec.loader.exec_module(engine)


POSITION_PERMS = tuple(permutations(range(6)))


def theta(lengths: tuple[int, int, int]):
    """Return the proper edges and six terminal vertices of a theta core."""
    edges: list[tuple[int, int]] = []
    boundary: list[int] = []
    next_vertex = 2
    for length in lengths:
        previous = 0
        for _ in range(1, length):
            vertex = next_vertex
            next_vertex += 1
            edges.append((previous, vertex))
            boundary.append(vertex)
            previous = vertex
        edges.append((previous, 1))
    assert next_vertex == 8
    assert len(edges) == 9 and len(boundary) == 6
    return edges, boundary


def minimum_intersection(left, right) -> int:
    """Minimize exact canonical-relation intersection over port reorderings."""
    best = 10**9
    for positions in POSITION_PERMS:
        reordered = {
            engine.canonical(tuple(signature[i] for i in positions))
            for signature in right
        }
        best = min(best, len(left & reordered))
    return best


def main() -> None:
    # Simple theta triples with positive lengths summing to 9.  A direct
    # u-v path may occur at most once, hence no (1,1,7) or (1,1,...) case.
    triples = (
        (1, 2, 6),
        (1, 3, 5),
        (1, 4, 4),
        (2, 2, 5),
        (2, 3, 4),
        (3, 3, 3),
    )
    relations = {}
    for lengths in triples:
        proper, boundary = theta(lengths)
        relation, raw = engine.exact_relation(proper, boundary)
        relations[lengths] = relation
        print(
            f"RELATION lengths={lengths} n=8 proper=9 raw={raw} "
            f"orbits={len(relation)}"
        )

    results = {}
    for i, left_name in enumerate(triples):
        for right_name in triples[i:]:
            value = minimum_intersection(
                relations[left_name], relations[right_name]
            )
            results[(left_name, right_name)] = value
            print(f"PAIR left={left_name} right={right_name} min={value}")
            assert value > 0

    expected = (
        6, 6, 7, 6, 8, 8,
        10, 7, 6, 8, 13, 12, 13, 13, 11,
        7, 11, 16, 7, 19, 25,
    )
    assert tuple(results.values()) == expected
    print("N8_THETA_OVERLAP_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
