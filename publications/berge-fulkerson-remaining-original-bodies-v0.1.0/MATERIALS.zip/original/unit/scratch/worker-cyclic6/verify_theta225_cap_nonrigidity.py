"""Verify one real six-pole cap-boundary non-rigidity example.

This is a single explicit theta six-pole, not a census.  The proper core has
three internally disjoint paths of lengths (2, 2, 5) between vertices 0 and
1.  The six internal degree-two vertices carry the ordered semiedges.  We
enumerate the actual six-matching incidence certificates (the cubic V-gate),
quotient only by a global permutation of the six matching labels, and check:

* every one of the 15 pairings of boundary ports has a cap-fixed certificate;
* the proper core and every capped closure are bridgeless;
* no single boundary signature is constant (so all-cap minimality does not
  imply a pairing-independent cap signature).

The computation uses only actual edge-pair assignments, not a load/parity
surrogate and not a graph census.
"""

from __future__ import annotations

from itertools import combinations, permutations


PAIRS = tuple(combinations(range(6), 2))
PAIR_INDEX = {pair: i for i, pair in enumerate(PAIRS)}
COLOR_PERMS = tuple(permutations(range(6)))
PAIR_TRANSFORMS = tuple(
    tuple(PAIR_INDEX[tuple(sorted((perm[a], perm[b])))] for a, b in PAIRS)
    for perm in COLOR_PERMS
)


def theta225() -> tuple[int, tuple[tuple[int, int], ...], tuple[int, ...]]:
    """Return the n=8 theta(2,2,5) proper core and semiedge vertices."""
    edges: list[tuple[int, int]] = []
    boundary: list[int] = []
    next_vertex = 2
    for length in (2, 2, 5):
        previous = 0
        for _ in range(1, length):
            vertex = next_vertex
            next_vertex += 1
            edges.append((previous, vertex))
            boundary.append(vertex)
            previous = vertex
        edges.append((previous, 1))
    assert next_vertex == 8
    assert len(edges) == 9 and len(boundary) == 6
    return next_vertex, tuple(edges), tuple(boundary)


def canonical(signature: tuple[int, ...]) -> tuple[int, ...]:
    """Quotient a boundary signature by one global S_6 colour relabelling."""
    return min(
        tuple(transform[pair_code] for pair_code in signature)
        for transform in PAIR_TRANSFORMS
    )


def relation(
    n: int,
    proper_edges: tuple[tuple[int, int], ...],
    boundary: tuple[int, ...],
) -> tuple[frozenset[tuple[int, ...]], int]:
    """Enumerate actual six-matching certificates and canonical signatures."""
    edges = list(proper_edges) + [(vertex, None) for vertex in boundary]
    incidence: list[list[int]] = [[] for _ in range(n)]
    for edge_index, (u, v) in enumerate(edges):
        incidence[u].append(edge_index)
        if v is not None:
            incidence[v].append(edge_index)
    assert all(len(incident) == 3 for incident in incidence)

    values: list[int | None] = [None] * len(edges)
    first_semiedge = len(proper_edges)
    values[first_semiedge] = PAIR_INDEX[(0, 1)]
    signatures: set[tuple[int, ...]] = set()
    raw_count = 0

    def vertex_ok(vertex: int) -> bool:
        assigned = [values[e] for e in incidence[vertex] if values[e] is not None]
        if len(assigned) != len(set(assigned)):
            return False
        return all(
            set(PAIRS[assigned[i]]).isdisjoint(PAIRS[assigned[j]])
            for i in range(len(assigned))
            for j in range(i)
        )

    def search(remaining: int) -> None:
        nonlocal raw_count
        if remaining == 0:
            raw_count += 1
            signature = tuple(values[first_semiedge + i] for i in range(6))
            assert all(value is not None for value in signature)
            signatures.add(canonical(signature))  # type: ignore[arg-type]
            return
        candidates = [e for e, value in enumerate(values) if value is None]
        edge_index = min(candidates)
        u, v = edges[edge_index]
        for pair_code in range(len(PAIRS)):
            values[edge_index] = pair_code
            if vertex_ok(u) and (v is None or vertex_ok(v)):
                search(remaining - 1)
        values[edge_index] = None

    search(len(edges) - 1)
    return frozenset(signatures), raw_count


def pairings() -> tuple[tuple[tuple[int, int], ...], ...]:
    result: list[tuple[tuple[int, int], ...]] = []

    def rec(remaining: set[int], current: list[tuple[int, int]]) -> None:
        if not remaining:
            result.append(tuple(current))
            return
        first = min(remaining)
        for second in sorted(remaining - {first}):
            rec(remaining - {first, second}, current + [(first, second)])

    rec(set(range(6)), [])
    return tuple(result)


def connected(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    adjacency = [[] for _ in range(n)]
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    if not connected(n, edges):
        return False
    for removed in range(len(edges)):
        remaining = edges[:removed] + edges[removed + 1 :]
        if not connected(n, remaining):
            return False
    return True


def main() -> None:
    n, proper, boundary = theta225()
    signatures, raw_count = relation(n, proper, boundary)
    assert raw_count == 9528
    assert len(signatures) == 119

    core = tuple(sorted(tuple(sorted(edge)) for edge in proper))
    assert bridgeless(n, core)

    fixed_counts: list[int] = []
    for pairing in pairings():
        fixed = [
            signature
            for signature in signatures
            if all(signature[a] == signature[b] for a, b in pairing)
        ]
        fixed_counts.append(len(fixed))

        # A cap can coincide with an existing proper edge, producing a
        # parallel pair.  This is still a bridgeless cubic multigraph and is
        # valid for the minimality implication used here; we therefore keep
        # edge multiplicities instead of silently discarding such pairings.
        capped = tuple(
            list(core) + [tuple(sorted((boundary[a], boundary[b]))) for a, b in pairing]
        )
        assert bridgeless(n, capped)

    # Equality pattern is invariant under S_6, so this tests for a genuine
    # pairing-independent constant cap signature, not a gauge artefact.
    constant = [signature for signature in signatures if len(set(signature)) == 1]
    assert min(fixed_counts) == 1
    assert max(fixed_counts) == 3
    assert len(constant) == 0

    print(
        {
            "pole": "theta(2,2,5)",
            "vertices": n,
            "proper_edges": len(proper),
            "raw_certificates_in_(0,1)_gauge": raw_count,
            "signature_orbits": len(signatures),
            "cap_pairings": len(fixed_counts),
            "fixed_signature_orbits_per_pairing": tuple(fixed_counts),
            "proper_core_bridgeless": True,
            "all_capped_closures_bridgeless": True,
            "constant_boundary_signature_orbits": len(constant),
        }
    )
    print("THETA225_ALL_CAPS_NONRIGID_VERIFIED")


if __name__ == "__main__":
    main()
