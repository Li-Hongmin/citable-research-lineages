# Omen bounded 5-regular class-2 probe (2026-09-02)

## Decision target

Test the cheapest finite discriminator for the high-connectivity gate: a
simple 5-regular graph with edge-connectivity at least 5, no nontrivial
5-edge-cut, and no decomposition into five edge-disjoint perfect matchings.
A hit would be a strict counterexample to the broad (m(5)=5) statement;
absence of a hit would not prove anything in general.

## Omen run

The script `omen_5regular_class2_probe.py` was copied to Omen and run as:

```text
python3 -u omen_5regular_class2_probe.py --orders 6 8 10 12 --samples 200
```

For each order and seed it generated a simple random 5-regular graph,
filtered connected graphs with explicit edge-connectivity at least 5 and
checked all subsets for nontrivial 5-cuts.  Perfect matchings were enumerated
recursively and an exact backtracking search tested five edge-disjoint
perfect matchings.

The run tested 799 graphs (200 each at orders 6, 8, 10; 199 at order 12).
All tested graphs were class 1; no graph was both class 2 and free of a
nontrivial 5-cut.

Terminal output:

```text
NO_CLASS2_5REGULAR_HIT_IN_BOUNDED_SAMPLE
OMEN_5REGULAR_CLASS2_PROBE_OK
```

The result is a bounded no-hit only.  It does not address the special
subclass (H_F=G+E(F)) or the open (m(5)=5) problem, and no order increase
is justified.  Source and Omen log hashes are recorded by the local files:

```text
omen_5regular_class2_probe.py
omen_5regular_class2_probe-20260902.log
```
