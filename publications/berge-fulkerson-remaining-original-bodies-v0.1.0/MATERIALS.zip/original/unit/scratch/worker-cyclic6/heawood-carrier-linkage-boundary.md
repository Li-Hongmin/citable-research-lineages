# Heawood carrier linkage: the local topological route is closed

**Scope.**  This is a fixed-instance boundary for the O6 carrier route.  It
does not claim a Berge--Fulkerson counterexample and does not use a graph
census.

## Fixed cap and exact minimum

Let $K$ be the Heawood graph on vertices $0,\ldots,13$, with edge set
hard-coded in `probe_heawood_carrier.py`, and let

\[
 F=\{01,23,49\}.
\]

The three edges of $F$ are independent.  Put $H=K-F$, regarding the six
resulting degree-two incidences at $0,1,2,3,4,9$ as ordered ports, and cap
them by

\[
 p=01\mid23\mid49.
\]

Thus $H/p=K$.  The proper core $H$ is connected and bridgeless, and $K$
has cyclic edge-connectivity six.

The fixed graph $K$ has 24 perfect matchings and 148 six-matching
Berge--Fulkerson cover multisets, allowing repetitions.  Exhausting this
finite family gives

\[
 \min_{\mathcal M}\Phi(\mathcal M)=1,
 \qquad
 (d_i)^{\downarrow}=(2,1,1,1,1,0)
\]

for all 12 minimizers.  Hence no rainbow cap cover exists.  For every
minimizer, if $i$ is the unique repeated cap colour and $j$ the unique
missing colour, the two $i$-coloured cap edges lie on one component of
$M_i\triangle M_j$.  The carrier component has length six in eight
minimizers and length ten in four.

One literal minimizer is the six perfect matchings

\[
\begin{aligned}
M_0={}&\{01,23,45,67,89,10\,11,12\,13\},\\
M_1={}&\{01,27,34,56,8\,13,9\,10,11\,12\},\\
M_2={}&\{05,12,34,6\,11,78,9\,10,12\,13\},\\
M_3={}&\{05,1\,10,27,3\,12,49,6\,11,8\,13\},\\
M_4={}&\{0\,13,12,3\,12,49,56,78,10\,11\},\\
M_5={}&\{0\,13,1\,10,23,45,67,89,11\,12\}.
\end{aligned}
\]

Here the cap degrees are $(2,1,0,1,1,1)$, and the carrier of colours
$0,2$ is the alternating cycle

\[
 0-1-2-3-4-5-0.
\]

Uncapping deletes $01$ and $23$ from this cycle and leaves the two
vertex-disjoint carrier paths $1-2$ and $0-5-4-3$ inside $H$.

## A cyclically-six two-shore embedding

Take two copies of $H$.  Order both port sets as
$(0,1,2,3,4,9)$, and glue left port $r$ to right port $q(r)$, where

\[
 q=(0,1,3,2,4,5).
\]

The six inter-shore edges are

\[
 0\,14, 1\,15, 2\,17, 3\,16, 4\,18, 9\,23.
\]

The permutation $q$ preserves the three pairs of $p$, so the same cap is
admissible on both shores and caps either shore back to a Heawood graph.  The
resulting 28-vertex graph is simple, cubic and bridgeless.  Its displayed
six-edge shore cut is cycle-separating.  Exhausting every deletion set of at
most five edges finds no two components that both contain cycles; hence its
cyclic edge connectivity is exactly six.

The identity port gluing is not this construction.  It has the cyclic
4-cut isolating the 4-cycle on vertices $\{1,2,15,16\}$.  The verifier checks
both statements explicitly, preventing the two gluings from being conflated.

## Strict boundary

The example proves that the following local implication is false:

\[
\begin{gathered}
\text{bridgeless cyclically-six cap closure}
+\text{ bridgeless real shore}
+\Phi\text{-minimal inseparable carrier}\\
\Longrightarrow
\text{bridge or cycle-separating cut of size }<6.
\end{gathered}
\]

It remains false even when two copies of the shore occur across a genuine
cycle-separating 6-cut of a simple bridgeless graph, with the same cap pairing
admissible on both sides.

This does **not** embed the carrier in a minimum BF counterexample.  The fixed
28-vertex graph is 3-edge-colourable, hence has a BF cover.  Therefore the
global minimum-counterexample condition could still rule out the carrier, but
only through information coupling the two shores.  The exact remaining input
is the cross-shore actual-incidence obstruction

\[
 \mathcal R(H_X)\cap \pi\mathcal R(H_Y)=\varnothing
 \quad\text{for every }\pi\in S_6,
\]

which holds in a BF counterexample by the O6 gluing equivalence.  No
shore-local carrier, bridge, or cyclic-connectivity argument can supply the
needed contradiction.  A positive continuation would have to prove that the
two carrier-linkage systems force an orbit intersection; the present carrier
descent by itself has reached its sharp stopping boundary.

## Reproduction

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-cyclic6/probe_heawood_carrier.py
```

Terminal marker:

```text
HEAWOOD_CARRIER_LINKAGE_LOCAL_COUNTEREXAMPLE_VERIFIED
```
