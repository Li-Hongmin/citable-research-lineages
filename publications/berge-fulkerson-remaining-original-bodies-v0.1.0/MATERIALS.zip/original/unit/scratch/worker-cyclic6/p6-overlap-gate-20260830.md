# BF cyclically-6 overlap gate: strict undecided boundary

**Scope.** This is one finite gate only.  The input is a pair of real,
connected, bridgeless cubic six-poles obtained by cutting a
cycle-separating six-cut.  No graph-order census, asymptotic scan, parity-only
argument, or broad literature search is used.

## Exact proposition and gluing interface

Let (H) have ordered semiedges (s_1,ldots,s_6).  A six-matching
certificate is a tuple (M_1,ldots,M_6) of matching edge sets such that

* every internal vertex is covered once by each (M_i);
* every proper edge is in exactly two of the (M_i);
* the boundary signature is
  (ho_j={i:s_jin M_i}in { [6]choose2}).

Write (mathcal R(H)) for the set of ordered signatures realized by such
certificates.  For two sides (H_X,H_Y) of a six-cut, the exact common-
incidence condition is

\[
\exists \rho_X\in\mathcal R(H_X),\ \rho_Y\in\mathcal R(H_Y),\
\exists\pi\in S_6:\quad
\rho_X(j)=\pi(\rho_Y(j))\quad(j=1,\ldots,6). \tag{O6}
\]

If (O6) holds, relabel the second six certificates by (pi) and glue the
matching edges across the six cut edges.  Each cut edge is then in exactly two
global matchings, so the glued graph has a Berge--Fulkerson cover.  Conversely,
restricting any global six-matching cover gives the two side certificates and
the same boundary equality.  Thus (O6) is an iff, not merely a sufficient
gluing test.

## Matching-gate formulation

Put (P={ [6]\choose2}).  Assign one variable (a_e\in P) to every proper
edge and semiedge.  At every internal cubic vertex the three incident values
must form a disjoint partition of ([6]):

\[
V=\{(a,b,c)\in P^3:a\dot\cup b\dot\cup c=[6]\}.
\]

The boundary relation (mathcal R(H)) is exactly the projection of the
solutions of this finite (V)-gate network onto the six semiedge variables.
Gluing is equality of the six boundary variables after one diagonal (S_6)
action.  This is the strongest direct perfect-matching/incidence encoding;
it does not introduce an abstract load model.

The same object can be written as a tensor network with one copy of the
three-ary gate (V) at each cubic vertex and one (P)-index contraction on
each proper edge.  The gate is a sum of ordered 1-factor assignments of
(K_6), not a single decomposable exterior/Plücker tensor.  Consequently a
Grassmann--Plücker reformulation supplies no automatic common-support theorem:
the missing statement is precisely that two projected (V)-networks have a
common monomial after a diagonal color permutation.  No such identity was
derived here.

## What actual incidence forces, and where it stops

For any realized (ho), each color (i) occurs an even number of times
among the six boundary pairs.  This follows by counting (M_i) on one shore
of the six-cut.  Equivalently, the six boundary pairs form a loopless
Eulerian multigraph on the six matching labels.  This is a necessary condition
inside the (V)-network, but it does not select a unique (S_6)-orbit and
does not compare the two independent projected networks.

Minimality gives one sharper, genuine matching statement.  Let (p) be a
pairing of the six boundary positions and let

\[
\operatorname{Fix}(p)=\{\rho:\rho_{a_r}=\rho_{b_r}\ (r=1,2,3)\}.
\]

If joining each paired boundary pair by three cap edges yields a bridgeless
smaller cubic graph, then minimality of a BF counterexample gives

\[
\forall p\quad\exists\rho_p\in\mathcal R(H)\cap
\operatorname{Fix}(p). \tag{Cap}
\]

The quantifier gap is exact:

\[
\text{(Cap)}\;=\;\forall p\,\exists\rho_p,
\qquad
\text{(O6)}\;=\;\exists\rho_X,\rho_Y,\pi.
\]

Neither the gate constraints nor minimality identifies the witnesses for
different pairings or forces witnesses on the two sides to lie in one common
(S_6)-orbit.

A precise sufficient strengthening is **common-cap rigidity**: for one
admissible pairing (p), both sides must realize a signature in the same
(S_6)-orbit inside (operatorname{Fix}(p)).  A useful structural version is
that all realizable (p)-fixed signatures of each side lie in one common orbit;
then (Cap) closes (O6).  No theorem establishing this rigidity for arbitrary
real six-poles is available in the current material.

## Direct finite real-pole probe

The standard-library edge-pair CSP probe
`check_small_sixpole_boundary_overlap.py` computes actual (V)-network
solutions, not parity surrogates.  For the explicit (C_6) six-pole and the
connected triangle-with-three-leaves six-pole it finds

\[
\begin{array}{c|cc}
H&\text{raw assignments}&|\mathcal R(H)/S_6|\\ \hline
C_6&3354&92\\
\text{triangle+three leaves}&1296&40
\end{array}
\]

The direct ordered-boundary intersection has size (1), and the minimum over
all (6!) boundary-position reorderings is still (1).  This is a real
matching-incidence negative search: it finds no disjoint pair in this probe.
The examples are small and are not a census of the cycle-separating
six-cut class.

As a stricter single-pair check, `probe_bridgeless_sixpole_pair.py` compares
the (C_6) pole with a simple bridgeless theta pole whose three core paths
have lengths (1,2,6).  Both have six distinct boundary vertices.  Each
relation has 3354 raw assignments and 92 color-orbits; their direct overlap
is 92 and the minimum over all boundary reorderings is 6.  Gluing the ordered
ports gives an explicitly checked simple, connected, cubic, bridgeless
14-vertex graph with a cycle-separating 6-cut.  This is still one probe, not a
general overlap theorem or a disjoint-pair search over the six-pole class.

## Stopping decision

No general overlap proof and no real pair of nonempty disjoint boundary
relations was obtained.  The exact result of this gate is therefore

\[
\boxed{\text{strictly undecided: (O6) is the remaining common-incidence
interface.}}
\]

This does not prove or refute the Berge--Fulkerson conjecture.  A worthwhile
next step would have to prove common-cap rigidity (or another cross-pole
incidence theorem), or exhibit a real pair with
\(
\mathcal R(H_X),\mathcal R(H_Y)\ne\varnothing
\)
but no overlap under any (S_6) relabeling.  Further parity/load identities
or unrelated order scans would not change this decision.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-cyclic6/check_small_sixpole_boundary_overlap.py
python3 units/berge-fulkerson/scratch/worker-cyclic6/probe_bridgeless_sixpole_pair.py
```

Terminal marker:

```text
SMALL_SIXPOLE_BOUNDARY_OVERLAP_PROBE_OK
BRIDGELESS_SIXPOLE_OVERLAP_PROBE_OK
```
