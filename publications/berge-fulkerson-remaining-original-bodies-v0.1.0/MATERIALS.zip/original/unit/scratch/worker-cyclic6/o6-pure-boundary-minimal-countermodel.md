# Minimal pure-boundary countermodel for O6

## Statement tested

Let the six port positions be 0,...,5, and let each boundary entry be a
two-subset of the six matching labels. For a relation set R write

    Cap(R): R intersects Fix(p) for every one of the 15 perfect pairings p.

The O6 pure-boundary question asks whether two relation sets satisfying Cap
must meet after a global S6 relabelling.

## Explicit countermodel

Use the disjoint labels

    a = {0,1},   b = {2,3}.

The left relation has the constant signature

    R6 = {(a,a,a,a,a,a)}.

The right relation has five signatures. For i=1,...,5, define rho(i) by

    rho(i)[0] = rho(i)[i] = b,
    rho(i)[j] = a for j not in {0,i},

and set R42 = {rho(1),...,rho(5)}.

For the colour-quotient convention, replace each relation by its global S6
orbit closure. The closures have 15 and 5*90=450 raw signatures,
respectively.

The constant signature is fixed by every pairing. Every pairing contains a
unique pair {0,i}, so rho(i) is fixed by that pairing. Thus both relations
satisfy Cap. Equality partition of port positions is invariant under global
colour relabelling: R6 has pattern 6, while R42 has pattern 4+2. Hence no
global S6 relabelling makes them intersect.

Every displayed signature also satisfies the necessary BF boundary parity:
each matching label occurs an even number of times (six for R6, and four or
two for R42).

## Minimality

A nonconstant signature fixed by a pairing must have all equality classes even.
The largest possible number of pairings fixed by such a signature is three,
attained by a 4+2 pattern. Therefore any relation avoiding the constant orbit
needs at least ceil(15/3)=5 signatures. A five-edge star at port 0 hits all
15 pairings and realizes this bound. Consequently the model is minimal at the
orbit-representative level: one constant orbit versus five 4+2 positional
orbits. If relations are not required to be S6-closed, this is six signatures
total.

## Incidence status

This minimal model is **not** the exact boundary relation of one common cubic
three-valent incidence network. If a genuine six-pole certificate has the
constant boundary (a,a,a,a,a,a), inspect a two-colour subgraph using one
colour in a and one outside a. Its six semiedge dummies are degree-one
endpoints, so a path component joins two of them. Swapping the two colours on
that path produces a genuine 4+2 boundary signature. Thus a pole relation
containing the constant orbit cannot consist only of R6.

The countermodel therefore closes only the pure boundary quantifier:
per-pairing cap witnesses do not force cross-relation overlap. It is not a
real-pole counterexample to the cyclically-6 branch.

## Reproduction

    python3 units/berge-fulkerson/scratch/worker-cyclic6/o6_pure_boundary_minimal_countermodel.py

The script ends with `O6_PURE_BOUNDARY_MINIMAL_COUNTERMODEL_VERIFIED`.
