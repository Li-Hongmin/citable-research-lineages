#!/usr/bin/env python3
"""One fixed real six-pole probe for common-cap rigidity.

The pole is the Heawood graph with three independent cap edges removed.  For
each of the fifteen pairings of its six ordered ports, this script caps the
pole, checks simplicity/connectedness/bridgelessness, enumerates all perfect
matchings and six-matching BF covers, and counts the resulting ordered
boundary-signature orbits under a global S_6 relabelling.

This is deliberately one fixed instance.  It is not a census or a proof of
common-cap rigidity.
"""

from __future__ import annotations

from itertools import combinations, combinations_with_replacement, permutations


EDGES = tuple(
    sorted(
        (
            (0, 1), (0, 5), (0, 13), (1, 2), (1, 10), (2, 3), (2, 7),
            (3, 4), (3, 12), (4, 5), (4, 9), (5, 6), (6, 7), (6, 11),
            (7, 8), (8, 9), (8, 13), (9, 10), (10, 11), (11, 12),
            (12, 13),
        )
    )
)
CAP_INDICES = (0, 5, 10)
PORTS = tuple(vertex for index in CAP_INDICES for vertex in EDGES[index])
PROPER = tuple(edge for index, edge in enumerate(EDGES) if index not in CAP_INDICES)
COLORS = tuple(range(6))
COLOR_PERMS = tuple(permutations(COLORS))


def all_pairings(items: tuple[int, ...]) -> tuple[tuple[tuple[int, int], ...], ...]:
    if not items:
        return ((),)
    first = items[0]
    return tuple(
        ((first, second),) + rest
        for position, second in enumerate(items[1:])
        for rest in all_pairings(items[1:position + 1] + items[position + 2:])
    )


PAIRINGS = all_pairings(tuple(range(6)))
assert len(PAIRINGS) == 15


def components(n: int, edges: tuple[tuple[int, int], ...], deleted=frozenset()):
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index in deleted:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    unseen = set(range(n))
    result = []
    while unseen:
        start = min(unseen)
        seen = {start}
        stack = [start]
        while stack:
            for vertex in adjacency[stack.pop()]:
                if vertex not in seen:
                    seen.add(vertex)
                    stack.append(vertex)
        unseen -= seen
        result.append(frozenset(seen))
    return tuple(result)


def connected(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    return len(components(n, edges)) == 1


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    return connected(n, edges) and all(
        connected(n, tuple(edge for j, edge in enumerate(edges) if j != index))
        for index in range(len(edges))
    )


def simple_cubic(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    normalized = tuple(tuple(sorted(edge)) for edge in edges)
    return (
        len(normalized) == len(set(normalized))
        and all(u != v for u, v in normalized)
        and all(sum(vertex in edge for edge in normalized) == 3 for vertex in range(n))
    )


def cyclic_components_after_deletion(
    n: int, edges: tuple[tuple[int, int], ...], deleted: frozenset[int]
):
    parts = components(n, edges, deleted)
    answer = []
    for part in parts:
        internal_edges = sum(u in part and v in part for u, v in edges)
        answer.append((part, internal_edges >= len(part), internal_edges))
    return tuple(answer)


def first_proper_cyclic_cut_at_most_five():
    """Return a witness if H has a proper cyclic cut of size < 6."""
    for size in range(1, 6):
        for deleted in combinations(range(len(PROPER)), size):
            parts = cyclic_components_after_deletion(14, PROPER, frozenset(deleted))
            if sum(is_cyclic for _, is_cyclic, _ in parts) >= 2:
                return size, deleted, parts
    return None


def perfect_matchings(edges: tuple[tuple[int, int], ...]):
    n = 14
    incident = [[] for _ in range(n)]
    for edge_index, (u, v) in enumerate(edges):
        incident[u].append((edge_index, v))
        incident[v].append((edge_index, u))
    result = []

    def rec(unmatched: frozenset[int], chosen: tuple[int, ...]):
        if not unmatched:
            result.append(frozenset(chosen))
            return
        vertex = min(unmatched)
        for edge_index, neighbour in incident[vertex]:
            if neighbour in unmatched:
                rec(unmatched - {vertex, neighbour}, chosen + (edge_index,))

    rec(frozenset(range(n)), ())
    return tuple(result)


def bf_covers(edges, matchings):
    incidence = [
        tuple(int(edge in matching) for edge in range(len(edges)))
        for matching in matchings
    ]
    target = (2,) * len(edges)
    result = []
    for choice in combinations_with_replacement(range(len(matchings)), 6):
        loads = tuple(
            sum(incidence[index][edge] for index in choice)
            for edge in range(len(edges))
        )
        if loads == target:
            result.append(choice)
    return tuple(result)


def pair_code(mask: int) -> int:
    assert mask.bit_count() == 2
    return mask


def signature_orbit(signature: tuple[int, ...]) -> tuple[int, ...]:
    transforms = tuple(
        tuple(
            sum(1 << permutation_[color] for color in COLORS if mask & (1 << color))
            for mask in range(64)
        )
        for permutation_ in COLOR_PERMS
    )
    transformed = []
    for mapping in transforms:
        transformed.append(tuple(mapping[mask] for mask in signature))
    return min(transformed)


def cap_graph(pairing):
    cap_edges = tuple(tuple(sorted((PORTS[a], PORTS[b]))) for a, b in pairing)
    return PROPER + cap_edges, cap_edges


def cap_signatures(edges, pairing, cap_edges, matchings, covers):
    edge_indices = {edge: index for index, edge in enumerate(edges)}
    cap_indices = tuple(edge_indices[edge] for edge in cap_edges)
    signatures = set()
    for cover in covers:
        signature = [None] * 6
        for cap_index in cap_indices:
            mask = sum(1 << color for color, matching_index in enumerate(cover)
                       if cap_index in matchings[matching_index])
            assert mask.bit_count() == 2
            cap_position = cap_indices.index(cap_index)
            a, b = tuple(pairing[cap_position])
            signature[a] = pair_code(mask)
            signature[b] = pair_code(mask)
        # The cap itself enforces the Fix(pairing) equations positionwise.
        signature = tuple(signature)
        assert all(value is not None for value in signature)
        assert all(signature[a] == signature[b] for a, b in pairing)
        signatures.add(signature)
    return signatures


def main():
    assert tuple(EDGES[index] for index in CAP_INDICES) == ((0, 1), (2, 3), (4, 9))
    assert PORTS == (0, 1, 2, 3, 4, 9)
    assert len(PROPER) == 18
    proper_cut = first_proper_cyclic_cut_at_most_five()

    rows = []
    for pairing in PAIRINGS:
        edges, cap_edges = cap_graph(pairing)
        structural = {
            "simple_cubic": simple_cubic(14, edges),
            "connected": connected(14, edges),
            "bridgeless": bridgeless(14, edges),
        }
        if all(structural.values()):
            matchings = perfect_matchings(edges)
            covers = bf_covers(edges, matchings)
            signatures = cap_signatures(edges, pairing, cap_edges, matchings, covers)
            orbits = {signature_orbit(signature) for signature in signatures}
            rows.append({
                "pairing": pairing,
                **structural,
                "perfect_matchings": len(matchings),
                "bf_covers": len(covers),
                "raw_signatures": len(signatures),
                "orbit_count": len(orbits),
            })
        else:
            rows.append({"pairing": pairing, **structural})

    assert len(rows) == 15
    print({
        "ports": PORTS,
        "proper_edges": len(PROPER),
        "proper_cyclic_cut_lt6": None if proper_cut is None else {
            "size": proper_cut[0],
            "deleted_edges": tuple(PROPER[index] for index in proper_cut[1]),
            "parts": tuple((tuple(sorted(part)), is_cyclic, edge_count)
                           for part, is_cyclic, edge_count in proper_cut[2]),
        },
        "pairings": rows,
        "all_cap_closures_bridgeless": all(row["bridgeless"] for row in rows),
        "all_admissible_pairings_single_orbit": all(
            row.get("orbit_count", 0) <= 1 for row in rows if row["bridgeless"]
        ),
    })
    print("HEAWOOD_COMMON_CAP_RIGIDITY_PROBE_OK")


if __name__ == "__main__":
    main()
