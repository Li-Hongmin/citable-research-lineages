#!/usr/bin/env python3
"""Single deterministic order-16 prism six-pole O6 probe.

The proper core is the circular ladder on eight rungs after deleting the
three disjoint top-rim edges (0,1), (2,3), (4,5).  We enumerate the complete
actual six-matching boundary relation and compare the pole with itself under
all 6! boundary correspondences.  This is a bounded discriminator, not a
census or an overlap theorem.
"""

from __future__ import annotations

from itertools import permutations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("prism8_o6_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)


def main() -> None:
    # networkx.circular_ladder_graph(8), with vertices 0..7 on one rim and
    # 8..15 on the other rim.  The deleted edges are a matching.
    edges = (
        (0, 1), (0, 8), (0, 7), (1, 2), (1, 9), (2, 3), (2, 10),
        (3, 4), (3, 11), (4, 5), (4, 12), (5, 6), (5, 13), (6, 7),
        (6, 14), (7, 15), (8, 9), (8, 15), (9, 10), (10, 11),
        (11, 12), (12, 13), (13, 14), (14, 15),
    )
    deleted = {(0, 1), (2, 3), (4, 5)}
    proper = tuple(edge for edge in edges if edge not in deleted)
    boundary = (0, 1, 2, 3, 4, 5)
    relation, raw = ENGINE.exact_relation(proper, boundary)
    assert raw > 0 and relation

    # A direct graph check avoids relying on a named-graph wrapper.
    def connected(edge_list: tuple[tuple[int, int], ...]) -> bool:
        adjacency = [[] for _ in range(16)]
        for u, v in edge_list:
            adjacency[u].append(v)
            adjacency[v].append(u)
        seen = {0}
        stack = [0]
        while stack:
            for vertex in adjacency[stack.pop()]:
                if vertex not in seen:
                    seen.add(vertex)
                    stack.append(vertex)
        return len(seen) == 16

    assert connected(proper)
    assert all(connected(proper[:i] + proper[i + 1:]) for i in range(len(proper)))

    best = None
    best_positions = None
    for positions in permutations(range(6)):
        reordered = {
            ENGINE.canonical(tuple(signature[i] for i in positions))
            for signature in relation
        }
        overlap = len(relation & reordered)
        if best is None or overlap < best:
            best, best_positions = overlap, positions
    print({
        "host": "circular_ladder_8",
        "order": 16,
        "deleted": sorted(deleted),
        "proper_edges": len(proper),
        "raw_assignments": raw,
        "relation_orbits": len(relation),
        "minimum_self_overlap": best,
        "best_positions": best_positions,
    })
    if best == 0:
        print("ZERO_SELF_OVERLAP_ORDER16_PRISM")
    else:
        print("POSITIVE_SELF_OVERLAP_ORDER16_PRISM")
    print("PRISM8_ORDER16_O6_PROBE_OK")


if __name__ == "__main__":
    main()
