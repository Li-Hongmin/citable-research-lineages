"""Exact local six-pole boundary probe; standard library only.

This is deliberately a two-gadget check, not a graph census.  It enumerates
the BF edge-pair CSP on C6 and on a triangle with three pendant vertices, then
checks every permutation of the six boundary positions.
"""

from itertools import combinations, permutations


PAIRS = tuple(combinations(range(6), 2))
PAIR_INDEX = {pair: i for i, pair in enumerate(PAIRS)}
COLOR_PERMS = tuple(permutations(range(6)))
PAIR_TRANSFORMS = tuple(
    tuple(PAIR_INDEX[tuple(sorted((perm[a], perm[b])))] for a, b in PAIRS)
    for perm in COLOR_PERMS
)


def canonical(signature):
    """Canonicalize an ordered boundary signature under a global S6 relabel."""
    return min(
        tuple(transform[pair_code] for pair_code in signature)
        for transform in PAIR_TRANSFORMS
    )


def relation(n, proper_edges, semiedge_vertices):
    """Enumerate canonical ordered BF boundary signatures of a cubic k-pole."""
    edges = [tuple(edge) for edge in proper_edges]
    edges.extend((vertex, None) for vertex in semiedge_vertices)
    incidence = [[] for _ in range(n)]
    for edge_index, (u, v) in enumerate(edges):
        incidence[u].append(edge_index)
        if v is not None:
            incidence[v].append(edge_index)
    assert all(len(incident) == 3 for incident in incidence)

    values = [None] * len(edges)
    first_semiedge = len(proper_edges)
    values[first_semiedge] = PAIR_INDEX[(0, 1)]
    signatures = set()
    raw_count = 0

    def vertex_ok(vertex):
        assigned = [values[e] for e in incidence[vertex] if values[e] is not None]
        return len(assigned) == len(set(assigned)) and all(
            set(PAIRS[assigned[i]]).isdisjoint(PAIRS[assigned[j]])
            for i in range(len(assigned))
            for j in range(i)
        )

    def search(remaining):
        nonlocal raw_count
        if remaining == 0:
            raw_count += 1
            boundary = tuple(
                values[first_semiedge + i] for i in range(len(semiedge_vertices))
            )
            signatures.add(canonical(boundary))
            return

        candidates = [e for e, value in enumerate(values) if value is None]
        edge_index = max(
            candidates,
            key=lambda e: sum(
                values[vertex] is not None
                for vertex in edges[e]
                if vertex is not None
            ),
        )
        u, v = edges[edge_index]
        for pair_code in range(len(PAIRS)):
            values[edge_index] = pair_code
            if vertex_ok(u) and (v is None or vertex_ok(v)):
                search(remaining - 1)
        values[edge_index] = None

    search(len(edges) - 1)
    return signatures, raw_count


def reordered(signatures, positions):
    return {
        canonical(tuple(signature[position] for position in positions))
        for signature in signatures
    }


def main():
    c6, c6_raw = relation(
        6,
        [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0)],
        [0, 1, 2, 3, 4, 5],
    )
    triangle, triangle_raw = relation(
        6,
        [(0, 1), (1, 2), (2, 0), (0, 3), (1, 4), (2, 5)],
        [3, 3, 4, 4, 5, 5],
    )
    direct = len(c6 & triangle)
    minimum = min(
        len(c6 & reordered(triangle, positions))
        for positions in permutations(range(6))
    )
    print(f"C6_RAW={c6_raw} C6_ORBITS={len(c6)}")
    print(f"TRIANGLE_LEAVES_RAW={triangle_raw} TRIANGLE_LEAVES_ORBITS={len(triangle)}")
    print(f"DIRECT_INTERSECTION={direct} MIN_ALL_POSITION_REORDERINGS={minimum}")
    assert (c6_raw, len(c6)) == (3354, 92)
    assert (triangle_raw, len(triangle)) == (1296, 40)
    assert direct == 1
    assert minimum == 1
    print("SMALL_SIXPOLE_BOUNDARY_OVERLAP_PROBE_OK")


if __name__ == "__main__":
    main()
