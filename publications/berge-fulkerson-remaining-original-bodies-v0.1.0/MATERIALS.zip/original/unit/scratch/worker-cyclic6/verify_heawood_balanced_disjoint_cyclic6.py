#!/usr/bin/env python3
"""Verify a sharp boundary for balanced six-pole normalization.

Two copies of the Heawood shore are glued by a fixed port permutation.  The
resulting 28-vertex cubic graph has no cycle-separating cut of size at most
five, while the two shores' *balanced* boundary relations are disjoint for
that port correspondence.  Their full actual relations still intersect.

This is not a BF counterexample: the full overlap is explicitly checked.  It
shows that balanced-boundary normalization alone cannot prove the six-cut
overlap theorem, even at cyclic connectivity six.
"""

from __future__ import annotations

from itertools import combinations
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
SPEC = spec_from_file_location("heawood_balanced_engine", ENGINE_PATH)
assert SPEC is not None and SPEC.loader is not None
ENGINE = module_from_spec(SPEC)
sys.modules[SPEC.name] = ENGINE
SPEC.loader.exec_module(ENGINE)

DATA = runpy.run_path(
    str(HERE / "probe_heawood_carrier.py"), run_name="heawood_constants"
)
EDGES = tuple(DATA["EDGES"])
CAP = tuple(DATA["CAP"])
PORTS = tuple(vertex for index in CAP for vertex in EDGES[index])
PROPER = tuple(edge for index, edge in enumerate(EDGES) if index not in CAP)

# This permutation is deliberately chosen to make the two balanced relation
# sets disjoint.  It is different from the permutation used in the carrier
# example and is checked as a genuine 28-vertex host below.
PORT_PERMUTATION = (0, 3, 5, 4, 2, 1)


def balanced(signature: tuple[int, ...]) -> bool:
    return all(
        sum(color in ENGINE.PAIRS[code] for code in signature) == 2
        for color in range(6)
    )


def transformed(relation, permutation):
    return {
        ENGINE.canonical(tuple(signature[index] for index in permutation))
        for signature in relation
    }


def host_edges():
    first = list(PROPER)
    second = [(14 + u, 14 + v) for u, v in PROPER]
    cross = [
        (PORTS[index], 14 + PORTS[PORT_PERMUTATION[index]])
        for index in range(6)
    ]
    return tuple(first + second + cross)


def cyclically_six(edges) -> bool:
    """Exact bit-mask check for cycle-separating cuts of size <=5."""
    n = 28
    edges = tuple(edges)
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        bit = 1 << index
        adjacency[u].append((v, bit))
        adjacency[v].append((u, bit))

    def components(deleted: int):
        unseen = (1 << n) - 1
        result = []
        while unseen:
            first = unseen & -unseen
            start = first.bit_length() - 1
            unseen ^= first
            seen = first
            stack = [start]
            while stack:
                vertex = stack.pop()
                for neighbour, edge_bit in adjacency[vertex]:
                    if deleted & edge_bit or not (unseen >> neighbour) & 1:
                        continue
                    unseen ^= 1 << neighbour
                    seen |= 1 << neighbour
                    stack.append(neighbour)
            result.append(seen)
        return result

    def cyclic(vertices: int):
        # A connected graph is cyclic iff its induced edge count is at least
        # its vertex count.
        vertex_count = vertices.bit_count()
        internal_edges = sum(
            (vertices >> u) & 1 and (vertices >> v) & 1
            for u, v in edges
        )
        return internal_edges >= vertex_count

    for cut_size in range(1, 6):
        for deleted_indices in combinations(range(len(edges)), cut_size):
            deleted = sum(1 << index for index in deleted_indices)
            if sum(cyclic(component) for component in components(deleted)) >= 2:
                return False
    return True


def main():
    relation, raw = ENGINE.exact_relation(PROPER, PORTS)
    assert raw == 266466
    # The exact engine's canonical relation has 166 colour-orbits.
    assert len(relation) == 166
    balanced_relation = frozenset(
        signature for signature in relation if balanced(signature)
    )
    assert len(balanced_relation) == 19

    reordered_balanced = transformed(
        balanced_relation, PORT_PERMUTATION
    )
    reordered_full = transformed(relation, PORT_PERMUTATION)
    assert not (balanced_relation & reordered_balanced)
    assert len(relation & reordered_full) == 35

    edges = host_edges()
    normalized = tuple(tuple(sorted(edge)) for edge in edges)
    assert len(normalized) == len(set(normalized))
    assert all(
        sum(vertex in edge for edge in normalized) == 3
        for vertex in range(28)
    )
    # Connectivity and bridge-freeness are included in the cut test; the
    # order-one cut loop also makes the assertion explicit.
    assert cyclically_six(edges)

    print(
        {
            "heawood_raw_assignments": raw,
            "full_relation_orbits": len(relation),
            "balanced_orbits": len(balanced_relation),
            "balanced_overlap_at_permutation": len(
                balanced_relation & reordered_balanced
            ),
            "full_overlap_at_permutation": len(relation & reordered_full),
            "host_vertices": 28,
            "host_edges": len(edges),
            "host_cyclically_6": True,
        }
    )
    print("HEAWOOD_BALANCED_DISJOINT_CYCLIC6_VERIFIED")


if __name__ == "__main__":
    main()
