# The cyclically-6 branch: exact six-cut interface

**Date:** 2026-08-30  
**Scope:** one analytic lemma for the cyclically-6 branch of the
Berge--Fulkerson conjecture. No graph census, asymptotic search, or abstract
route/load model is used.

## The compressed question

Let \(G\) be a bridgeless cubic graph and let \(C=\delta(X)\) be a
cycle-separating cut of size six. Cutting the six edges produces ordered
six-poles \(H_X\) and \(H_{\bar X}\), with the \(j\)-th semiedges corresponding
to the same edge of \(C\). The single missing lemma is

\[
\tag{6-cut overlap}
\mathcal R(H_X)\cap \pi\mathcal R(H_{\bar X})\ne\varnothing
\quad\text{for some }\pi\in S_6,
\]

where \(\mathcal R(H)\) is the set of ordered six-semiedge incidence signatures
realized by an actual six-matching BF certificate in \(H\), and \(\pi\) is a
global permutation of the six matching labels. If this lemma held for every
cyclically-6-connected minimum counterexample, that branch would be impossible.
Failure on a real pair of six-poles would be the exact pole-level boundary
needed for a cyclically-6-connected BF candidate; it would not by itself prove
that the completed graph is a counterexample.

## Exact gluing lemma (common perfect-matching incidence)

For a cubic \(k\)-pole \(H\), call

\[
\rho=(\rho_1,\ldots,\rho_k),\qquad
\rho_j\in { [6] \choose 2},
\]

realizable if there are six matching edge sets \(M_1,\ldots,M_6\) in \(H\)
such that every internal vertex is covered once by each \(M_i\), every proper
edge belongs to exactly two \(M_i\), and

\[
\rho_j=\{i: \text{the \(j\)-th semiedge belongs to }M_i\}.
\]

Let \(\mathcal R(H)\) be the set of all such \(\rho\). Then for a cut \(C\) as
above,

\[
\boxed{
\operatorname{BF}(G)\iff
\exists\rho_X\in\mathcal R(H_X),\rho_{\bar X}\in\mathcal R(H_{\bar X}),
\exists\pi\in S_6:\ 
\rho_X(j)=\pi(\rho_{\bar X}(j))\ \forall j.
}
\]

**Proof.** Restrict a six-perfect-matching BF cover of \(G\) to either side of
the cut. Each side is a six-matching certificate, and the two boundary
signatures agree after one relabelling of the six global matchings. Conversely,
given two certificates with signatures related by \(\pi\), relabel the second
certificate and glue the two matching edge sets across each cut edge. At every
cut edge the two semiedges occur in the same two matching labels, so the glued
edge occurs exactly twice; all internal edges already occur exactly twice. Each
matching covers every vertex once on both sides, hence is a perfect matching of
\(G\). This proves both directions.

Thus the six-cut overlap condition is not merely sufficient: it is the exact
common-incidence interface for BF across a six-cut.

## What parity gives at six, and why it stops there

For \(M\) a perfect matching and \(m_M(X)=|M\cap C|\), counting incidences on
the \(X\)-side gives

\[
|X|=2|M\cap E(X)|+m_M(X),\qquad
3|X|=2|E(X)|+6,
\]

so

\[
m_M(X)\equiv |X|\equiv 6\pmod 2.
\]

For a BF cover \(M_1,\ldots,M_6\),

\[
0\le m_{M_i}(X)\le 6,\qquad
m_{M_i}(X)\in2\mathbb Z,\qquad
\sum_i m_{M_i}(X)=12.
\]

The two profiles

\[
(2,2,2,2,2,2),\qquad (0,2,2,2,2,4)
\]

already satisfy every one of these cut equations. At the boundary-signature
level, the six semiedge pairs form a loopless Eulerian multigraph on the six
matching labels: each color has even degree. For example, the pair lists

\[
(12),(23),(34),(45),(56),(61)
\quad\text{and}\quad
(62),(62),(63),(63),(45),(45)
\]

have even color degrees and give the two displayed degree profiles. These are
arithmetic possibilities only; they are not asserted to be realizable by a
given pole. They show that parity and the edge-load equation do not force a
specific six-cut signature, produce a five-cut, or identify the two sides'
actual singleton/perfect-matching choices.

The odd parity at a five-cut is exactly why the 5-cut analysis has a much
smaller boundary problem. No such reduction follows at six.

## Evidence and decision

The locally cached source papers were checked on 2026-08-30:

* Máčajová--Mazzuoccolo (2020), Theorem 1.2: a minimum BF counterexample is
  cyclically at least five-edge-connected; the following paragraph leaves
  connectivity five or six under Jaeger--Swart.
* Máčajová--Mazzuoccolo--Tabarelli (2026): the 13 boundary cases concern the
  exact-connectivity-five branch and do not cover six.
* Liu--Hao--Zhang (2021): BF is proved for Kochol's named cyclically-6-connected
  superposition families, not for the whole class.
* Mazák--Rajník--Škoviera (2025), Theorem 1.2: cyclically-6-connected strictly
  critical snarks exist in every even order at least 342, so the branch is not
  vacuous.

No proof of the six-cut overlap lemma, no real counterexample violating it, and
no general BF-cover construction was obtained. The precise stopping decision is

\[
\boxed{\text{P6 remains undecided; the only missing interface is common actual
six-matching boundary incidence across a cyclic six-cut.}}
\]

The weakest direct sufficient hypothesis is the overlap condition itself for
every cyclic six-cut of a minimum counterexample. Any future S-level advance
must either prove this hypothesis from cubic incidence/minimality or exhibit a
real pair of sides with disjoint \(\mathcal R\)-relations (and then analyze the
completed graph). Further parity-only arguments or new order scans cannot
change this decision.

## One finite local probe (not a census)

As a bounded sanity check, exact BF boundary relations were enumerated for a
few explicitly named simple six-poles. The assignment is an edge-label CSP:
each edge receives one of the \(15={6\choose2}\) color pairs and the three
pairs at every vertex are disjoint; the first semiedge pair is fixed to
\(\{1,2\}\), and the resulting signatures are quotient-canonicalized under
\(S_6\). The resulting numbers of boundary orbits were

\[
\begin{array}{c|rrrrrr}
\text{pole}&P_4\text{ tree}&C_6&\triangle+\text{3 leaves}&
C_5+\text{leaf}&C_4+\text{path}_2&K_3+\text{path}\\
\hline
|\mathcal R/S_6|&42&92&40&73&65&42
\end{array}
\]

The \(C_6\) relation and the triangle-with-three-leaves relation intersect in
one orbit in the displayed ordering. Checking all \(6!\) reorderings of the
boundary positions never made this intersection empty (the minimum was one).
The \(P_4\) tree relation likewise had minimum intersection one against each
of the other named examples; these probes therefore produced no disjoint
nonempty pair. They are only local negative evidence: the examples have
small order and several have bridges, so they do not test the full
cyclically-6-connected pole class.

## The exact minimality consequence, and its quantifier gap

For a pairing \(p=\{\{a_1,b_1\},\{a_2,b_2\},\{a_3,b_3\}\}\) of the six cut
positions, let \(\operatorname{Fix}(p)\) be the signatures satisfying
\(\rho_{a_r}=\rho_{b_r}\) for \(r=1,2,3\). Joining the paired semiedges by
three new independent edges gives a zero-vertex cap. If the resulting closure
of a side \(H\) is bridgeless, it is smaller than \(G\); minimality then gives

\[
\mathcal R(H)\cap\operatorname{Fix}(p)\ne\varnothing . \tag{cap}
\]

This is a genuine perfect-matching statement: each cap edge must receive one
and the same pair of matching labels at its two ends. It is also the strongest
immediate use of minimality that does not assume a new structural theorem.
However, even if every admissible pairing \(p\) gives a bridgeless closure,
(cap) has the form
\[
\forall p\ \exists\rho_p\in\mathcal R(H)\cap\operatorname{Fix}(p),
\]
whereas six-cut gluing needs one signature shared by the two *different*
side relations. Minimality supplies no identity between the certificates
\(\rho_p\) for different pairings or between the two sides. A common-cap
rigidity theorem (for example, a cap whose realizable boundary relation is a
single \(S_6\)-orbit) would close the gap, but no such theorem is known here.
