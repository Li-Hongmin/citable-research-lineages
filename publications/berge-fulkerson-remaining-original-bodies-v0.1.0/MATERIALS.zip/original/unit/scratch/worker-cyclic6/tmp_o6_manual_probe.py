import sys
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
from itertools import permutations

p = Path(__file__).with_name('search_small_real_sixpole_disjoint.py')
s = spec_from_file_location('eng_tmp', p)
m = module_from_spec(s)
sys.modules[s.name] = m
s.loader.exec_module(m)

def pole(n, edges):
    deg = [0]*n
    for u,v in edges:
        deg[u] += 1; deg[v] += 1
    assert all(d <= 3 for d in deg), deg
    sem = tuple(v for v,d in enumerate(deg) for _ in range(3-d))
    assert len(sem) == 6
    return tuple(sorted(tuple(sorted(e)) for e in edges)), sem

cands = {
    'C6': pole(6, [(i,(i+1)%6) for i in range(6)]),
    'P4': pole(4, [(0,1),(1,2),(2,3)]),
    'K13': pole(4, [(0,1),(0,2),(0,3)]),
    'triangle-tail': pole(6, [(0,1),(1,2),(2,0),(0,3),(3,4),(4,5)]),
    'C4-tail': pole(6, [(0,1),(1,2),(2,3),(3,0),(0,4),(4,5)]),
    'C4-path2': pole(6, [(0,1),(1,2),(2,3),(3,0),(0,4),(1,5)]),
    'K33-star-connected': pole(6, [(0,5),(1,4),(1,5),(2,4),(2,5),(0,3)]),
    'K33-star-connected2': pole(6, [(0,4),(1,4),(1,5),(2,3),(2,5),(0,3)]),
    'K33-star-connected-path': pole(8, [(0,3),(0,6),(6,7),(7,4),(1,4),(1,5),(2,3),(2,5),(0,5)]),
}
allk = [(u,3+v) for u in range(3) for v in range(3)]
for rem, name in [
    ([(0,3),(1,3),(2,3)], 'K33-remove-star'),
    ([(0,3),(1,4),(2,4)], 'K33-remove-2star'),
    ([(0,3),(1,4),(2,5)], 'K33-remove-perfect'),
]:
    cands[name] = pole(6, [e for e in allk if e not in rem])

rels = {}
for name, (edges, sem) in cands.items():
    rel, raw = m.exact_relation(edges, sem)
    rels[name] = rel
    print(name, 'edges=', edges, 'sem=', sem, 'raw=', raw,
          'orbits=', len(rel), flush=True)
names = list(rels)
for ia, a in enumerate(names):
    for b in names[ia:]:
        if 'K33-star' not in a and 'K33-star' not in b and a != b:
            continue
        best = 10**9; arg = None
        for pos in permutations(range(6)):
            rr = {m.canonical(tuple(sig[i] for i in pos)) for sig in rels[b]}
            x = len(rels[a] & rr)
            if x < best:
                best, arg = x, pos
        print('PAIR', a, b, 'min=', best, 'arg=', arg, flush=True)
