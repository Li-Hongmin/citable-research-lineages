# Omen order-18 actual-incidence O6 probe (2026-09-02)

## Decision target

The probe was intended to distinguish a real disjoint six-pole boundary
relation from overlap in a fixed, small random order-18 family.  For two
six-poles \(H_X,H_Y\), the target condition is the exact incidence statement

\[
\exists\rho_X\in\mathcal R(H_X),\ \rho_Y\in\mathcal R(H_Y),\ \pi\in S_6,
\qquad \rho_X(j)=\pi(\rho_Y(j))\quad(1\le j\le6).
\]

The relation engine uses the full six-matching boundary assignments, not a
parity, balanced, or rainbow surrogate.

## Omen execution and stop rule

The source files were copied byte-for-byte to
[local archival reference]

~~~
search_random_actual_o6.py              ed7a893303627c77cd7bcb43848b7c357ff58dd45939961b2e3e451b98565c18
search_small_real_sixpole_disjoint.py   b6f058cfc5ee28bc508ceded5bd8ff1869e2f478dec488a73023f1873d87d898
~~~

Command:

~~~
python3 -u search_random_actual_o6.py \
  --orders 18 --samples 4 --matching-limit 2
~~~

It ran in detached tmux session o6_order18 on omen, from 03:55:37 JST.
The fixed stop rule was five minutes.  At 04:01:28 JST the process was
terminated because it was still using one CPU and had produced no complete
candidate row.  run.log remained zero bytes; no relation, gluing, or
candidate count was emitted.

## Four-value decision

This run is **inconclusive (unknown)**.  It found neither a real disjoint
pair nor a bounded no-hit: the exact order-18 relation enumeration did not
finish within the predeclared budget.  Therefore it changes no theorem
boundary and does not justify an order increase or a slower continuation.

Earlier completed probes at orders 14 and 16 remain separate finite evidence;
they do not repair the missing order-18 observation.
