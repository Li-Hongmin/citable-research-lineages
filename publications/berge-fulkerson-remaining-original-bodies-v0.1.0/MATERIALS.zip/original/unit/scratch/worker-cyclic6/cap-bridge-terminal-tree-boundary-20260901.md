# Six-cut cap bridges: exact terminal-tree boundary

**Scope.** This is an analytic refinement of the cyclically-\(\ge6\) six-cut
interface. It does not prove the cross-shore overlap condition and does not
use a graph census.

Let \(G\) be simple and bridgeless with \(\lambda_c(G)\ge 6\), let
\(C=\delta(X)\) be a cycle-separating cut of size six, and let \(H=G[X]\) be
the corresponding six-pole. For a pairing \(p\) of the six ports, write
\(K=H/p\) for the cubic cap closure. If \(K\) has a bridge, let \(A\) be the
vertex set of one component of \(K-b\), and let \(t\) be the number of ports
of \(H\) incident with \(A\), counted with multiplicity.

Because \(X\) contains a cycle, \(X\) is connected: each component of
\(G[X]\) has at least three boundary edges (otherwise \(G\) would have a
bridge or a nontrivial two-cut), while any cyclic component has boundary at
least six because \(G-X\) contains a cycle. The total boundary is six, so
there is only one component. Thus \(H\), and hence every \(K=H/p\), is
connected before any bridge is considered.

## Bridge classification

If \(b\) is a cap edge, it is the only cap edge crossing \(A\). Hence \(t\) is
odd and \(\delta_G(A)\) consists exactly of those \(t\) cut edges. Since the
opposite shore contains a cycle, a cyclic \(G\)-cut of size \(t<6\) is
impossible. Thus \(A\) is acyclic. The proper subgraph induced by \(A\) is
initially only a forest (internal cap edges of \(K\) become cut edges again in
\(G\)). Every nonempty tree component has at least three boundary incidences:
\(G\) is bridgeless, and a nonempty cubic tree with \(d\) dangling edges has
\(d\ge3\). Since \(t\le5\), there is only one component. A connected cubic
tree with \(t\) dangling edges satisfies

\[
3|A|=2(|A|-1)+t,\qquad |A|=t-2,
\]

so \(t\in\{3,5\}\) (the case \(t=1\) has no nonempty tree).

If \(b\) is a proper edge, no cap edge crosses \(A\), so all port pairs of
\(p\) lie wholly on one side and \(t\) is even. The cut in \(G\) has size
\(t+1\). The proper subgraph induced by \(A\) is a forest. If \(A\) contained a cycle, the opposite shore would give a
cycle-separating cut; \(\lambda_c(G)\ge6\) therefore forces \(t+1\ge6\).
The cases \(t=0\) and \(t=6\) make \(b\) a bridge of \(G\), so they are
impossible. Consequently \(t\in\{2,4\}\), and \(A\) is acyclic. Its total
boundary is \(t+1\in\{3,5\}\), so the same component-count argument makes the
forest a single tree. The tree equation with \(t+1\) boundary edges gives
\(|A|=t-1\), i.e. a one-vertex or three-vertex terminal tree.

Therefore every bridge of every cap closure is accounted for by a terminal
tree with two, three, four, or five ports (depending on whether the bridge is
proper or a cap edge); no cyclic bridge component is possible.

## Consequence for minimality

If a shore has no such one-/three-vertex terminal-tree component, all fifteen
zero-vertex cap closures \(H/p\) are bridgeless. Minimality of a minimum
Berge--Fulkerson counterexample then gives, for every pairing \(p\),

\[
\mathcal R(H)\cap\operatorname{Fix}(p)\ne\varnothing.
\]

This is still only \(\forall p\,\exists\rho_p\). The six-cut gluing condition is
\(\exists\rho_X,\rho_Y,\pi\) with \(\rho_X=\pi\rho_Y\) portwise. Thus removing
all terminal-tree cap bridges sharpens the structural input but does not close
the cross-shore actual-incidence quantifier gap.

## Global boundary

Even if \(\lambda_c(G)=6\), the remaining implication is the actual
common-incidence statement

\[
\exists \rho_X\in\mathcal R(H_X),\ \rho_Y\in\mathcal R(H_Y),\ \pi\in S_6,
\qquad \rho_X(j)=\pi(\rho_Y(j))\quad\forall j.
\]

If \(\lambda_c(G)>6\), no cycle-separating six-cut exists at all, so a six-pole
reduction cannot start; the Jaeger--Swart conjecture does not supply this
missing BF theorem. Hence a D5-independent proof must either establish the
cross-shore incidence theorem at exact connectivity six or handle the
\(\lambda_c>6\) branch directly.

This is a strict boundary/weak additional condition, not a Berge--Fulkerson
proof or counterexample.
