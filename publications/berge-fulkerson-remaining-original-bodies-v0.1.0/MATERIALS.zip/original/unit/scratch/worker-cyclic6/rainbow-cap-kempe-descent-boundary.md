# Rainbow-cap Kempe descent at a cyclic six-cut

## Scope and decision

This pulse does not decide the cyclically-six O6 overlap statement.  It gives
one actual-perfect-matching sufficient condition and identifies its exact
alternating-cycle obstruction.  It also gives two real bridgeless six-poles
showing that all cap closures being BF-colourable does not force this
condition.  The example is not a minimum-counterexample shore pair and is not
a Berge--Fulkerson counterexample.

Let (H) be an ordered cubic six-pole and let

\[
 p=\{\{a_1,b_1\},\{a_2,b_2\},\{a_3,b_3\}\}
\]

be a pairing of its ports.  Joining each (a_r,b_r) gives a capped cubic
graph (K=H/p) with three distinguished cap edges
(F=\{f_1,f_2,f_3\}).  For a BF cover
(\mathcal M=(M_1,\ldots,M_6)) of (K), put

\[
 L(f)=\{i:f\in M_i\},\qquad
 d_i=|\{f\in F:i\in L(f)\}|.
\]

Each (L(f)) has size two and hence \(\sum_i d_i=6\).

## The rainbow-cap sufficient condition

Call the cover *rainbow on the cap* if the three sets (L(f_1),L(f_2),
L(f_3)) are pairwise disjoint.  Equivalently,

\[
 d_1=\cdots=d_6=1.
\]

Suppose the same port pairing (p) is admissible on two six-poles
(H_X,H_Y), and both capped graphs (H_X/p,H_Y/p) have rainbow-cap BF
covers.  Restricting either cover to its pole gives a (p)-fixed boundary
signature: the two ports joined by (f_r) have the common label (L(f_r)).
There is only one (S_6)-orbit of ordered triples of pairwise-disjoint
two-subsets of ([6]).  Therefore the two restricted signatures agree after
one global permutation of the six matching labels.  The exact gluing lemma
then gives a BF cover across the original six-cut.

Thus a concrete sufficient condition for O6 is

\[
 \boxed{\text{one common admissible pairing whose two cap closures admit
 rainbow-cap BF covers}.} \tag{R}
\]

Unlike common-cap overlap itself, (R) is a one-closure edge-incidence
property: every one of the six perfect matchings must use exactly one of the
three distinguished cap edges.

## Exact Kempe descent and the carrier obstruction

Define the collision potential

\[
 \Phi(\mathcal M)=\sum_{i=1}^6 {d_i\choose2}.
\]

It is nonnegative and vanishes exactly for a rainbow cap.  Suppose
(d_i\ge2) and (d_j=0).  The symmetric difference
(M_i\mathbin\triangle M_j) is a disjoint union of alternating even cycles.
Every cap edge counted by (d_i) lies in this symmetric difference.  If one
component (C) contains exactly (r) of these cap edges, with
(0<r<d_i), exchange (M_i) and (M_j) along (C).  Both remain perfect
matchings and their edge-incidence sum is unchanged, so all six matchings
still form a BF cover.  Only the two cap degrees change:

\[
 d_i' = d_i-r,\qquad d_j'=r.
\]

Consequently

\[
 \Phi(\mathcal M')-\Phi(\mathcal M)
 ={d_i-r\choose2}+{r\choose2}-{d_i\choose2}
 =r(r-d_i)<0. \tag{1}
\]

Repeated descent must terminate at a rainbow cover whenever such a partial
component exists at every non-rainbow stage.  Conversely, choose a cover
minimising (Phi) inside its BF Kempe-exchange component.  If it is not
rainbow, then for every repeated colour (i), every missing colour (j),
and every component of (M_i\triangle M_j), the component contains either
none or all (d_i) of the (i)-labelled cap edges.  Since those edges must
occur somewhere, one alternating cycle contains all of them.

This is the exact obstruction to the descent:

\[
 \boxed{\text{a repeated cap colour is carried as one inseparable block by
 every relevant missing-colour alternating system}.} \tag{C}
\]

After deleting the cap edges, that carrier cycle becomes a two- or
three-linkage through the original six-pole.  Therefore a proof of (R) from
minimum-counterexample structure must rule out these actual alternating
carrier linkages; parity or aggregate edge load cannot do it.

## Real all-cap boundary: rainbow compatibility is not automatic

Take the two simple eight-vertex theta six-poles whose proper cores have path
lengths

\[
 (1,4,4)\qquad\text{and}\qquad(3,3,3),
\]

with one semiedge on each of the six internal degree-two vertices.  Both
proper cores are bridgeless, and all fifteen zero-vertex capped closures of
each pole are bridgeless.  Exact common perfect-matching incidence enumeration
gives respectively

\[
 147\quad\text{and}\quad135
\]

boundary (S_6)-orbits; every pairing has a nonempty cap-fixed fibre.  In the
standard ordering of the fifteen port pairings, the pairings admitting a
rainbow cap are

\[
 \{2,6,8,10,11,13\},\qquad \{0,7,12\}.
\]

They are disjoint.  Hence even two real, simple, distinct-terminal,
proper-edge-bridgeless six-poles with every cap closure bridgeless and
BF-colourable need not have a common rainbow pairing.

This does **not** refute common-cap overlap or O6.  The two full relations
intersect in 47 orbits, and eleven pairings have a common non-rainbow
cap-fixed orbit.  Moreover their direct gluing has cyclic connectivity four,
so the example does not test the additional whole-graph cyclically-six
structure.  Its exact consequence is narrower and decisive:

\[
 \boxed{\text{minimality through BF-colourable cap closures alone cannot
 prove O6 by rainbow normalization}.}
\]

The remaining version of this route must use cyclically-six/minimum-graph
structure to eliminate the carrier obstruction (C), or must allow common
non-rainbow cap types.

## Reproduction

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-cyclic6/verify_rainbow_cap_boundary.py
```

The terminal marker is

```text
RAINBOW_CAP_REAL_POLE_BOUNDARY_VERIFIED
```
