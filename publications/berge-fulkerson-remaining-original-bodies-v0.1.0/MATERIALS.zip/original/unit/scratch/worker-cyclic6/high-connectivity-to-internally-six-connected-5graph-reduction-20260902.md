# High cyclic connectivity reduces a BF counterexample to a class-2 5-graph

**Date.** 2026-09-02.  This is an analytic reduction gate.  It is not a
proof of the Berge--Fulkerson conjecture and it does not replace the
common-incidence analysis for an exact six-cut.

## Statement

Let \(G\) be a connected bridgeless cubic graph with cyclic edge connectivity
\(\lambda_c(G)\ge 6\).  Choose any 2-factor \(F\) of \(G\) (one exists by
Petersen's perfect-matching theorem), and form the 5-regular multigraph

\[
        H=G+E(F),
\]

by adding one parallel copy of every edge of \(F\).  Then:

1. \(H\) is 5-edge-connected.
2. Every 5-edge-cut of \(H\) is the star of a single vertex.  Equivalently,
   \(H\) has no nontrivial 5-edge-cut (it is internally 6-edge-connected in
   the usual 5-graph sense).
3. If \(G\) is a Berge--Fulkerson counterexample, then \(H\) is class 2: it
   has no decomposition into five pairwise edge-disjoint perfect matchings.

Consequently, a BF counterexample with \(\lambda_c(G)\ge6\) would produce a
5-edge-connected, class-2, 5-regular multigraph whose underlying simple
cubic graph is cyclically at least 6-edge-connected and whose nontrivial
5-cuts are absent.

The reduction applies both to \(\lambda_c(G)=6\) and to
\(\lambda_c(G)>6\).  In the latter case there is no cycle-separating six-cut,
so this 5-regular gate is not a reformulation of the six-pole interface.

## Proof of the cut assertions

For a nonempty proper \(X\subset V(G)\), write

\[
 d=|\delta_G(X)|,\qquad f=|\delta_F(X)|.
\]

Because \(F\) is a union of cycles, \(f\) is even, and

\[
             |\delta_H(X)|=d+f.
\tag{1}
\]

First \(d\ge3\).  Indeed, \(d=1\) is excluded by bridgelessness.  If
\(d=2\), neither shore can be acyclic: every nonempty cubic tree component
with \(b\) boundary incidences satisfies \(b=|V|+2\ge3\).  Thus a
2-cut would be cycle-separating, contrary to \(\lambda_c(G)\ge6\).
If \(d\ge5\), (1) gives \(|\delta_H(X)|\ge5\).  For \(d=3\) or \(d=4\),
the value \(f=0\) would put every spanning \(F\)-cycle entirely on one
side, so both shores contain an \(F\)-cycle and \(G\) would have a
cycle-separating \(3\)- or \(4\)-cut.  Hence \(f\ge2\) in these two cases,
and (1) again gives at least five.  Thus \(H\) is 5-edge-connected.

Now assume \(|\delta_H(X)|=5\).  Since \(f\) is even and \(d\ge3\), the
only possibilities are

\[
       (d,f)=(3,2)\quad\text{or}\quad(d,f)=(5,0).
\tag{2}
\]

The second possibility would make \(\delta_G(X)\) a cycle-separating
5-cut: \(f=0\) puts every \(F\)-cycle on one shore, and both nonempty shores
contain such a cycle.  This contradicts \(\lambda_c(G)\ge6\).

In the first possibility, \(\delta_G(X)\) is a 3-cut.  At least one shore
is acyclic; otherwise it is a cycle-separating 3-cut.  Let \(A\) be an
acyclic shore.  A nonempty cubic forest with \(b\) boundary incidences has
each tree component incident with at least three boundary edges.  Moreover,
for a connected cubic tree,

\[
       3|V(A)|=2(|V(A)|-1)+b,\qquad b=|V(A)|+2.
\tag{3}
\]

Here \(b=3\), so there is exactly one component and \(|V(A)|=1\).  The
three original cut edges at that vertex are joined in \(H\) by their two
parallel \(F\)-copies, giving the five-edge star of the vertex.  Thus every
5-cut of \(H\) is trivial.

The phrase “at least one shore is acyclic” is all that is needed: if both
shores were cyclic, the same 3-cut would violate the assumed cyclic
connectivity.  The forest component argument also rules out a disconnected
acyclic shore, since each nonempty component would require at least three
boundary incidences while the total is three.

## Why a BF counterexample forces class 2

Assume that \(H\) has five pairwise edge-disjoint perfect matchings
\(N_1,\ldots,N_5\).  Since \(H\) is 5-regular, these matchings exhaust all
edges of \(H\): at each vertex they use five distinct incident edges.  Map a
matching in \(H\) back to \(G\) by forgetting whether an edge of \(F\) is the
original copy or its parallel copy; call the result \(M_i\).  Each \(M_i\)
is a perfect matching of \(G\); a matching cannot contain both parallel
copies, so projection does not create an incidence conflict.  Every edge
outside \(F\) occurs in exactly one \(M_i\), and every edge of \(F\) occurs
in exactly two \(M_i\).

The complement

\[
                 M_0=E(G)\setminus E(F)
\]

is a perfect matching (the complement of a 2-factor in a cubic graph).
Therefore \(M_0,M_1,\ldots,M_5\) cover every edge of \(G\) exactly twice,
which is a Berge--Fulkerson cover.  Hence a BF counterexample cannot yield
class 1 \(H\).

## Exact scope and remaining gate

The reduction is a one-way implication.  It does **not** show that every
such 5-regular graph is class 2, nor that every class-2 5-graph comes from a
BF counterexample.  Thus the following is a precise sufficient condition,
not a known theorem:

> If every 5-edge-connected 5-regular 5-graph whose underlying cubic graph
> is cyclically at least 6-edge-connected and whose nontrivial 5-cuts are
> absent is class 1, then no BF counterexample has
> \(\lambda_c\ge6\).

For exact connectivity six, one may still separately study a cyclic
6-cut and the actual six-matching common-incidence relation.  For
\(\lambda_c>6\), no such cut exists and the class-2 5-graph gate (or another
direct high-connectivity argument) is the remaining interface.

## Literature boundary

Ma--Mattiolo--Steffen--Wolf, *Pairwise Disjoint Perfect Matchings in
r-Edge-Connected r-Regular Graphs* (arXiv:2206.10975; 2023 version),
Observation 5.11, records the same implication in the direction “if
\(m(5)=5\), then the Berge--Fulkerson conjecture follows”; their Problem
1.6 asks whether a 5-edge-connected class-2 5-regular graph exists.  This
open problem is exactly why the present reduction is a gate rather than a
resolution.

No graph enumeration is used in this note.
