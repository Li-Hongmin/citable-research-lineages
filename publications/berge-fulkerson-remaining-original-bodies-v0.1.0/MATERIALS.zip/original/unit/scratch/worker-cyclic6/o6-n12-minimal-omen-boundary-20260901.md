# O6 order-12 minimal targeted boundary (2026-09-01)

## Pulse and scope

The tested arrow was the exact six-cut common-incidence condition

\[
  \exists\rho_X\in\mathcal R(H_X),\rho_Y\in\mathcal R(H_Y),\pi\in S_6,
  \qquad \rho_X(j)=\pi(\rho_Y(j))\quad(j=1,\ldots,6).
\]

The probe was deliberately restricted to order-12 connected cubic hosts.  For
each of three deterministic `networkx.random_regular_graph(3,12,seed)` hosts,
the first three vertex-disjoint 3-edge matchings were removed when the
resulting six-pole had connected proper core and no proper bridge.  The exact
edge-pair \((V)\)-gate relation was enumerated; no parity/load/rainbow
surrogate was used.

## Omen result

Command on Omen:

```text
python3 -u search_random_actual_o6.py --orders 12 --samples 3 --matching-limit 3
```

Source hashes:

```text
search_random_actual_o6.py       ed7a893303627c77cd7bcb43848b7c357ff58dd45961b2e3e451b98565c18
search_small_real_sixpole_disjoint.py
                                  b6f058cfc5ee28bc508ceded5bd8ff1869e2f478dec488a73023f1873d87d898
```

Seven poles survived the connected/proper-bridgeless filter.  Their exact
relation sizes (raw assignments / colour-orbit signatures) were

```text
81300/218, 64668/231, 65580/156, 27132/146,
5838/147, 5838/147, 21876/200.
```

All 28 unordered pole pairs, including self-pairs, were checked over all 720
boundary-position correspondences.  The minimum colour-orbit intersection
was 12; no zero-overlap pair occurred.  The log checksum is

```text
637986d458749aa41559f549bcd872ec0558dbb0d8690ac7305c988c75a5407e
```

## Decision

This is finite negative evidence only:

\[
\boxed{\text{the seven targeted order-12 poles contain no disjoint actual
relation pair, even after boundary reordering}.}
\]

It neither proves universal O6 nor tests the minimum-counterexample
hypothesis.  In particular, positive overlap under arbitrary boundary
reordering is weaker than the fixed cut-coordinate overlap required for a
given glued graph.  The unresolved interface remains common actual
six-matching incidence across the two shores.

Reproduction from project root after copying the two scripts to Omen:

```text
python3 -u search_random_actual_o6.py --orders 12 --samples 3 --matching-limit 3
```

