# Omen order-16 prism six-pole O6 probe (2026-09-02)

## Decision target

For one real simple cubic six-pole, test the exact actual six-matching
boundary relation against itself under every (6!) port correspondence.  A
zero intersection would be a pole-level disjoint-relation hit; a positive
intersection is finite negative evidence only.

## Construction and command

The host is the circular ladder (prism) on 16 vertices.  Delete the matching

\[
\{(0,1),(2,3),(4,5)\},
\]

leaving 21 proper edges and six distinct semiedge endpoints.  The proper core
was checked connected and proper-edge-bridgeless.  The exact relation engine
assigns one of the 15 two-subsets of six matching labels to each edge, with a
disjoint partition at every cubic vertex; no parity or balanced surrogate is
used.

Omen command (detached tmux, 5-minute limit):

```text
python3 -u probe_prism8_order16_o6.py
```

Omen run directory:

```text
[local archival reference]
```

Source SHA-256:

```text
probe_prism8_order16_o6.py              8fb34e86cbd036e88c07c474643be3396444f53e9cf007ae09dc103a9cf2dc86
search_small_real_sixpole_disjoint.py   b6f058cfc5ee28bc508ceded5bd8ff1869e2f478dec488a73023f1873d87d898
```

## Exact Omen output

```text
raw_assignments=2026518
relation_orbits=158
minimum_self_overlap=29
best_positions=(0, 2, 4, 1, 5, 3)
PRISM8_ORDER16_O6_PROBE_OK
```

The archived Omen log is
`omen-o6-prism8-order16-20260902.log` with SHA-256
`e177688e3c3d9d71503d570ab0000949dd655c97643dac830f9cf9de85be657f`.

## Four-value decision

This fixed order-16 real six-pole has positive self-overlap (minimum 29), so
it is not a disjoint-relation counterexample.  The result is a bounded no-hit
for one structured pole and does not prove the universal six-cut overlap
condition; no order increase is justified from this observation alone.

