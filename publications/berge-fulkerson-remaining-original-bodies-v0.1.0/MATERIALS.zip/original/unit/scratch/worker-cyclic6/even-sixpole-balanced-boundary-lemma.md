# Even six-pole boundary balancing by Kempe paths

## Statement

Let \(H\) be a cubic six-pole with six semiedges. Assume that \(H\) has a
six-matching certificate

\[
M_1,\ldots,M_6,\qquad \sum_{i=1}^6\chi^{M_i}=2\mathbf 1
\]

on all proper and semiedge objects (a semiedge is therefore in exactly two
of the \(M_i\)). Then \(H\) has another six-matching certificate for which

\[
d_i:=\#\{\text{semiedges used by }M_i\}=2
\qquad (i=1,\ldots,6). \tag{BB}
\]

Thus every nonempty actual boundary relation \(\mathcal R(H)\) contains a
balanced signature: every matching colour occurs on exactly two of the six
boundary positions. No connectivity, bridgelessness, or
minimal-counterexample hypothesis is needed.

## Proof

Replace each proper edge and each semiedge by two parallel/dangling copies.
Colour the two copies of an object \(e\) by the two matching indices that use
it. At every internal vertex there is exactly one incident copy of each
colour. Hence the copies of colours \(i,j\) form a degree-two subgraph at
every internal vertex; its components with boundary dummies are paths, and
each such path has exactly two boundary-dummy endpoints.

The pole order is even, since

\[
3|V(H)|=2|E_{\mathrm{proper}}(H)|+6.
\]

Consequently each \(d_i\) is even: after the \(d_i\) colour-\(i\) dangling
copies are removed, the remaining internal vertices are paired by
colour-\(i\) proper copies. Also \(\sum_i d_i=12\).

Choose a certificate minimizing

\[
\Phi=\sum_{i=1}^6(d_i-2)^2.
\]

If (BB) fails, some \(d_i\ge4\) and some \(d_j=0\). In the two-colour
subgraph for \(i,j\), every boundary endpoint has colour \(i\), so there are
at least two distinct \(i\)-to-\(i\) path components. Swap colours \(i\) and
\(j\) on one such path. This preserves the local one-copy-per-colour
condition at every internal vertex and preserves the load two of every
original edge. It changes

\[
(d_i,d_j)\longmapsto(d_i-2,d_j+2)=(d_i-2,2),
\]

while all other \(d_r\) stay fixed. The potential change is

\[
(d_i-4)^2-(d_i-2)^2+0-4=8-4d_i<0,
\]

contradicting minimality. Therefore all \(d_i=2\).

## Boundary consequence

For a balanced signature \(\rho\), put

\[
L_i=\{j:i\in\rho_j\}\subseteq[6].
\]

Each \(L_i\) is a two-element set and every boundary position belongs to two
of the \(L_i\). Hence the six \(L_i\) are the edges of a loopless
2-regular multigraph on the six boundary positions (cycle types \(6\),
\(4+2\), \(3+3\), or \(2+2+2\)). If two poles have balanced signatures
with the same multiset \(\{L_1,\ldots,L_6\}\), a colour permutation aligns
the six \(L_i\)'s and gives the required six-cut overlap.

This is a genuine strengthening of the six-cut interface, but it does not
by itself prove cross-shore overlap: two poles may have disjoint sets of such
2-factors, and the existing cap condition does not force a prescribed one.

## Scope

The lemma is a normalization theorem for actual common perfect-matching
incidence. It is not a parity/load surrogate and does not address
\(\lambda_c>6\).
