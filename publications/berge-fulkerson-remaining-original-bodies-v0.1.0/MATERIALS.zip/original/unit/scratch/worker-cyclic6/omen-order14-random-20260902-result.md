# Omen order-14 actual-incidence O6 pulse (2026-09-02)

## Decision target

The tested interface is the exact six-cut overlap condition

\[
  \exists\rho_X\in\mathcal R(X),\ \rho_Y\in\mathcal R(Y),\ \pi\in S_6,
  \qquad \rho_X=\pi\rho_Y .
\]

A zero intersection for a valid gluing would be a real disjoint actual
six-pole pair.  A positive intersection is only bounded negative evidence.
The computation uses the complete six-matching boundary relation of each
pole; it does not replace it by parity, load, or rainbow data.

## Omen run

Host: `omen`, detached session `o6-order14-20260902`.

Command:

```text
python3 -u search_random_actual_o6.py --orders 14 --samples 4 --matching-limit 3
```

The source files copied byte-for-byte to Omen were:

```text
search_random_actual_o6.py              ed7a893303627c77cd7bcb43848b7c357ff58dd45939961b2e3e451b98565c18
search_small_real_sixpole_disjoint.py   b6f058cfc5ee28bc508ceded5bd8ff1869e2f478dec488a73023f1873d87d898
```

The run directory was `[local archival reference]`.
The archived log is `omen-order14-random-20260902/run.log` (SHA-256
`331dbbd646b610f8f65160968010bcb9c5b06c8f2864f25c13852115df336b10`).

## Exact finite output

Eleven order-14 poles survived the connected/proper-edge-bridgeless filter.
Their raw relation counts / colour-orbit relation sizes were

```text
44892/264, 51888/263, 88644/169,
94032/449, 106128/448, 99438/391,
31632/146, 9528/119, 9528/119,
89232/206, 23532/246.
```

All 66 unordered pole pairs (including self-pairs) were tested under all 720
boundary-position permutations.  The minimum colour-orbit intersection was
7; no zero-overlap pair occurred.  The process ended normally with
`RANDOM_ACTUAL_O6_TARGETED_PROBE_OK`.

## Four-value decision

* No real disjoint six-pole pair was found in this fixed-seed order-14 family.
* No universal O6 overlap theorem follows from the run.
* The cyclically-six branch remains unresolved; no order increase is justified
  by this bounded no-hit.

This is a targeted finite negative result, not a graph census and not an
UNSAT certificate.
