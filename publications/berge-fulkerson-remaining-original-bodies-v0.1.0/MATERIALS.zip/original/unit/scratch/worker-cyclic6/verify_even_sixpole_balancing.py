#!/usr/bin/env python3
"""Small independent sanity check for the six-pole balancing lemma.

The proof is general; this verifier only checks that several named actual
incidence networks (including repeated and distinct terminals) have a
balanced boundary signature.  It uses a self-contained recursive gate
enumerator and no legacy relation module.
"""

from __future__ import annotations

from itertools import combinations

PAIRS = tuple(combinations(range(6), 2))
PAIR_INDEX = {pair: i for i, pair in enumerate(PAIRS)}


def canonical(signature):
    best = None
    for perm in __import__("itertools").permutations(range(6)):
        image = tuple(
            PAIR_INDEX[tuple(sorted((perm[a], perm[b])))]
            for a, b in (PAIRS[c] for c in signature)
        )
        if best is None or image < best:
            best = image
    return best


def relation(proper: tuple[tuple[int, int], ...],
             boundary: tuple[int, ...]) -> frozenset[tuple[int, ...]]:
    n = max(max(edge) for edge in proper + tuple((v, v) for v in boundary)) + 1
    edges = list(proper) + [(v, None) for v in boundary]
    incidence = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        incidence[u].append(index)
        if v is not None:
            incidence[v].append(index)
    assert all(len(items) == 3 for items in incidence)
    values: list[int | None] = [None] * len(edges)
    values[len(proper)] = 0  # exact colour gauge: first semiedge = {0,1}
    result: set[tuple[int, ...]] = set()

    def candidates(index: int):
        allowed = set(range(15))
        for vertex in edges[index]:
            if vertex is None:
                continue
            used = set()
            for edge in incidence[vertex]:
                code = values[edge]
                if code is not None:
                    used.update(PAIRS[code])
            allowed = {
                code for code in allowed
                if set(PAIRS[code]).isdisjoint(used)
            }
        return allowed

    def valid(vertex: int) -> bool:
        assigned = [
            values[index] for index in incidence[vertex]
            if values[index] is not None
        ]
        return len(assigned) == len(set(assigned)) and all(
            set(PAIRS[a]).isdisjoint(PAIRS[b])
            for a, b in combinations(assigned, 2)
        )

    def rec(left: int) -> None:
        if left == 0:
            result.add(canonical(tuple(
                values[len(proper) + i] for i in range(6)
            )))
            return
        unassigned = [i for i, value in enumerate(values) if value is None]
        index = min(unassigned, key=lambda item: len(candidates(item)))
        u, v = edges[index]
        for code in candidates(index):
            values[index] = code
            if valid(u) and (v is None or valid(v)):
                rec(left - 1)
        values[index] = None

    rec(len(edges) - 1)
    return frozenset(result)


def balanced(signature: tuple[int, ...]) -> bool:
    return all(
        sum(color in PAIRS[code] for code in signature) == 2
        for color in range(6)
    )


def theta(lengths: tuple[int, int, int]):
    proper = []
    boundary = []
    next_vertex = 2
    for length in lengths:
        previous = 0
        for _ in range(1, length):
            proper.append((previous, next_vertex))
            boundary.append(next_vertex)
            previous = next_vertex
            next_vertex += 1
        proper.append((previous, 1))
    return tuple(proper), tuple(boundary)


def main() -> None:
    examples = [
        ("C6", tuple((i, (i + 1) % 6) for i in range(6)), tuple(range(6))),
        ("theta225", *theta((2, 2, 5))),
        ("theta333", *theta((3, 3, 3))),
    ]
    rows = []
    for name, proper, boundary in examples:
        signatures = relation(proper, boundary)
        count = sum(balanced(signature) for signature in signatures)
        assert signatures and count
        rows.append((name, len(signatures), count))
    print({"examples": rows})
    print("EVEN_SIXPOLE_BALANCING_SANITY_OK")


if __name__ == "__main__":
    main()
