#!/usr/bin/env python3
"""Targeted minimal probe for an all-cap, no-rainbow real six-pole.

The candidates are obtained by deleting a matching of three edges from a
short list of named simple cubic graphs.  We retain the actual (V)-gate
boundary relation, not a boundary-only model.  For each candidate we check:

* the six-pole is connected and has no proper-edge bridge;
* all fifteen zero-vertex cap closures are connected and bridgeless;
* every cap has a BF-fixed boundary signature; and
* whether any actual boundary signature has the rainbow shape
  (three pairwise disjoint labels, each repeated twice).

This is deliberately a named/constructive minimum probe, not a census.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
import sys
import argparse

import networkx as nx

HERE = Path(__file__).resolve().parent
ENGINE_PATH = HERE / "search_small_real_sixpole_disjoint.py"
spec = __import__("importlib.util").util.spec_from_file_location("o6_named_engine", ENGINE_PATH)
assert spec is not None and spec.loader is not None
ENGINE = __import__("importlib.util").util.module_from_spec(spec)
sys.modules[spec.name] = ENGINE
spec.loader.exec_module(ENGINE)


def pairings(remaining: tuple[int, ...] = tuple(range(6))):
    if not remaining:
        return ((),)
    first = remaining[0]
    result = []
    for i, second in enumerate(remaining[1:]):
        rest = remaining[1:i + 1] + remaining[i + 2:]
        result.extend(((first, second),) + tail for tail in pairings(rest))
    return tuple(result)


PAIRINGS = pairings()
assert len(PAIRINGS) == 15


def connected(n: int, edges: tuple[tuple[int, int], ...], deleted=()):
    """Connectivity in a multigraph represented by an edge tuple."""
    deleted = set(deleted)
    if n == 0:
        return True
    adjacency = [[] for _ in range(n)]
    for index, (u, v) in enumerate(edges):
        if index in deleted:
            continue
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        for vertex in adjacency[stack.pop()]:
            if vertex not in seen:
                seen.add(vertex)
                stack.append(vertex)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]):
    return connected(n, edges) and all(connected(n, edges, (i,)) for i in range(len(edges)))


def proper_pole(graph: nx.Graph, deleted: tuple[tuple[int, int], ...]):
    normalized = {tuple(sorted(e)) for e in deleted}
    proper = tuple(
        tuple(sorted(e)) for e in graph.edges()
        if tuple(sorted(e)) not in normalized
    )
    # Boundary ports are ordered by the deleted-edge order, then endpoint.
    boundary = tuple(v for e in deleted for v in e)
    assert len(boundary) == 6 and len(set(boundary)) == 6
    n = graph.number_of_nodes()
    relabel = {v: i for i, v in enumerate(sorted(graph.nodes()))}
    proper = tuple(tuple(sorted((relabel[u], relabel[v]))) for u, v in proper)
    boundary = tuple(relabel[v] for v in boundary)
    return proper, boundary


def cap_edges(proper, boundary, pairing):
    return tuple(proper) + tuple(
        tuple(sorted((boundary[a], boundary[b]))) for a, b in pairing
    )


def fixed(signature, pairing):
    return all(signature[a] == signature[b] for a, b in pairing)


def rainbow_shape(signature):
    """Three disjoint pair labels, each with multiplicity two."""
    counts = {}
    for value in signature:
        counts[value] = counts.get(value, 0) + 1
    if sorted(counts.values()) != [2, 2, 2]:
        return False
    labels = [set(ENGINE.PAIRS[value]) for value in counts]
    return len(set().union(*labels)) == 6


def named_graphs():
    # Ordered by increasing order; these are a deliberately short named list.
    result = [
        ("K4", nx.complete_graph(4)),
        ("K3,3", nx.complete_bipartite_graph(3, 3)),
        ("cube", nx.cubical_graph()),
        ("Petersen", nx.petersen_graph()),
        ("Heawood", nx.heawood_graph()),
        ("Möbius-Kantor", nx.moebius_kantor_graph()),
    ]
    for n in (4, 5, 6, 7, 8):
        result.append((f"prism{n}", nx.circular_ladder_graph(n)))
    for n in (4, 5, 6, 7):
        graph = nx.cycle_graph(2 * n)
        graph.add_edges_from((i, i + n) for i in range(n))
        result.append((f"mobius{2*n}", graph))
    return result


@dataclass(frozen=True)
class Candidate:
    graph_name: str
    order: int
    deleted: tuple[tuple[int, int], ...]
    proper: tuple[tuple[int, int], ...]
    boundary: tuple[int, ...]


def candidates(max_order: int | None = None, orbit_representatives: bool = False):
    seen = set()
    for graph_name, graph in named_graphs():
        if max_order is not None and graph.number_of_nodes() > max_order:
            continue
        edges = tuple(tuple(sorted(e)) for e in graph.edges())
        automorphisms = (
            tuple(nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter())
            if orbit_representatives else ()
        )
        deleted_orbits = set()
        for deleted in combinations(edges, 3):
            vertices = tuple(v for e in deleted for v in e)
            if len(set(vertices)) != 6:
                continue
            deleted_key = tuple(sorted(deleted))
            if orbit_representatives:
                deleted_key = min(
                    tuple(sorted(tuple(sorted((a[u], a[v]))) for u, v in deleted))
                    for a in automorphisms
                )
                if deleted_key in deleted_orbits:
                    continue
                deleted_orbits.add(deleted_key)
            proper, boundary = proper_pole(graph, deleted)
            key = (graph_name, proper, boundary)
            if key in seen:
                continue
            seen.add(key)
            n = graph.number_of_nodes()
            if not connected(n, proper):
                continue
            if not bridgeless(n, proper):
                continue
            yield Candidate(graph_name, n, deleted, proper, boundary)


def inspect(candidate: Candidate):
    relation, raw = ENGINE.exact_relation(candidate.proper, candidate.boundary)
    rainbow_signatures = {sig for sig in relation if rainbow_shape(sig)}
    cap_rows = []
    for index, pairing in enumerate(PAIRINGS):
        cap = cap_edges(candidate.proper, candidate.boundary, pairing)
        is_bridge_free = bridgeless(candidate.order, cap)
        fixed_sigs = {sig for sig in relation if fixed(sig, pairing)}
        cap_rows.append({
            "index": index,
            "bridgeless": is_bridge_free,
            "bf_fixed": bool(fixed_sigs),
            "rainbow": bool(fixed_sigs & rainbow_signatures),
        })
    return raw, relation, rainbow_signatures, tuple(cap_rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--max-order", type=int, default=10,
        help="largest named host order to inspect (default: 10; no high-order census)",
    )
    parser.add_argument(
        "--orbit-representatives", action="store_true",
        help="reduce each named host to one representative per automorphism orbit",
    )
    args = parser.parse_args()
    total = 0
    structurally_valid = 0
    cap_bf_valid = 0
    no_rainbow = []
    by_order = {}
    for candidate in candidates(args.max_order, args.orbit_representatives):
        total += 1
        raw, relation, rainbow_signatures, rows = inspect(candidate)
        structurally = all(row["bridgeless"] for row in rows)
        if not structurally:
            continue
        structurally_valid += 1
        cap_bf = all(row["bf_fixed"] for row in rows)
        if not cap_bf:
            continue
        cap_bf_valid += 1
        rain_count = sum(row["rainbow"] for row in rows)
        by_order.setdefault(candidate.order, {"candidates": 0, "all_caps_bf": 0, "rainbow_counts": []})
        by_order[candidate.order]["candidates"] += 1
        by_order[candidate.order]["all_caps_bf"] += 1
        by_order[candidate.order]["rainbow_counts"].append(rain_count)
        print({
            "graph": candidate.graph_name,
            "order": candidate.order,
            "deleted": candidate.deleted,
            "raw_assignments": raw,
            "relation_orbits": len(relation),
            "rainbow_signature_orbits": len(rainbow_signatures),
            "rainbow_cap_count": rain_count,
            "all_caps_bridgeless": structurally,
        })
        if rain_count == 0:
            no_rainbow.append(candidate)
    print({
        "named_candidates": total,
        "all_caps_bridgeless": structurally_valid,
        "all_caps_bridgeless_and_bf": cap_bf_valid,
        "no_rainbow_candidates": len(no_rainbow),
        "by_order": by_order,
    })
    if no_rainbow:
        print("NO_RAINBOW_REAL_POLE_FOUND")
    else:
        print("NO_NO_RAINBOW_POLE_IN_NAMED_PROBE")


if __name__ == "__main__":
    main()
