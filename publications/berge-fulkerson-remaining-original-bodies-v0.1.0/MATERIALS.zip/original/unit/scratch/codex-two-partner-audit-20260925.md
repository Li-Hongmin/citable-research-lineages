# 两伙伴结论与共同残差判据：独立核查（2026-09-25）

**裁决：GPT Pro 的两伙伴结论成立。** 在完整 graph-induced PM family、完整的 T–T 负支持（包含 T-loop），以及四个 intended projection 与相应 core 的交集均为空的假设下，Note 104 的第三类 leakage 障碍为空；真正剩下的只有负坐标或奇闭分量。定理 3 的共同图判据成立，但其两项列举条件必须补上“强制半边不得被边界掩码禁止”的检查。该遗漏不影响本次半边载荷为 0/1 的固定目标应用。

核查对象为 [Pro 原文 §§2、5](pro-case-xii-2026-09-24.md)、[Note 104](../notes/104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md) 和 [Note 109](../notes/109-perfect-matching-polytope-exchanges-do-not-force-the-shared-witness-intersection.md)；定义直接取自 [Note 093 (3)–(4)、(12)](../notes/093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)，残差约定核对 [Note 078](../notes/078-residual-degree-two-criterion-for-two-triple-completion.md)。以下为独立推导，未采用既有 audit 的结论。

**两伙伴的直接证明。** 设 \(R=K-P\ge0\)，\(P\) 的唯一半边为 \(s_i\)。每个顶点的残差度为 2，四条残差半边各出现一次，故残差恰由两条终端路径和若干闭分量组成。由
\[
3|V|=2|E_{\rm proper}|+5
\]
知 \(|V|\) 为奇数；全部闭分量为偶环，故两条终端路径的顶点数一奇一偶。含 \(k\) 条 proper edges 的路径有 \(k+1\) 个顶点，其端半边颜色满足
\[
c_0\oplus c_1\equiv k+1\pmod2.
\]
因此奇顶点路径的两端异色，偶顶点路径的两端同色。每次交替二染的边界大小均为 \(1+3\)，singleton 必在奇顶点路径的两个端点之一。翻转这一条路径，交换 singleton 端点，保持 \(P\)、\(K\) 和残差总和不变。这证明**恰好两个标签**，并给出两个分解族之间的可逆对应；并非断言只有两个匹配分解。

边界情形不破坏证明：同一 proper edge 的两份拷贝耗尽两端残差度，组成孤立 2-cycle，各色各取一份，所得原边掩码仍为 0/1；两个不同的平行边必须保留不同身份；零条 proper edge 的终端路径有一个顶点，两条半边异色，仍符合公式。偶环换色只改变匹配身份，不产生第三个 singleton 标签。本命题的四条残差半边互异，均无二重半边。

**投影与 Note 104。** \(\mathcal F_i(K;j)\) 是所有实际 \((Q,P_i,P_j)\) 分解对完整 \(P_i\) 掩码的投影，没有固定 \(Q\)、\(P_j\)，也不限于某个指定 colouring 或选定行族。因此上述翻转确实保持投影所保留的同一个 \(P\)，也保持其原有的 agreement-core 资格。

加回实际固定半载荷 \(H\) 后，每个伙伴 \(j\) 产生 BF 类型 \((ij)(t)\)，其中 \(t\in T\)。禁止所有这类 T–T 行后，两伙伴都必须是 \(i\) 在五环 \(S\) 中的邻点，因而恰好穷尽这两个邻点。若它们为 \(j_1,j_2\)，则
\[
\mathcal F_i(K;j_1)=\mathcal F_i(K;j_2)
=\{P\in\mathcal P_i(G):K-P\ge0,\ \text{所有闭残差分量为偶环}\}.
\]
具体得到
\[
\begin{aligned}
\mathcal F_3(K_{23};1)&=\mathcal F_3(K_{23};5),\\
\mathcal F_5(K_{23};2)&=\mathcal F_5(K_{23};3),\\
\mathcal F_1(K_{34};4)&=\mathcal F_1(K_{34};3),\\
\mathcal F_3(K_{34};5)&=\mathcal F_3(K_{34};1).
\end{aligned}
\]
Note 093 (12) 假定的是 intended projection 与相应 core 的**交集为空**，不必假定整个投影为空。于是 Note 104 的十六个 restricted families 中，任何非负且闭分量全偶的候选都会进入对应 intended intersection，立即矛盾。Note 104 (13) 的“唯一 alternate leakage”是空前提下的条件结论，不能作为可实现的第三种失败机制。此项加强不需要 no-all-terminal 或全部 25 个正 S–T cells。

“no TT”的用语需要明确：[Note 091](../notes/091-dependent-two-splice-gate-splits-into-sign-feasibility-and-four-row-sections.md) 区分 T-loop 与非对角 T–T，exact Case XII 两者均禁止。若仅禁止不同 T 状态之间的行，上述推论不能照搬。例如三顶点路径 \(u-v-w\)，半边 \(1,2\) 接 \(u\)，\(5\) 接 \(v\)，\(3,4\) 接 \(w\)。取 \(K=\mathbf1\)、\(P=\{s_2,vw\}\)，其残差两伙伴为 3、4；状态 23 属于 \(T\)。实际 T-half
\[
H=\{s_2,vw\}+\{s_3,uv\}+\{s_1,s_4,s_5\}=\mathbf1
\]
可被加回。此图 triple matching 的缺失对只能是 \(13,14,23,24\)，故没有非对角 T–T 行，却有 T-loop \([23]\)。这是弱化用语的反例，不是 exact Case XII 的反例。

**与 Note 109 的关系。** 终端路径翻转改变剩余两个匹配，特别改变指定 \(W\) 的边界及完整掩码。它保持 \(P,K\)，却不保持 Note 109 的 fixed-\(W\) 截面。该截面的等式
\[
N+P-\tau=K-W-\tau
\]
及其 binary/target-phase 条件不受本结果推翻。消去 Note 104 的空泄漏分支没有构造规定的 opposite witness，也没有证明 synchronized rectangle lemma。Note 109 的局部等式本身亦不能充当该全局命题不可由完整闭包推出的证明。

**定理 3：正确判据及一个遗漏检查。** 对一般非负整数 degree-two loads \(R,R'\)，令 \(B\) 为半边集合，
\[
E_*=\{e:R(e),R'(e)\ge1\},\qquad
F_2=\{e:R(e)=2\ \text{或}\ R'(e)=2\},\qquad Q=F_2\cup\beta.
\]
存在边界恰为 \(\beta\) 的共同匹配 \(W\)，使 \(R-W,R'-W\) 也是实际匹配，当且仅当：

1. \(F_2\cap B\subseteq\beta\)，\(Q\subseteq E_*\)，且 \(Q\) 中不同原边没有公共顶点；
2. 删除 \(Q\) 覆盖的顶点后，保留全部未覆盖顶点（包括孤立点），由 \(E_*\) 的 proper edges 诱导的图每个连通分量均有偶数个顶点。

理由：每个二重原边必须由 \(W\) 使用，其他选择只能在共同正支撑中。删除强制项后，图的最大度不超过 2；路径、环（含平行边 2-cycle）、孤立点的完美匹配存在性恰由顶点数奇偶决定。选出剩余匹配后，两个补载荷非负、二元且每顶点度为 1，故自动是实际 PM。这里检查的是**共同图的顶点数**，也包含奇顶点路径，不只是原残差的奇环。

Pro 已写“forbid the other semiedges”；若这包含显式拒绝 force/forbid 冲突，定理正确。但仅执行随后列出的两项测试会漏判：取 \(C_5\)，每个顶点附一条半边，令 \(R=R'\) 在五条半边上均为 2、在 proper edges 上均为 0，取 \(\beta=\{s_1\}\)。全部强制边均在 \(E_*\)，彼此不冲突，删除后空图满足偶分量条件；但任何共同 \(W\) 必含全部五条半边，故所求交集为空。缺少的正是 \(F_2\cap B\subseteq\beta\)。

本次 \(R=K-\tau\)、\(R'=K'-\tau'\) 的半边载荷仅为 0 或 1，因此该额外检查自动通过，定理 3 可用于这个固定伙伴子问题；它没有保证两个非空 fibre 必相交。

验证仅运行了手工构造的固定掩码检查：两个七顶点例分别检查二重原边、不同平行边及伙伴翻转；上述三顶点例检查零 proper-edge 路径；上述 \(C_5\) 例复现定理 3 的漏项。没有图枚举、广泛搜索或新手稿；未修改 tracked files。
