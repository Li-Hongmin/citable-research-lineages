#!/usr/bin/env python3
"""Disposable audit of canonical Kempe transport on all 41 n=11 branches.

The promoted order-eleven bundle counts arbitrary compatible pentagons in the
five disjointness relations.  This script separately computes the canonical
Kempe transports f_t and their holonomy h.  The two objects must not be
identified: a relation pentagon need not follow the canonical transport at
each step.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parent
BUNDLE = UNIT / "computations/bundles/case-xii-order-11"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


legacy = load("case_xii_legacy_relation_audit", BUNDLE / "case_xii_pentagon_audit.py")
audit = load("case_xii_n11_relation_audit", BUNDLE / "case_xii_n11_geng_audit.py")


def matching_key(matching):
    return tuple(sorted(matching))


def alternating_component(pole, left, complement, start_position):
    _, info, incidence = legacy.incidence(pole)
    allowed = set(left) | set(complement)
    start = f"s{start_position}"
    if start not in left:
        raise AssertionError("transport must start in the left matching")
    component = {start}
    stack = [start]
    while stack:
        edge = stack.pop()
        for vertex in info[edge][0]:
            for other in incidence[vertex]:
                if other in allowed and other not in component:
                    component.add(other)
                    stack.append(other)
    return frozenset(component)


def relation_data(pole):
    matchings, _, edge_position, _ = legacy.enumerate_perfect_matchings(pole)
    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    for position in singleton:
        singleton[position].sort(key=matching_key)

    order = legacy.PENTAGON_ORDER
    relations = []
    for left_position, right_position in zip(order, order[1:] + order[:1]):
        relation = tuple(
            (left, right)
            for left in singleton[left_position]
            for right in singleton[right_position]
            if left.isdisjoint(right)
        )
        relations.append(relation)
    return tuple(matchings), singleton, tuple(relations), edge_position


def transport(pole, pair, t, edge_position):
    order = legacy.PENTAGON_ORDER
    left, right = pair
    all_edges = frozenset(edge for edge, _, _ in pole.edge_data())
    complement = all_edges - left - right

    # The three colour classes left, right, complement must partition all
    # edges and meet every internal vertex once each.
    if not left.isdisjoint(right):
        raise AssertionError("input is not a relation edge")
    _, _, incidence = legacy.incidence(pole)
    for vertex in range(pole.n):
        if sum(edge in complement for edge in incidence[vertex]) != 1:
            raise AssertionError("third colour class is not a perfect matching")

    component = alternating_component(pole, left, complement, order[t])
    left_prime = frozenset((left - component) | (complement & component))
    expected_position = order[(t + 2) % 5]
    if legacy.boundary_set(left_prime, edge_position) != frozenset({expected_position}):
        raise AssertionError("Kempe path has the wrong boundary endpoint")
    if not right.isdisjoint(left_prime):
        raise AssertionError("transport output is not a relation edge")
    return right, left_prime


def cycle_decomposition(permutation, ordered_domain):
    seen = set()
    cycles = []
    for start in ordered_domain:
        if start in seen:
            continue
        cycle = []
        current = start
        while current not in seen:
            seen.add(current)
            cycle.append(current)
            current = permutation[current]
        if current != start:
            raise AssertionError("map is not a permutation")
        cycles.append(tuple(cycle))
    cycles.sort(key=lambda cycle: (len(cycle), tuple(map(str, cycle))))
    return tuple(cycles)


def compatible_pentagon_count(relations):
    # Count anchored relation cycles (x_0,...,x_4), exactly as the promoted
    # audit does.  Each uses one matching at each boundary position.
    next_by_left = []
    for relation in relations:
        adjacency = defaultdict(list)
        for left, right in relation:
            adjacency[left].append(right)
        next_by_left.append(adjacency)

    count = 0
    for first_left, first_right in relations[0]:
        def extend(t, current):
            nonlocal count
            if t == 4:
                count += sum(right == first_left for right in next_by_left[t][current])
                return
            for right in next_by_left[t][current]:
                extend(t + 1, right)

        extend(1, first_right)
    return count


def analyse_branch(pole, graph6, mapping, branch_index):
    matchings, singleton, relations, edge_position = relation_data(pole)
    relation_sizes = tuple(len(relation) for relation in relations)
    if len(set(relation_sizes)) != 1:
        raise AssertionError("canonical transport theorem predicts equal relation sizes")

    matching_ids = {
        matching: f"M{index:02d}"
        for index, matching in enumerate(sorted(matchings, key=matching_key), start=1)
    }

    maps = []
    for t, relation in enumerate(relations):
        step = {pair: transport(pole, pair, t, edge_position) for pair in relation}
        if len(step) != len(relation):
            raise AssertionError("duplicate relation edge")
        if set(step.values()) != set(relations[(t + 1) % 5]):
            raise AssertionError(f"f_{t} is not a bijection")
        maps.append(step)

    holonomy = {}
    for start in relations[0]:
        current = start
        for step in maps:
            current = step[current]
        holonomy[start] = current
    if set(holonomy.values()) != set(relations[0]):
        raise AssertionError("h is not a permutation of E_0")

    cycles = cycle_decomposition(holonomy, relations[0])
    cycle_type = tuple(sorted(len(cycle) for cycle in cycles))
    fixed_points = sum(len(cycle) == 1 for cycle in cycles)
    relation_pentagons = compatible_pentagon_count(relations)

    # Independent cross-check against the original bundle's counting routine.
    old_stats = audit.matching_relation_statistics(legacy, pole)
    if tuple(old_stats["relation_sizes_cyclic"]) != relation_sizes:
        raise AssertionError("relation-size mismatch with promoted audit")
    if old_stats["compatible_pentagons"] != relation_pentagons:
        raise AssertionError("compatible-pentagon mismatch with promoted audit")

    def pair_id(pair):
        return f"{matching_ids[pair[0]]}>{matching_ids[pair[1]]}"

    return {
        "branch_index": branch_index,
        "augmented_graph6": graph6,
        "boundary_position_to_augmented_vertex": {
            str(k): v for k, v in sorted(mapping.items())
        },
        "proper_edges": [list(edge) for edge in pole.proper_edges],
        "singleton_matching_counts_1_to_5": [len(singleton[i]) for i in range(1, 6)],
        "common_relation_size_k": relation_sizes[0],
        "relation_sizes_cyclic": list(relation_sizes),
        "compatible_pentagons": relation_pentagons,
        "h_cycle_type": list(cycle_type),
        "h_fixed_points": fixed_points,
        "h_is_identity": all(holonomy[x] == x for x in holonomy),
        "h_is_involution": all(holonomy[holonomy[x]] == x for x in holonomy),
        "matching_edge_sets": {
            matching_ids[m]: sorted(m) for m in sorted(matchings, key=matching_key)
        },
        "relations": [
            [pair_id(pair) for pair in relation] for relation in relations
        ],
        "canonical_transports": [
            {pair_id(source): pair_id(target) for source, target in step.items()}
            for step in maps
        ],
        "h_cycles": [[pair_id(pair) for pair in cycle] for cycle in cycles],
    }


def run(geng="geng"):
    proc = subprocess.Popen(
        [geng, "-q", "-c", "-d3", "-D5", "12", "19"],
        stdout=subprocess.PIPE,
        text=True,
    )
    if proc.stdout is None:
        raise RuntimeError("cannot read geng output")

    branches = []
    for line in proc.stdout:
        graph6 = line.strip()
        graph = nx.from_graph6_bytes(graph6.encode("ascii"))
        if Counter(dict(graph.degree()).values()) != Counter({3: 11, 5: 1}):
            continue
        apex = next(vertex for vertex, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        neighbours = tuple(graph.neighbors(apex))
        for mapping in audit.boundary_label_representatives(neighbours):
            pole = audit.pole_from_augmented(legacy, graph, apex, mapping)
            if legacy.enumerate_tait_states(pole) != legacy.S_DIAGONALS:
                continue
            branches.append(
                analyse_branch(pole, graph6, mapping, len(branches) + 1)
            )

    returncode = proc.wait()
    if returncode:
        raise RuntimeError(f"geng failed with exit status {returncode}")
    if len(branches) != 41:
        raise AssertionError(f"expected 41 branches, found {len(branches)}")

    joint = Counter(
        (
            b["common_relation_size_k"],
            tuple(b["h_cycle_type"]),
            b["h_fixed_points"],
            b["compatible_pentagons"],
        )
        for b in branches
    )
    by_k = {}
    for k in sorted({b["common_relation_size_k"] for b in branches}):
        selected = [b for b in branches if b["common_relation_size_k"] == k]
        by_k[str(k)] = {
            "branches": len(selected),
            "h_cycle_type_distribution": {
                str(key): value for key, value in sorted(Counter(
                    tuple(b["h_cycle_type"]) for b in selected
                ).items())
            },
            "h_fixed_point_distribution": {
                str(key): value for key, value in sorted(Counter(
                    b["h_fixed_points"] for b in selected
                ).items())
            },
            "compatible_pentagon_distribution": {
                str(key): value for key, value in sorted(Counter(
                    b["compatible_pentagons"] for b in selected
                ).items())
            },
        }

    nontrivial = [b for b in branches if not b["h_is_identity"]]
    witness = min(
        nontrivial,
        key=lambda b: (
            b["common_relation_size_k"],
            b["augmented_graph6"],
            tuple(b["boundary_position_to_augmented_vertex"].values()),
        ),
    )
    return {
        "retained_branches": len(branches),
        "all_transports_verified_bijective": True,
        "all_old_compatible_pentagon_counts_cross_checked": True,
        "fixed_point_equals_compatible_pentagon": all(
            b["h_fixed_points"] == b["compatible_pentagons"] for b in branches
        ),
        "branches_where_fixed_point_count_differs_from_compatible_pentagons": sum(
            b["h_fixed_points"] != b["compatible_pentagons"] for b in branches
        ),
        "by_common_relation_size": by_k,
        "joint_distribution_k_cycle_fixed_compatible": [
            {
                "k": key[0],
                "cycle_type": list(key[1]),
                "fixed_points": key[2],
                "compatible_pentagons": key[3],
                "branches": value,
            }
            for key, value in sorted(joint.items())
        ],
        "minimal_nonidentity_witness": witness,
        "branches": branches,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--geng", default="geng")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    result = run(args.geng)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json:
        args.json.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
