"""Bounded replay: three explicit poles and Note 101's frozen local rows."""
from collections import Counter
from itertools import combinations_with_replacement


def add(*vectors):
    return tuple(map(sum, zip(*vectors)))


def sub(a, *vectors):
    return tuple(x - sum(ys) for x, *ys in zip(a, *vectors))


def perfect_matchings(n, edges):
    incident = [[i for i, e in enumerate(edges) if v in e] for v in range(n)]
    assert all(len(es) == 3 for es in incident)

    def visit(uncovered, chosen):
        if not uncovered:
            yield tuple(int(i in chosen) for i in range(len(edges)))
            return
        v = min(uncovered)
        for i in incident[v]:
            if set(edges[i]) <= uncovered:
                yield from visit(uncovered.difference(edges[i]), chosen | {i})

    out = tuple(visit(set(range(n)), set()))
    assert len(set(out)) == len(out)
    return out


def residual_components(n, edges, r):
    """Copy multiplicities are retained; parallel original edges stay distinct."""
    assert min(r) >= 0
    assert all(sum(r[i] for i, e in enumerate(edges) if v in e) == 2
               for v in range(n))
    remaining, cycles, paths = set(range(n)), [], []
    while remaining:
        seen, frontier = set(), {min(remaining)}
        while frontier:
            v = frontier.pop()
            if v in seen:
                continue
            seen.add(v)
            for i, e in enumerate(edges):
                if r[i] and len(e) == 2 and v in e:
                    frontier.update(set(e) - seen)
        remaining -= seen
        proper = sum(r[i] for i, e in enumerate(edges)
                     if len(e) == 2 and e[0] in seen)
        ends = [j for j, i in enumerate(range(len(edges) - 5, len(edges)), 1)
                for _ in range(r[i]) if edges[i][0] in seen]
        if ends:
            assert len(ends) == 2
            paths.append((tuple(ends), proper))
        else:
            cycles.append(proper)
    return sorted(cycles), paths


def boundary(m):
    return frozenset(i + 1 for i, x in enumerate(m[-5:]) if x)


# Pro's labelled theta pole: u,v,a,b,c,d,e = 0,...,6.
edges = ((0, 2), (2, 1), (0, 3), (3, 4), (4, 1), (0, 5), (5, 6), (6, 1),
         (3,), (5,), (2,), (4,), (6,))
proper_sets = ((2, 4, 6), (3, 5, 7), (0, 4, 6), (1, 2, 6), (5, 7),
               (0, 3, 7), (2, 7), (0, 7), (1, 3, 5), (4, 5), (1, 5),
               (2, 4), (0, 4), (1, 2))
boundaries = ('3', '3', '1', '4', '134', '2', '234', '124', '5', '135',
              '145', '235', '125', '245')
M = [tuple(int(i in ps) for i in range(8)) +
     tuple(int(str(j) in b) for j in range(1, 6))
     for ps, b in zip(proper_sets, boundaries)]
pm = perfect_matchings(7, edges)
assert set(pm) == set(M) and len(pm) == 14
one, two = (1,) * 13, (2,) * 13
S = {frozenset(map(int, p)) for p in ('13', '14', '24', '25', '35')}
support, bf_count = set(), 0
for row in combinations_with_replacement(pm, 6):
    if add(*row) == two:
        bf_count += 1
        states = [frozenset(range(1, 6)) - boundary(m)
                  for m in row if len(boundary(m)) == 3]
        assert len(states) == 2
        support.add(tuple(sorted(tuple(sorted(s)) for s in states)))
types = Counter('S' * sum(frozenset(s) in S for s in state) +
                'T' * sum(frozenset(s) not in S for s in state)
                for state in support)
assert bf_count == 26 and types == {'SS': 9, 'ST': 11, 'TT': 6}
assert not any(len(boundary(m)) == 5 for m in pm)
print('pro_theta: PM=14 BF_rows=26 support_SS=9 ST=11 TT=6 all_terminal_PM=0')

# Check every distinct semiedge-one complementary carrier from three PMs.
pair_sums = {}
for a, b in combinations_with_replacement(pm, 2):
    pair_sums.setdefault(add(a, b), []).append((a, b))
carriers = {sub(two, *h) for h in combinations_with_replacement(pm, 3)
            if sub(two, *h)[-5:] == (1,) * 5 and min(sub(two, *h)) >= 0}
feasible, doubled = 0, 0
for k in carriers:
    for p in pm:
        if len(boundary(p)) != 1:
            continue
        r = sub(k, p)
        if min(r) < 0:
            assert r not in pair_sums
            continue
        cycles, paths = residual_components(7, edges, r)
        assert (r in pair_sums) == all(c % 2 == 0 for c in cycles)
        if r in pair_sums:
            feasible += 1
            partners = {next(iter(boundary(m))) for pair in pair_sums[r]
                        for m in pair if len(boundary(m)) == 1}
            opposite_paths = [set(ends) for ends, length in paths if length % 2 == 0]
            assert len(opposite_paths) == 1 and partners == opposite_paths[0]
            assert len(partners) == 2 and not partners & boundary(p)
            doubled += int(2 in r[:8])
print(f'pro_theta_two_partner: carriers={len(carriers)} feasible_retained_masks={feasible} '
      f'with_doubled_edge={doubled} PASS')

# Full-mask phase failure and the two literal endpoint row equations.
K = sub(two, M[10], M[5], M[1])
Kp = sub(two, M[12], M[1], M[3])
assert K == add(M[0], M[13], M[2]) and Kp == add(M[1], M[13], M[2]) == one
phase = sub(add(M[13], M[0]), M[1])
assert phase[:8] == (0, 1, 2, -1, 1, -1, 1, -1)
assert add(M[11], M[2], M[3], M[10], M[5], M[1]) == two
second = add(M[4], M[5], M[8], M[12], M[1], M[3])
assert second[3] == 3 and second != two
print('pro_literal_rows: row_14_23=True row_25_34=False e3_load=3')
print('pro_phase_vector:', phase[:8])

# A connected cubic five-pole on nine vertices: an odd closed C3 in K-P.
odd_edges = ((0, 1), (1, 2), (2, 0), (3, 4), (4, 5), (6, 7), (7, 8),
             (1, 3), (2, 6), (4, 7), (5, 8), (3,), (5,), (6,), (8,), (0,))
odd_pm = perfect_matchings(9, odd_edges)
odd_p = tuple(int(i in (7, 8, 9, 10, 15)) for i in range(16))
assert odd_p in odd_pm
odd_r = sub((1,) * 16, odd_p)
assert residual_components(9, odd_edges, odd_r)[0] == [3]
assert not any(add(a, b) == odd_r for a, b in combinations_with_replacement(odd_pm, 2))
print('odd_closed_fixture: cycle_lengths=[3] decompositions=0 PASS')

# Two copies of edge 0; edge 1 is a distinct parallel edge with zero load.
double_edges = ((0, 1), (0, 1), (2, 3), (3, 4), (5, 6), (0, 2), (1, 5), (4, 6),
                (2,), (4,), (5,), (6,), (3,))
double_pm = perfect_matchings(7, double_edges)
double_k = (2, 0) + (1,) * 11
double_p = tuple(int(i in (5, 6, 7, 12)) for i in range(13))
assert double_p in double_pm
double_r = sub(double_k, double_p)
assert residual_components(7, double_edges, double_r)[0] == [2]
decomp = [(a, b) for a, b in combinations_with_replacement(double_pm, 2)
          if add(a, b) == double_r]
partners = {next(iter(boundary(m))) for pair in decomp
            for m in pair if len(boundary(m)) == 1}
assert partners == {1, 2} and len(decomp) == 2
assert all(a[0] == b[0] == 1 and a[1] == b[1] == 0 for a, b in decomp)
print('doubled_edge_fixture: cycle_lengths=[2] singleton_partners=[1,2] '
      'each_colour_uses_edge0_once=True parallel_edge1_unused=True')

# Note 101 is a local incidence model, not a graph or a complete PM family.
words = dict(A='21001', B='02010', C='10121', D='00012', P3='10211', P5='11002',
             X='00200', Y='11200', p1_13='21001', p3_13='10211', p2_24='12101',
             p4_24='10021', p2_25='12111', p5_25='11002', q13='12122',
             q14='12212', q24='21212', q25='20221', qp25='21221', q35='22121',
             r23='21122', r34='22102')
rows = [('r23', 'B', 'X', 'q13', 'p1_13', 'p3_13'),
        ('r23', 'B', 'X', 'q14', 'A', 'C'),
        ('r23', 'B', 'X', 'q24', 'p2_24', 'p4_24'),
        ('r23', 'B', 'X', 'q25', 'p2_25', 'p5_25'),
        ('r23', 'B', 'X', 'q35', 'P3', 'P5'),
        ('qp25', 'r34', 'B', 'Y', 'C', 'D')]
assert all(Counter(words[m][v] for m in row) == Counter({'0': 2, '1': 2, '2': 2})
           for row in rows for v in range(5))
assert words['q25'] != words['qp25']
print('note101: six_occurrence_rows=PASS q25_equals_qprime25=False')
for target, h in [('Y', ('r23', 'B', 'X')), ('D', ('r23', 'B', 'X')),
                  ('A', ('r34', 'Y', 'C')), ('X', ('r34', 'Y', 'C'))]:
    bad = [(v + 1, c, 2 - sum(words[m][v] == str(c) for m in (*h, target)))
           for v in range(5) for c in range(3)
           if sum(words[m][v] == str(c) for m in (*h, target)) > 2]
    assert bad
    print(f'note101_R_{target}_negative_local_incidences:', bad)
