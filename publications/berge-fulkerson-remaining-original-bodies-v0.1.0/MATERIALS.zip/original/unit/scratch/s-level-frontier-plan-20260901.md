# S-level frontier plan (2026-09-01)

## Main decision

The only current route with a plausible S-level payoff is a genuine
common-perfect-matching theorem for the remaining cyclically-5-connected
Berge--Fulkerson cases.  The first target is:

\[
\text{exact Case-XII support on one cubic 5-pole}
\Longrightarrow
\text{a D5 four-cell singleton-fibre join}.
\]

A four-cell join gives the forbidden (A=(12345)) cover by the local load
argument.  The theorem must include the Tait-empty branch and use the common
trivalent incidence of actual perfect matchings; support labels, edge loads,
route parity, and abstract relation models are insufficient.

## Four-valued gates

1. **Proof:** combine the D5 theorem with the published case reduction; this
   is the S-level BF result.
2. **Real counterexample:** construct one simple, connected, bridge-free
   cubic 5-pole with exact forbidden support and verify its complete PM
   closure; this is an S-level negative result.
3. **Sharp condition:** prove only UE2/tree-exchange/loop-to-completion
   hypotheses; publish as an A+/S− boundary, not as a BF solution.
4. **Route closure:** if common-incidence exchange cannot supply the missing
   fibre overlap, stop this interface and do not increase the graph order.

## Current evidence

* D5 transfer to disjoint S--S fibres is exact.
* Saturated blockers and minimizing carrier paths are necessary but do not
  synchronize across the five omitted terminals; a real all-ST/no-A pole
  realizes this boundary.
* Omen exact-40/girth-five and Tait-empty pulses ended at round limits.
* Omen exact-​S/no-​A, order 15: 80 SAT rounds; 23 exact-​S candidates,
  all with (A); no exact-​S/no-​A model.
* Abstract countermodels rule out support-only, load-only, and route-only
  proofs.  They are not cubic-pole counterexamples.
* A fresh Omen `K=1` common boundary-pool encoding is UNSAT before CEGAR;
  analytically, an S-loop plus its disjoint S--T cell forces a forbidden
  T-loop.  This closes only the unique-fibre route, not unrestricted fibres.
* The later symbolic-cube `K=3` UNSAT is **not** a D5-join result.  Removing
  every D5 relation/no-join constraint still gives UNSAT at `K=1` and `K=3`
  from a six-cell shared-λ core.  The model assumes one fixed trivalent
  label per boundary class, which real perfect-matching fibres do not share;
  treat that pulse as a model-boundary correction only.
* Barnette CEN/UV and reflected transfer theorems are strong conditional
  results; arbitrary legal (C_4) preservation remains closed at the
  concrete incidence interface, and no novelty claim is made yet.

## Work allocation

* **BF proof leaf:** derive a cross-cell fibre/alternating-cycle Helly or
  rounding theorem from the absence of T-loops and T--T types.
* **BF counterexample leaf:** only test a newly encoded *actual-PM* common-
  incidence condition; a `round_limit` is never treated as UNSAT, and a
  shared-λ/cube UNSAT is not credited to D5.
* **Remaining-case leaf:** attack the five-overlap singleton-fibre join in
  Cases IV/IX/XI separately; do not assume that a Case-XII theorem covers
  them.
* **High-connectivity leaf:** attack the independent gate that every relevant
  5-edge-connected 5-regular multigraph is 1-factorizable; it cannot be
  replaced by a five-pole boundary argument.
* **Barnette leaf:** preserve the exact RR/RJ/JR/JJ criterion; no further
  unconditioned C4 scans.

## Publication gate

Do a targeted literature/newness check only after a general theorem or a
real counterexample exists.  Until then the honest label is: strong finite
and conditional boundaries, but not an S-level resolution.
