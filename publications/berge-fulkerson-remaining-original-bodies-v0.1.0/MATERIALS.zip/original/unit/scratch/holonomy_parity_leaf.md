# Case-XII holonomy：本轮叶子结论

设补五边形的循环次序为
\[
v_0v_1v_2v_3v_4v_0=1,4,2,5,3,1,
\]
并令 \(E_t=R_{v_t v_{t+1}}\)（下标模 5）。假设一个 cubic
5-pole 的全部 Tait lonely states **恰好**是该五边形的五条边。

## 1. 相邻关系之间存在保留公共 matching 的典范双射（真）

取 \((P,Q)\in E_t\)，其中 \(P\in\mathcal P_{v_t}\)、
\(Q\in\mathcal P_{v_{t+1}}\)，并令 \(C\) 是其边补。于是
\(P,Q,C\) 是一个 Tait colouring，且 \(C\) 使用其余三条 semiedges。

考察 \(P\cup C\) 的 alternating path decomposition。从 semiedge
\(v_t\) 出发的分支终止于 \(C\) 的某个边界位置 \(z\)。在这条分支上交换
\(P,C\)，所得 Tait colouring 的 lonely state 是
\(\{v_{t+1},z\}\)。因为全部 lonely states 恰为五边形边，且
\(z\notin\{v_t,v_{t+1}\}\)，只能有
\(z=v_{t+2}\)。因此交换产生
\[
f_t(P,Q)=(Q,P')\in E_{t+1},
\]
而且公共 matching \(Q\) 不变。

交换后 \(P\cup C\) 的底层子图及该 path component 不变；沿同一路径交换回来
就是逆操作。因此 \(f_t:E_t\to E_{t+1}\) 是双射。

## 2. 五个 relation sizes 总相等（真）

由上述双射立即得到
\[
|R_{14}|=|R_{42}|=|R_{25}|=|R_{53}|=|R_{31}|.
\]
这解释了 \(n=11\) 计算中只出现 \((k,k,k,k,k)\)：它不是小阶偶然，
而是任意阶上由 Kempe path 强制的定理。

## 3. \(k=1\) 时 holonomy 必有不动点（真）

若一个（从而每个）\(E_t\) 只有一条边，双射 \(f_t\) 保留相邻两层的公共
matching，故五条唯一关系边必依次拼成
\[
P_{v_0}\sim P_{v_1}\sim P_{v_2}\sim P_{v_3}
\sim P_{v_4}\sim P_{v_0}.
\]
等价地，holonomy
\(h=f_4f_3f_2f_1f_0\) 是单元素集合 \(E_0\) 上的置换，因而固定其唯一元素。

## 4. 其他 parity 叶子的边界

上述论证只给出一个 \(k\) 元集合上的置换 \(h\)。单凭 \(k\) 的奇偶不能推出
固定点：例如三循环作用在 \(k=3\) 上没有固定点；偶数 \(k\) 更无此保证。
所以“关系基数相等”本身只解决 \(k=1\) 分支。下一最小命题应是判定真实
matching-derived \(h\) 是否必为 involution（若是，则奇数 \(k\) 强制固定点），
或至少判定 \(\operatorname{sgn}(h)\) / cycle type 是否受 cubic matching 结构限制。

