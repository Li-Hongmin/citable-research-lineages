# 重叠 (S)-(T) cells 的重复 singleton 槽：量词边界

## 只攻击的命题

固定

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

目标命题是：同一个 simple connected bridge-free cubic 5-pole 的完整
Case-XII support（15 个 (S)-(S) 类型和 25 个 (S)-(T) 类型，且无
(A)、无 (T)-loop、无 (T)-(T)）是否必给一个 D5 四-cell
singleton-fibre join。此页只检验唯一可能从 20 个重叠 (S)-(T) cells
得到的新约束；不做升阶、census 或抽象 load 搜索。

## 重叠 cell 的正确方程

令 (s=\{i,a\}\in S)、(t=\{i,b\}\in T)，其中 (s,t) 只共享
位置 (i)。一个实际六-matching witness 不是把重复位置识别成一个
matching，而是选择

\[
 Q_s,Q_t,\quad P_i^{(0)},P_i^{(1)},P_a,P_b,
\]

并满足逐边的整数方程

\[
 \chi_{Q_s}+\chi_{Q_t}+
 \chi_{P_i^{(0)}}+\chi_{P_i^{(1)}}+
 \chi_{P_a}+\chi_{P_b}=2\mathbf 1. \tag{1}
\]

这里 (P_i^{(0)},P_i^{(1)}in\mathcal P_i) 可以不同；它们只在
semiedge (i) 上必然各出现一次。完整 support 的含义只是每个这样的
六元关系非空。

若错误地把 (P_i^{(0)}=P_i^{(1)})，才会得到「该 PM 的每条边已被
两次、因而与 (P_a,P_b) 及 (Q_s,Q_t) 全部不交」的假矛盾。真实
方程 (1) 允许两个 (i)-槽在 proper alternating cycles 上不同；在只
有一个槽使用某条 proper edge 时，其余四个 matching 仍可补足该边的
负载。

## 为什么该信息不能传到 D5 join

两个同一重叠 cell 的 witnesses 相减，得到

\[
 (\chi_{Q_s'}-\chi_{Q_s})+(\chi_{Q_t'}-\chi_{Q_t})
 +\sum_{r=0}^1(\chi_{P_i^{(r)'}}-\chi_{P_i^{(r)}})
 +(\chi_{P_a'}-\chi_{P_a})+(\chi_{P_b'}-\chi_{P_b})=0. \tag{2}
\]

每个同边界差是 proper even alternating cycles 的并。因而 (2) 只给出
同一个 cell 内的 cycle-absorption；它没有把该 cell 的 (P_i) 槽与另一个
cell 的 (P_i) 槽绑定。对不同重叠 cells 作同样相减，新增的 (Q) 与
singleton 差仍可彼此吸收，未产生公共五元 singleton tuple。

特别地，20 个重叠 cells 不会把 D5 的四元关系

\[
 \widehat\Pi_d\subseteq
 \prod_{r\in U_d}\mathcal P_r
\]

提升为四-cell natural join。D5 transfer 已经把 forbidden (A) 和
(T)-(T) endpoint pairing 用尽；重叠 cells 的重复槽没有剩余的
endpoint toggle 可生成新的 D5 relation。

## 严格四值结论

* **解析证明：** 未得到。方程 (1)--(2) 不推出 D5 join。
* **真实 exact-40 pole 反例：** 未构造。
* **承重附加条件：** 若额外假设重叠 cell 的重复 singleton 槽在
  跨 cell 间可取同一个实际 PM（或满足可验证的 exchange-convex/Helly
  条件），则可再进入已有的 D5 join 引理；该假设不由 support 提供。
* **路线状态：** 在“从重叠 cells 的重复位置方程直接推出跨 cell fibre
  一致性”这一接口上严格关闭。Case-XII 的真正剩余箭头仍是

\[
 \text{无 }T\text{-loop}/T\text{-}T + \text{五个 D5 关系非空}
 \Longrightarrow \text{四-cell singleton-fibre join},
\]

尚未决定。

该结论不改变 Case-XII 猜想真伪，也不声称抽象关系模型可实现为 pole；
它只记录：重叠 cell 的重复槽不能被当作一个已同步的 singleton fibre。

## 复现/核对

本页为逐边方程与量词核对，无随机或外部计算。可用项目已有纯标准库
证书检查实际 witness 槽的独立性：

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-incidence-gate/audit_d5_carriers_20260901.py
```

该命令并非本页命题的完整证明；它只复核同一 pole 上 D5 witnesses
使用 actual PM 的事实。
