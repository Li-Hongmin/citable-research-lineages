#!/usr/bin/env python3
"""Test whether five consecutive canonical Kempe matchings have capacity two.

This is a disposable leaf computation.  It reuses the exact pole generation
and transport implementations already present in the unit, but keeps all new
code under this leaf's own scratch directory.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
from pathlib import Path
import subprocess
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
SHARED_SCRATCH = UNIT / "scratch"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load("cocycle_leaf_n13_base", SHARED_SCRATCH / "case_xii_n13_c10_target.py")
transport_mod = load(
    "cocycle_leaf_transport", SHARED_SCRATCH / "n11_transport_relation_audit.py"
)


def max_multiplicity(matchings):
    counts = Counter(edge for matching in matchings for edge in matching)
    return max(counts.values()), tuple(sorted(edge for edge, n in counts.items() if n >= 3))


def canonical_window(pole, relations, edge_position, start_layer, start_pair):
    """Return P_1,...,P_5 from a relation edge (P_0,P_1)."""
    pair = start_pair
    selected = [pair[1]]
    for offset in range(4):
        layer = (start_layer + offset) % 5
        pair = transport_mod.transport(pole, pair, layer, edge_position)
        expected = set(relations[(layer + 1) % 5])
        assert pair in expected
        selected.append(pair[1])
    return tuple(selected)


def audit_order(n: int):
    command = ["geng", "-q", "-c", "-d3", "-D5", str(n + 1), str((3 * n + 5) // 2)]
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    assert proc.stdout is not None
    counts = Counter()
    first_bad = None
    first_mixed = None
    first_all_bad_orbit = None

    for line in proc.stdout:
        counts["generated"] += 1
        graph = nx.from_graph6_bytes(line.strip().encode())
        if Counter(dict(graph.degree()).values()) != Counter({3: n, 5: 1}):
            continue
        counts["degree_sequence"] += 1
        apex = next(v for v, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        counts["proper_connected"] += 1
        normalized = base.normalized_mapping(graph, apex, n)
        if normalized is None:
            continue
        counts["exact_C5_states"] += 1
        mapping, pole = normalized
        _, _, relations, edge_position = transport_mod.relation_data(pole)

        successor = {}
        for layer, relation in enumerate(relations):
            for pair in relation:
                successor[(layer, pair)] = (
                    (layer + 1) % 5,
                    transport_mod.transport(pole, pair, layer, edge_position),
                )

        unseen = set(successor)
        while unseen:
            start = next(iter(unseen))
            orbit = []
            current = start
            while current not in orbit:
                orbit.append(current)
                unseen.discard(current)
                current = successor[current]
            assert current == start
            counts["transport_orbits"] += 1
            orbit_good = False
            for layer, pair in orbit:
                selected = canonical_window(pole, relations, edge_position, layer, pair)
                maximum, _ = max_multiplicity(selected)
                orbit_good |= maximum <= 2
            if orbit_good:
                counts["orbits_with_good_window"] += 1
            else:
                counts["all_bad_orbits"] += 1
                if first_all_bad_orbit is None:
                    first_all_bad_orbit = {
                        "graph6": line.strip(),
                        "mapping": mapping,
                        "orbit_length": len(orbit),
                        "relation_sizes": [len(r) for r in relations],
                    }

        branch_good = False
        branch_bad = False
        for layer, relation in enumerate(relations):
            for start_pair in relation:
                counts["canonical_windows"] += 1
                selected = canonical_window(pole, relations, edge_position, layer, start_pair)
                maximum, bad_edges = max_multiplicity(selected)
                if maximum <= 2:
                    counts["good_windows"] += 1
                    branch_good = True
                else:
                    counts["bad_windows"] += 1
                    branch_bad = True
                    if first_bad is None:
                        first_bad = {
                            "graph6": line.strip(),
                            "mapping": mapping,
                            "layer": layer,
                            "bad_edges": bad_edges,
                            "relation_sizes": [len(r) for r in relations],
                            "selected": [sorted(m) for m in selected],
                        }
        if branch_good:
            counts["branches_with_good_window"] += 1
        if branch_bad:
            counts["branches_with_bad_window"] += 1
        if branch_good and branch_bad:
            counts["mixed_branches"] += 1
            if first_mixed is None:
                first_mixed = line.strip()

    returncode = proc.wait()
    assert returncode == 0
    return {
        "n": n,
        "counts": dict(counts),
        "first_bad": first_bad,
        "first_mixed_graph6": first_mixed,
        "first_all_bad_orbit": first_all_bad_orbit,
    }


if __name__ == "__main__":
    orders = tuple(int(x) for x in sys.argv[1:]) or (5, 7, 9, 11, 13)
    for order in orders:
        print(audit_order(order))
