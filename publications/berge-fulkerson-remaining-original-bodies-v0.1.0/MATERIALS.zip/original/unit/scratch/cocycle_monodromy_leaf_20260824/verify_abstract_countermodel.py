#!/usr/bin/env python3
"""Verify a C10 Boolean-torsor model with no capacity-two transversal.

The model is intentionally abstract: it satisfies the disjointness, singleton
fibre, canonical transport, and F2 cocycle laws extracted from H-P.  It is not
claimed to be realizable by a cubic 5-pole.
"""

from __future__ import annotations

from itertools import combinations, product


def symdiff(*sets):
    result = set()
    for current in sets:
        result.symmetric_difference_update(current)
    return frozenset(result)


def build_matchings():
    matchings = []
    for k in range(10):
        elements = {"a" if k % 2 == 0 else "b", f"s{k % 5}"}
        for other in range(10):
            if other == k or other % 2 == k % 2:
                continue
            distance = (other - k) % 10
            if distance in (1, 9):
                continue
            elements.add(f"d{min(k, other)}_{max(k, other)}")
        matchings.append(frozenset(elements))
    return tuple(matchings)


def main():
    matching = build_matchings()

    disjoint_pairs = {
        frozenset((i, j))
        for i, j in combinations(range(10), 2)
        if matching[i].isdisjoint(matching[j])
    }
    expected_cycle = {
        frozenset((k, (k + 1) % 10))
        for k in range(10)
    }
    assert disjoint_pairs == expected_cycle

    # Each layer i has N_i and N_{i+5}; enumerate all 2^5 transversals.
    capacity_two = []
    for bits in product((0, 1), repeat=5):
        chosen_indices = tuple(i + 5 * bits[i] for i in range(5))
        chosen = tuple(matching[k] for k in chosen_indices)
        maximum = max(sum(edge in current for current in chosen) for edge in {"a", "b"})
        if maximum <= 2:
            capacity_two.append(chosen_indices)
    assert not capacity_two

    # q_k is the relation-edge coordinate and x_k the H-P switch vector.
    q = tuple(symdiff(matching[k], matching[(k + 1) % 10]) for k in range(10))
    x = tuple(symdiff(matching[k], matching[(k + 2) % 10]) for k in range(10))
    assert all(x[k] == symdiff(q[k], q[(k + 1) % 10]) for k in range(10))
    assert symdiff(*x) == frozenset()
    assert all(
        symdiff(*x[k : k + 5]) == symdiff(q[k], q[(k + 5) % 10])
        for k in range(5)
    )

    print(
        {
            "disjointness_graph": "C10",
            "local_fibre_rank": 0,
            "canonical_holonomy": "bit flip after five steps",
            "transversals_checked": 32,
            "capacity_two_transversals": 0,
            "closed_orbit_cocycle_sum": 0,
        }
    )


if __name__ == "__main__":
    main()
