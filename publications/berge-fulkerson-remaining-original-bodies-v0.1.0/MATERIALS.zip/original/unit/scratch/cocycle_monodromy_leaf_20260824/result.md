# Boolean torsor cocycle and the capacity-two boundary

## Statement

Let \(v_t\) be the cyclic order \(1,4,2,5,3\), extended with period five.
For a canonical transport trajectory write

\[
P_t\in\mathcal P_{v_t},\qquad (P_t,P_{t+1})\in R_{v_tv_{t+1}}.
\]

For \(B=P_{t+1}\), let \(X_t(B)\) be the path component of \(H-B\) whose
boundary semiedges are \(v_t,v_{t+2}\).  Identifying edge sets with their
vectors in \(\mathbb F_2^{E(H)}\), canonical Kempe transport satisfies

\[
P_{t+2}=P_t+X_t(P_{t+1}).
\]

If \(q(P,Q)=P+Q\) on a relation edge, then

\[
X_t(P_{t+1})
=q(P_t,P_{t+1})+q(P_{t+1},P_{t+2}).
\tag{1}
\]

Thus the natural cross-shared-matching path cochain is the coboundary \(dq\).
In particular, after five transports,

\[
\sum_{t=0}^4X_t(P_{t+1})
=P_0+P_1+P_5+P_6,
\tag{2}
\]

and its sum around every closed canonical transport orbit is zero.

## Proof of exactness

For fixed \(B\in\mathcal P_{v_{t+1}}\), the graph \(H-B\) is the union of two
boundary paths and alternating cycles.  The exact \(C_5\)-state condition fixes
one boundary path to have endpoints \(v_t,v_{t+2}\).  Switching the two
colours on this path changes \(P_t\) to \(P_{t+2}\), while all Boolean cycle
coordinates are unchanged.  This proves the first displayed recurrence.
Equation (1) is then

\[
(P_t+P_{t+1})+(P_{t+1}+P_{t+2})=P_t+P_{t+2}=X_t(P_{t+1}).
\]

Summing telescopes to (2), and summing over a closed orbit gives zero.

## Why this does not imply capacity two

The five consecutive matchings \(P_1,\ldots,P_5\) contain one member of every
boundary class.  Four consecutive pairs are disjoint.  Hence an edge can have
multiplicity at least three among them only by lying in

\[
P_1\cap P_3\cap P_5.
\]

Consequently this window is capacity two if and only if that triple
intersection is empty.  But a triple-common edge cancels from both differences
\(P_1+P_3=X_1(P_2)\) and \(P_3+P_5=X_3(P_4)\).  It is invisible to the
Boolean-affine cocycle.

This loss is genuine, not just a gap in the telescoping argument.  Take ten
abstract matching states \(N_k\), \(k\in\mathbb Z/10\), with \(N_k\) in layer
\(k\bmod5\), and make the disjointness graph exactly

\[
N_0N_1\cdots N_9N_0=C_{10}.
\]

Every shared state then has singleton left and right fibres, so \(r(B)=0\), and
canonical transport is \(N_kN_{k+1}\mapsto N_{k+1}N_{k+2}\).  Put a common
element \(a\) in every even \(N_k\), a common element \(b\) in every odd
\(N_k\), include \(s_i\) in both states of layer \(i\), and for each
nonconsecutive opposite-parity pair \(\{k,\ell\}\) add a distinct blocker
\(d_{k\ell}\) to both \(N_k,N_\ell\).  These rules make precisely consecutive
states disjoint.  Each layer contains one even and one odd state.  Any five-layer
transversal therefore chooses five \(a/b\) types, so by pigeonhole at least
three chosen states contain \(a\) or at least three contain \(b\).  No
capacity-two transversal exists.

Nevertheless, with

\[
q_k=N_k+N_{k+1},\qquad X_k=N_k+N_{k+2},
\]

one has \(X_k=q_k+q_{k+1}\), zero cocycle sum around the ten-step orbit, and
fixed-point-free five-step monodromy.  Thus this model satisfies the full
singleton Boolean-fibre and canonical cocycle laws while violating the desired
selection conclusion.

## Exact boundary

The Boolean-torsor/canonical-monodromy axioms alone cannot prove a capacity-two
transversal.  They forget integral multiplicity-three obstructions.  This does
not give a cubic 5-pole counterexample: the abstract \(a/b\) model may fail an
additional graph-realizability constraint.  A successful proof must therefore
use extra structure coupling different transport orbits or a genuinely
integer/positive condition on edge multiplicities, rather than another
telescoping identity in \(\mathbb F_2\).

The disposable verifiers in this directory check the abstract model exactly
and record a finite diagnostic: in the simple, connected, distinct-terminal
class through thirteen vertices, every exact-\(C_5\) pole has a good canonical
window, although bad windows occur from order nine and all-bad individual
transport orbits occur at order thirteen.
