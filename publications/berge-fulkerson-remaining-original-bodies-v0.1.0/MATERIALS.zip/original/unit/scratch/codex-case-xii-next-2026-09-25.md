# 四次 K4 插入与基极存在性（2026-09-25）

在 [SPEC](../SPEC-2026-09-23-case-xii-rectangle.md) 的量词下，未发现
[昨日条件构造](codex-case-xii-rectangle-conditional-countermechanism-2026-09-24.md)
的漏洞：完整 BF 支撑和 [Note 101](../notes/101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md)
六行中的同名复用均可保持。以下独立证明只要求同名为同一匹配；异名之间没有额外的相等约束，尤其不令 \(q_{25}=q'_{25}\)。

用删去 \(01\) 的 \(K_4\) 替换 proper edge \(uv\)，接入 \(u0,v1\)。任一新 PM 使用的接入边数为偶数，故其内部模式恰为
\[
\{u0,v1,23\},\qquad \{02,13\},\qquad \{03,12\}.
\]
第一种投影到含 \(uv\) 的旧 PM，后两种投影到不含它的旧 PM；边界不变。这穷尽了新图的全部 PM。新 BF 行的两条接入边各有负载二，投影后 \(uv\) 也有负载二。反向延拓任一旧 BF 行时，两个含 \(uv\) 的 occurrence 用第一种模式，其余四个分成两对，分别用后两种。因此完整 BF 边界支撑双向相等。

还须让六行同时延拓。称名字集合 balanced，若它与每行恰交于两个名字。端口的 occurrence 集合 \(\sigma\) 必 balanced。若 balanced 集合 \(\tau\) 与 \(\sigma\) 不交，则按名字将 \(\sigma,\tau,(\sigma\cup\tau)^c\) 分别赋予上述三种模式：每行每种模式恰用两次，所有同名 occurrence 一致。新边 \(02,13\) 都有 occurrence 集合 \(\tau\)。

写 \(r=r_{23},s=r_{34},q'=q'_{25}\)，取
\[
\begin{aligned}
U&=\{r,X,Y,D\},\\
W&=\{B,C,p^1_{13},p^2_{24},p^2_{25},P_3\},\\
V&=\{X,A,Y,s,q_{13},q_{24},q_{25},q_{35}\}.
\end{aligned}
\]
它们均 balanced，且 \(U\cap W=V\cap W=\varnothing\)。对任意 balanced 输入 \(\sigma\)，确有 balanced 集合 \(Z\) 避开 \(\sigma\cup U\)。证明如下：设 \(H=\{r,B,X\}\)，第一至第五行分别为 \(H\cup E_{ij}\)，其中各 \(E_{ij}\) 是互不相交的三名字块。令 \(c=|\sigma\cap H|\)，则 \(|\sigma\cap E_{ij}|=2-c\)。在四个 \(E_{ij}\ne E_{14}\) 中各选一个未用名字（若 \(B\notin\sigma\)），或各选两个（若 \(B\in\sigma\)），再加入：

| \(B,C\) 是否在 \(\sigma\) 中 | 加入 \(Z\) |
|---|---|
| 否，否 | \(B,C\) |
| 否，是 | \(B,h,t\) |
| 是，否 | \(C,h,t\) |
| 是，是 | \(q_{14},A,q',s\) |

这里 \(h\in\{q_{14},A\}\setminus\sigma\)，\(t\in\{q',s\}\setminus\sigma\)。中间两行的两项选择分别由第一组行和第六行的二名配额保证；最后一行中 \(c=1\)，且第六行的配额已被 \(B,C\) 用尽。若需在其他块选两个名字，则 \(c\ge1\)，故至少两个可选。由此逐行恰选两个，且全部避开 \(\sigma\cup U\)。

所以四次插入
\[
\sigma\longrightarrow Z\longrightarrow U\longrightarrow W\longrightarrow V
\]
对每个基极都合法。第二次插入的两条 \(U\)-边中保留一条 \(e\)，另一条用于后续插入；最后保留一条 \(V\)-边 \(f\)。全部六行及完整支撑保持，而
\[
(K_{23}-Y)(e)=(K_{23}-D)(e)=-1,\qquad
(K_{34}-A)(f)=(K_{34}-X)(f)=-1.
\]
[Note 104](../notes/104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md)
的每个上下文若满足 [Note 109](../notes/109-perfect-matching-polytope-exchanges-do-not-force-the-shared-witness-intersection.md)
的矩形条件，则 \(K=P+N+L\) 且 \(Q=N+P-T\) 为 PM，从而 \(K-T=Q+L\ge0\)；entry 情形取 \(P=T,Q=N\)。上述四个负坐标遂排除全部十六上下文。新增十六个顶点和二边割不违反 SPEC。

**最小的剩余存在性条件。** 六行资格可严格缩成两行。在一个完整支撑确为 Case XII 的具体五极 \(G\) 中，只须找到完整匹配 \(B\in\mathcal P_2(G),C\in\mathcal P_4(G)\)，使同一个负载有两种指定分解：
\[
\boxed{\quad
2\mathbf1-B-C
=A+X+q_{14}+r_{23}
=Y+D+q'_{25}+r_{34}.
\quad} \tag{*}
\]
各名字的边界沿用 Note 101。必要性显然。充分性：固定第一行的 \(r_{23},B,X\)，其补载荷已有 state \(14\)。任何 \(T\)-state 分解都会产生禁止的 \(T\)--\(T\) 行；而三边着色的双色路径交换使非空、包含于 \(S\) 的 state 集沿 \(S\) 的五环饱和，补出另外四行（即 [Note 055](../notes/055-half-load-column-saturation-and-case-xii-compression.md) 的载荷饱和）。第二个等式就是第六行。

因此下一项真正决定存在性的最小见证，是**一个确切 Case-XII 支撑的具体 \(G\)，以及同一 \(B,C\) 下的两种分解 \((*)\)**。两个边界 cell 各自非空不够，必须比较完整 \(B,C\) masks。若取得这种见证，按 SPEC 完成其全 PM 枚举与支撑认证，即得到基极，四次插入随即给出矩形反例。若要否定存在性，则须证明所有 exact-Case-XII 五极都没有这种共同分解；单图或有限阶的无交不能完成此步。本轮证明了条件构造与两行归约，未解决 \((*)\) 的存在性；未运行枚举，到此停止。
