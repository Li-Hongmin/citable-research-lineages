#!/usr/bin/env python3
"""Exhaust the fixed Note-007 literal rows under the adjacent frozen SPEC."""
from collections import Counter, defaultdict
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
from pathlib import Path
import argparse
import json
import time


def run(input_path, output_path):
    started = time.monotonic()
    spec_path = Path(__file__).with_name("SPEC.md")
    spec = spec_from_file_location("note007", input_path)
    old = module_from_spec(spec)
    spec.loader.exec_module(old)
    old.graph_checks()
    masks = old.enumerate_perfect_matchings()
    covers = old.enumerate_bf_covers(masks)
    assert (len(masks), len(covers)) == (31, 177)
    vectors = [tuple((m >> e) & 1 for e in range(old.N_EDGES)) for m in masks]
    by_vector = {v: i for i, v in enumerate(vectors)}
    by_mask = {m: i for i, m in enumerate(masks)}
    boundaries = [old.boundary_mask(m) for m in masks]
    classes = defaultdict(list)
    for i, b in enumerate(boundaries):
        classes[b].append(i)
    names = ("A", "B", "C", "D", "X", "Y")
    slots = (
        ("q13", "A", "X", "r45", "C", "D"),
        ("q14", "A", "C", "r23", "B", "X"),
        ("q24", "B", "C", "r15", "A", "D"),
        ("q25", "B", "D", "r34", "Y", "C"),
    )
    single_boundary = {"A": 1, "B": 2, "C": 8, "D": 16, "X": 4, "Y": 4}

    def boundary_for(name):
        if name in single_boundary:
            return single_boundary[name]
        i, j = map(int, name[1:])
        return 31 ^ (1 << (i - 1)) ^ (1 << (j - 1))

    def load(ids):
        return tuple(sum(vectors[i][e] for i in ids) for e in range(old.N_EDGES))

    def sep(n, p, desired):
        return not ((masks[desired] & ~masks[p]) & ~masks[n]) and not (
            (masks[p] & ~masks[desired]) & masks[n])

    def residual(n, p, desired):
        value = tuple(a + b - c for a, b, c in zip(vectors[n], vectors[p], vectors[desired]))
        answer = by_vector.get(value)
        assert (answer is not None) == sep(n, p, desired)
        if answer is not None:
            assert boundaries[answer] == boundaries[n]
        return answer

    # Independent of splice targets: decode all four pivot relations from BF covers.
    relations = []
    for row_slots in slots:
        relation = []
        expected = [boundary_for(s) for s in row_slots]
        assert len(set(expected)) == 6
        for cover in covers:
            if Counter(boundaries[i] for i in cover) != Counter(expected):
                continue
            row = {s: next(i for i in cover if boundaries[i] == b)
                   for s, b in zip(row_slots, expected)}
            assert load(row.values()) == (2,) * old.N_EDGES
            relation.append(row)
        relations.append(relation)

    configs = [{}]
    for relation in relations:
        configs = [{**c, **r} for c in configs for r in relation
                   if all(c[k] == r[k] for k in c.keys() & r.keys())]
    configs.sort(key=lambda c: tuple(c[k] for k in names) + tuple(c[k] for k in sorted(c) if k not in names))
    assert len({tuple(sorted(c.items())) for c in configs}) == len(configs)

    # Full carrier products, constructed without reference to desired target identities.
    decompositions = defaultdict(list)
    for i, j in combinations(range(1, 6), 2):
        for q, p, other in product(classes[31 ^ (1 << (i - 1)) ^ (1 << (j - 1))],
                                    classes[1 << (i - 1)], classes[1 << (j - 1)]):
            decompositions[(i, j, load((q, p, other)))].append((q, p, other))

    def families(c):
        result = []
        for family, half, state, literals in (
            ("23", (c["r23"], c["B"], c["X"]), (3, 5), (c["B"], c["X"], c["Y"], c["D"])),
            ("34", (c["r34"], c["Y"], c["C"]), (1, 3), (c["Y"], c["C"], c["A"], c["X"])),
        ):
            k = tuple(2 - x for x in load(half))
            rows = [(q, *half, p, other) for q, p, other in decompositions[(*state, k)]]
            assert all(load(r) == (2,) * old.N_EDGES for r in rows)
            # Reference finals come from all BF covers, not forced residuals.
            finals = []
            q_b = 31 ^ (1 << (state[0] - 1)) ^ (1 << (state[1] - 1))
            r_b = boundaries[half[0]]
            for cover in covers:
                singles = [i for i in cover if boundaries[i].bit_count() == 1]
                triples = [i for i in cover if boundaries[i].bit_count() == 3]
                if Counter(singles) != Counter(literals) or len(triples) != 2:
                    continue
                if Counter(boundaries[i] for i in triples) == Counter((q_b, r_b)):
                    finals.append((next(i for i in triples if boundaries[i] == q_b),
                                   next(i for i in triples if boundaries[i] == r_b), *literals))
            result.append({"family": family, "fixed_half": half, "carrier_load": k,
                           "source_rows": rows, "literal_slots_2_to_5": literals,
                           "reference_final_rows": finals})
        return result

    def component_records(p, desired):
        remaining = set(old.edge_indices(masks[p] ^ masks[desired]))
        assert all(e < old.N_PROPER for e in remaining)
        result = []
        while remaining:
            todo = [min(remaining)]
            part = set()
            while todo:
                e = todo.pop()
                if e in part:
                    continue
                part.add(e)
                uv = set(old.PROPER[e])
                todo.extend(f for f in remaining - part if uv.intersection(old.PROPER[f]))
            remaining -= part
            degrees = Counter(v for e in part for v in old.PROPER[e])
            assert set(degrees.values()) == {2} and len(part) % 2 == 0
            edges = sorted(part)
            result.append({"component_id": "e:" + ",".join(map(str, edges)),
                           "edge_ids": edges,
                           "source_phase": [e for e in edges if masks[p] >> e & 1],
                           "desired_phase": [e for e in edges if masks[desired] >> e & 1]})
        return result

    def chains(f, detailed=False):
        finals = set(f["reference_final_rows"])
        attempts = []
        for row_index, row in enumerate(f["source_rows"]):
            for first, second in ((4, 5), (5, 4)):
                desired = f["literal_slots_2_to_5"][first - 2]
                wanted_second = f["literal_slots_2_to_5"][second - 2]
                for companion in range(6):
                    if companion == first:
                        continue
                    update = residual(row[companion], row[first], desired)
                    record = {"source_row_index": row_index, "endpoint_order": [first, second],
                              "first_companion_slot": companion, "first_residual": update}
                    if update is None:
                        if detailed:
                            attempts.append(record)
                        continue
                    mid = list(row)
                    mid[first], mid[companion] = desired, update
                    assert load(mid) == (2,) * old.N_EDGES
                    second_attempts = []
                    for other_companion in range(6):
                        if other_companion == second:
                            continue
                        update2 = residual(mid[other_companion], mid[second], wanted_second)
                        second_record = {"companion_slot": other_companion, "residual": update2}
                        if update2 is not None:
                            final = mid.copy()
                            final[second], final[other_companion] = wanted_second, update2
                            assert load(final) == (2,) * old.N_EDGES
                            accepted = tuple(final[2:]) == tuple(f["literal_slots_2_to_5"])
                            assert not accepted or tuple(final) in finals
                            second_record.update(final_row=final, literal_slots_preserved=accepted)
                            if accepted and not detailed:
                                return {"family": f["family"], "initial": row, "intermediate": mid,
                                        "final": final, "endpoint_order": [first, second],
                                        "companion_slots": [companion, other_companion]}, None
                        second_attempts.append(second_record)
                    record.update(intermediate_row=mid, second_attempts=second_attempts)
                    if detailed:
                        attempts.append(record)
        return None, attempts

    def diagnostic(fs):
        exported = []
        for f in fs:
            four_projection_parts = []
            endpoint_records = []
            opposite = next(other for other in fs if other is not f)
            active = defaultdict(list)
            for ri, row in enumerate(opposite["source_rows"]):
                for slot, identity in enumerate(row):
                    active[identity].append({"row_index": ri, "slot": slot})
            for endpoint in (4, 5):
                desired = f["literal_slots_2_to_5"][endpoint - 2]
                projected = sorted({r[endpoint] for r in f["source_rows"]})
                g = [p for p in classes[boundaries[desired]]
                     if p == desired or any(sep(n, p, desired) for n in f["fixed_half"])]
                four_projection_parts.append({"endpoint_slot": endpoint, "desired_id": desired,
                    "F": projected, "G": g, "intersection": sorted(set(projected) & set(g))})
                for ri, row in enumerate(f["source_rows"]):
                    p = row[endpoint]
                    components = component_records(p, desired)
                    labels = [{"edge_id": e, "companion_slots": [s for s in range(6)
                               if s != endpoint and masks[row[s]] >> e & 1]}
                              for comp in components for e in comp["desired_phase"]]
                    assert all(len(x["companion_slots"]) == 2 for x in labels)
                    intersection = set(range(6)) - {endpoint}
                    for label in labels:
                        intersection &= set(label["companion_slots"])
                    assert intersection == {s for s in range(6) if s != endpoint and sep(row[s], p, desired)}
                    outputs = []
                    for subset in range(1 << len(components)):
                        flip = sum(1 << e for j, comp in enumerate(components) if subset >> j & 1
                                   for e in comp["edge_ids"])
                        partial = by_mask[masks[p] ^ flip]
                        for companion in range(6):
                            if companion == endpoint:
                                continue
                            out = residual(row[companion], p, partial)
                            if out is not None:
                                outputs.append({"component_subset": subset, "partial_flip_id": partial,
                                    "companion_slot": companion, "residual_id": out,
                                    "opposite_family": opposite["family"],
                                    "opposite_occurrences": active[out]})
                    endpoint_records.append({"source_row_index": ri, "endpoint_slot": endpoint,
                        "source_id": p, "desired_id": desired, "components": components,
                        "desired_phase_labels": labels, "companion_intersection": sorted(intersection),
                        "partial_flip_residuals": outputs})
            _, attempts = chains(f, detailed=True)
            quartet_load = load(f["literal_slots_2_to_5"])
            exported.append({**f, "projections": four_projection_parts,
                "endpoint_components_and_cross_cell_residuals": endpoint_records,
                "all_sequential_attempts": attempts,
                "target_overload_edges": [e for e, x in enumerate(quartet_load) if x > 2],
                "target_quartet_load": quartet_load})
        return exported

    strata = Counter("six_distinct" if c["X"] != c["Y"] else "degenerate" for c in configs)
    output = {"schema_version": 1, "spec_sha256": sha256(spec_path.read_bytes()).hexdigest(),
        "input_verifier_sha256": sha256(input_path.read_bytes()).hexdigest(),
        "scope": "Fixed labelled Note-007 pole; all literal-row configurations; no exact-Case-XII claim",
        "input": {"n": old.N, "proper_edges": old.PROPER, "terminal_vertices": old.TERMINALS},
        "PMs": [{"id": i, "mask": m, "edge_ids": list(old.edge_indices(m)),
                 "boundary": [j + 1 for j in range(5) if boundaries[i] >> j & 1]}
                for i, m in enumerate(masks)],
        "BF_covers": covers, "pivot_slot_names": slots,
        "pivot_relation_sizes": list(map(len, relations)),
        "domain_counts": {"all_literal": len(configs), "six_distinct": strata["six_distinct"],
                          "degenerate": strata["degenerate"]},
        "domain_enumeration_complete": True, "configurations": configs,
        "configurations_checked": 0, "unclassified_configuration_count": len(configs),
        "verdict": "UNKNOWN", "unknown_reason": "empty_literal_configuration_domain" if not configs else None,
        "a_cover_ids": [i for i, c in enumerate(covers) if any(boundaries[m] == 31 for m in c)],
        "witnesses": []}
    assert len(output["a_cover_ids"]) == 6
    for index, c in enumerate(configs):
        fs = families(c)
        witness = next((w for f in fs if (w := chains(f)[0]) is not None), None)
        output["configurations_checked"] += 1
        output["unclassified_configuration_count"] -= 1
        if witness is None:
            output.update(verdict="NO_GO", counterexample={"configuration_index": index,
                          "slot_identities": c, "families": diagnostic(fs)})
            break
        output["witnesses"].append({"configuration_index": index, **witness})
    else:
        if configs:
            output["verdict"] = "FINITE_GO"
    output["elapsed_seconds"] = time.monotonic() - started
    output_path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k: output[k] for k in ("verdict", "domain_counts", "pivot_relation_sizes",
                     "configurations_checked", "unclassified_configuration_count", "elapsed_seconds")}, indent=2))
    if "counterexample" in output:
        print(json.dumps({"counterexample": output["counterexample"]["slot_identities"],
            "families": [{"family": f["family"], "source_count": len(f["source_rows"]),
                          "reference_target_count": len(f["reference_final_rows"]),
                          "overload_edges": f["target_overload_edges"], "projections": f["projections"]}
                         for f in output["counterexample"]["families"]]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_verifier", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        run(args.input_verifier, args.output)
    except Exception as exc:
        args.output.write_text(json.dumps({"verdict": "UNKNOWN", "unknown_reason": repr(exc),
            "domain_enumeration_complete": False, "unclassified_configuration_count": None}, indent=2) + "\n")
        raise
