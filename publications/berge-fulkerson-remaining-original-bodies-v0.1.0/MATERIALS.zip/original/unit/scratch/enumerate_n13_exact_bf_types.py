#!/usr/bin/env python3
"""Enumerate all six-matching BF covers of the explicit n=13 pole."""

from collections import Counter
from itertools import combinations_with_replacement

import verify_n13_c10_independent as pole


def boundary_type(labels):
    counts = [sum(color in label for label in labels) for color in range(6)]
    if sorted(counts) == [1, 1, 1, 1, 1, 5]:
        return ("A",)
    assert sorted(counts) == [1, 1, 1, 1, 3, 3], counts
    triple = [color for color in range(6) if counts[color] == 3]
    misses = [
        tuple(i + 1 for i, label in enumerate(labels) if color not in label)
        for color in triple
    ]
    return tuple(sorted(misses))


def human(kind):
    if kind == ("A",):
        return "(12345)"
    left, right = kind
    if left == right:
        return f"[{left[0]}{left[1]}]"
    return f"({left[0]}{left[1]})({right[0]}{right[1]})"


def compute():
    pole.graph_checks()
    matchings = pole.enumerate_matchings()
    edge_ids = tuple(eid for eid, _, _ in pole.EDGES)
    incidence = [tuple(int(eid in matching) for eid in edge_ids) for matching in matchings]

    covers = 0
    types = Counter()
    first_witness = {}
    tested = 0
    for combo in combinations_with_replacement(range(len(matchings)), 6):
        tested += 1
        totals = [sum(incidence[index][e] for index in combo) for e in range(len(edge_ids))]
        if any(value != 2 for value in totals):
            continue
        covers += 1
        labels = []
        for position in range(1, 6):
            semiedge = f"s{position}"
            labels.append(tuple(color for color, index in enumerate(combo) if semiedge in matchings[index]))
        assert all(len(label) == 2 for label in labels)
        kind = boundary_type(labels)
        types[kind] += 1
        first_witness.setdefault(kind, combo)

    return matchings, tested, covers, types, first_witness


def main():
    matchings, tested, covers, types, first_witness = compute()
    names = sorted(human(kind) for kind in types)
    print({
        "perfect_matchings": len(matchings),
        "multisets_tested": tested,
        "bf_cover_multisets": covers,
        "exact_type_count": len(types),
        "exact_types": names,
        "type_cover_counts": {human(k): types[k] for k in sorted(types, key=human)},
        "contains_12345": ("A",) in types,
    })
    print("FIRST_WITNESSES")
    for kind in sorted(first_witness, key=human):
        print(human(kind), tuple(index + 1 for index in first_witness[kind]))


if __name__ == "__main__":
    main()
