# Common relation size two: complete abstract classification

This scratch note uses only the relation and canonical-switch conclusions proved
in Notes 001--003.  It does not assert that every abstract model below is
realizable by perfect matchings of a cubic 5-pole.

Let `X_t` be the five cyclic matching classes and let

\[
E_t\subseteq X_t\times X_{t+1},\qquad |E_t|=2
\]

(indices modulo five).  Canonical Kempe transport is a bijection

\[
f_t:E_t\longrightarrow E_{t+1}
\]

of the form `f_t(x,y)=(y,z)`.  The reverse colour exchange is the inverse
transport.  Relations are sets, so their two edges are distinct.

## 1. Endpoint skeletons

For a two-edge relation write

- `D` if its two left endpoints and its two right endpoints are both distinct;
- `R` if its two edges share their right endpoint;
- `L` if its two edges share their left endpoint.

The overlap form of `f_t` implies

\[
E_t\text{ is R}\quad\Longleftrightarrow\quad E_{t+1}\text{ is L}.
\]

A relation cannot be both `L` and `R`, since its two edges would then be equal.
Consequently the cyclic set of shared intermediate classes is an independent
set of `C_5`, hence has size `s=0,1`, or `2`.  Up to a dihedral relabelling of
the pentagon, the complete list of endpoint words is

\[
\begin{array}{c|c|c}
s& (E_0,E_1,E_2,E_3,E_4)&\text{number of active matching vertices}\\
\hline
0&DDDDD&10\\
1&RLDDD&9\\
2&RLRLD&8.
\end{array}
\]

There are no further endpoint skeletons.

## 2. Relation cycles and canonical splicings

At a matching vertex incident with one incoming and one outgoing relation edge,
the canonical splice is forced.  At a shared vertex there are two incoming and
two outgoing relation edges; the relation graph permits all continuations,
whereas canonical transport chooses one of the two bijective splicings.

This gives the complete classification.

1. `s=0`: the relation graph is a two-sheeted cover of `C_5`.  It is either
   `C_5 disjoint union C_5`, with two relation 5-cycles, or the connected cover
   `C_10`, with no relation 5-cycle.  Canonical transport is forced, so its
   holonomy is respectively the identity or the transposition of the two edges
   of `E_0`.
2. `s=1`: the graph consists of two 5-cycles sharing the unique shared matching
   vertex.  It always has exactly two relation 5-cycles.  The two canonical
   splicings at the shared vertex give holonomy identity or transposition.
3. `s=2`: the two shared vertices are joined, in each of the two cyclic
   directions, by two lifted paths.  Choosing one path in each direction gives
   exactly `2*2=4` relation 5-cycles.  The two local canonical splicings have
   total even or odd parity, giving holonomy identity or transposition.

Thus canonical fixed-point-free holonomy is compatible with two or four full
relation 5-cycles when `s>0`; it detects the relation cycle only in the
all-distinct case `s=0`.

## 3. Minimal abstract countermodel

The proved local axioms do **not** force a relation 5-cycle.  Let

\[
X_t=\{0_t,1_t\}.
\]

For `t=0,1,2,3` set

\[
E_t=\{(0_t,0_{t+1}),(1_t,1_{t+1})\},
\]

and set

\[
E_4=\{(0_4,1_0),(1_4,0_0)\}.
\]

Define each `f_t` by taking an edge to the unique next edge whose left endpoint
is its right endpoint.  Then every `f_t` is a bijection of the required overlap
form, the backward exchange is its inverse, all five relation sizes are two,
and the holonomy swaps the two edges of `E_0`.  The layered relation graph is
`C_10`, so it has no lifted 5-cycle.

This model is minimal among countermodels: if any matching class is shared then
`s>0` and the classification above supplies a 5-cycle.  Hence every no-cycle
model needs two active vertices in each of the five classes, for ten vertices
and the ten relation edges already forced by `|E_t|=2`.

## 4. Exact missing real-matching condition

For `k=2`, all shared-endpoint cases are already settled positively.  The only
remaining real-matching question is the `DDDDD` case.  What is missing is a
global condition, special to five families of perfect matchings of one common
cubic 5-pole, that forces the product of the five induced two-point
compatibility bijections to be the identity.  Equivalently, it must rule out
the connected double cover `C_10 -> C_5`.

No axiom proved in Notes 001--003 does this: equal relation sizes, the two
forward/backward Kempe exchanges, bijectivity, and endpoint overlap all hold in
the countermodel.  Therefore the next real proof must extract a parity or
incidence invariant from common-edge membership of the underlying perfect
matchings (or else construct a cubic 5-pole realizing this `C_10`, which would
disprove Pentagon-selection in the `k=2` stratum).
