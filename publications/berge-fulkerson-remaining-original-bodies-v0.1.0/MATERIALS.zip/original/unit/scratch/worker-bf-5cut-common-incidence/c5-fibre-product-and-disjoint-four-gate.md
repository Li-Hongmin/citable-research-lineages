# The (C_5) side adds no witness reuse; the remaining gate is a four-of-five join

## Question and decision

Let (G=L\oplus R) be a cyclically 5-edge-connected minimum
Berge--Fulkerson counterexample across a cycle-separating 5-cut, with
(R=C_5).  Use the Case-XII labelling

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

This leaf asks whether the actual perfect matchings on **both** sides of the
cut identify the singleton witnesses used in different Case-XII cells.
They do not: restriction across the cut is a literal fibre product, and the
(C_5) fibre has size one in every supported boundary class.  Moreover, the
five (S)-triple classes that occur in every Case-XII witness do not extend
through (C_5) at all.  Thus the opposite side adds no cross-cell witness
identity beyond the one-pole perfect-matching family of (L).

The exact Case-XII pole problem remains undecided.  The strict new reduction
is that the common-singleton gate may be placed on four **disjoint**
(S\!-!T) cells.  Ordinary support automatically makes each of the four
relations nonempty, so the only missing assertion is a four-way natural
join.  This formulation applies without change to both the exact-(S) and
the Tait-empty branches.

## 1. Perfect-matching fibre product across a cut

For a cubic pole (H) and (B\subseteq[5]), let

\[
 \mathcal M_B(H)=\{M:M\text{ is a perfect matching of }H,
                         \ \partial M=B\}.
\]

Restriction and gluing give a canonical bijection

\[
 \mathcal M(G)
 \cong
 \bigsqcup_{B\subseteq[5]}
 \mathcal M_B(L)\times\mathcal M_B(R).                 \tag{1}
\]

Indeed, the two restrictions of a global perfect matching use the same cut
edges.  Conversely, two pole matchings with the same boundary set glue to a
global perfect matching.  No choice made for one global matching constrains
the choice made for another.

For (R=C_5), with one semiedge at each cycle vertex,

\[
 |\mathcal M_B(R)|=
 \begin{cases}
 1,&B=[5],\\
 1,&|B|=1,\\
 1,&|B|=3\text{ and }[5]\setminus B\in T,\\
 0,&\text{otherwise}.
 \end{cases}                                             \tag{2}
\]

This is immediate after deleting the vertices already covered by
semiedges: the uncovered vertices have a unique matching precisely in the
three cases displayed.  Hence restriction to (L) is a bijection from
global perfect matchings onto the eleven extendable boundary fibres of
(L); the (R)-part is a deterministic tail.

In particular, for every (s\in S), the triple-boundary matching (Q_s)
has boundary ([5]\setminus s) and is absent from (1).  Every one of the
forty Case-XII positive types contains at least one such (Q_s).  Therefore
no Case-XII witness is a six-tuple of global perfect matchings of (G).
The full global matching family cannot, by itself, compare the choices of
(Q_s) or of their companion singleton matchings in two different cells.

The same factorisation holds at the six-matching level.  With labelled
boundary assignments,

\[
 \mathcal C(G)=\mathcal C(L)\cap\mathcal C(C_5).          \tag{3}
\]

The fixed pentagon has exactly

\[
 \mathcal C(C_5)=\{A\}\cup\{(t)(t'):t,t'\in T\},         \tag{4}
\]

sixteen types.  Case XII is the complementary forty pair types, namely all
pairs with at least one endpoint in (S).  Thus disjointness in (3) is
exactly the already known no-cover condition; it is not an additional
equation coupling two different local witnesses.

Whole-graph minimality does not alter (1)--(3).  It supplies a BF cover only
after a specified smaller cubic bridgeless replacement is made.  Such a
cover belongs to a different graph and does not identify two members of a
witness fibre in the fixed pole (L).  The inherited girth, bridge and
terminal-tree 2-cut conditions constrain the graph supporting the fibres,
but do not perform this quantifier exchange.

## 2. Five disjoint cells and their natural relations

There are exactly five disjoint (S\!-!T) cells:

\[
 \mathcal D_5=
 \{(13,45),(14,23),(24,15),(25,34),(35,12)\}.             \tag{5}
\]

For (d=(s,t)\in\mathcal D_5), the union (s\cup t) is a four-subset of
([5]).  Let \(\widehat\Pi_d\) be the relation on the four singleton
matching classes indexed by (s\cup t): a four-tuple lies in
\(\widehat\Pi_d\) when some actual (Q_s,Q_t) complete it to an exact
six-matching double cover.  Because (s\cap t=\varnothing), every singleton
position occurs once.  Consequently

\[
 (s)(t)\text{ is supported}
 \quad\Longleftrightarrow\quad
 \widehat\Pi_d\ne\varnothing.                            \tag{6}
\]

There is no repeated-slot issue in (6).  Extend \(\widehat\Pi_d\) to a
five-variable cylinder \(\Pi_d\) by allowing an arbitrary singleton
matching in the unique missing class.

Any four members of \(\mathcal D_5\) have endpoint unions containing every
three-subset of ([5]).  Indeed, their four missing positions are distinct;
the two-element complement of any three-subset contains at least one of
them.  Conversely, three members fail: the triple of their missing
positions is uncovered.  Thus four is minimal for this direct argument.

Suppose that, for some (d_0\in\mathcal D_5),

\[
 (P_1,\ldots,P_5)
 \in\bigcap_{d\in\mathcal D_5\setminus\{d_0\}}\Pi_d.     \tag{7}
\]

If three of the (P_i) used one edge, a cell among the four would contain
all three positions and its six-matching load would exceed two.  Hence the
five singleton matchings have edge load at most two.  At every cubic vertex
their three incident loads sum to five and are therefore ((2,2,1)).  The
load-one edges form a sixth perfect matching, including all five semiedges,
and give an (A=(12345)) cover with the five (P_i).  Therefore

\[
 \boxed{
 \exists d_0\in\mathcal D_5:\ 
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing
 \quad\Longrightarrow\quad A.}                           \tag{8}
\]

Unlike the earlier four-cell set containing an overlapping pair, every
individual relation in (8) is automatically nonempty under ordinary
Case-XII support.  The missing arrow is purely the cross-cell join.

## 3. Sharpness on frozen real poles

The order-thirteen exact-(S) (C_{10}) pole has all five disjoint cells.
Their projection sizes are

\[
 (12,6,8,8,6),
\]

but all five possible four-way joins in (8) are empty.  Its complete closure
has an (A)-cover by another mechanism and does not have all twenty-five
(S\!-!T) types.  Thus exact-(S) plus the five disjoint cells alone does
not imply (8).

The order-thirteen all-(S\!-!T), no-(A) pole has projection sizes

\[
 (96,110,96,72,125),
\]

and again all five four-way joins are empty.  It has all twenty-five cells
in one real cubic perfect-matching family, but also all (T)-loops and all
(T\!-!T) types.  Hence common cubic incidence plus positive support does
not imply (8); the unused information is precisely the negative support
condition (and, in the Tait-empty insulated example, the whole-graph cut
condition).

These two checks are boundaries, not Case-XII counterexamples.

## 4. Exact remaining proposition

The common-incidence question for both Tait branches is now the following
single, result-neutral statement.

> **Disjoint four-cell join proposition.**  Let (L) be a bridge-free,
> girth-five cubic 5-pole with distinct terminals and only the terminal-tree
> proper 2-cuts allowed by a cyclically 5-edge-connected whole graph.  If
> its complete BF support is exactly the forty Case-XII types, must at least
> one of the five joins in (8) be nonempty?

A positive answer excludes Case XII without assuming that (L) is
3-edge-colourable.  A negative answer realised by one actual pole with exact
support is a genuine Case-XII pole-level counterexample.  The present data
prove neither outcome.

The thinnest bearing step is therefore not another route label, parity
invariant, or larger census.  It is a theorem that the absence of every
(T)-loop and (T\!-!T) completion forces one four-way natural join of
the actual singleton witness fibres, or a real exact-support pole showing
that it does not.

## Verification

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-bf-5cut-common-incidence/verify_c5_fibre_and_disjoint_four_gate.py
```

The script independently checks the eleven singleton (C_5) fibres, its
sixteen BF types, the five minimal disjoint four-cell endpoint covers, and
the frozen real-pole join sizes.  It ends with

```text
C5_FIBRE_AND_DISJOINT_FOUR_GATE_VERIFIED
```

No graph generation, new-order census, route-label parity, or abstract
non-cubic model is used.
