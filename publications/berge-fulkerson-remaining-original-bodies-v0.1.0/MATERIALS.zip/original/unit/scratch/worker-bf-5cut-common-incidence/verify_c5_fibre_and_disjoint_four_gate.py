#!/usr/bin/env python3
"""Verify the deterministic C5 matching fibre and the disjoint four-cell gate.

This is not a graph census.  It enumerates the eleven perfect matchings of
the fixed five-cycle pole, checks its sixteen BF boundary types, proves the
small endpoint-cover assertion for the five disjoint S--T cells, and checks
the resulting four-way joins on two already frozen order-thirteen poles.
"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, combinations_with_replacement
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
EXISTING = (
    ROOT
    / "units/berge-fulkerson/scratch/worker-real-exact-s-no-a"
    / "four_cell_common_singleton_interface.py"
)

S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}
D5 = tuple(sorted((s, t) for s in S for t in T if set(s).isdisjoint(t)))


def c5_matching_patterns():
    """Return all perfect-matching edge sets of C5 with one port per vertex."""
    proper = tuple((f"e{i}", i, (i + 1) % 5) for i in range(5))
    ports = tuple((f"p{i + 1}", i) for i in range(5))
    edges = tuple((name, (u, v)) for name, u, v in proper) + tuple(
        (name, (u,)) for name, u in ports
    )
    answer = []
    for size in range(1, 6):
        for chosen in combinations(edges, size):
            degrees = [0] * 5
            for _, ends in chosen:
                for vertex in ends:
                    degrees[vertex] += 1
            if degrees == [1] * 5:
                answer.append(frozenset(name for name, _ in chosen))
    return tuple(answer)


def boundary_type(patterns):
    boundary_sets = []
    for pattern in patterns:
        boundary_sets.append(
            frozenset(index for index in range(1, 6) if f"p{index}" in pattern)
        )
    sizes = sorted(map(len, boundary_sets))
    if sizes == [1, 1, 1, 1, 1, 5]:
        return ("A",)
    if sizes != [1, 1, 1, 1, 3, 3]:
        raise AssertionError(sizes)
    pairs = [tuple(sorted(set(range(1, 6)) - set(item))) for item in boundary_sets if len(item) == 3]
    return tuple(sorted(pairs))


def c5_bf_support(patterns):
    edges = {f"e{i}" for i in range(5)} | {f"p{i}" for i in range(1, 6)}
    support = set()
    for selected in combinations_with_replacement(range(len(patterns)), 6):
        loads = {edge: 0 for edge in edges}
        for index in selected:
            for edge in patterns[index]:
                loads[edge] += 1
        if set(loads.values()) == {2}:
            support.add(boundary_type(tuple(patterns[index] for index in selected)))
    return frozenset(support)


def verify_c5_fibre():
    patterns = c5_matching_patterns()
    by_boundary = {}
    for pattern in patterns:
        boundary = frozenset(
            index for index in range(1, 6) if f"p{index}" in pattern
        )
        by_boundary.setdefault(boundary, []).append(pattern)

    supported = set(by_boundary)
    expected = {frozenset(range(1, 6))}
    expected.update(frozenset((i,)) for i in range(1, 6))
    cycle_edges = {frozenset((i, i % 5 + 1)) for i in range(1, 6)}
    expected.update(frozenset(set(range(1, 6)) - edge) for edge in cycle_edges)
    assert supported == expected
    assert all(len(fibre) == 1 for fibre in by_boundary.values())

    support = c5_bf_support(patterns)
    expected_types = {("A",)} | set(combinations_with_replacement(sorted(T), 2))
    assert support == expected_types
    return len(patterns), len(support)


def verify_disjoint_endpoint_cover():
    assert len(D5) == 5
    triples = set(combinations(range(1, 6), 3))
    four_covers = []
    for chosen in combinations(D5, 4):
        covered = {
            triple
            for s, t in chosen
            for triple in triples
            if set(triple) <= set(s) | set(t)
        }
        assert covered == triples
        four_covers.append(chosen)
    for chosen in combinations(D5, 3):
        covered = {
            triple
            for s, t in chosen
            for triple in triples
            if set(triple) <= set(s) | set(t)
        }
        assert covered != triples
    return len(four_covers)


def load_existing_interface():
    spec = spec_from_file_location("existing_four_cell", EXISTING)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def frozen_join_boundary():
    module = load_existing_interface()
    records = {}
    for name, edges in (
        ("exact_s_c10", module.loop_interface.C10_EDGES),
        ("all_st_no_a", module.loop_interface.ALL_SS_EDGES),
    ):
        data = module.joint.matching_data(module.loop_interface.pole(edges))
        projections = {cell: module.cell_projection(data, cell) for cell in D5}
        assert all(projections[cell] for cell in D5)
        joins = []
        for chosen in combinations(D5, 4):
            joins.append(len(set.intersection(*(projections[cell] for cell in chosen))))
        assert joins == [0] * 5
        records[name] = {
            "projection_sizes": tuple(len(projections[cell]) for cell in D5),
            "four_way_join_sizes": tuple(joins),
        }
    return records


def main():
    matching_count, type_count = verify_c5_fibre()
    endpoint_covers = verify_disjoint_endpoint_cover()
    records = frozen_join_boundary()
    print(
        {
            "c5_matching_fibres": matching_count,
            "c5_bf_types": type_count,
            "disjoint_cells": D5,
            "minimal_disjoint_four_covers": endpoint_covers,
            "frozen_boundaries": records,
        }
    )
    print("C5_FIBRE_AND_DISJOINT_FOUR_GATE_VERIFIED")


if __name__ == "__main__":
    main()
