# The opposite (C_5) shore does not synchronize the Case-XII columns

## Decision

Let (L) be the non-pentagonal shore in the published Case-XII reduction,
with

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

The half-load column-saturation theorem applies to (L) whether or not
(L) is 3-edge-colourable.  The relevant Kempe switches are performed in
the cubic edge-multiplicity graph of one actual three-matching half, not in
a Tait colouring of (L).  Thus the Tait-empty branch and the exact-(S)
branch reach the same five-saturated-column interface.

Gluing the opposite shore (R=C_5) back in does not strengthen this
interface.  There is an exact perfect-matching fibre-product formula, and
the (C_5) factor is either empty or a singleton in every boundary fibre.
In particular, the (S)-triple matchings which occur in every Case-XII
(S)--(T) witness do not extend to perfect matchings of the whole graph.
The whole-graph perfect-matching family therefore cannot compare the five
carrier columns or identify singleton witnesses used in different columns.

Consequently the route

\[
 \text{column saturation}
 \; + \; R=C_5\text{ fibre product}
 \Longrightarrow \text{D5 singleton join}
\]

is closed.  A Case-XII exclusion still requires a theorem internal to the
common perfect-matching incidence of (L), or a genuinely new minimality
reduction which changes the graph and is BF-lifting.  The opposite shore,
the gluing equations, and Tait-colourability do not supply the missing
quantifier exchange.

## Boundary convention

For a perfect matching (M) of an ordered cubic 5-pole, let

\[
 \partial M\subseteq[5]
\]

be the positions of the semiedges used by (M).  Since the pole has odd
order, (|\partial M|\) is odd.  Write

\[
 \mathcal P_i(H)=\{M:\partial M=\{i\}\},
 \qquad
 \mathcal Q_r(H)=\{M:\partial M=[5]\setminus r\},
\]

and let $\mathcal W(H)$ be the all-five boundary fibre.
The pair label (r=ij) is therefore the pair of terminal positions omitted
by a triple-boundary matching.

Order the boundary vertices of the pentagonal shore so that its five cycle
edges have endpoint pairs (T).  This is exactly the ordering in the
Case-XII Appendix of Máčajová--Mazzuoccolo--Tabarelli.

## The (C_5) perfect-matching fibres

The perfect matchings of (R=C_5) are completely rigid by their boundary:

\[
 |\mathcal M_U(R)|=
 \begin{cases}
 1,&U=\{i\}\text{ for some }i,\\
 1,&U=[5]\setminus t\text{ for some }t\in T,\\
 1,&U=[5],\\
 0,&\text{otherwise}.
 \end{cases}                                      \tag{1}
\]

Indeed, after a singleton semiedge is selected, the four remaining cycle
vertices form a path with its unique perfect matching.  After three
semiedges are selected, the two remaining vertices must be joined by a
cycle edge, which occurs exactly when their omitted pair lies in (T).
Selecting all five semiedges gives the unique final matching.

In particular,

\[
 \mathcal Q_s(R)=\varnothing\quad(s\in S),
 \qquad
 |\mathcal Q_t(R)|=1\quad(t\in T).                 \tag{2}
\]

## Exact whole-graph fibre product

Let (G=L\oplus R) be obtained by joining equally labelled semiedges into
the five cut edges.  Restriction to the two shores gives, for every odd
boundary subset (U\subseteq[5]), a canonical bijection

\[
 \mathcal M_U(G)
 \cong
 \mathcal M_U(L)\times\mathcal M_U(R).             \tag{3}
\]

To prove (3), a perfect matching of (G) uses a cut edge exactly when both
shore restrictions use its corresponding semiedge, so the two restrictions
have the same boundary (U).  Conversely, two shore matchings with the
same boundary glue edge-for-edge to a perfect matching of (G).  These
operations are inverse.

Combining (1) and (3), restriction to (L) is a bijection

\[
 \mathcal M(G)\longrightarrow
 \left(\bigsqcup_{i=1}^5\mathcal P_i(L)\right)
 \sqcup
 \left(\bigsqcup_{t\in T}\mathcal Q_t(L)\right)
 \sqcup \mathcal W(L).                             \tag{4}
\]

The internal choice in a nonempty (L)-fibre is completely free: its
(R)-partner is the single matching prescribed by the boundary.  If
(M,M') have boundaries (U,V), their whole-graph extensions satisfy

\[
 \chi_{\overline M}-\chi_{\overline {M'}}
 = (\chi_M-\chi_{M'})
   \oplus(\chi_{r_U}-\chi_{r_V}),                  \tag{5}
\]

where (r_U,r_V) are the unique pentagonal-shore matchings.  The second
summand depends only on (U,V), never on the selected members of the
(L)-fibres.  Thus alternating cycles through (R) merely close terminal
paths determined by the two boundary sets; they do not equate two internal
matching choices in (L).

Most importantly, (2)--(4) give

\[
 \boxed{\mathcal Q_s(L)\text{ is invisible to }\mathcal M(G)
        \quad(s\in S).}                             \tag{6}
\]

Every Case-XII (S)--(T) witness contains one matching from such an
(S)-triple fibre.  Hence no whole-graph perfect-matching exchange can act
on the complete six-tuple underlying a saturated column.  Its (T)-half
does extend to three whole-graph perfect matchings, but the complementary
(S)-half does not.

## BF colourings also glue only through the boundary type

Six perfect matchings forming a BF colouring of (G) restrict to BF
colourings of (L) and (R) with the same boundary colour assignment and
hence the same type.  Conversely, two shore BF colourings of the same type
can be aligned by a permutation of the six colours and glued.  Therefore

\[
 G\text{ has a BF colouring}
 \quad\Longleftrightarrow\quad
 \mathcal C(L)\cap\mathcal C(R)\ne\varnothing.      \tag{7}
\]

For the pentagonal shore,

\[
 \mathcal C(R)=\{(12345)\}
 \cup\{(t)(t'):t,t'\in T\},                        \tag{8}
\]

including the five (T)-loops.  The exact Case-XII support on (L) is

\[
 \mathcal C(L)=
 \{[s]:s\in S\}
 \cup\{(s)(s'):s,s'\in S\}
 \cup\{(s)(t):s\in S,t\in T\}.                    \tag{9}
\]

The two sets partition the 56 boundary types.  Thus (7) explains the
whole-graph obstruction using only support flags.  It imposes no condition
on which actual matching witness realizes a type in (9).  In particular,
being a BF counterexample does not turn

\[
 \forall(s,t)\ \exists\text{ a witness}
\]

into a common-singleton statement across several cells.

## Why Tait-empty is no longer a separate half-load branch

Take an actual $(s)(t)$ witness of $L$ and split it as

\[
 A=Q_s+P_i+P_j,
 \qquad
 B=R_t+P_k+P_\ell,
 \qquad A+B=2\mathbf1.                              \tag{10}
\]

Replacing each edge $e$ by $A(e)\in\{0,1,2\}$ labelled copies gives a
cubic multigraph $L_A$.  The displayed three actual matchings are already
a proper 3-edge-colouring of $L_A$.  The state set
$\mathcal R(A)$ is the set of boundary states among all such
decompositions of this fixed load.

If $\mathcal R(A)$ contained a state in $T$, combining that decomposition
with the fixed $T$-half in (10) would give a forbidden $T$-loop or
$T$--$T$ BF type.  Hence

\[
 \varnothing\ne\mathcal R(A)\subseteq S.
\]

Bichromatic switches in $L_A$, not in $L$, then give

\[
 \mathcal R(A)=S.                                  \tag{11}
\]

This proves the saturated (S\times\{t\}) column without assuming that
(L) itself has any Tait colouring.  If (L) is Tait-empty, (11) simply
says that the edge-multiplicity graph (L_A) is 3-edge-colourable; it does
not say that (A=\mathbf1).

Thus all genuine Case-XII shores, Tait-empty or not, reduce to five actual
complementary carrier columns.  The remaining D5 implication is exactly the
same in both cases.

There is no hidden quantifier gap in this application.  Exact Case-XII
support supplies an actual witness in every (S)--(T) cell, and the two
forbidden families used in the proof are absent from that same complete
support.  What follows is precisely

\[
 \forall t\in T\quad
 \exists(A_t,B_t)\quad
 A_t+B_t=2\mathbf1,
 \qquad \mathcal R(A_t)=S.                         \tag{12}
\]

What does not follow is a choice of four of these carriers whose
decompositions reuse one common tuple of singleton matchings.  Thus the
remaining gap is cross-column synchronization, not applicability to a
Tait-empty shore.

## Where whole-graph minimality could still enter

The minimum-counterexample hypothesis gives genuine structural information:
(L) is connected, nonacyclic and proper-edge-bridgeless, its terminals are
distinct, the host has girth five, and any proper 2-edge-cut in (L) cuts
off one of the classified terminal trees.  These properties constrain the
graph containing the fibres, but equations (3)--(9) show that they do not
add a second-shore witness identity.

Minimality can re-enter only through a concrete operation: one must produce
a smaller cubic bridgeless graph whose every BF colouring lifts back to
(G).  Without such a BF-lifting reduction, the assertion that (G) is
minimum compares graph orders and does not compare two decompositions of
the same fixed (L).  No fibre-product argument with the unchanged
(C_5) shore performs that reduction.

Accordingly, a positive continuation must prove one of the following new
statements:

1. an internal common-incidence/Helly theorem for the five saturated
   carrier columns of (L); or
2. a BF-lifting whole-graph reduction triggered by the failure of their D5
   join.

The first is precisely the existing cross-column problem.  The second is a
new graph-reduction theorem, not a consequence of (R=C_5), cut gluing, or
Tait-colourability.

## Four-value outcome

* General Case-XII exclusion: **not obtained**.
* Real exact-40 counterexample: **not obtained**.
* Strict theorem: the column-saturation theorem is valid in the Tait-empty
  branch, and the opposite (C_5) shore has the transparent singleton
  fibre product (3)--(6).
* Route closure: the unchanged whole-graph/two-shore gluing supplies no
  cross-column singleton synchronization.  Further work should not split
  off a separate Tait-empty half-load branch or repeat (C_5)-side matching
  exchanges; it must attack common incidence inside (L) or exhibit a new
  BF-lifting reduction.
