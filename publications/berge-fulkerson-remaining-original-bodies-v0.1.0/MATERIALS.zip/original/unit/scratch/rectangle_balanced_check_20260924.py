"""Independent, streaming check of the six row equations and K4 local lifts."""

from collections import Counter
from itertools import combinations, product


ROWS = tuple(map(frozenset, (
    ("r", "B", "X", "q13", "p13_1", "p13_3"),
    ("r", "B", "X", "q14", "A", "C"),
    ("r", "B", "X", "q24", "p24_2", "p24_4"),
    ("r", "B", "X", "q25", "p25_2", "p25_5"),
    ("r", "B", "X", "q35", "P3", "P5"),
    ("qp25", "s", "B", "Y", "C", "D"),
)))
NAMES = frozenset.union(*ROWS)
H = frozenset(("r", "B", "X"))
BLOCKS = tuple(row - H for row in ROWS[:5])
U = frozenset(("r", "X", "Y", "D"))
W = frozenset(("B", "C", "p13_1", "p24_2", "p25_2", "P3"))
V = frozenset(("X", "A", "Y", "s", "q13", "q24", "q25", "q35"))


def balanced(s):
    return s <= NAMES and all(len(s & row) == 2 for row in ROWS)


def balanced_sets(row_index=0, chosen=frozenset(), seen=frozenset()):
    """Decide each name only at its first row; exhaust all row-quota solutions."""
    if row_index == len(ROWS):
        yield chosen
        return
    row = ROWS[row_index]
    needed = 2 - len(chosen & row)
    fresh = sorted(row - seen)
    if 0 <= needed <= len(fresh):
        for extra in combinations(fresh, needed):
            yield from balanced_sets(row_index + 1, chosen | frozenset(extra), seen | row)


def table_bridges(sigma):
    """Exhaust every choice permitted by the draft's four-case construction."""
    b, c = "B" in sigma, "C" in sigma
    if not b and not c:
        extras = [("B", "C")]
    elif b and c:
        extras = [("q14", "A", "qp25", "s")]
    else:
        extras = [("C" if b else "B", h, t)
                  for h in sorted({"q14", "A"} - sigma)
                  for t in sorted({"qp25", "s"} - sigma)]
    choices = [tuple(combinations(sorted(block - sigma), 2 if b else 1))
               for i, block in enumerate(BLOCKS) if i != 1]
    for blocks in product(*choices):
        for extra in extras:
            yield frozenset(extra).union(*blocks)


def gadget_check():
    # Four internal vertices; -1 and -2 are the external ends of the two cut edges.
    edges = ((-1, 0), (-2, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))
    masks = [bits for bits in product((0, 1), repeat=len(edges))
             if all(sum(bit for bit, edge in zip(bits, edges) if v in edge) == 1
                    for v in range(4))]
    assert len(masks) == 3
    assert all(m[0] == m[1] for m in masks)
    assert Counter(m[0] for m in masks) == {0: 2, 1: 1}
    fibers = Counter()
    for row in product(masks, repeat=6):
        if all(sum(m[e] for m in row) == 2 for e in range(len(edges))):
            fibers[tuple(m[0] for m in row)] += 1
    assert len(fibers) == 15 and set(fibers.values()) == {6}
    assert all(sum(status) == 2 for status in fibers)
    return {"local_PM_patterns": len(masks), "ordered_BF_lifts": sum(fibers.values()),
            "old_port_statuses": len(fibers), "lifts_per_status": 6}


def run():
    assert len(NAMES) == 22
    assert all(balanced(s) for s in (U, W, V))
    assert not (U & W or W & V)
    counts, by_common_half, bridge_count = Counter(), Counter(), 0
    for sigma in balanced_sets():
        assert balanced(sigma)
        counts[int("B" in sigma), int("C" in sigma)] += 1
        by_common_half[len(sigma & H)] += 1
        found = 0
        for z in table_bridges(sigma):
            assert balanced(z) and not z & (sigma | U), (sigma, z)
            assert all(balanced(NAMES - (a | b)) and not a & b
                       for a, b in ((sigma, z), (z, U), (U, W), (W, V)))
            found += 1
        assert found, sigma
        bridge_count += found
    residuals = {"Y": 2 - len(U & H) - int("Y" in U),
                 "D": 2 - len(U & H) - int("D" in U),
                 "A": 2 - len(V & {"s", "Y", "C"}) - int("A" in V),
                 "X": 2 - len(V & {"s", "Y", "C"}) - int("X" in V)}
    assert set(residuals.values()) == {-1}
    print("named_variables:", len(NAMES))
    print("balanced_sets:", sum(counts.values()))
    print("counts_(B_in_sigma,C_in_sigma):", dict(sorted(counts.items())))
    print("counts_|sigma_intersect_H|:", dict(sorted(by_common_half.items())))
    print("all_permitted_bridge_choices_checked:", bridge_count)
    print("bridge_failures: 0")
    print("K4:", gadget_check())
    print("four_literal_residuals:", residuals)


if __name__ == "__main__":
    run()
