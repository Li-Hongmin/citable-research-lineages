# Correction: half-load carrier uniqueness is not implied by no T--T support

The attempted implication

\[
\text{no (T)-loop/ (T)--(T)}
\Longrightarrow
\text{a (T)-carrier half-load has a unique decomposition}
\]

is false as stated and must not be used.

If two decompositions of the same half-load are

\[
 B=R_t+P_i+P_j=R_{t'}+P_{i'}+P_{j'},
\]

then adding them gives \(B+B=2B\), not \(2\mathbf 1\).  A forbidden
Berge--Fulkerson cover requires total load \(2\mathbf1\), so the absence of
\(T\)-loop and \(T\)--\(T\) types does not exclude the second decomposition.

The uniqueness argument is valid only under the additional condition
\(B=\mathbf1\) on every edge object (or another hypothesis forcing
\(2B=2\mathbf1\)).  General Case-XII half-loads have entries \(0,1,2\), so
that condition is not available.

Likewise, a proper bichromatic alternating cycle in a decomposition of \(B\)
can be switched to another decomposition of the same \(B\); no forbidden
double cover follows without the missing \(B=\mathbf1\) condition.

Therefore the earlier claims of pairwise-distinct rigid (T)-carriers and
terminal-path-only bichromatic components are withdrawn.  The D5 problem
remains at the previously established cross-column singleton-incidence
interface; the finite symbolic Omen `bounded_unsat` result is independent of
this correction.

The failure is also realized by a genuine order-15 pole, independently
verified by
`worker-proof/verify_exact_s_odd_half_support.py`.  That pole has 47 perfect
matchings, Tait state set (S), and complete support consisting of the 15
(S\)--(S) types plus (A); hence it has no (T)-loop or (T\)--(T) type.
For the same (T)-state (45), the half-load with triple matching

```text
R = id43 = {e5,e6,e8,e10,e11,e18,s1,s2,s3}
```

has two decompositions, using

```text
(P4a,P5a) = (id2,id1),
(P4b,P5b) = (id3,id0).
```

The two singleton pairs differ by the same proper (C_4),

```text
P4a △ P4b = P5a △ P5b = {e12,e13,e14,e18}.
```

This is a real pole-level counterexample to carrier uniqueness, although it
is not a Case-XII pole because it lacks the (S\)--(T) support.  The
abstract common-PM guard model gives the same failure below the cubic
vertex-incidence level.
