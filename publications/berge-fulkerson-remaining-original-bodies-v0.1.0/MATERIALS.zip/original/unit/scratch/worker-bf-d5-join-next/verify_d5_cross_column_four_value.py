#!/usr/bin/env python3
"""Pure-standard-library certificate for the D5 cross-column stop.

This checks only finite endpoint arithmetic and the two conditional join
mechanisms used in the accompanying mathematical note.  It deliberately
does not claim that Case-XII support supplies either mechanism.
"""

from __future__ import annotations

from itertools import combinations, product


TERMINALS = frozenset(range(1, 6))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(((1, 2), (1, 5), (2, 3), (3, 4), (4, 5)))
D5 = (
    ((1, 3), (4, 5)),
    ((1, 4), (2, 3)),
    ((2, 4), (1, 5)),
    ((2, 5), (3, 4)),
    ((3, 5), (1, 2)),
)

TRANSFER = {
    ((1, 3), (4, 5)): ((1, 4), (3, 5)),
    ((1, 4), (2, 3)): ((1, 3), (2, 4)),
    ((2, 4), (1, 5)): ((1, 4), (2, 5)),
    ((2, 5), (3, 4)): ((2, 4), (3, 5)),
    ((3, 5), (1, 2)): ((1, 3), (2, 5)),
}


def canon(pair):
    return tuple(sorted(pair))


def pairings(four):
    four = tuple(sorted(four))
    a = four[0]
    out = []
    for index in range(1, 4):
        b = four[index]
        rest = four[1:index] + four[index + 1 :]
        out.append((canon((a, b)), canon(rest)))
    return tuple(out)


def state(pair):
    pair = canon(pair)
    if pair in S:
        return "S"
    if pair in T:
        return "T"
    raise AssertionError(pair)


def toggled(first, second, endpoint_pair):
    first_new = canon(set(first) ^ set(endpoint_pair))
    second_new = canon(set(second) ^ set(endpoint_pair))
    sizes = sorted((len(first_new), len(second_new)))
    if sizes == [0, 4]:
        return "A"
    if sizes != [2, 2]:
        raise AssertionError((first, second, endpoint_pair))
    return "".join(sorted((state(first_new), state(second_new))))


def pairing_labels(first, second, pairing):
    return tuple(sorted(
        toggled(first, second, endpoint_pair)
        for endpoint_pair in pairing
    ))


def verify_transfer_table():
    for d, partner in TRANSFER.items():
        s, t = d
        assert s in S and t in T and set(s).isdisjoint(t)
        assert partner[0] in S and partner[1] in S
        assert set(partner[0]).isdisjoint(partner[1])
        assert set(s) | set(t) == set(partner[0]) | set(partner[1])

        st_labels = tuple(
            sorted(
                pairing_labels(s, t, pairing)
                for pairing in pairings(set(s) | set(t))
            )
        )
        assert st_labels == (("A", "A"), ("SS", "SS"), ("TT", "TT")), (
            d, st_labels
        )

        ss_labels = tuple(
            sorted(
                pairing_labels(partner[0], partner[1], pairing)
                for pairing in pairings(
                    set(partner[0]) | set(partner[1])
                )
            )
        )
        assert ss_labels == (("A", "A"), ("ST", "ST"), ("TT", "TT")), (
            partner, ss_labels
        )


def verify_scope_cover():
    triples = tuple(combinations(sorted(TERMINALS), 3))
    assert len(D5) == 5
    for triple in triples:
        containing = [
            d for d in D5 if set(triple) <= set(d[0]) | set(d[1])
        ]
        assert len(containing) == 2, (triple, containing)

    for omitted in range(5):
        chosen = [d for index, d in enumerate(D5) if index != omitted]
        assert all(
            any(set(triple) <= set(d[0]) | set(d[1]) for d in chosen)
            for triple in triples
        )
    for omitted in combinations(range(5), 2):
        chosen = [
            d for index, d in enumerate(D5) if index not in omitted
        ]
        assert not all(
            any(set(triple) <= set(d[0]) | set(d[1]) for d in chosen)
            for triple in triples
        )


def verify_load_conclusion():
    profiles = [
        profile
        for profile in product(range(3), repeat=3)
        if sum(profile) == 5
    ]
    assert profiles == [(1, 2, 2), (2, 1, 2), (2, 2, 1)]
    assert [
        (a, b) for a in range(3) for b in range(3) if a + b == 4
    ] == [(2, 2)]


def verify_ue2_and_tree_helly():
    fibres = (frozenset(("p",)), frozenset(("p",)), frozenset(("p",)))
    assert set.intersection(*(set(fibre) for fibre in fibres)) == {"p"}
    assert sum(
        bool(fibres[i] & fibres[j]) for i, j in combinations(range(3), 2)
    ) == 3

    subtrees = (
        frozenset((0, 1, 2)),
        frozenset((1, 2, 3)),
        frozenset((2, 3, 4)),
    )
    assert all(
        subtrees[i] & subtrees[j]
        for i, j in combinations(range(3), 2)
    )
    assert set.intersection(*(set(item) for item in subtrees)) == {2}


def main():
    verify_transfer_table()
    verify_scope_cover()
    verify_load_conclusion()
    verify_ue2_and_tree_helly()
    print({
        "D5": D5,
        "transfer_rows": len(TRANSFER),
        "scope_triples": 10,
        "four_cell_minimality": True,
        "load_profile": "(2,2,1)",
        "UE2_example": True,
        "tree_helly_example": True,
    })
    print("D5_CROSS_COLUMN_FOUR_VALUE_VERIFIED")


if __name__ == "__main__":
    main()
