# D5 cross-column join: four-value closure

## Scope

This leaf attacks one implication only.  Let (H) be a simple connected
cubic (5)-pole, let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and assume that the complete Berge--Fulkerson support of (H) is the
forty positive Case-XII types: the fifteen (S\)--(S) types and the
twenty-five (S\)--(T) types, with no (A=(12345)), no (T)-loop and no
(T\)--(T) type.  The question is whether this forces a common singleton
tuple in four of the five disjoint (S\)--(T) cells.

The conclusion of this leaf is deliberately four-valued:

* a general proof was **not obtained**;
* a real exact-forty/no-(A) pole was **not obtained**;
* two actual-perfect-matching sufficient conditions are stated below;
* the within-column and subtraction routes are **strictly closed**.  The
  remaining statement is the cross-column synchronization arrow.

No order census or new graph generation is used here.

## Exact relations and the already-closed part

The five disjoint cells are

\[
 D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For \(d=(s,t)\in D_5\), put \(U_d=s\cup t\), and let

\[
 \widehat\Pi_d\subseteq \prod_{i\in U_d}\mathcal P_i
\]

be the relation of **actual** singleton perfect matchings occurring in an
exact six-matching cover with triple classes \(s,t\).  Let \(\Pi_d\) be the
five-coordinate cylinder obtained by filling the unique missing terminal
coordinate arbitrarily.

For a disjoint (S\)--(T) witness, the two terminal paths in the symmetric
difference of its triple matchings have three possible endpoint pairings.
The (A,A) and (T,T) pairings are forbidden under the hypotheses, leaving
the unique (S,S) pairing.  Toggling the path in both triple matchings keeps
the four singleton matchings and the edge-load equation unchanged.  The
reverse toggle gives the converse.  Thus, on the same actual PM family,

\[
 \widehat\Pi_{(13,45)}=\widehat\Sigma_{(14,35)},\quad
 \widehat\Pi_{(14,23)}=\widehat\Sigma_{(13,24)},\quad
 \widehat\Pi_{(24,15)}=\widehat\Sigma_{(14,25)},
\]
\[
 \widehat\Pi_{(25,34)}=\widehat\Sigma_{(24,35)},\quad
 \widehat\Pi_{(35,12)}=\widehat\Sigma_{(13,25)},
\]

where (widehat\Sigma) denotes the corresponding disjoint (S\)--(S)
relation.  This is an equality of actual matching relations, not a support
flag or a load relaxation.

Likewise, fixing one complementary half-load (A) in a column and applying
the five-state Kempe closure gives all five (S)-rows of that column.  The
negative (T)-loop/(T\)--(T) assumptions are exactly what exclude a
(T)-state in this closure.  This spends all information available inside a
single carrier column.  It gives no equality between the singleton tuples
belonging to two different carrier loads.

## The exact remaining arrow

For each \(d\in D_5\), every three-subset of the terminal set is contained
in (U_d) for exactly two choices of (d).  Consequently, for every
(J=D_5\setminus\{d_0\}), a tuple in

\[
 \bigcap_{d\in J}\Pi_d                                      \tag{1}
\]

has no proper edge occurring in three singleton matchings.  At each cubic
internal vertex the five singleton incidences are therefore ((2,2,1));
the load-one edges, together with all five semiedges, form a perfect
matching (P_0).  The five singleton matchings and (P_0) give the
forbidden (A)-cover.  Thus the only missing implication is

\[
 \text{five nonempty, saturated actual carrier columns}
 \Longrightarrow
 \text{(1) for at least one }d_0.                     \tag{2}
\]

This is a \(\forall d\,\exists\text{ witness}\Rightarrow
\exists\text{ common singleton tuple}\) exchange.  It is not an endpoint
pairing question anymore.

## Two sharp actual-PM sufficient conditions

The following conditions are sufficient for (1), and are stated at the
matching level so that they can be checked on one pole.

### Pivot UE2

Fix (J), an anchor (a\in J), and (x\in\widehat\Pi_a).  Let (m) be
the terminal omitted by (a).  For (d\in J\setminus\{a\}), define

\[
 E_d(x)=\{P\in\mathcal P_m:
 \text{some }y\in\widehat\Pi_d\text{ agrees with }x
 \text{ on }U_a\cap U_d\text{ and uses }P\text{ at }m\}.
\]

The pivot identity is exact:

\[
 x\text{ extends through all four cells}
 \Longleftrightarrow
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing .       \tag{3}
\]

In particular, if all three fibres are singletons and at least two of the
three pairwise comparisons are agreements (equivalently, the equality graph
on the three values is connected), then (3) holds.  This is the **UE2**
condition.  It is strictly
weaker than a rectangular section of all twenty-five cells.

### Median-exchange Helly

Let (X_m(H)) have vertex set (mathcal P_m), joining two matchings when
their symmetric difference is one proper alternating cycle.  If, for some
((J,a,x)), (X_m(H)) is a median graph, the three fibres (E_d(x)) are
nonempty convex subgraphs, and they intersect pairwise, then they have a
common vertex.  Median graphs have the finite Helly property for convex
subgraphs: the median of one point from each pairwise intersection lies in
all three convex sets.  Equation (3) then gives (1), hence (A).

The tree/subtree criterion is the special case in which (X_m(H)) is a
tree.  Both conditions use only actual PMs and actual alternating cycles;
neither is implied by Case-XII support in the present proof.

## Why the remaining implication is not proved

Subtracting witnesses from two different columns gives only

\[
 (\chi_{Q'_s}-\chi_{Q_s})+(\chi_{Q'_t}-\chi_{Q_t})
 +\sum_i(\chi_{P'_i}-\chi_{P_i})=0.                 \tag{4}
\]

Each same-boundary difference in (4) is a union of proper alternating
cycles.  A changed missing singleton can therefore be absorbed by changes
in the two triple matchings.  Equation (4) does not identify any singleton
PM across columns, and repeating it around the five-cycle supplies no
additional equality.  The twenty overlapping (S\)--(T) cells have two
occurrences of a repeated singleton class, so their analogous equation has
the same cycle-absorption freedom.

The existing common-incidence countermodels below the cubic vertex-incidence
level realize all positive Case-XII flags with empty four-cell joins.  They
show that support, formal exchange, and aggregate edge loads cannot fill
(2); an actual proof must use the common three-valent vertex incidence (or a
new theorem that recovers it).  Conversely, the frozen real poles with empty
joins fail the exact forty hypothesis: one has missing (S\)--(T) support,
the other has extra (T)-loops and (T\)--(T) types.  Thus no real
exact-forty/no-(A) counterexample is available.

## Omen discriminator and stop

The only bounded discriminator with a direct bearing on (2) was the common
PM pool at nominal order (13), with two slots in every singleton/triple
class and all five four-of-five joins forbidden.  Its Omen check returned
`unknown` after 600 seconds, with no model and no bounded UNSAT certificate.
Therefore it changes no mathematical claim; in particular it is not evidence
for either a proof or a counterexample.  The corrected finite-cube/trivalent
relaxation has a bounded (K=3) UNSAT certificate, but it is not a real
perfect-matching family and is only a conditional model-level boundary.

The four-value decision for this leaf is consequently:

| outcome | status |
|---|---|
| general D5 join proof | not obtained |
| real exact-forty/no-(A) pole with all joins empty | not obtained |
| sharp additional condition | pivot UE2; median/tree-exchange Helly |
| route status | closed at within-column/cycle-subtraction level; cross-column implication remains undecided |

No new Omen run, graph census, or order expansion is justified from this
boundary.  The next positive attempt would have to prove UE2/Helly from the
negative (T)-support, while the next negative attempt would have to realize
the complete forty-type support in one genuine cubic pole.

## Existing certificates used for orientation

The endpoint transfer is independently checked by
`worker-bf-d5-join-proof/verify_d5_ss_transfer.py`; the exact pivot identity
and the two frozen real boundaries are checked by
`worker-bf-d5-singleton-gate/audit_d5_pivot_extension_boundary.py`.  The Omen
bounded result is recorded in
`worker-bf-joint-incidence-omen/d5-k2-shared-pm-bounded-unknown-20260902.md`.
