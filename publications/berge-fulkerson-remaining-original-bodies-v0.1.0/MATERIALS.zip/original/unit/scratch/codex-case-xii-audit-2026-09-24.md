# Case XII：双伙伴引理与四残差必要条件的独立核查

2026-09-24。**总体裁决：精确未决缺口（precise unresolved gap）。**
[Pro 文本](pro-case-xii-2026-09-24.md)的 Theorem 1 成立；在 Note 104
明确假设的“四个首投影交集都空”分支中，四种 leakage 确实可以全部排除。
四残差测试是冻结 synchronized rectangle 的有效必要条件，但未证明
exact Case XII 与冻结 occurrence 行能强制其中一个通过，更未证明通过者包含指定的对侧完整 witness。
下面不给出完整 Case XII 结论，也没有真实 exact-Case-XII 反例。

## 1. 双伙伴断言：证明及适用条件

设 \(G\) 为无自环的三价五极图，proper 平行边各自是独立 edge object。

\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]

令 \(K\) 为逐顶点度数三、五条 semiedge 负载均为一的整数负载，
\(P\in\mathcal P_i(G)\) 为真实 singleton PM。假设 \(R=K-P\ge0\)，且其
degree-two copy-multigraph 的每个闭分量都为偶环。则**恰有两个不同于 \(i\)
的 singleton 伙伴类**可以出现于 \(R=W+N\) 的实际 PM 分解中。

证明。\(3|V|=2|E_{\rm pr}|+5\)，故 \(|V|\) 为奇数。
任一 PM \(M\) 满足 \(|V|=2|M_{\rm pr}|+|\partial M|\)，所以边界大小为奇数。
\(R\) 有四个单重 terminal ends，分成两条路径；其余分量为闭环。
对路径和偶闭环交替着色，得到两个度数一的实际 PM。其边界大小为奇数、和为四，
故为 \(1+3\)。把 singleton 色记为 \(W\)，其唯一端点记为 \(j\)。

含 \(j\) 的路径另一端 \(k\) 必属 \(N\)，因而该路径两端异色；另一条路径两端都属 \(N\)，
因而两端同色。两端同色或异色由路径长度决定，不随重新着色而变。
所以 singleton 只能位于第一条路径的 \(j,k\) 两端；交换这条路径上的两色，
在所有伙伴 \(j\) 与伙伴 \(k\) 的分解之间给出互逆双射。该操作保持 \(K,P\) 的完整掩码。

这里有两个不可省略的细节。

- **奇闭分量：**每个闭分量必须单独可二着色。两个奇环不会互相抵消。
  只检查 \(R\ge0\) 或总顶点数的奇偶性不够；有奇闭分量就没有两 PM 分解。
- **重复边：**若一个 proper edge 的负载为二，两份副本已经占满其两个端点的残差度数，
  因而构成孤立二环。两色各取一份，投回原 edge object 后每个 PM 的坐标仍为一。
  它不同于两条不同的平行边；后者也要分别保留坐标。上述 terminal-path 交换不涉及孤立二环。

这是全阶解析证明。完整 PM family 保证构造出的匹配被计入；仅列出选定行的模型不能省掉这个条件。

## 2. 完整无 TT 支持确实排除 leakage

设 \(K=2\mathbf1-H\)，其中 \(H\) 是真实的固定 \(t\in T\) 半行。
上节的每个分解与 \(H,P\) 合起来都是实际 BF 行。
若 singleton 伙伴为 \(j\)，其另一半的状态为 \(ij\)；完整无 TT 支持迫使 \(ij\in S\)。
五环 \(S\) 中每个 \(i\) 恰有两个邻居，因此上述两个伙伴恰好就是这两个邻居。于是完整掩码集合满足

\[
\begin{aligned}
\mathcal F_3(K_{23};1)&=\mathcal F_3(K_{23};5),&
\mathcal F_5(K_{23};2)&=\mathcal F_5(K_{23};3),\\
\mathcal F_1(K_{34};4)&=\mathcal F_1(K_{34};3),&
\mathcal F_3(K_{34};5)&=\mathcal F_3(K_{34};1).
\end{aligned}                                                    \tag{1}
\]

这不是仅有边界支持相等。在 [Note 104](../notes/104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md)
的四个交集都空的假设下，任一 \(P\in\mathcal C_a(\tau)\) 若进入 alternate projection，
同一完整 \(P\) 也进入 intended projection，直接矛盾。因此该分支中只剩

\[
P\not\le K\quad\text{或}\quad K-P\ge0\text{ 且有奇闭分量}.       \tag{2}
\]

Note 104 的第三种 leakage 不能实际发生。这里无需无 all-terminal 条件或全部 25 个 ST 正支持。
但路径交换改变了两个残差匹配，不能保持指定对侧 witness \(W\)，所以没有证明同步矩形。
“四个首投影都失败”只用于这个条件分支，**不是**给 [SPEC](../SPEC-2026-09-23-case-xii-rectangle.md)
主命题补加的假设。

## 3. 对照冻结 occurrence 行后的四残差必要条件

[Note 101](../notes/101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md)
固定的六条行，均要求逐 edge object 的总负载为 \(2\mathbf1\)，是

\[
\begin{aligned}
&(r_{23},B,X,q_{13},p^1_{13},p^3_{13}),\\
&(r_{23},B,X,q_{14},A,C),\\
&(r_{23},B,X,q_{24},p^2_{24},p^4_{24}),\\
&(r_{23},B,X,q_{25},p^2_{25},p^5_{25}),\\
&(r_{23},B,X,q_{35},P_3,P_5),\\
&(q'_{25},r_{34},B,Y,C,D).
\end{aligned}                                                    \tag{3}
\]

相同字母必须是同一完整匹配。特别是最后一行是 **\(q'_{25}\)**；不能把它与饱和列中的
\(q_{25}\) 合并，也不能把 \(p^2_{25},p^5_{25}\) 自动替换成 \(B,D\)。
冻结行给出的准确恒等式是

\[
K_{23}=2\mathbf1-r_{23}-B-X=q_{14}+A+C,\qquad
K_{34}=2\mathbf1-r_{34}-Y-C=q'_{25}+B+D.                         \tag{4}
\]

因此 Pro 的四残差应按以下完整掩码解释：

\[
\begin{array}{c|c|c}
\tau&R_\tau&\text{intended singleton partner}\\\hline
Y&2\mathbf1-r_{23}-B-X-Y=q_{14}+A+C-Y&5\\
D&2\mathbf1-r_{23}-B-X-D=q_{14}+A+C-D&3\\
A&2\mathbf1-r_{34}-Y-C-A=q'_{25}+B+D-A&3\\
X&2\mathbf1-r_{34}-Y-C-X=q'_{25}+B+D-X&1
\end{array}                                                     \tag{5}
\]

若任一 [Note 109](../notes/109-perfect-matching-polytope-exchanges-do-not-force-the-shared-witness-intersection.md)
情境有 \(K=P+N+W\)，且 \(N'=N+P-\tau\in\mathcal P(G)\)，则

\[
R_\tau=K-\tau=W+N'.                                           \tag{6}
\]

entry 情境有 \(P=\tau,N'=N\)，同样适用。两 PM 之和的非重复闭分量是偶交替环，
重复边是二环，故 (6) 强制 \(R_\tau\ge0\) 且所有闭分量为偶环。
结合 (1)，同步矩形必然推出

\[
\begin{gathered}
Y\in\mathcal F_3(K_{23};5)\ \lor\
D\in\mathcal F_5(K_{23};3)\ \lor\\
A\in\mathcal F_1(K_{34};3)\ \lor\
X\in\mathcal F_3(K_{34};1).
\end{gathered}                                                 \tag{7}
\]

在完整无 TT 假设下，(7) 与“(5) 至少一个残差非负且闭分量全偶”等价。
所以 Pro 的四残差**必要**蕴含成立，不需要预先定义哪个对侧 witness 合格，
也不需要假设四个首投影都失败。它不等价于普通 first-splice 成功：使用固定半行中的
companion 做 \(P\to\tau\) 会把 \(K\) 改成 \(K-P+\tau\)，不能证明字面目标进入原 \(K\)。

## 4. 缺失的推理及假设

第一处未决内容是实质性的全图命题。令 \(\mathfrak X\) 为满足完整 exact-Case-XII 支持、
并真实实现 (3) 的冻结数据 \((G,\rho)\)。目前没有证明

\[
\forall(G,\rho)\in\mathfrak X\quad
\exists\tau\in\{Y,D,A,X\}:\quad
R_\tau\ge0\ \text{且每个闭分量为偶环}.                         \tag{8}
\]

Note 101 本身的局部三价模型满足全部六行，却分别在以下局部坐标使四残差为 \(-1\)：

\[
R_Y:(v_5,0),\quad R_D:(v_1,0),\quad
R_A:(v_4,0),\quad R_X:(v_4,0).                                \tag{9}
\]

这只排除了“由行方程和局部三价性直接推出 (8)”的证明；该模型没有 proper-edge pairing，
也没有全图 PM closure，因此 (9) 不是主命题反例。

第二处是完整 witness 的联合可行性。由 [Note 106](../notes/106-common-k-domination-forces-a-full-perfect-matching-completion.md)
的度数论证，对任何真实 \(\tau,W\)，

\[
K-W-\tau\in\mathcal P(G)\quad\Longleftrightarrow\quad
\tau+W\le K.                                                   \tag{10}
\]

非负整数残差在每个顶点的度数为一，所以自动是完整 PM；没有额外的奇环条件。
然而 (8) 只给出某个残差分解，不保证其中有**指定的**对侧 operative witness。
必须补上其完整掩码 fibre 与 (10) 的交集非空性。

此外，“十六情境等价于四个 entry 情境”需要一个明确的**资格保持假设**：
若 \(W\) 在某个非 entry 情境、源 \(P\) 下合格，则把源重置为 \(\tau\)、转入相应 entry 情境后，
同一完整 \(W\) 仍须合格。对侧规则独立于 \(P,a\) 是充分条件；仅有
\(\tau\in\mathcal C_a(\tau)\) 不足。Notes 104/106/108/109 给出状态及完整身份要求，
没有逐情境指定这一 admissibility relation 或证明资格保持。
Pro 对无条件十六到四等价的保留是正确的；其单向必要条件 (6)–(7) 不受此缺定义影响。

## 5. 有界实际校验

[检查器](codex-case-xii-audit-2026-09-24.py)仅使用 Python 标准库。
它从边对象独立递归枚举 Pro 的一个七顶点图的全部 PM，流式检查其
\(\binom{19}{6}=27132\) 个六 occurrence 多重集，并检查两个固定的小残差图。
另逐顶点复核 (3) 的全部冻结局部行；没有图阶搜索或批量图枚举。

Pro 七顶点图的全部 PM 和 BF 支持计数属实，其固定 \(K,W,P\ne\tau\) 的坏 phase 也属实。
但它有 TT 支持，且所给第二条字面行在 \(e_3=bc\) 上负载为三；不能作为
\(\mathfrak X\) 中的样本。这与 Pro 自己声明的有限适用范围一致。

实际运行（退出码 0）：

```text
python3 scratch/codex-case-xii-audit-2026-09-24.py

pro_theta: PM=14 BF_rows=26 support_SS=9 ST=11 TT=6 all_terminal_PM=0
pro_theta_two_partner: carriers=3 feasible_retained_masks=12 with_doubled_edge=4 PASS
pro_literal_rows: row_14_23=True row_25_34=False e3_load=3
pro_phase_vector: (0, 1, 2, -1, 1, -1, 1, -1)
odd_closed_fixture: cycle_lengths=[3] decompositions=0 PASS
doubled_edge_fixture: cycle_lengths=[2] singleton_partners=[1,2] each_colour_uses_edge0_once=True parallel_edge1_unused=True
note101: six_occurrence_rows=PASS q25_equals_qprime25=False
note101_R_Y_negative_local_incidences: [(5, 0, -1)]
note101_R_D_negative_local_incidences: [(1, 0, -1)]
note101_R_A_negative_local_incidences: [(4, 0, -1)]
note101_R_X_negative_local_incidences: [(4, 0, -1)]
```

本轮止于 (8) 和指定对侧完整 witness 的交集条件；解析的双伙伴证明及必要蕴含已经核实，
数值重放不把这一未决边界晋级为一般同步定理。
