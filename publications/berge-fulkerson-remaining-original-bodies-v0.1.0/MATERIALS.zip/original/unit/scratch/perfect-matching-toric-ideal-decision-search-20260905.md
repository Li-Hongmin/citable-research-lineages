# Perfect-matching toric moves do not supply the dependent section

Search date: 2026-09-05.  The decision question was whether a current theorem
on perfect-matching toric ideals converts a six-matching load equality into
the two anchored paired splices required by Note 082.

Mori, Motomura, Ohsugi and Tsuchiya, *Toric ideals of matching polytopes and
edge colorings*, Mathematika (2026), DOI `10.1112/mtk.70099`, Proposition
6.8 identifies a degree bound for the perfect-matching toric ideal with
connectivity of perfect-matching edge-colourings by moves involving at most
that many colour classes.  Combined with their matching-polytope results,
bipartite graphs have degree at most three.  For general graphs, degree at
most four remains Conjecture 1.6.

This does not prove the Case-XII dependent section.  A toric move connects
two decompositions of a load that are already known to exist; exact support
does not provide the literal target decomposition with the required shared
singleton identities.  A degree-three move also need not fix the two anchor
occurrences or preserve their boundary classes, whereas Note 082 requires
two degree-two pair-sum moves with pointwise-fixed anchors.  Finally, the
five-pole is not assumed bipartite, so the proved degree-three bound is not
available in the required generality.

The paper is cached in the ResearchLibrary under
`lib/kentamori2026toric/info.yaml`; the legal arXiv full text is arXiv
`2501.19209`.  No claim from this decision search is promoted to a permanent
mathematical note.
