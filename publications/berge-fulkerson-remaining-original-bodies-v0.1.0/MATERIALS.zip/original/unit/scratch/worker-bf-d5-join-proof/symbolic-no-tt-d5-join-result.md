# Pure relation boundary for the D5 four-way join

## Decision

At the bare fibre/support level, the implication

\[
\text{all 15 S--S and all 25 S--T cells} + \text{no T-loop/TT}
\Longrightarrow
\text{one four-of-five D5 join}
\]

is false.  The certificate below gives a finite relational countermodel.
It is intentionally **not** a perfect-matching incidence system and hence
not a cubic-pole counterexample.  It closes only the route that attempts to
derive the cross-cell join from boundary-type support flags alone.

## Countermodel

Take a two-element singleton fibre

\[
\mathcal P_i=\{0,1\},\qquad i\in[5].
\]

The five disjoint S--T cells are

\[
\mathcal D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For a cell, its relation is a set of assignments on the classes in the
union of its two labels.  Set the five D5 relations to the following
singletons (coordinates are listed in increasing order):

\[
\begin{array}{c|c|c}
d & [5]\setminus\{m(d)\} & \text{unique assignment}\\ \hline
(13,45)&(1,3,4,5)&0000\\
(14,23)&(1,2,3,4)&0000\\
(24,15)&(1,2,4,5)&0000\\
(25,34)&(2,3,4,5)&1000\\
(35,12)&(1,2,3,5)&1000
\end{array}
\]

Here `1000` means value 1 at the first listed coordinate and 0 at the
remaining three.  Give every other S--S or S--T cell the all-zero singleton
relation.  Give every T--T cell, including T-loops, the empty relation.
Thus exactly the 40 Case-XII positive type flags are present:

* five S-loops;
* ten off-diagonal S--S cells;
* twenty-five S--T cells;
* no T-loop and no T--T cell.

## All five D5 joins are empty

Any four D5 domains overlap in three coordinates.  If the omitted cell is
one of the first three, the retained family contains `(25,34)`, which
requires class 2 to have value 1, while at least one of `(13,45)`,
`(14,23)`, `(24,15)` requires class 2 to have value 0.  If `(25,34)` is
the omitted cell, the retained family contains `(35,12)`, which requires
class 1 to have value 1 while each of the first three requires class 1 to
have value 0.  The same class-2 conflict remains when `(35,12)` is omitted.
Consequently

\[
\bigcap_{d\in\mathcal D_5\setminus\{d_0\}}\Pi_d=\varnothing
\qquad(d_0\in\mathcal D_5).
\]

The deterministic verifier is:

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-join-proof/symbolic_no_tt_d5_join_countermodel.py
```

It ends with:

```text
SYMBOLIC_NO_TT_D5_JOIN_COUNTERMODEL_VERIFIED
```

## Exact boundary

To obtain a pole-level theorem one must add a cross-cell condition not
encoded by support flags.  A direct sufficient axiom is the D5 rectangular
section condition

\[
\tag{R_{D5}}
\exists d_0\in\mathcal D_5:
\bigcap_{d\ne d_0}\Pi_d\ne\varnothing.
\]

On an actual cubic 5-pole, the four-cell load lemma then produces the
forbidden `(12345)` cover.  The countermodel shows that no-T-loop/TT alone
does not supply `(R_{D5})`; the missing information is common matching
incidence, witness reuse, or an equivalent Helly/rectangularity theorem.

