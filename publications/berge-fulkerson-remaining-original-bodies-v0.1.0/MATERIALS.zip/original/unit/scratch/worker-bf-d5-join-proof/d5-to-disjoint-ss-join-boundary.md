# D5 cells transfer exactly to the disjoint S--S cells

## Decision

For the Case-XII target let

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\}.
\]

The five disjoint cells are

\[
\mathcal D_5=
\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

I attacked only the proposed implication that the absence of the forbidden
`A` and `T--T` types forces a four-of-five natural join of these cells.  The
new exact reduction is a boundary-pair transfer:

\[
\boxed{
\text{every D5 singleton relation equals a disjoint S--S singleton relation}
}
\]

after the following five-cell identification:

\[
\begin{array}{c|c}
d\in\mathcal D_5&\phi(d)\text{ (disjoint S--S pair)}\\ \hline
(13,45)&(14,35)\\
(14,23)&(13,24)\\
(24,15)&(14,25)\\
(25,34)&(24,35)\\
(35,12)&(13,25)
\end{array}
\tag{1}
\]

The table is a strict consequence of common perfect-matching incidence and
the negative support conditions.  It does **not** prove that any four of the
five relations have a common singleton five-tuple.  It moves that question
to the five disjoint S--S relations, which form the disjointness pentagon on
the five S pair classes.

## Exact path-pairing table

Take a disjoint (d=(s,t)\in\mathcal D_5).  A witness consists of actual
perfect matchings (Q_s,Q_t) in the triple-boundary classes indexed by the
missing pairs (s,t), together with singleton matchings (P_i), one for
each (i\in s\cup t).  The symmetric difference (Q_s\triangle Q_t) has
two terminal-to-terminal path components (and possibly proper even cycle
components).  The four path endpoints are the elements of (s\cup t).  The
two paths give one of the three pairings of those four endpoints.

For a path with endpoint pair (r\), toggling the path in both triple
matchings gives two actual perfect matchings with missing pairs

\[
s'=s\triangle r,\qquad t'=t\triangle r.\tag{2}
\]

The two toggled matchings still have the same total incidence as (Q_s,Q_t):
on the path, the two matchings merely exchange their alternating edges.
Consequently the same singleton matchings (P_i) still complete the pair to
an exact six-matching double cover.  This is a statement about one common
cubic perfect-matching family; no load-only replacement is being made.

The three endpoint pairings have the following complete type table:

\[
\begin{array}{c|ccc}
\text{original pair}&\text{pairing 1}&\text{pairing 2}&\text{pairing 3}\\ \hline
s\in S,\ t\in T,\ s\cap t=\varnothing
&A,A&SS,SS&TT,TT\\
u,v\in S,\ u\cap v=\varnothing
&A,A&ST,ST&TT,TT
\end{array}
\tag{3}
\]

The order of columns depends on the labels; in the first row the middle
column is the unique `SS` pairing, and in the second row it is the unique
`ST` pairing.  The endpoint calculation is exhaustive: a same-side pairing
changes one missing pair from size two to size zero and the other to size
four,
which is type (A); the two cross pairings produce the two displayed
two-pair types.  The symbolic verifier checks all five concrete labels.

## Transfer lemma

Let \(\widehat\Pi_d\) be the relation on the four singleton classes indexed
by (s\cup t): a tuple belongs to it when some actual (Q_s,Q_t) completes
it.  Let \(\widehat\Sigma_{u,v}\) be the analogous relation for a disjoint
pair (u,v\in S).  Both relations use exactly the same four singleton
slots, because

\[
s\cup t=u\cup v.
\]

Assume the pole is a valid side of the whole-graph Case-XII cut.  The
cyclically-5-edge-connected minimum-counterexample interface supplies a
bridge-free cubic side with five distinct terminals; the inherited girth
five condition removes short proper alternating cycles.  These structural
facts ensure that the two path components are genuine terminal paths, but
they do not affect the endpoint table (3).

Now assume the complete BF support has no (A)-type and no (T\)--(T) type.
If a tuple belongs to \(\widehat\Pi_d\), the (A,A) and (TT,TT) pairings in
(3) are impossible: toggling either path would itself produce a forbidden
six-matching cover on the same cubic pole.  Hence the path pairing must be
the unique (SS,SS) pairing.  Toggling either path gives a witness in
\(\widehat\Sigma_{\phi(d)}\) with the identical singleton tuple.  Conversely,
for a witness in \(\widehat\Sigma_{\phi(d)}\), the (A,A) and (TT,TT
pairings are again forbidden, leaving the unique (ST,ST) pairing; toggling
either path gives a witness in \(\widehat\Pi_d\).  Therefore

\[
\boxed{\widehat\Pi_d=\widehat\Sigma_{\phi(d)}}
\qquad(d\in\mathcal D_5).
\tag{4}
\]

The identification extends to the five-variable cylinders \(\Pi_d\) and
\(\Sigma_{\phi(d)}\) by assigning the missing singleton coordinate
arbitrarily.  Thus the desired conclusion is equivalent to

\[
\exists e_0\in E(C_5):
\bigcap_{e\ne e_0}\Sigma_e\ne\varnothing,
\tag{5}
\]

where (E(C_5)) is the disjointness pentagon on (S).  The transfer does
not collapse the quantifiers or establish (5).

## Why the remaining join is not proved

The no-(A)/no-(TT) assumption controls the endpoint pairing of each
individual witness.  It does not identify singleton choices made by two
different witness pairs.  A pole can have different (Q_u) and different
singleton fibres in two S--S witnesses; alternating-cycle exchange changes
the pair while allowing singleton incidence to absorb the difference.
The whole-graph conditions (girth five, bridge-freeness, and the classified
terminal-tree proper 2-cuts) do not supply a Helly or rectangularity theorem
for these singleton fibres.  They constrain the host graph, not the
quantifier exchange between separate six-matching decompositions.

Accordingly, the exact remaining arrow is

\[
\boxed{
\text{common cubic PM incidence}+\text{no }A/TT+\text{whole-graph cuts/girth}
\ \Longrightarrow\ ?\ \text{four-of-five join of the five disjoint S--S fibres}.
}
\]

No proof or actual 40-type pole is obtained in this pulse.  This is a
strictly thinner interface than the original D5 question, not a Case-XII
exclusion.  A sufficient extra hypothesis would be any genuine
cross-cell singleton-fibre transport/Helly theorem that gives (5); once (5)
holds, the existing load argument gives the forbidden (A=(12345)) cover.

For orientation, a separate two-element **pure relation** model realizes all
positive S--S/S--T flags and empty T-loop/T--T flags while making all five
four-of-five joins empty.  It is deliberately not a cubic pole (nor a common
perfect-matching incidence system), so it cannot settle the pole proposition;
it only certifies that support flags alone cannot fill the remaining arrow.
Its self-contained certificate is
`symbolic_no_tt_d5_join_countermodel.py`, ending in
`SYMBOLIC_NO_TT_D5_JOIN_COUNTERMODEL_VERIFIED`.

## Verification

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-join-proof/verify_d5_ss_transfer.py
```

The verifier ends with

```text
D5_SS_TRANSFER_TABLE_VERIFIED
```

It uses only finite endpoint-set arithmetic and does not perform a graph
census.
