#!/usr/bin/env python3
"""Verify the Case-XII D5 -> disjoint S--S transfer table.

This is a symbolic boundary calculation only.  It does not generate poles or
enumerate perfect matchings.  It checks the three endpoint pairings for each
of the five disjoint S--T cells and for the corresponding disjoint S--S
cells.  The result is the exact type-level part of the common-incidence
argument: in a pole with no A and no T--T support, a witness in one D5 cell
has the same singleton tuple as a witness in one disjoint S--S cell, and
conversely.  The five-way/four-way natural join is not proved here.
"""

from __future__ import annotations

from itertools import combinations


POSITIONS = frozenset(range(1, 6))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(((1, 2), (1, 5), (2, 3), (3, 4), (4, 5)))


def canon(pair):
    return tuple(sorted(pair))


def pairings(four):
    """Return the three unordered pairings of a four-element set."""
    four = tuple(sorted(four))
    a = four[0]
    result = []
    for index in range(1, 4):
        b = four[index]
        rest = four[1:index] + four[index + 1 :]
        c, d = rest
        result.append((canon((a, b)), canon((c, d))))
    return tuple(result)


def outcome(first, second, path):
    """Classify the boundary type after toggling one path.

    ``first`` and ``second`` are the missing pairs of the two triple-boundary
    matchings.  Toggling a path with terminal endpoints ``path`` replaces
    each missing pair by symmetric difference with that endpoint pair.
    """
    first_new = canon(set(first) ^ set(path))
    second_new = canon(set(second) ^ set(path))
    sizes = sorted((len(first_new), len(second_new)))
    if sizes == [0, 4]:
        return "A", (first_new, second_new)
    if sizes != [2, 2]:
        raise AssertionError((first, second, path, first_new, second_new))
    if first_new in S and second_new in S:
        return "SS", (first_new, second_new)
    if first_new in T and second_new in T:
        return "TT", (first_new, second_new)
    if (first_new in S and second_new in T) or (
        first_new in T and second_new in S
    ):
        return "ST", (first_new, second_new)
    raise AssertionError((first, second, path, first_new, second_new))


def pairing_record(first, second):
    records = []
    for pairing in pairings(set(first) | set(second)):
        records.append(
            (pairing, tuple(outcome(first, second, path)[0] for path in pairing))
        )
    return tuple(records)


def safe_ss_partner(st_cell):
    """Return the unique disjoint S--S cell produced by the SS pairing."""
    first, second = st_cell
    records = pairing_record(first, second)
    safe = [
        (pairing, tuple(outcome(first, second, path)[1] for path in pairing))
        for pairing, labels in records
        if labels == ("SS", "SS")
    ]
    assert len(safe) == 1, (st_cell, records)
    # The two path components only exchange the two new triple classes, so
    # their ordered outcomes are reversals of one another.
    first_labels, second_labels = safe[0][1]
    assert set(first_labels) == set(second_labels)
    labels = tuple(sorted(first_labels))
    assert all(label in S for label in labels)
    assert set(labels[0]).isdisjoint(labels[1])
    return labels


def main():
    d5 = tuple(
        sorted((s, t) for s in S for t in T if set(s).isdisjoint(t))
    )
    expected_d5 = (
        ((1, 3), (4, 5)),
        ((1, 4), (2, 3)),
        ((2, 4), (1, 5)),
        ((2, 5), (3, 4)),
        ((3, 5), (1, 2)),
    )
    assert d5 == expected_d5, d5

    transfer = tuple((cell, safe_ss_partner(cell)) for cell in d5)
    expected_transfer = (
        (((1, 3), (4, 5)), ((1, 4), (3, 5))),
        (((1, 4), (2, 3)), ((1, 3), (2, 4))),
        (((2, 4), (1, 5)), ((1, 4), (2, 5))),
        (((2, 5), (3, 4)), ((2, 4), (3, 5))),
        (((3, 5), (1, 2)), ((1, 3), (2, 5))),
    )
    assert transfer == expected_transfer, transfer

    # For an S--T disjoint pair there is one all-A pairing, one all-TT
    # pairing, and one all-SS pairing.  For its S--S partner there is one
    # all-A, one all-TT, and one all-ST pairing.  This is the complete
    # endpoint table needed for the no-A/no-TT transfer.
    for st_cell, ss_cell in transfer:
        st_labels = tuple(labels for _, labels in pairing_record(*st_cell))
        assert sorted(st_labels) == [("A", "A"), ("SS", "SS"), ("TT", "TT")]
        ss_labels = tuple(labels for _, labels in pairing_record(*ss_cell))
        assert sorted(ss_labels) == [("A", "A"), ("ST", "ST"), ("TT", "TT")]

    # The five partner cells are exactly the edges of the disjointness
    # pentagon on S.  Each D5 cell omits a different terminal position.
    partners = tuple(ss for _, ss in transfer)
    assert len(set(partners)) == 5
    missing = tuple(
        tuple(sorted(POSITIONS - (set(st[0]) | set(st[1]))))
        for st, _ in transfer
    )
    assert missing == ((2,), (5,), (3,), (1,), (4,)), missing

    print({"D5": d5, "transfer": transfer, "omitted_positions": missing})
    print("D5_SS_TRANSFER_TABLE_VERIFIED")


if __name__ == "__main__":
    main()
