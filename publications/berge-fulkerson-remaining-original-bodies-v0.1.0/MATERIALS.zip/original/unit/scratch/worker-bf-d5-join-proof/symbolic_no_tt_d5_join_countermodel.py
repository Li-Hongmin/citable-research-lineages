#!/usr/bin/env python3
"""A finite relational countermodel for the D5 four-way join implication.

This certificate lives deliberately below the perfect-matching level.  It
keeps the five singleton fibres and the 56 boundary-type predicates, but it
does not claim that the relations are realised by one cubic pole.  Its sole
purpose is to test the logical implication

    all Case-XII positive cells + no T-loop/TT  =>  one D5 four-way join.

The answer is negative at this support/fibre level.  Each positive S--S or
S--T cell is assigned a nonempty singleton relation; all T--T cells and
T-loops are empty.  The five disjoint S--T cells are singleton relations with
incompatible target values, so every four-of-five cylinder intersection is
empty.  Thus a proof of the pole statement must use common cubic
perfect-matching incidence (or another extra hypothesis), not only the
boundary support labels.
"""

from __future__ import annotations

from itertools import combinations


POSITIONS = frozenset(range(1, 6))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(((1, 2), (1, 5), (2, 3), (3, 4), (4, 5)))

# The five disjoint S--T cells.  Their endpoint unions miss, respectively,
# 2, 5, 3, 1, 4.
D5 = tuple(sorted(
    (s, t) for s in S for t in T if set(s).isdisjoint(t)
))

# Each cell relation is a set of assignments on the classes in s union t.
# Values are deliberately chosen so that d_3 conflicts at class 2 with the
# first three cells, while d_4 conflicts at class 1 with the first three.
# This makes every four-of-five join empty.
D5_TARGETS = {
    ((1, 3), (4, 5)): {1: 0, 3: 0, 4: 0, 5: 0},
    ((1, 4), (2, 3)): {1: 0, 2: 0, 3: 0, 4: 0},
    ((1, 5), (2, 4)): {1: 0, 2: 0, 4: 0, 5: 0},
    ((2, 5), (3, 4)): {2: 1, 3: 0, 4: 0, 5: 0},
    ((1, 2), (3, 5)): {1: 1, 2: 0, 3: 0, 5: 0},
}


def cell_key(s: tuple[int, int], t: tuple[int, int]):
    return tuple(sorted((tuple(s), tuple(t))))


def relation(s: tuple[int, int], t: tuple[int, int]):
    """Return the formal singleton relation for one boundary cell.

    A positive Case-XII cell (at least one endpoint in S) is nonempty.  The
    five D5 cells use the incompatible targets above.  Other positive cells
    use the all-zero assignment.  T--T cells, including loops, are empty.
    """
    key = cell_key(s, t)
    if s in T and t in T:
        return frozenset()
    classes = tuple(sorted(set(s) | set(t)))
    target = D5_TARGETS.get(key)
    if target is None:
        target = {i: 0 for i in classes}
    return frozenset((tuple(target[i] for i in classes),))


def relation_assignments(s, t):
    classes = tuple(sorted(set(s) | set(t)))
    return classes, relation(s, t)


def join_nonempty(cells):
    """Check the natural cylinder join of the listed D5 relations."""
    partials = []
    for s, t in cells:
        classes, values = relation_assignments(s, t)
        partials.append((classes, values))
    # A relation has one tuple here, but retaining a tiny backtracking check
    # makes the certificate explicit and insensitive to that presentation.
    assignments = [dict()]
    for classes, values in partials:
        extended = []
        for assignment in assignments:
            for values_tuple in values:
                candidate = dict(assignment)
                if any(
                    position in candidate and candidate[position] != value
                    for position, value in zip(classes, values_tuple)
                ):
                    continue
                candidate.update(zip(classes, values_tuple))
                extended.append(candidate)
        assignments = extended
    return bool(assignments)


def verify_support_flags():
    # Exactly the 40 Case-XII positive types are nonempty.
    positive = []
    forbidden = []
    for left, right in combinations(sorted(S | T), 2):
        values = relation(left, right)
        if values:
            positive.append((left, right))
        else:
            forbidden.append((left, right))
    # Add the five loop types explicitly.
    loop_flags = {pair: bool(relation(pair, pair)) for pair in sorted(S | T)}
    assert all(loop_flags[pair] for pair in S)
    assert not any(loop_flags[pair] for pair in T)
    assert len(positive) == 35  # 10 S--T? counted below with loops separate
    assert len(forbidden) == 10  # the ten T--T off-diagonal cells
    return positive, forbidden, loop_flags


def verify_d5_joins():
    assert len(D5) == 5
    joins = []
    for omitted in range(5):
        chosen = tuple(cell for index, cell in enumerate(D5) if index != omitted)
        joins.append(join_nonempty(chosen))
    assert joins == [False] * 5
    return tuple(joins)


def main():
    positive, forbidden, loops = verify_support_flags()
    joins = verify_d5_joins()
    print({
        "positive_off_diagonal_cells": len(positive),
        "forbidden_TT_off_diagonal_cells": len(forbidden),
        "positive_S_loops": sum(loops[pair] for pair in S),
        "positive_T_loops": sum(loops[pair] for pair in T),
        "D5": D5,
        "four_of_five_joins": joins,
        "A_type": False,
    })
    print("SYMBOLIC_NO_TT_D5_JOIN_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
