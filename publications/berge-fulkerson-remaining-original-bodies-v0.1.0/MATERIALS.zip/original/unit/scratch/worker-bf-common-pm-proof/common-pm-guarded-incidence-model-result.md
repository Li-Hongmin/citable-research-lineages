# Guarded common-PM incidence model: strict boundary

## Scope

This is a finite **incidence** model, not a simple connected cubic 5-pole.
It is stronger than a route-label or private-witness model in one precise
respect: every witness uses vectors from one global perfect-matching pool.
The vectors can be realized as perfect matchings of a common product of
two-parallel-edge coordinate gadgets; changing a coordinate is an
alternating 2-cycle.  Five additional coordinates explicitly record the
semiedge boundary subset of every vector.  The missing ingredient is the
common cubic vertex incidence.

## Construction and certificate

The singleton pool has two vectors (P_{i,0},P_{i,1}) in every boundary
class.  Thirty base coordinates are indexed by all forbidden cross-class
pairs.  Thus the only disjoint singleton pairs are the ten edges of the
connected double cover (C_{10}\to C_5) over

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\}.
\]

The five loop relations therefore have sizes `(2,2,2,2,2)` and have no
pentagon section.  For each of the 25 S--T cells one global S-triple and one
global T-triple are added, with a four-singleton completion satisfying the
coordinatewise six-vector load equation.  Ten off-diagonal S--S cells are
added in the same way, and the five S loops are represented by a doubled
partition.

For every unordered pair of T-triples (including repetitions), one guard
coordinate is added.  It is 1 on both singleton variants of a selected
boundary class and the two targeted T-triple vectors are chosen so that the
coordinate load is strictly greater than two for every T--T singleton
choice.  Hence no T-loop relation and no T--T completion survives, even
after quantifying over the whole global matching pool.  No zero-boundary
matching is present, so an A-cover is absent by construction.

The model also contains one explicit same-class exchange: the S-triple
`("ss",0,1,0)` and its copy `("ss-exchange",0,1,0)` differ in exactly one
coordinate, hence in one formal alternating 2-cycle.  Their companion
S-triples differ in the same coordinate, so both sides of the exchange have
an exact S--S completion.  The fresh singleton copies only duplicate existing
C10 relation edges; they do not create a pentagon section.

The deterministic verifier is

```text
python3 units/berge-fulkerson/scratch/worker-bf-common-pm-proof/common_pm_guarded_incidence_model.py
```

and ends with

```text
COMMON_PM_GUARDED_INCIDENCE_MODEL_VERIFIED
```

It reports 30 base coordinates, 325 guards, 5 boundary coordinates, 77
global matching vectors,
relation sizes `(3,3,2,3,3)` after the one exchange copy, zero pentagon
sections, all 15 S--S and all 25 S--T cells present, and no A/T-loop/T--T
support.

## Decision value

This closes the following weaker route:

\[
\text{global common binary PM incidence}
 + \text{formal same-class alternating-cycle closure}
 + L_{\rm XII}
\not\Rightarrow \text{a common singleton section}.
\]

It does **not** close the real pole problem.  A proof for a simple connected
cubic 5-pole must still use the omitted shared three-valent vertex incidence
(and any consequences of being an actual matching family), or a theorem that
recovers that incidence from the support hypothesis.
