#!/usr/bin/env python3
"""A common-PM incidence countermodel for the rectangular-section route.

This is deliberately *not* a cubic 5-pole.  It is a finite incidence model:
all matching vectors live in one common binary edge-coordinate system, and
every two vectors differ by a disjoint union of formal alternating 2-cycles
(replace one of two parallel coordinate edges).  Boundary classes are
attached as the usual singleton/triple labels.  The model is therefore
strictly stronger than a private-witness route graph, while still omitting
the common cubic vertex-incidence constraint.

The singleton disjointness graph is the connected C10 double cover of the
S-pentagon.  Guard coordinates give every T-triple pair a coordinate whose
double-cover equation is impossible, while preserving all 15 S--S and all
25 S--T covers.  No zero-boundary matching is included, so an A-cover is
absent by construction.

The certificate's purpose is narrow: common global PM vectors, exact
six-vector load equations, and formal same-class cycle exchanges do not by
themselves force a pentagon section or an A-cover.  It is not evidence for a
real cubic-pole Case-XII counterexample.
"""

from __future__ import annotations

from itertools import combinations, combinations_with_replacement, product


S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
ORDER = (1, 4, 2, 5, 3)
S_SET = set(S)
T_SET = set(T)


def singleton_labels():
    return tuple((i, bit) for i in range(1, 6) for bit in (0, 1))


def relation_edges():
    """The connected C10 -> C5 singleton relation bundle."""
    allowed = set()
    for k in range(5):
        left = ORDER[k]
        right = ORDER[(k + 1) % 5]
        for bit in (0, 1):
            right_bit = bit if k < 4 else 1 - bit
            allowed.add(frozenset(((left, bit), (right, right_bit))))
    return allowed


def build_base_singletons():
    labels = singleton_labels()
    allowed = relation_edges()
    forbidden = [
        (left, right)
        for left, right in combinations(labels, 2)
        if left[0] != right[0]
        and frozenset((left, right)) not in allowed
    ]
    supports = {label: 0 for label in labels}
    for coordinate, (left, right) in enumerate(forbidden):
        supports[left] |= 1 << coordinate
        supports[right] |= 1 << coordinate
    return labels, allowed, forbidden, supports


def base_load(supports, labels, count):
    loads = [0] * count
    for label in labels:
        vector = supports[label] & ((1 << count) - 1)
        while vector:
            bit = vector & -vector
            coordinate = bit.bit_length() - 1
            loads[coordinate] += 1
            vector -= bit
    return loads


def feasible_slot_choices(slot_classes, supports, base_count):
    out = []
    for bits in product((0, 1), repeat=len(slot_classes)):
        labels = tuple((position, bit) for position, bit in zip(slot_classes, bits))
        if max(base_load(supports, labels, base_count), default=0) <= 2:
            out.append(labels)
    return out


def choose_slots(slot_classes, supports, base_count):
    choices = feasible_slot_choices(slot_classes, supports, base_count)
    if not choices:
        raise AssertionError(f"no feasible singleton choices for {slot_classes}")
    return choices[0]


def occurrence(labels, position):
    return sum(label[0] == position for label in labels)


def guard_choices(st_records):
    """Choose one class guard for every unordered pair of T records.

    A guard coordinate is 1 on both singleton variants of one class j.  Its
    T-triple bits are chosen so the targeted pair has total load > 2 on this
    coordinate for every T--T singleton choice.
    """
    choices = []
    for first, second in combinations_with_replacement(range(len(st_records)), 2):
        first_record = st_records[first]
        second_record = st_records[second]
        found = None
        for position in range(1, 6):
            first_occurrence = occurrence(first_record[4], position)
            second_occurrence = occurrence(second_record[4], position)
            first_bits = (1,) if first_occurrence == 0 else ((0,) if first_occurrence == 2 else (0, 1))
            second_bits = (1,) if second_occurrence == 0 else ((0,) if second_occurrence == 2 else (0, 1))
            t_load = sum(position in pair for pair in (first_record[3], second_record[3]))
            for first_bit, second_bit in product(first_bits, second_bits):
                if first == second and first_bit != second_bit:
                    continue
                if t_load + first_bit + second_bit > 2:
                    found = (position, first_bit, second_bit)
                    break
            if found is not None:
                break
        if found is None:
            raise AssertionError((first, second, first_record, second_record))
        choices.append((first, second, *found))
    return tuple(choices)


def matching_load(supports, labels, coordinate_count):
    loads = [0] * coordinate_count
    for label in labels:
        vector = supports[label]
        while vector:
            bit = vector & -vector
            coordinate = bit.bit_length() - 1
            loads[coordinate] += 1
            vector -= bit
    return loads


def split_vectors(supports, labels, coordinate_count, first_bit=None):
    """Return two binary vectors whose coordinate sum with labels is 2."""
    loads = matching_load(supports, labels, coordinate_count)
    if max(loads, default=0) > 2:
        raise AssertionError("singleton load exceeds capacity two")
    first = 0
    second = 0
    for coordinate, load in enumerate(loads):
        residual = 2 - load
        bit = 1 if residual == 2 else 0
        if first_bit is not None:
            bit = first_bit(coordinate, load)
        other = residual - bit
        if bit not in (0, 1) or other not in (0, 1):
            raise AssertionError((coordinate, load, bit, other))
        first |= bit << coordinate
        second |= other << coordinate
    return first, second


def build_model():
    labels, allowed, forbidden, supports = build_base_singletons()
    base_count = len(forbidden)

    st_records = []
    for s_index, s in enumerate(S):
        for t_index, t in enumerate(T):
            slots = list(s) + list(t)
            chosen = choose_slots(slots, supports, base_count)
            st_records.append((s_index, t_index, s, t, chosen))

    guards = guard_choices(st_records)
    guard_count = len(guards)
    for guard_index, (_, _, position, _, _) in enumerate(guards):
        coordinate = base_count + guard_index
        for label in labels:
            if label[0] == position:
                supports[label] |= 1 << coordinate
    coordinate_count = base_count + guard_count

    # Five terminal coordinates record the boundary subset of every matching
    # vector.  They are not used to build the C10 relation; they simply make
    # the six-vector equations include the semiedges explicitly.
    terminal_offset = coordinate_count
    coordinate_count += 5
    for label in labels:
        supports[label] |= 1 << (terminal_offset + label[0] - 1)

    vectors = {}
    metadata = {}

    # The five S-loop witnesses: Q_s is duplicated and the two singleton
    # variants are doubled.  Pick one actual C10 relation edge per layer.
    for loop_index, pair in enumerate(S):
        selected = next(
            ((pair[0], bit_a), (pair[1], bit_b))
            for bit_a in (0, 1)
            for bit_b in (0, 1)
            if supports[(pair[0], bit_a)] & supports[(pair[1], bit_b)] == 0
        )
        loads = matching_load(supports, selected, coordinate_count)
        if max(loads, default=0) > 1:
            raise AssertionError("loop singleton pair is not disjoint")
        vector = sum((1 - load) << coordinate for coordinate, load in enumerate(loads))
        name = ("loop", loop_index)
        vectors[name] = vector
        metadata[name] = pair

    # Ten off-diagonal S--S types, each with its own pair of S triples.
    for first_index, second_index in combinations(range(len(S)), 2):
        first_pair = S[first_index]
        second_pair = S[second_index]
        selected = choose_slots(list(first_pair) + list(second_pair), supports, base_count)
        first_name = ("ss", first_index, second_index, 0)
        second_name = ("ss", first_index, second_index, 1)
        first_vector, second_vector = split_vectors(
            supports, selected, coordinate_count
        )
        vectors[first_name] = first_vector
        vectors[second_name] = second_vector
        metadata[first_name] = first_pair
        metadata[second_name] = second_pair

    # Every S--T cell gets one S triple and one T triple.  At a guard, the T
    # bit is prescribed; the S bit is the residual bit.
    pair_to_guard = {(first, second): (position, first_bit, second_bit)
                     for first, second, position, first_bit, second_bit in guards}
    for record_index, (s_index, t_index, s, t, selected) in enumerate(st_records):
        first_vector = 0
        second_vector = 0
        loads = matching_load(supports, selected, coordinate_count)
        for coordinate in range(base_count):
            residual = 2 - loads[coordinate]
            first_bit = 1 if residual == 2 else 0
            second_bit = residual - first_bit
            first_vector |= first_bit << coordinate
            second_vector |= second_bit << coordinate
        for guard_index, (first, second, position, first_bit, second_bit) in enumerate(guards):
            coordinate = base_count + guard_index
            selected_occurrence = occurrence(selected, position)
            # The T bit is forced for occurrence 0/2; for occurrence 1 use 0
            # except at the targeted pair, where the guard choice is imposed.
            t_bit = 1 if selected_occurrence == 0 else 0
            if selected_occurrence == 1 and record_index == first:
                t_bit = first_bit
            if selected_occurrence == 1 and record_index == second:
                t_bit = second_bit
            s_bit = 2 - selected_occurrence - t_bit
            if s_bit not in (0, 1) or t_bit not in (0, 1):
                raise AssertionError((record_index, guard_index, position, selected_occurrence, s_bit, t_bit))
            first_vector |= s_bit << coordinate
            second_vector |= t_bit << coordinate
        first_name = ("stS", record_index)
        second_name = ("stT", record_index)
        vectors[first_name] = first_vector
        vectors[second_name] = second_vector
        metadata[first_name] = s
        metadata[second_name] = t

    # Add one explicit *single-coordinate* same-class exchange.  Use the
    # first off-diagonal S--S witness, whose selected slots are
    # (1,3,1,4).  A fresh coordinate is 1 on two fresh singleton variants
    # (classes 3 and 4) and on neither old variant.  Toggle both S-triples
    # participating in that witness; the old witness uses the new coordinate
    # twice on its triples, while the exchanged witness uses the two fresh
    # singleton variants.  Thus both witnesses remain exact covers and the
    # first S-triple differs from its exchanged copy in exactly one formal
    # alternating 2-cycle.
    exchange_coordinate = coordinate_count
    original_ss = ("ss", 0, 1, 0), ("ss", 0, 1, 1)
    if original_ss[0] not in vectors or original_ss[1] not in vectors:
        raise AssertionError("designated S--S exchange pair is missing")
    for name in vectors:
        vectors[name] |= 1 << exchange_coordinate
    vectors[original_ss[0]] |= 1 << exchange_coordinate
    vectors[original_ss[1]] |= 1 << exchange_coordinate

    fresh_singleton_3 = (3, 2)
    fresh_singleton_4 = (4, 2)
    # Their base/guard incidences copy the 0-variants; only the exchange
    # coordinate is new.  They therefore preserve the C10 relation pattern.
    supports[fresh_singleton_3] = supports[(3, 0)] | (1 << exchange_coordinate)
    supports[fresh_singleton_4] = supports[(4, 0)] | (1 << exchange_coordinate)
    labels = labels + (fresh_singleton_3, fresh_singleton_4)
    for fresh, base in ((fresh_singleton_3, (3, 0)), (fresh_singleton_4, (4, 0))):
        for other in labels:
            if other[0] != fresh[0] and frozenset((base, other)) in allowed:
                allowed.add(frozenset((fresh, other)))

    exchanged_first = ("ss-exchange", 0, 1, 0)
    exchanged_second = ("ss-exchange", 0, 1, 1)
    vectors[exchanged_first] = vectors[original_ss[0]] ^ (1 << exchange_coordinate)
    vectors[exchanged_second] = vectors[original_ss[1]] ^ (1 << exchange_coordinate)
    metadata[exchanged_first] = S[0]
    metadata[exchanged_second] = S[1]
    coordinate_count += 1

    # Replace the five terminal bits by the prescribed boundary subset.  The
    # internal/guard coordinates were already solved by the load equations;
    # the boundary bits satisfy the equations by the slot multiplicities.
    for name, vector in vectors.items():
        pair = metadata[name]
        for position in range(1, 6):
            bit = 0 if position in pair else 1
            coordinate = terminal_offset + position - 1
            if bit:
                vector |= 1 << coordinate
            else:
                vector &= ~(1 << coordinate)
        vectors[name] = vector

    classes = {pair: [] for pair in S + T}
    for name, vector in vectors.items():
        classes[metadata[name]].append((name, vector))
    return {
        "labels": labels,
        "allowed": allowed,
        "forbidden": forbidden,
        "supports": supports,
        "base_count": base_count,
        "guards": guards,
        "coordinate_count": coordinate_count,
        "vectors": vectors,
        "metadata": metadata,
        "classes": classes,
        "st_records": st_records,
    }


def cover_exists(model, first_pair, second_pair, first_vector, second_vector):
    supports = model["supports"]
    coordinate_count = model["coordinate_count"]
    slots = list(first_pair) + list(second_pair)
    for bits in product((0, 1), repeat=4):
        selected = tuple((position, bit) for position, bit in zip(slots, bits))
        loads = matching_load(supports, selected, coordinate_count)
        if all(
            ((first_vector >> coordinate) & 1)
            + ((second_vector >> coordinate) & 1)
            + load
            == 2
            for coordinate, load in enumerate(loads)
        ):
            return selected
    return None


def check_relation_bundle(model):
    supports = model["supports"]
    # Exactly the designated ten C10 edges are disjoint across classes.
    for left, right in combinations(model["labels"], 2):
        if left[0] == right[0]:
            continue
        disjoint = not (supports[left] & supports[right])
        expected = frozenset((left, right)) in model["allowed"]
        if disjoint != expected:
            raise AssertionError((left, right, disjoint, expected))

    # The C10 double cover has no section around ORDER.
    relation = []
    for index in range(5):
        left = ORDER[index]
        right = ORDER[(index + 1) % 5]
        relation.append(tuple(
            (a, b)
            for a in model["labels"]
            if a[0] == left
            for b in model["labels"]
            if b[0] == right and not (supports[a] & supports[b])
        ))
    # The unexchanged core has two edges per layer; the fresh exchanged
    # singleton copies duplicate two of those edges.  Duplicating a sheet
    # cannot create a section, but we check the enlarged bundle directly.
    assert all(len(layer) >= 2 for layer in relation)
    sections = 0
    for first, second in relation[0]:
        current = {second}
        for layer in range(1, 5):
            current = {
                candidate
                for source in current
                for source_endpoint, candidate in relation[layer]
                if source_endpoint == source
            }
        if first in current:
            sections += 1
    assert sections == 0, sections
    return relation


def check_support(model):
    classes = model["classes"]
    # Five S loops.
    for pair in S:
        found = False
        for name, vector in classes[pair]:
            if cover_exists(model, pair, pair, vector, vector) is not None:
                found = True
                break
        assert found, ("missing S loop", pair)

    # Ten off-diagonal S--S cells and all 25 S--T cells.
    for first_index, second_index in combinations(range(len(S)), 2):
        first, second = S[first_index], S[second_index]
        found = any(
            cover_exists(model, first, second, first_vector, second_vector) is not None
            for _, first_vector in classes[first]
            for _, second_vector in classes[second]
        )
        assert found, ("missing S-S", first, second)
    for first in S:
        for second in T:
            found = any(
                cover_exists(model, first, second, first_vector, second_vector) is not None
                for _, first_vector in classes[first]
                for _, second_vector in classes[second]
            )
            assert found, ("missing S-T", first, second)

    # No T-loop relation and no T--T type.  The former follows from the C10
    # relation check; the latter is checked against every global T vector and
    # every singleton choice, not merely the designated witnesses.
    for first_index, second_index in combinations_with_replacement(range(len(T)), 2):
        first, second = T[first_index], T[second_index]
        for first_name, first_vector in classes[first]:
            for second_name, second_vector in classes[second]:
                witness = cover_exists(
                    model, first, second, first_vector, second_vector
                )
                assert witness is None, ("forbidden T-T", first, second, first_name, second_name, witness)


def check_exchange_closure(model):
    """Every same-class vector pair has a formal alternating-cycle exchange."""
    vectors = model["vectors"]
    metadata = model["metadata"]
    minimum = None
    minimum_pair = None
    for first_name, first_vector in vectors.items():
        for second_name, second_vector in vectors.items():
            if first_name >= second_name or metadata[first_name] != metadata[second_name]:
                continue
            # In the two-parallel-edge realization, each differing coordinate
            # is one alternating 2-cycle.  No graph search is needed.
            difference = first_vector ^ second_vector
            assert difference >= 0
            weight = difference.bit_count()
            if minimum is None or weight < minimum:
                minimum = weight
                minimum_pair = (first_name, second_name)
    assert minimum == 1, (minimum, minimum_pair)
    return minimum_pair


def main():
    model = build_model()
    relation = check_relation_bundle(model)
    check_support(model)
    exchange_pair = check_exchange_closure(model)
    print({
        "base_coordinates": model["base_count"],
        "guard_coordinates": len(model["guards"]),
        "global_matching_vectors": len(model["vectors"]),
        "class_sizes": {str(pair): len(model["classes"][pair]) for pair in S + T},
        "relation_sizes": tuple(len(layer) for layer in relation),
        "pentagon_sections": 0,
        "A_cover": False,
        "T_loop": False,
        "TT_support": False,
        "single_cycle_exchange_pair": exchange_pair,
    })
    print("COMMON_PM_GUARDED_INCIDENCE_MODEL_VERIFIED")


if __name__ == "__main__":
    main()
