# Common-PM incidence boundary for the 40-type Case-XII target

## Question and exact status

Put

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

The target is a simple connected cubic 5-pole whose *complete* BF support is

\[
 L_{\mathrm{XII}}
 =\{[s]:s\in S\}\cup
   \{(s)(s'):s,s'\in S,\ s\leq s'\}\cup
   \{(s)(t):s\in S,t\in T\},
\]

namely five S-loops, ten off-diagonal S--S types, and all 25 S--T types,
with no A-type and no T--T type.  No proof or genuine pole with complete
support exactly \(L_{\mathrm{XII}}\) is obtained here.  The missing implication
is isolated below without assuming an exact-S Tait state set.

All 25 S--T cells already make the matching-level graph \(W(H)\) connected:
the within-class single-cycle exchange graph is connected for each boundary
class, and the class quotient contains the connected \(K_{5,5}\).  Therefore
under the target hypothesis “\(W(H)\) is disconnected” is not a separate
conclusion; one must derive a contradiction.

## A rigorous common-section lemma

Let \(\mathcal Q_r\) denote the triple-boundary perfect matchings whose
missing pair is \(r\), and let \(\mathcal P_i\) denote singleton-boundary
perfect matchings using semiedge \(i\).  For a cell \((s,t)\), the four
singleton slots are the multiset \(s\uplus t\); if \(s\cap t=\{i\}\), the
position \(i\) occurs twice.

Assume the following **role-independent rectangular witness** exists:

* one fixed \(Q_s\in\mathcal Q_s\) for every \(s\in S\);
* one fixed \(R_t\in\mathcal Q_t\) for every \(t\in T\); and
* one fixed \(P_i\in\mathcal P_i\) for every \(i\in[5]\);

such that every one of the 25 cells is completed by these fixed matchings,
using \(P_i\) once for every occurrence of \(i\) in \(s\uplus t\).  In
incidence-vector notation, every edge satisfies

\[
 \chi_{Q_s}+\chi_{R_t}
 +\sum_{i\in s}\chi_{P_i}+\sum_{i\in t}\chi_{P_i}
 =2\mathbf 1. \tag{1}
\]

Define

\[
 A_s=\chi_{Q_s}+\sum_{i\in s}\chi_{P_i},\qquad
 B_t=\chi_{R_t}+\sum_{i\in t}\chi_{P_i}.
\]

Equation (1) gives \(A_s+B_t=2\mathbf1\) for all \(s,t\).  Fixing one
variable at a time shows that all \(A_s\) equal a vector \(A\), and all
\(B_t\) equal \(B=2\mathbf1-A\).

Fix an edge \(e\), and write \(a=A(e)\).  Since \(B(e)\ge0\), only
\(a\in\{0,1,2\}\) is possible.  If \(a=0\), then for every S-edge
\(s=ij\), (1) gives \(Q_s(e)=P_i(e)=P_j(e)=0\).  The S-edge graph is a
5-cycle, so every \(P_i(e)=0\).  Then \(B(e)=2\) would force
\(R_t(e)=2\) for every T-edge \(t\), impossible for a 0--1 matching
incidence.  If \(a=2\), then \(B(e)=0\); the connected T-edge 5-cycle
similarly forces every \(P_i(e)=0\), after which
\(A(e)=Q_s(e)\le1\), a contradiction.  Hence

\[
 A(e)=B(e)=1\qquad\text{for every edge }e. \tag{2}
\]

For \(s=ij\in S\), (2) gives

\[
 P_i(e)+P_j(e)\le1
\]

for every edge.  Thus the five \(P_i\) are edge-disjoint on each edge of
the S pentagon.  The set of indices whose \(P_i\) contains a fixed edge is
an independent set of a 5-cycle and therefore has size at most two.  At
each internal cubic vertex the five singleton matchings contribute total
load five, so their edge loads are exactly \((1,2,2)\).  The load-one edges
form a perfect matching \(P_0\), and every semiedge has load one.  Therefore

\[
 P_0,P_1,P_2,P_3,P_4,P_5
\]

is an A-type BF cover, contradicting the no-A premise.  This proves:

> A role-independent rectangular witness for the 25 S--T cells is
> incompatible with an A-free pole.

The lemma uses only common perfect-matching incidence and the 25 exact
double-cover equations; it does not assume exact-S.

## The exchange identity does not supply the section

For a single completion witness write

\[
 \chi_Q+\chi_R+\sum_{i\in s\uplus t}\chi_{P_i}=2\mathbf 1.
\]

If (Q'=Q\mathbin\triangle C) is a same-boundary exchange and the other
triple matching is held fixed, any second witness satisfies

\[
 \sum_i(\chi_{P_i'}-\chi_{P_i})=\chi_Q-\chi_{Q'}. \tag{3}
\]

Thus the singleton fibre can absorb the whole exchange: one may have
(P'=P\mathbin\triangle C) and all other singleton witnesses unchanged.
This is realized by six genuine A/SS exchange triangles in the two fixed
order-15 poles of Note 021.  Hence common cubic incidence and alternating
cycle closure alone do not force witness reuse across cells; (3) is exactly
the cancellation that a section theorem would have to forbid.

## Why the 40 positive types do not yet give the section

For each cell \((s,t)\), let \(\mathscr W_{s,t}\) be its finite set of
actual six-matching witnesses.  Complete support says only

\[
\mathscr W_{s,t}\ne\varnothing\qquad(s\in S,t\in T).
\]

It does **not** supply one \(Q_s\), one \(R_t\), and one boundary-position
matching \(P_i\) that work in every cell.  Even choosing one common triple
matching in each class (a biclique in the triple-matching projection) leaves
the four singleton decompositions free to vary from cell to cell.  The
alternating-cycle exchange edges in \(W(H)\) constrain triple matchings, not
these singleton fibres.

The weaker role-specific reuse also does not close the gap.  If a fixed
\(P_i^S\) is used in S-slots and a fixed \(P_i^T\) in T-slots, the same
calculation gives

\[
 A_s=\chi_{Q_s}+\sum_{i\in s}\chi_{P_i^S},\qquad
 B_t=\chi_{R_t}+\sum_{i\in t}\chi_{P_i^T},
\]

but the edgewise alternatives \(A(e)=0\) and \(A(e)=2\) are no longer
contradictory: the unused role can carry the compensating singleton load.
Thus the needed condition is genuinely **cross-role identity of the
singleton witness**, not merely reuse within one role or reuse of aggregate
loads.

Equivalently, the unresolved extraction problem is a 25-cell rectangular
section (a Hall-type global consistency statement) for the witness fibres
\(\mathscr W_{s,t}\).  Nonempty fibres, class-quotient connectivity, and
single-cycle closure do not prove this section.

## Real boundary already known

The order-thirteen pole in
`notes/024-common-cubic-incidence-does-not-force-an-unsafe-route-without-exact-s.md`
is a genuine simple connected cubic pole with all 25 actual S--T cells,
connected active \(W(H)\), no A cover, and all disjoint S--T routes SS.  Its
complete BF support additionally contains the five T-loops and ten T--T
types.  Hence it is a real boundary example showing that common cubic
incidence, complete perfect-matching closure, and witness reuse do not force
the rectangular section when the negative “no T-type” part of
\(L_{\mathrm{XII}}\) is not used.  It is not a counterexample to the exact
40-type target.

More sharply, that same pole has every one of the 15 S--S types as well as
all 25 S--T types.  Choosing one actual witness for each of these 40 positive
types gives a common-PM witness family satisfying all positive incidence
equations and still having no A cover; by the lemma, this family cannot admit
the rectangular section.  Thus the positive 40-cell data alone cannot imply
the section.  The only unused information in this real boundary is the
presence of the extra T-loop/T--T support, so an exclusion proof must use the
absence of those types (or an equivalent global compatibility theorem).

**Strict conclusion:** existence of a simple connected cubic 5-pole with
complete BF support exactly \(L_{\mathrm{XII}}\) remains **unresolved**.  The
thinnest unproved interface is

\[
\text{support exactly }L_{\mathrm{XII}}
\Longrightarrow
\text{a role-independent rectangular witness (or another cross-cell
incidence obstruction)}.
\]

The displayed lemma proves that this interface, once established, would
immediately contradict the no-A hypothesis.
