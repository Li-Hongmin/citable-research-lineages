#!/usr/bin/env python3
"""Independent finite verifier for the move-174--300 radius-one result.

This verifier shares only the project's perfect-matching enumerator and Pole
type with the primary scan.  It independently reconstructs the labelled
children, exact-S relations, fixed-Q groups, the 32 endpoint-source patterns,
the capacity-two search, and the one-cycle-neighbour predicate.  It compares
all per-move Q counts with the primary JSON and stops at any discrepancy or
unrepaired fixed-Q failure.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
from functools import reduce
from hashlib import sha256
from itertools import combinations, product
import json
from operator import or_
from pathlib import Path
import sys
import time


HERE = Path(__file__).resolve().parent
WORKER_PROOF = HERE.parent / "worker-proof"
sys.path.insert(0, str(WORKER_PROOF))
import audit_fixed_q_rounding_n17_seed_neighbourhood as inherited  # noqa: E402


legacy = inherited.legacy
BASE_N = 15
BASE_PROPER = (
    (0, 2), (0, 3), (1, 5), (1, 7), (2, 4),
    (3, 14), (4, 11), (5, 6), (5, 9), (6, 7),
    (6, 10), (7, 8), (8, 9), (8, 13), (9, 12),
    (10, 11), (10, 14), (11, 12), (12, 13), (13, 14),
)
BASE_SEMI_ENDPOINTS = (0, 1, 2, 3, 4)
ORDER = (1, 4, 2, 5, 3)
TARGET_STATES = frozenset({(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)})
START = 174
END = 300


def expand(pair):
    selected = {pair[0]: BASE_N, pair[1]: BASE_N + 1}
    proper = []
    semiedges = list(BASE_SEMI_ENDPOINTS)
    for index, (u, v) in enumerate(BASE_PROPER):
        if index in selected:
            w = selected[index]
            proper.extend(((u, w), (w, v)))
        else:
            proper.append((u, v))
    for position, endpoint in enumerate(BASE_SEMI_ENDPOINTS):
        index = len(BASE_PROPER) + position
        if index in selected:
            w = selected[index]
            proper.append((endpoint, w))
            semiedges[position] = w
    proper.append((BASE_N, BASE_N + 1))
    return tuple(proper), tuple(semiedges)


def normalize(proper, semiedges):
    relabel = {endpoint: position for position, endpoint in enumerate(semiedges)}
    internal = sorted(set(range(BASE_N + 2)) - set(semiedges))
    relabel.update({vertex: index + 5 for index, vertex in enumerate(internal)})
    edges = tuple(sorted(
        tuple(sorted((relabel[u], relabel[v]))) for u, v in proper
    ))
    return legacy.Pole(n=17, proper_edges=edges)


def matching_data(pole):
    matchings, edge_vertices, edge_position, incidence = (
        legacy.enumerate_perfect_matchings(pole)
    )
    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    states = set()
    for left, right in combinations(range(1, 6), 2):
        if any(a.isdisjoint(b) for a in singleton[left] for b in singleton[right]):
            states.add((left, right))
    relations = []
    for left, right in zip(ORDER, ORDER[1:] + ORDER[:1]):
        relations.append(tuple(
            (a, b)
            for a in singleton[left]
            for b in singleton[right]
            if a.isdisjoint(b)
        ))
    return edge_vertices, incidence, frozenset(states), tuple(relations)


def q_groups(relations, universe):
    answer = []
    for relation in relations:
        grouped = defaultdict(list)
        for left, right in relation:
            grouped[universe - left - right].append((left, right))
        answer.append(tuple(
            (third, tuple(variants))
            for third, variants in sorted(
                grouped.items(), key=lambda item: tuple(sorted(item[0]))
            )
        ))
    return tuple(answer)


def source_roles():
    choices = {position: [] for position in range(1, 6)}
    for t in range(5):
        choices[ORDER[t]].append((t, 0))
        choices[ORDER[(t + 1) % 5]].append((t, 1))
    assert all(len(choices[position]) == 2 for position in choices)
    answer = []
    for bits in product((0, 1), repeat=5):
        roles = [set() for _ in range(5)]
        for position, bit in enumerate(bits, 1):
            t, role = choices[position][bit]
            roles[t].add(role)
        answer.append(tuple(tuple(sorted(role)) for role in roles))
    return tuple(answer)


SOURCE_ROLES = source_roles()


def capacity_rounds(variant_groups, universe):
    edge_order = tuple(sorted(universe, key=lambda edge: (edge[0], int(edge[1:]))))
    edge_index = {edge: index for index, edge in enumerate(edge_order)}
    encoded = tuple(tuple(
        (
            tuple(edge_index[edge] for edge in left),
            tuple(edge_index[edge] for edge in right),
        )
        for left, right in variants
    ) for variants in variant_groups)
    counts = [0] * len(edge_order)

    for roles_by_state in SOURCE_ROLES:
        def search(t):
            if t == 5:
                return all(value >= 1 for value in counts)
            roles = roles_by_state[t]
            variants = encoded[t][:1] if not roles else encoded[t]
            for variant in variants:
                additions = [variant[role] for role in roles]
                touched = []
                valid = True
                for matching in additions:
                    for edge in matching:
                        counts[edge] += 1
                        touched.append(edge)
                        if counts[edge] > 2:
                            valid = False
                if valid and search(t + 1):
                    for edge in touched:
                        counts[edge] -= 1
                    return True
                for edge in touched:
                    counts[edge] -= 1
            return False

        if search(0):
            return True
    return False


def is_one_internal_cycle(left, right, edge_vertices):
    difference = left ^ right
    if not difference or len(difference) % 2:
        return False
    incidence = defaultdict(list)
    for edge in difference:
        endpoints = edge_vertices[edge]
        if len(endpoints) != 2:
            return False
        for vertex in endpoints:
            incidence[vertex].append(edge)
    if any(len(edges) != 2 for edges in incidence.values()):
        return False
    unseen = set(difference)
    queue = deque((next(iter(unseen)),))
    seen = set()
    while queue:
        edge = queue.popleft()
        if edge in seen:
            continue
        seen.add(edge)
        for vertex in edge_vertices[edge]:
            queue.extend(incidence[vertex])
    return seen == difference


def independent_audit(pair):
    proper, semiedges = expand(pair)
    pole = normalize(proper, semiedges)
    edge_vertices, _, states, relations = matching_data(pole)
    if states != TARGET_STATES:
        return False, Counter()
    universe = frozenset(edge_vertices)
    groups = q_groups(relations, universe)
    ranges = tuple(range(len(group)) for group in groups)
    thirds = tuple(tuple(item[0] for item in group) for group in groups)
    variants = tuple(tuple(item[1] for item in group) for group in groups)
    fixed_cache = {}
    counters = Counter()

    def fixed(indices):
        if indices not in fixed_cache:
            fixed_cache[indices] = capacity_rounds(
                tuple(variants[t][indices[t]] for t in range(5)), universe
            )
        return fixed_cache[indices]

    for indices in product(*ranges):
        counters["distinct_q_tuples"] += 1
        selected = tuple(thirds[t][indices[t]] for t in range(5))
        if reduce(or_, selected, frozenset()) != universe:
            continue
        counters["edge_covering_q_tuples"] += 1
        if fixed(indices):
            counters["fixed_q_successes"] += 1
            continue
        counters["fixed_q_failures"] += 1

        repaired = False
        for t in range(5):
            for replacement, candidate in enumerate(thirds[t]):
                if replacement == indices[t]:
                    continue
                if not is_one_internal_cycle(selected[t], candidate, edge_vertices):
                    continue
                changed = list(indices)
                changed[t] = replacement
                changed = tuple(changed)
                changed_selected = tuple(thirds[j][changed[j]] for j in range(5))
                if reduce(or_, changed_selected, frozenset()) != universe:
                    continue
                if fixed(changed):
                    repaired = True
                    break
            if repaired:
                break
        if not repaired:
            raise AssertionError(("independent radius-one failure", pair, indices))
        counters["radius_one_repaired_failures"] += 1
    return True, counters


def run(primary_path):
    raw = primary_path.read_bytes()
    primary = json.loads(raw)
    assert primary["scope"]["requested_start"] == START
    assert primary["scope"]["requested_end"] == END
    assert primary["scope"]["complete_requested_range"] is True
    records = {record["move_number"]: record for record in primary["records"]}
    assert sorted(records) == list(range(START, END + 1))

    totals = Counter()
    began = time.monotonic()
    pairs = combinations(range(25), 2)
    for move_number, pair in enumerate(pairs, 1):
        if move_number < START:
            continue
        exact_s, counters = independent_audit(pair)
        record = records[move_number]
        assert exact_s == record["exact_S"]
        totals["labelled_moves_scanned"] += 1
        if exact_s:
            totals["exact_S_children"] += 1
            expected = record["audit_counts"]
            for key in (
                "distinct_q_tuples",
                "edge_covering_q_tuples",
                "fixed_q_successes",
                "fixed_q_failures",
                "radius_one_repaired_failures",
            ):
                assert counters[key] == expected.get(key, 0), (
                    move_number, key, counters[key], expected.get(key, 0)
                )
                totals[key] += counters[key]
        print("VERIFIED_MOVE", move_number, flush=True)

    assert dict(totals) == primary["totals"]
    return {
        "primary_sha256": sha256(raw).hexdigest(),
        "scope": {"start": START, "end": END, "complete": True},
        "totals": dict(totals),
        "elapsed_seconds": round(time.monotonic() - began, 6),
        "first_radius_one_failure": None,
        "independently_verified": True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--primary",
        type=Path,
        default=HERE / "moves174_300_primary.json",
    )
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    result = run(args.primary)
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.json is not None:
        args.json.write_text(text + "\n", encoding="utf-8")
    print(text)
    print("RADIUS_ONE_MOVES_174_300_INDEPENDENTLY_VERIFIED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
