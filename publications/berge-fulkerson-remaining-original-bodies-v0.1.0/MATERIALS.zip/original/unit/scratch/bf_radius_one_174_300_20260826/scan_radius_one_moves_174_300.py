#!/usr/bin/env python3
"""Scan the labelled Note-020 seed children in moves 174 through 300.

For every exact-S child and every edge-covering five-tuple of third
matchings Q, first test the complete fixed-Q endpoint fibre.  If that fibre
does not capacity-two round, exhaust every neighbour obtained by replacing
one Q_t by a same-boundary third matching whose symmetric difference is one
internal alternating cycle.  Stop at the first failed radius-one repair.

The graph generation, matching enumeration, Q fibres, and rounding test are
reused from the frozen drivers behind Notes 030 and 035.  This file adds only
the missing move-range loop and a streaming finite-scope certificate.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from functools import reduce
from itertools import combinations, product
import json
from operator import or_
from pathlib import Path
import sys
import time


HERE = Path(__file__).resolve().parent
WORKER_PROOF = HERE.parent / "worker-proof"
sys.path.insert(0, str(WORKER_PROOF))

import audit_fixed_q_rounding_n17_seed_neighbourhood as neighbourhood  # noqa: E402
import audit_radius_one_q_repair_first173 as first173  # noqa: E402


rounding = neighbourhood.rounding
DEFAULT_START = 174
DEFAULT_END = 300


def names(matching) -> tuple[str, ...]:
    return tuple(sorted(matching, key=lambda edge: (edge[0], int(edge[1:]))))


def q_tuple(groups, indices):
    return tuple(groups[t][index][0] for t, index in enumerate(indices))


def q_variants(groups, indices):
    return tuple(groups[t][index][1] for t, index in enumerate(indices))


def is_success(result) -> bool:
    return not isinstance(result, tuple)


def build_adjacency(groups, edge_vertices):
    """All directed one-state, same-boundary, one-internal-cycle moves."""
    adjacency = []
    profile = Counter()
    for t, group in enumerate(groups):
        state_adjacency = defaultdict(list)
        for left_index, (left_q, _) in enumerate(group):
            for right_index, (right_q, _) in enumerate(group):
                if left_index == right_index:
                    continue
                components = first173.symmetric_difference_components(
                    left_q, right_q, edge_vertices
                )
                if len(components) != 1:
                    continue
                component = components[0]
                state_adjacency[left_index].append((right_index, component))
                profile[(t, component["length"])] += 1
        adjacency.append(dict(state_adjacency))
    return tuple(adjacency), profile


def find_fixed(indices, groups, universe, incidence, cache):
    result = cache.get(indices)
    if result is None:
        result = rounding.find_fixed_q_rounding(
            q_variants(groups, indices), universe, incidence
        )
        cache[indices] = result
    return result


def radius_one_audit(indices, groups, adjacency, universe, incidence, cache):
    counts = Counter()
    successful = []
    for t in range(5):
        for replacement, component in adjacency[t].get(indices[t], ()):
            changed = list(indices)
            changed[t] = replacement
            changed = tuple(changed)
            counts["one_cycle_neighbours"] += 1
            changed_q = q_tuple(groups, changed)
            if reduce(or_, changed_q, frozenset()) != universe:
                counts["not_edge_covering"] += 1
                continue
            counts["edge_covering"] += 1
            result = find_fixed(
                changed, groups, universe, incidence, cache
            )
            if not is_success(result):
                counts["edge_covering_but_fixed_bad"] += 1
                continue
            counts["successful_repairs"] += 1
            successful.append((
                component["length"] // 2,
                t,
                replacement,
                component,
                changed,
                result,
            ))
    successful.sort(key=lambda item: (item[0], item[1], item[2]))
    return dict(counts), successful


def audit_move(move_number, pair):
    proper, semiedge_endpoints = neighbourhood.expand(pair)
    neighbourhood.check_pole(
        neighbourhood.BASE_N + 2, proper, semiedge_endpoints
    )
    pole = neighbourhood.normalized_pole(proper, semiedge_endpoints)
    data = neighbourhood.matching_data(pole)
    (
        matchings,
        edge_vertices,
        _,
        incidence,
        singleton,
        states,
        relations,
    ) = data
    base = {
        "move_number": move_number,
        "move": tuple(neighbourhood.object_name(index) for index in pair),
        "family": neighbourhood.move_family(pair),
        "geometry": neighbourhood.move_geometry(pair),
        "perfect_matchings": len(matchings),
        "tait_state_count": len(states),
        "exact_S": states == neighbourhood.TARGET_STATES,
    }
    if states != neighbourhood.TARGET_STATES:
        return base, None

    universe = frozenset(edge_vertices)
    groups = rounding.fixed_q_groups(relations, universe)
    rounding.verify_q_groups(groups, edge_vertices)
    adjacency, adjacency_profile = build_adjacency(groups, edge_vertices)
    ranges = tuple(range(len(group)) for group in groups)
    cache = {}
    counts = Counter()
    repair_count_distribution = Counter()
    repair_cycle_lengths = Counter()
    first_repair = None

    for indices in product(*ranges):
        counts["distinct_q_tuples"] += 1
        qs = q_tuple(groups, indices)
        if reduce(or_, qs, frozenset()) != universe:
            continue
        counts["edge_covering_q_tuples"] += 1
        fixed = find_fixed(indices, groups, universe, incidence, cache)
        if is_success(fixed):
            counts["fixed_q_successes"] += 1
            continue

        counts["fixed_q_failures"] += 1
        neighbour_counts, successful = radius_one_audit(
            indices, groups, adjacency, universe, incidence, cache
        )
        repair_count_distribution[len(successful)] += 1
        for item in successful:
            repair_cycle_lengths[item[3]["length"]] += 1

        if not successful:
            failure = {
                **base,
                "proper_edges": tuple(tuple(edge) for edge in pole.proper_edges),
                "semiedge_endpoints_after_normalization": (0, 1, 2, 3, 4),
                "singleton_profile": tuple(
                    len(singleton[position]) for position in range(1, 6)
                ),
                "relation_sizes": tuple(len(relation) for relation in relations),
                "fixed_q_group_sizes": tuple(len(group) for group in groups),
                "group_indices": indices,
                "q_tuple": tuple(names(third) for third in qs),
                "fixed_q_variant_sizes": tuple(
                    len(item) for item in q_variants(groups, indices)
                ),
                "half_support_components": rounding.half_support_data(
                    qs, edge_vertices
                ),
                "complete_radius_one_neighbour_counts": neighbour_counts,
                "one_cycle_neighbours_by_state_and_length": {
                    str(key): value
                    for key, value in sorted(adjacency_profile.items())
                },
            }
            base.update({
                "singleton_profile": failure["singleton_profile"],
                "relation_sizes": failure["relation_sizes"],
                "fixed_q_group_sizes": failure["fixed_q_group_sizes"],
                "audit_counts_before_stop": dict(counts),
            })
            return base, failure

        counts["radius_one_repaired_failures"] += 1
        if first_repair is None:
            _, t, replacement, component, changed, witness = successful[0]
            changed_q = q_tuple(groups, changed)
            first_repair = {
                "starting_group_indices": indices,
                "changed_state": t,
                "replacement_group_index": replacement,
                "alternating_component": component,
                "q_prime_group_indices": changed,
                "q_prime": tuple(names(third) for third in changed_q),
                "rounding_source_bits": witness["source_bits"],
                "rounding_selected_singletons": tuple(
                    names(matching)
                    for matching in witness["selected_singletons"]
                ),
            }

    assert counts["edge_covering_q_tuples"] == (
        counts["fixed_q_successes"] + counts["fixed_q_failures"]
    )
    assert counts["fixed_q_failures"] == counts[
        "radius_one_repaired_failures"
    ]
    base.update({
        "singleton_profile": tuple(
            len(singleton[position]) for position in range(1, 6)
        ),
        "relation_sizes": tuple(len(relation) for relation in relations),
        "fixed_q_group_sizes": tuple(len(group) for group in groups),
        "audit_counts": dict(counts),
        "successful_repair_count_distribution": {
            str(key): value for key, value in sorted(repair_count_distribution.items())
        },
        "successful_directed_repair_cycle_lengths": {
            str(key): value for key, value in sorted(repair_cycle_lengths.items())
        },
        "first_repair_witness": first_repair,
    })
    return base, None


def run(start, end):
    assert DEFAULT_START <= start <= end <= DEFAULT_END
    pairs = combinations(range(len(neighbourhood.BASE_PROPER) + 5), 2)
    totals = Counter()
    records = []
    first_failure = None
    began = time.monotonic()

    for move_number, pair in enumerate(pairs, 1):
        if move_number < start:
            continue
        if move_number > end:
            break
        move_began = time.monotonic()
        record, failure = audit_move(move_number, pair)
        record["elapsed_seconds"] = round(time.monotonic() - move_began, 6)
        records.append(record)
        totals["labelled_moves_scanned"] += 1
        if record["exact_S"]:
            totals["exact_S_children"] += 1
            counts = record.get("audit_counts", record.get("audit_counts_before_stop", {}))
            for key, value in counts.items():
                totals[key] += value
        print(
            "MOVE",
            move_number,
            "exact_S=" + str(record["exact_S"]),
            "fixed_failures=" + str(
                record.get("audit_counts", record.get("audit_counts_before_stop", {})).get(
                    "fixed_q_failures", 0
                )
            ),
            "elapsed=" + str(record["elapsed_seconds"]),
            flush=True,
        )
        if failure is not None:
            first_failure = failure
            break

    complete = first_failure is None and totals["labelled_moves_scanned"] == end - start + 1
    return {
        "scope": {
            "seed_order": neighbourhood.BASE_N,
            "child_order": neighbourhood.BASE_N + 2,
            "move_numbering": "1-based lexicographic combinations of 25 labelled edge objects",
            "requested_start": start,
            "requested_end": end,
            "complete_requested_range": complete,
            "full_target_range": start == DEFAULT_START and end == DEFAULT_END,
        },
        "totals": dict(totals),
        "elapsed_seconds": round(time.monotonic() - began, 6),
        "records": records,
        "first_radius_one_failure": first_failure,
        "finite_range_supports_radius_one_candidate": complete,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, default=DEFAULT_START)
    parser.add_argument("--end", type=int, default=DEFAULT_END)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if not DEFAULT_START <= args.start <= args.end <= DEFAULT_END:
        parser.error("require 174 <= start <= end <= 300")
    result = run(args.start, args.end)
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.json is not None:
        args.json.write_text(text + "\n", encoding="utf-8")
        print(json.dumps({
            "scope": result["scope"],
            "totals": result["totals"],
            "elapsed_seconds": result["elapsed_seconds"],
            "first_radius_one_failure": result["first_radius_one_failure"],
        }, indent=2, sort_keys=True))
    else:
        print(text)
    if result["first_radius_one_failure"] is not None:
        print("RADIUS_ONE_Q_REPAIR_COUNTEREXAMPLE_FOUND_IN_MOVES_174_300")
        return 1
    if result["scope"]["complete_requested_range"]:
        print("RADIUS_ONE_Q_REPAIR_SUPPORTED_ON_REQUESTED_RANGE")
        return 0
    print("RADIUS_ONE_Q_REPAIR_RANGE_INCOMPLETE")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
