# Note 020 seed 的 labelled one-step 后缀满足 radius-one variable-Q rounding

固定 Note 020 的十五阶 exact-$S$ 5-pole。依照 Note 030 的编号，对其二十五个带标签
edge-object 取二元组，细分所选两个对象并连接两个新顶点，得到三百个十七阶 labelled
children。本结果只新计算 moves $174,\ldots,300$。

## 有限命题

在 moves $174$ through $300$ 中，任取 complete Tait state set 恰为

\[
S=\{13,14,24,25,35\}
\]

的 child，并任取一个覆盖全部边的第三 matching 五元组
$Q=(Q_0,\ldots,Q_4)$。若 $Q$ 的完整 fixed-$Q$ endpoint fibre 不含
capacity-two split，则存在 $t$ 与同边界 perfect matching $Q'_t$，使得

\[
Q'_j=Q_j\quad(j\ne t),\qquad
Q_t\mathbin\triangle Q'_t
\]

是一个内部交替环，新五元组 $Q'$ 仍覆盖全部边，并且其 fixed-$Q'$ fibre 含
capacity-two split。

## 穷尽论证

这 127 个 labelled moves 中有 69 个 exact-$S$ children。对每个 child 完整枚举
perfect matchings，由五个 $S$-state relations 按第三 matching 分组；每组的 endpoint
variants 是固定第三 matching 的完整内部交替环 cube。随后枚举组指标的完整笛卡尔积，
只保留覆盖全部边的 $Q$-tuples，并对每一个执行完整的 32 个 boundary-source choices 与
endpoint variants 搜索。

共得到

\[
177{,}474\text{ 个不同 }Q\text{-tuples},\qquad
26{,}147\text{ 个 edge-covering }Q\text{-tuples}.
\]

其中 25,997 个已 fixed-$Q$ round，150 个 fixed-$Q$ failure。对每个 failure，逐状态枚举
所有同边界第三 matchings，保留 symmetric difference 为一个连通内部偶环的候选，再要求
新五元组 edge-covering 并完整搜索其 fixed fibre。结果是

\[
\boxed{150/150}
\]

均有 radius-one repair；没有 radius-one failure。150 个 failures 分布在 moves

\[
174,175,215,216,217,225,226,227,228,229.
\]

第二个 verifier 独立重建 labelled children、exact-$S$ relations、$Q$ groups、32 个 endpoint
source patterns、capacity search 与 single-internal-cycle 判据；它只与主驱动共享项目的 Pole
类型及 perfect-matching enumerator。它逐 move 重得完全相同的 69、177,474、26,147、25,997、
150 和 150，并以

```text
RADIUS_ONE_MOVES_174_300_INDEPENDENTLY_VERIFIED
```

结束。

结合 Note 035 已建立的 first-173 结果，整个 300-move labelled one-step family 现满足同一
有限命题。合并计数为 165 个 exact-$S$ children、48,690 个 edge-covering $Q$-tuples、
48,485 个 fixed-$Q$ successes 与 205 个 fixed-$Q$ failures，且

\[
\boxed{205/205}
\]

fixed failures 均可 radius-one repair。这里的合并结论引用 Note 035 的 prefix 证据；本轮没有
重扫 moves $1$ through $173$。

## 证据边界

新后缀结论是完整有限计算定理，并有算法独立的全范围复核。最薄弱的共同接口是项目既有
perfect-matching enumerator 的完备性，以及由 state relation 按 complement 分组确实枚举所有
fixed-$Q$ endpoint variants。合并后的 300-move 结论还继承 Note 035 对 first 172 moves 使用旧
cache 而未重算的覆盖接口。

本结果不推出所有十七阶 exact-$S$ poles、所有一步邻域，或任意阶 exact-$S$ poles 的一般
radius-one theorem。它只关闭 Note 020 这个 labelled seed 的完整 one-step family。

## 复现入口

环境：Python 3.13.15，NetworkX 3.6.1。

```bash
cd units/berge-fulkerson/scratch/bf_radius_one_174_300_20260826
uv run --with networkx python -u scan_radius_one_moves_174_300.py \
  --start 174 --end 300 --json moves174_300_primary.json
uv run --with networkx python -u independent_verify_moves_174_300.py \
  --primary moves174_300_primary.json --json moves174_300_independent.json
```

主结果 JSON 的 SHA-256 为

```text
b4ecf2f5287dba483865f0f14cc85789df9acf21e1d63bd8108010b79feee1f4
```
