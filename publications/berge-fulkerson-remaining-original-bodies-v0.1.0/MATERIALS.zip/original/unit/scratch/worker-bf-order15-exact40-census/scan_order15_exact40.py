#!/usr/bin/env python3
"""Complete order-15 census wrapper for real Case-XII support.

The order-13 scanner contains the audited graph6 streaming, proper-core
filters, complete perfect-matching enumeration, terminal canonicalisation,
and exact 40-type support test.  This wrapper reuses that implementation and
changes only its global order parameter to 15, so the generated augmented
graphs have degree sequence ``(5,3^15)`` on 16 vertices.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "worker-bf-order13-exact40-census"
sys.path.insert(0, str(BASE))
import scan_order13_exact40 as base  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--geng", default="geng"
    )
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--progress-every", type=int, default=250)
    parser.add_argument("--json", type=Path, default=None)
    args = parser.parse_args()

    # All order-dependent logic in the audited scanner reads this module
    # global (including geng's vertex/edge arguments and degree filtering).
    base.ORDER = 15
    result = base.scan_order(args.geng, args.limit, args.progress_every)
    result["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result["base_scanner_sha256"] = hashlib.sha256(
        (BASE / "scan_order13_exact40.py").read_bytes()
    ).hexdigest()
    result["order"] = 15
    result["scope"] = (
        "all unlabelled simple connected augmented graphs with degree "
        "sequence (5,3^15), after deleting the unique degree-five apex: "
        "connected proper core, proper-edge bridgeless, five distinct terminals"
    )
    text = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    print(text)
    if args.json is not None:
        args.json.write_text(text + "\n", encoding="utf-8")
    print("ORDER15_EXACT40_CENSUS_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
