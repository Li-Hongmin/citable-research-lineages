#!/usr/bin/env python3
"""Targeted UE2 audit for the exact-40 common-coordinate countermodel.

The imported model has one global binary singleton/triple vector pool and
checks all 40 positive Case-XII equations together with the absence of A,
T-loop and T--T equations.  It deliberately omits cubic vertex incidence.
This script computes the five D5-transferred S--S relations, then checks all
four-of-five joins and the anchored three-fibre UE2 condition.  A negative
result is therefore an abstract incidence boundary only.
"""

from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
MODEL_PATH = HERE.parent / "worker-lp-integer-rounding" / (
    "verify_exact40_lp_integer_abstract_countermodel.py"
)


def load_model_module():
    spec = spec_from_file_location("exact40_lp_model", MODEL_PATH)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relation(model, first, second):
    """Return all partial singleton tuples in one S--S cell."""
    cells, vectors, singleton_support = model.make_model()
    coordinate_count = len(model.BASE_COORDINATES) + 5
    first_vectors = [vector for vector in vectors if vector["kind"] == first]
    second_vectors = [vector for vector in vectors if vector["kind"] == second]
    slots = tuple(first) + tuple(second)
    omitted = tuple(set(range(5)) - set(slots))
    assert len(omitted) == 1
    omitted = omitted[0]
    # The imported model always has exactly the 0/1 singleton labels.
    labels_by_class = {
        i: tuple((i, bit) for bit in (0, 1)) for i in range(5)
    }
    rows = set()
    for choices in __import__("itertools").product(
        *(labels_by_class[position] for position in slots)
    ):
        for first_vector in first_vectors:
            for second_vector in second_vectors:
                if model.equation_holds(
                    first_vector, second_vector, choices, singleton_support
                ):
                    row = [None] * 5
                    for position, label in zip(slots, choices, strict=True):
                        row[position] = label
                    rows.add(tuple(row))
                    break
            else:
                continue
            break
    return frozenset(rows), omitted


def extension_sets(anchor_row, anchor_missing, others):
    out = []
    for rows, other_missing in others:
        shared = [
            i for i in range(5)
            if i != anchor_missing and i != other_missing
        ]
        values = set()
        for row in rows:
            if all(row[i] == anchor_row[i] for i in shared):
                value = row[anchor_missing]
                assert value is not None
                values.add(value)
        out.append(frozenset(values))
    return tuple(out)


def normalized_rows(rows):
    """Fill the omitted coordinate by either actual singleton label."""
    out = set()
    for row in rows:
        missing = row.index(None)
        for bit in (0, 1):
            full = list(row)
            full[missing] = (missing, bit)
            out.add(tuple(full))
    return frozenset(out)


def main():
    model = load_model_module()
    # Force the original exact-40 gates before this more targeted audit.
    cells_data, vectors, singleton_support = model.make_model()
    model.verify_allowed_equations(cells_data, vectors, singleton_support)
    model.verify_forbidden_tt(cells_data, vectors, singleton_support)
    model.verify_capacity_gap(singleton_support)
    model.verify_exact_s_relation(singleton_support)
    model.verify_no_balanced_two_edge_blocker(vectors, singleton_support)

    S = model.S
    cells = (
        (S[1], S[4]),  # (13,45) -> (14,35)
        (S[0], S[2]),  # (14,23) -> (13,24)
        (S[1], S[3]),  # (24,15) -> (14,25)
        (S[2], S[4]),  # (25,34) -> (24,35)
        (S[0], S[3]),  # (35,12) -> (13,25)
    )
    relations = {}
    missing = {}
    for cell in cells:
        relations[cell], missing[cell] = relation(model, *cell)
        assert relations[cell]

    full_relations = {
        cell: normalized_rows(rows) for cell, rows in relations.items()
    }
    fourway = {}
    total_anchors = 0
    extendible = 0
    unique = 0
    joined = 0
    equality_distribution = Counter()
    fibre_sizes = Counter()
    first_join = None
    for omitted in cells:
        chosen = tuple(cell for cell in cells if cell != omitted)
        common = set.intersection(*(set(full_relations[cell]) for cell in chosen))
        fourway[omitted] = len(common)
        assert not common
        for anchor in chosen:
            others = tuple(cell for cell in chosen if cell != anchor)
            anchor_missing = missing[anchor]
            for anchor_row in relations[anchor]:
                total_anchors += 1
                fibres = extension_sets(
                    anchor_row,
                    anchor_missing,
                    tuple((relations[cell], missing[cell]) for cell in others),
                )
                if not all(fibres):
                    continue
                extendible += 1
                fibre_sizes[tuple(sorted(map(len, fibres)))] += 1
                if all(len(fibre) == 1 for fibre in fibres):
                    unique += 1
                    agreements = sum(
                        bool(fibres[i] & fibres[j])
                        for i, j in combinations(range(3), 2)
                    )
                    equality_distribution[agreements] += 1
                if set.intersection(*(set(fibre) for fibre in fibres)):
                    joined += 1
                    if first_join is None:
                        first_join = (omitted, anchor, anchor_row, others, fibres)

    assert joined == 0
    assert all(value == 0 for value in fourway.values())
    assert unique > 0
    assert equality_distribution.get(2, 0) == 0
    assert equality_distribution.get(3, 0) == 0
    print({
        "relation_sizes": {str(cell): len(relations[cell]) for cell in cells},
        "fourway_join_sizes": {str(cell): value for cell, value in fourway.items()},
        "anchors": total_anchors,
        "extendible_stars": extendible,
        "unique_extension_stars": unique,
        "fibre_size_distribution": dict(sorted(fibre_sizes.items(), key=str)),
        "equality_edge_distribution": dict(sorted(equality_distribution.items())),
        "joined_stars": joined,
        "model_is_abstract": True,
    })
    print("D5_UE2_EXACT40_ABSTRACT_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
