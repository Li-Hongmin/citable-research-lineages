#!/usr/bin/env python3
"""Check whether failed 37-PM pivot stars locally splice to forbidden T types."""

from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
GATE_PATH = (
    HERE.parents[1]
    / "scratch/worker-bf-5cut-common-incidence"
    / "verify_c5_fibre_and_disjoint_four_gate.py"
)


def load_gate():
    spec = spec_from_file_location("fixed_d5_gate", GATE_PATH)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def exact_cover(matchings, edge_count):
    loads = [0] * edge_count
    for matching in matchings:
        for edge in matching:
            loads[edge] += 1
    return all(load == 2 for load in loads)


def main():
    gate = load_gate()
    interface = gate.load_existing_interface()
    data = interface.joint.matching_data(
        interface.loop_interface.pole(interface.loop_interface.ALL_SS_EDGES)
    )
    edges, _, _, _, classes, matching_count = data
    matchings = sorted({matching for fibre in classes.values() for matching in fibre})
    matching_id = {matching: index for index, matching in enumerate(matchings)}
    assert matching_count == len(matchings) == 37

    def missing(cell):
        answer = set(range(1, 6)) - set(cell[0]) - set(cell[1])
        assert len(answer) == 1
        return answer.pop()

    def cell_witnesses(cell):
        first, second = cell
        positions = tuple(index for index in range(1, 6) if index != missing(cell))
        answer = {}
        for singletons in product(*(classes[(index,)] for index in first + second)):
            values = dict(zip(first + second, singletons, strict=True))
            core = tuple(matching_id[values[index]] for index in positions)
            for q_first in classes[interface.joint.complement(first)]:
                for q_second in classes[interface.joint.complement(second)]:
                    witness = (q_first, q_second) + singletons
                    if exact_cover(witness, len(edges)):
                        ids = tuple(matching_id[item] for item in witness)
                        answer.setdefault(core, set()).add(ids)
        return {core: tuple(sorted(witnesses)) for core, witnesses in answer.items()}

    relations = {cell: cell_witnesses(cell) for cell in gate.D5}

    # Canonical forbidden covers: all T-loops and unordered T--T types.
    forbidden = {}
    t_states = sorted(interface.joint.T)
    for first_index, first in enumerate(t_states):
        for second in t_states[first_index:]:
            for q_first in classes[interface.joint.complement(first)]:
                for q_second in classes[interface.joint.complement(second)]:
                    for singletons in product(
                        *(classes[(index,)] for index in first + second)
                    ):
                        witness = (q_first, q_second) + singletons
                        if exact_cover(witness, len(edges)):
                            ids = tuple(sorted(matching_id[item] for item in witness))
                            forbidden.setdefault(ids, (first, second))
    assert len(forbidden) == 115

    records = []
    for omitted in gate.D5:
        chosen = tuple(cell for cell in gate.D5 if cell != omitted)
        for anchor in chosen:
            anchor_missing = missing(anchor)
            anchor_positions = tuple(
                index for index in range(1, 6) if index != anchor_missing
            )
            for anchor_core, anchor_witnesses in relations[anchor].items():
                anchor_values = dict(zip(anchor_positions, anchor_core, strict=True))
                extensions = []
                for cell in chosen:
                    if cell == anchor:
                        continue
                    cell_missing = missing(cell)
                    positions = tuple(
                        index for index in range(1, 6) if index != cell_missing
                    )
                    compatible = []
                    for core, witnesses in relations[cell].items():
                        values = dict(zip(positions, core, strict=True))
                        overlap = set(anchor_positions) & set(positions)
                        if all(values[index] == anchor_values[index] for index in overlap):
                            compatible.append((values[anchor_missing], core, witnesses))
                    extensions.append((cell, compatible))
                if not all(compatible for _, compatible in extensions):
                    continue

                # These are exactly the 16 unique-extension stars reported by
                # audit_d5_pivot_extension_boundary.py.  Their four positive
                # rows also have unique six-PM completions in this pole.
                assert len(anchor_witnesses) == 1
                assert all(len(compatible) == 1 for _, compatible in extensions)
                assert all(
                    len(compatible[0][2]) == 1 for _, compatible in extensions
                )
                row_witnesses = [anchor_witnesses[0]] + [
                    compatible[0][2][0] for _, compatible in extensions
                ]
                pool = set().union(*(set(witness) for witness in row_witnesses))
                local_forbidden = tuple(
                    (kind, witness)
                    for witness, kind in forbidden.items()
                    if set(witness) <= pool
                )
                extension_values = tuple(
                    compatible[0][0] for _, compatible in extensions
                )
                agreement_edges = sum(
                    extension_values[left] == extension_values[right]
                    for left, right in combinations(range(3), 2)
                )
                records.append(
                    {
                        "omitted": omitted,
                        "anchor": anchor,
                        "anchor_core": anchor_core,
                        "extension_values": extension_values,
                        "agreement_edges": agreement_edges,
                        "row_witnesses": tuple(row_witnesses),
                        "local_forbidden": local_forbidden,
                    }
                )

    assert len(records) == 16
    assert Counter(record["agreement_edges"] for record in records) == {0: 9, 1: 7}
    local_distribution = Counter(len(record["local_forbidden"]) for record in records)
    assert local_distribution == {0: 2, 1: 7, 2: 2, 3: 5}

    exceptions = tuple(record for record in records if not record["local_forbidden"])
    assert len(exceptions) == 2
    expected_exceptions = {
        (
            ((1, 4), (2, 3)),
            (33, 16, 24, 0),
            (2, 12, 10),
        ),
        (
            ((2, 5), (3, 4)),
            (33, 16, 24, 0),
            (2, 4, 10),
        ),
    }
    assert {
        (record["omitted"], record["anchor_core"], record["extension_values"])
        for record in exceptions
    } == expected_exceptions

    # Even the nearest forbidden cover for either exception needs one PM not
    # occurring in any of its four positive row witnesses.
    nearest_external = []
    for record in exceptions:
        pool = set().union(*(set(witness) for witness in record["row_witnesses"]))
        distance = min(
            sum(matching not in pool for matching in witness)
            for witness in forbidden
        )
        assert distance == 1
        nearest_external.append(distance)

    print(
        {
            "extendible_stars": len(records),
            "agreement_edge_distribution": dict(
                sorted(Counter(record["agreement_edges"] for record in records).items())
            ),
            "local_forbidden_count_distribution": dict(sorted(local_distribution.items())),
            "no_local_forbidden_stars": tuple(
                {
                    "omitted": record["omitted"],
                    "anchor": record["anchor"],
                    "anchor_core": record["anchor_core"],
                    "extension_values": record["extension_values"],
                    "row_witnesses": record["row_witnesses"],
                }
                for record in exceptions
            ),
            "nearest_forbidden_external_occurrences": tuple(nearest_external),
        }
    )
    print("PIVOT_FORBIDDEN_SPLICING_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
