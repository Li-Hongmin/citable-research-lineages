#!/usr/bin/env python3
"""Local certificate for a support-preserving non-tree exchange blow-up.

The 3-pole J0 = K_{2,3} (equivalently K_{3,3} with one vertex deleted)
has no matching using all three ports.  Replace one internal proper edge of
J0 by the two-pole P-e0, where P is Petersen.  The resulting 3-pole J*
still has exactly the same BF boundary-support interface as J0, but every
external port has a fixed-outside local family of four perfect matchings
whose pairwise differences are one alternating cycle.  Hence a vertex
replacement by J* preserves all BF boundary support while forcing a K4 in
each nonempty singleton exchange graph.

This is a local graph certificate, not an exact-40 pole construction.  Its
purpose is to show that a median/tree exchange hypothesis cannot be inferred
from BF support alone (unless an additional irreducibility condition rules
out the support-preserving blow-up).
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement


def canon(u, v):
    return (u, v) if u < v else (v, u)


def enumerate_matchings(vertices, proper, ports):
    """Enumerate edge-object perfect matchings of a cubic k-pole."""
    proper = tuple(canon(*edge) for edge in proper)
    objects = proper + tuple((port, -1) for port in ports)
    incident = {vertex: [] for vertex in vertices}
    for index, (u, v) in enumerate(objects):
        incident[u].append((index, v))
        if v != -1:
            incident[v].append((index, u))
    output = []

    def rec(unmatched, chosen):
        if not unmatched:
            output.append(frozenset(chosen))
            return
        u = min(unmatched)
        for index, v in incident[u]:
            if v == -1:
                rec(unmatched - {u}, chosen + [index])
            elif v in unmatched:
                rec(unmatched - {u, v}, chosen + [index])

    rec(set(vertices), [])
    return tuple(output), objects


def components_on_symmetric_difference(first, second, objects, vertices):
    """Count proper alternating-cycle components after boundary cancellation."""
    difference = first ^ second
    graph = {vertex: set() for vertex in vertices}
    for index in difference:
        u, v = objects[index]
        if v == -1:
            raise AssertionError("boundary edge in purported same-port difference")
        graph[u].add(v)
        graph[v].add(u)
    unseen = {vertex for vertex in vertices if graph[vertex]}
    count = 0
    sizes = []
    while unseen:
        root = min(unseen)
        seen = {root}
        queue = deque([root])
        while queue:
            u = queue.popleft()
            for v in graph[u]:
                if v not in seen:
                    seen.add(v)
                    queue.append(v)
        unseen -= seen
        count += 1
        sizes.append(len(seen))
    return count, tuple(sorted(sizes))


def bf_cover_exists(matchings, edge_count):
    target = (2,) * edge_count
    for choice in combinations_with_replacement(range(len(matchings)), 6):
        loads = tuple(
            sum(index in matchings[row] for row in choice)
            for index in range(edge_count)
        )
        if loads == target:
            return choice
    return None


def is_connected(vertices, proper):
    graph = {vertex: set() for vertex in vertices}
    for u, v in proper:
        graph[u].add(v)
        graph[v].add(u)
    seen = {min(vertices)}
    queue = deque(seen)
    while queue:
        u = queue.popleft()
        for v in graph[u]:
            if v not in seen:
                seen.add(v)
                queue.append(v)
    return seen == set(vertices)


def build_j0():
    # K_{2,3}; ports are 2,3,4 and internal vertices are 0,1.
    vertices = frozenset(range(5))
    proper = tuple((left, right) for left in (0, 1) for right in (2, 3, 4))
    ports = (2, 3, 4)
    return vertices, proper, ports


def build_j2():
    # Petersen minus edge (0,1), with two ports at its endpoints.
    edges = (
        (0, 1), (0, 4), (0, 5), (1, 2), (1, 6),
        (2, 3), (2, 7), (3, 4), (3, 8), (4, 9),
        (5, 7), (5, 8), (6, 8), (6, 9), (7, 9),
    )
    vertices = frozenset(range(10))
    proper = tuple(edge for edge in edges if edge != (0, 1))
    ports = (0, 1)
    return vertices, proper, ports


def build_jstar():
    """Replace J0 edge (0,2) by a fresh copy of J2."""
    j0_vertices, j0_proper, j0_ports = build_j0()
    j2_vertices, j2_proper, j2_ports = build_j2()
    offset = 5
    vertices = frozenset(j0_vertices | {offset + vertex for vertex in j2_vertices})
    replaced = (0, 2)
    proper = [edge for edge in j0_proper if edge != replaced]
    proper.extend((offset + u, offset + v) for u, v in j2_proper)
    # Attach the two J2 ports to the endpoints of the replaced edge.
    proper.extend(((0, offset + j2_ports[0]), (2, offset + j2_ports[1])))
    ports = j0_ports
    return vertices, tuple(proper), ports, frozenset(
        index for index, edge in enumerate(tuple(canon(*e) for e in proper))
        if edge[0] >= offset and edge[1] >= offset
    )


def check_j2_state_and_cover():
    vertices, proper, ports = build_j2()
    matchings, objects = enumerate_matchings(vertices, proper, ports)
    semiedge_indices = tuple(len(proper) + index for index in range(2))
    states = defaultdict(list)
    for matching in matchings:
        state = sum(index in matching for index in semiedge_indices)
        states[state].append(matching)
    assert {state: len(rows) for state, rows in states.items()} == {0: 4, 2: 2}
    assert bf_cover_exists(matchings, len(objects)) is not None
    # The four no-port matchings form a K4 in the one-cycle exchange graph.
    no_port = states[0]
    for first, second in combinations(no_port, 2):
        count, sizes = components_on_symmetric_difference(
            first, second, objects, vertices
        )
        assert count == 1 and sizes[0] % 2 == 0
    return {
        "perfect_matchings": len(matchings),
        "state_counts": {str(state): len(rows) for state, rows in sorted(states.items())},
        "bf_cover": True,
        "no_port_exchange_K4": True,
    }


def check_j0_and_jstar():
    j0_vertices, j0_proper, j0_ports = build_j0()
    j0_matchings, j0_objects = enumerate_matchings(j0_vertices, j0_proper, j0_ports)
    j0_semiedges = tuple(len(j0_proper) + index for index in range(3))
    j0_states = defaultdict(list)
    for matching in j0_matchings:
        state = sum(index in matching for index in j0_semiedges)
        j0_states[state].append(matching)
    assert {state: len(rows) for state, rows in j0_states.items()} == {1: 6}
    assert bf_cover_exists(j0_matchings, len(j0_objects)) is not None

    vertices, proper, ports, j2_proper_indices = build_jstar()
    matchings, objects = enumerate_matchings(vertices, proper, ports)
    assert len(set(objects)) == len(objects)
    degree = {vertex: 0 for vertex in vertices}
    for u, v in proper:
        degree[u] += 1
        degree[v] += 1
    for port in ports:
        degree[port] += 1
    assert set(degree.values()) == {3}
    assert is_connected(vertices, proper)
    semiedges = tuple(len(proper) + index for index in range(3))
    by_port = defaultdict(list)
    for matching in matchings:
        used = tuple(port for port, index in zip(ports, semiedges) if index in matching)
        if len(used) == 1:
            by_port[used[0]].append(matching)
    assert set(by_port) == set(ports)

    # A K4 is certified by fixing every edge outside the internal J2 proper
    # edge set and varying only the four no-port J2 states.
    k4_groups = {}
    for port, rows in by_port.items():
        groups = defaultdict(list)
        for matching in rows:
            outside = frozenset(index for index in matching if index not in j2_proper_indices)
            groups[outside].append(matching)
        good = []
        for outside, group in groups.items():
            if len(group) != 4:
                continue
            if all(
                components_on_symmetric_difference(first, second, objects, vertices)[0] == 1
                for first, second in combinations(group, 2)
            ):
                good.append(group)
        assert len(good) >= 1, (port, {len(group) for group in groups.values()})
        k4_groups[port] = max(len(group) for group in good)

    # No matching of J* uses all three external ports: this is the parity-
    # preserving contraction invariant needed for support preservation.
    state_counts = Counter(
        sum(index in matching for index in semiedges) for matching in matchings
    )
    assert state_counts.get(3, 0) == 0
    assert bf_cover_exists(matchings, len(objects)) is not None

    # Contracting the Petersen two-pole back to its replaced J0 edge maps
    # every J* perfect matching to a J0 perfect matching.  This is the
    # matching-level part of support preservation, not a boundary-only
    # assertion.  The local fibre sizes are 2 for the two J0 matchings that
    # use the replaced edge and 4 for the other four.
    base_proper = tuple(canon(*edge) for edge in build_j0()[1])
    base_edge = canon(0, 2)
    base_objects = base_proper + tuple((port, -1) for port in build_j0()[2])
    j0_set = set(j0_matchings)
    attachment_indices = tuple(
        index for index, edge in enumerate(objects)
        if edge in (canon(0, 5 + 0), canon(2, 5 + 1))
    )
    assert len(attachment_indices) == 2
    projected = defaultdict(list)
    for matching in matchings:
        used_attachments = tuple(index for index in attachment_indices if index in matching)
        assert len(used_attachments) in (0, 2)
        row = [index for index in matching if index not in j2_proper_indices]
        row = [index for index in row if index not in attachment_indices]
        projected_edges = [objects[index] for index in row]
        if len(used_attachments) == 2:
            projected_edges.append(base_edge)
        projected_edge_indices = frozenset(
            base_objects.index(edge) for edge in projected_edges
        )
        assert projected_edge_indices in j0_set
        projected[projected_edge_indices].append(matching)
    assert sorted(len(rows) for rows in projected.values()) == [2, 2, 4, 4, 4, 4], {
        key: len(rows) for key, rows in projected.items()
    }
    return {
        "J0_perfect_matchings": len(j0_matchings),
        "J0_state_counts": {str(state): len(rows) for state, rows in sorted(j0_states.items())},
        "Jstar_vertices": len(vertices),
        "Jstar_proper_edges": len(proper),
        "Jstar_perfect_matchings": len(matchings),
        "Jstar_state_counts": {str(state): value for state, value in sorted(state_counts.items())},
        "Jstar_BF_cover": True,
        "K4_group_size_by_port": {str(port): value for port, value in sorted(k4_groups.items())},
        "Jstar_connected_cubic": True,
        "contraction_fibre_sizes": tuple(sorted(len(rows) for rows in projected.values())),
    }


def main():
    j2 = check_j2_state_and_cover()
    jstar = check_j0_and_jstar()
    print({"J2": j2, "J0_Jstar": jstar})
    print("PIVOT_MEDIAN_BLOWUP_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
