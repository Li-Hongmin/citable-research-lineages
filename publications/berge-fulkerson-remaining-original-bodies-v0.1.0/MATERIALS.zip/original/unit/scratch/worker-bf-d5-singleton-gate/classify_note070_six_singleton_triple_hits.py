#!/usr/bin/env python3
"""Classify forced triple-hit edges in the Note-070 failed-star singleton set."""

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parents[1]
    / "computations/bundles/failed-pivot-residual-selector-counterexample"
    / "verify_failed_pivot_residual_avoiding_pole.py"
)
SPEC = spec_from_file_location("note070", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def main():
    anchor = (33, 16, 24, 0)
    extensions = (2, 12, 10)
    family = anchor + extensions
    assert tuple(BASE.B[label] for label in anchor) == ((1,), (2,), (4,), (5,))
    assert all(BASE.B[label] == (3,) for label in extensions)
    records = []
    for selected in combinations(family, 6):
        loads = Counter(edge for label in selected for edge in BASE.VECTORS[label])
        hits = []
        for edge in BASE.PROPER:
            users = tuple(label for label in selected if edge in BASE.VECTORS[label])
            if len(users) >= 3:
                hits.append((edge, users))
        assert hits
        assert sum(len(BASE.VECTORS[label]) for label in selected) == 36
        assert 2 * len(BASE.PROPER) == 34
        records.append({
            "omitted": next(label for label in family if label not in selected),
            "triple_hits": tuple(hits),
            "overload_above_two": sum(max(0, load - 2) for load in loads.values()),
            "deficit_below_two": sum(max(0, 2 - loads[edge]) for edge in BASE.PROPER),
        })
    print({"singleton_family": family, "six_subsets": tuple(records)})
    print("NOTE070_SIX_SINGLETON_TRIPLE_HITS_CLASSIFIED")


if __name__ == "__main__":
    main()
