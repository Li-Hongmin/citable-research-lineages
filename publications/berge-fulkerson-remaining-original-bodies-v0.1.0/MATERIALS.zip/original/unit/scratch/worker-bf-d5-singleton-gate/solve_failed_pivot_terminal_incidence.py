#!/usr/bin/env python3
"""SAT test for a failed pivot star in common trivalent vertex incidence.

Each perfect-matching identity chooses one of the two proper half-edges at a
terminal unless its boundary uses the semiedge.  The four positive rows have
load two on all three incident edges.  Every five-occurrence selector whose
boundary residual would complete a T-loop/T--T cover is forced to have load
zero or at least three at some terminal or internal vertex.  Internal
vertices are independent at this abstraction layer; proper-edge endpoint
pairing is reserved for a subsequent real-pole realization test.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations

from z3 import Bool, Not, Or, PbEq, PbGe, Solver, sat, unknown


POSITIONS = tuple(range(1, 6))
S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}

# First exceptional star from audit_pivot_forbidden_splicing_boundary.py.
ROWS = (
    (((2, 4), (1, 5)), (28, 11, 16, 24, 33, 0)),
    (((1, 3), (4, 5)), (18, 35, 33, 2, 24, 0)),
    (((2, 5), (3, 4)), (31, 29, 16, 0, 12, 24)),
    (((3, 5), (1, 2)), (34, 17, 10, 0, 33, 16)),
)


def complement(pair):
    return tuple(sorted(set(POSITIONS) - set(pair)))


def pool_boundaries():
    answer = {}
    for (first, second), row in ROWS:
        assignments = ((row[0], complement(first)), (row[1], complement(second)))
        assignments += tuple(zip(row[2:], ((i,) for i in first + second), strict=True))
        for matching, boundary in assignments:
            if matching in answer:
                assert answer[matching] == boundary
            answer[matching] = boundary
    assert len(answer) == 15
    return answer


def forbidden_residual(boundaries, selector):
    loads = {position: sum(position in boundaries[item] for item in selector)
             for position in POSITIONS}
    if not all(value in (1, 2) for value in loads.values()):
        return None
    residual = tuple(position for position, value in loads.items() if value == 1)
    six = [boundaries[item] for item in selector] + [residual]
    if sorted(map(len, six)) != [1, 1, 1, 1, 3, 3]:
        return None
    pairs = tuple(sorted(complement(boundary) for boundary in six if len(boundary) == 3))
    return pairs if all(pair in T for pair in pairs) else None


def weighted_terms(selector, variables, position):
    counts = Counter(item for item in selector if position not in BOUNDARIES[item])
    return [(variables[(item, position)], count) for item, count in counts.items()]


BOUNDARIES = pool_boundaries()
OCCURRENCES = tuple(item for _, row in ROWS for item in row)
SELECTORS = {}
for chosen in combinations(range(len(OCCURRENCES)), 5):
    selector = tuple(sorted(OCCURRENCES[index] for index in chosen))
    kind = forbidden_residual(BOUNDARIES, selector)
    if kind is not None:
        SELECTORS.setdefault(selector, kind)


def main():
    # First decide which selectors can be made bad at an ordinary internal
    # cubic vertex.  One such vertex can be supplied per killable selector,
    # so only selectors forced good at every internal vertex need to be
    # killed by the five terminal vertices.
    internal = Solver()
    internal_variables = {
        (matching, edge): Bool(f"i_{matching}_{edge}")
        for matching in BOUNDARIES for edge in range(3)
    }
    for matching in BOUNDARIES:
        internal.add(PbEq(
            [(internal_variables[(matching, edge)], 1) for edge in range(3)], 1
        ))
    for _, row in ROWS:
        for edge in range(3):
            internal.add(PbEq(
                [(internal_variables[(matching, edge)], count)
                 for matching, count in Counter(row).items()], 2
            ))
    internal.set(timeout=300000)
    assert internal.check() == sat

    internal_witnesses = {}
    forced_good = {}
    for selector, kind in sorted(SELECTORS.items()):
        bad_edges = []
        counts = Counter(selector)
        for edge in range(3):
            terms = [(internal_variables[(matching, edge)], count)
                     for matching, count in counts.items()]
            bad_edges.extend((PbEq(terms, 0), PbGe(terms, 3)))
        internal.push()
        internal.add(Or(bad_edges))
        local_status = internal.check()
        if local_status == sat:
            model = internal.model()
            internal_witnesses[selector] = tuple(
                tuple(sorted(matching for matching in BOUNDARIES
                             if bool(model.eval(internal_variables[(matching, edge)]))))
                for edge in range(3)
            )
        elif local_status == unknown:
            print({"status": "unknown", "stage": "internal_vertex",
                   "selector": selector, "reason": internal.reason_unknown()})
            print("FAILED_PIVOT_TRIVALENT_INCIDENCE_UNKNOWN")
            return
        else:
            forced_good[selector] = kind
        internal.pop()

    variables = {
        (matching, position): Bool(f"a_{matching}_{position}")
        for matching, boundary in BOUNDARIES.items()
        for position in POSITIONS if position not in boundary
    }
    solver = Solver()

    # At each terminal, A/B are its two proper incident half-edges.  Every
    # positive six-PM row has two occurrences on A, two on B, and two on the
    # fixed semiedge.
    tracked = {}
    for row_index, (_, row) in enumerate(ROWS):
        for position in POSITIONS:
            assert sum(position in BOUNDARIES[item] for item in row) == 2
            label = Bool(f"row_{row_index}_terminal_{position}")
            tracked[str(label)] = {"row": row_index, "terminal": position}
            solver.assert_and_track(
                PbEq(weighted_terms(row, variables, position), 2), label
            )

    assert solver.check() == sat
    row_only_status = "sat"

    # A selector is good at a terminal exactly when its two proper loads and
    # fixed semiedge load all lie in {1,2}.  Only the selectors which cannot
    # be killed at any internal vertex must be bad at a terminal.
    selector_labels = {}
    for selector_index, (selector, kind) in enumerate(sorted(forced_good.items())):
        bad_vertices = []
        for position in POSITIONS:
            port_load = sum(position in BOUNDARIES[item] for item in selector)
            terms = weighted_terms(selector, variables, position)
            if port_load == 1:
                good = PbEq(terms, 2)
            else:
                assert port_load == 2
                good = Or(PbEq(terms, 1), PbEq(terms, 2))
            bad_vertices.append(Not(good))
        label = Bool(f"selector_{selector_index}")
        selector_labels[str(label)] = {
            "selector": selector,
            "forbidden_type": kind,
        }
        solver.assert_and_track(Or(bad_vertices), label)

    solver.set(timeout=300000)
    status = solver.check()
    output = {
        "status": str(status),
        "pool_matchings": len(BOUNDARIES),
        "row_covers": len(ROWS),
        "row_only_status": row_only_status,
        "forbidden_boundary_selectors": len(SELECTORS),
        "internal_killable_selectors": len(internal_witnesses),
        "internal_forced_good_selectors": len(forced_good),
    }
    if status == sat:
        model = solver.model()
        output["terminal_choices_A"] = {
            position: tuple(sorted(
                matching for matching, boundary in BOUNDARIES.items()
                if position not in boundary and bool(model.eval(variables[(matching, position)]))
            ))
            for position in POSITIONS
        }
        for selector in forced_good:
            assert any(
                (lambda load, total: load == 0 or load >= 3 or total - load == 0 or total - load >= 3)(
                    sum(count * int(bool(model.eval(variable)))
                        for variable, count in weighted_terms(selector, variables, position)),
                    5 - sum(position in BOUNDARIES[item] for item in selector),
                )
                for position in POSITIONS
            )
        output["internal_witness_vertex_upper_bound"] = len(internal_witnesses)
        output["first_internal_witness"] = (
            next(iter(internal_witnesses.items())) if internal_witnesses else None
        )
        print(output)
        print("FAILED_PIVOT_TRIVALENT_INCIDENCE_SAT")
    elif status == unknown:
        output["reason"] = solver.reason_unknown()
        print(output)
        print("FAILED_PIVOT_TRIVALENT_INCIDENCE_UNKNOWN")
    else:
        core = tuple(sorted(str(item) for item in solver.unsat_core()))
        output["unsat_core_size"] = len(core)
        output["unsat_core_rows"] = tuple(
            tracked[item] for item in core if item in tracked
        )
        output["unsat_core_selectors"] = tuple(
            selector_labels[item] for item in core if item in selector_labels
        )
        print(output)
        print("FAILED_PIVOT_TRIVALENT_INCIDENCE_UNSAT")


if __name__ == "__main__":
    main()
