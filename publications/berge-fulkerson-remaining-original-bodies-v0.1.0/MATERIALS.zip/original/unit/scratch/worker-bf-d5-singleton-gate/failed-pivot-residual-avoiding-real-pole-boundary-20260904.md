# A bridge-free cubic pole avoids every forbidden residual selector

## Decision

The four positive D5 cover equations of the first exceptional pivot identity
pattern do not force a five-occurrence forbidden residual, even after imposing
one common simple connected cubic 5-pole and requiring all fifteen designated
matching identities to be different actual perfect matchings.

A directed (n=13) synthesis produced the proper-edge set

\[
\begin{aligned}
&(0,10),(0,11),(1,8),(1,9),(2,9),(2,10),(3,7),(3,12),\
&(4,6),(4,7),(5,6),(5,7),(5,8),(6,12),(8,11),(9,11),(10,12).
\end{aligned}
\]

There is one semiedge at each of vertices (0,1,2,3,4).  An independent
pure-stdlib verifier establishes that this is a simple connected cubic
5-pole, has no bridge, and has exactly 36 perfect matchings.  The fifteen
specified vectors are pairwise distinct members of that complete family.
Each of the four designated six-PM rows has load two on every proper edge and
semiedge.  The three anchor-compatible class-(P_3) extensions are the
distinct specified matchings labelled (2,12,10).

The 24 row occurrences give exactly 79 distinct five-occurrence selectors
whose boundary residual would complete a (T)-loop or (T)--(T) type.
Every one of the 79 selectors has load zero or at least three on an actual
proper edge of this pole.  Hence none satisfies the interval
(1\leq\ell_F\leq2), and the residual-complement lemma cannot fire from
these four rows.

This is a genuine common-cubic-incidence counterexample to the fixed
all-distinct identity-pattern selector implication.  It is not a theorem
about every failed pivot identity partition, and it does not assert that the
complete D5 relations of this pole have unique extension fibres.

## Exact support boundary

The pole is bridge-free but has girth four.  Its complete closure is:

\[
\#\mathcal P(H)=36,qquad
|\operatorname{BFsupp}(H)|=48=15_{SS}+21_{ST}+12_{TT}.
\]

It has no (A=(12345)) cover.  Its Tait-state set consists of nine of the ten
pair states, with (45) the only missing state.  Thus the first failure of
the Case-XII exact-support hypothesis is already the nonempty (TT) support;
the (ST) support is also incomplete ((21/25)).  The example therefore
does not realize exact BF-40 and, because of its 4-cycle, does not cover a
girth-five side condition.

The one permitted strengthened synthesis kept (n=13), connectedness,
distinct matching identities and all 79 residual blockers, and additionally
forbade triangles and 4-cycles.  Z3 returned `unknown` with reason `timeout`
after its 300-second limit.  This is not UNSAT, and no larger order was run.

## Reproduction

The fixed pole is checked by

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/verify_failed_pivot_residual_avoiding_pole.py
```

ending with

```text
FAILED_PIVOT_RESIDUAL_AVOIDING_POLE_VERIFIED
```

The directed synthesis entry is

```text
units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/synthesize_failed_pivot_residual_avoiding_pole.py
```

Run without `--girth5` for the frozen girth-four model and with `--girth5`
for the fixed-order strengthened query.  The Omen run directory was

```text
[local archival reference]
```

No graph census or order expansion was used.
