#!/usr/bin/env python3
"""Fixed-pole audit for the Case-XII D5 singleton pivot obstruction.

This is not a graph census.  It reuses the two frozen order-13 cubic
5-poles and their complete perfect-matching families.  For every four-of-
five D5 family it fixes one cell as an anchor and reduces the natural join
to three extension sets in the single singleton class omitted by the
anchor.
"""

from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
UNIT = HERE.parents[1]
GATE = (
    UNIT
    / "scratch/worker-bf-5cut-common-incidence"
    / "verify_c5_fibre_and_disjoint_four_gate.py"
)


def load_gate_module():
    spec = spec_from_file_location("fixed_d5_gate", GATE)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def missing_position(cell) -> int:
    missing = set(range(1, 6)) - set(cell[0]) - set(cell[1])
    assert len(missing) == 1
    return missing.pop()


def core_relation(cylinder, cell):
    """Remove the arbitrary coordinate from a five-coordinate cylinder."""
    missing = missing_position(cell)
    positions = tuple(index for index in range(1, 6) if index != missing)
    return frozenset(
        tuple(row[index - 1] for index in positions) for row in cylinder
    )


def extension_sets(anchor_cell, anchor_core, other_cells, cores):
    """Return the three possible values in the anchor's missing class."""
    missing = missing_position(anchor_cell)
    anchor_positions = tuple(index for index in range(1, 6) if index != missing)
    anchor = dict(zip(anchor_positions, anchor_core, strict=True))
    answer = []
    for cell in other_cells:
        cell_missing = missing_position(cell)
        positions = tuple(index for index in range(1, 6) if index != cell_missing)
        overlap = set(anchor_positions) & set(positions)
        values = set()
        for row in cores[cell]:
            candidate = dict(zip(positions, row, strict=True))
            if all(candidate[index] == anchor[index] for index in overlap):
                values.add(candidate[missing])
        answer.append(frozenset(values))
    assert len(answer) == 3
    return tuple(answer)


def audit_pole(gate, interface, edges):
    data = interface.joint.matching_data(interface.loop_interface.pole(edges))
    cylinders = {
        cell: interface.cell_projection(data, cell) for cell in gate.D5
    }
    assert all(cylinders.values())
    cores = {
        cell: core_relation(cylinders[cell], cell) for cell in gate.D5
    }

    intersection_counts = {}
    for size in (2, 3, 4):
        values = tuple(
            len(set.intersection(*(set(cylinders[cell]) for cell in chosen)))
            for chosen in combinations(gate.D5, size)
        )
        intersection_counts[size] = {
            "nonempty": sum(value > 0 for value in values),
            "total": len(values),
            "sizes": values,
        }

    total_anchors = 0
    extendible_stars = 0
    unique_extension_stars = 0
    equality_edge_distribution = Counter()
    joined_stars = 0

    # Each omitted D5 cell leaves one four-cell family.  Choose every member
    # of that family in turn as the anchor.
    for omitted in gate.D5:
        chosen = tuple(cell for cell in gate.D5 if cell != omitted)
        for anchor_cell in chosen:
            others = tuple(cell for cell in chosen if cell != anchor_cell)
            for anchor_core in cores[anchor_cell]:
                total_anchors += 1
                extensions = extension_sets(
                    anchor_cell, anchor_core, others, cores
                )
                if not all(extensions):
                    continue
                extendible_stars += 1
                if all(len(values) == 1 for values in extensions):
                    unique_extension_stars += 1
                equality_edges = sum(
                    bool(extensions[left] & extensions[right])
                    for left, right in combinations(range(3), 2)
                )
                equality_edge_distribution[equality_edges] += 1
                if set.intersection(*(set(values) for values in extensions)):
                    joined_stars += 1

    # The pivot lemma is exact: a joined star is the same thing as a
    # four-cylinder tuple, counted once for each possible anchor cell/core.
    assert joined_stars == 0
    assert intersection_counts[4]["nonempty"] == 0

    return {
        "perfect_matchings": data[-1],
        "cylinder_sizes": tuple(len(cylinders[cell]) for cell in gate.D5),
        "core_sizes": tuple(len(cores[cell]) for cell in gate.D5),
        "intersection_counts": intersection_counts,
        "pivot": {
            "anchors": total_anchors,
            "extendible_stars": extendible_stars,
            "unique_extension_stars": unique_extension_stars,
            "equality_edge_distribution": dict(sorted(equality_edge_distribution.items())),
            "joined_stars": joined_stars,
        },
    }


def main() -> None:
    gate = load_gate_module()
    interface = gate.load_existing_interface()
    records = {
        "exact_s_c10": audit_pole(
            gate, interface, interface.loop_interface.C10_EDGES
        ),
        "all_st_no_a": audit_pole(
            gate, interface, interface.loop_interface.ALL_SS_EDGES
        ),
    }

    # Recheck the exact status of the two real boundaries from their full
    # complete-PM support, rather than relying on their historical labels.
    c10_record = interface.joint.pole_record(
        "exact_s_c10", {}, interface.loop_interface.pole(
            interface.loop_interface.C10_EDGES
        )
    )
    all_st_record = interface.joint.pole_record(
        "all_st_no_a", {}, interface.loop_interface.pole(
            interface.loop_interface.ALL_SS_EDGES
        )
    )
    assert c10_record["has_A"] and len(c10_record["st_support"]) == 17
    assert len(c10_record["support"]) == 40
    assert not all_st_record["has_A"]
    assert len(all_st_record["st_support"]) == 25
    # All 55 unordered pair types occur: the ten extra T--T types and five
    # T-loops are precisely why this pole is not the 40-type target.
    assert len(all_st_record["support"]) == 55

    assert records["exact_s_c10"]["perfect_matchings"] == 31
    assert records["exact_s_c10"]["pivot"] == {
        "anchors": 64,
        "extendible_stars": 0,
        "unique_extension_stars": 0,
        "equality_edge_distribution": {},
        "joined_stars": 0,
    }
    assert records["all_st_no_a"]["perfect_matchings"] == 37
    assert records["all_st_no_a"]["pivot"] == {
        "anchors": 452,
        "extendible_stars": 16,
        "unique_extension_stars": 16,
        "equality_edge_distribution": {0: 9, 1: 7},
        "joined_stars": 0,
    }
    assert records["exact_s_c10"]["intersection_counts"][2]["nonempty"] == 4
    assert records["exact_s_c10"]["intersection_counts"][3]["nonempty"] == 1
    assert records["all_st_no_a"]["intersection_counts"][2]["nonempty"] == 8
    assert records["all_st_no_a"]["intersection_counts"][3]["nonempty"] == 3

    print({"D5": gate.D5, "records": records})
    print("D5_PIVOT_EXTENSION_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
