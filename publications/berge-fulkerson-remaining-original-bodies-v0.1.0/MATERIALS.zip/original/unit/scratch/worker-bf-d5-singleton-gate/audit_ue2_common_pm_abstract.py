#!/usr/bin/env python3
"""Audit the UE2 pivot condition in one shared-PM incidence model.

This is deliberately a finite incidence calculation, not a cubic-pole
construction.  It imports the global vector pool from
``common_pm_guarded_incidence_model.py`` and computes the five disjoint
S--S relations obtained from the D5 transfer.  It then checks every
four-of-five cylinder and every anchored three-fibre star.  The purpose is
to decide whether UE2 is forced by common binary incidence plus exact
six-vector loads; a negative result is only an abstract route boundary.
"""

from __future__ import annotations

from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
MODEL_PATH = (
    HERE.parent / "worker-bf-common-pm-proof"
    / "common_pm_guarded_incidence_model.py"
)


def load_model_module():
    spec = spec_from_file_location("shared_pm_model", MODEL_PATH)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def matching_load(supports, labels, coordinate_count):
    loads = [0] * coordinate_count
    for label in labels:
        vector = supports[label]
        for coordinate in range(coordinate_count):
            loads[coordinate] += (vector >> coordinate) & 1
    return loads


def relation(model, first, second):
    """Return all actual singleton tuples in a disjoint S--S cell.

    A tuple is represented as ``(P_1,...,P_5)`` with ``None`` in the one
    omitted position.  Each tuple is retained iff some global vectors in
    the two triple classes solve the exact coordinatewise load equation.
    """
    classes = model["classes"]
    supports = model["supports"]
    coordinate_count = model["coordinate_count"]
    first_vectors = [vector for _, vector in classes[first]]
    second_vectors = [vector for _, vector in classes[second]]
    slots = tuple(first + second)
    missing = tuple(set(range(1, 6)) - set(slots))
    assert len(missing) == 1
    missing = missing[0]
    singleton_classes = [
        [label for label in model["labels"] if label[0] == position]
        for position in range(1, 6)
    ]
    answer = set()
    for selected in product(*(singleton_classes[position - 1] for position in slots)):
        loads = matching_load(supports, selected, coordinate_count)
        for first_vector in first_vectors:
            for second_vector in second_vectors:
                if all(
                    ((first_vector >> coordinate) & 1)
                    + ((second_vector >> coordinate) & 1)
                    + loads[coordinate]
                    == 2
                    for coordinate in range(coordinate_count)
                ):
                    row = [None] * 5
                    for position, label in zip(slots, selected, strict=True):
                        row[position - 1] = label
                    answer.add(tuple(row))
                    break
            else:
                continue
            break
    return frozenset(answer), missing


def extension_sets(anchor_row, anchor_missing, other_relation_rows):
    """Compute the three UE2 extension fibres for one anchor row."""
    answer = []
    for rows, other_missing in other_relation_rows:
        assert anchor_row[anchor_missing - 1] is None
        assert rows and all(row[other_missing - 1] is None for row in rows)
        values = set()
        shared = [
            position for position in range(1, 6)
            if position != anchor_missing and position != other_missing
        ]
        for row in rows:
            if all(row[position - 1] == anchor_row[position - 1] for position in shared):
                value = row[anchor_missing - 1]
                assert value is not None
                values.add(value)
        answer.append(frozenset(values))
    return tuple(answer)


def main():
    model_module = load_model_module()
    model = model_module.build_model()
    S = tuple(model_module.S)
    # D5 transfer table from Note 047, expressed as disjoint S--S cells.
    cells = (
        (S[1], S[4]),  # (13,45) -> (14,35)
        (S[0], S[2]),  # (14,23) -> (13,24)
        (S[1], S[3]),  # (24,15) -> (14,25)
        (S[2], S[4]),  # (25,34) -> (24,35)
        (S[0], S[3]),  # (35,12) -> (13,25)
    )
    relations = {}
    missing = {}
    for cell in cells:
        relations[cell], missing[cell] = relation(model, *cell)
        assert relations[cell]

    fourway = {}
    total_anchors = 0
    extendible = 0
    unique = 0
    joined = 0
    first_join = None
    equality_distribution = Counter()
    fibre_size_distribution = Counter()
    for omitted in cells:
        chosen = tuple(cell for cell in cells if cell != omitted)
        common = set.intersection(*(set(relations[cell]) for cell in chosen))
        fourway[omitted] = len(common)
        assert not common
        for anchor in chosen:
            others = tuple(cell for cell in chosen if cell != anchor)
            anchor_missing = missing[anchor]
            for anchor_row in relations[anchor]:
                total_anchors += 1
                fibres = extension_sets(
                    anchor_row,
                    anchor_missing,
                    tuple((relations[cell], missing[cell]) for cell in others),
                )
                if not all(fibres):
                    continue
                extendible += 1
                fibre_size_distribution[tuple(sorted(map(len, fibres)))] += 1
                if all(len(fibre) == 1 for fibre in fibres):
                    unique += 1
                    edge_count = sum(
                        bool(fibres[i] & fibres[j])
                        for i, j in combinations(range(3), 2)
                    )
                    equality_distribution[edge_count] += 1
                if set.intersection(*(set(fibre) for fibre in fibres)):
                    joined += 1
                    if first_join is None:
                        first_join = (omitted, anchor, anchor_row, others, fibres)

    # The model's original verifier establishes all 15 S--S and all 25 S--T
    # cells, and excludes A/T-loop/TT support.  Reassert those gates here so
    # this audit cannot silently run on a different model branch.
    model_module.check_relation_bundle(model)
    model_module.check_support(model)
    model_module.check_exchange_closure(model)

    print({
        "cells": cells,
        "relation_sizes": {str(cell): len(relations[cell]) for cell in cells},
        "fourway_join_sizes": {str(cell): value for cell, value in fourway.items()},
        "anchors": total_anchors,
        "extendible_stars": extendible,
        "unique_extension_stars": unique,
        "fibre_size_distribution": dict(sorted(fibre_size_distribution.items(), key=str)),
        "equality_edge_distribution": dict(sorted(equality_distribution.items())),
        "joined_stars": joined,
        "first_join": first_join,
        "model_is_abstract": True,
    })
    print("D5_UE2_COMMON_PM_ABSTRACT_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
