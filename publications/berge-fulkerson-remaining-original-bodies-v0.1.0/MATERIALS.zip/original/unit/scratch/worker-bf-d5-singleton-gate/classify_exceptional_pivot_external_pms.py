#!/usr/bin/env python3
"""Classify the one-external-PM forbidden covers of the two pivot exceptions."""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations_with_replacement, product

import audit_pivot_forbidden_splicing_boundary as pivot


EXCEPTIONS = (
    {
        "omitted": ((1, 4), (2, 3)),
        "rows": (
            (28, 11, 16, 24, 33, 0),
            (18, 35, 33, 2, 24, 0),
            (31, 29, 16, 0, 12, 24),
            (34, 17, 10, 0, 33, 16),
        ),
    },
    {
        "omitted": ((2, 5), (3, 4)),
        "rows": (
            (28, 11, 16, 24, 33, 0),
            (18, 35, 33, 2, 24, 0),
            (7, 27, 33, 24, 16, 4),
            (34, 17, 10, 0, 33, 16),
        ),
    },
)


def main():
    gate = pivot.load_gate()
    interface = gate.load_existing_interface()
    joint = interface.joint
    data = joint.matching_data(
        interface.loop_interface.pole(interface.loop_interface.ALL_SS_EDGES)
    )
    edges, edge_vertices, _, incidence, classes, matching_count = data
    matchings = sorted({matching for fibre in classes.values() for matching in fibre})
    matching_id = {matching: index for index, matching in enumerate(matchings)}
    boundary = {
        matching_id[matching]: fibre
        for fibre, family in classes.items()
        for matching in family
    }
    assert matching_count == len(matchings) == 37

    def covers(kind):
        first, second = kind
        answer = set()
        for q_first in classes[joint.complement(first)]:
            for q_second in classes[joint.complement(second)]:
                for singletons in product(*(classes[(i,)] for i in first + second)):
                    witness = (q_first, q_second) + singletons
                    if pivot.exact_cover(witness, len(edges)):
                        answer.add(tuple(sorted(matching_id[item] for item in witness)))
        return frozenset(answer)

    positive_types = tuple(combinations_with_replacement(sorted(joint.S), 2)) + tuple(
        sorted(tuple(sorted((s, t))) for s in joint.S for t in joint.T)
    )
    assert len(positive_types) == 40
    positive = {kind: covers(kind) for kind in positive_types}
    assert all(positive.values())

    forbidden = {}
    t_states = sorted(joint.T)
    for index, first in enumerate(t_states):
        for second in t_states[index:]:
            for witness in covers((first, second)):
                forbidden.setdefault(witness, (first, second))
    assert len(forbidden) == 115

    reports = []
    for exception in EXCEPTIONS:
        omitted = exception["omitted"]
        chosen = set(gate.D5) - {omitted}
        chosen_positive = {tuple(sorted(cell)) for cell in chosen}
        pool = set().union(*(set(row) for row in exception["rows"]))

        # Recheck the four hard-coded rows against the frozen pole and cells.
        row_types = set()
        for row in exception["rows"]:
            actual = tuple(matchings[item] for item in row)
            assert pivot.exact_cover(actual, len(edges))
            labels = tuple(
                tuple(sorted(set(range(1, 6)) - set(boundary[item])))
                for item in row[:2]
            )
            kind = (next(item for item in labels if item in joint.S),
                    next(item for item in labels if item in joint.T))
            row_types.add(kind)
        assert row_types == chosen

        nearest = []
        for witness, kind in forbidden.items():
            external = tuple(item for item in witness if item not in pool)
            if len(external) == 1:
                nearest.append((external[0], kind, witness))
        assert nearest

        by_external = defaultdict(list)
        for external, kind, witness in nearest:
            by_external[external].append((kind, witness))

        external_reports = []
        for external in sorted(by_external):
            same_class_pool = sorted(item for item in pool if boundary[item] == boundary[external])
            distances = []
            for local in same_class_pool:
                components = joint.symmetric_component_count(
                    matchings[external], matchings[local], edges, edge_vertices
                )
                symmetric_edges = len(set(matchings[external]) ^ set(matchings[local]))
                distances.append((components, symmetric_edges, local))
            assert distances
            minimum = min((components, symmetric_edges)
                          for components, symmetric_edges, _ in distances)
            positive_usage = {
                joint.human(kind): sum(external in witness for witness in witnesses)
                for kind, witnesses in positive.items()
                if any(external in witness for witness in witnesses)
            }
            other_usage = {
                joint.human(kind): positive_usage[joint.human(kind)]
                for kind in positive
                if kind not in chosen_positive and joint.human(kind) in positive_usage
            }
            forbidden_occurrences = []
            for kind, witness in sorted(by_external[external], key=str):
                remaining = list(witness)
                remaining.remove(external)
                assert all(item in pool for item in remaining)
                load = [0] * len(edges)
                for item in remaining:
                    for edge in matchings[item]:
                        load[edge] += 1
                residual = tuple(edge for edge, value in enumerate(load) if value == 1)
                assert set(load) <= {1, 2}
                assert residual == matchings[external]
                assert all(
                    sum(edges.index(edge) in residual for edge in incident) == 1
                    for incident in incidence.values()
                )
                forbidden_occurrences.append(
                    {
                        "residual_from_five_pool_pms": True,
                        "other_five_load_counts": {
                            value: load.count(value) for value in (1, 2)
                        },
                        "other_five": tuple(remaining),
                        "type": joint.human(kind),
                        "witness": witness,
                    }
                )
            external_reports.append(
                {
                    "pm": external,
                    "boundary": boundary[external],
                    "all_occurrences_are_unique_residuals": all(
                        item["residual_from_five_pool_pms"]
                        for item in forbidden_occurrences
                    ),
                    "nearest_pool_distance": {
                        "alternating_components": minimum[0],
                        "symmetric_difference_edges": minimum[1],
                        "pool_pms": tuple(local for components, symmetric_edges, local in distances
                                          if (components, symmetric_edges) == minimum),
                    },
                    "same_class_pool_distances": tuple(sorted(distances)),
                    "forbidden_occurrences": tuple(forbidden_occurrences),
                    "positive_cell_witness_counts": dict(sorted(positive_usage.items())),
                    "other_positive_cell_witness_counts": dict(sorted(other_usage.items())),
                }
            )

        reports.append(
            {
                "omitted": omitted,
                "four_row_pool": tuple(sorted(pool)),
                "one_external_forbidden_cover_count": len(nearest),
                "external_pms": tuple(external_reports),
            }
        )

    signatures = []
    for report in reports:
        signatures.append(tuple(
            (
                item["boundary"],
                item["nearest_pool_distance"]["alternating_components"],
                tuple(item["other_positive_cell_witness_counts"]),
                tuple(entry["type"] for entry in item["forbidden_occurrences"]),
            )
            for item in report["external_pms"]
        ))
    shared_source_pattern = signatures[0] == signatures[1]

    output = {
        "matching_count": matching_count,
        "positive_cells": len(positive),
        "forbidden_covers": len(forbidden),
        "exceptions": tuple(reports),
        "source_signatures": tuple(signatures),
        "shared_source_pattern": shared_source_pattern,
    }
    print(output)
    print("EXCEPTIONAL_PIVOT_EXTERNAL_PMS_CLASSIFIED")


if __name__ == "__main__":
    main()
