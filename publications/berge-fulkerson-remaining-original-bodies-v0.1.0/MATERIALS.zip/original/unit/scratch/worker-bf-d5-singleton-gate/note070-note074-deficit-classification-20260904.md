# Note 070 pole: complete Note 074 gate-deficit classification

## Decision

None of the eight optimal four-row gates from Note 074 is fully realizable
using the frozen order-13 failed-star pole of Note 070.  Across all 28
concrete choices of cells, the minimum is two obstructed added rows.  Every
obstruction is already a negative entry of

\[
D=2-\sum_{P\text{ in the singleton quadruple}}\chi_P.
\]

There is no odd closed-cycle obstruction and no terminal-path parity/state
mismatch.  Every nonnegative deficit in this finite instance decomposes into
two actual perfect matchings with the requested boundary states.  Thus this
pulse finds only proper-edge overload, not a new parity obstruction.

## Exact input and scope

The calculation reads, without modifying or regenerating them:

- the 17 proper edges and all 36 perfect matchings of the frozen Note 070
  order-13 pole;
- the singleton identities
  `a1=33, a2=16, a4=24, a5=0, x=2, y=12, z=10`;
- the eight minimum four-row gate patterns and their 28 concrete cell choices
  frozen by the Note 074 classification.

For each target singleton quadruple and chosen cell, the program forms the
22-coordinate deficit, including the five semiedges.  Negative coordinates
are reported immediately.  Otherwise its multiplicity-one support is split
into closed cycles and terminal paths.  Odd closed cycles are rejected;
even components are alternately coloured in every component orientation,
and the resulting two edge sets are checked against the complete frozen PM
set and the requested pair of triple-boundary classes.

This covers 26 distinct quadruple/cell targets.  Their classification is

\[
20\ \text{negative-edge},\qquad
0\ \text{odd-cycle},\qquad
0\ \text{terminal-state mismatch},\qquad
6\ \text{decomposable}.
\]

The six decomposable targets are

```text
{a1,a4,x,z}     (13,34)
{a1,a5,y,z}     (13,35)
{a2,a4,a5,x}    (24,35)
{a2,a4,a5,x}    (25,34)
{a2,a5,y,z}     (23,35)
{a4,a5,x,y}     (34,35)
```

The 28 gates have category profiles

```text
2 negative-edge + 2 decomposable    4 gates
3 negative-edge + 1 decomposable   16 gates
4 negative-edge + 0 decomposable    8 gates
```

Hence no complete gate occurs.  The four minimum-obstruction choices are
the four cell choices in the third `omit z` gate.  Their two unavoidable
overloads are shared by

```text
{a1,a2,x,y}:       e0,e7,e9,e10
{a1,a4,a5,y}:      e2
```

where the frozen proper-edge numbering is

```text
e0=(0,10)  e1=(0,11)  e2=(1,8)   e3=(1,9)
e7=(3,12)  e8=(4,6)   e9=(4,7)   e10=(5,6)
```

The seven repeated obstruction profiles over all gates, written as
multisets of negative-edge index sets, are

```text
gate count  profile
4           {0,7}, {2,7,9,10}, {7}, {7}
2           {0,7,9,10}, {2,7,9,10}, {7,9,10}
4           {0,7,9,10}, {2}
4           {1,3}, {7}, {8}
6           {1,8}, {2}, {7}
4           {1,8}, {3}, {7}
4           {1}, {2}, {7}, {8}
```

## Reproduction on Omen

Script:

```text
units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/classify_note070_note074_deficits.py
```

The single-process Omen command was

```bash
cd [local archival reference]
ulimit -v 524288
/usr/bin/time -v python3 classify_note070_note074_deficits.py \
  --note070-verifier verify_failed_pivot_residual_avoiding_pole.py \
  --note074-json omen-run.json \
  > result.log 2> run.log
```

Frozen run outputs:

```text
[local archival reference]
[local archival reference]
```

The final marker is

```text
NOTE070_NOTE074_DEFICITS_CLASSIFIED
```

The run took 0.07 seconds, used 14,592 KB peak RSS, and exited with status
zero.  It used one Python process, no graph search, no order extension, and
no SAT/ILP solver.
