# Four pivot rows do not force a forbidden-boundary five-PM residual selector

## Decision

The proposed selector statement is false at the common-edge occurrence-load
level.  Four positive D5 double-cover equations forming a failed UE2 pivot
star do not by themselves force five of their PM occurrences to have edge
loads in ({1,2}) and forbidden (T)-boundary residual.

The countermodel below has one common edge universe, fourteen distinct binary
matching vectors, the five prescribed boundary semiedges, and four exact
six-vector double covers.  It is not a cubic-pole realization because no
common trivalent vertex-incidence system is imposed.

## Canonical failed star

Use the four D5 cells

\[
 A=(13,45),\quad B=(14,23),\quad C=(24,15),\quad D=(25,34),
\]

with (C) as anchor.  Let its singleton tuple be
((a_1,a_2,a_4,a_5)).  The other rows have unique extensions (x,x,y)
in singleton class (3), where (x\ne y).  Hence the extension equality
graph has one edge and UE2 fails.  The four witnesses are

\[
\begin{aligned}
A&: q_A+r_{45}+a_1+x+a_4+a_5=2\mathbf1,\\
B&: q_B+r_{23}+a_1+a_2+x+a_4=2\mathbf1,\\
C&: q_C+r_{15}+a_1+a_2+a_4+a_5=2\mathbf1,\\
D&: q_D+r_{34}+a_2+y+a_4+a_5=2\mathbf1.       \tag{1}
\end{aligned}
\]

The (q)'s and (r)'s have the triple boundary classes dictated by their
subscripts; for example (q_A) has boundary (245) and (r_{45}) has
boundary (123).

## Four blocking proper edges

For a proper edge, list the matching vectors containing it.  Take

\[
\begin{aligned}
e_1&=\{a_2,a_5,r_{23},r_{45}\},\\
e_2&=\{a_4,r_{15},r_{23},r_{45},y\},\\
e_3&=\{a_1,r_{15},r_{34},x,y\},\\
e_4&=\{a_5,r_{15},r_{23},r_{34},x\}.          \tag{2}
\end{aligned}
\]

Each set in (2) meets every row of (1) in exactly two occurrences.  The
semiedge (s_i) contains precisely the vectors whose boundary contains
(i); it also meets every row twice.  Thus all four equations in (1) hold
edgewise on the same nine-edge universe.  The resulting fourteen incidence
vectors are pairwise distinct, including (x\ne y).

Among the occurrences in (1), there are exactly 69 five-occurrence
multisets whose semiedge residual is binary and whose completed six boundary
patterns would be a (T)-loop or (T)--(T) type.  Every one is blocked by
at least one edge in (2): its load on that edge is (0) or at least (3).
Consequently no candidate satisfies (1\le\ell_F\le2) on the common edge
universe, so the residual-complement lemma cannot fire.

This blocker is sharp inside the canonical occurrence system.  There are
147 possible binary proper-edge columns meeting every row twice.  No choice
of at most three such columns blocks all 69 candidates; (2) uses four.

## Exact additional condition

Let (mathcal F_T) be the finite family of five-occurrence multisets from a
failed star having a forbidden (T)-boundary residual.  For every edge (e)
put

\[
 B_e=\{F\in\mathcal F_T:\ell_F(e)\notin\{1,2\}\}.
\]

The desired selector exists exactly when

\[
             \mathcal F_T\not\subseteq\bigcup_{e\in E(H)}B_e.       \tag{3}
\]

Thus (3), or any theorem implying it from common trivalent vertex incidence,
is the sharp missing Hall condition.  Once such an (F) exists, the general
residual-complement lemma makes its residual an actual perfect matching and
immediately produces the forbidden cover.  Complete positive-cell support
does not enter this last step.

The abstract countermodel proves only that the four cover equations and
boundary data do not imply (3).  It does not decide whether cubic vertex
incidence, alternating-cycle closure, or the other 36 positive Case-XII
cells force (3) in a genuine pole.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/verify_failed_pivot_residual_abstract_countermodel.py
```

The final line is

```text
FAILED_PIVOT_RESIDUAL_ABSTRACT_COUNTERMODEL_VERIFIED
```
