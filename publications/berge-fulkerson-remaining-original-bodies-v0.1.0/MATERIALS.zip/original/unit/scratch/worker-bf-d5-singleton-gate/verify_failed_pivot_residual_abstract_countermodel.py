#!/usr/bin/env python3
"""Minimal common-edge countermodel to the failed-pivot residual selection."""

from collections import Counter
from itertools import combinations, combinations_with_replacement


NAMES = (
    "a1", "a2", "a4", "a5", "x", "y",
    "qA", "r45", "qB", "r23", "qC", "r15", "qD", "r34",
)
ROWS = (
    ("qA", "r45", "a1", "x", "a4", "a5"),
    ("qB", "r23", "a1", "a2", "x", "a4"),
    ("qC", "r15", "a1", "a2", "a4", "a5"),
    ("qD", "r34", "a2", "y", "a4", "a5"),
)
BOUNDARY = {
    "a1": {1}, "a2": {2}, "a4": {4}, "a5": {5},
    "x": {3}, "y": {3},
    "qA": {2, 4, 5}, "r45": {1, 2, 3},
    "qB": {2, 3, 5}, "r23": {1, 4, 5},
    "qC": {1, 3, 5}, "r15": {2, 3, 4},
    "qD": {1, 3, 4}, "r34": {1, 2, 5},
}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}

# Each column is one proper edge.  It records precisely the named matching
# vectors containing that edge.
PROPER_COLUMNS = (
    frozenset(("a2", "a5", "r23", "r45")),
    frozenset(("a4", "r15", "r23", "r45", "y")),
    frozenset(("a1", "r15", "r34", "x", "y")),
    frozenset(("a5", "r15", "r23", "r34", "x")),
)


def state(name):
    if len(BOUNDARY[name]) != 3:
        return None
    return tuple(sorted(set(range(1, 6)) - BOUNDARY[name]))


def forbidden_boundary_candidates():
    available = Counter(name for row in ROWS for name in row)
    answer = []
    for candidate in combinations_with_replacement(NAMES, 5):
        used = Counter(candidate)
        if any(used[name] > available[name] for name in used):
            continue
        terminal_loads = {
            terminal: sum(terminal in BOUNDARY[name] for name in candidate)
            for terminal in range(1, 6)
        }
        if not all(load in (1, 2) for load in terminal_loads.values()):
            continue
        residual_boundary = {
            terminal for terminal, load in terminal_loads.items() if load == 1
        }
        sizes = sorted(
            [len(BOUNDARY[name]) for name in candidate]
            + [len(residual_boundary)]
        )
        if sizes != [1, 1, 1, 1, 3, 3]:
            continue
        states = [state(name) for name in candidate if state(name) is not None]
        if len(residual_boundary) == 3:
            states.append(tuple(sorted(set(range(1, 6)) - residual_boundary)))
        if len(states) == 2 and all(item in T for item in states):
            answer.append(candidate)
    return tuple(answer)


def main():
    semiedge_columns = tuple(
        frozenset(name for name in NAMES if terminal in BOUNDARY[name])
        for terminal in range(1, 6)
    )
    columns = PROPER_COLUMNS + semiedge_columns

    # The four displayed positive D5 witnesses are exact double covers.
    assert all(sum(name in column for name in row) == 2
               for column in columns for row in ROWS)

    # x,x,y are the three unique pivot extensions: one agreement, not UE2.
    x, y = "x", "y"
    assert x != y
    vectors = {
        name: tuple(name in column for column in columns) for name in NAMES
    }
    assert len(set(vectors.values())) == len(NAMES)

    candidates = forbidden_boundary_candidates()
    assert len(candidates) == 69
    blocked_by = tuple(
        frozenset(
            index for index, candidate in enumerate(candidates)
            if sum(name in column for name in candidate) not in (1, 2)
        )
        for column in PROPER_COLUMNS
    )
    assert set().union(*(set(blocked) for blocked in blocked_by)) == set(
        range(len(candidates))
    )

    # Four blocking columns are minimal among all 0/1 columns satisfying the
    # same four row equations.
    allowed = []
    for mask in range(1 << len(NAMES)):
        column = frozenset(
            NAMES[index] for index in range(len(NAMES)) if mask >> index & 1
        )
        if all(sum(name in column for name in row) == 2 for row in ROWS):
            allowed.append(column)
    all_candidates = (1 << len(candidates)) - 1
    masks = []
    for column in allowed:
        mask = 0
        for index, candidate in enumerate(candidates):
            if sum(name in column for name in candidate) not in (1, 2):
                mask |= 1 << index
        masks.append(mask)
    assert not any(mask == all_candidates for mask in masks)
    assert not any(left | right == all_candidates
                   for left, right in combinations(masks, 2))
    assert not any(a | b | c == all_candidates
                   for a, b, c in combinations(masks, 3))

    print({
        "matching_vectors": len(NAMES),
        "positive_D5_rows": len(ROWS),
        "proper_edge_columns": len(PROPER_COLUMNS),
        "allowed_local_columns": len(allowed),
        "forbidden_boundary_five_occurrence_candidates": len(candidates),
        "all_candidates_blocked": True,
        "minimum_blocking_columns": 4,
        "common_trivalent_vertex_realization": False,
    })
    print("FAILED_PIVOT_RESIDUAL_ABSTRACT_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
