# One-external matching splice reduces to a five-matching load interval

## Decision

The one-external residual step has a general all-order proof.  It removes the
need to obtain the sixth matching from another positive Case-XII cell.
However, the pivot equations have not been shown to produce the required
five-matching load interval for an arbitrary failed UE2 star.  Thus the full
exact-40 implication remains undecided at one precise condition.

## Residual-complement lemma

Let (H) be any cubic 5-pole and let (F=(M_1,ldots,M_5)) be five actual
perfect matchings, with repetition allowed.  Put

\[
   \ell_F(e)=\sum_{r=1}^5\chi_{M_r}(e).
\]

If

\[
             1\le \ell_F(e)\le2\qquad(e\in E(H)),       \tag{1}
\]

then

\[
 M^*=\{e:\ell_F(e)=1\},\qquad
 \chi_{M^*}=2\mathbf1-\sum_{r=1}^5\chi_{M_r}            \tag{2}
\]

is the unique sixth perfect matching completing (F) to a double cover.

Indeed, at every cubic vertex the three incident loads lie in
({1,2}) and sum to five, since each of the five matchings meets the vertex
once.  They are therefore (1,2,2).  Hence exactly one incident edge belongs
to (M^*), so (M^*) is a perfect matching.  Equation (2) then makes every
edge load two.  The boundary class of (M^*) is fixed by the five boundary
patterns already in (F).  In particular, if these six boundary patterns
form a (T)-loop or (T)--(T) type, (1) contradicts the negative support
hypothesis immediately.

No fifth D5 cell, overlap cell, or witness-reuse assumption is used.

## The two 37-PM exceptions

For the two extendible pivot stars in
`pivot-negative-support-local-splicing-boundary-20260904.md` whose four-row
PM support contains no forbidden cover, the complete incidence data give,
respectively, four and five choices of a five-PM multiset (F) contained in
the row support such that (1) holds and the boundary residual in (2) is a
forbidden (T)-type.  In every case the previously observed row-external PM
is exactly the unique vector (M^*) in (2).

Thus those two apparent exceptions are not exceptions to an incidence proof:
once their five internal PMs are selected, cubicity itself forces the external
matching and the forbidden cover.  Any exact-40 pole automatically excludes
these two concrete incidence patterns.

## Exact remaining interface

For a general failed pivot star, the four positive double-cover equations do
not yet supply a rule selecting five of their PM occurrences for which (1)
holds.  The obstruction is exact:

* an edge with (ell_F(e)=0) gives residual value (2), so (2) is not a
  matching vector;
* an edge with (ell_F(e)\ge3) gives a negative residual;
* if neither occurs, the lemma closes the argument without any further
  Case-XII witness.

Accordingly the thinnest sufficient additional condition is:

> **Five-PM residual coverage.**  Every failed UE2 pivot star admits a
> five-occurrence submultiset (F) from its four positive witnesses (or from
> those witnesses plus one specified positive-cell splice) satisfying
> (1\le\ell_F\le2) edgewise and having forbidden (T)-boundary residual.

This is the one-hole Hall condition in its exact form: the candidate five-set
must cover every edge while respecting capacity two.  Complete support of the
forty positive cells only says that each cell has some witness; without a
witness-reuse theorem it does not imply this edgewise coverage condition.

Evidence level: the residual-complement lemma is a general proof; exclusion
of the two saved 37-PM patterns is a strict common-incidence consequence; the
selection of (F) for every failed pivot star is unresolved.  No graph-order
search, literature search, or permanent note is used.
