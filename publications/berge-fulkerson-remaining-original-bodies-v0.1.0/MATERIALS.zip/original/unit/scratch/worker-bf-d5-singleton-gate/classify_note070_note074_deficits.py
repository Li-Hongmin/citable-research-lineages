#!/usr/bin/env python3
"""Classify Note-074 gate deficits inside the frozen Note-070 pole.

This is a finite, standard-library calculation on existing perfect-matching
and edge data.  For every one of the 28 concrete cell choices, each target
singleton quadruple gives D = 2 - sum(chi_P).  We classify D by the first
applicable obstruction:

  negative_edge; odd_closed_cycle; terminal_path_state_mismatch; decomposable.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path


IDENTITY_TO_PM = {
    "a1": 33,
    "a2": 16,
    "a4": 24,
    "a5": 0,
    "x": 2,
    "y": 12,
    "z": 10,
}


def load_module(path):
    spec = importlib.util.spec_from_file_location("note070_frozen", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_first_json(path):
    text = path.read_text(encoding="utf-8")
    value, _ = json.JSONDecoder().raw_decode(text)
    return value


def parse_cell(name):
    left, right = name.strip("()").split(",")
    return tuple(sorted((tuple(map(int, left)), tuple(map(int, right)))))


def complement(pair):
    return tuple(sorted(set(range(1, 6)) - set(pair)))


def full_designated_matchings(base):
    edge_index = {edge: index for index, edge in enumerate(base.PROPER)}
    return {
        label: tuple(sorted(
            [edge_index[edge] for edge in proper]
            + [16 + position for position in base.B[label]]
        ))
        for label, proper in base.VECTORS.items()
    }


def connected_components(edge_ids, edge_endpoints):
    incident = defaultdict(list)
    for edge in edge_ids:
        for vertex in edge_endpoints[edge]:
            incident[vertex].append(edge)
    unseen = set(edge_ids)
    components = []
    while unseen:
        seed = unseen.pop()
        component = {seed}
        stack = [seed]
        while stack:
            edge = stack.pop()
            for vertex in edge_endpoints[edge]:
                for neighbour in incident[vertex]:
                    if neighbour in unseen:
                        unseen.remove(neighbour)
                        component.add(neighbour)
                        stack.append(neighbour)
        components.append(tuple(sorted(component)))
    return tuple(sorted(components))


def alternating_component_colouring(component, edge_endpoints, internal_vertices):
    adjacency = defaultdict(set)
    incident = defaultdict(list)
    for edge in component:
        for vertex in edge_endpoints[edge]:
            if vertex in internal_vertices:
                incident[vertex].append(edge)
    for vertex, edges in incident.items():
        if len(edges) not in (0, 2):
            raise AssertionError((vertex, edges, component))
        if len(edges) == 2:
            left, right = edges
            adjacency[left].add(right)
            adjacency[right].add(left)
    colour = {component[0]: 0}
    stack = [component[0]]
    while stack:
        edge = stack.pop()
        for neighbour in adjacency[edge]:
            expected = 1 - colour[edge]
            if neighbour in colour:
                if colour[neighbour] != expected:
                    return None
            else:
                colour[neighbour] = expected
                stack.append(neighbour)
    if set(colour) != set(component):
        raise AssertionError((component, colour))
    return colour


def boundary(pm):
    return tuple(edge - 16 for edge in pm if edge >= 17)


def classify_quadruple(quadruple, cell, base, full, all_pms):
    labels = tuple(IDENTITY_TO_PM[name] for name in quadruple)
    loads = [sum(edge in full[label] for label in labels) for edge in range(22)]
    deficit = tuple(2 - value for value in loads)
    negative = tuple(edge for edge, value in enumerate(deficit) if value < 0)
    record = {
        "quadruple": list(quadruple),
        "pm_labels": list(labels),
        "cell": "(" + ",".join("".join(map(str, pair)) for pair in cell) + ")",
        "deficit_distribution": dict(sorted(Counter(deficit).items())),
        "negative_edge_indices": list(negative),
        "negative_proper_edges": [list(base.PROPER[edge]) for edge in negative if edge < 17],
    }
    if negative:
        record["category"] = "negative_edge"
        return record

    edge_endpoints = {edge: base.PROPER[edge] for edge in range(17)}
    for position in range(1, 6):
        edge_endpoints[16 + position] = (position - 1, ("terminal", position))
    d1 = tuple(edge for edge, value in enumerate(deficit) if value == 1)
    d2 = tuple(edge for edge, value in enumerate(deficit) if value == 2)
    if any(value not in (0, 1, 2) for value in deficit):
        raise AssertionError(deficit)

    internal = set(range(base.N))
    components = connected_components(d1, edge_endpoints)
    component_records = []
    colourings = []
    odd_cycles = []
    for component in components:
        terminals = tuple(sorted(
            endpoint[1]
            for edge in component
            for endpoint in edge_endpoints[edge]
            if isinstance(endpoint, tuple) and endpoint[0] == "terminal"
        ))
        if len(terminals) not in (0, 2):
            raise AssertionError((quadruple, cell, component, terminals))
        colouring = alternating_component_colouring(component, edge_endpoints, internal)
        kind = "closed_cycle" if not terminals else "terminal_path"
        component_records.append({
            "kind": kind,
            "edge_count": len(component),
            "terminals": list(terminals),
            "edge_indices": list(component),
        })
        if colouring is None:
            if kind != "closed_cycle" or len(component) % 2 != 1:
                raise AssertionError((component, terminals))
            odd_cycles.append(component)
        else:
            colourings.append(colouring)
    record["D1_components"] = component_records
    if odd_cycles:
        record["category"] = "odd_closed_cycle"
        record["odd_closed_cycle_lengths"] = [len(component) for component in odd_cycles]
        return record

    desired = frozenset((frozenset(complement(cell[0])), frozenset(complement(cell[1]))))
    decompositions = set()
    attainable_boundaries = set()
    for swaps in product((0, 1), repeat=len(colourings)):
        left = set(d2)
        right = set(d2)
        for colouring, swap in zip(colourings, swaps):
            for edge, colour in colouring.items():
                (left if colour ^ swap == 0 else right).add(edge)
        left = tuple(sorted(left))
        right = tuple(sorted(right))
        if left not in all_pms or right not in all_pms:
            raise AssertionError((quadruple, cell, left, right))
        boundary_pair = frozenset((frozenset(boundary(left)), frozenset(boundary(right))))
        attainable_boundaries.add(boundary_pair)
        if boundary_pair == desired:
            decompositions.add(tuple(sorted((left, right))))

    def boundary_pair_record(pair):
        return sorted((sorted(item) for item in pair), key=str)

    record["attainable_boundary_pairs"] = sorted(
        (boundary_pair_record(pair) for pair in attainable_boundaries), key=str
    )
    record["decomposition_count"] = len(decompositions)
    if not decompositions:
        record["category"] = "terminal_path_state_mismatch"
        record["desired_triple_boundaries"] = boundary_pair_record(desired)
        return record
    record["category"] = "decomposable"
    record["one_decomposition"] = [list(pm) for pm in min(decompositions)]
    record["one_decomposition_boundaries"] = [
        list(boundary(pm)) for pm in min(decompositions)
    ]
    return record


def expand_concrete_gates(note074):
    gates = []
    for six_set in note074["six_subsets"]:
        if six_set["minimum_additional_rows"] != 4:
            continue
        omitted = six_set["omitted"]
        for solution_index, solution in enumerate(six_set["minimum_solutions"]):
            for choice_index, cells in enumerate(product(*(
                row["allowed_cells"] for row in solution
            ))):
                gates.append({
                    "omitted": omitted,
                    "solution_index": solution_index,
                    "choice_index": choice_index,
                    "targets": tuple(
                        (tuple(row["singleton_quadruple"]), parse_cell(cell))
                        for row, cell in zip(solution, cells)
                    ),
                })
    if len(gates) != 28:
        raise AssertionError(len(gates))
    return tuple(gates)


def obstruction_fingerprint(record):
    category = record["category"]
    if category == "negative_edge":
        detail = tuple(record["negative_edge_indices"])
    elif category == "odd_closed_cycle":
        detail = tuple(record["odd_closed_cycle_lengths"])
    elif category == "terminal_path_state_mismatch":
        detail = tuple(
            tuple(tuple(boundary) for boundary in pair)
            for pair in record["attainable_boundary_pairs"]
        )
    else:
        detail = (record["decomposition_count"],)
    return category, detail


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--note070-verifier", type=Path, required=True)
    parser.add_argument("--note074-json", type=Path, required=True)
    args = parser.parse_args()

    base = load_module(args.note070_verifier)
    note074 = read_first_json(args.note074_json)
    full = full_designated_matchings(base)
    all_pms = frozenset(base.enumerate_pms())
    assert len(all_pms) == 36
    assert all(full[label] in all_pms for label in IDENTITY_TO_PM.values())
    assert tuple(base.B[IDENTITY_TO_PM[name]] for name in IDENTITY_TO_PM) == (
        (1,), (2,), (4,), (5,), (3,), (3,), (3,)
    )

    gates = expand_concrete_gates(note074)
    evaluation_cache = {}
    gate_records = []
    target_occurrence_frequency = Counter()
    category_profile_frequency = Counter()
    obstruction_profile_frequency = Counter()
    for gate_index, gate in enumerate(gates):
        evaluations = []
        for quadruple, cell in gate["targets"]:
            key = (quadruple, cell)
            if key not in evaluation_cache:
                evaluation_cache[key] = classify_quadruple(
                    quadruple, cell, base, full, all_pms
                )
            evaluation = evaluation_cache[key]
            evaluations.append(evaluation)
            target_occurrence_frequency[(quadruple, cell, evaluation["category"])] += 1
        categories = tuple(sorted(item["category"] for item in evaluations))
        obstructed = tuple(item for item in evaluations if item["category"] != "decomposable")
        fingerprints = tuple(sorted(map(obstruction_fingerprint, obstructed), key=str))
        category_profile_frequency[categories] += 1
        obstruction_profile_frequency[fingerprints] += 1
        gate_records.append({
            "gate_index": gate_index,
            "omitted": gate["omitted"],
            "solution_index": gate["solution_index"],
            "choice_index": gate["choice_index"],
            "obstruction_count": len(obstructed),
            "fully_realizable": not obstructed,
            "targets": evaluations,
        })

    minimum = min(record["obstruction_count"] for record in gate_records)
    complete = [record for record in gate_records if record["fully_realizable"]]

    def serialize_profile(counter):
        return [
            {"profile": profile, "gate_count": count}
            for profile, count in sorted(counter.items(), key=lambda item: str(item[0]))
        ]

    output = {
        "status": "COMPLETE_28_CHOICE_CLASSIFICATION",
        "frozen_pole_order": base.N,
        "frozen_pole_perfect_matchings": len(all_pms),
        "identity_to_pm": IDENTITY_TO_PM,
        "optimal_gate_patterns": 8,
        "concrete_cell_choices": len(gates),
        "distinct_quadruple_cell_targets": len(evaluation_cache),
        "category_distribution_distinct_targets": dict(sorted(Counter(
            item["category"] for item in evaluation_cache.values()
        ).items())),
        "minimum_obstructions_per_gate": minimum,
        "minimum_gate_indices": [
            record["gate_index"] for record in gate_records
            if record["obstruction_count"] == minimum
        ],
        "fully_realizable_gate_count": len(complete),
        "fully_realizable_gate_indices": [record["gate_index"] for record in complete],
        "category_profile_frequency": serialize_profile(category_profile_frequency),
        "repeated_obstruction_profile_frequency": serialize_profile(
            obstruction_profile_frequency
        ),
        "target_occurrence_frequency": [
            {
                "quadruple": list(key[0]),
                "cell": "(" + ",".join("".join(map(str, pair)) for pair in key[1]) + ")",
                "category": key[2],
                "gate_occurrences": count,
            }
            for key, count in sorted(target_occurrence_frequency.items(), key=str)
        ],
        "distinct_target_classification": [
            evaluation_cache[key] for key in sorted(evaluation_cache, key=str)
        ],
        "gates": gate_records,
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    print("NOTE070_NOTE074_DEFICITS_CLASSIFIED")


if __name__ == "__main__":
    main()
