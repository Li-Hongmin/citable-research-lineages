#!/usr/bin/env python3
"""List the exact positive and forbidden support gaps of the Note-070 pole."""

from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parents[1]
    / "computations/bundles/failed-pivot-residual-selector-counterexample"
    / "verify_failed_pivot_residual_avoiding_pole.py"
)
SPEC = spec_from_file_location("note070", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def main():
    pms = BASE.enumerate_pms()
    classes = defaultdict(list)
    for pm in pms:
        boundary = tuple(edge - 16 for edge in pm if edge >= 17)
        classes[boundary].append(pm)

    def exact(row):
        return all(sum(edge in pm for pm in row) == 2 for edge in range(22))

    def covers(first, second):
        return any(
            exact(row)
            for row in product(
                classes[BASE.comp(first)],
                classes[BASE.comp(second)],
                *(classes[(i,)] for i in first + second),
            )
        )

    states = tuple(combinations(BASE.POSITIONS, 2))
    support = {
        (first, second)
        for first, second in combinations_with_replacement(states, 2)
        if covers(first, second)
    }
    positive = {
        pair
        for pair in combinations_with_replacement(sorted(BASE.S), 2)
    } | {
        tuple(sorted((s, t)))
        for s in BASE.S
        for t in BASE.T
    }
    forbidden = {
        pair
        for pair in combinations_with_replacement(sorted(BASE.T), 2)
    }
    missing_positive = tuple(sorted(positive - support))
    supported_forbidden = tuple(sorted(forbidden & support))
    d5 = {
        tuple(sorted(pair))
        for pair in (((1, 3), (4, 5)), ((1, 4), (2, 3)),
                     ((2, 4), (1, 5)), ((2, 5), (3, 4)),
                     ((3, 5), (1, 2)))
    }
    assert len(pms) == 36
    assert len(missing_positive) == 4
    assert len(supported_forbidden) == 12
    print({
        "missing_positive": missing_positive,
        "missing_d5": tuple(sorted(d5 - support)),
        "supported_forbidden": supported_forbidden,
    })
    print("NOTE070_SUPPORT_GAP_CLASSIFIED")


if __name__ == "__main__":
    main()
