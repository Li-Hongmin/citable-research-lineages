#!/usr/bin/env python3
"""Explicit girth-five voltage lift of the frozen Note-070 counterexample."""

from collections import Counter, deque
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parents[1]
    / "computations/bundles/failed-pivot-residual-selector-counterexample"
    / "verify_failed_pivot_residual_avoiding_pole.py"
)
SPEC = spec_from_file_location("note070_base", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

VOLTAGE = {(5, 7): 1, (9, 11): 1}


def vertex(v, layer):
    return 3 * v + layer


def lift_edge(edge):
    u, v = edge
    shift = VOLTAGE.get(edge, 0)
    return tuple(
        tuple(sorted((vertex(u, layer), vertex(v, (layer + shift) % 3))))
        for layer in range(3)
    )


LIFTED_BASE = tuple(edge for base_edge in BASE.PROPER for edge in lift_edge(base_edge))
VERTICAL = tuple((vertex(v, 1), vertex(v, 2)) for v in range(5))
PROPER = LIFTED_BASE + VERTICAL
SEMIEDGES = tuple((vertex(v, 0),) for v in range(5))
EDGE_UNIVERSE = PROPER + SEMIEDGES


def lift_matching(label):
    selected = set()
    for edge in BASE.VECTORS[label]:
        selected.update(lift_edge(edge))
    for position in BASE.B[label]:
        terminal = position - 1
        selected.add(VERTICAL[terminal])
        selected.add(SEMIEDGES[terminal])
    return frozenset(selected)


def connected(edges, skip=None):
    adjacency = {v: [] for v in range(39)}
    for edge in edges:
        if edge == skip:
            continue
        u, v = edge
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    queue = deque((0,))
    while queue:
        u = queue.popleft()
        for v in adjacency[u]:
            if v not in seen:
                seen.add(v)
                queue.append(v)
    return len(seen) == 39


def girth(edges):
    adjacency = {v: [] for v in range(39)}
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    best = 99
    for root in range(39):
        distance = {root: 0}
        parent = {root: None}
        queue = deque((root,))
        while queue:
            u = queue.popleft()
            for v in adjacency[u]:
                if v not in distance:
                    distance[v] = distance[u] + 1
                    parent[v] = u
                    queue.append(v)
                elif parent[u] != v:
                    best = min(best, distance[u] + distance[v] + 1)
    return best


def main():
    assert len(PROPER) == 56 and len(set(PROPER)) == 56
    degree = Counter(v for edge in PROPER for v in edge)
    assert all(degree[v] == (2 if v in range(0, 15, 3) else 3) for v in range(39))
    assert connected(PROPER)
    assert not any(not connected(PROPER, edge) for edge in PROPER)
    assert girth(PROPER) >= 5

    vectors = {label: lift_matching(label) for label in BASE.VECTORS}
    assert len(set(vectors.values())) == 15
    incidence = {v: {edge for edge in EDGE_UNIVERSE if v in edge} for v in range(39)}
    for matching in vectors.values():
        assert all(len(matching & incidence[v]) == 1 for v in range(39))
    for _, row in BASE.ROWS:
        loads = Counter(edge for label in row for edge in vectors[label])
        assert all(loads[edge] == 2 for edge in EDGE_UNIVERSE)

    occurrences = tuple(label for _, row in BASE.ROWS for label in row)
    selectors = set()
    for positions in combinations(range(24), 5):
        selector = tuple(sorted(occurrences[index] for index in positions))
        if BASE.kind(selector):
            selectors.add(selector)
    assert len(selectors) == 79
    for selector in selectors:
        assert any(
            sum(edge in vectors[label] for label in selector) not in (1, 2)
            for edge in PROPER
        )

    print({
        "order": 39,
        "simple_connected_cubic_5_pole": True,
        "bridge_free": True,
        "girth": girth(PROPER),
        "designated_actual_matchings": len(vectors),
        "four_exact_D5_covers": True,
        "pivot_extensions": (2, 12, 10),
        "forbidden_boundary_selectors": len(selectors),
        "all_selectors_blocked": True,
        "nonzero_voltages": VOLTAGE,
    })
    print("GIRTH5_VOLTAGE_LIFT_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    main()
