#!/usr/bin/env python3
"""Verify a trivalent failed-pivot halfedge model with a parity obstruction."""

from collections import Counter

from verify_failed_pivot_residual_abstract_countermodel import (
    BOUNDARY, NAMES, PROPER_COLUMNS, ROWS,
)


def frozen(items):
    return frozenset(items.split())


TERMINALS = tuple(
    frozenset(name for name in NAMES if terminal in BOUNDARY[name])
    for terminal in range(1, 6)
)

# Nine abstract trivalent vertices.  At each vertex the three halfedge
# signatures partition the fourteen specified matching identities.
VERTICES = (
    (TERMINALS[0], frozen("a2 a5 qA qB"), frozen("a4 r15 x y")),
    (frozen("a1 qC qD x y"), TERMINALS[1], frozen("a4 a5 r23")),
    (frozen("a1 a4 r34"), frozen("a2 a5 qA r23"), TERMINALS[2]),
    (frozen("a1 a5 qB r34"), frozen("a2 qC r45 x y"), TERMINALS[3]),
    (frozen("a1 a2 qD r45"), frozen("a4 r15 x y"), TERMINALS[4]),
    (frozen("a1 qC r34 x y"), PROPER_COLUMNS[0],
     frozen("a4 qA qB qD r15")),
    (frozen("a1 a5 qB qD"), frozen("a2 qA qC r34 x"), PROPER_COLUMNS[1]),
    (PROPER_COLUMNS[2], frozen("a2 a5 qA r23"),
     frozen("a4 qB qC qD r45")),
    (frozen("a1 a2 qD r45"), frozen("a4 qA qB qC y"), PROPER_COLUMNS[3]),
)


def main():
    universe = frozenset(NAMES)
    for vertex in VERTICES:
        assert set().union(*map(set, vertex)) == set(universe)
        assert sum(map(len, vertex)) == len(universe)
        assert all(sum(name in column for name in row) == 2
                   for column in vertex for row in ROWS)

    # Leave the indicated terminal signature at the first five vertices
    # unpaired.  Every blocker signature occurs exactly once and is not a
    # terminal signature.
    occurrence_count = Counter(column for vertex in VERTICES for column in vertex)
    terminal_count = Counter(TERMINALS)
    assert all(occurrence_count[column] == 1 for column in PROPER_COLUMNS)
    assert all(terminal_count[column] == 0 for column in PROPER_COLUMNS)

    mismatches = tuple(
        column for column, count in occurrence_count.items()
        if (count - terminal_count[column]) % 2
    )
    assert all(column in mismatches for column in PROPER_COLUMNS)

    # In k uniform copies, every signature C would need
    # k*n_C-t_C even.  A terminal signature with odd t_C forces k odd, while
    # each blocker has odd n_C and t_C=0 and therefore forces k even.
    odd_terminal = next(
        column for column, count in terminal_count.items() if count % 2
    )
    assert occurrence_count[odd_terminal] % 2 == 1
    for parity in (0, 1):
        feasible = all(
            (parity * count - terminal_count[column]) % 2 == 0
            for column, count in occurrence_count.items()
        )
        assert not feasible

    print({
        "vertices": len(VERTICES),
        "matching_identities": len(NAMES),
        "terminal_halfedges": len(TERMINALS),
        "selector_blocker_signatures": len(PROPER_COLUMNS),
        "parity_mismatched_signatures": len(mismatches),
        "uniform_copy_parities_feasible": (),
    })
    print("TRIVALENT_COLUMN_PAIRING_OBSTRUCTION_VERIFIED")


if __name__ == "__main__":
    main()
