# The two exceptional pivot stars have a common residual source

Fix the 37-perfect-matching order-13 pole and the two exceptional pivot
stars isolated by `audit_pivot_forbidden_splicing_boundary.py`.  For each
star let (U) be the set of perfect-matching identities used by its four
positive D5 rows.  There are nine forbidden covers whose six matching
occurrences contain exactly one identity outside (U): four for the first
star and five for the second.

## The external matching is forced by the five local matchings

In every one of the nine covers, remove its unique external matching (M).
The remaining five matchings lie in (U), and their edge-load function
(lambda) satisfies

\[
\lambda(e)\in\{1,2\}\qquad(e\in E(H)).
\]

Consequently

\[
M=\{e:\lambda(e)=1\}
  =2\mathbf 1-\sum_{k=1}^{5}\chi_{N_k}.                 \tag{1}
\]

This is not merely an equality found by looking up (M) in the 37-PM
family.  At every cubic vertex, the three incident loads belong to
({1,2}) and sum to five, so they are (1,2,2).  Thus the residual in
(1) uses exactly one incident edge at every vertex and is automatically a
perfect matching.  The computation verifies this vertex equation directly.
Every case has seven load-one edges and fifteen load-two edges.

Hence all nine one-external forbidden covers have one unified source
mechanism: the apparent external PM is the unique cubic residual of five
four-row-pool PMs.  It need not be supplied by another positive cell or by
the full-40 hypothesis.

## Complete forbidden-source classification

The alternating distance is the number of components of the symmetric
difference with the nearest same-boundary PM already in (U); (|\triangle|)
is the number of differing edges.

### Omitted cell ((14)(23))

| external PM | boundary | nearest pool PM | distance; \(|\triangle|\) | forbidden type | five-PM residual source |
|---:|---:|---:|---:|---|---|
| 3 | (P_2) | 16 | 1; 4 | ((12)(45)) | 0,17,24,33,35 |
| 9 | (P_4) | 24 | 1; 4 | ((12)(45)) | 0,16,17,33,35 |
| 13 | (P_5) | 0 | 1; 4 | ((15)(34)) | 2,11,24,29,33 |
| 15 | (P_3) | 2 | 1; 4 | ((15)(34)) | 0,11,24,29,33 |

### Omitted cell ((25)(34))

| external PM | boundary | nearest pool PM | distance; \(|\triangle|\) | forbidden type | five-PM residual source |
|---:|---:|---:|---:|---|---|
| 3 | (P_2) | 16 | 1; 4 | ((12)(45)) | 0,17,24,33,35 |
| 9 | (P_4) | 24 | 1; 4 | ((12)(45)) | 0,16,17,33,35 |
| 13 | (P_5) | 0 | 1; 4 | ((15)(23)) | 10,11,16,27,33 |
| 23 | (P_5) | 0 | 2; 8 | ((15)(23)) | 2,11,16,27,33 |
| 25 | (P_3) | 10 | 1; 4 | ((15)(23)) | 0,11,16,27,33 |

The two stars share the two forbidden ((12)(45)) sources literally: the
external identities, nearest mates, and five-PM residual sets are identical.
Their complete source lists are not identical.  The other branch is
((15)(34)) in the first star and ((15)(23)) in the second, and the second
star alone has the two-component external PM 23.  Thus the source mechanism
is uniform although its full catalogue is not.

## Occurrence in the forty positive cells

The following lists are exhaustive.  A cell is listed when at least one
actual six-PM witness in that positive cell contains the indicated PM; the
verifier also records the exact number of such witnesses in every cell.

- PM 3 occurs in 20 cells:
  ((12)(13),(12)(14),(12)(24),(12)(25),(12)(35),
  (13)(23),(13)(24),(13)(25),(14)(23),(14)(25),
  (15)(24),(15)(25),(23)(25),(23)(35),(24)(25),
  (24)(35),(25)(34),(25)(35),(25)(45),[25]).

- PM 9 occurs in 19 cells:
  ((12)(14),(12)(24),(13)(14),(13)(24),(13)(34),
  (13)(45),(14)(23),(14)(24),(14)(25),(14)(34),
  (14)(35),(15)(24),(24)(25),(24)(35),(24)(45),
  (25)(34),(25)(45),(34)(35),(35)(45)).

- PM 13 occurs in 21 cells:
  ((12)(35),(13)(15),(13)(25),(13)(35),(13)(45),
  (14)(15),(14)(25),(14)(35),(14)(45),(15)(24),
  (15)(25),(15)(35),(23)(35),(24)(35),(24)(45),
  (25)(34),(25)(35),(25)(45),(34)(35),(35)(45),[35]).

- PM 15 occurs in 21 cells:
  ((12)(13),(12)(35),(13)(14),(13)(15),(13)(23),
  (13)(24),(13)(25),(13)(34),(13)(35),(13)(45),
  (14)(23),(14)(35),(15)(35),(23)(35),(24)(35),
  (25)(34),(25)(35),(34)(35),(35)(45),[13],[35]).

- PM 23 occurs in 23 cells:
  ((12)(25),(12)(35),(13)(15),(13)(25),(13)(35),
  (13)(45),(14)(25),(14)(35),(15)(24),(15)(25),
  (15)(35),(23)(25),(23)(35),(24)(25),(24)(35),
  (24)(45),(25)(34),(25)(35),(25)(45),(34)(35),
  (35)(45),[25],[35]).

- PM 25 occurs in 23 cells:
  ((12)(13),(12)(35),(13)(14),(13)(15),(13)(23),
  (13)(24),(13)(25),(13)(34),(13)(35),(13)(45),
  (14)(23),(14)(35),(15)(35),(23)(24),(23)(25),
  (23)(35),(24)(35),(25)(34),(25)(35),(34)(35),
  (35)(45),[13],[35]).

These positive-cell occurrences are genuine but are not needed to create
the forbidden cover: equation (1) already forces the missing PM from the
five local identities.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/classify_exceptional_pivot_external_pms.py
```

The terminal marker is

```text
EXCEPTIONAL_PIVOT_EXTERNAL_PMS_CLASSIFIED
```

The script enumerates the fixed 37-PM family, all forty positive cells and
all 115 forbidden covers.  It performs no graph search or order expansion.
