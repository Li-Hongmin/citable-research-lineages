#!/usr/bin/env python3
"""Pure-stdlib verification of the synthesized residual-avoiding 5-pole."""

from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement, product

N = 13
PROPER = (
    (0,10),(0,11),(1,8),(1,9),(2,9),(2,10),(3,7),(3,12),(4,6),
    (4,7),(5,6),(5,7),(5,8),(6,12),(8,11),(9,11),(10,12),
)
ROWS = (
    (((2,4),(1,5)),(28,11,16,24,33,0)),
    (((1,3),(4,5)),(18,35,33,2,24,0)),
    (((2,5),(3,4)),(31,29,16,0,12,24)),
    (((3,5),(1,2)),(34,17,10,0,33,16)),
)
VECTORS = {
28:((1,9),(3,7),(5,6),(8,11),(10,12)),11:((0,10),(4,7),(5,8),(6,12),(9,11)),
16:((0,10),(2,9),(3,12),(4,6),(5,7),(8,11)),24:((0,11),(1,8),(2,9),(4,6),(5,7),(10,12)),
33:((1,8),(2,10),(3,12),(4,7),(5,6),(9,11)),0:((0,11),(1,9),(2,10),(3,7),(5,8),(6,12)),
18:((0,10),(2,9),(5,7),(6,12),(8,11)),35:((3,7),(4,6),(5,8),(9,11),(10,12)),
2:((0,10),(1,9),(3,12),(4,7),(5,6),(8,11)),31:((1,9),(4,7),(5,6),(8,11),(10,12)),
29:((2,10),(3,7),(5,8),(6,12),(9,11)),12:((0,10),(1,8),(3,12),(4,7),(5,6),(9,11)),
34:((2,9),(4,7),(5,6),(8,11),(10,12)),17:((0,10),(1,8),(5,7),(6,12),(9,11)),
10:((0,11),(1,9),(3,7),(4,6),(5,8),(10,12)),
}
POSITIONS=tuple(range(1,6)); S={(1,3),(1,4),(2,4),(2,5),(3,5)}
T=set(combinations(POSITIONS,2))-S

def comp(p): return tuple(sorted(set(POSITIONS)-set(p)))
def boundaries():
    out={}
    for (a,b),row in ROWS:
        for m,c in ((row[0],comp(a)),(row[1],comp(b)),*zip(row[2:],((i,) for i in a+b))):
            assert m not in out or out[m]==c; out[m]=c
    return out
B=boundaries(); E={e:i for i,e in enumerate(PROPER)}

def connected(skip=None):
    seen={0}; q=[0]
    while q:
        v=q.pop()
        for e in PROPER:
            if e==skip or v not in e: continue
            w=e[0] if e[1]==v else e[1]
            if w not in seen: seen.add(w); q.append(w)
    return len(seen)==N

def girth():
    best=99
    for skip in PROPER:
        s,t=skip; q=deque([(s,0)]); seen={s}
        while q:
            v,d=q.popleft()
            if v==t: best=min(best,d+1); break
            for e in PROPER:
                if e==skip or v not in e: continue
                w=e[0] if e[1]==v else e[1]
                if w not in seen: seen.add(w); q.append((w,d+1))
    return best

def enumerate_pms():
    adj={v:[] for v in range(N)}
    for i,(u,v) in enumerate(PROPER): adj[u].append((v,i)); adj[v].append((u,i))
    used=[False]*N; chosen=[]; out=set()
    def rec():
        try: u=next(v for v in range(N) if not used[v])
        except StopIteration: out.add(tuple(sorted(chosen))); return
        used[u]=True
        if u<5: chosen.append(17+u); rec(); chosen.pop()
        for v,i in adj[u]:
            if used[v]: continue
            used[v]=True; chosen.append(i); rec(); chosen.pop(); used[v]=False
        used[u]=False
    rec(); return out

def kind(selector):
    loads={p:sum(p in B[m] for m in selector) for p in POSITIONS}
    if not all(x in (1,2) for x in loads.values()): return None
    residual=tuple(p for p,x in loads.items() if x==1)
    six=[B[m] for m in selector]+[residual]
    if sorted(map(len,six)) != [1,1,1,1,3,3]: return None
    pairs=tuple(sorted(comp(x) for x in six if len(x)==3))
    return pairs if all(x in T for x in pairs) else None

def main():
    assert len(set(PROPER))==17 and all(u<v for u,v in PROPER)
    deg=Counter(v for e in PROPER for v in e)
    assert all(deg[v]==(2 if v<5 else 3) for v in range(N)) and connected()
    full={m:tuple(sorted([E[e] for e in es]+[17+p-1 for p in B[m]])) for m,es in VECTORS.items()}
    pms=enumerate_pms(); assert all(m in pms for m in full.values())
    assert len(set(full.values()))==15 and len({full[x] for x in (2,12,10)})==3
    for _,row in ROWS:
        load=Counter(e for m in row for e in full[m]); assert all(load[e]==2 for e in range(22))
    occ=tuple(m for _,row in ROWS for m in row); selectors={}
    for pick in combinations(range(24),5):
        s=tuple(sorted(occ[i] for i in pick)); k=kind(s)
        if k: selectors.setdefault(s,k)
    assert len(selectors)==79
    bad_edges={}
    for s in selectors:
        loads=[sum(e in full[m] for m in s) for e in range(17)]
        bad=tuple(PROPER[e] for e,x in enumerate(loads) if x==0 or x>=3)
        assert bad; bad_edges[s]=bad
    anchor={1:33,2:16,4:24,5:0}
    for (cell,row),ext in zip(ROWS[1:],(2,12,10)):
        smap=dict(zip(cell[0]+cell[1],row[2:])); assert smap[3]==ext
        assert all(smap[p]==m for p,m in anchor.items() if p in smap)

    classes=defaultdict(list)
    for pm in pms:
        boundary=tuple(edge-16 for edge in pm if edge>=17)
        classes[boundary].append(pm)
    states=tuple(combinations(POSITIONS,2))
    tait=set()
    for state in states:
        for row in product(classes[comp(state)],*(classes[(i,)] for i in state)):
            if all(sum(edge in pm for pm in row)==1 for edge in range(22)):
                tait.add(state); break
    support=set()
    for first,second in combinations_with_replacement(states,2):
        for row in product(classes[comp(first)],classes[comp(second)],
                           *(classes[(i,)] for i in first+second)):
            if all(sum(edge in pm for pm in row)==2 for edge in range(22)):
                support.add((first,second)); break
    has_a=any(
        all(sum(edge in pm for pm in row)==2 for edge in range(22))
        for row in product(classes[POSITIONS],*(classes[(i,)] for i in POSITIONS))
    )
    ss={kind for kind in support if kind[0] in S and kind[1] in S}
    tt={kind for kind in support if kind[0] in T and kind[1] in T}
    st=support-ss-tt
    assert (len(ss),len(st),len(tt),has_a)==(15,21,12,False)
    print({'order':N,'simple_connected_cubic_5_pole':True,'perfect_matchings':len(pms),
           'designated_distinct_actual_pms':15,'four_row_double_covers':True,
           'extensions':(2,12,10),'forbidden_boundary_selectors':79,
           'all_selectors_have_bad_proper_edge':True,'girth':girth(),
           'bridges':tuple(e for e in PROPER if not connected(e)),
           'tait_states':tuple(sorted(tait)),
           'bf_support_profile':{'SS':len(ss),'ST':len(st),'TT':len(tt),'A':has_a},
           'bad_edge_count_distribution':dict(sorted(Counter(map(len,bad_edges.values())).items()))})
    print('FAILED_PIVOT_RESIDUAL_AVOIDING_POLE_VERIFIED')
if __name__=='__main__': main()
