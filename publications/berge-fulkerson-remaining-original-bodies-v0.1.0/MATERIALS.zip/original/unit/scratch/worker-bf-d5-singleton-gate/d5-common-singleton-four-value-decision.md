# The Case-XII D5 common-singleton gate reduces to one pivot fibre

## Question and four-value decision

Let

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\},
\]

and let

\[
\mathcal D_5=
\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For a real simple connected cubic 5-pole, let \(\widehat\Pi_d\) be the
four-singleton relation of the actual six-perfect-matching completions in
cell \(d\), and let \(\Pi_d\) be its five-coordinate cylinder.  Under the
complete forty-type Case-XII support, decide whether

\[
\exists d_0\in\mathcal D_5:\qquad
\bigcap_{d\ne d_0}\Pi_d\ne\varnothing.                 \tag{G}
\]

The exact four-value decision is:

1. **General proof: not obtained.**  Complete forty-type support still does
   not currently imply (G).
2. **Real counterexample: not obtained.**  No frozen real pole has complete
   support equal to the forty Case-XII types, so none refutes (G) under its
   full hypothesis.
3. **Sharp conditional theorem: obtained.**  After fixing one actual
   four-coordinate anchor, the whole obstruction is exactly a three-set
   intersection in one singleton matching class.  In the unique-extension
   subcase, two agreement edges connecting the three extensions are
   necessary and sufficient.  This is strictly weaker than coordinate
   rigidity or a 25-cell rectangular section.
4. **Strict real boundary: obtained.**  The frozen order-13 all-\(S\)-\(T\),
   no-\(A\) pole has sixteen anchors which extend separately to all three
   remaining cells, always with unique extension values, but the equality
   graph of the three values has zero edges nine times and one edge seven
   times.  It never has the two connected agreement edges needed for (G).
   This pole has extra \(T\)-loops and \(T\)-\(T\) types, so it is a boundary,
   not a Case-XII counterexample.

Thus the requested implication remains **undecided**, but its thinnest
remaining witness-reuse obstruction is now a single-coordinate equality
problem rather than a four-relation Helly problem.

## Exact pivot reduction

For \(d\in\mathcal D_5\), write

\[
U_d=s(d)\cup t(d)=[5]\setminus\{m(d)\}.
\]

Fix a four-cell set \(J=\mathcal D_5\setminus\{d_0\}\), an anchor
\(a\in J\), and an actual tuple

\[
x\in\widehat\Pi_a.
\]

For each other \(d\in J\setminus\{a\}\), define the extension fibre in the
single missing class \(\mathcal P_{m(a)}\) by

\[
E_d(x)=\left\{P\in\mathcal P_{m(a)}:
\begin{array}{l}
\text{some }y\in\widehat\Pi_d\text{ has }y_{m(a)}=P,\\[-2mm]
y_i=x_i\quad(i\in U_a\cap U_d)
\end{array}\right\}.                                  \tag{1}
\]

The anchor already fixes the other four singleton coordinates.  Hence a
five-tuple extending \(x\) lies in all four cylinders exactly when its
\(m(a)\)-coordinate lies in all three sets in (1).  Therefore

\[
\boxed{
\exists z\in\bigcap_{d\in J}\Pi_d\text{ with }z|_{U_a}=x
\iff
\bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing.}   \tag{2}
\]

This is an exact matching-level equivalence on one pole; no route labels or
aggregate loads are introduced.

Suppose additionally that the three nonempty extension fibres in (1) are
singletons.  Make a graph on the three non-anchor cells, joining two cells
when their unique values are the same actual matching in
\(\mathcal P_{m(a)}\).  Equality is transitive, so (2) holds exactly when
this graph is connected, equivalently when it has at least two edges.  This
gives the **unique-extension two-agreement condition**

\[
\tag{UE2}
\exists(J,a,x):\quad
|E_d(x)|=1\ (d\ne a),
\quad\text{and their equality graph is connected}.
\]

Condition (UE2) is enough for (G), which by Note 047 forces an
\(A=(12345)\) cover.  It asks for only one anchor tuple and two equalities
in one singleton class.  It does not fix all coordinates in every cell,
all triple matchings, or any of the other twenty-one \(S\)-\(T\) cells.
It is therefore strictly thinner than the earlier (CR), (3ER), and full
rectangular-section hypotheses.

## What the two frozen real poles show

The calculation uses the complete perfect-matching families of two already
frozen order-13 poles and performs no graph generation.

### Exact-\(S\) C10 pole

This pole has 31 perfect matchings and D5 cylinder sizes

\[
(12,6,8,8,6).
\]

Among the ten pairwise cylinder intersections, four are nonempty; among the
ten triple intersections, one is nonempty; all five four-way joins are
empty.  Across all five choices of \(J\), all four anchors in each \(J\),
and every anchor core tuple, there are 64 anchored cases, but none extends
separately to all three other cells.  The pole has an \(A\)-cover and only
17 of the 25 \(S\)-\(T\) types, so it fails the target hypothesis before
(G).

### All-\(S\)-\(T\), no-\(A\) pole

This pole has 37 perfect matchings and D5 cylinder sizes

\[
(96,110,96,72,125).
\]

Eight of ten pairwise intersections and three of ten triple intersections
are nonempty, but every four-way join is empty.  Among 452 anchored core
cases, exactly 16 extend separately to each of the other three cells.  In
all 16 cases every extension fibre is a singleton.  Their equality-graph
distribution is

\[
9\text{ cases with }0\text{ edges},\qquad
7\text{ cases with }1\text{ edge},\qquad
0\text{ cases with }\ge2\text{ edges}.
\]

Thus even a common four-coordinate anchor plus three genuine actual-PM
extensions does not imply a join.  The first failed condition is precisely
the second agreement in the one missing singleton class.  Because this
pole's complete closure contains the forbidden \(T\)-loops and
\(T\)-\(T\) types, the negative part of the forty-type hypothesis is the
only remaining source from which that agreement could be forced.

## Consequence and stopping point

No further census is justified by this pulse.  A positive proof should now
attack only the following statement:

> In a real cubic 5-pole with complete support exactly equal to the forty
> Case-XII types, the absence of every \(T\)-loop and \(T\)-\(T\) completion
> forces one anchored extension family to satisfy (2), or at least (UE2).

The current actual-PM data neither prove nor refute this statement.  The
result therefore stops at the strict real boundary and the one-coordinate
conditional theorem above.

## Reproduction

From the AIMath root run

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/audit_d5_pivot_extension_boundary.py
```

The deterministic final line is

```text
D5_PIVOT_EXTENSION_BOUNDARY_VERIFIED
```

