# Pivot UE2 and median-tree exchange: support-preserving blow-up boundary

## Question

Let (H) be a simple connected cubic 5-pole whose complete BF support is
exactly the Case-XII set (15 (S)--(S) types and 25 (S)--(T) types),
with no (A=(12345)), no (T)-loop and no (T)--(T) type.  Does this
actual perfect-matching incidence automatically imply either

* the pivot UE2 condition (one anchor whose three extension fibres are
  singletons with at least two agreement edges), or
* the median/tree exchange-Helly condition (the relevant singleton exchange
  graph is a tree and the fibres are pairwise-intersecting subtrees)?

The four-value decision is:

1. **General proof:** not obtained.
2. **Fixed real exact-40 counterexample:** none is available, because no real
   exact-40 pole is currently known.
3. **Sharp conditional theorem:** both UE2 and median/tree-Helly remain
   sufficient for the D5 join; the new support-preserving blow-up lemma below
   shows that the tree part is not a support invariant.
4. **Strict real boundary:** a concrete cubic 3-pole operation preserves the
   entire BF boundary-support set while forcing a (K_4) of one-cycle
   exchanges in every nonempty singleton class after vertex replacement.
   Thus exact support cannot, by itself, imply that the exchange graph is a
   tree.  The conclusion is conditional on the existence of an exact-40
   pole and is not a Case-XII counterexample.

## The local gadget

Let (J_0=K_{3,3}-v), viewed as a 3-pole.  In coordinates, its two internal
vertices are (0,1), its ports are (2,3,4), and its proper edges are

\[
 (0,2),(0,3),(0,4),(1,2),(1,3),(1,4).
\]

Replace the internal edge (e=(0,2)) by the two-pole (J_2=P-e_0), where
(P) is the Petersen graph and (e_0=(0,1)).  The resulting 15-vertex
3-pole is (J_\star).

The local certificate establishes:

\[
\begin{array}{c|c}
\text{object}&\text{value}\\ \hline
J_0\text{ PMs}&6\quad(\text{all use exactly one external port})\\
J_2\text{ PMs}&6\quad(4\text{ use no ports},\ 2\text{ use both})\\
J_\star\text{ PMs}&20\quad(\text{all use exactly one external port})\\
J_\star\text{ BF cover}&\text{yes}\\
\text{fixed-outside exchange groups}&4\text{ states at each port}\\
\text{pairwise symmetric differences in each group}&\text{one proper alternating cycle}
\end{array}
\]

Hence each port has a literal (K_4) in the one-cycle exchange graph.  The
four states are obtained by fixing the (J_0) matching outside (e) and
varying the four no-port perfect matchings of (J_2).

The contraction map (J_\star\to J_0) has fibre sizes

\[
 (2,2,4,4,4,4),
\]

according as the (J_0) matching uses (e) or avoids (e).  All 20 local
matchings have exactly one external port, so this is a genuine
matching-level, boundary-preserving map rather than a load-only model.

## Support-preserving vertex replacement

For any cubic 5-pole (H) and internal vertex (v), replace (v) by
(J_\star), attaching its three old neighbours to the three ports.  Call
the result (H^\star).  If (H) is simple and connected, so is (H^\star),
with the same five terminal semiedges.

The BF boundary support is exactly preserved:

\[
\boxed{\mathcal C(H^\star)=\mathcal C(H).}
\]

For the forward map, a six-matching BF cover of (H) uses each of the three
edges at (v) twice.  The six local matchings of one BF cover of
(J_\star) have their three port labels as a partition of the six matching
positions into three pairs; permuting the six positions realizes the labels
required at (v).  For the reverse map, every (J_\star) matching uses
exactly one port, so contract (J_\star) to (v) in each of the six
matchings.  Proper-edge multiplicities and all five external boundary labels
are unchanged.

Now take any singleton-boundary perfect matching (M\in\mathcal P_i(H)).
At (v), (M) uses one of the three incident edges, hence (M) extends to
(H^\star) using the corresponding port of (J_\star).  The local (K_4)
group gives four extensions which agree outside (J_\star), and every pair
differs by one proper alternating cycle.  Therefore every nonempty singleton
class of (H^\star) contains a (K_4) in its actual exchange graph.

Consequently, if an exact-40 pole (H) existed, (H^\star) would have the
same exact-40 support and forbidden-type exclusions, while none of its five
singleton exchange graphs could be a tree.  This rules out deriving the
median/tree hypothesis from support alone; an irreducibility or
no-support-preserving-blow-up assumption would be additional and genuinely
load-bearing.

## Relation to UE2

The blow-up does not itself refute UE2: local extra exchange states can leave
some pivot fibres with two agreeing values.  It does show that the stronger
median-tree route is unavailable as an automatic consequence of the same
support hypothesis.  The exact remaining real arrow is therefore still

\[
\text{exact-40 actual cubic incidence}
\Longrightarrow ?\ \text{UE2 or another cross-cell witness-reuse theorem},
\]

with no tree assumption justified by support.

## Omen verification

The pure-standard-library local certificate was run on Omen through `ssh`
and detached `tmux`:

```text
session: pivot-median-blowup-20260902
directory: [local archival reference]
log: [local archival reference]
marker: PIVOT_MEDIAN_BLOWUP_BOUNDARY_VERIFIED
```

Source:

```text
units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/verify_pivot_median_blowup_boundary.py
```

The output is (J_2=6) PMs with state counts (4/2), (J_\star=20) PMs
all in state one, a (K_4) group at each of the three ports, and a BF cover.

No graph census, higher-order search, literature search, or permanent-note
edit was used.
