# Girth five does not force a failed-pivot residual selector

## Decision

The statement (P_{\mathrm{girth}}) is false.  There is a simple connected
bridge-free cubic 5-pole of order (39) and girth (5) containing four
actual D5 six-perfect-matching covers that form a failed UE2 pivot star, but
none of the 79 forbidden-boundary five-occurrence selectors has edge loads
everywhere in ({1,2}).

The example is an explicit three-layer voltage lift of the frozen order-13
pole in Note 070.  No graph-order search is used.

## Voltage construction

Let (G) be the proper core of the Note-070 pole, with vertices
(0,ldots,12), and orient every listed edge (uv) from its smaller to its
larger endpoint.  Put

\[
 \omega(5,7)=\omega(9,11)=1\in\mathbb Z_3,
 \qquad \omega(e)=0\quad\text{otherwise}.             \tag{1}
\]

The lifted vertices are ((v,a)), where (a\in\mathbb Z_3).  Each proper
base edge (uv) gives the three edges

\[
       (u,a)(v,a+\omega(uv)),\qquad a\in\mathbb Z_3.  \tag{2}
\]

For every terminal base vertex (v=0,ldots,4), add the proper edge
((v,1)(v,2)) and leave one semiedge at ((v,0)).  This gives (39)
vertices, (56) proper edges, and five semiedges; every vertex is cubic and
the five semiedges have distinct incident vertices.

## Lifting the fifteen matchings

For each of the fifteen specified actual perfect matchings (M) in Note 070,
include all three lifts (2) of every proper edge in (M).  If (M) uses the
terminal semiedge at (v), also include the new edge ((v,1)(v,2)) and the
semiedge at ((v,0)).

At each lifted vertex this selects exactly one incident edge, so it is an
actual perfect matching.  Distinct base matchings remain distinct.  Every
lifted edge has the same incidence column on these fifteen matchings as its
base edge; the new terminal-pair edge has the same column as the corresponding
base semiedge.  Consequently:

* all four designated D5 rows remain exact double covers;
* the three anchor-compatible class-(P_3) extensions remain the distinct
  matchings (2,12,10), so UE2 fails;
* every one of the 79 selectors is still blocked: a base proper edge with
  load (0) or at least (3) lifts to three edges with the same load.

## Girth, connectedness, and bridges

The base proper graph is triangle-free and has exactly two four-cycles,

\[
 (1,8,11,9),\qquad (4,6,5,7).
\]

Their oriented voltage sums under (1) are respectively (-1) and (1), so
neither has a closed four-cycle lift.  A cycle of length at most four using
only lifted base edges would project to a non-backtracking closed walk of the
same length; the preceding triangle and four-cycle check excludes it.

The five base terminal vertices (0,ldots,4) are independent.  Hence a
four-cycle using two new terminal-pair edges cannot occur: its two remaining
edges would project to an edge between two terminal vertices.  A cycle of
length at most four using one new terminal-pair edge would require a proper
lifted path of length at most three between two different layers of the same
base vertex.  Its projection would be a length-two backtrack, which returns
to the same layer, or a base triangle.  Both are impossible.  Thus the new
pole has girth at least five; direct verification gives girth exactly five.

The nonzero voltage of either base four-cycle generates all of
(mathbb Z_3), so the proper voltage lift is connected.  Every lifted base
edge lies on a lifted repetition of a base cycle because the Note-070 core is
bridge-free.  Each new terminal-pair edge has an alternative path through the
connected proper lift.  Therefore the resulting pole is connected and has no
proper bridge.  It is simple by construction.

## Consequence

Girth five does not force the five-PM residual-coverage condition, even in a
real simple connected bridge-free cubic 5-pole.  The residual-complement
lemma remains valid, but it cannot be triggered from the four pivot rows plus
girth alone.  Any Case-XII proof must still use another hypothesis, such as
the remaining positive cells or the global absence of (T)-loop and
(T)--(T) support.

This example is not asserted to have exact Case-XII support.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/verify_girth5_voltage_lift_counterexample.py
```

The final marker is

```text
GIRTH5_VOLTAGE_LIFT_COUNTEREXAMPLE_VERIFIED
```
