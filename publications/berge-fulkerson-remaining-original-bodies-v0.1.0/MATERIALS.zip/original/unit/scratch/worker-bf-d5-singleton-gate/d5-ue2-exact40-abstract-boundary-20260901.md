# UE2 at the exact-40 common-incidence boundary

## Decision

The tested implication is the precise UE2 arrow:

\[
\begin{gathered}
\text{one global binary singleton/triple matching-vector pool},\\
\text{all 40 Case-XII positive six-vector equations},\\
\neg A,\quad\neg\text{T-loop},\quad\neg\text{T--T}
\end{gathered}
\quad\Longrightarrow\quad
\text{some D5 four-cell family satisfies UE2}.
\]

Here UE2 means: after choosing one four-cell anchor and one actual anchor
tuple, the three extension fibres in the anchor's missing singleton class
are nonempty singletons whose equality graph has at least two edges.  This
is exactly the unique-extension sufficient condition in
`d5-common-singleton-four-value-decision.md`.

The implication is **false in the tested common-coordinate model**.  The
model is deliberately not a cubic 5-pole: it omits the shared three-valent
vertex-incidence axiom.  Thus this is a strict abstract route boundary, not
a Berge--Fulkerson counterexample and not a refutation for real poles.

## Omen result

The Omen run used `ssh` and a detached `tmux` session:

```text
session: d5-ue2-exact40b-20260901
directory: [local archival reference]
log: [local archival reference]
marker: D5_UE2_EXACT40_ABSTRACT_BOUNDARY_VERIFIED
```

The two source files copied to Omen had SHA-256 values

```text
audit_ue2_exact40_lp_abstract.py
b38331a4777396e779cefdc24603e0746ff900fd854b35cd508c5b373056b3

verify_exact40_lp_integer_abstract_countermodel.py
45f7b432fc1e709068d917c7a91cffc1f053f2e821392f559c4c4a02eaaa008f
```

## Exact finite output

The five transferred disjoint S--S relations each have one actual partial
singleton tuple.  For every choice of four of the five cells, the normalized
four-way cylinder join has size zero.  The complete anchored audit reports:

```text
relation sizes:       1, 1, 1, 1, 1
four-way joins:        0, 0, 0, 0, 0
anchors:               20
extendible stars:      2
unique-extension stars:2
fibre sizes:           (1,1,1) in both cases
equality edges:        1 in both cases
joined stars:          0
```

Thus every UE2 candidate in this model is explicitly rejected: the only two
anchors whose three fibres are simultaneously nonempty have exactly one
agreement edge, never the two edges required for connectedness.  The five
four-cell joins are also all empty.

The imported verifier independently checks all 40 designated cells (five
S-loops, ten S--S cells and twenty-five S--T cells), the exact six-vector
equations, the absence of every T-loop and T--T equation, and the absence of
an integral capacity-two singleton transversal.  The last condition already
forces every D5 four-cell join to be empty in this model.

## Evidence level and remaining real interface

This closes the weaker statement that common binary incidence plus the exact
40 boundary equations already forces UE2.  It does **not** close the real
pole problem.  The missing condition is precisely common cubic vertex
incidence (and whatever alternating-cycle geometry follows from it): in a
real cubic pole, a capacity-two singleton transversal would automatically
produce the sixth A matching, whereas the abstract model intentionally has
no zero-boundary vectors.

Accordingly the remaining real implication is still

\[
\text{actual perfect-matchings of one simple connected cubic 5-pole}
 +\text{exact Case-XII support}
\Longrightarrow \text{UE2 or another D5 join mechanism}.
\]

No graph generation, order expansion, ordinary census, literature search,
or permanent-note edit was used in this pulse.

## Reproduction

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/audit_ue2_exact40_lp_abstract.py
```

The deterministic terminal line is

```text
D5_UE2_EXACT40_ABSTRACT_BOUNDARY_VERIFIED
```
