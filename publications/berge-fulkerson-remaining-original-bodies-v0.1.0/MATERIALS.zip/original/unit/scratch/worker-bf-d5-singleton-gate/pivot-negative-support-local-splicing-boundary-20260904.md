# Negative (T)-support does not enter the pivot gate by a four-row local splice

## Decision

The remaining implication

\[
\text{no (T)-loop/no (T)--(T)}
\quad\Longrightarrow\quad
\text{a pivot fibre intersection (or UE2)}
\]

is not proved or refuted.  The cheapest proposed mechanism for proving it,
however, fails sharply: a missing second agreement among the three pivot
extensions does **not** always expose a forbidden (T)-loop or (T)--(T)
cover inside the four positive D5 row witnesses.

This is a fixed-pole common-incidence statement.  It uses the complete 37-PM
family of the frozen order-13 cubic 5-pole, not an aggregate load model.

## Exhaustive local check

The pole has exactly 16 anchored D5 stars that extend separately to the three
other cells.  Every extension fibre is a singleton.  Their equality graphs
have zero edges in nine cases and one edge in seven cases, so every star
misses UE2.

For each star, fix its unique six-PM completion in the anchor cell and the
unique six-PM completion in each of the three extension cells.  Let (U) be
the union of the actual PM identities occurring in these four rows.  Enumerate
all 115 distinct forbidden BF covers of the pole (the five (T)-loops and ten
(T)--(T) types, with all actual witnesses), and retain those whose PM
multiset is supported in (U).  The distribution is

\[
\begin{array}{c|rrrr}
\#\{\text{forbidden covers supported in }U\}&0&1&2&3\\ \hline
\#\{\text{pivot stars}\}&2&7&2&5.
\end{array}
\]

Thus fourteen failures happen to coexist locally with at least one forbidden
cover, but two do not.  Both exceptions use anchor

\[
((24),(15)),\qquad (P_1,P_2,P_4,P_5)=(33,16,24,0),
\]

and are:

\[
\begin{array}{c|c|c}
\text{omitted D5 cell}&\text{three (P_3) extension values}
 &\text{four row witnesses}\\ \hline
((14),(23))&(2,12,10)&
(28,11,16,24,33,0),\ (18,35,33,2,24,0),\\
&& (31,29,16,0,12,24),\ (34,17,10,0,33,16)\\[1mm]
((25),(34))&(2,4,10)&
(28,11,16,24,33,0),\ (18,35,33,2,24,0),\\
&& (7,27,33,24,16,4),\ (34,17,10,0,33,16).
\end{array}
\]

Here the integers are canonical PM IDs in the frozen 37-PM enumeration.  In
each exception, every forbidden cover of the real pole needs at least one PM
identity outside the four-row support; the bound is sharp (the minimum is one).

## Exact consequence

There is no universal identity of the form

\[
\text{four anchored positive row witnesses failing UE2}
\Longrightarrow
\text{a forbidden witness using only those rows' PMs}.
\]

Therefore the negative support assumptions cannot be injected into the pivot
argument by a row-local support splice.  Any positive proof must use at least
one genuinely global source of an additional PM: for example, a Kempe mate or
another positive cell outside the anchored four rows, followed by a theorem
showing that its absence of forbidden (T)-support forces the second
agreement.  Common edge incidence, the four displayed double-cover equations,
and their symmetric differences do not supply that matching.

This does not show that the full exact-40 hypothesis is insufficient: the
37-PM pole itself has all forbidden (T)-support.  It isolates the precise
remaining quantifier exchange.  One must derive the extra PM globally from
no-(T)-loop/no-(T)--(T), rather than read a forbidden cover directly from
each failed local star.

## Reproduction

From the AIMath root run

```text
python3 units/berge-fulkerson/scratch/worker-bf-d5-singleton-gate/audit_pivot_forbidden_splicing_boundary.py
```

The final line is

```text
PIVOT_FORBIDDEN_SPLICING_BOUNDARY_VERIFIED
```
