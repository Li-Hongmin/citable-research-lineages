#!/usr/bin/env python3
"""Directed n=13 realization of the residual-avoiding failed pivot star."""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import sys

from z3 import And, Bool, Implies, Int, Not, Or, PbEq, PbGe, PbLe, Solver, sat, unknown

import solve_failed_pivot_terminal_incidence as local


N = 13
TERMINALS = tuple(range(5))
EDGES = tuple(combinations(range(N), 2))
GIRTH5 = "--girth5" in sys.argv


def main():
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in EDGES}
    y = {
        (matching, edge): Bool(f"y_{matching}_{edge[0]}_{edge[1]}")
        for matching in local.BOUNDARIES for edge in EDGES
    }
    solver = Solver()

    for vertex in range(N):
        target = 2 if vertex in TERMINALS else 3
        solver.add(PbEq([(x[edge], 1) for edge in EDGES if vertex in edge], target))
    solver.add(x[(5, 6)])

    if GIRTH5:
        for vertices in combinations(range(N), 3):
            solver.add(Or(*(Not(x[edge]) for edge in combinations(vertices, 2))))
        for a, b, c, d in combinations(range(N), 4):
            for left, right in (((a, b), (c, d)),
                                ((a, c), (b, d)),
                                ((a, d), (b, c))):
                cycle = tuple(tuple(sorted((u, v))) for u in left for v in right)
                solver.add(Or(*(Not(x[edge]) for edge in cycle)))
    # A parent of lower rank gives one connected component without a lazy
    # graph census or repeated component blocking.
    rank = {vertex: Int(f"rank_{vertex}") for vertex in range(N)}
    solver.add(rank[0] == 0)
    for vertex in range(N):
        solver.add(rank[vertex] >= 0, rank[vertex] < N)
        if vertex == 0:
            continue
        parents = []
        for parent in range(N):
            if parent == vertex:
                continue
            edge = tuple(sorted((parent, vertex)))
            choice = Bool(f"parent_{vertex}_{parent}")
            parents.append((choice, 1))
            solver.add(Implies(choice, x[edge]))
            solver.add(Implies(choice, rank[parent] < rank[vertex]))
        solver.add(PbEq(parents, 1))

    # Fifteen shared identities are actual perfect matchings with the fixed
    # boundary classes of the first exceptional 37-PM pivot star.
    for matching, boundary in local.BOUNDARIES.items():
        shifted_boundary = {position - 1 for position in boundary}
        for edge in EDGES:
            solver.add(Implies(y[(matching, edge)], x[edge]))
        for vertex in range(N):
            target = 1 - int(vertex in shifted_boundary)
            solver.add(PbEq(
                [(y[(matching, edge)], 1) for edge in EDGES if vertex in edge],
                target,
            ))
    for first, second in combinations(local.BOUNDARIES, 2):
        if local.BOUNDARIES[first] == local.BOUNDARIES[second]:
            solver.add(Or([
                y[(first, edge)] != y[(second, edge)] for edge in EDGES
            ]))

    # The three pivot extensions 2, 12, 10 are different actual matchings,
    # not three names that the model may collapse to one vector.
    for first, second in combinations((2, 12, 10), 2):
        solver.add(Or(*(y[(first, edge)] != y[(second, edge)] for edge in EDGES)))

    # The four actual six-PM equations share graph edges and PM identities.
    for _, row in local.ROWS:
        counts = Counter(row)
        for edge in EDGES:
            terms = [(y[(matching, edge)], count)
                     for matching, count in counts.items()]
            solver.add(PbLe(terms, 2))
            solver.add(Or(Not(x[edge]), PbEq(terms, 2)))

    # No forbidden-boundary five-selector may have load in {1,2} on every
    # real edge; otherwise its cubic residual is the forbidden sixth PM.
    for selector in local.SELECTORS:
        counts = Counter(selector)
        bad_edges = []
        for edge in EDGES:
            terms = [(y[(matching, edge)], count)
                     for matching, count in counts.items()]
            bad_edges.append(And(x[edge], Or(PbEq(terms, 0), PbGe(terms, 3))))
        solver.add(Or(bad_edges))

    solver.set(timeout=300000)
    status = solver.check()
    output = {
        "status": str(status),
        "n": N,
        "matching_identities": len(local.BOUNDARIES),
        "row_covers": len(local.ROWS),
        "forbidden_boundary_selectors": len(local.SELECTORS),
        "girth_at_least_five": GIRTH5,
    }
    if status == unknown:
        output["reason"] = solver.reason_unknown()
        print(output)
        print("FAILED_PIVOT_REALIZATION_UNKNOWN")
        return
    if status != sat:
        print(output)
        print("FAILED_PIVOT_REALIZATION_N13_UNSAT")
        return

    model = solver.model()
    proper_edges = tuple(edge for edge in EDGES if bool(model.eval(x[edge])))
    selected = {
        matching: tuple(edge for edge in proper_edges if bool(model.eval(y[(matching, edge)])))
        for matching in local.BOUNDARIES
    }
    assert len(proper_edges) == 17
    assert all(sum(vertex in edge for edge in proper_edges)
               == (2 if vertex in TERMINALS else 3) for vertex in range(N))
    for matching, boundary in local.BOUNDARIES.items():
        shifted_boundary = {position - 1 for position in boundary}
        assert all(sum(vertex in edge for edge in selected[matching])
                   == 1 - int(vertex in shifted_boundary) for vertex in range(N))
    assert all(selected[first] != selected[second]
               for first, second in combinations(local.BOUNDARIES, 2)
               if local.BOUNDARIES[first] == local.BOUNDARIES[second])
    for _, row in local.ROWS:
        assert all(sum(edge in selected[matching] for matching in row) == 2
                   for edge in proper_edges)
    for selector in local.SELECTORS:
        assert any((load := sum(edge in selected[matching] for matching in selector)) == 0
                   or load >= 3 for edge in proper_edges)

    output["proper_edges"] = proper_edges
    output["matching_vectors"] = selected
    print(output)
    print("FAILED_PIVOT_RESIDUAL_AVOIDING_REAL_POLE_SYNTHESIZED")


if __name__ == "__main__":
    main()
