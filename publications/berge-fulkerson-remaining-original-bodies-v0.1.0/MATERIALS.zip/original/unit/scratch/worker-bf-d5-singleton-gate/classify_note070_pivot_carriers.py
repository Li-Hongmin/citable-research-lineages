#!/usr/bin/env python3
"""Classify all three-matching decompositions of the Note-070 pivot half-loads."""

from collections import defaultdict
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parents[1]
    / "computations/bundles/failed-pivot-residual-selector-counterexample"
    / "verify_failed_pivot_residual_avoiding_pole.py"
)
SPEC = spec_from_file_location("note070", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def main():
    pms = sorted(BASE.enumerate_pms())
    matching_id = {pm: index for index, pm in enumerate(pms)}
    classes = defaultdict(list)
    for pm in pms:
        boundary = tuple(edge - 16 for edge in pm if edge >= 17)
        classes[boundary].append(pm)
    full = {
        label: tuple(sorted([BASE.E[edge] for edge in edges] +
                            [17 + position - 1 for position in BASE.B[label]]))
        for label, edges in BASE.VECTORS.items()
    }
    known_id = {pm: label for label, pm in full.items()}

    def name(pm):
        return known_id.get(pm, f"x{matching_id[pm]}")

    def load(row):
        return tuple(sum(edge in pm for pm in row) for edge in range(22))

    def decompositions(target):
        answer = defaultdict(list)
        for state in combinations(BASE.POSITIONS, 2):
            for row in product(classes[BASE.comp(state)],
                               *(classes[(i,)] for i in state)):
                if load(row) == target:
                    answer[state].append(tuple(name(pm) for pm in row))
        return {state: tuple(rows) for state, rows in sorted(answer.items())}

    reports = []
    for cell, row in BASE.ROWS:
        singleton = dict(zip(cell[0] + cell[1], row[2:], strict=True))
        sides = []
        for pair, triple in zip(cell, row[:2], strict=True):
            selected = (full[triple], *(full[singleton[i]] for i in pair))
            sides.append({
                "initial_state": pair,
                "initial_ids": (triple, *(singleton[i] for i in pair)),
                "decompositions": decompositions(load(selected)),
            })
        reports.append({"cell": cell, "sides": tuple(sides)})
    print({"rows": tuple(reports)})
    print("NOTE070_PIVOT_CARRIERS_CLASSIFIED")


if __name__ == "__main__":
    main()
