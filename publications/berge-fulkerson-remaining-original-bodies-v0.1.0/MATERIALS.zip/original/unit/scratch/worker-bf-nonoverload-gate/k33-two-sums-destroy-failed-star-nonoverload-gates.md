# $K_{3,3}$ two-sums destroy the failed-star nonoverload gates

This is a conditional obstruction theorem.  It does not construct an
exact-Case-XII pole from scratch.  It shows that, if such a pole contains a
failed pivot star, then support-preserving $K_{3,3}$ two-sums produce
another exact-Case-XII pole in which the proposed edge-nonoverload gate
fails.  Hence edge nonoverload cannot be forced from exact boundary support,
common perfect-matching incidence, and cubicity alone.

## Repeated-extension star

Use the notation

\[
 U=(A,B,C,D,X,Y)=(a_1,a_2,a_4,a_5,x,y)
\]

of Notes 072--073.  The four pivot singleton quadruples are

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD,            \tag{1}
\]

and the three target quadruples are

\[
 BDXY,\qquad ACXY,\qquad ABDY.                       \tag{2}
\]

### Theorem

Let a cubic 5-pole $H_0$ contain actual perfect matchings realizing the
repeated-extension failed star (1).  There is a pole $H_2$, obtained by two
successive $K_{3,3}$ two-sums on one proper edge and then one of its splice
edges, with the following properties.

1. The complete BF boundary support and complete Tait state set of $H_2$
   equal those of $H_0$.
2. The same singleton identities realize the same four pivot rows in
   $H_2$, with the same repeated-extension equality pattern.
3. Every quadruple in (2) has load at least three on some proper edge of
   $H_2$.

In particular, if $H_0$ has exact Case-XII support, then so does $H_2$,
but none of the three specified target tuples passes condition 1 of Note
078.

### Proof

Write the order of $H_0$ as $2k+3$.  It has $3k+2$ proper edges, and
each singleton-boundary perfect matching uses $k+1$ proper edges.  Hence
the six members of $U$ have total proper-edge load

\[
 6(k+1)=6k+6>2(3k+2).                               \tag{3}
\]

Every pivot row is a double cover, so none of its four singleton matchings
can have load three on one edge.  Note 073 enumerates the resulting possible
three-member hit sets as

\[
 ABY,ACY,ADY,BDX,AXY,BXY,CXY,DXY,                  \tag{4}
\]

and proves that no four-subset of $U$ can occur on one edge.  Thus (3)
gives a proper edge $e$ whose exact $U$-hit set $H$ is one of (4).

Identify perfect matchings of $K_{3,3}$ with permutations in $S_3$, and
let $f=u_0v_0$ be its distinguished edge.  Refining the finite check of
Note 077 by the prescribed $f$-hit set gives the following statement for
every $H$ in (4): there are two assignments of gadget perfect matchings to
$A,B,C,D,X,Y$ such that

- a gadget matching uses $f$ exactly when its identity lies in $H$;
- all four quadruples in (1) are completable by two gadget perfect
  matchings;
- the coordinatewise union of the two target-badness vectors is $111$.

Here a target is bad precisely when one gadget edge belongs to at least
three of its four assigned matchings.  The eight explicit pairs are checked
by the verifier below.  Note 077 already proves that one assignment never
has badness $111$, so two factors are sharp for this factorwise statement.

Insert the first factor along $e$.  For each pivot row, its four singleton
gadget matchings are completable.  The completing pair uses $f$ a total of
  $2-|H\cap R|$ times for pivot singleton set $R$, exactly the number of
  the row's two old triple matchings that use $e$.  The two completing
gadget matchings can therefore be assigned to those two row-private triple
identities and spliced occurrence by occurrence.  This preserves all four
pivot rows and their literal singleton reuse.

Both splice edges have the same matching hit signature as $e$.  Insert the
second factor along either one and repeat the argument.  A bad gadget edge
different from $f$ remains an edge of the sum; if the bad edge is $f$,
either splice edge has the same triple hit and supplies the overload instead.
After the second insertion one unused first splice edge remains.  The union
$111$ therefore gives an overload for every target in (2).  Note 076 gives
the exact preservation of complete BF support and Tait states under both
two-sums.

## Three-distinct-extension star

Let

\[
 U=(A,B,C,D,X,Y,Z)=(a_1,a_2,a_4,a_5,x,y,z)
\]

and use the four pivot rows and eight optimal four-row gates of Note 074.

### Theorem

From any cubic 5-pole carrying this actual three-distinct-extension star,
one $K_{3,3}$ two-sum produces a pole with the same complete BF support,
the same Tait states, and the same pivot star, but in which every one of the
eight Note-074 gates contains an overloaded specified quadruple.

### Proof

The seven singleton matchings have total proper load $7(k+1)$, exceeding
$2(3k+2)$, so some proper edge has hit set $H$ of size at least three.
Each of the four pivot quadruples meets $H$ in at most two identities.
There are exactly 29 subsets $H\subseteq U$ satisfying these conditions.

For each of the 29 possible $H$, the same $S_3$ matching enumeration
finds one assignment with prescribed $f$-hit set $H$, with all four
pivot quadruples completable, and with this additional property: each of the
eight optimal gates contains at least one target quadruple that is bad in
the gadget.  Splicing this assignment along the selected edge preserves the
pivot rows exactly as above.  The bad gadget or splice edge blocks every
gate at the edge-nonoverload stage.

## Exact boundary of the conclusion

The construction uses genuine perfect matchings of a common cubic 5-pole
and preserves complete exact Case-XII boundary support conditionally on a
base pole.  It is not an unconditional real Case-XII example, because no
such base pole is supplied here.  Each insertion also creates a cyclic
proper 2-edge-cut and internal 4-cycles.  Therefore it does not close a
girth-five or whole-graph-irreducible version of the gate.

The missing positive hypothesis is consequently not another local vertex
partition, matching-order equation, or boundary-support condition.  It must
couple different proper-edge factors--for example through girth five,
cyclic connectivity/minimality, or a theorem preventing independent
factorwise companion completions.  Without such an indecomposability input,
the edge-overload obstruction can be amplified at will.

## Verification

The standard-library verifier reuses the permanent enumerators of Notes 074
and 077:

```text
python3 units/berge-fulkerson/scratch/worker-bf-nonoverload-gate/verify_two_k33_overload_amplifier.py
```

It enumerates $6^6$ repeated-star assignments and $6^7$
three-distinct-star assignments.  On Omen with Python 3.10.12 it used one
process, 0.74 seconds wall time, and 12,288 KB maximum RSS.  Its final marker
is

```text
K33_FAILED_STAR_OVERLOAD_AMPLIFIERS_VERIFIED
```
