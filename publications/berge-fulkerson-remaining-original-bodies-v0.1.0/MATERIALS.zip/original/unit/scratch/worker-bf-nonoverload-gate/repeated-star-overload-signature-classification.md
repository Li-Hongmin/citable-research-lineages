# Local signature classification for three overloaded repeated-star targets

This note uses only the repeated-extension data of Notes 073 and 079, the
residual nonoverload gate of Note 078, the structural restrictions of Note
019, and the support-preserving boundary from Note 076.  It classifies what
can be deduced locally if all three repeated-star target quadruples are
overloaded.  It does **not** construct a global exact-Case-XII pole.

Write

\[
 U=\{A,B,C,D,X,Y\}
\]

and let the four pivot singleton quadruples be

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.
\]

The three desired reuse targets are

\[
 T_1=BDXY,\qquad T_2=ACXY,\qquad T_3=ABDY.
\]

By Note 073, every proper edge has (U)-load at most three, and an edge of
(U)-load three has one of the eight signatures

\[
 ABY,\ ACY,\ ADY,\ BDX,\ AXY,\ BXY,\ CXY,\ DXY.       \tag{1}
\]

## Exact target-wise classification

If a target (T_i) is overloaded, its witness edge has target load at least
three.  Since its total (U)-load is at most three, its complete hit
signature is a three-subset of (T_i).  Intersecting (1) with the three
targets gives exactly

\[
\begin{array}{c|c}
T_1=BDXY&BDX,\ BXY,\ DXY\\
T_2=ACXY&ACY,\ AXY,\ CXY\\
T_3=ABDY&ABY,\ ADY.
\end{array}                                           \tag{2}
\]

Thus a choice of one overload witness for each target has exactly
(3\cdot3\cdot2=18) possible signature triples.  No two targets can use the
same witness edge.  Indeed, a common witness would need an allowed
three-signature contained in the intersection of the two targets.  The
intersections (T_1\cap T_2=XY) and (T_2\cap T_3=AY) have size two, while
(T_1\cap T_3=BDY) is not in (1).

For completeness, the following two tables list all 18 possibilities by the
three pairwise intersection sizes

\[
 (|H_1\cap H_2|,|H_1\cap H_3|,|H_2\cap H_3|).
\]

For (H_3=ABY):

\[
\begin{array}{c|ccc}
 &ACY&AXY&CXY\\ \hline
BDX&(0,1,2)&(1,1,2)&(1,1,1)\\
BXY&(1,2,2)&(2,2,2)&(2,2,1)\\
DXY&(1,1,2)&(2,1,2)&(2,1,1)
\end{array}                                           \tag{3}
\]

For (H_3=ADY):

\[
\begin{array}{c|ccc}
 &ACY&AXY&CXY\\ \hline
BDX&(0,1,2)&(1,1,2)&(1,1,1)\\
BXY&(1,1,2)&(2,1,2)&(2,1,1)\\
DXY&(1,2,2)&(2,2,2)&(2,2,1).
\end{array}                                           \tag{4}
\]

## The only possible adjacency

At an internal cubic vertex, the (U)-hit sets of its three incidences are
pairwise disjoint: every member of (U) is a perfect matching and therefore
uses exactly one incidence at the vertex.  Consequently two overload
witness edges can be adjacent only when their signatures are disjoint.
Tables (3)--(4) show that the only disjoint pair is

\[
 H_1=BDX,\qquad H_2=ACY.                              \tag{5}
\]

In particular, the (T_3) witness is vertex-disjoint from both other
witnesses in every one of the 18 cases.  Sixteen signature triples force all
three witnesses to be pairwise vertex-disjoint.  In the remaining two
triples, namely

\[
 (BDX,ACY,ABY),\qquad (BDX,ACY,ADY),                  \tag{6}
\]

the first two witnesses may be adjacent, but adjacency is not forced.

The exceptional adjacency has an exact local form.  Suppose a vertex (v)
is incident with a (BDX)-edge and an (ACY)-edge.  The third incidence
(h) has empty (U)-signature.  Each pivot quadruple contributes two
singleton occurrences to each of the first two edges, so both triple
occurrences of every pivot row must use (h).  Thus all eight pivot triple
tokens use (h).

At the other endpoint (w) of (h), let (K\subseteq U) be the signature
of one of the other incidences.  The other has signature (U\setminus K),
and the four pivot rows require

\[
\begin{aligned}
 A+X+C+D&=2,\\
 A+B+X+C&=2,\\
 A+B+C+D&=2,\\
 B+Y+C+D&=2
\end{aligned}                                        \tag{7}
\]

for the indicator variables of (K).  Subtraction gives

\[
 B=D=X,\qquad A=Y,
\]

and (7) then has exactly the two complementary solutions

\[
 K=BDX\quad\hbox{or}\quad K=ACY.                    \tag{8}
\]

Hence the exceptional adjacency forms a two-vertex rung: (h=vw) has
empty (U)-signature and all eight triple tokens, and at each end the other
two edges have signatures (BDX) and (ACY).  In the canonical repeated
extension the five semiedge signatures are

\[
 \{A\},\ \{B\},\ \{X,Y\},\ \{C\},\ \{D\},
\]

so (h), (v), and (w) are proper and terminal-free.

## What the irreducibility hypotheses do and do not imply

The preceding classification yields only two possible marked local forests:

1. three pairwise vertex-disjoint proper edges; or
2. the terminal-free two-vertex rung above, together with a disjoint
   (ABY)- or (ADY)-edge.

Neither forest contains a cycle.  In the second case the two-vertex rung has
four proper boundary edges, not two.  Thus the local signature equations do
not force a triangle, a square, a bridge, or a terminal-free cyclic proper
2-edge-cut.  Girth at least five merely forbids later identifications of the
dangling endpoints that would close a short cycle; bridge-freeness and the
classification of proper 2-edge-cuts in Note 019 concern how the dangling
incidences are connected in the rest of the pole, information absent from
the three signatures.

This is therefore an exact local stopping boundary.  The signature census
does not prove the desired irreducible nonoverload theorem, but neither is it
a counterexample to that theorem: global realization of the three marked
forests by one complete perfect-matching family remains unproved.  A positive
argument must use a nonlocal consequence of girth five, whole-graph cyclic
connectivity/minimality, or companion completion across the rest of the pole;
it cannot follow from the three overload signatures and cubic endpoint
partitions alone.
