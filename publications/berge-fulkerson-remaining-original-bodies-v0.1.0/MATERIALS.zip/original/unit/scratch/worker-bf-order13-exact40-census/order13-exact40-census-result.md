# Order-13 exact-40 census (Omen, 2026-09-01)

This bounded computation exhaustively scanned all unlabelled simple connected
augmented graphs on 14 vertices with degree sequence `(5,3^13)`, deleting the
unique degree-five apex.  The retained poles have connected proper core,
five distinct terminals, and no proper-edge bridge.  For every retained pole
the complete 55 ordinary boundary types and the `(12345)` cover test were
computed, followed by canonicalization under all terminal permutations.

Result: no pole has exactly the 40 Case-XII ordinary types with no
`(12345)` cover.

Counts: 59,338 generated; 6,690 with the target degree sequence; 6,374 with
connected proper core; 1,580 proper-bridged; 4,794 proper-edge-bridgeless;
0 exact-40/no-A candidates.  Elapsed time was 42.736859 seconds on Omen.

The result is a strict order-13 no-hit only.  It is not an all-order
nonexistence proof and does not decide the common-incidence Case-XII gate.

Reproduction entry: `scan_order13_exact40.py`.
Raw JSON: `order13_exact40.json`.

Hashes:

- scanner SHA-256: `3abef3d91849e16f72a45b3d6695a23d4d4895b83f96c8a908b2b42d106727fc`
- JSON SHA-256: `ecc59e7c4b12bb2044c2798d91da8d5d57cbccb5874afb166c9c8453576e77bb`
- all generated graph6 SHA-256: `04daa4d720813d3ca7c0d515342881e7e3c63a522b56bea815ce456a1394ca6d`
- proper-connected graph6 SHA-256: `c535ad6eddcb44a42d8b5e60fb2f6763e5a8ea690c659e43c366e78d8cc55e4f`
- proper-bridgeless record SHA-256: `58b55b64589fe6fdd8ab55ac765b629ecd8aa7c0a94722d07903869ea88e164d`
