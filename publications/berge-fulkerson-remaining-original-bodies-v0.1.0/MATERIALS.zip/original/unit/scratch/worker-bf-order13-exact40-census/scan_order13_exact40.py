#!/usr/bin/env python3
"""Complete order-13 census for the real Case-XII 40-type support.

This pulse has one deliberately narrow purpose.  It streams *all* unlabelled
simple connected augmented graphs on 14 vertices with degree sequence
``(5,3^13)`` from nauty ``geng``.  The unique degree-five vertex is deleted;
the five neighbours become distinct semiedge terminals.  We retain exactly
the poles whose proper core is connected and has no proper-edge bridge, then
compute the complete 56-type BF support from the common perfect-matching
family of that one pole.

The five temporary terminal labels are removed from the decision by taking
the canonical representative under all 5! terminal permutations.  A hit is
therefore a genuine simple connected proper-edge-bridgeless cubic 5-pole
whose complete support is the Case-XII set (five S loops, ten S--S types and
twenty-five S--T types) and which has no A=(12345) cover.

This is an Omen-bound exhaustive certificate, not an arbitrary-order claim.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import time

import networkx as nx


HERE = Path(__file__).resolve().parent
SCRATCH = HERE.parent
sys.path.insert(0, str(SCRATCH / "worker-kempe"))
import exact_st_joint_audit as joint  # noqa: E402


ORDER = 13
POSITIONS = tuple(range(1, 6))
PAIRS = tuple(itertools.combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
TYPES = tuple(itertools.combinations_with_replacement(PAIRS, 2))


def target_support() -> frozenset:
    out = set()
    for first, second in TYPES:
        if first == second:
            if first in S:
                out.add((first, second))
        elif first in S and second in S:
            out.add((first, second))
        elif (first in S) ^ (second in S):
            out.add((first, second))
    assert len(out) == 40
    return frozenset(out)


TARGET = target_support()


def canonical_type(kind, permutation):
    if kind == ("A",):
        return kind
    first, second = kind

    def map_pair(pair):
        return tuple(sorted(permutation[x] for x in pair))

    return tuple(sorted((map_pair(first), map_pair(second))))


def canonical_support(support):
    def sort_key(kind):
        if kind == ("A",):
            return (0, ())
        return (1, kind)

    keys = []
    for perm in itertools.permutations(POSITIONS):
        mapping = {position: perm[position - 1] for position in POSITIONS}
        image = [canonical_type(kind, mapping) for kind in support]
        # The A marker is represented by a string tuple whereas ordinary
        # types are pairs of integer pairs; sort through the human encoding so
        # Python never compares those heterogeneous tuple entries directly.
        keys.append(tuple(sorted(image, key=sort_key)))
    return min(keys)


TARGET_CANONICAL = canonical_support(TARGET)


def human(kind) -> str:
    if kind == ("A",):
        return "(12345)"
    first, second = kind
    if first == second:
        return f"[{first[0]}{first[1]}]"
    return f"({first[0]}{first[1]})({second[0]}{second[1]})"


def support_text(support) -> tuple[str, ...]:
    return tuple(sorted(human(kind) for kind in support))


def pole_from_augmented(graph: nx.Graph, apex: int):
    """Delete the apex and canonically number its neighbours 0,...,4."""
    neighbours = tuple(sorted(graph.neighbors(apex)))
    if len(neighbours) != 5 or len(set(neighbours)) != 5:
        raise AssertionError("the apex does not have five distinct neighbours")
    mapping = {position: vertex for position, vertex in enumerate(neighbours, 1)}
    inverse = {vertex: position - 1 for position, vertex in mapping.items()}
    internal = sorted(set(graph) - {apex} - set(inverse))
    if len(internal) != ORDER - 5:
        raise AssertionError((len(internal), ORDER - 5))
    relabel = dict(inverse)
    relabel.update({vertex: 5 + i for i, vertex in enumerate(internal)})
    proper = tuple(sorted(
        joint.base.legacy.canonical_edge(relabel[u], relabel[v])
        for u, v in graph.edges()
        if apex not in (u, v)
    ))
    return joint.base.legacy.Pole(n=ORDER, proper_edges=proper), mapping


def full_support(data):
    """Compute all 55 non-A types; A is checked separately below."""
    support = set()
    for kind in TYPES:
        present, _, _ = joint.type_support_and_routes(
            kind, data, need_routes=False
        )
        if present:
            support.add(kind)
    return frozenset(support)


def inspect_graph(graph: nx.Graph):
    degree_values = Counter(dict(graph.degree()).values())
    if degree_values != Counter({3: ORDER, 5: 1}):
        return None
    apexes = [vertex for vertex, degree in graph.degree() if degree == 5]
    if len(apexes) != 1:
        raise AssertionError(apexes)
    apex = apexes[0]
    proper = graph.copy()
    proper.remove_node(apex)
    if not nx.is_connected(proper):
        return None
    proper_bridges = tuple(sorted(tuple(sorted(edge)) for edge in nx.bridges(proper)))
    pole, mapping = pole_from_augmented(graph, apex)
    data = joint.matching_data(pole)
    support = full_support(data)
    has_a = joint.capacity_witness(data) is not None
    canonical = canonical_support(support)
    return {
        "pole": pole,
        "mapping": mapping,
        "proper_bridges": proper_bridges,
        "matching_count": data[-1],
        "support": support,
        "has_A": has_a,
        "canonical_support": canonical,
    }


def digest_line(graph6, record) -> str:
    """Stable line used for the certificate digest (no Python hash randomisation)."""
    payload = {
        "graph6": graph6,
        "matching_count": record["matching_count"],
        "proper_bridges": record["proper_bridges"],
        "has_A": record["has_A"],
        "support": support_text(
            record["support"] | ({("A",)} if record["has_A"] else set())
        ),
        "canonical_support": tuple(human(kind) for kind in record["canonical_support"]),
    }
    return json.dumps(payload, separators=(",", ":"), sort_keys=True)


def scan_order(geng: str, limit: int | None = None, progress_every: int = 250):
    command = [
        geng, "-q", "-c", "-d3", "-D5", str(ORDER + 1),
        str((3 * ORDER + 5) // 2),
    ]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    if process.stdout is None:
        raise RuntimeError("failed to open geng output")

    counts = Counter()
    all_graph_digest = hashlib.sha256()
    proper_connected_digest = hashlib.sha256()
    bridge_free_digest = hashlib.sha256()
    support_size_distribution = Counter()
    canonical_support_distribution = Counter()
    matching_count_distribution = Counter()
    candidates = []
    started = time.perf_counter()

    for line in process.stdout:
        graph6 = line.strip()
        if not graph6:
            continue
        counts["generated"] += 1
        all_graph_digest.update((graph6 + "\n").encode("ascii"))
        if limit is not None and counts["generated"] > limit:
            break
        graph = nx.from_graph6_bytes(graph6.encode("ascii"))
        if Counter(dict(graph.degree()).values()) != Counter({3: ORDER, 5: 1}):
            continue
        counts["degree_sequence"] += 1
        apex = next(vertex for vertex, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        counts["proper_connected"] += 1
        # This digest covers all connected proper poles, including the ones
        # removed by the proper-bridge condition, without retaining them.
        proper_connected_digest.update((graph6 + "\n").encode("ascii"))
        record = inspect_graph(graph)
        assert record is not None
        if record["proper_bridges"]:
            counts["proper_bridged"] += 1
            continue
        counts["proper_bridgeless"] += 1
        line_digest = digest_line(graph6, record)
        bridge_free_digest.update((line_digest + "\n").encode("utf-8"))
        support_with_a = record["support"] | ({("A",)} if record["has_A"] else set())
        support_size_distribution[len(support_with_a)] += 1
        canonical_support_distribution[
            tuple(human(kind) for kind in record["canonical_support"])
        ] += 1
        matching_count_distribution[record["matching_count"]] += 1
        if record["canonical_support"] == TARGET_CANONICAL and not record["has_A"]:
            counts["exact_case_xii_no_A"] += 1
            candidates.append({
                "graph6": graph6,
                "mapping": {str(k): v for k, v in sorted(record["mapping"].items())},
                "proper_edges": [list(edge) for edge in record["pole"].proper_edges],
                "matching_count": record["matching_count"],
                "support": support_text(record["support"]),
                "has_A": record["has_A"],
            })
        if progress_every and counts["generated"] % progress_every == 0:
            print(
                "PROGRESS", dict(counts),
                "elapsed", round(time.perf_counter() - started, 3),
                file=sys.stderr,
                flush=True,
            )

    # If a test limit was used, terminate the producer deliberately.  The
    # final certificate is only accepted for the no-limit run.
    if limit is not None and process.poll() is None:
        process.terminate()
    returncode = process.wait()
    if limit is None and returncode:
        raise RuntimeError(f"geng failed with exit status {returncode}")

    return {
        "order": ORDER,
        "scope": (
            "all unlabelled simple connected augmented graphs with degree "
            "sequence (5,3^13), after deleting the unique degree-five apex: "
            "connected proper core, proper-edge bridgeless, five distinct terminals"
        ),
        "geng_command": command,
        "complete_run": limit is None,
        "limit": limit,
        "counts": dict(counts),
        "support_size_distribution": dict(sorted(support_size_distribution.items())),
        "canonical_support_distribution": {
            "|".join(key): value
            for key, value in sorted(canonical_support_distribution.items())
        },
        "matching_count_distribution": dict(sorted(matching_count_distribution.items())),
        "all_graph6_sha256": all_graph_digest.hexdigest(),
        "proper_connected_graph6_sha256": proper_connected_digest.hexdigest(),
        "proper_bridgeless_record_sha256": bridge_free_digest.hexdigest(),
        "candidates": candidates,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--geng", default="geng"
    )
    parser.add_argument("--limit", type=int, default=None, help="test-only prefix limit")
    parser.add_argument("--progress-every", type=int, default=250)
    parser.add_argument("--json", type=Path, default=None)
    args = parser.parse_args()

    result = scan_order(args.geng, args.limit, args.progress_every)
    result["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    if args.json is not None:
        args.json.write_text(
            json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    print("ORDER13_EXACT40_CENSUS_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
