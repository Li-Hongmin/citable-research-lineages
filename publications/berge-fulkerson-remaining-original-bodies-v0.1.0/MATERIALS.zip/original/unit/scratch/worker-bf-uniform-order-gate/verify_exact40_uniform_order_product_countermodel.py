#!/usr/bin/env python3
"""Symbolic exact-40, uniform-PM-order failed-star incidence countermodel."""

from collections import Counter
from itertools import combinations, combinations_with_replacement, product


P = tuple(range(1, 6))
S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
NAMES = (
    "a1", "a2", "a4", "a5", "x", "y",
    "qA", "r45", "qB", "r23", "qC", "r15", "qD", "r34",
)
SINGLETONS = frozenset(("a1", "a2", "a4", "a5", "x", "y"))
TRIPLES = frozenset(NAMES) - SINGLETONS
ROWS = (
    ("qA", "r45", "a1", "x", "a4", "a5"),
    ("qB", "r23", "a1", "a2", "x", "a4"),
    ("qC", "r15", "a1", "a2", "a4", "a5"),
    ("qD", "r34", "a2", "y", "a4", "a5"),
)
STAR_CELLS = (
    ((1, 3), (4, 5)), ((1, 4), (2, 3)),
    ((2, 4), (1, 5)), ((2, 5), (3, 4)),
)
B = {
    "a1": {1}, "a2": {2}, "a4": {4}, "a5": {5},
    "x": {3}, "y": {3},
    "qA": {2, 4, 5}, "r45": {1, 2, 3},
    "qB": {2, 3, 5}, "r23": {1, 4, 5},
    "qC": {1, 3, 5}, "r15": {2, 3, 4},
    "qD": {1, 3, 4}, "r34": {1, 2, 5},
}

BLOCKERS = (
    frozenset(("a2", "a5", "r23", "r45")),
    frozenset(("a4", "r15", "r23", "r45", "y")),
    frozenset(("a1", "r15", "r34", "x", "y")),
    frozenset(("a5", "r15", "r23", "r34", "x")),
)
COMPLETION = (
    frozenset(("a5", "x", "qB", "qC", "r34")),
    frozenset(("a5", "x", "qB", "qC", "qD")),
    frozenset(("a4", "r45", "qB", "qC", "qD")),
    frozenset(("a2", "a4", "qA")),
    frozenset(("a1", "a4", "qD")),
    frozenset(("a1", "a2", "y", "qA")),
    frozenset(("a1", "a2", "y", "qA")),
)
LOCAL = BLOCKERS + COMPLETION
BASE_STAR = LOCAL + (TRIPLES,)
STAR_SPLIT = (
    frozenset(("a1", "a4", "y")),
    frozenset(("a2", "a5", "x")),
)


def state(name):
    return tuple(sorted(set(P) - B[name])) if len(B[name]) == 3 else None


def forbidden_selectors():
    available = Counter(name for row in ROWS for name in row)
    out = []
    for candidate in combinations_with_replacement(NAMES, 5):
        used = Counter(candidate)
        if any(used[name] > available[name] for name in used):
            continue
        loads = tuple(sum(p in B[name] for name in candidate) for p in P)
        if not all(load in (1, 2) for load in loads):
            continue
        residual = {p for p, load in zip(P, loads) if load == 1}
        sizes = sorted([len(B[name]) for name in candidate] + [len(residual)])
        if sizes != [1, 1, 1, 1, 3, 3]:
            continue
        states = [state(name) for name in candidate if state(name) is not None]
        if len(residual) == 3:
            states.append(tuple(sorted(set(P) - residual)))
        if len(states) == 2 and all(item in T for item in states):
            out.append(candidate)
    return tuple(out)


def pair_support(columns):
    vectors = {name: tuple(name in c for c in columns) for name in NAMES}
    triple = {state(name): name for name in TRIPLES}
    singleton = {
        p: tuple(name for name in SINGLETONS if B[name] == {p}) for p in P
    }
    support = set()
    for left, right in combinations_with_replacement(sorted(triple), 2):
        for singles in product(*(singleton[p] for p in left + right)):
            row = (triple[left], triple[right], *singles)
            if all(sum(vectors[name][i] for name in row) == 2
                   for i in range(len(columns))):
                support.add((left, right))
                break
    return frozenset(support)


def verify_two_subset_factor():
    pairs = tuple(combinations(range(6), 2))
    assert len(pairs) == 15
    assert {sum(i in pair for pair in pairs) for i in range(6)} == {5}
    # This is the separation fact used by every private positive-row factor.
    for counts in product(range(7), repeat=6):
        if sum(counts) <= 6:
            pair_sums = {counts[i] + counts[j] for i, j in pairs}
            if len(pair_sums) == 1:
                assert len(set(counts)) == 1
    return pairs


def verify_covering_graph_gate():
    vertices = ("a1", "a2", "a4", "a5", "x", "y")
    base = {
        frozenset(edge) for edge in (
            ("a2", "y"), ("a5", "y"), ("x", "y"), ("a1", "x")
        )
    }
    all_edges = {frozenset(edge) for edge in combinations(vertices, 2)}

    def alpha_at_most_two(edges):
        return all(
            any(edge <= set(triple) for edge in edges)
            for triple in combinations(vertices, 3)
        )

    missing = tuple(sorted(all_edges - base, key=lambda edge: tuple(sorted(edge))))
    solutions = []
    minimum = None
    for added_count in range(len(missing) + 1):
        solutions = [
            added for added in combinations(missing, added_count)
            if alpha_at_most_two(base | set(added))
        ]
        if solutions:
            minimum = added_count
            break
    expected = {
        frozenset(("a1", "a4")),
        frozenset(("a2", "a5")),
        frozenset(("a4", "x")),
    }
    assert minimum == 3 and len(solutions) == 1
    assert set(solutions[0]) == expected
    return minimum, expected


def main():
    positive = set(combinations_with_replacement(S, 2))
    positive.update((s, t) for s in S for t in T)
    assert len(positive) == 40 and set(STAR_CELLS) <= positive

    assert all(sum(name in c for name in row) == 2
               for c in LOCAL for row in ROWS)
    local_weight = {name: sum(name in c for c in LOCAL) for name in NAMES}
    assert {local_weight[name] for name in SINGLETONS} == {4}
    assert {local_weight[name] for name in TRIPLES} == {3}
    assert len(LOCAL) == 11 and 2 * len(LOCAL) + 5 == 3 * 9
    assert all(2 * local_weight[name] + len(B[name]) == 9 for name in NAMES)

    selectors = forbidden_selectors()
    assert len(selectors) == 69
    assert all(any(sum(name in c for name in f) not in (1, 2)
                   for c in BLOCKERS) for f in selectors)

    assert all(sum(name in c for name in row) == 2
               for c in BASE_STAR for row in ROWS)
    assert {sum(name in c for c in BASE_STAR) for name in NAMES} == {4}
    normalized_star_cells = frozenset(tuple(sorted(cell)) for cell in STAR_CELLS)
    assert pair_support(BASE_STAR) == normalized_star_cells
    assert all(sum(name in c for name in row) == 2
               for c in STAR_SPLIT for row in ROWS)
    assert all(sum(name in c for c in STAR_SPLIT) == 1 for name in SINGLETONS)
    assert all(sum(name in c for c in STAR_SPLIT) == 0 for name in TRIPLES)

    private_cells = positive - set(STAR_CELLS)
    pairs = verify_two_subset_factor()
    minimum_covering_edges, covering_completion = verify_covering_graph_gate()
    assert len(private_cells) == 36

    # E0 = BASE_STAR x product_g binom([6]_g,2).  The product is kept
    # symbolic.  Every token has base density 1/3.  Two final coordinates
    # split the four singleton occurrences of every row and contain no
    # triple token.
    base_edges = len(BASE_STAR) * len(pairs) ** len(private_cells)
    base_weight = base_edges // 3
    proper_edges = base_edges + 2
    order = 2 * base_weight + 3
    assert base_edges == 3 * base_weight
    assert 2 * proper_edges + 5 == 3 * order
    assert 2 * (base_weight + 1) + 1 == order
    assert 2 * base_weight + 3 == order

    extensions = ("x", "x", "y")
    assert len(set(extensions)) == 2  # separately extendible, no common value
    six_singleton_weight = 6 * (base_weight + 1)
    assert six_singleton_weight == 2 * proper_edges + 2

    print({
        "exact_positive_pair_types": len(positive),
        "forbidden_A_Tloop_TT": 0,
        "star_pair_support": tuple(sorted(normalized_star_cells)),
        "failed_star_extensions": extensions,
        "forbidden_selectors": len(selectors),
        "all_selectors_blocked": True,
        "private_positive_row_factors": len(private_cells),
        "proper_edges_symbolic": proper_edges,
        "uniform_singleton_weight": base_weight + 1,
        "uniform_triple_weight": base_weight,
        "common_order": order,
        "six_singleton_capacity_excess": 2,
        "minimum_additional_covering_rows": minimum_covering_edges,
        "unique_minimum_missing_pairs": tuple(
            sorted(tuple(sorted(edge)) for edge in covering_completion)
        ),
        "common_trivalent_vertex_incidence": False,
    })
    print("EXACT40_UNIFORM_ORDER_PRODUCT_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
