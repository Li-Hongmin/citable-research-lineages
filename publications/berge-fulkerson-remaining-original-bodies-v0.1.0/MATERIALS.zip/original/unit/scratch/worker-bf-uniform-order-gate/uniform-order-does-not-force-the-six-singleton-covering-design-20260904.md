# Uniform PM order does not force the six-singleton covering design

## Decision

The common-order strengthening is false at the common binary
proper-coordinate level.  There is a finite symbolic incidence model with

\[
15\ S\text{--}S+25\ S\text{--}T
\]

as its exact pair-type support, no \(A\), \(T\)-loop, or \(T\)--\(T\)
equation, a failed four-row \(D_5\) pivot star, and one common odd integer
\(n\) such that every pool vector satisfies

\[
 2|M_{\rm proper}|+|\partial M|=n.                 \tag{1}
\]

All 69 forbidden-boundary selectors of the failed star remain blocked.
Thus exact BF-40 plus (1) does not force either a residual selector or the
six-singleton low-load configuration at this abstraction level.

The construction has no common trivalent vertex incidence and is not a
cubic 5-pole.  Consequently the corresponding statement for real cubic
5-poles remains undecided; the next indispensable layer is vertex incidence
and the perfect-matching closure that it induces.

## An eleven-column uniform failed-star factor

Use the four rows

\[
\begin{aligned}
A&=(q_A,r_{45},a_1,x,a_4,a_5),\\
B&=(q_B,r_{23},a_1,a_2,x,a_4),\\
C&=(q_C,r_{15},a_1,a_2,a_4,a_5),\\
D&=(q_D,r_{34},a_2,y,a_4,a_5).
\end{aligned}                                      \tag{2}
\]

Here \(a_i\) has singleton boundary \(i\), both \(x,y\) have singleton
boundary 3, and the eight triple tokens have the boundary classes indicated
by their state labels.  The anchor row is \(C\); its three unique extension
values are \(x,x,y\).  Hence (2) is separately extendible but its common
extension fibre is empty.

The following eleven proper columns meet every row of (2) in exactly two
occurrences:

\[
\begin{array}{c|l}
1& a_2,a_5,r_{23},r_{45}\\
2& a_4,r_{15},r_{23},r_{45},y\\
3& a_1,r_{15},r_{34},x,y\\
4& a_5,r_{15},r_{23},r_{34},x\\
5& a_5,x,q_B,q_C,r_{34}\\
6& a_5,x,q_B,q_C,q_D\\
7& a_4,r_{45},q_B,q_C,q_D\\
8& a_2,a_4,q_A\\
9& a_1,a_4,q_D\\
10& a_1,a_2,y,q_A\\
11& a_1,a_2,y,q_A.
\end{array}                                         \tag{3}
\]

Every singleton vector in (3) has weight 4 and every triple vector has
weight 3.  Since \(m=11\), (1) holds with \(n=9\), and
\(2m+5=3n\).  The first four columns are the known sharp blocker: every one
of the 69 forbidden-boundary five-occurrence selectors has load 0 or at
least 3 in one of them.  The remaining seven columns change only the PM
weights; they preserve those blockers.

## Exact-40 product extension

Adjoin to (3) the column containing all eight triple tokens.  This gives a
twelve-column star factor \(C_0\) in which every one of the fourteen tokens
has weight 4.  Adding a coordinate cannot create a new double-cover
equation, and direct enumeration on the eleven original columns shows that
the only pair-type equations in this factor are the four positive cells in
(2).

For each of the other 36 positive Case-XII cells, introduce a private
six-token row: two triple tokens with the required boundary classes and four
singleton tokens with the required boundary classes.  Even when a boundary
class repeats, its occurrences receive distinct identities.  Give this row
the factor

\[
 \binom{[6]}2,
\]

whose fifteen coordinates select every pair of its six tokens.  Define the
base proper universe by the Cartesian product

\[
 E_0=C_0\times\prod_{g=1}^{36}\binom{[6]_g}{2}.       \tag{4}
\]

Every designated row has load two at every coordinate of (4), and every
token has weight exactly one third of \(|E_0|\).  Moreover, if a six-token
multiset has constant load two on (4), varying the \(g\)-th pair while all
other factors are fixed shows that all six multiplicities in group \(g\)
are equal.  Since the multiset has total size six, it is therefore either
one entire private group or lies wholly in the star factor.  The latter has
only the four equations in (2).  Hence (4) has exactly the forty designated
pair types and no forbidden pair type.  There is no boundary-five token, so
there is no \(A\)-equation.

Finally add two coordinates.  In every private row they partition its four
singleton tokens into two pairs and contain neither triple token.  In the
star factor use

\[
 {a_1,a_4,y\},\qquad {a_2,a_5,x\}.                 \tag{5}
\]

Each set in (5) meets every row of (2) twice.  Thus all forty equations
survive, each singleton weight increases by one, and no triple weight
changes.  Put

\[
 m_0=12\cdot15^{36}=3b,qquad m=m_0+2,qquad n=2b+3.
\]

Then every singleton has proper weight \(b+1\), every triple has proper
weight \(b\), and both boundary sizes satisfy (1).  The four original
blocker columns occur in (4), so the failed star and all 69 blocked selectors
survive unchanged.

## The exact six-singleton covering-design gate

Let \(U\) be six actual singleton PM identities.  For every actual BF row
whose four singleton occurrences form a four-subset of \(U\), put the
missing pair \(U\setminus R\) as an edge of a graph \(G_U\) on \(U\).
Then

\[
 \alpha(G_U)\le2                                      \tag{6}
\]

is exactly the condition that every three-subset of \(U\) is contained in
the singleton part of some such row.  Indeed, a triple \(X\subset U\) is
covered precisely when the complementary triple \(U\setminus X\) contains
an edge of \(G_U\).

Condition (6) forces the desired low-load conclusion.  If three members of
\(U\) used one proper edge, a row covering that triple would have singleton
load at least three there, contradicting its six-vector double-cover
equation.  Hence every edge has \(U\)-load at most two.  But in a cubic
5-pole with \(m=3b+2\), the six singleton PMs have total proper weight

\[
 6(b+1)=2m+2>2m,                                    \tag{7}
\]

a contradiction.

Thus (6), not uniform PM order by itself, is the exact sufficient
witness-reuse condition for this counting proof.  Mantel's theorem gives
\(|E(G_U)|\ge6\); equality requires
\(G_U\cong K_3\sqcup K_3\).  In the canonical star (2), the four row edges
are

\[
 a_2y,\quad a_5y,\quad xy,\quad a_1x.               \tag{8}
\]

They cannot lie in \(K_3\sqcup K_3\), because \(y\) already has degree
three.  A complete local enumeration shows that at least three additional
row edges are necessary, and the unique minimum completion is

\[
 a_1a_4,\quad a_2a_5,\quad a_4x.                    \tag{9}
\]

Equivalently, exact-40 must supply three further actual rows whose singleton
quadruples are the complements of the pairs in (9), using these same six
PM identities.  Notes 055 and 057 provide the required boundary cells and
three-coordinate transports, but do not identify their new singleton
tokens with the tokens in (9).  The previously verified saturated-column
witness hypergraph realizes precisely this failure.

When the three pivot extensions are all distinct, the natural singleton
family has seven members and one must first choose a six-subset.  The Note
070 pole shows that the inevitable triple-hit edges in every such six-set
are not confined to the three extensions: they include both
two-extension/one-anchor and one-extension/two-anchor triples.  Therefore a
no-\(T\)--\(T\) argument must control both mixed forms; forbidding an edge
common to all three extensions cannot establish (6).

## Evidence boundary

The product construction proves

\[
 \text{exact BF-40 binary equations}+
 \text{uniform PM order}
 \not\Longrightarrow (6),
\]

and hence does not force a residual selector or a join at the shared-vector
level.  It does not satisfy common cubic vertex equations or full graph PM
closure.  For a real cubic pole the precise remaining question is whether
those incidence constraints force some six-token graph \(G_U\) to satisfy
(6).

The symbolic verifier is
`verify_exact40_uniform_order_product_countermodel.py` and ends with

```text
EXACT40_UNIFORM_ORDER_PRODUCT_COUNTERMODEL_VERIFIED
```
