# Four-junction normal form for an overlapping BF row (analytic draft)

This draft sharpens [Note 142](../notes/142-overlap-rows-force-four-singleton-phase-junctions.md). Its assumptions are one actual complete row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1
\]
and absence of a state-\(34\) Tait colouring. It does not assume that an exact-Case-XII pole exists. All switches below act on complete perfect matchings, including semiedges.

Pair the occurrences as \(E_1=(U,r)\), \(E_2=(Z,Y)\), \(E_3=(D,C)\), and put \(F_i=E_i^0\triangle E_i^1\). As in Note 142, each active edge has type \(12,13,23\), and a junction has one incident edge of each type. The only active terminal semiedges are \(4,5\), both of type \(13\). Suppress degree-two active vertices and independently normalize junction-free monochromatic cycles by closed pair switches. Call the resulting coloured multigraph the *core*. A strand is *overloaded* when its edges have half-load \((2,0)\) or \((0,2)\); otherwise it is split. The status is constant along a strand. At each junction either zero or two strands are overloaded, and both terminal arms are split.

## All-orders concentration theorem

If there is no state-\(34\) Tait colouring, **at least one individual alternating cycle of** \(Z_3\triangle Y_3\) **contains four or more junctions**. In particular, any number of mutually separate two-junction singleton-phase cycles cannot account for the obstruction.

To prove this, suppose instead that every \(F_2\) cycle contains zero or two junctions. Normalize the zero-junction monochromatic cycles and contract each two-junction \(F_2\) cycle to a vertex. It consists of one type-\(12\) strand and one type-\(23\) strand between its two junctions. The remaining type-\(13\) strands give the contracted vertices degree two, except for the two terminal leaves. Thus the contracted network is a disjoint union of cycles and one path between terminals \(4,5\).

At a contracted vertex let \(x,y\) be the overload bits of its type-\(12\), type-\(23\) strands. Both incident type-\(13\) strands have the same bit \(z=x\oplus y\), by the junction rule. The two terminal arms are split, so \(z=0\) throughout the terminal path. Every closed contracted cycle has a constant bit \(z\) on its type-\(13\) strands. When \(z=1\), its type-\(13\) strands together with all its type-\(12\) strands form **one closed component of** \(F_1=U\triangle r\); switch \(E_1\) on that component to set \(z=0\). Now \(x=y\) on every contracted vertex. Switch \(E_2=(Z,Y)\) on each two-junction \(F_2\) cycle whose two strands are overloaded. All active edges become split, so the \(r+Y+C\) half is a proper state-\(34\) Tait colouring, a contradiction. Every \(F_2\) cycle has an even number of junctions by Note 142; hence the first cycle escaping this normalization has at least four. \(\square\)

## Conditional classification

If the number of junctions is \(J=4\), all four lie on **one** alternating cycle of \(F_2=Z_3\triangle Y_3\). After further closed pair switches, the core must have one of the following two patterns; realizability in an exact-Case-XII pole is not asserted:

1. The two type-\(13\) terminal arms are in a component with no junctions. The four junctions form a terminal-free properly three-coloured \(K_4\): the three strand types are its three distinct perfect matchings. Exactly three strands, forming a triangle in the suppressed core, are overloaded.
2. All four junctions lie in the terminal component. Their \(F_2\) strands form a four-cycle of alternating types \(12,23\). The two terminal arms attach at opposite vertices, and the remaining two vertices are joined by a type-\(13\) chord. Exactly three strands are overloaded: the chord and the two \(F_2\) strands through one of the terminal-arm vertices. They form a triangle in the suppressed core. The other terminal-arm vertex has only split incident strands.

The three overloaded strands form an **even proper cycle in the original pole**: at every vertex of that cycle its two overloaded edges have opposite half-loads. Thus a triangle in the suppressed core does not assert a three-cycle in the cubic pole. If the pole has proper girth at least five, this even cycle has length at least six.

## Exact-negative-support exclusion of the terminal-free core

If the complete BF support also excludes the loop \([34]\), the active component containing terminals \(4,5\) **must contain at least two junctions**. Indeed, if it contains none, it is a single split type-\(13\) path between those terminals. Its edge owners alternate between \(\{U,C\}\) and \(\{r,D\}\), while its inactive third edges are owned by \(\{Z,Y\}\). It is therefore the whole open \(4\leftrightarrow5\) alternating component of \(U_{35}\triangle D_5\). Switch \(U_{35},D_5\) along it. Their boundaries become triple missing \(34\) and singleton \(4\), respectively, so the six matching occurrences give a BF row of forbidden type \([34]\). Every active component has an even number of junctions, as proved below. Thus the terminal-free \(K_4\) pattern above is impossible under exact Case-XII negative support.

Consequently, **if an actual exact-Case-XII overlap row has \(J=4\), only the terminal-connected diamond pattern can occur**. Its four junctions lie on one \(Z_3\triangle Y_3\) cycle; the two type-\(13\) terminal arms attach at opposite junctions; and, after boundary-preserving closed pair switches, an even overloaded cycle traverses the chord and the two phase-cycle strands at one arm junction. The four-junction case remains conditional: this does not assert that an exact-Case-XII pole or such a row exists.

The diamond's type-\(13\) chord also contains an actual edge of \(r_{34}\cap C_4\). If \(r_{34}\) and \(C_4\) were edge-disjoint, their cubic complement would be a singleton-\(3\) perfect matching and give a forbidden state-\(34\) Tait colouring. An edge shared by \(r,C\) is overloaded of type \(13\), and after the closed-cycle normalization the chord is the only such strand. Along an overloaded type-\(13\) strand its owner pairs alternate \(\{r,C\}\) and \(\{U,D\}\) at each internal degree-two vertex. Therefore:
\[
\boxed{\text{one-edge chord}\quad\Longrightarrow\quad U_{35}\cap D_5=\varnothing
\quad\Longrightarrow\quad\text{an actual state-}35\text{ Tait colouring}.}
\]
The last implication uses the cubic complement of the disjoint matchings \(U_{35}\) and \(D_5\), whose terminal union is \(\{1,2,4,5\}\). Under exact Case-XII support, the usual bichromatic terminal-path switches then propagate this state around the \(S\)-pentagon, so a one-edge chord forces the full Tait-state set \(S\), as in [Note 130](../notes/130-the-mixed-side-right-row-exceptional-class-three-forces-an-s-tait-state.md). In the Tait-empty exact-Case-XII branch, the chord must consequently contain at least two proper edges and carries **both** owner pairs \(\{r,C\}\) and \(\{U,D\}\). This locates one complete-matching Tait blocker on the exterior phase core; it does not identify which component of \(q_{25}\triangle r_{34}\) uses its \(r\)-owned edges.

The same argument applies to **all three** strands of the overloaded triangle. Any two edge-disjoint matchings among \(r_{34},Y_3,C_4\) would, with their cubic complement, give a forbidden state-\(34\) Tait colouring. Each such same-half intersection is overloaded, and the normalized \(J=4\) core has just one overloaded strand of each type. Hence the following actual owner pairs all occur on their indicated strand:
\[
\begin{array}{c|c|c}
\text{strand type}&\text{required by no state-}34\text{ Tait}&
  \text{also required when Tait-empty}\\\hline
12&r_{34}\cap Y_3&U_{35}\cap Z_3\\
13&r_{34}\cap C_4&U_{35}\cap D_5\\
23&Y_3\cap C_4&Z_3\cap D_5
\end{array}
\]
The rightmost intersections are forced by Tait-emptiness: disjointness of either pair would give a state-\(35\) Tait colouring by complementing the two matchings. On an overloaded strand the owner pair alternates between its \(T\)-pair and \(S\)-pair at every internal degree-two vertex. Therefore **any one-edge triangle strand forces an actual state-\(35\) Tait colouring**, and every strand has length at least two in the Tait-empty branch. This conclusion concerns the normalized actual row; the closed pair switches preserve the boundary states and the complete double cover.

If, in addition, the disjoint pairing-critical hexagon \(\Gamma\) of [Notes 140](../notes/140-disjoint-singleton-phase-has-a-unique-critical-six-cycle-owner-pattern.md) and [141](../notes/141-a-disjoint-critical-hexagon-is-a-five-edge-carrier-detour.md) exists, its entire incident edge set is split in the original row. In the diamond normalization, switch only overloaded junction-free components and, if needed, the \(F_2\) cycle; the latter avoids every edge incident with \(\Gamma\). Thus those edges remain split, and the overloaded triangle is wholly outside \(V(\Gamma)\), including its type-\(13\) strand. This is a localization, not a contradiction with the seed obstruction.

For an exact-Case-XII row in the no-common-seed branch of [Notes 137--138](../notes/137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md), if the critical cycle is a disjoint hexagon of Note 140, the concentration theorem therefore forces **one exterior** \(Z_3\triangle Y_3\) cycle with at least four junctions. At the minimal count \(J=4\), the exact negative support restricts this to the terminal-connected diamond just described. No conclusion here makes that phase cycle intersect either forced \(2\leftrightarrow3\) carrier path outside the hexagon.

## Proof

Switching the two matchings of \(E_i\) on one closed component of \(F_i\) preserves both matching boundaries and the six-row identity. On every active strand of that component, it toggles split versus overloaded. Thus the overload indicator is a binary cycle-space vector of the core, and the available closed \(F_i\) components can be added to that vector. A junction-free monochromatic cycle is itself a closed component of either relevant \(F_i\), so it may be made split.

Each active component has an even number of junctions: every junction has one type-\(12\) port, and the type-\(12\) strands pair those ports without reaching a terminal. Its number of terminal leaves is also even, since the type-\(13\) ports pair junctions and leaves. Therefore terminals \(4,5\) belong to the same active component. A closed two-junction component has three differently typed strands joining its junctions. Its overload is either empty or two of these strands, removed by switching the common pair difference. A terminal two-junction component has two split type-\(13\) arms and type-\(12\), type-\(23\) strands between the junctions; the latter are both split or both overloaded, and the closed \(F_2\) switch removes the second case. A zero-junction terminal component is a split type-\(13\) path. Hence if \(J=4\) and no state-\(34\) Tait colouring exists, all four junctions belong to one component.

First suppose that component has no terminal leaves. Each of the three strand types is a perfect matching of its four junctions. If two types give the same pairing, their two parallel-strand cycles, together with a closed cycle using the third type, form a basis of the component's three-dimensional binary cycle space. All overload can then be switched away. If all three pairings differ, the component is \(K_4\); each \(F_i\) is one four-cycle. These three four-cycles span the two-dimensional subspace of even subgraphs with even edge count. Its other coset consists of the four triangles. The split coset would yield a state-\(34\) Tait colouring after normalizing every other component, so the overload is in the triangle coset and can be switched to one triangle. In this case \(F_2\) is a single four-junction cycle.

Now suppose the four-junction component contains the two terminal leaves. Its \(F_2\) components are either two two-junction cycles or one four-junction cycle. In the first case connectedness forces one terminal arm onto each two-junction cycle, with the other two type-\(13\) ports joined across the cycles. At each terminal junction the two \(F_2\) strands have equal overload status. Switch each closed \(F_2\) cycle if necessary; its strands become split, which also forces the connecting type-\(13\) strand to be split. This would yield a Tait colouring. Hence \(F_2\) is one four-cycle.

Label this four-cycle \(a b c d a\), with strand types alternating \(12,23\). The terminal arms attach at two distinct vertices, and the remaining vertices are joined by one type-\(13\) chord. If the arms attach at adjacent vertices, their split status forces three consecutive four-cycle strands to have the same overload bit \(x\). Switch the whole \(F_2\) cycle to set \(x=0\). The remaining four-cycle strand and the parallel type-\(13\) chord then have the same bit; together they are a closed component of \(F_1\) or \(F_3\), so switch it if necessary. Again every edge becomes split, giving a Tait colouring. Thus the arms are opposite.

In the opposite-arm case, the two four-cycle strands incident to one terminal junction have a common overload bit \(x\), and those incident to the other have a common bit \(z\). The chord has bit \(x\oplus z\). If \(x=z\), switching the closed \(F_2\) cycle when needed clears every bit and gives the forbidden Tait colouring. Hence \(x\ne z\). Switching that cycle can place the two overloaded four-cycle strands at either terminal junction; with the chord they form the stated triangle. The \(F_1\) and \(F_3\) components through this core are open terminal paths, so this remaining triangle is not removed by a closed pair switch.

Finally, [Note 141, equation (6)](../notes/141-a-disjoint-critical-hexagon-is-a-five-edge-carrier-detour.md) lists every owner pair on edges incident with \(\Gamma\). Each pair has one occurrence in \(\{U,Z,D\}\) and one in \(\{r,Y,C\}\), in either owner branch. Hence these edges are split, and no overloaded strand can traverse them. \(\square\)

The [Máčajová--Mazzuoccolo--Tabarelli source](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Appendix XII, excludes the \([34]\) BF loop, so every actual exact-Case-XII overlapping row meets the theorem's no-state-\(34\) assumption. Proposition 4.4 does not require the pole to admit any Tait colouring.

This is a conditional minimal-core classification. It does not prove that \(J=4\) is attained in an exact-Case-XII pole, force \(Z_3\triangle Y_3\) to meet \(\Gamma\), or settle the common-\(B_2+C_4\) pair-load intersection.

## Literal fixed-\(B_2,C_4\) transfer of one phase cycle

The phase cycle has an exact full-mask test for a useful additional right row. Restore the carrier identity \(q_{25}+B_2=U_{35}+Z_3\), and let \(\Omega\) be any single component of \(Z_3\triangle Y_3\). Exchange \(Z_3,Y_3\) along \(\Omega\), giving actual matchings \(Z^\Omega,Y^\Omega\). Define the formal vector
\[
q^\Omega=q_{25}+Y_3-Y^\Omega
          =q_{25}+Z^\Omega-Z_3.                    \tag{*}
\]
Then \(q^\Omega\) is an actual triple-boundary perfect matching **if and only if** \(q_{25}\) uses every \(Z_3\)-edge and no \(Y_3\)-edge of \(\Omega\). Equivalently, by \(q_{25}+B_2=U_{35}+Z_3\), \(B_2\) and \(U_{35}\) agree on every edge of \(\Omega\). Indeed, if this holds then \(q^\Omega=q_{25}\triangle\Omega\); otherwise (*) has a negative or a double coordinate on \(\Omega\). In the positive case,
\[
q^\Omega+B_2+D_5+r_{34}+Y^\Omega+C_4=2\mathbf1,
\qquad q^\Omega+B_2=U_{35}+Z^\Omega,
\]
so this one cycle yields another actual right row with the **same complete** \(B_2,D_5,r_{34},C_4\) masks. The terminal-pairing theorem of [Note 136](../notes/136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md) applies separately to both rows. The diamond normal form alone does not establish this edgewise agreement or force either row to meet the left \(B_2+C_4\) spectrum.
