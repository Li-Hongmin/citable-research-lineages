"""Check whether boundary-role labels determine the C-phase in Note 040.

The graph is the connected 15-vertex cubic 5-pole from Note 020.  This is
scratch evidence only: the structural proof does not depend on enumeration.
"""

from collections import defaultdict


PROPER = (
    (0, 2), (0, 3), (1, 5), (1, 7), (2, 4),
    (3, 14), (4, 11), (5, 6), (5, 9), (6, 7),
    (6, 10), (7, 8), (8, 9), (8, 13), (9, 12),
    (10, 11), (10, 14), (11, 12), (12, 13), (13, 14),
)
EDGE_VERTICES = {f"e{i}": frozenset(edge) for i, edge in enumerate(PROPER)}
EDGE_VERTICES.update({f"s{i}": frozenset({i - 1}) for i in range(1, 6)})
EDGES = frozenset(EDGE_VERTICES)
INCIDENT = {
    v: tuple(e for e, ends in EDGE_VERTICES.items() if v in ends)
    for v in range(15)
}


def boundary(matching):
    return frozenset(e for e in matching if e.startswith("s"))


def enumerate_matchings():
    out = set()

    def dfs(uncovered, chosen):
        if not uncovered:
            out.add(frozenset(chosen))
            return
        v = min(uncovered)
        for edge in INCIDENT[v]:
            ends = EDGE_VERTICES[edge]
            if ends <= uncovered:
                dfs(uncovered - ends, chosen + (edge,))

    dfs(frozenset(range(15)), tuple())
    return tuple(sorted(out, key=lambda m: tuple(sorted(m))))


def components(edge_set):
    edge_set = set(edge_set)
    by_vertex = defaultdict(set)
    for edge in edge_set:
        for v in EDGE_VERTICES[edge]:
            by_vertex[v].add(edge)
    out = []
    while edge_set:
        seed = next(iter(edge_set))
        stack = [seed]
        component = set()
        while stack:
            edge = stack.pop()
            if edge not in edge_set:
                continue
            edge_set.remove(edge)
            component.add(edge)
            for v in EDGE_VERTICES[edge]:
                stack.extend(by_vertex[v] & edge_set)
        out.append(frozenset(component))
    return out


def is_internal_cycle(edge_set):
    if not edge_set or any(e.startswith("s") for e in edge_set):
        return False
    degree = defaultdict(int)
    for edge in edge_set:
        for v in EDGE_VERTICES[edge]:
            degree[v] += 1
    return all(d == 2 for d in degree.values()) and len(components(edge_set)) == 1


def cycle_components(edge_set):
    result = []
    for component in components(edge_set):
        degree = defaultdict(int)
        for edge in component:
            for v in EDGE_VERTICES[edge]:
                degree[v] += 1
        if all(d == 2 for d in degree.values()):
            result.append(component)
    return result


def main():
    matchings = enumerate_matchings()
    triples = defaultdict(list)
    for p in matchings:
        bp = boundary(p)
        if len(bp) != 1:
            continue
        for r in matchings:
            br = boundary(r)
            if len(br) != 1 or bp == br or not p.isdisjoint(r):
                continue
            q = EDGES - p - r
            # A partition into three local perfect matchings is automatic at
            # every cubic internal vertex; still check it literally.
            if q not in matchings or len(boundary(q)) != 3:
                raise AssertionError("invalid complement matching")
            triples[(next(iter(bp)), next(iter(br)))].append((p, r, q))

    grouped = defaultdict(list)
    grouped_without_q = defaultdict(list)
    transitions = 0
    for roles, family in triples.items():
        for p, r, q in family:
            for pp, rr, qq in family:
                c = q ^ qq
                if not is_internal_cycle(c):
                    continue
                dp = p ^ pp
                dr = r ^ rr
                if dp ^ dr != c:
                    raise AssertionError("companion identity failed")
                z = dp - c
                if z != dr - c:
                    raise AssertionError("external parts differ")

                # Normalize by flipping every cycle component of Z in the
                # new P',R' pair.  Algebraically this deletes those components
                # from both symmetric differences.
                w = frozenset().union(*cycle_components(z)) if z else frozenset()
                ndp = dp ^ w
                ndr = dr ^ w
                nz = ndp - c
                phase = frozenset(ndp & c)
                complement = frozenset(c - phase)
                canonical = min((phase, complement), key=lambda x: tuple(sorted(x)))
                bit = 0 if phase == canonical else 1
                key = (roles, q, qq, frozenset(c), frozenset(nz))
                grouped[key].append((bit, p, r, pp ^ w, rr ^ w, phase))
                key_without_q = (roles, frozenset(c), frozenset(nz))
                grouped_without_q[key_without_q].append(
                    (bit, q, qq, p, r, pp ^ w, rr ^ w, phase)
                )
                transitions += 1

    ambiguous = []
    for key, records in grouped.items():
        if {record[0] for record in records} == {0, 1}:
            ambiguous.append((key, records))
    boundary_ambiguous = []
    for key, records in grouped_without_q.items():
        if {record[0] for record in records} == {0, 1}:
            boundary_ambiguous.append((key, records))

    print(f"perfect_matchings={len(matchings)}")
    print(f"ordered_boundary_role_classes={len(triples)}")
    print(f"single_cycle_transitions={transitions}")
    print(f"fixed_Q_Qprime_Z_groups={len(grouped)}")
    print(f"opposite_phase_groups={len(ambiguous)}")
    print(f"opposite_phase_groups_without_fixed_Q_Qprime={len(boundary_ambiguous)}")
    if ambiguous:
        key, records = ambiguous[0]
        roles, q, qq, c, z = key
        print(f"roles={roles}")
        print("Q=" + " ".join(sorted(q)))
        print("Qprime=" + " ".join(sorted(qq)))
        print("C=" + " ".join(sorted(c)))
        print("Z=" + " ".join(sorted(z)))
        for bit in (0, 1):
            record = next(r for r in records if r[0] == bit)
            _, p, r, pp, rr, phase = record
            print(f"phase_bit={bit}")
            print("P=" + " ".join(sorted(p)))
            print("R=" + " ".join(sorted(r)))
            print("Pprime=" + " ".join(sorted(pp)))
            print("Rprime=" + " ".join(sorted(rr)))
            print("DP_cap_C=" + " ".join(sorted(phase)))
    if boundary_ambiguous:
        key, records = boundary_ambiguous[0]
        roles, c, z = key
        print("BOUNDARY_LABELS_DO_NOT_DETERMINE_PHASE")
        print(f"roles={roles}")
        print("C=" + " ".join(sorted(c)))
        print("Z=" + " ".join(sorted(z)))
        for bit in (0, 1):
            record = next(r for r in records if r[0] == bit)
            _, q, qq, p, r, pp, rr, phase = record
            print(f"phase_bit={bit}")
            print("Q=" + " ".join(sorted(q)))
            print("Qprime=" + " ".join(sorted(qq)))
            print("P=" + " ".join(sorted(p)))
            print("R=" + " ".join(sorted(r)))
            print("Pprime=" + " ".join(sorted(pp)))
            print("Rprime=" + " ".join(sorted(rr)))
            print("DP_cap_C=" + " ".join(sorted(phase)))


if __name__ == "__main__":
    main()
