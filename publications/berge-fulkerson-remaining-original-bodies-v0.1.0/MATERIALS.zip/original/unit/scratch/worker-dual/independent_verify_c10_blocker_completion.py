#!/usr/bin/env python3
"""Self-contained verification of the 13-vertex C10 blocker completion.

Only the Python standard library is used.  Perfect matchings are recursively
enumerated from the explicit edge table; no project enumerator is imported.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, product
import json


N = 13
PENTAGON_ORDER = (1, 4, 2, 5, 3)
TARGET_STATES = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
PROPER_EDGES = (
    (0, 2),
    (0, 3),
    (1, 3),
    (1, 4),
    (2, 12),
    (4, 8),
    (5, 6),
    (5, 9),
    (5, 10),
    (6, 7),
    (6, 9),
    (7, 8),
    (7, 11),
    (8, 12),
    (9, 10),
    (10, 11),
    (11, 12),
)

# Supports among designated states 0,...,9, keyed by the relabelled proper
# edges above.  State k lies in Case-XII boundary class PENTAGON_ORDER[k mod 5].
SUPPORTS = {
    (0, 2): (1, 3, 6, 8),
    (0, 3): (2, 4, 7, 9),
    (1, 3): (0, 3, 5, 8),
    (1, 4): (1, 4, 6, 9),
    (2, 12): (0, 2, 5, 7),
    (4, 8): (0, 2, 5, 7),
    (5, 6): (1, 3, 5, 7, 9),
    (5, 9): (0, 2, 4, 6, 8),
    (5, 10): (),
    (6, 7): (0, 2, 4, 6, 8),
    (6, 9): (),
    (7, 8): (3, 9),
    (7, 11): (1, 5, 7),
    (8, 12): (1, 4, 6, 8),
    (9, 10): (1, 3, 5, 7, 9),
    (10, 11): (0, 2, 4, 6, 8),
    (11, 12): (3, 9),
}


def edge_table():
    table = [(f"e{i}", edge, None) for i, edge in enumerate(PROPER_EDGES)]
    table.extend((f"s{i}", (i - 1,), i) for i in range(1, 6))
    return tuple(table)


EDGES = edge_table()
ENDPOINTS = {edge_id: frozenset(vertices) for edge_id, vertices, _ in EDGES}
BOUNDARY_POSITION = {edge_id: position for edge_id, _, position in EDGES}
INCIDENT = defaultdict(list)
for edge_id, vertices, _ in EDGES:
    for vertex in vertices:
        INCIDENT[vertex].append(edge_id)
for vertex in INCIDENT:
    INCIDENT[vertex].sort()


def verify_pole():
    assert len(PROPER_EDGES) == len(set(PROPER_EDGES)) == 17
    assert all(u < v for u, v in PROPER_EDGES)
    assert all(len(INCIDENT[v]) == 3 for v in range(N))
    adjacency = {v: set() for v in range(N)}
    for u, v in PROPER_EDGES:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in adjacency[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    assert len(seen) == N


def enumerate_perfect_matchings():
    matchings = set()

    def search(uncovered, chosen):
        if not uncovered:
            matchings.add(frozenset(chosen))
            return
        vertex = min(uncovered)
        for edge_id in INCIDENT[vertex]:
            endpoints = ENDPOINTS[edge_id]
            if endpoints <= uncovered:
                search(uncovered - endpoints, chosen + (edge_id,))

    search(frozenset(range(N)), tuple())
    return tuple(sorted(matchings, key=lambda matching: tuple(sorted(matching))))


def boundary_set(matching):
    return frozenset(
        BOUNDARY_POSITION[edge]
        for edge in matching
        if BOUNDARY_POSITION[edge] is not None
    )


def singleton_classes(matchings):
    singleton = {i: [] for i in range(1, 6)}
    for matching in matchings:
        boundary = boundary_set(matching)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    return singleton


def relation(singleton, left, right):
    return tuple(
        (first, second)
        for first in singleton[left]
        for second in singleton[right]
        if first.isdisjoint(second)
    )


def compatible_pentagons(relations):
    adjacency = []
    for current in relations:
        following = defaultdict(list)
        for left, right in current:
            following[left].append(right)
        adjacency.append(following)
    count = 0
    for first_left, first_right in relations[0]:
        def extend(layer, current):
            nonlocal count
            if layer == 4:
                count += sum(candidate == first_left for candidate in adjacency[layer][current])
                return
            for candidate in adjacency[layer][current]:
                extend(layer + 1, candidate)

        extend(1, first_right)
    return count


def capacity_witness(singleton):
    positions = sorted(singleton, key=lambda position: len(singleton[position]))
    selected = []
    multiplicity = Counter()

    def search(index):
        if index == len(positions):
            return tuple(selected)
        position = positions[index]
        for matching in singleton[position]:
            if any(multiplicity[edge] >= 2 for edge in matching):
                continue
            selected.append((position, matching))
            multiplicity.update(matching)
            witness = search(index + 1)
            if witness is not None:
                return witness
            multiplicity.subtract(matching)
            selected.pop()
        return None

    return search(0)


def designated_matchings():
    edge_id = {edge: f"e{i}" for i, edge in enumerate(PROPER_EDGES)}
    states = []
    for k in range(10):
        layer = k % 5
        states.append(
            frozenset(
                [edge_id[edge] for edge, support in SUPPORTS.items() if k in support]
                + [f"s{PENTAGON_ORDER[layer]}"]
            )
        )
    return tuple(states)


def verify_odd_cuts(designated):
    apex = N
    minimum = 100
    for matching in designated:
        chosen_edges = []
        for edge_id in matching:
            if edge_id.startswith("e"):
                chosen_edges.append(PROPER_EDGES[int(edge_id[1:])])
            else:
                chosen_edges.append((int(edge_id[1:]) - 1, apex))
        for mask in range(1, 1 << (N + 1)):
            if mask.bit_count() % 2 == 0:
                continue
            crossing = sum(
                ((mask >> u) & 1) != ((mask >> v) & 1)
                for u, v in chosen_edges
            )
            assert crossing >= 1
            minimum = min(minimum, crossing)
    return minimum


def main():
    verify_pole()
    matchings = enumerate_perfect_matchings()
    singleton = singleton_classes(matchings)

    states = set()
    for left, right in combinations(range(1, 6), 2):
        if relation(singleton, left, right):
            states.add((left, right))
    assert states == TARGET_STATES

    relations = tuple(
        relation(singleton, left, right)
        for left, right in zip(PENTAGON_ORDER, PENTAGON_ORDER[1:] + PENTAGON_ORDER[:1])
    )

    designated = designated_matchings()
    assert all(matching in matchings for matching in designated)
    disjoint_pairs = {
        frozenset((i, j))
        for i, j in combinations(range(10), 2)
        if designated[i].isdisjoint(designated[j])
    }
    assert disjoint_pairs == {
        frozenset((k, (k + 1) % 10)) for k in range(10)
    }

    designated_good = []
    for bits in product((0, 1), repeat=5):
        selected = [designated[i + 5 * bits[i]] for i in range(5)]
        maximum = max(Counter(edge for matching in selected for edge in matching).values())
        if maximum <= 2:
            designated_good.append(bits)
    assert not designated_good

    witness = capacity_witness(singleton)
    assert witness is not None
    assert any(matching not in set(designated) for _, matching in witness)

    result = {
        "proper_edges": PROPER_EDGES,
        "simple_connected_cubic_5_pole": True,
        "perfect_matchings": len(matchings),
        "singleton_counts": [len(singleton[i]) for i in range(1, 6)],
        "tait_states": sorted(states),
        "relation_sizes": [len(current) for current in relations],
        "compatible_pentagons": compatible_pentagons(relations),
        "designated_states": 10,
        "designated_disjointness": "C10",
        "designated_transversals_checked": 32,
        "designated_capacity_two": 0,
        "minimum_designated_odd_cut": verify_odd_cuts(designated),
        "full_capacity_two_witness": [
            [position, sorted(matching)] for position, matching in witness
        ],
        "witness_uses_matching_closure_outside_designated_states": True,
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    print("INDEPENDENT_C10_BLOCKER_COMPLETION_VERIFIED")


if __name__ == "__main__":
    main()
