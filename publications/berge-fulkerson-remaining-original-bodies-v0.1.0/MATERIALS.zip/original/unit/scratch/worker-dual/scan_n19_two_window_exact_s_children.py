#!/usr/bin/env python3
"""Scan the complete +2 neighbourhood of the frozen n=17 two-window pole.

For each of the C(28, 2)=378 labelled two-edge insertions, this script
enumerates the child's complete perfect-matching family.  It also derives
the same child Tait states from parent Kempe-component switches.  It then
separates three logically different conditions:

1. the move is a triangle expansion, so all ten parent matchings have the
   project's unique standard lift;
2. those ten lifts still induce the designated C10;
3. the complete singleton-matching closure has exactly the target Tait C5.

For clarity, the program separately reports the one disjoint move for which
all ten matchings merely have a boundary-preserving local extension.  That
extension is not a standard triangle lift and all ten extensions share the
new bridge, so it destroys C10.

Only a child satisfying all three conditions can inherit the forced-path hypothesis.
For such a child we test whether one actual descendant of a=(5,6) lies on
both Y_0 and Y_2.  Perfect matchings are discarded after each child.

Only Python's standard library is used.
"""

from __future__ import annotations

from collections import Counter, deque
from itertools import combinations
import json


BASE_N = 17
BASE_PROPER = (
    (0, 4),
    (0, 12),
    (1, 2),
    (1, 15),
    (2, 9),
    (3, 13),
    (3, 16),
    (4, 9),
    (5, 6),
    (5, 7),
    (5, 14),
    (6, 7),
    (6, 14),
    (7, 8),
    (8, 12),
    (8, 16),
    (9, 13),
    (10, 11),
    (10, 13),
    (10, 16),
    (11, 14),
    (11, 15),
    (12, 15),
)
BASE_SEMI_ENDPOINTS = (0, 1, 2, 3, 4)

# A proper-edge support is the set of designated states N_k using it.
BASE_SUPPORTS = (
    (1, 3, 6, 8),
    (2, 4, 7, 9),
    (0, 3, 5, 8),
    (2, 4, 7, 9),
    (1, 4, 6, 9),
    (1, 5, 7, 9),
    (0, 2, 4, 6),
    (0, 2, 5, 7),
    (0, 2, 4, 6, 8),
    (1, 3, 5, 7, 9),
    (),
    (),
    (1, 3, 5, 7, 9),
    (0, 2, 4, 6, 8),
    (1, 5),
    (3, 7, 9),
    (3, 8),
    (3, 7, 9),
    (0, 2, 4, 6),
    (1, 5, 8),
    (0, 2, 4, 6, 8),
    (1, 5),
    (0, 3, 6, 8),
)

TARGET_STATES = frozenset({(0, 1), (1, 2), (2, 3), (3, 4), (0, 4)})
BASE_STATES = TARGET_STATES | {(0, 2), (1, 3)}
A_BASE_INDEX = BASE_PROPER.index((5, 6))


def object_name(index: int) -> str:
    if index < len(BASE_PROPER):
        u, v = BASE_PROPER[index]
        return f"e{index:02d}:{u}-{v}"
    position = index - len(BASE_PROPER)
    return f"s{position}@{BASE_SEMI_ENDPOINTS[position]}"


def object_endpoints(index: int) -> frozenset[int]:
    if index < len(BASE_PROPER):
        return frozenset(BASE_PROPER[index])
    return frozenset((BASE_SEMI_ENDPOINTS[index - len(BASE_PROPER)],))


def base_designated_masks() -> tuple[int, ...]:
    proper_count = len(BASE_PROPER)
    masks = []
    for state in range(10):
        mask = 0
        for edge_index, support in enumerate(BASE_SUPPORTS):
            if state in support:
                mask |= 1 << edge_index
        mask |= 1 << (proper_count + state % 5)
        masks.append(mask)
    return tuple(masks)


def check_matching(
    mask: int,
    n: int,
    proper: tuple[tuple[int, int], ...],
    semiedge_endpoints: tuple[int, ...],
) -> bool:
    incidence = [0] * n
    for edge_index, (u, v) in enumerate(proper):
        if (mask >> edge_index) & 1:
            incidence[u] += 1
            incidence[v] += 1
    offset = len(proper)
    for position, endpoint in enumerate(semiedge_endpoints):
        if (mask >> (offset + position)) & 1:
            incidence[endpoint] += 1
    return incidence == [1] * n


def check_pole(
    n: int,
    proper: tuple[tuple[int, int], ...],
    semiedge_endpoints: tuple[int, ...],
) -> None:
    assert len(proper) == len(set(tuple(sorted(edge)) for edge in proper))
    degrees = [0] * n
    adjacency = [[] for _ in range(n)]
    for u, v in proper:
        assert u != v
        degrees[u] += 1
        degrees[v] += 1
        adjacency[u].append(v)
        adjacency[v].append(u)
    for endpoint in semiedge_endpoints:
        degrees[endpoint] += 1
    assert degrees == [3] * n
    assert len(set(semiedge_endpoints)) == 5
    seen = {0}
    stack = [0]
    while stack:
        for neighbour in adjacency[stack.pop()]:
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    assert len(seen) == n


def enumerate_matchings(
    n: int,
    proper: tuple[tuple[int, int], ...],
    semiedge_endpoints: tuple[int, ...],
) -> tuple[int, ...]:
    endpoint_masks = [((1 << u) | (1 << v)) for u, v in proper]
    endpoint_masks.extend(1 << endpoint for endpoint in semiedge_endpoints)
    incidence: list[list[int]] = [[] for _ in range(n)]
    for edge_index, endpoints in enumerate(endpoint_masks):
        remaining = endpoints
        while remaining:
            low = remaining & -remaining
            incidence[low.bit_length() - 1].append(edge_index)
            remaining ^= low

    all_vertices = (1 << n) - 1
    output: list[int] = []

    def search(covered: int, selected: int) -> None:
        if covered == all_vertices:
            output.append(selected)
            return
        uncovered = all_vertices ^ covered
        vertex = min(
            (v for v in range(n) if (uncovered >> v) & 1),
            key=lambda v: sum(
                not (endpoint_masks[e] & covered) for e in incidence[v]
            ),
        )
        for edge_index in incidence[vertex]:
            endpoints = endpoint_masks[edge_index]
            if endpoints & covered:
                continue
            search(covered | endpoints, selected | (1 << edge_index))

    search(0, 0)
    assert len(output) == len(set(output))
    return tuple(sorted(output))


def singleton_classes(
    matchings: tuple[int, ...], proper_count: int
) -> tuple[tuple[int, ...], ...]:
    return tuple(
        tuple(
            matching
            for matching in matchings
            if ((matching >> proper_count) & 0b11111) == 1 << position
        )
        for position in range(5)
    )


def tait_states(classes: tuple[tuple[int, ...], ...]) -> frozenset[tuple[int, int]]:
    return frozenset(
        (left, right)
        for left in range(5)
        for right in range(left + 1, 5)
        if any(a & b == 0 for a in classes[left] for b in classes[right])
    )


def parent_tait_colourings(
    classes: tuple[tuple[int, ...], ...], edge_count: int
) -> tuple[tuple[int, ...], ...]:
    """Return colour-labelled parent Tait colourings from disjoint PM pairs."""
    all_edges = (1 << edge_count) - 1
    output = []
    for left in range(5):
        for right in range(left + 1, 5):
            for first in classes[left]:
                for second in classes[right]:
                    if first & second:
                        continue
                    third = all_edges ^ first ^ second
                    colouring = [2] * edge_count
                    remaining = first
                    while remaining:
                        low = remaining & -remaining
                        colouring[low.bit_length() - 1] = 0
                        remaining ^= low
                    remaining = second
                    while remaining:
                        low = remaining & -remaining
                        colouring[low.bit_length() - 1] = 1
                        remaining ^= low
                    assert sum(colour == 2 for colour in colouring) == third.bit_count()
                    assert check_matching(
                        third, BASE_N, BASE_PROPER, BASE_SEMI_ENDPOINTS
                    )
                    output.append(tuple(colouring))
    return tuple(output)


def full_base_endpoints(object_index: int) -> tuple[int, int]:
    if object_index < len(BASE_PROPER):
        return BASE_PROPER[object_index]
    position = object_index - len(BASE_PROPER)
    return (BASE_SEMI_ENDPOINTS[position], BASE_N + position)


def graph_components(adjacency: dict[int, set[int]]) -> tuple[frozenset[int], ...]:
    unseen = set(adjacency)
    output = []
    while unseen:
        start = min(unseen)
        component = {start}
        stack = [start]
        unseen.remove(start)
        while stack:
            vertex = stack.pop()
            for neighbour in adjacency[vertex]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    return tuple(output)


def toggle_colour(colour: int, pair: tuple[int, int]) -> int:
    if colour == pair[0]:
        return pair[1]
    if colour == pair[1]:
        return pair[0]
    return colour


def boundary_state(boundary_colours: tuple[int, ...]) -> tuple[int, int]:
    counts = Counter(boundary_colours)
    assert sorted(counts.values()) == [1, 1, 3]
    lonely = {colour for colour, count in counts.items() if count == 1}
    positions = tuple(
        position
        for position, colour in enumerate(boundary_colours)
        if colour in lonely
    )
    assert len(positions) == 2
    return positions


def kempe_lifted_states_for_colouring(
    colouring: tuple[int, ...], pair: tuple[int, int]
) -> frozenset[tuple[int, int]]:
    """Boundary states obtained from all valid two-colour component switches."""
    selected_colours = {colouring[index] for index in pair}
    if len(selected_colours) == 2:
        colour_pairs = (tuple(sorted(selected_colours)),)
    else:
        only = next(iter(selected_colours))
        colour_pairs = tuple(
            tuple(sorted((only, other))) for other in range(3) if other != only
        )

    output = set()
    for colour_pair in colour_pairs:
        adjacency: dict[int, set[int]] = {}
        selected_endpoints = {
            edge_index: full_base_endpoints(edge_index) for edge_index in pair
        }
        for endpoints in selected_endpoints.values():
            for vertex in endpoints:
                adjacency.setdefault(vertex, set())
        for edge_index, colour in enumerate(colouring):
            if edge_index in pair or colour not in colour_pair:
                continue
            u, v = full_base_endpoints(edge_index)
            adjacency.setdefault(u, set()).add(v)
            adjacency.setdefault(v, set()).add(u)

        components = graph_components(adjacency)
        component_of = {
            vertex: component_index
            for component_index, component in enumerate(components)
            for vertex in component
        }
        for switch_mask in range(1 << len(components)):
            def switched(vertex: int) -> bool:
                return bool(switch_mask & (1 << component_of[vertex]))

            if any(
                switched(endpoints[0]) == switched(endpoints[1])
                for endpoints in selected_endpoints.values()
            ):
                continue

            colours = []
            for position in range(5):
                edge_index = len(BASE_PROPER) + position
                colour = colouring[edge_index]
                terminal_dummy = BASE_N + position
                if edge_index in pair:
                    if switched(terminal_dummy):
                        colour = toggle_colour(colour, colour_pair)
                elif colour in colour_pair:
                    endpoint = BASE_SEMI_ENDPOINTS[position]
                    if switched(endpoint):
                        colour = toggle_colour(colour, colour_pair)
                colours.append(colour)
            output.add(boundary_state(tuple(colours)))
    return frozenset(output)


def kempe_predicted_states(
    colourings: tuple[tuple[int, ...], ...], pair: tuple[int, int]
) -> frozenset[tuple[int, int]]:
    output = set()
    for colouring in colourings:
        output.update(kempe_lifted_states_for_colouring(colouring, pair))
    return frozenset(output)


def expand(pair: tuple[int, int]):
    """Build a child and the local data needed for standard lifts."""
    selected = {pair[0]: BASE_N, pair[1]: BASE_N + 1}
    proper: list[tuple[int, int]] = []
    semiedge_endpoints = list(BASE_SEMI_ENDPOINTS)
    unchanged: dict[int, int] = {}
    inside: dict[int, dict[int, int]] = {}
    outside: dict[int, int] = {}

    for base_index, (u, v) in enumerate(BASE_PROPER):
        if base_index not in selected:
            unchanged[base_index] = len(proper)
            proper.append((u, v))
            continue
        new_vertex = selected[base_index]
        first = len(proper)
        proper.append((u, new_vertex))
        second = len(proper)
        proper.append((new_vertex, v))
        inside[base_index] = {u: first, v: second}

    offset = len(BASE_PROPER)
    selected_semis: dict[int, int] = {}
    for position, endpoint in enumerate(BASE_SEMI_ENDPOINTS):
        base_index = offset + position
        if base_index not in selected:
            continue
        new_vertex = selected[base_index]
        stub_index = len(proper)
        proper.append((endpoint, new_vertex))
        semiedge_endpoints[position] = new_vertex
        inside[base_index] = {endpoint: stub_index}
        selected_semis[base_index] = position

    bridge = len(proper)
    proper.append((BASE_N, BASE_N + 1))
    proper_count = len(proper)

    for base_index in range(offset, offset + 5):
        position = base_index - offset
        if base_index in selected_semis:
            outside[base_index] = proper_count + position
        else:
            unchanged[base_index] = proper_count + position

    for base_index in pair:
        if base_index >= offset:
            continue
        endpoints = BASE_PROPER[base_index]
        # The outside half is chosen later once a shared triangle vertex is
        # known.  Store both endpoint-indexed halves in ``inside``.
        assert set(inside[base_index]) == set(endpoints)

    return (
        tuple(proper),
        tuple(semiedge_endpoints),
        unchanged,
        inside,
        outside,
        bridge,
    )


def standard_lift(
    parent: int,
    pair: tuple[int, int],
    expansion,
) -> tuple[int | None, frozenset[int]]:
    """Return a boundary-preserving local extension and the lift-image of a.

    For disjoint selected objects the outside choices of the parent can be
    preserved only when it uses neither object, in which case the new bridge
    is forced.  If the objects share a vertex, they form a triangle and the
    usual unique project-standard triangle lift applies.  The disjoint case
    is retained only as a diagnostic and is not called a standard lift.
    """
    proper, semi, unchanged, inside, outside, bridge = expansion
    del semi
    selected_used = tuple(index for index in pair if (parent >> index) & 1)
    shared = object_endpoints(pair[0]) & object_endpoints(pair[1])
    lift_image_a: set[int] = set()

    if not shared:
        if selected_used:
            return None, frozenset()
        child = 1 << bridge
        for base_index, child_index in unchanged.items():
            if (parent >> base_index) & 1:
                child |= 1 << child_index
        if A_BASE_INDEX not in pair:
            lift_image_a.add(unchanged[A_BASE_INDEX])
        return child, frozenset(lift_image_a)

    assert len(shared) == 1
    shared_vertex = next(iter(shared))
    assert len(selected_used) <= 1
    child = 0
    for base_index, child_index in unchanged.items():
        if (parent >> base_index) & 1:
            child |= 1 << child_index

    if not selected_used:
        child |= 1 << bridge
    else:
        used = selected_used[0]
        other = pair[1] if used == pair[0] else pair[0]
        if used < len(BASE_PROPER):
            other_endpoint = next(
                endpoint
                for endpoint in BASE_PROPER[used]
                if endpoint != shared_vertex
            )
            used_outside = inside[used][other_endpoint]
        else:
            used_outside = outside[used]
        opposite_inside = inside[other][shared_vertex]
        child |= (1 << used_outside) | (1 << opposite_inside)

        if used == A_BASE_INDEX:
            # The blocker descendant is the exterior segment of the
            # subdivided a-edge.  The opposite inner triangle edge is also
            # used by this matching, but it does not contract to a.
            lift_image_a.add(used_outside)

    if A_BASE_INDEX not in pair:
        lift_image_a.add(unchanged[A_BASE_INDEX])
    return child, frozenset(lift_image_a)


def designated_disjoint_pairs(matchings: tuple[int, ...]) -> frozenset[tuple[int, int]]:
    return frozenset(
        (first, second)
        for first in range(10)
        for second in range(first + 1, 10)
        if matchings[first] & matchings[second] == 0
    )


EXPECTED_C10 = frozenset(
    tuple(sorted((state, (state + 1) % 10))) for state in range(10)
)


def boundary_path_edges(
    n: int,
    proper: tuple[tuple[int, int], ...],
    semiedge_endpoints: tuple[int, ...],
    matching: int,
    target_positions: frozenset[int],
) -> frozenset[int]:
    adjacency: list[list[tuple[int, int]]] = [[] for _ in range(n)]
    for edge_index, (u, v) in enumerate(proper):
        if (matching >> edge_index) & 1:
            continue
        adjacency[u].append((v, edge_index))
        adjacency[v].append((u, edge_index))
    source, target = (semiedge_endpoints[p] for p in sorted(target_positions))
    parent: dict[int, tuple[int, int] | None] = {source: None}
    queue = deque([source])
    while queue and target not in parent:
        vertex = queue.popleft()
        for neighbour, edge_index in adjacency[vertex]:
            if neighbour not in parent:
                parent[neighbour] = (vertex, edge_index)
                queue.append(neighbour)
    assert target in parent
    path_edges = set()
    current = target
    while parent[current] is not None:
        previous, edge_index = parent[current]
        path_edges.add(edge_index)
        current = previous
    return frozenset(path_edges)


def route_record(pair, expansion, lifts, a_images):
    proper, semi, *_ = expansion
    assert len(set(a_images)) == 1
    a_descendants = next(iter(set(a_images)))
    y0 = boundary_path_edges(
        BASE_N + 2, proper, semi, lifts[1], frozenset({3, 4})
    )
    y2 = boundary_path_edges(
        BASE_N + 2, proper, semi, lifts[3], frozenset({0, 1})
    )
    t0 = lifts[0] & lifts[2] & lifts[4] & ((1 << len(proper)) - 1)
    t2 = lifts[2] & lifts[4] & lifts[6] & ((1 << len(proper)) - 1)
    common_a_on_both = a_descendants & y0 & y2
    return {
        "move": [object_name(index) for index in pair],
        "a_descendant_child_edge_indices": sorted(a_descendants),
        "a_descendant_in_Y0": sorted(a_descendants & y0),
        "a_descendant_in_Y2": sorted(a_descendants & y2),
        "same_a_descendant_in_both": sorted(common_a_on_both),
        "T0_inter_Y0": sorted(
            edge for edge in y0 if (t0 >> edge) & 1
        ),
        "T2_inter_Y2": sorted(
            edge for edge in y2 if (t2 >> edge) & 1
        ),
        "double_Y": bool(common_a_on_both),
    }


def main() -> None:
    assert len(BASE_PROPER) == len(BASE_SUPPORTS) == 23
    check_pole(BASE_N, BASE_PROPER, BASE_SEMI_ENDPOINTS)
    designated = base_designated_masks()
    assert all(
        check_matching(mask, BASE_N, BASE_PROPER, BASE_SEMI_ENDPOINTS)
        for mask in designated
    )
    assert designated_disjoint_pairs(designated) == EXPECTED_C10

    base_matchings = enumerate_matchings(BASE_N, BASE_PROPER, BASE_SEMI_ENDPOINTS)
    base_classes = singleton_classes(base_matchings, len(BASE_PROPER))
    assert tuple(len(group) for group in base_classes) == (8, 8, 6, 7, 4)
    assert tait_states(base_classes) == BASE_STATES
    parent_colourings = parent_tait_colourings(
        base_classes, len(BASE_PROPER) + 5
    )
    del base_matchings, base_classes

    totals = Counter()
    first_failure = Counter()
    state_sizes = Counter()
    triangle_profiles = Counter()
    extended_nontriangle_records = []
    exact_records = []
    first_double_y = None
    kempe_subset_violations = []
    kempe_prediction_sizes = Counter()
    kempe_missing_state_counts = Counter()
    object_count = len(BASE_PROPER) + 5

    for pair in combinations(range(object_count), 2):
        totals["moves"] += 1
        expansion = expand(pair)
        proper, semi, *_ = expansion
        check_pole(BASE_N + 2, proper, semi)

        matchings = enumerate_matchings(BASE_N + 2, proper, semi)
        totals["children_fully_enumerated"] += 1
        classes = singleton_classes(matchings, len(proper))
        states = tait_states(classes)
        state_sizes[len(states)] += 1
        predicted = kempe_predicted_states(parent_colourings, pair)
        kempe_prediction_sizes[len(predicted)] += 1
        kempe_missing_state_counts[len(states - predicted)] += 1
        if not predicted <= states:
            kempe_subset_violations.append(
                {
                    "move": [object_name(index) for index in pair],
                    "predicted": sorted(map(list, predicted)),
                    "actual": sorted(map(list, states)),
                }
            )

        if states == TARGET_STATES:
            totals["all_children_full_exact_S"] += 1

        lifts = []
        a_images = []
        for parent in designated:
            lifted, a_image = standard_lift(parent, pair, expansion)
            if lifted is None:
                break
            assert check_matching(lifted, BASE_N + 2, proper, semi)
            assert lifted in matchings
            lifts.append(lifted)
            if a_image:
                a_images.append(a_image)
        shared_endpoint_triangle = bool(
            object_endpoints(pair[0]) & object_endpoints(pair[1])
        )
        if len(lifts) == 10:
            totals["all_ten_boundary_preserving_local_extensions"] += 1
        if not shared_endpoint_triangle:
            first_failure["not_project_standard_triangle_lift"] += 1
            if len(lifts) == 10:
                extended_nontriangle_records.append(
                    {
                        "move": [object_name(index) for index in pair],
                        "full_exact_S": states == TARGET_STATES,
                        "Tait_states": sorted(map(list, states)),
                        "lifted_designated_exact_C10": (
                            designated_disjoint_pairs(tuple(lifts)) == EXPECTED_C10
                        ),
                        "local_reason": (
                            "All ten extensions use the new bridge, so no two "
                            "of them are disjoint."
                        ),
                    }
                )
            del matchings, classes
            continue

        assert len(lifts) == 10
        totals["project_standard_triangle_lift_family"] += 1
        lifted_c10 = designated_disjoint_pairs(tuple(lifts)) == EXPECTED_C10
        assert lifted_c10
        totals["standard_lifts_still_exact_C10"] += 1

        exact_s = states == TARGET_STATES
        if exact_s:
            totals["project_standard_lift_and_full_exact_S"] += 1
        else:
            first_failure["project_standard_lift_but_not_full_exact_S"] += 1

        triangle_profiles[
            (
                len(matchings),
                tuple(len(group) for group in classes),
                tuple(sorted(states)),
            )
        ] += 1

        if exact_s and lifted_c10:
            totals["full_hypothesis_children"] += 1
            route = route_record(pair, expansion, tuple(lifts), tuple(a_images))
            record = {
                "move": [object_name(index) for index in pair],
                "perfect_matchings": len(matchings),
                "singleton_profile": [len(group) for group in classes],
                "Tait_states": sorted(map(list, states)),
                "route": route,
            }
            exact_records.append(record)
            if route["double_Y"]:
                totals["double_Y_children"] += 1
                first_double_y = record
                break

        del matchings, classes

    # A double-Y witness is a legitimate early stop.  Otherwise the scan is
    # required to cover the full labelled one-step neighbourhood.
    if first_double_y is None:
        assert totals["moves"] == 378
        assert totals["children_fully_enumerated"] == 378

    assert not kempe_subset_violations, kempe_subset_violations[:3]
    assert min(kempe_prediction_sizes) >= 6
    assert min(state_sizes) == 6
    assert totals["all_children_full_exact_S"] == 0
    assert totals["project_standard_triangle_lift_family"] == 51
    assert totals["all_ten_boundary_preserving_local_extensions"] == 52
    assert len(extended_nontriangle_records) == 1
    for key in (
        "all_children_full_exact_S",
        "project_standard_lift_and_full_exact_S",
        "full_hypothesis_children",
        "double_Y_children",
    ):
        totals[key] += 0
    triangle_matching_counts = Counter()
    for key, count in triangle_profiles.items():
        triangle_matching_counts[key[0]] += count
    output = {
        "target_Tait_states_zero_based": sorted(map(list, TARGET_STATES)),
        "seed_Tait_states_zero_based": sorted(map(list, BASE_STATES)),
        "totals": dict(totals),
        "first_failure_distribution": dict(first_failure),
        "all_child_Tait_state_size_distribution": dict(sorted(state_sizes.items())),
        "parent_Tait_colourings_used_for_Kempe_prediction": len(parent_colourings),
        "Kempe_prediction_subset_violations": kempe_subset_violations,
        "Kempe_predicted_state_size_distribution": dict(
            sorted(kempe_prediction_sizes.items())
        ),
        "child_states_not_reached_by_parent_Kempe_lifts": dict(
            sorted(kempe_missing_state_counts.items())
        ),
        "extended_nontriangle_diagnostic": extended_nontriangle_records,
        "triangle_perfect_matching_count_distribution": dict(
            sorted(triangle_matching_counts.items())
        ),
        "triangle_distinct_matching_profiles": len(triangle_profiles),
        "full_hypothesis_records": exact_records,
        "first_double_Y": first_double_y,
        "uniform_Kempe_reason": {
            "scope": "all 378 labelled children of this frozen seed",
            "prediction_is_subset_of_complete_PM_enumeration_for_every_child": True,
            "minimum_Kempe_predicted_child_Tait_states": min(
                kempe_prediction_sizes
            ),
            "mechanism": (
                "For every parent Tait colouring and selected object pair, "
                "switch a union of two-colour components separating both "
                "selected endpoint pairs; the switched colouring extends "
                "over the inserted edge.  These explicit lifts alone give "
                "at least six child states for every move."
            ),
            "triangle_subfamily": (
                "For the 51 project-standard triangle lifts this reduces to "
                "the structural Tait-colouring bijection, so both seed extras "
                "(0,2) and (1,3) survive."
            ),
        },
    }
    print(json.dumps(output, ensure_ascii=False, indent=2, sort_keys=True))
    print("N19_TWO_WINDOW_EXACT_S_CHILD_SCAN_OK")


if __name__ == "__main__":
    main()
