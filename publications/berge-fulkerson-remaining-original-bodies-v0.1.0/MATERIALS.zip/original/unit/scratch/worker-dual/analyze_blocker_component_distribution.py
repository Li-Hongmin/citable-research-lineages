#!/usr/bin/env python3
"""Locate two-edge blockers in the components of H minus the next matching."""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
from pathlib import Path
import subprocess
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
AUDIT_PATH = HERE / "audit_bad_c10_single_cycle_repair.py"
SPEC = importlib.util.spec_from_file_location("cycle_repair_audit", AUDIT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {AUDIT_PATH}")
audit = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = audit
SPEC.loader.exec_module(audit)
base = audit.base


def complement_components(matching, edge_vertices, edge_position):
    graph = nx.Graph()
    edge_by_nodes = {}
    for edge, endpoints in edge_vertices.items():
        if edge in matching:
            continue
        if len(endpoints) == 2:
            u, v = endpoints
        else:
            u = endpoints[0]
            v = ("boundary", edge_position[edge])
        graph.add_edge(u, v)
        edge_by_nodes[frozenset((u, v))] = edge
    result = {}
    for nodes in nx.connected_components(graph):
        edges = frozenset(
            edge_by_nodes[frozenset((u, v))]
            for u, v in graph.subgraph(nodes).edges()
        )
        positions = tuple(sorted(edge_position[edge] for edge in edges if edge_position[edge] is not None))
        assert len(positions) in (0, 2)
        info = {"kind": "cycle" if not positions else "path", "positions": positions, "edges": edges}
        for edge in edges:
            result[edge] = info
    return result


def diagnose_subsystem(subsystem, singleton, edge_vertices, edge_position):
    cycle = audit.c10_cycle_order(subsystem)
    blockers = audit.two_edge_farkas_blockers(subsystem)
    blocker_results = []
    for blocker in blockers:
        entries = []
        for k, source in enumerate(cycle):
            following = cycle[(k + 1) % 10]
            contained = tuple(edge for edge in blocker if edge in source)
            assert len(contained) == 1
            blocker_edge = contained[0]
            info = complement_components(following, edge_vertices, edge_position)[blocker_edge]
            repair = False
            triple_before = sorted(source & cycle[(k + 2) % 10] & cycle[(k + 4) % 10])
            triple_after = None
            if info["kind"] == "cycle":
                replacement = source ^ info["edges"]
                position = next(edge_position[e] for e in source if edge_position[e] is not None)
                assert replacement in singleton[position]
                assert replacement.isdisjoint(following)
                triple_after = sorted(replacement & cycle[(k + 2) % 10] & cycle[(k + 4) % 10])
                repair = not triple_after
            entries.append(
                {
                    "k": k,
                    "blocker_edge": blocker_edge,
                    "kind": info["kind"],
                    "positions": info["positions"],
                    "component_length": len(info["edges"]),
                    "triple_before": triple_before,
                    "triple_after": triple_after,
                    "repair": repair,
                }
            )
        blocker_results.append(
            {
                "blocker": blocker,
                "cycle_occurrences": sum(entry["kind"] == "cycle" for entry in entries),
                "repairing_occurrences": sum(entry["repair"] for entry in entries),
                "entries": entries,
            }
        )
    return blocker_results


def run(n=13):
    command = ["geng", "-q", "-c", "-d3", "-D5", str(n + 1), str((3 * n + 5) // 2)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    assert process.stdout is not None
    aggregate = Counter()
    examples = []
    for line in process.stdout:
        graph = nx.from_graph6_bytes(line.strip().encode())
        if Counter(dict(graph.degree()).values()) != Counter({3: n, 5: 1}):
            continue
        apex = next(vertex for vertex, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        normalized = base.normalized_mapping(graph, apex, n)
        if normalized is None:
            continue
        _, pole = normalized
        matchings, edge_vertices, edge_position, _ = base.legacy.enumerate_perfect_matchings(pole)
        singleton = {position: [] for position in range(1, 6)}
        for matching in matchings:
            boundary = base.legacy.boundary_set(matching, edge_position)
            if len(boundary) == 1:
                singleton[next(iter(boundary))].append(matching)
        for position in singleton:
            singleton[position].sort(key=audit.matching_key)
        for subsystem in audit.c10_subsystems(singleton):
            if audit.designated_good(subsystem) is not None:
                continue
            aggregate["bad_subsystems"] += 1
            diagnosis = diagnose_subsystem(subsystem, singleton, edge_vertices, edge_position)
            aggregate["blocker_pairs"] += len(diagnosis)
            for current in diagnosis:
                aggregate[f"cycle_occurrences_{current['cycle_occurrences']}"] += 1
                aggregate[f"repairing_occurrences_{current['repairing_occurrences']}"] += 1
                if current["cycle_occurrences"] == 0:
                    aggregate["blocker_pairs_without_cycle"] += 1
                if current["repairing_occurrences"] == 0:
                    aggregate["blocker_pairs_without_repair"] += 1
            if len(examples) < 2:
                examples.append({"graph6": line.strip(), "diagnosis": diagnosis})
    assert process.wait() == 0
    print({"n": n, "aggregate": dict(aggregate), "examples": examples})


if __name__ == "__main__":
    run()
