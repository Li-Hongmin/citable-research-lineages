# Capacity-two feasibility: exact dual and the boundary of polyhedral separation

## Multiple-choice packing formulation

For each boundary class \(i\), let \(\mathcal P_i\) be its singleton-boundary
perfect matchings.  With a variable \(x_{iP}\) for \(P\in\mathcal P_i\), a
capacity-two transversal is exactly an integral solution of

\[
x_{iP}\in\{0,1\},\qquad
\sum_{P\in\mathcal P_i}x_{iP}=1,
\qquad
\sum_i\sum_{P\ni e}x_{iP}\leq 2\quad(e\in E(H)).
\tag{1}
\]

The LP relaxation of (1) has the following exact Farkas alternative.  It is
infeasible if and only if there are nonnegative edge weights \(y_e\) such that

\[
\sum_i\min_{P\in\mathcal P_i}\sum_{e\in P}y_e
>2\sum_e y_e.
\tag{2}
\]

Indeed, putting
\(\alpha_i=\min_{P\in\mathcal P_i}y(P)\), every feasible fractional selection
would give

\[
\sum_i\alpha_i
\leq\sum_i\sum_Px_{iP}y(P)
=\sum_e y_e\sum_{i,P\ni e}x_{iP}
\leq2\sum_e y_e.
\]

Conversely, (2) is the ordinary LP dual infeasibility certificate after the
five class equalities are assigned free multipliers.

## Minimal infeasible core of the abstract C10 blocker

In each of the five layers of the abstract blocker, one state contains the
common element \(a\) and the other contains the common element \(b\).  Write
\(p_i,q_i\) for selecting those two states.  The full infeasibility already
occurs in the seven constraints

\[
p_i+q_i=1\quad(i=1,\ldots,5),\qquad
\sum_i p_i\leq2,qquad \sum_iq_i\leq2.
\tag{3}
\]

Summing (3) gives \(5\leq4\).  This is an irreducible infeasible subsystem:
if either capacity constraint is removed, choose all five states of the other
type; if one class equality is removed, choose two \(a\)-states and two
\(b\)-states in the remaining four classes and choose nothing in the omitted
class.  Thus the blocker is not merely integrally infeasible; its LP
relaxation is infeasible.  In (2), the certificate is simply

\[
y_a=y_b=1,\qquad y_e=0\ (e\ne a,b),
\]

for which the two sides are \(5\) and \(4\).

## The raw set model fails vertex equations, but this does not exclude it

Represent an abstract edge by its support among the ten designated matching
states.  At a vertex of a cubic graph, the supports of the three incident
edges must be pairwise disjoint and partition all ten states.  For the raw
model with the two common elements, five semiedge elements, and fifteen
pair-specific blockers, the only such partition, even after allowing an edge
used by none of the ten states, is

\[
(\operatorname{supp}(a),\operatorname{supp}(b),\varnothing).
\]

In particular, none of the raw semiedge or pair-blocker columns can be incident
at a cubic vertex.  This only disproves that particular sparse presentation:
new edge columns can be added to the ten matchings without changing their C10
disjointness graph.

## A simple connected cubic completion at order thirteen

Such an extension exists.  After relabelling the five boundary positions to
the Case-XII order \(1,4,2,5,3\), take semiedge \(s_i\) at vertex \(i-1\) and
proper edges

\[
\begin{split}
&(0,2),(0,3),(1,3),(1,4),(2,12),(4,8),(5,6),(5,9),(5,10),\\
&(6,7),(6,9),(7,8),(7,11),(8,12),(9,10),(10,11),(11,12).
\end{split}
\tag{4}
\]

There are ten explicitly verified singleton-boundary perfect matchings in
this pole whose induced disjointness graph is exactly \(C_{10}\).  All five
even states share three proper edges and all five odd states share two proper
edges.  Consequently none of the \(2^5\) transversals restricted to these ten
states has capacity two.

Adjoining an apex to the five semiedges turns every one of the ten states into
an ordinary perfect matching of a 14-vertex graph.  Exhaustive evaluation of
all odd vertex sets gives minimum crossing value one for every state.  Hence
the ten-state blocker satisfies both the perfect-matching vertex equations and
all odd-cut inequalities.  No linear inequality valid for the ordinary
perfect-matching polytope can exclude these ten vectors.

The complete perfect-matching set of (4), however, is larger:

\[
|\mathcal M|=49,qquad
(|\mathcal P_1|,\ldots,|\mathcal P_5|)=(3,3,5,5,5).
\]

Its exact Tait lonely-pair state set is

\[
\{13,14,24,25,35\},
\]

the five consecutive relation sizes are all eight, and the full relations
contain 40 compatible pentagons.  A capacity-two transversal exists and uses
singleton matchings outside the designated ten-state subsystem.

## Consequence

The abstract \(a/b\) blocker has a minimal two-edge Farkas certificate, but it
cannot be ruled out by applying vertex equations or odd-cut inequalities to
the designated matching vectors.  Those constraints admit a simple connected
cubic realization with the exact Case-XII Tait-state skeleton.  What destroys
the blocker is closure of the *complete* perfect-matching family: the same
graph necessarily has additional singleton matchings that provide a good
transversal.

Therefore a proof of the capacity-two conjecture must constrain all perfect
matchings simultaneously, for example through alternating-cycle generation or
a closure/exchange statement.  Searching for a violated inequality of the
single-perfect-matching polytope is insufficient.

The disposable generators and exact verifier are
`c10_cubic_incidence_completion.py` and
`verify_c10_blocker_completion.py` in this directory.
