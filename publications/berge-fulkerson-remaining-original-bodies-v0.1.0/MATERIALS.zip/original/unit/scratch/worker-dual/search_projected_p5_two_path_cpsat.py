#!/usr/bin/env python3
"""Test the two-blocker/two-route lemma after projecting C10 to N0,...,N4."""

from __future__ import annotations

import argparse
from itertools import combinations

import networkx as nx
from ortools.sat.python import cp_model


STATES = range(5)
SUPPORTS = tuple(
    mask
    for mask in range(1 << 5)
    if all(not ((mask >> i) & 1 and (mask >> (i + 1)) & 1) for i in range(4))
)
EVEN = sum(1 << i for i in (0, 2, 4))
ODD = sum(1 << i for i in (1, 3))


def solve(n: int, geometry: str, time_limit: float) -> dict:
    pairs = tuple(combinations(range(n), 2))
    model = cp_model.CpModel()
    y = {
        (u, v, support_index): model.new_bool_var(f"y_{u}_{v}_{support_index}")
        for u, v in pairs
        for support_index in range(len(SUPPORTS))
    }
    for u, v in pairs:
        model.add_at_most_one(y[u, v, index] for index in range(len(SUPPORTS)))
    for vertex in range(n):
        model.add(
            sum(
                y[min(vertex, other), max(vertex, other), index]
                for other in range(n)
                if other != vertex
                for index in range(len(SUPPORTS))
            )
            == (2 if vertex < 5 else 3)
        )
        for state in STATES:
            model.add(
                sum(
                    y[min(vertex, other), max(vertex, other), index]
                    for other in range(n)
                    if other != vertex
                    for index, support in enumerate(SUPPORTS)
                    if (support >> state) & 1
                )
                == (0 if vertex == state else 1)
            )

    blocker_edges = {
        "even": (5, 6, EVEN),
        "odd": (5, 7, ODD) if geometry == "adjacent" else (7, 8, ODD),
    }
    support_index = {support: index for index, support in enumerate(SUPPORTS)}
    for u, v, support in blocker_edges.values():
        model.add(y[min(u, v), max(u, v), support_index[support]] == 1)

    for k in (0, 2):
        removed_state = k + 1
        y1, y2 = (k + 3) % 5, (k + 4) % 5
        blocker_u, blocker_v, _ = blocker_edges["even"]
        blocker_pair = frozenset((blocker_u, blocker_v))
        orientations = [model.new_bool_var(f"z_{k}_{orientation}") for orientation in range(2)]
        model.add_exactly_one(orientations)
        for orientation in range(2):
            endpoint_pairs = (
                ((y1, blocker_u), (y2, blocker_v))
                if orientation == 0
                else ((y1, blocker_v), (y2, blocker_u))
            )
            for connection, (source, sink) in enumerate(endpoint_pairs):
                arcs = {
                    (u, v): model.new_bool_var(f"f_{k}_{orientation}_{connection}_{u}_{v}")
                    for u in range(n)
                    for v in range(n)
                    if u != v and frozenset((u, v)) != blocker_pair
                }
                for vertex in range(n):
                    outgoing = [arc for (u, _), arc in arcs.items() if u == vertex]
                    incoming = [arc for (_, v), arc in arcs.items() if v == vertex]
                    balance = orientations[orientation] if vertex == source else -orientations[orientation] if vertex == sink else 0
                    model.add(sum(outgoing) - sum(incoming) == balance)
                for (u, v), arc in arcs.items():
                    model.add(arc <= orientations[orientation])
                    model.add(
                        arc
                        <= sum(
                            y[min(u, v), max(u, v), index]
                            for index, support in enumerate(SUPPORTS)
                            if not ((support >> removed_state) & 1)
                        )
                    )

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = 4
    status = solver.solve(model)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {
            "n": n,
            "geometry": geometry,
            "status": "infeasible" if status == cp_model.INFEASIBLE else "unknown_or_timeout",
            "wall_time": solver.wall_time,
            "branches": solver.num_branches,
        }
    selected = [
        (u, v, SUPPORTS[index])
        for u, v in pairs
        for index in range(len(SUPPORTS))
        if solver.value(y[u, v, index])
    ]
    graph = nx.Graph()
    graph.add_nodes_from(range(n))
    graph.add_edges_from((u, v) for u, v, _ in selected)
    return {
        "n": n,
        "geometry": geometry,
        "status": "realized_disconnected" if not nx.is_connected(graph) else "realized",
        "components": nx.number_connected_components(graph),
        "proper_edges_with_supports": [
            {"edge": [u, v], "support": [state for state in STATES if (mask >> state) & 1]}
            for u, v, mask in selected
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--geometry", choices=("adjacent", "disjoint", "both"), default="both")
    parser.add_argument("--time-limit", type=float, default=120.0)
    args = parser.parse_args()
    geometries = ("adjacent", "disjoint") if args.geometry == "both" else (args.geometry,)
    for geometry in geometries:
        print(solve(args.n, geometry, args.time_limit))


if __name__ == "__main__":
    main()
