# Forced-path leaf: the two-window route is false before full closure

## Remaining target

For an induced matching cycle (N_0,ldots,N_9), put

\[
T_k=N_k\cap N_{k+2}\cap N_{k+4}.
\]

The component reduction remains valid: after simultaneously flipping every
cycle component of (H-N_{k+1}) that meets (T_k), the residual triple
intersection is exactly (T_k\cap Y_k).  Hence one window with
(T_k\cap Y_k=\varnothing) gives a capacity-two transversal.

The universal forced-path claim

\[
\exists k\quad T_k\cap Y_k=\varnothing
\]

is still unresolved for poles whose **complete** singleton matching family
has exact Tait state set (S).

## A tempting two-window lemma is false

It is false that a common even blocker edge can lie on at most one even
forced path under cubic incidence, common even/odd blocker edges, and exact
disjointness (C_{10}) of the ten designated matchings.

There is a simple connected cubic 5-pole on 17 internal vertices with

\[
a=(5,6)\in\bigcap_{k\ {m even}}N_k,
\qquad
b=(5,7)\in\bigcap_{k\ {m odd}}N_k,
\]

whose ten designated singleton matchings have disjointness graph exactly
(C_{10}), but

\[
a\in Y_0(H-N_1)\cap Y_2(H-N_3).
\]

The two paths are

\[
Y_0=3-16-8-7-6-5-14-11-10-13-9-4,
\]

\[
Y_2=0-12-8-7-6-5-14-11-15-1.
\]

Consequently both (T_0\cap Y_0) and (T_2\cap Y_2) are nonempty.  The
standard-library certificate is
`agent-proof/verify_two_window_counterexample.py`.

This example is not a counterexample under the full exact-(S) premise.  Its
complete singleton class sizes are

\[
(8,8,6,7,4),
\]

and its complete disjoint boundary-pair set is

\[
\{01,02,04,12,13,23,34\},
\]

which strictly exceeds (S).  An independent second 17-vertex construction
in `agent-counterexample/analyze_n17_two_window_pole.py` has 86 perfect
matchings, eight Tait states, and a capacity-two witness supplied by matchings
outside the designated ten.

Therefore any true forced-path theorem must use complete matching closure or
a consequence of full exact (S).  It cannot follow from the ten selected
matching vectors, their exact designated (C_{10}), cubic vertex incidence,
or a rule forbidding two same-parity path obstructions.

## Finite and abstract boundaries

- Local disjointness, endpoint pairing, and mod-two endpoint parity admit an
  abstract system with all ten (T_k\cap Y_k\ne\varnothing).
- At orders 13 and 15, the incidence model rules out two prescribed
  same-parity windows for both adjacent and disjoint blocker geometries.
  The 17-vertex construction shows that this is only a small-order boundary.
- Projecting to the five matchings (N_0,\ldots,N_4) admits connected
  13-vertex realizations with both blockers and two forced paths.  Thus even
  the small-order obstruction uses the second traversal of the boundary
  classes, not merely the local five-matching chain.
- A 17-vertex adjacent-blocker CP-SAT model imposing all ten forced paths and
  exact designated (C_{10}) reached its 300-second limit after 5,778,670
  branches.  Its status is **unknown**, not infeasible.

The reusable exploratory drivers are
`search_forced_path_incidence_cpsat.py` and
`search_projected_p5_two_path_cpsat.py`.  The all-ten problem should not be
advanced by another ordinary order grid; the next discriminating premise is
full exact-(S) matching closure.
