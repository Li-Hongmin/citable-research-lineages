# Cycle closure reduces the obstruction to one forced boundary path

## Component notation

Let singleton-boundary perfect matchings

\[
N_0,N_1,\ldots,N_9
\]

induce the disjointness cycle \(C_{10}\), with indices read modulo ten and
boundary layers modulo five.  Fix \(k\), and write

\[
A=N_k,\qquad B=N_{k+1},\qquad D=N_{k+2},\qquad E=N_{k+4}.
\]

Both \(A\) and \(D\) are disjoint from \(B\).  Under the exact-\(S\)
hypothesis, \(H-B\) is the disjoint union of:

- a boundary path \(X_k\) whose endpoints are the boundary positions of
  \(A,D\);
- the other boundary path \(Y_k\);
- zero or more even cycle components.

On \(X_k\), the matchings \(A,D\) choose opposite alternating halves because
they use opposite endpoint semiedges.  On \(Y_k\), they choose the same forced
half because neither uses either endpoint semiedge.  On each cycle, they may
choose the same or opposite alternating halves independently.

It follows that

\[
A\cap D\subseteq Y_k\cup\bigcup
\{Z:Z\text{ is a cycle on which }A,D\text{ choose the same half}\}.
\tag{1}
\]

## Exact multi-cycle flip identity

Put

\[
T_k=A\cap D\cap E.
\]

Let \(\mathcal Z_k\) be all cycle components of \(H-B\) meeting \(T_k\), and
flip \(A\) on all of them:

\[
Q_k=A\mathbin\triangle\bigtriangleup_{Z\in\mathcal Z_k}E(Z).
\]

Every flipped component meets \(A\cap D\), so \(A,D\) use the same half on
that component.  After the flip, \(Q_k,D\) use opposite halves there.  The
flip does not change \(X_k,Y_k\), and a cycle not meeting \(T_k\) contributes
nothing to the original triple intersection.  Therefore

\[
\boxed{
Q_k\cap N_{k+2}\cap N_{k+4}=T_k\cap Y_k.
}
\tag{2}
\]

The matching \(Q_k\) remains in the same singleton boundary class as \(N_k\)
and remains disjoint from \(N_{k+1}\).

Consequently, if

\[
T_k\cap Y_k=\varnothing
\tag{3}
\]

for some \(k\), then

\[
Q_k,N_{k+1},N_{k+2},N_{k+3},N_{k+4}
\]

is a capacity-two transversal.  Four consecutive pairs are disjoint.  An
edge occurring in three of these five matchings would have to occupy the
unique three-vertex independent set \(\{0,2,4\}\) of the five-position path,
but (2)--(3) exclude precisely that triple.

Thus distribution over several alternating cycles is not an obstruction:
all relevant cycles can be flipped simultaneously.  The only part of the
triple intersection that Boolean cycle closure cannot remove is its part on
the forced path \(Y_k\).

## Interaction with a two-edge blocker

Suppose proper edges \(a,b\) meet every one of the ten states.  Consecutive
states are disjoint, so no state can contain both \(a,b\): otherwise its
neighbour would contain neither.  Hence the ten states contain exactly one of
\(a,b\), alternating around \(C_{10}\).  Every same-parity triple \(T_k\)
contains the corresponding blocker edge.

For the relation edge \((N_k,N_{k+1})\), the blocker edge in \(N_k\) cannot lie
on \(X_k\).  The matchings \(N_k,N_{k+2}\) contain that same blocker edge, but
they choose opposite halves of \(X_k\).  It therefore lies either on \(Y_k\)
or on a cycle where the two matchings use the same half.

The two-edge-blocker closure problem is consequently reduced to the precise
path statement

\[
\boxed{
\text{for some }k,\quad
N_k\cap N_{k+2}\cap N_{k+4}\cap Y_k=\varnothing.
}
\tag{4}
\]

Equation (4) is sufficient for a capacity-two transversal by (2).  A proof of
(4) from connected cubic realizability and exact \(S\) is not yet known.  A
counterexample must put at least one same-parity triple-common edge on the
non-switchable path \(Y_k\) for every \(k\); merely splitting common edges over
several cycle components is insufficient.

## Finite observations

For all 52 two-edge blocker pairs occurring in the ten bad thirteen-vertex
C10 subsystems, the relevant blocker edge is on a cycle in either nine or all
ten directed windows.  Every blocker pair has at least seven windows in which
a single cycle already removes the complete triple intersection.

The complete \(+2\) two-edge-insertion neighbourhood of the Note-009 pole was
also tested.  Of 231 labelled moves, 141 retain exact \(S\).  They contain

\[
1472\text{ induced C10 subsystems}
=896\text{ internally good}+576\text{ internally bad}.
\]

All 576 bad subsystems have a two-edge blocker and all 576 admit a
path-preserving single-cycle repair.  This is a local order-fifteen test, not
an exhaustive classification of all order-fifteen poles.

The component diagnostic is `analyze_blocker_component_distribution.py`; the
local expansion scan is `scan_n15_blocker_completion_expansions.py`.
