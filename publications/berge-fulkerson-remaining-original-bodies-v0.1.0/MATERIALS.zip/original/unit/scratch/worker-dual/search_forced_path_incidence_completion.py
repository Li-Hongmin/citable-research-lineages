#!/usr/bin/env python3
"""Search cubic incidence completions realizing all ten forced-path routes.

This strengthens the abstract path-system check but remains weaker than full
perfect-matching closure: only ten designated matching vectors are imposed.
Connectivity of the proper graph and of every required complement path is
enforced by iterative valid cuts.
"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "c10_cubic_incidence_completion.py"
SPEC = importlib.util.spec_from_file_location("incidence_completion_base", BASE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {BASE_PATH}")
base = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = base
SPEC.loader.exec_module(base)


def canonical_side(side, n):
    complement = frozenset(range(n)) - side
    return min(side, complement, key=lambda current: tuple(sorted(current)))


def augment_lp(path, n, fixed_edges, route_cuts):
    lines = path.read_text(encoding="utf-8").splitlines()
    binary_index = lines.index("Binary")
    extra = []
    support_index = {mask: i for i, mask in enumerate(base.SUPPORTS)}
    for label, u, v, mask in fixed_edges:
        extra.append(f" fix_{label}: {base.variable(u, v, support_index[mask])} = 1")
    for cut_index, (state, side) in enumerate(route_cuts):
        names = [
            base.variable(min(u, v), max(u, v), si)
            for u in side
            for v in range(n)
            if v not in side
            for si, support in enumerate(base.SUPPORTS)
            if not ((support >> state) & 1)
        ]
        extra.append(f" route_{cut_index}: {base.linear_sum(names)} >= 1")
    lines[binary_index:binary_index] = extra
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def solve(n, blocker_geometry, max_rounds, required_windows=tuple(range(10))):
    if n < 9:
        raise ValueError("need four nonterminal vertices to fix two blocker edges")
    blocker_edges = {
        "even": (5, 6, base.EVEN),
        "odd": (5, 7, base.ODD) if blocker_geometry == "adjacent" else (7, 8, base.ODD),
    }
    fixed = [(label, *data) for label, data in blocker_edges.items()]
    connectivity_cuts = []
    route_cuts = []
    known_connectivity = set()
    known_routes = set()
    with tempfile.TemporaryDirectory(prefix="forced-path-incidence-") as temporary:
        temporary = Path(temporary)
        lp = temporary / "problem.lp"
        solution = temporary / "solution.txt"
        for round_index in range(max_rounds):
            base.write_lp(n, connectivity_cuts, lp)
            augment_lp(lp, n, fixed, route_cuts)
            completed = subprocess.run(
                ["glpsol", "--lp", str(lp), "-o", str(solution)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            if "INTEGER OPTIMAL SOLUTION FOUND" not in completed.stdout:
                return {
                    "n": n,
                    "geometry": blocker_geometry,
                    "status": "infeasible",
                    "rounds": round_index + 1,
                    "connectivity_cuts": len(connectivity_cuts),
                    "route_cuts": len(route_cuts),
                    "solver_tail": completed.stdout.splitlines()[-12:],
                }
            selected = base.read_selected(solution)
            graph = nx.Graph()
            graph.add_nodes_from(range(n))
            graph.add_edges_from((u, v) for u, v, _ in selected)
            components = [frozenset(component) for component in nx.connected_components(graph)]
            added = False
            if len(components) > 1:
                for component in components:
                    side = canonical_side(component, n)
                    if side and side not in known_connectivity:
                        known_connectivity.add(side)
                        connectivity_cuts.append(side)
                        added = True
                if added:
                    continue

            failures = []
            for k in required_windows:
                removed_state = (k + 1) % 10
                complement = nx.Graph()
                complement.add_nodes_from(range(n))
                complement.add_edges_from(
                    (u, v)
                    for u, v, si in selected
                    if not ((base.SUPPORTS[si] >> removed_state) & 1)
                )
                label = "even" if k % 2 == 0 else "odd"
                u, v, _ = blocker_edges[label]
                assert nx.has_path(complement, u, v)
                component = frozenset(nx.node_connected_component(complement, u))
                y_terminals = ((k + 3) % 5, (k + 4) % 5)
                for terminal in y_terminals:
                    if terminal not in component:
                        side = canonical_side(component, n)
                        key = (removed_state, side)
                        if key not in known_routes:
                            known_routes.add(key)
                            route_cuts.append(key)
                            added = True
                        failures.append((k, terminal, tuple(sorted(component))))
            if added:
                continue
            if failures:
                raise RuntimeError("route failures repeated despite cuts")
            return {
                "n": n,
                "geometry": blocker_geometry,
                "required_windows": list(required_windows),
                "status": "all_ten_forced_paths_realized",
                "rounds": round_index + 1,
                "connectivity_cuts": len(connectivity_cuts),
                "route_cuts": len(route_cuts),
                "proper_edges_with_supports": [
                    {
                        "edge": [u, v],
                        "support": [
                            state
                            for state in range(10)
                            if (base.SUPPORTS[si] >> state) & 1
                        ],
                    }
                    for u, v, si in selected
                ],
            }
    return {
        "n": n,
        "geometry": blocker_geometry,
        "status": "round_limit",
        "rounds": max_rounds,
        "connectivity_cuts": len(connectivity_cuts),
        "route_cuts": len(route_cuts),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--geometry", choices=("adjacent", "disjoint", "both"), default="both")
    parser.add_argument("--max-rounds", type=int, default=500)
    parser.add_argument("--windows", type=int, nargs="*", default=list(range(10)))
    args = parser.parse_args()
    if any(k < 0 or k >= 10 for k in args.windows) or len(set(args.windows)) != len(args.windows):
        raise ValueError("windows must be distinct integers from 0 through 9")
    required_windows = tuple(args.windows)
    geometries = ("adjacent", "disjoint") if args.geometry == "both" else (args.geometry,)
    for geometry in geometries:
        print(solve(args.n, geometry, args.max_rounds, required_windows))


if __name__ == "__main__":
    main()
