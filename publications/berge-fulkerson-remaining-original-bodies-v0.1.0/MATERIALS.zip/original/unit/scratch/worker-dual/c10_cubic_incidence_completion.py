#!/usr/bin/env python3
"""Test cubic-incidence completions of the abstract C10 capacity blocker.

The ten designated matching states are indexed cyclically by Z/10.  State
``k`` belongs to boundary class ``k mod 5``.  Consecutive states must be
disjoint, so the support of every graph edge is an independent set of C10.
Every nonconsecutive pair is required to share an edge, making the designated
disjointness graph exactly C10.  The even and odd supports are forced as
proper edges; they are the two-row LP blocker for capacity two.

For a requested odd number ``n`` of internal vertices, the program asks GLPK
for a *simple connected* cubic 5-pole incidence matrix containing these ten
perfect matchings.  Terminals 0,...,4 carry semiedges with supports
``{i,i+5}``.  Connectivity is imposed by iterative component cuts.

This only tests incidence-level realizability of the ten designated
matchings.  It does not assert that they are all singleton-boundary perfect
matchings of the resulting pole.
"""

from __future__ import annotations

import argparse
from itertools import combinations
from pathlib import Path
import re
import subprocess
import tempfile

import networkx as nx


ORDER = 10
ALL = range(ORDER)


def is_independent(mask: int) -> bool:
    return all(
        not ((mask >> i) & 1 and (mask >> ((i + 1) % ORDER)) & 1)
        for i in ALL
    )


SUPPORTS = tuple(mask for mask in range(1 << ORDER) if is_independent(mask))
EVEN = sum(1 << i for i in range(0, ORDER, 2))
ODD = sum(1 << i for i in range(1, ORDER, 2))
BOUNDARY = tuple((1 << i) | (1 << (i + 5)) for i in range(5))


def variable(u: int, v: int, support_index: int) -> str:
    return f"y_{u}_{v}_{support_index}"


def linear_sum(names: list[str]) -> str:
    return " + ".join(names) if names else "0"


def write_lp(n: int, cuts: list[frozenset[int]], path: Path) -> None:
    pairs = tuple(combinations(range(n), 2))
    support_index = {mask: i for i, mask in enumerate(SUPPORTS)}
    lines = ["Minimize", " obj: y_0_1_0", "Subject To"]

    # Simple proper graph: at most one edge for a vertex pair.
    for u, v in pairs:
        lines.append(
            f" simple_{u}_{v}: "
            + linear_sum([variable(u, v, si) for si in range(len(SUPPORTS))])
            + " <= 1"
        )

    # Cubic degree, counting the fixed semiedge at terminals 0,...,4.
    for v in range(n):
        names = [
            variable(min(u, v), max(u, v), si)
            for u in range(n)
            if u != v
            for si in range(len(SUPPORTS))
        ]
        proper_degree = 2 if v < 5 else 3
        lines.append(f" degree_{v}: {linear_sum(names)} = {proper_degree}")

    # Each of the ten designated states selects exactly one incident edge at
    # every internal vertex.  A fixed semiedge already covers state k at its
    # terminal when k is in that semiedge support.
    for v in range(n):
        boundary_mask = BOUNDARY[v] if v < 5 else 0
        for k in ALL:
            names = [
                variable(min(u, v), max(u, v), si)
                for u in range(n)
                if u != v
                for si, mask in enumerate(SUPPORTS)
                if (mask >> k) & 1
            ]
            rhs = 0 if (boundary_mask >> k) & 1 else 1
            lines.append(f" match_{v}_{k}: {linear_sum(names)} = {rhs}")

    # Exact C10 disjointness on the ten designated states.  Consecutive pairs
    # are automatically disjoint because every allowed support is independent.
    coverage_id = 0
    for i, j in combinations(ALL, 2):
        if (j - i) % ORDER in (1, ORDER - 1):
            continue
        boundary_cover = any(
            ((mask >> i) & 1) and ((mask >> j) & 1) for mask in BOUNDARY
        )
        if boundary_cover:
            continue
        names = [
            variable(u, v, si)
            for u, v in pairs
            for si, mask in enumerate(SUPPORTS)
            if ((mask >> i) & 1) and ((mask >> j) & 1)
        ]
        lines.append(f" cover_{coverage_id}: {linear_sum(names)} >= 1")
        coverage_id += 1

    # The two common edges make every five-layer transversal violate capacity
    # two: every layer has one even and one odd state.
    for label, mask in (("even", EVEN), ("odd", ODD)):
        si = support_index[mask]
        names = [variable(u, v, si) for u, v in pairs]
        lines.append(f" force_{label}: {linear_sum(names)} >= 1")

    # Cuts accumulated from disconnected integer solutions.
    for cut_id, side in enumerate(cuts):
        names = [
            variable(min(u, v), max(u, v), si)
            for u in side
            for v in range(n)
            if v not in side
            for si in range(len(SUPPORTS))
        ]
        lines.append(f" connected_{cut_id}: {linear_sum(names)} >= 1")

    lines.append("Binary")
    for u, v in pairs:
        for si in range(len(SUPPORTS)):
            lines.append(" " + variable(u, v, si))
    lines.append("End")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_selected(solution: Path) -> list[tuple[int, int, int]]:
    selected = []
    pattern = re.compile(r"\by_(\d+)_(\d+)_(\d+)\b\s+\*?\s+1(?:\.0+)?\b")
    for line in solution.read_text(encoding="utf-8").splitlines():
        match = pattern.search(line)
        if match:
            selected.append(tuple(map(int, match.groups())))
    return selected


def solve(n: int, max_rounds: int = 100) -> dict:
    cuts: list[frozenset[int]] = []
    with tempfile.TemporaryDirectory(prefix="c10-cubic-incidence-") as temp:
        temp_path = Path(temp)
        lp = temp_path / "problem.lp"
        solution = temp_path / "solution.txt"
        for round_index in range(max_rounds):
            write_lp(n, cuts, lp)
            completed = subprocess.run(
                ["glpsol", "--lp", str(lp), "-o", str(solution)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                check=False,
            )
            if "INTEGER OPTIMAL SOLUTION FOUND" not in completed.stdout:
                return {
                    "n": n,
                    "status": "infeasible_or_solver_failure",
                    "connectivity_cuts": len(cuts),
                    "solver_tail": completed.stdout.splitlines()[-20:],
                }
            selected = read_selected(solution)
            graph = nx.Graph()
            graph.add_nodes_from(range(n))
            graph.add_edges_from((u, v) for u, v, _ in selected)
            components = [frozenset(c) for c in nx.connected_components(graph)]
            if len(components) == 1:
                return {
                    "n": n,
                    "status": "connected_simple_incidence_completion",
                    "connectivity_cuts": len(cuts),
                    "proper_edges_with_supports": [
                        {
                            "edge": [u, v],
                            "support": [k for k in ALL if (SUPPORTS[si] >> k) & 1],
                        }
                        for u, v, si in selected
                    ],
                }
            # A cut for every proper component is safe.  Canonicalize by also
            # storing its complement to avoid repeating the same inequality.
            known = {min(c, frozenset(range(n)) - c, key=lambda x: tuple(sorted(x))) for c in cuts}
            added = False
            for component in components:
                canonical = min(
                    component,
                    frozenset(range(n)) - component,
                    key=lambda x: tuple(sorted(x)),
                )
                if canonical and canonical not in known:
                    cuts.append(canonical)
                    known.add(canonical)
                    added = True
            if not added:
                raise RuntimeError("disconnected solution repeated despite component cuts")
    return {"n": n, "status": "connectivity_cut_limit", "connectivity_cuts": len(cuts)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("n", type=int, nargs="+", help="odd internal orders")
    parser.add_argument("--max-rounds", type=int, default=100)
    args = parser.parse_args()
    for n in args.n:
        if n < 5 or n % 2 == 0:
            raise ValueError("n must be odd and at least five")
        print(solve(n, args.max_rounds))


if __name__ == "__main__":
    main()
