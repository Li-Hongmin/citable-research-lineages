#!/usr/bin/env python3
"""Verify the exact matching-exchange boundary of the frozen Note-026 pole.

This program does not search other poles or orders.  It distinguishes two
closure notions on the one frozen 17-vertex pole:

1. pair-component closure: starting with N_i,N_{i+5}, flip components of
   P symmetric-difference Q only when both P and Q are already present;
2. full ambient closure: all singleton perfect matchings of the pole, or
   equivalently all flips on ambient alternating cycles.

The certificate proves that the first closure retains exactly the target
five-cycle of Tait states, while the second adds 02 and 13.  It then gives
the minimum one-cycle intrusion from the first closure for each extra state.
Only Python's standard library is used.
"""

from __future__ import annotations

from collections import defaultdict, deque
import importlib.util
from itertools import combinations
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SEED_PATH = (
    HERE.parent / "agent-proof" / "verify_two_window_counterexample.py"
)
SPEC = importlib.util.spec_from_file_location("note026_seed", SEED_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import frozen seed from {SEED_PATH}")
seed = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = seed
SPEC.loader.exec_module(seed)


Edge = tuple[int, int]
Matching = frozenset[Edge]
TARGET_S = frozenset({(0, 1), (1, 2), (2, 3), (3, 4), (0, 4)})
EXTRA_T = frozenset({(0, 2), (1, 3)})


def matching_key(matching: Matching) -> tuple[Edge, ...]:
    return tuple(sorted(matching))


def singleton_classes() -> tuple[tuple[Matching, ...], ...]:
    graph = seed.adjacency(set(seed.EDGE_SUPPORTS))
    return tuple(
        tuple(
            sorted(
                seed.enumerate_singleton_matchings(graph, position),
                key=matching_key,
            )
        )
        for position in range(5)
    )


def verify_singleton_matching(matching: Matching, position: int) -> None:
    incidence = [0] * seed.N
    for u, v in matching:
        assert (u, v) in seed.EDGE_SUPPORTS
        incidence[u] += 1
        incidence[v] += 1
    incidence[position] += 1  # the unique boundary semiedge
    assert incidence == [1] * seed.N


def component_edge_sets(first: Matching, second: Matching) -> tuple[Matching, ...]:
    """Connected alternating cycles in the same-class symmetric difference."""
    difference = first ^ second
    if not difference:
        return ()
    adjacency: dict[int, set[int]] = defaultdict(set)
    for u, v in difference:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())

    unseen = set(adjacency)
    answer = []
    while unseen:
        start = min(unseen)
        vertices = {start}
        queue = deque([start])
        unseen.remove(start)
        while queue:
            vertex = queue.popleft()
            for neighbour in adjacency[vertex]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    vertices.add(neighbour)
                    queue.append(neighbour)
        component = frozenset(
            edge for edge in difference if edge[0] in vertices
        )
        assert all(edge[1] in vertices for edge in component)
        assert len(component) % 2 == 0
        answer.append(component)
    return tuple(sorted(answer, key=matching_key))


def pair_component_closure(starts: tuple[Matching, ...]) -> frozenset[Matching]:
    """Least closure under components exposed by two already known members."""
    known = set(starts)
    changed = True
    while changed:
        changed = False
        snapshot = tuple(sorted(known, key=matching_key))
        for first, second in combinations(snapshot, 2):
            for component in component_edge_sets(first, second):
                candidate = first ^ component
                if candidate not in known:
                    known.add(candidate)
                    changed = True
    return frozenset(known)


def tait_states(families) -> frozenset[tuple[int, int]]:
    return frozenset(
        (left, right)
        for left, right in combinations(range(5), 2)
        if any(
            first.isdisjoint(second)
            for first in families[left]
            for second in families[right]
        )
    )


def canonical_cycle(component: Matching) -> tuple[int, ...]:
    adjacency: dict[int, set[int]] = defaultdict(set)
    for u, v in component:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert adjacency and all(len(neighbours) == 2 for neighbours in adjacency.values())
    start = min(adjacency)

    def traverse(first_neighbour: int) -> tuple[int, ...]:
        order = [start]
        previous, current = start, first_neighbour
        while current != start:
            order.append(current)
            following = adjacency[current] - {previous}
            assert len(following) == 1
            previous, current = current, next(iter(following))
        return tuple(order)

    return min(traverse(neighbour) for neighbour in adjacency[start])


def path_edges(path: list[int]) -> frozenset[Edge]:
    return frozenset(
        tuple(sorted((first, second)))
        for first, second in zip(path, path[1:])
    )


def best_one_cycle_source(
    target: Matching,
    boundary_class: int,
    designated: tuple[Matching, ...],
) -> tuple[int, Matching]:
    candidates = []
    for state in (boundary_class, boundary_class + 5):
        components = component_edge_sets(designated[state], target)
        if len(components) == 1:
            candidates.append((len(components[0]), state, components[0]))
    assert candidates
    _, state, component = min(candidates)
    return state, component


def edge_list(edges: Matching) -> list[list[int]]:
    return [list(edge) for edge in sorted(edges)]


def main() -> None:
    proper_edges = set(seed.EDGE_SUPPORTS)
    designated = tuple(frozenset(seed.matching(state)) for state in range(10))
    full = singleton_classes()
    assert tuple(len(layer) for layer in full) == (8, 8, 6, 7, 4)
    for position, layer in enumerate(full):
        assert len(layer) == len(set(layer))
        for matching in layer:
            verify_singleton_matching(matching, position)
    assert all(designated[state] in full[state % 5] for state in range(10))

    y0 = seed.boundary_paths_after_removing(1)[(3, 4)]
    y2 = seed.boundary_paths_after_removing(3)[(0, 1)]
    y_edges = {"Y0": path_edges(y0), "Y2": path_edges(y2)}
    assert seed.A in y_edges["Y0"] and seed.A in y_edges["Y2"]

    generated = tuple(
        pair_component_closure((designated[position], designated[position + 5]))
        for position in range(5)
    )
    assert tuple(len(layer) for layer in generated) == (4, 4, 2, 2, 2)
    designated_pair_components = tuple(
        component_edge_sets(
            designated[position], designated[position + 5]
        )
        for position in range(5)
    )
    assert tuple(len(items) for items in designated_pair_components) == (
        2,
        2,
        1,
        1,
        1,
    )

    # Explicit fixed-point check for the natural pair-component exchange axiom.
    for layer in generated:
        for first in layer:
            for second in layer:
                for component in component_edge_sets(first, second):
                    assert first ^ component in layer

    generated_states = tait_states(generated)
    full_states = tait_states(full)
    assert generated_states == TARGET_S
    assert full_states == TARGET_S | EXTRA_T

    witnesses = {}
    common_left_cycle = None
    right_cycles = []
    for left_class, right_class in sorted(EXTRA_T):
        pairs = [
            (left, right)
            for left in full[left_class]
            for right in full[right_class]
            if left.isdisjoint(right)
        ]
        assert len(pairs) == 2
        # The sharp distinction: the left matching has already been forced by
        # pair-component closure, whereas the right matching has not.
        assert all(left in generated[left_class] for left, _ in pairs)
        assert all(right not in generated[right_class] for _, right in pairs)
        assert all(left not in designated for left, _ in pairs)
        assert all(right not in designated for _, right in pairs)
        assert len({left for left, _ in pairs}) == 1

        ranked = []
        for left, right in pairs:
            left_state, left_cycle = best_one_cycle_source(
                left, left_class, designated
            )
            right_state, right_cycle = best_one_cycle_source(
                right, right_class, designated
            )
            ranked.append(
                (
                    len(left_cycle) + len(right_cycle),
                    len(right_cycle),
                    matching_key(left),
                    matching_key(right),
                    left,
                    right,
                    left_state,
                    right_state,
                    left_cycle,
                    right_cycle,
                )
            )
        (
            _,
            _,
            _,
            _,
            left,
            right,
            left_state,
            right_state,
            left_cycle,
            right_cycle,
        ) = min(ranked)

        assert designated[left_state] ^ left_cycle == left
        assert designated[right_state] ^ right_cycle == right
        assert left.isdisjoint(right)
        assert left_cycle.isdisjoint({seed.A, seed.B})
        assert right_cycle.isdisjoint({seed.A, seed.B})
        assert len(left_cycle) == 4 and len(right_cycle) == 8
        if common_left_cycle is None:
            common_left_cycle = left_cycle
        else:
            assert common_left_cycle == left_cycle
        right_cycles.append(right_cycle)

        state_name = f"{left_class}{right_class}"
        witnesses[state_name] = {
            "left_matching_in_pair_component_closure": edge_list(left),
            "right_matching_outside_pair_component_closure": edge_list(right),
            "left_source": f"N{left_state}",
            "left_alternating_cycle": list(canonical_cycle(left_cycle)),
            "right_source": f"N{right_state}",
            "right_ambient_alternating_cycle": list(canonical_cycle(right_cycle)),
            "right_cycle_window_edges": {
                name: edge_list(right_cycle & edges)
                for name, edges in y_edges.items()
            },
            "both_cycles_avoid_blockers_a_b": True,
            "resulting_pair_is_disjoint": True,
            "all_full_disjoint_pairs_for_state": len(pairs),
        }

    assert right_cycles[0] != right_cycles[1]
    assert common_left_cycle is not None

    output = {
        "scope": "frozen Note-026 17-vertex pole only",
        "blocked_windows": {
            "a": list(seed.A),
            "Y0": y0,
            "Y2": y2,
            "a_in_both": True,
        },
        "pair_component_closure": {
            "definition": (
                "least family containing N_i,N_(i+5) and closed under "
                "flipping a component of P symmetric-difference Q when "
                "P,Q are already present in the same boundary class"
            ),
            "class_sizes": [len(layer) for layer in generated],
            "designated_pair_alternating_components": [
                [list(canonical_cycle(component)) for component in components]
                for components in designated_pair_components
            ],
            "fixed_point_verified": True,
            "tait_states": [f"{i}{j}" for i, j in sorted(generated_states)],
            "has_non_S_state": False,
        },
        "full_singleton_matching_closure": {
            "class_sizes": [len(layer) for layer in full],
            "tait_states": [f"{i}{j}" for i, j in sorted(full_states)],
            "extra_states": [f"{i}{j}" for i, j in sorted(EXTRA_T)],
        },
        "minimum_intrusions": witnesses,
        "structural_boundary": {
            "common_generated_left_cycle": list(canonical_cycle(common_left_cycle)),
            "distinct_required_ambient_right_cycles": [
                list(canonical_cycle(cycle)) for cycle in right_cycles
            ],
            "right_cycles_are_distinct": True,
            "right_cycles_avoid_both_blocker_edges": True,
            "conclusion": (
                "double-window data plus pair-component exchange closure does "
                "not force a non-S state; the sample's non-S states use "
                "additional ambient alternating cycles.  The stronger theorem "
                "with complete perfect-matching closure is not decided."
            ),
        },
    }
    print(json.dumps(output, indent=2, sort_keys=False))
    print("NOTE026_EXCHANGE_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
