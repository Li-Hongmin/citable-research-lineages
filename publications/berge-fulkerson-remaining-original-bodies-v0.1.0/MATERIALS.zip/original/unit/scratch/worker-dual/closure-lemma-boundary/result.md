# Note 026 样本中的 matching-exchange 边界

本页只讨论 Note 026 冻结的 17 阶 pole。结论不是一般的 full-closure
定理，而是一个严格的分离命题：两个同奇偶 blocked $Y$-windows 加上
由 designated matchings 内生生成的 component-exchange 闭包，仍不推出
非 $S$ 的 Tait state。样本中的 $02,13$ 都来自这个闭包之外的
ambient alternating cycles。

## 两种闭包

记 $\mathcal M_i$ 为边界类 $i$ 的全部 singleton perfect matchings，
并令 $\mathcal B_i$ 是包含 $N_i,N_{i+5}$ 的最小集合，满足：若
$P,Q\in\mathcal B_i$，则对 $P\mathbin\triangle Q$ 的每个连通分量
$C$，都有 $P\mathbin\triangle C\in\mathcal B_i$。称
$\mathcal B=(\mathcal B_i)$ 为 **pair-component closure**。

这个定义只允许使用两个已经在集合中的 matching 所暴露的交替圈。它
弱于 full ambient closure：后者允许翻转图中任意 $P$-alternating
cycle，因而得到整个 $\mathcal M_i$。这个量词差异正是本样本的承重点。

## 严格分离命题

对冻结 pole，有


\[
 (|\mathcal B_0|,\ldots,|\mathcal B_4|)=(4,4,2,2,2),
\]

且 $\mathcal B$ 的 disjoint boundary-pair support 恰为

\[
 S=\{01,04,12,23,34\}.
\]

与此同时，完整 singleton matching classes 满足

\[
 (|\mathcal M_0|,\ldots,|\mathcal M_4|)=(8,8,6,7,4),
\]

其 support 为

\[
 S\cup\{02,13\}.
\]

而同一个 designated system 仍有

\[
 a=(5,6)\in Y_0(H-N_1)\cap Y_2(H-N_3).
\]

因此存在一个由同一真实 cubic pole 的真实 perfect matchings 组成的
component-exchange-closed 子模型，它保留两个 blocked windows，却没有
任何非 $S$ state。这严格排除了以下推理：只从 blocked-window 数据、
designated $C_{10}$ 和“两个已知 matching 之间可逐分量交换”推出 T-state。

### 证明

对五个边界类，$N_i\mathbin\triangle N_{i+5}$ 的交替圈分量数依次为

\[
 2,2,1,1,1.
\]

前两类的两个分量分别是

\[
 3-13-10-16-3
\]

和

\[
 5-6-14-11-15-12-8-7-5.
\]

其余三类各只有一个分量。因此翻转任意分量子集得到的 Boolean cubes
大小为 $(4,4,2,2,2)$。任意两个 cube 元素的对称差仍只是原分量的一个
子集，所以该族已经是 pair-component closure 的不动点。直接检查这些
14 个 matching 的跨类不交关系，恰得 $S$。

另一方面，对同一 23-edge pole 递归枚举删除相应 terminal vertex 后的
全部 perfect matchings，得到 class sizes $(8,8,6,7,4)$。穷尽所有跨类
不交对，只比 $S$ 多出 $02,13$。脚本同时逐顶点检查每个枚举对象确为
singleton perfect matching，并穷尽验证上述不动点与全部不交关系。

## 两个 extra states 的最短交换来源

令

\[
 C=3-13-10-16-3.
\]

它已经由 designated antipodal pairs 暴露，因此

\[
 P_0=N_0\mathbin\triangle C\in\mathcal B_0,
 \qquad
 P_1=N_6\mathbin\triangle C\in\mathcal B_1.
\]

状态 $02$ 的最短证书是

\[
 Q_2=N_7\mathbin\triangle D_{02},
 \qquad P_0\cap Q_2=\varnothing,
\]

其中

\[
 D_{02}=0-4-9-13-3-16-8-12-0.
\]

这里 $Q_2\in\mathcal M_2\setminus\mathcal B_2$。状态 $13$ 的最短
证书是

\[
 Q_3=N_3\mathbin\triangle D_{13},
 \qquad P_1\cap Q_3=\varnothing,
\]

其中

\[
 D_{13}=0-4-9-13-10-11-15-12-0,
\]

且 $Q_3\in\mathcal M_3\setminus\mathcal B_3$。完整枚举还表明，每个
extra state 恰有两个 disjoint realizations；每个 realization 的左端都
已在 $\mathcal B_0$ 或 $\mathcal B_1$ 中，而右端都在相应的
$\mathcal B_2,\mathcal B_3$ 之外。因此相对于 pair-component closure，
每个 extra state 的最小 intrusion 恰是一个新的 ambient alternating
cycle；相对于十个 designated matchings，则仍需要左右各一次交换。

两个 8-cycle $D_{02},D_{13}$ 不同，而且它们与公共 4-cycle $C$ 都不
包含 blocker edges $a=(5,6)$ 或 $b=(5,7)$。它们在两个窗口中的边交为

\[
\begin{aligned}
D_{02}\cap Y_0&=\{(4,9),(9,13),(3,16),(8,16)\},\\
D_{02}\cap Y_2&=\{(0,12),(8,12)\},\\
D_{13}\cap Y_0&=\{(4,9),(9,13),(10,13),(10,11)\},\\
D_{13}\cap Y_2&=\{(0,12),(11,15)\}.
\end{aligned}
\]

所以 extra states 并不是由穿过公共 blocker 的一个统一局部 cycle-flip
产生；它们使用两个不同的全局绕行。

## 一般命题的准确失败边界

这个样本既没有证明、也没有反驳

\[
 \text{两个同奇偶 blocked }Y\text{-windows + full matching closure}
 \Longrightarrow \text{至少一个非 }S\text{ state}.
\]

它确定了证明所缺的最小类型信息：必须从 complete ambient graph 推出一个
**escape cycle** $D$，使某个新 matching $N_r\mathbin\triangle D$ 与
pair-component closure 中另一非相邻边界类的 matching 不交。只重复
designated antipodal component flips 不可能做到这一点，因为对应闭包已
严格停在 $S$。

因此本叶停止于明确边界：一般 full-closure lemma 仍开放；Note 026 的两个
extra states 只能证明完整图在这个样本中恰好提供了所需 escape cycles，
不能证明 double-window 接口在任意 pole 中强制这些 cycles。

复跑：

```bash
uv run python units/berge-fulkerson/scratch/worker-dual/closure-lemma-boundary/verify_exchange_boundary.py
```

终止标记为 `NOTE026_EXCHANGE_BOUNDARY_VERIFIED`。
