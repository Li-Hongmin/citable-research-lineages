#!/usr/bin/env python3
"""Search all-ten forced-path cubic completions with exact flow constraints.

This has the same incidence-only scope as
``search_forced_path_incidence_completion.py``.  Unlike that lazy route-cut
prototype, every required blocker-to-Y connection is present in the initial
MIP as a unit-flow system.  Only whole-graph connectivity is separated
lazily.
"""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE / "c10_cubic_incidence_completion.py"
SPEC = importlib.util.spec_from_file_location("incidence_completion_base", BASE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {BASE_PATH}")
base = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = base
SPEC.loader.exec_module(base)


def canonical_side(side: frozenset[int], n: int) -> frozenset[int]:
    complement = frozenset(range(n)) - side
    return min(side, complement, key=lambda current: tuple(sorted(current)))


def flow_variable(k: int, orientation: int, connection: int, u: int, v: int) -> str:
    return f"f_{k}_{orientation}_{connection}_{u}_{v}"


def orientation_variable(k: int, orientation: int) -> str:
    return f"z_{k}_{orientation}"


def signed_sum(positive: list[str], negative: list[str]) -> str:
    terms = list(positive)
    terms.extend(f"- {name}" for name in negative)
    return " + ".join(terms).replace("+ -", "-") if terms else "0"


def add_forced_path_flows(
    path: Path,
    n: int,
    blocker_edges: dict[str, tuple[int, int, int]],
    required_windows: tuple[int, ...],
    fixed_orientations: dict[int, int],
) -> None:
    lines = path.read_text(encoding="utf-8").splitlines()
    binary_index = lines.index("Binary")
    support_index = {mask: i for i, mask in enumerate(base.SUPPORTS)}
    constraints: list[str] = []
    orientation_names: list[str] = []

    for label, (u, v, mask) in blocker_edges.items():
        constraints.append(
            f" fix_{label}: {base.variable(min(u, v), max(u, v), support_index[mask])} = 1"
        )

    for k in required_windows:
        removed_state = (k + 1) % 10
        y1, y2 = (k + 3) % 5, (k + 4) % 5
        label = "even" if k % 2 == 0 else "odd"
        blocker_u, blocker_v, _ = blocker_edges[label]
        blocker_pair = frozenset((blocker_u, blocker_v))
        z_names = [orientation_variable(k, orientation) for orientation in range(2)]
        orientation_names.extend(z_names)
        constraints.append(f" orient_{k}: {z_names[0]} + {z_names[1]} = 1")
        if k in fixed_orientations:
            orientation = fixed_orientations[k]
            constraints.append(f" fix_orient_{k}: {z_names[orientation]} = 1")

        for orientation in range(2):
            endpoints = (
                ((y1, blocker_u), (y2, blocker_v))
                if orientation == 0
                else ((y1, blocker_v), (y2, blocker_u))
            )
            z_name = orientation_variable(k, orientation)
            for connection, (source, sink) in enumerate(endpoints):
                for vertex in range(n):
                    outgoing = [
                        flow_variable(k, orientation, connection, vertex, other)
                        for other in range(n)
                        if other != vertex and frozenset((vertex, other)) != blocker_pair
                    ]
                    incoming = [
                        flow_variable(k, orientation, connection, other, vertex)
                        for other in range(n)
                        if other != vertex and frozenset((vertex, other)) != blocker_pair
                    ]
                    positive = list(outgoing)
                    negative = list(incoming)
                    if vertex == source:
                        negative.append(z_name)
                    elif vertex == sink:
                        positive.append(z_name)
                    constraints.append(
                        f" flow_{k}_{orientation}_{connection}_{vertex}: "
                        f"{signed_sum(positive, negative)} = 0"
                    )

                for u in range(n):
                    for v in range(n):
                        if u == v or frozenset((u, v)) == blocker_pair:
                            continue
                        name = flow_variable(k, orientation, connection, u, v)
                        constraints.append(
                            f" active_{k}_{orientation}_{connection}_{u}_{v}: {name} - {z_name} <= 0"
                        )
                        available = [
                            base.variable(min(u, v), max(u, v), si)
                            for si, support in enumerate(base.SUPPORTS)
                            if not ((support >> removed_state) & 1)
                        ]
                        constraints.append(
                            f" capacity_{k}_{orientation}_{connection}_{u}_{v}: "
                            f"{signed_sum([name], available)} <= 0"
                        )

    lines[binary_index:binary_index] = constraints
    lines[binary_index + len(constraints) + 1 : binary_index + len(constraints) + 1] = [
        " " + name for name in orientation_names
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_routes(
    n: int,
    selected: list[tuple[int, int, int]],
    blocker_edges: dict[str, tuple[int, int, int]],
    required_windows: tuple[int, ...],
) -> None:
    for k in required_windows:
        removed_state = (k + 1) % 10
        complement = nx.Graph()
        complement.add_nodes_from(range(n))
        complement.add_edges_from(
            (u, v)
            for u, v, support_index in selected
            if not ((base.SUPPORTS[support_index] >> removed_state) & 1)
        )
        label = "even" if k % 2 == 0 else "odd"
        blocker_u, blocker_v, _ = blocker_edges[label]
        component = nx.node_connected_component(complement, blocker_u)
        assert blocker_v in component
        assert (k + 3) % 5 in component
        assert (k + 4) % 5 in component


def solve_lp_with_highs(lp: Path) -> tuple[str, list[tuple[int, int, int]], str]:
    try:
        import highspy
    except ImportError as error:
        raise RuntimeError("HiGHS backend requires: uv run --with highspy ...") from error

    solver = highspy.Highs()
    solver.setOptionValue("output_flag", False)
    solver.setOptionValue("threads", 2)
    solver.readModel(str(lp))
    solver.run()
    model_status = solver.getModelStatus()
    status_text = solver.modelStatusToString(model_status)
    if model_status == highspy.HighsModelStatus.kOptimal:
        model = solver.getLp()
        values = solver.getSolution().col_value
        selected = []
        for name, value in zip(model.col_names_, values):
            if not name.startswith("y_") or value < 0.5:
                continue
            _, u, v, support_index = name.split("_")
            selected.append((int(u), int(v), int(support_index)))
        return "optimal", selected, status_text
    if model_status in (
        highspy.HighsModelStatus.kInfeasible,
        highspy.HighsModelStatus.kUnboundedOrInfeasible,
    ):
        return "infeasible", [], status_text
    return "unknown", [], status_text


def solve(
    n: int,
    blocker_geometry: str,
    max_rounds: int,
    required_windows: tuple[int, ...] = tuple(range(10)),
    solver_backend: str = "glpk",
    fixed_orientations: dict[int, int] | None = None,
) -> dict:
    if n < 9:
        raise ValueError("need four nonterminal vertices to fix two blocker edges")
    blocker_edges = {
        "even": (5, 6, base.EVEN),
        "odd": (5, 7, base.ODD) if blocker_geometry == "adjacent" else (7, 8, base.ODD),
    }
    fixed_orientations = fixed_orientations or {}
    connectivity_cuts: list[frozenset[int]] = []
    known_connectivity: set[frozenset[int]] = set()

    with tempfile.TemporaryDirectory(prefix="forced-path-flow-") as temporary:
        temporary_path = Path(temporary)
        lp = temporary_path / "problem.lp"
        solution = temporary_path / "solution.txt"
        for round_index in range(max_rounds):
            base.write_lp(n, connectivity_cuts, lp)
            add_forced_path_flows(
                lp, n, blocker_edges, required_windows, fixed_orientations
            )
            if solver_backend == "highs":
                backend_status, selected, solver_details = solve_lp_with_highs(lp)
                solver_tail = [solver_details]
            else:
                completed = subprocess.run(
                    ["glpsol", "--lp", str(lp), "-o", str(solution)],
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
                output = completed.stdout
                if "INTEGER OPTIMAL SOLUTION FOUND" in output:
                    backend_status = "optimal"
                    selected = base.read_selected(solution)
                elif (
                    "PROBLEM HAS NO INTEGER FEASIBLE SOLUTION" in output
                    or "PROBLEM HAS NO PRIMAL FEASIBLE SOLUTION" in output
                    or "LP HAS NO PRIMAL FEASIBLE SOLUTION" in output
                ):
                    backend_status = "infeasible"
                    selected = []
                else:
                    backend_status = "unknown"
                    selected = []
                solver_tail = output.splitlines()[-16:]

            if backend_status != "optimal":
                status = "infeasible" if backend_status == "infeasible" else "solver_failure_or_unknown"
                return {
                    "n": n,
                    "geometry": blocker_geometry,
                    "required_windows": list(required_windows),
                    "fixed_orientations": fixed_orientations,
                    "status": status,
                    "rounds": round_index + 1,
                    "connectivity_cuts": len(connectivity_cuts),
                    "solver_tail": solver_tail,
                }

            verify_routes(n, selected, blocker_edges, required_windows)
            graph = nx.Graph()
            graph.add_nodes_from(range(n))
            graph.add_edges_from((u, v) for u, v, _ in selected)
            components = [frozenset(component) for component in nx.connected_components(graph)]
            if len(components) == 1:
                return {
                    "n": n,
                    "geometry": blocker_geometry,
                    "required_windows": list(required_windows),
                    "fixed_orientations": fixed_orientations,
                    "status": "all_ten_forced_paths_realized",
                    "rounds": round_index + 1,
                    "connectivity_cuts": len(connectivity_cuts),
                    "proper_edges_with_supports": [
                        {
                            "edge": [u, v],
                            "support": [
                                state
                                for state in range(10)
                                if (base.SUPPORTS[support_index] >> state) & 1
                            ],
                        }
                        for u, v, support_index in selected
                    ],
                }

            added = False
            for component in components:
                side = canonical_side(component, n)
                if side and side not in known_connectivity:
                    known_connectivity.add(side)
                    connectivity_cuts.append(side)
                    added = True
            if not added:
                raise RuntimeError("disconnected solution repeated despite connectivity cuts")

    return {
        "n": n,
        "geometry": blocker_geometry,
        "status": "round_limit",
        "rounds": max_rounds,
        "connectivity_cuts": len(connectivity_cuts),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--geometry", choices=("adjacent", "disjoint", "both"), default="both")
    parser.add_argument("--max-rounds", type=int, default=30)
    parser.add_argument("--solver", choices=("glpk", "highs"), default="glpk")
    parser.add_argument(
        "--windows",
        type=int,
        nargs="*",
        default=list(range(10)),
        help="directed windows k whose blocker edge must lie on Y_k",
    )
    parser.add_argument(
        "--orientation-mask",
        type=int,
        default=None,
        help="fix orientation of each requested window by its bit in this mask",
    )
    args = parser.parse_args()
    if any(k < 0 or k >= 10 for k in args.windows) or len(set(args.windows)) != len(args.windows):
        raise ValueError("windows must be distinct integers from 0 through 9")
    required_windows = tuple(args.windows)
    fixed_orientations = {}
    if args.orientation_mask is not None:
        if args.orientation_mask < 0 or args.orientation_mask >= (1 << len(required_windows)):
            raise ValueError("orientation mask is outside the requested-window range")
        fixed_orientations = {
            k: (args.orientation_mask >> index) & 1
            for index, k in enumerate(required_windows)
        }
    geometries = ("adjacent", "disjoint") if args.geometry == "both" else (args.geometry,)
    for geometry in geometries:
        print(
            solve(
                args.n,
                geometry,
                args.max_rounds,
                required_windows,
                args.solver,
                fixed_orientations,
            )
        )


if __name__ == "__main__":
    main()
