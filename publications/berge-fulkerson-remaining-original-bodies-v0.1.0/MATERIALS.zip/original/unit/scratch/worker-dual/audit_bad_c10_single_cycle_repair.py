#!/usr/bin/env python3
"""Test a falsifiable one-cycle closure lemma on exact-S cubic 5-poles.

Candidate lemma tested per pole:

    Every induced C10 subsystem consisting of two singleton matchings in each
    Case-XII boundary class, whose 32 internal transversals all violate edge
    capacity two, has a capacity-two transversal after replacing one selected
    state by a same-class singleton matching at one alternating-cycle exchange.

The finite audit is diagnostic only; success at bounded order is not a proof.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import importlib.util
from itertools import combinations, product
from pathlib import Path
import subprocess
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent / "case_xii_n13_c10_target.py"
BASE_SPEC = importlib.util.spec_from_file_location("worker_dual_c10_base", BASE_PATH)
if BASE_SPEC is None or BASE_SPEC.loader is None:
    raise RuntimeError(f"cannot import {BASE_PATH}")
base = importlib.util.module_from_spec(BASE_SPEC)
sys.modules[BASE_SPEC.name] = base
BASE_SPEC.loader.exec_module(base)


ORDER = base.legacy.PENTAGON_ORDER


def matching_key(matching):
    return tuple(sorted(matching))


def capacity_two(chosen):
    multiplicity = Counter(edge for matching in chosen for edge in matching)
    return max(multiplicity.values()) <= 2


def cycle_component_count(first, second, edge_vertices):
    difference = first ^ second
    adjacency = defaultdict(set)
    for edge in difference:
        endpoints = edge_vertices[edge]
        if len(endpoints) != 2:
            raise AssertionError("same singleton class should cancel its semiedge")
        u, v = endpoints
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert adjacency and all(len(neighbours) == 2 for neighbours in adjacency.values())
    unseen = set(adjacency)
    components = 0
    while unseen:
        components += 1
        stack = [next(iter(unseen))]
        while stack:
            vertex = stack.pop()
            if vertex not in unseen:
                continue
            unseen.remove(vertex)
            stack.extend(adjacency[vertex] & unseen)
    return components


def pair_transition(left_pair, right_pair):
    edges = [
        (i, j)
        for i, left in enumerate(left_pair)
        for j, right in enumerate(right_pair)
        if left.isdisjoint(right)
    ]
    if len(edges) != 2:
        return None
    if {i for i, _ in edges} != {0, 1} or {j for _, j in edges} != {0, 1}:
        return None
    target_from_zero = next(j for i, j in edges if i == 0)
    return target_from_zero  # 0 = parallel, 1 = crossed in the fixed pair orders


def c10_subsystems(singleton):
    pair_layers = []
    for position in ORDER:
        current = [
            tuple(sorted(pair, key=matching_key))
            for pair in combinations(singleton[position], 2)
        ]
        pair_layers.append(tuple(sorted(current, key=lambda pair: tuple(map(matching_key, pair)))))

    transitions = []
    for layer in range(5):
        following = (layer + 1) % 5
        table = defaultdict(list)
        for left_index, left_pair in enumerate(pair_layers[layer]):
            for right_index, right_pair in enumerate(pair_layers[following]):
                bit = pair_transition(left_pair, right_pair)
                if bit is not None:
                    table[left_index].append((right_index, bit))
        transitions.append(table)

    for first_index, first_pair in enumerate(pair_layers[0]):
        chosen_indices = [first_index]
        bits = []

        def extend(layer):
            if layer == 4:
                last_index = chosen_indices[-1]
                for closing_index, bit in transitions[4].get(last_index, ()): 
                    if closing_index != first_index:
                        continue
                    if sum(bits) % 2 != bit:
                        # XOR of all five transition bits is one exactly when
                        # the lift is connected C10 rather than two C5s.
                        yield tuple(
                            pair_layers[t][chosen_indices[t]] for t in range(5)
                        )
                return
            current_index = chosen_indices[-1]
            for next_index, bit in transitions[layer].get(current_index, ()):
                chosen_indices.append(next_index)
                bits.append(bit)
                yield from extend(layer + 1)
                bits.pop()
                chosen_indices.pop()

        yield from extend(0)


def designated_good(pair_layers):
    for bits in product((0, 1), repeat=5):
        chosen = tuple(pair_layers[layer][bits[layer]] for layer in range(5))
        if capacity_two(chosen):
            return chosen
    return None


def two_edge_farkas_blockers(pair_layers):
    states = tuple(matching for pair in pair_layers for matching in pair)
    edges = sorted(set().union(*states))
    return tuple(
        (first, second)
        for first, second in combinations(edges, 2)
        if all(first in matching or second in matching for matching in states)
    )


def one_cycle_repair(pair_layers, singleton, edge_vertices):
    selected_sets = [set(pair) for pair in pair_layers]
    for replace_layer in range(5):
        position = ORDER[replace_layer]
        for source in pair_layers[replace_layer]:
            for replacement in singleton[position]:
                if replacement in selected_sets[replace_layer]:
                    continue
                if cycle_component_count(source, replacement, edge_vertices) != 1:
                    continue
                other_layers = [layer for layer in range(5) if layer != replace_layer]
                for bits in product((0, 1), repeat=4):
                    chosen = [None] * 5
                    chosen[replace_layer] = replacement
                    for bit, layer in zip(bits, other_layers):
                        chosen[layer] = pair_layers[layer][bit]
                    if capacity_two(chosen):
                        return {
                            "replace_layer": replace_layer,
                            "position": position,
                            "source": sorted(source),
                            "replacement": sorted(replacement),
                            "cycle_edges": sorted(source ^ replacement),
                            "removed_edges": sorted(source - replacement),
                            "added_edges": sorted(replacement - source),
                            "chosen": [sorted(matching) for matching in chosen],
                        }
    return None


def c10_cycle_order(pair_layers):
    states = tuple(matching for pair in pair_layers for matching in pair)
    adjacency = {
        matching: sorted(
            (other for other in states if other != matching and matching.isdisjoint(other)),
            key=matching_key,
        )
        for matching in states
    }
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())
    start = min(states, key=matching_key)
    order = [start, adjacency[start][0]]
    while len(order) < 10:
        previous, current = order[-2], order[-1]
        following = next(neighbour for neighbour in adjacency[current] if neighbour != previous)
        assert following not in order
        order.append(following)
    assert start in adjacency[order[-1]]
    return tuple(order)


def path_preserving_repair(pair_layers, singleton, edge_vertices, edge_position):
    cycle = c10_cycle_order(pair_layers)
    selected = set(cycle)
    for direction in (1, -1):
        for offset, source in enumerate(cycle):
            following = [cycle[(offset + direction * step) % 10] for step in range(1, 5)]
            position = next(
                edge_position[edge]
                for edge in source
                if edge_position[edge] is not None
            )
            for replacement in singleton[position]:
                if replacement in selected:
                    continue
                if cycle_component_count(source, replacement, edge_vertices) != 1:
                    continue
                if not replacement.isdisjoint(following[0]):
                    continue
                if replacement & following[1] & following[3]:
                    continue
                chosen = (replacement, *following)
                assert capacity_two(chosen)
                return {
                    "position": position,
                    "source": sorted(source),
                    "replacement": sorted(replacement),
                    "cycle_edges": sorted(source ^ replacement),
                    "window": [sorted(matching) for matching in chosen],
                }
    return None


def analyze_pole(pole, stop_on_failure=True):
    matchings, edge_vertices, edge_position, _ = base.legacy.enumerate_perfect_matchings(pole)
    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = base.legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    for position in singleton:
        singleton[position].sort(key=matching_key)

    counts = Counter()
    first_failure = None
    first_repair = None
    for subsystem in c10_subsystems(singleton):
        counts["c10_subsystems"] += 1
        if designated_good(subsystem) is not None:
            counts["c10_with_internal_capacity_two"] += 1
            continue
        counts["bad_c10_subsystems"] += 1
        blockers = two_edge_farkas_blockers(subsystem)
        if blockers:
            counts["bad_with_two_edge_farkas_blocker"] += 1
            counts[f"two_edge_blocker_count_{len(blockers)}"] += 1
        else:
            counts["bad_without_two_edge_farkas_blocker"] += 1
        repair = one_cycle_repair(subsystem, singleton, edge_vertices)
        path_repair = path_preserving_repair(
            subsystem, singleton, edge_vertices, edge_position
        )
        if path_repair is None:
            counts["path_preserving_failures"] += 1
        else:
            counts["path_preserving_repairs"] += 1
            counts[f"path_repair_cycle_length_{len(path_repair['cycle_edges'])}"] += 1
        if repair is None:
            counts["one_cycle_failures"] += 1
            first_failure = {
                "proper_edges": pole.proper_edges,
                "singleton_sizes": [len(singleton[i]) for i in range(1, 6)],
                "subsystem": [[sorted(matching) for matching in pair] for pair in subsystem],
            }
            if stop_on_failure:
                break
        else:
            counts["one_cycle_repairs"] += 1
            counts[f"repair_cycle_length_{len(repair['cycle_edges'])}"] += 1
            repair["two_edge_farkas_blockers"] = blockers
            repair["path_preserving_repair"] = path_repair
            if first_repair is None:
                first_repair = repair
    return counts, first_failure, first_repair


def explicit_completion():
    edges = (
        (0, 2), (0, 3), (1, 3), (1, 4), (2, 12), (4, 8),
        (5, 6), (5, 9), (5, 10), (6, 7), (6, 9), (7, 8),
        (7, 11), (8, 12), (9, 10), (10, 11), (11, 12),
    )
    return base.legacy.Pole(n=13, proper_edges=tuple(sorted(edges)))


def audit_order(n, stop_on_failure=True):
    command = ["geng", "-q", "-c", "-d3", "-D5", str(n + 1), str((3 * n + 5) // 2)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    assert process.stdout is not None
    totals = Counter()
    first_failure = None
    first_repair = None
    for line in process.stdout:
        totals["generated"] += 1
        graph = nx.from_graph6_bytes(line.strip().encode())
        if Counter(dict(graph.degree()).values()) != Counter({3: n, 5: 1}):
            continue
        apex = next(vertex for vertex, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        normalized = base.normalized_mapping(graph, apex, n)
        if normalized is None:
            continue
        totals["exact_S_poles"] += 1
        _, pole = normalized
        counts, failure, repair = analyze_pole(pole, stop_on_failure=stop_on_failure)
        totals.update(counts)
        if first_repair is None and repair is not None:
            first_repair = repair
        if failure is not None:
            first_failure = {"graph6": line.strip(), **failure}
            if stop_on_failure:
                process.terminate()
                break
    returncode = process.wait()
    if first_failure is None:
        assert returncode == 0
    return {
        "n": n,
        "counts": dict(totals),
        "first_failure": first_failure,
        "first_repair": first_repair,
    }


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Audit the one-cycle repair lemma.  With no arguments, run the "
            "declared complete orders 5,7,9,11,13."
        )
    )
    parser.add_argument("--explicit", action="store_true")
    parser.add_argument("--n", type=int, nargs="*")
    parser.add_argument("--all-failures", action="store_true")
    args = parser.parse_args()
    if args.explicit:
        counts, failure, repair = analyze_pole(explicit_completion(), not args.all_failures)
        print({"explicit": True, "counts": dict(counts), "first_failure": failure, "first_repair": repair})
    orders = args.n
    if not args.explicit and args.n is None:
        orders = [5, 7, 9, 11, 13]
    for n in orders or ():
        print(audit_order(n, not args.all_failures))


if __name__ == "__main__":
    main()
