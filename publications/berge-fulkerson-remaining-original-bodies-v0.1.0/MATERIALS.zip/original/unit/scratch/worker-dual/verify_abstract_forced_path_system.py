#!/usr/bin/env python3
"""Verify the minimal local path-system obstruction around an abstract C10.

This is deliberately not a graph-realizability certificate.  It shows that
the current disjointness, Boolean-fibre, endpoint-pairing, and mod-2 endpoint
axioms alone permit all ten forced paths to carry a triple-common blocker.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
from itertools import combinations
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "cocycle_monodromy_leaf_20260824" / "verify_abstract_countermodel.py"
SPEC = importlib.util.spec_from_file_location("abstract_c10_source", SOURCE)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {SOURCE}")
source = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = source
SPEC.loader.exec_module(source)


PENTAGON_ORDER = (1, 4, 2, 5, 3)


def main():
    states = source.build_matchings()
    assert len(states) == 10
    disjoint = {
        frozenset((i, j))
        for i, j in combinations(range(10), 2)
        if states[i].isdisjoint(states[j])
    }
    assert disjoint == {
        frozenset((k, (k + 1) % 10)) for k in range(10)
    }

    path_records = []
    for k in range(10):
        triple = states[k] & states[(k + 2) % 10] & states[(k + 4) % 10]
        blocker = "a" if k % 2 == 0 else "b"
        assert blocker in triple
        # In layer coordinates, H-N_{k+1} has X endpoints k,k+2 and the
        # other forced path Y endpoints k+3,k+4 (all modulo five).
        y_layers = tuple(sorted(((k + 3) % 5, (k + 4) % 5)))
        y_positions = tuple(sorted(PENTAGON_ORDER[layer] for layer in y_layers))
        path_records.append(
            {
                "k": k,
                "blocker": blocker,
                "y_layers": y_layers,
                "y_positions": y_positions,
            }
        )

    for parity, blocker in ((0, "a"), (1, "b")):
        current = [record for record in path_records if record["k"] % 2 == parity]
        assert all(record["blocker"] == blocker for record in current)
        pair_counts = Counter(record["y_positions"] for record in current)
        assert set(pair_counts.values()) == {1}
        assert len(pair_counts) == 5
        endpoint_counts = Counter(position for record in current for position in record["y_positions"])
        assert endpoint_counts == Counter({position: 2 for position in range(1, 6)})

    total_endpoint_counts = Counter(
        position for record in path_records for position in record["y_positions"]
    )
    assert total_endpoint_counts == Counter({position: 4 for position in range(1, 6)})

    print(
        {
            "states": 10,
            "disjointness": "C10",
            "blocker_edges": 2,
            "forced_path_obstructions": 10,
            "five_path_endpoint_degree_per_parity": [2, 2, 2, 2, 2],
            "all_endpoint_parities_even": True,
            "graph_realizability_claimed": False,
        }
    )
    print("ABSTRACT_FORCED_PATH_SYSTEM_VERIFIED")


if __name__ == "__main__":
    main()
