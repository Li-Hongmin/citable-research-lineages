#!/usr/bin/env python3
"""Test the C10 cycle-flip lemma in all +2 expansions of the Note-009 pole."""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
from itertools import combinations, product
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
HELPER_PATH = HERE.parent / "worker-verify" / "scan_n15_local_expansions.py"
SPEC = importlib.util.spec_from_file_location("n15_expansion_helper", HELPER_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {HELPER_PATH}")
helper = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = helper
SPEC.loader.exec_module(helper)


helper.BASE_N = 13
helper.BASE_PROPER = (
    (0, 2), (0, 3), (1, 3), (1, 4), (2, 12), (4, 8),
    (5, 6), (5, 9), (5, 10), (6, 7), (6, 9), (7, 8),
    (7, 11), (8, 12), (9, 10), (10, 11), (11, 12),
)
helper.BASE_SEMI_ENDPOINTS = (0, 1, 2, 3, 4)

ORDER = (0, 3, 1, 4, 2)  # boundary positions 1,4,2,5,3 in zero-based form


def matching_key(mask):
    return mask


def pair_transition(left_pair, right_pair):
    edges = [
        (i, j)
        for i, left in enumerate(left_pair)
        for j, right in enumerate(right_pair)
        if left & right == 0
    ]
    if len(edges) != 2:
        return None
    if {i for i, _ in edges} != {0, 1} or {j for _, j in edges} != {0, 1}:
        return None
    return next(j for i, j in edges if i == 0)


def c10_subsystems(classes):
    pair_layers = [tuple(combinations(classes[position], 2)) for position in ORDER]
    transitions = []
    for layer in range(5):
        following = (layer + 1) % 5
        table = defaultdict(list)
        for left_index, left_pair in enumerate(pair_layers[layer]):
            for right_index, right_pair in enumerate(pair_layers[following]):
                bit = pair_transition(left_pair, right_pair)
                if bit is not None:
                    table[left_index].append((right_index, bit))
        transitions.append(table)

    for first_index in range(len(pair_layers[0])):
        indices = [first_index]
        bits = []

        def extend(layer):
            if layer == 4:
                for closing_index, bit in transitions[4].get(indices[-1], ()):
                    if closing_index == first_index and sum(bits) % 2 != bit:
                        yield tuple(pair_layers[t][indices[t]] for t in range(5))
                return
            for next_index, bit in transitions[layer].get(indices[-1], ()):
                indices.append(next_index)
                bits.append(bit)
                yield from extend(layer + 1)
                bits.pop()
                indices.pop()

        yield from extend(0)


def capacity_two(chosen, edge_count):
    counts = [0] * edge_count
    for matching in chosen:
        remaining = matching
        while remaining:
            low = remaining & -remaining
            edge = low.bit_length() - 1
            counts[edge] += 1
            if counts[edge] == 3:
                return False
            remaining ^= low
    return True


def internally_good(subsystem, edge_count):
    return any(
        capacity_two(
            tuple(subsystem[layer][bits[layer]] for layer in range(5)), edge_count
        )
        for bits in product((0, 1), repeat=5)
    )


def blocker_pairs(subsystem, proper_count):
    states = tuple(matching for pair in subsystem for matching in pair)
    used_proper = 0
    for matching in states:
        used_proper |= matching & ((1 << proper_count) - 1)
    indices = [edge for edge in range(proper_count) if (used_proper >> edge) & 1]
    return tuple(
        (first, second)
        for first, second in combinations(indices, 2)
        if all(
            ((matching >> first) & 1) or ((matching >> second) & 1)
            for matching in states
        )
    )


def cycle_order(subsystem):
    states = tuple(matching for pair in subsystem for matching in pair)
    adjacency = {
        matching: sorted(
            other for other in states if other != matching and matching & other == 0
        )
        for matching in states
    }
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())
    start = min(states)
    order = [start, adjacency[start][0]]
    while len(order) < 10:
        following = next(x for x in adjacency[order[-1]] if x != order[-2])
        assert following not in order
        order.append(following)
    return tuple(order)


def one_cycle(first, second, endpoint_masks, proper_count):
    difference = first ^ second
    assert difference >> proper_count == 0
    adjacency = defaultdict(set)
    remaining = difference
    while remaining:
        low = remaining & -remaining
        edge = low.bit_length() - 1
        endpoints = endpoint_masks[edge]
        vertices = [v for v in range(15) if (endpoints >> v) & 1]
        assert len(vertices) == 2
        u, v = vertices
        adjacency[u].add(v)
        adjacency[v].add(u)
        remaining ^= low
    if not adjacency or any(len(neighbours) != 2 for neighbours in adjacency.values()):
        return False
    seen = set()
    stack = [next(iter(adjacency))]
    while stack:
        vertex = stack.pop()
        if vertex in seen:
            continue
        seen.add(vertex)
        stack.extend(adjacency[vertex] - seen)
    return len(seen) == len(adjacency)


def path_repair(subsystem, classes, endpoint_masks, proper_count, edge_count):
    cycle = cycle_order(subsystem)
    selected = set(cycle)
    for direction in (1, -1):
        for offset, source in enumerate(cycle):
            following = [cycle[(offset + direction * step) % 10] for step in range(1, 5)]
            boundary = (source >> proper_count) & 0b11111
            assert boundary.bit_count() == 1
            position = boundary.bit_length() - 1
            for replacement in classes[position]:
                if replacement in selected:
                    continue
                if not one_cycle(source, replacement, endpoint_masks, proper_count):
                    continue
                if replacement & following[0]:
                    continue
                if replacement & following[1] & following[3]:
                    continue
                chosen = (replacement, *following)
                assert capacity_two(chosen, edge_count)
                return True
    return False


def main():
    helper.check_pole(helper.BASE_N, helper.BASE_PROPER, helper.BASE_SEMI_ENDPOINTS)
    totals = Counter()
    failures = []
    object_count = len(helper.BASE_PROPER) + 5
    for pair in combinations(range(object_count), 2):
        totals["moves"] += 1
        proper, semi = helper.expand(pair)
        helper.check_pole(15, proper, semi)
        matchings = helper.enumerate_matchings(15, proper, semi)
        classes = helper.singleton_classes(matchings, len(proper))
        if helper.tait_states(classes) != helper.TARGET_STATES:
            continue
        totals["exact_S_children"] += 1
        proper_count = len(proper)
        edge_count = proper_count + 5
        endpoint_masks = [((1 << u) | (1 << v)) for u, v in proper]
        endpoint_masks.extend(1 << endpoint for endpoint in semi)
        for subsystem in c10_subsystems(classes):
            totals["c10_subsystems"] += 1
            if internally_good(subsystem, edge_count):
                totals["internally_good_c10"] += 1
                continue
            totals["bad_c10_subsystems"] += 1
            blockers = blocker_pairs(subsystem, proper_count)
            if blockers:
                totals["bad_with_two_edge_blocker"] += 1
            else:
                totals["bad_without_two_edge_blocker"] += 1
            if path_repair(subsystem, classes, endpoint_masks, proper_count, edge_count):
                totals["path_repairs"] += 1
            else:
                totals["path_repair_failures"] += 1
                failures.append(
                    {
                        "move": pair,
                        "proper_edges": proper,
                        "semiedge_endpoints": semi,
                        "blocker_pairs": blockers,
                        "subsystem": subsystem,
                    }
                )
    print({"totals": dict(totals), "first_failure": failures[:1]})


if __name__ == "__main__":
    main()
