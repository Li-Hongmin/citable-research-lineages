#!/usr/bin/env python3
"""Decompose the two extra Tait states of the frozen Note-026 pole.

The script enumerates the complete singleton perfect-matching family of the
17-vertex pole, identifies every disjoint pair producing the forbidden states
02 and 13, and measures each endpoint's alternating-cycle exchange distance
from the two designated matchings in its boundary class.

Only Python's standard library is used.  The scope is this one frozen pole;
no insertion or larger-order search is performed.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
from itertools import product
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
VERIFY = HERE / "agent-proof" / "verify_two_window_counterexample.py"
SPEC = importlib.util.spec_from_file_location("two_window_seed", VERIFY)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {VERIFY}")
seed = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = seed
SPEC.loader.exec_module(seed)


EXTRA_STATES = ((0, 2), (1, 3))


def matching_key(matching: frozenset[tuple[int, int]]):
    return tuple(sorted(matching))


def exchange_components(
    first: frozenset[tuple[int, int]],
    second: frozenset[tuple[int, int]],
) -> tuple[dict[str, object], ...]:
    """Return the even-cycle components of two same-class matchings."""
    difference = first ^ second
    if not difference:
        return ()
    adjacency: dict[int, set[int]] = defaultdict(set)
    for u, v in difference:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())

    unseen = set(adjacency)
    output = []
    while unseen:
        start = min(unseen)
        stack = [start]
        vertices = set()
        while stack:
            vertex = stack.pop()
            if vertex in vertices:
                continue
            vertices.add(vertex)
            unseen.discard(vertex)
            stack.extend(adjacency[vertex] - vertices)
        edges = frozenset(
            edge for edge in difference if set(edge) <= vertices
        )
        assert len(edges) % 2 == 0
        assert first ^ edges != first
        output.append(
            {
                "vertices": tuple(sorted(vertices)),
                "edges": tuple(sorted(edges)),
                "length": len(edges),
                "removed": tuple(sorted(first & edges)),
                "added": tuple(sorted(second & edges)),
            }
        )
    return tuple(sorted(output, key=lambda item: item["vertices"]))


def exchange_descriptor(source, target):
    components = exchange_components(source, target)
    return {
        "component_count": len(components),
        "total_cycle_length": sum(item["length"] for item in components),
        "maximum_cycle_length": max(
            (item["length"] for item in components), default=0
        ),
        "components": components,
    }


def best_designated_source(
    matching: frozenset[tuple[int, int]],
    boundary_class: int,
    designated: tuple[frozenset[tuple[int, int]], ...],
):
    candidates = []
    for state in (boundary_class, boundary_class + 5):
        descriptor = exchange_descriptor(designated[state], matching)
        candidates.append(
            (
                descriptor["component_count"],
                descriptor["total_cycle_length"],
                state,
                descriptor,
            )
        )
    _, _, state, descriptor = min(candidates, key=lambda item: item[:3])
    return state, descriptor


def matching_record(
    matching: frozenset[tuple[int, int]],
    boundary_class: int,
    class_index: dict[frozenset[tuple[int, int]], tuple[int, int]],
    designated: tuple[frozenset[tuple[int, int]], ...],
):
    source, exchange = best_designated_source(matching, boundary_class, designated)
    designated_states = [state for state, item in enumerate(designated) if item == matching]
    return {
        "id": f"P{boundary_class}.{class_index[matching][1]}",
        "boundary_class": boundary_class,
        "designated_states": designated_states,
        "edges": sorted(matching),
        "nearest_designated_source": f"N{source}",
        "exchange": exchange,
    }


def full_matching(
    proper_matching: frozenset[tuple[int, int]], boundary_class: int
) -> frozenset[tuple[int, ...]]:
    return frozenset(set(proper_matching) | {(boundary_class,)})


def full_edge_endpoints(edge: tuple[int, ...]) -> tuple[object, object]:
    if len(edge) == 2:
        return edge
    position = edge[0]
    return (position, ("boundary", position))


def two_colour_components(
    first: frozenset[tuple[int, ...]],
    second: frozenset[tuple[int, ...]],
) -> tuple[frozenset[tuple[int, ...]], ...]:
    union = first | second
    adjacency: dict[object, set[object]] = defaultdict(set)
    for edge in union:
        u, v = full_edge_endpoints(edge)
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(adjacency)
    output = []
    while unseen:
        start = min(unseen, key=repr)
        stack = [start]
        vertices = set()
        while stack:
            vertex = stack.pop()
            if vertex in vertices:
                continue
            vertices.add(vertex)
            unseen.discard(vertex)
            stack.extend(adjacency[vertex] - vertices)
        component_edges = frozenset(
            edge
            for edge in union
            if set(full_edge_endpoints(edge)) <= vertices
        )
        output.append(component_edges)
    return tuple(sorted(output, key=lambda item: tuple(sorted(map(repr, item)))))


def boundary_class_of_full_matching(matching: frozenset[tuple[int, ...]]):
    semiedges = [edge[0] for edge in matching if len(edge) == 1]
    return semiedges[0] if len(semiedges) == 1 else None


def kempe_path_records(
    designated: tuple[frozenset[tuple[int, int]], ...],
    singleton: tuple[tuple[frozenset[tuple[int, int]], ...], ...],
    class_index: dict[frozenset[tuple[int, int]], tuple[int, int]],
):
    """One-component Kempe switches from the ten designated Tait colourings."""
    all_objects: frozenset[tuple[int, ...]] = frozenset(
        set(seed.EDGE_SUPPORTS) | {(position,) for position in range(5)}
    )
    records = []
    seen = set()
    for state in range(10):
        following = (state + 1) % 10
        first = full_matching(designated[state], state % 5)
        second = full_matching(designated[following], following % 5)
        assert first.isdisjoint(second)
        third = all_objects - first - second
        colours = (first, second, third)
        for left_colour in range(3):
            for right_colour in range(left_colour + 1, 3):
                for component in two_colour_components(
                    colours[left_colour], colours[right_colour]
                ):
                    switched = list(colours)
                    switched[left_colour] = colours[left_colour] ^ component
                    switched[right_colour] = colours[right_colour] ^ component
                    assert set().union(*switched) == set(all_objects)
                    assert sum(map(len, switched)) == len(all_objects)

                    singleton_colours = []
                    for colour, matching in enumerate(switched):
                        position = boundary_class_of_full_matching(matching)
                        if position is None:
                            continue
                        proper = frozenset(edge for edge in matching if len(edge) == 2)
                        assert proper in singleton[position]
                        singleton_colours.append(
                            (position, f"P{position}.{class_index[proper][1]}")
                        )
                    if len(singleton_colours) != 2:
                        continue
                    boundary_state = tuple(sorted(position for position, _ in singleton_colours))
                    if boundary_state not in EXTRA_STATES:
                        continue

                    component_boundary = sorted(
                        edge[0] for edge in component if len(edge) == 1
                    )
                    key = (
                        state,
                        following,
                        left_colour,
                        right_colour,
                        tuple(sorted(map(repr, component))),
                        tuple(sorted(singleton_colours)),
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    records.append(
                        {
                            "from_designated_pair": [f"N{state}", f"N{following}"],
                            "switched_colour_pair": [left_colour, right_colour],
                            "component_edge_count": len(component),
                            "component_boundary_positions": component_boundary,
                            "component_proper_edges": sorted(
                                edge for edge in component if len(edge) == 2
                            ),
                            "extra_state": list(boundary_state),
                            "resulting_singleton_matchings": [
                                matching_id for _, matching_id in sorted(singleton_colours)
                            ],
                        }
                    )
    return tuple(
        sorted(
            records,
            key=lambda record: (
                record["extra_state"],
                record["component_edge_count"],
                record["from_designated_pair"],
            ),
        )
    )


def main() -> None:
    proper_edges = set(seed.EDGE_SUPPORTS)
    graph = seed.adjacency(proper_edges)
    singleton = tuple(
        tuple(sorted(seed.enumerate_singleton_matchings(graph, position), key=matching_key))
        for position in range(5)
    )
    designated = tuple(frozenset(seed.matching(state)) for state in range(10))
    assert tuple(len(group) for group in singleton) == (8, 8, 6, 7, 4)
    assert all(designated[state] in singleton[state % 5] for state in range(10))

    class_index = {
        matching: (position, index)
        for position, group in enumerate(singleton)
        for index, matching in enumerate(group)
    }

    summaries = []
    all_best_witnesses = []
    compact_all_pairs = []
    for left, right in EXTRA_STATES:
        pairs = tuple(
            (first, second)
            for first in singleton[left]
            for second in singleton[right]
            if first.isdisjoint(second)
        )
        assert pairs

        ranked = []
        endpoint_distance_profiles = Counter()
        for first, second in pairs:
            left_source, left_exchange = best_designated_source(
                first, left, designated
            )
            right_source, right_exchange = best_designated_source(
                second, right, designated
            )
            distances = (
                left_exchange["component_count"],
                right_exchange["component_count"],
            )
            endpoint_distance_profiles[tuple(sorted(distances))] += 1
            outside_count = sum(
                matching not in designated for matching in (first, second)
            )
            rank = (
                outside_count,
                sum(distances),
                max(distances),
                left_exchange["total_cycle_length"]
                + right_exchange["total_cycle_length"],
                matching_key(first),
                matching_key(second),
            )
            ranked.append(
                (
                    rank,
                    first,
                    second,
                    left_source,
                    left_exchange,
                    right_source,
                    right_exchange,
                )
            )
            compact_all_pairs.append(
                {
                    "extra_state": [left, right],
                    "left_id": f"P{left}.{class_index[first][1]}",
                    "left_source": f"N{left_source}",
                    "left_cycle_lengths": [
                        component["length"]
                        for component in left_exchange["components"]
                    ],
                    "right_id": f"P{right}.{class_index[second][1]}",
                    "right_source": f"N{right_source}",
                    "right_cycle_lengths": [
                        component["length"]
                        for component in right_exchange["components"]
                    ],
                }
            )
        ranked.sort(key=lambda item: item[0])
        best_rank = ranked[0][0][:4]
        best = [item for item in ranked if item[0][:4] == best_rank]

        witness_records = []
        for item in best:
            _, first, second, *_ = item
            witness_records.append(
                {
                    "left": matching_record(
                        first, left, class_index, designated
                    ),
                    "right": matching_record(
                        second, right, class_index, designated
                    ),
                }
            )
        all_best_witnesses.extend(
            {"extra_state": [left, right], **record} for record in witness_records
        )
        summaries.append(
            {
                "extra_state": [left, right],
                "disjoint_pair_count": len(pairs),
                "pairs_with_designated_endpoint": sum(
                    first in designated or second in designated
                    for first, second in pairs
                ),
                "pairs_with_both_endpoints_new": sum(
                    first not in designated and second not in designated
                    for first, second in pairs
                ),
                "endpoint_exchange_distance_profile": {
                    str(key): value
                    for key, value in sorted(endpoint_distance_profiles.items())
                },
                "best_rank": {
                    "new_matching_endpoints": best_rank[0],
                    "total_cycle_components": best_rank[1],
                    "maximum_endpoint_components": best_rank[2],
                    "total_symmetric_difference_edges": best_rank[3],
                },
                "number_of_best_witnesses": len(best),
            }
        )

    # The designated antipodal pairs expose the Boolean-cycle closure that
    # is visible before considering the extra disjoint pairs.
    antipodal = []
    boolean_closure = []
    for position in range(5):
        components = exchange_components(
            designated[position], designated[position + 5]
        )
        generated = set()
        for bits in product((0, 1), repeat=len(components)):
            matching = designated[position]
            for bit, component in zip(bits, components):
                if bit:
                    matching = matching ^ frozenset(component["edges"])
            assert matching in singleton[position]
            generated.add(matching)
        # The generated Boolean cube is closed under flipping any subset of
        # the symmetric-difference components of any two of its members.
        for first in generated:
            for second in generated:
                pair_components = exchange_components(first, second)
                for bits in product((0, 1), repeat=len(pair_components)):
                    matching = first
                    for bit, component in zip(bits, pair_components):
                        if bit:
                            matching = matching ^ frozenset(component["edges"])
                    assert matching in generated
        boolean_closure.append(frozenset(generated))
        antipodal.append(
            {
                "boundary_class": position,
                "designated_pair": [f"N{position}", f"N{position + 5}"],
                "component_count": len(components),
                "components": components,
                "Boolean_cube_size": len(generated),
                "full_singleton_class_size": len(singleton[position]),
            }
        )

    boolean_states = frozenset(
        (left, right)
        for left in range(5)
        for right in range(left + 1, 5)
        if any(
            first.isdisjoint(second)
            for first in boolean_closure[left]
            for second in boolean_closure[right]
        )
    )
    target_states = frozenset({(0, 1), (0, 4), (1, 2), (2, 3), (3, 4)})
    assert boolean_states == target_states

    relation_sizes = {
        f"{left}{right}": sum(
            first.isdisjoint(second)
            for first in boolean_closure[left]
            for second in boolean_closure[right]
        )
        for left, right in sorted(boolean_states)
    }

    kempe_records = kempe_path_records(designated, singleton, class_index)
    kempe_summary = []
    for extra_state in EXTRA_STATES:
        retained = [
            record for record in kempe_records
            if tuple(record["extra_state"]) == extra_state
        ]
        minimum = min(
            (record["component_edge_count"] for record in retained),
            default=None,
        )
        kempe_summary.append(
            {
                "extra_state": list(extra_state),
                "one_component_switch_count": len(retained),
                "minimum_component_edge_count": minimum,
                "minimum_switches": [
                    record
                    for record in retained
                    if minimum is not None
                    and record["component_edge_count"] == minimum
                ],
            }
        )

    output = {
        "singleton_class_sizes": [len(group) for group in singleton],
        "extra_state_summaries": summaries,
        "all_extra_pair_exchange_routes": compact_all_pairs,
        "best_witnesses": all_best_witnesses,
        "designated_antipodal_exchange_decompositions": antipodal,
        "pair_component_Boolean_closure_boundary": {
            "class_sizes": [len(group) for group in boolean_closure],
            "closed_under_all_component_subflips_between_its_members": True,
            "Tait_states": sorted(map(list, boolean_states)),
            "relation_sizes": relation_sizes,
            "has_extra_02_or_13": bool(
                {(0, 2), (1, 3)} & boolean_states
            ),
            "scope_warning": (
                "This is an abstract pair-generated exchange-closed subfamily, "
                "not the complete perfect-matching family of the pole.  The "
                "actual extra partners arise from additional alternating "
                "cycles not forced by the antipodal component cubes."
            ),
        },
        "one_component_Kempe_paths_from_designated_Tait_colourings": kempe_summary,
    }
    print(json.dumps(output, ensure_ascii=False, indent=2, sort_keys=True))
    print("TWO_WINDOW_EXTRA_STATE_EXCHANGES_OK")


if __name__ == "__main__":
    main()
