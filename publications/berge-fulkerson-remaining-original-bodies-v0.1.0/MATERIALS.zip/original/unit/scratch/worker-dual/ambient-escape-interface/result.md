# Ambient-escape interface: the exact saturation boundary

## Saturation lemma

Let \(H\) be a finite cubic 5-pole and let \(\mathcal M_i\) be the complete
class of perfect matchings whose boundary set is the singleton \(\{i\}\).
Fix \(P\in\mathcal M_i\).  Form the exchange graph on \(\mathcal M_i\) by
joining \(R\) to \(R\mathbin\triangle C\) for every ambient
\(R\)-alternating cycle \(C\) of \(H\).  Then this exchange graph is
connected.  Equivalently, the closure of any one member of \(\mathcal M_i\)
under all ambient alternating-cycle flips is the whole class
\(\mathcal M_i\).

Indeed, for any \(Q\in\mathcal M_i\), the common boundary semiedge cancels
from \(P\mathbin\triangle Q\).  Every internal vertex has degree zero or two
in this symmetric difference.  Hence it is a disjoint union of even cycles,
alternating between \(P\) and \(Q\).  Flipping these components one at a
time gives a path from \(P\) to \(Q\).

## Consequence for the proposed interface

If nonempty families \(\mathcal B_i\subseteq\mathcal M_i\) are closed under
**every** ambient alternating-cycle flip of the one common pole, then

\[
\mathcal B_i=\mathcal M_i\qquad(i=0,\ldots,4).
\]

Therefore a purported countermodel with

\[
T(\mathcal B)=S,
\]

two blocked \(Y\)-windows, and complete ambient closure is already a full
exact-\(S\) pole with those blocked windows.  It is not an intermediate
local exchange model: it is precisely a counterexample to the unresolved
full-closure implication.

Conversely, if a pair-component Boolean cube
\(\mathcal B_i\) is a proper subset of \(\mathcal M_i\), at least one member
of \(\mathcal B_i\) has an ambient alternating-cycle flip leaving the cube.
This forces an escape **from the cube**, but it does not force that the new
matching be disjoint from a nonadjacent boundary class.  That latter
cross-class conclusion is the unresolved content.

For the frozen Note-026 pole, the proper inclusions

\[
(4,4,2,2,2)<(8,8,6,7,4)
\]

therefore already force ambient exits.  The recorded cycles \(D_{02}\) and
\(D_{13}\) are concrete exits which, together with the common \(C_4\), also
happen to create the non-\(S\) pairs \(02\) and \(13\).  The saturation lemma
does not make that second fact universal.

## Frozen decision

This leaf did not prove

\[
\text{two same-parity blocked windows}+\text{full exact-}S
\Longrightarrow\bot,
\]

and it did not produce a counterexample to it.  A formal exchange system
that declares only selected cycles can avoid the two escapes, but then it
violates the common-graph saturation premise above.  Thus it is not a strict
countermodel requested here.

The exact missing coupling is between:

1. the endpoint transitions that put the blocker edge on both forced paths;
2. the global edge gluing that determines every ambient alternating cycle;
3. cross-class disjointness after those cycle flips.

Local cubic choices and within-class closure considered separately do not
identify that coupling.  The decision is therefore unchanged: the general
full-closure implication remains open, and further abstract exchange-graph
engineering would not distinguish it.
