#!/usr/bin/env python3
"""Independent certificate for a two-forced-path counterexample.

The five boundary semiedges are attached at vertices 0,...,4.  A proper
edge is listed together with the designated perfect matchings N_k that use
it.  Matching N_k additionally uses the boundary semiedge at k mod 5.

Only Python's standard library is used.  The verifier checks the exact
hypotheses in the delegated two-window statement and prints the boundary
path decomposition of H-N_1 and H-N_3.
"""

from __future__ import annotations

from collections import defaultdict, deque


N = 17
TERMINALS = frozenset(range(5))
A = (5, 6)
B = (5, 7)

# This is a simple connected proper graph.  Supports not shown are empty.
EDGE_SUPPORTS = {
    (0, 4): (1, 3, 6, 8),
    (0, 12): (2, 4, 7, 9),
    (1, 2): (0, 3, 5, 8),
    (1, 15): (2, 4, 7, 9),
    (2, 9): (1, 4, 6, 9),
    (3, 13): (1, 5, 7, 9),
    (3, 16): (0, 2, 4, 6),
    (4, 9): (0, 2, 5, 7),
    (5, 6): (0, 2, 4, 6, 8),
    (5, 7): (1, 3, 5, 7, 9),
    (5, 14): (),
    (6, 7): (),
    (6, 14): (1, 3, 5, 7, 9),
    (7, 8): (0, 2, 4, 6, 8),
    (8, 12): (1, 5),
    (8, 16): (3, 7, 9),
    (9, 13): (3, 8),
    (10, 11): (3, 7, 9),
    (10, 13): (0, 2, 4, 6),
    (10, 16): (1, 5, 8),
    (11, 14): (0, 2, 4, 6, 8),
    (11, 15): (1, 5),
    (12, 15): (0, 3, 6, 8),
}


def adjacency(edges: set[tuple[int, int]]) -> dict[int, set[int]]:
    result = {vertex: set() for vertex in range(N)}
    for u, v in edges:
        result[u].add(v)
        result[v].add(u)
    return result


def components(edges: set[tuple[int, int]]) -> list[set[int]]:
    graph = adjacency(edges)
    unseen = set(range(N))
    answer = []
    while unseen:
        start = min(unseen)
        component = {start}
        queue = deque([start])
        unseen.remove(start)
        while queue:
            u = queue.popleft()
            for v in graph[u]:
                if v in unseen:
                    unseen.remove(v)
                    component.add(v)
                    queue.append(v)
        answer.append(component)
    return answer


def matching(state: int) -> set[tuple[int, int]]:
    return {edge for edge, support in EDGE_SUPPORTS.items() if state in support}


def path_between(
    graph: dict[int, set[int]], source: int, target: int
) -> list[int]:
    parent = {source: None}
    queue = deque([source])
    while queue and target not in parent:
        u = queue.popleft()
        for v in graph[u]:
            if v not in parent:
                parent[v] = u
                queue.append(v)
    assert target in parent
    answer = []
    current = target
    while current is not None:
        answer.append(current)
        current = parent[current]
    return list(reversed(answer))


def enumerate_singleton_matchings(
    graph: dict[int, set[int]], boundary_position: int
) -> list[frozenset[tuple[int, int]]]:
    """Enumerate proper parts after fixing the one used semiedge."""
    answer = []

    def recurse(
        uncovered: frozenset[int], chosen: tuple[tuple[int, int], ...]
    ) -> None:
        if not uncovered:
            answer.append(frozenset(chosen))
            return
        vertex = min(uncovered, key=lambda u: len(graph[u] & uncovered))
        for other in sorted(graph[vertex] & uncovered):
            edge = tuple(sorted((vertex, other)))
            recurse(uncovered - {vertex, other}, chosen + (edge,))

    recurse(frozenset(range(N)) - {boundary_position}, ())
    return answer


def boundary_paths_after_removing(state: int) -> dict[tuple[int, int], list[int]]:
    remaining = set(EDGE_SUPPORTS) - matching(state)
    graph = adjacency(remaining)
    exposed = TERMINALS - {state % 5}
    result = {}
    for component in components(remaining):
        endpoints = sorted(component & exposed)
        if endpoints:
            assert len(endpoints) == 2
            pair = tuple(endpoints)
            result[pair] = path_between(graph, *pair)
    return result


def verify() -> None:
    proper_edges = set(EDGE_SUPPORTS)
    assert all(0 <= u < v < N for u, v in proper_edges)
    assert len(proper_edges) == len(EDGE_SUPPORTS)

    graph = adjacency(proper_edges)
    assert {vertex: len(neighbours) for vertex, neighbours in graph.items()} == {
        vertex: (2 if vertex in TERMINALS else 3) for vertex in range(N)
    }
    assert len(components(proper_edges)) == 1

    # Each N_k plus its one boundary semiedge covers every internal vertex
    # exactly once.
    matchings = []
    for state in range(10):
        proper = matching(state)
        incidence = defaultdict(int)
        for u, v in proper:
            incidence[u] += 1
            incidence[v] += 1
        incidence[state % 5] += 1  # the unique boundary semiedge
        assert [incidence[v] for v in range(N)] == [1] * N
        matchings.append(proper)

    for state in range(10):
        next_state = (state + 1) % 10
        assert matchings[state].isdisjoint(matchings[next_state])
        assert state % 5 != next_state % 5  # boundary semiedges also differ

    # In fact the ten designated matchings induce exactly C10: every other
    # pair intersects in a proper edge, except that antipodal states share
    # their boundary semiedge.
    for first in range(10):
        for second in range(first + 1, 10):
            share = bool(matchings[first] & matchings[second]) or (
                first % 5 == second % 5
            )
            cyclic_distance = (second - first) % 10
            assert (not share) == (cyclic_distance in (1, 9))

    assert all(A in matchings[state] for state in range(0, 10, 2))
    assert all(A not in matchings[state] for state in range(1, 10, 2))
    assert all(B in matchings[state] for state in range(1, 10, 2))
    assert all(B not in matchings[state] for state in range(0, 10, 2))

    paths_0 = boundary_paths_after_removing(1)
    paths_2 = boundary_paths_after_removing(3)
    assert set(paths_0) == {(0, 2), (3, 4)}
    assert set(paths_2) == {(0, 1), (2, 4)}
    assert A in {
        tuple(sorted(edge))
        for edge in zip(paths_0[(3, 4)], paths_0[(3, 4)][1:])
    }
    assert A in {
        tuple(sorted(edge))
        for edge in zip(paths_2[(0, 1)], paths_2[(0, 1)][1:])
    }

    print("vertices=17 proper_edges=23 connected=True simple=True")
    print("ten_singleton_boundary_perfect_matchings=True")
    print("consecutive_pairs_disjoint=True")
    print(f"a={A} common_even=True b={B} common_odd=True adjacent=True")
    print(f"H-N1 boundary_paths={paths_0}")
    print(f"H-N3 boundary_paths={paths_2}")
    print("a_in_Y0=True a_in_Y2=True")

    # This marks the exact scope: the full singleton-matching closure has
    # extra disjoint boundary-class pairs, so the example is not an exact-S
    # pole even though its ten designated states induce exactly C10.
    singleton = [enumerate_singleton_matchings(graph, i) for i in range(5)]
    tait_pairs = [
        (i, j)
        for i in range(5)
        for j in range(i + 1, 5)
        if any(p.isdisjoint(q) for p in singleton[i] for q in singleton[j])
    ]
    assert [len(layer) for layer in singleton] == [8, 8, 6, 7, 4]
    assert tait_pairs == [(0, 1), (0, 2), (0, 4), (1, 2), (1, 3), (2, 3), (3, 4)]
    print("designated_disjointness_graph=exact_C10")
    print(f"full_singleton_counts={[len(layer) for layer in singleton]}")
    print(f"full_Tait_boundary_pairs={tait_pairs} exact_S=False")
    print("TWO_WINDOW_COUNTEREXAMPLE_VERIFIED")


if __name__ == "__main__":
    verify()
