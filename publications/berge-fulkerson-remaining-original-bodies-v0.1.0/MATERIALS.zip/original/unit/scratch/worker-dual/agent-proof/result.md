# Two same-parity forced-path obstructions can coexist

## Exact conclusion

The proposed two-window lemma is false under the delegated hypotheses.
There is a simple connected cubic 5-pole with ten singleton-boundary perfect
matchings $N_0,\ldots,N_9$, consecutive pairs disjoint, and proper edges

\[
a\in\bigcap_{i\text{ even}}N_i,
\qquad
b\in\bigcap_{i\text{ odd}}N_i,
\]

for which simultaneously

\[
a\in Y_0(H-N_1)
\quad\hbox{and}\quad
a\in Y_2(H-N_3).
\]

Thus neither vertex matching incidence, consecutive disjointness, the two
common blocker edges, nor even exact $C_{10}$ disjointness of the ten
*designated* matchings can prove that two same-parity windows are impossible.

## Explicit 17-vertex counterexample

The internal vertices are $0,1,\ldots,16$.  Boundary semiedge $s_i$ is
incident with vertex $i$, for $0\le i<5$.  In the table, the right column
is the support of a proper edge: state $k$ uses that edge precisely when
$k$ occurs in the column.  State $N_k$ also uses the unique semiedge
$s_{k\bmod 5}$.

| proper edge | support |
|---|---|
| 0--4 | 1,3,6,8 |
| 0--12 | 2,4,7,9 |
| 1--2 | 0,3,5,8 |
| 1--15 | 2,4,7,9 |
| 2--9 | 1,4,6,9 |
| 3--13 | 1,5,7,9 |
| 3--16 | 0,2,4,6 |
| 4--9 | 0,2,5,7 |
| 5--6 | 0,2,4,6,8 |
| 5--7 | 1,3,5,7,9 |
| 5--14 | empty |
| 6--7 | empty |
| 6--14 | 1,3,5,7,9 |
| 7--8 | 0,2,4,6,8 |
| 8--12 | 1,5 |
| 8--16 | 3,7,9 |
| 9--13 | 3,8 |
| 10--11 | 3,7,9 |
| 10--13 | 0,2,4,6 |
| 10--16 | 1,5,8 |
| 11--14 | 0,2,4,6,8 |
| 11--15 | 1,5 |
| 12--15 | 0,3,6,8 |

The five terminal vertices have proper degree two and the other twelve vertices have
proper degree three.  The proper graph is simple and connected.  Direct
incidence counting shows that every $N_k\cup\{s_{k\bmod5}\}$ covers every
internal vertex exactly once.  Every proper-edge support is an independent
set of $C_{10}$, and consecutive states use different semiedges, so
$N_k\cap N_{k+1}=\varnothing$, including $N_9\cap N_0=\varnothing$.

Take

\[
a=\{5,6\},
\qquad b=\{5,7\}.
\]

Their supports are respectively all five even and all five odd states.
They are adjacent proper edges; hence this also covers the geometrically
more restrictive adjacent-blocker case.

## The two forced paths

Deleting $N_1$ gives the two boundary paths

\[
X_0:0-12-15-1-2,
\]

and

\[
Y_0:3-16-8-7-6-5-14-11-10-13-9-4.
\]

The first has boundary endpoints $0,2$, as required for $X_0$; the
second has the remaining endpoints $3,4$.  Edge $a=\{5,6\}$ lies on
$Y_0$.

Deleting $N_3$ gives

\[
Y_2:0-12-8-7-6-5-14-11-15-1
\]

and

\[
X_2:2-9-4.
\]

Again $a=\{5,6\}$ lies on $Y_2$.  Since

\[
a\in N_0\cap N_2\cap N_4
\quad\hbox{and}\quad
a\in N_2\cap N_4\cap N_6,
\]

both $T_0\cap Y_0$ and $T_2\cap Y_2$ are nonempty.

In fact, among these ten designated matchings two states are disjoint if and
only if they are consecutive in $C_{10}$.  Thus adding nonconsecutive-pair
coverage for the designated system does not rescue the lemma.

## Weakest bearing point and remaining quantifier

This pole is **not** an exact-$S$ pole after closing under *all* singleton
perfect matchings.  The five boundary classes contain respectively

\[
8,8,6,7,4
\]

singleton matchings, and their full disjoint boundary-pair set is

\[
\{01,02,04,12,13,23,34\}.
\]

Therefore the counterexample settles exactly the delegated universal
statement, but it does not settle the stronger statement quantified only
over poles whose **complete matching closure** has exact state set $S$.
That closure condition is now the weakest missing premise: any valid
forced-path theorem must use it (or a consequence of it), rather than only
the ten selected matching vectors and their common blocker edges.

The independent standard-library verifier is
`verify_two_window_counterexample.py`; run

```bash
python3 units/berge-fulkerson/scratch/worker-dual/agent-proof/verify_two_window_counterexample.py
```

It checks graph degrees and connectivity, all ten perfect-matching equations,
the exact designated $C_{10}$, both blocker supports, both path
decompositions, and the full singleton closure quoted above.
