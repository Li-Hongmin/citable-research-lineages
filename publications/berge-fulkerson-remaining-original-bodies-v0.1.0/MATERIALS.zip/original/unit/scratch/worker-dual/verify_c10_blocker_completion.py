#!/usr/bin/env python3
"""Verify a cubic completion of the abstract a/b C10 capacity blocker.

The completion proves a negative diagnostic: vertex equations and odd-cut
inequalities do not exclude the ten-state blocker.  The completed pole has
additional singleton-boundary perfect matchings, and those additional states
restore a capacity-two transversal.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
from itertools import combinations, product
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
SHARED = HERE.parent


def load_base():
    path = SHARED / "case_xii_n13_c10_target.py"
    spec = importlib.util.spec_from_file_location("worker_dual_base", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


base = load_base()
legacy = base.legacy

# Solver-layer t is sent to Case-XII boundary position v_t.
PENTAGON_ORDER = (1, 4, 2, 5, 3)
RELABEL = {t: PENTAGON_ORDER[t] - 1 for t in range(5)}
RELABEL.update({v: v for v in range(5, 13)})

# Proper edges and their supports among the ten designated matching states,
# before boundary relabelling.
SUPPORTED_OLD = (
    ((0, 1), (2, 4, 7, 9)),
    ((0, 4), (1, 3, 6, 8)),
    ((1, 2), (0, 3, 5, 8)),
    ((2, 3), (1, 4, 6, 9)),
    ((3, 8), (0, 2, 5, 7)),
    ((4, 12), (0, 2, 5, 7)),
    ((5, 6), (1, 3, 5, 7, 9)),
    ((5, 9), (0, 2, 4, 6, 8)),
    ((5, 10), ()),
    ((6, 7), (0, 2, 4, 6, 8)),
    ((6, 9), ()),
    ((7, 8), (3, 9)),
    ((7, 11), (1, 5, 7)),
    ((8, 12), (1, 4, 6, 8)),
    ((9, 10), (1, 3, 5, 7, 9)),
    ((10, 11), (0, 2, 4, 6, 8)),
    ((11, 12), (3, 9)),
)


def relabel_edge(edge):
    u, v = edge
    return tuple(sorted((RELABEL[u], RELABEL[v])))


SUPPORTED = tuple((relabel_edge(edge), support) for edge, support in SUPPORTED_OLD)
PROPER_EDGES = tuple(sorted(edge for edge, _ in SUPPORTED))


def capacity_witness(singleton):
    positions = sorted(singleton, key=lambda i: len(singleton[i]))
    selected = []
    multiplicity = Counter()

    def search(index):
        if index == len(positions):
            return tuple(selected)
        position = positions[index]
        for matching in singleton[position]:
            if any(multiplicity[e] >= 2 for e in matching):
                continue
            selected.append((position, matching))
            multiplicity.update(matching)
            witness = search(index + 1)
            if witness is not None:
                return witness
            multiplicity.subtract(matching)
            selected.pop()
        return None

    return search(0)


def main():
    pole = legacy.Pole(n=13, proper_edges=PROPER_EDGES)
    assert len(set(PROPER_EDGES)) == len(PROPER_EDGES)
    proper_adjacency = {vertex: set() for vertex in range(13)}
    for u, v in PROPER_EDGES:
        proper_adjacency[u].add(v)
        proper_adjacency[v].add(u)
    assert all(
        len(proper_adjacency[vertex]) + (vertex < 5) == 3
        for vertex in range(13)
    )
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in proper_adjacency[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    assert len(seen) == 13
    matchings, edge_vertices, edge_position, incidence = legacy.enumerate_perfect_matchings(pole)
    edge_id = {edge: f"e{i}" for i, edge in enumerate(PROPER_EDGES)}

    designated = []
    for k in range(10):
        layer = k % 5
        matching = frozenset(
            [edge_id[edge] for edge, support in SUPPORTED if k in support]
            + [f"s{PENTAGON_ORDER[layer]}"]
        )
        assert matching in matchings
        designated.append(matching)

    expected_cycle = {
        frozenset((k, (k + 1) % 10)) for k in range(10)
    }
    actual_disjoint = {
        frozenset((i, j))
        for i, j in combinations(range(10), 2)
        if designated[i].isdisjoint(designated[j])
    }
    assert actual_disjoint == expected_cycle

    # All 32 transversals of only the designated two-per-layer subsystem fail.
    good_designated = []
    for bits in product((0, 1), repeat=5):
        chosen = [designated[layer + 5 * bits[layer]] for layer in range(5)]
        maximum = max(Counter(edge for matching in chosen for edge in matching).values())
        if maximum <= 2:
            good_designated.append(bits)
    assert not good_designated

    # Each designated vector is a perfect matching of the 14-vertex augmented
    # graph.  Exhaustively check all odd-set inequalities x(delta(U)) >= 1.
    apex = 13
    graph_edges = list(PROPER_EDGES) + [(position - 1, apex) for position in range(1, 6)]
    min_odd_cut = 100
    for matching in designated:
        chosen_edges = {
            PROPER_EDGES[int(edge[1:])]
            if edge.startswith("e")
            else (int(edge[1:]) - 1, apex)
            for edge in matching
        }
        for mask in range(1, 1 << 14):
            if mask.bit_count() % 2 == 0:
                continue
            crossing = sum(((mask >> u) & 1) != ((mask >> v) & 1) for u, v in chosen_edges)
            assert crossing >= 1
            min_odd_cut = min(min_odd_cut, crossing)

    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)

    tait_states = legacy.enumerate_tait_states(pole)
    assert tait_states == legacy.S_DIAGONALS
    _, _, relations = base.relation_data(pole)
    full_witness = capacity_witness(singleton)
    assert full_witness is not None

    designated_set = set(designated)
    output = {
        "proper_edges": PROPER_EDGES,
        "simple_connected_cubic": True,
        "designated_matching_count": len(designated),
        "designated_disjointness_graph": "C10",
        "designated_capacity_two_transversals": 0,
        "minimum_designated_odd_cut_value": min_odd_cut,
        "all_designated_odd_cut_inequalities_hold": True,
        "all_perfect_matchings": len(matchings),
        "singleton_class_sizes_1_to_5": [len(singleton[i]) for i in range(1, 6)],
        "tait_states": sorted(tait_states),
        "relation_sizes_14_42_25_53_31": [len(relation) for relation in relations],
        "full_compatible_pentagons": base.compatible_pentagon_count(relations),
        "full_capacity_two_witness_uses_extra_states": any(
            matching not in designated_set for _, matching in full_witness
        ),
        "full_capacity_two_witness": [
            (position, sorted(matching)) for position, matching in full_witness
        ],
    }
    print(output)


if __name__ == "__main__":
    main()
