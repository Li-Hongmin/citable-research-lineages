# Frozen Note-026 extra-state exchange decomposition

This is a finite observation about the single frozen 17-vertex pole of
Note 026.  It is not a general closure lemma.

## Complete singleton closure and extra pairs

The five singleton perfect-matching class sizes are

\[
(8,8,6,7,4).
\]

Their complete disjoint boundary-pair support is

\[
\{01,02,04,12,13,23,34\}.
\]

The two non-cycle states have exactly the following realizations:

\[
02:\quad P^0_0\perp P^2_0,\quad P^0_0\perp P^2_1,
\]

\[
13:\quad P^1_0\perp P^3_5,\quad P^1_0\perp P^3_6.
\]

There are no other disjoint pairs in either state.  All six participating
matchings are non-designated.  Their proper edge sets are:

| matching | proper edges |
|---|---|
| \(P^0_0\) | (1,2), (3,13), (4,9), (5,6), (7,8), (10,16), (11,14), (12,15) |
| \(P^2_0\) | (0,4), (1,15), (3,16), (5,7), (6,14), (8,12), (9,13), (10,11) |
| \(P^2_1\) | (0,4), (1,15), (3,16), (5,14), (6,7), (8,12), (9,13), (10,11) |
| \(P^1_0\) | (0,4), (2,9), (3,13), (5,6), (7,8), (10,16), (11,14), (12,15) |
| \(P^3_5\) | (0,12), (1,2), (4,9), (5,7), (6,14), (8,16), (10,13), (11,15) |
| \(P^3_6\) | (0,12), (1,2), (4,9), (5,14), (6,7), (8,16), (10,13), (11,15) |

## All designated-source decompositions

For each participating new matching, the symmetric difference with both
designated matchings in the same boundary class is as follows.  A displayed
vertex sequence is cyclic, so its last vertex rejoins its first.

| target | source | components | total edges | alternating cycles |
|---|---:|---:|---:|---|
| \(P^0_0\) | \(N_0\) | 1 | 4 | 3-13-10-16 |
| \(P^0_0\) | \(N_5\) | 1 | 8 | 5-6-14-11-15-12-8-7 |
| \(P^1_0\) | \(N_1\) | 1 | 8 | 5-6-14-11-15-12-8-7 |
| \(P^1_0\) | \(N_6\) | 1 | 4 | 3-13-10-16 |
| \(P^2_0\) | \(N_2\) | 1 | 12 | 0-4-9-13-10-11-14-6-5-7-8-12 |
| \(P^2_0\) | \(N_7\) | 1 | 8 | 0-4-9-13-3-16-8-12 |
| \(P^2_1\) | \(N_2\) | 1 | 12 | 0-4-9-13-10-11-14-5-6-7-8-12 |
| \(P^2_1\) | \(N_7\) | 2 | 12 | 0-4-9-13-3-16-8-12; 5-7-6-14 |
| \(P^3_5\) | \(N_3\) | 1 | 8 | 0-4-9-13-10-11-15-12 |
| \(P^3_5\) | \(N_8\) | 1 | 14 | 0-4-9-13-10-16-8-7-5-6-14-11-15-12 |
| \(P^3_6\) | \(N_3\) | 2 | 12 | 0-4-9-13-10-11-15-12; 5-7-6-14 |
| \(P^3_6\) | \(N_8\) | 1 | 14 | 0-4-9-13-10-16-8-7-6-5-14-11-15-12 |

Thus every one of the six new matchings has a designated source at one
alternating-cycle flip.  The only distinction between "fewest flips" and
"fewest changed edges" occurs for \(P^3_6\): one 14-cycle from \(N_8\), or
two cycles with 12 total edges from \(N_3\).

## Minimum certificates for the two extra states

The minimum certificate for state 02 is

\[
N_0\xrightarrow{C_4}P^0_0,
\qquad
N_7\xrightarrow{C_{02}}P^2_0,
\]

where \(C_4=3-13-10-16-3\) and
\(C_{02}=0-4-9-13-3-16-8-12-0\),

and \(P^0_0\perp P^2_0\).  It uses two cycle components and 12 symmetric-
difference edges in total.  Before the exchanges,
\(N_0\cap N_7=\{(4,9)\}\).

The minimum certificate for state 13 is

\[
N_6\xrightarrow{C_4}P^1_0,
\qquad
N_3\xrightarrow{C_{13}}P^3_5,
\]

where \(C_{13}=0-4-9-13-10-11-15-12-0\),

and \(P^1_0\perp P^3_5\).  It again uses two cycle components and 12
symmetric-difference edges.  Before the exchanges,
\(N_6\cap N_3=\{(0,4),(12,15)\}\).

The common four-cycle removes \((3,16),(10,13)\) from either \(N_0\) or
\(N_6\) and adds \((3,13),(10,16)\).  The second eight-cycle is different
for the two extra states.

Relative to the two blocked paths printed in Note 026, \(C_4\) uses the two
\(Y_0\)-edges \((3,16),(10,13)\) and no \(Y_2\)-edge.  Each of \(C_{02}\)
and \(C_{13}\) uses four \(Y_0\)-edges and two \(Y_2\)-edges, but the actual
edges differ.  None of the three minimum-certificate cycles contains either
blocker \(a=(5,6)\) or \(b=(5,7)\).  Thus the exchanges route around the
blockers; they do not eliminate a blocked window by flipping its blocker.

## Exact boundary of the observation

Every participating new matching intersects every designated matching in
every other boundary class.  Consequently:

\[
\boxed{\text{neither extra state is a one-sided designated replacement}.}
\]

Both sides must be exchanged before disjointness appears.  Hence this sample
does show that full matching closure supplies both forbidden non-cycle
states, and each new matching is individually one cycle away from the
designated family.  It does **not** yield a local proof from a single
neighbour-preserving Kempe flip.  A general two-blocked-window lemma would
still need a theorem forcing two coordinated within-class exchanges (or a
different global exact-\(S\) argument).  The frozen sample alone cannot show
that its two extra states are forced by the double-window interface rather
than by additional global incidence.

The exhaustive verifier is `analyze_extra_state_exchange.py`.  Run from the
project root with

```bash
uv run python units/berge-fulkerson/scratch/worker-dual/extra-state-exchange/analyze_extra_state_exchange.py
```

It terminates with `NOTE026_EXTRA_STATE_EXCHANGE_VERIFIED`.
