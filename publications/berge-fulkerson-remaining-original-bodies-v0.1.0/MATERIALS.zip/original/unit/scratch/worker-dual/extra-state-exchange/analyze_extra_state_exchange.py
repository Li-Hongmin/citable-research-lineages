#!/usr/bin/env python3
"""Exhaust the two extra Tait states of the frozen Note-026 pole.

The authority for the 17-vertex pole and its ten designated matchings is
``../agent-proof/verify_two_window_counterexample.py``.  This program uses
only the Python standard library.  It

* enumerates every singleton-boundary perfect matching in all five classes;
* enumerates every disjoint pair realizing the extra boundary states 02, 13;
* decomposes each participating new matching against both designated
  matchings in its own boundary class; and
* finds the minimum exchange certificate for each extra state.

The proper part of a singleton matching is stored below.  Its unique
semiedge is determined by the boundary-class number.
"""

from __future__ import annotations

from collections import defaultdict, deque
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
import json
from pathlib import Path
import sys
from typing import Iterable


HERE = Path(__file__).resolve().parent
SEED_PATH = HERE.parent / "agent-proof" / "verify_two_window_counterexample.py"


def load_seed():
    spec = spec_from_file_location("note026_frozen_seed", SEED_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import frozen seed from {SEED_PATH}")
    module = module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


seed = load_seed()
Edge = tuple[int, int]
Matching = frozenset[Edge]


def edge_key(edge: Edge) -> Edge:
    return tuple(sorted(edge))


def path_edge_set(path: list[int]) -> set[Edge]:
    return {
        edge_key((first, second))
        for first, second in zip(path, path[1:])
    }


Y0_PATH = seed.boundary_paths_after_removing(1)[(3, 4)]
Y2_PATH = seed.boundary_paths_after_removing(3)[(0, 1)]
WINDOW_EDGES = {
    "Y0": path_edge_set(Y0_PATH),
    "Y2": path_edge_set(Y2_PATH),
}


def matching_key(matching: Matching) -> tuple[Edge, ...]:
    return tuple(sorted(matching))


def verify_singleton_matching(matching: Matching, position: int) -> None:
    """Check the proper part plus semiedge at ``position`` is perfect."""
    incidence = [0] * seed.N
    for u, v in matching:
        assert (u, v) in seed.EDGE_SUPPORTS
        incidence[u] += 1
        incidence[v] += 1
    incidence[position] += 1
    assert incidence == [1] * seed.N


def enumerate_singleton_classes() -> list[list[Matching]]:
    graph = seed.adjacency(set(seed.EDGE_SUPPORTS))
    classes = [
        sorted(
            seed.enumerate_singleton_matchings(graph, position),
            key=matching_key,
        )
        for position in range(5)
    ]
    assert [len(layer) for layer in classes] == [8, 8, 6, 7, 4]
    for position, layer in enumerate(classes):
        assert len(layer) == len(set(layer))
        for matching in layer:
            verify_singleton_matching(matching, position)
    return classes


def connected_vertex_sets(edges: set[Edge]) -> list[set[int]]:
    adjacency: dict[int, set[int]] = defaultdict(set)
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    unseen = set(adjacency)
    answer = []
    while unseen:
        start = min(unseen)
        component = {start}
        queue = deque([start])
        unseen.remove(start)
        while queue:
            vertex = queue.popleft()
            for neighbour in adjacency[vertex]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        answer.append(component)
    return answer


def directed_cycle(
    adjacency: dict[int, set[int]], start: int, first_neighbour: int
) -> tuple[int, ...]:
    vertices = [start]
    previous = start
    current = first_neighbour
    while current != start:
        vertices.append(current)
        following = sorted(adjacency[current] - {previous})
        assert len(following) == 1
        previous, current = current, following[0]
    return tuple(vertices)


def canonical_cycle(
    adjacency: dict[int, set[int]], component: set[int]
) -> tuple[int, ...]:
    start = min(component)
    neighbours = sorted(adjacency[start])
    assert len(neighbours) == 2
    candidates = [directed_cycle(adjacency, start, neighbour) for neighbour in neighbours]
    answer = min(candidates)
    assert set(answer) == component and len(answer) == len(component)
    return answer


def exchange_decomposition(source: Matching, target: Matching) -> dict:
    """Decompose a same-class symmetric difference into alternating cycles."""
    difference = set(source ^ target)
    assert difference
    adjacency: dict[int, set[int]] = defaultdict(set)
    for u, v in difference:
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())

    cycles = []
    for component in connected_vertex_sets(difference):
        vertices = canonical_cycle(adjacency, component)
        ordered_edges = tuple(
            edge_key((vertices[index], vertices[(index + 1) % len(vertices)]))
            for index in range(len(vertices))
        )
        memberships = [edge in source for edge in ordered_edges]
        assert len(vertices) % 2 == 0
        assert all(
            memberships[index] != memberships[(index + 1) % len(memberships)]
            for index in range(len(memberships))
        )
        cycles.append(
            {
                "length": len(ordered_edges),
                "vertices": list(vertices),
                "ordered_edges": [list(edge) for edge in ordered_edges],
                "window_edge_intersections": {
                    name: [
                        list(edge)
                        for edge in ordered_edges
                        if edge in window_edges
                    ]
                    for name, window_edges in WINDOW_EDGES.items()
                },
                "contains_blocker_a": seed.A in ordered_edges,
                "contains_blocker_b": seed.B in ordered_edges,
                "source_edges_removed": [
                    list(edge) for edge in ordered_edges if edge in source
                ],
                "target_edges_added": [
                    list(edge) for edge in ordered_edges if edge in target
                ],
            }
        )
    cycles.sort(key=lambda cycle: tuple(cycle["vertices"]))
    assert sum(cycle["length"] for cycle in cycles) == len(difference)
    return {
        "component_count": len(cycles),
        "total_cycle_edges": len(difference),
        "cycles": cycles,
    }


def source_record(
    source_state: int,
    source: Matching,
    target_id: str,
    target: Matching,
) -> dict:
    return {
        "source": f"N{source_state}",
        "target": target_id,
        **exchange_decomposition(source, target),
    }


def source_order(record: dict) -> tuple[int, int, str]:
    """Prefer fewer flips, then fewer changed proper edges."""
    return (
        record["component_count"],
        record["total_cycle_edges"],
        record["source"],
    )


def edge_length_order(record: dict) -> tuple[int, int, str]:
    return (
        record["total_cycle_edges"],
        record["component_count"],
        record["source"],
    )


def matching_object(
    matching_id: str,
    matching: Matching,
    designated_states: Iterable[int],
) -> dict:
    return {
        "id": matching_id,
        "designated_states": [f"N{state}" for state in designated_states],
        "proper_edges": [list(edge) for edge in sorted(matching)],
    }


def main() -> None:
    proper_edges = set(seed.EDGE_SUPPORTS)
    graph = seed.adjacency(proper_edges)
    assert seed.A in WINDOW_EDGES["Y0"] and seed.A in WINDOW_EDGES["Y2"]
    assert len(proper_edges) == 23
    assert {
        vertex: len(neighbours) for vertex, neighbours in graph.items()
    } == {
        vertex: (2 if vertex in seed.TERMINALS else 3)
        for vertex in range(seed.N)
    }
    assert len(seed.components(proper_edges)) == 1

    classes = enumerate_singleton_classes()
    designated = [frozenset(seed.matching(state)) for state in range(10)]
    for state, matching in enumerate(designated):
        verify_singleton_matching(matching, state % 5)
        assert matching in classes[state % 5]

    ids: dict[Matching, str] = {}
    class_output = []
    for position, layer in enumerate(classes):
        layer_output = []
        for index, matching in enumerate(layer):
            matching_id = f"P{position}_{index}"
            ids[matching] = matching_id
            marks = [state for state in range(10) if designated[state] == matching]
            layer_output.append(matching_object(matching_id, matching, marks))
        class_output.append(layer_output)

    # Full disjoint boundary-pair support, not only the two extra states.
    full_tait_pairs = []
    disjoint_by_state: dict[tuple[int, int], list[tuple[Matching, Matching]]] = {}
    for first, second in combinations(range(5), 2):
        pairs = [
            (left, right)
            for left in classes[first]
            for right in classes[second]
            if left.isdisjoint(right)
        ]
        if pairs:
            full_tait_pairs.append((first, second))
            disjoint_by_state[(first, second)] = pairs
    target_cycle = {(0, 1), (1, 2), (2, 3), (3, 4), (0, 4)}
    extra_states = {(0, 2), (1, 3)}
    assert set(full_tait_pairs) == target_cycle | extra_states

    # The designated disjointness graph includes semiedge conflicts and is C10.
    designated_disjoint = set()
    for first, second in combinations(range(10), 2):
        boundary_conflict = first % 5 == second % 5
        if not boundary_conflict and designated[first].isdisjoint(designated[second]):
            designated_disjoint.add(frozenset((first, second)))
    expected_c10 = {
        frozenset((state, (state + 1) % 10)) for state in range(10)
    }
    assert designated_disjoint == expected_c10

    relevant = set(
        matching
        for state in extra_states
        for pair in disjoint_by_state[state]
        for matching in pair
    )
    designated_set = set(designated)
    assert relevant.isdisjoint(designated_set)

    exchange_records = {}
    for position, layer in enumerate(classes):
        for matching in layer:
            if matching not in relevant:
                continue
            matching_id = ids[matching]
            disjoint_designated_states = [
                f"N{state}"
                for state, source in enumerate(designated)
                if state % 5 != position and matching.isdisjoint(source)
            ]
            # Thus neither extra state is a one-sided repair which keeps a
            # designated matching in the other boundary class fixed.
            assert disjoint_designated_states == []
            records = [
                source_record(state, designated[state], matching_id, matching)
                for state in (position, position + 5)
            ]
            fewest_components = min(records, key=source_order)
            fewest_edges = min(records, key=edge_length_order)
            assert fewest_components["component_count"] == 1
            exchange_records[matching] = {
                "matching": matching_object(matching_id, matching, ()),
                "disjoint_designated_states_in_other_classes": (
                    disjoint_designated_states
                ),
                "all_designated_sources": records,
                "minimum_flip_then_length_source": {
                    "source": fewest_components["source"],
                    "component_count": fewest_components["component_count"],
                    "total_cycle_edges": fewest_components["total_cycle_edges"],
                },
                "minimum_edge_length_source": {
                    "source": fewest_edges["source"],
                    "component_count": fewest_edges["component_count"],
                    "total_cycle_edges": fewest_edges["total_cycle_edges"],
                },
                "has_one_cycle_source": True,
            }

    extra_output = []
    minimum_state_certificates = {}
    for state in sorted(extra_states):
        pair_output = []
        certificate_candidates = []
        for left, right in disjoint_by_state[state]:
            left_id, right_id = ids[left], ids[right]
            assert left.isdisjoint(right)
            source_combinations = []
            for left_state, right_state in product(
                (state[0], state[0] + 5),
                (state[1], state[1] + 5),
            ):
                left_decomposition = source_record(
                    left_state, designated[left_state], left_id, left
                )
                right_decomposition = source_record(
                    right_state, designated[right_state], right_id, right
                )
                source_combinations.append(
                    {
                        "sources": [f"N{left_state}", f"N{right_state}"],
                        "source_proper_edge_intersection": [
                            list(edge)
                            for edge in sorted(
                                designated[left_state] & designated[right_state]
                            )
                        ],
                        "total_components": (
                            left_decomposition["component_count"]
                            + right_decomposition["component_count"]
                        ),
                        "total_cycle_edges": (
                            left_decomposition["total_cycle_edges"]
                            + right_decomposition["total_cycle_edges"]
                        ),
                        "one_cycle_for_each_matching": (
                            left_decomposition["component_count"] == 1
                            and right_decomposition["component_count"] == 1
                        ),
                        "left_exchange": left_decomposition,
                        "right_exchange": right_decomposition,
                    }
                )
            best = min(
                source_combinations,
                key=lambda record: (
                    record["total_components"],
                    record["total_cycle_edges"],
                    record["sources"],
                ),
            )
            certificate = {
                "pair": [left_id, right_id],
                "both_matchings_new": (
                    left not in designated_set and right not in designated_set
                ),
                "minimum_source_certificate": best,
            }
            pair_output.append(certificate)
            certificate_candidates.append(certificate)

        best_for_state = min(
            certificate_candidates,
            key=lambda certificate: (
                certificate["minimum_source_certificate"]["total_components"],
                certificate["minimum_source_certificate"]["total_cycle_edges"],
                certificate["pair"],
            ),
        )
        assert best_for_state["minimum_source_certificate"]["total_components"] == 2
        assert best_for_state["minimum_source_certificate"][
            "one_cycle_for_each_matching"
        ]
        state_name = "".join(map(str, state))
        minimum_state_certificates[state_name] = best_for_state
        extra_output.append(
            {
                "state": state_name,
                "disjoint_pair_count": len(pair_output),
                "disjoint_pairs": pair_output,
            }
        )

    assert {
        state: len(disjoint_by_state[state]) for state in extra_states
    } == {(0, 2): 2, (1, 3): 2}

    output = {
        "scope": "frozen Note-026 17-vertex pole only",
        "vertices": seed.N,
        "proper_edges": len(seed.EDGE_SUPPORTS),
        "blocked_windows": {
            "Y0_vertices": Y0_PATH,
            "Y2_vertices": Y2_PATH,
            "a": list(seed.A),
            "a_in_both": seed.A in WINDOW_EDGES["Y0"]
            and seed.A in WINDOW_EDGES["Y2"],
        },
        "singleton_class_sizes": [len(layer) for layer in classes],
        "singleton_classes": class_output,
        "full_tait_boundary_pairs": ["".join(map(str, pair)) for pair in full_tait_pairs],
        "target_cycle_states": ["01", "12", "23", "34", "04"],
        "extra_states": extra_output,
        "relevant_new_matching_exchanges": {
            ids[matching]: exchange_records[matching]
            for matching in sorted(relevant, key=lambda item: ids[item])
        },
        "minimum_extra_state_certificates": minimum_state_certificates,
        "finite_conclusion": {
            "every_extra_pair_uses_two_new_matchings": True,
            "every_participating_new_matching_has_a_one_cycle_designated_source": True,
            "both_extra_states_have_a_two_single_cycle_certificate": True,
            "no_participating_new_matching_is_disjoint_from_a_designated_matching_in_another_class": True,
            "no_extra_state_is_obtained_by_one_sided_designated_replacement": True,
            "does_not_prove_general_two_window_closure_lemma": True,
        },
    }
    print(json.dumps(output, indent=2, sort_keys=False))
    print("NOTE026_EXTRA_STATE_EXCHANGE_VERIFIED")


if __name__ == "__main__":
    main()
