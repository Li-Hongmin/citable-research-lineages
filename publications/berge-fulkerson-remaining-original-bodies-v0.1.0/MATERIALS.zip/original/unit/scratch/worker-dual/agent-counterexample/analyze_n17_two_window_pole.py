#!/usr/bin/env python3
"""Close the full perfect-matching family of one n=17 incidence realization.

The input is the explicit connected cubic completion found by the incidence
CP-SAT model with two common blocker edges and the two required routes
``a in Y_0`` and ``a in Y_2``.  This script independently checks the graph,
the ten designated matchings, their disjointness graph and forced paths, then
enumerates the complete perfect-matching family and its Tait states.

The solver layers 0,...,4 are relabelled to the Case-XII diagonal pentagon
order before comparing Tait states with the project's exact-S convention.
"""

from __future__ import annotations

from collections import Counter
import importlib.util
from itertools import combinations
from pathlib import Path
import sys

import networkx as nx


HERE = Path(__file__).resolve().parent
SCRATCH = HERE.parents[1]
BASE_PATH = SCRATCH / "case_xii_n13_c10_target.py"


def load_base():
    spec = importlib.util.spec_from_file_location("case_xii_target", BASE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {BASE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


base = load_base()
legacy = base.legacy

N = 17
PENTAGON_ORDER = (1, 4, 2, 5, 3)
RELABEL = {layer: PENTAGON_ORDER[layer] - 1 for layer in range(5)}
RELABEL.update({vertex: vertex for vertex in range(5, N)})

# Edge supports are the designated matching indices using that proper edge.
SUPPORTED_OLD = (
    ((0, 4), (1, 3, 6, 8)),
    ((0, 12), (2, 4, 7, 9)),
    ((1, 2), (0, 3, 5, 8)),
    ((1, 9), (2, 4, 7, 9)),
    ((2, 3), (1, 4, 6, 9)),
    ((3, 8), (0, 2, 5, 7)),
    ((4, 11), (0, 2, 5, 7)),
    ((5, 6), (0, 2, 4, 6, 8)),
    ((5, 7), (1, 3, 5, 7, 9)),
    ((5, 14), ()),
    ((6, 11), (3, 9)),
    ((6, 16), (1, 5, 7)),
    ((7, 13), (0, 2, 4, 6, 8)),
    ((7, 15), ()),
    ((8, 11), (1, 4, 6, 8)),
    ((8, 16), (3, 9)),
    ((9, 12), (0, 3, 6, 8)),
    ((9, 13), (1, 5)),
    ((10, 12), (1, 5)),
    ((10, 13), (3, 7, 9)),
    ((10, 14), (0, 2, 4, 6, 8)),
    ((14, 15), (1, 3, 5, 7, 9)),
    ((15, 16), (0, 2, 4, 6, 8)),
)


def relabel_edge(edge: tuple[int, int]) -> tuple[int, int]:
    return tuple(sorted((RELABEL[edge[0]], RELABEL[edge[1]])))


SUPPORTED = tuple((relabel_edge(edge), support) for edge, support in SUPPORTED_OLD)
PROPER_EDGES = tuple(sorted(edge for edge, _ in SUPPORTED))


def capacity_witness(singleton: dict[int, list[frozenset[str]]]):
    positions = sorted(singleton, key=lambda position: len(singleton[position]))
    selected: list[tuple[int, frozenset[str]]] = []
    multiplicity: Counter[str] = Counter()

    def search(index: int):
        if index == len(positions):
            return tuple(selected)
        position = positions[index]
        for matching in singleton[position]:
            if any(multiplicity[edge] >= 2 for edge in matching):
                continue
            selected.append((position, matching))
            multiplicity.update(matching)
            witness = search(index + 1)
            if witness is not None:
                return witness
            multiplicity.subtract(matching)
            selected.pop()
        return None

    return search(0)


def verify_old_forced_route(k: int, blocker: tuple[int, int]) -> dict:
    removed = (k + 1) % 10
    complement = nx.Graph()
    complement.add_nodes_from(range(N))
    complement.add_edges_from(
        edge for edge, support in SUPPORTED_OLD if removed not in support
    )
    blocker_component = nx.node_connected_component(complement, blocker[0])
    y_terminals = {(k + 3) % 5, (k + 4) % 5}
    terminal_set = blocker_component & set(range(5))
    y_path = nx.shortest_path(complement, *sorted(y_terminals))
    y_path_edges = {
        frozenset((first, second))
        for first, second in zip(y_path, y_path[1:])
    }
    return {
        "k": k,
        "blocker": blocker,
        "component_terminals": sorted(terminal_set),
        "expected_y_terminals": sorted(y_terminals),
        "y_path_vertices": y_path,
        "blocker_is_on_y": frozenset(blocker) in y_path_edges
        and terminal_set == y_terminals,
    }


def main() -> None:
    assert len(PROPER_EDGES) == len(set(PROPER_EDGES))
    graph = nx.Graph()
    graph.add_nodes_from(range(N))
    graph.add_edges_from(PROPER_EDGES)
    degrees = {
        vertex: graph.degree(vertex) + (1 if vertex < 5 else 0)
        for vertex in range(N)
    }
    assert all(degree == 3 for degree in degrees.values())
    assert nx.is_connected(graph)

    pole = legacy.Pole(n=N, proper_edges=PROPER_EDGES)
    matchings, _, edge_position, _ = legacy.enumerate_perfect_matchings(pole)
    edge_id = {edge: f"e{index}" for index, edge in enumerate(PROPER_EDGES)}

    designated: list[frozenset[str]] = []
    for state in range(10):
        layer = state % 5
        matching = frozenset(
            [edge_id[edge] for edge, support in SUPPORTED if state in support]
            + [f"s{PENTAGON_ORDER[layer]}"]
        )
        assert matching in matchings
        designated.append(matching)

    actual_disjoint = {
        frozenset((first, second))
        for first, second in combinations(range(10), 2)
        if designated[first].isdisjoint(designated[second])
    }
    expected_cycle = {
        frozenset((state, (state + 1) % 10)) for state in range(10)
    }

    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)

    full_witness = capacity_witness(singleton)
    designated_set = set(designated)
    routes = [
        verify_old_forced_route(0, (5, 6)),
        verify_old_forced_route(2, (5, 6)),
    ]
    assert all(route["blocker_is_on_y"] for route in routes)

    tait_states = legacy.enumerate_tait_states(pole)
    output = {
        "n": N,
        "proper_edges_solver_labels": tuple(sorted(edge for edge, _ in SUPPORTED_OLD)),
        "proper_edges_case_xii_labels": PROPER_EDGES,
        "simple_connected_cubic": True,
        "designated_matching_count": len(designated),
        "designated_disjoint_pairs": sorted(map(sorted, actual_disjoint)),
        "expected_c10_pairs": sorted(map(sorted, expected_cycle)),
        "missing_c10_pairs": sorted(map(sorted, expected_cycle - actual_disjoint)),
        "extra_disjoint_pairs": sorted(map(sorted, actual_disjoint - expected_cycle)),
        "two_forced_routes_solver_labels": routes,
        "all_perfect_matchings": len(matchings),
        "singleton_class_sizes_1_to_5": [len(singleton[i]) for i in range(1, 6)],
        "tait_states": sorted(tait_states),
        "expected_exact_S": sorted(legacy.S_DIAGONALS),
        "exact_S": tait_states == legacy.S_DIAGONALS,
        "full_capacity_two_witness_exists": full_witness is not None,
        "full_capacity_two_witness_uses_extra_states": full_witness is not None
        and any(matching not in designated_set for _, matching in full_witness),
        "full_capacity_two_witness": None
        if full_witness is None
        else [(position, sorted(matching)) for position, matching in full_witness],
    }
    print(output)


if __name__ == "__main__":
    main()
