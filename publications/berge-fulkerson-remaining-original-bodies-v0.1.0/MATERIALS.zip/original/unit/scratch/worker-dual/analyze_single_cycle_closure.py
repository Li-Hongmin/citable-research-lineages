#!/usr/bin/env python3
"""Find the smallest alternating-cycle repair of the embedded bad C10."""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
from itertools import product
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
VERIFY = HERE / "independent_verify_c10_blocker_completion.py"
spec = importlib.util.spec_from_file_location("independent_completion", VERIFY)
if spec is None or spec.loader is None:
    raise RuntimeError(f"cannot import {VERIFY}")
data = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = data
spec.loader.exec_module(data)


def exchange_components(first, second):
    difference = first ^ second
    adjacency = defaultdict(set)
    for edge in difference:
        endpoints = data.ENDPOINTS[edge]
        if len(endpoints) == 1:
            # Same-class singleton matchings share their semiedge, so this
            # branch should not occur in the exchanges considered below.
            vertex = next(iter(endpoints))
            adjacency[vertex].add(("boundary", edge))
            continue
        u, v = endpoints
        adjacency[u].add(v)
        adjacency[v].add(u)
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())
    unseen = set(adjacency)
    components = []
    while unseen:
        start = next(iter(unseen))
        stack = [start]
        vertices = set()
        while stack:
            vertex = stack.pop()
            if vertex in vertices:
                continue
            vertices.add(vertex)
            unseen.discard(vertex)
            stack.extend(adjacency[vertex] - vertices)
        cycle_edges = sorted(
            edge
            for edge in difference
            if data.ENDPOINTS[edge] <= vertices
        )
        components.append({"vertices": sorted(vertices), "edges": cycle_edges})
    return tuple(sorted(components, key=lambda item: item["vertices"]))


def maximum_multiplicity(matchings):
    multiplicity = Counter(edge for matching in matchings for edge in matching)
    return max(multiplicity.values()), multiplicity


def main():
    matchings = data.enumerate_perfect_matchings()
    singleton = data.singleton_classes(matchings)
    designated = data.designated_matchings()
    designated_set = set(designated)
    class_of_state = {
        state: data.PENTAGON_ORDER[index % 5]
        for index, state in enumerate(designated)
    }

    distance = {}
    source = {}
    for position in range(1, 6):
        starts = [state for state in designated if class_of_state[state] == position]
        for matching in singleton[position]:
            best = min(
                (
                    len(exchange_components(start, matching)),
                    tuple(sorted(start)),
                    start,
                )
                for start in starts
            )
            distance[matching] = best[0]
            source[matching] = best[2]

    ranked = []
    positions = tuple(range(1, 6))
    for chosen in product(*(singleton[position] for position in positions)):
        maximum, multiplicity = maximum_multiplicity(chosen)
        if maximum > 2:
            continue
        outside = tuple(matching for matching in chosen if matching not in designated_set)
        ranked.append(
            (
                len(outside),
                sum(distance[matching] for matching in outside),
                max((distance[matching] for matching in outside), default=0),
                tuple(tuple(sorted(matching)) for matching in chosen),
                chosen,
                multiplicity,
            )
        )
    assert ranked
    ranked.sort(key=lambda item: item[:4])
    best = ranked[0]
    outside = [matching for matching in best[4] if matching not in designated_set]

    exchanges = []
    for matching in outside:
        initial = source[matching]
        exchanges.append(
            {
                "position": next(iter(data.boundary_set(matching))),
                "from": sorted(initial),
                "to": sorted(matching),
                "cycles": exchange_components(initial, matching),
            }
        )

    common_even = set.intersection(*(set(designated[k]) for k in range(0, 10, 2)))
    common_odd = set.intersection(*(set(designated[k]) for k in range(1, 10, 2)))
    output = {
        "good_transversals": len(ranked),
        "minimum_new_matchings": best[0],
        "minimum_total_cycle_exchanges_at_that_level": best[1],
        "minimum_max_exchange_distance": best[2],
        "common_even_edges": sorted(common_even),
        "common_odd_edges": sorted(common_odd),
        "best_transversal": [sorted(matching) for matching in best[4]],
        "maximum_multiplicity": max(best[5].values()),
        "multiplicity_one_edges": sorted(edge for edge, count in best[5].items() if count == 1),
        "multiplicity_two_edges": sorted(edge for edge, count in best[5].items() if count == 2),
        "exchanges": exchanges,
    }
    print(output)


if __name__ == "__main__":
    main()
