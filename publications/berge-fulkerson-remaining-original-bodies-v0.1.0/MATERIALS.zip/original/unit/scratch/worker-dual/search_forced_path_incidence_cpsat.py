#!/usr/bin/env python3
"""CP-SAT realization test for forced-path C10 incidence systems."""

from __future__ import annotations

import argparse
from itertools import combinations
import importlib.util
from pathlib import Path
import sys

import networkx as nx
from ortools.sat.python import cp_model


HERE = Path(__file__).resolve().parent
FLOW_PATH = HERE / "search_forced_path_incidence_flow.py"
SPEC = importlib.util.spec_from_file_location("forced_path_flow", FLOW_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot import {FLOW_PATH}")
flow = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = flow
SPEC.loader.exec_module(flow)
base = flow.base


def solve(
    n: int,
    geometry: str,
    windows: tuple[int, ...],
    time_limit: float,
    workers: int,
    require_exact_c10: bool = True,
    fix_both_blockers: bool = True,
    active_states: tuple[int, ...] = tuple(range(10)),
) -> dict:
    pairs = tuple(combinations(range(n), 2))
    model = cp_model.CpModel()
    y = {
        (u, v, support_index): model.new_bool_var(base.variable(u, v, support_index))
        for u, v in pairs
        for support_index in range(len(base.SUPPORTS))
    }

    for u, v in pairs:
        model.add_at_most_one(y[u, v, support_index] for support_index in range(len(base.SUPPORTS)))

    for vertex in range(n):
        incident = [
            y[min(vertex, other), max(vertex, other), support_index]
            for other in range(n)
            if other != vertex
            for support_index in range(len(base.SUPPORTS))
        ]
        model.add(sum(incident) == (2 if vertex < 5 else 3))

    for vertex in range(n):
        boundary_mask = base.BOUNDARY[vertex] if vertex < 5 else 0
        for state in active_states:
            incident = [
                y[min(vertex, other), max(vertex, other), support_index]
                for other in range(n)
                if other != vertex
                for support_index, support in enumerate(base.SUPPORTS)
                if (support >> state) & 1
            ]
            model.add(sum(incident) == (0 if (boundary_mask >> state) & 1 else 1))

    if require_exact_c10:
        for first, second in combinations(range(10), 2):
            if (second - first) % 10 in (1, 9):
                continue
            if any(
                ((mask >> first) & 1) and ((mask >> second) & 1)
                for mask in base.BOUNDARY
            ):
                continue
            covering = [
                y[u, v, support_index]
                for u, v in pairs
                for support_index, support in enumerate(base.SUPPORTS)
                if ((support >> first) & 1) and ((support >> second) & 1)
            ]
            model.add(sum(covering) >= 1)

    blocker_edges = {
        "even": (5, 6, base.EVEN),
        "odd": (5, 7, base.ODD) if geometry == "adjacent" else (7, 8, base.ODD),
    }
    support_index = {support: index for index, support in enumerate(base.SUPPORTS)}
    fixed_labels = blocker_edges if fix_both_blockers else {
        "even" if all(k % 2 == 0 for k in windows) else "odd": blocker_edges[
            "even" if all(k % 2 == 0 for k in windows) else "odd"
        ]
    }
    for label, (u, v, support) in fixed_labels.items():
        model.add(y[min(u, v), max(u, v), support_index[support]] == 1)

    for k in windows:
        removed_state = (k + 1) % 10
        y1, y2 = (k + 3) % 5, (k + 4) % 5
        label = "even" if k % 2 == 0 else "odd"
        blocker_u, blocker_v, _ = blocker_edges[label]
        blocker_pair = frozenset((blocker_u, blocker_v))
        orientations = [model.new_bool_var(f"z_{k}_{orientation}") for orientation in range(2)]
        model.add_exactly_one(orientations)

        for orientation in range(2):
            endpoints = (
                ((y1, blocker_u), (y2, blocker_v))
                if orientation == 0
                else ((y1, blocker_v), (y2, blocker_u))
            )
            for connection, (source, sink) in enumerate(endpoints):
                arcs = {
                    (u, v): model.new_bool_var(f"f_{k}_{orientation}_{connection}_{u}_{v}")
                    for u in range(n)
                    for v in range(n)
                    if u != v and frozenset((u, v)) != blocker_pair
                }
                for vertex in range(n):
                    outgoing = [arc for (u, _), arc in arcs.items() if u == vertex]
                    incoming = [arc for (_, v), arc in arcs.items() if v == vertex]
                    balance = orientations[orientation] if vertex == source else -orientations[orientation] if vertex == sink else 0
                    model.add(sum(outgoing) - sum(incoming) == balance)
                for (u, v), arc in arcs.items():
                    model.add(arc <= orientations[orientation])
                    available = [
                        y[min(u, v), max(u, v), index]
                        for index, support in enumerate(base.SUPPORTS)
                        if not ((support >> removed_state) & 1)
                    ]
                    model.add(arc <= sum(available))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = workers
    solver.parameters.symmetry_level = 2
    connectivity_cuts = 0
    while True:
        status = solver.solve(model)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {
                "n": n,
                "geometry": geometry,
                "windows": list(windows),
                "require_exact_c10": require_exact_c10,
                "fix_both_blockers": fix_both_blockers,
                "active_states": list(active_states),
                "status": "infeasible" if status == cp_model.INFEASIBLE else "unknown_or_timeout",
                "connectivity_cuts": connectivity_cuts,
                "wall_time": solver.wall_time,
                "branches": solver.num_branches,
            }

        selected = [
            (u, v, support_index)
            for u, v in pairs
            for support_index in range(len(base.SUPPORTS))
            if solver.value(y[u, v, support_index])
        ]
        flow.verify_routes(n, selected, blocker_edges, windows)
        graph = nx.Graph()
        graph.add_nodes_from(range(n))
        graph.add_edges_from((u, v) for u, v, _ in selected)
        components = [frozenset(component) for component in nx.connected_components(graph)]
        if len(components) == 1:
            return {
                "n": n,
                "geometry": geometry,
                "windows": list(windows),
                "require_exact_c10": require_exact_c10,
                "fix_both_blockers": fix_both_blockers,
                "active_states": list(active_states),
                "status": "realized",
                "connectivity_cuts": connectivity_cuts,
                "wall_time": solver.wall_time,
                "branches": solver.num_branches,
                "proper_edges_with_supports": [
                    {
                        "edge": [u, v],
                        "support": [
                            state
                            for state in range(10)
                            if (base.SUPPORTS[index] >> state) & 1
                        ],
                    }
                    for u, v, index in selected
                ],
            }
        for component in components:
            side = flow.canonical_side(component, n)
            if not side:
                continue
            crossing = [
                y[min(u, v), max(u, v), index]
                for u in side
                for v in range(n)
                if v not in side
                for index in range(len(base.SUPPORTS))
            ]
            model.add(sum(crossing) >= 1)
            connectivity_cuts += 1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--geometry", choices=("adjacent", "disjoint", "both"), default="both")
    parser.add_argument("--windows", type=int, nargs="*", default=[0, 2, 4, 6, 8])
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--no-exact-c10", action="store_true")
    parser.add_argument("--single-blocker", action="store_true")
    parser.add_argument("--active-states", type=int, nargs="*", default=list(range(10)))
    args = parser.parse_args()
    windows = tuple(args.windows)
    if any(k < 0 or k >= 10 for k in windows) or len(set(windows)) != len(windows):
        raise ValueError("windows must be distinct integers from 0 through 9")
    active_states = tuple(args.active_states)
    if any(state < 0 or state >= 10 for state in active_states) or len(set(active_states)) != len(active_states):
        raise ValueError("active states must be distinct integers from 0 through 9")
    required_removed_states = {(k + 1) % 10 for k in windows}
    if not required_removed_states.issubset(active_states):
        raise ValueError("every route's removed matching must be active")
    geometries = ("adjacent", "disjoint") if args.geometry == "both" else (args.geometry,)
    for geometry in geometries:
        print(
            solve(
                args.n,
                geometry,
                windows,
                args.time_limit,
                args.workers,
                not args.no_exact_c10,
                not args.single_blocker,
                active_states,
            )
        )


if __name__ == "__main__":
    main()
