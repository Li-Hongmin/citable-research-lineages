# A falsifiable single-cycle closure lemma for bad C10 subsystems

## Minimal exchange in the 49-matching pole

Use the explicit thirteen-vertex pole of Note 009, with sorted proper-edge
identifiers

\[
\begin{array}{c|ccccccccccccccccc}
j&0&1&2&3&4&5&6&7&8&9&10&11&12&13&14&15&16\\
\hline
e_j&(02)&(03)&(13)&(14)&(2,12)&(48)&(56)&(59)&(5,10)&
(67)&(69)&(78)&(7,11)&(8,12)&(9,10)&(10,11)&(11,12).
\end{array}
\]

For the designated two-state-per-layer blocker, take the five-state window
\(N_5,N_6,N_7,N_8,N_9\) in layer order \(1,4,2,5,3\).  Its first matching is

\[
N_5=\{e_2,e_4,e_5,e_6,e_{12},e_{14},s_1\}.
\]

The proper square on vertices \(5,6,9,10\) has edge set

\[
C=\{e_6,e_8,e_{10},e_{14}\}.
\]

It is alternating for \(N_5\).  The single flip

\[
Q=N_5\mathbin\triangle C
=\{e_2,e_4,e_5,e_8,e_{10},e_{12},s_1\}
\]

removes the two common odd-state edges \(e_6,e_{14}\).  The window

\[
Q,N_6,N_7,N_8,N_9
\]

has four consecutive disjoint pairs and empty triple intersection

\[
Q\cap N_7\cap N_9=\varnothing.
\]

Therefore it has edge multiplicity at most two.  Exhaustive comparison shows
that zero new matchings cannot work (all 32 designated transversals are bad),
whereas this one new matching at one cycle exchange works.  The exchange is
minimal in both the number of added matchings and the number of alternating
cycles.

## Exact local implication

Let \(N_0,\ldots,N_9\) be singleton-boundary perfect matchings whose induced
disjointness graph is

\[
N_0N_1\cdots N_9N_0=C_{10},
\]

with layer sequence periodic modulo five.  Fix \(k\).  If a cycle component
\(C\) of \(H-N_{k+1}\) is alternating for \(N_k\), put

\[
Q=N_k\mathbin\triangle C.
\]

Then \(Q\) is a singleton matching in the same boundary class as \(N_k\) and
is still disjoint from \(N_{k+1}\).  If additionally

\[
Q\cap N_{k+2}\cap N_{k+4}=\varnothing,
\tag{1}
\]

then

\[
Q,N_{k+1},N_{k+2},N_{k+3},N_{k+4}
\]

is a capacity-two transversal.  Indeed, its four consecutive pairs are
disjoint.  An edge occurring three times among five positions with this path
disjointness would have to occupy the unique size-three independent set
\(\{0,2,4\}\) of the five-position path, which is excluded by (1).

## Candidate closure lemma

The following is the precise falsifiable statement suggested by the data.

> **Two-edge-blocker cycle-flip lemma.**  Let \(H\) be a simple connected
> cubic 5-pole with distinct terminals and exact Tait state set
> \(S=\{13,14,24,25,35\}\).  Suppose ten singleton matchings
> \(N_0,\ldots,N_9\) induce \(C_{10}\), and suppose two proper edges \(a,b\)
> meet every \(N_k\).  Then for some \(k\), a cycle component of
> \(H-N_{k+1}\) has a flip \(Q=N_k\triangle C\) satisfying (1).

The two-edge hypothesis is exactly the smallest Farkas obstruction from Note
009.  Since consecutive \(N_k,N_{k+1}\) are disjoint, every \(N_k\) contains
exactly one of \(a,b\), and the labels alternate around \(C_{10}\).  Thus each
boundary layer contains one \(a\)-state and one \(b\)-state.

## Finite falsification test

All simple connected distinct-terminal exact-\(S\) unlabelled skeletons
through thirteen internal vertices were streamed.  The numbers of retained
skeletons at orders \(5,7,9,11,13\) were

\[
1,1,7,41,318.
\]

No induced C10 subsystem occurs before order thirteen.  At order thirteen:

\[
62\text{ induced C10 subsystems}
=52\text{ internally capacity-good}+10\text{ internally bad}.
\]

All ten bad subsystems have a two-edge Farkas blocker.  Four have four such
edge pairs and six have six.  Every one of the ten has a path-preserving
single-cycle repair satisfying (1).  The repairing cycle lengths are

\[
4\text{ in three cases},\qquad
6\text{ in four cases},\qquad
8\text{ in three cases}.
\]

This is bounded evidence, not a proof of the candidate lemma.  In particular,
it does not cover order fifteen or bad C10 subsystems whose infeasibility is
integer-only rather than certified by two edges.

The exact disposable audit is
`audit_bad_c10_single_cycle_repair.py`; the explicit-pole minimization is
`analyze_single_cycle_closure.py`.

From the project root, the complete declared finite audit is self-contained:

```text
uv run --with networkx python units/berge-fulkerson/scratch/worker-dual/audit_bad_c10_single_cycle_repair.py
```

With no arguments this runs orders `5 7 9 11 13`.  The multi-cycle refinement
and the remaining forced-path obstruction are recorded in
`component_reduction.md`.
