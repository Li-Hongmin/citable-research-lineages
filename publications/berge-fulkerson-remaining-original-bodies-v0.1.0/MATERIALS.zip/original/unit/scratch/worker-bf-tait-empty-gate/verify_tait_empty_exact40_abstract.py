#!/usr/bin/env python3
"""A Tait-empty common-vector boundary for the Case-XII D5 gate.

This is deliberately an incidence model rather than a cubic pole.  It keeps
one global pool of binary vectors, assigns the usual singleton/triple
boundary labels, and checks every six-vector equation against that pool.  The
singleton vectors are pairwise intersecting, so the model has no Tait state.
Private guard coordinates block every T--T completion (including T loops).
The model is useful only as a route boundary: it omits the common trivalent
vertex incidence of genuine perfect matchings.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations, combinations_with_replacement, product


POSITIONS = tuple(range(1, 6))
PAIRS = tuple(combinations(POSITIONS, 2))
S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
S_SET = frozenset(S)
T_SET = frozenset(T)


def complement(pair):
    return frozenset(set(POSITIONS) - set(pair))


def labels():
    return tuple((i, bit) for i in POSITIONS for bit in (0, 1))


def build_singleton_coordinates():
    """Make every two singleton vectors intersect, with load at most two."""
    labs = labels()
    supports = {lab: 0 for lab in labs}
    coordinate = 0
    for left, right in combinations(labs, 2):
        supports[left] |= 1 << coordinate
        supports[right] |= 1 << coordinate
        coordinate += 1
    return labs, supports, coordinate


def selected_labels(slots, fixed_bits=None):
    """Choose distinct variants for repeated terminal positions."""
    occurrence = defaultdict(int)
    result = []
    for position in slots:
        if fixed_bits is None:
            bit = occurrence[position]
        else:
            if occurrence[position]:
                raise AssertionError((slots, position, fixed_bits))
            bit = fixed_bits[position]
        if bit > 1:
            raise AssertionError((slots, position))
        result.append((position, bit))
        occurrence[position] += 1
    return tuple(result)


def load(supports, selected, width):
    out = [0] * width
    for lab in selected:
        vector = supports[lab]
        while vector:
            bit = vector & -vector
            out[bit.bit_length() - 1] += 1
            vector -= bit
    return out


def add_vector(vectors, metadata, name, vector, pair):
    if name in vectors:
        raise AssertionError(name)
    vectors[name] = vector
    metadata[name] = pair


def make_positive_records():
    """Create one witness record for every S-loop, S-S and S-T cell."""
    records = []
    # Keep each triple vector private to one record.  This makes the global
    # pool finite and makes the negative T--T guards transparent.
    for pair in S:
        records.append(("loop", pair, pair, tuple(pair) + tuple(pair)))
    for left, right in combinations(S, 2):
        records.append(("ss", left, right, tuple(left) + tuple(right)))
    for left in S:
        for right in T:
            records.append(("st", left, right, tuple(left) + tuple(right)))
    assert len(records) == 40
    return records


def build_model():
    labs, supports, coordinate_count = build_singleton_coordinates()
    vectors = {}
    metadata = {}
    records = make_positive_records()
    record_data = []
    # Each record carries (S-triple, second triple, selected singleton labels).
    for record_index, (kind, left, right, slots) in enumerate(records):
        fixed_bits = None
        if kind == "st" and len(set(slots)) == 4:
            # There is one D5 cell for each omitted terminal m.  Its selected
            # bit pattern has a single 1 at m+1 (cyclically) and 0 elsewhere.
            # Distinct D5 cells then disagree on a position fixed by both,
            # so their singleton cylinders are pairwise disjoint.
            missing = next(position for position in POSITIONS if position not in slots)
            distinguished = missing % len(POSITIONS) + 1
            fixed_bits = {position: int(position == distinguished) for position in slots}
        selected = selected_labels(slots, fixed_bits)
        singleton_load = load(supports, selected, coordinate_count)
        if max(singleton_load, default=0) > 2:
            raise AssertionError((record_index, slots, singleton_load))
        q_left = 0
        q_right = 0
        for coordinate, value in enumerate(singleton_load):
            residual = 2 - value
            if residual == 2:
                q_left |= 1 << coordinate
                q_right |= 1 << coordinate
            elif residual == 1:
                # Orient the residual consistently.  Guard coordinates below
                # may flip the two bits when the second vector is targeted.
                q_right |= 1 << coordinate
            elif residual != 0:
                raise AssertionError((record_index, coordinate, value))
        left_name = ("Q", record_index, 0)
        right_name = ("Q", record_index, 1)
        add_vector(vectors, metadata, left_name, q_left, left)
        add_vector(vectors, metadata, right_name, q_right, right)
        record_data.append({
            "kind": kind,
            "left": left,
            "right": right,
            "slots": slots,
            "selected": selected,
            "left_name": left_name,
            "right_name": right_name,
        })

    # Isolate the designated singleton tuple of each positive record.  For a
    # fresh coordinate c_alpha supported only on one selected singleton
    # label alpha, the designated triple pair has total bit one at c_alpha.
    # Replacing alpha in that slot lowers the load to one, while every other
    # triple vector has bit zero there.  Hence each target cell has exactly
    # the one chosen singleton tuple and one chosen triple pair as a witness;
    # this makes the D5 cylinder intersections genuinely empty rather than
    # merely empty for the displayed witnesses.
    for record in record_data:
        for selected_label in record["selected"]:
            coordinate = coordinate_count
            coordinate_count += 1
            supports[selected_label] |= 1 << coordinate
            # Recompute the residual for every record.  A record containing
            # this label has singleton load one and receives a single bit on
            # its right triple; records not containing it have residual two
            # and receive one bit on *both* triples.  (With only two variants
            # per boundary class, labels are necessarily reused across
            # records.)
            for other in record_data:
                residual = 1 if selected_label in other["selected"] else 2
                left_bit = 1 if residual == 2 else 0
                right_bit = 1
                if left_bit:
                    vectors[other["left_name"]] |= 1 << coordinate
                else:
                    vectors[other["left_name"]] &= ~(1 << coordinate)
                if right_bit:
                    vectors[other["right_name"]] |= 1 << coordinate
                else:
                    vectors[other["right_name"]] &= ~(1 << coordinate)

    # Only T-triple vectors need guards.  A guard coordinate is 1 on both
    # variants of one singleton class.  For the targeted pair of T vectors it
    # is chosen so that every T--T singleton choice has load > 2.  For each
    # positive record the companion triple bit is set to the residual, so all
    # 40 positive equations survive.
    t_names = tuple(record["right_name"] for record in record_data if record["kind"] == "st")
    t_records = {record["right_name"]: record for record in record_data if record["kind"] == "st"}
    guards = []
    for first_index, second_index in combinations_with_replacement(range(len(t_names)), 2):
        first_name = t_names[first_index]
        second_name = t_names[second_index]
        first_record = t_records[first_name]
        second_record = t_records[second_name]
        found = None
        for position in POSITIONS:
            first_occurrence = first_record["slots"].count(position)
            second_occurrence = second_record["slots"].count(position)
            # The bit of a targeted triple is forced when its positive record
            # has residual 0 or 2, and is free when residual is 1.
            first_allowed = ((0,) if first_occurrence == 2 else
                             (1,) if first_occurrence == 0 else (0, 1))
            second_allowed = ((0,) if second_occurrence == 2 else
                              (1,) if second_occurrence == 0 else (0, 1))
            forbidden_singleton_load = (
                first_record["right"].count(position)
                + second_record["right"].count(position)
            )
            for first_bit in first_allowed:
                for second_bit in second_allowed:
                    if first_name == second_name and first_bit != second_bit:
                        continue
                    if forbidden_singleton_load + first_bit + second_bit > 2:
                        found = (position, first_bit, second_bit)
                        break
                if found is not None:
                    break
            if found is not None:
                break
        if found is None:
            raise AssertionError((first_name, second_name))
        position, first_bit, second_bit = found
        coordinate = coordinate_count
        coordinate_count += 1
        for lab in labs:
            if lab[0] == position:
                supports[lab] |= 1 << coordinate
        # Recompute both bits for every record at this new coordinate.  The
        # targeted T bits use the guard choice; the other records use a fixed
        # residual split.
        for record in record_data:
            occurrence = record["slots"].count(position)
            residual = 2 - occurrence
            if record["right_name"] == first_name:
                right_bit = first_bit
            elif record["right_name"] == second_name:
                right_bit = second_bit
            else:
                right_bit = 1 if residual == 2 else 0
            left_bit = residual - right_bit
            if left_bit not in (0, 1) or right_bit not in (0, 1):
                raise AssertionError((record["left_name"], coordinate, occurrence,
                                      left_bit, right_bit))
            if left_bit:
                vectors[record["left_name"]] |= 1 << coordinate
            else:
                vectors[record["left_name"]] &= ~(1 << coordinate)
            if right_bit:
                vectors[record["right_name"]] |= 1 << coordinate
            else:
                vectors[record["right_name"]] &= ~(1 << coordinate)
        guards.append((first_name, second_name, position, first_bit, second_bit))

    # Five terminal coordinates encode the usual semiedge boundary.  They are
    # independent of the proper-coordinate guards and satisfy every positive
    # six-vector equation by the pair/complement convention.
    terminal_offset = coordinate_count
    coordinate_count += 5
    for name, vector in list(vectors.items()):
        pair = metadata[name]
        for position in POSITIONS:
            if position not in pair:
                vector |= 1 << (terminal_offset + position - 1)
            else:
                vector &= ~(1 << (terminal_offset + position - 1))
        vectors[name] = vector
    for lab in labs:
        vector = supports[lab]
        vector |= 1 << (terminal_offset + lab[0] - 1)
        supports[lab] = vector

    classes = defaultdict(list)
    for name, vector in vectors.items():
        classes[metadata[name]].append((name, vector))
    return {
        "labels": labs,
        "supports": supports,
        "vectors": vectors,
        "metadata": metadata,
        "classes": classes,
        "records": records,
        "record_data": record_data,
        "guards": guards,
        "proper_coordinates": terminal_offset,
        "coordinate_count": coordinate_count,
        "terminal_offset": terminal_offset,
    }


def vector_bit(vector, coordinate):
    return (vector >> coordinate) & 1


def matching_load(model, selected):
    width = model["coordinate_count"]
    loads = [0] * width
    for lab in selected:
        vector = model["supports"][lab]
        for coordinate in range(width):
            loads[coordinate] += vector_bit(vector, coordinate)
    return loads


def cover_exists(model, first_pair, second_pair, first_vector, second_vector, selected):
    loads = matching_load(model, selected)
    return all(
        vector_bit(first_vector, coordinate)
        + vector_bit(second_vector, coordinate)
        + value == 2
        for coordinate, value in enumerate(loads)
    )


def all_singleton_choices(model, slots):
    return product(*(tuple(lab for lab in model["labels"] if lab[0] == position)
                     for position in slots))


def check_positive_support(model):
    classes = model["classes"]
    # Every declared target type has a witness from the global pool.
    for left in S:
        assert any(
            cover_exists(model, left, left, q0[1], q1[1], selected)
            for q0, q1 in combinations_with_replacement(classes[left], 2)
            for selected in all_singleton_choices(model, left + left)
        ), ("missing S-loop", left)
    for left, right in combinations(S, 2):
        assert any(
            cover_exists(model, left, right, q0[1], q1[1], selected)
            for q0 in classes[left]
            for q1 in classes[right]
            for selected in all_singleton_choices(model, left + right)
        ), ("missing S-S", left, right)
    for left in S:
        for right in T:
            assert any(
                cover_exists(model, left, right, q0[1], q1[1], selected)
                for q0 in classes[left]
                for q1 in classes[right]
                for selected in all_singleton_choices(model, left + right)
            ), ("missing S-T", left, right)


def check_no_t_types(model):
    classes = model["classes"]
    for left, right in combinations_with_replacement(T, 2):
        for q0 in classes[left]:
            for q1 in classes[right]:
                for selected in all_singleton_choices(model, left + right):
                    assert not cover_exists(model, left, right, q0[1], q1[1], selected), (
                        "forbidden T type", left, right, q0[0], q1[0], selected
                    )


def check_tait_empty(model):
    supports = model["supports"]
    for left, right in combinations(model["labels"], 2):
        if left[0] == right[0]:
            continue
        assert supports[left] & supports[right], ("Tait pair", left, right)


def cell_projection(model, cell):
    left, right = cell
    classes = model["classes"]
    answer = set()
    # Store a full five-position tuple; the omitted position in this cell is
    # a wildcard, exactly as in a D5 cylinder intersection.
    for full in product(*(tuple(lab for lab in model["labels"] if lab[0] == position)
                          for position in POSITIONS)):
        selected = tuple(full[position - 1] for position in left + right)
        if any(
            cover_exists(model, left, right, q0[1], q1[1], selected)
            for q0 in classes[left]
            for q1 in classes[right]
        ):
            answer.add(full)
    return answer


def check_d5_joins(model):
    d5 = tuple((left, right) for left in S for right in T
               if set(left).isdisjoint(right))
    projections = {cell: cell_projection(model, cell) for cell in d5}
    joins = []
    for omitted in d5:
        common = set.intersection(*(projections[cell] for cell in d5 if cell != omitted))
        joins.append(len(common))
        assert not common, ("D5 join", omitted, common)
    return d5, joins


def check_declared_equations(model):
    """Every one of the 40 construction records is an exact six-vector load."""
    for record in model["record_data"]:
        selected = record["selected"]
        left_name = record["left_name"]
        right_name = record["right_name"]
        assert cover_exists(
            model, record["left"], record["right"],
            model["vectors"][left_name], model["vectors"][right_name], selected
        ), record


def main():
    model = build_model()
    check_declared_equations(model)
    check_positive_support(model)
    check_no_t_types(model)
    check_tait_empty(model)
    d5, joins = check_d5_joins(model)
    # No zero-boundary vectors are included in the abstract pool; therefore
    # the A type is absent by construction.  The model intentionally does not
    # claim the cubic-vertex complement closure of a real pole.
    print({
        "singleton_vectors": len(model["labels"]),
        "triple_vectors": len(model["vectors"]),
        "positive_types": 40,
        "tait_states": 0,
        "t_loop": False,
        "tt_support": False,
        "a_vectors_in_pool": 0,
        "d5_cells": len(d5),
        "d5_join_sizes": joins,
        "guard_coordinates": len(model["guards"]),
        "coordinate_count": model["coordinate_count"],
    })
    print("TAIT_EMPTY_EXACT40_ABSTRACT_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
