# Tait-empty S-loop branching: a two-fibre necessary condition

## Scope

Let H be a cubic 5-pole and let

```text
S = {13, 14, 24, 25, 35}.
```

This note attacks only common perfect-matching incidence at the five S-loop
witnesses. It does not use a new graph search, an abstract vector
countermodel, or an Omen run.

## Two-fibre branching lemma

For an S-loop [ij], write an arbitrary six-matching witness as

```text
Q0, Q1 in Q_ij,
Pi0, Pi1 in P_i,
Pj0, Pj1 in P_j,
```

with the edgewise load equation

```text
chi(Q0) + chi(Q1) + chi(Pi0) + chi(Pi1)
  + chi(Pj0) + chi(Pj1) = 2 * 1.             (L0)
```

If H is Tait-empty, at least two of the three occurrence pairs

```text
(Q0,Q1), (Pi0,Pi1), (Pj0,Pj1)
```

must be distinct.

Proof. Suppose at most one pair is distinct. Call the two repeated pairs
(X,X) and (Y,Y), and call the remaining pair (Z,Z'). Equation (L0) gives,
for every edge object e,

```text
Z(e) + Z'(e) = 2 - 2*X(e) - 2*Y(e),
```

The left side is nonnegative, so the value -2 cannot occur; the right-hand
side is therefore in {0,2}. Since Z(e), Z'(e) are 0/1, this forces
Z(e)=Z'(e) for every e. All three pairs are therefore repeated, and (L0)
divides by two to

```text
chi(X) + chi(Y) + chi(Z) = 1.
```

The three edge-disjoint perfect matchings X, Y, Z form a Tait colouring,
contrary to the hypothesis. QED.

## Global fibre-count consequence

Mark a fibre P_i or Q_ij when it contains at least two distinct perfect
matchings. The lemma says that every one of the five S-loop hyperedges

```text
{P_i, P_j, Q_ij}   (ij in S)
```

contains at least two marked vertices. If p of the five singleton fibres are
marked and q of the five S-triple fibres are marked, double-counting loop
incidences gives

```text
2*p + q >= 10.                                  (1)
```

Hence p+q >= 5. Equality p+q=5 is possible only when p=5 and q=0. If any
S-triple fibre is non-singleton (q>0), then p+q >= 6. In particular, if all
five S-triple fibres are singleton, all five singleton fibres must be
non-singleton.

This improves the weaker one-hit statement (minimum hitting number three):
Tait-emptiness forces a two-hit on every S-loop witness, not merely one
non-singleton fibre.

## Relation to exact Case XII

The condition is necessary for a Tait-empty exact-40 pole because the five
S-loops are among its positive types. It is not sufficient for a D5 join or
an A-cover. It does not use the absence of T-loops/T--T types, and no known
argument turns the marked-fibre count into cross-cell singleton reuse.

The remaining arrow is still:

```text
exact 40 support + no A/T-loop/T--T + Tait-empty
  => ? D5 four-cell join (or another A-producing incidence theorem).
```

The missing information is how distinct matching pairs in different S-loop
witnesses are coupled by common alternating-cycle closure and by the 25 S--T
witness families. The count (1) alone supplies no such coupling.

## Four-value decision

* General proof of the Tait-empty branch: **not obtained**.
* Real exact-40 Tait-empty pole: **not constructed**.
* Strict added condition: **proved** — every S-loop witness has at least two
  distinct fibre pairs; globally 2p+q >= 10, with the equality rigidity above.
* Route status: **closed at fibre cardinality; unresolved at cross-cell
  incidence/synchronization**.
