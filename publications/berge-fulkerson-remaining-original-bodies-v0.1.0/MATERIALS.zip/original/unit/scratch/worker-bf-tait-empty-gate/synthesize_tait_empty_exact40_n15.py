#!/usr/bin/env python3
"""Bounded CEGAR pulse for the Tait-empty exact-40 branch.

This wrapper reuses the existing common graph/perfect-matching synthesis
object, but adds one genuinely new lazy gate: if the synthesized pole has a
Tait colouring, the current proper-edge set is blocked.  A Tait colouring of
a cubic five-pole covers every present proper edge, so this is a sound
graph-level clause for the current candidate.  The evaluator then tests the
next candidate afresh.

The pulse is deliberately fixed at n=15.  It is not a census and a timeout
or round limit is an unresolved bounded result, never an UNSAT proof.
"""

from __future__ import annotations

import importlib.util
import json
import time
from pathlib import Path
from itertools import combinations

from z3 import Not, unknown, sat


HERE = Path(__file__).resolve().parent
# The Omen pulse copies both sources into one detached run directory, while
# the local tree keeps the base in its neighbouring worker directory.
_LOCAL_BASE = (
    HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
)
_BUNDLED_BASE = HERE / "synthesize_exact40_joint_pb.py"
BASE_PATH = _LOCAL_BASE if _LOCAL_BASE.exists() else _BUNDLED_BASE
SPEC = importlib.util.spec_from_file_location("exact40_base", BASE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def tait_colourings(n: int, proper_edges: tuple[tuple[int, int], ...]):
    """Return all concrete singleton-pair Tait colourings of one pole.

    A colouring is represented by two singleton-boundary perfect matchings
    and their proper-edge complement.  The complement automatically carries
    the remaining three semiedges, but membership in the actual PM family is
    checked explicitly.
    """
    matchings, classes = BASE.matching_classes(n, proper_edges)
    matching_set = {frozenset(matching) for matching in matchings}
    edge_count = len(proper_edges)
    all_objects = set(range(edge_count + len(BASE.TERMINALS)))
    out = []
    for first, second in combinations(BASE.TERMINALS, 2):
        first_family = classes.get(frozenset((first,)), ())
        second_family = classes.get(frozenset((second,)), ())
        for left in first_family:
            left_set = set(left)
            for right in second_family:
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third not in matching_set:
                    continue
                out.append((first, second, left, right, third))
    return tuple(out)


def run(n: int = 15, max_rounds: int = 40, timeout_ms: int = 300_000,
        out_path: Path | None = None):
    solver, x, edges, _ = BASE.build_solver(n)
    target_set = set(BASE.TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            rounds.append({"round": round_no, "status": "unknown"})
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("TAIT_EMPTY_SYNTHESIS_UNKNOWN")
            return payload
        if status != sat:
            rounds.append({"round": round_no, "status": "unsat"})
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("TAIT_EMPTY_EXACT40_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(
            edge for edge, var in x.items()
            if bool(model.eval(var, model_completion=True))
        ))
        result = BASE.evaluate(n, proper_edges)
        bad = []

        # Keep the same structural gates as the base synthesis object.
        if len(BASE.connected_components(n, proper_edges)) != 1:
            comps = BASE.connected_components(n, proper_edges)
            side = min(comps, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(
                edge for edge in edges
                if (edge[0] in side) ^ (edge[1] in side)
            )
            solver.add(BASE.Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side),
                        "crossing_count": len(crossing)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(
                    edge for edge in edges
                    if edge != bridge
                    and ((edge[0] in side) ^ (edge[1] in side))
                )
                if crossing:
                    solver.add(BASE.Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge),
                            "side": sorted(side)})

        # New Tait-empty gate.  Every concrete Tait colouring covers all
        # present proper edges, hence one clause blocks this graph edge set.
        colourings = tait_colourings(n, proper_edges)
        if colourings:
            solver.add(BASE.clause_for_union(x, edges, proper_edges))
            bad.append({
                "kind": "tait_nonempty",
                "colourings": len(colourings),
                "states": sorted({(a, b) for a, b, *_ in colourings}),
            })

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = BASE.graph_certificate(n, proper_edges, result)
        cert["tait_colourings"] = len(colourings)
        cert["tait_states"] = sorted({(a, b) for a, b, *_ in colourings})
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and result["a_witness"] is None
                and not any(result["joins"])
                and not colourings):
            payload = {
                "status": "real_tait_empty_exact40_joinfree",
                "rounds": rounds,
                "certificate": cert,
                "elapsed_s": time.time() - started,
            }
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_TAIT_EMPTY_EXACT40_D5_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("TAIT_EMPTY_SYNTHESIS_ROUND_LIMIT")
    return payload


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=15)
    parser.add_argument("--max-rounds", type=int, default=40)
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n != 15:
        raise SystemExit("this pulse is intentionally fixed at n=15")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)
