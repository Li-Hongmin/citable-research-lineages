#!/usr/bin/env python3
"""Freeze a real PM-incidence boundary for the Tait-empty D5 route.

The fixed order-29 pole is the Petersen-minus-vertex replacement pole from
worker-tait-empty-boundary.  This script checks one graph only; it is not a
census and does not synthesize a Case-XII pole.  Its purpose is to test
whether the two-hit S-loop fibre condition plus genuine same-class
alternating-cycle exchange already implies a D5 four-cell join.
"""

from __future__ import annotations

import importlib.util
import sys
from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPLACEMENT = HERE.parent / "worker-tait-empty-boundary" / (
    "verify_vertex_j_replacement_boundary.py"
)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BASE = load_module("h29_replacement_boundary", REPLACEMENT)

POSITIONS = tuple(range(1, 6))
PAIR_SET = tuple(combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(set(PAIR_SET) - set(S))
PAIR_TYPES = tuple(combinations_with_replacement(PAIR_SET, 2))
D5 = tuple(sorted(
    (s, t) for s in S for t in T if set(s).isdisjoint(t)
))


def complement(pair: tuple[int, int]) -> tuple[int, ...]:
    return tuple(position for position in POSITIONS if position not in pair)


def boundary_classes(matchings, proper_count: int):
    classes = defaultdict(list)
    for matching in matchings:
        boundary = tuple(sorted(
            index - proper_count + 1
            for index in matching
            if index >= proper_count
        ))
        classes[boundary].append(frozenset(matching))
    for key in classes:
        classes[key].sort(key=lambda matching: tuple(sorted(matching)))
    return dict(classes)


def exact_completion(
    q0: frozenset[int],
    q1: frozenset[int],
    slots: tuple[int, ...],
    classes: dict[tuple[int, ...], list[frozenset[int]]],
    edge_count: int,
):
    """Return all singleton choices completing a fixed triple pair."""
    load = [0] * edge_count
    for matching in (q0, q1):
        for edge in matching:
            load[edge] += 1
    if max(load) > 2:
        return tuple()

    # Keep occurrence slots distinct: repeated boundary positions may use two
    # different perfect matchings, exactly as in a loop witness.
    order = sorted(range(len(slots)), key=lambda k: len(classes[(slots[k],)]))
    choices: list[frozenset[int] | None] = [None] * len(slots)
    out = []

    def recurse(index: int):
        if index == len(order):
            if all(value == 2 for value in load):
                out.append(tuple(choices))
            return
        slot_index = order[index]
        position = slots[slot_index]
        for matching in classes[(position,)]:
            if any(load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                load[edge] += 1
            choices[slot_index] = matching
            recurse(index + 1)
            choices[slot_index] = None
            for edge in matching:
                load[edge] -= 1

    recurse(0)
    return tuple(out)


def support_exists(
    left: tuple[int, int],
    right: tuple[int, int],
    classes: dict[tuple[int, ...], list[frozenset[int]]],
    edge_count: int,
) -> bool:
    first = classes[complement(left)]
    second = classes[complement(right)]
    if left == right:
        triple_pairs = combinations_with_replacement(first, 2)
    else:
        triple_pairs = product(first, second)
    slots = tuple(left + right)
    return any(
        exact_completion(q0, q1, slots, classes, edge_count)
        for q0, q1 in triple_pairs
    )


def all_support(
    classes: dict[tuple[int, ...], list[frozenset[int]]], edge_count: int
):
    support = set()
    for left, right in PAIR_TYPES:
        if support_exists(left, right, classes, edge_count):
            support.add((left, right))
    return frozenset(support)


def capacity_exists(
    classes: dict[tuple[int, ...], list[frozenset[int]]], edge_count: int
) -> bool:
    order = sorted(POSITIONS, key=lambda position: len(classes[(position,)]))
    load = [0] * edge_count

    def recurse(index: int) -> bool:
        if index == len(order):
            return True
        position = order[index]
        for matching in classes[(position,)]:
            if any(load[edge] >= 2 for edge in matching):
                continue
            for edge in matching:
                load[edge] += 1
            if recurse(index + 1):
                return True
            for edge in matching:
                load[edge] -= 1
        return False

    return recurse(0)


def d5_relations(
    classes: dict[tuple[int, ...], list[frozenset[int]]], edge_count: int
):
    """Return all actual five-coordinate cylinders for the five D5 cells."""
    relations = {}
    witness_counts = {}
    for left, right in D5:
        slots = tuple(left + right)
        missing = tuple(position for position in POSITIONS if position not in slots)
        assert len(missing) == 1
        relation = set()
        count = 0
        for q0 in classes[complement(left)]:
            for q1 in classes[complement(right)]:
                for choice in exact_completion(
                    q0, q1, slots, classes, edge_count
                ):
                    full = [None] * 5
                    for position, matching in zip(slots, choice):
                        full[position - 1] = tuple(sorted(matching))
                    relation.add(tuple(full))
                    count += 1
        relations[(left, right)] = frozenset(relation)
        witness_counts[(left, right)] = count
    return relations, witness_counts


def loop_branch_counts(
    pair: tuple[int, int],
    classes: dict[tuple[int, ...], list[frozenset[int]]],
    edge_count: int,
):
    """Count exact loop witnesses by number of distinct occurrence pairs."""
    q_family = classes[complement(pair)]
    i_family = classes[(pair[0],)]
    j_family = classes[(pair[1],)]
    counts = Counter()
    total = 0
    for q0, q1 in combinations_with_replacement(q_family, 2):
        for i0, i1 in combinations_with_replacement(i_family, 2):
            for j0, j1 in combinations_with_replacement(j_family, 2):
                load = [0] * edge_count
                for matching in (q0, q1, i0, i1, j0, j1):
                    for edge in matching:
                        load[edge] += 1
                if any(value != 2 for value in load):
                    continue
                total += 1
                distinct = sum((q0 != q1, i0 != i1, j0 != j1))
                counts[distinct] += 1
    return total, counts


def exchange_connected(
    classes: dict[tuple[int, ...], list[frozenset[int]]],
    edge_list,
    proper_count: int,
):
    """Check single-proper-alternating-cycle connectivity of every fibre."""
    endpoints = {
        index: tuple(edge_list[index])
        for index in range(proper_count)
    }
    rows = {}
    for boundary, family in classes.items():
        adjacency = {matching: set() for matching in family}
        for first, second in combinations(family, 2):
            difference = (set(first) ^ set(second))
            proper_difference = difference & set(range(proper_count))
            if not proper_difference:
                continue
            graph = defaultdict(set)
            for edge in proper_difference:
                u, v = endpoints[edge]
                graph[u].add(v)
                graph[v].add(u)
            root = min(graph)
            seen = {root}
            queue = deque([root])
            while queue:
                vertex = queue.popleft()
                for neighbour in graph[vertex]:
                    if neighbour not in seen:
                        seen.add(neighbour)
                        queue.append(neighbour)
            if seen != set(graph):
                continue
            adjacency[first].add(second)
            adjacency[second].add(first)
        seen = set()
        if family:
            seen.add(family[0])
            queue = deque([family[0]])
            while queue:
                matching = queue.popleft()
                for neighbour in adjacency[matching]:
                    if neighbour not in seen:
                        seen.add(neighbour)
                        queue.append(neighbour)
        rows[boundary] = {
            "vertices": len(family),
            "exchange_edges": sum(map(len, adjacency.values())) // 2,
            "connected": seen == set(family),
        }
    return rows


def main() -> None:
    vertices, proper, terminals, _, _ = BASE.build_pole()
    matchings, edge_list = BASE.enumerate_pole_matchings(
        vertices, proper, terminals
    )
    proper_count = len(proper)
    edge_count = len(edge_list)
    classes = boundary_classes(matchings, proper_count)

    assert len(vertices) == 29
    assert proper_count == 41
    assert len(matchings) == 176
    assert BASE.taits_empty(vertices, proper, terminals)

    support = all_support(classes, edge_count)
    assert len(support) == 55
    assert not capacity_exists(classes, edge_count)

    s_loops = sum((pair, pair) in support for pair in S)
    ss_offdiag = sum(
        left != right and left in S and right in S
        for left, right in support
    )
    st = sum(
        (left in S and right in T) or (left in T and right in S)
        for left, right in support
    )
    t_loops = sum((pair, pair) in support for pair in T)
    tt_offdiag = sum(
        left != right and left in T and right in T
        for left, right in support
    )
    assert (s_loops, ss_offdiag, st, t_loops, tt_offdiag) == (5, 10, 25, 5, 10)

    loop_rows = {}
    for pair in sorted(S):
        total, counts = loop_branch_counts(pair, classes, edge_count)
        assert total > 0
        assert set(counts) == {3}
        loop_rows[pair] = {
            "witnesses": total,
            "distinct_occurrence_pairs": dict(sorted(counts.items())),
        }

    exchange_rows = exchange_connected(classes, edge_list, proper_count)
    assert all(row["connected"] for row in exchange_rows.values())

    relations, witness_counts = d5_relations(classes, edge_count)
    join_sizes = {}
    for omitted in D5:
        common = set.intersection(*(
            set(relations[cell]) for cell in D5 if cell != omitted
        ))
        join_sizes[omitted] = len(common)
    assert all(size == 0 for size in join_sizes.values())

    output = {
        "order": len(vertices),
        "proper_edges": proper_count,
        "perfect_matchings": len(matchings),
        "tait_empty": True,
        "ordinary_support": len(support),
        "support_breakdown": {
            "S_loops": s_loops,
            "S_S_offdiag": ss_offdiag,
            "S_T": st,
            "T_loops": t_loops,
            "T_T_offdiag": tt_offdiag,
        },
        "A_cover": False,
        "S_loop_branching": loop_rows,
        "exchange_fibres_all_connected": True,
        "D5_witness_counts": {
            str(cell): witness_counts[cell] for cell in D5
        },
        "D5_four_cell_join_sizes": {
            str(cell): join_sizes[cell] for cell in D5
        },
        "exact_40": False,
        "boundary_reason": "five T-loops and ten T--T types remain",
    }
    print(output)
    print("H29_TAIT_EMPTY_DELTA_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
