# Tait-empty exact-40 Omen pulse at order 15

## Scope

The pulse tests only the following unresolved branch at order 15: one common
simple connected cubic 5-pole, exact Case-XII positive support (the 40 types),
no A=(12345) cover, no Tait colouring, and no D5 join. It is a bounded CEGAR
synthesis, not a census and not an all-order statement.

## Reproduction

```text
python3 -u synthesize_tait_empty_exact40_n15.py --n 15 --max-rounds 20 \
  --timeout-ms 120000 --json tait_empty_exact40_n15.json
```

Omen run directory:

```text
[local archival reference]
```

Source fingerprints:

```text
synthesize_tait_empty_exact40_n15.py
dba8ae77a8eba588c8600178362bda587611c847ff60168347455caec45c177d

synthesize_exact40_joint_pb.py (base)
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

## Omen outcome

All 20 solver rounds returned SAT. The run ended at `round_limit`; it
produced neither an UNSAT certificate nor a real exact-40 Tait-empty model.
The evaluated candidates retained 55 ordinary BF support types (target: 40)
and had 17--30 concrete Tait colourings. Thus every candidate was rejected
by at least one positive-support or Tait-nonempty gate before reaching the
target. This is an unresolved bounded result, not evidence of impossibility.

## Analytic boundary

For an S-loop [ij], any six-matching witness uses the three fibres P_i, P_j,
and Q_ij. If all three are singletons, the double-cover equation is

```text
2(chi(P_i) + chi(P_j) + chi(Q_ij)) = 2 * 1.
```

This is exactly a Tait colouring. Therefore a Tait-empty pole must have a
non-singleton member in each of the five S-loop triples. The resulting
five-edge hypergraph has minimum hitting number 3; in particular, at least
three of the ten relevant fibres are non-singleton. This is a strict
necessary condition only; it does not imply an A-cover, a D5 join, or a
contradiction.

## Four-value decision

| Outcome | Status |
|---|---|
| General proof of the Tait-empty branch | **No** |
| Real exact-40 Tait-empty counterexample | **No** |
| Strict additional condition | **Yes** — fibre-hitting/cardinality condition above |
| Route status | **Closed at this interface / bounded unresolved** |

The omitted decisive layer is the common cubic three-valent incidence of all
perfect matchings (and its compatibility across witnesses). The abstract
exact-40 Tait-empty model in `tait-empty-exact40-abstract-boundary-20260901.md`
shows that support labels, binary load equations, and D5-join absence alone
cannot decide the branch; it is not a cubic-pole counterexample.
