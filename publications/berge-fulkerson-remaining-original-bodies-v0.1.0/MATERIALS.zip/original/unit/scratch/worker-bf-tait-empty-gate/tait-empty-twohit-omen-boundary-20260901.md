# Omen pulse: Tait-empty exact-40 with the two-hit S-loop gate

## Decision target

This fixed-order pulse attacks only the remaining real-pole interface:

```text
common cubic five-pole / PM incidence
+ all 40 positive Case-XII types (15 S--S and 25 S--T)
+ five S-loop two-hit conditions
+ Tait-empty, no A, and empty D5 four-cell joins.
```

The order is fixed at `n=13`; no order scan or H29/exchange experiment is
included.  The two-hit gate is encoded directly on each selected S-loop
six-matching witness: at least two of its three same-fibre occurrence pairs
must differ.  A compact canonical singleton-intersection gate is added as a
necessary Tait-empty condition.  Complete PM enumeration supplies the lazy
Tait-colouring blockers, so a successful target model would still have to be
genuinely Tait-empty.

## Omen reproduction

Remote directory:

```text
[local archival reference]
```

Omen environment: Python 3.10.12 with the installed Z3 package.

```text
python3 -u synthesize_tait_empty_exact40_twohit_pb.py \
  --n 13 --max-rounds 20 --timeout-ms 300000 \
  --json tait_empty_twohit_n13.json
```

Source hashes:

```text
synthesize_tait_empty_exact40_twohit_pb.py
669ca3c53cbd3d7be312f1950e1ac5386ed06f58fa2c1ddcbf4c3b596fa2c717
synthesize_exact40_joint_pb.py
aa8dcb9d759a642576aff91ecb41f64af8499265d54098bd0f84fde5dd333804
```

The archived Omen outputs are in
`omen-twohit-n13-20260901/{run.log,tait_empty_twohit_n13.json}`.
Their local SHA-256 values are

```text
run.log
fbbacfac03465c07900612cce45663174206fc7636f75ef04b60e9302cfa4711
tait_empty_twohit_n13.json
2f3699d5ca83b81d6152890160e838ac04e74986375be2d8508b99d3dce692f9
```

## Result

All 20 solver rounds returned SAT; the pulse ended with
`TAIT_EMPTY_TWOHIT_ROUND_LIMIT` after 23.55 seconds.  No round produced a
Tait-empty exact-40 pole, an UNSAT proof, or a real Case-XII counterexample.

Across the 20 evaluated candidates:

* support size was 55 in 17 rounds, 52 in two rounds, and 53 in one;
* every round had concrete Tait colourings (10--22 colourings);
* 18 rounds had an A-cover (two did not);
* three rounds exposed a D5 join; the remainder had no join in that round;
* every round was rejected by at least one concrete forbidden-support or
  Tait-colouring blocker before reaching the target.

The first candidate, for example, had 34 PMs, support 55, 15 Tait
colourings, an A-cover, and one D5 join.  The two-hit and canonical gates
were active in the solver certificate.

## Four-value decision

| outcome | status |
|---|---|
| real Tait-empty exact-40 pole | not found |
| finite real counterexample | not found |
| UNSAT/impossibility proof | not obtained |
| current encoding | bounded solver boundary (`round_limit`) |

This result does not support an impossibility claim.  It only shows that the
fixed `n=13` common-incidence encoding, even after adding the two-hit
S-loop condition, remains in the same CEGAR boundary: the solver keeps
returning poles with extra support and/or Tait colourings.  Increasing the
order or repeating the pulse is not justified without a structural reduction
of these blockers.
