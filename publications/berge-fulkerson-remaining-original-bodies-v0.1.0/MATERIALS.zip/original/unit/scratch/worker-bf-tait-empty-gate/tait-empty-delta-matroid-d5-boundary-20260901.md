# Tait-empty branch: delta-matroid exchange stops before the D5 join

## Scope and decision

This note tests the proposed interface

```text
common perfect-matching incidence + two-hit S-loop fibres
  + same-fibre alternating-cycle exchange
  => a D5 four-cell join.
```

The implication is **not established**.  The obstruction is not a lack of
exchange connectivity: exchange connectivity is a within-fibre statement,
whereas a D5 join requires one compatible matching choice in four different
S--T cells.  Matching delta-matroid or ear-decomposition exchange gives no
fibre convexity or Helly property that would synchronize those four cells.

## Real PM-incidence boundary

The fixed order-29 pole `H29` is a genuine simple connected cubic 5-pole.  Its
proper core has girth five, is bridgeless, and has no nonterminal cyclic
2-cut.  A pure standard-library verifier is

```text
python3 units/berge-fulkerson/scratch/worker-bf-tait-empty-gate/verify_h29_tait_empty_delta_boundary.py
```

The run terminates with `H29_TAIT_EMPTY_DELTA_BOUNDARY_VERIFIED` and reports:

| quantity | value |
|---|---:|
| vertices / proper edges | 29 / 41 |
| perfect matchings | 176 |
| Tait colourings | none |
| ordinary BF support | 55 |
| independent `(12345)` A-covers | none |

The 55 supported types split as

```text
5 S-loops + 10 off-diagonal S--S + 25 S--T
  + 5 T-loops + 10 off-diagonal T--T.
```

Thus H29 has all five D5 S--T cells as actual perfect-matching
completions, but it is not an exact-40/Case-XII pole: the five T-loops and
ten T--T types remain.  It is consequently a strict boundary example, not a
counterexample to the Case-XII claim.

## What the example separates

Every S-loop witness in H29 has three distinct occurrence pairs (the
two-hit fibre lemma is therefore met with room to spare).  The matching
fibres are connected under proper alternating-cycle exchange.  Nevertheless,
for each of the five D5 cells, the intersection of the four other cell
relation sets is empty:

```text
D5 witness counts: 2048, 1408, 1024, 1152, 1600
D5 four-cell join sizes: 0, 0, 0, 0, 0
```

The active matching-level exchange graph is also connected.  Hence the
following implication is false even for one common genuine PM family:

```text
two-hit S-loop branching + connected same-fibre exchange + all D5 cells
  => D5 four-cell join.
```

The missing exact Case-XII hypotheses are precisely the exclusion of
T-loops and T--T types.  Since H29 has those types, it does not decide
whether that additional exclusion forces cross-cell synchronization.

## Consequence for the proof programme

The delta-matroid/ear route should be closed at this interface.  It proves
exchange connectivity only; it does not supply the cross-cell Helly or
common-incidence statement needed for a D5 join.  The remaining sharp
question is:

```text
one simple connected cubic 5-pole,
Tait-empty, exact 40-type support,
no T-loops and no T--T types
  => ? cross-cell fibre synchronization / A-cover.
```

The earlier two-hit count remains valid (for five S-loop witnesses,
`2p + q >= 10`), but H29 shows that count plus ordinary exchange cannot be
promoted to the missing conclusion.  No Omen run, higher-order census, or
abstract-only model is used in this boundary test.

## Evidence level

* strict real-PM-incidence boundary example;
* not an exact-40 pole and therefore not a Case-XII counterexample;
* no general proof of the Tait-empty branch;
* remaining interface isolated to the no-T-loop/no-T--T coupling.

