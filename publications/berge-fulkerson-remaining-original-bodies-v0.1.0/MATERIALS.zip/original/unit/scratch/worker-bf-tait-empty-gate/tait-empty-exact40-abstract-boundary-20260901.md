# Tait-empty exact-40 abstract boundary

## Decision

The Tait-empty branch cannot be closed from the Case-XII support labels,
common binary matching-vector incidence, exact six-vector load equations,
and the absence of T-loops/T--T types alone.  A finite global-vector model
with all these properties has all five D5 joins empty.

This is a strict **abstract** countermodel, not a cubic 5-pole.  It omits
the shared three-valent vertex equations which every genuine perfect
matching satisfies.  Therefore it closes only the route that uses common
binary incidence without that local cubic layer; it is not a real Case-XII
counterexample.

## Construction

There are two singleton vectors (P_{i,b}) for each boundary position
(i\in[5]), (b\in\{0,1\}).  For every unordered pair of the ten labels
((i,b)), introduce a coordinate and put a 1 on exactly the two vectors in
that pair.  Consequently every two singleton vectors from different
positions intersect, so the singleton Tait-state relation is empty.

For each of the five S-loops, ten off-diagonal S--S cells, and twenty-five
S--T cells (40 cells in all), choose one singleton variant for every slot;
when a position is repeated, use its two distinct variants.  For the five
disjoint S--T cells, the selected bits on the four present positions are
chosen as follows.  If (m) is the omitted position, put the unique 1 at
(m+1\pmod 5), and put 0 at the other three positions.  Thus distinct D5
cells disagree on a position fixed by both.

For each positive cell add two private triple vectors.  At every coordinate
their two bits are the residual (2-) (singleton load), so the displayed
cell is an exact six-vector double cover.  To prevent an alternative
singleton tuple from reusing a private cell witness, add one coordinate for
each selected singleton occurrence.  That coordinate is 1 on the selected
singleton vector; every global triple pair receives the corresponding
residual (one bit if it contains that singleton label, two bits otherwise).
The construction therefore has exactly 80 triple vectors in one global
pool.

Finally, for every unordered pair of the 25 T-triple vectors (including a
vector paired with itself), add one guard coordinate.  It is 1 on both
singleton variants of one boundary position.  The two targeted T vectors
are assigned bits so that

\[
  \text{(their forced singleton load at the position)}
  +\text{(the two T bits)}>2.
\]

The residual bit is assigned to the companion S vector in each positive
S--T record.  This preserves all 25 positive records while blocking every
T-loop and every T--T pair for every singleton choice.

Five terminal coordinates encode the usual boundary subsets.  No
zero-boundary vector is included, so the abstract pool has no A-type vector.

## Verified properties

The deterministic verifier

```text
python3 units/berge-fulkerson/scratch/worker-bf-tait-empty-gate/verify_tait_empty_exact40_abstract.py
```

checks:

* 10 singleton vectors, all pairwise intersecting across positions
  (`tait_states = 0`);
* one common pool of 80 triple vectors and exact load 2 for all 40
  declared positive cells;
* all five S-loops, all ten S--S types, and all twenty-five S--T types;
* no T-loop and no T--T type, quantified over the whole vector pool;
* all five D5 join sizes are zero;
* no A-type vector is present in the pool.

The Omen run used the byte-for-byte source SHA256
`1755e86bd5b9dc800b94fe87bda7ff40d4ae98861b06311abc44cf15824d44ad` and
returned:

```text
{'singleton_vectors': 10, 'triple_vectors': 80, 'positive_types': 40,
 'tait_states': 0, 't_loop': False, 'tt_support': False,
 'a_vectors_in_pool': 0, 'd5_cells': 5,
 'd5_join_sizes': [0, 0, 0, 0, 0], 'guard_coordinates': 325,
 'coordinate_count': 535}
TAIT_EMPTY_EXACT40_ABSTRACT_BOUNDARY_VERIFIED
```

The result log SHA256 is
`c906d2e6b65bd0ff5296b4621d0a60ef07b5e41a5ff863ff9ae0f7b52d5b236b`.

## Exact scope and remaining interface

The model does **not** satisfy the common cubic-vertex equations and does
not claim closure under a complement matching.  In particular, its lack of
an A vector is by pool design, not a cubic local consequence.  The result
therefore proves only the strict boundary

\[
\text{Tait-empty} + \text{40 positive types} + \neg(T\text{-loop},T\text{--}T)
 + \text{global binary incidence}
\not\Rightarrow \text{D5 join/A}
\]

without shared trivalent incidence.  A genuine proof must use that omitted
layer (or whole-graph connectivity); a genuine counterexample must realize
the same obstruction in one simple connected cubic 5-pole.

The edge-replacement observation in Note 045 independently explains why
Tait-emptiness itself is not visible to BF support: a Petersen two-pole can
force Tait-emptiness while preserving all boundary support.  It does not
preserve the Case-XII cyclic-connectivity hypotheses, so it is not a real
counterexample either.
