#!/usr/bin/env python3
"""Fixed n=13 CEGAR pulse for the Tait-empty two-hit interface.

This is a deliberately small strengthening of the common cubic-pole /
perfect-matching incidence encoding.  It adds two necessary conditions for a
Tait-empty Case-XII pole:

* one canonical singleton PM from each terminal class intersects every other
  canonical singleton PM on a proper edge;
* in each of the five selected S-loop six-PM witnesses, at least two of the
  three repeated-occurrence pairs are genuinely different.

The evaluator still re-enumerates the complete PM family and lazily blocks
extra BF support, an A-cover, D5 joins, and every concrete Tait colouring.
Thus a timeout/round limit is only a bounded solver result, never UNSAT.
The order is fixed at n=13 to keep this pulse a minimal structural test.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from itertools import combinations
from pathlib import Path

from z3 import And, Not, Or, Xor


HERE = Path(__file__).resolve().parent
LOCAL_BASE = HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
BUNDLED_BASE = HERE / "synthesize_exact40_joint_pb.py"
BASE_PATH = LOCAL_BASE if LOCAL_BASE.exists() else BUNDLED_BASE
spec = importlib.util.spec_from_file_location("exact40_twohit_base", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = BASE
spec.loader.exec_module(BASE)


def _different(first, second, edges):
    """Boolean expression saying that two same-boundary PM slots differ."""
    return Or(*(Xor(first[edge], second[edge]) for edge in edges))


def build_solver(n: int):
    solver, x, edges, witness_vars = BASE.build_solver(n)

    # Necessary Tait-empty gate: canonical selected singleton PMs from
    # distinct terminal classes must intersect on a proper edge.  This is a
    # compact necessary condition, not a complete Tait-emptiness encoding.
    by_terminal = {i: [] for i in BASE.TERMINALS}
    for (kind, slot), y in witness_vars.items():
        boundary = BASE.slots_for_type(kind)[slot]
        if len(boundary) == 1:
            terminal = next(iter(boundary))
            by_terminal[terminal].append(y)
    if any(not values for values in by_terminal.values()):
        raise RuntimeError("missing canonical singleton slot")
    canonical = {terminal: values[0] for terminal, values in by_terminal.items()}
    for left, right in combinations(BASE.TERMINALS, 2):
        solver.add(Or(*(And(canonical[left][edge], canonical[right][edge])
                        for edge in edges)))

    # Two-hit S-loop gate.  For kind (s,s), slots 0/1 are the two Q_{ij}
    # occurrences, 2/3 the P_i occurrences, and 4/5 the P_j occurrences.
    # At least two of these three occurrence pairs must differ in a
    # Tait-empty six-matching witness (the two-hit fibre lemma).
    for pair in sorted(BASE.S):
        kind = (pair, pair)
        slots = [witness_vars[(kind, slot)] for slot in range(6)]
        differences = [
            _different(slots[0], slots[1], edges),
            _different(slots[2], slots[3], edges),
            _different(slots[4], slots[5], edges),
        ]
        solver.add(Or(And(differences[0], differences[1]),
                      And(differences[0], differences[2]),
                      And(differences[1], differences[2])))

    return solver, x, edges, witness_vars


def tait_colourings(n: int, proper_edges):
    """Enumerate concrete singleton-pair Tait colourings of one pole."""
    matchings, classes = BASE.matching_classes(n, proper_edges)
    matching_set = {frozenset(matching) for matching in matchings}
    edge_count = len(proper_edges)
    all_objects = set(range(edge_count + len(BASE.TERMINALS)))
    out = []
    for first, second in combinations(BASE.TERMINALS, 2):
        first_family = classes.get(frozenset((first,)), ())
        second_family = classes.get(frozenset((second,)), ())
        for left in first_family:
            left_set = set(left)
            for right in second_family:
                right_set = set(right)
                if left_set & right_set:
                    continue
                third = frozenset(all_objects - left_set - right_set)
                if third in matching_set:
                    out.append((first, second, left, right, third))
    return tuple(out)


def run(n: int, max_rounds: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges, _ = build_solver(n)
    target_set = set(BASE.TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if str(status) == "unknown":
            rounds.append({"round": round_no, "status": "unknown"})
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("TAIT_EMPTY_TWOHIT_UNKNOWN")
            return payload
        if str(status) != "sat":
            rounds.append({"round": round_no, "status": "unsat"})
            payload = {"status": "unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("TAIT_EMPTY_TWOHIT_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(
            edge for edge, var in x.items()
            if bool(model.eval(var, model_completion=True))))
        result = BASE.evaluate(n, proper_edges)
        bad = []

        components = BASE.connected_components(n, proper_edges)
        if len(components) != 1:
            side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
            crossing = frozenset(edge for edge in edges
                                 if (edge[0] in side) ^ (edge[1] in side))
            solver.add(Or([x[e] for e in crossing]))
            bad.append({"kind": "disconnected", "side": sorted(side)})
        else:
            for bridge, side in BASE.bridge_cuts(n, proper_edges):
                crossing = frozenset(edge for edge in edges
                                     if edge != bridge
                                     and ((edge[0] in side) ^ (edge[1] in side)))
                if crossing:
                    solver.add(Or([x[e] for e in crossing]))
                else:
                    solver.add(Not(x[bridge]))
                bad.append({"kind": "bridge", "bridge": list(bridge),
                            "side": sorted(side)})

        colourings = tait_colourings(n, proper_edges)
        if colourings:
            solver.add(BASE.clause_for_union(x, edges, proper_edges))
            bad.append({"kind": "tait_nonempty", "colourings": len(colourings),
                        "states": sorted({(a, b) for a, b, *_ in colourings})})

        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A", "union_size": len(union)})

        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        for omitted, union, _, _ in result["join_data"]:
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "D5_join", "omitted": str(omitted),
                        "union_size": len(union)})

        cert = BASE.graph_certificate(n, proper_edges, result)
        cert["tait_colourings"] = len(colourings)
        cert["tait_states"] = sorted({(a, b) for a, b, *_ in colourings})
        cert["two_hit_static_gate"] = True
        cert["canonical_intersection_gate"] = True
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and result["a_witness"] is None
                and not any(result["joins"])
                and not colourings):
            payload = {"status": "real_tait_empty_exact40_twohit_joinfree",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                                    encoding="utf-8")
            print("REAL_TAIT_EMPTY_EXACT40_TWOHIT_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("TAIT_EMPTY_TWOHIT_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--max-rounds", type=int, default=20)
    parser.add_argument("--timeout-ms", type=int, default=300000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.n != 13:
        raise SystemExit("this pulse is intentionally fixed at n=13")
    run(args.n, args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
