#!/usr/bin/env python3
"""Verify a transport-decorated exact-40 token hypergraph.

This checks the literal conclusions of Notes 055 and 057, not common binary
edge incidence.  That distinction is part of the result.
"""

from itertools import combinations_with_replacement


S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
U_BOUNDARY = {"A": 1, "B": 2, "C": 4, "D": 5, "X": 3, "Y": 3}
LITERAL_SEEDS = {
    ((1, 3), (4, 5)): (("q13", "A", "X"), ("r45", "C", "D")),
    ((1, 4), (2, 3)): (("q14", "A", "C"), ("r23", "B", "X")),
    ((2, 4), (1, 5)): (("q24", "B", "C"), ("r15", "A", "D")),
    ((2, 5), (3, 4)): (("q25", "B", "D"), ("r34", "Y", "C")),
}
OVERLAPS = {
    ((1, 3), (1, 2)): (1, 3, 2, 5),
    ((2, 4), (2, 3)): (2, 4, 3, 1),
    ((3, 5), (3, 4)): (3, 5, 4, 2),
    ((1, 4), (4, 5)): (4, 1, 5, 3),
    ((2, 5), (1, 5)): (5, 2, 1, 4),
}
TARGET_TUPLES = {
    ((3, 5), (2, 3)): frozenset(("B", "D", "X", "Y")),
    ((1, 3), (3, 4)): frozenset(("A", "C", "X", "Y")),
    ((3, 5), (1, 2)): frozenset(("A", "B", "D", "Y")),
}
ORDER19_SWITCHES = {
    "B": ("B*", 7, "C14@old-core"),
    "X": ("X*", 5, "C10@old-core+G1"),
    "A": ("A*", 4, "C8@old-core"),
    "C": ("C*", 6, "C12@old-core+G0"),
}


token_boundary = dict(U_BOUNDARY)
token_kind = {name: "singleton" for name in U_BOUNDARY}


def singleton(name, terminal):
    token_boundary.setdefault(name, terminal)
    assert token_boundary[name] == terminal
    token_kind.setdefault(name, "singleton")
    return name


def triple(name, state):
    boundary = tuple(sorted(set(range(1, 6)) - set(state)))
    token_boundary.setdefault(name, boundary)
    assert token_boundary[name] == boundary
    token_kind.setdefault(name, "triple")
    return name


def row_boundary_ok(row):
    load = {terminal: 0 for terminal in range(1, 6)}
    for token in row:
        value = token_boundary[token]
        for terminal in ((value,) if isinstance(value, int) else value):
            load[terminal] += 1
    return set(load.values()) == {2}


def main():
    # Five fixed T-halves give the Note-055 saturated ST columns.
    t_halves = {}
    for state in T:
        literal = next((right for (s, t), (_, right) in LITERAL_SEEDS.items() if t == state), None)
        if literal:
            triple(literal[0], state)
            singleton(literal[1], state[0])
            singleton(literal[2], state[1])
            t_halves[state] = literal
        else:
            t_halves[state] = (
                triple(f"R{state}", state),
                singleton(f"p{state}:{state[0]}", state[0]),
                singleton(f"p{state}:{state[1]}", state[1]),
            )

    st_rows = {}
    st_halves = {}
    for s in S:
        for t in T:
            literal = LITERAL_SEEDS.get((s, t))
            if literal:
                left, right = literal
                triple(left[0], s)
                singleton(left[1], s[0])
                singleton(left[2], s[1])
                assert right == t_halves[t]
            else:
                left = (
                    triple(f"Q{s}@{t}", s),
                    singleton(f"p{s}@{t}:{s[0]}", s[0]),
                    singleton(f"p{s}@{t}:{s[1]}", s[1]),
                )
            st_halves[(s, t)] = left
            st_rows[(s, t)] = (left + t_halves[t],)
            assert row_boundary_ok(st_rows[(s, t)][0])

    # Five common S-half tokens give exactly the 15 unordered SS cells and
    # encode the dual loop-to-column saturation of Note 055.
    s_halves = {}
    for s in S:
        s_halves[s] = (
            triple(f"QS{s}", s),
            singleton(f"ps{s}:{s[0]}", s[0]),
            singleton(f"ps{s}:{s[1]}", s[1]),
        )
    ss_rows = {}
    for first, second in combinations_with_replacement(S, 2):
        row = s_halves[first] + s_halves[second]
        ss_rows[(first, second)] = (row,)
        assert row_boundary_ok(row)

    # Name both literal Note-057 transports for each of the five overlap rows.
    transport_rows = []
    for (s, t), (i, a, j, b) in OVERLAPS.items():
        left = st_halves[(s, t)]
        right = t_halves[t]
        p_i0 = next(token for token in left[1:] if token_boundary[token] == i)
        p_a = next(token for token in left[1:] if token_boundary[token] == a)
        p_i1 = next(token for token in right[1:] if token_boundary[token] == i)
        p_j = next(token for token in right[1:] if token_boundary[token] == j)
        target_s = tuple(sorted((a, b)))
        assert target_s in S and set(target_s).isdisjoint(t)

        p_b0 = singleton(f"transport:{s},{t}:b0", b)
        p_b1 = singleton(f"transport:{s},{t}:b1", b)
        q0 = triple(f"transport:{s},{t}:q0", target_s)
        q1 = triple(f"transport:{s},{t}:q1", target_s)
        row0 = (q0, right[0], p_a, p_b0, p_i1, p_j)
        row1 = (q1, right[0], p_a, p_b1, p_i0, p_j)
        assert row_boundary_ok(row0) and row_boundary_ok(row1)
        original_singletons = set(left[1:] + right[1:])
        assert len(original_singletons & set(row0[2:])) == 3
        assert len(original_singletons & set(row1[2:])) == 3
        st_rows[(target_s, t)] += (row0, row1)
        transport_rows.extend((row0, row1))

    # Embed the actual order-19 switch endpoints as named but row-inactive
    # tokens.  Thus all Note-055/057 transports exist while none uses an exact
    # component-repair endpoint or its missing companion.
    repair_tokens = set()
    for source, (target, _, _) in ORDER19_SWITCHES.items():
        singleton(target, token_boundary[source])
        repair_tokens.add(target)
    all_rows = tuple(row for rows in ss_rows.values() for row in rows) + tuple(
        row for rows in st_rows.values() for row in rows
    )
    assert repair_tokens.isdisjoint(token for row in all_rows for token in row)

    # The four literal rows are exact, while all three literal target tuples
    # are absent despite their positive cells having named witnesses.
    for cell, (left, right) in LITERAL_SEEDS.items():
        assert left + right in st_rows[cell]
    for cell, target in TARGET_TUPLES.items():
        assert cell in st_rows
        assert all(
            frozenset(token for token in row if token_kind[token] == "singleton") != target
            for row in st_rows[cell]
        )

    assert len(ss_rows) == 15 and len(st_rows) == 25
    assert len(transport_rows) == 10
    print({
        "SS_positive_cells": len(ss_rows),
        "ST_positive_cells": len(st_rows),
        "named_057_transport_rows": len(transport_rows),
        "literal_order19_rows": len(LITERAL_SEEDS),
        "literal_target_fibres_present": 0,
        "order19_component_repair_tokens_used_by_transports": 0,
        "negative_Tloop_TT_cells": 0,
        "model_level": "token-hypergraph; no common edge-incidence vectors",
    })
    print("TRANSPORT_DECORATED_ORDER19_HYPERGRAPH_VERIFIED")


if __name__ == "__main__":
    main()
