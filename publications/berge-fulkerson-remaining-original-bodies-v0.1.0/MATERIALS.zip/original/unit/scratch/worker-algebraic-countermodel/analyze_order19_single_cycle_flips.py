#!/usr/bin/env python3
"""Classify one-cycle flips around the three overloaded order-19 targets."""

from collections import Counter, defaultdict
from itertools import combinations_with_replacement, product
from pathlib import Path
from runpy import run_path


BASE = run_path(
    Path(__file__).resolve().parents[2]
    / "computations/bundles/guarded-repeated-star-selected-pm-countermodel/verify.py"
)
PROPER = BASE["PROPER"]
TERMINALS = BASE["TERMINALS"]
VECTORS = {name: BASE["guarded_objects"](name) for name in BASE["BASE_BOUNDARY"]}
S_STATES = BASE["S_STATES"]
T_STATES = tuple(
    state
    for state in combinations_with_replacement(range(1, 6), 2)
    if len(set(state)) == 2 and state not in S_STATES
)
OBJECTS = tuple(PROPER) + tuple(f"s{i}" for i in sorted(TERMINALS))
OBJECT_SET = frozenset(OBJECTS)
OBJECT_INDEX = {edge: index for index, edge in enumerate(OBJECTS)}

TARGETS = {
    "BDXY": ("B", "D", "X", "Y"),
    "ACXY": ("A", "C", "X", "Y"),
    "ABDY": ("A", "B", "D", "Y"),
}
OVERLOAD_TRIPLES = {
    "BDXY": ("B", "D", "X"),
    "ACXY": ("C", "X", "Y"),
    "ABDY": ("A", "D", "Y"),
}
LITERAL_OVERLOAD_EDGE = {
    "BDXY": (0, 10),
    "ACXY": (1, 5),
    "ABDY": (3, 9),
}


def matching_key(matching):
    return sum(1 << OBJECT_INDEX[edge] for edge in matching)


def boundary(matching):
    return tuple(i + 1 for i in range(5) if f"s{i}" in matching)


def cycle_components(difference):
    assert not any(isinstance(edge, str) for edge in difference)
    adjacency = defaultdict(list)
    for edge in difference:
        u, v = edge
        adjacency[u].append((v, edge))
        adjacency[v].append((u, edge))
    assert all(len(entries) == 2 for entries in adjacency.values())
    unseen = set(difference)
    output = []
    while unseen:
        start = next(iter(unseen))
        stack = [start[0]]
        vertices = {start[0]}
        component = set()
        while stack:
            vertex = stack.pop()
            for neighbour, edge in adjacency[vertex]:
                if edge not in component:
                    component.add(edge)
                if neighbour not in vertices:
                    vertices.add(neighbour)
                    stack.append(neighbour)
        unseen -= component
        assert len(component) == len(vertices)
        output.append(frozenset(component))
    return tuple(output)


def loads(row):
    return Counter(edge for matching in row for edge in matching)


def is_double_cover(row):
    edge_loads = loads(row)
    return all(edge_loads[edge] == 2 for edge in OBJECTS)


def is_nonoverloaded(row):
    return max(loads(row).values(), default=0) <= 2


def complement(state):
    return tuple(sorted(set(range(1, 6)) - set(state)))


def main():
    family = tuple(sorted(BASE["enumerate_all_perfect_matchings"](), key=matching_key))
    assert len(family) == 66
    matching_id = {matching: f"M{index:02d}" for index, matching in enumerate(family)}
    classes = defaultdict(list)
    for matching in family:
        classes[boundary(matching)].append(matching)

    # All one-alternating-cycle neighbours of the six literal singleton PMs.
    neighbours = defaultdict(list)
    for source_name, source in VECTORS.items():
        if source_name not in "ABCDXY":
            continue
        for candidate in classes[boundary(source)]:
            if candidate == source:
                continue
            components = cycle_components(source ^ candidate)
            if len(components) == 1:
                component = components[0]
                neighbours[source_name].append((len(component) // 2, candidate, component))
        neighbours[source_name].sort(key=lambda item: (item[0], matching_key(item[1])))

    # Map every singleton PM occurring in some complete-family forbidden row
    # to one explicit T-loop/TT witness.
    forbidden_witness = {}
    forbidden_types = set()
    for first, second in combinations_with_replacement(T_STATES, 2):
        for row in product(
            classes[complement(first)],
            classes[complement(second)],
            *(classes[(terminal,)] for terminal in first + second),
        ):
            if not is_double_cover(row):
                continue
            forbidden_types.add((first, second))
            for matching in row[2:]:
                forbidden_witness.setdefault(matching, ((first, second), row))
    assert len(forbidden_types) == 15

    report = {}
    for target_name, roles in TARGETS.items():
        literal_row = tuple(VECTORS[name] for name in roles)
        assert not is_nonoverloaded(literal_row)
        outcomes = []
        for source_name in OVERLOAD_TRIPLES[target_name]:
            position = roles.index(source_name)
            for distance, replacement, component in neighbours[source_name]:
                replaced = list(literal_row)
                replaced[position] = replacement
                clears_literal = loads(replaced)[LITERAL_OVERLOAD_EDGE[target_name]] <= 2
                fully_nonoverloaded = is_nonoverloaded(replaced)
                forbidden = forbidden_witness.get(replacement)
                outcomes.append({
                    "source": source_name,
                    "source_id": matching_id[VECTORS[source_name]],
                    "replacement": replacement,
                    "replacement_id": matching_id[replacement],
                    "distance": distance,
                    "component": component,
                    "clears_literal_overload": clears_literal,
                    "fully_nonoverloaded": fully_nonoverloaded,
                    "forbidden": forbidden,
                })

        clears = [outcome for outcome in outcomes if outcome["clears_literal_overload"]]
        fixes = [outcome for outcome in outcomes if outcome["fully_nonoverloaded"]]
        forbidden = [outcome for outcome in outcomes if outcome["forbidden"]]
        clear_and_forbidden = [outcome for outcome in clears if outcome["forbidden"]]
        fix_and_forbidden = [outcome for outcome in fixes if outcome["forbidden"]]
        assert clears and forbidden
        assert len(forbidden) == len(outcomes)
        assert len(clear_and_forbidden) == len(clears)

        def compact(outcome):
            item = {
                "source": f"{outcome['source']}={outcome['source_id']}",
                "replacement": outcome["replacement_id"],
                "replacement_edges": tuple(sorted(outcome["replacement"], key=str)),
                "distance": outcome["distance"],
                "alternating_component": tuple(sorted(outcome["component"])),
            }
            if outcome["forbidden"]:
                forbidden_type, row = outcome["forbidden"]
                item["forbidden_type"] = forbidden_type
                item["forbidden_row"] = tuple(matching_id[matching] for matching in row)
            return item

        min_clear = min(outcome["distance"] for outcome in clears)
        min_fix = min((outcome["distance"] for outcome in fixes), default=None)
        min_forbidden = min(outcome["distance"] for outcome in forbidden)
        min_clear_forbidden = min(
            (outcome["distance"] for outcome in clear_and_forbidden), default=None
        )
        min_fix_forbidden = min(
            (outcome["distance"] for outcome in fix_and_forbidden), default=None
        )
        report[target_name] = {
            "literal_overload_edge": LITERAL_OVERLOAD_EDGE[target_name],
            "minimum_clear_distance": min_clear,
            "clear_witness": compact(next(
                o for o in clears if o["distance"] == min_clear
            )),
            "minimum_full_repair_distance": min_fix,
            "full_repair_witness": compact(next(
                (o for o in fixes if o["distance"] == min_fix), None
            )) if min_fix is not None else None,
            "minimum_forbidden_distance": min_forbidden,
            "forbidden_witness": compact(next(
                o for o in forbidden if o["distance"] == min_forbidden
            )),
            "minimum_clear_and_forbidden_distance": min_clear_forbidden,
            "clear_and_forbidden_witness": compact(next(
                (o for o in clear_and_forbidden if o["distance"] == min_clear_forbidden),
                None,
            )) if min_clear_forbidden is not None else None,
            "minimum_full_repair_and_forbidden_distance": min_fix_forbidden,
            "full_repair_and_forbidden_witness": compact(next(
                (o for o in fix_and_forbidden if o["distance"] == min_fix_forbidden),
                None,
            )) if min_fix_forbidden is not None else None,
            "one_cycle_neighbours_checked": len(outcomes),
            "literal_clearing_neighbours": len(clears),
            "all_neighbours_enter_forbidden_support": True,
        }

    print({
        "complete_pm_family": len(family),
        "forbidden_TT_types": len(forbidden_types),
        "literal_ids": {name: matching_id[VECTORS[name]] for name in "ABCDXY"},
        "results": report,
    })
    print("ORDER19_SINGLE_CYCLE_FLIPS_CLASSIFIED")


if __name__ == "__main__":
    main()
