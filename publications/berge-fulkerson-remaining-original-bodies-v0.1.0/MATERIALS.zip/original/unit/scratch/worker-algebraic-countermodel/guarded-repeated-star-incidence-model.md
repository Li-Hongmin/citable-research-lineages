# A guarded common-trivalent incidence model still overloads all three targets

The common-trivalent incidence axioms, even supplemented by the absence of
every (T)-loop and (T)--(T) BF row **inside the designated matching
universe** and the elementary shared-edge consequence of no (T)-loops, do
not force a nonoverloaded target in the repeated-extension star.  There is a
finite model with fourteen designated actual perfect matchings of one simple
connected cubic 5-pole in which the four pivot rows are literal double
covers, all three targets are overloaded, every (T)-pair of singleton
identities shares an edge, and exhaustive enumeration of the designated
universe gives only (S)--(T) BF rows.

This is not a Case-XII pole: the common graph has additional perfect
matchings outside the designated universe.  Thus the result isolates full
perfect-matching closure, rather than local trivalent incidence or finitely
many negative rows, as the missing axiom.

## Construction

Start with the order-eleven pole and its fourteen designated matchings from
Note 080.  Their four pivot rows are

\[
 (q_{13},r_{45},A,X,C,D),\quad
 (q_{14},r_{23},A,B,X,C),\quad
 (q_{24},r_{15},A,B,C,D),\quad
 (q_{25},r_{34},B,Y,C,D).
\]

Within this fourteen-identity universe, exhaustive six-multiset enumeration
gives nine BF rows: five (S)--(T), one (S)-loop, and precisely three
(T)--(T) rows,

\[
 BBYYr_{23}r_{23},\qquad
 BCDYr_{45}r_{23},\qquad
 CCDD r_{45}r_{45}.
\]

Partition the identities into three colours

\[
 \begin{aligned}
 E_0&=\{A,C,Y\},\\
 E_1&=\{B,D,r_{23},r_{45}\},\\
 E_2&=\{X,q_{13},q_{14},q_{24},q_{25},r_{15},r_{34}\}.
 \end{aligned}
\]

Every pivot row meets each (E_i) twice.  Each of the three forbidden rows
has a colour count different from ((2,2,2)).  Append a (K_4) factor by
assigning its three perfect matchings to the three colour classes.  To keep
the common pole connected and simple, take a 2-sum between the colour-zero
edge (11,12) of this (K_4) and the old edge (4,6), whose designated
signature is exactly (E_0).  The replacement edges are (4,11) and
(6,12).

Call this first guard (G_0).  Each of the fourteen identities remains a
perfect matching of the same simple connected order-fifteen cubic 5-pole.
The colour balance preserves all four pivot double covers.  The old proper
edges (0,10,1,5,3,9)
retain signatures (BDX,CXY,ADY), respectively, so the targets

\[
 BDXY,\qquad ACXY,\qquad ABDY
\]

are all overloaded.  Conversely, any BF row in the augmented designated
universe must already have been one of the nine old rows and must have colour
count ((2,2,2)).  Exactly five (S)--(T) rows survive.  Hence no
(T)-loop or off-diagonal (T)--(T) row survives after (G_0).

## The shared-edge strengthening

Among (A,B,C,D,X,Y), with (X,Y) both in singleton boundary class (3),
the pairs whose two boundary labels form a (T)-state are

\[
 AB,\ AD,\ BX,\ BY,\ CX,\ CY,\ CD.                 \tag{1}
\]

The original pole together with (G_0) already supplies common edges for
(AD,BX,CX,CY).  The remaining pairs (AB,BY,CD) can all be supplied by
one further legal three-colour partition,

\[
 \begin{aligned}
 F_0&=\{A,B,Y,q_{13}\},\\
 F_1&=\{C,D,q_{14}\},\\
 F_2&=\{X,r_{45},r_{23},q_{24},r_{15},q_{25},r_{34}\}.
 \end{aligned}                                    \tag{2}
\]

Every pivot row again meets each (F_i) twice.  More strongly, (F_2) is
exactly the complete designated-identity signature of the current proper
edge (6,9).  Therefore a second (K_4) guard (G_1) can be joined by a
2-sum along its (F_2)-edge and (6,9).  This uses only one extra guard,
not two disconnected abstract blocks, and produces a simple connected
order-nineteen cubic 5-pole.

The (F_0)-edges witness (AB) and (BY); the (F_1)-edges witness (CD).
Together with the four old witnesses, every pair in (1) now shares an actual
edge.  The three old overloaded target edges are untouched.  Exhaustion over
the fourteen-identity universe leaves exactly the four pivot (S)--(T)
rows and no other BF row.

## Exact boundary

The construction refutes an implication formulated only for a selected
common PM-incidence universe:

\[
 \begin{gathered}
 \text{trivalent vertex equations}+
 \text{four literal pivot rows}+
 \text{no designated }T\text{-loop}/TT+\\
 \text{every singleton }T\text{-pair shares an edge}
 \end{gathered}
 \not\Longrightarrow
 \text{a nonoverloaded prescribed target}.
\]

It does not refute the genuine Case-XII implication, because negative support
there quantifies over the complete perfect-matching family of the pole.  In
fact, completing the order-nineteen graph's PM family reintroduces forbidden
types: the complete family has 66 perfect matchings and support profile
((SS,ST,TT)=(7,17,15)).  Therefore the sharp remaining interface is a
closure theorem: show
that any complete common cubic PM family containing this guarded overload
pattern necessarily adds a (T)-loop or (T)--(T) cover (or else supplies
a nonoverloaded target).

Reproduce with

```text
python3 units/berge-fulkerson/computations/bundles/guarded-repeated-star-selected-pm-countermodel/verify.py
```

The terminal marker is
`GUARDED_REPEATED_STAR_INCIDENCE_MODEL_VERIFIED`.
