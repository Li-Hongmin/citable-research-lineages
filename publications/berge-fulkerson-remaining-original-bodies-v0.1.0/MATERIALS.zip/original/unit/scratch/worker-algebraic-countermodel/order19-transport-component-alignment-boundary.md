# Exact-40 row transports do not encode component alignment

The literal conclusions of Notes 055 and 057 do not force any of the
order-nineteen target-repair components to acquire an external companion.
A finite token hypergraph simultaneously has all fifteen (S)--(S) cells,
all twenty-five (S)--(T) cells, the four literal failed-star rows, both
named Note-057 transports from each cyclic overlap row, and none of the three
literal target fibres.  None of the four actual order-nineteen single-cycle
repair endpoints is used by a transport row.

This is a relation-level stopping boundary, not a common binary-incidence
countermodel.  On the fixed order-nineteen graph a stronger model is
impossible: its complete 66-perfect-matching family has support profile
((SS,ST,TT)=(7,17,15)), so no selection of its actual perfect matchings can
create the missing exact-40 cells.  Changing that fact would require changing
or expanding the graph, which is outside this leaf.

## Named hypergraph

For each (tin T), fix one three-token (T)-half (K_t).  For every
(sin S), introduce a three-token (S)-half (H_{s,t}) and declare
(H_{s,t}cup K_t) to be the witness of cell ((s,t)).  At the four cells

\[
(13,45),\quad(14,23),\quad(24,15),\quad(25,34),
\]

use the literal order-nineteen halves, giving exactly

\[
q_{13}r_{45}AXCD,quad q_{14}r_{23}ABXC,quad
q_{24}r_{15}ABCD,quad q_{25}r_{34}BYCD.
\]

The fixed (K_t) tokens name the full Note-055 column transports.  For the
fifteen (S)--(S) cells, use five common halves (L_s) and the rows
(L_scup L_{s'}); fixing either half names the dual loop-to-column
transport.

For each of the five overlap rows in Note 057, the verifier adds both
transported rows in its associated disjoint cell.  Each row retains exactly
the prescribed three singleton identities and the fixed triple identity,
and introduces only the allowed new singleton identity.  Thus all ten
matching-reuse conclusions are literal rather than support flags.

Finally add the four labelled order-nineteen switch endpoints

\[
B\xrightarrow[C_{14}]{7}B^*,\qquad
X\xrightarrow[C_{10}]{5}X^*,\qquad
A\xrightarrow[C_8]{4}A^*,\qquad
C\xrightarrow[C_{12}]{6}C^*.
\]

They are present as matching tokens but occur in no transported row.  The
positive target cells have private witnesses, while the exact singleton
tuples (BDXY,ACXY,ABDY) remain absent.

## What this adds, and what it does not

Compared with a bare no-common-section relation hypergraph, this model adds:

1. the fourteen named order-nineteen identities and four literal BF rows;
2. the three specific overloaded target tuples;
3. fixed matching-level halves for all five saturated columns;
4. all ten three-singleton-reuse transports of Note 057;
5. the four actual repair-component endpoints and their distances.

It still has no common edge coordinates, no trivalent vertex partitions, and
no perfect-matching closure.  Therefore it proves only

\[
\text{exact-40 support + the stated row transports}
\not\Longrightarrow
\text{component companion alignment}
\]

as a statement about the explicit transport relations.  It does not prove
the corresponding implication false for common cubic perfect-matching
incidence.  That remaining layer must use edgewise equations connecting the
private cell witnesses to the four literal rows.

The deterministic verifier is
`verify_transport_decorated_order19_hypergraph.py`.  It was run on Omen in a
single Python process and terminates with
`TRANSPORT_DECORATED_ORDER19_HYPERGRAPH_VERIFIED`.
