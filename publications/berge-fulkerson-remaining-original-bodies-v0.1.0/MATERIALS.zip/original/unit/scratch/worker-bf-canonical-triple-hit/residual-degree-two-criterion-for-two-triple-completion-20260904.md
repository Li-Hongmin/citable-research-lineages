# Residual degree-two criterion for completing four singleton matchings

This is a scratch theorem.  It is derived directly from the definitions and
does not enumerate poles or matching families.

## Setup

Let \(H\) be a cubic 5-pole with terminal semiedges indexed by
\([5]\).  Let \(P_1,\ldots,P_4\) be actual singleton-boundary perfect
matching occurrences whose boundary multiset is the multiset union of two
terminal pairs \(s,t\).  Repetitions among the \(P_i\) are allowed.  On
every proper edge or semiedge \(e\), define

\[
 D(e)=2-\sum_{i=1}^4\chi_{P_i}(e).                 \tag{1}
\]

Write \(Q_s\) for a desired perfect matching with triple boundary
\([5]\setminus s\), and \(R_t\) for one with triple boundary
\([5]\setminus t\).

## Residual multigraph and terminal colours

Assume first that \(D(e)\ge0\) for every edge.  Replace each proper edge and
semiedge \(e\) by \(D(e)\) labelled copies.  Denote the resulting residual
multigraph by \(\mathcal D\).  Since every \(P_i\) meets each internal
vertex once,

\[
 \sum_{e\ni v}D(e)
 =6-\sum_{i=1}^4\sum_{e\ni v}\chi_{P_i}(e)
 =6-4=2.                                           \tag{2}
\]

Thus every internal vertex of \(\mathcal D\) has degree two.  Its components
are closed cycles or paths whose two ends are residual semiedge copies.
Parallel proper-edge copies and repeated semiedge copies are retained as
different copies.

Colour a residual copy red if it is to belong to \(Q_s\), and blue if it is
to belong to \(R_t\).  For terminal \(j\), its residual multiplicity is

\[
 D(j)=2-\mathbf1_{j\in s}-\mathbf1_{j\in t}.       \tag{3}
\]

The required endpoint colours are therefore:

- if \(D(j)=0\), there is no residual terminal copy;
- if \(D(j)=1\) and \(j\in s\setminus t\), its unique copy is blue;
- if \(D(j)=1\) and \(j\in t\setminus s\), its unique copy is red;
- if \(D(j)=2\), the two copies must receive one red and one blue.

When \(D(j)=2\), both copies are incident with the same internal vertex and
already exhaust its residual degree two.  They form one path component with
zero proper edges, so alternating colours automatically give one red and one
blue.

## Completion theorem

There exist actual perfect matchings \(Q_s,R_t\) such that

\[
 D=\chi_{Q_s}+\chi_{R_t}                            \tag{4}
\]

if and only if all three conditions below hold.

1. **Edge nonnegativity.**  For every proper edge and semiedge,
   \[
   D(e)\in\{0,1,2\}.
   \tag{5}
   \]

2. **Closed-cycle parity.**  Every closed-cycle component of
   \(\mathcal D\), with edge copies counted with multiplicity, has even
   length.  In particular, two copies of one proper edge form an allowed
   2-cycle.

3. **Terminal-path compatibility.**  Every terminal path admits alternating
   red-blue edge colours with the endpoint colours prescribed above.
   Equivalently, if a path has \(k\) proper-edge copies and its endpoint
   colour bits are \(c_0,c_1\in\{0,1\}\), where red is zero and blue is one,
   then
   \[
   c_0\mathbin\oplus c_1\equiv k+1\pmod2.          \tag{6}
   \]
   Thus endpoints requiring the same colour need \(k\) odd, while endpoints
   requiring different colours need \(k\) even.  A multiplicity-two
   semiedge gives \(k=0\) and opposite endpoint colours, as required.

Condition 3 can be stated without colour names.  For a path joining two
multiplicity-one terminals:

- endpoints both in \(s\setminus t\), or both in \(t\setminus s\), require
  an odd number of proper edges;
- one endpoint in \(s\setminus t\) and the other in \(t\setminus s\)
  requires an even number of proper edges.

The complete cell-by-cell specialization is:

- if \(s=t\), there are no multiplicity-one terminal ends; every
  \(j\notin s\) gives an automatic doubled-semiedge path, and only the
  closed-cycle parity condition remains;
- if \(|s\cap t|=1\), the two exclusive terminals are joined by the unique
  nontrivial terminal path and require an even number of proper edges;
- if \(s\cap t=\varnothing\), the four exclusive terminals are paired by
  two residual paths; a same-side pair requires odd proper length and a
  cross \(s\)-to-\(t\) pair requires even proper length.

The statement is symmetric under interchanging \((Q_s,s)\) and
\((R_t,t)\).

## Proof of necessity

Suppose (4) holds.  Every edge has residual multiplicity zero, one, or two,
so condition 1 holds.  Colour the copy contributed by \(Q_s\) red and the
copy contributed by \(R_t\) blue.  If both matchings contain the same edge,
its two residual copies receive different colours.

At every internal vertex, each of \(Q_s,R_t\) uses exactly one incident
edge.  The two residual incidences at the vertex therefore have opposite
colours.  Colours alternate on every component.  A closed alternating cycle
has even length, proving condition 2.  Along a terminal path with \(k\)
proper edges there are \(k+1\) internal vertices, hence \(k+1\) colour
changes between its semiedge ends.  This is exactly (6).

Finally, the boundary of \(Q_s\) is \([5]\setminus s\) and the boundary of
\(R_t\) is \([5]\setminus t\).  Formula (3) then forces precisely the
endpoint colours listed above.  Condition 3 follows.

## Proof of sufficiency

Assume conditions 1--3.  On every even closed-cycle component, colour edge
copies alternately red and blue; either initial colour may be chosen.  On
every terminal path, start with its prescribed first endpoint colour and
alternate.  Equation (6) says that the colour arriving at the other end is
the prescribed one.  The doubled-semiedge paths are handled by the same
rule with \(k=0\).  Components are independent, so this colours all copies
of \(\mathcal D\).

Every internal vertex is incident with one red and one blue residual copy.
Consequently the original edges carrying red copies form an actual perfect
matching \(Q\), and those carrying blue copies form an actual perfect
matching \(R\).  No colour can take both copies of a repeated edge, because
the copies share an endpoint and the two residual incidences there have
opposite colours.  Thus passing from labelled copies back to original edges
does not introduce a repeated edge in either matching.

The terminal colour prescription gives

\[
 \partial Q=[5]\setminus s,
 \qquad
 \partial R=[5]\setminus t.
\]

Hence \(Q=Q_s\), \(R=R_t\), and every edge has exactly its prescribed total
multiplicity \(D(e)\).  This proves (4).

## What the criterion isolates

Given four desired singleton identities, edge nonnegativity alone is not
sufficient.  An odd residual cycle or a terminal path with the wrong
endpoint parity is an exact obstruction to the two triple companions.
Conversely, there is no further global compatibility condition: once the
three displayed conditions hold, alternating each component constructs the
two actual companions.  Different even-cycle starting colours account for
all componentwise choices, modulo the allowed global interchange of the two
triple matchings.
