from itertools import permutations, product


PERMS = tuple(permutations(range(3)))
IDENTITY = PERMS.index((0, 1, 2))

# Variable order: a1, a2, a4, a5, x, y.
PIVOTS = (
    (0, 4, 2, 3),  # a1,x,a4,a5
    (0, 1, 4, 2),  # a1,a2,x,a4
    (0, 1, 2, 3),  # a1,a2,a4,a5
    (1, 5, 2, 3),  # a2,y,a4,a5
)
TARGETS = (
    (1, 3, 4, 5),  # a2,a5,x,y
    (0, 2, 4, 5),  # a1,a4,x,y
    (0, 1, 3, 5),  # a1,a2,a5,y
)


def completable(values: tuple[int, ...], quadruple: tuple[int, ...]) -> bool:
    """The four permutation matrices have no entry of multiplicity > 2."""
    return all(
        max(
            sum(PERMS[values[token]][row] == column for token in quadruple)
            for column in range(3)
        )
        <= 2
        for row in range(3)
    )


def classify() -> dict[tuple[bool, bool, bool], int]:
    # Common output relabelling normalizes a1 to the identity.
    counts: dict[tuple[bool, bool, bool], int] = {}
    for tail in product(range(6), repeat=5):
        values = (IDENTITY, *tail)
        if not all(completable(values, quadruple) for quadruple in PIVOTS):
            continue
        pattern = tuple(
            not completable(values, quadruple) for quadruple in TARGETS
        )
        counts[pattern] = counts.get(pattern, 0) + 1
    return counts


if __name__ == "__main__":
    result = classify()
    expected = {
        (False, False, False): 150,
        (False, False, True): 24,
        (False, True, False): 54,
        (False, True, True): 108,
        (True, False, False): 54,
        (True, False, True): 48,
        (True, True, False): 122,
    }
    assert result == expected
    assert sum(result.values()) == 560
    assert (True, True, True) not in result
    for pattern in sorted(result):
        print("".join("1" if bit else "0" for bit in pattern), result[pattern])
