# Single-component closure does not force companion alignment

## Decision

The repeated-extension real-pole statement remains unresolved. Standard
alternating-cycle closure does not force the companion alignment in Note
073, even when \(P\triangle P'\) has only one component.

Indeed, if

\[
P\triangle P'=C
\]

is a single proper alternating cycle, toggling a subset of its components
has only two outcomes: \(P'\) and \(P\). There is no intermediate
same-boundary perfect matching. Thus the closure of the pair
\(\{P,P'\}\) supplies no new phase with which to synchronize a transported
row from another carrier column.

This is a strict logical boundary for the alternating-cycle closure rule,
not a real Case-XII counterexample.

## Exact two-matching splice criterion

Suppose an actual BF row contains \(P'\) and another perfect matching \(N\),
while \(P\) is the desired same-boundary singleton matching. A row-preserving
replacement of these two matchings must have

\[
\chi_{P'}+\chi_N=\chi_P+\chi_{N'},
\qquad
\chi_{N'}=\chi_N+\chi_{P'}-\chi_P.                 \tag{1}
\]

When \(P\triangle P'=C\) is one cycle, the following are equivalent:

1. the vector \(N'\) in (1) is a perfect matching;
2. \(N\cap C=P\cap C\);
3. \(C\) is a connected component of \(N\triangle P'\).

Under these conditions, the bichromatic switch on \(C\) between \(P'\) and
\(N\) produces \(P\) and \(N'\), preserving the six-matching row sum.
Conversely, any two-matching splice confined to \(C\) must satisfy these
conditions.

The hypothesis that \(C\) is the sole component of \(P\triangle P'\) says
nothing about whether it is also a component of \(N\triangle P'\) for one
of the five companions in the row. This second incidence is precisely the
missing alignment.

## Consequence for the three target cells

For the canonical repeated-extension set

\[
U=\{a_1,a_2,a_4,a_5,x,y\},
\]

Note 073 reduces the desired contradiction to the three exact singleton
quadruples

\[
\begin{array}{c|c}
(35,23)&\{a_2,a_5,x,y\},\\
(13,34)&\{a_1,a_4,x,y\},\\
(35,12)&\{a_1,a_2,a_5,y\}.
\end{array}                                        \tag{2}
\]

Exact support gives at least one actual witness in each cell of (2), and
Notes 055 and 057 give within-carrier state changes and three-coordinate
transports. They do not assert that a wrong same-boundary singleton \(P'\)
in one of these witnesses has a companion \(N\) satisfying the equivalent
conditions above with the specified member \(P\in U\).

Therefore the thinnest sufficient additional statement is:

> In each of the three cells in (2), some transported witness can be changed
> to the displayed singleton tuple by a sequence of two-matching switches
> such that, at every replacement \(P'\to P\), every component of
> \(P\triangle P'\) is also a bichromatic component of
> \(N\triangle P'\) for a companion \(N\) in the current row.

In the single-component case this reduces exactly to condition 3 above.
Once the three target tuples are reached, Note 072 gives
\(\alpha(G_U)\le2\) and the six-singleton counting contradiction.

## Boundary

The complete perfect-matching family guarantees that every matching
obtained from an actual alternating-cycle toggle is present. It does not
guarantee that the required cycle is bichromatic with a companion belonging
to the same BF witness. Proving this cross-row bichromatic-component
incidence, or constructing a real Case-XII pole where it fails, is the first
undecided step. No endpoint calculation or closure of the pair
\(\{P,P'\}\) distinguishes it.
