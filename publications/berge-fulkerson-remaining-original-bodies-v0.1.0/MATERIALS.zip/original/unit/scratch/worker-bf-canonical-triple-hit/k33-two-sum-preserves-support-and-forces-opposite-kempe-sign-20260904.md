# A \(K_{3,3}\) two-sum preserves boundary support and forces opposite Kempe signs

This is a scratch argument for the exact-Case-XII interface left by Notes
055, 057, 073, and 075.  It is not a permanent note.

## Setup

Let \(H_0\) be a cubic 5-pole and let \(e=xy\) be a proper edge.  Let
\(K=K_{3,3}\), with bipartition

\[
 U=\{u_0,u_1,u_2\},\qquad V=\{v_0,v_1,v_2\},
\]

and distinguish \(f=u_0v_0\).  Form a new cubic 5-pole \(H\) by deleting
\(e,f\) from the disjoint union and adding

\[
 xv_0,\qquad u_0y.                                  \tag{1}
\]

The five semiedges of \(H\) are those of \(H_0\).  This operation will be
denoted by

\[
 H=H_0\oplus_{e,f}K_{3,3}.
\]

## Perfect matchings across the 2-edge cut

The two edges in (1) form the cut \(\delta(V(K))\).  For every perfect
matching \(M\) of \(H\),

\[
 |M\cap\delta(V(K))|\equiv |V(K)|\equiv0\pmod2,
\]

because summing the matching degrees over the six vertices of \(K\) gives

\[
 6=2|M\cap E(K-f)|+|M\cap\delta(V(K))|.
\]

The cut has size two, so a matching uses either neither cut edge or both.
It therefore has a unique pair of projections \((M_0,M_K)\):

- if it uses neither cut edge, take the two restrictions; then \(M_0\)
  avoids \(e\) and \(M_K\) avoids \(f\);
- if it uses both cut edges, delete them from the restrictions and restore
  \(e\) in the \(H_0\)-part and \(f\) in the \(K\)-part.

Conversely, a pair \((M_0,M_K)\) of perfect matchings splices uniquely when

\[
 \mathbf1_{e\in M_0}=\mathbf1_{f\in M_K}.           \tag{2}
\]

If the common value is zero, take their union.  If it is one, delete
\(e,f\) and insert the two edges in (1).  The boundary set of the spliced
matching is exactly the boundary set of \(M_0\).

Thus perfect matchings of \(H\) are in boundary-preserving bijection with
the fibre product in (2).

## BF support is preserved in both directions

Let \(W=(M_1,\ldots,M_6)\) be an ordered BF witness of \(H\).  Each edge in
(1) has load two.  Since every \(M_i\) uses both cut edges or neither, there
is one two-element set \(I\subseteq\{1,\ldots,6\}\) of through slots.
Projecting slot by slot gives ordered rows

\[
 W_0=(M_{0,1},\ldots,M_{0,6}),\qquad
 W_K=(M_{K,1},\ldots,M_{K,6}).
\]

Every old edge retains load two, while the restored edges \(e,f\) occur
exactly in the two slots in \(I\).  Hence \(W_0\) and \(W_K\) are BF
witnesses of \(H_0\) and \(K_{3,3}\), respectively.  The ordered boundary
word of \(W\) equals that of \(W_0\).

Conversely, let \(W_0\) and \(W_K\) be BF witnesses of the two factors.
Exactly two slots of \(W_0\) use \(e\), and exactly two slots of \(W_K\) use
\(f\).  Permute only the closed-gadget slots so that these two sets agree,
then splice corresponding matchings.  The resulting six matchings cover
the cut edges and every surviving factor edge exactly twice.  They form a
BF witness of \(H\) with the boundary word of \(W_0\).

It follows, for every BF boundary type \(b\), that

\[
 b\in\operatorname{BFsupp}(H)
 \quad\Longleftrightarrow\quad
 b\in\operatorname{BFsupp}(H_0).                   \tag{3}
\]

In particular, the operation creates neither a new \(T\)-loop nor a new
\(T\)--\(T\) type.

## Tait states are preserved in both directions

A Tait colouring is an ordered decomposition into three perfect matchings
with every edge used once.  In a Tait colouring of \(H\), each cut edge has
one colour.  The even-cut parity above forces the same colour to use both
cut edges.  Projection therefore gives Tait colourings of both factors.

Conversely, colour \(f\) in \(K_{3,3}\) with the colour of \(e\) in a Tait
colouring of \(H_0\), and splice the three colour classes.  This preserves
the five boundary colour sets.  Since \(K_{3,3}\) is Tait-colourable and
its colours may be permuted arbitrarily,

\[
 \operatorname{TaitStates}(H)
 =\operatorname{TaitStates}(H_0).                  \tag{4}
\]

Thus exact Tait state set \(S\) is also preserved.

## Two opposite-sign gadget covers with the same through slots

Represent a perfect matching of \(K_{3,3}\) by the permutation
\(\pi\in S_3\) for which \(u_i v_{\pi(i)}\) is selected.  A string \(abc\)
means \(\pi(0)=a,\pi(1)=b,\pi(2)=c\).  Consider

\[
 C_+=(012,012,120,120,201,201)                     \tag{5}
\]

and

\[
 C_-=(012,021,102,210,120,201).                    \tag{6}
\]

In (5), the three cyclic permutations form a 1-factorization and are each
used twice.  In (6), all six permutations occur once, and every edge
\(u_iv_j\) lies in exactly \((3-1)!=2\) of them.  Hence both rows are BF
covers.  In each row, precisely the first two slots use \(f=u_0v_0\).

Let

\[
 \kappa_K(C)=\prod_{i=1}^6\operatorname{sgn}(\pi_i).
\]

All three cyclic permutations in (5) are even, whereas (6) contains the
three even and three odd permutations of \(S_3\).  Therefore

\[
 \kappa_K(C_+)=+1,\qquad \kappa_K(C_-)=-1.          \tag{7}
\]

Given any BF witness \(W_0\) of \(H_0\), permute the slots of (5) and (6)
in parallel so that their two \(f\)-slots equal the two \(e\)-slots of
\(W_0\).  Splicing gives two BF witnesses \(W_+,W_-\) of \(H\) with exactly
the same ordered boundary word as \(W_0\).

## The local sign survives every proper paired switch

Every BF witness \(W\) of \(H\) projects to a BF cover
\(W_K=(N_1,\ldots,N_6)\) of \(K_{3,3}\).  Define its local gadget sign by

\[
 \kappa_K(W)=\prod_{i=1}^6\operatorname{sgn}(N_i). \tag{8}
\]

Consider an allowed synchronous switch of colours \(a,b\) on one proper
alternating-cycle component \(C\) of \(H\).

If \(C\) misses the 2-edge cut, it lies wholly on one side.  Its projection
either does nothing to \(W_K\), or is the same bichromatic cycle switch
inside \(K_{3,3}-f\).

If \(C\) meets the cut, it uses both cut edges.  Before the switch, one of
the two colours uses both cut edges and the other uses neither; a matching
cannot use exactly one.  The portion of \(C\) inside \(K-f\) is an
alternating path from \(u_0\) to \(v_0\).  Adding the restored edge \(f\)
closes it to a bichromatic alternating cycle \(D\) in \(K_{3,3}\), and the
projected change from \((N_a,N_b)\) is precisely the synchronous switch on
\(D\).

On an alternating cycle of length \(2k\), both permutation signs are
multiplied by \((-1)^{k-1}\).  Their product is unchanged.  The preceding
two cases therefore prove

\[
 \kappa_K(W')=\kappa_K(W)                           \tag{9}
\]

for every allowed proper paired switch in the whole pole \(H\).  Equations
(7)--(9) show that \(W_+\) and \(W_-\) lie in different boundary-fixed
Kempe classes.

This argument does not require \(H_0\) to be bipartite.  If \(H_0\) is
bipartite and the splice preserves the bipartitions, the global invariant
of Note 075 factorizes as

\[
 \kappa_H(W)=\kappa_{H_0}(W_0)\kappa_K(W_K).        \tag{10}
\]

Indeed, a non-through matching gives a block sum of the two partial
bijections.  A through matching differs from that block sum by one swap of
images and contributes an additional minus sign.  Exactly two slots are
through in a BF row, so the two additional signs cancel in the sixfold
product.  Consequently \(W_+\) and \(W_-\) also have opposite global
boundary-fixed \(\kappa_H\).

## Consequence for exact Case XII

Suppose \(H_0\) has exact Tait state set \(S\), has no BF \(T\)-loop or
\(T\)--\(T\) type, and has a witness in a fixed target cell \(b\).  By
(3)--(4), \(H\) has exactly the same Tait states and BF boundary support.
Nevertheless, the construction above supplies opposite local
\(\kappa_K\)-classes in \(\Omega_b(H)\).  Thus there is a strict dichotomy:

- if no such \(H_0\) exists, the exact-Case-XII class is empty;
- if one exists, negative support alone does not make the fixed-cell Kempe
  graph connected or its available sign invariant constant.

The conclusion is only a class obstruction.  For a prescribed singleton
tuple \(\tau\), let \(\Omega_b(\tau)\) be the target fibre and let \([W]_K\)
be the paired-switch class of a transported witness.  Companion alignment
still requires the strictly stronger condition

\[
 [W]_K\cap\Omega_b(\tau)\ne\varnothing.             \tag{11}
\]

Even constancy of a global or local \(\kappa\) would neither prove that
\(\Omega_b(\tau)\) is nonempty nor that two same-sign witnesses lie in the
same Kempe class.  Exact-40 support supplies an unspecified witness in the
cell, not the intersection in (11).
