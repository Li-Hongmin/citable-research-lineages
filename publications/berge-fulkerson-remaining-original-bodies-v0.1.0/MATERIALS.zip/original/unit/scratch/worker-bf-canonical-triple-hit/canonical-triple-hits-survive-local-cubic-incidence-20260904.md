# Canonical triple hits survive the local cubic endpoint equations

## Decision

The real-pole statement remains unresolved. Neither the two endpoints of a
fixed triple-hit proper edge nor the pairwise symmetric differences of its
three hitting singleton perfect matchings force the missing BF row.

For the canonical failed star of Note 072, every possible three-element
\(U\)-hit pattern admits a local trivalent realization at both ends of the
edge: every matching identity chooses exactly one of the three incident
edges, and every canonical BF row has local load \((2,2,2)\). This is a
strict local-incidence countermodel, not a global cubic 5-pole.

Thus the weaker proposed statement

> every actual triple-hit edge has its \(U\)-hit triple contained in the
> singleton part of an actual BF row

cannot follow from the local endpoint equations. A proof needs a global
alternating-component alignment or an equivalent cross-half-load
witness-reuse theorem.

## The eight possible hit triples

Use Note 072's singleton set

\[
U=\{a_1,a_2,a_4,a_5,x,y\}
\]

and its four singleton quadruples

\[
\begin{aligned}
A_s&=\{a_1,x,a_4,a_5\},&
B_s&=\{a_1,a_2,x,a_4\},\\
C_s&=\{a_1,a_2,a_4,a_5\},&
D_s&=\{a_2,y,a_4,a_5\}.
\end{aligned} \tag{1}
\]

At every proper edge, each set in (1) has load at most two because it is the
singleton part of a six-matching double-cover row. A three-subset of \(U\)
can therefore be a hit triple only if it is contained in none of these four
sets. The possibilities are exactly

\[
\begin{array}{c|c}
\text{one extension and two anchors}
 &a_1a_2y,\ a_1a_4y,\ a_1a_5y,\ a_2a_5x\\
\text{two extensions and one anchor}
 &a_1xy,\ a_2xy,\ a_4xy,\ a_5xy.
\end{array} \tag{2}
\]

No four-subset of \(U\) has all its triples in (2). Hence every proper edge
has \(U\)-load at most three, and a triple-hit edge has exactly one of the
eight patterns in (2). This also shows why controlling only an edge common
to all extension values is insufficient: both mixed forms must be excluded.

## Local trivalent realizations

Let the fourteen identities be the six elements of \(U\) and the eight
triple tokens

\[
q_A,r_{45},q_B,r_{23},q_C,r_{15},q_D,r_{34}
\]

from the canonical four rows. A legal local edge column is a subset of these
identities meeting every full row in exactly two occurrences. There are 147
such columns.

For each hit pattern \(H\) in (2), there are three pairwise disjoint legal
columns \(e,f,g\) whose union is all fourteen identities and whose
\(U\)-part on \(e\) is exactly \(H\). Representatives of the two mixed
forms are

\[
\begin{array}{c|l|l|l}
H&e&f&g\\ \hline
a_1a_2y
 &a_1,a_2,r_{45},y
 &q_A,q_C,q_D,r_{15},r_{23},r_{34},x
 &a_4,a_5,q_B\\
a_1xy
 &a_1,r_{15},r_{34},x,y
 &a_5,q_B,q_C,q_D,r_{23},r_{45}
 &a_2,a_4,q_A.
\end{array} \tag{3}
\]

Every canonical row meets each of \(e,f,g\) twice. Use the same partition at
each end of \(e\), with \(f,g\) represented by separate incident half-edges
at the two ends. Then every matching chooses exactly one incident edge at
each endpoint, while the four BF rows have the required local double-cover
load. The other six patterns have analogous partitions, checked by the
finite local verifier.

This partition certifies the endpoint equations for the four canonical
pivot rows only. It does not assert that the other thirty-six positive rows
of Note 072's product construction use these same three coordinates, nor
does it give a simultaneous pairing of all proper coordinates into a common
cubic graph.

## Why the immediate symmetric-difference switch stops

Let \(M_1,M_2,M_3\in U\) all contain \(e=uv\). For every pair
\(M_i,M_j\), the symmetric difference \(M_i\triangle M_j\) omits \(e\) and
has no edge incident with \(u\) or \(v\): both matchings already use \(e\)
at those vertices. Their alternating components are proper cycles disjoint
from the two endpoints. Switching only among the three hitting matchings
preserves the triple hit and provides no local route to a row containing all
three.

The exact additional datum needed for a splice can be stated
componentwise. Suppose column saturation or row transport produces a row
containing a singleton matching \(P'\), while the desired member of \(U\)
is a matching \(P\) with the same singleton boundary. Replacing \(P'\) by
\(P\) while preserving the row sum requires a companion \(N\) such that

\[
N'=N+\chi_{P'}-\chi_P. \tag{4}
\]

Since \(P\triangle P'\) is a union of proper alternating cycles, (4) is a
perfect matching exactly when \(N\) uses the \(P\)-edges on every component:

\[
N\cap(P\triangle P')=P\cap(P\triangle P'). \tag{5}
\]

Then \(N'\) is obtained by toggling all these components. Notes 055 and 057
guarantee the new decomposition and preserve specified singleton matchings,
but they do not guarantee the all-component companion alignment (5) with a
matching from a different pivot row.

## Exact sufficient reuse target

For the canonical six-set, Note 072 shows that the unique minimum completion
of its missing-pair graph requires

\[
a_1a_4,\qquad a_2a_5,\qquad a_4x. \tag{6}
\]

It is therefore enough to produce the following actual singleton
quadruples, using these exact PM identities:

\[
\begin{array}{c|c}
(35,23)&\{a_2,a_5,x,y\},\\
(13,34)&\{a_1,a_4,x,y\},\\
(35,12)&\{a_1,a_2,a_5,y\}.
\end{array} \tag{7}
\]

All three cells in (7) are Case-XII positive cells, so exact support supplies
some witnesses in them. The unresolved content is literal reuse of the
members of \(U\). A component-aligned splice satisfying (5) for the needed
replacements in (7) is a precise sufficient condition. It gives
\(\alpha(G_U)\le2\), and Note 072's six-singleton counting contradiction
then applies.

## Evidence boundary

The endpoint analysis proves only that local cubic incidence and symmetric
differences among the hitters do not decide the real statement. It neither
constructs a real Case-XII pole with a triple hit nor proves that one exists.
The first unverified implication is the passage from the within-column
decompositions of Notes 055 and 057 to the cross-column, all-component
companion alignment (5).

The verifier is verify_canonical_triple_hit_local_boundary.py and ends in
CANONICAL_TRIPLE_HIT_LOCAL_BOUNDARY_VERIFIED.
