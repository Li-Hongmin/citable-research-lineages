#!/usr/bin/env python3
"""Local cubic-endpoint boundary for canonical failed-star triple hits."""

from itertools import combinations, product


U = ("a1", "a2", "a4", "a5", "x", "y")
TRIPLES = ("qA", "r45", "qB", "r23", "qC", "r15", "qD", "r34")
NAMES = U + TRIPLES
ROWS = (
    ("qA", "r45", "a1", "x", "a4", "a5"),
    ("qB", "r23", "a1", "a2", "x", "a4"),
    ("qC", "r15", "a1", "a2", "a4", "a5"),
    ("qD", "r34", "a2", "y", "a4", "a5"),
)
SINGLETON_ROWS = tuple(frozenset(row[2:]) for row in ROWS)
EXPECTED_HITS = {
    frozenset(hit) for hit in (
        ("a1", "a2", "y"), ("a1", "a4", "y"),
        ("a1", "a5", "y"), ("a1", "x", "y"),
        ("a2", "a5", "x"), ("a2", "x", "y"),
        ("a4", "x", "y"), ("a5", "x", "y"),
    )
}


def allowed_columns():
    index = {name: i for i, name in enumerate(NAMES)}
    answer = []
    for bits in product((0, 1), repeat=len(NAMES)):
        if all(sum(bits[index[name]] for name in row) == 2 for row in ROWS):
            answer.append(frozenset(
                name for name, bit in zip(NAMES, bits, strict=True) if bit
            ))
    return tuple(answer)


def main():
    columns = allowed_columns()
    assert len(columns) == 147

    # A U-hit triple is possible exactly when none of the four known rows
    # already contains it.  Four or more U hits are impossible.
    uncovered = {
        frozenset(hit) for hit in combinations(U, 3)
        if not any(set(hit) <= row for row in SINGLETON_ROWS)
    }
    assert uncovered == EXPECTED_HITS
    assert not any(
        all(not any(set(hit) <= row for row in SINGLETON_ROWS)
            for hit in combinations(candidate, 3))
        for candidate in combinations(U, 4)
    )

    partitions = {}
    for hit in sorted(EXPECTED_HITS, key=lambda item: tuple(sorted(item))):
        witness = None
        for edge in columns:
            if edge & set(U) != hit:
                continue
            for second in columns:
                if edge & second:
                    continue
                third = frozenset(set(NAMES) - set(edge) - set(second))
                if third in columns:
                    witness = (edge, second, third)
                    break
            if witness is not None:
                break
        assert witness is not None
        assert set().union(*map(set, witness)) == set(NAMES)
        assert not any(witness[i] & witness[j] for i, j in combinations(range(3), 2))
        assert all(sum(len(column & set(row)) for column in witness) == 6
                   for row in ROWS)
        assert all(len(column & set(row)) == 2
                   for column in witness for row in ROWS)
        partitions[tuple(sorted(hit))] = tuple(
            tuple(sorted(column)) for column in witness
        )

    two_extensions_one_anchor = sum(
        {"x", "y"} <= set(hit) for hit in EXPECTED_HITS
    )
    one_extension_two_anchors = len(EXPECTED_HITS) - two_extensions_one_anchor
    assert (two_extensions_one_anchor, one_extension_two_anchors) == (4, 4)

    print({
        "allowed_pivot_columns": len(columns),
        "possible_U_triple_hits": len(EXPECTED_HITS),
        "two_extensions_one_anchor": two_extensions_one_anchor,
        "one_extension_two_anchors": one_extension_two_anchors,
        "maximum_U_hit_load": 3,
        "local_cubic_endpoint_partitions": partitions,
        "all_patterns_survive_local_cubic_endpoint_equations": True,
        "common_global_vertex_pairing": False,
    })
    print("CANONICAL_TRIPLE_HIT_LOCAL_BOUNDARY_VERIFIED")


if __name__ == "__main__":
    main()
