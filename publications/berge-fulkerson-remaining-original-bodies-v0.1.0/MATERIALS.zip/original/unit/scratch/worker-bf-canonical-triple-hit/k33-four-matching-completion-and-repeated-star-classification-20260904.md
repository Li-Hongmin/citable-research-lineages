# Four-matching completion in \(K_{3,3}\) and the repeated-extension star

This scratch note uses the canonical repeated-extension tokens of Notes
072--076.  It classifies only assignments of the six permutations in
\(S_3\); it does not enumerate graphs or poles.

## The four-to-six completion criterion

Identify a perfect matching of \(K_{3,3}\) with a permutation
\(\pi\in S_3\), and let \(P_\pi\) be its \(3\times3\) permutation matrix.
For four given matching occurrences \(\pi_1,\ldots,\pi_4\), put

\[
 C=\sum_{i=1}^4P_{\pi_i}.
\]

The following are equivalent.

1. There are \(\rho,\sigma\in S_3\) such that
   \[
   C+P_\rho+P_\sigma=2J_3.
   \tag{1}
   \]
2. Every entry of \(C\) is at most two.
3. No edge of \(K_{3,3}\) belongs to three of the four given matching
   occurrences.
4. For every \(i,j\in\{0,1,2\}\), at most two of the values
   \(\pi_1(i),\ldots,\pi_4(i)\) equal \(j\).

Necessity of (2) follows immediately from (1).  Conversely, if every entry
of \(C\) is at most two, then

\[
 D=2J_3-C
\]

is a nonnegative integral matrix with every row sum and column sum equal to
two.  Regard \(D\) as the incidence matrix of a 2-regular bipartite
multigraph.  Alternating its edges on every even-cycle component decomposes
it into two 1-factors, giving \(D=P_\rho+P_\sigma\).  This proves
sufficiency.

For \(3\times3\) matrices the unordered completing pair \(\{\rho,\sigma\}\)
is unique.  The support of \(D\) consists of doubled edges together with at
most one nontrivial even cycle; its two alternating 1-factors are therefore
unique up to their global interchange.

Call a four-token multiset **good** when it satisfies these equivalent
conditions, and **bad** otherwise.

## Reduction of the 14-token question to six singleton permutations

Write

\[
 A=a_1,\quad B=a_2,\quad C=a_4,\quad D=a_5,\quad X=x,\quad Y=y.
\]

The singleton parts of the four pivot rows are

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.          \tag{2}
\]

The eight triple tokens occur in only one pivot row each.  By the criterion
above, they can be assigned consistently after the singleton assignments
if and only if all four quadruples in (2) are good: in each row assign its
two private triple tokens the unique completing pair.

The three target singleton quadruples of Note 073 are

\[
 B D X Y,\qquad A C X Y,\qquad A B D Y.             \tag{3}
\]

Thus the proposed gadget blocker exists exactly if six permutations
\(A,B,C,D,X,Y\in S_3\) make all four quadruples in (2) good and all three
quadruples in (3) bad.

## Finite \(S_3\) classification

A bad quadruple contains three tokens agreeing on one edge.  Under the four
goodness assumptions in (2), the only token triples which can agree on an
edge are

\[
 ABY,\ ACY,\ ADY,\ BDX,\ AXY,\ BXY,\ CXY,\ DXY.
\tag{4}
\]

Indeed, these are exactly the triples not contained in one of the four
pivot quadruples.  Consequently a bad quadruple in (3) must be witnessed by
one of

\[
\begin{array}{c|c}
BDXY&BDX,\ BXY,\ DXY\\
ACXY&ACY,\ AXY,\ CXY\\
ABDY&ABY,\ ADY.
\end{array}                                        \tag{5}
\]

It remains a six-permutation classification, with no graph data.  A common
relabelling of the three output vertices normalizes \(A=012\).  Directly
applying the entry-multiplicity criterion to the remaining \(6^5\)
assignments gives the following complete table.  A bit is one when the
corresponding target in the order displayed in (3) is bad.

\[
\begin{array}{c|r}
\text{badness pattern}&\text{number of assignments}\\\hline
000&150\\
001&24\\
010&54\\
011&108\\
100&54\\
101&48\\
110&122\\
111&0.
\end{array}                                        \tag{6}
\]

The entries sum to \(560\), the complete set of normalized assignments for
which all four pivot quadruples are good.  The classification uses only the
six explicit rows

\[
012,\ 021,\ 102,\ 120,\ 201,\ 210
\]

and the test that no coordinate value occurs three times in a quadruple.
The accompanying standard-library script reproduces (6):
[`classify-k33-four-matching-completion.py`](classify-k33-four-matching-completion.py).

Since the \(111\) row is empty, no consistent assignment of \(S_3\)
permutations to the fourteen repeated-star tokens can make all four pivot
rows BF covers of the gadget while making all three target singleton
quadruples uncompletable.

The result is sharp at the level of target subsets: each two-target pattern
occurs.  For example, in the variable order \((A,B,C,D,X,Y)\), assignments

\[
\begin{array}{c|c}
011&(012,012,120,201,120,021)\\
101&(012,012,120,201,201,021)\\
110&(012,021,102,120,201,201)
\end{array}                                        \tag{7}
\]

make all four pivot quadruples good and exactly the indicated two targets
bad.

## Exact boundary of the conclusion

At least one of the three target singleton quadruples is therefore
completable inside every single inserted \(K_{3,3}\) gadget compatible with
the four pivot rows.  The two row-private gadget matchings completing it can
be chosen by the deficit-matrix construction above.

This does **not** produce the corresponding real target BF row in the whole
5-pole.  The two companion matchings must simultaneously complete the same
four singleton identities on every proper edge outside this gadget and have
the required triple boundaries.  Equivalently, gadget completable means
only that this one factor does not make the target fibre empty.  The
exact-Case-XII problem still requires an actual intersection

\[
 [W]_K\cap\Omega_b(\tau)\ne\varnothing
\]

in the full pole.  Thus one \(K_{3,3}\) sign factor cannot block all three
canonical targets, but the finite classification alone does not force any
target-fibre hit globally.
