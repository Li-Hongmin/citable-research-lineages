# 封口着色、十状态与三角形饱和的独立审计

2026-09-26。审查对象为 [Pro 完整答复](pro-triangle-133-20260926.txt)。
先读取了 [README](../README.md)、[冻结 SPEC](../SPEC-2026-09-23-case-xii-rectangle.md)
及 [已结束运行的裁决](case_xii_rectangle_20260923/verdict.md)。
旧运行的预算保持耗尽状态；本次只完成用户另行指定的一次有界独立审计。

**裁决：条件归约通过。** 在原问题的 distinct-terminal、loopless cubic
five-pole 适用域内，封口变换、全部十个边界状态、三角形饱和、自由边排除、
固定完整 \(U\) 而允许 \(Z\) 改变的 seed 等价，以及四极着色的充分检验均成立。
没有发现影响这一适用域的具体数学错误。封口步骤需要显式保留终端顶点互异这一前提；
完整 Case-XII 正支撑已经保证它。最弱未证步骤仍是左右可行性在同一个实际完整
pair load \(U\) 上相交。单个封口图得到两类是更强的同-anchor \(X=Y=Z\) 条件。

本次有限实现从局部 incidence 与边界颜色重新生成结果，没有调用 Pro 的检查器、
既有 pole 枚举器或 PM 枚举器。全部实际输出与可重跑代码见第 5 节。

## 1. 封口变换：假设、投影与逆向

取实际 PM
\[
B\in\mathcal P_2(G),\qquad Z\in\mathcal P_3(G),\qquad
C\in\mathcal P_4(G),\qquad U=B+C,
\]
所有 masks 均包括独立的 proper edge objects 和五条 semiedges。
令
\[
K=2\mathbf1-U-Z.
\]
若有负坐标，\(K\) 不能分解为三个 PM；将该选择的 palette 定为空是正确的。
否则 \(K(e)\in\{0,1,2\}\)，每个顶点的 incident load 是 \(6-3=3\)，且
\[
K(s_1)=K(s_5)=2,\qquad K(s_2)=K(s_3)=K(s_4)=1.
\]

**终端位置的精确前提。** 若原图终端顶点互异，在 \(s_1\) 的顶点，
双份 \(s_1\) 留下的唯一正 incidence 必是一个负载为一的 proper edge；
\(s_5\) 同理。仅由“剩余度数为一”不能认定该 incidence 是 proper：
若允许另一个 terminal 同顶点，它也可能是一条 semiedge。
因此 Pro 第 2 节在这里使用了其第 1 节讨论过的终端互异条件。

该条件在完整 exact Case XII 中自动成立：全部 ST 正 cells 使每个
\(\mathcal Q_{ij}\) 都非空，因此每个三元 terminal 集都是某实际 PM 的边界。
任意两个 terminals 都同属某个这样的三元集，故不可能共用一个图顶点。
这也与 [Note 100 开头的原问题定义](../notes/100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md)
一致。若把归约另行表述为仅有两项负支撑假设的定理，应明确保留终端互异前提。
本审计没有把它从纯度数方程中省略。

删除 \(s_1,s_5\) 的两个顶点及四份 semiedges，把各自唯一正 proper
incidence 改成编号 1、5 的新自由端，得到 \(\widehat K\)。
若两端原来是同一条正边，则保留一个连接自由端 1、5 的 vertex-free edge。
其余内部顶点仍三价，原边对象和副本身份均保留。辅助图可以不连通，
也可以有平行边或同顶点的不同 terminals；不要求它自身属于原 SPEC 的 pole 类。

设辅助边界颜色为 \(\lambda_1,\ldots,\lambda_5\)。恢复删除的顶点时，
给双份旧 \(s_i\) 使用除 \(\lambda_i\) 外的另两色，\(i=1,5\)。
有两种副本标签分配，但投影到原图三个颜色的 PM masks 后完全相同。
所以“唯一”成立于原匹配 masks 层，不能理解为带标签副本的唯一着色。

任何 proper edge 的两份副本在同一顶点必须异色，投影后每个颜色在该原边上的
坐标至多为一。不同的平行原边则始终保有不同坐标。
因此每个全图 proper three-colouring 恰给出一个有序三-PM 分解
\(K=M_0+M_1+M_2\)，允许无关的副本标签冗余。反向从任一这样的实际分解，
按所属 PM 给边副本着色，并作同一删除，即得到辅助着色。
在两方向中加入固定的 \(B,Z,C\) 都得到原图逐边负载二的真实 BF 行。
负支撑假设是在这条原图 BF 行上使用的。

## 2. 十状态转换与边界奇偶性

原图顶点数为奇数；删除两个顶点后仍为奇数。每个辅助颜色在内部顶点处的
度数是一，因此该颜色的 terminal 数为奇数。一个 vertex-free edge
给同一颜色增加两个 terminal ends，不改变奇偶。五端、三色因此只能为
\(3,1,1\)，总计十个 singleton-pair states，每个 state 有六个颜色置换。

恢复后的颜色 \(c\) 的原图边界为
\[
\partial M_c=
\{i\in\{2,3,4\}:\lambda_i=c\}
\;\cup\;
\{i\in\{1,5\}:\lambda_i\ne c\}.
\]
这正是两个被封口 terminal 的成员关系取补。独立实现逐个检查了全部
\(3^5=243\) 个颜色词，其中 60 个满足上述奇偶，并在六个 BF occurrences
中核对每个 terminal 的负载为二，得到：

| 辅助 state | 额外 singleton classes | 原图两个 triple states 或 A |
|---|---|---|
| 12 | 5 | (25)(34) |
| 13 | 5 | (24)(35) |
| 14 | 5 | (23)(45)，禁止 TT |
| 15 | 1、5 | all-terminal A，禁止 |
| 23 | 4 | (24)(34) |
| 24 | 3 | (23)(34)，禁止 TT |
| 25 | 1 | (12)(34)，禁止 TT |
| 34 | 2 | (23)(24) |
| 35 | 1 | (13)(24) |
| 45 | 1 | (14)(23) |

因此完整无 A／无 TT 支撑给出
\[
\mathcal T(U,Z)\subseteq
\Delta_R\cup\Delta_L,\qquad
\Delta_R=\{12,13,23\},\quad
\Delta_L=\{34,35,45\}.
\]
表中三条禁止 TT 行都是非对角类型；完整 Case XII 还排除 T-loops。
转换没有对 \(\widehat K\) 施加 Case-XII 支撑假设。

## 3. 三角形饱和与退化情形的解析证明

对一个实际 state \(ij\) 着色，保留 terminal \(i\) 所属的 singleton 色。
另两色的子图由偶环和 terminal paths 构成。terminal \(j\) 所在路径
的另一端必是剩余三端之一 \(k\)。交换这条实际路径的两色，得到 state \(ik\)。
零条 proper edges 的两-semiedge 路径同样可交换；内部偶环不改变边界 state。

在 state 12 中，保留 singleton 1 时可到 13、14 或 15；
后两者禁止，故必到 13。保留 singleton 2 时可到 23、24 或 25，
故必到 23。反过来，13 保留 1、23 保留 2 都被迫到 12。
因此右三角形任一 state 出现就饱和整个右三角形。
置换 \(1\leftrightarrow5,\ 2\leftrightarrow4\) 保持禁止集并交换左右，
所以左三角形同样饱和。于是
\[
\mathcal T(U,Z)\in
\{\varnothing,\Delta_L,\Delta_R,\Delta_L\cup\Delta_R\}.
\]

所有这些交换均在同一个 \(K=2\mathbf1-U-Z\) 的余下三色中进行，
所以固定的实际 \(B,Z,C\) masks 不变。Pro 的两组 pointwise cell 等价
也随表格与这一饱和成立；它们确实包含指定的三个 singleton occurrences，
没有把逐 cell 的全局存在量词当成字面复用。

有限实现没有直接硬编码三角形闭包：它从每个颜色词出发，列出每对颜色的
terminal endpoints、全部路径端点配对以及任意路径子集的交换结果。
任一实际 palette 必须对实际配对产生的全部交换闭合，所以它须通过相应的
“至少一种配对可行”条件。检查全部 \(2^{10}=1024\) 个状态子集，
无 A/TT 排除后剩 64 个，Kempe 必要条件后恰剩以上四个。
这证实了分类所需的有限边界事实；没有声称四种形式都由某个 exact-support
原图实现，也没有声称任意可选路径配对能同时在一个图中实现。

若有自由边 1--5，则必有 \(\lambda_1=\lambda_5\)，允许集中仅 23、34
满足它。这两个 state 中任何一个又迫使包含不满足该等式的整个三角形，
矛盾。故此退化情形在原图负支撑假设下不可着色。

此外，在允许集中，
\[
\begin{array}{ll}
\Delta_L:& \lambda_1=\lambda_2,\quad
 \lambda_3,\lambda_4,\lambda_5\text{ 两两不同},\\
\Delta_R:& \lambda_4=\lambda_5,\quad
 \lambda_1,\lambda_2,\lambda_3\text{ 两两不同}.
\end{array}
\]
把自由端 1、2 接到新三价顶点并补一条 semiedge，有合法新颜色当且仅当
\(\lambda_1\ne\lambda_2\)，此时颜色唯一。直接检查得到：全部 60 个词中
42 个可延拓；在负支撑允许的 36 个词中恰 18 个可延拓，正是右三角形。

## 4. 固定 U 改变 Z，与单-cap X=Y 的区别

令
\[
\mathcal U=\{B+C:B\in\mathcal P_2,\ C\in\mathcal P_4\}
\]
只包含实际完整 PM pair loads。辅助负载及其 palette 仅依赖 \(U,Z\)，
不依赖 \(U\) 的具体 PM 分解或副本命名。

state 45 的恢复行恰为
\[
B+Z+C+A+q_{14}+r_{23}=2\mathbf1,
\]
state 12 的恢复行恰为
\[
B+Z+C+D+q'_{25}+r_{34}=2\mathbf1.
\]
反向从这两种实际行删除 \(B,Z,C\) 并封口，也分别给出 state 45、12。
结合饱和，得到准确的两种量词：

\[
\begin{aligned}
\text{原 shared seed}
&\Longleftrightarrow
\exists U\in\mathcal U:\quad
\bigcup_{Z\in\mathcal P_3}\mathcal T(U,Z)
  =\Delta_L\cup\Delta_R,\\
\text{有 }X=Y\text{ 的 shared seed}
&\Longleftrightarrow
\exists U\in\mathcal U,\ Z\in\mathcal P_3:\quad
\mathcal T(U,Z)=\Delta_L\cup\Delta_R.
\end{aligned}
\]

第一行允许两个不同的 anchors \(Z_L,Z_R\)，分别取 \(X=Z_L,\ Y=Z_R\)。
选择 \(U\) 的任一实际分解 \(B+C\)，左右构造都能用这同一对完整 masks；
边界相同或负载的部分坐标相同都不足以替代完整向量相等。
仍不把 \(q'_{25}\) 与饱和列中的 \(q_{25}\) 识别。

例如抽象的两-anchor palettes \((\Delta_L,\Delta_R)\) 对同一 \(U\)
满足一般 seed 的形式条件，却没有单个 anchor 同时含两类。
本次有限逻辑检查只说明不能交换这两个量词；它不提供真实图，更不提供
exact-Case-XII 反例。

因此，给定一个实际左行及其 \(U,Z\)，第 3 节的四极若可着色，
确实得到同-anchor \(X=Y=Z\) 的 seed。该四极若不可着色，只排除这个
固定 \(U,Z\) 的加强构造；不能排除换另一个 \(Z\) 后同一 \(U\) 的一般 seed，
也不能排除其他 \(U\)。

**最弱未证步骤。** 全部 ST 正支撑分别保证
\[
\{U:\exists Z,\ \Delta_L\subseteq\mathcal T(U,Z)\}\ne\varnothing,\qquad
\{U:\exists Z,\ \Delta_R\subseteq\mathcal T(U,Z)\}\ne\varnothing.
\]
尚未证明这两个完整 pair-load 集合相交。等价地，未排除某个实际 exact-support
pole 对每个可行 \(U\) 都具有固定方向 \(\varepsilon(U)\in\{L,R\}\)，
该 \(U\) 下所有可着色 anchors 均只有 \(\Delta_{\varepsilon(U)}\)，
而不同 \(U\) 分别承担左右两类。Pro 对这一缺口的保留正确。

这里没有给出 exact-Case-XII 基极或其完整 PM/support 证书；
也没有从 seed 推出冻结 SPEC 的 prescribed opposite witness、same-K、
agreement core 或 target phase 交点。原 SPEC 主命题的未决裁决保持不变。

## 5. 新实现、命令和实际输出

仅 Python 标准库；计算对象是 27 个局部 incidence 词、243 个边界颜色词、
1024 个状态子集及一个两-anchor 逻辑检查。路径配对最多涉及四个自由端。
全部数据规模固定且很小，不建立 pole family，不进行 PM 或图阶搜索。
从本单元目录运行以下命令即可重现，命令自身不写文件。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
from itertools import combinations, permutations, product

colours = (0, 1, 2)
labels = frozenset(range(1, 6))
S = {"13", "14", "24", "25", "35"}
T = {"12", "15", "23", "34", "45"}

# Local cubic incidence: three fixed PM occurrences, three original edge objects.
nonnegative_words = local_colourings = 0
for fixed in product(range(3), repeat=3):
    load = tuple(2 - fixed.count(e) for e in range(3))
    assert sum(load) == 3
    if min(load) < 0:
        continue
    nonnegative_words += 1
    copies = tuple(e for e, n in enumerate(load) for _ in range(n))
    for assignment in permutations(colours):
        projected = tuple(tuple(sum(e == original and c == colour
                                    for e, c in zip(copies, assignment))
                                for original in range(3))
                          for colour in colours)
        assert all(sum(m) == 1 and set(m) <= {0, 1} for m in projected)
        assert all(sum(m[e] for m in projected) + fixed.count(e) == 2
                   for e in range(3))
        local_colourings += 1
assert (nonnegative_words, local_colourings) == (24, 144)
print("local cubic loads: 24/27 nonnegative; 144 labelled colourings project to 0/1 PM incidences")

# Two copies of an old terminal and its one positive proper port.
cap_extensions = 0
for port in colours:
    assignments = [(a, b) for a, b in product(colours, repeat=2)
                   if len({a, b, port}) == 3]
    projections = {tuple((int(c in (a, b)), int(c == port)) for c in colours)
                   for a, b in assignments}
    assert len(assignments) == 2 and len(projections) == 1
    assert next(iter(projections)) == tuple((int(c != port), int(c == port))
                                           for c in colours)
    cap_extensions += len(assignments)
print("cap restoration: 3 port colours; %d labelled extensions; unique projected masks per port" % cap_extensions)

def state(word):
    assert sorted(word.count(c) for c in colours) == [1, 1, 3]
    return "".join(str(i + 1) for i, c in enumerate(word) if word.count(c) == 1)

def restore(word):
    # Original single terminals retain their colour. Each capped terminal
    # receives the two colours other than the colour of its surviving port.
    masks = [set() for _ in colours]
    for i in range(2, 5):
        masks[word[i - 1]].add(i)
    for i in (1, 5):
        for c in colours:
            if c != word[i - 1]:
                masks[c].add(i)
    return tuple(frozenset(m) for m in masks)

def boundary_row(word):
    masks = restore(word)
    row = masks + (frozenset({2}), frozenset({3}), frozenset({4}))
    assert all(sum(i in m for m in row) == 2 for i in labels)
    assert all(len(m) % 2 == 1 for m in masks)
    singles = "".join(str(next(iter(m))) for m in sorted(
        (m for m in masks if len(m) == 1), key=lambda m: min(m)))
    if any(len(m) == 5 for m in masks):
        return singles, "A"
    triples = sorted("".join(map(str, sorted(labels - m)))
                     for m in masks if len(m) == 3)
    assert len(triples) == 2 and len(singles) == 1
    return singles, "/".join(triples)

words = [w for w in product(colours, repeat=5)
         if all(w.count(c) % 2 == 1 for c in colours)]
assert len(words) == 60
states = sorted({state(w) for w in words})
expected = {
    "12": ("5", "25/34"), "13": ("5", "24/35"),
    "14": ("5", "23/45"), "15": ("15", "A"),
    "23": ("4", "24/34"), "24": ("3", "23/34"),
    "25": ("1", "12/34"), "34": ("2", "23/24"),
    "35": ("1", "13/24"), "45": ("1", "14/23"),
}
table = {}
for s in states:
    entries = {boundary_row(w) for w in words if state(w) == s}
    assert entries == {expected[s]}
    table[s] = entries.pop()
forbidden = {s for s, (_, cell) in table.items()
             if cell == "A" or all(pair in T for pair in cell.split("/"))}
allowed = frozenset(states) - forbidden
assert forbidden == {"14", "15", "24", "25"}
print("boundary words: 60/243; all 10 states x 6 colour permutations PASS")
for s in states:
    singles, cell = table[s]
    print("state %s -> extra singleton(s) %s; cell %s; %s" %
          (s, singles, cell, "FORBIDDEN" if s in forbidden else "allowed"))

# Derive Kempe boundary obligations from every possible two-colour path
# pairing, including every subset of paths that could be switched.
# These are necessary boundary conditions, not graph-realizability claims.
def pairings(items):
    if not items:
        yield ()
        return
    for j in range(1, len(items)):
        for tail in pairings(items[1:j] + items[j + 1:]):
            yield ((items[0], items[j]),) + tail

requirements = {s: [] for s in states}
for word in words:
    for a, b in combinations(colours, 2):
        ends = tuple(i for i, c in enumerate(word) if c in (a, b))
        assert len(ends) in (2, 4)
        options = set()
        for pairing in pairings(ends):
            outcomes = set()
            for switches in product((False, True), repeat=len(pairing)):
                changed = list(word)
                for switch, path in zip(switches, pairing):
                    if switch:
                        for i in path:
                            changed[i] = b if changed[i] == a else a
                outcomes.add(state(tuple(changed)))
            options.add(frozenset(outcomes))
        requirements[state(word)].append(options)

palettes = []
negative_survivors = 0
for flags in product((False, True), repeat=10):
    palette = frozenset(s for s, flag in zip(states, flags) if flag)
    if not palette <= allowed:
        continue
    negative_survivors += 1
    if all(any(outcomes <= palette for outcomes in options)
           for s in palette for options in requirements[s]):
        palettes.append(palette)
L = frozenset({"34", "35", "45"})
R = frozenset({"12", "13", "23"})
assert negative_survivors == 64
assert set(palettes) == {frozenset(), L, R, L | R}
print("palette subsets: 1024 total; 64 pass exclusions; 4 pass all Kempe boundary obligations")
for p in sorted(palettes, key=lambda p: (len(p), tuple(sorted(p)))):
    print("palette {" + ",".join(sorted(p)) + "}")

free_states = {state(w) for w in words if state(w) in allowed and w[0] == w[4]}
assert free_states == {"23", "34"}
assert [p for p in palettes if p <= free_states] == [frozenset()]
print("free edge 1--5: allowed states {23,34}; only closed palette is empty")

join_total = join_allowed = 0
for word in words:
    extensions = [c for c in colours if len({word[0], word[1], c}) == 3]
    assert len(extensions) == int(word[0] != word[1])
    if extensions:
        boundary4 = (word[2], word[3], word[4], extensions[0])
        assert all(boundary4.count(c) % 2 == 0 for c in colours)
        join_total += 1
    s = state(word)
    if s in allowed:
        assert (word[0] == word[1]) == (s in L)
        if s in L:
            assert len(set(word[2:5])) == 3
        if s in R:
            assert word[3] == word[4] and len(set(word[:3])) == 3
        join_allowed += len(extensions)
assert (join_total, join_allowed) == (42, 18)
print("join terminals 1,2: 42/60 words extend; under exclusions 18/36, exactly triangle R")

# Quantifier check only: two abstract Z anchors for one fixed U.
# This is not a constructed pole or an exact-support counterexample.
general = stronger = split_only = 0
for p, q in product((frozenset(), L, R, L | R), repeat=2):
    seed = L | R <= p | q
    same_anchor = any(L | R <= r for r in (p, q))
    assert not same_anchor or seed
    general += seed
    stronger += same_anchor
    split_only += seed and not same_anchor
assert (general, stronger, split_only) == (9, 7, 2)
print("two-anchor logic: general seed=9/16; same-Z=7/16; split-only=2/16 (no graph realizability asserted)")
print("ALL ASSERTIONS PASS; boundary/local incidence only; no pole census or PM search")
PY
```

实际运行退出码为 0，输出如下：

```text
local cubic loads: 24/27 nonnegative; 144 labelled colourings project to 0/1 PM incidences
cap restoration: 3 port colours; 6 labelled extensions; unique projected masks per port
boundary words: 60/243; all 10 states x 6 colour permutations PASS
state 12 -> extra singleton(s) 5; cell 25/34; allowed
state 13 -> extra singleton(s) 5; cell 24/35; allowed
state 14 -> extra singleton(s) 5; cell 23/45; FORBIDDEN
state 15 -> extra singleton(s) 15; cell A; FORBIDDEN
state 23 -> extra singleton(s) 4; cell 24/34; allowed
state 24 -> extra singleton(s) 3; cell 23/34; FORBIDDEN
state 25 -> extra singleton(s) 1; cell 12/34; FORBIDDEN
state 34 -> extra singleton(s) 2; cell 23/24; allowed
state 35 -> extra singleton(s) 1; cell 13/24; allowed
state 45 -> extra singleton(s) 1; cell 14/23; allowed
palette subsets: 1024 total; 64 pass exclusions; 4 pass all Kempe boundary obligations
palette {}
palette {12,13,23}
palette {34,35,45}
palette {12,13,23,34,35,45}
free edge 1--5: allowed states {23,34}; only closed palette is empty
join terminals 1,2: 42/60 words extend; under exclusions 18/36, exactly triangle R
two-anchor logic: general seed=9/16; same-Z=7/16; split-only=2/16 (no graph realizability asserted)
ALL ASSERTIONS PASS; boundary/local incidence only; no pole census or PM search
```

本次审计已得到上述裁决，停止于固定完整 U 的跨-anchor 耦合缺口。
仅新增本 scratch 文件；未修改 SPEC、README 或 notes，未提交、推送或访问远程主机。
