# 跨共享 matching 的 Boolean cocycle：严格路线关闭

## 精确结论

令边界类按互补五边形顺序

\[
v_0,v_1,v_2,v_3,v_4=1,4,2,5,3
\]

循环排列，并令

\[
P_t\in\mathcal P_{v_t},\qquad
(P_t,P_{t+1})\in R_{v_tv_{t+1}}
\]

为一条 canonical Kempe transport 轨道。对共享 matching
\(B=P_{t+1}\)，记 \(X_t(B)\) 为 \(H-B\) 中端点为
\(v_t,v_{t+2}\) 的边界交替路。把边集视为
\(\mathbb F_2^{E(H)}\) 中的向量，则

\[
P_{t+2}=P_t\mathbin\triangle X_t(P_{t+1}).
\tag{1}
\]

在 relation edge 上定义

\[
q_t=q(P_t,P_{t+1})=P_t\mathbin\triangle P_{t+1}.
\]

于是跨两个不同共享 matching 的自然 path cochain 满足

\[
X_t(P_{t+1})=q_t\mathbin\triangle q_{t+1}=(dq)_t.
\tag{2}
\]

所以它是 coboundary。任意一段 transport 都只有端点项：

\[
\mathop{\triangle}_{t=a}^{b-1}X_t=q_a\mathbin\triangle q_b.
\tag{3}
\]

特别地，五步 monodromy defect 为

\[
\mathop{\triangle}_{t=0}^{4}X_t
=P_0\triangle P_1\triangle P_5\triangle P_6,
\tag{4}
\]

而任意闭合 canonical transport 轨道上的总和为零。因而从局部
Boolean torsor 和 canonical transport 自然得到的跨-fibre cocycle 是
exact 的；它本身不提供迫使五步 monodromy 有不动点的非零上同调障碍。

更强地，这组 Boolean-torsor/cocycle 公理**不能推出** capacity-two
transversal。下面的有限抽象模型同时满足这些公理而没有任何
capacity-two transversal。

## 恒等式证明

固定 \(B=P_{t+1}\)。在 exact-\(C_5\) lonely-state 假设下，
\(H-B\) 分解成两条边界交替路和若干偶交替圈；相应左右兼容纤维是这些
偶圈翻转群的 torsor。把端点为 \(v_t,v_{t+2}\) 的那条路上的两种颜色
互换，正把 \(P_t\) 送到 \(P_{t+2}\)，证明 (1)。于是

\[
q_t\triangle q_{t+1}
=(P_t\triangle P_{t+1})\triangle(P_{t+1}\triangle P_{t+2})
=P_t\triangle P_{t+2}=X_t,
\]

即 (2)；(3)--(4) 由 telescoping 立即得到。

## 为什么它看不见 capacity two

五个连续 matching \(P_1,\ldots,P_5\) 的四个相邻对两两不交。
因此一个边在这五个 matching 中出现至少三次，当且仅当它属于唯一可能的
三元独立集

\[
P_1\cap P_3\cap P_5.
\]

所以这个窗口 capacity two 当且仅当该三重交为空。然而三重公共边会同时从
\(P_1\triangle P_3=X_1(P_2)\) 和
\(P_3\triangle P_5=X_3(P_4)\) 中消去。这里缺失的是整数重数信息，不是尚未
telescoping 的模二项。

## 严格抽象反模型

取十个状态 \(N_k\)（\(k\in\mathbb Z/10\mathbb Z\)），令
\(N_k\) 属于第 \(k\bmod5\) 层；每层恰有 \(N_i,N_{i+5}\) 两个状态。
引入元素 \(a,b\)、每层 semiedge \(s_i\)，以及对每个非相邻异奇偶对
\(\{k,\ell\}\) 引入只被该对共享的新元素 \(d_{k\ell}\)。定义：

- 每个偶数状态含 \(a\)，每个奇数状态含 \(b\)；
- \(N_k\) 含本层的 \(s_{k\bmod5}\)；
- \(N_k,N_\ell\) 在异奇偶且不相邻时共同含 \(d_{k\ell}\)。

则两个状态不交当且仅当它们在

\[
N_0N_1\cdots N_9N_0=C_{10}
\]

上相邻。对任一共享状态，左、右兼容纤维都为单点，因而都是合法的
\(\mathbb F_2^0\)-torsor；canonical transport 沿 \(C_{10}\) 前进一步。
五步 monodromy 交换同层的两个状态，十步闭合。取

\[
q_k=N_k\triangle N_{k+1},\qquad X_k=N_k\triangle N_{k+2},
\]

便有 \(X_k=q_k\triangle q_{k+1}\) 以及闭轨总和为零。

另一方面，每层的两个状态一偶一奇。任取每层一个状态，共五个；鸽巢原理
保证至少三个同为偶数或至少三个同为奇数，故它们至少三重覆盖 \(a\) 或
\(b\)。所以 32 个五层 transversal 全部违反 capacity two。

这是真正的**逻辑接口反模型**：它严格否定

\[
\text{Boolean fibres + canonical cocycle/monodromy laws}
\Longrightarrow\text{capacity-two transversal}.
\]

它不是 cubic 5-pole，也不否定 Note 005 的真实图论猜想。

## 证据等级与边界

- **证据等级：** 抽象公理层为证明级路线关闭；反模型只有 10 个状态、
  32 个 transversal，并由同目录 verifier 穷尽复核。真实 cubic 5-pole 层仍为
  未判定。
- **最薄弱论证：** 反模型未证明可由一个共同 cubic 5-pole 的全部 perfect
  matchings 实现。它只承载 H--P 局部 Boolean torsor、disjointness、canonical
  transport 与由边集对称差生成的 cocycle 数据。
- **未解决边界：** cubic incidence、完整 perfect-matching closure、整数/正性或
  odd-cut 约束、以及不同 transport orbit 之间的非 canonical 耦合，是否足以排除
  此类三重覆盖 blocker，仍未知。因此 capacity-two transversal 猜想继续存活；
  关闭的只是纯 Boolean cocycle/monodromy 证明路线。

