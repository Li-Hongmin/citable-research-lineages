#!/usr/bin/env python3
"""Exact check of the rank-zero Boolean-torsor countermodel."""

from itertools import combinations, product


def delta(*sets: frozenset[str]) -> frozenset[str]:
    out: set[str] = set()
    for one_set in sets:
        out.symmetric_difference_update(one_set)
    return frozenset(out)


def states() -> tuple[frozenset[str], ...]:
    result = []
    for k in range(10):
        items = {"a" if k % 2 == 0 else "b", f"s{k % 5}"}
        for ell in range(10):
            if ell == k or ell % 2 == k % 2:
                continue
            if (ell - k) % 10 in (1, 9):
                continue
            items.add(f"d{min(k, ell)}_{max(k, ell)}")
        result.append(frozenset(items))
    return tuple(result)


def main() -> None:
    node = states()
    disjoint = {
        frozenset((k, ell))
        for k, ell in combinations(range(10), 2)
        if node[k].isdisjoint(node[ell])
    }
    c10 = {frozenset((k, (k + 1) % 10)) for k in range(10)}
    assert disjoint == c10

    good = []
    for bits in product((0, 1), repeat=5):
        chosen = tuple(i + 5 * bits[i] for i in range(5))
        load_a = sum("a" in node[k] for k in chosen)
        load_b = sum("b" in node[k] for k in chosen)
        if max(load_a, load_b) <= 2:
            good.append(chosen)
    assert not good

    q = tuple(delta(node[k], node[(k + 1) % 10]) for k in range(10))
    path = tuple(delta(node[k], node[(k + 2) % 10]) for k in range(10))
    assert all(path[k] == delta(q[k], q[(k + 1) % 10]) for k in range(10))
    assert delta(*path) == frozenset()
    assert all(delta(*path[k : k + 5]) == delta(q[k], q[k + 5]) for k in range(5))

    print(
        {
            "disjointness": "C10",
            "boolean_fibre_rank": 0,
            "five_step_monodromy": "layer bit flip",
            "transversals": 32,
            "capacity_two": 0,
            "closed_cocycle_sum": 0,
        }
    )


if __name__ == "__main__":
    main()
