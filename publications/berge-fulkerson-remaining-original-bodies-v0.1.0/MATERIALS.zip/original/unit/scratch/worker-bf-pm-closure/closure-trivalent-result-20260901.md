# Common-family cube + trivalent-coordinate interface (bounded pulse)

## Exact finite question

Use one common binary incidence family for the five singleton classes
`P_i` and ten triple classes `Q_{ij}`.  Give each class a complete
alternating-cycle cube of dimension (K): vectors in one class agree away
from its (K) designated cycle coordinates and contain every cube vertex.
At one shared internal cubic coordinate, every vector chooses exactly one of
three incident edges; each positive six-vector equation must use each local
edge exactly twice.  Quantify all vector choices in every cell, require the
exact Case-XII positive set (five S loops, ten S--S cells, twenty-five S--T
cells), forbid every T loop and T--T cell, and require all five D5
four-of-five transferred S--S joins to be empty.

No zero-boundary class is included, so an abstract SAT witness would not be
a real (A=(12345)) matching unless a separate common-pole realization were
given.

## Solver results

The deterministic script is

```text
python3 units/berge-fulkerson/scratch/worker-bf-pm-closure/new_interface_sat.py
```

For (K=1) (30 vectors, 15 cycle coordinates, one shared trivalent
coordinate), Z3 returns an exact UNSAT:

```text
status= unsat
CLOSURE_TRIVALENT_EXACT40_D5_UNSAT
```

This is a finite-model result, not a pole theorem.  It says that this
smallest nontrivial complete-cube interface cannot realize all requested
conditions simultaneously; no proof core was extracted.

The first genuinely multi-component cube test (K=2) (60 vectors, 30 cycle
coordinates) was run on Omen in detached tmux session
`bf-pm-closure-k2-20260901`.  At the five-minute resource gate it was still
searching (CPU approximately 100%, RSS approximately 1.6 GB) with an empty
log and was terminated.  Its status is **unknown/timeout**, not UNSAT or SAT.

Remote paths:

```text
[local archival reference]
[local archival reference]
```

The K=2 run therefore supplies no conclusion.  In particular, this pulse
does not claim a no-D5 theorem for complete cubes of arbitrary dimension.

## Scope boundary

The (K=1) UNSAT is stronger than the earlier aggregate/load-only model in
that every class has a common-family cycle flip and the shared cubic
coordinate partitions all vectors.  It is still weaker than a real cubic
5-pole: no global vertex/edge gluing or graph realizability is encoded.
Thus the only current D5 decision is a bounded interface closure:

* (K=1): **UNSAT** (checkable by rerunning the script with
  `BF_CUBE_K=1`);
* (K=2): **not distinguished** at the five-minute cutoff;
* arbitrary (K) or an actual pole: **open**.

