#!/usr/bin/env python3
"""Finite common-family/cube/trivalent Case-XII interface.

This is an intentionally small abstract model.  There are ``2**K`` vectors
in each of the five singleton and ten triple boundary classes.  The vectors
in one class form a K-dimensional alternating-cycle cube: cube endpoints
agree on every coordinate outside that class's K designated formal cycle
coordinates.
One shared cubic coordinate assigns every vector one of three incident
edges; every positive six-vector equation must use each local edge twice.

The solver also quantifies all vector choices in every cell, excludes every
T-loop/T--T completion, and requires every four-of-five D5 join to be empty.
No zero-boundary (A) class is supplied.  Consequently a SAT result is only
an abstract common-family countermodel, never a cubic pole.
"""

from __future__ import annotations

from itertools import combinations, combinations_with_replacement, product

import os

from z3 import If, Int, Or, Solver, Sum, sat, unsat


POSITIONS = tuple(range(5))
PAIRS = tuple(combinations(POSITIONS, 2))
S = ((0, 2), (0, 3), (1, 3), (1, 4), (2, 4))
T = ((0, 1), (0, 4), (1, 2), (2, 3), (3, 4))
S_SET = frozenset(S)
T_SET = frozenset(T)
CLASSES = tuple(("P", (i,)) for i in POSITIONS) + tuple(
    ("Q", pair) for pair in PAIRS
)
CLASS_INDEX = {cls: index for index, cls in enumerate(CLASSES)}
# Cube dimension per boundary class.  K=1 is the smallest nontrivial
# component cube; K=2 is the first genuinely multi-component closure test.
K = int(os.environ.get("BF_CUBE_K", "1"))
SKIP_LOCAL = os.environ.get("BF_SKIP_LOCAL", "0") == "1"
SKIP_NEGATIVE = os.environ.get("BF_SKIP_NEGATIVE", "0") == "1"
SKIP_D5 = os.environ.get("BF_SKIP_D5", "0") == "1"
VECTOR_COUNT = (1 << K) * len(CLASSES)
CYCLE_COORDS = tuple(range(K * len(CLASSES)))
LOCAL_EDGES = (0, 1, 2)

# Five D5 S--T cells and their transferred disjoint S--S cells.  The tuple
# entries are ordered as in the existing BF notes, but zero-indexed.
D5 = (
    ((S[1], T[4]), (S[1], S[4])),  # (14,45) -> (14,35)
    ((S[0], T[2]), (S[0], S[2])),  # (13,23) -> (13,24)
    ((S[1], T[0]), (S[1], S[3])),  # (14,12) -> (14,25)
    ((S[2], T[1]), (S[2], S[4])),  # (24,15) -> (24,35)
    ((S[4], T[0]), (S[0], S[3])),  # (35,12) -> (13,25)
)
D5_SS = tuple(item[1] for item in D5)


def triple_class(pair):
    return ("Q", tuple(pair))


def singleton_class(position):
    return ("P", (position,))


def slots(cell):
    """Return boundary classes in the six-vector equation's singleton slots."""
    first, second = cell
    return tuple(singleton_class(i) for i in first + second)


def vector_id(cls, bit):
    return (1 << K) * CLASS_INDEX[cls] + bit


def vector_cube_bits(cls, bit):
    """Return the K-bit cube word for one class variant."""
    assert 0 <= bit < (1 << K)
    return tuple((bit >> j) & 1 for j in range(K))


def cell_kind(cell):
    first, second = cell
    if first == second:
        return "S-loop" if first in S_SET else "T-loop"
    if first in S_SET and second in S_SET:
        return "S-S"
    if (first in S_SET and second in T_SET) or (first in T_SET and second in S_SET):
        return "S-T"
    return "T-T"


def all_cells(kind=None):
    out = []
    if kind in (None, "S-loop"):
        out += [(pair, pair) for pair in S]
    if kind in (None, "T-loop"):
        out += [(pair, pair) for pair in T]
    if kind in (None, "S-S"):
        out += list(combinations(S, 2))
    if kind in (None, "S-T"):
        out += [(s, t) for s in S for t in T]
    if kind in (None, "T-T"):
        out += list(combinations(T, 2))
    return tuple(out)


def all_variants(cls_slots):
    """All vector-ID choices for a six-vector equation's class slots."""
    return product(*(range(1 << K) for _ in cls_slots))


def build_solver():
    solver = Solver()

    # One bit per matching vector and formal cycle coordinate.  For class C,
    # C0/C1 differ only at coordinate C, so every same-class pair is a single
    # component and the complete one-cube is present.
    bits = [[Int(f"b_{v}_{c}") for c in CYCLE_COORDS] for v in range(VECTOR_COUNT)]
    for row in bits:
        for value in row:
            solver.add(value >= 0, value <= 1)
    for class_index, cls in enumerate(CLASSES):
        class_variants = tuple(range(1 << K))
        for bit in class_variants:
            for other_bit in class_variants:
                # Distinct cube vertices have identical coordinates outside
                # this class's K designated cycle coordinates.
                if bit == other_bit:
                    continue
                for coordinate in CYCLE_COORDS:
                    if coordinate // K != class_index:
                        solver.add(
                            bits[vector_id(cls, bit)][coordinate]
                            == bits[vector_id(cls, other_bit)][coordinate]
                        )
        for cube_bit in class_variants:
            v = vector_id(cls, cube_bit)
            word = vector_cube_bits(cls, cube_bit)
            for j in range(K):
                coordinate = class_index * K + j
                solver.add(bits[v][coordinate] == word[j])

    # Shared internal cubic coordinate: one of the three incident edges per
    # vector, with the two cube endpoints carrying the same local edge.
    local = [Int(f"ell_{v}") for v in range(VECTOR_COUNT)]
    for value in local:
        solver.add(value >= 0, value <= 2)
    if not SKIP_LOCAL:
        for class_index, cls in enumerate(CLASSES):
            for bit in range(1 << K):
                solver.add(local[vector_id(cls, bit)] == local[vector_id(cls, 0)])

    def exact_expr(cell, variants):
        """Six-vector exact load (all cycle coords and local cubic edges)."""
        first, second = cell
        triple_classes = (triple_class(first), triple_class(second))
        singleton_classes = slots(cell)
        cls_slots = triple_classes + singleton_classes
        vectors = [vector_id(cls, bit) for cls, bit in zip(cls_slots, variants)]
        equations = []
        for coordinate in CYCLE_COORDS:
            equations.append(Sum(bits[v][coordinate] for v in vectors) == 2)
        if not SKIP_LOCAL:
            for edge in LOCAL_EDGES:
                equations.append(Sum(If(local[v] == edge, 1, 0) for v in vectors) == 2)
        return AndAll(equations)

    def support_expr(cell):
        cls_slots = (triple_class(cell[0]), triple_class(cell[1])) + slots(cell)
        return Or(*(exact_expr(cell, variants) for variants in all_variants(cls_slots)))

    # Exact positive Case-XII support: five S loops, ten S-S, twenty-five S-T.
    for cell in all_cells("S-loop") + all_cells("S-S") + all_cells("S-T"):
        solver.add(support_expr(cell))

    # Exact negative support: quantify every vector choice in every T-loop and
    # T-T cell.  This is not a sampled/route condition.
    if not SKIP_NEGATIVE:
        for cell in all_cells("T-loop") + all_cells("T-T"):
            solver.add(~support_expr(cell))

    # D5 four-cell no-join: for each omitted transferred S-S cell and every
    # singleton variant tuple on that cell's four positions, at least one of
    # the remaining four cells has no completing pair of triple vectors.
    if not SKIP_D5:
        for omitted_index, omitted in enumerate(D5_SS):
            retained = tuple(cell for index, cell in enumerate(D5_SS) if index != omitted_index)
            for singleton_bits in product(range(1 << K), repeat=5):
                fixed = {singleton_class(i): singleton_bits[i] for i in POSITIONS}

                def relation_expr(cell):
                    cls_slots = (triple_class(cell[0]), triple_class(cell[1])) + slots(cell)
                    variants = []
                    for triple_bits in product(range(1 << K), repeat=2):
                        choices = tuple(triple_bits) + tuple(fixed[cls] for cls in slots(cell))
                        variants.append(exact_expr(cell, choices))
                    return Or(*variants)

                solver.add(Or(*(~relation_expr(cell) for cell in retained)))

    return solver, bits, local


def AndAll(items):
    """Small helper avoiding an import of z3.And in generated expressions."""
    from z3 import And

    return And(*items)


def decode(model, bits, local):
    values = {}
    for class_index, cls in enumerate(CLASSES):
        values[cls] = {
            "bits": tuple(
                tuple(model.eval(bits[vector_id(cls, b)][c]).as_long() for c in CYCLE_COORDS)
                for b in range(1 << K)
            ),
            "local": model.eval(local[vector_id(cls, 0)]).as_long(),
        }
    return values


def check_model(model, values):
    """Independent exhaustive checks over the decoded finite family."""

    def vector_bits(cls, bit):
        return values[cls]["bits"][bit]

    def exact(cell, variants):
        cls_slots = (triple_class(cell[0]), triple_class(cell[1])) + slots(cell)
        vectors = [vector_bits(cls, bit) for cls, bit in zip(cls_slots, variants)]
        for c in CYCLE_COORDS:
            if sum(vector[c] for vector in vectors) != 2:
                return False
        labels = [values[cls]["local"] for cls in cls_slots for _ in (0,)]
        labels = [values[cls]["local"] for cls, _ in zip(cls_slots, variants)]
        return all(labels.count(edge) == 2 for edge in LOCAL_EDGES)

    def support(cell):
        cls_slots = (triple_class(cell[0]), triple_class(cell[1])) + slots(cell)
        return any(exact(cell, variants) for variants in all_variants(cls_slots))

    positive = all(support(cell) for cell in all_cells("S-loop") + all_cells("S-S") + all_cells("S-T"))
    negative = not any(support(cell) for cell in all_cells("T-loop") + all_cells("T-T"))
    joins = []
    for omitted_index, omitted in enumerate(D5_SS):
        retained = tuple(cell for index, cell in enumerate(D5_SS) if index != omitted_index)
        common = 0
        for singleton_bits in product(range(1 << K), repeat=5):
            fixed = {singleton_class(i): singleton_bits[i] for i in POSITIONS}

            def relation(cell):
                return any(
                    exact(cell, tuple(triple_bits) + tuple(fixed[cls] for cls in slots(cell)))
                    for triple_bits in product(range(1 << K), repeat=2)
                )

            if all(relation(cell) for cell in retained):
                common += 1
        joins.append(common)
    cubes = all(
        vector_bits(cls, 0)[c] == vector_bits(cls, 1)[c] if c != CLASS_INDEX[cls] else
        vector_bits(cls, 0)[c] == 0 and vector_bits(cls, 1)[c] == 1
        for cls in CLASSES for c in CYCLE_COORDS
    )
    local_partition = all(values[cls]["local"] in LOCAL_EDGES for cls in CLASSES)
    return {
        "positive_support": positive,
        "negative_T_support": negative,
        "d5_join_sizes": tuple(joins),
        "cube_closure": cubes,
        "local_partition": local_partition,
    }


def main():
    solver, bits, local = build_solver()
    status = solver.check()
    print("status=", status)
    if status != sat:
        if status == unsat:
            print("CLOSURE_TRIVALENT_EXACT40_D5_UNSAT")
        else:
            print("CLOSURE_TRIVALENT_EXACT40_D5_UNKNOWN")
        return
    model = solver.model()
    values = decode(model, bits, local)
    checks = check_model(model, values)
    print({"classes": len(CLASSES), "vectors": VECTOR_COUNT, "cycle_coordinates": len(CYCLE_COORDS), **checks})
    print("CLOSURE_TRIVALENT_EXACT40_D5_JOINFREE_SAT")
    for cls in CLASSES:
        print(cls, values[cls])


if __name__ == "__main__":
    main()
