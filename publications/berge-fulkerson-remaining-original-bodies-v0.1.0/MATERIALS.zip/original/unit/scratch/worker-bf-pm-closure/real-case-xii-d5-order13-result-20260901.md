# Real common-PM Case-XII/D5 pulse (order 13)

## Exact finite question

Enumerate every unlabelled simple connected augmented graph with degree
sequence ((5,3^{13})), delete its unique degree-five apex, and retain only
the connected proper-edge-bridgeless cubic 5-poles with five distinct
terminals.  For each retained pole, recursively enumerate its complete
perfect-matching family and compute all 55 ordinary BF support types, the
(A=(12345)) cover test, and (for any exact Case-XII candidate) all five D5
four-cell singleton joins.  Seek a pole with exactly the 40 Case-XII types,
no (A), no T-loop/T--T type, and all five D5 joins empty.

## Omen computation

The detached session was `bf-real-order13-20260901`; the scanner was run
without a prefix limit:

```text
python3 -u units/berge-fulkerson/scratch/worker-bf-order13-exact40-census/scan_order13_exact40.py \
  --geng [local archival reference] \
  --progress-every 1000 --json order13_exact40.json
```

The scanner's exact PM evaluator is the recursive family in
`worker-kempe/exact_st_joint_audit.py`; all support tests quantify over that
complete family.  It ended with `ORDER13_EXACT40_CENSUS_OK` in 42.44 s.

Counts:

```text
generated augmented graphs                 59,338
degree sequence (5,3^13)                    6,690
connected proper core                      6,374
proper-edge bridged                        1,580
proper-edge bridgeless                     4,794
exact Case-XII/no-A candidates                 0
```

No SAT witness exists in this complete order-13 family; therefore there is
no D5 join witness to post-verify.  This is a finite **no-hit**, not an
all-order UNSAT theorem and not a proof that every real pole has a D5 join.

Remote artifacts:

```text
[local archival reference]
[local archival reference]
```

SHA-256:

```text
scanner 3abef3d91849e16f72a45b3d6695a23d4d4895b83f96c8a908b2b42d106727fc
JSON    9343c5473679c175f7866e3b8e95a9454344dc27234ac840345d17949b149e4f
```

Order 15 was not launched in this pulse: prior bounded order-15/girth-five
runs are not complete censuses, and the present decision does not authorize
an unbounded scan after the order-13 no-hit.  Any order-15 result would be a
separate bounded boundary unless it returns an independently checked SAT
witness.

