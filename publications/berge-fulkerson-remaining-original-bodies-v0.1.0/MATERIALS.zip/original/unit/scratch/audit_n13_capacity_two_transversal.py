#!/usr/bin/env python3
"""Audit the capacity-two singleton-matching transversal at order 13."""

from collections import Counter
import subprocess

import networkx as nx

import case_xii_n13_c10_target as base


def capacity_two_witness(singleton):
    selected = []
    multiplicity = Counter()
    positions = sorted(singleton, key=lambda i: len(singleton[i]))

    def search(k):
        if k == len(positions):
            return tuple(selected)
        position = positions[k]
        for matching in singleton[position]:
            if any(multiplicity[e] >= 2 for e in matching):
                continue
            selected.append((position, matching))
            for edge in matching:
                multiplicity[edge] += 1
            if search(k + 1):
                return tuple(selected)
            for edge in matching:
                multiplicity[edge] -= 1
            selected.pop()
        return None

    return search(0)


def run(n=13):
    command = ["geng", "-q", "-c", "-d3", "-D5", str(n + 1), str((3 * n + 5) // 2)]
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    assert proc.stdout is not None
    counts = Counter()
    first_failure = None
    for line in proc.stdout:
        counts["generated"] += 1
        graph = nx.from_graph6_bytes(line.strip().encode())
        if Counter(dict(graph.degree()).values()) != Counter({3: n, 5: 1}):
            continue
        counts["degree_sequence"] += 1
        apex = next(v for v, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        counts["proper_connected"] += 1
        normalized = base.normalized_mapping(graph, apex, n)
        if normalized is None:
            continue
        counts["exact_C5_states"] += 1
        mapping, pole = normalized
        _, singleton, relations = base.relation_data(pole)
        witness = capacity_two_witness(singleton)
        if witness is None:
            counts["capacity_two_failures"] += 1
            first_failure = {
                "graph6": line.strip(),
                "mapping": mapping,
                "proper_edges": pole.proper_edges,
                "singleton_sizes": [len(singleton[i]) for i in range(1, 6)],
                "relation_sizes": [len(r) for r in relations],
            }
            break
        counts["capacity_two_successes"] += 1
    returncode = proc.wait()
    if first_failure is None:
        assert returncode == 0
    print({"counts": dict(counts), "first_failure": first_failure})
    return 1 if first_failure else 0


if __name__ == "__main__":
    raise SystemExit(run())
