# 四次 K4 二和的条件定理与匹配身份边界

独立核查日期：2026-09-25。核查范围为单元 README、冻结 SPEC、Notes 101、104、106–109，以及承重定义所在的 Notes 019、055、093、099、103。没有修改受跟踪文件。

**判定。** Pro 的构造对 Note 101 式 (6) 的六行、以二十二个名字为变量且要求同名复用的解释成立。四次插入保持完整 BF 边界关系，并使四个指定残差分别出现负坐标，从而排除所构造的固定行赋值的全部十六个矩形上下文。它不给出 exact-Case-XII 基极，也不裁决真实 Case XII。

“保持 literal matching identities”必须限定为六行要求的同名复用。构造不保持异名变量在输入中恰好相等的关系，也不保持全 PM 家族的全部线性恒等式。若要求保留 Note 101 式 (5) 那个具体十九身份实例的等同关系，则所给 U、W、V 构造不成立；下文给出实际图证书上的具体失败。

设 r=r23、s=r34、q'=q'25，并令每个匹配名字表示完整边对象上的 0/1 mask。六行是

\[
\begin{aligned}
&(r,B,X,q_{13},p^1_{13},p^3_{13}),\\
&(r,B,X,q_{14},A,C),\\
&(r,B,X,q_{24},p^2_{24},p^4_{24}),\\
&(r,B,X,q_{25},p^2_{25},p^5_{25}),\\
&(r,B,X,q_{35},P_3,P_5),\\
&(q',s,B,Y,C,D).
\end{aligned}
\]

每行之和为 2𝟙。名字集合记为 L；balanced 表示与每行恰交两个名字。

## 完整 PM 提升与 BF 支撑

从 G 删除 proper edge uv，从新 K4 删除 01，再接 u0、v1。四个新顶点的匹配割奇偶性强制两个接入边同时被选或同时不选，所以全部局部 PM 模式恰为

\[
C_0=\{u0,v1,23\},\qquad
C_1=\{02,13\},\qquad C_2=\{03,12\}.
\]

旧 PM 含 uv 时只有 C0 延拓；不含 uv 时恰有 C1、C2 两种延拓。投影恢复 uv 当且仅当两个接入边被选。这是全部 PM 的精确描述，边界 masks 不变。

新图的任意 BF 行投影为旧图 BF 行，因为接入边负载二使恢复的 uv 也负载二。反向对旧图任意 BF 行，两个含 uv 的 occurrence 使用 C0，剩余四个 occurrence 两个使用 C1、两个使用 C2，即得新图 BF 行。因此保持的是完整的六 occurrence 边界关系，当然也保持完整 BF boundary support；没有用 selected-family 负支持替代完整闭包。

若端口的名字集合为 σ，取与 σ 不交的 balanced τ，令名字属于 σ、τ、L\(σ∪τ) 时分别采用 C0、C1、C2。每行每种模式恰用两次，六行同时成立。同名 occurrence 的延拓始终一致。02、13 都是 τ-边，给出一次合法转移 σ→τ。

该论证不把不同名字自动识别成同一变量。即使输入中的两个不同名字恰为同一个旧 PM，给它们不同的新模式也只是取得该旧 PM 的不同延拓；这正是下面的身份边界。

## 对所有 balanced σ 的桥引理

取

\[
\begin{aligned}
U&=\{r,X,Y,D\},\\
V&=\{X,A,Y,s,q_{13},q_{24},q_{25},q_{35}\},\\
W&=\{B,C,p^1_{13},p^2_{24},p^2_{25},P_3\}.
\end{aligned}
\]

它们逐行恰交两个名字，且 U∩W=V∩W=∅。

令 H={r,B,X}，第一至第五行写作 H∪Eij，其中五个 Eij 为两两不交的三名字块，E14={q14,A,C}。若 c=|σ∩H|，则 c≤2 且 |σ∩Eij|=2−c。

在四个 Eij≠E14 中，B∉σ 时各取一个不在 σ 的名字，B∈σ 时各取两个。这总是可行：前者每块至少剩一个；后者 c≥1，每块至少剩两个。再按表加入名字：

| B∈σ | C∈σ | 加入 Z |
|---|---|---|
| 否 | 否 | B,C |
| 否 | 是 | B,h,t |
| 是 | 否 | C,h,t |
| 是 | 是 | q14,A,q',s |

其中 h∈{q14,A}\σ，t∈{q',s}\σ。两个中间情形中，E14 配额保证 h 存在；第六行已经被 B 或 C 占一位，保证 t 存在。最后一行中 B,C 已占满第六行，因此 q',s 均不在 σ；同时 E14 的唯一 σ 元素是 C，因此 q14,A 都可用。

当 B∉σ 时，Z 含 B 和每个 Eij 的一个名字；当 B∈σ 时，Z 不含 H 的名字而在每个 Eij 中取两个。第六行的交集依次为 {B,C}、{B,t}、{C,t}、{q',s}。故 Z balanced，且 Z∩(σ∪U)=∅。这给出不限图阶的解析证明，不依赖有限图 census。

## 四次插入与十六上下文

沿

\[
\sigma\longrightarrow Z\longrightarrow U\longrightarrow W\longrightarrow V
\]

插入四个 K4，增加十六个顶点。第二次产生的两条 U-边只用一条作为后续端口，保留另一条 e；最后保留一条 V-边 f。前述逐步证明保持完整支撑、六行和同名复用。

记

\[
\begin{aligned}
K_{23}&=2\mathbf1-r-B-X,&K_{34}&=2\mathbf1-s-Y-C,\\
R_Y&=K_{23}-Y,&R_D&=K_{23}-D,\\
R_A&=K_{34}-A,&R_X&=K_{34}-X.
\end{aligned}
\]

在 e 上 r=X=Y=D=1、B=0；在 f 上 s=Y=A=X=1、C=0。因此

\[
R_Y(e)=R_D(e)=-1,\qquad R_A(f)=R_X(f)=-1.
\]

这里 f 也区分 q25 与 q'：前者为 1，后者为 0。

对 Note 109 的任一上下文，以 T 表示其 literal target，以 L0 表示 leakage matching（避免与上面的名字集合 W 混淆）。若矩形成立，必须有

\[
K=P+N+L_0,\qquad Q=N+P-T\in\mathcal P(G).
\]

于是

\[
K-T=Q+L_0\ge0.
\]

entry 情形 P=T，取 Q=N，同一推导成立。事实上该残差还只有偶闭分量，因为它是两个 PM 之和。四个负坐标已经否定必要的非负性，故排除全部四种 target、各自四个上下文。此步不要求事先认定 first-projection 失败、不使用 Note 104 的唯一 leakage 推论，也不依赖如何定义 opposite-witness eligibility。

## “身份保持”的实际反例边界

Note 101 式 (5) 的具体表有

\[
A=p^1_{13},\qquad P_3=p^3_{13},\qquad P_5=p^5_{25}.
\]

这些不是一般六行式 (6) 强制的等式。所给 V 含 A 而不含 p13_1，所以任何 occurrence set 为 V 的边都强制二者的完整 masks 不同；W 同样将它们分开。W 也将 P3 与 p13_3 分开。

这不只是形式上的疑问。独立读取 Note 102 的 67 顶点图证书 `computations/bundles/global-pairing-and-full-closure-boundary/note101_global_stub_pairing_result.json`，按端点重建 98 条 proper edges 和五条 semiedges，直接验证了三价性、全部二十二个名字的真实 PM 约束、全部六行和上述三个等式。故该实际输入满足六行，但 Pro 的 V-边不可能保留 A=p13_1。无需把这个基极误称为 exact Case XII；它已经反驳“对任意实际六行输入保留全部已有身份等式”这一更强读法。

Notes 099、103 的存在性提升与 Pro 的结论没有矛盾。端点星规范提升可以保留已有的匹配等式与成功 fibre；Pro 刻意选取另一个、只保证六行同名复用的提升，制造一个坏的固定赋值。它不证明新图上所有可能行赋值都失败。

## 冻结 SPEC 与真实 Case XII

冻结 SPEC 第 3 行写的是 every rooted cubic five-pole、complete exact Case-XII support 和 fixed Note-101 rows。它没有加入 girth、cyclic edge connectivity、minimum whole-graph counterexample 或 indecomposability。

四次插入保持输入已有的 simplicity、connectedness、absence of proper bridges。最后一个 K4−edge 内有三角形，其两个接入边切下一个无原始终端的循环部分；补侧也有前面因子的循环。因此输出确有 cyclic proper 2-cut。这个性质没有违反冻结 SPEC 的文字条件。

相比之下，Note 019 研究的真正最小整图反例为 cyclically 5-edge-connected。上述 terminal-free cyclic 2-cut 在接回另一侧之后仍然存在，所以输出不属于那个更强的最小反例类。不能将那一类的额外假设偷偷补入冻结 SPEC，也不能把当前构造用于裁决那个更强的类。

精确地，令 X 为满足冻结支撑条件、并带上述六行同名赋值的有根极对 (G,ρ)。已经证明

\[
X\ne\varnothing\ \Longrightarrow\
\exists(G^*,\rho^*)\in X:\neg\operatorname{Rect}(G^*,\rho^*),
\]

从而

\[
\boxed{\bigl[\forall(G,\rho)\in X,\operatorname{Rect}(G,\rho)\bigr]
\iff X=\varnothing.}
\]

该等价是严格的条件归约，不能推出 X 非空或为空。它也不是 `∀G ∃ρ Rect(G,ρ)` 的反例，更不是所有 exact-Case-XII 极的不存在性证明；把 X 为空用于排除全部 Case XII，还需要证明每个目标极都具有规定共享身份的六行。

冻结 SPEC 的真正 NOGO 要求已认证 exact-Case-XII 基极及完整 PM/support 证书。本核查未提供这种基极，所以不能宣告主命题已证伪或真实 Case XII 已解决。可关闭的是非空且对这些附着封闭的类上、对任意固定六行赋值强迫矩形的非空泛路线。

## 有限核对及文献边界

重放并检查已有的 `rectangle_balanced_check_20260924.py`：4,469 个 balanced 输入、67,149 个表格允许的桥选择均通过；K4 有三种局部 PM 模式、90 个有序 BF 局部行，对每种二槽端口状态有六种延拓。

另用 `k4_factor_graph_check_20260925.py` 直接构造固定十六顶点因子，独立按图枚举得 13 个 PM、42 个 BF 六重集；对所有 4,469 个输入逐一验证真实因子 PM、六行、受保护 U/V 边和四个负坐标。该脚本也直接核验上述 67 顶点身份等式反例。最大枚举对象是固定十六顶点图，不进行基极全 PM 或图阶 census。

文献检索日期为 2026-09-25。通过 OpenAlex 定向核对了 Máčajová–Mazzuoccolo, *Reduction of the Berge-Fulkerson conjecture to cyclically 5-edge-connected snarks*, DOI 10.1090/proc/15057，以及 Máčajová–Mazzuoccolo–Tabarelli, *Cycle separating cuts in possible counterexamples to the cycle double cover and the Berge-Fulkerson conjectures*, DOI 10.26493/1855-3974.3409.c13 的书目信息与作者摘要。前者摘要明确给出 minimum-counterexample cyclic-5 条件；后者涉及五割的十三类 admissible-set 对。本轮未重新核验其全文证明，也未提出文献新颖性判断。上面的 K4、桥引理和量词结论均由本地定义直接证明。
