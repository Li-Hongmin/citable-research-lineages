# A coherent Kempe-routing refinement for Berge–Fulkerson 5-poles

**Status:** independent research note; not peer reviewed.  The conclusions below take the published 13-case Appendix of Mácajová–Mazzuoccolo–Tabarelli, *Ars Mathematica Contemporanea* 26 (2026), P2.03, as input.  They do **not** independently reproduce the paper's earlier enumeration of 883 candidate sets or its reduction to 13 disjoint pairs.

## 1. Setup

A BF-colouring of a cubic 5-pole assigns a two-element subset of six colours to every edge/semiedge so that incident labels are disjoint.  For two colours `a,b`, the `a-b` subgraph consists of alternating cycles and paths.  If the symmetric difference of their boundary incidence sets is nonempty, it has two or four boundary endpoints.  The path components therefore induce a pairing of those endpoints.

For a fixed BF-colouring `phi`, write `rho_ab(phi)` for this **actual** endpoint pairing.  It is hidden when only the boundary type is retained, but it exists simultaneously for all colour pairs.

### Lemma 1: component-wise closure

For every block `P` of `rho_ab(phi)`, switching `a` and `b` along the corresponding Kempe path produces another BF-colouring of the same pole.  Hence its boundary type must belong to the pole's exact admissible-type set.

### Lemma 2: coherent commutation

If `{a,b}` and `{c,d}` are disjoint colour pairs, their Kempe switches commute.  Consequently, for every block `P` of `rho_ab(phi)` and every block `Q` of `rho_cd(phi)`, switching on both paths produces an admissible type.  Crucially, the same routing `rho_ab(phi)` must work simultaneously against every disjoint colour pair; one cannot select a different routing for each pairwise test.

These are necessary conditions for an exact admissible-type set.  They strengthen a type-level test that merely asks whether some one- or two-switch outcomes can be selected independently.

## 2. Eliminating case XIII

Suppose a 5-pole admits the type `(12345)`.  Relabel colours so that the five boundary labels are

```
e1={0,1}, e2={0,2}, e3={0,3}, e4={0,4}, e5={0,5}.
```

Consider colours `0` and `2`.  Their boundary endpoints are `e1,e3,e4,e5`.  The actual two Kempe paths must pair these four endpoints in one of exactly three ways.  Switching either component gives respectively

```
13|45  -> (13)(45)
14|35  -> (14)(35)
15|34  -> (15)(34).
```

The published set `R*` in case XIII contains none of these three types.  Therefore it cannot be the exact admissible-type set of a 5-pole.  Case XIII is excluded by a one-pair, one-switch argument.

More generally, if an exact admissible set contains `(12345)`, then for every boundary position `t` it must contain at least one of the three types corresponding to a perfect matching of the other four positions.

## 3. Eliminating cases III and VI

Both published sets contain `alpha=(25)(34)`.  Use the following representative BF boundary labels:

```
e1={0,1}, e2={0,2}, e3={1,3}, e4={1,4}, e5={0,5}.
```

Colour `0` occurs at positions `1,2,5` and misses `3,4`; colour `1` occurs at `1,3,4` and misses `2,5`, so this is indeed type `(25)(34)`.

### The `0-3` routing

Its endpoints are `1,2,3,5`.  The three possible routings give:

```
12|35 -> (25)(45), absent;
13|25 -> (14)(25), present;
15|23 -> (24)(25), present.
```

Thus the actual routing is either

```
A = 13|25,  or  B = 15|23.
```

### The `1-2` routing

Its endpoints are `1,2,3,4`:

```
12|34 -> (15)(34), absent;
13|24 -> (34)(45), absent;
14|23 -> (34)(35), present.
```

Hence it is forced to be `14|23`.

### The `1-5` routing

Its endpoints are `1,3,4,5`:

```
13|45 -> (24)(34), present;
14|35 -> (23)(34), absent;
15|34 -> (12)(34), absent.
```

Hence it is forced to be `13|45`.

Now `{0,3}` is colour-disjoint from both `{1,2}` and `{1,5}`.

* If the `0-3` routing is `A=13|25`, combining it with the forced `1-2` routing always produces `(14)(35)`, which is absent.
* If the `0-3` routing is `B=15|23`, combining it with the forced `1-5` routing always produces `[24]`, which is absent.

Both possible routings lead to contradictions.  Therefore no BF-colouring of type `(25)(34)` can occur in a pole whose exact admissible set is case III or case VI.  Since both candidate sets explicitly contain that type, cases III and VI are excluded.

## 4. Conditional refinement of the 13-case list

Taking the published 13-case enumeration as exhaustive, the coherent-routing test leaves

```
I, II, IV, V, VII, VIII, IX, X, XI, XII.
```

Thus the published list is conditionally reduced from 13 candidates to 10.

The paper separately shows that, if the `L` side is 3-edge-colourable, only cases XII and XIII survive its loop test.  Combining that statement with the exclusion of XIII leaves only XII in the 3-edge-colourable-`L` subcase.

## 5. Computational audit

Two independent Python programs accompany this note.

1. `bf_5cut_certificate.py` contains only the three local certificates.  It also checks 48 colour presentations of `(25)(34)` for each of cases III and VI.
2. `kempe_routing_audit.py` parses all 13 Appendix sets, assigns a hidden routing to every switchable colour pair, enforces all component-wise switches and all commuting two-pair switches, and solves the resulting finite CSP.

The full audit reports:

```
eliminated: III,VI,XIII
remaining : I,II,IV,V,VII,VIII,IX,X,XI,XII
```

The audit is a necessary-condition checker, not a realizability proof for the ten surviving cases.

## 6. What remains unverified

Before presenting this as a formal correction/refinement, the following checks are still required:

1. an independent human verification by specialists in BF-colourings and multipoles;
2. confirmation that the Appendix transcription exactly matches the authors' intended ordered-semiedge convention;
3. ideally, a response from the original authors or an independent reimplementation of their 883-to-13 enumeration;
4. formalization of the two routing lemmas and the finite membership checks in a proof assistant or a compact proof certificate.

The strongest current claim is therefore:

> **Candidate theorem.** Under the definitions and Appendix sets as published, cases III, VI and XIII violate necessary simultaneous Kempe-routing constraints.  Conditional on the published 13-case enumeration, only ten cases remain.
