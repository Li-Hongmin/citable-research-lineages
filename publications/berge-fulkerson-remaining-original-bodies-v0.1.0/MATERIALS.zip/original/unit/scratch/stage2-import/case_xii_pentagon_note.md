# A pentagonal perfect-matching reduction for Berge–Fulkerson Case XII

**Status.** Independent research note, not peer reviewed. The published 13-case analysis of Mácajová–Mazzuoccolo–Tabarelli is taken as input. The new lemma below is elementary and self-contained; the finite verification is reproduced by the accompanying standalone program.

## 1. Published Case-XII input

Let the five semiedges be numbered `1,...,5`. For the 5-cycle side, write

\[
T=\{12,15,23,34,45\}.
\]

Its BF admissible-type set consists of `(12345)` together with all pair-types and loops on the five vertices of `T`. In published Case XII, the other side has the complementary 40 BF types. Its loop types are therefore

\[
S=\{13,14,24,25,35\},
\]

which form the complementary pentagon

\[
1-4-2-5-3-1.
\]

The paper proves that Case XII is the only one among Cases I–XII in which that side can be 3-edge-colourable. Starting from any Tait colouring, the Kempe-chain argument in Lemma 4.3 generates the two neighbouring lonely-pair states. Since a Case-XII pole cannot have a lonely pair in `T` (its self-overlap would give a forbidden loop), iteration forces its complete set of Tait lonely-pair states to be exactly `S`.

## 2. Singleton perfect matchings and the compatibility graph

For each boundary position `i`, let

\[
\mathcal P_i=\{P:\ P\text{ is a perfect matching using exactly semiedge }i\}.
\]

For `P in P_i` and `Q in P_j`, write `P ~ Q` when `P` and `Q` are edge-disjoint. Then their complement is a third perfect matching, so `P,Q` and the complement form a Tait colouring with lonely pair `ij`.

Thus a compatible pentagon is a choice

\[
P_1\in\mathcal P_1,
P_4\in\mathcal P_4,
P_2\in\mathcal P_2,
P_5\in\mathcal P_5,
P_3\in\mathcal P_3
\]

such that

\[
P_1\sim P_4\sim P_2\sim P_5\sim P_3\sim P_1.
\]

## 3. Pentagonal perfect-matching lemma

**Lemma.** Let `H` be a cubic 5-pole. Suppose there are five perfect matchings `P_1,...,P_5` such that:

1. `P_i` uses exactly semiedge `i`;
2. `P_i` and `P_j` are edge-disjoint whenever
   \(ij\in S=\{13,14,24,25,35\}\).

Then `H` has a BF-colouring of boundary type `(12345)`.

**Proof.** For every edge or semiedge `e`, put

\[
m(e)=|\{i:e\in P_i\}|.
\]

The indices of matchings containing a fixed edge form an independent set of the 5-cycle `S`; hence `m(e) <= 2`.

At every vertex, each of the five perfect matchings chooses exactly one of the three incident edges. The three incident multiplicities therefore sum to 5, and each is at most 2. They must be

\[
\{2,2,1\}.
\]

Let

\[
P_0=\{e:m(e)=1\}.
\]

Exactly one incident edge belongs to `P_0` at every vertex, so `P_0` is a perfect matching. Semiedge `i` occurs only in `P_i`, and therefore every semiedge belongs to `P_0`. Finally, an edge with `m(e)=1` is covered once by `P_1,...,P_5` and once by `P_0`, whereas an edge with `m(e)=2` is already covered twice and is not in `P_0`. Thus

\[
P_0,P_1,\ldots,P_5
\]

cover every edge exactly twice. Their boundary multiplicities are `5,1,1,1,1,1`, which is type `(12345)`. ∎

### Consequence for Case XII

Because `(12345)` belongs to the 5-cycle side and is excluded from published Case-XII `L*`, any actual Case-XII pole must have **no compatible pentagon** in its singleton-perfect-matching compatibility graph.

This converts Case XII into a precise selection problem:

> Can the Kempe-generated five Tait boundary states be lifted to one compatible pentagon of actual perfect matchings?

That is the remaining infinite-order gap.

## 4. Exact small-order verification

The accompanying program exhaustively checks connected simple cubic 5-poles with:

- `n=5,7,9` internal vertices;
- five distinct boundary vertices;
- one fixed Tait colouring normalised to state `14`.

The normalisation loses no Case-XII possibilities: colours can be renamed, and the five boundary positions are fixed. For each order the program:

1. enumerates all three colour-class matchings with the normalised boundary colours;
2. rejects repeated proper edges and disconnected proper graphs;
3. deduplicates equal **labelled** proper-edge sets;
4. enumerates every Tait colouring and retains exactly those poles whose lonely-pair state set is `S`;
5. enumerates all perfect matchings with singleton boundary;
6. searches for the compatible pentagon;
7. constructs `P_0` by the lemma and checks every vertex and every edge.

The exact output is:

| internal vertices `n` | raw colour-matching triples | valid connected simple coloured triples | distinct labelled proper-edge sets | Case-XII Tait-state candidates | pentagon and `(12345)` verified |
|---:|---:|---:|---:|---:|---:|
| 5 | 9 | 6 | 6 | 1 | 1 |
| 7 | 675 | 276 | 246 | 10 | 10 |
| 9 | 165,375 | 56,592 | 41,508 | 780 | 780 |

Therefore:

> **Finite verification theorem.** Under the simple/distinct-terminal hypotheses above, no Case-XII 5-pole exists with at most nine internal vertices. Equivalently, any such side of a putative minimum BF counterexample has at least eleven internal vertices.

The numerical lower bound is not the main value—the important output is the new exact interface: a candidate must realise all five Tait states while its singleton-perfect-matching compatibility graph remains a nontrivial lift of the pentagon with no 5-cycle.

## 5. What this does and does not prove

### Proved in this note

- the pentagonal perfect-matching lemma;
- the reduction of Case XII to pentagon selection;
- complete labelled enumeration for `n=5,7,9` under the stated structural hypotheses;
- an explicit `(12345)` certificate for every retained small-order candidate.

### Not yet proved

- that every Case-XII Tait-state system contains a compatible pentagon in arbitrary order;
- that published Case XII is impossible;
- the full Berge–Fulkerson conjecture.

### Most economical next target

Let the five parts of the compatibility graph be `P_1,...,P_5`, with edges only along the base cycle `1-4-2-5-3-1`. Kempe switching implies local continuation in both directions, but an abstract finite cover of a 5-cycle can have only 10-cycles and no 5-cycle. The missing theorem must use additional matching structure—not merely local arc consistency—to rule out such nontrivial holonomy.

A natural next attack is a parity or Pfaffian invariant for the five bipartite compatibility relations. If it forces the product relation around the pentagon to have a fixed point, Case XII is eliminated and, combined with the published analysis, the entire 3-edge-colourable-side branch disappears.
