#!/usr/bin/env python3
"""
Independent boundary-level Kempe-routing audit for the 13 five-cut cases
listed in the Appendix of Macajova--Mazzuoccolo--Tabarelli,
Ars Math. Contemp. 26 (2026), P2.03.

No graph-generation package is required.  The script checks a necessary
condition: every BF-colouring has a simultaneously defined pairing of the
boundary endpoints of each two-colour Kempe subgraph.  Single switches, and
commuting switches for disjoint colour pairs, must stay inside the pole's
admissible type set.
"""
from itertools import combinations, permutations
import re

COLORS=tuple(range(6))
PAIRS=tuple(combinations(COLORS,2))
RAW={'I': '\n(12)(35) (13)(35) (15)(35) (23)(35) (25)(35) [35]\n(12)(25) (15)(25) (13)(25) (14)(25) (23)(25) (24)(25) [25]\n(12)(24) (13)(24) (15)(24) (23)(24)\n(12)(14) (14)(23) (14)(15) (13)(14)\n(12)(13) (13)(15) (13)(23) [13]\n', 'II': '\n(12)(35) (13)(35) (15)(35) (23)(35) (25)(35) [35]\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) [14]\n(12)(13) (13)(15) (13)(23) [13]\n', 'III': '\n(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]\n(12)(24) (13)(24) (15)(24) (14)(24) (23)(24) (24)(34)\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) [13]\n', 'IV': '\n(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34)\n(12)(13) (13)(15) (13)(23) (13)(34) [13]\n', 'V': '\n(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) [13]\n', 'VI': '\n(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35) [35]\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34)\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) [13]\n', 'VII': '\n(12)(35) (13)(35) (15)(35) (23)(35) (24)(35) (25)(35) (34)(35) [35]\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) [13]\n', 'VIII': '\n(12)(35) (13)(35) (25)(35) (14)(35) (15)(35) (23)(35) (24)(35) (34)(35) (35)(45)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) (25)(45) [25]\n(12)(24) (13)(24) (15)(24) (23)(24) (24)(34) (24)(45)\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) (14)(45)\n(12)(13) (13)(15) (13)(23) (13)(34) (13)(45) [13]\n', 'IX': '\n(12)(35) (13)(35) (25)(35) (14)(35) (15)(35) (23)(35) (24)(35) (34)(35) (35)(45) [35]\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) (25)(45) [25]\n(12)(24) (13)(24) (15)(24) (23)(24) (24)(34) (24)(45)\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) (14)(45)\n(12)(13) (13)(15) (13)(23) (13)(34) (13)(45) [13]\n', 'X': '\n(12)(35) (13)(35) (25)(35) (14)(35) (15)(35) (23)(35) (24)(35) (34)(35) (35)(45)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) (25)(45) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) (24)(45)\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) (14)(45) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) (13)(45) [13]\n', 'XI': '\n(12)(35) (13)(35) (25)(35) (14)(35) (15)(35) (23)(35) (24)(35) (34)(35) (35)(45)\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) (25)(45) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) (24)(45) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) (14)(45) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) (13)(45) [13]\n', 'XII': '\n(12)(35) (13)(35) (25)(35) (14)(35) (15)(35) (23)(35) (24)(35) (34)(35) (35)(45) [35]\n(12)(25) (13)(25) (14)(25) (15)(25) (23)(25) (24)(25) (25)(34) (25)(45) [25]\n(12)(24) (13)(24) (14)(24) (15)(24) (23)(24) (24)(34) (24)(45) [24]\n(12)(14) (13)(14) (14)(15) (14)(23) (14)(34) (14)(45) [14]\n(12)(13) (13)(15) (13)(23) (13)(34) (13)(45) [13]\n', 'XIII_R': '\n(12)(35) (15)(35) (23)(35) (25)(35) (34)(35)\n(12)(45) (15)(45) (23)(45) (25)(45) (34)(45)\n(12)(24) (15)(24) (23)(24) (24)(25) (24)(34)\n(12)(13) (13)(15) (13)(23) (13)(25) (13)(34)\n(12)(14) (14)(15) (14)(23) (14)(25) (14)(34)\n(12345)\n', 'XIII_L': '\n(13)(35) (14)(35) (24)(35) (35)(45) [35]\n(13)(45) (14)(45) (24)(45) [45]\n(13)(24) (14)(24) [24]\n(13)(14) [14]\n[13]\n(12)(15) (12)(23) (12)(34) (12)(45) [12]\n(15)(23) (23)(34) (23)(45) [23]\n(15)(34) (34)(45) [34]\n(15)(45) [45]\n[15]\n'}

def parse_types(s):
    toks=re.findall(r'\(\d\d\)\(\d\d\)|\[\d\d\]|\(12345\)',s)
    out=set()
    for tok in toks:
        if tok=='(12345)':
            out.add(('A',))
        elif tok.startswith('['):
            a=tuple(map(int,tok[1:3]))
            out.add((a,a))
        else:
            m=re.match(r'\((\d)(\d)\)\((\d)(\d)\)',tok)
            a=tuple(sorted((int(m.group(1)),int(m.group(2)))))
            b=tuple(sorted((int(m.group(3)),int(m.group(4)))))
            out.add(tuple(sorted((a,b))))
    return out

def human(t):
    if t==('A',):
        return '(12345)'
    a,b=t
    if a==b:
        return f'[{a[0]}{a[1]}]'
    return f'({a[0]}{a[1]})({b[0]}{b[1]})'

def representative(t):
    # Boundary positions are 1,...,5.  Colours 0 and 1 are the two
    # triple colours; 2,3,4,5 are lonely colours.
    if t==('A',):
        return tuple((0,i) for i in range(1,6))
    a,b=t
    labs=[[] for _ in range(5)]
    for pos in range(1,6):
        if pos not in a:
            labs[pos-1].append(0)
        if pos not in b:
            labs[pos-1].append(1)
    lonely=iter(range(2,6))
    for pos in range(5):
        while len(labs[pos])<2:
            labs[pos].append(next(lonely))
        labs[pos]=tuple(sorted(labs[pos]))
    return tuple(labs)

def boundary_type(bl):
    counts=[sum(c in lab for lab in bl) for c in COLORS]
    if sorted(counts)==[1,1,1,1,1,5]:
        return ('A',)
    assert sorted(counts)==[1,1,1,1,3,3], counts
    triple=[c for c in COLORS if counts[c]==3]
    miss=[]
    for c in triple:
        miss.append(tuple(i+1 for i,lab in enumerate(bl) if c not in lab))
    return tuple(sorted(miss))

def endpoints(bl,c,d):
    return tuple(i for i,lab in enumerate(bl) if ((c in lab) ^ (d in lab)))

def pairings(E):
    if len(E)==2:
        return ((E,),)
    assert len(E)==4
    a,b,c,d=E
    return (((a,b),(c,d)),((a,c),(b,d)),((a,d),(b,c)))

def switch(bl,c,d,path):
    ans=[set(x) for x in bl]
    for i in path:
        assert (c in ans[i]) ^ (d in ans[i])
        if c in ans[i]:
            ans[i].remove(c); ans[i].add(d)
        else:
            ans[i].remove(d); ans[i].add(c)
    return tuple(tuple(sorted(x)) for x in ans)

def domains_for(alpha,H):
    bl=representative(alpha)
    domains={}
    for q in combinations(COLORS,2):
        E=endpoints(bl,*q)
        if not E:
            continue
        good=[]
        for routing in pairings(E):
            # Every path component is switchable.
            if all(boundary_type(switch(bl,*q,path)) in H for path in routing):
                good.append(routing)
        if not good:
            return None,('unary',q)
        domains[q]=good
    return domains,None

def coherent(alpha,H):
    bl=representative(alpha)
    domains,err=domains_for(alpha,H)
    if err:
        return False,err
    variables=list(domains)
    compat={}
    for i,q in enumerate(variables):
        for r in variables[i+1:]:
            if set(q)&set(r):
                continue
            allowed=set()
            for iq,oq in enumerate(domains[q]):
                for ir,orr in enumerate(domains[r]):
                    ok=True
                    for p in oq:
                        b1=switch(bl,*q,p)
                        for s in orr:
                            # q and r use four distinct colours, so their
                            # Kempe switches commute and the r-routing persists.
                            if boundary_type(switch(b1,*r,s)) not in H:
                                ok=False
                                break
                        if not ok:
                            break
                    if ok:
                        allowed.add((iq,ir))
            if not allowed:
                return False,('binary',q,r)
            compat[(q,r)]=allowed

    order=sorted(variables,key=lambda q:len(domains[q]))
    assignment={}
    def permitted(q,i):
        for r,j in assignment.items():
            if set(q)&set(r):
                continue
            if (q,r) in compat and (i,j) not in compat[(q,r)]:
                return False
            if (r,q) in compat and (j,i) not in compat[(r,q)]:
                return False
        return True
    def dfs(k):
        if k==len(order):
            return True
        q=order[k]
        for i in range(len(domains[q])):
            if permitted(q,i):
                assignment[q]=i
                if dfs(k+1):
                    return True
                del assignment[q]
        return False
    sat=dfs(0)
    return sat,('sat',) if sat else ('global-unsat',)

L={k:parse_types(v) for k,v in RAW.items() if k in
   ('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII')}
L['XIII']=parse_types(RAW['XIII_L'])
R_COMMON=parse_types("""
(12)(15) (12)(23) (12)(34) (12)(45) [12]
(15)(23) (23)(34) (23)(45) [23]
(15)(34) (34)(45) [34]
(15)(45) [45]
[15]
(12345)
""")
R_XIII=parse_types(RAW['XIII_R'])

def audit_set(name,H):
    bad=[]
    for alpha in sorted(H,key=human):
        ok,why=coherent(alpha,H)
        if not ok:
            bad.append((alpha,why))
    print(f"{name:8s} size={len(H):2d}  incoherent={len(bad)}")
    for alpha,why in bad:
        print("   ",human(alpha),why)
    return bad

if __name__=='__main__':
    print("Kempe-routing audit")
    eliminated=[]
    for case in ('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'):
        badL=audit_set(case+' L',L[case])
        badR=audit_set(case+' R',R_COMMON)
        if badL or badR:
            eliminated.append(case)
    badL=audit_set('XIII L',L['XIII'])
    badR=audit_set('XIII R',R_XIII)
    if badL or badR:
        eliminated.append('XIII')
    remaining=[x for x in ('I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII')
               if x not in eliminated]
    print("eliminated:",','.join(eliminated))
    print("remaining :",','.join(remaining))

    # Minimal human-readable certificates.
    print("\nCase XIII, type (12345), central colour 0 vs lonely colour at position 2:")
    bl=representative(('A',))
    for routing in pairings(endpoints(bl,0,2)):
        outs={human(boundary_type(switch(bl,0,2,p))) for p in routing}
        print(tuple(tuple(i+1 for i in p) for p in routing),"->",sorted(outs))

    # A convenient representative of type (25)(34): colours 0 and 1 are
    # the triple colours, missing positions {3,4} and {2,5}, respectively.
    # Boundary semiedges e_1,...,e_5 carry:
    #   {0,1}, {0,2}, {1,3}, {1,4}, {0,5}.
    alpha=((2,5),(3,4))
    bl=((0,1),(0,2),(1,3),(1,4),(0,5))
    assert boundary_type(bl)==alpha
    print("\nCases III/VI certificate for alpha=(25)(34), boundary=",bl)
    chosen={}
    for q in ((0,3),(1,2),(1,5)):
        print("pair",q,"endpoints",tuple(i+1 for i in endpoints(bl,*q)))
        good=[]
        for routing in pairings(endpoints(bl,*q)):
            outs={human(boundary_type(switch(bl,*q,p))) for p in routing}
            inside=all(boundary_type(switch(bl,*q,p)) in L['III'] for p in routing)
            print(" ",tuple(tuple(i+1 for i in p) for p in routing),"->",sorted(outs),
                  "inside=",inside)
            if inside:
                good.append(routing)
        chosen[q]=good

    print("\nForced/coherent-routing contradiction:")
    # The 1--2 routing is forced; the 1--5 routing is forced; 0--3 has two
    # possible routings.  Disjoint-colour switches commute.
    r12=chosen[(1,2)][0]
    r15=chosen[(1,5)][0]
    for tag,r03 in zip(('A','B'),chosen[(0,3)]):
        for q2,r2 in (((1,2),r12),((1,5),r15)):
            outs=set()
            for pth03 in r03:
                b1=switch(bl,0,3,pth03)
                for pth2 in r2:
                    outs.add(human(boundary_type(switch(b1,*q2,pth2))))
            print(f"  03-{tag} + {q2} -> {sorted(outs)}; inside III/VI =",
                  all(parse_types(' '.join(outs)).issubset(L['III']) for _ in [0]))
