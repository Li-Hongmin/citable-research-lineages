#!/usr/bin/env python3
"""Pure-standard-library verifier for the Omen PM exchange certificate."""

from __future__ import annotations

from itertools import combinations


N = 7
TERMINALS = set(range(5))
EDGES = {
    (0, 5), (0, 6), (1, 2), (1, 5),
    (2, 4), (3, 4), (3, 6), (5, 6),
}
M = {(1, 5), (2, 4), (3, 6)}
P = {(1, 2), (3, 4), (5, 6)}


def norm(edge):
    u, v = edge
    return (u, v) if u < v else (v, u)


def degree(edges, vertex):
    return sum(vertex in edge for edge in edges)


def connected(edges):
    adjacency = {v: set() for v in range(N)}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in adjacency[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == N


def has_bridge(edges):
    for edge in edges:
        remainder = set(edges) - {edge}
        if not connected(remainder):
            return True
    return False


def is_singleton_pm(edges, boundary=0):
    if not edges <= EDGES:
        return False
    return all(degree(edges, v) == (0 if v == boundary else 1)
               for v in range(N))


def all_singleton_pms(boundary=0):
    answer = set()
    ordered = sorted(EDGES)
    for size in range(len(ordered) + 1):
        for chosen in combinations(ordered, size):
            candidate = frozenset(chosen)
            if is_singleton_pm(candidate, boundary):
                answer.add(candidate)
    return answer


def main():
    assert len(EDGES) == 8
    assert all(degree(EDGES, v) == (2 if v in TERMINALS else 3)
               for v in range(N))
    assert connected(EDGES)
    assert not has_bridge(EDGES)
    assert is_singleton_pm(M)
    assert is_singleton_pm(P)
    class_zero = all_singleton_pms()
    assert class_zero == {frozenset(M), frozenset(P)}
    delta = M ^ P
    assert len(delta) == 6
    assert all(degree(delta, v) in (0, 2) for v in range(N))
    assert {v for v in range(N) if degree(delta, v)} == {1, 2, 3, 4, 5, 6}

    # A one-edge symmetric exchange would select e in M\P and f in P\M
    # and require both swapped sets to remain singleton perfect matchings.
    candidates = []
    for e in sorted(M - P):
        for f in sorted(P - M):
            m_swap = (M - {e}) | {f}
            p_swap = (P - {f}) | {e}
            if is_singleton_pm(m_swap) and is_singleton_pm(p_swap):
                candidates.append((e, f))
    assert not candidates
    print({
        "order": N,
        "proper_edges": sorted(EDGES),
        "singleton_boundary": 0,
        "M": sorted(M),
        "N": sorted(P),
        "singleton_class_size": len(class_zero),
        "symmetric_difference_size": len(delta),
        "one_edge_symmetric_exchange_pairs": candidates,
    })
    print("STRONG_SYMMETRIC_EXCHANGE_CERTIFICATE_VERIFIED")


if __name__ == "__main__":
    main()
