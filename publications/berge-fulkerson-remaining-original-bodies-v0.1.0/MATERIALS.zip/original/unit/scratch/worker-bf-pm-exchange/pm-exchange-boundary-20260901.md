# Real-PM strong-exchange boundary (Omen pulse)

## Tested implication

For a fixed singleton boundary class \(\mathcal M_i\), test the
delta-matroid-style one-edge symmetric exchange axiom: for every
\(M,N\in\mathcal M_i\) and every \(e\in M\setminus N\), some
\(f\in N\setminus M\) makes both \(M-e+f\) and \(N-f+e\) perfect
matchings.

The cheapest obstruction is a single alternating cycle of length six: a
one-edge replacement cannot restore the two endpoints of a removed edge.

## Omen result

The SAT encoding searches one common simple cubic 5-pole and two actual
singleton-boundary matchings with six proper edges in their symmetric
difference. Omen found no order-five model and found the following order-
seven model:

```text
proper edges = (0,5) (0,6) (1,2) (1,5) (2,4) (3,4) (3,6) (5,6)
terminals   = 0,1,2,3,4
M           = (1,5) (2,4) (3,6), plus semiedge 0
N           = (1,2) (3,4) (5,6), plus semiedge 0
M triangle N = (1,2) (1,5) (2,4) (3,4) (3,6) (5,6)
```

The proper graph is connected and bridgeless. Its displayed difference is
the single cycle \(1-2-4-3-6-5-1\). Exhaustive one-edge swap testing gives no
pair \((e,f)\) for which both swapped sets are singleton perfect matchings.
For this pole the complete singleton class \(\mathcal M_0\) has exactly the
two displayed members.

Order five is impossible for this obstruction because the pole has only five
proper edges, so a six-edge difference cannot occur; orders below five cannot
carry five distinct terminals. Thus order seven is the minimum for this
specific strong-exchange failure.

This is a real cubic-pole counterexample to the **generic** PM
delta-matroid/one-edge strong-exchange premise. It is not exact Case XII and
does not test the D5 four-cell join directly. It closes only the route that
would obtain D5 rectangularity from an unqualified generic strong-exchange
theorem.

## Reproduction

```text
uv run --with z3-solver python \
  units/berge-fulkerson/scratch/worker-bf-pm-exchange/omen_strong_exchange_counterexample.py \
  --orders 5 7
python3 units/berge-fulkerson/scratch/worker-bf-pm-exchange/verify_strong_exchange_certificate.py
```

The Omen run used the detached session `pm-exchange-20260901`; its result
JSON has SHA-256
`0bac5f7132e17b4e892940aeccc330c4b27d943b52ea6a5f51cc1f69db9aed49` and
ends with `STRONG_SYMMETRIC_EXCHANGE_REAL_POLE_FOUND`.
