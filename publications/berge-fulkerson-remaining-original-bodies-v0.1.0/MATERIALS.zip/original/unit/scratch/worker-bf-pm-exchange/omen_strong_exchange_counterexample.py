#!/usr/bin/env python3
r"""Omen pulse: test the strong symmetric-exchange axiom for PM fibres.

For a fixed singleton boundary class M_i of a cubic 5-pole, the usual
delta-matroid-style symmetric exchange axiom would require that, for any two
matchings M,N and any e in M\N, some f in N\M makes both one-edge swaps
M-e+f and N-f+e perfect matchings.  Two matchings whose symmetric difference
is one alternating cycle of length at least six already violate this axiom.

The solver searches the smallest odd orders.  It encodes one common simple
cubic 5-pole and two actual singleton-boundary perfect matchings of that same
pole, forcing their proper-edge symmetric difference to have six edges.  A
post-solve verifier checks connectedness and bridgelessness and prints a
literal certificate.  This is intentionally not a Case-XII synthesis.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations

from z3 import Bool, If, Solver, Sum, sat, unsat


TERMINALS = tuple(range(5))


def edge_key(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def connected(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    adjacency = [[] for _ in range(n)]
    for u, v in edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in adjacency[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == n


def bridgeless(n: int, edges: tuple[tuple[int, int], ...]) -> bool:
    for removed in range(len(edges)):
        remaining = edges[:removed] + edges[removed + 1 :]
        if not connected(n, remaining):
            return False
    return True


def solve_order(n: int):
    edges = tuple(combinations(range(n), 2))
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    # y,z are proper-edge incidence vectors for two matchings in boundary
    # class {0}: terminal 0 uses its semiedge; all other vertices are covered
    # by exactly one proper edge.
    y = {edge: Bool(f"y_{edge[0]}_{edge[1]}") for edge in edges}
    z = {edge: Bool(f"z_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()
    for v in range(n):
        target_graph_degree = 2 if v in TERMINALS else 3
        incident_graph = [x[e] for e in edges if v in e]
        solver.add(Sum([If(value, 1, 0) for value in incident_graph])
                   == target_graph_degree)
        target_matching_degree = 0 if v == 0 else 1
        for matching in (y, z):
            incident = [matching[e] for e in edges if v in e]
            solver.add(Sum([If(value, 1, 0) for value in incident])
                       == target_matching_degree)
    for edge in edges:
        # Matching edges must be edges of the common pole.
        solver.add(If(y[edge], 1, 0) <= If(x[edge], 1, 0))
        solver.add(If(z[edge], 1, 0) <= If(x[edge], 1, 0))
        # Exactly six proper edges lie in the symmetric difference.  Since
        # y,z have the same boundary and degree equations, this is one
        # alternating 6-cycle, not several components.
    solver.add(Sum([If(y[e] != z[e], 1, 0) for e in edges]) == 6)
    if n == 5:
        # Keep the smallest-order result genuinely solver-derived; no graph
        # family is hard-coded.  The degree equations already imply the
        # unique 5-cycle pole, but this symmetry break is harmless.
        solver.add(x[edge_key(0, 1)])
    model = solver.model() if solver.check() == sat else None
    if model is None:
        return {"order": n, "status": "unsat"}
    proper = tuple(sorted(edge for edge, var in x.items()
                          if model.eval(var, model_completion=True)))
    first = tuple(sorted(edge for edge, var in y.items()
                         if model.eval(var, model_completion=True)))
    second = tuple(sorted(edge for edge, var in z.items()
                          if model.eval(var, model_completion=True)))
    diff = tuple(edge for edge in edges if (edge in first) != (edge in second))
    if len(diff) != 6:
        raise AssertionError((n, diff))
    if not connected(n, proper) or not bridgeless(n, proper):
        raise AssertionError(("non-bridgeless model", n, proper))
    return {
        "order": n,
        "status": "sat",
        "proper_edges": [list(edge) for edge in proper],
        "matching_M": [list(edge) for edge in first],
        "matching_N": [list(edge) for edge in second],
        "symmetric_difference": [list(edge) for edge in diff],
        "connected": True,
        "bridgeless": True,
        "cycle_edge_count": len(diff),
        "strong_symmetric_exchange": False,
        "exchange_failure_reason": (
            "M and N differ on one alternating 6-cycle; a one-edge swap "
            "cannot repair both exposed endpoints of any selected edge"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--orders", nargs="+", type=int, default=[5, 7])
    parser.add_argument("--json", type=str)
    args = parser.parse_args()
    records = []
    for order in args.orders:
        record = solve_order(order)
        records.append(record)
        if record["status"] == "sat":
            break
    result = {"records": records, "first_counterexample": next(
        (record for record in records if record["status"] == "sat"), None
    )}
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as handle:
            json.dump(result, handle, indent=2, sort_keys=True)
            handle.write("\n")
    if result["first_counterexample"] is not None:
        print("STRONG_SYMMETRIC_EXCHANGE_REAL_POLE_FOUND")
    else:
        print("STRONG_SYMMETRIC_EXCHANGE_NOT_FOUND_IN_REQUESTED_ORDERS")


if __name__ == "__main__":
    main()
