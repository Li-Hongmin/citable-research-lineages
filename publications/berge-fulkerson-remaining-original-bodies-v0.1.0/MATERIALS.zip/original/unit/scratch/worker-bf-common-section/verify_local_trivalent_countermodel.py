#!/usr/bin/env python3
"""Independent certificate for a local trivalent-incidence boundary model.

The certificate is intentionally below cubic-pole realizability.  A class is
represented by the set of the three edges incident with one common cubic
vertex that its perfect matchings may use.  We independently enumerate local
edge choices, verify every 40 positive Case-XII support flags, and check that
the five transferred D5 four-cell joins are empty.  No negative T/TT flag is
asserted locally: global non-support may arise from constraints away from the
chosen vertex.  Thus this is a strict *local-insufficiency* result, not a
pole counterexample.
"""

from __future__ import annotations

from itertools import combinations, product

EDGES = (0, 1, 2)
POSITIONS = tuple(range(5))
PAIR_SET = tuple(combinations(POSITIONS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(pair for pair in PAIR_SET if pair not in S)

SINGLETON_MASKS = (1, 2, 3, 3, 4)
TRIPLE_MASKS = {
    (0, 1): 4,
    (0, 2): 4,
    (0, 3): 4,
    (0, 4): 2,
    (1, 2): 4,
    (1, 3): 4,
    (1, 4): 1,
    (2, 3): 4,
    (2, 4): 2,
    (3, 4): 1,
}

D5 = tuple(sorted((s, t) for s in S for t in T
                   if set(s).isdisjoint(t)))
PHI = {
    ((0, 2), (3, 4)): ((0, 3), (1, 4)),
    ((0, 3), (1, 2)): ((0, 2), (1, 3)),
    ((1, 3), (0, 4)): ((0, 3), (1, 4)),
    ((1, 4), (2, 3)): ((1, 3), (2, 4)),
    ((2, 4), (0, 1)): ((0, 2), (1, 4)),
}


def choose(mask: int):
    return tuple(edge for edge in EDGES if mask & (1 << edge))


def local_balanced(masks: tuple[int, ...]) -> bool:
    """Directly enumerate all local choices; exact load is (2,2,2)."""
    for choices in product(*(choose(mask) for mask in masks)):
        loads = tuple(choices.count(edge) for edge in EDGES)
        if loads == (2, 2, 2):
            return True
    return False


def class_pair_support(left, right) -> bool:
    masks = [TRIPLE_MASKS[left], TRIPLE_MASKS[right]]
    masks.extend(SINGLETON_MASKS[position] for position in left + right)
    return local_balanced(tuple(masks))


def local_loop_support(pair) -> bool:
    return local_balanced((TRIPLE_MASKS[pair], TRIPLE_MASKS[pair],
                           *(SINGLETON_MASKS[position] for position in pair),
                           *(SINGLETON_MASKS[position] for position in pair)))


def transferred_cell_support(cell, labels) -> bool:
    left, right = PHI[cell]
    masks = [TRIPLE_MASKS[left], TRIPLE_MASKS[right]]
    for position in left + right:
        masks.append(1 << labels[position])
    return local_balanced(tuple(masks))


def d5_joins():
    rows = []
    for omitted in D5:
        chosen = tuple(cell for cell in D5 if cell != omitted)
        witnesses = []
        for labels in product(EDGES, repeat=5):
            if not all(SINGLETON_MASKS[i] & (1 << labels[i])
                       for i in POSITIONS):
                continue
            if all(transferred_cell_support(cell, labels) for cell in chosen):
                witnesses.append(labels)
        rows.append((omitted, tuple(witnesses)))
    return tuple(rows)


def main():
    assert all(mask in (1, 2, 3, 4, 5, 6, 7)
               for mask in SINGLETON_MASKS)
    assert set(TRIPLE_MASKS) == set(PAIR_SET)

    positive_loops = [pair for pair in PAIR_SET if pair in S
                      and local_loop_support(pair)]
    positive_pairs = [(left, right) for left, right in combinations(PAIR_SET, 2)
                      if (left in S or right in S)
                      and class_pair_support(left, right)]
    assert len(positive_loops) == 5
    assert len(positive_pairs) == 35
    assert len(D5) == 5

    joins = d5_joins()
    assert all(not witnesses for _, witnesses in joins)

    local_tt = [pair for pair in PAIR_SET if pair in T and local_loop_support(pair)]
    local_tt_pairs = [(left, right) for left, right in combinations(PAIR_SET, 2)
                      if left in T and right in T and class_pair_support(left, right)]
    print({
        "singleton_masks": SINGLETON_MASKS,
        "triple_masks": TRIPLE_MASKS,
        "positive_loops": len(positive_loops),
        "positive_offdiagonal": len(positive_pairs),
        "local_T_loops": len(local_tt),
        "local_TT_offdiagonal": len(local_tt_pairs),
        "d5_join_sizes": {str(cell): len(witnesses)
                           for cell, witnesses in joins},
        "model_scope": "one-vertex local trivalent incidence; not a pole",
    })
    print("LOCAL_TRIVALENT_CASE_XII_JOINFREE_VERIFIED")


if __name__ == "__main__":
    main()
