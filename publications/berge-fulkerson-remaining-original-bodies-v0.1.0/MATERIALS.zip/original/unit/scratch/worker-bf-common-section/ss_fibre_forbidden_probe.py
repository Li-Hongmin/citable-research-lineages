#!/usr/bin/env python3
"""Fixed-pole probe of disjoint S--S witness fibres versus T-forbidden types.

This script uses only the actual perfect matchings of the two frozen order-13
poles.  It enumerates all witnesses in the five disjoint S--S cells, transfers
each witness through its *actual* terminal-path pairing, and records the
carrier/defect data of the resulting T-half.  It also measures overlaps of
adjacent S--S singleton fibres.  No graph generation, aggregate relaxation,
or route-only model is used.

The intended decision is narrow: determine whether the no-T-loop condition
adds a nontrivial restriction visible directly on S--S fibres, beyond the
already-known statement that every transferred T-half must be carrierless.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
import importlib.util
import json
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
KEMPE = ROOT / "units/berge-fulkerson/scratch/worker-kempe"
REAL = ROOT / "units/berge-fulkerson/scratch/worker-real-exact-s-no-a"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


JOINT = load("ss_probe_joint", KEMPE / "exact_st_joint_audit.py")
LOOP = load("ss_probe_loop", REAL / "audit_loop_incidence_interface.py")

S = tuple(sorted(JOINT.S))
SS = tuple(sorted(
    (u, v) for i, u in enumerate(S) for v in S[i:]
    if u != v and set(u).isdisjoint(v)
))


def all_witnesses(data, cell):
    """Return (Q_u,Q_v, slots, singleton tuple) for every exact witness."""
    edges, _, _, _, classes, _ = data
    u, v = cell
    slots = tuple(sorted(set(u) | set(v)))
    out = []
    for q_u in classes[JOINT.complement(u)]:
        for q_v in classes[JOINT.complement(v)]:
            base = [0] * len(edges)
            for q in (q_u, q_v):
                for e in q:
                    base[e] += 1
            if max(base, default=0) > 2:
                continue
            for ps in product(*(classes[(i,)] for i in slots)):
                load = list(base)
                for p in ps:
                    for e in p:
                        load[e] += 1
                if all(value == 2 for value in load):
                    out.append((q_u, q_v, slots, ps))
    return tuple(out)


def sym_components(first, second, data):
    """Return proper-edge components of first △ second and their terminals."""
    edges, edge_vertices, edge_position, _, _, _ = data
    symmetric = set(first) ^ set(second)
    adjacency = defaultdict(set)
    edge_by_pair = {}
    terminal_nodes = defaultdict(set)
    for e in symmetric:
        endpoints = edge_vertices[edges[e]]
        if len(endpoints) == 2:
            u, v = endpoints
            a, b = ("v", u), ("v", v)
            adjacency[a].add(b)
            adjacency[b].add(a)
            edge_by_pair[frozenset((a, b))] = e
        elif len(endpoints) == 1:
            u = endpoints[0]
            t = ("t", edge_position[edges[e]])
            a = ("v", u)
            adjacency[a].add(t)
            adjacency[t].add(a)
            edge_by_pair[frozenset((a, t))] = e
            terminal_nodes[t].add(e)
        else:
            raise AssertionError(endpoints)
    unseen = set(adjacency)
    result = []
    while unseen:
        root = min(unseen, key=str)
        seen = {root}
        stack = [root]
        while stack:
            x = stack.pop()
            for y in adjacency[x]:
                if y not in seen:
                    seen.add(y)
                    stack.append(y)
        unseen -= seen
        proper = []
        boundary = []
        for pair, e in edge_by_pair.items():
            if pair <= seen:
                if len(edge_vertices[edges[e]]) == 2:
                    proper.append(e)
                else:
                    boundary.append(e)
        terminals = tuple(sorted(node[1] for node in seen if node[0] == "t"))
        result.append({
            "proper": tuple(sorted(proper)),
            "boundary": tuple(sorted(boundary)),
            "terminals": terminals,
        })
    return tuple(result)


def transferred_t_halves(record, cell, data):
    """Return both path-toggle T-halves for an S--S witness, if any."""
    q_u, q_v, _, ps = record
    edges, _, _, _, _, _ = data
    out = []
    boundary_of = {
        matching: key
        for key, family in data[4].items()
        for matching in family
    }
    for component in sym_components(q_u, q_v, data):
        if len(component["terminals"]) != 2:
            continue
        path = set(component["proper"]) | set(component["boundary"])
        q_u_new = tuple(sorted(set(q_u) ^ path))
        q_v_new = tuple(sorted(set(q_v) ^ path))
        # Determine the boundary type of this actual path toggle.  In an
        # exact Case-XII pole both path toggles must be ST; the other outcomes
        # are retained here as explicit forbidden-support witnesses.
        class_u = boundary_of[q_u_new]
        class_v = boundary_of[q_v_new]
        pair_u = JOINT.complement(class_u)
        pair_v = JOINT.complement(class_v)
        if len(pair_u) == 0 or len(pair_v) == 0:
            outcome = "A"
        elif pair_u in JOINT.S and pair_v in JOINT.S:
            outcome = "SS"
        elif pair_u in JOINT.T and pair_v in JOINT.T:
            outcome = "TT"
        elif (pair_u in JOINT.S and pair_v in JOINT.T) or (
            pair_u in JOINT.T and pair_v in JOINT.S
        ):
            outcome = "ST"
        else:
            raise AssertionError((pair_u, pair_v))
        if outcome != "ST":
            out.append({
                "terminals": component["terminals"],
                "outcome": outcome,
                "t_pair": None,
                "r_t": None,
                "defect": (),
                "defect_component_lengths": (),
                "carrier_sets": (),
                "carrierless": False,
            })
            continue
        if pair_u in JOINT.T:
            t_pair, r_t = pair_u, q_u_new
        elif pair_v in JOINT.T:
            t_pair, r_t = pair_v, q_v_new
        else:
            continue
        # The two singleton positions incident with the T pair are present in
        # the S--S scope, so the T half is well-defined.
        t_singletons = tuple(ps[tuple(record[2]).index(i)] for i in t_pair)
        load = [0] * len(edges)
        for matching in (r_t, *t_singletons):
            for e in matching:
                load[e] += 1
        defect = tuple(sorted(e for e, value in enumerate(load) if value != 1))
        defect_components = []
        # Use the support graph of the defect edges (all should be proper
        # alternating cycles in an exact six-cover half).
        dset = set(defect)
        if dset:
            comps = sym_components(tuple(defect), tuple(), data)
            # sym_components assumes matchings; for a defect edge set it still
            # yields its connected proper components, with no terminals.
            defect_components = [tuple(part["proper"]) for part in comps]
        carriers = []
        for comp in defect_components:
            twos = [e for e in comp if load[e] == 2]
            users = []
            for idx, matching in enumerate((r_t, *t_singletons)):
                if all(e in matching for e in twos):
                    users.append(idx)
            carriers.append(tuple(users))
        out.append({
            "terminals": component["terminals"],
            "outcome": outcome,
            "t_pair": tuple(t_pair),
            "r_t": r_t,
            "defect": defect,
            "defect_component_lengths": tuple(sorted(map(len, defect_components))),
            "carrier_sets": tuple(carriers),
            "carrierless": any(not users for users in carriers),
        })
    return tuple(out)


def fibre_rows(records):
    rows = set()
    for _, _, slots, ps in records:
        row = [None] * 5
        for i, p in zip(slots, ps):
            row[i - 1] = p
        rows.add(tuple(row))
    return frozenset(rows)


def audit(name, edges):
    pole = LOOP.pole(edges)
    data = JOINT.matching_data(pole)
    records = {cell: all_witnesses(data, cell) for cell in SS}
    stats = {
        "pole": name,
        "perfect_matchings": data[-1],
        "cells": {},
        "adjacent_overlap": {},
    }
    transferred = {}
    for cell in SS:
        halves = [h for r in records[cell] for h in transferred_t_halves(r, cell, data)]
        transferred[cell] = halves
        by_witness = [transferred_t_halves(r, cell, data) for r in records[cell]]
        outcome_counts = Counter(h["outcome"] for h in halves)
        fully_t_obstructed = sum(
            len(parts) == 2
            and all(part["outcome"] == "ST" and part["carrierless"] for part in parts)
            for parts in by_witness
        )
        stats["cells"][str(cell)] = {
            "witnesses": len(records[cell]),
            "fibre_rows": len(fibre_rows(records[cell])),
            "transferred_T_halves": len(halves),
            "path_outcomes": dict(sorted(outcome_counts.items())),
            "fully_T_obstructed_witnesses": fully_t_obstructed,
            "carrierless_halves": sum(h["carrierless"] for h in halves),
            "defect_length_profiles": dict(Counter(
                str(h["defect_component_lengths"]) for h in halves
            )),
            "carrier_profiles": dict(Counter(
                str(h["carrier_sets"]) for h in halves
            )),
        }
    # Adjacent cells share one S triple class and three singleton positions.
    for idx, first in enumerate(SS):
        for second in SS[idx + 1:]:
            if len(set(first) & set(second)) != 1:
                continue
            overlap = tuple(sorted(
                (set(first[0]) | set(first[1]))
                & (set(second[0]) | set(second[1]))
            ))
            if len(overlap) != 3:
                continue
            left = fibre_rows(records[first])
            right = fibre_rows(records[second])
            common = 0
            for row in left:
                for other in right:
                    if all(row[i - 1] == other[i - 1] for i in overlap):
                        common += 1
            stats["adjacent_overlap"][f"{first}|{second}"] = common
    return stats


def main():
    result = {
        "exact_s_c10": audit("exact_s_c10", LOOP.C10_EDGES),
        "all_st_no_a": audit("all_st_no_a", LOOP.ALL_SS_EDGES),
    }
    print(json.dumps(result, indent=2, sort_keys=True, default=str))
    print("SS_FIBRE_FORBIDDEN_PROBE_OK")


if __name__ == "__main__":
    main()
