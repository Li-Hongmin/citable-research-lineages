# S--S witness fibres under the negative T-support conditions

## Scope

This pulse uses only actual perfect matchings of the two frozen order-13
cubic 5-poles.  It does not generate graphs, scan orders, or replace the
matching family by an aggregate/load model.  The five disjoint S--S cells

\[
 (13,24),(13,25),(14,25),(14,35),(24,35)
\]

are the exact transfer partners of the five disjoint S--T cells.

## Universal fibre lemma

Let \(W=(Q_u,Q_v;P_i\ (i\in U))\) be an actual witness in a disjoint
S--S cell \(u,v\), with \(U=u\cup v\).  The symmetric difference
\(Q_u\triangle Q_v\) has two boundary paths (and possibly proper even
cycles).  For either boundary path \(L\), toggling \(L\) in both triple
matchings preserves the six-edge load.  The three endpoint pairings give

\[
 (A,A),\qquad (S\! -\! T,S\! -\! T),\qquad (T\! -\! T,T\! -\! T).
\]

Consequently, if the pole has no \(A\)-type and no \(T\! -\! T\) type,
**every** actual S--S witness has both path toggles of S--T type.  This is
universal over witnesses, not merely an existential route assertion.

For either resulting T-half \(x=\chi_R+\chi_{P_k}+\chi_{P_\ell}\), the
semiedge loads are one and the proper-edge defect set

\[
 D(x)=\{e:x(e)\neq1\}
\]

is a disjoint union of proper even cycles with alternating loads \(0,2\).
If every component had a carrier among \(R,P_k,P_\ell\), flipping those
carriers would make the three matchings edge-disjoint, yielding a Tait
colouring with lonely pair \(k\ell\), and hence a forbidden T-loop.  Thus
under no T-loop every transferred T-half has a carrierless defect component.
On each load-two edge exactly two of the three matching labels occur; a
component is carrierless exactly when all three labels \(12,13,23\) occur.
It therefore has length at least six.

In compact form, for every actual S--S witness \(W\) and each of its two
boundary paths \(L\),

\[
 \neg A\wedge\neg TT\wedge\neg T\text{-loop}
 \Longrightarrow
 L\text{ is ST and its T-half contains a carrierless even cycle of length}\ge6.
\]

The contrapositive is a fibre-level certificate: one non-robust witness
already supplies an \(A\), a TT type, or a T-loop.  The cycles and carriers
may vary from row to row, so this statement alone does not perform the
cross-cell quantifier exchange needed for a D5 join.

## Omen fixed-pole measurement

`ss_fibre_forbidden_probe.py` was copied byte-for-byte to Omen and run in
detached tmux session `ss-fibre-forbidden-20260901c`.

Remote log:

```text
[local archival reference]
```

Script SHA-256 at the final run:

```text
41baf0709fbc4e24f6b32aba0b55ca8829dfad0ba670f4c87a303055cff609e1
```

The terminal marker is `SS_FIBRE_FORBIDDEN_PROBE_OK`.

The exact-S C10 boundary (31 PMs) has S--S witness counts
\((10,10,14,12,14)\); its five adjacent fibre-overlap counts are
\((14,10,10,16,16)\).  It is not a negative-support pole: its S--S path
outcomes include A and TT.

The all-S--T/no-A boundary (37 PMs) has S--S witness counts
\((34,39,30,56,34)\); adjacent overlaps are
\((0,48,46,46,8)\).  Its S--S path outcomes are ST/TT (per cell
\((44,24),(50,28),(32,28),(64,48),(36,32)\)); the fully robust witness
counts (both toggles ST and carrierless) are \((0,8,9,4,3)\).  It has all
T-loops and TT types, so it is a real boundary, not a Case-XII pole.

## Decision

The no-T-loop/TT hypotheses impose the universal robust-witness condition
above, but no existing real pole satisfies the full exact-40 support.  No
analytic route from robust S--S fibres to a four-cell join was found; the
remaining interface is synchronization of the carrierless cycles (or an
independent UE2/fibre-overlap theorem).

