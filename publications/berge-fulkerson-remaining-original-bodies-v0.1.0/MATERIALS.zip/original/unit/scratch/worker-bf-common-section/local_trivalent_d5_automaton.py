#!/usr/bin/env python3
"""Bounded local cubic-vertex automaton for the D5 section question.

Each actual PM identity is represented only by its choice among the three
edges incident with one common cubic vertex.  A class is therefore a nonempty
subset of {0,1,2}; the same identity/class is reused in every six-matching
equation.  This retains the common trivalent incidence equation but omits
global graph realizability.
"""

from __future__ import annotations

from functools import lru_cache
from itertools import combinations, product


POSITIONS = tuple(range(5))
PAIR_SET = tuple(combinations(POSITIONS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(pair for pair in PAIR_SET if pair not in S)
MASKS = tuple(range(1, 8))


@lru_cache(None)
def balanced(slot_masks: tuple[int, ...]) -> bool:
    """Can one choose local edge labels with each of 3 edges used twice?"""
    states = {(0, 0, 0)}
    for mask in slot_masks:
        values = tuple(edge for edge in range(3) if mask & (1 << edge))
        nxt = set()
        for state in states:
            for edge in values:
                if state[edge] >= 2:
                    continue
                trial = list(state)
                trial[edge] += 1
                nxt.add(tuple(trial))
        states = nxt
        if not states:
            return False
    return (2, 2, 2) in states


def pair_support(singletons, triples, left, right):
    """Local support for boundary pair classes (left)(right)."""
    slots = tuple(singletons[position] for position in left + right)
    return balanced((triples[left], triples[right], *slots))


def loops_and_pairs(singletons, triples):
    """Return positive/negative type flags at the common vertex."""
    support = set()
    for left in PAIR_SET:
        for right in PAIR_SET:
            if pair_support(singletons, triples, left, right):
                support.add((left, right))
    return support


def no_local_a(singletons, triples):
    """No all-terminal PM class is supplied in this local model."""
    return True


def cell_tuple_has_support(singletons, triples, cell, chosen):
    """Whether fixed one-label singleton choices support one cell.

    chosen gives one local edge label per boundary position.  The missing
    position of a D5 cell is not in its four singleton slots.
    """
    left, right = cell
    slots = tuple(chosen[position] for position in left + right)
    return balanced((triples[left], triples[right], *(
        1 << edge for edge in slots
    )))


D5 = tuple(sorted((s, t) for s in S for t in T if not set(s) & set(t)))
PHI = {
    ((0, 2), (4, 3)): ((0, 3), (1, 4)),
    ((0, 3), (1, 2)): ((0, 2), (1, 3)),
    ((1, 3), (0, 4)): ((0, 3), (1, 4)),
    ((1, 4), (2, 3)): ((1, 3), (2, 4)),
    ((2, 4), (0, 1)): ((0, 2), (1, 4)),
}


def d5_join_exists(singletons, triples):
    """Return whether any four D5 cells share one local singleton tuple."""
    # At a single vertex all PM identities with the same class/edge label are
    # interchangeable, so a common tuple is represented by five edge labels.
    for omitted in D5:
        chosen_cells = tuple(cell for cell in D5 if cell != omitted)
        for labels in product(range(3), repeat=5):
            if all(
                cell_tuple_has_support(singletons, triples, PHI[cell], labels)
                for cell in chosen_cells
            ):
                return True, omitted, labels
    return False, None, None


def main():
    # Placeholder; the search implementation is added in the accompanying
    # verifier once the local state space is fixed.
    print("LOCAL_TRIVALENT_D5_AUTOMATON_SCAFFOLD")


if __name__ == "__main__":
    main()
