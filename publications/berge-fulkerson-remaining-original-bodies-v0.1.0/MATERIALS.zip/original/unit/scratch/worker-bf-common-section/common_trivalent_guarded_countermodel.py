#!/usr/bin/env python3
"""Common-PM guard model with one explicit trivalent incidence coordinate.

The imported guarded vector model already has one global binary coordinate
system, all 40 positive Case-XII cells, and global guards excluding A,
T-loops and TT.  This certificate adds one common cubic-vertex coordinate:
every matching vector is assigned one of three local incident edges, and all
40 designated positive six-vector witnesses are required to use each local
edge exactly twice.  It therefore tests whether a single shared trivalent
incidence constraint can force a D5 join.  It is still an abstract model,
not a graph realization: vertices other than this one are omitted.
"""

from __future__ import annotations

import importlib.util
from itertools import combinations, product
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE_PATH = (
    HERE.parent / "worker-bf-common-pm-proof"
    / "common_pm_guarded_incidence_model.py"
)


def load_base():
    spec = importlib.util.spec_from_file_location("guarded_base", BASE_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# The local labels are a compact deterministic solution of the 40 local
# (2,2,2) witness equations.  They were obtained once by a finite SAT solve
# and are checked below without importing a solver.
LOOP_LABELS = (2, 1, 1, 1, 0)
ST_S_LABELS = (2, 2, 2, 2, 1, 2, 1, 2, 2, 1,
               1, 1, 1, 2, 1, 1, 2, 1, 1, 1,
               2, 2, 2, 0, 0)
ST_T_LABELS = (2, 0, 2, 0, 0, 1, 0, 1, 0, 0,
               1, 1, 0, 0, 0, 1, 1, 0, 0, 0,
               1, 0, 0, 0, 0)
SINGLETON_LABELS = {
    (1, 0): 0, (1, 1): 1,
    (2, 0): 0, (2, 1): 2,
    (3, 0): 1, (3, 1): 1, (3, 2): 0,
    (4, 0): 2, (4, 1): 1, (4, 2): 0,
    (5, 0): 2, (5, 1): 1,
}


def local_label(name):
    """Return the one of three common local edges used by a vector."""
    if name[0] == "loop":
        return LOOP_LABELS[name[1]]
    if name[0] in {"ss", "ss-exchange"}:
        return 0
    if name[0] == "stS":
        return ST_S_LABELS[name[1]]
    if name[0] == "stT":
        return ST_T_LABELS[name[1]]
    if name in SINGLETON_LABELS:
        return SINGLETON_LABELS[name]
    raise AssertionError(("unknown vector name", name))


def local_balanced(members):
    loads = tuple(sum(local_label(name) == edge for name in members)
                  for edge in range(3))
    return loads == (2, 2, 2)


def first_cover(base, first, second):
    classes = base_model["classes"]
    for first_name, first_vector in classes[first]:
        for second_name, second_vector in classes[second]:
            singleton_tuple = base.cover_exists(
                base_model, first, second, first_vector, second_vector
            )
            if singleton_tuple is not None:
                return (first_name, second_name, *singleton_tuple)
    raise AssertionError(("missing positive cover", first, second))


def positive_witnesses(base):
    witnesses = []
    for pair in base.S:
        found = None
        for name, vector in base_model["classes"][pair]:
            singleton_tuple = base.cover_exists(
                base_model, pair, pair, vector, vector
            )
            if singleton_tuple is not None:
                found = (name, name, *singleton_tuple)
                break
        assert found is not None
        witnesses.append(("S-loop", pair, found))
    for first_index, second_index in combinations(range(len(base.S)), 2):
        first, second = base.S[first_index], base.S[second_index]
        witnesses.append(("S-S", (first, second), first_cover(base, first, second)))
    for first in base.S:
        for second in base.T:
            witnesses.append(("S-T", (first, second), first_cover(base, first, second)))
    assert len(witnesses) == 40
    return tuple(witnesses)


def relation(base, first, second):
    """Return five-coordinate singleton cylinders with global exact load."""
    classes = base_model["classes"]
    supports = base_model["supports"]
    coordinate_count = base_model["coordinate_count"]
    slots = tuple(first + second)
    missing = tuple(set(range(1, 6)) - set(slots))
    assert len(missing) == 1
    missing = missing[0]
    singleton_classes = [
        [label for label in base_model["labels"] if label[0] == position]
        for position in range(1, 6)
    ]
    rows = set()
    for selected in product(*(singleton_classes[position - 1] for position in slots)):
        loads = base.matching_load(supports, selected, coordinate_count)
        for first_name, first_vector in classes[first]:
            for second_name, second_vector in classes[second]:
                if all(
                    ((first_vector >> coordinate) & 1)
                    + ((second_vector >> coordinate) & 1)
                    + loads[coordinate]
                    == 2
                    for coordinate in range(coordinate_count)
                ):
                    row = [None] * 5
                    for position, label in zip(slots, selected, strict=True):
                        row[position - 1] = label
                    rows.add(tuple(row))
                    break
            else:
                continue
            break
    return frozenset(rows)


def d5_join_sizes(base):
    # D5 transfer partners among disjoint S-S cells, in the same order as the
    # guarded-model UE2 audit.
    S = tuple(base.S)
    cells = (
        (S[1], S[4]),
        (S[0], S[2]),
        (S[1], S[3]),
        (S[2], S[4]),
        (S[0], S[3]),
    )
    rows = {cell: relation(base, *cell) for cell in cells}
    assert all(rows.values())
    joins = []
    for omitted in cells:
        chosen = tuple(cell for cell in cells if cell != omitted)
        joins.append(len(set.intersection(*(set(rows[cell]) for cell in chosen))))
    return cells, rows, tuple(joins)


def main():
    global base_model
    base = load_base()
    base_model = base.build_model()
    # These checks establish all global guarded properties: all 40 positive
    # cells, no T-loop/TT, and no singleton pentagon section/A vector.
    base.check_relation_bundle(base_model)
    base.check_support(base_model)
    base.check_exchange_closure(base_model)

    witnesses = positive_witnesses(base)
    for kind, key, members in witnesses:
        if not local_balanced(members):
            raise AssertionError(("unbalanced local witness", kind, key, members,
                                  tuple(local_label(name) for name in members)))

    # Every vector in the common pool (including fresh singleton exchange
    # variants) has exactly one of the three local edges.
    vector_count = len(base_model["vectors"])
    singleton_count = len(base_model["labels"])
    assert all(local_label(name) in (0, 1, 2)
               for name in (*base_model["vectors"], *base_model["labels"]))

    cells, rows, joins = d5_join_sizes(base)
    assert joins == (0, 0, 0, 0, 0)

    # The local coordinate only adds constraints, so every globally forbidden
    # type remains forbidden.  The selected local-balanced witnesses preserve
    # all 40 positive types.
    print({
        "global_vectors": vector_count,
        "singleton_vectors": singleton_count,
        "positive_witnesses": len(witnesses),
        "local_edges": 3,
        "local_load_profile_each_positive": "(2,2,2)",
        "d5_cells": cells,
        "d5_join_sizes": joins,
        "A_cover": False,
        "T_loop": False,
        "TT_support": False,
        "model_scope": "common global PM vectors + one shared trivalent coordinate; not a cubic pole",
    })
    print("COMMON_TRIVALENT_GUARDED_COUNTERMODEL_VERIFIED")


if __name__ == "__main__":
    main()
