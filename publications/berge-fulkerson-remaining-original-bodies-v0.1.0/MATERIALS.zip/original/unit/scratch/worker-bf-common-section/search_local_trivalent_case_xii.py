#!/usr/bin/env python3
"""Search the one-vertex trivalent-incidence abstraction of Case XII.

This is deliberately a finite local-state test, not a graph construction.
For each singleton/triple boundary class we retain only the nonempty set of
the three edges at one common cubic vertex that an actual matching in that
class may use.  A six-matching equation is accepted when one choice from
each class gives load (2,2,2) at the vertex.  We ask whether the complete
Case-XII support flags (15 S--S + 25 S--T, with S loops) can coexist with
empty T-loops/T--T and with all five D5 four-cell joins empty.

The search uses a binary CSP over the ten triple-class masks.  It is only a
local incidence boundary: a positive result would show that common
three-valent incidence alone is insufficient, while an empty result would be
evidence that this local interface already forces a D5 join.
"""

from __future__ import annotations

from itertools import combinations, product
from functools import lru_cache

EDGES = (0, 1, 2)
MASKS = tuple(range(1, 8))
POSITIONS = tuple(range(5))
PAIR_SET = tuple(combinations(POSITIONS, 2))
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(pair for pair in PAIR_SET if pair not in S)

# D5 S--T cells and their transferred disjoint S--S cells.
D5 = tuple(sorted((s, t) for s in S for t in T if set(s).isdisjoint(t)))
PHI = {
    ((0, 2), (3, 4)): ((0, 3), (1, 4)),
    ((0, 3), (1, 2)): ((0, 2), (1, 3)),
    ((1, 3), (0, 4)): ((0, 3), (1, 4)),
    ((1, 4), (2, 3)): ((1, 3), (2, 4)),
    ((2, 4), (0, 1)): ((0, 2), (1, 4)),
}


def bit_values(mask: int) -> tuple[int, ...]:
    return tuple(edge for edge in EDGES if mask & (1 << edge))


@lru_cache(None)
def balanced(masks: tuple[int, ...]) -> bool:
    """Whether one edge choice per slot has exact load (2,2,2)."""
    states = {(0, 0, 0)}
    for mask in masks:
        nxt = set()
        for state in states:
            for edge in bit_values(mask):
                if state[edge] == 2:
                    continue
                trial = list(state)
                trial[edge] += 1
                nxt.add(tuple(trial))
        states = nxt
        if not states:
            return False
    return (2, 2, 2) in states


def relation_ok(singletons: tuple[int, ...], left: tuple[int, int],
                right: tuple[int, int], qleft: int, qright: int) -> bool:
    slots = tuple(singletons[i] for i in left + right)
    return balanced((qleft, qright, *slots))


def loop_ok(singletons: tuple[int, ...], pair: tuple[int, int], q: int) -> bool:
    return relation_ok(singletons, pair, pair, q, q)


def support_constraints(singletons: tuple[int, ...]):
    """Return allowed mask pairs for every triple-class pair and loops."""
    allowed = {}
    for a, b in combinations(PAIR_SET, 2):
        # Local incidence is only a necessary condition for a globally
        # positive support flag.  A forbidden T--T type may still have
        # locally balanced choices which fail to globalize, so no local
        # ``non-support'' constraint is imposed here.
        want = a in S or b in S
        pairs = frozenset(
            (qa, qb) for qa in MASKS for qb in MASKS
            if (not want) or relation_ok(singletons, a, b, qa, qb)
        )
        allowed[(a, b)] = pairs
    loops = {}
    for pair in PAIR_SET:
        # Only S-loops are required positive; T-loop absence is global and
        # cannot be inferred from one vertex's local masks.
        want = pair in S
        loops[pair] = frozenset(
            q for q in MASKS if (not want) or loop_ok(singletons, pair, q)
        )
    return allowed, loops


def solve_csp(singletons: tuple[int, ...], allowed, loops,
              max_solutions: int = 1):
    """Arc-consistency backtracking for ten triple masks."""
    domains = {pair: set(loops[pair]) for pair in PAIR_SET}
    if any(not values for values in domains.values()):
        return []

    neighbours = {pair: set() for pair in PAIR_SET}
    for a, b in combinations(PAIR_SET, 2):
        neighbours[a].add(b)
        neighbours[b].add(a)

    def propagate(dom):
        changed = True
        while changed:
            changed = False
            for a, b in combinations(PAIR_SET, 2):
                rel = allowed[(a, b)]
                na = {x for x in dom[a] if any((x, y) in rel for y in dom[b])}
                nb = {y for y in dom[b] if any((x, y) in rel for x in dom[a])}
                if not na or not nb:
                    return None
                if na != dom[a]:
                    dom[a] = na
                    changed = True
                if nb != dom[b]:
                    dom[b] = nb
                    changed = True
        return dom

    def recurse(dom, out):
        dom = {key: set(value) for key, value in dom.items()}
        dom = propagate(dom)
        if dom is None:
            return
        unsolved = [key for key, value in dom.items() if len(value) > 1]
        if not unsolved:
            out.append(tuple(next(iter(dom[pair])) for pair in PAIR_SET))
            return
        pair = min(unsolved, key=lambda key: len(dom[key]))
        for value in sorted(dom[pair]):
            if len(out) >= max_solutions:
                return
            child = {key: set(vals) for key, vals in dom.items()}
            child[pair] = {value}
            recurse(child, out)

    result = []
    recurse(domains, result)
    return result


def d5_join_exists_correct(singletons: tuple[int, ...], triple_assignment: tuple[int, ...]):
    """Check common singleton local edge labels for transferred S--S cells."""
    triples = dict(zip(PAIR_SET, triple_assignment, strict=True))
    for omitted in D5:
        cells = tuple(cell for cell in D5 if cell != omitted)
        for labels in product(EDGES, repeat=5):
            if not all(singletons[i] & (1 << labels[i]) for i in POSITIONS):
                continue
            ok = True
            for cell in cells:
                left, right = PHI[cell]
                slots = tuple(singletons[i] for i in left + right)
                if not balanced((triples[left], triples[right],
                                 *(1 << edge for edge in
                                   (labels[i] for i in left + right)))):
                    ok = False
                    break
            if ok:
                return True, omitted, labels
    return False, None, None


def main() -> None:
    tested = 0
    csp_solutions = 0
    joinfree = []
    support_feasible = []
    # Singleton mask symmetries are intentionally not quotiented: this is a
    # complete 7^5 finite local test.
    for singletons in product(MASKS, repeat=5):
        tested += 1
        allowed, loops = support_constraints(singletons)
        solutions = solve_csp(singletons, allowed, loops, max_solutions=64)
        if not solutions:
            continue
        csp_solutions += len(solutions)
        for assignment in solutions:
            support_feasible.append((singletons, assignment))
            has_join, omitted, labels = d5_join_exists_correct(singletons, assignment)
            if not has_join:
                joinfree.append((singletons, assignment))
                print({
                    "singleton_masks": singletons,
                    "triple_masks": dict(zip(PAIR_SET, assignment, strict=True)),
                    "join": False,
                    "tested_singleton_assignments": tested,
                    "support_solutions_seen": csp_solutions,
                })
                print("LOCAL_TRIVALENT_CASE_XII_JOINFREE_FOUND")
                return
    print({
        "tested_singleton_masks": tested,
        "support_csp_solutions_seen": csp_solutions,
        "joinfree": len(joinfree),
    })
    print("LOCAL_TRIVALENT_CASE_XII_ALL_FORCE_D5_JOIN")


if __name__ == "__main__":
    main()
