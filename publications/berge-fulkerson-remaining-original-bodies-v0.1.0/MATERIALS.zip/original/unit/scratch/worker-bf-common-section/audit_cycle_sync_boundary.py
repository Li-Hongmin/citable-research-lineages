#!/usr/bin/env python3
"""Fixed-real-pole boundary for synchronizing carrierless defect cycles.

This probe uses the actual perfect-matching family of the frozen order-13
all-S--T/no-A pole.  For each of the five transferred disjoint S--S cells it
keeps only witnesses for which both terminal-path transfers are S--T and each
transferred T-half has a carrierless defect component.  It then asks whether
any four cells admit one common tuple of the four singleton matchings.

The pole is deliberately not exact Case XII (it has T-loops and T--T types),
so a negative result is only a boundary for the cycle-synchronization route,
not a Case-XII counterexample.  No graph generation or aggregate relation
model is used.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path
import importlib.util
import json
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PROBE = HERE / "ss_fibre_forbidden_probe.py"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BASE = load("cycle_sync_probe", PROBE)
JOINT = BASE.JOINT
LOOP = BASE.LOOP


def row_for(record):
    """Embed a four-slot singleton tuple into five coordinates."""
    _, _, slots, ps = record
    row = [None] * 5
    for position, matching in zip(slots, ps):
        row[position - 1] = matching
    return tuple(row)


def robust_records(records, cell, data):
    """Keep rows whose two transferred T-halves are both carrierless ST."""
    out = []
    for record in records:
        halves = BASE.transferred_t_halves(record, cell, data)
        if len(halves) != 2:
            continue
        if not all(
            half["outcome"] == "ST" and half["carrierless"]
            for half in halves
        ):
            continue
        out.append((row_for(record), halves))
    return tuple(out)


def common_rows(cell_rows, selected):
    """Find a common five-coordinate tuple across selected partial rows."""
    choices = [cell_rows[cell] for cell in selected]
    if any(not values for values in choices):
        return None
    # Few rows occur in the frozen pole; backtrack with the most restrictive
    # cell first to make the test independent of row multiplicity.
    choices.sort(key=len)
    for anchor, _ in choices[0]:
        candidate = list(anchor)
        ok = True
        for values in choices[1:]:
            matches = [
                row for row, _ in values
                if all(
                    left is None or right is None or left == right
                    for left, right in zip(candidate, row)
                )
            ]
            if not matches:
                ok = False
                break
            # Pick a compatible row and continue; if a later cell can force a
            # different value, branch over all compatible choices below.
            candidate = [
                left if left is not None else right
                for left, right in zip(candidate, matches[0])
            ]
        if ok:
            # The greedy path above can miss a later-compatible branch, so a
            # complete DFS verifies the candidate existence exactly.
            def dfs(index, current):
                if index == len(choices):
                    return tuple(current)
                for row, _ in choices[index]:
                    if any(
                        left is not None and right is not None and left != right
                        for left, right in zip(current, row)
                    ):
                        continue
                    merged = [
                        left if left is not None else right
                        for left, right in zip(current, row)
                    ]
                    result = dfs(index + 1, merged)
                    if result is not None:
                        return result
                return None

            result = dfs(1, list(anchor))
            if result is not None:
                return result
    return None


def audit():
    pole = LOOP.pole(LOOP.ALL_SS_EDGES)
    data = JOINT.matching_data(pole)
    cells = tuple(BASE.SS)
    all_records = {
        cell: BASE.all_witnesses(data, cell)
        for cell in cells
    }
    robust = {
        cell: robust_records(all_records[cell], cell, data)
        for cell in cells
    }
    common = {}
    for omitted in cells:
        selected = tuple(cell for cell in cells if cell != omitted)
        common[str(omitted)] = common_rows(robust, selected)
    # A cycle-level signature records the proper defect components for each
    # path transfer.  This keeps the negative conclusion tied to genuine
    # alternating-cycle decompositions rather than only singleton rows.
    cycle_profiles = Counter()
    for values in robust.values():
        for _, halves in values:
            profile = tuple(
                tuple(sorted(half["defect_component_lengths"]))
                for half in halves
            )
            cycle_profiles[str(profile)] += 1
    result = {
        "pole": "order13_all_st_no_a",
        "perfect_matchings": data[-1],
        "cell_order": [str(cell) for cell in cells],
        "all_witness_counts": {
            str(cell): len(all_records[cell]) for cell in cells
        },
        "robust_witness_counts": {
            str(cell): len(robust[cell]) for cell in cells
        },
        "robust_cycle_profiles": dict(sorted(cycle_profiles.items())),
        "four_cell_common_rows": common,
        "any_four_cell_common_row": any(value is not None for value in common.values()),
    }
    return result


def main():
    result = audit()
    print(json.dumps(result, indent=2, sort_keys=True, default=str))
    # This is a deliberately bounded boundary marker, not a theorem marker.
    print("CYCLE_SYNC_REAL_POLE_BOUNDARY_AUDIT_OK")


if __name__ == "__main__":
    main()
