# Carrierless-cycle synchronization: a real-incidence boundary

## Question

The remaining D5 interface asks whether the carrierless even defect cycles
obtained by transferring the five disjoint S--S cells can be synchronized
into one common singleton tuple.  This check keeps the entire perfect-
matching family of one fixed cubic 5-pole; it does not replace matchings by
independent vectors or by a local vertex mask.

For each of the five transferred S--S cells, a witness is retained only if
both terminal-path toggles are S--T and each resulting T-half has a
carrierless defect component.  These are exactly the robust conditions from
the SS-fibre necessary lemma.  The retained witness contributes a partial
five-coordinate singleton row (the missing coordinate of the cell is free).
The test asks whether any four of the five partial-row families have a
common row, which is the natural join needed by the four-cell argument.

## Fixed real pole and result

The pole is the frozen order-13 all-S--T/no-A pole used by the preceding
SS-fibre probe.  It has 37 perfect matchings and all five disjoint S--S
cells.  The complete witness counts and robust counts are:

| transferred S--S cell | all witnesses | robust witnesses |
|---|---:|---:|
| (13),(24) | 34 | 0 |
| (13),(25) | 39 | 8 |
| (14),(25) | 30 | 9 |
| (14),(35) | 56 | 4 |
| (24),(35) | 34 | 3 |

The robust transferred halves have genuine even defect-cycle profiles

\[
((6),(6))^{12},\quad ((8),(8))^3,\quad ((10),(10))^5,
\quad ((4,6),(4,6))^3,\quad ((4,8),(4,8))^1.
\]

For each choice of four cells (equivalently, for each omitted cell), the
intersection of the robust partial-row families is empty.  Thus

\[
\boxed{\text{carrierless ST transfers in this real pole do not synchronize
to a four-cell singleton tuple}.}
\]

This is a genuine common-perfect-matching/alternating-cycle boundary, not an
abstract load countermodel.  It does **not** decide Case XII: the pole has
additional T-loops and T--T types, so the negative-support assumptions used
to force robust transfers are not all present.  The result only closes the
shortcut that carrierless cycles plus real incidence, by themselves, imply
the D5 natural join.

## Reproduction

```text
python3 units/berge-fulkerson/scratch/worker-bf-common-section/audit_cycle_sync_boundary.py
```

The same source was copied to Omen and run in tmux session
`cycle-sync-boundary-20260901`.

Source SHA-256:

```text
570f14d355f02fec2f1db550e4fdd256b2a3e7f2822fdb41acbcde7221d00f18
```

Terminal marker:

```text
CYCLE_SYNC_REAL_POLE_BOUNDARY_AUDIT_OK
```

## Status

This is a strict route boundary, not a Case-XII counterexample.  A positive
Case-XII theorem still needs an implication using the simultaneous absence
of T-loops and T--T types (or another common-incidence property) that is not
captured by the carrierless-cycle condition alone.
