#!/usr/bin/env python3
"""Search the frozen order-11 PM closure for the selected no-T-loop gate.

The search is deliberately local.  It asks whether four literal repeated-star
BF rows can have all three reuse targets overloaded while the seven pairs of
selected singleton matchings whose boundary pairs are T-states all intersect.
Those seven intersections are necessary, not sufficient, for absence of
T-loops in the complete perfect-matching family.
"""

from collections import Counter, defaultdict
from itertools import permutations, product


N = 11
PROPER = (
    (0, 8), (0, 10), (1, 5), (1, 8), (2, 7), (2, 9), (3, 8),
    (3, 9), (4, 6), (4, 7), (5, 6), (5, 10), (6, 9), (7, 10),
)
POSITIONS = tuple(range(1, 6))
STANDARD_CELLS = {
    "Arow": ((1, 3), (4, 5)),
    "Brow": ((1, 4), (2, 3)),
    "Crow": ((2, 4), (1, 5)),
    "Drow": ((2, 5), (3, 4)),
}
TARGETS = (
    ("B", "D", "X", "Y"),
    ("A", "C", "X", "Y"),
    ("A", "B", "D", "Y"),
)
SELECTED_T_PAIRS = (
    ("A", "B"), ("A", "D"), ("B", "X"), ("B", "Y"),
    ("C", "X"), ("C", "Y"), ("C", "D"),
)


def enumerate_pms():
    adjacency = {v: [] for v in range(N)}
    for edge_index, (u, v) in enumerate(PROPER):
        adjacency[u].append((v, edge_index))
        adjacency[v].append((u, edge_index))
    used = [False] * N
    chosen = []
    output = set()

    def rec():
        try:
            u = next(v for v in range(N) if not used[v])
        except StopIteration:
            output.add(tuple(sorted(chosen)))
            return
        used[u] = True
        if u < 5:
            chosen.append(len(PROPER) + u)
            rec()
            chosen.pop()
        for v, edge_index in adjacency[u]:
            if used[v]:
                continue
            used[v] = True
            chosen.append(edge_index)
            rec()
            chosen.pop()
            used[v] = False
        used[u] = False

    rec()
    return tuple(sorted(output))


def boundary(matching):
    return tuple(edge - len(PROPER) + 1 for edge in matching if edge >= len(PROPER))


def complement(pair):
    return tuple(sorted(set(POSITIONS) - set(pair)))


def cell_key(left, right):
    return tuple(sorted((tuple(sorted(left)), tuple(sorted(right)))))


def exact_cover(row, edge_count):
    loads = [0] * edge_count
    for matching in row:
        for edge in matching:
            loads[edge] += 1
    return all(load == 2 for load in loads)


def all_disjoint_cell_relations(matchings, classes):
    """Map a disjoint pair-state cell to its actual singleton tuples."""
    matching_id = {matching: index for index, matching in enumerate(matchings)}
    relations = {}
    for left in [pair for pair in product(POSITIONS, repeat=2) if pair[0] < pair[1]]:
        for right in [pair for pair in product(POSITIONS, repeat=2) if pair[0] < pair[1]]:
            if set(left) & set(right):
                continue
            key = cell_key(left, right)
            if key in relations:
                continue
            singleton_positions = tuple(sorted(left + right))
            relation = defaultdict(set)
            for singleton_row in product(*(classes[(p,)] for p in singleton_positions)):
                singleton_key = tuple(
                    (p, matching_id[m])
                    for p, m in zip(singleton_positions, singleton_row, strict=True)
                )
                for q_left in classes[complement(left)]:
                    for q_right in classes[complement(right)]:
                        row = (q_left, q_right) + singleton_row
                        if exact_cover(row, len(PROPER) + 5):
                            relation[singleton_key].add(
                                tuple(sorted(matching_id[m] for m in row))
                            )
            relations[key] = {
                singleton_key: tuple(sorted(witnesses))
                for singleton_key, witnesses in relation.items()
            }
    return relations


def main():
    matchings = enumerate_pms()
    assert len(matchings) == 24
    classes = defaultdict(list)
    for matching in matchings:
        classes[boundary(matching)].append(matching)
    relations = all_disjoint_cell_relations(matchings, classes)
    proper_parts = {
        index: frozenset(edge for edge in matching if edge < len(PROPER))
        for index, matching in enumerate(matchings)
    }
    ids_by_singleton_position = {
        position: tuple(
            index for index, matching in enumerate(matchings)
            if boundary(matching) == (position,)
        )
        for position in POSITIONS
    }

    def transformed_cell(permutation, name):
        mapping = {position: permutation[position - 1] for position in POSITIONS}
        left, right = STANDARD_CELLS[name]
        return cell_key(
            tuple(mapping[p] for p in left),
            tuple(mapping[p] for p in right),
        )

    raw_candidates = []
    overloaded_records = []
    seen = set()
    pivot_stars = 0
    overloaded_stars = 0
    for permutation in permutations(POSITIONS):
        mapping = {position: permutation[position - 1] for position in POSITIONS}
        rows = {
            name: relations[transformed_cell(permutation, name)]
            for name in STANDARD_CELLS
        }
        for crow_key, crow_witnesses in rows["Crow"].items():
            by_position = dict(crow_key)
            values = {
                "A": by_position[mapping[1]],
                "B": by_position[mapping[2]],
                "C": by_position[mapping[4]],
                "D": by_position[mapping[5]],
            }
            for x in ids_by_singleton_position[mapping[3]]:
                values["X"] = x
                akey = tuple(sorted((mapping[p], values[label]) for p, label in (
                    (1, "A"), (3, "X"), (4, "C"), (5, "D")
                )))
                bkey = tuple(sorted((mapping[p], values[label]) for p, label in (
                    (1, "A"), (2, "B"), (3, "X"), (4, "C")
                )))
                if akey not in rows["Arow"] or bkey not in rows["Brow"]:
                    continue
                for y in ids_by_singleton_position[mapping[3]]:
                    if y == x:
                        continue
                    values["Y"] = y
                    dkey = tuple(sorted((mapping[p], values[label]) for p, label in (
                        (2, "B"), (3, "Y"), (4, "C"), (5, "D")
                    )))
                    if dkey not in rows["Drow"]:
                        continue
                    pivot_stars += 1
                    overloaded = []
                    for target in TARGETS:
                        witnesses = tuple(
                            edge for edge in range(len(PROPER))
                            if sum(edge in proper_parts[values[label]] for label in target) >= 3
                        )
                        overloaded.append(witnesses)
                    if not all(overloaded):
                        continue
                    overloaded_stars += 1
                    intersections = {
                        pair: tuple(sorted(proper_parts[values[pair[0]]] & proper_parts[values[pair[1]]]))
                        for pair in SELECTED_T_PAIRS
                    }
                    failed_pairs = tuple(
                        pair for pair, edges in intersections.items() if not edges
                    )
                    forced_t_loops = []
                    universe = frozenset(range(len(PROPER) + 5))
                    for first, second in failed_pairs:
                        complement_matching = tuple(sorted(
                            universe - set(matchings[values[first]]) - set(matchings[values[second]])
                        ))
                        assert complement_matching in matchings
                        q_id = matchings.index(complement_matching)
                        loop_state = tuple(sorted(
                            boundary(matchings[values[first]]) + boundary(matchings[values[second]])
                        ))
                        forced_t_loops.append({
                            "selected_pair": (first, second),
                            "physical_state": loop_state,
                            "triple_matching": q_id,
                            "doubled_cover": tuple(sorted((
                                q_id, q_id, values[first], values[first],
                                values[second], values[second],
                            ))),
                        })
                    overloaded_records.append({
                        "permutation": permutation,
                        "identities": tuple((label, values[label]) for label in "ABCDXY"),
                        "target_overload_edges": tuple(zip(TARGETS, overloaded, strict=True)),
                        "one_witness_per_pivot_row": (
                            rows["Arow"][akey][0], rows["Brow"][bkey][0],
                            crow_witnesses[0], rows["Drow"][dkey][0],
                        ),
                        "failed_selected_t_pairs": failed_pairs,
                        "forced_t_loops": tuple(forced_t_loops),
                        "selected_t_pair_intersections": tuple(intersections.items()),
                    })
                    if not all(intersections.values()):
                        continue
                    signature = (permutation, tuple(values[label] for label in "ABCDXY"))
                    if signature in seen:
                        continue
                    seen.add(signature)
                    raw_candidates.append({
                        "permutation": permutation,
                        "identities": tuple((label, values[label]) for label in "ABCDXY"),
                        "proper_parts": tuple(
                            (label, tuple(sorted(proper_parts[values[label]])))
                            for label in "ABCDXY"
                        ),
                        "target_overload_edges": tuple(zip(TARGETS, overloaded, strict=True)),
                        "selected_t_pair_intersections": tuple(intersections.items()),
                        "row_witness_counts": (
                            len(rows["Arow"][akey]), len(rows["Brow"][bkey]),
                            len(crow_witnesses), len(rows["Drow"][dkey]),
                        ),
                    })

    assert pivot_stars == overloaded_stars == 3
    assert not raw_candidates
    assert Counter(
        len(record["failed_selected_t_pairs"]) for record in overloaded_records
    ) == {1: 1, 2: 1, 3: 1}
    closest = next(
        record for record in overloaded_records
        if len(record["failed_selected_t_pairs"]) == 1
    )
    assert closest["permutation"] == (1, 4, 3, 2, 5)
    assert closest["failed_selected_t_pairs"] == (("B", "Y"),)
    assert closest["forced_t_loops"][0]["physical_state"] == (3, 4)

    print({
        "perfect_matchings": len(matchings),
        "boundary_class_sizes": {
            boundary_key: len(value) for boundary_key, value in sorted(classes.items())
        },
        "labelled_repeated_pivot_stars": pivot_stars,
        "all_three_targets_overloaded": overloaded_stars,
        "selected_no_t_loop_gate_candidates": len(raw_candidates),
        "minimum_failed_selected_t_pairs": min(
            len(record["failed_selected_t_pairs"]) for record in overloaded_records
        ),
    })
    for record in overloaded_records:
        print({"overloaded_star": record})
    for candidate in raw_candidates:
        print(candidate)
    print("ORDER11_SELECTED_NO_T_LOOP_GATE_AUDITED")


if __name__ == "__main__":
    main()
