#!/usr/bin/env python3
"""Search the minimum simple unicyclic degree-three carrier layer.

Vertices 0,1 carry doubled terminal objects s2,s3; vertices 2,3,4 carry
s1,s4,s5; vertices 5,6 are terminal-free.  Only the internal copy graph,
its proper three-edge-colourings, and locally feasible A-triangle-C marks
are enumerated.  This is not a cubic-pole search.
"""

from itertools import combinations, product
import json


DEGREES = (1, 1, 2, 2, 2, 3, 3)
TERMINAL = {0: 2, 1: 3, 2: 1, 3: 4, 4: 5}
B_PATTERN = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
X_PATTERN = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
B_TT = tuple(sorted(((3, 4, 5), (1, 2, 3), (2,))))
X_TT = tuple(sorted(((2, 3, 4), (1, 2, 5), (3,))))
A_PATTERN = tuple(sorted(((1, 2, 3, 4, 5), (2,), (3,))))
ALL_EDGES = tuple((u, v) for u in range(7) for v in range(u + 1, 7))


def connected(edges):
    adjacency = {v: set() for v in range(7)}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        stack.extend(adjacency[stack.pop()] - seen)
        seen.update(stack)
    return len(seen) == 7


def graphs():
    for edges in combinations(ALL_EDGES, 7):
        degree = [0] * 7
        for u, v in edges:
            degree[u] += 1
            degree[v] += 1
        if tuple(degree) == DEGREES and connected(edges):
            yield edges


def colourings(edges):
    incident = {v: [] for v in range(7)}
    for index, (u, v) in enumerate(edges):
        incident[u].append(index)
        incident[v].append(index)
    used = [set() for _ in range(7)]
    colours = [-1] * len(edges)
    output = []

    def rec(index):
        if index == len(edges):
            boundary = {colour: [] for colour in range(3)}
            objects = {colour: set() for colour in range(3)}
            for edge_index, colour in enumerate(colours):
                objects[colour].add(f"e{edge_index}")
            for vertex, terminal in TERMINAL.items():
                missing = tuple(colour for colour in range(3) if colour not in used[vertex])
                if terminal in (2, 3):
                    assert len(missing) == 2
                    for colour in missing:
                        boundary[colour].append(terminal)
                        objects[colour].add(f"s{terminal}")
                else:
                    assert len(missing) == 1
                    colour = missing[0]
                    boundary[colour].append(terminal)
                    objects[colour].add(f"s{terminal}")
            boundary = {c: tuple(sorted(values)) for c, values in boundary.items()}
            output.append({
                "colours": tuple(colours),
                "boundary": boundary,
                "pattern": tuple(sorted(boundary.values())),
                "objects": {c: tuple(sorted(values)) for c, values in objects.items()},
            })
            return
        u, v = edges[index]
        options = range(1) if index == 0 else range(3)
        for colour in options:
            if colour in used[u] or colour in used[v]:
                continue
            colours[index] = colour
            used[u].add(colour)
            used[v].add(colour)
            rec(index + 1)
            used[u].remove(colour)
            used[v].remove(colour)
            colours[index] = -1

    rec(0)
    return output


def feasible_marks(edges):
    incident = {v: [] for v in range(7)}
    for index, (u, v) in enumerate(edges):
        incident[u].append(index)
        incident[v].append(index)
    output = []
    for bits in product((0, 1), repeat=len(edges)):
        if sum(bits[index] for index in incident[2]) != 1:
            continue
        if sum(bits[index] for index in incident[3]) != 1:
            continue
        if sum(bits[index] for index in incident[4]) != 2:
            continue
        if sum(bits[index] for index in incident[5]) != 2:
            continue
        if sum(bits[index] for index in incident[6]) != 2:
            continue
        output.append(tuple(f"e{i}" for i, bit in enumerate(bits) if bit))
    return tuple(output)


def fixed_half_owner_colourings(edges):
    """Visible-edge owners A,C,D compatible with the fixed terminal half."""
    incident = {v: [] for v in range(7)}
    for index, (u, v) in enumerate(edges):
        incident[u].append(index)
        incident[v].append(index)
    pinned = {2: 0, 3: 1, 4: 2}  # s1 in A, s4 in C, s5 in D
    output = []
    for owners in product(range(3), repeat=len(edges)):
        good = True
        for vertex, pin in pinned.items():
            if set(owners[index] for index in incident[vertex]) | {pin} != {0, 1, 2}:
                good = False
                break
        if not good:
            continue
        for vertex in (5, 6):
            if set(owners[index] for index in incident[vertex]) != {0, 1, 2}:
                good = False
                break
        if good:
            output.append(owners)
    return tuple(output)


def projection_record(row):
    return tuple(sorted(
        (
            {"boundary": row["boundary"][colour], "objects": row["objects"][colour]}
            for colour in range(3)
        ),
        key=lambda item: item["boundary"],
    ))


def negative_category(pattern):
    sizes = sorted(map(len, pattern))
    if sizes == [1, 1, 5]:
        return "A"
    assert sizes == [1, 3, 3]
    states = tuple(sorted(
        tuple(sorted(set(range(1, 6)) - set(boundary)))
        for boundary in pattern if len(boundary) == 3
    ))
    return "TT" if all(state in {
        (1, 2), (1, 5), (2, 3), (3, 4), (4, 5)
    } for state in states) else None


def main():
    counts = {
        "graphs": 0, "colourable": 0, "desired": 0, "negative": 0,
        "weak_F_candidates": 0, "fixed_half_owner_candidates": 0,
    }
    first = None
    first_owner_boundary = None
    for edges in graphs():
        counts["graphs"] += 1
        rows = colourings(edges)
        if not rows:
            continue
        counts["colourable"] += 1
        patterns = {row["pattern"] for row in rows}
        b_matchings = {
            row["objects"][colour]
            for row in rows if row["pattern"] == B_PATTERN
            for colour in range(3) if row["boundary"][colour] == (2,)
        }
        x_matchings = {
            row["objects"][colour]
            for row in rows if row["pattern"] == X_PATTERN
            for colour in range(3) if row["boundary"][colour] == (3,)
        }
        if not b_matchings or not x_matchings:
            continue
        counts["desired"] += 1
        forbidden = {
            "B_TT": B_TT in patterns,
            "X_TT": X_TT in patterns,
            "A": A_PATTERN in patterns,
            "all_TT_A_patterns": tuple(sorted(
                (pattern, negative_category(pattern))
                for pattern in patterns if negative_category(pattern) is not None
            )),
        }
        if forbidden["all_TT_A_patterns"]:
            continue
        counts["negative"] += 1
        for f_proper in feasible_marks(edges):
            f = frozenset((*f_proper, "s1", "s4"))
            if not all(set(b) & set(x) & f for b in b_matchings for x in x_matchings):
                continue
            counts["weak_F_candidates"] += 1
            if first is None:
                first = {
                    "edges": edges,
                    "f_proper": f_proper,
                    "B": tuple(sorted(b_matchings)),
                    "X": tuple(sorted(x_matchings)),
                    "B_projection": projection_record(next(
                        row for row in rows if row["pattern"] == B_PATTERN
                    )),
                    "X_projection": projection_record(next(
                        row for row in rows if row["pattern"] == X_PATTERN
                    )),
                    "colouring_patterns": tuple(sorted(patterns)),
                    "forbidden": forbidden,
                }
        for owners in fixed_half_owner_colourings(edges):
            f_proper = tuple(
                f"e{index}" for index, owner in enumerate(owners) if owner in (0, 1)
            )
            f = frozenset((*f_proper, "s1", "s4"))
            safe_pairs = tuple(
                (b, x) for b in b_matchings for x in x_matchings
                if not set(b) & set(x) & f
            )
            if not safe_pairs:
                counts["fixed_half_owner_candidates"] += 1
            elif first_owner_boundary is None:
                first_owner_boundary = {
                    "edges": edges,
                    "owners_ACD": owners,
                    "f_proper": f_proper,
                    "B": tuple(sorted(b_matchings)),
                    "X": tuple(sorted(x_matchings)),
                    "safe_pairs": safe_pairs,
                }
    assert counts["weak_F_candidates"] == 0
    assert counts["fixed_half_owner_candidates"] == 0
    print(json.dumps({
        "counts": counts,
        "first_weak_countermodel": first,
        "first_fixed_half_owner_boundary": first_owner_boundary,
    }, indent=2, sort_keys=True))
    print("UNICYCLIC_CARRIER_COUNTERMODEL_SCAN_OK")


if __name__ == "__main__":
    main()
