#!/usr/bin/env python3
"""Audit the saturated fixed-t=23 negative gate in existing frozen poles.

No graph is generated.  The script reuses the fixed complete-PM instances
already audited by ``audit_two_splice_target_35_23.py`` and adds the frozen
34-PM no-A pole plus the fixed order-nine pole from this directory.
"""

from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE_PATH = (
    ROOT / "scratch/worker-exact-negative-support-proof/"
    "audit_two_splice_target_35_23.py"
)
ZERO_CORE_PATH = (
    ROOT / "scratch/worker-bf-d5-zero-core/verify_d5_zero_core_stdlib.py"
)
ORDER9_PATH = HERE / "verify_order9_indivisible_all_bad_carrier.py"

base = run_path(BASE_PATH)
zero = run_path(ZERO_CORE_PATH)
order9 = run_path(ORDER9_PATH)

S = base["S"]
T = base["T"]
POSITIONS = base["POSITIONS"]


def canonical_order9():
    terminal = order9["TERMINAL"]
    old_to_new = {vertex: position - 1 for position, vertex in terminal.items()}
    internal = sorted(set(range(order9["N"])) - set(old_to_new))
    old_to_new.update({vertex: 5 + index for index, vertex in enumerate(internal)})
    proper = tuple(sorted(
        tuple(sorted((old_to_new[u], old_to_new[v])))
        for u, v in order9["PROPER"]
    ))
    return order9["N"], proper


def load_custom(name):
    if name == "order9-indivisible":
        order, proper = canonical_order9()
    elif name == "order13-first-synthesis":
        order = 13
        proper = tuple(zero["POLES"]["first_synthesis_no_A_boundary"])
    else:
        return base["load_instance"](name)
    family = base["enumerate_matchings"](order, proper)
    objects = frozenset(proper) | frozenset(f"s{i}" for i in range(5))
    object_index = {edge: index for index, edge in enumerate(sorted(objects, key=str))}
    family = tuple(sorted(
        family, key=lambda matching: base["matching_key"](matching, object_index)
    ))
    return order, frozenset(proper), objects, family, {}, object_index


def load_key(row, object_order):
    counts = Counter(edge for matching in row for edge in matching)
    return tuple(counts[edge] for edge in object_order)


def saturated_t23_halves(classes, objects):
    object_order = tuple(sorted(objects, key=str))
    carrier_loads = {}
    for state in S:
        carrier_loads[state] = frozenset(
            load_key(row, object_order)
            for row in product(
                classes[base["complement"](state)],
                classes[(state[0],)], classes[(state[1],)],
            )
        )
    saturated = []
    fixed_halves = 0
    for r23, b2, x3 in product(
        classes[base["complement"]((2, 3))], classes[(2,)], classes[(3,)]
    ):
        fixed_halves += 1
        h_load = load_key((r23, b2, x3), object_order)
        if max(h_load, default=0) > 2:
            continue
        k_load = tuple(2 - value for value in h_load)
        supported = tuple(sorted(state for state in S if k_load in carrier_loads[state]))
        if len(supported) == len(S):
            saturated.append((r23, b2, x3))
    return fixed_halves, tuple(saturated)


def audit(name):
    order, proper, objects, family, _, _ = load_custom(name)
    classes, profile = base["classify_boundary"](family, objects)
    fixed_halves, saturated = saturated_t23_halves(classes, objects)
    no_a = not profile["A"]
    no_tt = profile["TT"] == 0
    return {
        "instance": name,
        "order": order,
        "perfect_matchings": len(family),
        "fixed_t23_halves_tested": fixed_halves,
        "saturated_t23_halves": len(saturated),
        "A": profile["A"],
        "TT_types": profile["TT"],
        "no_A": no_a,
        "no_TT": no_tt,
        "saturated_and_no_A": bool(saturated) and no_a,
        "full_antecedent": bool(saturated) and no_a and no_tt,
        "projection_test_reached": bool(saturated) and no_a and no_tt,
        "first_missing_layer": (
            "saturated_fixed_t23_column" if not saturated else
            "global_no_A" if not no_a else
            "global_no_TT" if not no_tt else
            None
        ),
    }


def main():
    names = (
        "order9-indivisible",
        "order11",
        "order13",
        "order13-all-ss",
        "order13-first-synthesis",
        "order19",
    )
    records = tuple(audit(name) for name in names)
    assert not any(record["full_antecedent"] for record in records)
    print({
        "scope": "six frozen complete-PM real poles; no geng and no new graph",
        "instances": records,
        "instances_with_saturated_t23_and_no_A": sum(
            record["saturated_and_no_A"] for record in records
        ),
        "instances_with_saturated_t23_no_A_no_TT": 0,
        "decision": (
            "unseparated: the actual corpus is empty at global no-TT before "
            "the four Note093 projection tests"
        ),
    })
    print("EXISTING_T23_COLUMN_NEGATIVE_GATE_AUDITED")


if __name__ == "__main__":
    main()
