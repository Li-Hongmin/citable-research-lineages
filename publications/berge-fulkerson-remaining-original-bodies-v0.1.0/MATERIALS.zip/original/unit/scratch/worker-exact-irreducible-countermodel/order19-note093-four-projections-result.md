# The Note-081 order-19 pole has four vacuous Note-093 projection failures

Fix the simple connected cubic 5-pole and fourteen designated identities
from Note 081.  The physical edge set and designated perfect matchings are
read without modification from
`computations/bundles/guarded-repeated-star-selected-pm-countermodel/verify.py`.
The complete graph-induced perfect-matching family has 66 members.

For the two Note-093 fixed halves, put

\[
\begin{aligned}
 H_{23}&=r_{23}+B+X,&K_{23}&=2\mathbf1-H_{23},\\
 H_{34}&=r_{34}+Y+C,&K_{34}&=2\mathbf1-H_{34}.
\end{aligned}
\]

Every triple decomposition \(K=Q_{ij}+P_i+P_j\) was enumerated over the
complete 66-matching family, for all ten states \(ij\).  The nonzero state
counts are

\[
\begin{array}{c|rrrr}
K_{23}&13&14&23&24\\ \hline
\#\mathcal D_{ij}&3&3&3&3
\end{array}
\qquad
\begin{array}{c|rrrr}
K_{34}&23&25&34&45\\ \hline
\#\mathcal D_{ij}&6&6&6&6.
\end{array}                                             \tag{1}
\]

All omitted states have count zero.  In particular,

\[
 \mathcal D_{35}(K_{23})=\varnothing,
 \qquad
 \mathcal D_{13}(K_{34})=\varnothing.             \tag{2}
\]

The first equality is already forced by the complete matching classes:
the pole has no triple-boundary perfect matching of state \(35\).  For the
second equality, state-\(13\) triple matchings do exist globally, but none
extends with class-\(1\) and class-\(3\) singleton matchings to the specific
load \(K_{34}\).

## The four projection tests

For each target, the three fixed companions were all quantified when
forming the Note-093 sign set \(\mathcal G_H(\widehat P)\).  The results are

\[
\begin{array}{c|c|c|c|c}
\text{endpoint}&|\mathcal F|&
 (|G_{L_0}|,|G_{L_1}|,|G_{L_2}|)&|\mathcal G_H|&
 |\mathcal F\cap\mathcal G_H|\\ \hline
P_3\to Y&0&(1,2,1)&2&0\\
P_5\to D&0&(2,2,1)&2&0\\
P_1\to A&0&(1,2,1)&2&0\\
P'_3\to X&0&(2,1,1)&2&0
\end{array}                                             \tag{3}
\]

Here \(G_{L_a}\) denotes the fixed-companion preimage defined by the
`Sep` condition.  Thus all four Note-093 intersections are simultaneously
empty, but none is a nontrivial agreement-region obstruction: the relevant
oriented carrier projection is empty before it is intersected with the
nonempty sign set.

This also fixes the Note-082 continuation question.  There is no source row
of state \(35\) over \(H_{23}\) and no source row of state \(13\) over
\(H_{34}\).  Exhausting both endpoint orders and both forced-intermediate
forms therefore gives

\[
 \#\text{sequential fibres}=0,
 \qquad
 \#\text{forced-intermediate fibres}=0              \tag{4}
\]

for each carrier.  Equation (4) is failure by absence of the source
carrier, not failure of a second splice after a valid first row.

## Exact scope

The complete BF support profile of the same 66-matching closure is

\[
 (SS,ST,TT)=(7,17,15).                              \tag{5}
\]

Hence this pole is emphatically not exact Case XII: it already has all 15
\(TT\) state-pair types and lacks many required positive cells.  It is a
strict real-trivalent/full-closure boundary showing that four empty
projection intersections do not imply four populated carrier families.
It is not a counterexample to the exact-40 statement and does not test
whether four *nonempty* carrier projections can all miss their agreement
preimages.

The deterministic verifier is
`scratch/worker-exact-irreducible-countermodel/audit_order19_note093_projections.py`.
It was run on Omen with one Python process and a 1 GiB virtual-memory cap;
the final run used 11,264 KiB maximum resident memory and 0.08 s wall time,
ending with `ORDER19_NOTE093_PROJECTIONS_VERIFIED`.
