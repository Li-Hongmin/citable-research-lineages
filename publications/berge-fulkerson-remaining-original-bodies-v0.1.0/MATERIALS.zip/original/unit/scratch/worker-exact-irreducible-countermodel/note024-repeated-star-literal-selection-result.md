# The Note-024 pole has no repeated-star literal selection

Fix the order-thirteen cubic 5-pole of Note 024 and its complete family of
37 perfect matchings.  Use the four literal pivot-row families

\[
\begin{aligned}
R_1&=(q_{13},r_{45},A,X,C,D),\\
R_2&=(q_{14},r_{23},A,B,X,C),\\
R_3&=(q_{24},r_{15},A,B,C,D),\\
R_4&=(q_{25},r_{34},B,Y,C,D),
\end{aligned}
\]

where each displayed six-tuple is an actual six-perfect-matching double
cover.  A repeated-star literal selection requires the repeated letters to
denote the same perfect-matching identities in all four rows and requires
\(X\ne Y\).

The four row-family sizes are

\[
(|R_1|,|R_2|,|R_3|,|R_4|)=(32,22,16,18).
\]

Nevertheless, no repeated-star selection exists.  Joining in the order
\(R_3,R_1,R_2,R_4\) gives

\[
\begin{array}{c|r}
\text{compatibility imposed}&\text{number of partial selections}\\ \hline
R_3\Join R_1\text{ on }(A,C,D)&8\\
\text{then }R_2\text{ on }(A,B,C,X)&0\\
\text{then }R_4\text{ on }(B,C,D)&0.
\end{array}
\]

Thus the first failing gate is the extension of the eight
\((R_3,R_1)\)-pairs by an \(R_2\)-row with the same literal identities
\((A,B,C,X)\).  The condition \(X\ne Y\) is never reached.  An independent
streaming nested scan over the four row families, using no join indices,
reproduces the same counts, so the zero is not caused by a malformed index
key.

This is alternative (iii) of the bounded classification: all four pivot-row
families are individually nonempty, but they cannot share one literal
singleton assignment.  Consequently there is no selection on which to test
the two complementary carriers
\(\mathcal D_{35}(K_{23})\) and
\(\mathcal D_{13}(K_{34})\), the four Note-093 projection intersections, or
the sequential and forced-intermediate Note-082 dependent fibres.  In
particular, this calculation does not test the nonvacuous Note-093 gate.

The conclusion is only about the fixed Note-024 pole.  That pole is not
exact-\(S\), and the result is neither a real exact-Case-XII counterexample
nor an exclusion theorem for Case XII.

The deterministic standard-library verifier is
`audit_note024_repeated_star.py` in this directory.  The final run used one
Python 3.10.12 process on Omen with a 1 GiB virtual-memory cap.  It exited
zero with marker `NOTE024_REPEATED_STAR_CLASSIFIED`, wall time 0.02 seconds,
and maximum resident set size 9,984 KiB.  The executed source had SHA256

```text
6c2e45cc2000fa417764aa574070758a7ae870897891d637c0502a029428210b
```

