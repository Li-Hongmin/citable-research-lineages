# Every positive J sink in the fixed Note-024 pole has uniform one-step TT provenance

Fix the order-thirteen pole of Note 024 and its complete family of 37
perfect matchings.  The eight \(J_{31}=R_3\Join R_1\) choices have eight
different literal triples \((A,C,D)\), but all eight induce the same carrier
load

\[
K=2\mathbf1-A-C-D
 =q_{24}+r_{15}+B
 =q_{13}+r_{45}+X.                               \tag{1}
\]

For one fixed literal \((A,C,D)\), let \(\mathcal D(K)\) be the multisets
of three actual perfect-matching occurrences whose sum is \(K\).  Join two
vertices of \(\mathcal D(K)\) when one occurrence is retained and the other
two are replaced by an actual equal-load pair,

\[
M_i+M_j=M_k+M_l.                                  \tag{2}
\]

This is the complete occurrence-preserving two-sum calculus inside the
fixed carrier.  Same-boundary single-component paired splices are included
as special edges of (2).  No row jump from a shared identity and no change
of the fixed occurrences \(A,C,D\) is allowed.

The choice graph is the product of the \(B=(15\mid24;2)\) decompositions
and the \(X=(13\mid45;3)\) decompositions in \(\mathcal D(K)\), with one
coordinate changed along an edge of (2).  For a choice put

\[
J(B,X)=B\cap X\cap(A\mathbin\triangle C).          \tag{3}
\]

Orient a choice edge as a strict descent when it decreases \(|J|\).  Strict
set inclusion was checked separately and gives the same sinks.

## Complete fixed-instance graph

For each of the eight owner fibres, \(\mathcal D(K)\) has eight vertices
and ten undirected equal-pair edges.  Its boundary categories are

\[
4\ \mathrm{SS},\qquad2\ \mathrm{ST},\qquad2\ \mathrm{TT},
\qquad0\ \mathrm A.                              \tag{4}
\]

There is exactly one \(B\)-decomposition and one \(X\)-decomposition:

\[
d_B=(M_{10},M_{25},M_{31}),qquad
d_X=(M_{11},M_{20},M_{36}).                       \tag{5}
\]

Consequently the entire \(B\times X\) choice graph in every owner fibre
has one vertex and no edge.  This is stronger than a failure of one
suggested switch: every occurrence-preserving same-carrier replacement or
paired splice which remains in the required \(B/X\) fibres has been
exhausted, and none exists.

All eight isolated choices are genuinely bad.  Their \(J\)-sets are

\[
\begin{array}{c|c}
J&\text{number of owner fibres}\\ \hline
\{(4,10)\}&3\\
\{(4,10),(5,7)\}&5.
\end{array}                                                    \tag{6}
\]

Thus there are exactly eight positive local minima, equivalently eight
strict-descent sinks, and no nontrivial descent edge at all.

## Uniform TT exits

Every sink nevertheless has two radius-one TT exits in the full carrier
decomposition graph.  On the \(B\)-coordinate the equality is

\[
\boxed{M_{10}+M_{31}=M_7+M_{34}}.                \tag{7}
\]

The boundary classes change from

\[
(2)+(135)\quad\longrightarrow\quad(3)+(125).
\]

Retaining \(M_{25}\), whose boundary is \((234)\), changes (5) to

\[
(M_7,M_{25},M_{34}),
\]

which has TT type \((15)(34)\) with singleton 3.  Adding the untouched
\(A,C,D\) therefore gives an actual TT BF row in every one of the eight
owner fibres.

On the \(X\)-coordinate one has the previously visible equality

\[
\boxed{M_{11}+M_{20}=M_8+M_{23}}.                \tag{8}
\]

Here the boundary classes change from

\[
(245)+(3)\quad\longrightarrow\quad(345)+(2).
\]

Retaining \(M_{36}\), whose boundary is \((123)\), gives the TT type
\((12)(45)\) with singleton 2.  The certificate records the literal edge
sets and common edgewise load vector for both (7) and (8); neither equality
is inferred only from its boundary classes.  They are actual equal-pair
substitutions rather than same-boundary splices.

The two equations are independent of \((A,C,D)\).  Hence every one of the
eight positive sinks has exact distance one to TT from both carrier
coordinates.  No A exit is needed, and there is no positive sink without a
TT/A provenance.

## Decision boundary

The fixed-instance candidate

> if a bad \(B/X\) choice admits no strict same-carrier \(J\)-descent, then
> it has occurrence-preserving TT/A provenance

holds nonvacuously on the Note-024 pole.  Its antecedent holds for all eight
choices: each has \(J\ne\varnothing\) and is an isolated choice-graph
vertex.  Its conclusion is witnessed uniformly and at the minimum possible
positive distance by (7) and (8).

This is not a general extremal-descent lemma.  In particular, the fixed
pole already has TT support, so the calculation does not show that exact
negative support forces a descent.  What it establishes is the sharper
finite alternative requested here: in this complete 8-choice instance,
failure of every same-carrier descent is explained by explicit TT
factorizations, not by a bad provenance-free sink.

## Reproduction and scope

`audit_note024_extremal_descent.py` reconstructs the 37 perfect matchings,
the eight literal choices, all carrier decompositions, all equal-load pair
classes, the choice graphs, the two notions of strict descent, and shortest
TT/A paths.  The full output is in
`note024_extremal_descent_result.txt`, including every sink and the strict
edgewise equalities in (7)--(8).

The final Omen run used Python 3.10.12, one process and a 1 GiB virtual
memory cap.  It ended with `NOTE024_EXTREMAL_DESCENT_CLASSIFIED` in 0.03
seconds and used at most 11,776 KiB resident memory.  No other graph, order,
random search, SAT instance or CEGAR loop was used, and no permanent note
was modified.
