#!/usr/bin/env python3
"""Enumerate the minimum five-vertex degree-three carrier path.

The endpoint objects s2 and s3 occur twice; s1,s4,s5 occur once at the
three internal vertices.  The scan is over terminal order, all proper
three-edge-colourings, and every locally feasible A-triangle-C mark set F.
"""

from itertools import permutations, product
import json


COLORS = range(3)
B_PATTERN = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
X_PATTERN = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
B_TT = tuple(sorted(((3, 4, 5), (1, 2, 3), (2,))))
X_TT = tuple(sorted(((2, 3, 4), (1, 2, 5), (3,))))
A_PATTERN = tuple(sorted(((1, 2, 3, 4, 5), (2,), (3,))))


def colourings(order):
    output = []
    for path_colours in product(COLORS, repeat=4):
        if any(path_colours[i] == path_colours[i + 1] for i in range(3)):
            continue
        boundary = {colour: [] for colour in COLORS}
        edges = {colour: set() for colour in COLORS}
        for colour in COLORS:
            if colour != path_colours[0]:
                boundary[colour].append(2)
                edges[colour].add("s2")
            if colour != path_colours[3]:
                boundary[colour].append(3)
                edges[colour].add("s3")
        for index, terminal in enumerate(order):
            third = next(
                colour for colour in COLORS
                if colour not in (path_colours[index], path_colours[index + 1])
            )
            boundary[third].append(terminal)
            edges[third].add(f"s{terminal}")
        for index, colour in enumerate(path_colours):
            edges[colour].add(f"e{index}")
        boundary = {colour: tuple(sorted(values)) for colour, values in boundary.items()}
        pattern = tuple(sorted(boundary.values()))
        output.append({
            "path_colours": path_colours,
            "boundary": boundary,
            "pattern": pattern,
            "edges": {colour: tuple(sorted(values)) for colour, values in edges.items()},
        })
    return output


def feasible_marks(order):
    marks = []
    for bits in product((0, 1), repeat=4):
        good = True
        for index, terminal in enumerate(order):
            incident_mark_count = bits[index] + bits[index + 1]
            required = 1 if terminal in (1, 4) else 2
            if incident_mark_count != required:
                good = False
                break
        if good:
            marks.append(tuple(f"e{i}" for i, bit in enumerate(bits) if bit))
    return tuple(marks)


def main():
    records = []
    for order in permutations((1, 4, 5)):
        rows = colourings(order)
        patterns = {row["pattern"] for row in rows}
        b_matchings = {
            row["edges"][colour]
            for row in rows if row["pattern"] == B_PATTERN
            for colour in COLORS if row["boundary"][colour] == (2,)
        }
        x_matchings = {
            row["edges"][colour]
            for row in rows if row["pattern"] == X_PATTERN
            for colour in COLORS if row["boundary"][colour] == (3,)
        }
        for f_proper in feasible_marks(order):
            f = frozenset((*f_proper, "s1", "s4"))
            all_bad = bool(b_matchings and x_matchings) and all(
                set(b) & set(x) & f for b in b_matchings for x in x_matchings
            )
            records.append({
                "order": order,
                "f_proper": f_proper,
                "B": tuple(sorted(b_matchings)),
                "X": tuple(sorted(x_matchings)),
                "has_B_TT": B_TT in patterns,
                "has_X_TT": X_TT in patterns,
                "has_A": A_PATTERN in patterns,
                "all_bad": all_bad,
            })
    candidates = [record for record in records if (
        record["B"] and record["X"] and not record["has_B_TT"]
        and not record["has_X_TT"] and not record["has_A"]
        and record["all_bad"]
    )]
    print(json.dumps({
        "records": len(records),
        "candidates": len(candidates),
        "first": candidates[0] if candidates else None,
    }, indent=2, sort_keys=True))
    print("CARRIER_PATH_COUNTERMODEL_SCAN_OK")


if __name__ == "__main__":
    main()
