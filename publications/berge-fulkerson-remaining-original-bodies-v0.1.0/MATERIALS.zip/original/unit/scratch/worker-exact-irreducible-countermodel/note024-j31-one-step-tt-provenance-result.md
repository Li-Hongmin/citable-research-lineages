# Every Note-024 J31 choice has a one-step TT provenance

Fix the order-thirteen pole of Note 024 and the eight choices in
\(R_3\Join R_1\) sharing \((A,C,D)\).  Each choice supplies two separate
starting rows

\[
\begin{aligned}
R_1&=(q_{13},r_{45},A,X,C,D),\\
R_3&=(q_{24},r_{15},A,B,C,D),
\end{aligned}
\]

and the associated target quartet \((A,B,X,C)\) is overloaded.

## Occurrence-preserving closure

A state is a multiset of six actual perfect-matching occurrences whose
edgewise sum is \(2\mathbf 1\).  One move selects two occurrences \(P,Q\),
retains the other four pointwise, and replaces them by actual perfect
matchings \(P',Q'\) satisfying

\[
\chi_P+\chi_Q=\chi_{P'}+\chi_{Q'}.
\]

Repeated identities retain their multiplicities.  Passing to the multiset
quotient only removes irrelevant permutations of the six occurrence
positions; it does not permit a jump between rows sharing one identity and
does not activate an identity pool.  Same-boundary single-cycle paired
splices are included as special equal-pair moves.  The \(R_1\) and \(R_3\)
rows are searched as separate starting states and are not merged merely
because they share literal identities.

## Exact one-step result

For every one of the eight choices,

\[
d(R_1,\mathrm{TT/A})=d(R_3,\mathrm{TT/A})=1.
\]

Both start types are ST, so distance zero is impossible; these distances
are exact.  All sixteen shortest sinks are TT rather than A.  More strongly,
the eight \(R_1\) provenances are the same two-occurrence substitution:

\[
M_{11}+M_{20}=M_8+M_{23}.                         \tag{1}
\]

Their boundary classes are

\[
\begin{array}{c|c|l}
M&\partial M&\text{edge set}\\ \hline
11&245&\{s_1,s_3,s_4,(0,11),(2,9),(5,8),(6,12),(7,10)\}\\
20&3&\{s_2,(0,8),(1,9),(3,12),(4,10),(5,7),(6,11)\}\\
8&345&\{s_2,s_3,s_4,(0,11),(1,9),(5,8),(6,12),(7,10)\}\\
23&2&\{s_1,(0,8),(2,9),(3,12),(4,10),(5,7),(6,11)\}.
\end{array}
\]

Thus (1) is visible edge by edge.  In the literal notation it is

\[
q_{13}+X=q_{12}+B'.                               \tag{2}
\]

Substituting (2) into every \(R_1\) row while retaining
\(r_{45},A,C,D\) gives

\[
q_{12}+r_{45}+A+B'+C+D=2\mathbf1,                 \tag{3}
\]

which is the actual TT row of type \((12)(45)\).  The identities
\((q_{13},X,q_{12},B')=(11,20,8,23)\) do not depend on the J31 choice;
only the retained \((A,C,D)\) vary.  Hence all eight overloaded choices
share one uniform radius-one TT provenance.  The \(R_3\) starts also reach
TT in one move, although their equal-pair substitutions are not uniform.

## The exact-negative-support statement

Equation (2) gives the following general local lemma.

> **One-pair TT factorization lemma.**  If an actual pivot row
> \(q_{13}+r_{45}+A+X+C+D=2\mathbf1\) and actual matchings \(q_{12},B'\)
> satisfy \(q_{13}+X=q_{12}+B'\), then the same pole has the TT cover
> \((12)(45)\) displayed in (3).

The proof is the single substitution above.  Consequently exact Case-XII
negative support forbids such a factorization.

The natural stronger candidate is an *overload-to-bounded-provenance
dichotomy*: an overloaded J31 target in a complete cubic perfect-matching
closure forces, from one of its literal pivot rows, an occurrence-preserving
TT/A provenance of length at most two.  The fixed Note-024 instance satisfies
this with length one, but it does not prove the dichotomy.  In particular,
the still-missing general step is to force an equality such as (2) from
cubic incidence, full closure, and target overload; exact negative support
itself only rules the equality out after it has been obtained.

## Scope and reproduction

This is a complete fixed-instance shortest-path calculation.  It uses only
the 37 perfect matchings of the Note-024 pole and equal-load pairs among
them.  It performs no graph search, order extension, census, random search,
or SAT calculation.  Since the pole is not exact-\(S\), the result is not a
Case-XII exclusion theorem.

The standard-library verifier is `audit_note024_j31_tt_provenance.py` in
this directory.  Its source SHA256 is

```text
0936a384a8a6402969f23095c182766e3cb34d0287a3865316cdda3348450132
```

The final run used Python 3.10.12 on Omen, one process, and a 1 GiB virtual
memory cap.  It exited zero with marker
`NOTE024_J31_TT_PROVENANCE_CLASSIFIED`, wall time 0.03 seconds, and maximum
resident set size 11,264 KiB.
