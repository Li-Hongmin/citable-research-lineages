# Independent validation of the four residual leakage reduction

This checks only the three load-bearing claims in
no-tt-collapses-four-residual-parity-failures-to-cross-carrier-s-leakage.md.
All three are correct. No graph search or finite computation is used.

## 1. No terminal-path condition is missing

For either anchored carrier \(K\), one has

\[
K(s_k)=1\qquad(k\in[5]).
\]

If \(P\) has singleton boundary \(i\), then \(D=K-P\) has semiedge
multiplicity zero at \(i\) and one at each of the other four terminals.
At every internal vertex \(D\) has degree two. Under \(D\ge0\), its
components are therefore closed cycles and terminal-to-terminal paths.

Every even closed component can be alternately two-coloured. Every path can
also be alternately two-coloured, with no condition on its length because
neither endpoint colour has been prescribed. Each colour then meets every
internal vertex once, so the two colour classes are actual perfect
matchings.

Their boundary sizes are automatically odd. Indeed, for a cubic five-pole

\[
3|V|=2|E_{\rm proper}|+5,
\]

so \(|V|\) is odd, and the boundary size of every perfect matching has the
same parity as \(|V|\). The two boundary sizes sum to the four residual
semiedges. They must consequently be \(1\) and \(3\). If the singleton
colour uses terminal \(j\), then \(j\ne i\), and the other colour uses
\([5]\setminus\{i,j\}\). Hence

\[
D=q_{ij}+P_j
\]

for some \(j\ne i\).

The terminal-path parity condition in Note 078 is needed when the two target
boundaries, and therefore \(j\), are fixed in advance. Here \(j\) is read
from whichever alternating decomposition is obtained. Thus nonnegativity
and evenness of all closed components are sufficient, and no
wrong-terminal-parity case remains.

## 2. The four allowed leakages are unique

Adding \(D=q_{ij}+P_j\) to the fixed \(T\)-half produces a BF row of type
\((ij)(t)\), with \(t=23\) or \(34\). Since \(t\in T\), any \(ij\in T\)
would give a forbidden \(T\)--\(T\) row. Therefore \(ij\in S\).

The \(S\)-neighbours of the four endpoint classes are

\[
\begin{array}{c|c|c|c}
\widehat P_i&i&\{j:ij\in S\}&
  \text{intended }j\ \longrightarrow\ \text{only alternate }j'\\ \hline
Y&3&\{1,5\}&5\longrightarrow1\\
D&5&\{2,3\}&3\longrightarrow2\\
A&1&\{3,4\}&3\longrightarrow4\\
X&3&\{1,5\}&1\longrightarrow5.
\end{array}
\]

For a candidate in the corresponding restricted agreement-core family,
the intended value of \(j\) would put that same matching in the intended
projection \(\mathcal F_i(K;j)\), contradicting the relevant empty
intersection in Note 093(12). The two \(T\)-neighbours are excluded by
no-\(TT\), leaving exactly the displayed alternate \(S\)-projection.
These are precisely the states

\[
13,\quad25,\quad14,\quad35.
\]

Different alternating choices on even residual cycles may give multiple
decompositions, but every such decomposition is subject to the same two
exclusions. Therefore they cannot produce a second projection index:
the leakage state is unique even if its witness decomposition is not.

## 3. The no-\(A\) blocker is genuinely class-wide

For each endpoint class \(i\), the corresponding quartet \(W_i\) consists
of actual singleton perfect matchings in the other four boundary classes.
It is contained in a literal BF row, hence

\[
W_i\le2\mathbf1.
\]

Let \(P\) be any actual class-\(i\) perfect matching, with no restriction to
a partial-flip cube. If \(P\cap D_2(W_i)=\varnothing\), then

\[
W_i+P\le2\mathbf1.
\]

At every cubic vertex the five matching occurrences contribute total
incident load five. Three nonnegative incidence loads bounded by two and
summing to five must be \((2,2,1)\). Therefore

\[
Z=2\mathbf1-W_i-P
\]

is a \(0/1\) edge set meeting every vertex exactly once. The four
matchings in \(W_i\) use the four semiedges other than \(s_i\), while \(P\)
uses \(s_i\); consequently \(Z\) contains all five semiedges. Thus \(Z\)
is an actual all-terminal perfect matching, and

\[
W_i+P+Z=2\mathbf1
\]

is a forbidden \(A\)-cover.

Hence absence of \(A\) implies

\[
P\cap D_2(W_i)\ne\varnothing
\qquad\text{for every actual }P\in\mathcal P_i.
\]

The quantifier is over the complete class-\(i\) perfect-matching family,
not only over the displayed endpoint matching or its internal-cycle
switches.

## Verdict

The proposed three-way classification is valid:

1. a negative residual edge;
2. a nonnegative residual with an odd closed component; or
3. the unique alternate \(S\)-leakage in the table above.

The four-intersection claim itself remains undecided exactly as stated in
the source draft. This validation adds no existence claim for an exact
Case-XII pole and does not enter the dependent second splice.

