#!/usr/bin/env python3
"""Finite local-incidence extensions of the fixed order-nine PM closure.

This is deliberately *not* a graph extension.  A local matching identity has
the prescribed boundary and chooses one incident port at each of the nine
old trivalent vertices.  It need not choose a proper edge consistently at
both endpoints.  A local BF row uses every one of the three ports at every
vertex exactly twice.  The model is the weakest common-nine-vertex incidence
extension of the actual 18 perfect-matching identities.

For each of the eleven missing S--T cells, enumerate all completions that use
the maximum possible number of old actual identities (equivalently, the
minimum number of new local identities).  Test whether every such completion
already creates a new A/TT row or a safe entry in the fixed A,C,D carrier
fibre.  This gives a sharp finite boundary at this abstraction level.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement, product
import json

import verify_order9_indivisible_all_bad_carrier as fixed


POSITIONS = frozenset(range(1, 6))
S = frozenset({(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)})
T = frozenset({(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)})
MISSING = (
    ((1, 2), (1, 3)), ((1, 2), (2, 4)), ((1, 2), (2, 5)),
    ((1, 3), (2, 3)), ((1, 3), (3, 4)), ((1, 4), (2, 3)),
    ((2, 3), (2, 4)), ((2, 3), (2, 5)), ((2, 3), (3, 5)),
    ((2, 4), (3, 4)), ((3, 4), (3, 5)),
)


def complement(pair):
    return tuple(sorted(POSITIONS - set(pair)))


INCIDENT = tuple(tuple(
    index for index, edge in enumerate(fixed.OBJECTS)
    if (vertex in edge if len(edge) == 2 else edge[2] == vertex)
) for vertex in range(fixed.N))
assert all(len(row) == 3 for row in INCIDENT)

SEMI_AT_VERTEX = {}
for vertex, row in enumerate(INCIDENT):
    semis = [index for index in row if len(fixed.OBJECTS[index]) == 3]
    if semis:
        assert len(semis) == 1
        edge = fixed.OBJECTS[semis[0]]
        SEMI_AT_VERTEX[vertex] = (semis[0], edge[1])


def actual_profile(matching):
    profile = []
    for row in INCIDENT:
        chosen = [edge for edge in row if edge in matching]
        assert len(chosen) == 1
        profile.append(chosen[0])
    return tuple(profile)


ACTUAL_MATCHINGS = fixed.enumerate_perfect_matchings()
ACTUAL_TOKENS = tuple(
    (fixed.boundary(matching), actual_profile(matching), f"old{index}", False)
    for index, matching in enumerate(ACTUAL_MATCHINGS)
)
ACTUAL_PROFILES = frozenset(
    (boundary, profile) for boundary, profile, _, _ in ACTUAL_TOKENS
)


def cell_slots(cell):
    left, right = cell
    return (
        complement(left), complement(right),
        *((position,) for position in (*left, *right)),
    )


def locally_balanced(tokens):
    if len(tokens) != 6:
        return False
    for vertex, ports in enumerate(INCIDENT):
        counts = Counter(token[1][vertex] for token in tokens)
        if tuple(counts[port] for port in ports) != (2, 2, 2):
            return False
    return True


def residual_pair_options(new_slots, old_tokens):
    """All two-token profiles completing four old tokens locally."""
    per_vertex = []
    for vertex, ports in enumerate(INCIDENT):
        counts = Counter(token[1][vertex] for token in old_tokens)
        if any(counts[port] > 2 for port in ports):
            return tuple()
        residual = []
        for port in ports:
            residual.extend([port] * (2 - counts[port]))
        if len(residual) != 2:
            return tuple()
        allowed = set()
        for first, second in {(residual[0], residual[1]), (residual[1], residual[0])}:
            valid = True
            if vertex in SEMI_AT_VERTEX:
                semi, position = SEMI_AT_VERTEX[vertex]
                valid = (
                    ((first == semi) == (position in new_slots[0]))
                    and ((second == semi) == (position in new_slots[1]))
                )
            if valid:
                allowed.add((first, second))
        if not allowed:
            return tuple()
        per_vertex.append(tuple(sorted(allowed)))
    pairs = set()
    for assignment in product(*per_vertex):
        first = tuple(item[0] for item in assignment)
        second = tuple(item[1] for item in assignment)
        tokens = tuple(sorted(((new_slots[0], first), (new_slots[1], second))))
        pairs.add(tokens)
    return tuple(sorted(pairs))


def minimum_extensions(cell):
    slots = cell_slots(cell)
    by_boundary = defaultdict(list)
    for token in ACTUAL_TOKENS:
        by_boundary[token[0]].append(token)
    # Derive the maximum number of old occurrences before constructing the
    # residual profiles.  Boundary totals make every remaining terminal-port
    # count correct; the only obstruction is an old port already used >2.
    maximum_old = -1
    for old_count in range(6, -1, -1):
        feasible = False
        for old_indices in combinations(range(6), old_count):
            if any(not by_boundary[slots[index]] for index in old_indices):
                continue
            for old_tokens in product(*(by_boundary[slots[index]] for index in old_indices)):
                if all(
                    max(Counter(token[1][vertex] for token in old_tokens).values(), default=0) <= 2
                    for vertex in range(fixed.N)
                ):
                    feasible = True
                    break
            if feasible:
                break
        if feasible:
            maximum_old = old_count
            break
    assert maximum_old == 4
    extensions = {}
    for old_indices in combinations(range(6), maximum_old):
        if any(not by_boundary[slots[index]] for index in old_indices):
            continue
        for old_tokens in product(*(by_boundary[slots[index]] for index in old_indices)):
            new_indices = tuple(index for index in range(6) if index not in old_indices)
            new_slots = tuple(slots[index] for index in new_indices)
            for pair in residual_pair_options(new_slots, old_tokens):
                if any(item in ACTUAL_PROFILES for item in pair):
                    continue
                extensions.setdefault(pair, (old_indices, old_tokens, new_indices))
    return maximum_old, tuple(
        (pair, *extensions[pair]) for pair in sorted(extensions)
    )


def token_pool(new_pairs):
    pool = list(ACTUAL_TOKENS)
    for cell_index, pair in new_pairs:
        for token_index, (boundary, profile) in enumerate(dict.fromkeys(pair)):
            pool.append((boundary, profile, f"new{cell_index}_{token_index}", True))
    return tuple(pool)


def first_balanced_for_slots(pool, slots, require_new=True):
    by_boundary = defaultdict(list)
    for token in pool:
        by_boundary[token[0]].append(token)
    if any(not by_boundary[slot] for slot in slots):
        return None
    for row in product(*(by_boundary[slot] for slot in slots)):
        if require_new and not any(token[3] for token in row):
            continue
        if locally_balanced(row):
            return row
    return None


def first_new_forbidden(pool):
    a_slots = ((1, 2, 3, 4, 5), (1,), (2,), (3,), (4,), (5,))
    row = first_balanced_for_slots(pool, a_slots)
    if row is not None:
        return ("A", row)
    for left, right in combinations_with_replacement(sorted(T), 2):
        slots = (complement(left), complement(right),
                 *((position,) for position in (*left, *right)))
        row = first_balanced_for_slots(pool, slots)
        if row is not None:
            return ((left, right), row)
    return None


def fixed_token(matching):
    target = (fixed.boundary(matching), actual_profile(matching))
    return next(token for token in ACTUAL_TOKENS if token[:2] == target)


FIXED_A = fixed_token(fixed.A)
FIXED_C = fixed_token(fixed.C)
FIXED_D = fixed_token(fixed.D)


def fixed_fibres(pool):
    b_slots = ((1, 3, 5), (2, 3, 4), (2,))
    x_slots = ((2, 4, 5), (1, 2, 3), (3,))
    by_boundary = defaultdict(list)
    for token in pool:
        by_boundary[token[0]].append(token)

    def rows(slots):
        out = []
        for carrier in product(*(by_boundary[slot] for slot in slots)):
            row = (*carrier, FIXED_A, FIXED_C, FIXED_D)
            if locally_balanced(row):
                singleton = carrier[2]
                out.append((carrier, singleton))
        return tuple(out)

    return rows(b_slots), rows(x_slots)


def safe_entry(pool):
    b_rows, x_rows = fixed_fibres(pool)
    for b_row, b_token in b_rows:
        for x_row, x_token in x_rows:
            bad = []
            for vertex in range(fixed.N):
                port = b_token[1][vertex]
                if x_token[1][vertex] != port:
                    continue
                if (FIXED_A[1][vertex] == port) != (FIXED_C[1][vertex] == port):
                    bad.append((vertex, port))
            if not bad:
                return b_row, x_row
    return None


def row_names(row):
    return tuple(token[2] for token in row)


def main():
    per_cell = []
    clean_choice = {}
    for cell_index, cell in enumerate(MISSING):
        maximum_old, extensions = minimum_extensions(cell)
        outcomes = Counter()
        forbidden_types = Counter()
        first_clean = None
        examples = {}
        minimum_distinct_new = 2
        for pair, old_indices, old_tokens, new_indices in extensions:
            minimum_distinct_new = min(minimum_distinct_new, len(set(pair)))
            pool = token_pool(((cell_index, pair),))
            forbidden = first_new_forbidden(pool)
            safe = safe_entry(pool)
            if forbidden is not None:
                forbidden_types[str(forbidden[0])] += 1
            key = (
                "forbidden" if forbidden is not None else "no_forbidden",
                "safe" if safe is not None else "no_safe",
            )
            outcomes[key] += 1
            examples.setdefault(key, {
                "new_tokens": pair,
                "old_slot_indices": old_indices,
                "new_slot_indices": new_indices,
                "old_tokens": tuple(token[2] for token in old_tokens),
                "forbidden": None if forbidden is None else (
                    str(forbidden[0]), row_names(forbidden[1])
                ),
                "safe": None if safe is None else (
                    row_names(safe[0]), row_names(safe[1])
                ),
            })
            if forbidden is None and safe is None and first_clean is None:
                first_clean = pair
        if first_clean is not None:
            clean_choice[cell_index] = first_clean
        per_cell.append({
            "cell": cell,
            "maximum_old_occurrences": maximum_old,
            "minimum_new_occurrences": 6 - maximum_old,
            "minimum_distinct_new_identities_seen": minimum_distinct_new,
            "minimum_extensions": len(extensions),
            "outcomes": {"/".join(key): value for key, value in sorted(outcomes.items())},
            "first_new_forbidden_type_counts": dict(sorted(forbidden_types.items())),
            "has_clean_extension": first_clean is not None,
            "examples": {"/".join(key): value for key, value in examples.items()},
        })

    # Combine the first clean choice for every individually nonforcing cell.
    # If this union is clean, all subsets of those cells are clean by deleting
    # their private identities; any subset containing an individually forcing
    # cell is already forbidden.  This classifies all 2^11 cell subsets.
    simultaneous = None
    if clean_choice:
        pool = token_pool(tuple(sorted(clean_choice.items())))
        forbidden = first_new_forbidden(pool)
        safe = safe_entry(pool)
        simultaneous = {
            "deterministic_first_clean_choices_have_new_forbidden": forbidden is not None,
            "deterministic_first_clean_choices_have_safe_entry": safe is not None,
            "new_forbidden": None if forbidden is None else (
                str(forbidden[0]), row_names(forbidden[1])
            ),
            "safe": None if safe is None else (row_names(safe[0]), row_names(safe[1])),
            "included_cell_indices": tuple(sorted(clean_choice)),
            "classifies_all_2048_subsets": forbidden is None and safe is None,
        }

    result = {
        "model": (
            "old 18 actual PM identities plus boundary-correct local identities; "
            "one incident port per identity at each of the nine old cubic vertices; "
            "a local BF row has port loads (2,2,2) at every vertex; no proper-edge "
            "endpoint-consistency and hence not a graph or PM-closure extension"
        ),
        "baseline_already_has_A": False,
        "baseline_already_has_TT": True,
        "consequence_test": (
            "a forbidden witness must involve a new identity; safe means a new "
            "locally balanced B/X choice in the fixed literal A,C,D fibre"
        ),
        "cells": per_cell,
        "all_cells_have_individually_clean_minimum_extension": (
            len(clean_choice) == len(MISSING)
        ),
        "simultaneous_first_clean_probe": simultaneous,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    print("MISSING_ST_LOCAL_INCIDENCE_EXTENSIONS_AUDITED")


if __name__ == "__main__":
    main()
