# Order eleven cannot combine repeated-star overload with the selected no-T-loop gate

## Fixed-order conclusion

There is no order-eleven simple cubic 5-pole incidence object of girth at
least five carrying actual perfect matchings

\[
 A,B,C,D,X,Y,
 q_{13},r_{45},q_{14},r_{23},q_{24},r_{15},q_{25},r_{34}
\]

with the prescribed boundaries, such that all of the following hold:

1. \(X\ne Y\), and the four literal repeated-extension rows

   \[
   \begin{split}
    &(q_{13},r_{45},A,X,C,D),\\
    &(q_{14},r_{23},A,B,X,C),\\
    &(q_{24},r_{15},A,B,C,D),\\
    &(q_{25},r_{34},B,Y,C,D)
   \end{split}                                      \tag{1}
   \]

   double-cover every edge;

2. each of \(BDXY,ACXY,ABDY\) has load at least three on some proper
   edge;

3. every pair in

   \[
   AB,\ AD,\ BX,\ BY,\ CX,\ CY,\ CD                \tag{2}
   \]

   shares a proper edge.

Condition (2) is forced by absence of the five \(T\)-loops in the complete
perfect-matching closure.  The two selected singleton matchings in each pair
have different boundary semiedges.  If their proper parts were disjoint,
then at every cubic vertex they would use two distinct incidences and the
unused incidence would form a third perfect matching.  Doubling these three
matchings gives the corresponding \(T\)-loop.

It follows immediately that no order-eleven pole can satisfy

\[
 \text{no }T\text{-loop/}T\text{--}T
 +\text{ Note-019 irreducibility}
 +\text{(1)}+\text{three target overloads}.          \tag{3}
\]

The finite contradiction is stronger than (3): connectivity, bridge and
proper-two-cut restrictions, and the complete no-\(T\)--\(T\) condition were
not needed once (2) was imposed.

## Directed finite encoding

The search uses one Boolean graph variable for each of the 55 possible
proper edges and one incidence variable for every named matching and possible
proper edge.  It imposes the cubic degree sequence, the matching equations,
the four exact row equations, the three overload disjunctions, the seven
intersections (2), and excludes all triangles and squares.  This is one
fixed-order satisfiability object, not a scan over a graph list.

The symmetry constraint \(56\in E\) is lossless.  The six nonterminal
vertices contribute 18 proper incidences, while the five terminal vertices
contribute only 10; hence every order-eleven object has a
nonterminal--nonterminal edge, which may be relabelled as 56.

On Omen, Z3 5.1.0 returned `unsat` in the first solver call.  No candidate
graph was produced, so none of the lazy complete-closure or structural-cut
clauses was added.  The final marker was

```text
ORDER11_REPEATED_STAR_NO_TT_UNSAT
```

The final run took 38.55 seconds and 61,184 KB peak RSS.  Its source SHA-256
is

```text
5303bfc17fd66baa9d596f976875b9880ff0408002326cb0f23576a638debae2
```

## One-condition sharpness

Deleting only the selected intersection \(B\cap Y\ne\varnothing\) makes the
same order-eleven system satisfiable.  Omen found, in 1.12 seconds, the
girth-five graph

\[
\begin{split}
 &(0,7),(0,9),(1,8),(1,9),(2,8),(2,10),(3,6),\\
 &(3,9),(4,5),(4,10),(5,6),(5,8),(6,7),(7,10).
\end{split}                                       \tag{4}
\]

It also satisfies the Note-019 bridge/proper-two-cut check.  Thus the fixed
UNSAT boundary is sharp by one selected-pair condition.  Graph (4) is not
claimed to have no other \(T\)-loop or \(T\)--\(T\) witness in its complete
closure.

## Scope and reproduction

This is a strict order-eleven boundary, not an all-order theorem.  It gives
no order-thirteen or order-fifteen evidence and does not prove that
no-\(T\)-loop/\(T\)--\(T\) forces a nonoverloaded target in general.

The source is `synthesize_order11_repeated_star_no_tt.py` in this directory.
The Omen run is frozen at

```text
[local archival reference]
```

and was invoked there as

```text
python3 -u synthesize_order11_repeated_star_no_tt.py \
  --max-rounds 500 --timeout-ms 300000 --json result.json
```
