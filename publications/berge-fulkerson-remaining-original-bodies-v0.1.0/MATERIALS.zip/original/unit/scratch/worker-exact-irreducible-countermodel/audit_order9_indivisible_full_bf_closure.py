#!/usr/bin/env python3
"""Complete BF closure of the fixed order-nine all-bad carrier pole."""

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement
import json

import verify_order9_indivisible_all_bad_carrier as fixed


POSITIONS = frozenset(range(1, 6))
PAIRS = tuple(combinations(range(1, 6), 2))
S = frozenset({(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)})
T = frozenset(set(PAIRS) - set(S))
TARGET40 = frozenset(
    (left, right)
    for left, right in combinations_with_replacement(PAIRS, 2)
    if (left == right and left in S)
    or (left != right and left in S and right in S)
    or ((left in S) != (right in S))
)
assert len(TARGET40) == 40


def classify_boundaries(boundaries):
    sizes = sorted(map(len, boundaries))
    if sizes == [1, 1, 1, 1, 1, 5]:
        return ("A",)
    if sizes != [1, 1, 1, 1, 3, 3]:
        raise AssertionError(boundaries)
    missing = tuple(sorted(
        tuple(sorted(POSITIONS - set(boundary)))
        for boundary in boundaries if len(boundary) == 3
    ))
    singleton_multiset = sorted(
        boundary[0] for boundary in boundaries if len(boundary) == 1
    )
    assert singleton_multiset == sorted((*missing[0], *missing[1]))
    return missing


def human(kind):
    if kind == ("A",):
        return "(12345)"
    left, right = kind
    if left == right:
        return f"[{left[0]}{left[1]}]"
    return f"({left[0]}{left[1]})({right[0]}{right[1]})"


def literal_matching(matching):
    names = []
    for index in sorted(matching):
        edge = fixed.OBJECTS[index]
        if len(edge) == 2:
            names.append(f"{edge[0]}-{edge[1]}")
        else:
            names.append(f"s{edge[1]}@{edge[2]}")
    return tuple(names)


def main():
    matchings = fixed.enumerate_perfect_matchings()
    assert len(matchings) == 18
    boundary = {matching: fixed.boundary(matching) for matching in matchings}
    target_two = (2,) * len(fixed.OBJECTS)
    target_one = (1,) * len(fixed.OBJECTS)

    support_counts = Counter()
    first_witness = {}
    total_covers = 0
    for row in combinations_with_replacement(matchings, 6):
        if fixed.load(row) != target_two:
            continue
        total_covers += 1
        kind = classify_boundaries(tuple(boundary[item] for item in row))
        support_counts[kind] += 1
        first_witness.setdefault(kind, row)

    tait_counts = Counter()
    tait_first = {}
    for row in combinations(matchings, 3):
        if fixed.load(row) != target_one:
            continue
        singleton_positions = tuple(sorted(
            part[0] for part in (boundary[item] for item in row) if len(part) == 1
        ))
        assert len(singleton_positions) == 2
        tait_counts[singleton_positions] += 1
        tait_first.setdefault(singleton_positions, row)
    tait_states = frozenset(tait_counts)

    a_present = ("A",) in support_counts
    s_loops = frozenset((pair, pair) for pair in S if (pair, pair) in support_counts)
    t_loops = frozenset((pair, pair) for pair in T if (pair, pair) in support_counts)
    ss = frozenset(
        kind for kind in support_counts
        if kind != ("A",) and kind[0] in S and kind[1] in S
    )
    st = frozenset(
        kind for kind in support_counts
        if kind != ("A",) and ((kind[0] in S) != (kind[1] in S))
    )
    tt = frozenset(
        kind for kind in support_counts
        if kind != ("A",) and kind[0] in T and kind[1] in T
    )

    # Recover the complete fixed-K fibre and its unique B/X rows independently
    # from the support enumeration, then verify their two six-PM covers.
    target_k = tuple(2 - value for value in fixed.load((fixed.A, fixed.C, fixed.D)))
    k_rows = tuple(
        row for row in combinations_with_replacement(matchings, 3)
        if fixed.load(row) == target_k
    )
    b_pattern = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
    x_pattern = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
    b_rows = tuple(
        row for row in k_rows
        if tuple(sorted(boundary[item] for item in row)) == b_pattern
    )
    x_rows = tuple(
        row for row in k_rows
        if tuple(sorted(boundary[item] for item in row)) == x_pattern
    )
    assert len(b_rows) == len(x_rows) == 1
    fixed_b_cover = tuple(sorted((*b_rows[0], fixed.A, fixed.C, fixed.D), key=lambda m: tuple(sorted(m))))
    fixed_x_cover = tuple(sorted((*x_rows[0], fixed.A, fixed.C, fixed.D), key=lambda m: tuple(sorted(m))))
    assert fixed.load(fixed_b_cover) == fixed.load(fixed_x_cover) == target_two
    fixed_b_type = classify_boundaries(tuple(boundary[item] for item in fixed_b_cover))
    fixed_x_type = classify_boundaries(tuple(boundary[item] for item in fixed_x_cover))
    assert fixed_b_type == tuple(sorted(((1, 5), (2, 4))))
    assert fixed_x_type == tuple(sorted(((1, 3), (4, 5))))

    support = frozenset(support_counts)
    missing_target = TARGET40 - support
    has_full40_skeleton = not missing_target
    carrier_embeds = (
        has_full40_skeleton
        and fixed_b_type in support
        and fixed_x_type in support
    )

    hypothesis_sequence = (
        ("exact_Tait_state_set_S", tait_states == S),
        ("no_A_cover", not a_present),
        ("no_T_loops_or_TT", not t_loops and not tt),
        ("all_40_positive_types", not missing_target),
    )
    first_failed = next(name for name, passed in hypothesis_sequence if not passed)

    result = {
        "order": fixed.N,
        "perfect_matching_count": len(matchings),
        "BF_cover_multisets": total_covers,
        "BF_support_size_including_A": len(support),
        "BF_support": [human(kind) for kind in sorted(support, key=human)],
        "BF_type_multiplicities": {
            human(kind): support_counts[kind]
            for kind in sorted(support_counts, key=human)
        },
        "support_partition": {
            "A": int(a_present),
            "S_loops": len(s_loops),
            "S_S_including_loops": len(ss),
            "S_T": len(st),
            "T_loops": len(t_loops),
            "T_T_including_loops": len(tt),
        },
        "Tait_states": [list(state) for state in sorted(tait_states)],
        "Tait_colouring_counts": {
            "".join(map(str, state)): tait_counts[state]
            for state in sorted(tait_counts)
        },
        "A_cover": None if not a_present else [
            literal_matching(item) for item in first_witness[("A",)]
        ],
        "T_loops": [human(kind) for kind in sorted(t_loops, key=human)],
        "T_T_types_including_loops": [human(kind) for kind in sorted(tt, key=human)],
        "exact_Case_XII_hypothesis_sequence": [
            {"condition": name, "passes": passed}
            for name, passed in hypothesis_sequence
        ],
        "first_failed_condition": first_failed,
        "full40": {
            "target_types_present": len(TARGET40 & support),
            "missing_target_types": [human(kind) for kind in sorted(missing_target, key=human)],
            "actual_full40_witness_skeleton_exists": has_full40_skeleton,
            "fixed_bad_carrier_embeds_in_one_actual_full40_skeleton": carrier_embeds,
            "fixed_B_cover_type": human(fixed_b_type),
            "fixed_X_cover_type": human(fixed_x_type),
            "reason": (
                "choose the two fixed carrier covers in their cells and any actual witness in each other target cell"
                if carrier_embeds else
                "at least one required target cell has no actual cover in this pole"
            ),
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    print("ORDER9_INDIVISIBLE_FULL_BF_CLOSURE_AUDITED")


if __name__ == "__main__":
    main()
