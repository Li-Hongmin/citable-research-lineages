#!/usr/bin/env python3
"""Exhaust the abstract at-most-two-splice occurrence/bit lift to K4.

The six row positions are q,r,B,X,P3,P5.  B and X remain pointwise fixed.
Each nontrivial splice touches two positions and replaces their occurrence
identities by an equal-sum pair.  We enumerate the Note082 shapes in which
both singleton positions are incident with at most two splice edges, all
literal identity partitions, and all distinguished-edge bits consistent
with row load two and pair-sum conservation.

For K4, one perfect matching contains the distinguished edge and the other
two avoid it.  Thus a lift is exactly a three-colouring of identities: bit 1
forces colour 0, bits 0 use colours 1 or 2, every row has two occurrences of
each colour, and every splice preserves the unordered colour pair.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations, product


Q, R, B, X, P3, P5 = range(6)
ACTIVE = (Q, R, P3, P5)
BOUNDARY_SLOTS = ("q35", "r23", "s2", "s3", "s3", "s5")
BOUNDARY_VECTOR = {
    "q35": (1, 1, 0, 1, 0),
    "r23": (1, 0, 0, 1, 1),
    "s2": (0, 1, 0, 0, 0),
    "s3": (0, 0, 1, 0, 0),
    "s5": (0, 0, 0, 0, 1),
}
ODD_BOUNDARIES = tuple(
    bits for bits in product((0, 1), repeat=5) if sum(bits) % 2 == 1
)
SPLICE_EDGES = tuple(
    edge for edge in combinations(ACTIVE, 2) if P3 in edge or P5 in edge
)


def partitions(n):
    labels = [0] * n

    def rec(i, maximum):
        if i == n:
            yield tuple(labels)
            return
        for value in range(maximum + 2):
            labels[i] = value
            yield from rec(i + 1, max(maximum, value))

    labels[0] = 0
    yield from rec(1, 0)


def rows_for_shape(first_edge, second_edge):
    row0 = list(range(6))
    row1 = row0[:]
    for token, position in zip((6, 7), first_edge):
        row1[position] = token
    row2 = row1[:]
    for token, position in zip((8, 9), second_edge):
        row2[position] = token
    return tuple(map(tuple, (row0, row1, row2)))


def identity_row(row, part):
    return tuple(part[token] for token in row)


def valid_pair_replacement(old_tokens, new_tokens, part):
    old = tuple(sorted(part[token] for token in old_tokens))
    new = tuple(sorted(part[token] for token in new_tokens))
    if old == new:
        return True
    # Cancellation forbids a nontrivial equality sharing one occurrence;
    # a repeated pair 2M has no other 0/1 decomposition.
    if set(old) & set(new):
        return False
    if old[0] == old[1] or new[0] == new[1]:
        return False
    return True


def splice_token_pairs(rows, first_edge, second_edge):
    old1 = tuple(rows[0][p] for p in first_edge)
    new1 = tuple(rows[1][p] for p in first_edge)
    old2 = tuple(rows[1][p] for p in second_edge)
    new2 = tuple(rows[2][p] for p in second_edge)
    return ((old1, new1), (old2, new2))


def bit_patterns(part, identity_rows, replacements):
    identity_count = max(part) + 1
    for bits in product((0, 1), repeat=identity_count):
        if sum(bits[i] for i in identity_rows[0]) != 2:
            continue
        if any(
            sum(bits[part[t]] for t in old) != sum(bits[part[t]] for t in new)
            for old, new in replacements
        ):
            continue
        assert all(sum(bits[i] for i in row) == 2 for row in identity_rows)
        yield bits


def boundary_consistent(part, rows):
    labels = {}
    # Initial and target rows lie in the same anchored cell.  Intermediate
    # occurrences may change boundary and therefore receive no slot label.
    for row in (rows[0], rows[2]):
        for token, boundary in zip(row, BOUNDARY_SLOTS):
            identity = part[token]
            if identity in labels and labels[identity] != boundary:
                return False
            labels[identity] = boundary
    return True


def boundary_realisable(part, rows, replacements):
    known = {}
    for row in (rows[0], rows[2]):
        for token, label in zip(row, BOUNDARY_SLOTS):
            identity = part[token]
            vector = BOUNDARY_VECTOR[label]
            if identity in known and known[identity] != vector:
                return False
            known[identity] = vector
    unknown = tuple(i for i in range(max(part) + 1) if i not in known)
    for choices in product(ODD_BOUNDARIES, repeat=len(unknown)):
        values = dict(known)
        values.update(zip(unknown, choices))
        if all(
            tuple(values[part[old[0]]][i] + values[part[old[1]]][i]
                  for i in range(5))
            == tuple(values[part[new[0]]][i] + values[part[new[1]]][i]
                     for i in range(5))
            for old, new in replacements
        ):
            return True
    return False


def incidence_separable(patterns, identity_count):
    """Distinct identities must be distinguishable in some 0/1 coordinate."""
    return all(
        any(bits[left] != bits[right] for bits in patterns)
        for left in range(identity_count)
        for right in range(left + 1, identity_count)
    )


def count_vector(pair, size):
    out = [0] * size
    for identity in pair:
        out[identity] += 1
    return tuple(out)


def forces_direct_singleton_pair_equality(part, identity_rows, replacements):
    """Reject the direct P3+P5=Y+D relation forbidden by overload."""
    size = max(part) + 1
    source = count_vector((identity_rows[0][P3], identity_rows[0][P5]), size)
    target = count_vector((identity_rows[2][P3], identity_rows[2][P5]), size)
    wanted = tuple(a - b for a, b in zip(source, target))
    relations = []
    for old, new in replacements:
        old_ids = tuple(part[t] for t in old)
        new_ids = tuple(part[t] for t in new)
        left = count_vector(old_ids, size)
        right = count_vector(new_ids, size)
        relations.append(tuple(a - b for a, b in zip(left, right)))
    return any(
        all(wanted[i] == a * relations[0][i] + b * relations[1][i]
            for i in range(size))
        for a in range(-2, 3) for b in range(-2, 3)
    )


def has_k4_lift(part, bits, identity_rows, replacements):
    zero_ids = tuple(i for i, bit in enumerate(bits) if bit == 0)
    for phases in product((1, 2), repeat=len(zero_ids)):
        colours = [0] * len(bits)
        for identity, colour in zip(zero_ids, phases):
            colours[identity] = colour
        if any(Counter(colours[i] for i in row) != Counter({0: 2, 1: 2, 2: 2})
               for row in identity_rows):
            continue
        good = True
        for old, new in replacements:
            old_colours = sorted(colours[part[t]] for t in old)
            new_colours = sorted(colours[part[t]] for t in new)
            if old_colours != new_colours:
                good = False
                break
        if good:
            return tuple(colours)
    return None


def direct_compression_lifts(bits, identity_rows, replacements):
    changed = tuple(
        position for position in range(6)
        if identity_rows[0][position] != identity_rows[2][position]
    )
    if len(changed) != 2:
        return False
    size = len(bits)
    old_pair = tuple(identity_rows[0][position] for position in changed)
    new_pair = tuple(identity_rows[2][position] for position in changed)
    wanted = tuple(a - b for a, b in zip(
        count_vector(old_pair, size), count_vector(new_pair, size)
    ))
    relation_vectors = []
    # replacements here already carry identity pairs in the caller record;
    # accept either token-form or identity-form inputs.
    for old, new in replacements:
        old_ids = tuple(old)
        new_ids = tuple(new)
        relation_vectors.append(tuple(a - b for a, b in zip(
            count_vector(old_ids, size), count_vector(new_ids, size)
        )))
    forced = any(
        all(wanted[i] == a * relation_vectors[0][i] + b * relation_vectors[1][i]
            for i in range(size))
        for a in range(-2, 3) for b in range(-2, 3)
    )
    if not forced:
        return False
    zero_ids = tuple(i for i, bit in enumerate(bits) if bit == 0)
    for phases in product((1, 2), repeat=len(zero_ids)):
        colours = [0] * len(bits)
        for identity, colour in zip(zero_ids, phases):
            colours[identity] = colour
        if any(Counter(colours[i] for i in row) != Counter({0: 2, 1: 2, 2: 2})
               for row in (identity_rows[0], identity_rows[2])):
            continue
        if sorted(colours[i] for i in old_pair) == sorted(colours[i] for i in new_pair):
            return True
    return False


def main():
    counts = Counter()
    first_failure = None
    failures = []
    for first_edge in SPLICE_EDGES:
        for second_edge in SPLICE_EDGES:
            if not ({P3, P5} <= (set(first_edge) | set(second_edge))):
                continue
            rows = rows_for_shape(first_edge, second_edge)
            replacements = splice_token_pairs(rows, first_edge, second_edge)
            counts["ordered_shapes"] += 1
            for part in partitions(10):
                identity_rows = tuple(identity_row(row, part) for row in rows)
                if not boundary_consistent(part, rows):
                    continue
                if any(max(Counter(row).values()) > 2 for row in identity_rows):
                    continue
                if any(not valid_pair_replacement(old, new, part)
                       for old, new in replacements):
                    continue
                counts["identity_patterns"] += 1
                if not boundary_realisable(part, rows, replacements):
                    counts["boundary_infeasible"] += 1
                    continue
                counts["boundary_feasible"] += 1
                if forces_direct_singleton_pair_equality(part, identity_rows, replacements):
                    counts["direct_singleton_pair_equality"] += 1
                    continue
                patterns = tuple(bit_patterns(part, identity_rows, replacements))
                if not incidence_separable(patterns, max(part) + 1):
                    counts["incidence_inseparable"] += 1
                    continue
                counts["incidence_separable"] += 1
                for bits in patterns:
                    counts["bit_patterns"] += 1
                    lift = has_k4_lift(part, bits, identity_rows, replacements)
                    if lift is None:
                        counts["failures"] += 1
                        identity_replacements = tuple(
                            (tuple(part[t] for t in old),
                             tuple(part[t] for t in new))
                            for old, new in replacements
                        )
                        compressed = direct_compression_lifts(
                            bits, identity_rows, identity_replacements
                        )
                        counts[
                            "directly_compressible_failures" if compressed
                            else "essential_failures"
                        ] += 1
                        record = {
                                "shape": (first_edge, second_edge),
                                "partition": part,
                                "rows": identity_rows,
                                "replacements": identity_replacements,
                                "bits": bits,
                                "directly_compressible": compressed,
                            }
                        failures.append(record)
                        if first_failure is None:
                            first_failure = record
    print("counts", dict(counts))
    print("first_failure", first_failure)
    for record in failures:
        print("FAIL", record)
    print("TWO_SPLICE_K4_LIFTS_CLASSIFIED")


if __name__ == "__main__":
    main()
