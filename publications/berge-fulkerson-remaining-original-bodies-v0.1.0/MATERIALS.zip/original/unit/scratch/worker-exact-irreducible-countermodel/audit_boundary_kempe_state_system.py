#!/usr/bin/env python3
"""Greatest fixed point of the finite seven-end boundary Kempe system.

The model is necessary for every real degree-three carrier K but deliberately
forgets whether the three bichromatic terminal pairings come from one common
internal copy-multigraph.
"""

from collections import Counter
from itertools import combinations, product
import json


# End indices: 1, 2a, 2b, 3a, 3b, 4, 5.
LABELS = (1, 2, 2, 3, 3, 4, 5)
END_NAMES = ("1", "2a", "2b", "3a", "3b", "4", "5")
DUPLICATE_PAIRS = ((1, 2), (3, 4))
COLOR_PAIRS = ((0, 1), (0, 2), (1, 2))
S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}
B_TYPE = ("ST", (((1, 5), (2, 4)), 2))
X_TYPE = ("ST", (((1, 3), (4, 5)), 3))
B_BLOCK = frozenset((
    B_TYPE,
    ("ST", (((1, 4), (1, 5)), 1)),
    ("SS", (((1, 4), (2, 5)), 2)),
))
X_BLOCK = frozenset((
    X_TYPE,
    ("SS", (((1, 4), (3, 5)), 3)),
    ("ST", (((1, 4), (4, 5)), 4)),
))


def canonical(colours):
    relabel = {}
    following = 0
    output = []
    for colour in colours:
        if colour not in relabel:
            relabel[colour] = following
            following += 1
        output.append(relabel[colour])
    return tuple(output)


def boundary_type(colours):
    classes = []
    for colour in range(3):
        classes.append(tuple(
            LABELS[index] for index, value in enumerate(colours) if value == colour
        ))
    sizes = sorted(map(len, classes))
    if sizes == [1, 1, 5]:
        return "A", "12345"
    assert sizes == [1, 3, 3]
    singleton = next(boundary[0] for boundary in classes if len(boundary) == 1)
    states = tuple(sorted(
        tuple(sorted(set(range(1, 6)) - set(boundary)))
        for boundary in classes if len(boundary) == 3
    ))
    if all(state in S for state in states):
        category = "SS"
    elif all(state in T for state in states):
        category = "TT"
    else:
        category = "ST"
    return category, (states, singleton)


def pairings(vertices):
    vertices = tuple(vertices)
    if not vertices:
        yield tuple()
        return
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        rest = vertices[1:index] + vertices[index + 1:]
        for following in pairings(rest):
            yield tuple(sorted(((first, second), *following)))


def pairing_options(colours, colour_pair):
    endpoints = tuple(
        index for index, colour in enumerate(colours) if colour in colour_pair
    )
    forced = {
        duplicate for duplicate in DUPLICATE_PAIRS
        if {colours[index] for index in duplicate} == set(colour_pair)
    }
    return tuple(
        pairing for pairing in pairings(endpoints) if forced <= set(pairing)
    )


def switch_target(colours, colour_pair, terminal_pair):
    first_colour, second_colour = colour_pair
    result = list(colours)
    for endpoint in terminal_pair:
        if result[endpoint] == first_colour:
            result[endpoint] = second_colour
        elif result[endpoint] == second_colour:
            result[endpoint] = first_colour
        else:
            raise AssertionError((colours, colour_pair, terminal_pair))
    return canonical(result)


def configurations(colours):
    options = tuple(pairing_options(colours, pair) for pair in COLOR_PAIRS)
    output = []
    for selected in product(*options):
        targets = frozenset(
            switch_target(colours, colour_pair, terminal_pair)
            for colour_pair, pairing in zip(COLOR_PAIRS, selected)
            for terminal_pair in pairing
        )
        output.append({"pairings": selected, "targets": targets})
    return tuple(output)


def all_patterns():
    output = set()
    for colours in product(range(3), repeat=7):
        if colours[1] == colours[2] or colours[3] == colours[4]:
            continue
        if sorted(Counter(colours).values()) not in ([1, 1, 5], [1, 3, 3]):
            continue
        output.add(canonical(colours))
    return tuple(sorted(output))


def target_mask(config, index):
    mask = 0
    for target in config["targets"]:
        mask |= 1 << index[target]
    return mask


def minimum_closed_subsystem(allowed, configs, b_patterns, x_patterns):
    """Return a cardinality-minimum closed subsystem meeting B and X.

    This is a direct exhaustive search over at most 2^24 pattern subsets, not
    a SAT encoding.  A selected pattern only needs one local configuration
    whose every component-switch target remains selected.
    """
    ordered = tuple(sorted(allowed))
    index = {pattern: position for position, pattern in enumerate(ordered)}
    all_mask = (1 << len(ordered)) - 1
    b_mask = sum(1 << index[pattern] for pattern in b_patterns)
    x_mask = sum(1 << index[pattern] for pattern in x_patterns)
    options = {}
    for pattern in ordered:
        unique = {}
        for config in configs[pattern]:
            if not config["targets"] <= allowed:
                continue
            mask = target_mask(config, index)
            unique.setdefault(mask, config)
        options[index[pattern]] = tuple(sorted(unique.items()))

    checked = 0
    for size in range(2, len(ordered) + 1):
        for positions in combinations(range(len(ordered)), size):
            mask = sum(1 << position for position in positions)
            if not (mask & b_mask and mask & x_mask):
                continue
            checked += 1
            chosen = {}
            for position in positions:
                viable = next(
                    (config for targets, config in options[position]
                     if not targets & (all_mask ^ mask)),
                    None,
                )
                if viable is None:
                    break
                chosen[ordered[position]] = viable
            else:
                return ordered, mask, chosen, checked
    raise AssertionError("the greatest fixed point contained B and X")


def describe_config(pattern, config):
    pairings_output = []
    transitions = []
    for colour_pair, pairing in zip(COLOR_PAIRS, config["pairings"]):
        named_pairing = [
            [END_NAMES[first], END_NAMES[second]] for first, second in pairing
        ]
        pairings_output.append({
            "colours": list(colour_pair),
            "terminal_pairing": named_pairing,
        })
        for terminal_pair, named in zip(pairing, named_pairing):
            target = switch_target(pattern, colour_pair, terminal_pair)
            transitions.append({
                "colours": list(colour_pair),
                "component": named,
                "target_colours": list(target),
                "target_type": boundary_type(target),
            })
    return {"pairings": pairings_output, "transitions": transitions}


def block_configuration(pattern, configs):
    source_type = boundary_type(pattern)
    block = B_BLOCK if source_type in B_BLOCK else X_BLOCK
    assert source_type in B_BLOCK | X_BLOCK
    return next(
        config for config in configs[pattern]
        if {boundary_type(target) for target in config["targets"]} <= block
    )


def main():
    patterns = all_patterns()
    allowed = {
        pattern for pattern in patterns if boundary_type(pattern)[0] in ("SS", "ST")
    }
    configs = {pattern: configurations(pattern) for pattern in allowed}
    survivors = set(allowed)
    rounds = []
    while True:
        viable = {
            pattern: tuple(
                config for config in configs[pattern]
                if config["targets"] <= survivors
            )
            for pattern in survivors
        }
        following = {pattern for pattern, local in viable.items() if local}
        rounds.append({
            "before": len(survivors),
            "after": len(following),
            "removed": len(survivors - following),
        })
        if following == survivors:
            break
        survivors = following

    b_patterns = tuple(sorted(
        pattern for pattern in survivors
        if boundary_type(pattern) == B_TYPE
    ))
    x_patterns = tuple(sorted(
        pattern for pattern in survivors
        if boundary_type(pattern) == X_TYPE
    ))
    assert len(b_patterns) == 4
    assert len(x_patterns) == 4
    ordered, minimum_mask, chosen, subsets_checked = minimum_closed_subsystem(
        allowed, configs, b_patterns, x_patterns
    )
    minimum_patterns = tuple(
        pattern for position, pattern in enumerate(ordered)
        if minimum_mask & (1 << position)
    )
    assert any(pattern in b_patterns for pattern in minimum_patterns)
    assert any(pattern in x_patterns for pattern in minimum_patterns)
    assert {boundary_type(pattern) for pattern in minimum_patterns} == (
        B_BLOCK | X_BLOCK
    )
    # Use a more informative witness than the lexicographically first one:
    # every chosen configuration stays inside one of the two three-type blocks.
    chosen = {
        pattern: block_configuration(pattern, configs)
        for pattern in minimum_patterns
    }
    assert all(
        chosen[pattern]["targets"] <= set(minimum_patterns)
        for pattern in minimum_patterns
    )
    minimum_witness = [
        {
            "colours": list(pattern),
            "boundary_type": boundary_type(pattern),
            **describe_config(pattern, chosen[pattern]),
        }
        for pattern in minimum_patterns
    ]
    print(json.dumps({
        "all_boundary_patterns": len(patterns),
        "boundary_category_counts": dict(sorted(Counter(
            boundary_type(pattern)[0] for pattern in patterns
        ).items())),
        "allowed_exact_negative_patterns": len(allowed),
        "configuration_count": sum(len(value) for value in configs.values()),
        "fixed_point_rounds": rounds,
        "survivors": len(survivors),
        "B_survivors": b_patterns,
        "X_survivors": x_patterns,
        "minimum_closed_subsystem_size": len(minimum_patterns),
        "minimum_quotient_types": len({
            boundary_type(pattern) for pattern in minimum_patterns
        }),
        "minimum_search_subsets_checked": subsets_checked,
        "quotient_blocks": {
            "B_block": sorted(B_BLOCK),
            "X_block": sorted(X_BLOCK),
        },
        "minimum_closed_subsystem": minimum_witness,
    }, indent=2, sort_keys=True))
    print("BOUNDARY_KEMPE_STATE_SYSTEM_CLASSIFIED")


if __name__ == "__main__":
    main()
