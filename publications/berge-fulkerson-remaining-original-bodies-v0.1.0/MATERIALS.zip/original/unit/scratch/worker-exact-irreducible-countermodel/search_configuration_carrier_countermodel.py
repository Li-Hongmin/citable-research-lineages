#!/usr/bin/env python3
"""Search order-seven carrier configurations from a fixed B projection.

The three base colours have terminal boundaries 135, 234, and 2.  Their
remaining vertex stubs are paired colourwise.  Parallel pairs are retained
as double copies of one edge object; triple copies are rejected.
"""

from collections import Counter, defaultdict
from itertools import product
import json


S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}
B_PATTERN = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
X_PATTERN = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
TERMINAL = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5}
# Base colours Q24, R15, B have these terminal incidences.
TERMINAL_COLOURS = {
    0: {0},
    1: {1, 2},
    2: {0, 1},
    3: {1},
    4: {0},
}


def pairings(vertices):
    vertices = tuple(vertices)
    if not vertices:
        yield tuple()
        return
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        rest = vertices[1:index] + vertices[index + 1:]
        for following in pairings(rest):
            yield tuple(sorted(((min(first, second), max(first, second)), *following)))


def connected(edges):
    adjacency = {v: set() for v in range(7)}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in adjacency[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    return len(seen) == 7


def configurations():
    internal_by_colour = {
        colour: tuple(v for v in range(7) if colour not in TERMINAL_COLOURS.get(v, set()))
        for colour in range(3)
    }
    seen = set()
    for p0 in pairings(internal_by_colour[0]):
        for p1 in pairings(internal_by_colour[1]):
            for p2 in pairings(internal_by_colour[2]):
                edges = tuple(sorted((*p0, *p1, *p2)))
                multiplicity = Counter(edges)
                if max(multiplicity.values()) > 2:
                    continue
                if edges in seen:
                    continue
                seen.add(edges)
                yield edges


def negative_category(pattern):
    sizes = sorted(map(len, pattern))
    if sizes == [1, 1, 5]:
        return "A"
    assert sizes == [1, 3, 3]
    states = tuple(sorted(
        tuple(sorted(set(range(1, 6)) - set(boundary)))
        for boundary in pattern if len(boundary) == 3
    ))
    return "TT" if all(state in T for state in states) else None


def colourings(edges):
    used = [set() for _ in range(7)]
    colours = [-1] * len(edges)
    output = []

    def rec(index):
        if index == len(edges):
            boundary = {colour: [] for colour in range(3)}
            objects = {colour: set() for colour in range(3)}
            for edge_index, (edge, colour) in enumerate(zip(edges, colours)):
                objects[colour].add(edge)
            for vertex, terminal in TERMINAL.items():
                missing = tuple(c for c in range(3) if c not in used[vertex])
                if terminal in (2, 3):
                    assert len(missing) == 2
                    for colour in missing:
                        boundary[colour].append(terminal)
                        objects[colour].add(("s", terminal))
                else:
                    assert len(missing) == 1
                    colour = missing[0]
                    boundary[colour].append(terminal)
                    objects[colour].add(("s", terminal))
            boundary = {c: tuple(sorted(values)) for c, values in boundary.items()}
            output.append({
                "boundary": boundary,
                "pattern": tuple(sorted(boundary.values())),
                "objects": {c: frozenset(values) for c, values in objects.items()},
            })
            return
        u, v = edges[index]
        options = range(1) if index == 0 else range(3)
        for colour in options:
            if colour in used[u] or colour in used[v]:
                continue
            colours[index] = colour
            used[u].add(colour)
            used[v].add(colour)
            rec(index + 1)
            used[u].remove(colour)
            used[v].remove(colour)
            colours[index] = -1

    rec(0)
    return output


def fixed_half_owners(edges):
    multiplicity = Counter(edges)
    single_edges = tuple(edge for edge, count in multiplicity.items() if count == 1)
    incident_objects = defaultdict(list)
    for edge, count in multiplicity.items():
        u, v = edge
        incident_objects[u].append((edge, count))
        incident_objects[v].append((edge, count))
    terminal_owner = {1: 0, 4: 1, 5: 2}
    for vertex, terminal in TERMINAL.items():
        count = 2 if terminal in (2, 3) else 1
        incident_objects[vertex].append((("s", terminal), count))
    output = []
    for values in product(range(3), repeat=len(single_edges)):
        owner = dict(zip(single_edges, values))
        owner.update({("s", terminal): value for terminal, value in terminal_owner.items()})
        good = True
        for vertex in range(7):
            local = incident_objects[vertex]
            if sorted(count for _, count in local) == [1, 1, 1]:
                if {owner[obj] for obj, _ in local} != {0, 1, 2}:
                    good = False
                    break
            else:
                assert sorted(count for _, count in local) == [1, 2]
        if good:
            output.append(owner)
    return tuple(output)


def printable_object(obj):
    if obj[0] == "s":
        return f"s{obj[1]}"
    return f"{obj[0]}-{obj[1]}"


def main():
    counts = Counter({
        "configurations": 0, "connected": 0, "disconnected": 0,
        "has_X": 0, "exact_negative": 0, "countermodels": 0,
    })
    negative_profiles = Counter()
    first = None
    for edges in configurations():
        counts["configurations"] += 1
        counts["connected" if connected(edges) else "disconnected"] += 1
        rows = colourings(edges)
        patterns = {row["pattern"] for row in rows}
        b_matchings = {
            row["objects"][colour]
            for row in rows if row["pattern"] == B_PATTERN
            for colour in range(3) if row["boundary"][colour] == (2,)
        }
        x_matchings = {
            row["objects"][colour]
            for row in rows if row["pattern"] == X_PATTERN
            for colour in range(3) if row["boundary"][colour] == (3,)
        }
        assert b_matchings  # the generating colouring is a B projection
        if not x_matchings:
            continue
        counts["has_X"] += 1
        forbidden = tuple(sorted(
            (pattern, negative_category(pattern))
            for pattern in patterns if negative_category(pattern) is not None
        ))
        negative_profiles[tuple(sorted({category for _, category in forbidden}))] += 1
        if forbidden:
            continue
        counts["exact_negative"] += 1
        for owner in fixed_half_owners(edges):
            f = frozenset(
                obj for obj, value in owner.items() if value in (0, 1)
            )
            if not all(b & x & f for b in b_matchings for x in x_matchings):
                continue
            counts["countermodels"] += 1
            if first is None:
                first = {
                    "copy_edges": tuple(tuple(edge) for edge in edges),
                    "object_multiplicity": tuple(
                        (tuple(edge), count) for edge, count in sorted(Counter(edges).items())
                    ),
                    "F": tuple(sorted(printable_object(obj) for obj in f)),
                    "B": tuple(sorted(
                        tuple(sorted(printable_object(obj) for obj in matching))
                        for matching in b_matchings
                    )),
                    "X": tuple(sorted(
                        tuple(sorted(printable_object(obj) for obj in matching))
                        for matching in x_matchings
                    )),
                    "patterns": tuple(sorted(patterns)),
                }
    assert counts == Counter({
        "configurations": 123,
        "connected": 98,
        "disconnected": 25,
        "has_X": 40,
        "exact_negative": 0,
        "countermodels": 0,
    })
    print(json.dumps({
        "counts": dict(counts),
        "negative_profiles_among_BX_carriers": {
            "+".join(profile): count for profile, count in sorted(negative_profiles.items())
        },
        "first": first,
    }, indent=2, sort_keys=True))
    print("CONFIGURATION_CARRIER_COUNTERMODEL_SCAN_OK")


if __name__ == "__main__":
    main()
