#!/usr/bin/env python3
"""Direct global pairing synthesis for the nineteen Note-101 signatures.

The five terminal local types are fixed pointwise.  Six internal trivalent
types and a simple connected pairing of all proper stubs are synthesized in
one SAT call.  Paired stubs must have identical occurrence-bit columns, so
all nineteen selected signatures become perfect matchings of one cubic
five-pole.  The complete graph-induced PM closure is then enumerated once.
There is no graph-order scan and no CEGAR loop.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path

from z3 import And, Bool, Implies, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
LOCAL_EVALUATOR = (
    HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
)
BUNDLED_EVALUATOR = HERE / "synthesize_exact40_joint_pb.py"
EVALUATOR_PATH = LOCAL_EVALUATOR if LOCAL_EVALUATOR.exists() else BUNDLED_EVALUATOR
SPEC = importlib.util.spec_from_file_location("note101_pairing_evaluator", EVALUATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
EVALUATOR = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = EVALUATOR
SPEC.loader.exec_module(EVALUATOR)


N = 11
TERMINALS = tuple(range(5))
INTERNALS = tuple(range(5, N))
INCIDENCES = (0, 1, 2)
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(combinations(TERMINALS, 2)) - S)
TOKENS = (
    "A", "B", "C", "D", "P3", "P5", "X", "Y", "p24_2", "p24_4",
    "p25_2", "q13", "q14", "q24", "q25", "q25b", "q35", "r23", "r34",
)
TERMINAL_SIGNATURES = {
    "A": (2, 1, 0, 0, 1), "B": (0, 2, 0, 1, 0),
    "C": (1, 0, 1, 2, 1), "D": (0, 0, 0, 1, 2),
    "P3": (1, 0, 2, 1, 1), "P5": (1, 1, 0, 0, 2),
    "X": (0, 0, 2, 0, 0), "Y": (1, 1, 2, 0, 0),
    "p24_2": (1, 2, 1, 0, 1), "p24_4": (1, 0, 0, 2, 1),
    "p25_2": (1, 2, 1, 1, 1),
    "q13": (1, 2, 1, 2, 2), "q14": (1, 2, 2, 1, 2),
    "q24": (2, 1, 2, 1, 2), "q25": (2, 0, 2, 2, 1),
    "q25b": (2, 1, 2, 2, 1), "q35": (2, 2, 1, 2, 1),
    "r23": (2, 1, 1, 2, 2), "r34": (2, 2, 1, 0, 2),
}
ROWS = (
    ("r23", "B", "X", "q13", "A", "P3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "P5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("q25b", "r34", "B", "Y", "C", "D"),
)


def boundary_for_token(token):
    return frozenset(v for v in TERMINALS if TERMINAL_SIGNATURES[token][v] == 2)


def build_solver():
    stubs = tuple(
        (v, incidence)
        for v in range(N)
        for incidence in ((0, 1) if v in TERMINALS else INCIDENCES)
    )
    z = {
        (token, v, incidence): Bool(f"z_{token}_{v}_{incidence}")
        for token in TOKENS for v in range(N) for incidence in INCIDENCES
    }
    pair = {
        (left, right): Bool(
            f"pair_{left[0]}_{left[1]}__{right[0]}_{right[1]}"
        )
        for left_index, left in enumerate(stubs)
        for right in stubs[left_index + 1:]
        if left[0] != right[0]
    }
    solver = Solver()

    for token in TOKENS:
        for v in range(N):
            solver.add(PbEq(
                [(z[(token, v, incidence)], 1) for incidence in INCIDENCES], 1
            ))
            if v in TERMINALS:
                fixed = TERMINAL_SIGNATURES[token][v]
                solver.add(z[(token, v, fixed)])

    # Each designated BF row locally uses every incidence exactly twice.
    for row in ROWS:
        counts = Counter(row)
        for v in INTERNALS:
            for incidence in INCIDENCES:
                solver.add(PbEq([
                    (z[(token, v, incidence)], multiplicity)
                    for token, multiplicity in counts.items()
                ], 2))

    incident_pairs = defaultdict(list)
    vertex_pair_pairs = defaultdict(list)
    for (left, right), variable in pair.items():
        incident_pairs[left].append(variable)
        incident_pairs[right].append(variable)
        vertex_pair_pairs[tuple(sorted((left[0], right[0])))].append(variable)
        for token in TOKENS:
            solver.add(Implies(
                variable,
                z[(token, left[0], left[1])] == z[(token, right[0], right[1])],
            ))
    for stub in stubs:
        solver.add(PbEq([(variable, 1) for variable in incident_pairs[stub]], 1))
    for variables in vertex_pair_pairs.values():
        solver.add(PbLe([(variable, 1) for variable in variables], 1))

    # Layered reachability makes the paired simple graph connected.
    edge = {
        uv: Or(*variables) for uv, variables in vertex_pair_pairs.items()
    }
    reach = {
        (v, step): Bool(f"reach_{v}_{step}")
        for v in range(N) for step in range(N)
    }
    for v in range(N):
        solver.add(reach[(v, 0)] if v == 0 else Not(reach[(v, 0)]))
    for step in range(1, N):
        for v in range(N):
            arrivals = [reach[(v, step - 1)]]
            for u in range(N):
                if u == v:
                    continue
                arrivals.append(And(
                    reach[(u, step - 1)], edge[tuple(sorted((u, v)))]
                ))
            solver.add(reach[(v, step)] == Or(*arrivals))
    solver.add(And(*(reach[(v, N - 1)] for v in range(N))))
    return solver, z, pair, stubs


def load(row, edge_count):
    answer = [0] * edge_count
    for matching in row:
        for edge in matching:
            answer[edge] += 1
    return tuple(answer)


def sep(companion, source, target):
    companion, source, target = map(frozenset, (companion, source, target))
    return (target - source) <= companion and not (companion & (source - target))


def endpoint_audit(classes, fixed, target_y, target_d, object_count):
    target_load = tuple(2 - value for value in load(fixed, object_count))
    state35 = (2, 4)
    decompositions = tuple(
        row for row in product(
            classes[EVALUATOR.boundary_for_pair(state35)],
            classes[frozenset((2,))], classes[frozenset((4,))],
        )
        if load(row, object_count) == target_load
    )
    projection3 = {row[1] for row in decompositions}
    projection5 = {row[2] for row in decompositions}

    def status(projection, target):
        entry = target in projection
        square = any(
            source != target
            and any(sep(companion, source, target) for companion in fixed)
            for source in projection
        )
        return {"literal_entry": entry, "strict_square": square,
                "intersection_nonempty": entry or square}

    return {
        "state35_decompositions": len(decompositions),
        "Y": status(projection3, target_y),
        "D": status(projection5, target_d),
    }


def main():
    solver, z, pair, stubs = build_solver()
    solver.set(timeout=180_000)
    status = solver.check()
    if status == unknown:
        print(json.dumps({"status": "unknown", "reason": solver.reason_unknown()}))
        print("NOTE101_GLOBAL_PAIRING_UNKNOWN")
        return
    if status != sat:
        print(json.dumps({"status": "unsat", "order": N}))
        print("NOTE101_GLOBAL_PAIRING_UNSAT")
        return
    model = solver.model()
    paired = tuple(
        (left, right) for (left, right), variable in pair.items()
        if bool(model.eval(variable, model_completion=True))
    )
    proper_edges = tuple(sorted(tuple(sorted((left[0], right[0]))) for left, right in paired))
    assert len(proper_edges) == len(set(proper_edges)) == 14
    edge_index = {edge: index for index, edge in enumerate(proper_edges)}

    selected = {}
    for token in TOKENS:
        chosen = []
        for left, right in paired:
            if bool(model.eval(z[(token, left[0], left[1])], model_completion=True)):
                chosen.append(edge_index[tuple(sorted((left[0], right[0])))])
        chosen.extend(len(proper_edges) + v for v in boundary_for_token(token))
        selected[token] = tuple(sorted(chosen))

    # Directly verify the selected signatures are perfect matchings and rows.
    for matching in selected.values():
        covered = Counter()
        for item in matching:
            if item < len(proper_edges):
                covered.update(proper_edges[item])
            else:
                covered[item - len(proper_edges)] += 1
        assert all(covered[v] == 1 for v in range(N))
    assert all(load(tuple(selected[token] for token in row), len(proper_edges) + 5)
               == (2,) * (len(proper_edges) + 5) for row in ROWS)

    full = EVALUATOR.evaluate(N, proper_edges)
    full_endpoint = endpoint_audit(
        full["classes"],
        (selected["r23"], selected["B"], selected["X"]),
        selected["Y"], selected["D"], len(proper_edges) + 5,
    )
    support = full["support"]
    ss = {kind for kind in support if kind[0] in S and kind[1] in S}
    st = {kind for kind in support if (kind[0] in S) != (kind[1] in S)}
    tt = {kind for kind in support if kind[0] in T and kind[1] in T}
    endpoint_empty = not (
        full_endpoint["Y"]["intersection_nonempty"]
        or full_endpoint["D"]["intersection_nonempty"]
    )
    exact_case_xii = (
        full["tait_states"] == S and len(ss) == 15 and len(st) == 25
        and not tt and full["a_witness"] is None
    )
    real_counterexample = exact_case_xii and endpoint_empty
    output = {
        "status": "sat_simple_connected_global_pairing",
        "order": N,
        "proper_edges": proper_edges,
        "selected_matching_identities": len(set(selected.values())),
        "complete_PM_count": len(full["matchings"]),
        "complete_tait_states": tuple(sorted(full["tait_states"])),
        "complete_support_profile": {
            "SS": len(ss), "ST": len(st), "TT": len(tt),
            "A": full["a_witness"] is not None,
        },
        "complete_endpoint_audit": full_endpoint,
        "exact_case_xii": exact_case_xii,
        "real_note082_counterexample": real_counterexample,
        "first_failure_layer": (
            None if real_counterexample else
            "complete_PM_closure_A" if full["a_witness"] is not None else
            "complete_PM_closure_TT" if tt else
            "complete_PM_closure_endpoint_entry_or_square" if not endpoint_empty else
            "complete_case_xii_positive_support"
        ),
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    print(
        "NOTE101_GLOBAL_PAIRING_REAL_COUNTEREXAMPLE"
        if real_counterexample else "NOTE101_GLOBAL_PAIRING_BOUNDARY_FOUND"
    )


if __name__ == "__main__":
    main()
