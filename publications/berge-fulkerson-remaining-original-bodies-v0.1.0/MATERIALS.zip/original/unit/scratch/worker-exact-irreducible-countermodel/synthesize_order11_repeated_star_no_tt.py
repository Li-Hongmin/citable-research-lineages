#!/usr/bin/env python3
"""Directed order-11 synthesis for a repeated-star overload pole with no TT.

This is a fixed-order CEGAR search, not a graph census.  Four literal BF rows,
their six singleton identities, and the three overload targets are encoded in
one cubic-pole SAT object.  Complete perfect-matching closure is enumerated
only for each SAT candidate, and sound graph clauses remove candidates having
a forbidden Tait state or a T--T BF cover.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from collections import Counter, deque
from itertools import combinations
from pathlib import Path

from z3 import And, Bool, Implies, Not, Or, PbEq, PbGe, PbLe, Solver, unknown


HERE = Path(__file__).resolve().parent
LOCAL_EVALUATOR = (
    HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
)
BUNDLED_EVALUATOR = HERE / "synthesize_exact40_joint_pb.py"
EVALUATOR_PATH = LOCAL_EVALUATOR if LOCAL_EVALUATOR.exists() else BUNDLED_EVALUATOR
SPEC = importlib.util.spec_from_file_location("order11_no_tt_evaluator", EVALUATOR_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(EVALUATOR_PATH)
EVALUATOR = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = EVALUATOR
SPEC.loader.exec_module(EVALUATOR)


N = 11
TERMINALS = tuple(range(5))
SINGLETON_BOUNDARY = {
    "A": (0,), "B": (1,), "C": (3,), "D": (4,), "X": (2,), "Y": (2,),
}
TRIPLE_BOUNDARY = {
    "q13": (1, 3, 4), "r45": (0, 1, 2),
    "q14": (1, 2, 4), "r23": (0, 3, 4),
    "q24": (0, 2, 4), "r15": (1, 2, 3),
    "q25": (0, 2, 3), "r34": (0, 1, 4),
}
BOUNDARY = SINGLETON_BOUNDARY | TRIPLE_BOUNDARY
ROWS = (
    ("q13", "r45", "A", "X", "C", "D"),
    ("q14", "r23", "A", "B", "X", "C"),
    ("q24", "r15", "A", "B", "C", "D"),
    ("q25", "r34", "B", "Y", "C", "D"),
)
TARGETS = (
    ("B", "D", "X", "Y"),
    ("A", "C", "X", "Y"),
    ("A", "B", "D", "Y"),
)
SELECTED_T_PAIRS = (
    ("A", "B"), ("A", "D"), ("B", "X"), ("B", "Y"),
    ("C", "X"), ("C", "Y"), ("C", "D"),
)
TT_TYPES = frozenset(
    tuple(sorted((left, right)))
    for left in EVALUATOR.T for right in EVALUATOR.T
)


def structural_bad_cuts(chosen: set[tuple[int, int]]):
    bad = []
    for mask in range(1 << (N - 1)):
        if mask == (1 << (N - 1)) - 1:
            continue
        side = {0}
        side.update(i + 1 for i in range(N - 1) if mask & (1 << i))
        other = set(range(N)) - side
        cut = tuple(e for e in chosen if (e[0] in side) != (e[1] in side))
        allowed_two = (
            (len(side) == 1 and next(iter(side)) < 5)
            or (len(other) == 1 and next(iter(other)) < 5)
            or (len(side) == 2 and side <= set(TERMINALS))
            or (len(other) == 2 and other <= set(TERMINALS))
        )
        threshold = 2 if allowed_two else 3
        if len(cut) < threshold:
            bad.append((frozenset(side), threshold))
    return tuple(bad)


def graph_girth(chosen: set[tuple[int, int]]):
    adjacency = {v: [] for v in range(N)}
    for u, v in chosen:
        adjacency[u].append(v)
        adjacency[v].append(u)
    best = N + 1
    for removed in chosen:
        start, finish = removed
        queue = deque([(start, 0)])
        seen = {start}
        while queue:
            vertex, distance = queue.popleft()
            if vertex == finish:
                best = min(best, distance + 1)
                break
            for neighbour in adjacency[vertex]:
                edge = tuple(sorted((vertex, neighbour)))
                if edge == removed or neighbour in seen:
                    continue
                seen.add(neighbour)
                queue.append((neighbour, distance + 1))
    return best


def build_solver(selected_t_pairs=SELECTED_T_PAIRS):
    edges = tuple(combinations(range(N), 2))
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    y = {
        (name, edge): Bool(f"y_{name}_{edge[0]}_{edge[1]}")
        for name in BOUNDARY for edge in edges
    }
    solver = Solver()

    for vertex in range(N):
        solver.add(PbEq(
            [(x[edge], 1) for edge in edges if vertex in edge],
            2 if vertex in TERMINALS else 3,
        ))
    solver.add(x[(5, 6)])

    for vertices in combinations(range(N), 3):
        solver.add(PbLe([(x[edge], 1) for edge in combinations(vertices, 2)], 2))
    for a, b, c, d in combinations(range(N), 4):
        for cycle in (
            ((a, b), (b, c), (c, d), (a, d)),
            ((a, b), (b, d), (c, d), (a, c)),
            ((a, c), (b, c), (b, d), (a, d)),
        ):
            solver.add(PbLe([(x[tuple(sorted(edge))], 1) for edge in cycle], 3))

    for name, matching_boundary in BOUNDARY.items():
        boundary_set = set(matching_boundary)
        for edge in edges:
            solver.add(Implies(y[(name, edge)], x[edge]))
        for vertex in range(N):
            solver.add(PbEq(
                [(y[(name, edge)], 1) for edge in edges if vertex in edge],
                0 if vertex in boundary_set else 1,
            ))

    solver.add(Or(*(y[("X", edge)] != y[("Y", edge)] for edge in edges)))
    for row in ROWS:
        counts = Counter(row)
        for edge in edges:
            load = [(y[(name, edge)], multiplicity) for name, multiplicity in counts.items()]
            solver.add(PbLe(load, 2))
            solver.add(Or(Not(x[edge]), PbEq(load, 2)))

    for target in TARGETS:
        solver.add(Or(*(
            PbGe([(y[(name, edge)], 1) for name in target], 3)
            for edge in edges
        )))

    # Necessary consequences of no T-loop for the seven selected singleton
    # pairs.  Complete no-T-loop and no-T--T support is checked lazily below.
    for first, second in selected_t_pairs:
        solver.add(Or(*(
            And(y[(first, edge)], y[(second, edge)]) for edge in edges
        )))
    return solver, x, y, edges


def run(max_rounds: int, timeout_ms: int, json_path: Path | None):
    solver, x, y, edges = build_solver()
    rounds = []
    started = time.time()
    for round_number in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {
                "status": "unknown", "reason": solver.reason_unknown(),
                "round": round_number, "elapsed_s": time.time() - started,
            }
            marker = "ORDER11_REPEATED_STAR_NO_TT_UNKNOWN"
            break
        if str(status) != "sat":
            payload = {
                "status": "unsat", "rounds": rounds,
                "elapsed_s": time.time() - started,
            }
            marker = "ORDER11_REPEATED_STAR_NO_TT_UNSAT"
            break

        model = solver.model()
        chosen = {edge for edge in edges if bool(model.eval(x[edge], model_completion=True))}
        bad = []
        violations = structural_bad_cuts(chosen)
        for side, threshold in violations:
            solver.add(PbGe([
                (x[edge], 1) for edge in edges
                if (edge[0] in side) != (edge[1] in side)
            ], threshold))
        if violations:
            bad.append({"kind": "structural_cuts", "count": len(violations)})

        proper_edges = tuple(sorted(chosen))
        evaluation = EVALUATOR.evaluate(N, proper_edges)
        forbidden_tait = evaluation["tait_states"] & EVALUATOR.T
        pair_clauses = 0
        seen_unions = set()
        for state in sorted(forbidden_tait):
            for witness in evaluation["tait_witnesses"][state]:
                union = EVALUATOR.tait_pair_union(witness, proper_edges)
                key = tuple(sorted(union))
                if key in seen_unions:
                    continue
                seen_unions.add(key)
                solver.add(EVALUATOR.clause_for_union(x, edges, union))
                pair_clauses += 1
        if forbidden_tait:
            bad.append({
                "kind": "T_loop", "states": tuple(sorted(forbidden_tait)),
                "pair_clauses": pair_clauses,
            })

        forbidden_tt = evaluation["support"] & TT_TYPES
        if forbidden_tt:
            kind = min(forbidden_tt, key=str)
            union = EVALUATOR.forbidden_union(evaluation["witnesses"][kind], proper_edges)
            assert union == frozenset(proper_edges)
            solver.add(EVALUATOR.clause_for_union(x, edges, union))
            bad.append({
                "kind": "T_T", "types": len(forbidden_tt),
                "first_type": str(kind),
            })

        rounds.append({
            "round": round_number,
            "bad": bad,
            "matching_count": len(evaluation["matchings"]),
            "tait_states": tuple(sorted(evaluation["tait_states"])),
            "tt_types": len(forbidden_tt),
        })
        print(json.dumps(rounds[-1], sort_keys=True), flush=True)

        if not bad:
            named_matchings = {
                name: tuple(sorted(
                    edge for edge in proper_edges
                    if bool(model.eval(y[(name, edge)], model_completion=True))
                ))
                for name in BOUNDARY
            }
            overloads = {
                "".join(target): tuple(
                    edge for edge in proper_edges
                    if sum(edge in named_matchings[name] for name in target) >= 3
                )
                for target in TARGETS
            }
            payload = {
                "status": "sat_real_pole",
                "proper_edges": proper_edges,
                "girth": graph_girth(chosen),
                "matching_count": len(evaluation["matchings"]),
                "tait_states": tuple(sorted(evaluation["tait_states"])),
                "tt_types": 0,
                "has_A": evaluation["a_witness"] is not None,
                "named_matchings": named_matchings,
                "target_overloads": overloads,
                "rounds": rounds,
                "elapsed_s": time.time() - started,
            }
            marker = "ORDER11_REPEATED_STAR_NO_TT_REAL_POLE_FOUND"
            break
    else:
        payload = {
            "status": "round_limit", "rounds": rounds,
            "elapsed_s": time.time() - started,
        }
        marker = "ORDER11_REPEATED_STAR_NO_TT_ROUND_LIMIT"

    if json_path:
        json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print(marker)
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-rounds", type=int, default=500)
    parser.add_argument("--timeout-ms", type=int, default=300_000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    run(args.max_rounds, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
