#!/usr/bin/env python3
"""Classify repeated-star selections in the fixed Note-024 order-13 pole.

The program is pure standard library.  It enumerates the complete 37-PM
closure, indexes the four literal pivot-row families, streams their joins,
and tests only the two Note-093 carriers and Note-082 fibres requested by
the bounded pulse.
"""

from collections import Counter, defaultdict
from itertools import product


N = 13
TERMINALS = frozenset(range(5))
PROPER = (
    (0, 8), (0, 11), (1, 7), (1, 9), (2, 9), (2, 12),
    (3, 10), (3, 12), (4, 10), (4, 11), (5, 7), (5, 8),
    (5, 9), (6, 8), (6, 11), (6, 12), (7, 10),
)
OBJECTS = tuple(PROPER) + tuple(f"s{i}" for i in range(5))
OBJECT_SET = frozenset(OBJECTS)


def enumerate_perfect_matchings():
    adjacency = {v: [] for v in range(N)}
    for edge in PROPER:
        u, v = edge
        adjacency[u].append((v, edge))
        adjacency[v].append((u, edge))
    used = [False] * N
    chosen = []
    output = set()

    def rec():
        try:
            vertex = next(v for v in range(N) if not used[v])
        except StopIteration:
            output.add(frozenset(chosen))
            return
        used[vertex] = True
        if vertex in TERMINALS:
            chosen.append(f"s{vertex}")
            rec()
            chosen.pop()
        for neighbour, edge in adjacency[vertex]:
            if used[neighbour]:
                continue
            used[neighbour] = True
            chosen.append(edge)
            rec()
            chosen.pop()
            used[neighbour] = False
        used[vertex] = False

    rec()
    return tuple(sorted(output, key=lambda m: tuple(sorted(map(str, m)))))


def boundary(matching):
    return tuple(i + 1 for i in range(5) if f"s{i}" in matching)


def complement_state(state):
    return tuple(sorted(set(range(1, 6)) - set(state)))


def load(matchings):
    return Counter(edge for matching in matchings for edge in matching)


def is_double_cover(row):
    counts = load(row)
    return all(counts[edge] == 2 for edge in OBJECTS)


def complement_load(fixed):
    used = load(fixed)
    result = {edge: 2 - used[edge] for edge in OBJECTS}
    assert all(value in (0, 1, 2) for value in result.values())
    return result


def has_load(row, target_load):
    counts = load(row)
    return all(counts[edge] == target_load[edge] for edge in OBJECTS)


def sep(companion, source, target):
    return (target - source) <= companion and not (companion & (source - target))


def signed_matching(plus_a, plus_b, minus_c, family_set):
    values = Counter(plus_a)
    values.update(plus_b)
    values.subtract(minus_c)
    if any(values[edge] not in (0, 1) for edge in OBJECTS):
        return None
    result = frozenset(edge for edge in OBJECTS if values[edge] == 1)
    return result if result in family_set else None


def cell_rows(classes, first_state, second_state, singleton_classes):
    groups = (
        classes[complement_state(first_state)],
        classes[complement_state(second_state)],
        *(classes[(i,)] for i in singleton_classes),
    )
    return tuple(row for row in product(*groups) if is_double_cover(row))


def carrier_decompositions(classes, carrier, i, j):
    rows = product(
        classes[complement_state((i, j))],
        classes[(i,)],
        classes[(j,)],
    )
    return tuple(row for row in rows if has_load(row, carrier))


def projection_intersection(classes, fixed, decomps, source_index, target):
    projection = {row[source_index] for row in decomps}
    target_class = boundary(target)
    sign_set = {target}
    reasons = defaultdict(list)
    for candidate in classes[target_class]:
        for index, companion in enumerate(fixed):
            if sep(companion, candidate, target):
                sign_set.add(candidate)
                reasons[candidate].append(f"fixed_sep:{index}")
    reasons[target].append("target_entry")
    intersection = projection & sign_set
    return projection, sign_set, {
        matching: tuple(reasons[matching]) for matching in intersection
    }


def splice(row, source_position, target, companion_position, family_set):
    if source_position == companion_position:
        return None
    updated = signed_matching(
        row[companion_position], row[source_position], target, family_set
    )
    if updated is None:
        return None
    result = list(row)
    result[source_position] = target
    result[companion_position] = updated
    assert load(row) == load(result)
    return tuple(result)


def first_sequential_fibre(row, targets, literal_fixed_positions, family_set):
    original = tuple(row)
    source_positions = (4, 5)
    for order in ((0, 1), (1, 0)):
        first, second = order
        first_position = source_positions[first]
        second_position = source_positions[second]
        if row[first_position] == targets[first]:
            first_steps = [(tuple(row), "already")]
        else:
            first_steps = []
            for companion in range(6):
                changed = splice(
                    row, first_position, targets[first], companion, family_set
                )
                if changed is not None:
                    first_steps.append((changed, companion))
        for middle, first_companion in first_steps:
            if middle[second_position] == targets[second]:
                second_steps = [(middle, "already")]
            else:
                second_steps = []
                for companion in range(6):
                    changed = splice(
                        middle,
                        second_position,
                        targets[second],
                        companion,
                        family_set,
                    )
                    if changed is not None:
                        second_steps.append((changed, companion))
            for final, second_companion in second_steps:
                if any(final[p] != original[p] for p in literal_fixed_positions):
                    continue
                return {
                    "kind": "sequential",
                    "order": order,
                    "first_companion": first_companion,
                    "second_companion": second_companion,
                    "middle": middle,
                    "final": final,
                }
    return None


def first_forced_fibre(row, targets, family_set):
    source_positions = (4, 5)
    for first, other in ((0, 1), (1, 0)):
        intermediate = signed_matching(
            targets[first], targets[other], row[source_positions[other]], family_set
        )
        if intermediate is None:
            continue
        for triple_position in (0, 1):
            updated_triple = signed_matching(
                row[triple_position],
                row[source_positions[first]],
                intermediate,
                family_set,
            )
            if updated_triple is not None:
                return {
                    "kind": "forced",
                    "intermediate_for_source": first,
                    "triple_position": triple_position,
                    "intermediate": intermediate,
                    "updated_triple": updated_triple,
                }
    return None


def dependent_fibre(fixed, decomps, targets, family_set):
    for q, p_first, p_second in decomps:
        row = (q, fixed[0], fixed[1], fixed[2], p_first, p_second)
        witness = first_sequential_fibre(row, targets, (2, 3), family_set)
        if witness is None:
            witness = first_forced_fibre(row, targets, family_set)
        if witness is not None:
            return row, witness
    return None


def main():
    family = enumerate_perfect_matchings()
    family_set = set(family)
    assert len(family) == 37
    ids = {matching: index for index, matching in enumerate(family)}
    classes = defaultdict(list)
    for matching in family:
        classes[boundary(matching)].append(matching)

    # Tuple positions follow the literal names displayed below.
    r1 = cell_rows(classes, (1, 3), (4, 5), (1, 3, 4, 5))  # q13,r45,A,X,C,D
    r2 = cell_rows(classes, (1, 4), (2, 3), (1, 2, 3, 4))  # q14,r23,A,B,X,C
    r3 = cell_rows(classes, (2, 4), (1, 5), (1, 2, 4, 5))  # q24,r15,A,B,C,D
    r4 = cell_rows(classes, (2, 5), (3, 4), (2, 3, 4, 5))  # q25,r34,B,Y,C,D

    r1_by_acd = defaultdict(list)
    for row in r1:
        r1_by_acd[(row[2], row[4], row[5])].append(row)
    r2_by_abcx = defaultdict(list)
    for row in r2:
        r2_by_abcx[(row[2], row[3], row[5], row[4])].append(row)
    r4_by_bcd = defaultdict(list)
    for row in r4:
        r4_by_bcd[(row[2], row[4], row[5])].append(row)

    totals = Counter()
    join_keys = (
        "r3_r1_pairs",
        "r3_r1_r2_triples",
        "r3_r1_r2_r4_quadruples",
        "x_equals_y",
        "x_not_equals_y",
    )
    join_counts = Counter({key: 0 for key in join_keys})
    first_four_empty = None
    first_dependent_empty = None
    first_nonvacuous = None
    first_positive_dependent = None

    for row3 in r3:
        q24, r15, a, b, c, d = row3
        for row1 in r1_by_acd.get((a, c, d), ()):
            join_counts["r3_r1_pairs"] += 1
            q13, r45, _, x, _, _ = row1
            for row2 in r2_by_abcx.get((a, b, c, x), ()):
                join_counts["r3_r1_r2_triples"] += 1
                q14, r23, _, _, _, _ = row2
                for row4 in r4_by_bcd.get((b, c, d), ()):
                    join_counts["r3_r1_r2_r4_quadruples"] += 1
                    q25, r34, _, y, _, _ = row4
                    if x == y:
                        join_counts["x_equals_y"] += 1
                        continue
                    join_counts["x_not_equals_y"] += 1
                    totals["literal_selections"] += 1

                    fixed23 = (r23, b, x)
                    fixed34 = (r34, y, c)
                    dec23 = carrier_decompositions(
                        classes, complement_load(fixed23), 3, 5
                    )
                    dec34 = carrier_decompositions(
                        classes, complement_load(fixed34), 1, 3
                    )
                    if not dec23 or not dec34:
                        totals["vacuous_carrier"] += 1
                        continue
                    totals["nonvacuous_selections"] += 1

                    selection = {
                        "singletons": {
                            "A": a, "B": b, "C": c, "D": d, "X": x, "Y": y
                        },
                        "triples": {
                            "q13": q13, "r45": r45, "q14": q14, "r23": r23,
                            "q24": q24, "r15": r15, "q25": q25, "r34": r34,
                        },
                        "carrier_sizes": (len(dec23), len(dec34)),
                    }
                    if first_nonvacuous is None:
                        first_nonvacuous = selection

                    tests = (
                        projection_intersection(classes, fixed23, dec23, 1, y),
                        projection_intersection(classes, fixed23, dec23, 2, d),
                        projection_intersection(classes, fixed34, dec34, 1, a),
                        projection_intersection(classes, fixed34, dec34, 2, x),
                    )
                    intersection_sizes = tuple(len(test[2]) for test in tests)
                    if not any(intersection_sizes):
                        totals["four_empty"] += 1
                        if first_four_empty is None:
                            first_four_empty = selection | {
                                "intersection_sizes": intersection_sizes,
                                "tests": tests,
                            }

                    fibre23 = dependent_fibre(fixed23, dec23, (y, d), family_set)
                    fibre34 = dependent_fibre(fixed34, dec34, (a, x), family_set)
                    if fibre23 is None and fibre34 is None:
                        totals["all_dependent_empty"] += 1
                        if first_dependent_empty is None:
                            first_dependent_empty = selection | {
                                "intersection_sizes": intersection_sizes,
                                "tests": tests,
                            }
                    else:
                        totals["has_dependent_fibre"] += 1
                        if first_positive_dependent is None:
                            first_positive_dependent = selection | {
                                "intersection_sizes": intersection_sizes,
                                "fibre23": fibre23,
                                "fibre34": fibre34,
                            }

    # An index-independent nested scan guards against a malformed join key.
    direct_join_counts = Counter({key: 0 for key in join_keys})
    for row3 in r3:
        _, _, a, b, c, d = row3
        for row1 in r1:
            _, _, a1, x, c1, d1 = row1
            if (a1, c1, d1) != (a, c, d):
                continue
            direct_join_counts["r3_r1_pairs"] += 1
            for row2 in r2:
                _, _, a2, b2, x2, c2 = row2
                if (a2, b2, c2, x2) != (a, b, c, x):
                    continue
                direct_join_counts["r3_r1_r2_triples"] += 1
                for row4 in r4:
                    _, _, b4, y, c4, d4 = row4
                    if (b4, c4, d4) != (b, c, d):
                        continue
                    direct_join_counts["r3_r1_r2_r4_quadruples"] += 1
                    direct_join_counts[
                        "x_equals_y" if x == y else "x_not_equals_y"
                    ] += 1
    assert direct_join_counts == join_counts

    def matching_id(matching):
        return None if matching is None else ids[matching]

    def row_ids(row):
        return None if row is None else tuple(matching_id(m) for m in row)

    def selection_ids(selection):
        if selection is None:
            return None
        output = {
            "singletons": {key: matching_id(value) for key, value in selection["singletons"].items()},
            "triples": {key: matching_id(value) for key, value in selection["triples"].items()},
            "carrier_sizes": selection["carrier_sizes"],
        }
        if "intersection_sizes" in selection:
            output["intersection_sizes"] = selection["intersection_sizes"]
            output["intersection_witnesses"] = tuple(
                {
                    matching_id(matching): reasons
                    for matching, reasons in test[2].items()
                }
                for test in selection["tests"]
            )
        for key in ("fibre23", "fibre34"):
            if key not in selection:
                continue
            fibre = selection[key]
            if fibre is None:
                output[key] = None
                continue
            row, witness = fibre
            converted = dict(witness)
            for field in ("middle", "final"):
                if field in converted:
                    converted[field] = row_ids(converted[field])
            for field in ("intermediate", "updated_triple"):
                if field in converted:
                    converted[field] = matching_id(converted[field])
            output[key] = {"row": row_ids(row), "witness": converted}
        return output

    print("NOTE024_REPEATED_STAR_AUDIT")
    print("pm_count", len(family))
    print("class_sizes", {str(key): len(value) for key, value in sorted(classes.items())})
    print("pivot_row_family_sizes", (len(r1), len(r2), len(r3), len(r4)))
    print("join_counts", dict(join_counts))
    print("direct_join_counts", dict(direct_join_counts))
    print("totals", dict(totals))
    print("first_nonvacuous", selection_ids(first_nonvacuous))
    print("first_four_empty", selection_ids(first_four_empty))
    print("first_all_dependent_empty", selection_ids(first_dependent_empty))
    print("first_positive_dependent", selection_ids(first_positive_dependent))
    print("NOTE024_REPEATED_STAR_CLASSIFIED")


if __name__ == "__main__":
    main()
