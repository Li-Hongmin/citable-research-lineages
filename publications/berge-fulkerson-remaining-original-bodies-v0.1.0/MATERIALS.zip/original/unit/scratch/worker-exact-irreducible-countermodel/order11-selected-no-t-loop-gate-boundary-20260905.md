# The order-eleven overload pole fails the selected no-T-loop gate by one pair

## Statement tested

Consider the order-eleven pole of Note 080 and its complete family of 24
perfect matchings.  Relabel the five terminals arbitrarily.  In the resulting
labels seek a repeated-extension pivot star with singleton identities

\[
 A,B,C,D,X,Y
\]

and singleton quadruples

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.       \tag{1}
\]

Require each quadruple in (1) to occur in an actual BF row, require
\(X\ne Y\), and require all three Note-073 targets

\[
 BDXY,\qquad ACXY,\qquad ABDY                  \tag{2}
\]

to be overloaded on a proper edge.  Absence of a \(T\)-loop would force each
of the seven selected singleton pairs

\[
 AB,\ AD,\ BX,\ BY,\ CX,\ CY,\ CD               \tag{3}
\]

to share a proper edge.  Indeed, if one pair in (3) were edge-disjoint, its
cubic complement would be a triple-boundary perfect matching; doubling the
resulting three-edge-colouring would give the corresponding \(T\)-loop.

The complete fixed-pole search finds no star satisfying (1)--(3) and the
three overload requirements.

## Complete enumeration and sharp conflict

All 120 terminal permutations and all actual witnesses in the four relevant
\(D_5\) cells were enumerated.  Exactly three labelled repeated pivot stars
occur.  Every one has all three targets (2) overloaded.  Their numbers of
failed pair-intersection conditions from (3) are respectively

\[
 3,\quad 1,\quad 2.                              \tag{4}
\]

Thus the closest star is a one-condition near miss.  Its physical terminal
permutation is

\[
 (1,2,3,4,5)_{\rm standard}\longmapsto(1,4,3,2,5),
\]

and its six perfect-matching IDs in the script's canonical enumeration are

\[
 (A,B,C,D,X,Y)=(14,11,3,8,12,1).                \tag{5}
\]

One actual BF witness for each of the four pivot rows is

\[
\begin{split}
 &(3,5,8,12,14,20),\\
 &(2,3,11,12,14,21),\\
 &(3,7,8,11,14,19),\\
 &(1,3,8,11,18,23).
\end{split}                                      \tag{6}
\]

The targets \(BDXY,ACXY,ABDY\) are overloaded on the proper edges
\((0,10)\), \((3,9)\) or \((4,6)\), and \((1,5)\), respectively.  Six of
the seven intersections in (3) are nonempty.  The unique failure is

\[
 B\cap Y=\varnothing.                            \tag{7}
\]

Here \(B\) and \(Y\) have physical singleton boundaries 4 and 3.  Their
cubic complement is perfect matching 21, of boundary \(\{1,2,5\}\).
Consequently

\[
 (1,1,11,11,21,21)                               \tag{8}
\]

is an actual doubled-Tait BF cover of physical loop type \([34]\), a
\(T\)-loop in the chosen standard labelling.  Deleting only the condition
\(B\cap Y\ne\varnothing\) makes the closest fixed-pole instance feasible,
so the boundary in (7) is sharp for this witness.

## Scope

This is a strict fixed-instance unsatisfiability result.  It shows that the
order-eleven pole used to separate girth-five irreducibility from nonoverload
cannot also satisfy even the selected-pair necessary conditions imposed by
no \(T\)-loops.  It does not prove that no \(T\)-loop forces a nonoverloaded
target in an arbitrary pole, and it does not test the additional absence of
all \(T\)--\(T\) covers.  No larger order was searched.

The deterministic pure-standard-library search is
`audit_order11_selected_no_t_loop_gate.py` in this directory.  It was run
only on Omen in

```text
[local archival reference]
```

with final marker

```text
ORDER11_SELECTED_NO_T_LOOP_GATE_AUDITED
```

The final run took 0.04 seconds and 10,496 KB peak RSS.
