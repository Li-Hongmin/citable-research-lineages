# The K3,3 bad rectangle is compatible with the exact-no-TT path pairings

Fix the four-row owner rectangle of Note 097.  On the local `K3,3` block
write a perfect matching as the image word of its permutation and take

\[
A=012,\quad C=120,\quad D=201,
\]
\[
B_0=012,\quad B_1=120,\qquad
X_0=021,\quad X_1=102.
\]

The exact negative-support consequences outside this block are

\[
\pi_B=(2\,1)(3\,5),\qquad
\pi_X=(3\,4)(2\,5).
\]

These prescribed path pairings do not contradict the rectangle.  Choose
the local carrier decompositions

\[
(q_{24},r_{15},B)=(C,D,B_0),(A,D,B_1)
\]

and, writing \(Y=210\),

\[
(q_{13},r_{45},X)=(X_1,Y,X_0),(X_0,Y,X_1).
\]

Each displayed triple partitions the nine edges of `K3,3`.  Moreover,

\[
q_{24}\mathbin\triangle B_i=A\mathbin\triangle C
\]

is a closed six-cycle, while

\[
q_{13}\mathbin\triangle X_j=X_0\mathbin\triangle X_1
\]

is a closed four-cycle.  Both avoid the attachment edge \((0,2)\).  Hence
the block contributes no terminal endpoint to either bichromatic pair.
Its row and column switches alter only proper closed-cycle phases, while the
ambient attachment determines the terminal paths independently.  In
particular the four rectangle cells can all retain the two exact-no-TT
pairings above.

There is also no hidden two-sum or forbidden boundary balance forced by the
four common row equations.  Model one additional cubic coordinate by a
`K4` component: each actual perfect matching chooses one of its three
one-factors, and a six-matching BF row is valid exactly when the three
symbols occur twice each.  The four rows have fifteen matching identities,
sharing only \(A,C,D\).  There are exactly 9,234 ternary assignments for
which all four rows are balanced.  Exhausting them gives:

- none of the four available all-terminal singleton choices is
  capacity-valid in every assignment;
- none of the ten available TT tuples from the `15` and `45` triple classes
  is balanced in every assignment;
- no two distinct matching pairs have equal incidence sum in every
  assignment, and hence there is no forced boundary-changing pair-sum
  equality.

Thus extra positive cells, if represented only by existential witnesses,
can be assigned fresh identities and separated by further cubic
coordinates; they do not identify one of their matchings with this fixed
carrier fibre.  This is the same global-to-fibre gap isolated in Notes
095--097.  In particular full forty-cell existence flags do not supply the
missing implication

\[
\text{internal }J\text{-minimality}
\Longrightarrow
\text{forbidden terminal-path phase or A/TT equal sum}.
\]

This is an information boundary, not an actual Case-XII counterexample.
The coordinate argument does not construct one connected cubic five-pole,
does not close the selected vectors under all perfect matchings, and does
not prove that the forty positive rows can coexist in a real pole while all
A/TT rows remain absent.  Conversely, no identity presently available from
the forty existential cells, common cubic row equations, or the exact-no-TT
path pairings rules out the local rectangle.  The proposed extremal-descent
statement therefore remains undecided for real exact-Case-XII poles.

The finite check is
`check_k33_core_universal_balances.py`.  It was run on Omen with Python
3.10.12 in one process under a 1 GiB virtual-memory cap.  The run enumerated
9,234 assignments, used 93,952 KiB maximum resident memory, took 0.33 s,
and ended with `K33_CORE_UNIVERSAL_BALANCES_CLASSIFIED`.
