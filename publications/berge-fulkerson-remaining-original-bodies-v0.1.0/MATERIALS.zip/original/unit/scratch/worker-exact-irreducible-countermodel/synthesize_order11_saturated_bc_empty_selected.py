#!/usr/bin/env python3
"""One-shot n=11 synthesis for the saturated-H23 occurrence boundary.

The SAT object has one simple cubic five-pole, five designated carrier rows
saturating H23, and one actual BC-joined 25--34 row.  Within the complete
*designated* matching family it forbids every TT cover and both Note-093
endpoint intersections.  After one SAT model, the full graph-induced perfect
matching closure is enumerated exactly.  There is deliberately no CEGAR loop.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import argparse
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path

from z3 import And, Bool, Implies, Not, Or, PbEq, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
LOCAL_EVALUATOR = (
    HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
)
BUNDLED_EVALUATOR = HERE / "synthesize_exact40_joint_pb.py"
EVALUATOR_PATH = LOCAL_EVALUATOR if LOCAL_EVALUATOR.exists() else BUNDLED_EVALUATOR
SPEC = importlib.util.spec_from_file_location("saturated_bc_evaluator", EVALUATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
EVALUATOR = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = EVALUATOR
SPEC.loader.exec_module(EVALUATOR)


N = 11
TERMINALS = tuple(range(5))
S = tuple(sorted(EVALUATOR.S))
T = tuple(sorted(EVALUATOR.T))
H23_STATE = (1, 2)  # one-based 23
STATE14 = (0, 3)
STATE35 = (2, 4)


def complement(pair):
    return frozenset(set(TERMINALS) - set(pair))


BOUNDARY = {
    "r23": complement(H23_STATE),
    "B": frozenset((1,)),
    "X": frozenset((2,)),
    "q13": complement((0, 2)),
    "p13_1": frozenset((0,)),
    "p13_3": frozenset((2,)),
    "q14": complement((0, 3)),
    "A": frozenset((0,)),
    "C": frozenset((3,)),
    "q24": complement((1, 3)),
    "p24_2": frozenset((1,)),
    "p24_4": frozenset((3,)),
    "q25": complement((1, 4)),
    "p25_2": frozenset((1,)),
    "p25_5": frozenset((4,)),
    "q35": complement((2, 4)),
    "P3": frozenset((2,)),
    "P5": frozenset((4,)),
    "q25b": complement((1, 4)),
    "r34": complement((2, 3)),
    "Y": frozenset((2,)),
    "D": frozenset((4,)),
}

SATURATION_ROWS = (
    ("r23", "B", "X", "q13", "p13_1", "p13_3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "p25_5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
)
BC_ROW = ("q25b", "r34", "B", "Y", "C", "D")


def cover_expr(row, x, y, edges):
    counts = Counter(row)
    return And(*(
        Or(
            Not(x[edge]),
            PbEq([(y[(name, edge)], count) for name, count in counts.items()], 2),
        )
        for edge in edges
    ))


def equal_expr(first, second, y, edges):
    return And(*(y[(first, edge)] == y[(second, edge)] for edge in edges))


def sep_expr(companion, source, target, y, edges):
    clauses = []
    for edge in edges:
        # target-source=+1 forces companion=1; source-target=+1 forces 0.
        clauses.append(Implies(And(y[(target, edge)], Not(y[(source, edge)])), y[(companion, edge)]))
        clauses.append(Implies(And(y[(source, edge)], Not(y[(target, edge)])), Not(y[(companion, edge)])))
    return And(*clauses)


def build_solver():
    edges = tuple(combinations(range(N), 2))
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    y = {
        (name, edge): Bool(f"y_{name}_{edge[0]}_{edge[1]}")
        for name in BOUNDARY for edge in edges
    }
    solver = Solver()
    premise = {
        name: Bool(f"premise_{name}")
        for name in ("saturation", "BC_join", "X_ne_Y", "selected_no_TT", "endpoint_empty")
    }

    for vertex in range(N):
        solver.add(PbEq(
            [(x[edge], 1) for edge in edges if vertex in edge],
            2 if vertex in TERMINALS else 3,
        ))
    solver.add(x[(5, 6)])

    for name, boundary in BOUNDARY.items():
        for edge in edges:
            solver.add(Implies(y[(name, edge)], x[edge]))
        for vertex in range(N):
            solver.add(PbEq(
                [(y[(name, edge)], 1) for edge in edges if vertex in edge],
                0 if vertex in boundary else 1,
            ))

    for row in (*SATURATION_ROWS, BC_ROW):
        label = premise["saturation"] if row in SATURATION_ROWS else premise["BC_join"]
        solver.add(Implies(label, cover_expr(row, x, y, edges)))
    solver.add(Implies(premise["X_ne_Y"], Not(equal_expr("X", "Y", y, edges))))

    triple_by_state = defaultdict(list)
    singleton_by_position = defaultdict(list)
    for name, boundary in BOUNDARY.items():
        if len(boundary) == 3:
            triple_by_state[tuple(sorted(set(TERMINALS) - set(boundary)))].append(name)
        elif len(boundary) == 1:
            singleton_by_position[next(iter(boundary))].append(name)

    # The selected named family itself has no TT completion.  Repetitions of
    # one matching identity are included by the Cartesian products.
    forbidden_tt_rows = 0
    for left_index, left in enumerate(T):
        for right in T[left_index:]:
            for left_q, right_q, *singletons in product(
                triple_by_state[left],
                triple_by_state[right],
                *(singleton_by_position[position] for position in left + right),
            ):
                solver.add(Implies(
                    premise["selected_no_TT"],
                    Not(cover_expr(
                        (left_q, right_q, *singletons), x, y, edges
                    )),
                ))
                forbidden_tt_rows += 1

    # Quantify both endpoint failures over every selected-family state-35
    # decomposition of K=2-H23, not merely the displayed saturation row.
    endpoint_candidates = 0
    for q, p3, p5 in product(
        triple_by_state[STATE35],
        singleton_by_position[2],
        singleton_by_position[4],
    ):
        carrier_row = ("r23", "B", "X", q, p3, p5)
        is_decomposition = cover_expr(carrier_row, x, y, edges)
        y_failure = And(
            Not(equal_expr(p3, "Y", y, edges)),
            *(Not(sep_expr(companion, p3, "Y", y, edges))
              for companion in ("r23", "B", "X")),
        )
        d_failure = And(
            Not(equal_expr(p5, "D", y, edges)),
            *(Not(sep_expr(companion, p5, "D", y, edges))
              for companion in ("r23", "B", "X")),
        )
        solver.add(Implies(
            premise["endpoint_empty"],
            Implies(is_decomposition, And(y_failure, d_failure)),
        ))
        endpoint_candidates += 1

    return solver, x, y, edges, forbidden_tt_rows, endpoint_candidates, premise


def selected_matching(name, model, y, proper_edges, edge_lookup):
    matching = [edge_lookup[edge] for edge in proper_edges if bool(model.eval(y[(name, edge)], model_completion=True))]
    matching.extend(len(proper_edges) + terminal for terminal in BOUNDARY[name])
    return tuple(sorted(matching))


def load(row, edge_count):
    answer = [0] * edge_count
    for matching in row:
        for edge in matching:
            answer[edge] += 1
    return tuple(answer)


def sep(companion, source, target):
    companion, source, target = map(frozenset, (companion, source, target))
    return (target - source) <= companion and not (companion & (source - target))


def connected(n, proper_edges):
    adjacency = {vertex: set() for vertex in range(n)}
    for u, v in proper_edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in adjacency[vertex]:
            if neighbour not in seen:
                seen.add(neighbour)
                stack.append(neighbour)
    return len(seen) == n


def endpoint_audit(family, classes, fixed, y_target, d_target, edge_count):
    target_load = tuple(2 - value for value in load(fixed, edge_count))
    decompositions = tuple(
        row
        for row in product(
            classes[complement(STATE35)], classes[frozenset((2,))], classes[frozenset((4,))]
        )
        if load(row, edge_count) == target_load
    )
    projection3 = {row[1] for row in decompositions}
    projection5 = {row[2] for row in decompositions}

    def status(projection, target):
        return {
            "literal_entry": target in projection,
            "strict_square": any(
                source != target
                and any(sep(companion, source, target) for companion in fixed)
                for source in projection
            ),
        }

    return {
        "state35_decompositions": len(decompositions),
        "Y": status(projection3, y_target),
        "D": status(projection5, d_target),
    }


def main():
    global N
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=11)
    parser.add_argument("--timeout-ms", type=int, default=120_000)
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least five")
    N = args.n
    solver, x, y, edges, forbidden_tt_rows, endpoint_candidates, premise = build_solver()
    solver.set(timeout=args.timeout_ms)
    status = solver.check(*premise.values())
    if status == unknown:
        print(json.dumps({"status": "unknown", "reason": solver.reason_unknown()}))
        print("ORDER11_SATURATED_BC_EMPTY_SELECTED_UNKNOWN")
        return
    if status != sat:
        print(json.dumps({
            "status": "unsat",
            "premise_category_unsat_core": tuple(
                str(item).removeprefix("premise_") for item in solver.unsat_core()
            ),
            "selected_TT_rows_forbidden": forbidden_tt_rows,
            "selected_state35_candidates": endpoint_candidates,
        }, indent=2, sort_keys=True))
        print("ORDER11_SATURATED_BC_EMPTY_SELECTED_UNSAT")
        return

    model = solver.model()
    proper_edges = tuple(sorted(edge for edge in edges if bool(model.eval(x[edge], model_completion=True))))
    edge_lookup = {edge: index for index, edge in enumerate(proper_edges)}
    selected = {
        name: selected_matching(name, model, y, proper_edges, edge_lookup)
        for name in BOUNDARY
    }
    selected_family = tuple(sorted(set(selected.values())))
    selected_classes = defaultdict(list)
    for matching in selected_family:
        selected_classes[EVALUATOR.matching_boundary(matching, len(proper_edges))].append(matching)

    selected_tt = []
    for left_index, left in enumerate(T):
        for right in T[left_index:]:
            kind = (left, right)
            if EVALUATOR.find_cover(kind, selected_classes, len(proper_edges)) is not None:
                selected_tt.append(kind)
    selected_endpoint = endpoint_audit(
        selected_family,
        selected_classes,
        (selected["r23"], selected["B"], selected["X"]),
        selected["Y"], selected["D"], len(proper_edges) + 5,
    )
    assert not selected_tt
    assert not any(selected_endpoint[key][mode]
                   for key in ("Y", "D") for mode in ("literal_entry", "strict_square"))

    full = EVALUATOR.evaluate(N, proper_edges)
    full_endpoint = endpoint_audit(
        full["matchings"], full["classes"],
        (selected["r23"], selected["B"], selected["X"]),
        selected["Y"], selected["D"], len(proper_edges) + 5,
    )
    tt_types = tuple(sorted(kind for kind in full["support"] if kind[0] in T and kind[1] in T))
    full_empty = not any(full_endpoint[key][mode]
                         for key in ("Y", "D") for mode in ("literal_entry", "strict_square"))
    is_real_counterexample = (
        connected(N, proper_edges)
        and full["a_witness"] is None
        and not tt_types
        and full_empty
    )
    output = {
        "status": "sat_selected_family",
        "order": N,
        "proper_edges": proper_edges,
        "connected": connected(N, proper_edges),
        "selected_matching_identities": len(selected_family),
        "selected_TT_rows_forbidden": forbidden_tt_rows,
        "selected_state35_candidates": endpoint_candidates,
        "selected_endpoint_audit": selected_endpoint,
        "full_PM_count": len(full["matchings"]),
        "full_has_A": full["a_witness"] is not None,
        "full_TT_types": len(tt_types),
        "full_endpoint_audit": full_endpoint,
        "real_counterexample": is_real_counterexample,
        "first_missing_layer": (
            None if is_real_counterexample else
            "connected_graph" if not connected(N, proper_edges) else
            "full_PM_closure_A" if full["a_witness"] is not None else
            "full_PM_closure_TT" if tt_types else
            "full_PM_closure_endpoint_entry_or_square"
        ),
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    print(
        "ORDER11_SATURATED_BC_EMPTY_REAL_COUNTEREXAMPLE"
        if is_real_counterexample
        else "ORDER11_SATURATED_BC_EMPTY_SELECTED_BOUNDARY"
    )


if __name__ == "__main__":
    main()
