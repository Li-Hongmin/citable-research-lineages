#!/usr/bin/env python3
"""Fixed-order directed synthesis of an exact Case-XII repeated-star pole."""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from itertools import combinations
from pathlib import Path

from z3 import And, Not, Or, PbGe, PbLe, unknown


HERE = Path(__file__).resolve().parent
LOCAL_BASE = HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
BUNDLED_BASE = HERE / "synthesize_exact40_joint_pb.py"
BASE_PATH = BUNDLED_BASE if BUNDLED_BASE.exists() else LOCAL_BASE
SPEC = importlib.util.spec_from_file_location("order15_exact_repeated_base", BASE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BASE
SPEC.loader.exec_module(BASE)


N = 15
A_ROW = tuple(sorted(((0, 2), (3, 4))))
B_ROW = tuple(sorted(((0, 3), (1, 2))))
C_ROW = tuple(sorted(((1, 3), (0, 4))))
D_ROW = tuple(sorted(((1, 4), (2, 3))))
IDENTITY_SLOTS = {
    "A": ((A_ROW, 2), (B_ROW, 2), (C_ROW, 2)),
    "B": ((B_ROW, 4), (C_ROW, 4), (D_ROW, 2)),
    "C": ((A_ROW, 4), (B_ROW, 3), (C_ROW, 5), (D_ROW, 5)),
    "D": ((A_ROW, 5), (C_ROW, 3), (D_ROW, 3)),
    "X": ((A_ROW, 3), (B_ROW, 5)),
    "Y": ((D_ROW, 4),),
}
TARGETS = (
    ("B", "D", "X", "Y"),
    ("A", "C", "X", "Y"),
    ("A", "B", "D", "Y"),
)
SELECTED_T_PAIRS = (
    ("A", "B"), ("A", "D"), ("B", "X"), ("B", "Y"),
    ("C", "X"), ("C", "Y"), ("C", "D"),
)


def add_girth_five(solver, x):
    for vertices in combinations(range(N), 3):
        solver.add(PbLe([(x[edge], 1) for edge in combinations(vertices, 2)], 2))
    for a, b, c, d in combinations(range(N), 4):
        for cycle in (
            ((a, b), (b, c), (c, d), (a, d)),
            ((a, b), (b, d), (c, d), (a, c)),
            ((a, c), (b, c), (b, d), (a, d)),
        ):
            solver.add(PbLe([(x[tuple(sorted(edge))], 1) for edge in cycle], 3))


def structural_bad_cuts(proper_edges):
    chosen = set(proper_edges)
    terminals = set(BASE.TERMINALS)
    bad = []
    for mask in range(1 << (N - 1)):
        if mask == (1 << (N - 1)) - 1:
            continue
        side = {0}
        side.update(i + 1 for i in range(N - 1) if mask & (1 << i))
        other = set(range(N)) - side
        cut_size = sum((u in side) != (v in side) for u, v in chosen)
        allowed_two = (
            (len(side) == 1 and side <= terminals)
            or (len(other) == 1 and other <= terminals)
            or (len(side) == 2 and side <= terminals)
            or (len(other) == 2 and other <= terminals)
        )
        threshold = 2 if allowed_two else 3
        if cut_size < threshold:
            bad.append((frozenset(side), threshold, cut_size))
    return tuple(bad)


def add_repeated_star(solver, edges, witness_vars):
    named = {}
    for name, slots in IDENTITY_SLOTS.items():
        canonical = witness_vars[slots[0]]
        named[name] = canonical
        for slot in slots[1:]:
            other = witness_vars[slot]
            for edge in edges:
                solver.add(canonical[edge] == other[edge])

    solver.add(Or(*(named["X"][edge] != named["Y"][edge] for edge in edges)))
    for target in TARGETS:
        solver.add(Or(*(
            PbGe([(named[name][edge], 1) for name in target], 3)
            for edge in edges
        )))
    for first, second in SELECTED_T_PAIRS:
        solver.add(Or(*(
            And(named[first][edge], named[second][edge]) for edge in edges
        )))
    return named


def graph_girth(proper_edges):
    adjacency = {vertex: [] for vertex in range(N)}
    for u, v in proper_edges:
        adjacency[u].append(v)
        adjacency[v].append(u)
    best = N + 1
    for skipped in proper_edges:
        start, finish = skipped
        queue = [(start, 0)]
        seen = {start}
        for vertex, distance in queue:
            if vertex == finish:
                best = min(best, distance + 1)
                break
            for neighbour in adjacency[vertex]:
                edge = tuple(sorted((vertex, neighbour)))
                if edge == skipped or neighbour in seen:
                    continue
                seen.add(neighbour)
                queue.append((neighbour, distance + 1))
    return best


def run(total_seconds: int, json_path: Path | None):
    solver, x, edges, witness_vars = BASE.build_solver(N)
    named = add_repeated_star(solver, edges, witness_vars)
    add_girth_five(solver, x)
    target_support = set(BASE.TARGET_TYPES)
    deadline = time.monotonic() + total_seconds
    rounds = []

    while True:
        remaining_ms = int((deadline - time.monotonic()) * 1000)
        if remaining_ms <= 0:
            payload = {"status": "timeout", "rounds": rounds}
            marker = "ORDER15_EXACT_REPEATED_OVERLOAD_TIMEOUT"
            break
        solver.set(timeout=remaining_ms)
        status = solver.check()
        if status == unknown:
            payload = {
                "status": "unknown", "reason": solver.reason_unknown(),
                "rounds": rounds,
            }
            marker = "ORDER15_EXACT_REPEATED_OVERLOAD_UNKNOWN"
            break
        if str(status) != "sat":
            payload = {"status": "unsat", "rounds": rounds}
            marker = "ORDER15_EXACT_REPEATED_OVERLOAD_UNSAT"
            break

        model = solver.model()
        proper_edges = tuple(sorted(
            edge for edge in edges
            if bool(model.eval(x[edge], model_completion=True))
        ))
        bad = []
        cut_violations = structural_bad_cuts(proper_edges)
        for side, threshold, _ in cut_violations:
            solver.add(PbGe([
                (x[edge], 1) for edge in edges
                if (edge[0] in side) != (edge[1] in side)
            ], threshold))
        if cut_violations:
            bad.append({"kind": "Note019_cut", "count": len(cut_violations)})

        evaluation = BASE.evaluate(N, proper_edges)
        if not target_support <= set(evaluation["support"]):
            raise RuntimeError("encoded positive Case-XII witness missing in evaluator")

        tait_witnesses = evaluation.get("tait_witnesses")
        if tait_witnesses is None:
            tait_witnesses = BASE.tait_colourings(evaluation["classes"], proper_edges)
        tait_states = frozenset(tait_witnesses)

        forbidden_tait = tait_states - BASE.S
        seen_tait_unions = set()
        for state in sorted(forbidden_tait):
            for witness in tait_witnesses[state]:
                union = BASE.tait_pair_union(witness, proper_edges)
                key = tuple(sorted(union))
                if key in seen_tait_unions:
                    continue
                seen_tait_unions.add(key)
                solver.add(BASE.clause_for_union(x, edges, union))
        if forbidden_tait:
            bad.append({
                "kind": "forbidden_Tait", "states": tuple(sorted(forbidden_tait)),
                "clauses": len(seen_tait_unions),
            })

        if evaluation["a_witness"] is not None:
            union = BASE.forbidden_union(evaluation["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A"})

        forbidden_types = set(evaluation["support"]) - target_support
        if forbidden_types:
            kind = min(forbidden_types, key=str)
            union = BASE.forbidden_union(evaluation["witnesses"][kind], proper_edges)
            assert union == frozenset(proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({
                "kind": "forbidden_support", "count": len(forbidden_types),
                "first": str(kind),
            })

        rounds.append({
            "round": len(rounds), "bad": bad,
            "matching_count": len(evaluation["matchings"]),
            "support_size": len(evaluation["support"]),
            "tait_states": tuple(sorted(tait_states)),
        })
        print(json.dumps(rounds[-1], sort_keys=True), flush=True)

        if not bad:
            named_matchings = {
                name: tuple(
                    edge for edge in proper_edges
                    if bool(model.eval(vector[edge], model_completion=True))
                )
                for name, vector in named.items()
            }
            target_overloads = {
                "".join(target): tuple(
                    edge for edge in proper_edges
                    if sum(edge in named_matchings[name] for name in target) >= 3
                )
                for target in TARGETS
            }
            assert all(target_overloads.values())
            payload = {
                "status": "sat_real_exact_case_xii",
                "proper_edges": proper_edges,
                "girth": graph_girth(proper_edges),
                "proper_two_cut_violations": 0,
                "matching_count": len(evaluation["matchings"]),
                "boundary_class_sizes": {
                    str(sorted(boundary)): len(family)
                    for boundary, family in sorted(evaluation["classes"].items(), key=str)
                },
                "support": tuple(sorted(map(str, evaluation["support"]))),
                "support_profile": {"SS+ST": 40, "A": False, "T_loop_TT": 0},
                "tait_states": tuple(sorted(tait_states)),
                "named_singletons": named_matchings,
                "target_overloads": target_overloads,
                "rounds": rounds,
            }
            marker = "ORDER15_REAL_EXACT_CASE_XII_REPEATED_OVERLOAD_FOUND"
            break

    payload["elapsed_s"] = total_seconds - max(0, deadline - time.monotonic())
    if json_path:
        json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print(marker)
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=int, default=295)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if not 1 <= args.seconds <= 295:
        raise SystemExit("seconds must be between 1 and 295")
    run(args.seconds, args.json)


if __name__ == "__main__":
    main()
