#!/usr/bin/env python3
"""Independent literal verifier for the order-nine all-bad carrier."""

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement, product


N = 9
PROPER = (
    (0, 4), (0, 6), (1, 5), (1, 6), (1, 7), (2, 6),
    (2, 8), (3, 7), (3, 8), (4, 7), (5, 8),
)
# Logical semiedges s_i are incident with these vertices.
TERMINAL = {1: 2, 2: 4, 3: 0, 4: 3, 5: 5}
SEMI = tuple(("s", logical, vertex) for logical, vertex in sorted(TERMINAL.items()))
OBJECTS = PROPER + SEMI
INDEX = {obj: index for index, obj in enumerate(OBJECTS)}
S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = {(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)}


def obj(text):
    if text.startswith("s"):
        logical, vertex = text[1:].split("@")
        return ("s", int(logical), int(vertex))
    u, v = text.split("-")
    return (int(u), int(v))


def literal(*names):
    return frozenset(INDEX[obj(name)] for name in names)


A = literal("0-6", "1-5", "3-8", "4-7", "s1@2")
C = literal("0-4", "1-7", "2-6", "5-8", "s4@3")
D = literal("0-4", "1-6", "2-8", "3-7", "s5@5")
B = literal("0-6", "1-5", "2-8", "3-7", "s2@4")
X = literal("1-5", "2-6", "3-8", "4-7", "s3@0")


def enumerate_perfect_matchings():
    incident = [[] for _ in range(N)]
    endpoints = []
    for index, edge in enumerate(OBJECTS):
        vertices = edge if len(edge) == 2 else (edge[2],)
        endpoints.append(frozenset(vertices))
        for vertex in vertices:
            incident[vertex].append(index)
    output = set()

    def search(uncovered, selected):
        if not uncovered:
            output.add(frozenset(selected))
            return
        vertex = min(uncovered)
        for edge in incident[vertex]:
            if endpoints[edge] <= uncovered:
                search(uncovered - endpoints[edge], (*selected, edge))

    search(frozenset(range(N)), tuple())
    return tuple(sorted(output, key=lambda matching: tuple(sorted(matching))))


def boundary(matching):
    return tuple(sorted(
        OBJECTS[index][1] for index in matching
        if len(OBJECTS[index]) == 3
    ))


def load(row):
    value = Counter()
    for matching in row:
        value.update(matching)
    return tuple(value[index] for index in range(len(OBJECTS)))


def connected(edges):
    neighbours = {vertex: set() for vertex in range(N)}
    for u, v in edges:
        neighbours[u].add(v)
        neighbours[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for other in neighbours[vertex] - seen:
            seen.add(other)
            stack.append(other)
    return len(seen) == N


def classify(pattern):
    sizes = sorted(map(len, pattern))
    if sizes == [1, 1, 5]:
        return "A"
    assert sizes == [1, 3, 3]
    missing = tuple(sorted(
        tuple(sorted(set(range(1, 6)) - set(part)))
        for part in pattern if len(part) == 3
    ))
    if all(pair in T for pair in missing):
        return "T-loop" if missing[0] == missing[1] else "TT"
    if all(pair in S for pair in missing):
        return "S-loop" if missing[0] == missing[1] else "SS"
    return "ST"


def main():
    degrees = Counter(vertex for edge in PROPER for vertex in edge)
    for vertex in TERMINAL.values():
        degrees[vertex] += 1
    assert all(degrees[vertex] == 3 for vertex in range(N))
    assert connected(PROPER)
    for edge in PROPER:
        assert connected(tuple(other for other in PROPER if other != edge))

    # All six proper 2-cuts have terminals on both sides, so none separates a
    # terminal-free closed factor (colourable or otherwise).
    terminal_vertices = set(TERMINAL.values())
    two_cuts = []
    for first, second in combinations(PROPER, 2):
        remaining = tuple(edge for edge in PROPER if edge not in (first, second))
        neighbours = {vertex: set() for vertex in range(N)}
        for u, v in remaining:
            neighbours[u].add(v)
            neighbours[v].add(u)
        side = {0}
        stack = [0]
        while stack:
            vertex = stack.pop()
            for other in neighbours[vertex] - side:
                side.add(other)
                stack.append(other)
        if len(side) != N:
            other = set(range(N)) - side
            assert side & terminal_vertices and other & terminal_vertices
            two_cuts.append((first, second, len(side & terminal_vertices), len(other & terminal_vertices)))
    assert len(two_cuts) == 6
    assert sorted(sorted((left, right)) for _, _, left, right in two_cuts) == [
        [1, 4], [1, 4], [1, 4], [1, 4], [1, 4], [2, 3]
    ]

    matchings = enumerate_perfect_matchings()
    assert len(matchings) == 18
    assert all(item in matchings for item in (A, B, C, D, X))
    classes = defaultdict(list)
    for matching in matchings:
        classes[boundary(matching)].append(matching)

    target_k = tuple(2 - value for value in load((A, C, D)))
    assert min(target_k) >= 0 and max(target_k) <= 2
    decompositions = []
    for row in combinations_with_replacement(matchings, 3):
        if load(row) != target_k:
            continue
        pattern = tuple(sorted(boundary(matching) for matching in row))
        decompositions.append((row, pattern, classify(pattern)))
    assert len(decompositions) == 6
    assert Counter(category for _, _, category in decompositions) == {"ST": 4, "SS": 2}
    assert not any(category in {"T-loop", "TT"} for _, _, category in decompositions)

    b_pattern = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
    x_pattern = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))
    b_rows = [row for row, pattern, _ in decompositions if pattern == b_pattern]
    x_rows = [row for row, pattern, _ in decompositions if pattern == x_pattern]
    assert len(b_rows) == len(x_rows) == 1
    actual_b = next(item for item in b_rows[0] if boundary(item) == (2,))
    actual_x = next(item for item in x_rows[0] if boundary(item) == (3,))
    assert actual_b == B and actual_x == X

    complement_rows = [
        row for row in product(classes[(1,)], classes[(4,)], classes[(5,)])
        if tuple(2 - value for value in load(row)) == target_k
    ]
    # There are two literal (A,C,D) decompositions of 2-K.  The frozen one is
    # the scanner's first witness; both are bad for the unique B/X choice.
    assert len(complement_rows) == 2
    assert (A, C, D) in complement_rows
    assert all(
        B & X & (a_matching ^ c_matching) == {INDEX[(1, 5)]}
        for a_matching, c_matching, _ in complement_rows
    )

    print("order=9")
    print("perfect_matchings=18")
    print("K_decompositions=6; types=ST^4,SS^2; T-loop=TT=0")
    print("B_rows=1; X_rows=1; ACD_rows=2; every J={1-5}")
    print("proper_2cuts=6; every side contains a terminal")
    print("ORDER9_INDIVISIBLE_ALL_BAD_CARRIER_VERIFIED")


if __name__ == "__main__":
    main()
