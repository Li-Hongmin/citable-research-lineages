# Note 101 minimum block-pairing synthesis is unresolved at the parity layer

## Question and scope

The single attempted synthesis asked whether the nineteen actual token
signatures of Note 101 can be globally paired into a simple connected cubic
five-pole while retaining the five saturated \(H_{23}\) rows, the pointwise
\(BC\) row, selected-family no-\(A\)/no-\(TT\), and the two empty endpoint
intersections.  A successful graph was to be closed under all graph-induced
perfect matchings and tested for an exact Case-XII / Note-082 counterexample.

The computation did not scan orders, neighbourhoods, or random instances.
It first enumerated every valid local block profile and every three-block
partition, then made one optimization call for a minimum GF(2) parity
completion.  Only after that call returned a model would it have attempted
one simple connected equal-profile pairing and one complete-PM-closure
evaluation.

## Outcome

The finite local enumeration produced

\[
719\text{ valid block profiles},\qquad
4194\text{ valid three-block partitions}.
\]

The minimum-parity `Optimize` call reached its 180-second timeout and
returned

```text
{'status': 'GF2_unknown', 'reason': 'sat.canceled',
 'valid_blocks': 719, 'valid_partitions': 4194}
NOTE101_BLOCK_PARITY_UNKNOWN
```

Thus the first unresolved layer is already the minimum GF(2) parity
completion.  No optimizing model was obtained, so the computation did not
determine the minimum number of internal vertices, did not attempt the
simple/connected stub pairing, and did not enumerate a graph-induced perfect
matching closure.  In particular, it gives neither a real counterexample nor
an infeasibility result.  It also does not change the previously known lower
bound of four internal vertices (order at least nine).

This is the prescribed `unknown` stopping boundary.  No parameter change,
second solver formulation, order scan, or mathematical rerun was made.

## Omen execution record

The decisive run used Omen only, in

```text
[local archival reference]
```

with Python 3.10.12, Z3 5.1.0, one process, a 1-GiB virtual-memory limit, an
inner 180-second optimizer timeout, and an outer 240-second process timeout:

```bash
/usr/bin/time -v -o timing.txt /usr/bin/timeout 240s \
  bash -c 'ulimit -v 1048576; exec python3 synthesize_note101_block_pairing.py'
```

The process exited normally after reporting `unknown`.  Wall time was
3:00.92, user time 180.68 seconds, system time 0.22 seconds, and maximum RSS
602,896 KiB.  The outer timeout was not reached.  No synthesis process
remained afterward.

The first launch stopped before any solver call because Z3 5.1 accepts at
most three positional arguments to `Xor`.  Replacing the variadic call by an
equivalent binary fold was a compatibility repair; that 0.33-second launch
did not constitute a mathematical run.

SHA-256 values of the frozen remote inputs and outputs are:

```text
26e15258a0d290dc5d34a165a3eff956e43b09e7bdf682b1c02e3fc19070448c  synthesize_note101_block_pairing.py
2ded7619a13f116eae520d2d2272c3c09019decea7571f41a063ac0badf3f453  synthesize_exact40_joint_pb.py
846d7c06a17445ec74be25f4ef5a798d1ed320d7ff8bfd974d21cca0d2e6adcc  run.out
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  run.err
fb503d69532bf029f800d9cbd4c10dba2871a93d75fca6c5dc336ae41d179d71  timing.txt
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  exit_code.txt
```

The local synthesis source is
`synthesize_note101_block_pairing.py`.  Its selected-family antecedent checks
and complete-closure evaluation remain present but were not reached.
