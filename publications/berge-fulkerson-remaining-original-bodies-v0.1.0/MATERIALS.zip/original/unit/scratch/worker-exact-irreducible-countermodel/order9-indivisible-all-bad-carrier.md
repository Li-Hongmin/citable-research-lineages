# An order-nine indivisible all-bad common carrier

There is a simple connected proper-bridgeless cubic five-pole of order nine
with a common load (K) for the fixed (B)- and (X)-rows such that the fixed
layer contains no (T)-loop or (T)-(T) decomposition and every actual
(B\times X) choice overloads (A\triangle C).  No proper two-edge-cut of the
pole separates a terminal-free closed factor.  Orders five and seven have no
such pole, so order nine is sharp in the requested odd-order range.

## Literal pole and selected matchings

The augmented graph6 string is ``I?`FAosn?`` (the backtick is a graph6
character).  With logical semiedges

\[
 s_1@2,\quad s_2@4,\quad s_3@0,\quad s_4@3,\quad s_5@5,
\]

the proper edges are

\[
\begin{split}
&04,06,15,16,17,26,28,37,38,47,58.
\end{split}
\]

The complete pole has 18 perfect matchings.  One complementary triple is

\[
\begin{aligned}
A={}&\{06,15,38,47,s_1\},\\
C={}&\{04,17,26,58,s_4\},\\
D={}&\{04,16,28,37,s_5\}.
\end{aligned}
\]

For (K=2\mathbf 1-A-C-D), the edges (s_2,s_3) have load two and

\[
06,15,16,17,26,28,37,38,47,58,s_1,s_4,s_5
\]

have load one.  Its unique (B)-row is

\[
\begin{array}{c|l}
2 & 06,15,28,37,s_2\\
234 & 17,26,58,s_2,s_3,s_4\\
135 & 16,38,47,s_1,s_3,s_5,
\end{array}
\]

and its unique (X)-row is

\[
\begin{array}{c|l}
3 & 15,26,38,47,s_3\\
123 & 16,37,58,s_1,s_2,s_3\\
245 & 06,17,28,s_2,s_4,s_5.
\end{array}
\]

Thus their singleton matchings satisfy

\[
B\cap X\cap(A\triangle C)=\{15\}.
\]

The full perfect-matching closure gives exactly six decompositions of this
(K).  Their boundary patterns are

\[
\begin{gathered}
(123,245,3),\ (124,235,3),\ (1,234,235),\\
(123,235,4),\ (134,2,235),\ (135,2,234).
\end{gathered}
\]

They comprise four (S)-(T) and two (S)-(S) rows, hence no (T)-loop
and no (T)-(T) row.  There are two actual complementary
((A,C,D)\in\mathcal P_1\times\mathcal P_4\times\mathcal P_5) triples for
this same (K); both give the same nonempty obstruction \(\{15\}\) for the
unique (B\times X) choice.

The pole has six proper two-edge-cuts.  The terminal counts on their two
sides are five copies of (1|4) and one copy of (2|3).  Consequently no
side is terminal-free, before any question of three-edge-colourability.

## Exhaustion and reproduction

The Omen scan streamed all admissible augmented graph6 records and all 120
ordered boundary orientations.  It exhausted order five (4 generated
augmented graphs) and order seven (35 generated) without a hit, and stopped
at the first order-nine hit after 32 generated records.  Peak resident memory
was 13,312 KB.

```sh
python3 -u scan_indivisible_all_bad_carriers_through13.py \
  --geng [local archival reference] \
  --orders 5 7 9 11 13 --json result.json
```

The independent hard-coded verifier enumerates the 18 perfect matchings from
the literal edge set and checks the complete six-row (K)-closure, both
complementary triples, every (B\times X) intersection, and every proper
two-edge-cut:

```sh
python3 verify_order9_indivisible_all_bad_carrier.py
```

Its terminal marker is `ORDER9_INDIVISIBLE_ALL_BAD_CARRIER_VERIFIED`.

## Complete BF closure

A subsequent fixed-instance enumeration finds 51 BF-cover multisets and 37
boundary types.  The support consists of all 15 (S)--(S) types, the 14
(S)--(T) types

\[
\begin{gathered}
(12)(14),(12)(35),\\
(13)(15),(13)(45),\\
(14)(15),(14)(34),(14)(45),\\
(15)(24),(15)(25),(15)(35),\\
(24)(45),(25)(34),(25)(45),(35)(45),
\end{gathered}
\]

and the eight (T)--(T) types

\[
[15],[45],(12)(15),(12)(34),(12)(45),(15)(34),(15)(45),(34)(45).
\]

There is no all-terminal (A)-cover.  The Tait state set is

\[
S\cup\{15,45\},
\]

so exact-(S) is the first failed exact-Case-XII hypothesis.  The two extra
states are precisely the two global (T)-loops above.

The pole contains only 29 of the 40 positive Case-XII types.  Its missing
(S)--(T) cells are

\[
\begin{gathered}
(12)(13),(12)(24),(12)(25),(13)(23),(13)(34),(14)(23),\\
(23)(24),(23)(25),(23)(35),(24)(34),(34)(35).
\end{gathered}
\]

Consequently no actual full-40 witness skeleton exists in this pole, so the
bad fixed carrier cannot be embedded into one.  Its two covers themselves do
occupy the legitimate target cells ((15)(24)) and ((13)(45)); the obstruction
is the eleven missing global cells, not a mismatch of the fixed rows.

Thus this is a real finite countermodel to the proposed fibre-avoidance
implication under the stated irreducibility condition, and it additionally
satisfies the global no-(A) condition.  It is not a Case-XII pole: exact-(S),
global no-(T)--(T), and full forty-cell positivity all fail.
