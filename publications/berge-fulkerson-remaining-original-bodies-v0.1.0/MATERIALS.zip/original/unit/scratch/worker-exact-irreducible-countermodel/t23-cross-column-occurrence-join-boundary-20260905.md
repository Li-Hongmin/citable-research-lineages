# Saturated \(t=23\) cross-column occurrence join: a frozen-corpus boundary

Let

\[
 H=(r_{23},B,X),\qquad K=2\mathbf 1-H,
\]

and call \(H\) saturated when every state in
\(S=\{13,14,24,25,35\}\) has an actual three-perfect-matching
decomposition of \(K\).  The minimum actual join to the \(t=34\) column
used here consists of

\[
 K=q_{14}+A+C
\]

together with an actual row

\[
 q_{25}+r_{34}+B+Y+C+D=2\mathbf 1.
\]

Thus the two columns share the pointwise singleton occurrences \(B,C\), and
the second row supplies the external occurrences \(Y,D\).  This is weaker
than requiring all four repeated-star rows.

For every such join the two Note 093 tests are

\[
 \mathcal F_3(K;5)\cap\mathcal G_H(Y),\qquad
 \mathcal F_5(K;3)\cap\mathcal G_H(D).
\]

The calculation separately records direct literal entry in the carrier
projection and a strict fixed-half square
\(L+P=L'+\widehat P\), with \(P\ne\widehat P\).

## Complete result on the frozen poles

\[
\begin{array}{c|r|r|r|r|c|r}
\text{pole}&|\mathcal P|&\text{saturated }H&BC\text{ joins}&
\text{distinct gates}&A&TT\\ \hline
n=9&18&0&0&0&\text{no}&8\\
n=11&24&0&0&0&\text{no}&15\\
n=13\text{ Note 007}&31&0&0&0&\text{yes}&7\\
n=13\text{ all-SS}&37&2&1&1&\text{no}&15\\
n=13\text{ first synthesis}&34&1&2&2&\text{no}&15\\
n=19&66&0&0&0&\text{no}&15
\end{array}
\]

All three distinct minimum cross-column gates have both Note 093
intersections nonempty.  Their exact occurrence mechanisms are:

- the all-SS gate has direct \(Y,D\) entry and strict squares for both;
- one first-synthesis gate has direct \(Y,D\) entry and no strict square;
- the other has direct \(Y\) entry and a strict \(D\) square.

Consequently there is no gate with both intersections empty.  Requiring all
four repeated-star rows makes the sample still emptier: the order-eleven and
order-nineteen poles have respectively 1 and 252 full row-occurrence joins,
but none has a saturated \(H\); the two poles with saturated halves have no
full repeated-star join.

## Decision

The frozen real corpus proves only the finite statement that every minimum
\(BC\)-joined saturated gate in these six poles has both first-step
intersections nonempty.  It does **not** decide whether empty intersections
would force an all-terminal or \(T\)--\(T\) cover: the empty-intersection
antecedent is never reached, and the two poles contributing all three gates
already have all fifteen \(TT\) types.

The strict-square condition is not itself the common explanation, because
one gate has no strict square at either endpoint and succeeds by literal
projection entry.  The first genuinely distinguishing missing object is
therefore a real saturated \(H_{23}\) with the displayed actual \(BC\) join
and both Note 093 intersections empty.  Testing A/TT before such an object is
available cannot distinguish the proposed implication.

## Reproduction

The pure-standard-library driver is
`audit_existing_t23_cross_column_occurrence_join.py` in this directory.  It
enumerates only the complete perfect-matching closures of the six frozen
poles and creates no graph.  The final Omen run used one process with a
1 GiB virtual-memory cap, exited zero, took 1.75 seconds, used 17,452 KiB
peak RSS, and ended with

```text
EXISTING_T23_CROSS_COLUMN_OCCURRENCE_JOIN_AUDITED
```

The source SHA-256 was

```text
24bc1330246cbf829a19060ba42a5e0d38e0d3da29930319340769471232927c
```

The frozen remote run is
`[local archival reference]`.
