# A real order-nine common carrier has the exact-negative six-state relation

The boundary-colouring implication left open by the order-seven slice is
false.  There is a connected degree-three copy-multigraph \(K\), with
terminal-copy loads \((1,2,2,1,1)\), which admits both

\[
B=(15\mid24;2),\qquad X=(13\mid45;3),
\]

while its complete proper three-edge-colouring relation contains neither an
all-terminal A pattern nor a TT pattern.  Moreover, this \(K\) is compatible
with an owner-consistent complementary load \(A+C+D\) on a simple,
connected cubic 5-pole in which no proper edge is a bridge.

## The carrier

Take vertices \(0,\ldots,8\), with terminal \(s_i\) incident with vertex
\(i-1\) for \(1\le i\le5\).  The terminal-copy multiplicities are

\[
K(s_1),\ldots,K(s_5)=(1,2,2,1,1),
\]

and every following proper edge has multiplicity one:

\[
\begin{split}
03,07,15,28,36,46,47,56,58,78.
\end{split}                                                    \tag{1}
\]

Counting terminal copies, every vertex has \(K\)-degree three.  Direct
recursive enumeration gives twelve labelled colourings after fixing the
colour of the first edge, or six colour-permutation orbits.  Their complete
boundary relation is

\[
\begin{aligned}
\{&(15\mid24;2),(14\mid15;1),(14\mid25;2),\\
  &(13\mid45;3),(14\mid35;3),(14\mid45;4)\}.                  \tag{2}
\end{aligned}
\]

Thus (2) realizes, in one actual carrier with genuine component-switch
transport, exactly the two abstract three-type blocks of the boundary
Kempe countermodel.  Four entries are ST and two are SS; none is A or TT.
In particular, simultaneous interior realizability of the three
bichromatic pairing systems does not restore the failed implication.

One \(B\)-decomposition of \(K\) is

\[
\begin{aligned}
q_{24}&=\{15,36,78,s_1,s_3,s_5\},\\
r_{15}&=\{07,46,58,s_2,s_3,s_4\},\\
B     &=\{03,28,47,56,s_2\},
\end{aligned}                                                   \tag{3}
\]

and one \(X\)-decomposition is

\[
\begin{aligned}
q_{13}&=\{07,28,56,s_2,s_4,s_5\},\\
r_{45}&=\{36,47,58,s_1,s_2,s_3\},\\
X     &=\{03,15,46,78,s_3\}.
\end{aligned}                                                   \tag{4}
\]

The complete enumeration shows that the singleton fibres in (3) and (4)
are each singletons: there is exactly one literal \(B\) and one literal
\(X\) in this carrier.

## Complementary cubic 5-pole

The completion is not an arbitrary choice.  In the fixed \(K\), precisely
vertices 1 and 2 have local load profile \((2,1)\); the other seven vertices
have profile \((1,1,1)\).  A cubic completion must therefore add one
invisible proper half-incidence at each of vertices 1 and 2.  Pairing all
deficits gives the unique simple completion edge \(12\).  Thus the fixed
carrier has exactly one simple connected cubic 5-pole completion, rather
than merely one selected completion.  No proper edge of this pole is a
bridge.

Across this complete fixed-\(K\) completion set, there are exactly two
labelled decompositions of the complementary load \(2\mathbf1-K\) into
singleton classes 1, 4 and 5:

\[
\begin{aligned}
A_0&=\{12,36,47,58,s_1\},
&C_0&=\{07,15,28,46,s_4\},\\
A_1&=\{15,28,36,47,s_1\},
&C_1&=\{07,12,46,58,s_4\},\\
D_0=D_1&=\{03,12,56,78,s_5\}.                                \tag{5}
\end{aligned}
\]

The owner of \(03\) is forced without enumeration.  At vertex 0 the
semiedge \(s_1\) belongs to \(A\), so \(03\) can only belong to \(C\) or
\(D\).  At vertex 3 the semiedge \(s_4\) belongs to \(C\), so \(03\) can
only belong to \(A\) or \(D\).  Hence

\[
\operatorname{owner}(03)=D.                                  \tag{6}
\]

The remaining propagation also explains why (5) is complete.  The two
vertices force \(07=C\) and \(36=A\).  The incidences at vertices 6, 4 and
7 then force

\[
46=C,\quad47=A,\quad56=D,\quad78=D.
\]

At vertices 5 and 8, the owner of \(58\) may be either \(A\) or \(C\);
the edges \(15,28\) receive the other owner, and the double-load edge
\(12\) receives the remaining two matchings.  These are precisely the two
rows in (5).

Every load-one object of \(K\) has the same owner at both endpoints.
Equations (3) or (4), added to either row of (5), cover every proper edge
and semiedge of the pole exactly twice.  The certificate checks the same
statement for all six colouring orbits in (2), not only for the two
displayed carrier rows.

This embedding is not a counterexample to the desired nonoverload
conclusion.  Instead it isolates the remaining mechanism exactly:

\[
B\cap X=\{03\}\subseteq D,
\qquad
B\cap X\cap(A_i\mathbin\triangle C_i)=\varnothing
\quad(i=0,1).                                                   \tag{7}
\]

Thus the unique \(B,X\) pair is already safe.  The example disproves the
intermediate assertion that one real common carrier with both projections
must have A or TT, but it supports the sharper fixed-owner formulation: the
owner phase, not common-carrier realizability or Kempe transport alone,
distinguishes the safe pair.

The whole pole does not satisfy the exact Case-XII negative support.  It has
19 perfect matchings; an exhaustive test of all 56 BF boundary types gives

\[
\texttt{no-A}=\mathrm{false},
\qquad
\texttt{no-TT}=\mathrm{false}.                                \tag{8}
\]

Thus it violates both global exclusions, with the presence of an A cover
already sufficient to reject it as an exact Case-XII pole.  This global
failure does not affect the fixed-load counterexample in (1)--(7), but it
prevents the example from serving as a Case-XII graph.

## Search boundary and reproduction

The fixed \(B\)-colouring leaves respectively 6, 6 and 8 internal stubs in
its three colours, giving

\[
15\cdot15\cdot105=23{,}625
\]

raw pairing triples.  Configurations are deduplicated after forgetting the
generating colours, and triple copies of one edge object are rejected.  The
search stops at the first owner-embeddable exact-negative \(B/X\) carrier,
as required.  It occurs after 4,408 distinct configurations; therefore the
reported prefix counts are not a complete order-nine census.  Before the
stop, 2,271 configurations were rejected by an A colouring, 2,091 by a TT
colouring, and 45 exact-negative configurations lacked \(X\).

`search_order9_configuration_carrier_countermodel.py` performs the targeted
scan and freezes (1)--(7) with literal assertions.  Its output
`order9_configuration_carrier_result.txt` includes all six three-matching
decompositions, the owner assignment, the invisible edge, and the
edge-by-edge double-cover checks.  The Omen run used Python 3.10.12, one
process and a 1 GiB virtual-memory cap.  It stopped after 0.29 seconds with
maximum resident set size 11,520 KiB and marker
`ORDER9_CONFIGURATION_CARRIER_SCAN_OK`.  No order eleven, random search,
SAT instance, CEGAR loop, or new pole enumeration was attempted, and no
permanent note was modified.

`audit_order9_fixed_owner_and_full_bf_support.py` derives every deficit
directly from \(K\), exhausts all legal invisible-edge pairings, enumerates
all complementary decompositions in (5), verifies the owner forcing in
(6), enumerates the resulting pole's perfect matchings, and tests all 56 BF
boundary types for (8).  Its Omen run used one process and the same 1 GiB
cap, took 0.02 seconds, reached 10,240 KiB maximum resident memory, and
ended with `ORDER9_FIXED_OWNER_AND_FULL_BF_SUPPORT_VERIFIED`.
