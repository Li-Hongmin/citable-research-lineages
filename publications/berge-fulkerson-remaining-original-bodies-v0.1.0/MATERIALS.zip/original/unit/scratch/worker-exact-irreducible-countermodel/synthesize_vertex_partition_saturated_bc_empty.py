#!/usr/bin/env python3
"""Minimum common-trivalent vertex-partition countermodel synthesis.

Every named matching chooses one of three incidences at each of the five
terminal vertices.  Boundary semiedges are incidence 2 and are fixed by the
matching boundary; the other two incidences are proper stubs.  Six-matching
rows double-cover each incidence.  Proper stubs are deliberately not paired
between vertices into graph edges, so this is exactly the common local
trivalent-incidence layer below graph realization.
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from itertools import product

from z3 import And, Bool, Implies, Not, Or, PbEq, Solver, sat


VERTICES = tuple(range(5))
INCIDENCES = (0, 1, 2)
S = ((0, 2), (0, 3), (1, 3), (1, 4), (2, 4))
T = ((0, 1), (0, 4), (1, 2), (2, 3), (3, 4))
STATE35 = (2, 4)


def complement(pair):
    return frozenset(set(VERTICES) - set(pair))


BOUNDARY = {
    "r23": complement((1, 2)), "B": frozenset((1,)), "X": frozenset((2,)),
    "q13": complement((0, 2)), "p13_1": frozenset((0,)), "p13_3": frozenset((2,)),
    "q14": complement((0, 3)), "A": frozenset((0,)), "C": frozenset((3,)),
    "q24": complement((1, 3)), "p24_2": frozenset((1,)), "p24_4": frozenset((3,)),
    "q25": complement((1, 4)), "p25_2": frozenset((1,)), "p25_5": frozenset((4,)),
    "q35": complement((2, 4)), "P3": frozenset((2,)), "P5": frozenset((4,)),
    "q25b": complement((1, 4)), "r34": complement((2, 3)),
    "Y": frozenset((2,)), "D": frozenset((4,)),
}

SATURATION_ROWS = (
    ("r23", "B", "X", "q13", "p13_1", "p13_3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "p25_5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
)
BC_ROW = ("q25b", "r34", "B", "Y", "C", "D")


def cover_expr(row, z):
    counts = Counter(row)
    return And(*(
        PbEq([(z[(name, vertex, incidence)], count)
              for name, count in counts.items()], 2)
        for vertex in VERTICES for incidence in INCIDENCES
    ))


def equal_expr(first, second, z):
    return And(*(
        z[(first, vertex, incidence)] == z[(second, vertex, incidence)]
        for vertex in VERTICES for incidence in INCIDENCES
    ))


def sep_expr(companion, source, target, z):
    # Agreement-region form: wherever source and target choose different
    # incidences, the companion must choose the target incidence.
    return And(*(
        Implies(
            And(z[(source, vertex, source_incidence)],
                z[(target, vertex, target_incidence)]),
            z[(companion, vertex, target_incidence)],
        )
        for vertex in VERTICES
        for source_incidence in INCIDENCES
        for target_incidence in INCIDENCES
        if source_incidence != target_incidence
    ))


def build_solver():
    z = {
        (name, vertex, incidence): Bool(f"z_{name}_{vertex}_{incidence}")
        for name in BOUNDARY for vertex in VERTICES for incidence in INCIDENCES
    }
    solver = Solver()
    for name, boundary in BOUNDARY.items():
        for vertex in VERTICES:
            solver.add(PbEq(
                [(z[(name, vertex, incidence)], 1) for incidence in INCIDENCES], 1
            ))
            if vertex in boundary:
                solver.add(z[(name, vertex, 2)])
            else:
                solver.add(Not(z[(name, vertex, 2)]))
    for row in (*SATURATION_ROWS, BC_ROW):
        solver.add(cover_expr(row, z))
    solver.add(Not(equal_expr("X", "Y", z)))

    triple_by_state = defaultdict(list)
    singleton_by_position = defaultdict(list)
    for name, boundary in BOUNDARY.items():
        if len(boundary) == 3:
            triple_by_state[tuple(sorted(set(VERTICES) - set(boundary)))].append(name)
        else:
            singleton_by_position[next(iter(boundary))].append(name)

    forbidden_tt_rows = 0
    for left_index, left in enumerate(T):
        for right in T[left_index:]:
            for left_q, right_q, *singletons in product(
                triple_by_state[left], triple_by_state[right],
                *(singleton_by_position[position] for position in left + right),
            ):
                solver.add(Not(cover_expr((left_q, right_q, *singletons), z)))
                forbidden_tt_rows += 1

    endpoint_candidates = 0
    for q, p3, p5 in product(
        triple_by_state[STATE35], singleton_by_position[2], singleton_by_position[4]
    ):
        is_decomposition = cover_expr(("r23", "B", "X", q, p3, p5), z)
        y_failure = And(
            Not(equal_expr(p3, "Y", z)),
            *(Not(sep_expr(companion, p3, "Y", z)) for companion in ("r23", "B", "X")),
        )
        d_failure = And(
            Not(equal_expr(p5, "D", z)),
            *(Not(sep_expr(companion, p5, "D", z)) for companion in ("r23", "B", "X")),
        )
        solver.add(Implies(is_decomposition, And(y_failure, d_failure)))
        endpoint_candidates += 1
    return solver, z, forbidden_tt_rows, endpoint_candidates


def signature(name, model, z):
    return tuple(
        next(incidence for incidence in INCIDENCES
             if bool(model.eval(z[(name, vertex, incidence)], model_completion=True)))
        for vertex in VERTICES
    )


def is_cover(row, signatures):
    return all(
        sum(signatures[name][vertex] == incidence for name in row) == 2
        for vertex in VERTICES for incidence in INCIDENCES
    )


def sep(companion, source, target, signatures):
    return all(
        signatures[source][vertex] == signatures[target][vertex]
        or signatures[companion][vertex] == signatures[target][vertex]
        for vertex in VERTICES
    )


def main():
    solver, z, forbidden_tt_rows, endpoint_candidates = build_solver()
    solver.set(timeout=120_000)
    status = solver.check()
    if status != sat:
        print(json.dumps({"status": str(status)}))
        print("VERTEX_PARTITION_SATURATED_BC_EMPTY_NOT_REALIZED")
        return
    model = solver.model()
    signatures = {name: signature(name, model, z) for name in BOUNDARY}
    assert all(is_cover(row, signatures) for row in (*SATURATION_ROWS, BC_ROW))

    triple_by_state = defaultdict(list)
    singleton_by_position = defaultdict(list)
    for name, boundary in BOUNDARY.items():
        if len(boundary) == 3:
            triple_by_state[tuple(sorted(set(VERTICES) - set(boundary)))].append(name)
        else:
            singleton_by_position[next(iter(boundary))].append(name)
    tt_rows = 0
    for left_index, left in enumerate(T):
        for right in T[left_index:]:
            for row in product(
                triple_by_state[left], triple_by_state[right],
                *(singleton_by_position[position] for position in left + right),
            ):
                tt_rows += is_cover(row, signatures)
    assert tt_rows == 0

    carrier_rows = []
    for row in product(
        triple_by_state[STATE35], singleton_by_position[2], singleton_by_position[4]
    ):
        if is_cover(("r23", "B", "X", *row), signatures):
            carrier_rows.append(row)
            q, p3, p5 = row
            assert signatures[p3] != signatures["Y"]
            assert signatures[p5] != signatures["D"]
            assert not any(sep(companion, p3, "Y", signatures) for companion in ("r23", "B", "X"))
            assert not any(sep(companion, p5, "D", signatures) for companion in ("r23", "B", "X"))
    assert carrier_rows

    print(json.dumps({
        "status": "sat_common_trivalent_vertex_partition",
        "vertices": len(VERTICES),
        "named_matching_occurrences": len(BOUNDARY),
        "distinct_signatures": len(set(signatures.values())),
        "selected_TT_rows_forbidden": forbidden_tt_rows,
        "actual_selected_TT_rows": tt_rows,
        "selected_state35_candidates": endpoint_candidates,
        "actual_selected_state35_decompositions": len(carrier_rows),
        "A_absent_in_selected_family": True,
        "both_endpoint_intersections_empty": True,
        "signatures": signatures,
        "missing_graph_condition": (
            "proper incidence stubs are not paired consistently into common "
            "edge objects; consequently this is not a pole and not a full PM closure"
        ),
    }, indent=2, sort_keys=True))
    print("VERTEX_PARTITION_SATURATED_BC_EMPTY_COUNTERMODEL_FOUND")


if __name__ == "__main__":
    main()
