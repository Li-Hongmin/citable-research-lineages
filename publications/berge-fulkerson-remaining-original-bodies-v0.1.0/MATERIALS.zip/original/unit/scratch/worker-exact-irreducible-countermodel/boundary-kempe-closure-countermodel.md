# Boundary Kempe closure alone does not exclude the two mixed carrier projections

Let the seven labelled terminal ends be

\[
1,2_a,2_b,3_a,3_b,4,5,
\]

where the two ends carrying label 2, and likewise those carrying label 3,
meet the corresponding doubled terminal vertex.  A proper three-edge-colouring
induces a three-colour assignment to these ends.  After quotienting by a
global colour permutation, write

\[
(rs\mid tu;j)
\]

for a boundary pattern whose singleton colour class has label \(j\) and
whose two triple colour classes have missing pairs \(rs\) and \(tu\).  The
two required patterns are

\[
B=(15\mid24;2),\qquad X=(13\mid45;3).
\]

The finite boundary Kempe system below retains the labelled ends but forgets
the interior of the carrier.  Its states are the canonical colour
assignments satisfying

\[
\operatorname{sort}(|C_0|,|C_1|,|C_2|)\in
\{(1,3,3),(1,1,5)\},
\]

with \(2_a,2_b\) and \(3_a,3_b\) differently coloured.  For each of the
three colour pairs, a local configuration chooses a perfect pairing of the
terminal ends carrying those colours.  If the two ends of one doubled
terminal carry exactly that colour pair, their forced length-two terminal
path requires them to be paired with one another.  Switching one paired
path swaps its two endpoint colours.

This model has 40 canonical states.  Removing every \((1,1,5)\) A state and
every TT state leaves 24 exact-negative SS/ST states and 216 candidate local
pairing triples.  A greatest-fixed-point deletion removes no state: every
one of the 24 states has a pairing triple all of whose individual
component-switch targets remain among the 24.

More sharply, the exact-negative quotient consists of two three-type Kempe
blocks,

\[
\begin{aligned}
\mathcal K_B={}&\{(15\mid24;2),(14\mid15;1),(14\mid25;2)\},\\
\mathcal K_X={}&\{(13\mid45;3),(14\mid35;3),(14\mid45;4)\}.
\end{aligned}
\]

Each type has four canonical assignments according to the labelled-copy
orientations at 2 and 3.  For every one of these assignments there is an
explicit pairing triple whose switches stay in its displayed block; at the
type level the targets of each selected triple collectively meet all three
types of that block.  Hence the union of the two blocks gives a finite
Kempe-closed abstract system containing both \(B\) and \(X\), but containing
neither A nor TT.

The labelled statement is irreducible.  A direct search of all state subsets
meeting at least one of the four labelled realizations of \(B\) and at least
one of the four realizations of \(X\) tests 14,745,600 eligible subsets.  The
smallest closed subsystem has all 24 states.  Thus no proper subset of the
exact-negative labelled universe supports both required projections, even
when every selected state may choose its most favourable pairing triple.
The six quotient types are therefore a compact description of a 24-state
labelled countermodel, rather than six interchangeable labelled states.

## Why this is a necessary abstraction of a real carrier

For a real degree-three carrier, the bichromatic subgraph for any colour
pair has internal degree zero or two.  Its terminal path components
therefore pair exactly the boundary ends carrying those colours, including
the forced doubled-terminal pairing above.  Switching any such component
produces another proper colouring of the same carrier.  If that carrier has
no A or TT colouring, all switch targets remain in the 24-state universe.
Consequently its actual boundary colourings and actual terminal-path
pairings would form a closed subsystem of this finite model.  The model is
therefore a valid necessary relaxation of real carrier Kempe closure.

The countermodel shows that these boundary facts alone cannot prove that a
carrier admitting \(B\) and \(X\) must admit A or TT.  It is not a carrier,
and it does not disprove the corresponding statement for real cubic
copy-multigraphs.  Three joint-realizability conditions have deliberately
been discarded:

1. the three bichromatic pairing systems chosen at one state must all arise
   from one common internal degree-three copy-multigraph;
2. all 24 state configurations must be colourings of that same graph, and a
   component switch transports the other two bichromatic decompositions
   rather than allowing the target state to choose an unrelated fresh
   triple;
3. the fixed matchings \(A,C,D\) assign common edge owners and an alternating
   phase to the carrier incidences, including the invisible \(K(e)=0\)
   edges.  Terminal pairings alone do not encode the set
   \(A\mathbin\triangle C\) or the overload condition
   \(B\cap X\cap(A\mathbin\triangle C)\).

Thus the next decisive interface is simultaneous interior realizability and
switch transport on one fixed carrier, with the fixed-half owner/phase data
retained.  Further boundary-only closure or larger-order graph enumeration
cannot repair this abstraction.

## Certificate and scope

`audit_boundary_kempe_state_system.py` performs the construction, fixed-point
test, exhaustive minimum-subsystem search, and internal assertions.  Its
output `boundary_kempe_state_system_result.txt` records, for every one of the
24 labelled states, a concrete triple of terminal-end pairings and every
component-switch transition.  The final Omen run used Python 3.10.12, one
process, a 1 GiB virtual-memory cap, and no graph enumeration, SAT solver,
CEGAR loop, random search, or new pole.  No permanent note was modified.

