# Binary \(T\)-polymorphism separator remains undecided

## Exact finite question

Let

\[
D={ [6]\choose2}
\]

and let \(T(a,b,c)\) hold when \(a,b,c\) are pairwise disjoint and have
union \([6]\). Thus \(|D|=15\) and the ordered relation \(T\) has 90
triples.

Let

\[
S=\{13,14,24,25,35\},\qquad
\overline S=\{12,15,23,34,45\}.
\]

The relation \(R_{\rm XII}\subseteq D^5\) consists of the five-terminal
label tuples for which the six colour degrees are

\[
3,3,1,1,1,1
\]

and the omitted terminal pairs of the two degree-three colours are not both
in \(\overline S\). The finite census is

\[
\begin{array}{c|rrrr|r}
 &A&SS&ST&TT&\text{all admissible boundary tuples}\\ \hline
\text{labelled tuples}&720&5850&10800&5850&23220.
\end{array}
\]

Hence

\[
|R_{\rm XII}|=5850+10800=16650.
\]

Its 40 boundary-type orbits have labelled orbit-size distribution
\(90^5,360^{25},720^{10}\). This independently matches the Case-XII
decomposition into 15 \(SS\) and 25 \(ST\) types.

The question tested was exactly whether there exists

\[
f:D^2\longrightarrow D
\]

which preserves \(T\) but fails to preserve \(R_{\rm XII}\).

## Why such a separator would exclude a real exact-Case-XII pole

For a BF cover, use its six matching occurrences as colours. Every edge
object then has the two-subset label of the occurrences containing it. At
each cubic vertex the labels of the three incident objects partition the
six colours, so they satisfy \(T\). The two incidences of every internal
proper edge have equal labels. The five-terminal relation of a fixed pole is
therefore obtained from copies of \(T\) and equality by conjunction and
existential quantification over internal labels: it is pp-defined from
\(T\). Conversely, any satisfying label assignment gives six perfect
matchings by taking, for each colour, the edge objects whose labels contain
that colour. The local \(T\)-constraint makes each colour meet every cubic
vertex exactly once, and every edge belongs to exactly two colours. Thus
the pp description is exact, not merely a necessary relaxation.

Every polymorphism of \(T\) preserves equality and every pp-defined
relation. Moreover, a BF witness can have its six occurrences arbitrarily
permuted. Thus support of all forty Case-XII boundary types gives every
labelled tuple in \(R_{\rm XII}\), while absence of \(A\) and \(TT\) removes
exactly the other admissible tuples. A binary polymorphism preserving \(T\)
but not \(R_{\rm XII}\) would consequently prove that no real pole can have
exact Case-XII support.

## Complete SAT encoding

Identify \(D\) with the vertices of \(KG(6,2)\). A binary operation \(f\)
preserves \(T\) if and only if it is a graph homomorphism

\[
KG(6,2)^2\longrightarrow KG(6,2).
\tag{1}
\]

For the forward direction, any two disjoint two-sets extend uniquely to a
\(T\)-triple, so preservation of \(T\) preserves adjacency. Conversely,
the three coordinatewise pairs formed from two \(T\)-triples are pairwise
adjacent in the categorical product. Their three images under a graph
homomorphism are pairwise disjoint two-sets, hence form a \(T\)-triple.

The encoding used six Boolean incidence variables for each of the 225
values \(f(a,b)\), constrained each output to have size two, and imposed
disjointness on the 4050 edges of \(KG(6,2)^2\). Two symbolic five-tuples
\(x,y\) were constrained to lie in \(R_{\rm XII}\), and a third tuple was
linked coordinatewise by

\[
z_i=f(x_i,y_i).
\]

Finally \(z\notin R_{\rm XII}\) was asserted. Therefore SAT is equivalent
to a binary separator and UNSAT is equivalent to every binary
\(T\)-polymorphism preserving \(R_{\rm XII}\).

## Outcome and boundary

The single bounded Omen run returned:

    solver result: unknown
    reason: timeout
    elapsed: 217.004304 s
    maximum RSS: 89,476 KiB

The exact solver accumulated 1,003,032 conflicts and 2,135,885 decisions
before its internal deadline. It produced neither a separator table nor an
UNSAT proof. Consequently:

- no impossibility theorem for real exact Case XII follows;
- no classification of binary polymorphisms follows;
- it is not established that all binary polymorphisms are essentially
  unary or that they preserve \(R_{\rm XII}\);
- no arity-three query, graph search, or second encoding was started.

This is strictly an undecided finite interface, not a route closure.

## Reproduction

The run used one Omen process, ulimit -v 1048576, an external 240-second
timeout, and Z3 5.1.0.

- Solver: solve_binary_t_polymorphism_case_xii_separator.py
- SAT-certificate verifier: verify_binary_t_polymorphism_separator.py
- Result: binary_t_polymorphism_case_xii_separator_result.json
- Omen log: binary_t_polymorphism_case_xii_omen_run.log
- Timing: binary_t_polymorphism_case_xii_omen_timing.txt
- Result-file SHA256:
  de2a7e9442df5f3e181fc5a8ecba2d4244bb2f9fb8d02eaceb96a2f19c0dd597
- Marker: BINARY_T_POLYMORPHISM_UNDECIDED
