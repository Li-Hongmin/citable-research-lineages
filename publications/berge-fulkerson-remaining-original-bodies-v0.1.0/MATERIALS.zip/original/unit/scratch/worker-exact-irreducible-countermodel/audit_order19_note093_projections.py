#!/usr/bin/env python3
"""Audit the four Note-093 projections in the fixed Note-081 pole.

This imports the frozen construction but does not modify its bundle.  It
enumerates the complete 66-perfect-matching closure, both complete carrier
decomposition families, the four F-intersection-G tests, and the exact
Note-082 sequential/forced-intermediate continuations.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import importlib.util
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
DEFAULT_BASE = (
    HERE.parent.parent
    / "computations"
    / "bundles"
    / "guarded-repeated-star-selected-pm-countermodel"
    / "verify.py"
)


def load_base(path: Path):
    spec = importlib.util.spec_from_file_location("note081_base", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def add_load(matchings):
    return Counter(edge for matching in matchings for edge in matching)


def boundary(matching):
    return tuple(i + 1 for i in range(5) if f"s{i}" in matching)


def state(matching):
    assert len(boundary(matching)) == 3
    return tuple(sorted(set(range(1, 6)) - set(boundary(matching))))


def same_load(left, right, objects):
    a = add_load(left)
    b = add_load(right)
    return all(a[e] == b[e] for e in objects)


def complement_load(fixed, objects):
    used = add_load(fixed)
    result = {edge: 2 - used[edge] for edge in objects}
    assert all(value in (0, 1, 2) for value in result.values())
    return result


def has_load(row, target, objects):
    load = add_load(row)
    return all(load[edge] == target[edge] for edge in objects)


def sep(companion, source, target):
    return (target - source) <= companion and not (companion & (source - target))


def signed_matching(plus_a, plus_b, minus_c, objects, family_set):
    values = Counter(plus_a)
    values.update(plus_b)
    values.subtract(minus_c)
    if any(values[e] not in (0, 1) for e in objects):
        return None
    result = frozenset(edge for edge in objects if values[edge] == 1)
    return result if result in family_set else None


def label_matching(matching, labels, ids):
    names = labels.get(matching)
    if names:
        return "/".join(sorted(names))
    return ids[matching]


def decompositions(classes, carrier, objects, i, j):
    triple_boundary = tuple(sorted(set(range(1, 6)) - {i, j}))
    output = []
    for q in classes.get(triple_boundary, ()):
        for p_i in classes.get((i,), ()):
            for p_j in classes.get((j,), ()):
                row = (q, p_i, p_j)
                if has_load(row, carrier, objects):
                    output.append(row)
    return tuple(output)


def do_splice(row, source_pos, target, companion_pos, objects, family_set):
    if companion_pos == source_pos:
        return None
    updated = signed_matching(
        row[companion_pos], row[source_pos], target, objects, family_set
    )
    if updated is None:
        return None
    new_row = list(row)
    new_row[source_pos] = target
    new_row[companion_pos] = updated
    assert same_load(row, new_row, objects)
    return tuple(new_row)


def sequential_fibres(
    row,
    source_positions,
    targets,
    literal_fixed_positions,
    objects,
    family_set,
):
    original = tuple(row)
    output = []
    for order in ((0, 1), (1, 0)):
        first, second = order
        pos_first = source_positions[first]
        pos_second = source_positions[second]
        target_first = targets[first]
        target_second = targets[second]

        first_options = []
        if row[pos_first] == target_first:
            first_options.append((tuple(row), "already"))
        else:
            for companion in range(6):
                changed = do_splice(
                    row, pos_first, target_first, companion, objects, family_set
                )
                if changed is not None:
                    first_options.append((changed, companion))

        for middle, first_companion in first_options:
            second_options = []
            if middle[pos_second] == target_second:
                second_options.append((middle, "already"))
            else:
                for companion in range(6):
                    changed = do_splice(
                        middle,
                        pos_second,
                        target_second,
                        companion,
                        objects,
                        family_set,
                    )
                    if changed is not None:
                        second_options.append((changed, companion))

            for final, second_companion in second_options:
                if any(final[p] != original[p] for p in literal_fixed_positions):
                    continue
                assert final[pos_first] == target_first
                assert final[pos_second] == target_second
                output.append(
                    {
                        "order": order,
                        "first_companion_position": first_companion,
                        "second_companion_position": second_companion,
                        "middle": middle,
                        "final": final,
                    }
                )
    return output


def forced_intermediate_fibres(
    row, source_positions, targets, triple_positions, objects, family_set
):
    output = []
    for first, other in ((0, 1), (1, 0)):
        source_first = row[source_positions[first]]
        source_other = row[source_positions[other]]
        target_first = targets[first]
        target_other = targets[other]
        intermediate = signed_matching(
            target_first, target_other, source_other, objects, family_set
        )
        if intermediate is None:
            continue
        for triple_pos in triple_positions:
            updated_triple = signed_matching(
                row[triple_pos], source_first, intermediate, objects, family_set
            )
            if updated_triple is not None:
                output.append(
                    {
                        "intermediate_for_source": first,
                        "triple_position": triple_pos,
                        "intermediate": intermediate,
                        "updated_triple": updated_triple,
                    }
                )
    return output


def main():
    base_path = Path(__import__("sys").argv[1]) if len(__import__("sys").argv) > 1 else DEFAULT_BASE
    base = load_base(base_path)
    objects = frozenset(base.PROPER) | {f"s{i}" for i in base.TERMINALS}
    family = tuple(sorted(base.enumerate_all_perfect_matchings(), key=lambda m: tuple(sorted(map(str, m)))))
    family_set = set(family)
    assert len(family) == 66

    ids = {matching: f"M{index:02d}" for index, matching in enumerate(family)}
    labels = defaultdict(list)
    designated = {}
    for name in base.BASE_BOUNDARY:
        matching = base.guarded_objects(name)
        assert matching in family_set
        designated[name] = matching
        labels[matching].append(name)

    classes = defaultdict(list)
    for matching in family:
        classes[boundary(matching)].append(matching)

    fixed23 = (designated["r23"], designated["B"], designated["X"])
    fixed34 = (designated["r34"], designated["Y"], designated["C"])
    carrier23 = complement_load(fixed23, objects)
    carrier34 = complement_load(fixed34, objects)

    all_states = tuple(combinations(range(1, 6), 2))
    all_dec23 = {
        state_pair: decompositions(
            classes, carrier23, objects, state_pair[0], state_pair[1]
        )
        for state_pair in all_states
    }
    all_dec34 = {
        state_pair: decompositions(
            classes, carrier34, objects, state_pair[0], state_pair[1]
        )
        for state_pair in all_states
    }
    dec23_35 = all_dec23[(3, 5)]
    dec34_13 = all_dec34[(1, 3)]

    tests = (
        ("P3->Y", fixed23, dec23_35, 1, designated["Y"]),
        ("P5->D", fixed23, dec23_35, 2, designated["D"]),
        ("P1->A", fixed34, dec34_13, 1, designated["A"]),
        ("P3'->X", fixed34, dec34_13, 2, designated["X"]),
    )

    projection_results = {}
    for test_name, fixed, decomps, source_index, target in tests:
        projection = {row[source_index] for row in decomps}
        target_class = boundary(target)
        assert len(target_class) == 1
        fixed_preimages = tuple(
            {
                matching
                for matching in classes[target_class]
                if sep(companion, matching, target)
            }
            for companion in fixed
        )
        sign_set = {target}.union(*fixed_preimages)
        intersection = projection & sign_set
        reasons = {}
        for matching in intersection:
            why = []
            if matching == target:
                why.append("target_entry")
            for fixed_index, companion in enumerate(fixed):
                if sep(companion, matching, target):
                    why.append(f"fixed_sep:{fixed_index}")
            if why:
                reasons[matching] = tuple(why)
        projection_results[test_name] = {
            "projection_size": len(projection),
            "fixed_preimage_sizes": tuple(len(part) for part in fixed_preimages),
            "sign_set_size": len(sign_set),
            "intersection": reasons,
        }

    continuation_results = {}
    carrier_specs = (
        (
            "K23",
            fixed23,
            dec23_35,
            (designated["Y"], designated["D"]),
            (2, 3),
        ),
        (
            "K34",
            fixed34,
            dec34_13,
            (designated["A"], designated["X"]),
            (2, 3),
        ),
    )
    for carrier_name, fixed, decomps, targets, literal_fixed_positions in carrier_specs:
        sequential = []
        forced = []
        for q, p_first, p_second in decomps:
            row = (q, fixed[0], fixed[1], fixed[2], p_first, p_second)
            for witness in sequential_fibres(
                row, (4, 5), targets, literal_fixed_positions, objects, family_set
            ):
                sequential.append((row, witness))
            for witness in forced_intermediate_fibres(
                row, (4, 5), targets, (0, 1), objects, family_set
            ):
                forced.append((row, witness))
        continuation_results[carrier_name] = {
            "sequential": sequential,
            "forced": forced,
        }

    def printable_matching(matching):
        return label_matching(matching, labels, ids)

    def printable_row(row):
        return tuple(printable_matching(m) for m in row)

    print("ORDER19_NOTE093_AUDIT")
    print("pm_count", len(family))
    print("class_sizes", {str(key): len(value) for key, value in sorted(classes.items())})
    for carrier_name, all_decomps in (("K23", all_dec23), ("K34", all_dec34)):
        print(
            "all_carrier_state_counts",
            carrier_name,
            {str(key): len(value) for key, value in all_decomps.items()},
        )
        for state_pair, rows in all_decomps.items():
            for row in rows:
                print(
                    " carrier_decomposition",
                    carrier_name,
                    state_pair,
                    printable_row(row),
                )
    print("carrier_decompositions", {"K23_state35": len(dec23_35), "K34_state13": len(dec34_13)})
    for test_name, result in projection_results.items():
        print(
            "projection_test",
            test_name,
            "projection_size",
            result["projection_size"],
            "fixed_preimage_sizes",
            result["fixed_preimage_sizes"],
            "sign_set_size",
            result["sign_set_size"],
            "intersection_size",
            len(result["intersection"]),
        )
        for matching, why in sorted(result["intersection"].items(), key=lambda item: printable_matching(item[0])):
            rows = (
                dec23_35 if test_name in ("P3->Y", "P5->D") else dec34_13
            )
            source_index = 1 if test_name in ("P3->Y", "P1->A") else 2
            containing = [printable_row(row) for row in rows if row[source_index] == matching]
            print(" intersection_witness", printable_matching(matching), why, containing)

    for carrier_name, result in continuation_results.items():
        print(
            "two_splice",
            carrier_name,
            "sequential_count",
            len(result["sequential"]),
            "forced_count",
            len(result["forced"]),
        )
        for row, witness in result["sequential"]:
            print(
                " sequential_witness",
                printable_row(row),
                witness["order"],
                witness["first_companion_position"],
                witness["second_companion_position"],
                printable_row(witness["middle"]),
                printable_row(witness["final"]),
            )
        for row, witness in result["forced"]:
            print(
                " forced_witness",
                printable_row(row),
                witness["intermediate_for_source"],
                witness["triple_position"],
                printable_matching(witness["intermediate"]),
                printable_matching(witness["updated_triple"]),
            )

    complete_family, support_profile = base.complete_family_support_profile(objects)
    assert len(complete_family) == 66
    print("complete_support_profile", dict(sorted(support_profile.items())))
    print(
        "all_four_empty",
        all(not result["intersection"] for result in projection_results.values()),
    )
    print("ORDER19_NOTE093_PROJECTIONS_VERIFIED")


if __name__ == "__main__":
    main()
