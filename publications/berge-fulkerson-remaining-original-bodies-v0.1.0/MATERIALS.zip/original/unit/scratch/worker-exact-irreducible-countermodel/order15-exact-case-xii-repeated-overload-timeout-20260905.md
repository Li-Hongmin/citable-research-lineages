# The directed order-fifteen exact Case-XII repeated-overload test timed out

## Question and outcome

The fixed-order synthesis asked whether an order-fifteen simple connected
cubic 5-pole can simultaneously satisfy:

\[
 \begin{gathered}
 \text{girth at least five and the Note-019 proper-cut boundary},\\
 \text{complete ordinary BF support exactly }15\ SS+25\ ST,\\
 A=0,\quad T\text{-loops}=0,\quad T\text{--}T=0,\\
 \text{four literal repeated-extension pivot rows},\\
 \text{all three prescribed singleton targets overloaded}.
 \end{gathered}                                      \tag{1}
\]

The directed Omen run reached its hard wall-clock limit.  It produced neither
a real pole satisfying (1) nor a solver proof of infeasibility.  Therefore the
order-fifteen question remains **undecided** by this pulse.

## Constraint coverage

One SAT object contained the graph variables and six common
perfect-matching vectors for each of all forty positive Case-XII types.  The
five positive \(S\)-loops were encoded as doubled Tait colourings.  Four
specific \(D_5\) witnesses were tied together coordinatewise so that their
singleton slots were the literal identities

\[
 A,B,C,D,X,Y
\]

with \(X\ne Y\), and the three overload requirements for
\(BDXY,ACXY,ABDY\) were imposed directly.  The seven selected-pair
intersections forced by no \(T\)-loop were also hard constraints.  Triangles
and squares were excluded in the initial object.

For every SAT graph, the existing evaluator enumerated its complete perfect-
matching family and complete ordinary BF support.  Sound CEGAR clauses then
removed every concrete extra Tait state, \(A\)-cover, forbidden ordinary BF
type, or Note-019 cut violation.  Thus a SAT acceptance would have checked
all clauses in (1), while a solver `unsat` would have been a complete
fixed-order exclusion.  Neither terminal status occurred.

## Observed finite trace

The run completed 55 closure evaluations, indexed 0 through 54.  Every model
already contained all forty required positive types.  Their complete closure
statistics were

\[
\begin{array}{c|rrr}
\text{ordinary support size}&53&54&55\\ \hline
\text{number of models}&3&13&39
\end{array}
\]

so every model had between 13 and 15 forbidden \(T\)-loop/\(T\)--\(T\)
types.  The number of extra Tait states had distribution

\[
 3^2,\qquad4^{17},\qquad5^{36},
\]

and no model had Tait state set exactly \(S\).  Twelve of the 55 models had
no \(A\)-cover, showing that the surviving obstruction in those models was
specifically the negative \(T\)-support rather than \(A\).  All 55 had
40--46 perfect matchings and all passed the Note-019 cut check.

These counts are diagnostics only.  They do not imply infeasibility and are
not a census.

## Execution boundary

The correct bundled evaluator was explicitly selected before the final run.
The Omen command was

```text
timeout 235s python3 -u \
  synthesize_order15_exact_case_xii_repeated_overload.py \
  --seconds 230 --json result.json
```

The evaluator was still between CEGAR rounds when the outer process stopped,
so the authoritative termination is `timeout` exit status 124; no result JSON
or mathematical success marker was produced.  Peak RSS was 149,728 KB.

The run directory is

```text
[local archival reference]
```

and the synthesis source SHA-256 is

```text
57b2640f75fc71afc4d9ce8da94862593f5888f49974d1f6a12b80da8d5abe3c
```

No order seventeen instance, graph census, or adjacent search was attempted.
