#!/usr/bin/env python3
"""Diagnose the eight Note-024 R3--R1 partial repeated-star selections.

This is a fixed-instance standard-library calculation.  It compares each
literal singleton target with every actual R2 row, resolves same-boundary
single-cycle exchange distances, and records only local TT/A rows supported
by identities in the three-row batch.
"""

from collections import Counter, defaultdict, deque
from itertools import combinations_with_replacement, product
import json

import audit_note024_repeated_star as base


POSITIONS = frozenset(range(1, 6))
PAIR_SET = tuple((i, j) for i in range(1, 6) for j in range(i + 1, 6))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(set(PAIR_SET) - set(S))


def cycle_components(first, second):
    diff = set(first) ^ set(second)
    adjacency = defaultdict(set)
    for edge in diff:
        if isinstance(edge, str):
            raise AssertionError("same-boundary difference contains a semiedge")
        u, v = edge
        adjacency[u].add(v)
        adjacency[v].add(u)
    if not adjacency:
        return tuple()
    assert all(len(neighbours) == 2 for neighbours in adjacency.values())
    unseen = set(adjacency)
    components = []
    while unseen:
        start = min(unseen)
        stack = [start]
        vertices = set()
        while stack:
            vertex = stack.pop()
            if vertex in vertices:
                continue
            vertices.add(vertex)
            stack.extend(adjacency[vertex] - vertices)
        unseen -= vertices
        component_edges = frozenset(
            edge for edge in diff
            if not isinstance(edge, str) and edge[0] in vertices
        )
        components.append(component_edges)
    return tuple(sorted(components, key=lambda c: (len(c), sorted(c))))


def exchange_graph(classes):
    adjacency = defaultdict(set)
    for boundary_class, matchings in classes.items():
        for first in matchings:
            adjacency[first]
        for i, first in enumerate(matchings):
            for second in matchings[i + 1:]:
                if len(cycle_components(first, second)) == 1:
                    adjacency[first].add(second)
                    adjacency[second].add(first)
    return adjacency


def shortest_exchange_path(adjacency, source, target):
    if source == target:
        return (source,)
    queue = deque([source])
    parent = {source: None}
    while queue:
        current = queue.popleft()
        for following in sorted(adjacency[current], key=lambda matching: IDS[matching]):
            if following in parent:
                continue
            parent[following] = current
            if following == target:
                path = [target]
                while parent[path[-1]] is not None:
                    path.append(parent[path[-1]])
                return tuple(reversed(path))
            queue.append(following)
    return None


def multiset_overlap(first, second):
    return sum((Counter(first) & Counter(second)).values())


def enumerate_tt_rows(classes):
    rows = {}
    for first, second in combinations_with_replacement(sorted(T), 2):
        slots = first + second
        for row in base.cell_rows(classes, first, second, slots):
            key = tuple(sorted(row, key=lambda matching: IDS[matching]))
            rows.setdefault(key, (first, second, row))
    return tuple(rows.values())


def enumerate_a_rows(classes):
    rows = {}
    groups = [classes[(1, 2, 3, 4, 5)]] + [classes[(i,)] for i in range(1, 6)]
    if any(not group for group in groups):
        return tuple()
    for row in product(*groups):
        if base.is_double_cover(row):
            key = tuple(sorted(row, key=lambda matching: IDS[matching]))
            rows.setdefault(key, row)
    return tuple(rows.values())


def ids(row):
    return tuple(IDS[matching] for matching in row)


def edge_names(edges):
    return tuple(sorted((str(edge) for edge in edges)))


def path_record(path):
    return {
        "ids": ids(path),
        "cycles": tuple(
            edge_names(cycle_components(first, second)[0])
            for first, second in zip(path, path[1:])
        ),
    }


def local_forbidden_rows(batch, tt_rows, a_rows):
    available = Counter(batch)
    output = []
    for kind, first, second, row in (
        ("TT", first, second, row) for first, second, row in tt_rows
    ):
        needed = Counter(row)
        if all(needed[matching] <= available[matching] for matching in needed):
            output.append({"kind": kind, "type": (first, second), "row": ids(row)})
    for row in a_rows:
        needed = Counter(row)
        if all(needed[matching] <= available[matching] for matching in needed):
            output.append({"kind": "A", "type": "12345", "row": ids(row)})
    return tuple(output)


def paired_row_equalities(source_row, forbidden_rows):
    output = []
    for kind, first, second, target_row in (
        ("TT", first, second, row) for first, second, row in forbidden_rows
    ):
        if multiset_overlap(source_row, target_row) != 4:
            continue
        common = Counter(source_row) & Counter(target_row)
        left = list((Counter(source_row) - common).elements())
        right = list((Counter(target_row) - common).elements())
        assert len(left) == len(right) == 2
        assert base.load(left) == base.load(right)
        output.append({
            "kind": kind,
            "type": (first, second),
            "common": tuple(sorted((IDS[m] for m in common.elements()))),
            "left": tuple(sorted((IDS[m] for m in left))),
            "right": tuple(sorted((IDS[m] for m in right))),
        })
    return tuple(output)


def complement_pair_decompositions(quartet, family):
    quartet_load = base.load(quartet)
    if any(quartet_load[edge] > 2 for edge in base.OBJECTS):
        return tuple()
    target_load = {
        edge: 2 - quartet_load[edge] for edge in base.OBJECTS
    }
    output = []
    for index, first in enumerate(family):
        for second in family[index:]:
            if not base.has_load((first, second), target_load):
                continue
            boundaries = (base.boundary(first), base.boundary(second))
            sizes = tuple(sorted(map(len, boundaries)))
            if sizes == (1, 5):
                category = "A"
                state_type = "12345"
            else:
                assert sizes == (3, 3)
                states = tuple(sorted(base.complement_state(state) for state in boundaries))
                if all(state in S for state in states):
                    category = "SS"
                elif all(state in T for state in states):
                    category = "TT"
                else:
                    category = "ST"
                state_type = states
            output.append({
                "category": category,
                "type": state_type,
                "pair": (IDS[first], IDS[second]),
                "six_row": ids((first, second, *quartet)),
            })
    return tuple(output)


def overload_record(quartet):
    counts = base.load(quartet)
    return tuple(
        {"edge": str(edge), "load": counts[edge]}
        for edge in base.OBJECTS if counts[edge] > 2
    )


def matching_record(matching):
    return {
        "id": IDS[matching],
        "boundary": base.boundary(matching),
        "edges": tuple(sorted(str(edge) for edge in matching)),
    }


def required_cycle_exchange_closure(batch, paths, family_set):
    cycles = tuple(
        first ^ second
        for path in paths for first, second in zip(path, path[1:])
    )
    closure = set(batch)
    changed = True
    while changed:
        changed = False
        for matching in tuple(closure):
            for cycle in cycles:
                flipped = matching ^ cycle
                if flipped in family_set and flipped not in closure:
                    closure.add(flipped)
                    changed = True
    return closure, cycles


def occurrence_reachability(source, cycles, family_set):
    queue = deque([source])
    paths = {source: tuple()}
    while queue:
        current = queue.popleft()
        for cycle_index, cycle in enumerate(cycles):
            following = current ^ cycle
            if following not in family_set or following in paths:
                continue
            paths[following] = paths[current] + ((cycle_index, following),)
            queue.append(following)
    return paths


def inject_forbidden_row(target_row, labelled_batch, reachability):
    candidates = {
        target_index: tuple(
            source_index for source_index in range(len(labelled_batch))
            if target in reachability[source_index]
        )
        for target_index, target in enumerate(target_row)
    }
    order = sorted(candidates, key=lambda i: (len(candidates[i]), IDS[target_row[i]], i))
    if any(not candidates[i] for i in order):
        return None
    assignment = {}
    used = set()

    def search(depth):
        if depth == len(order):
            return True
        target_index = order[depth]
        for source_index in candidates[target_index]:
            if source_index in used:
                continue
            used.add(source_index)
            assignment[target_index] = source_index
            if search(depth + 1):
                return True
            del assignment[target_index]
            used.remove(source_index)
        return False

    if not search(0):
        return None
    provenance = []
    for target_index, target in enumerate(target_row):
        source_index = assignment[target_index]
        label, source = labelled_batch[source_index]
        path = reachability[source_index][target]
        provenance.append({
            "target_occurrence": target_index,
            "target_id": IDS[target],
            "source_occurrence": label,
            "source_id": IDS[source],
            "exchange_path": tuple(
                {"cycle_index": cycle_index, "result_id": IDS[result]}
                for cycle_index, result in path
            ),
        })
    return tuple(provenance)


def first_occurrence_preserving_forbidden_witness(
    labelled_batch, paths, family_set, tt_rows, a_rows
):
    cycles = tuple(
        first ^ second
        for path in paths for first, second in zip(path, path[1:])
    )
    reachability = tuple(
        occurrence_reachability(source, cycles, family_set)
        for _, source in labelled_batch
    )
    candidates = [
        ("TT", (first, second), row) for first, second, row in tt_rows
    ] + [("A", "12345", row) for row in a_rows]
    supported = []
    for kind, boundary_type, row in candidates:
        provenance = inject_forbidden_row(row, labelled_batch, reachability)
        if provenance is not None:
            supported.append({
                "kind": kind,
                "type": boundary_type,
                "row": ids(row),
                "uses_exchange": any(item["exchange_path"] for item in provenance),
                "provenance": provenance,
            })
    return {
        "supported_row_count": len(supported),
        "first": supported[0] if supported else None,
    }


def equality_against_nearest(nearest_row, target_decomposition):
    target_row_ids = target_decomposition["six_row"]
    target_row = tuple(FAMILY[index] for index in target_row_ids)
    common = Counter(nearest_row) & Counter(target_row)
    left = list((Counter(nearest_row) - common).elements())
    right = list((Counter(target_row) - common).elements())
    assert base.load(left) == base.load(right)
    return {
        "common": tuple(sorted(IDS[m] for m in common.elements())),
        "nearest_residual": tuple(sorted(IDS[m] for m in left)),
        "target_residual": tuple(sorted(IDS[m] for m in right)),
    }


def main():
    global FAMILY, IDS
    family = base.enumerate_perfect_matchings()
    FAMILY = family
    IDS = {matching: index for index, matching in enumerate(family)}
    classes = defaultdict(list)
    for matching in family:
        classes[base.boundary(matching)].append(matching)

    r1 = base.cell_rows(classes, (1, 3), (4, 5), (1, 3, 4, 5))
    r2 = base.cell_rows(classes, (1, 4), (2, 3), (1, 2, 3, 4))
    r3 = base.cell_rows(classes, (2, 4), (1, 5), (1, 2, 4, 5))
    assert (len(r1), len(r2), len(r3)) == (32, 22, 16)

    adjacency = exchange_graph(classes)
    family_set = set(family)
    tt_rows = enumerate_tt_rows(classes)
    a_rows = enumerate_a_rows(classes)
    pairs = []
    for row3 in r3:
        q24, r15, a, b, c, d = row3
        for row1 in r1:
            q13, r45, a1, x, c1, d1 = row1
            if (a1, c1, d1) != (a, c, d):
                continue
            target = (a, b, x, c)
            target_decompositions = complement_pair_decompositions(target, family)
            target_overload = overload_record(target)
            scored = []
            for row2 in r2:
                actual = row2[2:]
                mismatch = tuple(i for i in range(4) if actual[i] != target[i])
                paths = tuple(
                    shortest_exchange_path(adjacency, target[i], actual[i])
                    for i in mismatch
                )
                assert all(path is not None for path in paths)
                score = (
                    len(mismatch),
                    sum(len(path) - 1 for path in paths),
                    ids(row2),
                )
                scored.append((score, row2, mismatch, paths))
            best_score = min(item[0][:2] for item in scored)
            nearest = []
            for score, row2, mismatch, paths in scored:
                if score[:2] != best_score:
                    continue
                batch = tuple(row1) + tuple(row3) + tuple(row2)
                labelled_batch = tuple(
                    (f"R1.{name}", matching)
                    for name, matching in zip(("q13", "r45", "A", "X", "C", "D"), row1)
                ) + tuple(
                    (f"R3.{name}", matching)
                    for name, matching in zip(("q24", "r15", "A", "B", "C", "D"), row3)
                ) + tuple(
                    (f"R2.{name}", matching)
                    for name, matching in zip(("q14", "r23", "A", "B", "X", "C"), row2)
                )
                exchange_batch = batch + tuple(
                    matching
                    for path in paths for matching in path[1:-1]
                )
                exchange_closure, required_cycles = required_cycle_exchange_closure(
                    batch, paths, family_set
                )
                # Deliberately overpermit multiplicity here: a negative result
                # then excludes every occurrence assignment from this closure.
                overpermissive_closure_batch = tuple(
                    matching for matching in exchange_closure for _ in range(6)
                )
                nearest.append({
                    "r2": ids(row2),
                    "actual_singletons": ids(row2[2:]),
                    "actual_singleton_records": tuple(
                        matching_record(matching) for matching in row2[2:]
                    ),
                    "mismatch_positions": mismatch,
                    "exchange_paths": tuple(path_record(path) for path in paths),
                    "local_forbidden_rows": local_forbidden_rows(
                        batch, tt_rows, a_rows
                    ),
                    "exchange_augmented_local_forbidden_rows": local_forbidden_rows(
                        exchange_batch, tt_rows, a_rows
                    ),
                    "required_cycle_exchange_closure_ids": tuple(
                        sorted(IDS[matching] for matching in exchange_closure)
                    ),
                    "required_cycles": tuple(edge_names(cycle) for cycle in required_cycles),
                    "closure_local_forbidden_rows": local_forbidden_rows(
                        overpermissive_closure_batch, tt_rows, a_rows
                    ),
                    "occurrence_preserving_local_forbidden": (
                        first_occurrence_preserving_forbidden_witness(
                            labelled_batch, paths, family_set, tt_rows, a_rows
                        )
                    ),
                    "r2_to_tt_two_for_two_equalities": paired_row_equalities(
                        row2, tt_rows
                    ),
                    "equalities_to_target_decompositions": tuple(
                        target_decomposition | {
                            "equality": equality_against_nearest(
                                row2, target_decomposition
                            )
                        }
                        for target_decomposition in target_decompositions
                    ),
                })
            pairs.append({
                "r3": ids(row3),
                "r1": ids(row1),
                "target_singletons_ABXC": ids(target),
                "target_singleton_records": tuple(matching_record(m) for m in target),
                "target_overload": target_overload,
                "target_complement_decompositions": target_decompositions,
                "nearest_score_hamming_exchange_steps": best_score,
                "nearest": nearest,
            })

    assert len(pairs) == 8
    local_count_profile = tuple(
        tuple(
            nearest["occurrence_preserving_local_forbidden"]["supported_row_count"]
            for nearest in pair["nearest"]
        )
        for pair in pairs
    )
    assert local_count_profile == ((0, 0), (1, 1), (0, 0), (0,), (0,), (4,), (2,), (1,))
    pair_classification = tuple(
        "TT-accompanied" if all(count > 0 for count in counts) else "pure-identity"
        for counts in local_count_profile
    )
    assert pair_classification == (
        "pure-identity", "TT-accompanied", "pure-identity", "pure-identity",
        "pure-identity", "TT-accompanied", "TT-accompanied", "TT-accompanied",
    )
    assert not a_rows
    assert all(pair["target_overload"] for pair in pairs)
    assert all(not pair["target_complement_decompositions"] for pair in pairs)

    minimal_pair = pairs[0]
    minimal_nearest = next(
        nearest for nearest in minimal_pair["nearest"]
        if nearest["exchange_paths"][0]["ids"] == (20, 19)
    )
    minimal_pure_certificate = {
        "pair_index": 0,
        "r3": minimal_pair["r3"],
        "r1": minimal_pair["r1"],
        "target_singletons_ABXC": minimal_pair["target_singletons_ABXC"],
        "target_overload": minimal_pair["target_overload"],
        "nearest_r2": minimal_nearest["r2"],
        "mismatch_positions": minimal_nearest["mismatch_positions"],
        "exchange_paths": minimal_nearest["exchange_paths"],
        "target_singleton_records": minimal_pair["target_singleton_records"],
        "actual_singleton_records": minimal_nearest["actual_singleton_records"],
        "local_forbidden_supported_rows": (
            minimal_nearest["occurrence_preserving_local_forbidden"]["supported_row_count"]
        ),
    }
    print(json.dumps({
        "pm_count": len(family),
        "partial_pairs": len(pairs),
        "tt_row_count": len(tt_rows),
        "a_row_count": len(a_rows),
        "local_forbidden_count_profile": local_count_profile,
        "pair_classification": pair_classification,
        "minimal_pure_certificate": minimal_pure_certificate,
        "pairs": pairs,
    }, indent=2, sort_keys=True))
    print("NOTE024_PARTIAL_PAIR_MISMATCHES_DIAGNOSED")


if __name__ == "__main__":
    main()
