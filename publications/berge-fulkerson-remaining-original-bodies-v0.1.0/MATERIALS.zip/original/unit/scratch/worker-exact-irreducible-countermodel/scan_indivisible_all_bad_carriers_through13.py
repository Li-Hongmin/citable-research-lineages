#!/usr/bin/env python3
"""Find an indivisible all-bad common carrier through order thirteen.

The scan is deliberately narrower than a BF-support census.  It streams
unlabelled augmented graphs from ``geng``, enumerates their actual perfect
matchings, and looks only at the two fixed carrier rows

    B: (135, 234, 2),       X: (245, 123, 3).

For a common three-matching load K it then enumerates *all* decompositions of
K, rejects a T-loop or TT decomposition, and tests every actual B/X singleton
occurrence against every complementary (A,C,D)=(1,4,5) decomposition.

Only simple connected proper-bridgeless cubic five-poles are admitted.  A pole
is rejected in advance if a proper two-edge-cut separates a terminal-free
closed three-edge-colourable factor.  The implementation is pure stdlib and
keeps one pole at a time.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
import json
from pathlib import Path
import subprocess
import sys
import time


S = frozenset({(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)})
T = frozenset({(1, 2), (1, 5), (2, 3), (3, 4), (4, 5)})
ALL_POSITIONS = frozenset(range(1, 6))
B_PATTERN = tuple(sorted(((1, 3, 5), (2, 3, 4), (2,))))
X_PATTERN = tuple(sorted(((2, 4, 5), (1, 2, 3), (3,))))


def parse_graph6(text: str) -> tuple[int, tuple[tuple[int, int], ...]]:
    """Decode the small graph6 records produced here (order at most 14)."""
    data = text.strip().encode("ascii")
    if not data or data[0] == 126:
        raise ValueError("only graph6 orders below 63 are supported")
    n = data[0] - 63
    bits = []
    for value in data[1:]:
        value -= 63
        bits.extend((value >> shift) & 1 for shift in range(5, -1, -1))
    edges = []
    cursor = 0
    for upper in range(1, n):
        for lower in range(upper):
            if bits[cursor]:
                edges.append((lower, upper))
            cursor += 1
    return n, tuple(edges)


def adjacency(n: int, edges) -> tuple[tuple[int, ...], ...]:
    neighbours = [[] for _ in range(n)]
    for u, v in edges:
        neighbours[u].append(v)
        neighbours[v].append(u)
    return tuple(tuple(row) for row in neighbours)


def component_vertices(n: int, edges, start: int) -> frozenset[int]:
    neighbours = adjacency(n, edges)
    seen = {start}
    stack = [start]
    while stack:
        vertex = stack.pop()
        for other in neighbours[vertex]:
            if other not in seen:
                seen.add(other)
                stack.append(other)
    return frozenset(seen)


def connected(n: int, edges) -> bool:
    return n == 0 or len(component_vertices(n, edges, 0)) == n


def bridgeless(n: int, edges) -> bool:
    edge_tuple = tuple(edges)
    for index in range(len(edge_tuple)):
        if not connected(n, edge_tuple[:index] + edge_tuple[index + 1 :]):
            return False
    return True


def three_edge_colourable(vertices: frozenset[int], edges) -> bool:
    """Backtrack a proper three-edge-colouring of a cubic multigraph."""
    local = {vertex: [] for vertex in vertices}
    for index, (u, v) in enumerate(edges):
        if u == v:
            return False
        local[u].append(index)
        local[v].append(index)
    if any(len(local[vertex]) != 3 for vertex in vertices):
        raise AssertionError((vertices, edges, local))
    edge_order = sorted(
        range(len(edges)),
        key=lambda edge: -(len(local[edges[edge][0]]) + len(local[edges[edge][1]])),
    )
    used = {vertex: 0 for vertex in vertices}

    def search(depth: int) -> bool:
        if depth == len(edge_order):
            return True
        edge_index = edge_order[depth]
        u, v = edges[edge_index]
        unavailable = used[u] | used[v]
        for colour in range(3):
            bit = 1 << colour
            if unavailable & bit:
                continue
            used[u] |= bit
            used[v] |= bit
            if search(depth + 1):
                return True
            used[u] ^= bit
            used[v] ^= bit
        return False

    return search(0)


def proper_two_cut_audit(n: int, proper, terminals):
    """List proper 2-cuts and detect a terminal-free colourable closed side."""
    proper = tuple(proper)
    terminal_set = frozenset(terminals)
    cuts = []
    obstruction = None
    for left_index, right_index in combinations(range(len(proper)), 2):
        removed = {left_index, right_index}
        remaining = tuple(
            edge for index, edge in enumerate(proper) if index not in removed
        )
        first_component = component_vertices(n, remaining, 0)
        if len(first_component) == n:
            continue
        components = [first_component, frozenset(range(n)) - first_component]
        cut_record = {
            "cut_edges": (proper[left_index], proper[right_index]),
            "components": tuple(tuple(sorted(side)) for side in components),
            "terminal_counts": tuple(len(side & terminal_set) for side in components),
        }
        cuts.append(cut_record)
        for side in components:
            if side & terminal_set:
                continue
            cut_endpoints = []
            valid_cut = True
            for edge_index in (left_index, right_index):
                u, v = proper[edge_index]
                if (u in side) == (v in side):
                    valid_cut = False
                    break
                cut_endpoints.append(u if u in side else v)
            if not valid_cut:
                continue
            factor_edges = [
                edge for edge in proper
                if edge[0] in side and edge[1] in side
            ]
            factor_edges.append(tuple(cut_endpoints))
            factor_edges = tuple(factor_edges)
            if three_edge_colourable(side, factor_edges):
                obstruction = {
                    "cut_edges": (proper[left_index], proper[right_index]),
                    "factor_vertices": tuple(sorted(side)),
                    "closure_edge": tuple(cut_endpoints),
                }
                return tuple(cuts), obstruction
    return tuple(cuts), obstruction


def recover_pole(graph6: str, order: int):
    augmented_order, augmented_edges = parse_graph6(graph6)
    if augmented_order != order + 1:
        raise AssertionError((augmented_order, order))
    degrees = Counter(vertex for edge in augmented_edges for vertex in edge)
    if Counter(degrees.values()) != Counter({3: order, 5: 1}):
        return None
    apex = next(vertex for vertex, degree in degrees.items() if degree == 5)
    old_vertices = tuple(vertex for vertex in range(augmented_order) if vertex != apex)
    relabel = {vertex: index for index, vertex in enumerate(old_vertices)}
    terminal_old = tuple(sorted(
        v if u == apex else u
        for u, v in augmented_edges if apex in (u, v)
    ))
    terminals = tuple(relabel[vertex] for vertex in terminal_old)
    proper = tuple(sorted(
        (min(relabel[u], relabel[v]), max(relabel[u], relabel[v]))
        for u, v in augmented_edges if apex not in (u, v)
    ))
    if not connected(order, proper):
        return "disconnected"
    if not bridgeless(order, proper):
        return "bridged"
    return proper, terminals, apex, old_vertices


def enumerate_matchings(order: int, proper, terminals):
    """Return edge objects, PM bitmasks, boundary masks, and boundary classes."""
    objects = tuple(proper) + tuple((vertex,) for vertex in terminals)
    incident = [[] for _ in range(order)]
    for edge_index, endpoints in enumerate(objects):
        for vertex in endpoints:
            incident[vertex].append(edge_index)
    output = set()

    def search(uncovered: int, selected: int):
        if not uncovered:
            output.add(selected)
            return
        vertex_bit = uncovered & -uncovered
        vertex = vertex_bit.bit_length() - 1
        for edge_index in incident[vertex]:
            endpoint_mask = 0
            for endpoint in objects[edge_index]:
                endpoint_mask |= 1 << endpoint
            if uncovered & endpoint_mask == endpoint_mask:
                search(uncovered ^ endpoint_mask, selected | (1 << edge_index))

    search((1 << order) - 1, 0)
    matchings = tuple(sorted(output))
    semiedge_start = len(proper)
    boundary_masks = []
    classes = defaultdict(list)
    for matching_id, matching in enumerate(matchings):
        boundary_mask = 0
        for physical in range(5):
            if matching & (1 << (semiedge_start + physical)):
                boundary_mask |= 1 << physical
        boundary_masks.append(boundary_mask)
        classes[boundary_mask].append(matching_id)
    return objects, matchings, tuple(boundary_masks), classes


def triple_load(first: int, second: int, third: int, universe: int):
    if first & second & third:
        return None
    twice = (first & second) | (first & third) | (second & third)
    once = (first ^ second ^ third) & universe
    return twice, once


def complementary_load(first: int, second: int, third: int, universe: int):
    load = triple_load(first, second, third, universe)
    if load is None:
        return None
    used_twice, used_once = load
    return universe & ~(used_twice | used_once), used_once


def pair_sum_index(matchings):
    index = defaultdict(list)
    for first in range(len(matchings)):
        for second in range(first, len(matchings)):
            key = (matchings[first] & matchings[second], matchings[first] ^ matchings[second])
            index[key].append((first, second))
    return index


def all_three_decompositions(key, matchings, pair_index):
    twice, once = key
    allowed = twice | once
    rows = set()
    for third_id, third in enumerate(matchings):
        if third & ~allowed:
            continue
        residual_twice = twice & ~third
        residual_once = (once & ~third) | (twice & third)
        for first_id, second_id in pair_index.get((residual_twice, residual_once), ()):
            row = tuple(sorted((first_id, second_id, third_id)))
            rows.add(row)
    return tuple(sorted(rows))


def logical_boundary(physical_mask: int, orientation) -> tuple[int, ...]:
    inverse = {physical: logical for logical, physical in enumerate(orientation, 1)}
    return tuple(
        logical for physical, logical in sorted(inverse.items(), key=lambda item: item[1])
        if physical_mask & (1 << physical)
    )


def row_pattern(row, boundary_masks, orientation):
    return tuple(sorted(logical_boundary(boundary_masks[item], orientation) for item in row))


def classify_pattern(pattern):
    sizes = sorted(map(len, pattern))
    if sizes == [1, 1, 5]:
        return "A"
    if sizes != [1, 3, 3]:
        return "other"
    missing = tuple(sorted(
        tuple(sorted(ALL_POSITIONS - set(boundary)))
        for boundary in pattern if len(boundary) == 3
    ))
    if all(pair in T for pair in missing):
        return "T-loop" if missing[0] == missing[1] else "TT"
    if all(pair in S for pair in missing):
        return "S-loop" if missing[0] == missing[1] else "SS"
    return "ST"


def mask_for_physical(*positions: int) -> int:
    value = 0
    for position in positions:
        value |= 1 << position
    return value


def printable_object(obj, physical_to_logical):
    if len(obj) == 2:
        return f"{obj[0]}-{obj[1]}"
    physical = physical_to_logical["terminal_vertex_to_physical"][obj[0]]
    logical = physical_to_logical["physical_to_logical"][physical]
    return f"s{logical}@{obj[0]}"


def matching_record(matching_id, matchings, objects, boundary_masks, orientation, terminal_to_physical):
    physical_to_logical = {physical: logical for logical, physical in enumerate(orientation, 1)}
    helper = {
        "terminal_vertex_to_physical": terminal_to_physical,
        "physical_to_logical": physical_to_logical,
    }
    matching = matchings[matching_id]
    return {
        "id": matching_id,
        "boundary": logical_boundary(boundary_masks[matching_id], orientation),
        "edges": tuple(
            printable_object(objects[index], helper)
            for index in range(len(objects)) if matching & (1 << index)
        ),
    }


def inspect_pole(order, graph6, proper, terminals, two_cuts, counts):
    objects, matchings, boundary_masks, classes = enumerate_matchings(order, proper, terminals)
    counts["perfect_matchings"] += len(matchings)
    universe = (1 << len(objects)) - 1
    pairs = pair_sum_index(matchings)
    terminal_to_physical = {vertex: physical for physical, vertex in enumerate(terminals)}

    for orientation in permutations(range(5)):
        counts["orientations"] += 1
        a, b, x, c, d = orientation
        b_masks = (
            mask_for_physical(a, x, d),
            mask_for_physical(b, x, c),
            mask_for_physical(b),
        )
        x_masks = (
            mask_for_physical(b, c, d),
            mask_for_physical(a, b, x),
            mask_for_physical(x),
        )
        if any(not classes[mask] for mask in (*b_masks, *x_masks)):
            counts["orientation_missing_carrier_class"] += 1
            continue
        b_loads = defaultdict(list)
        for q_id, r_id, singleton_id in product(
            classes[b_masks[0]], classes[b_masks[1]], classes[b_masks[2]]
        ):
            key = triple_load(matchings[q_id], matchings[r_id], matchings[singleton_id], universe)
            if key is not None:
                b_loads[key].append((q_id, r_id, singleton_id))
        x_loads = defaultdict(list)
        for q_id, r_id, singleton_id in product(
            classes[x_masks[0]], classes[x_masks[1]], classes[x_masks[2]]
        ):
            key = triple_load(matchings[q_id], matchings[r_id], matchings[singleton_id], universe)
            if key is not None:
                x_loads[key].append((q_id, r_id, singleton_id))
        common_keys = b_loads.keys() & x_loads.keys()
        if not common_keys:
            counts["orientation_no_common_K"] += 1
            continue
        counts["orientations_with_common_K"] += 1

        for key in common_keys:
            counts["common_K"] += 1
            decompositions = all_three_decompositions(key, matchings, pairs)
            typed_rows = []
            forbidden = []
            b_rows = []
            x_rows = []
            for row in decompositions:
                pattern = row_pattern(row, boundary_masks, orientation)
                category = classify_pattern(pattern)
                typed_rows.append((row, pattern, category))
                if category in {"T-loop", "TT"}:
                    forbidden.append((row, pattern, category))
                if pattern == B_PATTERN:
                    singleton = next(
                        item for item in row
                        if logical_boundary(boundary_masks[item], orientation) == (2,)
                    )
                    b_rows.append((row, singleton))
                if pattern == X_PATTERN:
                    singleton = next(
                        item for item in row
                        if logical_boundary(boundary_masks[item], orientation) == (3,)
                    )
                    x_rows.append((row, singleton))
            if not b_rows or not x_rows:
                raise AssertionError((key, b_loads[key], x_loads[key], typed_rows))
            if forbidden:
                counts["common_K_forbidden_T_loop_or_TT"] += 1
                continue
            counts["common_K_fixed_layer_clean"] += 1

            complement_rows = []
            for a_id, c_id, d_id in product(
                classes[mask_for_physical(a)],
                classes[mask_for_physical(c)],
                classes[mask_for_physical(d)],
            ):
                complement = complementary_load(
                    matchings[a_id], matchings[c_id], matchings[d_id], universe
                )
                if complement == key:
                    complement_rows.append((a_id, c_id, d_id))
            if not complement_rows:
                counts["clean_common_K_without_ACD_complement"] += 1
                continue

            for a_id, c_id, d_id in complement_rows:
                counts["ACD_complements"] += 1
                phase = matchings[a_id] ^ matchings[c_id]
                intersections = []
                safe = False
                for b_row, b_id in b_rows:
                    for x_row, x_id in x_rows:
                        intersection = matchings[b_id] & matchings[x_id] & phase
                        intersections.append((b_row, x_row, intersection))
                        if not intersection:
                            safe = True
                            break
                    if safe:
                        break
                if safe:
                    counts["ACD_with_safe_BX"] += 1
                    continue
                counts["all_bad_hits"] += 1
                physical_to_logical = {
                    physical: logical for logical, physical in enumerate(orientation, 1)
                }
                return {
                    "order": order,
                    "augmented_graph6": graph6,
                    "proper_edges": proper,
                    "terminal_vertices_by_logical_position": {
                        str(logical): terminals[physical]
                        for logical, physical in enumerate(orientation, 1)
                    },
                    "perfect_matching_count": len(matchings),
                    "edge_objects_by_index": tuple(
                        f"{obj[0]}-{obj[1]}" if len(obj) == 2 else
                        f"s{physical_to_logical[terminal_to_physical[obj[0]]]}@{obj[0]}"
                        for obj in objects
                    ),
                    "A": matching_record(a_id, matchings, objects, boundary_masks, orientation, terminal_to_physical),
                    "C": matching_record(c_id, matchings, objects, boundary_masks, orientation, terminal_to_physical),
                    "D": matching_record(d_id, matchings, objects, boundary_masks, orientation, terminal_to_physical),
                    "K": {
                        "twice_edges": tuple(
                            printable_object(objects[index], {
                                "terminal_vertex_to_physical": terminal_to_physical,
                                "physical_to_logical": physical_to_logical,
                            })
                            for index in range(len(objects)) if key[0] & (1 << index)
                        ),
                        "once_edges": tuple(
                            printable_object(objects[index], {
                                "terminal_vertex_to_physical": terminal_to_physical,
                                "physical_to_logical": physical_to_logical,
                            })
                            for index in range(len(objects)) if key[1] & (1 << index)
                        ),
                    },
                    "all_K_decompositions": tuple({
                        "type": category,
                        "boundary_pattern": pattern,
                        "matchings": tuple(
                            matching_record(item, matchings, objects, boundary_masks, orientation, terminal_to_physical)
                            for item in row
                        ),
                    } for row, pattern, category in typed_rows),
                    "B_decompositions": tuple(tuple(
                        matching_record(item, matchings, objects, boundary_masks, orientation, terminal_to_physical)
                        for item in row
                    ) for row, _ in b_rows),
                    "X_decompositions": tuple(tuple(
                        matching_record(item, matchings, objects, boundary_masks, orientation, terminal_to_physical)
                        for item in row
                    ) for row, _ in x_rows),
                    "all_BX_intersections": tuple({
                        "B_row_ids": b_row,
                        "X_row_ids": x_row,
                        "J_edge_indices": tuple(
                            index for index in range(len(objects))
                            if intersection & (1 << index)
                        ),
                        "J_edges": tuple(
                            printable_object(objects[index], {
                                "terminal_vertex_to_physical": terminal_to_physical,
                                "physical_to_logical": physical_to_logical,
                            })
                            for index in range(len(objects))
                            if intersection & (1 << index)
                        ),
                    } for b_row, x_row, intersection in intersections),
                    "fixed_layer_has_T_loop_or_TT": False,
                    "proper_two_cuts": two_cuts,
                    "separable_colourable_proper_2cut": None,
                }
    return None


def scan_order(order: int, geng: str, progress_every: int):
    command = [geng, "-q", "-c", "-d3", "-D5", str(order + 1), str((3 * order + 5) // 2)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    if process.stdout is None:
        raise RuntimeError("could not read geng output")
    counts = Counter()
    hit = None
    exhausted = False
    started = time.monotonic()
    try:
        for line in process.stdout:
            graph6 = line.strip()
            if not graph6:
                continue
            counts["generated"] += 1
            recovered = recover_pole(graph6, order)
            if recovered is None:
                continue
            counts["degree_sequence"] += 1
            if recovered == "disconnected":
                counts["proper_disconnected"] += 1
                continue
            counts["proper_connected"] += 1
            if recovered == "bridged":
                counts["proper_bridged"] += 1
                continue
            counts["proper_bridgeless"] += 1
            proper, terminals, _, _ = recovered
            two_cuts, obstruction = proper_two_cut_audit(order, proper, terminals)
            if obstruction is not None:
                counts["separable_colourable_2cut"] += 1
                continue
            counts["structurally_indivisible"] += 1
            hit = inspect_pole(order, graph6, proper, terminals, two_cuts, counts)
            if hit is not None:
                break
            if progress_every and counts["generated"] % progress_every == 0:
                print(
                    "PROGRESS", order, dict(counts),
                    "elapsed", round(time.monotonic() - started, 2),
                    file=sys.stderr, flush=True,
                )
        else:
            exhausted = True
    finally:
        if process.poll() is None:
            process.terminate()
        returncode = process.wait()
        if exhausted and returncode != 0:
            raise RuntimeError(f"geng failed with status {returncode}")
    return {
        "order": order,
        "geng_command": command,
        "exhausted": exhausted,
        "counts": dict(sorted(counts.items())),
        "elapsed_seconds": round(time.monotonic() - started, 6),
        "hit": hit,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--geng", default="geng")
    parser.add_argument("--orders", type=int, nargs="+", default=(5, 7, 9, 11, 13))
    parser.add_argument("--progress-every", type=int, default=1000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    result = {
        "scope": (
            "all unlabelled simple connected augmented graphs of orders n+1, "
            "n in the requested odd orders, with degree sequence (5,3^n); "
            "connected proper-bridgeless distinct-terminal cubic five-poles; "
            "all 120 ordered terminal orientations; stop at first hit"
        ),
        "orders": [],
        "first_hit": None,
    }
    for order in args.orders:
        record = scan_order(order, args.geng, args.progress_every)
        result["orders"].append(record)
        if record["hit"] is not None:
            result["first_hit"] = record["hit"]
            break
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json is not None:
        args.json.write_text(text + "\n", encoding="utf-8")
    print(
        "INDIVISIBLE_ALL_BAD_CARRIER_FOUND"
        if result["first_hit"] is not None
        else "NO_INDIVISIBLE_ALL_BAD_CARRIER_THROUGH_REQUESTED_ORDERS"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
