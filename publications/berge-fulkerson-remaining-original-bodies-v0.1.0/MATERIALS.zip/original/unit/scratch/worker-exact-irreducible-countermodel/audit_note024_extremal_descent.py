#!/usr/bin/env python3
"""Extremal J-descent on the eight fixed Note-024 J31 choices.

Only occurrence-preserving equal-pair substitutions inside the common
carrier K=2-A-C-D are used.  The fixed pole and its complete 37-PM family
come from audit_note024_repeated_star.py.
"""

from collections import Counter, defaultdict, deque
from itertools import combinations, combinations_with_replacement, product
import json

import audit_note024_repeated_star as base


S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
PAIR_SET = frozenset(combinations(range(1, 6), 2))
T = PAIR_SET - S
B_TYPE = ("ST", ((1, 5), (2, 4)), 2)
X_TYPE = ("ST", ((1, 3), (4, 5)), 3)


def matching_load(index):
    matching = FAMILY[index]
    return tuple(int(edge in matching) for edge in base.OBJECTS)


def pair_load(pair):
    first, second = pair
    return tuple(a + b for a, b in zip(MATCHING_LOAD[first], MATCHING_LOAD[second]))


def decomposition_type(state):
    boundaries = tuple(base.boundary(FAMILY[index]) for index in state)
    sizes = sorted(map(len, boundaries))
    if sizes == [1, 1, 5]:
        return "A", "12345", None
    assert sizes == [1, 3, 3], (state, boundaries)
    pairs = tuple(sorted(
        base.complement_state(boundary)
        for boundary in boundaries if len(boundary) == 3
    ))
    singleton = next(boundary[0] for boundary in boundaries if len(boundary) == 1)
    if all(pair in S for pair in pairs):
        category = "SS"
    elif all(pair in T for pair in pairs):
        category = "TT"
    else:
        category = "ST"
    return category, pairs, singleton


def decompositions(target):
    output = set()
    for retained in range(len(FAMILY)):
        residual = tuple(
            value - used for value, used in zip(target, MATCHING_LOAD[retained])
        )
        if any(value not in (0, 1, 2) for value in residual):
            continue
        for pair in PAIRS_BY_LOAD.get(residual, ()): 
            output.add(tuple(sorted((*pair, retained))))
    return tuple(sorted(output))


def difference_components(first, second):
    diff = FAMILY[first] ^ FAMILY[second]
    adjacency = defaultdict(set)
    for edge in diff:
        if isinstance(edge, str):
            vertex = int(edge[1:])
            terminal = ("terminal", vertex)
            adjacency[vertex].add(terminal)
            adjacency[terminal].add(vertex)
        else:
            u, v = edge
            adjacency[u].add(v)
            adjacency[v].add(u)
    unseen = set(adjacency)
    components = 0
    while unseen:
        components += 1
        start = next(iter(unseen))
        stack = [start]
        seen = set()
        while stack:
            vertex = stack.pop()
            if vertex in seen:
                continue
            seen.add(vertex)
            stack.extend(adjacency[vertex] - seen)
        unseen -= seen
    return components


def move_kind(old_pair, new_pair):
    for aligned in (new_pair, tuple(reversed(new_pair))):
        if not all(
            base.boundary(FAMILY[old]) == base.boundary(FAMILY[new])
            for old, new in zip(old_pair, aligned)
        ):
            continue
        if all(difference_components(old, new) == 1
               for old, new in zip(old_pair, aligned)):
            return "same-boundary-single-component-paired-splice", aligned
    return "actual-equal-pair-substitution", new_pair


def equation_record(old_pair, new_pair):
    assert pair_load(old_pair) == pair_load(new_pair)
    kind, aligned = move_kind(old_pair, new_pair)
    edgewise = {
        str(edge): value
        for edge, value in zip(base.OBJECTS, pair_load(old_pair)) if value
    }
    return {
        "equation": f"M{old_pair[0]}+M{old_pair[1]}=M{new_pair[0]}+M{new_pair[1]}",
        "old_pair": old_pair,
        "new_pair": new_pair,
        "old_boundaries": tuple(base.boundary(FAMILY[index]) for index in old_pair),
        "new_boundaries": tuple(base.boundary(FAMILY[index]) for index in new_pair),
        "kind": kind,
        "aligned_new_pair": aligned,
        "edgewise_sum": edgewise,
    }


def matching_record(index):
    return {
        "id": index,
        "boundary": base.boundary(FAMILY[index]),
        "edges": tuple(sorted(str(edge) for edge in FAMILY[index])),
    }


def decomposition_graph(states):
    state_set = set(states)
    adjacency = {state: {} for state in states}
    for state in states:
        for left, right in combinations(range(3), 2):
            old_pair = tuple(sorted((state[left], state[right])))
            retained = state[3 - left - right]
            for new_pair in PAIRS_BY_LOAD[pair_load(old_pair)]:
                if new_pair == old_pair:
                    continue
                following = tuple(sorted((*new_pair, retained)))
                if following not in state_set or following == state:
                    continue
                adjacency[state].setdefault(
                    following, equation_record(old_pair, new_pair)
                )
    return adjacency


def singleton_matching(state, singleton):
    return next(
        index for index in state if base.boundary(FAMILY[index]) == (singleton,)
    )


def j_set(node, fixed):
    b_state, x_state = node
    b = FAMILY[singleton_matching(b_state, 2)]
    x = FAMILY[singleton_matching(x_state, 3)]
    a, c, _ = fixed
    return frozenset(b & x & (FAMILY[a] ^ FAMILY[c]))


def choice_graph(b_states, x_states, decomposition_adjacency):
    nodes = tuple(sorted(product(b_states, x_states)))
    node_set = set(nodes)
    adjacency = {node: {} for node in nodes}
    for node in nodes:
        b_state, x_state = node
        for following, move in decomposition_adjacency[b_state].items():
            target = (following, x_state)
            if target in node_set:
                adjacency[node].setdefault(target, {"coordinate": "B", **move})
        for following, move in decomposition_adjacency[x_state].items():
            target = (b_state, following)
            if target in node_set:
                adjacency[node].setdefault(target, {"coordinate": "X", **move})
    return nodes, adjacency


def reachable(starts, adjacency):
    seen = set(starts)
    queue = deque(starts)
    while queue:
        current = queue.popleft()
        for following in adjacency[current]:
            if following not in seen:
                seen.add(following)
                queue.append(following)
    return seen


def shortest_forbidden(start, adjacency):
    if decomposition_type(start)[0] in ("A", "TT"):
        return {"distance": 0, "sink": start, "sink_type": decomposition_type(start), "steps": ()}
    parent = {start: None}
    parent_move = {}
    queue = deque([start])
    sink = None
    while queue:
        current = queue.popleft()
        for following, move in adjacency[current].items():
            if following in parent:
                continue
            parent[following] = current
            parent_move[following] = move
            if decomposition_type(following)[0] in ("A", "TT"):
                sink = following
                queue.clear()
                break
            queue.append(following)
    if sink is None:
        return {"distance": None, "sink": None, "sink_type": None, "steps": ()}
    steps = []
    current = sink
    while parent[current] is not None:
        previous = parent[current]
        steps.append({"from": previous, "to": current, **parent_move[current]})
        current = previous
    steps.reverse()
    return {
        "distance": len(steps),
        "sink": sink,
        "sink_type": decomposition_type(sink),
        "steps": tuple(steps),
    }


def sink_record(node, fixed, adjacency, decomposition_adjacency):
    current_j = j_set(node, fixed)
    strict = tuple(
        following for following in adjacency[node]
        if len(j_set(following, fixed)) < len(current_j)
    )
    inclusion_strict = tuple(
        following for following in adjacency[node]
        if j_set(following, fixed) < current_j
    )
    provenance = []
    for coordinate, state in zip(("B", "X"), node):
        result = shortest_forbidden(state, decomposition_adjacency)
        provenance.append({"coordinate": coordinate, **result})
    finite = [item for item in provenance if item["distance"] is not None]
    best = min(finite, key=lambda item: item["distance"]) if finite else None
    return {
        "node": node,
        "J": tuple(sorted(str(edge) for edge in current_j)),
        "J_size": len(current_j),
        "strict_cardinality_descents": strict,
        "strict_inclusion_descents": inclusion_strict,
        "shortest_forbidden": best,
        "all_coordinate_provenance": provenance,
    }


def main():
    global FAMILY, IDS, MATCHING_LOAD, PAIRS_BY_LOAD
    FAMILY = base.enumerate_perfect_matchings()
    IDS = {matching: index for index, matching in enumerate(FAMILY)}
    assert len(FAMILY) == 37
    MATCHING_LOAD = tuple(matching_load(index) for index in range(len(FAMILY)))
    PAIRS_BY_LOAD = defaultdict(list)
    for pair in combinations_with_replacement(range(len(FAMILY)), 2):
        PAIRS_BY_LOAD[pair_load(pair)].append(pair)
    for key in PAIRS_BY_LOAD:
        PAIRS_BY_LOAD[key].sort()

    classes = defaultdict(list)
    for matching in FAMILY:
        classes[base.boundary(matching)].append(matching)
    r1 = base.cell_rows(classes, (1, 3), (4, 5), (1, 3, 4, 5))
    r3 = base.cell_rows(classes, (2, 4), (1, 5), (1, 2, 4, 5))

    starts_by_fixed = defaultdict(list)
    raw_starts = []
    for row3 in r3:
        q24, r15, a, b, c, d = row3
        for row1 in r1:
            q13, r45, a1, x, c1, d1 = row1
            if (a1, c1, d1) != (a, c, d):
                continue
            fixed = (IDS[a], IDS[c], IDS[d])
            node = (
                tuple(sorted((IDS[q24], IDS[r15], IDS[b]))),
                tuple(sorted((IDS[q13], IDS[r45], IDS[x]))),
            )
            starts_by_fixed[fixed].append(node)
            raw_starts.append((fixed, node))
    assert len(raw_starts) == 8

    carrier_records = []
    carrier_loads = set()
    all_sink_records = []
    start_records = []
    for fixed, starts in sorted(starts_by_fixed.items()):
        carrier = tuple(base.complement_load(tuple(FAMILY[index] for index in fixed))[edge]
                        for edge in base.OBJECTS)
        carrier_loads.add(carrier)
        states = decompositions(carrier)
        types = {state: decomposition_type(state) for state in states}
        b_states = tuple(state for state in states if types[state] == B_TYPE)
        x_states = tuple(state for state in states if types[state] == X_TYPE)
        decomposition_adjacency = decomposition_graph(states)
        nodes, adjacency = choice_graph(b_states, x_states, decomposition_adjacency)
        reached = reachable(starts, adjacency)
        positive = tuple(node for node in reached if j_set(node, fixed))
        sinks = tuple(
            node for node in positive
            if not any(
                len(j_set(following, fixed)) < len(j_set(node, fixed))
                for following in adjacency[node]
            )
        )
        sink_records = tuple(
            sink_record(node, fixed, adjacency, decomposition_adjacency)
            for node in sinks
        )
        all_sink_records.extend((fixed, record) for record in sink_records)
        for start in starts:
            start_records.append({
                "fixed_ACD": fixed,
                "node": start,
                "J": tuple(sorted(str(edge) for edge in j_set(start, fixed))),
                "J_size": len(j_set(start, fixed)),
                "is_positive_local_minimum": start in sinks,
            })
        carrier_records.append({
            "fixed_ACD": fixed,
            "carrier_decompositions": len(states),
            "decomposition_type_counts": dict(sorted(Counter(
                value[0] for value in types.values()
            ).items())),
            "decomposition_equal_pair_edges": sum(map(len, decomposition_adjacency.values())) // 2,
            "B_decompositions": len(b_states),
            "X_decompositions": len(x_states),
            "choice_nodes": len(nodes),
            "choice_edges": sum(map(len, adjacency.values())) // 2,
            "reachable_choice_nodes": len(reached),
            "positive_reachable_nodes": len(positive),
            "positive_local_minima": len(sinks),
            "sink_records": sink_records,
        })

    assert len(start_records) == 8
    assert len(starts_by_fixed) == 8
    assert len(carrier_loads) == 1
    assert all(record["J_size"] > 0 for record in start_records)
    assert Counter(record["J_size"] for record in start_records) == {1: 3, 2: 5}
    assert all(record["is_positive_local_minimum"] for record in start_records)
    assert all(record["B_decompositions"] == 1 for record in carrier_records)
    assert all(record["X_decompositions"] == 1 for record in carrier_records)
    assert all(record["choice_nodes"] == 1 for record in carrier_records)
    assert all(record["choice_edges"] == 0 for record in carrier_records)
    assert all(record["carrier_decompositions"] == 8 for record in carrier_records)
    assert all(record["decomposition_type_counts"] == {"SS": 4, "ST": 2, "TT": 2}
               for record in carrier_records)
    assert all_sink_records
    assert all(
        record["shortest_forbidden"] is not None
        for _, record in all_sink_records
    )
    assert len(all_sink_records) == 8
    for _, record in all_sink_records:
        provenance = {item["coordinate"]: item
                      for item in record["all_coordinate_provenance"]}
        assert provenance["B"]["distance"] == 1
        assert provenance["X"]["distance"] == 1
        assert provenance["B"]["sink_type"] == ("TT", ((1, 5), (3, 4)), 3)
        assert provenance["X"]["sink_type"] == ("TT", ((1, 2), (4, 5)), 2)
        assert provenance["B"]["steps"][0]["equation"] == "M10+M31=M7+M34"
        assert provenance["X"]["steps"][0]["equation"] == "M11+M20=M8+M23"
    print(json.dumps({
        "pm_count": len(FAMILY),
        "J31_start_choices": len(start_records),
        "fixed_ACD_owner_fibres": len(starts_by_fixed),
        "distinct_carrier_loads": len(carrier_loads),
        "uniform_TT_equalities": {
            "B_coordinate": {
                **equation_record((10, 31), (7, 34)),
                "matchings": tuple(matching_record(index)
                                   for index in (10, 31, 7, 34)),
                "sink_type": ("TT", ((1, 5), (3, 4)), 3),
            },
            "X_coordinate": {
                **equation_record((11, 20), (8, 23)),
                "matchings": tuple(matching_record(index)
                                   for index in (11, 20, 8, 23)),
                "sink_type": ("TT", ((1, 2), (4, 5)), 2),
            },
        },
        "starts": start_records,
        "carriers": carrier_records,
    }, indent=2, sort_keys=True))
    print("NOTE024_EXTREMAL_DESCENT_CLASSIFIED")


if __name__ == "__main__":
    main()
