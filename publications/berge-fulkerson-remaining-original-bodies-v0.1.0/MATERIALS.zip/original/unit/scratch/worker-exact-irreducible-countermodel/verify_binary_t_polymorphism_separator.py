#!/usr/bin/env python3
"""Pure-standard-library verifier for a SAT separator certificate."""

from __future__ import annotations

import json
from itertools import combinations
from pathlib import Path


HERE = Path(__file__).resolve().parent
RESULT = HERE / "binary_t_polymorphism_case_xii_separator_result.json"
DOMAIN = tuple(combinations(range(6), 2))
MASKS = tuple(sum(1 << c for c in edge) for edge in DOMAIN)
S = frozenset(
    frozenset(edge)
    for edge in ((0, 2), (0, 3), (1, 3), (1, 4), (2, 4))
)
T_OMITTED = frozenset(
    frozenset(edge) for edge in combinations(range(5), 2)
) - S


def in_relation(labels):
    degrees = [
        sum((MASKS[label] >> colour) & 1 for label in labels)
        for colour in range(6)
    ]
    if sorted(degrees) != [1, 1, 1, 1, 3, 3]:
        return False
    high = [colour for colour in range(6) if degrees[colour] == 3]
    omitted = [
        frozenset(i for i, label in enumerate(labels)
                  if not ((MASKS[label] >> colour) & 1))
        for colour in high
    ]
    return not all(edge in T_OMITTED for edge in omitted)


def main():
    record = json.loads(RESULT.read_text())
    if record["status"] != "separator_found":
        print("NO_SAT_SEPARATOR_CERTIFICATE_TO_VERIFY")
        return
    table = record["operation_table_row_major"]
    assert len(table) == 225 and all(0 <= value < 15 for value in table)
    for left in range(225):
        a, b = divmod(left, 15)
        for right in range(left + 1, 225):
            aa, bb = divmod(right, 15)
            if MASKS[a] & MASKS[aa] or MASKS[b] & MASKS[bb]:
                continue
            assert not (MASKS[table[left]] & MASKS[table[right]])
    x = tuple(record["separator_x"])
    y = tuple(record["separator_y"])
    z = tuple(table[15 * a + b] for a, b in zip(x, y))
    assert z == tuple(record["separator_output"])
    assert in_relation(x) and in_relation(y) and not in_relation(z)
    print("BINARY_T_POLYMORPHISM_SEPARATOR_VERIFIED")


if __name__ == "__main__":
    main()

