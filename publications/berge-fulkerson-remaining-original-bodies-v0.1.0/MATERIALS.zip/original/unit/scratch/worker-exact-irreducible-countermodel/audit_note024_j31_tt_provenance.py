#!/usr/bin/env python3
"""Shortest two-occurrence provenance from the eight fixed Note-024 choices.

States are six-occurrence perfect-matching multisets with load two on every
edge.  A move retains four occurrences and replaces the other two by an
actual equal-load pair.  No shared-identity row jump or identity-pool
activation is allowed.
"""

from collections import Counter, defaultdict, deque
from itertools import combinations_with_replacement
import json

import audit_note024_repeated_star as base


S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
PAIR_SET = frozenset(
    (i, j) for i in range(1, 6) for j in range(i + 1, 6)
)
T = PAIR_SET - S


def state(row):
    return tuple(sorted(IDS[matching] if not isinstance(matching, int) else matching
                        for matching in row))


def pair_load(first_id, second_id):
    counts = Counter(FAMILY[first_id])
    counts.update(FAMILY[second_id])
    return tuple(counts[edge] for edge in base.OBJECTS)


def row_category(row_state):
    boundaries = [base.boundary(FAMILY[index]) for index in row_state]
    sizes = sorted(map(len, boundaries))
    if sizes == [1, 1, 1, 1, 1, 5]:
        return "A", "12345"
    assert sizes == [1, 1, 1, 1, 3, 3], (row_state, boundaries)
    pair_states = tuple(sorted(
        base.complement_state(boundary)
        for boundary in boundaries if len(boundary) == 3
    ))
    if all(pair in S for pair in pair_states):
        category = "SS"
    elif all(pair in T for pair in pair_states):
        category = "TT"
    else:
        category = "ST"
    return category, pair_states


def matching_record(index):
    return {
        "id": index,
        "boundary": base.boundary(FAMILY[index]),
        "edges": tuple(sorted(str(edge) for edge in FAMILY[index])),
    }


def overload_record(matching_ids):
    counts = Counter(
        edge for index in matching_ids for edge in FAMILY[index]
    )
    return tuple(
        {"edge": str(edge), "load": counts[edge]}
        for edge in base.OBJECTS if counts[edge] > 2
    )


def difference_components(first_id, second_id):
    first = FAMILY[first_id]
    second = FAMILY[second_id]
    diff = first ^ second
    adjacency = defaultdict(set)
    terminal_vertices = set()
    for edge in diff:
        if isinstance(edge, str):
            vertex = int(edge[1:])
            terminal = ("terminal", vertex)
            adjacency[vertex].add(terminal)
            adjacency[terminal].add(vertex)
            terminal_vertices.add(terminal)
        else:
            u, v = edge
            adjacency[u].add(v)
            adjacency[v].add(u)
    unseen = set(adjacency)
    components = []
    while unseen:
        start = min(unseen, key=str)
        stack = [start]
        vertices = set()
        while stack:
            vertex = stack.pop()
            if vertex in vertices:
                continue
            vertices.add(vertex)
            stack.extend(adjacency[vertex] - vertices)
        unseen -= vertices
        component_edges = tuple(sorted(
            str(edge) for edge in diff
            if (
                (isinstance(edge, str) and ("terminal", int(edge[1:])) in vertices)
                or (not isinstance(edge, str) and edge[0] in vertices)
            )
        ))
        terminals = tuple(sorted(
            vertex[1] + 1 for vertex in vertices
            if isinstance(vertex, tuple) and vertex[0] == "terminal"
        ))
        components.append({"edges": component_edges, "terminals": terminals})
    return tuple(sorted(components, key=lambda item: (item["terminals"], item["edges"])))


def move_kind(old_pair, new_pair):
    for new_order in (new_pair, tuple(reversed(new_pair))):
        if not all(
            base.boundary(FAMILY[old]) == base.boundary(FAMILY[new])
            for old, new in zip(old_pair, new_order)
        ):
            continue
        component_counts = tuple(
            len(difference_components(old, new))
            for old, new in zip(old_pair, new_order)
        )
        if component_counts == (1, 1):
            return "same-boundary-single-component-splice", new_order
    return "actual-equal-pair-substitution", new_pair


def neighbours(row_state):
    for left in range(6):
        for right in range(left + 1, 6):
            old_pair = tuple(sorted((row_state[left], row_state[right])))
            key = PAIR_LOAD[old_pair]
            remaining = list(row_state)
            remaining.pop(right)
            remaining.pop(left)
            for new_pair in PAIRS_BY_LOAD[key]:
                if new_pair == old_pair:
                    continue
                following = tuple(sorted((*remaining, *new_pair)))
                kind, aligned_new = move_kind(old_pair, new_pair)
                yield following, {
                    "retained": tuple(remaining),
                    "old_pair": old_pair,
                    "new_pair": new_pair,
                    "kind": kind,
                    "aligned_new_pair": aligned_new,
                }


def shortest_forbidden(start):
    category, _ = row_category(start)
    if category in ("TT", "A"):
        return {"distance": 0, "sink": start, "component_seen": 1, "steps": tuple()}
    queue = deque([start])
    parent = {start: None}
    parent_move = {}
    sink = None
    while queue:
        current = queue.popleft()
        for following, move in neighbours(current):
            if following in parent:
                continue
            parent[following] = current
            parent_move[following] = move
            sink_category, _ = row_category(following)
            if sink_category in ("TT", "A"):
                sink = following
                queue.clear()
                break
            queue.append(following)
        if sink is not None:
            break
    if sink is None:
        return {
            "distance": None,
            "sink": None,
            "component_seen": len(parent),
            "steps": tuple(),
        }
    reversed_steps = []
    current = sink
    while parent[current] is not None:
        previous = parent[current]
        move = dict(parent_move[current])
        move["from"] = previous
        move["to"] = current
        move["from_category"] = row_category(previous)
        move["to_category"] = row_category(current)
        move["old_pair_boundaries"] = tuple(
            base.boundary(FAMILY[index]) for index in move["old_pair"]
        )
        move["new_pair_boundaries"] = tuple(
            base.boundary(FAMILY[index]) for index in move["new_pair"]
        )
        move["old_new_differences"] = tuple(
            difference_components(old, new)
            for old, new in zip(move["old_pair"], move["aligned_new_pair"])
        )
        reversed_steps.append(move)
        current = previous
    steps = tuple(reversed(reversed_steps))
    return {
        "distance": len(steps),
        "sink": sink,
        "sink_category": row_category(sink),
        "component_seen": len(parent),
        "steps": steps,
    }


def main():
    global FAMILY, IDS, PAIR_LOAD, PAIRS_BY_LOAD
    FAMILY = base.enumerate_perfect_matchings()
    IDS = {matching: index for index, matching in enumerate(FAMILY)}
    assert len(FAMILY) == 37
    classes = defaultdict(list)
    for matching in FAMILY:
        classes[base.boundary(matching)].append(matching)

    all_pairs = tuple(combinations_with_replacement(range(len(FAMILY)), 2))
    PAIR_LOAD = {pair: pair_load(*pair) for pair in all_pairs}
    PAIRS_BY_LOAD = defaultdict(list)
    for pair, key in PAIR_LOAD.items():
        PAIRS_BY_LOAD[key].append(pair)
    for key in PAIRS_BY_LOAD:
        PAIRS_BY_LOAD[key].sort()

    r1 = base.cell_rows(classes, (1, 3), (4, 5), (1, 3, 4, 5))
    r3 = base.cell_rows(classes, (2, 4), (1, 5), (1, 2, 4, 5))
    choices = []
    cache = {}
    for row3 in r3:
        _, _, a, _, c, d = row3
        for row1 in r1:
            if (row1[2], row1[4], row1[5]) != (a, c, d):
                continue
            starts = {"R1": state(row1), "R3": state(row3)}
            results = {}
            for name, start in starts.items():
                if start not in cache:
                    cache[start] = shortest_forbidden(start)
                results[name] = cache[start]
            finite = [result["distance"] for result in results.values()
                      if result["distance"] is not None]
            target = state((a, row3[3], row1[3], c))
            choices.append({
                "r1": starts["R1"],
                "r3": starts["R3"],
                "target_singletons_ABXC": target,
                "target_overload": overload_record(target),
                "starts": results,
                "minimum_distance": min(finite) if finite else None,
            })

    assert len(choices) == 8
    assert all(choice["target_overload"] for choice in choices)
    assert all(choice["minimum_distance"] == 1 for choice in choices)
    assert all(
        choice["starts"][name]["distance"] == 1
        for choice in choices for name in ("R1", "R3")
    )
    assert all(
        row_category(choice[name.lower()])[0] == "ST"
        for choice in choices for name in ("R1", "R3")
    )
    r1_steps = tuple(choice["starts"]["R1"]["steps"][0] for choice in choices)
    assert all(step["old_pair"] == (11, 20) for step in r1_steps)
    assert all(step["new_pair"] == (8, 23) for step in r1_steps)
    assert all(step["to_category"] == ("TT", ((1, 2), (4, 5))) for step in r1_steps)
    assert PAIR_LOAD[(11, 20)] == PAIR_LOAD[(8, 23)]
    uniform_r1_provenance = {
        "distance": 1,
        "old_pair": (11, 20),
        "new_pair": (8, 23),
        "identity_records": tuple(matching_record(index) for index in (11, 20, 8, 23)),
        "edgewise_pair_load": PAIR_LOAD[(11, 20)],
        "sink_type": ("TT", ((1, 2), (4, 5))),
        "retained_roles": ("r45", "A", "C", "D"),
    }
    print(json.dumps({
        "pm_count": len(FAMILY),
        "pair_sum_classes": len(PAIRS_BY_LOAD),
        "uniform_r1_provenance": uniform_r1_provenance,
        "choices": choices,
    }, indent=2, sort_keys=True))
    print("NOTE024_J31_TT_PROVENANCE_CLASSIFIED")


if __name__ == "__main__":
    main()
