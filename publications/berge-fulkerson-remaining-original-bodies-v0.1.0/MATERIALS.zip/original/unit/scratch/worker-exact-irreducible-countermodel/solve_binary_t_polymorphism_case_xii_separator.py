#!/usr/bin/env python3
"""Decide whether a binary polymorphism of T separates R_XII.

Domain elements are the 15 two-subsets of six matching-occurrence colours.
T is the ordered partition relation.  A binary T-polymorphism is equivalently
a graph homomorphism KG(6,2)^2 -> KG(6,2), which gives a compact Boolean
encoding: adjacent product vertices must receive disjoint two-subsets.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from itertools import combinations, product
from pathlib import Path

from z3 import (
    And,
    AtMost,
    Bool,
    If,
    Implies,
    Not,
    Or,
    PbEq,
    Solver,
    Sum,
    is_true,
    sat,
    unknown,
)


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "binary_t_polymorphism_case_xii_separator_result.json"
COLOURS = tuple(range(6))
TERMINALS = tuple(range(5))
DOMAIN = tuple(combinations(COLOURS, 2))
MASKS = tuple(sum(1 << c for c in edge) for edge in DOMAIN)
S = frozenset(
    frozenset(edge)
    for edge in ((0, 2), (0, 3), (1, 3), (1, 4), (2, 4))
)
T_OMITTED = frozenset(
    frozenset(edge) for edge in combinations(TERMINALS, 2)
) - S


def is_case_xii_tuple(labels: tuple[int, ...]) -> bool:
    degrees = [0] * 6
    for label in labels:
        mask = MASKS[label]
        for colour in COLOURS:
            degrees[colour] += (mask >> colour) & 1
    if sorted(degrees) != [1, 1, 1, 1, 3, 3]:
        return False
    high = [colour for colour in COLOURS if degrees[colour] == 3]
    omitted = [
        frozenset(i for i, label in enumerate(labels)
                  if not ((MASKS[label] >> colour) & 1))
        for colour in high
    ]
    assert all(len(edge) == 2 for edge in omitted)
    return not all(edge in T_OMITTED for edge in omitted)


def case_xii_census() -> dict:
    count = 0
    boundary_class = Counter()
    types = Counter()
    for labels in product(range(15), repeat=5):
        degrees = [
            sum((MASKS[label] >> colour) & 1 for label in labels)
            for colour in COLOURS
        ]
        if sorted(degrees) == [1, 1, 1, 1, 1, 5]:
            boundary_class["A"] += 1
            continue
        if sorted(degrees) != [1, 1, 1, 1, 3, 3]:
            continue
        high = [colour for colour in COLOURS if degrees[colour] == 3]
        omitted = tuple(sorted(
            tuple(i for i, label in enumerate(labels)
                  if not ((MASKS[label] >> colour) & 1))
            for colour in high
        ))
        kinds = tuple(frozenset(edge) in S for edge in omitted)
        kind = "SS" if all(kinds) else "TT" if not any(kinds) else "ST"
        boundary_class[kind] += 1
        if kind != "TT":
            count += 1
            types[omitted] += 1
    assert boundary_class == Counter(
        {"A": 720, "SS": 5_850, "ST": 10_800, "TT": 5_850}
    )
    assert count == 16_650
    assert len(types) == 40
    assert Counter(types.values()) == Counter({360: 25, 720: 10, 90: 5})
    return {
        "labelled_tuples": count,
        "all_BF_boundary_labelings": sum(boundary_class.values()),
        "class_distribution": dict(boundary_class),
        "boundary_types": len(types),
        "orbit_size_distribution": {
            str(size): multiplicity
            for size, multiplicity in sorted(Counter(types.values()).items())
        },
    }


def relation_expr(incidence):
    degrees = [
        Sum(*(If(incidence[i][colour], 1, 0) for i in TERMINALS))
        for colour in COLOURS
    ]
    high = [degree == 3 for degree in degrees]
    degree_shape = And(
        *(Or(degree == 1, degree == 3) for degree in degrees),
        Sum(*(If(item, 1, 0) for item in high)) == 2,
    )
    t_high = []
    for colour in COLOURS:
        omitted_in_t = Or(*(
            And(*(Not(incidence[i][colour]) for i in edge))
            for edge in T_OMITTED
        ))
        t_high.append(And(high[colour], omitted_in_t))
    return And(degree_shape, AtMost(*t_high, 1))


def selected_edge(model, selectors):
    chosen = [i for i, value in enumerate(selectors)
              if is_true(model.eval(value, model_completion=True))]
    assert len(chosen) == 1
    return chosen[0]


def main() -> None:
    started = time.monotonic()
    deadline = started + 220.0
    census = case_xii_census()
    solver = Solver()

    # f[(a,b)][c] says colour c belongs to f(a,b).
    f = tuple(
        tuple(Bool(f"f_a{a}_b{b}_c{colour}") for colour in COLOURS)
        for a in range(15) for b in range(15)
    )
    for value in f:
        solver.add(PbEq([(bit, 1) for bit in value], 2))

    disjoint = tuple(
        tuple((MASKS[a] & MASKS[b]) == 0 for b in range(15))
        for a in range(15)
    )
    product_edges = 0
    for a, b in product(range(15), repeat=2):
        left = 15 * a + b
        for aa, bb in product(range(15), repeat=2):
            right = 15 * aa + bb
            if left >= right or not disjoint[a][aa] or not disjoint[b][bb]:
                continue
            product_edges += 1
            for colour in COLOURS:
                solver.add(Or(Not(f[left][colour]), Not(f[right][colour])))
    assert product_edges == 4_050

    x_select = tuple(
        tuple(Bool(f"x_i{i}_e{edge}") for edge in range(15))
        for i in TERMINALS
    )
    y_select = tuple(
        tuple(Bool(f"y_i{i}_e{edge}") for edge in range(15))
        for i in TERMINALS
    )
    x_inc = tuple(
        tuple(Bool(f"x_i{i}_c{colour}") for colour in COLOURS)
        for i in TERMINALS
    )
    y_inc = tuple(
        tuple(Bool(f"y_i{i}_c{colour}") for colour in COLOURS)
        for i in TERMINALS
    )
    for selectors, incidence in ((x_select, x_inc), (y_select, y_inc)):
        for i in TERMINALS:
            solver.add(PbEq([(value, 1) for value in selectors[i]], 1))
            for colour in COLOURS:
                solver.add(
                    incidence[i][colour]
                    == Or(*(selectors[i][edge]
                            for edge in range(15)
                            if (MASKS[edge] >> colour) & 1))
                )
        solver.add(relation_expr(incidence))

    z_inc = tuple(
        tuple(Bool(f"z_i{i}_c{colour}") for colour in COLOURS)
        for i in TERMINALS
    )
    for i in TERMINALS:
        for a, b in product(range(15), repeat=2):
            antecedent = And(x_select[i][a], y_select[i][b])
            value = f[15 * a + b]
            for colour in COLOURS:
                solver.add(Implies(
                    antecedent, z_inc[i][colour] == value[colour]
                ))
    solver.add(Not(relation_expr(z_inc)))

    remaining_ms = max(1, int(1000 * (deadline - time.monotonic() - 3.0)))
    solver.set(timeout=remaining_ms)
    result = solver.check()
    record = {
        "status": (
            "separator_found" if result == sat
            else "all_binary_T_polymorphisms_preserve_R_XII"
            if str(result) == "unsat"
            else "unknown"
        ),
        "solver_result": str(result),
        "reason_unknown": solver.reason_unknown() if result == unknown else None,
        "domain_size": len(DOMAIN),
        "domain_pairs": [list(edge) for edge in DOMAIN],
        "T_relation_ordered_size": 90,
        "product_graph_edges": product_edges,
        "R_XII_census": census,
        "elapsed_s": time.monotonic() - started,
        "solver_statistics": str(solver.statistics()),
    }
    if result == sat:
        model = solver.model()
        table = []
        for value in f:
            mask = sum(
                1 << colour for colour in COLOURS
                if is_true(model.eval(value[colour], model_completion=True))
            )
            assert mask.bit_count() == 2
            table.append(MASKS.index(mask))
        x = tuple(selected_edge(model, row) for row in x_select)
        y = tuple(selected_edge(model, row) for row in y_select)
        z = tuple(table[15 * a + b] for a, b in zip(x, y))
        assert is_case_xii_tuple(x)
        assert is_case_xii_tuple(y)
        assert not is_case_xii_tuple(z)
        for left in range(225):
            a, b = divmod(left, 15)
            for right in range(left + 1, 225):
                aa, bb = divmod(right, 15)
                if disjoint[a][aa] and disjoint[b][bb]:
                    assert MASKS[table[left]] & MASKS[table[right]] == 0
        record.update({
            "operation_table_row_major": table,
            "separator_x": list(x),
            "separator_y": list(y),
            "separator_output": list(z),
        })

    encoded = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
    record["record_sha256_without_this_field"] = hashlib.sha256(encoded).hexdigest()
    record["elapsed_s"] = time.monotonic() - started
    OUTPUT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": record["status"],
        "elapsed_s": record["elapsed_s"],
        "R_XII_labelled_tuples": census["labelled_tuples"],
        "R_XII_boundary_types": census["boundary_types"],
    }, sort_keys=True))
    if result == sat:
        print("BINARY_T_POLYMORPHISM_SEPARATOR_FOUND")
    elif str(result) == "unsat":
        print("BINARY_T_POLYMORPHISM_ROUTE_CLOSED")
    else:
        print("BINARY_T_POLYMORPHISM_UNDECIDED")


if __name__ == "__main__":
    main()
