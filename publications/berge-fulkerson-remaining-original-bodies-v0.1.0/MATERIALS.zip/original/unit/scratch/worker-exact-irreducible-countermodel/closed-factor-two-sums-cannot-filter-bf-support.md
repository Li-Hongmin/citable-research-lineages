# Closed-factor two-sums cannot filter BF support or Note 082 fibre existence

## Exact statement

Let \(H_0\) be a cubic pole, let \(e=xy\) be a non-loop proper edge of
\(H_0\), let \(J\) be a closed cubic graph, and let \(f=uv\) be a non-loop
edge of \(J\). Delete \(e,f\) and reconnect their four ends crosswise to
obtain

\[
H=H_0\oplus_{e,f}J.
\]

Perfect matchings and edges are treated as objects, so parallel edges cause
no ambiguity. BF covers are multisets of six perfect-matching occurrences;
repeated occurrences are allowed. Then

\[
\boxed{
\operatorname{BFsupp}(H)=
\begin{cases}
\operatorname{BFsupp}(H_0),&J\text{ has a BF cover},\\
\varnothing,&J\text{ has no BF cover}.
\end{cases}}
\tag{1}
\]

No simplicity, bridgelessness, or three-edge-colourability hypothesis is
needed. All semiedges lie in \(H_0\), and their boundary labels and loads are
unchanged.

There is also a stronger existence statement. If \(J\) has a BF cover, then
every concrete Note 082 sequential or forced-intermediate fibre of \(H_0\)
lifts occurrence-by-occurrence to \(H\), and every such fibre in \(H\)
projects to one in \(H_0\). Thus

\[
\boxed{
\operatorname{Fib}_{082}(H)\ne\varnothing
\iff
\operatorname{Fib}_{082}(H_0)\ne\varnothing,}
\tag{2}
\]

where the fibre is the pointwise-anchored occurrence path classified in
Note 082. Three-edge-colourability is needed in Note 099 for its stronger
single global map on all perfect-matching identities, not for existence of
one such fibre.

Consequently a closed cubic factor cannot turn a carrier with extra
all-terminal or \(T\)--\(T\) support into exact Case XII. It either retains
every boundary type of the carrier or destroys every BF row. If it retains
the rows, it also cannot delete an already existing Note 082 fibre.

## The distinguished-bit gate

For a closed factor define

\[
\Pi(J,f)=\left\{
 I\in {[6]\choose 2}:
 \begin{array}{l}
 (N_1,\ldots,N_6)\text{ is an ordered BF cover of }J,\\
 I=\{i:f\in N_i\}
 \end{array}
 \right\}.
\tag{3}
\]

This apparent fifteen-state gate is binary:

\[
\boxed{
\Pi(J,f)=\varnothing
\quad\text{or}\quad
\Pi(J,f)={[6]\choose2}.}
\tag{4}
\]

Indeed, if \(J\) has one BF cover, the load of \(f\) is exactly two, so
exactly two of its six matching occurrences use \(f\). Permuting the six
occurrences places those two occurrences in any prescribed two-slot set.
This remains true when they are copies of the same perfect matching: slots
are occurrences, not distinct matching identities.

For a boundary type \(\tau\), define \(\Pi(H_0,e;\tau)\) analogously from
ordered BF rows of type \(\tau\). Slotwise factorization gives

\[
\tau\in\operatorname{BFsupp}(H)
\iff
\Pi(H_0,e;\tau)\cap\Pi(J,f)\ne\varnothing.
\tag{5}
\]

Equations (4) and (5) give (1).

## Proof of slotwise factorization

The two new splice edges form the cut \(\delta_H(V(J))\). Since every closed
cubic graph has even order, any perfect matching of \(H\) uses an even
number of these two cut edges, hence either both or neither. If it uses
both, delete them and restore \(e\) and \(f\); if it uses neither, simply
restrict to the two sides. This gives a unique pair

\[
(M_0,M_J)\in\mathcal M(H_0)\times\mathcal M(J)
\]

with

\[
\mathbf1_{e\in M_0}=\mathbf1_{f\in M_J}.
\tag{6}
\]

Conversely every pair satisfying (6) splices uniquely to a perfect matching
of \(H\).

Project a six-occurrence BF row of \(H\) slot by slot. Both new splice edges
have load two, and a matching uses them together, so their common two-slot
set restores load two on \(e\) and \(f\). Every other factor edge already
has load two. The projections are therefore BF covers of \(H_0\) and \(J\),
and the \(H_0\) projection has the same semiedge boundary type.

Conversely, take any BF row of \(H_0\) and any BF cover of \(J\). Each has
exactly two occurrences using its distinguished edge. Reorder only the six
\(J\)-occurrences so that these two position sets agree, then splice each
slot using (6). Internal factor edges retain load two, and each new splice
edge occurs in exactly those two positions. This is a BF row of \(H\) with
the boundary type of the \(H_0\) row.

The proof is unchanged if \(e\) or \(f\) belongs to a parallel pair. If a
bridge or another obstruction makes \(J\) BF-uncoverable, projection forces
\(\operatorname{BFsupp}(H)=\varnothing\).

## Occurrence transport preserves every Note 082 fibre

Take one concrete Note 082 fibre in \(H_0\). Write its initial BF row in six
occurrence positions as \((M_1,\ldots,M_6)\), and put

\[
b_i=\mathbf1_{e\in M_i}.
\]

Let \((F_1,\ldots,F_6)\) be any BF cover of \(J\). By (4), reorder its
occurrences initially so that

\[
\mathbf1_{f\in F_i}=b_i\qquad(i=1,\ldots,6).
\tag{7}
\]

Consider one paired splice in the exterior fibre. It replaces the two
occurrences at positions \(i,j\), with

\[
M_i+M_j=M_i'+M_j'.
\tag{8}
\]

Taking the \(e\)-coordinate gives

\[
b_i+b_j=b_i'+b_j'.
\tag{9}
\]

The entries are binary, so their unordered pairs agree:

\[
\{b_i,b_j\}_{\rm mult}=\{b_i',b_j'\}_{\rm mult}.
\tag{10}
\]

Assign the same two factor occurrences \(F_i,F_j\) to the two new exterior
occurrences, leaving them in place if their distinguished bits already
match and swapping them otherwise. Both new exterior--factor pairs satisfy
(6), while on the factor side

\[
F_i+F_j=F_i'+F_j'
\tag{11}
\]

holds because the two sides are the same multiset of matching occurrences.
All other factor positions are unchanged. Thus the factor multiset in the
new row is still the original BF cover of \(J\), and the splice is an actual
equal-pair replacement in \(H\).

Repeat for the second splice. The argument applies without change to both
sequential orders, reuse of the first updated companion, and the
forced-intermediate branch: these differ only in which two occurrence
positions are replaced, while (8)--(11) use only pair-sum conservation. In
the nondegenerate Note 082 list the pointwise literal positions \(B,X\) are
not touched; touching and restoring one would force the forbidden direct
endpoint equality under the target-overload hypothesis. Their lifted
matching identities therefore remain pointwise fixed.

Conversely, projecting every row and pair equality of a fibre in \(H\)
gives the corresponding occurrence-position fibre in \(H_0\). This proves
(2).

The lift transports six occurrences along one fibre. It need not assign one
factor matching to each member of the entire perfect-matching family of
\(H_0\), nor lift several unrelated BF rows by one globally consistent
identity map. The endpoint-star map in Note 099 remains stronger:
three-edge-colourability provides precisely that simultaneous canonical
lift. Such global consistency is not part of the existential Note 082 fibre
property.

## Decision for the proposed construction

The factor-filter route is closed before any graph search. A small closed
cubic factor \(J\) cannot selectively remove \(A\) or \(T\)--\(T\) types
while retaining the forty positive types. If it is BF-coverable, it also
cannot delete an existing Note 082 fibre; if it is not BF-coverable, it
deletes all forty positive rows. Therefore bounded tests of Petersen-type
or other non-three-edge-colourable factors against the known carriers
cannot change the decision and were not run.

This file is the reproduction entry: the result is the direct factorization
proof (3)--(11), with no computational certificate or parameter scan.

