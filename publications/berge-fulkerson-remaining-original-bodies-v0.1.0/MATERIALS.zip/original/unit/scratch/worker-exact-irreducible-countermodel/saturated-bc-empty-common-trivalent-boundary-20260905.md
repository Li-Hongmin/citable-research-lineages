# Saturated \(H_{23}\), an actual \(BC\) join, and two empty endpoint fibres

## The local common-trivalent countermodel

There is a common five-vertex trivalent incidence system with 22 named
matching occurrences and 19 distinct incidence signatures having all of the
following properties.

1. Each matching chooses one of three incidences at every vertex.  At the
   five terminal vertices, incidence 2 is the semiedge and is selected
   exactly at the prescribed boundary positions.
2. The same fixed half \(H_{23}=(r_{23},B,X)\) participates in five exact
   six-occurrence double covers, one for each state in
   \(S=\{13,14,24,25,35\}\).
3. There is an exact \(25\)--\(34\) row
   \(q_{25}'+r_{34}+B+Y+C+D=2\mathbf 1\), sharing the pointwise occurrences
   \(B,C\) with the state-14 column row.
4. In the complete selected family of the 19 distinct signatures, with
   repetitions allowed, no \(T\)--\(T\) row exists.  No all-terminal
   signature belongs to this selected family, so it has no selected
   all-terminal cover.
5. The selected family has one distinct state-35 decomposition of the
   complementary carrier.  Neither \(Y\) nor \(D\) enters its corresponding
   projection, and no occurrence in \(H_{23}\) supplies a `Sep` square for
   either endpoint.

Thus common local trivalence, exact row loads, saturated \(H_{23}\), an
actual occurrence-level \(BC\) join, selected no-A/no-TT, and both empty
endpoint intersections are mutually consistent.

This is not a cubic pole.  Its ten proper incidence stubs have not been
paired between vertices into common edge objects.  Consequently the 19
signatures are not asserted to be the complete perfect-matching family of
any graph.  The countermodel therefore closes every argument using only
vertexwise trivalent partitions and the displayed row equations, but it does
not refute the real complete-PM-closure statement.

## Fixed-order graph-incidence boundary

A separate PB formula imposed one simple cubic five-pole graph together with
the same 22 designated perfect-matching occurrences.  It required the five
saturation rows, the actual \(BC\) row, \(X\ne Y\), absence of all 304
possible selected-family TT rows, and simultaneous endpoint failure for all
12 selected-family state-35 candidate triples.

At order 9 this formula is UNSAT.  The assumption core contains all five
premise categories:

\[
 \{\text{saturation},\ BC\text{ join},\ X\ne Y,\
   \text{selected no-TT},\ \text{endpoint empty}\}.
\]

This is a bounded PB fact, not a general impossibility theorem.  No short
analytic contradiction was extracted, so the UNSAT result is not promoted
beyond this fixed-order boundary.

At order 11 the identical selected-family formula returned `unknown` after
its 120-second solver timeout.  It produced neither a model nor an UNSAT
certificate and therefore supplies no mathematical evidence in either
direction.  No candidate-blocking loop or CEGAR step was used at either
order.

## Decision

The real-pole proposition remains unresolved:

> In a complete graph-induced perfect-matching closure, do saturated
> \(H_{23}\), an actual \(BC\) join, global no-A/no-TT, and two empty endpoint
> intersections coexist?

The thinnest surviving layer is now explicit.  One must pair all proper
incidence stubs into the edges of a common connected cubic five-pole and then
take its complete perfect-matching closure, while preventing that closure
from adding an A cover, a TT cover, or either endpoint entry/square.  The
local trivalent equations alone cannot prove impossibility.

## Reproduction

The frozen local verifier is
`verify_vertex_partition_saturated_bc_empty.py`; it uses only the Python
standard library and ends with

```text
VERTEX_PARTITION_SATURATED_BC_EMPTY_VERIFIED
```

On Omen it took 0.03 seconds and 9,728 KiB peak RSS.  Its source SHA-256 is
`c7ab234fcbd06432bcbf30f5c1221d0a2a7357cdea40131b31eb82f11f26e39b`.
The generating SAT program is
`synthesize_vertex_partition_saturated_bc_empty.py`; its Omen run took 1.93
seconds and 54,696 KiB peak RSS and ended with
`VERTEX_PARTITION_SATURATED_BC_EMPTY_COUNTERMODEL_FOUND`.

The parameterized graph-incidence program is
`synthesize_order11_saturated_bc_empty_selected.py`.

- Order 9: Omen 3.68 seconds, 67,072 KiB peak RSS,
  `ORDER11_SATURATED_BC_EMPTY_SELECTED_UNSAT`.
- Order 11: Omen 123.49 seconds, 92,492 KiB peak RSS,
  `ORDER11_SATURATED_BC_EMPTY_SELECTED_UNKNOWN`.

The corresponding Omen directories are
`[local archival reference]`,
`[local archival reference]`,
and
`[local archival reference]`.
