#!/usr/bin/env python3
"""Join saturated t=23 halves to actual cross-column Y,D occurrences.

Only six frozen complete-perfect-matching poles are used.  A minimum actual
cross-column join consists of a saturated ``H23=(r23,B,X)``, one state-14
decomposition ``(q14,A,C)`` of its complementary carrier, and one actual
25--34 row ``(q25,r34,B,Y,C,D)`` sharing the pointwise occurrences ``B,C``.
It is compressed to ``(H23,Y,D)``.  For comparison we also count the stronger
join of all four repeated-star rows.

For the two Note-093 endpoint roles we distinguish literal projection entry
from a non-degenerate fixed-half pair-sum square (the ``Sep`` alternative).
No graph is generated and no parameter/order search is performed.
"""

from collections import Counter, defaultdict
from itertools import product
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
BASE = run_path(HERE / "audit_existing_t23_column_negative_gate.py")

S = BASE["S"]


def load_key(row, object_order):
    counts = Counter(edge for matching in row for edge in matching)
    return tuple(counts[edge] for edge in object_order)


def cell_rows(classes, objects, left, right, singleton_positions):
    return tuple(
        row
        for row in product(
            classes[BASE["base"]["complement"](left)],
            classes[BASE["base"]["complement"](right)],
            *(classes[(position,)] for position in singleton_positions),
        )
        if BASE["base"]["is_cover"](row, objects, 2)
    )


def carrier_decompositions(classes, target_load, object_order, i, j):
    return tuple(
        row
        for row in product(
            classes[BASE["base"]["complement"]((i, j))],
            classes[(i,)],
            classes[(j,)],
        )
        if load_key(row, object_order) == target_load
    )


def sep(companion, source, target):
    return (target - source) <= companion and not (
        companion & (source - target)
    )


def endpoint_status(projection, fixed_half, target):
    literal_entry = target in projection
    square_sources = {
        source
        for source in projection
        if source != target
        and any(sep(companion, source, target) for companion in fixed_half)
    }
    return literal_entry, bool(square_sources)


def audit(name):
    order, proper, objects, family, _, object_index = BASE["load_custom"](name)
    classes, profile = BASE["base"]["classify_boundary"](family, objects)
    object_order = tuple(sorted(objects, key=str))

    # Slots follow the literal names in Note 093 and audit_note024_repeated_star.
    r1 = cell_rows(classes, objects, (1, 3), (4, 5), (1, 3, 4, 5))
    r2 = cell_rows(classes, objects, (1, 4), (2, 3), (1, 2, 3, 4))
    r3 = cell_rows(classes, objects, (2, 4), (1, 5), (1, 2, 4, 5))
    r4 = cell_rows(classes, objects, (2, 5), (3, 4), (2, 3, 4, 5))

    r1_by_acd = defaultdict(list)
    for row in r1:
        r1_by_acd[(row[2], row[4], row[5])].append(row)
    r2_by_abcx = defaultdict(list)
    for row in r2:
        r2_by_abcx[(row[2], row[3], row[5], row[4])].append(row)
    r4_by_bcd = defaultdict(list)
    for row in r4:
        r4_by_bcd[(row[2], row[4], row[5])].append(row)

    saturated_cache = {}

    def saturated_data(fixed_half):
        if fixed_half in saturated_cache:
            return saturated_cache[fixed_half]
        half_load = load_key(fixed_half, object_order)
        if max(half_load, default=0) > 2:
            saturated_cache[fixed_half] = None
            return None
        carrier = tuple(2 - value for value in half_load)
        decompositions = {
            state: carrier_decompositions(
                classes, carrier, object_order, state[0], state[1]
            )
            for state in S
        }
        if not all(decompositions.values()):
            saturated_cache[fixed_half] = None
            return None
        saturated_cache[fixed_half] = decompositions
        return decompositions

    # Populate the cache with every saturated fixed t=23 half, independently
    # of whether it occurs in a stronger repeated-star join.
    _, all_saturated_halves = BASE["saturated_t23_halves"](classes, objects)
    for fixed_half in all_saturated_halves:
        assert saturated_data(fixed_half) is not None

    r4_by_bc = defaultdict(list)
    for row in r4:
        r4_by_bc[(row[2], row[4])].append(row)

    minimal_occurrence_joins = 0
    distinct_gates = set()
    for fixed_half in all_saturated_halves:
        _, b, x = fixed_half
        decompositions = saturated_data(fixed_half)
        assert decompositions is not None
        for _, _, c in decompositions[(1, 4)]:
            for row4 in r4_by_bc.get((b, c), ()):
                _, _, _, y, _, d = row4
                if x == y:
                    continue
                minimal_occurrence_joins += 1
                distinct_gates.add((fixed_half, y, d))

    full_occurrence_joins = 0
    saturated_full_occurrence_joins = 0
    distinct_full_gates = set()
    for row3 in r3:
        _, _, a, b, c, d = row3
        for row1 in r1_by_acd.get((a, c, d), ()):
            _, _, _, x, _, _ = row1
            for row2 in r2_by_abcx.get((a, b, c, x), ()):
                _, r23, _, _, _, _ = row2
                fixed_half = (r23, b, x)
                decompositions = saturated_data(fixed_half)
                for row4 in r4_by_bcd.get((b, c, d), ()):
                    _, _, _, y, _, _ = row4
                    if x == y:
                        continue
                    full_occurrence_joins += 1
                    if decompositions is None:
                        continue
                    saturated_full_occurrence_joins += 1
                    distinct_full_gates.add((fixed_half, y, d))

    patterns = Counter()
    entry_patterns = Counter()
    strict_square_patterns = Counter()
    empty_gates = []
    gate_statuses = []
    for fixed_half, y, d in distinct_gates:
        decompositions = saturated_data(fixed_half)
        assert decompositions is not None
        dec35 = decompositions[(3, 5)]
        projection3 = {row[1] for row in dec35}
        projection5 = {row[2] for row in dec35}
        y_entry, y_square = endpoint_status(projection3, fixed_half, y)
        d_entry, d_square = endpoint_status(projection5, fixed_half, d)
        y_intersection = y_entry or y_square
        d_intersection = d_entry or d_square
        patterns[(y_intersection, d_intersection)] += 1
        entry_patterns[(y_entry, d_entry)] += 1
        strict_square_patterns[(y_square, d_square)] += 1
        gate_statuses.append(
            (fixed_half, y, d, y_entry, y_square, d_entry, d_square)
        )
        if not y_intersection and not d_intersection:
            empty_gates.append((fixed_half, y, d))

    ids = {matching: index for index, matching in enumerate(family)}

    def gate_ids(gate):
        fixed_half, y, d = gate
        return {
            "H23": tuple(ids[matching] for matching in fixed_half),
            "Y": ids[y],
            "D": ids[d],
        }

    def gate_status_ids(status):
        fixed_half, y, d, y_entry, y_square, d_entry, d_square = status
        return gate_ids((fixed_half, y, d)) | {
            "Y_literal_entry": y_entry,
            "Y_strict_square": y_square,
            "D_literal_entry": d_entry,
            "D_strict_square": d_square,
        }

    return {
        "instance": name,
        "order": order,
        "perfect_matchings": len(family),
        "row_family_sizes": (len(r1), len(r2), len(r3), len(r4)),
        "saturated_H23": len(all_saturated_halves),
        "minimal_BC_occurrence_joins": minimal_occurrence_joins,
        "distinct_minimal_cross_column_gates": len(distinct_gates),
        "full_repeated_star_occurrence_joins": full_occurrence_joins,
        "saturated_full_repeated_star_occurrence_joins": (
            saturated_full_occurrence_joins
        ),
        "distinct_saturated_full_repeated_star_gates": len(distinct_full_gates),
        "entry_or_square_patterns_Y_D": {
            f"{int(left)}{int(right)}": count
            for (left, right), count in sorted(patterns.items())
        },
        "literal_entry_patterns_Y_D": {
            f"{int(left)}{int(right)}": count
            for (left, right), count in sorted(entry_patterns.items())
        },
        "strict_fixed_half_square_patterns_Y_D": {
            f"{int(left)}{int(right)}": count
            for (left, right), count in sorted(strict_square_patterns.items())
        },
        "both_intersections_empty": len(empty_gates),
        "first_empty_gate": gate_ids(empty_gates[0]) if empty_gates else None,
        "gate_statuses": tuple(
            sorted(
                (gate_status_ids(status) for status in gate_statuses),
                key=lambda item: (item["H23"], item["Y"], item["D"]),
            )
        ),
        "A": profile["A"],
        "TT_types": profile["TT"],
        "empty_implies_A_or_TT_in_this_pole": (
            not empty_gates or profile["A"] or profile["TT"] > 0
        ),
    }


def main():
    names = (
        "order9-indivisible",
        "order11",
        "order13",
        "order13-all-ss",
        "order13-first-synthesis",
        "order19",
    )
    records = tuple(audit(name) for name in names)
    empty_records = tuple(
        record for record in records if record["both_intersections_empty"]
    )
    counterexamples = tuple(
        record
        for record in empty_records
        if not record["A"] and record["TT_types"] == 0
    )
    assert not counterexamples
    print({
        "scope": (
            "six frozen complete-PM real poles; minimum actual BC joins plus "
            "stronger four-row joins"
        ),
        "records": records,
        "poles_with_both_intersections_empty": len(empty_records),
        "real_counterexamples": len(counterexamples),
        "decision": (
            "finite implication holds in the frozen corpus; inspect whether "
            "the nonvacuous empty gates have a common local A/TT construction"
        ),
    })
    print("EXISTING_T23_CROSS_COLUMN_OCCURRENCE_JOIN_AUDITED")


if __name__ == "__main__":
    main()
