#!/usr/bin/env python3
"""GF(2)-minimal global block pairing for the Note-101 local model.

The valid local block profiles and three-block partitions are enumerated
exactly.  One Optimize call chooses a minimum-cardinality set of internal
partitions which cancels the parity of the ten terminal proper stubs.  One
subsequent SAT call tries to pair equal profiles into a simple connected
graph.  If successful, the complete graph-induced PM closure is enumerated.
There is no order scan and no CEGAR loop.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from collections import Counter, defaultdict
from functools import reduce
from itertools import combinations, product
from pathlib import Path

from z3 import And, Bool, If, Not, Optimize, Or, PbEq, PbLe, Solver, Sum, Xor, sat, unknown


HERE = Path(__file__).resolve().parent
LOCAL_EVALUATOR = (
    HERE.parent / "worker-bf-real-synthesis" / "synthesize_exact40_joint_pb.py"
)
BUNDLED_EVALUATOR = HERE / "synthesize_exact40_joint_pb.py"
EVALUATOR_PATH = LOCAL_EVALUATOR if LOCAL_EVALUATOR.exists() else BUNDLED_EVALUATOR
SPEC = importlib.util.spec_from_file_location("note101_block_evaluator", EVALUATOR_PATH)
assert SPEC is not None and SPEC.loader is not None
EVALUATOR = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = EVALUATOR
SPEC.loader.exec_module(EVALUATOR)


TOKENS = (
    "A", "B", "C", "D", "P3", "P5", "X", "Y", "p24_2", "p24_4",
    "p25_2", "q13", "q14", "q24", "q25", "q25b", "q35", "r23", "r34",
)
TOKEN_INDEX = {token: index for index, token in enumerate(TOKENS)}
ALL_MASK = (1 << len(TOKENS)) - 1
TERMINAL_SIGNATURES = {
    "A": (2, 1, 0, 0, 1), "B": (0, 2, 0, 1, 0),
    "C": (1, 0, 1, 2, 1), "D": (0, 0, 0, 1, 2),
    "P3": (1, 0, 2, 1, 1), "P5": (1, 1, 0, 0, 2),
    "X": (0, 0, 2, 0, 0), "Y": (1, 1, 2, 0, 0),
    "p24_2": (1, 2, 1, 0, 1), "p24_4": (1, 0, 0, 2, 1),
    "p25_2": (1, 2, 1, 1, 1),
    "q13": (1, 2, 1, 2, 2), "q14": (1, 2, 2, 1, 2),
    "q24": (2, 1, 2, 1, 2), "q25": (2, 0, 2, 2, 1),
    "q25b": (2, 1, 2, 2, 1), "q35": (2, 2, 1, 2, 1),
    "r23": (2, 1, 1, 2, 2), "r34": (2, 2, 1, 0, 2),
}
ROWS = (
    ("r23", "B", "X", "q13", "A", "P3"),
    ("r23", "B", "X", "q14", "A", "C"),
    ("r23", "B", "X", "q24", "p24_2", "p24_4"),
    ("r23", "B", "X", "q25", "p25_2", "P5"),
    ("r23", "B", "X", "q35", "P3", "P5"),
    ("q25b", "r34", "B", "Y", "C", "D"),
)
ROW_MASKS = tuple(sum(1 << TOKEN_INDEX[token] for token in row) for row in ROWS)
S = frozenset(((0, 2), (0, 3), (1, 3), (1, 4), (2, 4)))
T = frozenset(set(combinations(range(5), 2)) - S)


def block_mask(vertex, incidence):
    return sum(
        1 << TOKEN_INDEX[token]
        for token in TOKENS if TERMINAL_SIGNATURES[token][vertex] == incidence
    )


def enumerate_local_partitions():
    valid_blocks = tuple(
        mask for mask in range(1 << len(TOKENS))
        if all((mask & row).bit_count() == 2 for row in ROW_MASKS)
    )
    valid_set = set(valid_blocks)
    partitions = set()
    for index, left in enumerate(valid_blocks):
        remaining = ALL_MASK ^ left
        for middle in valid_blocks[index + 1:]:
            if left & middle:
                continue
            right = remaining ^ middle
            if middle < right and right in valid_set:
                partitions.add((left, middle, right))
    return valid_blocks, tuple(sorted(partitions))


def minimum_parity_completion(partitions, terminal_proper):
    parity = Counter(terminal_proper)
    target = {block for block, count in parity.items() if count % 2}
    universe = sorted(set(target).union(block for part in partitions for block in part))
    chosen = [Bool(f"choose_partition_{index}") for index in range(len(partitions))]
    optimize = Optimize()
    for block in universe:
        users = [chosen[index] for index, part in enumerate(partitions) if block in part]
        if not users:
            if block in target:
                return "unsat", None
            continue
        xor = users[0] if len(users) == 1 else reduce(Xor, users)
        optimize.add(xor if block in target else Not(xor))
    optimize.minimize(Sum(*(If(value, 1, 0) for value in chosen)))
    optimize.set(timeout=180_000)
    result = optimize.check()
    if result == unknown:
        return "unknown", optimize.reason_unknown()
    if result != sat:
        return "unsat", None
    model = optimize.model()
    indices = tuple(
        index for index, value in enumerate(chosen)
        if bool(model.eval(value, model_completion=True))
    )
    return "sat", (target, indices)


def pair_simple_connected(terminal_proper, internal_partitions):
    occurrences = defaultdict(list)
    for vertex in range(5):
        for incidence in (0, 1):
            occurrences[block_mask(vertex, incidence)].append((vertex, incidence))
    for offset, partition in enumerate(internal_partitions, start=5):
        for incidence, block in enumerate(partition):
            occurrences[block].append((offset, incidence))
    assert all(len(stubs) % 2 == 0 for stubs in occurrences.values())
    n = 5 + len(internal_partitions)

    pair = {}
    by_stub = defaultdict(list)
    by_vertex_pair = defaultdict(list)
    for block, stubs in occurrences.items():
        for left_index, left in enumerate(stubs):
            for right in stubs[left_index + 1:]:
                if left[0] == right[0]:
                    continue
                variable = Bool(f"pair_{block}_{left[0]}_{left[1]}_{right[0]}_{right[1]}")
                pair[(block, left, right)] = variable
                by_stub[(block, left)].append(variable)
                by_stub[(block, right)].append(variable)
                by_vertex_pair[tuple(sorted((left[0], right[0])))].append(variable)
    solver = Solver()
    for block, stubs in occurrences.items():
        for stub in stubs:
            solver.add(PbEq([(value, 1) for value in by_stub[(block, stub)]], 1))
    for values in by_vertex_pair.values():
        solver.add(PbLe([(value, 1) for value in values], 1))

    edge = {
        uv: Or(*by_vertex_pair.get(uv, ()))
        for uv in combinations(range(n), 2)
    }
    reach = {(vertex, step): Bool(f"reach_{vertex}_{step}")
             for vertex in range(n) for step in range(n)}
    for vertex in range(n):
        solver.add(reach[(vertex, 0)] if vertex == 0 else Not(reach[(vertex, 0)]))
    for step in range(1, n):
        for vertex in range(n):
            arrivals = [reach[(vertex, step - 1)]]
            arrivals.extend(
                And(reach[(other, step - 1)], edge[tuple(sorted((vertex, other)))])
                for other in range(n) if other != vertex
            )
            solver.add(reach[(vertex, step)] == Or(*arrivals))
    solver.add(And(*(reach[(vertex, n - 1)] for vertex in range(n))))
    solver.set(timeout=180_000)
    if solver.check() != sat:
        return None, occurrences
    model = solver.model()
    selected = tuple(
        (block, left, right) for (block, left, right), value in pair.items()
        if bool(model.eval(value, model_completion=True))
    )
    return selected, occurrences


def load(row, size):
    value = [0] * size
    for matching in row:
        for edge in matching:
            value[edge] += 1
    return tuple(value)


def sep(companion, source, target):
    companion, source, target = map(frozenset, (companion, source, target))
    return (target - source) <= companion and not (companion & (source - target))


def endpoint_audit(classes, fixed, target_y, target_d, object_count):
    carrier = tuple(2 - value for value in load(fixed, object_count))
    state35 = (2, 4)
    rows = tuple(
        row for row in product(
            classes[EVALUATOR.boundary_for_pair(state35)],
            classes[frozenset((2,))], classes[frozenset((4,))],
        ) if load(row, object_count) == carrier
    )
    p3 = {row[1] for row in rows}
    p5 = {row[2] for row in rows}

    def status(projection, target):
        entry = target in projection
        square = any(source != target and any(sep(item, source, target) for item in fixed)
                     for source in projection)
        return {"literal_entry": entry, "strict_square": square,
                "intersection_nonempty": entry or square}

    return {"state35_decompositions": len(rows),
            "Y": status(p3, target_y), "D": status(p5, target_d)}


def main():
    valid_blocks, partitions = enumerate_local_partitions()
    terminal_proper = tuple(block_mask(vertex, incidence)
                            for vertex in range(5) for incidence in (0, 1))
    assert len(set(terminal_proper)) == 10
    completion_status, completion = minimum_parity_completion(
        partitions, terminal_proper
    )
    if completion_status == "unknown":
        print({"status": "GF2_unknown", "reason": completion,
               "valid_blocks": len(valid_blocks),
               "valid_partitions": len(partitions)})
        print("NOTE101_BLOCK_PARITY_UNKNOWN")
        return
    if completion_status == "unsat":
        print({"status": "GF2_infeasible", "valid_blocks": len(valid_blocks),
               "valid_partitions": len(partitions)})
        print("NOTE101_BLOCK_PARITY_INFEASIBLE")
        return
    assert completion is not None
    target, indices = completion
    internal = tuple(partitions[index] for index in indices)
    paired, occurrences = pair_simple_connected(terminal_proper, internal)
    if paired is None:
        print({"status": "minimum_parity_solution_not_simple_connected_pairable",
               "valid_blocks": len(valid_blocks), "valid_partitions": len(partitions),
               "odd_terminal_profiles": len(target),
               "minimum_internal_vertices": len(internal),
               "internal_partitions": internal})
        print("NOTE101_MINIMUM_BLOCK_PAIRING_NOT_SIMPLE_CONNECTED")
        return

    n = 5 + len(internal)
    proper_edges = tuple(sorted(tuple(sorted((left[0], right[0])))
                                for _, left, right in paired))
    assert len(proper_edges) == len(set(proper_edges)) == (3 * n - 5) // 2
    edge_index = {edge: index for index, edge in enumerate(proper_edges)}
    selected = {}
    for token in TOKENS:
        bit = 1 << TOKEN_INDEX[token]
        matching = [edge_index[tuple(sorted((left[0], right[0])))]
                    for block, left, right in paired if block & bit]
        matching.extend(len(proper_edges) + vertex for vertex in range(5)
                        if TERMINAL_SIGNATURES[token][vertex] == 2)
        selected[token] = tuple(sorted(matching))
    object_count = len(proper_edges) + 5
    assert all(load(tuple(selected[token] for token in row), object_count)
               == (2,) * object_count for row in ROWS)

    selected_classes_mutable = defaultdict(set)
    for matching in selected.values():
        boundary = frozenset(
            edge - len(proper_edges)
            for edge in matching if edge >= len(proper_edges)
        )
        selected_classes_mutable[boundary].add(matching)
    selected_classes = defaultdict(
        tuple,
        {boundary: tuple(sorted(family))
         for boundary, family in selected_classes_mutable.items()},
    )
    selected_support = frozenset(
        kind for kind in EVALUATOR.ALL_TYPES
        if EVALUATOR.find_cover(kind, selected_classes, len(proper_edges))
        is not None
    )
    selected_ss = {kind for kind in selected_support
                   if kind[0] in S and kind[1] in S}
    selected_st = {kind for kind in selected_support
                   if (kind[0] in S) != (kind[1] in S)}
    selected_tt = {kind for kind in selected_support
                   if kind[0] in T and kind[1] in T}
    selected_all_terminal = selected_classes[frozenset(range(5))]
    selected_endpoint = endpoint_audit(
        selected_classes,
        (selected["r23"], selected["B"], selected["X"]),
        selected["Y"], selected["D"], object_count,
    )
    selected_endpoint_empty = (
        not selected_endpoint["Y"]["intersection_nonempty"]
        and not selected_endpoint["D"]["intersection_nonempty"]
    )
    selected_profile = {
        "matching_identities": len(set(selected.values())),
        "all_terminal_identities": len(selected_all_terminal),
        "support": {"SS": len(selected_ss), "ST": len(selected_st),
                    "TT": len(selected_tt), "A": False},
        "endpoint_audit": selected_endpoint,
    }
    selected_antecedent = (
        len(set(selected.values())) == len(TOKENS)
        and not selected_all_terminal and not selected_tt
        and selected_endpoint_empty
    )
    if not selected_antecedent:
        print(json.dumps({
            "status": "selected_antecedent_not_preserved",
            "valid_blocks": len(valid_blocks),
            "valid_partitions": len(partitions),
            "odd_terminal_profiles": len(target),
            "minimum_internal_vertices": len(internal), "order": n,
            "proper_edges": proper_edges,
            "selected_profile": selected_profile,
        }, indent=2, sort_keys=True))
        print("NOTE101_SELECTED_ANTECEDENT_FAILED")
        return

    full = EVALUATOR.evaluate(n, proper_edges)
    endpoint = endpoint_audit(
        full["classes"], (selected["r23"], selected["B"], selected["X"]),
        selected["Y"], selected["D"], object_count,
    )
    ss = {kind for kind in full["support"] if kind[0] in S and kind[1] in S}
    st = {kind for kind in full["support"] if (kind[0] in S) != (kind[1] in S)}
    tt = {kind for kind in full["support"] if kind[0] in T and kind[1] in T}
    endpoint_empty = not endpoint["Y"]["intersection_nonempty"] and not endpoint["D"]["intersection_nonempty"]
    exact_case_xii = (full["tait_states"] == S and len(ss) == 15 and len(st) == 25
                      and not tt and full["a_witness"] is None)
    real_counterexample = exact_case_xii and endpoint_empty
    first_failure = (
        None if real_counterexample else
        "complete_PM_closure_A" if full["a_witness"] is not None else
        "complete_PM_closure_TT" if tt else
        "complete_PM_closure_endpoint_entry_or_square" if not endpoint_empty else
        "complete_case_xii_positive_support"
    )
    print(json.dumps({
        "status": "simple_connected_global_pairing_found",
        "valid_blocks": len(valid_blocks), "valid_partitions": len(partitions),
        "odd_terminal_profiles": len(target),
        "minimum_internal_vertices": len(internal), "order": n,
        "proper_edges": proper_edges,
        "selected_profile": selected_profile,
        "complete_PM_count": len(full["matchings"]),
        "complete_tait_states": tuple(sorted(full["tait_states"])),
        "complete_support_profile": {"SS": len(ss), "ST": len(st),
                                     "TT": len(tt), "A": full["a_witness"] is not None},
        "complete_endpoint_audit": endpoint,
        "exact_case_xii": exact_case_xii,
        "real_note082_counterexample": real_counterexample,
        "first_failure_layer": first_failure,
    }, indent=2, sort_keys=True))
    print("NOTE101_BLOCK_PAIRING_REAL_COUNTEREXAMPLE" if real_counterexample
          else "NOTE101_BLOCK_PAIRING_BOUNDARY_FOUND")


if __name__ == "__main__":
    main()
