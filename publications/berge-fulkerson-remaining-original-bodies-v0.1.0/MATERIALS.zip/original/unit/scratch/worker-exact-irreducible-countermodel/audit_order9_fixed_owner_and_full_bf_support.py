#!/usr/bin/env python3
"""Exhaust all complementary embeddings of the fixed order-9 carrier K."""

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement, product
import json


N = 9
K_PROPER = (
    (0, 3), (0, 7), (1, 5), (2, 8), (3, 6),
    (4, 6), (4, 7), (5, 6), (5, 8), (7, 8),
)
TERMINAL_VERTICES = tuple(range(5))
K_TERMINAL_LOADS = (1, 2, 2, 1, 1)
POSITIONS = tuple(range(1, 6))
S = {(1, 3), (1, 4), (2, 4), (2, 5), (3, 5)}
T = set(combinations(POSITIONS, 2)) - S


def perfect_pairings(vertices):
    vertices = tuple(vertices)
    if not vertices:
        yield tuple()
        return
    first = vertices[0]
    for index in range(1, len(vertices)):
        second = vertices[index]
        rest = vertices[1:index] + vertices[index + 1:]
        for following in perfect_pairings(rest):
            yield ((min(first, second), max(first, second)), *following)


def connected(proper):
    adjacency = {vertex: set() for vertex in range(N)}
    for u, v in proper:
        adjacency[u].add(v)
        adjacency[v].add(u)
    seen = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbour in adjacency[vertex] - seen:
            seen.add(neighbour)
            stack.append(neighbour)
    return len(seen) == N


def all_completions():
    incident = defaultdict(list)
    for edge in K_PROPER:
        u, v = edge
        incident[u].append((edge, 1))
        incident[v].append((edge, 1))
    for vertex, load in zip(TERMINAL_VERTICES, K_TERMINAL_LOADS):
        incident[vertex].append((("s", vertex + 1), load))
    deficits = []
    for vertex in range(N):
        profile = sorted(load for _, load in incident[vertex])
        assert sum(profile) == 3
        if profile == [1, 2]:
            deficits.append(vertex)
        else:
            assert profile == [1, 1, 1]

    support = set(K_PROPER)
    completions = []
    for invisible in perfect_pairings(deficits):
        if any(edge in support for edge in invisible):
            continue
        proper = tuple(sorted((*K_PROPER, *invisible)))
        if len(set(proper)) != len(proper) or not connected(proper):
            continue
        degrees = Counter(vertex for edge in proper for vertex in edge)
        for vertex in TERMINAL_VERTICES:
            degrees[vertex] += 1
        if all(degrees[vertex] == 3 for vertex in range(N)):
            completions.append((tuple(sorted(invisible)), proper))
    return tuple(deficits), tuple(completions)


DEFICIT_VERTICES, COMPLETIONS = all_completions()
assert DEFICIT_VERTICES == (1, 2)
assert len(COMPLETIONS) == 1
INVISIBLE, PROPER = COMPLETIONS[0]
OBJECTS = PROPER + tuple((vertex,) for vertex in TERMINAL_VERTICES)


def object_name(index):
    if index < len(PROPER):
        u, v = PROPER[index]
        return f"{u}-{v}"
    return f"s{index - len(PROPER) + 1}"


def printable_matching(matching):
    return tuple(sorted(object_name(index) for index in matching))


def enumerate_perfect_matchings():
    incident = {vertex: [] for vertex in range(N)}
    for index, endpoints in enumerate(OBJECTS):
        for vertex in endpoints:
            incident[vertex].append(index)
    output = set()

    def rec(uncovered, selected):
        if not uncovered:
            output.add(tuple(sorted(selected)))
            return
        vertex = min(uncovered)
        for edge in incident[vertex]:
            endpoints = OBJECTS[edge]
            if all(endpoint in uncovered for endpoint in endpoints):
                rec(uncovered.difference(endpoints), selected + (edge,))

    rec(frozenset(range(N)), tuple())
    return tuple(sorted(output))


def boundary(matching):
    return tuple(
        index - len(PROPER) + 1
        for index in matching if index >= len(PROPER)
    )


def has_load(row, target):
    counts = Counter(edge for matching in row for edge in matching)
    return all(counts[index] == value for index, value in enumerate(target))


def first_cover(rows, target):
    for row in rows:
        if has_load(row, target):
            return row
    return None


def comp(pair):
    return tuple(sorted(set(POSITIONS) - set(pair)))


def main():
    matchings = enumerate_perfect_matchings()
    classes = defaultdict(list)
    for matching in matchings:
        classes[boundary(matching)].append(matching)

    edge_index = {edge: index for index, edge in enumerate(PROPER)}
    k_load = [1 if edge in K_PROPER else 0 for edge in PROPER]
    k_load.extend(K_TERMINAL_LOADS)
    h_load = tuple(2 - value for value in k_load)

    decompositions = []
    for row in product(classes[(1,)], classes[(4,)], classes[(5,)]):
        if has_load(row, h_load):
            owner = next(
                label for label, matching in zip(("A", "C", "D"), row)
                if edge_index[(0, 3)] in matching
            )
            decompositions.append((row, owner))

    # The endpoint argument already forces D: at vertex 0, s1 in A leaves
    # 03 in C/D; at vertex 3, s4 in C leaves 03 in A/D.
    assert len(decompositions) == 2
    assert {owner for _, owner in decompositions} == {"D"}
    for row, _ in decompositions:
        assert has_load(row, h_load)

    target_two = (2,) * len(OBJECTS)
    a_row = first_cover(
        product(classes[POSITIONS], *(classes[(i,)] for i in POSITIONS)),
        target_two,
    )
    states = tuple(combinations(POSITIONS, 2))
    pair_support = {}
    for left, right in combinations_with_replacement(states, 2):
        row = first_cover(product(
            classes[comp(left)],
            classes[comp(right)],
            *(classes[(i,)] for i in left + right),
        ), target_two)
        if row is not None:
            pair_support[(left, right)] = row

    tt_witnesses = {
        kind: row for kind, row in pair_support.items()
        if kind[0] in T and kind[1] in T
    }
    global_no_a = a_row is None
    global_no_tt = not tt_witnesses
    assert not global_no_a
    assert not global_no_tt

    result = {
        "order": N,
        "deficit_vertices_derived_from_K": DEFICIT_VERTICES,
        "legal_simple_cubic_completion_count": len(COMPLETIONS),
        "all_invisible_edge_pairings": tuple(
            invisible for invisible, _ in COMPLETIONS
        ),
        "perfect_matchings": len(matchings),
        "complementary_decomposition_count": len(decompositions),
        "owners_of_03": sorted({owner for _, owner in decompositions}),
        "all_complementary_decompositions": [
            {
                "A": printable_matching(row[0]),
                "C": printable_matching(row[1]),
                "D": printable_matching(row[2]),
                "owner_of_03": owner,
            }
            for row, owner in decompositions
        ],
        "bad_phase_owner_exists": any(owner in ("A", "C")
                                      for _, owner in decompositions),
        "global_BF_support": {
            "all_56_boundary_types_tested": True,
            "no_A": global_no_a,
            "no_TT": global_no_tt,
            "exact_negative": global_no_a and global_no_tt,
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    print("ORDER9_FIXED_OWNER_AND_FULL_BF_SUPPORT_VERIFIED")


if __name__ == "__main__":
    main()
