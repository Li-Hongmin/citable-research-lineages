# The minimum carrier slices do not separate the two projections from TT/A

Fix

\[
K=2\mathbf1-A-C-D,
\]

with terminal-copy multiplicities \((1,2,2,1,1)\).  The two required
three-colour decompositions have boundary patterns

\[
\begin{aligned}
\mathcal B &: (135),(234),(2),\\
\mathcal X &: (245),(123),(3).
\end{aligned}
\]

The question is whether a degree-three copy-multigraph can have both
projection families, have no carrier colouring which combines with the
fixed half \((A,C,D)\) to give a TT or A BF cover, and nevertheless satisfy

\[
B\cap X\cap(A\triangle C)\ne\varnothing
\quad\text{for every }B\in\mathcal B, X\in\mathcal X.       \tag{1}
\]

## Complete minimum slices

At five internal vertices the terminal incidence forces the connected
carrier to be a path: the doubled objects \(s_2,s_3\) occupy its endpoints,
while \(s_1,s_4,s_5\) occur at the three internal vertices.  All six orders
of these three terminal objects and all proper three-edge-colourings were
enumerated.  The only order supporting both required projections also has
an A colouring.

At seven internal vertices, fix one \(\mathcal B\)-colouring.  For each of
its three colours, pair all nonterminal vertex stubs in every possible way.
This gives 123 distinct degree-three copy configurations after rejecting a
triple copy of one edge object; double copies are retained.  The enumeration
contains both connected and disconnected carriers:

\[
98\text{ connected},\qquad 25\text{ disconnected}.
\]

Every proper three-edge-colouring of each configuration was then enumerated.
Exactly 40 configurations also support an \(\mathcal X\)-projection.  Their
complete negative-support profile is

\[
\begin{array}{c|r}
\text{forbidden carrier outcome present}&\text{configurations}\\ \hline
A\text{ but no TT}&2\\
\text{TT but no }A&12\\
A\text{ and TT}&26.
\end{array}
\]

Thus zero of the 40 satisfies the exact negative boundary exclusions.  In
particular, this complete order-seven copy-configuration slice contains no
countermodel to (1); the intersection condition is never reached under its
full premise.

The TT test here is the complete one.  For every carrier colouring with one
singleton and two triple-boundary colour classes, the missing pairs of both
triple classes are computed, and the colouring is forbidden whenever both
belong to

\[
T=\{12,15,23,34,45\}.
\]

The A test is the boundary partition \((12345),(2),(3)\).  Restricting the
TT test only to the two projections with singleton 2 or 3 would be
incorrect: other singleton positions can also combine with the fixed
\((A,C,D)\) half to form a TT row.

## What this does and does not decide

The finite zero is consistent with the following carrier-level statement:

> If one degree-three copy-multigraph admits both the \(\mathcal B\) and
> \(\mathcal X\) boundary colourings, then some proper three-edge-colouring
> of that same copy-multigraph has TT or A boundary type.

The order-five and order-seven classifications do not prove this statement
for arbitrary carriers.  No structural argument presently couples two
possibly distinct Kempe components of the edge-colouring space, and no
countermodel was found within the permitted fixed slices.  Hence the
general implication remains undetermined at this layer; increasing the
order would be a new task and was not performed.

Terminal-path pairings alone also do not contain enough information to
interpret the set \(A\triangle C\).  A full-pole argument must additionally
retain the following incidence data.

1.  Every edge object with \(K(e)=1\) must be assigned its missing-copy
    owner in \(\{A,C,D\}\), consistently at both ends.
2.  At each cubic vertex, the three fixed matchings must each occupy exactly
    one incidence.  When the visible carrier incidences have multiplicities
    \((1,1,1)\), their three owners are therefore distinct; for pattern
    \((2,1)\), the invisible \(K(e)=0\) edge is used by the other two fixed
    matchings.
3.  The invisible \(K(e)=0\) incidences must be paired into common edge
    objects globally.  Equivalently, the visible part of
    \(A\triangle C\), together with those invisible edges, must admit the
    alternating A/C phase whose terminal endpoints are fixed at 1 and 4.

This owner-and-phase structure is the precise full-pole incidence missing
from a terminal-pattern-only model.  A general proof of (1), if true, must
either prove the displayed carrier-colouring statement before using this
structure, or use the owner-and-phase coupling directly to obtain a safe
pair \(B,X\).  The present finite result supplies neither general step.

## Reproduction and scope

The complete order-seven driver is
`search_configuration_carrier_countermodel.py` in this directory.  It uses
only the Python standard library and has source SHA256

```text
6989ace4ff9ab9b0471a28d6531b422a7b6f21b42255bf324869b211c0f66300
```

The final Omen run used Python 3.10.12, one process, and a 1 GiB virtual
memory cap.  It exited zero with marker
`CONFIGURATION_CARRIER_COUNTERMODEL_SCAN_OK`, wall time 0.04 seconds, and
maximum resident set size 11,264 KiB.  No pole, higher order, random graph,
SAT instance, or CEGAR loop was generated.

