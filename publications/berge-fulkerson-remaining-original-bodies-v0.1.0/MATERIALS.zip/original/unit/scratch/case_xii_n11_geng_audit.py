#!/usr/bin/env python3
"""Complete n=11 Case-XII audit via unlabelled augmented graphs.

Adjoin one vertex adjacent to the five semiedges of a simple cubic 5-pole.
The result has degree sequence (5,3^11).  Conversely, deleting the unique
degree-5 vertex from such a simple graph gives a cubic 5-pole with five
distinct boundary vertices.  Nauty's ``geng`` therefore replaces the
93,767,625 raw triples of colour-class matchings by a complete list of
unlabelled augmented graphs.

Boundary labelings need only be considered modulo the dihedral group of the
target pentagon S.  We take 12 representatives of the 120 labelings for each
augmented graph.  Every retained Case-XII branch is then checked with the
standalone matching/Tait routines from the imported n<=9 audit.
"""

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
LEGACY_AUDIT = HERE / "stage2-import" / "case_xii_pentagon_audit.py"


def load_legacy():
    spec = importlib.util.spec_from_file_location("case_xii_legacy", LEGACY_AUDIT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {LEGACY_AUDIT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def boundary_label_representatives(neighbours: tuple[int, ...]):
    """Twelve representatives of labelings modulo Aut(S)=D_5.

    In the cyclic order 1-4-2-5-3, rotate so the least-numbered neighbour is
    at position 1, then use reflection to require neighbour(4)<neighbour(3).
    """
    neighbours = tuple(sorted(neighbours))
    anchor = neighbours[0]
    rest = neighbours[1:]
    for perm in itertools.permutations(rest):
        mapping = {1: anchor, 4: perm[0], 2: perm[1], 5: perm[2], 3: perm[3]}
        if mapping[4] < mapping[3]:
            yield mapping


def pole_from_augmented(legacy, graph: nx.Graph, apex: int, mapping: dict[int, int]):
    """Relabel boundary neighbours to 0,...,4 as expected by legacy.Pole."""
    inverse = {vertex: position - 1 for position, vertex in mapping.items()}
    internal = sorted(set(graph) - {apex} - set(inverse))
    relabel = dict(inverse)
    relabel.update({vertex: 5 + i for i, vertex in enumerate(internal)})
    proper_edges = []
    for u, v in graph.edges():
        if apex in (u, v):
            continue
        proper_edges.append(legacy.canonical_edge(relabel[u], relabel[v]))
    return legacy.Pole(n=11, proper_edges=tuple(sorted(proper_edges)))


def matching_relation_statistics(legacy, pole):
    matchings, _, edge_position, _ = legacy.enumerate_perfect_matchings(pole)
    singleton = {i: [] for i in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)

    order = legacy.PENTAGON_ORDER
    relation_sizes = []
    for a, b in zip(order, order[1:] + order[:1]):
        relation_sizes.append(
            sum(x.isdisjoint(y) for x in singleton[a] for y in singleton[b])
        )

    cycle_count = 0
    first = order[0]
    for p1 in singleton[first]:
        selected = {first: p1}

        def dfs(k: int):
            nonlocal cycle_count
            if k == len(order):
                if selected[order[-1]].isdisjoint(p1):
                    cycle_count += 1
                return
            position = order[k]
            previous = selected[order[k - 1]]
            for matching in singleton[position]:
                if previous.isdisjoint(matching):
                    selected[position] = matching
                    dfs(k + 1)
            selected.pop(position, None)

        dfs(1)

    return {
        "singleton_sizes": tuple(len(singleton[i]) for i in range(1, 6)),
        "relation_sizes_cyclic": tuple(relation_sizes),
        "compatible_pentagons": cycle_count,
    }


def run(geng: str, all_labelings: bool = False):
    legacy = load_legacy()
    command = [geng, "-q", "-c", "-d3", "-D5", "12", "19"]
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    if proc.stdout is None:
        raise RuntimeError("failed to open geng output")

    counts = Counter()
    candidate_stats = []
    counterexample = None
    started = time.perf_counter()

    for line in proc.stdout:
        counts["geng_connected_degree_bounded"] += 1
        graph = nx.from_graph6_bytes(line.strip().encode("ascii"))
        degrees = Counter(dict(graph.degree()).values())
        if degrees != Counter({3: 11, 5: 1}):
            continue
        counts["degree_sequence_5_3x11"] += 1
        apex = next(v for v, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        counts["connected_proper_5_poles"] += 1

        neighbours = tuple(graph.neighbors(apex))
        if all_labelings:
            reps = tuple(
                dict(zip((1, 2, 3, 4, 5), perm))
                for perm in itertools.permutations(sorted(neighbours))
            )
            expected = 120
        else:
            reps = tuple(boundary_label_representatives(neighbours))
            expected = 12
        if len(reps) != expected:
            raise AssertionError(f"expected {expected} labelings, got {len(reps)}")

        for mapping in reps:
            counts["boundary_label_orbits_tested"] += 1
            pole = pole_from_augmented(legacy, graph, apex, mapping)
            states = legacy.enumerate_tait_states(pole)
            if states != legacy.S_DIAGONALS:
                continue
            counts["case_xii_state_branches"] += 1
            witness = legacy.find_pentagon_and_verify(pole)
            stats = matching_relation_statistics(legacy, pole)
            candidate_stats.append(stats)
            if witness is None:
                counterexample = {
                    "augmented_graph6": line.strip(),
                    "boundary_position_to_augmented_vertex": mapping,
                    "proper_edges": [list(edge) for edge in pole.proper_edges],
                    "tait_states": [list(pair) for pair in sorted(states)],
                    "matching_statistics": stats,
                }
                proc.terminate()
                break
            counts["pentagon_verified_branches"] += 1
        if counterexample is not None:
            break

    returncode = proc.wait()
    if counterexample is None and returncode != 0:
        raise RuntimeError(f"geng failed with exit status {returncode}")

    distributions = {
        "compatible_pentagons": dict(sorted(Counter(
            s["compatible_pentagons"] for s in candidate_stats
        ).items())),
        "singleton_size_vectors": dict(sorted(Counter(
            str(s["singleton_sizes"]) for s in candidate_stats
        ).items())),
        "relation_size_vectors": dict(sorted(Counter(
            str(s["relation_sizes_cyclic"]) for s in candidate_stats
        ).items())),
    }
    return {
        "order_internal_vertices": 11,
        "boundary_label_mode": "all_120" if all_labelings else "12_mod_D5",
        "geng_command": command,
        "counts": dict(counts),
        "counterexample": counterexample,
        "all_case_xii_branches_have_pentagon": counterexample is None,
        "candidate_distributions": distributions,
        "minimum_compatible_pentagons": min(
            (s["compatible_pentagons"] for s in candidate_stats), default=None
        ),
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--geng", default="geng")
    parser.add_argument("--json", type=Path)
    parser.add_argument("--all-labelings", action="store_true")
    args = parser.parse_args()
    result = run(args.geng, all_labelings=args.all_labelings)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json:
        args.json.write_text(text + "\n", encoding="utf-8")
    return 1 if result["counterexample"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
