# Low-order boundary for the unified Case-XII pole claim

## Question tested

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

The published Case-XII side has the 40 BF boundary types

\[
 \mathcal L_{\mathrm{XII}}
 =\{[s]:s\in S\}
   \cup\{(s)(s'):s\ne s',\ s,s'\in S\}
   \cup\{(s)(t):s\in S,\ t\in T\}.
\]

Thus it has five S-loops, ten distinct S--S types, and all 25 S--T types;
it has neither the A type \((12345)\) nor a T--T type.  The pole-level
question tested here is the strongest exact form relevant to the published
case:

> Does a simple connected cubic 5-pole with five distinct terminals have
> complete BF support exactly \(\mathcal L_{\mathrm{XII}}\), while having no
> A-cover?

The test does **not** impose a Tait state set.  Every BF type is decided from
the same pole's complete perfect-matching family.  For each candidate we
enumerate all perfect matchings, group them by boundary subset, and test all
55 non-A types by the exact six-matching completion equations.  The A type is
tested independently by the singleton capacity-two search.

## Exhaustive range

Every unlabelled simple connected augmented graph with one degree-five apex
and all remaining vertices of degree three was streamed from nauty `geng`.
Deleting the apex gives exactly the corresponding simple connected cubic
5-pole with five distinct terminal vertices.  The internal pole orders tested
were

\[
 n=5,7,9,11.
\]

The graph counts after the degree-sequence and connected-pole filters were:

| internal order | augmented graphs read | exact degree sequence | connected poles |
|---:|---:|---:|---:|
| 5  | 4    | 1   | 1   |
| 7  | 35   | 7   | 6   |
| 9  | 357  | 59  | 52  |
| 11 | 4291 | 581 | 536 |

For each pole, terminal labels were canonicalised under all (5!\) boundary
permutations before comparison with \(\mathcal L_{\mathrm{XII}}\).  Therefore
the result is independent of the temporary ordering of the five apex
neighbours and does not assume the standard pentagon labelling in advance.

## Result

The number of exact Case-XII-support, no-A poles was

\[
\boxed{0}
\]

at every tested order and in the union of all four orders.  Consequently,
within this finite range there is no real pole counterexample to the proposed
unified boundary claim, including no non-3-edge-colourable realization hidden
by an exact-S filter.

The result is only a finite lower-order boundary.  It is not a proof for
arbitrary order, does not establish that the non-Tait branch is empty, and
does not prove the Case-XII exclusion or the Berge--Fulkerson conjecture.
In particular, no conclusion is drawn for order 13 or higher; that extension
was intentionally stopped because a zero result there would not by itself
decide the analytic interface.

## Reproduction

From the project root:

```text
python3 units/berge-fulkerson/scratch/worker-bf-s-gate/target_case_xii_support_scan.py --max-order 11
```

The deterministic terminal line is:

```text
TARGET_CASE_XII_SUPPORT_SCAN_OK
```

The script is exploratory scratch only.  It uses the project's exact
perfect-matching completion routine and does not modify permanent notes.
