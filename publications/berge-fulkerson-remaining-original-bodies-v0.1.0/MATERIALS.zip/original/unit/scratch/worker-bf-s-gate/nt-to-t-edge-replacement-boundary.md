# The non-Tait-to-Tait interface is not pole-local

## Statement

Let (H) be any simple connected cubic 5-pole.  If a proper edge (e) of
(H) is replaced by the two-pole (J=P-e_0), where (P) is the Petersen
graph and (e_0) is one of its edges, then the resulting 5-pole (H') has
exactly the same BF boundary-type support as (H), but (H') is not
3-edge-colourable.

This is a pole-level conditional boundary: if a real pole with the exact
Case-XII support (mathcal L_{m XII}) and no (A)-type existed, this
replacement would produce a real non-Tait pole with the same complete support.
It is not itself a Case-XII pole, because no real exact-(mathcal L_{m XII})
pole is currently known and the replacement need not preserve whole-graph
girth or cyclic connectivity.

## Why the Petersen two-pole is an edge-equivalent BF gadget

The Petersen graph has six perfect matchings; their six matching vectors cover
each Petersen edge exactly twice.  Deleting (e_0) therefore gives a BF
colouring of (J) whose two semiedges have the same label (F), where (F)
is a 2-subset of the six colours.  Permuting the six colours gives this
extension for every possible (F).

Conversely, every BF colouring of (J) gives equal labels on its two
semiedges.  If (c) is one colour and (b_c) is the number of terminal
semiedges carrying (c), counting incidences at the ten internal vertices
gives

\[
10=2m_c+b_c.
\]

Thus (b_c) is even.  Since (J) has only two semiedges, a colour occurs
on one terminal exactly when it occurs on the other; both terminal labels are
the same 2-subset (F).  The same parity count for a perfect matching shows
that a matching of (J) uses either both semiedges or neither.  Both cases
occur because (P) has a perfect matching containing (e_0) and one avoiding
(e_0).

## Support preservation under replacement

Delete (e=uv) from (H), glue the two semiedges of (J) to (u) and (v),
and call the resulting pole (H').  For every perfect matching of (H),
use in (J) a matching using both terminals when (e) is selected, and a
matching using neither when (e) is not selected.  Conversely, restricting a
perfect matching of (H') to (J) and contracting (J) back to (e) gives
the inverse map on the selected/not-selected behaviour.

For a BF colouring of (H), the label (F) on (e) can be extended through
(J) by the Petersen BF colouring with both terminal labels (F); the labels
on every original edge and semiedge are unchanged.  For a BF colouring of
(H'), equality of the two terminal labels allows (J) to be contracted to
one edge carrying (F).  Hence the complete BF boundary-type sets satisfy

\[
\mathcal C(H')=\mathcal C(H),
\]

including the (A=(12345)) type and all S--S, S--T and T--T types.  This is a
common perfect-matching incidence statement, not merely a boundary-graph
analogy.

## The replacement destroys Tait colourability

If (J) admitted a proper 3-edge-colouring, the same parity count forces its
two terminals to receive the same colour.  Gluing them back to recover
(P) would give a proper 3-edge-colouring of the Petersen graph, impossible
because Petersen is a snark.  Therefore (J), and hence (H'), is
non-3-edge-colourable.

## Consequence for Case XII

The implication

\[
\mathcal C(H)=\mathcal L_{\rm XII}quad\Longrightarrow\quad
H\text{ is Tait-colourable}
\]

cannot be established from the complete pole BF support, Kempe closure, and
common perfect-matching incidence alone.  Any such theorem would also prove
that no pole with (mathcal C(H)=\mathcal L_{\rm XII}) exists at all.  An
actual exclusion of non-Tait Case XII must therefore use additional structure
of the glued whole graph (for example cyclic 5-edge-connectivity) or a direct
non-realizability theorem for (mathcal L_{\rm XII}).

This is a strict applicability boundary, not a concrete real-pole
counterexample to Case XII.
