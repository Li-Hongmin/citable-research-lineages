#!/usr/bin/env python3
"""Targeted low-order test for the *exact* Case-XII boundary support.

This is deliberately narrower than a census: it streams the already relevant
simple connected augmented cubic graphs of orders 5,7,9,11 and tests whether
the complete perfect-matching incidence of one pole has exactly the 40 BF
types in Figure 7, case XII.  No Tait-state or abstract quotient assumption
is imposed.  A support is canonicalised under all five-terminal relabellings,
so each unlabelled skeleton is tested only once.

The script is an exploratory certificate, not a proof in arbitrary order.
"""

from __future__ import annotations

import argparse
import itertools
import subprocess
import sys
from collections import Counter
from pathlib import Path

import networkx as nx

HERE = Path(__file__).resolve().parent
JOINT = HERE.parent / "worker-kempe"
sys.path.insert(0, str(JOINT))
import exact_st_joint_audit as joint  # noqa: E402


POSITIONS = tuple(range(1, 6))
PAIRS = tuple(itertools.combinations(POSITIONS, 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
TYPES = tuple(itertools.combinations_with_replacement(PAIRS, 2))


def target_support():
    """The published XII support: 10 SS edges, 25 ST edges, 5 S loops."""
    out = set()
    for a, b in TYPES:
        if a == b:
            if a in S:
                out.add((a, b))
        elif a in S and b in S:
            out.add((a, b))
        elif (a in S) ^ (b in S):
            out.add((a, b))
    assert len(out) == 40, len(out)
    return frozenset(out)


TARGET = target_support()


def canonical_type(kind, permutation):
    if kind == ("A",):
        return kind
    a, b = kind
    def map_pair(pair):
        return tuple(sorted(permutation[x] for x in pair))
    return tuple(sorted((map_pair(a), map_pair(b))))


def canonical_support(support):
    keys = []
    for perm in itertools.permutations(POSITIONS):
        mapping = {x: perm[x - 1] for x in POSITIONS}
        image = tuple(sorted(canonical_type(kind, mapping) for kind in support))
        keys.append(image)
    return min(keys)


TARGET_CANONICAL = canonical_support(TARGET)


def pole_from_augmented(graph, apex):
    neighbours = tuple(sorted(graph.neighbors(apex)))
    # Temporary positions 1,...,5; canonical_support removes this choice.
    mapping = {position: vertex for position, vertex in enumerate(neighbours, 1)}
    inverse = {vertex: position - 1 for position, vertex in mapping.items()}
    internal = sorted(set(graph) - {apex} - set(inverse))
    relabel = dict(inverse)
    relabel.update({vertex: 5 + i for i, vertex in enumerate(internal)})
    proper = tuple(sorted(
        joint.base.legacy.canonical_edge(relabel[u], relabel[v])
        for u, v in graph.edges() if apex not in (u, v)
    ))
    return joint.base.legacy.Pole(n=len(graph) - 1, proper_edges=proper)


def full_non_a_support(data):
    support = set()
    for kind in TYPES:
        ok, _, _ = joint.type_support_and_routes(kind, data, need_routes=False)
        if ok:
            support.add(kind)
    return frozenset(support)


def inspect_graph(graph):
    apex = next(v for v, d in graph.degree() if d == 5)
    proper = graph.copy()
    proper.remove_node(apex)
    if not nx.is_connected(proper):
        return None
    pole = pole_from_augmented(graph, apex)
    data = joint.matching_data(pole)
    support = full_non_a_support(data)
    # Type A is exactly the singleton capacity-two witness.
    has_a = joint.capacity_witness(data) is not None
    return {
        "pole": pole,
        "pm_count": data[-1],
        "support": support,
        "has_A": has_a,
        "tait_states": joint.base.legacy.enumerate_tait_states(pole),
    }


def scan_order(order, geng):
    command = [geng, "-q", "-c", "-d3", "-D5", str(order + 1), str((3 * order + 5) // 2)]
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    assert proc.stdout is not None
    counts = Counter()
    candidates = []
    for line in proc.stdout:
        counts["augmented"] += 1
        graph = nx.from_graph6_bytes(line.strip().encode("ascii"))
        if Counter(dict(graph.degree()).values()) != Counter({3: order, 5: 1}):
            continue
        counts["degree"] += 1
        record = inspect_graph(graph)
        if record is None:
            continue
        counts["connected_poles"] += 1
        if canonical_support(record["support"]) == TARGET_CANONICAL and not record["has_A"]:
            counts["exact_xii"] += 1
            candidates.append(record)
    code = proc.wait()
    if code != 0:
        raise RuntimeError((command, code))
    return counts, candidates


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=11)
    parser.add_argument("--geng", default="geng")
    args = parser.parse_args()
    if args.max_order < 5 or args.max_order % 2 == 0:
        raise ValueError("max-order must be odd and at least five")
    all_counts = {}
    all_candidates = []
    for order in range(5, args.max_order + 1, 2):
        counts, candidates = scan_order(order, args.geng)
        all_counts[order] = dict(counts)
        all_candidates.extend((order, x) for x in candidates)
    print({"counts": all_counts, "exact_xii_candidates": len(all_candidates)})
    for order, record in all_candidates:
        print({"order": order, "pm_count": record["pm_count"],
               "tait_states": sorted(record["tait_states"]),
               "proper_edges": record["pole"].proper_edges})
    print("TARGET_CASE_XII_SUPPORT_SCAN_OK")


if __name__ == "__main__":
    main()
