# Median-exchange Helly condition at the D5 gate

## Scope

This note attacks only the remaining cross-column implication for the five
disjoint (D_5) cells.  It does not add a support census, route invariant, or
load relaxation.  All matching sets below are actual perfect matchings of one
common cubic (5)-pole (H).

Put

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\},
\]

and let

\[
 D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For a cell (d), write (widehatPi_d) for its actual four-singleton
witness relation and (Pi_d) for the cylinder obtained by freeing its one
missing singleton coordinate.  The exact target is

\[
 \exists d_0\in D_5:
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing. \tag{1}
\]

By the established (S\! -\!T) to disjoint (S\! -\!S) path-toggle transfer,
(1) is equivalent on the same pole to the corresponding four-cell join of
the five disjoint (S\! -\!S) relations.

## Exact pivot reduction

Fix (J=D_5\setminus\{d_0\}), an anchor (a\in J), and an actual tuple
(x\inwidehatPi_a).  Let (m) be the singleton coordinate omitted by the
anchor.  For (d\in J\setminus\{a\}), define

\[
 E_d(x)=\{P\in\mathcal P_m:
 \text{some }y\in\widehatPi_d\text{ agrees with }x
 \text{ on }U_a\cap U_d\text{ and uses }P\text{ at }m\}.
 \tag{2}
\]

Then the coordinate restriction identity is exact:

\[
 x\text{ extends to }\bigcap_{d\in J}\Pi_d
 \quad\Longleftrightarrow\quad
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing. \tag{3}
\]

## A strict sufficient theorem beyond the tree case

Let (X_m(H)) be the graph on (mathcal P_m) in which two vertices are
adjacent when their symmetric difference is one proper alternating cycle.
Assume that for some ((J,a,x)):

1. (X_m(H)) is a finite **median graph** (in particular, a hypercube of
   independent alternating-cycle switches is allowed);
2. each of the three nonempty fibres (E_d(x)) is a convex subgraph of
   (X_m(H));
3. these three convex fibres intersect pairwise.

Then (1) holds.  Indeed, convex subsets of a median graph have the finite
Helly property.  Hence the three fibres in (2) have a common vertex, and (3)
produces the four-cell join.  The standard four-cell load argument then gives
the forbidden all-boundary (A=(12345)) cover.

The proof is purely graph-theoretic: for three convex sets (C_1,C_2,C_3)
in a median graph, choose (u_i\in C_i\cap C_{i+1}) cyclically.  The median
(z=m(u_1,u_2,u_3)) lies on each interval between two points of the same
convex set, so (z\in C_1\cap C_2\cap C_3).  (The same argument gives the
finite Helly property.)  Trees are median graphs, so this strictly contains
the previous tree-exchange criterion.

### Explicit hypercube form

A directly checkable special case is that every matching in the relevant
component of (mathcal P_m) is obtained from a base matching by toggling a
fixed set of pairwise edge-disjoint proper alternating cycles.  Encode it by
(z\in\{0,1\}^r), with one bit per cycle, and suppose each (E_d(x)) is a
subcube (some coordinates fixed).  Pairwise intersection means that no two
fibres prescribe conflicting values on any coordinate; choosing all prescribed
bits consistently gives a common matching.  This is the same theorem without
invoking median-graph terminology.

## Why this does not settle Case XII

The complete Case-XII support and the absence of (T)-loops/(T\! -\!T)
give nonemptiness of each cell relation and determine the endpoint pairing
in the (S\! -\!T) transfer.  They do not imply any of the three median-
Helly hypotheses:

* a singleton matching exchange graph may have commuting-cycle squares and
  other non-median identifications;
* an extension fibre can be disconnected because a missing singleton change
  is absorbed by simultaneous changes of the two triple matchings;
* pairwise intersection of the three pivot fibres is already a cross-cell
  witness-reuse assertion, not a consequence of support nonemptiness.

Subtracting two witnesses still gives only the cycle-absorption identity

\[
 (\chi_{Q'_s}-\chi_{Q_s})+(\chi_{Q'_t}-\chi_{Q_t})
 +\sum_i(\chi_{P'_i}-\chi_{P_i})=0,
\]

and does not supply a third six-matching tuple of forbidden type.

## Four-value decision

* General proof of (1): **not obtained**.
* A real cubic pole with exact forty Case-XII support and all five joins
  empty: **not obtained**.
* Strict additional condition: the median-exchange/convex-fibre/pairwise-
  overlap condition above (with UE2 and tree-Helly as simpler special cases).
* Correct status: **real-pole question remains undecided; this interface is
  closed for the within-column and subtraction routes**.

No new graph generation or order scan is justified by this result.
