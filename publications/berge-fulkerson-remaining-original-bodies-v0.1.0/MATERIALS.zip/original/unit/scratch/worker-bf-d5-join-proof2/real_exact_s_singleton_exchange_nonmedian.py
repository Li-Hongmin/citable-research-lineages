"""Check non-median singleton exchange graphs on the frozen n=15 exact-S pole."""
import importlib.util

path = "units/berge-fulkerson/scratch/worker-proof/verify_exact_s_odd_half_support.py"
spec = importlib.util.spec_from_file_location("pole", path)
pole = importlib.util.module_from_spec(spec); spec.loader.exec_module(pole)

pm = pole.enumerate_perfect_matchings()
classes = {i: [] for i in range(5)}
for M in pm:
    s = [i for i in range(5) if pole.semi(i + 1) in M]
    if len(s) == 1: classes[s[0]].append(M)

def exchange_graph(arr):
    adj = [[] for _ in arr]
    for a in range(len(arr)):
        for b in range(a):
            d = arr[a] ^ arr[b]; proper = [e for e in d if e < len(pole.EDGES)]
            verts, arcs = set(), []
            for e in proper:
                u, v = pole.EDGES[e]; verts.update((u, v)); arcs += [(u, v), (v, u)]
            seen, stack = set(), ([next(iter(verts))] if verts else [])
            while stack:
                v = stack.pop()
                if v in seen: continue
                seen.add(v); stack += [w for x, w in arcs if x == v and w not in seen]
            if seen == verts: adj[a].append(b); adj[b].append(a)
    return adj

def dist(adj, x, y):
    q, ds = [x], {x: 0}
    for v in q:
        for w in adj[v]:
            if w not in ds: ds[w] = ds[v] + 1; q.append(w)
    return ds.get(y, 10**9)

for i, arr in classes.items():
    adj = exchange_graph(arr); witness = None
    for x in range(len(arr)):
      for y in range(x + 1, len(arr)):
       for z in range(y + 1, len(arr)):
        med = [w for w in range(len(arr)) if dist(adj,x,w)+dist(adj,w,y)==dist(adj,x,y) and dist(adj,x,w)+dist(adj,w,z)==dist(adj,x,z) and dist(adj,y,w)+dist(adj,w,z)==dist(adj,y,z)]
        if len(med) != 1: witness = (x, y, z, med); break
       if witness: break
      if witness: break
    assert witness is not None
    print(i + 1, len(arr), sum(map(len, adj)) // 2, witness)
print("REAL_EXACT_S_SINGLETON_EXCHANGE_NONMEDIAN_VERIFIED")
