# P_join at the common-perfect-matching interface (2026-09-02)

## Scope and exact question

Put

\[
 S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\},
\]

and let

\[
 D_5=\{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For one simple connected cubic 5-pole (H), let \(\widehat\Pi_d\) be the
set of four-tuples of **actual** singleton-boundary perfect matchings in a
six-matching completion of cell (d\), and let \(\Pi_d\) be its
five-coordinate cylinder (the unique omitted singleton coordinate is free).

The only live implication is

\[
\tag{P_join}
\text{all 40 Case-XII support types and no (A,T\)-loop, or (T\!\!-​T)}
\Longrightarrow
\exists d_0\in D_5:\ \bigcap_{d\ne d_0}\Pi_d\ne\varnothing .
\]

This note uses one common PM family and symmetric differences only.  It does
not use a load relaxation, a boundary-relation model, or an order scan.

## What is proved: exact D5 transfer

For a D5 cell (d=(s,t)), a witness has actual matchings

\[
Q_s,Q_t,(P_i)_{i\in s\cup t},\qquad
\chi_{Q_s}+\chi_{Q_t}+\sum_{i\in s\cup t}\chi_{P_i}=2\mathbf1 .
\tag{1}
\]

The symmetric difference (Q_s\triangle Q_t) has two terminal paths,
possibly together with proper even cycles.  Toggle either terminal path in
both triple matchings.  The singleton matchings and (1) are unchanged.
The three endpoint pairings produce, respectively,

\[
 (A,A),\qquad (S\!\!-​S,S\!\!-​S),\qquad (T\!\!-​T,T\!\!-​T)
\]

when (s\in S,t\in T) are disjoint.  Under the negative Case-XII support
assumptions only the middle pairing is possible.  The reverse toggle gives
the converse.  Hence, as relations on the same four actual singleton PMs,

\[
\begin{array}{c|c}
d&\text{equal disjoint (S\!\!-​S) cell}\ \hline
(13,45)&(14,35)\\
(14,23)&(13,24)\\
(24,15)&(14,25)\\
(25,34)&(24,35)\\
(35,12)&(13,25).
\end{array}
\tag{2}
\]

This equality is verified by the finite endpoint certificate
`worker-bf-d5-join-proof/verify_d5_ss_transfer.py`, which ends with
`D5_SS_TRANSFER_TABLE_VERIFIED`.

## Exact pivot reduction and a sufficient theorem

Fix four cells (J=D_5\setminus\{d_0\}), an anchor (a\in J), and
an actual tuple (x\in\widehat\Pi_a).  Let (m=m(a)) be the missing
coordinate.  For (d\in J\setminus\{a\}), define

\[
 E_d(x)=\{P\in\mathcal P_m:\text{some tuple in }\widehat\Pi_d
 \text{ agrees with }x\text{ on }U_a\cap U_d\text{ and uses }P\text{ at }m\}.
\tag{3}
\]

Then, by coordinate restriction (no incidence relaxation),

\[
 x\text{ extends to }\bigcap_{d\in J}\Pi_d
 \quad\Longleftrightarrow\quad
 \bigcap_{d\in J\setminus\{a\}}E_d(x)\ne\varnothing .
\tag{4}
\]

Two useful sufficient conditions follow.

* **UE2.** The three fibres in (3) are singletons and at least two of
  their three values are equal.  Then (4) gives the four-cell join.
* **Tree-Helly.** The one-coordinate single-cycle exchange graph on
  \(\mathcal P_m\) is a tree; each fibre in (3) is a nonempty connected
  subtree; and the three fibres intersect pairwise.  Finite subtrees of a
  tree satisfy Helly, so (4) again gives the join.

Any such join yields (A=(12345)): the four scopes cover every 3-subset of
the five terminals, so no proper edge can lie in three of the five singleton
PMs.  At each cubic vertex their total incidence is five, hence the proper
edge loads are \((2,2,1)\); load-one edges (and the five semiedges) form a
sixth perfect matching.

## Why the Case-XII hypotheses stop short

Half-load/Kempe saturation proves only that each fixed (T)-column contains
all five (S\)-rows for the *same* carrier half.  Different columns may have
different complementary half-loads and different singleton fibres.  For two
witnesses, subtraction gives only

\[
 (\chi_{Q'_s}-\chi_{Q_s})+(\chi_{Q'_t}-\chi_{Q_t})
 +\sum_i(\chi_{P'_i}-\chi_{P_i})=0,
\tag{5}
\]

where every same-boundary difference is a union of proper alternating cycles.
Equation (5) permits a change in the missing singleton to be absorbed by the
two triple-matchings; it does not identify singleton PMs across columns.
The repeated singleton slots in overlapping (S\!\!-​T) cells provide the
same cycle-absorption identity and no additional equality.

Thus the exact remaining quantifier is

\[
\boxed{\text{five saturated actual carrier columns}\Longrightarrow
\text{one four-column singleton join}.}
\]

No proof of this implication and no real pole with all forty Case-XII types
and all five joins empty was obtained.  The exact-S C10 and all-(S\!\!-​T)
no-(A) poles are only boundary tests: their joins are empty, but the former
has missing (S\!\!-​T) support and the latter has extra (T)-loops/
(T\!\!-​T) types.  Therefore the mathematically correct decision is

\[
\boxed{\text{P_join remains undecided at the real-pole level; the
within-column route is closed.}}
\]

The actual-PM boundary audit is reproducible with
`worker-bf-d5-singleton-gate/audit_d5_pivot_extension_boundary.py`; it ends
with `D5_PIVOT_EXTENSION_BOUNDARY_VERIFIED` and records the zero four-way
joins and the (0/1)-edge UE2 obstruction on the two frozen poles.

