# Exact-40 type support does not force an extendible pivot star at witness-hypergraph level

## Decision

The real-pole statement (P_\star) remains undecided, but it cannot be proved
from the forty type-level existential statements, the five column-saturation
conclusions of Note 055, and the five row transports of Note 057.  There is
a strict common-PM-token witness hypergraph with exactly the forty positive
Case-XII types, no declared (A), (T)-loop, or (T)--(T) witness, five fully
saturated (T)-columns, all five literal A5-to-D5 transports, and no
extendible D5 pivot star.

The construction does not assign common edge-incidence vectors or cubic
vertex equations to the PM tokens.  It is therefore a strict quantifier
boundary, not a real pole counterexample.

## Five saturated carrier columns and transported relations

Use the D5 cells in transported A5 order:

\[
 (35,12),(14,23),(25,34),(13,45),(24,15).
\]

For each singleton class (i), use the two global PM tokens (0_i,1_i).
Take the five two-point relations from Note 058:

\[
\begin{array}{c|c|c}
&\text{transported equality}&\text{fixed coordinates}\\ \hline
1&x_1=x_5&x_2=0_2, x_3=0_3\\
2&x_2=x_1&x_3=1_3, x_4=0_4\\
3&x_3=x_2&x_4=1_4, x_5=0_5\\
4&x_4=x_3&x_5=1_5, x_1=0_1\\
5&x_5=x_4&x_1=1_1, x_2=1_2.
\end{array}                                                   \tag{1}
\]

Fix one row, write its overlap cell as ((ia,ij)) and its transported
disjoint cell as ((ab,ij)).  There are two carrier phases.  In each phase,
retain the same row token (R_{ij}) and the same two singleton tokens at the
endpoints of (ij) while the complementary half is decomposed at every one
of the five states in (S).  Thus every cell in the whole (ij)-column has
two carrier witnesses.  This is the literal witness-hypergraph form of the
column saturation supplied by Note 055, rather than five unrelated
type-support declarations.

At the disjoint state (ab), choose the complementary singleton tokens so
that the two resulting four-tuples are exactly the corresponding relation
in (1).  At the overlap state (ia), put the other (i)-token in the
complementary half.  Each overlap witness therefore contains both
(0_i) and (1_i).  Each transported D5 witness literally reuses
(R_{ij}), the fixed (a)- and (j)-tokens, and one of these two actual
(i)-tokens; only its (b)-token is new.  This is precisely the reuse in the
two transport equations of Note 057.  The verifier checks the token
identities, not merely the two relation sizes.

The other three complementary (S)-state decompositions in the column may
use private triple and singleton tokens, but their (T)-half remains the
fixed carrier of that phase.  Repeat this construction for all five
(T)-columns.  Only the fifteen (S)--(S) types are then supplied by wholly
private witnesses.  Hence all twenty-five (S)--(T) cells have two carrier
witnesses, all fifteen (S)--(S) types occur, and no forbidden-type
hyperedge is declared.

## No extendible star

Make the five-partite compatibility graph whose vertices are tuples in the
five relations.  Join tuples from different cells when they agree on their
three common singleton coordinates.  An extendible pivot star exists exactly
when some tuple has neighbours in at least three distinct other cell parts.

For (1), the only compatibility edges are one edge between rows (1,3) and
one edge between rows (2,5).  Every tuple therefore has neighbours in at
most one other part.  In particular, for every four-cell set, every anchor,
and both anchor tuples, at least one of the three separate extension fibres
is empty.  The number of extendible stars is zero.

## Exact additional condition

Let (G_{\rm comp}) be the five-partite tuple-compatibility graph just
defined, and let

\[
 d_{\rm part}(x)=#\{d\ne a:N(x)\cap\widehat\Pi_d\ne\varnothing\}
 \quad(x\in\widehat\Pi_a).
\]

Then the desired conclusion is precisely

\[
                    \max_x d_{\rm part}(x)\ge3.             \tag{2}
\]

Condition (2) is the sharp missing witness-reuse property.  Even exact-40
support together with five saturated carrier columns and the five literal
row transports gives no positive lower bound beyond one on
(d_{\rm part}) in this witness model.  Any proof of (P_\star) for real poles
must therefore derive (2) from common edge incidence, cubic vertex equations,
and complete perfect-matching closure, or from a further consequence of the
negative support assumptions.  It cannot infer (2) by identifying unrelated
existential witnesses from different columns.

## Relation to the Note 070 real-pole boundary

The obstruction in Note 070 does not already contain the saturated-column
structure used here.  In its ((13,45)) row, the complementary half-load has
decomposition-state set

\[
                 \{12,13,23\},
\]

while the fixed (45)-side half has state set

\[
                 \{23,25,34,45\}.
\]

The first set contains (T)-states and is not (S)-universal; this is exactly
why the four other cells of the (45)-column are absent.  Under exact-40 and
no (T)-loop/(T)--(T) support, Note 055 instead forces the minimal new real
structure: a fixed (T_{45}) half together with an (S)-universal complementary
half.  The same requirement holds in all five columns.  The unresolved real
question is whether common edge/vertex incidence couples those five
S-universal complements strongly enough to force (2).

## Evidence level

This is a strict common-token witness-hypergraph countermodel to the
implication

\[
\text{exact-40 support}
+\text{Note 055 column saturation}
+\text{Note 057 row transports}
\Longrightarrow P_\star.
\]

It has no common edge-incidence vectors, cubic vertex equations, or full
perfect-matching closure.  It therefore neither proves nor refutes
(P_\star) for real simple connected cubic 5-poles.

Reproduce with

```text
python3 units/berge-fulkerson/scratch/worker-bf-pstar-witness-hypergraph/verify_exact40_no_extendible_star_hypergraph.py
```

ending in

```text
EXACT40_NO_EXTENDIBLE_STAR_HYPERGRAPH_VERIFIED
```
