#!/usr/bin/env python3
"""Exact-40 witness-hypergraph boundary with no extendible D5 pivot star."""

from itertools import combinations, combinations_with_replacement


S = ((1, 3), (1, 4), (2, 4), (2, 5), (3, 5))
T = ((1, 2), (1, 5), (2, 3), (3, 4), (4, 5))
A5 = (
    ((1, 3), (1, 2)),
    ((2, 4), (2, 3)),
    ((3, 5), (3, 4)),
    ((1, 4), (4, 5)),
    ((2, 5), (1, 5)),
)
D5 = (
    ((3, 5), (1, 2)),
    ((1, 4), (2, 3)),
    ((2, 5), (3, 4)),
    ((1, 3), (4, 5)),
    ((2, 4), (1, 5)),
)

# None is the coordinate omitted by the D5 cell.  These are exactly the five
# two-point relations of Note 058.
RELATIONS = (
    ((0, 0, 0, None, 0), (1, 0, 0, None, 1)),
    ((0, 0, 1, 0, None), (1, 1, 1, 0, None)),
    ((None, 0, 0, 1, 0), (None, 1, 1, 1, 0)),
    ((0, None, 0, 0, 1), (0, None, 1, 1, 1)),
    ((1, 1, None, 0, 0), (1, 1, None, 1, 1)),
)


def missing(row):
    return row.index(None)


def extensions(anchor, other):
    anchor_missing = missing(anchor)
    return {
        row[anchor_missing]
        for row in other
        if all(
            left == right
            for left, right in zip(anchor, row, strict=True)
            if left is not None and right is not None
        )
    }


def main():
    positive = set(combinations_with_replacement(S, 2))
    positive.update((s, t) for s in S for t in T)
    assert len(positive) == 40

    # Saturate all five T columns.  For each of the two carrier phases, the
    # same R and the same two T-endpoint singleton tokens are retained while
    # the S state runs through all five choices, exactly as in Note 055.
    hyperedges = {kind: [] for kind in positive}
    for row, (a5, d5, relation) in enumerate(zip(A5, D5, RELATIONS, strict=True)):
        i = next(iter(set(a5[0]) & set(a5[1])))
        a = next(iter(set(a5[0]) - {i}))
        j = next(iter(set(a5[1]) - {i}))
        b = next(iter(set(d5[0]) - {a}))
        r_token = f"R{row}"
        for bit, tuple_row in enumerate(relation):
            b_half = {
                position: f"{tuple_row[position - 1]}_{position}"
                for position in a5[1]
            }
            for s_index, s_state in enumerate(S):
                if s_state == d5[0]:
                    a_half = {
                        position: f"{tuple_row[position - 1]}_{position}"
                        for position in s_state
                    }
                elif s_state == a5[0]:
                    # Reverse the row transport: the A half uses the other
                    # i-token and the fixed a-token, while the B half uses the
                    # D5 tuple's i-token and fixed j-token.
                    a_half = {
                        i: f"{1 - tuple_row[i - 1]}_{i}",
                        a: f"{tuple_row[a - 1]}_{a}",
                    }
                else:
                    a_half = {
                        position: f"private_{row}_{bit}_{s_index}_{position}"
                        for position in s_state
                    }
                # Keep the two half decompositions distinct.  In an overlap
                # cell the repeated terminal occurs once in each half, so a
                # dictionary lookup by terminal would silently use the same
                # token twice and destroy the literal transport witness.
                singleton_tokens = tuple(a_half[position] for position in s_state)
                singleton_tokens += tuple(b_half[position] for position in a5[1])
                hyperedges[(s_state, a5[1])].append((
                    f"Q{row}_{bit}_{s_index}", r_token, *singleton_tokens
                ))

        # The two transported pairs are (1_i,1_b) and (0_i,0_b), with the
        # new b-occurrences oppositely slotted as in Note 057.
        assert {tuple_row[i - 1] for tuple_row in relation} == {0, 1}
        assert {tuple_row[b - 1] for tuple_row in relation} == {0, 1}
        assert all(tuple_row[i - 1] == tuple_row[b - 1] for tuple_row in relation)

        # The D5 cell is exactly the prescribed two-point relation, not a
        # larger relation accidentally introduced by column saturation.
        d5_witnesses = hyperedges[d5]
        assert len(d5_witnesses) == 2
        for tuple_row, witness in zip(relation, d5_witnesses, strict=True):
            expected = tuple(
                f"{tuple_row[position - 1]}_{position}"
                for position in d5[0] + d5[1]
            )
            assert witness[1] == r_token
            assert witness[2:] == expected

        # Each overlap witness contains both i-tokens.  Each of the two D5
        # witnesses literally reuses R plus the fixed a- and j-tokens and
        # one of those i-tokens, as in the two equations of Note 057.
        a5_witnesses = hyperedges[a5]
        assert len(a5_witnesses) == 2
        for witness in a5_witnesses:
            assert {f"0_{i}", f"1_{i}"}.issubset(witness[2:])
            for transported in d5_witnesses:
                assert witness[1] == transported[1] == r_token
                assert len(set(witness[2:]) & set(transported[2:])) == 3

    assert all(len(hyperedges[(s, t)]) == 2 for s in S for t in T)

    # The remaining fifteen S--S types receive private witnesses.  Private
    # token names prevent this existential support from silently adding
    # cross-cell reuse not forced by the saturated T columns.
    for index, kind in enumerate(sorted(positive, key=str)):
        if hyperedges[kind]:
            continue
        first, second = kind
        hyperedges[kind].append((
            f"Q{index}_0", f"Q{index}_1",
            *(f"P{index}_{slot}_{position}"
              for slot, position in enumerate(first + second)),
        ))

    assert set(kind for kind, witnesses in hyperedges.items() if witnesses) == positive
    assert all(kind[0] in S for kind in hyperedges)
    assert not any(kind[0] in T and kind[1] in T for kind in hyperedges)

    extendible = []
    compatibility_edges = []
    for left, right in combinations(range(5), 2):
        for left_phase, anchor in enumerate(RELATIONS[left]):
            for right_phase, candidate in enumerate(RELATIONS[right]):
                if extensions(anchor, (candidate,)):
                    compatibility_edges.append(
                        (left + 1, left_phase, right + 1, right_phase)
                    )
    assert len(compatibility_edges) == 2
    assert {(left, right) for left, _, right, _ in compatibility_edges} == {
        (1, 3), (2, 5)
    }

    for omitted in range(5):
        chosen = tuple(index for index in range(5) if index != omitted)
        for anchor_index in chosen:
            others = tuple(index for index in chosen if index != anchor_index)
            for anchor in RELATIONS[anchor_index]:
                fibres = tuple(extensions(anchor, RELATIONS[index]) for index in others)
                if all(fibres):
                    extendible.append((omitted, anchor_index, anchor, fibres))
    assert not extendible

    print({
        "positive_support_types": len(positive),
        "saturated_T_columns": 5,
        "witnesses_per_ST_cell": 2,
        "D5_transferred_relation_sizes": tuple(map(len, RELATIONS)),
        "compatibility_edges": tuple(compatibility_edges),
        "extendible_pivot_stars": len(extendible),
        "forbidden_declared_types": 0,
        "common_PM_tokens": True,
        "common_edge_or_vertex_incidence": False,
    })
    print("EXACT40_NO_EXTENDIBLE_STAR_HYPERGRAPH_VERIFIED")


if __name__ == "__main__":
    main()
