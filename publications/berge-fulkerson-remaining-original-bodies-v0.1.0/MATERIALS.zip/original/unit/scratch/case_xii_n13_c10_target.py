#!/usr/bin/env python3
"""Streamed exact search for the Case-XII connected-C10 obstruction.

For odd ``n`` internal vertices, adjoining an apex to the five distinct
terminal vertices gives a simple graph with degree sequence ``(5, 3^n)``.
This script streams the corresponding unlabelled augmented graphs from
nauty ``geng``.  It enumerates Tait states only once per unlabelled skeleton:
the five terminal neighbours receive an arbitrary temporary labelling, and
the state graph is tested directly for being a 5-cycle.  If it is, a single
isomorphism to the target pentagon ``1-4-2-5-3-1`` supplies the only boundary
labelling needed modulo the target's dihedral automorphism group.

The target is the unique abstract common-relation-size-two obstruction from
Note 004: every consecutive relation has endpoint type D and their layered
union is the connected double cover C10 -> C5.  The search stops immediately
with a complete certificate if a real pole realizes it.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import networkx as nx


HERE = Path(__file__).resolve().parent
UNIT = HERE.parent
BUNDLE = UNIT / "computations/bundles/case-xii-order-11"


def load_legacy():
    path = BUNDLE / "case_xii_pentagon_audit.py"
    spec = importlib.util.spec_from_file_location("case_xii_legacy_n13", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


legacy = load_legacy()


def pole_from_augmented(
    graph: nx.Graph, apex: int, mapping: dict[int, int], n: int
):
    """Relabel the mapped boundary vertices to legacy vertices 0,...,4."""
    inverse = {vertex: position - 1 for position, vertex in mapping.items()}
    internal = sorted(set(graph) - {apex} - set(inverse))
    relabel = dict(inverse)
    relabel.update({vertex: 5 + i for i, vertex in enumerate(internal)})
    proper_edges = []
    for u, v in graph.edges():
        if apex in (u, v):
            continue
        proper_edges.append(legacy.canonical_edge(relabel[u], relabel[v]))
    return legacy.Pole(n=n, proper_edges=tuple(sorted(proper_edges)))


def c5_order(states):
    """Return a deterministic cyclic order iff the exact state graph is C5."""
    if len(states) != 5:
        return None
    adjacency = {i: set() for i in range(1, 6)}
    for a, b in states:
        adjacency[a].add(b)
        adjacency[b].add(a)
    if any(len(adjacency[i]) != 2 for i in range(1, 6)):
        return None
    start = 1
    previous = start
    current = min(adjacency[start])
    order = [start, current]
    while len(order) < 5:
        following = next(x for x in adjacency[current] if x != previous)
        if following in order:
            return None
        order.append(following)
        previous, current = current, following
    if start not in adjacency[current]:
        return None
    return tuple(order)


def normalized_mapping(graph: nx.Graph, apex: int, n: int):
    """Find one target-labelled representative iff the Tait-state graph is C5."""
    neighbours = tuple(sorted(graph.neighbors(apex)))
    temporary = dict(zip(range(1, 6), neighbours))
    pole = pole_from_augmented(graph, apex, temporary, n)
    order = c5_order(legacy.enumerate_tait_states(pole))
    if order is None:
        return None
    old_position_to_vertex = temporary
    mapping = {
        target: old_position_to_vertex[old]
        for target, old in zip(legacy.PENTAGON_ORDER, order)
    }
    normalized = pole_from_augmented(graph, apex, mapping, n)
    if legacy.enumerate_tait_states(normalized) != legacy.S_DIAGONALS:
        raise AssertionError("C5 normalization did not produce the target state set")
    return mapping, normalized


def matching_key(matching):
    return tuple(sorted(matching))


def relation_data(pole):
    matchings, _, edge_position, _ = legacy.enumerate_perfect_matchings(pole)
    singleton = {position: [] for position in range(1, 6)}
    for matching in matchings:
        boundary = legacy.boundary_set(matching, edge_position)
        if len(boundary) == 1:
            singleton[next(iter(boundary))].append(matching)
    for position in singleton:
        singleton[position].sort(key=matching_key)

    order = legacy.PENTAGON_ORDER
    relations = []
    for left, right in zip(order, order[1:] + order[:1]):
        relations.append(tuple(
            (a, b)
            for a in singleton[left]
            for b in singleton[right]
            if a.isdisjoint(b)
        ))
    return tuple(matchings), singleton, tuple(relations)


def endpoint_type(relation):
    if len(relation) != 2:
        return None
    lefts = {edge[0] for edge in relation}
    rights = {edge[1] for edge in relation}
    if len(lefts) == 2 and len(rights) == 2:
        return "D"
    if len(lefts) == 2 and len(rights) == 1:
        return "R"
    if len(lefts) == 1 and len(rights) == 2:
        return "L"
    return "B"  # duplicate edge would be required in a set-valued relation


def layered_graph(relations):
    graph = nx.Graph()
    order = legacy.PENTAGON_ORDER
    for t, relation in enumerate(relations):
        left_position = order[t]
        right_position = order[(t + 1) % 5]
        for left, right in relation:
            graph.add_edge((left_position, left), (right_position, right))
    return graph


def compatible_pentagon_count(relations):
    next_by_left = []
    for relation in relations:
        adjacency = defaultdict(list)
        for left, right in relation:
            adjacency[left].append(right)
        next_by_left.append(adjacency)

    count = 0
    for first_left, first_right in relations[0]:
        def extend(t, current):
            nonlocal count
            if t == 4:
                count += sum(x == first_left for x in next_by_left[t][current])
                return
            for following in next_by_left[t][current]:
                extend(t + 1, following)

        extend(1, first_right)
    return count


def certificate(graph6, mapping, pole, matchings, singleton, relations):
    matching_ids = {
        matching: f"M{index:03d}"
        for index, matching in enumerate(sorted(matchings, key=matching_key), 1)
    }
    layered = layered_graph(relations)

    def pair_id(pair):
        return [matching_ids[pair[0]], matching_ids[pair[1]]]

    return {
        "augmented_graph6": graph6,
        "boundary_position_to_augmented_vertex": {
            str(k): v for k, v in sorted(mapping.items())
        },
        "proper_edges": [list(edge) for edge in pole.proper_edges],
        "tait_states": [list(pair) for pair in sorted(legacy.enumerate_tait_states(pole))],
        "singleton_matching_counts_1_to_5": [len(singleton[i]) for i in range(1, 6)],
        "matching_edge_sets": {
            matching_ids[m]: sorted(m) for m in sorted(matchings, key=matching_key)
        },
        "relations_in_order_14_42_25_53_31": [
            [pair_id(pair) for pair in relation] for relation in relations
        ],
        "relation_endpoint_types": [endpoint_type(r) for r in relations],
        "compatible_pentagons": compatible_pentagon_count(relations),
        "layered_graph_nodes": layered.number_of_nodes(),
        "layered_graph_edges": layered.number_of_edges(),
        "layered_graph_connected": nx.is_connected(layered),
        "layered_graph_degree_multiset": sorted(dict(layered.degree()).values()),
    }


def run(n: int, geng: str):
    if n < 5 or n % 2 == 0:
        raise ValueError("the internal order n must be odd and at least five")
    augmented_n = n + 1
    augmented_edges = (3 * n + 5) // 2
    command = [geng, "-q", "-c", "-d3", "-D5", str(augmented_n), str(augmented_edges)]
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, text=True)
    if proc.stdout is None:
        raise RuntimeError("failed to open geng output")

    counts = Counter()
    relation_size_vectors = Counter()
    endpoint_type_vectors = Counter()
    compatible_pentagon_distribution = Counter()
    counterexample = None
    started = time.perf_counter()

    for line in proc.stdout:
        graph6 = line.strip()
        counts["geng_connected_degree_bounded"] += 1
        graph = nx.from_graph6_bytes(graph6.encode("ascii"))
        if Counter(dict(graph.degree()).values()) != Counter({3: n, 5: 1}):
            continue
        counts["degree_sequence_5_3xn"] += 1
        apex = next(v for v, degree in graph.degree() if degree == 5)
        proper = graph.copy()
        proper.remove_node(apex)
        if not nx.is_connected(proper):
            continue
        counts["connected_proper_5_poles"] += 1

        normalized = normalized_mapping(graph, apex, n)
        if normalized is None:
            continue
        counts["unlabelled_exact_C5_state_skeletons"] += 1
        mapping, pole = normalized
        matchings, singleton, relations = relation_data(pole)
        sizes = tuple(len(r) for r in relations)
        relation_size_vectors[str(sizes)] += 1
        if sizes != (2, 2, 2, 2, 2):
            continue
        counts["common_relation_size_2"] += 1
        types = tuple(endpoint_type(r) for r in relations)
        endpoint_type_vectors["".join(types)] += 1
        if types != ("D",) * 5:
            continue
        counts["endpoint_skeleton_DDDDD"] += 1

        pentagons = compatible_pentagon_count(relations)
        compatible_pentagon_distribution[str(pentagons)] += 1
        layered = layered_graph(relations)
        is_c10 = (
            layered.number_of_nodes() == 10
            and layered.number_of_edges() == 10
            and nx.is_connected(layered)
            and set(dict(layered.degree()).values()) == {2}
        )
        if not is_c10:
            counts["DDDDD_disconnected_double_cover"] += 1
            if pentagons != 2:
                raise AssertionError("trivial DDDDD double cover must have two lifted cycles")
            continue
        counts["connected_C10_double_cover"] += 1
        if pentagons != 0:
            raise AssertionError("connected C10 double cover cannot have a lifted 5-cycle")
        counterexample = certificate(
            graph6, mapping, pole, matchings, singleton, relations
        )
        proc.terminate()
        break

    returncode = proc.wait()
    if counterexample is None and returncode:
        raise RuntimeError(f"geng failed with exit status {returncode}")

    return {
        "internal_order": n,
        "coverage": (
            "all unlabelled simple connected augmented graphs with unique degree-5 "
            "apex, degree sequence (5,3^n), and connected apex deletion; one boundary "
            "representative modulo Aut(C5) for every exact-C5 Tait-state skeleton"
        ),
        "geng_command": command,
        "counts": dict(counts),
        "relation_size_vector_distribution_on_exact_C5_skeletons": dict(
            sorted(relation_size_vectors.items())
        ),
        "endpoint_type_distribution_at_common_size_2": dict(
            sorted(endpoint_type_vectors.items())
        ),
        "compatible_pentagon_distribution_on_DDDDD": dict(
            sorted(compatible_pentagon_distribution.items())
        ),
        "counterexample": counterexample,
        "target_realized": counterexample is not None,
        "complete_no_target_at_this_order": counterexample is None,
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--geng", default="geng")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    result = run(args.n, args.geng)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json:
        args.json.write_text(text + "\n", encoding="utf-8")
    return 1 if result["target_realized"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
