# Fixed-seed four-port (q)-filter audit

## Decision question

For the explicit order-13 all-(S)-(T), no-(A) pole, does one replaced
proper-edge pair (e,f) and either of the two certified real four-port
relations

\[
\Lambda_0=\{0\},\qquad \Lambda_2=\{2\}
\]

preserve all 40 Case-XII target classes (the five (S)-loops, ten (S\)-(S)
classes, and 25 (S\)-(T) classes) while filtering all 15 (T)-loop/
 (T\)-(T) classes?

For every unordered BF cover (C) and proper-edge pair, the computation uses

\[
q_C(e,f)=\#\{\text{matching slots of }C\text{ containing both }e,f\},
\]

and records (D_\tau(e,f)=\{q_C(e,f):C\text{ has type }\tau\}).  A row is a
success exactly when (D_\tau\cap\Lambda\neq\varnothing) for every target
type and (D_\tau\cap\Lambda=\varnothing) for every forbidden type.

## Omen certificate

The self-contained standard-library script
`audit_seed_q_filters.py` was copied byte-for-byte to omen (SHA256
`27e28731f858f042cde475db239d86661658fb866655735c84e53922d5d383c9`) and run
in bounded tmux session `qfilter_seed`.

The complete fixed-host enumeration returned:

* 37 perfect matchings and 795 unordered six-matching BF covers;
* all 55 pair-boundary classes are present, while the (A=(12345)) count is 0;
* all 136 unordered pairs of the 17 proper edges were tested.

For \(\Lambda_0=\{0\}\):

* 0/136 rows satisfy both preservation and filtering;
* 36/136 preserve all 40 target classes, but each of those 36 leaks all 15
  forbidden classes;
* 0/136 filters all 15 forbidden classes.

For \(\Lambda_2=\{2\}\):

* 0/136 rows satisfy both preservation and filtering;
* 0/136 preserve all 40 target classes;
* 32/136 filter all 15 forbidden classes, but those rows preserve 0 target
  classes.  The best target-preservation rows retain 35/40 and still leak
  10/15 forbidden classes.

The remote output terminates with
`NO_SINGLE_REAL_Q_FILTER_PRESERVES_40_AND_FILTERS_15`.

## Strict scope

This closes only the single-pair (q\)-filter route on this one real seed for
the two known relations \(\Lambda_0,\Lambda_2\).  It is not a no-go theorem
for other coupled gadgets, multiple replacements, other hosts, or the
existence of an exact-40 pole.
