# Four-port coupled replacements: the local \(q\)-filter boundary

## Question

Can a local gadget with at least four attachment ports preserve all
\(S\)-\(T\) support while deleting every \(T\)-loop and \(T\)-\(T\) type?
This note studies only one coupled four-port replacement, namely a gadget
that replaces two host edges.  It does not scan host graphs.

## Local symmetry theorem

Let \(J\) be a cubic four-pole with terminals
\(a,a',b,b'\), where \(a,a'\) are attached to the two ends of a host edge
\(e\), and \(b,b'\) to the two ends of a host edge \(f\).  In a
six-matching BF assignment, write \(F\subset[6]\) for the two colours
using \(e\), and \(G\subset[6]\) for the two colours using \(f\).  Thus the
four terminal labels of \(J\) are
\[
(F,F,G,G).
\]
Put \(q=|F\cap G|\in\{0,1,2\}\).

Define
\[
\Lambda(J)=\{q:\ J\text{ has a local BF assignment with terminal labels
}(F,F,G,G)\text{ and }|F\cap G|=q\}.
\tag{1}
\]
The action of \(S_6\) on colour names is transitive on ordered pairs
\((F,G)\) with a fixed intersection size \(q\).  Therefore \(\Lambda(J)\)
is the complete colour-symmetric boundary relation of \(J\): a particular
\((F,F,G,G)\) is admitted if and only if \(q\in\Lambda(J)\).

Consequently, replacing two host edges by \(J\) is necessarily a
\(q\)-filter.  For a host BF cover \(C\), let
\[
q_C(e,f)=
\bigl|\{c:\ c\text{ uses both }e\text{ and }f\}\bigr|.
\]
The cover extends across \(J\) exactly when
\(q_C(e,f)\in\Lambda(J)\).  No four-port gadget can distinguish the
actual colour names \(F,G\), or the \(S/T\) names of the cut boundary,
without an additional host-level correlation.

The parity equation at each colour class gives an independent check:
every colour occurs on an even number of the four terminal ports.  This is
automatic for \((F,F,G,G)\); the internal structure of \(J\) can only
restrict the three values of \(q\), not refine the \(S_6\)-orbit.

## Two smallest real examples

### The two-vertex four-pole: \(\Lambda=\{0\}\)

Take internal vertices \(u,v\), one proper edge \(uv\), and two terminals
at each vertex.  Attach the two ends of \(e\) to one terminal at \(u\)
and one at \(v\), and similarly for \(f\).  A local perfect matching is
either \(uv\) (using no terminals), or one terminal at \(u\) and one at
\(v\).  In a BF assignment \(uv\) is used twice, so the remaining four
colour classes choose one terminal on each side.  Requiring the two
terminals of \(e\) to have the same colour label and likewise for \(f\)
forces the four non-\(uv\) classes to split into the two disjoint labels
\(F,G\).  Hence \(F\cap G=\varnothing\), and
\[
\Lambda(J_0)=\{0\}.
\tag{2}
\]
This is a genuine simple connected cubic four-pole and the smallest
possible one.

### The four-cycle four-pole: a \(q=2\) filter

Take a square \(v_0v_1v_2v_3v_0\), with one terminal at each vertex.
Pair opposite terminals as the two ends of the host edges:
\(e=(v_0,v_2)\) and \(f=(v_1,v_3)\).  Enumerating the seven local perfect
matching patterns and the BF six-tuples gives
\[
\Lambda(J_\square)=\{2\}.
\tag{3}
\]
For an adjacent terminal pairing, the same square admits all three values,
\(\Lambda(J_\square)=\{0,1,2\}\), so that attachment choice is not a
filter.  These statements are direct finite local state calculations; no
host enumeration is involved.  The pure standard-library verifier is
verify_four_port_q_filters.py; it terminates with
FOUR_PORT_Q_FILTERS_VERIFIED.

Thus four-port coupling is not ruled out by symmetry alone: real gadgets
with nontrivial \(q\)-filters exist.  What symmetry does rule out is a
filter stated directly in terms of the Case-XII boundary labels.

## Exact host-level criterion

For a fixed host \(H\) and replaced edge pair \(e,f\), let
\[
D_\tau(e,f)=\{q_C(e,f): C\text{ is an actual BF cover of }H
\text{ having boundary type }\tau\}.
\tag{4}
\]
The four-port replacement with relation \(\Lambda(J)\) preserves every
\(S\)-\(T\) type and deletes every forbidden \(T\)-loop/\(T\)-\(T\) type
if and only if
\[
\begin{aligned}
& D_\tau(e,f)\cap\Lambda(J)\neq\varnothing
&&\text{for every }\tau\in S\text{-}T,\\
& D_\tau(e,f)\cap\Lambda(J)=\varnothing
&&\text{for every forbidden }T\text{-loop or }T\text{-}T\text{ type}.
\end{aligned}
\tag{5}
\]
This reduces the proposed construction to a three-valued host incidence
separation problem.  It is not decided by the local gadget relation.

In particular:

* \(\Lambda(J)=\{0,1,2\}\) preserves all BF support and filters nothing;
* \(\Lambda(J)=\varnothing\) destroys all BF support;
* \(\{0\}\) or \(\{2\}\) can filter only if the host \(q\)-sets in (4)
  separate all desired and forbidden types.

No real pole with the complete 40-type Case-XII support is known, so (5)
cannot currently be evaluated for the target.  The known all-\(S\)-\(T\)
real pole has extra \(T\)-loop/\(T\)-\(T\) support, and therefore is only a
boundary instance, not a target counterexample.

## Strict decision

There is no general local no-go for four-port coupling: the smallest real
four-pole already supplies a \(q=0\) filter, and a square supplies a
\(q=2\) filter.  Conversely, no gadget has been found that is certified
to preserve all 25 \(S\)-\(T\) types while deleting all \(T\)-loop/\(T\)-\(T\)
types.  The exact remaining interface is (5), a host-level \(q\)-separation
condition.  Resolving it requires one actual Case-XII host (or a theorem
about \(D_\tau(e,f)\)); further local gadget enumeration cannot decide the
Case-XII question.
