# Exact-\(S\) four-cell gate: the missing quantifier exchange

## Scope and verdict

This file attacks only the following implication for one **real** cubic
5-pole \(H\):

\[
\operatorname{Tait}(H)=S,\qquad
\mathcal C(H)=
\{\text{five \(S\)-loops, fifteen \(S\)-\(S\) cells,
twenty-five \(S\)-\(T\) cells}\},
\tag{0}
\]

with no \(A=(12345)\), no \(T\)-loop and no \(T\)-\(T\) cell:

\[
\bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}\ne\varnothing,\qquad
\mathcal C_4=\{(13,12),(13,45),(24,15),(25,34)\}.
\tag{1}
\]

No proof of (1) and no real pole satisfying (0) are currently known.  The
strict result is that the known hypotheses leave exactly a
\(\forall\exists\)-to-\(\exists\forall\) gap; the smallest additional axiom
that closes the four-cell route is the rectangular singleton-section axiom
(R) below.  This is a boundary result, not a Case-XII proof or
counterexample.

## The four-cell implication on a real pole

For \(s=ij\in S\), \(t=k\ell\in T\), let \(\Pi_{s,t}\) be the set of
five-tuples of **actual** singleton-boundary perfect matchings
\((P_1,\ldots,P_5)\) for which there are actual triple-boundary matchings
\(Q_s,Q_t\) with

\[
\chi_{Q_s}+\chi_{Q_t}
+\sum_{r\in s}\chi_{P_r}
+\sum_{r\in t}\chi_{P_r}
=2\mathbf 1.
\tag{2}
\]

When \(s\cap t\neq\varnothing\), (2) deliberately requires the same
\(P_r\) in both repeated singleton positions; this is exactly the
cross-cell reuse that ordinary support does not record.

The four endpoint unions in \(\mathcal C_4\) contain every
three-subset of \([5]\).  If a tuple lies in all four \(\Pi_{s,t}\), then
no edge can belong to three of the \(P_r\): choose a cell whose union
contains those three indices and use (2).  At each internal cubic vertex
the five singleton incidences have total load five, while every edge has
load at most two.  The three incident loads are therefore \(2,2,1\).
The load-one edges form a sixth perfect matching and all five semiedges
lie in it.  Hence the six matchings give an \(A\)-cover.

\[
\boxed{\text{(1) implies the forbidden }A\text{-type on the same real pole}.}
\tag{3}
\]

This is the already isolated local incidence implication; no independent
edge-load invariant is being claimed here.

## What exact Case XII support actually quantifies

The 25 positive \(S\)-\(T\) cells give only

\[
\forall(s,t)\in S\times T\quad
\exists\,(P^{s,t}_1,\ldots,P^{s,t}_5,Q^{s,t}_s,Q^{s,t}_t)
\quad\text{satisfying (2)}.
\tag{4}
\]

The desired four-cell gate is

\[
\exists\,(P_1,\ldots,P_5)\quad
\forall(s,t)\in\mathcal C_4\quad
\exists\,Q_s,Q_t\quad\text{satisfying (2)}.
\tag{5}
\]

The difference is not a choice of notation: the singleton fibres in (4)
are allowed to depend on the cell.  A loop \([s]\) in the exact-\(S\)
branch supplies one doubled Tait partition
\((P_i,P_j,Q_s)\), but a different \(S\)-loop may use unrelated singleton
matchings.  Exact-\(S\) gives the set of allowed lonely pairs, not a
section through these five singleton fibres.

The absence of \(T\)-loops and \(T\)-\(T\) cells is a negative condition on
which boundary types may occur.  It does not identify an internal singleton
matching used in one \(S\)-\(T\) witness with the singleton matching used in
another witness.  Thus it does not turn (4) into (5).

## Why whole-graph minimality does not perform the exchange

For a genuine Case-XII cut, \(R=C_5\), \(g(G)=5\), and cyclic
5-edge-connectivity imply that \(L\) is connected and bridge-free with
distinct terminals; possible proper 2-cuts only isolate the classified
terminal trees.  These structural facts do not identify two internal
perfect matchings in different witnesses.

Minimality can be invoked only after a BF-lifting replacement produces a
smaller cubic **bridgeless** whole graph.  It does not compare two
six-matching decompositions of the same \(L\).  No known length-\(\ge6\)
defect-cycle replacement is BF-lifting with the required cyclic
connectivity, so minimality supplies no missing section theorem.

The \(C_5\) side sees only the five cut-edge labels.  Its canonical
matchings do not see which member of \(\mathcal P_i\) was selected inside
\(L\).  Thus gluing to \(R\) also leaves the cell dependence in (4).

## Minimal missing axiom and exact boundary

The weakest direct hypothesis that closes the four-cell route is:

\[
\tag{R}
\exists(P_1,\ldots,P_5)\in
\bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}.
\]

Under (R), (3) contradicts the no-\(A\) part of (0).  Requiring a common
tuple for all 25 cells, or requiring fixed triple matchings as well, is
strictly stronger than necessary.

Conversely, none of the currently available consequences supplies (R):

* the five doubled \(S\)-loops give five separate sections, not one common
  singleton section;
* all 25 cellwise witnesses give (4), not (5);
* \(R=C_5\), girth five and minimality add no cross-cell witness identity.

Two real boundary poles isolate the missing information without deciding
(0): the order-13 exact-\(S\) C10 pole has four projection sizes
\((0,12,8,8)\), so its four-cell intersection is empty because one cell is
absent; the order-13 all-\(S\)-\(T\) all-SS pole has all four cells and
empty intersection, but its Tait state set is \(K_5\) and it has extra
\(T\)-loop/\(T\)-\(T\) types.  Neither is a counterexample to (0).

## Stopping decision

\[
\boxed{\text{The exact-\(S\) four-cell implication remains unresolved.}}
\]

The only next theorem that can change this decision without a new graph
census is a genuine cross-cell singleton-fibre theorem deriving (R) from
the common trivalent incidence of one pole.  A failure of (R) on an actual
pole satisfying (0) would be a real Case-XII pole-level boundary, while a
proof of (R) would exclude the exact-\(S\) branch.
