#!/usr/bin/env python3
"""Audit the two smallest real four-port q-filters on the all-ST/no-A seed.

This is a fixed-host incidence calculation.  It enumerates every perfect
matching and every unordered six-matching BF cover of the order-13 seed, then
records

    D_tau(e,f) = { q_C(e,f) : C has boundary type tau },

for all pairs of proper host edges.  The only local relations tested are the
two real four-poles already certified in ``verify_four_port_q_filters.py``:
Lambda={0} (the two-vertex four-pole) and Lambda={2} (the opposite square).

The target support is the 40 Case-XII classes (S-loops, S-S, and S-T); the
15 complementary T-loop/T-T classes are the forbidden support.  A candidate
pair/filter succeeds exactly when every target class has a compatible cover
and no forbidden class does.  The seed has no A cover, which is checked as
part of the complete enumeration.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, combinations_with_replacement
import json
from pathlib import Path


SEED_EDGES = (
    (0, 8), (0, 11), (1, 7), (1, 9), (2, 9), (2, 12),
    (3, 10), (3, 12), (4, 10), (4, 11), (5, 7), (5, 8),
    (5, 9), (6, 8), (6, 11), (6, 12), (7, 10),
)
N = 13
TERMINAL_VERTICES = tuple(range(5))
PROPER_COUNT = len(SEED_EDGES)

PAIRS = tuple(combinations(range(1, 6), 2))
S = frozenset(((1, 3), (1, 4), (2, 4), (2, 5), (3, 5)))
T = frozenset(set(PAIRS) - set(S))
PAIR_TYPES = tuple(combinations_with_replacement(PAIRS, 2))
TARGET_TYPES = frozenset(
    kind for kind in PAIR_TYPES if kind[0] in S or kind[1] in S
)
FORBIDDEN_TYPES = frozenset(set(PAIR_TYPES) - set(TARGET_TYPES))
assert len(TARGET_TYPES) == 40
assert len(FORBIDDEN_TYPES) == 15


def edge_name(index: int) -> str:
    u, v = SEED_EDGES[index]
    return f"e{index:02d}={u}-{v}"


def edge_objects():
    """Return endpoint tuples for 17 proper edges followed by 5 semiedges."""
    return tuple(SEED_EDGES) + tuple((v,) for v in TERMINAL_VERTICES)


def enumerate_perfect_matchings():
    objects = edge_objects()
    incident = {v: [] for v in range(N)}
    for edge, endpoints in enumerate(objects):
        for vertex in endpoints:
            incident[vertex].append(edge)

    result = []

    def search(uncovered: frozenset[int], selected: tuple[int, ...]):
        if not uncovered:
            result.append(tuple(sorted(selected)))
            return
        vertex = min(uncovered)
        for edge in incident[vertex]:
            endpoints = objects[edge]
            if all(endpoint in uncovered for endpoint in endpoints):
                search(
                    frozenset(uncovered.difference(endpoints)),
                    selected + (edge,),
                )

    search(frozenset(range(N)), tuple())
    return tuple(sorted(set(result)))


def boundary_of(matching):
    return frozenset(edge - PROPER_COUNT + 1 for edge in matching if edge >= PROPER_COUNT)


def classify_cover(cover, matching_boundaries):
    lengths = sorted(len(matching_boundaries[index]) for index in cover)
    if lengths == [1, 1, 1, 1, 1, 5]:
        return ("A",)
    if lengths != [1, 1, 1, 1, 3, 3]:
        raise AssertionError((cover, lengths))
    missing = []
    for index in cover:
        boundary = matching_boundaries[index]
        if len(boundary) == 3:
            missing.append(tuple(sorted(set(range(1, 6)) - set(boundary))))
    assert len(missing) == 2
    return tuple(sorted(missing))


def enumerate_bf_covers(matchings):
    """Yield (cover, boundary type, q-values for all proper edge pairs)."""
    edge_count = PROPER_COUNT + len(TERMINAL_VERTICES)
    edge_sets = tuple(frozenset(matching) for matching in matchings)
    boundaries = tuple(boundary_of(matching) for matching in matchings)
    pair_indices = tuple(combinations(range(PROPER_COUNT), 2))
    pair_by_edge = {pair: index for index, pair in enumerate(pair_indices)}
    counts = [0] * edge_count
    selected = []

    def search(start):
        remaining = 6 - len(selected)
        if any(value > 2 or value + remaining < 2 for value in counts):
            return
        if remaining == 0:
            if counts != [2] * edge_count:
                return
            cover = tuple(selected)
            kind = classify_cover(cover, boundaries)
            q_values = [0] * len(pair_indices)
            for matching_index in cover:
                used = edge_sets[matching_index]
                for first, second in combinations(sorted(used & set(range(PROPER_COUNT))), 2):
                    q_values[pair_by_edge[(first, second)]] += 1
            yield cover, kind, tuple(q_values)
            return
        for matching_index in range(start, len(matchings)):
            used = edge_sets[matching_index]
            if any(counts[edge] >= 2 for edge in used):
                continue
            for edge in used:
                counts[edge] += 1
            selected.append(matching_index)
            yield from search(matching_index)
            selected.pop()
            for edge in used:
                counts[edge] -= 1

    yield from search(0)


def support_name(kind):
    if kind == ("A",):
        return "A=(12345)"
    first, second = kind
    if first == second:
        return f"[{first[0]}{first[1]}]"
    return f"({first[0]}{first[1]})({second[0]}{second[1]})"


def main():
    assert len(set(SEED_EDGES)) == PROPER_COUNT
    matchings = enumerate_perfect_matchings()
    boundaries = tuple(boundary_of(matching) for matching in matchings)
    pair_indices = tuple(combinations(range(PROPER_COUNT), 2))
    d_values = {
        kind: [0] * len(pair_indices)
        for kind in PAIR_TYPES
    }
    a_values = [0] * len(pair_indices)
    cover_counts = Counter()
    total_covers = 0

    for cover, kind, q_values in enumerate_bf_covers(matchings):
        total_covers += 1
        cover_counts[kind] += 1
        target = a_values if kind == ("A",) else d_values[kind]
        for index, q in enumerate(q_values):
            target[index] |= 1 << q

    assert total_covers == sum(cover_counts.values())
    assert cover_counts[("A",)] == 0
    assert set(kind for kind, count in cover_counts.items() if count) == set(PAIR_TYPES)

    filters = {
        "lambda_0_two_vertex": 0,
        "lambda_2_square_opposite": 2,
    }
    records = []
    for filter_name, value in filters.items():
        bit = 1 << value
        for pair_index, (first, second) in enumerate(pair_indices):
            target_kept = sum(
                bool(d_values[kind][pair_index] & bit)
                for kind in TARGET_TYPES
            )
            forbidden_leak = sum(
                bool(d_values[kind][pair_index] & bit)
                for kind in FORBIDDEN_TYPES
            )
            records.append({
                "filter": filter_name,
                "lambda": [value],
                "edge_indices": [first, second],
                "edges": [list(SEED_EDGES[first]), list(SEED_EDGES[second])],
                "adjacent": bool(set(SEED_EDGES[first]) & set(SEED_EDGES[second])),
                "target_kept": target_kept,
                "target_total": len(TARGET_TYPES),
                "forbidden_leak": forbidden_leak,
                "forbidden_total": len(FORBIDDEN_TYPES),
                "target_all_preserved": target_kept == len(TARGET_TYPES),
                "forbidden_all_filtered": forbidden_leak == 0,
                "success": target_kept == len(TARGET_TYPES) and forbidden_leak == 0,
            })

    summary = {}
    for filter_name in filters:
        rows = [row for row in records if row["filter"] == filter_name]
        rows.sort(key=lambda row: (-row["target_kept"], row["forbidden_leak"], row["edge_indices"]))
        summary[filter_name] = {
            "success_count": sum(row["success"] for row in rows),
            "target_preserving_count": sum(row["target_all_preserved"] for row in rows),
            "fully_filtering_count": sum(row["forbidden_all_filtered"] for row in rows),
            "best_rows": rows[:10],
            "disjoint_best_rows": [row for row in rows if not row["adjacent"]][:10],
            "target_kept_histogram": dict(sorted(Counter(row["target_kept"] for row in rows).items())),
            "forbidden_leak_histogram": dict(sorted(Counter(row["forbidden_leak"] for row in rows).items())),
        }

    output = {
        "seed_order": N,
        "seed_proper_edges": [list(edge) for edge in SEED_EDGES],
        "perfect_matchings": len(matchings),
        "bf_cover_multisets": total_covers,
        "support_type_count": len(PAIR_TYPES),
        "target_type_count": len(TARGET_TYPES),
        "forbidden_type_count": len(FORBIDDEN_TYPES),
        "A_cover_count": cover_counts[("A",)],
        "cover_counts": {
            support_name(kind): count for kind, count in sorted(cover_counts.items(), key=lambda item: support_name(item[0]))
        },
        "filters": summary,
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    if any(summary[name]["success_count"] for name in filters):
        print("REAL_SEED_Q_FILTER_SUCCESS")
    else:
        print("NO_SINGLE_REAL_Q_FILTER_PRESERVES_40_AND_FILTERS_15")


if __name__ == "__main__":
    main()
