#!/usr/bin/env python3
"""Pure-stdlib local verifier for the four-port q-filter examples.

The objects are fixed two- and four-poles; this is not a host-graph scan.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations_with_replacement


def canon(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def local_matchings(
    vertices: tuple[int, ...],
    proper_edges: frozenset[tuple[int, int]],
    terminal_vertices: tuple[int, ...],
) -> tuple[tuple[frozenset[tuple[int, int]], frozenset[int]], ...]:
    adjacency = {v: set() for v in vertices}
    for u, v in proper_edges:
        adjacency[u].add(v)
        adjacency[v].add(u)
    terminals = {v: [] for v in vertices}
    for terminal, vertex in enumerate(terminal_vertices):
        terminals[vertex].append(terminal)
    out = []

    def search(unmatched, selected, used_terminals):
        if not unmatched:
            out.append((frozenset(selected), frozenset(used_terminals)))
            return
        v = min(unmatched)
        for w in sorted(adjacency[v] & unmatched):
            search(unmatched - {v, w}, selected + [canon(v, w)],
                   used_terminals)
        for terminal in terminals[v]:
            search(unmatched - {v}, selected,
                   used_terminals + [terminal])

    search(set(vertices), [], [])
    return tuple(out)


def q_relation(
    vertices: tuple[int, ...],
    proper_edges: frozenset[tuple[int, int]],
    terminal_vertices: tuple[int, ...],
    host_pairing: tuple[tuple[int, int], tuple[int, int]],
) -> tuple[int, ...]:
    matchings = local_matchings(vertices, proper_edges, terminal_vertices)
    items = list(proper_edges) + [
        ("terminal", terminal) for terminal in range(len(terminal_vertices))
    ]
    allowed = set()
    for cover in combinations_with_replacement(range(len(matchings)), 6):
        load = Counter()
        for matching_index in cover:
            proper, used = matchings[matching_index]
            for edge in proper:
                load[edge] += 1
            for terminal in used:
                load[("terminal", terminal)] += 1
        if any(load[item] != 2 for item in items):
            continue
        labels = [
            frozenset(
                slot for slot, matching_index in enumerate(cover)
                if terminal in matchings[matching_index][1]
            )
            for terminal in range(len(terminal_vertices))
        ]
        if any(labels[u] != labels[v] for u, v in host_pairing):
            continue
        first, second = host_pairing
        allowed.add(len(labels[first[0]] & labels[second[0]]))
    return tuple(sorted(allowed))


def main() -> None:
    two_vertices = (0, 1)
    two_edges = frozenset({(0, 1)})
    two_terminals = (0, 0, 1, 1)
    two_q = q_relation(
        two_vertices, two_edges, two_terminals,
        ((0, 2), (1, 3)),
    )
    assert two_q == (0,), two_q

    square_vertices = (0, 1, 2, 3)
    square_edges = frozenset({(0, 1), (1, 2), (2, 3), (0, 3)})
    square_terminals = (0, 1, 2, 3)
    opposite_q = q_relation(
        square_vertices, square_edges, square_terminals,
        ((0, 2), (1, 3)),
    )
    adjacent_q = q_relation(
        square_vertices, square_edges, square_terminals,
        ((0, 1), (2, 3)),
    )
    assert opposite_q == (2,), opposite_q
    assert adjacent_q == (0, 1, 2), adjacent_q

    print("two_vertex_four_pole_lambda=", two_q)
    print("square_opposite_lambda=", opposite_q)
    print("square_adjacent_lambda=", adjacent_q)
    print("FOUR_PORT_Q_FILTERS_VERIFIED")


if __name__ == "__main__":
    main()
