# The whole-graph Case-XII interface: Tait-empty versus exact-$S$

## Decision

For a genuine cyclically 5-edge-connected minimum Berge--Fulkerson
counterexample, the known (R=C_5), girth-five, and minimality information
does **not** produce a new contradiction in either branch of the Case-XII
side (L).  It does, however, leave one precise common-incidence gate in
the 3-edge-colourable branch and one strictly weaker defect-cycle gate in
the Tait-empty branch.

The two branches must not be merged:

\[
\operatorname{Tait}(L)=\varnothing,
\qquad\text{or}\qquad
\operatorname{Tait}(L)=S=\{13,14,24,25,35\}.
\tag{0}
\]

The second alternative follows from the published Case-XII Kempe
transition statement: if one lonely-pair state occurs, the two pentagon
neighbours occur, and iteration gives all five (S)-states; (T)-states
are excluded because their doubled loop type is absent.  The first
alternative is not ruled out by that statement.

## Whole-graph input and what it really gives

Let (G) be a minimum-order cyclically 5-edge-connected cubic
counterexample, let the cycle-separating cut have five edges, and write
(R=C_5) for one side and (L) for the other side, viewed as a cubic
5-pole.  The published Case-XII data give:

* (L) is connected, non-acyclic and bridge-free, with five distinct
  terminals;
* every proper 2-edge-cut of (L), if present, cuts off only the one- or
  two-vertex terminal trees classified in the minimality analysis;
* (g(G)=5), so (L) has no proper cycle of length three or four;
* the (C_5)-side has the standard 16 boundary types, while the Case-XII
  side is required to avoid the complementary forbidden types, including
  \(A=(12345)\), all \(T\)-loops and all \(T\)-\(T\) types.

The last item is a statement about boundary labels of six matching
incidences.  Gluing to (R) sees these labels on the five cut edges; it
does not identify which internal perfect matching of (L) was used in two
different six-matching witnesses.

## Exact-(S) branch: the four-cell gate survives, but is not forced

For $s\in S,t\in T$, let $\Pi_{s,t}$ be the set of five-tuples
$(P_1,\ldots,P_5)$ of actual singleton-boundary perfect matchings of
$L$ for which some $Q_s$ and $Q_t$ satisfy

\[
\chi_{Q_s}+\chi_{Q_t}
 +\sum_{i\in s}\chi_{P_i}
 +\sum_{i\in t}\chi_{P_i}=2\mathbf 1.
\tag{1}
\]

For

\[
\mathcal C_4=
\{(13,12),(13,45),(24,15),(25,34)\},
\tag{2}
\]

the endpoint unions (s\cup t) contain every three-subset of
([5]).  Therefore

\[
\bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}\ne\varnothing
\quad\Longrightarrow\quad
A=(12345).
\tag{3}
\]

The proof is local and exact.  A common tuple in (3) has singleton load at
most two on every edge: if three singleton matchings used an edge, one of
the four endpoint unions would contain their three indices and violate
(1).  At a cubic vertex the five singleton loads sum to five, so the
three incident loads are (2,2,1).  The load-one edges form a sixth
perfect matching, giving (A).

This gate applies to both branches whenever the intersection is defined,
but the whole-graph hypotheses do not imply the intersection.  In the
exact-(S) branch the five loop types can be represented by doubled Tait
colourings, yet the five resulting singleton choices need not be a common
pentagon section.  Distinct \(S\)-\(T\) cells may use distinct singleton
tuples, and the (C_5) side supplies no mechanism that identifies them.
Minimality of (G) also compares smaller graphs, not witness choices
inside one fixed (L); it therefore gives no Hall-type rectangular
section theorem.

Thus the remaining exact-(S) implication is precisely

\[
\text{Case-XII support on one real }L\text{ and no }A
\ \Longrightarrow\ 
\bigcap_{\mathcal C_4}\Pi_{s,t}=\varnothing,
\tag{4}
\]

or an alternative theorem using the same common cubic incidence.  Neither
(R=C_5), girth five, nor minimality proves (4).

## A consequence valid in both branches: carrierless (T)-half cycles

Take any actual \(S\)-\(T\) witness in \(L\), and split its six matchings
into the (S)-half and (T)-half.  If (x) is the incidence sum of either
half, then at every internal cubic vertex the three incident loads sum to
three, and every terminal semiedge has load one.  Hence the defect set

\[
D(x)=\{e:x(e)\ne1\}
\]

is a disjoint union of proper even alternating cycles with loads
(0,2,0,2,\ldots).  A component whose load-two edges have a common
matching carrier can be removed by flipping that matching on the cycle;
the result is a Tait colouring with the same boundary half.

In Case XII a (T)-loop is forbidden.  Consequently every actual
\(S\)-\(T\) witness has at least one **carrierless** component in its
(T)-half.  On such a component all three matching-pair labels
(12,13,23) occur among the load-two edges, so its length is at least six.
Because (g(G)=5), this is the only immediate metric conclusion: lengths
three and four are absent, but an even cycle of length six or more is fully
compatible with the known whole-graph structure.

This statement remains meaningful when $\operatorname{Tait}(L)=\varnothing$,
where no loop can be split into three colour classes.  It is therefore the
strongest common local consequence currently available to the Tait-empty
branch, but it does not couple the 25 cells or force an (A)-cover.

## Why (R=C_5) and minimality do not close the Tait-empty branch

The (C_5) side has canonical local matchings for its admissible boundary
patterns, but the gluing equations only require complementary boundary
labels across the cut.  A non-3-edge-colourable (L) can still have
singleton and triple-boundary perfect matchings and can participate in
\(S\)-\(T\) six-matching witnesses.  The absence of a Tait colouring says
only that no three disjoint singleton/triple matchings partition (L); it
does not make any of the 25 six-matching fibres empty.

Likewise, replacing a proper subgraph of (L) by a smaller gadget would be
useful only if every BF colouring of the resulting whole graph lifted back
and the resulting graph stayed cubic and bridgeless (and, for the published
Case-XII setting, retained the required cyclic connectivity).  The known
BF-lifting local reductions either are already excluded by (g(G)=5), or
require exactly these extra bridgelessness and boundary checks.  Minimality
therefore supplies no deletion theorem for an arbitrary Tait-empty side.

## Strict stopping boundary

The current whole-graph information proves the following and no more:

\[
\boxed{
\begin{array}{l}
\text{Tait-empty branch: every }S\text{-}T\text{ witness has a carrierless}\
\text{proper even defect cycle of length at least six;}\\[2mm]
\text{exact-}S\text{ branch: a common tuple on the four cells in (2)}\\
\text{would force }A,\text{ but no hypothesis supplies that tuple.}
\end{array}}
\]

Hence there is no new proof, real counterexample, or stronger reduction
from the (R=C_5)/girth-five/minimality package alone.  The next thinnest
testable theorem is one of:

1. a **cross-cell singleton-fibre theorem** proving (4) (or directly
   producing (A)) for a real exact-(S) pole;
2. a **non-Tait Case-XII exclusion theorem** using common cubic vertex
   incidence of all 25 witnesses, not merely their boundary types; or
3. a real cyclically-5-edge-connected construction with
   $\operatorname{Tait}(L)=\varnothing$ and the Case-XII support, which
   would settle the Tait-empty branch by counterexample.

No new census or abstract quotient is needed to distinguish these outcomes.

## Evidence boundary

The four-cell implication is recorded in permanent Note 043.  The
carrierless-cycle statement and its exact obstruction are proved in
`scratch/worker-loop-section-equation/loop-st-half-load-carrier-reduction.md`.
The inherited bridge, terminal, 2-cut and girth facts are in Note 019.
This file intentionally makes no claim that the Case-XII 40-type support
is realised by any actual pole.
