# 七顶点 shared-seed 障碍与 singleton 判据的独立检查

2026-09-26。本轮唯一有限观测是 [Pro 提案](pro-seed-obstruction-20260926.txt)
中的一个指定七顶点五极；没有图阶搜索。没有发现其七点构造、singleton-quartet
判据、pair-load 等价或 closed-factor 二和论证中的具体数学错误。
经核准的结论是：**完整 PM closure、无 all-terminal cover 和两个指定正 cells
仍不能强制 shared seed。这个结论的假设严格弱于 exact Case XII。**

定义依据：[Note 078](../notes/078-residual-degree-two-criterion-for-two-triple-completion.md)
的残差 copy-multigraph、[Note 101](../notes/101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md)
的字面行，以及 [Note 100 的开头](../notes/100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md)
的 exact-support 定义。有限计数从图的 edge objects 重新计算，不以旧记录的计数为证据。
本检查没有重跑 Note 100 的阶数穷尽，也不据此作本轮判断。

## 1. 精确命题与证明

令 \(G\) 是无自环三价五极，五条 semiedges 位于不同顶点。
\(\mathcal P_i\) 是所有边界恰为 \(\{i\}\) 的实际 PM；
\(\mathcal Q_{ij}\) 是所有边界恰为 \([5]\setminus\{i,j\}\) 的实际 PM。
向量包括每个 proper edge object 和每条 semiedge。固定
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
同名字表示同一完整匹配；\(X,Y\) 可以相等或不同；不要求
\(q'_{25}\) 等于后来饱和列里的 \(q_{25}\)。

seed 是同一 \(B\in\mathcal P_2,C\in\mathcal P_4\) 下的两行
\[
A+B+X+C+q_{14}+r_{23}=2\mathbf1,\qquad
B+Y+C+D+q'_{25}+r_{34}=2\mathbf1,
\]
其中 \(A\in\mathcal P_1,\ X,Y\in\mathcal P_3,\ D\in\mathcal P_5\)，
下标为 \(ij\) 的 triple matching 属于 \(\mathcal Q_{ij}\)。

对整数 degree-two 负载 \(R\)，记 \(\operatorname{Even}(R)\) 表示：
逐 edge object 非负，且其 copy-multigraph 的每个闭分量都是偶环。
同一 proper edge 的两份副本是孤立二环；同一 semiedge 的两份副本是在一个顶点相接的路径。

**命题。** 假设完整 BF 支撑没有 all-terminal 类型，也没有任何 \(TT\) 类型
（这里含 \(T\)-loops）。则 seed 存在当且仅当存在上述 singleton matchings，
使
\[
\operatorname{Even}(2\mathbf1-A-B-X-C),\qquad
\operatorname{Even}(2\mathbf1-B-Y-C-D)
\]
同时成立。这是全阶解析命题，有限检查不是它的证明。

必要性来自每个残差是两个 PM 之和。证明充分性，先固定左侧 quartet，
令 \(R=2\mathbf1-A-B-X-C\)。每个顶点残差度数为二；semiedges
\(1,2,3,4\) 的负载为一，\(5\) 的负载为二。双份 \(s_5\)
占满其顶点的残差度数，因此该分量的两色各含一份 \(s_5\)。
其余 terminal ends 构成两条路径，其他分量是闭偶环。

对所有分量交替二染，得到两个实际 PM。重复的原边两份一定异色，
故投回原图后的每个 PM 仍是 \(0/1\) mask。由
\[
3|V|=2|E_{\rm pr}|+5,\qquad
|V|=2|M_{\rm pr}|+|\partial M|,
\]
每个 PM 的边界大小为奇数。如果两条剩余路径一条两端同色、一条两端异色，
两色的边界大小都会为偶数，矛盾。如果两条均两端同色，可独立选相使四个
terminal ends 同色；连同 \(s_5\) 得到 all-terminal PM，另一色是 class 5 PM。
它们与原 quartet 合起来是禁止的 all-terminal BF cover。
因此两条路径均两端异色。

端点 \(\{1,2,3,4\}\) 的三个配对是
\[
12|34,\qquad13|24,\qquad14|23.
\]
若路径配对为其中之一，交替二染的两种无序 triple 边界分解恰是另两个配对。
其中唯一的 \(TT\) 配对是 \(12|34\)。无 \(TT\) 支撑迫使路径本身配成
\(12|34\)，否则二染会给出实际禁止 BF 行。因此可以令一色的边界为
\(235\)，另一色为 \(145\)，即 \(R=q_{14}+r_{23}\)。

右侧残差有双份 \(s_1\)，其余端点为 \(2,3,4,5\)。
唯一 \(TT\) 配对为 \(23|45\)，同理强制这一条路径配对，并允许颜色边界
\(134\) 与 \(125\)，即 \(R'=q'_{25}+r_{34}\)。固定的六个 singleton
matchings 全部保持，充分性成立。

这一步使用的是“无 all-terminal **BF cover**”，无需假定一般图没有
all-terminal PM。构造出的 PM 必须计入完整 graph-induced family；
对任意选定 PM 子集，以上充分性不成立。

定义
\[
\begin{aligned}
\Lambda_L&=\{B+C:\exists A\in\mathcal P_1,\ X\in\mathcal P_3,\
 \operatorname{Even}(2\mathbf1-A-X-B-C)\},\\
\Lambda_R&=\{B+C:\exists Y\in\mathcal P_3,\ D\in\mathcal P_5,\
 \operatorname{Even}(2\mathbf1-Y-D-B-C)\},
\end{aligned}
\]
其中 \(B\in\mathcal P_2,C\in\mathcal P_4\) 都为实际完整 masks。
在上述负支撑假设下，seed 等价于 \(\Lambda_L\cap\Lambda_R\ne\varnothing\)。
若左右可行对不同但完整向量 \(B_L+C_L=B_R+C_R\)，把右行的两项换成
左行的实际 \(B_L,C_L\)，残差及 BF 方程不变。这一替换直接证明 literal
row 的 pair-load 等价；对 literal row relations 本身不需要任何负支撑假设。

两个正 cells 只分别证明两集合非空。尚缺的断言仍是
\[
\text{完整 exact-Case-XII 支撑}\ \Longrightarrow\
\Lambda_L\cap\Lambda_R\ne\varnothing.
\]
上述判据消去了 quartet 可行之后的额外 triple terminal-pairing 测试，
没有证明这个跨行交集非空。

## 2. 一个指定图的决定性观测

proper graph 是三条内部不交的路径
\[
u-a-v,\qquad u-b-c-v,\qquad u-d-e-v,
\]
依次取
\(e_0=ua,e_1=av,e_2=ub,e_3=bc,e_4=cv,e_5=ud,e_6=de,e_7=ev\)。
\(s_1,\ldots,s_5\) 分别接在 \(b,d,c,a,e\)。
三个环长度为 \(5,5,6\)，每条 proper edge 在环上，故图简单、连通、
proper-bridgeless、girth five。

下面的独立 edge-subset 检查证实 Pro 的完整十四行 PM 表（名称与完整表
均在命令中给出）。特别地，
\[
\mathcal P_1=\{M_0\},\quad \mathcal P_2=\{M_1\},\quad
\mathcal P_3=\{M_4\},\quad \mathcal P_4=\{M_2,M_3\},\quad
\mathcal P_5=\{M_8\}.
\]
两条正确的全坐标 BF 行是
\[
M_0+M_1+M_4+M_3+M_{13}+M_{10}=2\mathbf1,\qquad
M_1+M_4+M_2+M_8+M_6+M_9=2\mathbf1.
\]
它们分别给出 \((14)(23)\) 与 \((25)(34)\)。

左行若改取 \(C=M_2\)，其 quartet 在 \(e_6=de\) 的负载为三，
来自 \(M_0,M_4,M_2\)；右行若改取 \(C=M_3\)，其 quartet 在 \(e_3=bc\)
的负载为三，来自 \(M_1,M_3,M_8\)。任何非负补全都不能修复。
由于 singleton classes 已完整，所有实际左、右行的 \((B,C)\) relations 恰为
\[
\mathcal L_{BC}=\{(M_1,M_3)\},\qquad
\mathcal R_{BC}=\{(M_1,M_2)\}.
\]
两 pair loads 在 \(e_3\) 分别为二和一，故也不相等。
已给出的成功行使各自残差为两 PM 之和，另一个候选又被负坐标排除，
所以这个图的 singleton-Even relations 也恰是这两个单点集。
这里直接检查了两候选，没有把第 1 节有负支撑前提的定理套用于此图。

选全部 semiedges 会留下 \(u,v\) 无法匹配，因此没有 all-terminal PM 或 cover。
但
\[
M_1+M_4+M_{10}=\mathbf1
\]
给出一个 Tait colouring，双份就是禁止的 \(T\)-loop \([23]\)。
另有真正非对角的 \(TT\) 行
\[
M_1+M_4+M_2+M_8+M_{10}+M_5=2\mathbf1
\quad\text{of type }(23)(45).
\]

完整 BF 支撑比较如下（SS、TT 各自含其 loops）：

| 类型 | 此七顶点图 | exact Case XII 所要求 |
|---|---:|---:|
| SS | 6 | 15 |
| ST | 10 | 25 |
| TT | 10 | 0 |
| all-terminal | 0 | 0 |

此例既有禁止类型，也缺少要求的正类型。完整 PM family 不等于完整
Case-XII 正支撑。它不能经由
[Note 055](../notes/055-half-load-column-saturation-and-case-xii-compression.md)
的负支撑饱和论证升级成冻结的六行资格，更不是
[SPEC](../SPEC-2026-09-23-case-xii-rectangle.md) 的反例。

## 3. 二和命题的量词核对

Pro 的 existential seed 透明性也成立。设 closed loopless cubic factor
\(F\) 有一个六 occurrence BF cover，沿 \(uv\in G,ab\in F\) 作二和。
\(|V(F)|\) 为偶数，任一 upstairs PM 穿过二边割的边数为零或二，
于是可限制回两个因子的实际 PM，BF 行与共享 \(B,C\) 都能限制。

反向给定 downstairs 的两条共享 \(B,C\) 行，置
\(b=\chi_B(uv),c=\chi_C(uv)\)。固定 \(F\) 的任一 BF cover；其六个
occurrence positions 中恰两个含 \(ab\)，四个不含。
为 \(B,C\) 选两个不同 positions，含边指标分别为 \(b,c\)，并在两行
用同一选择；总能选出。剩余四个 positions 含边数为 \(2-b-c\)，
与每条 host 行剩余四项的含边数一致，故可逐行独立配给。
这给出两条 upstairs BF 行并保持 literal \(B,C\)。
普通单行的同一配给证明完整 BF support 不变。

因此二和同时保持“某个 seed 存在”和 BF support；它可扩大该不完整支撑例，
无法把它变成 exact Case XII。这与
[2026-09-25 条件构造](codex-case-xii-next-2026-09-25.md)
破坏某个指定六行赋值的四残差是不同量词；本轮不重做该构造。

## 4. 可直接运行的独立命令与实际结果

从本单元目录运行下面的命令。不导入项目检查器、不写文件、不安装依赖。
只流式检查固定图的 \(2^{13}=8192\) 个 edge subsets 和
\(\binom{19}{6}=27132\) 个六 occurrence 多重集；保留十四个 PM 和二十六个 BF 行。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
from collections import Counter
from itertools import combinations_with_replacement
from math import comb

# One fixed graph only. Edges 0..7 are proper; 8..12 are s1..s5.
edges = [
    ("u","a"), ("a","v"), ("u","b"), ("b","c"),
    ("c","v"), ("u","d"), ("d","e"), ("e","v"),
    ("b",), ("d",), ("c",), ("a",), ("e",),
]
vertices = "uvabcde"
incidence = [sum(1 << e for e, ends in enumerate(edges) if v in ends)
             for v in vertices]
assert all(star.bit_count() == 3 for star in incidence)
actual = {m for m in range(1 << len(edges))
          if all((m & star).bit_count() == 1 for star in incidence)}

# Names from the proposal, compared against the independently generated family.
table = [
    ((0,4,6), "1"), ((0,3,7), "2"), ((2,4,6), "4"),
    ((3,5,7), "4"), ((1,2,6), "3"), ((0,7), "123"),
    ((5,7), "134"), ((2,7), "234"), ((1,3,5), "5"),
    ((0,4), "125"), ((4,5), "145"), ((2,4), "245"),
    ((1,5), "135"), ((1,2), "235"),
]
masks = [sum(1 << e for e in proper) |
         sum(1 << (7 + int(s)) for s in boundary)
         for proper, boundary in table]
assert len(set(masks)) == 14 and set(masks) == actual
vectors = [tuple((m >> e) & 1 for e in range(13)) for m in masks]
boundary = [frozenset(i for i in range(1,6) if m & (1 << (7+i)))
            for m in masks]
def load(row):
    return tuple(sum(vectors[i][e] for i in row) for e in range(13))
classes = {i: [j for j,b in enumerate(boundary) if b == {i}]
           for i in range(1,6)}
assert classes == {1:[0], 2:[1], 3:[4], 4:[2,3], 5:[8]}
print("PM=14; complete 13-edge subset check=8192; proposal table=PASS")
print("singleton classes:", classes)

S = {(1,3),(1,4),(2,4),(2,5),(3,5)}
terminals = frozenset(range(1,6))
def cell(row):
    assert sorted(len(boundary[i]) for i in row) == [1,1,1,1,3,3]
    return tuple(sorted(tuple(sorted(terminals-boundary[i]))
                        for i in row if len(boundary[i]) == 3))
bf_rows = [row for row in combinations_with_replacement(range(14),6)
           if load(row) == (2,)*13]
support = {cell(row) for row in bf_rows}
counts = Counter("SS" if s in S and t in S else
                 "TT" if s not in S and t not in S else "ST"
                 for s,t in support)
assert len(bf_rows) == 26 and len(support) == 26
assert counts == {"SS":6, "ST":10, "TT":10}
assert not any(len(b) == 5 for b in boundary)
print("six-occurrence multisets=%d; BF rows=%d; support SS=%d ST=%d TT=%d; all-terminal PM=0"
      % (comb(19,6), len(bf_rows), counts["SS"], counts["ST"], counts["TT"]))

left = (0,1,4,3,13,10)
right = (1,4,2,8,6,9)
assert load(left) == load(right) == (2,)*13
assert cell(left) == ((1,4),(2,3))
assert cell(right) == ((2,5),(3,4))
def relation(target):
    return {(next(i for i in row if boundary[i] == {2}),
             next(i for i in row if boundary[i] == {4}))
            for row in bf_rows if cell(row) == target}
left_pairs = relation(cell(left))
right_pairs = relation(cell(right))
assert left_pairs == {(1,3)} and right_pairs == {(1,2)}
print("left/right displayed full-mask BF rows=PASS")
print("complete row relations: L=%s R=%s; intersection=%s"
      % (sorted(left_pairs), sorted(right_pairs), sorted(left_pairs & right_pairs)))

for side, fixed, bad_C, edge in [
    ("left", (0,1,4), 2, 6), ("right", (1,4,8), 3, 3)
]:
    quartet = load(fixed + (bad_C,))
    assert [e for e,x in enumerate(quartet) if x > 2] == [edge]
    assert quartet[edge] == 3
    print("%s C=M%d: e%d load=3, residual=-1" % (side,bad_C,edge))
assert load((1,3)) != load((1,2))
assert load((1,4,10)) == (1,)*13
tt_row = (1,4,2,8,10,5)
assert load(tt_row) == (2,)*13 and cell(tt_row) == ((2,3),(4,5))
print("forbidden witnesses: [23] from 2*(M1+M4+M10); ((23)(45)) from M1+M4+M2+M8+M10+M5")
print("all assertions PASS; no graph-order enumeration")
PY
```

实际运行退出码为 0，输出：

```text
PM=14; complete 13-edge subset check=8192; proposal table=PASS
singleton classes: {1: [0], 2: [1], 3: [4], 4: [2, 3], 5: [8]}
six-occurrence multisets=27132; BF rows=26; support SS=6 ST=10 TT=10; all-terminal PM=0
left/right displayed full-mask BF rows=PASS
complete row relations: L=[(1, 3)] R=[(1, 2)]; intersection=[]
left C=M2: e6 load=3, residual=-1
right C=M3: e3 load=3, residual=-1
forbidden witnesses: [23] from 2*(M1+M4+M10); ((23)(45)) from M1+M4+M2+M8+M10+M5
all assertions PASS; no graph-order enumeration
```

已取得本轮决定性观测，到此停止。没有得到 exact-Case-XII 的 shared-seed 证明或反例。
