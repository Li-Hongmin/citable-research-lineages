#!/usr/bin/env python3
"""Bounded Omen pulse for the five D5 seed cells only.

This is deliberately a relaxation of the full Case-XII common-pool model.
It keeps one common family of K perfect-matching slots for all singleton and
triple boundary classes, the five S-loop cells, the five disjoint S--T seed
cells, finite-pool absence of A=(12345), and all five four-of-five D5 joins
empty.  The other 30 positive cells and all unwanted-support blockers are
omitted.  Therefore UNSAT is a useful bounded obstruction, while SAT is only
an unresolved relaxation witness.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import product
from pathlib import Path

from z3 import And, Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
REAL = HERE.parent / "worker-bf-real-synthesis"
BASE_PATH = REAL / "synthesize_exact40_joint_pb.py"
spec = importlib.util.spec_from_file_location("base_d5_seed_only", BASE_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)

TERMINALS = BASE.TERMINALS
S = tuple(sorted(BASE.S))
D5 = tuple(sorted(BASE.D5))
SEED_CELLS = tuple((s, s) for s in S) + D5


def boundary_name(boundary: frozenset[int]) -> str:
    return "_".join(map(str, sorted(boundary)))


def pool_var(boundary, slot, edge):
    return Bool(f"y_{boundary_name(boundary)}_{slot}_{edge[0]}_{edge[1]}")


def all_boundaries():
    out = {frozenset((i,)) for i in TERMINALS}
    for s, t in D5:
        out.add(BASE.boundary_for_pair(s))
        out.add(BASE.boundary_for_pair(t))
    return tuple(sorted(out, key=lambda b: (len(b), tuple(sorted(b)))))


def completion_formula(x, edges, pool_size, cell, tuple_slots):
    """Existence of a triple-slot pair completing one singleton tuple."""
    first, second = cell
    triple_boundaries = (BASE.boundary_for_pair(first),
                         BASE.boundary_for_pair(second))
    singleton_positions = tuple(sorted(set(first) | set(second)))
    options = []
    for left_slot in range(pool_size):
        for right_slot in range(pool_size):
            equalities = []
            for edge in edges:
                terms = [
                    (pool_var(triple_boundaries[0], left_slot, edge), 1),
                    (pool_var(triple_boundaries[1], right_slot, edge), 1),
                ]
                for pos in singleton_positions:
                    terms.append((pool_var(frozenset((pos,)),
                                           tuple_slots[pos], edge), 1))
                # All y-vectors imply x.  Consequently absent x-edges have
                # zero load automatically; only present edges need equality.
                equalities.append(Or(Not(x[edge]), PbEq(terms, 2)))
            options.append(And(*equalities))
    return Or(*options)


def build_solver(n: int, pool_size: int):
    edges = BASE.all_proper_edges(n)
    x = {edge: Bool(f"x_{edge[0]}_{edge[1]}") for edge in edges}
    solver = Solver()

    for v in range(n):
        incident = [x[e] for e in edges if v in e]
        target = 2 if v in TERMINALS else 3
        solver.add(PbEq([(value, 1) for value in incident], target))
    if n >= 7:
        solver.add(x[BASE.edge_key(5, 6)])

    boundaries = all_boundaries()
    for boundary in boundaries:
        for slot in range(pool_size):
            for edge in edges:
                solver.add(Or(Not(pool_var(boundary, slot, edge)), x[edge]))
            for v in range(n):
                terms = [(pool_var(boundary, slot, edge), 1)
                         for edge in edges if v in edge]
                target = 1 - int(v in TERMINALS and v in boundary)
                solver.add(PbEq(terms, target))

    # Positive seed cells: five loops and five disjoint S--T cells.
    for ci, kind in enumerate(SEED_CELLS):
        slot_boundaries = BASE.slots_for_type(kind)
        selectors = {}
        for position, boundary in enumerate(slot_boundaries):
            choices = []
            for slot in range(pool_size):
                z = Bool(f"z_{ci}_{position}_{slot}")
                selectors[(position, slot)] = z
                choices.append((z, 1))
            solver.add(PbEq(choices, 1))
        for edge in edges:
            load_terms = []
            for position, boundary in enumerate(slot_boundaries):
                for slot in range(pool_size):
                    z = selectors[(position, slot)]
                    yy = pool_var(boundary, slot, edge)
                    w = Bool(f"w_{ci}_{position}_{slot}_{edge[0]}_{edge[1]}")
                    solver.add(Or(Not(w), z))
                    solver.add(Or(Not(w), yy))
                    solver.add(Or(Not(z), Not(yy), w))
                    load_terms.append((w, 1))
            solver.add(PbLe(load_terms, 2))
            solver.add(Or(Not(x[edge]), PbEq(load_terms, 2)))

    # Finite-pool A blocker: every singleton-slot tuple overloads some edge.
    singleton_tuples = tuple(product(range(pool_size), repeat=len(TERMINALS)))
    for tuple_slots in singleton_tuples:
        valid_edges = []
        for edge in edges:
            terms = [(pool_var(frozenset((pos,)), tuple_slots[pos], edge), 1)
                     for pos in TERMINALS]
            valid_edges.append(PbLe(terms, 2))
        solver.add(Not(And(*valid_edges)))

    # Every D5 four-of-five join is empty for every singleton tuple.
    for omitted_index, omitted in enumerate(D5):
        retained = tuple(cell for cell in D5 if cell != omitted)
        for tuple_index, tuple_slots in enumerate(singleton_tuples):
            formulas = [completion_formula(x, edges, pool_size, cell,
                                           tuple_slots)
                        for cell in retained]
            solver.add(Or(*(Not(value) for value in formulas)))
    return solver, x, edges


def run(n: int, pool_size: int, timeout_ms: int, out_path: Path | None):
    solver, x, edges = build_solver(n, pool_size)
    started = time.time()
    solver.set(timeout=timeout_ms)
    status = solver.check()
    payload = {
        "n": n,
        "pool_size": pool_size,
        "status": ("bounded_unsat" if status != sat and status != unknown
                    else "sat" if status == sat else "unknown"),
        "elapsed_s": time.time() - started,
    }
    if status == sat:
        model = solver.model()
        proper_edges = [list(edge) for edge, var in x.items()
                        if bool(model.eval(var, model_completion=True))]
        payload["proper_edges"] = proper_edges
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print({"bounded_unsat": "D5_SEED_ONLY_BOUNDED_UNSAT",
           "sat": "D5_SEED_ONLY_SAT",
           "unknown": "D5_SEED_ONLY_UNKNOWN"}[payload["status"]])
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--pool-size", type=int, default=2)
    parser.add_argument("--timeout-ms", type=int, default=600000)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    run(args.n, args.pool_size, args.timeout_ms, args.json)


if __name__ == "__main__":
    main()
