#!/usr/bin/env python3
"""Symbolically eliminated cube/common-family D5 probe.

For every boundary class c and every other cube-coordinate block d, the
shared base incidence is x[c,d,r].  A vector's own block is its cube word
u[r], so the six-vector equations are reduced to the interval

    0 <= 2 - B[d,r] <= m[d].

Here m[d] is the number of occurrences of class d in the cell and B[d,r] is
the load contributed by all other class slots.  A shared trivalent label
lambda[c] handles the local three-edge equation.  D5 relations are cached on
four singleton coordinates (20,480 booleans for K=3); all five four-cell joins
are then one AtMost3 constraint per complete singleton tuple.  This is a
finite complete-cube model, not a graph-realization theorem.  Optional
``--pool-no-a`` adds the finite-cube A blocker.
"""

from __future__ import annotations

import argparse
import json
import time
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path

from z3 import And, AtMost, Bool, If, Int, Not, PbEq, PbGe, PbLe, Solver, Sum, sat, unknown


TERMINALS = tuple(range(5))
PAIRS = tuple(combinations(TERMINALS, 2))
S = ((0, 2), (0, 3), (1, 3), (1, 4), (2, 4))
T = ((0, 1), (0, 4), (1, 2), (2, 3), (3, 4))
S_SET = frozenset(S)
T_SET = frozenset(T)
CLASSES = tuple(("P", (i,)) for i in TERMINALS) + tuple(
    ("Q", pair) for pair in PAIRS
)
CLASS_INDEX = {cls: i for i, cls in enumerate(CLASSES)}
TARGET_TYPES = tuple(
    list(combinations_with_replacement(sorted(S), 2))
    + sorted(tuple(sorted((s, t))) for s in S for t in T)
)

# D5 transferred disjoint S--S cells, in the same order used by the closure
# notes.  Each misses one singleton coordinate.
D5_SS = (
    ((S[1], S[4])),
    ((S[0], S[2])),
    ((S[1], S[3])),
    ((S[2], S[4])),
    ((S[0], S[3])),
)


def pcls(i):
    return ("P", (i,))


def qcls(pair):
    return ("Q", tuple(pair))


def cell_slots(cell):
    first, second = cell
    return (qcls(first), qcls(second)) + tuple(pcls(i) for i in first + second)


def cell_indices(cell):
    return tuple(CLASS_INDEX[c] for c in cell_slots(cell))


def cell_local_formula(lambda_vars, cell):
    indices = cell_indices(cell)
    return And(*(
        Sum([If(lambda_vars[c] == edge, 1, 0) for c in indices]) == 2
        for edge in range(3)
    ))


def add_interval(solver, terms, multiplicity, fixed_own=None):
    """Add the exact cycle-block condition for one coordinate.

    ``terms`` is the non-self load B.  If fixed_own is supplied, the selected
    singleton vector contributes that constant bit; otherwise all m self bits
    are existential cube choices and only the interval remains.
    """
    if fixed_own is None:
        solver.add(PbLe(terms, 2))
        solver.add(PbGe(terms, 2 - multiplicity))
    else:
        solver.add(PbEq(terms, 2 - fixed_own))


def cycle_formula(solver, x, cell, K, fixed_singletons=None):
    """Existentially eliminate all vector variants for one cell.

    ``fixed_singletons`` maps terminal position to a cube word (0..2**K-1)
    and is used only for a D5 relation cache entry.  Triple variants remain
    existential and therefore contribute the interval [0,m].
    """
    indices = cell_indices(cell)
    multiplicities = [indices.count(d) for d in range(len(CLASSES))]
    fixed_singletons = fixed_singletons or {}
    formulas = []
    for d in range(len(CLASSES)):
        m = multiplicities[d]
        for r in range(K):
            terms = [
                (x[(c, d, r)], count)
                for c, count in enumerate(multiplicities)
                if c != d and count
            ]
            fixed_own = None
            cls = CLASSES[d]
            if m and cls[0] == "P" and cls[1][0] in fixed_singletons:
                word = fixed_singletons[cls[1][0]]
                # D5 scopes contain each singleton class once.  The formula
                # also handles a repeated fixed singleton by multiplying its
                # bit by the occurrence count.
                fixed_own = m * ((word >> r) & 1)
            add_interval(solver, terms, m, fixed_own)
            formulas.append(True)
    # All interval constraints were added to the solver, so this helper is
    # used only for top-level support formulas.  A separate pure-expression
    # version below is used for cached R booleans.
    return formulas


def interval_expr(x, cell, K, fixed_singletons=None):
    """Pure Boolean version of ``cycle_formula`` for relation caching."""
    indices = cell_indices(cell)
    multiplicities = [indices.count(d) for d in range(len(CLASSES))]
    fixed_singletons = fixed_singletons or {}
    out = []
    for d in range(len(CLASSES)):
        m = multiplicities[d]
        for r in range(K):
            terms = [
                (x[(c, d, r)], count)
                for c, count in enumerate(multiplicities)
                if c != d and count
            ]
            cls = CLASSES[d]
            if m and cls[0] == "P" and cls[1][0] in fixed_singletons:
                word = fixed_singletons[cls[1][0]]
                own = m * ((word >> r) & 1)
                out.append(PbEq(terms, 2 - own))
            else:
                out.append(PbLe(terms, 2))
                out.append(PbGe(terms, 2 - m))
    return And(*out)


def local_capacity_expr(lambda_vars, singleton_words):
    """Finite-cube A capacity test for one tuple of singleton vectors."""
    out = []
    # Cycle coordinates: all five P classes are selected once.  At a P block
    # its own bit is fixed by the tuple; at a Q block there is no self slot.
    for d in range(len(CLASSES)):
        for r in range(CURRENT_K):
            terms = [
                (CURRENT_X[(c, d, r)], 1)
                for c in range(5) if c != d
            ]
            own = ((singleton_words[d] >> r) & 1) if d < 5 else 0
            out.append(PbLe(terms, 2 - own))
    for edge in range(3):
        out.append(Sum([If(lambda_vars[c] == edge, 1, 0)
                        for c in range(5)]) <= 2)
    return And(*out)


def build_solver(K=3, pool_no_a=False):
    global CURRENT_K, CURRENT_X
    CURRENT_K = K
    solver = Solver()
    x = {}
    for c in range(len(CLASSES)):
        for d in range(len(CLASSES)):
            if c == d:
                continue
            for r in range(K):
                x[(c, d, r)] = Bool(f"x_{c}_{d}_{r}")
    CURRENT_X = x
    lambda_vars = [Int(f"lambda_{c}") for c in range(len(CLASSES))]
    for value in lambda_vars:
        solver.add(value >= 0, value <= 2)

    # Positive and negative boundary support, with all cube variants already
    # eliminated to interval constraints.
    def support_expr(cell):
        return And(cell_local_formula(lambda_vars, cell),
                   interval_expr(x, cell, K))

    positive = ([(pair, pair) for pair in S]
                + list(combinations(S, 2))
                + [(s, t) for s in S for t in T])
    negative = ([(pair, pair) for pair in T]
                + list(combinations(T, 2)))
    for cell in positive:
        solver.add(support_expr(cell))
    for cell in negative:
        solver.add(Not(support_expr(cell)))

    # Cache one R_{cell,u} per four-coordinate projection (20,480 booleans at
    # K=3), then impose the exact five-column no-join condition by AtMost3 on
    # each complete five-tuple projection.
    relation_cache = {}
    scopes = [tuple(sorted(set(a) | set(b))) for a, b in D5_SS]
    V = 1 << K
    for ci, (cell, scope) in enumerate(zip(D5_SS, scopes)):
        for words in product(range(V), repeat=4):
            fixed = dict(zip(scope, words))
            rel = Bool("R_%d_%s" % (ci, "_".join(map(str, words))))
            formula = And(cell_local_formula(lambda_vars, cell),
                          interval_expr(x, cell, K, fixed))
            solver.add(rel == formula)
            relation_cache[(ci, words)] = rel
    for words in product(range(V), repeat=5):
        rels = []
        for ci, scope in enumerate(scopes):
            projected = tuple(words[p - 0] for p in scope)
            rels.append(relation_cache[(ci, projected)])
        # AtMost3 is exactly emptiness of every four-of-five cylinder join.
        solver.add(AtMost(*rels, 3))

    if pool_no_a:
        # Optional finite-cube no-A strengthening.  It is not a full pole
        # quantifier: only the represented singleton cube is checked.
        for words in product(range(V), repeat=5):
            solver.add(Not(local_capacity_expr(lambda_vars, words)))

    return solver, x, lambda_vars, len(relation_cache)


def run(K, pool_no_a, timeout_ms, build_only, out_path):
    started = time.time()
    solver, x, lambda_vars, relation_count = build_solver(K, pool_no_a)
    build_s = time.time() - started
    payload = {"K": K, "n": 13, "pool_no_a": pool_no_a,
               "relation_count": relation_count,
               "assertions": len(solver.assertions()),
               "build_s": build_s}
    if build_only:
        payload["status"] = "build_only"
        print(json.dumps(payload, indent=2, sort_keys=True))
        print("CUBE_SYMBOLIC_D5_BUILD_ONLY_OK")
    else:
        solver.set(timeout=timeout_ms)
        status = solver.check()
        payload["status"] = ("sat" if status == sat else
                              "unknown" if status == unknown else
                              "bounded_unsat")
        print(json.dumps(payload, indent=2, sort_keys=True))
        print({"sat": "CUBE_SYMBOLIC_D5_SAT",
               "unknown": "CUBE_SYMBOLIC_D5_UNKNOWN",
               "bounded_unsat": "CUBE_SYMBOLIC_D5_BOUNDED_UNSAT"}[payload["status"]])
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--K", type=int, default=3)
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--pool-no-a", action="store_true")
    parser.add_argument("--timeout-ms", type=int, default=120000)
    parser.add_argument("--build-only", action="store_true")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.K < 1 or args.n < 5 or args.n % 2 == 0:
        raise SystemExit("K positive; n odd >=5")
    run(args.K, args.pool_no_a, args.timeout_ms, args.build_only, args.json)


if __name__ == "__main__":
    main()
