#!/usr/bin/env python3
"""Bounded common-incidence synthesis with *direct* D5 join constraints.

This is a deliberately narrow Omen pulse.  The graph is one simple cubic
5-pole and every pool vector is a perfect matching of that same graph.  The
40 positive Case-XII cells use a common pool of K matching slots per boundary
class.  Unlike the older CEGAR driver, absence of a four-of-five D5 join is
encoded in the base solver for every pool singleton tuple.  A-cover absence
is also encoded for the pool (the complete graph-level A blocker remains a
lazy check, because a pole may have PMs outside the finite pool).

Interpretation of a positive result is therefore careful: the independent
evaluator must still enumerate *all* perfect matchings of the returned graph
and verify exact support, no A/T-loop/TT, and no D5 join.  UNSAT is only a
bounded theorem for the selected order and pool size; timeout/round-limit is
unresolved.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import product
from pathlib import Path

from z3 import And, Bool, Not, Or, PbEq, PbLe, Solver, sat, unknown


HERE = Path(__file__).resolve().parent
REAL = HERE.parent / "worker-bf-real-synthesis"
SHARED_PATH = REAL / "synthesize_exact40_shared_pool.py"
spec = importlib.util.spec_from_file_location("shared_pool_base", SHARED_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(SHARED_PATH)
SHARED = importlib.util.module_from_spec(spec)
spec.loader.exec_module(SHARED)
BASE = SHARED.BASE

TERMINALS = BASE.TERMINALS
TARGET_TYPES = tuple(BASE.TARGET_TYPES)
D5 = tuple(BASE.D5)


def boundary_name(boundary: frozenset[int]) -> str:
    return "_".join(map(str, sorted(boundary)))


def pool_var(boundary, slot, edge):
    return Bool(
        f"y_{boundary_name(boundary)}_{slot}_{edge[0]}_{edge[1]}"
    )


def pool_boundaries():
    boundaries = {frozenset((i,)) for i in TERMINALS}
    for kind in TARGET_TYPES:
        boundaries.add(BASE.boundary_for_pair(kind[0]))
        boundaries.add(BASE.boundary_for_pair(kind[1]))
    return tuple(sorted(boundaries, key=lambda b: (len(b), tuple(sorted(b)))))


def exact_completion_formula(solver, x, n, edges, pool_size, cell, tuple_slots,
                             triple_slots, tag):
    """Return a Boolean saying that this pool tuple has a cell completion.

    The returned ``cell_ok`` is definitionally equivalent to the existence of
    one pair of triple pool slots whose six common vectors have proper-edge
    load exactly two.  Both directions are encoded: a solver cannot hide a
    valid completion by setting the auxiliary Boolean false.
    """
    first, second = cell
    triple_boundaries = (BASE.boundary_for_pair(first),
                         BASE.boundary_for_pair(second))
    singleton_positions = tuple(sorted(set(first) | set(second)))
    options = []
    for left_slot in range(pool_size):
        for right_slot in range(pool_size):
            edge_equalities = []
            for edge in edges:
                terms = [
                    (pool_var(triple_boundaries[0], left_slot, edge), 1),
                    (pool_var(triple_boundaries[1], right_slot, edge), 1),
                ]
                for pos in singleton_positions:
                    terms.append((
                        pool_var(frozenset((pos,)), tuple_slots[pos], edge), 1
                    ))
                # Only graph edges are subject to the double-cover equation.
                # ``edges`` is the complete potential-edge universe; absent
                # potential edges must not make every completion impossible.
                edge_equalities.append(
                    Or(Not(x[edge]), PbEq(terms, 2))
                )
            # Inline the exact conjunction.  This is logically equivalent to
            # the previous z/cell auxiliaries, but avoids two implications per
            # edge and is substantially smaller for K=3.
            options.append(And(*edge_equalities))
    return Or(*options)


def add_direct_no_join_and_pool_no_a(solver, x, n, edges, pool_size,
                                     include_pool_a: bool = True):
    """Add all finite-pool D5 no-join and optional pool no-A constraints."""
    tuples = tuple(product(range(pool_size), repeat=len(TERMINALS)))

    if include_pool_a:
        # A=(12345) uses one singleton PM from each class and is forbidden in
        # the finite pool.  A pool tuple is valid precisely when every proper
        # edge has load at most two (the pole semantics checks proper edges;
        # semiedge loads are fixed by the boundary classes).
        for tuple_index, tuple_slots in enumerate(tuples):
            # Inline the conjunction of per-edge capacity tests.  Its negation
            # is the required finite-pool A blocker.
            valid_edges = []
            for edge in edges:
                terms = [
                    (pool_var(frozenset((pos,)), tuple_slots[pos], edge), 1)
                    for pos in TERMINALS
                ]
                valid_edges.append(PbLe(terms, 2))
            solver.add(Not(And(*valid_edges)))

    # For each omitted D5 cell and each complete singleton tuple, at least one
    # of the other four cells must lack a completion.  This is exactly the
    # empty four-cell cylinder intersection in the finite common pool.
    for omitted_index, omitted in enumerate(D5):
        retained = tuple(cell for cell in D5 if cell != omitted)
        for tuple_index, tuple_slots in enumerate(tuples):
            cells_ok = []
            for cell_index, cell in enumerate(retained):
                cells_ok.append(exact_completion_formula(
                    solver, x, n, edges, pool_size, cell, tuple_slots,
                    None, f"o{omitted_index}_t{tuple_index}_c{cell_index}"
                ))
            solver.add(Or(*(Not(value) for value in cells_ok)))


def build_solver(n: int, pool_size: int, include_pool_a: bool = True):
    # Reuse the common-pool positive-cell incidence encoding, then strengthen
    # it with direct finite-pool join/no-A predicates.  The returned x/edges
    # have exactly the same names and semantics as the existing evaluator.
    solver, x, edges = SHARED.build_solver(n, pool_size)
    add_direct_no_join_and_pool_no_a(solver, x, n, edges, pool_size,
                                     include_pool_a=include_pool_a)
    return solver, x, edges


def evaluate(n: int, proper_edges):
    return SHARED.evaluate(n, proper_edges)


def certificate(n: int, proper_edges, result, pool_size):
    return {
        "n": n,
        "pool_size": pool_size,
        "proper_edges": [list(e) for e in proper_edges],
        "matching_count": len(result["matchings"]),
        "support_size": len(result["support"]),
        "support": [str(k) for k in sorted(result["support"], key=str)],
        "target_support": result["support"] == frozenset(TARGET_TYPES),
        "has_A": result["a_witness"] is not None,
        "d5_join_flags": list(result["joins"]),
    }


def block_graph_clause(solver, x, edges, proper_edges):
    """Return graph-level clauses for connectivity/bridge violations."""
    clauses = []
    components = BASE.connected_components(len({v for e in edges for v in e}),
                                           proper_edges)
    if len(components) != 1:
        side = min(components, key=lambda c: (len(c), tuple(sorted(c))))
        crossing = frozenset(edge for edge in edges
                             if (edge[0] in side) ^ (edge[1] in side))
        clauses.append((Or([x[e] for e in crossing]),
                        {"kind": "disconnected", "side": sorted(side)}))
    else:
        for bridge, side in BASE.bridge_cuts(
                len({v for e in edges for v in e}), proper_edges):
            crossing = frozenset(edge for edge in edges
                                 if edge != bridge
                                 and ((edge[0] in side) ^ (edge[1] in side)))
            if crossing:
                clause = Or([x[e] for e in crossing])
            else:
                clause = Not(x[bridge])
            clauses.append((clause, {"kind": "bridge", "bridge": list(bridge)}))
    return clauses


def run(n: int, pool_size: int, max_rounds: int, timeout_ms: int,
        out_path: Path | None, include_pool_a: bool = True):
    solver, x, edges = build_solver(n, pool_size, include_pool_a=include_pool_a)
    target_set = frozenset(TARGET_TYPES)
    rounds = []
    started = time.time()
    for round_no in range(max_rounds):
        solver.set(timeout=timeout_ms)
        status = solver.check()
        if status == unknown:
            payload = {"status": "unknown", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True)
                                    + "\n", encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("JOINT_POOL_UNKNOWN")
            return payload
        if status != sat:
            payload = {"status": "bounded_unsat", "rounds": rounds,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True)
                                    + "\n", encoding="utf-8")
            print(json.dumps(payload, indent=2, sort_keys=True))
            print("JOINT_POOL_BOUNDED_UNSAT")
            return payload

        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var,
                                                       model_completion=True))))
        result = evaluate(n, proper_edges)
        bad = []
        for clause, info in block_graph_clause(solver, x, edges, proper_edges):
            solver.add(clause)
            bad.append(info)

        # The finite-pool no-A condition is already hard, but the evaluator
        # checks every actual PM in the graph; block an outside-pool A cover.
        if result["a_witness"] is not None:
            union = BASE.forbidden_union(result["a_witness"], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "A_outside_pool", "union_size": len(union)})

        # Exact support/no unwanted types remain graph-universal and are lazily
        # blocked by concrete actual PM covers, as in the trusted evaluator.
        for kind in sorted(result["support"] - target_set, key=str):
            union = BASE.forbidden_union(result["witnesses"][kind], proper_edges)
            solver.add(BASE.clause_for_union(x, edges, union))
            bad.append({"kind": "forbidden_type", "type": str(kind),
                        "union_size": len(union)})

        cert = certificate(n, proper_edges, result, pool_size)
        rounds.append({"round": round_no, "bad": bad, "certificate": cert})
        print(json.dumps(rounds[-1], sort_keys=True))

        if (not bad and result["support"] == target_set
                and result["a_witness"] is None
                and not any(result["joins"])):
            payload = {"status": "real_exact40_joinfree",
                       "rounds": rounds, "certificate": cert,
                       "elapsed_s": time.time() - started}
            if out_path:
                out_path.write_text(json.dumps(payload, indent=2, sort_keys=True)
                                    + "\n", encoding="utf-8")
            print("REAL_EXACT40_JOINFREE_SYNTHESIZED")
            return payload

    payload = {"status": "round_limit", "rounds": rounds,
               "elapsed_s": time.time() - started}
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n",
                            encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    print("JOINT_POOL_ROUND_LIMIT")
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--pool-size", type=int, default=2)
    parser.add_argument("--max-rounds", type=int, default=8)
    parser.add_argument("--timeout-ms", type=int, default=120000)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--allow-pool-a", action="store_true",
                        help="diagnostic: omit only the finite-pool A blocker")
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0:
        raise SystemExit("n must be odd and at least 5")
    if args.pool_size < 1:
        raise SystemExit("pool-size must be positive")
    run(args.n, args.pool_size, args.max_rounds, args.timeout_ms, args.json,
        include_pool_a=not args.allow_pool_a)


if __name__ == "__main__":
    main()
