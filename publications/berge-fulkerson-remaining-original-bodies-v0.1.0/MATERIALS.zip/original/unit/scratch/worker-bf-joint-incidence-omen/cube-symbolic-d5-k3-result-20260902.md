# Symbolically eliminated common-family D5 pulse (2026-09-02)

## Decision target

Test the finite complete-cube/common-family strengthening of the D5 gate at
nominal order (n=13), with cube dimension (K=3).  The intended interface
has one shared vector family for all five singleton and ten triple boundary
classes, a common trivalent label (lambda_c), exact positive Case-XII
support, no (T)-loop/(T)-(T) support, and empty four-of-five D5 joins.
The finite-cube no-(A) option checks the five singleton cube vectors only.

For a cell, all self cube coordinates are eliminated symbolically.  If class
(d) occurs (m_d) times and the non-self load in coordinate (r) is
(B_{d,r}), existential self variants are equivalent to

\[
0\le 2-B_{d,r}\le m_d.
\]

For a D5 cell, the four singleton coordinates are cached as
(R_{c,u}).  At (K=3) this is (5\cdot 8^4=20{,}480) relation booleans;
the five-cell no-join condition is exactly

\[
\operatorname{AtMost3}(R_{1,u},\ldots,R_{5,u})
\]

for every complete (8^5) singleton tuple (u).

This is not a graph-realization theorem: the cube family is a strengthened
finite incidence model and does not encode a common simple cubic 5-pole.

## Omen runs

Source:
`cube_symbolic_d5_k3.py`, SHA-256
`8d40a11fdcba4e62952a7c647981204f1e839a89c6d184b482e7fa448e90b751`.

All runs used host `omen`, detached `tmux`, and a 4 GiB virtual-memory limit.

### K=3 build-only (without finite-cube A blocker)

```text
python3 -u cube_symbolic_d5_k3.py --K 3 --n 13 --build-only \\
  --json cube_k3_build2.json
```

Result: `CUBE_SYMBOLIC_D5_BUILD_ONLY_OK`; 20,480 cached relations, 53,333
assertions, build time 170.8146 s.  JSON SHA-256:
`c37cff77dd1baa530863820da6b51d9739d0447e962638a01343d4aeba1093f9`.

### K=3 solver check (finite-cube no-A strengthening)

```text
python3 -u cube_symbolic_d5_k3.py --K 3 --n 13 --pool-no-a \\
  --timeout-ms 300000 --json cube_k3_solve.json
```

Result: `CUBE_SYMBOLIC_D5_BOUNDED_UNSAT`; 20,480 cached relations, 86,101
assertions, build time 321.6327 s.  JSON SHA-256:
`7cb61da50493508450ccc70792316a0cb1a1851df32723b76bd3f9120fd6a553`.

### Corrected K=1 sanity check

```text
python3 -u cube_symbolic_d5_k3.py --K 1 --n 13 --pool-no-a \\
  --timeout-ms 120000 --json cube_k1_sanity.json
```

Result: `CUBE_SYMBOLIC_D5_BOUNDED_UNSAT`; 80 cached relations, 229
assertions, build time 0.5680 s.  JSON SHA-256:
`8c9e4a089be064dffc382067ab8a6ebcb0014bf50b821f5b4c376448987e1d9f`.

## Four-value decision

* A SAT model: **not obtained**.
* A complete-pole counterexample: **not obtained**.
* An all-order proof: **not obtained**.
* The only positive computational statement is a **bounded UNSAT** for the
  (K=3,n=13) finite complete-cube model with finite-cube no-(A), and for
  (K=1).  It cannot be promoted to a real-pole theorem because actual
  perfect-matching families need not form complete cubes and the model has no
  global graph gluing.

The earlier direct-potential-edge K=1/K=2 runs in this directory are not
evidence: their completion equation accidentally required load two on absent
potential edges.  They are superseded by this corrected symbolic run.

