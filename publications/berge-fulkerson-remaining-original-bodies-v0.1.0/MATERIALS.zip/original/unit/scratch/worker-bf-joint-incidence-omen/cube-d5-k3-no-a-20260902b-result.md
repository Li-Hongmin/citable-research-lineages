# Omen finite cube D5 no-join pulse (2026-09-02b)

## Decision target

Test the finite complete-cube/common-incidence model at nominal order (n=13)
with cube dimension (K=3).  The model imposes the exact positive
Case-XII support, excludes all (T)-loops and (T)--(T) cells, and requires
all five four-of-five D5 joins to be empty.  This run deliberately **does not**
impose the finite-pool (A=(12345)) blocker.  The question is whether the
no-join constraints themselves can survive in this finite incidence model.

This is not a graph-realization theorem: the symbolic cube has no common
simple cubic 5-pole or complete perfect-matching closure.

## Omen execution

Source file:

```text
cube_symbolic_d5_k3.py
SHA-256 8d40a11fdcba4e62952a7c647981204f1e839a89c6d184b482e7fa448e90b751
```

The source was copied byte-for-byte to Omen and run in detached tmux session
`cube-d5-k3-no-a-20260902b`, with a 4 GiB virtual-memory limit:

```text
python3 -u cube_symbolic_d5_k3.py --K 3 --n 13 --timeout-ms 300000 \
  --json cube_k3_no_a.json
```

Omen reported:

```json
{
  "K": 3,
  "assertions": 53333,
  "build_s": 171.76204562187195,
  "n": 13,
  "pool_no_a": false,
  "relation_count": 20480,
  "status": "bounded_unsat"
}
```

Archived artifacts:

* `cube-d5-k3-no-a-20260902b-result.json` (SHA-256
  `977de6ecec3ada523f349c7f1b37e9b9f5b9013f62f59f382ff8caf202f945e2`)
* `cube-d5-k3-no-a-20260902b-run.log` (SHA-256
  `ecff27f637895402c6eaca5a7d0014d4f8a9a57b810a743fc38a43c484dd34fe`)

## Four-value decision

The finite (K=3,n=13) cube model is **bounded-UNSAT even without the finite
pool (A)-blocker**.  Thus, within this symbolic common-incidence relaxation,
the five D5 no-join constraints are already incompatible with the exact
Case-XII support.

This does not prove the D5 join for a real cubic 5-pole: the cube model is only
a finite family of incidence coordinates and omits the shared trivalent graph
and its full perfect-matching closure.  It also says nothing about larger
cube dimension (K) or arbitrary matching fibres.  No order or (K) escalation
is justified by this result.
