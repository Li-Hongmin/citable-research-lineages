#!/usr/bin/env python3
"""Compressed bounded common-incidence probe for the D5 join.

The base object is the common-PM pool used by ``synthesize_exact40_shared_pool``.
Every pool vector is a perfect matching of one graph.  For each omitted D5
cell and each finite singleton tuple this variant chooses one retained cell
and one *present* potential edge.  The chosen edge is required to have load
different from two for every triple-slot pair in that cell.  This is an
edge-uniform blocker: it is stronger than arbitrary no-join (where the
blocking edge may depend on the triple pair), but is compact enough to probe
K=3.  A SAT model is only a candidate and must pass full PM evaluation;
UNSAT is only for this strengthened bounded model.

The script supports ``--build-only`` so construction cost can be measured
without accidentally treating a Python/Z3 memory failure as UNSAT.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import time
from itertools import product
from pathlib import Path

from z3 import And, Bool, If, Not, Or, PbEq, PbLe, Solver, sat, unknown

HERE = Path(__file__).resolve().parent
REAL = HERE.parent / "worker-bf-real-synthesis"
SHARED_PATH = REAL / "synthesize_exact40_shared_pool.py"
spec = importlib.util.spec_from_file_location("shared_pool_edge_blocker", SHARED_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(SHARED_PATH)
SHARED = importlib.util.module_from_spec(spec)
spec.loader.exec_module(SHARED)
BASE = SHARED.BASE
TERMINALS = BASE.TERMINALS
TARGET_TYPES = tuple(BASE.TARGET_TYPES)
D5 = tuple(BASE.D5)


def boundary_name(boundary: frozenset[int]) -> str:
    return "_".join(map(str, sorted(boundary)))


def yvar(boundary, slot, edge):
    return Bool(f"y_{boundary_name(boundary)}_{slot}_{edge[0]}_{edge[1]}")


def add_pool_no_a(solver, edges, pool_size):
    """Forbid A among the finite singleton pool (proper-edge semantics)."""
    for tuple_index, slots in enumerate(product(range(pool_size), repeat=5)):
        valid = []
        for edge in edges:
            load = [(yvar(frozenset((p,)), slots[p], edge), 1)
                    for p in TERMINALS]
            valid.append(PbLe(load, 2))
        solver.add(Not(And(*valid)))


def add_edge_uniform_nojoin(solver, x, edges, pool_size):
    """Add a compact, edge-uniform sufficient no-join blocker.

    For every omitted cell and singleton pool tuple, exactly one retained cell
    is selected.  Exactly one potential edge is then selected for that cell;
    it must be a present graph edge and must fail the exact-load equation for
    every pair of triple pool slots.  Hence that cell has no completion.
    """
    tuples = tuple(product(range(pool_size), repeat=5))
    for omitted_index, omitted in enumerate(D5):
        retained = tuple(cell for cell in D5 if cell != omitted)
        for tuple_index, slots in enumerate(tuples):
            selected_cells = [
                Bool(f"ub_cell_o{omitted_index}_t{tuple_index}_c{ci}")
                for ci in range(len(retained))
            ]
            solver.add(PbEq([(v, 1) for v in selected_cells], 1))
            for ci, cell in enumerate(retained):
                cell_selected = selected_cells[ci]
                block_edges = [
                    Bool(f"ub_edge_o{omitted_index}_t{tuple_index}_c{ci}_e{ei}")
                    for ei in range(len(edges))
                ]
                # One blocker edge iff this cell is selected; additionally the
                # edge must be present in the synthesized graph.
                block_count = [(v, 1) for v in block_edges]
                solver.add(Or(Not(cell_selected), PbEq(block_count, 1)))
                solver.add(Or(cell_selected, PbEq(block_count, 0)))
                for ei, edge in enumerate(edges):
                    b = block_edges[ei]
                    solver.add(Or(Not(b), x[edge]))
                    first, second = cell
                    tb = (BASE.boundary_for_pair(first),
                          BASE.boundary_for_pair(second))
                    singleton_positions = tuple(sorted(set(first) | set(second)))
                    for left_slot in range(pool_size):
                        for right_slot in range(pool_size):
                            terms = [
                                (yvar(tb[0], left_slot, edge), 1),
                                (yvar(tb[1], right_slot, edge), 1),
                            ]
                            terms.extend(
                                (yvar(frozenset((p,)), slots[p], edge), 1)
                                for p in singleton_positions
                            )
                            # If b is selected, this edge cannot satisfy the
                            # exact load equation for this triple-slot pair.
                            solver.add(Or(Not(b), Not(PbEq(terms, 2))))


def build_solver(n, pool_size):
    solver, x, edges = SHARED.build_solver(n, pool_size)
    add_pool_no_a(solver, edges, pool_size)
    add_edge_uniform_nojoin(solver, x, edges, pool_size)
    return solver, x, edges


def run(n, pool_size, timeout_ms, out_path, build_only=False):
    started = time.time()
    solver, x, edges = build_solver(n, pool_size)
    build_s = time.time() - started
    if build_only:
        payload = {"status": "build_only", "n": n, "pool_size": pool_size,
                   "assertions": len(solver.assertions()),
                   "build_s": build_s}
        print(json.dumps(payload, indent=2, sort_keys=True))
        if out_path:
            out_path.write_text(json.dumps(payload, indent=2, sort_keys=True)
                                + "\n", encoding="utf-8")
        print("EDGE_BLOCKER_BUILD_ONLY_OK")
        return payload
    solver.set(timeout=timeout_ms)
    status = solver.check()
    elapsed = time.time() - started
    if status == unknown:
        tag, text = "unknown", "EDGE_BLOCKER_UNKNOWN"
    elif status == sat:
        tag, text = "sat", "EDGE_BLOCKER_SAT_CANDIDATE"
    else:
        tag, text = "bounded_unsat", "EDGE_BLOCKER_BOUNDED_UNSAT"
    payload = {"status": tag, "n": n, "pool_size": pool_size,
               "assertions": len(solver.assertions()),
               "build_s": build_s, "elapsed_s": elapsed}
    if status == sat:
        model = solver.model()
        proper_edges = tuple(sorted(edge for edge, var in x.items()
                                    if bool(model.eval(var,
                                                       model_completion=True))))
        result = SHARED.evaluate(n, proper_edges)
        payload["proper_edges"] = [list(e) for e in proper_edges]
        payload["matching_count"] = len(result["matchings"])
        payload["support_size"] = len(result["support"])
        payload["has_A"] = result["a_witness"] is not None
        payload["d5_join_flags"] = list(result["joins"])
    print(json.dumps(payload, indent=2, sort_keys=True))
    if out_path:
        out_path.write_text(json.dumps(payload, indent=2, sort_keys=True)
                            + "\n", encoding="utf-8")
    print(text)
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=13)
    parser.add_argument("--pool-size", type=int, default=3)
    parser.add_argument("--timeout-ms", type=int, default=120000)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--build-only", action="store_true")
    args = parser.parse_args()
    if args.n < 5 or args.n % 2 == 0 or args.pool_size < 1:
        raise SystemExit("n must be odd >=5 and pool-size positive")
    run(args.n, args.pool_size, args.timeout_ms, args.json,
        build_only=args.build_only)


if __name__ == "__main__":
    main()
