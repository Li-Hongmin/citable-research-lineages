# Shared-lambda support-only correction (Omen, 2026-09-02)

## Decision target

The earlier finite-cube D5 pulse was rerun after removing the entire D5
relation cache and all five `AtMost3` four-of-five no-join constraints.  The
remaining model has only one common trivalent label `lambda[c]` for each of
the five singleton and ten triple boundary classes, together with the exact
40 positive Case-XII support cells and the negative T-loop/T--T cells.
There is no finite-pool `(12345)` blocker in this correction.

Thus this run tests whether the earlier UNSAT can be attributed to D5 joins.

## Omen runs

Source:
`cube_lambda_support_only.py`, SHA-256
`da8e6fa688a1ce1c4020e148536092fe0aa0f1c2fdc4736b6d0ed1313f39af72`.

Both runs used host `omen`, a detached-equivalent noninteractive invocation,
and a 4 GiB virtual-memory limit.

### K=1

```text
python3 -u cube_lambda_support_only.py --K 1 --timeout-ms 120000 \\
  --json cube_k1_support_only.json
```

```json
{
  "K": 1,
  "assertions": 85,
  "build_s": 0.21001744270324707,
  "n": 13,
  "pool_no_a": false,
  "relation_count": 0,
  "status": "bounded_unsat"
}
```

### K=3

```text
python3 -u cube_lambda_support_only.py --K 3 --timeout-ms 120000 \\
  --json cube_k3_support_only.json
```

```json
{
  "K": 3,
  "assertions": 85,
  "build_s": 0.4620051383972168,
  "n": 13,
  "pool_no_a": false,
  "relation_count": 0,
  "status": "bounded_unsat"
}
```

The Omen markers were respectively
`CUBE_LAMBDA_SUPPORT_ONLY_BOUNDED_UNSAT` for both runs.

## Correct interpretation

The D5 constraints are not needed for this model-level contradiction.  The
common single label `lambda[c]` already cannot realize all 40 positive cells
while rejecting the 15 T-loop and 45 T--T cells.  Since the contradiction is
independent of `K`, the K=3 D5 UNSAT is not evidence that a D5 four-column join
is forced by common perfect-matching incidence.

This is only a theorem about the strengthened symbolic model.  A genuine
cubic five-pole has no reason to assign one fixed trivalent edge label to an
entire boundary class: different perfect matchings in the same class may use
different local edge labels.  Therefore the result neither proves the
Berge--Fulkerson conjecture nor the D5 join for real poles.

## Minimal analytic lambda-only core

In fact the contradiction needs only six positive cells; no cube incidence
bits, no D5 relation, and no negative support cell are involved.  In the
zero-based terminal notation used by the source, take

```text
positive loops:  (13),(14),(24)     [S_2,S_3,S_4]
mixed cells:    (02,12),(02,23),(02,34) [S_0 with T_2,T_3,T_4].
```

Here `(e,f)` denotes the six-slot cell with boundary classes `Q_e,Q_f` and
the four singleton occurrences from `e` and `f`; a repeated endpoint is
therefore repeated in the multiset.  Write
`p_i=lambda(P_i)` and `q_e=lambda(Q_e)`, with three labels.

Let `c=p_2`.  The direct zero-based slot multisets are

```text
(02,12): {q_02,q_12,p_0,p_1,2p_2},
(02,23): {q_02,q_23,p_0,p_3,2p_2},
(02,34): {q_02,q_34,p_0,p_2,p_3,p_4}.
```

The first two equations force `p_0,p_1,p_3,q_02` to avoid `c`.  The loop
cells `(13),(14),(24)` force `p_1 != p_3`, `p_1 != p_4`, and `p_2 != p_4`.
Thus `p_1,p_3` are the two labels different from `c`, and `p_4=p_3`.
In the disjoint mixed cell `(02,34)`, the two copies of `p_3` already fill
that label.  Since `p_0,q_02` avoid `c`, exact two-load forces
`p_0=q_02=p_1` and `q_34=c`.  But `(02,12)` then contains three copies of
`p_1` (`q_02,p_0,p_1`), contradicting the required two copies of every
label.

Deleting any one of these six cells makes the label system satisfiable (a
direct 3-label enumeration confirms irreducibility), so this is a genuine
six-cell lambda-only UNSAT core.  It explains both Omen runs: the same core is
repeated independently in every cube coordinate, and the contradiction does
not depend on `K`.

This theorem is only about the diagnostic shared-lambda model.  In a genuine
cubic five-pole, a boundary class contains many perfect matchings whose local
edge labels need not agree; replacing that family by one fixed `lambda[c]`
is precisely the strengthening responsible for the contradiction.
