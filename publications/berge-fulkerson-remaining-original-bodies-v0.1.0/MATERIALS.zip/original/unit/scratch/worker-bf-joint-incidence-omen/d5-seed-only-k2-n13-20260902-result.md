# Omen D5 seed-only common-incidence pulse (2026-09-02)

## Decision target

This pulse tests a deliberate relaxation of the full Case-XII common-pool
model at order (n=13), pool size (K=2).  It keeps one common family of
actual perfect-matching incidence vectors for every singleton and triple
boundary class, the five S-loop cells, the five disjoint (D_5) S--T seed
cells, a finite-pool absence of (A=(12345)), and all five four-of-five
joins forbidden.  The other 30 positive cells and all extra-support/complete
closure checks are omitted.  Therefore an UNSAT result would be a bounded
common-incidence obstruction; a SAT result would only be a relaxation model.

## Omen run

Source:

```text
synthesize_d5_seed_only_pool.py
SHA-256 6594051b8bd4c3f03aa9ed2cbf18a0a71fc3f0f0149a75949d8f96072bc128be
```

Command on `omen` (detached tmux):

```text
python3 -u synthesize_d5_seed_only_pool.py --n 13 --pool-size 2 \
  --timeout-ms 600000 --json result.json
```

Remote run directory:

```text
[local archival reference]
```

Result JSON SHA-256:

```text
36d11a27972bcd606d915e3404c954dcebe17ccfc09ba9e1f4363aa257a31703
```

Omen returned:

```json
{"elapsed_s": 600.0188293457031, "n": 13, "pool_size": 2,
 "status": "unknown"}
```

## Four-value decision

No general proof, real pole, or bounded UNSAT certificate was obtained.  The
strictly relaxed seed-only model remained unresolved at the ten-minute Z3
budget.  This is not evidence for or against the Case-XII D5 join conjecture,
and it does not justify increasing the pool size or order.  The computational
branch is frozen pending a structural encoding improvement.
