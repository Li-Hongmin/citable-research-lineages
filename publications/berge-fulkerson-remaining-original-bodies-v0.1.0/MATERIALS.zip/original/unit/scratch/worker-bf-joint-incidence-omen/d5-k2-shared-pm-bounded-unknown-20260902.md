# D5 shared-PM pool probe: (K=2,n=13) remains unresolved

## Decision target

Test the single bounded target

\[
\begin{array}{c}
\text{one common simple cubic 5-pole of order 13,}\
\text{two perfect-matching slots in every singleton/triple boundary class,}\
\text{all 40 positive Case-XII cells, no finite-pool (A), and all five}\
\text{four-of-five D5 joins empty.}
\end{array}
\]

The pool vectors are proper perfect matchings of the same graph variables;
the six vectors selected for each positive cell satisfy exact proper-edge
load two.  The five D5 no-join constraints quantify every (2^5) singleton
slot tuple and require at least one retained cell to have no triple-slot
completion.  Thus this is a common-incidence strengthening, not a
support-only or aggregate-load model.  Graph-level extra perfect matchings,
forbidden support, (A), and joins are checked lazily if a candidate is
found.

## Omen run

Source hashes:

```text
synthesize_exact40_joinfree_pool.py  732a4aa61ea6d4f184921e18ff42fb685651bfb48d7ca48295e0d27a692ff2a4
synthesize_exact40_shared_pool.py     5e5d89d21829eacbde35b654c677648196c54a5b3525b7e840c520d5e969f9d5
```

Command (host `omen`, detached `tmux`, 4 GiB virtual-memory limit):

```text
python3 -u worker-bf-joint-incidence-omen/synthesize_exact40_joinfree_pool.py \
  --n 13 --pool-size 2 --max-rounds 4 --timeout-ms 600000 \
  --json [local archival reference]
```

The first solver check ran for 600.028 s and returned:

```json
{"elapsed_s": 600.0280740261078, "rounds": [], "status": "unknown"}
```

No model was produced, so no full-PM evaluator or CEGAR round was entered.

## Four-value decision

* `bounded_unsat`: **not obtained**;
* common-incidence SAT candidate / real exact-40 counterexample: **not obtained**;
* status: **unknown under the stated 600 s bounded check**.

This run changes no mathematical claim.  In particular, it neither proves
the D5 four-column join nor supplies a real pole with all joins empty.  The
previous (K=1) bounded UNSAT and this (K=2) timeout cannot be combined
into an all-(K) statement.

Raw Omen result and log are in
`omen-joint-incidence-d5-k2-n13-rerun-20260902/`.
