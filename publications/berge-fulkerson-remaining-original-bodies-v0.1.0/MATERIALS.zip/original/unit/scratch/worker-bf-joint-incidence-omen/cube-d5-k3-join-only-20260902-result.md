# Omen finite-cube D5 join-only pulse (2026-09-02)

## Decision target

This run tests the finite complete-cube/common-incidence relaxation at
nominal order (n=13), cube dimension (K=3).  It keeps the exact positive
Case-XII support (the 15 (S\)--(S) cells and 25 (S\)--(T) cells), excludes
all (T)-loops and (T\)--(T) cells, and imposes all five empty four-of-five
(D_5) joins.  Unlike the earlier no-(A) run, it does **not** impose the
finite-cube (A=(12345)) blocker.

The pre-registered discriminator was:

* SAT: the D5 empty-join constraints can coexist with positive/negative
  Case-XII support in this finite common-family model;
* bounded UNSAT: the D5 empty-join constraints already conflict with that
  support, independently of the (A)-blocker;
* unknown: this bounded model remains unresolved.

This is not a real-pole theorem.  The symbolic cube has no common simple
cubic five-pole or complete perfect-matching closure.

## Reproduction on Omen

Source:

```text
cube_symbolic_d5_k3.py
SHA-256 8d40a11fdcba4e62952a7c647981204f1e839a89c6d184b482e7fa448e90b751
```

The byte-identical source was run on host `omen` in detached tmux session
`d5_cube_join_only_20260902`, with a 4 GiB virtual-memory limit:

```text
python3 -u cube_symbolic_d5_k3.py --K 3 --n 13 --timeout-ms 300000 \\
  --json cube_k3_join_only.json
```

The run took 175.1585 s to build the model and returned:

```json
{
  "K": 3,
  "assertions": 53333,
  "build_s": 175.15854620933533,
  "n": 13,
  "pool_no_a": false,
  "relation_count": 20480,
  "status": "bounded_unsat"
}
```

Local copies of the Omen artifacts:

* `cube-d5-k3-join-only-20260902-result.json`, SHA-256
  `dae250b541a82280e3a010b7485ec0f8c1be736a9b9ba63de42a03c005d7117f`;
* `cube-d5-k3-join-only-20260902-run.log`, SHA-256
  `8592f625bb75da5696fdd6f2b516da15651bd50b8e2ac8abb73a7a061551831d`.

## Four-value decision

## Later承重点 correction (2026-09-02)

The `bounded_unsat` result above must not be credited to the five D5
no-join constraints.  A follow-up Omen run removed the entire D5 relation
cache and all `AtMost3` constraints while retaining only the shared
per-boundary-class trivalent labels and the exact positive/negative support.
It returned `bounded_unsat` already at `K=1` and `K=3`; an irreducible
six-cell lambda-only core is recorded in
`cube-lambda-support-only-20260902-result.md`.

Thus the K=3 result is a strict boundary of the strengthened
shared-`lambda` model, not evidence for a D5 join.  A real pole may contain
multiple matchings in one boundary class with different local edge labels,
so the shared-`lambda` premise is not available in Case XII.  The D5
common-incidence implication remains undecided.

The original text below is retained as the contemporaneous pre-correction
interpretation; the correction controls the mathematical meaning of this
record.

The (K=3,n=13) finite complete-cube model is **bounded UNSAT even with the
finite (A)-blocker removed**.  The follow-up lambda-only check shows that
this status is already forced by the shared-label/support layer; the
sentence in the contemporaneous interpretation that attributes the conflict
to the five D5 empty joins is therefore superseded.

This strengthens the earlier finite-cube (K=3) no-(A) result only at the
model level: it does not imply the D5 join for a real cubic five-pole, because
actual perfect-matching fibres need not be complete cubes and the model omits
global graph gluing and matching closure.  It says nothing about larger cube
dimension or arbitrary matching fibres.  No order or dimension escalation is
justified by this pulse.
