#!/usr/bin/env python3
"""Audit the fixed Note-071 pole against two necessary Case-XII interfaces.

This reads the frozen Note-071 verifier and Note-074 classification.  It does
not enumerate or modify graphs.  The two checks are:

* every proper one/two-edge cut has the form allowed by Note 019;
* every one of the 28 concrete Note-074 gates has an edge-overloaded target.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from collections import Counter
from itertools import combinations, product
from pathlib import Path


IDENTITY_TO_PM = {
    "a1": 33,
    "a2": 16,
    "a4": 24,
    "a5": 0,
    "x": 2,
    "y": 12,
    "z": 10,
}


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location("note071_frozen", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_first_json(path: Path):
    value, _ = json.JSONDecoder().raw_decode(path.read_text(encoding="utf-8"))
    return value


def components(vertices, edges, removed=frozenset()):
    adjacency = {vertex: [] for vertex in vertices}
    for edge in edges:
        if edge in removed:
            continue
        u, v = edge
        adjacency[u].append(v)
        adjacency[v].append(u)
    unseen = set(vertices)
    result = []
    while unseen:
        seed = min(unseen)
        unseen.remove(seed)
        part = {seed}
        stack = [seed]
        while stack:
            vertex = stack.pop()
            for neighbour in adjacency[vertex]:
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    part.add(neighbour)
                    stack.append(neighbour)
        result.append(frozenset(part))
    return tuple(sorted(result, key=lambda part: (len(part), min(part))))


def cut_record(cut, parts, proper, terminals):
    records = []
    for part in parts:
        internal = tuple(edge for edge in proper if set(edge) <= part)
        terminal_set = tuple(sorted(part & terminals))
        records.append({
            "order": len(part),
            "terminals": terminal_set,
            "terminal_count": len(terminal_set),
            "internal_edges": len(internal),
            "cycle_rank": len(internal) - len(part) + 1,
            "vertices": tuple(sorted(part)),
        })
    small_tree = any(
        (item["terminal_count"], item["order"], item["internal_edges"], item["cycle_rank"])
        in ((1, 1, 0, 0), (2, 2, 1, 0))
        for item in records
    )
    return {
        "cut": tuple(sorted(cut)),
        "components": records,
        "note019_allowed": len(parts) == 2 and small_tree,
    }


def concrete_gates(note074):
    gates = []
    for six_set in note074["six_subsets"]:
        if six_set["minimum_additional_rows"] != 4:
            continue
        for solution_index, solution in enumerate(six_set["minimum_solutions"]):
            cell_choices = product(*(row["allowed_cells"] for row in solution))
            for choice_index, cells in enumerate(cell_choices):
                gates.append({
                    "omitted": six_set["omitted"],
                    "solution_index": solution_index,
                    "choice_index": choice_index,
                    "targets": tuple(tuple(row["singleton_quadruple"]) for row in solution),
                    "cells": tuple(cells),
                })
    assert len(gates) == 28
    return tuple(gates)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--note071-verifier", type=Path, required=True)
    parser.add_argument("--note074-json", type=Path, required=True)
    args = parser.parse_args()

    note071 = load_module(args.note071_verifier)
    note074 = read_first_json(args.note074_json)
    vertices = frozenset(range(39))
    proper = tuple(note071.PROPER)
    terminals = frozenset(edge[0] for edge in note071.SEMIEDGES)

    bridges = []
    for edge in proper:
        parts = components(vertices, proper, frozenset((edge,)))
        if len(parts) > 1:
            bridges.append(cut_record((edge,), parts, proper, terminals))

    two_cuts = []
    for cut in combinations(proper, 2):
        parts = components(vertices, proper, frozenset(cut))
        if len(parts) > 1:
            two_cuts.append(cut_record(cut, parts, proper, terminals))

    vectors = {label: note071.lift_matching(label) for label in IDENTITY_TO_PM.values()}
    gates = concrete_gates(note074)
    target_cache = {}
    gate_records = []
    for gate_index, gate in enumerate(gates):
        targets = []
        for quadruple, cell in zip(gate["targets"], gate["cells"]):
            if quadruple not in target_cache:
                labels = tuple(IDENTITY_TO_PM[name] for name in quadruple)
                overloaded = tuple(
                    edge for edge in proper
                    if sum(edge in vectors[label] for label in labels) >= 3
                )
                target_cache[quadruple] = {
                    "quadruple": quadruple,
                    "pm_labels": labels,
                    "overloaded_edges": overloaded,
                }
            targets.append({**target_cache[quadruple], "cell": cell})
        blocked = tuple(target for target in targets if target["overloaded_edges"])
        gate_records.append({
            "gate_index": gate_index,
            "omitted": gate["omitted"],
            "solution_index": gate["solution_index"],
            "choice_index": gate["choice_index"],
            "blocked_target_count": len(blocked),
            "gate_blocked_by_overload": bool(blocked),
            "targets": targets,
        })

    invalid_two_cuts = tuple(record for record in two_cuts if not record["note019_allowed"])
    unblocked_gates = tuple(
        record for record in gate_records if not record["gate_blocked_by_overload"]
    )
    cut_profile = Counter(
        tuple(sorted((part["terminal_count"], part["order"]) for part in record["components"]))
        for record in two_cuts
    )
    result = {
        "order": len(vertices),
        "proper_edges": len(proper),
        "terminals": tuple(sorted(terminals)),
        "proper_bridges": bridges,
        "proper_two_edge_cut_count": len(two_cuts),
        "proper_two_edge_cuts": two_cuts,
        "proper_two_edge_cut_profile": tuple(
            {"component_terminal_order_pairs": profile, "cut_count": count}
            for profile, count in sorted(cut_profile.items(), key=str)
        ),
        "invalid_note019_two_edge_cuts": invalid_two_cuts,
        "case_xii_cut_boundary_passes": not bridges and not invalid_two_cuts,
        "distinct_note074_target_quadruples": len(target_cache),
        "overloaded_distinct_targets": sum(
            bool(record["overloaded_edges"]) for record in target_cache.values()
        ),
        "note074_gate_patterns": 8,
        "concrete_cell_choices": len(gates),
        "overload_blocked_concrete_gates": len(gates) - len(unblocked_gates),
        "unblocked_concrete_gates": unblocked_gates,
        "gate_records": gate_records,
        "target_records": tuple(target_cache[key] for key in sorted(target_cache)),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    assert not bridges
    assert len(two_cuts) == 5 and not invalid_two_cuts
    assert len(gates) == 28
    assert len(target_cache) == 20
    assert sum(bool(record["overloaded_edges"]) for record in target_cache.values()) == 15
    assert Counter(record["blocked_target_count"] for record in gate_records) == {
        2: 4,
        3: 16,
        4: 8,
    }
    assert not unblocked_gates
    print("NOTE071_CASE_XII_CUT_AND_NONOVERLOAD_GATE_AUDITED")


if __name__ == "__main__":
    main()
