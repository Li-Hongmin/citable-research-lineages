# The precise Case-XII proper-two-cut boundary does not force a nonoverloaded Note-074 gate

The order-\(39\) girth-five pole of Note 071 satisfies every small-cut
restriction that Note 019 proves for a genuine Case-XII side, but every one
of the eight optimal three-distinct-extension gates of Note 074 is still
blocked at the first condition of Note 078.  Thus girth five, bridge-freeness,
and the precise admissible form of every proper \(2\)-edge-cut do not force a
nonoverloaded singleton-reuse gate.

## Proper cuts

Use the vertex numbering of the frozen Note-071 voltage-lift certificate.
The terminal vertices are

\[
 0,3,6,9,12.
\]

Deleting any single proper edge leaves the proper core connected.  There are
exactly five proper \(2\)-edge-cuts:

\[
\begin{aligned}
 &\{(0,30),(0,33)\},&&\{(3,24),(3,27)\},
 &&\{(6,27),(6,30)\},\\
 &\{(9,21),(9,36)\},&&\{(12,18),(12,21)\}.
\end{aligned}
\]

Each cut isolates the displayed terminal vertex.  The isolated component
has one vertex, one terminal, no internal proper edge, and cycle rank zero.
The complementary component has \(38\) vertices, the other four terminals,
\(54\) internal proper edges, and cycle rank \(17\).  Hence every proper
\(2\)-edge-cut cuts off exactly the one-vertex terminal \(3\)-pole tree
allowed by Note 019.  No two-vertex terminal \(4\)-pole tree occurs, and no
other proper \(2\)-edge-cut exists.

## The three-distinct nonoverload gates

Use the actual perfect-matching identities fixed in Note 074,

\[
 a_1=33,\quad a_2=16,\quad a_4=24,\quad a_5=0,
 \quad x=2,\quad y=12,\quad z=10.
\]

For each target singleton quadruple \(P_1,P_2,P_3,P_4\), the calculation
tests all \(56\) proper edges of the lifted pole for

\[
 \sum_{i=1}^4\chi_{P_i}(e)\geq3.
\]

There are \(20\) distinct target quadruples across the eight optimal row
patterns and their \(28\) concrete cell choices.  Fifteen of the \(20\) are
overloaded.  More importantly, every concrete gate contains an overloaded
target.  The number of overloaded targets in one four-row gate has
distribution

\[
 2^{\,4},\qquad 3^{\,16},\qquad 4^{\,8},
\]

where the exponent counts concrete gates.  Thus all \(28\) gates fail the
edge-nonnegativity condition \(D(e)=2-\sum_i\chi_{P_i}(e)\geq0\) from
Note 078.  The choice between cells separated by a slash in Note 074 does
not affect this obstruction, because it does not change the singleton
quadruple.

This is also transparent from the voltage lift: every designated lifted
matching has the same incidence column on each lift of a base edge as its
base matching.  A base overload therefore appears on all three lifted
copies.  The calculation nevertheless checks the \(39\)-vertex lifted edge
sets directly.

## Consequence and scope

The implication

\[
\begin{gathered}
\text{simple connected bridge-free cubic \(5\)-pole of girth five}\\
+\ \text{every proper \(2\)-cut is a Note-019 terminal-tree cut}\\
+\ \text{the fixed failed-pivot rows of Note 071}
\end{gathered}
\Longrightarrow
\text{some Note-074 gate is edge-nonoverloaded}
\]

is false.  In particular, the exact small-cut information presently
inherited by a minimum Case-XII side does not repair the nonoverload failure
of Note 071.

This is not an exact-Case-XII pole and therefore is not a counterexample to
the remaining Case-XII statement.  A positive proof must use information
beyond the Note-019 local cut boundary, such as the complete positive-cell
family, the global absence of \(T\)-loop and \(T\)--\(T\) support, or a
strictly stronger whole-graph irreducibility consequence.

## Reproduction

The standard-library verifier is
`audit_note071_case_xii_cut_and_nonoverload_gate.py` in this directory.  It
reads only the frozen Note-071 verifier and Note-074 classification JSON.
The one-process Omen run was

```bash
cd [local archival reference]
ulimit -v 524288
/usr/bin/time -v python3 audit_note071_case_xii_cut_and_nonoverload_gate.py \
  --note071-verifier girth-five-failed-pivot-residual-selector-counterexample/verify_girth5_voltage_lift_counterexample.py \
  --note074-json omen-run.json \
  > result.json 2> run.log
```

It exited zero in \(0.13\) seconds with maximum RSS \(12{,}544\) KB.  The
final marker is

```text
NOTE071_CASE_XII_CUT_AND_NONOVERLOAD_GATE_AUDITED
```
