# Fixed-row paired-switch connectivity fails

The companion-alignment interface in
[Note 073](073-local-trivalent-incidence-does-not-force-the-six-singleton-gate.md)
cannot be supplied by a general connectivity theorem for the witnesses of one
BF boundary cell.  A connected simple bipartite cubic 5-pole of order nine
has a fixed cell whose three actual six-perfect-matching witnesses are three
isolated vertices under synchronous proper-cycle switches.

More generally, fixed-boundary witnesses in a bipartite 5-pole carry a
\(\mathbb Z_2\)-valued Kempe-class invariant.  The same construction can be
relabelled to each of the three target cells in Note 073.  It has forbidden
support outside exact Case XII, so the exact-Case-XII restricted problem
remains open.

## A boundary-fixed Kempe invariant

Let the internal graph of a cubic 5-pole be bipartite, with ordered parts
\(X,Y\).  Fix the boundary set of each of six ordered perfect matchings.
After deleting from \(X\) and \(Y\) the vertices matched to semiedges, the
proper edges of a matching \(M_i\) define a bijection between two fixed
ordered sets.  Let \(\epsilon(M_i)\in\{+1,-1\}\) be its sign and put

\[
 \kappa(W)=\prod_{i=1}^{6}\epsilon(M_i).            \tag{1}
\]

If matching occurrences \(i,j\) are synchronously toggled on a proper
alternating cycle of length \(2k\), both partial-bijection signs are
multiplied by \((-1)^{k-1}\).  Consequently

\[
 \kappa(W')=\kappa(W).                              \tag{2}
\]

Changing the orders on \(X,Y\) multiplies every witness in the fixed ordered
cell by the same constant.  Separation by \(\kappa\) is therefore intrinsic:
witnesses with opposite values cannot lie in the same paired-switch class.

## An order-nine cubic 5-pole

Take vertices \(0,\ldots,8\), semiedges at \(0,1,2,3,4\), and proper edges

\[
\begin{split}
 &(0,2),(0,3),(1,5),(1,6),(2,4),(3,8),\\
 &(4,7),(5,7),(5,8),(6,7),(6,8).
\end{split}                                        \tag{3}
\]

This is a connected simple cubic 5-pole.  Denote the proper edges in (3) by
\(e_0,\ldots,e_{10}\) and the semiedge at terminal \(i\) by \(s_i\).  The
following six perfect matchings occur:

\[
\begin{array}{c|l}
A&e_0,e_{10},e_7,s_2,s_4,s_5\\
A'&e_0,e_8,e_9,s_2,s_4,s_5\\
B&e_1,e_3,e_6,e_8,s_3\\
B'&e_1,e_{10},e_2,e_6,s_3\\
C&e_2,e_4,e_5,e_9,s_1\\
C'&e_3,e_4,e_5,e_7,s_1.
\end{array}                                        \tag{4}
\]

The cell \([13]=((13),(13))\) has exactly the three actual witnesses

\[
 (A,A,B,B,C,C),\qquad
 (A,A',B',B,C,C'),\qquad
 (A',A',B',B',C',C').                              \tag{5}
\]

Each proper edge and each semiedge has total load two in every row of (5).
No synchronous toggle of two occurrences on one proper alternating-cycle
component moves between distinct rows.  Thus the paired-switch graph has
three vertices, no edges, and component sizes \((1,1,1)\).  The pole has
exact Tait state set

\[
 S=\{13,14,24,25,35\}.
\]

All assertions in (3)--(5), including complete enumeration of the 22 perfect
matchings and all witnesses in \([13]\), are checked by the
[independent verifier](../computations/bundles/order-nine-paired-switch-disconnected-cell/README.md).

## The same obstruction in the target cells

The construction has a transparent bipartite form.  Start with a path
\(p-q-r\), delete \(pq\), delete one edge \(L_0R_0\) of a disjoint
\(K_{3,3}\), and add \(pR_0,L_0q\).  Place the terminals as follows:

\[
\begin{array}{c|c|c|c}
\text{cell}&\text{at }p&\text{at }q&\text{at }r\\ \hline
(35,23)&\{3,4\}&\{1\}&\{5,2\}\\
(13,34)&\{3,5\}&\{2\}&\{1,4\}\\
(35,12)&\{3,1\}&\{4\}&\{5,2\}.
\end{array}                                        \tag{6}
\]

On the \(K_{3,3}\) part, one witness uses the six permutations

\[
 012,012,120,120,201,201,
\]

and another uses

\[
 012,021,102,210,120,201.
\]

Their six partial-bijection signs are respectively

\[
 (-,-,+,+,+,+),\qquad(-,+,-,-,+,+),
\]

so their \(\kappa\)-values are opposite.  This gives disconnected fixed-cell
witness classes in each of the three cells required by Note 073.

## Exact remaining interface

For a fixed ordered cell \(b\), let \(\Omega_b\) be its actual BF witnesses,
\([W]_K\) the paired-switch class of a transported witness \(W\), and
\(\Omega_b(\tau)\) the witnesses containing a prescribed singleton tuple
\(\tau\).  Paired switches achieve the prescribed companion alignment
exactly when

\[
 [W]_K\cap\Omega_b(\tau)\ne\varnothing.             \tag{7}
\]

Connectivity of \(\Omega_b\) would remove only the class obstruction, and
only after \(\Omega_b(\tau)\ne\varnothing\) were known.  Notes
[055](055-half-load-column-saturation-and-case-xii-compression.md),
[057](057-overlap-cells-transport-singleton-fibres-into-d5.md), and
[074](074-three-distinct-extensions-require-four-witness-reuse-rows.md)
provide neither assertion.

The example has \(T\)-loop support, so it does not refute fixed-row
connectivity under the full exact-Case-XII exclusions.  It proves that any
positive theorem in that setting must use those exclusions to eliminate the
Kempe-class obstruction (1), rather than rely on cubicity, exact Tait set, or
ordinary perfect-matching closure alone.
