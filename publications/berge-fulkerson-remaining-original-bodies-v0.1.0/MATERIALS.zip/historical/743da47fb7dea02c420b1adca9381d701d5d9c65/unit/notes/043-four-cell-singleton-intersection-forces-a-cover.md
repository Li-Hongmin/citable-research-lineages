# Four fixed-singleton cells already force an \(A\)-cover

This note sharpens the remaining common-incidence interface for the
Case-XII support.  It does not prove that the interface is realizable in a
general cubic 5-pole.

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

For \(s\in S,t\in T\), let \(\Pi_{s,t}\) be the set of five-tuples
\((P_1,\ldots,P_5)\) of actual singleton-boundary perfect matchings for
which there exist actual triple-boundary matchings \(Q_s,Q_t\) satisfying

\[
\chi_{Q_s}+\chi_{Q_t}
 +\sum_{i\in s}\chi_{P_i}
 +\sum_{i\in t}\chi_{P_i}=2\mathbf 1.
\tag{1}
\]

If \(s\cap t\ne\varnothing\), the same \(P_i\) is used for both occurrences
in (1).  This is stronger than ordinary support, which may use two
different singleton matchings in the repeated position.

## The four-cell lemma

Consider

\[
\mathcal C_4=
\{(13,12),(13,45),(24,15),(25,34)\}.
\tag{2}
\]

The unions \(s\cup t\) over these four cells contain every three-element
subset of \([5]\).  Suppose that

\[
 (P_1,\ldots,P_5)\in
 \bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}.
\tag{3}
\]

For any proper edge \(e\), (1) implies that the singleton load contributed
by the \(P_i\)'s in that cell is at most two.  If three distinct
\(P_i,P_j,P_k\) all contain \(e\), choose a cell in (2) whose endpoint union
contains \(\{i,j,k\}\); its singleton load would be at least three, a
contradiction.  Hence

\[
 \sum_{i=1}^5\chi_{P_i}(e)\le2
\qquad\text{for every edge }e.
\tag{4}
\]

At each internal cubic vertex the five singleton matchings contribute total
load five over three incident edges.  Together with (4), the three local
loads are \((2,2,1)\).  The load-one edges therefore form a perfect
matching; every semiedge has load one because \(P_i\) uses only semiedge
\(i\).  Consequently these five singleton matchings and the load-one
matching form an actual \(A=(12345)\) Berge--Fulkerson cover.

Thus

\[
\boxed{
\bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}\ne\varnothing
\quad\Longrightarrow\quad
A=(12345).
}
\tag{5}
\]

Four cells are minimal for this direct endpoint-union argument: no one,
two, or three \(S\)-\(T\) cells have unions containing all ten
three-subsets of \([5]\).

## Exact remaining interface

The Case-XII support hypothesis asserts only that each ordinary
\(S\)-\(T\) cell has some six-matching completion.  It does not imply that
\(\Pi_{s,t}\) is nonempty, because repeated singleton slots may use
different matchings; nor does it imply that the four nonempty projections
in (2) intersect.  Therefore the unresolved statement can be written as

\[
\boxed{
\text{exact Case-XII support and no \(A\)}
\Longrightarrow
\bigcap_{(s,t)\in\mathcal C_4}\Pi_{s,t}=\varnothing.
}
\]

Equivalently, an exclusion proof must derive a cross-cell singleton
consistency theorem, or use a different consequence of the common cubic
vertex incidence.  Existing abstract load, route, exchange, and positive
support models do not supply this quantifier exchange.

The frozen order-13 all-SS pole has all 25 ordinary \(S\)-\(T\) cells but
is not exact-\(S\); its four projection sizes are
\((25,96,96,72)\) and their intersection is empty.  This is a real boundary
showing that cellwise support and common perfect-matching incidence alone do
not establish (3).

## Certificate

The local check is reproduced by:

    python3 units/berge-fulkerson/scratch/worker-real-exact-s-no-a/four_cell_common_singleton_interface.py

The terminal marker is FOUR_CELL_COMMON_SINGLETON_INTERFACE_OK.  The
certificate checks the endpoint-cover minimality and the two frozen real
pole boundary cases; it does not claim the general intersection.
