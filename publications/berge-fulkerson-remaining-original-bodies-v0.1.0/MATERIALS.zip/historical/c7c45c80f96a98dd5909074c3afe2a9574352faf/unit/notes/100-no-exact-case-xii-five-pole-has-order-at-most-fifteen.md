# No exact Case-XII five-pole has order at most fifteen

There is no simple connected cubic five-pole of odd order at most \(15\),
with five distinct terminal vertices and bridgeless proper-edge graph, whose
complete Berge--Fulkerson boundary support is exactly the forty types of
Case XII.  Consequently, if a real exact-Case-XII pole exists in this class,
then its order is at least \(17\).

Here ``exact Case XII'' means that the complete perfect-matching closure has
all fifteen \(S\)--\(S\) types and all twenty-five \(S\)--\(T\) types, and has
no all-terminal type, no \(T\)-loop, and no \(T\)--\(T\) type.  No assumption
on the Tait-state set is used as a preliminary filter.

## Exhaustive order-fifteen census

Represent a five-pole by adjoining one apex to its five semiedges.  The
result is a simple graph on sixteen vertices with degree sequence
\((5,3^{15})\); conversely, deleting the unique degree-five vertex recovers
the pole and its five distinct terminal incidences.  Unlabelled generation
with

```text
geng -q -c -d3 -D5 16 25
```

produced \(922{,}347\) connected augmented graphs.  Exactly \(89{,}064\)
had degree sequence \((5,3^{15})\).  After deleting the apex, \(86{,}577\)
had connected proper core and \(69{,}243\) also had no proper-edge bridge.

For every one of these \(69{,}243\) poles, the computation independently
enumerated its complete family of perfect matchings.  It then enumerated all
six-matching multisets with edge load exactly two, classified their boundary
types, and canonicalised the five terminal labels under all permutations.
None had exact Case-XII support.  The candidate list is empty.

The search does not first require the Tait states to form a particular
pentagon.  This is essential: the Case-XII definition concerns the complete
BF boundary support, and the negative \(A\) and \(T\)--\(T\) conditions are
checked on that same complete closure.

## Completeness and reproduction

The order-fifteen wrapper changes only the order parameter of the same
streaming scanner used for the lower-order census.  The completed Omen run
reported

```text
ORDER15_EXACT40_CENSUS_OK
EXIT_STATUS=0
```

after \(1016.245572\) seconds.  Its decisive hashes are

```text
all generated graph6 stream:
742ad906e2ece9d8828d513cf1a790c015c653d9de2fc916ace51ef3d8a399dc

connected proper-core graph6 stream:
6fe15a6e0c7569d764811201a74ff1bbd1b32f68e88d8a446b94288696950ed9

proper-bridgeless classified records:
6d4fa421e3a84e3bcc7c7c4c8268322809ff8d4af6593e6ac96ab3e1a38218e5

result JSON:
c0badaf56a5d6998e39051160940f7722513df3b13fdebbd39135e325c7b564d
```

The frozen source, log, and JSON are presently in
`scratch/worker-bf-order15-exact40-census/`.  The Omen copy is
`[historical local reference]`.

For lower odd orders, [Note 005](005-pentagon-selection-is-false-and-a-weaker-transversal-survives.md)
exhausts every exact-\(S\) pole through order thirteen and finds an
all-terminal BF cover in each one.  Exact Case-XII support implies exact
Tait set \(S\): every supported \(S\)-loop supplies its Tait state, while
doubling a Tait colouring in a \(T\)-state would produce a forbidden
\(T\)-loop.  Hence Note 005 excludes exact Case XII through order thirteen.
Combining it with the order-fifteen empty candidate list proves the stated
lower bound \(n\ge17\).

## Boundary of the result

This is a finite nonexistence theorem, not a proof that Case XII is
impossible at arbitrary order.  It does not establish the dependent
two-splice fibre of [Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md),
and it does not justify an order-seventeen scan.  Its role is to remove every
real counterexample through order fifteen from the remaining full-PM-closure
problem.
