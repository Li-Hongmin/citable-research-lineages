> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Square splicing with terminals outside the square edges

2026-10-03. Self-contained private contribution candidate. This makes explicit a generalization of the tree-switch proof in project Note 458. It claims no new priority and is not a proof of Barnette's conjecture. Same-model independent-context review is distinct from external review.

## Statement

Let \(H\) be a finite simple graph and \(F\) a spanning subgraph with degree one exactly at a terminal set \(T\), degree two at every other vertex, and \(|T|\in\{0,2,4\}\). For each \(i\) choose four distinct vertices \(h_i,x_i,y_i,j_i\); assume these four-vertex supports are pairwise disjoint and

\[
h_ix_i,y_ij_i\in E(F),\qquad
e_i=x_iy_i\in E(H)\setminus E(F),\qquad h_ij_i\in E(H).
\]

Put \(E=\{e_i\}\). Assume \(F\cup E\) is connected. Then \(H\) has a spanning subgraph obtained only by square switches

\[
\{h_ix_i,y_ij_i\}\longmapsto\{h_ij_i,x_iy_i\},
\]

which is (i) one Hamilton cycle if \(|T|=0\); (ii) one spanning path with endpoints \(T\) if \(|T|=2\); or (iii) a two-path spanning cover with endpoints \(T\) if \(|T|=4\). In case (iii) two distinct terminal pairings are obtainable.

Every edge of \(F\) outside the set of the displayed removable rails \(\{h_ix_i,y_ij_i\}\) is retained. In particular, prescribed matching edges or root anchors disjoint from the rails are protected. There is no condition \(T\subseteq\{x_i,y_i\}\), no cycle-base assumption, and no planarity or bipartiteness assumption.

## Proof

The components of \(F\) are cycles and exactly \(|T|/2\) paths. Contract these components and retain one quotient edge for each \(e_i\), allowing loops. Call the connected quotient \(Q\). If \(e_i\) is a nonloop, its endpoints are in different current components, with \(h_ix_i\) and \(y_ij_i\) respectively in those two components. The chord \(h_ij_i\) cannot already be in the current subgraph, since it would connect them. The square switch therefore produces a simple spanning subgraph with the same degree at each vertex.

Cutting one edge in each of two cycles and joining crosswise produces one cycle. Cutting one edge in a path and one in a cycle produces one path with the same endpoints. Cutting one edge in each of two paths produces two paths with a different terminal pairing: the two halves of each original path now join halves of the other. These statements also hold when a removed rail meets a terminal, leaving a one-vertex half-path. Supports are disjoint, so switches at other supports change none of the rails or added chords under consideration.

For zero terminals, take a spanning tree of \(Q\), choose one cycle component as root, and absorb all other cycles along its tree edges. At each step a tree edge joins the growing cycle to one as-yet-unabsorbed subtree component. Only cycle-cycle switches occur, leaving one spanning cycle.

For two terminals, root a spanning tree at the unique path component and absorb cycles by the same argument. This leaves one spanning terminal path.

For four terminals, \(F\) initially has exactly two path components. Take a spanning tree of \(Q\) and choose an edge \(e_*\) on the tree path joining them. Removing \(e_*\) leaves two subtrees, each rooted at one path component. Absorb every cycle in each subtree into its rooted path, without using \(e_*\). This gives a spanning two-path cover. The support of \(e_*\) is untouched, and its endpoints lie on the two different resulting paths. Applying its switch produces another spanning two-path cover with a different pairing. All switches remove only the specified rails, which proves the protection statement. \(\square\)

The same statement applies separately to every connected component \(X\) of \(F\cup E\) with 0, 2 or 4 terminals: any support incident with an \(e_i\) inside \(X\) lies wholly in \(X\), because its rails belong to \(F\). Terminal counts in such components are even since they are unions of \(F\)-paths and cycles. No quotient-degree parity assumption is required.

An explicit illustration is \(F=(a,b,c,d)\dot\cup(e,f,g,h)\), with added edges \(cf,bg\). Use the square support \((b,c,f,g)\), removable rails \(bc,fg\), and \(E=\{cf\}\). All terminals \(a,d,e,h\) lie outside the endpoints of E. The quotient has two vertices and one edge, so both quotient degrees are odd. Switching gives paths \((a,b,g,h)\) and \((d,c,f,e)\), changing \((a,d)(e,h)\) into \((a,h)(d,e)\). Thus neither the old terminal restriction nor an Eulerian quotient is necessary for this generalized result.

## Application interface

Note 914's local opening supplies an \(F\) of this exact degree pattern. At each complete two-special leaf the four consecutive old-word vertices are \(h_i,x_i,y_i,j_i\), its old edge \(x_iy_i\) has been deleted, its two rails survive, and its ordinary leaf chord \(h_ij_i\) exists. Distinct leaf intervals give disjoint supports. Restoring only these deleted leaf edges gives precisely the component quotient used in that proof. All terminal positions, including those directly assigned to the marked nodes, are therefore allowed. Face matching edges are not removed rails, and root trap paths lie outside the leaf supports.

Note 458's formal theorem restricts terminals to endpoints of the deleted leaf edges. Its proof supplies the tree mechanism above, but its statement cannot literally be invoked for the direct marked terminals of Note 914. This lemma resolves that formal applicability gap, conditional on the stated supports and degree pattern. It neither proves the local opening's component classification nor bypasses the exterior closure hypotheses.

## Verification and limitations

The proof is analytic and has no finite computation dependency. Reproduction consists of the three local switch cases and the spanning-tree construction. The independent-context reviewer assessed the generalization and found no substantive counterexample; this is same-model review, not different-source verification. General overlapping supports are not covered: disjointness is what prevents an earlier switch from deleting a later rail. No claim is made about arbitrary four-port networks or general Barnette graphs.
