> Archival public projection. This source records a historical research checkpoint; its mathematical claims remain unreviewed. Current Li Hongmin attribution, CC BY 4.0 permission, disclosed AI roles, corrections and unbundled premises are in the package rights/versions/dependencies files. Historical pending-publication wording is retained as historical status.

# Barnette 上游接口有界检查

范围：只核对 Notes 176、403、404、410、458、773、914 的图模型与接口；无计算、无外部检索、原 unit 未写入。本次为同模型新上下文检查，**不是异源外审**。

## 判定

实际 Hamilton 平面图足以提供所需的两侧 Jordan 盘、普通弦层状性及条件性的叶片方形支撑。**恰两 ordinary roots 与 B 次序不能提供 914 的全部特殊位点 profile。** 914 在首段明写该 profile，因此下面的反例不否定它的条件定理；它否定把该定理自动用于所有 root2/B 开圈的上游推理。

另一个真实接口是：458 正式定理要求终端属于被删叶边端点，914 的终端可以位于标记直接位点。literal 引用不成立，但其商图树换边证明有不依赖该限制的严格推广，故这是需要明写的引理缺口，而非所见实质反例。

## 哪些确实自动成立

1. Hamilton 圈 C 是 Jordan 曲线。共同 site 面完全位于 C 的一个补盘中；两 site matching edges 在该盘中。所有后来称为 face-side 的 matching edges 也在这个盘中，互不交叉。这里是**同一侧盘**，不意味着全部这些边都位于 site 的那一个实际面边界上。
2. 三边选定 facial arc 与 Note 176 的 cyclic order 使 alpha-beta 封闭的 C 子段恰为陷阱。六边形无内部弦时 a,b,c,d 的四条 matching 必须都出陷阱，并且在反侧盘：任何 face-side 出边均与 alpha-beta 交错。反侧不交叉强制主段的 targets 顺序为 t_d<t_c<t_b<t_a。
3. 以 Note 410 的定义，ordinary edges 是主段内剩下的反侧 matching。它们不可能严格包住任一 trap target：若 i<t<j，则 ordinary edge ij 与从 t 连到陷阱的同侧 matching 交错。因此 trap targets 是 exposed；ordinary intervals 两两嵌套或分离，从而给出森林。此结论不需要根数为二。
4. 主段内非 ordinary matching incidences，除四个 trap targets 外，恰为 site incidences 与 face-side matching incidences。因此**分配给 ordinary 节点的** special positions 的 matching 在 face 侧。若把“全部 special”也包括四个 trap targets，则“全部同侧”字面上为假；目标排除依赖这四个指定例外在另一侧。
5. 一个实际 ordinary **leaf** 若恰接收两个 specials x,y，开区间内不含 ordinary endpoints，也无其他 specials，所以其完整 old word 正是 H,x,y,J；HJ 是 leaf chord，xy 与两 rails 都是真实 old edges。不同 leaves 的闭区间分离，四点支撑互不交。该事实不要求叶片有普通 wrappers。

在 914 的明写 profile 下，被 s,t 夹住的每个 C_i 是完整 immediate-child interval。它的 ordinary incidences 全内部；其余直接 specials 没有插在子词之间。闭合子词并恢复叶边后，若无终端分量接触不连续子词，可用 face matching 与这些子词内的 old arcs 在 face 盘形成简单连接路径（old arcs 可向盘内微推）。这条路径隔断中间整个 child gap。gap 不能接外部 matching，否则相交；接到该分量则本来就在该分量。ordinary incidences 内部，于是留下两条 old 边割。该 Jordan 分离论证不需要所有 face matching 是同一个实际面的边界，只需要同侧盘。

## 明确不是 root2/B 自动推出的条件

914 需要另行输入：四个 distinct physical terminals 在 roots 内；exposed mates r1,r2 同根且成为相邻真实 old edge；该相邻对属于一枚标记节点；另一枚节点恰有两个直接 specials；相邻边在 s,t 所夹子词弧之外；另一根 all-leaf；其余 assigned specials 各在完整 two-special leaf。B 是外部骨架次序，不控制叶的 direct-special 数、标记节点数量或位置。Note 458 的 m=f 以及恰两 assignable specials 在 roots 外也是 profile/计数条件，不能从单独的 R=2 偷渡。

## 26 点实际图：root2/B 不强制 two-special leaves

取 Hamilton 圈（下标为 0,...,25）：

```
0:w0, 1:td,
2:H1, 3:u, 4:s1, 5:s2, 6:r1, 7:J1,
8:tc, 9:z1, 10:z2, 11:tb,
12:H2, 13:r2, 14:t2, 15:t1, 16:v, 17:J2,
18:ta, 19:w*, 20:alpha, 21:a, 22:b, 23:c, 24:d, 25:beta.
```

face-side matching 为

```
(0,3), (16,19), (20,25), (6,9), (10,13), (4,15), (5,14),
```

opposite-side matching 为

```
(1,24), (8,23), (11,22), (18,21), (2,7), (12,17).
```

全部 26 个 vertices 恰匹配一次，每个 pair 下标差奇数且不相邻。两页各自的 intervals 均嵌套或分离，故给出 simple cubic bipartite plane 图。site 为 q=(0,3), p=(16,19)。共同面有残余 arc 19,20,25,0，其选定三边 facial arc 经过 alpha-beta，陷阱 old interval 20,...,25 是 chord-free hexagon。另一残余 facial arc 是 3,4,15,16。四 trap targets 为 1,8,11,18，严格呈 B 骨架：w0,td,W1,tc,z1,z2,tb,W2,ta,w*。

ordinary matching 仅有 (2,7),(12,17)，所以恰两根，且都是 leaf。W1 接收 u,s1,s2,r1 四个 direct specials；W2 接收 r2,t2,t1,v 四个 direct specials。因此“root2/B 自动使每叶 two-special”严格为假。

本图也三连通。matching chord interlacement graph 连通：alpha-beta 与四 trap escape chords 交错；q 与 (1,24),(2,7) 交错；p 与 (18,21),(12,17) 交错；(4,15),(5,14) 与 (2,7)、(8,23)、(11,22)、(12,17) 交错；(6,9) 与 (2,7),(8,23) 交错；(10,13) 与 (11,22),(12,17) 交错。因此若有 2-edge cut，Hamilton 圈强制它恰为两条 old 边，隔出一个 matching-closed proper old interval，这会把 chord interlacement graph 分离，矛盾。C 排除 bridges；simple cubic 中 2-vertex cut 会产生至多 2-edge cut（将某个删除顶点并入合适一侧），所以三连通。这是手工结构验证，不依赖枚举。

## 458 到 914 的终端推广

设 F spanning，degree 1 恰在 T，其余 degree 2；E={x_i y_i} 为未用叶边。每叶支撑 H_i,x_i,y_i,J_i 四点互异且支撑两两不交，两 rails H_i x_i,y_i J_i 在 F，HJ chord 在 G。考虑 F+E 的一个 connected component，含 0、2 或 4 个 terminals。

把其 F components 收缩为商图 Q，E 给出 edges。Q connected。0 个 terminals 时所有 F components 是 cycles；2 个时恰一 path；4 个时恰两 paths。对任何 nonloop e_i，两个 rails 分处两个 F components，HJ 不可能已在 F（否则两个端点通过 x-H-J-y 已连通）。换 rails 为 HJ,xy 能吸收 cycle 而保留 terminals；不同支撑保证以后的 rails 不被破坏。

取 Q spanning tree：0/2 terminal 分别沿树合并成 cycle/path；4 terminal 时从树中两 path roots 的连接链删除一边，分两棵树先各自吸收 cycles，再可选择是否在该 unused nonloop edge 作最后换边，给两个不同 terminal pairings。全程不要求 T 位于 E endpoints；也不要求 Q Eulerian。所有支撑外的 anchor edges/trap subpaths 都保留。因此这是充分严格的推广；914 可援引这个一般引理，不能只用 458 正式陈述代替它。

有界结论：所见上游几何没有构造出 914 的条件定理反例；需要修正的是 profile 的量词边界与 458 终端接口的正式表述。未核对 914 下游的全部具体 exterior seam 覆盖，未宣布完整 Hamilton 证明链通过。

补充：已实际读过正式文件 `barnette-general-square-splicing-lemma.md`，其正式陈述与完整证明通过本轮有界检查。终端位于 h/j 或任一 rail 端点也允许（切后单点半路径仍可拼接）；nonloop 排除已有 chord；四终端最后一次 path-path switch 确实给不同配对，分量限制与 rails 外保护边均正确。此通过仍属同模型新上下文检查，不是异源外审。
