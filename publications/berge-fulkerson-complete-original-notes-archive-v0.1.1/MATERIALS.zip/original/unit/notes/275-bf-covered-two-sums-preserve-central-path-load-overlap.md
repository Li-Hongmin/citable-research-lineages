> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BF-covered two-sums preserve central-path load overlap

Keep the central-path exterior and the two forced row templates of [Notes 271–273](273-central-path-transfer-is-a-four-slot-load-intersection.md). Let \(H_0\) be a genuine cubic five-pole with this exterior, and let \(e_0=xy\) be an unmarked proper edge strictly inside its six-port shore. Let \(J\) be a closed cubic graph with proper edge \(f=uv\). Form the two-edge sum \(H=H_0\oplus_{e_0,f}J\) by deleting \(e_0,f\) and cross-joining their endpoints. Define \(\mathcal F_{ad},\mathcal F_{ac}\) from **all actual rows with the fixed exterior templates** as in Note 273.

**Theorem.** If \(J\) has a Berge--Fulkerson cover, then
\[
\begin{aligned}
\mathcal F_t(H)\ne\varnothing
&\iff \mathcal F_t(H_0)\ne\varnothing
&& (t=ad,ac),\\
\mathcal F_{ad}(H)\cap\mathcal F_{ac}(H)\ne\varnothing
&\iff
\mathcal F_{ad}(H_0)\cap\mathcal F_{ac}(H_0)\ne\varnothing .
\end{aligned}                                                    \tag{1}
\]
This is an existence statement for four-slot shore **load vectors**. The vectors themselves acquire new coordinates inside \(J\), and no canonical lift of every matching identity is claimed.

## Proof

Every perfect matching of \(H\) uses zero or both connector edges because \(|V(J)|\) is even. Restoring the deleted edges projects it to a matching of \(H_0\) and one of \(J\) with the same distinguished-edge bit. Every actual BF row of \(H\) therefore projects to a BF row of \(H_0\) of the same exterior template. Conversely, [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md) gives a lift of **any** specified BF row of \(H_0\): order one BF cover of \(J\) so its two \(f\)-using occurrences align with the two \(e_0\)-using occurrences of the row, and splice slot by slot. This proves both row-nonemptiness equivalences.

The following pairing statement holds for any two matching occurrences \(U,W\) in a row. If their \(e_0\)-bits agree, the two connector edges are absent from \(U\triangle W\), so its terminal paths never enter \(J\). If their bits differ, both connector edges occur in \(U\triangle W\). The projected matchings of \(J\) differ at \(f\), and their symmetric difference has one alternating cycle through \(f\); deleting \(f\) turns that cycle into a path from \(u\) to \(v\). Thus \(U\triangle W\) traverses \(J\) as a single replacement for \(e_0\), with only additional closed cycles inside \(J\). In either case the pairing of the four relevant shore ports is exactly the pairing in the projected row of \(H_0\).

By Note 273, a nonempty intersection in (1) is equivalent to the existence of a real \(ad\) row whose \(U_{ad}\triangle W_d\) pairs \(a:\Sigma\) with \(h_2\). Projection preserves this property, and **every** slotwise lift of such a row preserves it by the preceding paragraph. This proves the intersection equivalence. \(\square\)

If \(J\) has no BF cover, projection shows that \(H\) has no BF row at all. When \(J\) is BF-covered, Note 103 also gives \(\operatorname{BFsupp}(H)=\operatorname{BFsupp}(H_0)\). Hence a BF-covered two-sum can neither create nor remove a local example with both load sets nonempty and disjoint. Any minimum-order example of that kind has no such removable factor, subject to the reduced pole retaining the required simplicity and exterior hypotheses.

## A Tait-empty real local failure at order 35

For a self-contained factor certificate, present the Petersen graph with outer vertices \(a_i\), inner vertices \(b_i\), outer edges \(a_i a_{i+1}\), inner edges \(b_i b_{i+2}\), and spokes \(a_i b_i\), all indices modulo five. Its six perfect matchings are
\[
M_*=\{a_i b_i:0\le i<5\},\qquad
M_i=\{a_i b_i, a_{i+1}a_{i+2}, a_{i+3}a_{i+4},
             b_{i+1}b_{i+3}, b_{i+2}b_{i+4}\}.
\]
Every perfect matching uses an odd number of spokes, by parity of the five outer vertices. Three spokes are impossible: the two uncovered outer indices would have to be adjacent on the outer cycle and also adjacent on the inner five-cycle, whose edges join indices two apart. Five spokes give \(M_*\); one spoke at \(i\) leaves unique perfect matchings on the other four outer and four inner vertices, giving \(M_i\). Each spoke occurs in \(M_*\) and one \(M_i\); each outer or inner edge occurs in two of the \(M_i\). These six matchings are therefore a BF cover. The complement of \(M_*\) is the two five-cycles. For \(M_0\), its complement is likewise the cycles \(a_0a_1b_1b_4a_4a_0\) and \(a_2a_3b_3b_0b_2a_2\); rotation handles the other \(M_i\). A three-edge-colouring would make the complement of one colour matching a union of even cycles, so the factor is not three-edge-colourable.

Take the 25-vertex pole of [Note 272's local completion counterexample](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), using Note 255's modified twelve-vertex shore, and choose its central-cycle edge \(e_0=c_0=s_0s_1\). Let \(J\) be the Petersen graph with any edge \(f\). The resulting \(H\) is a connected simple cubic five-pole of order \(25+10=35\). The base has a real \(ad\) row and all six individual actual matchings needed by the prescribed \(ac\) template, but no \(ac\) row. Its \(ad\) row lifts by Note 103. Each individual \(ac\) matching lifts because a Petersen BF cover contains matchings both using and avoiding \(f\). Any putative \(ac\) row of \(H\) would project to the absent base row. Thus
\[
\mathcal F_{ad}(H)\ne\varnothing,\qquad
\mathcal F_{ac}(H)=\varnothing,                            \tag{2}
\]
even though every individually prescribed \(ac\) matching exists.

The pole \(H\) is Tait-empty. In any hypothetical three-edge-colouring, the two edges separating the Petersen factor would have the same colour (the factor has even order). Restoring \(f\) in that colour would three-edge-colour the Petersen graph, a contradiction. In particular neither forbidden shore Tait signature of Note 272 can occur. Nevertheless \(H\) is **not** exact Case XII: [Note 226's finite pentagon-hit theorem](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) forces the 25-vertex base to have an all-terminal or forbidden \(T\)--\(T\) BF type for this terminal pentagon, and Note 103 preserves its complete BF boundary support. The example separates three-edge-colourability from the missing *BF* types while retaining the real matching-level completion failure. Its two-edge cut also excludes it from the minimum-host setting.

The proof uses factor projection and path topology, not a new local enumeration or an OMEN run. It does not exhibit two nonempty disjoint load sets under exact Case XII and does not settle Berge--Fulkerson. The two-sum application is hand-derived and awaits independent verification.
