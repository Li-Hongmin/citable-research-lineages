> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The parallel marked path in \(K_{3,3}\) also has no exact-Case-XII row

Retain the six-port shore and the \(K_{3,3}\) exterior of [Note 368](368-the-crossed-k33-marked-path-has-no-case-xii-row.md): the unmarked tree is \(xr,xs,xt,yr,zs\), with subdivision vertices \(u_0,\ldots,u_4\), and the marked path is \(a=ys,b=yt,c=zt,d=zr\). Now take the other pentagon whose two \(e\)-neighbours are the end-adjacent marks \(a,b\):
\[
 S=e-a-c-d-b-e,\qquad T=\{ec,ed,ab,ad,bc\}.          \tag{1}
\]
In the labels of the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), \((e,a,c,d,b)=(3,1,4,2,5)\). Thus its required \((ea)(ab)=(13)(15)\) row exists, while \((bc)(ab)=(45)(15)\) and every other \(T\)--\(T\) row are forbidden.

**Theorem.** No cubic five-pole with this exterior has complete exact-Case-XII support (1), at any shore order or cycle rank. Together with Note 368 and the marked-path reversal, this excludes all four labelled pentagons whose \(e\)-neighbour pair is \(\{a,b\}\) or \(\{c,d\}\).

**Proof.** Suppose the required \((ea)(ab)\) row exists. Use the names \(P,R,E,B,A_1,A_2\) of Note 368: \(P\) is the state-\(ea\) triple, \(R\) the state-\(ab\) triple, \(E\) and \(B\) singleton at \(e,b\), and \(A_1,A_2\) singleton at \(a\). The rooted-tree and exterior-path classification in Note 368 uses only \(ea,eb\in S\) and \(ec,ed,ab\in T\), which also hold in (1). In particular, each \(a\)--\(b\) path of \(P\triangle A_i\) is wholly outside the shore. Denote the four listed routes there by \(D,L\) at root \(y\) and \(K,J\) at root \(s\).

At root \(y\), any occurrence using \(L\) would already match \(r\) through \(ru_0\) and \(t\) through \(t_bt\). Since both triples select terminal semiedges at \(c,d\), that occurrence would need both \(t_cz,t_dz\), impossible at \(z\). Hence both \(A_i\) use the direct route \(D=a-t_a-y-t_b-b\). At \(t_b\) they saturate \(t_by\), forcing \(R,E\) onto \(t_bt\); in particular \(E\) uses the \(t\)-half of \(b\).

Exact support forces the \(e\)-terminal path of \(P\triangle E\) to end at \(c\): exchanging to either other state \(ab\) or \(ad\) would put that state in \(T\) beside \(R=ab\in T\). Exchange \(P,E\) on this complete \(e\)--\(c\) component, giving a state-\(ac\) triple \(P_c\). We claim that \(P_c\) still uses \(t_ay\). If \(E\) also uses \(t_ay\), it is a common edge of \(P,E\), so the component cannot touch it. Otherwise \(E\) uses \(t_as\). Because it already uses \(t_bt\), it must choose \(t_cz\); at \(u_4\), both \(s,z\) are already matched by \(E\), so it uses port \(p_4\). The \(c\)-terminal exterior leg of \(P\triangle E\) is then exactly \(c-t_c-z-u_4-p_4\), again disjoint from \(t_ay\). In both cases the exchange leaves \(P_c\) on \(t_ay\). It also leaves the terminal edge \(s_b\) of \(P\), since the exchanged component ends at \(c\), not \(b\). Either untouched \(A_i\) uses \(t_by\) on its route \(D\), so \(P_c\triangle A_i\) contains the entirely exterior path
\[
                   a-t_a-y-t_b-b.                         \tag{2}
\]
Switching (2) changes \(P_c\) from \(ac\) to \(bc\in T\), while \(R=ab\in T\) stays fixed. This is a forbidden genuine row.

At root \(s\), the complete exterior singleton restrictions \(A_K,A_J\) are (3)–(4) of Note 368. Both occurrences cannot use \(K\): the load at \(t_b,t_a\) would make \(E\) select both \(t_by,t_ay\), meeting at \(y\). One \(K\) and one \(J\) are also impossible without using the order of the pentagon: switching \(P,A_K\) on \(K\) gives an \(eb\)-triple using \(t_bt\), while the untouched \(B\) is forced onto \(t_ct\); the exterior \(b\)--\(c\) switch gives \(ec\in T\) beside \(R=ab\in T\). Therefore both \(A_i\) use \(J\).

The remaining row has a forced exterior segment. The two \(A_J\) saturate \(su_1\). Since \(R\) must match \(z\) through \(zu_4\), it cannot also use \(su_4\); hence it selects \(t_as\). Both \(A_J\) use \(t_by\), so \(R,E\) use \(t_bt\). At \(t_a\), \(P,R\) saturate \(t_as\), forcing \(E\) onto \(t_ay\). Matching incidence then forces \(E\) onto \(t_cz\). At \(u_4\), \(P,R\) use \(zu_4\) and both \(A_J\) use port \(p_4\), so \(E\) uses \(su_4\). At \(u_3\), \(P,R\) use \(yu_3\) and both \(A_J\) use \(ru_3\), so \(E\) uses port \(p_3\). Consequently the \(c\)-terminal exterior leg of \(P\triangle E\) is
\[
       c-t_c-z-u_4-s-t_a-y-u_3-p_3.                    \tag{3}
\]
The required \(e\)--\(c\) exchange along (3) replaces \(P\)'s \(t_as\) half by \(E\)'s \(t_ay\) half and leaves \(s_b\) unchanged. Each \(A_J\) uses \(t_by\). The new state-\(ac\) triple and either \(A_J\) therefore have the direct exterior path (2), again producing forbidden \((bc)(ab)\). All possibilities are exhausted. \(\square\)

The proof is row-internal: shore matchings from distinct BF rows never have to be synchronized. The remaining marked-path pentagons have \(e\)-neighbour pairs \(\{b,c\},\{a,c\},\{b,d\},\{a,d\}\); the other \(K_{3,3}\) spanning tree, the triangular prism, and general Case XII remain open. This argument is analytic and awaits independent review of its cited upstream rooted-tree and quota lemmas; no local mathematical recomputation was used.
