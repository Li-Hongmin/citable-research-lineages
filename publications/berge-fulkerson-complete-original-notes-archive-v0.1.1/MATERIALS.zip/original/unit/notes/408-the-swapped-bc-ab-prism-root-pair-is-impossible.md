> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The swapped \(e\,bc:c\) and \(e\,ab:b\) prism root pair is impossible

Use the same two-spoke prism tree and marks as [Note 407](407-the-last-ab-bc-prism-row-forces-a-double-forbidden-completion.md), but put the forbidden \(e\)-labels at \(AC,bc\). Consider a real six-perfect-matching row with forbidden triple \(P=e\,bc:c\) and allowed triple \(R=e\,ab:b\). The remaining shore is arbitrary.

> **Root-pair exclusion.** Such a row cannot occur under complete exact Case-XII support for either allowed pentagon
> \[
> S_1=e-ab-AC-bc-Cc-e,\qquad
> S_2=e-ab-bc-AC-Cc-e.                                        \tag{1}
> \]
> The other roots and other forbidden-label placements are not covered.

**Proof.** Write \(K\) for the singleton-\(ab\) occurrence, \(J\) for singleton-\(bc\), and \(D_0,D_1\) for the two singleton-\(e\) occurrences. The zero-port rooted masks of \(P,R\) on \((u_1,\ldots,u_5)\) are \((B,C,A,b,a)\) and \((A,C,a,B,c)\), respectively. An \(ab\)-starting switch of \(R\) with \(K\) cannot end at \(AC\) or \(bc\): either would create a forbidden \(e\)-triple alongside the unchanged \(P\). Thus it must end at \(Cc\).

At \(b\), \(K\) cannot use \(bc:b\), since that would end the same path at forbidden \(bc\); it uses \(bu_4\). From \(B\), the \(Bu_1\) route can reach \(Cc\) only through \(Au_3,au_5,Cc:c\). But then \(b\) and \(c\) are already matched at \(bu_4,Cc:c\), leaving neither half-edge available to cover the subdivision of \(bc\). Hence \(K\) uses \(Bu_2,Cc:C\). Its complete \(ab\)--\(Cc\) path is wholly exterior:
\[
ab-t_{ab}-b-u_4-B-u_2-C-t_{Cc}-Cc.                         \tag{2}
\]
Switching (2) gives another allowed zero-port triple \(R'=e\,Cc:C\) with **the same complete shore matching** as \(R\).

The vertex and mark loads force both \(D_i\) to take \(ab:a,bc:b\). They also force \(K\) to take \(AC:A,bc:c\): \(C\) is already matched by \(Cc:C\), and \(b\) by \(bu_4\). There is at least one singleton-\(e\) occurrence \(E\) satisfying
\[
E:\quad AC:C,\quad Cc:c,\quad bc:b,\quad ab:a,\quad p_5.  \tag{3}
\]
Indeed, \(J\) covers \(c\) either by \(cu_5\) or by \(Cc:c\). In the first case it must use \(Cc:C,AC:A\), so both \(D_i\) use \(Cc:c,AC:C\). At \(u_5\), \(P\) uses \(au_5\) and \(R,J\) use \(cu_5\); because both \(D_i\) cover \(a,c\) at the marks, \(K\) takes the second \(au_5\) slot and both \(D_i\) take \(p_5\). In the second case \(J\) uses \(AC:C\); the singleton-\(e\) occurrence using the other \(Cc:c\) half-edge must also use \(AC:C\) to cover \(C\). It cannot use \(cu_5\), since \(c\) is covered at \(Cc:c\), and it cannot use \(au_5\), since \(a\) is covered at \(ab:a\). It therefore uses \(p_5\). This proves (3) in both cases.

Let \(q\) be the proper endpoint of the shore path starting at \(e\) in \(R\triangle E\). Because (2) changes no shore edge, exactly the same path and endpoint \(q\) occur in \(R'\triangle E\). Against \(R\), the \(p_5\)-arm of \(E\) ends at \(Cc\) through \(p_5-u_5-c-t_{Cc}-Cc\). Against \(R'\), it instead ends at \(AC\) through
\[
p_5-u_5-c-t_{Cc}-C-t_{AC}-AC.                            \tag{4}
\]
For \(S_2\), \(R'=e\,Cc\) can exchange its \(e\) terminal only for \(AC\) while keeping \(P=e\,bc\) forbidden: \(Cc\,AC\in S_2\), whereas \(Cc\,ab,Cc\,bc\notin S_2\). Its \(e\)-path therefore has to use (4), forcing \(q=p_5\). The same \(q\) against \(R=e\,ab\) then ends at \(Cc\), producing \(ab\,Cc\notin S_2\) alongside \(P=e\,bc\notin S_2\). Thus \(S_2\) is impossible.

Now suppose \(S=S_1\). To avoid a double-forbidden row, the \(e\)-path of \(R=e\,ab\) against \(E\) must end at \(AC\), while that of \(R'=e\,Cc\) against the same \(E\) must end at \(bc\). If \(E\) takes \(Bu_1\), its \(AC\)-arm against \(R\) ends at \(p_2\), whereas its \(bc\)-arm against \(R'\) ends at \(p_4\). These require two different values of the same \(q\). Hence \(E\) takes \(Bu_2\) or \(Bu_4\). In these two cases, the required common endpoint is respectively \(p_4\) or \(p_2\): against \(R\), the \(AC\)-arm follows \(AC-t_{AC}-C-u_2\), continuing through \(B-u_4-p_4\) if \(E:Bu_2\); against \(R'\), the \(bc\)-arm follows \(bc-t_{bc}-b-u_4\), continuing through \(B-u_2-p_2\) if \(E:Bu_4\).

Switch the resulting complete \(e\)--\(AC\) path of \(R\triangle E\). It gives an allowed triple \(T=ab\,AC\) and a singleton-\(AC\) occurrence \(E'\). In either \(Bu_2\) or \(Bu_4\) case, \(E'\) has terminal \(AC\), takes \(Cu_2,Bu_4,bc:b,Cc:c,ab:a\), and retains \(p_5\). The triple \(T\) retains \(ab:b,cu_5,au_3\), and its \(B\)-half is at \(u_2\) or \(u_4\).

Compare \(T\) with the unchanged singleton-\(ab\) matching \(K\). Switching its \(ab\)-starting path to \(e\) or \(Cc\) would give \(e\,AC\) or \(AC\,Cc\), both forbidden under \(S_1\) alongside \(P\). The path must therefore end at \(bc\). Switch it, giving the allowed triple \(U=AC\,bc\) and a singleton-\(bc\) matching \(K'\). Independently of whether \(K\) uses \(au_3\) or \(au_5\), the exterior of \(U\) has
\[
U:\quad AC:C,\quad bc:c,\quad Bu_2,\quad bu_4,\quad
Cc\text{ terminal},\quad ab\text{ terminal};              \tag{5}
\]
the exterior of \(K'\) has \(ab:b\) and the \(bc\) terminal. For (5), the \(ab\)-arm of \(T\triangle K\) reaches the shore through \(p_4\) when \(E:Bu_2\), or through \(p_2\) when \(E:Bu_4\); its \(bc\)-arm reaches the shore through \(p_3\) or \(p_5\) according as \(K\) uses \(au_5\) or \(au_3\). The switch changes both variants to the same six exterior slots displayed in (5).

Now \(U\triangle E'\) has a **wholly exterior** \(AC\)--\(Cc\) alternating terminal path:
\[
AC-t_{AC}-C-u_2-B-u_4-b-t_{bc}-c-t_{Cc}-Cc.           \tag{6}
\]
It switches \(U=AC\,bc\) to the allowed \(V=Cc\,bc\). The path gives \(V\) the edge \(bc:b\) and the \(ab\) terminal, while leaving the \(bc\) terminal in \(K'\) and the edge \(ab:b\) there. Hence \(V\triangle K'\) has another wholly exterior alternating terminal path
\[
bc-t_{bc}-b-t_{ab}-ab.                                   \tag{7}
\]
Switching (7) gives \(Cc\,ab\notin S_1\), while the original \(P=e\,bc\notin S_1\) has remained unchanged. This double-forbidden BF row excludes \(S_1\) and proves the theorem. Every switch is between complete perfect matchings and preserves the edge load two. \(\square\)

This proof uses complete matching switches and shore identity, without a clean-signature or size assumption. It leaves the other root pairs and forbidden-label placements open. The derivation is by hand and awaits independent proof review.
