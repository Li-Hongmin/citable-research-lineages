> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-port closure separates the remaining three-two row loads

> **Scope correction:** [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> shows that the required \(ad\) row need not use Note 272's left
> exterior on rowwise grounds. The full-family \(AI,ID,AD\)
> fibre exclusions in assertion 1 use the stated side placement
> and exact negative support; assertions 2–3 and the Hall-tree
> application also use the left \(ad\) template.

Continue the actual central-path exterior and both required \((ea)(ac)\), \((ea)(ad)\) rows of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). Use [Notes 282–283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md): the unmarked core becomes bipartite on deleting \(g\subset B\), \(|B|-|R|=1\), and the internal mark has ends \(v\in B,w\in R\). Its shore ports are \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). Suppose exactly two of \(A,I,D\) lie in \(B\). Let \(q\) be the one in \(R\), and let \(r\) be the one of \(H,J\) in \(R\). The full exact-Case-XII support has allowed Tait pentagon \(S=e-a-b-d-c-e\); in particular \(bc\in T\).

**Theorem.** Under these assumptions:

1. No shore matching with port set \(AI\), \(ID\), or \(AD\) selects both \(g\) and \(t_ew\).
2. If \(q=I\), no such exact-Case-XII pole exists.
3. If \(q=A\) or \(q=D\), the two required row families have **disjoint four-slot shore-load sets**. In the notation \(B(R_t)=X_a+Y_a+Z_e+V_a\) of [Note 273](273-central-path-transfer-is-a-four-slot-load-intersection.md), every \(ac,ad\) row satisfies respectively
   \[
   \begin{array}{c|cc}
   q&B(R_{ac})(g)&B(R_{ad})(g)\\\hline
   A&1&2\\
   D&2&1.
   \end{array}                                               \tag{1}
   \]
   In these two placements every required zero-port \(X_a\) also selects \(t_ev\) and avoids \(g\). One required row contains two **distinct** \(HJ\)-port matchings selecting \(g,t_ew\), while the other contains exactly one such occurrence. Consequently Note 273's one-path transfer between these two forced templates cannot occur in either surviving \(3{:}2\) placement. This is a necessary constraint on a hypothetical exact pole, not an existence claim.

## The forbidden \(AI,ID\) fibres

Colour \(t_e\) and all five exterior shore-interface endpoints \(R\), as in Note 283. Then all five terminal vertices are in \(R\), and the only same-side proper edges of the whole pole are \(g\), \(t_ew\), and the two cut edges at \(q,r\). Consider a shore matching \(N\) with ports \(AI\) or \(ID\), selecting \(g,t_ew\). Note 283's balance equation requires the two selected proper ports to have side sum zero, so one is based in \(B\) and one in \(R\). Among \(AI,ID\), the \(R\)-based port must be \(q\), and \(r\) is unselected. Thus \(r\) is the **only** same-side edge left in the complement of any full matching obtained by gluing \(N\) to an exterior mask with those ports.

The following are actual exterior matchings. The displayed edges omit the terminal semiedge named in the second column; \(a:\Sigma\) is the exterior half of the cut mark. The last column gives every nontrivial exterior-complement connection among free shore ports and unselected terminals.

| Shore ports | Singleton | Selected exterior edges besides its terminal | Exterior-complement connections |
|---|---|---|---|
| \(AI\) | \(c\) | \(a:\Sigma,b:A,d:E,2B,3C,4D,h_1\) | \(D-a,\ H-b,\ J-d\) |
| \(AI\) | \(b\) | \(a:\Sigma,c:A,d:B,2C,3D,4E,h_1\) | \(D-J,\ H-a,\ c-d\) |
| \(ID\) | \(c\) | \(a:C,b:A,d:B,3D,4E,h_1,h_2\) | \(A-a,\ H-d,\ J-b\) |
| \(ID\) | \(b\) | \(a:C,c:A,d:B,3D,4E,h_1,h_2\) | \(A-a,\ H-J,\ c-d\) |

Each mask covers \(t_a,t_b,t_c,t_d\), the four \(u_i\), and the five branch vertices \(A_{\rm ext},\ldots,E_{\rm ext}\) exactly once. For example, the \(AI,b\) row covers the branch vertices by \(c:A,d:B,2C,3D,4E\), and the \(ID,b\) row by \(c:A,d:B,a:C,3D,4E\). The displayed complement paths follow by taking the other two incident proper edges at each covered vertex. Thus gluing uses a genuine complete perfect matching, independent of either BF row.

For either singleton-\(c\) mask, each of the three free proper shore ports has its own exterior arm to \(a,b,d\); the fourth free shore port \(E\) has the terminal \(e\). Consequently all four ports lie on open terminal paths. Every closed complement cycle is even, because \(g,t_ew,q\) are selected and the sole remaining same-side edge \(r\) lies on an open path. The full matching extends to a Tait colouring. Its singleton colour is \(c\), and switching the complementary colours along the differently coloured terminal path makes *both* endpoints of that path the second lonely terminal. Exact support permits only \(ce,cd\), so that path must join \(e\) to \(d\). Since all terminal vertices lie in \(R\), a path is differently coloured exactly when it avoids \(r\).

For \(AI,c\), the \(d\)-arm is \(J\). Hence the shore complement must pair \(EJ\), and \(r\) must be \(H\), leaving the pairing \(EJ\mid DH\). If \(r=J\), the \(e\)--\(d\) path contains the exception and instead gives a forbidden state. For \(ID,c\), the \(d\)-arm is \(H\), so the only possible pairing is \(EH\mid AJ\) with \(r=J\).

Now reuse the *same shore matching* with its singleton-\(b\) exterior mask. In the \(AI\) case, the exterior \(D-J\) path joins the shore paths \(EJ,DH\) into an \(e\)--\(a\) terminal path containing \(r=H\). In the \(ID\) case, the exterior \(H-J\) path joins \(EH,AJ\) into an \(e\)--\(a\) path containing \(r=J\). In both cases the other open path is the exterior \(c\)--\(d\) path and avoids the exception. All closed cycles remain even; switching that differently coloured \(c\)--\(d\) path yields a genuine \(bc\)-Tait state. Since \(bc\in T\), its doubled colouring is a forbidden \(T\)-loop. Thus the \(AI,ID\) fibres are empty.

## The forbidden \(AD\) fibre

Only \(q=A,D\) can make \(AD\) a mixed-side port pair, which is required by Note 283's balance when \(g,t_ew\) are selected. Suppose such a shore matching \(N_{AD}\) exists. Two further actual singleton-\(c\) exterior masks use exactly these two shore ports:

| Mask | Selected exterior edges besides terminal \(c\) | Exterior-complement connections |
|---|---|---|
| \(Q_1\) | \(a:\Sigma,b:A,d:E,1B,3C,4D,h_2\) | \(a-d,\ b-H,\ I-J\) |
| \(Q_2\) | \(a:\Sigma,b:D,d:B,1A,3C,4E,h_2\) | \(b-d,\ a-I,\ H-J\) |

For \(Q_1\), the five branch vertices are covered by \(b:A,1B,3C,4D,d:E\); for \(Q_2\), by \(1A,d:B,3C,b:D,4E\). The chosen \(h_2\) covers \(u_2\), and the other three \(u_i\) are covered by their displayed path edges. Thus both masks are genuine.

The only unselected same-side edge in either complete matching is again \(r\). In \(Q_1\), terminals \(a,d\) are joined entirely outside the shore, so the differently coloured terminal path cannot be \(e\)--\(d\). If \(r=H\), its exterior \(b\)--\(H\) arm places it on a terminal path. Every closed cycle is then even and one of the singleton-\(c\) Tait states is forbidden. Thus \(r=J\). To avoid the same contradiction under \(Q_1\), \(r=J\) must lie on an odd closed cycle: the shore complement must pair \(I\)--\(J\) to close the exterior \(I\)--\(J\) path. Under \(Q_2\), the exterior \(b\)--\(d\) path again prevents an \(e\)--\(d\) path. To put the same \(r=J\) on an odd closed cycle now requires the shore pair \(H\)--\(J\). One fixed shore complement cannot pair \(J\) with both \(I\) and \(H\). This contradiction finishes assertion 1.

## The middle placement is impossible

Suppose \(q=I\). A shore matching with ports \(HJ\) and selected \(g,t_ew\) is also impossible. Glue it to the genuine singleton-\(c\) exterior mask
\[
\{c_{\rm term},a:C,b:D,d:E,1A,2B,h_3,h_4\}.           \tag{2}
\]
Its exterior complement has the three arms \(A-a,I-d,D-b\). The sole unselected same-side edge is the cut edge \(I\), which lies on an open terminal path; every closed cycle is even. A singleton-\(c\) Tait colouring could avoid a forbidden state only if its differently coloured path were \(e\)--\(d\). But that path must use the \(I\)-arm and hence the exceptional edge \(I\), making its endpoints the **same** colour. Every possible shore pairing therefore gives a forbidden \(T\)-Tait state.

In either required row, both \(HJ\) occurrences \(Y_a,V_a\) consequently select \(t_ev\) and avoid \(g\), by the matching balance of Note 283. The four-port \(Z_e\) avoids \(g\); both opposite triples \(U_{ac}\) (ports \(EA\)) and \(U_{ad}\) (ports \(ED\)) avoid \(g\) because \(A,D\in B\). The opposite singleton \(W_c\) or \(W_d\) avoids \(g\): its \(ID\) or \(AI\) ports contain \(I\in R\), and assertion 1 excludes its only possible \(g\)-using profile. Thus only the zero-port \(X_a\) could use \(g\), at most once among the six matching occurrences. A genuine BF row loads \(g\) twice. Contradiction, proving assertion 2.

## The two remaining placements have opposite loads

For \(q=A\), \(U_{ac}\) has ports \(EA\) and must use \(g\), while \(U_{ad}\) has \(ED\) and avoids it. The \(ID\)-port \(W_c\) avoids \(g\) by side balance because both ports lie in \(B\); the mixed \(AI\)-port \(W_d\) avoids it by assertion 1. Since \(Z_e\) avoids \(g\), subtracting the \(U,W\) loads from the BF edge load two gives the first line of (1).

For \(q=D\), \(U_{ad}\) must use \(g\) and \(U_{ac}\) avoids it. The \(AI\)-port \(W_d\) avoids \(g\) by side balance, and the mixed \(ID\)-port \(W_c\) avoids it by assertion 1. The same subtraction gives the second line of (1).

In either case \(I\in B\). Suppose a required zero-port \(X_a\) used \(g\). Note 283's balance makes it select \(t_ew\); its four-port partner \(Z_e\) avoids \(g\). The pure paths of \(X_a\triangle Z_e\) pair \(E\)--\(I\) and \(A\)--\(D\). The internal \(E\)--\(I\) path has odd length from \(t_e\in R\) to the base of \(I\in B\), and it contains the same-side edge \(t_ew\). The number of same-side edges on such an odd \(R\)--\(B\) path is even. As \(g\) is the only other possible one, \(g\) lies on this path too. Switching this actual \(E\)--\(I\) component in \(Z_e\) would give a shore matching with ports \(AD\), selecting \(g,t_ew\), contrary to assertion 1. Hence \(X_a\) avoids \(g\) and selects \(t_ev\). In (1), the entire one-unit versus two-unit difference at \(g\) is carried by \(Y_a,V_a\): for \(q=A\), exactly one of them uses \(g\) in every \(ac\) row and both do in every \(ad\) row; for \(q=D\), the roles of the rows reverse. The two occurrences in the latter row are distinct complete shore matchings by Notes 271–272, so the \(HJ\)-port \((g,t_ew)\) fibre has size at least two. \(\square\)

## Exact residual Hall barrier

There is a direct description of the still-forbidden fibre in [Note 289](289-the-remaining-near-bipartite-core-has-an-empty-r-r-two-port-fibre.md). In either remaining case \(q=A,D\), the required opposite triple \(U_{ac}\) or \(U_{ad}\), respectively, has shore ports \(E,q\) and selects \(g\). Write \(g=xy\), and let \(\hat q,\hat r\in R\) be the core vertices carrying ports \(q,r\). The restriction of this actual matching supplies a perfect matching of the balanced bipartite graph
\[
G_q=(C-g)-\{x,y,\hat q\}.                              \tag{3}
\]
If \(v\in\{x,y\}\), or \(\hat q=\hat r\), the fibre selecting \(q,r,g,t_ev\) is empty by local incidence. Otherwise that fibre is exactly the set of perfect matchings of \(G_q-v-\hat r\). Since Note 289 makes it empty under exact support, Hall's theorem gives a nonempty set \(S\subseteq B(G_q)\setminus\{v\}\) such that
\[
|N_{G_q}(S)|=|S|,\qquad \hat r\in N_{G_q}(S).       \tag{4}
\]
Conversely any such tight Hall set forbids the fibre: deleting \(\hat r\) leaves \(S\) with only \(|S|-1\) neighbours. Indeed, if \(G_q-v-\hat r\) has no perfect matching, a Hall-deficient \(S\) in that graph loses at most the one neighbour \(\hat r\) compared with \(G_q\), which already has a perfect matching. This forces exactly (4). Thus an exact pole in either remaining placement must exhibit a local incidence collision or this precise tight Hall barrier. No existing minimum-host or cyclic-connectivity result used here excludes either alternative.

The barrier has a sharp host-cut count. Choose \(S\) inclusion-minimal among sets satisfying (4), and put \(T=N_{G_q}(S)\), \(\Omega=S\cup T\). The graph induced by \(\Omega\) in \(C-g\) is connected: each connected piece has at least as many \(T\)-vertices as \(S\)-vertices because \(G_q\) has a perfect matching; equality in their sum makes the piece containing \(\hat r\) a smaller set satisfying (4) if there is more than one piece. Let \(\alpha\) count the proper shore-cut incidences based in \(S\), and let \(\eta=e_{C-g}(S,\hat q)\). Since \(S\) avoids \(v,x,y\), every \(J\)-edge from \(S\) goes to \(T\), to \(\hat q\), or across one of those \(\alpha\) shore ports. Cubic degree counting on the equally sized sets \(S,T\) therefore gives
\[
\boxed{|\delta_J(\Omega)|=2(\alpha+\eta),\qquad
0\le\alpha\le3,\quad0\le\eta\le2.}                 \tag{5}
\]
Indeed, if \(m=e_J(S,T)\), the edges leaving \(S\) number \(3|S|-m=\alpha+\eta\), and the edges leaving \(T\) number \(3|T|-m=\alpha+\eta\). Every marked edge meets \(\Omega\) at most once, so the same cut size holds in the completed cubic host with subdivided marks. Its complement contains the cap pentagon. By the published cyclic-five connectivity of a *minimum BF counterexample* ([Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md)), a cut of size below five must have an acyclic \(\Omega\)-side. A connected cubic tree has order \(|\delta(\Omega)|-2\). Hence \(\alpha+\eta\ge2\), and equality forces \(\Omega\) to be exactly a two-vertex tree: \(S=\{s\}\), \(T=\{\hat r\}\). Simplicity then gives \(\eta\le1\), so \(s\) has either two proper shore ports, or one such port and an edge to \(\hat q\). Every larger minimal Hall barrier has an even host cut of size \(6,8\), or \(10\). Cyclic-five connectivity alone permits these larger cuts; Proposition 4.4's five-cut classification does not apply to their even sizes.

The four-edge exception has one more forced port placement. Let \(s_B\) denote the core vertex carrying the unique \(B\)-based port among \(H,J\). The required row with **both** \(HJ\)-port occurrences selecting \(g,t_ew\) supplies an actual shore matching \(Y\) selecting \(g,t_ew,s_B,\hat r\). If \(\alpha=2,\eta=0\), the sole vertex \(s\in S\) has no internal \(C-g\) neighbour other than \(\hat r\). Since \(Y\) covers \(\hat r\) by its port, it must cover \(s\) by its own shore port. Thus \(s=s_B\), and its second shore port is one of the two \(B\)-based ports in \(\{A,I,D\}\). If \(r=J\), then \(s_B\) carries \(H=h_3\); girth five forbids its second port from being \(D=h_2\), since the common base would create the four-cycle through \(u_2,C_{\rm ext},u_3\). When \(q=D\), it also forbids the second port \(A=a:\Sigma\), whose common base with \(H\) would create the four-cycle through \(t_a,C_{\rm ext},u_3\). Hence in either \(q=A\) or \(q=D\) case with \(r=J\), that second port must be \(I=h_1\). If \(\alpha=1,\eta=1\) and \(s\ne s_B\), every \(HJ\)-port shore matching selecting \(g,t_ew\) must use the edge \(s\hat q\), because \(\hat r\) is already covered by its port. Neither surviving local shape has been ruled out by the two required rows.

This result closes the \(q=I\) subprofile and the **specified** four-slot transfer in the \(q=A,D\) subprofiles; it does not exclude those two subprofiles, prove Note 289's forbidden \(R\)--\(R\) fibre is nonempty, rule out the \(4+1\) or high-rank cores, or settle Berge–Fulkerson. The exterior masks and upstream forced row templates are hand-derived and await independent verification. No graph census, OMEN, or local bulk computation was used.
