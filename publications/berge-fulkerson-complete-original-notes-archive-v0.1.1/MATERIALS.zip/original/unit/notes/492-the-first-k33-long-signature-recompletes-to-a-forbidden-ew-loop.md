> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first Hamilton \(K_{3,3}\) long-row signature always recompletes to \([eW]\)

Work in the genuine complete BF row of [Note 489](489-k33-hamilton-adjacent-allowed-pair-has-one-long-root-signature.md) with forbidden \(e\)-states \(\{eZ,eW\}\), and use [Note 490's first residual signature](490-the-k33-long-row-forces-one-pentagon-and-shore-e-paths.md):
\[
P=eZ\text{ rooted at }Z:2,qquad R=eX\text{ rooted at }X:4,
\qquad J=Z\text{ using }2u_1.                              \tag{1}
\]
The exterior is the path \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\), with marks \((X,Y,Z,W)=(14,16,25,36)\). Name its six **complete** matching occurrences \(P,R,K,J,A,B\), where \(A,B\) are the two singleton-\(e\) occurrences. The load-two rule fixes their complete shore boundary sets as
\[
\begin{array}{c|cccccc}
&P&R&K&J&A&B\\\hline
\partial Q&\varnothing&\varnothing&\{p_4,p_5\}&\{p_2,p_4\}&
\{e,p_1,p_2,p_3\}&\{e,p_1,p_3,p_5\}.
\end{array}                                                \tag{2}
\]
The identities of the six shore matchings \(Q_P,Q_R,Q_K,Q_J,Q_A,Q_B\) are arbitrary; their boundary sets and their old load-two sum are the only facts used below.

**Fixed-full-mask closure theorem.** Every genuine row (1), on any six-port shore, has a genuine BF recompletion of forbidden Case-XII type \([eW]\). The recompletion preserves **each** of the six complete shore matching occurrences in (2), one for one. Consequently, no exact-Case-XII pole with forbidden \(\{eZ,eW\}\) can contain Note 490's first residual long-row signature. The statement needs neither its two shore \(e\)-path conditions nor any shore parity or irreducibility hypothesis.

**Proof.** Keep the same complete shore matching under each colour name, and replace only the exterior restriction by the following one. A marked half such as \(W:3\) means the edge from the indicated original vertex to its marked subdivision; an unlisted mark uses its terminal semiedge.

| colour | new boundary role | marked halves | tree halves | proper ports |
|---|---|---|---|---|
| \(P\) | \(eW\) | \(W:3\) | \(1u_1,2u_2,4u_3,5u_4,6u_5\) | none |
| \(R\) | \(eW\) | \(W:6\) | \(1u_1,2u_2,3u_3,4u_4,5u_5\) | none |
| \(K\) | \(W\) | \(X:1,Y:6,Z:5\) | \(2u_1,3u_2,4u_3\) | \(p_4,p_5\) |
| \(J\) | \(W\) | \(X:4,Y:1,Z:5\) | \(2u_1,3u_3,6u_5\) | \(p_2,p_4\) |
| \(A\) | \(e\) | \(X:1,Y:6,Z:2,W:3\) | \(4u_4,5u_5\) | \(p_1,p_2,p_3\) |
| \(B\) | \(e\) | \(X:4,Y:1,Z:2,W:6\) | \(3u_2,5u_4\) | \(p_1,p_3,p_5\) |

Every colour still uses precisely the shore ports of its **old complete** matching in (2), so each exterior restriction glues to that same matching. To check the exterior load, the two colours on each half of each tree edge are
\[
\begin{array}{c|cc|c}
 &\text{left original half}&\text{right original half}&\text{proper port}\\\hline
u_1&PR&KJ&AB\\
u_2&PR&KB&JA\\
u_3&RJ&PK&AB\\
u_4&RA&PB&KJ\\
u_5&RA&PJ&KB
\end{array}.                                                \tag{3}
\]
At the six original vertices, the three incident edge pairs are, in path order,
\[
\begin{array}{c|ccc}
1&PR:1u_1&KA:X:1&JB:Y:1\\
2&PR:2u_2&KJ:2u_1&AB:Z:2\\
3&PA:W:3&RJ:3u_3&KB:3u_2\\
4&PK:4u_3&RA:4u_4&JB:X:4\\
5&PB:5u_4&RA:5u_5&KJ:Z:5\\
6&PJ:6u_5&KA:Y:6&RB:W:6
\end{array}.                                                \tag{4}
\]
At each marked subdivision, the two terminal occurrences and the two occurrences on each original half are
\[
\begin{array}{c|ccc}
X&PR: \text{terminal}&KA:X:1&JB:X:4\\
Y&PR: \text{terminal}&JB:Y:1&KA:Y:6\\
Z&PR: \text{terminal}&AB:Z:2&KJ:Z:5\\
W&KJ: \text{terminal}&PA:W:3&RB:W:6.
\end{array}                                                \tag{5}
\]
The \(e\) terminal is used by \(A,B\). Tables (3)--(5) prove load two on every exterior edge and a genuine perfect matching in every colour. The unchanged shore already has load two because it is taken from the old actual row. The new two triples both have state \(eW\), and the two marked singletons both have state \(W\); thus the row is \([eW]\), which the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) forbids when \(eW\in T\). \(\square\)

This is a stronger resolution of the first case left in Note 490. In particular, the real crossed-path pole of [Note 491](491-the-crossed-k33-shore-paths-have-a-real-row-with-forbidden-full-support.md) also contains \([eW]\) by this same six-mask recompletion; its separate \([eZ]\) certificate remains true. The three other Note-490 signatures, other forbidden pairs of the Hamilton \(K_{3,3}\) exterior, the one-spoke prism and Berge--Fulkerson remain open. The proof is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review.
