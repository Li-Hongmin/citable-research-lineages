> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(B_3\) row also forces forbidden full support

Continue the fixed marked Hamilton exterior, labels and signature table of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In \(B_3\), the old genuine \((eX)(eY)\) row has \(P=eX\) rooted at \(X:4\), \(R=eY\) rooted at \(Y:5\), and \(K=Y\) on marked halves \(X:1,Z:6,W:3\), tree halves \(2u_1,4u_3,5u_4\), and proper ports \(p_2,p_5\). We exclude **every** labelled port phase by keeping each of the six complete shore matching restrictions unchanged and recompleting only the exterior.

Put \(S=\{J,a,b\}\). The old marked \(X\) halves are \(X:1=K\nu,X:4=P\bar\nu\), where \(\nu\in\{a,b\}\) and \(\bar\nu\) is the other \(e\)-singleton. At \(u_1:2\), write \(K\lambda\), where \(\lambda\in S\). Reading the old tree and marked partitions forces
\[
\boxed{e=ab,\quad
(p_1,p_2,p_3,p_4,p_5)=
\bigl(S\setminus\{\lambda\},K\lambda,
S\setminus\{\mu\},S\setminus\{\tau\},K\nu\bigr),
\quad \{\mu,\tau\}=\{J,\nu\}.}                             \tag{1}
\]
Indeed \(u_1:1=PR\), so its port is \(S\setminus\{\lambda\}\). At original vertex \(2\), \(u_1:2=K\lambda\) and \(u_2:2=PR\) give \(Z:2=S\setminus\{\lambda\}\); hence \(Z:6=W:3=K\lambda\), \(u_2:3=S\setminus\{\lambda\}\), and \(p_2=K\lambda\). Write \(u_3:4=K\mu\); since \(u_3:3=PR\), its port is \(S\setminus\{\mu\}\). Original vertex \(4\) sees \(K\mu,P\bar\nu,R\tau\), forcing \(\{\mu,\bar\nu,\tau\}=S\), or \(\{\mu,\tau\}=\{J,\nu\}\). The halves at \(u_4\) are \((R\tau,PK)\), so \(p_4=S\setminus\{\tau\}\). Finally \(Y:5=R\nu\) and \(u_5:5=J\bar\nu\) give \(p_5=K\nu\). Thus (1) covers all old exterior port phases; the arbitrary complete shore remains untouched.

## \(\tau=\nu\): a universal forbidden \([eZ]\) loop

If \(\tau=\nu\), then \(\mu=J\), so (1) gives \(p_3=ab\), \(p_2=\bar p_1\), and \(p_5=\bar p_4\), where a bar means complement among \(I=\{K,J,a,b\}\). Denote the port pairs by \(A_1,\ldots,A_5\). The following exterior row retains those five pairs. At each \(u_i\) list first half, second half, port:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,\bar A_1,A_1)&(\bar A_2,PR,A_2)&
(KJ,PR,ab)&(\bar A_4,PR,A_4)&(\bar A_5,PR,A_5).
\end{array}                                                     \tag{2}
\]
At marked subdivisions, in terminal/first-half/second-half order, put
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,A_5,A_4)&(PR,\bar A_5,A_5)&(KJ,PR,ab)&(PR,ab,KJ).
\end{array}                                                     \tag{3}
\]
The original vertices see
\[
(PR,A_5,\bar A_5),\quad
(\bar A_1,\bar A_2,PR),\quad
(PR,KJ,ab),\quad
(PR,A_4,\bar A_4),\quad
(PR,\bar A_5,A_5),\quad
(PR,ab,KJ).                                                 \tag{4}
\]
These are six-label partitions because \(A_2=\bar A_1\) and \(A_5=\bar A_4\). The marked rows are also partitions, and the old shore pairs are unchanged. The terminal pairs are \(e=ab,Z=KJ,X=Y=W=PR\), forbidden \([eZ]\).

## \(\tau=J\): a forbidden \([eX]\) loop or double triple

If \(\tau=J\), then \(\mu=\nu\), so \(p_4=ab\), \(p_3=S\setminus\{\nu\}\), and \(p_5=K\nu\). If also \(\lambda=\nu\), then \(p_5=\bar p_1\) and \(p_3=\bar p_2\). The universal fixed-shore construction in [Note 467, equations (2)--(4)](467-the-x-z-hamilton-b1-row-forces-a-forbidden-ex-loop.md) therefore gives forbidden \([eX]\), although the **old** row here is \(B_3\), not \(B_1\).

For the other two values of \(\lambda\), interchange \(a,b\) if needed and write \(\nu=a,\bar\nu=b\). Then \(\lambda\in\{J,b\}\). Let \(t\) be the other element of \(\{J,b\}\), so \(\{\lambda,t\}=\{J,b\}\). The old port pairs are
\[
(p_1,p_2,p_3,p_4,p_5)=
\bigl(S\setminus\{\lambda\},K\lambda,Jb,ab,Ka\bigr).     \tag{5}
\]
Keep each complete shore restriction and use these new exterior pairs:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\lambda,S\setminus\{\lambda\})
&(Pt,Ra,K\lambda)
&(PK,Ra,Jb)
&(KJ,PR,ab)
&(Jb,PR,Ka)
\end{array}                                                     \tag{6}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,Ka,Pb)&(PR,Jb,Ka)&(PK,Ra,Jb)&(PR,Jb,Ka).
\end{array}                                                     \tag{7}
\]
The original vertices see, respectively,
\[
(PR,Ka,Jb),\quad
(K\lambda,Pt,Ra),\quad
(Ra,PK,Jb),\quad
(Ra,Pb,KJ),\quad
(PR,Jb,Ka),\quad
(PR,Jb,Ka).                                                 \tag{8}
\]
Every triple in (6)--(8) partitions \(\{P,R,K,J,a,b\}\), using \(\{\lambda,t\}=\{J,b\}\) at \(u_2\) and vertex \(2\). The port column in (6) is exactly (5), and \(e=ab\) is unchanged. The terminal pairs are \(e=ab,X=RJ,Z=PK,Y=W=PR\), forbidden \((eX)(eZ)\). Swapping \(a,b\) covers the other value of \(\nu\). Thus every \(\tau=J\) phase is also excluded.

No exact-Case-XII pole with this fixed marked exterior can contain a genuine \(B_3\) row. Together with [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md), [Note 467](467-the-x-z-hamilton-b1-row-forces-a-forbidden-ex-loop.md), and [Note 468](468-the-x-z-hamilton-b2-row-forces-a-forbidden-double-triple.md), all three \(B\) signatures are excluded; only \(C_1,\ldots,C_7\) remain for forbidden \(\{eX,eZ\}\). The path reflection gives the corresponding exclusion for \(\{eY,eW\}\). This hand proof changes only the exterior pairs and awaits independent review; it uses no OMEN or local mathematical recomputation. \(\square\)
