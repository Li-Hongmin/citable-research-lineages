> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No three-vertex six-cut Hall block in the right DJ branch

> **Subsequent refinement:** [Note 316](316-zero-port-phase-closure-restricts-the-four-vertex-hall-block.md)
> uses the first possible four-vertex incidence shape below to
> restrict zero-port phases and exclude one \((P,j)\) placement.
> The theorem below is unchanged.

Continue the noncollision, complete exact-Case-XII central-path branch
with a real left \((ea)(ac)\) row and a real right \((ea)(ad)\) row,
in the \(R_0=DJ\) one-edge-near-bipartite shore of
[Notes 312–314](314-zero-port-hexagon-flip-excludes-the-a-v0-j-placement.md).
The completed minimum host has girth at least five. Let \(S\) be a
tight \(DJ\) Hall witness, with \(\alpha\) proper \(B\)-port
incidences in \(S\) and \(\eta=e_K(S,d)\).

**Theorem 1.** No witness has \(|S|=3\) and
\((\alpha,\eta)=(2,1)\). Hence every six-edge Hall block in this
branch has at least four \(B\)-vertices. The \((1,2)\) allocation
still has the stronger bound \(|S|\ge5\) of
[Note 311](311-a-six-cut-hall-block-with-one-b-port-needs-five-b-vertices.md).

**Proof.** [Note 313](313-the-first-six-cut-hall-cycle-restricts-the-j-port.md)
puts every putative three-vertex block on the six-cycle
\[
                  h-u-k-z-\ell-v_0-h,                        \tag{1}
\]
with \(H\) at \(h\), \(P\in\{A,I\}\) at \(k\), and
\(\ell d\) the unique edge to the \(D\)-port base. Its remaining
\(J\)-base positions are \((P,j)=(A,v_0),(A,z),(I,u),(I,z)\).
[Note 314](314-zero-port-hexagon-flip-excludes-the-a-v0-j-placement.md)
excludes \((A,v_0)\) by the full zero-port matching closure. We
exclude the other three.

First let \((P,j)=(I,u)\). In the right row
\((X,Y,Z,U,V,W)\), the \(U(EJ)\) matching uses
\(hv_0,kz,\ell d\). Each \(Q\in\{Y,V\}\) selects ports
\(I,D\). If it used \(\ell z\), the complete path
\(D-d-\ell-z-k-I\) would occur in \(U\triangle Q\), contrary
to [Note 309's](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md)
forced \(EI\mid DJ\) pairing. Hence both \(Y,V\) use
\(\ell v_0,hu\) and select \(I\) at \(k\). Port \(J\) at
\(u\) is used by \(U,Z\), and \(hu\) by \(Y,V\), so edge
\(ku\) is used by \(X,W\). At \(k\), this makes \(kz\) used
by \(U,Z\); at \(\ell\), the \(Y,V\) pair has saturated
\(\ell v_0\), while \(Z\) cannot use \(\ell z\) because it
uses \(kz\). Therefore \(\ell d\) is used by \(U,Z\) and
\(\ell z\) by \(X,W\). The actual right zero-port matching
\(X(g,t_{ew})\) thus uses the full cycle matching
\[
                         \{hv_0,ku,\ell z\}.                  \tag{2}
\]
Switch the entire alternating six-cycle (1) in \(X\). The result
\(X'\) is another actual zero-port matching, still selecting
\(g,t_{ew}\), and now uses \(\{hu,kz,\ell v_0\}\). Its shore
complement contains the complete path \(I-k-u-J\).
[Note 285's](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
two genuine forbidden-\(eb\) exterior completions exclude this
\(IJ\) pairing: the completion \(P_0\) connects \(I\)--\(D\)
outside the shore and has its terminal arm at \(J\), putting the
two remaining same-side exceptions \(D,J\) in one component.
Equivalently, its full-fibre table allows only
\(EA\mid ID\mid HJ\) or \(EJ\mid AD\mid IH\). This is a
contradiction.

It remains to take \(j=z\), allowing either \(P=A\) or \(P=I\).
We claim that the right zero-port matching \(X(g,t_{ew})\) must use
both \(kz\) and \(\ell d\).

If \(P=A\), then \(U(EJ)\) uses \(hv_0,ku,\ell d\).
Each of \(Y,V\) uses one of the alternating matchings
\[
 M_0=\{hu,kz,\ell v_0\},\qquad
 M_1=\{hv_0,ku,\ell z\}.                                  \tag{3}
\]
They cannot both use \(M_1\), since \(U\) already uses
\(hv_0,ku\). If both use \(M_0\), the row load at \(h,k,z\)
forces \(X=M_1\) on the six-cycle; its shore complement has the
local \(A-k-z-J\) port path. This contradicts Note 285's complete
zero-port pairing gate. If they use different matchings, the row
load at \(h,k\) forces \(X\) to use \(hu,kz\). The vertex
\(\ell\) is then matched either to \(d\) or to \(v_0\).
The latter makes \(X=M_0\), whose complement contains
\(J-z-\ell-d-D\), again forbidden by Note 285. Hence \(X\)
uses \(kz,\ell d\).

If \(P=I\), again \(U\) uses \(hv_0,ku,\ell d\). Each
\(Q\in\{Y,V\}\) selects \(I,D\). Were it to use
\(\ell v_0\), its \(U\triangle Q\) difference would contain
the complete \(D-d-\ell-v_0-h-u-k-I\) path, contradicting
\(EI\mid DJ\). Thus both \(Y,V\) use \(\ell z\). At \(z\),
port \(J\) is used by \(U,Z\) and edge \(\ell z\) by
\(Y,V\), so \(kz\) is used by \(X,W\). Now \(X\) matches
\(\ell\) either to \(d\) or to \(v_0\). The latter makes a
full cycle matching whose complement contains
\(J-z-\ell-d-D\), forbidden as above. Therefore \(X\)
again uses \(kz,\ell d\).

Turn to the real left \(ac\) row
\((X_L,Y_L,Z_L,U_L,V_L,W_L)\), whose shore port sets are
\((\varnothing,HJ,EAID,EA,HJ,ID)\). Since \(j=z\), both
\(Y_L,V_L\) select \(J\); they do not select the \(P\) port
at \(k\), and so both use \(ku\). If \(P=A\), the \(A\)
port is used by \(Z_L,U_L\), forcing \(kz\) into
\(X_L,W_L\). If \(P=I\), the \(I\) port is used by
\(Z_L,W_L\), forcing \(kz\) into \(X_L,U_L\). In either
case, the three edges incident to \(z=j\) have row load two
only if \(Z_L\) selects \(\ell z\): its \(J\) port is
already used by \(Y_L,V_L\), and its \(kz\) edge by the indicated
pair of other slots.

The same \(Z_L\) selects proper port \(P\) at \(k\) and port
\(D\) at \(d\). Compare it with the actual right zero-port
\(X\), which uses \(kz,\ell d\). Their shore difference has the
whole local component
\[
                         P-k-z-\ell-d-D.                     \tag{4}
\]
It avoids \(g,t_{ew}\). Switching (4) into \(X\) produces an
actual two-proper-port shore perfect matching selecting
\(P,D,g,t_{ew}\), contrary to
[Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md),
which permits only \(HJ\) for that full two-port fibre. This
excludes both \((A,z)\) and \((I,z)\), finishing the proof.
\(\square\)

**Corollary (first possible \((2,1)\) six-cut incidence shape).**
If such a Hall witness exists, then \(|S|\ge4\). At \(|S|=4\),
put \(T=N_K(S)\setminus\{d\}\). There is one \(t_0\in T\)
adjacent to three vertices \(h,k,\ell\in S\); the other three
vertices of \(T\) each join the fourth vertex \(m\in S\) to
one of \(h,k,\ell\). After labelling those three vertices
accordingly, \(H\) is based at \(h\), one port
\(P\in\{A,I\}\) at \(k\), and the edge to \(d\) at
\(\ell\); \(m\) has no outward incidence.

**Proof.** Here \(|T|=4\) and
\(e_K(S,T)=3|S|-\alpha-\eta=9\). Girth at least five gives
\(\sum_{t\in T}\binom{e_K(S,t)}2\le\binom42=6\).
Convexity and \(e_K(S,t)\le3\) make the minimum of the left side
equal to six, attained only at degree multiset \((3,2,2,2)\).
Thus each pair in \(S\) has exactly one common \(T\)-neighbour.
The degree-three vertex covers the three pairs among its three
neighbours; the remaining three pair-neighbourhoods must join the
fourth \(S\)-vertex to each of those three. Their degrees into
\(T\) are respectively two and three, so cubicity puts the three
outward incidences at the first three vertices, one each.
\(\square\)

Neither the four-vertex incidence shape nor the larger Hall blocks
are realization certificates. The \((1,2)\) six-cut allocation
begins only at \(|S|=5\) by Note 311. Local collisions, other
profiles, and the full Berge–Fulkerson conjecture remain open. All
new arguments are hand-derived and rely on the cited complete
matching-fibre exclusions; no local recomputation or OMEN run was
used.
