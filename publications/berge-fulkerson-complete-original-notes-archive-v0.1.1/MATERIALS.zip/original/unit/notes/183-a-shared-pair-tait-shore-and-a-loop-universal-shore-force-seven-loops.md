> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A shared-pair Tait shore and a loop-universal shore force seven loops

Consider the genuine \(|U|=1\) two-five-cut connector of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md), with three marked \(A\)--\(B\) edges \(x,y,z\), the \(A\)--\(w\) mark \(\delta\), and the \(B\)--\(w\) mark \(\epsilon\). Suppose \(A^\circ\) has a **real three-edge-colouring whose lonely ports are two of \(x,y,z\)**. Each of seven specified BF loops on \(B^\circ\) forces a *different* BF loop on the opened pole \(H\), so any six of those seven already exclude exact Case XII. In particular, all ten \(B^\circ\) loops force seven outer loops, while any nine of ten force at least six. Exact Case XII permits only five.

The conclusion concerns actual six-perfect-matching rows. A BF loop on \(B^\circ\) need not arise from a three-edge-colouring: it supplies two triple-boundary matching occurrences and two singleton occurrences at each lonely port, which can be relabelled into three two-slot *macrocolours*. Use slot pairs \(1=\{1,2\}\), \(2=\{3,4\}\), and \(3=\{5,6\}\). Only these true boundary slot labels enter the connector.

Relabel the shared ports and permute the three colours of the given \(A^\circ\)-colouring so that its port colours in the order \((0,x,y,z,\delta)\) are
\[
\boxed{(1,3,1,2,1).}                                      \tag{1}
\]
Thus \(x,z\) are lonely and \(0,y,\delta\) have the majority colour. Double this colouring to obtain an actual BF row on \(A^\circ\), using two slots for each macrocolour.

Each \(B^\circ\) tuple in the following table has one colour on three ports and each other colour on one port. Whenever its loop type is supported, choose an **actual** row of that type and permute its six occurrence slots so that the five port labels are exactly the displayed macrocolour pairs. The \(B^\circ\) tuple is ordered \((0,x,y,z,\epsilon)\); the outer terminal tuple is ordered \((x,y,z,\delta,\epsilon)\).

| \(B^\circ\) port macrocolours | connector \((uw,wt_\delta,wt_\epsilon)\) | outer terminal macrocolours | forced outer loop |
|---|---|---|---|
| \((2,1,2,3,2)\) | \((3,2,1)\) | \((2,3,1,3,3)\) | \([xz]\) |
| \((2,2,3,1,2)\) | \((3,2,1)\) | \((1,2,3,3,3)\) | \([xy]\) |
| \((2,2,2,1,3)\) | \((3,2,1)\) | \((1,3,3,3,2)\) | \([x\epsilon]\) |
| \((2,1,3,3,3)\) | \((3,2,1)\) | \((2,2,1,3,2)\) | \([z\delta]\) |
| \((3,1,2,3,3)\) | \((2,3,1)\) | \((2,3,1,2,2)\) | \([yz]\) |
| \((3,1,3,3,2)\) | \((2,3,1)\) | \((2,2,1,2,3)\) | \([z\epsilon]\) |
| \((3,2,2,1,2)\) | \((2,3,1)\) | \((1,3,3,2,3)\) | \([x\delta]\) |

The input \(B^\circ\) loops in table order are \([xz],[yz],[z\epsilon],[0x],[xy],[x\epsilon],[0z]\), all distinct.

For every row, the \(A^\circ\) and \(B^\circ\) macrocolours differ at \(0,x,y,z\). The displayed connector colours are pairwise distinct at \(w\), and \(uw\) is the third colour at \(u\). At \(t_\delta\), the \(A^\circ\)-half has colour \(1\), different from \(wt_\delta\); at \(t_\epsilon\), the \(B^\circ\)-half has colour \(2\) or \(3\), different from \(wt_\epsilon=1\). Hence each entry satisfies the exact six-slot gate of Note 172, with each macrocolour standing for its own two occurrence slots. Fill each terminal by the third macrocolour at its subdivision vertex, as displayed. Every original shore edge retains load two, and each connector edge is assigned a two-slot label; each of the six slots remains a genuine perfect matching. The majority macrocolour of the outer terminal tuple appears at three terminals, and its two lonely positions give the stated BF loop. The seven outer loops and their seven \(B^\circ\) input loops are each distinct, so removing any one input leaves six outputs. \(\square\)

There are two immediate minimum-host consequences. A three-vertex tree shore has centre port \(0\) by [Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md); of its two end groups, one contains \(\delta\) and one shared port, while the other contains the remaining two shared ports. Its four genuine Tait states include a pair of shared ports. An ordinary pentagon shore also has such a state: its five lonely pairs form a five-cycle on the five ports, and any three vertices of that cycle contain an edge. The other shore may have the published Case-XIII \(L^*\) relation. Figure 7 gives it all ten loops; even the Appendix XIII transcription with its repeated \(45\) has nine distinct loops, which already suffice here. Therefore
\[
\boxed{\text{in the \(|U|=1\) two-five-cut profile, neither tree--\(L^*\)
nor pentagon--\(L^*\) can have exact Case-XII support}.}     \tag{2}
\]
The connector and proof are symmetric under exchanging \(A,\delta\) with \(B,\epsilon\), so (2) includes both orders of each shore pair. It does not infer a Tait colouring from an \(L^*\) BF loop, and it does not decide tree--\(R^*\), pentagon--\(R^*\), \(L^*\)--\(R^*\), or \(R^*\)--\(R^*\).

[Note 184](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) uses a fixed \(A^\circ\) Tait row against three actual opposite-shore *pair* types. It gives a necessary \(P/Q\)-block equality when the opposite shore has the \(R^*\) relation.
