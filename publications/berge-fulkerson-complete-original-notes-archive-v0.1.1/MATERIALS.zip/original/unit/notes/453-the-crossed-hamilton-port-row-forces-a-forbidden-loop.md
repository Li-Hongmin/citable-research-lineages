> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The crossed Hamilton port row forces a forbidden loop

Keep the Hamilton three-spoke exterior of [Notes 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md) and [451](451-two-end-port-phases-force-forbidden-rows-in-the-hamilton-prism.md): the tree is
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36).
\]
Let a genuine BF row of type \((eX)(eY)\) have six **complete** matching occurrences \(P=eX,R=eY,K=Y,J=X,a=e,b=e\). Suppose its labelled shore-port pairs are the crossed form left in Note 451(7):
\[
(p_1,p_2,p_3,p_4,p_5)=(Ja,Ka,Jb,Kb,ab),
\qquad e=ab.                                      \tag{1}
\]
The symbols \(a,b\) are distinct singleton-\(e\) occurrence labels; their complete shore restrictions may differ. No condition on the shore graph or on the six complete shore restrictions is imposed.

**Crossed-port closure.** Every row satisfying (1) forces a genuine BF row of type \([eX]\) in the same five-pole. The new row uses each of the six original complete shore restrictions, attached to the occurrence with the same name. Consequently (1) is impossible when the complete support omits \([eX]\), including exact Case XII with forbidden pair \(\{eX,eW\}\).

Here is the new exterior restriction. At a tree subdivision, list the pair on the first-end half, second-end half, and proper port. At a marked subdivision, list the terminal pair and then the two marked halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(Rb,PK,Ja)&(RJ,Pb,Ka)&(Ra,PK,Jb)&(Ja,PR,Kb)&(KJ,PR,ab)
\end{array}                                                    \tag{2}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,Pa,Rb)&(PR,KJ,ab)&(PR,ab,KJ)&(PR,KJ,ab).
\end{array}                                                    \tag{3}
\]
The terminal pairs in (3) are \(KJ\) at \(X\) and \(PR\) at \(Y,Z,W\). Thus \(P,R\) are both zero-port \(eX\)-triples, \(K,J\) are singleton-\(X\), and \(a,b\) are singleton-\(e\): the row has type \([eX]\). The port column of (2) is exactly (1).

For completeness, the incident pairs at original vertices \(1,\ldots,6\), in their tree/marked-edge order, are
\[
(Rb,Pa,KJ),\quad(PK,RJ,ab),\quad(Pb,Ra,KJ),\quad
(PK,Ja,Rb),\quad(PR,KJ,ab),\quad(PR,KJ,ab).       \tag{4}
\]
Every triple in (2)--(4) partitions \(\{P,R,K,J,a,b\}\). Hence every occurrence selects one incident edge at every exterior vertex, and every exterior edge has load two. At all five proper shore ports and at terminal \(e\), the new occurrence pair is exactly the old pair. Gluing occurrence by occurrence to the **unchanged complete shore matchings** proves the claim. This is an all-order graph-induced closure implication; it does not require the two zero-port shore matchings to agree.

[Note 452](452-a-real-crossed-port-row-has-both-forbidden-hamilton-loops.md) supplies a real crossed row and independently exhibits forbidden loops in its full support. It therefore demonstrates sharpness of shore realizability but is consistent with this stronger rowwise closure. The two non-crossed phases were excluded in Note 451, so the specific fifth-line tree-half choice \(K:2u_1,4u_3,5u_5\) in Note 446(3) is now wholly excluded under exact Case XII. The other three choices in that fifth line, the two sixth-line choices, other forbidden pairs, and the full Berge--Fulkerson conjecture remain open. This certificate is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
