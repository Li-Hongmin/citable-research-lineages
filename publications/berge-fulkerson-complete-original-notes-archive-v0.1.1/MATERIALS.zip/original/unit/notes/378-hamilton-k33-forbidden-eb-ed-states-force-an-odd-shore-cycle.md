> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two forbidden \(e\)-states force an odd shore cycle in the Hamilton \(K_{3,3}\) exterior

Keep the \(|U|=r=5\) Hamilton-path \(K_{3,3}\) exterior of [Note 377](377-hamilton-k33-adjacent-ab-pair-has-no-case-xii-row.md):
\[
x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t,
\qquad a=xs,\quad b=xt,\quad c=yt,\quad d=zr.
\]
Write \(p_i\) for the proper shore port at \(u_i\), and \(Z\) for the arbitrary complete six-port shore with ports \(e,p_0,\ldots,p_4\). A zero-port shore matching \(Q\) is a complete perfect matching of \(Z\) using none of its ports. By [Notes 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), every such \(Q\) glues to both rooted zero-port triples in each state \(ej\).

**Two-state parity theorem.** Suppose \(Z-Q\) has no odd closed component. Then at least one of the four complete triples of states \(eb,ed\), with their two roots apiece and common shore matching \(Q\), extends to a genuine three-edge-colouring of the five-pole. Equivalently, at least one of the BF loops \([eb],[ed]\) belongs to the full perfect-matching support.

Consequently, if the pole has exact Case-XII support with \(e\)-neighbour pair \(\{a,c\}\), **every** zero-port shore matching \(Q\) has an odd closed component in \(Z-Q\). In particular, the two zero-port triples of any genuine BF row \((ej)(ek)\), including a loop, must use different complete shore matchings. The statement holds for every shore order and cycle rank in this exterior profile.

**Colourability corollary.** Under the same exact-support hypothesis, the pole has no three-edge-colouring. In fact, a three-edge-colouring at any state of the allowed pentagon would force three-edge-colourings at all five of its states, including \(ea\) and \(ec\), whereas the preceding odd-cycle condition rules out both.

**Proof.** Delete a zero-port triple from the exterior and follow the degree-two paths from the unused terminal to the five ports. The two roots of state \(eb\) induce the same pairing, while the two roots of state \(ed\) induce the other two pairings:

| state and root | exterior pairing |
|---|---|
| \(eb\), root \(x\) or \(t\) | \(b p_2\mid p_0p_3\mid p_1p_4\) |
| \(ed\), root \(z\) | \(d p_0\mid p_1p_2\mid p_3p_4\) |
| \(ed\), root \(r\) | \(d p_4\mid p_0p_1\mid p_2p_3\) |

For example, at the \(eb\) root \(x\), the unused \(b\)-half leads through \(t,c,y\) to \(p_2\), while the two remaining paths run \(p_0,x,a,s,p_3\) and \(p_1,r,d,z,p_4\). At the \(ed\) root \(z\), the paths are \(d,r,p_0\), \(p_1,y,c,t,b,x,a,s,p_2\), and \(p_3,z,p_4\). Reversing the tree checks the other two entries. As in [Note 359's parity lemma](359-two-root-parity-gate-and-k33-sharpness.md), every exterior path has even length, with terminal and port semiedges counted. Since \(Z-Q\) has no odd closed component, the triple fails to extend to a Tait colouring exactly when a cycle made by gluing shore and exterior paths contains an odd number of odd shore paths.

The three paths in \(Z-Q\) pair its six ports. Write their pairing as \(ep_k\mid\tau\), where \(\tau\) pairs the other four ports; \(ij\) below abbreviates \(p_ip_j\). Assign each shore path its length parity \(\sigma\in\{0,1\}\). The following cases exhaust the five choices of \(k\) and three pairings \(\tau\) for each choice; \(B,D_z,D_r\) denote the three exterior pairings in the table.

* \(k=1\): for \(\tau=02\mid34\) or \(04\mid23\), the \(B\) gluing is one open \(e\)--\(b\) path with no closed component; for \(\tau=03\mid24\), the \(D_z\) gluing is one open \(e\)--\(d\) path. Thus one Tait extension exists regardless of path parities. Tree reversal gives the same conclusion for \(k=3\).
* \(k=0\): for \(\tau=12\mid34\) or \(13\mid24\), the \(D_r\) gluing has no closed component. For the last pairing \(\tau=14\mid23\), the only closed component of \(B\) has parity \(\sigma_{14}\), that of \(D_r\) has parity \(\sigma_{23}\), and that of \(D_z\) has parity \(\sigma_{14}+\sigma_{23}\pmod2\). All three cannot be odd. Tree reversal gives the same conclusion for \(k=4\).
* \(k=2\): for \(\tau=03\mid14\) or \(04\mid13\), the \(D_z\) gluing has no closed component. For \(\tau=01\mid34\), the only closed component of \(D_r\) has parity \(\sigma_{01}\), that of \(D_z\) has parity \(\sigma_{34}\), and that of \(B\) has parity \(\sigma_{01}+\sigma_{34}\pmod2\). Again all three cannot be odd.

Thus at least one of \(B,D_z,D_r\) has only even closed components. The complement of its complete triple splits into the other two actual perfect matchings, giving the stated three-edge-colouring and, after doubling, the BF loop. For either Case-XII pentagon with \(e\)-neighbour pair \(\{a,c\}\), \(eb,ed\in T\), so both loops are forbidden by [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Hence every zero-port \(Q\) must have an odd closed component in \(Z-Q\).

If a BF row contained two zero-port triples sharing the same \(Q\), its four singleton matchings would have to cover the residual of \(2Q\) twice. On an odd closed component of \(Z-Q\), the required two singleton colours on consecutive residual edges alternate with their complement, which is impossible after an odd number of steps; this is [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). The two shore matchings are therefore distinct. \(\square\)

For the colourability corollary, suppose a three-edge-colouring has lonely terminals \(i,j\). Doubling it gives the BF loop \([ij]\), so \(ij\in S\). Exchange the colour lonely at \(i\) with the triple colour along their alternating path starting at \(i\). The path ends at one of the three triple terminals, and the exchange is another genuine three-edge-colouring whose lonely pair still contains \(j\). Of the three possible new pairs, exactly one is in the allowed pentagon \(S\): the other edge at \(j\). Thus that adjacent edge also has a three-edge-colouring. Exchanging the other lonely colour gives the other adjacent edge at \(i\). Iterating around the pentagon reaches \(ea\) and \(ec\). A three-edge-colouring of either state would contain a zero-port \(ej\) triple whose complement has only even closed components, contradicting the odd closed component of \(Z-Q\). \(\square\)

The theorem is a full-perfect-matching restriction on the remaining Hamilton \(K_{3,3}\) pair, not an exclusion of that pair: a positive \((ea)(ac)\) row has only one zero-port triple, and two distinct shore matchings may still support a positive two-zero-port row. It does not settle triangular-prism exteriors or the general exact Case XII obstruction. This is a hand proof without local mathematical recomputation or independent review.
