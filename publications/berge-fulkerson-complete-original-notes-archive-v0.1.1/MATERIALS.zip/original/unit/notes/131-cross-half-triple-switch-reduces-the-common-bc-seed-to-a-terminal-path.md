> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cross-half triple switch retains both complete seed singletons

**Subsequent resolution of one conditional branch.** [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) rules out the Tait-empty mixed-side setting itself whenever the right cell exists. The general cross-half full-mask statements below remain valid; the mixed-side \(5\leftrightarrow4\) alternative is now a vacuous conditional branch under complete negative support.

[Note 135](135-a-hot-class-four-right-row-forces-the-bad-cross-half-terminal-pairing.md) identifies a nonvacuous surviving use of that \(5\leftrightarrow4\) pairing: it is forced for every mixed-side right row whose class-four singleton uses both exceptional edges, and it describes the complete class-four cycle-phase family of cold partner rows.

**Stronger full-mask conclusion.** [Note 136](136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md) shows that the \(5\leftrightarrow2\) path below also yields the common complete \(B_2,C_4\) seed by exchanging the two class-two singleton occurrences. Hence only \(5\leftrightarrow4\) can survive if there is no seed. The endpoint-\(2\) discussion below remains a correct half-load identity, but is no longer a seed obstruction.

The right row of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md) has a Kempe move between its *two triple matchings*. Unlike a switch confined to one half-load, this move retains the complete masks of all four singleton occurrences, including both designated \(B_2,C_4\). The negative Case-XII support forces its terminal pairing. A second terminal pairing then gives an explicit sufficient condition for the common-\(B,C\) seed; failure produces a particular all-\(S\) carrier. This is a reduction of the full-mask obstruction, not a proof that the seed always exists.

## Fixed-singleton cross-half switch

Put \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole with no BF cover of all-terminal type \((12345)\), no \(T\)-loop, and no \(T\)--\(T\) type. Suppose actual complete perfect matchings form a right seed row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.                 \tag{1}
\]
There are actual triple matchings \(p_{35},t_{24}\) such that
\[
\boxed{q_{25}+r_{34}=p_{35}+t_{24},\qquad
p_{35}+B_2+D_5+t_{24}+Y_3+C_4=2\mathbf1.}               \tag{2}
\]
All four singleton masks in (2) are literally those in (1).

**Proof.** Consider the two-colour edge-copy graph of \(q_{25}+r_{34}\). The two matchings both use terminal 1, whose two semiedge copies form a two-edge component. The other terminal ends are \(2,5\) in \(r_{34}\) and \(3,4\) in \(q_{25}\). If the terminal path from 2 ended at 5, switching it would turn \(q_{25}\) into an all-terminal matching and \(r_{34}\) into a class-one singleton. Together with the four fixed singletons this would be a forbidden \((12345)\) BF row. If that path ended at 4, the switched triples would have missing pairs \(45,23\in T\), a forbidden \(T\)--\(T\) row. It must therefore end at 3. Switching that path changes the triple boundaries from \(25,34\) to \(35,24\), preserves their complete pair load, and proves (2). The other terminal path connects 5 to 4. Closed two-colour components may be toggled independently without changing (2). \(\square\)

The all-terminal exclusion rules out the \(2\leftrightarrow5\) pairing; the \(T\)--\(T\) exclusion rules out \(2\leftrightarrow4\). Neither exclusion is silently replaced by the other in this proof.

The seven-vertex full-PM pole of [Note 128](128-mixed-side-unique-companion-can-fail-the-full-cycle-phase.md) supplies a genuine failure when the \(T\)--\(T\) exclusion is removed. In its displayed right row \(q_{25}=M_6\), \(r_{34}=M_9\), the two-colour path is \(s_2,g_5,g_0,s_4\), joining 2 to 4. Switching it gives actual missing pairs \(45,23\in T\), while the four singleton masks stay unchanged. Thus the forced \(2\leftrightarrow3\) conclusion is genuinely using complete negative BF support.

## The remaining terminal-path test

In (2) let \(P\) be the unique terminal path of \(p_{35}+D_5\) beginning at terminal 5. Its other end belongs to \(\{1,2,4\}\).

* If \(P\) ends at **1**, then the common-\(B,C\) seed exists. Switching \(P\) gives
  \[
  p_{35}+D_5=q_{13}+A_1.                                  \tag{3}
  \]
  Now consider the two-colour graph of \(q_{13}+t_{24}\). The triples share terminal 5; their other terminal ends are \(2,4\) in \(q_{13}\) and \(1,3\) in \(t_{24}\). The path from 3 cannot end at 1, since switching the two \(t_{24}\)-only ends would create an all-terminal matching. It cannot end at 2, since the new missing pairs would be \(12,34\in T\). Thus it ends at 4. Switching it gives the literal left row
  \[
  \boxed{q_{14}+A_1+C_4+r_{23}+B_2+Y_3=2\mathbf1.}          \tag{4}
  \]
  Equations (1) and (4) share the complete \(B_2,C_4\) masks, and even retain the complete class-three mask \(X_3=Y_3\).

* If \(P\) ends at **2** or **4**, switching it gives a decomposition at state \(23\in T\) or \(34\in T\), respectively, of the half-load
  \[
  J=p_{35}+D_5+Y_3.
  \]
  Its complementary half-load is
  \[
  L=t_{24}+B_2+C_4=2\mathbf1-J,                          \tag{5}
  \]
  already decomposed at state \(24\in S\). Since \(J\) has a \(T\)-state and the complete BF support has no \(T\)-loop or \(T\)--\(T\) type, **every** decomposition state of \(L\) lies in \(S\). The column-saturation theorem of [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) then gives exactly \(\mathcal R(L)=S\). It does not keep \(B_2,C_4\) as named occurrences in every decomposition.

  In the endpoint-\(2\) case, the class-two occurrence exchange of Note 136 *does* keep the original complete \(B_2,C_4\) in a new left row. Only endpoint \(4\) remains unresolved by these operations.

The test \(P:5\leftrightarrow1\) is exact for producing (3) while keeping the complete \(Y_3\) mask and the fixed pair load \(p_{35}+D_5\): two-colour terminal-path pairings cannot be altered by switching closed components of that pair. Endpoint \(2\) gives the seed by a different occurrence exchange (Note 136). Other BF rows or other cycle phases of \(q_{25}+r_{34}\) can still produce the common seed when the path ends at \(4\).

## A common-path confluence criterion

There is a more direct, graph-theoretic sufficient condition that compares the two forced \(2\leftrightarrow3\) routes. In the original row (1), switching the \(q_{25},B_2\) terminal path from 2 must end at 3: endpoints 1 and 4 would turn the \(S\)-half into states \(15,45\in T\) against the unchanged \(T\)-half of state 34. The cross-half \(q_{25},r_{34}\) path from 2 also ends at 3 by (2). The two paths need not have the same complete edges.

Write \(\mathcal P_{35}(H)\) for the actual triple-boundary matchings missing terminals 3 and 5, and define
\[
\mathcal F=
\{Q\in\mathcal P_{35}(H):Q\le q_{25}+B_2
                         \text{ and }Q\le q_{25}+r_{34}\}.       \tag{6}
\]
The inequalities are coordinatewise on *all* proper and terminal edges. For any \(Q\in\mathcal F\), cubicity makes
\[
Z_3=q_{25}+B_2-Q,\qquad t_{24}=q_{25}+r_{34}-Q             \tag{7}
\]
actual perfect matchings, with the indicated complete boundaries. Thus \(Q+B_2+D_5+t_{24}+Y_3+C_4=2\mathbf1\). The fixed \(T\)-half \(r_{34}+Y_3+C_4\) in (1) forces the \(Q,D_5\) terminal path from 5 to end at 1: its other possible ends 2 and 4 would give forbidden \(T\)--\(T\) rows. The last forced triple switch in (3)--(4) therefore proves
\[
\boxed{\mathcal F\ne\varnothing\ \Longrightarrow\
       \Lambda_L(H)\cap\Lambda_R(H)\ne\varnothing.}              \tag{8}
\]

The condition \(\mathcal F\ne\varnothing\) has an exact path form:
\[
\boxed{\text{There is a \(q_{25}\)-alternating terminal path from 2 to 3
whose non-\(q_{25}\) edges all belong to \(B_2\cap r_{34}\).}}       \tag{9}
\]
To prove this, note that domination by both pair loads is equivalent to every edge of \(Q\setminus q_{25}\) belonging to \(B_2\cap r_{34}\). Since \(q_{25}\) and \(Q\) differ only at terminal positions 2 and 3, their symmetric difference consists of one such open alternating path and zero or more closed alternating cycles. Keep only the open path and toggle it in \(q_{25}\); the resulting actual triple matching still satisfies both inequalities in (6). Conversely, toggling a path as in (9) produces a member of \(\mathcal F\). This is an exact criterion for **this confluence mechanism**; the common-\(B,C\) seed can exist even when \(\mathcal F\) is empty.

## Mixed-side Tait-empty specialization

Assume additionally the mixed-side \(4+1\) bipartization of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md), with terminal 2 alone on the minority side and exceptional edges \(e\subset X,f\subset Y\). Suppose the Tait-state set is empty. By [Notes 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) and [130](130-the-mixed-side-right-row-exceptional-class-three-forces-an-s-tait-state.md), from any right row one may choose a right row with the same complete \(B_2,Y_3,r_{34}\) masks and profiles
\[
  (q_{25},B_2,D_5,r_{34},Y_3,C_4)\big|_{e,f}
  =((0,1),(1,0),(0,0),(0,0),(0,0),(1,1)).       \tag{10}
\]
The cross-half switch in (2) then has
\[
  p_{35}|_{e,f}=(0,0),\quad t_{24}|_{e,f}=(0,1),
  \quad J|_{e,f}=(0,0),\quad L|_{e,f}=(2,2).      \tag{11}
\]
Indeed \(q_{25}+r_{34}\) has profile \((0,1)\), and every \(X2\)-missing triple such as \(t_{24}\) has profile \((0,1)\). Thus \(J\) is a three-edge-coloured cubic edge-copy multigraph supported entirely in the bipartite graph \(H-\{e,f\}\).

Here \(P\) cannot join 5 in \(X\) to 2 in \(Y\). It would have an even number of proper edges by alternation between the distinct terminal colours, whereas every \(X\)--\(Y\) path in \(H-\{e,f\}\) has an odd number. Consequently the remaining test has only two outcomes:
\[
\begin{array}{c|c}
P\text{ joins }5\text{ to }1 &\text{the literal common-}B_2,C_4\text{ seed (4) follows},\\
P\text{ joins }5\text{ to }4 &J\text{ has state }34\in T,
\quad\mathcal R(L)=S.
\end{array}                                                   \tag{12}
\]
In the second outcome the switched triple \(q_{34}\) is an actual matching avoiding \(e,f\). Since \(34\in T\) is not a Tait state, [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) also requires \(e,f\) to lie in different components of \(H-q_{34}\). This is the concrete graph-induced obstruction left by this route: all admissible closed-cycle phases of the cross-half triple pair would need to avoid the \(5\leftrightarrow1\) path, or a different four-colour recolouring would have to provide the seed.

There is a sharper necessary cycle-phase witness if the pole has **no common seed at all**. In the original row, switch \(q_{25},B_2\) from state 25 to state 35 inside its \(S\)-half, retaining \(D_5\) and the \(T\)-half of state 34. This gives another actual triple \(Q^{A}_{35}\); the subsequent \(Q^{A}_{35},D_5\) path must join 5 to 1, because the other endpoints give forbidden \(T\)--\(T\) rows. Tait-emptiness forces \(Q^{A}_{35}\) to avoid \(e,f\), since a class-35 triple using both would extend to an \(S\)-Tait colouring. The cross-half triple \(p_{35}\) also avoids \(e,f\), but with no seed its \(D_5\) path must join 5 to 4 by (12). Therefore \(Q^{A}_{35}\ne p_{35}\), and
\[
Q^{A}_{35}\triangle p_{35}
\]
is a nonempty union of proper even alternating cycles entirely in \(H-\{e,f\}\). Moreover \(Q^{A}_{35}\not\le q_{25}+r_{34}\), for otherwise (8) would give the common seed. This identifies an actual off-profile phase and a failed complete-mask domination inside the full perfect-matching family. It is a necessary form of a seed counterexample, not a construction of one.

The original Proposition 4.4 and Case-XII appendix of Máčajová--Mazzuoccolo--Tabarelli, *Ars Mathematica Contemporanea* 26 (2026), DOI 10.26493/1855-3974.3409.c13, specify the boundary support; they do not assert the complete-matching identity in (4). Note 132 excludes the Tait-empty mixed-side branch; the full intersection \(\Lambda_L\cap\Lambda_R\) in the surviving branches and the Berge--Fulkerson conjecture remain open.
