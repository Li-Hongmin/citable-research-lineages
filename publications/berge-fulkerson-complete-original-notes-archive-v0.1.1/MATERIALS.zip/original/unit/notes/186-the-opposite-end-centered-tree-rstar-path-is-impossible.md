> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An opposite-end centred tree--R-star path is impossible

Retain the \(|U|=1\) minimum-host two-five-cut profile, with a tree shore \(A^\circ\) whose centre port is \(0\) and whose end groups are \(\{\delta,x\}\mid\{y,z\}\), opposite a Case-XIII \(R^*\) shore \(B^\circ\). Suppose the forbidden Case-XII five-cycle is
\[
\boxed{T=\delta-\epsilon-x-y-z-\delta.}                 \tag{1}
\]
Thus \(\delta,\epsilon\) are adjacent, the shared \(T\)-path is centred at \(y\), and its special tree port \(x\) is the endpoint attached to \(\epsilon\). This configuration is impossible. Swapping the two ports \(y,z\) covers the analogous path centred at \(z\) with \(x\) attached to \(\epsilon\).

Write \(c(p)\in\{P,Q\}\) for the block of local missing-pair state \(p\) in the full \(R^*\) BF relation. Since \(xy,yz\in T\), [Note 184, (2)](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md), applied to the tree's shared Tait state \(xy\), forces
\[
c(xy)=c(xz).                                            \tag{2}
\]
Next, the two actual six-slot compositions in [Note 185](185-the-centered-tree-rstar-path-forces-a-forbidden-bf-pair.md) use the tree's \(\delta y\) Tait state and send either opposite-shore type \((xy)(z\epsilon)\) or \((yz)(x\epsilon)\) to the same outer type \((xy)(\delta z)\). Here \(xy,\delta z\in T\), so exact Case XII excludes both inputs. Since \(R^*\) supports every cross-block pair, this gives
\[
c(xy)=c(z\epsilon),\qquad c(yz)=c(x\epsilon).           \tag{3}
\]
These two transports and their slot tables hold independently of the \(T\)-cycle orientation used in Note 185; only the final check that the output is forbidden changes here.

One more actual pair row supplies the missing equality. Use the tree's Tait state \(\delta z\), with port macrocolours \((0,x,y,z,\delta)=(1,1,1,2,3)\). In its doubled row, slots \(1,2\) have tree boundary \(\{0,x,y\}\), slots \(3,4\) boundary \(\{z\}\), and slots \(5,6\) boundary \(\{\delta\}\). If \(B^\circ\) supports \((yz)(z\epsilon)\), assign its actual row the following boundary subsets and connector labels:

| slot | \(B^\circ\) boundary |
|---|---|
| 1, 2 | \(\{z\}\) in each slot |
| 3 | \(\{y\}\) |
| 4 | \(\{0,x,\epsilon\}\) |
| 5 | \(\{\epsilon\}\) |
| 6 | \(\{0,x,y\}\) |

Set \(uw=\{3,5\}\), \(D_\delta=\{2,4\}\), and \(D_\epsilon=\{1,6\}\). The port labels at \(0,x,y,z\) are disjoint across shores; \(X_\delta=\{5,6\}\), \(Y_\epsilon=\{4,5\}\), so \(X_\delta\cap Y_\epsilon=\{5\}\subseteq uw\). Hence [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) complete gate holds and the six slots glue to actual perfect matchings. The outer terminal labels at \(x,y,z,\delta,\epsilon\) are
\[
\{3,5\},\ \{4,5\},\ \{5,6\},\ \{1,3\},\ \{2,3\}.
\]
Outer slot \(3\) has terminal boundary \(\{x,\delta,\epsilon\}\), missing \(yz\); slot \(5\) has \(\{x,y,z\}\), missing \(\delta\epsilon\). Thus the supported \(R^*\) type \((yz)(z\epsilon)\) would produce the forbidden outer type \((yz)(\delta\epsilon)\), because both states lie in \(T\) of (1). Therefore
\[
c(yz)=c(z\epsilon).                                    \tag{4}
\]

Equations (2)--(4) force
\[
c(xy)=c(xz)=c(yz)=c(x\epsilon)=c(z\epsilon).            \tag{5}
\]
The first three states form a monochromatic triangle on the shared ports. In the Figure-7 \(R^*\) partition, \(P=\{13,14,24,35,45\}\) is triangle-free, while \(Q=\{12,15,23,25,34\}\) has exactly one triangle on \(\{1,2,5\}\). Hence \(\{x,y,z\}=\{1,2,5\}\) and the common block in (5) is \(Q\). The other two shore ports \(0,\epsilon\) are \(\{3,4\}\). Among all six edges from \(\{1,2,5\}\) to \(\{3,4\}\), only \(23\) belongs to \(Q\). The two distinct edges \(x\epsilon,z\epsilon\) cannot both be in \(Q\), contradicting (5). \(\square\)

This excludes the centred-at-\(y\) or centred-at-\(z\) adjacent-\(\delta\epsilon\) orientation in which \(x\) attaches to \(\epsilon\). Together with Note 185, it leaves the orientation where \(x\) attaches to \(\delta\), and the case \(\delta\epsilon\notin T\), for tree--\(R^*\) shores. It does not settle pentagon--\(R^*\) or the two non-pentagonal cyclic-shore combinations.

[Note 187](187-the-tree-rstar-adjacent-special-ports-are-impossible.md) excludes the remaining adjacent-\(\delta\epsilon\) orientation by two further actual pair rows. Thus this tree--\(R^*\) profile now requires \(\delta\epsilon\notin T\).
