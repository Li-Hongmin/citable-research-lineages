> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No exact Case-XII pole has this marked two-spoke prism exterior

Use the two-spoke triangular-prism exterior of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Its tree subdivisions \(u_1,\ldots,u_5\) lie on \(AB,BC,Aa,Bb,ac\), its four marked terminals are \(X=AC,\ Y=Cc,\ Z=bc,\ W=ab\), and the sixth terminal \(e\) lies on an arbitrary six-port shore. [Notes 413](413-two-spoke-prism-exact-case-xii-requires-odd-zero-port-complements.md), [419](419-an-exterior-reslotting-excludes-the-last-adjacent-prism-row.md), [421](421-the-ab-bc-forbidden-pair-has-no-prism-mixed-cell.md), and [422](422-the-ac-ab-forbidden-pair-has-no-prism-mixed-cell.md) exclude five of the six possible forbidden \(e\)-pairs. This note treats the last pair \(\{X,Y\}\).

The two allowed pentagons with \(eX,eY\in T\) are
\[
S_1=e-Z-X-Y-W-e,\qquad S_2=e-Z-Y-X-W-e.               \tag{1}
\]
For both, \(eZ,eW\in S_i\). The [published Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eY)(eW)\) and forbids every \(T\)--\(T\) cell.

> **Exterior exclusion.** No cubic five-pole with this marked prism exterior and an arbitrary shore has complete exact Case-XII BF boundary support. In particular the required \((eY)(eW)\) cell cannot be realized under either pentagon in (1).

Suppose that cell has six complete perfect-matching occurrences. Write \(P=eY\) for its forbidden triple, \(R=eW\) for its allowed triple, \(K=W\), \(J=Y\) for the corresponding singleton occurrences, and \(D_0,D_1=e\) for the two singleton-\(e\) occurrences. Switching the \(W\)-starting path of \(R\triangle K\) must change \(R\) to \(eZ\), since the other possible new \(e\)-pairs \(eX,eY\) remain forbidden beside unchanged \(P\in T\). Both roots \(C,c\) of \(P=eY\) take \(bu_4\).

**The \(b\)-root of \(R=eW\) is impossible.** Here the tree slots of \(R\) are \((A,C,a,B,c)\). Starting at \(W\), the path of \(R\triangle K\) enters \(b\). Its direct allowed exit is \(W-t_W-b-t_Z-Z\), with \(K:Z:b\). If it instead takes \(bu_4\), it reaches \(B\). The \(Bu_2\) branch reaches \(C\) and can end only at forbidden \(X\) or \(Y\). The \(Bu_1\) branch reaches \(A\); \(X:A\) is forbidden, so it continues through \(Au_3,a,au_5,c\), where \(Y:c\) is forbidden and \(Z:c\) is the only allowed endpoint. But such a \(K\) occupies \(A\) through \(Au_3\) and \(c\) through \(Z:c\). It would have to cover both the \(X=AC\) and \(Y=Cc\) subdivisions at their common endpoint \(C\), which one matching cannot do. Thus the direct path is the only possibility.

Switch it to \(R'=eZ:b\), leaving \(R\)'s complete shore mask unchanged. At \(b\), \(P,R,K\) take \(bu_4,W:b,Z:b\), one each. Of \(J,D_0,D_1\), at least one \(e\)-singleton \(D\) takes \(W:b\) or \(Z:b\). In \(R\triangle D\) and \(R'\triangle D\), the exterior \(X\)- and \(Y\)-terminal components are then unchanged: only the \(W/Z\) terminal arm is relabelled by the short path through \(b\). If \(X,Y\) join wholly outside the shore, the prescribed \(e\)-switch is already impossible; otherwise their unchanged arms have distinct shore exits. The shore \(e\)-path has the same first proper exit against \(R,R'\). Under \(S_1\), it must select \(Y\) against \(R=eW\) and \(X\) against \(R'=eZ\); under \(S_2\) it must select \(X,Y\), respectively. Both demands contradict the fixed exit. Therefore \(R\) is rooted at \(a\).

**The \(a\)-root has one exterior escape.** Its tree slots are \((B,C,A,b,c)\). Starting at \(W\), \(K\) may take \(au_5\), reach \(c\), and end at \(Z:c\); the \(Y:c\) alternative is forbidden. Yet \(P,R\) both take \(bu_4\), so \(K\) could cover \(b\) only by \(W:b\) or \(Z:b\). The first is unavailable because \(K\) already takes the \(W\) terminal, and the second because it would also take \(Z:c\). Hence this route is impossible.

The path must take \(au_3\), reach \(A\), avoid forbidden \(X:A\), and follow \(Au_1\) to \(B\). The \(Bu_2\) branch reaches forbidden \(X\) or \(Y\), so it takes \(Bu_4\), reaches \(b\), and ends at allowed \(Z:b\). In \(K\), the \(A\)-endpoint of \(X\) and the \(b\)-endpoint of \(Z\) are occupied; covering the remaining marked subdivisions forces
\[
K:\quad W\text{ terminal},\quad X:C,\quad Y:c,\quad Z:b,
\quad Au_1,\ au_3,\ Bu_4,\quad p_2,p_5.               \tag{2}
\]
Switch this wholly exterior \(W\to Z\) path between \(R,K\). The resulting allowed triple \(R'=eZ:b\) has the **same complete shore mask** as \(R\). Its rooted tree slots are \((A,C,a,B,c)\); both \(R,R'\) take \(cu_5\).

**The \(C\)-root of \(P=eY\) is impossible.** Here \(P\) takes \(Y:C\), whereas \(R,J\) take the \(Y\) terminal and \(K\) takes \(Y:c\). Thus the two \(e\)-singleton occurrences split the remaining \(Y:C,Y:c\) slots. Choose \(D\) taking \(Y:c\). Since \(P,R\) take \(Z\) terminal and \(K:Z:b\), this \(D\) takes \(Z:b\); it then takes \(W:a\). Both \(a,c\) are covered at marks, so \(D\) has port \(p_5\). Against both \(R\) and \(R'\), the \(Y\)-terminal arm is the same exterior path
\[
Y-t_Y-c-u_5-p_5.                                      \tag{3}
\]
The shore \(e\)-path has the same first proper exit in the two comparisons. In \(S_1\), \(eW\) must switch to \(YW\), requiring \(p_5\), while \(eZ\) must switch to \(XZ\), requiring another port. In \(S_2\), these requirements reverse: \(eW\to XW\) requires another port, while \(eZ\to YZ\) requires \(p_5\). Both are impossible.

**The \(c\)-root of \(P=eY\) is impossible.** Now \(P,R\) both take \(Cu_2\) and \(Bu_1\). They take the \(X\) terminal, while \(K:X:C\). Also \(P,K\) saturate \(Y:c\), and \(R,J\) take the \(Y\) terminal. Edge loads at \(C,X,Y\) force
\[
J:X:C,\qquad D_0,D_1:X:A,\ Y:C.                       \tag{4}
\]
At \(B\), neither \(D_i\) may use \(Bu_1\), which \(P,R\) saturate. It therefore takes \(Bu_2\) or \(Bu_4\), and its \(u_1\)-slot is \(p_1\).

For either \(D_i\), the exterior \(X\)-arm of \(R'\triangle D_i\) is
\(X-t_X-A-u_1-p_1\). The \(Y\)-arm of \(R\triangle D_i\) also exits at \(p_1\) if \(D_i:Bu_2\), following \(Y-t_Y-C-u_2-B-u_1-p_1\); if \(D_i:Bu_4\), it exits at \(p_2\). Under \(S_1\), the fixed shore \(e\)-path must target \(Y\) against \(R=eW\) and \(X\) against \(R'=eZ\). Thus every \(D_i\) must take \(Bu_2\). Choose either one. Its complete \(e\to Y\) path against \(R\) exits the shore at \(p_1\) and has the stated exterior suffix. Switch it between \(R,D_i\), obtaining a real triple \(H=YW\), while \(P=eY\in T_1\) and \(J=Y\) remain unchanged. The new \(H\) takes \(Y:C\) and retains the \(X\) terminal. By (4), \(J\) takes \(X:C\) and the \(Y\) terminal. Hence
\[
Y-t_Y-C-t_X-X                                         \tag{5}
\]
is a wholly exterior path of \(H\triangle J\). Switching (5) changes \(H=YW\in S_1\) to \(XW\in T_1\), alongside unchanged \(P=eY\in T_1\), a forbidden double-\(T\) row. This excludes \(S_1\).

Under \(S_2\), choose an \(e\)-singleton \(D\) that does not take \(au_3\). Such a \(D\) exists: \(K\) already takes \(au_3\), so at most one of \(D_0,D_1\) can fill its remaining load. By (4), \(D:X:A\), and therefore its \(u_3\)-slot is \(p_3\). The \(X\)-arm of \(R\triangle D\) is
\(X-t_X-A-u_3-p_3\). The \(Y\)-arm of \(R'\triangle D\) exits at \(p_4\) if \(D:Bu_2\), and at \(p_2\) if \(D:Bu_4\). But \(S_2\) requires the same shore \(e\)-exit to select \(X\) against \(R=eW\) and \(Y\) against \(R'=eZ\). This would equate \(p_3\) with \(p_4\) or \(p_2\), impossible.

All four root pairs of the required \((eY)(eW)\) cell and both pentagons have been excluded. Combined with Notes 413, 419, 421, and 422, this excludes **all six forbidden \(e\)-pairs** for the specified marked two-spoke-prism exterior, at arbitrary shore order and without assumptions on girth, cycle rank, or connectivity. It does not exclude different marked exteriors or prove the Berge–Fulkerson conjecture. The upstream classifications and this hand proof still await independent review; no local mathematical recomputation or OMEN was used. \(\square\)
