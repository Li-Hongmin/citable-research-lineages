> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short diamond forces a three-owner Tait-defect cycle

The surviving \(J'=5\), six-edge aligned diamond of [Notes 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) and [145](145-negative-tait-states-force-mixed-owner-edges-on-one-phase-cycle.md) has a literal state-\(35\) Tait colouring that uses two matchings from its actual BF row. The third S-half occurrence cannot be transported to the Tait complement by paired cycle switches: one alternating cycle has a three-edge owner certificate touching **all three overloaded strands** of the diamond. This is a full-mask, graph-induced obstruction, not an exact-Case-XII realization or a common \(B_2+C_4\) seed.

## A general Tait-defect certificate

Let actual perfect matchings form a six-cover row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.              \tag{1}
\]
Suppose two of \(U,Z,D\) are edge-disjoint, and let \(X\) be the third. The cubic complement of the disjoint pair is an actual perfect matching \(X^*\) with the same boundary as \(X\), because the S-half has one occurrence on each terminal semiedge. If state \(34\) has no Tait colouring, then \(X\ne X^*\), and some component \(K\) of \(X\triangle X^*\) has three \(X^*\)-phase edges whose owner pairs in (1) are respectively
\[
\boxed{\{r,Y\},\qquad\{r,C\},\qquad\{Y,C\}.}           \tag{2}
\]
In particular \(K\) is a proper even alternating cycle of length at least six.

**Proof.** The disjoint S pair plus \(X^*\) is a state-\(35\) Tait colouring. If \(X=X^*\), then the S-half of (1) has load one everywhere, so the T-half \(r+Y+C\) also has load one and is a forbidden state-\(34\) Tait colouring.

On an \(X^*\)-phase edge of \(X\triangle X^*\), the disjoint S pair avoids the edge and \(X=0\), so all two row owners are among \(r,Y,C\). On an \(X\)-phase edge, the disjoint S pair contributes one and \(X\) contributes the other, so all three T occurrences avoid it. If on every component of \(X\triangle X^*\) one T occurrence owned all its \(X^*\)-phase edges, switch that occurrence with \(X\) on the component. The cycles are vertex-disjoint, so the switches preserve complete matchings, boundaries, and (1) independently. After all switches, \(X\) becomes \(X^*\), making both halves Tait colourings, a contradiction. Thus one component has empty intersection of its two-element T-owner sets. Any two two-element subsets of the three names \(\{r,Y,C\}\) intersect; empty total intersection therefore requires all three subsets, witnessed by the three edges in (2). \(\square\)

## The six-edge four-junction branch

Assume (1) is normalized as the four-junction diamond of Note 143, has no state-\(34\) Tait colouring, and its four-junction \(Z\triangle Y\) component \(\Omega\) has exactly six edges. All other junction-free active cycles have been made split by the closed pair switches used there.

**Theorem.** One of \(U\) or \(D\) is edge-disjoint from \(Z^\epsilon\) for some \(\epsilon\in\{0,1\}\), where \(Z^0=Z\) and \(Z^1=Z\triangle E(\Omega)\). Keep the other five row masks, except for the corresponding simultaneous swap \(Y^1=Y\triangle E(\Omega)\). Apply the general certificate to this actual row, taking \(X=D\) when \(U\cap Z^\epsilon=\varnothing\) and \(X=U\) when \(D\cap Z^\epsilon=\varnothing\). Its obstructing cycle \(K\) has an edge on each of the three overloaded strands: a type-\(12\) \(rY^\epsilon\) edge, a type-\(23\) \(Y^\epsilon C\) edge, and a type-\(13\) \(rC\) edge. Hence \(K\) meets both \(\Omega\) and its overloaded chord.

**Proof.** In the normalized row, an \(UZ\)- or \(DZ\)-owned edge outside \(\Omega\) would be overloaded on a junction-free active component; there is none. An inactive edge owned by both \(Z,Y\) has no third owner. Therefore \(U\cap Z\) and \(D\cap Z\) can occur only on \(\Omega\). If both \(U\) and \(D\) met each of the two phases \(Z^0,Z^1\), their intersections with both \(Z\) and \(Y\) would give four distinct owner-pair edges \(UZ,UY,DZ,DY\) on \(\Omega\). By Note 145 and absence of state \(34\), the same six-edge cycle also has the four distinct edges \(rZ,rY,CZ,CY\). Eight different row owner pairs cannot fit on six edges. Thus one of the stated disjoint pairs exists, using only the single switch on \(\Omega\); the other junction-free components remain split.

Switching \(Z,Y\) on \(\Omega\), if required, leaves the normalized diamond network intact and moves its two overloaded phase-cycle strands to the opposite terminal-arm junction; its type-\(13\) overloaded chord remains. The three T-owner pairs in (2), now read as \(rY^\epsilon,rC,Y^\epsilon C\), can occur only on overloaded edges. In a normalized four-junction diamond these are precisely its unique overloaded type-\(12\), type-\(13\), and type-\(23\) strands. Thus the three certificate edges lie one on each strand. The first and third are on \(\Omega\), and the middle one is on the chord. \(\square\)

## Exact six-edge pattern and the fixed carrier

There are only four owner patterns for the six edges of \(\Omega\) under the preceding no-state-\(34\) hypothesis. Starting at the junction with the two overloaded phase-cycle strands, traverse \(\Omega\) through \(\alpha\) (overloaded type \(12\)), \(\beta\) (split type \(23\)), \(\gamma\) (split type \(12\)), and \(\delta\) (overloaded type \(23\)). The table lists the successive owner pairs on each strand; \(C\) in an owner pair means the class-four matching, not the strand \(\gamma\).

| Strand lengths \((\alpha,\beta,\gamma,\delta)\) | \(\alpha\) | \(\beta\) | \(\gamma\) | \(\delta\) |
|---|---|---|---|---|
| \((2,2,1,1)\) | \(UZ,rY\) | \(ZC,YD\) | \(rZ\) | \(YC\) |
| \((2,1,2,1)\) | \(UZ,rY\) | \(ZC\) | \(UY,rZ\) | \(YC\) |
| \((1,2,1,2)\) | \(rY\) | \(ZC,YD\) | \(rZ\) | \(YC,ZD\) |
| \((1,1,2,2)\) | \(rY\) | \(ZC\) | \(UY,rZ\) | \(YC,ZD\) |

Indeed Note 145 forces \(rY,ZC,rZ,YC\) on \(\alpha,\beta,\gamma,\delta\), respectively. Four strands with six edges have either one strand of length three or two strands of length two. Along \(\Omega\), the \(Z,Y\) phases alternate edge by edge. A length-three strand leaves the two unit strands of the other type in the same phase, violating one of the forced mixed-owner pairs. Of the six placements of two length-two strands, the placements \((\alpha,\delta)\) and \((\beta,\gamma)\) similarly fail the forced phases. The four remaining placements have the unique phase directions displayed above.

At both endpoints of the overloaded type-\(13\) chord, the two incident \(\Omega\) owner pairs in every table row leave the complementary owner pair \(UD\). Both arcs of \(\Omega\) between those endpoints have length three. Owner pairs alternate \(UD,rC\) along the chord, so its length is odd; a one-edge chord would make a four-cycle, and a girth-five pole therefore has a chord of at least three proper edges.

Now impose Note 143's literal alignment \(B_2=U\), \(q_{25}=Z\) on \(\Omega\), and suppose the corresponding right-row junction count is \(J'=5\). The two chord-end \(UD\) edges belong to \(B_2\), not \(q_{25}\). At any interior chord vertex the incident owner pairs are \(UD,rC,ZY\). If \(q_{25}\) uses its \(UD\) edge, that vertex is a right-row junction; if it uses the \(ZY\) third edge, it is not. Every interior \(UD\) edge used by \(q_{25}\) has **two** interior endpoints and therefore creates two right-row junctions. Since four of the five right-row junctions already lie on \(\Omega\), no such edge can be used by \(q_{25}\). Consequently the complete masks satisfy
\[
\boxed{B_2=U_{35},\qquad q_{25}=Z_3=Y_3
\quad\text{at every interior vertex of the chord}.}        \tag{3}
\]
At its endpoints the analogous \(B_2=U,q_{25}=Z\) identities already follow from alignment. Thus the \(1\leftrightarrow4\) component of \(U_{35}\triangle Z_3\), which equals a component of \(q_{25}\triangle Z_3\) by Note 143(6), avoids **every vertex of the chord as well as \(\Omega\)**. The unique right-row junction outside \(\Omega\) must lie elsewhere.

If the right row also satisfies Note 143's literal \(B_2=U_{35}\) alignment and has \(J'=5\), then \(|E(\Omega)|=6\) by Note 145, so this theorem applies. In a genuine exact-Case-XII pole, the forbidden \([34]\) BF loop supplies the no-state-\(34\) hypothesis. The certificate shows precisely why the available S-Tait colouring does not automatically repair the T-half: a single \(X\triangle X^*\) cycle carries all three incompatible T-owner pairs. It does not decide whether that cycle can coexist with the fixed-\(B_2\) two-level terminal-pairing constraints of [Note 144](144-fixed-singleton-phase-cube-has-two-terminal-pairing-gates.md).

Under the full exact negative support, the \(5\)-terminal path between the triple and class-five colours of **any** state-\(35\) Tait colouring must end at \(1\): endpoints \(2,4\) would Kempe-switch it to forbidden Tait states \(23,34\). The original \(U_{35}+D_5\) path also ends at \(1\), because its other endpoints would give forbidden \(T\)--\(T\) BF rows against the unchanged state-\(34\) half. Thus, in the \(D\cap Z^\epsilon=\varnothing\) branch above, both the original \(U_{35}\) and the distinct Tait complement \(U^*_{35}\) pair \(D_5\) with terminal \(1\). If a common \(B_2+C_4\) seed is absent, Note 136 gives a cross-half \(p_{35}\) pairing \(D_5\) with \(4\), so the complete class-\(35\) perfect-matching family contains at least three distinct masks \(U,U^*,p\). In the \(U\cap Z^\epsilon=\varnothing\) branch, the Tait complement \(D^*_5\ne D_5\) instead gives two distinct complete class-five matchings. These are necessary family sizes, not a contradiction.
