> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dependent two-splice gates split into sign feasibility and four-row sections

The two extension patterns left by the six-singleton argument have different
irreducible forms.  In the repeated-extension pattern, complete
perfect-matching closure reduces every proposed splice to dependent
coordinatewise sign tests in one anchored row.  In the three-distinct
pattern, four such row realizations must share the same six actual singleton
identities.  Exact forty-type support supplies neither dependency.

Use the repeated-extension singleton identities

\[
 (A,B,C,D,X,Y)\in
 \mathcal P_1\times\mathcal P_2\times\mathcal P_4
 \times\mathcal P_5\times\mathcal P_3\times\mathcal P_3
\]

and the four literal pivot rows with singleton quartets

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.
\]

The three missing-pair targets are

\[
 BDXY,\qquad ACXY,\qquad ABDY.                    \tag{1}
\]

Assume exact Case-XII support, common trivalent incidence, and the complete
perfect-matching family of one loopless cubic 5-pole.  The available results
do not prove that one target has a Note-082 sequential or
forced-intermediate two-splice fibre, and no real exact-Case-XII pole is
known that refutes this assertion.

## Only two targets are literally anchored by the pivot rows

The \(t=23\) half

\[
 r_{23}+B+X
\]

literally anchors the \(BDXY\) target, while the \(t=34\) half

\[
 r_{34}+Y+C
\]

literally anchors the \(ACXY\) target.  Column saturation supplies source
rows

\[
\begin{aligned}
q_{35}^{23}+r_{23}+B+X+P_3^{23}+P_5^{23}
   &=2\mathbf1,\\
q_{13}^{34}+r_{34}+Y+C+P_1^{34}+P_3^{34}
   &=2\mathbf1.
\end{aligned}                                      \tag{2}
\]

Exact support of the \(t=12\) column supplies only a private half

\[
 r_{12}+P_1^{12}+P_2^{12}.                        \tag{3}
\]

It does not identify \(P_1^{12},P_2^{12}\) with the literal \(A,B\).
Consequently the third target is not literally anchored by exact forty
support and the four pivot rows alone.  Calling all three targets anchored
requires the additional reuse hypothesis

\[
 r_{12}+A+B\text{ occurs as an actual half of a BF row}.        \tag{4}
\]

This is an earlier obstruction than any phase-intersection test for the
third target.

## Full perfect-matching closure reduces membership to a sign test

For same-boundary perfect matchings \(P,\widehat P\) and another perfect
matching occurrence \(N\), define

\[
 \operatorname{Sep}(N;P,\widehat P)
 \iff
 \widehat P\setminus P\subseteq N
 \quad\text{and}\quad
 N\cap(P\setminus\widehat P)=\varnothing.          \tag{5}
\]

The forced vector

\[
 N'=N+P-\widehat P                                \tag{6}
\]

already has incident degree one at every cubic vertex and has the same
boundary as \(N\).  It is a \(0/1\) vector if and only if (5) holds.  Hence,
in the complete perfect-matching closure of the common cubic pole,

\[
 N'\in\mathcal P_{\partial N}
 \quad\Longleftrightarrow\quad
 \operatorname{Sep}(N;P,\widehat P).              \tag{7}
\]

Thus complete closure leaves no additional hidden matching-existence
condition.  The unresolved information is exactly whether one of the
finitely many forced vectors is coordinatewise \(0/1\).

The same reduction applies to the forced-intermediate branch.  For

\[
 Z_1=\widehat P_1+\widehat P_2-P_2,                \tag{8}
\]

the vertex and boundary equations are automatic.  The first requirement
is only that \(Z_1\) be \(0/1\); after that, the second forced vector
\(N+P_1-Z_1\) again belongs to the complete family exactly when it is
\(0/1\).

For one anchored row \(R\), the exact two-step condition can therefore be
written without any general closure quantifier:

1. in one of the two endpoint orders, some current occurrence satisfies
   (5) for the first replacement and some occurrence in the forced updated
   row satisfies (5) for the second replacement; or
2. one of the two vectors (8) is \(0/1\), and a current triple occurrence
   satisfies (5) for the resulting preparatory replacement.

Taking the union over the two literal rows in (2), and over the third row
only when (4) holds, is the precise repeated-extension gate.  This is
narrower than a general perfect-matching exchange or closure hypothesis:
it asks only for a dependent pair of explicit coordinatewise sign tests in
one anchored occurrence chain.

## What the partial-flip cubes and negative support imply

For a same-class endpoint pair \(P,\widehat P\), complete closure contains
the full cube obtained by independently flipping the components of
\(P\triangle\widehat P\).  Absence of the all-terminal type implies that
every cube member meets the appropriate anchor double-load set \(D_2\).
Equivalently, \(D_2\) meets the common part of the endpoint pair or meets
both phases on one alternating component.

Absence of \(T\)-loops and \(T\)--\(T\) types adds two further facts:
specified singleton pairs cannot be disjoint, and any cube member that
already enters a fixed \(T\)-column carrier can occur only in an allowed
\(S\)-state decomposition.

These statements have respectively the quantifier forms

\[
\forall I\ \exists e_I\in P^I\cap D_2
\]

and

\[
P^I\text{ enters a carrier}\Longrightarrow
\text{its partner state lies in }S.               \tag{9}
\]

Neither statement names one row occurrence \(N\).  Condition (5), in
contrast, requires one occurrence simultaneously to contain every added
edge and avoid every deleted edge.  The edge \(e_I\) in (9) may depend on
the cube vertex, and the carrier implication does not assert its
antecedent.  Common trivalent incidence does not reverse these quantifiers;
Notes 083--090 show separately why rowwise edge labels, topology, global
class flexibility, carrier saturation, and local alternating-chain phases
do not do so.

## Repeated-extension decision boundary

The desired three-target disjunction remains undecided for a real
exact-Case-XII cubic 5-pole.  The common-binary countermodel of Note 085
cannot settle it because it lacks a common trivalent vertex partition and
graph-induced full closure.  Conversely, Notes 055, 057, 073, 078, and
082--090 do not imply any one of the dependent sign tests above.

The strict remaining assumptions are therefore:

1. the literal \(t=12\) reuse (4), if the third target is to count as
   anchored; and
2. for at least one genuinely anchored target, a dependent two-stage
   \(\operatorname{Sep}\) chain, or the two \(0/1\) forced-intermediate
   tests in (8).

This does genuinely identify the Note-082 dependent fibre, but the
partial-flip and negative-support consequences do not enter that fibre:
they constrain cube vertices and edge hits, not a common companion
occurrence.  Any further hypothesis that only adds support types, more
partial flips, or more edge-hitting statements leaves the same sign gate
untouched.

## The three-distinct branch

Now use the four anchors \(a_1,a_2,a_4,a_5\) and three distinct class-3
extensions \(x,y,z\) of [Note 074](074-three-distinct-extensions-require-four-witness-reuse-rows.md).
For an omitted extension \(o\), let \(U_o\) be the remaining six singleton
identities.  If \(W\subset U_o\) is one of the requested singleton
quartets, define \(\operatorname{Hit}(W)\) to mean that an independently
available source row in one of the allowed Case-XII cells reaches the
literal quartet \(W\) by a sequential or forced-intermediate fibre of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).

Let \(\mathfrak G_o\) be the three, two, and three optimal four-quartet
families listed in Note 074 for omission of \(x,y,z\), respectively.  The
whole three-distinct branch is the single statement

\[
 \bigvee_{o\in\{x,y,z\}}
 \ \bigvee_{G\in\mathfrak G_o}
 \ \bigwedge_{W\in G}\operatorname{Hit}(W).                    \tag{10}
\]

Equivalently, on each \(U_o\) join the missing pair \(U_o\setminus W\)
when \(\operatorname{Hit}(W)\) holds.  Equation (10) asks one of these
three realizable-pair graphs to contain all four added edges of one optimal
Note-074 augmentation.

Exact support has quantifiers \(\forall c\,\exists R_c\).  Equation (10)
instead requires one choice of \(U_o\), followed by four rows whose fibres
all reuse those same six identities.  The eight-way alternative does not
itself force this exchange of quantifiers.  Indeed, simultaneous failure of

\[
 \{a_2,a_4,a_5,z\},\quad
 \{a_2,a_4,a_5,x\},\quad
 \{a_1,a_2,a_4,z\},\quad
 \{a_1,a_2,a_5,y\}                                  \tag{11}
\]

meets every one of the eight optimal gates.  Thus proving many unrelated
fibres nonempty is insufficient; a proof must exclude a cross-gate failure
transversal such as (11).

## Remaining theorem

The repeated-extension branch asks for at least one dependent sign-feasible
anchored chain, with the literal reuse condition (4) if the third target is
included.  The three-distinct branch asks for a four-row dependent-section
theorem: one common cubic full-perfect-matching closure must realize all four
target edges of one optimal augmentation using the same six singleton
identities.

The current exact-support, residual-parity, partial-flip, global-avoidance,
and support-preserving replacement results neither prove nor refute these
statements for a real exact-Case-XII pole.  This is the exact remaining
quantifier boundary; it is not evidence for a counterexample.
