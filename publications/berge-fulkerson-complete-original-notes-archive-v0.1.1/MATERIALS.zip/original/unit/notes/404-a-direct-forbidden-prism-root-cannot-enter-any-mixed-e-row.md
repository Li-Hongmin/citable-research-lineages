> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A direct forbidden prism root cannot enter any mixed \(e\)-row

Keep the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\), marked edges \(AC,Cc,bc,ab\), and arbitrary complete six-port shore. Suppose the full BF support is the published [Proposition 4.4 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), relabelled so that \(e\,ab,e\,Cc\in T\) and \(e\,AC,e\,bc\in S\). A zero-port forbidden triple is called *direct* here when it is \(e\,ab\) rooted at \(a\), or \(e\,Cc\) rooted at \(c\).

> **Direct-root exclusion.** No actual mixed BF row can contain either direct forbidden triple, regardless of which allowed \(e\,AC\) or \(e\,bc\) triple and which of its two roots supplies the other triple. The conclusion uses neither a clean shore signature nor a bound on shore order, cycle rank or port-path lengths.

[Notes 399](399-the-direct-mixed-prism-root-pair-is-impossible-at-all-shore-orders.md), [402](402-the-opposite-direct-mixed-prism-root-pair-is-impossible.md) and [403](403-all-four-direct-mixed-prism-root-pairs-are-impossible.md) already exclude both direct forbidden roots paired with \(e\,AC:C\) or \(e\,bc:b\). It remains to exclude \(e\,bc:c\) for each direct forbidden root; the remaining \(e\,AC:A\) pairs will then follow by one switch.

**Common exterior switch.** Let \(R:e\,bc:c\), let \(P\) have either direct forbidden root, and let \(K\) be the singleton-\(bc\) occurrence. The zero-port rooted-tree mask of \(R\) is \((B,C,A,b,a)\). Starting at terminal \(bc\), the path of \(R\triangle K\) enters \(c\). Taking \(Cc:c\) would end at forbidden \(Cc\), so \(K\) takes \(cu_5\). It then reaches \(a\); taking \(ab:a\) would end at forbidden \(ab\), so \(K\) takes \(au_3\) and reaches \(A\). If \(K\) takes \(Au_1\), the path reaches \(B\). From there, \(Bu_4\) leads to forbidden \(ab\), whereas \(Bu_2\) leads either to forbidden \(Cc\) or to an \(e\,AC:C\) root pair already excluded by Note 399 or Note 403. Hence \(K\) takes \(AC:A\), and switching this wholly exterior path gives an allowed \(R':e\,AC:A\) with \(R'|_Z=R|_Z\). Both choices of \(P\) use \(Cu_2,Bu_1,bu_4\), so the remaining vertices force
\[
K:(u_1,u_2,u_3,u_4,u_5)=(p_1,B\text{ or }p_2,a,B\text{ or }p_4,c),
\quad (AC,Cc,bc,ab)=(A,C,s,b),                         \tag{1}
\]
with exactly one of \(Bu_2,Bu_4\) selected. In particular \(K\) uses ports \(p_1\) and the other of \(p_2,p_4\). The mask of \(R'\) is \((B,C,a,b,c)\) with \(AC:A\) and the other three marks terminal.

**Case \(P:e\,ab:a\).** Here \(P\)'s tree mask is \((B,C,A,b,c)\). Write \(J\) for the singleton-\(ab\) occurrence and \(D,E\) for the singleton-\(e\) occurrences. Since \(P,R\) saturate \(bu_4\), equation (1) puts \(K\) on \(ab:b\); \(J\) takes the \(ab\) terminal, hence covers \(b\) by \(bc:b\). At \(c\), \(P,K\) saturate \(cu_5\), and \(J\) cannot take \(bc:c\) at the same subdivision as \(bc:b\), so \(J\) takes \(Cc:c\). At \(C\), \(P,R\) saturate \(Cu_2\), \(K\) takes \(Cc:C\), and \(J\) therefore takes \(AC:C\). The remaining marked slots force, after naming the singleton using \(bc:b\) by \(D\),
\[
\begin{array}{c|cccc}
 &AC&Cc&bc&ab\\\hline
D&C&c&b&a\\
E&A&C&c&b.
\end{array}                                               \tag{2}
\]
Indeed, \(D\) cannot take \(ab:b\) with \(bc:b\); it must take \(Cc:c\) because \(cu_5\) is saturated, and then \(AC:C\). The other halves give \(E\). The matching \(E\) covers \(B\) through \(Bu_2\) or \(Bu_4\), and \(a\) through \(au_3\) or \(au_5\). Its three proper ports lead to the following terminals in **both** \(R\triangle E\) and \(R'\triangle E\):
\[
\begin{array}{c|c|c}
 &E:Bu_2&E:Bu_4\\\hline
x\text{, the }Cc\text{-port}&p_1&p_2\\
y\text{, the }ab\text{-port}&p_4&p_1
\end{array}
\qquad
z=\begin{cases}p_5,&E:au_3,\\p_3,&E:au_5.\end{cases}      \tag{3}
\]
The third port \(z\) leads to \(AC\) against \(R\), and to \(bc\) against \(R'\). Thus \(x,y,z\) are distinct, while the shore path from \(e\) against \(E\) has the same proper endpoint \(q\) for \(R,R'\).

For \(S_{ab}=e-AC-ab-Cc-bc-e\), keeping \(P:e\,ab\in T\) demands \(q=x\) against \(R:e\,bc\), since \(Cc\) is the other allowed neighbour of \(bc\), but demands \(q=y\) against \(R':e\,AC\), since \(ab\) is the other allowed neighbour of \(AC\). For \(S_{Cc}=e-AC-Cc-ab-bc-e\), these requirements reverse: \(q=y\) against \(R\) and \(q=x\) against \(R'\). Since \(x\ne y\), both orientations are impossible.

**Case \(P:e\,Cc:c\).** Now \(P\) and \(R\) share tree mask \((B,C,A,b,a)\). Let \(J\) be the singleton-\(Cc\) occurrence. At \(c\), its own terminal excludes \(Cc:c\), so \(J\) uses either \(cu_5\) or \(bc:c\). The marked subdivisions and the saturated tree edges give the following exhaustive alternatives for one singleton-\(e\) occurrence \(E\):

| \(J\) at \(c\) | forced \(J\) at \(bc,ab,AC\) | \(E:(AC,Cc,bc,ab)\) | forced \(E\) tree choice |
|---|---|---|---|
| \(cu_5\) | \((b,a,C)\) | \((A,C,c,b)\) | \(au_3\) |
| \(bc:c\) | \((c,b,C)\) | \((A,C,b,a)\) | \(cu_5\) |

To see the first row, \(J\) cannot use \(bc:c\), so its \(bc\) mark uses \(b\); the \(ab\) and \(AC\) marks then use \(a,C\). The other singleton-\(e\) occurrence must use \(bc:b,ab:a,Cc:c,AC:C\), leaving the displayed mask for \(E\). In the second row, \(J\) uses \(ab:b,AC:C\); both singleton-\(e\) occurrences use \(bc:b,ab:a\), and exactly one uses \(Cc:c,AC:C\), leaving the displayed \(E\). All entries follow by covering one endpoint at each cubic vertex and loading each marked edge twice.

In the first row, \(E\)'s mask is (2), with \(E:au_3\), so the same \(x,y,z\) arms in (3) apply and give the same contradiction for both pentagons. In the second row, \(E\) covers \(B\) by \(Bu_2\) or \(Bu_4\), has ports \(p_1,p_3\) and one of \(p_4,p_2\), and its exterior arms are
\[
\begin{array}{c|c|c}
 &E:Bu_2&E:Bu_4\\\hline
x\text{, }Cc\text{ for both }R,R'&p_1&p_2\\
y\text{, }ab\text{ for }R\text{ and }bc\text{ for }R'&p_4&p_1
\end{array}.
\tag{4}
\]
The remaining arm is \(AC\)--\(p_3\) for \(R\) and \(ab\)--\(p_3\) for \(R'\). In \(S_{ab}\), the two allowed-state switches require respectively \(q=x\) against \(R\) and \(q=p_3\) against \(R'\), although \(x\ne p_3\). In \(S_{Cc}\), they require \(q=y\) and \(q=x\), although \(y\ne x\). This excludes both alternatives.

Finally, take \(R:e\,AC:A\) with either direct forbidden \(P\). Switch \(R\) with its singleton-\(AC\) occurrence along the path starting at \(AC\). Its other endpoint cannot be \(ab\) or \(Cc\): that would create either a forbidden loop at \(P\)'s label or a double-\(T\) row. Therefore it ends at \(bc\), making an \(e\,bc\)-triple rooted at \(b\) or \(c\) while leaving \(P\) unchanged. The \(b\)-root is excluded by Notes 402–403, and the \(c\)-root by the two cases just proved. Together with Notes 399 and 403, this covers all allowed roots. Every switch is between complete perfect matching occurrences and preserves load two. \(\square\)

This theorem rules out participation of the two specified direct forbidden roots in mixed BF rows. It does not show that those individual rooted perfect matchings are absent: [Note 230's Cartesian factorization](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) can supply them without placing them in a common BF row. The indirect forbidden roots, other forbidden \(e\)-label pairs, other exterior trees, and full exact Case XII remain open. The argument is hand-derived and awaits independent review.
