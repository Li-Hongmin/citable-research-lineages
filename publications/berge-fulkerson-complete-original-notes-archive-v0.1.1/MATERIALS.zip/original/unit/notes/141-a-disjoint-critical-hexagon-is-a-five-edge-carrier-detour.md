> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A disjoint critical hexagon is a five-edge carrier detour

The conditional \(A,A,B\) pattern of [Note 140](140-disjoint-singleton-phase-has-a-unique-critical-six-cycle-owner-pattern.md) has a rigid consequence for the *other* two full-mask decompositions of its carrier. The two canonical \(2\leftrightarrow3\) switches take opposite arcs of the same hexagon: five edges in \(q_{25}+B_2\), one edge in \(q_{25}+r_{34}\). The two possible owners of the remaining \(U_{35}\)-edge give different, explicit matching-difference patterns outside the hexagon. Independently, absence of the \([34]\) Tait loop forces at least three trivalent junctions in the right row's paired-difference network; if there are exactly three, its irreducible core is an overloaded triangle, exterior to this hexagon. The hexagon assertions remain conditional: neither an exact-Case-XII pole nor such a critical hexagon is known to exist.

## Carrier-detour theorem

Let \(H\) be a cubic five-pole with actual complete perfect matchings satisfying
\[
 U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1,
 \qquad q_{25}+B_2=U_{35}+Z_3,
 \qquad q_{25}+r_{34}=P_{35}+t_{24}.                 \tag{1}
\]
Suppose a component \(\Gamma\) of \(U_{35}\triangle P_{35}\) is a six-cycle, \((Z_3\triangle Y_3)\cap E(\Gamma)=\varnothing\), and its successive \(P_{35}\)-phase owner pairs are
\[
 A=\{Z_3,Y_3\},\qquad B=\{r_{34},D_5\},\qquad A. \tag{2}
\]
Assume that \(\Gamma\) is *pairing-critical*: for some intermediate matching \(V_{35}\) obtained by toggling other components of \(U_{35}\triangle P_{35}\), toggling \(\Gamma\) changes the pairing of the four terminal ends in \(V_{35}+D_5\). The as-yet untoggled \(V_{35}\) equals \(U_{35}\) on \(\Gamma\). Pattern (2) is the sole possibility left by Note 140 for a disjoint, unalignable critical six-cycle. The local conclusions below use (1)--(2), disjointness, and criticality; they require no other Case-XII support.

Write the cyclic edges of \(\Gamma\) as
\[
 e_0=v_0v_1:A,\quad e_1=v_1v_2:U,
 \quad e_2=v_2v_3:B,\quad e_3=v_3v_4:U,
 \quad e_4=v_4v_5:A,\quad e_5=v_5v_0:U,             \tag{3}
\]
and let \(h_i\) be the third edge at \(v_i\). Then \(e_1,e_3\) have owner pair \(\{U_{35},C_4\}\), while \(e_5\) has \(\{U_{35},X\}\) for one \(X\in\{C_4,r_{34}\}\). In either case,
\[
 q_{25}=Z_3=Y_3\quad\text{and}\quad B_2=U_{35}
 \qquad\text{at every vertex of }\Gamma.           \tag{4}
\]
In particular, the two carrier exchanges have the exact local form
\[
 (q_{25}\triangle U_{35})\cap E(\Gamma)
       =E(\Gamma)\setminus\{e_2\},
 \qquad
 (q_{25}\triangle P_{35})\cap E(\Gamma)=\{e_2\}. \tag{5}
\]
Both differences contain \(h_2,h_3\), and those are the same two edges in the two routes. If the switches in (1) use no optional closed-component flips, the five-edge arc and the one-edge arc in (5) lie on their respective forced \(2\leftrightarrow3\) terminal paths. Thus the two paths make a literal local detour between \(v_2\) and \(v_3\), although they need not agree elsewhere.

The full owner and residual pattern at the six third edges is
\[
\begin{array}{c|c|c|c|c}
 X&h_0,h_5&h_1,h_4&h_2,h_3&t_{24}\cap\{e_5,h_0,\ldots,h_5\}\\\hline
 C_4&\{D_5,r_{34}\}&\{D_5,r_{34}\}&\{Z_3,Y_3\}
       &h_0,h_1,h_2,h_3,h_4,h_5\\
 r_{34}&\{D_5,C_4\}&\{D_5,r_{34}\}&\{Z_3,Y_3\}
       &e_5,h_1,h_2,h_3,h_4
\end{array}                                                   \tag{6}
\]
Here the entries in the middle columns are the two owners in the first row of (1), not additional matching labels.

If \(X=C_4\), four complete-mask symmetric differences avoid **every edge incident with** \(\Gamma\):
\[
 Z_3\triangle Y_3,\qquad q_{25}\triangle Y_3,
 \qquad B_2\triangle C_4,\qquad D_5\triangle r_{34}. \tag{7}
\]
The last three have, respectively, unique open terminal paths \(1\leftrightarrow4\), \(2\leftrightarrow4\), and \(1\leftrightarrow2\); any other components are closed alternating cycles. Consequently the terminal vertices \(1,2,4\) lie in one component of \(H-V(\Gamma)\). When \(\Gamma\) is induced, \(t_{24}\) uses all six edges of its vertex cut.

There is an exact limitation to using these three exterior paths as the next Kempe move. Switch independently the unique open paths of \(q_{25}\triangle Y_3\), \(B_2\triangle C_4\), and \(D_5\triangle r_{34}\), leaving all closed components unchanged. Every subset of the three switches gives an actual ordered six-matching double cover with the **same occurrence masks on every edge incident with** \(\Gamma\). The switches merely exchange, respectively, the boundary roles triple-\(25\)/singleton-\(3\), singleton-\(2\)/singleton-\(4\), and singleton-\(5\)/triple-\(34\). Thus all eight ordered outcomes still have one \(S\)-triple of state \(25\) and one \(T\)-triple of state \(34\); this three-switch cube cannot by itself yield a forbidden BF type. Its ordered outcomes need not be distinct as unlabelled covers.

If \(X=r_{34}\), both \(B_2\triangle C_4\) and \(D_5\triangle r_{34}\) contain \(e_5,h_0,h_5\). On \(e_5\), the owners among these four matchings are \(B_2,r_{34}\); on \(h_0,h_5\), they are \(D_5,C_4\). The unique open paths of these two differences have endpoints \(2,4\) and \(1,2\), but the common three-edge segment could instead belong to closed components. If \(\Gamma\) is induced, \(t_{24}\) crosses four edges of its vertex cut and uses \(e_5\) internally.

The three cross-class differences in both branches satisfy a global edge-set identity:
\[
 \boxed{q_{25}\triangle Y_3
   =(B_2\triangle C_4)\triangle(D_5\triangle r_{34}).} \tag{8}
\]
Indeed, replacing \(U_{35}+Z_3\) by \(q_{25}+B_2\) in (1) gives the original right double-cover row. Partition its six occurrences into \((q_{25},Y_3)\), \((B_2,C_4)\), and \((D_5,r_{34})\). On every edge either both owners lie in one pair, so none of its three differences contains that edge, or the owners lie in two different pairs, so exactly those two differences contain it. Their threefold symmetric difference is empty, proving (8). In the \(r_{34}\)-branch, the common segment \(e_5,h_0,h_5\) cancels from the right-hand side, as the locally identical \(q_{25},Y_3\) masks require.

There is a forced junction outside the hexagon. Colour an edge in the union of the three differences by the two differences that contain it, using pair indices \(1=(q_{25},Y_3)\), \(2=(B_2,C_4)\), and \(3=(D_5,r_{34})\). At an internal vertex, each difference has degree zero or two. Thus the incident active edges are either absent, two edges of one common colour \(12,13,23\), or three edges with the three different colours \(12,13,23\). The terminal semiedges \(1,2,4\) have colours \(13,23,12\), respectively; terminals \(3,5\) are inactive. Counting active degrees modulo two gives an **odd number of three-colour junction vertices**. In the \(C_4\)-branch no active edge meets \(\Gamma\); in the \(r_{34}\)-branch its only active edges incident with \(\Gamma\) are \(e_5,h_0,h_5\), all of colour \(23\). Hence every three-colour junction lies outside \(V(\Gamma)\), and at least one exists there. This parity statement uses the complete six-matching row, without Case-XII support or a connectivity assumption.

The absence of a \(T\)-Tait state forces **at least three** junctions. Let \(J\) be their number. Suppose \(J=1\). The component containing the three active terminal semiedges is then a subdivision of a three-armed tree with one junction: each arm has one fixed edge colour \(13,23,12\). Every other active component is a closed cycle of one fixed colour. At terminal semiedges \(1,2,4\), the two owners are in opposite halves of the original right row \((q_{25}+B_2+D_5)+(r_{34}+Y_3+C_4)\). At a degree-two vertex on an arm, the two occurrence pairs exchange their selected edges, so the owner pair remains split across the halves. Thus all three arms, the junction, and all inactive edges have half-load one.

On any closed single-colour active cycle, either its owner pairs are already split across the halves, or the two half-loads alternate \((2,0),(0,2)\). In the latter case the cycle is a whole alternating component of either occurrence-pair difference named by its edge colour. Switching that pair on this **closed** component preserves both matching boundaries and the six-matching cover, and makes every owner pair on the cycle split across the halves. Do this independently for all overloaded active cycles. The resulting complete actual row has half-load one on **every** edge. Its \(T\)-half is a proper three-edge-colouring of state \(34\), yielding the forbidden \(T\)-loop \([34]\) by doubling it. This contradicts the negative support. Together with oddness of \(J\), we obtain the full-row implication
\[
 \boxed{\text{no }[34]\quad\Longrightarrow\quad
       J\text{ is odd and }J\ge3.}                  \tag{9}
\]
All these junctions lie outside \(V(\Gamma)\) in both owner branches. The implication uses only the actual \((25)(34)\) row and absence of the \(T\)-loop \([34]\); it does not require all forty Case-XII types. In the \(C_4\)-branch the entire active network avoids \(V(\Gamma)\). In the \(r_{34}\)-branch a closed active cycle of colour \(23\) may pass through \(e_5,h_0,h_5\), but the junctions cannot.

The first possible value \(J=3\) has a sharper normal form. Switch overloaded closed single-colour components as above. Suppress degree-two vertices of the remaining active network, retaining its three distinct terminal leaves of colours \(13,23,12\). Each three-colour junction has one port of each colour. A component with just one junction must contain **all three** terminal leaves, since its three differently coloured ports cannot pair with each other through constant-colour strands. If the other two junctions form a closed component, they are joined by one strand of each colour. At either junction the incident owner pairs are either all split across the two BF halves, or exactly two strands are overloaded. In the latter case the two overloaded colours share one pair index \(i\), and their two strands form a closed alternating component of difference \(i\). Switch that component to make the whole closed two-junction component split across the halves. The one-junction terminal component is already split, so this would give a forbidden \([34]\) Tait state. Therefore all three junctions belong to the terminal component.

If two terminal leaves attach to one junction, its third incident strand is split across the halves. The third terminal leaf attaches to another junction, and the remaining two junctions are joined by two parallel constant-colour strands. Those two colours share one pair index and again form a closed alternating component; switching it removes any overload and gives the forbidden Tait state. Hence **each terminal leaf attaches to a different junction**. The three inter-junction strands then form a triangle, one of each colour. The terminal arms are split across halves, so at every junction the two triangle strands are either both split or both overloaded. Connectivity makes this choice the same on all three strands. The all-split choice is the forbidden Tait state. Thus
\[
 \boxed{\text{no }[34],\ J=3
 \quad\Longrightarrow\quad
 \begin{gathered}
 \text{a triangle of three exterior junctions,}\\
 \text{one terminal arm at each, all three triangle strands overloaded,}
 \end{gathered}}                                      \tag{10}
\]
after harmless switches of disjoint closed single-colour components. Along the three triangle strands the two half-loads alternate \((2,0),(0,2)\), including at the junctions, so their union is an even proper cycle. The triangle strands cannot be made all split by a boundary-preserving switch within one of the three pair differences: for each pair index, its two triangle strands form part of an **open** path between two terminal leaves. This is the first irreducible negative-support core of the paired-difference network, not a proof that such a core occurs in exact Case XII.

There is a precise consequence for the \(X=r_{34}\) hexagon when \(J=3\). Its common colour-\(23\) segment \(e_5,h_0,h_5\) has one owner in each BF half, whereas every inter-junction triangle strand is overloaded. Since the split/overloaded status is constant along a degree-two colour strand, this segment lies either on the colour-\(23\) arm from terminal \(2\) to its junction or on a disjoint, already split, closed colour-\(23\) cycle. In the first case it belongs to the **open** terminal paths of both \(B_2\triangle C_4\) and \(D_5\triangle r_{34}\); in the second it belongs to **closed** components of both. The mixed open/closed placement is impossible at the three-junction minimum. This still does not decide which placement the complete Case-XII matching family permits.

The three-junction triangle also forces a genuine singleton-phase contact. At the junction carrying the terminal-\(2\) arm of colour \(23\), the two triangle strands have colours \(12\) and \(13\). Both are overloaded, and exactly one of their incident edges there is owned twice by the \(T\)-half. The \(T\)-occurrence from pair \(1=(q_{25},Y_3)\) is \(Y_3\), so this edge is owned by \(Y_3\) together with \(C_4\) or \(r_{34}\). It has \(q_{25}=B_2=0\), and the carrier identity \(q_{25}+B_2=U_{35}+Z_3\) forces \(Z_3=0\). Therefore
\[
 \boxed{J=3,\ \text{no }[34]
 \quad\Longrightarrow\quad
 (Z_3\triangle Y_3)\cap E(K)\ne\varnothing,}       \tag{11}
\]
where \(K\) is the overloaded even triangle cycle. Any normalization switches used above lie on other connected components of the paired-difference network, so the original \(q_{25},B_2,Y_3\) masks on \(K\) and the carrier identity remain valid for this argument. In both hexagon owner branches, \(K\) avoids \(V(\Gamma)\): the \(C_4\)-branch has no active edge there, and the \(r_{34}\)-branch has only split colour-\(23\) edges there. Thus a minimal three-junction obstruction contains two vertex-disjoint even cycles \(\Gamma,K\); a nonempty \(Z_3\triangle Y_3\) cycle touches \(K\) while avoiding \(\Gamma\). This is a necessary double-cycle configuration, not an exact-Case-XII counterexample or a proof of the common seed.

## Proof of the local carrier statements

The disjointness of \(Z_3\triangle Y_3\) from \(\Gamma\) makes those two matchings agree at every vertex of \(\Gamma\): if their chosen edges differed there, at least one chosen edge would be on the cycle. On either \(A\)-edge, (1) gives \(r_{34}=0\), \(q_{25}=1\), and \(B_2=0\). At each of the three \(U\)-edges, \(Z_3=0\), so \(q_{25}+B_2=1\). Every such edge touches an \(A\)-edge; matchinghood of \(q_{25}\) therefore forces \(q_{25}=0\) and \(B_2=1\) on it. At the two ends of the \(B\)-edge, \(q_{25}\) must use \(h_2,h_3\), precisely as \(Z_3,Y_3\) do. This proves (4), the first equality in (5), and the asserted membership of \(h_2,h_3\). The second equality in (5) follows because \(P_{35}\) uses all three \(P\)-phase edges whereas \(q_{25}\) uses only \(e_0,e_4\); at the other four cycle vertices their selected edges already agree.

The row owner pairs at the third edges are the complements of the two incident cycle owner pairs among the six occurrences in (1). The \(U\)-edge \(e_5\) could at first have second owner \(D_5\) as well. In that case it is doubled in \(V_{35}+D_5\), while the other two \(U\)-edges are joined through the \(D_5\)-owned \(e_2\); at most one open terminal path meets the cycle, contrary to criticality. Thus its second owner is \(C_4\) or \(r_{34}\), giving the middle columns of (6). On \(e_0,e_4\), \(q_{25}=P_{35}=1\); on \(e_2\), \(r_{34}=P_{35}=1\); on the other cycle edges, \(P_{35}=0\). Subtracting \(P_{35}\) from \(q_{25}+r_{34}\) gives the displayed complete local mask of \(t_{24}\).

For \(X=C_4\), equations (4) and (6) show \(q_{25}=Y_3\), \(B_2=C_4\), and \(D_5=r_{34}\) at each cycle vertex; the initial hypothesis gives \(Z_3=Y_3\) there. Hence every difference in (7) avoids the vertex set. Their terminal endpoints follow directly from the matching boundaries in (1), proving the exterior-path claim. For \(X=r_{34}\), (4) still holds, while the two difference pairs use opposite phases on \(e_5,h_0,h_5\), as specified in (6). The cut claims follow when all six third edges leave the cycle. \(\square\)

This theorem locates the next graph-induced obstruction. In the \(C_4\)-branch, the three cross-class terminal paths and all junctions are exterior to the pairing-critical cycle; in the \(r_{34}\)-branch, two differences share a local segment but all junctions remain exterior. The paired switches proved here do not give a forbidden \(T\)--\(T\) BF row or a common complete \(B_2+C_4\) seed. An exclusion needs a consequence of the **complete** exact-Case-XII perfect-matching family that constrains the exterior three-junction core and its relation to the hexagon. The source boundary classification is Máčajová--Mazzuoccolo--Tabarelli (2026), Proposition 4.4 and Appendix XII; it contains no cross-row full-mask identity.
