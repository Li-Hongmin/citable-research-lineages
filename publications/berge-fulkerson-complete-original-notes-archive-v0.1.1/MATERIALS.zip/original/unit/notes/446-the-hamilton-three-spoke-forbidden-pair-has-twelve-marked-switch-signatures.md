> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton three-spoke forbidden pair has twelve marked-switch signatures

Use the other three-spoke prism tree of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36).                    \tag{1}
\]
The five proper shore ports \(p_i\) meet \(u_i\), and the sixth shore terminal is \(e\). Assume the **complete** BF support is exact Case XII with forbidden \(e\)-labels \(\{eX,eW\}\). Both pentagon orientations require \((eX)(eY)\) and forbid \([eX]\) and \((eX)(eW)\), by the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf); the respective maps \((e,Y,X,W,Z)=(1,3,5,2,4)\) and \((1,3,2,5,4)\) send the required row to \((13)(15)\) or \((12)(13)\).

> **Twelve-signature gate.** In every genuine \((eX)(eY)\) BF row under these support conditions, the singleton-\(Y\) matching has exactly one of the twelve labelled exterior marked/tree/port signatures in (3). In particular the \(eY\)-triple rooted at \(1\) can switch only to \(Z:2\), never \(Z:6\). This is an all-order necessary condition, not an exclusion of the row.

Name the six complete matching occurrences
\[
P=eX,\qquad R=eY,\qquad K=Y,\qquad J=X,\qquad E=e,\qquad F=e. \tag{2}
\]
Both triples have zero proper ports, whereas \(K\) has exactly two, by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). The \(Y\)-starting path of \(R\triangle K\) cannot end at \(X\), which would give \([eX]\), or at \(W\), which would give \((eX)(eW)\). It ends at \(Z\). Root the path tree at the endpoint of \(Y\) used by \(R\). At a tree subdivision reached from its parent along a \(K\)-half, \(R\) uses the child half, so the path moves monotonically away from the root and never enters a proper shore port. Since \(K\) uses two of the five ports, it takes a tree half at exactly three tree subdivisions. The terminal path therefore traverses at most three tree edges. In particular \(R=eY:1\) cannot reach \(Z:6\), five tree edges away.

The remaining choices are completely fixed up to the alternatives shown here. A string such as \(3u_3\) is the half of tree edge \(u_3\) incident with vertex \(3\). In the \(p_i\) column, \(24\) means \(p_2,p_4\). A slash separates genuine alternatives; independent braces give their Cartesian choices.
\[
\begin{array}{c|c|c|c|c|c}
P=eX\text{ root}&R=eY\text{ root}&\text{end of }Y\text{-path}
 &K\text{ marked halves }(X,Z,W)&K\text{ tree halves}&K\text{ ports}\\ \hline
1&1&Z:2&(X:4,Z:2,W:6)&1u_1,3u_3,5u_5&24\\
4&1&Z:2&(X:4,Z:2,W:6)&1u_1,5u_5,(3u_2/3u_3)&34/24\\
1\text{ or }4&5&Z:2&(X:1,Z:2,W:6)&5u_4,4u_3,3u_2&15\\
1&5&Z:6&(X:4,Z:6,W:3)&1u_1,2u_2,5u_5&34\\
1&5&Z:6&(X:1,Z:6,W:3)&5u_5,\{2u_1,2u_2\},\{4u_3,4u_4\}&\text{other two of }1,2,3,4\\
4&5&Z:6&(X:1,Z:6,W:3)&2u_1,5u_5,(4u_3/4u_4)&24/23.
\end{array}                                                   \tag{3}
\]
The third line represents two labelled signatures, the fifth four; the six lines therefore represent \(1+2+2+1+4+2=12\) candidates. In its fifth line, the port set is the two indices in \(\{1,2,3,4\}\) whose tree halves were not chosen. These are **necessary** exterior data; (3) does not assert that each signature extends to four singleton matchings with a common actual shore or to full exact-Case-XII support.

For the local checks behind (3), if \(R=eY:1\), the allowed path is \(Y-1-u_1-2-Z\). Hence \(K\) takes \(1u_1,Z:2\), then \(X:4\) because \(1\) is occupied. If it took \(W:3\), vertex \(6\) would need \(6u_5\), already loaded twice by \(P,R\); hence \(W:6\). At vertex \(5\), \(K\) must take \(5u_5\), as \(5u_4\) is saturated. With \(P=eX:1\), \(3u_2\) is saturated and \(K\) must take \(3u_3\); with \(P=eX:4\), either \(3u_2\) or \(3u_3\) is available. This gives the first two lines.

If \(R=eY:5\) and the path ends at \(Z:2\), its three tree halves are \(5u_4,4u_3,3u_2\), leaving \(p_1,p_5\); occupying \(4\) and \(3\) forces \(X:1,W:6\). If it ends at \(Z:6\), the path uses \(5u_5\), which forces \(W:3\). For \(P=eX:1\), the choice \(X:4\) forces \(1u_1,2u_2\), while \(X:1\) allows either \(2u_1\) or \(2u_2\) and independently either \(4u_3\) or \(4u_4\). For \(P=eX:4\), the half \(1u_1\) is saturated by \(P,R\), so \(X:1\), and \(2u_2\) is likewise saturated, leaving \(2u_1\) and either \(4u_3\) or \(4u_4\). These are the last three lines.

The direct marked-only recompletion used in [Notes 444–445](445-all-six-forbidden-pairs-are-excluded-on-the-three-spoke-top-path-prism.md) does not automatically transfer to the first line of (3). There \(P,R\) both root at \(1\), and at vertex \(4\) they already fill \(4u_3\), while \(K\) takes \(X:4\). Since \(J\) selects terminal \(X\), name the singleton-\(e\) occurrence sharing \(X:4\) with \(K\) by \(F\); then \(4u_4=JE\). A putative \([eX]\) loop with \(P,R=eX:1\) and **all tree pairs fixed** would require \(t_X\) to have terminal pair \(KJ\), half \(X:1\) pair \(PR\), and half \(X:4\) pair \(EF\). But the unchanged pairs \(4u_3=PR\), \(4u_4=JE\) require \(X:4=KF\), a contradiction at vertex \(4\). This rules out that specific marked-only recipe; it does not rule out tree reslotting, a different forbidden completion, or the original genuine row.

The remaining task for this forbidden pair is to use the *labelled* shore-port pairs and full matching closure to decide the twelve candidate signatures. The other forbidden pairs of this Hamilton three-spoke tree, other exteriors, and Berge–Fulkerson remain open. This classification is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
