> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real common-endpoint \(X,Y\) Hamilton row has a forbidden loop

The unique \(Z:6\to W:6\) switch left by [Note 462](462-the-x-y-forbidden-hamilton-row-has-only-the-common-endpoint-switch.md) is attained by a genuine 21-vertex cubic five-pole of girth at least five. Its complete support has a forbidden \([eX]\) loop, so it is **not** exact Case XII. Thus feasibility of the remaining required row alone cannot exclude the \(\{eX,eY\}\) forbidden pair.

Use the marked exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,\qquad
(X,Y,Z,W)=(14,15,26,36)
\tag{1}
\]
and six complete matching labels
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad a=e,\quad b=e.
\tag{2}
\]
At \(u_i\), list first-end half, second-end half, proper shore port. At a marked subdivision, list terminal and its two halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Put these unordered label pairs on the exterior edges:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,KJ,ab)&(PR,Ka,Jb)&(PR,KJ,ab)&
(Ra,Pb,KJ)&(RJ,Pb,Ka)
\end{array}
\tag{3}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,Ka,Pb)&(PR,Jb,Ka)&(PK,ab,RJ)&(PR,Jb,Ka).
\end{array}
\tag{4}
\]
The six original prism vertices see
\[
(PR,Ka,Jb),\quad (KJ,PR,ab),\quad
(Ka,PR,Jb),\quad (KJ,Ra,Pb),\quad
(Pb,RJ,Ka),\quad (Pb,RJ,Ka).
\tag{5}
\]
Every triple in (3)--(5) partitions \(\{P,R,K,J,a,b\}\). The terminal pairs are \(e=ab,X=RJ,Y=W=PR,Z=PK\), giving \((eX)(eZ)\). In particular \(R\) roots at \(Z:6\), \(K\) uses \(W:6\), and \(R\triangle K\) follows the same-vertex path of Note 462(5).

Add shore vertices \(q_e,q_1,\ldots,q_5\), join \(q_i\) to \(u_i\), put terminal \(e\) at \(q_e\), and use the six-cycle
\[
q_e-q_1-q_3-q_5-q_4-q_2-q_e.
\tag{6}
\]
In this cyclic order, assign its six edges the pairs
\[
PJ,\quad RK,\quad PJ,\quad Rb,\quad Pa,\quad RK.
\tag{7}
\]
The shore port pairs, including terminal \(e\), are
\[
(e,p_1,p_2,p_3,p_4,p_5)
=(ab,ab,Jb,ab,KJ,Ka).
\tag{8}
\]
At \(q_e,q_1,q_3,q_5,q_4,q_2\), respectively, the two cycle-edge pairs and the port pair are
\[
(RK,PJ,ab),\quad(PJ,RK,ab),\quad
(RK,PJ,ab),\quad(PJ,Rb,Ka),\quad
(Rb,Pa,KJ),\quad(Pa,RK,Jb).
\tag{9}
\]
These are again six-label partitions. Thus each label defines an **entire actual perfect matching** of the 21 internal vertices and their terminal semiedges; every edge has load two. Every original prism edge is subdivided. The six-cycle has length six, and a cycle crossing between shore and exterior uses at least two connector edges, one shore edge, and two exterior edges, so the pole is simple, connected, and has girth at least five.

The zero-port shore restriction of \(P\) consists of the first, third, and fifth edges of (6). Its shore complement has three length-three port paths with pairing
\[
ep_2\mid p_1p_3\mid p_5p_4.
\tag{10}
\]
For the \(eX\)-triple \(P\) rooted at \(X:4\), [Note 359's complete exterior pairing table](359-two-root-parity-gate-and-k33-sharpness.md) gives
\[
Xp_5\mid p_1p_2\mid p_3p_4.
\tag{11}
\]
Gluing (10)--(11) makes one open \(X\)-to-\(e\) path and no mixed closed component. The exterior complement's pure cycles, if any, are even by Note 359's parity lemma; the six-cycle shore complement has no closed component. Hence the complement of \(P\) two-colours into actual singleton-\(e\) and singleton-\(X\) perfect matchings. Doubling this Tait colouring yields a genuine \([eX]\) BF loop in the **complete** support.

There is also a Tait-empty 29-vertex boundary with exactly the same complete BF support. At \(q_2\), whose three incident pairs in (9) are \(Pa,RK,Jb\), substitute the Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md), relabelling its six standard matchings to these three attachment pairs. Note 381 proves that this operation preserves **every** BF boundary type, while every zero-port shore matching in the new pole leaves an internal odd five-cycle in its complement. The row (3)--(9) and forbidden \([eX]\) loop therefore both persist. The substituted pole has a cyclic three-edge cut, so this is a boundary for a row-plus-odd-shore-cycle argument, not a minimum-host example.

This example realizes the only route left by Note 462 while violating the required negative support. It does not show that an irreducible larger shore can avoid all forbidden loops and rows. The construction and complement check are hand-derived, with no OMEN or local mathematical recomputation, and await independent review. \(\square\)

Later boundary: [Note 464](464-the-real-x-y-row-has-only-case-xii-allowed-types-with-fixed-shore-masks.md) proves that every exterior recompletion preserving these six complete shore restrictions has a Case-XII-allowed type in the entire \(e\)-sector. Thus the displayed \([eX]\) in the full support necessarily changes the selected shore-mask multiset.
