> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Odd half-support cycles occur in pairs, and order fifteen is sharp

In the half-integral construction of Note 012, let \(C\) be the edges used by
exactly two of the five third-colour matchings \(Q_t\).  Since each Tait
colouring partitions the edge set,

\[
\bigtriangleup_{t=0}^4(L_t\triangle R_t)=C.
\]

Regroup the ten singleton matchings into the two members of each boundary
class.  Each same-boundary pair differs by a disjoint union of proper even
alternating cycles.  Hence

\[
|E(C)|\equiv0\pmod2.
\]

Together with the Petersen-label argument, every odd component has length at
least five and odd components occur in even number.  Boundary terminal
vertices are outside \(C\).  With five distinct terminals, an odd component
therefore forces at least

\[
5+5+5=15
\]

internal vertices.

This bound is sharp for local realizability.  A simple connected cubic
15-vertex 5-pole has five target-S Tait colourings whose half-support is
exactly two disjoint 5-cycles.  It has 52 perfect matchings, singleton class
sizes \((5,4,5,5,5)\), and a capacity-two transversal.  Its complete Tait
state set is

\[
S\cup\{15,34,45\},
\]

so it is not exact-S.  The extra states arise exactly from failures among the
ten prescribed Kempe endpoint pairings: only one of the five selected
colourings has both required pairings.  A 17-vertex realization similarly has
half-support \(C_5\sqcup C_7\), all ten Tait states, and a capacity witness.

Thus local Petersen 5-cycles, cubic realization, parity and endpoint rounding
are not the obstruction.  The remaining exact-S interface is simultaneous
realization of all ten prescribed Kempe boundary pairings in the presence of
paired odd support cycles.

The deterministic pure-standard-library certificate is
`scratch/worker-proof/verify_petersen_realizations.py`.  It hard-codes the two
graphs and colourings and independently checks every matching count, state,
support component, capacity witness and Kempe pairing.

