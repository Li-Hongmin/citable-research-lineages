> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The three-spoke prism excludes the top/adjacent-bottom forbidden pairs

Keep the three-spoke prism exterior of [Note 442](442-the-three-spoke-prism-excludes-the-top-opposite-bottom-forbidden-pair.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,Cc),\qquad
(X,Y,Z,W)=(AC,ab,bc,ca).                                      \tag{1}
\]
The sixth shore port is the terminal \(e\). All matching occurrences below are **complete** perfect matchings of the five-pole, and each occurrence keeps its entire shore restriction during a recompletion.

> **Adjacent-bottom exclusion.** Complete exact-Case-XII BF support on the exterior (1) cannot have forbidden \(e\)-labels \(\{eX,eY\}\) or \(\{eX,eZ\}\), at any shore order or topology.

It suffices to treat \(\{eX,eY\}\): the reflection \(A\leftrightarrow C,\ a\leftrightarrow c\) fixes \(X,W\), swaps \(Y,Z\), and permutes the shore ports \(p_1\leftrightarrow p_2,\ p_3\leftrightarrow p_5\). The allowed pentagons are \(e-Z-X-Y-W-e\) and \(e-Z-Y-X-W-e\). Under the respective identifications \((e,Z,X,Y,W)=(1,3,5,2,4)\) and \((1,3,2,5,4)\), the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires \((eX)(eZ)\), as \((15)(13)\) or \((12)(13)\), and excludes \([eY]\), as \([12]\) or \([15]\), and \((eX)(eY)=(12)(15)\).

Take a required genuine row and name its six occurrences
\[
P=eX,\qquad R=eZ,\qquad K=Z,\qquad J=X,\qquad E=e,\qquad F=e. \tag{2}
\]
The two-letter types specify missing terminal pairs for triples; single letters specify singleton terminals. By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(P,R\) have zero shore ports, \(K,J\) two proper ports each, and \(E,F\) each select \(e\) and three proper ports. Root the tree at the endpoint of \(Z\) used by \(R\). The \(Z\)-starting path of \(R\triangle K\) runs wholly outside the shore: at each tree subdivision it enters from the parent on a \(K\)-half and leaves toward the child on the \(R\)-half. Its other end must be \(W\). An end at \(X\) would give the forbidden \([eX]\) loop, and an end at \(Y\) would give the forbidden \((eX)(eY)\) row. Switching the path to \(W\) preserves \(R\)'s entire shore matching.

There are four root-to-\(W\) tree paths. If \(R=eZ:b\) and the path ends at \(W:a\), then \(P,R\) already use \(cu_5\) twice, while \(K\), which uses neither \(Z:c\) nor \(W:c\), would need that same half. If \(R=eZ:c\) and the path ends directly at \(W:c\), \(P,R\) saturate \(au_3,bu_4\); \(K\) would have to take both \(Y:a\) and \(Y:b\). If \(R=eZ:c\) and the path ends at \(W:a\), \(K\) must take \(Y:b\) at \(b\), so it uses none of the \(u_4\) halves. The path uses the other four tree edges, leaving \(K\) only the single port \(p_4\), contrary to the two-port quota. The sole possible route is
\[
Z-b-u_4-B-u_2-C-u_5-c-W.                                    \tag{3}
\]
The saturated \(au_3,cu_5\) halves force \(K:Y:a,W:c\); since the route occupies \(Cu_5\), its \(X\)-half must be \(X:A\). Thus the complete exterior data of \(K\) are
\[
R=eZ:b,\qquad
K:Z;\ X:A,Y:a,W:c,\ bu_4,Bu_2,Cu_5;\ p_1,p_3.             \tag{4}
\]
In particular, no shore topology or parity assumption entered this reduction.

Let \(\Lambda=\{J,E,F\}\), and write a juxtaposition of two occurrence names for the corresponding two-label set. At a tree subdivision, an ordered triple means the label pairs on its first endpoint half, second endpoint half, and proper port. At a marked subdivision the order is terminal, first endpoint half, second endpoint half. Thus \(u_1=(A,B),u_2=(B,C),u_3=(A,a),u_4=(B,b),u_5=(C,c)\), while \(t_X=(A,C),t_Y=(a,b),t_Z=(b,c),t_W=(a,c)\).

## Every old port profile

If \(P=eX:A\), let \(L_1,L_2,L_4\) be the permutation of \(\Lambda\) accompanying \(P,K,R\), respectively, on \(Bu_1,Bu_2,Bu_4\). Let \(H\) accompany \(R\) on \(Au_1\). At \(C\), \(J\) accompanies \(K\) on \(Cu_5\), while \(E,F\) use \(X:C\). The \(u_1\) slot gives \(H\ne L_1\), hence \(H=L_2\) or \(L_4\). With \(T\) the remaining element of \(\{L_2,L_4\}\), the five old port pairs are
\[
\begin{array}{c|ccccc}
 &p_1&p_2&p_3&p_4&p_5\\ \hline
 P=eX:A &KT&\Lambda\setminus\{L_2\}&KH&\Lambda\setminus\{L_4\}&EF.
\end{array}                                                   \tag{5}
\]

If \(P=eX:C\), relabel the two singleton-\(e\) occurrences so that \(E:X:A\), \(F:X:C\). Let \(L_4\in\Lambda\) accompany \(R\) on \(Bu_4\), and let \(H,L_c\) be the permutation of \(\{J,E\}\) accompanying \(R,K\) on \(Cu_2,Cu_5\), respectively. The old pairs are
\[
\begin{array}{c|ccccc}
 &p_1&p_2&p_3&p_4&p_5\\ \hline
 P=eX:C &KL_4&\Lambda\setminus\{H\}&KE&\Lambda\setminus\{L_4\}&\Lambda\setminus\{L_c\}.
\end{array}                                                   \tag{6}
\]
These are exhaustive: (4) fixes all bottom original vertices; at the top vertices \(P,R,K\) fix the stated slots, and the remaining pairs must partition \(\Lambda\). The formulas record **labelled** ports, so the shore restrictions need not be equal or interchangeable.

## Port-preserving forbidden recompletions

There are three target types, with the following common marked-subdivision pairs. In type \(M\), take \(P=eY:a,R=eY:b,K=J=Y,E=F=e\); in type \(B\), take \(P=R=eY:b,K=J=Y,E=F=e\); in type \(D\), take \(P=eX,R=eY:b,K=Y,J=X,E=F=e\). Equal type symbols never assert equality of complete matchings; in particular, the six shore restrictions remain the six original ones.
\[
\begin{array}{c|ccc}
 &t_Y&t_Z&t_W\\ \hline
 M&(KJ,PF,RE)&(PR,JF,KE)&(PR,KE,JF)\\
 B&(KJ,EF,PR)&(PR,EF,KJ)&(PR,KJ,EF)\\
 D&(PK,JF,RE)&(PR,JF,KE)&(PR,KE,JF).
\end{array}                                                   \tag{7}
\]
The remaining marked subdivision \(t_X\) and all five tree subdivisions are prescribed below. Every row's port entries are exactly (5) or (6), **with each occurrence name unchanged**.

For (5), the three exhaustive cases are:
\[
\begin{array}{c|ccccc|c}
\text{condition/type}&u_1&u_2&u_3&u_4&u_5&t_X\\ \hline
H\in\{E,F\},\ M
 &(RH,PL_1,KT)&(KL_2,PR,\Lambda\setminus\{L_2\})
 &(P\bar H,RJ,KH)&(RL_4,PK,\Lambda\setminus\{L_4\})
 &(KJ,PR,EF)&(PR,KJ,EF)\\
H=L_4=J,\ B
 &(PR,JL_1,KL_2)&(KL_2,PR,JL_1)
 &(EF,PR,KJ)&(PR,KJ,EF)&(KJ,PR,EF)&(PR,KJ,EF)\\
H=L_2=J,\ D
 &(RJ,PE,KF)&(KJ,PR,EF)&(EF,PR,KJ)
 &(RF,PK,JE)&(KJ,PR,EF)&(RJ,PK,EF).
\end{array}                                                   \tag{8}
\]
Here \(\bar H\) is the other element of \(\{E,F\}\) in the first line. In the last line, relabel \(E=L_1,F=L_4\); then (5) is \((KF,EF,KJ,JE,EF)\).

For (6), the three exhaustive cases are:
\[
\begin{array}{c|ccccc|c}
\text{condition/type}&u_1&u_2&u_3&u_4&u_5&t_X\\ \hline
H\ne L_4,\ M
 &(RH,PT,KL_4)&(KH,PR,\Lambda\setminus\{H\})
 &(PF,RJ,KE)&(RL_4,PK,\Lambda\setminus\{L_4\})
 &(KL_c,PR,\Lambda\setminus\{L_c\})&(PR,KL_c,HF)\\
H=L_4=J,\ B
 &(PR,EF,KJ)&(KJ,PR,EF)&(JF,PR,KE)
 &(PR,KJ,EF)&(KE,PR,JF)&(PR,KE,JF)\\
H=L_4=E,\ D
 &(PR,JF,KE)&(PK,RE,JF)&(JF,PR,KE)
 &(RE,PK,JF)&(KJ,PR,EF)&(RJ,KE,PF).
\end{array}                                                   \tag{9}
\]
In the first line \(T=\Lambda\setminus\{H,L_4\}\) is one label. The cases \(H\ne L_4\), \(H=L_4=J\), and \(H=L_4=E\) partition all possibilities because \(H\in\{J,E\}\).

For a direct matching check, every parenthesized triple in (7)–(9) partitions \(\{P,R,K,J,E,F\}\). The pairs at the original top vertices also partition it. In the six lines of (8)–(9), respectively, the pairs at \(A,B,C\) are
\[
\begin{array}{c|ccc}
 &(A)&(B)&(C)\\ \hline
M\text{ from (5)}&(KJ,RH,P\bar H)&(PL_1,KL_2,RL_4)&(EF,PR,KJ)\\
B\text{ from (5)}&(KJ,PR,EF)&(JL_1,KL_2,PR)&(EF,PR,KJ)\\
D\text{ from (5)}&(PK,RJ,EF)&(PE,KJ,RF)&(EF,PR,KJ)\\
M\text{ from (6)}&(KL_c,RH,PF)&(PT,KH,RL_4)&(HF,PR,KL_c)\\
B\text{ from (6)}&(KE,PR,JF)&(EF,KJ,PR)&(JF,PR,KE)\\
D\text{ from (6)}&(KE,PR,JF)&(JF,PK,RE)&(PF,RE,KJ).
\end{array}                                                   \tag{10}
\]
At \(a,b,c\), type \(M\) has respectively \((RJ,PF,KE),(PK,RE,JF),(PR,KE,JF)\); type \(B\) has \((PR,EF,KJ),(KJ,PR,EF),(PR,KJ,EF)\); and type \(D\) has \((PR,JF,KE),(PK,RE,JF),(PR,KE,JF)\). Thus every occurrence selects exactly one edge at every exterior vertex and every exterior edge has load two. The port pair at \(e\) is still \(EF\); every proper port pair is unchanged by (8) or (9). Gluing to the six **original, possibly distinct** complete shore matchings produces a genuine BF row of forbidden \([eY]\) type in cases \(M,B\), or forbidden \((eX)(eY)\) type in case \(D\).

The required \((eX)(eZ)\) row therefore cannot exist. Reflection excludes \(\{eX,eZ\}\) as well. Together with Note 442 this removes three of the six forbidden pairs for this one three-spoke prism tree orbit. The remaining pairs are \(\{eY,eZ\}\), \(\{eW,eY\}\), and its reflection \(\{eW,eZ\}\). Other exteriors and Berge–Fulkerson remain open. This is a hand proof, checked only within this derivation; no OMEN or local mathematical recomputation was used. \(\square\)
