> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The long \(K_{3,3}\) row forces one Case-XII pentagon and specified shore \(e\)-paths

Keep the \(|U|=r=5\) exterior, terminal names and **actual complete** BF row of [Note 489](489-k33-hamilton-adjacent-allowed-pair-has-one-long-root-signature.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,16,25,36),
\]
\[
P=eZ,\quad R=eX,\quad K=X,\quad J=Z,\quad a=b=e
\quad\text{(boundary roles, not equality of matchings).}                 \tag{1}
\]
Assume complete exact Case-XII support and forbidden \(e\)-states \(eZ,eW\). The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the row (1) and forbids every \(T\)--\(T\) type. The two possible allowed pentagons are
\[
S_1=e-X-Z-W-Y-e,\qquad S_2=e-X-W-Z-Y-e.                 \tag{2}
\]

**Necessary boundary.** The row (1) must use \(S_1\). Its singleton \(J=Z\) must occupy
\[
J:Y:1,\quad X:4,\quad W:6.                             \tag{3}
\]
Let \(R'\) be obtained by switching \(R,K\) on Note 489's long \(X\)--\(Y\) path, so \(R'=eY\), while \(R\) and \(R'\) have the same *complete shore matching*. There is a uniquely specified singleton-\(e\) occurrence \(D_0\in\{a,b\}\) with exterior marks \(X:1,Y:6,Z:2,W:3\), tree halves \(4u_4,5u_5\), and proper ports \(p_1,p_2,p_3\). In the shore-only symmetric difference between \(R\) and \(D_0\), its \(e\)-starting path must end at \(p_2\).

The other singleton-\(e\) occurrence \(D_1\) has the following further necessary shore \(e\)-path endpoint. The notation \(J:2u_i\) or \(J:5u_i\) describes its tree half at the indicated original vertex.

| root of \(P=eZ\) | additional half of \(J\) | required \(e\)-partner in \(Q_R\triangle Q_{D_1}\) |
|---|---|---|
| \(Z:2\) | \(2u_1\) | \(p_1\) |
| \(Z:2\) | \(2u_2\) | \(p_2\) |
| \(Z:5\) | \(5u_4\) | \(p_2\) |
| \(Z:5\) | \(5u_5\) | \(p_2\) |

Here \(Q_M\) denotes the complete shore restriction of a matching occurrence \(M\). The statement makes no assertion that any one of these four residual rows exists on a shore, or that the shore path conditions suffice for exact support.

**Proof.** By Note 489, \(R\) uses marked half \(X:4\) and tree halves
\(1u_1,2u_2,3u_3,5u_4,6u_5\); \(K\) uses \(Y:1,Z:5,W:6\), tree halves \(2u_1,3u_2,4u_3\), and ports \(p_4,p_5\). Switching their exterior \(X\)--\(Y\) path gives \(R'=eY\), rooted at \(Y:1\), with tree halves \(2u_1,3u_2,4u_3,5u_4,6u_5\). A zero-port triple rooted at \(Z:2\) or \(Z:5\) gives the only two possibilities for \(P\).

For either \(D\in\{a,b\}\), let \(E\) be the other singleton-\(e\) occurrence. The two complementary three-matching half-loads are
\[
A=R+K+D=R'+K'+D,\qquad B=P+J+E,
\qquad A+B=2\mathbf1.                                      \tag{4}
\]
The unchanged half \(B\) has state \(eZ\in T\). Switching the \(e\)-starting component of the **whole-pole** \(R\triangle D\) gives \(A\) a pair state \(Xt\), where \(t\in\{Y,Z,W\}\). Doing the same in \(R'\triangle D\) gives \(Yt'\), where \(t'\in\{X,Z,W\}\). To avoid a forbidden genuine \(T\)--\(T\) row, both states must lie in the allowed pentagon. For \(S_1\) this requires \((t,t')=(Z,W)\); for \(S_2\) it requires \((t,t')=(W,Z)\).                         \(\tag{5}\)

At vertex 1, \(P,R\) both take \(1u_1\) and \(K\) takes \(Y:1\); at vertex 6, \(P,R\) both take \(6u_5\) and \(K\) takes \(W:6\). The load-two rule forces \(J\) to use one of \(X:1,Y:1\) and one of \(Y:6,W:6\). Since \(J\) uses each mark \(X,Y,W\) exactly once, it has precisely two possible marked patterns:
\[
\begin{array}{c|ccc}
 &X&Y&W\\\hline
\mathrm I&1&6&3\\
\mathrm{II}&4&1&6
\end{array}.                                                \tag{6}
\]

In pattern I, the load-two rule supplies a singleton-\(e\) occurrence \(D_B\) with marks \(Y:1,X:4,W:6\). Its shore port paired with \(e\) in \(Q_R\triangle Q_{D_B}\) is one of its three proper ports. The following table is obtained by following each alternating arm from a marked terminal to its first proper port; \(Tp_i\) abbreviates the arm joining terminal \(T\) to \(p_i\), and \(q\in\{4,5\}\), \(s\in\{1,2\}\).

| root of \(P\) | root of \(D_B\) at \(Z\) | exterior \(R\triangle D_B\) | exterior \(R'\triangle D_B\) |
|---|---|---|---|
| \(Z:5\) | \(Z:2\) | \(Yp_1,Zp_3,Wp_q\) | \(Xp_3,Zp_1,Wp_q\) |
| \(Z:2\) | \(Z:2\) | \(Yp_1,Zp_2,Wp_4\) | \(Xp_2,Zp_1,Wp_4\) |
| \(Z:2\) | \(Z:5\) | \(Yp_s,Zp_4,Wp_5\) | \(Xp_s,Zp_4,Wp_5\) |

Thus an old \(e\)-path ending at \(Z\) ends afterwards at \(X\) or \(Z\), and one ending at \(W\) still ends at \(W\). Neither transition in (5) occurs. This excludes pattern I for both roots of \(P\), independently of the complete shore matching identities.

In pattern II, the load-two rule supplies exactly one \(D_0\) with the masks stated above. Its exterior pairings are
\[
\begin{array}{c|ccc}
 R\triangle D_0&Yp_1&Zp_2&Wp_3\\
 R'\triangle D_0&Xp_3&Zp_1&Wp_2.
\end{array}                                                \tag{7}
\]
The shore part is identical in the two comparisons, since \(Q_R=Q_{R'}\). If its \(e\)-path reaches \(p_1,p_2,p_3\), respectively, the complete terminal endpoint changes \(Y\to Z,\ Z\to W,\ W\to X\). Only \(Z\to W\) meets (5). This proves \(S=S_1\) and \(\sigma(D_0)=p_2\).

For completeness, the remaining four pattern-II exterior possibilities give the last table. It also records all proper ports of \(D_1\); the same fixed shore \(e\)-arm argument determines the third column of the theorem.

| root \(P\); extra half \(J\) | ports of \(D_1\) | exterior \(R\triangle D_1\) | exterior \(R'\triangle D_1\) |
|---|---|---|---|
| \(Z:2;\ 2u_1\) | \(p_1,p_3,p_5\) | \(Yp_5,Zp_1,Wp_3\) | \(Xp_5,Zp_3,Wp_1\) |
| \(Z:2;\ 2u_2\) | \(p_2,p_3,p_5\) | \(Yp_5,Zp_2,Wp_3\) | \(Xp_5,Zp_3,Wp_2\) |
| \(Z:5;\ 5u_4\) | \(p_1,p_2,p_4\) | \(Yp_4,Zp_2,Wp_1\) | \(Xp_4,Zp_1,Wp_2\) |
| \(Z:5;\ 5u_5\) | \(p_1,p_2,p_5\) | \(Yp_5,Zp_2,Wp_1\) | \(Xp_5,Zp_1,Wp_2\) |

Each row has exactly one port whose old arm ends at \(Z\) and new arm at \(W\). Following the marked and tree halves listed above checks every table entry; the shore itself is never replaced by a formal port signature. All switches use complete matching occurrences and preserve the two full three-matching loads in (4). \(\square\)

**A genuine row meets the residual path conditions but has forbidden full support.** Take the even shore to be the six-cycle
\[
                  p_3-p_5-p_4-p_1-e-p_2-p_3,              \tag{8}
\]
where each symbol names the shore vertex carrying that terminal or proper port. The vertex \(e\) is the subdivision of the marked shore edge \(p_1p_2\); suppressing it leaves a five-cycle. Use the \(P:Z:5,\ J:5u_4\) exterior row. The following table gives all nonterminal exterior choices and all shore-cycle edges in each **complete** matching. An omitted exterior marked edge uses its terminal half; \(D_0,D_1\) each use the \(e\) terminal.

| occurrence | marked halves and tree halves; proper ports | shore-cycle edges |
|---|---|---|
| \(P=eZ\) | \(Z:5;\ 1u_1,2u_2,3u_3,4u_4,6u_5\) | \(p_5p_4,p_1e,p_2p_3\) |
| \(R=eX\) | \(X:4;\ 1u_1,2u_2,3u_3,5u_4,6u_5\) | \(p_3p_5,p_4p_1,ep_2\) |
| \(K=X\) | \(Y:1,Z:5,W:6;\ 2u_1,3u_2,4u_3;\ p_4,p_5\) | \(p_1e,p_2p_3\) |
| \(J=Z\) | \(X:4,Y:1,W:6;\ 2u_1,3u_2,5u_4;\ p_3,p_5\) | \(p_4p_1,ep_2\) |
| \(D_0=e\) | \(X:1,Y:6,Z:2,W:3;\ 4u_4,5u_5;\ p_1,p_2,p_3\) | \(p_5p_4\) |
| \(D_1=e\) | \(X:1,Y:6,Z:2,W:3;\ 4u_3,5u_5;\ p_1,p_2,p_4\) | \(p_3p_5\) |

Each original vertex, subdivision vertex, shore vertex and terminal edge has load two, so these are six actual perfect-matching occurrences of a cubic five-pole BF row. The shore \(e\)-path in both \(Q_R\triangle Q_{D_i}\) is the single edge \(ep_2\), as required by the theorem. The pole has \(6+5+4+6=21\) internal vertices and girth five: exterior-only cycles have length at least eight, the shore is a six-cycle, and a mixed cycle uses at least two proper edges, one shore edge and an exterior path of length at least two. The shore edge \(p_2p_3\), together with \(u_2-3-u_3\) and its two proper edges, attains length five.

Nevertheless, the complete support contains the forbidden loop \([eZ]\). In the complement of \(P\), the exterior pairs
\[
             Zp_1\mid p_2p_3\mid p_4p_5,
\]
while the shore complement pairs
\[
             ep_2\mid p_1p_4\mid p_3p_5.
\]
They glue into one path \(e-p_2-p_3-p_5-p_4-p_1-Z\). To check that no closed component was omitted, write \(\bar e,\bar p_i\) for the six shore vertices in (8). Between terminal \(e\) and terminal \(Z\), the path visits all 21 internal vertices in this order:
\[
\bar e,\bar p_2,u_2,3,t_W,6,t_Y,1,t_X,4,u_3,
\bar p_3,\bar p_5,u_5,5,u_4,\bar p_4,\bar p_1,u_1,2,t_Z.
\]
Alternating its edges gives two further complete perfect matchings beside \(P\), hence a genuine \(eZ\)-Tait colouring and the BF loop \([eZ]\). This pole is a counterexample to the *sufficiency* of the two shore-path conditions, not an exact-Case-XII pole or a counterexample to Berge--Fulkerson.

Path reflection \(i\mapsto7-i\) gives the analogous necessary orientation for the forbidden pair \(\{eZ,eX\}\). [Notes 492--494](494-the-last-two-k33-long-signatures-also-force-forbidden-ew-loops.md) subsequently exclude all four residual signatures from exact Case XII by fixed-full-shore-mask recompletions. Other forbidden pairs in this Hamilton \(K_{3,3}\) tree, the one-spoke prism, other five-pole profiles, and the Berge--Fulkerson conjecture remain open. This is a hand proof with no OMEN or local mathematical recomputation; an independent check is still needed before treating the wider exclusion chain as settled.
