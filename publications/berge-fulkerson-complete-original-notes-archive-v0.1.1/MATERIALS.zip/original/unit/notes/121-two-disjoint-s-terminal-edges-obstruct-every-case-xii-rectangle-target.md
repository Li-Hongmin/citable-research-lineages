> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two disjoint \(S\)-terminal edges obstruct every Case-XII rectangle target

**Superseded exact-support interpretation.** [Note 122](122-disjoint-s-terminal-edges-force-forbidden-all-terminal-bf-cover.md) proves that an exact-Case-XII pole cannot contain the two terminal edges assumed below, even without a six-row assignment. [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) excludes each \(S\)-terminal edge individually. Thus the conditional rectangle implication in this note is vacuous on the exact-support class. The local incidence table and the smaller-core seed equivalence remain valid under their stated hypotheses, but they are not a route to a real exact-Case-XII counterexample.

The [local BF recolouring lemma](120-t-paired-terminal-tree-two-cuts-are-forbidden-in-exact-case-xii.md) gives a formal consequence for the complete opposite-carrier rectangle predicate of [Note 117](117-existential-case-xii-rectangle-transfers-through-colourable-two-sums.md): under the two negative support exclusions and proper terminal edges \(1\)--\(4\), \(2\)--\(5\), every hypothetical six-row assignment fails all four full-projection target tests. These two edges are disjoint members of the \(S\)-pentagon and compatible with the girth-five and terminal-tree cut *shapes* inherited in [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md). Note 122 proves that adding the required positive \((14)(23)\) type already contradicts those exclusions, so no exact-support pole meets this premise.

## Statement

Assume the complete BF support of a loopless cubic five-pole \(H\) has no all-terminal type and no \(T\)--\(T\) type, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Suppose \(H\) contains a proper edge \(h_{14}\) joining the vertices incident with semiedges \(s_1,s_4\), and a proper edge \(h_{25}\) joining those incident with \(s_2,s_5\). Let \(\rho\) be any actual matching assignment satisfying the six Note-101 BF rows, with the repeated names \(B,C\) interpreted literally. In particular it has the two rows
\[
q_{14}+A+C+r_{23}+B+X=2\mathbf1,
\qquad q'_{25}+r_{34}+B+Y+C+D=2\mathbf1.          \tag{1}
\]
Set
\[
K_{23}=2\mathbf1-r_{23}-B-X,
\qquad K_{34}=2\mathbf1-r_{34}-Y-C.                 \tag{2}
\]
Then the four complete opposite-witness domination tests of Note 117 are all false:
\[
\boxed{\Phi(H,\rho)=\mathrm{false}.}                         \tag{3}
\]
The result remains true if additional aliases or disequalities are imposed on \(\rho\), since the proof uses only (1).

## The two edge-incidence constraints

The two BF rows in (1) have the following forced incidences. An entry lists exactly the two matching occurrences whose labels use that proper edge:

| edge | left row \((14)(23)\) | right row \((25)(34)\) | \(K_{23}\) | \(K_{34}\) |
|---|---|---|---:|---:|
| \(h_{14}\) | \(B,X\) | \(B,Y\) | 0 | 1 |
| \(h_{25}\) | \(X,C\) | \(Y,C\) | 1 | 0 |

Here is the full-mask derivation. At \(h_{14}\) in the left row, the terminal labels at positions \(1,4\) share \(r_{23}\). The only colours absent at both terminals are \(q_{14},B,X\). If \(q_{14}\) used the edge, swapping it with \(r_{23}\) on the two terminal semiedges and on \(h_{14}\), as in Note 120(4), would give an all-terminal BF colour. Hence the edge uses exactly \(B,X\). In the right row the labels at \(1,4\) share \(q'_{25}\), and the colours absent at both are \(B,Y,D\). If \(D\) used the edge, the same local swap would make \(D\) a triple colour missing \(23\) while \(r_{34}\) remains a triple colour missing \(34\), giving a forbidden \(T\)--\(T\) type. Thus the edge uses exactly \(B,Y\).

At \(h_{25}\) in the right row, the labels at \(2,5\) share \(r_{34}\); the three colours absent at both are \(q'_{25},Y,C\). Putting \(q'_{25}\) on the edge would permit an all-terminal local swap, so the edge uses exactly \(Y,C\). In the left row the labels at \(2,5\) share \(q_{14}\); the absent colours are \(A,X,C\). Putting \(A\) on the edge would make \(A\) a triple colour missing \(34\) while \(r_{23}\) remains a triple colour missing \(23\). Thus the edge uses exactly \(X,C\). All these deductions concern actual edges and actual BF colourings of the complete graph, so the negative-support exclusions apply.

## Every opposite witness is blocked

The table immediately gives \(Y(h_{14})=1>K_{23}(h_{14})=0\) and \(X(h_{25})=1>K_{34}(h_{25})=0\). Hence the target-\(Y\) and target-\(X\) tests fail for every choice of opposite witness.

For target \(D\), [Note 117](117-existential-case-xii-rectangle-transfers-through-colourable-two-sums.md)(3) takes an opposite witness \(W\in\mathcal F_2(K_{34};5)\). By definition there are actual matchings \(Q\) with triple boundary \([5]\setminus\{2,5\}\) and \(Z\) with singleton boundary \(5\) such that
\[
K_{34}=Q+W+Z.                                            \tag{4}
\]
Together with the fixed half \(r_{34}+Y+C\), this is another genuine BF row. At terminals \(1,4\), its common colour is \(Q\), and the three colours absent at both are \(Y,W,Z\). If \(Z\) used \(h_{14}\), swapping \(Q\) with \(Z\) would create the forbidden pair of \(T\)-states \(23,34\). Thus \(h_{14}\) uses \(Y,W\), in particular \(W(h_{14})=1\). Since \(K_{23}(h_{14})=0\), the domination \(D+W\le K_{23}\) fails.

For target \(A\), an opposite witness \(W\in\mathcal F_4(K_{23};1)\) belongs to a genuine BF row
\[
r_{23}+B+X+Q+W+Z=2\mathbf1,                         \tag{5}
\]
where \(Q\) has triple boundary \([5]\setminus\{1,4\}\) and \(Z\) has singleton boundary \(1\). At terminals \(2,5\), the common colour is \(Q\), and the three absent colours are \(X,W,Z\). If \(Z\) used \(h_{25}\), the local swap would create the forbidden \(T\)--\(T\) type \((34)(23)\). Therefore \(h_{25}\) uses \(X,W\), so \(W(h_{25})=1>K_{34}(h_{25})=0\). This blocks target \(A\) and proves (3). \(\square\)

## Footprint after deleting both terminal trees

Assume additionally that all four other proper edges at the tree vertices lead to the surviving core, rather than joining the two trees to each other. This holds in the minimum-host setting of Note 019: any cross edge between the two trees would make a three-terminal path isolated by a proper two-edge-cut, excluded by the cut classification and the order bound as in Note 120. Deleting both trees then leaves a smaller cubic five-pole \(K\), possibly with repeated terminal vertices: its first, second, fourth and fifth semiedges are the former connector edges, while semiedge \(3\) is unchanged. The forced local patterns above give the exact boundary masks of the ten named matchings after projection:

| matching in \(H\) | \(A\) | \(B\) | \(X\) | \(C\) | \(q_{14}\) | \(r_{23}\) | \(q'_{25}\) | \(r_{34}\) | \(Y\) | \(D\) |
|---|---|---|---|---|---|---|---|---|---|---|
| boundary in \(K\) | 245 | 5 | 3 | 1 | 134 | 2 | 235 | 4 | 3 | 124 |

For example, \(A\) uses semiedge \(s_1\) at the \(14\)-tree, so it uses the opposite connector \(4\); it avoids both semiedges at the \(25\)-tree and, by the first table, avoids its internal edge, so it uses both connectors \(2,5\). Hence its projected boundary is \(245\). Every other table entry follows from the same four local matching patterns. The first row in (1) projects to an actual BF row of type \((13)(25)\) in \(K\); the second projects to one of type \((14)(35)\). Their projected class-\(5\) and class-\(1\) matchings remain literally shared. This is a necessary condition on any attempted real exact-support construction with two terminal edges; \(K\) is not claimed to have exact Case-XII support.

The footprint is also an exact **seed-existence criterion** under the negative support assumptions. Write \(U_{ij}\) for an actual matching of \(K\) with triple boundary \([5]\setminus\{i,j\}\). Define \(\operatorname{CoreSeed}(K)\) by two BF rows
\[
\begin{aligned}
U_{13}+P_5+P_3+P_1+U_{25}+P_2&=2\mathbf1,\\
P_5+P'_3+P_1+U_{35}+U_{14}+P_4&=2\mathbf1,
\end{aligned}                                                   \tag{6}
\]
where \(P_5,P_1\) are the **same complete matchings** in both rows, and no identity between \(P_3,P'_3\) is required. The table proves \(\operatorname{Seed}(H)\Rightarrow\operatorname{CoreSeed}(K)\) when \(H\) excludes all-terminal and \(T\)--\(T\) BF types.

Conversely, any two rows (6) on \(K\) lift to the seed (1) on \(H\). At each tree, a matching using one connector must use the semiedge at the opposite tree vertex; a matching using both connectors uses neither semiedge nor the internal edge; a matching using neither connector can choose either the internal edge or both terminal semiedges. Make the latter choices according to the inverse boundary table above. Every named \(K\)-matching then has a unique lift with its required boundary in (1). The resulting internal-edge occurrence pairs are exactly \(B,X\) and \(B,Y\) on \(h_{14}\), and \(X,C\) and \(Y,C\) on \(h_{25}\); the terminal semiedges also have load two in each row. Every surviving core edge has load two by (6), and the shared \(P_5,P_1\) lift to literal common \(B,C\). Hence, provided the four connectors lead to the surviving core,
\[
\boxed{\text{no }(12345),\text{ no }T\text{--}T\text{ support on }H
\quad\Longrightarrow\quad
\bigl(\operatorname{Seed}(H)\iff\operatorname{CoreSeed}(K)\bigr).}
                                                               \tag{7}
\]
The reverse construction does not claim that inserting the two trees preserves or creates exact Case-XII **support**; only the two specified actual BF rows are lifted.

## Exact logical boundary

The theorem proves the implication
\[
\begin{gathered}
\text{exact Case-XII support + both terminal edges }h_{14},h_{25}\\
\text{+ at least one six-row assignment}
\end{gathered}
\Longrightarrow
\text{no six-row assignment satisfies the Note-117 rectangle predicate}.
                                                               \tag{8}
\]
It is **not** a realized exact-Case-XII counterexample. Note 122 supplies the missing closure step: the left row of (1) alone, together with the two internal-edge incidences in the first table, yields an all-terminal BF colouring after two independent local swaps. Note 123 excludes each \(S\)-terminal edge separately. The conditional domination failures above remain correct as load identities, but do not define a live exact-support counterexample branch. A positive rectangle theorem can focus on the zero-terminal-edge case.

For a direct topology witness, begin with a five-cycle core carrying one semiedge at each vertex. Replace the terminal semiedges at \(1,4\) by a two-vertex terminal tree attached at those two old vertices, and do the same at \(2,5\). The resulting nine-vertex proper core is a five-cycle with two internally disjoint length-three paths joining the nonadjacent pairs \(1,4\) and \(2,5\). It is simple, connected, bridgeless and has girth five; the middle edges of its two added paths are \(h_{14},h_{25}\). This small pole does **not** have exact Case-XII support by the direct order bound of [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md). Its role is only to show that the two-edge shape itself does not require a short cycle.
