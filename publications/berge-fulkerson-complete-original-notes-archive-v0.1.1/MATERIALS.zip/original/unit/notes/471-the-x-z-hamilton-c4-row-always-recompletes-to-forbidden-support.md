> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(C_4\) row always recompletes to forbidden support

Continue the fixed marked Hamilton exterior and matching names of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In signature \(C_4\), the required old \((eX)(eY)\) row has \(P=eX\) rooted at \(X:4\), \(R=eY\) rooted at \(Y:5\), and \(K=Y\) on marked halves \(X:1,Z:2,W:6\), tree halves \(3u_2,4u_3,5u_5\), and proper ports \(p_1,p_4\). We exclude every labelled port phase by changing only exterior pairs and retaining all six complete shore matching restrictions separately.

Put \(S=\{J,a,b\}\). The old pairs at \(X\) are \((RJ,K\lambda,P\bar\lambda)\), with \(\{\lambda,\bar\lambda\}=\{a,b\}\), in terminal/first-half/second-half order. The old pairs at the five tree subdivisions, in first-half/second-half/port order, are forced to be
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,S\setminus\{\alpha\},K\alpha)
&(PR,K\alpha,S\setminus\{\alpha\})
&(PR,K\delta,S\setminus\{\delta\})
&(R\epsilon,P\theta,K\eta)
&(K\xi,PR,S\setminus\{\xi\}),
\end{array}                                                   \tag{1}
\]
where \(\alpha\in S\) and
\[
\{\bar\lambda,\delta,\epsilon\}=S,
\qquad \{\epsilon,\theta,\eta\}=S,
\qquad \{\lambda,\theta,\xi\}=S.                            \tag{2}
\]
Indeed \(K\)'s old port \(p_1\), together with the common \(PR\) half at \(1u_1\), gives \(u_1\). Original vertex \(2\), with \(2u_2=PR\), then gives \(Z:2=K\alpha\). The old \(Z,W\) terminal pair \(PR\) and vertex \(6\) give \(Z:6=W:3=S\setminus\{\alpha\}\), \(W:6=K\alpha\), and hence \(u_2,u_3\) as displayed. The three equations in (2) are the partitions at vertex \(4\), at \(u_4\), and at vertex \(5\). Conversely these are the only old exterior constraints needed below. In particular the old proper-port list is
\[
 (p_1,p_2,p_3,p_4,p_5)=
 (K\alpha,S\setminus\{\alpha\},S\setminus\{\delta\},K\eta,S\setminus\{\xi\}),
 \qquad e=ab.                                                \tag{3}
\]

## \(\xi=J\): a forbidden double triple for every \(\alpha\)

If \(\xi=J\), equations (2) give \(\theta=\bar\lambda\) and \(\delta=\eta\). Thus (3) is
\((K\alpha,S\setminus\{\alpha\},S\setminus\{\eta\},K\eta,ab)\), with no restriction on \(\alpha\). Keep those port pairs and put
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,S\setminus\{\alpha\},K\alpha)
&(PK,R\alpha,S\setminus\{\alpha\})
&(PK,R\eta,S\setminus\{\eta\})
&(S\setminus\{\eta\},PR,K\eta)
&(KJ,PR,ab).
\end{array}                                                   \tag{4}
\]
At the marked subdivisions put
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PR,KJ,ab)&
(PK,R\alpha,S\setminus\{\alpha\})&
(PR,S\setminus\{\alpha\},K\alpha).
\end{array}                                                   \tag{5}
\]
The original vertices \(1,\ldots,6\) then see
\[
(PR,ab,KJ),\quad
(S\setminus\{\alpha\},PK,R\alpha),\quad
(R\alpha,PK,S\setminus\{\alpha\}),\quad
(R\eta,PK,S\setminus\{\eta\}),\quad
(PR,ab,KJ),\quad
(PR,S\setminus\{\alpha\},K\alpha).                    \tag{6}
\]
Every triple in (4)--(6) is a six-label partition. The terminals are \(e=ab,X=RJ,Z=PK,Y=W=PR\), the forbidden \((eX)(eZ)\) type.

## \(\xi\ne J\): two remaining phases of \(\alpha\)

Now (2) forces \(\xi=\bar\lambda\), \(\theta=J\), \(\delta=J\), \(\epsilon=\lambda\), and \(\eta=\xi\). The old port list becomes
\[
       (K\alpha,S\setminus\{\alpha\},ab,K\xi,S\setminus\{\xi\}). \tag{7}
\]
If \(\alpha\in\{a,b\}\), let \(\bar\alpha\) be the other element of \(\{a,b\}\). Use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RJ,P\bar\alpha,K\alpha)
&(RK,P\alpha,S\setminus\{\alpha\})
&(RJ,PK,ab)
&(RJ,P\lambda,K\xi)
&(R\xi,PK,S\setminus\{\xi\}),
\end{array}                                                   \tag{8}
\]
and
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,PK,ab)&(PR,ab,KJ)&
(PK,S\setminus\{\bar\alpha\},R\bar\alpha)&
(PR,K\bar\alpha,S\setminus\{\bar\alpha\}).
\end{array}                                                   \tag{9}
\]
At vertices \(1,\ldots,6\) the pairs are
\[
(PK,RJ,ab),\quad
(P\bar\alpha,RK,S\setminus\{\bar\alpha\}),\quad
(P\alpha,RJ,K\bar\alpha),\quad
(PK,RJ,ab),\quad
(P\lambda,KJ,R\xi),\quad
(PK,R\bar\alpha,S\setminus\{\bar\alpha\}).            \tag{10}
\]
Every triple in (8)--(10) partitions all six labels, including when \(\alpha=\lambda\) or \(\alpha=\xi\). Its port column is (7), and its terminals again give forbidden \((eX)(eZ)\).

Finally, if \(\alpha=J\), (7) satisfies \(p_2=\bar p_1\), \(p_3=ab\), and \(p_5=\bar p_4\), where complement is within \(I=\{K,J,a,b\}\). [Note 469, equations (2)--(4)](469-the-x-z-hamilton-b3-row-also-forces-forbidden-full-support.md) therefore applies verbatim: its exterior pair table retains (7) and \(e=ab\), and has terminal pairs \(Z=KJ\), \(X=Y=W=PR\). This is the forbidden \([eZ]\) loop. The use of that table depends only on the three stated port identities, not on the old signature being \(B_3\).

All three cases glue to the original six **complete** shore matchings, one occurrence each, for any shore order or topology. Thus no exact-Case-XII pole with this marked exterior has a genuine \(C_4\) row. With [Note 470](470-two-x-z-hamilton-c-signatures-force-the-forbidden-double-triple.md), the \(\{eX,eZ\}\) forbidden pair now has only \(C_3,C_5,C_6,C_7\) among Note 466's necessary signatures. Reflection gives the corresponding exclusions for \(\{eY,eW\}\). This hand proof awaits independent review; the other signatures, other exteriors, full exact Case XII and Berge--Fulkerson remain open. \(\square\)
