> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All-terminal BF completion is a constrained Petersen-walk labelling

This note gives an exact criterion for the **other** connected-core branch left by [Notes 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md) and [165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md). Let \(H\) be any cubic five-pole with terminal semiedges \(s_1,\ldots,s_5\), and fix an actual perfect matching \(P_0\) using all five semiedges. In the marked-core model, such a matching is exactly a perfect matching of \(F=J-M\). Exact Case XII forbids an all-terminal **BF cover**, but does not forbid \(P_0\) itself.

Remove \(P_0\) from the proper-edge graph of \(H\). Every pole vertex has degree two in the remaining graph, so it is a disjoint union \(\mathcal C\) of proper cycles. Write \([5]=\{1,\ldots,5\}\), and regard the ten two-subsets of \([5]\) as the vertices of the Petersen graph \(KG(5,2)\), adjacent when disjoint.

## Exact criterion

The matching \(P_0\) belongs to an all-terminal six-matching BF cover **if and only if** the edges of \(\mathcal C\) admit labels
\[
\lambda:E(\mathcal C)\longrightarrow\binom{[5]}2
\]
with these three properties:

1. At every vertex \(v\), the labels of its two incident \(\mathcal C\)-edges are disjoint. Denote the unique omitted element of \([5]\) by \(\mu(v)\).
2. At the terminal vertex incident with \(s_i\), one has \(\mu(v)=i\).
3. For every proper edge \(uv\in P_0\), one has \(\mu(u)=\mu(v)\).

The first property says that the successive edge labels around each cycle of \(\mathcal C\) form a closed walk in the Petersen graph. The second prescribes the omitted singleton labels at the five marked subdivision vertices. The third couples those walks across the edges of \(P_0\). In particular, checking each cycle separately without the third property is insufficient.

**Proof.** An all-terminal BF cover containing \(P_0\) has five other matching occurrences. Each must use an odd, hence positive, number of semiedges. The semiedge load remaining after \(P_0\) is exactly five, so those occurrences have singleton boundaries \(1,\ldots,5\), once each; name them \(P_1,\ldots,P_5\). Label every edge \(e\) of \(\mathcal C\) by the two indices \(i\) for which \(e\in P_i\). These are two-subsets because \(P_0\) avoids \(\mathcal C\) and the BF load is two. At a vertex the two labels are disjoint, and the fifth \(P_i\) uses the incident \(P_0\)-edge; its index is \(\mu(v)\). On \(s_i\), that fifth matching is \(P_i\), giving property 2. On a proper \(P_0\)-edge its index must agree at both endpoints, giving property 3.

Conversely, from such a labelling define \(P_i\) to use every \(\mathcal C\)-edge whose label contains \(i\), and every \(P_0\)-edge whose endpoint omissions equal \(i\). Properties 1 and 3 make \(P_i\) a perfect matching at every pole vertex. Property 2 makes its sole terminal semiedge \(s_i\). Every \(\mathcal C\)-edge lies in exactly two of the \(P_i\), and every \(P_0\)-edge lies in \(P_0\) and exactly one \(P_i\). Hence \(P_0+P_1+\cdots+P_5=2\mathbf1\), an all-terminal BF cover. \(\square\)

For a genuine exact-Case-XII pole with \(F\) perfectly matchable, **every** \(P_0\in\operatorname{PM}(F)\) must fail this labelled-walk criterion. This is an exact full-PM-closure obstruction, not a claim that a perfect matching of \(F\) automatically extends. It replaces the five unknown singleton masks by Petersen walks on the cycles of one fixed \(P_0\), coupled by explicit equalities along \(P_0\).

## A real boundary: an all-terminal matching need not extend

The implication “\(F\) has a perfect matching, hence the pole has an all-terminal BF cover” already fails for a simple 3-edge-connected cubic core. Take
\[
V(J)=\{a,b,c,0,1,2,3,4\},
\]
with edges the triangle \(ab,bc,ca\), the pentagon \(01,12,23,34,40\), and the four edges \(a0,b2,c4,13\). Mark all five pentagon edges and subdivide them into terminal vertices to form \(H\). The core is cubic and simple. Contracting \(abc\) gives the triangular prism (triangles \(0,4,x\) and \(1,2,3\), joined by \(01,x2,43\)). A cut that does not split \(abc\) projects to a cut of the 3-edge-connected prism. A cut that splits \(abc\) crosses two triangle edges; it crosses at least one more edge, since the old vertices \(0,\ldots,4\) induce a connected graph and each triangle vertex has an attachment to them. Thus \(J\) is 3-edge-connected, and \(H\) is connected and proper-bridge-free.

After deleting the five marks, vertices \(0,2,4\) are leaves matched respectively to \(a,b,c\), while \(1,3\) must be matched to each other. Hence
\[
\operatorname{PM}(F)=\bigl\{\{a0,b2,c4,13\}\bigr\}.
\]
For its unique all-terminal matching \(P_0\), the proper complement \(\mathcal C\) consists of the **unmarked triangle** \(abc\) and the ten-edge subdivided pentagon. On the triangle, the three edge labels \(\lambda(ab),\lambda(bc),\lambda(ca)\) would have to be three pairwise disjoint two-subsets of \([5]\), which requires six labels. No Petersen-walk labelling exists, so \(H\) has **no all-terminal BF cover**, despite having an all-terminal perfect matching and a 3-edge-connected core. No enumeration of selected rows or guessed matchings is involved.

This pole has thirteen vertices, a proper triangle, and a five-edge marked cycle. [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) excludes its complete support from exact Case XII; the triangle and marked cycle also violate the minimum-host restrictions of Notes 123 and 158. The example closes only the unconditional matching-to-BF implication. For a minimum-host exact-Case-XII pole, each candidate \(P_0\) must fail the criterion by a less immediate obstruction.

The next decision is whether the minimum-host cut and marked-path constraints force a labelling for at least one \(P_0\), or whether a real graph satisfying those constraints has a verifiable labelling obstruction.
