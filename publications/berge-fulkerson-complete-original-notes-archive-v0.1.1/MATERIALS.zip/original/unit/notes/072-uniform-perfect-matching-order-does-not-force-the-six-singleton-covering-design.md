> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Uniform perfect-matching order does not force the six-singleton covering design

The abstract-incidence strengthening suggested by
[Notes 070](070-four-pivot-rows-and-cubicity-do-not-force-a-residual-selector.md)
and
[071](071-girth-five-does-not-force-a-failed-pivot-residual-selector.md)
is false.  There is a finite common binary proper-coordinate system with

\[
 15\ S\text{--}S+25\ S\text{--}T
\]

as its exact BF pair-type support, with no \(A\), \(T\)-loop, or
\(T\)--\(T\) equation, and containing a failed four-row \(D_5\) pivot
star whose \(69\) forbidden residual selectors are all blocked.  Moreover,
there is one odd integer \(n\) such that every matching vector \(M\) in the
system satisfies the perfect-matching order equation

\[
 2|M_{\mathrm{proper}}|+|\partial M|=n.             \tag{1}
\]

Thus exact BF-40 support, common binary edge incidence, and uniform
perfect-matching order do not force a residual selector or the required
six-singleton low-load configuration.  The construction below has no common
trivalent vertex incidence and is not a cubic 5-pole.  The real-pole problem
therefore remains open at precisely that stronger layer.

## The uniform failed-star factor

Use singleton tokens

\[
 U=\{a_1,a_2,a_4,a_5,x,y\},
 \qquad
 \partial a_i=\{i\},\quad \partial x=\partial y=\{3\},
\]

and eight triple tokens \(q_A,r_{45},q_B,r_{23},q_C,r_{15},q_D,r_{34}\)
with the boundary classes indicated by

\[
\begin{aligned}
A&=(q_A,r_{45};a_1,x,a_4,a_5),\\
B&=(q_B,r_{23};a_1,a_2,x,a_4),\\
C&=(q_C,r_{15};a_1,a_2,a_4,a_5),\\
D&=(q_D,r_{34};a_2,y,a_4,a_5).
\end{aligned}                                      \tag{2}
\]

The four rows occupy the \(D_5\) cells

\[
 (13,45),\quad(14,23),\quad(24,15),\quad(25,34).
\]

Their eleven proper coordinates are

\[
\begin{array}{c|l}
1&a_2,a_5,r_{23},r_{45}\\
2&a_4,r_{15},r_{23},r_{45},y\\
3&a_1,r_{15},r_{34},x,y\\
4&a_5,r_{15},r_{23},r_{34},x\\
5&a_5,x,q_B,q_C,r_{34}\\
6&a_5,x,q_B,q_C,q_D\\
7&a_4,r_{45},q_B,q_C,q_D\\
8&a_2,a_4,q_A\\
9&a_1,a_4,q_D\\
10&a_1,a_2,y,q_A\\
11&a_1,a_2,y,q_A.
\end{array}                                         \tag{3}
\]

Every row in (2) has load two on every coordinate.  Each singleton token has
weight four and each triple token weight three, so (1) holds with \(n=9\).
The first four coordinates form a sharp blocker: each of the \(69\)
forbidden-boundary five-occurrence selectors has load zero or at least three
on one of them.  Taking \(C\) as anchor, the three compatible extension
values are \(x,x,y\); every arm extends separately, but no one matching
extends all three arms.

## Exact-40 product extension

Add one coordinate containing all eight triple tokens.  Every token in the
resulting twelve-coordinate star factor then has weight four, while its BF
pair support remains exactly the four cells in (2).

For each of the other \(36\) positive Case-XII cells, introduce six private
tokens forming one designated BF row and give them the fifteen-coordinate
factor \(\binom{[6]}2\).  Take the Cartesian product of the star factor and
these \(36\) private factors.  Every token has density \(1/3\), and every
designated row has load two on every product coordinate.  Conversely, if a
six-token multiset has constant load two on one private
\(\binom{[6]}2\)-factor, varying the selected pair shows that all six token
multiplicities are equal.  Such a multiset is therefore that complete private
row or lies entirely in the star factor.  Hence the product has exactly the
forty designated pair types and no forbidden pair type.

Finally add two coordinates.  On every private row they partition its four
singleton tokens into two pairs and contain neither triple token.  On the
star factor use

\[
 \{a_1,a_4,y\},\qquad \{a_2,a_5,x\}.               \tag{4}
\]

Both coordinates still meet every designated row twice.  Put

\[
 m_0=12\cdot15^{36}=3b,\qquad m=m_0+2,
 \qquad n=2b+3.
\]

Every singleton token now has proper weight \(b+1\), every triple token has
proper weight \(b\), and

\[
 2m+5=3n,
 \qquad 2(b+1)+1=n,
 \qquad 2b+3=n.
\]

Thus all matching vectors satisfy (1).  Adding coordinates cannot destroy
the four original blocker coordinates, so the failed star and all \(69\)
blocked selectors survive.

## The exact missing-pair gate

For six actual singleton perfect matchings \(U\), form a graph \(G_U\) on
these six identities.  Whenever an actual BF row uses four members
\(R\subset U\) as its singleton part, add the missing pair \(U\setminus R\)
as an edge.  Then

\[
 \alpha(G_U)\le2                                      \tag{5}
\]

is exactly the assertion that every three-subset of \(U\) is contained in
the singleton part of some actual BF row: a triple \(X\) is covered precisely
when \(U\setminus X\) contains an edge of \(G_U\).

Condition (5) is sufficient to exclude a real cubic 5-pole.  If a proper
edge belonged to three members of \(U\), a row covering that triple would
have singleton load at least three there, contradicting its double-cover
equation.  Hence every proper edge would have \(U\)-load at most two.  But a
cubic 5-pole of order \(n=2k+3\) has \(3k+2\) proper edges, and every
singleton perfect matching has \(k+1\) proper edges.  Therefore

\[
 \sum_{M\in U}|M_{\mathrm{proper}}|
 =6k+6>2(3k+2)=6k+4,                                \tag{6}
\]

a contradiction.

For the four rows (2), the missing-pair graph initially has edges

\[
 a_2y,\quad a_5y,\quad xy,\quad a_1x.               \tag{7}
\]

At least three further edges are necessary for (5), and the unique
three-edge completion is

\[
 a_1a_4,\quad a_2a_5,\quad a_4x.                    \tag{8}
\]

Equivalently, three further actual BF rows must reuse these same six
singleton identities with singleton quadruples complementary to (8).
[Notes 055](055-half-load-column-saturation-and-case-xii-compression.md)
and
[057](057-overlap-cells-transport-singleton-fibres-into-d5.md)
supply the necessary boundary cells and transport relations, but they do not
identify their singleton witnesses with the six identities in (8).

Consequently, uniform matching order is not the missing ingredient.  The
remaining real-pole question is whether common trivalent vertex incidence
and the resulting complete perfect-matching closure force some six-identity
missing-pair graph to satisfy (5).  No conclusion here applies directly to a
real Case-XII pole without that additional argument.
