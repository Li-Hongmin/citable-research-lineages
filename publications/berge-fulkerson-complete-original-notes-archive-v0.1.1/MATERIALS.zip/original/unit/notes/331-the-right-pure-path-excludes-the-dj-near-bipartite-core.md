> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right pure path excludes the DJ near-bipartite core

Assume the complete exact-Case-XII central-path profile and a genuine right \((ea)(ad)\) row as in [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md). Work conditionally in the \(3{:}2\) near-bipartite unmarked-core placement \(R_0=DJ\) of [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md): deleting \(g\subset B\) makes the core bipartite with sides \(B,R\), the marked edge has ends \(v\in B,w\in R\), the proper ports \(A,I,H\) are \(B\)-based, and \(D,J\) are \(R\)-based. Give the subdivision vertex \(t_e\) colour \(R\). The allowed pentagon is \(S=e-a-b-d-c-e\), so \(be,bc\in T\).

**Theorem.** No complete exact-Case-XII five-pole has this right-row \(R_0=DJ\) placement. The conclusion holds even when the marked \(B\)-end is incident with \(g\); no Hall witness or noncollision assumption is used.

**Proof.** In the right row, let \(X\) be its zero-port shore matching and \(Z\) its singleton-\(e\) shore matching. The actual load profile of Note 297 gives
\[
  g,t_ew\in X,\qquad g\notin Z,\qquad E\in Z,
  \qquad \operatorname{ports}(Z)=EAHJ.                 \tag{1}
\]
The pure \(ea\)-half route in that note pairs the two shore paths of \(X\triangle Z\) as \(EH\mid AJ\). Let \(P_{EH}\) be the \(E\)--\(H\) path. Its two port semiedges both belong to \(Z\), so its internal proper-edge segment has odd length. It runs from \(t_e\in R\) to the base of \(H\) in \(B\). Among shore proper edges only \(g\) and \(t_ew\) fail to cross the displayed bipartition. Since the path starts from \(t_e\) through \(t_ew\in X\), an odd-length \(R\)--\(B\) internal segment must contain the second same-side edge \(g\) as well. This argument does not depend on whether those two edges meet at \(v\).

Switch the complete alternating path \(P_{EH}\) into \(Z\). The resulting **actual** shore matching \(N\) loses ports \(E,H\), retains \(A,J\), and gains \(g,t_ew\):
\[
             \operatorname{ports}(N)=AJ,\qquad g,t_ew\in N.      \tag{2}
\]
We exclude (2) directly by full perfect-matching closure. Glue \(N\) to the exterior mask
\[
 M_b=\{b_{\rm term},a:\Sigma,c:A_{\rm ext},d:E_{\rm ext},
             1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4\}.       \tag{3}
\]
The selected shore interfaces in (3) are exactly \(A,J\). It covers the four exterior mark vertices by \(a:\Sigma,b_{\rm term},c:A_{\rm ext},d:E_{\rm ext}\), the five exterior branch vertices by \(c:A_{\rm ext},1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},d:E_{\rm ext}\), and \(u_1,u_2,u_3,u_4\) by \(1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4\), respectively. Thus the gluing is a complete actual singleton-\(b\) perfect matching.

Colour the exterior interface endpoints as in [Note 283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md), so that all five terminal vertices lie in \(R\). The only same-side proper edges of the full pole are \(g,t_ew\), and the \(D,J\) interfaces. The completed matching selects \(g,t_ew,J\), leaving only the \(D\) interface exceptional in its complement. Under (3), that interface lies on the open path from unused terminal \(d\), through \(t_d,B_{\rm ext},u_2\), to the shore. Therefore every closed complement cycle is even, and alternating its edges with two colours extends the singleton-\(b\) matching to a Tait colouring. The other complement path joins two terminals among \(e,a,c\). It avoids the same-side exception and has both ends in \(R\), so its terminal semiedges receive different colours. Switching its two colours gives Tait states joining \(b\) to **each** endpoint. At least one is \(be\) or \(bc\), forbidden by exact Case XII. This contradiction proves the theorem. \(\square\)

[Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md) already excludes \(R_0=IJ\) under the same two genuine rows and exact support. Consequently, **conditional on the stated \(3{:}2\) near-bipartite core profile**, neither surviving \(R\)-port placement of [Note 299](299-two-singleton-c-masks-exclude-the-right-ad-h-side-and-one-b-port-profiles.md) remains. This closes that profile without using the invalid extension of Note 281 identified in [Note 330](330-marked-end-collision-gives-a-conditional-shore-transversal.md). It does not settle the \(4+1\) profile, other core structures, the complete Case-XII problem, or Berge–Fulkerson. The path and mask proof is symbolic and awaits independent verification; no local computation or OMEN run was used.
