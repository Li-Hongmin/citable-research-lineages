> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# D5 completions transfer to the disjoint (S)--(S) fibres

This note gives an exact matching-level reduction for the Case-XII
interface.  It does not prove the remaining natural-join statement and does
not construct a Case-XII pole.

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Assume that a cubic 5-pole has no BF cover of type

\[
 A=(12345),
\]

and no (T)--(T) cover.  For a triple-boundary matching class indexed by
an element of (S\cup T), write (Q_s) for an actual perfect matching in
that class, and write (P_i) for an actual singleton-boundary matching at
terminal (i).

The five disjoint (S\)--(T) pairs are

\[
 \mathcal D_5=
 \{(13,45),(14,23),(24,15),(25,34),(35,12)\}.
\]

For (d=(s,t)\in\mathcal D_5), let (widehat\Pi_d) be the relation of
four-tuples ((P_i)_{i\in s\cup t}) for which some (Q_s,Q_t) satisfy

\[
 \chi_{Q_s}+\chi_{Q_t}+
 \sum_{i\in s\cup t}\chi_{P_i}=2\mathbf 1.
 \tag{1}
\]

Likewise, for disjoint (u,v\in S), let (widehat\Sigma_{u,v}) be the
corresponding relation using (Q_u,Q_v).  The two relations have the same
four singleton coordinates when (s\cup t=u\cup v).

## Transfer theorem

There is a canonical correspondence

\[
\begin{array}{c|c}
 d\in\mathcal D_5 & \phi(d)\text{ (disjoint (S\)--(S) pair)}\\
\hline
 (13,45)&(14,35)\\
 (14,23)&(13,24)\\
 (24,15)&(14,25)\\
 (25,34)&(24,35)\\
 (35,12)&(13,25)
\end{array}
\tag{2}
\]

such that

\[
 \boxed{\widehat\Pi_d=\widehat\Sigma_{\phi(d)}}.
 \tag{3}
\]

Consequently, the Case-XII question of whether one four-of-five (D_5)
join exists is exactly the question whether one four-of-five join of the
five disjoint (S\)--(S) relations exists.

### Proof

The symmetric difference (Q_s\triangle Q_t) consists of two terminal
paths with endpoints (s\cup t), together with possible proper even cycles.
The three pairings of the four terminal endpoints produce, after toggling one
path in both (Q_s) and (Q_t), the following boundary classes:

\[
\begin{array}{c|ccc}
\text{original classes}&\text{pairing 1}&\text{pairing 2}&\text{pairing 3}\\
\hline
 S\text{--}T\text{ disjoint}&(A,A)&(S\text{--}S,S\text{--}S)&(T\text{--}T,T\text{--}T)\\
 S\text{--}S\text{ disjoint}&(A,A)&(S\text{--}T,S\text{--}T)&(T\text{--}T,T\text{--}T).
\end{array}
\tag{4}
\]

The first and third alternatives in the first row are forbidden by the
hypothesis.  Hence every (S\)--(T) witness uses the unique middle
pairing, and toggling either terminal path gives a witness in the associated
disjoint (S\)--(S) class with exactly the same four singleton matchings.
Conversely, the second row has only its middle (S\)--(T) alternative
available, so the toggle is reversible.  Computing the five endpoint
pairings gives exactly table (2), proving (3).

## What the transfer does and does not give

Let (Pi_d) and (Sigma_{u,v}) be the five-coordinate cylinders obtained
by leaving the unique missing terminal coordinate arbitrary.  The transfer
gives

\[
 \exists d_0\in\mathcal D_5:
 \bigcap_{d\ne d_0}\Pi_d\ne\varnothing
 \quad\Longleftrightarrow\quad
 \exists e_0\in E(C_5):
 \bigcap_{e\ne e_0}\Sigma_e\ne\varnothing.
 \tag{5}
\]

If either side of (5) holds, the four-cell load argument applies.  Every
proper edge is then contained in at most two of the common singleton
matchings, and the five local loads at a cubic vertex are ((2,2,1)).
The load-one edges form a sixth perfect matching, and the five semiedges have
load one, yielding the forbidden (A)-cover.

The hypotheses of Case XII provide only nonemptiness of each individual
relation.  They do not imply the four-way natural join in (5): different
cells may use different singleton matchings from the same terminal class.
Thus (5) is a genuine cross-cell witness-reuse/Helly problem, not a missing
endpoint calculation.  Pure support, aggregate integer loads, route labels,
and formal exchange closure do not supply this quantifier exchange.

## Scope and verification

The transfer uses one common cubic pole and actual perfect matchings; it is
stronger than a boundary-type or load-only model.  It is nevertheless only a
reduction.  It neither excludes Case XII nor proves the Berge--Fulkerson
conjecture.  A proof of the remaining join needs an additional theorem about
the common three-valent incidence of the matching family, while a counterexample
must realize the complete forty-type support and make all five joins empty.

The finite endpoint verification is reproduced by

    python3 units/berge-fulkerson/scratch/worker-bf-d5-join-proof/verify_d5_ss_transfer.py

which ends with `D5_SS_TRANSFER_TABLE_VERIFIED`.
