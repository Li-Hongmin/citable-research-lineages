> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The cross-half 5-to-2 path also gives a common BC seed

The \(5\leftrightarrow1\) terminal path in [Note 131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md) gives a literal common-\(B_2,C_4\) seed. The other path ending at \(2\) also gives the seed: exchange the two actual class-two singleton occurrences between the half-loads before a forced Kempe path switch. Thus, in a genuine exact-Case-XII five-pole with no common seed, **every** cross-half triple phase of **every** right \((25)(34)\) row must have the single remaining terminal pairing \(5\leftrightarrow4\). This is a full-mask statement at every order, with no bipartization or Tait assumption.

## Theorem

Let \(H\) be a cubic five-pole with no all-terminal BF type and no \(T\)--\(T\) BF type, including \(T\)-loops, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Suppose actual complete perfect matchings give a right row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.              \tag{1}
\]
The forced cross-half triple switch of Note 131, followed by any subset of closed alternating-component switches, gives
\[
q_{25}+r_{34}=p_{35}+t_{24},
\qquad
p_{35}+B_2+D_5+t_{24}+Y_3+C_4=2\mathbf1.             \tag{2}
\]
If the terminal path of \(p_{35}+D_5\) beginning at \(5\) ends at \(1\) **or \(2\)**, then actual complete matchings give a left row
\[
q_{14}+A_1+C_4+r_{23}+B_2+Y_3=2\mathbf1,             \tag{3}
\]
with the **same complete \(B_2,C_4,Y_3\) masks** as (1). In particular,
\[
\Lambda_L(H)\cap\Lambda_R(H)\ne\varnothing.           \tag{4}
\]

**Proof.** The endpoint-\(1\) case is the two-switch construction in Note 131. Suppose the path ends at \(2\). Switching its two colours changes the pair \(p_{35}+D_5\) into an actual triple and an actual class-two singleton:
\[
p_{35}+D_5=\rho_{23}+\widehat B_2.                    \tag{5}
\]
Substitute (5) into (2) and group the six *occurrences* as
\[
(t_{24}+B_2+C_4)+(\rho_{23}+\widehat B_2+Y_3)
       =2\mathbf1.                                   \tag{6}
\]
The two complete class-two matchings \(B_2,\widehat B_2\) can be exchanged between these halves without changing the six-matching load or either boundary state. This gives
\[
(t_{24}+\widehat B_2+C_4)+(\rho_{23}+B_2+Y_3)
       =2\mathbf1.                                   \tag{7}
\]
The first half has state \(24\in S\); the fixed second half has state \(23\in T\). In the first half, switch the bichromatic terminal path between \(t_{24}\) and \(\widehat B_2\), retaining the complete \(C_4\) mask. The triple-colour endpoint is one of \(1,3,5\). Endpoints \(3,5\) would change the first state to \(34,45\in T\) against the unchanged \(T\)-state \(23\), contradicting the negative support. Therefore it ends at \(1\), and
\[
t_{24}+\widehat B_2=q_{14}+A_1.
\]
Substitution in (7) is exactly the left row (3), including the literal original \(B_2,C_4,Y_3\) masks. \(\square\)

The theorem does not require the new \(\widehat B_2\) to equal the original \(B_2\); the occurrence exchange is precisely what removes that apparent identity obstruction. The \(5\leftrightarrow4\) path instead yields a class-four singleton and another \(T\)-state \(34\) half-load. A class-four exchange returns to a right row while retaining \(B_2,C_4,Y_3\), as recorded in [Note 135](135-a-hot-class-four-right-row-forces-the-bad-cross-half-terminal-pairing.md); the argument above does not turn that outcome into a left row.

Consequently, if \(\Lambda_L(H)\cap\Lambda_R(H)=\varnothing\), then for **every** right row (1) and **every** resulting pair \(p_{35},t_{24}\) in (2), the \(p_{35}+D_5\) terminal path has endpoint \(4\). This is the exact surviving cross-half terminal-pairing obstruction. It does not prove that such a complete-PM family exists or that the obstruction is impossible.
