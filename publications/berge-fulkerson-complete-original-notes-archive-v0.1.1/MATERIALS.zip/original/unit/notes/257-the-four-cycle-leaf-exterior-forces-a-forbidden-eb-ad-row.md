> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The four-cycle-with-leaf exterior forces a forbidden \((eb)(ad)\) row

Work in the minimum-host, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md), with complete exact-Case-XII perfect-matching support. This note treats its third \(r=3,|U|=4\) shape: a four-cycle on \(U\), with its edges subdivided by four singleton vertices and one extra singleton leaf. The odd shore \(\Sigma\) has arbitrary order and cycle rank.

Write the exterior vertices as \(U=\{u_1,u_2,u_3,u_4\}\) and \(W=\{A,B,C,D,P\}\), with
\[
K=\{1A,2A,2B,3B,3C,4C,4D,1D,1P\},\qquad
h_i=u_i\Sigma\quad(i=2,3,4).                              \tag{1}
\]
Here \(iw=u_iw\); \(e\) is the internal shore mark. The two marks joining \(W\) to \(\Sigma\) are named \(a,d\), so \(ea,ed\) are the two allowed edges at \(e\). The remaining marks are \(b,c\).

**Theorem.** No such marked exterior has complete exact-Case-XII BF support. Up to reflection of (1), there are two placements satisfying degree, girth-five, and the distinct-endpoint condition of [Note 246](246-the-two-shore-marks-need-distinct-singleton-endpoints.md). The first has no pure \(S\) half-load. In the second, every required real \((ea)(ad)\) row can be converted, using complete matching closure, into a forbidden real \((eb)(ad)\) row. Thus three of Note 245's six unmarked \(|U|=4\) exteriors are now excluded at every shore order: the two six-cycle-with-leaf shapes in [Notes 248](248-the-second-leaf-six-cycle-forces-an-overloaded-ec-row.md) and [256](256-the-first-leaf-b-exterior-forces-a-forbidden-eb-ad-row.md), and this four-cycle-with-leaf shape.

## The two marked placements

The marked capacities of \(A,B,C,D,P\) are \(1,1,1,1,2\). A \(W\)--\(W\) mark cannot join two vertices sharing a neighbour in \(U\), because its subdivision would create a four-cycle. Among \(A,B,C,D\), only \(AC\) and \(BD\) are allowed; \(P\) can meet only \(B,C\). By Note 246, at most one shore mark meets \(P\). If none does, both cross marks are \(PB,PC\), leaving the shore marks at \(A,D\). If one does, reflect so that the remaining cross mark at \(P\) is \(PB\); the other cross mark is \(AC\), and the other shore mark is at \(D\). Thus the two placements are
\[
\begin{array}{c|cc|cc}
 &a&d&b&c\\ \hline
\mathrm I&A\!:\!\Sigma&D\!:\!\Sigma&PB&PC\\
\mathrm{II}&P\!:\!\Sigma&D\!:\!\Sigma&PB&AC.
\end{array}                                                   \tag{2}
\]
Interchanging the two shore-mark names reverses the allowed pentagon at \(e\); the displayed orientation loses no case.

For I, take the pure \(ea\) half of the required \((ea)(ad)\) row. Its zero-port triple is forced by [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) to have exterior
\[
X_a=\{a:A,1P,2B,3C,4D\}.                              \tag{3}
\]
By [Note 244's exterior-path argument](244-every-shore-mark-must-neighbour-the-internal-mark.md), the \(a\)-terminal path of \(X_a\triangle Y_a\) must end at \(d\) without entering \(\Sigma\). The route through \(A-u_1-P\) ends at \(b\) or \(c\); hence the path to \(d\) must use \(A-u_2-B-u_3-C-u_4-D\). In \(Y_a\), this occupies \(B\) and \(C\), so the nonterminal marks \(b=PB\) and \(c=PC\) would both have to use \(P\). No matching can do that. Placement I is impossible.

## Placement II: a unit exterior half is forced

For II write a required real row as
\[
\mathcal D=X_a+Y_a+Z_e,\qquad
\mathcal E=U_{ad}+V_a+W_d,\qquad
\mathcal D+\mathcal E=2\mathbf1.                         \tag{4}
\]
The [published Case-XII table](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains \((ea)(ad)\); \(ad\in T\), so both before and after exchanging the complete singleton-\(a\) matchings \(Y_a,V_a\), the \(ea\) half must be pure \(S\).

The zero-port triple \(X_a\) uses \(a:P\). The two perfect matchings of \(K-P\) are
\[
M_0=\{1A,2B,3C,4D\},\qquad M_1=\{1D,2A,3B,4C\}.      \tag{5}
\]
If \(X_a\) uses \(M_0\), its exterior \(a\)--\(d\) alternating path is forced through \(P-u_1-A-u_2-B-u_3-C-u_4-D\). The singleton-\(a\) matching would then occupy \(P,A,B,C\) on that path, leaving no endpoint for both nonterminal cross marks \(PB,AC\). Thus \(X_a=\{a:P\}\cup M_1\), and switching the short \(P-u_1-D\) path gives the state-\(ed\) triple
\[
X_d=\{d:D,1P,2A,3B,4C\}.                              \tag{6}
\]
The same short path forces each pure-half singleton-\(a\) exterior to be one of
\[
\begin{aligned}
Y_A&=\{b:B,c:A,d:D,1P,3C,h_2,h_4\},\\
Y_C&=\{b:B,c:C,d:D,1P,2A,h_3,h_4\}.
\end{aligned}                                                   \tag{7}
\]
This applies to both \(Y_a\) and \(V_a\), by exchanging the **complete** singleton-\(a\) matchings in (4) and using purity again.

The two occurrences in (7) already load \(b:B,d:D,1P,h_4\) twice. The triple \(U_{ad}\), whose boundary contains \(e\), must use exactly one proper shore port by Note 230. It cannot use \(d:D\), so it uses \(d:\Sigma\); its other nonterminal mark is therefore \(a:P\). Its \(K\)-mask is \(M_0\) or \(M_1\). Since \(X_a,U_{ad}\) already use \(a:P\) twice, \(Z_e,W_d\) use \(a:\Sigma\). Also \(Z_e\) uses \(b:P,d:\Sigma\), while \(W_d\) uses \(b:P\) and has terminal \(d\). Neither may use \(1P\) or \(h_4\).

If \(U_{ad}\) uses \(M_1\), then \(2A\) is already loaded twice by \(X_a,U_{ad}\). Neither singleton-\(a\) occurrence can be \(Y_C\). Both are \(Y_A\); their shore ports load \(h_2,h_4\) twice, forcing \(Z_e\) to use \(h_3\). Its exterior is then uniquely
\[
Z_C=\{a:\Sigma,d:\Sigma,b:P,c:C,1A,2B,4D,h_3\}.     \tag{8}
\]

If \(U_{ad}\) uses \(M_0\), the two singleton-\(a\) occurrences cannot both be \(Y_A\), because \(3C\) would have load three, or both \(Y_C\), because \(2A\) would have load three. They are one of each. Their mark and port loads force \(Z_e,W_d\) to split the remaining two exterior patterns: \(c:A,h_2,1D,3B,4C\) and \(c:C,h_3,1A,2B,4D\), with \(a:\Sigma,b:P\) in both and \(d:\Sigma\) in \(Z_e\). The first pattern cannot belong to \(Z_e\): its shore \(e\)-path cannot pair with \(a:\Sigma\) or \(d:\Sigma\), since against (6) or \(X_a\), respectively, that would switch to \(ad\in T\). It must pair with \(h_2\), whose exterior route ends at \(c\) against **both** \(X_a\) and \(X_d\), whereas purity requires opposite \(b,c\) endpoints. Hence \(Z_e=Z_C\) again. Exchange \(Y_a,V_a\) if necessary to put \(Y_A\) in \(\mathcal D\). The exchange keeps the six complete matchings and their total load unchanged.

In either case the pure half may therefore be written with the following unit-load exterior:
\[
X_a=\{a:P,1D,2A,3B,4C\},\quad
Y_A=\{b:B,c:A,d:D,1P,3C,h_2,h_4\},\quad Z_C\text{ as in (8)}. \tag{9}
\]
These masks partition the nine \(K\)-edges, both halves of each exterior mark, and \(h_2,h_3,h_4\) exactly once.

## A second exterior colouring of the same half-load

The following three exterior matchings have the same shore-port sets **slot by slot** as (9), and also partition every exterior proper edge exactly once:

| Shore ports | Exterior mask | Full-pole boundary |
|---|---|---|
| \(\varnothing\) | \(U_{eb}=\{b:B,1P,2A,3C,4D\}\) | \(a,c,d\) |
| \(\{h_2,h_4\}\) | \(V_b=\{a:P,c:C,d:D,1A,3B,h_2,h_4\}\) | \(b\) |
| \(\{e,a:\Sigma,d:\Sigma,h_3\}\) | \(W_e=\{a:\Sigma,d:\Sigma,b:P,c:A,1D,2B,4C,h_3\}\) | \(e\) |

Each mask covers every exterior vertex not covered by its boundary terminal. Reuse, respectively, the three **actual complete shore restrictions** of \(X_a,Y_A,Z_C\) in (9), and glue them to \(U_{eb},V_b,W_e\). The result is three actual full-pole perfect matchings with state \(eb\). Their aggregate load equals that of (9) on the shore because its matching restrictions are unchanged, and on every exterior proper edge because both exterior triples have unit load. Keeping \(\mathcal E\) from (4) therefore gives a real \((eb)(ad)\) BF row. Since \(e\)'s allowed neighbours are exactly \(a,d\), both \(eb\) and \(ad\) lie in \(T\). Exact Case XII forbids this \(T\)--\(T\) row, proving the theorem. \(\square\)

The proof uses no bound on the shore's order or unmarked cycle rank. The paw exterior, both \(r=4\) trees, larger barriers, the other Tutte profiles, and Berge--Fulkerson itself remain open. This is an analytic proof and has not received an independent check.
