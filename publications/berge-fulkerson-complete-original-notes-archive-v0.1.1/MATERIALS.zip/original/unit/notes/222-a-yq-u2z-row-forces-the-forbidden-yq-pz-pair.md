> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A \((yq)(u_2z)\) shore row forces the outer \((yq)(pz)\) pair

Continue the genuine \(I_m\) tree--\(R^*\) connector of
[Note 221](221-a-shared-z-star-forces-an-outer-xz-loop-in-im.md).
The tree shore is centred at \(u_1\), with end groups
\(\{u_2,x\}\mid\{z,p\}\). Whenever the cyclic shore has
the actual BF type \((yq)(u_2z)\), the outer five-pole has
the actual type
\[
                              \boxed{(yq)(pz).}             \tag{1}
\]
In the Figure-7 \(R^*\) relation the hypothesis is
\(c(yq)\ne c(u_2z)\).

Use the tree's actual type \((u_2z)(xp)\). The six shore
boundary matchings may be independently relabelled as follows:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(u_2\) |
| 2 | \(u_1u_2z\) (missing \(xp\)) | \(q\) |
| 3 | \(x\) | \(u_1u_2z\) (missing \(yq\)) |
| 4 | \(z\) | \(u_1yq\) (missing \(u_2z\)) |
| 5 | \(u_2\) | \(y\) |
| 6 | \(p\) | \(z\) |

The shore-half labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&25&24&13/16&-\\
B&34&13&36&-&45/24
\end{array}.
\]
They are disjoint at \(u_1,u_2,z\). Set
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)
                    =(56,46;24,13,23,15).                  \tag{2}
\]
The labels partition \([6]\) at \(u_1,u_2,w_1,w_2\)
and the five marked subdivision vertices. The resulting outer
terminal labels are
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(15,56,26,45,36).                \tag{3}
\]
Slot \(5\) has \(\{z,x,p\}\), missing \(yq\), and
slot \(6\) has \(\{x,y,q\}\), missing \(pz\); the four
remaining slots are singleton boundaries. The actual input
shore rows cover every internal edge twice, so (2) proves
the genuine outer BF pair (1).

This excludes two unordered private-port classes from
[Note 221, (5)](221-a-shared-z-star-forces-an-outer-xz-loop-in-im.md):
\[
\begin{array}{c|c}
\{y,q\}&(z,u_2,u_1)\\\hline
\{1,2\}&(5,3,4)\\
\{2,5\}&(1,3,4)
\end{array}.                                                  \tag{4}
\]
In both rows of (4), \(yq\in Q\) and \(u_2z\in P\),
so (1) is actual. For \(\{y,q\}=\{1,2\}\), the port
receiving label \(1\) has \(c(bu_2)=P\ne Q=c(bz)=c(yq)\).
For \(\{y,q\}=\{2,5\}\), the port receiving label \(5\)
has the same property. Call this private port \(b\). The
appropriate actual transport of [Note 218](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md)
forces \([bz]\), and the \(p\)-star transport of
[Note 212, (3)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
forces \([bp]\). Thus any allowed Case-XII loop five-cycle
has the two edges \(bz,bp\). Its complement contains
\(yq\), because \(b\) already has its two neighbours,
and contains \(pz\), because a five-cycle has no triangle
\(b-p-z-b\). The actual type (1) is therefore a forbidden
\(T\)--\(T\) pair. This holds for either orientation of
\(y,q\), eliminating four labelled placements.

The other eight orders in Note 221, (5) remain necessary
candidates, not realizations. The mirror tree centre, other
shore pairs, and the full exact-Case-XII closure remain open.
The analytic proof awaits an independent check.
