> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The second-leaf six-cycle has one marking and one triple switch

Work in the minimum-host, complete exact-Case-XII, one-internal-mark profile with \(|U|=4,r=3\). Take the last unmarked exterior shape of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md):
\[
\begin{array}{c|l}
u_1&w_0,w_1\\
u_2&w_0,w_2\\
u_3&w_0,p\\
u_4&w_1,w_2,q.
\end{array}                                                   \tag{1}
\]
The three additional shore edges are \(h_i=u_iC\), \(i=1,2,3\). The singleton \(w_0\) has no marked incidence, \(w_1,w_2\) each have one, and the leaves \(p,q\) each have two.

**Theorem.** Up to exchanging indices \(1,2\), the only marked placement compatible with cubic degree, girth five and [Note 246's](246-the-two-shore-marks-need-distinct-singleton-endpoints.md) distinct-endpoint condition is
\[
a:w_2-C,\qquad d:q-C,\qquad b:w_1-p,\qquad c:p-q,\qquad e\subset C. \tag{2}
\]
By [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md), \(ea,ed\in S\). In every actual pure-\(S\) half-load decomposed at \(ea\) as \(D=X_a+Y_a+Z_e\), the two zero-port triple restrictions are forced to be
\[
\begin{aligned}
X_a|_{\rm ext}&=\{a:w_2,u_1w_1,u_2w_0,u_3p,u_4q\},\\
X_d|_{\rm ext}&=\{d:q,u_1w_1,u_2w_0,u_3p,u_4w_2\},
\end{aligned}                                                   \tag{3}
\]
where \(X_d\) is obtained from \(X_a\) by switching the wholly exterior \(a\)--\(d\) path. The singleton-\(a\) matching has one of precisely three exterior restrictions:
\[
Y_a|_{\rm ext}=\{u_4w_2,d:q,b:w_1,c:p,u_iw_0\}
\cup\{h_j:j\in\{1,2,3\}\setminus\{i\}\},
\qquad i=1,2,3.                                           \tag{4}
\]
The two triples in (3) have identical **complete shore masks**. Equations (3)--(4) are necessary exterior restrictions; they do not prescribe the singleton-\(e\) matching or assert exact-Case-XII realization.

**Marked-placement proof.** A \(W\)--\(W\) mark cannot join two singleton vertices sharing a neighbour in \(U\), or its subdivision would create a proper four-cycle. In (1), the only allowable pairs among vertices with marked capacity are \(w_1p,w_2p,pq\). Exactly two of these three pairs must carry the two \(W\)--\(W\) marks. Choosing \(w_1p,w_2p\) leaves both \(W\)--\(C\) marks at \(q\), contrary to Note 246. The other two choices are exchanged by \((u_1,w_1)\leftrightarrow(u_2,w_2)\), giving (2).

**Half-load proof.** By Note 230, a state-\(ea\) triple uses no proper shore port. It selects \(a:w_2\); deleting \(w_2\) from (1) forces the unique \(U\)--\(W\) perfect matching in the first line of (3). In \(X_a\triangle Y_a\), the path from terminal \(a\) must end at \(d\), because \(ed\) is the other allowed pair incident with \(e\). It remains wholly exterior by the zero-port argument of Note 244. There are only two ways to reach \(q\) from \(w_2\) along this alternating path:
\[
a-w_2-u_4-q-d,
\qquad
a-w_2-u_2-w_0-u_1-w_1-u_4-q-d.                        \tag{5}
\]
The second path cannot occur in one perfect matching \(Y_a\). It occupies \(w_1\) through \(u_4\) and \(q\) through \(d\), so its nonterminal mark \(b=w_1p\) must select \(p\); then \(c=pq\) has neither endpoint available. The first path is therefore forced. Switching it gives the second line of (3) without changing any shore edge of \(X_a\).

In \(Y_a\), the forced edge \(d:q\) makes \(c:p\) necessary; then \(b:w_1\) is necessary. The vertices \(u_1,u_2,u_3\) remain to be matched to the single available \(w_0\) or their respective shore edges \(h_1,h_2,h_3\). Exactly one uses \(w_0\), yielding the three masks (4). \(\square\)

[Note 248](248-the-second-leaf-six-cycle-forces-an-overloaded-ec-row.md) subsequently fixes the cyclic order and singleton-\(e\) mask, then excludes this quotient by a complete matching exchange in the required \((ea)(ec)\) row. The other five unmarked shapes of Note 245, larger barriers, and the full Berge--Fulkerson conjecture remain open. This analytic deduction has not received an independent model or implementation check.
