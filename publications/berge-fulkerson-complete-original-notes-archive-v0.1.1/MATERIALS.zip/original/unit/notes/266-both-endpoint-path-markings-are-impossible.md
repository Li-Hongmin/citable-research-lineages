> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both endpoint path markings are impossible

Retain the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile and the \(|U|=r=4\) path tree of [Note 265](265-the-endpoint-path-marking-with-an-end-to-end-cross-mark-is-impossible.md):
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad h_i=u_i\Sigma.
\]
By Note 265, one marking with the shore mark at an endvertex is already excluded. This note treats the other, up to reflection:
\[
a:A\!:\!\Sigma,\qquad b:AD,\quad c:BE,\quad d:CE.   \tag{1}
\]

**Theorem.** No pole with (1) has complete exact-Case-XII perfect-matching support, at any shore order or unmarked cycle rank. Every possible second neighbour \(b,c,d\) of the internal mark \(e\) is excluded. Together with Note 265, both path-tree markings whose shore mark meets an endvertex are impossible.

Suppose \(ea,es\) are the two allowed pentagon edges at \(e\), where \(s\in\{b,c,d\}\). The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) supplies a real \((ea)(as)\) row, written
\[
X_a+Y_a+Z_e+U_{as}+V_a+W_s=2\mathbf1.              \tag{2}
\]
The \(ea\) half is pure \(S\) because \(as\in T\). Its zero-port triple has the unique exterior
\[
X_a=\{a:A,1B,2C,3D,4E\}.                           \tag{3}
\]
The \(a\)--\(s\) path in \(X_a\triangle Y_a\) stays exterior by [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). Exchanging the two **complete** singleton-\(a\) occurrences \(Y_a,V_a\) preserves a real row and the opposite \(T\)-state, so both must satisfy the pure-\(S\) path condition. The zero-port assertion uses [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md).

## The neighbour \(b=AD\)

The path from \(A\) to \(b:D\) would use \(1A,2B,3C,b:D\), after which \(c:BE\) and \(d:CE\) both need \(E\). Thus the only possible switch is at the common endpoint \(A\), producing \(X_b=\{b:A,1B,2C,3D,4E\}\) with the same complete shore mask as \(X_a\).

If \(Z_e\) selects \(b:A\), changing \(X_a\) to \(X_b\) alters only the \(a,b\) route at \(A\); the \(c,d\) terminal routes are unchanged. If \(Z_e\) selects \(b:D\), then \(c,d\) may choose \((B,C),(B,E),(E,C)\), and \(a\) may choose \(A\) or \(\Sigma\). These are all six masks; the following table gives their selected proper shore ports and exterior terminal endpoints against \((X_a,X_b)\):

| \(c,d\) halves | \(a\)-half | Other exterior edges of \(Z_e\) | Port: endpoint pair |
|---|---|---|---|
| \(B,C\) | \(A\) | \(4E,h_1,h_2,h_3\) | \(h_1:(c,c),h_2:(d,d),h_3:(b,a)\) |
| \(B,C\) | \(\Sigma\) | \(1A,4E,h_2,h_3\) | \(a:\Sigma:(c,a),h_2:(d,d),h_3:(b,c)\) |
| \(B,E\) | \(A\) | \(2C,h_1,h_3,h_4\) | \(h_1:(c,c),h_3:(b,a),h_4:(d,d)\) |
| \(B,E\) | \(\Sigma\) | \(1A,2C,h_3,h_4\) | \(a:\Sigma:(c,a),h_3:(b,c),h_4:(d,d)\) |
| \(E,C\) | \(A\) | \(1B,h_2,h_3,h_4\) | \(h_2:(d,d),h_3:(b,a),h_4:(c,c)\) |
| \(E,C\) | \(\Sigma\) | \(1A,2B,h_3,h_4\) | \(a:\Sigma:(d,a),h_3:(b,d),h_4:(c,c)\) |

Every row also contains \(b:D\), the displayed \(c,d,a\) halves, and the singleton terminal \(e\). As a representative nontrivial trace, in the last row \(h_3\) reaches \(b\) against \(X_a\), while against \(X_b\) it continues through \(A-u_1-B-u_2-C-t_d\) to \(d\). No port has endpoint pair \((c,d)\) or \((d,c)\). The fixed shore pairing of \(e\) therefore cannot make the opposite \(c,d\) endpoints required by purity. This excludes \(eb\in S\).

## The neighbour \(d=CE\)

The \(a\)--\(d\) path ending at \(E\) leaves \(b:AD\) without a free endpoint, so it ends at \(C\). The resulting singleton exterior is unique:
\[
Y_a|_{\rm ext}=V_a|_{\rm ext}
=\{d:C,b:D,c:E,1A,2B,h_3,h_4\}.                   \tag{4}
\]
Since (4) occurs twice in (2), its edges are unavailable to \(Z_e\). The latter must use \(\{a:\Sigma,b:A,c:B,d:E,3C,4D,h_1,h_2\}\), together with terminal \(e\). The three-slot pure-half exterior consequently has unit load on every proper exterior edge.

This unit load has a different, same-port decomposition:

| Shore ports | Original \(ea\) exterior | Replacement \(ec\) exterior |
|---|---|---|
| \(\varnothing\) | \(X_a:\{a:A,1B,2C,3D,4E\}\) | \(X'_c:\{c:E,1A,2B,3C,4D\}\) |
| \(\{h_3,h_4\}\) | \(Y_a:\{d:C,b:D,c:E,1A,2B,h_3,h_4\}\) | \(Y'_c:\{a:A,b:D,d:E,1B,2C,h_3,h_4\}\) |
| \(\{e,a:\Sigma,h_1,h_2\}\) | \(Z_e:\{a:\Sigma,b:A,c:B,d:E,3C,4D,h_1,h_2\}\) | \(Z'_e:\{a:\Sigma,b:A,c:B,d:C,3D,4E,h_1,h_2\}\) |

Each displayed mask is an exterior matching. Both columns use every \(K\)-edge, every mark half, and every \(h_i\) once. Reuse the three complete shore restrictions from the original half, slot by slot, with the replacement exteriors. This gives three actual full-pole perfect matchings with the same aggregate edge load as before. Retain the opposite \(ad\in T\) half. The result is a forbidden real \((ec)(ad)\) row, since \(ec\in T\) when \(ea,ed\in S\). This excludes \(ed\in S\).

## The neighbour \(c=BE\)

The \(a\)--\(c\) path cannot end at \(E\), since that would leave \(b:AD\) without an endpoint. It ends at \(B\), and the singleton-\(a\) matching has exactly two possible exteriors:
\[
\begin{aligned}
Y_1&=\{c:B,b:D,d:C,1A,4E,h_2,h_3\},\\
Y_2&=\{c:B,b:D,d:E,1A,3C,h_2,h_4\}.
\end{aligned}                                                \tag{5}
\]
Both \(Y_a,V_a\) are among (5). If both use \(Y_1\), then \(4E\) occurs in \(X_a,Y_a,V_a\) and has load three. Hence at least one of them uses \(Y_2\). Exchange the two **complete** singleton-\(a\) occurrences if necessary, placing \(Y_2\) in the pure \(ea\) half while retaining the same \(Z_e\) and the opposite \(ac\in T\) half.

If both occurrences use \(Y_2\), edge load two uniquely fixes \(Z_e=Z_1\) below. If they are \(Y_1,Y_2\), their common doubled edges \(c:B,b:D,1A,h_2\) force \(c:E,b:A,d:C,a:\Sigma,2B,h_1\) in \(Z_e\); the remaining vertex \(D\) has exactly two completions. Thus in all cases the singleton-\(e\) exterior is one of
\[
\begin{aligned}
Z_1&=\{a:\Sigma,b:A,c:E,d:C,2B,4D,h_1,h_3\},\\
Z_2&=\{a:\Sigma,b:A,c:E,d:C,2B,3D,h_1,h_4\}.    \tag{6}
\end{aligned}
\]
For either choice, the pure half \(X_a+Y_2+Z_e\) has a *same-port, same-total-load* state-\(ed\) or state-\(eb\) replacement:

| \(Z_e\) | Shore ports | Original \(ea\) exterior | Replacement exterior |
|---|---|---|---|
| \(Z_1\) | \(\varnothing\) | \(X_a:\{a:A,1B,2C,3D,4E\}\) | \(X'_b:\{b:D,1A,2B,3C,4E\}\) |
| \(Z_1\) | \(\{h_2,h_4\}\) | \(Y_2:\{c:B,b:D,d:E,1A,3C,h_2,h_4\}\) | \(Y'_b:\{a:A,c:E,d:C,1B,3D,h_2,h_4\}\) |
| \(Z_1\) | \(\{e,a:\Sigma,h_1,h_3\}\) | \(Z_1\) from (6) | \(Z'_e:\{a:\Sigma,b:A,c:B,d:E,2C,4D,h_1,h_3\}\) |
| \(Z_2\) | \(\varnothing\) | \(X_a:\{a:A,1B,2C,3D,4E\}\) | \(X'_d:\{d:C,1A,2B,3D,4E\}\) |
| \(Z_2\) | \(\{h_2,h_4\}\) | \(Y_2:\{c:B,b:D,d:E,1A,3C,h_2,h_4\}\) | \(Y'_d:\{a:A,b:D,c:E,1B,3C,h_2,h_4\}\) |
| \(Z_2\) | \(\{e,a:\Sigma,h_1,h_4\}\) | \(Z_2\) from (6) | \(Z'_e:\{a:\Sigma,b:A,c:B,d:E,2C,3D,h_1,h_4\}\) |

Each row is a genuine exterior matching with the displayed shore ports. In each three-row block, the original and replacement columns have equal total load on every proper exterior edge and terminal semiedge; this follows directly by counting the eight \(K\)-edges, four \(h_i\), and both halves of each mark. Reuse the three **complete shore restrictions** of \(X_a,Y_2,Z_e\) with the replacement exteriors. The resulting three full-pole perfect matchings have the same total load as the original pure half, so the opposite \(ac\in T\) half completes a real BF row. For \(Z_1\) this row has type \((eb)(ac)\), and for \(Z_2\) it has type \((ed)(ac)\). Both are forbidden \(T\)--\(T\) types because \(ea,ec\in S\). This excludes \(ec\in S\) and proves the theorem. \(\square\)

The two internal path-tree markings, larger barriers, other Tutte profiles, and Berge–Fulkerson remain open.
