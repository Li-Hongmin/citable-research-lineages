> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real crossed-port row has both forbidden Hamilton loops

The crossed port form left in [Note 451(7)](451-two-end-port-phases-force-forbidden-rows-in-the-hamilton-prism.md) is realizable by a genuine BF row on a simple cubic five-pole. Thus its exclusion from exact Case XII must use the **complete** boundary support or further minimum-host restrictions; shore feasibility alone cannot exclude it. The example below has both forbidden loops \([eX]\) and \([eW]\), so it is not an exact-Case-XII pole.

## A 21-vertex pole and six complete matchings

Take the six prism vertices \(1,\ldots,6\), subdivide the Hamilton tree edges \(i(i+1)\) at \(u_i\) for \(i=1,\ldots,5\), and subdivide the four omitted edges \((X,Y,Z,W)=(14,15,26,36)\) at \(t_X,t_Y,t_Z,t_W\), each carrying its named terminal semiedge. For the six-port shore take the cycle
\[
q_1-q_2-q_4-q_3-q_e-q_5-q_1.                         \tag{1}
\]
Join \(u_i\) to \(q_i\) for all \(i\), and attach terminal \(e\) to \(q_e\). These specify every edge of the five-pole. It has \(6+5+4+6=21\) vertices and is connected, simple and cubic when semiedges are counted. Every cycle internal to either the subdivided prism or the shore has length at least six; a mixed cycle uses two proper ports, at least two exterior edges, and at least one shore edge, so its length is at least five. The cycle \(q_1-u_1-2-u_2-q_2-q_1\) shows that its girth is five.

Name six complete matching occurrences \(P,R,K,J,E,F\). At a tree subdivision, list the pair on its first-end half, second-end half, and proper port; at a marked subdivision, list its terminal pair and the two marked halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). The exterior edge-label pairs are
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RF,PK,JE)&(RF,PJ,KE)&(RE,PK,JF)&(RJ,PE,KF)&(KJ,PR,EF)
\end{array}                                                   \tag{2}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,PK,EF)&(PK,JE,RF)&(PR,JE,KF)&(PR,KF,JE).
\end{array}                                                   \tag{3}
\]
The shore cycle-edge pairs, in the cyclic order (1), are
\[
\begin{array}{c|cccccc}
\text{edge}&q_1q_2&q_2q_4&q_4q_3&q_3q_e&q_eq_5&q_5q_1\\ \hline
\text{labels}&PF&RJ&PE&RK&PJ&RK.
\end{array}                                                   \tag{4}
\]
The six shore-port pairs, including terminal \(e\), are
\[
\begin{array}{c|cccccc}
\text{port}&e&p_1&p_2&p_3&p_4&p_5\\ \hline
\text{labels}&EF&JE&KE&JF&KF&EF.
\end{array}                                                   \tag{5}
\]
Here \((a,b)=(E,F)\), so the proper-port part of (5) is precisely the crossed form \((Ja,Ka,Jb,Kb,EF)\) of Note 451(7). The terminal pairs in (3) and (5) give \(P=eX,R=eY,K=Y,J=X,E=F=e\), hence type \((eX)(eY)\). Its exterior restriction is the Note-446 fifth-line choice \(K:2u_1,4u_3,5u_5\).

Tables (2)–(5) specify six **complete** perfect matchings and a genuine BF row. Every subdivision triple partitions \(\{P,R,K,J,E,F\}\). At original prism vertices \(1,\ldots,6\), the incident pairs are, respectively,
\[
(PK,RF,JE),\quad(PK,RF,JE),\quad(PJ,RE,KF),\quad
(PK,RJ,EF),\quad(PE,KJ,RF),\quad(PR,KF,JE),          \tag{6}
\]
again partitions. At shore vertices \(q_1,q_2,q_4,q_3,q_e,q_5\), the cycle/port pairs are
\[
(PF,RK,JE),\quad(PF,RJ,KE),\quad(RJ,PE,KF),\quad
(PE,RK,JF),\quad(RK,PJ,EF),\quad(PJ,RK,EF).          \tag{7}
\]
Thus each occurrence selects exactly one incident edge at each vertex, and every edge has load two. In particular, the two zero-port triples retain the **different complete shore matchings**
\[
Q_P=\{q_1q_2,q_4q_3,q_eq_5\},\qquad
Q_R=\{q_2q_4,q_3q_e,q_5q_1\}.                       \tag{8}
\]

## Complete closure supplies both forbidden loops

In the complement of \(Q_P\), the three shore paths pair the ports as
\[
ep_3\mid p_1p_5\mid p_2p_4,                         \tag{9}
\]
each with three edges including its two port semiedges; there is no closed shore component. [Note 359's exterior pairing table](359-two-root-parity-gate-and-k33-sharpness.md) gives, for the zero-port \(eX\)-triple rooted at \(4\), the pairing \(Xp_5\mid p_1p_2\mid p_3p_4\). Gluing it to (9) produces the single open route
\[
e\to p_3\to p_4\to p_2\to p_1\to p_5\to X.
\tag{10}
\]
The zero-port \(eW\)-triple rooted at \(3\) has exterior pairing \(Wp_1\mid p_4p_5\mid p_2p_3\), which similarly gives the single open route
\[
e\to p_3\to p_2\to p_4\to p_5\to p_1\to W.
\tag{11}
\]
More concretely, the **entire** complements of these two triples are the following paths, with the displayed terminal semiedges at their ends:
\[
e-q_e-q_3-u_3-4-u_4-q_4-q_2-u_2-3-t_W-6-t_Z-2-u_1-q_1-q_5-u_5-5-t_Y-1-t_X-X,
\tag{12}
\]
\[
e-q_e-q_3-u_3-3-u_2-q_2-q_4-u_4-4-t_X-1-t_Y-5-u_5-q_5-q_1-u_1-2-t_Z-6-t_W-W.
\tag{13}
\]
Each path contains all 21 pole vertices exactly once and has 22 edges, so there is no residual closed component. Alternating either path into two singleton matchings gives a Tait colouring; doubling those three matchings gives genuine loops \([eX]\) and \([eW]\) in the **complete** BF support. This proves directly that the 21-vertex pole is not exact Case XII, even though the crossed \((eX)(eY)\) row is real.

There is also a 29-vertex boundary with the same crossed row and an odd closed component in the complement of **every** zero-port shore matching. Replace \(q_2\), whose incident pairs in (7) are \(PF,RJ,KE\), by the Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md). Its three attachment pairs can be labelled \((M_2,M_4)=(P,F)\), \((M_1,M_3)=(R,J)\), and \((M_\infty,M_0)=(K,E)\). Note 381's substitution proof lifts the six complete matchings and preserves the **entire** BF boundary support, so the required crossed row and both forbidden loops persist. Its odd-cycle argument forces every zero-port shore matching to leave an internal complementary five-cycle. The inserted gadget creates a cyclic three-edge cut; this 29-vertex pole is a boundary for rowwise plus shore-parity arguments, not an exact-Case-XII or minimum-host example.

The result distinguishes a real row from a real exact-Case-XII pole: the crossed signature is compatible with actual incidence, complete matchings, girth five and even the odd-closed-shore condition after support-neutral substitution, while full closure still restores the two forbidden loops. It does not decide whether any irreducible higher-order shore can carry this signature **without** forbidden support. The construction and path checks are hand-derived and await independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 453](453-the-crossed-hamilton-port-row-forces-a-forbidden-loop.md) resolves the last question for this crossed signature: every genuine row of this port form admits a shore-preserving forbidden \([eX]\) BF recompletion, at every shore order.
