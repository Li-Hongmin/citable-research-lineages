> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fork-triangle marking is impossible for a long-leaf \(e\)-neighbour

Continue the complete exact-Case-XII, one-internal-mark five-cut setting of [Notes 259–260](260-the-mixed-fork-row-has-a-forbidden-ec-ab-shore-splice.md), with the same \(|U|=4,r=4\) fork
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\qquad h_i=u_i\Sigma.
\]
The odd shore \(\Sigma\) has arbitrary order and unmarked cycle rank. This time the marks are
\[
a:L\!:\!\Sigma,\qquad b:PR,\qquad c:PQ,\qquad d:QR,       \tag{1}
\]
and \(ea,eb\) are the two allowed edges at the internal shore mark \(e\). The choice \(b=QR\) is equivalent by interchanging \(P,Q\) and \(u_1,u_2\).

**Theorem.** No rooted cubic five-pole with (1) has complete exact-Case-XII BF support. In the required real \((ea)(ab)\) row, equal singleton-\(a\) exterior masks either overload \(3O\), or force a pure unit exterior half that has a same-port forbidden \(ec\) replacement. Different singleton-\(a\) masks fail the pure-\(S\) terminal-path condition after exchanging the complete singleton occurrences. Together with [Note 260](260-the-mixed-fork-row-has-a-forbidden-ec-ab-shore-splice.md), this excludes **every placement of the allowed second neighbour of \(e\)** for the fork marking with shore mark at \(L\) and a marked triangle on \(P,Q,R\). The other fork markings and the path tree remain open.

## The two possible singleton-\(a\) masks

Take the published Case-XII row \((ea)(ab)\), with \(ab\in T\), and write it as
\[
\mathcal D=X_a+Y_a+Z_e,\qquad
\mathcal E=U_{ab}+V_a+W_b,\qquad
\mathcal D+\mathcal E=2\mathbf1.                         \tag{2}
\]
The opposite \(T\)-state makes \(\mathcal D\) pure \(S\), also after exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\). The zero-port triple has the unique exterior
\[
X_a=\{a:L,1P,2Q,3O,4R\}.                              \tag{3}
\]
The exterior \(a\)--\(b\) path in \(X_a\triangle Y_a\) goes either by the short route \(L-u_4-R\) or by the long route \(L-u_3-O-u_1-P\). Completing the other two marks and the \(U\)-vertices gives exactly
\[
\begin{aligned}
Y_s&=\{b:R,c:P,d:Q,3O,4L,h_1,h_2\},\\
Y_\ell&=\{b:P,c:Q,d:R,1O,3L,h_2,h_4\}.
\end{aligned}                                                   \tag{4}
\]
Hence both \(Y_a,V_a\) have one of these two exteriors. Switching their respective \(a\)--\(b\) paths gives state-\(eb\) zero-port triples with the *same complete shore mask* as \(X_a\):
\[
X_s=\{b:R,1P,2Q,3O,4L\},\qquad
X_\ell=\{b:P,1O,2Q,3L,4R\}.                        \tag{5}
\]
Purity requires the shore \(e\)-path against \(X_a\) and against the applicable triple in (5) to end at \(c,d\) in opposite order. If \(Y_a,V_a\) are different, exchanging them makes **both** \(X_s,X_\ell\) relevant with the same \(X_a,Z_e\) and the same shore \(e\)-pairing.

If both singleton-\(a\) occurrences use \(Y_s\), the edge \(3O\) occurs in \(X_a,Y_a,V_a\) and has load three. This is impossible.

## Mixed masks cannot keep the half pure

Suppose the two occurrences are \(Y_s,Y_\ell\). They already load \(h_2\) twice; \(X_a+Y_s\) already loads \(3O\) twice. Therefore \(Z_e\) uses neither edge. Since its nonterminal cross marks \(b,c,d\) must occupy all three leaves \(P,Q,R\), vertex \(u_2\) must use \(2O\): \(Q\) is occupied and \(h_2\) is unavailable. The only possible remaining treatments of \(L\) are
\[
\begin{array}{c|c|c}
\text{treatment of }L&\text{other proper edges}&\text{shore ports besides }e\\ \hline
a:\Sigma,3L&2O,h_1,h_4&\{a:\Sigma,h_1,h_4\}\\
a:\Sigma,4L&2O,h_1,h_3&\{a:\Sigma,h_1,h_3\}\\
a:L&2O,h_1,h_3,h_4&\{h_1,h_3,h_4\}.
\end{array}                                                   \tag{6}
\]
The cross-mark halves have one of the two orientations
\[
B_s=\{b:R,c:P,d:Q\},\qquad B_\ell=\{b:P,c:Q,d:R\}.     \tag{7}
\]
Thus (6)–(7) list all six exterior possibilities for \(Z_e\); no shore-internal matching is assumed.

For the first two treatments, the shore \(e\)-path cannot pair with \(a:\Sigma\): against either triple in (5), that port goes directly to terminal \(a\), giving the forbidden state \(ab\). For the remaining \(h\)-ports, the following table lists the exterior terminal reached against \(X_a,X_s,X_\ell\), in that order:

| Treatment of \(L\) | Cross orientation | Selected \(h\)-ports and terminal triples |
|---|---|---|
| \(a:\Sigma,3L\) | \(B_s\) | \(h_1:(c,c,d),\ h_4:(b,d,c)\) |
| \(a:\Sigma,3L\) | \(B_\ell\) | \(h_1:(b,d,c),\ h_4:(d,c,d)\) |
| \(a:\Sigma,4L\) | \(B_s\) | \(h_1:(c,c,d),\ h_3:(d,d,c)\) |
| \(a:\Sigma,4L\) | \(B_\ell\) | \(h_1:(b,d,c),\ h_3:(c,c,d)\) |
| \(a:L\) | \(B_s\) | \(h_1:(c,c,d),\ h_3:(d,d,a),\ h_4:(b,a,c)\) |
| \(a:L\) | \(B_\ell\) | \(h_1:(b,d,c),\ h_3:(c,c,a),\ h_4:(d,a,d)\) |

Every entry is obtained by following the alternating path in the eight-edge tree (3). In each row, no port has endpoint triple \((c,d,d)\) or \((d,c,c)\), the only two ways to keep both exchanged rows pure \(S\). The sole port that swaps \(c,d\) against \(X_s\), namely the second row's \(h_4:(d,c,d)\), fails against \(X_\ell\). Hence the mixed case is impossible.

## The repeated long mask has a forbidden shore splice

It remains that \(Y_a,V_a\) both use \(Y_\ell\). Their common mask already loads \(b:P,c:Q,d:R,1O,3L,h_2,h_4\) twice. The singleton-\(e\) exterior is then uniquely forced to use the complementary mark halves and avoid those loaded edges:
\[
Z_e=\{a:\Sigma,b:R,c:P,d:Q,2O,4L,h_1,h_3\}.     \tag{8}
\]
Indeed, \(a:L\) would leave \(u_4\) without an available edge, \(3L\) is saturated, and \(2O\) is the only way to cover \(O\) without using \(1O\) or forcing saturated \(h_2\). The three masks \(X_a,Y_\ell,Z_e\) partition every proper exterior edge once.

They have a second, state-\(ec\) exterior decomposition with the **same shore ports in the same slots** and the same unit aggregate load:

| Shore ports | Pure \(ea\) exterior | Replacement \(ec\) exterior |
|---|---|---|
| \(\varnothing\) | \(X_a=\{a:L,1P,2Q,3O,4R\}\) | \(U_{ec}=\{c:P,1O,2Q,3L,4R\}\) |
| \(\{h_2,h_4\}\) | \(Y_\ell=\{b:P,c:Q,d:R,1O,3L,h_2,h_4\}\) | \(V_c=\{a:L,b:R,d:Q,1P,3O,h_2,h_4\}\) |
| \(\{e,a:\Sigma,h_1,h_3\}\) | \(Z_e\text{ from (8)}\) | \(W_e=\{a:\Sigma,b:P,c:Q,d:R,2O,4L,h_1,h_3\}\) |

Each replacement mask is an exterior matching, and both columns partition the eight \(K\)-edges, all exterior marked halves, and \(h_1,h_2,h_3,h_4\) exactly once. Reuse the three **complete actual shore matching restrictions** of \(X_a,Y_\ell,Z_e\) in the supposed row (2), glue them slotwise to the \(ec\) column, and keep its opposite \(ab\) half. This yields a real BF row of type \((ec)(ab)\). Both states lie in \(T\): \(ec\) is not incident with one of \(e\)'s allowed neighbours, and \(ab\) joins the two allowed neighbours through \(e\). Exact Case XII forbids the row. All three cases are impossible, proving the theorem. \(\square\)

The proof uses complete perfect-matching closure via the singleton exchange and final shore splice. It does not constrain the shore's order or cycle rank. The other two fork markings, the path tree, larger barriers, other Tutte profiles, and Berge--Fulkerson remain open. The six-route table and analytic argument have not received an independent check.
