> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The three-spoke prism excludes the top/opposite-bottom forbidden pair

Use the three-spoke prism tree of [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,Cc),\qquad
(X,Y,Z,W)=(AC,ab,bc,ca).
\tag{1}
\]
The tree edges are subdivided at \(u_i\), and the four omitted edges at their marked terminal vertices. The sixth shore terminal is \(e\). Assume that the **complete** BF support is exact Case XII with forbidden \(e\)-labels \(\{eX,eW\}\). Its two possible pentagons are \(e-Y-X-W-Z-e\) and \(e-Y-W-X-Z-e\). Under their respective identifications \((e,Y,X,W,Z)=(1,3,5,2,4)\) and \((1,3,2,5,4)\), the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) lists the mixed row \((eX)(eY)\) as \((15)(13)\) and \((12)(13)\), respectively. It lists neither \([eW]\), respectively \([12]\) and \([15]\), nor \((eX)(eW)=(12)(15)\).

> **Three-spoke exclusion.** No cubic five-pole with exterior (1), at any shore order or topology, has this exact-Case-XII support. Every required \((eX)(eY)\) row either fails a local matching slot or can be recompleted, while retaining each of its six entire shore matchings, to the forbidden loop \([eW]\) or forbidden row \((eX)(eW)\).

Name the complete matching occurrences \(P=eX,\ R=eY,\ K=Y,\ J=X,\ E=e,\ F=e\), where the equalities specify missing-pair types for triples and terminal types for singletons. Both triples are zero-port by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). In \(R\triangle K\), the \(Y\)-starting path must end at \(Z\): ending at \(X\) gives \([eX]\), and ending at \(W\) gives \((eX)(eW)\), with \(P=eX\) unchanged. Root the tree at the endpoint of \(Y\) used by \(R\). At each subdivided tree edge, \(R\) matches the subdivision vertex to the child. Starting at the root, the alternating path can only leave an original vertex along a \(K\)-edge to a child or to a marked terminal; it reaches each subdivision vertex along that \(K\)-edge and leaves along the \(R\)-edge to the child. It therefore never uses a proper shore port. Switching produces an actual \(eZ\)-triple with exactly \(R\)'s complete shore matching.

There are only four root-and-tree-path candidates ending at \(Z\). With \(R=eY:a\), the long route \(Y-a-u_3-A-u_1-B-u_2-C-u_5-c-Z\) occupies \(a\) by \(au_3\) and \(c\) by \(Z:c\), leaving neither endpoint available for the required \(W=ca\) half of \(K\). With \(R=eY:b\), the direct route \(Y-b-Z:b\) fails because \(P,R\) already load both \(au_3,cu_5\) twice: \(K\) would need \(W\) at both \(a,c\). The two remaining routes are
\[
\alpha:\ Y-a-u_3-A-u_1-B-u_4-b-Z,\qquad
\beta:\ Y-b-u_4-B-u_2-C-u_5-c-Z.                 \tag{2}
\]
In route \(\alpha\), the saturated \(cu_5\) slot and the path fix
\[
R=eY:a,\qquad
K:Y;\ X:C,Z:b,W:c,\ au_3,Au_1,Bu_4;\ p_2,p_5.  \tag{3}
\]
We now show that **every** genuine six-matching row satisfying (3) has a forbidden recompletion. No first-exit, parity, or equal-shore-mask hypothesis is needed.

Put \(\Lambda=\{J,E,F\}\). In every case below, \(P,R\) use no proper shore port, \(K\) uses \(p_2,p_5\), and \(E,F\) select shore terminal \(e\). The three occurrences in \(\Lambda\) cover each of \(a,b,c\) by marked halves: \(P,R,K\) have already filled the relevant spoke-half slots. Thus the top-vertex choices below determine all five proper-port label pairs.

**Case \(P=eX:A\).** Relabel \(E,F\) so that \(E:X:A\) and \(F:X:C\). At \(A\), \(J,F\) split \(Au_1,Au_3\); at \(B\), one label \(L\in\Lambda\) takes \(Bu_4\), while the other two take \(Bu_2\). At \(C\), \(J,E\) take \(Cu_5\) and \(F:X:C\). Consequently the proper-port pairs, in \(p_1,\ldots,p_5\) order, are exactly
\[
\begin{array}{c|ccccc}
&p_1&p_2&p_3&p_4&p_5\\ \hline
F:Au_1,\ J:Au_3&JE&KL&EF&\Lambda\setminus\{L\}&KF\\
F:Au_3,\ J:Au_1&EF&KL&EJ&\Lambda\setminus\{L\}&KF.
\end{array}                                                   \tag{4}
\]
Here a juxtaposition such as \(KL\) is a two-label set; \(\Lambda\setminus\{L\}\) has two labels. All three choices of \(L\) are allowed in this table.

For the first line of (4), replace the exterior by a forbidden \([eW]\) loop: take both zero-port triples \(P,R=eW:a\), make \(K,J\) singleton \(W\), and retain \(E,F\) singleton \(e\). At the tree subdivisions \(u_1,\ldots,u_5\), put the three incident edge-label pairs in the order \((\text{first endpoint half},\text{second endpoint half},p_i)\):
\[
(KF,PR,JE),\
(\Lambda\setminus\{L\},PR,KL),\
(PR,KJ,EF),\
(KL,PR,\Lambda\setminus\{L\}),\
(EJ,PR,KF).                                             \tag{5}
\]
At the marked subdivisions, the terminal/first-half/second-half pairs are
\[
t_X:(PR,JE,KF),\quad
t_Y:(PR,EF,KJ),\quad
t_Z:(PR,EF,KJ),\quad
t_W:(KJ,PR,EF),                                           \tag{6}
\]
where the half orders are \(X:(A,C),Y:(a,b),Z:(b,c),W:(a,c)\).

For the second line of (4), instead take \(P=eX:A,\ R=eW:a,\ K=W,\ J=X,\ E=F=e\) as **boundary types**. The tree-subdivision pairs in the same order are
\[
(KJ,PR,EF),\
(\Lambda\setminus\{L\},PR,KL),\
(RF,PK,EJ),\
(KL,PR,\Lambda\setminus\{L\}),\
(EJ,PR,KF),                                             \tag{7}
\]
and the marked-subdivision pairs are
\[
t_X:(RJ,PE,KF),\quad
t_Y:(PR,JE,KF),\quad
t_Z:(PR,JE,KF),\quad
t_W:(PK,RF,JE).                                           \tag{8}
\]
This is the forbidden double-\(T\) row \((eX)(eW)\). In (5) and (7), the port pairs agree **label by label** with the old row (4), and each triple of incident pairs partitions \(\{P,R,K,J,E,F\}\). At each original prism vertex, the same is true; at \(B\), for example, the pairs are \(PR,\Lambda\setminus\{L\},KL\). Therefore all six new exterior restrictions are actual matchings with every exterior edge loaded twice. Gluing each to its **unchanged, possibly different** complete shore restriction produces the claimed forbidden row.

**Case \(P=eX:C\).** Now \(P,K\) saturate \(X:C\), so \(E,F\) both take \(X:A\), while \(J\) takes \(Au_3\). Let \(L_1,L_2,L_4\) be the permutation of \(\Lambda\) taking \(Bu_1,Bu_2,Bu_4\), respectively, and let \(H\) be the one taking \(Cu_2\). The remaining two take \(Cu_5\). At \(u_2\), \(H\ne L_2\), so \(H=L_1\) or \(H=L_4\). The old proper-port pairs are
\[
\begin{array}{c|ccccc}
&p_1&p_2&p_3&p_4&p_5\\ \hline
H=L_1&\Lambda\setminus\{L_1\}&KL_4&EF&
       \Lambda\setminus\{L_4\}&KL_1\\
H=L_4&\Lambda\setminus\{L_1\}&KL_1&EF&
       \Lambda\setminus\{L_4\}&KL_4.
\end{array}                                                   \tag{9}
\]
For \(H=L_1\), use the forbidden \([eW]\) loop with \(P,R=eW:a,\ K=J=W,\ E=F=e\) as boundary types. Its tree-subdivision pairs are
\[
(KL_1,PR,\Lambda\setminus\{L_1\}),\
(\Lambda\setminus\{L_4\},PR,KL_4),\
(PR,KJ,EF),\
(KL_4,PR,\Lambda\setminus\{L_4\}),\
(\Lambda\setminus\{L_1\},PR,KL_1).                 \tag{10}
\]
Its marked pairs are \(t_X:(PR,\Lambda\setminus\{L_1\},KL_1)\) and the \(t_Y,t_Z,t_W\) pairs of (6).

For \(H=L_4\), use the forbidden double-\(T\) row with \(P=eX:C,\ R=eW:a,\ K=W,\ J=X,\ E=F=e\) as boundary types. Its tree-subdivision pairs are
\[
(PK,RL_1,\Lambda\setminus\{L_1\}),\
(PL_2,RL_4,KL_1),\
(RJ,PK,EF),\
(KL_4,PR,\Lambda\setminus\{L_4\}),\
(\Lambda\setminus\{L_4\},PR,KL_4),                 \tag{11}
\]
and its marked pairs are \(t_X:(RJ,EF,PK)\) and the \(t_Y,t_Z,t_W\) pairs of (8). Each row of (10)–(11) has exactly the old port pairs (9). The six labels partition at every subdivision and at the original vertices: at \(B\), (11) gives \(RL_1,PL_2,KL_4\), whose three non-\(P,R,K\) labels are the permutation \(L_1,L_2,L_4\) of \(\Lambda\). This verifies a full BF row after gluing the retained shore matchings.

Finally, \(\beta\) is the reflected version of \(\alpha\). Reflect the prism by \(A\leftrightarrow C,\ a\leftrightarrow c\), fixing \(B,b,X,W\) and swapping \(Y,Z\) and ports \(p_1\leftrightarrow p_2,\ p_3\leftrightarrow p_5\). In a \(\beta\)-row first switch its \(R=eY:b\) with \(K=Y\) along \(\beta\), giving \(eZ:c\) and singleton \(Z\) while \(P=eX\) remains. After relabelling by the reflection, this is an \(\alpha\)-row with \(R=eY:a,\ K=Y\) in a pole whose shore ports are merely renamed. The above shore-preserving recompletion yields a forbidden row there; reversing the relabelling gives one in the original pole. Hence \(\beta\) is excluded too.

All four \(Y\to Z\) routes are therefore excluded, so the required \((eX)(eY)\) row cannot exist. This closes the forbidden pair \(\{e\,AC,e\,ca\}\) for this **one three-spoke prism tree orbit**, not the other forbidden pairs, the second three-spoke tree orbit, other exterior profiles, or Berge–Fulkerson. The argument is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
