> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The cross-row singleton-\(e\) is a three-deletion matching

Assume a genuine exact-Case-XII \((4,2,2)\) five-pole. [Note 200](200-two-kempe-switches-balance-the-422-exterior-connector.md) leaves only
\[
S=p-c-q-d-e-p,\qquad T=\{pq,pd,qe,ce,cd\},                 \tag{1}
\]
with unit loads on the entire exterior connector in every \(S\)--\(T\) row. [Note 201](201-the-surviving-422-shore-must-have-an-unmarked-odd-cycle.md) shows that the unmarked shore \(F_C=F[C]\) contains an odd cycle. This note locates the *remaining* cross-row singleton-\(e\) identity question in a specific ordinary matching graph. It does not assume that the two required rows already share a matching.

**Three-deletion bijection.** Let \(v_p,v_d,v_h\) be the three \(C\)-endpoints of the respective outer marks and centre edge. They are pairwise distinct, and
\[
\boxed{\operatorname{PM}(F_C-\{v_p,v_d,v_h\})\ne\varnothing.}    \tag{2}
\]
The full perfect matchings with singleton boundary \(e\) and exterior edges
\[
h,\qquad qw_1,\qquad cw_2,
\]
are in bijection with the perfect matchings of this three-vertex-deletion graph: add the fixed three exterior edges, the terminal semiedge at \(t_e\), and the two marked halves from \(t_p,t_d\) to \(v_p,v_d\). Every other core vertex is matched inside \(F_C\). Conversely, any such full matching restricts to a matching of the deletion graph.

To prove existence in (2), take either required row \((de)(pq)\) or \((ep)(cd)\). Saturate its \(S\)-half to state \(de\). The proof of Note 200 forces the singleton-\(e\) occurrence \(Z\) in this decomposition to use exactly the displayed exterior edges. For the second row, the exterior \(de\to ep\) switch restores state \(ep\) **without changing \(Z\) or the full half-load**, so the original \(T\)-half can be retained. Thus both required row fibres admit a representative with this exterior route. Its restriction supplies (2); a genuine perfect matching cannot select two exterior edges at the same core vertex, so the three deleted vertices are distinct. In these chosen representatives, the triple and other-singleton occurrences have shore-port sets \(\{e_X\}\) and \(\{q,c,e_Y\}\), while \(Z\) has \(\{p,d,h\}\); the complete masks inside \(C\) may still differ.

**Exact difference between two choices.** Let \(Z_1,Z_2\) be singleton-\(e\) occurrences selected from these canonical representatives of the two row fibres. Their terminal and all exterior proper edges agree. Hence
\[
Z_1\triangle Z_2
\quad\text{is a disjoint union of even alternating cycles entirely in}
\quad F_C-\{v_p,v_d,v_h\}.                              \tag{3}
\]
In particular, if the graph in (2) has a unique perfect matching, the two required row fibres have representatives with the **same full** singleton-\(e\) occurrence. Conversely, if their canonical singleton-\(e\) fibres are disjoint, the deletion graph has at least two perfect matchings and contains an even cycle surviving deletion of \(v_p,v_d,v_h\). This is a necessary boundary for a failure of this particular identity, not an exact-Case-XII counterexample or a solution of the other matching identities.

There is a precise one-cycle transport test. Fix one actual BF row containing \(Z_2\), and let \(K\) be one component of (3). Replacing \(Z_2\) by \(Z_2\triangle K\) while changing **only one other matching occurrence** \(N\) and preserving the six-matching edge load is possible exactly when \(N\) uses on \(K\) the edges complementary to \(Z_2\). Then \(N\triangle K\) is another actual perfect matching and
\[
(Z_2\triangle K)+(N\triangle K)=Z_2+N.                    \tag{4}
\]
If no such occurrence exists in that row, this paired switch is unavailable. Other rows, multi-occurrence changes, or another choice of \(Z_1\) may still supply common identity. Thus (3) localizes the remaining obstruction to full-cycle phase alignment **inside the unmarked shore**; unit exterior loads alone do not certify the intersection of the two row fibres.
