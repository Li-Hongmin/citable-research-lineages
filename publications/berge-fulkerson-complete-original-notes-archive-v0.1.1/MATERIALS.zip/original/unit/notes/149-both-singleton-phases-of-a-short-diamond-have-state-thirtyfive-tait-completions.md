> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both singleton phases of a short diamond have state-35 Tait completions

The six-edge owner classification of [Note 146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md) forces more complete perfect matchings than its first Tait complement shows. After the harmless normalization of [Note 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md), **each** of the two phases of the four-junction singleton hexagon extends to an actual state-\(35\) three-edge-colouring. The completions are explicit flips on the two cycles of the theta core. This is a full-mask closure statement for every actual row of the specified shape, not an exact-Case-XII realization or a common \(B_2+C_4\) seed.

Let
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1                    \tag{1}
\]
be an actual normalized four-junction row with no state-\(34\) Tait colouring, and let its four-junction component \(\Omega\subseteq Z_3\triangle Y_3\) have six edges. Use \(K_o=\alpha\cup\delta\cup\chi\) and \(K_s=\beta\cup\gamma\cup\chi\) from [Note 148](148-short-diamond-core-cycles-cannot-change-the-five-terminal-pairing.md), where \(\chi\) is the overloaded chord. Put \(Z^0=Z_3\) and \(Z^1=Z_3\triangle E(\Omega)\); the latter equals \(Y_3\) on \(\Omega\) and \(Z_3\) outside it. A superscript \(K\) on \(U\) or \(D\) denotes switching that complete matching on the named proper alternating cycle.

**Two-phase Tait theorem.** The following two columns are actual, pairwise edge-disjoint perfect-matching triples in each row of the table. Each column sums to \(\mathbf1\) on every proper edge and semiedge and has Tait state \(35\).

| Strand lengths \((\alpha,\beta,\gamma,\delta)\) | Singleton phase \(Z^0\) | Singleton phase \(Z^1\) |
|---|---|---|
| \((2,2,1,1)\) | \(U^{K_o},Z^0,D\) | \(U,Z^1,D^{K_s}\) |
| \((2,1,2,1)\) | \(U^{K_o},Z^0,D\) | \(U^{K_s},Z^1,D\) |
| \((1,2,1,2)\) | \(U,Z^0,D^{K_o}\) | \(U,Z^1,D^{K_s}\) |
| \((1,1,2,2)\) | \(U,Z^0,D^{K_o}\) | \(U^{K_s},Z^1,D\) |

The two singleton masks are distinct complete matchings because they differ on all six edges of \(\Omega\). Thus this row supplies at least two distinct state-\(35\) Tait colourings, even if the pole has further singleton phase cycles elsewhere. In the \((2,1,2,1)\) pattern the two colourings share \(D_5\); in the \((1,2,1,2)\) pattern they share \(U_{35}\).

**Proof.** In the normalized row, all active components outside the four-junction diamond are split, and inactive edges are split as well. Therefore the S half \(U+Z+D\) has load one on every edge outside \(\Theta=\Omega\cup\chi\). Any two S matchings intersecting each other do so only on the overloaded strands of \(\Theta\). The four owner sequences in Note 146 give the following phasewise disjoint pair:

| Strand lengths | Pair disjoint from \(Z^0\) | Pair disjoint from \(Z^1\) |
|---|---|---|
| \((2,2,1,1)\) | \(D,Z^0\) | \(U,Z^1\) |
| \((2,1,2,1)\) | \(D,Z^0\) | \(D,Z^1\) |
| \((1,2,1,2)\) | \(U,Z^0\) | \(U,Z^1\) |
| \((1,1,2,2)\) | \(U,Z^0\) | \(D,Z^1\) |

For example, the first two patterns have an \(UZ\) edge but no \(DZ\) edge on \(\Omega\), while the last two have a \(DZ\) edge but no \(UZ\) edge. In the switched phase, \(Z^1\) uses the \(Y\)-edges of \(\Omega\): the first and third patterns have no \(UY\) edge, and the second and fourth have no \(DY\) edge. On the chord \(Z^0,Z^1\) use only the inactive \(ZY\) third edges, disjoint from \(U,D\); outside the diamond, split normalization rules out every \(UZ\) and \(DZ\) intersection. Each listed pair is therefore disjoint globally. It has a unique cubic perfect-matching complement, whose boundary gives the third colour of a state-\(35\) Tait colouring.

The complement identities are literal. On \(K_o\), the first two patterns alternate \(U\) while the last two alternate \(D\), and replacing that occurrence by its \(K_o\) phase makes the S half-load one on the overloaded cycle. This gives the first Tait column, as proved more explicitly in Notes 147--148. On \(K_s\), the first and third patterns alternate \(D\), while the second and fourth alternate \(U\): the middle edge of its three-edge \(\beta\cup\gamma\) arc is respectively \(YD,UY,YD,UY\), and the chord alternates \(UD,rC\). Switching \(Z\) on \(\Omega\) moves the S-half overload from \(K_o\) to \(K_s\); switching the indicated occurrence on \(K_s\) removes it. Outside \(\Theta\) all three masks remain the original split S half. Hence the second Tait column has load one everywhere, identifying its unique complement with the displayed \(K_s\) flip. \(\square\)

For a genuine exact-Case-XII pole, every state-\(35\) Tait colouring stays within the allowed \(S\)-Tait orbit under terminal Kempe switches; the two completions therefore do not create a forbidden \(T\)-loop. They do show that the complete matching family contains both singleton-\(3\) phases as genuine Tait colours, with their companion masks confined to the short theta core. By [Note 148](148-short-diamond-core-cycles-cannot-change-the-five-terminal-pairing.md), all these core flips preserve the relevant \(U+D\) terminal pairing. Any no-seed \(p_{35}\) with the other \(D_5\)-pairing must still be distinguished by a cycle using edges outside \(\Theta\).
