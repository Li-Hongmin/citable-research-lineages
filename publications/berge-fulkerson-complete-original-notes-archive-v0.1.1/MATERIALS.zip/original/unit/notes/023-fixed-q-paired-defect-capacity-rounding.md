> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-Q paired-defect capacity rounding

The minimum exact-\(S\) pole of Note 020 shows that odd half-support need not
prevent capacity-two rounding.  This note identifies the mechanism in that
example while separating a general multiplicity lemma from conclusions that
are presently known only for the 15-vertex pole.

## A general covered-split criterion

Let \(P_1,\ldots,P_5\) be five perfect matchings of a cubic graph or cubic
pole, and define

\[
m(e)=|\{i:e\in P_i\}|,\qquad
P_0=\{e:m(e)=1\}.
\]

Suppose that the five matchings cover every edge.  Then

\[
\max_e m(e)\leq2
\quad\longleftrightarrow\quad
P_0\text{ is a perfect matching}. \tag{1}
\]

Indeed, the three incident multiplicities at every cubic vertex sum to five.
Under the capacity-two bound they are necessarily \((2,2,1)\), so the
multiplicity-one edges form a perfect matching.  Conversely, if \(P_0\) is a
perfect matching, exactly one incident edge at each vertex has multiplicity
one.  The other two multiplicities are positive by coverage, are not one by
the definition of \(P_0\), and sum to four; hence both are two.  For a
singleton-boundary transversal, each semiedge occurs in its designated
matching and in no other matching, so every semiedge belongs to \(P_0\).

This criterion is independent of the 15-vertex example.  A second general
fact is the matching cut-parity identity.  For every odd cycle \(C\),

\[
|P_0\cap\delta(V(C))|\equiv |V(C)|\equiv1\pmod2. \tag{2}
\]

Thus an odd half-support component is compatible with capacity two, but it
must have an odd number of multiplicity-one defect exits.

## Complete enumeration for the 15-vertex exact-S pole

For the pole of Note 020, the five singleton matching classes have sizes

\[
(5,4,5,5,5),
\]

so their product contains exactly \(2500\) transversals.  Complete enumeration
finds \(126\) capacity-two transversals.

Let \((L_t,R_t,Q_t)\) be the five selected Tait colourings used in Note 020.
Among the 126 solutions, four choose directly between the original ten
endpoints \(L_t,R_t\), use no switch, and preserve all five \(Q_t\).  The
complements of the fixed \(Q_t\) contain internal \((0,1)\)-alternating
cycles with length profiles

\[
(),\quad(6),\quad(6),\quad(),\quad(4,4).
\]

Switching arbitrary subsets of these cycles preserves the complete
fixed-\(Q\) signature.  The resulting endpoint families contain 100 feasible
representations, corresponding to 42 distinct capacity-two transversals.
The remaining 84 of the 126 capacity-two transversals are not represented by
this fixed-\(Q\) endpoint-switch family.  In particular,

\[
126=4\text{ zero-switch fixed-}Q
   +38\text{ switched fixed-}Q
   +84\text{ outside that family}.
\]

## Exchange distance does not give a uniform normal form

For a selected matching \(P\in\mathcal P_i\), define its distance from the
two original endpoints \(A_i,B_i\) by

\[
d(P)=\min_{A\in\{A_i,B_i\}}\frac{|P\triangle A|}{2}.
\]

Across the \(126\cdot5=630\) matching occurrences, 313 have distance zero,
193 have distance two through a \(C_4\), 73 have distance three through a
\(C_6\), and 51 have distance four through either a \(C_8\) or two
\(C_4\)'s.  The total distance of a transversal assumes every value from
zero through fourteen except one, with distribution

```text
0:4, 2:11, 3:4, 4:23, 5:7, 6:17, 7:17,
8:13, 9:7, 10:10, 11:5, 12:2, 13:3, 14:3.
```

Consequently these capacity solutions do not admit a uniform short-exchange
normal form relative to the original endpoints.  Their common structure is
instead visible in the multiplicity-one matching \(P_0\).

## Three paired-defect factors

Every one of the 126 solutions has one of exactly three possible
multiplicity-one perfect matchings.  Their fibres have sizes \(72,27,27\).
Once the five terminal vertices are matched by their semiedges, the ten
remaining vertices induce two odd \(C_5\)'s joined by the three independent
connector edges \(e_{10},e_{13},e_{14}\).  The three factors are

| connector | proper edges of \(P_0\) | fibre size |
|---|---|---:|
| \(e_{10}\) | \(e_8,e_{10},e_{11},e_{17},e_{19}\) | 72 |
| \(e_{13}\) | \(e_8,e_9,e_{13},e_{16},e_{17}\) | 27 |
| \(e_{14}\) | \(e_7,e_{11},e_{14},e_{15},e_{19}\) | 27 |

Cut parity forces an odd number of exits from each \(C_5\).  All three
connectors cannot occur in \(P_0\), because their removal would leave two
unmatchable vertices on one of the cycles.  Hence exactly one connector is
used.  It supplies one defect exit from each odd cycle and pairs the two
defects.  Deleting its endpoints leaves a four-vertex path on each cycle,
whose perfect matching is unique.  This proves the three-factor description
without relying on the fibre count.

## Scoped candidate

The example motivates the following candidate interface.  After switches on
internal \((0,1)\)-alternating cycles that preserve every \(Q_t\), seek a
covered endpoint split for which \(P_0\) is a perfect matching and has exactly
one exit from each odd half-support component, with the exits paired by
proper connector edges.  By (1), any such split is immediately a
capacity-two transversal.

This **fixed-\(Q\) paired-defect rounding** statement is proved here only for
the particular 15-vertex pole: it has four zero-switch witnesses and 42
distinct fixed-\(Q\) witnesses in total.  It is a scoped candidate, not a
general theorem for exact-\(S\) poles or for arbitrary odd half-support
components.

The deterministic certificate is
`scratch/worker-proof/classify_exact_s_capacity_roundings.py`.  From the
project root, run

```text
python3 units/berge-fulkerson/scratch/worker-proof/classify_exact_s_capacity_roundings.py
```

The terminating line is

```text
EXACT_S_CAPACITY_ROUNDINGS_CLASSIFIED
```
