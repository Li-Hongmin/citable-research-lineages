> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Loop-to-column carriers in Cases IV, IX and XI

This note gives a strict branch reduction for the three remaining exact
five-cut support cases IV, IX and XI. It does not exclude any of them.

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

For a three-matching half-load \(A\), let \(\mathcal R(A)\) be the set of
lonely-pair states of all proper 3-edge-colourings of its cubic
parallel-edge multigraph. We use the standard closure

\[
\varnothing\ne\mathcal R(A)\subseteq S
\quad\Longrightarrow\quad
\mathcal R(A)=S. \tag{1}
\]

## Tait-emptiness

The supported S-loops in Cases IV, IX and XI are respectively

\[
\{[13],[24],[25]\},\qquad
\{[13],[25],[35]\},\qquad
\{[13],[14],[24],[25]\}.
\]

If a proper 3-edge-colouring had lonely pair \(r\), doubling its colour
classes would give an actual BF cover of loop type \([r]\). Hence \(r\) must
be a supported loop. Closure under the two neighbours in the complementary
S-pentagon then forces all five S states, contradicting the missing loop in
each case. Since no T-loop is supported, all T states are excluded as well.
Therefore every exact IV, IX or XI pole is Tait-empty.

## Carrier orientation theorem

Take any supported S-loop witness \([s]\), with complementary half-loads
\(A+B=2\mathbf1\). Both halves initially have state \(s\). They cannot both
have state set contained in \(S\): by (1) both would then equal \(S\), and
combining arbitrary decompositions would realize every S--S type, including
one omitted by the exact case support.

Thus one half, say \(B\), has a T-state. The other half cannot also have a
T-state, because two complementary T decompositions would produce a
forbidden T-loop or T--T type. Consequently

\[
\mathcal R(A)=S,\qquad
s\in\mathcal R(B),\qquad
\mathcal R(B)\cap T\ne\varnothing. \tag{2}
\]

The state set of the second shore is further restricted by the exact support.
For Cases IV and IX,

\[
\mathcal R(B)\subseteq
\begin{cases}
(T\setminus\{45\})\cup\{13,24,25\},&\mathrm{IV},\\
T\cup\{13,25,35\},&\mathrm{IX},
\end{cases}
\tag{3}
\]

and for Case XI,

\[
\mathcal R(B)\subseteq (S\setminus\{35\})\cup T. \tag{4}
\]

Indeed, every state in the universal shore combines with every state in
\(\mathcal R(B)\), so any state whose pair type is absent from the exact
support is impossible.

## Remaining interface

The theorem supplies an S-universal carrier from every supported S-loop and
places its complementary carrier in a restricted T column (or one of the
listed S-loops). It does not identify carriers arising from different loop
witnesses or different S--T cells. Alternating-cycle differences can still
change the half-load and its singleton fibres. The remaining problem is
therefore a cross-column common-incidence statement: prove that two such
carriers share a compatible singleton section, or construct a real pole in
which all candidate sections remain incompatible.

The derivation and the exact fibre-cardinality consequences are preserved in
scratch/worker-mmtt-case-ix-xi-incidence/residual-iv-ix-xi-tait-empty-boundary-20260902.md.
