> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Overlapping BF types force non-singleton singleton fibres

This note records a general perfect-matching obstruction in the Tait-empty
branch of a cubic five-pole. It sharpens the fibre information available for
MMT Cases IV, IX and XI, but it does not prove a cross-cell join or the
Berge--Fulkerson conjecture.

Let \(H\) be a cubic five-pole with distinct semiedges. Write
\(\mathcal P_i\) for the perfect matchings using only semiedge \(i\), and
\(\mathcal Q_{ij}\) for those using the three semiedges outside \(ij\).

## Overlap-repetition lemma

Assume that \(H\) has no proper 3-edge-colouring. If a BF cover of type
\[
(ij)(ik),\qquad i,j,k\text{ distinct},
\]
uses the same matching \(P\in\mathcal P_i\) in its two \(i\)-slots, then
\(H\) has a proper 3-edge-colouring. Consequently every supported
overlapping type \((ij)(ik)\) satisfies
\[
|\mathcal P_i|\ge 2. \tag{1}
\]

### Proof

The six matchings in the alleged cover can be written
\[
Q_{ij},\ Q_{ik},\ P,\ P,\ P_j,\ P_k,
\]
and their edge-object incidence vectors satisfy
\[
\chi_{Q_{ij}}+\chi_{Q_{ik}}+2\chi_P+\chi_{P_j}+\chi_{P_k}
=2\mathbf 1. \tag{2}
\]

Every matching other than the two copies of \(P\) therefore avoids every
proper edge of \(P\). Delete those proper edges. The remaining proper graph
has degree two at every internal vertex and at terminal \(i\), and degree one
at the other four terminals; its components are paths and cycles.

On each path, \(Q_{ij}\) and \(P_j\) use opposite endpoint statuses. At
terminal \(j\), \(Q_{ij}\) uses the proper edge and \(P_j\) uses the
semiedge; at every other endpoint they make the opposite choice. Their
restrictions are therefore opposite alternating patterns and are edge
disjoint. On a cycle, if the two alternating restrictions coincide, toggle
\(Q_{ij}\) on that cycle; otherwise leave it unchanged. We obtain a
boundary-equivalent matching \(Q'_{ij}\) disjoint from \(P_j\) on every
edge object.

The complement of \(Q'_{ij}\cup P_j\) in \(H\) is a perfect matching \(R_i\)
using only semiedge \(i\). Thus \(Q'_{ij},P_j,R_i\) are three edge-disjoint
perfect matchings with boundary classes
\([5]\setminus\{i,j\},\{j\},\{i\}\). They form a proper 3-edge-colouring,
contradicting the assumption. \(\square\)

## Consequence for the residual MMT cases

The exact supports of Cases IV, IX and XI all contain the following five
overlapping \(S\)--\(T\) types:
\[
(13)(12),\quad (24)(12),\quad (13)(23),\quad
(14)(34),\quad (25)(15). \tag{3}
\]

The preceding Tait/Kempe reduction shows that an exact IV, IX or XI pole is
Tait-empty. Applying (1) to (3) gives
\[
|\mathcal P_1|,|\mathcal P_2|,|\mathcal P_3|,|\mathcal P_4|,|\mathcal P_5|\ge2.
\tag{4}
\]

In particular, (4) supplies the previously missing non-singleton condition
for \(\mathcal P_4\) in Case IX.

## Boundary of the result

The lemma is a fibre-cardinality statement. It does not identify the
matching choices used in different BF cells, and hence does not imply the
D5 natural join or an \(A=(12345)\) cover. The remaining interface for
IV/IX/XI is still a common-perfect-matching incidence theorem across cells.

For orientation, a bounded Omen check at order \(13\) imposed a common finite
singleton pool, finite-pool Tait-emptiness, and a singleton
\(\mathcal P_4\). Those checks returned `bounded_unsat`; a separate pulse
with all five singleton pools required to be distinct returned `unknown`
after 120 seconds. These finite statuses are not used in the proof of (4)
and do not quantify over arbitrary poles.

The exploratory proof and reproduction artifacts are in
`scratch/worker-mmtt-case-ix-xi-incidence/overlap-repetition-obstruction-20260902.md`.
