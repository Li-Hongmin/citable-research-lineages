> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two Kempe switches balance the \((4,2,2)\) exterior connector

Let the marked five-pole have the genuine \((4,2,2)\) quotient of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md): cyclic shore \(C\), forks \(w_1,w_2\) with marks \(a,b\) and \(c,d\), central vertex \(u\), edge \(h=uv_h\), and the internal mark \(e\) in \(C\). Assume complete exact Case-XII BF support with allowed five-cycle \(S\) and forbidden complement \(T\), as in [Máčajová--Mazzuoccolo--Tabarelli, Figure 7 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

**Theorem.** In *every actual* \(S\)--\(T\) six-matching row, both complementary three-matching half-loads use every edge of the exterior connector exactly once:
\[
\boxed{A(f)=B(f)=1\quad
\text{for }f\in\{h,uw_1,uw_2,pw_1,qw_1,cw_2,dw_2\}.}       \tag{1}
\]
The same holds for the four half-edges from \(t_p,t_q,t_c,t_d\) into \(C\), by cubicity at those subdivision vertices. No assumption on the deletion matching \(F[C]-v_h\), the order of \(C\), or the identity of the two triple matchings is needed. This eliminates both formal zero-\(h\) seed profiles of [Note 199](199-two-formal-zero-h-loads-for-the-de-pc-seed.md), as well as zero-\(h\) carriers in the other \(T\) columns. It does not synchronize the full matching masks of different carriers.

**Placement corollary.** If such a pole exists, then, after relabelling the fork marks, its allowed cycle must be form III of (2):
\[
\boxed{S=p-c-q-d-e-p,\quad pq,cd\in T,\quad H=I_q=I_c=E=1.}   \tag{1a}
\]
The corollary is proved after the connector theorem; it excludes the other two relative placements but does not establish existence in form III.

**Proof.** Let \(A\) be the \(S\)-half and \(B\) the \(T\)-half of an actual row. By [Note 055](055-half-load-column-saturation-and-case-xii-compression.md), the *same full load* \(A\) has decompositions at every state of \(S\), and none at a state of \(T\): any latter decomposition combined with the fixed \(T\)-decomposition of \(B\) would be a forbidden \(T\)-loop or \(T\)--\(T\) row. [Note 197](197-a-saturated-s-carrier-cannot-double-the-h-edge-in-the-422-profile.md) gives \(A(h)\le1\). Suppose that \(A(h)=0\). Then its load at \(u\) is \((0,2,1)\) or \((0,1,2)\), in the order \((h,uw_1,uw_2)\).

Relabel the two forks and their marks so that \(de\in S\), and call the first-fork marks \(p,q\). Up to exchanging \(p,q\), the five-cycle has exactly three forms:
\[
\begin{array}{c|l|c|c|c}
 &S&\ell&k_d&k_\ell\\\hline
\mathrm I&p-q-c-e-d-p&c&p&q\\
\mathrm {II}&p-q-c-d-e-p&p&c&q\\
\mathrm {III}&p-c-q-d-e-p&p&q&c.
\end{array}                                                       \tag{2}
\]
Here \(\ell\) is \(e\)'s other neighbour on \(S\); \(k_d\) is \(d\)'s other neighbour, and \(k_\ell\) is \(\ell\)'s other neighbour. Decompose the fixed load \(A=X+Y+Z\) at state \(de\), with \(X\) the triple matching, \(Y\) singleton-\(d\), and \(Z\) singleton-\(e\). The triple \(X\) uses \(e\)'s half-edge into \(C\), \(dw_2\), and \(uw_1\). The alternating path from terminal \(d\) in \(X\triangle Y\) must end at \(\ell\); otherwise switching it changes state \(de\) to a forbidden \(T\)-state. This is the unique second neighbour of \(e\) in \(S\). Let \(X'\) be the resulting triple matching at state \(e\ell\). In each case below this \(d\)--\(\ell\) path is wholly outside \(C\), so \(X'\) and \(X\) have **identical edges on the entire cyclic shore**, including the selected half of the internal mark \(e\).

The possible exterior loads and the forced uses by \(Y,Z\) are as follows. A parenthesized pair lists the edge at \(u\) and the other fork edge used by that matching; \(m\) is either \(p\) or \(q\), and \(n\) is the other mark.
\[
\begin{array}{c|c|c|c|c}
\text{form}&A|_u&Y&Z&d\text{--}\ell\text{ path in }X\triangle Y\\\hline
\mathrm I&(0,2,1)&(uw_1,cw_2)&(uw_2,mw_1)&d-w_2-c\\
\mathrm {II,III}&(0,2,1)&(uw_2,pw_1)&(uw_1,cw_2)&d-w_2-u-w_1-p\\
\mathrm {II,III}&(0,1,2)&(uw_2,pw_1)&(uw_2,qw_1)&d-w_2-u-w_1-p.
\end{array}                                                       \tag{3}
\]
To verify that the table exhausts the options: in form I the \(ec,ed\) triple states force both \(cw_2,dw_2\), so \(A(uw_2)=1\) and \(w_1\) has twice \(uw_1\) plus one mark \(m\). If \(Y\) used \(uw_2,mw_1\), the exterior path from \(d\) would end at \(m\), giving \(em\in T\). In forms II and III, \(ep\in S\). If \(A(uw_1)=2\), this forces \(pw_1\) as the only first-fork mark; \(qc\in S\), with \(qw_1\) absent, then forces \(cw_2\), while \(de\) forces \(dw_2\). Thus \(w_2\) has all three edges once. The route \(Y=(uw_1,cw_2)\) would give \(ce\in T\), leaving the middle line. If \(A(uw_2)=2\), \(dw_2\) is the only second-fork mark, and \(ep,qc\in S\) force \(pw_1,qw_1\) respectively. The route of \(Y\) through \(qw_1\) would give \(eq\in T\), leaving the final line. Every listed switch is along an explicit exterior alternating terminal path; it does not change an edge of \(C\).

Now compare \(X\triangle Z\) and \(X'\triangle Z\). Their restrictions to \(C\) are identical. Each has four alternating path ends on \(C\), so that restriction gives a fixed pairing of four *ports* (even if two ports meet the same core vertex). Write \(r\mapsto s\) when the exterior of the symmetric difference connects terminal \(r\) to port \(s\) on \(C\). Write \(e\) for the particular \(e\)-half used by \(X\). Directly tracing the edges in (3) gives:
\[
\begin{array}{c|l|l}
\text{line of (3)}&X\triangle Z\text{ exterior}&X'\triangle Z\text{ exterior}\\\hline
1&m\mapsto d,\ n\mapsto n,\ c\mapsto c,\ e\mapsto e
 &m\mapsto c,\ n\mapsto n,\ d\mapsto d,\ e\mapsto e\\
2&c\mapsto d,\ p\mapsto p,\ q\mapsto q,\ e\mapsto e
 &c\mapsto p,\ q\mapsto q,\ d\mapsto d,\ e\mapsto e\\
3&q\mapsto d,\ p\mapsto p,\ c\mapsto c,\ e\mapsto e
 &q\mapsto p,\ d\mapsto d,\ c\mapsto c,\ e\mapsto e.
\end{array}                                                       \tag{4}
\]
For example, line 2 begins with the exterior segment \(c-w_2-d\) in \(X\triangle Z\), while after the \(d\)--\(p\) switch it becomes \(c-w_2-u-w_1-p\). All unlisted path pieces lie inside \(C\), where the two symmetric differences agree.

The path from singleton terminal \(e\) in \(X\triangle Z\) must end at \(k_d\): its switch changes state \(de\) to \(d k_d\in S\). Similarly the \(e\)-path in \(X'\triangle Z\) must end at \(k_\ell\), since its switch changes \(e\ell\) to \(\ell k_\ell\in S\). Reading these required terminal partners through (2) and (4), the fixed shore pairing would have to pair its \(e\)-port as follows:
\[
\begin{array}{c|c|c}
\text{form and exterior profile}&\text{before }d\text{--}\ell\text{ switch}&\text{after }d\text{--}\ell\text{ switch}\\\hline
\mathrm I,\ m=p&e\leftrightarrow d&e\leftrightarrow q\\
\mathrm I,\ m=q&e\leftrightarrow p&e\leftrightarrow c\\
\mathrm {II},\ (0,2,1)&e\leftrightarrow d&e\leftrightarrow q\\
\mathrm {II},\ (0,1,2)&e\leftrightarrow c&e\leftrightarrow p\\
\mathrm {III},\ (0,2,1)&e\leftrightarrow q&e\leftrightarrow p\\
\mathrm {III},\ (0,1,2)&e\leftrightarrow d&e\leftrightarrow c.
\end{array}                                                       \tag{5}
\]
In every row the two demanded partners differ, although the shore pairing is exactly the same. This contradiction excludes \(A(h)=0\). Note 197 leaves only \(A(h)=1\), and its load equation at \(u\) then gives \(A(uw_1)=A(uw_2)=1\).

It remains to rule out a doubled mark at either fork. Reuse the \(de\)-decomposition \(X+Y+Z\) and the exterior \(d\)--\(\ell\) switch above. In form I, \(ec,ed\in S\) already make \(cw_2,dw_2,uw_2\) each have load one. If the first fork were unbalanced, it would have one mark \(m\) twice and the other absent. Then \(Y\) cannot use \(uw_2,mw_1\), since its forced \(d\)--\(m\) switch gives \(em\in T\). Hence \(Y=(h,cw_2)\) and \(Z=(uw_2,mw_1)\). The two exterior maps for \(X\triangle Z\) and \(X'\triangle Z\) are exactly line 1 of (4): \(h\) lies in \(Y\), so neither symmetric difference sees it. The first two rows of (5) give the same contradiction.

In forms II and III, \(ep,de\in S\) force positive loads on \(pw_1,dw_2\). If \(w_1\) is unbalanced, it therefore doubles \(pw_1\) and omits \(qw_1\). The \(qc\) state then forces \(cw_2\), so the second fork is balanced. The forbidden \(d\)--\(c\) switch forces \(Y=(uw_2,pw_1)\) and \(Z=(h,cw_2)\). If \(w_2\) is unbalanced instead, it doubles \(dw_2\) and omits \(cw_2\); the \(qc\) state forces \(qw_1\), so the first fork is balanced. Singleton-\(d\) cannot itself use \(dw_2\); its permitted \(d\)--\(p\) switch forces \(Y=(uw_2,pw_1)\) and \(Z=(h,qw_1)\). In both cases the \(d\)--\(p\) path is wholly outside \(C\), and \(X'|_C=X|_C\). Tracing the two unchanged shore matchings gives these forced partners for the \(e\)-port:
\[
\begin{array}{c|c|c|c}
\text{fork with doubled mark}&S&X\triangle Z&X'\triangle Z\\\hline
w_1:p&\mathrm {II}&e\leftrightarrow d&e\leftrightarrow q\\
w_1:p&\mathrm {III}&e\leftrightarrow q&e\leftrightarrow h\\
w_2:d&\mathrm {II}&e\leftrightarrow c&e\leftrightarrow p\\
w_2:d&\mathrm {III}&e\leftrightarrow h&e\leftrightarrow c.
\end{array}                                                       \tag{6}
\]
For direct checking, when \(pw_1\) is doubled the old exterior map is \((p,c,q,e)\mapsto(h,d,q,e)\) and the new one is \((c,d,q,e)\mapsto(h,d,q,e)\). When \(dw_2\) is doubled the old map is \((q,p,c,e)\mapsto(h,p,c,e)\) and the new one is \((q,d,c,e)\mapsto(p,h,c,e)\). In each row of (6) the same shore pairing would give \(e\) two different partners, impossible. Thus neither fork is unbalanced. Since its \(u\)-edge already has load one, both of its marked edges also have load one. Complementing loads to two gives (1) for \(B\) as well. At each outer marked subdivision vertex, terminal load and fork-side load are both one, so the shore-side half-edge load is one. \(\square\)

## The one surviving placement

With (1) established, revisit the \(de\)-decomposition \(X+Y+Z\). In form I, \(Y\) cannot use \(uw_2\): the forced exterior \(d\)--\(m\) path would give \(em\in T\). Thus \(Y=(h,cw_2)\) and \(Z=(uw_2,mw_1)\), even though the two first-fork marks now each have load one. The old and new exterior maps for \(X\triangle Z\) are still line 1 of (4). The first two rows of (5) therefore exclude form I outright.

In forms II and III, all seven connector edges have load one. The singleton-\(d\) matching cannot use \(h\), since then it uses \(cw_2\) and the exterior \(d\)--\(c\) switch gives \(ce\in T\). It must use \(uw_2,pw_1\); the remaining singleton-\(e\) matching \(Z\) uses \(h,qw_1,cw_2\). Switch \(X,Y\) on the exterior \(d-w_2-u-w_1-p\) path, obtaining \(X'\) with the same shore mask as \(X\). The two exterior terminal-to-shore maps are
\[
\begin{array}{c|l}
X\triangle Z&q\mapsto h,\ c\mapsto d,\ p\mapsto p,\ e\mapsto e\\
X'\triangle Z&q\mapsto p,\ c\mapsto h,\ d\mapsto d,\ e\mapsto e.
\end{array}                                                       \tag{7}
\]
In form II, \(k_d=c\) and \(k_p=q\). Thus the fixed shore pairing must send its \(e\)-port to \(d\) before the switch and to \(p\) after it, impossible. In form III, \(k_d=q\) and \(k_p=c\); both requirements send the \(e\)-port to \(h\). This proves that only form III survives.

In form III the required \(e\leftrightarrow h\) shore pairing makes the alternating \(e\)--\(q\) path in \(X\triangle Z\) pass through \(h\). Switching that path gives another actual decomposition of the same \(A\)-load at state \(dq\in S\), whose **triple matching uses \(h\)**. By Note 194's triple-matching bijection, its restriction to \(F[C]\) is a perfect matching after deleting \(v_h\), so \(H=1\).

The remaining deletion indicators in (1a) follow from actual required disjoint rows. Since \(de\in S\) and \(pq\in T\), [Note 198](198-the-de-ab-disjoint-row-fixes-its-fork-owner-and-splits-the-h-load.md) forces the \(pq\)-triple to select \(q\)'s \(C\)-endpoint, hence \(I_q=1\). Swapping the forks and applying the same result to \((ep)(cd)\) forces the \(cd\)-triple to select \(c\)'s \(C\)-endpoint, hence \(I_c=1\). The actual \(de\)-triple already gives \(E=1\). These deductions use complete matching rows, not the single-state support formula alone. This completes the proof of (1a). \(\square\)

The argument controls the **full matching identities inside one carrier**: \(X\) and \(X'\) are the same matching on \(C\), while \(Z\) is retained. Every \(S\)--\(T\) carrier now has the same unit load on all exterior proper edges except the two halves of the internal mark \(e\). Only loads within \(C\) and those two \(e\)-halves can differ between carriers. This still does not identify a matching shared by two different \(T\)-column carriers; their cyclic-shore masks remain the actual cross-column closure problem. In fact the proof only needs a nonempty half-load state set \(\mathcal R(A)\subseteq S\); the actual \(T\)-half is used to establish that inclusion.
