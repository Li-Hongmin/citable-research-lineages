> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Balanced boundary signatures for cubic six-poles

Let (H) be a cubic six-pole admitting a six-matching certificate with every object load (2). Then (H) admits such a certificate in which every matching uses exactly two semiedges.

Proof: choose a certificate minimizing (sum_i(d_i-2)^2), where (d_i) is the number of semiedges in matching (i). Each (d_i) is even and (sum_i d_i=12). If some (d_i\ge4), another (d_j=0). In the two-colour subgraph for (i,j), an (i)-to-(i) alternating path exists; swapping colors on it changes ((d_i,d_j)) to ((d_i-2,d_j+2)) and strictly lowers the potential, a contradiction.

Thus every nonempty actual boundary relation contains a balanced signature. This is a normalization result only: balanced signatures on two shores need not have a common boundary pairing, so it does not by itself close the cyclic-six-cut branch.
