> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The indirect \(e\,ab:b\) and \(e\,bc:b\) prism root pair is impossible

Keep the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\) and marks \(AC,Cc,bc,ab\). Suppose an actual BF row has the forbidden zero-port triple \(P:e\,ab:b\) and the allowed zero-port triple \(R:e\,bc:b\). Assume complete exact Case-XII support with \(e\,ab,e\,Cc\in T\). The shore order, cycle rank and port-path lengths are arbitrary.

> **Indirect-pair exclusion.** Such a row does not exist for either allowed pentagon \(S_{ab}=e-AC-ab-Cc-bc-e\) or \(S_{Cc}=e-AC-Cc-ab-bc-e\). This excludes one indirect forbidden-root pair beyond [Note 404's direct-root theorem](404-a-direct-forbidden-prism-root-cannot-enter-any-mixed-e-row.md); the other indirect pairs remain open.

**Proof.** The two triples have the same exterior rooted-tree mask \((A,C,a,B,c)\); their marked masks differ only by \(P:ab:b\) and \(R:bc:b\). Let \(K\) be the singleton-\(bc\) occurrence. The \(bc\)-starting path of \(R\triangle K\) enters \(b\). If \(K\) takes \(ab:b\), it ends at \(ab\) and gives the forbidden \([e\,ab]\) loop. Thus \(K\) takes \(bu_4\), reaches \(B\), and takes \(Bu_1\) or \(Bu_2\). The \(Bu_1\) route can end at allowed \(AC\) only through \(AC:A\): its other branches end at forbidden \(ab,Cc\). But then \(P,R\) saturate both \(Cu_2\) and \(cu_5\), forcing \(K\) to take both \(Cc:C\) and \(Cc:c\), impossible at the same subdivision. Therefore \(K\) takes \(Bu_2\), reaches \(C\), and takes \(AC:C\), since \(Cc:C\) would end at forbidden \(Cc\).

The remaining saturated vertices and marked subdivisions fix
\[
K:(u_1,u_2,u_3,u_4,u_5)=(p_1,B,A,b,p_5),\qquad
(AC,Cc,bc,ab)=(C,c,s,a).                               \tag{1}
\]
The exterior \(bc\)--\(AC\) switch makes \(R':e\,AC:C\) with the same shore matching as \(R\), leaving \(P\) unchanged. Name the singleton-\(ab\) occurrence \(J\), and the two singleton-\(e\) occurrences \(D,E\). At \(a\), \(P,R\) saturate \(au_3\), while \(K\) takes \(ab:a\); hence \(J\), which takes the \(ab\) terminal, must use \(au_5\). At \(b\), \(P:ab:b,R:bc:b,K:bu_4\) leave just two choices for \(J\).

If \(J\) takes \(bc:b\), then \(J\) uses \(Cc:c,AC:C\). The load-two equations on the four marked subdivisions force one singleton-\(e\), call it \(E\), to have mark mask
\[
E:(AC,Cc,bc,ab)=(A,C,c,b).                         \tag{2}
\]
The same equations force \(E\) to use \(Bu_1,au_5\), hence ports \(p_2,p_3,p_4\). Tracing the three exterior arms against \(R\) gives \(AC\leftrightarrow p_4\), \(Cc\leftrightarrow p_2\), \(ab\leftrightarrow p_3\); against \(R'\) it gives \(Cc\leftrightarrow p_2\), \(bc\leftrightarrow p_3\), \(ab\leftrightarrow p_4\). The shore \(e\)-path against \(E\) has one fixed endpoint \(q\). In \(S_{ab}\), negative support requires \(q=p_2\) against \(R:e\,bc\) and \(q=p_4\) against \(R':e\,AC\). In \(S_{Cc}\), it requires \(q=p_3\) and \(q=p_2\), respectively. Both are impossible.

If \(J\) takes \(bu_4\), it must use \(bc:c,Cc:C,AC:A\). The marked load equations now distinguish the singleton-\(e\) occurrence \(D\) with mask \((A,C,c,b)\) from the occurrence \(E\) with mask \((C,c,b,a)\). They also force \(D:au_5\), \(E:p_5\), while each of \(D,E\) covers \(B\) through \(Bu_1\) or \(Bu_2\). Against \(R\), the \(Cc\)-arm of \(E\) is always \(Cc-t_{Cc}-c-u_5-p_5\). Against \(R'\), its \(ab\)-arm ends at \(p_2\) if \(E\) takes \(Bu_1\), and at \(p_1\) if it takes \(Bu_2\). Thus \(S_{ab}\) would require the same shore \(e\)-path to end at \(p_5\) against \(R\) and at \(p_2\) or \(p_1\) against \(R'\), impossible. For \(S_{Cc}\), use \(D\): its \(ab\)-arm against \(R\) ends at \(p_3\), while its \(Cc\)-arm against \(R'\) ends at \(p_2\) or \(p_1\) according as \(D\) takes \(Bu_1\) or \(Bu_2\). The required common shore endpoint again cannot exist. Every comparison switches two complete perfect matchings and leaves \(P:e\,ab\in T\) untouched, so a wrong endpoint produces a genuine forbidden double-\(T\) BF row. \(\square\)

Consequently, an exact-Case-XII mixed row containing an \(e\,ab\) triple cannot pair it with \(e\,bc:b\): the direct \(ab:a\) root is excluded by Note 404, and the indirect \(ab:b\) root by this theorem. The allowed root \(e\,bc:c\), and mixed rows using \(e\,AC\), still require analysis; this note is not an exclusion of the entire prism profile. The proof is hand-derived and awaits independent review.
