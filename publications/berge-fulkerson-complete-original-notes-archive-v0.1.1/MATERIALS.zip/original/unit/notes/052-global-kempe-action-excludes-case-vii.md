> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case VII

This note applies the stabilizer-complete global component-switch closure of
Notes 048--051 to the 34-type exact five-cut support
(H_{\\mathrm{VII}}) in the Mácajová--Mazzuoccolo--Tabarelli (MMT)
Appendix. The statement is conditional on that transcription and ordered
semiedge convention.

## Statement

The greatest fixed point of the necessary global Kempe-action system has
[
\\mathscr S_\\infty([14])
=
\\mathscr S_\\infty([35])
=\\varnothing.
]
Since both loop types occur in (H_{\\mathrm{VII}}), no real cubic
5-pole has complete BF support exactly (H_{\\mathrm{VII}}).

Together with Notes 046, 048, 049 and 051, this conditionally excludes Cases
I, II, III, V, VI, VII and XIII from the MMT 13-case list. Case IV is a
strict closure of this action method (Note 050); Cases VIII--XII and the
cyclically-6-connected branch remain open.

## Fixed-point certificate

A state records all nonempty two-colour boundary path pairings of one
labelled BF-colouring. Switching one component preserves the route of the
switched pair and every route for a disjoint colour pair. No persistence is
imposed for overlapping pairs, and internal alternating cycles are omitted,
so the finite system over-approximates the actual colouring action. Every
colour relabelling to a target representative is retained, including target
stabilizers.

For (H_{\\mathrm{VII}}), the system has
[
|H_{\\mathrm{VII}}|=34,qquad
|\\mathscr S_0|=726,qquad
N_{\\mathrm{switch}}=14520.
]
The greatest-fixed-point deletion totals are (418,4,10) over three rounds.
The final surviving total is 294, but the fibres over ([14]) and ([35])
are empty.

The short obstruction for ([14]) is
[
[14]#24
\\xrightarrow[\\text{boundary path }25]{04}
(13)(14)#\\{2,5,8,11\\}.
]
The two canonical target maps give exactly these four candidates; each is
deleted in round one because its (15)-switch on path (25) would require a
target in ([13]), and all eight target stabilizer maps have no such state.
Thus the supported ([14]) fibre disappears at round two.

An exact-support pole would yield a nonempty post-fixed family and hence a
surviving state for every supported type, contradicting this empty fibre.

## Scope and certificate

This result is a boundary-action exclusion only. It does not address Cases
IV, VIII, IX, X, XI or XII, and it does not address cyclically-6-connected
graphs. The stabilizer-complete certificate is

../scratch/worker-mmtt-case-vii-global-action/verify_case_vii_global_kempe_action.py

and ends with
CASE_VII_GLOBAL_KEMPE_ACTION_EXCLUDED.
