> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The near-end path \(AE\) neighbour overloads the \((ea)(ed)\) row

Use the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile and path-tree marking of [Notes 267–268](268-the-near-end-path-ce-neighbour-overloads-the-eb-row.md):
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\quad h_i=u_i\Sigma,
\qquad a:B\!:\!\Sigma,\quad b:AD,\quad c:AE,\quad d:CE. \tag{1}
\]
The odd shore \(\Sigma\) has arbitrary order and unmarked cycle rank. Suppose \(ea,ec\in S\), so \(ed\in T\).

**Theorem.** No pole with (1) and \(ea,ec\in S\) has complete exact-Case-XII perfect-matching support. Every pure-\(S\) state-\(ea\) half forces its singleton-\(e\) exterior to use both \(d:C\) and \(2B\). Exchanging the two complete singleton-\(e\) matchings in the required real \((ea)(ed)\) row then saturates those edges, while its opposite state-\(ed\) zero-port triple must use \(2B\). Together with Notes 267–268, this excludes the *entire* near-end path-tree marking (1), at every shore order and rank.

## Two pure-half exterior masks

The state-\(ea\) zero-port triple has the unique exterior
\[
X_a=\{a:B,1A,2C,3D,4E\}.                           \tag{2}
\]
Purity forces the \(a\)-terminal path in \(X_a\triangle Y_a\) to end at \(c\), the other allowed neighbour of \(e\). The path stays exterior by [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). Ending at \(c:E\) would force \(2B,3C,4D,c:E\), leaving \(b:AD\) without an endpoint. Thus it ends at \(c:A\). Switching this path gives the state-\(ec\) zero-port triple
\[
X_c=\{c:A,1B,2C,3D,4E\},                           \tag{3}
\]
with exactly the same *complete shore matching* as \(X_a\).

Let \(Z_e\) be the singleton-\(e\) matching in a pure \(ea\) half. The fixed shore \(e\)-path must reach \(b,d\) in opposite order against \((X_a,X_c)\). The nonterminal cross-mark halves of \(Z_e\) have only four disjoint orientations, already classified in [Note 267](267-the-near-end-path-marking-excludes-the-ad-neighbour.md):
\[
I=(b:A,c:E,d:C),\quad II=(b:D,c:A,d:C),\quad
III=(b:D,c:A,d:E),\quad IV=(b:D,c:E,d:C).            \tag{4}
\]
The table checks all 16 exterior masks. In each row, the last two columns give the endpoint pair against \((X_a,X_c)\) at the port reached by \(b\) or \(d\), respectively, against \(X_a\). A row with “or” covers the two indicated choices of the remaining \(K\)-edge; their listed endpoint pairs agree.

| Cross halves | \(a\)-half | Other \(K\)-edges | \(b\)-port pair | \(d\)-port pair |
|---|---|---|---|---|
| I | \(B\) | \(3D\) or \(4D\) | \(h_1:(b,a)\) | \(h_2:(d,d)\) |
| I | \(\Sigma\) | \(1B,3D\) or \(1B,4D\) | \(a:\Sigma:(b,a)\) | \(h_2:(d,d)\) |
| I | \(\Sigma\) | \(2B,3D\) or \(2B,4D\) | \(h_1:(b,d)\) | \(a:\Sigma:(d,a)\) |
| II | \(B\) | \(4E\) | \(h_3:(b,b)\) | \(h_2:(d,d)\) |
| II | \(\Sigma\) | \(1B,4E\) | \(h_3:(b,b)\) | \(h_2:(d,d)\) |
| II | \(\Sigma\) | \(2B,4E\) | \(h_3:(b,b)\) | \(a:\Sigma:(d,a)\) |
| III | \(B\) | \(2C\) | \(h_3:(b,b)\) | \(h_4:(d,d)\) |
| III | \(B\) | \(3C\) | \(h_2:(b,b)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(1B,2C\) | \(h_3:(b,b)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(1B,3C\) | \(h_2:(b,b)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(2B,3C\) | \(a:\Sigma:(b,a)\) | \(h_4:(d,d)\) |
| IV | \(B\) | \(1A\) | \(h_3:(b,b)\) | \(h_2:(d,d)\) |
| IV | \(\Sigma\) | \(1A,2B\) | \(h_3:(b,b)\) | \(a:\Sigma:(d,a)\) |

Only the third row gives the required \((b,d)\) at one shore port. Its two complete exterior masks are
\[
\begin{aligned}
Z_3&=\{a:\Sigma,b:A,c:E,d:C,2B,3D,h_1,h_4\},\\
Z_4&=\{a:\Sigma,b:A,c:E,d:C,2B,4D,h_1,h_3\}.
\end{aligned}                                               \tag{5}
\]
For either mask, \(h_1\) reaches \(b\) against (2) along \(u_1-A-t_b\), but reaches \(d\) against (3) along \(u_1-B-u_2-C-t_d\). This directly verifies the only surviving endpoint exchange. In particular, **every** pure-\(S\) state-\(ea\) half uses \(d:C\) and \(2B\) in its singleton-\(e\) occurrence.

## The required cross-row overload

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ed)\) row, since \(ea\in S\) and \(ed\in T\). Its \(ea\) half is pure \(S\), so its singleton-\(e\) matching \(Z_e\) has one of (5). The opposite state-\(ed\) half has another singleton-\(e\) matching \(W_e\). Exchange these **complete** singleton occurrences. This preserves the six-matching edge load and the opposite \(T\)-state; hence the new \(ea\) half is also pure \(S\), and \(W_e\) likewise has one of (5). Therefore \(Z_e,W_e\) already load \(d:C\) and \(2B\) twice each, regardless of whether they use the same choice in (5).

The opposite state-\(ed\) triple has boundary \(\{a,b,c\}\), so mark \(d=CE\) is nonterminal. It cannot use \(d:C\), now saturated, and must use \(d:E\). By [Note 230's zero-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), its exterior contains the unique matching of \(K-E\), namely \(\{1A,2B,3C,4D\}\). This supplies a third use of \(2B\), contradicting edge load two. \(\square\)

By Notes 267–269, the only \(|U|=r=4\) path-tree marking not yet excluded is the central shore mark \(a:C-\Sigma\) with cross marks \(AD,AE,BE\). Larger barriers, the other Tutte profiles, and Berge–Fulkerson remain open. The route table is hand-derived and awaits independent checking.
