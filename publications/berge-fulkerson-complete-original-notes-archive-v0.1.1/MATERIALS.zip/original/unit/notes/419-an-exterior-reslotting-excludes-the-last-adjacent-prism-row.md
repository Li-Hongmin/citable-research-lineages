> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exterior reslotting excludes the last adjacent-prism row

Use the two-spoke triangular-prism exterior and the terminal order of [Notes 415](415-the-adjacent-bc-cc-second-direct-root-has-one-real-exterior-boundary.md) and [418](418-the-surviving-prism-row-has-a-sharp-k-e-path-condition.md). Let the forbidden \(e\)-labels be \(\{bc,Cc\}\), and let the allowed pentagon be
\[
S=e-ab-bc-Cc-AC-e.
\]
Suppose an actual \((e\,bc)(e\,ab)\) BF row has the sole exterior table (5) of Note 415. Its forbidden triple is \(P=e\,bc:c\), its allowed triple is \(R=e\,ab:a\), and its singleton occurrences are \(K=ab\), \(J=bc\), and \(E,F=e\). The shore is arbitrary: no order, rank, path-length, girth, or connectivity condition is assumed.

> **Last-table exclusion.** This row cannot belong to an exact Case-XII perfect-matching closure. Together with the root exclusions of Notes 414–417, neither pentagon orientation with forbidden \(e\)-pair \(\{bc,Cc\}\) occurs on this marked two-spoke-prism exterior, at any shore order.

**First switch.** Exact support requires the \(e\)-terminal path of \(R\triangle E\) to end at \(bc\). Indeed, its other endpoints \(AC,Cc\) would change the allowed state \(e\,ab\) to \(ab\,AC\) or \(ab\,Cc\), both outside \(S\), while leaving the forbidden \(P=e\,bc\) unchanged. In table (5), the \(bc\)-arm of \(R\triangle E\) exits the exterior at \(p_1\). Thus the shore part of that path joins \(e\) to \(p_1\). Switch this **complete** path between \(R,E\), obtaining a triple \(H\) of state \(ab\,bc\) and a singleton-\(bc\) occurrence. The shore restriction of \(H\) now uses ports \(e,p_1\). Its exterior mask is
\[
\begin{array}{c|ccccc|cccc}
 &u_1&u_2&u_3&u_4&u_5&AC&Cc&bc&ab\\\hline
H&p_1&C&A&B&c&s&s&b&a.
\end{array}                                                    \tag{1}
\]
The original \(P,K,J\) remain unchanged, so \(P=e\,bc\) is still a forbidden triple in this actual BF row.

**Two opposite endpoint demands.** The singleton-\(ab\) exterior of \(K\) and the singleton-\(bc\) exterior of \(J\) each use proper shore ports \(p_4,p_5\). Direct tracing against (1) gives
\[
\begin{array}{c|ccc}
 &\text{starting arm}&\text{other arm}&\text{other arm}\\\hline
H\triangle K&ab\,p_1&AC\,p_4&Cc\,p_5\\
H\triangle J&bc\,p_1&AC\,p_4&Cc\,p_5.
\end{array}                                                    \tag{2}
\]
For example, the first arm is \(ab-t_{ab}-a-u_3-A-u_1-p_1\) against \(K\), and \(bc-t_{bc}-b-t_{ab}-a-u_3-A-u_1-p_1\) against \(J\). In both comparisons, \(AC\,p_4\) follows \(AC-t_{AC}-C-u_2-B-u_4-p_4\), and \(Cc\,p_5\) follows \(Cc-t_{Cc}-c-u_5-p_5\). The remaining differing shore ports are \(e,p_1,p_4,p_5\).

Switching the \(ab\)-starting path of \(H\triangle K\) must keep \(H\)'s new state in \(S\), because \(P\) is still outside \(S\). Its possible new missing pairs are \(bc\,e\), \(bc\,AC\), and \(bc\,Cc\); only \(bc\,Cc\) belongs to \(S\). Hence the shore path from \(p_1\) must reach \(p_5\). Likewise, switching the \(bc\)-starting path of \(H\triangle J\) can give \(ab\,e\), \(ab\,AC\), or \(ab\,Cc\); only \(ab\,e\) belongs to \(S\). Hence for the \(J\) comparison the shore path from \(p_1\) must reach \(e\). These endpoint requirements use the published Case-XII exclusion of every \(T\)--\(T\) BF type, not an assumed connectivity property of the shore.

**Reslotting contradiction.** The exterior symmetric difference of the original \(K,J\) is the wholly exterior terminal path
\[
ab-t_{ab}-b-t_{bc}-bc.                                   \tag{3}
\]
Switching (3) between these two complete matching occurrences exchanges which of their **unchanged shore masks** carries the singleton-\(ab\) exterior and which carries the singleton-\(bc\) exterior. It does not touch \(P,R,E\), so the first switch still produces the same complete \(H\). Fix either shore mask \(U\) of the original \(K,J\) pair. In one actual BF row it carries the \(K\) exterior, so (2) forces \(p_1p_5\) in the shore pairing of \(H|_Z\triangle U\). After (3) it carries the \(J\) exterior, so the same shore pairing must contain \(p_1e\). A pairing cannot give two partners to \(p_1\). This contradicts exact support and proves the last-table exclusion. \(\square\)

For a direct check on [Note 418's second 21-vertex row](418-the-surviving-prism-row-has-a-sharp-k-e-path-condition.md), the first switch leaves \(H|_Z\) with ports \(e,p_1\) and edges \(h_2h_4,h_5h_3\). The unchanged \(K|_Z\) has ports \(p_4,p_5\) and edges \(h_eh_3,h_1h_2\). Their symmetric difference connects \(p_1\) to \(p_4\), so the \(ab\)-starting path in (2) reaches \(AC\). Switching it gives the explicitly forbidden double-\(T\) type \((e\,bc)(bc\,AC)\), already after two complete path switches. Its Petersen-expanded versions inherit this endpoint pairing.

[Notes 414](414-an-adjacent-prism-forbidden-pair-excludes-the-indirect-bc-direct-ab-row.md), [416](416-adjacent-bc-cc-indirect-bc-and-ab-roots-are-impossible.md), and [417](417-adjacent-bc-cc-last-mixed-root-excludes-one-pentagon.md) exclude the other three root pairs of the required \((e\,bc)(e\,ab)\) cell. Note 415 excludes its remaining root pair for the reverse pentagon and forces table (5) for \(S\). Thus the displayed marked exterior has no exact-Case-XII realization for forbidden pair \(\{bc,Cc\}\), without invoking all-odd shore complements, finite order bounds, or a cyclically-five host. Together with [Note 413's](413-two-spoke-prism-exact-case-xii-requires-odd-zero-port-complements.md) two alternating-pair exclusions, this removes three of the six forbidden \(e\)-pairs for this exterior; the three still open here are \(\{AC,Cc\},\{AC,ab\},\{ab,bc\}\). The 21-vertex and Petersen-expanded rows of Note 418 remain genuine rows, but the switches above expose a forbidden double-\(T\) type in their complete closure. The classification inputs and this hand proof await independent review. Other exterior profiles and the full Berge–Fulkerson conjecture remain open; no OMEN or local mathematical recomputation was used.
