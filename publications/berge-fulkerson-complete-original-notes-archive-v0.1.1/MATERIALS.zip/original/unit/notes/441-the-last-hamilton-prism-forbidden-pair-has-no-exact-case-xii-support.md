> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last Hamilton-prism forbidden pair has no exact-Case-XII support

Use the Hamilton two-spoke prism exterior of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
a-u_1-A-u_2-C-u_3-B-u_4-b-u_5-c,\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab),
\]
with proper shore ports \(p_i\) at \(u_i\) and a sixth shore terminal \(e\). Assume complete exact-Case-XII support with forbidden pair \(\{eX,eZ\}\). Its allowed pentagons are
\[
S_1=e-Y-X-Z-W-e,\qquad S_2=e-Y-Z-X-W-e.          \tag{1}
\]
The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine mixed BF row \((eX)(eY)\) and excludes the loop \([eZ]\). For \(S_1\), the map \((e,Y,X,Z,W)=(1,3,5,2,4)\) sends that row to the listed \((13)(15)\) and \([eZ]\) to the absent \([12]\); for \(S_2\), \((e,Y,Z,X,W)=(1,3,5,2,4)\) sends them to the listed \((12)(13)\) and absent \([15]\). We prove that no such row can remain in the exact support, regardless of shore order or topology.

Write the six actual complete matchings as \(P=eX\), \(R=eY\), \(K=Y\), \(J=X\), and \(D_0=D_1=e\), where the equalities name terminal-boundary types only. By the one-internal-mark quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(P,R\) have zero proper shore ports. The \(Y\)-starting component of \(R\triangle K\) is therefore wholly exterior. It must end at \(W\), the other allowed \(e\)-label: an end at \(X\) gives forbidden loop \([eX]\), while an end at \(Z\) gives forbidden row \((eX)(eZ)\), with \(P=eX\) unchanged. Switching yields an actual \(R'=eW\) with **the same complete shore restriction** as \(R\).

There are just three possible tree paths for this switch:
\[
\begin{array}{c|c|l}
R\text{ root}&\text{route}&\text{result}\\ \hline
C&Y-C-u_2-A-u_1-a-W&\alpha\\
C&Y-C-u_3-B-u_4-b-W&\beta\\
c&Y-c-u_5-b-W&\gamma.
\end{array}                                                    \tag{2}
\]
The apparent long \(c\)-root route to \(W:a\) occupies both \(A,B\) with tree halves of \(K\), leaving neither endpoint free for its required \(X\) half-edge. On route \(\beta\), \(K\) must cover \(a\) by \(Z:a\), since \(P,R\) already load \(au_1\) twice; it must then cover \(c\) by \(cu_5\), which \(P,R\) also already load twice. Hence \(\beta\) is impossible.

For any singleton-\(e\) occurrence \(D\), let \(X_R,Z_R\) and \(X_{R'},Z_{R'}\) be the first proper ports reached by the indicated marked terminal arms in the exterior symmetric differences with \(R,R'\). The same shore \(e\)-path is used in both comparisons. To avoid a forbidden type, \(S_1\) requires \(X_R=Z_{R'}\), while \(S_2\) requires \(Z_R=X_{R'}\). In every comparison below, the relevant arms reach proper ports and the third marked arm reaches the remaining proper port, so no exterior port-to-port detour alters these equalities.

## Route \(\gamma\): a first-exit contradiction

Here \(R=eY:c\), \(R'=eW:b\), and \(K\) takes \(Z:a,W:b,cu_5\); \(P,R\) saturate \(au_1\). The mark and vertex quotas among \(J,D_0,D_1\) force a unique member \(M\) with
\[
M:(Y:c,Z:a,W:b),\qquad
\{J,D_0,D_1\}\setminus\{M\}:(Y:C,Z:c,W:a).        \tag{3}
\]
Indeed, \(P,K\) saturate \(cu_5\), \(R,M\) must use \(Y:c\), \(K,M\) use \(Z:a,W:b\), and the other two use \(Z:c,W:a,Y:C\). At \(b\), \(P\) uses \(bu_4\), \(R\) uses \(bu_5\), \(K,M\) use \(W:b\), so the two regular members in (3) split the remaining \(bu_4,bu_5\) slots.

A regular singleton-\(e\) occurrence \(D:(Y:C,Z:c,W:a,bu_5)\) fails **both** orientations. Directly following the alternating arms gives
\[
\begin{array}{c|cc|cc}
D:X&X_R&Z_{R'}&Z_R&X_{R'}\\ \hline
A&p_2&p_1&\{p_3,p_4\}&p_2\\
B&p_4&\{p_1,p_2\}&p_3&p_4.
\end{array}                                                    \tag{4}
\]
The two required columns are disjoint in each orientation. Thus \(M\ne J\): if \(M=J\), one of the two regular \(D_i\) takes \(bu_5\). Now \(M\) is one of the \(D_i\), and the other regular \(D\) must take \(bu_4\). Its exits are
\[
\begin{array}{c|cc|cc}
D:X&X_R&Z_{R'}&Z_R&X_{R'}\\ \hline
A&p_2&p_5&p_5&p_2\\
B&p_5&p_5&p_3&\{p_1,p_2\}.
\end{array}                                                    \tag{5}
\]
Equation (5) excludes \(S_2\); under \(S_1\) it forces \(D:X:B\). But the special singleton-\(e\) occurrence \(M\) then also fails \(S_1\):
\[
\begin{array}{c|cc}
M:X&X_R&Z_{R'}\\ \hline
A&\{p_2,p_3,p_4\}&p_1\\
B&p_4&\{p_1,p_2,p_3\}.
\end{array}                                                    \tag{6}
\]
For example, when \(M:X:B\), its \(X\)-arm against \(R\) exits directly at \(p_4\); its \(Z\)-arm against \(R'\) first follows \(a-u_1\) and can exit only at \(p_1,p_2\), or \(p_3\). Equations (4)–(6) exclude route \(\gamma\) without any shore assumption.

## Route \(\alpha\): three forbidden-loop recompletions

Now \(R=eY:C\), \(R'=eW:a\). The \(Y\to W\) path and the saturated \(au_1,bu_4\) edges force
\[
K:Y;\ X:B,Z:c,W:a,Au_1,Cu_2,bu_5;\ p_3,p_4.       \tag{7}
\]
At \(a,c\), the three remaining occurrences \(J,D_0,D_1\) have exactly one distinguished member \(M:(Y:C,Z:c,W:a,bu_5)\); the other two take \((Y:c,Z:a,W:b)\). If \(M\) is a singleton-\(e\) occurrence, the demanded-exit table is
\[
\begin{array}{c|cc|cc}
M:X&X_R&Z_{R'}&Z_R&X_{R'}\\ \hline
A&p_2&\{p_3,p_4\}&\{p_3,p_4\}&p_1\\
B&p_3&p_4&p_4&p_3.
\end{array}                                                    \tag{8}
\]
So \(M=J\). Both singleton-\(e\) occurrences then take \(Y:c,Z:a,W:b\). The tree-edge quotas at \(A,B,C\) leave only the following three distinct shore-port profiles after relabelling those two occurrences as \(E,F\):
\[
\begin{array}{c|cccc}
&K&J&E&F\\ \hline
C_1&34&23&125&145\\
C_2&34&13&125&245\\
C_3&34&24&135&125.
\end{array}                                                    \tag{9}
\]
Here \(125\) means proper ports \(p_1,p_2,p_5\); \(E,F\) also both select shore terminal \(e\), and \(P,R\) use no shore port. For completeness, if \(P=eX:A\), the two \(E,F\) take \(X:A,X:B\) respectively; the \(X:A\) member uses \(Cu_3,Bu_4\), while the \(X:B\) member chooses \(Au_1\) or \(Au_2\), giving \(C_1,C_2\). If \(P=eX:B\), both \(E,F\) take \(X:A\); one uses \(Cu_3,Bu_4\), and the other takes \(Cu_2\) with \(Bu_3\) or \(Bu_4\), giving \(C_1,C_3\). The remaining halves and ports follow from the selected marks and cubicity.

In all three profiles, keep the six **complete shore restrictions** of the original row. Replace the exterior restrictions of \(P,R\) by the two zero-port triples
\[
\begin{array}{c|c|l|l}
&\text{marked terminals}&\text{marked half}&\text{tree halves}\\ \hline
P=eZ:a&X,Y,W&Z:a&Au_1,Cu_2,Bu_3,bu_4,cu_5\\
R=eZ:c&X,Y,W&Z:c&au_1,Au_2,Cu_3,Bu_4,bu_5.
\end{array}                                                    \tag{10}
\]
The four new singleton exterior masks, with proper ports shown last, are:
\[
\begin{array}{c|c|c|l|l}
&\text{label}&\text{marked terminal}&\text{marked halves; tree halves}&\text{proper ports}\\ \hline
C_1&K&Z&X:B,Y:c,W:a;\ Au_1,Cu_2,bu_5&34\\
&J&Z&X:A,Y:C,W:b;\ au_1,Bu_4,cu_5&23\\
&E&e&X:A,Y:C,Z:c,W:a;\ Bu_3,bu_4&125\\
&F&e&X:B,Y:c,Z:a,W:b;\ Au_2,Cu_3&145\\ \hline
C_2&K&Z&X:B,Y:C,W:b;\ au_1,Au_2,cu_5&34\\
&J&Z&X:A,Y:c,W:a;\ Cu_2,Bu_4,bu_5&13\\
&E&e&X:A,Y:C,Z:c,W:a;\ Bu_3,bu_4&125\\
&F&e&X:B,Y:c,Z:a,W:b;\ Au_1,Cu_3&245\\ \hline
C_3&K&Z&X:B,Y:c,W:a;\ Au_1,Cu_2,bu_5&34\\
&J&Z&X:A,Y:C,W:b;\ au_1,Bu_3,cu_5&24\\
&E&e&X:B,Y:C,Z:c,W:a;\ Au_2,bu_4&135\\
&F&e&X:A,Y:c,Z:a,W:b;\ Cu_3,Bu_4&125.
\end{array}                                                    \tag{11}
\]
The \(e\) entries in the marked-terminal column mean that the terminal lies on the retained shore, not on the exterior. In each row of (11), the proper-port set agrees **label by label** with (9). The six new exterior masks load every exterior edge twice: at \(u_1,\ldots,u_5\), the three incident edge-label pairs \((\text{left half},\text{right half},p_i)\) are
\[
\begin{array}{c|ccccc}
C_1&(RJ,PK,EF)&(RF,PK,JE)&(RF,PE,KJ)&(RJ,PE,KF)&(RK,PJ,EF)\\
C_2&(RK,PF,JE)&(RK,PJ,EF)&(RF,PE,KJ)&(RJ,PE,KF)&(RJ,PK,EF)\\
C_3&(RJ,PK,EF)&(RE,PK,JF)&(RF,PJ,KE)&(RF,PE,KJ)&(RK,PJ,EF).
\end{array}                                                    \tag{12}
\]
The marked subdivision pairs are likewise partitions of \(\{P,R,K,J,E,F\}\): \(Z\)'s terminal pair is \(KJ\), and the \(X,Y,W\) terminal pairs are \(PR\); their half-edge pairs follow directly from (10)–(11). The same check at the six original prism vertices confirms each label covers one incident edge. Thus (10)–(11), glued to the unchanged shore matchings, give a genuine BF loop \([eZ]\) in every profile. This contradicts exact Case XII and excludes route \(\alpha\).

Routes \(\alpha,\beta,\gamma\) exhaust the required \((eX)(eY)\) row, and each is excluded. Therefore the Hamilton two-spoke prism exterior cannot have exact-Case-XII support with \(\{eX,eZ\}\) forbidden. Together with [Notes 431](431-the-hamilton-prism-excludes-the-ab-cc-forbidden-pair.md), [432](432-the-hamilton-prism-excludes-the-cc-ab-forbidden-pair.md), [435](435-the-last-clean-hamilton-prism-forbidden-pair-has-no-case-xii-row.md), [439](439-both-hamilton-cc-ac-row-masks-recomplete-to-the-forbidden-ey-loop.md), and [440](440-the-surviving-hamilton-x-w-rows-all-recomplete-to-forbidden-support.md), this conditionally excludes **all six** forbidden pairs for the Hamilton marked exterior. [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md) proves that the two-spoke prism has exactly three spanning-tree orbits; [Notes 423](423-no-exact-case-xii-pole-has-the-marked-two-spoke-prism-exterior.md) and [429](429-no-exact-case-xii-pole-has-the-other-marked-two-spoke-prism-exterior.md) exclude the other two. Thus the combined hand-proof chain conditionally excludes **every two-spoke prism spanning-tree exterior** from exact Case XII. Other exterior profiles and Berge–Fulkerson remain open. This proof is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
