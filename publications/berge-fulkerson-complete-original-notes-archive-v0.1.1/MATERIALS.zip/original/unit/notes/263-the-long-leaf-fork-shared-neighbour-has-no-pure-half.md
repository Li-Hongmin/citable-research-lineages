> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The long-leaf fork shared-neighbour has no pure half

Retain the complete exact-Case-XII, minimum-host, one-internal-mark five-cut profile and the \(|U|=4,r=4\) fork tree of [Note 262](262-the-short-leaf-fork-shared-neighbour-has-no-pure-half.md):
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\qquad h_i=u_i\Sigma.
\]
Now put the shore mark at the long leaf \(R\), and take
\[
a:R\!:\!\Sigma,\qquad b:QR,\qquad c:LP,\qquad d:PQ. \tag{1}
\]
Let \(e\) be the internal shore mark and suppose its two allowed neighbours are \(a,b\). The odd shore \(\Sigma\) has arbitrary order and unmarked cycle rank.

**Theorem.** No rooted cubic five-pole with (1) has complete exact-Case-XII BF support. The required real \((ea)(ab)\) row forces a short exterior \(a\)--\(b\) triple switch at \(R\). Every singleton-\(e\) exterior compatible with that switch either preserves the \(c,d\) routes or changes a route involving terminal \(b\); none exchanges \(c,d\) as purity requires. This excludes the shared-endpoint \(e\)-neighbour choice of the long-leaf fork marking at every shore order. Together with Note 262, both fork leaf placements have this particular neighbour choice excluded; their other choices and the path tree remain open.

## The zero-port triples

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains \((ea)(ab)\). As \(ab\in T\), its \(ea\) half \(X_a+Y_a+Z_e\) must be pure \(S\). [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes \(X_a\) zero-port. Deleting \(R\) from the exterior tree gives its unique mask
\[
X_a|_{\rm ext}=\{a:R,1P,2Q,3O,4L\}.                 \tag{2}
\]
The \(a\)--\(b\) path of \(X_a\triangle Y_a\) stays outside \(\Sigma\) by [Note 244's argument](244-every-shore-mark-must-neighbour-the-internal-mark.md). Its only paths to the two endpoints of \(b=QR\) are the direct \(a-t_a-R-t_b-b\) path and the tree route \(R-u_4-L-u_3-O-u_2-Q\). The latter makes \(Y_a\) occupy \(L,Q\). Then \(c=LP\) must use \(P\), leaving neither endpoint of \(d=PQ\) available. Therefore the direct path is forced, and switching it produces a state-\(eb\) zero-port triple with exactly the same shore and \(K\)-masks:
\[
X_b|_{\rm ext}=\{b:R,1P,2Q,3O,4L\}.                 \tag{3}
\]
Purity would require the shore \(e\)-path against (2) and (3) to end at \(c,d\) in opposite order, for either pentagon with neighbours \(a,b\) at \(e\).

## All singleton-\(e\) exteriors fail the endpoint swap

If \(Z_e\) uses \(b:R\), it must use \(a:\Sigma\). The edge \(b:R\) is common to \(X_b,Z_e\); against \(X_a\), the only changed component links port \(a:\Sigma\) to terminal \(b\), while against \(X_b\) it links that port directly to terminal \(a\). All other proper shore ports keep their exterior \(c,d\) routes. Thus pairing \(e\) with \(a:\Sigma\) gives endpoints \(b,a\), and pairing it elsewhere cannot exchange \(c,d\).

If \(Z_e\) uses \(b:Q\), then \(d\) must select \(P\) and \(c\) must select \(L\). The remaining singleton \(R\) is covered by \(a:R\) or \(4R\). The three-port shore quota leaves exactly six exterior masks, indexed by the half of \(a\) and the edge covering \(O\). The table lists each selected proper shore port's exterior terminal against \(X_a,X_b\), respectively:

| \(a\) half and \(O\)-edge of \(Z_e\) | Selected proper shore ports and endpoint pairs |
|---|---|
| \(a:R,1O\) | \(h_2:(b,a),\ h_3:(d,d),\ h_4:(c,c)\) |
| \(a:R,2O\) | \(h_1:(d,d),\ h_3:(b,a),\ h_4:(c,c)\) |
| \(a:R,3O\) | \(h_1:(d,d),\ h_2:(b,a),\ h_4:(c,c)\) |
| \(a:\Sigma,1O\) | \(a:\Sigma:(c,a),\ h_2:(b,c),\ h_3:(d,d)\) |
| \(a:\Sigma,2O\) | \(a:\Sigma:(c,a),\ h_1:(d,d),\ h_3:(b,c)\) |
| \(a:\Sigma,3O\) | \(a:\Sigma:(c,a),\ h_1:(d,d),\ h_2:(b,c)\) |

For example, in the fourth row \(Z_e\) uses \(a:\Sigma,b:Q,c:L,d:P,4R,1O,h_2,h_3\). Against (2), \(h_2\) reaches terminal \(b\) through \(Q-t_b\); against (3), it continues through \(t_b-R-u_4-L-t_c\) and reaches \(c\), giving \((b,c)\). The same direct trace gives the other entries. None is \((c,d)\) or \((d,c)\). Hence the shore \(e\)-path cannot make the two required pure states, contradicting the real row. \(\square\)

This is a matching-level obstruction for one \(e\)-neighbour choice, not a full exclusion of the long-leaf fork marking. The other fork neighbour choices, path tree, larger barriers, other Tutte profiles, and Berge--Fulkerson remain open. The six-route table is hand-derived and has not received an independent check.
