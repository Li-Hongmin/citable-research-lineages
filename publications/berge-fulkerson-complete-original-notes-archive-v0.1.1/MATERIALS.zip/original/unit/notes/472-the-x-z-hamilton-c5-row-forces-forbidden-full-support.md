> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(C_5\) row forces forbidden full support

Continue the marked Hamilton exterior, six matching labels, and necessary signatures of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In \(C_5\), the old genuine \((eX)(eY)\) row has \(P=eX\) rooted at \(X:4\), \(R=eY\) rooted at \(Y:5\), and singleton \(K=Y\) on \(X:1,Z:2,W:6,3u_2,4u_4,5u_5,p_1,p_3\). We prove that every labelled old phase admits a forbidden BF recompletion with the six complete shore restrictions retained individually.

Write \(S=\{J,a,b\}\), and let \(\lambda\in\{a,b\}\) be the old companion of \(K\) at \(X:1\). Write \(\bar\lambda\) for the other \(e\)-singleton. The old \(X\) pairs are \((RJ,K\lambda,P\bar\lambda)\). The old pairs at the tree subdivisions, in first-half/second-half/port order, are
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,S\setminus\{\alpha\},K\alpha)
&(PR,K\alpha,S\setminus\{\alpha\})
&(PR,J\lambda,K\bar\lambda)
&(RK,P\theta,S\setminus\{\theta\})
&(K\xi,PR,S\setminus\{\xi\}),
\end{array}                                                   \tag{1}
\]
where \(\alpha\in S\) and \(\{\lambda,\theta,\xi\}=S\). Indeed the old \(PR\) halves at \(1u_1,2u_2,3u_3\), together with \(K\)'s port \(p_1\), propagate \(K\alpha\) through \(Z:2,W:6,3u_2\). At vertex \(4\), the old pairs \(X:4=P\bar\lambda\) and \(u_4:4=RK\) force \(u_3:4=J\lambda\); hence \(p_3=K\bar\lambda\). Vertex \(5\) gives the stated brace condition. In particular, the old port pairs are
\[
(p_1,p_2,p_3,p_4,p_5)=
(K\alpha,S\setminus\{\alpha\},K\bar\lambda,
 S\setminus\{\theta\},S\setminus\{\xi\}),
\qquad e=ab.                                                \tag{2}
\]

## \(\alpha\ne\lambda\): one double-triple template

Let \(\tau\) be the third element of \(S\), so \(\{\alpha,\lambda,\tau\}=S\). Keep (2) and use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(R\lambda,P\tau,K\alpha)
&(RK,P\alpha,S\setminus\{\alpha\})
&(R\lambda,PJ,K\bar\lambda)
&(RK,P\theta,S\setminus\{\theta\})
&(R\xi,PK,S\setminus\{\xi\}),
\end{array}                                                   \tag{3}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,PK,ab)&(PR,S\setminus\{\lambda\},K\lambda)&
(PK,S\setminus\{\tau\},R\tau)&
(PR,K\tau,S\setminus\{\tau\}).
\end{array}                                                   \tag{4}
\]
At original vertices \(1,\ldots,6\) the incident pairs are
\[
(PK,R\lambda,S\setminus\{\lambda\}),\quad
(P\tau,RK,S\setminus\{\tau\}),\quad
(P\alpha,R\lambda,K\tau),\quad
(PJ,RK,ab),\quad
(P\theta,K\lambda,R\xi),\quad
(PK,R\tau,S\setminus\{\tau\}).                         \tag{5}
\]
Every triple in (3)--(5) partitions the six labels, using \(\{\alpha,\lambda,\tau\}=S\) and \(\{\lambda,\theta,\xi\}=S\). The terminals are \(X=RJ,Z=PK,Y=W=PR\): forbidden \((eX)(eZ)\).

## \(\alpha=\lambda\): the two orders of \(\theta,\xi\)

If \(\theta=J,\xi=\bar\lambda\), use the following exterior pairs:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RJ,P\bar\lambda,K\lambda)
&(RK,P\lambda,J\bar\lambda)
&(RJ,P\lambda,K\bar\lambda)
&(RJ,PK,ab)
&(R\bar\lambda,PK,J\lambda),
\end{array}                                                   \tag{6}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,P\lambda,K\bar\lambda)&(PR,K\bar\lambda,J\lambda)&
(PK,J\lambda,R\bar\lambda)&(PR,K\bar\lambda,J\lambda).
\end{array}                                                   \tag{7}
\]
Vertices \(1,\ldots,6\) see
\[
(P\lambda,RJ,K\bar\lambda),\quad
(P\bar\lambda,RK,J\lambda),\quad
(P\lambda,RJ,K\bar\lambda),\quad
(P\lambda,RJ,K\bar\lambda),\quad
(PK,J\lambda,R\bar\lambda),\quad
(PK,R\bar\lambda,J\lambda).                            \tag{8}
\]
The port column of (6) is \((K\lambda,J\bar\lambda,K\bar\lambda,ab,J\lambda)\), exactly (2), and (6)--(8) are partitions. The terminals again give forbidden \((eX)(eZ)\).

If \(\theta=\bar\lambda,\xi=J\), keep the corresponding port list \((K\lambda,J\bar\lambda,K\bar\lambda,J\lambda,ab)\) and use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,J\bar\lambda,K\lambda)
&(RK,P\lambda,J\bar\lambda)
&(RJ,P\lambda,K\bar\lambda)
&(RK,P\bar\lambda,J\lambda)
&(RJ,PK,ab),
\end{array}                                                   \tag{9}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,K\lambda,J\bar\lambda)&(PR,J\bar\lambda,K\lambda)&
(KJ,P\lambda,R\bar\lambda)&(PR,K\bar\lambda,J\lambda).
\end{array}                                                   \tag{10}
\]
At original vertices the incident pairs are
\[
(PR,K\lambda,J\bar\lambda),\quad
(J\bar\lambda,RK,P\lambda),\quad
(P\lambda,RJ,K\bar\lambda),\quad
(P\lambda,RK,J\bar\lambda),\quad
(P\bar\lambda,RJ,K\lambda),\quad
(PK,R\bar\lambda,J\lambda).                            \tag{11}
\]
Every triple in (9)--(11) partitions all six labels. Its terminal pairs are \(e=ab,Z=KJ,X=Y=W=PR\), the forbidden \([eZ]\) loop.

All cases preserve each old proper-port pair and \(e=ab\), so they glue to the original six **complete** shore matchings on any actual shore. No exact-Case-XII pole with this fixed marked exterior can have a \(C_5\) row. Together with [Notes 470--471](471-the-x-z-hamilton-c4-row-always-recompletes-to-forbidden-support.md), only \(C_3,C_6,C_7\) remain for forbidden \(\{eX,eZ\}\); path reflection gives the corresponding result for \(\{eY,eW\}\). This hand proof awaits independent review, and it does not settle the other exteriors, full exact Case XII or Berge--Fulkerson. \(\square\)
