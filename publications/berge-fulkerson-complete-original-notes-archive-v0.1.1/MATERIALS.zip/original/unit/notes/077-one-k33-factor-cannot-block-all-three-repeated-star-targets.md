> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One \(K_{3,3}\) factor cannot block all three repeated-star targets

The \(K_{3,3}\) two-sum from
[Note 076](076-k33-two-sums-preserve-boundary-support-and-force-opposite-kempe-signs.md)
can split every supported BF cell into distinct Kempe classes, but it cannot
simultaneously empty all three singleton-tuple fibres required by the
repeated-extension gate of
[Note 073](073-local-trivalent-incidence-does-not-force-the-six-singleton-gate.md).

More precisely, if the four pivot singleton quadruples can each be completed
to a BF cover of one \(K_{3,3}\) factor, then at least one of the three target
quadruples can also be completed.  The result is sharp: any chosen two target
quadruples can be made uncompletable.

## Four-to-six completion in \(K_{3,3}\)

Identify a perfect matching of \(K_{3,3}\) with a permutation
\(\pi\in S_3\), and let \(P_\pi\) be its permutation matrix.  For four
matching occurrences \(\pi_1,\ldots,\pi_4\), put

\[
 C=\sum_{r=1}^{4}P_{\pi_r}.
\]

The following conditions are equivalent:

1. There are \(\rho,\sigma\in S_3\) such that
   \[
   C+P_\rho+P_\sigma=2J_3.
   \]
2. Every entry of \(C\) is at most two.
3. No edge of \(K_{3,3}\) belongs to three of the four occurrences.

Only sufficiency needs proof.  If \(C\le2J_3\), then

\[
 D=2J_3-C
\]

is a nonnegative integral matrix with all row and column sums equal to two.
It is the incidence matrix of a 2-regular bipartite multigraph, whose even
cycles decompose into two 1-factors.  Hence
\(D=P_\rho+P_\sigma\).  In the \(3\times3\) case the unordered completing
pair is unique.

Call a four-occurrence family **good** when these conditions hold, and
**bad** otherwise.

## The repeated-extension classification

Write the six singleton tokens as

\[
 (A,B,C,D,X,Y)=(a_1,a_2,a_4,a_5,x,y).
\]

The singleton parts of the four pivot rows are

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.          \tag{1}
\]

Their eight triple tokens are row-private.  Therefore a consistent
assignment of gadget matchings to all fourteen tokens exists exactly when
the four singleton quadruples in (1) are good; the two private triple tokens
in each row are then its unique completing pair.

The three target singleton quadruples are

\[
 BDXY,\qquad ACXY,\qquad ABDY.                     \tag{2}
\]

A common relabelling of the three output vertices normalizes \(A=012\).
Testing the remaining \(6^5\) assignments by the entry-multiplicity
criterion gives

\[
\begin{array}{c|r}
\text{badness pattern for (2)}&\text{assignments}\\ \hline
000&150\\
001&24\\
010&54\\
011&108\\
100&54\\
101&48\\
110&122\\
111&0.
\end{array}                                        \tag{3}
\]

The entries sum to \(560\), all normalized assignments for which the four
pivot quadruples are good.  Since pattern \(111\) is absent, one gadget
factor never blocks all three targets.  Each two-target pattern occurs, so
the assertion cannot be strengthened to two guaranteed completable targets.
For example, the assignments

\[
\begin{array}{c|c}
011&(012,012,120,201,120,021)\\
101&(012,012,120,201,201,021)\\
110&(012,021,102,120,201,201)
\end{array}                                        \tag{4}
\]

in the order \((A,B,C,D,X,Y)\) realize all three sharp patterns.  The finite
classification is frozen in the
[standard-library verifier](../computations/bundles/k33-four-matching-completion-repeated-star/README.md).

## Boundary of the positive conclusion

At least one target quadruple is completable inside every single inserted
\(K_{3,3}\) factor compatible with the pivot rows.  This does not produce a
target BF row in the whole pole.  Its two companion matchings must complete
the same four singleton identities simultaneously on every other proper
edge and must have the required triple boundaries.

Thus one \(K_{3,3}\) sign factor cannot destroy the repeated-extension gate,
but the real Case-XII problem remains a global simultaneous-completion
problem across all proper-edge factors.
