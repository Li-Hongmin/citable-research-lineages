> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A signed six-port gate for the two-root fibres

Continue the \(|U|=r=5\) one-internal-mark, one-shore profile of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). The complete shore is \(Z=C\cup\{t_e\}\). Write its six ports as \(e,p_1,\ldots,p_5\), with \(p_i\) at the subdivision vertex of tree edge \(i\). The exact Case-XII boundary relation is the one in Máčajová--Mazzuoccolo--Tabarelli, Proposition 4.4 and Appendix XII (2026, DOI 10.26493/1855-3974.3409.c13). In particular, for two of the four exterior labels \(j\), the \(ej\)-Tait loop is forbidden.

## Exact parity reduction

Fix a zero-port shore perfect matching \(Q\) and a mark \(j\ne e\). Its two complete state-\(ej\) triple matchings are \(P_{j,x,Q}\), one for each endpoint \(x\) of \(j\), by Note 358. In the shore complement \(Z-Q\), retain the three port paths with their lengths modulo two and the closed cycles. In the exterior complement of \(P_{j,x,Q}\), retain the pairing \(\pi_{j,x}\) of \(j,p_1,\ldots,p_5\).

**Parity lemma.** Every path and every closed cycle of the exterior complement has even length, counting terminal and port semiedges as edges. If \(Z-Q\) has no odd closed cycle, \(P_{j,x,Q}\) extends to a genuine \(ej\)-Tait colouring exactly when every closed component obtained by gluing the shore-path pairing to \(\pi_{j,x}\) contains an even number of odd shore paths. In this case the number of odd shore paths is odd: either one or three.

Indeed, each tree port reaches its \(W\)-vertex through a two-edge segment, each unselected exterior mark joins its two \(W\)-ends through a two-edge segment, and the unused half of \(j\), together with terminal \(j\), is another two-edge segment. The exterior complement is assembled from these segments; any pure marked cycle is even. A glued closed walk uses an even number of port identifications, so its length parity is the sum of the parities of its shore paths. A complement with only even closed cycles two-colours into the other two perfect matchings; the open \(e\)--\(j\) path has the required endpoint parity because the five-pole has odd order. Finally, \(|V(Z)|\) is even. Each shore path has one more edge than internal vertices, and the closed shore cycles are even, so the sum of the three shore-path lengths is odd.

Thus, when the shore has no odd closed complement, its entire contribution to all eight \(ej\)-Tait decisions is one of at most \(15\cdot4=60\) signed pairings: fifteen pairings of six ports and four assignments of an odd number of odd paths. This is a finite parity quotient, not a claim that all sixty signatures are realizable by a cubic shore or that Tait decisions determine BF-row activity.

There is also an exact **cycle-local BF-row gate** for the original coupling question. Suppose a BF row contains \(P=P_{j,x,Q}\), and let \(P'=P_{j,y,Q}\). Their symmetric difference is the even fundamental cycle \(D\) formed by mark \(j\) and the unique tree path between its ends. A BF row containing \(P'\), with the other five named matchings unchanged **outside \(D\)**, exists if and only if one of those five matching occurrences contains every edge of \(D\setminus P\). In that case switch \(P\) and that occurrence together along \(D\). Conversely, at each vertex of \(D\), changing \(P\) moves one of the two colours on the other cycle edge to the old \(P\)-edge; because each edge has the same pair of colours at both ends, the moved colour is constant around \(D\). It is therefore one companion occurrence on every edge of \(D\setminus P\). This criterion says exactly when a root flip can stay local to its fundamental cycle. It does not decide rows that also change matchings outside \(D\).

**Exterior four-singleton theorem.** Let \(P_{ej}\) and \(P_{ek}\) be *any two* zero-port triple matching restrictions to this five-vertex exterior; \(j=k\) and arbitrary root choices are allowed. Then their load-two residual on the exterior always splits into four actual singleton-exterior matching restrictions with intended full boundaries \(e,e,j,k\). Thus the exterior alone never obstructs a four-singleton load-two completion for a proposed row \((ej)(ek)\). Full-pole completion still requires the four exterior port-colour sets to match four actual shore matchings in the same load-two row.

To prove it, count copies in \(D_E=2\mathbf1_E-P_{ej}-P_{ek}\), including the dangling port and terminal semiedges. Every exterior internal vertex has degree four. The proper exterior graph is bipartite, with six \(W\)-vertices on one side and the five \(U\)-vertices plus four marked subdivision vertices on the other. The five proper shore ports contribute two residual semiedge copies each. The exterior terminals contribute one at \(j\) and one at \(k\), or two at \(j\) when \(j=k\). Attach these twelve copies to three new vertices on the \(W\)-side, four copies per new vertex. When \(j\ne k\), attach the two terminal copies to the **same** new vertex, so they must receive distinct colours. The resulting bipartite multigraph is four-regular on nine vertices per side. Hall's inequality \(4|A|\le4|N(A)|\) gives a perfect matching; delete it and repeat at degrees three, two and one. Removing the three new vertices from the four resulting colour classes gives four exterior perfect matchings, each with exactly three dangling semiedges. Name the distinct terminal colours \(j,k\) (or the two \(j\) occurrences) and the other two colours \(e,e\). The former use two proper shore ports each and the latter three, exactly as [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) requires. Parallel residual copies get different colours, so every colour class is an ordinary matching of the original exterior.

**Branch-pair obstruction.** Take two zero-port triple matchings with the *same* shore restriction \(Q\), rooted at \(x,y\in W\), and suppose a tree edge \(g=vw\) lies on the unique \(x\)--\(y\) path while another tree edge \(h=vz\) leaves that path at \(v\). If the complement of \(Q\) pairs the ports \(p_g,p_h\) by an odd-length path, then these two triples cannot lie in one BF row, whether their states \(ej,ek\) are equal or different.

Indeed, any such row has four singleton occurrences; call their colour set \(I\). Since the two triples both use \(Q\), [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes the two port colour sets equal to some two-set \(L\subset I\). Rooting at either \(x\) or \(y\) orients the off-path edge \(h\) away from \(v\), so both triples match its subdivision vertex \(u_h\) to \(z\). The two residual copies of \(vu_h\) must carry the two colours \(I\setminus L\). Along the on-path edge \(g\), the two root orientations differ, so the residual has one further copy of \(vu_g\), also coloured from \(I\setminus L\). These three incidences meet \(v\), although each of the two colours in \(I\setminus L\) can occur only once there. This is impossible. The obstruction is a shore-colour alignment failure despite the unconditional exterior four-singleton completion above.

## A three-spoke prism path

There is a useful positive subcase, stated with its exact marking assumption. Suppose the suppressed six-vertex cubic exterior is a triangular prism, its five tree edges form a Hamilton path \(1-2-3-4-5-6\), and its other four edges are
\[
                         14,\quad15,\quad26,\quad36.                 \tag{1}
\]
Thus the tree contains all three prism spokes. Put \(p_i\) on tree edge \(i(i+1)\). Rooting the tree at the two ends of each mark and following the unused exterior edges gives the following **complete** pairing table. The entry \(j\ell\mid ab\mid cd\) means that terminal \(j\) is paired with \(p_\ell\), while the other ports pair as \(p_ap_b\) and \(p_cp_d\).

| mark \(j\) | first root | second root | both roots blocked: one odd shore path \((k,q)\) | both roots blocked: three odd shore paths \((k,\tau)\) |
|---|---|---|---|---|
| \(14\) | \(j4\mid15\mid23\) | \(j5\mid12\mid34\) | \((4,12),(5,23)\) | \((2,15\mid34)\) |
| \(15\) | \(j5\mid14\mid23\) | \(j3\mid12\mid45\) | \((5,12),(3,14)\) | \((1,23\mid45)\) |
| \(26\) | \(j3\mid12\mid45\) | \(j1\mid34\mid25\) | \((3,25),(1,45)\) | \((5,12\mid34)\) |
| \(36\) | \(j1\mid45\mid23\) | \(j2\mid34\mid15\) | \((1,34),(2,45)\) | \((4,15\mid23)\) |

In the last two columns, the shore pairs \(e p_k\) and \(\tau\); with one odd shore path, \(q\) names the odd pair in \(\tau\). An odd \(e p_k\) path cannot block any mark, because it lies on the open \(e\)--\(j\) component. The table assumes no odd closed shore cycle.

For clarity, the table's blocker test is elementary. If \(j\) is paired with \(p_k\) in an exterior pairing, the other two shore paths form either two closed components or one closed component; one odd shore path blocks this root in either case. If \(j\) is paired with \(p_\ell\ne p_k\), a closed component exists only when the shore matching \(\tau\) contains the exterior pair disjoint from \(p_k\). With one odd shore path, that pair must be \(q\). With three odd shore paths, a root with \(\ell=k\) is blocked exactly when \(\tau\) equals its two exterior pairs; a root with \(\ell\ne k\) is blocked exactly when \(\tau\) contains its exterior pair disjoint from \(p_k\). Applying these rules to the two displayed root pairings gives the final columns. Their entries are pairwise distinct across the four marks.

**Prism-path consequence.** If \(Z-Q\) has no odd closed cycle, at most one of the four labels \(j\) has both root completions blocked. Exact Case XII forbids the \(ej\)-Tait loop for **two** labels \(j\). Hence, in an exact-Case-XII pole with marking (1), *every* zero-port shore matching \(Q\) has an odd closed component in \(Z-Q\). By [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the two zero-port triples in any actual BF row \((ej)(ek)\), including \(j=k\), must therefore have **different complete shore matchings**. This is a same-row full-mask constraint, not an assertion that either root of a prescribed triple enters a BF row.

## A genuine \(K_{3,3}\) boundary

The preceding Tait conclusion does not hold for every six-vertex exterior. Here is a connected simple cubic five-pole of order 21 and girth five in which one zero-port shore matching has no odd closed shore cycle, yet **all eight** of its two-root \(ej\) triple complements contain an odd cycle.

Take \(W=\{a,b,r_1,r_2,l_1,l_2\}\). The tree has edges \(ab,ar_1,ar_2,bl_1,bl_2\), each subdivided by \(u_0,u_1,u_2,u_3,u_4\), respectively. Put a shore edge from \(u_i\) to \(z_i\). The four exterior marks are the edges \(r_i l_h\) for \(i,h\in\{1,2\}\), each subdivided by a vertex \(t_{ih}\) carrying its own terminal semiedge. The suppressed cubic graph is \(K_{3,3}\). Let \(Z\) be the six-cycle
\[
                 t_e-z_0-z_1-z_2-z_3-z_4-t_e,
\]
with terminal \(e\) at \(t_e\); suppressing \(t_e\) recovers the five-vertex odd shore and its internal mark. This specifies all \(6+5+4+6=21\) vertices and every proper edge. Choose
\[
                 Q=\{z_0z_1,z_2z_3,z_4t_e\}.
\]
Its complement has the three **odd** shore paths \(ep_0,p_1p_2,p_3p_4\), all of length three, and no closed component. For any mark \(r_i l_h\), the triple rooted at \(r_i\) leaves the five-cycle
\[
                 b-u_3-z_3-z_4-u_4-b
\]
in its complement; the triple rooted at \(l_h\) leaves the five-cycle
\[
                 a-u_1-z_1-z_2-u_2-a.
\]
The cycle does not depend on the other endpoint of the mark. All eight triple matchings are real by the rooted-tree construction and the zero-port gluing of Note 230. Every proper edge lies on a cycle, and a cycle crossing the shore uses at least five edges, so the stated graph properties follow. This example defeats an inference from two-root full-PM closure and a shore complement with no odd closed cycle to any \(ej\)-Tait state. It is **not** an exact-Case-XII pole: its order 21 is below [Note 226's order-33 bound](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md).

The first shore matching \(Q\) gives a **complete-row no-reuse theorem**, stronger than its odd-cycle obstruction: **no two zero-port triples of any states \(ej,ek\) that use \(Q\) can occur together in one BF row**. If their roots lie on opposite \(r/l\) sides, the root path runs through \(a,b\), and the branch-pair obstruction applies at \(a\) using the odd \(p_1p_2\) shore path (or at \(b\) using \(p_3p_4\)). If both roots are on the \(r\)-side, both triples match \(u_3,u_4\) toward \(l_1,l_2\). Let \(I\) be the four singleton colours and \(L\subset I\) the common colour set on ports \(p_3,p_4\), forced equal by their odd shore path. Each of the edges \(bu_3,bu_4\) has two residual copies carrying precisely \(I\setminus L\). The two colours in \(I\setminus L\) would each occur twice at \(b\), impossible. Both roots on the \(l\)-side give the symmetric contradiction at \(a\). The proof needs only that \(Q\)'s complement pairs \(p_1p_2\) and \(p_3p_4\) by odd paths; it applies to any shore order and rank with that signature. The exterior four-singleton theorem shows that the failed reuse is entirely a shore-colour alignment obstruction.

The same real pole also separates *BF activity* from cycle-local root coupling. Take the other zero-port matching
\[
                Q'=\{t_ez_0,z_1z_2,z_3z_4\},
\]
whose complement pairs \(ep_4,p_0p_1,p_2p_3\), again with three odd paths and no closed cycle. Fix \(j=r_1l_1\), and abbreviate the other three marked subdivision vertices by \(t_{12},t_{22},t_{21}\). For the triple \(P=P_{j,r_1,Q'}\), the entire complement is the single alternating terminal path
\[
 e,t_e,z_4,u_4,b,u_3,z_3,z_2,u_2,a,u_0,z_0,z_1,u_1,r_1,
 t_{12},l_2,t_{22},r_2,t_{21},l_1,t_j,j.              \tag{2}
\]
Thus \(P\) extends to a Tait colouring, and doubling its three colour matchings gives a genuine BF row of type \([ej]\). The other root \(P'=P_{j,l_1,Q'}\) also extends to a Tait colouring: its exterior pairing is \(jp_3\mid p_1p_2\mid p_0p_4\), whose union with the shore pairing is again one \(e\)--\(j\) path and no closed cycle.

These two roots **do co-occur in a real BF row**. Write their Tait decompositions as \(P+E+J=\mathbf1\) and \(P'+E'+J'=\mathbf1\), where \(E,E'\) are singleton-\(e\) and \(J,J'\) singleton-\(j\) matchings. Adding gives
\[
                    P+P'+E+E'+J+J'=2\mathbf1.             \tag{3}
\]
The same argument globally couples any two Tait-compatible triple matchings of one state. It does not keep the other named matchings fixed.

The fundamental root-flip cycle is
\[
 r_1,t_j,l_1,u_3,b,u_0,a,u_1,r_1.
\]
In the doubled Tait row of \(P\), its four edges outside \(P\) are \(t_jl_1,bu_3,au_0,u_1r_1\). Along path (2), the first two occur in odd positions \(21,5\), and the last two in even positions \(10,14\). They therefore belong to different complementary Tait colours. Neither complementary matching occurrence contains all four, and the duplicated \(P\) contains none. The cycle-local BF-row gate above proves that **no root flip retaining the other five occurrences outside this cycle** is possible. Row (3) shows that a coupling does exist when the other matchings are allowed to change off the cycle.

The result isolates a finite signed-pairing obstruction, proves a same-row shore-mask constraint for marking (1), and separates cycle-local from global row coupling in a genuine pole. Other prism markings, other \(K_{3,3}\) trees, non-Tait global root coupling, and exact Case XII remain open. The arguments are analytic and have not received an independent proof check.
