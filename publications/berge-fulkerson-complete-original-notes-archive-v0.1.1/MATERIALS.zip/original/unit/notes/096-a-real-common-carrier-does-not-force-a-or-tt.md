> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real common carrier does not force an all-terminal or TT colouring

The two common-carrier projections isolated in
[Note 095](095-repeated-star-mixed-quartet-nonoverload-is-a-fibre-avoidance-condition.md)
can coexist in one genuine trivalent copy-multigraph without producing an
all-terminal or \(T\)--\(T\) colouring.  Thus common internal incidence,
all proper three-edge-colourings and their genuine Kempe-component transport
do not by themselves settle the repeated-star nonoverload gate.

The carrier embeds in a simple connected cubic five-pole.  In that embedding
its unique pair of required singleton projections is already nonoverloaded;
the example therefore isolates the fixed-half owner phase rather than
refuting the exact-Case-XII statement.

## The carrier

Take vertices \(0,\ldots,8\).  Terminal \(s_i\) is incident with vertex
\(i-1\), and the terminal-copy loads are

\[
(1,2,2,1,1).
\]

Every proper edge in

\[
03,07,15,28,36,46,47,56,58,78                 \tag{1}
\]

has copy multiplicity one.  Counting terminal copies, every vertex has
degree three in the resulting copy-multigraph \(K\).

Its complete proper three-edge-colouring relation, modulo global colour
permutation, is

\[
\begin{aligned}
\{&(15\mid24;2),(14\mid15;1),(14\mid25;2),\\
  &(13\mid45;3),(14\mid35;3),(14\mid45;4)\}.      \tag{2}
\end{aligned}
\]

Here \((rs\mid tu;j)\) means that the singleton colour has terminal \(j\)
and the two triple colours omit the pairs \(rs,tu\).  Relation (2) consists
of four \(S\)--\(T\) and two \(S\)--\(S\) states.  It contains neither a
\((5,1,1)\) all-terminal boundary pattern nor a \(T\)--\(T\) state.

In particular, the two required projections are realized by

\[
\begin{aligned}
q_{24}&=\{15,36,78,s_1,s_3,s_5\},\\
r_{15}&=\{07,46,58,s_2,s_3,s_4\},\\
B     &=\{03,28,47,56,s_2\},                     \tag{3}\\[2mm]
q_{13}&=\{07,28,56,s_2,s_4,s_5\},\\
r_{45}&=\{36,47,58,s_1,s_2,s_3\},\\
X     &=\{03,15,46,78,s_3\}.                     \tag{4}
\end{aligned}
\]

The complete relation has only one class-two singleton matching \(B\) in
the first oriented projection and only one class-three singleton matching
\(X\) in the second.

## Embedding and owner phase

Add the proper edge \(12\), invisible to \(K\), to the support in (1).
This gives a simple connected cubic five-pole with no proper bridge.  The
complementary load \(2\mathbf1-K\) splits as

\[
\begin{aligned}
A&=\{15,28,36,47,s_1\},\\
C&=\{07,12,46,58,s_4\},\\
D&=\{03,12,56,78,s_5\}.                           \tag{5}
\end{aligned}
\]

Adding (5) to any colouring in (2) double-covers every edge object.  The
unique required singleton pair satisfies

\[
B\cap X=\{03\}\subseteq D,
\qquad
B\cap X\cap(A\mathbin\triangle C)=\varnothing.    \tag{6}
\]

Thus it lies in the safe owner phase of Note 095.

For this fixed \(K\), the embedding is owner-rigid at the common edge.
Only vertices \(1,2\) have local copy-load profile \((2,1)\); all other
vertices have profile \((1,1,1)\).  Hence the only two invisible
half-incidences must be paired as the edge \(12\).  The complementary load
has exactly two decompositions with singleton boundaries \(1,4,5\).  In
both,

\[
s_1\in A\Longrightarrow03\in\{C,D\},
\qquad
s_4\in C\Longrightarrow03\in\{A,D\},
\]

so \(03\) is forced into \(D\).

## Consequence and scope

Relation (2) realizes in one actual carrier the two Kempe-closed boundary
blocks that can otherwise be written abstractly.  Therefore none of the
following implies an all-terminal or \(T\)--\(T\) carrier colouring:

1. both required singleton projections;
2. common trivalent internal incidence;
3. all colourings of that fixed carrier; and
4. genuine synchronous transport of all bichromatic components.

The completed five-pole is not exact Case XII: its full perfect-matching
family has all-terminal and \(T\)--\(T\) BF covers.  The example also does
not violate the target nonoverload condition, by (6).  It proves that the
owner partition supplied by the fixed matchings \(A,C,D\), and ultimately
its coupling to the full BF-cover family, cannot be discarded.

The complete colouring relation and embedding are verified by the
[order-nine carrier certificate](../computations/bundles/order-nine-common-carrier/README.md).
