> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last two long Hamilton \(K_{3,3}\) signatures force \([eW]\)

Use the marked Hamilton \(K_{3,3}\) exterior and genuine complete \((eZ)(eX)\) row of [Notes 489--490](490-the-k33-long-row-forces-one-pentagon-and-shore-e-paths.md), with forbidden \(e\)-states \(\{eZ,eW\}\). [Notes 492--493](493-the-second-k33-long-signature-recompletes-to-forbidden-ez-ew.md) exclude both signatures rooted at \(P:Z:2\). Here \(P=eZ\) is rooted at \(Z:5\), and \(J=Z\) has the two remaining choices \(5u_4\) or \(5u_5\). Name the six complete old matching occurrences \(P,R,K,J,A,B\), with \(A=D_0,B=D_1\) in Note 490.

In either choice, the old matching restrictions to the shore have load two and the following boundary sets:
\[
\begin{array}{c|cccccc}
&P&R&K&J&A&B\\\hline
J:5u_4&\varnothing&\varnothing&p_4p_5&p_3p_5&ep_1p_2p_3&ep_1p_2p_4\\
J:5u_5&\varnothing&\varnothing&p_4p_5&p_3p_4&ep_1p_2p_3&ep_1p_2p_5.
\end{array}                                                \tag{1}
\]
Concatenation in this table denotes a set of ports, not a pairing of them. The six shore matching **identities**, not just their port sets, will be retained one for one.

**Theorem.** Both remaining signatures admit a recompletion of the same six complete shore matchings to a genuine BF loop \([eW]\). Thus, conditional on Notes 489--490, the forbidden pair \(\{eZ,eW\}\) is impossible for the entire Hamilton-path \(K_{3,3}\) exterior in the \(|U|=r=5\), one-internal-mark, one-shore profile. Reflection \(i\mapsto7-i\) gives the same exclusion for \(\{eZ,eX\}\). No claim is made about the other forbidden-pair orbits or other five-pole profiles.

**Case \(J:5u_4\).** Replace only the exterior masks of the six old complete matchings by these:

| colour | boundary role | marked halves | tree halves | proper ports |
|---|---|---|---|---|
| \(P\) | \(eW\) | \(W:3\) | \(1u_1,2u_2,4u_3,5u_4,6u_5\) | none |
| \(R\) | \(eW\) | \(W:6\) | \(1u_1,2u_2,3u_3,4u_4,5u_5\) | none |
| \(K\) | \(W\) | \(X:1,Y:6,Z:5\) | \(2u_1,3u_2,4u_3\) | \(p_4,p_5\) |
| \(J\) | \(W\) | \(X:1,Y:6,Z:5\) | \(2u_1,3u_2,4u_4\) | \(p_3,p_5\) |
| \(A\) | \(e\) | \(X:4,Y:1,Z:2,W:3\) | \(5u_4,6u_5\) | \(p_1,p_2,p_3\) |
| \(B\) | \(e\) | \(X:4,Y:1,Z:2,W:6\) | \(3u_3,5u_5\) | \(p_1,p_2,p_4\) |

At the five tree subdivisions, the pairs on the left half, right half and proper port are respectively
\[
\begin{array}{c|ccc}
u_1&PR&KJ&AB\\
u_2&PR&KJ&AB\\
u_3&RB&PK&JA\\
u_4&RJ&PA&KB\\
u_5&RB&PA&KJ.
\end{array}                                                \tag{2}
\]
At original vertices \(1,\ldots,6\), the three incident pairs are
\[
\begin{array}{c|ccc}
1&PR:1u_1&KJ:X:1&AB:Y:1\\
2&PR:2u_2&KJ:2u_1&AB:Z:2\\
3&PA:W:3&KJ:3u_2&RB:3u_3\\
4&PK:4u_3&RJ:4u_4&AB:X:4\\
5&PA:5u_4&RB:5u_5&KJ:Z:5\\
6&PA:6u_5&RB:W:6&KJ:Y:6.
\end{array}                                                \tag{3}
\]
The marked-subdivision pairs are \(X:(PR\text{ terminal},KJ:X:1,AB:X:4)\), \(Y:(PR\text{ terminal},AB:Y:1,KJ:Y:6)\), \(Z:(PR\text{ terminal},AB:Z:2,KJ:Z:5)\), and \(W:(KJ\text{ terminal},PA:W:3,RB:W:6)\). The \(e\) terminal has \(A,B\). Thus every exterior edge has load two, and every row of the table is a matching with exactly the old shore ports in (1). Each one glues to its own old complete shore matching, producing the forbidden \([eW]\) BF row.

**Case \(J:5u_5\).** Here the two zero-port triples may use the **same exterior** root at \(W:6\); their complete shore matchings remain the old \(Q_P,Q_R\), whether equal or different.

| colour | boundary role | marked halves | tree halves | proper ports |
|---|---|---|---|---|
| \(P\) | \(eW\) | \(W:6\) | \(1u_1,2u_2,3u_3,4u_4,5u_5\) | none |
| \(R\) | \(eW\) | \(W:6\) | \(1u_1,2u_2,3u_3,4u_4,5u_5\) | none |
| \(K\) | \(W\) | \(X:1,Y:6,Z:5\) | \(2u_1,3u_2,4u_3\) | \(p_4,p_5\) |
| \(J\) | \(W\) | \(X:4,Y:1,Z:5\) | \(2u_1,3u_2,6u_5\) | \(p_3,p_4\) |
| \(A\) | \(e\) | \(X:4,Y:1,Z:2,W:3\) | \(5u_4,6u_5\) | \(p_1,p_2,p_3\) |
| \(B\) | \(e\) | \(X:1,Y:6,Z:2,W:3\) | \(4u_3,5u_4\) | \(p_1,p_2,p_5\) |

At \(u_1,\ldots,u_5\), the three pairs are
\[
\begin{array}{c|ccc}
u_1&PR&KJ&AB\\
u_2&PR&KJ&AB\\
u_3&PR&KB&JA\\
u_4&PR&AB&KJ\\
u_5&PR&JA&KB.
\end{array}                                                \tag{4}
\]
At vertices \(1,\ldots,6\), they are
\[
\begin{array}{c|ccc}
1&PR:1u_1&KB:X:1&JA:Y:1\\
2&PR:2u_2&KJ:2u_1&AB:Z:2\\
3&PR:3u_3&KJ:3u_2&AB:W:3\\
4&PR:4u_4&KB:4u_3&JA:X:4\\
5&PR:5u_5&AB:5u_4&KJ:Z:5\\
6&PR:W:6&KB:Y:6&JA:6u_5.
\end{array}                                                \tag{5}
\]
The marked-subdivision pairs are \(X:(PR\text{ terminal},KB:X:1,JA:X:4)\), \(Y:(PR\text{ terminal},JA:Y:1,KB:Y:6)\), \(Z:(PR\text{ terminal},AB:Z:2,KJ:Z:5)\), and \(W:(KJ\text{ terminal},AB:W:3,PR:W:6)\). Again the \(e\) terminal has \(A,B\). This proves an actual six-matching \([eW]\) row with the exact six old shore masks in the second line of (1). \(\square\)

The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual \((eZ)(eX)\) row and forbids every \(T\)--\(T\) type when \(eZ,eW\in T\). Notes 489--490 reduce any such exact-support row to the four signatures now excluded by Notes 492--494. Thus the pair \(\{eZ,eW\}\), and by path reflection \(\{eZ,eX\}\), is conditionally excluded for this Hamilton \(K_{3,3}\) exterior. The other forbidden pairs, the one-spoke prism, other five-pole profiles and Berge--Fulkerson remain open. The proof is hand-derived, without OMEN or local mathematical recomputation, and awaits independent review.
