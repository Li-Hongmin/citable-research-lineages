> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three-edge-colourable two-sums preserve literal dependent-splice fibres

Let \(H_0\) be a cubic pole, let \(e=xy\) be a proper edge of \(H_0\), and
let \(J\) be a closed simple cubic graph with a proper edge \(f\). Delete
\(e\) and \(f\), and reconnect their four ends crosswise to form

\[
H=H_0\oplus_{e,f}J.
\tag{1}
\]

Assume that \(J\) is 3-edge-colourable. Then:

1. every one-splice, sequential two-splice and forced-intermediate
   construction of Note 082 succeeds in \(H\) if and only if its two factor
   projections succeed in \(H_0\) and \(J\);
2. \(H\) and \(H_0\) have exactly the same complete BF boundary support and
   Tait state set;
3. every literal dependent two-splice fibre in \(H_0\) has a consistent lift
   to the same literal fibre in \(H\). Consequently such a fibre exists in
   \(H\) if and only if it exists in \(H_0\).

The third assertion is stronger than a slot-by-slot existence argument:
one fixed map from the complete perfect-matching family of \(H_0\) to the
three colour factors of \(J\) lifts every matching identity, every BF row and
every pair-sum equality simultaneously.

## Perfect-matching factorization

The two new splice edges form the cut separating \(V(J)\) from the rest of
\(H\). Every perfect matching uses either both cut edges or neither.
Restoring \(e\) and \(f\) in the first case gives a unique pair

\[
(M_0,M_J)\in\mathcal M(H_0)\times\mathcal M(J),
\]

and a pair splices if and only if

\[
\mathbf1_{e\in M_0}=\mathbf1_{f\in M_J}.
\tag{2}
\]

Boundary data are entirely inherited from \(M_0\).

## Factorization of one and two splices

Let \(P,\widehat P,N\) be perfect matchings of \(H\), and write their unique
factor projections with subscripts \(0,J\). The one-splice alignment
condition of Note 082 is equivalent to

\[
N'=N+P-\widehat P
\tag{3}
\]

being a perfect matching. Put

\[
N'_0=N_0+P_0-\widehat P_0,\qquad
N'_J=N_J+P_J-\widehat P_J.
\tag{4}
\]

If (3) is a perfect matching, uniqueness of projection makes both vectors
in (4) perfect matchings. Conversely, if both vectors in (4) are perfect
matchings, their distinguished-edge bits agree:

\[
\begin{aligned}
\mathbf1_{e\in N'_0}
&=\mathbf1_{e\in N_0}+\mathbf1_{e\in P_0}
  -\mathbf1_{e\in\widehat P_0}\\
&=\mathbf1_{f\in N_J}+\mathbf1_{f\in P_J}
  -\mathbf1_{f\in\widehat P_J}
 =\mathbf1_{f\in N'_J}.
\end{aligned}
\tag{5}
\]

They therefore splice to (3). Hence

\[
\boxed{
\operatorname{Align}_{H}(N;P\to\widehat P)
\iff
\operatorname{Align}_{H_0}(N_0;P_0\to\widehat P_0)
\land
\operatorname{Align}_{J}(N_J;P_J\to\widehat P_J).}
\tag{6}
\]

Apply (6) successively to the two ordered systems (5)--(7) of Note 082.
This proves the sequential two-splice assertion in both orders. For the
forced-intermediate branch, the first candidate

\[
Z=Y+D-P_5
\tag{7}
\]

is a perfect matching of \(H\) if and only if its two factor candidates are
perfect matchings, by the same proof as (3)--(5). The second candidate
\(N+P_3-Z\) then factorizes in the same way. Thus the complete Note082 case
list is factorwise, with no hidden cross-factor phase condition.

## Exact BF and Tait support

Projection of any BF witness of \(H\) gives BF witnesses of both factors.
In particular it gives a witness of the same boundary type in \(H_0\).

Conversely, fix one 3-edge-colouring of \(J\), with colour-class
one-factors \(F_0,F_1,F_2\), labelled so that

\[
f\in F_0.
\tag{8}
\]

In every BF witness of \(H_0\), exactly two matching occurrences use \(e\).
Assign \(F_0\) to those two slots and assign \(F_1,F_1,F_2,F_2\) to the
other four slots. The six \(J\)-factors double-cover \(J\), their
distinguished bits agree slotwise with the \(H_0\)-factors, and hence they
splice to a BF witness of \(H\) with the same boundary type. Therefore

\[
\operatorname{BFsupp}(H)=\operatorname{BFsupp}(H_0).
\tag{9}
\]

For a Tait colouring, the two cut edges have the same colour. Projection
gives a Tait colouring of \(H_0\). Conversely, permute the three colours of
the fixed colouring of \(J\) so that the colour of \(f\) agrees with that of
\(e\), then splice. Hence

\[
\operatorname{TaitStates}(H)=\operatorname{TaitStates}(H_0).
\tag{10}
\]

Only existence of one 3-edge-colouring of \(J\) is used.

## A canonical consistent lift of every literal identity

Let \(g,h\) be the other two edge objects incident with \(x\), so

\[
\delta(x)=\{e,g,h\}.
\]

Every perfect matching \(M\) of \(H_0\) contains exactly one member of this
three-edge star. Define

\[
c(M)=
\begin{cases}
0,&e\in M,\\
1,&g\in M,\\
2,&h\in M.
\end{cases}
\tag{11}
\]

Now lift every perfect-matching identity \(M\) occurring in the literal
fibre by the single rule

\[
\widetilde M=M\oplus F_{c(M)}.
\tag{12}
\]

This rule is consistent automatically: repeated occurrences of the same
\(H_0\)-matching receive the same \(J\)-factor. Equation (8) and (11) give
the splice-bit condition (2).

Two elementary consequences of the star definition carry the entire
argument.

First, in every BF row

\[
M_1+\cdots+M_6=2\mathbf1
\tag{13}
\]

each of \(e,g,h\) has load two. Therefore

\[
\#\{i:c(M_i)=j\}=2\qquad(j=0,1,2).
\tag{14}
\]

The six factors in (12) are thus exactly
\(F_0,F_0,F_1,F_1,F_2,F_2\), and they double-cover \(J\).

Second, any matching pair-sum equality

\[
M_1+M_2=M_3+M_4
\tag{15}
\]

has equal coordinate sums on \(e,g,h\). Since each matching chooses one of
these three edge objects, this is precisely

\[
\{c(M_1),c(M_2)\}_{\rm mult}
=
\{c(M_3),c(M_4)\}_{\rm mult}.
\tag{16}
\]

The colour factors are pairwise edge-disjoint, so (16) gives

\[
F_{c(M_1)}+F_{c(M_2)}
=F_{c(M_3)}+F_{c(M_4)}.
\tag{17}
\]

Thus every paired-splice equality in the \(H_0\) fibre lifts under the same
identity assignment (12). This includes both sequential orders and the two
equalities in the forced-intermediate branch. Initial, intermediate and
final rows all remain BF rows by (14).

It follows that every literal dependent two-splice fibre of \(H_0\) lifts
to \(H\). The reverse implication follows by factor projection from the
first section. Hence

\[
\boxed{
\text{literal dependent two-splice fibre exists in }H
\iff
\text{the corresponding fibre exists in }H_0.}
\tag{18}
\]

No finite slot-colouring obstruction remains: the endpoint-star colouring
\(c\) is a canonical solution for all rows and all literal identities at
once.

## Consequence

Insertion of any closed 3-edge-colourable cubic factor by a two-edge sum is
transparent not only to BF support and Tait states, but also to the complete
literal dependent-splice gate of Note 082. In particular such an insertion
cannot create or destroy the missing dependent fibre. Any minimum-order
exact-support obstruction relevant to that gate is irreducible under these
two-edge sums.

## The \(K_{3,3}\) owner rectangle as a corollary

For the factor and owner assignment of Notes 097--098, the canonical lift
uses the four one-factors avoiding the distinguished edge and supplies a
locally safe \(B\times X\) choice for every exterior distinguished-bit
pair.  Thus the selected \(2\times2\) bad rectangle of Note 097 is not
closed under the complete perfect-matching family of a genuine separable
two-sum.  The terminal-pairing compatibility of Note 098 remains a strict
boundary for the four selected row equations, but it is not a full-closure
obstruction: after closure, every remaining failure is exactly the failure
of the exterior factor.

The theorem does not prove that a dependent fibre exists in an
indecomposable exact-Case-XII pole.  It proves that a minimum counterexample
to that assertion cannot contain a two-edge-sum factor which is
three-edge-colourable.

