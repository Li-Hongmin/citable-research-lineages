> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case II

This note applies the global component-switch closure from
[Note 048](048-global-kempe-action-excludes-case-i.md) to a second exact
five-cut case in Mácajová--Mazzuoccolo--Tabarelli (MMT). The statement is
conditional on the published Appendix transcription and its ordered
semiedge convention.

## Statement

Let (H_{\\mathrm{II}}) be the 28 boundary types listed for MMT Case II.
No real cubic 5-pole has complete Berge--Fulkerson support exactly
(H_{\\mathrm{II}}).

Together with Note 046 and Note 048, this conditionally removes Cases I, II,
III, VI and XIII from the MMT 13-case list. The result is still only a
five-cut-branch reduction; it does not address the cyclically-6-connected
branch or prove the Berge--Fulkerson conjecture.

## Global action

For a labelled BF-colouring (arphi), a routing signature records the
endpoint pairing of every nonempty two-colour Kempe path system. Switching
one component preserves the complete route of the switched pair and every
route for a disjoint colour pair. No persistence rule is imposed on
overlapping pairs, and internal alternating cycles are omitted. Hence the
finite transition system is an over-approximation of the actual action on
all BF-colourings of a pole.

For every target boundary type, all colour relabellings carrying the switched
boundary labelling to the fixed representative are included. This is
necessary when the representative has a nontrivial colour stabilizer. The
greatest fixed point of this over-approximate transition system must contain
the routing signature of every actual colouring in an exact-support pole.

## Case-II fixed point

The 28 types of (H_{\\mathrm{II}}) produce 272 locally coherent signatures.
The two deletion rounds are:

| round | deleted types and numbers |
|---|---|
| 1 | ((12)(14):19, (12)(24):19, (13)(14):1, (13)(24):1, (13)(35):4, (14)(15):1, (14)(23):1, (14)(24):24, (14)(25):1, (15)(24):1, (15)(35):4, (23)(24):1, (23)(35):4, (24)(25):1, (25)(35):4, [14]:24, [24]:24, [35]:34) |
| 2 | ((14)(24):1, [14]:1, [24]:1, [35]:1) |

Thus the surviving fibres of
[
(14)(24),quad [14],quad [24],quad [35]
]
are all empty, although all four types belong to (H_{\\mathrm{II}}).
An actual exact-support pole would provide a nonempty transition-closed
family and therefore a surviving state for every supported type, which is
impossible.

## Certificate and scope

The stabilizer-complete certificate is

`../scratch/worker-mmtt-case-ii-global-action/verify_case_ii_global_kempe_action.py`

and ends with `CASE_II_GLOBAL_KEMPE_ACTION_EXCLUDED`. It reuses the
stabilizer-complete action engine verified in Note 048 and checks the complete
272-state Case-II system. No graph census, route-parity model, or edge-load
model is used.
