> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Terminal-tree reductions stop at BF-forced-intersecting edge pairs

Let $G$ be a minimum-order counterexample to the Berge--Fulkerson
conjecture with a Case-XII cycle-separating 5-edge-cut.  As in Note 019,
write $R=C_5$ for the cyclic side and $L$ for the other side.  Every proper
2-edge-cut of $L$, if one exists, cuts off either a one-vertex cubic 3-pole
containing one original terminal or a two-vertex cubic 4-pole containing
two original terminals.  This note determines the exact limit of deleting
these terminal trees by a whole-graph reduction that lifts all
six-matching Berge--Fulkerson colourings.

For a BF-colouring, the *label* of an edge is the two-subset of the six
perfect matchings containing it.  A local replacement is *BF-lifting* if
every BF-colouring of the replaced graph extends over the original gadget
with the same labels at its ports.

## The one-vertex terminal 3-pole is already minimal

If a cubic $k$-pole has $n$ vertices and $m$ proper edges, degree counting
gives

\[
3n=2m+k.
\]

Consequently every cubic 3-pole has positive odd order.  A connected one
has at least one vertex, and the terminal 3-pole consisting of a single
cubic vertex attains this bound.  Direct deletion leaves three degree
deficits in the surrounding graph, while no zero-vertex three-port cubic
replacement can repair them.  Thus no strictly smaller same-boundary
cubic gadget exists.  This closes only the direct local deletion: a
reduction using a larger part of the surrounding graph is not excluded.

## Exact lifting relation for the two-vertex terminal 4-pole

Let the terminal tree be the edge $uv$, with ports $p_0,p_1$ incident with
$u$ and $p_2,p_3$ incident with $v$.  Its five local matching patterns are

\[
\{uv\},\qquad \{p_i,p_j\}
   \quad(i\in\{0,1\},\ j\in\{2,3\}).
\]

Replacing it by two edges permits three pairings.  The same-side pairing
$01\mid23$ never lifts: a colour using either replacement edge would have
to use both ports incident with one original vertex, which is not a
matching.

Consider either cross pairing $02\mid13$ or $03\mid12$.  Let $F$ and $G$
be the two-element labels of its replacement edges and put
$q=|F\cap G|$.  If $q>0$, each colour in $F\cap G$ would use all four ports
after expansion and therefore fail to be a matching.  If $q=0$, the two
colours in $F$ take the first cross pair, the two in $G$ take the second,
and the remaining two colours take $uv$.  Every port and $uv$ is then
covered exactly twice.  Hence the complete relation is

\[
\begin{array}{c|ccc}
\text{pairing} & q=0&q=1&q=2\\ \hline
01\mid23 & \text{no}&\text{no}&\text{no}\\
02\mid13 & \text{yes}&\text{no}&\text{no}\\
03\mid12 & \text{yes}&\text{no}&\text{no}.
\end{array}
\]

In particular, a cross smoothing lifts a given BF-colouring if and only if
its two new edge labels are disjoint.

## At least one cross smoothing is bridgeless

Delete $u,v$ and all their incident edges, and call the remaining graph
$H$.  Its four port vertices are distinct.  Moreover, $H$ is connected:
the remaining core and $R=C_5$ are connected through the other three edges
of the original 5-cut.  Both cross smoothings are cubic and simple.  Any
coincidence of endpoints or any already existing proposed smoothing edge
would close a triangle or 4-cycle through $u,v$, contrary to $g(G)=5$.

Write

\[
M_1=02\mid13,\qquad M_2=03\mid12.
\]

A new smoothing edge is not a bridge because $H$ is connected, and every
nonbridge of $H$ remains a nonbridge.  If $e$ is a bridge of $H$, both
components of $H-e$ contain at least one port; otherwise $e$ would also be
a bridge of $G$.  Thus the only possible obstruction is the split of the
four ports induced by such a bridge.

Every perfect matching of four ports crosses every $1\mid3$ split.  It
fails to cross a $2\mid2$ split precisely when its two pairs are the two
blocks of that split.  Therefore $H+M_1$ can fail to be bridgeless only if
a bridge of $H$ induces $02\mid13$, while $H+M_2$ can fail only if a bridge
induces $03\mid12$.  Bridge-induced component splits in a connected graph
form a laminar family: after contracting its 2-edge-connected components,
they are the edge cuts of a tree.  The splits $02\mid13$ and $03\mid12$
cross, so they cannot both occur.  Consequently

\[
\boxed{\text{at least one of }H+M_1\text{ and }H+M_2\text{ is bridgeless}.}
\]

Every bridgeless cross smoothing is a smaller bridgeless cubic graph, so
minimum-order minimality of $G$ gives it a BF-colouring.  If any such
colouring assigned disjoint labels to the two new edges, the $q=0$ lift
would give a BF-colouring of $G$, a contradiction.  We obtain the sharp
residual conclusion:

> In every BF-colouring of every bridgeless cross smoothing, the two new
> edges have intersecting labels.

Thus the two new edges form a *BF-forced-intersecting edge pair*.  Graph
topology guarantees a safe smoothing, but minimality alone does not supply
the edge-pair flexibility needed to lift its BF-colouring.

## Absorbing the tree into $C_5$ does not repair the lift

The two terminals on $R$ are nonadjacent.  Absorbing the two-vertex tree
into $R$ produces a seven-vertex theta 5-pole: a 5-cycle together with a
second length-three path between two cycle vertices at distance two.
Replacing this pole by a fresh $C_5$, in any order of the five ports,
produces a smaller cubic graph.

This replacement is bridgeless.  The remaining core is connected, every
new cut edge has four alternative attachments, and every replacement-cycle
edge lies on the fresh $C_5$.  A bridge of the core has original cluster
attachments on both sides because $G$ was bridgeless; the replacement
cycle reconnects those same attachments.

Nevertheless the replacement is not BF-lifting.  A fresh $C_5$ admits the
type $(12345)$, in which one matching uses all five ports.  In the theta
pole such a matching would cover the two added path vertices and three
cycle port vertices.  The only two uncovered cycle vertices are the
nonadjacent endpoints of the added path, so they cannot be matched.  Hence
the theta pole does not admit $(12345)$, independently of port order.

Complete local enumeration strengthens this analytic obstruction.  The
fresh $C_5$ has 11 matching patterns and 16 BF types; the theta pole has
14 matching patterns and 26 BF types.  For none of the $5!=120$ port
permutations is the permuted $C_5$ type set contained in the theta type
set.  The maximum overlap is only 12 of 16, attained by 20 permutations.
For the first such permutation,

\[
(0,1,2,3,4)\longmapsto(0,1,2,4,3),
\]

the four missing types are

\[
(12345),\qquad(14)(45),\qquad(35)(45),\qquad[45],
\]

where $[45]=(45)(45)$.  Therefore even the best $C_5$ replacement would
need a global theorem ensuring that some BF-colouring of the smaller graph
avoids these four local types.  Minimum-order minimality gives existence
of a BF-colouring but does not control its local type.

## Boundary of the reduction route

There is no general terminal-tree deletion theorem at the presently
available local BF interface.  The one-vertex tree has no smaller
same-boundary cubic replacement.  A two-vertex tree always has at least
one structurally safe cross smoothing, but a BF-colouring lifts exactly
when the two new labels are disjoint; in a minimum counterexample they are
therefore forced to intersect in every BF-colouring.  The only natural
girth-five enlargement tested here, the theta-to-$C_5$ replacement, fails
for all 120 port orders and already fails analytically on $(12345)$.

This is a strict route closure, not an exclusion of Case XII and not a
counterexample to the Berge--Fulkerson conjecture.  A continuation needs
either a BF edge-pair flexibility theorem that breaks forced intersection,
or a theorem controlling the four missing local $C_5$ types.  The finite
local statements are certified by
`scratch/worker-verify/terminal_tree_bf_reductions.py`, whose terminal
marker is `TERMINAL_TREE_BF_REDUCTIONS_OK`; the bridgelessness and
$(12345)$ obstructions above are analytic and do not depend on enumeration
of large graphs.
