> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A Hamilton-path \(K_{3,3}\) end-pair row cannot root at \(x\)

In the \(|U|=r=5\) tree-exterior profile of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), take the remaining Hamilton-path spanning tree of \(K_{3,3}\). Write its bipartition as \(\{x,y,z\}\sqcup\{r,s,t\}\), with tree path
\[
x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t,
\]
where \(u_i\) has shore port \(p_i\). The four exterior marked edges are
\[
a=xs,\qquad b=xt,\qquad c=yt,\qquad d=zr.       \tag{1}
\]
The fifth mark \(e\) lies in the arbitrary six-port shore. Consider the two labelled Case-XII pentagons with \(e\)-neighbour pair \(\{a,d\}\):
\[
\begin{array}{c|c}
S_5=e-a-b-c-d-e&T_5=\{ac,ad,eb,ec,bd\},\\
S_6=e-a-c-b-d-e&T_6=\{ab,ad,eb,ec,cd\}.
\end{array}                                                   \tag{2}
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ad)\) row for either pentagon and excludes every double-\(T_i\) row.

**Root-exclusion theorem.** In any genuine \((ea)(ad)\) row compatible with complete exact-Case-XII support (2), the zero-port state-\(ea\) triple must be rooted at \(s\). In particular, a row rooted at \(x\) is impossible, regardless of the shore order or cycle rank.

**Proof.** Name the state-\(ea\) triple \(P\), state-\(ad\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(d\) matching \(D\), and singleton-\(a\) occurrences \(A_1,A_2\). The shore quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes \(P\) zero-port, and Note 358 gives only roots \(x,s\). Since \(R=ad\in T_i\), switching \(P\) with either \(A_j\) must give \(ed\in S_i\); the alternatives \(eb,ec\) would form double-\(T_i\) rows. The \(a\)--\(d\) path is wholly exterior by the zero-port argument of [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md).

Suppose \(P\) is rooted at \(x\). Its exterior restriction uses \(t_ax\), terminals \(b,c,d\), and the tree edges \(ru_0,yu_1,su_2,zu_3,tu_4\). The only possible \(a\)--\(d\) routes are
\[
H:a-t_a-x-u_0-r-t_d-d
\]
and the longer route continuing from \(r\) through \(u_1,y,u_2,s,u_3,z\) before reaching \(d\). On the longer route, a singleton-\(a\) matching has already used both \(x,y\). It would have to cover mark \(b=xt\) through \(t\), and mark \(c=yt\) through the same vertex \(t\), impossible. Hence both \(A_j\) use \(H\). Each selects \(t_bt,t_cy,t_dr,xu_0\).

The terminal and edge loads now force \(E,D\) onto \(t_as,t_bx,t_ct\), while \(R,E\) use \(t_dz\) and \(P,R\) use \(t_ax\). Thus \(E\) matches \(s,x,t,z\) through those four marked halves and has just two exterior tree choices: at \(r\), one of \(ru_0,ru_1\), and at \(y\), one of \(yu_1,yu_2\). The pair \((ru_1,yu_1)\) is impossible because both edges meet \(u_1\).

Switch \(P,A_1\) along \(H\). The resulting state-\(ed\) triple \(P'\) has exactly the same complete shore matching \(Q=P|_Z\). Following the exterior legs in \(P\triangle E\) and \(P'\triangle E\) gives the table below; the port lists follow the displayed terminal order.

| \(E\)'s tree edges | Before \(H\): \(P\triangle E\), \(b,c,d\) | After \(H\): \(P'\triangle E\), \(a,b,c\) |
|---|---|---|
| \(ru_0,yu_1\) | \(p_2,p_4,p_3\) | \(p_2,p_3,p_4\) |
| \(ru_0,yu_2\) | \(p_1,p_4,p_3\) | \(p_1,p_3,p_4\) |
| \(ru_1,yu_2\) | \(p_0,p_4,p_3\) | \(p_3,p_0,p_4\) |

For \(S_5\), the original \(e\)-path must end at \(b\), since only \(ab\) among \(ab,ac,ad\) belongs to \(S_5\). Each table row makes the same shore \(e\)-path end at \(a\) or \(b\) after \(H\), producing \(ad\in T_5\) or \(bd\in T_5\) beside \(R\). For \(S_6\), the original \(e\)-path must end at \(c\), but all three rows leave it at \(c\), producing \(cd\in T_6\) beside \(R\). This excludes root \(x\). \(\square\)

At root \(s\), the exterior \(a\)--\(d\) path must use either \(a-t_a-s-u_2-y-u_1-r-t_d-d\) or \(a-t_a-s-u_3-z-t_d-d\); this theorem makes no claim that either route can occur in a complete exact-Case-XII pole. It is a one-row necessary condition for just the two pentagons (2). Other pentagons, the Hamilton-path profile as a whole, the triangular prism and general Case XII remain open. The proof is hand-derived and awaits independent review; no local mathematical recomputation was used.
