> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right pure AJ switch excludes the four-one near-bipartite core

Keep the genuine right \((ea)(ad)\) row of [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md) in the central-path exterior, with complete exact-Case-XII support and allowed pentagon \(S=e-a-b-d-c-e\). Suppose the unmarked core \(C-g\) is bipartite, \(g\) has both ends in side \(B\), the marked edge \(e=vw\) has \(v\in B,w\in R\), and **all five proper shore ports** \(A,I,D,H,J\) are based in \(R\). This is the \((|B|-|R|,p_B,p_R)=(-1,0,5)\) profile of [Note 282](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md), stated here as an explicit hypothesis. Colour \(t_e\) in \(R\). The full five-pole becomes bipartite on deleting the two proper edges \(g,t_ew\); its terminal \(e\) is in \(R\), and \(a,b,c,d\) are in \(B\).

**Theorem.** This profile cannot contain the genuine right \((ea)(ad)\) row under complete exact-Case-XII support. No noncollision assumption is needed.

**Proof.** Let \(X\) be the right row's zero-port shore matching and \(Z\) its singleton-\(e\) shore matching. The core matching balance of Note 282 makes \(X\) select \(t_ew\) and avoid \(g\). The three \(R\)-based proper ports \(A,H,J\) of \(Z\), together with its selected \(E\) terminal, make \(Z\) select \(g\) by the same balance. The pure \(ea\)-half of Note 297 forces the shore paths of \(X\triangle Z\) to pair \(EH\mid AJ\).

The \(E\)--\(H\) path begins with \(t_ew\in X\), and the \(A\)--\(J\) path avoids it. Both port semiedges of the \(A\)--\(J\) path belong to \(Z\), so its internal proper-edge segment has odd length. Its endpoints are both in \(R\). Every proper shore edge except \(g,t_ew\) crosses the \(B/R\) colouring; therefore the odd internal \(R\)--\(R\) segment must contain \(g\). Switch this complete \(A\)--\(J\) alternating path into \(X\). The result is an actual shore matching \(N\) with
\[
             \operatorname{ports}(N)=AJ,\qquad g,t_ew\in N.       \tag{1}
\]

The exterior has the following independent singleton-\(c\) matching mask with precisely the selected shore ports \(A,J\), already displayed in [Note 298, equation (4)](298-the-right-central-ad-row-forces-s-tait-in-the-three-two-near-bipartite-core.md):
\[
 M_c=\{c_{\rm term},a:\Sigma,b:A_{\rm ext},d:E_{\rm ext},
             1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4\}.       \tag{2}
\]
The four marked exterior vertices are covered by \(a:\Sigma,b:A_{\rm ext},c_{\rm term},d:E_{\rm ext}\); the five branch vertices by \(b:A_{\rm ext},1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},d:E_{\rm ext}\); and \(u_1,u_2,u_3,u_4\) by \(1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4\). Thus gluing (1) to (2) gives a complete actual singleton-\(c\) perfect matching \(P_c\) selecting both \(g,t_ew\).

Every proper edge of the complement of \(P_c\) lies in the bipartite graph \(H-\{g,t_ew\}\). Its closed cycles are even, so alternate two colours on its complement paths and cycles to extend \(P_c\) to a Tait colouring. Among the four terminals outside the singleton class \(c\), one is \(e\in R\) and three are \(a,b,d\in B\). One complementary terminal path therefore joins \(e\) to one of \(a,b,d\); the other joins two of \(a,b,d\). Along this latter exception-free \(B\)--\(B\) path, the two terminal semiedges receive different complementary colours. Switching those colours along the path gives two actual Tait states joining \(c\) to its two endpoints. But \(c\) has only one allowed neighbour among \(a,b,d\), namely \(d\). At least one switched state lies in \(T\), contrary to exact Case XII. \(\square\)

Together with [Note 331](331-the-right-pure-path-excludes-the-dj-near-bipartite-core.md) and Note 301's \(IJ\) exclusion, this removes both stated numerical profiles **when \(g\subset B\) and the marked edge crosses the bipartition** in the left-\(ac\)/right-\(ad\) central-path setting. Notes 276, 277, and 281 do not justify dropping those explicit side hypotheses for the right row; cases with a different mark-side placement, a bipartite unmarked core, or no such edge \(g\) remain. The proof is symbolic and awaits independent verification; no local computation or OMEN run was used.
