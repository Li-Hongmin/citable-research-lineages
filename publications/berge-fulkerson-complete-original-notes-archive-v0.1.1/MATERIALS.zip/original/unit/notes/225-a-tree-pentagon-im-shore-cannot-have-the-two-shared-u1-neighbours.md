> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(I_m\) tree--pentagon shore cannot put both shared ports next to \(u_1\)

Work in the minimum-host, girth-at-least-five \(I_m\) quotient of
[Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md).
Let \(A^\circ\) be the three-vertex tree with centre port \(u_1\)
and end groups \(\{u_2,z\}\mid\{x,p\}\). Let \(B^\circ\) be an
ordinary pentagon on the ports \(u_1,u_2,z,y,q\). Then

\[
\boxed{u_1u_2,\ u_1z\text{ consecutive on the }B\text{-pentagon}
\quad\Longrightarrow\quad
\text{the outer five-pole does not have exact Case-XII support}.} \tag{1}
\]

Here consecutive means that both displayed pairs are edges of the
pentagon's port cycle. Its five Tait states are precisely those five
edges, and overlaying any two of its three-edge-colourings supplies
an actual BF row on the two corresponding states. Every pair of the
four cross-end Tait states of the tree similarly has an actual row.
All gluing below therefore starts with genuine six-perfect-matching
shore rows; the slot tables check the exterior edges.

The port cycle has only two possible orientations after fixing the
neighbours of \(u_1\):
\[
u_1-u_2-y-q-z-u_1,\qquad
u_1-u_2-q-y-z-u_1.                                      \tag{2}
\]

## Three connector transports

The first transport works in both orientations. The tree type
\((u_2x)(zx)\) and pentagon type \((u_1u_2)(u_1z)\) have these
independently relabelled boundary occurrences:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1zp\) | \(u_2\) |
| 2 | \(u_1u_2p\) | \(z\) |
| 3 | \(u_2\) | \(zyq\) |
| 4 | \(z\) | \(u_2yq\) |
| 5, 6 | \(x\) | \(u_1\) |

With \(R_i=u_iw_i\) and \(D_x,D_y,D_p,D_q\) the singleton-side
mark halves, the labels are
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)=(34,56;12,56,34,12),
\quad (T_z,T_x,T_y,T_p,T_q)=(56,34,12,56,56).              \tag{3}
\]
Thus the outer relation contains \([xy]\).

For the second orientation in (2), use the tree type
\((u_2x)(u_2p)\) and pentagon type \((qy)(qu_2)\):

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1zp\) | \(y\) |
| 2 | \(u_1zx\) | \(u_2\) |
| 3 | \(x\) | \(u_1u_2z\) |
| 4 | \(p\) | \(u_1zy\) |
| 5, 6 | \(u_2\) | \(q\) |

Here
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)=(56,14;14,23,56,23),
\quad (T_z,T_x,T_y,T_p,T_q)=(56,56,56,23,14).             \tag{4}
\]
Consequently \([pq]\) occurs.

The third transport uses the tree type \((u_2x)(zp)\) and
the pentagon type \((yq)(u_1z)\), again available in the second
orientation:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1zp\) | \(y\) |
| 2 | \(u_1u_2x\) | \(q\) |
| 3 | \(z\) | \(u_2yq\) |
| 4 | \(p\) | \(u_1u_2z\) |
| 5 | \(u_2\) | \(u_1\) |
| 6 | \(x\) | \(z\) |

Its labels are
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)=(36,16;14,25,23,45),
\quad (T_z,T_x,T_y,T_p,T_q)=(25,35,46,56,16).             \tag{5}
\]
Outer slots 5 and 6 have boundaries \(\{z,x,p\}\) and
\(\{y,p,q\}\), so they give the actual pair
\[
                         \boxed{(yq)(xz).}                 \tag{6}
\]

In each of (3)--(5), the two shore-half labels at the direct
\(z\)-mark are disjoint. At each \(u_i,w_i\) and each of the four
other marked subdivision vertices the three incident labels
partition \([6]\). These checks prove load two on every exterior
edge; the input shore rows already give load two internally.

## Both cyclic orders fail

For \(u_1-u_2-y-q-z-u_1\), the actual pentagon type
\((yu_2)(yq)\) invokes [Note 216, (5)](216-a-tree-rstar-im-shore-forces-a-single-minority-port-placement.md),
whose slot constructions use only that type, and forces outer
\([py]\) and \([yq]\). Together with \([xy]\) from (3),
the allowed Case-XII loop cycle would give \(y\) three
neighbours \(p,q,x\), impossible.

For \(u_1-u_2-q-y-z-u_1\), the actual type \((yz)(yq)\)
invokes [Note 216, (4)](216-a-tree-rstar-im-shore-forces-a-single-minority-port-placement.md)
and forces \([yz]\). Equations (3)--(4) additionally force
\([xy]\) and \([pq]\). A five-cycle on \(z,y,x,p,q\)
containing these three edges is exactly one of
\[
 z-y-x-p-q-z,\qquad z-y-x-q-p-z.                            \tag{7}
\]
Both omit \(yq\) and \(xz\); hence the actual pair (6) is a
forbidden \(T\)--\(T\) type. This proves (1). \(\square\)

This removes the two relative pentagon port cycles in (2) for the
stated tree end partition. It does not settle the other pentagon
orders, the other admissible tree end partition, the other quotient
types, or full exact Case XII. The analytic rows have not received
an independent check; no graph enumeration was run.
