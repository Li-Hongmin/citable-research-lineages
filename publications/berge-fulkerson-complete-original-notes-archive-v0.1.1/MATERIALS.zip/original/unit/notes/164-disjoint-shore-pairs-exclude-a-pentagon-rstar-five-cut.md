> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disjoint shore pairs exclude a pentagon--R-star five-cut

In the marked five-cut branch of [Note 163](163-five-cut-perfect-matching-closure-composes-shore-bf-relations.md), one shore cannot be an ordinary 5-cycle while the other has the published Case-XIII \(R^*\) boundary relation. The proof uses an exact six-slot composition: a pair of **disjoint** missing-pair states supported on both shores forces four terminal loop states. No five-cycle of allowed Case-XII loops can contain all four. This excludes the entire pentagon--\(R^*\) branch for every relative terminal labelling. [Note 165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md) subsequently excludes the mixed \(L^*\)--\(R^*\) and three-vertex-tree--\(R^*\) branches. The analytic argument awaits independent checking.

## A common disjoint type creates a four-cycle of loops

Let \(p=\{a,b\}\) and \(q=\{c,d\}\) be disjoint missing-pair states. Suppose both shore five-poles in Note 163 admit the BF type \((p)(q)\). Permute the six matching slots of each actual shore colouring as follows:

| slot | first shore boundary | second shore boundary | terminal boundary |
|---|---|---|---|
| 1 | triple missing \(ab\) | singleton \(b\) | singleton \(a\) |
| 2 | triple missing \(cd\) | singleton \(d\) | singleton \(c\) |
| 3 | singleton \(b\) | triple missing \(ab\) | singleton \(a\) |
| 4 | singleton \(d\) | triple missing \(cd\) | singleton \(c\) |
| 5 | singleton \(a\) | singleton \(c\) | triple missing \(ac\) |
| 6 | singleton \(c\) | singleton \(a\) | triple missing \(ac\) |

Every pair of shore boundary subsets in a row is disjoint, so the precise gluing criterion (1) of Note 163 produces terminal loop \([ac]\). Choosing either endpoint of \(p\) in place of \(a\), and either endpoint of \(q\) in place of \(c\), gives all four loops
\[
\boxed{[ac],\ [ad],\ [bc],\ [bd]\in\operatorname{BFsupp}(H).} \tag{1}
\]
Their missing-pair states form a four-cycle \(K_{2,2}\) in the graph on terminal labels. The five loops permitted by exact Case XII form a 5-cycle \(S\), which contains no four-cycle. Therefore the two shore supports of an exact-Case-XII five-cut cannot have a common type \((p)(q)\) with disjoint \(p,q\).

## Applying the obstruction to a pentagon and \(R^*\)

For an ordinary 5-cycle shore, its five Tait missing-pair states form a 5-cycle \(T_0\) on the terminal labels. It admits every pair and loop type on those five states. The Case-XIII \(R^*\) relation in the [2026 appendix](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) admits exactly the 25 pair types across the partition
\[
P=\{13,14,24,35,45\},\qquad
Q=\{12,15,23,25,34\}                               \tag{2}
\]
of the ten missing-pair states, up to a permutation of terminal labels. Thus a type \((p)(q)\) is present in \(R^*\) exactly when \(p,q\) lie in opposite classes.

If the two shores formed exact Case XII, every two disjoint states \(p,q\in T_0\) would have to lie in the **same** class of (2); otherwise the common disjoint type would force the forbidden four-cycle (1). But the disjointness graph of the five edges of a 5-cycle is again a connected 5-cycle. Equality of partition class along every edge of that graph makes all five states of \(T_0\) lie in one class. As each class has size five, that class would equal \(T_0\).

Neither class of (2) is a 5-cycle on the terminal labels: in \(P\) the vertex degrees are \((2,1,2,3,2)\), while in \(Q\) they are \((2,3,2,1,2)\). Terminal relabelling preserves the degree multiset. Hence neither can equal \(T_0\), a contradiction. We conclude
\[
\boxed{\text{A minimum-host exact-Case-XII marked five-cut cannot have shores of types }C_5\text{ and }R^*.} \tag{3}
\]
This obstruction is on the complete graph-induced BF boundary support: each input type is witnessed by an actual six-perfect-matching row, and the slot permutation and gluing in (1) give actual forbidden output rows. It does not use or claim a common \(B_2+C_4\) seed in the surviving branches.
