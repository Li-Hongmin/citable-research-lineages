> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last clean Hamilton-prism row cannot root its forbidden \(ab\)-triple at \(b\)

Keep the Hamilton two-spoke prism exterior and labels of [Note 433](433-the-last-clean-hamilton-prism-pair-has-one-allowed-root-and-two-marked-masks.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                              \tag{1}
\]
Assume complete exact Case-XII BF support with forbidden \(e\)-labels \(\{eZ,eW\}\), and take a real required mixed row \((eW)(eY)\). Write \(P=eW\) for its forbidden triple, \(R=eY\) for its allowed triple, \(K=Y,J=W\) for the marked singletons, and \(D_0,D_1=e\) for the singleton-\(e\) occurrences. The shore has arbitrary order and matching family.

> **Root exclusion.** In such a row, \(P=eW\) cannot be rooted at \(b\). Consequently a putative exact-Case-XII pole with this exterior must realize its required \((eW)(eY)\) type with \(P=eW:a\) and \(R=eY:C\).

Suppose \(P=eW:b\). [Note 433](433-the-last-clean-hamilton-prism-pair-has-one-allowed-root-and-two-marked-masks.md) proves that \(R=eY:C\), that switching the \(Y\)-starting exterior path of \(R\triangle K\) yields \(R'=eX\) with the **same complete shore matching** as \(R\), and that one of the two unchanged singleton-\(e\) occurrences, call it \(D\), has
\[
D:Y:C,\quad Z:c,\quad W:a.                           \tag{2}
\]
The \(Y\to X\) switch has only two possibilities:
\[
\begin{array}{c|c|c}
&\text{path}&R'\text{ root}\\ \hline
A&Y-t_Y-C-u_2-A-t_X-X&A\\
B&Y-t_Y-C-u_3-B-t_X-X&B
\end{array}.                                                \tag{3}
\]
The allowed pentagons are \(S_1=e-X-Z-W-Y-e\) and \(S_2=e-X-W-Z-Y-e\). To avoid a forbidden \(T\)--\(T\) completion beside unchanged \(P\), the same shore \(e\)-path against \(D\) must select
\[
\begin{array}{c|cc}
&R=eY&R'=eX\\ \hline
S_1&W&Z\\
S_2&Z&W
\end{array}.                                                \tag{4}
\]

Here is a direct port trace. In \(D\), if \(X:A\), vertex \(A\) is covered at the mark and \(B\) uses \(B u_3\) or \(B u_4\); if \(X:B\), vertex \(B\) is covered at the mark and \(A u_1\) is forced because \(P,R\) saturate \(A u_2\). Vertex \(b\) uses \(b u_4\) or \(b u_5\), as its \(W\)-mark is taken at \(a\). Against \(R=eY:C\), the \(W\)-terminal arm follows \(W-t_W-a-u_1\), ending at \(p_1\) when \(D:X:A\) and at \(p_2\) when \(D:X:B\). The \(Z\)-arm follows \(Z-t_Z-c-u_5\): it ends at \(p_5\) if \(D:b u_4\), at \(p_3\) if \(D:b u_5,Bu_4\), and at \(p_4\) if \(D:b u_5\) without \(Bu_4\). In particular it never exits at \(p_1,p_2\).

For route \(A\), \(R'=eX:A\). Its \(Z\)-arm has exactly the same exit as under \(R\). Its \(W\)-arm exits at \(p_1\) if \(D:X:A\); if \(D:X:B\), it continues through \(a-u_1-A-X-B-u_3-p_3\) and exits at \(p_3\). For route \(B\), \(R'=eX:B\). Its \(W\)-arm exits at \(p_1\) or \(p_2\), according as \(D:X:A\) or \(X:B\). Its \(Z\)-arm is unchanged except in the case \(D:X:A,b u_5,Bu_4\), when it follows \(Z-c-u_5-b-u_4-B-X-A-u_2-p_2\) instead of exiting at \(p_3\). These statements give the demanded-exit table; braces bound all possible exits in that entry:
\[
\begin{array}{c|c|cc}
\text{route}&D\text{ at }X&S_1:(W_R,Z_{R'})&S_2:(Z_R,W_{R'})\\ \hline
A&A&(p_1,\{p_3,p_4,p_5\})&(\{p_3,p_4,p_5\},p_1)\\
A&B&(p_2,\{p_4,p_5\})&(\{p_4,p_5\},p_3)\\
B&A&(p_1,\{p_2,p_4,p_5\})&(\{p_3,p_4,p_5\},p_1)\\
B&B&(p_2,\{p_4,p_5\})&(\{p_4,p_5\},p_2)
\end{array}.                                                \tag{5}
\]
Every pair of demanded port sets in (5) is disjoint. The traced \(W,Z\) terminal arms reach distinct exterior ports in each comparison. Since a zero-port triple against a singleton-\(e\) occurrence has three marked terminal ends and three exterior port ends, its remaining marked arm reaches the third port; there is no exterior port-to-port detour. The shore restrictions of \(R,R'\) are identical, so their \(e\)-path against unchanged \(D\) has the same first proper shore exit. Equation (4) would require that exit to belong to both disjoint entries of some row of (5), a contradiction. \(\square\)

The proof uses an actual complete six-matching row and does not assume a clean shore matching or any bound on shore order, complement cycles or path lengths. It closes only the \(b\)-root of this required row. The remaining \(P=eW:a\) root, other forbidden pairs, the full exact-Case-XII obstruction and Berge–Fulkerson remain open. This is a hand proof awaiting independent review; no OMEN or local mathematical recomputation was used.
