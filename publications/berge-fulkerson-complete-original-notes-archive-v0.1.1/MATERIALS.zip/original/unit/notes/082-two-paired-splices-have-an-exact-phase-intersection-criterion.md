> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two paired splices have an exact phase-intersection criterion

The cross-carrier alignment left open by
[Note 081](081-selected-perfect-matching-negative-support-does-not-force-nonoverload.md)
has a complete normal form when at most two paired splices are allowed.  The
classification below applies to the anchored target cell \((35,23)\); the
other anchored target is obtained by relabelling.

Fix an actual BF row

\[
 q+r+B+X+P_3+P_5=2\mathbf 1,                     \tag{1}
\]

where (P_3,Y) have singleton boundary (3), and (P_5,D) have
singleton boundary (5).  The desired literal row is

\[
 q'+r'+B+X+Y+D=2\mathbf 1.                        \tag{2}
\]

All symmetric differences between same-boundary singleton matchings are
unions of proper alternating cycles.

## One replacement

For current (P), desired (widehat P), and a current row companion
(N), put

\[
 \operatorname{Align}(N;P\to\widehat P)
 \iff
 N\cap(P\triangle\widehat P)
   =\widehat P\cap(P\triangle\widehat P).          \tag{3}
\]

Then (3) is necessary and sufficient for

\[
 N'=N+P-\widehat P                                \tag{4}
\]

to be a perfect matching.  In that case

\[
 N+P=N'+\widehat P,
\]

so switching every component of (P\triangle\widehat P) between the
two occurrences is an exact paired splice preserving the six-row load.

There is an equivalent edge-label formulation.  On every
(widehat P)-phase edge of (P\triangle\widehat P), exactly two of the
five row companions of (P) occur, because (1) has load two there and
(P) does not.  Label that edge by this two-subset of companions.  A
companion (N) satisfies (3) if and only if it belongs to the intersection
of all these labels.  Thus rowwise load two gives nonempty labels but does
not give their global intersection.

## Two sequential replacements

Interpret one splice as installing one of the two desired singleton
matchings.  For the order (P_3\to Y) followed by (P_5\to D), the
following condition is necessary and sufficient.

Choose a first companion (N) among the other five occurrences in (1)
such that

\[
 \operatorname{Align}(N;P_3\to Y),
 \qquad N_1=N+P_3-Y.                               \tag{5}
\]

If (N\ne P_5), retain the current (P_5) and choose a second companion
(M) in the intermediate row, distinct from (P_5), such that

\[
 \operatorname{Align}(M;P_5\to D),
 \qquad M_1=M+P_5-D.                               \tag{6}
\]

Here (M) may be the updated occurrence (N_1).  If (N=P_5), the first
splice has instead changed the boundary-five occurrence to

\[
 P_5^{(1)}=P_5+P_3-Y,
\]

and the exact second condition is

\[
 \operatorname{Align}(M;P_5^{(1)}\to D)            \tag{7}
\]

for another occurrence (M) in the intermediate row.  Conditions
(5)--(7), together with the symmetric alternative which installs (D)
first and (Y) second, are exactly the two possible sequential-splice
orders.  Sufficiency follows by (4) twice.  Necessity follows because each
paired splice preserves the sum of its two participating occurrences, so
its altered companion is forced by (4) and must have the phase in (3).

The fixed literal occurrences (B,X) cannot serve as a companion in a
successful two-step sequence unless they are touched in both steps.  If,
for example, (B) is changed and restored while the other endpoints install
(Y,D), summing the two pair equalities gives

\[
 P_3+P_5=Y+D.                                     \tag{8}
\]

But (8) would turn (1) directly into the literal row (2), impossible when
(BDXY) has a load-three edge.  Hence under the overload hypothesis the
effective companions in (5)--(7) are the two triple occurrences (q,r),
possibly with one of them used in both steps, or the other wrong singleton
in the first chain step followed by (q) or (r).

If arbitrary preparatory splices are allowed rather than requiring each
step to install one desired singleton, there is one additional path shape.
For example, a first splice can replace (P_3) by an intermediate (Z_3)
and a second splice can replace the pair (Z_3,P_5) simultaneously by
(Y,D).  The intermediate is not free: it is forced edgewise by

\[
 Z_3=Y+D-P_5.                                     \tag{9}
\]

Thus this path exists exactly when (Z_3) is a perfect matching and some
companion (N\in\{q,r\}) makes

\[
 N+P_3-Z_3                                        \tag{10}
\]

a perfect matching.  There is a symmetric condition with
(Z_5=Y+D-P_3).  Equations (3), (9), and (10) therefore also give a
necessary and sufficient test for the fully unrestricted two-splice
interpretation.

## Completeness of the two-splice case list

Here the occurrences carrying the literal matchings (B) and (X) are
required to finish again as those same literal matchings.  This is the
pointwise interpretation of replacing ((P_3,P_5)) by ((Y,D)) in the fixed
row (1).  Under that interpretation the preceding case list is complete.

Indeed, draw one edge between the two occurrence positions touched by each
nontrivial paired splice.  A splice preserves the sum of its two endpoints;
in particular, if one endpoint is unchanged then so is the other.  Apart
from the degenerate case in which (P_3=Y) or (P_5=D) already, both singleton
positions must therefore be incident with the graph of the at most two
splice edges.  Up to reversing their order, there are only the following
possibilities.

1.  The two edges are disjoint.  Each target singleton is installed by its
    own companion.  This is (5)--(6), with the second companion distinct
    from the first.
2.  The two edges form a length-two path whose middle vertex is (q) or
    (r).  The first splice updates that triple occurrence and the second
    reuses the update.  This is again (5)--(6), now with (M=N_1), or its
    reversed-order analogue.
3.  One splice edge joins the two wrong-singleton positions and the other
    joins one of them to an outside companion.  If the singleton--singleton
    edge is used first, the singleton position not touched by the second
    splice must already receive its desired value; this is branch (7), or
    its symmetric version.  If the outside-companion edge is used first,
    then either the remaining singleton was already desired (a degenerate
    one-replacement case), or the second splice must install (Y,D)
    simultaneously.  In the latter case conservation of the second pair
    forces (9), and conservation of the first forces (10).  This is
    precisely the forced-intermediate case.
4.  The middle vertex is one of the fixed literal occurrences (B,X).
    Restoring that occurrence and summing the two pair equalities forces
    (8), contradicting the overload hypothesis.

Two repeated splice edges between the singleton positions, or one splice
between them together with a disjoint edge elsewhere, also force (8).
Any edge not incident with either still-wrong singleton is irrelevant to
installing the target.  Finally, if one target singleton is already present,
the problem reduces to the one-replacement test (3); equivalently it is
included above by allowing the other replacement to have empty symmetric
difference.  Thus there is no additional shape in which a first splice
changes a triple occurrence and a second splice somehow outputs both
desired singletons: boundary classes are preserved at occurrence positions,
so both singleton positions must themselves be endpoints of that second
splice, which is exactly case 3.

## What exact positive support supplies

The fixed (t=23) half of the literal pivot row is

\[
 r_{23}+B+X.
\]

Column saturation supplies (1) at state (35), but only asserts the
existence of some (q,P_3,P_5).  It gives no information about the
two-subset labels on (P_3\triangle Y) or (P_5\triangle D), and hence no
nonempty intersection in (3).

The only other positive cell with the singleton boundary multiset of
(B,D,X,Y) is the same cell itself; the repeated boundary (3) admits no
alternative pair-state partition.  Note 057 does not have ((35,23)) as
one of its overlap-to-disjoint source rows.  Its transports therefore do not
add a companion to (5)--(7).

Other positive cells can contain additional singleton matchings in boundary
classes (3) and (5), but neither support nonemptiness nor the row
transport theorem identifies their component phases with the particular
(P_3,Y,P_5,D) in (1).  Complete perfect-matching closure ensures that an
aligned switch, once found, is an actual matching; it does not force the
label intersections in (3).

## Sharp additional hypothesis

The minimum sufficient and necessary extra hypothesis for two sequential
splices is exactly one of the two ordered systems (5)--(7).  In words:

> one of (q,r), or its first-splice update, must carry the desired phase
> on every component of the first singleton difference, and a remaining
> triple companion must carry the desired phase on every component of the
> second difference; alternatively the first wrong singleton can carry the
> first desired phase and pass the resulting boundary-five or boundary-three
> occurrence to a triple companion in the second splice.

For unrestricted preparatory splices, add the forced-intermediate test
(9)--(10).  These are component-alignment hypotheses, not consequences of
the forty type-support flags.  No argument from the present exact-support,
closure, or Note-019 assumptions is known to force any of them, and no real
exact-Case-XII pole is known which violates them.  The stated target
implication therefore remains undecided at this precise phase-intersection
gate.
