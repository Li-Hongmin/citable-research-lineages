> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adjacent \(bc,Cc\) forbidden labels exclude the two indirect \(bc,ab\) roots

Use the marked two-spoke prism of [Notes 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md) and [414–415](415-the-adjacent-bc-cc-second-direct-root-has-one-real-exterior-boundary.md). Suppose the forbidden \(e\)-labels are \(\{bc,Cc\}\). The two possible allowed pentagons are
\[
S_\alpha=e-ab-bc-Cc-AC-e,\qquad
S_\beta=e-ab-Cc-bc-AC-e.                                  \tag{1}
\]

> **Root-pair exclusion.** For either pentagon in (1), no actual six-perfect-matching \((e\,bc)(e\,ab)\) row has forbidden triple \(P=e\,bc:b\) and allowed triple \(R=e\,ab:b\). The shore may have arbitrary size, cycle rank, and port-path lengths.

Let \(K\) be singleton-\(ab\), \(J\) singleton-\(bc\), and \(D_0,D_1\) singleton-\(e\). Both rooted triples have tree slots
\[
P,R:(A,C,a,B,c)\quad\text{on }(u_1,\ldots,u_5).         \tag{2}
\]
Thus \(P,R\) saturate \(Au_1,Cu_2,au_3,Bu_4,cu_5\). In \(R\triangle K\), the path starting at \(ab\) must end at \(AC\); ending at \(bc\) or \(Cc\) would create a second forbidden triple alongside unchanged \(P=e\,bc\).

At \(b\), \(K\) cannot take \(bc:b\), which would end that path at \(bc\). It therefore takes \(bu_4\). The path then follows \(ab-t_{ab}-b-u_4-B\). Since \(Bu_4\) is saturated, \(K\) covers \(B\) through \(Bu_1\) or \(Bu_2\). The \(Bu_2\) route reaches \(C\): taking \(Cc:C\) ends at forbidden \(Cc\), whereas taking \(AC:C\) occupies \(C\) and forces \(c\) onto \(Cc:c\), leaving neither end free to cover the \(bc\) subdivision. Hence \(K:Bu_1\), and its route reaches \(A\). At \(A\), taking \(Au_3\) continues through \(a,u_5,c\) to forbidden \(bc\) or \(Cc\). Thus \(K:AC:A\), and the only allowed path is wholly exterior:
\[
ab-t_{ab}-b-u_4-B-u_1-A-t_{AC}-AC.                 \tag{3}
\]
The remaining mark and vertex slots force
\[
K:\quad AC:A,\ Cc:C,\ bc:c,\ ab\text{ terminal},\quad
Bu_1,\ bu_4,\ au_5;\qquad K\text{ uses ports }p_2,p_3.  \tag{4}
\]
Switching (3) gives \(R'=e\,AC:A\) with exactly the same complete shore matching as \(R\).

Since \(P,R\) saturate \(cu_5\) and \(K:bc:c\), singleton \(J\) must take \(Cc:c\), and then \(AC:C\). At \(b\), \(J\) takes \(ab:b\) or \(bu_4\). In either case **some** singleton-\(e\) occurrence \(E\) takes both \(ab:a\) and \(bc:b\):

* If \(J:ab:b\), the \(ab\) subdivision makes both \(D_i\) take \(ab:a\), while the \(bc\) subdivision makes one of them take \(bc:b\).
* If \(J:bu_4\), exactly one \(D_i\) takes \(ab:a\). This occurrence cannot also take \(ab:b\), and \(K,J\) saturate \(bu_4\), so it must cover \(b\) by \(bc:b\).

At \(c\), the saturated \(cu_5\) edge and \(E:bc:b\) force \(E:Cc:c\). At \(C\), saturated \(Cu_2\) then forces \(E:AC:C\). Since \(E\) covers \(a,c\) at marked halves, it uses port \(p_5\). In particular,
\[
E:\quad ab:a,\ bc:b,\ Cc:c,\ AC:C,\ p_5.          \tag{5}
\]
Since \(P,R\) saturate \(Bu_4\), the \(B\)-edge of \(E\) is \(Bu_1\) or \(Bu_2\). Direct tracing gives the three exterior terminal-arm endpoints:
\[
\begin{array}{c|cc}
E\text{ at }B&Bu_1&Bu_2\\\hline
R:\ (AC,Cc,bc)&(p_2,p_5,p_4)&(p_4,p_5,p_1)\\
R':\ (ab,Cc,bc)&(p_2,p_5,p_4)&(p_1,p_5,p_4)
\end{array}
\]
In particular, both \(R,R'\) retain \(cu_5\) and the terminal \(Cc\), so their \(Cc\)-terminal arms against \(E\) are the same exterior path \(Cc-t_{Cc}-c-u_5-p_5\). Because (3) changes no shore edge, the shore \(e\)-path against \(R\) and \(R'\) first reaches the same proper port \(q\). Thus in both comparisons the \(e\)-path ends at \(Cc\) exactly when \(q=p_5\).

Under \(S_\alpha\), avoiding a second forbidden triple requires the \(e\)-path against \(R=e\,ab\) to end at \(bc\), but the one against \(R'=e\,AC\) to end at \(Cc\). Under \(S_\beta\) these requirements are reversed. Both contradict the common \(q\), proving the exclusion. \(\square\)

Together with Notes 414–415, this leaves \(e\,bc:c/e\,ab:b\) as the only unclassified root pair under \(S_\beta\). Under \(S_\alpha\), that pair and Note 415's one real exterior configuration for \(e\,bc:c/e\,ab:a\) remain. This does not exclude the adjacent forbidden pair as a whole, other placements, or the Berge–Fulkerson conjecture. The proof is hand-derived and awaits independent review.
