> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton prism excludes one \(AB,ab\) forbidden pentagon

Keep the Hamilton two-spoke exterior of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                              \tag{1}
\]
Assume complete exact-Case-XII BF support with forbidden \(e\)-labels \(\{eX,eW\}\). The two candidate pentagons are
\[
S_1=e-Y-X-W-Z-e,\qquad S_2=e-Y-W-X-Z-e.               \tag{2}
\]
The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed type \((eX)(eY)\) and forbids every \(T\)--\(T\) type.

> **One-orientation exclusion.** No cubic five-pole with exterior (1) has complete exact-Case-XII support for \(S_1\), at any shore order. For \(S_2\), every required \((eX)(eY)\) row has the marked-half boundary (8) below. This is a necessary boundary, not an existence claim.

Take a genuine row of type \((eX)(eY)\). Write \(P=eX\) for its forbidden triple, \(R=eY\) for its allowed triple, \(J=X,K=Y\) for their singleton partners and \(D_0,D_1=e\) for the other singletons. Since \(P\) is unchanged, the \(Y\)-starting component of \(R\triangle K\) must end at \(Z\): endpoints \(X,W\) would create a double-forbidden \(T\)--\(T\) type. This component is wholly exterior: \(R\) uses no proper shore port by [Note 230, equation (1)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), and at each tree subdivision the path enters on a \(K\)-half and leaves on \(R\)'s vertex half, rather than on \(K\)'s possible port edge.

If \(R=eY:c\), the only possible \(Y\to Z\) path is the short \(Y-c-Z\) path. The long route through \(u_5,b,u_4,B,u_3,C,u_2,A,u_1,a\) occupies both ends of the unselected \(X=AB\) mark in \(K\). Switching the short path gives an actual \(R'=eZ:c\) with exactly the same tree edges and complete shore matching as \(R\). At \(c\), the triple \(P=eX\) uses \(cu_5\), while \(R\) uses \(Y:c\) and \(K\) uses \(Z:c\). Edge load two leaves only one further \(cu_5\) slot among \(J,D_0,D_1\); hence some singleton-\(e\) occurrence \(D\) uses \(Y:c\) or \(Z:c\). Against that \(D\), replacing \(R\) by \(R'\) changes only the \(Y/Z\) alternating terminal arm: one of \(Y:c,Z:c\) is common in one comparison, and the other comparison follows the same arm with its terminal label changed. The \(X,W\) arms remain fixed. Under \(S_1\), the fixed shore \(e\)-path would have to reach \(X\) against \(R\) and \(W\) against \(R'\); under \(S_2\) the demands are reversed. Both demanded arms must therefore reach distinct ports, contradicting the common first shore exit. Thus \(R\) cannot be rooted at \(c\) for either orientation.

Now root \(R=eY\) at \(C\). A \(Y\to Z:a\) path through \(u_2,A,u_1\) is impossible: it makes \(K\) use \(Y\) at the terminal and \(Z:a\), so \(K\) cannot cover \(c\) by either marked half, while \(P,R\) already saturate \(cu_5\). The only remaining path is
\[
Y-C-u_3-B-u_4-b-u_5-c-Z.                          \tag{3}
\]
It forces the complete exterior of \(K\):
\[
K:Y\text{ terminal},\quad X:A,\ Z:c,\ W:a,\quad
Cu_3,\ Bu_4,\ bu_5,\quad p_1,p_2.                   \tag{4}
\]
Switching (3) gives \(R'=eZ:c\) with the same complete shore matching as \(R\). Independently of whether \(P=eX\) is rooted at \(A\) or \(B\), \(P,R\) saturate \(au_1,bu_4,cu_5\). The remaining mark and tree-edge loads in the three occurrences \(J,D_0,D_1\) have one distinguished member \(M\):
\[
M:(W:a,Z:c,Y:C,b u_5),\qquad
\{J,D_0,D_1\}\setminus\{M\}:(W:b,Z:a,Y:c).         \tag{5}
\]
Indeed, one remaining \(W:a\) slot and two \(Z:a\) slots cover \(a\); one remaining \(Z:c\) slot and two \(Y:c\) slots cover \(c\). The \(W:a,Z:c\) occurrence must take \(Y:C\), while \(bu_4\) is saturated and it cannot take \(W:b\), so it takes the remaining \(bu_5\) slot.

For a singleton-\(e\) occurrence \(D\), let \(X_R,W_R\) and \(X_{R'},W_{R'}\) be the ports reached by the respective marked terminal arms against \(R,R'\). Under \(S_1\), the demanded shore exits are \(X_R,W_{R'}\); under \(S_2\), they are \(W_R,X_{R'}\). If \(M=D\), every possible root and \(X\)-half gives disjoint exits:
\[
\begin{array}{c|c|c|c}
P\text{ root}&D:X&S_1:(X_R,W_{R'})&S_2:(W_R,X_{R'})\\ \hline
A&B&(p_3,\{p_1,p_2\})&(\{p_1,p_2\},p_4)\\
B&A&(p_2,p_1)&(p_1,p_2)\\
B&B&(p_3,p_2)&(p_2,p_4).
\end{array}                                                 \tag{6}
\]
For example, when \(P:A,D:X:B\), the \(X\)-arm starts \(X-B-u_3\) against \(R\) and exits at \(p_3\); against \(R'\), it follows \(X-B-u_4\) to \(p_4\). The \(W\)-arm starts \(W-a-u_1\) and exits at \(p_1\) or \(p_2\). When \(P:B,D:X:A\), it exits at \(p_1\) and the \(X\)-arm at \(p_2\). When \(P:B,D:X:B\), saturation of \(Au_2\) forces \(Au_1\), giving the last row. These traces also show that both marked arms reach distinct ports in each comparison; the third marked arm reaches the remaining port, so there is no exterior port-to-port detour.

Suppose instead \(M=J\). Then both \(D_i\) have \((Y:c,Z:a,W:b)\). If \(P:A\), the \(X:A\) marked half is saturated by \(P,K\), so both \(D_i:X:B\). They split the remaining \(Cu_2,Cu_3\) slots; choose the one with \(Cu_2\). Its \(X\)-arm under \(R\) exits at \(p_3\), while its \(W\)-arm under \(R'\) exits at \(p_5\). If \(P:B\), the \(D_i\) split the \(X:A,X:B\) slots; choose \(D:X:B\). Its corresponding exits are again \(p_3,p_5\). Thus \(S_1\) fails in every remaining case. In every comparison used here the demanded arms reach proper ports, and the other marked arms cannot create a port-to-port detour for the same endpoint-count reason.

For \(S_2\), (6) still forces \(M=J\). Therefore every surviving required row has
\[
\begin{array}{c|c}
K&Y\text{ terminal},\ X:A,\ Z:c,\ W:a,\ Cu_3,\ Bu_4,\ bu_5,\ p_1,p_2\\
J&X\text{ terminal},\ Y:C,\ Z:c,\ W:a,\ bu_5\\
D_0,D_1&e\text{ terminal},\ Y:c,\ Z:a,\ W:b
\end{array}                                                 \tag{8}
\]
with \(P=eX:A\) or \(P=eX:B\). Equation (8) does not fix the full shore matchings or prove the existence of an exact-Case-XII row. The other pentagon \(S_1\) is excluded; [Note 440](440-the-surviving-hamilton-x-w-rows-all-recomplete-to-forbidden-support.md) subsequently excludes the \(S_2\) row by full matching recompletion, and [Note 441](441-the-last-hamilton-prism-forbidden-pair-has-no-exact-case-xii-support.md) completes the Hamilton exterior. Other exterior profiles and Berge–Fulkerson conjecture remain open. This is a hand proof awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)
