> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The adjacent \(bc,Cc\) forbidden pair leaves one real exterior boundary

Use the two-spoke prism exterior of [Notes 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md) and [414](414-an-adjacent-prism-forbidden-pair-excludes-the-indirect-bc-direct-ab-row.md), with forbidden \(e\)-labels \(\{bc,Cc\}\). Put
\[
S_\alpha=e-ab-bc-Cc-AC-e,\qquad
S_\beta=e-ab-Cc-bc-AC-e.                                  \tag{1}
\]
Consider an actual six-perfect-matching \((e\,bc)(e\,ab)\) row whose forbidden triple is \(P=e\,bc:c\) and allowed triple is \(R=e\,ab:a\). Their rooted tree slots are
\[
P:(B,C,A,b,a),\qquad R:(B,C,A,b,c)                     \tag{2}
\]
on \((u_1,\ldots,u_5)\). Let \(K,J\) be singleton-\(ab\), singleton-\(bc\), and let \(E,F\) be the two singleton-\(e\) occurrences.

> **Sharp exterior boundary.** Under exact Case-XII support, \(S_\beta\) admits no such root pair. Under \(S_\alpha\), every such row has, up to exchanging the names of the two singleton-\(e\) occurrences, exactly the exterior mask in (5) below. This mask is realized by six complete perfect matchings of a simple 21-vertex cubic five-pole, but that pole admits the forbidden BF loop \([e\,bc]\) and is not exact Case XII. Thus (5) is a real rowwise boundary, not an exact-support example.

**Force an exterior \(ab\)--\(AC\) switch.** The \(ab\)-starting path of \(R\triangle K\) must end at \(AC\): its other possible terminal ends \(bc,Cc\) would give two forbidden triples alongside unchanged \(P\). Since \(P,R\) saturate \(bu_4\), \(K\) must take \(bc:b\). Since they saturate \(Cu_2\), \(K\) covers \(C\) at a marked half. There are two possibilities at \(c\).

If \(K:cu_5\), then \(K:Cc:C,AC:A,au_3\). The allowed path is the wholly exterior short path
\[
ab-t_{ab}-a-u_3-A-t_{AC}-AC.                          \tag{3}
\]
The \(B\)-edge of \(K\) is \(Bu_2\) or \(Bu_4\). Quotas at \(b,c,C\) force \(J:ab:b,Cc:c,AC:C\). The singleton-\(e\) occurrence using \(ab:a\), named \(E\), must take \(bc:b,Cc:c,AC:C,p_5\): \(P,R\) saturate \(bu_4\), while \(R,K\) saturate \(cu_5\). Switch (3), obtaining \(R'=e\,AC:A\) with exactly the same shore matching as \(R\). Both \(R,R'\) take \(cu_5\) and have terminal \(Cc\), so their \(Cc\)-arms against \(E\) both follow \(Cc-t_{Cc}-c-u_5-p_5\). Each of their other terminal arms goes to a different proper port. The shore \(e\)-path has the same first endpoint against \(R\) and \(R'\), but (1) requires \(bc,Cc\) under \(S_\alpha\), or \(Cc,bc\) under \(S_\beta\), respectively. The short possibility is impossible.

If \(K:Cc:c\), choosing \(au_5\) would end the \(ab\)-path at forbidden \(Cc\). Hence \(K:AC:C,bc:b,au_3,Au_1,Bu_2\) and ports \(p_4,p_5\). The \(Bu_4\) alternative ends the \(ab\)-path at forbidden \(bc\). The only allowed path is the wholly exterior long path
\[
ab-t_{ab}-a-u_3-A-u_1-B-u_2-C-t_{AC}-AC.            \tag{4}
\]
Switch it to obtain \(R'=e\,AC:C\) with the same complete shore matching as \(R\).
Consequently, against any fixed singleton-\(e\) occurrence, the shore path from \(e\) first reaches the same proper port in \(R\triangle D\) and \(R'\triangle D\). The required terminal arms must exit at that same port.

**Exclude all but one long configuration.** Since \(P,R\) saturate \(bu_4\), the singleton \(J\) takes \(ab:b\). At \(c\), it takes \(cu_5\) or \(Cc:c\). Let \(E\) be the singleton-\(e\) occurrence taking \(ab:a\). The \(b\)-quota and the \(bc\) subdivision force \(E:bc:b\).

If \(J:cu_5\), then \(E:Cc:c,AC:C,p_5\). Both \(R,R'\) retain \(cu_5\) and terminal \(Cc\), so their \(Cc\)-arms against \(E\) again exit at \(p_5\). The required \(bc/Cc\) reversal in (1) is impossible.

Hence \(J:Cc:c,AC:C\). The remaining mark loads force
\(E:AC:A,Cc:C,bc:b,ab:a,cu_5\). Since \(P,R\) saturate \(Bu_1\), \(E\) covers \(B\) by \(Bu_2\) or \(Bu_4\). The relevant exterior exits are
\[
\begin{array}{c|cc}
E\text{ at }B&Bu_2&Bu_4\\\hline
R\triangle E:\ bc&p_4&p_1\\
R\triangle E:\ Cc&p_1&p_2\\
R'\triangle E:\ Cc&p_1&p_1\\
R'\triangle E:\ bc&p_4&p_2
\end{array}
\]
For the first and second rows, start at \(bc-t_{bc}-b-u_4\) and \(Cc-t_{Cc}-C-u_2\). For the third, follow \(Cc-t_{Cc}-C-t_{AC}-A-u_1\); the last starts at \(bc-t_{bc}-b-u_4\). The choice of \(E\)'s \(B\)-edge determines which arm continues through \(B\). All three terminal arms reach distinct proper ports of \(E\).
For \(S_\alpha\), compare the first and third rows; for \(S_\beta\), compare the second and fourth. Either orientation forces \(E:Bu_4\).

At \(a\), the remaining singleton \(F\) and \(J\) split the available \(au_3,au_5\) slots. If \(J:au_5\), then \(F:au_3,p_5\), while the mark loads give \(F:AC:A,Cc:C,bc:c,ab:b\). Both \(R,R'\) have the \(bc\)-arm \(bc-t_{bc}-c-u_5-p_5\) against \(F\); the opposite required targets in (1) are impossible. Hence \(J:au_3\), \(F:au_5\). Now \(F:AC:A,Cc:C,bc:c,ab:b\), and its \(B\)-edge is \(Bu_2\) or \(Bu_4\). The relevant exits are
\[
\begin{array}{c|cc}
F\text{ at }B&Bu_2&Bu_4\\\hline
R\triangle F:\ bc&p_4&p_1\\
R\triangle F:\ Cc&p_1&p_2\\
R'\triangle F:\ Cc&p_1&p_1\\
R'\triangle F:\ bc&p_3&p_3
\end{array}
\]
The corresponding prefixes are \(bc-t_{bc}-c-u_5-a-t_{ab}-b-u_4\), \(Cc-t_{Cc}-C-u_2\), \(Cc-t_{Cc}-C-t_{AC}-A-u_1\), and \(bc-t_{bc}-c-u_5-a-u_3-p_3\). Each finishes at the displayed port after following \(F\)'s \(B\)-edge when encountered.
The \(S_\beta\) target exits, \(R:Cc\) and \(R':bc\), never agree. For \(S_\alpha\), the \(R:bc\) and \(R':Cc\) exits agree only if \(F:Bu_4\). Then \(E,F\) saturate \(Bu_4\), \(P,R\) saturate \(Bu_1\), and \(K,J\) saturate \(Bu_2\). All remaining exterior choices are fixed.

**The surviving table and a real row.** In the following table, a mark entry \(s\) means its terminal semiedge; a port entry \(p_i\) means the edge from \(u_i\) to the shore. The \(e\)-semiedge occurs only in \(E,F\).
\[
\begin{array}{c|ccccc|cccc}
 &u_1&u_2&u_3&u_4&u_5&AC&Cc&bc&ab\\\hline
P&B&C&A&b&a&s&s&c&s\\
R&B&C&A&b&c&s&s&s&a\\
K&A&B&a&p_4&p_5&C&c&b&s\\
J&A&B&a&p_4&p_5&C&c&s&b\\
E&p_1&p_2&p_3&B&c&A&C&b&a\\
F&p_1&p_2&p_3&B&a&A&C&c&b
\end{array}                                                     \tag{5}
\]
Every exterior edge and terminal in (5) has load two. In particular \(P,R\) use zero shore ports, \(K,J\) use \(p_4,p_5\), and \(E,F\) use \(e,p_1,p_2,p_3\).

For a complete actual row, take a six-cycle shore with vertices \(h_e,h_1,h_2,h_3,h_4,h_5\) in that cyclic order, attach port \(e\) to \(h_e\), and join each \(u_i\) to \(h_i\). On the shore let \(P,R\) both use
\[
Q=\{h_5h_e,h_1h_2,h_3h_4\},
\]
let \(K,J\) both use \(\{h_eh_1,h_2h_3\}\) together with ports \(p_4,p_5\), and let \(E,F\) both use \(\{h_4h_5\}\) together with ports \(e,p_1,p_2,p_3\). These are six complete perfect matchings. The three shore edge pairs and every port edge each have load two, so (5) is a genuine BF row on the resulting simple 21-vertex cubic five-pole.
This pole has girth five: the subdivided prism has no cycle shorter than six, the shore is a six-cycle, and a cycle crossing between them uses two port edges, at least one shore edge, and at least two exterior edges. The five-cycle \(h_1-u_1-B-u_2-h_2-h_1\) attains the bound.

It is not an exact Case-XII pole. The complement of \(Q\) in the shore has the port pairings \(ep_1,p_2p_3,p_4p_5\) and no closed component. For the rooted triple \(P=e\,bc:c\), the exterior complement pairs \(bc\,p_3,p_1p_5,p_2p_4\) (see Note 387). Gluing these pairings makes a single \(e\)--\(bc\) path and no closed component. It spans all 21 internal vertices, so its 22 edges alternate into a singleton-\(e\) and a singleton-\(bc\) perfect matching. Doubling those two matchings and \(P\) yields the forbidden loop \([e\,bc]\). Thus the real row certifies only the sharpness of the exterior and rowwise analysis; it does not resolve the adjacent forbidden pair under full closure. \(\square\)

The [Petersen three-pole substitution of Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) at \(h_1\) transports this row to a 29-vertex pole and makes every zero-port shore matching leave an odd closed complementary component. At \(h_1\), the original row uses \(h_1h_2\) in \(P,R\), \(h_eh_1\) in \(K,J\), and \(p_1\) in \(E,F\). Attach these three edges to the Petersen gadget's \(v_1,v_4,u_0\), respectively, and splice the six restricted Petersen matchings
\[
(P,R,K,J,E,F)=(M_2,M_4,M_1,M_3,M_\infty,M_0).
\]
Equation (2) of Note 381 checks every attachment pair. The two zero-port shore matchings of \(P,R\) are now **different**, because \(M_2,M_4\) have different internal Petersen edges after their common edge at \(v_0\) is deleted. The substitution also preserves the forbidden \([e\,bc]\) loop and introduces a cyclic three-edge cut. Hence the all-odd condition of [Note 413](413-two-spoke-prism-exact-case-xii-requires-odd-zero-port-complements.md), even together with \(Q_P\ne Q_R\) and the surviving real row, does not supply exact support.
The 29-vertex pole also has girth five: the Petersen gadget has girth five, and the distance inside it between any two attachment vertices is at least three, exceeding the two-edge detour through the replaced vertex. Thus the new obstruction to exact support is a BF loop across different shore matchings, while the example still has a cyclic three-edge cut.
The inherited \([e\,bc]\) loop necessarily uses **different complete shore matchings** in its two triple occurrences: if both used \(Q\), the four singleton occurrences would have to split an odd closed component of the shore complement of \(Q\), which is impossible. In particular, a Tait split or a test that reuses one \(Q\) cannot detect this forbidden type. The obstruction lies in closure across different complete shore matchings.

The remaining \(e\,bc:c/e\,ab:b\) root pair, other mixed cells and forbidden placements, irreducible all-odd shores, and the full Berge–Fulkerson conjecture remain open. The classification and the explicit row are hand-derived and await independent proof review; no local mathematical recomputation or OMEN was used.
