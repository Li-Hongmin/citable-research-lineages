> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two five-cut barrier shores have flexible three-hit singleton profiles

Work in [Note 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) normalized deficiency-two barrier \(U\), and take its profile with two non-singleton odd components \(A,B\), each having a five-edge cut in \(J\). The other \(|U|\) odd components are singleton, all five marked edges join distinct components of \(F-U\), \(h(U)=0\), and \(F[U]\) is edgeless. Assume full exact Case-XII support in the minimum host. The statements below concern the **entire** pole matching family and every actual BF row; they do not assert that this profile exists.

For a perfect matching \(N\) of the five-pole \(H\) and an odd component \(C\) of \(F-U\), let \(\lambda_C(N)\) count its edges that cover a vertex of \(C\) from outside \(F[C]\). They are unmarked \(F\)-edges from \(C\) to \(U\), or the \(C\)-side half of a marked edge crossing from \(C\) to another odd component. Since \(|C|\) is odd, \(\lambda_C(N)\) is odd and positive. Every vertex of \(U\) is matched to a component, and a triple-boundary (respectively singleton-boundary) matching selects two (respectively four) marked endpoints. Thus
\[
\sum_{C\text{ odd}}\lambda_C(N)=
\begin{cases}
|U|+2,&N\text{ triple-boundary},\\
|U|+4,&N\text{ singleton-boundary}.
\end{cases}                                                   \tag{1}
\]
There are \(|U|+2\) odd components. Equation (1) therefore forces a triple matching to have \(\lambda_C=1\) for **every** \(C\). A singleton matching has \(\lambda_C=3\) at exactly one component and \(1\) at all others. A singleton component consists of one vertex and cannot have three matching edges, so this unique three-hit component is \(A\) or \(B\). Call it the singleton's **shore profile**.

## Exact two-and-two row quota

Every six-matching BF row has two triple occurrences and four singleton occurrences. Since \(|\delta_J(A)|=5\) and no mark is internal to \(A\), the six-slot load on its five boundary edges is
\[
\sum_{\text{six slots}}\lambda_A(N)=2|\delta_J(A)|=10.
\]
The triples contribute \(1+1\); if \(r\) of the four singletons have profile \(A\), the singletons contribute \(3r+(4-r)=4+2r\). Hence \(2+4+2r=10\), so \(r=2\). The same holds for \(B\):
\[
\boxed{\text{Every actual BF row has exactly two \(A\)-profile
and two \(B\)-profile singleton occurrences.}}                    \tag{2}
\]

Moreover **each of the five complete singleton classes contains both shore profiles**. If class \(c\) were fixed to \(A\), choose a positive \((cx)(cy)\) row with \(cx\in S\) and \(cy\in T\). Its two class-\(c\) occurrences would use both \(A\)-profile slots, forcing the class-\(x\) and class-\(y\) occurrences to profile \(B\). The \(S\)-half \(Q_{cx}+P_c+P_x\) is mixed. Keep the complementary \(T\)-half fixed and perform the five terminal-path switches around the \(S\)-pentagon from [Note 168](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md). At each switch, the new triple still has \(\lambda_A=1\); the complete \(S\)-half load and the other singleton are unchanged, so the moving singleton retains its \(\lambda_A\), hence its shore profile. Negative \(T\)--\(T\) support keeps every intermediate state in \(S\). After five switches the same state \(cx\) has its singleton profiles reversed, contradicting the assumed fixed class. The argument for a class fixed to \(B\) is symmetric. This is a full-family conclusion, with no asserted common matching mask between separate rows.

There is also a **cellwise** form. For every \(c\), every \(cx\in S\), and every \(cy\in T\), the positive cell \((cx)(cy)\) has an actual row in which its two class-\(c\) singleton occurrences have opposite shore profiles. Start with any row in the cell. If its \(S\)-half has two equal profiles, (2) makes the two \(T\)-half profiles both opposite, so the two class-\(c\) occurrences already differ. If its \(S\)-half is mixed, the same five switches give both profile orientations at the unchanged \(S\)-state while preserving the complete \(T\)-half; choose the orientation opposite to its class-\(c\) occurrence. This asserts existence of a split-profile row in **each overlapping cell**, not a shared matching mask across cells.

## A three-vertex tree shore

Suppose \(A\) is an acyclic three-vertex path, the only possible tree with a five-edge cubic cut. Its centre has one boundary edge; each end has two. An \(A\)-profile singleton has three boundary hits, so **all three vertices** of \(A\) are matched through boundary edges, including the centre's unique edge. If that centre edge were a marked edge with label \(c\), a class-\(c\) singleton could not use its \(A\)-side half: it uses \(s_c\) at the subdivision vertex. Class \(c\) would then have no \(A\)-profile matching, contrary to the preceding theorem. Thus
\[
\boxed{\text{The centre port of every three-vertex tree shore is an
unmarked \(F\)-edge to \(U\).}}                              \tag{3}
\]

If **both** \(A\) and \(B\) are such trees, let \(e_A,e_B\) be their centre edges. Deleting them makes the proper graph of \(H\) bipartite: put \(U\), the two tree centres, and all five marked subdivision vertices on one side; put the four tree ends and every singleton odd component on the other. The remaining unmarked edges cross, and every marked edge joins two vertices on the second side through a subdivision vertex on the first. Hence this profile lies in Note 127's same-side \(5+0\) branch, with exceptional edges \(e_A,e_B\). [Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md) forces their \(U\) endpoints to be distinct. This reduces the tree--tree subcase to the existing two-edge bipartization interface; it does not exclude it.

For a cyclic five-cut shore, the three-hit profile still obeys (1)--(2), while the shore's full boundary matching relation remains necessary. Here no mark is internal to the shore, so its five-edge \(J\)-cut is also a five-edge cut of the **whole minimum host**. [Proposition 4.4 of Máčajová--Mazzuoccolo--Tabarelli](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) then classifies that cyclic shore as an ordinary pentagon or a Case-XIII \(L^*,R^*\) shore, since the other side of its internal five-cut contains more than a pentagon. This argument does not apply to Note 169's separate five-cut profile with one internal mark: its corresponding host cut has six edges.

There is a direct way to use the published support without losing the outer row. Restrict any actual outer BF row to the shore five-pole \(A^\circ\), replacing its five cut edges by ports. The restriction remains a six-matching BF row, since every internal edge and every port is loaded twice. By (2), precisely the **two outer singleton occurrences of \(A\)-profile** become the two triple-boundary occurrences of this local row; its other four occurrences have singleton boundaries. If their two local missing-pair states are \(p_A,q_A\), the local type is \((p_A)(q_A)\), with \([p_A]\) when they coincide. The same holds on \(B\).

For a non-pentagonal cyclic shore, the Figure 7 Case-XIII relation therefore requires \(p_A,q_A\) to lie in one of the two five-state blocks if its type is \(L^*\); its loops also allow \(p_A=q_A\). If its type is \(R^*\), the states must lie in opposite blocks and in particular be distinct. These are restrictions on **each actual outer row**. [Note 163](163-five-cut-perfect-matching-closure-composes-shore-bf-relations.md) identifies those two published relations, but its direct disjoint-shore composition formula does not apply here: the two shores are joined through \(U\) and the singleton components. [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) gives the exact slot-compatibility relation when \(|U|=1\); for that profile, complete shore BF type relations suffice once the connector and relative port placements are included.
