> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global common perfect-matching incidence does not force a Case-XII section

This note records a strict negative result at the matching-incidence layer.
It does not construct a cubic pole.  Its purpose is to identify the exact
information that is still missing from the Case-XII argument.

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

The target support consists of the five S-loops, the ten off-diagonal
S--S types, and all twenty-five S--T types, with no A-type
\((12345)\), no T-loop, and no T--T type.  A pentagon section means a
choice of one singleton matching in each boundary class whose disjointness
relations follow the S-pentagon.  Such a section gives an A-cover by the
usual multiplicity-one argument.

## Countermodel at the global-vector level

Take two global singleton vectors \(P_{i,0},P_{i,1}\) for every boundary
position \(i\).  On thirty base coordinates, indexed by all cross-class
pairs that are not edges of the connected double cover

\[
 C_{10}\longrightarrow C_5,
\]

put a one on the two corresponding singleton variants.  Consequently the
only disjoint singleton pairs are the ten edges of that connected
\(C_{10}\), and the five loop relations have sizes
\((2,2,2,2,2)\) but have no pentagon section.

For every S--S and S--T cell choose a common triple vector and four vectors
from this same global singleton pool so that the six vectors have coordinate
load exactly two.  Thus all fifteen S--S and all twenty-five S--T positive
types are present using one common pool of matching vectors; the witnesses
are not private to individual cells.

Now add one guard coordinate for each unordered pair of the five T-triple
classes, including repetitions.  On each guard, both variants of one
singleton class are marked, and the two targeted T-triple vectors are chosen
so that every possible T--T singleton choice has load strictly larger than
two.  The guards therefore exclude every T-loop and every T--T completion,
even after quantifying over the whole global vector pool.  No
zero-boundary vector is included, so an A-cover is absent.

The model also includes a genuine formal one-step exchange.  One S--S
triple vector and its companion are duplicated, changing exactly one
coordinate; their difference is one formal alternating 2-cycle.  Fresh
singleton variants make both sides of the exchange satisfy an exact S--S
six-vector equation.  The relation sizes become \((3,3,2,3,3)\), while
pentagon sections and all negative T/TT constraints remain absent.  Thus
the obstruction is not an artefact of having no exchange.

The construction has 77 global binary vectors after this exchange
augmentation (75 before it).  The deterministic verifier is

```text
python3 units/berge-fulkerson/scratch/worker-bf-common-pm-proof/common_pm_guarded_incidence_model.py
```

It reports

```text
base_coordinates=30
guard_coordinates=325
relation_sizes=(3,3,2,3,3)
pentagon_sections=0
A_cover=False
T_loop=False
TT_support=False
COMMON_PM_GUARDED_INCIDENCE_MODEL_VERIFIED
```

The formal same-class exchanges are realized by changing one of two
parallel coordinate edges, so every same-class difference is an alternating
2-cycle in the coordinate model.

## Exact consequence

Therefore

\[
\boxed{
\text{global common binary PM incidence}
 +\text{ exact six-vector loads}
 +\text{ formal same-class exchange closure}
 +L_{\mathrm{XII}}
\not\Rightarrow \text{a pentagon section or an A-cover}.
}
\]

This is stronger than a private-witness or route-label countermodel, because
all witnesses are vectors in one common matching pool and the negative
T/TT conditions are enforced globally.  It is still not a real pole: the
vectors do not arise from one common set of three-valent vertex incidence
constraints, and the boundary metadata is not a cubic-graph realization.

Consequently the remaining Case-XII interface is sharply defined.  Any
positive theorem must use a genuinely cubic vertex-incidence property of
perfect matchings (or an equivalent theorem about real alternating paths),
not merely global load equations, class support, or formal exchange closure.

The construction and its verifier are retained in
`scratch/worker-bf-common-pm-proof/common_pm_guarded_incidence_model.py`.
