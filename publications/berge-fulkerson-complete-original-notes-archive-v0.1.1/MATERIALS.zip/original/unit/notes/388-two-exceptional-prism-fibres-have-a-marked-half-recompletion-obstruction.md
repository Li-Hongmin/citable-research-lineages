> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two exceptional prism fibres have a marked-half recompletion obstruction

Continue the sharp signed-fibre classification of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Use its two-spoke triangular-prism exterior
\[
T=\{AB,BC,Aa,Bb,ac\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac),
\]
whose four marks are \(AC,Cc,bc,ab\). Fix a complete zero-port shore matching \(Q\) with no odd closed component and one of Note 387's two exceptional signed signatures. In either case, the two \(ej\)-states **not** in the doubly blocked pair each have a rooted triple whose complement is a single \(e\)--\(j\) path, apart from possible even closed shore components. Thus each extends to a genuine Tait colouring. Add those two Tait decompositions to obtain a six-perfect-matching BF row with two triple shore restrictions both equal to \(Q\).

> **Marked-half obstruction.** Keep all six complete shore restrictions of this canonical two-Tait row, including the two copies of \(Q\). In **every** exterior recompletion to a BF row, each zero-port triple state still belongs to the two originally allowed labels in the table below. Even one triple state from the doubly blocked pair is impossible with these six shore masks. This holds for every shore order, internal matching structure and even-cycle phase.

The terminal states, chosen Tait roots and proper-port sets of the four singleton occurrences are forced as follows. The two singleton-\(e\) occurrences are \(E_0,E_1\); the other two are \(X,Y\), carrying the displayed allowed singleton terminals in either order.

| doubly blocked pair \(F\) | signed \(Q\) paths | allowed Tait triples | ports of each \(E_i\) | ports of each \(X,Y\) |
|---|---|---|---|---|
| \(\{ab,Cc\}\) | \(ep_5\) even, \(p_2p_4\) odd, \(p_1p_3\) even | \(e\,AC\) at \(C\), \(e\,bc\) at \(b\) | \(\{p_2,p_3,p_4\}\) | \(\{p_1,p_5\}\) |
| \(\{AC,bc\}\) | \(ep_3\) even, \(p_2p_4\) odd, \(p_1p_5\) even | \(e\,Cc\) at \(C\), \(e\,ab\) at \(b\) | \(\{p_2,p_4,p_5\}\) | \(\{p_1,p_3\}\) |

**Tait-row verification.** The four exterior pairings used here are in Note 387's table. Gluing them to the signed shore paths gives these open-path orders of the five proper ports:
\[
\begin{array}{c|c}
F& e\text{-to-allowed-terminal orders}\\\hline
\{ab,Cc\}& 5,2,4,1,3\quad(e\,AC_C),\qquad 5,4,2,1,3\quad(e\,bc_b)\\
\{AC,bc\}& 3,2,4,1,5\quad(e\,Cc_C),\qquad 3,4,2,1,5\quad(e\,ab_b).
\end{array}                                                     \tag{1}
\]
There is no closed component traversing shore ports in these four gluings, and any closed component wholly within the shore is even by hypothesis. The exterior has no odd closed component by Note 358. Alternately colour each complete complement path starting with singleton colour \(E_i\) at terminal \(e\); this gives the port sets in the table. The choices of colour on even closed components do not change any port set. Each Tait decomposition covers every edge once, so their sum is an actual BF row with edge load two.

**No forbidden recompletion, first signature.** Suppose \(F=\{ab,Cc\}\) and preserve all six shore restrictions. The two \(E_i\) use ports \(p_2,p_3,p_4\), while \(X,Y\) use \(p_1,p_5\). At the prism vertex \(B\), each \(E_i\) must use the \(B\)-half of the tree edge \(AB\): its other two tree edges have ports \(p_2,p_4\). That half is saturated by \(E_0,E_1\), so both new zero-port triples must use the \(A\)-half at \(p_1\). For **any** exterior mark this forces its triple root to be \(C\) or \(b\), by the rooted-tree rule. Both roots orient the tree edge \(ac=p_5\) toward \(c\). Thus both new triples use the \(c\)-half at \(p_5\), forcing both \(E_i\) onto its \(a\)-half. The remaining marked halves of each \(E_i\) are then uniquely
\[
AC:A,\qquad Cc:C,\qquad bc:c,\qquad ab:b.                     \tag{2}
\]
Every forbidden triple rooted as forced above uses the same marked half as both \(E_i\): \(ab:b\) for \(e\,ab\), or \(Cc:C\) for \(e\,Cc\). That edge would have load at least three. Hence **neither forbidden triple state can occur even once** in a BF row with these six shore masks, regardless of the other triple state or how \(X,Y\) are renamed.

**No forbidden recompletion, second signature.** Now \(F=\{AC,bc\}\). The \(E_i\) use \(p_2,p_4,p_5\), and \(X,Y\) use \(p_1,p_3\). The same \(B\)-vertex argument forces both new triples to use the \(A\)-half at \(p_1\), so either root is \(C\) or \(b\). Both roots orient \(Aa=p_3\) toward \(a\), so both triples take its \(a\)-half and both \(E_i\) must take its \(A\)-half. Their uniquely forced marked halves are now
\[
AC:C,\qquad Cc:c,\qquad bc:b,\qquad ab:a.                     \tag{3}
\]
A forbidden triple rooted at \(C\) uses \(AC:C\), and one rooted at \(b\) uses \(bc:b\); each is already used by both \(E_i\). The resulting load three forbids **even one** forbidden triple in any recompletion with these shore masks. \(\square\)

The [23-vertex genuine pole of Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md) realizes the first signature and this canonical actual BF row, so it is a concrete counterexample to the proposed *same-shore-mask* recompletion. Its separate six-cycle shore flip produces forbidden Tait loops, showing that a different complete shore matching can still defeat exact support. The theorem closes the direct fixed-mask route even to a **mixed** allowed–forbidden row at these two signatures; it does not rule out a putative exact-Case-XII pole by another BF row or by full shore matching closure. The proof is hand-derived and awaits an independent check; no OMEN or local mathematical recomputation was used.
