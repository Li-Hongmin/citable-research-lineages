> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The C10 blocker is polyhedrally realizable but not closed

For each singleton class \(\mathcal P_i\), a capacity-two transversal is the
multiple-choice packing system

\[
x_{iP}\in\{0,1\},\qquad \sum_{P\in\mathcal P_i}x_{iP}=1,
\qquad \sum_{i,P\ni e}x_{iP}\le2.
\]

Its LP relaxation is infeasible exactly when nonnegative edge weights satisfy

\[
\sum_i\min_{P\in\mathcal P_i}y(P)>2\sum_e y_e.
\]

For the abstract C10 blocker of Note 006, write \(p_i,q_i\) for choosing the
state containing the common element \(a,b\).  Its irreducible infeasible core
is just

\[
p_i+q_i=1\ (i=1,\ldots,5),\qquad
\sum_i p_i\le2,\qquad \sum_iq_i\le2,
\]

whose sum is \(5\le4\).  The Farkas certificate is \(y_a=y_b=1\).

Crucially, this blocker is not excluded by the ordinary perfect-matching
polytope.  There is a simple connected cubic 5-pole on thirteen internal
vertices, with semiedge \(s_i\) at vertex \(i-1\), and proper edges

\[
\begin{split}
&(0,2),(0,3),(1,3),(1,4),(2,12),(4,8),(5,6),(5,9),(5,10),\\
&(6,7),(6,9),(7,8),(7,11),(8,12),(9,10),(10,11),(11,12),
\end{split}
\]

containing ten genuine singleton-boundary perfect matchings whose
disjointness graph is exactly C10 and whose restricted 32 transversals are
all capacity-bad.  After adjoining an apex, every designated matching obeys
all vertex and odd-cut constraints; exhaustive odd-set evaluation has minimum
crossing value one.

The complete perfect-matching family changes the conclusion.  The same pole
has 49 perfect matchings, singleton class sizes \((3,3,5,5,5)\), exact Tait
state set \(S\), five consecutive relation sizes all eight, and 40 compatible
pentagons.  It has a capacity-two transversal, necessarily using matchings
outside the designated ten-state subsystem.

Therefore no inequality valid for one ordinary perfect-matching polytope can
eliminate the blocker.  The missing structure is closure of the complete
perfect-matching family—most plausibly alternating-cycle generation or an
exchange theorem coupling all singleton classes.  A proof based only on ten
chosen matching vectors, even with every odd-cut inequality, is insufficient.

The exact verifier is
`scratch/worker-dual/verify_c10_blocker_completion.py` and runs with

```text
uv run --with networkx python units/berge-fulkerson/scratch/worker-dual/verify_c10_blocker_completion.py
```

