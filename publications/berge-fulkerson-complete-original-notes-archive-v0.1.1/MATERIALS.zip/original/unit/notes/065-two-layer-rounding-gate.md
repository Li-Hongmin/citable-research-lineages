> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Capacity rounding has two independent integrality gates

The aggregate capacity LP can be feasible while no classwise singleton selection exists. A verified simple connected girth-5 cubic 5-pole of order 13 has an integral aggregate solution, but all (64) choices from its five singleton fibres violate some edge capacity; the associated 5-regular multigraph is class-II.

Conversely, if the augmented graph obtained by adding the apex is bipartite, the aggregate degree system has a totally unimodular incidence matrix. Any feasible LP therefore has an integral aggregate (z), a 5-regular bipartite multigraph. Kőnig edge-colouring decomposes it into five perfect matchings, and the apex edges force one singleton boundary class per factor.

Thus any general exact-\( S \) proof must overcome two separate gates:
\[
\text{aggregate LP integrality},
\qquad
\text{classwise integer rounding/class-I decomposition}.
\]
LP, odd-cut, or aggregate load arguments alone cannot establish the Berge–Fulkerson conclusion.

Proof and verification details: `scratch/worker-lp-integer-rounding/lp-to-integer-rounding-boundary.md` and `verify_girth5_lp_integer_gap.py`.
