> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Ten \(D_2\) Hamilton phases force forbidden rows; six need cross-port closure

Continue the fixed Hamilton exterior and the required genuine \((eX)(eZ)\) row of [Notes 462 and 476](476-the-adjacent-forbidden-hamilton-x4-root-has-four-k-signatures.md), with \(P=eX\) rooted at \(X:4\), \(R=eZ\) rooted at \(Z:6\), and the \(D_2\) singleton \(K=Z\) using
\[
X:1,\ Y:5,\ W:6,\ 2u_1,\ 3u_2,\ 4u_4,\ p_3,\ p_5.
\tag{1}
\]
The terminal pairs are \(e=ab,X=RJ,Y=W=PR,Z=PK\). Exact Case XII with forbidden pair \(\{eX,eY\}\) requires this row but forbids \([eX],[eY],(eX)(eY)\), by the [published Appendix XII](https://amc-journal.eu/index.php/amc/article/view/3409/2156) (Máčajová--Mazzuoccolo--Tabarelli, *Ars Math. Contemp.* 26 (2026), DOI 10.26493/1855-3974.3409.c13). The positive recompletions below retain all six old complete shore matchings separately. The no-go statements are stronger: they fix only the old labelled port pairs, allowing different complete shore matchings behind them.

## Old row: sixteen labelled phases

Put \(S=\{J,a,b\}\), choose \(\sigma\in\{a,b\}\), and let \(\bar\sigma\) be the other \(e\)-singleton. The entire old \(D_2\) exterior row has the form
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\alpha,S\setminus\{\alpha\})&
(PR,K\delta,S\setminus\{\delta\})&
(PR,J\sigma,K\bar\sigma)&
(RK,P\mu,S\setminus\{\mu\})&
(R\rho,P\lambda,K\gamma)
\end{array},                                                   \tag{2}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,K\sigma,P\bar\sigma)&
(PR,S\setminus\{\sigma\},K\sigma)&
(PK,S\setminus\{\alpha\},R\alpha)&
(PR,S\setminus\{\delta\},K\delta).
\end{array}                                                   \tag{3}
\]
The orders at tree and marked subdivisions are those of Note 476. The parameters satisfy exactly
\[
\{\sigma,\mu,\rho\}=S,\qquad
\{\rho,\lambda,\gamma\}=S,\qquad
\{\lambda,\alpha,\delta\}=S.                                  \tag{4}
\]
For example, original vertex \(5\) gives the first brace, \(u_5\) the second, and original vertex \(6\) the third. Conversely the six original vertices see
\[
(PR,K\sigma,S\setminus\{\sigma\}),\
(K\alpha,PR,S\setminus\{\alpha\}),\
(K\delta,PR,S\setminus\{\delta\}),\
(J\sigma,RK,P\bar\sigma),\
(P\mu,R\rho,K\sigma),\
(P\lambda,R\alpha,K\delta);
\tag{5}
\]
each is a six-label partition precisely under (4). Thus (2)--(4) describe all local labelled phases of \(D_2\), without claiming a shore exists for each. There are \(2\cdot2\cdot2\cdot2=16\) phases. Their shore-port pairs are
\[
e=ab,\qquad
(p_1,p_2,p_3,p_4,p_5)
=\bigl(S\setminus\{\alpha\},S\setminus\{\delta\},
K\bar\sigma,S\setminus\{\mu\},K\gamma\bigr).                   \tag{6}
\]

The sixteen phases fall into the following five classes, each closed under interchanging \(a,b\). An unordered brace in the \((\alpha,\delta)\) column allows both orders.

| Class | Remaining parameters | \((\alpha,\delta)\) | Count | Fixed-port forbidden type |
|---|---|---|---:|---|
| I | \(\mu=\lambda=J,\ \gamma=\sigma,\ \rho=\bar\sigma\) | \(\{\alpha,\delta\}=\{\sigma,\bar\sigma\}\) | 4 | \([eY]\) |
| II | \(\mu=\gamma=\bar\sigma,\ \lambda=\sigma,\ \rho=J\) | \(\{\alpha,\delta\}=\{J,\bar\sigma\}\) | 4 | \([eY]\) |
| III | \(\mu=\gamma=J,\ \lambda=\sigma,\ \rho=\bar\sigma\) | \((\alpha,\delta)=(J,\bar\sigma)\) | 2 | \([eX]\) |
| IV | \(\mu=\gamma=J,\ \lambda=\sigma,\ \rho=\bar\sigma\) | \((\alpha,\delta)=(\bar\sigma,J)\) | 2 | none |
| V | \(\mu=\lambda=\bar\sigma,\ \gamma=\sigma,\ \rho=J\) | \(\{\alpha,\delta\}=\{J,\sigma\}\) | 4 | none |

## The ten forbidden recompletions

For classes I and II put \(\bar\gamma=\{a,b\}\setminus\{\gamma\}\) and choose \(x\) by
\[
\begin{array}{c|ccc}
&\gamma&x&\lambda\\ \hline
\mathrm I&\sigma&\sigma&J\\
\mathrm{II}&\bar\sigma&J&\sigma .
\end{array}                                                   \tag{7}
\]
Then \(\{\lambda,x,\bar\sigma\}=S\) and \(\{x,\mu,\bar\gamma\}=S\). Keep all six old complete shore restrictions unchanged, and put
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RK,P\alpha,S\setminus\{\alpha\})&
(RK,P\delta,S\setminus\{\delta\})&
(R\lambda,Px,K\bar\sigma)&
(R\mu,PK,S\setminus\{\mu\})&
(S\setminus\{\gamma\},PR,K\gamma)
\end{array},                                                   \tag{8}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,S\setminus\{\bar\gamma\},K\bar\gamma)&
(KJ,P\bar\gamma,R\gamma)&
(PR,S\setminus\{\alpha\},K\alpha)&
(PR,K\alpha,S\setminus\{\alpha\}).
\end{array}                                                   \tag{9}
\]
At original vertices \(1,\ldots,6\), the triples are
\[
(RK,S\setminus\{\bar\gamma\},P\bar\gamma),\
(P\alpha,RK,S\setminus\{\alpha\}),\
(P\delta,R\lambda,K\alpha),\
(Px,R\mu,K\bar\gamma),\
(PK,S\setminus\{\gamma\},R\gamma),\
(PR,K\alpha,S\setminus\{\alpha\}).
\tag{10}
\]
Equations (4) and (7) make each a partition; (8)--(9) partition every subdivision, and their port pairs are (6). The new terminals are \(e=ab,Y=KJ,X=Z=W=PR\), the forbidden loop \([eY]\). This excludes all eight class-I/II phases at every shore order.

Class III has the ports
\[
e=ab,\qquad
(p_1,\ldots,p_5)=(ab,J\sigma,K\bar\sigma,ab,KJ).              \tag{11}
\]
For both values of \(\sigma\), the following exterior pairs preserve (11):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(KJ,PR,ab)&(K\bar\sigma,PR,J\sigma)&
(J\sigma,PR,K\bar\sigma)&(KJ,PR,ab)&(ab,PR,KJ)
\end{array},                                                   \tag{12}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(KJ,PR,ab)&(PR,ab,KJ)&
(PR,J\sigma,K\bar\sigma)&(PR,K\bar\sigma,J\sigma).
\end{array}                                                   \tag{13}
\]
The six original vertices see, respectively,
\[
(KJ,PR,ab),\
(PR,K\bar\sigma,J\sigma),\
(PR,J\sigma,K\bar\sigma),\
(PR,KJ,ab),\
(PR,ab,KJ),\
(PR,K\bar\sigma,J\sigma),
\tag{14}
\]
so every slot partitions the six labels. The terminals are \(e=ab,X=KJ,Y=Z=W=PR\), the forbidden loop \([eX]\). Thus ten of the sixteen labelled \(D_2\) phases force forbidden support by keeping the original six complete shore matchings.

## Why the other six resist every fixed-port forbidden type

The above classification of fixed-port recompletions is exhaustive, not merely a choice of templates. By [Note 230's six-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the port pairs (6) keep \(P,R\) as the zero-port triples, \(a,b\) as singleton-\(e\), and \(K,J\) as the other two singletons. Since \(P,R\) occur on no port, interchange their *exterior* names in a root search when convenient. This does not exchange their complete shore masks.

For \([eY]\), \(K\) selects terminal \(Y\) and, having ports \(p_3,p_5\), must cover original vertices \(4,5\) through \(X:4,u_4:5\). The two triple roots at \(Y\) cannot coincide: if both root at \(Y:1\), vertex \(5\) repeats a singleton on \(Y:5\) and \(u_5:5\); if both root at \(Y:5\), vertex \(1\) repeats one between \(X:1\) and \(Y:1\). With roots split, say \(P:Y:1,R:Y:5\), vertex \(5\) forces \(\gamma\in\{a,b\}\), \(Y:5=R\gamma\), \(u_4:5=PK\), while vertices \(1,4\) force \(X:4=K\bar\gamma\). Write \(u_3:3=Ry,u_3:4=Px\). The partitions at \(u_3\), vertices \(2,3\), and vertex \(4\), compared with the old third brace of (4), give the common gate
\[
y=\lambda,\qquad
\{x,\lambda\}=S\setminus\{\bar\sigma\}=\{J,\sigma\},\qquad
\{x,\mu,\bar\gamma\}=S,\qquad \gamma\in\{a,b\}.                \tag{15}
\]
If \(\gamma=\sigma\), equations (4) and (15) give class I; if \(\gamma=\bar\sigma\), they give class II. Conversely (8)--(10) realize both, so these are exactly the \([eY]\) phases.

For \([eX]\), \(K\) selects terminal \(X\); its ports \(p_3,p_5\) force it onto \(u_4:4\) and \(Y:5\). The two triple \(X\)-roots cannot both be \(X:4\), since vertex \(1\) would repeat an \(e\)-singleton between \(X:1\) and \(Y:1\). If they split, the same vertex-partition argument gives (15), hence only classes I/II. If both root at \(X:1\), vertices \(1,4,6\) force
\[
\mu=J,\qquad \delta=\bar\sigma,\qquad \gamma=\alpha.          \tag{16}
\]
With (4), this is either a class-I phase or class III. Formulae (12)--(14) realize class III. Thus \([eX]\) adds only those two phases to the eight already excluded.

For \((eX)(eY)\), put \(P=eX,R=eY\). If \(K\) is singleton \(Y\), its ports force \(P:X:1,R:Y:5\), and the remaining partitions give (15). If \(K\) is singleton \(X\), they force \(R:Y:1\). With \(P:X:4\), the partitions again give (15); with \(P:X:1\), they require \(\gamma\in\{a,b\}\), \(\delta=\bar\sigma\), and \(\{\alpha,\mu,\bar\gamma\}=S\), which solve (4) only in classes I/II. No other root or singleton placement is possible. Consequently classes IV and V admit **none** of the three forbidden types with their old labelled port pairs, even if the complete shore matchings behind those same signatures are changed.

The two resistant classes have different exact boundaries when old shore-port signatures may be reused with new multiplicities. In class V, with \(p_s=ab,p_t=J\bar\sigma\), the four nonempty signatures are
\[
Q_\sigma=\{e,p_s,p_4,p_5\},\quad Q_{\bar\sigma}=\{e,p_s,p_t,p_3\},\quad
Q_J=\{p_t,p_4\},\quad Q_K=\{p_3,p_5\}.                       \tag{16a}
\]
If a BF row uses only these signatures and the empty signature, load two at \(e,p_t,p_3,p_4,p_5\) forces one occurrence of each \(Q_\sigma,Q_{\bar\sigma},Q_J,Q_K\). Its labelled port pairs can then be relabelled to (6), so no forbidden type results. **One** new-signature occurrence is still insufficient: if it is an \(e\)-singleton, duplicating either old non-\(e\) signature overloads a port shared with the remaining old \(e\)-singleton, so the two old non-\(e\) signatures occur once each and the supposedly new \(e\)-signature is the omitted old one. If it is a non-\(e\) singleton, duplicating either old \(e\)-signature overloads a port shared with the remaining old non-\(e\) singleton, forcing both old \(e\)-signatures once and again reproducing the omitted old signature. Hence any forbidden \(e\)-sector row in class V needs **at least two occurrences with new shore-port signatures**.

In class IV, the four old nonempty signatures are
\[
Q_\sigma=\{e,p_1,p_2,p_4\},\quad Q_{\bar\sigma}=\{e,p_2,p_3,p_4\},\quad
Q_J=\{p_1,p_5\},\quad Q_K=\{p_3,p_5\}.                       \tag{16b}
\]
Port load two permits their multiplicities
\[
(m_\sigma,m_{\bar\sigma},m_J,m_K)
=(t,2-t,2-t,t),\qquad t\in\{0,1,2\}.                        \tag{16c}
\]
Thus the old-signature multiplicity route remains open in class IV; (16c) is only a port-incidence identity, not a forbidden full BF row. The no-go statement above applies to the original \(t=1\) labelled port pairs.

## All six resistant phases have real rows and forbidden full closure

It remains important that classes IV and V are not merely formal port assignments. For either, use the old exterior (2)--(3), and take a six-cycle shore on vertices \(q_e,q_1,\ldots,q_5\), with terminal \(e\) at \(q_e\) and port \(p_i\) joining \(q_i\) to \(u_i\). It suffices to give the representatives with \(\sigma=a,\bar\sigma=b\); exchanging \(a,b\) gives the others.

In class IV, \((\alpha,\delta,\mu,\rho,\lambda,\gamma)=(b,J,J,b,a,J)\), so
\[
(e,p_1,p_2,p_3,p_4,p_5)=(ab,Ja,ab,Kb,ab,KJ).                 \tag{17}
\]
Use shore cycle \(q_e-q_1-q_5-q_3-q_2-q_4-q_e\), with successive edge pairs
\[
RK,\quad Pb,\quad Ra,\quad PJ,\quad RK,\quad PJ.              \tag{18}
\]
At its vertices in this order, the two cycle-edge pairs and the port pair are
\[
(PJ,RK,ab),\
(RK,Pb,Ja),\
(Pb,Ra,KJ),\
(Ra,PJ,Kb),\
(PJ,RK,ab),\
(RK,PJ,ab).
\tag{19}
\]

In class V, \((\mu,\rho,\lambda,\gamma)=(b,J,b,a)\) and \(\{\alpha,\delta\}=\{J,a\}\). Let \(s\in\{1,2\}\) be the index with \(p_s=ab\), and \(t\) the other index, so \(p_t=Jb\). The ports are
\[
(e,p_s,p_t,p_3,p_4,p_5)=(ab,ab,Jb,Kb,Ja,Ka).                 \tag{20}
\]
Use cycle \(q_e-q_3-q_t-q_4-q_5-q_s-q_e\), with successive edge pairs
\[
RJ,\quad Pa,\quad RK,\quad Pb,\quad RJ,\quad PK.              \tag{21}
\]
At its six vertices, the three incident pairs are
\[
(PK,RJ,ab),\
(RJ,Pa,Kb),\
(Pa,RK,Jb),\
(RK,Pb,Ja),\
(Pb,RJ,Ka),\
(RJ,PK,ab).
\tag{22}
\]
Every triple in (19) and (22) partitions \(\{P,R,K,J,a,b\}\). Together with (2)--(5), these give genuine six-matching BF rows on simple connected 21-vertex cubic five-poles of girth at least five, for **all six** resistant labelled phases.

In class IV, the complement of the zero-port shore matching \(Q_P\) has pairing
\[
ep_1\mid p_2p_4\mid p_3p_5;                               \tag{23}
\]
in class V it has \(ep_3\mid p_tp_4\mid p_sp_5\). Neither shore complement has a closed component. Since \(P=eX\) roots at \(X:4\), its exterior complement pairs
\[
Xp_5\mid p_1p_2\mid p_3p_4.                                \tag{24}
\]
The three exterior pieces are \(X-t_X-1-t_Y-5-u_5-p_5\), \(p_1-u_1-2-t_Z-6-t_W-3-u_2-p_2\), and \(p_3-u_3-4-u_4-p_4\), visiting all 15 exterior vertices. Gluing (23)--(24) gives, respectively, the single open routes
\[
e,p_1,p_2,p_4,p_3,p_5,X
\qquad\text{and}\qquad
e,p_3,p_4,p_t,p_s,p_5,X.                                   \tag{25}
\]
Each shore complement visits all six shore vertices as well. Alternating either spanning \(e\)--\(X\) path gives a genuine forbidden \([eX]\) loop in the **complete** support. Hence these poles are not exact Case XII, while their old rows cannot reach a forbidden type through fixed-port recompletion.

For \(D_2\), the all-order conditional exclusion now covers ten labelled phases, and six real phases remain dependent on changed shore-port signatures or other full-closure mechanisms. This does not exclude \(D_2\) under arbitrary shore order, the other \(D_i\), the \(P:X:1\) branch, other exterior markings, exact Case XII, or Berge--Fulkerson. All certificates and classifications here are hand-derived, without OMEN or local mathematical recomputation, and await independent review. \(\square\)

Later boundary: [Note 480](480-cross-balanced-shore-colours-force-the-zero-port-masks-to-coincide.md) shows that the class-IV \(t=0,2\) options in (16c) cannot yield a forbidden row using only the six **old complete shore matchings** once every zero-port shore matching has the odd complementary cycle required by exact Case XII. The port-incidence freedom in (16c) remains genuine, but its full-row use needs a new complete shore mask.
