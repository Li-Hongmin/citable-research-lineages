> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Seven shore port states do not supply the second B cross row

Use the type-B exterior and the six shore ports \(E,A,D,I,H,J\) of [Notes 253–254](254-the-b-cross-rows-require-shore-cycle-intersections.md). The exact-Case-XII gate requires both \((ea)(ad)\) and \((ea)(ab)\) rows. Their shore port sets are
\[
\begin{array}{c|ccc|ccc}
&X&Y&Z&U&V&W\\\hline
ad&\varnothing&HJ&EADI&ED&HJ&AI\\
ab&\varnothing&HJ&EADI&EA&HJ&DI.
\end{array}                                                   \tag{1}
\]
The pure \(X\triangle Z\) paths must pair \(E\)--\(I\) and \(A\)--\(D\).

**Counterexample to individual-matching sufficiency.** A connected simple cubic five-pole of order 25 and girth five has the B exterior, a real \((ea)(ad)\) BF row with the required pure pairing, and shore perfect matchings in **all seven** port classes appearing in (1). The two extra shore matchings glue to Note 253's prescribed \(U_{ab},W_b\) exterior masks, so every individual matching required by the proposed \(ab\) row exists as a *complete five-pole perfect matching*. Yet the shore has **no \(ab\)-profile six-matching BF row at all**: two internal edges would be loaded at least three times. Thus individual matching existence plus the first real cross row does not supply the second. This is a genuine matching-level boundary, **not** an exact-Case-XII pole.

## The modified shore and the existing \(ad\) row

Take central vertices \(s_0,\ldots,s_5\) with cycle edges \(c_i=s_is_{i+1}\), outer vertices \(r_0,\ldots,r_5\) with spokes \(p_i=s_ir_i\), and outer edges
\[
q_{03}=r_0r_3,\qquad q_{15}=r_1r_5,\qquad q_{24}=r_2r_4.
\]
Place ports \(H,E,I,J,D,A\) at \(r_0,r_1,r_2,r_3,r_4,r_5\). This changes only two outer edges of Note 254's shore: \(q_{14},q_{25}\) become \(q_{15},q_{24}\). In its \(ad\) six-matching table, replace these two edge names in both \(Y\) and \(V\), leaving \(X,Z,U,W\) and all port sets unchanged. Every edge still has load two: the replaced outer edges carry precisely \(YV\), while the central edges, spokes, \(q_{03}\), and ports retain Note 254's pair labels. Each matching still covers every shore vertex once. Gluing the same six B-exterior masks of Note 253 therefore gives a genuine \((ea)(ad)\) BF row, with \(X\triangle Z\) pairing \(EI\mid AD\) and the pure-half shore defect cycle from Note 254.

The formerly absent two-port states now have explicit shore matchings:
\[
M_{EA}=\{c_0,c_2,c_4,q_{03},q_{24};E,A\},\qquad
M_{DI}=\{c_0,c_2,c_4,q_{03},q_{15};D,I\}.             \tag{2}
\]
They glue to the actual exterior masks \(U_{ab}\) and \(W_b\) of Note 253, respectively; no identity is merely formal. The other five port classes occur in the \(ad\) row. The shore has girth five: the central six-cycle and the three outer chords have shortest cycles of lengths six, six, five, and five, respectively, and two chords cannot make a shorter cycle. As in Note 254, the exterior has girth at least five and the five shore-interface endpoints are distinct and pairwise nonadjacent on the exterior, so the glued five-pole has girth five.

## Why the \(ab\) row still fails

First determine the complete shore fibre with ports \(HJ\). The selected ports cover \(r_0,r_3\). If both \(q_{15},q_{24}\) are used, the central six-cycle has exactly its two alternating perfect matchings. If neither is used, the four spokes at \(r_1,r_2,r_4,r_5\) leave the nonadjacent central vertices \(s_0,s_3\). If only \(q_{15}\) is used, the forced spokes \(p_2,p_4\) leave \(s_3\) isolated among \(s_0,s_1,s_3,s_5\); if only \(q_{24}\) is used, the forced spokes \(p_1,p_5\) leave \(s_0\) isolated among \(s_0,s_2,s_3,s_4\). Hence the fibre consists of exactly two matchings,
\[
Y_0=\{c_0,c_2,c_4,q_{15},q_{24};H,J\},\qquad
Y_1=\{c_1,c_3,c_5,q_{15},q_{24};H,J\}.             \tag{3}
\]

Both matchings in (3) contain \(q_{15}\) and \(q_{24}\). Thus the two \(HJ\) occurrences \(Y,V\), whether equal or different, already load **both edges twice**.

Every \(EA\)-port shore matching contains \(q_{24}\). To see this, the selected ports cover \(r_1,r_5\), making \(p_2,p_4\) compulsory if \(q_{24}\) is not used. If \(r_0,r_3\) then use \(q_{03}\), the central vertex \(s_3\) is isolated among \(s_0,s_1,s_3,s_5\). If they use \(p_0,p_3\), the only unmatched central vertices are the nonadjacent \(s_1,s_5\). Both fail. By the same argument with the other outer pair, every \(DI\)-port shore matching contains \(q_{15}\): avoiding it forces \(p_1,p_5\), after which using \(q_{03}\) isolates \(s_0\), while using \(p_0,p_3\) leaves the nonadjacent \(s_2,s_4\).

In any proposed \(ab\)-profile row, its \(U\) matching must therefore add a third occurrence of \(q_{24}\), and its \(W\) matching a third occurrence of \(q_{15}\). This violates load two regardless of the zero-port and four-port matchings or the pure-path pairing. \(\square\)

In general, let \(\operatorname{core}(B)\) be the internal edges used by **every** shore matching with port set \(B\). A necessary condition for the \(ab\) row in (1) is
\[
\operatorname{core}(HJ)\cap\operatorname{core}(EA)
=\operatorname{core}(HJ)\cap\operatorname{core}(DI)=\varnothing.
\]
Here the two intersections contain \(q_{24}\) and \(q_{15}\), respectively. The analogous \(ad\) intersections with \(ED,AI\) are empty, as its explicit row confirms. This states the correct boundary for the proposed port-state shortcut: fibre nonemptiness does not control edges forced in all members of those fibres.

This five-pole has a forbidden \([eb]\) loop as well: the shore matchings \(\{p_0,\ldots,p_5\}\), \(Y_0\), and \(\{c_1,c_3,c_5,q_{03};E,A,D,I\}\) partition its shore once and glue to Note 252's \(eb\) exterior Tait colouring. Therefore the example does not refute exact Case XII. What it refutes is the weaker assertion that all seven required shore port states plus one genuine cross row force the second. The surviving all-orders question still needs simultaneous full-row load compatibility and the complete negative BF support.

The construction and impossibility proof are hand-derived and have not received independent verification.
