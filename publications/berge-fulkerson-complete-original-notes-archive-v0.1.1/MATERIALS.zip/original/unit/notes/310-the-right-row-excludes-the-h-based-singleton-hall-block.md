> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right row excludes the H-based singleton Hall block

Continue the actual left \((ea)(ac)\) and right \((ea)(ad)\) rows in
the \(R_0=DJ\), \(3{:}2\) near-bipartite central-path profile of
[Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md).
Assume complete exact-Case-XII negative support. Write \(h,d,j\)
for the bases of the proper ports \(H,D,J\), respectively.

**Theorem.** No tight \(DJ\) Hall witness of [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md)
is a singleton, even when the shore has arbitrary cycle rank. In a
cyclically five-edge-connected minimum host, every inclusion-minimal
such Hall block therefore has a six-, eight-, or ten-edge cut. The
claim uses the real right \(ad\) row, and does not assume its false
\(EJ\mid ID\) pairing from the retracted Note 305.

**Proof.** [Note 309, Theorem 2](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md)
puts the \(H\)-port base \(h\) in every Hall witness. If
\(S_H=\{h\}\), then \(N_K(S_H)=\{d,j\}\); cubicity and simplicity
give the three incidences
\[
                           H,\quad hd,\quad hj                \tag{1}
\]
at \(h\). The port \(D\) covers \(d\), and \(J\) covers \(j\).

In the left \(ac\) row, let \(Z_L\) be its four-port shore matching
with ports \(E,A,I,D\), and let \(L\) be either singleton-\(a\)
matching with ports \(H,J\). Because \(Z_L\) selects \(D\) and
not \(H,J\), (1) forces \(hj\in Z_L\). Because \(L\) selects both
\(H,J\), the complete path
\[
                           H-h-j-J                         \tag{2}
\]
is one component of \(Z_L\triangle L\). Switch (2) into \(Z_L\).
It yields an actual shore matching \(F\) selecting **all six ports**
\(E,A,I,D,H,J\). It still avoids \(g\), since \(Z_L\) avoids \(g\)
by [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md)
and (2) is local at \(h,j\).

In the right \(ad\) row, let \(X_R\) denote its zero-proper-port
matching selecting \(g,t_{ew}\). Its port sets, in slot order, are
\[
       (\varnothing,ID,EAHJ,EJ,ID,AH).                  \tag{3}
\]
At \(h\), the \(H\) edge is selected by the third and sixth
slots. Both \(ID\) slots select \(D\), so (1) forces them to use
\(hj\). The \(EJ\) slot selects \(J\), so it must use \(hd\).
Every edge has row load two. Thus \(X_R\) also uses \(hd\).
If \(w=d\), this already contradicts \(t_{ew}\in X_R\), since
one matching cannot select both edges at \(d\). Otherwise continue.

The symmetric difference \(F\triangle X_R\) has the entire local
component
\[
                           H-h-d-D.                         \tag{4}
\]
Indeed \(F\) selects the two endpoint ports, while \(X_R\)
selects \(hd\). Switch (4) into \(X_R\). The resulting actual
two-proper-port shore matching has ports \(DH\) and still selects
\(g,t_{ew}\), as neither exceptional edge lies on (4). This
contradicts [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md),
which permits only \(HJ\) for that complete fibre. Thus
\(|S_H|\ne1\).

For an inclusion-minimal witness in a minimum host, use
[Note 290's cut identity](290-two-port-closure-separates-the-remaining-three-two-row-loads.md):
\(|\delta(\Omega)|=2(\alpha+\eta)\le10\), where the \(H\)
port gives \(\alpha\ge1\) and \(d\in N_K(S_H)\) gives
\(\eta\ge1\). Its proof shows that a four-edge cut in a
cyclically five-edge-connected minimum host must be a two-vertex
tree, hence \(|S_H|=1\). This case is now excluded; the remaining
even cut sizes are \(6,8,10\). \(\square\)

This restores the six-edge lower bound for the **right** near-
bipartite \(DJ\) branch by a valid local exchange, without the
incorrect \(I\)-base claim in Notes 305–307. Multivertex Hall
blocks, the local incidence collision, other core profiles, and
Berge–Fulkerson remain open. The proof is hand-derived and depends
on the stated row masks and complete-fibre exclusion; it has not
had an independent second-source check. No local enumeration or
OMEN run was used.
