> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Half-load saturation compresses Case XII to five carrier columns

Fix

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Let (H) be a cubic (5)-pole with five distinct terminals.  A perfect
matching uses an odd number of terminals.  A sum of three perfect matchings
whose terminal load is one at every terminal therefore has boundary pattern
(3+1+1); call the pair of singleton terminals its state.

## Column-saturation theorem

Assume that the BF support of (H) contains no (T)-loop and no (T\)--(T)
type.  If one actual BF completion has type ((s)(t)), with
(s\in S) and (t\in T), then the same three matchings in the (t)-half
can be retained while the (s)-half is replaced by a decomposition at
every state (r\in S).  Hence all five types

\[
 (r)(t),\qquad r\in S,
\]

occur as actual completions.  Dually, one (S)-loop ([s]) generates all
(S\)--(S) types ((r)(s)), (r\in S).

Consequently, under the two negative support assumptions, the positive
Case-XII pair support is determined by only the five (S)-loops and the
five disjoint (S\)--(T) seed cells: these ten seeds occur if and only if
all forty positive pair types occur.  The separate (A=(12345)) type is not
part of this equivalence.

## Proof

Write one completion as

\[
 A=Q_s+P_i+P_j,\qquad
 B=R_t+P_k+P_\ell,qquad A+B=2\mathbf 1.                 \tag{1}
\]

Replace every proper edge (e) by (A(e)\in\{0,1,2\}) parallel copies and
retain each terminal edge once.  At every internal vertex the resulting
multigraph (H_A) is cubic.  A decomposition

\[
 A=M_1+M_2+M_3                                      \tag{2}
\]

is equivalent to a proper three-edge-colouring of (H_A).  Since the five
terminal loads of (A) are one, the three matching boundary sizes are
(3,1,1).  Let \(\mathcal R(A)\) be the set of singleton-terminal states
arising from all decompositions (2).

The bichromatic path switch used in a three-edge-colouring gives the
following closure: if

\[
 \varnothing\ne\mathcal R(A)\subseteq S,
\]

then \(\mathcal R(A)=S\).  Indeed, from a state (ij\in S), switching the
component joining the triple-colour terminal to (i) replaces (i) by the
unique other endpoint which forms an (S)-edge with (j).  The analogous
switch at (j) traverses the connected (5)-cycle formed by the edges of
(S).

Now suppose that \(\mathcal R(A)\) contained a state (r\in T).  Combining
that decomposition of (A) with the fixed decomposition of (B) in (1)
would give a forbidden (T)-loop when (r=t), and a forbidden (T\)--(T)
completion when (r\ne t).  Thus \(\mathcal R(A)\cap T=\varnothing\).  Since
(s\in\mathcal R(A)), the closure gives \(\mathcal R(A)=S\).  Retaining the
fixed three matchings of (B) proves the column assertion.

The same argument applied to either half of an (S)-loop shows that one
half has state set (S); fixing the complementary half then generates all
(S\)--(S) cells.

For completeness, every BF cover whose two halves have (3+1+1) boundary
patterns is obtained by choosing a load (A), a decomposition state in
\(\mathcal R(A)\), and a decomposition state in
\(\mathcal R(2\mathbf 1-A)\).  Thus the exact pair support is a union of
rectangles

\[
 \bigcup_A \mathcal R(A)\times\mathcal R(2\mathbf 1-A).       \tag{3}
\]

If both shores of one rectangle contained (T)-states, (3) would produce a
forbidden (T)-loop or (T\)--(T) type.  Therefore at least one shore is a
nonempty subset of (S), and the closure forces that shore to be all of
(S).  Projecting (3) to (S\times T) proves the seed compression.

## Exact remaining interface

The theorem does **not** synchronize the five saturated columns.  For a
column carrier (A_t), let \(\widehat\Pi_t\) be its actual four-singleton
witness relation.  Saturation proves that each \(\widehat\Pi_t\) is
nonempty (and supplies all five (S)-states), but it does not identify a
singleton matching reused by two different columns.  The unresolved
implication is precisely

\[
 \text{five saturated actual carrier columns}
 \Longrightarrow
 \text{a four-column common singleton tuple}.                 \tag{4}
\]

Such a tuple gives the (A=(12345)) cover by the four-cell intersection
lemma.  Alternating-cycle differences between columns yield only an
edgewise cancellation identity; without an additional cross-column
exchange, Helly, or witness-reuse hypothesis, (4) remains undecided.

This result is a strict analytic reduction, not a proof or disproof of the
Berge--Fulkerson conjecture.
