> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every last Hamilton \(K_{3,3}\) \(S_1\) row recompletes to a forbidden \([eb]\) loop

The seven exterior signatures in [Note 384](384-seven-shore-port-signatures-for-the-last-hamilton-s1-row.md) all have a **second complete exterior BF completion** with the *same six complete shore restrictions*. In that completion, both triples have state \(eb\), so the original genuine \((ea)(eb)\) row forces the forbidden \([eb]\) BF loop. This eliminates \(S_1=e-a-b-d-c-e\) in the Hamilton \(K_{3,3}\) exterior with an arbitrary six-port shore. Reflection of the Hamilton path exchanges \(a,c\) and maps \(S_1\) to \(S_2=e-a-d-b-c-e\), eliminating the latter as well. The conclusion is restricted to this exterior profile and relies on the hand-derived upstream Notes 379, 382–384.

## A same-shore-mask completion

Use the vertices and marks of [Note 383](383-the-remaining-hamilton-s1-row-forces-a-long-route-and-two-p4-e-matches.md). Let the original row be \(P_{ea},R_{eb},A_a,B_b,E_{0,e},E_{1,e}\), with its zero-port shore matchings \(Q_P,Q_R\). The four singleton shore restrictions have one of the seven port signatures of Note 384. Keep **all six shore restrictions literally unchanged**, including \(Q_P,Q_R\). Replace their exterior restrictions as follows:

* Put an \(eb\)-triple rooted at \(x\) on \(Q_P\), and an \(eb\)-triple rooted at \(t\) on \(Q_R\). Both are actual complete perfect matchings by [Note 358's zero-port Cartesian factorization](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md).
* Reuse the old complete shore restrictions of \(A,B,E_0,E_1\). Give \(A,B\) new exterior singleton-\(b\) restrictions and \(E_0,E_1\) exterior singleton-\(e\) restrictions from the certificate below. Every one uses exactly its old proper-port set, so gluing makes four complete perfect matchings.

For brevity, write \(a_x\) for \(t_ax\), \(a_s\) for \(t_as\), \(b_x,b_t,c_y,c_t,d_r,d_z\) analogously. In the first certificate table, the entries for \(A,B\) list their \(a,c,d\) halves; the entries for \(E_0,E_1\) list their \(a,b,c,d\) halves. Both \(A,B\) use terminal \(b\), and both \(E_0,E_1\) use terminal \(e\).

| class | \(A\): \(a,c,d\) | \(B\): \(a,c,d\) | \(E_0\): \(a,b,c,d\) | \(E_1\): \(a,b,c,d\) |
|---|---|---|---|---|
| I | \(x,t,r\) | \(x,y,r\) | \(s,x,t,z\) | \(s,t,y,z\) |
| II | \(x,y,r\) | \(x,t,r\) | \(s,x,t,z\) | \(s,t,y,z\) |
| III | \(x,t,r\) | \(x,y,z\) | \(s,t,y,r\) | \(s,x,t,z\) |
| IV | \(x,t,r\) | \(x,y,z\) | \(s,t,y,r\) | \(s,x,t,z\) |
| V | \(x,y,z\) | \(s,t,r\) | \(x,t,y,z\) | \(s,x,t,r\) |
| VI | \(x,y,r\) | \(s,t,r\) | \(x,t,y,z\) | \(s,x,t,z\) |
| VII | \(x,t,r\) | \(s,y,z\) | \(x,t,y,z\) | \(s,x,t,r\) |

The second table gives **all** proper exterior tree edges of those four singleton occurrences. Their proper shore ports are exactly the pairs in the corresponding class of Note 384.

| class | \(A\) tree edges | \(B\) tree edges | \(E_0\) tree edges | \(E_1\) tree edges |
|---|---|---|---|---|
| I | \(yu_1,su_3,zu_4\) | \(su_2,zu_3,tu_4\) | \(ru_0,yu_2\) | \(xu_0,ru_1\) |
| II | \(su_2,zu_3,tu_4\) | \(yu_1,su_3,zu_4\) | \(ru_0,yu_2\) | \(xu_0,ru_1\) |
| III | \(yu_2,su_3,zu_4\) | \(ru_1,su_2,tu_4\) | \(xu_0,zu_3\) | \(ru_0,yu_1\) |
| IV | \(yu_1,su_3,zu_4\) | \(ru_0,su_2,tu_4\) | \(xu_0,zu_3\) | \(ru_1,yu_2\) |
| V | \(ru_1,su_3,tu_4\) | \(xu_0,yu_2,zu_4\) | \(ru_0,su_2\) | \(yu_1,zu_3\) |
| VI | \(su_2,zu_3,tu_4\) | \(xu_0,yu_1,zu_4\) | \(ru_0,su_3\) | \(ru_1,yu_2\) |
| VII | \(yu_2,su_3,zu_4\) | \(xu_0,ru_1,tu_4\) | \(ru_0,su_2\) | \(yu_1,zu_3\) |

## Verification

The two new triples have fixed exterior restrictions
\[
\begin{array}{c|l}
R_x^{eb} & b_x;\ a,c,d;\ ru_0,yu_1,su_2,zu_3,tu_4\\
R_t^{eb} & b_t;\ a,c,d;\ xu_0,ru_1,yu_2,su_3,zu_4.
\end{array}                                                       \tag{1}
\]
The two certificate tables permit a direct finite check without enumerating any shore matchings:

1. In each class and each of the four singleton rows, its marked halves and displayed tree edges meet each of \(x,r,y,s,z,t\) **once**. The stated terminal semiedge and the class's ports then match every exterior internal vertex once.
2. At \(t_a,t_c,t_d\), the two triples take the terminals. The first table gives exactly two singleton owners on each of the two marked halves. At \(t_b\), \(A,B\) take terminal \(b\); the two triples take opposite halves, and \(E_0,E_1\) take the respective remaining half.
3. At each \(u_i\), the two triples in (1) take different tree edges. The second table puts one singleton on each of those edges, while the *other two singleton colours* are exactly the port pair \(L_i\) in Note 384. For example, in class VI at \(u_2\), \(R_x^{eb},A\) take \(su_2\), \(R_t^{eb},E_1\) take \(yu_2\), and the port pair is \(BE_0\), as required.

Thus every exterior edge and semiedge has load two. The six shore restrictions were not changed, so every shore edge and port also retains load two. The six resulting objects are **complete actual perfect matchings** of BF type \([eb]\). Since \(eb\) belongs to the forbidden complementary pentagon of \(S_1\), Appendix XII rules out every one of the seven original row classes. Notes 379, 382–384 show that any purported exact-Case-XII \(S_1\) pole in this exterior must have one of those classes. Therefore no such pole exists.

For \(S_2\), reverse the exterior path \(x,r,y,s,z,t\). This automorphism sends \(p_i\) to \(p_{4-i}\), exchanges the marks \(a,c\), and fixes \(b,d\). It sends the edge set of \(S_1=e-a-b-d-c-e\) to that of \(S_2=e-a-d-b-c-e\). The shore is arbitrary, so reflecting its port names preserves the quantified class of complete five-poles. A hypothetical \(S_2\) pole would therefore give a hypothetical \(S_1\) pole, already excluded. Hence **neither** of the two remaining Case-XII pentagons occurs in this Hamilton \(K_{3,3}\) exterior.

Combined with the earlier exclusions of the other ten pentagons in [Notes 374–377](377-hamilton-k33-adjacent-ab-pair-has-no-case-xii-row.md), this closes the entire Hamilton \(K_{3,3}\) marked-tree exterior at arbitrary shore order and cycle rank, subject to verification of those upstream hand proofs. Together with the conditional double-star and non-Hamilton marked-tree exclusions in [Notes 367 and 372](372-the-k33-marked-path-has-no-exact-case-xii-pentagon.md), it would close the \(K_{3,3}\) side of the five-point tree profile. The triangular-prism exteriors, other deficient-core profiles and Berge–Fulkerson conjecture remain open. No OMEN or local mathematical recomputation was used; the certificate and dependency chain await an independent proof check.
