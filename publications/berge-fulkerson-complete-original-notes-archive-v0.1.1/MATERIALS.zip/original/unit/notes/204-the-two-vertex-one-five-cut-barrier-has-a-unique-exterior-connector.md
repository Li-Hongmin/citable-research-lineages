> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two-vertex one-five-cut barrier has a unique exterior connector

Assume the minimum-host, connected deficient-core setting of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md), and let a smallest maximum Tutte barrier be \(U=\{u_1,u_2\}\). Consider its profile with one non-singleton odd component \(C\), a five-edge \(J\)-cut around \(C\), and the unique internal marked edge \(e\subset C\). The other three odd components of \(F-U\) are singletons. The five-pole has girth at least five by [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md), and no core vertex meets three marks by [Note 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md).

**Connector theorem.** Up to exchanging \(u_1,u_2\), name the singleton components \(w_0,w_1,w_2\). The unmarked edges meeting \(U\) are exactly
\[
u_1w_0,\quad u_1w_1,\quad u_2w_0,\quad u_2w_2,\quad
u_1v_1,\quad u_2v_2,\qquad v_1,v_2\in C,\ v_1\ne v_2.       \tag{1}
\]
Of the four marks other than \(e\), one is \(w_1w_2\), and each of \(w_0,w_1,w_2\) has exactly one marked edge to \(C\). Thus the exterior core vertices induce the five-cycle
\[
u_1-w_1-w_2-u_2-w_0-u_1,                              \tag{2}
\]
whose sole marked edge is \(w_1w_2\). The attachment to \(C\) consists of the two unmarked edges in (1) and three marked edges, one from each \(w_i\). This is a necessary quotient shape; it does not assert an exact-Case-XII realization.

**Proof.** By Note 169, \(U\) has no marked incidence, \(F[U]\) is edgeless, and each \(u_i\) meets three distinct components of \(F-U\). Let \(r\) count the unmarked edges from \(U\) into \(C\). At most one comes from each \(u_i\), so \(r\le2\). The five-edge cut of \(C\) has \(r\) unmarked edges and \(5-r\) crossing marked edges. Only four marks are available outside \(C\), so \(r\ge1\).

If \(r=1\), the two barrier vertices have five incidences with the three singleton components. Each \(u_i\) meets any one such component at most once. Two singleton vertices must therefore be adjacent to **both** \(u_1,u_2\), giving an unmarked four-cycle in the opened five-pole, contrary to girth five. Hence \(r=2\), with one \(C\)-edge from each \(u_i\).

Four \(U\)-singleton incidences remain. Each singleton has at least one: with none, all three of its core edges would be marked, contrary to Note 157. Each has at most two, one from each \(u_i\). Their degrees toward \(U\) are therefore \((2,1,1)\). Call the shared singleton \(w_0\), and name the private ones so that \(u_iw_i\) is an edge. This proves all the exterior unmarked edges in (1).

The cut of \(C\) now uses three crossing marks, leaving one mark between two singleton vertices. If it met \(w_0\) and \(w_i\), then \(u_iw_0\), \(u_iw_i\), and this mark would be a core triangle with one marked edge. Subdividing that edge gives a proper four-cycle in the five-pole. Thus the remaining mark joins \(w_1,w_2\). Each singleton has three core incidences, so the other marked incidence at each \(w_i\) goes to \(C\). Finally, \(v_1=v_2\) would make the unmarked four-cycle \(u_1-w_0-u_2-v_1-u_1\), again contrary to girth five. This proves (1)--(2). \(\square\)

By [Note 203](203-a-cross-triple-switch-excludes-the-422-case-xii-profile.md), no one-vertex barrier remains. Thus (1)--(2) is the first possible connector of this one-five-cut profile in the deficient-core branch. [Note 169's order identity](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) and [Note 100's small-order bound](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) force \(F[C]\) to contain an unmarked cycle when \(|U|=2\). The theorem fixes the exterior; deciding exact Case XII still requires the actual complete matching relation of that cyclic shore.
