> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A fixed singleton in one half-load has an exact two-state fibre

The bridge in [Note 343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md) depends on the endpoint of one alternating path. Here that endpoint is made into an intrinsic invariant of a complete load and a fixed complete singleton matching. The statement applies to every cubic five-pole; the Case-XII consequences use the complete support specified by Máčajová, Mazzuoccolo and Tabarelli, Proposition 4.4 and Appendix XII.

**Fixed-singleton fibre theorem.** Let \(B\) be an integer half-load of a cubic five-pole, with unit load on each of its five terminal semiedges, and suppose
\[
                 B=U_{eb}+V_e+W_b.                         \tag{1}
\]
The subscripts are complete boundary classes: \(U_{eb}\) uses terminals \(a,c,d\), while \(V_e,W_b\) use \(e,b\), respectively. Form the edge-copy multigraph of \(B-W_b=U_{eb}+V_e\). It has exactly two open components joining the four terminals \(e,a,c,d\), with any number of closed even alternating components. Let \(p\in\{a,c,d\}\) be the terminal paired with \(e\). Then **all** three-perfect-matching decompositions of the same load \(B\) that contain the same complete matching \(W_b\) have precisely the two boundary states
\[
             \mathcal R_b(B;W_b)=\{eb,bp\}.                 \tag{2}
\]
Both states actually occur. In particular, \(p\) depends only on \((B,W_b)\), not on the chosen splitting of \(B-W_b\) into the other two complete matchings.

**Proof.** After deleting one copy of every edge in \(W_b\) from the edge-copy load \(B\), every internal vertex has degree two. Only the four terminal semiedges \(e,a,c,d\) remain, each with degree one. Thus the residual graph has the stated two open paths and closed cycles. Its colouring by \(U_{eb},V_e\) alternates on every component, including parallel-edge two-cycles. Any other decomposition retaining the entire \(W_b\) is exactly a two-colouring of this same residual graph and is obtained by independently exchanging the two colours on its components.

Starting with singleton \(V_e\), exchanging the \(e\)--\(p\) path makes it singleton \(p\) and leaves the other colour triple. Exchanging the other open path instead makes \(U_{eb}\) singleton \(p\). Exchanging both paths restores singleton \(e\), with the two colour roles interchanged. Closed-component exchanges do not change terminal classes. Hence the only states are \(eb\) and \(bp\), and both have explicit decompositions. \(\square\)

Now assume the central-path exact-Case-XII row and zero-port phases of [Notes 341–343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md):
\[
 X_C+Y_a+Z_e+U_C+V_e+W_b=2\mathbf1.
\]
For either choice \(D_e\in\{Z_e,V_e\}\), put \(B_C^{D}=U_C+D_e+W_b\), and denote its invariant by \(p_C^{D}\). The theorem gives an **if and only if** criterion at this fixed carrier and fixed \(W_b\):
\[
 B_C^{D}\text{ has a state-}bc\text{ decomposition containing }W_b
 \quad\Longleftrightarrow\quad p_C^{D}=c.                 \tag{3}
\]
When (3) holds for \(D_e=V_e\), Note 343's two distinct carrier pairs give actual \((ea)(bc)\) and \((dc)(eb)\) rows sharing the complete identities \(Z_e,W_b\). For \(D_e=Z_e\), they share \(V_e,W_b\). Conversely, when \(p_C^{D}\in\{a,d\}\), no recolouring of the same residual load with the same \(W_b\), including any closed-component phase switch, can produce this \(bc\) row. A different load or a different singleton-\(b\) matching would be needed; (3) says nothing about those possibilities.

The alternatives have a sharp support interpretation. By [Note 055](055-half-load-column-saturation-and-case-xii-compression.md), the complementary pure half-load has all five states of the allowed pentagon \(S=e-a-b-d-c-e\). If \(p_C^D=c\), the fixed-\(W_b\) fibre of \(B_C^D\) carries the two forbidden-pentagon states \(eb,bc\), giving two complete \(S\)-to-\(T\) columns on the same carrier pair. If \(p_C^D=a\) or \(d\), it carries \(eb\) together with the allowed state \(ab\) or \(bd\), respectively, giving an \(S\)-to-\(T\) column and an actual allowed loop \([ab]\) or \([bd]\). Both outcomes stay within the published Case-XII boundary type set. The theorem does **not** prove that an exact-Case-XII pole realizes either outcome, nor that some phase must have \(p_C^D=c\).

**Phase-family dichotomy.** Let \(k\ge1\) be the number of components of \(X_\Sigma\triangle U_\Sigma\) in the original row. The \(2^{k+1}\) pairs \((C,D_e)\), with \(C\) any zero-port cycle phase and \(D_e=Z_e\) or \(V_e\), have distinct complementary carrier pairs by [Note 342](342-the-eb-row-creates-two-exterior-pure-load-fibres.md). Therefore either (i) some \(p_C^D=c\), giving the two-identity cross-carrier bridge of Note 343, or (ii) all these fixed-\(W_b\) fibres have \(p_C^D\in\{a,d\}\). In case (ii), at least \(2^k\) **distinct carrier pairs** witness the same one of the allowed loops \([ab]\), \([bd]\), all with the complete \(W_b\) in their \(B\)-half. This is a literal matching-identity multiplicity, not just repeated boundary support. No upper bound on those loop carriers follows from the present hypotheses, so the dichotomy does not exclude case (ii).

[Note 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md) strengthens this dichotomy using the purity of **every** zero-port phase: each \(p_C^D\) is phase-invariant and fixed by the singleton-\(e\) exterior mask. In case (ii), both loop classes \([ab]\) and \([bd]\) occur on at least \(2^k\) distinct carrier pairs each. The endpoint \(c\) is forced for at least one singleton-\(e\) occurrence in every left \(Y_L,U_D\) row and in every right row except its specified III-with-\(3C\)/IV pair.

**A further obstruction if a third singleton identity joins.** In the two rows from the \(p_C^V=c\) bridge, suppose their singleton-\(c\) matchings also coincide, and denote the five resulting complete singleton matchings by \(P_a,W_b,P_c,P_d,Z_e\). Each row bounds by two the load of its four singleton classes, respectively \(\{a,b,c,e\}\) and \(\{b,c,d,e\}\). Therefore every proper edge covered by three of the five matchings has **exactly** the class signature \(\{a,d,i\}\) for one \(i\in\{b,c,e\}\); no edge can be covered four times. If there is no such edge, all five singleton loads are at most two, and the load-one edges form a sixth perfect matching, giving an \(A=(abcde)\) BF cover by the argument of [Note 043](043-four-cell-singleton-intersection-forces-a-cover.md). Hence an exact-Case-XII pole with no \(A\)-cover can synchronize that third identity only if one of these three specified triple-hit signatures occurs. This is a conditional full-mask obstruction, not a proof that the third identity synchronizes.

[Note 345](345-the-two-identity-bridge-has-an-exact-third-matching-gate.md) gives a necessary and sufficient test for that third identity to synchronize at one fixed \(e\to c\) phase: the candidate singleton-\(c\) matching must belong to the swapped pure half-load, and its degree-two residual must have even closed cycles. [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md) shows that the prescribed terminal-path parity then follows automatically from pure-\(S\) support.
