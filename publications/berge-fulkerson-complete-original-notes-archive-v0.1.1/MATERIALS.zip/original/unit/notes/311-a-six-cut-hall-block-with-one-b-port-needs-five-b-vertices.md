> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A six-cut Hall block with one B-port needs five B-vertices

> **Subsequent refinement:** [Note 312](312-the-right-row-excludes-the-two-point-six-cut-hall-block.md)
> excludes the two-vertex block in the other six-cut allocation
> \((\alpha,\eta)=(2,1)\); [Note 313](313-the-first-six-cut-hall-cycle-restricts-the-j-port.md)
> classifies the first remaining three-vertex shape and removes two
> \(J\)-port positions. The theorem below is unchanged.

Continue the corrected exact-Case-XII \(R_0=DJ\) near-bipartite
branch of [Notes 309–310](310-the-right-row-excludes-the-h-based-singleton-hall-block.md).
Let \(g=xy\subset B\), let the internal marked edge meet
\(v\in B,w\in R\), and set
\(K=(C-\{g,e\})-\{x,y\}\). In the noncollision branch, let
\(S\subseteq B\setminus\{x,y,v\}\) be a tight Hall witness:
\[
        |N_K(S)|=|S|+1,\qquad d,j\in N_K(S).          \tag{1}
\]
By [Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md),
the base \(h\) of port \(H\) lies in \(S\); by [Note 310](310-the-right-row-excludes-the-h-based-singleton-hall-block.md),
\(|S|>1\). Assume the completed minimum host has girth at least five.
Let \(\alpha\) be the number of proper \(B\)-side port incidences
based in \(S\), and let \(\eta=e_K(S,d)\), as in
[Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md).

**Theorem.** If this Hall block has a six-edge host cut and
\((\alpha,\eta)=(1,2)\), then \(|S|\ge5\). At the first possible
size \(|S|=5\), put \(T=N_K(S)\setminus\{d\}\). The five vertices
of \(T\) have degrees into \(S\) exactly \(3,3,2,2,2\). The two
degree-three neighbourhoods meet in precisely the \(H\)-port base
\(h\). Every pair of vertices of \(S\) has exactly one common
neighbour in \(T\), except the two neighbours of \(d\), which have
none. This is an incidence classification, not a realization of a
full Case-XII row.

**Proof.** Write \(s=|S|\). Equation (1) gives \(|T|=s\). Every
vertex of \(S\) has cubic degree; precisely \(\alpha=1\) of its
incidences is a proper shore port, and precisely \(\eta=2\) edges
lead to \(d\). The set \(S\) avoids the two ends of \(g\) and the
\(B\)-end of \(e\), so all its other incidences lead to \(T\).
Hence
\[
                         e_K(S,T)=3s-3.              \tag{2}
\]
For \(t\in T\) let \(k_t=e_K(S,t)\le3\). Girth at least five
excludes a four-cycle, so each unordered pair in \(S\) has at
most one common neighbour in \(T\). The two different vertices
\(p,q\in S\) adjacent to \(d\) have **no** common neighbour in
\(T\); otherwise \(p-d-q-t-p\) is a four-cycle. Therefore
\[
          \sum_{t\in T}\binom{k_t}{2}
                 \le \binom{s}{2}-1.                  \tag{3}
\]
But \(\sum k_t=3s-3\) by (2). For \(s=2,3,4\), convexity of
\(\binom{k}{2}\) on \(0\le k\le3\) gives the following least
possible values:
\[
\begin{array}{c|c|c}
s&\text{least-concentrated }(k_t:t\in T)
 &\min\sum\binom{k_t}{2}\\\hline
2&(2,1)&1=\binom22\\
3&(2,2,2)&3=\binom32\\
4&(3,2,2,2)&6=\binom42.
\end{array}                                            \tag{4}
\]
Each contradicts the strict deficit in (3), proving \(s\ge5\).

For \(s=5\), (2) gives \(\sum k_t=12\), while (3) gives at most
\(9\) shared pairs. The unique degree multiset with pair count
at most nine is \((3,3,2,2,2)\), with count exactly nine. Thus
every pair except \(\{p,q\}\) shares exactly one neighbour in
\(T\). The two three-element neighbourhoods cannot be disjoint
on a five-element \(S\), and they cannot meet twice without
giving a repeated pair; they meet once. Write them as
\(\{a,b,c\}\), \(\{a,d',e'\}\). Their pair sets cover six
pairs. The three degree-two neighbourhoods are three of the
four cross pairs \(bd',be',cd',ce'\); the fourth is the missing
pair \(\{p,q\}\). The vertex \(a\) has degree two into \(T\),
the endpoints \(p,q\) each degree two, and the other two vertices
degree three. Since \(h\) is the unique proper-port base in
\(S\), it would have degree one into \(T\) if it were adjacent
to \(d\). No such degree occurs. Hence \(h=a\), proving the
stated classification. \(\square\)

The other six-cut allocation \((\alpha,\eta)=(2,1)\) is untouched;
its two-vertex Hall blocks remain the cheapest direct case.
For \((1,2)\), the order-five incidence pattern is only a
necessary shape, not an exact-support example. The argument is
analytic and uses no local enumeration or OMEN.
