> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-zero class-IV two-mask closure is path or disjointness

Continue the actual class-IV \(D_2\) row and the two unique old-signature forbidden exteriors of [Notes 481--482](482-the-p1-p3-alternating-path-is-the-exact-paired-singleton-closure-gate.md). Write \(Q_P,Q_R\) for its two zero-port complete shore matchings. They have distinct masks under the exact-Case-XII odd-complement condition of Note 359. This note classifies forbidden old-signature rows that **retain these two complete zero masks** and use at most two new complete shore-matching occurrences.

## A doubled-singleton completion lemma

Let \(H\) be any cubic even-order shore with ports, let \(P,R\) be zero-port perfect matchings, and let \(W\) be another perfect matching. There exist two complete shore perfect matchings \(U,V\) satisfying
\[
 \mathbf1_P+\mathbf1_R+2\mathbf1_W+\mathbf1_U+\mathbf1_V
       =2\mathbf1_{E(H)}                                  \tag{1}
\]
**if and only if**
\[
                    W\cap(P\cup R)=\varnothing.            \tag{2}
\]
Their port sets are both the complement of \(\partial W\) among the shore ports. If \(P\ne R\), then \(U\ne V\).

Necessity is immediate: an edge in \(W\cap(P\cup R)\) would have load at least three in (1). For sufficiency, every edge of \(W\) already has load two. At each shore vertex, \(P\) and \(R\) each use an edge outside \(W\). If they use the **same** edge, put both \(U,V\) on the remaining third edge. Where \(P,R\) use different edges, put one of \(U,V\) on each. These latter edges form the components of \(P\triangle R\), all of which are even internal alternating cycles because \(P,R\) are zero-port perfect matchings. Choose either phase on each cycle and its complement for the other matching. The choices agree at both ends of every edge and give two complete perfect matchings with (1). At a port used by \(W\), neither \(U\) nor \(V\) uses it; at any other port, \(P,R,W\) are all absent and both \(U,V\) use it. A nonempty \(P\triangle R\) makes \(U,V\) distinct. \(\square\)

This lemma applies to each of the four old singleton masks in the class-IV row:

| Forbidden exterior | Old mask repeated twice | New role supplied by \(U,V\) |
|---|---|---|
| \(t=0,\ [eY]\) | \(Q_J\), ports \(\{p_1,p_5\}\) | two \(e\)-singletons, ports \(\{e,p_2,p_3,p_4\}\) |
| \(t=0,\ [eY]\) | \(Q_b\), ports \(\{e,p_2,p_3,p_4\}\) | two \(Y\)-singletons, ports \(\{p_1,p_5\}\) |
| \(t=2,\ [eX]\) | \(Q_K\), ports \(\{p_3,p_5\}\) | two \(e\)-singletons, ports \(\{e,p_1,p_2,p_4\}\) |
| \(t=2,\ [eX]\) | \(Q_a\), ports \(\{e,p_1,p_2,p_4\}\) | two \(X\)-singletons, ports \(\{p_3,p_5\}\) |

For any row of this table, (2) is necessary and sufficient for a **full forbidden BF row**: use (1) on the shore and the corresponding uniquely doubled exterior in Note 481(2) or (3). Thus a class-IV exact-Case-XII row must satisfy
\[
 Q_s\cap(Q_P\cup Q_R)\ne\varnothing
           \qquad(s\in\{a,b,J,K\}).                       \tag{3}
\]
These are four whole-mask overlap requirements. Counting only port hits cannot see them, since \(P,R\) use no ports.

## Exhaustive radius-two fixed-zero boundary

Suppose \(Q_P\ne Q_R\), every zero-port shore matching has an odd closed complementary component, and all four one-new-mask gates of Note 481(4) fail. Then a forbidden row retaining \(Q_P,Q_R\), retaining only the old **port signatures**, and using exactly two new complete shore-matching occurrences exists **if and only if** at least one of the following holds:

1. \(Q_a\triangle Q_K\) pairs \(p_1\) with \(p_3\), or \(Q_b\triangle Q_J\) does so, as in Note 482(2)--(3);
2. one of \(Q_a,Q_b,Q_J,Q_K\) is edge-disjoint from \(Q_P\cup Q_R\), as in (2).

Indeed, at \(t=0\) the four singleton slots have signatures \(b,b,J,J\); at \(t=2\) they have \(a,a,K,K\). With exactly two new occurrences, either one slot in each singleton role is new, or both slots in just one role are new. The first distribution is exactly the paired-singleton exchange of Note 482. In the second, the other old role is repeated, so (1)--(2) are necessary and sufficient. The failed one-new gates ensure that the two constructed masks really are new in either construction. These are all distributions. The zero-new case is excluded by Note 480 and the one-new case by the four assumed gate failures. Therefore, under these assumptions, **no forbidden old-signature row retaining the old zero masks can use fewer than three new complete shore-matching occurrences** exactly when all six path/disjointness tests above fail.

In the Petersen-substituted 29-vertex boundary of Note 481, the two \(p_1p_3\) path tests fail by Note 482, while the unchanged edges labelled \(Ra,Pb,PJ,RK\) witness (3) for \(a,b,J,K\), respectively. All radius-two fixed-zero mechanisms therefore fail. Its actual old-signature forbidden rows change three complete shore masks, as Note 481 proves; those rows also change one zero mask.

The conclusion is confined to old port signatures and rows retaining both old zero masks. Genuine exact Case XII could still force a forbidden row by changing a zero mask or a port signature; whether its other required positive rows do so is unresolved. The proof is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review. \(\square\)

Later boundary: [Note 484](484-a-doubled-singleton-and-two-retained-masks-complete-the-changed-zero-row.md) classifies the allocation with one new zero mask and one new singleton mask. The repeated old singleton \(W\) must avoid both the retained zero mask \(S\) and the retained other singleton \(B\); this edgewise disjointness is sufficient as well. Together with Notes 481--483 it exhausts old-signature forbidden rows using at most two new complete shore-matching occurrences.

Odd-zero correction: [Note 485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md) proves that every row constructed by the repeated-\(W\) lemma here would have a forbidden Tait state and therefore a clean zero-port shore mask. Under Note 359's odd-zero premise, the four disjointness gates are automatically false; they are not four independent exact-Case-XII restrictions.
