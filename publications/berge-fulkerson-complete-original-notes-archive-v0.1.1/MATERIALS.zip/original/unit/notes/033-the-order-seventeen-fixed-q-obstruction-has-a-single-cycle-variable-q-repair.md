> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The order-seventeen fixed-Q obstruction has a single-cycle repair

The fixed-\(Q\) counterexample of Note 030 is repaired by changing exactly
one third matching along exactly one alternating cycle.  This gives a
strictly minimal variable-\(Q\) repair for that pole, while showing that not
every ordinary capacity transversal admits such a representation.

For two edge-covering \(Q\)-five-tuples \(Q,Q'\), measure repair cost by

\[
r_Q=|\{t:Q_t\ne Q'_t\}|,
\]

\[
r_C=\sum_t \#\operatorname{comp}(Q_t\triangle Q'_t),
\qquad
d=\frac12\sum_t|Q_t\triangle Q'_t|.
\]

The minimum repair cost for the failed tuple of Note 030 is

\[
\boxed{(r_Q,r_C,d)=(1,1,3)}.
\]

Only \(Q_0\) changes.  Its symmetric difference with \(Q'_0\) is the
internal alternating six-cycle

\[
5-6-10-11-16-15-5,
\]

with edge indices

\[
\{e_7,e_8,e_{10},e_{16},e_{18},e_{22}\}.
\]

The other four \(Q_t\) remain fixed.  The new tuple still covers every edge,
its half-support is exactly this \(C_6\), and its endpoint fibre contains a
capacity-two split.  Note 030 exhaustively rules out cost zero, so the repair
is strictly minimal.  There is one minimum \(Q'\)-tuple, two corresponding
capacity transversals and two endpoint representations.  Six further
transversals are repaired by changing \(Q_0\) along one \(C_8\).

The pole has 1,276 ordinary capacity-two transversals.  Their minimum number
of changed \(Q_t\) is distributed as

\[
\begin{array}{c|rrrrrr}
r_Q&1&2&3&4&5&\text{no edge-covering completion}\\\hline
\text{transversals}&8&120&454&343&173&178.
\end{array}
\]

For the 1,098 representable transversals, every changed \(Q_t\) in an
optimal solution differs by one alternating cycle, so \(r_Q=r_C\).  The
remaining 178 transversals have no edge-covering \(Q'\)-completion even when
all five third matchings may change.  Hence the stronger claim that every
ordinary capacity transversal admits a variable-\(Q\) representation is
false.

The surviving scoped candidate is narrower: if an edge-covering \(Q\)-tuple
of an exact-S pole has no fixed-\(Q\) rounding, perhaps one boundary-preserving
alternating-cycle exchange in one \(Q_t\) always produces an edge-covering
tuple whose fibre rounds.  The present note verifies this only for the
specific Note 030 obstruction and does not prove a universal radius-one
theorem.

The frozen verifier is
`scratch/worker-proof/verify_n17_single_q_c6_repair.py`; it ends with
`N17_SINGLE_Q_C6_REPAIR_VERIFIED`.  The complete 1,276-transversal
classification is produced by
`scratch/worker-proof/classify_n17_variable_q_repairs.py`.
