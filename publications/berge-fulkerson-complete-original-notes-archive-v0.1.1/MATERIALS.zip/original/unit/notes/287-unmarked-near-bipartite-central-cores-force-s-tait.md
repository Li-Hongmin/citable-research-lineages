> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Unmarked near-bipartite central cores force S-Tait

Work in the one-internal-mark central-path profile of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with both real \((ea)(ad)\) and \((ea)(ac)\) rows and the complete exact-Case-XII matching closure. The shore ports are
\[
E=e,\qquad A=a:\Sigma,\qquad I=h_1,\qquad D=h_2,
\qquad H=h_3,\qquad J=h_4,
\]
and the allowed pentagon is \(S=e-a-b-d-c-e\). Let \(C=F[\Sigma]\) be the original **unmarked** central core.

**Theorem.** If an internal edge \(g\in E(C)\) makes \(C-g\) bipartite, then the complete five-pole has a genuine three-edge-colouring and its Tait-state set is \(S\). Equivalently, a Tait-empty exact-Case-XII pole in this central-path profile has **no single-edge odd-cycle transversal in its unmarked core**. This is a conditional theorem for the remaining forced central-path geometry; it does not exclude the \(S\)-Tait branch or imply the four-slot load intersection.

## Reduction to the last port placement

The core is odd by [Note 277](277-the-central-path-rows-force-an-unmarked-odd-shore-cycle.md), so the two ends of \(g\) lie in one bipartition side \(B\) of \(C-g\). If the internal marked edge \(e\) has both ends in the same side, the subdivided six-port shore minus \(g\) is bipartite, contradicting [Note 281](281-the-central-six-port-shore-has-no-single-edge-odd-cycle-transversal.md). Thus write its ends as \(v\in B,w\in R\). [Note 282](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md) leaves two cut profiles. Its \(4+1\) profile already forces \(S\)-Tait by [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md). In the \(3{:}2\) profile, exactly three of \(A,I,D,H,J\) are based in \(B\), and the four-port slot \(Z_e\) makes \(k=|B\cap\{A,I,D\}|\) equal to one or two. [Note 286](286-two-b-side-ports-in-the-three-two-core-force-s-tait.md) forces \(S\)-Tait when \(k=2\).

It remains to handle \(k=1\). Here \(H,J\in B\), and the two \(R\)-based proper cut edges form one of the pairs
\[
R_0\in\{\{A,I\},\{I,D\},\{A,D\}\}.                 \tag{1}
\]
The full five-pole becomes bipartite after deleting the four exceptional proper edges \(g,t_ew\), and the two cut edges named by \(R_0\). In every forced row, [Note 283's balance](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) gives
\[
X_a:(t_ev,g\notin X_a),\qquad
Y_a,V_a:(t_ew,g\notin Y_a\cup V_a),\qquad
Z_e:(E,g\in Z_e),\qquad
W_d,W_c:t_ev.                                             \tag{2}
\]

We use the following direct colouring test. If a **complete actual singleton matching other than singleton-\(e\)** selects \(g,t_ev\) and both \(R_0\) cut edges, then its complement contains only one of the four bipartition exceptions: \(t_ew\). At \(t_e\), the matching chooses \(t_ev\), so the complementary terminal semiedge \(e\) continues through \(t_ew\). Hence that exception lies on an open terminal path, every closed cycle is even, and the matching extends to a Tait colouring. Exact support excludes every \(T\)-Tait state by its absent \(T\)-loops, so this colouring has a state in \(S\), and ordinary terminal-path switches give the whole of \(S\).

## Two placements are already present in the required rows

If \(R_0=\{A,I\}\), the required \((ea)(ad)\) row contains the singleton-\(d\) occurrence \(W_d\) with proper shore ports \(A,I\). Since both are based in \(R\), the shore balance equation forces \(W_d\) to select \(t_ev\) and \(g\). It meets the colouring test.

If \(R_0=\{I,D\}\), the required \((ea)(ac)\) row contains singleton-\(c\) occurrence \(W_c\) with proper shore ports \(I,D\). The same balance forces \(t_ev,g\), so the colouring test applies again. Neither argument assumes a match from one row equals a match from the other.

## The final pair is exposed by one pure-half switch

Let \(R_0=\{A,D\}\); then \(I\in B\) and \(A,D\in R\). Take the zero-port shore matching \(X_a\) and four-port shore matching \(Z_e\) from either required row. Their symmetric difference has two paths with the forced pure pairing
\[
E\longleftrightarrow I,\qquad A\longleftrightarrow D.    \tag{3}
\]
By (2), \(g\in Z_e\setminus X_a\), and the \(E\)--\(I\) path contains \(t_ev\) but avoids \(t_ew\). The edge \(g\) cannot lie on a closed component of \(X_a\triangle Z_e\): that component would be an even alternating cycle with exactly one edge internal to a bipartition side, an impossibility. It cannot lie on the \(E\)--\(I\) path either. Both port edges on that path belong to \(Z_e\), so its internal path from \(t_e\in R\) to the base of \(I\in B\) has odd length. If it used \(g\), exactly one of its internal edges would preserve the bipartition side, forcing that length to be even. Therefore \(g\) lies on the \(A\)--\(D\) alternating path.

Switch that one path between the **actual** shore matchings \(X_a,Z_e\). The resulting shore perfect matching \(N_{AD}\) has exactly the proper ports \(A,D\), retains \(t_ev\), and gains \(g\). Its existence is graph-induced matching closure, not a selected-boundary inference.

The central-path exterior has the following independent singleton-\(b\) matching with exactly those two shore interfaces:
\[
M^{\mathrm{ext}}_{b,AD}=
\{\,b:\mathrm{terminal},\ a:\Sigma,\ c:E_{\rm ext},\ d:B_{\rm ext},
1A_{\rm ext},\ 3C_{\rm ext},\ 4D_{\rm ext},\ h_2\,\}.       \tag{4}
\]
Indeed \(t_a,t_b,t_c,t_d\) are covered respectively by \(a:\Sigma\), the terminal \(b\), \(c:E_{\rm ext}\), and \(d:B_{\rm ext}\); \(u_1,u_2,u_3,u_4\) are covered by \(1A_{\rm ext},h_2,3C_{\rm ext},4D_{\rm ext}\); and the five exterior path vertices \(A_{\rm ext},B_{\rm ext},C_{\rm ext},D_{\rm ext},E_{\rm ext}\) are covered exactly once by \(1A_{\rm ext},d:B_{\rm ext},3C_{\rm ext},4D_{\rm ext},c:E_{\rm ext}\). Thus (4) glues to \(N_{AD}\) and produces a complete actual singleton-\(b\) matching. It selects \(g,t_ev,A,D\), so the colouring test finishes the final placement and the theorem. \(\square\)

The same colouring also fixes the complementary shore pairing of this new complete matching. The exterior complement of (4) has arms \(e\leftrightarrow E\), \(a\leftrightarrow I\), \(c\leftrightarrow H\), \(d\leftrightarrow J\). All four terminal vertices lie in \(R\), and the only remaining same-side edge \(t_ew\) lies on the \(e\)-terminal path, whose endpoints therefore receive the same complementary colour. The other terminal path has differently coloured endpoints. Flipping its two colours gives Tait states with \(b\) and either endpoint; exact support permits only \(ab,bd\). Thus the different-colour path is \(a\)--\(d\), and the shore complement of \(N_{AD}\) necessarily pairs
\[
\boxed{EH\mid IJ.}                                       \tag{5}
\]
This is a complete-matching consequence of negative support; it does not identify a matching across the two required BF rows.

The proof uses one actual row in each of the \(AI,ID\) cases and one row plus a path switch in the \(AD\) case. The new exterior matching (4) is checked vertex by vertex. [Note 288](288-the-one-b-port-near-bipartite-core-profile-is-not-exact-case-xii.md) strengthens this conclusion: a singleton-\(c\) completion makes the entire one-\(B\)-port profile incompatible with exact support. No local perfect-matching census, OMEN run, or selected-row substitution is used. The remaining mathematical obstruction is the general high-rank unmarked core and, even in the \(S\)-Tait near-bipartite branch, synchronization of the prescribed four-slot load vectors. The upstream forced exterior row tables of Notes 271–272 still require independent verification.
