> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The remaining near-bipartite core has an empty R-R two-port fibre

Continue the \(3{:}2\) unmarked near-bipartite central-core profile of [Notes 286–288](288-the-one-b-port-near-bipartite-core-profile-is-not-exact-case-xii.md). Let \(C-g\) be bipartite with \(g\subset B\), let the internal marked edge run from \(v\in B\) to \(w\in R\), and let exactly two of \(A=a:\Sigma,I=h_1,D=h_2\) be based in \(B\). Exactly one of \(H=h_3,J=h_4\) is then based in \(R\). Write \(R_0\) for the two \(R\)-based proper shore ports, one in \(\{A,I,D\}\) and one in \(\{H,J\}\). Work with the central-path exterior of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) and complete exact-Case-XII negative support.

**Theorem.** The complete shore matching fibre with port set \(R_0\) contains **no** matching selecting both \(t_ev\) and \(g\). This exclusion holds even if the exact pole has all five allowed \(S\)-Tait states. It is a condition on every graph-induced shore perfect matching, not on selected BF rows.

The singleton-\(c\) exterior has a valid matching with each of the six possible \(R_0\) port sets. Besides the terminal semiedge \(c\), its selected edges are:
\[
\begin{array}{c|l}
R_0&\text{selected exterior edges other than terminal }c\\\hline
AH&a:\Sigma,\ h_3,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 1B_{\rm ext},\ 2C_{\rm ext},\ 4D_{\rm ext}\\
AJ&a:\Sigma,\ h_4,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 1B_{\rm ext},\ 2C_{\rm ext},\ 3D_{\rm ext}\\
IH&a:C_{\rm ext},\ h_1,\ h_3,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 2B_{\rm ext},\ 4D_{\rm ext}\\
IJ&a:C_{\rm ext},\ h_1,\ h_4,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 2B_{\rm ext},\ 3D_{\rm ext}\\
DH&a:C_{\rm ext},\ h_2,\ h_3,\ b:D_{\rm ext},\ d:B_{\rm ext},\ 1A_{\rm ext},\ 4E_{\rm ext}\\
DJ&a:C_{\rm ext},\ h_2,\ h_4,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 1B_{\rm ext},\ 3D_{\rm ext}.
\end{array}                                                     \tag{1}
\]
In every row of (1), the selected \(a,b,d\) edges cover \(t_a,t_b,t_d\), while terminal \(c\) covers \(t_c\). Each \(u_i\) is covered by its displayed shore edge or its one displayed path edge. The remaining path edges and marked halves cover each of \(A_{\rm ext},B_{\rm ext},C_{\rm ext},D_{\rm ext},E_{\rm ext}\) once: respectively by
\[
\begin{array}{c|ccccc}
AH&b:A&1B&2C&4D&d:E\\
AJ&b:A&1B&2C&3D&d:E\\
IH&b:A&2B&a:C&4D&d:E\\
IJ&b:A&2B&a:C&3D&d:E\\
DH&1A&d:B&a:C&b:D&4E\\
DJ&b:A&1B&a:C&3D&d:E.
\end{array}                                                     \tag{2}
\]
Thus these are six actual exterior matchings, independent of any prescribed BF row.

Suppose a shore matching \(N\) in the stated fibre selected \(t_ev,g\). Glue it to the matching in (1) with the same port set. The resulting full-pole singleton-\(c\) matching selects \(g,t_ev\) and both exceptional \(R_0\) cut edges. [Note 288's singleton-\(c\) parity argument](288-the-one-b-port-near-bipartite-core-profile-is-not-exact-case-xii.md) applies verbatim: its complement has only \(t_ew\) as an unselected same-side edge, lying on the \(e\)-terminal path. Every closed cycle is even, and switching the other terminal path yields two Tait states incident to \(c\), neither of which is \(ce\). At least one is a forbidden \(T\)-state, contradicting exact support. \(\square\)

The theorem does not show that this prohibited fibre is forced to be nonempty. That existence question is now a precise complete-PM-closure gate for the surviving \(3{:}2\) profile. The \(4+1\) profile, the four-slot load intersection, and high-rank cores remain open. No graph census or local bulk computation was used.
