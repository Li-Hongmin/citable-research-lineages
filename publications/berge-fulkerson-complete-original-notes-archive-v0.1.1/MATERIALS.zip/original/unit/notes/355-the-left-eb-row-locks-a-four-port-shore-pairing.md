> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A left \((ea)(eb)\) row locks a four-port shore pairing

> **Later consequence:** [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) excludes the left row altogether by a zero-port \(U_A\) gluing. The pairing lock and fixed-identity gate below remain valid conditional calculations, but are no longer the unresolved Case-XII branch.

Use the central-path six-port exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact-Case-XII perfect-matching support and
\(S=e-a-b-d-c-e\). Write the shore ports as \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). By [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) and [Note 354](354-the-right-eb-row-forces-a-forbidden-double-t-completion.md), every surviving required \((ea)(eb)\) row has the left singleton-\(a\) mask \(Y_L\) and the zero-port \(eb\)-triple mask \(U_D\). The conclusions here remain conditional on the hand-derived exterior and endpoint classifications of [Notes 271 and 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md).

**Theorem.** Let \(M_e\) be either complete singleton-\(e\) occurrence of such a row whose \(e\)-path in \(U_D\triangle M_e\) ends at \(c\). Switch that complete path, obtaining the triple \(U'_{ade}\). Then the *shore-only* symmetric difference \(Y_L|_\Sigma\triangle U'|_\Sigma\) pairs its four ports as
\[
                         EI\mid HJ.                         \tag{1}
\]
Here (1) denotes two paths, one from \(E\) to \(I\) and one from \(H\) to \(J\); common edges of the two shore matchings are ignored. In particular, either cross pairing \(EH\mid IJ\) or \(EJ\mid IH\) would create a genuine forbidden \((eb)(bc)\) BF row. This holds at arbitrary shore order and cycle rank.

**Proof.** The relevant left exterior masks are
\[
\begin{aligned}
X_{ea}&=\{a:C,1A,2B,3D,4E;\ b,c,d\},\\
Y_{L,a}&=\{c:A,b:D,d:E,1B,2C,H,J;\ a\},\\
U_{D,eb}&=\{b:D,1A,2B,3C,4E;\ a,c,d\}.
\end{aligned}                                                  \tag{2}
\]
The \(e\to c\) masks in [Note 346's table](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md) are the three orientation-I masks \(a:C,4D\), \(a:\Sigma,2C,4D\), and \(a:\Sigma,3C,4D\), each with \(b:A,c:E,d:B\). For each, the \(e\)-path enters the exterior at \(I\), then follows
\[
 I(M),\ 1A(U_D),\ b:A(M),\ b:D(U_D),\
 4D(M),\ 4E(U_D),\ c:E(M),\ c_{\rm term}(U_D).        \tag{3}
\]
The shore segment joins \(E,I\). After the complete switch, independent of which of the three masks was used,
\[
 U'|_{\rm ext}=\{b:A,c:E,2B,3C,4D,I;\ a,d,e\},
 \qquad \partial_\Sigma U'=\{E,I\}.                     \tag{4}
\]
The switched singleton has boundary \(c\), and the six occurrences still give a genuine \((ea)(bc)\) row. Put \(R=X+Y_L+U'\).

The two masks (6) and (9) below are in fact the only possible singleton-\(b\) exteriors contained in \(R\). Such a matching must take \(a:C,d:E,c:A\): the other available edges at those marked vertices are terminal edges, or collide at \(E\). The shore port \(D\) has load zero in \(R\), so \(u_2\) must take \(2B\); then \(u_1\) must take \(I\). At \(u_3,u_4\), the remaining choice is \((H,4D)\) or \((3D,J)\). In particular it cannot reuse \(Y_L\)'s \(HJ\)-port shore matching unchanged.

The shore restrictions of \(Y_L,U'\) have ports \(HJ,EI\). Suppose their shore symmetric difference pairs \(I\) with \(J\). Exchange the two shore restrictions along that entire \(I\)--\(J\) path. The resulting shore matchings \(Y^\sharp,U^\sharp\) have port sets \(IH,EJ\), respectively, and
\[
       Y_L|_\Sigma+U'|_\Sigma
             =Y^\sharp|_\Sigma+U^\sharp|_\Sigma.        \tag{5}
\]
Glue \(Y^\sharp|_\Sigma\) to the exterior mask
\[
 B_b^{IH}|_{\rm ext}
       =\{a:C,c:A,d:E,2B,4D,I,H;\ b\}.                \tag{6}
\]
It is a complete actual singleton-\(b\) matching, contained edgewise in \(R\): its proper exterior edges come from \(X,Y_L,U'\), and its shore edges come from \(Y_L,U'\) by the path exchange. The shore residual is \(X|_\Sigma+U^\sharp|_\Sigma\). Outside the shore the residual has exactly the four-edge path
\[
                 c_{\rm term},\ c:E,\ 4E,\ J,             \tag{7}
\]
the eight-edge closed cycle
\[
           b:D,\ 3D,\ 3C,\ 2C,\ 2B,\ 1B,\ 1A,\ b:A,    \tag{8}
\]
and two copies of each \(a,d\) terminal semiedge. The shore residual is the union of a zero-port perfect matching and an \(EJ\)-port matching: it has one odd-length \(E\)--\(J\) path, with lengths counting both port semiedges, and only even alternating closed cycles. Gluing (7) to that shore path replaces the two \(J\) semiedges by one proper edge, so the complete \(e\)--\(c\) path is even. The cycle (8) is even as well.

If instead the shore difference pairs \(I\) with \(H\), exchange that path. Now \(Y^\sharp,U^\sharp\) have port sets \(IJ,EH\). Glue \(Y^\sharp\) to
\[
 B_b^{IJ}|_{\rm ext}
       =\{a:C,c:A,d:E,2B,3D,I,J;\ b\}.                \tag{9}
\]
It is again a complete singleton-\(b\) matching contained in \(R\). The exterior residual has no closed component and, apart from the doubled \(a,d\) terminal semiedges, is exactly the twelve-edge path
\[
 c_{\rm term},\ c:E,\ 4E,\ 4D,\ b:D,\ b:A,\
 1A,\ 1B,\ 2B,\ 2C,\ 3C,\ H .                         \tag{10}
\]
The shore residual \(X+U^\sharp\) has an odd-length \(E\)--\(H\) path and only even closed cycles, so the complete \(e\)--\(c\) path is again even.

In either case, alternate two colours on every residual path and cycle, giving actual triple matchings \(Q_{acd},Q_{ade}\) with
\[
                         R=B_b+Q_{acd}+Q_{ade}.             \tag{11}
\]
Retain the other three complete matchings of the switched \((ea)(bc)\) row: the unused singleton-\(e\) matching \(F_e\), the switched singleton-\(c\) matching \(C_c\), and the original singleton-\(b\) matching \(W_b\). Regrouping as
\[
       (Q_{acd}+F_e+W_b)\mid(Q_{ade}+B_b+C_c)
\]
gives \((eb)(bc)\), forbidden by the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Thus \(I\) can be paired with neither \(J\) nor \(H\); the only four-port pairing is (1). \(\square\)

The theorem isolates the remaining left obstruction as a definite shore-path lock for **each** \(e\to c\) singleton-\(e\) occurrence and every zero-port phase. It does not show that the locked pairing is impossible. It uses actual full-pole matchings throughout; the intermediate shore-only switch is glued to an explicitly contained exterior singleton mask before any BF completion is asserted. No all-terminal perfect matching is invoked.

**Exact fixed-identity completion gate.** Retain the same complete \(F_e,C_c,W_b\) and the resulting load \(R=X+Y_L+U'\), but allow an arbitrary complete singleton-\(b\) matching \(B_b\), not necessarily obtained by a two-matching shore path switch. A forbidden \((eb)(bc)\) re-decomposition retaining these three identities exists **if and only if** one of the following two tests succeeds:

1. \(B_b\le R\) has exterior (6), shore ports \(IH\), and every closed component of \((R-B_b)|_\Sigma\) is even; or
2. \(B_b\le R\) has exterior (9), shore ports \(IJ\), and every closed component of \((R-B_b)|_\Sigma\) is even.

Indeed, the forced-exterior argument above proves that these are the only singleton-\(b\) possibilities within \(R\). For (6), the exterior residual is (7), (8), and the doubled \(a,d\) terminal edges; for (9), it is (10) and those doubled terminal edges. In either case the shore residual has exactly two port ends, \(EJ\) or \(EH\). Its internal vertices have degree two. Because \(|V(\Sigma)|\) is even, if all its closed cycles are even, its unique open path uses an even number of shore vertices and therefore has odd length including both port semiedges. It joins the even-length exterior \(c\)-arm into an even \(e\)--\(c\) path. Thus the residual splits into \(Q_{acd},Q_{ade}\) and yields the forbidden row. Conversely, any such re-decomposition supplies its singleton \(B_b\le R\) and two-colours the residual, so every closed shore cycle must be even. The pairing lock (1) rules out the easiest two-matching constructions of \(B_b\); it does not settle these two full three-matching fibres.
