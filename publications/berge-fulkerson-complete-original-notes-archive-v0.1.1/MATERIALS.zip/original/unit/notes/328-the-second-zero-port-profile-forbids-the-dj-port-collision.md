> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The second zero-port profile forbids the DJ port collision

In the genuine left/right-row, complete exact-Case-XII,
\(R_0=DJ\) near-bipartite branch, the right row supplies
an actual zero-proper-port shore matching \(X\) selecting
\(g,t_{ew}\). By [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md),
the full complement of every such matching pairs the six
shore ports as either
\[
                   EA\mid ID\mid HJ
             \quad\text{or}\quad EJ\mid AD\mid IH.       \tag{1}
\]

**Port-coincidence rule.** If two distinct proper ports
among \(A,I,D,H,J\) have the same cubic base vertex,
their pair must be one of \(ID,HJ,AD,IH\). In
particular, the \(D,J\) bases are distinct.

**Proof.** Since \(X\) selects no proper port, the two
port edges at a common base are both unselected. Cubicity
forces \(X\) to select the base's third edge. The full
complement therefore has the two-edge component joining
those two ports through the base. Equation (1) lists all
possible such proper-port pairs and omits \(DJ\).
\(\square\)

This removes the \(d=j\) local-collision alternative
mentioned in [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md).
It does not address the remaining collision of the marked
edge's \(B\)-end with an endpoint of \(g\), the larger
Hall blocks, other profiles, or Berge–Fulkerson. The
deduction uses the cited hand-derived complete-fibre gate;
no local computation or OMEN run was used.
