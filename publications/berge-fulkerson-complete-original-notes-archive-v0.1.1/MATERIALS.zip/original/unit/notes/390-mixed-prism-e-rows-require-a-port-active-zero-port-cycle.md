> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed prism \(e\)-rows require a port-active zero-port cycle

Continue the full-row two-mask theorem of [Note 389](389-mixed-e-rows-need-two-zero-port-shore-matchings-in-two-spoke-prism.md) for its two-spoke prism exterior. Let \(Q\) be a zero-port shore perfect matching whose complement has no odd closed component and has one of the two exceptional signed signatures in [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Write \(P_e\) for the shore complement path starting at terminal \(e\), and \(P_o\) for its odd proper-to-proper path \(p_2p_4\). The third port path is even. The internal vertices of the three paths and any closed components of \(Z-Q\) are disjoint.

> **Port-active cycle gate.** Suppose an actual BF row of type \((ej)(ek)\) contains \(Q\) as one zero-port triple shore restriction and contains at least one triple state from the doubly blocked pair of \(Q\). Let \(Q'\) be the other complete zero-port triple shore restriction. Then some alternating cycle of \(Q\triangle Q'\) meets an internal vertex of \(P_e\) or \(P_o\). Equivalently, \(Q'\) cannot agree with \(Q\) at every vertex of both designated paths.
>
> This is necessary for **any** mixed allowed–forbidden \(ej\)-row in a putative exact-Case-XII pole when one of its shore matchings is clean. It applies whether \(Q'\) is clean or has odd closed complementary components.

**Proof.** Suppose instead that no cycle of \(Q\triangle Q'\) meets either \(P_e\) or \(P_o\). Then \(Q'\) uses the same \(Q\)-edge as \(Q\) at every vertex of those paths. In the shore load-two equation
\[
Q+Q'+E_0+E_1+X+Y=2\mathbf1_{E(Z)},                       \tag{1}
\]
the common matching edge is saturated at each such vertex. The four singleton colour pairs on the two residual path edges must therefore be complementary. The endpoint port-pair relation of [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) holds separately along **each of these two unchanged paths**, even though \(Q\) and \(Q'\) may differ on the third path or on closed components.

Let \(I=\{E_0,E_1,X,Y\}\), with \(E_0,E_1\) the singleton-\(e\) occurrences, and let \(L_i\subset I\) be the two singleton colours at port \(p_i\). Both \(E_i\) use three proper ports; \(X,Y\) each use two.

If the doubly blocked pair is \(\{ab,Cc\}\), the unchanged even path \(ep_5\) and unchanged odd path \(p_2p_4\) give
\[
L_5=\{X,Y\},\qquad L_2=L_4.                               \tag{2}
\]
Each \(E_i\) is absent from \(p_5\), can use at most two of \(p_1,p_3\), and must use three proper ports. Since it belongs to \(L_2,L_4\) either twice or not at all, it must belong to both. Hence \(L_2=L_4=\{E_0,E_1\}\). At the exterior vertex \(B\), an \(E_i\) using ports \(p_2,p_4\) has only the \(B\)-half of \(AB=p_1\) left to cover \(B\), and so cannot use port \(p_1\). To reach three proper ports, it must use \(p_3\). Thus
\[
\operatorname{ports}(E_i)=\{p_2,p_3,p_4\},\qquad
\operatorname{ports}(X)=\operatorname{ports}(Y)=\{p_1,p_5\}.       \tag{3}
\]
These are precisely the port sets ruled out for **any forbidden triple** by Note 388's first marked-half proof. This contradicts the assumed row.

For the other exceptional pair \(\{AC,bc\}\), the unchanged paths are even \(ep_3\) and odd \(p_2p_4\). They give \(L_3=\{X,Y\}\) and \(L_2=L_4\). The same count forces \(L_2=L_4=\{E_0,E_1\}\), and the same vertex \(B\) forbids \(E_i\) at \(p_1\). Therefore
\[
\operatorname{ports}(E_i)=\{p_2,p_4,p_5\},\qquad
\operatorname{ports}(X)=\operatorname{ports}(Y)=\{p_1,p_3\}.       \tag{4}
\]
Note 388's second marked-half proof again excludes even one forbidden triple. This contradiction proves that \(Q\triangle Q'\) must meet \(P_e\) or \(P_o\). As the symmetric difference of two perfect matchings is a union of alternating even cycles, at least one such cycle is port-active in the stated sense. \(\square\)

The gate turns “\(Q'\ne Q\)” into a specific necessary location for the change. Flipping only cycles in closed components of \(Z-Q\), or changing only the third even shore path while leaving \(P_e,P_o\) untouched, cannot realize a required mixed \(ej\)-row from a clean exceptional \(Q\). Note 386's eight-vertex example has a \(Q\)-alternating six-cycle meeting both designated paths and then produces forbidden Tait loops, but this example does not prove that every larger shore has such a cycle or that every port-active cycle gives a forbidden BF type. The remaining task is to use the complete zero-port matching family and exact support to control these port-active cycles. This is a hand proof awaiting independent review; no OMEN or local mathematical recomputation was used.
