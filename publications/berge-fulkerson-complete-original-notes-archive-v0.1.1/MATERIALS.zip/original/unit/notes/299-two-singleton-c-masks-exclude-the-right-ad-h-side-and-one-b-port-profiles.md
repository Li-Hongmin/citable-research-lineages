> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two singleton-c masks exclude the right ad H-side and one-B-port profiles

Continue the central-path exterior and the genuine right \((ea)(ad)\) row of [Notes 297–298](298-the-right-central-ad-row-forces-s-tait-in-the-three-two-near-bipartite-core.md). The six shore ports are \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). Let the unmarked core become bipartite after deleting \(g\subset B\), with the internal marked edge joining \(v\in B\) to \(w\in R\), and assume the \(3{:}2\) profile of Note 282. Colour the exterior as in Note 283: all five terminal vertices lie in \(R\); the only same-side proper edges are \(g,t_ew\) and the two \(R\)-based shore cut edges \(R_0\). Work under complete exact-Case-XII support, whose allowed Tait states are \(S=e-a-b-d-c-e\).

**Theorem.** If \(R_0\in\{AI,IH,DH\}\), the complete shore matching fibre with ports \(AH\) has **no** member selecting both \(g,t_ew\). In the right \((ea)(ad)\) row, the opposite singleton \(W_d\) necessarily is such a member for each of these three side placements. Consequently those placements are impossible. Combining this with Note 298, a right \((ea)(ad)\) row in the stated \(3{:}2\) near-bipartite profile can survive complete exact support only when
\[
                         \boxed{R_0=IJ\quad\text{or}\quad R_0=DJ.}       \tag{1}
\]
In either surviving placement its zero-port occurrence selects \(g,t_ew\) and the pole has an actual \(S\)-Tait colouring. This is a necessary boundary, not an existence assertion.

## The two actual singleton-c exterior masks

Both masks below have the same selected shore ports \(A,H\). Each includes terminal \(c\), and the entries list its other selected exterior edges. The last column is the *complete exterior complement* route system on the four unselected terminals and the four free shore ports \(E,I,D,J\):
\[
\begin{array}{c|l|l}
 &\text{selected edges besides terminal }c&\text{complement routes}\\\hline
M_0&a:\Sigma,\ b:A_{\rm ext},\ d:E_{\rm ext},\ 1B_{\rm ext},\ 2C_{\rm ext},\ 4D_{\rm ext},\ h_3
   &a\!\leftrightarrow\!b,\ d\!\leftrightarrow\!D,\ I\!\leftrightarrow\!J,\ e\!\leftrightarrow\!E\\
M_1&a:\Sigma,\ b:D_{\rm ext},\ d:B_{\rm ext},\ 1A_{\rm ext},\ 2C_{\rm ext},\ 4E_{\rm ext},\ h_3
   &a\!\leftrightarrow\!J,\ b\!\leftrightarrow\!d,\ I\!\leftrightarrow\!D,\ e\!\leftrightarrow\!E.
\end{array}                                                       \tag{2}
\]
Both are actual exterior perfect matchings. For \(M_0\), the marks \(t_a,t_b,t_c,t_d\) are covered by \(a:\Sigma,b:A,c_{\rm term},d:E\), the path vertices \(A_{\rm ext},\ldots,E_{\rm ext}\) by \(b:A,1B,2C,4D,d:E\), and \(u_1,\ldots,u_4\) by \(1B,2C,h_3,4D\). For \(M_1\), the analogous three covers are \((a:\Sigma,b:D,c_{\rm term},d:B)\), \((1A,d:B,2C,b:D,4E)\), and \((1A,2C,h_3,4E)\). Taking the unused edges at each exterior vertex gives the routes in (2). In particular, the terminal paths \(a\)--\(b\) of \(M_0\) and \(b\)--\(d\) of \(M_1\) lie wholly outside the shore.

## Reusing one complete shore matching

Suppose a shore matching \(N\) has ports \(AH\) and selects \(g,t_ew\). Glue **the same** \(N\) to either mask in (2). The selected edges \(g,t_ew\) disappear from each complete matching's complement. The selected \(R\)-based cut edge among \(A,H\) also disappears. Thus the only possible same-side edge in either complement is the *other* cut edge in \(R_0\). All additional closed shore cycles are even. Whenever this remaining exception lies on an open terminal path, every closed cycle is even and the singleton-\(c\) matching extends to a Tait colouring. The external terminal pair without an exception is the differently coloured path, so switching its two colours produces two states incident to \(c\); an \(a\)--\(b\) pair gives \(ca,cb\), and a \(b\)--\(d\) pair gives \(cb,cd\). Each includes a forbidden state because \(c\) is adjacent only to \(e,d\) in \(S\).

If \(R_0=DH\), then \(H\) is selected by \(N\) and \(D\) is the sole unselected exception. Under \(M_0\), the exterior arm \(d\)--\(D\) puts \(D\) on an open terminal path for **every** shore-complement pairing. The exterior \(a\)--\(b\) path has no exception. The resulting \(ca\) or \(cb\) Tait state is forbidden. Thus no such \(N\) exists.

If \(R_0=AI\) or \(IH\), the selected cut edge is respectively \(A\) or \(H\), and the sole unselected exception is \(I\). Under \(M_0\), its exterior route is \(I\)--\(J\). Unless the shore complement of \(N\) also pairs \(I\)--\(J\), this exception lies on an open terminal path, while the exterior \(a\)--\(b\) path forces a forbidden \(ca\) or \(cb\) Tait state. Exact support therefore requires the shore-complement pairing
\[
                              ED\mid IJ.       \tag{3}
\]
Now glue the *unchanged* \(N\) to \(M_1\). Its exterior \(I\)--\(D\) route joins the shore \(I\)--\(J\) and \(E\)--\(D\) paths to the terminal arms \(a\)--\(J\) and \(e\)--\(E\). The unique exception \(I\) lies on this open \(a\)--\(e\) path. The external \(b\)--\(d\) path has no exception. All closed components are even, so its colour switch gives forbidden state \(cb\). This contradiction excludes the \(AH,g,t_ew\) fibre also for \(AI,IH\).

Finally, use [Note 298's right-row balance](298-the-right-central-ad-row-forces-s-tait-in-the-three-two-near-bipartite-core.md). In placement \(AI\), the \(ID\)-port occurrences \(Y_a,V_a\) must select \(t_ev\) and avoid \(g\); the edge-load equation therefore makes \(W_d\) select \(t_ew,g\). In placements \(IH,DH\), the full-family \(ID\)-fibre exclusion of [Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) has the same effect. In all three, \(W_d\) has ports \(AH\), contradicting the fibre theorem. Note 298 already excludes \(ID,AD,AH,AJ\), leaving exactly (1). \(\square\)

The proof uses two actual exterior masks and one shore matching reused under full perfect-matching closure. It does not rule out the two \(r=J\) placements in (1), the \(4+1\) near-bipartite profile, higher-rank cores, or Berge–Fulkerson. The incidence and parity arguments were checked by hand; no local enumeration or OMEN run was used.

[Note 300](300-two-forbidden-ej-completions-trap-the-marked-edge-in-an-internal-odd-cycle.md) adds a complete-fibre restriction in those two remaining placements: every \(EJ\)-port matching selecting \(g\) must leave the marked edge on a closed odd shore cycle.
