> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The crossed double-star \((ea)(ac)\) row has a second shore gate

Continue the marked double-star of [Note 364](364-adjacent-double-star-cross-row-has-one-crossed-shore-gate.md), with allowed pentagon
\[
                 S=e-a-d-c-b-e,
 \qquad T=\{ec,ed,ab,ac,bd\}.
\]
Appendix XII requires a real BF row \((ea)(ac)\). Name its state-\(ea\) triple \(P\), state-\(ac\) triple \(R\), singleton-\(e\) \(E\), singleton-\(c\) \(C\), and two singleton-\(a\) occurrences \(A_1,A_2\). At every step, switches act on complete actual perfect matchings. Since \(R=ac\in T\), the \(a\)-terminal path of \(P\triangle A_i\) must end at \(b\): ends \(c,d\) would replace \(ea\) by \(ec,ed\in T\). Likewise the \(e\)-terminal path of \(P\triangle E\) must end at \(d\): ends \(b,c\) would replace \(ea\) by \(ab,ac\in T\).

**Theorem.** Every such row has the unique exterior matching restrictions in the table below. In particular, its state-\(ea\) triple is rooted at \(r_1\), and its state-\(ac\) triple chooses \(t_ar_1,t_cr_2\). The complete shore restrictions obey (1)–(2). The conclusion holds at every shore order and cycle rank, but does not by itself exclude the crossed Case-XII placement.

First, \(P\) cannot be rooted at \(l_1\). Since the other mark at that leaf is \(c\) and \(ec\in T\), both \(A_i\) must use \(l_1u_3\); otherwise the direct \(a\)--\(c\) switch gives a forbidden \((ec)(ac)\) row. The two \(A_i\) saturate \(l_1u_3\), forcing \(R\) to use the same \(a\)-half \(t_al_1\). Its \(c\)-half must then be \(t_cr_2\). At \(l_1\), the remaining edge \(l_1t_c\) would have to carry \(E,C\), but \(C\) already uses terminal \(c\) and cannot use a \(c\)-half. This is impossible.

Thus \(P\) uses \(t_ar_1\). There are three ways for \(R\) to choose its \(a,c\) halves. If it uses \(t_ar_1,t_cl_1\), the edge loads at \(l_1,t_c,r_2,t_d,l_2,t_b,r_1\) place one \(A_i\) on \(r_1u_1\), the other on \(r_1t_b\), and \(E\) on \(r_1t_b\). The first \(A_i\) has only the exterior \(a\)--\(b\) route \(a-t_a-r_1-u_1-x-u_0-y-u_4-l_2-t_b-b\); its other branches end at forbidden \(c,d\). In \(P\triangle E\), the \(b\)-terminal path passes through \(r_1\). The required, distinct \(e\)--\(d\) switch therefore leaves \(t_ar_1,t_br_1,s_b\) unchanged. The second \(A_i\) then switches the new state-\(ad\) triple along \(a-t_a-r_1-t_b-b\), producing forbidden \((bd)(ac)\).

Suppose instead that \(R\) uses \(t_al_1,t_cr_2\). At \(r_1\), at most one \(A_i\) can use \(r_1u_1\), since \(R\) already uses that edge. If one does, the other uses \(r_1t_b\), and the same forced \(a\)--\(b\) route reaches \(l_2t_b\). The \(E\)-occurrence at \(r_1\) uses either \(t_ar_1\) together with \(P\), or \(t_br_1\). In the first case the \(e\)--\(d\) switch cannot touch their common \(a\)-half; in the second, its separate \(b\)-terminal component contains \(r_1\). Either way, the switch leaves a direct \(a-t_a-r_1-t_b-b\) path for the \(A_i\) on \(r_1t_b\), again producing \((bd)(ac)\).

If neither \(A_i\) uses \(r_1u_1\), both use \(r_1t_b\). When \(C\) uses \(r_1u_1\), \(E\) shares \(t_ar_1\) with \(P\), and the same two-switch contradiction applies. Otherwise \(C\) uses \(t_ar_1\) and \(E\) uses \(r_1u_1\). Then \(E\) also uses \(t_al_1\), forcing both \(A_i\) onto \(l_1t_c\). At \(t_c,r_2,t_d\) this puts \(E\) on \(r_2t_c\) and both \(A_i\) on \(r_2t_d\), hence \(E,C\) on \(l_2t_d\). But the two \(A_i\) on \(r_1t_b\) force \(E,C\) on \(l_2t_b\) as well. One matching cannot use both \(l_2t_b\) and \(l_2t_d\), so this last placement is impossible.

Consequently \(R\) uses \(t_ar_1,t_cr_2\). Loads at the four leaves force both \(A_i\) onto \(r_1u_1,l_1t_c,r_2t_d,l_2t_b\). Their required \(a\)--\(b\) path then forces \(xu_0,yu_4\) in both occurrences. The centre \(y\) is matched by both triples through \(yu_0\). At \(x\), \(R\) must choose \(xu_2\), leaving \(p_1\) as its proper shore port: choosing \(xu_1\) instead would give \(C\) a forbidden third proper shore port, since \(C\) already uses \(p_0,p_4\). The whole exterior row is therefore:

| occurrence | marked halves or terminal | tree edges beyond leaves | shore ports |
|---|---|---|---|
| \(P_{ea}\) | \(t_ar_1;\ s_b,s_c,s_d\) | \(xu_1,yu_0,r_2u_2,l_1u_3,l_2u_4\) | none |
| \(R_{ac}\) | \(t_ar_1,t_cr_2;\ s_b,s_d\) | \(xu_2,yu_0,l_1u_3,l_2u_4\) | \(e,p_1\) |
| \(E_e\) | \(t_al_1,t_br_1,t_cr_2,t_dl_2\) | \(xu_2,yu_3\) | \(e,p_0,p_1,p_4\) |
| \(C_c\) | \(s_c;\ t_al_1,t_br_1,t_dl_2\) | \(r_2u_2,xu_1,yu_3\) | \(p_0,p_4\) |
| each \(A_i\) | \(s_a;\ t_cl_1,t_dr_2,t_bl_2\) | \(r_1u_1,xu_0,yu_4\) | \(p_2,p_3\) |

Put \(Q=P|_Z\), \(L=E|_Z\). The exterior pieces of \(P\triangle E\) run from \(b,c,d\) to \(p_0,p_1,p_4\), respectively. The forced \(e\)--\(d\) route gives
\[
               Q\triangle L:\qquad ep_4\mid p_0p_1
               \quad\text{(plus closed components)}.       \tag{1}
\]
After that switch, the new state-\(ad\) triple \(P'\) has shore ports \(e,p_4\). The exterior pieces of \(P'\triangle A_i\) run from \(a,b,c\) to \(p_4,p_2,p_3\). Switching the \(a\)-path to \(e\) or \(b\) would give \(ed\) or \(bd\) beside \(R=ac\in T\). Therefore it must end at \(c\), yielding \(cd\in S\), and for each \(i\)
\[
               P'|_Z\triangle A_i|_Z:\qquad p_4p_3\mid ep_2
               \quad\text{(plus closed components)}.       \tag{2}
\]
The two \(A_i\) share their exterior restriction, but by [Note 343's overlap lemma](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md) they have distinct complete shore matchings; each must satisfy (2). Thus the \(ep_4\) path of \(Q\triangle L\) meets both \(p_2p_3\) paths of \(Q\triangle A_i|_Z\) on an actual \(Q\)-edge, by the same symmetric-difference argument as in Note 364. The other required \((ea)(ab)\) row demands \(ep_0\mid p_1p_3\) and then \(p_0p_4\mid ep_2\). These are two different complete-row shore gates; exact support has not been shown to identify their zero-port shore matchings or crossing edges. This proof is hand-derived and has not received independent review; no local mathematical recomputation was used.
