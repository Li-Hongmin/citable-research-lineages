> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No side-J five-block with a central D edge

Continue the real exact-Case-XII left and right rows in the
five-vertex six-cut Hall block (1) of
[Note 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md).
Take the \(D\)-edge base \(\ell=u\), the \(J\)-base
\(j=y\), the \(H\)-base \(f\), and the other proper
\(B\)-port \(Q\in\{A,I\}\) at \(b\). Note 321 forces
every zero-port \((g,t_{ew})\) matching to use \(ud_D\)
and its third edge to be selected at \(z\). Full block
matching closure gives both actual phases
\[
\begin{aligned}
X_1&:\quad ud_D,bo,fp,ay,cx,\quad z\text{-third},\\
X_2&:\quad ud_D,bo,cp,fy,ax,\quad z\text{-third}.
\end{aligned}                                                   \tag{1}
\]
Use [Note 301's complete-fibre rule](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
\(\sigma(L)=EI\mid AD\) for every actual
\(HJ,g,t_{ew}\) matching \(L\), and Note 321's
\(\sigma(N)=EA\mid ID\mid HJ\) for every actual
zero-port \((g,t_{ew})\) matching \(N\).

**Theorem.** No actual \(HJ,g,t_{ew}\) shore matching
exists in this placement. Thus the genuine left row rules
out \((\ell,j,H)=(u,y,f)\) for either value of \(Q\).
Reflecting \((a,b,o,y)\leftrightarrow(c,f,p,z)\)
also rules out \((u,z,b)\). In the \((\alpha,\eta)=(2,1)\)
five-vertex design, the only central-\(D\)-edge placement
not excluded by these results has \(j=x\).

**Proof.** A purported \(HJ\) matching selects \(H\)
at \(f\) and \(J\) at \(y\). If it avoids \(ud_D\),
it matches \(u,a,b,c\) bijectively to
\(o,p,x,z\). The complete list is
\[
\begin{array}{c|l}
L_0&uo,ax,bz,cp\\
L_1&up,bo,ax,cz\\
L_2&up,bz,ao,cx.
\end{array}                                                   \tag{2}
\]
Each row also selects \(Hf,Jy\). For \(L_0\), the
complete \(H\)--\(J\) component of \(L_0\triangle X_1\)
is
\[
                         H-f-p-c-x-a-y-J.                     \tag{3}
\]
Switching it in \(L_0\) yields an actual zero-port
\((g,t_{ew})\) matching selecting
\(\{uo,bz,fp,cx,ay\}\) on all of \(S\). It avoids
\(ud_D\), contrary to Note 321. For either \(L_1\)
or \(L_2\), the complete \(H\)--\(J\) component of
\(L_i\triangle X_2\) is \(H-f-y-J\). Switching it
again gives an actual zero-port matching avoiding
\(ud_D\). Hence no phase in (2) occurs.

If the purported \(HJ\) matching selects \(ud_D\),
the only local phase is
\[
        L_3:\quad Hf,Jy,ud_D,bo,ax,cp,\quad z\text{-third}.
                                                                    \tag{4}
\]
Its difference with \(X_1\) has the complete
\(H\)--\(J\) component (3). Switching that component
in \(L_3\) produces an actual zero-port matching \(N\)
with local phase \(X_1\) and with every shore edge outside
(3) unchanged, including \(ud_D,z\text{-third},g,t_{ew}\).

In the complement of \(L_3\), the \(Q\)-path reaches the
unselected third edge at \(x\) through
\(Q-b-z-c-x\). In the complement of \(N\), it reaches
that same edge through
\[
                      Q-b-z-c-p-u-o-a-x.                       \tag{5}
\]
The shore continuation after that edge is identical for
\(L_3\) and \(N\). If \(Q=A\), Note 301 requires it
to end at \(D\) for \(L_3\), while Note 321 requires
\(E\) for \(N\). If \(Q=I\), the required ends are
\(E,D\), respectively. This contradiction excludes
\(L_3\), completing the proof. \(\square\)

The \(\ell=u,j=x\) placement is subsequently excluded by
[Note 325](325-no-central-j-five-block-with-a-central-d-edge.md).
The remaining \(\ell=b,j=z,H=f,Q=I\)
placement of [Note 322](322-the-remaining-f-based-five-block-fixes-the-left-hj-phase.md),
the other six-cut allocation, larger Hall blocks, incidence
collisions, other shore profiles, or Berge–Fulkerson. The
argument is hand-derived and awaits independent second-source
checking. No local computation or OMEN was used.
