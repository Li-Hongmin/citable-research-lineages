> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two \(R^*\) private ports agree at the direct mark

Use the genuine \(I_m\) quotient of [Note 210](210-two-star-rectangles-restrict-the-rstar-im-connector.md).
Let the tree shore \(A^\circ\) be centred at \(u_1\), with
end groups \(\{u_2,x\}\mid\{z,p\}\), and let \(B^\circ\)
have the complete actual Figure-7 \(R^*\) relation. If the
outer five-pole has exact Case-XII support, then
\[
                         \boxed{c(yz)=c(qz).}                \tag{1}
\]
Here \(c(rs)\in\{P,Q\}\) is the Figure-7 block of the
missing-pair state \(rs\). The conclusion holds at every order
of the cyclic shore.

Suppose instead that \(c(yz)\ne c(qz)\). The two explicit
six-slot rows in [Note 219](219-two-shared-colour-transitions-are-impossible-in-opposite-tree-rstar-im.md)
use the same actual \(B^\circ\) type \((yz)(qz)\) and force
both outer BF types
\[
                         (yq)(xz),\qquad(yq)(pz).            \tag{2}
\]
Let \(S\) be the allowed Case-XII loop five-cycle. Its
complement \(T\) cannot contain both states of an actual BF
pair. If \(yq\in T\), (2) puts both \(xz,pz\) in \(S\).
Then \(z\)'s two neighbours in \(S\) are \(x,p\). The other
three edges of this five-cycle form an \(x\)--\(p\) path
through \(y,q\), so \(yq\in S\), a contradiction. Therefore
\[
                              yq\in S.                      \tag{3}
\]

Exactly one of \(c(yz),c(qz)\) differs from \(d=c(yq)\).
Suppose \(c(qz)\ne d\). The tree's actual star
\((xz)(xp)\) and the \(B\)-star \((qz)(qy)\), composed by
[Note 212, (3)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md),
force \([xq]\in S\). If \(c(qu_2)\ne d\), the tree star
\((pu_2)(px)\) and \(B\)-star \((qu_2)(qy)\) also force
\([pq]\in S\). If \(c(qu_2)=d\), then
\(c(qu_2)\ne c(qz)\), and the second genuine row of
[Note 218](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md)
forces \([zq]\in S\). Either way, \(q\) has three distinct
loop neighbours: \(y,x\), and \(p\) or \(z\). This is
impossible in a five-cycle.

If instead \(c(yz)\ne d\), the same star transport gives
\([xy]\in S\). If \(c(yu_2)\ne d\), it also gives
\([py]\in S\); otherwise \(c(yu_2)=d\ne c(yz)\), and
the first genuine row of Note 218 gives \([yz]\in S\).
Now \(y\) has the three distinct loop neighbours \(q,x\),
and \(p\) or \(z\), again impossible. This proves (1).

Combining (1) with the four-loop exclusions of Note 218 leaves
the following **necessary port orders** in the published Figure-7
labels. The unordered pair \(\{y,q\}\) is shown in the first
column; either order of its two labels is retained. The last
column lists the ordered \((z,u_2)\) choices, with \(u_1\)
receiving the unused label.
\[
\begin{array}{c|c}
\{y,q\}&(z,u_2)\\\hline
\{1,2\}&(4,3),(5,3)\\
\{1,3\}&(2,4),(2,5)\\
\{2,4\}&(3,1),(3,5)\\
\{2,5\}&(1,3),(4,3)\\
\{3,4\}&(1,2),(5,2)\\
\{3,5\}&(2,1),(2,4)
\end{array}.                                                  \tag{4}
\]
To check completeness, the \(P\)-neighbour sets of local labels
\(1,\ldots,5\) are \(\{3,4\},\{4\},\{1,5\},
\{1,2,5\},\{3,4\}\); the \(Q\)-neighbour sets are their
complements among the other four labels. Condition (1) selects
the common-colour choices for \(z\). Note 218 removes the
common opposite-colour choices for \(u_2\) and the two pure-star
rectangles. Table (4) contains twenty-four labelled orders, each
with exactly one of \(y,q\) changing colour between \(z,u_2\).
It is a boundary of these necessary tests, not a realization
table for exact Case XII.

The proof uses the full actual \(R^*\) pair relation, two
distinct tree BF rows for (2), and exact six-slot gluing. It
does not classify the placements satisfying (1), the mirror
tree centre, other shore combinations, or the full exact
Case-XII closure. The analytic chain awaits an independent check.
