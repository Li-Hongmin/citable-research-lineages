> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cross-triple switch excludes the \((4,2,2)\) exact-Case-XII profile

**Theorem.** No genuine marked \((4,2,2)\) five-pole in the setting of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md) has the complete exact Case-XII BF support listed by [Máčajová--Mazzuoccolo--Tabarelli, Figure 7 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). This holds at every order and uses actual six-perfect-matching rows, including their complete edge loads. It excludes this Tutte-barrier profile, not the other deficiency-two profiles or the Berge--Fulkerson conjecture.

Let \(\mathcal R(D)\) be the missing-pair states of all three-perfect-matching decompositions of a fixed half-load \(D\), whose terminal load is one at each of the five terminals. We use the following consequence of [Notes 055](055-half-load-column-saturation-and-case-xii-compression.md) and [200](200-two-kempe-switches-balance-the-422-exterior-connector.md):
\[
\varnothing\ne\mathcal R(D)\subseteq S
\quad\Longrightarrow\quad D(h)=1.                         \tag{1}
\]
Indeed, Note 055 saturates \(D\) to every state of \(S\). Its states forcing each fork edge make \(D(uw_1),D(uw_2)>0\), hence \(D(h)\le1\) by [Note 197](197-a-saturated-s-carrier-cannot-double-the-h-edge-in-the-422-profile.md). If \(D(h)=0\), Note 200's form-III comparison of the same shore pairing before and after the exterior \(de\to ep\) switch gives incompatible partners for the internal \(e\)-port: \(q,p\) in profile \((0,2,1)\), and \(d,c\) in profile \((0,1,2)\). Its proof uses an actual complementary \(T\)-half only to establish \(\mathcal R(D)\subseteq S\). Thus (1) applies to an \(S\)-only half-load of **any** BF row, including an \(S\)--\(S\) row.

**Proof.** Suppose an exact-Case-XII pole of this profile exists. By Note 200, after relabelling the fork marks,
\[
S=p-c-q-d-e-p,\qquad T=\{pq,pd,qe,ce,cd\},             \tag{2}
\]
and each half of every \(S\)--\(T\) row loads \(h,uw_1,uw_2\) once. Take the required genuine \((de)(pq)\) row. Label its six full perfect-matching occurrences by their terminal boundaries:
\[
\begin{array}{c|ccc|ccc}
 &X&Y&Z&U&V&W\\\hline
\text{boundary}&\{p,q,c\}&\{d\}&\{e\}&\{c,d,e\}&\{p\}&\{q\}\\
\text{edge at }u&uw_1&uw_2&h&uw_2&h&uw_1.
\end{array}                                                   \tag{3}
\]
The \(de\)-triple \(X\) uses \(dw_2\), while the \(pq\)-triple \(U\) uses \(pw_1\): the first is forced by the quotient, and the second by [Note 198](198-the-de-ab-disjoint-row-fixes-its-fork-owner-and-splits-the-h-load.md), because \(q\) is the neighbour of \(e\) in \(T\). Note 198 also puts \(h\) in the singleton-\(p\) matching \(V\). The remaining entries of the last row of (3) follow from the unit load at \(u\).

Consequently \(X\triangle U\) has the **whole exterior alternating component**
\[
s_d-t_d-w_2-u-w_1-t_p-s_p,                              \tag{4}
\]
where the first and last edges are the terminal semiedges. Switch \(X,U\) along (4), obtaining full perfect matchings \(X',U'\). Their terminal boundaries become
\[
\partial X'=\{q,c,d\}\quad(\text{missing }ep),\qquad
\partial U'=\{p,c,e\}\quad(\text{missing }qd).             \tag{5}
\]
The six matching occurrences still cover every proper edge and semiedge twice. Regroup them by the new missing pairs:
\[
D_{ep}=X'+Z+V,\qquad D_{qd}=U'+Y+W,
\qquad D_{ep}+D_{qd}=2\mathbf1.                            \tag{6}
\]
Both displayed half-loads have terminal load one everywhere and a decomposition in a state of \(S\), since \(ep,qd\in S\). But (3)--(4) give, in the order \((h,uw_1,uw_2)\),
\[
D_{ep}|_u=(2,0,1),\qquad D_{qd}|_u=(0,2,1).             \tag{7}
\]
By (1), neither \(\mathcal R(D_{ep})\) nor \(\mathcal R(D_{qd})\) can be contained in \(S\). Each therefore contains a state of \(T\). Choose a decomposition at such a state in **each** complementary half-load of (6). Their union is a genuine BF row of type \(T\)--\(T\), including a forbidden \(T\)-loop if the two states coincide. This contradicts exact Case XII. \(\square\)

The shore matchings and their order never enter (4)--(7). In particular, the conditional odd-cycle and three-deletion necessities of [Notes 201](201-the-surviving-422-shore-must-have-an-unmarked-odd-cycle.md) and [202](202-the-cross-row-e-singleton-is-a-three-deletion-matching.md) are superseded for a genuine exact-Case-XII \((4,2,2)\) pole. Their matching interfaces remain valid under their stated antecedent, but that antecedent cannot occur. The remaining complete-PM closure problem must be sought in another marked-core profile.

**Barrier corollary.** In the connected, deficient unmarked-core branch of a minimum host, no maximum Tutte barrier consists of one vertex. [Note 166](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) reduces such a barrier to the \((4,2,2)\) or \((4,4,2)\) quotient after the small-order exclusion. The theorem above eliminates the first, and [Note 193](193-two-rstar-shores-force-a-forbidden-loop-in-the-one-vertex-connector.md) eliminates the second. A smallest maximum barrier in this branch therefore has at least two vertices.

The new deduction (3)--(7) has been checked directly against the stated half-load lemmas. An independent check of the upstream Notes 198 and 200 has not yet been obtained.
