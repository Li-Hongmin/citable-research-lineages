> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both Hamilton \(Cc,ac\) row masks recomplete to the forbidden \([eY]\) loop

Use the Hamilton tree and notation of [Note 438](438-the-hamilton-cc-ac-forbidden-pair-has-only-two-long-row-masks.md):
\[
a-u_1-A-u_2-C-u_3-B-u_4-b-u_5-c,\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).
\]
The five proper ports \(p_i\) attach at \(u_i\), and \(e\) is the sixth shore port. Write a six-matching row as \(P,R,K,J,M,N\), where \(P=eY\), \(R=eX\), \(K=X\), \(J=Y\), and \(M=N=e\) specify their terminal boundaries. The equality \(M=N=e\) denotes boundary types, not equality of matchings.

> **Exterior recompletion theorem.** Let six *complete* perfect matchings of any cubic five-pole with this exterior form either of the two port patterns in Note 438, equation (10). Keeping each matching's entire shore restriction fixed, one can replace only the six exterior restrictions and obtain a BF row of forbidden loop type \([eY]\). This holds for either pentagon orientation and does not require the two zero-port shore matchings to coincide, a clean shore matching, or any bound on shore order.

The original row fixes the following two-element label set at every shore port:
\[
\begin{array}{c|cccccc}
&e&p_1&p_2&p_3&p_4&p_5\\ \hline
S_1&MN&KJ&MN&MN&MN&KJ\\
S_2&MN&KN&MN&JM&MN&KJ.
\end{array}                                                    \tag{1}
\]
The first column records that \(M,N\) select the shore terminal \(e\); the other entries record proper cut edges. In both cases \(P,R\) use no shore port. For each label retain exactly its original shore perfect matching, including all internal edges.

Here are replacement **exterior** matchings for \(S_1\). An entry \(X:A\) denotes the half-edge at the marked subdivision \(t_X\), and terminals refer only to \(X,Y,Z,W\); \(e\) lies in the retained shore.
\[
\begin{array}{c|c|l|l|l}
&\text{selected marked terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P,R&X,Z,W&Y:c&au_1,Au_2,Cu_3,Bu_4,bu_5&\varnothing\\
K,J&Y&X:A,Z:c,W:a&Cu_2,Bu_3,bu_4&p_1,p_5\\
M,N&\varnothing&X:B,Y:C,Z:a,W:b&Au_1,cu_5&p_2,p_3,p_4.
\end{array}                                                    \tag{2}
\]
Thus \(P,R\) are both rooted \(eY:c\) triples, \(K,J\) both have singleton boundary \(Y\), and \(M,N\) both have singleton boundary \(e\). The three displayed exterior masks partition all exterior edges once; repeating each mask loads each edge twice. Their port sets are exactly (1), so each glues to its retained complete shore matching, even when those shore matchings differ.

For \(S_2\), use the following exterior masks with the **same retained shore matchings**:
\[
\begin{array}{c|c|l|l|l}
&\text{selected marked terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P,R&X,Z,W&Y:c&au_1,Au_2,Cu_3,Bu_4,bu_5&\varnothing\\
K&Y&X:A,Z:c,W:a&Cu_2,Bu_3,bu_4&p_1,p_5\\
J&Y&X:B,Z:c,W:a&Au_1,Cu_2,bu_4&p_3,p_5\\
M&\varnothing&X:B,Y:C,Z:a,W:b&Au_1,cu_5&p_2,p_3,p_4\\
N&\varnothing&X:A,Y:C,Z:a,W:b&Bu_3,cu_5&p_1,p_2,p_4.
\end{array}                                                    \tag{3}
\]
For direct edge-load verification, the pairs on the three edges at each tree subdivision are, in order \((\text{left tree half},\text{right tree half},p_i)\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
S_1&(PR,MN,KJ)&(PR,KJ,MN)&(PR,KJ,MN)&(PR,KJ,MN)&(PR,MN,KJ)\\
S_2&(PR,JM,KN)&(PR,KJ,MN)&(PR,KN,JM)&(PR,KJ,MN)&(PR,MN,KJ).
\end{array}                                                    \tag{4}
\]
The three pairs at \(t_X,t_Y,t_Z,t_W\), in order \((\text{terminal},\text{first half},\text{second half})\), are
\[
\begin{array}{c|cccc}
&t_X:(X:A,X:B)&t_Y:(Y:C,Y:c)&t_Z:(Z:a,Z:c)&t_W:(W:a,W:b)\\ \hline
S_1&(PR,KJ,MN)&(KJ,MN,PR)&(PR,MN,KJ)&(PR,KJ,MN)\\
S_2&(PR,KN,JM)&(KJ,MN,PR)&(PR,MN,KJ)&(PR,KJ,MN).
\end{array}                                                    \tag{5}
\]
At each of the six original prism vertices, the three incident entries of (2) or (3) likewise partition \(\{P,R,K,J,M,N\}\): for \(S_2\), for example, the pairs at \(A\) are \(JM,PR,KN\), and those at \(B\) are \(KN,PR,JM\). Equations (4)–(5) and this vertex check prove that every displayed exterior mask is a perfect matching and every exterior edge has load two. The unchanged shore edges retain load two from the original genuine row. Therefore (2) and (3) each give six **complete** perfect matchings of forbidden BF loop type \([eY]\).

The [published Case-XII support](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Appendix XII, excludes \([eY]\) under the forbidden pair \(\{eY,eZ\}\). Consequently **no** cubic five-pole with the Hamilton two-spoke exterior has complete exact-Case-XII BF support for that forbidden pair, in either orientation. The sole use of Note 438 is its reduction of every required \((eY)(eX)\) row to (10); the present recompletion is independent of shore topology and uses no local mathematical recomputation. [Notes 440](440-the-surviving-hamilton-x-w-rows-all-recomplete-to-forbidden-support.md) and [441](441-the-last-hamilton-prism-forbidden-pair-has-no-exact-case-xii-support.md) treat the remaining Hamilton pairs. Berge–Fulkerson remains open. \(\square\)
