> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The opposite prism mixed row cannot escape through \(C\)

Continue the genuine \((e\,Cc)(e\,bc)\) row of [Note 400](400-the-opposite-mixed-prism-row-has-two-direct-escape-roots.md): the forbidden \(e\,Cc\)-triple \(P\) is rooted at \(c\), the allowed \(e\,bc\)-triple \(R\) at \(b\), the singleton-\(Cc\) occurrence is \(J\), and the singleton-\(bc\) occurrence is \(K\). Assume complete exact Case-XII support with forbidden \(e\)-labels \(Cc,ab\). The shore is arbitrary. Note 400 forces the \(bc\)--\(AC\) exterior escape of \(R\triangle K\), with a \(C\)-route or an \(A\)-route.

> **All-order \(C\)-route exclusion.** The \(C\)-route
> \[
> bc-t_{bc}-b-u_4-B-u_2-C-t_{AC}-AC                    \tag{1}
> \]
> is impossible for either Case-XII pentagon orientation. Consequently, this specified root pair, if present, must take Note 400's \(A\)-route. No clean shore signature, short path or bound on shore order is used.

**Proof.** Suppose (1) occurs. Switch \(R,K\) on it. The resulting allowed \(e\,AC\)-triple \(R'\) is rooted at \(C\), has the same zero-port shore matching as \(R\), and has exterior mask
\[
(u_1,u_2,u_3,u_4,u_5)=(A,B,a,b,c),\qquad
(AC,Cc,bc,ab)=(C,s,s,s).                                \tag{2}
\]
The new singleton-\(AC\) matching \(K'\) uses \(Cu_2,Bu_4,bc:b,AC:s\). Because a singleton of boundary \(AC\ne e\) uses exactly two proper shore ports by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), its already selected edges at \(u_2,u_4\) leave only one further tree half-edge. It must cover \(A\) through \(Au_1\) or \(Au_3\); hence it covers \(a,c\) through \(ab:a,Cc:c\), takes port \(p_5\), and uses the other of \(p_1,p_3\). In particular its exterior marks are
\[
(AC,Cc,bc,ab)=(s,c,b,a).                               \tag{3}
\]

At \(Cc\), \(P,K'\) use the \(c\)-half and \(R',J\) use the terminal, so both singleton-\(e\) occurrences use \(Cc:C\). At \(C\), \(P,K'\) saturate \(Cu_2\), so \(J\) must use \(AC:C\), and both singleton-\(e\) occurrences use \(AC:A\). The vertex \(c\) is covered by \(P,K'\) at \(Cc:c\), by \(R'\) at \(cu_5\), and by the remaining three occurrences at \(cu_5\) once and \(bc:c\) twice.

If \(J\) uses \(cu_5\), then it already uses tree half-edges to cover \(c,A,B\). Its singleton-\(Cc\) port quota leaves no fourth tree half-edge, so it covers \(a\) by \(ab:a\). The wholly exterior path
\[
Cc-t_{Cc}-c-u_5-a-t_{ab}-ab\quad\text{in }P\triangle J   \tag{4}
\]
turns \(P\) into an \(e\,ab\)-triple rooted at \(a\). The independent switch (1) turns \(R\) into the \(e\,AC\)-triple rooted at \(C\) in (2). These disjoint matching-pair switches commute and produce exactly the forbidden mixed root pair excluded by [Note 399](399-the-direct-mixed-prism-root-pair-is-impossible-at-all-shore-orders.md). Hence \(J\) uses \(bc:c\). It then cannot use \(bc:b\) at the same marked subdivision; the \(b\)-half of \(u_4\) is saturated by \(P,K'\), so \(J\) uses \(ab:b\).

At the \(bc\) and \(ab\) marks, the two singleton-\(e\) occurrences now have complementary choices. Name by \(X\) the one using \(bc:b\); it must use \(ab:a\), whereas the other, \(Y\), uses \(bc:c,ab:b\). Together with the forced \(AC:A,Cc:C\), the exterior masks are
\[
\begin{array}{c|cccc|c}
&AC&Cc&bc&ab&\text{other forced tree choice}\\\hline
X&A&C&b&a&cu_5,\ p_3\\
Y&A&C&c&b&au_3\text{ or }au_5.
\end{array}                                                   \tag{5}
\]
Each uses one of \(Bu_1,Bu_2,Bu_4\). The entries in (5) follow from matching the three remaining prism vertices and the quota of three proper ports for a singleton-\(e\) occurrence.

There are two allowed pentagons. First take \(S_{ab}=e-AC-ab-Cc-bc-e\). Since \(P\) remains in \(T\), switching the \(e\)-starting path of \(R'\triangle X\) may only change \(e\,AC\) to an \(S\)-state. Its only possible terminal endpoint is \(ab\). Against the exterior mask (2) and (5), the arm to \(ab\) is always
\[
p_3-u_3-a-t_{ab}-ab;                                  \tag{6}
\]
the other two proper-port arms end at \(Cc,bc\). Thus the shore \(e\)-path of \(R'\triangle X\) must end at \(p_3\). But \(R'\) and the original \(R\) have **identical shore matchings**, while \(X\) is unchanged. In \(R\triangle X\), the same shore path still reaches \(p_3\), and (6) is unchanged because \(R\) also uses \(au_3\) and terminal \(ab\). Switching this complete \(e\)--\(ab\) path changes \(R\)'s state from \(e\,bc\) to \(ab\,bc\in T\), alongside the unchanged \(P:e\,Cc\in T\). Contradiction.

Now take \(S_{Cc}=e-AC-Cc-ab-bc-e\). The \(e\)-path of \(R'\triangle Y\) must reach \(Cc\), the unique other \(S\)-neighbour of \(AC\). The exterior table of [Note 395](395-the-mixed-prism-e-singletons-have-an-exact-three-port-selector.md) applies to \(Y\)'s mark mask in (5): the shore endpoint is \(p_2\) if \(Y\) uses \(Bu_1\), and \(p_1\) if it uses \(Bu_2\) or \(Bu_4\). Against the original \(R:e\,bc\) rooted at \(b\), [Note 396's second exterior table](396-the-mixed-prism-root-pair-has-one-pentagon-and-two-exterior-masks.md) sends these same ports, respectively, to \(Cc\) or \(AC\). Both \(bc\,Cc\) and \(bc\,AC\) lie in \(T\) for \(S_{Cc}\). Switching \(R,Y\) along its unchanged shore \(e\)-path again makes a double-\(T\) row with \(P\). Contradiction. \(\square\)

The conclusion is conditional on the two stated triple roots. [Note 402](402-the-opposite-direct-mixed-prism-root-pair-is-impossible.md) subsequently excludes Note 400's \(A\)-route too; the other root pairs and the complete Case-XII problem remain open. The argument uses only complete matching switches and cubic edge loads; it is hand-derived and awaits independent review.
