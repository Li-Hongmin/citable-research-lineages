> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The pendant loop cannot use the doubled singleton phase

Retain the genuine \(|U|=3,r=2\) cycle--leaf quotient and \(e\)-neighbour pair \(\{a,c\}\) of [Notes 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md) and [240](240-a-six-cycle-cross-switch-forces-four-pure-carriers-in-the-pendant-loop.md). The reflection \(c\leftrightarrow d\), \(x\leftrightarrow z\), \(u_2\leftrightarrow u_3\) gives the result for \(\{a,d\}\). The odd shore \(C\) may have arbitrary order and cycle rank.

**Theorem.** Under complete exact Case-XII support, in every actual \([ea]\) BF loop row, each half-load whose decomposition-state set lies in the allowed pentagon \(S\) has the type-\(F\) singleton-\(a\) exterior mask of Note 239. The type-\(G\) mask, which doubles \(u_3z\), is impossible for such a half. In particular every required \([ea]\) row contains a pure-\(S\) half of type \(F\). This does not exclude the \([ea]\) row itself: its other half may be mixed, and even two type-\(F\) halves need not share their shore matching masks.

**Proof.** Suppose a genuine \([ea]\) row has a pure-\(S\) half \(D=X_\alpha+Y_G+Z\). By [Note 240, (1)--(3)](240-a-six-cycle-cross-switch-forces-four-pure-carriers-in-the-pendant-loop.md), the singleton-\(e\) matching \(Z\) has one of the two complete exterior restrictions \(R_d,R_h\). In both cases its external terminal routes against the zero-port triple \(X_\alpha\) are
\[
\begin{array}{c|ccc}
 &b&c&d\\\hline
R_d&a:C&c:C&d:C\\
R_h&a:C&c:C&h_3.
\end{array}                                                       \tag{1}
\]
Here each entry is the *shore port edge* reached by that terminal path; equal shore endpoints do not identify different ports.

The wholly exterior \(a\)--\(c\) component of \(X_\alpha\triangle Y_G\) can be switched. It replaces \(X_\alpha\) by a state-\(ec\) triple \(X_c\) while preserving its **complete shore mask** and leaving \(Z\) unchanged. Consequently the alternating pairing inside \(C\cup\{t_e\}\) between the \(e\)-port and one of the other three ports of \(Z\) is exactly the same before and after this switch.

There are only two allowed cyclic orders. First let \(S=e-a-b-d-c-e\). In the state-\(ea\) decomposition, purity forces the \(e\)-terminal of \(X_\alpha\triangle Z\) to pair with terminal \(b\), since \(ab\) is the only allowed edge incident with \(a\) other than \(ea\). Table (1) therefore pairs the shore \(e\)-port with \(a:C\), regardless of whether \(Z\) has type \(R_d\) or \(R_h\). In \(X_c\triangle Z\), terminal \(a\) reaches \(a:C\) directly. Switching its \(e\)--\(a\) path produces state \(ac\in T\), contrary to \(D\)'s being pure \(S\).

Now let \(S=e-a-d-b-c-e\). Purity at \(ea\) forces the \(e\)-terminal to pair with \(d\). With \(Z=R_d\), table (1) pairs \(e\) with \(d:C\), and terminal \(d\) still reaches \(d:C\) directly in \(X_c\triangle Z\). With \(Z=R_h\), it pairs \(e\) with \(h_3\); after the \(a\)--\(c\) switch, terminal \(d\) still follows the exterior route
\[
d-t_d-z-u_3-h_3,
\]
because \(X_c\) retains \(u_3z\). In either case switching the \(e\)--\(d\) path of \(X_c\triangle Z\) produces state \(cd\in T\), again impossible for a pure-\(S\) half.

Thus \(Y_G\) cannot occur. Exact negative support guarantees that at least one half of every \([ea]\) loop is pure \(S\); [Note 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md) then leaves only type \(F\) for it. \(\square\)

The result uses actual full perfect-matching closure twice: the six-cycle exchange in Note 240 forces the two \(R\)-masks from the same genuine row, and the two subsequent terminal-path switches are decompositions of the *same complete half-load*. A bare six-port pairing table or selected matching family does not imply the theorem. The remaining type-\(F\) and other neighbour-pair branches still carry the exact Case-XII and Berge--Fulkerson obstacles. The analytic proof has not received independent verification of its upstream chain.
