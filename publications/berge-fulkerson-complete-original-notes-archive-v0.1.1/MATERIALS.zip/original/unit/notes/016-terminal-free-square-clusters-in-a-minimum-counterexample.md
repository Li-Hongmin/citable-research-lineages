> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Terminal-free square clusters in a minimum counterexample

Fix an edge \(uv\).  The 4-cycles through it correspond to cross-edges
between the two other neighbours of \(u\) and the two other neighbours of
\(v\).  Two disjoint cross-edges form a six-vertex domino; two adjacent ones
form a \(K_{2,3}\) fan; three force a proper 2-edge-cut; four form a saturated
\(K_{3,3}\) component.  Thus without a proper cut of size at most two, only
the domino and fan remain.

The terminal-free \(K_{2,3}\) fan contracts to one cubic vertex.  Its three
port colours are distinct, and every contracted Tait colouring has exactly
two extensions.  Its six perfect-matching patterns lift all three possible
capacity profiles \((1,2,2)\) and permutations.  Coincident external
endpoints force a small cut or saturated \(K_{3,3}\).  Hence a no-small-cut
minimum counterexample contains no such fan.

For the two-cell domino with ports in outer order, the end pairing
\(14|23\) and cross pairing \(13|24\) lift all nine capacity profiles.  The
rail pairing \(12|34\) supports only all-equal Tait boundary colours and only
two profiles.  A maximal domino has structurally admissible end reduction
unless a triangle or small cut already exists.  If that reduction is globally
Tait-incompatible, every colouring uses the cross signature; structural
failure of the cross reduction, after excluding small cuts, encloses the
domino by a cross 5- or 6-cycle.

Therefore the sole sharp residual terminal-free two-square configuration in
a no-small-cut minimum counterexample is

\[
\boxed{\text{end-Tait-incompatible and enclosed by a cross 5- or 6-cycle}.}
\]

For every straight ladder \(L_k=P_{k+1}\square K_2\), \(k\ge1\), the end
pairing \(14|23\) lifts all nine capacity profiles.  If \(k\) is odd, the
rail pairing \(12|34\) also lifts all nine while the cross pairing lifts only
two; if \(k\) is even, cross and rail exchange these roles.  The same parity
rule holds for nonconstant Tait signatures.

This arbitrary-length statement is certified by a finite transfer system.
At a ladder cut, record the subsets of the five selected matchings using the
two rail edges; there are \(16^2=256\) states and 540 admissible transitions.
For all nine profiles and three pairings, reachable-state sets enter a cycle
of length one or two after at most two columns.  Since \(L_k\) has at least
two column transitions, the finite-state calculation proves the formula for
all \(k\), rather than extrapolating bounded data.

Accordingly, in a maximal no-small-cut ladder, if the end reduction is
globally Tait-incompatible then the parity-good second reduction must be
structurally blocked.  After excluding small cuts, an odd-length ladder is
enclosed through its rail ports by a cycle of length \(k+2\) or \(k+3\), and
an even-length ladder through its cross ports by a cycle of length \(k+3\) or
\(k+4\).

The exact local programs are
`scratch/worker-verify/local_domino_cluster_states.py`,
`scratch/worker-verify/local_k23_cluster_states.py`, and
`scratch/worker-verify/local_ladder_transfer_certificate.py`; the independent
bounded cross-check is `scratch/worker-verify/local_ladder_family_states.py`.
