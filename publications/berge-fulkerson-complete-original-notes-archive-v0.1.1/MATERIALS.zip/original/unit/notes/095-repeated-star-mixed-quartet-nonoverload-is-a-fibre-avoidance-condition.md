> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Repeated-star mixed-quartet nonoverload is a fibre-avoidance condition

The first literal-identity gate preceding the carrier projections of
[Note 093](093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)
has a sharp local form.  For two repeated-star pivot rows sharing three
literal singleton identities, the mixed target quartet is nonoverloaded if
and only if two fixed-row fibres avoid one explicit bad intersection.  Under
absence of the all-terminal BF type, the condition is equivalently that the
class-three matching hits the old double-load set only in its unique safe
region.

Consider two actual BF rows in one cubic five-pole,

\[
\begin{aligned}
R_3&=(q_{24},r_{15},A,B,C,D),\\
R_1&=(q_{13},r_{45},A,X,C,D),
\end{aligned}                                                    \tag{1}
\]

where

\[
\partial(A,B,C,D,X)=(1,2,4,5,3).
\]

Put

\[
W=A+B+C+D,
\qquad
D_2=\{e:W(e)=2\},                                  \tag{2}
\]

and let

\[
T=A+B+C+X                                             \tag{3}
\]

be the mixed quartet whose complement would have to split into the triple
states \(14\) and \(23\).  The two rows imply

\[
W\le 2\mathbf 1,
\qquad
A+X+C+D\le 2\mathbf 1.                              \tag{4}
\]

Then

\[
\boxed{
T\le 2\mathbf 1
\iff
X\cap B\cap(A\mathbin\triangle C)=\varnothing.
}                                                     \tag{5}
\]

If the pole has no all-terminal BF cover, this is equivalently

\[
\boxed{
\varnothing\ne X\cap D_2\subseteq B\cap D.
}                                                     \tag{6}
\]

## Classification of the overload edges

Fix an edge object and abbreviate the incidences of \(A,B,C,D,X\) by
\(a,b,c,d,x\).  If \(T(e)\ge3\), then (4) gives

\[
a+b+c+d\le2,
\qquad
a+x+c+d\le2.                                       \tag{7}
\]

The case \(d=1\) leaves too few of \(a,b,c,x\) to make
\(a+b+c+x\ge3\).  Hence \(d=0\).  Writing \(s=a+c\), the remaining
conditions are

\[
s+b\le2,
\qquad
s+x\le2,
\qquad
s+b+x\ge3.                                        \tag{8}
\]

Their unique solution is

\[
s=1,
\qquad
b=x=1.                                             \tag{9}
\]

Thus every overload has load exactly three and one of the two signatures

\[
ABX,
\qquad
BCX.                                               \tag{10}
\]

Conversely, either signature overloads \(T\), proving (5).

There is an equivalent description through \(D_2\).  If
\(e\in X\cap D_2\), then the second inequality in (4) gives
\(a+c+d\le1\), while \(a+b+c+d=2\).  Therefore \(b=1\), and exactly
one of \(a,c,d\) equals one.  The possibilities are

\[
ABX,
\qquad
BCX,
\qquad
BDX.                                               \tag{11}
\]

The first two are precisely the overload signatures; the third is safe.
Hence

\[
T\le2\mathbf1
\iff
X\cap D_2\subseteq B\cap D.                      \tag{12}
\]

## What absence of the all-terminal type adds

Let \(P\) be any singleton-class-three perfect matching.  If
\(P\cap D_2=\varnothing\), then

\[
W+P\le2\mathbf1.                                  \tag{13}
\]

At every internal cubic vertex the five matching occurrences in \(W+P\)
have total incident load five, so the three incident edge loads in (13)
are \((2,2,1)\).  The five singleton semiedges occur once each.  It follows
that

\[
Z=2\mathbf1-W-P                                    \tag{14}
\]

is an all-terminal perfect matching and
\(A,B,C,D,P,Z\) is an all-terminal BF cover.  Its absence therefore forces

\[
P\cap D_2\ne\varnothing
\qquad
\text{for every }P\in\mathcal P_3.                \tag{15}
\]

Applying (15) to \(X\) turns (12) into (6).  This is the full direct
consequence of no all-terminal cover at the nonoverload gate: it forces a
hit of \(D_2\), but it does not decide whether the hit has bad signature
\(ABX\) or \(BCX\), or safe signature \(BDX\).

Absence of the \(T\)-loop \([23]\) only gives \(B\cap X\ne\varnothing\).
All three signatures in (11) satisfy that condition.  If a bad signature
occurs, the proposed mixed residual is already negative on that edge, so
absence of a \(T\)--\(T\) factorization has no residual on which to act.

There is nevertheless a distinct way in which no \(T\)--\(T\) support can
act.  If actual matchings \(q_{12}\) and \(B'\in\mathcal P_2\) satisfy

\[
q_{13}+X=q_{12}+B',                               \tag{16}
\]

then substituting this equality in \(R_1\) gives

\[
q_{12}+r_{45}+A+B'+C+D=2\mathbf1,
\]

an actual \((12)(45)\) BF cover.  Exact Case-XII negative support therefore
forbids (16).  This paired-sum obstruction is not implied by the existence
of an \(ABX\) or \(BCX\) overload edge; a positive argument would still
have to derive an equality such as (16) from full closure and the bad
fixed-fibre intersection.

## Exact fixed-fibre criterion

For fixed literal identities \(A,C,D\), define

\[
\begin{aligned}
\mathcal B_{ACD}
 &=\{B\in\mathcal P_2:
       (q_{24},r_{15},A,B,C,D)
       \text{ is a BF row for some }q_{24},r_{15}\},\\
\mathcal X_{ACD}
 &=\{X\in\mathcal P_3:
       (q_{13},r_{45},A,X,C,D)
       \text{ is a BF row for some }q_{13},r_{45}\}.
                                                               \tag{17}
\end{aligned}
\]

All choices joining these two pivot rows over the common literal triple are
the pairs in \(\mathcal B_{ACD}\times\mathcal X_{ACD}\).  By (5), such a
choice is nonoverloaded exactly when

\[
\boxed{
\exists A,C,D\ \exists B\in\mathcal B_{ACD}\
\exists X\in\mathcal X_{ACD}:
X\cap B\cap(A\mathbin\triangle C)=\varnothing.
}                                                     \tag{18}
\]

Under absence of the all-terminal type, the same condition is

\[
\exists A,C,D,B,X:
\quad
\varnothing\ne X\cap D_2(A,B,C,D)\subseteq B\cap D. \tag{19}
\]

Thus the first nonoverload step is exactly a fixed-fibre avoidance problem,
not a general perfect-matching avoidance problem.

## Common-carrier rectangle form

The two fixed fibres in (17) are projections of the same integral cubic
copy-multigraph load

\[
K=2\mathbf1-A-C-D.                                \tag{20}
\]

Indeed, their decompositions are

\[
K=q_{24}+r_{15}+B
  =q_{13}+r_{45}+X.                               \tag{21}
\]

Every edge of load one in \(K\) is used by exactly one of \(A,C,D\).
Write

\[
E_1(K)=E_A\mathbin{\dot\cup}E_C\mathbin{\dot\cup}E_D             \tag{22}
\]

for this owner partition, and put

\[
I(B,X)=B\cap X\cap E_1(K).                        \tag{23}
\]

The bad signatures in (10) are precisely agreements in \(E_A\cup E_C\),
whereas agreement in \(E_D\) has the safe signature \(BDX\).  Hence (5)
becomes

\[
A+B+C+X\le2\mathbf1
\iff
I(B,X)\cap(E_A\cup E_C)=\varnothing.              \tag{24}
\]

For a load-one edge \(e\), define

\[
\mathcal B_e=\{B\in\mathcal B_{ACD}:e\in B\},
\qquad
\mathcal X_e=\{X\in\mathcal X_{ACD}:e\in X\}.    \tag{25}
\]

Equation (15), applied to every
\((B,X)\in\mathcal B_{ACD}\times\mathcal X_{ACD}\), is exactly the
rectangle cover

\[
\mathcal B_{ACD}\times\mathcal X_{ACD}
=\bigcup_{e\in E_1(K)}\mathcal B_e\times\mathcal X_e.           \tag{26}
\]

The desired nonoverloaded pair exists exactly when the smaller bad-phase
family fails to cover:

\[
\boxed{
\mathcal B_{ACD}\times\mathcal X_{ACD}
\ne
\bigcup_{e\in E_A\cup E_C}\mathcal B_e\times\mathcal X_e.
}                                                               \tag{27}
\]

Thus no all-terminal cover forces the full cover (26), while the positive
argument must exclude the strictly stronger bad-phase cover in (27).
Terminal-path Kempe restrictions inside one colouring of \(K\) do not by
themselves distinguish the three owner phases in (22).  More strongly,
[Note 096](096-a-real-common-carrier-does-not-force-a-or-tt.md) realizes
both required projections in one genuine carrier without an all-terminal
or \(T\)--\(T\) carrier colouring, while
[Note 097](097-a-k33-owner-phase-rectangle-blocks-local-fibre-avoidance.md)
realizes the bad owner-phase rectangle itself as a cubic local block.

## Remaining boundary

[Note 086](086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md)
provides global singleton-class avoiders one edge at a time.  Condition
(18) instead requires one pair of matchings in the two fixed literal fibres
to avoid all bad incidences simultaneously.  Complete perfect-matching
closure also does not keep an arbitrary avoider inside either fixed fibre;
[Notes 087--090](087-carrier-entry-is-residual-parity-and-is-not-forced-by-global-class-flexibility.md)
isolate this same global-to-fibre gap for carrier entry and alternating-cycle
replacement.

Consequently the real exact-Case-XII implication remains undecided.  A
positive proof must establish the safe fixed-fibre section (18), after which
the residual parity, carrier projection, and dependent second-splice gates
still remain.  Information that supplies only edgewise global avoiders,
without preserving the literal \(A,C,D\) row fibre, cannot settle this first
gate.
