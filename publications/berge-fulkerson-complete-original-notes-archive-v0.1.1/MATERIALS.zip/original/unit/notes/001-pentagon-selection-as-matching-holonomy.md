> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pentagon selection as a perfect-matching holonomy problem

## Setup

Let `H` be a cubic 5-pole with semiedges `e_1,...,e_5`. For each boundary position define

\[
\mathcal P_i=\{P:P\text{ is a perfect matching of }H,
P\cap\{e_1,\ldots,e_5\}=\{e_i\}\}.
\]

For distinct `i,j`, let

\[
R_{ij}=\{(P,Q)\in\mathcal P_i\times\mathcal P_j:P\cap Q=\varnothing\}.
\]

Then `ij` is a Tait lonely-pair state if and only if `R_{ij}` is nonempty. Indeed, two disjoint perfect matchings in a cubic graph leave at every internal vertex the unique third incident edge, and these remaining edges form the third colour class. The converse follows by taking the two singleton-boundary colour classes of a Tait colouring.

## Exact holonomy formulation

For the complementary pentagon

\[
c=(1,4,2,5,3),
\]

a compatible pentagon of singleton-boundary perfect matchings exists if and only if

\[
\bigl(R_{31}\circ R_{53}\circ R_{25}\circ R_{42}\circ R_{14}\bigr)
\cap\Delta_{\mathcal P_1}\ne\varnothing.
\]

Thus Pentagon-selection is exactly the assertion that the matching-derived relation obtained by going once around the five boundary classes has a fixed point.

The boundary statement that all five lonely-pair states occur says only that each of the five relations is nonempty. This does not imply a fixed point: abstract layered compatibility graphs can form a nontrivial double cover `C_10 -> C_5`, with local continuation in both directions but no lifted 5-cycle. Consequently, arc consistency or the existence of each Tait state cannot prove Pentagon-selection. Any proof must use structure special to perfect matchings of a common cubic 5-pole.

## Pentagonal perfect-matching lemma

Suppose one can choose `P_i in \mathcal P_i` for all five positions so that `P_i` and `P_j` are disjoint whenever

\[
ij\in\{13,14,24,25,35\}.
\]

For every edge or semiedge `e`, set `m(e)=|\{i:e\in P_i\}|`. The indices of matchings containing one edge form an independent set of the pentagon, hence `m(e)<=2`. At an internal cubic vertex the three incident multiplicities sum to five, so they are exactly `2,2,1`. Therefore the edges of multiplicity one form a perfect matching `P_0`; because `P_i` has boundary intersection exactly `{e_i}`, every semiedge has multiplicity one and belongs to `P_0`. The six matchings `P_0,P_1,...,P_5` cover every edge exactly twice, with boundary multiplicities `5,1,1,1,1,1`. Hence they give a Berge–Fulkerson colouring of type `(12345)`.

## Consequence and boundary

Under the published description of Case XII, a real Case-XII pole cannot contain such a fixed point, because `(12345)` is excluded from its exact admissible set. The imported finite program finds a fixed point for every enumerated candidate with `5,7,9` internal vertices under the simple, connected, distinct-terminal hypotheses. This finite observation does not settle arbitrary order.

The unresolved mathematical statement is therefore precise: determine whether a cubic 5-pole whose five Tait lonely-pair states are exactly the complementary pentagon must have fixed-point matching holonomy; if not, construct a real 5-pole realizing nontrivial holonomy and identify the correct extra hypothesis.

