> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The three-two core profile fixes row slots and blocks some zero-port masks

Continue [Note 282's](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md) unresolved \(3{:}2\) branch. The unmarked core \(C=F[\Sigma]\) becomes bipartite after deleting one edge \(g\) internal to side \(B\); the other side is \(R\), \(|B|-|R|=1\), and exactly three of the five proper shore ports \(A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\) are based in \(B\). The endpoints of the internal mark \(e\) are \(v\in B,w\in R\), with subdivision vertex \(t_e\) and terminal shore port \(E=e\). Work under the two required real central rows of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) and complete exact-Case-XII negative support.

**Theorem.** Let \(k\) be the number of \(B\)-side ports among \(A,I,D\). Then \(k\in\{1,2\}\). If \(k=1\), both \(H,J\) are in \(B\), and *every required \(ad/ac\) row* has the following exact marked-edge profile:
\[
\begin{array}{c|c|c}
\text{shore slots}&t_e\text{ choice}&g\text{ bit}\\\hline
X_a&t_ev&0\\
Y_a,\ V_a&t_ew&0\\
Z_e&E\text{ terminal}&1\\
U_t&E\text{ terminal}&\mathbf1_{q_t\in R}\\
W_t&t_ev&1-\#(B\cap S(W_t)).
\end{array}                                                     \tag{1}
\]
Here \(q_{ad}=D,q_{ac}=A\), while \(S(W_{ad})=\{A,I\}\) and \(S(W_{ac})=\{I,D\}\); each displayed count for \(W_t\) is zero or one.
In particular the row's zero-port occurrence \(X_a\) always avoids \(g\), even though the unrestricted zero-port shore fibre could a priori contain a different matching selecting \(t_ew\) and \(g\).

There is also a **complete-family obstruction**. Let \(R_0\subset\{A,I,D,H,J\}\) be the pair of proper shore ports based in \(R\). If
\[
R_0\in\bigl\{\{I,D\},\{A,H\},\{A,D\},\{H,J\}\bigr\},     \tag{2}
\]
then **no** zero-port shore perfect matching can select both \(t_ew\) and \(g\). The pair \(\{H,J\}\) is unavailable in this \(3{:}2\) profile, but is included to show the exterior pairing mechanism. In the \(k=1\) subcase, (2) makes the entire zero-port fibre fixed to \(t_ev\), avoiding \(g\), whenever the sole \(B\)-port among \(A,I,D\) is \(A\) or \(I\). The sole-\(D\) placement is not excluded by this test.

## Matching balance and row slots

For a shore matching \(M\), let \(S(M)\) be its selected proper ports, let \(c=1\) when it selects terminal \(E\), and put \(z=\mathbf1_{g\in M}\). If \(c=0\), let \(h=1\) when \(t_e\) is matched to \(w\), and \(h=0\) when matched to \(v\). Matching the two bipartition sides of the unmarked core gives
\[
\sum_{p\in S(M)}\operatorname{side}(p)
 +(1-c)(1-2h)=1-2z,
\quad \operatorname{side}(p)=
\begin{cases}+1,&p\in B,\\-1,&p\in R.\end{cases}         \tag{3}
\]
For the four-port singleton \(Z_e\), its proper ports are \(A,I,D\), so (3) gives \(2k-3=1-2z(Z_e)\). Hence \(z(Z_e)=2-k\in\{0,1\}\), proving \(k=1\) or \(2\). Since exactly three of all five proper ports lie in \(B\), \(k=1\) puts both \(H,J\) in \(B\).

For a singleton-\(a\) shore matching \(Y_a\) or \(V_a\), its proper ports are \(H,J\). In the \(k=1\) case their side sum is \(+2\), and (3) forces \(h=1,z=0\): both use \(t_ew\) and avoid \(g\). In any BF row, \(Z_e,U_t\) both select terminal \(E\), loading that semiedge twice. The other four shore slots \(X_a,Y_a,V_a,W_t\) must load each of the two half-edges \(t_ev,t_ew\) exactly twice. Because \(Y_a,V_a\) already use \(t_ew\), both \(X_a,W_t\) use \(t_ev\). Equation (3) for the zero-port \(X_a\) then gives \(z(X_a)=0\). This proves (1).

## Forbidden zero-port completions

Colour \(t_e\) with \(R\). Then the shore minus \(\{g,t_ew\}\) is bipartite. Align the central-path exterior so its five proper-interface endpoints are in \(R\); this makes every \(B\)-based proper interface crossing, while the two edges based at \(R_0\) are \(R\)--\(R\) exceptions. Thus the *whole five-pole* becomes bipartite after deleting \(g,t_ew\) and those two proper interface edges.

Suppose a zero-port shore matching \(X'\) selected \(t_ew\) and \(g\). The following two **actual exterior matching masks** have no shore interface, so each glues independently to this same \(X'\):
\[
\begin{array}{c|c|c|c}
\text{missing state}&\text{selected mark half}&\text{selected }K\text{ edges}
&\text{complementary exterior port pairing}\\\hline
eb&b:A_{\rm ext}&1B,2C,3D,4E&I D\mid A H,\quad b\!\to J\\
eb&b:D_{\rm ext}&1A,2B,3C,4E&A D\mid H J,\quad b\!\to I.
\end{array}                                                     \tag{4}
\]
Each mask also selects the other three terminal semiedges \(a,c,d\). The analogous state-\(ed\) masks, with \(d:B_{\rm ext}\) or \(d:E_{\rm ext}\), have the same respective port pairings. These are complete graph-induced perfect matchings, independent of whether any designated BF row used them.

If \(R_0\) is one of the two pairs in the first line of (4), its two exceptional cut edges lie on one component of the complement of the first \(eb\) triple. If \(R_0\) is one of the two pairs in the second line, they lie on one component of the second \(eb\) triple. In either case \(g,t_ew\) are selected by the triple, and all other proper edges cross the displayed bipartition. Every closed component therefore contains zero or two exceptional \(R\)--\(R\) edges and is even. By [Note 125's triple-complement lemma](125-no-single-edge-bipartization-in-exact-case-xii.md), the triple extends to a forbidden \(eb\) Tait colouring. This contradicts exact support and proves (2). \(\square\)

This theorem constrains the complete zero-port fibre in part of the \(3{:}2\) branch; it does not exclude that branch, Note 282's mixed-side \(4+1\) branch, or high-rank cores. It does not force the four-slot load intersection. The exterior masks and upstream central-path rows are hand-derived and await independent verification.
