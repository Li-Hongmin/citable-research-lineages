> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three exterior graphs for the first surviving one-shore barrier

Retain the minimum-host one-five-cut profile of [Notes 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) and [230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). By [Note 232](232-the-two-vertex-one-five-cut-barrier-cannot-have-exact-case-xii-support.md), a smallest maximum Tutte barrier \(U\) in this profile has at least three vertices. This note identifies **all** exterior unmarked graphs at the first remaining value \(|U|=3\), without limiting the cycle rank of the odd shore \(C\).

Put \(W=\{w_1,w_2,w_3,w_4\}\) for the four singleton components of \(F-U\), \(K=F[U,W]\), and \(r=|E_F(U,C)|\). Each vertex of \(U\) has three \(F\)-neighbours in distinct components of \(F-U\), so it has at most one neighbour in \(C\). Since the cut around \(C\) has five edges and only four marks other than the internal mark \(e\) can cross it,
\[
1\le r\le3,\qquad |E(K)|=9-r.                         \tag{1}
\]
Every \(w\in W\) has between one and three neighbours in \(U\): its other core edges are marked, and [Note 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md) forbids three marked edges at one vertex. The opened five-pole has girth at least five by [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md), so \(K\) has no four-cycle.

**Exterior classification.** Up to graph isomorphism preserving the bipartition \(U\mid W\), exactly these three \(K\)-shapes remain:
\[
\begin{array}{c|c|c|c}
r & |E(K)| & K & \text{degree sequence on }W\\\hline
2&7&\text{one }C_6\text{ on }U\cup3W\text{, plus one pendant }W\text{ at its degree-three }U&(2,2,2,1)\\
3&6&\text{a subdivided three-leaf claw, central vertex in }W&(3,1,1,1)\\
3&6&\text{the seven-vertex path }W-U-W-U-W-U-W&(2,2,1,1).
\end{array}                                                       \tag{2}
\]
In particular \(r=1\) is impossible. The table classifies only the **unmarked exterior**. It does not assert that any marked placement or cyclic shore completes to exact Case XII.

**Proof.** Because \(K\) has no four-cycle, each unordered pair of vertices of \(U\) has at most one common neighbour in \(W\). Therefore
\[
\sum_{w\in W}\binom{d_K(w)}2\le\binom32=3.             \tag{3}
\]
If \(r=1\), the four positive degrees on \(W\) sum to eight. Their least possible value in the left side of (3) is four, attained at \((2,2,2,2)\); this is impossible.

If \(r=2\), those degrees sum to seven. Equation (3) rules out \((3,2,1,1)\), leaving \((2,2,2,1)\). The three degree-two vertices of \(W\) must join the three *different* pairs of \(U\); otherwise two vertices of \(U\) would have two common neighbours. These six vertices form a \(C_6\). The remaining vertex of \(W\) is a leaf, attached to the unique \(U\)-vertex of degree three, since the \(U\)-degrees are \((3,2,2)\).

If \(r=3\), the degrees on \(W\) sum to six, so they are \((3,1,1,1)\) or \((2,2,1,1)\). Each \(U\)-vertex has degree two in \(K\). In the first case the degree-three \(W\)-vertex meets all of \(U\), and each \(U\) meets one distinct leaf, giving the claw. In the second case the two degree-two \(W\)-vertices meet distinct pairs of \(U\) by the four-cycle exclusion; those pairs form a path on the three \(U\)-vertices, and the two leaves attach at its ends. This gives the displayed seven-vertex path. \(\square\)

The marked-edge count is also fixed: \(5-r\) of the four exterior marks join \(W\) to \(C\), and \(r-1\) join two vertices of \(W\). Thus the \(C_6\)-plus-leaf shape has three \(W\)--\(C\) marks and one \(W\)--\(W\) mark; each tree shape has two of each. In the claw, the central \(W\)-vertex has no mark, and its three leaves have two marks apiece. Since the core is simple, the two \(W\)--\(W\) marks form a path through those leaves; its endpoints each carry one \(W\)--\(C\) mark.

All three unmarked shapes in (2) satisfy the strict Hall inequality of [Note 233](233-minimal-barrier-forces-strict-hall-on-the-one-shore-exterior.md). The classification also fixes **every** exterior zero-port triple fibre. A forest has at most one perfect matching, because two different perfect matchings would have an alternating cycle. Hence in either \(r=3\) tree, \(K-w\) has exactly one perfect matching for every \(w\in W\). In the \(r=2\) shape, deleting the pendant \(W\)-leaf leaves a \(C_6\) with exactly two perfect matchings, while deleting any of the three cycle \(W\)-vertices breaks the unique cycle and leaves exactly one. Thus
\[
|\mathcal M_w|=
\begin{cases}
2,&r=2\text{ and }w\text{ is the pendant leaf},\\
1,&\text{otherwise}.
\end{cases}                                                     \tag{4}
\]
The existence in every case comes from Note 233. Equation (4), combined with Note 230's Cartesian factorization, bounds each state-\(ej\) exterior fibre by the number of endpoints of mark \(j\), plus at most one extra mask if it meets the pendant leaf. The shore factor can still have arbitrarily many complete matchings.

Endpoint exposure and exterior triple identity alone eliminate none of the three shapes. Any further exclusion at \(|U|=3\) must use the marked placements, the cyclic shore's matching relation, and actual six-matching row loads; (2)--(4) are the complete rank-independent quotient input for that analysis.
