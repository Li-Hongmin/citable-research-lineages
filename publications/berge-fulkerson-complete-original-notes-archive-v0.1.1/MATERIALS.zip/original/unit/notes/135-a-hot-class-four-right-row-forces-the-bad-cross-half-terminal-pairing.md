> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A hot class-four right row forces the 5-to-4 cross-half pairing

The sufficient common-seed path \(5\leftrightarrow1\) in [Note 131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md) cannot arise from a mixed-side right row whose class-four singleton uses both exceptional edges. [Note 134](134-mixed-side-left-cell-forces-profiled-s-tait-and-balanced-seed-projections.md) proves that every left class-four occurrence is cold, so only cold right rows can contribute to the complete \(B_2+C_4\) spectral intersection. For a hot right row, every cross-half triple phase has the opposite \(5\leftrightarrow4\) pairing. This does not exclude a seed from a cold right row.

## Theorem

Let \(S=\{13,14,24,25,35\}\), \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole with no all-terminal BF type, no \(T\)-loop and no \(T\)--\(T\) BF type. Suppose disjoint proper edges \(e\subset X\), \(f\subset Y\) make \(H-\{e,f\}\) bipartite, with terminal \(2\) alone in \(Y\). Suppose actual complete matchings give a right row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1
\quad\text{with}\quad C_4|_{e,f}=(1,1).                 \tag{1}
\]
Apply the forced cross-half terminal-path switch of Note 131, keeping all four singleton masks, and optionally switch **any subset of the closed alternating components** of the same triple pair:
\[
q_{25}+r_{34}=p_{35}+t_{24}.                             \tag{2}
\]
For **every** resulting complete pair \(p_{35},t_{24}\), the terminal path in \(p_{35}+D_5\) beginning at \(5\) ends at **\(4\)**. Switching that path gives an actual \(T\)-state \(34\) decomposition of
\[
J=p_{35}+D_5+Y_3,\qquad J|_{e,f}=(0,0),                   \tag{3}
\]
whose complementary half-load
\[
L=t_{24}+B_2+C_4=2\mathbf1-J
\quad\text{satisfies}\quad L|_{e,f}=(2,2),\quad\mathcal R(L)=S. \tag{4}
\]

**Proof.** The mixed-side profile table of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) gives \(q_{25}|_{e,f}=(0,1)\), \(B_2|_{e,f}=(1,0)\), and \(r_{34}|_{e,f}=(0,0)\); the last follows because a \(T\)-triple with profile \((1,1)\) would extend to a forbidden \(T\)-Tait colouring. Load two in (1) and \(h(C_4)=1\) force \(h(D_5)=h(Y_3)=0\).

Every triple missing an \(X2\) pair has profile \((0,1)\), so \(t_{24}|_{e,f}=(0,1)\). Equation (2) then forces \(p_{35}|_{e,f}=(0,0)\). Thus \(p_{35},D_5,Y_3\) all avoid the exceptional edges, proving the load assertion for \(J\); equation (4)'s load follows by complementarity.

The \(p_{35},D_5\) terminal path from \(5\) can end at \(1,2\), or \(4\). It cannot end at \(2\): the path lies in \(H-\{e,f\}\), so a path from \(5\in X\) to \(2\in Y\) has an odd number of proper edges, whereas alternation between distinct terminal colours gives an even number. If it ended at \(1\), the remaining forced triple switch of Note 131 would produce an actual left row
\[
q_{14}+A_1+C_4+r_{23}+B_2+Y_3=2\mathbf1               \tag{5}
\]
with the **same complete** \(C_4\) mask as in (1). Note 134 proves that every such mixed-side left row has \(C_4|_{e,f}=(0,0)\), contradicting (1). Hence the endpoint is \(4\), giving state \(34\in T\) for \(J\). Since \(L\) already has state \(24\in S\) and its complement has a \(T\)-state, the negative BF support and [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) give \(\mathcal R(L)=S\). \(\square\)

By [Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md), a right row with \(h(Y_3)=0\) has a fixed-\(B_2,Y_3,r_{34}\) partner with the opposite class-four profile. Therefore **the hot member of every such pair** satisfies the forced \(5\leftrightarrow4\) conclusion above. The cold member can still have the \(5\leftrightarrow1\) path that yields a common complete \(B_2,C_4\) seed. When \(h(Y_3)=1\), the class-four singleton is already cold. Thus this theorem rejects a particular fixed-row confluence route; it neither empties \(\Lambda_L\cap\Lambda_R\) nor proves it nonempty.

More exactly, every left pair load has profile \((1,0)\) on \((e,f)\) by Note 134, while a hot right \(B_2+C_4\) load has profile \((2,1)\). If \(\Lambda_R^{\mathrm{cold}}\) denotes the right spectrum restricted to rows with \(C_4|_{e,f}=(0,0)\), then
\[
\boxed{\Lambda_L(H)\cap\Lambda_R(H)
       =\Lambda_L(H)\cap\Lambda_R^{\mathrm{cold}}(H).}  \tag{6}
\]
This is an equality of complete-vector intersections, not an assertion that any particular cold vector lies in the left spectrum.

## The actual class-four cycle-phase cube

The single partner in Note 129 can be extended to an explicit cycle-phase cube of actual fixed-\(B_2,Y_3,r_{34}\) partners. Start with any right row (1) having \(h(Y_3)=0\), with either class-four profile. Note 129's first forced terminal-path switch gives
\[
q_{25}+D_5=q_{24}+Z_4
\quad\text{and hence}\quad
q_{24}+B_2+Z_4+r_{34}+Y_3+C_4=2\mathbf1.             \tag{7}
\]
The complete matchings \(Z_4,C_4\) have the same singleton boundary, so their symmetric difference is a disjoint union of proper even alternating cycles \(C_1,\ldots,C_m\). Their exceptional profiles are opposite by Note 129. Exactly one of these cycles, say \(C_*\), contains **both** \(e,f\): each belongs to the symmetric difference, while a closed alternating cycle containing just one exceptional edge would be odd in the bipartition of \(H-\{e,f\}\).

For any subset \(I\subseteq\{1,\ldots,m\}\), swap the \(Z_4,C_4\) colours on precisely the cycles indexed by \(I\), producing actual same-boundary matchings \(Z_4^I,C_4^I\) with
\[
Z_4^I+C_4^I=Z_4+C_4.
\]
They replace \(Z_4,C_4\) in (7) without changing any complete edge load or the literal \(B_2,Y_3,r_{34}\) masks. Against the unchanged \(T\)-state \(34\) of the second half, the \(q_{24},Z_4^I\) terminal path can end only at \(5\): endpoints \(1,3\) would yield forbidden \(T\)-states \(12,23\). Switching it gives a genuine right row
\[
q_{25}^I+B_2+D_5^I+r_{34}+Y_3+C_4^I=2\mathbf1.       \tag{8}
\]
Distinct subsets \(I\) give distinct complete \(C_4^I\) masks. Exactly the \(2^{m-1}\) subsets containing \(C_*\) reverse the original exceptional profile. In particular, from a hot row they give \(2^{m-1}\) actual cold rows, all retaining the same complete \(B_2,Y_3,r_{34}\).

Apply Note 131's cross-half triple switch separately to each of those cold rows, allowing every closed-cycle phase of its triple pair. By [Note 136](136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md), a \(p_{35}+D_5^I\) terminal path ending at **either \(1\) or \(2\)** gives the full common-\(B_2,C_4^I\) seed. The endpoint-\(2\) construction exchanges the two complete class-two singleton occurrences before a final forced path switch; no equality between those occurrences is needed. Thus **absence of every common seed forces all \(2^{m-1}\) cold rows, in every cross-half triple phase, to have the sole remaining pairing \(5\leftrightarrow4\)**. No assertion is made that the phase choices change this pairing.

There is an exact exceptional-edge location in this remaining case. In each cold row, \(p_{35}\) avoids \(e,f\) and \(D_5^I\) uses both. If the \(5\)-path ends at \(4\), the switched triple has missing pair \(34\in T\) and must avoid both exceptional edges. Hence the switched \(5\)--\(4\) path contains neither; both \(e,f\) lie on the other \(1\)--\(2\) terminal path or on one closed alternating cycle. A cycle containing exactly one exceptional edge would be odd in the bipartition of \(H-\{e,f\}\).

The remaining \(5\leftrightarrow4\) outcome stays inside a **fixed singleton-pair right fibre**. Write
\[
p_{35}+D_5^I=r_{34}'+Z_4,
\quad Z_4|_{e,f}=(1,1),
\quad
t_{24}+B_2+C_4^I+r_{34}'+Z_4+Y_3=2\mathbf1.          \tag{9}
\]
The hot profile of \(Z_4\) follows because the \(T\)-triple \(r_{34}'\) avoids both exceptional edges while \(p_{35}+D_5^I\) has load one on each. Exchange the complete class-four occurrences \(Z_4,C_4^I\) between the halves. The new first half \(t_{24}+B_2+Z_4\) has state \(24\in S\), and its complement \(r_{34}'+Y_3+C_4^I\) has state \(34\in T\). Switching the \(t_{24},Z_4\) terminal path must end at \(5\): endpoints \(1,3\) give forbidden \(T\)-states \(12,23\) against that fixed complement. The result is another actual cold right row
\[
q_{25}'+B_2+D_5'+r_{34}'+Y_3+C_4^I=2\mathbf1.       \tag{10}
\]
It retains the **same complete \(B_2,C_4^I,Y_3\)** masks; the triple masks and class-five mask may change. Consequently any no-seed pole has a right-fibre transport that remains in the \(5\leftrightarrow4\) outcome for every choice of actual phase. This does not prove that such a closed family is impossible.
