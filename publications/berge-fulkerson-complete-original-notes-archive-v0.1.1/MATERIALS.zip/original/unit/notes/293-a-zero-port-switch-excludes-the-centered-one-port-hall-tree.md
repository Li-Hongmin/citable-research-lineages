> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A zero-port switch excludes the centred one-port Hall tree

Work in the minimum-host central-path exterior of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with complete exact-Case-XII support and the surviving \(3{:}2\) near-bipartite shore profile of [Notes 283, 289–290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md). Thus \(C-g\) is bipartite with sides \(B,R\), \(g\subset B\), the marked edge \(e\) has ends \(v\in B,w\in R\), and the two \(R\)-based proper shore ports are \(q\in\{A,D\}\) and \(r\in\{H,J\}\). Write \(p=\{H,J\}\setminus\{r\}\), so \(p\) is \(B\)-based. As before, \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\), and the allowed Tait pentagon is \(e-a-b-d-c-e\), making \(eb\) forbidden.

**Theorem.** A minimal Hall barrier of [Note 290, (4)](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) cannot have \(\alpha=\eta=1\) and \(s=s_B\). Equivalently, the four-edge Hall tree cannot have its one-port vertex at the \(B\)-based \(H/J\) port. This holds for all four placements \((q,r)\in\{A,D\}\times\{H,J\}\). Together with [Notes 291–292](292-a-seven-vertex-theta-excludes-the-last-two-port-hall-tree.md), it leaves only the \(\alpha=\eta=1,\ s\ne s_B\) one-port tree among Note 290's four-edge Hall barriers.

## A forbidden zero-port linkage

First observe a full-matching closure rule. Suppose \(N\) is **any actual zero-port shore matching** selecting both \(g\) and \(t_ew\), and the complement of \(N\) inside the shore contains a path pairing \(q\) with \(p\). This is impossible under exact Case XII.

Indeed, glue \(N\) to the following genuine exterior zero-port matching of [Note 283, (4)](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md):

\[
M_{eb}=\{a_{\rm term},c_{\rm term},d_{\rm term},
             b:D_{\rm ext},1A_{\rm ext},2B_{\rm ext},
             3C_{\rm ext},4E_{\rm ext}\}.                 \tag{1}
\]

Its boundary is the triple \(acd\), missing \(e,b\). The exterior complement of (1) pairs the proper shore ports as
\[
AD\mid HJ,\qquad b\longleftrightarrow I.             \tag{2}
\]
Note 283 checks that (1) covers every exterior vertex exactly once. For clarity, the \(A\)--\(D\) complement path follows
\(t_a-C_{\rm ext}-u_2\); the \(H\)--\(J\) path follows
\(u_3-D_{\rm ext}-u_4\); and the \(b\)--\(I\) path follows
\(t_b-A_{\rm ext}-u_1\). The selected edges at the intermediate vertices are precisely those listed in (1).

In the whole five-pole minus the glued matching, the only possible same-side proper edges are the two *unselected* cut edges \(q,r\): the other same-side edges \(g,t_ew\) were selected. Because \(q\in\{A,D\}\) and \(p,r\) are the two ports \(H,J\), the shore complement path \(q\)--\(p\), joined to the exterior paths \(A\)--\(D\) and \(H\)--\(J\), puts \(q,r\) in **one and the same complement component**. Every closed complement component therefore has either zero or two same-side edges and has even length. Alternating the two remaining colours on each component extends the glued triple matching to a genuine Tait colouring with missing pair \(eb\). Since \(eb\notin S\), its doubled BF loop is forbidden. This proves the closure rule. Notice that the rule concerns a particular *complement pairing* of a zero-port matching; [Note 283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) did not exclude the zero-port fibre for all four \((q,r)\) placements.

## The required row forces that linkage

Suppose now \(\alpha=\eta=1\) and \(s=s_B\). The two-vertex Hall tree has vertices \(s\in B\) and \(\hat r\in R\). Its vertex \(s\) carries the sole shore port \(p\) and has edges to \(\hat q,\hat r\), where \(\hat q\in R\) carries \(q\). Denote these two edges by \(a_s=s\hat q\) and \(b_s=s\hat r\). Note 290's required double-\(HJ\) row is the \((ea)(ad)\) row if \(q=A\), and the \((ea)(ac)\) row if \(q=D\). In either case choose one of its two actual singleton-\(a\) shore matchings \(Y\), and let \(W\) be the row's opposite singleton shore matching. Their forced port and marked-edge profiles are

\[
\begin{array}{c|c|c|c|c}
q& S(Y)&Y\cap\{g,t_ev,t_ew\}&S(W)&W\cap\{g,t_ev,t_ew\}\\\hline
A&HJ&\{g,t_ew\}&AI&\{t_ev\}\\
D&HJ&\{g,t_ew\}&ID&\{t_ev\}.
\end{array}                                                    \tag{3}
\]

The \(Y\)-matching selects \(p,r\), so it covers \(s,\hat r\) by those ports and covers \(\hat q\) by its third proper edge. The \(W\)-matching selects \(q,I\) and neither \(p\) nor \(r\), so it covers \(\hat q\) by \(q\) and must cover \(s\) by \(b_s\). Consequently one entire component of the shore symmetric difference \(Y\triangle W\) is the immediate \(p\)--\(r\) path
\[
p-s-\hat r-r.                                         \tag{4}
\]
The other open component pairs \(q\) with \(I\). Both \(q\) and \(I\) belong to \(W\), so this latter path has an odd number of internal edges. Its ends are on opposite bipartition sides, \(q\in R\) and \(I\in B\); hence it contains an even number of same-side edges. Every closed alternating component also contains an even number of same-side edges. The only such edges in \(Y\triangle W\) are \(g\) and \(t_ew\); neither lies on (4). Thus they occur together either on the \(q\)--\(I\) path or on one closed alternating cycle.

If they lie on a closed cycle, switch that cycle between \(Y,W\). The resulting actual \(W'\) retains its mixed port set \(AI\) or \(ID\) and selects both \(g,t_ew\), contrary to [Note 290's forbidden fibres](290-two-port-closure-separates-the-remaining-three-two-row-loads.md).

If they lie on the \(q\)--\(I\) path, switch that path. The resulting actual \(W'\) has **zero proper shore ports** and selects \(g,t_ew\). Since this switch does not meet (4), \(W'\) still selects \(b_s=s\hat r\). At \(s\), its two unselected edges are \(p,a_s\); at \(\hat q\), it no longer selects \(q\) or \(a_s\), so its two unselected edges are \(q,a_s\). The complement of \(W'\) therefore contains the direct shore path
\[
p-s-\hat q-q.                                        \tag{5}
\]
The zero-port linkage rule above excludes this \(W'\) as well. Both alternatives contradict complete matching closure, proving the theorem. \(\square\)

The conclusion is conditional on the hand-derived forced exterior rows of Notes 271–272 and the full-family fibre exclusion in Note 290; it is not a proof that an exact-Case-XII pole exists or cannot exist. No graph enumeration, local recomputation, OMEN run, or release was used.
