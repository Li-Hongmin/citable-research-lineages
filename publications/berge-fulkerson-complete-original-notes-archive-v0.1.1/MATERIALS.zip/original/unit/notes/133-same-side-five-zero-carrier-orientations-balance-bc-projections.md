> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Same-side five-zero carriers realize both singleton orientations

The same-side \(5+0\) branch of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) is the only two-edge-bipartizable branch in which an exact-Case-XII pole can still be Tait-empty, by [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md). In this branch, complete negative BF support gives a fixed-carrier orientation theorem. In particular, the two complete \(B+C\) spectra of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md) always meet **after restriction to the two exceptional edges**. Their complete-vector intersection remains open.

## Fixed-carrier orientation theorem

Let \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole with disjoint proper edges \(e,f\) such that \(H-\{e,f\}\) is bipartite, all five terminals lie in one part \(X\), and both \(e,f\) lie inside \(X\). Suppose the complete BF support has no \(T\)-loop and no \(T\)--\(T\) type. Fix an actual six-matching BF row whose half-loads are
\[
A=Q_s+P_i+P_j,\qquad R=Q_t+U_k+U_\ell,\qquad
A+R=2\mathbf1,\quad s=ij\in S,\quad t=k\ell\in T.       \tag{1}
\]
All symbols denote complete actual perfect matchings, including semiedges. Write \(E\) and \(F\) for the singleton profiles \((1,0)\) and \((0,1)\) on \((e,f)\).

If \(A(e)=A(f)=1\), then **with the complete three matchings of \(R\) fixed**, every \(S\)-state \(uv\) has two decompositions of the same complete half-load \(A\): one with \(P_u\) of profile \(E\) and \(P_v\) of profile \(F\), and one with those profiles reversed. Thus the ten oriented edges of the \(S\)-pentagon are all realized within this single complementary carrier.

**Proof.** The balance equation in Note 127 shows that every triple-boundary perfect matching avoids both \(e,f\), while every singleton-boundary perfect matching uses exactly one. In a decomposition of \(A\) with \(A(e)=A(f)=1\), the two singleton occurrences therefore have opposite profiles.

Any decomposition state of \(A\) in \(T\), combined with the fixed \(T\)-state decomposition of \(R\), would be a forbidden \(T\)-loop or \(T\)--\(T\) BF row. Hence every decomposition state of \(A\) lies in \(S\).

Start at a state \(ij\in S\) with the class-\(i\) singleton of profile \(E\) and the class-\(j\) singleton of profile \(F\). Switch the bichromatic terminal path between \(Q_{ij}\) and \(P_i\) in the three-edge-colouring of the edge-copy multigraph of \(A\). The other endpoint is some triple-colour terminal \(k\), and the unchanged class-\(j\) singleton makes the new state \(jk\). It must lie in \(S\), so \(k\) is the unique neighbour of \(j\) in the \(S\)-pentagon other than \(i\). The switched triple still avoids \(e,f\). Since the old triple also avoids both and the moving singleton contains only \(e\), the switched path avoids \(e,f\); the new class-\(k\) singleton keeps profile \(E\). The analogous switch moves the \(F\)-singleton to the other \(S\)-neighbour of the fixed \(E\)-singleton and preserves profile \(F\).

These two moves traverse the ten oriented edges of the pentagon. Explicitly, starting with \(1:E,3:F\), five successive moves give
\[
(1_E,3_F)\to(5_E,3_F)\to(5_E,2_F)\to
(4_E,2_F)\to(4_E,1_F)\to(3_E,1_F).                \tag{2}
\]
The final state is again \(13\), with the profiles reversed. Dihedral relabelling gives the same conclusion from any starting \(S\)-state. Every move changes only two complete matching masks within \(A\), so \(R\) and the load identity in (1) remain fixed. \(\square\)

## Balanced cross-half singleton pairs

In any row (1), designate one of the two singleton occurrences in \(A\) and one in \(R\). There is another actual row with the **same complete half-loads \(A,R\)**, the same \(S\)- and \(T\)-states, and the same complete three matchings of \(R\), in which the two designated singletons together use \(e\) and \(f\) once each:
\[
(P_{\mathrm{designated}}+U_{\mathrm{designated}})|_{e,f}=(1,1). \tag{3}
\]
Indeed, if \((A(e),A(f))=(2,0)\) or \((0,2)\), its singleton occurrences use only one exceptional edge and those of \(R\) use only the other. If \((A(e),A(f))=(1,1)\), use the orientation theorem at the original state to put the designated \(A\)-singleton opposite the fixed designated \(R\)-singleton. No prescribed complete identity within \(A\) is retained in this adjustment.

The exact-Case-XII appendix of Máčajová--Mazzuoccolo--Tabarelli, *Ars Mathematica Contemporanea* 26 (2026), DOI 10.26493/1855-3974.3409.c13, supplies actual rows of both types \((14)(23)\) and \((25)(34)\). In the first, \(C_4\) is in the \(S\)-half and \(B_2\) is in the \(T\)-half; in the second their roles are reversed. Applying (3) separately gives
\[
\boxed{(1,1)\in\operatorname{proj}_{e,f}\Lambda_L(H)
             \cap\operatorname{proj}_{e,f}\Lambda_R(H).}       \tag{4}
\]
Equation (4) is an intersection of **two-coordinate projections**, not a common complete \(B_2+C_4\) pair load. The two balanced rows can disagree on other proper edges, and the orientation switches can replace the complete \(B_2\) or \(C_4\) mask. Thus (4) removes a profile-only separation in the surviving Tait-empty two-edge-bipartizable branch, while the full \(\Lambda_L\cap\Lambda_R\) and the existence of a real exact-Case-XII pole remain undecided.

For any balanced \(B_2+C_4\) pair in (4), the two exceptional edges lie on the **same component** of its edge-copy degree-two graph. Indeed, that graph has one alternating terminal path with both endpoints in \(X\), plus even alternating cycles. A closed cycle containing exactly one of \(e,f\) would be odd, and an \(X\)--\(X\) alternating terminal path containing exactly one would have odd proper-edge length although its two semiedges have different matching colours. Consequently either both exceptional edges lie on the terminal path, or both lie on one closed alternating cycle. This dichotomy constrains the complete pair-load fibres but does not make the left and right fibres equal.

There is a sharper consequence in the **Tait-empty** branch. Consider the two opposite-orientation decompositions of one mixed-load carrier \(A\) at the same \(S\)-state \(ij\), supplied by the theorem. Their triple matching masks \(Q_{ij},Q'_{ij}\) must be different. If they were the same complete mask, the two singleton pairs would have the same complete pair load and fixed singleton boundaries \(i,j\). Recolouring a fixed pair load can reverse exceptional-edge ownership only on closed alternating cycles; the terminal path has its colour assignment fixed by the boundary. The parity argument above places both \(e,f\) on one such closed cycle. They would then lie in the same component of \(H-Q_{ij}\), and Note 127's complement criterion would extend \(Q_{ij}\) to an \(S\)-Tait colouring, a contradiction. Thus the five-step circuit (2) necessarily changes the complete triple mask whenever the pole is Tait-empty. It is a genuine full-matching phase obstruction, with no claim that it alone forces the left-right seed.
