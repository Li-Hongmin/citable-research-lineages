> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An overlapping BF row without its Tait loop has four singleton-phase junctions

[Note 139](139-overlap-bf-rows-force-distinct-common-singleton-matchings.md) proves that the two class-three singleton masks in an overlapping \((35)(34)\) row differ when the \([34]\) Tait loop is absent. The complete six-matching incidence gives a stronger conclusion: their difference contains at least **four** vertices where three paired differences meet. This result does not require the other thirty-nine positive Case-XII types, an all-terminal exclusion, or a small-order computation.

## The four-junction theorem

Let \(H\) be a cubic five-pole with an actual complete BF row
\[
 U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.          \tag{1}
\]
Assume that \(H\) has no three-edge-colouring of Tait state \(34\). The exact-Case-XII exclusion of BF loop \([34]\) implies this assumption, since doubling any such Tait colouring gives that loop. Form three occurrence pairs, each with one member in each BF half,
\[
 E_1=(U_{35},r_{34}),\qquad
 E_2=(Z_3,Y_3),\qquad E_3=(D_5,C_4),                 \tag{2}
\]
and write \(F_i\) for the complete edge set of the symmetric difference of pair \(E_i\). Give an edge in \(F_1\cup F_2\cup F_3\) type \(ij\) when it belongs to \(F_i\cap F_j\). A *junction* is a vertex incident with one active edge of each type \(12,13,23\). Then the number \(J\) of junctions is even and
\[
 \boxed{J\ge4.}                                    \tag{3}
\]
Every junction lies on \(F_2=Z_3\triangle Y_3\). Each alternating cycle of \(F_2\) contains an even number of junctions. Thus (3) strengthens \(Z_3\ne Y_3\): the complete singleton-phase difference has at least four specified three-colour interaction vertices.

For the disjoint pairing-critical hexagon \(\Gamma\) of [Notes 140](140-disjoint-singleton-phase-has-a-unique-critical-six-cycle-owner-pattern.md) and [141](141-a-disjoint-critical-hexagon-is-a-five-edge-carrier-detour.md), \(Z_3\triangle Y_3\) avoids every edge incident with \(\Gamma\). Hence **all four or more junctions lie outside** \(V(\Gamma)\). This remains conditional on an actual critical hexagon; the constructed five-pole in Note 140 has a loop row of a different type.

## Proof

At every edge of (1), exactly two of the six named occurrences are present. Relative to the pairing (2), the two owners either come from the same pair, in which case the edge lies in none of \(F_1,F_2,F_3\), or from two different pairs, in which case it lies in exactly the corresponding two differences. At a cubic vertex, each of the three differences has degree zero or two, counting semiedges. Therefore the active incidence is either empty, two edges of one type, or three edges of the three distinct types. Along a degree-two active strand, its type is constant.

The terminal semiedges \(1,2,3\) are inactive: their owner pairs are \(\{U,r\},\{U,r\},\{Z,Y\}\). Terminal semiedges \(4,5\) have type \(13\), with owner pairs \(\{U,C\}\) and \(\{r,D\}\). Counting active degrees modulo two shows that \(J\) is even.

Call an active edge *split* when one owner lies in each half \(\{U,Z,D\}\) and \(\{r,Y,C\}\) of (1); otherwise it is *overloaded*, with both owners in one half. Every inactive edge is split because each pair in (2) straddles the halves. At a degree-two vertex of type \(ij\), the two occurrences of each of pairs \(i,j\) take opposite active edges. Thus the split/overloaded status is constant along each maximal constant-type strand. All terminal arms of type \(13\) are split, since their terminal semiedges are split. At a junction, either all three incident edges are split, or exactly two are overloaded, one by each half.

We may normalize any overloaded *closed component with no junction*: it is a single-type alternating cycle. Switching either occurrence pair named by its type on the whole closed cycle makes every edge there split, preserves both matching boundaries, and leaves the six-row identity (1) intact. Such independent switches do not change the three difference supports or their junction count.

Suppose \(J=0\). The two active terminal semiedges are joined by a split type-\(13\) path; all other active components are closed single-type cycles. Normalize the overloaded cycles. Every edge of the resulting actual row is split, so its \(T\)-half \(r_{34}+Y_3+C_4\) is a proper three-edge-colouring of state \(34\), contrary to the hypothesis.

Suppose \(J=2\). If the two terminal semiedges join by a junction-free type-\(13\) path, the two junctions form a separate closed component. They are connected by three constant-type strands, one each of types \(12,13,23\). Normalize the junction-free cycles first. If this three-strand component is not already split, exactly two strands are overloaded. Their two types share a pair index \(i\), and their union is a closed alternating component of \(F_i\). Switch pair \(E_i\) on that cycle; all three strands become split.

Otherwise the two terminal arms attach to the two junctions, one at each, because each junction has only one type-\(13\) port. The junctions are then connected by two strands, of types \(12\) and \(23\). The arms are split. If the two internal strands are overloaded, their union is a closed alternating component of \(F_2=Z_3\triangle Y_3\); switching \(Z_3,Y_3\) there makes them split. If they were split already, no switch is needed. In either case, after normalizing the remaining junction-free cycles, every edge of the row is split and the forbidden state-\(34\) Tait colouring results. Hence neither \(J=0\) nor \(J=2\) is possible, proving (3).

Finally, at a junction the two \(F_2\)-edges have types \(12\) and \(23\), so the junction belongs to \(Z_3\triangle Y_3\). A closed \(F_2\)-component changes between those two types at every junction and keeps its type at every degree-two vertex. It must encounter an even number of junctions before returning to its starting edge. \(\square\)

This four-junction obstruction is a full-row negative-support consequence, not a cross-row seed theorem. Four junctions can form a terminal-connected bicyclic network or a terminal-free closed component; the argument above does not rule out either in a real exact-Case-XII pole. To exclude the disjoint critical hexagon, the remaining step is to couple at least one of its forced carrier paths to these exterior \(Z_3\triangle Y_3\) junctions in the **complete** perfect-matching family.
