> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first-leaf B exterior forces a forbidden \((eb)(ad)\) row

Work in the complete exact-Case-XII setting and the first-leaf type-B marked exterior of [Notes 249 and 253](253-two-shared-a-cross-rows-pin-the-first-leaf-b-exterior.md). The odd shore \(C\) and its unmarked cycle rank are arbitrary. This note uses the exterior masks of [Note 252](252-the-first-leaf-b-marking-has-a-real-cross-row.md) as a *second decomposition of the same half-load*, with no assumption that Note 252's particular six-cycle shore occurs in the putative pole.

**Theorem.** No rooted cubic five-pole with the type-B exterior and complete exact-Case-XII BF support exists. Already the required real \((ea)(ad)\) row would force a forbidden real \((eb)(ad)\) row. Consequently the first-leaf six-cycle exterior shape of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md) is excluded in every marking and at every shore order: type E fails in Note 249, types D and C fail in Notes 250–251, and type B fails here.

## A load-preserving shore splice

The mechanism is general. Split a pole into an exterior and a shore along a fixed set of ports. Suppose two ordered three-matching exterior half-loads have the same shore-port set in each slot, each use every exterior proper edge with the **same aggregate multiplicity**, and their shore-side terminal incidences agree slotwise. If one half occurs in a six-matching BF row, keep its three complete shore matching restrictions and glue them to the three slots of the other exterior half. Each new occurrence is an actual perfect matching, and the replacement half has exactly the same load on every proper edge. The opposite half of the BF row can therefore be kept unchanged. The terminal boundary type changes to that of the new exterior half.

This uses graph-induced perfect-matching closure only in its literal gluing form: for a fixed port set, a shore matching and a compatible exterior matching independently cover their disjoint vertex sets and join to one complete matching. It does not posit an identity shared by different pre-existing BF rows.

## The two B-exterior half-loads

Take the pure \(ea\) half \(D=X_a+Y_a+Z_e\) of the required \((ea)(ad)\) row. [Note 253, equation (2)](253-two-shared-a-cross-rows-pin-the-first-leaf-b-exterior.md) forces its three exterior masks. Alongside them, take the three exterior masks \(U_{eb},V_b,W_e\) from [Note 252's explicit row](252-the-first-leaf-b-marking-has-a-real-cross-row.md):

| shore port set | \(ea\) half: terminal boundary and exterior mask | \(eb\) half: terminal boundary and exterior mask |
|---|---|---|
| \(\varnothing\) | \(bcd:\ \{a:P,1Q,2R,3O,4L\}\) | \(acd:\ \{b:L,1Q,2O,3P,4R\}\) |
| \(\{h_2,h_4\}\) | \(a:\ \{3P,1O,d:Q,b:L,c:R,h_2,h_4\}\) | \(b:\ \{a:P,d:Q,c:R,h_2,h_4,1L,3O\}\) |
| \(\{e,a:C,d:C,h_3\}\) | \(e:\ \{a:C,d:C,b:P,c:Q,1L,2O,4R,h_3\}\) | \(e:\ \{a:C,d:C,b:P,c:Q,1O,2R,4L,h_3\}\) |

The labels \(bcd,acd,a,b,e\) in the middle columns denote the **full-pole terminal boundaries**, not extra exterior edges. In particular both halves use the internal \(e\)-terminal in the third slot and neither uses it in the first two slots. Their shore port sets agree slot by slot, including this terminal. Directly from the displayed masks, **each column partitions all proper exterior edges once**: the nine \(K\)-edges, the eight halves of the four exterior marked edges, and \(h_2,h_3,h_4\). Thus the two three-matching exterior half-loads have identical aggregate load \(\mathbf1\) on every exterior proper edge.

Let \(Q_0,Q_{HJ},Q_{EADI}\) be the actual complete shore restrictions of \(X_a,Y_a,Z_e\) in the supposed \((ea)(ad)\) row. Glue them, in that order, to the \(eb\)-column of the table. The result is three actual full-pole perfect matchings with state \(eb\). They have the **same shore loads** as \(X_a,Y_a,Z_e\) because the complete shore masks are reused, and the **same exterior loads** because both exterior columns are unit. Replacing \(D\) by this new \(eb\) half leaves the unchanged opposite \(ad\) half at total load two on every proper edge. Both old and new halves use each terminal semiedge exactly once, so the six occurrences still load every terminal twice. Hence they form a real BF row of type
\[
\boxed{(eb)(ad).}
\]

For any allowed Case-XII pentagon in this profile, \(e\)'s two neighbours are \(a,d\). Therefore \(eb\in T\), and \(ad\in T\) because \(a,e,d\) are consecutive on the pentagon. Exact Case XII forbids every \(T\)--\(T\) pair. This contradicts the required \((ea)(ad)\) row and proves the theorem. \(\square\)

The rowwise examples of [Notes 254–255](255-seven-shore-port-states-do-not-supply-the-second-b-cross-row.md) remain genuine but are now seen to carry this forbidden \((eb)(ad)\) row as soon as their displayed \((ea)(ad)\) row is used. Their additional \([eb]\) loops are separate witnesses of non-exact support. The other four exterior shapes left at \(|U|=4\), larger one-shore barriers, other Tutte profiles, and Berge--Fulkerson itself remain unresolved. The argument is analytic and has not received an independent check.
