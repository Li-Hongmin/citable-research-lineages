> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth five and Tait-empty support do not by themselves exclude Case XII

This note records a strict boundary for the non-3-edge-colourable branch of
the Case-XII reduction.  It is not a Case-XII pole and does not decide the
Berge--Fulkerson conjecture.

Let

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\}.
\]

## A real boundary example

There is a simple connected cubic 5-pole \(H_{33}\), with five distinct
terminals, satisfying all of the following:

* \(\operatorname{Tait}(H_{33})=\varnothing\);
* every one of the 25 \(S\)--\(T\) BF boundary types is realised;
* no \((12345)\) BF cover exists;
* the proper girth is exactly five.

The example is obtained from the frozen order-13 all-\(S\)--\(T\), no-\(A\)
pole of Note 024 by replacing one edge in each of its two disjoint squares
with a Petersen two-pole \(J=P-e\).  The resulting pole has order 33 and 47
proper edges.

For the Petersen two-pole, parity at its ten internal vertices gives

\[
10=2m+b,
\]

so every perfect matching uses either both terminals or neither.  Therefore
every BF colouring of \(J\) assigns the same two-colour label to its two
terminals.  Contracting or expanding \(J\) consequently preserves the
complete BF boundary support of the host pole in both directions.  A
3-edge-colouring of \(J\) would close to a 3-edge-colouring of the Petersen
graph, so \(J\) is Tait-empty.  The two replacements remove the only squares
and preserve girth five.

The fixed verifier is

```text
python3 units/berge-fulkerson/scratch/worker-tait-empty-boundary/verify_girth5_nontait_bf_boundary.py
```

and ends with `GIRTH5_NONTAIT_BF_BOUNDARY_VERIFIED`.  The host pole's complete
BF support and the absence of \(A\) are independently checked by the frozen
certificate cited in Note 024.

## What the example separates

The constructed pole also retains all five \(T\)-loops and all ten
\(T\)--\(T\) types.  Each inserted Petersen two-pole is separated by a
cyclic proper 2-edge-cut.  Hence the example is not a genuine Case-XII side
of a cyclically 5-edge-connected minimum counterexample.

It proves the strict non-implication

\[
\begin{aligned}
&\text{real cubic incidence}+\text{girth }5+\operatorname{Tait}=\varnothing\\
&\qquad+\text{all 25 }S\!\text{--}T+\neg(12345)
\not\Longrightarrow\bot .
\end{aligned}
\]

Thus any proof of the Tait-empty Case-XII branch must use at least one of
the two additional hypotheses violated here: exact absence of every
\(T\)-loop and \(T\)--\(T\) type, or the whole-graph prohibition on a
nonterminal cyclic 2-edge-cut.  Girth and local six-matching incidence alone
are insufficient.

The final open statement is therefore narrower:

> Does a bridge-free, girth-five cubic 5-pole with no nonterminal proper
> 2-edge-cut and exact Case-XII support exist?

No proof or real counterexample for this exact statement is supplied here.

## Evidence and provenance

The construction and structural checks are in
`scratch/worker-tait-empty-boundary/tait-empty-girth5-route-boundary.md` and
`scratch/worker-tait-empty-boundary/verify_girth5_nontait_bf_boundary.py`.
The complete-support seed is the real order-13 all-SS pole recorded in
Note 024.  This note uses the construction only as a boundary result; it
does not promote the exploratory seed search or any finite census to a
general theorem.
