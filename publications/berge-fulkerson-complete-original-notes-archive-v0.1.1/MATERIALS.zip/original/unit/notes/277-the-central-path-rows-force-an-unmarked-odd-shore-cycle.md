> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central-path rows force an unmarked odd shore cycle

> **Scope correction (2026-10-01):** The \(E\)--\(D\) path of the
> \((ea)(ad)\) row used below requires the left exterior template.
> [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> gives a genuine right row with \(U_{ad}(EJ)\). The unmarked-core oddness
> conclusion is not established here for that branch.

In the one-internal-mark five-cut profile of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), let \(\Sigma\) be the connected odd component of the unmarked core \(F=J-M\), and let \(e=vw\) be its unique internal marked edge. The six-port shore is \(Z=\Sigma\cup\{t_e\}\): the subdivision vertex \(t_e\) is joined to \(v,w\), and its terminal semiedge is the port \(E=e\). The other relevant ports are \(A=a:\Sigma\), \(I=h_1\), and \(D=h_2\). Work in the fixed central-path exterior and pure pairing of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md).

**Theorem.** If this actual pole has both required \((ea)(ad)\) and \((ea)(ac)\) rows with the forced pure \(E\)--\(I\), \(A\)--\(D\) shore pairing, then the **unmarked graph \(F[\Sigma]\)** contains an odd cycle. Thus a high-rank but bipartite unmarked shore cannot realize the complete exact-Case-XII support in the remaining central-path marking. The conclusion is stronger than [Note 276's](276-the-two-central-path-rows-force-an-odd-shore-cycle.md) odd cycle in \(Z\), because it excludes oddness arising only from the subdivided marked edge \(e\).

## Proof

Suppose \(F[\Sigma]\) is bipartite. A zero-port matching \(X_a\) of \(Z\) must match \(t_e\) to one endpoint of \(e\); its remaining edges perfectly match \(F[\Sigma]\) after deleting that endpoint. Since \(|\Sigma|\) is odd, the bipartition sides differ by exactly one vertex, and every endpoint exposed by such a matching lies in the larger side.

If \(v,w\) lie on the same side, colour \(t_e\) with the opposite side. Then all internal edges of \(Z\) are bipartite, contradicting Note 276 because both required rows exist. Hence \(v,w\) lie on opposite sides. Exactly one of them, say \(v\), lies in the larger side. **Every** zero-port shore matching therefore uses the same half-edge \(t_ev\), including the zero-port occurrences \(X_{ad}\) and \(X_{ac}\) in our two rows. Their remaining shore matchings may differ arbitrarily.

In the \(ad\) row, \(X_{ad}\triangle U_{ad}\) has a shore path from \(E\) to \(D\). In the \(ac\) row, \(X_{ac}\triangle U_{ac}\) has a shore path from \(E\) to \(A\). Both start at \(t_e\) along \(t_ev\), since their \(U\)-matchings use terminal port \(E\), while their zero-port \(X\)-matchings use \(t_ev\). Each path starts and ends with an edge of its \(U\)-matching, so after deleting its two port semiedges it has odd internal length. Removing the common first edge \(t_ev\) leaves an **even** path from \(v\) to the internal endpoint of \(D\), and an even path from \(v\) to the internal endpoint of \(A\), both wholly in \(F[\Sigma]\).

The pure \(A\)--\(D\) path of \(X_{ad}\triangle Z_{ad}\) starts and ends with \(Z_{ad}\)-edges, so after removing its two port semiedges it has **odd** internal length. It avoids \(t_e\): that vertex belongs instead to the disjoint pure \(E\)--\(I\) path. Thus it too lies wholly in \(F[\Sigma]\). Concatenating the two even paths through \(v\) with this odd \(A\)--\(D\) path gives an odd closed walk in the bipartite graph \(F[\Sigma]\), a contradiction. \(\square\)

No identity of the two zero-port complete matchings is assumed; only their forced choice of one half of \(e\) is used. The proof supplies an explicit odd-walk certificate from **any chosen pair** of the two real rows. [Note 254's bipartite twelve-vertex shore](254-the-b-cross-rows-require-shore-cycle-intersections.md) realizes either row separately under different port identifications, while [Note 255's modified shore](255-seven-shore-port-states-do-not-supply-the-second-b-cross-row.md) has unmarked odd cycles but still lacks the prescribed second row. Hence the odd cycle is necessary, not sufficient. This result does not establish the four-slot load intersection or settle Berge--Fulkerson; its upstream forced-row tables remain to be independently checked.
