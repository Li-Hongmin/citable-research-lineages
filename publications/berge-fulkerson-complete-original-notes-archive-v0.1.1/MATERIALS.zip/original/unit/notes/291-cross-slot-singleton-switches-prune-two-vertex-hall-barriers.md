> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cross-slot singleton switches prune two-vertex Hall barriers

Work conditionally in the genuine central-path exterior of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with the complete exact-Case-XII BF support of [Máčajová–Mazzuoccolo–Tabarelli (2026), Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), checked against the primary PDF on 2026-10-01. The allowed pentagon is \(S=e-a-b-d-c-e\). Denote the six shore ports by \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). In either prescribed row, both singleton-\(a\) occurrences have the forced exterior mask \(Y_L\), with shore ports \(HJ\). The opposite singleton has ports \(AI\) in the \(ad\) row and \(ID\) in the \(ac\) row.

**Cross-slot threading lemma.** Let \(Y\) be *either* singleton-\(a\) occurrence in a real prescribed row. In the \(ad\) row, the unique terminal \(a\)--\(d\) path of \(Y\triangle W_d\) traverses all four shore ports \(A,I,H,J\). In the \(ac\) row, the unique terminal \(a\)--\(c\) path of \(Y\triangle W_c\) traverses all four shore ports \(I,D,H,J\). Equivalently, the shore-path pairings
\[
\boxed{AJ\mid IH\quad(ad),\qquad DH\mid IJ\quad(ac)}
\tag{1}
\]
are impossible. This is a consequence of the *complete* matching closure within each row; it makes no identification of matchings across the two rows.

## Proof of the threading lemma

The prescribed exterior masks give every exterior component of these two symmetric differences. Here a letter \(A,I,D,H,J\) at an endpoint means the corresponding shore port, not the similarly named exterior path vertex:
\[
\begin{array}{c|c|c}
\text{row}&\text{exterior paths from the terminal pair}&
                 \text{remaining exterior path}\\\hline
ad&a\!-\!A,\quad d\!-\!J&I\!-\!H\\
ac&a\!-\!D,\quad c\!-\!H&I\!-\!J .
\end{array}                                                    \tag{2}
\]
These are direct traces of the actual masks, rather than abstract boundary types. For \(ad\), the \(d\)--\(J\) route passes through
\(t_d,E_{\rm ext},t_c,A_{\rm ext},t_b,D_{\rm ext},u_4\), and the \(I\)--\(H\) route passes through \(u_1,B_{\rm ext},u_2,C_{\rm ext},u_3\). The \(a\)--\(A\) route uses only \(t_a\). For \(ac\), the \(a\)--\(D\) route passes through \(t_a,C_{\rm ext},u_2\), the \(c\)--\(H\) route through \(t_c,A_{\rm ext},t_b,D_{\rm ext},u_3\), and the \(I\)--\(J\) route through \(u_1,B_{\rm ext},t_d,E_{\rm ext},u_4\). The three paths in each row cover all thirteen exterior internal vertices, so there is no omitted exterior cycle or arm.

Switch the two *complete actual matchings* \(Y,W_d\) along their \(a\)--\(d\) alternating path, obtaining \(Y',W_d'\) with singleton boundaries \(d,a\), respectively. The six matching occurrences still load every edge twice. Their boundary multiset is unchanged: the triple boundaries remain \(bcd,bce\), the singleton boundaries remain \(e,a,a,d\). They therefore form another real \((ea)(ad)\) BF row. Note 272's forced-row theorem makes the new singleton-\(a\) occurrence \(W_d'\) use the \(HJ\) shore ports. It began with ports \(AI\); all four of \(A,I,H,J\) must therefore be toggled on the switched terminal path. The same argument with \(Y,W_c\) yields the \(ac\) assertion: the *other* singleton-\(a\) occurrence remains unchanged with exterior \(Y_L\), and Note 271 forbids a real row whose two singleton-\(a\) occurrences use opposite exterior sides. Thus \(W_c'\) also has ports \(HJ\), even though Note 271 states its template only up to an initial path reflection.

In the \(ad\) case, pairing \(AJ\mid IH\) in the shore joins the two terminal arms of (2) through \(AJ\), while \(IH\) and the exterior \(I\)--\(H\) path form a closed alternating component. The terminal switch toggles only \(A,J\), leaving \(W_d'\) with ports \(I,J\), contrary to \(HJ\). The other two pairings, \(AH\mid IJ\) and \(AI\mid HJ\), put all four ports on the terminal path. Likewise, \(DH\mid IJ\) in the \(ac\) case would leave \(W_c'\) with ports \(I,H\), contrary to \(HJ\); the other two pairings \(DJ\mid IH\) and \(DI\mid HJ\) pass this necessary test. This proves (1). \(\square\)

## Applying the lemma to Note 290's four-edge Hall cuts

Use the surviving \(3{:}2\) near-bipartite profile of [Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md): \(q\in\{A,D\}\) is the \(R\)-based port among \(A,I,D\), \(r\in\{H,J\}\) is the \(R\)-based port among \(H,J\), and \(s_B\) carries the other, \(B\)-based \(H/J\) port. Assume the Hall barrier has \(\alpha+\eta=2\), so its two-vertex tree is \(s\hat r\). Let \(p\) be the additional \(B\)-based port at \(s\) when \(\alpha=2,\eta=0\), or the sole port at \(s\) when \(\alpha=\eta=1\) and \(s\ne s_B\). The required row with both \(HJ\) singleton occurrences selecting \(g,t_ew\) is the \(ad\) row if \(q=A\), and the \(ac\) row if \(q=D\).

**Two-port vertex, \(\alpha=2,\eta=0\).** Note 290 gives \(s=s_B\) and \(p\in\{A,I,D\}\setminus\{q\}\). If an opposite singleton \(W\) selects \(p\), then \(Y\triangle W\) has the immediate shore path \(p\,s\,s_B\) between these two ports. Applying (1) to the indicated row removes the following placements:
\[
\begin{array}{c|c|c|c}
q&r&p&\text{forbidden immediate shore path}\\\hline
A&H&I&I J\quad(ac)\\
A&J&I&I H\quad(ad)\\
D&H&I&I J\quad(ac)\\
D&H&A&A J\quad(ad)\\
D&J&I&I H\quad(ad).
\end{array}                                                    \tag{3}
\]
The table uses the \(ac\) row when \(W=W_c\) has ports \(ID\), and the \(ad\) row when \(W=W_d\) has ports \(AI\). Note 290's girth-five argument already forces \(p=I\) whenever \(r=J\). Hence the **only \(\alpha=2,\eta=0\) placement not excluded by these arguments** is
\[
\boxed{q=A,\qquad r=H,\qquad s=s_B\text{ carries }J,D.}        \tag{4}
\]
Its two required singleton switches have allowed shore pairings; (4) is not an existence claim.

**One-port vertex, \(\alpha=\eta=1,\ s\ne s_B\).** Here \(p\in\{A,I,D\}\setminus\{q\}\). Every \(HJ\) matching in the double-\(HJ\) row uses \(s\hat q\): its selected \(r\)-port covers \(\hat r\), and it selects neither \(p\) nor the edge \(s\hat r\). If \(q=A,p=D\), the opposite \(W_d\) selects \(q=A\) but not \(p=D\), so it uses \(s\hat r\). The alternating path
\[
A-\hat q-s-\hat r-r                                      \tag{5}
\]
is therefore an entire shore component of \(Y\triangle W_d\). For \(r=J\) this is the forbidden \(AJ\) pairing in (1). Similarly, if \(q=D,p=A\), the opposite \(W_c\) selects \(D\) but not \(A\), and (5) is a \(D\)--\(r\) shore component; \(r=H\) gives the forbidden \(DH\) pairing. Thus
\[
\boxed{(q,p,r)\ne(A,D,J),\qquad(q,p,r)\ne(D,A,H).}          \tag{6}
\]
The \(p=I\) placements and the two opposite orientations \((A,D,H),(D,A,J)\) pass this necessary switch test. The case \(s=s_B\) is not covered by (6).

There is a related reduction of Note 290's local-incidence alternative. If \(\hat q=\hat r\), the shared base itself gives a shore path \(q\)--\(r\) in \(Y\triangle W_d\) when \(q=A\), or in \(Y\triangle W_c\) when \(q=D\). Equation (1) excludes \((q,r)=(A,J),(D,H)\). Girth five excludes a shared base for \((A,H)\): the exterior route \(t_a-C_{\rm ext}-u_3\) would close a four-cycle. Thus the only unexcluded coincident-base placement is
\[
\boxed{\hat q=\hat r\ \Longrightarrow\ (q,r)=(D,J).}       \tag{7}
\]
Also \(\hat r\ne w\), because an \(HJ\) matching in the double-\(HJ\) row selects both its \(r\)-port and \(t_ew\). In the \(\alpha=\eta=1,\ s\ne s_B\) branch, \(\hat q\ne w\) as well: the same \(HJ\) matching selects both \(s\hat q\) and \(t_ew\), which would meet at \(\hat q=w\).

## The surviving two-port vertex creates a second pentagon cut

In (4), the sole internal edge of \(s\) joins it to \(\hat H=\hat r\); its two ports go to \(u_2\) through \(D=h_2\) and to \(u_4\) through \(J=h_4\). The \(H=h_3\) port joins \(\hat H\) to \(u_3\). Consequently
\[
P=s-\hat H-u_3-C_{\rm ext}-u_2-s                         \tag{8}
\]
is a genuine proper 5-cycle in the minimum host, distinct from the original cap pentagon. Its five outward edges, in the cyclic order displayed in (8), are
\[
1=sJ,\quad 2=\hat H z,\quad 3=u_3D_{\rm ext},
\quad 4=C_{\rm ext}t_a,\quad 5=u_2B_{\rm ext},            \tag{9}
\]
where \(z\) is the third neighbour of \(\hat H\). The vertex \(\hat H\) cannot be \(w\), since an actual \(HJ\) singleton selects \(H\) and \(t_ew\) simultaneously. Girth five rules out a chord of \(P\). The cap pentagon lies in the complement of \(P\); hence this five-edge cut separates cycles. In a bridgeless cubic cyclically five-edge-connected minimum counterexample, its complement is connected: two complementary components would each have a cut of at least three edges and together use at least six of the five cut edges. Proposition 4.4 therefore applies to this *second* five-cut. Its \(P\)-side is the ordinary pentagon relation of Cases I–XII; the opposite side must have one of the corresponding complete BF relations. Case XIII cannot use \(P\) as either side: its two listed relations have respectively no loops or no all-terminal type, whereas an ordinary pentagon has five loops and the all-terminal type.

The two required rows, however, **do not contradict the pentagon relation by themselves**. Restricting their actual six matchings to the outward edges (9) gives
\[
\begin{array}{c|cccccc}
&X_a&Y_a&Z_e&U_t&V_a&W_t\\\hline
ad&345&1&2&234&1&5\\
ac&345&1&2&5&1&234 .
\end{array}                                                   \tag{10}
\]
For example, \(X_a\) uses the cycle edge \(s\hat H\) and outward edges \(3,4,5\); \(U_{ad}\) and \(W_c\) use the cycle edge \(su_2\) and outward edges \(2,3,4\). Every entry in (10) follows from the forced exterior masks and the one-edge matching decisions at \(s,\hat H\). In both rows the two triple colours miss respectively \(12\) and \(15\), so the induced \(P\)-boundary BF type is precisely \((12)(15)\), which appears in the published ordinary-pentagon relation. This calculation rules out an immediate contradiction from the *selected rows at the new pentagon cut*. It does not give a BF colouring of the opposite shore: that shore also contains the original cap pentagon, and the displayed rows need not extend across it.

The opposite shore \(Q\) has a further **real terminal adjacency**: its cut-terminal vertices for ports \(1\) and \(3\) are \(u_4,D_{\rm ext}\), joined inside \(Q\) by the proper edge \(4D\). This rules out most of the second-cut relations. [Note 123's one-edge BF exchange](123-exact-case-xii-terminal-vertices-are-independent.md) says that an edge between ports \(1,4\) turns a real \((25)(15)\) colouring into a real \((23)(15)\) colouring. Relabel that implication around the cyclic order \(1,2,3,4,5\) of \(P\). Five useful forms are
\[
\begin{array}{c|c|c}
\text{terminal edge in }Q&\text{trigger BF type in }Q&
                 \text{forced ordinary-pentagon type}\\\hline
13&(12)(24)&(12)(45)\\
24&(23)(35)&(23)(15)\\
35&(34)(14)&(34)(12)\\
14&(15)(35)&(15)(23)\\
25&(12)(14)&(12)(34).
\end{array}                                                   \tag{11}
\]
For the first line, use the permutation \(1\mapsto1,2\mapsto4,3\mapsto5,4\mapsto3,5\mapsto2\) in Note 123's implication. The next two lines rotate this implication around \(P\), and the last two reflect and rotate it. Every type in the last column belongs to the ordinary pentagon relation, because both of its missing pairs are adjacent on \(P\). If \(Q\) admitted a trigger in its row, the forced type would be common to \(P,Q\) and their actual BF colourings would glue into a BF cover of the minimum counterexample, an impossibility.

The primary Appendix lists the triggers in (11) for the canonical \(L^*\) relation of every Case I–XII **except** \((34)(14)\) in Cases I and II. In particular, Cases III–XII have all five triggers; Cases I and II have the four triggers for diagonals \(13,24,14,25\). Although the actual terminal edge of \(Q\) is \(13\) in the labeling (9), identifying the ordinary pentagon \(P\) with the Appendix's standard pentagon is determined only up to a dihedral permutation. Under such an identification, that edge can become any of the five diagonals. Therefore the exact remaining necessary condition is
\[
\boxed{Q\text{ has Case I or II support, and its actual terminal edge }4D
\text{ corresponds to canonical diagonal }35.}             \tag{12}
\]
The missing trigger in Cases I–II is an exact boundary of this particular one-edge exchange test, not a certificate that either relation is realizable by the present \(Q\). No BF colouring of \(Q\) was inferred from the displayed BF rows of the original pole.

The threading lemma and (3)–(12) are conditional on the hand-derived forced exterior rows of Notes 271–272 and the exclusions of Notes 289–290. At this stage they leave (4), the listed \(\alpha=\eta=1\) placements, the \(v\in\{x,y\}\) incidence collision, larger Hall barriers, the \(4+1\) and high-rank cores, other rectangle contexts, and Berge–Fulkerson unresolved. They give no genuine exact-Case-XII counterexample. The new exterior traces and upstream row tables still require independent verification; no graph census, local recomputation, OMEN run, or publication was used.

**Subsequent refinement.** [Note 292](292-a-seven-vertex-theta-excludes-the-last-two-port-hall-tree.md) excludes the remaining placement (4) and the one-port placement \((q,p,r)=(A,D,H)\) by identifying seven-vertex theta five-cuts in the minimum host. Thus the \(\alpha=2,\eta=0\) four-edge Hall obstruction is now conditionally closed.
