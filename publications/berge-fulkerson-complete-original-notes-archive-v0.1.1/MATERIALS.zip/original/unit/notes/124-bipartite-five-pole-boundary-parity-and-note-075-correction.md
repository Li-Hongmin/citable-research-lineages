> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bipartite five-poles have one excluded terminal in every BF pair type

The nine-vertex graph in [Note 075](075-fixed-row-paired-switch-connectivity-fails.md)(3)
is non-bipartite: its proper edges contain the seven-cycle
\(0-2-4-7-5-8-3-0\). Consequently its certified three isolated
\([13]\) BF witnesses cannot be separated using Note 075's bipartite
matching sign. The path--\(K_{3,3}\) pole in the later part of that note is a
different bipartite example and does supply opposite-sign witnesses in its
three stated target cells. The following all-orders restriction explains
why the bipartite construction cannot have exact Case-XII support.

## Boundary-parity theorem

Let \(H\) be a cubic five-pole whose proper-edge graph is bipartite with
parts \(X,Y\). Semiedges are counted with multiplicity, so several may meet
one vertex. Exactly one of \(X,Y\) carries four semiedges and the other
carries one. Call the sole semiedge on the latter side \(s_i\). Then:

1. Every perfect matching of \(H\) uses either one semiedge on the
   four-semiedge side or three semiedges, two on that side and \(s_i\).
   In particular no perfect matching uses all five semiedges.
2. In every six-perfect-matching BF cover, the two triple-boundary matchings
   both contain \(s_i\). Thus both missing-pair labels avoid \(i\):
   \[
   \operatorname{BFsupp}(H)
   \subseteq
   \bigl\{(p)(q):p,q\in\tbinom{[5]\setminus\{i\}}2\bigr\}.
   \tag{1}
   \]
   The right side has at most \(\binom{6+1}{2}=21\) unordered types,
   including loops; this is an upper bound, not a realization claim.
3. Every Tait state of \(H\) avoids \(i\). A Tait colouring exists because
   adjoining a pendant edge at each semiedge gives a bipartite graph of
   maximum degree three, which has a proper three-edge-colouring.

In particular, a bipartite five-pole cannot have Tait state set equal to
any pentagon on all five terminal positions. This independently exposes
the incompatibility between the two claims originally made for the
explicit graph (3) of Note 075.

**Proof.** Let \(t_X,t_Y\) be the numbers of semiedges incident with each
side. Counting ends of proper edges gives
\[
3|X|-t_X=3|Y|-t_Y,
\qquad t_X+t_Y=5.
\tag{2}
\]
The odd integer \(t_X-t_Y\) is a multiple of three and lies between
\(-5\) and \(5\), so it is \(\pm3\). Interchange the sides so
\(t_X=4,t_Y=1\); then \(|X|-|Y|=1\).

For a perfect matching \(P\), let \(a_X,a_Y\) count its semiedges on the
two sides. Its proper edges match all remaining vertices across the
bipartition, hence
\[
|X|-a_X=|Y|-a_Y,
\qquad a_X-a_Y=1.
\tag{3}
\]
Since \(a_Y\le1\), the only possibilities are \((a_X,a_Y)=(1,0)\) and
\((2,1)\). In a BF cover the six boundary sizes sum to ten, because every
semiedge is covered twice. Therefore exactly two of its six matchings have
three semiedges. Both contain \(s_i\), so their complementary missing
pairs avoid \(i\), proving (1). In a Tait colouring the boundary sizes of
the three colour classes sum to five, so there is one triple class and two
singleton classes, whose singleton terminals lie on \(X\). This proves
the Tait-state restriction. The edge-colouring assertion follows from the
standard bipartite line-colouring theorem, or by successively taking
matchings after regularizing the pendant-edge graph. \(\square\)

The exact Case-XII support listed in Máčajová--Mazzuoccolo--Tabarelli
(2026, Proposition 4.4 and the Case-XII appendix, DOI
10.26493/1855-3974.3409.c13) contains all twenty-five \(S\)--\(T\)
types, where \(S=\{13,14,24,25,35\}\) and
\(T=\{12,15,23,34,45\}\). For every position \(i\), some required
missing-pair label contains \(i\), contradicting (1). Hence
\[
\boxed{\text{No bipartite cubic five-pole has exact Case-XII BF support.}}
\tag{4}
\]
This uses complete BF support, not a selected family or a Tait-state
assumption. It leaves the non-bipartite, terminal-independent poles of
[Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) and their
common-\(B,C\) pair-load intersection from
[Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md)
unresolved.

In Note 123's marked-core representation, let \(J\) be the cubic core and
\(M\) its five marked edges. A cycle \(C\) of \(J\) expands to a proper
cycle of length \(|C|+|C\cap M|\) in the pole, and every proper cycle
arises this way. Therefore exact Case XII requires at least one core cycle
with
\[
|C|+|C\cap M|\equiv1\pmod2.                         \tag{5}
\]
When \(J\) is bipartite, (5) says that some cycle uses an odd number of
marked edges. This is a necessary parity condition on the minimum-host
core, not a condition sufficient for the pair-load intersection.

## Scope of the Note-075 correction

The frozen [nine-vertex certificate](../computations/bundles/order-nine-paired-switch-disconnected-cell/README.md)
checks the edge list (3), its 22 perfect matchings, exact Tait set \(S\),
and the three isolated \([13]\) witnesses. Its assertions about those
witnesses remain valid; its verifier does not assert bipartiteness.

In the separate path--\(K_{3,3}\) pole of Note 075, the path vertices
\(p,q,r\) carry respectively two, one, and two semiedges. The four
semiedges at \(p,r\) lie on one bipartition side, and the semiedge at
\(q\) lies on the other. In each of Note 075's three cells the two
triple-boundary colours each use one terminal at \(p,q,r\). The two
singleton colours at \(r\) are precisely the two matchings using both
connector edges, or the deleted \(K_{3,3}\) edge after projection. Thus the two displayed gadget BF covers
splice to the same prescribed boundary cell, with the same path matching
in every slot; their gadget permutation-sign products are opposite.
The fixed-boundary bipartite sign therefore separates those witnesses.
Unlike the certified pole (3), this construction does not claim exact
Tait set \(S\) or five distinct terminal vertices.

[Note 076](076-k33-two-sums-preserve-boundary-support-and-force-opposite-kempe-signs.md)
independently proves that a \(K_{3,3}\) two-sum creates opposite local
paired-switch signs while preserving *complete* BF support. Consequently
the sign obstruction is real, but neither Note-075 example decides the
existential Case-XII seed or its full-PM closure.
