> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The second Hamilton \(K_{3,3}\) long-row signature forces forbidden \((eZ)(eW)\)

Keep the genuine \((eZ)(eX)\) row and marked Hamilton \(K_{3,3}\) exterior of [Notes 489--490](490-the-k33-long-row-forces-one-pentagon-and-shore-e-paths.md), with forbidden \(e\)-states \(\{eZ,eW\}\). Take Note 490's **second** residual signature:
\[
P=eZ\text{ rooted at }Z:2,qquad R=eX\text{ rooted at }X:4,
\qquad J=Z\text{ using }2u_2.                              \tag{1}
\]
Name the six actual complete occurrences \(P,R,K,J,A,B\) as in [Note 492](492-the-first-k33-long-signature-recompletes-to-a-forbidden-ew-loop.md). Their shore boundary sets are forced to be
\[
\begin{array}{c|cccccc}
&P&R&K&J&A&B\\\hline
\partial Q&\varnothing&\varnothing&\{p_4,p_5\}&\{p_1,p_4\}&
\{e,p_1,p_2,p_3\}&\{e,p_2,p_3,p_5\}.
\end{array}                                                \tag{2}
\]

**Fixed-full-mask closure theorem.** Every genuine row (1), on an arbitrary six-port shore, admits a BF recompletion of type \((eZ)(eW)\) using its **same six complete shore matchings one for one**. This is a forbidden \(T\)--\(T\) type in exact Case XII when \(eZ,eW\in T\). Hence this second long-root signature is impossible in exact support, with no use of the shore \(e\)-path constraints of Note 490.

**Proof.** Preserve each old complete shore restriction \(Q_P,Q_R,Q_K,Q_J,Q_A,Q_B\), and use the following new exterior matching under the same colour name. A mark absent from the marked-half column uses its terminal semiedge.

| colour | new boundary role | marked halves | tree halves | proper ports |
|---|---|---|---|---|
| \(P\) | \(eZ\) | \(Z:2\) | \(1u_1,3u_2,4u_3,5u_4,6u_5\) | none |
| \(R\) | \(eW\) | \(W:6\) | \(1u_1,2u_2,3u_3,4u_4,5u_5\) | none |
| \(K\) | \(W\) | \(X:1,Y:6,Z:5\) | \(2u_1,3u_2,4u_3\) | \(p_4,p_5\) |
| \(J\) | \(Z\) | \(X:4,Y:1,W:6\) | \(2u_2,3u_3,5u_5\) | \(p_1,p_4\) |
| \(A\) | \(e\) | \(X:4,Y:1,Z:2,W:3\) | \(5u_4,6u_5\) | \(p_1,p_2,p_3\) |
| \(B\) | \(e\) | \(X:1,Y:6,Z:5,W:3\) | \(2u_1,4u_4\) | \(p_2,p_3,p_5\) |

Every row glues to the old complete shore matching under the same name because its \(e,p_i\) set is unchanged from (2). The following edge-colour pairs certify load two on the tree subdivisions:
\[
\begin{array}{c|cc|c}
 &\text{left half}&\text{right half}&\text{proper port}\\\hline
u_1&PR&KB&JA\\
u_2&RJ&PK&AB\\
u_3&RJ&PK&AB\\
u_4&RB&PA&KJ\\
u_5&RJ&PA&KB
\end{array}.                                                \tag{3}
\]
At original vertices \(1,\ldots,6\), their three incident pairs are respectively
\[
\begin{array}{c|ccc}
1&PR:1u_1&KB:X:1&JA:Y:1\\
2&PA:Z:2&RJ:2u_2&KB:2u_1\\
3&PK:3u_2&RJ:3u_3&AB:W:3\\
4&PK:4u_3&RB:4u_4&JA:X:4\\
5&PA:5u_4&RJ:5u_5&KB:Z:5\\
6&PA:6u_5&RJ:W:6&KB:Y:6.
\end{array}                                                \tag{4}
\]
The marked subdivisions have terminal and original-half pairs
\[
\begin{array}{c|ccc}
X&PR:\text{terminal}&KB:X:1&JA:X:4\\
Y&PR:\text{terminal}&JA:Y:1&KB:Y:6\\
Z&RJ:\text{terminal}&PA:Z:2&KB:Z:5\\
W&PK:\text{terminal}&AB:W:3&RJ:W:6.
\end{array}                                                \tag{5}
\]
Finally, \(A,B\) use the \(e\) terminal. Thus every exterior edge has load two and every colour is a genuine matching; the unchanged shore also has load two. The two zero-port triples have boundary types \(eZ,eW\), so the recompletion is the forbidden \((eZ)(eW)\) row. \(\square\)

Together with Note 492, the \(P:Z:2\) branch of Note 490 is entirely excluded for forbidden \(\{eZ,eW\}\), at every shore order, rank and complement parity. Only its two \(P:Z:5\) signatures remain in this required \((eZ)(eX)\) row. This is a conditional hand-derived closure result pending independent review; it uses no OMEN or local mathematical recomputation and does not resolve the remaining Hamilton \(K_{3,3}\) pair, other exterior families, full exact Case XII or Berge--Fulkerson.
