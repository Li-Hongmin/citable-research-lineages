> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-spoke prism zero-port signatures force an alternating forbidden pair

Continue the rooted-tree parity reduction of [Notes 358–359](359-two-root-parity-gate-and-k33-sharpness.md) and the genuine two-spoke boundary in [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md). Use that note's triangular prism and tree
\[
T=\{AB,BC,Aa,Bb,ac\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac),
\]
with four exterior marks \(AC,Cc,bc,ab\), in that order along the marked path \(A-C-c-b-a\). The sixth shore port is \(e\). For a zero-port shore perfect matching \(Q\), each marked label \(j\) has two actual complete rooted \(ej\)-triple matchings with the same \(Q\). Call \(j\) **doubly blocked at \(Q\)** if both triple complements contain an odd cycle.

> **Sharp zero-port signature theorem.** Suppose \(Z-Q\) has no odd closed component. If two distinct marks are doubly blocked at \(Q\), then exactly one of the following holds:
> \[
> \begin{array}{c|c|c|c}
> \text{doubly blocked pair}&e\text{-path}&\text{odd proper path}&\text{even proper path}\\\hline
> \{AC,bc\}&ep_3&p_2p_4&p_1p_5\\
> \{Cc,ab\}&ep_5&p_2p_4&p_1p_3 .
> \end{array}                                                     \tag{1}
> \]
> In both cases the \(e\)-path is even. Conversely, each signed pairing in (1) blocks both roots of precisely the displayed two marks. No signed pairing without an odd closed shore component blocks three marks.

For audit, \(j\ell\mid uv\mid wz\) denotes the exterior pairing \(jp_\ell,p_up_v,p_wp_z\). In the one-odd column, \((k;q)\) denotes \(ep_k\) and the unique odd proper shore path \(q\); its other proper pair is forced. In the three-odd column, \((k;uv\mid wz)\) denotes the complete shore pairing with all three paths odd.

| mark | first root | second root | one-odd signatures blocking both | three-odd signature blocking both |
|---|---|---|---|---|
| \(AC\) | \(A:j5\mid13\mid24\) | \(C:j3\mid14\mid25\) | \((5;14),(3;24)\) | \((4;13\mid25)\) |
| \(Cc\) | \(C:j5\mid14\mid23\) | \(c:j1\mid24\mid35\) | \((5;24),(1;23)\) | \((2;14\mid35)\) |
| \(bc\) | \(b:j3\mid12\mid45\) | \(c:j3\mid15\mid24\) | \((3;q)\), any proper pair \(q\subset\{1,2,4,5\}\) | none |
| \(ab\) | \(a:j1\mid24\mid35\) | \(b:j5\mid12\mid34\) | \((1;34),(5;24)\) | \((4;12\mid35)\) |

**Proof.** Root \(T\) at the selected endpoint of each mark and orient each tree subdivision toward its child in the zero-port triple. The parent endpoint is then connected to that port in the complement; an unselected mark connects its two prism endpoints, and the selected mark connects its other endpoint to terminal \(j\). Tracing these degree-two connections gives the first two pairing columns. This uses the complete two-root factorization of Note 358, so neither root or shore matching can be silently omitted.

The shore has one or three odd port paths by Note 359. If the only odd path is the \(e\)-path, no root is blocked: every closed component uses only even shore paths and even exterior paths. Otherwise apply Note 359's blocker rule. For an exterior \(j\ell\mid uv\mid wz\) and shore \(ep_k\): when \(\ell=k\), either odd proper path blocks the root; when \(\ell\ne k\), the shore must contain the exterior pair disjoint from \(p_k\) and that pair must be odd. With three odd paths and \(\ell=k\), the two proper shore pairs must equal \(uv\mid wz\); with \(\ell\ne k\), the pair disjoint from \(p_k\) must be present. These conditions give the last two columns.

The three-odd signatures are distinct and \(bc\) has none. Among one-odd signatures, the only inter-row intersections are
\[
(3;24)\in AC\cap bc,\qquad (5;24)\in Cc\cap ab.
\]
Their forced remaining shore pairs are \(15\) and \(13\), respectively. This proves the exhaustive classification and the converse. \(\square\)

**Exact-Case-XII consequence.** In the [published relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), two of the four \(ej\)-Tait loops are forbidden. Thus if a putative exact-Case-XII pole with this exterior has **any** zero-port \(Q\) without an odd closed shore component, its forbidden \(e\)-pair must be one of the two alternating pairs of the four-mark path, and \(Q\) must have the corresponding *exact* signed shore signature in (1). For any other forbidden \(e\)-pair, every zero-port \(Q\) has an odd closed shore component, so the two zero-port triples in a genuine BF row cannot reuse one complete shore matching by [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). This dichotomy applies at every shore order and cycle rank. It does not settle the required BF rows with two different shore masks.

Both signatures in (1) are graph-realizable at the single-\(Q\) level by Note 386's eight-vertex theta shore: use its displayed port assignment for \(\{Cc,ab\}\), and exchange the names \(p_3,p_5\) for \(\{AC,bc\}\). In both real poles, the other zero-port matching \(Q'\) from the same alternating six-cycle has one odd \(e\)-path and two even proper paths, so complete matching closure produces all four \(ej\)-Tait loops and excludes exact Case XII. This realizes the sharp boundary of the signed-fibre theorem while leaving the full exact-support obstruction open. The table and deductions are hand-derived and await an independent proof check; no OMEN or local mathematical recomputation was used.
