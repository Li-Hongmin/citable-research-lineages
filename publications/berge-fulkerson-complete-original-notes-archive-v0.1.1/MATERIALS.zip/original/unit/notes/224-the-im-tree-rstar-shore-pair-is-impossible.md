> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(I_m\) tree--\(R^*\) shore pair is impossible

Work in the genuine \(I_m\) two-five-cut quotient of a
minimum-host exact-Case-XII candidate, with girth at least five,
as in [Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md).
Then **one three-vertex tree shore and one complete Figure-7
Case-XIII \(R^*\) shore cannot occur**, at any order of the
cyclic shore. This closes that shore-type combination in
\(I_m\), not the other shore combinations or the full
Berge--Fulkerson conjecture.

The remaining row needed for the exclusion is a general
six-slot transport. Name the tree shore \(A^\circ\), centre it
at \(u_1\), and give it end groups
\(\{u_2,x\}\mid\{z,p\}\). If \(B^\circ\) supports the
actual BF type \((yq)(u_1q)\), then the outer five-pole
supports
\[
                              \boxed{(yq)(xz).}             \tag{1}
\]
Use the actual tree type \((u_2z)(xp)\). Independently relabel
the six occurrences of the two shore rows as follows:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(q\) |
| 2 | \(u_1u_2z\) (missing \(xp\)) | \(q\) |
| 3 | \(x\) | \(u_1u_2z\) (missing \(yq\)) |
| 4 | \(p\) | \(u_2zy\) (missing \(u_1q\)) |
| 5 | \(u_2\) | \(y\) |
| 6 | \(z\) | \(u_1\) |

The shore-half labels and exterior connector labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&25&26&13/14&-\\
B&36&34&34&-&45/12
\end{array},
\qquad
(R_1,R_2;D_x,D_y,D_p,D_q)=(45,16;26,13,23,45).       \tag{2}
\]
At every exterior cubic vertex and marked subdivision vertex,
the incident two-slot labels partition \([6]\). The direct
\(z\)-mark has residual \(15\), and the outer terminal labels
are
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(15,45,26,56,36).                \tag{3}
\]
Slot \(5\) has \(\{z,x,p\}\), missing \(yq\); slot
\(6\) has \(\{y,p,q\}\), missing \(xz\). The remaining
four slots are singleton boundaries. Because the shore inputs
are actual BF rows, their internal edges retain load two,
and the connector partitions prove (1) for six genuine
outer perfect matchings.

After [Note 223](223-a-yq-u1y-row-forces-the-forbidden-yq-xz-pair.md),
the only relative Figure-7 placements of this tree end partition
still needing exclusion have
\[
         (y,q,z)=(4,2,3),\qquad
         (u_1,u_2)=(1,5)\ \text{or}\ (5,1).             \tag{4}
\]
Here \(yq=24\in P\) while \(u_1q\) is \(12\) or
\(25\), both in \(Q\); hence \((yq)(u_1q)\) is an
actual \(R^*\) type. The existing four-loop transports
force the unique allowed loop cycle
\[
                              S=z-y-x-q-p-z.                \tag{5}
\]
Both \(yq\) and \(xz\) lie outside \(S\), so (1) is a
forbidden \(T\)--\(T\) type. This excludes both orders
in (4) and finishes the end partition
\(\{u_2,x\}\mid\{z,p\}\).

For completeness, [Note 170, (3)](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md)
puts the centre port of any three-vertex tree shore on an
unmarked edge toward \(u_1\) or \(u_2\). If the centre is
\(u_1\), the three pairings of its four remaining ports are
\[
 \{u_2,z\}\mid\{x,p\},\qquad
 \{u_2,x\}\mid\{z,p\},\qquad
 \{u_2,p\}\mid\{z,x\}.                                    \tag{6}
\]
The last pairing makes the end incident with both \(u_2\)
and mark \(p\) part of the proper four-cycle through
\(u_2,w_2,t_p\), violating girth five. The first pairing
is excluded by [Notes 216--217](217-the-first-tree-rstar-im-end-partition-is-impossible.md).
The second is excluded by [Notes 218--224](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md)
and the row above. Reflecting the \(I_m\) quotient by
\((u_1,w_1,x,y)\leftrightarrow(u_2,w_2,p,q)\) handles a
tree centred at \(u_2\). Exchanging the two five-cut shores,
with \(x\leftrightarrow y\) and \(p\leftrightarrow q\),
handles a tree initially named \(B\). Thus no tree--\(R^*\)
shore pair survives in this quotient.

The conclusion depends on the minimum-host structural setting,
the complete actual Case-XIII relation of the cyclic shore,
and the six-slot transports in Notes 212 and 216--224. Those
analytic dependencies await an independent check. The result
does not exclude tree--pentagon, pentagon--\(R^*\), other
two-vertex quotients, larger barriers, or a perfectly
matchable-core branch.
