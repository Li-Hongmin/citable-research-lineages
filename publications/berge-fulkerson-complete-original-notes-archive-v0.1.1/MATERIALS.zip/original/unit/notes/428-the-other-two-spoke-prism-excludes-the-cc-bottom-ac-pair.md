> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other two-spoke prism excludes the (Cc,ac) forbidden pair

Use the marked prism tree of [Note 427](427-the-other-two-spoke-prism-excludes-the-top-bottom-diagonal-pair.md):
\[
(u_1,\ldots,u_5)=(AB,BC,Aa,Bb,bc),\qquad
(X,Y,Z,W)=(AC,Cc,ac,ab).
\]
The shore has ports \(e,p_1,\ldots,p_5\) and arbitrary size. Suppose the **complete** BF boundary support is exact Case XII with forbidden \(e\)-labels \(\{Y,Z\}\). Its two possible allowed pentagons are
\[
S_1=e-X-Y-Z-W-e,\qquad S_2=e-X-Z-Y-W-e.                \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eY)(eW)\) and excludes every double-\(T\) cell.

> **Pair exclusion.** Neither pentagon in (1) can be the complete BF boundary support of a pole with this marked tree and any shore.

Suppose the required row exists. Write \(P=eY\) for its forbidden triple, \(R=eW\) for its allowed triple, \(K=W,J=Y\) for the corresponding marked singleton occurrences, and \(D_0,D_1=e\) for the two singleton-\(e\) occurrences. The \(W\)-starting path of \(R\triangle K\) must end at \(X\), the only other allowed \(e\)-label; an ending at \(Y\) or \(Z\) would give a second forbidden triple beside unchanged \(P\). The path is wholly exterior by the zero-port-triple argument of [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md). A switch along it gives \(R'=eX\) with the **same complete shore matching** as \(R\), leaving \(P,J,D_0,D_1\) unchanged.

For any unchanged singleton-\(e\) occurrence \(D\), the \(e\)-to-port path within the shore is identical against \(R,R'\). The pentagons require opposite terminal targets:
\[
\begin{array}{c|cc}
 &R=eW&R'=eX\\ \hline
S_1&Z&Y\\
S_2&Y&Z
\end{array}.                                                \tag{2}
\]
Both triples have zero exterior ports; \(D\) has three. Hence when the \(Y\)- and \(Z\)-terminal arms reach distinct exterior ports, the third terminal also reaches the remaining port and no exterior port-to-port detour is possible.

**The direct \(a\)-root is impossible.** If \(R=eW:a\), its rooted tree slots are \((B,C,A,b,c)\). From \(W-t_W-a\), the path cannot end at forbidden \(Z:a\). The long possible \(X\)-route through \(u_3,A,u_1,B,u_2,C,X:C\) occupies \(a,C\) in \(K\), forcing both \(Z=ac\) and \(Y=Cc\) to use \(c\). Thus the only route is \(W-t_W-a-u_3-A-t_X-X\), which forces
\[
K:X:A,\ Y:C,\ Z:c,\ W\text{ terminal},\ au_3.      \tag{3}
\]
The switched \(R'=eX:A\) and \(R\) both take \(cu_5\).

If \(P=eY:C\), then \(P,R\) saturate \(cu_5\), while \(P,K\) saturate \(Y:C\). Both \(D_i\) take \(Y:c\). Each such \(D_i\) must also take \(Z:a,W:b\): its \(Y:c\) covers \(c\), and \(Z:a\) then covers \(a\). If instead \(P=eY:c\), the \(Y\)-terminal and marked-half loads force one \(D_i:Y:c\); that occurrence again takes \(Z:a,W:b\). In either root case choose such a \(D\). It covers both \(b,c\) at marks, so \(D:p_5\); in both \(R\triangle D\) and \(R'\triangle D\) the \(Y\)-terminal arm is the unchanged path
\[
Y-t_Y-c-u_5-p_5.                                       \tag{4}
\]
The shore \(e\)-path must select \(Y\) in one comparison and \(Z\) in the other by (2), but \(Y\) has the same port \(p_5\) in both. The distinct \(Z\)-arm cannot also use \(p_5\). Contradiction.

**The \(b\)-root leaves only one root/route pair.** Now \(R=eW:b\) has slots \((A,C,a,B,c)\). From \(W-t_W-b\), \(K\) cannot take \(bu_5\), which reaches only forbidden \(Y:c,Z:c\); it must pass through \(bu_4,B\). It may then reach \(X:A\) through \(Bu_1,A\), or \(X:C\) through \(Bu_2,C\). Call these routes \(A\) and \(C\).

On route \(A\), \(K:bu_4,Bu_1,X:A,Z:a\). If \(P=eY:C\), the \(au_3,cu_5\) loads force \(K:Y:c\); if \(P=eY:c\), the \(Cu_2,au_3\) loads force \(K:Y:C,cu_5\). In both cases the \(Y\)-edge loads force at least one \(D_i:Y:c\), and that matching takes \(Z:a,W:b,p_5\). Equation (4) again contradicts (2). On route \(C\), the marks are forced to \(K:X:C,Y:c,Z:a\), with \(K:bu_4,Bu_2,Au_3\). If \(P=eY:C\), then \(P,R\) saturate \(cu_5\); the same \(Y:c\)-load argument again produces a \(D_i:Y:c,Z:a,W:b,p_5\), contradicting (2).

It remains to take
\[
P=eY:c,\qquad R=eW:b,\qquad
K:W\text{ terminal},X:C,Y:c,Z:a,bu_4,Bu_2,Au_3.    \tag{5}
\]
The switch gives \(R'=eX:C\). Here \(P,R\) saturate \(Cu_2,Au_1,Bu_4,au_3\), while \(P,K\) saturate \(Y:c\). The loads at \(C,X,Y\) force
\[
J:X:C,\qquad D_0,D_1:X:A,Y:C,\quad p_3\text{ in both }D_i.  \tag{6}
\]
Among \(J,D_0,D_1\), exactly one occurrence \(M\) takes \(Z:a,W:b,cu_5\); the other two take \(Z:c,W:a\). At \(B\), the same three occurrences use \(Bu_1,Bu_1,Bu_2\) in some order, since \(P,R\) saturate \(Bu_4\) and \(K:Bu_2\).

If \(M=D_i\), this singleton-\(e\) has \(X:A,Y:C,Z:a,W:b,cu_5,p_3\). Its \(Z\)-terminal arm exits at \(p_3\) against both \(R,R'\). Its \(Y\)-arm exits at \(p_2\) or \(p_4\) against \(R\), and at \(p_2\) or \(p_1\) against \(R'\), according as \(M:Bu_1\) or \(Bu_2\). Neither orientation of (2) can select the required equal port. Therefore \(M=J\).

Now **both** \(D_i\) have marked halves \(X:A,Y:C,Z:c,W:a\). Each covers \(b\) by \(bu_4\) or \(bu_5\), and \(B\) by \(Bu_1\) or \(Bu_2\). Their \(Y,Z\) terminal arms have these shore exits:

| \(D_i\)'s \(B,b\) slots | \(Y\) under \(R\) | \(Y\) under \(R'\) | \(Z\) under \(R\) | \(Z\) under \(R'\) |
|---|---|---|---|---|
| \(Bu_1,bu_4\) | \(p_2\) | \(p_2\) | \(p_5\) | \(p_5\) |
| \(Bu_1,bu_5\) | \(p_2\) | \(p_2\) | \(p_3\) | \(p_4\) |
| \(Bu_2,bu_4\) | \(p_3\) | \(p_1\) | \(p_5\) | \(p_5\) |
| \(Bu_2,bu_5\) | \(p_4\) | \(p_1\) | \(p_3\) | \(p_4\) |

For example, with \(Bu_2,bu_5\), the \(R\triangle D_i\) \(Y\)-arm follows \(Y-t_Y-C-u_2-B-u_4-p_4\), and its \(Z\)-arm follows \(Z-t_Z-c-u_5-b-t_W-a-u_3-p_3\). Against \(R'\), those arms end at \(p_1,p_4\), respectively. The \(S_1\) demanded exits (\(Z\) under \(R\), \(Y\) under \(R'\)) differ in all four rows. The \(S_2\) demanded exits (\(Y\) under \(R\), \(Z\) under \(R'\)) agree only in the last row. That would force **both** \(D_i:Bu_2,bu_5\), overloading \(Bu_2\) beside \(K\) and \(bu_5\) beside \(P\). Thus \(S_2\) also fails.

The required \((eY)(eW)\) cell is impossible. Together with Notes 424–427, this excludes **five of the six** forbidden \(e\)-pairs for the second two-spoke tree. Only \(\{Cc,ab\}\) remains here; other marked exteriors and the Berge–Fulkerson conjecture remain open. This complete-matching proof is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
