> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(K_{3,3}\) two-sums destroy failed-star nonoverload gates

The residual criterion of
[Note 078](078-residual-degree-two-criterion-for-two-triple-completion.md)
begins with an edge-nonoverload gate for each specified singleton
quadruple.  That gate is not forced by exact boundary support, common actual
perfect matchings, and cubic incidence.  The support-preserving
\(K_{3,3}\) two-sum of
[Note 076](076-k33-two-sums-preserve-boundary-support-and-force-opposite-kempe-signs.md)
can amplify the unavoidable triple-hit edge of a failed pivot star until
every proposed reuse gate is overloaded.

This is a conditional transformation theorem.  It does not construct an
exact-Case-XII pole from scratch.

## Repeated extension

Use the six singleton identities

\[
 (A,B,C,D,X,Y)=(a_1,a_2,a_4,a_5,x,y)
\]

and the four pivot singleton quadruples

\[
 AXCD,\qquad ABXC,\qquad ABCD,\qquad BYCD.          \tag{1}
\]

The three reuse targets of Note 073 are

\[
 BDXY,\qquad ACXY,\qquad ABDY.                     \tag{2}
\]

Let a cubic 5-pole \(H_0\) contain actual perfect matchings realizing the
four BF rows in (1), with the same identity \(X\) used in the two repeated
arms.  There is a cubic 5-pole \(H_2\), obtained from \(H_0\) by two
successive \(K_{3,3}\) two-sums along one proper edge and then one of its
splice edges, such that:

1. \(H_2\) has exactly the same complete BF boundary support and Tait state
   set as \(H_0\);
2. the same lifted singleton identities realize the same four pivot rows
   and the same repeated-extension equality pattern;
3. every quadruple in (2) has load at least three on some proper edge of
   \(H_2\).

To prove this, write \(|V(H_0)|=2k+3\).  Its \(3k+2\) proper edges receive
total load \(6(k+1)=6k+6\) from the six singleton matchings.  Some edge
therefore has load at least three.  No pivot quadruple can contribute three
occurrences to one edge, because it belongs to a BF double cover.  Note 073
then shows that the exact hit set is one of

\[
 ABY,ACY,ADY,BDX,AXY,BXY,CXY,DXY.                 \tag{3}
\]

For each hit set \(J\) in (3), identify the perfect matchings of
\(K_{3,3}\) with \(S_3\) and distinguish \(f=u_0v_0\).  There are two
assignments of gadget matchings to the six identities such that:

- precisely the identities in \(J\) use \(f\);
- every pivot quadruple in (1) is completable to a BF cover of the gadget;
- the Boolean OR of their three target-badness vectors is \(111\).

One assignment can never have badness \(111\), by Note 077, so two factors
are sharp for this factorwise statement.

Insert the first factor at the edge with hit set \(J\).  For a pivot
singleton set \(R\), its gadget matchings use \(f\) exactly
\(|J\cap R|\) times.  Its completing pair therefore uses \(f\)
\(2-|J\cap R|\) times, exactly the number of the two old triple matchings
using the replaced edge.  The completing pair can consequently be assigned
and spliced occurrence by occurrence, preserving literal reuse.  Both
splice edges retain hit set \(J\), so the second factor is inserted in the
same way.  If a bad gadget edge is the deleted edge \(f\), an unused splice
edge has the same hit set and remains overloaded.  The two badness vectors
together block all three targets.  Note 076 supplies exact support and
Tait-state preservation.

## Three distinct extensions

For the seven identities

\[
 (A,B,C,D,X,Y,Z)=(a_1,a_2,a_4,a_5,x,y,z),
\]

use the four pivot rows and eight optimal four-row patterns of
[Note 074](074-three-distinct-extensions-require-four-witness-reuse-rows.md).
One \(K_{3,3}\) two-sum suffices to block all eight gates.

Indeed, the seven singleton matchings have total proper-edge load
\(7(k+1)>2(3k+2)\), so some edge has a hit set \(J\) of size at least three.
Every pivot quadruple meets \(J\) in at most two identities.  There are 29
such subsets of the seven identities.  For each of them, an \(S_3\)
assignment with prescribed \(f\)-hit set \(J\) simultaneously makes all
four pivot quadruples completable and gives every one of the eight optimal
gates at least one overloaded target quadruple.  The same occurrencewise
splice preserves the four pivot rows, while the overload blocks every cell
choice associated with that target.

The finite \(S_3\) classifications for both branches are frozen in the
[proof bundle](../computations/bundles/k33-failed-star-overload-amplifier/README.md).

## Irreducibility is indispensable

If \(H_0\) has exact Case-XII support, then so do the transformed poles, but
the construction supplies no unconditional base pole.  Moreover, every
insertion creates internal 4-cycles and a cyclic proper 2-edge-cut.  The
result therefore does not survive the girth-five and cyclic-connectivity
conditions inherited from a minimum whole-graph counterexample.

Consequently no argument using only exact boundary support, cubic common
matching incidence, and the four pivot rows can force a Note-078
nonoverloaded target.  Any positive theorem must couple different
proper-edge factors through an indecomposability hypothesis, such as girth
five, cyclic connectivity, whole-graph minimality, or an equivalent global
restriction on simultaneous companion completions.
