> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All six forbidden pairs are excluded on the three-spoke top-path prism

Keep the exterior of [Notes 442–444](444-the-three-spoke-prism-excludes-the-two-adjacent-bottom-forbidden-labels.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,Cc),\qquad
(X,Y,Z,W)=(AC,ab,bc,ca),                                  \tag{1}
\]
with sixth shore terminal \(e\). Notes 442–444 exclude forbidden pairs \(\{eX,eW\}\), \(\{eX,eY\}\), \(\{eX,eZ\}\), and \(\{eY,eZ\}\). This note excludes the final reflection class and hence the entire marked-tree orbit, conditional on that hand-derived chain.

> **Final forbidden-pair exclusion.** No cubic five-pole with exterior (1), at any shore order or topology, has complete exact-Case-XII BF support with forbidden pair \(\{eY,eW\}\) or its reflected pair \(\{eZ,eW\}\). In particular, if Notes 442–444 hold, no complete exact-Case-XII pole has this three-spoke top-path prism exterior, irrespective of the forbidden pair.

It suffices to treat \(\{eY,eW\}\). The allowed pentagons are \(e-X-Y-W-Z-e\) and \(e-X-W-Y-Z-e\). Under \((e,X,Y,W,Z)=(1,3,5,2,4)\) and \((1,3,2,5,4)\), respectively, the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires \((eY)(eZ)\), listed as \((14)(15)\) or \((12)(14)\). It forbids both \([eY]\) and \((eY)(eW)=(12)(15)\).

Name a required genuine row's six **complete** matching occurrences
\[
P=eY,\qquad R=eZ,\qquad K=Z,\qquad J=Y,\qquad E=e,\qquad F=e. \tag{2}
\]
Here a two-letter type names the missing pair of a triple, while a single letter names the terminal of a singleton. By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(P,R\) use no shore port. At the \(Z\)-starting component of \(R\triangle K\), an end at \(Y\) would give forbidden \([eY]\), and an end at \(W\) would give forbidden \((eY)(eW)\). Thus if \(R=eZ:b\), \(K\) cannot take \(Y:b\), which would end the path immediately at \(Y\). It must take \(bu_4\), then \(Y:a,W:c\). If \(R=eZ:c\), \(K\) cannot take \(W:c\), which would end the path immediately at \(W\). It must take \(cu_5\), then \(W:a,Y:b\). No assumption on the remaining path or on the shore is used.

Write \(UV\) for the pair of occurrence labels \(\{U,V\}\). A triple \((T,L,R)\) at a marked subdivision gives its terminal, first marked half, and second marked half; hence \(t_Y=(\text{terminal},Y:a,Y:b)\), \(t_Z=(\text{terminal},Z:b,Z:c)\), and \(t_W=(\text{terminal},W:a,W:c)\). The columns \(u_3:a,u_4:b,u_5:c\) give the pairs on the indicated tree halves. The original row (2) has exactly the following bottom data:
\[
\begin{array}{c|ccc|ccc}
(P\text{ root},R\text{ root})&u_3:a&u_4:b&u_5:c&t_Y&t_Z&t_W\\ \hline
(a,b)&RJ&PK&PR&(RJ,PK,EF)&(PK,RJ,EF)&(PR,EF,KJ)\\
(b,b)&PR&KJ&PR&(RJ,KE,PF)&(PK,RE,JF)&(PR,JF,KE)\\
(a,c)&RJ&PR&PK&(RJ,PF,KE)&(PK,JF,RE)&(PR,KE,JF)\\
(b,c)&PR&RJ&PK&(RJ,EF,PK)&(PK,EF,RJ)&(PR,KJ,EF).
\end{array}                                                   \tag{3}
\]
In line \((b,b)\), relabel \(E,F\) so that \(K,E\) take \(Y:a\); in line \((a,c)\), relabel them so that \(K,E\) take \(Y:b\). Each line follows by partitioning six labels at \(a,b,c,t_Y,t_Z,t_W\) after the just-forced \(K\) halves. For instance, in line \((a,b)\), \(P,K\) take \(Y:a\), so \(Y:b=EF\); \(P,K\) also take \(bu_4\), so \(Z:b=RJ\); then \(Z:c=EF\), \(W:c=KJ\), and \(W:a=EF\).

For every line, keep all six original complete shore restrictions, **every** tree-edge pair, every proper-port pair, and all pairs at \(t_X\). Replace only the pairs at \(t_Y,t_Z,t_W\) by the following:
\[
\begin{array}{c|ccc|c}
(P,R)\text{ old roots}&t_Y&t_Z&t_W&\text{new type}\\ \hline
(a,b)&(KJ,PF,RE)&(PR,JF,KE)&(PR,KE,JF)&[eY]\\
(b,b)&(KJ,EF,PR)&(PR,EF,KJ)&(PR,KJ,EF)&[eY]\\
(a,c)&(RJ,PK,EF)&(PR,KJ,EF)&(PK,EF,RJ)&(eY)(eW)\\
(b,c)&(RJ,KE,PF)&(PR,KE,JF)&(PK,JF,RE)&(eY)(eW).
\end{array}                                                   \tag{4}
\]
The tree-half pairs \((u_3:a,u_4:b,u_5:c)\) remain exactly those in the corresponding line of (3). For the first two lines, \(P\) retains its old \(eY\) root, \(R=eZ:b\) becomes \(eY:b\), and \(K=Z\) becomes singleton \(Y\), yielding a forbidden \([eY]\) loop. For the last two lines, \(P=eY\) retains its root, \(R=eZ:c\) becomes \(eW:c\), and \(K=Z\) becomes singleton \(W\), yielding the forbidden \((eY)(eW)\) row. \(J=Y\) and \(E=F=e\) remain boundary types throughout; equality of boundary types does not assert equality of shore matchings.

Each triple in (4) partitions \(\{P,R,K,J,E,F\}\). At the three bottom original vertices, combine its unchanged tree pair from (3) with the two new marked-half pairs: for \((a,b)\), these are \((RJ,PF,KE)\) at \(a\), \((PK,RE,JF)\) at \(b\), and \((PR,KE,JF)\) at \(c\); the other lines give the same six-label partition directly. All top vertices and tree subdivisions are untouched. Every marked or tree edge still has load two, and every occurrence selects one edge at each exterior vertex. At \(e\) the label pair remains \(EF\); all five proper-port pairs also remain unchanged. Gluing each new exterior restriction to its **own unchanged complete shore matching** therefore gives an actual forbidden BF row in the pole.

The required \((eY)(eZ)\) row cannot occur, proving \(\{eY,eW\}\) impossible. Reflection \(A\leftrightarrow C,\ a\leftrightarrow c\) swaps \(Y,Z\) and gives \(\{eZ,eW\}\).

The two bottom-triangle recompletions give a support law without assuming exact Case XII. For **any** pole with exterior (1), [Note 444](444-the-three-spoke-prism-excludes-the-two-adjacent-bottom-forbidden-labels.md) proves that \((eY)(eW)\) forces \([eY]\) or \((eY)(eZ)\); the argument above proves that \((eY)(eZ)\) forces \([eY]\) or \((eY)(eW)\). Direct terminal-path switches cover the alternative endpoints, and (3)–(4) cover the remaining endpoint. Consequently, whenever \([eY]\) is absent, the two mixed types \((eY)(eW)\) and \((eY)(eZ)\) are present together or absent together. Reflection gives the analogous law with \(Y,Z\) exchanged. This is a graph-induced complete-matching closure implication, independent of shore order and topology.

Together with Notes 442–444, all six forbidden pairs are excluded for this one three-spoke tree orbit. The other three-spoke tree orbit, other exterior profiles, the general real exact-Case-XII closure obstacle, and Berge–Fulkerson remain open. This proof and its upstream hand-derived chain await independent review; no OMEN or local mathematical recomputation was used. \(\square\)
