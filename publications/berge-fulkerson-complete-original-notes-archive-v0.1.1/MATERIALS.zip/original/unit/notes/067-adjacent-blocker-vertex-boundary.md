> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Vertex-level boundary for a two-edge capacity blocker

Suppose a putative capacity-two transversal is blocked by two proper edges (F=\{a,b\}), with every selected singleton matching containing exactly one of (a,b). If (a,b) are adjacent at a cubic vertex (v), then the third incident edge (c) has zero load across the five singleton matchings: all five incidences at (v) are supplied by (a) or (b).

This is a genuine vertex-equation constraint, but it does not by itself force a forbidden T-loop or TT support. The order-13 exact-\( S \) blocker example has its closure repaired by additional perfect matchings and an (A)-cover. The remaining question is whether complete PM closure must always repair such zero-load edges in every exact-\( S \) pole.
