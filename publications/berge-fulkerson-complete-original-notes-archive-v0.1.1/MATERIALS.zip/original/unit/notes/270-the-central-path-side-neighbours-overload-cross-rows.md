> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central path side neighbours overload cross rows

Continue the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile, now in the last \(|U|=r=4\) marked exterior left by [Notes 264–269](269-the-near-end-path-ae-neighbour-overloads-the-ed-row.md):
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad h_i=u_i\Sigma,
\]
\[
a:C\!:\!\Sigma,\qquad b:AD,\quad c:AE,\quad d:BE. \tag{1}
\]
The shore \(\Sigma\) has arbitrary odd order and unmarked cycle rank. The reflection \(A\leftrightarrow E,\ B\leftrightarrow D\) interchanges \(b,d\) and fixes \(a,c\).

**Theorem.** Complete exact-Case-XII perfect-matching support is impossible in (1) if the second allowed neighbour of the internal mark \(e\) is \(b=AD\) or, by reflection, \(d=BE\). Only the end-to-end cross mark \(c=AE\) remains as a possible second \(e\)-neighbour in the \(|U|=r=4\) one-shore barrier profile.

It suffices to take \(ea,eb\in S\), so \(ec\in T\). The state-\(ea\) zero-port triple has the unique exterior
\[
X_a=\{a:C,1A,2B,3D,4E\}.                           \tag{2}
\]
In any pure-\(S\) \(ea\) half, the \(a\)-terminal path in \(X_a\triangle Y_a\) must end at \(b\). [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md) keeps it exterior. Ending at \(b:A\) would use \(2C,1B,b:A\); then \(c:AE,d:BE\) would both need \(E\). Hence it ends at \(b:D\), and switching the path gives the state-\(eb\) zero-port triple
\[
X_b=\{b:D,1A,2B,3C,4E\},                           \tag{3}
\]
with exactly the same complete shore matching as \(X_a\).

## Unique pure-half singleton-\(e\) exterior

Let \(Z_e\) be the singleton-\(e\) occurrence of a pure \(ea\) half. Since the shore restrictions of (2) and (3) coincide, purity requires one selected shore port to lead to \(c,d\) in opposite order against \((X_a,X_b)\). The nonterminal cross marks of \(Z_e\) have only these four disjoint orientations:
\[
I=(b:A,c:E,d:B),\quad II=(b:D,c:A,d:B),\quad
III=(b:D,c:A,d:E),\quad IV=(b:D,c:E,d:B).            \tag{4}
\]
The table covers every exterior matching: its “other \(K\)-edges” column lists all choices after the displayed mark halves are fixed. The last two columns record the ordered endpoints against \((X_a,X_b)\) at the port reached by \(c\) or \(d\), respectively, against \(X_a\). A row containing “or” represents both indicated \(K\)-choices with the same relevant endpoint pairs.

| Cross halves | \(a\)-half | Other \(K\)-edges | \(c\)-port pair | \(d\)-port pair |
|---|---|---|---|---|
| I | \(C\) | \(3D\) | \(h_4:(c,c)\) | \(h_2:(d,d)\) |
| I | \(C\) | \(4D\) | \(h_3:(c,a)\) | \(h_2:(d,d)\) |
| I | \(\Sigma\) | \(2C,3D\) | \(h_4:(c,c)\) | \(a:\Sigma:(d,a)\) |
| I | \(\Sigma\) | \(2C,4D\) | \(h_3:(c,d)\) | \(a:\Sigma:(d,a)\) |
| I | \(\Sigma\) | \(3C,4D\) | \(a:\Sigma:(c,a)\) | \(h_2:(d,d)\) |
| II | \(C\) | \(4E\) | \(h_1:(c,c)\) | \(h_2:(d,d)\) |
| II | \(\Sigma\) | \(2C,4E\) | \(h_1:(c,c)\) | \(a:\Sigma:(d,a)\) |
| II | \(\Sigma\) | \(3C,4E\) | \(h_1:(c,c)\) | \(h_2:(d,d)\) |
| III | \(C\) | \(1B\) | \(h_2:(c,c)\) | \(h_4:(d,d)\) |
| III | \(C\) | \(2B\) | \(h_1:(c,c)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(1B,2C\) | \(a:\Sigma:(c,a)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(1B,3C\) | \(h_2:(c,c)\) | \(h_4:(d,d)\) |
| III | \(\Sigma\) | \(2B,3C\) | \(h_1:(c,c)\) | \(h_4:(d,d)\) |
| IV | \(C\) | \(1A\) | \(h_4:(c,c)\) | \(h_2:(d,d)\) |
| IV | \(\Sigma\) | \(1A,2C\) | \(h_4:(c,c)\) | \(a:\Sigma:(d,a)\) |
| IV | \(\Sigma\) | \(1A,3C\) | \(h_4:(c,c)\) | \(h_2:(d,d)\) |

Only the fourth row has the required \((c,d)\) at one port. Its full singleton-\(e\) exterior is therefore
\[
\boxed{Z_e|_{\rm ext}=\{a:\Sigma,b:A,c:E,d:B,2C,4D,h_1,h_3\}.} \tag{5}
\]
The decisive \(h_3\)-route runs from \(u_3-D-u_4-E-t_c\) against (2), and from \(u_3-C-u_2-B-t_d\) against (3). Thus it has endpoints \((c,d)\) directly. In particular every pure-\(S\) \(ea\) half uses both \(c:E\) and \(2C\) in its singleton-\(e\) matching.

## A required cross-row overload

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ec)\) row, with \(ea\in S,ec\in T\). Its \(ea\) half is pure \(S\), so its singleton-\(e\) matching \(Z_e\) uses (5). The opposite state-\(ec\) half also has a singleton-\(e\) matching \(W_e\). Exchange these **complete** occurrences. The opposite \(T\)-state and total edge load remain unchanged, so the new \(ea\) half is pure \(S\); by the mask theorem, \(W_e\) also uses (5). Together they already load \(c:E\) and \(2C\) twice.

The opposite state-\(ec\) triple has boundary \(\{a,b,d\}\) and must select one half of the nonterminal mark \(c=AE\). The \(c:E\) half is saturated, so it selects \(c:A\). By [Note 230's zero-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), its exterior then contains the unique matching of \(K-A\), namely \(\{1B,2C,3D,4E\}\). This third use of \(2C\) contradicts edge load two. Reflection excludes \(ed\in S\) by the same argument. \(\square\)

By Notes 264–270, the only unexcluded \(|U|=r=4\) marked exterior is (1) with \(ea,ec\in S\). Larger barriers, the other Tutte profiles, and Berge–Fulkerson remain open. The route table is hand-derived and awaits independent checking.
