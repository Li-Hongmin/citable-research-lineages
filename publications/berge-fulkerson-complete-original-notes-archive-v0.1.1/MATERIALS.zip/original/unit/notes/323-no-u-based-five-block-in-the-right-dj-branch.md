> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No u-based five-block in the right DJ branch

Continue the real left and right exact-Case-XII rows in the
five-vertex Hall block (1) of [Note 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md).
Take \(\ell=b\), \(j=z\), \(H\) based at \(u\), and
\(Q\in\{A,I\}\) based at \(f\). This is the other local
placement left when \(\ell=b,j=z\). Full zero-port
matching closure in Note 321 supplies an actual
\((g,t_{ew})\) zero-port matching \(N\) with phase
\[
                    N:\quad bd_D,up,fy,ao,cz,
                         \quad x\text{ uses its third edge}.   \tag{1}
\]
Use [Note 301's complete-fibre rule](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
\(\sigma(L)=EI\mid AD\) for every actual
\(HJ,g,t_{ew}\) matching \(L\), and Note 321's
\(\sigma(N')=EA\mid ID\mid HJ\) for every actual
zero-port \((g,t_{ew})\) matching \(N'\).

**Theorem.** Every actual \(HJ,g,t_{ew}\) shore matching
in this placement uses \(bd_D\) and has the sole local
phase
\[
       L:\quad Hu,Jz,bd_D,ao,fp,cx,
                      \quad y\text{ uses its third edge}.      \tag{2}
\]
Thus the two left singleton-\(a\) occurrences \(Y_L,V_L\)
both use \(bd_D\) and have this same block phase. Their
complete shore matchings need not be equal. In fact the genuine
left four-port slot and right zero-port slot then contradict
[Note 302's forced route](302-the-right-zero-port-matching-forces-both-left-ad-opposite-fibres.md).
Hence this entire \((\ell,j,H)=(b,z,u)\) placement is
impossible for either \(Q=A\) or \(Q=I\). The reflected
exclusion holds with
\((a,b,o,y)\leftrightarrow(c,f,p,z)\).

**Proof.** If \(L\) avoids \(bd_D\), direct matching of
the four remaining \(S\)-vertices to \(T\setminus\{z\}\)
gives exactly
\[
 L_0:\quad Hu,Jz,bo,ax,fy,cp,
 \qquad
 L_1:\quad Hu,Jz,bo,ay,fp,cx.                          \tag{3}
\]
Their selected edges differ on the complete alternating
six-cycle \(a-x-c-p-f-y-a\). Hence actual matching closure
realizes \(L_0\) from either phase without changing
\(g,t_{ew}\). In \(L_0\triangle N\) the complete
\(H\)--\(J\) component is
\[
                           H-u-p-c-z-J.                      \tag{4}
\]
Switching it in \(L_0\) yields the genuine zero-port
matching \(\{up,bo,ax,fy,cz\}\) on all five
\(S\)-vertices. It avoids \(bd_D\), contradicting
Note 321. Thus neither phase in (3) occurs.

If \(L\) uses \(bd_D\), the two local phases are (2) and
\[
       L_d:\quad Hu,Jz,bd_D,ao,cp,fy,
                       \quad x\text{ uses its third edge}.    \tag{5}
\]
The complete \(H\)--\(J\) component of \(L_d\triangle N\)
is again (4). Switching it in \(L_d\) gives an actual
zero-port matching \(N_d\) with the local phase (1),
and leaves every shore edge outside this component
unchanged, including \(g,t_{ew}\).

In the complement of \(L_d\), the port \(Q\) reaches
the unselected third edge at \(y\) through
\[
                  Q-f-p-u-o-b-z-c-x-a-y.                     \tag{6}
\]
In the complement of \(N_d\), it reaches the same
edge through \(Q-f-p-c-x-a-y\). The remaining shore
continuation from that edge is unchanged by the switch.
For \(Q=A\), Note 301 requires the continuation to end
at \(D\), whereas Note 321 requires it to end at \(E\).
For \(Q=I\), the required ends are \(E,D\), respectively.
Thus \(L_d\) is impossible and only (2) remains.
\(\square\)

## The left four-port slot contradicts the right zero-port slot

Both left singleton-\(a\) slots \(Y_L,V_L\) select the
block edges \(bd_D,ao,fp,cx\) of (2), so each of these
edges has full load two. At the proper port \(Q=f\),
the left-row slots are \(ZU\) if \(Q=A\) and \(ZW\)
if \(Q=I\). Therefore \(fy\) has slots \(XW\) or
\(XU\), respectively. At \(y\), its third edge has
slots \(YV\), so \(ay\) has slots \(ZU\) or \(ZW\),
respectively. Thus the left four-port slot \(Z_L(EAID)\)
selects \(ay\). At \(a\), \(ao:YV\), so \(ax\)
contains slot \(X_L\). At \(x\), \(cx:YV\), so the
third edge at \(x\) contains slot \(Z_L\).

The \(Z_L\) slot also selects the \(Q\)-port at \(f\)
and the \(D\)-port at \(d_D\), while avoiding \(H,J\).
Its remaining vertices \(u,b,c\) must match
\(o,p,z\). The only possibilities are
\[
\begin{aligned}
Z_1&:\quad Qf,Dd_D,ay,uo,bz,cp,
                  \quad x\text{ uses its third edge},\\
Z_2&:\quad Qf,Dd_D,ay,up,bo,cz,
                  \quad x\text{ uses its third edge}.
\end{aligned}                                                   \tag{7}
\]

By [Note 321's complete zero-port phase table](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md),
the right row's actual zero-port slot \(X_R(g,t_{ew})\)
is one of
\[
\begin{aligned}
X_0&:\quad bd_D,uo,fp,ay,cz,
                  \quad x\text{ uses its third edge},\\
X_1&:\quad bd_D,up,fy,ao,cz,
                  \quad x\text{ uses its third edge}.
\end{aligned}                                                   \tag{8}
\]
Each combination has the indicated complete alternating
component of \(X_R\triangle Z_L\):
\[
\begin{array}{c|cc}
 &Z_1&Z_2\\\hline
X_0&D-d_D-b-z-c-p-f-Q&D-d_D-b-o-u-p-f-Q\\
X_1&D-d_D-b-z-c-p-u-o-a-y-f-Q&D-d_D-b-o-a-y-f-Q.
\end{array}                                                   \tag{9}
\]
All edges in each displayed path alternate between the two
actual matchings, and the path is complete at the port
ends \(D,Q\). Note 302 forces the shore paths of this
same \(X_R\triangle Z_L\) to pair \(ED\mid AI\).
Neither \(DA\) nor \(DI\) is allowed, so all four
combinations contradict Note 302. This excludes the
placement for both choices of \(Q\); reflection excludes
its mirror. \(\square\)

The companion [Note 322](322-the-remaining-f-based-five-block-fixes-the-left-hj-phase.md)
fixes the other \(H=f\) placement and forces its second port
to be \(I\), but does not exclude it. All \(\ell=u\) placements, the other six-cut
allocation, larger Hall blocks, other core profiles, and
Berge–Fulkerson remain open. The proof is hand-derived and
awaits independent second-source checking. No local
computation or OMEN run was used.
