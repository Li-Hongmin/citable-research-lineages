> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every singleton-\(a\) matching hits the right bridge's \(d,e\) pair

> **Scope correction:** [Note 230, (1)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) already forbids every all-terminal perfect matching in this deficient-core profile. The exterior hitting lemma remains valid; its application to an all-terminal cover below is a local identity statement, not a new Case-XII exclusion. The specified \(AJ\) bridge is conditional on the no-\(c\) row excluded in [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md).

Use only the marked central-path exterior of [Note 271, (1)](271-the-central-path-row-requires-two-distinct-shore-masks.md). Write \(I=h_1\) for its first proper shore port edge. No Case-XII support, BF row, shore order, or shore matching is needed for the first assertion.

**Exterior hitting lemma.** Every complete singleton-\(a\) perfect matching \(M_a\) of this five-pole selects at least one of the two proper edges
\[
                              b:D,\qquad I=h_1.           \tag{1}
\]

**Proof.** Suppose \(M_a\) avoids both. Since it selects terminal \(a\) but no other terminal, the marked \(b\)-vertex must use \(b:A\). This covers the exterior vertex \(A_{\rm ext}\), so neither \(1A\) nor \(c:A\) is available. The path vertex \(u_1\) has incident edges \(1A,1B,h_1\); the first and third are unavailable, forcing \(1B\). This covers \(B_{\rm ext}\), so the marked \(d\)-vertex cannot use \(d:B\) and must use \(d:E\). Now \(E_{\rm ext}\) is covered, making \(c:E\) unavailable, while \(c:A\) was already unavailable. The nonterminal marked \(c\)-vertex cannot be matched, a contradiction. \(\square\)

The lemma sharpens the two-carrier obstruction of [Note 351](351-the-right-aj-bridge-forces-an-a-d-e-triple-hit-at-i.md). When that note's third-identity gate succeeds, its singleton-\(d\) matching \(D_d\) has exterior mask
\[
       D_d|_{\rm ext}=\{a:C,b:D,c:A,2B,4E,h_1,h_3;\ d\},
\]
and the shared singleton-\(e\) matching \(V_e\) has III \(a:\Sigma,2B,3C\), whose exterior includes **both** \(b:D\) and \(h_1\). Therefore
\[
              \{b:D,h_1\}\subseteq D_d\cap V_e.            \tag{2}
\]
By (1), **every** singleton-\(a\) matching, from any carrier and any boundary cell, triple-hits at least one edge of (2) together with \(D_d,V_e\). Thus no five-singleton all-terminal \(A\)-cover can retain both complete identities \(D_d,V_e\), regardless of which singleton-\(a\), singleton-\(b\), or singleton-\(c\) matchings are chosen. In particular, replacing only the \(a\)-matching in Note 351 cannot repair its cover obstruction. With \(V_e\) retained, a successful all-terminal cover would have to replace \(D_d\); with \(D_d\) retained, it would have to replace \(V_e\).

The same obstruction holds if \(V_e\) is replaced by **any** singleton-\(e\) matching from an \(ea\)-decomposition of Note 351's fixed pure load \(\widetilde P=X_C+Y_R+V_e\). This load has zero at shore port \(H\) and two at \(I\). [Note 271's pure-side theorem](271-the-central-path-row-requires-two-distinct-shore-masks.md) permits only \(Y_L\) with ports \(H,J\) or \(Y_R\) with ports \(I,D\) for its singleton-\(a\) slot, so every such decomposition uses the right mask \(Y_R\). Its \(ea\)-triple is zero-port and selects terminal \(b\); hence the load-one marked edges \(b:A,b:D\) are split between the \(a,e\) singletons. The right \(a\)-mask uses \(b:A\), forcing the \(e\)-matching to use \(b:D\). The port load two at \(I\) makes both singleton slots use \(h_1\). Thus every such \(e\)-matching still contains both edges in (2). Repairing the \(D_d\)-pair through a new \(e\)-identity requires leaving this fixed \(ea\)-carrier; alternatively one must replace \(D_d\).

This proves a precise **identity-level boundary** for the specific right \(AJ\) bridge. It neither forbids its two actual Case-XII rows nor excludes a different \(d\)- or \(e\)-matching elsewhere in the complete family. The full exact Case-XII and Berge–Fulkerson questions remain open.
