> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central--rim \(e\)-neighbour placement is impossible in the two-vertex connector

Use [Note 204's](204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md) genuine two-vertex, one-five-cut connector and the labels of [Note 205](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md): the unmarked exterior path is \(w_1-u_1-w_0-u_2-w_2\), \(a\) joins \(w_0\) to the shore, \(b,c\) join \(w_1,w_2\) to the shore, \(f\) joins \(w_1,w_2\), and \(e\) lies within the shore.

**Theorem.** Complete exact Case-XII support is impossible when the two neighbours of \(e\) in its allowed missing-pair pentagon \(S\) are \(a\) and \(f\). By reflecting the exterior path, the only relative placement to check is
\[
S=e-a-b-c-f-e,
\qquad T=\{eb,ec,ac,af,bf\}.                       \tag{1}
\]
This excludes a placement of the two-vertex connector at every order. It does not exclude the other placements or require uniqueness of any shore deletion matching.

**The saturated half.** Choose any required actual \(S\)--\(T\) BF row, and let \(A\) be its \(S\)-half. Exact negative support and [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) give \(\mathcal R(A)=S\). Decompose its same full load at state \(ea\):
\[
A=X+Y+Z,qquad
\partial X=\{b,c,f\},\quad \partial Y=\{a\},\quad\partial Z=\{e\}.
\]
By Note 205, the triple \(X\) selects the exterior endpoint \(w_0\) of \(a\), and its other exterior edges are \(u_1w_1,u_2w_2\). Its one exposed shore endpoint is selected through \(e\).

The terminal-\(a\) component of \(X\triangle Y\) begins at \(w_0\). Since \(Y\) has terminal \(a\), it must match \(w_0\) by either \(u_1w_0\) or \(u_2w_0\). In the first case the alternating path next reaches \(w_1\), where \(Y\) must choose either the \(b\)-half or the \(f\)-half. The \(b\)-choice would end at terminal \(b\), switching state \(ea\) to forbidden \(eb\); hence \(Y\) chooses \(f\). The second case reaches \(w_2\), where the \(c\)-choice would give forbidden \(ec\), so again \(Y\) chooses \(f\). Thus the forced path is wholly exterior and joins terminals \(a,f\). Switching \(X,Y\) along it gives a triple \(X'\) at state \(ef\) while
\[
X'|_C=X|_C,qquad Z\text{ is unchanged}.             \tag{2}
\]
The two exterior possibilities for \(X'\) are \(f:w_1\) with path matching \(u_1w_0,u_2w_2\), called \(L\), and \(f:w_2\) with \(u_1w_1,u_2w_0\), called \(R\).

**The fixed-shore pairing test.** The singleton-\(e\) matching \(Z\) uses the \(e\)-terminal and therefore selects one of \(w_1,w_2\) through \(f\). Every one of its exterior routes has three ports on \(C\). Write \(h_i\) for the port \(u_iv_i\), and write \(a,b,c\) for the shore-side halves of those marks. The table lists all routes. In its last three columns, \(b_0\) is the shore port reached from terminal \(b\) in the exterior of \(X\triangle Z\); \(c_L,c_R\) are the shore ports reached from terminal \(c\) in the exterior of \(X'_L\triangle Z\) and \(X'_R\triangle Z\). Each of these symmetric differences has three separate exterior terminal-to-port paths, plus the direct \(e\)-terminal-to-\(e\)-port path; any remaining exterior components are closed cycles.
\[
\begin{array}{c|c|c|c|c|c}
Z\text{ route}&Z\text{ shore ports}&Z\text{ other exterior choices}&b_0&c_L&c_R\\\hline
L0& a,b,c       & f:w_1,\ u_1w_0,u_2w_2&b&c&c\\
L1& a,b,h_1     & f:w_1,\ c:w_2,\ h_1,u_2w_0&b&h_1&h_1\\
L2& a,b,h_2     & f:w_1,\ c:w_2,\ h_2,u_1w_0&b&h_2&h_2\\
L3& b,c,h_1     & f:w_1,\ a:w_0,\ h_1,u_2w_2&b&c&c\\
L4& b,h_1,h_2   & f:w_1,\ a:w_0,\ c:w_2,\ h_1,h_2&b&h_2&h_1\\
R0& a,b,c       & f:w_2,\ u_1w_1,u_2w_0&b&c&c\\
R1& a,c,h_1     & f:w_2,\ b:w_1,\ h_1,u_2w_0&h_1&c&c\\
R2& a,c,h_2     & f:w_2,\ b:w_1,\ h_2,u_1w_0&a&c&c\\
R3& b,c,h_2     & f:w_2,\ a:w_0,\ h_2,u_1w_1&b&c&c\\
R4& c,h_1,h_2   & f:w_2,\ a:w_0,\ b:w_1,\ h_1,h_2&h_1&c&c.
\end{array}                                                     \tag{3}
\]
For example, in route \(R2\), the exterior \(b\)-path of \(X\triangle Z\) is \(b-w_1-u_1-w_0-a\), whereas in route \(L4\) the exterior \(c\)-path of \(X'_R\triangle Z\) runs \(c-w_2-t_f-w_1-u_1-h_1\). The table follows by matching the remaining vertices of the path after the selected mark endpoints; it uses complete perfect matchings, not formal port labels. In every row \(b_0\ne c_L,c_R\), with distinct **port edges** even if two ports have the same endpoint in \(C\).

The restriction to \(C\) of \(X\triangle Z\) equals that of \(X'\triangle Z\) by (2), so its four shore ports have one fixed alternating pairing. In state \(ea\), the alternating path from terminal \(e\) in \(X\triangle Z\) must end at \(b\): otherwise switching it gives a missing pair outside \(S\). Thus its \(e\)-port is paired with \(b_0\). In state \(ef\), that path in \(X'\triangle Z\) must end at \(c\), so the same \(e\)-port is paired with \(c_L\) or \(c_R\). This contradicts every row of (3), proving the theorem. \(\square\)

The argument needs only one saturated \(S\)-carrier, obtained from an actual required \(S\)--\(T\) row. It leaves the remaining three relative choices for the neighbour pair of \(e\), as well as their possible cyclic orders, for further full-matching analysis.
