> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Kempe transport around the Case-XII pentagon

This note depends on [the matching-holonomy formulation](001-pentagon-selection-as-matching-holonomy.md).

## Canonical transport between adjacent relations

Write the complementary pentagon cyclically as

\[
v_0v_1v_2v_3v_4v_0=1,4,2,5,3,1
\]

and let `E_t=R_{v_t v_{t+1}}`. Assume the complete set of Tait lonely-pair states is exactly the five edges of this pentagon.

Take `(P,Q) in E_t`, and let `C` be the third perfect matching complementary to `P union Q`. In the alternating subgraph `P union C`, the path starting at semiedge `v_t` ends at a boundary position `z` belonging to `C`. Switching `P` and `C` on this component leaves `Q` fixed and produces lonely pair `{v_{t+1},z}`. This pair must again be an edge of the complementary pentagon. Since `z` differs from `v_t` and `v_{t+1}`, necessarily `z=v_{t+2}`.

The switch therefore defines

\[
f_t:E_t\longrightarrow E_{t+1},\qquad (P,Q)\longmapsto(Q,P').
\]

Switching back on the same alternating component is its inverse, so `f_t` is a bijection. In particular,

\[
|R_{14}|=|R_{42}|=|R_{25}|=|R_{53}|=|R_{31}|.
\]

Thus the equal relation-size vectors observed computationally are forced at every order.

If this common cardinality is one, the five unique relation edges share their intermediate matchings and form a compatible pentagon. Hence every Case-XII obstruction must have common relation size at least two. For larger cardinality the canonical Kempe transports define a composite

\[
h=f_4f_3f_2f_1f_0:E_0\to E_0
\]

which is a permutation. A fixed point of this particular `h` produces a compatible pentagon, but the converse is false: a compatible pentagon may use relation edges not selected by the canonical transports. Pentagon-selection remains the multivalued relation condition in Note 001, not a fixed-point assertion for this single permutation.

## Complete order-eleven verification

Under the hypotheses that the proper graph is simple and connected and the five semiedges have distinct incident vertices, the [order-eleven computation bundle](../computations/bundles/case-xii-order-11/README.md) exhausts all poles with eleven internal vertices.

Adding an apex adjacent to the five boundary vertices converts such a pole into a simple graph with degree sequence `(5,3^11)` and connected apex deletion; deleting the unique degree-five vertex is the inverse construction. Unlabelled generation and subsequent boundary labeling give the filtration

\[
4291\longrightarrow581\longrightarrow536\longrightarrow6432
\longrightarrow41\longrightarrow41.
\]

The last two numbers are the branches whose complete Tait state set is the complementary pentagon and those possessing a compatible pentagon, respectively. A separate run over all `536*120=64,320` boundary labelings retains 410 branches and verifies all 410, eliminating reliance on the `D_5` quotient representatives.

Consequently, within the stated structural class, a Case-XII pole has at least thirteen internal vertices. Among the 41 quotient branches, 15 have common relation size one and are already covered by the general transport theorem. For the other branches the canonical `h` has cycle types `(1,1)`, `(2)`, `(2,2)`, `(3)`, and `(4)`; 19 branches have no canonical fixed point although every branch has a compatible pentagon. These examples separate canonical Kempe transport from the existential multivalued holonomy problem.

## Remaining boundary

Neither the transport theorem nor the finite verification proves arbitrary-order Pentagon-selection. The finite examples rule out the strategy of proving it through a fixed point, involutivity, sign, or restricted cycle type of the canonical permutation `h`. The remaining object is the full layered compatibility graph: one must prove that it contains some lifted 5-cycle, or construct a real 5-pole whose layered graph has only longer lifts.
