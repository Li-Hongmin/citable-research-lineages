> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last five Hamilton port profiles force a forbidden double-triple

Let the Hamilton three-spoke exterior be
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,\qquad
(X,Y,Z,W)=(14,15,26,36),
\]
with sixth, possibly large, shore terminal \(e\). Name six **complete** matching occurrences \(P,R,K,J,a,b\), where \(a,b\) are the two singleton-\(e\) occurrences in an old \((eX)(eY)\) row. Keep each occurrence's entire old shore restriction. The only data needed below are its shore terminal pair \(e=ab\) and its five labelled proper-port pairs.

**Five-profile closure theorem.** Each of the five genuinely realizable residual port profiles of [Note 456(2)](456-five-residual-hamilton-port-profiles-have-real-bf-rows.md) admits a new exterior BF row of forbidden type \((eX)(eW)\) with exactly those six unchanged complete shore restrictions. In the new row
\[
P=eX,\qquad R=eW,\qquad K=X,\qquad J=W,\qquad
\operatorname{state}(a)=\operatorname{state}(b)=e
\]
as boundary *states* (the occurrence labels \(a,b\) remain distinct). In particular, the five profiles cannot occur in any pole whose **complete** BF support omits \((eX)(eW)\).

At a tree subdivision, each triple lists first-end half, second-end half, proper port. At a marked subdivision, each lists terminal, first-end half, second-end half in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\).

## The two \(U\) profiles

Write \(\{c,d\}=\{a,b\}\). Both profiles have the common form
\[
(p_1,p_2,p_3,p_4,p_5)=(Jd,Ka,Kb,ab,Jc),\qquad e=ab.
\tag{1}
\]
The choices \((c,d)=(a,b)\) and \((b,a)\) are \(U_1,U_2\), respectively. Use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(Rc,PK,Jd)&(RJ,Pb,Ka)&(Ja,PR,Kb)
 &(KJ,PR,ab)&(Kd,PR,Jc)
\end{array}
\tag{2}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RK,PJ,ab)&(PR,Kd,Jc)&(PR,ab,KJ)&(PJ,RK,ab).
\end{array}
\tag{3}
\]
The original vertices \(1,\ldots,6\) see
\[
(Rc,PJ,Kd),\quad(PK,RJ,ab),\quad
(Pb,Ja,RK),\quad(PR,KJ,ab),\quad
(PR,Kd,Jc),\quad(PR,KJ,ab).
\tag{4}
\]
Every triple in (2)--(4) partitions \(\{P,R,K,J,a,b\}\).

## The two \(S\) profiles

Write \(\{x,y\}=\{a,b\}\). Their common form is
\[
(p_1,p_2,p_3,p_4,p_5)=(Jy,Kx,ab,Kb,Ja),\qquad e=ab.
\tag{5}
\]
The choices \((x,y)=(a,b)\) and \((b,a)\) are \(S_1,S_2\). Use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RK,Px,Jy)&(RJ,Py,Kx)&(RJ,PK,ab)
 &(RJ,Pa,Kb)&(Rb,PK,Ja)
\end{array}
\tag{6}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RK,PJ,ab)&(PR,ab,KJ)&(PR,Ky,Jx)&(PJ,Kx,Ry).
\end{array}
\tag{7}
\]
The original vertices see
\[
(RK,PJ,ab),\quad(Px,RJ,Ky),\quad
(Py,RJ,Kx),\quad(PK,RJ,ab),\quad
(Pa,Rb,KJ),\quad(PK,Jx,Ry).
\tag{8}
\]
Again every triple in (6)--(8) partitions the six occurrence labels.

## The \(T\) profile

Here
\[
(p_1,p_2,p_3,p_4,p_5)=(Ja,Kb,Kb,ab,Ja),\qquad e=ab.
\tag{9}
\]
Use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RK,Pb,Ja)&(RJ,Pa,Kb)&(RJ,Pa,Kb)
 &(RK,PJ,ab)&(Rb,PK,Ja)
\end{array}
\tag{10}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RK,Pa,Jb)&(PR,Jb,Ka)&(PR,Ka,Jb)&(PJ,Kb,Ra).
\end{array}
\tag{11}
\]
The original vertices see
\[
(RK,Pa,Jb),\quad(Pb,RJ,Ka),\quad
(Pa,RJ,Kb),\quad(Pa,RK,Jb),\quad
(PJ,Rb,Ka),\quad(PK,Jb,Ra).
\tag{12}
\]
Each triple is a partition.

In all three templates, the proper-port column is the old profile and terminal \(e\) remains \(ab\). Every exterior edge has load two because both its endpoint partitions give the same displayed pair; each of the six new exterior restrictions is a matching because it selects one edge at every exterior vertex. Gluing occurrence by occurrence to its **unchanged, possibly different complete shore matching** therefore gives a genuine six-matching BF row in the *same* five-pole. The terminal pairs in every template are \(X=RK,Y=PR,Z=PR,W=PJ,e=ab\). Consequently \(P,R\) are zero-port triples \(eX,eW\), \(K,J\) are singleton \(X,W\), and the row type is \((eX)(eW)\). This type is absent from published exact Case XII for either pentagon orientation with forbidden pair \(\{eX,eW\}\).

Combining [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md), [Notes 447--450](450-the-direct-y-to-z-hamilton-signature-forces-a-forbidden-row.md), [451](451-two-end-port-phases-force-forbidden-rows-in-the-hamilton-prism.md), [453](453-the-crossed-hamilton-port-row-forces-a-forbidden-loop.md), [454](454-fifth-line-hamilton-rows-leave-two-labelled-port-phases.md), and [455](455-sixth-line-hamilton-rows-leave-four-labelled-port-profiles.md) with the five templates above gives a support law without assuming exact Case XII: **any** genuine \((eX)(eY)\) BF row on this marked exterior forces at least one of \([eX]\), \([eW]\), or \((eX)(eW)\) in the complete BF support. Indeed, the \(Y\)-starting \(R\triangle K\) path ending at \(X\) or \(W\) directly yields \([eX]\) or \((eX)(eW)\); otherwise it ends at \(Z\), where Note 446's twelve-signature classification applies. The cited notes and the present templates give one of the three target types for every signature. Published exact Case XII with forbidden pair \(\{eX,eW\}\) omits all three, so no cubic five-pole with this marked Hamilton three-spoke exterior has that complete support, at any shore order or topology. This conclusion depends on the full hand-derived certificate chain and awaits independent review. It excludes one forbidden pair for one exterior; the other forbidden pairs, other exterior profiles, the full exact-Case-XII obstruction, and Berge--Fulkerson remain open. No OMEN or local mathematical recomputation was used. \(\square\)
