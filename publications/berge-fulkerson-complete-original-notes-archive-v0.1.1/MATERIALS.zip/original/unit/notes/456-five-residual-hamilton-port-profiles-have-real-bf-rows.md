> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five residual Hamilton port profiles have real BF rows

The residual \((eX)(eY)\) port profiles in [Notes 454(22)](454-fifth-line-hamilton-rows-leave-two-labelled-port-phases.md) and [455(12)](455-sixth-line-hamilton-rows-leave-four-labelled-port-profiles.md) are all realized by genuine six-complete-matching BF rows on simple cubic five-poles. One profile appears in both notes, so there are five distinct labelled port profiles after renaming the two singleton-\(e\) occurrences \(a,b\). This is a sharp boundary for attempts to discard them by exterior or shore row feasibility alone. Every example below also has \([eX]\) in its **complete** support and is therefore outside exact Case XII.

## Uniform 21-vertex construction

Use the Hamilton three-spoke exterior \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) with marked subdivisions \(t_X,t_Y,t_Z,t_W\) on \((X,Y,Z,W)=(14,15,26,36)\). The terminal semiedges at the four marked subdivisions carry \(X,Y,Z,W\). Add six shore vertices \(q_e,q_1,\ldots,q_5\), join \(q_i\) to \(u_i\), attach terminal \(e\) at \(q_e\), and join the shore vertices in one six-cycle specified below. This makes a simple connected cubic five-pole of order \(6+5+4+6=21\). Every exterior prism edge is subdivided, the shore is a six-cycle, and a mixed cycle uses two proper port edges, so the girth is at least five.

As before name the complete occurrences
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad a=e,\quad b=e.
\tag{1}
\]
The five profiles and their old exterior choices are
\[
\begin{array}{c|ccccc|c}
 &p_1&p_2&p_3&p_4&p_5&\text{exterior below}\\ \hline
U_1&Jb&Ka&Kb&ab&Ja&A(b)\\
U_2&Ja&Ka&Kb&ab&Jb&A(a)\\
S_1&Jb&Ka&ab&Kb&Ja&B(a)\\
S_2&Ja&Kb&ab&Kb&Ja&B(b)\\
T  &Ja&Kb&Kb&ab&Ja&C
\end{array},\qquad e=ab.
\tag{2}
\]
Here \(A(\eta)\) means \(\eta=b\) for \(U_1\) and \(\eta=a\) for \(U_2\), with \(\delta\) the other \(e\)-singleton. \(B(\beta)\) has \(\beta=a\) or \(b\). At a tree subdivision the entries below are first-end half, second-end half, port; at a marked subdivision they are terminal and two halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\).

For \(A(\eta)\), put \(\{\delta,\eta\}=\{a,b\}\). Its exterior pairs are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(R\delta,PK,\{J,\eta\})
 &(RJ,Pb,Ka)&(Ra,PJ,Kb)&(RK,PJ,ab)&(K\eta,PR,J\delta)
\end{array}
\tag{3}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RJ,PK,ab)&(PK,\{J,\eta\},R\delta)
 &(PR,ab,KJ)&(PR,KJ,ab).
\end{array}
\tag{4}
\]
For \(B(\beta)\), where \(\beta\in\{a,b\}\), use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(PR,K\beta,\Lambda\setminus\{\beta\})
 &(PR,\Lambda\setminus\{\beta\},K\beta)
 &(PR,KJ,ab)&(Ra,PJ,Kb)&(Kb,PR,Ja)
\end{array}
\tag{5}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RJ,Ka,Pb)&(PK,Jb,Ra)
 &(PR,\Lambda\setminus\{\beta\},K\beta)
 &(PR,K\beta,\Lambda\setminus\{\beta\}),
\end{array}
\qquad\Lambda=\{J,a,b\}.
\tag{6}
\]
For \(C\), use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(PR,Kb,Ja)&(PR,Ja,Kb)&(PR,Ja,Kb)
 &(RK,PJ,ab)&(Kb,PR,Ja)
\end{array}
\tag{7}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RJ,Ka,Pb)&(PK,Jb,Ra)&(PR,Ja,Kb)&(PR,Kb,Ja).
\end{array}
\tag{8}
\]
Each displayed subdivision triple is a partition of \(\{P,R,K,J,a,b\}\). At each of the six original prism vertices, the three incident pairs also partition this set: for (3)--(4), these are
\[
(R\delta,PK,\{J,\eta\}),\quad(PK,RJ,ab),\quad
(Pb,Ra,KJ),\quad(PJ,RK,ab),\quad
(PJ,K\eta,R\delta),\quad(PR,KJ,ab);
\tag{9}
\]
for (5)--(6), they are
\[
(PR,Ka,Jb),\quad
(K\beta,PR,\Lambda\setminus\{\beta\}),\quad
(\Lambda\setminus\{\beta\},PR,K\beta),\quad
(KJ,Ra,Pb),\quad(PJ,Kb,Ra),\quad
(PR,K\beta,\Lambda\setminus\{\beta\});
\tag{10}
\]
and for (7)--(8), they are
\[
(PR,Ka,Jb),\quad(Kb,PR,Ja),\quad(Ja,PR,Kb),\quad
(Ja,RK,Pb),\quad(PJ,Kb,Ra),\quad(PR,Kb,Ja).
\tag{11}
\]

The six-cycle shore and its edge pairs complete the construction. In each row of the following table, the six displayed cycle-edge pairs follow the six shore vertices in cyclic order, and the final edge closes back to the first. Thus \(P\) occupies edges \(1,3,5\), \(R\) occupies edges \(2,4,6\), and every shore vertex sees its displayed port pair from (2) plus two cycle-edge pairs partitioning all six labels:
\[
\begin{array}{c|l|l}
 &\text{cyclic shore vertices}&\text{successive edge pairs}\\ \hline
U_1&q_1,q_3,q_e,q_5,q_2,q_4&Pa,\ RJ,\ PK,\ Rb,\ PJ,\ RK\\
U_2&q_1,q_2,q_3,q_5,q_e,q_4&Pb,\ RJ,\ Pa,\ RK,\ PJ,\ RK\\
S_1&q_1,q_4,q_2,q_5,q_3,q_e&Pa,\ RJ,\ Pb,\ RK,\ PJ,\ RK\\
S_2&q_1,q_5,q_3,q_2,q_4,q_e&Pb,\ RK,\ PJ,\ Ra,\ PJ,\ RK\\
T  &q_1,q_5,q_4,q_2,q_3,q_e&Pb,\ RK,\ PJ,\ Ra,\ PJ,\ RK
\end{array}
\tag{12}
\]
Equations (2)--(12) specify six **complete** matchings in every five-pole and show that every edge has load two. The terminal pairs \(e=ab\) and \(X,Y,Z,W=(RJ,PK,PR,PR)\) give the required \((eX)(eY)\) BF type.

## Direct complete-support obstruction

Let \(Q_P\) be \(P\)'s complete zero-port shore matching, namely the first, third, and fifth edges of its six-cycle. The three components of the shore complement pair the ports as follows. The last column chooses one of the two exterior zero-port \(eX\)-triple roots from [Note 359](359-two-root-parity-gate-and-k33-sharpness.md):
\[
\begin{array}{c|l|c}
 &\text{shore complement pairing}&X\text{ root}\\ \hline
U_1&ep_3\mid p_5p_2\mid p_4p_1&1\\
U_2&ep_5\mid p_2p_3\mid p_4p_1&4\\
S_1&ep_1\mid p_4p_2\mid p_5p_3&1\\
S_2&ep_1\mid p_5p_3\mid p_2p_4&1\\
T  &ep_1\mid p_5p_4\mid p_2p_3&4
\end{array}
\tag{13}
\]
For root \(1\), the exterior pairing is \(Xp_4\mid p_1p_5\mid p_2p_3\); for root \(4\), it is \(Xp_5\mid p_1p_2\mid p_3p_4\). In \(U_1,S_1,S_2,T\), the union with (13) is a single open \(e\)--\(X\) route. In \(U_2\), it has the open \(e\)--\(X\) route plus one closed component containing two shore paths. Each shore path here has three edges including its port semiedges, while every exterior complement path and pure exterior cycle has even length by Note 359. Hence that closed component is even as well. There is no closed shore component. Alternating the full complement therefore yields a genuine Tait colouring and, by doubling its three matchings, a BF loop \([eX]\) in each **complete** support.

Thus all five port profiles are genuine row boundaries, yet none of these five 21-vertex poles has exact-Case-XII support. The result does not decide whether a different, irreducible shore can carry one of the profiles while omitting all forbidden support. It is a hand-derived certificate awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 457](457-the-last-five-hamilton-port-profiles-force-a-forbidden-double-triple.md) resolves the last question for these five profiles: every genuine row of any of the five port forms forces the forbidden \((eX)(eW)\) type while preserving the row's six complete shore restrictions.
