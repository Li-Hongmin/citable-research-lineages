> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(B_2\) row forces a forbidden double triple

Continue the fixed marked Hamilton exterior and matching names of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In signature \(B_2\), the genuine old \((eX)(eY)\) row has \(P=eX\) rooted at \(X:1\), \(R=eY\) rooted at \(Y:5\), and \(K=Y\) on marked halves \(X:1,Z:6,W:3\), tree halves \(2u_2,4u_3,5u_4\), and proper ports \(p_1,p_5\). We show that **every** such row, at every shore order and topology, admits a forbidden \((eX)(eZ)\) recompletion while retaining all six complete shore matching restrictions separately.

Put \(S=\{J,a,b\}\). The old exterior pair partitions force its proper-port pairs to be
\[
\boxed{(p_1,p_2,p_3,p_4,p_5)
=\bigl(K\alpha,S\setminus\{\delta\},S\setminus\{\epsilon\},ab,K\gamma\bigr),
\quad \{\alpha,\beta,\gamma\}=S,
\quad \{\beta,\delta,\epsilon\}=S.}                         \tag{1}
\]
All letters in either three-element brace are distinct. In particular \(\{\alpha,\gamma\}=\{\delta,\epsilon\}\), but their two orders are independent. The terminal \(e\) has pair \(ab\).

Here is a direct derivation of (1). The old marked \(X\) pairs are \((RJ,PK,ab)\). Write the two halves at \(u_1\) as \((R\gamma,P\beta)\); since \(K\) uses port \(p_1\), its pair is \(K\alpha\), with \(\{\alpha,\beta,\gamma\}=S\). Original vertex \(1\) and marked \(Y\) then give \(Y:5=R\gamma\). At vertex \(2\), the old halves \(u_1:2=P\beta\), \(u_2:2=RK\) force \(Z:2=S\setminus\{\beta\}\), hence \(Z:6=K\beta\) and \(W:3=K\beta\). Write \(u_2:3=P\delta\), \(u_3:3=R\epsilon\); original vertex \(3\) requires \(\{\beta,\delta,\epsilon\}=S\). The pairs at \(u_2,u_3\) then give the second and third ports in (1). Original vertex \(4\) fixes \(u_4\)'s halves as \((RJ,PK)\), hence \(p_4=ab\). At vertex \(5\), the old \(u_4:5=PK\) and \(Y:5=R\gamma\) force \(u_5:5=S\setminus\{\gamma\}\); with \(u_5:6=PR\), its port is \(K\gamma\). No property of the internal shore matching graph enters this derivation.

For every choice in (1), leave the pair on each shore edge and port unchanged. Reassign only the exterior pairs, listing first tree half, second tree half, then proper port at \(u_i\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(R\gamma,P\beta,K\alpha)
&(K\delta,PR,S\setminus\{\delta\})
&(K\epsilon,PR,S\setminus\{\epsilon\})
&(KJ,PR,ab)
&(S\setminus\{\gamma\},PR,K\gamma)
\end{array}                                                    \tag{2}
\]
At marked subdivisions, list terminal and the two halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\):
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,PK,ab)&(PR,S\setminus\{\gamma\},K\gamma)&
(PK,R\epsilon,S\setminus\{\epsilon\})&
(PR,S\setminus\{\epsilon\},K\epsilon).
\end{array}                                                    \tag{3}
\]
The six original vertices see, respectively,
\[
(R\gamma,PK,S\setminus\{\gamma\}),\quad
(P\beta,K\delta,R\epsilon),\quad
(PR,K\epsilon,S\setminus\{\epsilon\}),\quad
(PR,ab,KJ),\quad
(PR,S\setminus\{\gamma\},K\gamma),\quad
(PR,S\setminus\{\epsilon\},K\epsilon).                 \tag{4}
\]
Each triple in (2)--(4) partitions \(\{P,R,K,J,a,b\}\): at \(u_1\) and original vertex \(2\) this uses the two brace conditions in (1), and elsewhere each two-set is paired with its complement in \(\{K,J,a,b\}\). The port column in (2) equals (1), so the original six **complete** shore restrictions glue unchanged. The new terminal pairs are
\[
e=ab,\qquad X=RJ,\qquad Z=PK,\qquad Y=W=PR,              \tag{5}
\]
the forbidden \((eX)(eZ)\) type for either Case-XII pentagon orientation with forbidden \(\{eX,eZ\}\). Thus signature \(B_2\) cannot occur in a genuine exact-Case-XII pole with this marked exterior.

Together with [Note 467](467-the-x-z-hamilton-b1-row-forces-a-forbidden-ex-loop.md), only \(B_3,C_1,\ldots,C_7\) remain among the twelve necessary signatures of Note 466. Reflection gives the corresponding conclusion for forbidden \(\{eY,eW\}\). This is a shore-independent hand proof, without OMEN or local mathematical recomputation, and awaits independent review. \(\square\)
