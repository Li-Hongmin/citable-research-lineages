> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The middle marked pair excludes both Case-XII pentagons on the \(K_{3,3}\) path

Use the five-vertex tree exterior of [Note 368](368-the-crossed-k33-marked-path-has-no-case-xii-row.md). Its \(K_{3,3}\) bipartition is \(\{x,y,z\}\sqcup\{r,s,t\}\); the tree edges \(xr,xs,xt,yr,zs\) have subdivision vertices \(u_0,\ldots,u_4\) and shore ports \(p_0,\ldots,p_4\). The four exterior marks are
\[
a=ys,\qquad b=yt,\qquad c=zt,\qquad d=zr,
\qquad s-a-y-b-t-c-z-d-r.                         \tag{1}
\]
The fifth mark \(e\) lies in the arbitrary six-port shore \(Z\). Consider the two pentagons with middle \(e\)-neighbour pair \(\{b,c\}\):
\[
\begin{array}{c|c}
S_1=e-b-a-d-c-e & T_1=\{ea,ed,bc,bd,ac\},\\
S_2=e-b-d-a-c-e & T_2=\{ea,ed,ab,bc,cd\}.
\end{array}                                                   \tag{2}
\]
Under the relabellings \((e,b,a,d,c)=(3,1,4,2,5)\) for \(S_1\) and \((e,b,d,a,c)=(3,1,4,2,5)\) for \(S_2\), the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((eb)(bc)=(13)(15)\) BF row and forbids every \(T_i\)--\(T_i\) row, including \([bc]\).

**Theorem.** No cubic five-pole with exterior (1), at any shore order or cycle rank, has complete exact-Case-XII support for either pentagon in (2). Together with Notes [368](368-the-crossed-k33-marked-path-has-no-case-xii-row.md) and [369](369-the-parallel-k33-marked-path-also-has-no-case-xii-row.md), this excludes six of the twelve labelled pentagons on this marked tree.

**Proof.** Fix one of the two pentagons and a required \((eb)(bc)\) row. Name its state-\(eb\) triple \(P\), state-\(bc\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(c\) matching \(C\), and singleton-\(b\) occurrences \(B_1,B_2\). Their terminal sets are, respectively, \(acd,ade,e,c,b,b\). By [Note 230's shore quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [Note 358's rooted-tree rule](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), \(P\) has no proper shore port and its \(b\)-half is rooted at either \(y\) or \(t\). Since \(R=bc\in T_i\), switching \(P\) with either \(B_j\) can only produce the other allowed state \(ec\): the possible alternatives \(ea,ed\) belong to \(T_i\). The resulting \(b\)--\(c\) terminal path is wholly exterior by the same zero-port argument as [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md).

**Root \(y\).** Here \(P\) uses \(t_by\). Starting at \(b\), the alternating path must pass through \(y,u_3,r,u_0,x\); turning at \(y\) to \(a\) or at \(r\) to \(d\) gives a forbidden double-\(T_i\) row. From \(x\), there are just two routes ending at \(c\):
\[
\begin{split}
H&:b-t_b-y-u_3-r-u_0-x-u_2-t-t_c-c,\\
L&:b-t_b-y-u_3-r-u_0-x-u_1-s-u_4-z-t_c-c.
\end{split}                                                   \tag{3}
\]
On \(L\), a singleton \(B_j\) has already matched both \(y\) and \(s\), the endpoints of mark \(a\), so it cannot cover \(t_a\). Hence both \(B_j\) use \(H\). They then select \(t_as,t_ct,t_dz,yu_3,ru_0,xu_2\) and ports \(p_1,p_4\). Matching at each marked subdivision vertex and imposing load two on each incident edge forces the complete exterior restrictions below. The port column includes \(e\) when its terminal edge is selected.

| Matching | Mark halves | Tree edges | Ports |
|---|---|---|---|
| \(P\) | \(t_by\) | \(xu_0,su_1,tu_2,ru_3,zu_4\) | none |
| \(R\) | \(t_by,t_cz\) | \(xu_1,tu_2,ru_3,su_4\) | \(e,p_0\) |
| \(E\) | \(t_ay,t_bt,t_cz,t_dr\) | \(xu_1,su_4\) | \(e,p_0,p_2,p_3\) |
| \(C\) | \(t_ay,t_bt,t_dr\) | \(xu_0,su_1,zu_4\) | \(p_2,p_3\) |
| each \(B_j\) | \(t_as,t_ct,t_dz\) | \(yu_3,ru_0,xu_2\) | \(p_1,p_4\) |

For clarity, the two \(B_j\) saturate their three selected mark halves; the terminal load fixes \(R,E\) on \(t_cz\) and \(E,C\) on \(t_dr,t_ay\). Then \(y,t,r,z,s,x\), in that order, fix the remaining mark and tree choices. The port choices follow at \(u_0,\ldots,u_4\).

Write \(Q=P|_Z\). In \(P\triangle E\), the exterior legs of terminals \(a,c,d\) end at \(p_2,p_0,p_3\), respectively. Switch \(P,B_1\) along \(H\), obtaining a state-\(ec\) triple \(P'\) with **the same complete shore matching \(Q\)**. In \(P'\triangle E\), the legs of \(a,b,d\) end at \(p_3,p_2,p_0\), respectively.

For \(S_1\), the original \(e\)-path of \(P\triangle E\) must end at \(a\): switching to either \(bc\) or \(bd\) would give two \(T_1\) states beside \(R\). Thus the shore path pairs \(e\) with \(p_2\). After the \(H\)-switch the same shore path ends at \(b\); switching \(P',E\) gives the forbidden \([bc]\) row. For \(S_2\), the original \(e\)-path must end at \(d\), so the shore pairs \(e\) with \(p_3\). After the \(H\)-switch it ends at \(a\); switch \(P',E\) to obtain a state-\(ac\) triple \(P''\). The \(e\)--\(a\) component does not touch \(t_ct\), so \(P''\) still uses \(t_ct\), while \(C\) uses \(t_bt\). Their complete symmetric difference therefore contains the exterior path \(c-t_c-t-t_b-b\). Switching that path gives \(ab\in T_2\) beside \(R=bc\in T_2\), again impossible.

**Root \(t\).** Now \(P\) uses \(t_bt\). A \(b\)--\(c\) path in \(P\triangle B_j\) is either
\[
D:b-t_b-t-t_c-c
\quad\text{or}\quad
L':b-t_b-t-u_2-x-u_1-s-u_4-z-t_c-c.             \tag{4}
\]
Any \(B_j\) using \(L'\) switches \(P\) to a state-\(ec\) triple rooted at \(z\). The automorphism of (1) reversing the marked path, \((a,b,c,d)\mapsto(d,c,b,a)\), fixes each unoriented pentagon in (2), maps this row to a \((eb)(bc)\) row rooted at \(y\), and contradicts the preceding case. Both \(B_j\) must therefore use \(D\). They saturate \(t_ct\), so \(R,E\) use \(t_cz\).

If \(E\) uses \(t_bt\), that edge is common to \(P,E\). Switching \(P,B_1\) along \(D\) changes only the former \(c\)-terminal component of \(P\triangle E\) into a \(b\)-terminal component; the \(a\)- and \(d\)-terminal components, including their shore pairings, remain unchanged. For \(S_1\), the old \(e\)-path must end at \(a\), so the new state-\(ec\) triple switches with \(E\) to \(ac\in T_1\). For \(S_2\), the old \(e\)-path must end at \(d\), and the new triple switches to \(cd\in T_2\). Both contradict \(R=bc\in T_i\).

It remains that \(E\) uses \(t_by\). Its other marked halves are then forced to be \(t_as,t_cz,t_dr\). It matches \(t\) through \(tu_2\), and matches \(x\) through either \(xu_0\) or \(xu_1\); \(xu_2\) is unavailable because \(E\) already uses \(tu_2\). The following exterior endpoint table is obtained by following the unique alternating paths. In each entry the ports are listed in the same order as the terminal labels in the column heading.

| \(E\)'s edge at \(x\) | Before \(D\): \(P\triangle E\), terminals \(a,c,d\) | After \(D\): \(P'\triangle E\), terminals \(a,b,d\) |
|---|---|---|
| \(xu_0\) | \(p_1,p_4,p_3\) | \(p_1,p_3,p_4\) |
| \(xu_1\) | \(p_3,p_4,p_0\) | \(p_4,p_3,p_0\) |

Again the \(D\)-switch leaves \(P|_Z=Q\) fixed. For \(S_1\), the old \(e\)-path must end at \(a\); the two rows of the table make the new one end at \(a\) or \(b\), giving \(ac\in T_1\) or \(bc\in T_1\) beside \(R\). For \(S_2\), the old \(e\)-path must end at \(d\); the new one ends at \(b\) or \(d\), giving \(bc\in T_2\) or \(cd\in T_2\). This exhausts both roots and both pentagons. \(\square\)

The result uses a genuine required BF row, complete perfect-matching exchanges and the negative Case-XII support; it does not synchronize shore matchings across different rows. The six remaining labelled pentagons on this tree have \(e\)-neighbour pairs \(\{a,c\},\{b,d\},\{a,d\}\). The other \(K_{3,3}\) spanning tree, the triangular prism, general exact Case XII and the Berge--Fulkerson conjecture remain open. This analytic proof has not received an independent check; no local mathematical recomputation was used.
