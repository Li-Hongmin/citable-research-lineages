> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 114 — 全重着色拼接的三位／九位精确归约（2026-09-13，脉冲 5/5）

有限命题：固定 S={167,246,257,347,356} 后，合法两极／三极边界是否分别由三个／九个稳定子轨道完全决定能否对齐？

**裁决：是。** 两极的七种 (x,x) 边界分成三个轨道，大小 1,4,2；三极的全部 42 种有序共线三元组分成九个轨道，大小 4,2,4,4,8,8,2,8,2。轨道编号按 `profiles.json` 顺序，从零开始。

**严格归约。** 对有固定端口顺序的 k 极 P（k=2 或 3），定义 B_S(P) 为所有内部顶点线均在 S 的 Fano 着色的有序端口色集合。定义其支持掩码 σ_k(P)：第 i 位为 1 当且仅当 B_S(P) 命中 S 的稳定子 H 的第 i 个边界轨道。三极在这里不增加封口顶点，也不要求端口三元组的线属于 S。按实际拼接配对调整右侧端口顺序后，

    P 与 Q 的拼接有至多五线着色 ⇔ σ_k(P) & σ_k(Q) ≠ 0。

证明：在任意极中对内部顶点的三色和作 GF(2)^3 求和，内部边抵消，故端口色之和为零。两端口必同色；三端口非零，因而两两不同且共线。若支持相交，选同轨道的两份真实着色，施一个稳定 S 的自同构对齐边界再粘合，所有保留顶点线仍在 S。反之，拼接图的至多五条线可补成五线集合；Note 110 给自同构把它送到 S。限制到两侧所得着色边界完全相同，支持必相交。这也覆盖仅用少于五条线的着色，不需为它们另选固定五线集合。

H 的作用保持 B_S(P)，所以每个被命中的轨道其实全部被命中。端口顺序不可任意忘掉：实际三和配对需先作用到有序状态，再形成掩码。

**承重边界。** 闭图删点所得给定着色的端口线必属于原调色板；任意三极的内部五线着色却可能需要第六条线才能补上封口顶点。因此 Note 110 的六个有序星轨道仅占上述九个轨道中的六个，其余三个轨道各有四个状态。用“封口后仍在 S 内”的六位支持作相交可提供充分条件，不能不加证明地取代这里的九位必要充分条件。

独立校验：`profiles.py` 按 GF(2) 基生成群和轨道；`verify_profiles.py` 独立穷举 7! incidence 置换，逐对验证 49 个两极与 1764 个三极边界配对，并核对 64 与 262144 对抽象支持掩码。两段代码均位于 `computations/fano-r1-20260913/`，分别运行 `python3` 即可。抽象掩码校验不声称全部掩码均可由真实极实现；数学归约把真实可实现性完整保留在 B_S(P) 定义里。

最薄弱一步：尚未证明任何两侧均 F5 的实际割因子必有相交支持，也未给出实际不相交支持对。因而 R1 完整 GO/NOGO 仍未决，既不能切换 R2/R3，也不能宣称归约到所有循环四边连通图。
