> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An all-pentagonal matching in minimum-host Case XII requires order 45

This note combines the specified-matching five-regular quotient in [Note 228](228-all-terminal-completion-by-chord-colours-and-cycle-loads.md) with the minimum-host cyclic connectivity in [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md). It gives a conditional, all-orders obstruction for the perfectly matchable marked-core branch. It does not exclude exact Case XII with other complement cycles or with no all-terminal perfect matching.

## An eight-vertex odd-cut lemma

**Lemma.** Let \(Q\) be a loopless \(r\)-regular multigraph of even order at most eight. If every odd vertex set \(W\) has \(|\delta_Q(W)|\ge r\), then \(Q\) has a proper \(r\)-edge-colouring.

**Proof.** Give each individual edge weight \(1/r\). The weight at every vertex is one. For any odd \(W\),
\[
\sum_{e\in E(Q[W])}\frac1r
=\frac{|W|}{2}-\frac{|\delta_Q(W)|}{2r}
\le\frac{|W|-1}{2}.
\]
By Edmonds's matching polytope theorem, this vector is a convex combination of matching incidence vectors. Since its degree is one at every vertex, every matching with positive coefficient in that combination is perfect. The original theorem is [Edmonds, *Maximum matching and a polyhedron with 0,1-vertices* (1965), Section 2](../../../../ResearchLibrary/lib/edmonds1965maximum/edmonds1965maximum.pdf), doi:10.6028/jres.069b.013. Its matching-polytope description applies to parallel edges as distinct coordinates; equivalently one may combine their fractional weights on the underlying simple graph and then distribute each selected pair among its parallel copies.

Call an odd cut *tight* if it has exactly \(r\) edges. Its fractional weight is one. Every perfect matching meets it in a positive odd number of edges, so every matching in the convex combination meets every tight cut **exactly once**. Choose one such perfect matching \(M\). For any odd cut \(D=\delta_Q(W)\), the smaller shore has at most three vertices, so \(|M\cap D|\le3\). If \(|D|=r\), then \(|D\setminus M|=r-1\). Otherwise degree parity gives \(|D|\ge r+2\), whence \(|D\setminus M|\ge r-1\). Thus \(Q-M\) is an \((r-1)\)-regular multigraph satisfying the same odd-cut hypothesis with \(r-1\). Repeat until \(r=0\). The removed perfect matchings partition the edges and supply the colouring. \(\square\)

The bound eight comes from the fact that every odd cut then has a shore of at most three vertices. For ten vertices, a five-vertex shore can be crossed five times, so this induction does not give a 5-edge-colouring.

**Five-cut gluing at order ten.** Let \(Q\) be a loopless 5-regular, 5-edge-connected multigraph on ten vertices. If it has a five-edge cut with at least three vertices on each shore, then it is 5-edge-colourable. Indeed, the cut shores have odd orders, so their sizes are \(3+7\) or \(5+5\). Replace each shore's complement by a new vertex, keeping only the five cut edges and the shore's internal edges. The resulting two loopless 5-regular multigraphs have orders \(4+8\) or \(6+6\), and each inherits every cut lower bound of five from \(Q\). The lemma gives a five-edge-colouring of both. At the two new vertices, the cut edges have five distinct colours; permute the colours on one side to align them edge by edge, then glue. Therefore any non-5-edge-colourable \(Q\) at order ten has **no nontrivial five-edge cut**.

## Case-XII consequence

**Theorem.** Let \(H\) be the non-pentagonal five-pole shore of a *minimum-order* Berge–Fulkerson counterexample whose full actual BF boundary support is exact Case XII. If \(H\) has an all-terminal perfect matching \(P\) such that every cycle of \(E(H)\setminus P\) is a five-cycle, then
\[
                         \boxed{|V(H)|\ge45.}                \tag{1}
\]

**Proof.** Write \(E(H)\setminus P=kC_5\), so \(|V(H)|=5k\) and \(k\) is odd. Attach the forbidden terminal pentagon \(T\), obtaining the minimum host \(G_T\). The five joining edges extend \(P\) to a perfect matching of \(G_T\), whose complement is \((k+1)C_5\). Proper girth five from Note 019 means no \(P\)-edge has both ends on a single one of these five-cycles: two such ends would be nonadjacent on that cycle and create a triangle, or adjacent and repeat a cycle edge. Contract each five-cycle. The quotient \(Q_P\) is a loopless 5-regular multigraph on \(k+1\) vertices.

Every nontrivial quotient cut lifts to a cut in \(G_T\) whose two shores each contain a five-cycle. Note 019's cyclic five-edge connectivity therefore gives \(|\delta_{Q_P}(W)|\ge5\) for every nontrivial \(W\), in particular every odd \(W\). On the other hand, [Note 228, (3)](228-all-terminal-completion-by-chord-colours-and-cycle-loads.md) says that a proper 5-edge-colouring of \(Q_P\) is equivalent to an all-terminal BF row of \(H\) containing this specified \(P\). Exact Case XII forbids that row, so \(Q_P\) is not 5-edge-colourable. The lemma forces \(k+1\ge10\). Hence \(k\ge9\) and \(|V(H)|=5k\ge45\). \(\square\)

This raises [Note 226's unconditional order-33 lower bound](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) to 45 **only** in the all-pentagonal complement branch of a minimum host. It also identifies the remaining quotient obstacle precisely: a loopless 5-regular multigraph on at least ten vertices, with every cut of size at least five, whose chromatic index exceeds five. Such a quotient alone would still not certify exact Case-XII BF support for its expanded five-pole.

At equality \(|V(H)|=45\), the quotient has ten vertices; five-cut gluing further forces every five-edge cut of \(Q_P\) to isolate a single vertex. This is a necessary boundary at the first surviving order, not an existence assertion.

The quotient is directly connected to an existing open problem. [Ma, Mattiolo, Steffen and Wolf, *Pairwise disjoint perfect matchings in r-edge-connected r-regular graphs* (2023), Problem 1.6](../../../../ResearchLibrary/lib/unknownarxiv2206a/unknownarxiv2206a.pdf), doi:10.1137/22m1500654, ask whether **any** 5-edge-connected 5-regular class-2 graph exists; their paper reports no example. Such a \(P\) would supply one. Their Theorem 1.5 and Observation 5.11 show that a universal positive 5-edge-colouring theorem for this class would imply Berge–Fulkerson itself, so it cannot be taken as a routine input here. At order ten, our lemma would make \(Q_P\) a smallest possible class-2 member; their Theorem 5.13 then additionally makes every three-vertex cut trivial. The five-cut restriction above is also their Theorem 5.13(i), with a direct small-order gluing proof given here. These are the precise published boundaries found in the targeted literature check of 2026-09-30; no existence of a ten-vertex quotient is claimed.
