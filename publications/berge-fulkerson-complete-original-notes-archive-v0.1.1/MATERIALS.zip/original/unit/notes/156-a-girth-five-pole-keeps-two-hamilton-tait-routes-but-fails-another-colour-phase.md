> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A girth-five pole keeps two Hamilton Tait routes but fails another colour phase

The edge-swapped twenty-one-vertex pole of [Note 155](155-a-tait-closed-cycle-exposes-forbidden-state-fifteen-after-both-direct-gates-pass.md) has two state-\(35\) Tait anchors whose singleton-\(3\)/singleton-\(5\) differences are spanning open paths, both through the chord-side edge \(z=j_1x_2\). Their direct terminal pairings pass the Case-XII tests, but a closed triple/singleton-\(5\) switch gives forbidden state \(15\). The construction below retains **all those properties at girth five** in a simple connected, proper-bridge-free cubic five-pole on forty-nine vertices whose five terminal vertices are independent. It is an analytic graph construction, with no perfect-matching enumeration. The two inserted colourable factors create nonterminal 2-edge-cuts, and the forbidden Tait state excludes exact Case XII; the result is a boundary for girth and the selected Tait gates, not a Berge--Fulkerson counterexample. The edge proof awaits independent checking.

## Two edge replacements

Use the **edge-swapped** version of Note 155, after its equation (12). Its two four-cycles are
\[
Q=t_3,u,v,k,t_3,
\qquad R=v_2,x_1,j_3,v_3,v_2.                         \tag{1}
\]
The edges \(e_1=uv\) and \(e_2=x_1j_3\) have owner pairs \(Dr\) and \(ZY\), respectively. They belong to \(Q\) and \(R\), respectively, and both occur in **each** spanning singleton path of Note 155(13). The direct paths in its (7) avoid both edges.

For each \(h\in\{1,2\}\), take a separate graph \(H_h\) with vertices \(a_i^h,b_i^h\), \(i\in\mathbb Z/7\mathbb Z\), and three one-factors
\[
E_0^h=\{a_i^h b_i^h\},\quad
E_1^h=\{a_i^h b_{i+1}^h\},\quad
E_3^h=\{a_i^h b_{i+3}^h\}.                         \tag{2}
\]
This is the Heawood graph in a cyclic presentation. Delete \(a_0^h b_0^h\in E_0^h\). Replace \(uv\) with the two links \(ua_0^1,b_0^1v\), and replace \(x_1j_3\) with \(x_1a_0^2,b_0^2j_3\). Give the links the owner pair of the removed edge. Give the remaining factor edges these owner pairs:

| Factor | \(E_0\) and links | \(E_1\) | \(E_3\) | \(B_2\) on the factor | \(q_{25}\) on the factor |
|---|---|---|---|---|---|
| \(H_1\) at \(uv\) | \(Dr\) | \(UC\) | \(ZY\) | \(E_1^1\) | \(E_3^1\) |
| \(H_2\) at \(x_1j_3\) | \(ZY\) | \(Ur\) | \(DC\) | \(E_1^2\) | \(E_0^2\) and both links |

The \(B,q\) assignments on the base graph are those of Note 155, with \(e_2\) removed from \(q\); neither base matching used \(e_1\). At each new vertex the three incident owner pairs partition \(\{U,Z,D,r,Y,C\}\). At each old endpoint the removed edge has simply been replaced by a link with the same owners. Thus all six original names extend to complete actual perfect matchings, their sum is \(2\mathbf1\), and the displayed choices extend the complete identity \(q+B=U+Z\). The five semiedge boundaries are unchanged, and both normalized BF row identities extend with the same states. Neither factor adds a junction to the original or right paired network, so the aligned diamond still has \(J'=5\). The new pole has \(21+2(14)=49\) vertices and \(29-2+2(20+2)=71\) proper edges.

The differences of any two one-factors in (2) form one alternating fourteen-cycle: their offset difference is nonzero modulo the prime \(7\). In particular, after deletion of \(a_0^h b_0^h\), the union of \(E_0^h\) with either other one-factor is a thirteen-edge alternating Hamilton path between \(a_0^h,b_0^h\). Both factors are bipartite and have no four-cycle, since the six nonzero differences between offsets \(0,1,3\) are distinct modulo \(7\). Hence each has girth at least six.

## The paths and forbidden phase survive

In each factor the three S-half owners \(U,Z,D\) occupy distinct one-factors. The core cycles \(K_o,K_s,\Omega\) avoid \(e_1,e_2\). Therefore both Tait triples in Note 155(6) extend across the factors with the same complete boundary states. Their four direct open paths in Note 155(7) avoid the replaced edges and remain unchanged. The same holds for the base portions of \(P_{54}\), \(r\triangle C\), and the \(5\leftrightarrow4\) component of \(p\triangle D\); the \(2\leftrightarrow3\) path \(P_{23}\) extends through \(H_1\) without changing its ends.

For each Tait anchor, the singleton-\(3\)/singleton-\(5\) path in Note 155(13) uses both \(e_1\) and \(e_2\). On \(H_1\), its two colours are \(D=E_0^1\) and \(Z=E_3^1\); on \(H_2\), they are \(Z=E_0^2\) and \(D=E_3^2\). Replace each occurrence of \(e_h\) in (13) by the two links and the corresponding thirteen-edge path. The result in either anchor is one open \(5\leftrightarrow3\) path through **all forty-nine vertices**, still containing \(z\). Consequently neither anchor has a closed singleton-\(3\)/singleton-\(5\) component.

In the first anchor, the \(U^{K_o}/D\)-alternating square \(Q\) of Note 155(14) becomes an alternating eighteen-cycle \(Q^*\): replace its \(D\)-edge \(uv\) by the two \(Dr\) links and the \(E_0^1/E_1^1\) thirteen-edge path. Switching \(U^{K_o},D\) on \(Q^*\) leaves a state-\(35\) Tait colouring. The resulting \(\widetilde U\triangle Z\) path from terminal \(3\) is still the untouched four-edge walk
\[
s_3,t_3,k,t_1,s_1.                                      \tag{3}
\]
Its terminal switch gives an actual state-\(15\) Tait colouring. Appendix XII of [Máčajová--Mazzuoccolo--Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) lists only \([13],[14],[24],[25],[35]\) as Case-XII Tait loops, so this state excludes exact Case XII.

Finally, the swapped base graph has no triangle. Its only unordered vertex pairs with two common proper neighbors are \(\{u,k\}\) and \(\{t_3,v\}\), the opposite pairs of \(Q\), and \(\{v_2,j_3\}\) and \(\{x_1,v_3\}\), the opposite pairs of \(R\). Thus (1) lists **all** its four-cycles. The two replacements break both. A cycle entering either \(H_h\) through one link must leave by the other, using at least five internal edges because adding \(a_0^h b_0^h\) to a shorter internal path would make a cycle of length below six in \(H_h\). It therefore replaces one old edge by a path of at least seven edges. Internal factor cycles also have length at least six. The untouched base cycle \(x_3x_4v_5v_4ax_3\) has length five. Hence the new pole has **girth exactly five**.

The proper-edge graph is also bridgeless. In the swapped base, start with the theta core \(\Omega\cup\chi\), then add the ears \(v_1j_1x_2\), \(v_3j_3x_1\), \(j_1j_2x_4\), \(x_3av_4\), \(abvkt_1j_2\), and \(j_3t_2ut_3k\), followed by the edge \(uv\). These are exactly all twenty-nine base proper edges, and every ear has both ends in the preceding graph; hence every base proper edge lies on a cycle. After deletion of \(a_0^h b_0^h\), each factor still contains the spanning Hamilton cycle \(E_1^h\cup E_3^h\), so no internal factor edge is a bridge. Each connector lies on a cycle obtained by joining a base path around \(e_h\) to an internal \(a_0^h\)--\(b_0^h\) path. Thus the forty-nine-vertex pole has no proper bridge. Its terminal vertices are still \(t_1,t_2,t_3,b,v_0\), pairwise nonadjacent in the base table, since neither graft changes an edge incident with two of them.

Each \(H_h\) has a BF cover obtained by taking two copies of each one-factor in (2). The replacements are precisely closed-factor two-edge sums, so [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md), equation (5), and [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md), equation (3), apply twice. Hence the **entire BF boundary support** of the forty-nine-vertex pole equals that of the edge-swapped twenty-one-vertex pole, and the two poles have the same truth value of the common complete \(B_2+C_4\) seed. Their **entire Tait-state sets** also agree: in any three-edge-colouring, parity on the even-order factor makes its two connector edges the same colour, so restoring the deleted edges projects the colouring; conversely, permute a factor three-edge-colouring to match the colour on the deleted base edge and splice. These equalities confirm that the graft cannot remove the forbidden loop. They do not determine whether either pole has a seed.

The construction isolates the remaining boundary: girth five, the aligned selected rows, the direct Tait terminal gates, the canonical \(p\triangle D\) endpoint, and even two spanning open singleton paths do not imply Case-XII negative Tait support. The nonterminal 2-edge-cuts make this girth amplification transparent to full boundary support and seed existence; neither minimum-host irreducibility nor indecomposable exact Case-XII perfect-matching closure is tested here.
