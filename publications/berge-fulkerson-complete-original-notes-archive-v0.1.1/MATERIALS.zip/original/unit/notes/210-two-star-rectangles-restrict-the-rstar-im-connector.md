> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-star rectangles restrict the two-\(R^*\) \(I_m\) connector

Work in the genuine two-vertex, two-five-cut barrier profile of
[Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md).
In the \(I_m\) exterior quotient, \(U=\{u_1,u_2\}\); both \(u_i\)
have one unmarked edge to each odd shore \(A,B\), while \(u_iw_i\)
meets a singleton component.  The five marks are the direct
\(A\)--\(B\) mark \(z\), the \(A\)--\(w_1\) and
\(B\)--\(w_1\) marks \(x,y\), and the \(A\)--\(w_2\) and
\(B\)--\(w_2\) marks \(p,q\).  Thus the shore port sets are
\(\{u_1,u_2,z,x,p\}\) and \(\{u_1,u_2,z,y,q\}\).
The statements below use the complete **actual** BF row relations
of these shores.  They do not assert that a pair of \(R^*\) shores
realizes exact Case XII.

## Shared-leaf stars give outer loops

Let \(a\in\{x,p\}\), \(b\in\{y,q\}\), and let \(r,s\) be
any two distinct ports of \(\{u_1,u_2,z\}\).  Then
\[
 \boxed{A^\circ\text{ supports }(ra)(sa),\quad
 B^\circ\text{ supports }(rb)(sb)
 \quad\Longrightarrow\quad H\text{ supports }[ab].}           \tag{1}
\]
Here support means a genuine six-perfect-matching BF row, including
the internal shore edges.  Relabelling the six matching occurrences
independently on the two shores does not change those internal loads.

For \(\{r,s\}=\{u_1,u_2\}\), put the \(A\)-triple boundaries
\([5]_A\setminus\{u_1,a\}\) and
\([5]_A\setminus\{u_2,a\}\) in slots \(1,2\); put its
singletons \(u_1,u_2,a,a\) in \(3,4,5,6\).
Put the \(B\)-singletons \(u_1,u_2\) in \(1,2\), its two
triple boundaries missing \(u_1b,u_2b\) in \(3,4\), and its
singletons \(b,b\) in \(5,6\).  At both \(u_i\), the residual
\(u_iw_i\) label is \(56\).  Every \(A\)-marked port has
label \(56\) at \(a\), \(12\) otherwise; every
\(B\)-marked port has label \(56\) at \(b\), \(34\)
otherwise.  The two labels at the direct \(z\)-mark are
disjoint.  Give the \(w_i\)-side halves of \(x,p\) label
\(34\), and those of \(y,q\) label \(12\).  Every exterior
vertex and mark subdivision now sees a partition of all six
slots.  In slots \(5,6\), precisely the three outer terminals
other than \(a,b\) occur, proving (1) for this leaf pair.

For the other leaf pairs, it suffices by reflecting the exterior
quotient to take \(a=x\) and \(b=y\) or \(q\).  In the table,
the \(A\)-triples missing \(ra,sa\) occupy slots \(1,2\), and
the \(B\)-triples missing \(rb,sb\) occupy slots \(3,4\).
\(A_{3456}\) and \(B_{1256}\) list their four singleton
boundaries in those slots.  A digit pair is the indicated
two-slot edge label; \(R_i\) labels \(u_iw_i\), and
\(D_x,D_y,D_p,D_q\) label the singleton-side mark halves.
\[
\begin{array}{c|c|c|c|c|c}
(a,b)&(r,s)&A_{3456}&B_{1256}&(R_1,R_2)
 &(D_x,D_y,D_p,D_q)\\\hline
(x,y)&(z,u_1)&(z,x,u_1,x)&(z,y,y,u_1)&(24,56)&(35,16,34,12)\\
(x,q)&(z,u_1)&(z,x,u_1,x)&(z,u_1,q,q)&(46,56)&(35,12,34,12)\\
(x,y)&(u_2,z)&(u_2,z,x,x)&(u_2,z,y,y)&(56,56)&(34,12,34,12)\\
(x,q)&(u_2,z)&(u_2,z,x,x)&(u_2,z,q,q)&(56,56)&(34,12,34,12)
\end{array}.                                                   \tag{2}
\]
In every row, the two shore labels at \(z\) are disjoint; the
three labels at each \(u_i,w_i\) and mark subdivision vertex
partition \([6]\).  The outer terminal labels are
\(T_a=12,T_b=34\), and \(T_c=56\) for the other three
marks.  Slots \(5,6\) therefore give \([ab]\).  Reflection
\((u_1,u_2,x,p,y,q)\leftrightarrow
(u_2,u_1,p,x,q,y)\) gives \(a=p\), completing (1).

## The necessary Figure-7 placement

The published Case-XIII relation \(R^*\) has exactly the pairs
across the two Figure-7 blocks
\[
 P=\{13,14,24,35,45\},\qquad
 Q=\{12,15,23,25,34\}
\]
and no BF loops [Máčajová--Mazzuoccolo--Tabarelli,
Figure 7 and Appendix XIII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).
Call a private port \(a\) *active* when the three block colours of
\(u_1a,u_2a,za\) are not all equal.  The three colours then
separate exactly two of the three shared-leaf pairs.  Two
two-element subsets of a three-element set intersect, so (1)
forces \([ab]\) for every active private port \(a\) of \(A\)
and every active private port \(b\) of \(B\).

Exact Case XII allows BF loops only on the five edges of one
pentagon \(S\).  If both private ports on both shores were active,
\([xy],[xq],[py],[pq]\) would form a four-cycle, which cannot
lie in \(S\).  Therefore
\[
 \boxed{\text{An exact-Case-XII }I_m\text{ with two }R^*
 \text{ shores has a private port constant on }
 \{u_1,u_2,z\}\text{ on at least one shore}.}                  \tag{3}
\]
At local label \(2\), the unique \(P\)-edge is \(24\); at
label \(4\), the unique \(Q\)-edge is \(34\).  Labels
\(1,3,5\) have a \(2+2\) colour split.  Hence a private
port is constant on the three shared ports precisely when its
label and the *other* private label are \((2,4)\) or
\((4,3)\).  Both private ports of one shore cannot be constant.
This identifies the precise port-placement boundary left by (3).

Constancy alone does not suppress loops involving that port.
For instance, in the labelling
\((u_1,u_2,z,x,p)=(1,5,2,3,4)\) and
\((u_1,u_2,z,y,q)=(1,5,2,3,4)\), the private ports
\(p,q\) are constant.  Nevertheless \(A^\circ\) supports
\((px)(pz)\) and \(B^\circ\) supports \((yq)(zq)\):
the two pairs have opposite Figure-7 colours \(34\in Q\) and
\(24\in P\).  Put the \(A\)-triples missing \(px,pz\)
in slots \(1,2\), its singletons \(x,z,p,p\) in
\(3,4,5,6\); put the \(B\)-singletons \(y,z\) in
\(1,2\), its triples missing \(yq,zq\) in \(3,4\),
and \(q,q\) in \(5,6\).  The connector choice
\((D_x,D_y,D_p,D_q)=(14,23,34,12)\) has
\(R_1=R_2=56\) and gives an actual outer \([pq]\) row.
This is a boundary for the star argument; the relative placement
is excluded below by *other* rows.

There is an additional actual-row gate at one singleton.  If
\(A^\circ\) supports \((u_1u_2)(u_1x)\) and \(B^\circ\)
supports \((u_1u_2)(u_1y)\), then the outer relation contains
both \((xp)(yq)\) and \((xq)(yp)\).  To see this, put the
\(A\)-triple boundaries \(\{z,x,p\},\{u_2,z,p\}\) in
slots \(1,2\), its singleton \(u_1,u_1,u_2,x\) in
\(3,4,5,6\); put the \(B\)-singleton \(u_1,u_1\) in
\(1,2\), its triple boundaries \(\{z,y,q\},\{u_2,z,q\}\)
in \(3,4\), and singleton \(y,u_2\) in \(5,6\).
Here \(R_1=56,R_2=13\), and the two connector completions are
\[
\begin{array}{c|cccc|ccccc|c}
 &D_x&D_y&D_p&D_q&T_z&T_x&T_y&T_p&T_q&\text{outer type}\\\hline
1&34&12&45&26&56&25&46&36&15&(yp)(xq)\\
2&34&12&46&25&56&25&46&35&16&(yq)(xp)
\end{array}.                                                   \tag{4}
\]
Each line partitions all six slots at every connector vertex and
mark subdivision vertex, so it glues actual shore rows.  If
\([xy]\) also occurs, neither allowed loop pentagon can admit
both types in (4): \(xp\in S\) would force the triangle
\(xy,xp,yp\); \(xp\notin S\) would force \(yq,xq\in S\)
and the triangle \(xy,yq,xq\).  Thus the three rows contradict
exact Case XII.  Reflection gives the analogous condition at
\(w_2\).

For example, put \((u_1,u_2,z,x,p)=(1,5,2,3,4)\) on \(A\)
and \((u_1,u_2,z,y,q)=(1,5,2,3,4)\) on \(B\).
The private ports \(x,y\) are active, so (1) gives \([xy]\);
both local types used in (4) are present because \(15\in Q\)
and \(13\in P\).  This relative placement is excluded.  Other
constant-private-port placements, the remaining two-vertex
quotients, larger Tutte barriers, and the perfectly matchable
unmarked-core branch are not settled here.  The analytic proof
has not received an independent check.

[Note 212](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
subsequently adds the other private port as a fourth possible star
leaf.  Its six-slot transport excludes **all** relative placements
of two \(R^*\) shores in \(I_m\), including the constant-port
placements left open by this note.
