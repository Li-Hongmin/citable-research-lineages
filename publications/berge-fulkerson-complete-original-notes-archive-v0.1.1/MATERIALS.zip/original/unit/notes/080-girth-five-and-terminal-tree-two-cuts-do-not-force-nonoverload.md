> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth five and terminal-tree two-cuts do not force nonoverload

The structural restrictions inherited by a Case-XII side in
[Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md)
do not force the first condition of the residual completion criterion in
[Note 078](078-residual-degree-two-criterion-for-two-triple-completion.md).
This fails in both failed-star branches: an order-eleven pole blocks all
three repeated-extension targets, and the order-thirty-nine pole of
[Note 071](071-girth-five-does-not-force-a-failed-pivot-residual-selector.md)
blocks every optimal three-distinct-extension gate.  Both are genuine cubic
5-poles of girth five whose proper 2-edge-cuts have exactly the terminal-tree
form allowed by Note 019.

Neither pole has exact Case-XII boundary support.  The result therefore
isolates a joint interface: exact negative support and whole-graph
irreducibility must be used together; neither the support-preserving
decomposable models of Note 079 nor the present irreducible positive-row
models decide the remaining statement.

## An order-eleven repeated-extension counterexample

Let the internal vertices be \(0,\ldots,10\), put a semiedge at each of
\(0,\ldots,4\), and take the proper edges

\[
\begin{split}
 &(0,8),(0,10),(1,5),(1,8),(2,7),(2,9),(3,8),\\
 &(3,9),(4,6),(4,7),(5,6),(5,10),(6,9),(7,10).
\end{split}                                        \tag{1}
\]

This is a simple connected cubic 5-pole of girth five.  It has no proper
bridge, and the complete list of smaller shores of proper 2-edge-cuts is

\[
 \{0\},\{1\},\{2\},\{3\},\{4\}.                  \tag{2}
\]

Thus every such cut isolates precisely a one-vertex terminal 3-pole tree,
as permitted by Note 019.

The pole has fourteen distinct actual perfect matchings

\[
 A,B,C,D,X,Y,q_{13},r_{45},q_{14},r_{23},
 q_{24},r_{15},q_{25},r_{34},
\]

whose explicit edge sets are frozen in the proof bundle.  They form the
four literal BF double-cover rows

\[
\begin{aligned}
 &(q_{13},r_{45},A,X,C,D),\\
 &(q_{14},r_{23},A,B,X,C),\\
 &(q_{24},r_{15},A,B,C,D),\\
 &(q_{25},r_{34},B,Y,C,D).
\end{aligned}                                      \tag{3}
\]

Here \(A,B,C,D\) have singleton boundaries \(1,2,4,5\), while the distinct
matchings \(X,Y\) both have boundary \(3\).  The same identity \(X\) occurs
in the first two arms, so (3) is the repeated-extension star of Notes
073 and 079.  Its three prescribed targets are all overloaded:

\[
\begin{array}{c|c|c}
\text{target}&\text{edge}&\text{six-identity hit set}\\ \hline
BDXY&(0,10)&BDX\\
ACXY&(1,5)&CXY\\
ABDY&(3,9)&ADY.
\end{array}                                        \tag{4}
\]

Hence none passes the edge-nonnegativity gate in Note 078.

## The three-distinct branch in the Note-071 pole

The order-thirty-nine voltage-lift pole of Note 071 has no proper bridge.
Its proper core has exactly five 2-edge-cuts:

\[
\begin{aligned}
 &\{(0,30),(0,33)\},&&\{(3,24),(3,27)\},
 &&\{(6,27),(6,30)\},\\
 &\{(9,21),(9,36)\},&&\{(12,18),(12,21)\}.
\end{aligned}                                      \tag{5}
\]

Each isolates the displayed terminal vertex; there are no other proper
2-edge-cuts.  Thus this pole also satisfies the precise Note-019 cut
boundary.

Use its three distinct extension identities and four anchors from
[Note 074](074-three-distinct-extensions-require-four-witness-reuse-rows.md):

\[
 a_1=33,\quad a_2=16,\quad a_4=24,\quad a_5=0,
 \quad x=2,\quad y=12,\quad z=10.                  \tag{6}
\]

Across the eight optimal row-pattern gates and their 28 concrete cell
choices there are 20 distinct target singleton quadruples.  Fifteen are
overloaded, and every concrete gate contains at least one of them.  The
number of overloaded targets in a gate has distribution

\[
 2^{\,4},\qquad3^{\,16},\qquad4^{\,8},           \tag{7}
\]

where the exponent counts gates.  All 28 choices therefore fail before
cycle or terminal-path parity is considered.

The explicit matching, cut, and gate checks for both poles are frozen in
the [proof bundle](../computations/bundles/irreducible-failed-star-nonoverload-counterexamples/README.md).

## Remaining boundary

The following implication is false in both repeated and three-distinct
branches:

\[
\begin{gathered}
\text{simple connected bridge-free cubic 5-pole of girth five}\\
+\ \text{every proper 2-cut is an allowed terminal-tree cut}\\
+\ \text{the four literal failed-pivot BF rows}
\end{gathered}
\Longrightarrow
\text{some prescribed reuse gate is edge-nonoverloaded}. \tag{8}
\]

This does not refute the exact-Case-XII statement: the two poles carry
additional or missing BF boundary types.  Together with
[Note 079](079-k33-two-sums-destroy-failed-star-nonoverload-gates.md), it
shows exactly what cannot be separated.  A successful argument must use a
common consequence of exact positive and negative BF support, the opposite
cut side, and whole-graph minimality; girth and the currently known local
cut classification alone do not couple the separated overload witnesses.
