> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A one-internal-mark barrier shore has a rank-free six-port quota

Work in the minimum-host, connected deficient-core setting of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md). Let \(U\) be its normalized maximum Tutte barrier, \(|U|=k\), and take the profile with one non-singleton odd component \(C\) of \(F-U\), a five-edge cut \(\delta_J(C)\), and the unique marked edge \(e\) internal to \(C\). The other \(k+1\) odd components are singleton vertices. In particular, no marked edge meets \(U\), \(F[U]\) has no edge, and the other four marks join distinct components of \(F-U\).

The size and cycle rank of \(C\) do not enter the following identities. They constrain the **entire actual perfect-matching family** of the five-pole, and the six-edge host cut identified in [Note 171](171-five-vertex-tree-barrier-shores-force-a-two-edge-bipartization.md).

## Every pole matching has a fixed shore-hit count

Form the five-pole \(H\) by subdividing the five marked edges of \(J\), with terminal semiedge \(s_i\) at the subdivision vertex \(t_i\). For an actual perfect matching \(N\) of \(H\), write \(B=\partial N\) for its terminal boundary, \(c=\mathbf1_{\{e\in B\}}\), and let \(b\) count the five proper cut edges from \(C\) to the exterior in the subdivided graph. Thus \(b\) does not count \(s_e\). Then

\[
\boxed{b+|B|-c=3.}                                           \tag{1}
\]

Equivalently, the number \(b+c\) of ports used on the six-port shore \(C\cup\{t_e\}\), with \(s_e\) regarded as a port, is

\[
\boxed{b+c=3-|B|+2c.}                                       \tag{2}
\]

Consequently the complete matching family has the following necessary profiles:

| Boundary of \(N\) | \(c\) | Five proper cut edges used \(b\) | Six shore ports used \(b+c\) | Hits at \(C\) |
|---|---:|---:|---:|---:|
| triple, \(e\notin B\) | 0 | 0 | 0 | 1 |
| triple, \(e\in B\) | 1 | 1 | 2 | 1 |
| singleton, \(e\notin B\) | 0 | 2 | 2 | 3 |
| singleton, \(e\in B\) | 1 | 3 | 4 | 3 |

Here a hit at \(C\) means a matching edge covering a vertex of \(C\) from outside \(F[C]\). If \(c=0\), the matching uses one of the two halves of the internal mark \(e\), which supplies one additional hit at \(C\); hence its hit count is \(b+1-c\). Equation (1) also rules out an all-terminal **perfect matching** in this deficient-core profile, as expected from \(F\)'s deficiency two. The table asserts no existence of a matching in any particular row.

**Proof of (1).** Of the five proper cut edges, let \(a\) have their exterior endpoint in \(U\), and \(t=b-a\) have it at one of the four exterior marked subdivision vertices. Each of the \(k-a\) remaining vertices of \(U\) is matched to a singleton component of \(F-U\). Among the four exterior subdivision vertices, \(t\) are matched across the cut and \(|B|-c\) use their terminal semiedges. Each of the other \(4-t-(|B|-c)\) is matched to a singleton component. There are exactly \(k+1\) such singleton components, each with exactly one vertex. Therefore

\[
(k-a)+4-t-(|B|-c)=k+1,
\]

which is (1). The cut description and the matching at \(t_e\) give (2) and the hit column. \(\square\)

The same hit count follows independently from the Tutte barrier: the \(k+2\) odd components receive \(k+5-|B|\) matching hits from \(U\) and selected marked endpoints. A triple matching therefore hits every component once. A singleton matching has two excess hits; singleton components cannot absorb them, so \(C\) receives three. Since the internal mark contributes \(1-c\) hits to \(C\), this again gives the four values of \(b\) above.

## Four triple classes share one complete shore mask

Exact Case XII has a real BF row containing each of the ten missing-pair states. In particular, for every \(j\ne e\), an actual triple-boundary matching of state \(ej\) exists. Its terminal boundary excludes \(e\), so the first table forces \(b+c=0\): it uses neither a proper cut edge nor \(s_e\). Its restriction to \(Z=C\cup\{t_e\}\) is therefore an ordinary perfect matching of the even-order graph on \(Z\).

Let \(\mathcal Z_0\) be the complete family of these zero-port matchings of \(Z\), and let \(\mathcal E_{ej}\) be the exterior restrictions of the actual state-\(ej\) triple matchings. The absence of cut edges gives an **exact Cartesian factorization**

\[
\boxed{\mathcal P_{ej}(H)=\mathcal Z_0\times\mathcal E_{ej}
\qquad(j\ne e).}                                           \tag{3}
\]

All four exterior fibres are nonempty by positive Case-XII support, and \(\mathcal Z_0\) is nonempty. Fix **any one** \(Z_0\in\mathcal Z_0\); pairing it independently with one member of each \(\mathcal E_{ej}\) gives four actual triple matchings, one in every state \(ej\), whose complete masks on the entire shore \(Z\) are literally identical. For any two such states \(ej,ek\), the symmetric difference has one alternating terminal path from \(j\) to \(k\), plus possible closed alternating cycles, all outside \(Z\). Flip those closed components in one matching. Hence the two matchings can be chosen with **exactly one exterior alternating terminal path** as their symmetric difference while still sharing their complete \(Z\)-mask. This is a cross-state full-mask identity supplied by complete graph-induced matching closure. It does not put the chosen matchings into a common BF row or synchronize their exterior masks.

The exterior factor has a sharper, order-independent description. Let \(W\) be the set of its \(k+1\) singleton components, and let
\[
D=\{w\in W:F[U,W\setminus\{w\}]\text{ has a perfect matching}\}.
\]
For \(w\in D\), write \(\mathcal M_w\) for the matchings of \(F[U,W\setminus\{w\}]\). A zero-port state-\(ej\) exterior matching consists **exactly** of a member of \(\mathcal M_w\), one marked half-edge \(t_jw\), and the three other exterior terminal semiedges, for some \(w\in D\) adjacent to \(t_j\). Therefore
\[
\boxed{\mathcal E_{ej}\ne\varnothing
\quad\Longleftrightarrow\quad D\cap N(t_j)\ne\varnothing
\qquad(j\ne e).}                                           \tag{4}
\]
Positive Case-XII support forces all four intersections in (4). A fixed matching in some \(\mathcal M_w\) can be reused for precisely those states \(ej\) whose marked subdivision vertex \(t_j\) meets \(w\). [Note 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md) excludes three marked edges at one core vertex, so this number is at most two. In particular \(|D|\ge2\), and **no three** of the four states can have the same complete matching mask on the unmarked exterior edges \(F[U,W]\). The common-mask conclusion above is thus confined to the shore \(Z\); its exterior cannot be synchronized across three states by fixing one \(U\)--\(W\) matching.

For \(|U|=1\), the two forks of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md) illustrate the last boundary at the single-matching level: each fork can expose its vertex for two incident marked labels, while no vertex serves three labels. [Note 203](203-a-cross-triple-switch-excludes-the-422-case-xii-profile.md) separately rules out exact Case XII for that one-vertex quotient; the factorization and obstruction above hold without fixing \(|U|\).

## Exact four-singleton completion of a repeated shore mask

Fix \(Q\in\mathcal Z_0\), and consider two triple occurrences whose restrictions to \(Z\) are both \(Q\), as the factorization (3) permits at the **single-matching** level. Let \(I=\{1,2,3,4\}\) name four prospective singleton occurrences. At each of the six shore ports \(\alpha\), prescribe a two-set \(A_\alpha\subset I\) of singleton slots that must use that port. Put \(\Gamma_Q=E(Z)\setminus Q\), including all six port semiedges. Every vertex has degree two in \(\Gamma_Q\), so its components are three port-to-port paths and some closed cycles.

There are actual shore matchings \(R_1,\ldots,R_4\) with these port labels and
\[
2\mathbf1_Q+\sum_{i=1}^4\mathbf1_{R_i}=2\mathbf1_{E(Z)}
\]
**if and only if** every closed component of \(\Gamma_Q\) is even and, on every path with endpoint ports \(\alpha,\beta\) and \(\ell\) edges **including the two port semiedges**,
\[
\boxed{A_\beta=
\begin{cases}
A_\alpha,&\ell\text{ odd},\\
I\setminus A_\alpha,&\ell\text{ even}.
\end{cases}}                                               \tag{5}
\]
For compatible prescribed labels, the number of ordered four-singleton shore completions is \(6^z\), where \(z\) is the number of even closed components of \(\Gamma_Q\).

Indeed, the two occurrences of \(Q\) already load every \(Q\)-edge twice. Each remaining edge must belong to exactly two of the four \(R_i\). At a vertex the two \(\Gamma_Q\)-edge label sets must partition \(I\), so labels alternate between a two-set and its complement along every component. A closed component admits such an alternation exactly when it is even; each even cycle has six choices for one edge label. Along a path the prescribed end labels obey exactly (5), and a compatible path has a unique labelling. Conversely these labels define four actual perfect matchings of the six-pole, proving the criterion and count.

This criterion is local to \(Z\). To make a whole BF row, the four shore matchings must still glue to **actual exterior singleton matchings with those same port two-sets**, while the chosen two triple occurrences and four singleton occurrences must share one edge-load-two row. Thus common triple masks on \(Z\) alone do not force a Case-XII type or a forbidden type. If every \(Q\in\mathcal Z_0\) has an odd closed component in \(\Gamma_Q\), then the two zero-port triple occurrences of any positive row \((ej)(ek)\) must have **different** complete shore masks; this is a conditional obstruction to that particular reuse mechanism, not to the row itself.

## The complementary six-pole has four boundary profiles

Attach the terminal pentagon to \(H\), giving the whole host \(G_T\), and put \(Z=C\cup\{t_e\}\). The cut \(\delta_{G_T}(Z)\) has six edges: the five proper cut edges just used and the edge from \(t_e\) to the cap pentagon. Open the complementary shore \(E=G_T-Z\) at these six edges. For any actual perfect matching \(P\) of this six-pole, let \(b\) be its number of used cut semiedges, \(c\in\{0,1\}\) indicate use of the cut semiedge at the cap vertex corresponding to \(e\), and \(h\) count the four other edges from exterior marked subdivision vertices to the cap. Then

\[
\boxed{b+h-c=3.}                                           \tag{6}
\]

The matching parity of the even-order six-pole makes \(b\) even. The five cap vertices make \(c+h\) odd. Thus every matching of the **complete** family of \(E\) has one of exactly four numerical profiles:

| \(c\) | \(b\) | \(h\) |
|---:|---:|---:|
| 0 | 0 | 3 |
| 0 | 2 | 1 |
| 1 | 2 | 2 |
| 1 | 4 | 0 |

In particular no matching of \(E\) uses all six cut semiedges. These four profiles are only allowed numerical types; equation (6) does not assert that all four occur.

**Proof of (6).** Let \(a\) of the used cut semiedges meet \(U\), and \(t\) meet the four exterior subdivision vertices. Then \(b=a+t+c\). The \(k+1\) singleton components must be matched from the \(k-a\) available vertices of \(U\) and the \(4-t-h\) available exterior subdivision vertices. Their exact count gives \((k-a)+(4-t-h)=k+1\), hence \(a+t+h=3\), equivalent to (6). Since \(|Z|=|C|+1\) is even, so is the order of \(E\), and its matching has even boundary size \(b\). A perfect matching of the five cap vertices uses an odd number \(c+h\) of their external edges. Solving these conditions gives the table. \(\square\)

## A rowwise six-slot consequence

Consider any actual BF pair or loop row of \(H\), with missing-pair states \(p,q\in\binom{[5]}2\), and put \(m_e=\mathbf1_{\{e\in p\}}+\mathbf1_{\{e\in q\}}\in\{0,1,2\}\). In that row the two triple occurrences have boundary \([5]\setminus p\) and \([5]\setminus q\), while the four singleton occurrences carry the elements of \(p\) and \(q\). The first table therefore gives the exact six-port slot multiset

\[
\boxed{0^{m_e}\;2^{6-2m_e}\;4^{m_e}.}                       \tag{7}
\]

Thus zero-port and four-port slots occur in equal number in **every** genuine row, independently of which of the forty Case-XII pair types the row realizes. The identity uses every actual matching in the row; it does not identify complete masks across distinct rows or close the remaining high-rank \(C\) relation. [Note 203](203-a-cross-triple-switch-excludes-the-422-case-xii-profile.md) already excludes the one-vertex-barrier instance; the surviving scope here has \(|U|\ge2\) and, by [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md), \(|U|+\rho\ge11\). In contrast to the two-five-cut profile of [Note 209](209-a-five-cut-barrier-shore-cannot-have-lstar-support.md), this shore has a six-edge cut in the whole host, so the published five-cut \(L^*/R^*\) classification cannot be applied to it.
