> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five-vertex zero-port closure forces the D edge and the HJ pair

Continue the genuine left and right exact-Case-XII rows in the
noncollision, one-edge-near-bipartite \(R_0=DJ\) branch. Use the
five-vertex six-cut Hall block of [Note 320](320-five-vertex-six-cut-hall-design-and-zero-port-phase-gate.md):
\[
\begin{array}{c|ccccc}
T&o&p&x&y&z\\\hline
N_S(t)&\{u,a,b\}&\{u,c,f\}&\{a,c\}&\{a,f\}&\{b,c\}
\end{array}                                                   \tag{1}
\]
The three outward incidences of \(S\) are \(H,Q,\ell d_D\),
based in some order at \(u,b,f\), where \(Q=A\) or \(I\).
The \(J\)-port is based at \(j\in\{x,y,z\}\). A **zero-port
matching** below is an actual shore perfect matching selecting
\(g,t_{ew}\). Its full complement has, by [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md),
only the two possible pairings
\[
           EA\mid ID\mid HJ\qquad\text{or}\qquad
           EJ\mid AD\mid IH.                              \tag{2}
\]

**Theorem.** Every zero-port matching selects \(\ell d_D\).
Its complement contains a complete path from \(H\) to \(J\)
inside the block (1), so its pairing is necessarily
\(EA\mid ID\mid HJ\). Up to the reflection
\((a,b,o,y)\leftrightarrow(c,f,p,z)\), every local
placement lies in the following necessary table.
Here \(r\) is the unique \(T\)-vertex whose third edge is selected
by the zero-port matching; every phase in the indicated \(r\)-fibre
is reachable by a block-internal alternating-cycle switch.

| \(\ell\) | \(j\) | base of \(H\) | \(r\) |
|---|---|---|---|
| \(u\) | \(x\) | \(f\) or \(b\) | \(y\) or \(z\), respectively |
| \(u\) | \(y\) | \(f\) | \(z\) |
| \(u\) | \(z\) | \(b\) | \(y\) |
| \(b\) | \(x\) | \(u\) | \(y\) |
| \(b\) | \(y\) | \(f\) | \(x\) |
| \(b\) | \(z\) | \(f\) or \(u\) | \(y\) or \(x\), respectively |

In the genuine right \((ea)(ad)\) row, the entry
\((\ell,j,H,Q,r)=(b,x,u,I,y)\) is impossible; so is its reflection
\((f,x,u,I,z)\). The entry \((b,y,f,I,x)\) and its reflection
\((f,z,b,I,x)\) are also impossible. Comparing with the genuine
left \(EAID\) slot excludes \((b,x,u,A,y)\) and its reflection
\((f,x,u,A,z)\), as well as \((b,y,f,A,x)\) and its reflection
\((f,z,b,A,x)\). The table asserts necessary local phases, not
realizations of exact Case XII. Consequently a genuine right row
with \(\ell=b\) has \(j=z\), and one with \(\ell=f\) has
\(j=y\).

## A zero-port matching cannot avoid the D edge

Suppose one does. Note 320's phase closure first forces
\(\{H,\ell\}=\{b,f\}\), with \(Q\) based at \(u\).
Reflect (1) if needed to take \(H=b,\ell=f\). All four
full block matchings of Note 320, equation (3), are actual
zero-port matchings with the same exterior. In particular, its
\(M_3=\{up,fy,ao,bz,cx\}\) has the complete complement path
\[
                         Q-u-o-b-H.                         \tag{3}
\]
If \(Q=A\), (3) is absent from both pairings (2). Hence \(Q=I\).
For \(j=x\), the phase
\(M_4=\{up,fy,ax,bo,cz\}\) has the complete path
\(D-d_D-f-p-c-x-J\). For \(j=y\), that same phase has
\(I-u-o-a-y-J\). For \(j=z\), \(M_3\) has
\(D-d_D-f-p-c-z-J\). None of these paths occurs in (2).
The edge \(D d_D\) and \(d_Df\) belong to the complement because
\(d_D\) uses its third edge when \(fd_D\) is unselected.
Thus every choice of \(j\) is impossible.

## Phases using the D edge

Fix a zero-port matching selecting \(\ell d_D\). The two
degree-three \(T\)-vertices \(o,p\) must be matched from \(S\).
Exactly one of \(x,y,z\) uses its third edge; call it \(r\).
Since \(J\) is unselected, \(r\ne j\). Directly matching the
remaining four vertices of \(S\) gives the following complete
phase lists, with \(\ell d_D\) omitted:
\[
\begin{array}{c|c|l}
\ell&r&\text{selected }S\!\text{--}\!T\text{ edges}\\\hline
u&x&bo,fp,ay,cz\ ;\ bz,ao,cp,fy\\
u&y&bo,fp,ax,cz\ ;\ bz,ao,fp,cx\\
u&z&bo,fp,ay,cx\ ;\ bo,cp,fy,ax\\
b&x&uo,fp,ay,cz\ ;\ up,fy,ao,cz\\
b&y&uo,fp,ax,cz\\
b&z&uo,fp,ay,cx\ ;\ uo,cp,fy,ax\ ;\ up,fy,ao,cx.
\end{array}                                                   \tag{4}
\]
For fixed \((\ell,r)\), successive entries in (4) differ on
one alternating cycle contained in (1). The cycles, in table
order, are respectively
\(b-o-a-y-f-p-c-z-b\),
\(b-o-a-x-c-z-b\),
\(a-y-f-p-c-x-a\),
\(u-o-a-y-f-p-u\), and for the last line
\(a-y-f-p-c-x-a\), \(u-o-a-x-c-p-u\).
Thus actual perfect-matching closure realizes every phase of
the occupied \((\ell,r)\)-fibre without changing any edge outside
\(S\cup T\), including \(g,t_{ew}\).

Only four local complement endpoints are exposed by (4):
\(H,Q,J\), and the unselected third edge at the unique
non-\(j\), non-\(r\) vertex of \(\{x,y,z\}\). The \(D\)-port
lies outside this local component because \(\ell d_D\) is
selected. Tracing these four ends gives:

* For \(\ell=u,r=y\), \(J=x\) joins the port at \(f\),
  while \(J=z\) joins the port at \(b\), in both phases.
  For \(\ell=u,r=z\), \(J=x\) joins \(b\), while
  \(J=y\) joins \(f\), in both phases.
* For \(\ell=b,r=y\), \(J=x\) joins \(u\) and
  \(J=z\) joins \(f\). For \(\ell=b,r=x\), \(J=y\)
  joins \(f\) and \(J=z\) joins \(u\), in both phases.
* For \(\ell=u,r=x\), the first phase joins \(J\) to
  \(f\) if \(j=y\), or to \(b\) if \(j=z\); the second
  phase joins \(b\) to \(f\) and \(J\) to the same exterior
  exit. For \(\ell=b,r=z\), the first phase joins
  \(J\) to \(u\) if \(j=x\), or to \(f\) if \(j=y\);
  each of the other phases joins \(u\) to \(f\) and \(J\)
  to that same exterior exit.

The third bullet excludes both exceptional fibres. If \(Q=A\),
their second phases give the forbidden \(AH\) complement pair.
If \(Q=I\), the first phase either pairs \(I\) with \(J\),
which is forbidden, or pairs \(H\) with \(J\). In the latter
case (2) forces the first phase's \(I\)-to-exit path to continue
outside the block to \(D\). The phase switch preserves that
outside continuation, while the second phase joins \(J\) to
the same exit. It would therefore have the forbidden complete
\(JD\) path. This excludes \((\ell,r)=(u,x),(b,z)\),
for either value of \(Q\).

In every other phase, (2) forbids \(QJ\), so the port joined
locally to \(J\) must be \(H\). The four cases in the first two
bullets give exactly the displayed necessary table. Since (2)
has only one pairing containing \(HJ\), every surviving zero-port
matching has complement pairing \(EA\mid ID\mid HJ\).
The reflection of (1) handles \(\ell=f\).

## Right-row routes exclude two placements

Take \(\ell=b,j=x,H=u,Q=I=f\). The table forces the
right row's zero-port slot \(X\) to have the unique local phase
\[
                  X:\quad bd_D,uo,fp,ax,cz,
                     \quad y\text{ uses its third edge}.      \tag{5}
\]
The right row's \(U(EJ)\) slot also uses \(bd_D\) by Hall
saturation: with \(J=x\) selected, only four \(T\)-vertices
remain to match the four \(S\)-vertices other than \(b\).
There are exactly two local \(U\)-phases:
\[
        U_1:\ uo,ay,fp,cz;\qquad
        U_2:\ up,ao,fy,cz.                                  \tag{6}
\]
The right-row proper-port loads are \(I:YV\), \(H:ZW\),
and \(J:ZU\). If \(U=U_1\), the common \(XU_1\) edges
\(uo,fp,cz\) force successively
\(up:YV\), \(fy:ZW\), \(cp:ZW\), \(cx:YV\),
\(ax:XW\), \(ao:YV\), and \(ay:UZ\).
Then slot \(Z\) selects both \(fy\) and \(ay\) at \(y\),
impossible.

If \(U=U_2\), \(Z\) selects \(J=x\) and so cannot use
\(ax,cx\). Since \(cz:XU\), it must use \(cp\).
At \(p\), the selected edges \(U:up\), \(X:fp\),
and \(Z:cp\), together with \(I:YV\) at \(f\), force
\(fp:XW\) and \(fy:UZ\). Thus \(Z\) cannot use
\(ay\); it also cannot use \(ax\), so it uses \(ao\).
Consequently the complete local component of
\(X\triangle Z\) is
\[
                         H-u-o-a-x-J.                         \tag{7}
\]
But the genuine right row requires its \(X\triangle Z\) shore
paths to pair \(EH\mid AJ\), by [Note 297, equation (3)](297-the-right-central-ad-row-survives-the-exterior-route-check.md).
The complete \(HJ\) component (7) contradicts that pairing.
Reflection gives the stated \(\ell=f\) exclusion. \(\square\)

For the second entry, take \(\ell=b,j=y,H=f,Q=I=u\).
The two available zero-port phases in (4) are
\[
 X_1:\ bd_D,uo,fp,ay,cz;\qquad
 X_2:\ bd_D,up,fy,ao,cz.                                  \tag{8}
\]
The right row cannot use \(X_2\) as its zero-port slot:
its \(X_2\triangle Z\) shore difference contains the complete
\(H-f-y-J\) component, contrary to Note 297's required
\(EH\mid AJ\) pairing. Thus its zero-port slot is \(X_1\).
With \(J=y\) and \(bd_D\) selected, the right \(U(EJ)\) slot
has the unique local phase \(uo,fp,ax,cz\).

The right-row port loads at \(f,u,y\) are \(H:ZW\),
\(I:YV\), and \(J:ZU\). Since \(X_1,U\) both select
\(fp,uo,cz\), edge load two forces
\(fy:YV\), \(up:ZW\), \(cp:YV\), and \(cx:ZW\).
At \(y\), the \(J:ZU\) and \(fy:YV\) loads force
\(ay:XW\). At \(a\), slot \(W\) therefore cannot
use \(ax,ao\). Slot \(Z\) uses \(cx\), so it cannot
use \(ax\) and must use \(ao\). The shore difference \(X_1\triangle Z\)
now contains the complete path
\[
                         H-f-p-u-o-a-y-J,                    \tag{9}
\]
again contradicting \(EH\mid AJ\). Reflection excludes
\((f,z,b,I,x)\). \(\square\)

## The left four-port route excludes the adjacent A placement

Take \(\ell=b,j=x,H=u,Q=A=f\). The zero-port slot \(X_R\)
again has the unique phase (5). The genuine left \((ea)(ac)\)
row has a four-port slot \(Z_L(EAID)\), which selects the
\(A\)-port at \(f\), the \(D\)-port at \(d_D\), and neither
\(H\) nor \(J\). Hence \(Z_L\) avoids \(bd_D\), and its
four vertices \(u,a,b,c\) must match into \(T\). Since
\(o,p,x\) have no usable third edge, its complete local list is
\[
\begin{array}{c|c}
Z_L\text{ edges in }S\!\text{--}\!T
  &\text{complete path in }X_R\triangle Z_L\\\hline
bo,up,ax,cz & D-d_D-b-o-u-p-f-A\\
bo,up,ay,cx & D-d_D-b-o-u-p-f-A\\
bz,uo,ax,cp & D-d_D-b-z-c-p-f-A\\
bz,up,ao,cx & D-d_D-b-z-c-x-a-o-u-p-f-A.
\end{array}                                                   \tag{10}
\]
Every path alternates between the two actual matchings and
is complete at its proper-port endpoints. But
[Note 302](302-the-right-zero-port-matching-forces-both-left-ad-opposite-fibres.md)
forces \(X_R\triangle Z_L\) to pair \(ED\mid AI\), never
\(AD\). Thus \((b,x,u,A,y)\) is impossible. Reflection
excludes \((f,x,u,A,z)\). \(\square\)

The same argument closes \(\ell=b,j=y,H=f,Q=A=u\).
The right row cannot use phase \(X_2\) of (8), because
\(X_2\triangle Z\) contains \(H-f-y-J\), independently
of whether \(Q=A\) or \(I\). Thus \(X_R=X_1\).
Now \(Z_L(EAID)\) selects the \(A\)-port at \(u\),
the \(D\)-port at \(d_D\), and no \(H,J\) port.
The four remaining \(S\)-vertices have precisely the
following local matchings; each gives a complete forbidden
\(DA\) path in \(X_1\triangle Z_L\):
\[
\begin{array}{c|c}
Z_L\text{ edges in }S\!\text{--}\!T
 &\text{complete path}\\\hline
bo,ax,fy,cp & D-d_D-b-o-u-A\\
bo,ay,fp,cx & D-d_D-b-o-u-A\\
bo,ay,fp,cz & D-d_D-b-o-u-A\\
bz,ao,fy,cp & D-d_D-b-z-c-p-f-y-a-o-u-A.
\end{array}                                                   \tag{11}
\]
This contradicts Note 302's \(ED\mid AI\) route and excludes
\((b,y,f,A,x)\); reflection excludes \((f,z,b,A,x)\).
\(\square\)

This proof uses actual perfect-matching switches and row edge
loads. It does not exclude the other entries in the table,
the other six-cut allocation \((\alpha,\eta)=(1,2)\), larger
Hall witnesses, incidence collisions, other shore profiles, or
Berge–Fulkerson. The derivation is hand-checked against the
cited complete-fibre arguments and has not had an independent
second-source check. The finite phase lists were derived by hand;
no computational enumeration or OMEN run was used.
