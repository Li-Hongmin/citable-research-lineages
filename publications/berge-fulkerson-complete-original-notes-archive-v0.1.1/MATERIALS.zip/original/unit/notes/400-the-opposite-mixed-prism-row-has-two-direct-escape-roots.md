> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The opposite mixed prism row has two direct escape roots

Keep the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\) and marks \(AC,Cc,bc,ab\). Consider an actual complete BF row of type \((e\,Cc)(e\,bc)\) in the exact-Case-XII orientation with forbidden \(e\)-labels \(Cc,ab\). Let its forbidden \(e\,Cc\)-triple \(P\) be rooted at \(c\), its allowed \(e\,bc\)-triple \(R\) at \(b\), and \(K\) be the singleton-\(bc\) occurrence. The two zero-port exterior triple masks are
\[
\begin{array}{c|c|c}
& (u_1,u_2,u_3,u_4,u_5)&(AC,Cc,bc,ab)\\\hline
P&(B,C,A,b,a)&(s,c,s,s)\\
R&(A,C,a,B,c)&(s,s,b,s).
\end{array}                                                   \tag{1}
\]
The shore order, cycle rank, complement parity and port-path lengths are unrestricted.

> **Direct escape and transfer gate.** The terminal path of \(R\triangle K\) starting at \(bc\) must end at \(AC\), and it is entirely exterior. It has exactly one of the two forms
> \[
> \begin{aligned}
> bc-t_{bc}-b-u_4-B-u_2-C-t_{AC}-AC,&&\text{the \(C\)-route},\\
> bc-t_{bc}-b-u_4-B-u_1-A-t_{AC}-AC,&&\text{the \(A\)-route}.
> \end{aligned}                                                  \tag{2}
> \]
> In particular \(K\) uses \(bu_4\), and either \(Bu_2,AC:C\) or \(Bu_1,AC:A\). Switching \(R,K\) along (2) produces an \(e\,AC\)-triple rooted, respectively, at \(C\) or \(A\), without changing its zero-port shore matching. In the \(C\)-route branch, any independent switch of \(P\) with the singleton-\(Cc\) occurrence that produces an \(e\,ab\)-triple rooted at \(a\) is impossible by [Note 399](399-the-direct-mixed-prism-root-pair-is-impossible-at-all-shore-orders.md).

**Proof.** The boundary ends of \(R\triangle K\) are \(bc,AC,Cc,ab\). If the \(bc\)-path ended at \(Cc\), switching \(R,K\) would give the forbidden \([e\,Cc]\) loop with the unchanged \(P\); if it ended at \(ab\), it would give a forbidden double-\(T\) row \((e\,Cc)(e\,ab)\). Hence it must end at \(AC\). At the marked subdivision \(t_{bc}\), \(K\) takes the terminal and \(R\) the \(b\)-half, so the path enters \(b\). The singleton \(K\) cannot use the \(bc:b\)-half at that same subdivision. If it used \(ab:b\), the path would immediately continue to terminal \(ab\), which is forbidden. Thus \(bu_4\in K\).

At \(u_4\), \(R\) uses \(Bu_4\), so the path reaches \(B\). The matching \(K\) covers \(B\) through \(Bu_1\) or \(Bu_2\). If it uses \(Bu_2\), the path follows \(u_2-C\), since \(R\) uses \(Cu_2\). There \(K\) can use only \(AC:C\) or \(Cc:C\). The latter would end at forbidden terminal \(Cc\), so \(AC:C\in K\) and the first path in (2) follows.

If \(K\) uses \(Bu_1\), the path follows \(u_1-A\), since \(R\) uses \(Au_1\). If \(K\) takes \(AC:A\), the second path in (2) follows. Otherwise \(K\) takes \(Au_3\). The path then reaches \(a\) through \(R\)'s \(au_3\). Taking \(ab:a\) would end at forbidden terminal \(ab\), so \(K\) must take \(au_5\); the path reaches \(c\) through \(R\)'s \(cu_5\). Since \(K\) already takes the terminal \(bc\), it cannot also use \(bc:c\) at \(t_{bc}\), and must take \(Cc:c\), ending at forbidden terminal \(Cc\). Thus the only allowed \(Bu_1\) branch is \(AC:A\). This proves the complete dichotomy, with no visit to the shore.

The switch on either path exchanges \(R\)'s terminal \(AC\) with \(K\)'s terminal \(bc\), so the new triple has state \(e\,AC\). In the first path it takes \(AC:C\), hence is rooted at \(C\); in the second it takes \(AC:A\), hence is rooted at \(A\). Finally, if an independent \(P\)--singleton-\(Cc\) switch also gives \(e\,ab:a\) in the first branch, the two new triple occurrences and the unchanged other four occurrences would be an actual BF row of the exact root pair ruled out by Note 399. The two switches act on disjoint pairs of matching occurrences, so they preserve every edge load and commute. \(\square\)

The first branch and the transfer condition are attained at the level of a genuine mixed row: in [Note 397's 25-vertex row](397-a-real-mixed-prism-row-satisfies-both-e-port-selectors.md), switch \(P,J\) along its exterior \(ab\)--\(Cc\) path and \(R,K\) along its exterior \(AC\)--\(bc\) path. Reading these switches backward gives (1), the \(C\)-route in (2), and an exterior \(Cc\)--\(ab\) switch rooted at \(a\). That pole has forbidden BF types, so this is sharpness for the **row-level** transfer and not an exact-Case-XII construction. [Note 401](401-the-opposite-prism-c-route-is-impossible-at-all-shore-orders.md) excludes the \(C\)-route under exact support, even when this first transfer is avoided; [Note 402](402-the-opposite-direct-mixed-prism-root-pair-is-impossible.md) excludes the \(A\)-route as well. The argument is hand-derived and awaits independent review.
