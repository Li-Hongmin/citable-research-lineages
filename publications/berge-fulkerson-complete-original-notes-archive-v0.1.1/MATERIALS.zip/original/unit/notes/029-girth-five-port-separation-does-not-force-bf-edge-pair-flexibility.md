> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth-five port separation does not force BF edge-pair flexibility

The local separation available in the terminal-tree smoothing of Note 022
does not repair the edge-pair flexibility statement.  There is a smallest
simple cubic girth-five graph with a structurally safe inverse expansion and
a pair of edges whose BF labels coincide in every BF cover.

The graph has order twelve and graph6 record

`K?ABEagE\`gH_`.

Its edge set is

\[
\begin{split}
&05,16,26,07,17,37,08,28,48,39,49,69,\\
&2\,10,3\,10,5\,10,1\,11,4\,11,5\,11.
\end{split}
\]

It is connected, simple, cubic, bridgeless and has girth five.  Designate

\[
e=05,\qquad f=69.
\]

Both endpoint groupings for reversing the cross smoothing are safe.  After
deleting \(e,f\), adding two new terminal-tree vertices, their four
attachment edges and the edge joining the two new vertices, either expanded
graph is again simple, cubic, bridgeless and of girth five.

Nevertheless \(e,f\) are BF-forced-intersecting.  The graph has ten perfect
matchings.  Exactly two of them contain either designated edge, and both
contain both edges:

\[
P_0=\{05,37,48,69,2\,10,1\,11\},
\]

\[
P_3=\{05,17,28,69,3\,10,4\,11\}.
\]

Thus a perfect matching contains \(e\) if and only if it contains \(f\).
In every six-matching BF cover,

\[
\phi(e)=\phi(f),\qquad |\phi(e)\cap\phi(f)|=2.
\]

Complete enumeration gives ten unordered BF-cover multisets, and every one
has intersection size two.

The order is minimal in the tested structural class.  Complete cubic
girth-five census counts at orders \(4,6,8,10,12\) are

\[
0,0,0,1,2.
\]

The order-ten Petersen graph has no independent edge pair whose inverse
two-vertex expansion preserves girth five.  Of the two order-twelve graphs,
one contains the forced safe pair above and the other has only flexible safe
pairs.

Hence simple cubicity, bridgelessness, girth five, and the full local
inverse-expansion port separation are insufficient to force disjoint BF
labels.  A positive theorem for the actual Case-XII reduction must use
additional global structure of a minimum BF counterexample or the complete
Case-XII exact admissible set.  This graph is not a Berge--Fulkerson
counterexample and does not exclude Case XII.

The complete streaming verifier is
`scratch/worker-verify/case_xii_separated_bf_pair_scan.py`; it terminates with
`CASE_XII_SEPARATED_BF_PAIR_COUNTEREXAMPLE_OK`.
