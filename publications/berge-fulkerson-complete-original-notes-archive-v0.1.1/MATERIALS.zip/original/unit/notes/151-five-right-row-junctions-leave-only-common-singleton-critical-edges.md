> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five right-row junctions leave only common-singleton critical edges

[Note 150](150-short-diamond-tait-anchors-force-an-external-critical-phase-edge.md) forces a critical \(p_{35}\cap Z_3\) edge outside the short theta core if the common \(B_2+C_4\) seed is absent. The right row's **single** junction outside the hexagon eliminates two of the three owner pairs left there: \(\{Z,r\}\) and \(\{Z,C\}\). Every surviving external collision is an inactive \(\{Z,Y\}\) edge shared literally by both class-three singleton occurrences, the right-row triple \(q_{25}\), and its canonical cross-half successor \(p_{35}\). This is a conditional full-mask conclusion, not an exact-Case-XII realization.

## Theorem

Use the normalized actual row, aligned right row, six-edge diamond, \(J'=5\), and canonical \(p=q\triangle E(P)\) of Note 150. The negative support is needed to force the \(2\leftrightarrow3\) path \(P\); the edgewise assertion below only needs that the specified row and path are actual. Write \(\Theta=\Omega\cup\chi\). Then
\[
\boxed{
\bigl(E(p)\cap E(Z)\bigr)\setminus E(\Theta)
\subseteq E(Y),
\qquad
p(a)=Z(a)=Y(a)=q(a)=1
\ \text{on every edge on the left}.}                       \tag{1}
\]
Such an edge has original owner pair \(\{Z,Y\}\), and is inactive in the three paired differences of both the original normalized row and the aligned right row.
It lies in \(q\triangle U\) but **not** on the canonical \(q\triangle r\) path \(P\): on it \(q=p=1\), whereas switching \(P\) would remove the \(q\)-edge. Thus it belongs either to the forced \(2\leftrightarrow3\) component of \(q\triangle U\) or to one of that pair's closed phase components. It cannot belong to the \(1\leftrightarrow4\) component of \(U\triangle Z\), where \(q=U\) by the boundary identities of Note 143.

More generally, on **every other closed component** \(F\ne\Omega\) of \(Z\triangle Y\), the complete matching choices at each incident vertex satisfy
\[
q|_{V(F)}=p|_{V(F)}=U|_{V(F)},
\qquad B|_{V(F)}=Z|_{V(F)}.                             \tag{2}
\]
Here restriction to vertices means the incident matching edge at each vertex, including a possible edge leaving \(F\). Thus the critical cycles of \(U\triangle p\) avoid every movable singleton phase component outside \(\Omega\); their external \(Z\)-collisions can only use common \(ZY\) edges.

Consequently, if the common \(B_2+C_4\) seed is absent, the pairing-critical edge supplied by Note 150 has owner pair **exactly** \(\{Z,Y\}\). In the bypass branch of patterns \((2,2,1,1)\), \((2,1,2,1)\), and \((1,1,2,2)\), one pairing-critical cycle contains at least two distinct such exterior edges, by Note 150's two-external-edge corollary. The fourth pattern \((1,2,1,2)\) currently forces one.

## Proof

Outside \(\Theta\), the four-junction normalization makes every original row edge split between \(\{U,Z,D\}\) and \(\{r,Y,C\}\). Hence an edge of \(p\cap Z\) outside \(\Theta\) has one of the owner pairs \(\{Z,r\},\{Z,Y\},\{Z,C\}\). Indeed \(p\le q+r\) edgewise and \(q+B=U+Z\); these are also the carrier profiles of [Note 138](138-pairing-change-forces-an-unalignable-cycle-with-a-three-edge-owner-certificate.md).

Pair the right-row occurrences as in [Note 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md):
\[
E'_1=(q,Y),\qquad E'_2=(B,C),\qquad E'_3=(D,r).       \tag{3}
\]
Exactly four of its five junctions lie on \(\Omega\). Neither a \(\{Z,r\}\) nor a \(\{Z,C\}\) edge outside \(\Theta\) is incident with a vertex of \(\Theta\): by Note 146's four owner sequences and chord identity, the owner pairs on edges **leaving** \(\Theta\) belong to \(\{Dr,UC,DC,Ur,ZY\}\). The \(UD\) third edge at either chord endpoint belongs to \(\Theta\) itself. Thus both endpoints of an exterior \(\{Z,r\}\) or \(\{Z,C\}\) edge are outside \(\Omega\).

Let \(a\notin\Theta\) have owners \(\{Z,C\}\). At either endpoint the other two owner pairs are \(\{Y,D\}\) and \(\{U,r\}\): it lies on a junction-free type-\(23\) strand of the original paired network. If \(q(a)=1\), the carrier equality makes \(B=U\) at both endpoints. There \(q,Y\) use the \(ZC,YD\) edges respectively, \(B,C\) use \(Ur,ZC\), and \(D,r\) use \(YD,Ur\). All three pairs in (3) choose distinct edges, so **each endpoint** is an exterior right-row junction. That would give at least six right-row junctions, contrary to \(J'=5\). Hence \(q\) uses no \(ZC\) edge on an external type-\(23\) component. At every vertex of that component it uses the \(Ur\) third edge, so \(q=r=U\) there and the canonical \(q\triangle r\) path avoids it. Thus \(p=q=U\) at every such vertex, proving (2) for type \(23\) and excluding every exterior \(\{Z,C\}\) collision.

Let \(a\notin\Theta\) have owners \(\{Z,r\}\). Its other two endpoint pairs are \(\{U,Y\}\) and \(\{D,C\}\): it lies on a junction-free type-\(12\) component of the original network. If \(q(a)=1\), then \(B=U\) at both ends, and the three pairs in (3) use respectively \((Zr,UY)\), \((UY,DC)\), and \((DC,Zr)\). Both endpoints are exterior right-row junctions, again impossible. Thus \(q(a)=0\) and \(B(a)=1\). The entire component of \(Z\triangle Y\) containing \(a\) is a closed even type-\(12\) cycle with alternating owner pairs \(Zr,UY\): it has no original junction outside \(\Omega\) and cannot meet \(\Omega\) through a type-\(12\) port. Since \(q+B=U+Z\), the restriction of \(q\) to this cycle is one of its two alternating perfect matchings. Its avoidance of \(a\) forces \(q=U\) throughout the cycle, while \(r=Z\) there. The cycle is therefore a **closed component** of \(q\triangle r\). The canonical terminal path \(P\) does not switch it, so \(p=q=U\) throughout the cycle. This proves (2) for type \(12\) and excludes every exterior \(\{Z,r\}\) collision.

Only \(\{Z,Y\}\) remains. Here \(r(a)=0\), so \(p(a)=1\) implies \(q(a)=1\) by \(p\le q+r\). Both singleton occurrences use \(a\) by definition; thus \(p=q=Z=Y=1\). The edge is inactive in the original pairing because \(Z,Y\) are one paired occurrence, and inactive in the right pairing because \(q,Y\) share it. This proves (1). \(\square\)

The proper edges owned \(\{Z,Y\}\) at interior chord vertices already lie outside \(E(\Theta)\); the theorem does **not** claim that every such edge is pairing-critical or lies away from those chord ports. The remaining exact Case-XII question is whether an exterior common-singleton edge can lie on the required pairing-changing cycle while the same full matching family realizes every positive cell and avoids every forbidden type. The 2026 [Proposition 4.4 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) classify boundary support but do not settle this complete-mask condition.

The edgewise argument does not use the length six itself. For any normalized aligned four-junction diamond with an even phase cycle of length \(L\), [Note 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) gives \(J'_\Omega=L-2\). Whenever equality holds in its bound \(J'\ge L-1\), there is just one right-row junction outside \(\Omega\). The same proof gives (1) and (2) for its canonical forced \(q\triangle r\) path. Length six and the Tait anchors of Note 150 enter only when converting that phase rigidity into a **pairing-critical** common-singleton witness.

The count also identifies the boundary at higher junction number. Using the oddness of \(J'\) from Note 143, an exterior \(ZC\) edge used by \(q\) forces \(J'\ge L+1\): its two endpoints are junctions and at least one further exterior junction is needed for parity. If \(q\) takes the \(Z\)-phase on an exterior type-\(12\) cycle \(F\), every vertex of \(F\) is a right-row junction, forcing \(J'\ge L+|V(F)|-1\). Thus the eliminations above are consequences of **minimal** right-row junction count; they are not asserted for larger \(J'\).
