> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The remaining f-based five-block fixes the left HJ phase

Continue the real exact-Case-XII left and right rows in the
five-vertex Hall block (1) of [Note 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md).
Take \(\ell=b\), \(j=z\), \(H\) based at \(f\), and
\(Q\in\{A,I\}\) based at \(u\). This is one of the local
placements still allowed by Note 321. The right row's zero-port
slot \(X_R\) has the unique block phase
\[
              X_R:\quad bd_D,uo,fp,ax,cz;
                       \qquad y\text{ uses its third edge}.     \tag{1}
\]
Use [Note 301's complete-fibre rule](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md):
every actual \(HJ,g,t_{ew}\) shore matching has complement
pairing \(EI\mid AD\). Every zero-port \((g,t_{ew})\)
matching has pairing \(EA\mid ID\mid HJ\) by Note 321.

**Theorem.** Every actual \(HJ,g,t_{ew}\) shore matching \(L\)
in this placement avoids \(bd_D\) and has precisely the
following local phase:
\[
            L:\quad Hf,Jz,bo,up,ay,cx.                     \tag{2}
\]
In particular the left row's two singleton-\(a\) slots
\(Y_L,V_L\) have identical *block* phases, although their
complete shore matchings need not coincide. The left row's
zero-port and four-port slots are then forced locally to
\[
\begin{aligned}
 X_L&:\quad bd_D,uo,fp,ax,cz,
                  \qquad y\text{ uses its third edge},\\
 Z_L&:\quad Q u,Dd_D,ao,bz,cp,fy,
                  \qquad x\text{ uses its third edge}.
\end{aligned}                                                   \tag{3}
\]
Furthermore, the genuine right row excludes \(Q=A\); hence
\(Q=I\) in this \((\ell,j,H)=(b,z,f)\) placement.
The conclusion also holds after reflecting
\((a,b,o,y)\leftrightarrow(c,f,p,z)\).

**Proof.** An \(HJ\)-port matching selects \(H\) at \(f\)
and \(J\) at \(z\). If it avoids \(bd_D\), its only
block phase is (2). If it uses \(bd_D\), direct matching of
\(o,p\) and the remaining \(T\)-vertices gives exactly
\[
\begin{array}{c|c}
\text{phase}&\text{selected edges besides }Hf,Jz\\\hline
L_1&bd_D,uo,cp,ax;\quad y\text{ uses its third edge}\\
L_2&bd_D,uo,cp,ay;\quad x\text{ uses its third edge}\\
L_3&bd_D,up,ao,cx;\quad y\text{ uses its third edge}.
\end{array}                                                   \tag{4}
\]

For \(L_2\), the complete \(H\)--\(J\) component of
\(L_2\triangle X_R\) is \(H-f-p-c-z-J\). Switching it
in \(L_2\) creates an actual zero-port \((g,t_{ew})\)
matching with selected block edges
\(bd_D,uo,fp,ay,cz\) and third edge at \(x\).
But Note 321's complete zero-port phase table requires the
third-edge position \(y\) when \((\ell,j,H)=(b,z,f)\).
Thus \(L_2\) is impossible.

For \(L_1\), the complete \(H\)--\(J\) component of
\(L_1\triangle X_R\) is \(H-f-p-c-z-J\).
For \(L_3\), it is
\[
                       H-f-p-u-o-a-x-c-z-J.                \tag{5}
\]
In either case switching this component in \(L_i\) yields an
actual zero-port matching \(N_i\) with the local phase (1).
The switch leaves every shore edge outside the displayed
component unchanged, including the third edges at \(x,y\),
the edge \(bd_D\), and the marked edges \(g,t_{ew}\).

In the complement of each \(L_i\), \(i=1,3\), the
\(Q\)-path reaches the unselected third edge at \(x\):
\[
\begin{array}{c|l}
L_1&Q-u-p-f-y-a-o-b-z-c-x\\
L_3&Q-u-o-b-z-c-p-f-y-a-x.
\end{array}                                                   \tag{6}
\]
The complement of \(N_i\) reaches that same edge through
\(Q-u-p-c-x\). Their continuation outside \(S\cup T\)
is identical. If \(Q=A\), Note 301 requires this continuation
to end at \(D\) for \(L_i\), whereas Note 321 requires it
to end at \(E\) for \(N_i\). If \(Q=I\), the required
ends are \(E\) and \(D\), respectively. Both are
impossible. Hence only (2) remains.

In the left row, the two \(HJ\) occurrences \(Y_L,V_L\)
therefore both select the block edges \(bo,up,ay,cx\).
These four edges, as well as the \(H,J\) port edges, have
their full load two in slots \(Y_L,V_L\).
The \(D\)-port edge has slots \(Z_L,W_L\), so at \(b\)
the edge \(bd_D\) has slots \(X_L,U_L\) and \(bz\)
has slots \(Z_L,W_L\). Vertex by vertex, load two now
forces
\[
\begin{array}{c|ccccccc}
\text{edge}&cz&cp&fp&fy&y\text{-third}&uo&ax\\\hline
\text{slots}&X_LU_L&Z_LW_L&X_LU_L&Z_LW_L&X_LU_L
             &X_L\,*&X_L\,*.
\end{array}                                                   \tag{7}
\]
For the last two entries, the partner is \(W_L\) when
\(Q=A\), and \(U_L\) when \(Q=I\): the \(Q\)-port
edge has slots \(Z_LU_L\) or \(Z_LW_L\), respectively.
At \(o\) and \(a\), this also gives \(ao\in Z_L\);
at \(x\), it gives the third edge \(x\text{-third}\in Z_L\).
Thus the \(X_L,Z_L\) phases are exactly (3). \(\square\)

## The right row excludes Q=A

Suppose \(Q=A\) at \(u\). Write the right row as
\((X,Y,Z,U,V,W)\). Its proper-port loads are
\(A:ZW\), \(H:ZW\), and \(J:ZU\).
The \(U(EJ)\) matching selects \(bd_D\) by Hall
saturation. With \(J=z\) selected, its three possible
block phases, omitting \(bd_D\), are
\[
 U_1=\{uo,fp,ay,cx\},\quad
 U_2=\{uo,fy,ax,cp\},\quad
 U_3=\{up,fy,ao,cx\}.                                    \tag{8}
\]
If \(U=U_1\), edges \(uo,fp\) have slots \(XU\).
The port loads at \(u,f\) then put \(up,fy\) in
\(YV\); vertex \(p\) puts \(cp\) in \(ZW\).
Thus \(Z\) selects \(cp\).

If \(U=U_2\), \(uo:XU\) and hence \(up:YV\).
At \(f\), both \(Z,W\) select the \(H\)-port, while
\(X\) selects \(fp\) and \(U\) selects \(fy\).
The second use of \(fp\) must therefore be in \(Y\)
or \(V\). But both use \(up\) at \(p\), so neither
can use \(fp\). This phase is impossible.

If \(U=U_3\), the \(A:ZW\) load at \(u\) forces
\(uo\) to be shared by \(X\) and one of \(Y,V\),
and \(up\) by \(U\) and the other. The
\(H:ZW\) load at \(f\) similarly pairs each of
\(fp:X\) and \(fy:U\) with one of \(Y,V\).
At \(p\), the partner of \(up:U\) differs from
the partner of \(fp:X\), so the remaining edge
\(cp\) has slots \(ZW\). Again \(Z\) selects \(cp\).

For either \(U_1\) or \(U_3\), the actual
\(X\triangle Z\) shore difference consequently has
the complete component
\[
                         H-f-p-c-z-J.                         \tag{9}
\]
This contradicts [Note 297's right-row pure-path condition](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
\(EH\mid AJ\). Thus \(Q\ne A\), and \(Q=I\).
Reflection gives the same conclusion in the mirrored
placement. \(\square\)

This does not identify either complete left matching with a
right-row matching. In particular (3) fixes only the displayed
block edges; the outside matching and its path phases remain
free. The \(H=u\) placement with \(\ell=b,j=z\) is
excluded by [Note 323](323-no-u-based-five-block-in-the-right-dj-branch.md).
The \(\ell=u\) placements are excluded by
[Notes 324](324-no-side-j-five-block-with-a-central-d-edge.md)
and [325](325-no-central-j-five-block-with-a-central-d-edge.md).
The other six-cut allocation, larger Hall blocks, other shore
profiles, and Berge–Fulkerson remain open. The derivation is
symbolic and awaits independent
second-source checking; no local computation or OMEN was used.
