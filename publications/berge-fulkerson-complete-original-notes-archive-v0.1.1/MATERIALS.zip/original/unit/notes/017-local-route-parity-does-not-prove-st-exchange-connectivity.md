> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local route parity does not prove S--T exchange connectivity

The exchange-connectivity conjecture of Note 015 cannot be proved using only
the labels A, SS, TT and the parity or distance of same-class alternating
cycle exchanges.

Across all six S--T-active order-13 poles, shared-neighbour exchange triangles
realize route transitions

\[
\mathrm{A/A}:6,qquad \mathrm{A/SS}:6,qquad \mathrm{SS/SS}:5.
\]

Thus a genuine cubic-pole exchange can preserve or change the route label;
no nonconstant two- or three-colour invariant of just these labels propagates
through every exchange.

There is also an abstract connected graph \(W\) on eleven vertices with all
ten boundary classes, full \(K_{5,5}\) S--T quotient, a nontrivial same-class
exchange edge, an SS--exchange--SS triangle, and all six disjoint completion
edges labelled SS.  This is not a perfect-matching incidence system or cubic
pole, so it does not refute the pole-level conjecture.  It proves that
connectivity plus local labelled-graph rules are insufficient.

The complete 231-move neighbourhood of the 13-vertex seed gives 45 exact-S
order-15 poles.  All have S--T support.  Thirty-nine have disconnected active
exchange graph and route profile SS:7.  The other six are connected, and all
have unsafe routes: two have A:3,SS:6; two have A:7,SS:4,TT:2; and two have
A:8,SS:6,TT:3.  No connected all-SS real pole occurs.  The maximum S--T
support is 21 of 25, missing one four-cell column; both such poles are
connected and have A routes.

Accordingly the pole-level conjecture remains open and supported through the
tested family.  Any proof must retain the integer incidence/coverage equations
of the six perfect matchings in each completion, or compatibility among
different completion witnesses; route labels alone have lost too much data.

The exact programs are
`scratch/worker-kempe/exchange_route_transition_audit.py`,
`scratch/worker-kempe/verify_abstract_all_ss_exchange_w.py`, and
`scratch/worker-kempe/n15_local_exchange_conjecture_scan.py`.

