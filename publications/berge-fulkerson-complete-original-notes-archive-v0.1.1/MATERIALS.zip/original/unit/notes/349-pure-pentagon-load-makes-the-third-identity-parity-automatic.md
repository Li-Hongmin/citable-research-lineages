> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A pure pentagon load makes the third-identity path parity automatic

This corrects the separation of the residual tests in [Note 345](345-the-two-identity-bridge-has-an-exact-third-matching-gate.md). Let \(P\) be an integer half-load of a cubic five-pole, obtained from three perfect matchings and having load one on each terminal semiedge. Write \(\mathcal R(P)\) for the states of **all** its three-matching decompositions. Fix the allowed pentagon
\[
             S=e-a-b-d-c-e.
\]
Assume \(\varnothing\ne\mathcal R(P)\subseteq S\). In exact Case XII this purity follows for the pure half of any row with an opposite \(T\)-state half by [Note 055](055-half-load-column-saturation-and-case-xii-compression.md).

**Fixed-singleton parity theorem.** Let \(C_c\) be any complete singleton-\(c\) perfect matching with \(C_c\le P\) edgewise. If every closed component of the edge-copy residual \(R=P-C_c\) is even, then its two terminal paths are exactly
\[
             d\longleftrightarrow e\quad\text{(even proper length)},
             \qquad a\longleftrightarrow b\quad\text{(odd proper length)}. \tag{1}
\]
Moreover, \(P\) has **both** \(cd\)- and \(ce\)-state decompositions retaining the same complete matching \(C_c\).

**Proof.** The residual has degree two at every internal vertex and one copy of each of the terminal semiedges \(e,a,b,d\). Thus it consists of two open terminal paths and closed cycles, with labelled edge copies retained when an edge has residual multiplicity two. The five-pole has odd internal order: \(3|V|=2|E_{\rm proper}|+5\). Every even closed residual cycle uses an even number of vertices. If the two open paths have \(k_1,k_2\) proper-edge copies, they use \(k_1+1,k_2+1\) vertices, so \(k_1+k_2\) is odd. Exactly one path has even proper length.

Alternate two colours on all components. On the odd-length terminal path, give both terminal ends the triple colour. On the even-length path, give one terminal end the singleton colour and the other the triple colour. Either choice of singleton end extends consistently to proper alternating colours on both paths and every even closed cycle. Hence the two endpoints \(p,q\) of the even path give **two actual decompositions of the same \(P\) containing \(C_c\)**, with states \(cp,cq\). Purity forces both states into \(S\). The only two neighbours of \(c\) in \(S\) are \(d,e\), so \(\{p,q\}=\{d,e\}\). The other path joins \(a,b\) and has odd proper length. This proves (1) and both decompositions. \(\square\)

**Corrected third-identity gate.** In Note 345, take \(P=P^V=X+Y+V\) and let \(C_c\) range over the singleton-\(c\) candidates obtained from the \(e\to c\) path of \(U\triangle V\) (or use the symmetric choice of \(Z,V\)). The cross-carrier third identity exists **if and only if** at least one candidate satisfies just:

1. \(C_c\le P\) on every edge and semiedge;
2. every closed component of \(P-C_c\) is even.

The terminal-path test listed separately in Note 345 follows automatically from these two conditions and purity; its proposed test-1–2-pass/test-3-fail branch cannot occur. Thus, after an actual \(e\to c\) bridge, failure to synchronize the third identity has only two residual causes: an unavoidable unsafe owner edge on the mandatory path, or an odd closed residual cycle for every owner-safe cycle phase. Even if the third identity synchronizes, [Note 344's triple-hit condition](344-a-fixed-singleton-load-has-an-exact-two-state-fibre.md) can still obstruct an all-terminal BF cover. This is an exact simplification of the real full-matching gate, not an exclusion of exact Case XII.
