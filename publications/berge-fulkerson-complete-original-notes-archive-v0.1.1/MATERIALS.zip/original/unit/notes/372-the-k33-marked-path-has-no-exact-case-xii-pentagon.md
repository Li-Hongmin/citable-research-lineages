> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(K_{3,3}\) marked path has no exact-Case-XII pentagon

Continue the \(K_{3,3}\) five-vertex tree exterior of [Notes 368](368-the-crossed-k33-marked-path-has-no-case-xii-row.md)–[371](371-the-separated-marked-pairs-leave-only-the-path-ends.md): the bipartition is \(\{x,y,z\}\sqcup\{r,s,t\}\), tree edges \(xr,xs,xt,yr,zs\) have subdivisions \(u_0,\ldots,u_4\) and ports \(p_0,\ldots,p_4\), and the exterior marks are \(a=ys,b=yt,c=zt,d=zr\). Those notes exclude ten of the twelve labelled Case-XII pentagons on this exterior. The remaining two have \(e\)-neighbour pair \(\{a,d\}\):
\[
\begin{array}{c|c}
S_5=e-a-b-c-d-e&T_5=\{ac,ad,eb,ec,bd\},\\
S_6=e-a-c-b-d-e&T_6=\{ab,ad,eb,ec,cd\}.
\end{array}                                                   \tag{1}
\]
For either pentagon, the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ad)\) row: relabel the cycle as \((e,a,b,c,d)=(3,1,4,2,5)\) or \((e,a,c,b,d)=(3,1,4,2,5)\), so this row is \((13)(15)\). Every double-\(T_i\) row is forbidden.

**Theorem.** A cubic five-pole with this fixed \(K_{3,3}\) path exterior cannot have complete exact-Case-XII support, regardless of the six-port shore order or cycle rank. In particular, all twelve labelled pentagons on this exterior are excluded.

**Proof.** Fix \(S_i\) from (1) and a required \((ea)(ad)\) BF row. Name the state-\(ea\) triple \(P\), state-\(ad\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(d\) matching \(D\), and the two singleton-\(a\) occurrences \(A_1,A_2\). Their terminal sets are \(bcd,bce,e,d,a,a\). The shore quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes \(P\) zero-port, and [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) roots its \(a\)-half at \(y\) or \(s\). Switching \(P\) with either \(A_j\) must give state \(ed\in S_i\): the other candidates \(eb,ec\) lie in \(T_i\) beside \(R=ad\in T_i\). By [Note 244's argument](244-every-shore-mark-must-neighbour-the-internal-mark.md), this \(a\)--\(d\) terminal path is wholly exterior.

**Root \(y\).** Here \(P\) uses \(t_ay,ru_3,xu_0,su_1,tu_2,zu_4\). The only \(a\)--\(d\) paths are the direct route
\[
H:a-t_a-y-u_3-r-t_d-d
\]
and the route through \(r,u_0,x,u_1,s,u_4,z\). On the latter, a singleton \(A_j\) has already matched both \(y,z\); it would have to cover \(t_b,t_c\) through their \(t\)-halves, matching \(t\) twice. Hence both \(A_j\) use \(H\). Each then uses \(t_bt,t_cz,t_dr,yu_3\). Load two at the marked subdivisions and at \(y\) forces
\[
E:\ t_as,t_by,t_ct,t_dz,
\qquad D:\ t_as,t_by,t_ct,
\qquad R:\ t_ay,t_dz.                              \tag{2}
\]
The only remaining exterior choices of \(E\) are one edge at \(r\), \(ru_0\) or \(ru_3\), and one at \(x\), \(xu_0,xu_1\) or \(xu_2\), with \((ru_0,xu_0)\) impossible because they meet at \(u_0\). Switch \(P,A_1\) along \(H\), obtaining a state-\(ed\) triple \(P'\) with the same complete shore matching \(Q=P|_Z\). Directly following \(P\triangle E\) and \(P'\triangle E\) gives the exterior endpoints below; port lists follow the terminal order in the headings.

| \(E\)'s edges at \(r,x\) | Before \(H\): \(P\triangle E\), \(b,c,d\) | After \(H\): \(P'\triangle E\), \(a,b,c\) |
|---|---|---|
| \(ru_3,xu_0\) | \(p_1,p_2,p_4\) | \(p_1,p_4,p_2\) |
| \(ru_3,xu_1\) | \(p_0,p_2,p_4\) | \(p_0,p_4,p_2\) |
| \(ru_3,xu_2\) | \(p_1,p_0,p_4\) | \(p_1,p_4,p_0\) |
| \(ru_0,xu_1\) | \(p_3,p_2,p_4\) | \(p_4,p_3,p_2\) |
| \(ru_0,xu_2\) | \(p_1,p_3,p_4\) | \(p_1,p_3,p_4\) |

For \(S_5\), the old \(e\)-path must end at \(b\), since \(ab\in S_5\) while \(ac,ad\in T_5\). In every row of the table the same shore \(e\)-path then ends at \(a\) or \(b\) after \(H\), giving \(ad\in T_5\) or \(bd\in T_5\) beside \(R\). For \(S_6\), the old \(e\)-path must end at \(c\). Four rows leave it at \(c\), giving \(cd\in T_6\). Only \((ru_0,xu_2)\) leaves it at \(b\), an allowed \(bd\) state.

In that last case, the \(d\)-terminal path of \(P'\triangle D\) must end at \(a\); ending at \(b\) or \(c\) would give \(eb\) or \(ec\) beside \(R\). Since \(D\) uses \(t_as,t_by,t_ct\), the only exterior route to \(a\) forces \(D\) to use \(ru_0,xu_1\): the choices \(ru_3\) and \(ru_0,xu_2\) end at \(b,c\), respectively. Thus the \(d\)--\(a\) component is
\[
d-t_d-r-u_0-x-u_1-s-t_a-a.                         \tag{3}
\]
The table forces the \(e\)--\(b\) component of \(P'\triangle E\) to use shore pair \(ep_3\) and exterior leg \(p_3-u_3-y-t_b-b\). It is disjoint outside the shore from (3). Switch \(P',E\) along it, making a state-\(bd\) triple \(P''\). Component (3) remains in \(P''\triangle D\); switching it gives \(ab\in T_6\) beside \(R=ad\in T_6\), a contradiction. This excludes root \(y\) for both pentagons.

**Root \(s\).** Now \(P\) uses \(t_as,xu_1,zu_4,ru_0,tu_2,yu_3\). The only possible \(a\)--\(d\) routes are
\[
J:a-t_a-s-u_4-z-t_d-d,
\qquad K:a-t_a-s-u_1-x-u_0-r-t_d-d.             \tag{4}
\]
On \(J\), a singleton \(A_j\) must use \(t_by,t_ct,t_dz,su_4\). On \(K\) it uses \(t_dr,su_1,xu_0\) and is of one of two subtypes:
\[
K_y:\ t_by,t_ct,zu_4;
\qquad K_t:\ t_bt,t_cz,yu_3.                     \tag{5}
\]
Both \(K_y\) occurrences would overload \(zu_4\) with \(P\), and both \(K_t\) would overload \(yu_3\) with \(P\). If both occurrences use \(J\), or one uses \(J\) and the other \(K_y\), they saturate \(t_ct\), forcing \(D\) onto \(t_cz\). Switching \(P\) along \(J\) gives a state-\(ed\) triple using \(t_dz\). Its symmetric difference with \(D\) contains the exterior \(d-t_d-z-t_c-c\) path, giving \(ec\in T_i\) beside \(R\). Therefore the only remaining combinations are \(J+K_t\) and \(K_y+K_t\).

For \(J+K_t\), the same direct \(d\)--\(c\) switch rules out \(D\) on \(t_cz\), so \(D\) uses \(t_ct\), hence \(t_by\); \(E\) uses \(t_bt,t_cz\). Loads at \(y,a,z,r\) give
\[
E:\ t_ay,t_bt,t_cz,t_dr,
\qquad D:\ t_as,t_by,t_ct,zu_4,
\qquad R:\ t_ay,t_dz.                            \tag{6}
\]
Switching \(P\) with \(K_t\) gives a state-\(ed\) triple rooted at \(r\). For its \(d\)-path with \(D\) to end at the only allowed mark \(a\), \(D\) must use \(ru_0,xu_1\): taking \(ru_3\) ends at \(b\), and taking \(ru_0,xu_2\) ends at \(c\). Edge loads now force \(R\) onto \(ru_3,xu_0\) and \(E,J\) onto \(xu_2\). The singleton \(E\) matches \(s\) through either \(su_1\) or \(su_4\). Let \(P_J,P_K\) be the state-\(ed\) triples obtained by switching \(P\) along \(J,K_t\), respectively. Their shore restriction is again \(Q\).

| \(E\)'s edge at \(s\) | \(P\triangle E\): \(b,c,d\) | \(P_J\triangle E\): \(a,b,c\) | \(P_K\triangle E\): \(a,b,c\) |
|---|---|---|---|
| \(su_1\) | \(p_3,p_4,p_0\) | \(p_3,p_4,p_0\) | \(p_3,p_0,p_4\) |
| \(su_4\) | \(p_1,p_3,p_0\) | \(p_3,p_1,p_0\) | \(p_3,p_0,p_1\) |

For \(S_5\), the old \(e\)-path ends at \(b\). The \(J\)-switch makes it end at \(a\) when \(E\) uses \(su_1\), or at \(b\) when it uses \(su_4\), giving \(ad,bd\in T_5\). For \(S_6\), it originally ends at \(c\). With \(E\) on \(su_1\), the \(K_t\)-switch leaves it at \(c\), giving \(cd\in T_6\); with \(E\) on \(su_4\), the \(J\)-switch moves it to \(a\), giving \(ad\in T_6\). Thus \(J+K_t\) is impossible.

For \(K_y+K_t\), the marked-edge loads force \(E\) onto \(t_as,t_by,t_ct,t_dz\) and \(D\) onto \(t_ay,t_bt,t_cz\). At \(x\), the two \(K\)-matchings saturate \(xu_0\), while \(P\) uses \(xu_1\). Since \(R\) uses \(tu_2\), it must take \(xu_1\), and \(E,D\) take \(xu_2\). Write \(P_K\) for the state-\(ed\) triple obtained by switching along either \(K\); both have the same exterior restriction and shore matching \(Q\). The two possible edges of \(E\) at \(r\) give:

| \(E\)'s edge at \(r\) | \(P\triangle E\): \(b,c,d\) | \(P_K\triangle E\): \(a,b,c\) |
|---|---|---|
| \(ru_0\) | \(p_3,p_1,p_4\) | \(p_1,p_3,p_4\) |
| \(ru_3\) | \(p_0,p_1,p_4\) | \(p_1,p_4,p_0\) |

For \(S_6\), the old \(e\)-path ends at \(c\), and the \(K\)-switch makes it end at \(a\), giving \(ad\in T_6\). For \(S_5\), the old path ends at \(b\). If \(E\) uses \(ru_0\), the new path still ends at \(b\), giving \(bd\in T_5\). Only \(E\) on \(ru_3\) remains; there the new path ends at \(c\), giving the allowed \(cd\) state.

In this last configuration, \(P_K\triangle D\) must join \(d\) to \(a\). The singleton \(D\) uses \(t_ay,t_bt,t_cz,xu_2\), so choosing \(ru_0\) would instead join \(d\) to \(b\); hence it uses \(ru_3\), and the required exterior component is
\[
d-t_d-r-u_3-y-t_a-a.                            \tag{7}
\]
The \(e\)--\(c\) component of \(P_K\triangle E\) uses the shore pair \(ep_0\) and the exterior leg \(p_0-u_0-x-u_2-t-t_c-c\), disjoint outside the shore from (7). Switching \(P_K,E\) makes a state-\(cd\) triple, leaving (7) available with \(D\). Switching (7) then gives \(ac\in T_5\) beside \(R=ad\in T_5\), the final contradiction. \(\square\)

All exchanges above act on components of actual complete perfect matchings, retain BF edge load two, and use only one required row and its exchange descendants. Every spanning tree of \(K_{3,3}\) has degree multiset \((3,1,1)\) or \((2,2,1)\) on each bipartition side, since each side's tree degrees sum to five. The three resulting pairs of multisets are, up to automorphism, the double-star, the marked-path tree here, and the Hamilton-path tree. Thus this theorem and [Note 367](367-the-crossed-double-star-row-switches-to-a-forbidden-ab-loop.md) leave **only the Hamilton-path marking** among \(K_{3,3}\) exteriors, subject to the cited hand-proved row classifications. Triangular-prism exteriors, other five-pole profiles, general exact Case XII and the Berge--Fulkerson conjecture remain unresolved. The proof is analytic and has not received independent review; no local mathematical recomputation was used.
