> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A pairing change forces one unalignable alternating cycle

[Note 137](137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md) locates a terminal-pairing change between two actual class-\(35\) matchings. The complete six-matching row gives a sharper obstruction: **one cycle that changes the pairing cannot be assigned to any of the five other matching occurrences as a paired switch**. Failure of that assignment has a certificate on at most three edges of the same cycle. The result uses complete matching masks and the absence of \(T\)--\(T\) BF types; it does not assume that an exact-Case-XII pole exists.

## Componentwise companion theorem

Write \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole with no BF cover whose two missing-pair states lie in \(T\), including \(T\)-loops. Fix an actual row of complete perfect matchings
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.            \tag{1}
\]
Let \(P_{35}\) be any other actual matching with the same boundary as \(U_{35}\), and write its proper symmetric-difference cycles as
\[
U_{35}\triangle P_{35}=\Gamma_1\sqcup\cdots\sqcup\Gamma_k.   \tag{2}
\]
For every edge \(a\in\Gamma_i\cap P_{35}\), let \(L(a)\) be the **two occurrence labels** among
\[
\mathcal N=\{Z_3,D_5,r_{34},Y_3,C_4\}                      \tag{3}
\]
that cover \(a\) in (1). If
\[
\bigcap_{a\in\Gamma_i\cap P_{35}}L(a)\ne\varnothing
\quad\text{for every }i,                                  \tag{4}
\]
then the terminal path from \(5\) in \(P_{35}+D_5\) ends at \(1\).

Equivalently, if that path ends at \(2\) or \(4\), then some cycle \(\Gamma_i\) has
\[
\boxed{\bigcap_{a\in\Gamma_i\cap P_{35}}L(a)=\varnothing.} \tag{5}
\]
There are **two or three edges on this one cycle** whose owner labels already have empty intersection. For two edges the labels are disjoint pairs; if no two are disjoint, three labels form a triangle \(\{a,b\},\{a,c\},\{b,c\}\) on three occurrence names. The cycle in (5) can be chosen so that toggling it, after toggling some other cycles of (2), changes the \(5\)-terminal partner; hence it meets both open terminal paths at that stage.

## Proof

The \(U_{35}+D_5\) path from \(5\) ends at one of \(1,2,4\). Endpoints \(2,4\) give first-half states \(23,34\in T\) against the fixed \(T\)-state \(34\) of \(r_{34}+Y_3+C_4\), which is forbidden. Thus its endpoint is \(1\).

For a cycle \(\Gamma_i\), condition (4) means that one companion occurrence \(N_i\in\mathcal N\) owns **every** \(P_{35}\)-phase edge of \(\Gamma_i\). At either end of an adjacent \(U_{35}\)-phase edge, \(N_i\) already uses the incident \(P_{35}\)-phase edge; since \(N_i\) is a matching, it avoids that \(U_{35}\)-phase edge. Thus \(\Gamma_i\) alternates between \(U_{35}\) and \(N_i\), and swapping their colours on \(\Gamma_i\) gives two actual complete matchings with unchanged boundaries and pair load. Conversely, any such paired switch requires one label in every \(L(a)\). This is the one-replacement identity of [Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md), applied component by component.

Assume (4) for every cycle. Choose one aligned companion for each cycle and first switch all cycles whose chosen companion is **not** \(D_5\). The cycles are vertex-disjoint, so these switches commute even when the same companion is chosen more than once. They give another actual six-matching row
\[
U^*_{35}+Z'_3+D_5+r'_{34}+Y'_3+C'_4=2\mathbf1.       \tag{6}
\]
The first half still has state \(35\in S\), and the second still has state \(34\in T\). The negative support therefore forces the \(5\)-path in \(U^*_{35}+D_5\) to end at \(1\).

Each remaining cycle was assigned to \(D_5\). It is an entire closed alternating component of the original \(U_{35}+D_5\): at each of its vertices the two matching edges are precisely its two cycle edges. The earlier switches are vertex-disjoint from it, so it remains a closed component of \(U^*_{35}+D_5\). Toggling all those cycles in \(U^*_{35}\) alone yields \(P_{35}\), while the two open terminal paths of the sum with the **original complete** \(D_5\) remain untouched. Hence \(P_{35}+D_5\) still pairs \(5\) with \(1\), proving (4).

Now suppose its partner is \(2\) or \(4\). The contrapositive gives at least one unalignable cycle. Toggle all alignable cycles as above; the resulting matching still pairs \(5\) with \(1\). Toggle the remaining, unalignable cycles one at a time. The partner must change on one of them. A cycle missing either open terminal path could not change the pairing, so this unalignable critical cycle meets both paths. Finally, each \(L(a)\) has size two because \(U_{35}(a)=0\) and (1) has load two. If two labels are disjoint they already certify (5). Otherwise choose a label \(\{i,j\}\); since the total intersection is empty there is a label missing \(i\), necessarily \(\{j,k\}\), and a label missing \(j\), necessarily \(\{i,k\}\) to avoid a disjoint pair. These three labels certify (5). \(\square\)

## Exact Case-XII consequence

From any right \((25)(34)\) row in [Note 137](137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md), the forced within-half switch gives (1), with \(U_{35}=u_{35}\) and \(Z_3=q_{25}+B_2-u_{35}\). The forced cross-half switch gives \(P_{35}=p_{35}\). If no common complete \(B_2,C_4\) seed exists, [Note 136](136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md) makes the \(P_{35}+D_5\) endpoint \(4\), so (5) holds **for every right row and every pair of closed-component phases**. This supplies a single real alternating cycle with both a terminal-path crossing and a two- or three-edge complete-owner obstruction.

In the same-side \(5+0\) branch that cycle avoids both exceptional edges by Note 137. By the closed-factor localization there, it cannot lie wholly in an attached closed two-sum factor. The theorem does not forbid its occurrence in an indecomposable exact-Case-XII pole. The remaining decision is whether full exact support constrains the two- or three-edge owner pattern on such a cycle strongly enough to force a companion, a forbidden BF type, or a common seed.

## The carrier restricts both certificate types

For the particular Case-XII row, write \(q=q_{25}\), \(B=B_2\), \(r=r_{34}\), \(U=u_{35}\), \(Z=Z_3\), and \(P=p_{35}\). Besides (1), the two forced switches give complete-mask identities
\[
q+B=U+Z,\qquad q+r=P+t_{24}.                         \tag{7}
\]
On every \(P\)-phase edge \(a\) of \(U\triangle P\), one has \(U(a)=0\) and \(P(a)=1\). Consequently its owner pair has exactly one of the following forms, where \(x\in\{D_5,Y_3,C_4\}\):
\[
\begin{array}{c|c|c}
L(a)&(q(a),B(a),r(a))&\text{carrier description}\\\hline
\{Z,x\}&(1,0,0)&q\text{-only}\\
\{r,x\}&(0,0,1)&r\text{-only}\\
\{Z,r\}&(1,0,1)\text{ or }(0,1,1)&\text{overlap}.
\end{array}                                                   \tag{8}
\]
Indeed, \(P\le q+r\) by (7), while \(Z=q+B\) on \(P\)-phase edges. Both \(Z\) and \(r\) are among the five companions, and row (1) leaves exactly two owners. If \(L(a)=\{Z,x\}\), then \(r=0\), so \(q=1\) and \(B=0\); if \(L(a)=\{r,x\}\), then \(Z=q+B=0\), so \(q=B=0\). The remaining possibility has \(Z=r=1\), giving the two overlap profiles in (8).

Thus an unalignable cycle necessarily contains **both** a \(q\)-only edge and an \(r\)-only edge. Its two-edge certificate, when present, has the precise form
\[
\{Z,x\},\ \{r,y\},\qquad x\ne y,
\quad x,y\in\{D_5,Y_3,C_4\}.                         \tag{9}
\]
If no two labels are disjoint, its three-edge certificate has the form
\[
\{Z,x\},\ \{r,x\},\ \{Z,r\}
\quad\text{for one }x\in\{D_5,Y_3,C_4\}.             \tag{10}
\]
In particular, the triangle case needs an edge where \(r\) overlaps \(q\) or \(B\); a cycle on which these overlap profiles are absent has a disjoint two-edge certificate.

Choose the switches in (7) with **no optional closed-component flips**. Then \(q\triangle U\) is exactly the forced \(2\leftrightarrow3\) path in \(q+B\), and \(q\triangle P\) is exactly the forced \(2\leftrightarrow3\) path in \(q+r\). Every \(q\)-only edge in (8) lies on the first path, and every \(r\)-only edge lies on the second. Therefore, if no common seed exists, the critical cycle furnished above can be chosen to contain an edge of **each of these two forced paths**, while also meeting both open terminal paths of an intermediate matching plus \(D_5\). This four-path incidence condition uses the canonical choice with no optional closed flips.

There is a further restriction from the two open paths at the instant a cycle \(\Gamma\) becomes critical. Let \(V\) be the intermediate class-\(35\) matching before toggling \(\Gamma\); on this as-yet untoggled cycle, \(V=U\). The \(U\)-phase edges of \(\Gamma\) joined by \(D_5\)-owned \(P\)-phase edges belong to one component of \(V+D_5\). If \(D_5\) owned all but at most one \(P\)-phase edge of \(\Gamma\), those links would connect **all** its \(U\)-phase edges, whereas a critical cycle must meet two different open components. Hence at least two \(P\)-phase edges of \(\Gamma\) avoid \(D_5\). For a critical six-cycle, \(D_5\) owns at most one of its three \(P\)-phase edges; a triangle certificate (10) on that six-cycle therefore has \(x=Y_3\) or \(x=C_4\), never \(x=D_5\). More generally, if no two labels are disjoint and the triangle has \(x=D_5\), then every \(D_5\)-free label must be \(\{Z,r\}\), so the critical cycle contains at least two of the overlap edges in (8).

If the two edges in (9) happen to be consecutive \(P\)-phase edges of that cycle, let \(h\) be the \(U\)-phase edge between them and let \(z\) be the third name in \(\{D_5,Y_3,C_4\}\setminus\{x,y\}\). The six edge colours partition at each cubic vertex, so \(h\) has owner pair \(\{U,z\}\), and the third incident edges at its two ends have owner pairs \(\{r,y\}\) and \(\{Z,x\}\), respectively. Moreover \(h\in B\): at the \(q\)-only end, \(q\) uses its \(P\)-phase edge, whereas \(U\) uses \(h\), forcing \(B\) to use \(h\) in \(q+B=U+Z\). This local crossing does not require the certificate edges to be consecutive, and by itself supplies no forbidden BF type; the remaining issue is the global connection of these paths in the complete matching family.
