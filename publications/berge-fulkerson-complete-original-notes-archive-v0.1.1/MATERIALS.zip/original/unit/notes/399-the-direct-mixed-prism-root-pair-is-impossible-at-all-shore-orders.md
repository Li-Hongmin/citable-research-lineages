> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct mixed prism root pair is impossible at every shore order

Use the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\), with marks \(AC,Cc,bc,ab\) and sixth shore port \(e\). Assume a complete actual six-perfect-matching BF row of type \((e\,ab)(e\,AC)\), whose forbidden \(e\,ab\)-triple \(P\) is rooted at \(a\) and whose allowed \(e\,AC\)-triple \(R\) is rooted at \(C\). Assume the **complete** BF boundary support is exact Case XII, with forbidden \(e\)-labels \(ab,Cc\). No shore order, cycle-rank, complement-parity or path-length restriction is made.

> **All-order root-pair exclusion.** No such BF row exists for either allowed pentagon orientation. This excludes the specified pair of exterior roots in an exact-Case-XII two-spoke-prism pole. It does not exclude the other roots or the whole exterior profile.

**Proof.** [Note 396](396-the-mixed-prism-root-pair-has-one-pentagon-and-two-exterior-masks.md) excludes the orientation \(S_{Cc}=e-AC-Cc-ab-bc-e\). Thus suppose
\[
S=S_{ab}=e-AC-ab-Cc-bc-e.                               \tag{1}
\]
Name the singleton-\(e\) occurrence using \(Bu_2\) by \(E\), the one using \(Bu_4\) by \(F\), and the singleton-\(AC\) occurrence by \(K\). The necessary first shore pairing is \(e\,p_4\) in \(R\triangle E\). Switch this complete \(e\)--\(ab\) path between \(R,E\), obtaining a triple \(R_1\) in the allowed state \(AC\,ab\) and a singleton-\(ab\) matching \(E_1\). The forbidden \(P\) is unchanged. The exterior masks after this switch are
\[
\begin{array}{c|c|c|c}
& (u_1,u_2,u_3,u_4,u_5)&(AC,Cc,bc,ab)&\text{shore ports}\\\hline
R_1&(A,B,a,p_4,c)&(C,s,s,b)&e,p_4\\
E_1&(p_1,B,\eta,b,\theta)&(A,C,c,s)&p_1,z
\end{array}                                                   \tag{2}
\]
where \((\eta,\theta,z)=(a,p_5,p_5)\) or \((p_3,a,p_3)\). Here \(s\) denotes a marked terminal semiedge. Both variants will follow the same exterior route below.

Compare \(R_1\) with the unchanged \(K\). By [Note 398's second quartet gate](398-two-cross-switches-force-a-second-shore-quartet.md), if the \(AC\)-starting path of \(R_1\triangle K\) ended at \(e\) or \(bc\), exchanging it would already give a forbidden double-\(T\) row with \(P\). The only remaining possibility pairs shore ports \(p_4,p_5\), so that the complete path ends at \(Cc\). Switch it, obtaining an allowed \(ab\,Cc\)-triple \(R_2\) and singleton-\(Cc\) matching \(K_2\). Their exterior masks are
\[
\begin{array}{c|c|c|c}
& (u_1,u_2,u_3,u_4,u_5)&(AC,Cc,bc,ab)&\text{shore ports}\\\hline
R_2&(A,C,a,B,p_5)&(s,c,s,b)&e,p_5\\
K_2&(A,B,p_3,p_4,c)&(C,s,b,a)&p_3,p_4.
\end{array}                                                   \tag{3}
\]
The mask of \(E_1\) remains (2). Its difference with \(R_2\) has the following **wholly exterior** alternating terminal path, in both variants of \((\eta,\theta,z)\):
\[
ab-t_{ab}-b-u_4-B-u_2-C-t_{Cc}-c-t_{bc}-bc.           \tag{4}
\]
Its ten edges alternate \(E_1,R_2,E_1,R_2,\ldots,E_1,R_2\) from \(ab\) to \(bc\); neither \(u_3\) nor \(u_5\) appears, which is why both variants in (2) give the same path.
Switching \(R_2,E_1\) along (4) moves the triple from \(ab\,Cc\) to the allowed state \(Cc\,bc\), yielding \(R_3\). Its exterior mask is
\[
(u_1,u_2,u_3,u_4,u_5)=(A,B,a,b,p_5),\qquad
(AC,Cc,bc,ab)=(s,C,c,s).                                 \tag{5}
\]
The shore part remains \(R_2\)'s, with ports \(e,p_5\). The singleton \(K_2\) is unchanged. Equation (3) and (5) now give another wholly exterior alternating terminal path:
\[
Cc-t_{Cc}-C-t_{AC}-AC\quad\text{in }R_3\triangle K_2. \tag{6}
\]
The four edges alternate \(K_2,R_3,K_2,R_3\) in the displayed order.
Switching (6) changes \(R_3\)'s state \(Cc\,bc\) to \(AC\,bc\). In the pentagon (1), \(AC\,bc\in T\). The original \(P\) still has \(e\,ab\in T\). We have produced a genuine forbidden double-\(T\) BF row from the supposed exact-support row, a contradiction. Every switch was between two complete perfect matchings along one complete alternating terminal path, so each intermediate row retains load two on every edge. \(\square\)

The first two switches use the shore pairings \(e\,p_4\) and \(p_4p_5\); the last two switches (4) and (6) never enter the shore. Hence making a larger or more complicated shore satisfy the second quartet cannot evade this contradiction. The [real 25-vertex selector row](397-a-real-mixed-prism-row-satisfies-both-e-port-selectors.md) evades the assumed second pairing and is therefore not a counterexample to the theorem. The proof is hand-derived and awaits independent review; full exact Case XII and Berge–Fulkerson remain open.
