> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two pentagon shores make the one-vertex host Tait-colourable

**Correction.** The graph coloured below is the smaller marked core \(J\), whose three-edge-colourability does not rule out a BF-uncovered whole host \(G\). [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) retracts only the claimed exclusion of the pentagon--pentagon Case-XII profile; the explicit colouring argument for \(J\) remains.

In [Note 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) normalized two-five-cut profile, suppose \(U=\{u\}\), the third odd component is \(\{w\}\), and both non-singleton shores \(A,B\) are ordinary pentagons in the cubic host \(J\). Then **\(J\) has a three-edge-colouring**, independently of the order of its five marked edges. This core-colouring statement does not assume exact Case-XII support or an order bound; it does not exclude the shore pair from a BF-uncovered whole host \(G\).

The [connector count in Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) gives three edges from \(A\) to \(B\), one from each shore to \(w\), one from each shore to \(u\), and the edge \(uw\). Every vertex of a pentagon shore has exactly one edge leaving it. In particular the neighbours of \(u,w\) in \(B\) are distinct. Cut the five edges leaving \(A\). The complementary five-pole \(L\) consists of the pentagon \(B\) and a three-edge path from the \(B\)-neighbour of \(u\) through \(u,w\) to the \(B\)-neighbour of \(w\). Its five ports lie at \(u,w\) and the three other pentagon vertices. The two attachment vertices of the path are at distance one or two on \(B\).

## Six explicit Tait states on the complementary shore

Write \(B=v_1v_2v_3v_4v_5v_1\), with \(u\) attached to \(v_1\). The vertex \(w\) attaches to \(v_2\) or \(v_3\), after reversing the pentagon if needed. Let \(x_i\) be the colour of \(v_iv_{i+1}\), with \(x_5\) on \(v_5v_1\), and let \(y_1,y_2,y_3\) colour the path from \(v_1\) to the other attachment vertex. Use nonzero colours \(1,2,3\) in \(\mathbb F_2^2\); the sum of two distinct colours is the third. In every row below set \(x_1=1,x_5=2,y_1=3\). At the other attachment vertex set \(y_3=x_1+x_2\) when it is \(v_2\), and \(y_3=x_2+x_3\) when it is \(v_3\). Each remaining port receives the sum of the colours on its two incident proper edges.

| path endpoint | \((x_2,x_3,x_4;y_2)\) | lonely port pair |
|---|---|---|
| \(v_2\) | \((2,3,1;1)\) | \(rt\) |
| \(v_2\) | \((2,3,1;2)\) | \(st\) |
| \(v_2\) | \((2,1,3;2)\) | \(rs\) |
| \(v_2\) | \((3,2,1;1)\) | \(pr\) |
| \(v_2\) | \((3,1,3;1)\) | \(qt\) |
| \(v_2\) | \((3,2,3;1)\) | \(pq\) |
| \(v_3\) | \((2,1,3;1)\) | \(rt\) |
| \(v_3\) | \((2,1,3;2)\) | \(rs\) |
| \(v_3\) | \((2,3,1;2)\) | \(ps\) |
| \(v_3\) | \((3,1,3;1)\) | \(qt\) |
| \(v_3\) | \((3,2,1;2)\) | \(pr\) |
| \(v_3\) | \((3,2,3;2)\) | \(qr\) |

Here \(p,q\) are the ports at \(u,w\). For endpoint \(v_2\), the ports \(r,s,t\) lie at \(v_3,v_4,v_5\); for endpoint \(v_3\), they lie at \(v_2,v_4,v_5\). Every row assigns three different colours at the two degree-three attachment vertices and distinct colours to the two proper edges at every port vertex. Thus each is an actual three-edge-colouring of \(L\). The six lonely pairs in either block of the table are distinct.

For the \(v_3\) attachment, these six states are **all** Tait states of \(L\). Up to colour permutation, \(x_1=1,x_5=2,y_1=3\) is forced. Then \(x_2\in\{2,3\}\), \(x_4\in\{1,3\}\), \(x_3\) differs from both \(x_2,x_4\), and \(y_2\) differs from \(3\) and \(y_3=x_2+x_3\). These conditions give exactly the six \(v_3\) rows above. [Note 176](176-petersen-realizes-the-422-tait-state-boundary.md) uses this exact state set for a genuine \((4,2,2)\) host example.

An ordinary pentagon five-pole has five Tait missing-pair states, the edges of a five-cycle on its five port labels; see [Figure 5 of Máčajová--Mazzuoccolo--Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). The five states of \(A\) and the six displayed states of \(L\) are subsets of the ten possible port pairs, so they intersect. In three-edge-colourings with the same lonely pair, the five boundary colours agree after one permutation of the three colour names. Glue these colourings across the five cut edges. This three-edge-colours every edge of \(J\), proving the claim. \(\square\)

The argument establishes the colouring of \(J\). [Note 179](179-a-colourable-two-shore-core-opens-to-a-tait-colourable-five-pole.md) lifts any such colouring to the outer pole \(H\), excluding its Tait-empty exact-Case-XII option. [Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md) subsequently excludes the \(S\)-Tait option by actual BF rows of \(H\). The colouring of \(J\) alone remains insufficient to cover the whole host \(G\).
