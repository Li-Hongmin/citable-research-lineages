> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cross-signature two-mask switches in the Hamilton class-IV row

Continue the genuine \(D_2\) class-IV \((eX)(eZ)\) row of [Notes 479--485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md), with the Hamilton exterior \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) and \((X,Y,Z,W)=(14,15,26,36)\). Its complete shore matchings \(Q_P,Q_R,Q_a,Q_b,Q_J,Q_K\) have port sets
\[
\partial Q_P=\partial Q_R=\varnothing,\quad
\partial Q_a=\{e,p_1,p_2,p_4\},\quad
\partial Q_b=\{e,p_2,p_3,p_4\},\quad
\partial Q_J=\{p_1,p_5\},\quad
\partial Q_K=\{p_3,p_5\}.                                      \tag{1}
\]
Let \(\pi_{aK},\pi_{bJ}\) pair the six shore ports along the open paths of \(Q_a\triangle Q_K\) and \(Q_b\triangle Q_J\), respectively. Note 482 considered only exchanges whose *new* pair has old port signatures. New signatures give six further, nonredundant two-mask gates.

**Theorem.** Each equality in either table produces a genuine BF loop of the indicated [Appendix-XII-forbidden type](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). The loop retains both old zero-port shore matchings and one old singleton shore matching of each role. In the six rows labelled “new”, the two other singleton shore matchings have port signatures absent from (1), so both are genuinely new. The two old-signature rows are the gates of Note 482; under the odd-zero premise of Note 485 their two changed masks are also new.

| Loop | New non-\(e\) singleton ports | Shore path gate |
|---|---|---|
| \([eY]\) | \(p_1p_5\) | \(\pi_{aK}(p_1)=p_3\) (Note 482) |
| \([eY]\) | \(p_1p_4\) | \(\pi_{aK}(e)=p_2\) (new) |
| \([eY]\) | \(p_2p_5\) | \(\pi_{aK}(p_2)=p_3\) (new) |
| \([eY]\) | \(p_2p_4\) | \(\pi_{aK}(e)=p_1\) (new) |

| Loop | New non-\(e\) singleton ports | Shore path gate |
|---|---|---|
| \([eX]\) | \(p_3p_5\) | \(\pi_{bJ}(p_1)=p_3\) (Note 482) |
| \([eX]\) | \(p_1p_2\) | \(\pi_{bJ}(p_2)=p_5\) (new) |
| \([eX]\) | \(p_1p_3\) | \(\pi_{bJ}(p_3)=p_5\) (new) |
| \([eX]\) | \(p_2p_5\) | \(\pi_{bJ}(p_1)=p_2\) (new) |

These tables are also exhaustive **within the following prescribed two-pair recompletion**: the two zero exteriors are equal to \(T_Y^5\) or \(T_X^1\); the retained singleton exteriors are \((E_1,N_Y^1)\) or \((E_1,N_X^0)\), respectively; and the two new singleton shore restrictions sum to \(Q_a+Q_K\) or \(Q_b+Q_J\). No exhaustiveness claim is made for other exteriors, changed zero masks, or other shore-port signatures.

## Exterior and shore exchanges

The restrictions \(T_Y^5,E_1,N_Y^1\) in Note 481(2) partition every exterior edge once. The three alternating open components of \(E_1\triangle N_Y^1\), including their endpoint semiedges, are
\[
Y-t_Y-1-t_X-4-u_3-p_3,\qquad
p_1-u_1-2-t_Z-6-t_W-3-u_2-p_2,\qquad
p_4-u_4-5-u_5-p_5.                                      \tag{2}
\]
The singleton-\(Y\) phase must keep \(Y\) on the first path, so its proper shore ports consist of one of \(\{p_1,p_2\}\) and one of \(\{p_4,p_5\}\). These are exactly the four entries in the first table. Exchanging phases on the other paths constructs exterior matchings \(E',N_Y'\) with
\[
                   E'+N_Y'=E_1+N_Y^1                       \tag{3}
\]
edgewise; \(E'\) has no exterior terminal, while \(N_Y'\) uses \(Y\). The shore gives the completed \(E'\) matching its terminal \(e\).

Likewise \(T_X^1,E_1,N_X^0\) partition the exterior. The alternating open components of \(E_1\triangle N_X^0\) are
\[
X-t_X-4-u_4-p_4,\qquad
p_1-u_1-1-t_Y-5-u_5-p_5,\qquad
p_2-u_2-2-t_Z-6-t_W-3-u_3-p_3.                         \tag{4}
\]
Keeping \(X\) on the first path makes the new singleton-\(X\) port pair an element of \(\{p_1,p_5\}\times\{p_2,p_3\}\), exactly the four entries in the second table, and gives \(E'+N_X'=E_1+N_X^0\).

For two shore matchings \(U,V\) whose port sets partition \(\{e,p_1,\ldots,p_5\}\), a target pair \(U',V'\) satisfies \(U'+V'=U+V\) exactly when the symmetric difference between the old and target \(V\)-port sets is a union of complete endpoint pairs of \(\pi_{UV}\). Shared edges belong to both decompositions, and on each open alternating component there are precisely two phases; even closed components can be phased independently. Requiring \(e\in\partial U'\) fixes the phase of the path containing \(e\). Apply this test to \((U,V)=(Q_a,Q_K)\) and the four targets from (2). Their port-set symmetric differences are respectively \(\{p_1,p_3\},\ \{p_1,p_3,p_4,p_5\},\ \{p_2,p_3\},\ \{p_2,p_3,p_4,p_5\}\), giving exactly the first four gates. For \((U,V)=(Q_b,Q_J)\), the four differences are \(\{p_1,p_3\},\ \{p_2,p_5\},\ \{p_3,p_5\},\ \{p_1,p_2\}\), giving the second four gates.

Let \(Q_E',Q_N'\) be the shore matchings from a successful gate. The old shore load equation gives
\[
Q_P+Q_R+Q_b+Q_J+Q_E'+Q_N'
 =Q_P+Q_R+Q_b+Q_J+Q_a+Q_K=2\mathbf1_Z           \tag{5}
\]
for \([eY]\), and the analogous equation with \((a,K)\) retained and \((b,J)\) exchanged gives \([eX]\). Glue \(Q_P,Q_R\) to two copies of the relevant \(T\) exterior, the retained old singleton masks to \(E_1,N\), and the two new masks to \(E',N'\). Equations (3)--(5) load every edge of the **whole five-pole** twice. All six objects are actual perfect matchings; no selected-row approximation is involved. The six new-signature entries necessarily introduce exactly two new complete shore masks, since their port sets differ from every signature in (1).

## Exact-support restriction and a real boundary

For the orientation in Notes 479--485, Appendix XII forbids both \([eX]\) and \([eY]\). Hence a genuine exact-Case-XII pole carrying this class-IV row must avoid **all eight** path equalities above. The four \([eY]\) avoidances leave only five possible pairings for \(\pi_{aK}\):
\[
ep_3\mid p_1p_2\mid p_4p_5,\quad
ep_3\mid p_1p_4\mid p_2p_5,\quad
ep_3\mid p_1p_5\mid p_2p_4,\quad
ep_4\mid p_1p_2\mid p_3p_5,\quad
ep_5\mid p_1p_2\mid p_3p_4.                            \tag{6}
\]
The four \([eX]\) avoidances likewise leave five possibilities for \(\pi_{bJ}\):
\[
p_1e\mid p_2p_3\mid p_4p_5,\quad
p_1p_4\mid ep_5\mid p_2p_3,\quad
p_1p_5\mid ep_2\mid p_3p_4,\quad
p_1p_5\mid ep_3\mid p_2p_4,\quad
p_1p_5\mid ep_4\mid p_2p_3.                            \tag{7}
\]

The genuine 29-vertex Petersen-substituted pole of Note 481 has every zero-port complement odd. In its lifted old row \(a=M_\infty\), \(K=M_3\) on the Petersen gadget of Note 381. Writing \(\hat u_i\) for its inner vertices to distinguish them from the exterior tree subdivisions, the three complete \(Q_a\triangle Q_K\) port paths are
\[
e-q_e-q_1-p_1,\qquad
p_2-\hat u_0-\hat u_2-v_2-v_1-\hat u_1-\hat u_4-v_4-q_4-p_4,\qquad
p_3-q_3-q_5-p_5.                                           \tag{8}
\]
The middle path uses alternating \(M_\infty,M_3\) edges in the gadget; its attachment incidences are exactly those fixed in Note 481(5). Switching the last two paths gives new singleton-\(Y\) shore ports \(\{p_2,p_4\}\) and new singleton-\(e\) shore ports \(\{e,p_1,p_3,p_5\}\). The fourth first-table gate and the two exterior switches of (2) therefore produce a forbidden \([eY]\) row **with exactly two new shore masks and two new port signatures**. Thus Note 481's lower bound of three new masks is sharp only **among old-signature forbidden rows**; permitting new signatures lowers the count to two on the same real, Tait-empty pole. The Petersen substitution creates a cyclic three-edge cut, so this pole is not exact Case XII.
For comparison, the same lifted row has \(\pi_{bJ}=p_1p_5\mid ep_4\mid p_2p_3\); all four second-table gates fail. The forbidden two-mask escape here is genuinely supplied by the first table.

The two new port signatures are minimal for an escape from the old signature family. Indeed, port load two gives a simple four-slot check: if three singleton signatures are selected from \(a,b,J,K\), the fourth, whenever it has the required four-port \(e\)-role or two-port non-\(e\) role, is again one of \(a,b,J,K\). With one old \(e\)-signature \(a\), the old non-\(e\) choices \(JJ,JK,KK\) respectively overload \(p_1\), force \(b\), and force \(a\) for the fourth signature; with \(b\), they force \(b,a\), or overload \(p_3\). If the proposed new signature is non-\(e\), retaining \(J\) and choosing old \(e\)-signatures \(aa,ab,bb\) respectively overloads \(p_1\), forces \(K\), or forces \(J\); retaining \(K\) instead forces \(K,J\), or overloads \(p_3\). Thus no row of these two loop types can have exactly one new port-signature occurrence.

The result adds six necessary matching-path restrictions to this one fixed class-IV phase and gives a real two-mask boundary with new signatures. It does not exclude all surviving pairings (6)--(7), other exterior carriers, other required rows, or Berge--Fulkerson. The proof is hand-derived without OMEN or local mathematical recomputation and awaits independent review. \(\square\)

Later boundary: [Note 487](487-an-odd-zero-class-iv-pole-avoids-all-eight-two-mask-path-gates.md) constructs a genuine 29-vertex odd-zero, Tait-empty pole whose old class-IV row has both pairings in (6)--(7), so **all eight** gates fail, while its complete BF support still contains forbidden \([eY]\). It has a cyclic three-edge cut and is not exact Case XII.
