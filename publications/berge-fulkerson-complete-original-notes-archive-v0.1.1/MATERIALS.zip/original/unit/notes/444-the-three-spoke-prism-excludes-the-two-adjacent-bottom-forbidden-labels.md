> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The three-spoke prism excludes two adjacent forbidden bottom labels

Continue the three-spoke prism exterior of [Notes 442](442-the-three-spoke-prism-excludes-the-top-opposite-bottom-forbidden-pair.md) and [443](443-the-three-spoke-prism-excludes-top-and-adjacent-bottom-forbidden-pairs.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,Cc),\qquad
(X,Y,Z,W)=(AC,ab,bc,ca).                                  \tag{1}
\]
The sixth shore terminal is \(e\). A two-letter type \(ej\) denotes a triple matching missing terminals \(e,j\); a single letter denotes the terminal of a singleton matching.

> **Bottom-adjacent exclusion.** No cubic five-pole with exterior (1), at any shore order or topology, has complete exact-Case-XII BF support with forbidden \(e\)-labels \(\{eY,eZ\}=\{e\,ab,e\,bc\}\).

The two possible pentagons are \(e-X-Y-Z-W-e\) and \(e-X-Z-Y-W-e\). Under the respective identifications \((e,X,Y,Z,W)=(1,3,5,2,4)\) and \((1,3,2,5,4)\), the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the row \((eY)(eW)\), listed as \((14)(15)\) or \((12)(14)\). It contains neither \([eY]\) nor \((eY)(eZ)=(12)(15)\).

Take such a required **genuine** row, naming its six complete matching occurrences
\[
P=eY,\qquad R=eW,\qquad K=W,\qquad J=Y,\qquad E=e,\qquad F=e. \tag{2}
\]
By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(P,R\) have no shore ports. The \(W\)-starting path of \(R\triangle K\) must end at \(X\): ending at \(Y\) switches (2) to forbidden \([eY]\), while ending at \(Z\) switches it to forbidden \((eY)(eZ)\). We need only its first step. If \(R=eW:a\), taking \(Y:a\) in \(K\) would end that path at \(Y\), so \(K\) takes \(au_3\), then necessarily \(Y:b,Z:c\). If \(R=eW:c\), taking \(Z:c\) in \(K\) would end the path at \(Z\), so \(K\) takes \(cu_5\), then necessarily \(Z:b,Y:a\). This uses no assumption on where the path travels later.

Write \(UV\) for the pair of occurrence labels \(\{U,V\}\). In a marked-subdivision triple \((T,L,R)\), the entries label its terminal, first marked half, and second marked half; thus \(t_Y=(\text{terminal},Y:a,Y:b)\), \(t_Z=(\text{terminal},Z:b,Z:c)\), and \(t_W=(\text{terminal},W:a,W:c)\). The columns headed \(u_3:a,u_4:b,u_5:c\) give the label pair on the indicated tree half. Edge load two and the matching condition force the following bottom data in the **old** row (2):
\[
\begin{array}{c|ccc|ccc}
(P\text{ root},R\text{ root})&u_3:a&u_4:b&u_5:c&t_Y&t_Z&t_W\\ \hline
(a,a)&KJ&PR&PR&(RJ,PF,KE)&(PR,JF,KE)&(PK,RE,JF)\\
(b,a)&PK&RJ&PR&(RJ,EF,PK)&(PR,EF,KJ)&(PK,RJ,EF)\\
(a,c)&RJ&PR&PK&(RJ,PK,EF)&(PR,KJ,EF)&(PK,EF,RJ)\\
(b,c)&PR&RJ&PK&(RJ,KE,PF)&(PR,KE,JF)&(PK,JF,RE).
\end{array}                                                   \tag{3}
\]
In the first line, relabel \(E,F\) so that \(K,E\) take \(Y:b\); in the last, relabel them so that \(K,E\) take \(Y:a\). For example, when \((P,R)=(b,c)\), \(P,R\) fill \(au_3\), forcing \(Y:a=KE\) and \(W:a=JF\); \(P,K\) fill \(cu_5\), so \(W:c=RE\) and \(Z:c=JF\). The remaining entries of that line follow at \(t_Y,t_Z\) and \(b\). The other lines follow by the same degree-three and load-two check.

Keep **each occurrence's entire shore restriction** and retain every proper shore-port pair. For \((P,R)=(a,a)\), also retain every tree edge pair and the marked \(t_X\) pairs, changing only \(t_Y,t_Z,t_W\) as in the first line below. For \((P,R)=(b,a)\), first interchange the labels \(P,R\) on both halves of the three tree edges on the path \(a-u_3-A-u_1-B-u_4-b\), leaving their port pairs unchanged; then use the second line. In the latter case the two zero-port tree masks become the roots \(P=eY:a,R=eY:b\), while the first case has \(P=R=eY:a\). In both cases \(K,J\) become singleton \(Y\), and the new row has forbidden type \([eY]\).

For \(R=eW:c\), keep **all** tree and \(t_X\) pairs unchanged. Replace only the bottom marked pairs as in the last two lines. The new boundary types are \(P=eY\) at its old root, \(R=eZ:c\), \(K=Z\), \(J=Y\), and \(E=F=e\), giving the forbidden double row \((eY)(eZ)\). Here every equality of types describes a boundary and root, never equality of complete shore matchings.

The complete replacement data are:
\[
\begin{array}{c|ccc|ccc|c}
(P,R)\text{ old roots}&u_3:a&u_4:b&u_5:c&t_Y&t_Z&t_W&\text{new type}\\ \hline
(a,a)&KJ&PR&PR&(KJ,PR,EF)&(PR,KJ,EF)&(PR,EF,KJ)&[eY]\\
(b,a)&RK&PJ&PR&(KJ,PE,RF)&(PR,KE,JF)&(PR,JF,KE)&[eY]\\
(a,c)&RJ&PR&PK&(RJ,PE,KF)&(PK,JE,RF)&(PR,KF,JE)&(eY)(eZ)\\
(b,c)&PR&RJ&PK&(RJ,EF,PK)&(PK,EF,RJ)&(PR,KJ,EF)&(eY)(eZ).
\end{array}                                                   \tag{4}
\]
At each of \(a,b,c\), its tree-half pair from (4) and its two incident marked-half pairs partition \(\{P,R,K,J,E,F\}\). Each triple at \(t_Y,t_Z,t_W\) also partitions these six labels. The \(t_X\) pairs are unchanged. The only tree change, in line \((b,a)\), swaps \(P,R\) on opposite halves of each edge of the displayed path. Every tree subdivision still assigns one edge to each matching and each edge has two labels; at the internal original vertices \(A,B\), both labels still choose one tree edge. The bottom vertices are checked by (4). Thus all six exterior restrictions are genuine matchings, every exterior edge has load two, and all six original complete shore matchings glue back because their \(e\) and proper-port labels are unchanged.

The required \((eY)(eW)\) row therefore cannot occur. This excludes the fourth of the six forbidden pairs on this **one** three-spoke prism tree orbit. The remaining pairs are \(\{eW,eY\}\) and its reflection \(\{eW,eZ\}\); the other three-spoke tree orbit, other exterior profiles, and Berge–Fulkerson remain open. This is a hand-derived proof awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)
