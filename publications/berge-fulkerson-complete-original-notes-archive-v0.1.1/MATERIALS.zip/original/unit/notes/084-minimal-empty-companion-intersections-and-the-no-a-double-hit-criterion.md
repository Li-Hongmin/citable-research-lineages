> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimal empty companion intersections and the no-A double-hit criterion

The phase-intersection test of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md)
has exactly two irreducible modes of failure.  Both occur in actual
double-cover rows of simple cubic graphs of girth five and cyclic
edge-connectivity five.  Consequently neither cubic incidence nor this
connectivity forces a row companion aligned with a prescribed alternating
exchange.  The exact additional information supplied by the absence of an
all-terminal cover is instead a double-hit condition on the partial-flip
cube.

## The two irreducible empty-intersection certificates

Let \(\mathcal L\) be an inclusion-minimal family of two-element sets with

\[
 \bigcap_{L\in\mathcal L}L=\varnothing .          \tag{1}
\]

Up to renaming the ground set, precisely one of the following holds:

\[
 \mathcal L=\{\{a,b\},\{c,d\}\},                 \tag{2}
\]

where the two sets are disjoint, or

\[
 \mathcal L=\{\{a,b\},\{a,c\},\{b,c\}\}.        \tag{3}
\]

Indeed, if two members are disjoint, they already witness (1), so
minimality gives (2).  Otherwise the family is pairwise intersecting.
Choose distinct members \(\{a,b\}\) and \(\{a,c\}\).  Some member must
omit \(a\); pairwise intersection forces it to be \(\{b,c\}\).  These
three members already have empty intersection, so minimality gives (3).
The converse for both displayed families is immediate.

In the setting of Note 082, the sets in \(\mathcal L\) are the two row
companions using successive desired-phase edges of
\(P\mathbin\triangle Y\).  Thus (2)--(3) classify every irreducible way in
which the one-replacement membership

\[
 N+P-Y\in\mathcal P_{\partial N}                  \tag{4}
\]

can fail because no single current companion carries the complete
\(Y\)-phase.

## Both certificates occur in highly connected cubic rows

The disjoint-pair certificate is realized by the graph and BF row of
[Note 083](083-cyclic-five-connectivity-does-not-force-one-row-companion-alignment.md).
On each of three alternating six-cycles its desired-phase labels are

\[
 \{1,2\},\quad\{1,2\},\quad\{3,4\},              \tag{5}
\]

so \(\{1,2\}\) and \(\{3,4\}\) form (2).

There is also an eighteen-vertex realization of (3).  Put

\[
 V=\{(c,i,j):c,i\in\mathbb Z_3,\ j\in\mathbb Z_2\},
\]

and, for every \((c,i)\), add

\[
 p_{c,i}=(c,i,0)(c,i,1),\qquad
 y_{c,i}=(c,i,1)(c,i+1,0).                       \tag{6}
\]

Complete these three disjoint alternating six-cycles with the third-edge
perfect matching

\[
\begin{aligned}
 &(0,0,0)(1,0,0),&&(2,0,0)(0,2,1),
 &&(1,2,1)(2,2,1),\\
 &(0,0,1)(1,1,0),&&(0,1,0)(2,0,1),
 &&(0,1,1)(1,2,0),\\
 &(0,2,0)(2,1,1),&&(1,0,1)(2,1,0),
 &&(1,1,1)(2,2,0).
\end{aligned}                                     \tag{7}
\]

Index five companion occurrences by
\(\Omega=\{0,1,2,3,4\}\).  Label every \(p\)-edge by \(\{0\}\), and
label \(y_{c,0},y_{c,1},y_{c,2}\), in every block, by

\[
 \{1,2\},\quad\{1,3\},\quad\{2,3\}.             \tag{8}
\]

At each vertex label the third stub by the complement in \(\Omega\) of
the incident \(p\)- and \(y\)-labels.  The pairs in (7) join equal stub
labels, so this gives an edge labelling.  Let \(P\) be the set of all
\(p\)-edges and let \(N_a\) contain the edges whose label contains \(a\).
The three incident labels at each vertex partition \(\Omega\), hence every
\(N_a\) is a perfect matching and

\[
 \chi_P+\sum_{a=0}^4\chi_{N_a}=2\mathbf1.         \tag{9}
\]

The five companions are distinct, although the six occurrences contain
the legitimate repetition \(P=N_0\).  The graph has 29 perfect matchings
and satisfies

\[
 g=5,\qquad\lambda=3,\qquad\lambda_c=5.           \tag{10}
\]

On every component of \(P\mathbin\triangle Y\), the three desired-phase
labels are exactly (8): they intersect pairwise but have empty total
intersection.  Every nonempty union of these alternating components can be
flipped in \(P\), but for no resulting matching \(P^I\) and no current
companion \(N_a\) is

\[
 N_a+P-P^I
\]

a perfect matching.  Thus complete partial-flip closure does not repair
either irreducible certificate within the current row.

## The exact no-A double-hit condition

Let \(A,B,C,D\) be four singleton-boundary perfect matchings using four
distinct terminals, and let every partial flip \(P^I\) use the remaining
terminal.  Suppose the literal pivot row gives

\[
 W=\chi_A+\chi_B+\chi_C+\chi_D\le2\mathbf1,
 \qquad D_2=\{e:W(e)=2\}.                         \tag{11}
\]

If \(P^I\cap D_2=\varnothing\), then
\(W+\chi_{P^I}\le2\mathbf1\).  At every cubic vertex the five matching
occurrences have total incident load five, so the three incident loads are
\((2,2,1)\).  Therefore

\[
 Z=2\mathbf1-W-\chi_{P^I}                         \tag{12}
\]

is an all-terminal perfect matching, and
\(A,B,C,D,P^I,Z\) form a forbidden all-terminal BF cover.  Consequently

\[
 \text{no all-terminal cover}
 \quad\Longrightarrow\quad
 P^I\cap D_2\ne\varnothing\quad\text{for every }I. \tag{13}
\]

This condition has an exact component form.  Write

\[
 P\mathbin\triangle Y=C_1\mathbin{\dot\cup}\cdots
 C_k,qquad F=P\cap Y,
\]

and put \(P_i=P\cap C_i\), \(Y_i=Y\cap C_i\).  There is a phase choice
\(P^I\) avoiding \(D_2\) if and only if

\[
 D_2\cap F=\varnothing,
 \qquad
 \forall i,\quad D_2\cap P_i=\varnothing
                 \ \text{or}\ D_2\cap Y_i=\varnothing.      \tag{14}
\]

Indeed, under (14) choose independently on each component a phase missed by
\(D_2\).  Conversely every chosen phase in an avoiding matching must be
missed by \(D_2\), and its common part must also be missed.  Hence the
negation of (14) is exactly the cube-hitting condition forced by no
all-terminal cover:

\[
 D_2\cap F\ne\varnothing
 \quad\text{or}\quad
 \exists i:\ D_2\cap P_i\ne\varnothing
              \text{ and }D_2\cap Y_i\ne\varnothing.        \tag{15}
\]

Condition (15) still does not select one companion across all certificate
edges.  On a formal six-cycle, the four literal pivot rows, the three target
overloads, adjacent disjoint desired-phase labels, and the strongest
one-component instance of (15) are jointly feasible for 24 of the 30
ordered disjoint-label assignments.  Every one of the five possible unused
companion roles occurs.  This finite local statement is recorded only to
show that the new double-hit equation and the old row equations are
compatible; it is not a graph-realizability theorem.

## Consequence and remaining boundary

The two-set classification and the cubic realizations prove that no Helly,
pairwise-intersection, girth-five, cyclic-five-connectivity, or
partial-flip-closure argument can by itself force (4).  The absence of the
all-terminal type adds exactly (13)--(15), but that condition concerns the
union \(D_2\) of anchor overloads rather than equality of the companion
occurrence on different edges.

Neither eighteen-vertex construction is an exact-Case-XII five-pole.  The
local feasibility calculation is not a common cubic graph.  Thus these
examples do not refute Case XII.  A positive argument must couple (15) to
cross-row perfect-matching reuse, or prove directly that some specified
partial flip belongs to a second carrier row which forces (4).  Continuing
to strengthen the intersection property of labels inside one row cannot
decide the case.

The triangle construction and local disjoint-label calculation are frozen
in the
[verification bundle](../computations/bundles/minimal-empty-companion-intersections/README.md).
The disjoint high-connectivity realization remains in the bundle linked by
Note 083.
