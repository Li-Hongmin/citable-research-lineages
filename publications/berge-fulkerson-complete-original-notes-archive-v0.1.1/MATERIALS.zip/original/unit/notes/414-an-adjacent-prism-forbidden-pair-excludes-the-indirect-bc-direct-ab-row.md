> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An adjacent forbidden pair excludes the \(e\,bc:b/e\,ab:a\) prism row

Keep the two-spoke prism tree and marks of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md):
\[
T=\{AB,BC,Aa,Bb,ac\},\qquad (p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac),
\]
with the other four marks \(AC,Cc,bc,ab\) and a sixth terminal \(e\) on an arbitrary shore. Suppose the forbidden \(e\)-labels of an exact Case-XII BF relation are the **adjacent** pair \(\{bc,Cc\}\). The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((e\,bc)(e\,ab)\). Its possible allowed pentagons are
\[
S_\alpha=e-ab-bc-Cc-AC-e,\qquad
S_\beta=e-ab-Cc-bc-AC-e.                                  \tag{1}
\]

> **Root-pair exclusion.** No actual six-perfect-matching BF row of type
> \((e\,bc)(e\,ab)\) has its forbidden triple rooted as \(P=e\,bc:b\) and its
> allowed triple rooted as \(R=e\,ab:a\), for either pentagon in (1).
> Shore size, cycle rank, and path lengths are unrestricted.

Here \(e\,j\) means that \(e,j\) are the two *missing* terminals of a triple matching. Put \(K\) for singleton-\(ab\), \(J\) for singleton-\(bc\), and \(D_0,D_1\) for the two singleton-\(e\) occurrences. The rooted tree slots of \(P,R\) are respectively
\[
(A,C,a,B,c),\qquad(B,C,A,b,c)                         \tag{2}
\]
on \((u_1,\ldots,u_5)\). In particular, \(P,R\) saturate both \(Cu_2\) and \(cu_5\), so \(K\) cannot take either edge. In \(R\triangle K\), the path starting at \(ab\) must end at \(AC\): ending at \(bc\) or \(Cc\) would leave \(P=e\,bc\) unchanged and give two forbidden triples. The path cannot start through \(au_5\), since it would then end at \(bc\) or \(Cc\). Starting through \(au_3\), it has precisely two kinds of wholly exterior completion:

* **Short:** \(ab-t_{ab}-a-u_3-A-t_{AC}-AC\). Then \(K\) takes \(AC:A,Cc:C,bc:c,au_3,bu_4\), and covers \(B\) through \(Bu_1\) or \(Bu_2\).
* **Long:** \(ab-t_{ab}-a-u_3-A-u_1-B-u_2-C-t_{AC}-AC\). Then \(K\) takes \(AC:C,Cc:c,bc:b,au_3,Au_1,Bu_2\) and ports \(p_4,p_5\).

The alternative from \(B\) through \(Bu_4\) ends at forbidden \(bc\). Switching the stated path gives \(R'=e\,AC\) with exactly the same **complete shore matching** as \(R\). In the short case \(R'\) is rooted at \(A\); in the long case it is rooted at \(C\).

**Short case.** The \(Cu_2\) and \(cu_5\) edges are saturated by \(P,R\). Mark and vertex quotas force \(J:Cc:c,AC:C\). At \(b\), \(R,K\) saturate \(bu_4\), so \(J\) takes either \(bc:b\) or \(ab:b\). The first possibility makes both \(D_i\) take \(ab:b\) at \(b\), but the \(bc\) subdivision still requires one \(D_i\) to take \(bc:b\); this is impossible. Hence \(J:ab:b\).

The singleton-\(e\) occurrence \(E\) using \(ab:a\) is then forced to take
\[
E:\quad AC:C,\ Cc:c,\ bc:b,\ ab:a,\ p_5.              \tag{3}
\]
Both \(R\) and \(R'\) take \(cu_5\) and have terminal \(Cc\). Thus the \(Cc\)-terminal arm of either symmetric difference with \(E\) is exactly
\(Cc-t_{Cc}-c-u_5-p_5\). Directly following the other two arms shows that their exterior endpoints are other proper ports; in particular neither \(bc\)-arm ends at \(p_5\).

Let \(q\) be the first proper port reached by the \(e\)-path within the shore in \(R\triangle E\). Since \(R,R'\) have the same zero-port shore matching, the corresponding shore path against \(R'\) has the same \(q\). Each exterior difference pairs its three triple terminals with the three proper ports of \(E\), so an \(e\)-path reaches \(Cc\) exactly when \(q=p_5\), in **both** comparisons. Under \(S_\alpha\), the \(e\)-paths must instead end at \(bc\) from \(R\) and \(Cc\) from \(R'\). Under \(S_\beta\), the required ends are \(Cc\) and \(bc\). Either orientation contradicts the common \(q\).

**Long case.** Here \(P,K\) saturate \(bc:b\). Quotas at \(c,C\) force \(J:Cc:c,AC:C\), while at \(b\) the singleton \(J\) takes either \(ab:b\) or \(bu_4\). Both \(D_i\) take \(AC:A,Cc:C,bc:c\).

If \(J:ab:b\), the singleton-\(e\) occurrence \(E\) using \(ab:a\) must take \(bu_4,p_5\). It takes \(bc:c\), and both \(R,R'\) take \(cu_5\) and have terminal \(bc\). Hence their \(bc\)-terminal arms against \(E\) both exit at \(p_5\); their \(Cc\)-arms exit at \(p_1\) or \(p_2\). The common shore endpoint \(q\) would have to select \(bc\) in one comparison and \(Cc\) in the other, again contradicting (1).

If \(J:bu_4\), both \(D_i\) take \(ab:b,au_5\). Name either of them \(D\). Its tree edge at \(B\) is \(Bu_1,Bu_2\), or \(Bu_4\), and its remaining exterior mask is
\[
D:\quad AC:A,\ Cc:C,\ bc:c,\ ab:b,\ au_5.             \tag{4}
\]
Tracing the relevant exterior terminal arms gives:
\[
\begin{array}{c|ccc}
D\text{ at }B&Bu_1&Bu_2&Bu_4\\\hline
R\triangle D:\ bc&p_4&p_4&p_1\\
R\triangle D:\ Cc&p_2&p_1&p_2\\
R'\triangle D:\ Cc&p_2&p_1&p_1\\
R'\triangle D:\ bc&p_3&p_3&p_3
\end{array}                                                     \tag{5}
\]
The four row prefixes are, respectively,
\[
\begin{array}{ll}
R,bc:&bc-t_{bc}-c-u_5-a-t_{ab}-b-u_4,\\
R,Cc:&Cc-t_{Cc}-C-u_2,\\
R',Cc:&Cc-t_{Cc}-C-t_{AC}-A-u_1,\\
R',bc:&bc-t_{bc}-c-u_5-a-u_3-p_3.
\end{array}
\]
At \(u_4,u_2,u_1\), respectively, continue through \(B\) precisely when \(D\) uses \(Bu_4,Bu_2,Bu_1\); the other branch goes to its port. These traces give (5), and all three exterior terminal arms end at distinct proper ports of \(D\). For \(S_\beta\), the required \(Cc\)-arm from \(R\) never has the same endpoint as the required \(bc\)-arm from \(R'\). For \(S_\alpha\), the required \(bc\)-arm from \(R\) and \(Cc\)-arm from \(R'\) agree only in the \(Bu_4\) column. But \(P,R,K\) occupy one each of \(Bu_4,Bu_1,Bu_2\), and \(J:bu_4\) cannot use \(Bu_4\). Edge load two therefore permits at most one of \(D_0,D_1\) to take \(Bu_4\). The other occurrence contradicts the common-endpoint requirement. This excludes the long case and proves the claim. \(\square\)

This excludes one possible root pair of the required mixed cell; it does not exclude its other three root pairs, the full two-spoke prism profile, exact Case XII in other profiles, or the Berge–Fulkerson conjecture. The proof is a hand derivation and awaits independent review.
