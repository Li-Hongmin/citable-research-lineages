> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The mixed-side left cell forces a profiled S-Tait triple

[Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) forces an \(S\)-Tait colouring from the right \((25)(34)\) cell in the mixed-side \(4+1\) two-edge-bipartization. The complementary left cell has a separate, shorter carrier obstruction: every \((14)(23)\) row fixes two singleton exceptional-edge profiles, and it too forces an actual \(S\)-Tait triple using both exceptional edges. Together with the fixed-\(B_2\) involution of [Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md), this makes the left and right \(B_2+C_4\) spectra agree on the two exceptional-edge coordinates, while leaving their full-mask intersection open.

## Theorem

Let \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole whose complete BF support has no \(T\)-loop and no \(T\)--\(T\) type. Suppose disjoint proper edges \(e\subset X\) and \(f\subset Y\) make \(H-\{e,f\}\) bipartite, with terminals \(1,3,4,5\) in \(X\) and terminal \(2\) in \(Y\). If actual complete perfect matchings form a left row
\[
q_{14}+A_1+C_4+r_{23}+B_2+X_3=2\mathbf1,                 \tag{1}
\]
then \(C_4\) and \(X_3\) both avoid \(e,f\). Moreover, \(H\) has an actual triple-boundary perfect matching missing either \(14\) or \(35\) which uses **both** \(e,f\), and hence an actual \(S\)-Tait colouring.

**Proof.** By the mixed-side matching table of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md), a class-2 singleton has profile \((1,0)\), a triple missing an \(X2\) pair has profile \((0,1)\), and an \(X\)-singleton or a triple missing an \(XX\) pair has profile \((0,0)\) or \((1,1)\). Write \(h(M)\in\{0,1\}\) for the common \(e,f\)-bit in the latter two cases. Put
\[
A=q_{14}+A_1+C_4,\qquad R=r_{23}+B_2+X_3.
\]
The fixed \(T\)-half \(R\) has exceptional loads \(1+h(X_3)\) on each edge, so the \(S\)-half \(A\) has exceptional loads \(1-h(X_3)\) on each.

Switch the bichromatic terminal path between \(q_{14}\) and \(A_1\) within \(A\), retaining the complete \(C_4\) mask. Its triple endpoint belongs to \(\{2,3,5\}\). Endpoints \(3,5\) would give states \(34,45\in T\) against the unchanged \(T\)-state \(23\) of \(R\); both are forbidden. Hence the endpoint is \(2\), and the same half-load has a decomposition
\[
A=q_{24}+P_2+C_4.                                      \tag{2}
\]
The first two matchings in (2) have profiles \((0,1)\) and \((1,0)\). Therefore \(A(e)=A(f)=1+h(C_4)\). Comparing with \(1-h(X_3)\) gives
\[
h(C_4)=h(X_3)=0,\qquad A(e)=A(f)=1.                    \tag{3}
\]
In particular, (1) now has \(h(q_{14})+h(A_1)=1\).

If \(h(q_{14})=1\), its complement lies in the bipartite graph \(H-\{e,f\}\). Its two unused semiedges lie in \(X\), so the terminal path and all closed components of the complement are even. Alternating them gives a Tait colouring missing \(14\).

It remains to consider \(h(q_{14})=0\), \(h(A_1)=1\). Switch the \(q_{14},C_4\) terminal path in \(A\), leaving \(A_1\) literally fixed. Negative support forces its triple endpoint to be \(3\), since only the new state \(13\) among \(12,13,15\) lies in \(S\). Thus
\[
A=q_{13}+A_1+P_3.                                      \tag{4}
\]
Both switched matchings in this step avoided \(e,f\), so \(h(q_{13})=h(P_3)=0\). Next switch the \(q_{13},A_1\) terminal path, retaining \(P_3\). Its endpoint is forced to be \(5\): the other candidate states \(23,34\) lie in \(T\). We get
\[
A=q_{35}+P_5+P_3.                                      \tag{5}
\]
Since \(A(e)=A(f)=1\) and \(h(P_3)=0\), exactly one of \(q_{35},P_5\) uses both exceptional edges.

Suppose \(h(P_5)=1\), so \(h(q_{35})=0\). Switch the \(q_{35},P_3\) terminal path in (5), retaining \(P_5\). The only allowed endpoint is \(2\), giving state \(25\); the alternatives \(15,45\) are forbidden \(T\)-states. But every state-\(25\) decomposition with this retained \(P_5\) has profiles
\[
(q_{25},P_2,P_5)|_{e,f}
  =((0,1),(1,0),(1,1)),
\]
whose load on both \(e,f\) is \(2\), contrary to (3). Thus \(h(q_{35})=1\). As in the first case, the bipartite complement of \(q_{35}\) alternates to an actual Tait colouring missing \(35\). \(\square\)

## Consequence for the complete \(B_2+C_4\) spectra

Equation (3) holds for **every** actual left \((14)(23)\) row under the theorem's assumptions. Therefore every left \(B_2+C_4\) pair load has profile
\[
(B_2+C_4)|_{e,f}=(1,0).                              \tag{6}
\]
If an actual right \((25)(34)\) row is also present, [Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) provides a right row with \(h(C_4)=0\): this is immediate when its class-three singleton uses both exceptional edges, and otherwise follows by the fixed-\(B_2,Y_3,r_{34}\) involution. Thus
\[
\boxed{(1,0)\in
  \operatorname{proj}_{e,f}\Lambda_L(H)
  \cap\operatorname{proj}_{e,f}\Lambda_R(H).}           \tag{7}
\]
The left and right \(C_4\) matchings in (7) need not be the same complete mask. Equation (7) does not imply \(\Lambda_L(H)\cap\Lambda_R(H)\ne\varnothing\), nor does the theorem exclude an \(S\)-Tait exact-Case-XII pole. It identifies the surviving obstruction as a discrepancy away from the two exceptional edges inside actual pair-load fibres.

There is a concrete path constraint on any pair load counted in (6) or (7). The edge-copy multigraph of \(B_2+C_4\) has one terminal path, joining \(2\in Y\) to \(4\in X\), and otherwise consists of even alternating cycles, including possible doubled edges. Its only exceptional-edge occurrence is \(e\), since \(f\) is absent. A closed alternating cycle containing \(e\) alone would have odd length in the bipartition of \(H-\{e,f\}\), which is impossible. Hence **\(e\) lies on that unique \(2\)--\(4\) terminal path**. A common complete pair load must therefore synchronize this entire path as well as its cycle loads; agreement at \(e,f\) alone does not supply either synchronization.
