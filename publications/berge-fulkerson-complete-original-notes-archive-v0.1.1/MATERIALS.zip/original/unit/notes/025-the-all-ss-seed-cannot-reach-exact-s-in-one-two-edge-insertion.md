> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The all-SS seed cannot reach exact-S in one two-edge insertion

Let \(H\) be the order-thirteen pole of Note 024.  Its active matching-level
exchange graph is connected and all designated disjoint S--T completions
have route SS, but its Tait state graph is \(K_5\), rather than the
five-cycle \(S\).  This note determines whether one smallest order-raising
move can repair precisely that missing exact-S hypothesis.

The pole has 17 proper edges and five labelled semiedges.  For each unordered
pair of distinct edge objects, subdivide both and join the new subdivision
vertices.  These

\[
\binom{22}{2}=231
\]

labelled moves form its complete one-step order-fifteen neighbourhood.
Boundary relabelling is allowed, so a child is exact-S at the Tait level
exactly when its Tait state graph is any 5-cycle.

## Complete local exclusion

No child has five Tait states.  The exact distribution is

\[
\begin{array}{c|rrrrr}
|H_{\rm Tait}|&6&7&8&9&10\\\hline
\text{all moves}&9&2&32&57&131\\
\text{proper--proper}&4&2&15&34&81\\
\text{proper--semiedge}&5&0&17&23&40\\
\text{semiedge--semiedge}&0&0&0&0&10.
\end{array}
\]

Thus every move fails before S--T support, active exchange connectivity,
route class, or an A-cover becomes relevant.  In particular this complete
neighbourhood contains no counterexample to the exact-S conjecture in
Note 015.

The nine closest children have six states.  In every case, the four states
deleted from the parent \(K_5\) form a complete star; the surviving state
graph is \(K_4\sqcup K_1\), never a 5-cycle.  Five such moves pair the
proper edge \((7,10)\) with one of the five semiedges and delete the four
states incident with that boundary position.  The other four are
proper--proper moves with the same star-deletion pattern.

## Seed-local Kempe explanation

The exclusion can be recovered without enumerating the child's perfect
matchings.  Attach a labelled dummy endpoint to every semiedge and fix one
of the seed's 24 Tait colourings.  For selected edge objects \(e,f\), choose
a two-colour subgraph containing their colours, delete \(e,f\), and take a
union \(U\) of components which separates both pairs of endpoints.  Switch
the two colours on \(U\).  The two segments at each new subdivision vertex
then have distinct colours, and the joining edge receives the third colour.
For a semiedge, the component containing its dummy endpoint determines the
new boundary colour.

This constructs a Tait colouring of the child from the parent.  Over all 24
parent colourings and all admissible component unions, the resulting
boundary-state set agrees exactly, for each of the 231 moves, with an
independent complete perfect-matching enumeration of the child.  Hence the
Kempe lift proves the seed-local bound

\[
|H_{\rm Tait}(H')|\ge6
\]

throughout the one-step neighbourhood and explains the star-deletion cases.

This is a complete finite exclusion only for the specified seed and move.  It
does not cover every order-fifteen pole, arbitrary two-edge insertions from
other parents, or larger modifications, and it does not decide Note 015.

The direct and Kempe-derived calculations are implemented in
`scratch/worker-kempe/exact_s_seed_neighbourhood_scan.py` and
`scratch/worker-kempe/two_edge_kempe_lift_audit.py`; their terminal markers
are `EXACT_S_SEED_NEIGHBOURHOOD_SCAN_OK` and
`TWO_EDGE_KEMPE_LIFT_AUDIT_OK`.
