> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The complete seed one-step family has radius-one rounding

[Note 035](035-radius-one-variable-q-rounding-holds-on-the-first-173-seed-children.md)
proved radius-one variable-\(Q\) rounding on the first 173 labelled
one-step children of the order-fifteen exact-\(S\) pole from
[Note 020](020-exact-s-allows-odd-half-support-cycles.md).  This note
completes the remaining moves \(174,\ldots,300\), and hence the entire
labelled one-step family.  It is a complete finite-family theorem, not
an arbitrary-order radius-one theorem.

## Finite statement

Take the twenty-five labelled edge objects of the Note 020 pole.  For
each of their

\[
\binom{25}{2}=300
\]

pairs, subdivide the two selected objects and join the new vertices,
giving a labelled order-seventeen child.

For every such child whose complete Tait state set is exactly

\[
S=\{13,14,24,25,35\},
\]

and every edge-covering five-tuple of third matchings
\(Q=(Q_0,\ldots,Q_4)\), the following holds.  If the complete fixed-\(Q\)
endpoint fibre has no capacity-two split, then there are a state \(t\)
and a same-boundary perfect matching \(Q'_t\) such that

\[
Q'_j=Q_j\quad(j\ne t),\qquad
Q_t\mathbin\triangle Q'_t
\]

is one internal alternating cycle, the new tuple \(Q'\) still covers
every edge, and its complete fixed-\(Q'\) endpoint fibre has a
capacity-two split.

## Complete suffix computation

The 127 moves \(174,\ldots,300\) contain 69 exact-\(S\) children.
Complete perfect-matching enumeration, grouping by third matching and
enumeration of the full Cartesian product give

\[
177{,}474\text{ distinct }Q\text{-tuples},
\qquad
26{,}147\text{ edge-covering }Q\text{-tuples}.
\]

Of the edge-covering tuples, 25,997 round with \(Q\) fixed.  The remaining
150 are fixed-\(Q\) failures.  For each failure, every same-boundary
one-state replacement whose symmetric difference is one connected
internal even cycle was tested; the replacement was required to preserve
edge coverage, and its complete fixed fibre was searched over all
32 boundary-source choices and all endpoint variants.  The result is

\[
\boxed{150/150}
\]

radius-one repairs, with no failure.  The 150 failures occur in moves

\[
174,175,215,216,217,225,226,227,228,229.
\]

An independent verifier rebuilds the labelled children, exact-\(S\)
relations, third-matching groups, 32 source patterns, capacity search
and single-internal-cycle predicate.  It shares only the project Pole
type and perfect-matching enumerator with the primary driver.  It
reproduces every per-move count and the aggregate

\[
(69,\ 177474,\ 26147,\ 25997,\ 150,\ 150).
\]

## Complete 300-move family

Combining the suffix with Note 035 gives 165 exact-\(S\) children,
48,690 edge-covering \(Q\)-tuples, 48,485 fixed-\(Q\) successes and
205 fixed-\(Q\) failures.  All

\[
\boxed{205/205}
\]

fixed failures have a radius-one repair.

The new suffix is independently recomputed in full.  The combined
300-move statement inherits Note 035's evidence for moves \(1,\ldots,173\);
in particular, its first 172 moves use the complete cached fixed-\(Q\)
audit from that note rather than a new recomputation.

## Evidence and boundary

The disposable primary and independent drivers, raw aggregate data and
reproduction commands are in
[the move-174--300 result directory](../scratch/bf_radius_one_174_300_20260826/result.md).
The primary JSON has SHA-256

    b4ecf2f5287dba483865f0f14cc85789df9acf21e1d63bd8108010b79feee1f4

and the independent verifier terminates with

    RADIUS_ONE_MOVES_174_300_INDEPENDENTLY_VERIFIED

This theorem closes the entire labelled one-step neighbourhood of one
specific order-fifteen seed.  It does not cover other order-seventeen
exact-\(S\) poles, other seed neighbourhoods or arbitrary order.  The
general variable-\(Q\) radius-one conjecture remains open; the endpoint
data that a proof must control is reduced in
[Note 040](040-one-cycle-tait-transitions-are-companion-external-linkages.md)
to a companion external linkage and a cycle phase.
