> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton prism excludes the \(Cc,ab\) forbidden pair

Use the Hamilton two-spoke prism tree of [Notes 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md)–[431](431-the-hamilton-prism-excludes-the-ab-cc-forbidden-pair.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                              \tag{1}
\]
The shore carrying \(e\) has arbitrary order and complete perfect-matching family. Suppose its full BF boundary support is exact Case XII with forbidden \(e\)-labels \(\{eY,eW\}\). The only allowed five-cycles are
\[
S_1=e-X-Y-W-Z-e,\qquad S_2=e-X-W-Y-Z-e.              \tag{2}
\]

> **Pair exclusion.** Neither pentagon in (2) can be the complete exact-Case-XII BF support of a pole with exterior (1). In particular the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) required mixed type \((eY)(eX)\) cannot occur while every \(T\)--\(T\) type is absent.

Take an actual six-perfect-matching row of type \((eY)(eX)\). Let \(P=eY\) be its forbidden triple, \(R=eX\) its allowed triple, \(K=X\) and \(J=Y\) its marked singleton occurrences, and \(D_0,D_1=e\) its singleton-\(e\) occurrences. The \(X\)-starting path of \(R\triangle K\) must end at \(Z\), the only other allowed \(e\)-label: endpoints \(Y,W\) give a forbidden second triple beside unchanged \(P\). This path is wholly exterior because \(R\) uses zero proper shore ports, as in [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md).

The zero-port triples have these tree halves on \((u_1,\ldots,u_5)\):
\[
\begin{array}{c|ccccc}
R=eX:A&a&C&B&b&c\\
R=eX:B&a&A&C&b&c\\
P=eY:C&a&A&B&b&c\\
P=eY:c&a&A&C&B&b
\end{array}.                                                \tag{3}
\]
In particular \(P,R\) always saturate \(a u_1\); when \(R=eX:B\), they also saturate \(A u_2\).

**The root \(R=eX:A\) fails.** An \(X\to Z:a\) path must use \(a u_1\), already saturated by \(P,R\). The only other allowed route follows \(X-A-u_2-C-u_3-B-u_4-b-u_5-c-Z\). It occupies both \(C,c\) in \(K\), leaving neither endpoint for the unselected \(Y=Cc\) mark. Every other terminal endpoint is forbidden. Hence \(R=eX:B\).

At this root the only allowed route is
\[
X-t_X-B-u_4-b-u_5-c-t_Z-Z.                         \tag{4}
\]
The alternative through \(B,u_3,C,u_2,A,u_1,a,Z\) uses the saturated \(a u_1\). Since (4) covers \(b,c\), the other marked halves of \(K\) are \(Y:C,W:a\). Also \(P,R\) saturate \(A u_2\), so \(K\) covers \(A\) by \(A u_1\). Thus the complete exterior of \(K\) is
\[
K:X\text{ terminal},\ Y:C,\ Z:c,\ W:a,\ A u_1,\ B u_4,\ b u_5,
\quad p_2,p_3.                                             \tag{5}
\]
Switching (4) between \(R,K\) gives \(R'=eZ:c\) with the **same complete shore matching** as \(R\); \(P,J,D_0,D_1\) stay unchanged. The allowed targets of the fixed shore \(e\)-path against any \(D_i\) are
\[
\begin{array}{c|cc}
&R=eX&R'=eZ\\ \hline
S_1&Y&W\\
S_2&W&Y
\end{array}.                                                \tag{6}
\]

Since \(P,R\) saturate \(a u_1\), every occurrence among \(J,D_0,D_1\) covers \(a\) by a marked half. The \(Z,W\) edge loads and (5) force exactly one occurrence \(M\) with \(Z:c,W:a\), and two occurrences \(E\) with \(Z:a,W:b\). There are two roots of \(P\).

In every singleton-\(e\) mask below, both the \(Y\)- and \(W\)-terminal arms reach distinct exterior ports against each of \(R,R'\); the stated paths and port tables trace these arms. Because either triple uses zero exterior ports while \(D_i\) uses three, the remaining terminal arm reaches the third port. There is no exterior port-to-port component, so the fixed shore \(e\)-path must exit through the port of its prescribed target in (6).

**Root \(P=eY:C\).** Here \(P,R\) saturate \(c u_5\), while \(P,K\) saturate \(Y:C\). Both \(D_i\) must take \(Y:c\); the unique \(Z:c,W:a\) occurrence is therefore \(M=J\), and both \(D_i\) have \(Z:a,W:b,Y:c\).

For each such \(D_i\), the \(Y\)-arm under \(R\) and the \(W\)-arm under \(R'\) both exit at \(p_5\). The other two arms also reach ports: \(W\) under \(R\) exits at \(p_2,p_3\), or \(p_4\), and \(Y\) under \(R'\) exits at \(p_1,p_2\), or \(p_3\). These are distinct from the \(p_5\)-arms in their respective comparisons.

Under \(S_1\), the required \(e\to Y\) switch between \(R,D_i\) has exterior suffix \(Y-t_Y-c-u_5-p_5\). It gives a real allowed triple \(H=XY\) with \(Y:c\) and the unchanged \(Z\) terminal. The unchanged \(J=Y\) has \(Z:c\) and the \(Y\) terminal. Consequently \(Y-t_Y-c-t_Z-Z\) is a wholly exterior path of \(H\triangle J\); switching it produces \(XZ\in T_1\) beside unchanged \(P=eY\in T_1\), impossible.

Under \(S_2\), take either \(D_i\). If it has \(X:A\), its \(Y\)-terminal arm against \(R'\) exits at \(p_1\): follow \(Y-c-Z-a-u_1-p_1\). Its \(W\)-arm against \(R\) exits at \(p_4,p_2\), or \(p_3\), according to its remaining upper slots; it cannot reach \(p_1\). Equation (6) therefore forces **both** \(D_i:X:B\), but \(R:X:B\) already uses one of that half-edge's two slots. Thus \(S_2\) also fails.

**Root \(P=eY:c\).** Now \(P,R\) saturate \(A u_2,C u_3,a u_1\), while \(P,K\) saturate \(B u_4,b u_5\). The \(X:B\) half-edge has only one available slot beyond \(R\). For every \(J,D_i\), \(X:A\) forces \(B u_3\), while \(X:B\) forces \(A u_1\). At \(c\), the occurrences \(P,R,K\) use \(Y:c,c u_5,Z:c\), respectively, so \(J,D_0,D_1\) use these three slots once each.

If \(M=J\), call the two \(Z:a,W:b\) singletons \(D_F,D_G\), with \(D_F:c u_5,Y:C\) and \(D_G:Y:c\). For \(D_F\), the \(S_1\) demanded exits are
\[
\begin{array}{c|cc}
&Y\text{ under }R&W\text{ under }R'\\ \hline
X:A&p_2&p_1\\
X:B&p_3&p_2
\end{array}.                                                \tag{7}
\]
They never agree. The other arms also reach ports: \(D_F\)'s \(W\)-arm under \(R\) exits at \(p_4\), and its \(Y\)-arm under \(R'\) at \(p_4\) or \(p_3\). For \(D_G\), the \(S_2\) demanded exits are \(W\) under \(R:p_4\) and \(Y\) under \(R':p_1\) when \(X:A\), or \(p_3\) when \(X:B\). They never agree either; its other \(Y,W\)-arms both exit at \(p_5\).

If \(M=D_i\), call it \(D_M\). It has \(Y:C,Z:c,W:a,b u_4\): the \(b u_5\) slots are already occupied by \(P,K\). The other \(D\) has \(Y:c,Z:a,W:b\), while \(J\) takes \(c u_5\). The four demanded exits of \(D_M\) are
\[
\begin{array}{c|cc|cc}
&\multicolumn{2}{c|}{S_1}&\multicolumn{2}{c}{S_2}\\
&Y\text{ under }R&W\text{ under }R'&W\text{ under }R&Y\text{ under }R'\\ \hline
X:A&p_2&p_1&p_1&p_5\\
X:B&p_3&p_2&p_2&p_3
\end{array}.                                                \tag{8}
\]
Again the demanded ports differ in every row. For example, when \(D_M:X:A\), its \(Y\)-arm under \(R\) follows \(Y-C-u_3-B-X-A-u_2-p_2\), whereas its \(Y\)-arm under \(R'\) follows \(Y-C-u_3-B-u_4-b-u_5-p_5\). The other entries follow directly from the saturated slots above. This excludes both orientations at the last root, proving the pair exclusion. \(\square\)

The result uses actual complete matchings and their exchanges; neither a clean shore matching nor any shore-size or parity bound is assumed. Together with Note 431, it excludes two of the six forbidden \(e\)-pairs of this Hamilton two-spoke exterior. Note 430's remaining clean signature now pertains only to the \(\{eZ,eW\}\) pair. The other four forbidden pairs, other exteriors, full exact Case XII, and Berge–Fulkerson remain open. This hand proof awaits independent review; no OMEN or local mathematical recomputation was used.
