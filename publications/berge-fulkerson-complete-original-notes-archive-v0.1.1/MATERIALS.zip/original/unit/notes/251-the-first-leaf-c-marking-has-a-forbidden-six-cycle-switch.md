> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first-leaf C marking has a forbidden six-cycle switch

Keep the complete exact-Case-XII one-internal-mark profile and [Note 249's](249-the-first-leaf-six-cycle-has-three-surviving-markings.md) first-leaf six-cycle
\[
K=\{1O,1L,1Q,2O,2R,3O,3P,4L,4R\},\qquad h_i=u_iC\ (i=2,3,4).
\]
Consider its type C marking
\[
a:R-C,\qquad d:Q-C,\qquad b:L-P,\qquad c:P-Q,
\]
where \(e\) is the internal mark of the odd shore \(C\). Write \(iw=u_iw\) and use \(a:R,a:C\), etc., for the two halves of a subdivided mark. The shore order and matching relation are unrestricted.

**Theorem.** This marking cannot have complete exact-Case-XII support. Its pure-\(S\) half-loads have four possible singleton-\(e\) exterior masks, but the required real \((ea)(eb)\) row forces two particular masks whose difference contains a wholly exterior alternating six-cycle. Switching that cycle in both actual singleton-\(e\) matchings preserves the six-matching edge load and produces a forbidden \(T\)-state in the nominally pure half.

## Pure-half masks

In an \(ea\) decomposition \(D=X_a+Y_a+Z_e\), [Notes 230 and 249](249-the-first-leaf-six-cycle-has-three-surviving-markings.md) force
\[
\begin{aligned}
X_a|_{\rm ext}&=\{a:R,1Q,2O,3P,4L\},\\
Y_a|_{\rm ext}&=\{2R,1O,d:Q,b:L,c:P,h_3,h_4\}.
\end{aligned}                                                   \tag{1}
\]
Switching the exterior \(a\)--\(d\) path in \(X_a\triangle Y_a\) gives a state-\(ed\) triple \(X_d\) with the **same complete shore matching** and exterior
\[
X_d|_{\rm ext}=\{d:Q,1O,2R,3P,4L\}.                  \tag{2}
\]
Because \(ea,ed\in S\), purity requires the \(e\)-path in \(X_a\triangle Z_e\) and \(X_d\triangle Z_e\) to end at \(b,c\) in opposite orders.

Here is the complete exterior check for \(Z_e\). It uses three ports among \(a:C,d:C,h_2,h_3,h_4\). Let \(m\) count the selected ports \(a:C,d:C\). The remaining \(U\)--\(W\) edges are fixed by the uncovered singleton vertices. There are \(1,8,9\) masks for \(m=0,1,2\). Every used proper shore port has an exterior alternating path to a triple terminal in both (1) and (2). The notation \(h_i:x/y\) records the path's terminal against \(X_a\), then against \(X_d\).

| \(m\) | Mark halves of \(Z_e\) | \(U\)--\(W\) edges | Used \(h\)-ports and terminal pairs |
|---:|---|---|---|
| 0 | \(a:R,d:Q,b:L,c:P\) | \(1O\) | \(h_2:d/a,\ h_3:c/c,\ h_4:b/b\) |
| 1 | \(a:C,d:Q,b:L,c:P\) | \(1O,2R\) | \(h_3:c/c,\ h_4:b/b\) |
| 1 | same | \(1O,4R\) | \(h_2:d/b,\ h_3:c/c\) |
| 1 | \(a:R,d:C,b:L,c:P\) | \(1Q,2O\) | \(h_3:c/c,\ h_4:b/b\) |
| 1 | same | \(1Q,3O\) | \(h_2:c/a,\ h_4:b/b\) |
| 1 | \(a:R,d:C,b:L,c:Q\) | \(1O,3P\) | \(h_2:c/a,\ h_4:b/b\) |
| 1 | \(a:R,d:C,b:P,c:Q\) | \(1O,4L\) | \(h_2:c/a,\ h_3:b/b\) |
| 1 | same | \(1L,2O\) | \(h_3:b/b,\ h_4:c/a\) |
| 1 | same | \(1L,3O\) | \(h_2:b/a,\ h_4:c/b\) |
| 2 | \(a:C,d:C,b:L,c:P\) | \(1Q,2O,4R\) | \(h_3:c/c\) |
| 2 | same | \(1Q,3O,4R\) | \(h_2:c/b\) |
| 2 | same | \(1Q,2R,3O\) | \(h_4:b/b\) |
| 2 | \(a:C,d:C,b:L,c:Q\) | \(1O,2R,3P\) | \(h_4:b/b\) |
| 2 | same | \(1O,3P,4R\) | \(h_2:c/b\) |
| 2 | \(a:C,d:C,b:P,c:Q\) | \(1L,3O,4R\) | \(h_2:b/b\) |
| 2 | same | \(1O,2R,4L\) | \(h_3:b/b\) |
| 2 | same | \(1L,2O,4R\) | \(h_3:b/b\) |
| 2 | same | \(1L,2R,3O\) | \(h_4:c/b\) |

To check completeness, \(d:Q,c:Q\) and \(b:P,c:P\) are the only forbidden pairs of marked singleton endpoints. Once four marked halves and \(m\) shore ports are chosen, \(u_1\) must use one of \(1O,1L,1Q\); the other unmatched \(W\)-vertices determine the displayed \(K\)-edges and which \(h_i\) are used. No shore-internal matching was assumed. The shore \(e\)-path cannot pair with \(a:C\), because this port goes directly to terminal \(a\) against \(X_d\), or with \(d:C\), because it goes directly to \(d\) against \(X_a\). Thus only the displayed \(h_i\) can be its port. The four \(c/b\) entries, and no others, give the required exchange:

| Mask | \(Z_e|_{\rm ext}\) | \(e\)-paired port | Edges shared with \(A=X_a+Y_a\) |
|---|---|---|---|
| \(Z_1\) | \(a:R,d:C,b:P,c:Q,1L,3O,h_2,h_4\) | \(h_4\) | \(a:R,h_4\) |
| \(Z_2\) | \(a:C,d:C,b:L,c:P,1Q,3O,4R,h_2\) | \(h_2\) | \(b:L,c:P,1Q\) |
| \(Z_3\) | \(a:C,d:C,b:L,c:Q,1O,3P,4R,h_2\) | \(h_2\) | \(b:L,1O,3P\) |
| \(Z_4\) | \(a:C,d:C,b:P,c:Q,1L,2R,3O,h_4\) | \(h_4\) | \(2R,h_4\) |

All four require \(S=e-a-c-b-d-e\). These are necessary exterior masks, not assertions that a particular shore realizes any of them.

## The real \((ea)(eb)\) row and its six-cycle

Here \(eb\in T\), and the [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real row
\[
D=X_a+Y_a+Z_e,\qquad E=U_{eb}+V_b+W_e,
\qquad D+E=2\mathbf1.                                  \tag{3}
\]
The opposite \(T\)-state makes \(D\) pure \(S\). Exchanging the **complete** singleton-\(e\) matchings \(Z_e,W_e\) keeps the row valid and the opposite state in \(T\), so both \(Z_e,W_e\) must occur in the four-mask table.

The zero-port triple \(U_{eb}\) selects \(b:L\) or \(b:P\); deleting that singleton vertex from \(K\) gives respectively the unique exteriors
\[
U_L=\{b:L,1Q,2O,3P,4R\},\qquad
U_P=\{b:P,1Q,2R,3O,4L\}.                              \tag{4}
\]
Every exterior edge in the support of \(A=X_a+Y_a\) has load one. On such an edge, at most one of \(Z_e,W_e,U_{eb}\) may occur, since \(V_b\) has nonnegative load and (3) totals two. The last column of the four-mask table first leaves only the unordered pairs \(\{Z_1,Z_2\},\{Z_1,Z_3\},\{Z_2,Z_4\},\{Z_3,Z_4\}\). The \(A\)-edges of \(U_L\) are \(b:L,1Q,2O,3P\), meeting every one of these four pairs. The \(A\)-edges of \(U_P\) are \(1Q,2R,4L\); they meet all but \(\{Z_1,Z_3\}\). Therefore every such row must use exactly \(Z_1,Z_3\) as its two singleton-\(e\) matchings, and \(U_{eb}=U_P\). This is only a necessary edge-load conclusion; no assumption about \(V_b\) or the shore is needed.

The exteriors of \(Z_1,Z_3\) differ along the wholly exterior alternating six-cycle
\[
\mathcal C=t_b-P-u_3-O-u_1-L-t_b,
\]
whose \(Z_1\)-edges are \(b:P,3O,1L\) and whose \(Z_3\)-edges are \(3P,1O,b:L\). Flip \(\mathcal C\) in **both** complete singleton-\(e\) matchings. They remain actual perfect matchings with the same singleton boundary and unchanged shore masks; their sum, and thus the entire row's edge load, is unchanged.

If \(D\) originally used \(Z_1\), its flipped matching has exterior
\(a:R,d:C,b:L,c:Q,1O,3P,h_2,h_4\). Its unchanged shore \(e\)-path still uses \(h_4\), but the exterior route from \(h_4\) ends at \(b\) against \(X_a\). If \(D\) originally used \(Z_3\), its flipped matching has exterior \(a:C,d:C,b:P,c:Q,1L,3O,4R,h_2\); its unchanged shore \(e\)-path uses \(h_2\), whose exterior route also ends at \(b\) against \(X_a\). Switching that \(e\)--\(b\) path between \(X_a\) and the flipped singleton matching gives a decomposition of the new \(D\) in state \(ab\in T\). The opposite half still has state \(eb\in T\), contradicting exact Case XII. Thus no row (3) exists, and type C is impossible at every shore order and rank. \(\square\)

Together with [Note 250](250-the-first-leaf-d-marking-forces-a-doubled-cross-half.md), this leaves only type B in Note 249's first-leaf shape. The other four-vertex exterior shapes, larger barriers, other Tutte profiles and Berge--Fulkerson remain open. The finite mask table and analytic closure proof are hand-derived and have not received an independent check.
