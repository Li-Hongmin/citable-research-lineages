> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A surviving zero-port mask forces an S-Tait state

Continue the \(3{:}2\) unmarked-core profile of [Notes 282–283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md). Use shore ports \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). Assume the two proper shore ports on the \(R\) side of the bipartition of \(F[\Sigma]-g\) are precisely \(A,I\). Thus \(D,H,J\) are on the \(B\) side. The marked edge has ends \(v\in B,w\in R\), and \(g\) joins two \(B\)-vertices.

**Theorem.** Suppose the complete zero-port shore matching fibre contains an actual matching \(X'\) that selects both \(t_ew\) and \(g\). Under exact-Case-XII negative support, the complementary degree-two shore graph has the **unique port pairing**
\[
\boxed{AH\mid EI\mid DJ.}                                \tag{1}
\]
The same \(X'\), glued to the actual zero-port exterior matching of missing-pair state \(ea\), extends to a Tait colouring in that allowed \(S\)-state. Consequently the pole's Tait-state set is all of \(S\). Neither the existence of \(X'\) nor the exact Case-XII support is asserted here.

## Two forbidden completions fix the pairing

Colour the subdivision vertex \(t_e\) with \(R\) and align the exterior endpoints of all proper shore interfaces with \(R\). As in Note 283, the full five-pole minus \(\{g,t_ew,A,I\}\) is bipartite. The matching \(X'\) uses \(g,t_ew\), so any zero-port triple formed from it has only the two cut edges \(A,I\) as possible odd-cycle exceptions in its complement.

There are two independently valid exterior matchings with boundary \(a,c,d\), hence missing pair \(eb\):
\[
\begin{array}{c|c|c}
\text{selected half and path edges}&\text{exterior complement}&\text{name}\\\hline
b:A_{\rm ext};\ 1B,2C,3D,4E&ID\mid AH,\quad b\to J&P_0\\
b:D_{\rm ext};\ 1A,2B,3C,4E&AD\mid HJ,\quad b\to I&P_1.
\end{array}                                                     \tag{2}
\]
Each also selects terminal semiedges \(a,c,d\). Their sole shore interface is empty, so each glues to this **same complete** \(X'\). Let \(\sigma\) be the pairing of the six ports in the complement of \(X'\) restricted to the shore. Every closed shore component is even because \(X'\) already uses both internal bipartition exceptions \(g,t_ew\).

The two cut exceptions \(A,I\) must lie in **different** components of each full triple complement. If they shared a component, every closed cycle would contain zero or two exceptions and be even, extending the triple to a forbidden \(eb\) Tait colouring by [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md).

In \(P_0\), edge \(I\) lies on the exterior \(ID\) path and edge \(A\) on the exterior \(AH\) path. Those two paths can occupy different full components only if \(\sigma\) contains \(ID\) or \(AH\); otherwise they belong to the same component, which may be the terminal path or a closed cycle. In \(P_1\), edge \(I\) lies on the terminal \(b\)--\(I\) arm. To keep \(A\) separate, the exterior \(AD\) path must close into a cycle. This occurs only if \(\sigma\) contains \(AD\) or \(EI\): in the latter case the terminal path connects directly through \(EI\), and the remaining four ports form one or two cycles with the exterior \(AD,HJ\) paths.

The pairing \(\sigma\) is a perfect matching of six distinct port positions. Of the four combinations
\[
\{ID,AH\}\times\{AD,EI\},
\]
only \(AH\) together with \(EI\) are disjoint. The final pair is then \(DJ\), proving (1). \(\square\)

## The allowed \(ea\) colouring

Keep \(X'\) and select the state-\(ea\) zero-port exterior mask
\[
a:C_{\rm ext},\quad 1A,2B,3D,4E,
\quad\text{terminal semiedges }b,c,d.                     \tag{3}
\]
Its exterior complement connects \(a\)--\(A\), \(I\)--\(J\), and \(D\)--\(H\). With (1), the unique terminal path of the complete triple complement is
\[
e-E-I-J-D-H-A-a.                                          \tag{4}
\]
Both remaining exceptional cut edges \(I,A\) lie on this path. Since \(g,t_ew\) are in the triple matching, every closed complement component lies in the bipartite graph obtained by deleting all four exceptions and is even. Alternating the complement therefore gives a genuine Tait colouring in state \(ea\in S\). Bichromatic terminal-path switches propagate one \(S\)-Tait state around the allowed pentagon, while exact support excludes all \(T\)-Tait states through its absent \(T\)-loops. The Tait-state set is exactly \(S\). \(\square\)

This is a conditional **complete-PM-family** consequence for one surviving port-side placement, not a BF-cover construction or a contradiction. If the \((t_ew,g)\) zero-port profile is absent, the theorem gives no new Tait state. The complementary path pairings and the upstream central-path embedding are hand-derived and await independent verification.
