> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One long root signature survives the adjacent-allowed-pair gate on the \(K_{3,3}\) Hamilton path

Work in the \(|U|=r=5\), one-internal-mark, one-shore profile of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). Let its suppressed exterior be \(K_{3,3}\) with Hamilton tree
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,\qquad
(X,Y,Z,W)=(14,16,25,36).                              \tag{1}
\]
The tree bipartition is \(\{1,3,5\}\mid\{2,4,6\}\). The four omitted edges are exactly the displayed marks. The arbitrary shore has terminal \(e\) and proper ports \(p_i\) at \(u_i\).

Assume complete exact-Case-XII support with forbidden \(e\)-states \(\{eZ,eW\}\). The allowed \(e\)-states are \(eX,eY\). The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual row \((eZ)(eX)\). Name its six **complete** matching occurrences
\[
P=eZ,\quad R=eX,\quad K=X,\quad J=Z,\quad a=e,\quad b=e.
\tag{2}
\]
The fixed half \(P+b+J\) has state \(eZ\in T\).

**Necessary-root theorem.** Every genuine row (2) under this exact support must have
\[
\boxed{\begin{gathered}
R=eX\text{ rooted at }X:4,\qquad
K:X\text{ on the terminal};\\
K:Y:1,\ Z:5,\ W:6,\quad
K:2u_1,\ 3u_2,\ 4u_3,\quad
\partial K_{\rm proper}=\{p_4,p_5\};\\
R\triangle K\text{ has the exterior terminal path }
X-t_X-4-u_3-3-u_2-2-u_1-1-t_Y-Y.
\end{gathered}}                                                \tag{3}
\]
This is a necessary signature, not an assertion that such a complete BF row or an exact-support pole exists.

**Proof.** The \(X\)-starting component of \(R\triangle K\) must end at \(Y\). Ending at \(Z\) makes \(R\) a state-\(eZ\) triple beside \(P=eZ\), giving forbidden \([eZ]\); ending at \(W\) gives forbidden \((eZ)(eW)\). Since \(R\) is a zero-port triple, its rooted tree matching takes one tree half at every \(u_i\). The component can leave an original vertex by a \(K\)-marked half, ending at that mark's terminal, or by a \(K\)-tree half. In the latter case it leaves the tree subdivision on \(R\)'s opposite half, never entering the shore, and moves monotonically away from the root. The singleton \(K\) takes exactly three tree halves, so its \(X\)-to-\(Y\) route crosses at most three tree edges.

The endpoint pairs \(X:(1,4)\), \(Y:(1,6)\) allow four tree routes. \(1\to6\) has five edges and is too long. The direct \(1\to1\) route is
\[
X-t_X-1-t_Y-Y.
\tag{4}
\]
At vertex \(1\), either rooted state-\(eZ\) triple \(P\) takes the third edge \(1u_1\). Relabel \((X_{\rm lemma},Y_{\rm lemma},Z_{\rm lemma},W_{\rm lemma})=(Z,W,X,Y)\) in the [local two-root switch lemma of Note 488](488-a-local-two-root-switch-excludes-the-adjacent-hamilton-pair.md). It excludes (4): the required \(eZ\in T\) half cannot coexist with the direct switch between the allowed \(eX,eY\) states.

On \(4\to6\), \(K\) takes \(4u_4,5u_5,Y:6\). Its \(Z\)-half must be \(Z:2\), since vertex \(5\) is already covered; its \(W\)-half must be \(W:3\), since vertex \(6\) is already covered. Its remaining uncovered original vertex is \(1\), so its third tree half is \(1u_1\). But \(R\), rooted at \(X:4\), also takes \(1u_1\), as does \(P\) rooted at either endpoint of \(Z=25\). These three occurrences overload that edge.

Only \(4\to1\) remains. Its three tree halves are forced to be \(4u_3,3u_2,2u_1\). They cover original vertices \(4,3,2\); \(Y:1\) covers vertex \(1\). The other two marked halves are forced to be \(Z:5,W:6\), and the unused tree subdivisions give ports \(p_4,p_5\). This is exactly (3). \(\square\)

Path reflection \(i\mapsto7-i\) fixes \(Z=25\) and \(Y=16\), and interchanges \(X=14\) with \(W=36\). It gives the corresponding single-long-route necessary signature when the forbidden pair is \(\{eZ,eX\}\). [Notes 490--494](494-the-last-two-k33-long-signatures-also-force-forbidden-ew-loops.md) subsequently realize genuine rows of signature (3) with forbidden full support and exclude its exact-Case-XII use for both reflected forbidden pairs. The other forbidden pairs, the one-spoke prism family, other five-pole profiles and Berge--Fulkerson remain open. This proof is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review.
