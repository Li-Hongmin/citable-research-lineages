> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The B cross rows require shore cycles meeting both pure paths

Continue the complete exact-Case-XII setting and type-B marked exterior of [Note 253](253-two-shared-a-cross-rows-pin-the-first-leaf-b-exterior.md). Write the six shore ports as
\[
E=e,\quad A=a:C,\quad D=d:C,\quad I=h_3,\quad H=h_2,\quad J=h_4.
\]
For either required \((ea)(ab)\) or \((ea)(ad)\) row, write its six actual perfect matchings as
\[
X+Y+Z+U+V+W=2\mathbf1,
\]
where the pure \(ea\) half is \(X+Y+Z\), and \(Y,V\) are the two singleton-\(a\) occurrences. Note 253 fixes their *complete exterior masks* to be equal. Its shore port table reads

| row | \(X\) | \(Y,V\) | \(Z\) | \(U\) | \(W\) |
|---|---|---|---|---|---|
| \((ea)(ab)\) | \(\varnothing\) | \(\{H,J\}\) | \(\{E,A,D,I\}\) | \(\{E,A\}\) | \(\{D,I\}\) |
| \((ea)(ad)\) | \(\varnothing\) | \(\{H,J\}\) | \(\{E,A,D,I\}\) | \(\{E,D\}\) | \(\{A,I\}\) |

In either row, the two shore terminal paths of \(X\triangle Z\) pair \(E\) with \(I\) and \(A\) with \(D\), by the purity argument of Note 253.

**Theorem.** In each of these two rows, \(Y\triangle V\) contains internal shore edges and is a union of alternating even cycles. **Each** of the \(E\)--\(I\) and \(A\)--\(D\) paths of \(X\triangle Z\) shares an edge with that union. In particular the two singleton-\(a\) occurrences cannot use the same complete shore matching, and a shore whose \(\{H,J\}\)-port matching is unique cannot realize either row with exact Case-XII negative support.

The following statement is independent of the B exterior and isolates the mechanism. Suppose six perfect matchings \(X,Y,Z,U,V,W\) of a cubic six-pole cover each proper edge twice. Let \(X\) use none of four distinguished ports, \(Z\) use all four, let \(Y,V\) have the same port set disjoint from those four, and let \(U,W\) split the four ports into two pairs. Then every terminal path of \(X\triangle Z\) whose ends lie in *different* \(U/W\) port pairs meets \(Y\triangle V\) in an edge.

**Proof.** The matchings \(Y,V\) have the same boundary, so their symmetric difference is a disjoint union of even alternating cycles using only proper edges. Let \(P\) be a distinguished terminal path of \(X\triangle Z\) whose ends belong to different \(U/W\) port pairs. Suppose \(P\) avoids \(Y\triangle V\). At each vertex of \(P\), \(Y\) and \(V\) then use the same incident edge. That edge is already loaded twice; each of the other two incident edges must be loaded twice by \(X,Z,U,W\). Because each of these four is a matching, their two-element label sets on the two remaining edges are complementary.

At the first port of \(P\), the label set is \(\{Z,U\}\) if that port belongs to \(U\), and \(\{Z,W\}\) if it belongs to \(W\). Moving along \(P\), these sets alternate respectively with \(\{X,W\}\) or \(\{X,U\}\). At its last port, \(P\) again uses a \(Z\)-edge, so the last port must belong to the **same** one of \(U,W\) as the first. This contradicts the choice of endpoints. A terminal path has degree two at every shore vertex it visits; an alternating cycle through such a vertex uses two incident edges as well. In a cubic graph they share an edge. Thus \(P\) meets \(Y\triangle V\) in an edge. \(\square\)

For \((ea)(ad)\), the \(U/W\) port partition is \(\{E,D\}\mid\{A,I\}\); for \((ea)(ab)\) it is \(\{E,A\}\mid\{D,I\}\). Both \(E\)--\(I\) and \(A\)--\(D\) cross the partition in each row. The general statement therefore proves the theorem.

There is a second, independent necessary shore feature. Note 253 makes the exterior load of each half identically one. If the pure half also loaded every internal shore edge once, the opposite half would do so too, and its three matchings would give a Tait colouring in state \(ab\) or \(ad\), both in the forbidden set \(T\). Doubling that colouring would give the forbidden loop \([ab]\) or \([ad]\). Hence each required row has a nonempty shore defect set: its internal edges of pure-half load zero or two form alternating \(0/2\) cycles. No shore port edge belongs to such a cycle, since every port is used once in each half.

This defect set cannot equal \(Y\triangle V\) edgewise. On a \(Y\)-edge of their symmetric difference, the pure-half load is one or two; on a \(V\)-edge it is zero or one, because the total row load is two. If the defect set were exactly \(Y\triangle V\), exchanging the two complete singleton-\(a\) occurrences would turn every shore load of the pure half into one while preserving the BF row. Its opposite \(T\)-half would also become unit, producing the forbidden Tait loop. Thus the shore has two distinct nonempty cycle-space elements, its singleton-difference cycles and its load-defect cycles. This conclusion is qualitative: [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) already gives a much stronger order bound for any exact pole.

## A real shore satisfying the \(ad\) rowwise gate

The cycle-intersection condition is attainable by actual matchings, even with girth five after attaching the B exterior. Let the shore have vertices \(s_0,\ldots,s_5,r_0,\ldots,r_5\), central cycle edges \(c_i=s_is_{i+1}\) (indices modulo six), spokes \(p_i=s_ir_i\), and outer edges
\[
q_{03}=r_0r_3,\qquad q_{14}=r_1r_4,\qquad q_{25}=r_2r_5.
\]
Place its ports \(H,E,I,J,D,A\) at \(r_0,r_1,r_2,r_3,r_4,r_5\), respectively. The following table gives six complete shore matchings; the port column names the semiedges used.

| matching | internal shore edges | ports |
|---|---|---|
| \(X\) | \(p_0,p_1,p_2,p_3,p_4,p_5\) | none |
| \(Y\) | \(c_0,c_2,c_4,q_{14},q_{25}\) | \(H,J\) |
| \(Z\) | \(c_1,c_4,p_0,p_3\) | \(E,A,D,I\) |
| \(U\) | \(c_0,c_3,p_2,p_5,q_{03}\) | \(E,D\) |
| \(V\) | \(c_1,c_3,c_5,q_{14},q_{25}\) | \(H,J\) |
| \(W\) | \(c_2,c_5,p_1,p_4,q_{03}\) | \(A,I\) |

At every shore vertex, each row selects exactly one incident edge. The pair labels on the internal edges are
\[
\begin{array}{c|cccccc}
&c_0&c_1&c_2&c_3&c_4&c_5\\\hline
\text{pair}&YU&ZV&YW&UV&YZ&VW
\end{array},\qquad
\begin{array}{c|ccc}
&p_0,p_3&p_1,p_4&p_2,p_5\\\hline
\text{pair}&XZ&XW&XU
\end{array},
\]
while \(q_{03},q_{14},q_{25}\) carry \(UW,YV,YV\). The ports carry \(YV\) at \(H,J\), \(ZU\) at \(E,D\), and \(ZW\) at \(A,I\). Thus every edge, including every port, has load two. The paths of \(X\triangle Z\) pair \(E\)--\(I\) through \(c_1\) and \(A\)--\(D\) through \(c_4\). The difference \(Y\triangle V\) is exactly the central six-cycle; it meets both paths, at \(c_1\) and \(c_4\).
The pure half \(X+Y+Z\) is nonunit on the shore: along
\[
s_0-r_0-r_3-s_3-s_4-s_5-s_0
\]
its six edge loads alternate \(2,0,2,0,2,0\). Thus the example also meets the defect-cycle requirement of an exact row, although its complete support fails elsewhere.

Glue this shore to the type-B exterior using, in order, the six exterior masks \(X_a,Y_a,Z_e,U_{ad},V_a,W_d\) of Note 253. Each table row becomes a complete perfect matching of the resulting 25-vertex connected cubic five-pole, and the pair-label tables plus Note 253's exterior partition prove a genuine \((ea)(ad)\) BF row. The shore has girth six. The exterior \(K\) has girth six; subdividing either cross mark \(b,c\) introduces no shorter cycle. The five distinct exterior endpoints of the shore interfaces \(u_2,u_3,u_4,t_a,t_d\) are pairwise nonadjacent, so a cycle crossing the interface twice uses at least two exterior edges, one shore edge, and the two interface edges. A cycle crossing it four or more times is longer still. Thus the full pole has girth at least five, and \(u_2-r_0-r_3-u_4-R-u_2\) shows equality.

This is a counterexample to the claim that the B exterior and the required pure \(E\)--\(I\) pairing alone make the \((ea)(ad)\) row impossible. It cannot supply the other required \((ea)(ab)\) row: there is **no shore matching with ports \(\{E,A\}\)**. Indeed, using the ports at \(r_1,r_5\) forces the spokes \(p_2,p_4\), because the alternative outer edges \(q_{25},q_{14}\) meet those port vertices. If \(r_0,r_3\) use \(q_{03}\), the unmatched central vertices are \(s_0,s_1,s_3,s_5\), of which \(s_3\) is isolated in the remaining central path. If they use \(p_0,p_3\), the unmatched central vertices are the nonadjacent pair \(s_1,s_5\). Both possibilities fail. The \(ab\) row's triple \(U\) requires precisely \(\{E,A\}\), so it is absent even before testing BF load two.

The pole fails exact negative support for a second, explicit reason. On this same shore, the three matchings
\[
X=\{p_0,\ldots,p_5\},\quad
Y=\{c_0,c_2,c_4,q_{14},q_{25};H,J\},\quad
Z'=\{c_1,c_3,c_5,q_{03};E,A,D,I\}
\]
partition every shore edge once. Glue them to the three exterior matchings \(U_{eb},V_b,W_e\), respectively, in [Note 252](252-the-first-leaf-b-marking-has-a-real-cross-row.md). Those exterior masks also partition every exterior edge once and have terminal boundaries \(\{a,c,d\},\{b\},\{e\}\). The result is a genuine Tait colouring of the 25-vertex pole with missing pair \(eb\in T\); doubling its three perfect matchings gives the forbidden BF loop \([eb]\). Its order 25 also lies below the published exact-Case-XII bound of [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md).

The same gluing observation gives an all-orders necessary signature exclusion. The B exterior has unit-load triples with shore port partitions \(\varnothing\mid HJ\mid EADI\) in Note 252 and \(ED\mid HJ\mid AI\), \(EA\mid HJ\mid DI\) in Note 253. Their full-pole Tait states would be, respectively, \(eb,ad,ab\), all forbidden members of \(T\). Therefore an exact-Case-XII B shore cannot admit a three-edge colouring with **any** of these three port partitions. Its required \(ab\) and \(ad\) BF rows must realize the last two partitions with nonunit shore loads in both halves.

The cycle-intersection and defect-cycle conclusions use actual complete matching masks and exact negative support. They exclude rigid \(\{H,J\}\)-matching shores, including the six-cycle shore of [Note 252](252-the-first-leaf-b-marking-has-a-real-cross-row.md), regardless of which opposite cross row is attempted. The 25-vertex example shows that one \(ad\) row can pass the shore gate but that the \(ab\) row is a separate necessary constraint. Simultaneous \(ab\) and \(ad\) rows with full exact support, type B as a whole, and Berge--Fulkerson remain open.

The proof and the matching table were derived and checked by hand; they have not received an independent verification.
