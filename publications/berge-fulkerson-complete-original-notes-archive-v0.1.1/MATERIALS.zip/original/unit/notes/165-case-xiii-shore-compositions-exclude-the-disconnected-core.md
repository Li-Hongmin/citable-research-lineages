> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Case-XIII shore compositions exclude the disconnected marked core

Consider the marked five-cut remaining in [Notes 161–164](164-disjoint-shore-pairs-exclude-a-pentagon-rstar-five-cut.md). Its two odd shore five-poles compose by the exact six-slot rule of [Note 163, (1)](163-five-cut-perfect-matching-closure-composes-shore-bf-relations.md). This note excludes the last two shore combinations, \(R^*–L^*\) and \(R^*–T_3\), for **every** relative terminal labelling. Here \(T_3\) is the three-vertex path with two ports at each end and one at its centre. Consequently, assuming the preceding structural reductions, a minimum-host exact-Case-XII pole has **connected** unmarked core \(F=J-M\). The new argument is analytic; Notes 157–164 and this implication still require independent proof checking. It gives no conclusion for connected \(F\).

## Which Case-XIII relation is used

In [Máčajová–Mazzuoccolo–Tabarelli (2026), Proposition 4.4 and Figure 7](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), put
\[
P=\{13,14,24,35,45\},\qquad Q=\{12,15,23,25,34\}.
\]
The Figure 7 \(R^*\) has every pair type across \(P,Q\), no loop type, and the all-terminal type. Its \(L^*\) has both complete five-vertex pair graphs on \(P\) and \(Q\), together with all ten loop types. The all-terminal \(R^*\) type cannot enter this five-cut composition by Note 163: an all-five-boundary shore matching cannot be disjoint from the other odd shore's boundary in the same slot.

Appendix XIII repeats \(45\) in the second \(L^*\) five-clique in place of \(25\). Read literally, its \((12)(45)\) would also lie in \(R^*\), although the paper requires the two graphs to be edge-disjoint. Figure 7 shows the \(25\) vertex, its loop, and its black clique edges. The statements here use that figure. This is a source-text discrepancy, not an extra graph-theoretic assumption silently attributed to the Appendix.

We need two immediate six-slot consequences. The rectangle construction of Note 163 says that shore types \((xy)(xz)\) and \((wy)(wz)\), for four distinct labels \(x,w,y,z\), produce terminal loop \([xw]\). Also, if **both** shores have the same type \((xy)(xz)\), they produce \([yz]\): pair each shore triple missing \(xy\) or \(xz\) with the other shore's singleton \(x\), then cross-pair the remaining singleton \(y,z\) slots. Every paired boundary is disjoint. The common-*disjoint*-type obstruction of Note 164 remains in force: if both shores support \((ab)(cd)\) with four distinct labels, the terminal support contains the four-cycle of loops on \(\{a,b\}\mid\{c,d\}\), impossible in exact Case XII.

## \(R^*–L^*\): alignment still produces six loops

Give the \(R^*\) shore the displayed \(P,Q\) labels, and let \(P_L,Q_L\) be the two classes of a terminal-permuted \(L^*\). A common disjoint pair type is forbidden. Thus, for every disjoint pair of states of opposite \(R^*\) classes, those two states must also have opposite \(L^*\) classes. The graph of these opposite-\(R^*\)-class disjoint pairs has components
\[
13-25-14-23-45-12-35,\qquad 24-15,\qquad \{34\}.       \tag{1}
\]
On each component, the \(L^*\) class colouring must equal the \(R^*\) colouring or its complement. Each \(L^*\) class has five states. If the seven-state path is unchanged, the isolated \(34\) must also be unchanged; the possible \(P_L\) sets are \(P\) and \(P-\{24\}+\{15\}\). The latter has an isolated terminal vertex \(2\), whereas every terminal relabelling of the graph \(P\) has minimum degree one. If the path is flipped, \(34\) must also be flipped; the two possible \(P_L\) sets are \(Q\) and \(\{12,23,24,25,34\}\). The latter has terminal degree four at \(2\), whereas \(P\) has maximum degree three. Hence the **unordered** partition of the \(L^*\) shore is exactly \(\{P,Q\}\). Whether a terminal permutation can interchange \(P,Q\) is immaterial.

With these aligned classes, the rectangle construction gives six different terminal loops. Each row lists actual shore BF types from Figure 7; the two states in its \(R^*\) column cross \(P,Q\), and those in its \(L^*\) column lie within one class.

| terminal loop | \(R^*\) shore type | \(L^*\) shore type | rectangle \(x,w;y,z\) |
|---|---|---|---|
| \([12]\) | \((13)(15)\) | \((23)(25)\) | \(1,2;3,5\) |
| \([13]\) | \((12)(14)\) | \((23)(34)\) | \(1,3;2,4\) |
| \([24]\) | \((14)(34)\) | \((12)(23)\) | \(4,2;1,3\) |
| \([25]\) | \((23)(24)\) | \((35)(45)\) | \(2,5;3,4\) |
| \([34]\) | \((13)(23)\) | \((14)(24)\) | \(3,4;1,2\) |
| \([35]\) | \((13)(23)\) | \((15)(25)\) | \(3,5;1,2\) |

Exact Case XII has only five loop types. An unaligned partition was already excluded by (1); an aligned one has the six loops above. Therefore no \(R^*–L^*\) marked five-cut composes to exact Case XII.

## \(R^*–T_3\): five surviving labellings all fail

Let the tree's centre port be \(c\), and write its two end-port groups as \(U,V\), each of size two. A single tree perfect matching has singleton boundary only at an end port, never at \(c\). Its possible missing-pair states are exactly the four edges of \(K_{U,V}\); all four occur in Tait colourings, so every pair or loop type on these four states occurs in an actual tree BF row.

The two disjoint pairs of states in \(K_{U,V}\) are its opposite edges. By Note 164, each opposite pair must have the **same** \(P/Q\) colour; otherwise the shared BF type gives a forbidden four-cycle of terminal loops. Explicitly, for \(U=\{a,b\},V=\{d,e\}\), the two tests are \(c(ad)=c(be)\) and \(c(ae)=c(bd)\), where \(c\) is membership in \(P\). Applying these two equalities to the three two-plus-two partitions of \([5]-\{c\}\) for each centre \(c\) leaves exactly the five arrangements below (interchanging \(U,V\) changes nothing). The rejected arrangements are \(24\mid35,25\mid34\) at centre \(1\); \(12\mid45,14\mid25,15\mid24\) at centre \(3\); \(12\mid35,13\mid25,15\mid23\) at centre \(4\); and \(12\mid34,13\mid24\) at centre \(5\).

| centre \(c\) | \(U\mid V\) | four state colours | contradiction |
|---|---|---|---|
| \(1\) | \(23\mid45\) | alternating | four loops incident with \(1\) |
| \(2\) | \(13\mid45\) | alternating | triangle \([12],[23],[13]\) |
| \(2\) | \(14\mid35\) | alternating | triangle \([23],[25],[35]\) |
| \(2\) | \(15\mid34\) | all \(P\) | \([12],[25]\) occur but \([34]\) cannot |
| \(5\) | \(14\mid23\) | alternating | four loops incident with \(5\) |

Here is a direct check of the last column. For a tree end port \(w\), its two incident tree states are \(wy,wz\), where \(\{y,z\}\) is the opposite end group. If the \(R^*\) states \(cy,cz\) have different \(P/Q\) colours, the rectangle rule produces \([cw]\). In the \(c=1\) and \(c=5\) rows this holds for **both** end groups, giving all four loops incident with the centre. No five-cycle of allowed Case-XII loops has a vertex of degree four. In the first alternating \(c=2\) row it gives \([12],[23]\); the common shore type \((14)(34)\) gives \([13]\) by the common-overlapping-type rule. In the second it gives \([23],[25]\); the common type \((13)(15)\) gives \([35]\). Neither triangle lies in a five-cycle.

In the all-\(P\) row, \(c=2,\ U=\{1,5\},\ V=\{3,4\}\). The rectangle rule gives \([12]\) and \([25]\) because \(23\in Q\) and \(24\in P\). Suppose the terminal composition also had loop \([34]\). Its four singleton output slots would all have boundary \(3\) or \(4\). In the participating \(R^*\) type \((p)(q)\), with \(p\in P,q\in Q\), each of its two triple slots would therefore have to pair with a tree singleton at the *other* member of its missing pair. The tree has no singleton at \(2\). Consequently \(q=34\): the only other \(Q\) state meeting \(\{3,4\}\) is \(23\), which would require tree singleton \(2\). Likewise \(p\) is one of \(13,14,35,45\); \(24\) would again require singleton \(2\). Thus the four \(R^*\) singleton slots have only **one** boundary occurrence in \(U=\{1,5\}\). But the tree's two triple slots each miss one label in \(U\) and one in \(V\). To make both corresponding terminal singleton slots have boundary \(3\) or \(4\), each must pair with an \(R^*\) singleton in \(U\). Two such occurrences are needed, a contradiction. Hence \([34]\) is absent from the complete composed support. A five-cycle containing both \([12]\) and \([25]\) must connect \(1\) to \(5\) through \(3,4\) by either \(1-3-4-5\) or \(1-4-3-5\); both use \([34]\). Exact Case XII is impossible in the last row too.

Thus \(R^*–T_3\) cannot produce exact Case XII. Together with Notes 163–164, all shore-type possibilities for the marked five-cut are excluded. Combining with the four-crossing belt exclusion of Note 162 and the disconnected-core classification of Note 161 yields the conditional structural conclusion
\[
\boxed{\text{minimum-host exact Case XII}\quad\Longrightarrow\quad F=J-M\text{ is connected}.} \tag{2}
\]
The condition “minimum-host” enters through the earlier cut classification and Proposition 4.4. For the connected \(F\) left by (2), the exact remaining dichotomy from Note 157 and Note 161 is: either \(F\) has a perfect matching (hence the pole has an all-terminal *perfect matching*, which need not extend to a BF row), or its matching deficiency is two and every maximum Tutte barrier is nonempty. Neither branch is excluded here. In particular, (2) does not prove a common \(B_2+C_4\) seed or settle the Berge–Fulkerson conjecture.
