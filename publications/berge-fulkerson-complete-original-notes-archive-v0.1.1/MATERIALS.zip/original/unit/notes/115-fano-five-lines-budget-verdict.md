> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 115 — F5 run-to-verdict 终态报告（2026-09-13）

**终态：BUDGET。** 已完成五个脉冲；F5 未证明、未证伪。全程停留 R1，其允许重新着色的 GO/NOGO 判据均未获得，因此没有切换 R2 或 R3。冻结 SPEC 未修改。

改变的数学判断：

- “五线集合单轨道足以拼接给定着色”被真实十顶点图排除；相应二和、非平凡三和的给定着色在边界对齐后最少均需六线，但拼接图自身都有一线着色。关闭的仅是自同构独力完成的子机制。
- 一侧可三边着色时，二和、三和确实保持 F5（Note 113）。一般两侧 F5 保持性仍开放。
- 一般拼接的完整重着色问题精确变成真实极的支持相交：两极三位、三极九位（Note 114）。三极的封口线可能不在内部五线调色板中，不能把九位缩成闭图星的六位。

最薄弱一步：真实图的全部着色究竟能实现哪些支持掩码，仍未控制。独立有限校验已覆盖几何群作用、真实图证书及一线接口，但不承担全阶可实现性论证。

剩余边界：没有一般 R1 拼接定理，没有任何线数最小值为六的图，没有进入 F6 证明的第六线消去步骤；没有运行 n≤36 的新普查。原 probe 的 31,646 个输入图结论未扩展，本次只读取其代码、报告与既有证据，未重跑全表。循环四边连通三正则图的非平凡三边割本来就不存在：若三边割一侧无环，三价度数求和 3v=2(v−1)+3 得 v=1；因此在该类图上检查非平凡三割不能检验一般拼接保持性。本轮不把这种空范围当作 R1 的 GO。

下一批候选（继续 R1，不擅自扩阶）：

1. 对指定割开边的真实两极，计算完整三位支持；判定两个 F5 闭因子是否可能给出不相交支持。若能独立验证这样的实际对，才达到二和方向的 R1 NOGO。
2. 对指定删点的真实三极，计算完整九位支持及所有六种实际端口配对；特别记录三个“封口线不在 S 中”的轨道是否修复六位支持中的空交。
3. 从同一图全着色之间的明确重着色操作出发，证明至少一个公共轨道必出现；需要真实着色族的论证，不能再用单着色自同构替代。

证据索引：Notes 110–114；`computations/fano-r1-20260913/`。每项永久数学结论均先经独立实现校验。未做 novelty 检索；以上结果不主张新颖性。没有评等级、投稿、进入匹配六元组 ILP 或 F4 路线。

工作区原无 Git 仓库，故在 `units/berge-fulkerson/` 初始化局部仓库；只跟踪本任务的 LOG、Notes 110–115 和本轮计算证据。历史文件及冻结 SPEC 保持未跟踪且未修改。
