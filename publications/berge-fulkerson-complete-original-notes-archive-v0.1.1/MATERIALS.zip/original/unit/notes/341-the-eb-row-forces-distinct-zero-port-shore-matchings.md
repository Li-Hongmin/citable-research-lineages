> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(ea\)--\(eb\) row forces distinct zero-port shore matchings

Use the central-path exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with six shore ports
\[
E=e,\qquad A=a:\Sigma,\qquad I=h_1,\quad D=h_2,\quad H=h_3,\quad J=h_4,
\]
allowed pentagon \(S=e-a-b-d-c-e\), and complete exact-Case-XII perfect-matching support. The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual \((ea)(eb)\) row
\[
R=X_{ea}+Y_a+Z_e+U_{eb}+V_e+W_b=2\mathbf1.             \tag{1}
\]
By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), both triple occurrences restrict to zero-port perfect matchings on the entire six-port shore.

**Theorem.** Every row (1) has
\[
                         X_\Sigma\ne U_\Sigma.           \tag{2}
\]
In particular, the shore has at least two zero-port perfect matchings, and their symmetric difference contains a nonempty shore-internal alternating cycle. The statement holds for arbitrary shore order and cycle rank in the stated central-path profile.

**Proof.** Suppose \(X_\Sigma=U_\Sigma=Q\). Both occurrences of \(Q\) saturate its edges. In \(\Gamma=E(\Sigma)\setminus Q\), including the six port semiedges, every edge consequently has a two-slot label from \(\{Y,Z,V,W\}\). At each internal vertex the labels of its two incident \(\Gamma\)-edges are complementary. The components of \(\Gamma\) are three port paths and some closed cycles; every closed cycle is even because the actual row supplies alternating complementary labels. Write \(\sigma(Q)\) for the pairing of the six ports by those paths.

The zero-port state-\(eb\) triple has two genuine exterior masks, \(U_A,U_D\), displayed in [Note 340, (3)](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md). By Note 230's Cartesian factorization, **both** masks glue to this same actual shore matching \(Q\), regardless of which occurs in (1). In the complements of the glued triples, their exterior portions have the following connections:
\[
\begin{array}{c|c|c}
 &\text{port-to-port paths}&\text{terminal arms}\\\hline
U_A&ID\ (8\text{ edges}),\quad AH\ (4\text{ edges})&e\to E,\quad b\to J\\
U_D&AD\ (4\text{ edges}),\quad HJ\ (4\text{ edges})&e\to E,\quad b\to I.
\end{array}                                                   \tag{3}
\]
Lengths include the two port semiedges. For example, the \(U_A\) path \(ID\) uses \(h_1,1A,c:A,c:E,d:E,d:B,2B,h_2\); the other three port paths use respectively \((a:\Sigma,a:C,3C,h_3)\), \((a:\Sigma,a:C,2C,h_2)\), and \((h_3,3D,4D,h_4)\). Thus all four exterior port paths have even length, and there are no exterior closed components. Gluing the two semiedges at each port into one edge changes a closed walk's length by an even number, so the displayed path parities are the full-cycle parities.

If one of the two full state-\(eb\) triple complements had only even closed cycles, [Note 125's triple-complement parity lemma](125-no-single-edge-bipartization-in-exact-case-xii.md) would produce a genuine \(eb\)-Tait colouring. Doubling that colouring gives the forbidden exact-Case-XII loop \([eb]\). The closed shore cycles are already even, so **each** exterior mask in (3) must close at least one odd cycle through the shore ports. For \(U_A\), a closed port cycle is possible only if \(\sigma(Q)\) contains \(ID\), \(AH\), or \(EJ\); for \(U_D\), only if it contains \(AD\), \(HJ\), or \(EI\). Intersecting these two conditions over the fifteen pairings of six ports leaves precisely
\[
\sigma(Q)\in\{EA\mid ID\mid HJ,\quad EI\mid AH\mid DJ,
                    \quad EJ\mid AD\mid IH\}.             \tag{4}
\]
Indeed, sorting the fifteen pairings by the partner of \(E\), the two cycle tests leave respectively \(EA\mid ID\mid HJ\), \(EI\mid AH\mid DJ\), none, none, and \(EJ\mid AD\mid IH\) for partners \(A,I,D,H,J\). This is only a necessary topological test; the cycles must still be odd.
This is also a gate for the *entire* zero-port matching family: any zero-port shore matching whose complement has no odd closed component must have one of the three pairings in (4). No BF row is needed for this implication; the forbidden \([eb]\) loop and the two complete exterior matching masks suffice.

For a shore port \(p\), let \(L_p\) be its two singleton-slot labels. In particular \(L_E=ZV\). By Note 230's quota, \(Y,W\) each use two proper shore ports, while \(Z,V\) each use three. The complementary-label rule says that paired ports have **equal** labels if their shore path has odd length and **complementary** labels if it has even length. The pure state-\(ea\) half of (1) uses \(Y_L\), with proper ports \(HJ\), or \(Y_R\), with proper ports \(ID\). Exchanging the complete \(Z_e,V_e\) occurrences leaves the forbidden opposite state \(eb\) and the row load unchanged, so both \(Z\) and \(V\) must pass the corresponding pure-side route test of Note 271's sixteen-mask table. Reading that table gives three facts:

1. Neither pure-left singleton-\(e\) mask uses both \(H,J\); neither pure-right one uses both \(I,D\).
2. A pure-left mask using \(A,D\) but not \(J\) has proper port set \(AID\).
3. A pure-right mask using \(A,H\) but not \(I\) has proper port set \(AHJ\).

Also, [Note 340's sharper port gate](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md) applies to (1) and to the row after exchanging \(Z,V\): since the triples share \(Q\), neither pure half can be unit at all five proper shore ports. Equivalently, each of \(Z,V\) uses at least one of \(Y\)'s two proper ports.

Now exclude the three pairings in (4).

- For \(EA\mid ID\mid HJ\), the two \(Y\)-ports are paired with each other, whether \(Y=Y_L\) or \(Y_R\). Both labels contain \(Y\), so they cannot be complementary and must be equal. Fact 1 rules out \(Z\) or \(V\) as their common second slot; therefore \(W\) uses both ports and \(Z\) avoids both. The pure half then has unit load at all shore ports, contrary to Note 340.

- For \(EI\mid AH\mid DJ\), first take \(Y=Y_L\). The \(A,H\) labels differ in whether they contain \(Y\), so their shore path is even. It closes with the even exterior \(U_A\) path \(AH\); this is the only closed port component of that triple complement. All its other closed components are even shore cycles, giving the forbidden \(eb\)-Tait colouring. Now take \(Y=Y_R\). Pairing \(E,I\) forces \(L_I=YW\), so \(W\) uses \(I\), while \(Z,V\) avoid \(I\). The only closed port component for \(U_A\) is again \(AH\), and it must be odd. Hence \(L_A=L_H\). Since \(W\) uses only two proper ports, it cannot occur at both \(A,H\) as well as \(I\). Thus \(L_A=L_H=ZV\); in particular \(Z\) uses \(A,H\) and avoids \(I\). Fact 3 gives \(Z\)'s proper ports \(AHJ\), disjoint from \(Y_R\)'s \(ID\), contrary to Note 340.

- For \(EJ\mid AD\mid IH\), take \(Y=Y_R\) first. The \(A,D\) labels differ in whether they contain \(Y\), so their path is even. It is the only closed port component under \(U_D\), whose exterior \(AD\) path is even; the forbidden \(eb\)-Tait colouring follows. If \(Y=Y_L\), pairing \(E,J\) forces \(L_J=YW\), so \(W\) uses \(J\) and \(Z,V\) avoid \(J\). To keep the \(U_D\) cycle \(AD\) odd, \(L_A=L_D\). That equal label cannot contain \(W\), which would then have to use \(A,D,J\); hence \(L_A=L_D=ZV\). Fact 2 gives \(Z\)'s proper ports \(AID\), disjoint from \(Y_L\)'s \(HJ\), again contrary to Note 340.

All possible \(\sigma(Q)\) are excluded, proving (2). Since two zero-port matchings on the same shore differ by a nonempty union of even alternating cycles, the final assertion follows. \(\square\)

**All-even zero-port complement consequence.** More generally, let \(Q\) be *any* zero-port shore perfect matching whose complement has only even closed components. Then \(Q\) extends to a genuine \(ea\)-Tait colouring of the entire five-pole. Indeed, its port pairing lies in (4). Glue \(Q\) to the zero-port state-\(ea\) exterior mask \(X_a\) of Note 271, (3). Its complement has the exterior paths \(IJ\) and \(DH\) of [Note 339, (3)](339-the-genuine-right-row-forces-an-internal-pure-load-circulation.md), both of even length, and terminal arms at \(E,A\). For \(EI\mid AH\mid DJ\) and \(EJ\mid AD\mid IH\), all six ports lie on the \(e\)--\(a\) terminal path, so every closed component is an even shore cycle. For \(EA\mid ID\mid HJ\), the \(U_A\) complement has only the closed port cycle \(ID\), while the \(U_D\) complement has only \(HJ\). The forbidden \([eb]\) loop forces both shore paths \(ID,HJ\) to be odd. Under \(X_a\), these paths and the even exterior \(IJ,DH\) paths form one closed cycle of even length. The remaining closed components are even shore cycles. Note 125's complement lemma therefore gives the asserted \(ea\)-Tait colouring. In particular, if a central-path exact-Case-XII pole has no Tait colouring, **every** zero-port shore matching has an odd closed component in its shore complement.

This uses full matching closure twice: to glue both forbidden-state exterior triples to the *same* \(Q\), and to exchange the complete singleton-\(e\) occurrences. It closes Note 340's nonunit-port alternative for the required \((ea)(eb)\) cell. Distinct zero-port shore matchings can still occupy that cell, and their interaction with the genuine left \((ea)(ac)\) and right \((ea)(ad)\) rows is unresolved; neither the central-path profile nor Berge–Fulkerson is excluded. The port-route inputs are the hand-derived tables of Notes 271 and 340 and still warrant independent second-source proof review.

[Note 342](342-the-eb-row-creates-two-exterior-pure-load-fibres.md) derives two distinct pure-half exterior fibres and a conditional cross-row load lower bound from the different zero-port shore matchings.
