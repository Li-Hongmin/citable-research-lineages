> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-cycle Tait transitions are companion external linkages

This note supplies the endpoint-routing datum left open by
[Note 039](039-double-role-cycle-rounding-needs-endpoint-routing.md).
It gives an exact normal form for a boundary-preserving change of one
third matching.  The result is a structural reduction, not a proof of
radius-one capacity rounding.

## Companion-route identity

Let

\[
(P,R,Q),\qquad(P',R',Q')
\]

be two Tait triples of the same cubic graph or pole.  Assume \(P,P'\)
have the same singleton boundary and \(R,R'\) have the same singleton
boundary.  Put

\[
C=Q\mathbin\triangle Q',\qquad
D_P=P\mathbin\triangle P',\qquad
D_R=R\mathbin\triangle R'.
\]

Because both triples partition the full edge set,

\[
P\mathbin\triangle R\mathbin\triangle Q
=P'\mathbin\triangle R'\mathbin\triangle Q'=E.
\]

Consequently

\[
\boxed{D_P\mathbin\triangle D_R=C.} \tag{1}
\]

Both \(D_P,D_R\) are internal even subgraphs.  Equation (1) gives the
edgewise identities

\[
D_P\setminus C=D_R\setminus C=:Z, \tag{2}
\]

and

\[
(D_P\cap C)\mathbin{\dot\cup}(D_R\cap C)=C. \tag{3}
\]

Thus the nonlocal part of a one-role endpoint exchange occurs identically
in the companion role.

## Single-cycle normal form

Assume \(C\) is one internal cycle.  At a vertex outside \(C\), \(Z\)
has degree zero or two.  At a vertex of \(C\), cubicity gives
\(\deg_Z\in\{0,1\}\).  Hence \(Z\) is a vertex-disjoint union of internal
cycles and paths whose distinct endpoints lie on \(C\).

Every cycle component \(W\) of \(Z\) is an ordinary internal Kempe cycle.
Indeed, outside \(C\) one has \(Q=Q'\), and (2) says that the old and new
endpoint colours are exchanged on every edge of \(W\).  Replacing

\[
(P',R')\longmapsto
(P'\mathbin\triangle W,R'\mathbin\triangle W)
\]

keeps \(Q'\), all boundary data and the Tait partition fixed, while
removing \(W\) from both \(D_P,D_R\).  Repeating gives a normalized
representative in which \(Z\) consists only of vertex-disjoint paths
pairing vertices of \(C\).

At a nonendpoint of \(Z\), one of \(D_P,D_R\) uses both incident
\(C\)-edges and the other uses neither.  At an endpoint of \(Z\), each
uses one incident \(C\)-edge.  Therefore the \(C\)-edge assignment
switches exactly at the endpoints of \(Z\).  Given the path linkage
\(Z\), there are precisely two complementary algebraic phase assignments
on \(C\).  The given labelled transition realizes one of these two
assignments; the boundary data alone need not determine which one, and
the complementary assignment need not be realizable for the fixed old
triple.

Thus every normalized one-cycle transition is encoded by

1. a vertex-disjoint external linkage \(Z\) between an even subset of
   vertices of \(C\); and
2. one binary phase on \(C\).

This is the exact endpoint-routing datum missing from a description that
records only \(C\) and its local defect exits.

## The first one-role repair from Note 039

For the displayed order-seventeen repair,

\[
\begin{aligned}
C&=\{e_7,e_8,e_9,e_{11},e_{12},e_{15}\},\\
D_P&=\{e_2,e_3,e_8,e_{11},e_{12},e_{15}\}.
\end{aligned}
\]

Equation (1) forces

\[
D_R=C\mathbin\triangle D_P
=\{e_2,e_3,e_7,e_9\}.
\]

With the stored proper-edge ordering,

\[
e_2=1\,5,\qquad e_3=1\,7,
\]

so the common external route is the path

\[
Z=5-1-7
\]

joining two vertices of the third-matching cycle

\[
C=5-6-7-8-9-15-5.
\]

The selected role uses the complementary \(C\)-arc
\(5-15-9-8-7\), giving its six-cycle \(D_P\); the companion role uses
the arc \(5-6-7\), giving its four-cycle \(D_R\).

## Consequence and boundary

The identity does not by itself prove radius-one capacity rounding.
The signed multiplicity update still depends on which endpoint route is
selected and on the old multiplicities along its alternating halves.
What it proves is that the extra data in Note 039 is a constrained
external linkage, not an arbitrary perfect-matching symmetric difference.

A positive radius-one theorem may therefore be reduced to an
endpoint-linkage selection problem: choose a realizable normalized \(Z\)
and a compatible realizable phase so that the signed multiplicity
conditions of Note 039(4)--(5) hold.  Any approach recording only \(C\)
and local exits, but not this linkage, remains incomplete.
