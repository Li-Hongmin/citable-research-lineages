> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A pentagon--R-star two-five-cut requires adjacent special ports

In [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) minimum-host \(|U|=1\) two-five-cut profile, let \(A^\circ\) be an ordinary pentagon shore and \(B^\circ\) a published Case-XIII \(R^*\) shore. If the outer pole has exact Case-XII BF support with forbidden missing-pair pentagon \(T\), then
\[
\boxed{\delta\epsilon\in T.}                                      \tag{1}
\]
The assertion is a necessary port-placement restriction, not an existence claim for the adjacent case. The proof uses actual complete shore BF types and the connector gate; it never infers an outer row from selected matchings.

The five Tait missing-pair states of \(A^\circ\) are the five edges of a cycle on its local ports \(\{0,\delta,\alpha,\beta,\gamma\}\). Delete \(0\) from that state cycle. The remaining four ports form a path; its two end edges are disjoint. Rename the three shared ports so that those end edges are \(\delta y\) and \(xz\). Both loops \([\delta y],[xz]\) are actual doubled Tait rows, and \((\delta y)(xz)\) is an actual pentagon BF type, as in [Note 164](164-disjoint-shore-pairs-exclude-a-pentagon-rstar-five-cut.md). The latter also follows directly: the four singleton matchings at \(\delta,y,x,z\), together with the two triple matchings missing \(\delta y,xz\), load every cycle edge and port twice. Equivalently, their six boundary subsets can be ordered as
\[
(0xz,\ 0\delta y,\ \delta,\ x,\ y,\ z).                \tag{2}
\]
The doubled loop rows have boundary subsets \((0xz,0xz,\delta,\delta,y,y)\) and \((0y\delta,0y\delta,z,z,x,x)\), respectively. Therefore **all nine genuine six-slot transports** in [Note 188](188-the-tree-rstar-two-five-cut-profile-is-impossible.md) apply to this pentagon shore as well: those tables use only these three boundary types, not the internal shape of the tree. For the \(R^*\) shore write \(c(p)\in\{P,Q\}\) for the Figure-7 block of a local missing-pair state. A forbidden outer \(T\)--\(T\) output from an input \((p)(q)\) forces \(c(p)=c(q)\).

If \(\delta\epsilon\notin T\), its unique short path has midpoint among \(x,y,z\). Interchanging \(x,z\) preserves all three actual \(A^\circ\) BF types just displayed. The placements in [Note 188](188-the-tree-rstar-two-five-cut-profile-is-impossible.md) with
\[
\delta-x-\epsilon-z-y-\delta,\quad
\delta-y-\epsilon-z-x-\delta,\quad
\delta-y-\epsilon-x-z-\delta
\]
are excluded verbatim by its explicit rows. Their images under \(x\leftrightarrow z\) cover the corresponding midpoint-\(z\) placements. It remains to consider the other ordering with midpoint \(x\):
\[
\boxed{T=\delta-x-\epsilon-y-z-\delta.}               \tag{3}
\]

For (3), [Note 184's](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) actual \(xz\)-loop transport \((xy)(0x)\mapsto(yz)(z\delta)\) has forbidden output, giving \(c(xy)=c(x0)\). The first two rows of Note 188's doubled-\(\delta y\) table send \((x\epsilon)(yz)\) and \((z\epsilon)(xy)\) to \((\delta x)(yz)\), also forbidden under (3). Hence
\[
c(x\epsilon)=c(yz),\qquad c(z\epsilon)=c(xy)=c(x0).    \tag{4}
\]
Two more actual rows use the same doubled-\(\delta y\) shore row. The notation \(0yz\) means boundary \(\{0,y,z\}\), and a two-digit slot label denotes a two-set.

| supported \(B^\circ\) input | \(B^\circ\) boundaries in slots \(1,\ldots,6\) | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((x\epsilon)(y\epsilon)\) | \(y,\epsilon,x,0yz,\epsilon,0xz\) | \(46;25\) | \(12;46\) | \(3:\delta x,\ 5:y\epsilon\) |
| \((z\epsilon)(y\epsilon)\) | \(y,\epsilon,z,0xy,\epsilon,0xz\) | \(46;25\) | \(12;46\) | \(3:\delta z,\ 5:y\epsilon\) |

In both lines, \(X_0=\{1,2\}\), \(X_\delta=\{3,4\}\), and \(R=\{3,5\}\). All four common port labels are disjoint across the shores, \(X_\delta\cap Y_\epsilon=\varnothing\), and the displayed \(D\)-labels satisfy [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) full gate. Slot \(3\) uses the \(\delta\)-half and the displayed \(B^\circ\) singleton; slot \(5\) uses the \(y\)-half and the \(\epsilon\)-half. Formula (3) of Note 172 gives the two listed outer triples; the other four slots are singleton boundaries. Since \(\delta x,\delta z,y\epsilon\in T\) in (3), exact Case XII forces
\[
c(x\epsilon)=c(y\epsilon)=c(z\epsilon).                \tag{5}
\]
Equations (4)--(5) put \(xy,x0,x\epsilon,yz,y\epsilon,z\epsilon\) in one \(R^*\) block. It would have three edges incident with \(x\), namely \(xy,x0,x\epsilon\), and three incident with the distinct port \(\epsilon\), namely \(x\epsilon,y\epsilon,z\epsilon\). But the Figure-7 block \(P=\{13,14,24,35,45\}\) has only vertex \(4\) of degree three, and \(Q=\{12,15,23,25,34\}\) has only vertex \(2\) of degree three. This contradiction proves (1). \(\square\)

This theorem alone does not exclude adjacent-\(\delta\epsilon\) pentagon--\(R^*\) placements, \(L^*\)--\(R^*\), \(R^*\)--\(R^*\), or the other Tutte-barrier profiles. Unlike the disjoint-shore pentagon--\(R^*\) exclusion in Note 164, the result here concerns the connector with one vertex \(u\), one vertex \(w\), and three marked edges between the shores.

[Note 190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) subsequently excludes the adjacent-\(\delta\epsilon\) placements by further actual connector rows, closing pentagon--\(R^*\) in this profile.
