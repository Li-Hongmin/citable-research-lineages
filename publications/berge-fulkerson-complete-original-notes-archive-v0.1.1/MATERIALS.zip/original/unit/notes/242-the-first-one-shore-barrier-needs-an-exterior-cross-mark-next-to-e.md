> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first one-shore barrier needs an exterior cross-mark next to \(e\)

Work in the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md), with a minimum-cardinality maximum Tutte barrier \(|U|=3\). [Note 236](236-girth-five-leaves-four-marked-exterior-quotients-at-the-first-barrier.md) leaves four marked exterior quotients. [Notes 235](235-the-claw-connector-excludes-the-two-endpoint-e-neighbours.md) and [238](238-the-two-path-quotients-exclude-their-shore-mark-pair-at-e.md) already exclude the two \(W\)--\(C\) marks as the two allowed neighbours of the internal mark \(e\) in the three tree quotients. [Note 237](237-the-cycle-leaf-connector-excludes-the-two-cycle-shore-e-neighbours.md) excludes the pair \(\{c,d\}\) of cycle-side \(W\)--\(C\) marks in the remaining cycle--leaf quotient. We close its remaining pair \(\{a,c\}\), and by reflection \(\{a,d\}\), without restricting the odd shore's order or cycle rank.

Use [Note 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md)'s notation for the cycle--leaf quotient:
\[
K: p-u_1-x-u_2-q-u_3-z-u_1,
\qquad h_2=u_2C,\quad h_3=u_3C,
\]
where the displayed walk contains the six-cycle on \(u_1,x,u_2,q,u_3,z\) plus the pendant edge \(pu_1\). The marks are \(a:p-C\), \(b:p-q\), \(c:x-C\), \(d:z-C\), and \(e\subset C\). Put \(\alpha=\{u_1x,u_2q,u_3z\}\) and \(\beta=\{u_1z,u_2x,u_3q\}\).

**Theorem.** Complete exact Case-XII support is impossible if \(e\)'s two neighbours in the allowed missing-pair pentagon are \(a,c\) or \(a,d\). Both cyclic orders of the other two marks are excluded. Consequently, in **every** \(|U|=3\) marked exterior quotient of Note 236, at least one allowed neighbour of \(e\) must be a mark joining two singleton exterior vertices \(W\). This is a necessary boundary, not a realization of the remaining placements.

## A port-stability obstruction

First fix any pure-\(S\) half-load \(D=X_\alpha+Y_a+R_e\) at state \(ea\), with \(ea,ec\in S\), and suppose its singleton-\(e\) matching \(R_e\) uses the three proper shore ports \(a:C,c:C,d:C\) and selects \(b:p\). The exterior routes of \(X_\alpha\triangle R_e\) from terminals \(b,c,d\) reach \(a:C,c:C,d:C\), respectively: the first route is \(b-t_b-p-t_a-a:C\), and the other two are direct. This does not depend on which matching of \(K-p\) is used by \(R_e\).

By [Note 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md), \(X_\alpha\triangle Y_a\) has a wholly exterior \(a\)--\(c\) path. Switch it, obtaining a state-\(ec\) triple \(X_c\) with **the same complete shore mask** as \(X_\alpha\). Thus the pairing of the shore \(e\)-port against \(R_e\) is unchanged. If \(S=e-a-b-d-c-e\), purity at \(ea\) requires the \(e\)-path to end at \(b\), hence to use shore port \(a:C\). But in \(X_c\triangle R_e\), terminal \(a\) reaches \(a:C\) directly; switching its \(e\)--\(a\) path gives \(ac\in T\). If \(S=e-a-d-b-c-e\), purity requires the \(e\)-path to end at \(d\), hence to use \(d:C\). Terminal \(d\) still reaches \(d:C\) directly in \(X_c\triangle R_e\); switching gives \(cd\in T\). In either order this contradicts purity. We will refer to this as the **three-shore-port obstruction**:
\[
\boxed{D\text{ pure }S\quad\Longrightarrow\quad
R_e\text{ cannot use }a:C,c:C,d:C\text{ together with }b:p.}  \tag{1}
\]

## The two phases of the opposite triple

Take the required actual \([ea]\) BF loop. Exact negative support makes at least one half pure \(S\); write it
\[
D=X_\alpha+Y_F+Z,
\qquad E=U+V+W,
\qquad D+E=2\mathbf1,                                  \tag{2}
\]
where \(X,U\) are the two state-\(ea\) triples, \(Y_F,V\) are singleton-\(a\), and \(Z,W\) are singleton-\(e\). [Notes 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md) and [241](241-the-pendant-loop-cannot-use-the-doubled-singleton-phase.md) force \(X\)'s exterior phase \(\alpha\) and \(Y\)'s type \(F\).

Suppose first that \(U\) uses \(\beta\). Exchange the entire exterior six-cycle between \(X_\alpha\) and \(U_\beta\), retaining their shore masks and the other four matching occurrences. The new half with triple \(X_\beta\) is mixed by Note 239, so its complementary half is pure \(S\). Note 241 forces its singleton-\(a\) \(V\) to have type \(F\). In the original row, the two type-\(F\) singletons load \(h_2,h_3,b:q\) twice. Both triples load \(a:p\) twice. Therefore \(Z,W\) avoid \(h_2,h_3,b:q,a:p\), and each uses exactly three proper shore ports by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). The only available proper shore ports are \(a:C,c:C,d:C\); both singleton-\(e\) matchings use all three and select \(b:p\). In particular \(Z\) violates (1), a contradiction. Hence
\[
\boxed{U\text{ also uses }\alpha.}                         \tag{3}
\]

Now both triples load \(u_1x,u_2q,u_3z\) twice, as well as \(a:p\). Thus \(V,Z,W\) avoid those four edges, while \(Z,W\) both use \(a:C\). The singleton \(V\) cannot have type \(G\), which uses \(u_3z\). It cannot have type \(F\) either: if it did, \(Y_F,V_F\) would again saturate \(h_2,h_3,b:q\), forcing \(Z\) to violate (1). Therefore \(V\) is **neither** \(F\) nor \(G\). By Note 239 it follows that the half \(U_\alpha+V+R\) is mixed for *either* choice \(R\in\{Z,W\}\). Exchanging the complete singleton-\(e\) occurrences between the two halves of (2) gives a second actual BF row. Exact negative support forces **both** \(X_\alpha+Y_F+Z\) and \(X_\alpha+Y_F+W\) to be pure \(S\).

Each of \(Z,W\) must use at least one of \(h_2,h_3\). Otherwise its three proper shore ports are \(a:C,c:C,d:C\). With no \(h_i\) hit, selecting \(b:q\) would require the unique \(K-q\) matching, which contains \(u_3z\), already loaded twice by the triples. It must therefore select \(b:p\), violating (1) in the pure half containing it. The two available extra uses of \(h_2,h_3\), one of each after \(Y_F\), are consequently taken one apiece by \(Z,W\); \(V\) uses neither. Since a singleton-\(a\) matching has exactly two proper shore hits and does not use \(a:C\), \(V\)'s hits are precisely \(c:C,d:C\).

Exactly one of \(Z,W\) must now use \(d:C\), because \(V\) uses it once and \(Y_F\) instead uses \(d:z\). Call this singleton-\(e\) matching \(R\). It also uses \(a:C\) and exactly one of \(h_2,h_3\), so its third cut port is fixed. If \(R\) used \(h_3\), then it would select \(c:x\), have \(u_3\) occupied by \(h_3\), and leave \(u_2\) unmatched: \(u_2x\) meets the already occupied \(x\), \(u_2q\) is loaded twice by the triples, and \(h_2\) is absent from \(R\). Hence \(R\) uses \(h_2\), selects \(c:x\), matches \(u_3q\) and \(u_1z\), and must select \(b:p\) to cover \(p\). Its complete exterior restriction is
\[
R:\quad a:C,\ d:C,\ h_2,\ c:x,\ b:p,\ u_1z,\ u_3q.       \tag{4}
\]
Here \(R\) does **not** use \(c:C\), so (1) as stated does not apply directly. Nevertheless its \(b\)-route against \(X_\alpha\) still reaches \(a:C\), and its \(d\)-route still reaches \(d:C\), exactly the only two routes used in the proof of (1). Repeating that two-switch argument gives \(ac\in T\) for \(S=e-a-b-d-c-e\) or \(cd\in T\) for \(S=e-a-d-b-c-e\), contradicting purity of the half containing \(R\). This excludes \(\{a,c\}\). Reflecting the exterior excludes \(\{a,d\}\); with Note 237, no pair of the three \(W\)--\(C\) marks survives in the cycle--leaf quotient. Notes 235 and 238 provide the corresponding tree-quotient exclusion, proving the theorem. \(\square\)

The decisive use of complete perfect-matching closure is the exchange of the two *whole* singleton-\(e\) occurrences between complementary halves. It upgrades a restriction on one chosen pure half to a restriction on both actual singleton identities and forces the cut-port count. A formal shore signature, selected-matching subfamily, or quotient classification alone does not supply this step. The full exact Case XII and Berge--Fulkerson conjecture remain open for placements where \(e\) neighbours an exterior \(W\)--\(W\) mark and for the other profiles of Note 169. This analytic chain still lacks independent verification of its upstream claims.
