> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A smallest maximum Tutte barrier has three odd-shore profiles

Assume the connected marked-core, minimum-host, full exact-Case-XII setting of [Note 166](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md). Suppose \(F=J-M\) has no perfect matching, so its deficiency is two. [Note 168](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md) gives \(h(U)\le1\) for every maximum Tutte barrier, and Note 166 excludes an even component of \(F-U\). Choose a maximum barrier \(U\) with **minimum cardinality**. This note normalizes that barrier and spends the remaining cut budget; it does not exclude the deficiency-two branch.

## Stripping the barrier

\[
\boxed{h(U)=0,\qquad F[U]\text{ is edgeless},\qquad
\text{every }u\in U\text{ meets three distinct odd components of }F-U.} \tag{1}
\]

**Proof.** First suppose \(h(U)=1\). Note 168 leaves only Note 166's \(E=2,a=b=0\) shape. In particular \(F[U]\) is edgeless, and the unique marked vertex \(u\in U\) has exactly two \(F\)-neighbours. Remove \(u\) from \(U\). If its neighbours lie in the same odd component, adding \(u\) turns that component even; the number of odd components drops by one, so \(U-\{u\}\) is a smaller maximum barrier **with an even component**, contrary to Note 166. If its neighbours lie in distinct odd components, adding \(u\) merges them into one odd component; the number of odd components again drops by one, making \(U-\{u\}\) a smaller maximum barrier. Thus \(h(U)=0\).

Now every vertex of \(U\) has degree three in \(F\). If \(u\in U\) has three neighbours inside \(U\), removing \(u\) makes it an additional isolated odd component, increasing the deficiency from two to four, impossible. If it has two neighbours inside \(U\), its remaining neighbour lies in an odd component, and removing \(u\) turns that component even while preserving deficiency two, again impossible. If it has one neighbour inside \(U\), its other two neighbours either lie in the same odd component, giving a forbidden even component after removing \(u\), or lie in distinct odd components, giving a smaller maximum barrier. Therefore \(F[U]\) has no edge.

Finally, all three \(F\)-neighbours of a vertex \(u\in U\) lie outside \(U\). If they lie in one odd component, removing \(u\) creates a forbidden even component. If they lie in exactly two odd components, removing \(u\) merges those two into one odd component and leaves a smaller maximum barrier. Hence the three neighbours lie in distinct odd components. \(\square\)

The argument uses only the effect of moving one vertex from \(U\) into \(F-U\): for a deficiency-two barrier with \(q=|U|+2\), the new set is again maximum exactly when the number of odd components drops by one. This avoids assuming any matching identity across BF rows.

## Three remaining cut-budget profiles

All components of \(F-U\) are odd. Since \(h(U)=0\) and \(F[U]\) is edgeless, Note 166's identity becomes
\[
E+b=4,\qquad
E=\sum_C(|\delta_J(C)|-3).                         \tag{2}
\]
Let \(m\) be the number of marked edges whose two endpoints lie in the same component of \(F-U\). Then \(b=2m\), so \(E+2m=4\). Every odd component with a three-edge \(J\)-cut is a singleton unless it contains at least two internal marked edges, by [Note 123's marked-cut inequality](123-exact-case-xii-terminal-vertices-are-independent.md).

The case \(E=0,m=2\) is impossible. If the two internal marks lie in different components, each is a nontrivial three-cut shore with only one internal mark, violating Note 123. If they lie in the same component, the required triple-boundary state missing precisely their two labels cannot exist: [Note 161's deletion argument](161-disconnected-unmarked-core-has-a-five-cut-or-a-two-vertex-four-cut.md) requires its two selected marked endpoints in **distinct** odd components of every maximum barrier.

Consequently the smallest maximum barrier has exactly one of these profiles:

| budget | non-singleton odd components | internal marked edges |
|---|---|---|
| \(E=2,\ m=1\) | one component with a five-edge \(J\)-cut | its unique internal mark |
| \(E=4,\ m=0\) | one component with a seven-edge \(J\)-cut | none |
| \(E=4,\ m=0\) | two components, each with a five-edge \(J\)-cut | none |

Every other odd component is a singleton with a three-edge \(J\)-cut. The five marked edges otherwise run between distinct odd components, and each \(u\in U\) meets three distinct components by (1). This is a necessary **all-orders** quotient classification for the deficiency-two branch. The five-cut and seven-cut shore matching relations, and the perfectly matchable \(F\) branch of [Note 167](167-all-terminal-bf-completion-is-a-petersen-walk-labelling.md), still require complete perfect-matching closure arguments.

There is an exact order budget. For a connected component \(C\) of \(F-U\), write \(r(C)=|E(F[C])|-|C|+1\) for its unmarked cycle rank, and let \(\rho=\sum_C r(C)\). Cubic degree counting gives
\[
|C|=|\delta_J(C)|+2m_C+2r(C)-2,
\]
where \(m_C\) counts marks internal to \(C\). Thus either one non-singleton shore has \(|C|=5+2\rho\), or two have sizes \(3+2r(A)\) and \(3+2r(B)\); the remaining components are singleton. In both cases
\[
\boxed{|V(H)|=2|U|+11+2\rho.}                          \tag{3}
\]
[Note 100's existing order bound](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) therefore requires \(|U|+\rho\ge3\). In particular a one-vertex barrier needs at least two independent unmarked cycles across its non-singleton shores; a completely acyclic profile needs \(|U|\ge3\). This uses the established small-order result, not a new enumeration.
