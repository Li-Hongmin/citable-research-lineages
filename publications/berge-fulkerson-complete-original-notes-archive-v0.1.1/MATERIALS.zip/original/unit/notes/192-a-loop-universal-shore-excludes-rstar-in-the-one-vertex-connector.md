> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A loop-universal shore excludes R-star in the one-vertex connector

In [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) genuine \(|U|=1\) two-five-cut connector, suppose \(B^\circ\) has the published Case-XIII \(R^*\) boundary relation and the other actual shore relation \(A^\circ\) contains **all ten** BF loops. Then the outer five-pole cannot have exact Case-XII boundary support, for any relative port permutation. In particular, the shore pair \(L^*\)--\(R^*\) is impossible in this profile. Combining this with [Note 190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md), the only shore-type pair still possible in the \(|U|=1\) two-five-cut profile is \(R^*\)--\(R^*\).

The point is that a BF loop \([pq]\) has the same six **boundary subsets** as a doubled Tait colouring with lonely pair \(pq\): two triple boundaries \([5]\setminus\{p,q\}\), two singleton \(p\) boundaries, and two singleton \(q\) boundaries. Its internal matching identities need not form a Tait colouring. The connector of Note 172 uses only these boundary subsets and the fact that the shore row consists of six genuine perfect matchings with load two. Thus [Note 184's](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) and [Notes 188, 190's](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) transports from a doubled Tait boundary apply verbatim to any **actual** shore BF loop of the same type. No three-edge-colourability of \(A^\circ\) is assumed.

Let \(T\) be the forbidden missing-pair pentagon of exact Case XII. Write the three common marked ports as \(x,y,z\), the \(A\)--\(w\) port as \(\delta\), the \(B\)--\(w\) port as \(\epsilon\), and the two unmarked ports toward \(u\) as \(0\). The relation \(R^*\) supports exactly the BF pairs whose local states have opposite Figure-7 colours
\[
P=\{13,14,24,35,45\},\qquad Q=\{12,15,23,25,34\}.
\]
Write \(c(p)\) for this colour after the arbitrary relative port permutation. If an actual connector transport would produce a forbidden \(T\)--\(T\) outer pair from a \(B^\circ\) input \((p)(q)\), then \(c(p)=c(q)\).

If \(\delta\epsilon\notin T\), name the midpoint of their shorter \(T\)-path \(x\), and name the two remaining common ports so that
\[
T=\delta-x-\epsilon-z-y-\delta.                    \tag{1}
\]
The loop-universal shore supplies actual \([xz]\) and \([\delta y]\) rows. The \([xz]\) row's [Note 184 transport](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) sends \((xy)(x\epsilon)\) to \((yz)(z\epsilon)\), so \(c(xy)=c(x\epsilon)\). The first three \([\delta y]\) rows of [Note 188](188-the-tree-rstar-two-five-cut-profile-is-impossible.md) send \((x\epsilon)(yz)\) and \((z\epsilon)(xy)\) to \((\delta x)(yz)\), and \((yz)(y\epsilon)\) to \((\delta y)(yz)\). All these outputs are \(T\)--\(T\) types under (1), hence
\[
c(xy)=c(x\epsilon)=c(yz)=c(z\epsilon)=c(y\epsilon). \tag{2}
\]
The three states \(yz,z\epsilon,y\epsilon\) form a monochromatic triangle, so the block must be \(Q\) and \(\{y,z,\epsilon\}=\{1,2,5\}\). Neither remaining port \(3\) nor \(4\) has two \(Q\)-neighbours in this triangle, yet \(xy,x\epsilon\in Q\) demand exactly that for \(x\). Contradiction.

If \(\delta\epsilon\in T\), name the three common ports in order along its other path:
\[
T=\delta-\epsilon-x-y-z-\delta.                  \tag{3}
\]
The same two actual loops suffice. The first three \([\delta y]\) rows of [Note 190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) force
\[
c(z\epsilon)=c(yz)=c(xy)=c(x\epsilon),           \tag{4}
\]
because each displayed outer pair consists of two edges of (3). Thus \(xy,yz,z\epsilon,\epsilon x\) form a monochromatic four-cycle. The block \(Q\) contains no four-cycle; \(P\) is one four-cycle with a single leaf at its fifth port, which here must be \(0\). The first two \([xz]\) rows of Note 190 send \((z0)(x\epsilon)\) and \((z\epsilon)(x0)\) to \((z\delta)(x\epsilon)\), forbidden under (3). Hence \(c(z0)=c(x\epsilon)=P\) and \(c(x0)=c(z\epsilon)=P\). The leaf \(0\) would have two distinct \(P\)-neighbours, impossible.

Both cases use only genuine BF loop rows and actual supported \(R^*\) pairs, so every asserted outer row is supplied by Note 172's exact connector. Figure 7 gives all ten loops to \(L^*\), proving the stated exclusion. \(\square\)

The unique \(0_A=3\) placement left by [Note 191](191-a-disjoint-shore-pair-excludes-rstar-except-one-lstar-centre-port.md)'s weaker three-type gate is therefore also excluded. The remaining \(R^*\)--\(R^*\) pair, other Tutte-barrier profiles, and the general exact Case-XII closure problem remain unresolved.

[Note 193](193-two-rstar-shores-force-a-forbidden-loop-in-the-one-vertex-connector.md) subsequently excludes the \(R^*\)--\(R^*\) pair by a separate actual pair-to-loop rectangle. Hence the entire \(|U|=1\) two-five-cut profile is closed under the stated minimum-host hypotheses.
