> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first-leaf B marking has a real cross row

Use the type B marked exterior of [Note 249](249-the-first-leaf-six-cycle-has-three-surviving-markings.md):
\[
K=\{1O,1L,1Q,2O,2R,3O,3P,4L,4R\},\qquad
a:P-C,\ d:Q-C,\ b:L-P,\ c:R-Q.
\]
Here \(iw=u_iw\). This note tests a precise weaker claim suggested by [Note 250](250-the-first-leaf-d-marking-forces-a-doubled-cross-half.md) and [Note 251](251-the-first-leaf-c-marking-has-a-forbidden-six-cycle-switch.md): whether the B marking itself prevents a real \((ea)(eb)\) six-perfect-matching row, even before exact negative support is imposed.

**Counterexample to that weaker claim.** There is a connected simple cubic five-pole of order 19 with this marked exterior and a real \((ea)(eb)\) row. Each half loads every proper edge once. Its full BF support is **not** exact Case XII: the row itself exhibits a Tait state \(eb\in T\), so doubling that Tait colouring gives the forbidden loop \([eb]\).

Take the odd shore \(C\) to be the path \(v_1v_2v_3v_4v_5\), with internal marked edge \(e=v_1v_5\). Attach \(h_3=u_3v_1\), the shore half of \(a\) at \(v_2\), \(h_2=u_2v_3\), \(h_4=u_4v_4\), and the shore half of \(d\) at \(v_5\). Subdivide the five marks and put one terminal semiedge at each subdivision vertex. The shore together with \(t_e\) is the six-cycle \(t_e v_1v_2v_3v_4v_5t_e\). In the following table, a listed exterior mask includes proper shore ports; \(Q,R,P_4\) list only internal shore edges, and the terminal boundary is specified separately:
\[
Q=\{t_ev_1,v_2v_3,v_4v_5\},\quad
R=\{v_1v_2,t_ev_5\},\quad P_4=\{v_3v_4\}.          \tag{1}
\]

| Half | Matching | Terminal boundary | Exterior mask | Internal shore edges |
|---|---|---|---|---|
| \(D\) | \(X_a\) | \(b,c,d\) | \(a:P,1Q,2R,3O,4L\) | \(Q\) |
| \(D\) | \(Y_a\) | \(a\) | \(3P,1O,d:Q,b:L,c:R,h_2,h_4\) | \(R\) |
| \(D\) | \(Z_e\) | \(e\) | \(a:C,d:C,b:P,c:Q,1L,2O,4R,h_3\) | \(P_4\) |
| \(E\) | \(U_{eb}\) | \(a,c,d\) | \(b:L,1Q,2O,3P,4R\) | \(Q\) |
| \(E\) | \(V_b\) | \(b\) | \(a:P,d:Q,c:R,h_2,h_4,1L,3O\) | \(R\) |
| \(E\) | \(W_e\) | \(e\) | \(a:C,d:C,b:P,c:Q,1O,2R,4L,h_3\) | \(P_4\) |

Each row of the table is a perfect matching: the exterior edges cover \(U\), \(W\), and the exterior mark subdivision vertices not already covered by its terminal edges, while (1) covers exactly the unmatched shore vertices and \(t_e\). In each half, the three exterior masks partition all nine \(K\)-edges, all eight exterior marked halves and all three \(h\)-edges. Their internal shore masks \(Q,R,P_4\) partition the six shore-cycle edges; each terminal semiedge occurs exactly once. Consequently \(D+E=2\mathbf1\) on every edge, with states \(ea\) and \(eb\) as claimed. The graph has girth five: the internal shore and \(K\) each have a six-cycle, while \(u_2-R-u_4-v_4-v_3-u_2\) is a five-cycle; the two-edge marked paths and all shore attachments create no triangle or quadrilateral.

This is a **real matching-row counterexample** to excluding B by a compatible exterior mask, a compatible six-port shore, or one cross row. It does not refute any exact-Case-XII claim. The surviving B obstruction must use the complete negative BF support across additional matchings or rows. In fact, this order-19 graph is ruled out as exact Case XII independently by [Note 226's order-33 bound](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md).
