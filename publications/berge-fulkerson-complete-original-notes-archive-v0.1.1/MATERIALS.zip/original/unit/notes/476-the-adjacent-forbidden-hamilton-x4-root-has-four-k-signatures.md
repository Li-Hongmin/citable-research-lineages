> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The adjacent-forbidden Hamilton \(X:4\) root has four \(K\) signatures

Use the fixed marked Hamilton exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36),
\tag{1}
\]
and the old genuine \((eX)(eZ)\) row of [Note 462](462-the-x-y-forbidden-hamilton-row-has-only-the-common-endpoint-switch.md), with six distinct complete matching occurrences \(P=eX,R=eZ,K=Z,J=X,a=e,b=e\) in boundary-type notation. The terminal pairs are \(e=ab,X=RJ,Y=W=PR,Z=PK\). Assume the forbidden \([eX]\) and \((eX)(eY)\) types are absent. Note 462 then forces \(R\) to root at \(Z:6\), \(K\) to take \(W:6\), and the \(R\triangle K\) terminal path to run directly through original vertex \(6\). Here we classify the branch in which \(P\) roots at \(X:4\).

In this branch, both \(P\) and \(R\) take the tree halves \(1u_1,2u_2,3u_3\), so each of those three edges has pair \(PR\). At original vertex \(2\), \(K\) cannot take \(2u_2\), and it cannot take \(Z:2\) because it selects terminal \(Z\). Thus \(K\) must take \(2u_1\). At original vertex \(3\), \(K\) cannot take \(3u_3\) or \(W:3\), because it already takes \(W:6\); hence it must take \(3u_2\). These are two of the three tree halves used by the singleton \(K\).

At original vertex \(1\), \(1u_1=PR\), so \(K\) must take either \(X:1\) or \(Y:1\). It takes exactly one half of each marked subdivision \(X,Y,W\), and exactly one more tree half. If it takes \(X:1\), its \(Y\)-half is \(Y:5\), leaving original vertex \(4\) for the third tree half. That half can be \(4u_3\) or \(4u_4\). If instead it takes \(Y:1\), its \(X\)-half is \(X:4\), leaving original vertex \(5\) for the third tree half. That half can be \(5u_4\) or \(5u_5\). Therefore the following table is exhaustive:
\[
\begin{array}{c|c|c|c}
&K\text{ marked halves}&K\text{ tree halves}&K\text{ proper ports}\\ \hline
D_1&X:1,Y:5,W:6&2u_1,3u_2,4u_3&p_4,p_5\\
D_2&X:1,Y:5,W:6&2u_1,3u_2,4u_4&p_3,p_5\\
D_3&X:4,Y:1,W:6&2u_1,3u_2,5u_4&p_3,p_5\\
D_4&X:4,Y:1,W:6&2u_1,3u_2,5u_5&p_3,p_4
\end{array}                                                     \tag{2}
\]
The proper-port column is simply the complement of the three tree subdivisions occupied by \(K\). Each line is a **necessary** matching signature, not a claim that it has an actual BF row or exact-Case-XII support.

The \(D_4\) line already has a useful fixed-mask boundary. Put \(S=\{J,a,b\}\). Here \(X:4=PK\), \(X:1=ab\), and original vertex \(1\) forces \(Y:1=KJ,Y:5=ab\). Reading the old pairs successively through \(u_1,u_2,Z,W,u_3,u_4,u_5\) gives
\[
e=ab,\qquad
(p_1,p_2,p_3,p_4,p_5)=
\bigl(S\setminus\{\alpha\},S\setminus\{\delta\},
K\theta,K\eta,S\setminus\{\nu\}\bigr),
\quad \{\alpha,\delta,\nu\}=S,
\quad \{\theta,\eta\}=\{a,b\}.                         \tag{3}
\]
For clarity, \(u_1:2=K\alpha\), \(u_2:3=K\delta\), \(Z:6=R\alpha\), \(W:6=K\delta\), \(u_5:6=P\nu\), so vertex \(6\) gives the first brace in (3). At vertex \(4\), \(X:4=PK\) forces \(u_3:4=S\setminus\{\theta\}\) and \(u_4:4=R\theta\); at vertex \(5\), \(Y:5=ab\) forces \(u_4:5=PJ,u_5:5=RK\), and the \(u_4\) partition gives the second brace.

If the old six complete shore restrictions are kept label by label, the pair on \(p_3\) and \(p_4\) remains \(K\theta\) and \(K\eta\). The zero-port occurrences \(P,R\) remain the two triples and the two occurrences using \(e\), namely \(a,b\), remain singleton-\(e\), by the same six-port quota used in [Note 464](464-the-real-x-y-row-has-only-case-xii-allowed-types-with-fixed-shore-masks.md). A proposed \([eX]\) row would therefore put \(K\) on terminal \(X\), so it cannot use \(X:4\); its two port uses prevent it from using either tree half at \(u_3,u_4\). Original vertex \(4\), incident only with \(X:4,4u_3,4u_4\), would then be unmatched by \(K\). Thus \([eX]\) cannot be obtained while preserving those labelled shore restrictions. This does not rule out \([eY]\) or \((eX)(eY)\), nor a forbidden row with changed shore restrictions.

[Note 463](463-a-real-common-endpoint-x-y-hamilton-row-has-a-forbidden-loop.md) realizes \(D_1\) with six complete matchings on a genuine 21-vertex five-pole, while its full support also contains forbidden \([eX]\). [Note 464](464-the-real-x-y-row-has-only-case-xii-allowed-types-with-fixed-shore-masks.md) shows that retaining that row's six shore masks once each cannot detect the forbidden type. Thus (2)--(3) sharpen the tree-level target for the last adjacent forbidden-pair orbit but do not settle its cross-mask full-closure obstacle, the \(P:X:1\) branch, other marked exteriors, exact Case XII, or Berge--Fulkerson. These are hand-derived necessary statements without OMEN or local mathematical recomputation; they await independent review. \(\square\)
