> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton row must root its \(eY\)-triple at \(Y:5\)

Consider the fixed marked Hamilton three-spoke exterior of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36).                         \tag{1}
\]
The five proper shore ports are \(p_i\) at \(u_i\), and the sixth shore terminal is \(e\). Suppose the **complete** support is exact Case XII with forbidden \(e\)-labels \(\{eX,eZ\}\). Its two possible pentagons are \(e-Y-X-Z-W-e\) and \(e-Y-Z-X-W-e\). Under the respective identifications \((e,Y,X,Z,W)=(1,3,5,2,4)\) and \((e,Y,Z,X,W)=(1,3,5,2,4)\), the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eX)(eY)\) row and excludes \([eX]\), \([eZ]\), and \((eX)(eZ)\).

Name the six complete matching occurrences of such a required row
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad a=e,\quad b=e.   \tag{2}
\]
Here each equality names the missing-pair type of a triple or the one terminal of a singleton. Its terminal pairs are
\[
e=ab,\qquad X=RJ,\qquad Y=PK,\qquad Z=W=PR.             \tag{3}
\]

## All-order necessary gate

The \(Y\)-starting component of \(R\triangle K\) cannot end at \(X\), which would make \([eX]\) beside the unchanged \(P\), nor at \(Z\), which would make forbidden \((eX)(eZ)\). It must end at \(W\). This component starts with the \(K\)-coloured terminal \(Y\), then takes the \(R\)-coloured marked half. At each original vertex it leaves by a \(K\) edge; if that edge enters a tree subdivision, it is a tree half rather than a port, and the component leaves the subdivision by its \(R\) tree half because \(R\) has no port. It therefore never enters the shore and moves monotonically away from \(R\)'s tree root until it reaches a marked terminal. The singleton \(K\) uses one half at each of \(X,Z,W\), three tree halves, and two proper shore ports. Thus the route crosses at most three tree edges. The route from \(Y:1\) to \(W:6\) has length five and is impossible.

In the table, \(iu_j\) denotes the half of tree edge \(u_j\) incident with original vertex \(i\). Each line is a **necessary** marked/tree/port signature; a line does not assert that a complete BF row or exact support exists.
\[
\begin{array}{c|c|c|c|l|c}
 &P\text{ root}&R\text{ root};\ W\text{ end}&K\text{ marked halves}
 &K\text{ tree halves}&K\text{ ports}\\ \hline
A_1&1&1;3&X4,Z6,W3&1u_1,2u_2,5u_5&3,4\\
A_2&4&1;3&X4,Z6,W3&1u_1,2u_2,5u_5&3,4\\
B_1&1&5;3&X1,Z6,W3&2u_1,4u_3,5u_4&2,5\\
B_2&1&5;3&X1,Z6,W3&2u_2,4u_3,5u_4&1,5\\
B_3&4&5;3&X1,Z6,W3&2u_1,4u_3,5u_4&2,5\\
C_1&1&5;6&X1,Z2,W6&3u_2,4u_3,5u_5&1,4\\
C_2&1&5;6&X1,Z2,W6&3u_2,4u_4,5u_5&1,3\\
C_3&1&5;6&X1,Z2,W6&3u_3,4u_4,5u_5&1,2\\
C_4&4&5;6&X1,Z2,W6&3u_2,4u_3,5u_5&1,4\\
C_5&4&5;6&X1,Z2,W6&3u_2,4u_4,5u_5&1,3\\
C_6&1&5;6&X4,Z2,W6&1u_1,3u_2,5u_5&3,4\\
C_7&1&5;6&X4,Z2,W6&1u_1,3u_3,5u_5&2,4
\end{array}                                                    \tag{4}
\]

For completeness, on \(Y:1\to W:3\), \(K\) takes \(1u_1,2u_2,W:3\). This forces \(X:4,Z:6\); vertex \(5\) then forces \(5u_5\), because \(5u_4\) is saturated by \(P,R\), giving \(A_1,A_2\). On \(Y:5\to W:3\), \(K\) takes \(5u_4,4u_3,W:3,X:1\). It must take \(Z:6\), since \(Z:2\) would leave vertex \(6\) to the saturated \(6u_5\). Vertex \(2\) admits \(2u_1\) or \(2u_2\), but the latter is saturated when \(P\) roots at \(4\); these are \(B_1,B_2,B_3\). On \(Y:5\to W:6\), \(K\) takes \(5u_5,W:6,Z:2\). If it takes \(X:1\), its remaining vertices \(3,4\) can be covered by two distinct tree subdivisions in exactly the five ways \(C_1\)--\(C_5\); \(3u_3\) is saturated when \(P\) roots at \(4\). If it takes \(X:4\), then \(P\) must root at \(1\), for otherwise \(1u_1\) is saturated; the two options at vertex \(3\) give \(C_6,C_7\). The port column is the complement of the three used tree subdivisions. These cases exhaust the route choices and the original-vertex matching constraints, at every shore order.

There is already a small fixed-mask restriction in \(A_1,A_2\). In either line the original \(K\) uses both \(p_3,p_4\). Any \([eX]\) recompletion preserving the unordered multiset of the six complete shore restrictions would have to keep \(K\) as a singleton-\(X\) occurrence, because the two zero-port occurrences are the triples and the two four-port occurrences are singleton-\(e\). But \(K\)'s ports at \(u_3,u_4\) leave it no tree half at original vertex \(4\); it would have to use \(X:4\), impossible for a singleton-\(X\) matching. This only excludes the fixed-multiset recompletion, not the full closure.

## Every \(A_2\) phase has a forbidden fixed-mask recompletion

In fact \(A_2\) is excluded by the complete BF support condition at **every** shore order and topology. Put \(S=\{J,a,b\}\). The old roots \(P:X:4,R:Y:1\), together with the tree and marked halves in \(A_2\), force its six shore-port pairs to have the form
\[
e=ab,\quad
(p_1,p_2,p_3,p_4,p_5)
=\bigl(S\setminus\{\lambda _1\},S\setminus\{\lambda _2\},
K\theta,K\eta,ab\bigr),
\quad
\{\lambda _1,\lambda _2,\lambda _3\}=S,
\quad \{\theta,\eta\}=\{\lambda _1,\lambda _2\}.          \tag{5}
\]
All letters in each brace are distinct. To see completeness, the old first/second halves at \(u_1,u_2\) are \((PK,R\lambda _1)\) and \((PK,R\lambda _2)\). At \(Z,W\), original vertex \(6\) propagates \(\lambda _1\) to \(W:3=K\lambda _1\). Original vertex \(3\) then makes its three companions \(\lambda _1,\lambda _2,\lambda _3\) partition \(S\). At \(u_3\), the halves are \((P\lambda _3,R\eta)\), and the port is \(K\theta\); original vertex \(4\) forces \(p_4=K\eta\). Finally \(p_5=ab\) follows from the old \(Y:5=ab\) and vertex \(5\). Conversely the old local pair partitions impose no further relation on these twelve labelled phases.

If \(\lambda _3=h\in\{a,b\}\), let \(\nu\) be the other element of \(\{a,b\}\); then \(\{\lambda _1,\lambda _2\}=\{J,\nu\}=\{\theta,\eta\}\). Keep **each** of the six original complete shore matching restrictions unchanged and replace only the exterior pairs by
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\lambda _1,S\setminus\{\lambda _1\})
&(R\lambda _2,PK,S\setminus\{\lambda _2\})
&(Rh,P\eta,K\theta)
&(R\theta,Ph,K\eta)
&(RK,PJ,ab)
\end{array}                                                   \tag{6}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,J\nu,Kh)&(PR,Kh,J\nu)&(KJ,Ph,R\nu)&(PR,J\nu,Kh).
\end{array}                                                   \tag{7}
\]
At original vertices \(1,\ldots,6\), the incident pairs are
\[
(PR,J\nu,Kh),\quad
(K\lambda _1,R\lambda _2,Ph),\quad
(PK,Rh,J\nu),\quad
(P\eta,R\theta,Kh),\quad
(Ph,RK,J\nu),\quad
(PJ,R\nu,Kh).                                                  \tag{8}
\]
Each triple in (6)--(8) partitions \(\{P,R,K,J,a,b\}\); the port columns equal (5). The terminal pairs are \(e=ab,Z=KJ,X=Y=W=PR\), the forbidden loop \([eZ]\).

If \(\lambda _3=J\), then \(\{\lambda _1,\lambda _2\}=\{\theta,\eta\}=\{a,b\}\). Instead use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\lambda _1,S\setminus\{\lambda _1\})
&(P\lambda _2,RK,S\setminus\{\lambda _2\})
&(PJ,R\eta,K\theta)
&(J\theta,PR,K\eta)
&(KJ,PR,ab)
\end{array}                                                   \tag{9}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PR,KJ,ab)&(PK,RJ,ab)&(PR,ab,KJ).
\end{array}                                                   \tag{10}
\]
The original vertices see
\[
(PR,ab,KJ),\quad
(K\lambda _1,P\lambda _2,RJ),\quad
(RK,PJ,ab),\quad
(PJ,R\eta,K\theta),\quad
(PR,KJ,ab),\quad
(PR,ab,KJ).                                                   \tag{11}
\]
Again every triple is a six-label partition and the port columns agree with (5). The terminal pairs are \(e=ab,X=RJ,Z=PK,Y=W=PR\), the forbidden double-triple type \((eX)(eZ)\). Since (6)--(11) change no shore restriction, either recompletion glues to the **same arbitrary actual shore** as the old genuine row. Hence no exact-Case-XII pole with the marked exterior (1) can realize signature \(A_2\).

The same templates exclude four of the twelve labelled port phases of \(A_1\). In that signature let \(X:1=P\nu\) with \(\nu\in\{a,b\}\), let \(\bar\nu\) be the other \(e\)-singleton, and let \(Y:1=R\mu\). Writing \(u_1:1=K\lambda _1\) and \(u_2:2=K\lambda _2\), the old vertex partitions give \(\{\nu,\mu,\lambda _1\}=S\) and
\[
(p_1,p_2,p_3,p_4,p_5)
=\bigl(S\setminus\{\lambda _1\},S\setminus\{\lambda _2\},
K\lambda _2,K\bar\nu,S\setminus\{\mu\}\bigr).          \tag{11a}
\]
If \(\mu=J\), then \(\lambda _1=\bar\nu\) and \(p_5=ab\). For \(\lambda _2\in\{J,\nu\}\), the port list (11a) is exactly (5), with \((\lambda _1,\lambda _2,\theta,\eta)=(\bar\nu,\lambda _2,\lambda _2,\bar\nu)\). Hence (6)--(11) yield forbidden \([eZ]\) when \(\lambda _2=J\), and forbidden \((eX)(eZ)\) when \(\lambda _2=\nu\). This excludes four labelled \(A_1\) phases, counting both values of \(\nu\).

It remains to cover \(\lambda _2=\bar\nu\) when \(\mu=J\), and all three choices of \(\lambda _2\) when \(\mu=\bar\nu\). By interchanging \(a,b\), take \(\nu=a,\bar\nu=b\). The four remaining port profiles and their \((\mu,\lambda _2)\) parameters are
\[
\begin{array}{c|c|ccccc}
& (\mu,\lambda _2)&p_1&p_2&p_3&p_4&p_5\\ \hline
I&(J,b)&Ja&Ja&Kb&Kb&ab\\
II&(b,J)&ab&ab&KJ&Kb&Ja\\
III&(b,a)&ab&Jb&Ka&Kb&Ja\\
IV&(b,b)&ab&Ja&Kb&Kb&Ja
\end{array}                                                     \tag{11b}
\]
For each line keep the six original **complete** shore matching restrictions separately, and replace only their exterior restrictions by the row of edge pairs below. At each \(u_i\), the entries are first half, second half, proper port:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
I&(Rb,PK,Ja)&(Rb,PK,Ja)&(Ra,PJ,Kb)&(Ra,PJ,Kb)&(RK,PJ,ab)\\
II&(RJ,PK,ab)&(RJ,PK,ab)&(Ra,Pb,KJ)&(RJ,Pa,Kb)&(RK,Pb,Ja)\\
III&(RJ,PK,ab)&(Ra,PK,Jb)&(RJ,Pb,Ka)&(RJ,Pa,Kb)&(RK,Pb,Ja)\\
IV&(RK,PJ,ab)&(RK,Pb,Ja)&(Ra,PJ,Kb)&(Ra,PJ,Kb)&(Rb,PK,Ja)
\end{array}                                                     \tag{11c}
\]
At \(X,Y,Z,W\), the entries are terminal and then the two marked halves in the orders of (1):
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
I&(RJ,Pa,Kb)&(PR,KJ,ab)&(PK,Ja,Rb)&(PR,Jb,Ka)\\
II&(RJ,Pb,Ka)&(PR,Ka,Jb)&(PK,ab,RJ)&(PR,Jb,Ka)\\
III&(RJ,Pb,Ka)&(PR,Ka,Jb)&(PK,Jb,Ra)&(PR,ab,KJ)\\
IV&(RJ,Pa,Kb)&(PR,Jb,Ka)&(PK,ab,RJ)&(PR,KJ,ab)
\end{array}                                                     \tag{11d}
\]
For a direct check, the pairs at original vertices \(1,\ldots,6\) are
\[
\begin{array}{c|llllll}
&1&2&3&4&5&6\\ \hline
I&(Rb,Pa,KJ)&(PK,Rb,Ja)&(PK,Ra,Jb)&(PJ,Ra,Kb)&(PJ,RK,ab)&(PJ,Rb,Ka)\\
II&(RJ,Pb,Ka)&(PK,RJ,ab)&(PK,Ra,Jb)&(Pb,RJ,Ka)&(Pa,RK,Jb)&(Pb,RJ,Ka)\\
III&(RJ,Pb,Ka)&(PK,Ra,Jb)&(PK,RJ,ab)&(Pb,RJ,Ka)&(Pa,RK,Jb)&(Pb,Ra,KJ)\\
IV&(RK,Pa,Jb)&(PJ,RK,ab)&(Pb,Ra,KJ)&(PJ,Ra,Kb)&(PJ,Rb,Ka)&(PK,RJ,ab)
\end{array}                                                     \tag{11e}
\]
Every triple in (11c)--(11e) partitions \(\{P,R,K,J,a,b\}\). The port columns in (11c) are (11b), and \(e=ab\) is unchanged, so each row glues to the **same arbitrary shore** as its old \(A_1\) row. All four terminal-pair lists in (11d) are \(e=ab,X=RJ,Z=PK,Y=W=PR\): the forbidden \((eX)(eZ)\) type. Swapping \(a,b\) covers the other four labelled phases. Together with the transfer from (5), this excludes all twelve \(A_1\) phases at every shore order. Consequently an exact-Case-XII \((eX)(eY)\) row in this marked exterior cannot root its \(R=eY\) triple at \(Y:1\); it must root at \(Y:5\).

## A real \(A_2\) row and two additional cross-mask loop certificates

The \(A_2\) line is attained by a simple connected 21-vertex cubic five-pole of girth at least five. At each \(u_i\), list the halves toward \(i,i+1\), then the port. At each marked subdivision list its terminal and then its halves in the order \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Put these pairs on the exterior edges:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PK,RJ,ab)&(PK,Ra,Jb)&(Pb,RJ,Ka)&(ab,PR,KJ)&(KJ,PR,ab)
\end{array}                                                     \tag{12}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PK,RJ,ab)&(PR,ab,KJ)&(PR,KJ,ab).
\end{array}                                                     \tag{13}
\]
The six original vertices see, respectively,
\[
(PK,ab,RJ),\ (RJ,PK,ab),\ (Ra,Pb,KJ),\
(RJ,PK,ab),\ (PR,KJ,ab),\ (PR,KJ,ab),                       \tag{14}
\]
each a partition of the six labels. For the shore take vertices \(q_e,q_1,\ldots,q_5\), connect \(q_i\) to \(u_i\), put terminal \(e\) at \(q_e\), and form the cycle
\[
q_e-q_1-q_5-q_3-q_4-q_2-q_e
\]
with successive edge pairs \(PJ,RK,PJ,Rb,Pa,RK\). Its port pairs, including \(e\), are exactly
\[
                (ab,ab,Jb,Ka,KJ,ab).                        \tag{15}
\]
Each shore vertex also sees three disjoint pairs. Thus (12)--(15) specify six **complete** perfect matchings that load every edge twice, with terminal pairs (3). The original prism edges are all subdivided, the shore is a six-cycle, and any mixed cycle crosses at least two connectors, one shore edge, and two exterior edges; the girth is at least five. The old \(P\) and \(R\) have distinct zero-port shore restrictions \(Q_P,Q_R\). Here \((\lambda _1,\lambda _2,\lambda _3,\theta,\eta)=(J,a,b,a,J)\), so (6)--(8) already give a forbidden \([eZ]\) recompletion that preserves its original six shore restrictions once each.

For this shore, \(Q_R\) uses the second, fourth, and sixth cycle edges. Its complement pairs
\[
                     ep_1\mid p_2p_4\mid p_3p_5              \tag{16}
\]
with no closed shore component. The old \(P=eX\) exterior restriction, rooted at \(X:4\), has complementary pairing \(Xp_5\mid p_1p_2\mid p_3p_4\). Recombine this exterior restriction with \(Q_R\). The complement joins into the single open route
\[
               e,p_1,p_2,p_4,p_3,p_5,X,                     \tag{17}
\]
where consecutive named ports alternate between shore and exterior paths. All 15 exterior and six shore vertices lie on these paths, so there is no other component. Alternating colours give a genuine forbidden \([eX]\) BF loop.

Independently take the zero-port \(eZ\)-triple whose exterior tree is rooted at \(Z:2\), again with the same complete shore matching \(Q_R\). Its exterior complement pairs \(Zp_3\mid p_1p_2\mid p_4p_5\): tracing the three paths gives \(Z-t_Z-6-t_W-3-u_3-p_3\), \(p_1-u_1-2-u_2-p_2\), and \(p_4-u_4-4-t_X-1-t_Y-5-u_5-p_5\). These paths contain all 15 exterior vertices. Together with (16) they form the single open route
\[
               e,p_1,p_2,p_4,p_5,p_3,Z.                     \tag{18}
\]
Hence \([eZ]\) is also in the **complete** support by a second route. In both (17) and (18), the two complementary singleton shore restrictions are the old \(Q_a,Q_J\): \(Q_a\) has ports \(e,p_1,p_3,p_5\) and internal edge \(q_4q_2\), while \(Q_J\) has ports \(p_2,p_4\) and internal edges \(q_eq_1,q_5q_3\). Each forbidden loop can therefore be represented with shore-mask multiset \(Q_R,Q_R,Q_a,Q_a,Q_J,Q_J\), reusing three old masks with new multiplicities as in [Note 465](465-the-real-x-y-row-has-a-forbidden-loop-using-only-three-old-shore-masks.md).

The twelve-signature gate is an all-order necessary condition for this **fixed marked exterior**, and the fixed-mask templates exclude \(A_1,A_2\) for every labelled port phase. The 21-vertex example proves that the old \(A_2\) BF row is real, while both fixed-mask and cross-mask closure put forbidden types in its complete support. The ten remaining necessary signatures are \(B_1,B_2,B_3,C_1,\ldots,C_7\); no exact-Case-XII pole has been produced. The reflection \(1\leftrightarrow6,2\leftrightarrow5,3\leftrightarrow4\), with \(X\leftrightarrow W,Y\leftrightarrow Z\), gives the corresponding gate and reflected short-root exclusion for forbidden \(\{eY,eW\}\). The gate and certificates are hand-derived, without OMEN or local mathematical recomputation, and await independent review. \(\square\)
