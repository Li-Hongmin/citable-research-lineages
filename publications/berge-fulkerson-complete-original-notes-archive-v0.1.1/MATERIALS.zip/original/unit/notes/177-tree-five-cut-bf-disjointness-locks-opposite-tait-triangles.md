> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A tree five-cut locks opposite Tait triangles to an all-terminal shore row

Let a cubic graph \(K\) have a five-edge cut with one shore the three-vertex tree \(T_3\). Name its centre port \(h\), and its two end-port groups \(\{a,b\}\mid\{c,d\}\). Let \(D\) be the other five-pole. Assume \(K\) has **no BF cover**, so the complete BF relations of \(D\) and \(T_3\) are disjoint. The lemma does not assume marked edges or exact Case XII.

**Application to the possible \((4,2,2)\) profile.** Take \(K\) to be the *whole* minimum-counterexample host \(G\) associated with [Note 166's](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) \((4,2,2)\) quotient, and \(T_3=G[\{u,w_1,w_2\}]\). Its four end ports are the edges from \(w_1,w_2\) to the four marked subdivision vertices; the centre port is the unmarked edge from \(u\) to the cyclic core. The opposite shore \(D\) includes that core, all five marked subdivision vertices, and the pentagon on the other side of the Case-XII cut. It is **not** the smaller cyclic shore of [Note 175](175-the-422-exterior-connector-excludes-only-the-all-terminal-type.md). Suppressing the five marked vertices instead gives the core \(J\), which [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) proves is BF-covered by minimality. Hence the hypothesis here belongs to \(G\), not to \(J\). [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) shows that the other one-vertex quotient is also still open.

The tree's four Tait states are
\[
X=\{ac,ad,bc,bd\},                                      \tag{1}
\]
and every loop or pair type on \(X\) belongs to its BF relation: double or combine actual tree three-edge-colourings. Since a shared BF type would glue across the cut, no BF type of \(D\) has both states in \(X\). In particular \(D\) has no Tait state in \(X\).

## The only possible Tait-state sets

The six states outside \(X\) form two triangles sharing the terminal position \(h\):
\[
Y_a=\{ha,hb,ab\},\qquad Y_c=\{hc,hd,cd\}.              \tag{2}
\]
[Lemma 4.3 and its proof in Máčajová--Mazzuoccolo--Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) show that from any Tait state \(xy\), terminal Kempe paths give another Tait state sharing \(x\) and another sharing \(y\). Inside \(Y_a\cup Y_c\), state \(ab\) can move at \(a\) only to \(ha\), and at \(b\) only to \(hb\). Starting from \(ha\) or \(hb\) likewise forces \(ab\). The same holds for \(Y_c\). Hence
\[
\boxed{\mathcal T(D)\in\{\varnothing,\ Y_a,\ Y_c,\ Y_a\cup Y_c\}.} \tag{3}
\]
This is a necessary classification of **actual three-edge-colourings**, not a classification of the full BF relation. Equation (3) needs only that \(K\) is not three-edge-colourable: a common Tait state would glue. Thus it also applies separately to the smaller marked core \(J\) whenever that core is a snark, with its own opposite shore. The stronger BF-row claims below need the BF-uncovered hypothesis and apply to the whole \(G\), not to its BF-covered core.

## Opposite triangles have one surviving path pairing

Suppose both triangles occur. Choose any actual three-edge-colouring \(\phi\) of \(D\) with state \(ab\) and any \(\psi\) with state \(cd\). Overlay their three perfect matchings each. This is an actual six-matching BF row of \(D\) of type \((ab)(cd)\). Let \(M\) be \(\phi\)'s majority-colour matching, with boundary \(\{h,c,d\}\), and \(N\) be \(\psi\)'s majority-colour matching, with boundary \(\{h,a,b\}\). The other four matching occurrences have singleton boundaries \(a,b,c,d\).

The symmetric difference \(M\triangle N\) consists of even cycles and two alternating terminal paths pairing \(a,b,c,d\). If the pairing is \(ac\mid bd\), switch \(M,N\) along the \(a\)--\(c\) path. The new triple boundaries are \(\{h,a,d\}\) and \(\{h,b,c\}\), so the new BF type is \((bc)(ad)\), with both states in \(X\). If the pairing is \(ad\mid bc\), switch along the \(a\)--\(d\) path; the new type is \((bd)(ac)\), again entirely in \(X\). Either type also occurs on \(T_3\), so either cross pairing would BF-cover \(K\). Thus **every** such choice of \(\phi,\psi\) has the remaining pairing
\[
\boxed{ab\mid cd.}                                       \tag{4}
\]
Switching along the \(a\)--\(b\) path in (4) changes \(M\)'s boundary to all five ports and \(N\)'s boundary to \(\{h\}\); the other four singleton occurrences remain \(a,b,c,d\). Therefore \(D\) has an actual **all-terminal BF type**. We obtain the conditional trichotomy
\[
\boxed{K\text{ BF-uncovered}\quad\Longrightarrow\quad
\mathcal T(D)=\varnothing,\ Y_a,\ Y_c,
\text{ or }\bigl(Y_a\cup Y_c\text{ with (4) and an all-terminal BF row}\bigr).} \tag{5}
\]

## The all-terminal matching has an exact core gate in the marked profile

The path lock does not depend on how an all-terminal BF row was obtained. In **any** such row of \(D\), let \(Q\) have all five boundary ports and let \(P_h\) have only port \(h\). The two terminal paths of \(Q\triangle P_h\) pair \(a,b,c,d\). If one path joins opposite end groups, switching \(Q,P_h\) on it produces a pair type whose two missing pairs lie in \(X\), hence a BF cover of \(K\). Therefore every all-terminal row in a BF-uncovered host satisfies
\[
\boxed{Q\triangle P_h\text{ pairs }a\text{ with }b\text{ and }c\text{ with }d.} \tag{6}
\]

In the whole-host \((4,2,2)\) application, let \(v_h\in C\) be the endpoint of the centre edge \(h\), and let \(F[C]\) be the unmarked connected component of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md). Write \(r_i\) for the pentagon vertex joined to the marked subdivision vertex \(t_i\), including \(i=e\) for the mark internal to \(C\). An all-terminal perfect matching \(Q\) of the enlarged shore \(D\), with boundary \(\{h,a,b,c,d\}\), exists **if and only if**
\[
\boxed{F[C]-v_h\text{ has a perfect matching}.}             \tag{7}
\]
Indeed, the four boundary edges at \(t_a,t_b,t_c,t_d\) match those vertices externally, so their spokes to the pentagon and their halves toward \(C\) are unavailable. The pentagon has only its spoke \(r_et_e\) left and must use it. Its other four vertices then use the unique matching of the path obtained by deleting \(r_e\). The vertex \(t_e\) is matched to \(r_e\), so neither half of the internal mark is used. The only remaining unmatched core vertices are \(C-v_h\), and they can use precisely the edges of \(F[C]-v_h\). These forced choices also prove the converse.

For the cyclic pentagon order \(r_e,r_1,r_2,r_3,r_4\), its non-\(Q\) edges and the four spokes form the fixed paths \(t_1r_1r_er_4t_4\) and \(t_2r_2r_3t_3\). The two non-\(Q\) halves at \(t_e\) join the endpoints of the internal mark. Thus the cycle system to be labelled in Note 167 is obtained from \(F[C]\setminus Q\) by these two paths, the four marked halves toward \(C\), and the two halves through \(t_e\); no choice remains in the pentagon matching itself.

Consequently the full two-triangle option in (5) requires a matching in (7). More precisely, its all-terminal **BF row** requires one such matching whose forced extension \(Q\) satisfies the all-terminal completion criterion of [Note 167](167-all-terminal-bf-completion-is-a-petersen-walk-labelling.md) on \(D\), with the resulting singleton-\(h\) matching obeying (6). A matching in (7) alone does not supply that six-matching row.

In particular, if \(F[C]-v_h\) has no perfect matching, then the full two-triangle case is impossible and \(\mathcal T(D)\) is empty or exactly one of \(Y_a,Y_c\). This is a conditional structural reduction, not an exclusion of the \((4,2,2)\) profile.

The marked Petersen **core** of [Note 176](176-petersen-realizes-the-422-tait-state-boundary.md) has the full six-state set \(Y_a\cup Y_c\) and is BF-covered by a genuine tree-supported pair type. This does not test (5) on the larger shore \(D\) of a BF-uncovered whole host. For the possible \((4,2,2)\) minimum-host profile, (3)--(5) restrict that larger shore only. Transferring them to the cyclic core or to the exact Case-XII five-pole requires their actual matching relations across the five marked subdivisions and the opposite pentagon.
