> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Compatible pentagons can survive nontrivial canonical holonomy

The canonical transport map is not the full relation: a compatible pentagon may use a noncanonical choice at a cell. In the complete order-11 audit, all 41 exact-(S) Case-XII branches have at least one compatible pentagon. This includes the branches whose canonical holonomy is a 3-cycle (two branches) or a 4-cycle (one branch); in each of these examples the canonical holonomy has no fixed point, while compatible pentagons exist.

Thus nontrivial holonomy does not obstruct compatibility, but neither does the finite order-11 census prove universal existence. The correct remaining question is a relation-level selection theorem using the common cubic perfect-matching incidence, not a deterministic transport invariant.

Evidence and reproduction are retained in `scratch/n11_transport_relation_audit_results.json` and `scratch/case_xii_n11_geng_results.json`.
