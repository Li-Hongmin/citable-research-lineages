> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two R-star shores force a forbidden loop in the one-vertex connector

In the genuine \(|U|=1\) two-five-cut connector of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md), two shores with the published Case-XIII \(R^*\) BF relation cannot compose to an exact-Case-XII outer five-pole, for any relative port labelling. Together with [Notes 190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) and [192](192-a-loop-universal-shore-excludes-rstar-in-the-one-vertex-connector.md) and the earlier shore exclusions cited there, this eliminates the **entire \(|U|=1\) two-five-cut Tutte-barrier profile** in the minimum-host setting. The conclusion is about actual complete perfect-matching closure; it does not eliminate other barrier profiles or prove Berge--Fulkerson.

## A star-pair rectangle makes an outer BF loop

Let the three shared marked ports be \(b,c,d\), the two special outer ports \(\delta,\epsilon\), and let \(C=\{0,b,c,d\}\) be the common set of *local port names*; the two \(0\)-ports are distinct edges toward the same connector vertex \(u\). Choose distinct outer terminal names
\[
s\in\{\delta,b,c,d\},\qquad t\in\{\epsilon,b,c,d\},\qquad s\ne t,
\]
and distinct \(p,q\in C\setminus\{s,t\}\). Suppose \(A^\circ\) supports the actual pair type \((sp)(sq)\), and \(B^\circ\) supports \((tp)(tq)\). Then the outer relation contains the **loop** \([st]\).

Indeed, permute the six occurrences of each supported shore BF row to the following boundary subsets. A triple entry is written as its missing pair; a singleton entry names its sole port.

| slot | \(A^\circ\) boundary | \(B^\circ\) boundary |
|---|---|---|
| 1 | triple missing \(sp\) | singleton \(p\) |
| 2 | triple missing \(sq\) | singleton \(q\) |
| 3 | singleton \(p\) | triple missing \(tp\) |
| 4 | singleton \(q\) | triple missing \(tq\) |
| 5, 6 | singleton \(s\) in each slot | singleton \(t\) in each slot |

At every shared port the two shore labels are disjoint, because a singleton \(p\) or \(q\) faces a triple that misses it, and \(s\ne t\) in slots \(5,6\). Neither \(s\) nor \(t\) is \(0\), so the labels on the two \(0\)-ports partition slots \(1,\ldots,4\); hence \(R=\{5,6\}\). Put \(D_\delta=\{3,4\}\) and \(D_\epsilon=\{1,2\}\). If \(s=\delta\), then \(X_\delta=\{5,6\}\); otherwise \(X_\delta=\{1,2\}\). If \(t=\epsilon\), then \(Y_\epsilon=\{5,6\}\); otherwise \(Y_\epsilon=\{3,4\}\). Thus these connector labels satisfy [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) full gate in all four cases. In slots \(5,6\), the two selected shore singleton ports are \(s,t\), \(uw\) is selected, and precisely the other three outer terminals are selected. The other four slots must be singleton boundaries: the six slots have ten terminal incidences in total, and each outer matching has a positive odd boundary. The two outer triple occurrences therefore both miss \(st\), proving \([st]\) by six genuine perfect matchings with load two. \(\square\)

For an \(R^*\) shore, write \(c(vr)\in\{P,Q\}\) for the Figure-7 block of the local pair \(vr\). Its type \((vp)(vq)\) is supported exactly when \(c(vp)\ne c(vq)\). Two nonconstant binary colourings of the same finite set \(W\) always separate a common pair: if one colouring partitions \(W\) into two nonempty classes and the other separates no pair across those classes, the latter is constant. Therefore the star-pair rectangle forces \([st]\) whenever both maps
\[
p\longmapsto c_A(sp),\qquad p\longmapsto c_B(tp)
\quad(p\in C\setminus\{s,t\})                         \tag{1}
\]
are nonconstant.

The Figure-7 blocks are \(P=\{13,14,24,35,45\}\) and \(Q=\{12,15,23,25,34\}\). At ports \(1,3,5\), incident edges split \(2+2\) between the blocks. Port \(2\) has its unique minority-colour edge toward \(4\), and port \(4\) has its unique minority-colour edge toward \(3\). Thus the complete directed **minority-arc graph** in each shore is
\[
\boxed{2\longrightarrow4\longrightarrow3.}           \tag{2}
\]
In particular, no four neighbours of a port have one colour. The rectangle with \(s=\delta,t=\epsilon\) uses all four names in \(C\), so it **always** produces \([\delta\epsilon]\). Exact Case XII therefore requires \(\delta\epsilon\notin T\).

## The four other forbidden loops force the fifth

Write the now necessary nonadjacent forbidden pentagon as
\[
\boxed{T=\delta-b-\epsilon-d-c-\delta.}            \tag{3}
\]
The loops \([\delta b],[\delta c],[b\epsilon],[d\epsilon],[cd]\) are all forbidden. Apply (1) to the first four. In the following statements \(v\to w\) means precisely the local minority arc (2), evaluated separately in the \(A^\circ\) and \(B^\circ\) Figure-7 labellings:
\[
\begin{array}{rcl}
[\delta b]\text{ absent}&\Longrightarrow&A:\delta\to b\ \text{ or }\ B:b\to\epsilon,\\
[\delta c]\text{ absent}&\Longrightarrow&A:\delta\to c\ \text{ or }\ B:c\to\epsilon,\\
[b\epsilon]\text{ absent}&\Longrightarrow&A:b\to\delta\ \text{ or }\ B:\epsilon\to b,\\
[d\epsilon]\text{ absent}&\Longrightarrow&A:d\to\delta\ \text{ or }\ B:\epsilon\to d.
\end{array}                                                   \tag{4}
\]
For example, the first line says that at least one colouring in (1), on \(\{0,c,d\}\), must be constant. At \(A\)'s centre \(\delta\), this happens exactly when the excluded neighbour \(b\) is its unique minority neighbour; at \(B\)'s centre \(b\), it happens exactly when the excluded neighbour \(\epsilon\) is its unique minority neighbour. The other lines follow identically.

The directed path (2) has at most one outgoing and one incoming minority arc at any port. To satisfy both of the first two lines of (4), one must use an \(A\)-arc from \(\delta\) to one of \(b,c\) and a \(B\)-arc from the other one to \(\epsilon\). To satisfy both of the last two lines, one must use an \(A\)-arc from one of \(b,d\) into \(\delta\) and a \(B\)-arc from \(\epsilon\) to the other one. Hence \(\delta\) is both the head and tail of minority arcs in \(A\), and \(\epsilon\) is both the head and tail in \(B\). By (2), both special ports have **local label \(4\)**. The \(A\)-arcs are \(4\to3\) and \(2\to4\), and so are the \(B\)-arcs. The required opposite choices in the two pairs \(\{b,c\}\) and \(\{b,d\}\) leave exactly two possibilities:

| case | \(A^\circ\) local labels | \(B^\circ\) local labels | colours from centres \(c_A,d_B\) to \(0,b\) |
|---|---|---|---|
| I | \(\delta=4,b=3,d=2,\ \{c,0\}=\{1,5\}\) | \(\epsilon=4,b=3,c=2,\ \{d,0\}=\{1,5\}\) | \(c_A0=Q,\ c_Ab=P;\ d_B0=Q,\ d_Bb=P\) |
| II | \(\delta=4,c=3,b=2,\ \{d,0\}=\{1,5\}\) | \(\epsilon=4,d=3,b=2,\ \{c,0\}=\{1,5\}\) | \(c_A0=P,\ c_Ab=Q;\ d_B0=P,\ d_Bb=Q\) |

Here \(c_A\) and \(d_B\) in the last column denote the ports named \(c\) on \(A\) and \(d\) on \(B\), not the block-colouring functions. In either case, \(A^\circ\) supports \((c0)(cb)\) and \(B^\circ\) supports \((d0)(db)\), because each pair uses opposite blocks. Apply the star-pair rectangle with \(s=c,t=d,p=0,q=b\). It produces the forbidden outer loop \([cd]\), contradicting (3). Thus two \(R^*\) shores are impossible. \(\square\)

The argument uses only Figure 7's complete **actual** \(R^*\) pair relation, six-slot permutations of supported rows, and Note 172's exact connector. It makes no finite-order inference and no claim that a partial relation or selected matching rows would suffice. The \(|U|=1\) two-five-cut profile is closed; the separate \((4,2,2)\) profile, larger barriers, the connected-core alternatives, and the full exact-Case-XII conjectural closure still require proof or a genuine counterexample.

Equivalently, in [Notes 166 and 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) connected-core, deficiency-two branch, a smallest maximum Tutte barrier with \(|U|=1\), if it exists at all, must have the **\((4,2,2)\)** quotient: one cyclic component carrying the single internal marked edge, two singleton components, and four crossing marked edges. This corollary does not constrain minimum barriers with \(|U|\ge2\) or the branch in which \(F\) has a perfect matching.
