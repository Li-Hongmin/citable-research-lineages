> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An attempted exclusion of the one-vertex two-five-cut barrier

**Correction.** [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) shows that the exclusion claimed below is unproved: the gluing contradictions produce BF covers of the smaller core \(J\), which is BF-covered by minimality, and Proposition 4.4 does not classify its opposite ear shore \(E(B)\). The local ear formulas may still be used within their stated scope. Retain the two-five-cut profile as open.

Assume the minimum-counterexample and exact-Case-XII setting of [Notes 169--172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md). The attempted conclusion was that a smallest deficiency-two Tutte barrier \(U=\{u\}\) cannot have two non-singleton five-cut odd components \(A,B\) and one singleton component \(\{w\}\). [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) identifies the invalid host-identity step. The local ear formulas below remain available; the overall exclusion is **open**.

The proof uses the complete BF relations in [Máčajová--Mazzuoccolo--Tabarelli (2026), Proposition 4.4 and Figures 5--7](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), not selected rows. The [five-edge-cut classification of Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) leaves each shore an acyclic three-vertex tree, an ordinary pentagon \(C_5\), or a cyclic shore of Case-XIII type \(L^*\) or \(R^*\). Here \(L^*\) has every one of the ten loop types and no all-terminal type; \(R^*\) has no loops and has the all-terminal type. A pentagon has five loop types and the all-terminal type. The tree has four loop types, none involving its centre port, and no all-terminal type. The Case-XIII state partition below follows Figure 7; its Appendix transcription has the \(25\)/\(45\) discrepancy identified in [Note 165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md).

## The two-vertex ear attached to a shore

Cut the five host edges leaving \(A\). The other shore of this cut, denoted \(E(B)\), is obtained from \(B\) by attaching the path \(h-u-w-k\) at two distinct ports \(h,k\) of \(B\); its new ports are \(p\) at \(u\) and \(q\) at \(w\). Its other ports \(a,b,c\) are the three edges from \(B\) to \(A\). For the original connector, \(h\) is the unmarked edge toward \(u\), and \(k\) is the marked edge toward \(w\). The labels \(p,q,a,b,c\) are the five edges of the cut around \(A\), not the five outer terminals of the marked pole.

For each \(x\in\{a,b,c\}\), direct restriction of the six matching slots gives
\[
\begin{aligned}
[pq]\in\operatorname{BFsupp}(E(B))&\iff[hk]\in\operatorname{BFsupp}(B),\\
[px]\in\operatorname{BFsupp}(E(B))&\iff[kx]\in\operatorname{BFsupp}(B),\\
[qx]\in\operatorname{BFsupp}(E(B))&\iff[hx]\in\operatorname{BFsupp}(B).
\end{aligned}                                                    \tag{1}
\]
For example, an \([pq]\) row on \(E(B)\) has two triple slots whose boundary is \(\{a,b,c\}\), two singleton-\(p\) slots, and two singleton-\(q\) slots. In the singleton-\(p\) slots the \(B\)-boundary is \(k\), and in the singleton-\(q\) slots it is \(h\). Both original ports already have load two, so the two triple slots restrict to \(B\)-boundary \(\{a,b,c\}\). This is exactly a \([hk]\) row. Conversely, join \(u,w\) through \(uw\) in those two triple slots, put \(p\) opposite the two \(k\)-singleton slots and \(q\) opposite the two \(h\)-singleton slots. The other two equivalences follow by the same forced choices at \(u,w\): in the two triple slots of an \([px]\) row the port \(q\) is selected and \(B\) has boundary \(\{h\}\cup(\{a,b,c\}\setminus\{x\})\), missing \(kx\); the converse again fills the four singleton slots through \(uw\) or the appropriate old port.

If \(B\) has all ten loop types, then \(E(B)\) also has all ten. Equation (1) gives the seven loops involving \(p\) or \(q\). For a loop \([xy]\) with distinct \(x,y\in\{a,b,c\}\), let \(z\) be the third shared port and take a \([xz]\) row on \(B\). Its two triple slots have boundary \(\{h,k,y\}\); make them the two singleton-\(y\) slots of \(E(B)\). Its two singleton-\(z\) slots become the two triple slots of \(E(B)\) by selecting \(p,q\), and its two singleton-\(x\) slots use \(uw\). This gives \([xy]\). Hence
\[
B\text{ has all ten loops}\quad\Longrightarrow\quad
E(B)\text{ has all ten loops}.                              \tag{2}
\]

There is also an all-terminal transfer. If \(B\) supports \((hk)(yz)\) for two of the three shared ports \(y,z\), let \(x\) be the third. Relabel an actual row so that its six \(B\)-boundaries are
\[
\{x,y,z\},\quad\{h,k,x\},\quad\{h\},\quad\{k\},\quad\{y\},\quad\{z\}.
\]
Use \(p,q\) in the first slot, both old ports in the second, \(q\) opposite \(h\), \(p\) opposite \(k\), and \(uw\) opposite \(y,z\). The resulting \(E(B)\)-boundaries are all five ports, then \(x,q,p,y,z\), one singleton of each kind. Thus
\[
(hk)(yz)\in\operatorname{BFsupp}(B)
\quad\Longrightarrow\quad
(p q a b c)\in\operatorname{BFsupp}(E(B)).                 \tag{3}
\]
For the Figure-7 \(L^*\) relation, such a disjoint same-class pair exists **for every choice of \(h,k\)**. With
\[
P=\{13,14,24,35,45\},\qquad Q=\{12,15,23,25,34\},
\]
the supported pairs
\[
(13)(24),\ (13)(45),\ (14)(35),\ (24)(35)
\quad\text{and}\quad
(12)(34),\ (15)(23),\ (25)(34)
\]
contain every state of \(P\cup Q\) as one endpoint and have disjoint terminal pairs. Applying (3) to the pair containing \(hk\) proves
\[
B\text{ has relation }L^*\quad\Longrightarrow\quad
E(B)\text{ has the all-terminal BF type}.                  \tag{4}
\]

If two five-poles on opposite sides of a host five-cut have a common BF type, their actual six-matching rows can be slot-permuted to have the same two-slot labels on all five cut edges. Gluing slot by slot gives a BF cover of the whole host. We use this only for a common loop or the all-terminal type. This glues the original host across a five-cut; it is different from the marked outer-pole connector of Note 172, where an all-terminal shore input cannot participate.

## Invalid attempted elimination of the shore types

The following paragraphs retain the original attempted inference for traceability. Their uses of Proposition 4.4 on \(E(B)\), and of a BF cover or three-edge-colouring of the smaller \(J\) as a contradiction, are invalid by Note 178. Their stated exclusions are not conclusions of this note.

First suppose \(A\) has type \(R^*\). Its five-cut is cycle-separating: \(A\) is cyclic, and \(E(B)\) contains a cycle through \(u,w\) and a path in connected \(B\) between its two attachment ports. Proposition 4.4 applies to the minimum host. Among its thirteen listed shore pairs, the only loop-free relation is Case-XIII \(R^*\); the paired relation must be Case-XIII \(L^*\). In particular, \(E(B)\) must have all ten loops.

Equation (1) rules out a tree \(B\): [Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) puts its centre port at \(h\), and no tree loop contains \(h\), so \([pq]\) is absent from \(E(B)\). It rules out \(R^*\) for the same reason. A pentagon \(B\) is impossible because all ten loops on \(E(B)\) would, by (1), require the four loops \([hk],[ha],[hb],[hc]\) on \(B\), whereas every port has loop degree two in a pentagon relation. The only remaining \(B\) is \(L^*\). But then (4) gives an all-terminal BF row on \(E(B)\), and \(A=R^*\) has the same type. Gluing gives a BF cover of \(J\), contrary to the choice of host. Thus neither shore is \(R^*\).

Now suppose a shore is \(L^*\), say \(B\). Its partner \(A\) is a tree, a pentagon, or \(L^*\), since \(R^*\) has been excluded. Each such \(A\) supports a loop. By (2), \(E(B)\) supports all ten loops, so it shares one with \(A\). Gluing gives a BF cover of \(J\). Thus neither shore is \(L^*\).

Only tree and pentagon shores remain. [Note 169's order identity](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) with [Note 100's existing small-order bound](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) excludes tree--tree and tree--pentagon when \(|U|=1\). [Note 173](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md) gives a direct three-edge-colouring of the host for pentagon--pentagon. Every possibility is excluded. \(\square\)

The valid boundary after Note 178 is that [Note 166's one-vertex quotient classification](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) still leaves both the \((4,2,2)\) profile and the two-five-cut \((4,4,2)\) profile. Their complete perfect-matching closures are undecided.
