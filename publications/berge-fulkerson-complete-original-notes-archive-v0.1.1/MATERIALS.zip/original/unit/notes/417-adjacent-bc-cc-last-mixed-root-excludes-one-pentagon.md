> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last adjacent \(bc,Cc\) mixed root excludes one pentagon orientation

Use the two-spoke prism tree \(AB,BC,Aa,Bb,ac\), with the four marks \(AC,Cc,bc,ab\) and arbitrary six-port shore, as in [Notes 414–416](416-adjacent-bc-cc-indirect-bc-and-ab-roots-are-impossible.md). Suppose the forbidden \(e\)-labels are \(\{bc,Cc\}\). Write
\[
S_\alpha=e-ab-bc-Cc-AC-e,\qquad
S_\beta=e-ab-Cc-bc-AC-e.                                  \tag{1}
\]

> **Last-root exclusion.** No actual six-perfect-matching \((e\,bc)(e\,ab)\) row has forbidden triple \(P=e\,bc:c\) and allowed triple \(R=e\,ab:b\), under either pentagon in (1). Consequently the marked two-spoke-prism exterior cannot have exact Case-XII support with forbidden pair \(\{bc,Cc\}\) and pentagon \(S_\beta\). With \(S_\alpha\), the required mixed cell can only use the unique exterior table of [Note 415, equation (5)](415-the-adjacent-bc-cc-second-direct-root-has-one-real-exterior-boundary.md).

**Proof.** Let \(K\) be singleton-\(ab\), \(J\) singleton-\(bc\), and \(D_0,D_1\) singleton-\(e\). The rooted zero-port tree slots of \(P,R\) are respectively
\[
(B,C,A,b,a),\qquad(A,C,a,B,c)                         \tag{2}
\]
on \((u_1,\ldots,u_5)\). Thus \(P,R\) saturate \(Cu_2\). In \(R\triangle K\), the \(ab\)-starting path must end at \(AC\): endings at \(bc,Cc\) would give a second forbidden triple beside unchanged \(P=e\,bc\).

At \(b\), \(K:bc:b\) would end the path at forbidden \(bc\), so \(K:bu_4\). The path continues through \(B\), where \(K\) takes \(Bu_1\) or \(Bu_2\). If it takes \(Bu_2\), the route reaches \(C\). Taking \(Cc:C\) ends at forbidden \(Cc\); taking \(AC:C\) forces \(c\) onto \(Cc:c\), leaving neither endpoint available for the \(bc\) subdivision because \(b\) is already covered by \(bu_4\). Hence \(K:Bu_1\), and the path reaches \(A\). The \(Au_3\) continuation runs through \(a,u_5,c\) and ends at forbidden \(bc\) or \(Cc\). Therefore \(K:AC:A\), and the complete allowed path is wholly exterior:
\[
ab-t_{ab}-b-u_4-B-u_1-A-t_{AC}-AC.                 \tag{3}
\]
The remaining mark slots give \(K:Cc:C,bc:c\). At \(a\), \(K\) may take \(au_3\) or \(au_5\); neither choice affects (3). Switching it yields \(R'=e\,AC:A\) with exactly the same complete shore matching as \(R\). Both \(R,R'\) take \(cu_5\) and have terminal \(Cc\).

At \(c\), \(P,K\) saturate \(bc:c\), while \(R\) takes \(cu_5\). Since \(J\) has the \(bc\) terminal, \(J\) covers \(c\) through \(cu_5\) or \(Cc:c\). At \(b\), \(P,K\) saturate \(bu_4\), so \(J:ab:b\). At the \(ab\) subdivision, \(P,K\) take the terminal while \(R,J\) take \(ab:b\); hence **both** singleton-\(e\) occurrences take \(ab:a\).

Among \(D_0,D_1\), at least one occurrence \(E\) must take \(Cc:c\). If \(J:cu_5\), both do; if \(J:Cc:c\), one does, because \(R\) already occupies one \(cu_5\) slot and \(bc:c\) is saturated. Since \(E\) takes \(ab:a,Cc:c\), it must also take \(bc:b,AC:C\): the other half of each mark is forced by the vertices already covered at \(a,c\), and \(Cu_2\) is saturated. Thus \(E\) uses port \(p_5\). Against both \(R\) and \(R'\), its \(Cc\)-terminal arm is the same wholly exterior path
\[
Cc-t_{Cc}-c-u_5-p_5.                                \tag{4}
\]
The other two terminal arms use different proper ports of \(E\). For a direct check, \(E\) covers \(A\) by \(Au_1\) or \(Au_3\), and \(B\) by \(Bu_2\) or \(Bu_4\); the remaining arm exits are
\[
\begin{array}{c|cccc}
E:(A,B)&(Au_1,Bu_2)&(Au_1,Bu_4)&(Au_3,Bu_2)&(Au_3,Bu_4)\\\hline
R:(AC,bc)&(p_4,p_3)&(p_2,p_3)&(p_4,p_1)&(p_2,p_1)\\
R':(ab,bc)&(p_3,p_4)&(p_3,p_2)&(p_1,p_4)&(p_2,p_1)
\end{array}
\]
The shore matching of \(R\) is identical to that of \(R'\), so the shore \(e\)-path first reaches the same port \(q\) in both comparisons. It reaches \(Cc\) exactly when \(q=p_5\), in both.

For \(S_\alpha\), the \(e\)-path against \(R=e\,ab\) must end at \(bc\), whereas that against \(R'=e\,AC\) must end at \(Cc\). For \(S_\beta\), the requirements are reversed. Either contradicts (4), proving the last-root exclusion. \(\square\)

The mixed cell \((e\,bc)(e\,ab)\) is required by [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Its four root pairs are now covered by Notes 414–417: \(P:b,R:a\) and \(P:b,R:b\) are excluded for both orientations; \(P:c,R:a\) is excluded for \(S_\beta\) and has only Note 415's real exterior table for \(S_\alpha\); \(P:c,R:b\) is excluded above for both. Therefore \(S_\beta\) is impossible in this marked exterior at every shore order, while \(S_\alpha\), the other three forbidden \(e\)-pairs, other exterior profiles, and the full Berge–Fulkerson conjecture remain open. The argument is hand-derived and awaits independent review.
