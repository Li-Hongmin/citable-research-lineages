> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 111 — 给定五线着色的二和自同构拼接会失败（2026-09-13，脉冲 2/5）

有限命题：任意两份给定的五线着色，沿指定边作二和，总能仅用 Fano 自同构对齐边色并把并集控制在五线以内。

**裁决：假。** 有一个十顶点 simple connected bridgeless cubic graph H，顶点 0,…,9，带色边如下（末位为颜色）：
```
(0,3,7) (0,5,1) (0,6,6) (1,2,2) (1,3,4)
(1,9,6) (2,5,7) (2,9,5) (3,8,3) (4,5,6)
(4,7,5) (4,9,3) (6,7,2) (6,8,4) (7,8,7)
```
恰用 S={167,246,257,347,356}，每条线出现两次。取两份 H，分别割开 e=(0,5)（色 1）与 f=(1,2)（色 2），按端点顺序连接两对半边。

两边所有旧顶点保留，故要使最终线并集至多五，两个五线集合必须相等。对两边同时施自同构，等价于只对右边施一个相对自同构 t；于是必须 t(S)=S 且 t(2)=1。但删去线 123、145 的交点 1 被 S 的稳定子固定，2 不在其点轨道中，矛盾。
完整 168 自同构枚举进一步给出：在 t(2)=1 的约束下，最小并集恰为 6。

这**不是 F5 反例，也不是 R1 的 NOGO**。H 沿以上边顺序有 Tait 证书
`1 2 3 2 3 1 1 3 2 3 1 2 2 1 3`，所得二和可重新着为一条 Fano 线。

证据：`computations/fano-r1-20260913/graph.json` 与 `check_graph.py`。生成器随机配对同色端点；独立校验器不导入生成器、不使用 NetworkX，直接逐边删除检查连通性，逐顶点检查两种着色，并用 7! incidence 置换穷尽自同构，最后直接验证二和的重新着色。命令：`python3 computations/fano-r1-20260913/check_graph.py`。
最薄弱一步：给定着色反例不能替代对全部着色的量化。
下一命题：同样的固定着色障碍能否发生于非平凡三和？
