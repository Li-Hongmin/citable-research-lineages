> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A doubled singleton and two retained masks complete the changed-zero row

Continue the class-IV \(D_2\) shore of [Notes 481--483](483-fixed-zero-class-iv-two-mask-closure-is-path-or-disjointness.md). The old six complete shore matchings are \(Q_P,Q_R,Q_a,Q_b,Q_J,Q_K\), with \(P,R\) zero-port, and the only forbidden old-signature exteriors are the uniquely doubled \(t=0\) loop \([eY]\) and \(t=2\) loop \([eX]\) of Note 481. The remaining allocation with **two** new complete shore-matching occurrences changes one zero mask and one singleton mask. It too has an exact shore criterion.

## Two retained masks beside a doubled matching

Let \(H\) be a cubic shore with port set \(\mathcal P\). Let \(W,S,B\) be complete perfect matchings with
\[
   \partial S=\varnothing,\qquad
   \partial B=\mathcal P\setminus\partial W.              \tag{1}
\]
There exist complete matchings \(S',B'\), with \(\partial S'=\varnothing\) and \(\partial B'=\partial B\), such that
\[
 2\mathbf1_W+\mathbf1_S+\mathbf1_B+\mathbf1_{S'}
                 +\mathbf1_{B'}=2\mathbf1_{E(H)}          \tag{2}
\]
**if and only if**
\[
                    W\cap(S\cup B)=\varnothing.           \tag{3}
\]
The condition is edgewise on the whole shore.

If (2) holds, a \(W\)-edge already has load two and cannot belong to \(S\) or \(B\), proving necessity. Conversely, under (3), both \(S\) and \(B\) are perfect matchings of the degree-two complement \(H-W\). Its nonclosed components are port-to-port paths with both endpoints outside \(\partial W\). On each such path, \(S\) avoids both port semiedges while \(B\) uses both, so the two matchings occupy opposite alternating phases and partition the path edges. Set \(S'=S,B'=B\) there. Every closed component is even, since \(S\) matches it. If \(S,B\) have opposite phases on a closed cycle, also set \(S'=S,B'=B\) there. If they have the same phase, put **both** \(S',B'\) on the other phase. All assignments are whole-component matchings, preserve the port boundaries in (1), and satisfy (2) on every edge. \(\square\)

If \(H-S\) has an odd closed component, then \(W,S,B\) cannot partition \(E(H)\): otherwise \(H-S=W\cup B\) would alternate two perfect matchings on every closed component. Hence \(S\) and \(B\) share at least one edge on a closed component of \(H-W\), and the constructed \(S',B'\) both differ from their retained counterparts. They are thus two new occurrences unless \(S'\) coincides with another old zero mask. In that exceptional case (2) is already a forbidden row with at most one new occurrence.

## Eight changed-zero gates

At \(t=0\), the old singleton masks with complementary port sets are \(Q_b,Q_J\). At \(t=2\), they are \(Q_a,Q_K\). For either class choose which mask \(W\) is repeated, put the other in the retained slot \(B\), and choose \(S\) to be \(Q_P\) or \(Q_R\). These are eight choices. In every choice, (3) is **necessary and sufficient** for the corresponding forbidden full BF loop: use (2) on the shore and Note 481(2) or (3) on the exterior. Consequently, an exact-Case-XII class-IV row in this fixed exterior must obey
\[
\begin{array}{ll}
 Q_b\cap(Q_J\cup Q_S)\ne\varnothing,&
 Q_J\cap(Q_b\cup Q_S)\ne\varnothing,\\
 Q_a\cap(Q_K\cup Q_S)\ne\varnothing,&
 Q_K\cap(Q_a\cup Q_S)\ne\varnothing,
\end{array}
\qquad S=P,R.                                           \tag{4}
\]
These eight tests use complete masks and include old-mask overlaps that port signatures cannot detect.

Together with Notes 481--483, this exhausts **all** forbidden rows using only old port signatures and at most two new complete shore-matching occurrences, under the exact-Case-XII odd-zero premise. With zero new occurrences, Note 480 applies; with one, the four gates of Note 481(4) apply. With two, the allocations are:

| New zero masks | New singleton masks | Exact gate |
|---:|---:|---|
| 0 | 2, one in each singleton role | \(p_1p_3\) path in Note 482(2) or (3) |
| 0 | 2, both in one singleton role | disjointness in Note 483(2) |
| 1 | 1 | one of the eight disjointness tests (3)--(4) |
| 2 | 0 | impossible: the two old singleton masks would each repeat and force the zero masks to coincide |

The fixed-zero rows of Note 483 and the changed-zero rows here may produce fewer than two genuinely new masks when an old mask happens to reappear; Note 481's zero- and one-new gates already cover those degeneracies. Thus, **if** all one-new, path, fixed-zero disjointness, and changed-zero disjointness gates fail, every forbidden old-signature row must use at least three new complete shore-matching occurrences. This threshold is attained by the real Petersen-substituted 29-vertex pole of Note 481: it satisfies the odd-zero premise and has old-signature forbidden loops with exactly three new masks. It is not exact Case XII because of its cyclic three-edge cut and forbidden support.

The classification does not control three-or-more-mask rows or new port signatures, and it does not derive any gate from the other positive Case-XII cells. Those remain the full-closure burden. The proof is hand-derived without OMEN or local mathematical recomputation and awaits independent review. \(\square\)

Odd-zero correction: [Note 485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md) proves that repeating a complete singleton matching in either surviving forbidden exterior forces a forbidden Tait state and hence a clean zero-port shore matching. Under the odd-zero premise already assumed for exact Case XII, the eight disjointness gates (3)--(4) here and the four fixed-zero gates of Note 483 are automatically false. Among rows using at most two new complete shore masks, only Note 482's \(p_1p_3\) paired-singleton path gate remains substantive.
