> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-edge bipartization: matching profiles and Tait blockers

The adjacent-edge exclusion in
[Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md)
leaves disjoint two-edge odd-cycle transversals. Their matching profiles
split according to whether both exceptional edges lie on one side of
the resulting bipartition or one lies on each side. The first case has
an allowed \(S\)-Tait branch and a separated-odd-components branch;
the second has a fixed minority singleton class and exact Tait blockers
for its \(T\)-boundary triples. This is a conditional classification,
not an existence claim for exact Case XII.

## Both exceptional edges on the same side

Let \(H\) have all twenty-five \(S\)--\(T\) BF types and no
\(T\)-loop. Suppose \(F=\{e,f\}\) consists of disjoint proper edges,
\(H-F\) is bipartite with parts \(X,Y\), and both \(e,f\) join vertices
of \(X\). Such edges must be disjoint by Note 126. For any perfect
matching \(P\), write \(z(P)=|P\cap F|\), and let \(a_X(P),a_Y(P)\)
count its terminal semiedges on the two sides. Counting proper-edge
ends and then vertices covered by a perfect matching gives
\[
3|X|-t_X-4=3|Y|-t_Y,
\qquad a_X(P)-a_Y(P)=|X|-|Y|-2z(P).                 \tag{1}
\]
Since \(t_X+t_Y=5\), exactly two terminal distributions remain:
\[
(t_X,t_Y,|X|-|Y|)=(2,3,1)
\quad\text{or}\quad(5,0,3).                            \tag{2}
\]

**The \(2+3\) branch.** Let \(p\) be the pair of the two \(X\)-side
terminal positions. Positive \(S\)--\(T\) support supplies an actual
triple-boundary matching \(Q\) missing \(p\). It uses all three
\(Y\)-side semiedges, so (1) gives \(-3=1-2z(Q)\) and hence
\(z(Q)=2\). Thus \(Q\) uses both exceptional edges. The proper edges of
\(H-Q\) lie in the bipartite graph \(H-F\); its closed components are
even cycles, and its two unused semiedges lie on \(X\), so its sole
terminal path is even. Alternating the complement extends \(Q\) to a
Tait colouring with state \(p\). If \(p\in T\), doubling this colouring
would give a forbidden \(T\)-loop. Therefore
\[
\boxed{p\in S\text{ and }p\text{ is an actual Tait state}.} \tag{3}
\]
Under the full exact-Case-XII exclusions, the Tait-state dichotomy of
[Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md)
then makes the whole Tait set equal to \(S\). Equation (3) does not
force the common-\(B,C\) seed.

**The \(5+0\) branch.** All five semiedges lie on \(X\). Equation (1)
shows that every singleton-boundary matching uses exactly one of
\(e,f\), while every triple-boundary matching avoids both; no
all-terminal matching exists. For a triple matching \(Q\), the
complement \(H-Q\) contains both exceptional edges. Every component
of its proper graph uses zero, one, or two of them, and every other
proper edge crosses the bipartition. Consequently a closed component
is odd exactly when it contains one exceptional edge. There is only one
terminal-path component. Hence
\[
\boxed{
Q\text{ extends to a Tait colouring}
\iff e,f\text{ lie in the same component of }H-Q.} \tag{4}
\]
Indeed, in the same-component case every closed component uses zero or
two exceptional edges and is even; the terminal path is also even by
the odd-order parity argument in Note 125. In the different-component
case, at least one exceptional edge lies in a closed component by
uniqueness of the terminal path, making that cycle odd.

For every actual triple matching \(Q\) whose missing pair lies in
\(T\), absence of a \(T\)-loop and (4) force \(e,f\) into **different**
components of \(H-Q\). This is a condition on every matching in the
complete PM family, not only a chosen BF row.

There is a small but genuine full-family flexibility consequence. Exact
Case XII has distinct terminal vertices by [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md),
so [Note 086](086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md)
proves that a proper edge can be fixed in at most one singleton class.
Since each singleton matching in the \(5+0\) branch uses exactly one of
\(e,f\), at most one singleton class is fixed to \(e\) and at most one
is fixed to \(f\). Hence at least three of the five singleton classes
contain actual matchings of **both** exceptional-edge profiles. The
\(S\)-pentagon has independence number two, so two such flexible classes
form an \(S\)-pair. After a dihedral relabelling, they can be the
\(B,C\) classes \(2,4\) in Note 118. This guarantees both edge-bit
choices in the complete singleton classes; it does not guarantee that
either choice lies in the required left or right BF-row fibre, nor that
the full pair-load vectors intersect.

[Note 168](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md)
sharpens this under full exact-Case-XII support: **all five** singleton
classes have both exceptional-edge profiles. Its proof uses the fixed-carrier
pentagon switch of Note 133 in a positive \(S\)--\(T\) row with a repeated
singleton class. It still does not synchronize complete masks across rows.

## One exceptional edge on each side

Suppose instead that \(e\) joins two vertices of \(X\) and \(f\) joins
two vertices of \(Y\). Swapping the parts and edge names if needed, the
terminal distribution is \(t_X=4,t_Y=1\), with \(|X|-|Y|=1\). Denote
the sole \(Y\)-side terminal position by \(y\). For a perfect matching
\(P\), write \(x(P)=\mathbf1_{e\in P}\) and
\(w(P)=\mathbf1_{f\in P}\). The exact balance is
\[
a_X(P)-a_Y(P)=1-2x(P)+2w(P).                    \tag{5}
\]
It gives the following complete boundary-profile table; \(XX\) means
a pair of terminal positions both in \(X\), and \(Xy\) a pair
containing \(y\).

| Matching boundary | Exceptional-edge profile \((x,w)\) |
|---|---|
| singleton at \(y\) | \((1,0)\) |
| singleton at \(X\) | \((0,0)\) or \((1,1)\) |
| triple missing \(XX\) | \((0,0)\) or \((1,1)\) |
| triple missing \(Xy\) | \((0,1)\) |
| all five terminals | \((0,1)\) |

For a triple matching \(Q\) missing \(Xy\), its complement contains
\(e\) and avoids \(f\). The only possible odd closed component of
\(H-Q\) is the one containing \(e\). If \(e\) lies on the terminal
path, that path has an even number of proper edges: it runs from an
\(X\)-terminal to the \(Y\)-terminal, so it has an odd number of
cross edges and one internal \(X\)-edge. Hence \(Q\) extends to a Tait
colouring exactly when \(e\) lies on the terminal path. For a triple
matching missing \(XX\) with profile \((1,1)\), the complement is
bipartite and the two unused semiedges are both on \(X\), so it always
extends to a Tait colouring. If its profile is \((0,0)\), the
same-component test of (4) applies to \(e,f\), now one internal to each
part: a component with both is even, and a closed component with one
is odd. Consequently the absence of \(T\)-loops forces
\[
\begin{array}{ll}
t=Xy\in T:&e\text{ lies on an odd closed component of }H-Q,\\
t=XX\in T:&(x(Q),w(Q))=(0,0)
\text{ and }e,f\text{ lie in different components of }H-Q.
\end{array}                                                 \tag{6}
\]
These are conditions on **every** actual triple matching with the
indicated \(T\) boundary.

Every singleton matching in class \(y\) uses \(e\) and avoids \(f\).
Under full exact-forty support, the terminal vertices are distinct by
Note 123, and because \(e\) is fixed in class \(y\), Note 086's
class-exclusivity theorem ensures that each of the other four singleton
classes has an actual matching avoiding \(e\). By the table, each such
matching also avoids \(f\). This is complete-PM-family flexibility, but
it does not place those avoiding masks inside a specified BF-row fibre.

## One-cycle profile switch

Let \(P,P'\) be any two actual perfect matchings of the **same terminal
boundary** in either branch, and suppose their distinguished-edge bits
differ at both \(e\) and \(f\). Every component of
\(P\triangle P'\) is a proper even alternating cycle. A cycle that
uses exactly one of \(e,f\) would be odd: every other edge crosses the
bipartition, while the one exceptional edge stays within a part.
Therefore \(e,f\) lie on the **same** component \(C\) of
\(P\triangle P'\). Toggling just \(C\) in \(P\) gives another actual
matching of the same terminal boundary and already changes both
distinguished-edge bits to those of \(P'\).

Thus the flexible singleton classes above have a genuine one-cycle
route between their two exceptional-edge profiles. Applying that
switch inside a **fixed BF row** still requires a companion matching
with the opposite phase on every edge of \(C\), exactly the alignment
condition of [Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).
The two-edge parity argument alone does not supply that companion.

There is an exact candidate count in the mixed-side branch. Consider
a BF row whose two missing-pair labels are one \(Xy\) and one \(XX\).
Its singleton occurrences consist of one class-\(y\) matching and
three \(X\)-side matchings, counting repetitions. The cross triple has
profile \((0,1)\), and the class-\(y\) singleton has \((1,0)\).
Because the row loads both \(e,f\) twice, **exactly one** occurrence
among the \(XX\) triple and the three \(X\)-singletons has profile
\((1,1)\); the other three have \((0,0)\). If the \(XX\) label lies
in \(T\), equation (6) forces that triple to \((0,0)\), so the unique
\((1,1)\) occurrence is a singleton. For a different \((0,0)\)
singleton to switch to profile \((1,1)\) within this fixed row, this
unique singleton is the only possible paired-switch companion at
\(e,f\). Whether it aligns on the whole alternating cycle is the
remaining condition.

Neither the same-side \(5+0\) branch nor the mixed-side branch is
excluded. Their interaction with the pair-load spectra
\(\Lambda_L,\Lambda_R\) of
[Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md)
remains undecided.

[Note 128](128-mixed-side-unique-companion-can-fail-the-full-cycle-phase.md)
sharpens the last paragraph's companion question. For a \((0,0)\)
singleton \(P\) and the unique \((1,1)\) singleton \(N\), a fixed-pair-load
profile transfer exists exactly when \(e,f\) lie on a **closed** component
of \(P\triangle N\); if they lie on its terminal path, no matching in
that pair-load fibre can transfer their profile while retaining the two
singleton boundaries. An actual seven-vertex pole has the latter case,
an independently existing same-boundary target, and no aligned row
companion. It has forbidden \(T\)-support, so this does not decide exact
Case XII.
