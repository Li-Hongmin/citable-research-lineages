> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right \(AJ\) bridge forces an \(a,d,e\) triple hit at \(I\)

> **Scope correction:** [Note 230, (1)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) already forbids every all-terminal perfect matching in this deficient-core profile. The triple-hit calculation below distinguishes specific matching identities but cannot by itself exclude exact Case XII. [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) also excludes the no-\(c\) row from which this \(AJ\) bridge was constructed.

Continue the actual right \((ea)(eb)\) row and its six-cycle switch in [Notes 347 and 350](350-the-right-bridge-third-identity-is-an-aj-shore-fibre.md). For each zero-port phase, let
\[
 P=X_C+Y_R+Z'_e,\qquad B=U_C+V_e+W'_b=2\mathbf1-P,
 \qquad \widetilde P=X_C+Y_R+V_e .                    \tag{1}
\]
Here \(Z'\) has III \(a:\Sigma,1B,2C\), \(V\) has III \(a:\Sigma,2B,3C\), and \(P\) has the unit exterior vector. Suppose the third-identity gate of [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md) succeeds: a complete singleton-\(c\) matching \(C_c\) from \(U_C\triangle Z'\) belongs to a \(dc\)-decomposition of \(P\). Its opposite \(eb\)-half is the displayed \(B\). The cross-carrier \((ea)(bc)\) row uses the other pure load \(\widetilde P\), an \(ea\)-decomposition of it **retaining \(V_e\)** (the displayed \(X_C+Y_R+V_e\) is one), and the \(bc\)-decomposition obtained from \(U_C+Z'+W'\). The two rows share \(C_c,W'_b,V_e\).

**Forced triple-hit theorem.** In **every** such pair of rows, whatever \(ea\)-decomposition of \(\widetilde P\) retaining \(V_e\) and whatever \(dc\)-decomposition of \(P\) retaining \(C_c\) are chosen, their five complete singleton matchings load the proper shore port edge \(I=h_1\) three times, with class signature
\[
                         \{a,d,e\}.                      \tag{2}
\]
Thus this particular two-carrier, three-identity join never yields an all-terminal \(A=(abcde)\) BF cover by the five-singleton load-one completion. It remains a genuine pair of allowed Case-XII rows; the three uses in (2) belong to matchings from **different** carrier pairs.

**Proof.** By [Note 350, (2)–(3)](350-the-right-bridge-third-identity-is-an-aj-shore-fibre.md), \(C_c\) has ports \(A,J\), and the residual \(P-C_c\) has exterior terminal arms \(a\to H,b\to I,d\to D,e\to E\). By [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md), its even open path joins \(d\) to \(e\), while its odd open path joins \(a\) to \(b\). In a \(dc\)-decomposition retaining \(C_c\), the residual singleton-\(d\) colour starts at terminal \(d\); the \(a\)- and \(b\)-terminal semiedges have the triple colour. Along the exterior \(b\to I\) arm, the edge colours therefore alternate as
\[
 b_{\rm term}:\mathrm{triple},\ b:D:\mathrm{single},\ 4D:\mathrm{triple},\
 4E:\mathrm{single},\ c:E:\mathrm{triple},\ c:A:\mathrm{single},\
 1A:\mathrm{triple},\ h_1:\mathrm{single}.             \tag{3}
\]
So every resulting singleton-\(d\) matching selects \(h_1\), independently of closed residual-cycle phases. In fact its full exterior mask is forced to be
\[
 D_d|_{\rm ext}=\{a:C,b:D,c:A,2B,4E,h_1,h_3;\ d\}.  \tag{4}
\]

Meanwhile, \(\widetilde P\) has shore-port load two at \(I\): the two displayed singleton-\(e\) and singleton-\(a\) matchings \(V_e,Y_R\) both use \(h_1\), while \(X_C\) is zero-port. In **any** \(ea\)-decomposition of the same \(\widetilde P\), the triple matching also has zero shore ports by [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), since its boundary excludes \(e\). Therefore its singleton-\(a\) and singleton-\(e\) matchings must both use \(h_1\), regardless of which complete identities realize that decomposition. In the cross-carrier join, the singleton-\(e\) identity is specifically \(V_e\). The singleton-\(b\) matching \(W'_b\) uses ports \(D,H\), and \(C_c\) uses \(A,J\), so neither uses \(h_1\). Together with the singleton-\(d\) conclusion this proves the exact three-hit signature (2). \(\square\)

The conclusion concerns the **specified** two carrier pairs and the shared \(C_c,W'_b,V_e\) identities. [Note 352](352-every-singleton-a-matching-hits-the-right-bridge-d-e-pair.md) strengthens it: every singleton-\(a\) matching of the entire pole uses \(b:D\) or \(I\), and both edges lie in the displayed \(D_d\cap V_e\). Hence **no** choice of \(a,b,c\) singleton identities can complete these same \(D_d,V_e\) identities to an all-terminal cover. A different \(d\)- or \(e\)-matching identity is necessary; this does not disprove exact Case XII or Berge–Fulkerson.
