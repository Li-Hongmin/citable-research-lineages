> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nineteen-vertex diamond has two open Tait routes through the chord-side edge

The two state-\(35\) Tait completions of [Note 149](149-both-singleton-phases-of-a-short-diamond-have-state-thirtyfive-tait-completions.md) do not, by themselves, force a chord-side \(ZY\) edge of [Note 153](153-two-proper-common-arm-exits-and-a-neutral-three-hit-cubic-gadget.md) onto a closed singleton-\(3\)/singleton-\(5\) alternating component. The genuine cubic five-pole below has an aligned \((2,2,1,1)\) six-edge diamond, a five-edge chord, \(J'=5\), the canonical \(5\to4\) and \(2\to3\) switches, and the required \((1\,2)(4\,5)\) pairing of \(r_{34}\triangle C_4\). Yet both Tait completions have a **spanning open \(3\leftrightarrow5\) path** through the same chord-side edge. This is a complete-mask counterexample to the proposed *local two-Tait closed-cycle gate*, not an exact-Case-XII counterexample: an explicit forbidden state-\(23\) Tait colouring occurs. The edgewise construction is analytic and awaits independent checking; no finite search or full-PM enumeration is claimed.

## The cubic five-pole and its six actual matchings

Use vertices \(v_0,\ldots,v_5,x_1,\ldots,x_4,a,b,j,t_1,t_2,t_3,u,v,k\). The five semiedges \(s_i\) meet \(t_i\) for \(i=1,2,3\), \(b\) for \(i=4\), and \(v_0\) for \(i=5\). Specify every proper edge and semiedge by its two owners in a six-matching BF row:

| Owners | Proper edges | Semiedges |
|---|---|---|
| \(UZ\) | \(v_0v_1\) | |
| \(rY\) | \(v_1v_2\) | |
| \(ZC\) | \(v_2v_3\) | |
| \(YD\) | \(v_3v_4\) | |
| \(rZ\) | \(v_4v_5\) | |
| \(YC\) | \(v_5v_0\) | |
| \(UD\) | \(v_2x_1,\ x_2x_3,\ x_4v_5\) | |
| \(rC\) | \(x_1x_2,\ x_3x_4\) | |
| \(UC\) | \(v_4a,\ t_3u,\ vk\) | \(s_4\) |
| \(Dr\) | \(ab,\ uv,\ kt_3\) | \(s_5\) |
| \(Ur\) | \(v_3j\) | \(s_1,s_2\) |
| \(DC\) | \(v_1t_2,\ jt_1\) | |
| \(ZY\) | \(t_2x_2,\ x_3a,\ x_1u,\ x_4j,\ bv,\ t_1k\) | \(s_3\) |

Every vertex has degree three. At each vertex its three incident owner pairs partition \(\{U,Z,D,r,Y,C\}\): the chord interiors have \((UD,rC,ZY)\), the terminal-arm and square vertices have \((UC,Dr,ZY)\), and \(j,t_1,t_2\) have \((Ur,DC,ZY)\); the six core vertices have the indicated complementary triples. Thus each owner is a **complete actual perfect matching**, and every edge has load two in
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.       \tag{1}
\]
The semiedge row proves the subscripts. The graph is simple and connected, with nineteen vertices and twenty-six proper edges. The proper four-cycle \(t_3uvkt_3\) and the forbidden support exhibited below keep this example outside the minimum exact-Case-XII setting.

The hexagon \(\Omega=v_0v_1v_2v_3v_4v_5v_0\) has owner sequence \((UZ,rY,ZC,YD,rZ,YC)\), exactly Note 146's \((2,2,1,1)\) pattern. Its chord is \(v_2x_1x_2x_3x_4v_5\), with successive owners \((UD,rC,UD,rC,UD)\). All edges outside this theta core are split between the \(U,Z,D\) and \(r,Y,C\) halves. The four original junctions are \(v_0,v_2,v_4,v_5\).

## The aligned right row and its forced paths

The actual complete carrier decomposition \(q_{25}+B_2=U_{35}+Z_3\) is
\[
\begin{aligned}
q_{25}&=\{v_0v_1,v_2v_3,v_4v_5,x_1u,t_2x_2,x_3a,x_4j,vk,s_1,s_3,s_4\},\\
B_2&=\{v_0v_1,v_2x_1,x_2x_3,x_4v_5,v_3j,v_4a,bv,t_1k,t_3u,s_2\}.
\end{aligned}                                             \tag{2}
\]
They agree with \(Z,U\), respectively, at every vertex of \(\Omega\) and at each chord interior vertex. Substituting (2) into (1) gives the actual right BF row. Its four junctions on \(\Omega\) are \(v_1,v_2,v_3,v_5\); the only exterior one is \(t_1\), so \(J'=5\).

The two canonical switches use the following **complete open components**, written from semiedge to semiedge:
\[
\begin{aligned}
P_{54}\subset q\triangle D&:\quad
s_5,v_0,v_1,t_2,x_2,x_3,a,b,s_4,\\
P_{23}\subset q\triangle r&:\quad
s_2,t_2,x_2,x_1,u,v,k,t_3,s_3.
\end{aligned}                                             \tag{3}
\]
In particular \(P_{54}\) avoids \(v_4\), \(P_{23}\) joins \(2\) to \(3\), and the proper chord-side edge
\[
z=t_2x_2\in P_{54}\cap P_{23},\qquad
q(z)=\widehat C(z)=Z(z)=Y(z)=1,quad
p(z)=0,                                                   \tag{4}
\]
where \(\widehat C=D\triangle E(P_{54})\) and \(p=q\triangle E(P_{23})\). The paired chord-side exit of Note 153 is \(x_3a\); the internal \(UD\) chord edge between them is \(x_2x_3\).

The two open components of \(r\triangle C\) are
\[
s_4,b,a,v_4,v_5,v_0,s_5,
\qquad
s_2,t_2,v_1,v_2,v_3,j,t_1,s_1,                       \tag{5}
\]
so its pairing is \((1\,2)(4\,5)\), and \(v_2v_3\) lies on the \(1\leftrightarrow2\) path as required by Note 152's strand trace. The distinguished \(C\triangle\widehat C\) component through \(h=v_4a\) is the actual twelve-cycle
\[
v_4,a,x_3,x_4,v_5,v_0,v_1,t_2,x_2,x_1,v_2,v_3,v_4.   \tag{6}
\]
Its four contacts with \(r\triangle C\) are the \(C\)-edges \(v_4a,v_5v_0,v_1t_2,v_2v_3\), two on each open path. No no-seed conclusion is asserted for this pole.

## Both Tait routes through \(z\) are open

Put \(K_o=(v_2v_1v_0v_5)\cup\chi\) and \(K_s=(v_2v_3v_4v_5)\cup\chi\), where \(\chi\) is the five-edge chord. They are the two eight-cycles of Note 149. Its two actual state-\(35\) Tait colourings in this owner pattern are
\[
(U^{K_o}_{35},Z_3,D_5),\qquad
(U_{35},Z^{\Omega}_3,D^{K_s}_5).                    \tag{7}
\]
In each colouring the singleton-\(3\) and singleton-\(5\) colours are disjoint. Their differences are, respectively, the following **spanning open paths**:
\[
\begin{aligned}
Z\triangle D:\quad
&s_5,v_0,v_1,t_2,x_2,x_3,a,b,v,u,x_1,v_2,v_3,v_4,v_5,x_4,j,t_1,k,t_3,s_3,\\
Z^{\Omega}\triangle D^{K_s}:\quad
&s_5,v_0,v_5,v_4,v_3,v_2,v_1,t_2,x_2,x_1,u,v,b,a,x_3,x_4,j,t_1,k,t_3,s_3.
\end{aligned}                                             \tag{8}
\]
Every consecutive pair in (8) is an edge from the table; each sequence visits all nineteen vertices once, alternates between its two named colours, and contains \(z=t_2x_2\). Therefore \(z\) is on the \(3\leftrightarrow5\) **open** component in both Tait completions. Neither completion has a closed \(3/5\) component to switch. The proposed local two-Tait closed-cycle gate is false even with the actual aligned row, \(J'=5\), and the three selected terminal pairings (3)--(5).

This does not refute a statement using **complete exact-Case-XII support**. In the first Tait colouring of (7), the \(5\)-terminal component of \(U^{K_o}\triangle D\) is
\[
s_5,v_0,v_5,x_4,x_3,x_2,x_1,v_2,v_1,t_2,s_2.        \tag{9}
\]
Switching the two Tait colours on (9) yields an actual state-\(23\) Tait colouring, forbidden by exact Case XII. Thus full negative support excludes this graph by a concrete complete-matching certificate; the two Tait completions and selected path gates alone do not. Whether that negative support forces a closed route through \(z\), a common complete \(B_2+C_4\) seed, or another global exit remains open.
