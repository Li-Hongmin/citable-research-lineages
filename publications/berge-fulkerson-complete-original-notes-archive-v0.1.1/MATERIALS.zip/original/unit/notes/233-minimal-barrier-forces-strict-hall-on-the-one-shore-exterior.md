> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A minimum barrier forces strict Hall on the one-shore exterior

Work in [Note 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) connected, deficient unmarked-core setting. Let \(U\) be a **minimum-cardinality maximum Tutte barrier**, \(|U|=k\), in its profile with one non-singleton odd component \(C\) of \(F-U\), one internal marked edge \(e\subset C\), and \(k+1\) singleton odd components \(W\). Thus \(F[U]\) is edgeless, no marked edge meets \(U\), and \(\operatorname{def}(F)=2\). Let \(K=F[U,W]\) be the bipartite graph of unmarked exterior edges.

**Strict-Hall theorem.** For every nonempty \(A\subseteq U\),
\[
\boxed{|N_K(A)|\ge |A|+1.}                              \tag{1}
\]
Consequently, for **every** \(w\in W\), the graph \(K-w\) has a perfect matching. In the notation of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), its exposable-singleton set is exactly
\[
\boxed{D=W,\qquad |D|=k+1.}                              \tag{2}
\]
This holds regardless of the order or cycle rank of \(C\).

**Proof.** Complete exact Case-XII support supplies a triple-boundary perfect matching in any missing-pair state \(ej\), \(j\ne e\). By [Note 230, (1)--(4)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), it uses no proper edge of the five-cut around \(C\). Its exterior restriction matches every vertex of \(U\) to a distinct vertex of \(W\), leaving one \(w\) exposed for mark \(j\). Hence \(K\) has a matching saturating \(U\), and Hall's inequality gives \(|N_K(A)|\ge |A|\) for all \(A\subseteq U\).

Suppose equality holds for some nonempty \(A\). Choose such an \(A\) inclusion-minimal and put \(t=|A|=|N_K(A)|\). The graph induced by \(A\cup N_K(A)\) in \(K\) is connected: otherwise each of its connected pieces with \(U\)-part \(A_i\) has neighbour set \(N_K(A_i)\), Hall gives \(|N_K(A_i)|\ge|A_i|\), and summing forces equality in a proper nonempty \(A_i\), contrary to the choice of \(A\).

Remove \(A\) from the barrier, forming \(U'=U\setminus A\). In \(F-U'\), the connected set \(A\cup N_K(A)\) has \(2t\) vertices. Since \(N_K(A)\) lists *all* \(F\)-neighbours of \(A\) among singleton components and \(F[U]\) is edgeless, this set can join no other singleton component. If no vertex of \(A\) meets \(C\), it becomes one even component in place of the \(t\) singleton odd components \(N_K(A)\). If \(A\) meets \(C\), it joins \(C\) and becomes one odd component of order \(|C|+2t\), in place of \(C\) and those \(t\) singletons. Either way the number of odd components is
\[
q(F-U')=q(F-U)-t=(k+2)-t=|U'|+2.                         \tag{3}
\]
Thus \(U'\) is another maximum Tutte barrier of deficiency two, smaller than \(U\). This contradicts the choice of \(U\), proving (1).

For any \(w\in W\), deleting \(w\) lowers every neighbourhood size by at most one. Equation (1) gives \(|N_{K-w}(A)|\ge|A|\) for all \(A\subseteq U\). Hall's theorem therefore gives a matching saturating \(U\) in \(K-w\); since both sides have \(k\) vertices, it is a perfect matching. This is (2). \(\square\)

**Full-matching consequence.** Fix any zero-port shore matching \(Q\in\mathcal Z_0\) from Note 230. For each exterior mark \(j\ne e\) and **each chosen endpoint** \(w\in W\) of that mark, a perfect matching of \(K-w\) combines with \(Q\), the half-edge \(t_jw\), and the other three terminal semiedges to give an actual state-\(ej\) triple matching. If two marks \(j,\ell\) share an endpoint \(w\), choose the same matching of \(K-w\) for both. Their complete masks then differ only along the exterior alternating terminal path
\[
s_j-t_j-w-t_\ell-s_\ell.
\]
For distinct chosen endpoints \(w,w'\), the symmetric difference of two \(K\)-matchings exposing them consists of one alternating \(w\)--\(w'\) path and even cycles; flipping those cycles in one matching leaves a single exterior terminal \(j\)--\(\ell\) path, with the shore mask still equal to \(Q\). Thus every choice of exposed endpoint admitted by a marked edge can be routed at the single-matching level.

Equation (2) strengthens Note 230's \(|D|\ge2\) to **all** \(k+1\) singleton shores. It removes Hall exposure as a possible obstruction in the four \(ej\)-triple fibres. It does not put the resulting triples in one BF row, prescribe the four singleton masks, or settle the six-port phase condition of Note 230, (5). After [Note 232](232-the-two-vertex-one-five-cut-barrier-cannot-have-exact-case-xii-support.md), an exact-Case-XII pole in this profile would have \(k\ge3\), hence at least four independently exposable singleton shores.
