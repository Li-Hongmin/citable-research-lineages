> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The second Hamilton three-spoke signature forces a forbidden row

Continue [Notes 446–447](447-the-first-hamilton-three-spoke-signature-forces-a-forbidden-loop.md) for the Hamilton three-spoke exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36).
\]
Name a genuine \((eX)(eY)\) BF row's six **complete** matching occurrences \(P=eX,R=eY,K=Y,J=X,E=e,F=e\), and put \(\Lambda=\{J,E,F\}\). Assume the second line of Note 446(3): \(P=eX:4\), \(R=eY:1\), while \(K\) uses \(X:4,Z:2,W:6,1u_1,5u_5\) and one of \(3u_2,3u_3\).

**Claim.** Every such row can be recompleted, retaining each occurrence's entire shore matching, into a forbidden \((eX)(eW)\) row if \(K\) uses \(3u_2\), or a forbidden \([eX]\) loop if \(K\) uses \(3u_3\). This all-order implication does not require exact Case XII; it applies whenever the respective target type is absent.

At the original marked vertex \(t_X\), the pairs are \((RJ,EF,PK)\) in terminal/\(X:1\)/\(X:4\) order. At \(t_Y\) they are \((PK,RJ,EF)\) in terminal/\(Y:1\)/\(Y:5\) order. In both branches \(p_5=EF\). We give each branch's forced old port pairs and a new row. In the tables, an \(u_i\) triple lists its first-end half, second-end half, and proper port. A marked triple lists its terminal and its halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposed letters denote unordered occurrence pairs.

## Branch \(K:3u_2\)

The proper ports are \(p_3,p_4\). At \(u_1:2\), write \(R a\); at \(u_2:2\), write \(P b\); and at \(Z:2\), write \(K c\). Then \((a,b,c)\) is a permutation of \(\Lambda\). Indeed, those three pairs partition the six labels at vertex \(2\). The \(K c\) partner propagates through \(t_Z,6,t_W,3\), forcing \(u_3:3=P c\). Write \(u_3:4=R L\). Its remaining port is \(K g\), where \(\{L,g\}=\{a,b\}\). At vertex \(4\) this makes \(u_4:4=\Lambda\setminus\{L\}\) and \(p_4=K L\). Thus the old five port pairs are
\[
(p_1,p_2,p_3,p_4,p_5)
=(\Lambda\setminus\{a\},\ \Lambda\setminus\{b\},\ Kg,\ KL,\ EF).
\tag{1}
\]
The following new exterior row has \(P=eX:4,R=eW:3,K=W,J=X,E=F=e\) as boundary types:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,Ka,\Lambda\setminus\{a\})
 &(PR,Kb,\Lambda\setminus\{b\})
 &(Pc,RL,Kg)
 &(\Lambda\setminus\{L\},PR,KL)
 &(KJ,PR,EF)
\end{array}                                                   \tag{2}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,EF,PK)&(PR,KJ,EF)
 &(PR,\Lambda\setminus\{a\},Ka)
 &(PK,Ra,\Lambda\setminus\{a\}).
\end{array}                                                   \tag{3}
\]
At original vertices \(1,\ldots,6\), the three pairs are, respectively,
\[
(PR,EF,KJ),\quad(Ka,PR,\Lambda\setminus\{a\}),\quad
(Kb,Pc,Ra),\quad(RL,\Lambda\setminus\{L\},PK),\quad
(PR,KJ,EF),\quad(PR,Ka,\Lambda\setminus\{a\}).
\tag{4}
\]
Each is a partition of \(\{P,R,K,J,E,F\}\), using \(\{a,b,c\}=\Lambda\) and \(\{c,L,g\}=\Lambda\). The port column of (2) is exactly (1); (3) has terminal type \((eX)(eW)\).

## Branch \(K:3u_3\)

The proper ports are \(p_2,p_4\). Write \(u_1:2=Ra\) and \(u_3:4=RL\), with \(a,L\in\Lambda\) independent. The partition at vertex \(2\) and the \(Z/W\) marked subdivisions makes \(p_2=Ka\); the partition at vertex \(4\) makes \(p_4=KL\). The remaining port pairs are
\[
(p_1,p_2,p_3,p_4,p_5)
=(\Lambda\setminus\{a\},\ Ka,\ \Lambda\setminus\{L\},\ KL,\ EF).
\tag{5}
\]
For **every** \(a,L\), recomplete with both triples \(P,R=eX:4\), both \(K,J=X\), and \(E,F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,Ka,\Lambda\setminus\{a\})
 &(PR,\Lambda\setminus\{a\},Ka)
 &(PR,KL,\Lambda\setminus\{L\})
 &(\Lambda\setminus\{L\},PR,KL)
 &(KJ,PR,EF)
\end{array}                                                   \tag{6}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(KJ,EF,PR)&(PR,KJ,EF)
 &(PR,\Lambda\setminus\{a\},Ka)
 &(PR,Ka,\Lambda\setminus\{a\}).
\end{array}                                                   \tag{7}
\]
At vertices \(1,\ldots,6\), the pair partitions are
\[
(PR,EF,KJ),\quad(Ka,PR,\Lambda\setminus\{a\}),\quad
(\Lambda\setminus\{a\},PR,Ka),\quad
(KL,PR,\Lambda\setminus\{L\}),\quad
(PR,KJ,EF),\quad(PR,Ka,\Lambda\setminus\{a\}).
\tag{8}
\]
The port column of (6) is (5), and the terminal pairs in (7) give \([eX]\).

In each branch, every subdivision triple and every original-vertex triple partitions all six labels; hence each labelled exterior restriction is an actual matching, and every exterior edge has load two. The \(e\) shore terminal is still selected by \(E,F\), and the five proper-port pairs are unchanged **label by label**. Gluing each occurrence to its own original complete shore restriction yields the claimed genuine forbidden row. Under the exact-Case-XII forbidden pair \(\{eX,eW\}\), Appendix XII excludes both target types, so the second line of Note 446(3) is impossible. Together with Note 447, the first three of its twelve labelled signatures are excluded. Its remaining nine signatures, other forbidden pairs of this exterior, and Berge–Fulkerson are not decided here. The argument is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
