> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two forbidden EJ completions trap the marked edge in an internal odd cycle

Continue the central-path exterior and \(3{:}2\) unmarked near-bipartite core of [Notes 297–299](299-two-singleton-c-masks-exclude-the-right-ad-h-side-and-one-b-port-profiles.md). Let \(C-g\) be bipartite with \(g\subset B\), let the internal marked edge join \(v\in B\) to \(w\in R\) through \(t_e\), and put \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). Assume complete exact-Case-XII negative support with \(ad,bc\in T\). Consider either remaining right-row placement \(R_0=IJ\) or \(R_0=DJ\); thus \(J\) and one of \(I,D\) are the two \(R\)-based proper ports.

**Theorem (complete-fibre form).** Every actual shore perfect matching \(N\) with port set \(EJ\) that selects \(g\) leaves the marked half-edge \(t_ew\) on a **closed odd shore-internal cycle** of its complement. The other marked half-edge \(t_ev\) lies on that same cycle. The conclusion applies to the complete \(EJ,g\) fibre, not just to the designated BF row. In particular, the right \((ea)(ad)\) row's \(U_{ad}\) occurrence has this property in both placements.

## Two genuine T-state completions

Glue the same shore matching \(N\) to either of these actual exterior masks. Both select the shore terminal \(E\) and proper port \(J=h_4\); the listed terminal boundaries are the three selected semiedges:
\[
\begin{array}{c|c|l|l}
 &\text{terminal boundary}&\text{selected exterior edges besides terminal semiedges}
      &\text{complete exterior-complement routes}\\\hline
M_{ad}&b,c,e&a:C_{\rm ext},d:E_{\rm ext},1A_{\rm ext},2B_{\rm ext},3D_{\rm ext},h_4
      &a\!\leftrightarrow\!A, d\!\leftrightarrow\!I, D\!\leftrightarrow\!H\\
M_{bc}&a,d,e&b:A_{\rm ext},c:E_{\rm ext},1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4
      &b\!\leftrightarrow\!D, c\!\leftrightarrow\!I, H\!\leftrightarrow\!A.
\end{array}                                                        \tag{1}
\]
Here \(M_{ad}\) is the right row's \(U_{ad}\) exterior, while \(M_{bc}\) is an independent missing-pair-\(bc\) triple. For \(M_{ad}\), the five exterior path vertices are covered by \((1A,2B,a:C,3D,d:E)\) and \(u_1,u_2,u_3,u_4\) by \((1A,2B,3D,h_4)\). For \(M_{bc}\), those covers are \((b:A,1B,2C,3D,c:E)\) and \((1B,2C,3D,h_4)\). The mark vertices are covered once by the displayed terminal semiedges or cross halves. Thus both masks and all routes in (1) can be checked directly at every exterior vertex.

In the whole pole with \(t_e\) and the exterior coloured as in Note 283, the only same-side proper edges are \(g,t_ew\) and the two \(R_0\) cut edges. The matching \(N\) selects \(g,J\), and selects terminal \(E\) at \(t_e\). Its complement therefore contains both marked half-edges \(t_ev,t_ew\), while its only same-side edges are \(t_ew\) and the other \(R\)-based cut edge \(q\in\{I,D\}\). Since each mask in (1) has a missing pair in \(T\), every complete complement must retain an odd closed cycle; otherwise alternating its even closed cycles and terminal path would produce a forbidden Tait colouring.

If \(q=I\), the \(d\)--\(I\) arm of \(M_{ad}\) puts \(q\) on an open terminal path. Hence \(t_ew\) must be on a closed odd component under this completion. Suppose it were on a shore path rather than a shore-internal closed cycle. The only exterior connection between two free ports under \(M_{ad}\) is \(D\)--\(H\), so that shore path would have to pair \(D\)--\(H\), leaving \(A\)--\(I\) as the other shore pair. Under \(M_{bc}\), the exterior \(H\)--\(A\) connection now joins these two shore paths into the open \(b\)--\(c\) path. Both remaining same-side edges \(t_ew,I\) lie on that path; every closed component is even, producing a forbidden \(bc\)-Tait colouring. Thus \(t_ew\) belongs to an intrinsic closed shore cycle.

If \(q=D\), use \(M_{bc}\) first. Its \(b\)--\(D\) arm makes \(q\) open, so \(t_ew\) must be on a closed odd component. If that component used a shore path, the sole exterior free-port connection \(H\)--\(A\) would force the shore pairing \(HA\mid ID\). Under \(M_{ad}\), the exterior \(D\)--\(H\) connection then joins these shore paths into the open \(a\)--\(d\) terminal path. It contains both \(t_ew,D\), so all closed components are even and the forbidden \(ad\)-Tait colouring follows. This again forces an intrinsic closed shore cycle through \(t_ew\).

At \(t_e\), \(N\) selects terminal \(E\), so the two unselected half-edges \(t_ev,t_ew\) belong to the same complement component. Thus the intrinsic cycle through \(t_ew\) also contains \(t_ev\). It is odd because \(t_ew\) is its sole same-side edge. Suppressing \(t_e\) turns it into an even cycle of the unmarked core through the marked edge \(e=vw\), disjoint from \(g\) and from the proper edges selected by \(N\). \(\square\)

The condition is an actual all-matchings restriction: every \(EJ\)-port shore matching selecting \(g\) must leave a marked-edge return cycle wholly inside the shore. It does not establish that such a matching exists without the right BF row, rule out the two remaining \(IJ,DJ\) placements, or settle Berge–Fulkerson. The proof is hand-derived and uses no local enumeration or OMEN.
