> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cross-row HJ switch excludes the last five-vertex Hall block

Continue the actual left \((ea)(ac)\) and right \((ea)(ad)\)
rows in the noncollision, \(R_0=DJ\), one-edge-near-bipartite
branch of a completed minimum host with girth at least five.
Assume complete exact-Case-XII perfect-matching closure
and the five-vertex six-cut Hall incidence of
[Note 320](320-five-vertex-six-cut-hall-design-and-zero-port-phase-gate.md):
\[
 N_S(o)=\{u,a,b\},\quad N_S(p)=\{u,c,f\},\quad
 N_S(x)=\{a,c\},\quad N_S(y)=\{a,f\},\quad
 N_S(z)=\{b,c\}.                                      \tag{1}
\]
By [Notes 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md)
and [323–325](325-no-central-j-five-block-with-a-central-d-edge.md),
the only placements of this incidence design needed below,
up to reflection, are
\[
        \ell=b,\qquad J=z,\qquad H=f,\qquad P=u,
        \qquad P\in\{A,I\},\quad D=d_D.               \tag{2}
\]
Here \(bd_D\) is an internal edge, and \(D d_D\), \(Pu\),
\(Hf\), \(Jz\) are the named port edges.

**Theorem.** Both placements in (2) are impossible. Consequently, under
the stated genuine-row and complete-support hypotheses, there
is no noncollision five-vertex six-cut Hall block with
\((\alpha,\eta)=(2,1)\) in the \(R_0=DJ\) branch.

**Proof.** The right row's actual zero-port slot \(X\)
uses \(bd_D\), by [Note 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md).
Its \(U(EJ)\) slot also uses \(bd_D\): it selects \(Jz\)
and no \(H,P\) port, so if \(b\) used \(bo\) instead,
the remaining four vertices of \(S\) would have only
\(p,x,y\) available to match. The right \(Z(EAHJ)\)
slot selects \(Jz\) and cannot use the saturated
\(bd_D\), so it uses \(bo\). At \(b\), the edge
\(bz\) must consequently carry two of the three
remaining slots \(Y,V,W\). Thus **at least one** of
the actual right singleton-\(a\) matchings
\(Q\in\{Y,V\}\) selects \(bz\). It has ports
\(ID\), selects \(t_{ev}\), and avoids \(g\), by
[Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md).
In particular \(Q\) uses \(Dd_D\), and it uses \(Iu\)
when \(P=I\).

Let \(L\) be either actual left-row singleton-\(a\)
shore matching. By Note 301 it has ports \(HJ\),
selects \(g,t_{ew}\), and the two shore paths of the
*complete actual matchings* \(L\triangle Q\) pair
\[
                            ID\mid HJ.                       \tag{3}
\]
If \(L\) used \(bd_D\), then
\(D-d_D-b-z-J\) would be an entire component of
\(L\triangle Q\), pairing \(D\) with \(J\) and
contradicting (3). Therefore \(L\) avoids \(bd_D\).
With \(Hf,Jz\) selected, matching the remaining
\(S\)-vertices through (1) has only one phase:
\[
                   L:\quad Hf,Jz,bo,up,ay,cx.          \tag{4}
\]

If \(P=I\), then \(Q\) uses \(Iu,Dd_D,bz\). Were
it to select \(fp\), the complete component
\(H-f-p-u-I\) of \(L\triangle Q\) would contradict
(3). Thus it selects \(fy\); matching \(p,o\) then
forces \(cp,ao\), and \(x\) uses its third edge.
The complete \(H\)--\(J\) component is
\[
                         H-f-y-a-o-b-z-J.                     \tag{5}
\]
If \(P=A\), the matching \(Q(ID)\) selects no
proper port based in \(S\), so it matches all five
vertices of \(S\) bijectively to \(T\). With \(bz\)
selected, the three possible phases and their complete
\(H\)--\(J\) components of \(L\triangle Q\) are
\[
\begin{array}{c|l|l}
 &Q\text{ on }S\text{--}T&H\text{--}J\text{ component}\\\hline
M_1&uo,bz,ax,cp,fy&H-f-y-a-x-c-p-u-o-b-z-J\\
M_2&uo,bz,ay,fp,cx&H-f-p-u-o-b-z-J\\
M_3&up,bz,ao,cx,fy&H-f-y-a-o-b-z-J.
\end{array}                                                   \tag{6}
\]
Thus in either case \(L\triangle Q\) has a complete
\(H\)--\(J\) path lying wholly in the displayed
block. Switching that path in the *actual* matching
\(L\) leaves its exterior, \(g,t_{ew}\), and the
unselected edge \(bd_D\) unchanged. The result \(N\)
is an actual zero-proper-port \((g,t_{ew})\) matching
that avoids \(bd_D\). Its selected \(S\)--\(T\)
edges form one of the four perfect-matching phases of
[Note 320, equation (3)](320-five-vertex-six-cut-hall-design-and-zero-port-phase-gate.md).
Their block-internal alternating six-cycle switches
connect all four phases, so they realize from \(N\)
another actual zero-port matching \(N'\) with phase
\[
                         N':\quad uo,bz,ay,fp,cx.             \tag{7}
\]
Its *full shore complement* contains the complete path
\[
                         P-u-p-c-z-J.                          \tag{8}
\]
The first and last edges are the unselected port edges;
every internal edge in (8) is unselected by (7). But
[Note 285's complete-fibre gate](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
allows a zero-port \((g,t_{ew})\) matching in the
\(R_0=DJ\) profile only the complement pairings
\(EA\mid ID\mid HJ\) and \(EJ\mid AD\mid IH\).
Neither contains \(AJ\) or \(IJ\). This contradiction excludes
both cases of (2). Their reflected placements are excluded by the same
argument. Combining with Notes 321 and 323–325 proves the stated
five-vertex conclusion. \(\square\)

The argument switches complete actual matchings; it never
identifies the shore restrictions of two different BF rows.
It closes this incidence design only. The other six-cut
allocation \((\alpha,\eta)=(1,2)\), larger Hall witnesses,
incidence collisions, other shore profiles, and the full
Berge–Fulkerson conjecture remain open. The cited upstream
hand proofs have not yet had independent second-source
checking. No local computation or OMEN run was used.
