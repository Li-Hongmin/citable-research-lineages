> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A shared \(z\)-star forces an outer \(xz\) loop in \(I_m\)

Continue the genuine \(I_m\) tree--\(R^*\) connector of
[Note 220](220-the-two-rstar-private-ports-agree-at-the-direct-mark.md).
The tree shore \(A^\circ\) is centred at \(u_1\), with end
groups \(\{u_2,x\}\mid\{z,p\}\). If the complete cyclic
shore relation contains the actual BF type
\((u_1z)(u_2z)\), then the outer five-pole contains the
actual BF loop
\[
                              \boxed{[xz].}                 \tag{1}
\]
In the Figure-7 \(R^*\) relation the input condition is simply
\(c(u_1z)\ne c(u_2z)\).

Use the tree's actual type \((u_2z)(xz)\) and assign the
six local boundary matchings as follows. A three-letter entry
is a triple boundary; the other entries are singleton boundaries.

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(u_2\) |
| 2 | \(u_1u_2p\) (missing \(xz\)) | \(z\) |
| 3 | \(z\) | \(u_2yq\) (missing \(u_1z\)) |
| 4 | \(u_2\) | \(u_1yq\) (missing \(u_2z\)) |
| 5 | \(x\) | \(z\) |
| 6 | \(z\) | \(u_1\) |

The shore-half labels and exterior connector labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&24&36&15/12&-\\
B&46&13&25&-&34/34
\end{array},
\qquad
(R_1,R_2;D_x,D_y,D_p,D_q)=(35,56;46,12,34,12).       \tag{2}
\]
At \(u_1,u_2,w_1,w_2\) and all five marked subdivision
vertices, the incident two-slot labels partition \([6]\).
The direct \(z\)-mark has terminal residual \(14\), and the
five outer terminal labels are
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(14,23,56,56,56).                \tag{3}
\]
Slots \(5,6\) both have exactly \(\{y,p,q\}\), missing
\(xz\). The other four slots are singleton boundaries at
\(z,z,x,x\). Both input shore types are genuine six-matching
rows, so their internal edges already have load two; the
connector partitions prove (1) for actual perfect matchings.

There is a useful exact-Case-XII application. Write
\(a=c(yz)=c(qz)\) and \(d=c(yq)\). Suppose \(a\ne d\)
and exactly one of \(y,q\) changes colour between \(z,u_2\).
The tree star \((xz)(xp)\) and the two private-port stars
force \([xy],[xq]\) by
[Note 212, (3)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md).
If \(q\) changes, the tree's \(p\)-star forces \([py]\),
while [Note 218](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md)
forces \([zq]\). The allowed loop cycle is then uniquely
\(p-y-x-q-z-p\), which omits \(xz\). If \(y\) changes,
the corresponding loops are \([pq],[yz]\), giving the
unique cycle \(z-y-x-q-p-z\), which again omits \(xz\).
Thus, under these colour conditions, \(c(u_1z)\ne c(u_2z)\)
contradicts exact Case XII by (1).

In the published Figure-7 labels, this excludes the following
orders from [Note 220, (4)](220-the-two-rstar-private-ports-agree-at-the-direct-mark.md)
for either ordering of \(y,q\):
\[
\begin{array}{c|c}
\{y,q\}&(z,u_2,u_1)\\\hline
\{1,2\}&(4,3,5)\\
\{1,3\}&(2,4,5),(2,5,4)\\
\{2,5\}&(4,3,1)\\
\{3,5\}&(2,1,4),(2,4,1)
\end{array}.                                                  \tag{4}
\]
This removes twelve labelled orders. The other twelve orders
in Note 220, (4) are, for either orientation of \(y,q\),
\[
\begin{array}{c|c}
\{y,q\}&(z,u_2,u_1)\\\hline
\{1,2\}&(5,3,4)\\
\{2,5\}&(1,3,4)\\
\{2,4\}&(3,1,5),(3,5,1)\\
\{3,4\}&(1,2,5),(5,2,1)
\end{array}.                                                  \tag{5}
\]
They are only necessary candidates, not certified realizations.
The mirror tree centre, other shore combinations,
and the complete exact-Case-XII closure remain open. This
analytic proof awaits an independent check.
