> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The remaining Hamilton \(S_1\) row forces a long route and two \(p_4\) singleton-\(e\) matchings

Fix the Hamilton \(K_{3,3}\) exterior and \(S_1=e-a-b-d-c-e\) of [Notes 378–382](382-the-hamilton-s-t-root-pair-fails-the-two-e-path-tests.md). Under complete exact-Case-XII BF support, a required \((ea)(eb)\) row has only the root pair \((s,x)\), by Notes 379 and 382. Name its occurrences \(P_{ea},R_{eb},A_a,B_b,E_e,F_e\). The roots give the exterior restrictions
\[
\begin{array}{c|l}
P &t_as;\ b,c,d;\ xu_0,ru_1,yu_2,zu_3,tu_4\\
R &t_bx;\ a,c,d;\ ru_0,yu_1,su_2,zu_3,tu_4,
\end{array}                                                     \tag{1}
\]
where the tree is \(x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t\) and the marks are \(a=xs,b=xt,c=yt,d=zr\).

> **Exterior-spine theorem.** In every such genuine row, the mandatory \(a\)--\(c\) exchange of \(P\triangle A\) uses the long route
> \[
>       a,t_a,s,u_3,z,u_4,t,t_c,c.                       \tag{2}
> \]
> Both singleton-\(e\) occurrences use the \(b\)-half \(t_bt\), the \(c\)-half \(t_cy\), the \(d\)-half \(t_dz\), and proper shore port \(p_4\). Consequently \(A\) uses \(t_bx,t_ct,t_dr\), while \(B\) uses \(t_ct,t_dr,zu_4\). These conditions are necessary for exact support at every shore order and cycle rank; they do not certify that a complete row with exact support exists.

**Proof.** Because the other triple is \(R=eb\in T_1\), the \(a\)-terminal path in \(P\triangle A\) must end at \(c\); otherwise switching it makes a forbidden \(T_1\)--\(T_1\) row. As in Note 382, this exterior path is either the short route
\[
              H_2:a,t_a,s,u_2,y,t_c,c                         \tag{3}
\]
or the long route (2). Let \(P'\) be the state-\(ec\) triple after the switch. For each singleton-\(e\) occurrence, its \(e\)-path with \(P\) must reach \(b\), whereas its \(e\)-path with \(P'\) must reach \(d\): the other endpoint states lie in \(T_1\) beside \(R\). Since \(P,P'\) have the same entire shore matching, the two terminal legs in question must reach the **same** proper shore port.

Suppose first that \(A\) uses (3). The common \(tu_4\) edge of \(P,R\) forces \(A\) onto \(t_bt\) at \(t\), because \(A\) uses \(t_cy\). At \(x\), \(A\) uses \(xu_0\). The mark loads then force one singleton-\(e\) occurrence, call it \(E\), to use \(t_bx,t_as\), and the other to use \(t_bt,t_ax\). At \(t\), \(P,R\) saturate \(tu_4\), while \(A\) and the other singleton-\(e\) saturate \(t_bt\); hence \(B,E\) both use \(t_ct\). At \(y\), \(A\) and the other singleton-\(e\) use \(t_cy\), so \(B,E\) split \(yu_1,yu_2\). At \(s\), \(P,E\) use \(t_as\), \(R,A\) use \(su_2\), and \(B\) plus the other singleton-\(e\) use \(su_3\). Since \(P,R\) also saturate \(zu_3\), \(E\) uses shore port \(p_3\).

The old \(b\)-leg of \(P\triangle E\) begins \(b,t_b,x,u_0\). If \(E\) uses \(p_0\), the leg ends there, and the new \(b\)-leg after (3) still ends there because \(P'\) retains \(xu_0\). The required endpoint change to \(d\) is impossible. Thus \(E\) uses \(ru_0\), forcing its \(d\)-half to be \(t_dz\). The new \(d\)-leg of \(P'\triangle E\) is then \(d,t_d,z,u_3,p_3\), as \(P'\) retains \(zu_3\). The old \(b\)-leg, after passing through \(r,u_1\), ends at \(p_1\) if \(E\) uses \(p_1\) there, or at \(p_2\) through \(y,u_2\) if it uses \(yu_1\). Neither is \(p_3\). Thus (3) is excluded.

Now \(A\) uses (2). At \(t\), it takes \(t_ct\), hence at \(x\) it takes \(t_bx\); at \(z\), it takes \(zu_4\), hence its \(d\)-half is \(t_dr\). Since \(P,R\) both use \(tu_4\), while \(P,B\) use terminal \(b\), the two singleton-\(e\) occurrences both use \(t_bt\), and \(B\) uses \(t_ct\). The \(c\)-half \(t_ct\) is saturated by \(A,B\), so both singleton-\(e\) occurrences use \(t_cy\).

Consider either singleton-\(e\) occurrence \(E\). If it used \(t_dr\), its new \(d\)-leg with \(P'\) would be \(d,t_d,r,u_1,p_1\). Indeed \(P'\) uses \(ru_1\), whereas \(E\), already matching \(r,y\) through the \(d,c\) halves, must use \(p_1\) at \(u_1\). Its old \(b\)-leg with \(P\) begins \(b,t_b,t,u_4\). If \(E\) uses \(p_4\), that leg ends at \(p_4\). Otherwise it continues through \(z,u_3\), where it may end at \(p_3\). If it instead continues through \(s,t_a,x,u_0\), then \(E\) uses \(t_ax\) and must end at \(p_0\), since \(r\) is already matched through \(t_dr\). Thus its old \(b\)-leg ends at one of \(p_0,p_3,p_4\), never at \(p_1\). This contradicts the common shore exit.

Both singleton-\(e\) occurrences therefore use \(t_dz\). Their common use saturates that half, forcing \(B\) onto \(t_dr\). At \(z\), \(P,R\) saturate \(zu_3\) and the two singleton-\(e\) occurrences saturate \(t_dz\), so \(A,B\) saturate \(zu_4\). At \(u_4\), \(P,R\) saturate \(tu_4\), and \(A,B\) saturate \(zu_4\); hence both singleton-\(e\) occurrences use \(p_4\). Their old \(b\)-legs and new \(d\)-legs indeed both end at \(p_4\), so this argument cannot eliminate the long-route row. \(\square\)

The real row of [Note 380](380-a-real-hamilton-ea-eb-row-survives-the-two-immediate-switches.md) attains this entire exterior spine. Its forbidden \([eb]\) arises from an extra complete matching, while [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) shows that making every zero-port shore complement contain an odd cycle still leaves that forbidden BF loop. In any putative exact-support row, the two zero-port shore matchings \(Q_P,Q_R\) must be different by Note 378; both singleton-\(e\) occurrences use **both** terminal \(e\) and port \(p_4\); and [Note 361's defect lemma](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md) requires each odd closed component of \(Z-Q_P\) to contain at least two \(Q_R\)-edges, and conversely. These are concrete constraints on the remaining complete multi-matching shore coupling. They do not imply the forbidden \([eb]\) BF loop by themselves. Other pentagon \(S_2\), other exteriors and the full conjecture remain open. This is a hand proof without local mathematical recomputation or independent review.
