> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Existential Case-XII rectangles transfer through colourable two-sums

[Note 116](116-alias-preserving-factor-obstruction-to-the-case-xii-rectangle.md) shows that a synchronized rectangle can fail for a *prescribed* set of six rows after a support-preserving \(K_4\) attachment, even when three additional matching identities are retained. The quantifier over row choices matters: the existence of a rectangle for **some** six-row assignment is invariant under every three-edge-colourable two-sum, for the complete opposite-carrier projection version defined below. In particular, a bad assignment produced by the attachment cannot by itself prove that the attached graph has no good assignment.

This note treats only actual perfect matchings and their complete edge masks. It does not assert that an exact-Case-XII pole or a good assignment exists.

## A precise rectangle predicate

Use the six row equations (1) of Note 116, with the same singleton names \(A,B,C,D,X,Y\) and carrier loads

\[
K_{23}=2\mathbf1-r_{23}-B-X,\qquad
K_{34}=2\mathbf1-r_{34}-Y-C.                         \tag{1}
\]

The singleton boundaries are \(\partial A=\{1\}\), \(\partial B=\{2\}\), \(\partial X=\partial Y=\{3\}\), \(\partial C=\{4\}\), and \(\partial D=\{5\}\); \(P_3,P_5\) and each \(p^i_{uv}\) have the indicated singleton boundary. A matching named \(q_{uv}\), \(r_{uv}\), or \(q'_{25}\) has triple boundary \([5]\setminus\{u,v\}\). An assignment \(\rho\) gives an actual perfect matching of the stipulated boundary class to each name and makes every row have load \(2\mathbf1\). Equalities between names may additionally be prescribed, including the three aliases of Note 116. No inequality between differently named matchings is imposed in the transfer theorem. In particular, each \(K\) in (1) has semiedge load one at all five terminals.

For an integer carrier load \(K\), let

\[
\mathcal F_u(K;v)=\{W\in\mathcal P_u(G):
\exists Q\in\mathcal P_{[5]\setminus\{u,v\}}(G),
Z\in\mathcal P_v(G),\ K=Q+W+Z\}.                 \tag{2}
\]

All matching classes and sums in (2) use complete masks, including proper edges and semiedges. Define the opposite witness domains and the four target tests by

\[
\begin{array}{c|c|c|c}
\text{target }T&K_T&\mathcal O_T&\text{leakage partner}\\ \hline
Y&K_{23}&\mathcal F_1(K_{34};3)&1\\
D&K_{23}&\mathcal F_2(K_{34};5)&2\\
A&K_{34}&\mathcal F_4(K_{23};1)&4\\
X&K_{34}&\mathcal F_5(K_{23};3)&5
\end{array}                                                   \tag{3}
\]

The **full-projection rectangle predicate** is

\[
\Phi(G,\rho)\iff
\exists T\in\{Y,D,A,X\},\ W\in\mathcal O_T:
\chi_T+\chi_W\le K_T\quad\text{edgewise}.             \tag{4}
\]

It is exactly the disjunction of the sixteen Note-104 contexts when “opposite operative witness” means the full carrier projections (3), with no additional joint condition on the opposite row. To see this, any proposed rectangle has

\[
K_T=P+N+W,\qquad N+P-T\in\mathcal P(G),
\]

so \(K_T-T-W=N+P-T\ge0\), giving (4). Conversely, if (4) holds, the vertex-degree-three identity of [Note 106](106-common-k-domination-forces-a-full-perfect-matching-completion.md) makes

\[
N=K_T-T-W\in\mathcal P(G).                            \tag{5}
\]

Its boundary is the triple complementary to the target class and the leakage partner. Take \(P=T\), which belongs to the entry core and to each of the three non-entry agreement cores by the empty alternating-cycle choice. Then \(K_T=P+N+W\) and \(N+P-T=N\) is an actual matching. The prescribed opposite identity is the *same* complete \(W\) in (2) and (5). Thus sixteen context tests collapse to the four domination intersections (4) for this specified witness-domain interpretation. The [earlier exact equivalence analysis](../scratch/r2-shared-witness-pole-20260928/equivalence-check.md) also records why an extra opposite-row condition involving \(P\) or \(N\) would require a different predicate.

## Transfer theorem

Let \(H_0\) be a cubic five-pole, let \(e\) be a proper edge, and let \(J\) be a closed three-edge-colourable cubic graph with distinguished edge \(f\). Form \(H=H_0\oplus_{e,f}J\) by the usual two-edge sum. Write \(\mathfrak R(G)\) for the assignments satisfying the six rows and any fixed list of *equality* constraints between names. Then:

**Theorem.** Every \(\rho_0\in\mathfrak R(H_0)\) has a canonical lift \(\widetilde\rho_0\in\mathfrak R(H)\) such that

\[
\Phi(H_0,\rho_0)\Longrightarrow
\Phi(H,\widetilde\rho_0).                           \tag{6}
\]

Every \(\rho\in\mathfrak R(H)\) projects to \(\pi\rho\in\mathfrak R(H_0)\), and

\[
\Phi(H,\rho)\Longrightarrow\Phi(H_0,\pi\rho).       \tag{7}
\]

Consequently, when the row constraints contain equalities but no prescribed disequality,

\[
\boxed{
\exists\rho\in\mathfrak R(H)\ \Phi(H,\rho)
\iff
\exists\rho_0\in\mathfrak R(H_0)\ \Phi(H_0,\rho_0).
}                                                        \tag{8}
\]

The equivalence still holds when the three aliases \(p^1_{13}=A\), \(p^3_{13}=P_3\), and \(p^5_{25}=P_5\) are among the required equalities. It applies whether the common complete BF support is exact Case XII or not.

### Proof

Choose a three-edge-colouring \(F_0,F_1,F_2\) of \(J\), with \(f\in F_0\). At one endpoint of \(e\), denote the other two incident edges by \(g,h\). Every actual matching \(M\) of \(H_0\) uses exactly one of \(e,g,h\); assign it the corresponding colour \(c(M)\in\{0,1,2\}\), and splice \(M\) with \(F_{c(M)}\). This single rule is the canonical lift of [Note 099](099-three-edge-colourable-two-sums-preserve-dependent-splice-fibres.md). It assigns the same factor matching to every occurrence of the same exterior matching, so it preserves all required identity equalities.

In any BF row of \(H_0\), each of \(e,g,h\) has load two. Hence its six lifted occurrences use each factor colour twice, and are a BF row of \(H\). Thus all six rows lift simultaneously. If \(\Phi(H_0,\rho_0)\) has target \(T\) and opposite witness \(W\), (2) gives an opposite-carrier decomposition \(K_{\rm opp}=Q+W+Z\), while (5) gives a source decomposition \(K_T=T+W+N\). Adding the corresponding fixed halves produces two BF rows in \(H_0\). Their canonical lifts are BF rows in \(H\), and the one matching \(\widetilde W\) is literally shared between them. In particular,

\[
\widetilde K_T=\widetilde T+\widetilde W+\widetilde N,
\qquad
\widetilde W\in\mathcal O_{\widetilde T}(H).
\]

This proves (6).

Conversely, every matching of \(H\) has unique projections onto both factors, with matching distinguished-edge bits. Every BF row projects to a BF row of \(H_0\), and any literal equality of upstairs matchings remains an equality after projection. Given \(\Phi(H,\rho)\), (5) supplies an actual upstairs matching \(N=K_T-T-W\). Project its source row and the opposite row witnessing \(W\in\mathcal O_T\). Their common complete \(W\)-mask projects to one common matching of \(H_0\), and their source equality gives

\[
K_{T,0}=T_0+W_0+N_0.
\]

Hence \(W_0\in\mathcal O_{T_0}\) and \(T_0+W_0\le K_{T,0}\), proving (7). Taking existential quantifiers gives (8). \(\square\)

## Boundary of the result

The transfer does not require a canonical lift to preserve an arbitrary *bad* selected assignment. Note 116 deliberately chooses a different lift and makes all four residuals negative. If a good assignment existed in the exterior pole, the canonical lift above would still give a good assignment in the attached pole. Thus the attachment closes the **universal, per-assignment** rectangle route but leaves the **existential, row-reselecting** route intact.

A required disequality between names is different from an identity equality. Canonical lifting preserves \(q_{25}\ne q'_{25}\), so (6) remains valid with that requirement. Projection may collapse distinct upstairs matchings: in the explicit thirteen-to-seventeen-vertex insertion of Note 116, \(q_{25}\) and \(q'_{25}\) are the same matching before insertion and differ only by their \(\alpha/\beta\) factor choices afterward. Therefore (7) does not in general land in a class requiring \(q_{25}\ne q'_{25}\); equivalence (8) has not been claimed for that narrower class.

For actual minimum BF counterexamples, [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) imposes girth five and excludes nonterminal proper two-edge-cut factors on a Case-XII side. No conclusion here supplies a rectangle in that irreducible class. The decisive positive claim would have to force (4), or a stronger explicitly specified opposite-witness intersection, for at least one row assignment of an eligible indecomposable exact-Case-XII pole. The existence of such a pole and that positive claim remain open.
