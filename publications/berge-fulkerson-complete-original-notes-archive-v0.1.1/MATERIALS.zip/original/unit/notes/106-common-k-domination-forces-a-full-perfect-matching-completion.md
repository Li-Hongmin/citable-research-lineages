> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Common \(K\)-domination forces a full perfect-matching completion

The opposite-carrier shortcut left after
[Note 104](104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md)
has one order-independent valid part. For either fixed Note-101 carrier,
two actual perfect matchings dominated jointly by its complementary load
have a unique edgewise residual which is itself an actual perfect matching.
This removes residual degree and odd-cycle obstructions once such a pair is
found. It does not force the pair, agreement-core membership, full witness
identity, or the required component phase.

## The fixed load has local degree three

Let \(G\) be a loopless cubic pole and let

\[
 H=L_0+L_1+L_2,\qquad K=2\mathbf1-H,
 \tag{1}
\]

where \(L_0,L_1,L_2\) are actual perfect matchings. At every cubic vertex
each \(L_a\) uses exactly one incidence. Including the semiedge incidence
at a terminal vertex, one obtains

\[
 \sum_{e\ni v}K(e)=6-3=3.                       \tag{2}
\]

In particular (2) applies to both Note-104 loads
\(K_{23}=2\mathbf1-r_{23}-B-X\) and
\(K_{34}=2\mathbf1-r_{34}-Y-C\). It follows from the actual fixed
identities in Note 101, rather than from their terminal types.

## Full-identity completion

Let \(U,V\) be actual perfect matchings of \(G\). If

\[
 \chi_U+\chi_V\le K                              \tag{3}
\]

on every edge object, put

\[
 p=K-\chi_U-\chi_V.                              \tag{4}
\]

The vector \(p\) is integral and nonnegative. By (2), its incident sum at
every cubic vertex is \(3-1-1=1\). Hence its coordinates at that vertex
are one zero--one choice. Since (4) is defined on common edge objects,
these local choices are globally consistent. Thus \(p=\chi_P\) for one
actual perfect matching \(P\), and

\[
 \boxed{K=\chi_P+\chi_U+\chi_V}                  \tag{5}
\]

holds edge by edge, including semiedges. Conversely, (5) implies (3), so
(3) is the exact criterion for this common completion.

Also \(K-\chi_P=\chi_U+\chi_V\). Its nondoubled closed components are
components of \(U\triangle V\), and are therefore even alternating cycles.
Thus a jointly dominated pair automatically supplies residual
nonnegativity and the even-component condition used in Note 104.

## Exact boundary of the shortcut

Condition (3) is not supplied by the existence of a matching or a BF row
with the opposite leakage boundary state. It is a coordinatewise statement
about the same two complete matching masks and the same \(K\).

Nor does (5) put \(P\) in one of Note 104's agreement-core families. That
requires \(P\) to equal the specified target outside a specified agreement
region, with its complete symmetric difference confined to that region.
Finally, Note 104 forces a unique leakage state but explicitly not a unique
witness. Identifying its witness with an opposite-carrier operative matching
and imposing the Note-082 phase are further full-mask and componentwise
conditions.

Consequently the remaining universal claim is precisely the nonemptiness,
in at least one of the sixteen contexts, of a dominated-pair intersection
which simultaneously satisfies agreement-core membership, equality of the
complete leakage-witness identity, and the prescribed phase. The fixed rows
and exact support give only separate boundary projections of this
intersection. They do not presently prove it nonempty, and no actual
exact-Case-XII pole is known that makes it empty.

This closes the shortcut from opposite boundary-state existence alone. It
does not close R2; the phased full-identity proposition remains unknown.
