> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The real \(X,Y\) row has a forbidden loop using only three old shore masks

[Note 464](464-the-real-x-y-row-has-only-case-xii-allowed-types-with-fixed-shore-masks.md) proves that the real \((eX)(eZ)\) row of [Note 463](463-a-real-common-endpoint-x-y-hamilton-row-has-a-forbidden-loop.md) cannot be recompleted to any Case-XII-forbidden \(e\)-type while retaining the **multiset** of its six complete shore restrictions. The distinction between retaining that multiset and retaining only the **set** of available shore restrictions is sharp in the same 21-vertex pole. A second, explicit \([eX]\) BF loop uses no shore restriction outside the old row: its six shore restrictions, with repetition, are
\[
                         Q_R,Q_R,Q_a,Q_a,Q_J,Q_J.                 \tag{1}
\]
Here the subscripts refer to the six original matching occurrences \(P,R,K,J,a,b\) of Note 463. The old multiset is \(Q_P,Q_R,Q_K,Q_J,Q_a,Q_b\), so (1) does not contradict Note 464.

Use the shore cycle of Note 463, with vertices in cyclic order
\[
q_e,q_1,q_3,q_5,q_4,q_2
\]
and successive edge pairs \(PJ,RK,PJ,Rb,Pa,RK\). Its port pairs are
\[
(e,p_1,p_2,p_3,p_4,p_5)=(ab,ab,Jb,ab,KJ,Ka).             \tag{2}
\]
The zero-port shore restriction \(Q_R\) consists of
\[
q_1q_3,\quad q_5q_4,\quad q_2q_e.                            \tag{3}
\]
The shore restrictions \(Q_a,Q_J\) partition **all remaining shore edges and ports**:
\[
\begin{aligned}
Q_a &: q_4q_2;\ e,p_1,p_3,p_5,\\
Q_J &: q_eq_1,q_3q_5;\ p_2,p_4.
\end{aligned}                                                  \tag{4}
\]
Thus \(Q_R,Q_a,Q_J\) are three genuine complementary matchings of the six-port shore. In particular the complement of \(Q_R\) pairs its ports as
\[
                ep_1\mid p_2p_4\mid p_3p_5.                  \tag{5}
\]

Take the **exterior** restriction of the old \(P=eX\) occurrence, rooted at \(X:4\), and glue it to the **shore** restriction \(Q_R\). Both restrictions use no proper shore port, so they form a new complete triple-boundary perfect matching \(T_X\) of state \(eX\). The exterior complement pairs
\[
                Xp_5\mid p_1p_2\mid p_3p_4                 \tag{6}
\]
as in Note 463(11). Pairings (5)--(6) join into one open \(e\)--\(X\) path. In fact the entire complement is the following path, where each \(t_j\) is the subdivision vertex of marked edge \(j\):
\[
\begin{split}
e,q_e,q_1,u_1,2,t_Z,6,t_W,3,u_2,q_2,q_4,\qquad\\
u_4,4,u_3,q_3,q_5,u_5,5,t_Y,1,t_X,X.
\end{split}                                                    \tag{7}
\]
It visits all 21 internal vertices exactly once. Alternately colouring the edges of (7) from the \(e\) end gives two singleton perfect matchings \(D_e,D_X\). On the shore they restrict exactly to \(Q_a,Q_J\), respectively: at \(e,p_1,p_3,p_5\) the first colour occurs, at \(p_2,p_4\) the second occurs, and the three internal complement edges in (4) have the corresponding colours. Therefore
\[
                 T_X,T_X,D_e,D_e,D_X,D_X                   \tag{8}
\]
is a six-complete-matching BF cover of forbidden type \([eX]\), and its shore-mask multiset is exactly (1).

This proves a precise boundary for row-preserving closure: even the **set** of the six old complete shore matchings can suffice to create a forbidden BF type, although retaining each occurrence once cannot. The construction uses a clean zero-port shore matching and a Tait complement. It does not show that a forbidden type can be forced from an arbitrary real row, or from an exact-Case-XII pole. Indeed, [Note 359](359-two-root-parity-gate-and-k33-sharpness.md) proves that exact Case XII on this marked Hamilton exterior makes every zero-port shore complement contain an odd closed component; the Petersen substitution in [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) also destroys this particular Tait argument while preserving the forbidden BF support. The path certificate and mask identification above are hand-derived and await independent review. \(\square\)
