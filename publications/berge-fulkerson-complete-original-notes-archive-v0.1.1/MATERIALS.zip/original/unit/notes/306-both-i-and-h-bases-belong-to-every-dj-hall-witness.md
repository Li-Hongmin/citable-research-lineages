> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both I and H bases belong to every surviving DJ Hall witness

> **Scope correction (2026-10-01):** [Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md)
> retracts Note 305's \(I\)-base claim. The self-contained first
> section below still proves \(L\triangle W=DI\mid HJ\), with
> \(g,t_{ew}\) on the \(DI\) path. The subsequent claim that every
> Hall witness contains **both** \(I,H\), and the resulting
> six-edge-cut lower bound, are withdrawn. Note 309 proves the
> corrected \(H\)-base conclusion.

Continue the genuine exact-Case-XII central-path, \(R_0=DJ\), \(3{:}2\) near-bipartite setting of [Notes 301–305](305-every-tight-hall-corridor-must-contain-the-i-port-base.md). The left \((ea)(ac)\) BF row has a singleton-\(a\) shore matching \(L\) with ports \(HJ\) selecting \(g,t_{ew}\), and its opposite singleton-\(c\) matching \(W\) has ports \(ID\), selects \(t_{ev}\), and avoids \(g\), by [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md). The right \((ea)(ad)\) BF row has a zero-proper-port shore matching \(X_R\) selecting \(g,t_{ew}\), by [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md). These are actual matchings of one shore, though they come from two different rows.

**Theorem.** The shore paths of \(L\triangle W\) pair
\[
                            \boxed{DI\mid HJ},        \tag{1}
\]
and **both** exceptional same-side edges \(g,t_{ew}\) lie on its \(D\)--\(I\) path. In particular, every tight Hall witness \(S_H\) of [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md) contains both the \(I\)-port base \(i\) and the \(H\)-port base \(h\). Neither base can coincide with an endpoint of \(g\) or with the marked \(B\)-endpoint \(v\), and no singleton Hall witness survives. For an inclusion-minimal witness, [Note 290's host-cut identity](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) gives a cut of size \(6,8\), or \(10\), even when the required \(ad\) row has the right exterior.

## The two-row exchange

The only same-side edges in \(L\triangle W\) are \(g,t_{ew}\). At an alternating even closed cycle their number is even. For the pairings \(DI\mid HJ\) and \(DJ\mid HI\), each open path also contains an even number: its two port bases have opposite sides and the same matching selected both ports in the first pairing, or have the same side and different matchings selected the ports in the second. Thus the two exceptional edges occur together on one open path or on one closed cycle. The third pairing \(DH\mid IJ\) places exactly one exceptional edge on each open path, since each joins opposite sides and has endpoints selected by different matchings.

For \(DJ\mid HI\), switching the component containing both exceptional edges into \(W\) produces an actual two-port matching selecting \(g,t_{ew}\) with ports \(IJ\), \(DH\), or \(ID\), according as that component is the \(D\)--\(J\) path, the \(H\)--\(I\) path, or a closed cycle. All three fibres are empty by [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md), whose complete-fibre proof does not use a left \(ad\) row. Hence this pairing is impossible.

For \(DH\mid IJ\), suppose \(g\) lies on the \(D\)--\(H\) path. Switching that path into \(W\) gives ports \(IH\), retains \(t_{ev}\), and selects \(g\), contradicting [Note 283's bipartite balance](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md): its two \(B\)-based ports and \(t_{ev}\) contribute \(+3\), whereas selecting \(g\) requires \(-1\). Otherwise \(g\) lies on the \(I\)--\(J\) path. Switching that path into \(W\) gives ports \(DJ\) and selects \(g,t_{ev}\), the complete fibre forbidden by [Note 289](289-the-remaining-near-bipartite-core-has-an-empty-r-r-two-port-fibre.md). This pairing is impossible too.

For \(DI\mid HJ\), a cycle containing both exceptional edges can be switched into \(W\), giving the forbidden \(ID,g,t_{ew}\) fibre. If instead the \(H\)--\(J\) path contains both, switch it into \(W\). The resulting actual shore matching \(F\) has all four proper ports \(D,I,H,J\) and selects \(g,t_{ew}\). Compare \(F\) with the actual right-row zero-port matching \(X_R\), which also selects \(g,t_{ew}\). Switch the \(D\)-starting open path of \(F\triangle X_R\) into \(X_R\). It produces a two-port shore matching selecting \(g,t_{ew}\) and port \(D\), again impossible by Note 296, Theorem 2. Thus both exceptional edges must lie on the \(D\)--\(I\) path, proving (1).

## Consequence for the Hall corridor

Use \(K=(C-\{g,e\})-\{x,y\}\), with \(g=xy\), and let \(S_H\subseteq B\setminus\{x,y,v\}\) satisfy
\[
               |N_K(S_H)|=|S_H|+1,\qquad d,j\in N_K(S_H). \tag{2}
\]
[Note 305](305-every-tight-hall-corridor-must-contain-the-i-port-base.md) already proves \(i\in S_H\). Suppose \(h\notin S_H\). The matching \(L\) selects \(J,H,g,t_{ew}\); it matches every vertex of \(S_H\) through \(K\) and therefore saturates the exactly \(|S_H|\) neighbours \(N_K(S_H)\setminus\{j\}\). The matching \(W\) selects \(I,D,t_{ev}\) and avoids \(g\); every vertex of \(S_H\setminus\{i\}\) is also matched through \(K\). Starting at the \(W\)-selected \(D\) port, the alternating path of \(L\triangle W\) enters \(S_H\) on an \(L\)-edge, then alternates from \(S_H\setminus\{i\}\) to \(N_K(S_H)\) on a \(W\)-edge and back to \(S_H\) on an \(L\)-edge. It cannot leave this corridor before ending at \(I\) or \(J\). But (1) says it ends at \(I\) **and contains** \(g,t_{ew}\), neither of which belongs to \(K\). Contradiction. Thus \(h\in S_H\).

The two proper ports \(I,H\) both leave every such \(S_H\). If they have the same base, that base has only one internal incidence and cannot alone neighbour both distinct \(d,j\); otherwise the bases are two different vertices. Hence \(|S_H|\ge2\). Relative to [Note 290's](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) \(G_D=K-d\), any inclusion-minimal witness has at least two \(B\)-side port incidences \(\alpha\ge2\), and \(d\in N_K(S_H)\) gives \(\eta=e_K(S_H,d)\ge1\). Its connected Hall block therefore has \(|\delta(\Omega)|=2(\alpha+\eta)\ge6\), with the same note's upper bound ten. \(\square\)

Together with [Note 305's corridor route](305-every-tight-hall-corridor-must-contain-the-i-port-base.md), this leaves two different actual \(D\)--\(I\) transports at every Hall witness: the right-row \(U\triangle Y\) path stays in \(S_H\cup N_K(S_H)\), while the left-row \(L\triangle W\) path must leave it to traverse \(g,t_e\). Their matching masks have not been aligned into one BF row. This is the remaining cross-row interface for this profile.

The theorem removes the four-edge Hall-tree alternative in the real right-row branch without importing Note 296's conditional Theorem 1. Larger Hall witnesses containing both \(i,h\), the local collision \(v\in\{x,y\}\), other near-bipartite profiles, and Berge–Fulkerson remain open. The argument is hand-derived, with no enumeration or independent second-source check.
