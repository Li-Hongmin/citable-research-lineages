> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The indirect \(e\,bc:b\) and \(e\,ab:b\) prism root pair is impossible

Use the two-spoke prism exterior and forbidden \(e\)-labels \(AC,bc\) of [Notes 408–410](410-the-direct-bc-prism-root-cannot-enter-a-mixed-e-row.md). Suppose an actual six-perfect-matching BF row has forbidden triple \(P=e\,bc:b\) and allowed triple \(R=e\,ab:b\). Both zero-port rooted tree masks are \((A,C,a,B,c)\) on \((u_1,\ldots,u_5)\). No shore restriction is assumed.

> **Root-pair exclusion.** This row is impossible under complete exact Case-XII support for either allowed pentagon
> \[
> S_1=e-ab-AC-bc-Cc-e,\qquad S_2=e-ab-bc-AC-Cc-e.          \tag{1}
> \]

**Proof.** Let \(K\) be singleton-\(ab\), \(J\) singleton-\(bc\), and \(D_0,D_1\) singleton-\(e\). Since \(P=e\,bc\) is forbidden, the \(ab\)-starting path in \(R\triangle K\) must end at \(Cc\), the only other allowed \(e\)-label. At \(b\), \(K\) cannot use \(bc:b\), which would end at forbidden \(bc\); it takes \(bu_4\). A route from \(B\) through \(Bu_1\) can reach \(Cc\) only through \(Au_3,au_5,Cc:c\), but then \(b,c\) are both occupied and the \(bc\) mark has no matching half-edge. Thus \(K\) takes \(Bu_2,Cc:C\), and the complete path is wholly exterior:
\[
ab-t_{ab}-b-u_4-B-u_2-C-t_{Cc}-Cc.                         \tag{2}
\]
The mark and vertex slots then give \(K:AC:A,bc:c,au_5\), with ports \(p_1,p_3\). Switching (2) gives an allowed \(R'=e\,Cc:C\) with exactly the same complete shore matching as \(R\).

At \(b\), \(P\) takes \(bc:b\), \(R\) takes \(ab:b\), and \(K\) takes \(bu_4\). Singleton-\(bc\) cannot use \(bc:b\), so \(J\) takes the second \(bu_4\) slot and therefore \(ab:a\). The two singleton-\(e\) occurrences take the remaining \(ab:a,ab:b\) slots one each. Name the one using \(ab:a\) by \(E\). Its \(b\)-edge is necessarily \(bc:b\); at \(c\), the \(cu_5\) edge is saturated by \(P,R\) and \(bc:c\) by \(K\) and the other singleton-\(e\), so \(E\) takes \(Cc:c\). Covering \(C,A\) and the remaining mark forces
\[
E:\quad AC:C,\quad Cc:c,\quad bc:b,\quad ab:a,
       \quad Au_3,\quad p_5.                                  \tag{3}
\]
Since \(P,R\) saturate \(Bu_4\), its \(B\)-edge is \(Bu_1\) or \(Bu_2\).

Let \(q\) be the proper endpoint of the shore \(e\)-path in \(R\triangle E\). Path (2) is wholly exterior, so \(R'\triangle E\) has the same shore path and endpoint \(q\). Against \(R\), the \(p_5\)-arm reaches \(Cc\) through \(p_5-u_5-c-t_{Cc}-Cc\); against \(R'\), it reaches \(AC\) through \(p_5-u_5-c-t_{Cc}-C-t_{AC}-AC\).

For \(S_2\), the only allowed exchange of \(R'=e\,Cc\) sends \(e\) to \(AC\), so \(q=p_5\). But the same \(q\) sends \(R=e\,ab\) to \(ab\,Cc\notin S_2\), alongside unchanged \(P=e\,bc\notin S_2\). Hence \(S_2\) is impossible.

For \(S_1\), \(R=e\,ab\) requires its \(e\)-path to reach \(AC\), while \(R'=e\,Cc\) requires \(bc\). If \(E:Bu_1\), the two exterior arms exit at \(p_2,p_4\), respectively, contradicting their common shore endpoint \(q\). Thus \(E:Bu_2\); both required arms then exit at \(p_4\). Switch the complete \(e\)--\(AC\) path of \(R\triangle E\), producing allowed \(T=ab\,AC\) and singleton-\(AC\) \(E'\). Their relevant exterior slots are
\[
\begin{array}{c|ccccc|cccc}
 &u_1&u_2&u_3&u_4&u_5&AC&Cc&bc&ab\\\hline
T&A&B&a&p_4&c&C&s&s&b\\
E'&p_1&C&A&B&p_5&s&c&b&a
\end{array}                                                     \tag{4}
\]
Here \(T\) has terminals \(e,Cc,bc\), while \(E'\) has terminal \(AC\).

The \(ab\)-starting path of \(T\triangle K\) must end at \(bc\); ending at \(e\) or \(Cc\) would create forbidden \(e\,AC\) or \(AC\,Cc\) alongside \(P\). Its exterior arms exit at \(p_4,p_3\), respectively. Switch the complete \(ab\)--\(bc\) path, producing allowed \(U=AC\,bc\) and singleton-\(bc\) \(K'\). Now \(U\) uses \(AC:C,bc:c,Bu_2,bu_4\) and has \(Cc,ab\) terminal semiedges; \(K'\) has the \(bc\) terminal and \(ab:b\). The complete path
\[
AC-t_{AC}-C-u_2-B-u_4-b-t_{bc}-c-t_{Cc}-Cc             \tag{5}
\]
alternates between \(E'\) and \(U\), lies wholly outside the shore, and switches \(U\) to allowed \(V=Cc\,bc\). Finally,
\[
bc-t_{bc}-b-t_{ab}-ab                                     \tag{6}
\]
alternates between \(K'\) and \(V\), giving forbidden \(Cc\,ab\) while the original forbidden \(P=e\,bc\) remains unchanged. This excludes \(S_1\). All exchanges use complete perfect matchings and preserve load two. \(\square\)

The remaining \(e\,bc:b\) with \(e\,ab:a\) root pair, and rows using allowed \(e\,Cc\), still require analysis. The proof is hand-derived and awaits independent review.
