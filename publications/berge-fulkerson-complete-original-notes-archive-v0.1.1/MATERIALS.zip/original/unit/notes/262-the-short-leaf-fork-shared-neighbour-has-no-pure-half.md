> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The short-leaf fork shared-neighbour has no pure half

Continue the complete exact-Case-XII, minimum-host, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md). Take its \(|U|=4,r=4\) fork tree
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\qquad h_i=u_i\Sigma,
\]
with odd shore \(\Sigma\) of arbitrary order and cycle rank. Put the single shore mark at the short leaf \(P\), and the three cross marks at
\[
a:P\!:\!\Sigma,\qquad b:PR,\qquad c:LQ,\qquad d:QR. \tag{1}
\]
Assume \(ea,eb\) are the allowed neighbours of the internal shore mark \(e\). The marks \(a,b\) meet the same singleton \(P\).

**Theorem.** No rooted cubic five-pole with (1) has complete exact-Case-XII BF support. A pure \(ea\) half of the required real \((ea)(ab)\) row would need its singleton-\(e\) matching to change the shore \(e\)-path endpoint from \(c\) to \(d\) when the zero-port triple changes from state \(ea\) to \(eb\). The only possible short \(a\)--\(b\) switch and every compatible exterior singleton-\(e\) mask fail that endpoint exchange. This excludes one \(e\)-neighbour choice of the short-leaf fork marking at every shore order; the other neighbour choices and the long-leaf fork marking remain open.

## The forced short triple switch

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ab)\) row. As \(ab\in T\), its \(ea\) half \(X_a+Y_a+Z_e\) is pure \(S\). [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes \(X_a\) zero-port, and the matching of \(K-P\) is unique:
\[
X_a|_{\rm ext}=\{a:P,1O,2Q,3L,4R\}.                 \tag{2}
\]
By [Note 244's exterior-path argument](244-every-shore-mark-must-neighbour-the-internal-mark.md), the \(a\)--\(b\) path in \(X_a\triangle Y_a\) stays outside \(\Sigma\). Apart from the direct path \(a-t_a-P-t_b-b\), the tree offers only \(P-u_1-O-u_3-L-u_4-R\), ending through \(b:R\). The latter would make \(Y_a\) occupy \(L\) and \(R\). Then \(c=LQ\) must select \(Q\), while \(d=QR\) has neither endpoint free. Thus the direct path is forced. Switching it gives a state-\(eb\) zero-port triple with the **same complete shore mask** and the same \(K\)-edges:
\[
X_b|_{\rm ext}=\{b:P,1O,2Q,3L,4R\}.                 \tag{3}
\]

In either allowed order of the pentagon with neighbours \(a,b\) at \(e\), purity requires the shore \(e\)-path in \(X_a\triangle Z_e\) and \(X_b\triangle Z_e\) to end at \(c,d\) in opposite order. We show that no singleton-\(e\) exterior permits this.

## The singleton-\(e\) endpoint check

If \(Z_e\) uses \(b:P\), then it must use \(a:\Sigma\). The edges \(b:P\) are common to \(X_b,Z_e\), so their symmetric difference does not enter \(P\). Against \(X_a\), the only component affected by replacing \(a:P\) with \(b:P\) runs from the shore port \(a:\Sigma\) to terminal \(b\); against \(X_b\), that same port goes directly to terminal \(a\). Every other selected shore port has the **same** exterior route to \(c\) or \(d\) against both triples. Pairing \(e\) with \(a:\Sigma\) gives endpoints \(b,a\); pairing it with any other port cannot exchange \(c,d\).

If \(Z_e\) uses \(b:R\), then \(d\) must select \(Q\), \(c\) must select \(L\), and \(P\) is covered by \(a:P\) or \(1P\). The singleton-\(e\) shore quota leaves exactly five exterior masks, displayed by their remaining choices below. Each entry after a port is the terminal reached along its exterior alternating route against \(X_a,X_b\), respectively:

| \(a\) half and \(O\)-edge of \(Z_e\) | Selected proper shore ports and endpoint pairs |
|---|---|
| \(a:P,1O\) | \(h_2:(d,d),\ h_3:(c,c),\ h_4:(b,a)\) |
| \(a:P,2O\) | \(h_1:(d,d),\ h_3:(c,c),\ h_4:(b,a)\) |
| \(a:P,3O\) | \(h_1:(c,c),\ h_2:(d,d),\ h_4:(b,a)\) |
| \(a:\Sigma,2O\) | \(a:\Sigma:(d,a),\ h_3:(c,c),\ h_4:(b,d)\) |
| \(a:\Sigma,3O\) | \(a:\Sigma:(c,a),\ h_2:(d,d),\ h_4:(b,c)\) |

For instance, in the fourth row \(Z_e\) uses \(1P,2O,h_3,h_4\) in addition to \(a:\Sigma,b:R,c:L,d:Q\). Against (2), the route from \(h_4\) stops at terminal \(b\); against (3), it runs through \(R-t_b-P-u_1-O-u_2-Q-t_d\) and stops at \(d\). This gives \((b,d)\), as tabulated. The other rows follow the same alternating-path trace. None of the table's port pairs is \((c,d)\) or \((d,c)\). Hence no shore pairing of \(e\) can produce the two pure states required by the allowed pentagon. This contradicts the required row and proves the theorem. \(\square\)

The obstruction uses one real BF row and the complete matching switch that preserves its shore mask; it does not use a bound on \(|\Sigma|\) or its cycle rank. It says nothing about the other \(e\)-neighbour choices of (1), the long-leaf fork marking, the path tree, or the remaining Tutte profiles. The five-route table is hand-derived and has not received an independent check.
