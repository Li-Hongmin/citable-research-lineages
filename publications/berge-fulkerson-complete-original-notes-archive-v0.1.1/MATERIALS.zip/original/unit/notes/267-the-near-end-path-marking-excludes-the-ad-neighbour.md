> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The near-end path marking excludes the \(AD\) neighbour

Continue the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile of [Notes 245 and 265](265-the-endpoint-path-marking-with-an-end-to-end-cross-mark-is-impossible.md). For the \(|U|=r=4\) path tree write
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad h_i=u_i\Sigma,
\]
and choose one of the two remaining internal shore-mark placements:
\[
a:B\!:\!\Sigma,\qquad b:AD,\quad c:AE,\quad d:CE. \tag{1}
\]
The shore \(\Sigma\) has arbitrary odd order and unmarked cycle rank.

**Theorem.** In (1), complete exact-Case-XII perfect-matching support is impossible when \(ea,eb\in S\). Thus the second allowed neighbour of the internal mark \(e\) cannot be \(b=AD\). The choices \(ec\in S\) and \(ed\in S\), as well as the central shore-mark placement, are not decided here.

The [published Case-XII support](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ab)\) row. Write its six complete matching occurrences as
\[
X_a+Y_a+Z_e+U_{ab}+V_a+W_b=2\mathbf1.            \tag{2}
\]
Because \(ab\in T\), the \(ea\) half is pure \(S\); the same holds after exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\). [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) fixes the zero-port triple exterior
\[
X_a=\{a:B,1A,2C,3D,4E\}.                           \tag{3}
\]
The \(a\)--\(b\) terminal path in \(X_a\triangle Y_a\) is exterior by [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). It ends either at \(b:A\), using \(B-u_1-A\), or at \(b:D\), using \(B-u_2-C-u_3-D\). Completing the other cross marks gives precisely three singleton-\(a\) exteriors:
\[
\begin{aligned}
Y_{s3}&=\{b:A,c:E,d:C,1B,3D,h_2,h_4\},\\
Y_{s4}&=\{b:A,c:E,d:C,1B,4D,h_2,h_3\},\\
Y_{\ell}&=\{b:D,c:A,d:E,2B,3C,h_1,h_4\}.
\end{aligned}                                               \tag{4}
\]
The subscripts \(s3,s4\) distinguish the edge covering \(D\). Switching the displayed \(a\)--\(b\) terminal path in the triple produces zero-port triples with the *same complete shore matching* as \(X_a\):
\[
X_s=\{b:A,1B,2C,3D,4E\},\qquad
X_\ell=\{b:D,1A,2B,3C,4E\}.                       \tag{5}
\]
In a pure half, the shore \(e\)-path against \(X_a\) and the relevant triple in (5) must end at \(c,d\) in opposite order.

## Two short singleton occurrences

If both \(Y_a,V_a\) use \(Y_{s3}\), edge \(3D\) appears in \(X_a,Y_a,V_a\) and has load three. If both use \(Y_{s4}\), their doubled exterior edges force
\[
Z_e|_{\rm ext}=\{a:\Sigma,b:D,c:A,d:E,2B,3C,h_1,h_4\}. \tag{6}
\]
Against \((X_a,X_s)\), its selected proper ports have endpoint pairs \(a:\Sigma:(b,a),h_1:(c,c),h_4:(d,d)\). Thus the \(e\)-path cannot exchange \(c,d\).

If the two occurrences are \(Y_{s3},Y_{s4}\), their common doubled edges \(b:A,c:E,d:C,1B,h_2\) leave exactly two singleton-\(e\) exteriors. One is (6); the other is
\[
\{a:B,b:D,c:A,d:E,2C,h_1,h_3,h_4\}.            \tag{7}
\]
For (7), the port endpoint pairs against \((X_a,X_s)\) are \(h_1:(c,a),h_3:(b,c),h_4:(d,d)\). Again no port has pair \((c,d)\) or \((d,c)\). Hence neither mixed-short nor repeated-short case is possible.

## Two long singleton occurrences

If both occurrences use \(Y_\ell\), edge load two forces
\[
Z_e|_{\rm ext}=\{a:\Sigma,b:A,c:E,d:C,1B,4D,h_2,h_3\}. \tag{8}
\]
The pure \(ea\) half then has unit load on every proper exterior edge. It has this different, same-port decomposition of state \(ec\):

| Shore ports | Original \(ea\) exterior | Replacement \(ec\) exterior |
|---|---|---|
| \(\varnothing\) | \(X_a:\{a:B,1A,2C,3D,4E\}\) | \(X'_c:\{c:E,1A,2B,3C,4D\}\) |
| \(\{h_1,h_4\}\) | \(Y_\ell:\{b:D,c:A,d:E,2B,3C,h_1,h_4\}\) | \(Y'_c:\{a:B,b:A,d:E,2C,3D,h_1,h_4\}\) |
| \(\{e,a:\Sigma,h_2,h_3\}\) | \(Z_e\text{ from (8)}\) | \(Z'_e:\{a:\Sigma,b:D,c:A,d:C,1B,4E,h_2,h_3\}\) |

Every mask in this table is an exterior matching, and the two columns have equal total load on every proper exterior edge and terminal semiedge. Reuse the three *complete shore restrictions* of the original half with the replacement exteriors, slot by slot, retaining the opposite \(ab\in T\) half. This creates a real \((ec)(ab)\in T\)--\(T\) BF row, forbidden by exact Case XII. Hence the repeated-long case is impossible.

## One short and one long occurrence

Exchange \(Y_a,V_a\) in (2). Purity then requires the **same** shore \(e\)-port, paired against the unchanged shore masks of \(X_a,X_s,X_\ell\), to have exterior endpoint triple \((c,d,d)\) or \((d,c,c)\). We check every possible singleton-\(e\) exterior, without assuming a shore-internal matching. The cross-mark halves have only four disjoint orientations:
\[
I=(b:A,c:E,d:C),\quad II=(b:D,c:A,d:C),\quad
III=(b:D,c:A,d:E),\quad IV=(b:D,c:E,d:C).
\]
For each, the table lists all ways to cover the unmarked tree. An entry after a port is its terminal against \((X_a,X_s,X_\ell)\). Only ports that reach \(c\) or \(d\) against \(X_a\) are shown; the third proper port cannot serve the required \(e\)-path.

| Cross halves | \(a\)-half | Other \(K\)-edges of \(Z_e\) | Candidate port triples |
|---|---|---|---|
| I | \(B\) | \(3D\) | \(h_2:(d,d,a),\ h_4:(c,c,c)\) |
| I | \(B\) | \(4D\) | \(h_2:(d,d,a),\ h_3:(c,c,d)\) |
| I | \(\Sigma\) | \(1B,3D\) | \(h_2:(d,d,d),\ h_4:(c,c,c)\) |
| I | \(\Sigma\) | \(1B,4D\) | \(h_2:(d,d,c),\ h_3:(c,c,d)\) |
| I | \(\Sigma\) | \(2B,3D\) | \(a:\Sigma:(d,a,a),\ h_4:(c,c,c)\) |
| I | \(\Sigma\) | \(2B,4D\) | \(a:\Sigma:(d,a,a),\ h_3:(c,c,d)\) |
| II | \(B\) | \(4E\) | \(h_1:(c,a,c),\ h_2:(d,d,a)\) |
| II | \(\Sigma\) | \(1B,4E\) | \(a:\Sigma:(c,a,a),\ h_2:(d,d,c)\) |
| II | \(\Sigma\) | \(2B,4E\) | \(h_1:(c,d,c),\ a:\Sigma:(d,a,a)\) |
| III | \(B\) | \(2C\) | \(h_1:(c,a,c),\ h_4:(d,d,d)\) |
| III | \(B\) | \(3C\) | \(h_1:(c,a,c),\ h_4:(d,d,d)\) |
| III | \(\Sigma\) | \(1B,2C\) | \(a:\Sigma:(c,a,a),\ h_4:(d,d,d)\) |
| III | \(\Sigma\) | \(1B,3C\) | \(a:\Sigma:(c,a,a),\ h_4:(d,d,d)\) |
| III | \(\Sigma\) | \(2B,3C\) | \(h_1:(c,c,c),\ h_4:(d,d,d)\) |
| IV | \(B\) | \(1A\) | \(h_2:(d,d,a),\ h_4:(c,c,c)\) |
| IV | \(\Sigma\) | \(1A,2B\) | \(a:\Sigma:(d,a,a),\ h_4:(c,c,c)\) |

The remaining incident \(h_i\)-edges in each row are forced by the matching condition, so the table covers all 16 masks. None contains \((c,d,d)\) or \((d,c,c)\). This rules out any one-short, one-long row and completes the theorem. \(\square\)

The argument uses one required real BF row, complete matching exchange, and a same-port splice; it does not restrict \(\Sigma\). It does not decide the other two \(e\)-neighbour choices for (1), the central path-tree marking, larger barriers, other Tutte profiles, or Berge–Fulkerson.
