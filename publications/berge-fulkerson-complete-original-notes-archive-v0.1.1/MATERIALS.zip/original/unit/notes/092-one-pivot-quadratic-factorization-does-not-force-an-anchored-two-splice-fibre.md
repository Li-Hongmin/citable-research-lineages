> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One pivot quadratic factorization does not force an anchored two-splice fibre

The cubic relations obtained by subtracting consecutive repeated-extension
pivot rows do not supply the dependent section left open by
[Note 091](091-dependent-two-splice-gate-splits-into-sign-feasibility-and-four-row-sections.md).
This already fails in the exact-forty common-binary system of
[Note 085](085-common-binary-incidence-does-not-force-a-two-step-carrier-section.md),
even when one relation has a two-step factorization by actual token
identities.  Thus arbitrary quadratic connectivity in one pivot fibre cannot
replace the occurrence-labelled carrier condition of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).

## The pivot relation and its factorization

The first two literal pivot rows are

\[
\begin{aligned}
q_{13}+r_{45}+A+X+C+D&=2\mathbf1,\\
q_{14}+r_{23}+A+B+X+C&=2\mathbf1.
\end{aligned}                                      \tag{1}
\]

After cancelling the three pointwise common singleton occurrences
\(A,X,C\), they give

\[
q_{13}+r_{45}+D=q_{14}+r_{23}+B.                  \tag{2}
\]

Retain the 125 tokens and 48 binary coordinates of Note 085 and adjoin one
class-1 singleton token \(A'\) with incidence vector

\[
100000000010111111111110111110111111111111111111.
                                                               \tag{3}
\]

Coordinatewise,

\[
A'=r_{45}+D-q_{14}=B+r_{23}-q_{13}.               \tag{4}
\]

In particular, (2) has the two actual pair-sum moves

\[
(r_{45},D,q_{13})
\longleftrightarrow(A',q_{14},q_{13})
\longleftrightarrow(B,q_{14},r_{23}).             \tag{5}
\]

Adding back \(A,X,C\) turns (5) into two paired splices through an actual
intermediate six-token double-cover row.  All literal identities in the
four original pivot rows remain unchanged.

## Exact negative support and the anchored fibres survive

The one-token extension retains the designated rows of all fifteen
\(S\)--\(S\) and all twenty-five \(S\)--\(T\) types.  Exhaustive integer
decomposition on the fixed coordinates finds no \(T\)-loop and no
\(T\)--\(T\) row.  The pool contains no all-terminal token, so it has no
\(A=(12345)\) cover.  Its boundary support is therefore still exactly the
forty Case-XII pair types.

Now consider the two targets genuinely anchored by the literal pivot data,
\(BDXY\) and \(ACXY\).  Their four endpoint replacements give twenty forced
companion vectors of the form

\[
N+P-\widehat P,                                   \tag{6}
\]

and their unrestricted preparatory branches give four forced-intermediate
vectors.  Note 085 realizes none of these twenty-four vectors.  The new
token (3) is distinct from all of them.  Hence every sequential and every
forced-intermediate Note-082 fibre for both anchored targets remains empty,
despite (5).

This proves the strict common-binary nonimplication

\[
\begin{split}
&\text{exact forty-type support and an actual quadratic factorization}\\
&\qquad\not\Longrightarrow
\text{a literal anchored dependent two-splice fibre}.
\end{split}                                       \tag{7}
\]

## The missing condition is cross-fibre occurrence coupling

For a load vector \(L\), let \(\Gamma_3(L)\) be the graph whose vertices
are actual three-token decompositions of \(L\), with an edge when one
occurrence is retained and the other two are replaced by an equal-sum pair.
Relation (2) concerns

\[
L=2\mathbf1-A-X-C.                                \tag{8}
\]

A quadratic factorization only connects its two displayed vertices in
\(\Gamma_3(L)\).  In contrast, an anchored target asks for two compatible
replacements in one fixed six-occurrence carrier row: the literal anchors
must remain pointwise fixed, and the exact companion produced by the first
move must survive the second sign test.  These are different fibres and
different occurrence quantifiers.

If “preserving identities” is strengthened to require precisely that
same-row, pointwise-fixed, two-position path, then Notes 082 and 091 show
that the hypothesis is already the desired dependent two-splice fibre.  It
does not follow from ordinary quadratic factorization.

The construction in this note is not a cubic 5-pole: its coordinates have
no common trivalent vertex partition, and its token pool is not the complete
perfect-matching family induced by such a graph.  Consequently (7) does not
decide the real exact-Case-XII implication.  A positive theorem must use the
common cubic vertex partition and graph-induced full perfect-matching
closure to couple the pivot quadratic component to the anchored carrier
section.

The fixed calculation and Omen resource record are in the
[verification bundle](../computations/bundles/pivot-quadratic-factorization-common-binary-boundary/README.md).
