> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cross-column Helly gate for singleton-fibre joins

## Statement

Fix four supported boundary cells (J=\{a,d_1,d_2,d_3\}), with (a) an anchor cell. Let (x) be an actual singleton tuple in the anchor fibre \hat\Pi_a. For each (d_j), let (E_{d_j}(x)) be the set of singleton tuples in the missing coordinate that agree with (x) on the coordinates shared by cells (a) and (d_j).

The anchor tuple extends to a common four-column section exactly when
\[
\bigcap_{j=1}^3 E_{d_j}(x)\ne\varnothing.
\]

If the singleton alternating-cycle exchange graph on the missing coordinate is a tree, each (E_{d_j}(x)) is a nonempty connected subtree, and the three fibres are pairwise intersecting, then the intersection is nonempty by the Helly property for subtrees of a tree. Hence the four-column join exists and yields the (A=(12345)) cover by the established singleton-load construction.

## Boundary

The carrier identities and Tait-empty overlap conditions do not imply the hypotheses above. In particular, pairwise intersection is insufficient when the exchange graph has cycles, and no general real-pole theorem currently forces a tree or convex exchange structure. Thus this is a strict sufficient condition, not an exclusion of Cases IV/IX/XI.

This note records the exact remaining interface: prove tree/convex exchange structure for the common perfect-matching incidence, or construct a real pole with saturated carriers and empty four-column joins.
