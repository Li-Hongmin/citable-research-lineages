> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The cycle--leaf connector excludes its two cycle-shore \(e\)-neighbours

Use the \(|U|=3,r=2\) exterior of [Notes 234](234-three-exterior-graphs-for-the-first-surviving-one-shore-barrier.md) and [236](236-girth-five-leaves-four-marked-exterior-quotients-at-the-first-barrier.md). Name the barrier vertices \(u_1,u_2,u_3\), the cycle singleton vertices \(w_{12},w_{23},w_{31}\), and the pendant singleton \(p\), so the unmarked exterior edges are
\[
u_1w_{12},\ u_2w_{12},\ u_2w_{23},\ u_3w_{23},\
u_3w_{31},\ u_1w_{31},\ u_1p,\quad h_2=u_2C,\ h_3=u_3C.
\]
Write \(q=w_{23}\). Note 236 forces the sole exterior \(W\)--\(W\) mark to join \(p\) to \(q\). Name the four exterior marks
\[
a:p-C,\qquad b:p-q,\qquad c:w_{12}-C,\qquad d:w_{31}-C;
\]
the fifth mark \(e\) is internal to the odd shore \(C\).

**Theorem.** Complete exact Case-XII support is impossible if the two neighbours of \(e\) in the allowed missing-pair pentagon are \(c,d\). This excludes both relative orders of the other two marks, at every order and cycle rank of \(C\).

**Proof.** Choose an actual \(S\)--\(T\) BF row and let \(D\) be its \(S\)-half. A \(T\)-decomposition of \(D\) would make a forbidden \(T\)--\(T\) row with the fixed complementary half, so [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) gives \(\mathcal R(D)=S\). Decompose the same load at state \(ec\):
\[
D=X+Y_c+Z_e,\qquad
\partial X=\{a,b,d\},\quad\partial Y_c=\{c\},\quad\partial Z_e=\{e\}.               \tag{1}
\]
By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the \(ec\)-triple \(X\) uses no proper shore port. Its active mark \(c\) must select \(w_{12}\). The graph \(K-w_{12}\) has a unique perfect matching by Note 234, so the complete exterior of \(X\) is
\[
c:w_{12},\qquad u_1p,\qquad u_2q,\qquad u_3w_{31}.       \tag{2}
\]

The alternating path beginning at terminal \(c\) in \(X\triangle Y_c\) must end at \(d\), since \(ed\) is the only other allowed pair incident with \(e\). At \(w_{12}\), \(Y_c\) must use \(w_{12}u_1\) or \(w_{12}u_2\). The \(u_1\)-choice follows (2) to \(p\), where \(Y_c\) can only use \(a:p\) or \(b:p\), ending at \(a\) or \(b\); thus it is forbidden. The path takes \(w_{12}u_2\), follows (2) to \(q\), and cannot use \(b:q\), which would end at \(b\). It takes \(qu_3\), follows (2) to \(w_{31}\), and must use \(d:w_{31}\) to end at \(d\); the alternative \(w_{31}u_1\) would follow (2) to \(p\) and end at \(a\) or \(b\). Hence the **same** singleton matching \(Y_c\) contains
\[
w_{12}u_2,\qquad qu_3,\qquad d:w_{31}.                  \tag{3}
\]

Because \(Y_c\) has terminal boundary \(\{c\}\), it must match \(t_a,t_b\) through proper half-edges. Vertex \(q\) is already matched by \(qu_3\), so \(b\) must select \(p\). That occupies \(p\), so \(a\) must select its shore endpoint. Now all three unmarked neighbours of \(u_1\) are occupied in \(Y_c\): \(w_{12}\) by \(u_2\), \(w_{31}\) by \(d\), and \(p\) by \(b\). Since \(u_1\) has no edge to \(C\), it cannot be matched. This contradicts \(Y_c\)'s being a perfect matching. \(\square\)

The obstruction uses only the exterior quotient and one saturated actual half-load. It leaves other neighbour pairs of \(e\) in this marked quotient, the two path quotients and surviving claw orders, and all other deficient-core profiles for full matching closure.
