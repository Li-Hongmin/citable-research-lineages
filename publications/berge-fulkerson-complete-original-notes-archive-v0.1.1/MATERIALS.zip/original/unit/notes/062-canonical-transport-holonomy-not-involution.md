> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical D5 transport holonomy is not universally trivial

For the matching-derived transport maps on the five Case-XII boundary relations, the only general base-point identity is conjugacy
\[
h_{t+1}=f_t h_t f_t^{-1},
\]
and reverse transport gives (h_t^{-1}). Neither identity forces (h_t) to be an involution or to have a fixed point.

An explicit simple connected cubic 5-pole on 11 internal vertices (27 perfect matchings, exact Tait set (S=\{13,14,24,25,35\})) has canonical holonomy on (E_0=R_{14}) equal to a 3-cycle. A second 11-vertex pole realizes a 4-cycle. Thus neither a universal involution law, universal fixed-point law, nor universal parity/sign law can be used to prove the Case-XII join.

The first pole nevertheless has a compatible pentagon, showing that canonical deterministic transport is strictly stronger than existence of a compatible pentagon: fixed point implies compatibility, but the converse fails.

This closes the canonical-holonomy route. The explicit edge lists, transport orbits, and independent reproduction program are retained in `scratch/holonomy_cycle_theorem_leaf.md` and `scratch/compute_transport_cycle_types.py`.
