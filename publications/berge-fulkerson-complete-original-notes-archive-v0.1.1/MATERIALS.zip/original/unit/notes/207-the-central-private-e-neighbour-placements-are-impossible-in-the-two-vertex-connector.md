> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central--private \(e\)-neighbour placements are impossible in the two-vertex connector

Retain the genuine two-vertex connector and labels of [Notes 204--206](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md). This note excludes the two cyclic orders in which the internal mark \(e\) is adjacent in the allowed missing-pair pentagon to the central mark \(a\) and one private mark \(b\). Reflection \(b\leftrightarrow c\), \(u_1\leftrightarrow u_2\) then also excludes adjacency to \(a,c\). The result uses actual complete perfect matchings, not an assumed shore identity.

**Theorem.** In an exact-Case-XII pole with this connector, \(e\) cannot have neighbour pair \(\{a,b\}\) or \(\{a,c\}\) in \(S\).

Choose an actual \(S\)--\(T\) row and its \(S\)-half \(A\). By [Note 055](055-half-load-column-saturation-and-case-xii-compression.md), \(\mathcal R(A)=S\). Decompose the same full load at state \(ea\): let \(X\) be the triple, \(Y\) singleton-\(a\), and \(Z\) singleton-\(e\). [Note 205](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md) fixes the exterior of \(X\) to \(a:w_0, u_1w_1,u_2w_2\), with one exposed \(e\)-endpoint in the shore.

Since \(eb\in S\) and \(ec,ef\in T\), the terminal-\(a\) path of \(X\triangle Y\) must end at \(b\). Starting from \(w_0\), a route through \(u_2\) would end at \(c\) or \(f\), both forbidden. The route through \(u_1\) must continue from \(w_1\) through the \(b\)-half, since the \(f\)-half would end at forbidden \(f\). Thus the forced \(a\)--\(b\) path is wholly exterior. Switching it gives a triple \(X'\) at state \(eb\), with exterior \(b:w_1,u_1w_0,u_2w_2\), and
\[
X'|_C=X|_C,\qquad Z\text{ unchanged}.               \tag{1}
\]

There are only two cyclic orders, up to reversal:
\[
\begin{array}{c|c|c|c}
 &S&T&\text{required partners of the }e\text{-terminal}\;\;X\triangle Z,\ X'\triangle Z\\\hline
\mathrm I&e-a-c-f-b-e&\{ec,ef,af,ab,bc\}&c,\ f\\
\mathrm {II}&e-a-f-c-b-e&\{ec,ef,ab,ac,bf\}&f,\ c.
\end{array}                                                    \tag{2}
\]
For example, in form I, an \(e\)-path ending at \(c\) switches \(ea\) to \(ac\in S\), while endings at \(b\) or \(f\) give forbidden states. After (1), only an ending at \(f\) gives an \(S\)-state. The other row follows in the same way.

To compare complete paths, use the ten exhaustive singleton-\(e\) exterior routes \(L0\)--\(L4,R0\)--\(R4\) in [Note 206, (3)](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md). In the table below, \(c_0,f_0\) are the shore ports reached from terminals \(c,f\) in the exterior of \(X\triangle Z\), and \(f_1,c_1\) are the ports reached from \(f,c\) in \(X'\triangle Z\). Each exterior difference matches its three outer terminal ends separately to \(Z\)'s three shore ports; the \(e\)-terminal reaches the unchanged \(e\)-port directly. These are distinct port **edges**, even when two meet the same core vertex.
\[
\begin{array}{c|cc|cc}
Z\text{ route}&c_0&f_1&f_0&c_1\\\hline
L0&c&b&a&c\\
L1&a&b&h_1&h_1\\
L2&h_2&b&a&h_2\\
L3&c&b&h_1&c\\
L4&h_2&b&h_1&h_2\\
R0&c&b&a&c\\
R1&c&h_1&a&c\\
R2&c&h_2&h_2&c\\
R3&c&h_2&h_2&c\\
R4&c&h_2&h_2&c.
\end{array}                                                    \tag{3}
\]
For instance, in route \(L1\), the exterior \(f\)-path of \(X\triangle Z\) ends at \(h_1\), while the \(c\)-path of \(X'\triangle Z\) also ends at \(h_1\). In route \(R2\), the former ends at \(h_2\), whereas the latter ends at \(c\). Direct tracing of the five-vertex exterior path gives every row.

In form I the fixed shore restriction of \(X\triangle Z=X'\triangle Z\) would have to pair its \(e\)-port first with \(c_0\), then with \(f_1\). The first two columns of (3) differ in every row, so form I is impossible.

In form II the required partners are \(f_0,c_1\). The last two columns of (3) agree **only in route \(L1\)**. Hence every \(S\)-only half-load in form II, when decomposed at \(ea\), has \(Z\) in this route:
\[
Z:\quad f:w_1,\ c:w_2,\ h_1,\ u_2w_0;
\qquad \text{shore ports }\{a,b,h_1\}.              \tag{4}
\]
The forced \(a\)--\(b\) path puts \(u_1w_0,b:w_1\) in \(Y\). Since \(Y\) must also match \(t_f\) and \(w_1\) is occupied, it uses \(f:w_2\), forcing \(u_2v_2\) at \(u_2\). Thus **every** such \(S\)-only half-load has the unit exterior connector load, in particular
\[
\varnothing\ne\mathcal R(D)\subseteq S
\quad\Longrightarrow\quad D(u_1v_1)=1.             \tag{5}
\]

Finally take the required actual \((ea)(bf)\) row in form II, using the \(ea\)-decomposition \(X,Y,Z\) of its \(S\)-half. Name its \(bf\)-triple \(U\), singleton-\(b\) \(V\), and singleton-\(f\) \(W\). By (4)--(5), both complementary halves load every exterior edge once. [Note 205](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md) permits the \(bf\)-triple to expose \(b\), \(h_1\), or \(h_2\). If it exposes \(b\) or \(h_1\), its symmetric difference with \(X\) has the wholly exterior terminal path \(a\)--\(f\). Switching the two triples along it gives the forbidden \((ef)(ab)\), since \(ef,ab\in T\). Therefore \(U\) exposes \(h_2\) and uses \(b:w_1,f:w_2,u_1w_0\). In the complementary unit-load half, \(W\) must use \(u_1w_1\) at \(w_1\), and \(V\) uses \(h_1=u_1v_1\).

Now \(X\triangle U\) has the exterior terminal component \(a-w_0-u_1-w_1-b\). Switch \(X,U\) along it to obtain triples \(X''\) at state \(eb\in S\) and \(U''\) at state \(af\in S\). Regroup the same six full matching occurrences as
\[
D_{eb}=X''+Z+V,\qquad D_{af}=U''+Y+W,
\qquad D_{eb}+D_{af}=2\mathbf1.                       \tag{6}
\]
Their \(u_1v_1\)-loads are respectively \(2\) and \(0\), because \(X''\) uses \(u_1w_0\), \(U''\) uses \(u_1w_1\), and \(Z,V\) both use \(u_1v_1\). Both halves have an \(S\)-state but violate (5). Each therefore has some \(T\)-state. Decomposing the two complementary full loads at those states gives a forbidden genuine \(T\)--\(T\) row. This excludes form II and proves the theorem. \(\square\)

Together with [Note 206](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md), the internal mark \(e\) can no longer be adjacent to the central mark \(a\) in the allowed pentagon. The remaining neighbour-pair types are \(\{b,c\}\) and \(\{b,f\}\) up to the exterior reflection; their full matching closure is still open.
