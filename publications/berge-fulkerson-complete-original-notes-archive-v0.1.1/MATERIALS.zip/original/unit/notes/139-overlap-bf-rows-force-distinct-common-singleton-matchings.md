> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Overlapping BF rows force distinct common-terminal singleton matchings

The complete Case-XII support contains overlapping \(S\)--\(T\) cells. Each actual row of one of these cells has two singleton occurrences at the terminal common to its two missing pairs. **Their complete perfect-matching masks must differ.** Otherwise the row itself yields a forbidden \(T\)-Tait state. This strengthens the nonempty row-transport fibres of [Note 057](057-overlap-cells-transport-singleton-fibres-into-d5.md), without assuming that an exact-Case-XII pole exists.

## Duplicated-singleton theorem

Let \(H\) be a cubic five-pole and let \(i,j,k\) be distinct terminals. Suppose an actual six-perfect-matching double cover has type \((ij)(ik)\), with triple-boundary matchings \(Q_{ij},R_{ik}\), singleton occurrences \(M_i^0,M_i^1,M_j,M_k\), and complete edge-load identity
\[
Q_{ij}+R_{ik}+M_i^0+M_i^1+M_j+M_k=2\mathbf1.       \tag{1}
\]
If \(M_i^0=M_i^1\) as complete masks, then **both** \(ij\) and \(ik\) are actual Tait states of \(H\).

**Proof.** Write \(M=M_i^0=M_i^1\). Every edge of \(M\) is already covered twice in (1), so the other four matchings avoid it. At every cubic vertex, the two edges outside \(M\) each carry two of the four occurrence colours
\[
\Omega=\{Q_{ij},R_{ik},M_j,M_k\},
\]
and their colour pairs are complementary in \(\Omega\). Consequently the labels alternate between a pair and its complement along every component of \(H-M\); in particular, every closed component is even and can be properly two-edge-coloured.

Let \(a,b\) be the two terminals outside \(\{i,j,k\}\). The four exposed terminal labels of \(H-M\) are
\[
\begin{array}{c|cccc}
\text{terminal}&a&b&j&k\\\hline
\text{pair}&\{Q_{ij},R_{ik}\}&\{Q_{ij},R_{ik}\}&
\{R_{ik},M_j\}&\{Q_{ij},M_k\}.
\end{array}                                                 \tag{2}
\]
The pair at \(a,b\) is neither equal nor complementary to the pair at \(j\) or \(k\). The latter two pairs are complementary. As a path in \(H-M\) has endpoint labels equal or complementary, its two open components must join \(a\) to \(b\) and \(j\) to \(k\), respectively.

Two-colour each component of \(H-M\), and give \(M\) a third colour. On the \(a\)--\(b\) path the new terminal colours at \(a,b\) agree; on the \(j\)--\(k\) path they differ. The phase of the latter path can be chosen independently. One choice makes the threefold terminal colour occur at \(a,b,j\), so its missing pair is \(ik\); the other makes it occur at \(a,b,k\), so its missing pair is \(ij\). These are two actual three-edge-colourings of \(H\), proving the claim. \(\square\)

## Exact Case-XII consequence

Put \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\), as in the [2026 Case-XII appendix](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). A \(T\)-Tait state would give a forbidden \(T\)-loop BF cover by doubling its three colours. Hence, in **every** actual BF row of an overlapping cell \((ij)(ik)\) with \(ij\in S\), \(ik\in T\),
\[
\boxed{M_i^0\ne M_i^1.}                                    \tag{3}
\]
Their symmetric difference is therefore a nonempty union of proper even alternating cycles. On each cycle the two colours may be swapped independently, giving at least two distinct complete class-\(i\) masks among the ordered actual rows that keep \(Q_{ij},R_{ik},M_j,M_k\) fixed. In particular, each of the five row-transport relations \(\Theta_i\) used in Note 057 has at least two distinct first-coordinate singleton identities. This conclusion uses only the absence of the relevant \(T\)-loop; all forty positive types and the all-terminal exclusion are unnecessary.

Full exact Case-XII support has an overlapping \(S\)--\(T\) cell at every terminal. Thus its complete singleton perfect-matching family \(\mathcal P_i\) satisfies \(|\mathcal P_i|\ge2\) for all five \(i\), even if no Tait colouring exists.

For the row of [Note 138](138-pairing-change-forces-an-unalignable-cycle-with-a-three-edge-owner-certificate.md), equation (3) says \(Z_3\ne Y_3\). Exchanging those two class-three occurrences between its half-loads and switching the forced \(3\leftrightarrow2\) path of \(U_{35}+Y_3\) gives another actual right row
\[
q'_{25}+B'_2+D_5+r_{34}+Z_3+C_4=2\mathbf1,
\qquad q'_{25}+B'_2=U_{35}+Y_3.                       \tag{4}
\]
The other two possible endpoints would give a \(T\)-state \(15\) or \(45\) opposite the fixed \(T\)-state \(34\). The original within-half row has \(q_{25}+B_2=U_{35}+Z_3\), so (3) makes the two complete \(q+B\) loads in these right rows **different**, while \(D_5,r_{34},C_4\) stay identical. This is the general full-mask version of the occurrence exchange used conditionally in [Note 130](130-the-mixed-side-right-row-exceptional-class-three-forces-an-s-tait-state.md).

Distinct singleton identities within each row do not synchronize different rows. The two-token relation model of [Note 058](058-row-transports-do-not-force-a-four-column-section.md) already has two choices in every fibre yet no four-column join. Nor does (3) rule out the unalignable critical cycle of Note 138. [Note 140](140-disjoint-singleton-phase-has-a-unique-critical-six-cycle-owner-pattern.md) gives a real five-pole in which distinct same-boundary singleton masks avoid an unalignable cycle, and classifies the six-cycle pattern if such disjointness occurs in a pairing-critical Case-XII row. That real pole lacks the exact Case-XII negative support and the critical terminal pairing. The remaining question is whether those global conditions couple the \(Z_3\triangle Y_3\) phase cycle to the pairing-changing \(U_{35}\triangle P_{35}\) cycle or to the common \(B_2+C_4\) seed.

The nonidentity cannot be confined to a closed two-sum factor. Indeed, if \(H=H_0\oplus J\) with \(J\) terminal-free, the row (1) projects to an actual BF row of \(H_0\) and a BF cover of \(J\). By [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md), the negative \(T\)-loop support is inherited by \(H_0\). Applying (3) there shows that the two class-\(i\) matchings have distinct **exterior projections**. Hence at least one component of their symmetric difference reaches the exterior or crosses the two-sum interface; cycles wholly inside \(J\) cannot account for all of it.
