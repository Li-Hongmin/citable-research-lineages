> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complement transfer excludes the t-port four-vertex Hall placement

Continue the genuine left \((ea)(ac)\) and right \((ea)(ad)\) rows
in the noncollision, complete exact-Case-XII \(R_0=DJ\)
near-bipartite branch. Use the four-vertex Hall incidence graph
of [Note 315](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md):
\[
 S=\{h,k,\ell,m\},\quad T=\{o,r,s,t\},\qquad
 o\{h,k,\ell\},\ r\{h,m\},\ s\{k,m\},\ t\{\ell,m\},
 \quad \ell d.                                             \tag{1}
\]
Let \(H\) be at \(h\), \(P\in\{A,I\}\) at \(k\),
\(J\) at \(t\), and \(D\) at \(d\). Write \(r\rho\)
and \(s\sigma\) for the two third edges at \(r,s\) that
leave the displayed eight-vertex block.

**Theorem.** Neither \((P,j)=(A,t)\) nor \((I,t)\)
is possible. With [Notes 316–317](317-complement-transfer-excludes-the-a-s-four-vertex-hall-placement.md),
the first-order four-vertex \((\alpha,\eta)=(2,1)\)
Hall incidence shape can only have \(j=r\), if it occurs at all.

**Proof.** By [Note 316](316-zero-port-phase-closure-restricts-the-four-vertex-hall-block.md),
the actual right zero-port matching \(X_R(g,t_{ew})\) uses
\(\ell d\). Since \(t\) must then be matched to \(m\)
and \(o\) must be matched internally, its restriction has
one of two shapes:
\[
 \{\ell d,mt,ho,ks\},\qquad
 \{\ell d,mt,hr,ko\}.                                    \tag{2}
\]
The first has the complete complementary proper-port path
\(P-k-o-\ell-t-J\), forbidden by
[Note 285's zero-port pairing table](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md).
Thus \(X_R\) has the second shape in (2).

The left four-port matching \(Z_L(EAID)\) selects both
\(P\) at \(k\) and \(D\) at \(d\); it selects neither
\(H\) nor \(J\). As \(o,t\) have no available outward
matching edge, its three remaining \(S\)-vertices have
exactly these choices:
\[
 \{ho,\ell t,mr\},\quad
 \{ho,\ell t,ms\},\quad
 \{hr,\ell o,mt\}.                                       \tag{3}
\]
In the first choice, \(X_R\triangle Z_L\) contains the
complete path
\(D-d-\ell-t-m-r-h-o-k-P\). In the third,
it contains \(D-d-\ell-o-k-P\). Switching either path
into \(X_R\) gives an actual \(DP,g,t_{ew}\)
two-proper-port shore matching, contrary to
[Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md).
Hence \(Z_L\) uses \(ho,\ell t,ms\), in particular edge
\(ms\).

Take either left singleton-\(a\) shore matching \(Y\).
By [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md),
it selects \(H,J,g,t_{ew}\) and its shore complement pairs
\(EI\mid AD\). The selected \(H,J\) ports cover \(h,t\),
leaving exactly three possible local shapes:
\[
 Y_1:\ \{ko,\ell d,mr\},\qquad
 Y_2:\ \{ko,\ell d,ms\},\qquad
 Y_3:\ \{ks,\ell o,mr\}.                                \tag{4}
\]
For \(Y_3\), the full local alternating path
\(H-h-r-m-t-J\) in \(Y_3\triangle X_R\) can be
switched into \(Y_3\). The result is an actual zero-port
\((g,t_{ew})\) matching using the full internal phase
\(\{hr,ks,\ell o,mt\}\), with no \(\ell d\). This
contradicts Note 316.

For \(Y_1\), the same switch gives a zero-port matching
\(N\) with the local edges of \(X_R\), without changing
any edge outside that local \(H\)--\(J\) path. Before
the switch, the complement of \(Y_1\) has the complete
local segment
\[
                P-k-s-m-t-\ell-o-h-r-\rho.                   \tag{5}
\]
The edges \(H,J,\ell d,s\sigma\) are selected by \(Y_1\),
so \(r\rho\) is the only complement exit of this segment
from the displayed block. Note 301 therefore forces its
unchanged exterior continuation to end at \(D\) if \(P=A\),
and at \(E\) if \(P=I\).

After the switch, the complement of \(N\) contains the
complete local \(H\)--\(J\) path
\(H-h-o-\ell-t-J\), while its \(P\)-starting segment is
\(P-k-s-m-r-\rho\). The latter retains the same exterior
continuation from \(\rho\). But for a zero-port
\((g,t_{ew})\) matching with an \(HJ\) complement path,
Note 285 permits only \(EA\mid ID\mid HJ\). It requires
\(A\) to pair with \(E\) and \(I\) with \(D\), the
opposite of the inherited pairing in either \(P\) case.
Thus \(Y_1\) is impossible.

Both actual left singleton occurrences \(Y_L,V_L\) must
therefore have shape \(Y_2\). Each selects \(ms\), while
the left four-port matching \(Z_L\) also selects \(ms\).
One edge would be used by three slots of a BF row,
contradicting its required load two. \(\square\)

The remaining \(j=r\) positions are excluded in
[Note 319](319-no-four-vertex-six-cut-hall-block-in-the-right-dj-branch.md).
Larger Hall blocks, the \((1,2)\) allocation, collisions,
other core profiles, and Berge–Fulkerson remain open. The
argument uses actual matchings and complete-family fibre
rules; it is hand-derived and awaits independent checking.
