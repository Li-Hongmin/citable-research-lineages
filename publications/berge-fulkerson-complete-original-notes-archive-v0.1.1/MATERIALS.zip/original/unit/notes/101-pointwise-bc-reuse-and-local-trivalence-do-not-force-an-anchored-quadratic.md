> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pointwise \(BC\) reuse and local trivalence do not force an anchored quadratic

The cross-column condition left by
[Note 093](093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)
does not follow from the saturated carrier rows, pointwise reuse of the
literal occurrences \(B,C\), and common trivalent incidence equations.  A
five-vertex local countermodel satisfies all these equations, has no selected
all-terminal or \(T\)--\(T\) row, and has both endpoint projections empty.
Thus the remaining positive statement must use the global pairing of proper
incidences into edges and the complete graph-induced perfect-matching family.

## The joined rows

Fix

\[
 H_{23}=r_{23}+B+X,\qquad K_{23}=2\mathbf1-H_{23}.
\]

The saturated column consists of one row for every

\[
 S=\{13,14,24,25,35\},
\]

and its state-\(14\) row is

\[
 q_{14}+A+C+r_{23}+B+X=2\mathbf1.                 \tag{1}
\]

The cross-column row is

\[
 q'_{25}+r_{34}+B+Y+C+D=2\mathbf1,                \tag{2}
\]

where the occurrences \(B,C\) in (1) and (2) are pointwise identical.
Cancelling them gives only the quartic trade

\[
 q_{14}+A+r_{23}+X=q'_{25}+r_{34}+Y+D.             \tag{3}
\]

Its boundary loads agree, so the boundary classes do not factor (3).  The
desired first splice would require the additional quadratic factor

\[
 L+P_3=L'+Y
 \quad\text{or}\quad
 L+P_5=L'+D,\qquad L\in\{r_{23},B,X\}.             \tag{4}
\]

## A common local trivalent countermodel

Take five trivalent vertices \(v_1,\ldots,v_5\), with local incidences
labelled \(0,1,2\); incidence \(2\) is the semiedge at each vertex.  A token
is a word in \(\{0,1,2\}^5\), selecting one incidence at every vertex.  Its
boundary is the set of coordinates carrying \(2\).  Use the following
tokens:

\[
\begin{array}{c|c@{\qquad}c|c}
A&21001&B&02010\\
C&10121&D&00012\\
P_3&10211&P_5&11002\\
X&00200&Y&11200\\
p^1_{13}&21001&p^3_{13}&10211\\
p^2_{24}&12101&p^4_{24}&10021\\
p^2_{25}&12111&p^5_{25}&11002\\
q_{13}&12122&q_{14}&12212\\
q_{24}&21212&q_{25}&20221\\
q'_{25}&21221&q_{35}&22121\\
r_{23}&21122&r_{34}&22102
\end{array}                                                     \tag{5}
\]

There are nineteen distinct words in (5).  At every vertex, each of the
three incidences occurs twice in each of the six rows

\[
\begin{aligned}
&(r_{23},B,X,q_{13},p^1_{13},p^3_{13}),\\
&(r_{23},B,X,q_{14},A,C),\\
&(r_{23},B,X,q_{24},p^2_{24},p^4_{24}),\\
&(r_{23},B,X,q_{25},p^2_{25},p^5_{25}),\\
&(r_{23},B,X,q_{35},P_3,P_5),\\
&(q'_{25},r_{34},B,Y,C,D).
                                                               \tag{6}
\end{aligned}
\]

The first five rows saturate \(H_{23}\) over all states in \(S\); the last
is (2) and literally reuses \(B,C\).

Let \(\mathcal P\) be the nineteen-word selected family, with repetitions
allowed in a six-token row.  Exhausting all boundary-compatible tuples gives
no \(T\)--\(T\) double-cover row.  The family contains no word of boundary
\(\{1,2,3,4,5\}\), so it has no selected all-terminal row.  The complementary
carrier has exactly one distinct state-\(35\) decomposition in
\(\mathcal P\), namely the displayed \((q_{35},P_3,P_5)\).

For local signatures, the forced vector \(L+P-Y\) is \(0/1\) exactly when

\[
 P(v)=Y(v)\quad\text{or}\quad L(v)=Y(v)
 \qquad\text{for every }v.                         \tag{7}
\]

Direct substitution in (5) shows that (7) fails for every
\(L\in\{r_{23},B,X\}\) with \((P,Y)=(P_3,Y)\), and likewise for
\((P,Y)=(P_5,D)\).  Neither literal target is already in the corresponding
carrier projection.  Hence both Note-093 endpoint intersections are empty.

## Consequence

Equations (5)--(7) give a strict countermodel to any derivation using only
common vertexwise trivalence, the five saturated rows, the pointwise
\(BC\)-join, selected negative support, and row addition or cancellation.
In particular, the quartic relation (3) need not have an anchored quadratic
factor (4).

The model is not a cubic five-pole: its ten proper incidence stubs have not
been paired between different vertices into common edge objects, and
\(\mathcal P\) is not asserted to be the complete perfect-matching family of
a graph.  It therefore does not refute the real exact-Case-XII statement.
The surviving question is precisely whether global proper-edge pairing and
the resulting complete graph-induced perfect-matching toric relations force
one factor in (4), or otherwise force a forbidden all-terminal or
\(T\)--\(T\) cover.

The explicit finite verification is frozen in the
[proof bundle](../computations/bundles/saturated-bc-local-trivalent-countermodel/README.md).
