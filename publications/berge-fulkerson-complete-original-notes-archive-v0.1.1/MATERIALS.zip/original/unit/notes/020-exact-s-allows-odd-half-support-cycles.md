> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact-S allows odd half-support cycles

The evenness implication left open by Notes 012 and 018 is false.  There is a
simple connected cubic 5-pole with distinct terminals whose complete Tait
state set is exactly

\[
S=\{13,14,24,25,35\},
\]

and which admits five selected Tait colourings satisfying all ten prescribed
exact-S Kempe endpoint pairings, while the associated half-support consists
of two odd cycles.  The example has 15 internal vertices, so the lower bound
of Note 018 is sharp even under exact-S.

## The pole

Let the internal vertices be \(0,\ldots,14\), and let semiedge \(s_i\) be
incident with vertex \(i-1\), for \(1\leq i\leq5\).  In the displayed order
\(e_0,\ldots,e_{19}\), the proper edges are

```text
(0,2) (0,3) (1,5) (1,7) (2,4)
(3,14) (4,11) (5,6) (5,9) (6,7)
(6,10) (7,8) (8,9) (8,13) (9,12)
(10,11) (10,14) (11,12) (12,13) (13,14)
```

Direct enumeration gives 47 perfect matchings.  The five singleton boundary
classes have sizes

\[
(5,4,5,5,5),
\]

and testing all disjoint singleton pairs gives the complete Tait state set
exactly \(S\).

## Odd half-support with all prescribed pairings

Choose the five Tait colourings in the cyclic state order

\[
14,24,25,35,13.
\]

Writing each colouring as \((L_t,R_t,Q_t)\), one may choose the third
matchings as

```text
Q0  e1 e7 e11 e14 e15 e19 s2 s3 s5
Q1  e3 e5 e7 e12 e15 e18 s1 s3 s5
Q2  e2 e6 e9 e12 e16 e18 s1 s3 s4
Q3  e4 e8 e9 e13 e16 e17 s1 s2 s4
Q4  e0 e8 e10 e11 e17 e19 s2 s4 s5
```

These five matchings cover every edge.  Their proper edges of multiplicity
two are precisely

\[
\{e_7,e_8,e_9,e_{11},e_{12}\}
\mathbin{\dot\cup}
\{e_{15},e_{16},e_{17},e_{18},e_{19}\},
\]

which induce the two vertex cycles

\[
5-6-7-8-9-5,
\qquad
10-11-12-13-14-10.
\]

Thus the half-support is \(C_5\mathbin{\dot\cup}C_5\).  Its Petersen labels
in cyclic order are respectively

\[
01,23,04,12,34
\quad\text{and}\quad
01,34,12,04,23.
\]

For the pentagon order \((1,4,2,5,3)\), direct component tracing verifies for
every \(t\) both required endpoint pairings: the \((0,2)\)-paths pair
\((v_t,v_{t+2})\) and \((v_{t+3},v_{t+4})\), while the \((1,2)\)-paths pair
\((v_{t+1},v_{t+4})\) and \((v_{t+2},v_{t+3})\).  Hence all ten prescribed
exact-S pairings hold simultaneously; their failure cannot explain the odd
support.

## Sharpness and scope

Note 018 proves that, with five distinct terminal vertices, odd half-support
components occur in pairs, each has length at least five, and the terminals
lie outside the support.  Consequently any such example has at least
\(5+5+5=15\) internal vertices.  The pole above attains this bound.  It is
therefore a minimum-order counterexample to

\[
\text{exact-}S
\quad\Longrightarrow\quad
\text{every half-support component is even}.
\]

This closes the proposed odd-cycle parity route, but it does **not** refute
the capacity-two conjecture.  The same pole has a capacity-two transversal:

```text
P1  e2 e4 e5 e9 e12 e15 e18 s1
P2  e1 e4 e7 e11 e14 e15 e19 s2
P3  e1 e2 e6 e9 e12 e16 e18 s3
P4  e0 e3 e6 e7 e13 e14 e16 s4
P5  e0 e3 e5 e8 e10 e13 e17 s5
```

Every edge occurs in at most two of these five perfect matchings.

## Certificate

The frozen pure-standard-library verifier is
`scratch/worker-proof/verify_exact_s_odd_half_support.py`.  It independently
checks simplicity, connectedness and cubic degrees; recursively enumerates
all perfect matchings; computes the complete Tait state set; verifies the five
colourings, both odd support components, all ten Kempe pairings and the
literal capacity-two witness.  Reproduce from the project root with

```text
python3 units/berge-fulkerson/scratch/worker-proof/verify_exact_s_odd_half_support.py
```

The terminating line is

```text
EXACT_S_ODD_HALF_SUPPORT_COUNTEREXAMPLE_VERIFIED
```
