> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two shared-\(a\) cross rows pin the first-leaf B exterior

Retain the complete exact-Case-XII, one-internal-mark setting and the only first-leaf six-cycle marking not excluded by [Notes 250–251](251-the-first-leaf-c-marking-has-a-forbidden-six-cycle-switch.md): type B of [Note 249](249-the-first-leaf-six-cycle-has-three-surviving-markings.md),
\[
K=\{1O,1L,1Q,2O,2R,3O,3P,4L,4R\},\quad
a:P-C,\ d:Q-C,\ b:L-P,\ c:R-Q,
\quad h_i=u_iC\ (i=2,3,4).                              \tag{1}
\]
Write \(iw=u_iw\), and let \(a:P,a:C\) name the two halves of the marked edge \(a\), etc. The shore \(C\) has arbitrary order and unmarked cycle rank.

**Theorem.** Every actual Case-XII \((ea)(ab)\) or \((ea)(ad)\) row on this marked exterior has the same uniquely determined exterior masks in its pure-\(S\) half:
\[
\begin{aligned}
X_a&=\{a:P,1Q,2R,3O,4L\},\\
Y_a&=\{3P,1O,d:Q,b:L,c:R,h_2,h_4\},\\
Z_e&=\{a:C,d:C,b:P,c:Q,1L,2O,4R,h_3\}.
\end{aligned}                                                   \tag{2}
\]
These three masks partition every proper exterior edge exactly once. The shore pairing in that half must join \(e\) to \(h_3\), forcing \(S=e-a-c-b-d-e\). The opposite half has one of the following uniquely determined exterior triples of masks, according to its \(T\)-state:

| Opposite state | Triple exterior | Singleton-\(a\) exterior | Other singleton exterior |
|---|---|---|---|
| \(ab\) | \(U_{ab}=\{a:C,b:P,1Q,2R,3O,4L\}\) | \(V_a|_{\rm ext}=Y_a|_{\rm ext}\) | \(W_b=\{a:P,c:Q,d:C,1L,2O,4R,h_3\}\) |
| \(ad\) | \(U_{ad}=\{a:P,d:C,1Q,2R,3O,4L\}\) | \(V_a|_{\rm ext}=Y_a|_{\rm ext}\) | \(W_d=\{a:C,b:P,c:Q,1L,2O,4R,h_3\}\) |

In particular both required rows force a *shore* six-matching completion with the following port sets, where \(e\) denotes the internal mark's terminal port:

| Half | Triple | Singleton-\(a\) | Remaining singleton |
|---|---|---|---|
| pure \(ea\) | \(\varnothing\) | \(\{h_2,h_4\}\) | \(\{e,a:C,d:C,h_3\}\) |
| opposite \(ab\) | \(\{e,a:C\}\) | \(\{h_2,h_4\}\) | \(\{d:C,h_3\}\) |
| opposite \(ad\) | \(\{e,d:C\}\) | \(\{h_2,h_4\}\) | \(\{a:C,h_3\}\) |

The table fixes boundary sets on the same shore graph, **not** the complete shore matching masks or an identity reused across the two rows.

## Proof

Begin with the required real \((ea)(ad)\) row. The pair \(ad\) lies in \(T\) in **either** allowed pentagon order because \(e\)'s neighbours are \(a,d\). Write this row, and later the \((ea)(ab)\) row once its \(T\)-status is established, uniformly as
\[
D=X_a+Y_a+Z_e,\qquad E=U_{at}+V_a+W_t,
\qquad D+E=2\mathbf1.                                  \tag{3}
\]
For \(t=d\), the negative support makes \(D\) pure \(S\). The zero-port quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and the unique exposed-vertex matching of (1) give \(X_a\) in (2). The exterior \(a\)--\(d\) switch and purity give the unique \(Y_a\) in (2), as proved in Note 249.

Exchange the **complete** singleton-\(a\) matchings \(Y_a,V_a\) across (3). The opposite half still has state \(at\in T\), so the new \(ea\) half is also pure \(S\). Note 249's uniqueness therefore forces \(V_a\) to have the same exterior mask as \(Y_a\). Every exterior edge of \(Y_a\) is already used twice in (3), once by each singleton-\(a\) occurrence, so \(Z_e\) must avoid all seven edges of \(Y_a\).

The singleton-\(e\) matching \(Z_e\) must select one half of each of \(a,b,c,d\) and three proper shore ports. Avoiding \(d:Q,b:L,c:R,h_2,h_4\) forces \(d:C,b:P,c:Q\); the only three still available proper ports are then \(a:C,d:C,h_3\), so \(a:C,h_3\) are forced too. It cannot use \(1O\) or \(3P\), the remaining two edges of \(Y_a\). Among the \(K\)-edges, \(1L\) is forced because \(1O\) is forbidden and \(Q\) is occupied by \(c:Q\); then \(4R\) is forced because \(L\) is occupied by \(1L\), and finally \(2O\) is forced. This gives precisely \(Z_e\) in (2). Comparing (2) with (1) shows that \(X_a,Y_a,Z_e\) partition each proper exterior edge once.

The state-\(ed\) zero-port triple obtained by switching \(X_a\triangle Y_a\) has the same complete shore mask as \(X_a\) and exterior \(X_d=\{d:Q,1O,2R,3P,4L\}\). The shore \(e\)-path in \(X_a\triangle Z_e\) cannot use \(a:C\) or \(d:C\), since these ports lead directly to terminal \(a\) against \(X_d\) or to \(d\) against \(X_a\), respectively. It must use \(h_3\). Its exterior route ends at \(c\) against \(X_a\), following
\[
h_3-u_3-O-u_2-R-u_4-L-u_1-Q-c,
\]
and at \(b\) against \(X_d\), following \(h_3-u_3-P-b\). Purity therefore forces \(S=e-a-c-b-d-e\); both \(ab,ad\) are now in its complement \(T\). The required \((ea)(ab)\) row can consequently be treated by the same complete singleton-\(a\) exchange and has the same pure-half exterior (2).

Because \(D\) has unit exterior load, so does \(E\). The exterior of \(V_a\) is already \(Y_a\), hence \(U_{at}+W_t\) must partition the edges of \(X_a+Z_e\). For state \(ab\), the triple has terminal set \(\{c,d,e\}\) and uses one proper shore port by Note 230. Its marked half \(b:P\) is forced because \(b:L\) belongs to \(V_a\). It cannot also use \(a:P\), as both halves would meet the same singleton vertex \(P\); it therefore uses \(a:C\) as its unique proper shore port. Deleting \(P\) from \(K\) forces \(1Q,2R,3O,4L\), giving \(U_{ab}\). The remaining edges of \(X_a+Z_e\) give \(W_b\). For state \(ad\), the triple has terminal set \(\{b,c,e\}\) and must use \(d:C\), the half complementary to \(V_a\)'s \(d:Q\), as its one proper shore port. It uses \(a:P\), since the other choice \(a:C\) would create a second proper port. The same \(K-P\) matching gives \(U_{ad}\), and the residual gives \(W_d\). The six-port table follows directly. \(\square\)

The result is a necessary full-row constraint on a true exact-Case-XII pole. It does not provide either of the two shore completions, and their separate existence would not identify the complete shore matchings between rows. [Note 252's](252-the-first-leaf-b-marking-has-a-real-cross-row.md) five-vertex shore illustrates the distinction. Put \(v_0=t_e\) and retain its port order \(e,h_3,a:C,h_2,h_4,d:C\) around the six-cycle. Purity forces the zero-port shore matching \(Q=\{v_0v_1,v_2v_3,v_4v_5\}\); the two-port \(h_2,h_4\) matching and four-port \(e,a:C,d:C,h_3\) matching are unique and partition the remaining three cycle edges. In the proposed opposite \(ad\) half, the matchings with port sets \(\{e,d:C\}\), \(\{h_2,h_4\}\), \(\{a:C,h_3\}\) are also unique and each uses two of those three remaining edges. The six-matchings would consequently load the three \(Q\)-edges once and the other three edges three times. Thus the real \((ea)(eb)\) row in Note 252 cannot satisfy the exact-Case-XII \((ea)(ad)\) gate, even before invoking its forbidden \([eb]\) loop.

The other exterior quotients, barrier profiles, and Berge--Fulkerson remain open. The argument is analytic and has not received an independent check.
