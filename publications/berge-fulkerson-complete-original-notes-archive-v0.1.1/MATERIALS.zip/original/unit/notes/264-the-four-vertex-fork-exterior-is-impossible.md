> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The four-vertex fork exterior is impossible

Work in the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md). Let \(|U|=r=4\), and suppose the unmarked exterior is its fork tree. Use the notation
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\qquad h_i=u_i\Sigma,
\]
where \(O,L,P,Q,R\) are the five singleton components and \(\Sigma\) is the odd shore, of arbitrary order and unmarked cycle rank. The internal mark is \(e\). By [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md), the unique exterior mark \(a\) meeting \(\Sigma\) is one of the two neighbours of \(e\) in the allowed pentagon \(S\).

**Theorem.** The fork exterior has no complete exact-Case-XII perfect-matching support, at any shore order or rank. In particular, conditional on the minimum-host barrier reduction and the earlier marked-exterior results, the only unmarked \(|U|=r=4\) shape still open from Note 245 is the subdivided five-vertex path.

## Marked placements

The degree deficits of \(K\) are two at each leaf \(P,Q,R\), one at \(L\), and zero at \(O\). If \(a\) meets \(L\), the three cross marks form the triangle on \(P,Q,R\), excluded for both choices of the second \(e\)-neighbour by [Notes 260–261](261-the-fork-triangle-marking-is-impossible-for-the-long-leaf-neighbour.md). If \(a\) meets a short leaf, take it to be \(P\). The cross marks must form a path on \(P,Q,R,L\) with endvertices \(P,L\); the path \(P-Q-R-L\) has a mark \(RL\), which makes a four-cycle with \(R-u_4-L\). Thus, up to symmetry, the only girth-five placement is
\[
a:P\!:\!\Sigma,\qquad b:PR,\quad c:LQ,\quad d:QR.       \tag{1}
\]
If \(a\) meets the long leaf \(R\), the two short leaves are interchangeable, and the unique cross-mark path is
\[
a:R\!:\!\Sigma,\qquad b:QR,\quad c:LP,\quad d:PQ.       \tag{2}
\]
The choice \(eb\in S\) in (1) and (2) is excluded by [Notes 262–263](263-the-long-leaf-fork-shared-neighbour-has-no-pure-half.md). It remains to rule out \(ec\in S\) and \(ed\in S\) in each placement.

For either choice \(s\in\{c,d\}\), the [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains a real row \((ea)(as)\): \(ea,es\in S\) and \(as\in T\). Write it as
\[
X_a+Y_a+Z_e+U_{as}+V_a+W_s=2\mathbf1.              \tag{3}
\]
The first three occurrences form a pure-\(S\) half, because a \(T\)-state in that half would give a forbidden \(T\)--\(T\) row with the opposite half. The state-\(ea\) triple \(X_a\) has zero proper shore ports by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). Purity forces the \(a\)-terminal path in \(X_a\triangle Y_a\) to end at \(s\); as in Note 244, this path stays exterior. Exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\) in (3) gives another real row with the same pure-\(S\) first half. Thus any forced exterior edge of \(Y_a\) occurs twice in (3), and \(Z_e\) cannot use it.

## Short-leaf placement

For (1), the unique zero-port triple exterior is
\[
X_a=\{a:P,1O,2Q,3L,4R\}.                           \tag{4}
\]
If \(s=c\), the exterior \(a\)--\(c\) path ending at \(c:Q\) would occupy \(P,Q\), leaving both \(b:PR\) and \(d:QR\) to use \(R\). It must end at \(c:L\). If \(s=d\), the path ending at \(d:R\) would occupy \(P,R\), leaving \(b:PR\) without an endpoint. It must end at \(d:Q\). Completing the singleton matchings gives the following *unique* exteriors for both \(Y_a\) and \(V_a\). Flip the displayed \(a\)--\(s\) path in \(X_a\triangle Y_a\) to obtain the zero-port triple \(X_s\), with exactly the same shore matching as \(X_a\).

| Second neighbour \(s\) | Forced exterior of \(Y_a,V_a\) | Exterior of \(X_s\) |
|---|---|---|
| \(c\) | \(\{b:R,c:L,d:Q,1P,3O,h_2,h_4\}\) | \(\{c:L,1P,2Q,3O,4R\}\) |
| \(d\) | \(\{b:R,c:L,d:Q,1P,2O,h_3,h_4\}\) | \(\{d:Q,1P,2O,3L,4R\}\) |

Since \(Z_e\) avoids every edge in its row's forced singleton exterior and has exactly three proper shore ports, its exterior is also unique:

| \(s\) | Forced exterior of \(Z_e\) | Proper shore port: terminal against \((X_a,X_s)\) |
|---|---|---|
| \(c\) | \(\{a:\Sigma,b:P,c:Q,d:R,2O,4L,h_1,h_3\}\) | \(a:\Sigma:(b,a),\ h_1:(c,b),\ h_3:(d,d)\) |
| \(d\) | \(\{a:\Sigma,b:P,c:Q,d:R,3O,4L,h_1,h_2\}\) | \(a:\Sigma:(b,a),\ h_1:(d,b),\ h_2:(c,c)\) |

The singleton-\(e\) matching \(Z_e\) also uses its terminal \(e\). To check the route table directly, for \(s=c\) the \(h_1\)-route against \(X_a\) is \(u_1-O-u_2-Q-t_c\), and against \(X_c\) it is \(u_1-P-t_b\). For \(s=d\), the \(h_1\)-route against \(X_a\) continues through \(O-u_3-L-u_4-R-t_d\), while against \(X_d\) it is \(u_1-P-t_b\). The remaining entries follow the same alternating traces through (4) and \(X_s\).

The shore restrictions of \(X_a,X_s\) are identical. Hence the shore \(e\)-path uses the same one of the three selected proper ports in both comparisons. Purity requires it to end at the two marks outside \(\{a,s\}\) in opposite order: at \(b,d\) for \(s=c\), and at \(b,c\) for \(s=d\). Neither row has the required endpoint pair. Therefore neither choice admits (3).

## Long-leaf placement

For (2), the zero-port triple exterior is
\[
X_a=\{a:R,1P,2Q,3O,4L\}.                           \tag{5}
\]
If \(s=d=PQ\), an \(a\)--\(d\) path ending at \(P\) uses \(4R,3L,1O,d:P\); then \(c:LP\) has no free endpoint. A path ending at \(Q\) uses \(4R,3L,2O,d:Q\); then \(b:QR\) has no free endpoint. Thus no singleton-\(a\) matching \(Y_a\) can give the required pure half.

If \(s=c=LP\), the long path ending at \(P\) occupies \(P,R\), forcing both \(b:QR\) and \(d:PQ\) to use \(Q\). The direct path ending at \(L\) is the sole possibility, and it forces
\[
Y_a|_{\rm ext}=V_a|_{\rm ext}
=\{b:Q,c:L,d:P,3O,4R,h_1,h_2\}.                    \tag{6}
\]
In (3), \(Z_e\) therefore avoids \(b:Q,c:L,d:P,h_1,h_2\). It must select the other halves \(b:R,c:P,d:Q\), and consequently \(a:\Sigma\). Both \(P,Q\) are covered by marks, so \(u_1,u_2\) can be matched only through \(1O,2O\), respectively: their shore ports \(h_1,h_2\) are already loaded twice by (6). One matching cannot use both \(1O\) and \(2O\), since they meet \(O\). Thus \(Z_e\) does not exist, and (3) is impossible.

The two leaf placements are excluded without restricting the shore's internal matching relation. Together with Notes 260–263 and the placement classification above, this excludes the entire four-vertex fork exterior. The path-tree exterior, larger barriers, the other Tutte profiles, and Berge–Fulkerson remain open. \(\square\)
