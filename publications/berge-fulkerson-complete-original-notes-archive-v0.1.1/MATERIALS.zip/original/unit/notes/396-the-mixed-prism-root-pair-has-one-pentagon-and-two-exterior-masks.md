> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The mixed prism root pair has one pentagon orientation and two exterior masks

Keep the two-spoke prism tree and the actual \((e\,ab)(e\,AC)\) row of [Notes 394–395](395-the-mixed-prism-e-singletons-have-an-exact-three-port-selector.md). Thus \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\); \(P\) is the forbidden \(e\,ab\)-triple rooted at \(a\), \(R\) is the allowed \(e\,AC\)-triple rooted at \(C\), and \(E,F,J,K\) are singleton occurrences at \(e,e,ab,AC\). Assume the *complete* BF support is exactly Appendix XII, with forbidden \(e\)-labels \(ab,Cc\). The six-port shore may have arbitrary order and cycle rank. No clean zero-port signature or short \(p_2p_4\) path is assumed.

The two possible allowed pentagons with \(e\)-neighbours \(AC,bc\) are
\[
\begin{aligned}
S_{ab}&=e-AC-ab-Cc-bc-e,\\
S_{Cc}&=e-AC-Cc-ab-bc-e.
\end{aligned}                                                    \tag{1}
\]
As in the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), a row whose two states both lie outside the allowed pentagon is forbidden.

> **Orientation and exterior-mask gate.** For this root pair, \(S_{Cc}\) is impossible. In the only remaining orientation \(S_{ab}\), the singleton \(K\) uses \(Bu_4,Au_1,Cu_2,ab:a,bc:b,Cc:c\) and ports \(p_3,p_5\); \(J\) uses \(Bu_1,Au_3,au_5,AC:C,Cc:c,bc:b\) and ports \(p_2,p_4\). Up to exchanging \(E,F\), one singleton-\(e\) uses \(Bu_2\) and the other \(Bu_4\). Both use \(AC:A,Cc:C,bc:c,ab:b\) and port \(p_1\); one uses \(au_3\), the other \(au_5\). The \(e\)-path against \(R\) must end at \(p_4\) for the \(Bu_2\) singleton and at \(p_2\) for the \(Bu_4\) singleton.

**Proof.** [Note 394](394-a-mixed-prism-row-forces-an-ac-bc-escape-and-attains-it.md) already forces \(K\) to use \(Cu_2,ab:a,bc:b,Cc:c,p_5\) and forces the terminal path of \(R\triangle K\) starting at \(AC\) to end at \(bc\). The latter condition itself forces \(Bu_4\), without the short-path hypothesis used in that note. Indeed, \(K\) cannot take \(Bu_2\), since it takes \(Cu_2\). If it took \(Bu_1\), its uncovered vertex \(A\) would have to use \(Au_3\), and the wholly exterior alternating path would be
\[
 AC-t_{AC}-C-u_2-B-u_1-A-u_3-a-t_{ab}-ab.              \tag{2}
\]
Switching \(R,K\) along (2) would give the forbidden \([e\,ab]\) row. Hence \(K\) takes \(Bu_4\), and \(R\triangle K\) has the wholly exterior \(AC\)--\(bc\) path of Note 394, equation (1).

Switch \(R,K\) on this path and call the resulting triple \(R'\). Its state is \(e\,bc\); its shore matching is still \(R\)'s zero-port matching. In the exterior it uses \(Au_1,Cu_2,au_3,Bu_4,cu_5\) and the marked halves \(AC:s,Cc:s,bc:b,ab:s\). For each \(D\in\{E,F\}\), the shore part of \(R'\triangle D\), including its path from \(e\) to one of \(D\)'s three proper ports, is **identical** to the shore part of \(R\triangle D\). Tracing only the exterior of \(R'\triangle D\) gives

| \(D\)'s edge at \(B\) | port to \(AC\) | port to \(Cc\) | port to \(ab\) |
|---|---|---|---|
| \(Bu_1\) | \(p_4\) | \(p_2\) | \(p_3\) or \(p_5\) |
| \(Bu_2\) | \(p_1\) | \(p_4\) | \(p_3\) or \(p_5\) |
| \(Bu_4\) | \(p_1\) | \(p_2\) | \(p_3\) or \(p_5\) |

For example, in the first row the \(p_4\)-arm is \(p_4-u_4-B-u_1-A-t_{AC}-AC\), while the \(p_2\)-arm is \(p_2-u_2-C-t_{Cc}-Cc\). In the second row the \(p_4\)-arm is \(p_4-u_4-B-u_2-C-t_{Cc}-Cc\). The remaining arms are \(p_5-u_5-c-t_{bc}-b-t_{ab}-ab\) or \(p_3-u_3-a-u_5-c-t_{bc}-b-t_{ab}-ab\). This proves the table without using shore parity.

By [Note 395](395-the-mixed-prism-e-singletons-have-an-exact-three-port-selector.md), the \(e\)-path of \(R\triangle D\) must use the port leading to \(m=ab\) in \(S_{ab}\), or to \(m=Cc\) in \(S_{Cc}\). If \(S=S_{Cc}\), this port is \(p_2\) when \(D\) uses \(Bu_1\), and \(p_1\) otherwise. The displayed table sends these ports under \(R'\triangle D\) to \(Cc\) and \(AC\), respectively. Both \(bc\,Cc\) and \(bc\,AC\) lie outside \(S_{Cc}\). Switching \(R',D\) therefore pairs one of those forbidden states with the unchanged forbidden \(e\,ab\)-triple \(P\), a double-forbidden row. Thus \(S_{Cc}\) is impossible.

For \(S=S_{ab}\), Note 395 instead selects \(p_4\) for \(Bu_1\) or \(Bu_2\), and \(p_2\) for \(Bu_4\). If \(D\) took \(Bu_1\), its selected \(p_4\)-arm against \(R'\) would end at \(AC\). Since \(bc\,AC\notin S_{ab}\), the same double-forbidden switch excludes this choice. Thus both \(E,F\) take their \(B\)-edge from \(Bu_2,Bu_4\). Edge load two at \(B\) now places \(J\) on \(Bu_1\), with the two choices for \(E,F\) distinct. At \(u_1\), \(P,J\) occupy the \(B\)-half and \(R\) the \(A\)-half, so \(K\) occupies the other \(A\)-half slot and \(E,F\) take port \(p_1\). Since \(P,K\) cover \(A\) by \(Au_3,Au_1\), respectively, \(J\) uses \(Au_3\). It therefore cannot also use \(au_3\) and must use \(au_5\). The remaining \(a\)-half slots go one each to \(E,F\). The tree subdivisions give exactly the listed ports. Finally the \(ab\)-selector of Note 395 is \(p_4\) for the \(Bu_2\) singleton and \(p_2\) for the \(Bu_4\) singleton. \(\square\)

The surviving **exterior** masks for \(E,F\), naming \(E\) as the \(Bu_2\) singleton, are exactly

| choice | \(E:(u_1,u_2,u_3,u_4,u_5)\) | \(F:(u_1,u_2,u_3,u_4,u_5)\) |
|---|---|---|
| \(E\) takes \(au_3\) | \((p_1,B,a,p_4,p_5)\) | \((p_1,p_2,p_3,B,a)\) |
| \(F\) takes \(au_3\) | \((p_1,B,p_3,p_4,a)\) | \((p_1,p_2,a,B,p_5)\) |

Both cases require the shore pairings \(e\leftrightarrow p_4\) in \(R\triangle E\) and \(e\leftrightarrow p_2\) in \(R\triangle F\). These are necessary conditions on **complete matchings**, not a certificate that either shore pairing is realizable in one BF row. No contradiction has been proved for \(S_{ab}\), and neither this root-pair exclusion nor the exterior table excludes other roots, other exterior trees, full exact Case XII, or the Berge–Fulkerson conjecture. The argument is a direct hand check and has not received independent review.

There is a stronger path-activity consequence in [Note 387's clean exceptional fibre](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Let \(Q=P|_Z\), \(Q'=R|_Z\), and suppose \(Z-Q\) has no odd closed component, with even paths \(e\,p_5\) and \(p_1p_3\), and odd path \(p_2p_4\). The short-path assumption is unnecessary for this consequence. In the surviving mask, the singleton port pairs are \(L_e=L_{p_1}=EF\), \(L_{p_2}=FJ\), \(L_{p_4}=EJ\), while each of \(L_{p_3},L_{p_5}\) consists of \(K\) and one of \(E,F\). If \(Q,Q'\) agreed at every vertex of either even path, [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) would make that path's endpoint pairs complementary: its \(EF\) end would require \(JK\) at the other end. Neither \(p_3\) nor \(p_5\) has that pair. Thus \(Q\triangle Q'\) touches **both** even paths. When the odd \(p_2p_4\) path has three edges, Note 391 also forces \(Q'\) to use its unique internal edge, so the symmetric difference touches all three shore port paths. This strengthens Note 391's one-even-path conclusion only for the surviving exact-support exterior template; it does not force one cycle to meet all three paths.
