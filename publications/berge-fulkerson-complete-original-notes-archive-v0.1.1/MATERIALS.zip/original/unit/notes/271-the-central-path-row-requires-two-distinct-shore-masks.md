> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central path row requires two distinct shore masks

> **Later consequence:** [Note 354](354-the-right-eb-row-forces-a-forbidden-double-t-completion.md) and [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) use the complete \((ea)(eb)\) matching closure to exclude this central-path marked exterior under the classifications cited there. The row templates below retain their conditional mathematical meaning.

Continue the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile in the sole \(|U|=r=4\) marked exterior left by [Note 270](270-the-central-path-side-neighbours-overload-cross-rows.md):
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\quad h_i=u_i\Sigma,
\qquad a:C\!:\!\Sigma,\quad b:AD,\quad c:AE,\quad d:BE,
\qquad ea,ec\in S.                                  \tag{1}
\]
The six-port shore \(\Sigma\) has even order and arbitrary unmarked cycle rank; the core before subdividing the internal mark \(e\) has odd order. Reflecting the path interchanges \(b,d\) and the two ends \(A,E\).

**Theorem.** Every real Case-XII \((ea)(ac)\) row in (1) has, up to reflection, the exact exterior masks in Table (5) below. Its two singleton-\(a\) occurrences have the *same exterior mask and shore port set* \(\{h_3,h_4\}\), but their **complete shore matchings are distinct**. Their symmetric difference therefore contains a nonempty shore-internal alternating cycle. This is a necessary full-row gate, not an existence certificate or an exclusion of the remaining marking.

## The two sides cannot mix

Write a required real \((ea)(ac)\) row as
\[
X_a+Y_a+Z_e+U_{ac}+V_a+W_c=2\mathbf1.            \tag{2}
\]
Since \(ac\in T\), both the original \(ea\) half and the half obtained by exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\) are pure \(S\). By [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the state-\(ea\) triple exterior is
\[
X_a=\{a:C,1A,2B,3D,4E\}.                           \tag{3}
\]
The \(a\)--\(c\) path of \(X_a\triangle Y_a\) stays exterior by [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). It ends at either \(c:A\) or \(c:E\). Completing the other two cross marks gives exactly
\[
\begin{aligned}
Y_L&=\{c:A,b:D,d:E,1B,2C,h_3,h_4\},\\
Y_R&=\{c:E,b:A,d:B,3C,4D,h_1,h_2\}.
\end{aligned}                                               \tag{4}
\]
The switched zero-port triples \(X_{c,L}=\{c:A,1B,2C,3D,4E\}\) and \(X_{c,R}=\{c:E,1A,2B,3C,4D\}\) have exactly the same complete shore matching as \(X_a\). Purity requires one fixed shore \(e\)-port in \(Z_e\) to reach \(b,d\) in opposite order against \((X_a,X_{c,L})\) if the singleton uses \(Y_L\), or against \((X_a,X_{c,R})\) if it uses \(Y_R\).

There are 16 possible singleton-\(e\) exterior masks, indexed by the four disjoint cross-mark orientations
\[
I=(b:A,c:E,d:B),\quad II=(b:D,c:A,d:B),\quad
III=(b:D,c:A,d:E),\quad IV=(b:D,c:E,d:B).
\]
The table lists all 16 matchings of the remaining exterior path. For each
zero-port triple \(X_a,X_{c,L},X_{c,R}\), the ordered pair
\((P_b,P_d)\) gives the selected proper shore port at the far end of
its exterior alternating path from terminal \(b,d\), respectively,
against the fixed singleton-\(e\) mask in that row. Write \(A\) for
the proper port \(a:\Sigma\). A pure left side requires
\(P_b^0=P_d^L\) or \(P_d^0=P_b^L\); replace \(L\) by \(R\) for a pure
right side. These are necessary exterior route checks, independent
of the shore-internal pairing.

| Cross halves | \(a\)-half | Other \(K\)-edges | \((P_b,P_d)_0\) | \((P_b,P_d)_L\) | \((P_b,P_d)_R\) | Possible pure side |
|---|---|---|---|---|---|---|
| I | \(C\) | \(3D\) | \(h_1,h_2\) | \(h_4,h_1\) | \(h_1,h_2\) | L |
| I | \(C\) | \(4D\) | \(h_1,h_2\) | \(h_3,h_1\) | \(h_1,h_2\) | L |
| I | \(\Sigma\) | \(2C,3D\) | \(h_1,A\) | \(h_4,h_1\) | \(h_1,h_4\) | L |
| I | \(\Sigma\) | \(2C,4D\) | \(h_1,A\) | \(h_3,h_1\) | \(h_1,h_3\) | L |
| I | \(\Sigma\) | \(3C,4D\) | \(h_1,h_2\) | \(h_2,h_1\) | \(h_1,h_2\) | L |
| II | \(C\) | \(4E\) | \(h_3,h_2\) | \(h_3,h_1\) | \(h_1,h_2\) | — |
| II | \(\Sigma\) | \(2C,4E\) | \(h_3,A\) | \(h_3,h_1\) | \(h_1,h_3\) | R |
| II | \(\Sigma\) | \(3C,4E\) | \(A,h_2\) | \(h_2,h_1\) | \(h_1,h_2\) | L |
| III | \(C\) | \(1B\) | \(h_3,h_4\) | \(h_3,h_4\) | \(h_4,h_2\) | R |
| III | \(C\) | \(2B\) | \(h_3,h_4\) | \(h_3,h_4\) | \(h_4,h_1\) | R |
| III | \(\Sigma\) | \(1B,2C\) | \(h_3,h_4\) | \(h_3,h_4\) | \(h_4,h_3\) | R |
| III | \(\Sigma\) | \(1B,3C\) | \(A,h_4\) | \(h_2,h_4\) | \(h_4,h_2\) | R |
| III | \(\Sigma\) | \(2B,3C\) | \(A,h_4\) | \(h_1,h_4\) | \(h_4,h_1\) | R |
| IV | \(C\) | \(1A\) | \(h_3,h_2\) | \(h_3,h_4\) | \(h_4,h_2\) | — |
| IV | \(\Sigma\) | \(1A,2C\) | \(h_3,A\) | \(h_3,h_4\) | \(h_4,h_3\) | R |
| IV | \(\Sigma\) | \(1A,3C\) | \(A,h_2\) | \(h_2,h_4\) | \(h_4,h_2\) | L |

For a **fixed** allowed pentagon \(S=e-a-b-d-c-e\), only the equality
\(P_b^0=P_d^{L/R}\) in the route test is compatible with a pure half:
the \(e\)-path must end at \(b\) in state \(ea\), and at \(d\) after
the exterior \(a\)--\(c\) switch to state \(ec\). The reverse equality
\(P_d^0=P_b^{L/R}\), when used by the shore \(e\)-path, corresponds to
the reflected pentagon \(e-a-d-b-c-e\); a mask may satisfy both
equalities. Thus the “possible pure side” column is a union over
the two cyclic orders; [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md)
uses the fixed-order refinement for the required \((ea)(eb)\) row.

For example, in orientation I with \(a:\Sigma,2C,4D\), port \(h_1\)
reaches \(b\) against \(X_a\) and \(d\) against \(X_{c,L}\);
against \(X_{c,R}\) it still reaches \(b\). In orientation IV with
\(a:\Sigma,1A,3C\), port \(h_2\) reaches \(d,b\) against
\((X_a,X_{c,L})\) but reaches \(d\) against \(X_{c,R}\).
The 16 ordered-pair rows show directly that **no mask supports both
L and R**. Since exchanging \(Y_a,V_a\) leaves \(X_a,Z_e\) and their
complete shore restrictions fixed, the two singleton-\(a\)
occurrences in (2) cannot use different sides. Reflect so that both
use \(Y_L\).

## The full exterior row

The two occurrences of \(Y_L\) saturate its exterior edges. Among the
L-labelled masks in the route table, only orientation I with
\(a:\Sigma,3C,4D\) avoids every edge of \(Y_L\); it is therefore the
unique possible singleton-\(e\) exterior. The opposite triple and
singleton exteriors are then forced by edge load two and their
boundary types:

**Table (5). The forced left-side exterior row**

| Slot | Boundary | Exterior mask | Shore ports |
|---|---|---|---|
| \(X_a\) | \(b,c,d\) | \(\{a:C,1A,2B,3D,4E\}\) | \(\varnothing\) |
| \(Y_a\) | \(a\) | \(Y_L\) from (4) | \(\{h_3,h_4\}\) |
| \(Z_e\) | \(e\) | \(\{a:\Sigma,b:A,c:E,d:B,3C,4D,h_1,h_2\}\) | \(\{e,a:\Sigma,h_1,h_2\}\) |
| \(U_{ac}\) | \(b,d,e\) | \(\{a:\Sigma,c:E,1A,2B,3C,4D\}\) | \(\{e,a:\Sigma\}\) |
| \(V_a\) | \(a\) | \(Y_L\) from (4) | \(\{h_3,h_4\}\) |
| \(W_c\) | \(c\) | \(\{a:C,b:A,d:B,3D,4E,h_1,h_2\}\) | \(\{h_1,h_2\}\) |

Every exterior mask in (5) is a matching. On the eight \(K\)-edges
\((1A,1B,2B,2C,3C,3D,4D,4E)\), the slot pairs are respectively
\((XU,YV,XU,YV,ZU,XW,ZU,XW)\); each marked half-edge, terminal
semiedge, and \(h_i\) also has load two. The two singleton-\(a\)
restrictions are externally identical, but their shore restrictions
need not be. The table's purity condition forces the shore
\(e\)-path in \(X_a\triangle Z_e\) to pair with \(h_1\) or
\(h_2\): those exterior routes end at \(b,d\) in opposite order
against \((X_a,X_{c,L})\). Pairing \(e\) with \(a:\Sigma\) instead
gives terminal \(c\) against \(X_a\) and the forbidden \(ac\in T\)
decomposition.

## Identical shore matchings are impossible

Suppose the two complete shore restrictions of \(Y_a,V_a\) in (5) were identical. Since their exteriors are also identical, they would be the same full-pole perfect matching, occurring twice in the BF row. Remove its edges from the shore six-pole. The remaining graph \(\Gamma\) has degree two at each internal vertex, four ports \(e,a:\Sigma,h_1,h_2\), and some closed cycles. Every edge of \(\Gamma\) has total load two across the other four matching slots \(I=\{X_a,Z_e,U_{ac},W_c\}\).

Label an edge of \(\Gamma\) by the two slots of \(I\) using it. At each internal vertex, the two incident \(\Gamma\)-edge label sets are complementary in \(I\), because each of the four perfect matchings uses exactly one of those two edges. The four port label sets are
\[
A_e=A_{a:\Sigma}=\{Z_e,U_{ac}\},\qquad
A_{h_1}=A_{h_2}=\{Z_e,W_c\}.                       \tag{6}
\]
Two port ends of one path in \(\Gamma\) must have equal or complementary two-set labels. The sets \(\{Z_e,U_{ac}\}\) and \(\{Z_e,W_c\}\) are neither equal nor complementary. Therefore \(e\) pairs with \(a:\Sigma\), and \(h_1\) pairs with \(h_2\) in \(\Gamma\). On the \(e\)--\(a:\Sigma\) path, the edge labels alternate between \(\{Z_e,U_{ac}\}\) and \(\{X_a,W_c\}\), so this is exactly the \(e\)-path of \(X_a\triangle Z_e\). Its exterior continuation from \(a:\Sigma\) ends at terminal \(c\), contradicting the required pure \(S\) half. Hence the two complete shore matchings differ. With the same port set, their symmetric difference is a nonempty disjoint union of shore-internal alternating cycles. \(\square\)

The note does not establish an actual full-pole row with (5), nor
does it exclude the remaining marked exterior. It identifies the
precise shore phase separation that any exact-Case-XII pole in this
profile must realize. Larger barriers, the other Tutte profiles,
and Berge–Fulkerson remain open. The expanded exterior route table
is a hand-checked incidence and alternating-path certificate; the
upstream pure-half and minimum-host reductions still require an
independent proof review.
