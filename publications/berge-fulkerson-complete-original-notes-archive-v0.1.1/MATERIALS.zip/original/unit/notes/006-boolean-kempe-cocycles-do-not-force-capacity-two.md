> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Boolean Kempe cocycles do not force capacity two

The current Case-XII frontier is the capacity-two singleton-transversal
conjecture recorded in Note 005.  A purely mod-two proof of that conjecture is
impossible from the canonical Kempe-transport axioms alone.

Let the boundary classes occur cyclically as (1,4,2,5,3), and let
(P_t) be a canonical transport trajectory.  If (X_t(P_{t+1})) is the
appropriate boundary path in the complement of (P_{t+1}), then, as edge-set
vectors over \(\mathbb F_2\),

\[
P_{t+2}=P_t+X_t(P_{t+1}).
\]

Writing (q(P,Q)=P+Q) on consecutive disjoint pairs gives

\[
X_t(P_{t+1})=q(P_t,P_{t+1})+q(P_{t+1},P_{t+2}).
\]

Thus the natural path cochain is a coboundary and telescopes on every closed
transport orbit.  This identity is correct but loses precisely the integral
information needed here: an edge contained in three selected matchings
cancels from the relevant symmetric differences.

## Exact abstract obstruction

Take states (N_k), (k\in\mathbb Z/10\mathbb Z), with two states in each of
five layers, and make the disjointness graph the cycle

\[
N_0N_1\cdots N_9N_0=C_{10}.
\]

Put an element (a) in every even state and an element (b) in every odd
state.  Put the layer semiedge (s_i) in both states of layer (i).  For each
nonconsecutive pair of opposite parity add a fresh element shared by exactly
that pair.  Then precisely consecutive states are disjoint, so canonical
transport advances one step around (C_{10}) and all the Boolean cocycle
identities above hold.

Every five-layer transversal chooses five parity types.  By the pigeonhole
principle, at least three chosen states contain (a), or at least three contain
(b).  Hence no capacity-two transversal exists.

This is an abstract incidence model, not a cubic 5-pole.  It therefore does
not refute the current conjecture.  It does prove a route boundary: any proof
must use a constraint absent from the Boolean transport data, such as cubic
graph realizability, integral perfect-matching/odd-cut inequalities, or
coupling between different transport orbits.  Further mod-two telescoping or
canonical-holonomy arguments cannot decide the conjecture by themselves.

The disposable exact verifier is
`scratch/cocycle_monodromy_leaf_20260824/verify_abstract_countermodel.py`.

