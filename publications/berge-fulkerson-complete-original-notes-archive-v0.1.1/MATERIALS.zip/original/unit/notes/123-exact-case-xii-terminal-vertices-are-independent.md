> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Case-XII support makes the five terminal vertices independent

In fact, **all twenty-five \(S\)--\(T\) types and no \(T\)--\(T\) type** suffice to force five distinct, pairwise nonadjacent terminal vertices in a cubic five-pole. The complete Case-XII support in Máčajová--Mazzuoccolo--Tabarelli (2026, Proposition 4.4, Figure 7 and the Case-XII appendix, DOI 10.26493/1855-3974.3409.c13) has precisely these properties. This strengthens the \(T\)-edge exclusion of [Note 120](120-t-paired-terminal-tree-two-cuts-are-forbidden-in-exact-case-xii.md) and the two-disjoint-\(S\)-edge exclusion of [Note 122](122-disjoint-s-terminal-edges-force-forbidden-all-terminal-bf-cover.md); neither the absence of the all-terminal type nor a minimum-host assumption is needed.

## Distinctness from positive \(S\)--\(T\) types

Write \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Suppose two semiedges \(s_i,s_j\) meet the same cubic vertex. The three positions outside \(\{i,j\}\) contain both an \(S\)-pair \(p\) and a \(T\)-pair \(q\): neither of the complementary five-cycles \(S,T\) contains a triangle. In the required BF type \((p)(q)\), both triple colours occur on both \(s_i\) and \(s_j\), because \(p,q\) avoid \(i,j\). But two semiedges incident with one cubic vertex must have disjoint colour labels. Hence **all \(S\)--\(T\) types alone force the five terminal vertices to be distinct**, without any connectivity assumption.

## One-edge BF-closure lemma

Let \(H\) be a cubic five-pole, and suppose a proper edge \(h_{14}\) joins the vertices incident with semiedges \(s_1,s_4\). Then

\[
\boxed{(25)(15)\in\operatorname{BFsupp}(H)
\quad\Longrightarrow\quad
(23)(15)\in\operatorname{BFsupp}(H).}                 \tag{1}
\]

**Proof.** Choose an actual six-perfect-matching double-cover colouring of type \((25)(15)\). Name the colour missing terminals \(2,5\) by \(U\), and the colour missing terminals \(1,5\) by \(V\). Name the four singleton colours \(A,B,C,D\), with boundaries \(1,2,5,5\), respectively. The five semiedge labels are

\[
\begin{array}{c|ccccc}
&s_1&s_2&s_3&s_4&s_5\\\hline
\phi&\{U,A\}&\{V,B\}&\{U,V\}&\{U,V\}&\{C,D\}.
\end{array}                                                   \tag{2}
\]

Every proper edge has exactly two colours. Since the three incident labels partition the six colours at each cubic vertex, \(\phi(h_{14})\) is a two-subset of the colours absent from both \(s_1\) and \(s_4\), namely \(\{B,C,D\}\). Thus it contains a colour \(Z\in\{C,D\}\).

Replace \(U\) by \(Z\) on each of \(s_1,s_4\), and replace \(Z\) by \(U\) on \(h_{14}\); leave every other edge label unchanged. At each endpoint of \(h_{14}\), the multiset of its six incident colours is unchanged, so the result is another actual six-perfect-matching double cover. Colour \(V\) is still on \(s_2,s_3,s_4\), hence misses \(15\). Colour \(Z\), originally on \(s_5\), is now on \(s_1,s_4,s_5\), hence misses \(23\). This is type \((23)(15)\), proving (1). \(\square\)

Relabel (1) by the permutation \(1\mapsto2,\ 2\mapsto4,\ 3\mapsto5,\ 4\mapsto3,\ 5\mapsto1\). It gives the second implication

\[
\boxed{h_{23}\text{ present},\quad
(14)(12)\in\operatorname{BFsupp}(H)
\quad\Longrightarrow\quad
(45)(12)\in\operatorname{BFsupp}(H).}                 \tag{3}
\]

These implications use actual BF colourings and their complete edge labels. They do not assume a Tait colouring, girth, bridgelessness, matching identities across rows, or an enumeration.

## Case-XII consequence

The Case-XII appendix lists \((15)(25)\) and \((12)(14)\) in \(L^*\), while \((15)(23)\) and \((12)(45)\) are absent. Thus (1) excludes \(h_{14}\), and (3) excludes \(h_{23}\). More generally, the dihedral automorphisms preserving the pair partition \(S,T\) are transitive on \(S\) and separately on \(T\). Relabelling (1) and (3) excludes a proper edge joining **any** two terminal vertices. Together with the distinctness argument above, this proves the stronger statement

\[
\boxed{S\times T\subseteq\operatorname{BFsupp}(H),\quad
(T\times T)\cap\operatorname{BFsupp}(H)=\varnothing
\quad\Longrightarrow\quad
\text{the five terminal vertices are distinct and independent}.} \tag{4}
\]

Here pairs of missing-pair states are unordered; \(S\times T\) means all twenty-five \(S\)--\(T\) BF types, and \(T\times T\) includes the five \(T\)-loops. Exact Case XII satisfies the premise, but (4) does not require its \(S\)-loops, other \(S\)--\(S\) types, or exclusion of \((12345)\).

For the non-cycle side of a minimum BF counterexample, [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) classifies proper two-edge cuts as isolating a one-vertex or two-vertex terminal tree. Equation (4) rules out the two-vertex case. Thus every proper two-edge cut on that side isolates a single terminal vertex.

There is an equivalent core description in this minimum-host setting. Delete each semiedge and suppress its degree-two terminal vertex. Since the five terminal vertices are independent, these five suppressions act on five distinct proper edges of a resulting connected cubic multigraph \(J\); subdividing those marked edges and attaching semiedges reconstructs \(H\). The girth-five condition from Note 019 makes \(J\) simple: a loop or parallel edge in \(J\) would expand to a proper cycle of length at most four in \(H\). The graph \(J\) is also 3-edge-connected. Indeed, a cut of size one or two in \(J\) lifts to a proper cut of the same size in \(H\): assign a suppressed terminal vertex to its common endpoint side for an internal marked edge, and to either endpoint side for a crossing marked edge. Both shores contain core vertices, so a size-one cut contradicts bridge-freeness of \(H\), and a size-two cut contradicts Note 019's classification after the two-vertex terminal trees have been excluded. Thus the remaining minimum-host object is a **simple 3-edge-connected cubic core with five distinct marked edges**. Since \(J\) is smaller than the minimum counterexample \(G\) and is bridgeless, minimality also gives a BF cover of \(J\). This cover does not automatically lift across the five marked-edge subdivisions and the opposite pentagon; that simultaneous lift is a separate matching problem.

The cyclic connectivity of \(G\) restricts cuts of this marked core. Let \(M\) be the five marked edges, let \(A\subset V(J)\), put \(k=|\delta_J(A)|\), and let \(m_A\) count marked edges with both ends in \(A\). If \(J[A]\) contains a cycle, then
\[
\boxed{k+m_A\ge5.}                                  \tag{5}
\]
Indeed, take the vertices of \(A\) in \(G\) together with the subdivision vertex of every marked edge internal to \(A\), but none of the opposite pentagon vertices or subdivision vertices on crossing marked edges. Their boundary consists of the \(k\) core-cut edges (or one half of each crossing marked edge) and the \(m_A\) links to the pentagon. Both this set and its complement contain cycles, so cyclic 5-edge-connectivity gives (5). The complementary inequality \(k+m_{V(J)\setminus A}\ge5\) holds when its core side contains a cycle. In a 3-edge-connected cubic graph, an acyclic shore of a 3-edge-cut is a single vertex by degree counting. Consequently a nontrivial 3-edge-cut of \(J\) has at least two marked edges internal to each shore and at most one marked edge crossing the cut. Likewise every triangle of \(J\) contains at least two marked edges, and every 4-cycle contains at least one. These conditions control marked-core decompositions; they do not imply a common-\(B,C\) seed.

This theorem leaves the zero-terminal-edge exact-support class unresolved. The converse of (4) fails even with all twenty-five \(S\)--\(T\) types and no all-terminal cover: the thirteen-vertex pole of [Note 024](024-common-cubic-incidence-does-not-force-an-unsafe-route-without-exact-s.md) has terminal vertices \(0,1,2,3,4\) with no edges among them, but its complete support contains \(T\)--\(T\) types. Terminal independence also cannot rescue a universal rectangle for *prescribed* rows: the conditional support-preserving attachments of [Note 116](116-alias-preserving-factor-obstruction-to-the-case-xii-rectangle.md) automatically remain in the independent-terminal class by (4), yet defeat all sixteen contexts for their marked rows. The unresolved positive target is still existential row selection in the minimum-host class, starting with the common-\(B,C\) pair-load intersection \(\Lambda_L\cap\Lambda_R\) of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md).
