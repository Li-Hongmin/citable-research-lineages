> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pair-component closure does not force a T-state in the two-window pole

Let \(H\) be the seventeen-vertex cubic 5-pole of
[Note 026](026-two-forced-path-windows-are-realizable-before-full-exact-s-closure.md),
with designated singleton perfect matchings \(N_0,\ldots,N_9\).  Their
disjointness graph is exactly \(C_{10}\), and the common even blocker

\[
a=(5,6)
\]

lies on both same-parity forced paths

\[
a\in Y_0(H-N_1)\cap Y_2(H-N_3).
\]

The complete singleton matching family of this pole has two boundary states
outside the target pentagon.  This note determines which part of matching
closure creates those states and isolates the precise closure principle that
remains insufficient.

## Pair-component closure

For each boundary class \(i\in\mathbb Z_5\), let \(\mathcal M_i\) be the
complete set of singleton perfect matchings using semiedge \(i\).  Define
\(\mathcal B_i\subseteq\mathcal M_i\) to be the smallest family containing
\(N_i,N_{i+5}\) with the following property: whenever \(P,Q\in\mathcal B_i\)
and \(C\) is a connected component of \(P\mathbin\triangle Q\), then

\[
P\mathbin\triangle C\in\mathcal B_i.
\]

Thus \(\mathcal B_i\) closes only the alternating-cycle components exposed by
matching pairs already present in the family.  It is weaker than ambient
alternating-cycle closure, which permits every \(P\)-alternating cycle of the
underlying graph and therefore generates the complete class
\(\mathcal M_i\).

## Separation theorem for the frozen pole

For the pole \(H\), the pair-component closure satisfies

\[
(|\mathcal B_0|,\ldots,|\mathcal B_4|)=(4,4,2,2,2)
\]

and its disjoint boundary-pair support is exactly

\[
T(\mathcal B)=S=\{01,04,12,23,34\}.
\]

The same designated system still has the two blocked windows displayed
above.  Consequently,

\[
\boxed{
\text{two same-parity blocked }Y\text{-windows}
+\text{ designated }C_{10}
+\text{ pair-component closure}
\not\Longrightarrow \text{ a non-}S\text{ state}.}
\]

By contrast, the complete singleton classes satisfy

\[
(|\mathcal M_0|,\ldots,|\mathcal M_4|)=(8,8,6,7,4)
\]

and

\[
T(\mathcal M)=S\cup\{02,13\}.
\]

To prove the first assertion, the five antipodal differences
\(N_i\mathbin\triangle N_{i+5}\) have respectively

\[
2,2,1,1,1
\]

alternating-cycle components.  In classes \(0\) and \(1\), the two components
are

\[
C_4=3-13-10-16-3
\]

and

\[
C_8=5-6-14-11-15-12-8-7-5.
\]

Independent component flips therefore give Boolean cubes of sizes
\((4,4,2,2,2)\).  The symmetric difference of any two members of one cube is
a union of the same original components, so these cubes are already fixed
under pair-component closure.  Their complete cross-class disjointness
support is \(S\).  Exact enumeration of all singleton perfect matchings gives
the larger class sizes and the two additional states stated above.

## The two ambient escape cycles

The common four-cycle \(C_4\) already belongs to the pair-generated Boolean
closure.  Put

\[
P_0=N_0\mathbin\triangle C_4\in\mathcal B_0,
\qquad
P_1=N_6\mathbin\triangle C_4\in\mathcal B_1.
\]

The minimum exchange certificate for state \(02\) is

\[
Q_2=N_7\mathbin\triangle D_{02},
\qquad P_0\cap Q_2=\varnothing,
\]

where

\[
D_{02}=0-4-9-13-3-16-8-12-0.
\]

Here \(Q_2\in\mathcal M_2\setminus\mathcal B_2\).  Similarly, the minimum
certificate for state \(13\) is

\[
Q_3=N_3\mathbin\triangle D_{13},
\qquad P_1\cap Q_3=\varnothing,
\]

where

\[
D_{13}=0-4-9-13-10-11-15-12-0
\]

and \(Q_3\in\mathcal M_3\setminus\mathcal B_3\).  Thus the complete ambient
closure creates the two extra states through the common \(C_4\) together
with two distinct ambient eight-cycle escapes \(D_{02}\) and \(D_{13}\).

Each of \(02\) and \(13\) has exactly two disjoint realizations in the
complete matching family.  Every participating matching is non-designated
and intersects every designated matching in every other boundary class.
Hence neither extra state can be obtained by replacing only one side of a
designated pair: both sides must undergo coordinated within-class exchanges.

All three cycles in the minimum certificates,

\[
C_4,\qquad D_{02},\qquad D_{13},
\]

avoid both blocker edges \(a=(5,6)\) and \(b=(5,7)\).  The additional states
therefore arise by global routes around the blockers, not by a uniform local
flip through a blocked edge.

## Remaining boundary

This separation does not prove or refute the general implication

\[
\text{two same-parity blocked }Y\text{-windows}
+\text{ complete matching closure}
\Longrightarrow \text{ at least one non-}S\text{ state}.
\]

It shows that a proof must use ambient information strong enough to force an
escape cycle \(D\) for which \(N_r\mathbin\triangle D\) is disjoint from a
matching in a nonadjacent boundary class.  Repeating component exchanges
exposed by the designated antipodal pairs cannot supply such a cycle: their
entire pair-component closure is already exact \(S\).

The pair-component separation and the complete extra-state decomposition are
verified independently by
[the exchange-boundary verifier](../scratch/worker-dual/closure-lemma-boundary/verify_exchange_boundary.py)
and
[the exhaustive matching-exchange verifier](../scratch/worker-dual/extra-state-exchange/analyze_extra_state_exchange.py).
Their terminal markers are `NOTE026_EXCHANGE_BOUNDARY_VERIFIED` and
`NOTE026_EXTRA_STATE_EXCHANGE_VERIFIED`, respectively.
