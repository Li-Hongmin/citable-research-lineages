> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cyclic five-connectivity does not force one-row companion alignment

The component-alignment condition isolated in
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md)
does not follow from one BF row, even when all matching occurrences belong
to one simple cyclically $5$-edge-connected cubic graph of girth five.
There is an eighteen-vertex graph with perfect matchings
$P,Y,N_0,\ldots,N_4$ such that

\[
 \chi_P+\sum_{a=0}^4\chi_{N_a}=2\mathbf 1,
 \qquad
 P\mathbin\triangle Y=C_6\mathbin\dot\cup C_6
                         \mathbin\dot\cup C_6,                 \tag{1}
\]

but no current row companion $N_a$ has the $Y$-phase on even one of
the three alternating components.  Thus the two-subset edge labels of
Note 082 have no Helly property forced by cubic incidence, girth five, or
cyclic five-connectivity.

## Construction

Put

\[
 V=\{(c,i,j):c,i\in\mathbb Z_3,\ j\in\mathbb Z_2\}.
\]

For every $(c,i)$, add

\[
 p_{c,i}=(c,i,0)(c,i,1),\qquad
 y_{c,i}=(c,i,1)(c,i+1,0).                        \tag{2}
\]

For each fixed $c$, these are the alternating edges of an induced
six-cycle.  Add the following third-edge perfect matching:

\[
\begin{aligned}
 &(0,0,0)(1,0,0),&&(2,0,0)(0,2,1),
 &&(1,2,1)(2,2,1),\\
 &(0,0,1)(1,1,0),&&(0,1,0)(1,2,0),
 &&(0,1,1)(2,0,1),\\
 &(0,2,0)(2,1,1),&&(1,0,1)(2,1,0),
 &&(1,1,1)(2,2,0).
\end{aligned}                                      \tag{3}
\]

This gives a simple connected cubic graph $G$.  Direct cut enumeration
gives

\[
 g(G)=5,\qquad \lambda(G)=3,\qquad \lambda_c(G)=5, \tag{4}
\]

where $\lambda_c$ is cyclic edge-connectivity.

## One exact double-cover row

Index five companion occurrences by
$\Omega=\{0,1,2,3,4\}$.  Label every $p$-edge by $\{0\}$, and in
each block label

\[
 y_{c,0},y_{c,1},y_{c,2}
 \quad\hbox{by}\quad
 \{1,2\},\{1,2\},\{3,4\}.                         \tag{5}
\]

At a vertex, label its third stub by the complement in $\Omega$ of the
labels on its incident $p$- and $y$-edges.  In the vertex order

\[
 (c,0,0),(c,0,1),(c,1,0),(c,1,1),(c,2,0),(c,2,1),
\]

the stub labels are

\[
 \{1,2\},\{3,4\},\{3,4\},\{3,4\},\{3,4\},\{1,2\}. \tag{6}
\]

The first three edges in (3) pair all six stubs labelled $\{1,2\}$;
the remaining six pair all twelve stubs labelled $\{3,4\}$.  Hence the
stub labels descend to honest edge labels.

Let $P=\{p_{c,i}\}$, $Y=\{y_{c,i}\}$, and let $N_a$ consist of the
edges whose label contains $a$.  The three incident labels at every
vertex partition $\Omega$ into sets of sizes $(1,2,2)$, so every $N_a$
is a perfect matching.  Explicitly,

\[
\begin{aligned}
 N_0&=P,\\
 N_1=N_2&=\{y_{c,0},y_{c,1}:c\in\mathbb Z_3\}
            \cup\{\text{the first three edges of (3)}\},\\
 N_3=N_4&=\{y_{c,2}:c\in\mathbb Z_3\}
            \cup\{\text{the last six edges of (3)}\}.
\end{aligned}                                      \tag{7}
\]

The repeated occurrences are legitimate because a BF row is a multiset
of six perfect matchings.  A $p$-edge is used by $P$ and $N_0$,
while every other edge has a two-element label.  This proves the
edgewise identity in (1).

## Empty phase intersections

On the $Y$-phase of every component of $P\triangle Y$, the labels are

\[
 \{1,2\},\quad\{1,2\},\quad\{3,4\}.               \tag{8}
\]

Their intersection is empty, and companion $0$ occurs on none of these
edges.  Therefore, for every $a$ and every component $C$,

\[
 N_a\cap C\ne Y\cap C.                             \tag{9}
\]

In particular no current companion satisfies
$\operatorname{Align}(N_a;P\to Y)$.

## Boundary of the conclusion

The example refutes precisely

\[
\begin{gathered}
 \text{one actual cubic BF row}+
 \text{girth five}+
 \text{cyclic five-connectivity}
 \\
 \Longrightarrow
 \text{a current row companion aligned with }P\to Y.
\end{gathered}                                     \tag{10}
\]

It is not an exact-Case-XII counterexample.  The graph is closed rather
than a five-pole, the five companion occurrences represent only three
distinct perfect matchings, and $Y$ itself belongs to the complete
perfect-matching family outside the displayed row.  Thus the example does
not obstruct importing an aligned matching from another row, a preparatory
splice, or the full two-splice alternatives of Note 082.  The remaining
positive interface must use cross-row information from the complete
perfect-matching closure together with exact Case-XII negative support; it
cannot be reduced to local topology or one-row load equations.

The explicit graph, exhaustive matching enumeration, cut checks, and
phase-intersection checks are frozen in the
[verification bundle](../computations/bundles/cyclically-five-connected-empty-phase-intersection/README.md).
