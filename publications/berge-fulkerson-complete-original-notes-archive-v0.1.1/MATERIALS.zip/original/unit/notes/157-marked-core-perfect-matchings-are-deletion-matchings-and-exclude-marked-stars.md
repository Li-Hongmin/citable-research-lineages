> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Marked-core perfect matchings are deletion matchings; exact Case XII excludes marked stars

[Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) reduces a minimum-host exact-Case-XII five-pole to a simple cubic core \(J\) with five distinct marked edges \(e_i=u_iv_i\): subdivide each \(e_i\) at \(t_i\) and attach terminal semiedge \(s_i\) there. The following exact description applies to any such cubic core, even when marked edges share endpoints. It gives a core-only form of the **complete perfect-matching family** and one new structural restriction: because exact Case XII realizes all ten triple-boundary states, no core vertex is incident with three marked edges. This analytic argument awaits independent checking; it does not assert existence or nonexistence of an exact-support pole.

## The complete matching bijection

Put \(F=J-\{e_1,\ldots,e_5\}\). For each perfect matching \(N\) of the five-pole \(H\), define
\[
\alpha_N(i)=
\begin{cases}
*,&s_i\in N,\\
u_i,&u_it_i\in N,\\
v_i,&v_it_i\in N.
\end{cases}                                               \tag{1}
\]
The three alternatives are exhaustive and exclusive at \(t_i\). The selected endpoints \(A_N=\{\alpha_N(i):\alpha_N(i)\ne *\}\) are distinct, since one perfect matching cannot use two edges at a core vertex. The restriction \(N_F=N\cap E(F)\) is a perfect matching of \(F-A_N\). Conversely, any choice of \(\alpha(i)\in\{*,u_i,v_i\}\) with distinct selected endpoints, together with a perfect matching of \(F-A_\alpha\), extends uniquely to a perfect matching of \(H\) by adding the corresponding semiedge or half-edge at each \(t_i\). Thus
\[
\boxed{\operatorname{PM}(H)
\longleftrightarrow
\bigl\{(\alpha,P):\alpha\text{ selects distinct core endpoints},\quad
P\in\operatorname{PM}(F-A_\alpha)\bigr\}.}              \tag{2}
\]
Its terminal boundary is \(B_N=\{i:\alpha_N(i)=*\}\). Because \(|V(J)|\) is even, \(|A_N|=5-|B_N|\) is even. Hence the boundary has odd size, as it should. In particular, a triple-boundary matching uses exactly two marked half-edges, a singleton-boundary matching uses four, and an all-terminal matching is exactly a perfect matching of \(F\). The absence of an **all-terminal BF cover** does not by itself say that \(F\) lacks a perfect matching: a single such matching may fail to complete to six matchings satisfying (3).

## An exact six-matching BF-row criterion on the core

Take six occurrence slots \(a=1,\ldots,6\), with data \((\alpha_a,P_a)\) as in (2). They give a BF double cover of \(H\) **if and only if**
\[
\begin{aligned}
\{\alpha_a(i):a\in[6]\}_{\rm multiset}
   &=\{*,*,u_i,u_i,v_i,v_i\}
       &&\text{for every }i\in[5],\\
\sum_{a=1}^{6}\mathbf1_{f\in P_a}&=2
       &&\text{for every }f\in E(F).
\end{aligned}                                             \tag{3}
\]
The first line is exactly load two on the semiedge and on both halves of each marked edge. The second is load two on every unmarked core edge. The individual condition \(P_a\in\operatorname{PM}(F-A_{\alpha_a})\) enforces all cubic vertex incidences. Conversely, these are all edges of \(H\), so (3) is sufficient. Thus a boundary type belongs to the **full graph-induced BF support** precisely when six such core deletion matchings satisfy (3) with the prescribed six boundary sets. No selected matching family or local row approximation enters this equivalence.

At a core vertex \(x\) incident with \(d\) marked edges, (3) assigns exactly \(2d\) of the six occurrence slots to its marked half-edges. The other \(6-2d\) slots must be matched on the \(3-d\) unmarked edges at \(x\), two per edge. In particular, when \(d=2\), the unique unmarked edge at \(x\) is forced to carry the two slots not assigned to marked half-edges. This is a concrete edge-label constraint for any attempt to synchronize BF rows across the five marked edges.

## Two adjacent marks: the exact local quota

Suppose \(e_i,e_j\) meet at \(x\), whose third edge \(f\) is unmarked. In a six-occurrence BF row, let \(C_i,C_j\subseteq[6]\) be the two slots using \(s_i,s_j\), and let \(L_f\subseteq[6]\) be the two slots using \(f\). The local half-edge labels at \(x\) must be disjoint two-sets \(X_i,X_j\) such that
\[
X_i\sqcup X_j\sqcup L_f=[6],\qquad
X_i\cap C_i=X_j\cap C_j=\varnothing.                    \tag{4}
\]
Such labels exist **if and only if**
\[
\boxed{C_i\cap C_j\subseteq L_f.}                       \tag{5}
\]
Necessity is immediate: a slot using both terminal semiedges cannot also use either incident marked half-edge at \(x\), so its matching must use \(f\). For sufficiency, set \(R=[6]\setminus L_f\). By the inclusion in (5), every slot of \(R\cap(C_i\setminus C_j)\) can only go to \(X_j\), and every slot of \(R\cap(C_j\setminus C_i)\) can only go to \(X_i\). Each forced group has size at most two. Assign the remaining slots, which lie outside \(C_i\cup C_j\), to fill both sets to size two: if the forced groups have sizes \(a,b\le2\), there are exactly \(4-a-b\) free slots, while the unfilled capacities sum to \((2-a)+(2-b)=4-a-b\). The opposite half-edge label at \(t_i\) or \(t_j\) is then the complement of its semiedge and \(x\)-half-edge labels, so each has size two. This proves local sufficiency.

In a pair type \((p)(q)\), the intersection \(C_i\cap C_j\) consists exactly of the triple occurrences whose boundaries contain both \(i,j\); singleton-boundary occurrences cannot belong to both. An all-terminal type instead also has its five-boundary occurrence in this intersection. In particular, for any positive Case-XII type \((p)(q)\) with \(p,q\) both disjoint from \(\{i,j\}\), the edge \(f\) is forced to carry **both triple occurrences**. Case XII requires such an \(S\)--\(T\) cell for every \(\{i,j\}\), since the three pairs on the complementary triple include both an \(S\)- and a \(T\)-pair. Nevertheless, (5) always admits some two-set \(L_f\), for every prescribed pair of terminal labels. The adjacent-mark fork therefore excludes **no BF boundary type by local incidence alone**. The global matching conditions in (2)--(3), including the same complete masks across rows, remain essential.

## Exact-support consequence

Suppose three marked edges \(e_i,e_j,e_k\) meet at one core vertex \(x\), and let \(p=[5]\setminus\{i,j,k\}\). A matching of triple boundary \([5]\setminus p=\{i,j,k\}\) would use \(s_i,s_j,s_k\). Its \(\alpha\) is therefore \(*\) at each of these three edges, so it cannot select \(x\) through a marked half-edge. But \(x\) has no edge in \(F\), and \(x\notin A_\alpha\). Hence \(F-A_\alpha\) has an isolated vertex and no perfect matching. We have proved the boundary-specific exclusion
\[
\boxed{d_{\{e_i\}}(x)=3
\quad\Longrightarrow\quad
\operatorname{PM}_{p}(H)=\varnothing,
\qquad p=[5]\setminus\{i,j,k\}.}                         \tag{6}
\]
Consequently no BF boundary type containing state \(p\) can occur, irrespective of the other triple state or the four singleton boundaries.

The Case-XII appendix of [Máčajová--Mazzuoccolo--Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires every state \(p\in S\cup T=\binom{[5]}2\) in a positive BF type: for \(p\in S\) choose a partner in \(T\), and conversely. Each such type contains an actual triple-boundary perfect matching of state \(p\). Therefore (6) gives
\[
\boxed{\text{exact Case-XII BF support}
\quad\Longrightarrow\quad
\Delta\bigl(J[\{e_1,\ldots,e_5\}]\bigr)\le2.}         \tag{7}
\]
The marked-edge subgraph is consequently a disjoint union of paths and cycles. This is additional to Note 123's simplicity, 3-edge-connectivity, terminal independence, and marked cut inequalities. It does not force the marked edges to be a matching, a common \(B_2+C_4\) seed, or a BF cover of the closed host. The unresolved step is to use the coupled six-slot condition (3), together with all positive and negative Case-XII types, to constrain the remaining marked paths and cycles.
