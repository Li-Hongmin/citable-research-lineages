> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Selected-perfect-matching negative support does not force nonoverload

The negative-support information needed after
[Notes 078--080](078-residual-degree-two-criterion-for-two-triple-completion.md)
cannot be imposed only on the perfect matchings explicitly appearing in a
failed pivot star.  There is a simple connected cubic 5-pole with fourteen
designated actual perfect matchings such that

1. the four repeated-extension pivot rows are literal BF double covers;
2. all three prescribed singleton quadruples are edge-overloaded;
3. every selected singleton pair whose boundary labels form a (T)-state
   shares a proper edge; and
4. the only BF rows using the fourteen designated identities are the four
   pivot (S)--(T) rows.  In particular this selected universe has no
   (T)-loop or (T)--(T) row.

Thus common trivalent incidence, the selected negative-support equations,
and the elementary shared-edge consequence of no (T)-loops still do not
force a nonoverloaded target.  The complete perfect-matching closure is an
essential hypothesis.

## The repeated star

Let the six singleton identities be (A,B,C,D,X,Y), where (X,Y) have
boundary class (3), and let the four pivot rows be

\[
\begin{aligned}
 &(q_{13},r_{45},A,X,C,D),\\
 &(q_{14},r_{23},A,B,X,C),\\
 &(q_{24},r_{15},A,B,C,D),\\
 &(q_{25},r_{34},B,Y,C,D).
\end{aligned}                                      \tag{1}
\]

The three target singleton quadruples are

\[
 BDXY,\qquad ACXY,\qquad ABDY.                    \tag{2}
\]

Begin with the order-eleven pole of
[Note 080](080-girth-five-and-terminal-tree-two-cuts-do-not-force-nonoverload.md).
Its designated identities realize (1), while the targets in (2) have
three-hit proper edges with signatures (BDX,CXY,ADY), respectively.

## Two balanced guards

Identify the three perfect matchings of (K_4) with three colours.  A
six-multiset double-covers the (K_4) factor exactly when each colour occurs
twice.  First colour the fourteen identities by

\[
\begin{aligned}
 E_0&=\{A,C,Y\},\\
 E_1&=\{B,D,r_{23},r_{45}\},\\
 E_2&=\{X,q_{13},q_{14},q_{24},q_{25},r_{15},r_{34}\}.
\end{aligned}                                      \tag{3}
\]

Every row in (1) has colour count ((2,2,2)).  A two-edge sum along an old
edge with signature (E_0) therefore lifts all four rows to a simple
connected order-fifteen cubic 5-pole.  Exhausting the designated
six-multisets leaves five (S)--(T) rows and no (T)-loop or
(T)--(T) row.

A second balanced colouring is

\[
\begin{aligned}
 F_0&=\{A,B,Y,q_{13}\},\\
 F_1&=\{C,D,q_{14}\},\\
 F_2&=\{X,r_{45},r_{23},q_{24},r_{15},q_{25},r_{34}\}.
\end{aligned}                                      \tag{4}
\]

Again every row in (1) has two occurrences of each colour.  The set (F_2)
is the complete designated signature of an existing proper edge, so a second
(K_4) two-edge sum gives a simple connected order-nineteen cubic 5-pole and
preserves the literal rows and the three overloads.  The two new colour
classes supply common edges for the previously missing pairs (AB,BY,CD).
Together with the old witnesses, all seven pairs

\[
 AB,AD,BX,BY,CX,CY,CD                            \tag{5}
\]

share a proper edge.  These are exactly the selected singleton pairs whose
boundary labels form a (T)-state.  Exhaustion of all six-multisets over the
fourteen identities now leaves exactly the four rows (1), all of type
(S)--(T).

## Exact boundary

The construction is not a Case-XII pole.  Its complete family has (66)
perfect matchings, and completing the BF support over that family restores

\[
 (SS,ST,TT)=(7,17,15).                            \tag{6}
\]

Consequently the refuted implication is precisely

\[
\begin{gathered}
 \text{selected common cubic PM incidence}+
 \text{four literal pivot rows}+\\
 \text{selected no-}T\text{-loop/}TT+
 \text{all seven shared-edge conditions}
\end{gathered}
\Longrightarrow
\text{a nonoverloaded target}.                    \tag{7}
\]

No conclusion here refutes the genuine full-closure Case-XII statement or
the additional irreducibility restrictions of Note 019.  The remaining
positive interface is to prove that complete perfect-matching closure,
together with exact negative support and those restrictions, converts the
three local overloads into a forbidden (T)-loop or (T)--(T) cover (or
supplies a nonoverloaded target).

The explicit pole, designated matchings, exhaustive six-multiset check, and
complete-family enumeration are frozen in the
[verification bundle](../computations/bundles/guarded-repeated-star-selected-pm-countermodel/README.md).

