> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two-five-cut barrier exclusion confuses the marked core with the minimum host

The exclusion asserted in [Note 174](174-the-one-vertex-two-five-cut-barrier-is-impossible.md) does **not** follow from its proof. In the minimum-counterexample setting, the graph \(G\) is the whole BF-uncovered host, \(H\) is its exact-Case-XII five-pole side, and \(J\) is obtained by suppressing the five marked terminal vertices of \(H\). [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) proves that \(J\) is smaller than \(G\) and bridgeless. Minimality therefore gives
\[
\boxed{J\text{ has a BF cover}.}                              \tag{1}
\]
This is precisely the opposite of the contradiction used twice in Note 174. The issue is one of host identity, not of six-slot gluing: a common BF type across a five-cut of \(J\) correctly produces a BF cover **of \(J\)**, as (1) already requires. It does not automatically produce a BF cover of \(G\) after the five marked-edge subdivisions and the opposite pentagon are restored.

## Where the published five-cut classification applies

[Proposition 4.4 of Máčajová--Mazzuoccolo--Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) classifies the two BF relations across a cycle-separating five-cut **of a minimum BF counterexample**. [Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) can legitimately apply it to one cyclic shore \(A\) of the normalized two-five-cut profile: no marked edge lies inside \(A\), so \(\delta_G(A)\) is still a five-cut, and the other side in \(G\) contains the opposite pentagon and more vertices. Thus \(A\) is an ordinary pentagon or has the Case-XIII \(L^*,R^*\) relation.

Note 174 instead cuts \(A\) off inside the **core** \(J\) and denotes the other five-pole by \(E(B)\): it consists of \(B\) and the \(u-w\) path. This is not the opposite shore of \(\delta_G(A)\). The latter contains the five marked subdivision vertices and the pentagon as well as \(B,u,w\). Consequently Proposition 4.4 does not imply that \(A=R^*\) forces \(E(B)=L^*\). Likewise, a common loop or all-terminal type between \(A\) and \(E(B)\) gives only the expected BF cover of \(J\), so Note 174's eliminations of \(R^*\) and \(L^*\) do not follow.

[Note 173](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md) proves that two pentagon shores make \(J\) three-edge-colourable. This also does not contradict the minimum-counterexample hypothesis on \(G\). At each marked subdivision vertex in \(G\), the two halves of the old \(J\)-edge and its new edge to the opposite pentagon must receive three distinct colours; the two equal-coloured halves of a colouring of \(J\) cannot simply be retained. Thus Note 173 does not exclude the pentagon--pentagon case of \(H\).

## Scope of this correction

The local slot identities (1)--(4) of Note 174 concern actual BF rows on \(B\) and its ear expansion \(E(B)\); the host-identity error alone does not refute those identities. The independent order bound of [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) still excludes tree--tree and tree--pentagon when \(|U|=1\). [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) still gives the actual complete six-slot composition criterion for the marked pole and, through its explicit rows, excludes \(L^*\)--\(L^*\) and certain relative port placements.

No valid argument in Note 174 excludes **all** two-five-cut profiles with \(|U|=1\). At the time of this correction, the pentagon--pentagon and other placements not eliminated by Note 172 remained to be decided by the complete marked-pole relation, or by a BF-cover construction on the whole \(G\). Hence [Note 166's](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) one-vertex possibilities \((4,2,2)\) and \((4,4,2)\) must both be retained. The conditional \((4,2,2)\) theorems in [Notes 175--177](177-tree-five-cut-bf-disjointness-locks-opposite-tait-triangles.md) remain statements about that profile; their wording must not treat it as the unique surviving one.

This correction does not exhibit a genuine exact-Case-XII pole or disprove the exclusion claimed in Note 174. It establishes that the given proof does not decide that exclusion and identifies the precise interface where a replacement proof must act: the full marked-pole BF support or the actual opposite shore in \(G\), with the five subdivisions and pentagon present.

[Note 179](179-a-colourable-two-shore-core-opens-to-a-tait-colourable-five-pole.md) subsequently proves that a three-edge-colouring of this particular core \(J\) **does** lift to a three-edge-colouring of the opened five-pole \(H\). This rules out the Tait-empty *pole* option for two pentagon shores; it does not restore the invalid inference that \(G\) is BF-covered.

[Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md) later excludes the pentagon--pentagon case by a separate argument on actual BF rows of \(H\). This does not restore Note 174's broader two-five-cut exclusion.

[Notes 188--193](193-two-rstar-shores-force-a-forbidden-loop-in-the-one-vertex-connector.md) later supply a different proof of the broader \(|U|=1\) two-five-cut exclusion, using Note 172's exact BF-row connector and the complete actual shore relations. That new proof does not reuse Note 174's invalid identification of the marked core \(J\) with the whole host \(G\).
