> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A singleton-b mask excludes the last non-I one-port Hall tree

Continue the exact central-path and \(3{:}2\) near-bipartite profile of [Notes 290–293](293-a-zero-port-switch-excludes-the-centered-one-port-hall-tree.md). The two \(R\)-based proper shore ports are \(q\in\{A,D\}\) and \(r\in\{H,J\}\). All five terminal vertices lie on side \(R\) after colouring the exterior as in [Note 283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md); apart from selected \(g,t_ew\), the only same-side proper edges are the cut edges at \(q,r\). The allowed Tait states are the five edges of \(S=e-a-b-d-c-e\).

**Theorem.** No \(\alpha=\eta=1,\ s\ne s_B\) four-edge Hall tree can have \((q,p,r)=(D,A,J)\), where \(p\) is the sole shore port at its \(B\)-vertex \(s\). Therefore, conditional on the upstream forced rows and Notes 289–293, every remaining four-edge Hall obstruction has \(\alpha=\eta=1,\ s\ne s_B,\ p=I\).

## The \(DH\) fibre is forbidden in this orientation

Assume \(q=D,r=J\), so \(D,J\) are \(R\)-based and \(H\) is \(B\)-based. There is **no actual shore matching** \(N\) with proper port set \(DH\) selecting both \(g,t_ew\).

For if there were, glue it to this exterior matching, whose singleton terminal is \(b\):
\[
M_b=\{b_{\rm term},a:C_{\rm ext},c:E_{\rm ext},d:B_{\rm ext},
                   1A_{\rm ext},4D_{\rm ext},h_2,h_3\}.       \tag{1}
\]
The chosen edges cover the four marked subdivision vertices \(t_a,t_b,t_c,t_d\), the four path vertices \(u_1,u_2,u_3,u_4\), and the five branch vertices \(A_{\rm ext},\ldots,E_{\rm ext}\) exactly once: the branches are covered respectively by \(1A,d:B,a:C,4D,c:E\). Its two shore ports are precisely \(D=h_2,H=h_3\), so (1) and \(N\) form a genuine complete singleton-\(b\) perfect matching.

The complement of (1) has an exterior path from terminal \(d\) to the free port \(J=h_4\):
\[
d-t_d-E_{\rm ext}-u_4-J.                           \tag{2}
\]
The sole *unselected* same-side proper edge of the full five-pole is \(J\), since \(D,g,t_ew\) are selected. Edge \(J\) lies on the open terminal path containing \(d\), by (2). All closed complement cycles therefore have zero same-side edges and are even. Alternating the two complementary colours gives a Tait colouring with singleton colour at \(b\). Its \(d\)-terminal path contains the one same-side edge \(J\), so its two terminal ends receive the same complementary colour. The other terminal path has ends in \(\{a,c,e\}\), contains no same-side edge, and its ends receive different complementary colours. Switching that path gives both of its ends, in turn, as the second singleton terminal. At most one of \(a,c,e\) is an allowed partner of \(b\), namely \(a\). One of the two Tait states is therefore forbidden. This contradicts exact Case XII and proves the \(DH\) fibre exclusion.

## Application to the Hall tree

Let \((q,p,r)=(D,A,J)\). The required \((ea)(ac)\) row has two singleton-\(a\) shore occurrences \(Y,V\) with ports \(HJ\), each selecting \(g,t_ew\), while its opposite singleton \(W_c\) has ports \(ID\), avoids \(g\), and selects \(t_ev\), by [Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md). Choose either \(Y\). At the Hall-tree vertex \(s\), \(Y\) selects \(s\hat D\), because it selects \(J\) at \(\hat J\) and does not select the \(A\) port at \(s\). The matching \(W_c\) selects \(D\) at \(\hat D\), so it uses \(s\hat J\). Consequently
\[
D-\hat D-s-\hat J-J                              \tag{3}
\]
is one entire shore component of \(Y\triangle W_c\). The other open component pairs \(I\) with \(H\).

Both \(I,H\) are based in \(B\). Their alternating path has an even number of internal edges, because one endpoint port is selected by \(W_c\) and the other by \(Y\). It therefore contains an even number of same-side edges. Every closed alternating component also contains an even number. The only same-side edges in \(Y\triangle W_c\) are \(g,t_ew\), neither of which belongs to (3). Thus they lie together either on the \(I\)--\(H\) path or on one closed alternating cycle.

In the cycle case, switching that cycle gives an actual \(ID\)-port \(W_c'\) selecting \(g,t_ew\), forbidden by Note 290. In the path case, switching the \(I\)--\(H\) path gives an actual \(DH\)-port \(W_c'\): it loses \(I\), gains \(H\), retains \(D\), and acquires \(g,t_ew\). The fibre exclusion just proved forbids this as well. Both alternatives contradict complete perfect-matching closure, proving the theorem. \(\square\)

This result leaves the four \(p=I\) one-port placements, the local incidence collisions, larger Hall barriers, other core profiles, and Berge–Fulkerson open. It is conditional on the hand-derived forced rows of Notes 271–272; no graph enumeration, local recomputation, OMEN run, or release was used.
