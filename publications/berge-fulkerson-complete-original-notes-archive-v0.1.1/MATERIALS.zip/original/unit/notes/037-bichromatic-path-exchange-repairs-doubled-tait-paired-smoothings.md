> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bichromatic path exchange repairs doubled-Tait paired smoothings

Let \(K\) be a common four-port core.  The ports \(a,b\) belong to one
deleted terminal-tree vertex and \(c,d\) to the other.  The two cross
smoothings are

\[
H_0=K+ac+bd,
\qquad
H_1=K+ad+bc.
\]

The six forced+flexible near-misses isolated in
[Note 034](034-no-order-fourteen-terminal-tree-placement-survives-both-smoothings.md)
share one mechanism: a bichromatic path exchange converts the forced
smoothing's doubled-Tait BF cover into a BF cover of the alternative
smoothing whose two new labels are disjoint.

## Bichromatic-path exchange lemma

Suppose \(H_0\) has a proper 3-edge-colouring in which \(ac\) and \(bd\)
both have colour \(\alpha\).  Let \(\beta\ne\alpha\) be another colour.  If
the port-containing path components of the \(\alpha\beta\)-subgraph of
\(K\) are routed as

\[
ad\mid bc,
\]

then \(H_1\) has a proper 3-edge-colouring in which \(ad\) and \(bc\) have
different colours.  Doubling its three colour classes therefore gives a BF
cover of \(H_1\) in which the labels of \(ad\) and \(bc\) are disjoint.

To prove this, choose the \(\alpha\beta\)-path \(P\) from \(b\) to \(c\).
In the colouring of \(H_0\), removing the two \(\alpha\)-edges \(ac\) and
\(bd\) leaves colour \(\alpha\) missing at all four ports of \(K\).
Consequently \(P\) starts and ends with \(\beta\)-edges.  Exchange
\(\alpha\) and \(\beta\) along \(P\).  Colour \(\beta\) is now missing at
\(b,c\), while colour \(\alpha\) remains missing at \(a,d\).  Delete
\(ac,bd\), add \(ad\) with colour \(\alpha\), and add \(bc\) with colour
\(\beta\).  The result is a proper 3-edge-colouring of \(H_1\).  In the
doubled colouring, \(ad\) belongs to the two copies of the
\(\alpha\)-matching and \(bc\) to the two copies of the
\(\beta\)-matching, so their BF labels are disjoint.

Equivalently, \(ac\) and \(bd\) lie on the same
\(\alpha\beta\)-bichromatic cycle of \(H_0\), and deleting those two edges
opens that cycle according to the other cross pairing \(ad\mid bc\), not
the same-side pairing \(ab\mid cd\).

## The six order-fourteen near-misses

Among the 36 terminal-tree placements of Note 034, six have one
forced-intersecting smoothing and one flexible smoothing.  All six have
the same structure:

1. the forced smoothing is \(H_0=K+ac+bd\);
2. \(H_0\) has a unique unordered BF-cover multiset;
3. that cover is a doubled Tait colouring;
4. \(ac\) and \(bd\) have the same Tait colour, and hence intersection
   parameter \(q=2\);
5. one of the other two colours gives the useful \(ad\mid bc\)
   bichromatic routing;
6. the remaining colour gives the unusable same-side routing
   \(ab\mid cd\).

The lemma therefore constructs a flexible-side \(q=0\) BF cover in every
one of the six placements.  The alternative bichromatic route is not a
second repair: its same-side pairing does not define either cross
smoothing.

The path used by the exchange has five edges in all six examples.  This
also realizes the minimum change between the forced cover and a
flexible-side \(q=0\) cover.  After minimizing over the forced BF covers,
the flexible \(q=0\) covers, and all permutations of the six matching
occurrences, every example has

\[
(r_M,r_C,d)=(4,4,10),
\]

where

\[
r_M=\bigl|\{i:M_i\ne M_i'\}\bigr|,
\qquad
r_C=\sum_i\operatorname{comp}(M_i\mathbin{\triangle}M_i'),
\qquad
d=\frac12\sum_i|M_i\mathbin{\triangle}M_i'|.
\]

The two copies of the \(\alpha\)-matching and the two copies of the
\(\beta\)-matching change along the same five-edge alternating path; the
two copies of the third colour remain fixed.  Thus four matching
occurrences change, each symmetric difference has one component, and
\(d=4\cdot5/2=10\).

## Scope

The lemma is a sufficient condition for doubled-Tait BF covers only.  It
does not prove the unrestricted paired-smoothing assertion for arbitrary
BF covers: such a cover need not arise by doubling three Tait colour
classes, so the argument does not provide an appropriate bichromatic path.
The 36 order-fourteen placements contain no double-forced example, but
that finite observation neither proves nor refutes the general
paired-smoothing lemma.  No order-sixteen census was run.

The finite comparison and its detailed output are
[paired_smoothing_exchange_analysis.py](../scratch/worker-verify/paired_smoothing_exchange_analysis.py)
and
[paired_smoothing_exchange_result.md](../scratch/worker-verify/paired_smoothing_exchange_result.md).
The program terminates with
\(\texttt{PAIRED\_SMOOTHING\_EXCHANGE\_ANALYSIS\_OK}\).
