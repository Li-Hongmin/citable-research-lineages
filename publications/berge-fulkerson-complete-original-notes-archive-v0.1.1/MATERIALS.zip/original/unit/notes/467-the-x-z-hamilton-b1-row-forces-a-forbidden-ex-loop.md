> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(B_1\) row forces a forbidden \([eX]\) loop

Continue the fixed marked Hamilton exterior, matching labels, and twelve necessary signatures of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). Assume a genuine \((eX)(eY)\) BF row has signature \(B_1\): \(P=eX\) roots at \(X:1\), \(R=eY\) roots at \(Y:5\), and the \(Y\)-to-\(W\) switch ends at \(W:3\). The singleton \(K=Y\) takes marked halves \(X:1,Z:6,W:3\), tree halves \(2u_1,4u_3,5u_4\), and proper ports \(p_2,p_5\). The shore may have arbitrary order and topology.

Let \(I=\{K,J,a,b\}\) be the four singleton labels, and for each two-set \(A\subset I\) write \(\bar A=I\setminus A\). Denote the old two-label pairs at \(p_i\) by \(A_i\). Every \(B_1\) row satisfies the three port identities
\[
\boxed{A_5=\bar A_1,\qquad A_3=\bar A_2,\qquad A_4=ab.}    \tag{1}
\]
These identities alone imply that the **same six complete shore restrictions, each used once**, admit a forbidden \([eX]\) BF recompletion.

To derive (1), put \(S=\{J,a,b\}\). At the marked \(X\) vertex, the old terminal/half pairs are \((RJ,PK,ab)\). Write \(u_1:1=R\lambda\) for \(\lambda\in S\). Then \(u_1:2=PK\) and \(A_1=S\setminus\{\lambda\}\). Original vertex \(1\) and marked \(Y\) force \(Y:5=R\lambda\). Since \(u_4:5=PK\), original vertex \(5\) gives \(u_5:5=S\setminus\{\lambda\}\); with \(u_5:6=PR\), this forces \(A_5=K\lambda=\bar A_1\).

At \(u_2\), write its two tree halves \((R\mu,P\nu)\), and its port \(A_2=K\rho\), where \(\{\mu,\nu,\rho\}=S\). The old \(Z\)- and \(W\)-marked slots propagate \(Z:6=W:3=K\mu\). At original vertex \(3\), the remaining half \(u_3:3\) is \(R\rho\); the other half \(u_3:4\) is \(PK\), since \(K\) takes \(4u_3\). Hence \(A_3=S\setminus\{\rho\}=\bar A_2\). Finally \(u_4:4=RJ\) and \(u_4:5=PK\), so \(A_4=ab\). This proves (1) using only the old genuine row's local partitions.

Now leave every edge pair on the complete shore unchanged. On the **exterior**, put the pair \(\bar A_i\) on the half of \(u_i\) toward original vertex \(i\), put \(PR\) on its half toward \(i+1\), and retain \(A_i\) on its proper port. At the four marked subdivision vertices put, in terminal/first-half/second-half order,
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(KJ,PR,ab)&(PR,A_1,A_5)&(PR,A_2,\bar A_2)&
(PR,A_3,\bar A_3).
\end{array}                                                    \tag{2}
\]
Each tree subdivision is a six-label partition \((\bar A_i,PR,A_i)\); the marked vertices are partitions by (1). The six original vertices see, respectively,
\[
(\bar A_1,PR,A_1),\quad
(PR,\bar A_2,A_2),\quad
(PR,\bar A_3,A_3),\quad
(PR,ab,\bar A_4),\quad
(PR,\bar A_5,A_5),\quad
(PR,\bar A_2,\bar A_3).                                   \tag{3}
\]
The first five are partitions because \(A_4=ab\); the last is a partition because \(A_3=\bar A_2\), hence \(\bar A_3=A_2\). The proper-port pairs \(A_i\) and shore terminal pair \(e=ab\) agree label by label with the old complete shore matchings, so (2)--(3) glue to six genuine complete perfect matchings of the **same** five-pole. Their terminal pairs are
\[
e=ab,\qquad X=KJ,\qquad Y=Z=W=PR,                        \tag{4}
\]
which is the forbidden \([eX]\) type under either Case-XII pentagon orientation for \(\{eX,eZ\}\). Therefore an exact-Case-XII pole with this marked exterior cannot have signature \(B_1\).

Together with Note 466, this leaves \(B_2,B_3,C_1,\ldots,C_7\) as nine necessary tree signatures for the \(\{eX,eZ\}\) forbidden pair; reflection gives the corresponding exclusion for \(\{eY,eW\}\). The argument says nothing about the remaining signatures, other marked exteriors, or the complete Case-XII obstruction. It is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review. \(\square\)
