> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other two-spoke prism excludes the \(AC,ab\) forbidden pair

Consider the triangular prism with tree
\[
(u_1,u_2,u_3,u_4,u_5)=(AB,BC,Aa,Bb,bc)
\]
and marked terminals \(X=AC,\ Y=Cc,\ Z=ac,\ W=ab\). The sixth terminal \(e\) is on an arbitrary six-port shore. This is a different two-spoke tree from [Note 423](423-no-exact-case-xii-pole-has-the-marked-two-spoke-prism-exterior.md): the tree has a unique degree-three prism vertex \(B\); its spoke-neighbour \(b\) has tree degree two here but degree one in Note 423. Prism automorphisms preserve spokes, so they cannot identify the trees. Suppose exact Case-XII support has forbidden \(e\)-labels \(\{X,W\}\). Its two possible allowed pentagons are
\[
S_1=e-Y-X-W-Z-e,\qquad S_2=e-Y-W-X-Z-e.               \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a mixed \((eX)(eY)\) row and excludes all \(T\)--\(T\) rows.

> **Pair exclusion.** Neither pentagon in (1) is the complete BF boundary support of a pole with this marked tree and any shore. The required \((eX)(eY)\) row cannot survive full perfect-matching closure.

Suppose the row exists. Name its forbidden triple \(P=eX\), allowed triple \(R=eY\), singleton occurrences \(K=Y,J=X\), and two singleton-\(e\) occurrences \(D_0,D_1\). The \(Y\)-starting path of \(R\triangle K\) must end at \(Z\): endings at \(X,W\) would produce a second \(T\)-triple beside unchanged \(P=eX\). Both roots \(A,C\) of \(P=eX\) take \(cu_5\).

**The \(c\)-root of \(R=eY\) is impossible.** Its rooted tree slots are \((A,C,a,B,b)\). From \(Y-t_Y-c\), the path can end directly through \(t_Z\) at \(Z:c\). Otherwise \(K:cu_5\) takes it to \(b\). The branch \(W:b\) is forbidden, so it follows \(bu_4\) to \(B\). From \(B\), the \(Bu_2\) route reaches \(C\), where \(X:C\) is forbidden and \(Y:C\) is unavailable because \(K\) takes the \(Y\) terminal. The \(Bu_1\) route reaches \(A\); \(X:A\) is forbidden, so it follows \(Au_3\) to \(a\). The only allowed endpoint there is \(Z:a\), but now \(K\) covers \(b\) by \(bu_4\) and \(a\) by \(Z:a\), leaving neither endpoint to cover the \(W=ab\) subdivision. Thus the only allowed path is the wholly exterior
\[
Y-t_Y-c-t_Z-Z.                                        \tag{2}
\]

Switch (2) to \(R'=eZ:c\) with the same complete shore mask as \(R\). At \(c\), \(P,R,K\) take \(cu_5,Y:c,Z:c\), respectively. The remaining occurrences \(J,D_0,D_1\) each take one of these edges, so some \(e\)-singleton \(D\) takes \(Y:c\) or \(Z:c\). In \(R\triangle D\) and \(R'\triangle D\), the exterior \(X,W\) terminal components are unchanged; the short switch only relabels the \(Y/Z\) arm. If \(X,W\) join wholly outside the shore, the prescribed \(e\)-switch is already impossible. Otherwise their unchanged arms exit at distinct ports. Yet the shore \(e\)-path has the same first proper exit against \(R,R'\): \(S_1\) requires it to select \(X\) then \(W\), and \(S_2\) requires \(W\) then \(X\). This contradiction leaves only \(R=eY:C\).

**The \(C\)-root has one \(Y\to Z\) path.** Its rooted tree slots are \((A,B,a,b,c)\). From \(Y-t_Y-C\), \(K\) cannot take \(X:C\), so it takes \(Cu_2\) to \(B\). The \(Bu_1\) route reaches \(A\): \(X:A\) is forbidden, and continuing through \(Au_3\) to allowed \(Z:a\) would occupy both endpoints \(A,C\) of the \(X=AC\) subdivision in \(K\). Hence \(K:Bu_4\), and the path reaches \(b\). Taking \(W:b\) is forbidden, so it follows \(bu_5\) to \(c\) and ends at \(Z:c\). The \(Y\) terminal prevents taking \(Y:c\). Covering the remaining marked subdivisions fixes
\[
K:\quad Y\text{ terminal},\quad X:A,\quad W:a,\quad Z:c,
\quad Cu_2,\ Bu_4,\ bu_5,\quad p_1,p_3.               \tag{3}
\]
Switch this wholly exterior path to an allowed triple \(R'=eZ:c\) with the same complete shore mask as \(R\). The rooted tree slots of \(R'\) are \((A,C,a,B,b)\).

**Root \(P=eX:A\).** Here \(P,K\) both take \(X:A\), while \(R,J\) take the \(X\) terminal; thus both \(D_i\) take \(X:C\). Since \(P,K\) saturate \(Cu_2\) and \(R:Y:C\), the singleton \(J\) takes \(Y:C\). Fix either \(D=D_i\). It cannot also take \(Y:C\), so \(D:Y:c\).

Under \(S_1\), the \(e\)-path of \(R=eY\) against \(D\) must end at \(X\). Switching that complete path produces \(H=XY\in S_1\). Its exterior takes \(Y:c\): the \(X\)-starting arm runs through \(X-t_X-C-t_Y-c\), since \(D:X:C,Y:c\) and \(R:Y:C\). The unchanged \(K\) takes the \(Y\) terminal and \(Z:c\). Thus \(Y-t_Y-c-t_Z-Z\) is a wholly exterior path of \(H\triangle K\); switching it gives \(XZ\in T_1\) beside unchanged \(P=eX\in T_1\).

Under \(S_2\), use the \(e\)-path of \(R'=eZ\) against the same \(D\). It must end at \(X\), giving \(H'=XZ\in S_2\). Since \(D:X:C\), the new \(H'\) takes \(X:C\). The unchanged singleton \(J\) takes \(Y:C\) and the \(X\) terminal, so \(X-t_X-C-t_Y-Y\) is a wholly exterior path of \(H'\triangle J\). Switching it gives \(YZ\in T_2\) beside unchanged \(P=eX\in T_2\). Both orientations are impossible.

**Root \(P=eX:C\).** At the \(X\) subdivision, \(P:X:C\), \(K:X:A\), and \(R,J\) take the terminal. Thus one \(e\)-singleton \(D_C\) takes \(X:C\), while the other \(D_A\) takes \(X:A\). The \(S_1\) two-switch contradiction above uses only \(D_C:X:C,Y:c\) and \(K:Z:c\); it applies unchanged.

For \(S_2\), first show \(J:Y:C\). At \(C\), \(P:X:C\), \(R:Y:C\), \(K:Cu_2\), and \(D_C:X:C\). If \(J\) did not take \(Y:C\), then \(D_A:Y:C\). Since \(P,R\) saturate \(cu_5\), this \(D_A\) takes \(Z:c\); since \(P,R\) saturate \(au_3\), it takes \(W:a\). It also takes \(X:A\), so its \(u_3\)-slot is \(p_3\). Against both \(R=eY\) and \(R'=eZ\), its exterior \(W\)-terminal arm is the unchanged path \(W-t_W-a-u_3-p_3\). Under \(S_2\) the same shore \(e\)-exit must instead select \(W\) against \(R\) and the distinct \(X\)-arm against \(R'\). If the two arms join wholly outside the shore, the prescribed switch already fails; otherwise their exits differ. Thus \(J:Y:C\).

Now switch \(R'=eZ\) with \(D_C=e\) along its required complete \(e\to X\) path. The new triple \(H'=XZ\) takes \(X:C\), while \(J\) takes \(Y:C\) and the \(X\) terminal. The same exterior path \(X-t_X-C-t_Y-Y\) changes \(H'\) to \(YZ\in T_2\) alongside unchanged \(P=eX\in T_2\). This excludes \(S_2\), finishing both roots of \(P\) and \(R\). \(\square\)

This result concerns the forbidden pair \(\{AC,ab\}\) in the second two-spoke tree only. The other five forbidden pairs here, the one- and three-spoke prism trees, other deficient-core profiles, and the full Berge–Fulkerson conjecture remain open. The proof is hand-derived from complete matching occurrences and awaits independent review; no OMEN or local mathematical recomputation was used.
