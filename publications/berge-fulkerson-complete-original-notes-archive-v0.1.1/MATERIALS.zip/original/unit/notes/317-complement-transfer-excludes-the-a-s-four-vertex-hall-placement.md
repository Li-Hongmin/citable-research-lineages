> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complement transfer excludes the A-s four-vertex Hall placement

Continue the genuine left \((ea)(ac)\) and right \((ea)(ad)\) rows
in the noncollision, complete exact-Case-XII \(R_0=DJ\)
near-bipartite branch. Use [Note 315's](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md)
first possible four-vertex Hall incidence graph
\[
 S=\{h,k,\ell,m\},\quad T=\{o,r,s,t\},\qquad
 o\{h,k,\ell\},\ r\{h,m\},\ s\{k,m\},\ t\{\ell,m\},
 \quad \ell d.                                             \tag{1}
\]
Suppose \(H\) is at \(h\), \(A\) at \(k\), \(J\) at
\(s\), and \(D\) at \(d\). The third edge at each of
\(r,t\) leaves the displayed block; denote the one at \(t\)
by \(t\tau\).

**Theorem.** This \((P,j)=(A,s)\) placement is impossible.
Together with [Note 316's](316-zero-port-phase-closure-restricts-the-four-vertex-hall-block.md)
exclusion of \((I,s)\), no first-order four-vertex
\((\alpha,\eta)=(2,1)\) Hall block can have \(j=s\).

**Proof.** By Note 316 the genuine right zero-port shore matching
\(X_R(g,t_{ew})\) uses \(\ell d\). Since \(o\) has no edge
outside (1) and the unselected \(J\)-port forces \(s\) to be
matched internally, its remaining local edges are one of
\[
 \{ho,ks,mr\},\qquad \{ho,ks,mt\},\qquad
 \{hr,ko,ms\}.                                             \tag{2}
\]
The first choice leaves the complete complementary port path
\(A-k-o-\ell-t-m-s-J\); the third leaves \(A-k-s-J\).
[Note 285's complete zero-port pairing table](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
for \(R_0=DJ\) forbids either \(AJ\) path. Consequently
\[
                 X_R:\quad \ell d,ho,ks,mt.                  \tag{3}
\]

Take either genuine left singleton-\(a\) shore matching \(Y\).
It selects \(H,J,g,t_{ew}\), by
[Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md).
The ports cover \(h,s\), so \(Y\) uses \(ko\) and then
one of
\[
 (\ell t,mr),\qquad(\ell d,mr),\qquad(\ell d,mt).          \tag{4}
\]
In \(Y\triangle X_R\), the full local alternating path
\(H-h-o-k-s-J\) is a component. Switch it into \(Y\),
obtaining an actual zero-port matching \(N\) which still selects
\(g,t_{ew}\). The first choice of (4) makes \(N\) use a full
block matching avoiding \(\ell d\), contradicting Note 316.
The second gives \(N\) the first choice of (2), whose
complementary \(AJ\) path was just excluded. Hence \(Y\) uses
\(\ell d,mt\), and \(N\) has the local edges in (3).

Now compare the *complements* of \(Y\) and \(N\). In the complement
of \(Y\), the complete local segment from \(A\) to the sole
available exit \(t\tau\) is
\[
                  A-k-s-m-r-h-o-\ell-t-\tau.                 \tag{5}
\]
Indeed, \(Y\) selects the third edge at \(r\), as well as
\(H,J,ko,\ell d,mt\). Its complement has no other exit from
the displayed block: \(H,J,\ell d\) and the third edge at
\(r\) are selected. [Note 301's full-fibre rule](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
requires the shore complement of every such \(Y\) to pair
\(EI\mid AD\). Thus the continuation of (5) outside the
displayed block runs from \(\tau\) to \(D\).

The switch from \(Y\) to \(N\) changes no edge outside
\(H-h-o-k-s-J\). In particular it retains that
\(\tau\)--\(D\) complement continuation. Inside the block,
the complement of \(N\) has the two complete segments
\[
            A-k-o-\ell-t-\tau,
            \qquad H-h-r-m-s-J.                              \tag{6}
\]
Therefore its six shore ports pair \(AD\) and \(HJ\).
But Note 285 allows only
\[
             EA\mid ID\mid HJ
       \quad\text{or}\quad EJ\mid AD\mid IH               \tag{7}
\]
for *every* actual zero-port \((g,t_{ew})\) matching in this
placement. Neither pairing in (7) contains both \(AD\) and
\(HJ\). This contradiction proves the theorem. \(\square\)

This proof does not treat \(j=r,t\); [Notes 318–319](319-no-four-vertex-six-cut-hall-block-in-the-right-dj-branch.md)
exclude those positions separately. Larger Hall blocks, the
\((1,2)\) allocation, incidence collisions, other core
profiles, and Berge–Fulkerson remain open.
This is a hand-derived full perfect-matching closure argument;
no local recomputation or OMEN run was used.
