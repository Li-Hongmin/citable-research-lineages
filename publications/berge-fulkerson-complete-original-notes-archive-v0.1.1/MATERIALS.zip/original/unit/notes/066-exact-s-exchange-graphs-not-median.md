> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact-\( S \) singleton exchange graphs need not be median

The median/convex Helly condition is sufficient for a common singleton section, but it is not forced by real cubic incidence. In the verified order-15 exact-\( S \) (C_5\sqcup C_5) pole (47 perfect matchings; singleton class sizes (5,4,5,5,5)), the alternating-cycle exchange graphs of the five singleton classes have respectively (8,6,8,8,8) edges and each contains a triple of vertices whose three geodesic intervals have empty intersection. Thus none of these five exchange graphs is median.

Consequently, cubic vertex equations plus exact-\( S \) do not imply the median/convex Helly hypotheses. The remaining capacity-two problem cannot be reduced to exchange-graph Helly; it must use stronger joint PM-incidence or classwise compatibility constraints.
