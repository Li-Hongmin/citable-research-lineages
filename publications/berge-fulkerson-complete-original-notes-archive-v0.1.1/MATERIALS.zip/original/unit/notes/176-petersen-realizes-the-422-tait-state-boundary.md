> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Petersen realizes the \((4,2,2)\) Tait-state boundary

The one-vertex \((4,2,2)\) quotient in [Note 166](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) cannot be excluded by asking the two shores of its five-cut to share a three-edge-colouring state. A marked Petersen graph has exactly that quotient and **disjoint shore Tait-state sets**, yet its complete BF matching family supplies a common pair type and a BF cover of the core. This is a real graph boundary for a Tait-only argument, not an exact-Case-XII five-pole. [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) retains the other one-vertex quotient as open.

## The cubic host and its marked barrier

Use outer vertices \(v_1,\ldots,v_5\) in cyclic order and inner vertices \(u,z,w,x,y\). Give the outer cycle the five edges \(v_iv_{i+1}\) (indices modulo five), the spokes
\[
v_1u,\quad v_2z,\quad v_3w,\quad v_4x,\quad v_5y,
\]
and the inner edges
\[
uw,\quad wy,\quad yz,\quad zx,\quad xu.
\]
The inner edges join indices \(1,3,5,2,4,1\), so this is the usual Petersen graph. Mark
\[
M=\{xu,xv_4,yw,yv_5,uw\}.                              \tag{1}
\]
Subdividing these five edges and attaching terminal semiedges gives a genuine fifteen-vertex cubic five-pole \(H\).

Put \(F=J-M\) and \(U=\{z\}\). Then \(F\) is connected through \(zv_2\); after deleting \(z\), its three odd components are the singletons \(\{x\},\{y\}\) and the seven-vertex component
\[
C=\{v_1,\ldots,v_5,u,w\},
\]
whose unmarked edges are the outer pentagon together with \(v_1u,wv_3\). The four crossing marks are \(xu,xv_4\) at \(x\) and \(yw,yv_5\) at \(y\); \(uw\) is the sole mark inside \(C\). Thus the quotient is exactly \((4,2,2)\). The four edges \(zx,v_1u,wv_3,v_4v_5\) form a matching of \(F\) with eight covered vertices. Since \(o(F-U)-|U|=3-1=2\), Tutte--Berge gives deficiency exactly two, and \(U\) is a smallest maximum barrier.

## Tait states are disjoint across the five-cut

Cut the five edges between the three-vertex tree \(T=\{z,x,y\}\) and \(C\). Name their ports
\[
p=xu,\quad q=yw,\quad r=zv_2,\quad s=xv_4,\quad t=yv_5.
\]
The centre port of \(T\) is \(r\), and its end-port groups are \(\{p,s\}\mid\{q,t\}\). Its four Tait missing-pair states are exactly
\[
\mathcal T(T)=\{pq,pt,qs,st\}.                             \tag{2}
\]
The other shore is the pentagon with a three-edge path \(v_1-u-w-v_3\), with the same port positions \(p,q,r,s,t\). [Note 173's exhaustive six-colouring table](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md) gives
\[
\mathcal T(C)=\{rt,rs,ps,qt,pr,qr\}.                    \tag{3}
\]
The sets (2)--(3) partition all ten port pairs. A three-edge-colouring of the host would restrict to a common Tait state on both shores; conversely a common state could be colour-aligned and glued. There is none, so the host is not three-edge-colourable. Its failure of the Tait overlap test is therefore exact, with no local enumeration.

## A genuine BF pair still glues

The Petersen graph has a six-perfect-matching BF cover visible without a search. Let \(P_0\) contain all five spokes. For each \(i\in\{1,\ldots,5\}\), let \(P_i\) contain spoke \(v_iI_i\), the unique two-edge matching of the outer pentagon after deleting \(v_i\), and the unique two-edge matching of the inner pentagon after deleting its corresponding vertex \(I_i\), where \((I_1,I_2,I_3,I_4,I_5)=(u,z,w,x,y)\). Each spoke occurs in \(P_0,P_i\); each edge of either pentagon occurs in exactly two of the five deletion matchings. Hence every host edge is covered twice.

On the five-cut, the six actual matching boundaries are
\[
\begin{array}{c|cccccc}
\text{matching}&P_0&P_1&P_2&P_3&P_4&P_5\\\hline
\text{boundary}&\{r,s,t\}&\{q\}&\{p,q,r\}&\{p\}&\{s\}&\{t\}
\end{array}
\]
and therefore have BF type \((pq)(st)\). Its two states belong to the tree's Tait set (2), while **neither belongs to the cyclic shore's Tait set (3)**. The cyclic shore nevertheless supports this pair type through its full actual six-matching closure. Thus shared Tait states are sufficient for a host three-edge-colouring but are not necessary for a host BF cover.

The marked pole \(H\) has order fifteen, so [Note 100's complete-support bound](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) excludes exact Case XII for it. The example refutes only the proposed Tait-overlap shortcut for the real \((4,2,2)\) topology; it does not refute a statement that also assumes exact Case XII or a minimum BF-counterexample host. A proof for this possible branch must use full perfect-matching closure, including BF pair types that are absent from the shores' Tait-state intersection.
