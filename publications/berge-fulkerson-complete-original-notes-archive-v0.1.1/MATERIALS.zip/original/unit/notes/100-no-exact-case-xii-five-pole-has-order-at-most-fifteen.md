> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No exact Case-XII five-pole has order at most fifteen

There is no simple connected cubic five-pole of odd order at most \(15\),
with five distinct terminal vertices and bridgeless proper-edge graph, whose
complete Berge--Fulkerson boundary support is exactly the forty types of
Case XII.  Consequently, if a real exact-Case-XII pole exists in this class,
then its order is at least \(17\).

Here ``exact Case XII'' means that the complete perfect-matching closure has
all fifteen \(S\)--\(S\) types and all twenty-five \(S\)--\(T\) types, and has
no all-terminal type, no \(T\)-loop, and no \(T\)--\(T\) type.  No assumption
on the Tait-state set is used as a preliminary filter.

## Exhaustive order-fifteen census

Represent a five-pole by adjoining one apex to its five semiedges.  The
result is a simple graph on sixteen vertices with degree sequence
\((5,3^{15})\); conversely, deleting the unique degree-five vertex recovers
the pole and its five distinct terminal incidences.  Unlabelled generation
with

```text
geng -q -c -d3 -D5 16 25
```

produced \(922{,}347\) connected augmented graphs.  Exactly \(89{,}064\)
had degree sequence \((5,3^{15})\).  After deleting the apex, \(86{,}577\)
had connected proper core and \(69{,}243\) also had no proper-edge bridge.

For every one of these \(69{,}243\) poles, the computation independently
enumerated its complete family of perfect matchings.  It then enumerated all
six-matching multisets with edge load exactly two, classified their boundary
types, and canonicalised the five terminal labels under all permutations.
None had exact Case-XII support.  The candidate list is empty.

The search does not first require the Tait states to form a particular
pentagon.  This is essential: the Case-XII definition concerns the complete
BF boundary support, and the negative \(A\) and \(T\)--\(T\) conditions are
checked on that same complete closure.

## Completeness and reproduction

The order-fifteen wrapper changes only the order parameter of the same
streaming scanner used for the lower-order census.  The completed Omen run
reported

```text
ORDER15_EXACT40_CENSUS_OK
EXIT_STATUS=0
```

after \(1016.245572\) seconds.  Its decisive hashes are

```text
all generated graph6 stream:
742ad906e2ece9d8828d513cf1a790c015c653d9de2fc916ace51ef3d8a399dc

connected proper-core graph6 stream:
6fe15a6e0c7569d764811201a74ff1bbd1b32f68e88d8a446b94288696950ed9

proper-bridgeless classified records:
6d4fa421e3a84e3bcc7c7c4c8268322809ff8d4af6593e6ac96ab3e1a38218e5

result JSON:
c0badaf56a5d6998e39051160940f7722513df3b13fdebbd39135e325c7b564d
```

The frozen source, log, and JSON are presently in
`scratch/worker-bf-order15-exact40-census/`.  The Omen copy is
`[unbundled local reference]`.

For the lower odd orders, the [direct full-BF-support scan through order
eleven](../scratch/worker-bf-s-gate/target-case-xii-support-scan-result.md)
checks all simple connected distinct-terminal poles at orders \(5,7,9,11\),
with no exact-support hit. The separate [order-thirteen complete-support
census](../scratch/worker-bf-pm-closure/real-case-xii-d5-order13-result-20260901.md)
checks all \(4{,}794\) connected proper-bridgeless candidates and has no hit.
Neither direct scan assumes a Tait state set. Combining these two direct
results with the order-fifteen census proves the stated lower bound
\(n\ge17\).

The earlier attempted shortcut through [Note 005](005-pentagon-selection-is-false-and-a-weaker-transversal-survives.md)
is invalid: a BF loop \([s]\) need not come from a three-edge-colouring.
Doubling a three-edge-colouring gives a BF loop, but the converse does not
follow from the loop type. The correct Tait-state conclusion under exact
Case-XII support is the dichotomy
\[
\mathcal T(H)=\varnothing\quad\text{or}\quad\mathcal T(H)=S. \tag{1}
\]
Indeed a \(T\)-state would give a forbidden \(T\)-loop by doubling, while
one \(S\)-state generates every \(S\)-state by the standard Kempe-switch
closure (equivalently, [Note 055](055-half-load-column-saturation-and-case-xii-compression.md)
with half-load \(\mathbf1\)). For an actual counterexample to the false
loop-to-Tait converse,
two-sum the five-cycle pole with the Petersen graph along one proper edge.
The Petersen graph has a BF cover, so [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md)
preserves every five-cycle BF loop. A three-edge-colouring of the sum would
give the two connector edges the same colour by parity on the ten Petersen
vertices; closing them to the deleted Petersen edge would three-edge-colour
the Petersen graph, a contradiction. Thus this BF-loop-bearing pole has no
Tait state at all. The same argument applies to a Petersen insertion into
*any* BF-covered five-pole: it keeps its complete BF support and removes all
three-edge-colourings. Consequently, if exact Case-XII support is realized
by any pole, it is also realized by a Tait-empty pole after such an insertion
(although the inserted two-edge cut need not be eligible in a minimum host).
This direction of implication agrees with Lemma 4.3 of
Máčajová--Mazzuoccolo--Tabarelli (2026, DOI
10.26493/1855-3974.3409.c13), checked against its primary PDF on
2026-09-29; that lemma starts from a given
three-edge-colouring and constructs BF loops. The finite lower bound here
rests on the direct complete-support scans above.

## Boundary of the result

This is a finite nonexistence theorem, not a proof that Case XII is
impossible at arbitrary order.  It does not establish the dependent
two-splice fibre of [Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md),
and it does not justify an order-seventeen scan.  Its role is to remove every
real counterexample through order fifteen from the remaining full-PM-closure
problem.
