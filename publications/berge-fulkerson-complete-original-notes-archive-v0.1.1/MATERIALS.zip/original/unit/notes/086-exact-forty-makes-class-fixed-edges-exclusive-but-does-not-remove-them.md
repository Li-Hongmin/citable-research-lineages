> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact forty support makes class-fixed edges exclusive but does not remove them

Let \(H\) be a cubic five-pole with distinct terminal vertices and let
\(\mathcal P_i\) be its singleton-boundary perfect matchings in class
\(i\).  For each class put

\[
 F_i=\bigcap_{P\in\mathcal P_i}(P\cap E_{\mathrm{proper}}(H)). \tag{1}
\]

Exact Case-XII boundary support forces these five fixed-edge sets to be
pairwise disjoint.  It does not, even together with the known girth and cut
conditions, force the individual sets to be empty.  A fifteen-vertex
Petersen-subdivision pole gives a sharp topology-level counterexample.

## Exact forty support makes fixed edges class-exclusive

Write

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Suppose that the BF support of \(H\) contains all fifteen \(S\)--\(S\)
types and all twenty-five \(S\)--\(T\) types.  Then

\[
 F_i\cap F_j=\varnothing\qquad(i\ne j).          \tag{2}
\]

If \(ij\in S\), choose a BF cover of loop type \((ij)(ij)\).  Its four
singleton occurrences consist of two members of \(\mathcal P_i\) and two
members of \(\mathcal P_j\).  An edge in \(F_i\cap F_j\) would therefore
have load at least four, contradicting the BF load two.

If \(ij\in T\), choose \(s\in S\) meeting \(ij\) in exactly one endpoint,
say \(i\in s\) and \(j\notin s\), and use a cover of type \((s)(ij)\).
The singleton boundary multiset is \(s\mathbin{\dot\cup}ij\), so this row
contains two class-\(i\) occurrences and one class-\(j\) occurrence.  A
common fixed edge would have load at least three, again impossible.  This
proves (2).

Thus every proper edge is fixed in at most one singleton class.  In
particular, whenever an overloaded selected tuple uses an edge in at least
two distinct singleton classes, at least one of those classes has another
perfect matching avoiding that edge.  The unresolved issue is whether such
an avoiding matching can be chosen in the required pivot fibre and with the
component phase needed by [Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).

## Exact characterization within one singleton class

Let \(\bar H\) be the proper-edge skeleton and let \(v_i\) be the terminal
vertex incident with semiedge \(i\).  Deleting the selected semiedge and its
already covered endpoint gives a bijection

\[
 \mathcal P_i\cong\operatorname{PM}(\bar H-v_i). \tag{3}
\]

Put \(G=\bar H-v_i\), fix \(P\in\operatorname{PM}(G)\), and let \(e\in P\).
The following are equivalent:

1. some perfect matching of \(G\) avoids \(e\);
2. \(G-e\) has a perfect matching;
3. there is no \(X\subseteq V(G)\) satisfying
   \[
   o(G-X)=|X|,\qquad o(G-e-X)=|X|+2;             \tag{4}
   \]
4. \(e\) lies on a \(P\)-alternating cycle in \(G\).

Only (4) requires explanation.  If \(G-e\) has no perfect matching, then
\(P-e\) leaves only the ends of \(e\) unmatched, so its Tutte deficiency is
exactly two.  Hence some \(X\) satisfies the second equality in (4).
Adding one edge can reduce the number of odd components by at most two,
while the perfect matching of \(G\) gives \(o(G-X)\le |X|\); the first
equality follows.  Conversely the second equality violates Tutte's
criterion for \(G-e\).  The equivalence with the alternating-cycle condition
is the standard symmetric-difference decomposition of two perfect
matchings.

## A Petersen-subdivision counterexample

Take the Petersen graph \(J\) on

\[
 \{0,1,2,3,4,5,a,b,u,w\}
\]

with edge set

\[
\begin{aligned}
\{&0a,a3,1b,b4,0u,u4,1w,w3,25,05,15,23,24,ab,uw\}.
\end{aligned}                                    \tag{5}
\]

Subdivide \(05,15,23,24,uw\) once, naming the new vertices respectively
\(t_1,t_2,t_3,t_4,v\), and attach one semiedge at each new vertex.  The
result is a simple connected bridge-free fifteen-vertex five-pole of girth
five.  Its only proper two-edge cuts are the five pairs of halves of a
subdivided edge, and each cuts off one terminal vertex.  The unsubdivided
edge

\[
 e=ab                                             \tag{6}
\]

belongs to none of them.

Nevertheless \(ab\in F_v\).  In \(G=\bar H-v\), the seven edges

\[
 ab,\ 0u,\ 3w,\ 5t_1,\ 1t_2,\ 2t_3,\ 4t_4       \tag{7}
\]

form a perfect matching.  After deleting \(ab\), the set

\[
 D=\{a,b,u,w,t_1,t_2,t_3,t_4\}
\]

is independent and has all its neighbours in

\[
 X=\{0,1,2,3,4,5\}.
\]

Thus

\[
 o(G-ab-X)=8=|X|+2,                              \tag{8}
\]

and no perfect matching of \(G-ab\) exists.  By (3), every member of
\(\mathcal P_v\) contains \(ab\).

There is no hidden small-cut explanation.  If the five semiedges are closed
by a fresh cycle in the order \(t_1,t_2,t_3,t_4,v\), the resulting
twenty-vertex cubic graph has girth five and cyclic edge-connectivity five.
A complete matching and cut calculation gives

\[
 (|\mathcal P_{t_1}|,|\mathcal P_{t_2}|,
   |\mathcal P_{t_3}|,|\mathcal P_{t_4}|,|\mathcal P_v|)
   =(5,5,5,5,2)
\]

and

\[
 (F_{t_1},F_{t_2},F_{t_3},F_{t_4},F_v)
   =(\varnothing,\varnothing,\varnothing,\varnothing,\{ab\}). \tag{9}
\]

The fixed graph and exhaustive verifier are frozen in the
[verification bundle](../computations/bundles/fixed-singleton-edge-petersen-subdivision/README.md).

## Consequence for the Case-XII route

The example is not an exact-Case-XII pole, so it does not refute the desired
two-splice conclusion.  It proves that girth five, cyclic edge-connectivity
five, the terminal-tree classification of proper two-cuts, and keeping the
target edge outside those cuts do not force a same-class avoiding perfect
matching.  The only general positive information currently obtained from
exact forty support is the class-exclusivity (2).

Accordingly, the next proof interface is not to exclude fixed edges by
topology.  It is to use (2) inside an actual positive pivot row: after moving
to a singleton class in which the overload edge is avoidable, one must show
that a suitable avoiding matching lies in a paired alternating-cycle switch
which preserves the pivot row and supplies the phase alignment required by
Note 082.
