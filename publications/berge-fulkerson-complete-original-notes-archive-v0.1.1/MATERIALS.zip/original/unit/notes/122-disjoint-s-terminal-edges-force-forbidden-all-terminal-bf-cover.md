> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two disjoint \(S\)-terminal edges cannot occur in an exact Case-XII pole

**Stronger subsequent result.** [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) excludes even one \(S\)-terminal edge, using only the positive type \((25)(15)\) and the absent type \((23)(15)\). The two-edge theorem below remains a valid, weaker local closure statement.

The conditional two-edge rectangle obstruction in [Note 121](121-two-disjoint-s-terminal-edges-obstruct-every-case-xii-rectangle-target.md) has an empty exact-Case-XII premise. A single required positive BF row, the absence of the all-terminal type, and one absent \(T\)--\(T\) type already exclude its two terminal edges. This is an all-orders theorem for actual cubic five-poles and their complete BF support; it uses neither a Tait colouring nor any perfect-matching enumeration.

## The local impossibility theorem

Let \(H\) be a cubic five-pole with five distinct terminal vertices. Suppose \(h_{14}\) joins the vertices incident with semiedges \(s_1,s_4\), and \(h_{25}\) joins those incident with \(s_2,s_5\). Then

\[
\boxed{
(14)(23)\in\operatorname{BFsupp}(H),\quad
(12345)\notin\operatorname{BFsupp}(H),\quad
(23)(34)\notin\operatorname{BFsupp}(H)
\quad\Longrightarrow\quad\bot.}                         \tag{1}
\]

**Proof.** Choose an actual BF colouring of type \((14)(23)\). Name its six complete matching colours as follows:
\[
q_{14}+A+B+X+C+r_{23}=2\mathbf1,
\quad
\partial(A,B,X,C)=(1,2,3,4),                    \tag{2}
\]
where \(q_{14}\) has triple boundary \(235\), and \(r_{23}\) has triple boundary \(145\). The labels of the five terminal semiedges are
\[
\begin{array}{c|ccccc}
&s_1&s_2&s_3&s_4&s_5\\\hline
\text{two colours}&A,r_{23}&B,q_{14}&X,q_{14}&C,r_{23}&q_{14},r_{23}.
\end{array}                                               \tag{3}
\]

At \(h_{14}\), the two terminal labels share \(r_{23}\); the three colours absent at both are \(q_{14},B,X\). The internal edge has two of these three colours. If it contains \(q_{14}\), the local recolouring of [Note 120](120-t-paired-terminal-tree-two-cuts-are-forbidden-in-exact-case-xii.md)(4) swaps \(q_{14}\) with \(r_{23}\) on the two semiedges and this edge. Then \(q_{14}\) occurs on all five terminal semiedges, contrary to the second hypothesis in (1). Therefore
\[
\phi(h_{14})=\{B,X\}.                                 \tag{4}
\]

At \(h_{25}\), the labels at \(s_2,s_5\) share \(q_{14}\); the three colours absent at both are \(A,X,C\). If the internal edge contains \(A\), swapping \(A\) with \(q_{14}\) makes \(A\) a triple colour at terminals \(1,2,5\), missing \(34\). The unchanged \(r_{23}\) is a triple colour missing \(23\), giving the forbidden type \((23)(34)\). Thus
\[
\phi(h_{25})=\{X,C\}.                                 \tag{5}
\]

Now perform **both** permitted local recolourings: swap \(X\) with \(r_{23}\) at the \(14\)-tree, and swap \(X\) with \(q_{14}\) at the \(25\)-tree. Equations (4)--(5) make both swaps legal. The trees have disjoint vertices and edges, so the swaps commute and leave every other edge label unchanged. Colour \(X\) was already present at \(s_3\); after the swaps it is also present at \(s_1,s_4\) and \(s_2,s_5\). The resulting actual BF colouring has type \((12345)\), contradicting (1). \(\square\)

Equivalently, for a pole with these two terminal edges, the positive type \((14)(23)\) forces at least one of the two types \((12345)\) and \((23)(34)\). The conclusion holds even if the rest of the pole has bridges or other short cycles.

## Exact Case-XII structural consequence

Put \(S=\{13,14,24,25,35\}\), \(T=\{12,15,23,34,45\}\). The exact Case-XII support in Máčajová--Mazzuoccolo--Tabarelli (2026, Proposition 4.4 and Figure 7, DOI 10.26493/1855-3974.3409.c13) contains \((14)(23)\) and excludes both forbidden types in (1). Hence no exact-Case-XII pole can contain both \(h_{14}\) and \(h_{25}\).

The automorphism group of the \(S\)-pentagon is dihedral and transitive on unordered pairs of disjoint \(S\)-edges. Relabelling (1) by any such automorphism shows:
\[
\boxed{\text{No exact-Case-XII five-pole has two disjoint proper edges
joining terminal-vertex pairs in }S.}                   \tag{6}
\]

[Note 120](120-t-paired-terminal-tree-two-cuts-are-forbidden-in-exact-case-xii.md) also excludes every terminal-terminal edge whose pair lies in \(T\). For the side of a *minimum* BF counterexample, [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) and girth five exclude adjacent terminal-terminal edges. Combining these facts gives the bound of **at most one proper edge**; the present two-edge proof alone leaves one \(S\)-terminal edge. Note 123 rules out that last edge. These conclusions do not depend on whether the pole is three-edge-colourable.

Without the minimum-host restrictions, Notes 120 and 122 alone say that the terminal-induced graph is a subgraph of the \(S\)-pentagon with matching number at most one. It is therefore empty, one \(S\)-edge, or two adjacent \(S\)-edges sharing one terminal. Note 123 excludes both nonempty shapes under exact support, without a minimum-host restriction.

## Effect on the rectangle route

The exact-support premise of Note 121's two-edge rectangle obstruction is impossible even before asking for a common-\(B,C\) seed. Its projected core-seed criterion remains a correct identity statement for a hypothetical pair of BF rows, but it cannot supply an exact-Case-XII counterexample with both terminal edges. Note 123 removes the single-edge case as well. The zero-edge class and the indecomposable full-perfect-matching intersection \(\Lambda_L\cap\Lambda_R\) of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md) remain unresolved.
