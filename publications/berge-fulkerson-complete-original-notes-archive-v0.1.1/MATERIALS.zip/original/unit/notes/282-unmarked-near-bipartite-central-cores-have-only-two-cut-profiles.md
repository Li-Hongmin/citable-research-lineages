> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Unmarked near-bipartite central cores have only two cut profiles

> **Scope correction (2026-10-01):** The sentence below that calls
> nonbipartiteness of the subdivided shore after deleting \(g\)
> "required by Note 281" does not apply to the genuine right
> \((ea)(ad)\) row of [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md).
> The numerical classification and balance proof remain valid **when**
> \(g\) has same-side ends and the marked edge crosses the stated
> bipartition; they do not establish those side assumptions for the
> right-row branch.

Continue the actual one-internal-mark central-path profile of [Notes 230 and 277](277-the-central-path-rows-force-an-unmarked-odd-shore-cycle.md). Let \(C=F[\Sigma]\) be the connected odd unmarked core, let the internal marked edge be \(e=vw\), and let its subdivision vertex be \(t_e\). The six-port shore has terminal port \(E=e\) at \(t_e\) and five proper interfaces \(A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\).

Assume that deleting one internal **unmarked** edge \(g\) makes \(C\) bipartite, while the subdivided six-port shore remains nonbipartite after deleting \(g\). The latter is required by [Note 281](281-the-central-six-port-shore-has-no-single-edge-odd-cycle-transversal.md) under complete exact-Case-XII support.

**Theorem (two cut profiles).** Choose the bipartition of \(C-g\) with both ends of \(g\) in \(B\), and label the endpoints of \(e\) so that \(v\in B,w\in R\). Then exactly one of the following numerical profiles holds:
\[
\begin{array}{c|c|c}
|B|-|R|&\#\{A,I,D,H,J\}\text{ based in }B
&\#\{A,I,D,H,J\}\text{ based in }R\\\hline
-1&0&5\\
 1&3&2.
\end{array}                                                     \tag{1}
\]
In the first profile, **every** zero-port shore perfect matching uses the half-edge \(t_ew\) and avoids \(g\). Moreover, the whole five-pole minus the two disjoint proper edges \(g,t_ew\) is bipartite, with four exterior terminals on one side and terminal \(e\) alone on the other. Hence the mixed-side theorem of [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) forces the exact pole's Tait-state set to be \(S\). This is a necessary condition, not an exclusion. In the second profile, a zero-port matching can have only the profiles
\[
(t_ev,\,g\notin X)\quad\text{or}\quad
(t_ew,\,g\in X),                                      \tag{2}
\]
and the theorem does not assert that both occur.

## Proof

By Note 277, \(C\) itself is nonbipartite, so the deleted edge \(g\) joins two vertices of one side of \(C-g\); name it \(B\). If \(v,w\) lay on the same side, colouring \(t_e\) on the other side would make the entire six-port shore minus \(g\) bipartite, contradicting Note 281. Thus \(v,w\) lie on opposite sides as stated.

The five proper shore interfaces and the two ends of the deleted internal mark \(e\) are the seven boundary incidences of \(C\) in the cubic marked core. Let \(p_B,p_R\) count the five proper interfaces based in \(B,R\), respectively. Every unmarked internal edge of \(C\) except \(g\) crosses the bipartition; \(g\) contributes two degree ends in \(B\), while the two marked endpoints contribute one boundary incidence per side. Subtracting the degree sums on the sides gives
\[
3(|B|-|R|)=p_B-p_R+2,
\qquad p_B+p_R=5.                                         \tag{3}
\]
The core has odd order, so \(|B|-|R|\) is odd. Equation (3) with \(0\le p_B,p_R\le5\) has only the two solutions (1).

For a zero-port shore matching \(X\), \(t_e\) is matched to one of \(v,w\). After deleting that endpoint, its remaining edges match the core, perhaps using \(g\). If \(u\) is the chosen endpoint and \(z=\mathbf1_{g\in X}\), the same bipartite balance gives
\[
\begin{cases}
|B|-|R|=1+2z,&u=v\in B,\\
|B|-|R|=-1+2z,&u=w\in R.
\end{cases}                                                     \tag{4}
\]
For the first row of (1), (4) forces \(u=w,z=0\); for the second it leaves precisely (2).

In the first row of (1), colour \(t_e\) with \(R\). All five proper shore interfaces are based in \(R\); colour their common exterior endpoints by \(B\). The central-path exterior is bipartite with this alignment, and its four marked subdivision vertices \(t_a,t_b,t_c,t_d\) lie in \(B\). Every proper edge of the full pole except \(g\) and \(t_ew\) now crosses sides. These two exceptions lie inside \(B\) and \(R\), respectively, and so are disjoint. Terminal \(e\) is at \(t_e\in R\), while the other four terminals lie in \(B\). This is exactly [Note 127's mixed-side \(4+1\) branch](127-two-edge-bipartization-profiles-and-tait-blockers.md), to which Note 132 applies under full exact support. \(\square\)

The theorem identifies the remaining one-edge-near-bipartite **unmarked** core boundary after Note 281. It does not decide whether either profile in (1) can realize the two required central rows, whether the four-slot loads intersect, or whether Berge–Fulkerson holds. The upstream forced central-path geometry remains subject to independent verification.
