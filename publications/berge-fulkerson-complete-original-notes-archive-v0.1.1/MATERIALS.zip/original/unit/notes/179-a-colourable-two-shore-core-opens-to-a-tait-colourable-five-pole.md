> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A colourable two-shore core opens to a Tait-colourable five-pole

Consider the \(|U|=1\) two-five-cut quotient of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md). Its cubic core \(J\) has shores \(A,B\), a vertex \(u\) joined once to each shore and to \(w\), three marked edges \(\alpha,\beta,\gamma\) joining \(A\) to \(B\), and the remaining marked edges \(\delta=A w\), \(\epsilon=B w\). Subdivide those five marked edges and attach a terminal semiedge at each subdivision vertex to obtain the five-pole \(H\). No assumption on the internal structure of \(A,B\) is needed in the first theorem.

\[
\boxed{J\text{ three-edge-colourable}\quad\Longrightarrow\quad
H\text{ three-edge-colourable}.}                           \tag{1}
\]

**Proof.** Start with any three-edge-colouring of \(J\), and permute the colour names so that the edges from \(A,B\) to \(u\) have colours \(1,2\), respectively; \(uw\) then has colour \(3\). The two marked edges at \(w\) have colours \(d=\phi(\delta)\), \(f=\phi(\epsilon)\), with \(\{d,f\}=\{1,2\}\). Keep the colouring on \(A\), and apply the cyclic permutation \(\pi:1\mapsto2\mapsto3\mapsto1\) to **every** edge of \(B\), including its five port halves. The \(B\)-to-\(u\) edge now has colour \(3\), so give \(uw\) colour \(2\). At every shared marked subdivision vertex \(t_i\), \(i\in\{\alpha,\beta,\gamma\}\), the two shore halves have colours \(x,\pi(x)\), which are distinct; give its terminal the third colour.

Only the two edges from \(w\) to \(t_\delta,t_\epsilon\) remain. Colour them as follows:

| original \((d,f)\) | \(wt_\delta\) | \(wt_\epsilon\) | terminal colours \((s_\delta,s_\epsilon)\) |
|---|---:|---:|---:|
| \((1,2)\) | \(3\) | \(1\) | \((2,2)\) |
| \((2,1)\) | \(1\) | \(3\) | \((3,1)\) |
| \((2,1)\) | \(3\) | \(1\) | \((1,3)\) |

At \(w\), these two colours and \(uw=2\) are distinct. At \(t_\delta\) they differ from the unchanged \(A\)-half colour \(d\); at \(t_\epsilon\) they differ from the permuted \(B\)-half colour \(\pi(f)\). The displayed terminal colours complete the three-colour partition at both vertices. All other vertices already have three distinct incident colours, proving (1). \(\square\)

## Which Tait states this construction forces

Write \(x_i\) for the original colour of each shared mark \(i\in\{\alpha,\beta,\gamma\}\). The new terminal colour at \(i\) is the third colour of \(x_i,\pi(x_i)\), namely \(\pi^2(x_i)\). Every three-edge-colouring of an odd cubic five-pole has semiedge colour multiplicities \((3,1,1)\), by parity. Applied to \(A\), this gives two exact alternatives.

Equivalently, \((d,f)=(1,2)\) precisely when the missing-pair Tait state of the \(A\)-shore colouring lies entirely among the three shared ports \(\alpha,\beta,\gamma\): the ports toward \(u,w\) then have the common majority colour. The swapped case \((d,f)=(2,1)\) is precisely when that shore state contains the port toward \(u\) or \(w\). Thus the six-state table in Note 173 can be divided into the two branches below without reopening any internal matching data.

If \((d,f)=(1,2)\), then the \(A\)-ports toward \(u,w\) both have colour \(1\), so the three shared colours are \(1,2,3\) in some order. The constructed \(H\)-colouring has terminal colour \(2\) at \(\delta,\epsilon\) and at the shared mark of old colour \(3\). Its Tait state is therefore
\[
\boxed{\{i:x_i=1\}\ \cup\ \{i:x_i=2\},}               \tag{2}
\]
a pair among the three shared marks.

If \((d,f)=(2,1)\), then the shared colour multiset is exactly one of \(\{1,1,3\},\{2,2,3\},\{3,3,3\}\). In the first two cases let \(k\) be the unique shared mark with old colour \(3\). The two choices in the table give **both** Tait states \(k\delta\) and \(k\epsilon\). In the last case both choices give state \(\delta\epsilon\):
\[
\boxed{\begin{array}{c|c}
\{x_\alpha,x_\beta,x_\gamma\}&\text{states forced in }H\\\hline
\{1,1,3\}\text{ or }\{2,2,3\}&k\delta,\ k\epsilon\\
\{3,3,3\}&\delta\epsilon
\end{array}}                                               \tag{3}
\]

The two-state alternative in (3) actually forces a third state. If the shared colours are \(\{1,1,3\}\), interchange colours \(1,3\) on the whole \(B\)-shore, instead of applying \(\pi\). Its shared halves still differ; \(B0\) stays colour \(2\), so put colour \(3\) on \(uw\) and colours \(1,2\) on \(wt_\delta,wt_\epsilon\). All three shared terminals now have colour \(2\), while \(s_\delta,s_\epsilon\) have colours \(3,1\). If the shared colours are \(\{2,2,3\}\), interchange colours \(2,3\) on \(B\); put \(2\) on \(uw\), and \(1,3\) on \(wt_\delta,wt_\epsilon\). All three shared terminals have colour \(1\), while \(s_\delta,s_\epsilon\) have colours \(3,2\). In **both** cases this second shore permutation gives the Tait state \(\delta\epsilon\). Together with (3), the actual Tait set of \(H\) then contains the triangle
\[
\boxed{\{k\delta,\ k\epsilon,\ \delta\epsilon\}.}       \tag{4}
\]

For a genuine exact-Case-XII pole, [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) gives the Tait-state dichotomy \(\mathcal T(H)=\varnothing\) or \(\mathcal T(H)=S\), where \(S\) is the allowed five-cycle of missing pairs. If its core \(J\) is colourable, (1) forces \(\mathcal T(H)=S\). Since a five-cycle contains no triangle, (4) excludes **every** core colouring in the swapped mixed-colour case. A swapped core colouring is therefore possible only when all three shared marks have the old colour of \(uw\); then \(\delta\epsilon\in S\) is necessary. For an aligned core colouring, the pair in (2) must lie in \(S\). Equivalently, the missing-pair Tait state on the \(A\)-shore of every colouring of \(J\) must either lie wholly among \(\alpha,\beta,\gamma\) or equal the pair of ports toward \(u,w\). These are **necessary gates for every colouring of \(J\)**, not sufficient conditions for exact Case XII.

In particular, [Note 173](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md) proves that a core with two pentagon shores is three-edge-colourable. Thus its opened pole \(H\) is necessarily Tait-colourable, and the Tait-empty exact-Case-XII branch is excluded for that shore pair. This implication alone does not exclude the \(S\)-Tait branch or supply a BF cover of the whole host \(G\).

The remaining \(S\)-Tait branch for two pentagon shores is excluded by the genuine BF matching exchange in [Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md); the general implication (1) alone does not supply that exclusion.
