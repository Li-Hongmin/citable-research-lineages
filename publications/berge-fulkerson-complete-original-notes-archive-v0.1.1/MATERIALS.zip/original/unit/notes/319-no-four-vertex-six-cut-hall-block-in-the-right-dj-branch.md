> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No four-vertex six-cut Hall block in the right DJ branch

Continue the noncollision, complete exact-Case-XII central-path
branch with genuine left \((ea)(ac)\) and right \((ea)(ad)\)
rows, \(R_0=DJ\), a one-edge-near-bipartite shore, and the
completed minimum host of girth at least five. By
[Note 315](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md),
the first possible \((\alpha,\eta)=(2,1)\) six-cut Hall
witness with \(|S|=4\) has the incidence graph
\[
 S=\{h,k,\ell,m\},\quad T=\{o,r,s,t\},\qquad
 o\{h,k,\ell\},\ r\{h,m\},\ s\{k,m\},\ t\{\ell,m\},
 \quad \ell d.                                             \tag{1}
\]
Here \(H\) is at \(h\), \(P\in\{A,I\}\) at \(k\),
and \(D\) at \(d\). [Notes 316–318](318-complement-transfer-excludes-the-t-port-four-vertex-hall-placement.md)
exclude \(j=s,t\), so only the position \(j=r\) for the
\(J\)-port base remains.

**Theorem.** The \(j=r\) position is also impossible,
for either \(P=A\) or \(P=I\). Consequently every
six-cut Hall witness in this branch has \(|S|\ge5\):
the \((2,1)\) allocation has no block of size at most four,
and [Note 311](311-a-six-cut-hall-block-with-one-b-port-needs-five-b-vertices.md)
already gives \(|S|\ge5\) for \((1,2)\).

The required part of [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
can be checked directly from its two actual forbidden-\(eb\)
exterior masks. Their complement connections are
\(P_0:ID\mid AH,\ b\to J\) and
\(P_1:AD\mid HJ,\ b\to I\). For a zero-port
\((g,t_{ew})\) shore matching, \(D,J\) are the only
unselected same-side exceptions. If they lie in one full
complement component under either mask, every closed cycle is
even and a forbidden \(eb\)-Tait colouring follows.
Thus a shore \(HD\) or \(AJ\) pair is impossible under
\(P_1\), an \(IJ\) pair is impossible under \(P_0\),
and shore pairs \(HJ\) and \(AD\) cannot coexist under
\(P_0\). These are precisely the zero-port exclusions used
below; they also follow from Note 285's complete table.

**Proof.** Let \(X\) be any actual zero-proper-port shore
matching selecting \(g,t_{ew}\); the right row supplies one.
If \(X\) avoids \(\ell d\), it uses one of the three full
block perfect matchings
\[
 M_h=\{ho,ks,\ell t,mr\},\quad
 M_k=\{hr,ko,\ell t,ms\},\quad
 M_\ell=\{hr,ks,\ell o,mt\}.                             \tag{2}
\]
Any two phases differ on an alternating six-cycle, so full
perfect-matching closure gives a zero-port \((g,t_{ew})\)
matching using \(M_k\). Its complement contains the
**complete** proper-port path
\[
                         H-h-o-\ell-d-D.                    \tag{3}
\]
Neither of [Note 285's two allowed pairings](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
for \(R_0=DJ\), namely \(EA\mid ID\mid HJ\) and
\(EJ\mid AD\mid IH\), contains \(HD\). Hence every
such \(X\) uses \(\ell d\).

With \(\ell d\) selected, covering \(o\) and the unselected
\(J\)-base \(r\) leaves exactly three local shapes:
\[
 X_a=\{\ell d,ho,ks,mr\},\quad
 X_b=\{\ell d,hr,ko,ms\},\quad
 X_c=\{\ell d,hr,ko,mt\}.                                \tag{4}
\]
The complement of \(X_c\) contains
\(J-r-m-s-k-P\), a forbidden \(JP\) path for either
\(P=A,I\). The shapes \(X_a,X_b\) differ on the
alternating six-cycle \(h-o-k-s-m-r-h\). Thus, from any
actual zero-port \((g,t_{ew})\) matching in (4), full
closure supplies one with local shape \(X_b\). Fix this
actual matching \(X_b\).

Take either genuine left singleton-\(a\) shore matching
\(Y(HJ,g,t_{ew})\) of
[Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md).
Since \(H,J\) cover \(h,r\), its restriction to (1) is
one of
\[
 Y_1:\ \{ko,\ell t,ms\},\qquad
 Y_2:\ \{ko,\ell d,ms\},\qquad
 Y_3:\ \{ks,\ell o,mt\}.                                \tag{5}
\]
For all three, \(H-h-r-J\) is a full local alternating
component of \(Y\triangle X_b\). Switch it into \(Y\).
The result \(N\) is an actual zero-port matching still
selecting \(g,t_{ew}\).

If \(Y=Y_1\), then \(N\) uses \(M_k\), already forbidden
by (3). If \(Y=Y_3\), then \(N\) uses \(M_\ell\), with
no \(\ell d\), contradicting the first part of this proof.
It remains to consider \(Y_2\). Here the switched matching
\(N\) has local shape \(X_b\). Write \(s\sigma\) for the
third edge at \(s\). The complement of \(Y_2\) has the
local segment
\[
                          P-k-s-\sigma.                      \tag{6}
\]
The edges \(H,J,\ell d\) and the third edge at \(t\)
are selected, so \(s\sigma\) is its sole complement exit
from the displayed block. [Note 301's complete-fibre rule](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
pairs \(EI\mid AD\) for \(Y_2\); the unchanged exterior
continuation of (6) therefore ends at \(D\) when \(P=A\),
and at \(E\) when \(P=I\).

Switching \(H-h-r-J\) changes nothing on this exterior
continuation. The complement of \(N\) still has
\(P-k-s-\sigma\), but also has the complete local path
\[
                         H-h-o-\ell-t-m-r-J.                 \tag{7}
\]
Thus it pairs \(HJ\) while retaining \(AD\) if \(P=A\),
or \(IE\) if \(P=I\). Note 285 allows only
\(EA\mid ID\mid HJ\) when \(HJ\) is paired. Both
inherited pairings violate this rule. So \(Y_2\) is
impossible as well, completing the contradiction. \(\square\)

The correction to [Note 316's last paragraph](316-zero-port-phase-closure-restricts-the-four-vertex-hall-block.md)
is explicit: for \(j=r\), phase \(M_k\) has the
forbidden \(HD\) complement path (3). The theorem closes
only the first four-vertex six-cut Hall block in the stated
near-bipartite branch. Hall blocks of size at least five,
the incidence-collision branch, other shore profiles, and
Berge–Fulkerson remain open. The proof is hand-derived and
depends on the cited complete-fibre results; no local
recomputation or OMEN run was used.
