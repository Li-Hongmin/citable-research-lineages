> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two required crossed double-star rows have complementary exterior pure loads

Use the crossed-adjacent Case-XII placement \(S=e-a-d-c-b-e\) in the double-star exterior of [Notes 364–365](365-the-crossed-double-star-ac-row-has-a-second-unique-shore-gate.md). Let \(\mathcal R_b\) be any actual \((ea)(ab)\) BF row and \(\mathcal R_c\) any actual \((ea)(ac)\) BF row. Their exterior restrictions are the unique tables of those notes; their complete shore matching masks may be arbitrary within the stated gates.

In \(\mathcal R_b\), let \(P_b\) be the state-\(ea\) triple, \(E_b\) its singleton-\(e\), and choose either of its two singleton-\(a\) occurrences \(A_b\). Write \(A_b'\) for the other occurrence, \(R_b\) for the state-\(ab\) triple, and \(B_b\) for singleton-\(b\). Define
\[
 U_b=P_b+E_b+A_b,\qquad V_b=R_b+B_b+A_b'=2\mathbf1-U_b.
\]
Similarly, in \(\mathcal R_c\), choose singleton-\(a\) occurrence \(A_c\), and write
\[
 U_c=P_c+E_c+A_c,\qquad V_c=R_c+C_c+A_c'=2\mathbf1-U_c,
\]
where \(R_c\) has state \(ac\), and \(C_c\) is singleton-\(c\). All symbols are incidence vectors of **complete actual perfect matchings**; \(Z\) denotes the six-port shore. Let \(E_{\rm ext}\) consist of all edges outside the interior of \(Z\), including terminal and shore-port semiedges.

**Theorem (mixed complement gate).** For every choice of the two rows and of \(A_b,A_c\), each pure half-load is **unit on the exterior**:
\[
       U_b|_{E_{\rm ext}}=U_c|_{E_{\rm ext}}=\mathbf1_{E_{\rm ext}}. \tag{1}
\]
including all terminal semiedges and all six edges entering \(Z\). Consequently
\[
 U_b+U_c=2\mathbf1_H
 \quad\Longleftrightarrow\quad
 V_b+V_c=2\mathbf1_H.                                    \tag{2}
\]
If either equality holds, the right side of (2) is a genuine forbidden \((ab)(ac)\) \(T\)--\(T\) BF row. Thus complete exact-Case-XII support forces, for **every** pair of required rows and every choice of one singleton-\(a\) from each,
\[
       \Delta:=U_b|_Z+U_c|_Z-2\mathbf1_Z\ne0.          \tag{3}
\]
More precisely, each individual defect \(\delta_b=U_b|_Z-\mathbf1_Z\), \(\delta_c=U_c|_Z-\mathbf1_Z\) vanishes at the six ports and is a disjoint union of **even shore cycles with alternating \(+1,-1\) edge values**; \(\Delta=\delta_b+\delta_c\). Under exact Case XII both individual defects are nonzero, because [Note 361](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md) excludes Tait colourings in this double-star exterior. Equation (3) says that no pair of these signed cycle defects may be negatives of one another. This is an exact full-matching anti-complement condition, not an existence or exclusion theorem for the remaining crossed placement.

**Proof.** Sum the two unique exterior tables. The six chosen occurrences \(P_b,E_b,A_b,P_c,E_c,A_c\) load every exterior edge exactly twice. For the terminal semiedges the owners are \(E_b,E_c\) at \(e\), \(A_b,A_c\) at \(a\), and \(P_b,P_c\) at each of \(b,c,d\). The other exterior edges have these owners (the two \(A\)-occurrences in a fixed row have the same exterior restriction):

| edges | two owners |
|---|---|
| \(t_ar_1,t_al_1\) | \(P_c,E_b\); \(P_b,E_c\) |
| \(t_br_1,t_bl_2\) | \(E_c,A_b\); \(E_b,A_c\) |
| \(t_cr_2,t_cl_1\) | \(E_c,A_b\); \(E_b,A_c\) |
| \(t_dr_2,t_dl_2\) | \(E_b,A_c\); \(E_c,A_b\) |
| \(xu_0,yu_0\) | \(P_b,A_c\); \(P_c,A_b\) |
| \(xu_1,r_1u_1\) | \(P_c,A_b\); \(P_b,A_c\) |
| \(xu_2,r_2u_2\) | \(E_b,E_c\); \(P_b,P_c\) |
| \(yu_3,l_1u_3\) | \(P_b,E_c\); \(P_c,A_b\) |
| \(yu_4,l_2u_4\) | \(E_b,A_c\); \(P_b,P_c\) |
| \(p_0,p_1,p_2,p_3,p_4\) | \(E_b,E_c\); \(E_b,E_c\); \(A_b,A_c\); \(E_b,A_c\); \(E_c,A_b\) |

Every owner pair in the table has one occurrence from each row, so **each** pure half-load uses that edge once. This proves the stronger (1). Since \(V_b=2\mathbf1-U_b\) and \(V_c=2\mathbf1-U_c\), their sum is \(4\mathbf1-(U_b+U_c)\), proving (2). The six actual matchings in \(V_b+V_c\) have the prescribed singleton boundaries \(a,b\) for state \(ab\) and \(a,c\) for state \(ac\); thus equality in (2) is a real \((ab)(ac)\) row, prohibited by Appendix XII because both states lie in \(T\). This proves (3).

Each \(U\) is a three-matching half-load of a BF row, so every shore edge has load \(0,1,\) or \(2\), and each individual defect \(\delta=U|_Z-\mathbf1_Z\) has values \(-1,0,1\). At every shore vertex, the three incident \(U\)-loads sum to three; therefore the incident \(\delta\)-values sum to zero. Either all three are zero, or they are a permutation of \((+1,-1,0)\). By (1) every port has value zero, so the support lies in shore-internal edges. Each nonzero support vertex has one positive and one negative edge, making the support a disjoint union of cycles with alternating signs. These cycles are even. A zero individual defect would make its three actual matching occurrences partition every edge of the five-pole, a Tait colouring of state \(ea\), contrary to Note 361 under complete exact Case XII. Finally \(\Delta=\delta_b+\delta_c\); (3) forbids cancellation. \(\square\)

Each required row has two distinct singleton-\(a\) complete masks by the overlap lemma used in Notes 364–365. Hence (3) forbids **all four** pairwise complement choices for any fixed pair of rows. Algebraic or port-level matching of the two pure halves is insufficient: their exterior and port loads are already unit; only the shore-internal signed even-cycle phases can prevent the forbidden row. Proving that some pair of actual rows has opposite phases, or constructing a complete exact-support pole where all such pairs avoid cancellation, is the precise remaining decision for this double-star placement. No local mathematical recomputation was used; the proof is hand-derived and awaits independent review of its upstream exterior tables.

**Equal phases are forbidden as well.** If \(U_b=U_c\) as complete load vectors, replace the three pure \(ea\) matching occurrences \(P_b,E_b,A_b\) in \(\mathcal R_b\) by the three complete occurrences \(P_c,E_c,A_c\) from \(\mathcal R_c\). The unchanged \(V_b\) still complements the same load, so the result is a genuine \((ea)(ab)\) row. Its \(ea\)-triple is rooted at \(r_1\), contrary to [Note 364's root exclusion](364-adjacent-double-star-cross-row-has-one-crossed-shore-gate.md). Since both pure loads are unit on the exterior, this proves \(\delta_b\ne\delta_c\). Together with (3), every cross-column choice satisfies
\[
                         \delta_b\ne\delta_c,
                         \qquad\delta_b\ne-\delta_c.       \tag{4}
\]
This is a full-matching equality and antipodality separation, not merely a distinction of zero-port shore masks.

The same anti-complement conclusion holds **within** either \(T\)-column. Take two pure state-\(ea\) half-loads from rows of type \((ea)(ab)\), or two from rows of type \((ea)(ac)\). Their exterior loads are each unit by the corresponding unique table. If their shore defects were negatives, pairing their complementary half-loads would give the forbidden loop \([ab]\) or \([ac]\), respectively. Thus the combined set of shore defects carried by these two required columns contains no pair \(\delta,-\delta\), whether the two phases come from the same row, different rows in one column, or the two different columns. The missing positive step is to force such an antipodal pair from complete shore matching closure; the present incidence argument does not do so.

For the two singleton-\(a\) choices **inside one fixed row**, this antipodal test has a simple full-mask form. If its zero-port triple, singleton-\(e\), opposite triple, and opposite singleton are \(Q,E,R,W\), respectively, the row equation gives
\[
 (Q+E+A_1)+(Q+E+A_2)-2\mathbf1=Q+E-R-W.          \tag{5}
\]
For either unique exterior template, \(Q+E\) and \(R+W\) agree on every exterior edge and shore port. Thus (5) is supported entirely inside \(Z\). Exact Case XII requires it to be nonzero; if it vanished, the two pure phases would be antipodal and the two opposite halves would make \([ab]\) or \([ac]\). This row-level residue is fixed even when the two \(A_i\) shore masks are exchanged along their alternating cycles.
