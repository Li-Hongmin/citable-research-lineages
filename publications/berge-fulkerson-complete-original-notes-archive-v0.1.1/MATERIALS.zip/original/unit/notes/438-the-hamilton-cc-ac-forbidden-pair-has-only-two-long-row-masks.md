> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton \(Cc,ac\) forbidden pair has only two long-row masks

Use the Hamilton two-spoke prism exterior of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                              \tag{1}
\]
Assume the **complete** BF support is exact Case XII with forbidden \(e\)-labels \(\{eY,eZ\}\). The two possible pentagons are
\[
S_1=e-X-Y-Z-W-e,\qquad S_2=e-X-Z-Y-W-e.              \tag{2}
\]
The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine mixed row \((eY)(eX)\) and forbids every double-\(T\) row.

> **Root and row-mask gate.** Every required \((eY)(eX)\) row has forbidden triple \(P=eY:c\), allowed triple \(R=eX:A\), and the wholly exterior \(X\to W\) switch
> \[
> X-A-u_2-C-u_3-B-u_4-b-W.                         \tag{3}
> \]
> Among its two singleton-\(e\) occurrences, one is forced to take \(X:B,Y:C,Z:a,W:b,cu_5\). The remaining singleton-\(e\) occurrence \(N\) and singleton-\(Y\) occurrence \(J\) have exactly the two marked and proper-port profiles in (10), according to \(S_1\) or \(S_2\). This is a necessary full-row boundary, not an exact-Case-XII realization. No shore order, complement parity, or clean matching is assumed.

Take a real row of type \((eY)(eX)\). Name its triples \(P=eY\), \(R=eX\), their singleton partners \(J=Y\), \(K=X\), and the two singleton-\(e\) occurrences \(D_0,D_1\). The \(X\)-starting component of \(R\triangle K\) must end at \(W\), the only other allowed \(e\)-label: ending at \(Y\) or \(Z\) gives two forbidden triples beside unchanged \(P\). It is wholly exterior: the zero-port triple \(R\) uses a vertex half-edge at every tree subdivision, so the path entering a subdivision on a \(K\)-half must leave on that \(R\)-half rather than through a proper port. Switching gives an actual \(R'=eW\) with the **same complete shore matching** as \(R\).

The candidate \(X\to W\) paths are short \(X-B-u_4-b-W\) when \(R\) roots at \(B\), short \(X-A-u_1-a-W\) when it roots at \(A\), and long (3) when it roots at \(A\). The apparent long \(B\)-root route reaches \(a\) through \(u_3,C,u_2,A,u_1\), but it covers both ends of the unselected \(Y=Cc\) and \(Z=ac\) marks at \(c\); one matching cannot take both \(Y:c,Z:c\). Thus the list is complete.

The two pentagons require opposite first shore exits for every unchanged singleton-\(e\) occurrence \(D\):
\[
\begin{array}{c|cc}
&R=eX&R'=eW\\ \hline
S_1&Y&Z\\
S_2&Z&Y.
\end{array}                                                  \tag{4}
\]
Write \(Y_R,Z_R,Y_{R'},Z_{R'}\) for the proper ports reached by those terminal arms in the corresponding symmetric differences with \(D\). Since \(R,R'\) have the same complete shore restriction, \(S_1\) requires \(Y_R=Z_{R'}\), and \(S_2\) requires \(Z_R=Y_{R'}\). A demanded arm that does not reach a port already fails. When the two demanded arms reach distinct ports, the fixed shore \(e\)-path cannot serve both; the third marked terminal arm reaches the remaining exterior port, so no exterior port-to-port detour changes the comparison.

**The common \(p_5\) gate.** If any \(D\) has marked halves \((Y:c,Z:a,W:b)\), then both \(R\) and \(R'\) select \(cu_5\), whereas \(D\) covers \(c,b\) by marks. Its \(Y\)-terminal arm is therefore the same exterior path \(Y-c-u_5-p_5\) against both triples. A \(Z\)-arm in either comparison cannot reach this already occupied port; if it fails to reach any port, its demanded switch fails outright. Hence (4) contradicts the common shore \(e\)-path for **both** orientations. This gate uses actual complete matchings but no shore topology.

Here is the root reduction by edge load; the exceptional branch is dealt with below. An entry “gate” means the six-row mark slots force a singleton-\(e\) occurrence with the gate's three halves.
\[
\begin{array}{c|c|c|l}
R\text{ root}&X\to W\text{ route}&P\text{ root}&\text{result}\\ \hline
B&\text{short}&C&\text{gate: }P,R\text{ saturate }au_1,cu_5\\
B&\text{short}&c&K:cu_5\text{ gives the gate; }K:Y:c\text{ handled below}\\
A&\text{short}&C&\text{gate: both }D_i:(Y:c,Z:a,W:b)\\
A&\text{short}&c&\text{gate: one }D_i:(Y:c,Z:a,W:b)\\
A&\text{long}&C&\text{gate: one }D_i:(Y:c,Z:a,W:b).
\end{array}                                                  \tag{5}
\]
For example, in the first row \(P,R\) saturate \(au_1,cu_5\), forcing the short-path \(K\) to take \(Z:a,Y:c,W:b\). The singleton \(J=Y\) must then take \(Z:c,W:a\), leaving one \(D_i\) with \(Z:a,Y:c,W:b\). The other gate rows follow by the same three slots at \(a,c\): a matching using \(Z:a\) cannot also use \(Z:c\), and \(J\) selects the \(Y\) terminal. In the short \(A\)-root/\(c\)-root row, for instance, \(P,R\) saturate \(au_1\), while \(K:W:a,Z:c\); among \(J,D_0,D_1\), the two \(Z:a\) occurrences must cover \(c\) by \(Y:c\) or \(cu_5\), so one of them is the required \(D_i\). In the long \(A\)-root/\(C\)-root row, \(P,R\) saturate both \(au_1,cu_5\) and \(K:Z:a,Y:c,W:b\), leaving the same \(D_i\).

**Short \(B\)-root, \(P=eY:c\).** The short path forces \(K:X\) terminal, \(Z:a,W:b,Au_1,Bu_4\). If \(K:cu_5,Y:C\), then \(P,K\) use the remaining slots at \(c\) so that one \(D_i\) has \((Y:c,Z:a,W:b)\), and the gate applies. Otherwise \(K:Y:c,Cu_2,p_3,p_5\). The mark quotas give a unique occurrence \(M\in\{J,D_0,D_1\}\) with \(Z:a,cu_5,W:b\), the other two taking \(Z:c,W:a\). If \(M=D\), then \(D:Y:C\) and its possible \(X\)-halves give the demanded-exit table
\[
\begin{array}{c|cc}
D:X&S_1:(Y_R,Z_{R'})&S_2:(Z_R,Y_{R'})\\ \hline
A&(p_2,p_1)&(p_1,p_4)\\
B&(p_3,p_2)&(p_2,p_3).
\end{array}                                                  \tag{6}
\]
Both orientations fail. If \(M=J\), both \(D_i\) take \((Y:C,Z:c,W:a)\) and split the remaining \(bu_4,bu_5\) slots. Choose the one taking \(bu_4\). Its \(Z_R=Z_{R'}=p_5\); its \(Y_R\) is \(p_2\) or \(p_3\), and \(Y_{R'}\) is \(p_1\) or \(p_3\), according to its \(X\) half. This violates either row of (4). Hence no \(B\)-root enters the required cell.

**Long \(A\)-root, \(P=eY:c\).** The path (3) fixes
\[
K:X\text{ terminal},\quad Y:c,\ Z:a,\ W:b,\quad Au_2,Cu_3,Bu_4,\quad p_1,p_5. \tag{7}
\]
At \(a\), \(P,R\) saturate \(au_1\); at \(c\), \(P,K\) saturate \(Y:c\). The edge loads force a unique \(M\in\{J,D_0,D_1\}\) with \(Z:a,cu_5,W:b\), while the other two take \(Z:c,W:a\). If \(M=J\), both \(D_i\) have \((Y:C,Z:c,W:a)\) and split \(bu_4,bu_5\). Choosing the \(bu_4\) occurrence gives \(Y_R=p_2,Z_{R'}=p_5,Z_R=p_5\) and \(Y_{R'}\in\{p_1,p_3\}\), so both orientations fail.

Thus \(M=D\). It must take \(Y:C\), and its \(X\)-half has exactly these demanded exits:
\[
\begin{array}{c|cc}
M:X&S_1:(Y_R,Z_{R'})&S_2:(Z_R,Y_{R'})\\ \hline
A&(p_2,p_1)&(p_1,p_4)\\
B&(p_2,p_2)&(p_3,p_3).
\end{array}                                                  \tag{8}
\]
Hence \(M:X:B\). It covers \(c\) by \(cu_5\) and uses proper ports \(p_2,p_3,p_4\). Call the other singleton-\(e\) occurrence \(N\). It has \((Y:C,Z:c,W:a)\), while \(J\) has \((Z:c,W:a)\) and the \(Y\) terminal. These two occurrences split the remaining \(X:A,X:B\) and \(bu_4,bu_5\) slots. Their relevant exits are
\[
\begin{array}{c|c|cccc}
N:X&N:b&Y_R&Z_R&Y_{R'}&Z_{R'}\\ \hline
A&u_4&p_2&p_5&p_1&p_5\\
A&u_5&p_2&p_4&p_4&p_1\\
B&u_4&p_2&p_5&p_3&p_5\\
B&u_5&p_2&p_4&p_3&p_2.
\end{array}                                                  \tag{9}
\]
Equation (4) now forces \(N:X:B,b u_5\) under \(S_1\), or \(N:X:A,b u_5\) under \(S_2\). The singleton \(J\) takes the opposite \(X\) half and \(bu_4\). The two complete **exterior** port patterns are therefore
\[
\begin{array}{c|c|c|c|c}
&K&J&M&N\\ \hline
S_1&X;\ p_1,p_5&Y;\ X:A,bu_4,\ p_1,p_5&e;\ X:B,cu_5,\ p_2,p_3,p_4&e;\ X:B,bu_5,\ p_2,p_3,p_4\\
S_2&X;\ p_1,p_5&Y;\ X:B,bu_4,\ p_3,p_5&e;\ X:B,cu_5,\ p_2,p_3,p_4&e;\ X:A,bu_5,\ p_1,p_2,p_4.
\end{array}                                                  \tag{10}
\]
All entries also retain their marked halves from (7)–(9). The shore restrictions and complement cycles remain unfixed; (10) does not assert a real full-closure exact-Case-XII pole. In particular, [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md) and [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) require the two zero-port triples \(P,R\) in any such row to use **different complete shore matchings**, because every zero-port shore matching would have an odd closed complementary component. [Note 439](439-both-hamilton-cc-ac-row-masks-recomplete-to-the-forbidden-ey-loop.md) subsequently excludes both patterns (10) by a forbidden-loop recompletion that preserves all six complete shore matchings separately; [Note 441](441-the-last-hamilton-prism-forbidden-pair-has-no-exact-case-xii-support.md) completes the Hamilton exterior. The full exact-Case-XII question and Berge–Fulkerson remain open. This is a hand proof awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)
