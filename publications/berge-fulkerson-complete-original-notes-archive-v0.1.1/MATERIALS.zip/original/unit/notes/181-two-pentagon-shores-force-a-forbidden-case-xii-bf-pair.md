> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two pentagon shores force a forbidden Case-XII BF pair

In the minimum-host exact-Case-XII setting, the \(|U|=1\) two-five-cut profile of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) **cannot have two ordinary pentagon shores**. [Note 180](180-two-pentagon-case-xii-forces-one-relative-port-order.md) reduces every such candidate to one relative port order and two possible allowed Tait five-cycles. Here three explicit three-edge-colourings of the genuine opened pole \(H\) give a forbidden BF pair in either cycle. The argument uses actual complete perfect matchings, without a graph enumeration or an inference from Tait states alone.

## The last possible graph and three genuine colourings

Let the vertices of the two pentagons be \(A_0,\ldots,A_4\) and \(B_0,\ldots,B_4\), in cyclic order. Their five outward incidences are
\[
\begin{array}{c|ccccc}
&0&1&2&3&4\\\hline
A_i&u&t_\delta&t_r&t_t&t_s\\
B_i&u&t_\epsilon&t_r&t_s&t_t
\end{array}                                                 \tag{1}
\]
where \(u\) also meets \(w\), \(w\) meets \(t_\delta,t_\epsilon\), and each \(t_i\) has its terminal semiedge \(s_i\). This is exactly Note 180's remaining relative order.

The following table specifies **every edge colour** in three colourings of \(H\). In the two cycle columns, colours run along \(A_0A_1,A_1A_2,A_2A_3,A_3A_4,A_4A_0\) and similarly on \(B\). The port columns are in the vertex order of (1). The connector column is \((uw,wt_\delta,wt_\epsilon)\), and the terminal column is \((s_r,s_s,s_t,s_\delta,s_\epsilon)\).

| Tait state | \(A\) cycle | \(B\) cycle | \(A\) ports | \(B\) ports | connector | terminals |
|---|---|---|---|---|---|---|
| \(rt\) | \((2,3,2,1,3)\) | \((3,1,2,3,1)\) | \((1,1,1,3,2)\) | \((2,2,3,1,2)\) | \((3,2,1)\) | \((2,3,1,3,3)\) |
| \(st\) | \((1,3,2,1,3)\) | \((2,3,1,2,3)\) | \((2,2,1,3,2)\) | \((1,1,2,3,1)\) | \((3,1,2)\) | \((3,1,2,3,3)\) |
| \(\delta\epsilon\) | \((1,2,3,2,3)\) | \((2,1,3,1,3)\) | \((2,3,1,1,1)\) | \((1,3,2,2,2)\) | \((3,2,1)\) | \((3,3,3,1,2)\) |

At each pentagon vertex, its two cycle colours and its port colour are \(1,2,3\). At \(u\) the two first port colours and \(uw=3\) are distinct; at \(w\) the connector triple is a permutation of \((1,2,3)\). At each \(t_i\), the two incident port/connector colours and the displayed terminal colour are distinct. Thus every row is an actual three-edge-colouring, and the stated Tait state follows from the terminal column. The rows can also be obtained from [Note 173's](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md) \(v_2\) rows \((2,3,1;2),(2,3,1;1),(3,2,3;1)\) by [Note 179's](179-a-colourable-two-shore-core-opens-to-a-tait-colourable-five-pole.md) shore permutation.

The colour-\(3\) perfect matching in each row is its majority-colour matching. Denote them by \(M_{rt},M_{st},N_{\delta\epsilon}\), respectively. Reading the table gives
\[
\begin{aligned}
M_{rt}={}&\{A_1A_2,A_4A_0,A_3t_t,
 B_0B_1,B_3B_4,B_2t_r,uw,s_s,s_\delta,s_\epsilon\},\\
M_{st}={}&\{A_1A_2,A_4A_0,A_3t_t,
 B_1B_2,B_4B_0,B_3t_s,uw,s_r,s_\delta,s_\epsilon\},\\
N_{\delta\epsilon}={}&\{A_2A_3,A_4A_0,A_1t_\delta,
 B_2B_3,B_4B_0,B_1t_\epsilon,uw,s_r,s_s,s_t\}.
\end{aligned}                                                \tag{2}
\]
Each list covers all seventeen pole vertices exactly once. In **both** symmetric differences \(M_{rt}\triangle N_{\delta\epsilon}\) and \(M_{st}\triangle N_{\delta\epsilon}\), one terminal path is the same explicit alternating path
\[
s_\delta- t_\delta-A_1-A_2-A_3-t_t-s_t.               \tag{3}
\]
Its six edges alternate between the first and the second matching, starting with \(s_\delta\) in \(M_{rt}\) or \(M_{st}\), and ending with \(s_t\) in \(N_{\delta\epsilon}\).

## Either allowed five-cycle gives a forbidden row

Overlay the three colour-class matchings of the \(rt\) colouring with those of the \(\delta\epsilon\) colouring. This is an actual six-matching BF row; switching only \(M_{rt},N_{\delta\epsilon}\) along (3) preserves every edge load and both perfect-matching conditions. Their triple boundaries change from \(\{s,\delta,\epsilon\},\{r,s,t\}\) to \(\{s,t,\epsilon\},\{r,s,\delta\}\), so the resulting BF type is
\[
\boxed{(r\delta)(t\epsilon).}                             \tag{4}
\]
If \(S=r-t-s-\delta-\epsilon-r\), both \(r\delta\) and \(t\epsilon\) are in the forbidden complementary five-cycle \(T\). This contradicts exact Case XII.

For the other possibility \(S=r-t-s-\epsilon-\delta-r\), overlay the \(st\) and \(\delta\epsilon\) colourings instead. Switching \(M_{st},N_{\delta\epsilon}\) along the same path (3) changes their triple boundaries from \(\{r,\delta,\epsilon\},\{r,s,t\}\) to \(\{r,t,\epsilon\},\{r,s,\delta\}\), giving
\[
\boxed{(s\delta)(t\epsilon).}                             \tag{5}
\]
Both states in (5) lie in \(T\) for this second \(S\). This is again a forbidden actual BF type. Note 180 exhausts the relative port orders and the two possible \(S\) cycles, so two pentagon shores are impossible. \(\square\)

This theorem closes the pentagon--pentagon subcase of the \(|U|=1\) two-five-cut profile. [Note 183](183-a-shared-pair-tait-shore-and-a-loop-universal-shore-force-seven-loops.md) later excludes tree/\(L^*\) and pentagon/\(L^*\) by seven actual outer BF loops. Tree/\(R^*\), pentagon/\(R^*\), \(L^*\)/\(R^*\), and \(R^*\)/\(R^*\) still require the complete connector relation or a whole-host lift. The one-shore \((4,2,2)\) profile and the other Tutte-barrier branches also remain open.
