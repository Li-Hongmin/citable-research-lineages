> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All-terminal BF completion is chord colouring plus one-edge cycle balance

Let \(H\) be a cubic five-pole and let \(P_0\) be an actual perfect matching using all five semiedges \(s_1,\ldots,s_5\). Its proper-edge complement \(\mathcal C=E(H)\setminus P_0\) is a disjoint union of cycles. [Note 167](167-all-terminal-bf-completion-is-a-petersen-walk-labelling.md) gives a Petersen-walk labelling criterion for completing this **specified** \(P_0\) to an all-terminal BF row. The following exact form replaces the walk labels by colours on the edges of \(P_0\), odd-gap conditions, and one load check per even complement cycle.

**Cycle-balance theorem.** Assign each proper edge \(uv\in P_0\) one colour \(\kappa(uv)\in[5]\), and give the terminal vertex incident with \(s_i\) the fixed colour \(i\). Each vertex now has one colour \(\mu(v)\): the colour of its incident \(P_0\)-edge or terminal semiedge. For a cycle \(C\in\mathcal C\), put \(O_i(C)=\{v\in V(C):\mu(v)=i\}\). Call \(\kappa\) *gap-feasible* if, for every \(C,i\):

- if \(O_i(C)=\varnothing\), then \(C\) is even;
- if \(O_i(C)\ne\varnothing\), successive vertices of \(O_i(C)\) have odd cyclic distance along \(C\).

The distance from a singleton \(O_i(C)\) to itself is \(|C|\). For nonempty \(O_i(C)\), the second condition makes the path components of \(C-O_i(C)\) even and fixes their unique perfect matching \(N_i(C)\). On an even \(C\), choose one edge \(e_C\) and define
\[
q_C=|\{i:O_i(C)=\varnothing\}|,\qquad
b_C=|\{i:O_i(C)\ne\varnothing,\ e_C\in N_i(C)\}|.
\]
Then the exact criterion is
\[
\boxed{P_0\text{ belongs to an all-terminal BF cover}
\iff\exists\text{ a gap-feasible }\kappa\text{ such that }
0\le 2-b_C\le q_C\quad\text{for every even }C.}          \tag{1}
\]
For a fixed feasible \(\kappa\), the number of BF completions with the five singleton matchings named by their terminal labels is exactly
\[
             \prod_{C\in\mathcal C:\ |C|\text{ even}}
                 \binom{q_C}{2-b_C}.                         \tag{2}
\]
An empty product is one; a binomial outside its range is zero.

**Proof.** In an all-terminal BF cover containing \(P_0\), each of the other five matching occurrences has an odd, positive number of semiedges. Their total semiedge load is five, so they have the five distinct singleton boundaries. Call them \(P_i\), with boundary \(\{i\}\). Every proper \(P_0\)-edge has load one from \(P_0\), so exactly one \(P_i\) contains it; assign it colour \(i\). At a terminal vertex, \(P_i\) uses \(s_i\). Consequently, on each complement cycle \(C\), the cycle edges of \(P_i\) perfectly match the vertices of \(C-O_i(C)\). If \(O_i(C)\) is nonempty, that matching exists precisely when each gap between omitted vertices contains an even number of vertices, equivalently when its cyclic distance is odd; the matching is then unique. If \(O_i(C)\) is empty, \(C\) itself must be even and \(P_i\) chooses one of its two alternating perfect matchings. Thus \(\kappa\) is gap-feasible. On the chosen edge \(e_C\), the nonempty colours contribute \(b_C\) and the \(q_C\) empty colours contribute between zero and \(q_C\), proving necessity of the inequality in (1).

Conversely, take a gap-feasible \(\kappa\) satisfying that inequality. For each empty colour on an even cycle, choose the alternating perfect matching containing \(e_C\) for exactly \(2-b_C\) of those colours; choose the opposite phase for the others. Combine these choices with the forced \(N_i(C)\), all proper \(P_0\)-edges coloured \(i\), and \(s_i\), to form \(P_i\). Every pole vertex is matched once by \(P_i\): a vertex of colour \(i\) uses its \(P_0\)-edge or \(s_i\), while every other vertex uses one cycle edge. Each \(P_0\)-edge and semiedge has load two in \(P_0+P_1+\cdots+P_5\).

Let \(\ell(e)\) be the load of a cycle edge among \(P_1,\ldots,P_5\). At every cycle vertex exactly four of those matchings use cycle edges, so the loads of its two incident cycle edges sum to four. Around an odd cycle this recurrence forces \(\ell(e)=2\) on every edge. Around an even cycle the loads alternate \(a,4-a\); our phase choice makes \(a=\ell(e_C)=2\), so every edge again has load two. This proves sufficiency. Each even cycle has exactly \(\binom{q_C}{2-b_C}\) allowable phase choices, independently of the other cycles, while every nonempty colour has a unique path matching. This proves (2). \(\square\)

## A genuine pole where gap feasibility alone overloads an even cycle

Take disjoint proper cycles \(A=a_0a_1\cdots a_7a_0\) and \(B=b_0b_1\cdots b_{12}b_0\). Add the eight proper edges
\[
a_0b_1,\ a_1b_2,\ a_2b_4,\ a_3b_5,\
a_4b_7,\ a_5b_8,\ a_6b_{10},\ a_7b_{11},
\]
and attach semiedges \(s_1,s_2,s_3,s_4,s_5\) at \(b_0,b_3,b_6,b_9,b_{12}\), respectively. The result is a connected simple cubic five-pole on 21 vertices. It has no proper bridge: cycle edges lie on their displayed cycles, and any joining edge lies on a cycle formed with another joining edge and paths in \(A,B\). Let \(P_0\) be its eight joining edges and five semiedges. Its complement is exactly \(A\sqcup B\). Colour the two joining edges from \(a_{2j},a_{2j+1}\) by \(j+1\) for \(j=0,1,2,3\).

On \(A\), the colour classes are the four adjacent pairs \(\{a_0,a_1\},\ldots,\{a_6,a_7\}\), while colour 5 is absent. On \(B\), colours 1--4 each occupy a consecutive triple \(\{b_{3j},b_{3j+1},b_{3j+2}\}\), and colour 5 occupies \(\{b_{12}\}\). Every nonempty colour class on either cycle has odd successive cyclic gaps, and an empty class occurs only on the even cycle \(A\). Thus this **actual graph and actual \(P_0\)-edge colouring are gap-feasible**.

Yet the forced path matchings for colours 2, 3 and 4 all use \(a_0a_1\); colour 1 does not. Thus \(b_A=3\) on that edge and \(q_A=1\), so \(2-b_A=-1\) violates (1). No choice of the empty colour-5 phase completes **this colouring** to a BF row. The example refutes the tempting per-colouring implication “odd gaps imply completion” when an even complement cycle is present. It does not assert that some *other* colouring cannot complete \(P_0\); (1) is the correct existential boundary.

In fact another colouring does complete the same \(P_0\): give colour 2 to the first four joining edges in the displayed list and colour 4 to the last four. On \(B\), the colour-2 and colour-4 omission sets are the consecutive five-vertex runs \(b_1,\ldots,b_5\) and \(b_7,\ldots,b_{11}\); the other three colours occur only at their terminal vertices, so all odd-cycle gaps pass. On \(A\), the two nonempty colour sets are \(a_0,\ldots,a_3\) and \(a_4,\ldots,a_7\). At \(a_0a_1\) they give \(b_A=1\) and leave \(q_A=3\) empty colours, so one empty colour takes the phase containing this edge. Formula (1) gives an actual all-terminal BF cover. This makes the logical boundary of the first colouring failure explicit.

## Five odd cycles can still have no completion for a specified matching

The obstruction has a general quotient form. Let \(Q\) be any loopless 5-regular multigraph, delete one vertex \(x\), and expand every remaining vertex into a five-cycle with its five incidences attached at distinct cycle vertices. The five former incidences of \(x\) become labelled semiedges. Let \(P_0\) consist of all edges and semiedges between the expansion cycles, so its complement is a disjoint union of five-cycles. Then
\[
\boxed{P_0\text{ belongs to an all-terminal BF row of the expanded five-pole}
\iff Q\text{ has a proper 5-edge-colouring}.}                  \tag{3}
\]
Indeed, on each complement five-cycle every one of the five singleton colours must occur, hence occurs once. The colours on the \(P_0\)-edges therefore give a proper 5-edge-colouring after contracting the cycles and restoring \(x\). Conversely, relabel any proper 5-edge-colouring of \(Q\) so that its five edges at \(x\) have the prescribed terminal colours. On each expanded five-cycle, each colour omits exactly one vertex and uniquely matches the other four along the cycle. Every cycle edge belongs to exactly two of these five matchings; together with \(P_0\) they form the required BF row. This equivalence concerns the **specified** \(P_0\), regardless of the expansion's other perfect matchings.

There is a genuine **all-odd** failure of (3), even with proper girth five and no proper bridge. Let \(Q\) be the 5-regular multigraph on
\(L=\{\ell_0,\ell_1,\ell_2\}\) and \(R=\{r_0,r_1,r_2\}\): double each edge of the triangle on \(L\), double each edge of the triangle on \(R\), and add the three single edges \(\ell_jr_j\), \(j=0,1,2\). The cut \(\delta_Q(L)\) has only three edges. Every perfect matching of \(Q\) crosses this odd cut, so five perfect matchings cannot partition \(E(Q)\): they would require at least five cut-edge occurrences where only three edges exist. Thus
\[
                         \boxed{\chi'(Q)>5.}                 \tag{4}
\]

Delete \(\ell_0\) and turn its five incident edge ends into semiedges, obtaining a 5-regular five-pole \(Q^\circ\) on the other five vertices. Expand each vertex \(v\) of \(Q^\circ\) into a proper five-cycle \(C_v\), attaching its five incident edges or semiedges to five distinct cycle vertices. At every \(v\), its five incidences comprise two pairs from doubled triangle edges (a pair may now consist of two semiedges) and one singleton. Attach one pair at cycle positions \(0,2\), the other at \(1,3\), and the singleton at \(4\). At \(\ell_1,\ell_2\), put the semiedges at \(0,2\), and attach the same edge of their doubled connecting pair at position \(1\) on both cycles (the other at \(3\)). Label the semiedges at \(\ell_1\) by \(s_1,s_2\) at positions \(0,2\), those at \(\ell_2\) by \(s_3,s_4\), and the semiedge at \(r_0\) by \(s_5\). Call the resulting cubic five-pole \(H_Q\).

The five cycles give \(|V(H_Q)|=25\). The pole is connected and simple; no proper edge is a bridge, since every edge of \(Q^\circ\) lies on a cycle and the expansion cycles connect all its incidences. It has proper girth five. An internal \(C_v\) is a five-cycle. A cycle using two parallel quotient edges has length at least \(2+2+2=6\), because their two attachment vertices have distance two on each end cycle. A cycle following at least three quotient edges has at least one internal cycle edge between successive attachments, hence length at least six. These exhaust the possible shorter cycles.

Let \(P_0\) use every inter-cycle edge and all five semiedges of \(H_Q\). Every vertex of an expansion cycle has exactly one such incident edge, so \(P_0\) is an actual all-terminal perfect matching and its complement is exactly the five disjoint odd cycles \(C_v\). The equivalence (3) and the odd-cut obstruction (4) give
\[
\boxed{H_Q\text{ is simple, connected, proper-bridge-free and girth five,}
\quad \mathcal C(P_0)=5C_5,\quad P_0\text{ has no all-terminal BF completion}.} \tag{5}
\]
There is also a direct cut proof of this instance of (5). The three right-hand expansion cycles form an odd shore with exactly three boundary edges: \(s_5\) and the two crossing edges. Every matching in a BF row must use an odd number of these edges; since their total BF load is six, all six matchings must use exactly one. The canonical \(P_0\) uses all three.

The order 25 is sharp for this **all-pentagonal complement** obstruction under simplicity and girth five. Suppose a simple cubic five-pole of proper girth at least five has an all-terminal matching \(P\) whose complement is \(kC_5\). No proper edge of \(P\) joins two vertices of one complement cycle: adjacent endpoints would repeat a cycle edge, while nonadjacent endpoints would create a triangle. Contract the \(k\) cycles and restore one new vertex at the five semiedges. This yields a loopless 5-regular multigraph \(Q_P\) on \(k+1\) vertices. The pole has odd order, so \(k\) is odd. If \(|V(H)|<25\), then \(k=1\) or \(3\). For \(k=1\), \(Q_P\) has two vertices and five parallel edges, hence is 5-edge-colourable. For \(k=3\), the four degree-five equations force opposite edges of \(Q_P\) to have equal multiplicities \(a,b,c\), with \(a+b+c=5\). Its five edge colours can be assigned to the \(a,b,c\) copies of the three one-factors of \(K_4\). By (3), \(P\) extends to an all-terminal BF row. Thus \(H_Q\) is the smallest simple girth-five example with \(\mathcal C(P)=kC_5\) and a specified nonextendible \(P\); no assertion about other complement cycle lengths is made.

This refutes “all odd complement cycles and girth five make a specified all-terminal matching extendible.” The obstruction lies in the distinguished matching, rather than in the entire all-terminal BF type: the **same pole does have an all-terminal BF row**.

To see this, let \(A=C_{\ell_1}\), \(B=C_{\ell_2}\). Separate the three right-hand cycles \(C_{r_0},C_{r_1},C_{r_2}\) as a three-pole \(R\), whose boundary is \(s_5\) and the two crossing edges from \(A_4,B_4\). Replace \(R\) temporarily by a cubic vertex \(z\), incident with \(s_5,zA_4,zB_4\), to obtain an eleven-vertex five-pole \(L'\). Its all-terminal matching
\[
P'=\{s_1,s_2,s_3,s_4,s_5,\ A_1B_1,\ A_3A_4,\ B_3B_4\}
\]
has the single complement cycle
\[
z,A_4,A_0,A_1,A_2,A_3,B_3,B_2,B_1,B_0,B_4,z.
\]
Colour the three proper edges of \(P'\) by \(\kappa(A_3A_4)=1\), \(\kappa(A_1B_1)=5\), and \(\kappa(B_3B_4)=4\). In the displayed cyclic order, the colour-1 vertices have positions \(1,2,5\), the colour-4 vertices have positions \(6,7,10\), and the colour-5 vertices have positions \(0,3,8\); colours 2 and 3 each occur at their sole terminal vertex. Every cyclic gap is odd. Criterion (1) therefore gives an actual all-terminal BF row of \(L'\) containing \(P'\).

The three-pole \(R\) has an explicit Tait colouring. Temporarily join its three boundary edges to a cubic vertex \(z_R\). Give the edges \(z_Rr_0,z_Rr_1,z_Rr_2\) colours \(1,2,3\), respectively. For each doubled quotient pair \(r_ir_j\), colour its two edges \(i+1\) and \(j+1\). At \(C_{r_i}\), attach the two edges of its own colour at positions \(0,1\), the two other colours at \(2,3\), and the \(z_R\)-edge at \(4\); this respects the earlier rule that each doubled pair occupies \(0,2\) or \(1,3\), with one edge of each required colour. In cyclic order the external colours are \((a,a,b,c,a)\), where \(\{a,b,c\}=\{1,2,3\}\). The five internal cycle edges receive \((b,c,a,b,c)\) in cyclic order, giving a proper three-edge-colouring. Doubling each colour-class matching yields a BF row of the capped graph and hence of \(R\).

Because \(|V(R)|=15\) is odd, each matching in any BF row of \(R\) meets its three-edge boundary an odd number of times. The total boundary load is six, so every matching meets exactly one boundary edge. The three boundary labels are therefore an ordered partition of the six slots into pairs. Permuting one row's six slots realizes **every** such partition. At \(z\), the three incident labels of the \(L'\) row are exactly such a partition; align them with the \(R\) row and glue. Conversely, any BF row of \(H_Q\) restricts to three pairs at \(R\)'s boundary and therefore contracts to an actual BF row of \(L'\). Writing \(\mathcal B\) for complete BF boundary support, this proves the stronger full-closure identity
\[
                         \mathcal B(H_Q)=\mathcal B(L').
\]
In particular the glued row retains the all-terminal matching slot because the \(s_5\) label is aligned. Thus
\[
\boxed{P_0\text{ does not extend, but }H_Q\text{ has an all-terminal BF row}.} \tag{6}
\]
In particular this pole is no exact-Case-XII example. Independently, its order 25 already excludes exact Case XII by Note 226. Its right-hand three-cycle shore also exhibits a cyclic three-edge cut after adjoining the external edges, so it does not satisfy the minimum-host connectivity constraints of Note 019.

The gluing argument has a general form. **Odd three-boundary substitution:** an odd-order cubic three-pole with one actual BF row has exactly the same complete *labelled* BF boundary relation as a cubic vertex: all ordered partitions of the six slots into three pairs. Parity makes every matching meet the boundary once, and the load-two condition makes every boundary edge occur twice; permuting one row realizes all partitions. Consequently, replacing such a three-pole by a cubic vertex preserves the complete BF support of any larger pole with which it is glued. This explains why a specified matching can acquire a noncompletion obstruction behind a cyclic three-edge cut while the larger pole's entire BF boundary support remains unchanged. In a minimum BF-counterexample host, Note 019's cyclic five-edge connectivity forbids this particular insertion when both sides are cyclic.

For a genuine minimum-host exact-Case-XII pole, the all-pentagonal subcase has a stronger necessary boundary. Suppose it has an all-terminal perfect matching \(P\) with \(\mathcal C(P)=kC_5\), and attach the forbidden pentagon \(T\) to form the host \(G_T\). The matching \(P\) extends across all five joining edges to a perfect matching of \(G_T\), whose complement consists of \(k+1\) five-cycles. Contract these cycles to obtain the loopless 5-regular multigraph \(Q_P\) used in (3), with the new cap cycle contracted to \(x\). For every nontrivial vertex cut of \(Q_P\), both preimage shores in \(G_T\) contain a five-cycle. By the host's cyclic five-edge connectivity from Note 019, that cut has at least five edges; hence \(Q_P\) is 5-edge-connected. Exact Case XII excludes the all-terminal BF type, so (3) also makes \(Q_P\) non-5-edge-colourable. Therefore
\[
\boxed{\mathcal C(P)=kC_5\text{ in a minimum-host exact Case XII}
\quad\Longrightarrow\quad Q_P\text{ is loopless, 5-regular, 5-edge-connected, and }\chi'(Q_P)>5.}
\]
The 25-vertex example has a three-edge cut in its quotient and so does not reach this boundary. The implication does not assert that the all-pentagonal \(P\) exists in an exact-Case-XII pole, or that every such quotient is five-edge-colourable.

**Immediate consequences.** Every odd component of \(\mathcal C\) must have at least five vertices to permit this specified \(P_0\) to extend: it must contain all five colours. A five-cycle component must carry the five colours exactly once, and any \(P_0\)-edge with both ends on that component makes extension impossible. The triangle obstruction in Note 167 is the smallest instance of the first condition; its other even complement cycle is irrelevant to that obstruction.

When every cycle of \(\mathcal C\) is odd, all five colours must appear on every cycle, and (1) reduces to **gap parity alone**. The BF completion is unique for each feasible \(\kappa\). In particular, if \(\mathcal C\) is a single cycle, the test colours only the proper edges of \(P_0\): each chord gets one of five colours, the five terminal vertices have their fixed distinct colours, and each colour class must cut the odd cycle into even paths. For a genuine exact-Case-XII pole with an all-terminal matching \(P_0\), criterion (1) must fail for **every** assignment \(\kappa\), because its all-terminal BF type is absent. This is a necessary full-PM-closure boundary, not an exclusion of that branch.

There is an all-orders constructive subcase. Suppose \(\mathcal C=C\) is one cycle and every proper \(P_0\)-edge has both ends in one open arc between consecutive terminal vertices of \(C\). Each such arc has an even number of vertices, since its vertices are paired by those edges. Colour all \(P_0\)-edges internal to an arc by the label of the terminal immediately preceding that arc. For each colour \(i\), the set \(O_i(C)\) is its terminal vertex followed by all vertices of the next arc. Its consecutive cyclic gaps have length one except for the final gap, whose length is \(|C|\) minus an even number and is also odd. Theorem (1) constructs an all-terminal BF row. Hence
\[
\boxed{\text{an exact-Case-XII pole with such a }P_0
\text{ must have a }P_0\text{-edge joining different terminal arcs}.} \tag{7}
\]
In a minimum BF-counterexample host this cross-arc condition also follows from the inherited restriction on terminal-free proper two-edge cuts in [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md); (7) independently proves it for any pole through actual matching closure.

On an even complement cycle, gap parity alone leaves the alternating load \(a,4-a\); the one-edge inequality in (1) is the exact extra condition. No enumeration, selected-row approximation, or assumption about a minimum host enters the proof.
