> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A local two-root switch excludes the adjacent Hamilton pair

Fix the Case-XII orientation in which \(eX,eY\) are the two forbidden \(e\)-states. The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) leaves either of the two allowed pentagons
\[
S_+=e-Z-X-Y-W-e,\qquad S_-=e-Z-Y-X-W-e.              \tag{1}
\]
In both, \(eX\in T\), where \(T\) is the complementary pentagon; no \(T\)--\(T\) BF type occurs in complete exact-Case-XII support.

**Local switch lemma.** Let a cubic five-pole have an actual BF row of type \((eX)(eZ)\), with six **complete** perfect-matching occurrences
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad a=e,\quad b=e.
\tag{2}
\]
Suppose \(R\triangle K\) has an alternating component
\[
Z-t_Z-v-t_W-W,                                            \tag{3}
\]
where \(t_Z,t_W\) are marked subdivision vertices, \(R\) uses \(t_Zv\) and the terminal \(W\), \(K\) uses the terminal \(Z\) and \(t_Wv\), and \(P\) takes the third edge incident with \(v\). Then the pole's complete BF support cannot be exact Case XII with either pentagon (1). No assumption on the shore or on the other components of symmetric differences is needed.

**Proof.** Switch \(R,K\) along (3), producing complete matchings \(R',K'\) of boundary roles \(eW,W\). At \(v\), the occurrences \(P,R,K\) take its three distinct incident edges. Load two therefore puts exactly one of \(J,a,b\) on each edge. Choose \(D\in\{a,b\}\) that takes \(t_Zv\) or \(t_Wv\), and let \(E\) be the other singleton-\(e\) occurrence. Such a \(D\) exists because only one of \(J,a,b\) can take \(P\)'s third edge. The whole-pole half-loads satisfy
\[
A=R+D+K=R'+D+K',\qquad B=P+E+J,\qquad A+B=2\mathbf1. \tag{4}
\]
The fixed half \(B\) has state \(eX\in T\). Any \(T\)-state obtained by decomposing \(A\) produces a forbidden actual \(T\)--\(T\) row.

There is an \(e\)-starting alternating path in the **complete pole** \(R\triangle D\). Its other terminal is some \(t\in\{X,Y,W\}\). Switching \(R,D\) on that path decomposes \(A\) with state \(Zt\). Compare it with the \(e\)-starting path of \(R'\triangle D\). The two symmetric differences agree outside (3). Their local difference is exact:

* If \(D\) takes \(t_Zv\), it is shared by \(R,D\) before (3) is switched. Afterwards the former \(W\)-terminal arm runs through \(t_Wv,v,t_Zv\) to the \(Z\) terminal. All other terminal arms are unchanged.
* If \(D\) takes \(t_Wv\), the former \(W\)-terminal arm runs through \(t_Wv,v,t_Zv\) before the switch. Afterwards that same continuation begins at the \(Z\) terminal. All other terminal arms are unchanged.

Consequently the new \(e\)-path ends at \(t'=t\) when \(t=X\) or \(Y\), and at \(t'=Z\) when \(t=W\). Switching \(R',D\) on it decomposes the **same** \(A\) with state \(Wt'\).

For \(S_+\), \(Zt\in S_+\) requires \(t=X\), while \(Wt'\in S_+\) requires \(t'=Y\). For \(S_-\), the requirements are \(t=Y\) and \(t'=X\). The local replacement above gives neither \(X\to Y\) nor \(Y\to X\). Equivalently, if \(t=W\) the old state \(ZW\) is already in \(T\); if \(t=X\) or \(Y\), at least one of \(Zt,Wt\) is in \(T\). One of the two genuine decompositions of (4) therefore completes \(B\) to a forbidden \(T\)--\(T\) row. \(\square\)

## The fixed Hamilton three-spoke exterior

Take the exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,\qquad
(X,Y,Z,W)=(14,15,26,36).                              \tag{6}
\]
In the orientation of (1), the published Appendix XII requires an actual \((eX)(eZ)\) row (2). [Note 462](462-the-x-y-forbidden-hamilton-row-has-only-the-common-endpoint-switch.md) proves from the forbidden \([eX]\) and \((eX)(eY)\) types that \(R\) must root at \(Z:6\), \(K\) must take \(W:6\), and (3) is exactly
\[
Z-t_Z-6-t_W-W.                                            \tag{7}
\]
The third edge at original vertex \(6\) is \(6u_5\). Whether \(P=eX\) roots at \(X:1\) or \(X:4\), its rooted tree matching takes \(6u_5\). The local switch lemma therefore excludes **both** roots and hence the entire fixed exterior (6) for the forbidden pair \(\{eX,eY\}\). Reflecting the path \(i\mapsto7-i\) interchanges the pair \(\{X,Y\}\) with \(\{Z,W\}\), so it also excludes the reflected pair \(\{eZ,eW\}\).

For a concrete check, in [Note 463's genuine row](463-a-real-common-endpoint-x-y-hamilton-row-has-a-forbidden-loop.md) the singleton \(a\) takes \(W:6\), and the \(e\)-starting path of \(R\triangle a\) exits at \(p_5\) and ends at \(Y\). The two switches in the lemma give actual states \(ZY\) and \(WY\) for the same three-matching load; each of the two pentagon orientations forbids one of them beside the unchanged \(eX\) half.

Together with the other four forbidden-pair exclusions in [Note 457](457-the-last-five-hamilton-port-profiles-force-a-forbidden-double-triple.md), [Note 461](461-the-y-z-forbidden-hamilton-pair-forces-a-forbidden-recompletion.md) and [Note 475](475-the-last-x-z-hamilton-c3-row-forces-forbidden-full-support.md), this conditionally closes all six forbidden-pair choices for the fixed marked exterior (6). The row-level statements of [Notes 463 and 476--487](476-the-adjacent-forbidden-hamilton-x4-root-has-four-k-signatures.md) retain their stated scope, and their exhibited genuine poles have forbidden complete support, as the lemma requires.

There is a slightly wider consequence within the one-internal-mark, one-shore \(|U|=r=5\) profile. [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md) identifies the other three-spoke prism-tree orbit, already excluded for all six forbidden pairs by [Notes 442--445](445-all-six-forbidden-pairs-are-excluded-on-the-three-spoke-top-path-prism.md). [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md) classifies the three two-spoke prism-tree orbits, all excluded by [Notes 423, 429 and 441](441-the-last-hamilton-prism-forbidden-pair-has-no-exact-case-xii-support.md). Therefore, conditional on those upstream hand proofs, **a triangular-prism exterior with exact Case-XII support would have to use a one-spoke spanning tree**. This is a necessary structural boundary, not an exact-Case-XII pole or a proof of Berge--Fulkerson. The argument uses no OMEN or local mathematical recomputation and awaits independent proof review.

More precisely, [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) gives only the prism and \(K_{3,3}\) as simple suppressed six-vertex exteriors in this profile. [Notes 367 and 372](372-the-k33-marked-path-has-no-exact-case-xii-pentagon.md) exclude the \(K_{3,3}\) double-star and marked-path trees, leaving its Hamilton-path tree. Thus the profile's unresolved tree families are **one-spoke prism** and **Hamilton-path \(K_{3,3}\)**, subject throughout to the cited hand-derived chains and the minimum-host assumptions of Note 358.
