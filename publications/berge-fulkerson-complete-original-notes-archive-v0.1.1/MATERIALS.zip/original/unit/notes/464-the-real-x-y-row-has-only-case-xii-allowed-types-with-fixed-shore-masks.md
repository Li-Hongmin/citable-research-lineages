> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The real \(X,Y\) row has only Case-XII-allowed types with fixed shore masks

The 21-vertex pole of [Note 463](463-a-real-common-endpoint-x-y-hamilton-row-has-a-forbidden-loop.md) has a genuine \((eX)(eZ)\) BF row and a forbidden \([eX]\) loop in its **complete** support. Nevertheless, none of the three immediate types forbidden by exact Case XII with \(\{eX,eY\}\),
\[
[eX],\qquad [eY],\qquad (eX)(eY),
\tag{1}
\]
can be obtained by retaining the six matching occurrences \(P,R,K,J,a,b\) of that row with **each occurrence's complete six-port shore restriction unchanged**, and reassigning only their exterior edges. In fact these are **all** the Case-XII-forbidden types accessible to such a fixed-mask row: the fixed shore restrictions make both zero-port triples miss \(e\). Under either orientation of Note 462, \(e\) maps to label \(1\), \(\{X,Y\}\) to \(\{2,5\}\), and \(\{Z,W\}\) to \(\{3,4\}\). [Published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) then lists precisely seven allowed types among the ten \((ej)(ek)\) and \([ej]\) types:
\[
[eZ],\ [eW],\ (eX)(eZ),\ (eX)(eW),\
(eY)(eZ),\ (eY)(eW),\ (eZ)(eW).
\tag{1a}
\]
The missing three are exactly (1). Thus **every** BF row preserving this selected shore-mask multiset has a type allowed by the Case-XII \(e\)-sector, even though the pole's complete support has forbidden \([eX]\). This is a real, hand-checkable counterexample to inferring a forbidden Case-XII type from one row's fixed six shore masks. It does not block forbidden rows using other shore-mask multisets, and is not an exact-Case-XII pole.

Only the labelled port pairs are needed for the no-go proof. From Note 463(8),
\[
e=ab,\qquad
(p_1,p_2,p_3,p_4,p_5)=(ab,Jb,ab,KJ,Ka).
\tag{2}
\]
The original occurrences \(P,R\) use no proper port, \(K,J\) use two proper ports each, and \(a,b\) use three each. By the six-port quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), any recompletion of (1) with these fixed complete shore restrictions must keep \(P,R\) as the two zero-port triple occurrences and \(a,b\) as the two singleton-\(e\) occurrences. Thus \(K,J\) take the other two singleton roles. Swapping \(P,R\) in the **exterior pair search** preserves (2), since neither label appears on a shore port; this symmetry does not assert that their two distinct complete shore matchings can be swapped.

## The two loops

For \([eY]\), \(K\) would be a singleton-\(Y\) occurrence and would select terminal \(Y\). But (2) makes \(K\) use proper ports at \(u_4,u_5\), hence neither tree half at those subdivisions. Its only possible edge at original vertex \(5\) is \(Y:5\), which a singleton-\(Y\) occurrence cannot use. So \([eY]\) is impossible.

For \([eX]\), the terminal pairs would be
\[
e=ab,\qquad X=KJ,\qquad Y=Z=W=PR.
\tag{3}
\]
As before, \(K\) must use \(Y:5\). Since \(K\) selects terminal \(X\), it uses neither half of \(X\); since it uses \(Y:5\), it misses \(Y:1\). Covering original vertices \(1,4\) forces \(K\) onto \(1u_1\) and \(4u_3\), respectively. If both \(P,R\) root at \(X:1\), they already occupy \(4u_3\); if both root at \(X:4\), they already occupy \(1u_1\). Thus their \(X\)-roots are opposite. Interchange their exterior labels if needed, and take \(P:X:1,\ R:X:4\).

At \(u_1\), \(R\) and \(K\) use the first half, while \(p_1=ab\), so its three pairs are \((RK,PJ,ab)\). At original vertex \(1\), write \(X:1=P\nu\) with \(\nu\in\{a,b\}\); the other pairs are \(1u_1=RK\) and \(Y:1=J\bar\nu\), where \(\bar\nu\) is the other \(e\)-singleton. Because \(Y=PR\), the opposite marked half is \(Y:5=K\nu\).

At \(u_5\), both zero-port triples use its second half \(PR\). The fixed port \(p_5=Ka\) therefore forces its first half to be \(Jb\). At original vertex \(5\), \(u_4:5=PR\) as well, so \(Y:5=Ka\). Hence \(\nu=a\), \(X:1=Pa\), and \(X:4=Rb\) by (3). At \(u_4\), the second half is \(PR\) and the fixed port is \(KJ\), so its first half is \(ab\). Original vertex \(4\) would then see
\[
u_3:4=PK,\qquad X:4=Rb,\qquad u_4:4=ab,
\tag{4}
\]
with \(b\) appearing twice. This rules out \([eX]\), including the swapped \(P,R\) root order.

## The forbidden double triple

For \((eX)(eY)\), \(K,J\) must be the singleton-\(X,Y\) occurrences in one order. If \(K\) were singleton \(Y\), the same vertex-\(5\) argument as for \([eY]\) would fail. Therefore \(K\) is singleton \(X\) and \(J\) singleton \(Y\). By exterior \(P,R\) symmetry, take \(P=eX,\ R=eY\). The terminal pairs are
\[
e=ab,\qquad X=RK,\qquad Y=PJ,\qquad Z=W=PR.
\tag{5}
\]
Again \(K\) must use \(Y:5\), then \(1u_1\) at vertex \(1\) and \(4u_3\) at vertex \(4\). The roots \(P:X:4,\ R:Y:5\) would both occupy \(1u_1\), while \(P:X:1,\ R:Y:1\) would both occupy \(4u_3\). Only two root pairs remain.

If \(P:X:1,\ R:Y:5\), then \(u_1:1=RK\), and \(p_1=ab\) forces \(u_1:2=PJ\). At original vertex \(1\), the other two edges are \(X:1=PJ,\ Y:1=ab\). Thus \(X:4=ab\). At original vertex \(4\), \(u_3:4=PK\), so \(u_4:4=RJ\). But the same edge enters \(u_4\), whose fixed port is \(KJ\); it would put \(J\) on two edges of \(u_4\). This root pair is impossible.

If \(P:X:4,\ R:Y:1\), then \(u_1:1=PK\) and \(u_1:2=RJ\). Write \(Y:1=R\nu\), where \(\nu\in\{a,b\}\) because \(Y=PJ\). Vertex \(1\) and terminal \(X=RK\) force \(X:1=J\bar\nu\) and \(X:4=P\nu\). At original vertex \(4\), \(u_3:4=RK\), so \(u_4:4=J\bar\nu\). Yet \(u_4:5=PR\) and \(p_4=KJ\) force \(u_4:4=ab\). The equality \(J\bar\nu=ab\) is impossible. This excludes the second root pair and completes the proof of (1).

The \([eX]\) loop exhibited in Note 463 comes from two-colouring the complement of the zero-port triple \(P\). The old row has **distinct** zero-port shore restrictions \(Q_P,Q_R\), whereas that doubled Tait colouring uses \(Q_P\) twice. Thus its shore-mask multiset changes. More generally, the six old shore restrictions are distinct: \(P,R\) are different alternating matchings of the six-cycle, and the other four have different labelled port sets in (2). Any row retaining their unordered multiset could therefore be relabelled to retain them occurrence by occurrence, which the proof above excludes for (1).

The constructed Tait loop actually uses two shore masks with **new port signatures**. Starting with the singleton-\(e\) colour at \(e\), the three odd shore paths in Note 463(10) keep that colour at their paired endpoints, while each even exterior path in Note 463(11) reverses it between its two terminal or port edges. Following the single open path, the singleton-\(e\) occurrence uses shore ports \(\{e,p_2,p_4,p_5\}\); the singleton-\(X\) occurrence selects exterior terminal \(X\) and proper shore ports \(\{p_1,p_3\}\). Neither shore-port signature belongs to the four old singleton restrictions in (2). On the six-cycle shore, the new singleton-\(e\) restriction uses the internal edge \(q_1q_3\); the new singleton-\(X\) restriction uses \(q_eq_2,q_4q_5\). This describes the particular full-closure escape exactly. The no-go theorem itself only forces a changed **multiset**; a different forbidden row could in principle repeat old shore matchings instead of introducing a new one.

Inserting the support-preserving Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) at the shore vertex \(q_2\) keeps both the old row and the full-support \([eX]\) loop while adding an odd complementary shore cycle to every zero-port shore matching. The fixed-mask gap persists. One may then make the same substitution at the still-untouched shore vertex \(q_1\). The resulting pole has \(21+8+8=37\) vertices, girth at least five, the same complete BF support and the same fixed-mask obstruction. The \(q_2\) Petersen block still puts an odd five-cycle in the complement of every zero-port shore matching, and makes the pole Tait-empty. Thus even the [published order-33 lower bound for an exact-Case-XII pole](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md), imposed merely as a numerical threshold alongside the real row and odd-shore-cycle condition, does not repair the selected-mask inference. The two substitutions leave cyclic three-edge cuts, so they do not model the irreducible minimum host. This is a precise boundary for a one-row, occurrence-preserving closure argument. Other forbidden BF types and cross-row full-PM mechanisms remain to be decided. The proof is hand-derived, without OMEN or local mathematical recomputation, and awaits independent review. \(\square\)
