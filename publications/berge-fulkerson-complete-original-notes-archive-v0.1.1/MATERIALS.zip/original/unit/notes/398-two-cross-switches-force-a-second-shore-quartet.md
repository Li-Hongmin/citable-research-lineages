> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two cross-switches force a second shore quartet in the mixed prism row

Continue the only surviving exterior orientation of [Note 396](396-the-mixed-prism-root-pair-has-one-pentagon-and-two-exterior-masks.md):
\[
S=e-AC-ab-Cc-bc-e.
\]
Let \(P\) be the forbidden \(e\,ab\)-triple rooted at \(a\), \(R\) the allowed \(e\,AC\)-triple rooted at \(C\), \(E,F\) the two singleton-\(e\) occurrences, \(J\) singleton-\(ab\), and \(K\) singleton-\(AC\), in one actual complete six-matching BF row. Name \(E\) as the occurrence using \(Bu_2\) and \(F\) as the one using \(Bu_4\). No bound on shore order, cycle rank, port-path length or zero-port signature is imposed.

By Note 396, the shore \(e\)-path in \(R\triangle E\) ends at \(p_4\), and the one in \(R\triangle F\) ends at \(p_2\). Each full path then reaches terminal \(ab\). Switch \(R,E\) along its \(e\)--\(ab\) path and call the resulting triple \(R_E\); similarly define \(R_F\) by switching \(R,F\) in the original row. In either resulting row the unchanged \(P\) still has forbidden state \(e\,ab\), while the new triple has allowed state \(AC\,ab\).

> **Second quartet gate.** The shore part of \(R_E\triangle K\) must pair \(p_4\) with \(p_5\), and its other open pair is \(e\,p_3\). The shore part of \(R_F\triangle K\) must pair \(p_2\) with \(p_5\), and its other open pair is again \(e\,p_3\). Each is a condition on *complete actual matchings* in a different, explicitly obtained BF row. Failure of either pairing gives a forbidden double-\(T\) row using the original six matching occurrences and successive alternating-path exchanges.

**Proof.** The first switch changes \(R\)'s shore boundary from no ports to \(\{e,p_4\}\), and changes its exterior only on
\[
p_4-u_4-b-t_{ab}-ab.
\]
Thus \(R_E\) uses \(e,p_4\) on the shore, \(ab:b\) at the mark, and \(u_4:p_4\); its other exterior edges agree with \(R\). Note 396 gives \(K\) ports \(p_3,p_5\), with \(Cu_2,Bu_4,Au_1,ab:a,bc:b,Cc:c\). The three exterior arms of \(R_E\triangle K\) are
\[
\begin{aligned}
AC&-t_{AC}-C-u_2-B-u_4-p_4,\\
Cc&-t_{Cc}-c-u_5-p_5,\\
bc&-t_{bc}-b-t_{ab}-a-u_3-p_3.
\end{aligned}                                                    \tag{1}
\]
The fourth endpoint, \(e\), is on the shore. The full \(AC\)-starting alternating path therefore ends at \(e,Cc\), or \(bc\), according as the shore joins \(p_4\) to \(e,p_5\), or \(p_3\). Switching \(R_E,K\) on it changes \(R_E\)'s state \(AC\,ab\) to, respectively, \(e\,ab\), \(ab\,Cc\), or \(ab\,bc\). Only \(ab\,Cc\) belongs to \(S\); the other two lie in \(T\) and would coexist with the unchanged \(P\in T\). Hence \(p_4p_5\) is forced, leaving \(ep_3\).

For \(F\), the first \(e\)--\(ab\) path leaves the shore through \(p_2\) and follows \(p_2-u_2-B-u_4-b-t_{ab}-ab\). Thus \(R_F\) has shore ports \(e,p_2\), uses \(u_2:p_2,Bu_4,ab:b\), and agrees with \(R\) elsewhere. Its \(AC\)-arm against \(K\) is \(AC-t_{AC}-C-u_2-p_2\); the \(Cc\)- and \(bc\)-arms still end at \(p_5,p_3\), respectively. The same state test forces \(p_2p_5\) and leaves \(ep_3\). \(\square\)

The [25-vertex actual row of Note 397](397-a-real-mixed-prism-row-satisfies-both-e-port-selectors.md) passes both first selectors and fails this second gate. Its first \(R\triangle E\) shore path is
\[
e-h_0-h_1-h_3-h_7-h_8-h_5-p_4.
\]
After switching it, the shore path of \(R_E\triangle K\) starting at \(p_4\) is
\[
p_4-h_5-h_1-h_3-h_7-h_8-h_9-h_4-p_3.                   \tag{2}
\]
Joining (2) to the \(AC\)- and \(bc\)-arms in (1) and switching \(R_E,K\) gives the forbidden \((e\,ab)(ab\,bc)\) double-\(T\) row. The 33-vertex Petersen replacement in Note 397 retains this forbidden BF type by support preservation. Thus that counterexample fails exact Case XII already in the two-step exchange closure of its displayed six occurrences; its separate forbidden Tait loop is not needed for this rejection.

The gate does not prove the two quartet pairings incompatible in an arbitrary shore. [Note 399](399-the-direct-mixed-prism-root-pair-is-impossible-at-all-shore-orders.md) shows that even a shore satisfying them cannot yield exact Case XII: two further exterior switches force a double-\(T\) row. The paths and load checks are hand-derived and have not received independent review.
