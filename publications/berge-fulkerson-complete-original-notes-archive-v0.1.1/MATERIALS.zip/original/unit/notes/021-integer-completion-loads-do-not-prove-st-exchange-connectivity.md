> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Integer completion loads do not prove S--T exchange connectivity

The exchange-connectivity conjecture of Note 015 cannot be proved from the
integer edge loads of individual BF completions, their deficits, or modular
projections of those equations alone.  This is a limitation of that
information layer, not a counterexample to the conjecture for cubic 5-poles.

## Load and deficit telescope under exchange

For a disjoint S--T completion with triple-boundary perfect matchings
\(Q,R\), define

\[
\ell(Q,R)=\chi_Q+\chi_R,
\qquad
d(Q,R)=2\mathbf 1-\ell(Q,R).
\]

If \(P_i\), for \(i\in s\cup t\), are the four singleton-boundary perfect
matchings, the exact BF double-cover equation is

\[
\sum_{i\in s\cup t}\chi_{P_i}=d(Q,R).
\]

Suppose that \(Q'=Q\mathbin\triangle C\) is a same-boundary exchange along
one alternating cycle.  With \(R\) fixed,

\[
\ell(Q',R)-\ell(Q,R)=\chi_{Q'}-\chi_Q,
\qquad
d(Q',R)-d(Q,R)=\chi_Q-\chi_{Q'}.
\]

These identities telescope tautologically along every exchange path: their
sum is only the difference of the endpoint incidence vectors, and it is zero
on a closed walk.  Thus a route-forcing argument would have to show that the
singleton decompositions cannot absorb the local deficit change.  The next
example shows that they can absorb it exactly.

## Exact one-slot cancellation in genuine order-fifteen poles

The two order-fifteen exact-\(S\) poles with 21 of the 25 S--T types both
have disjoint-completion route profile

\[
\mathrm A:3,\qquad \mathrm{SS}:6.
\]

Enumerating every four-singleton decomposition of every disjoint completion
finds six genuine A--SS shared-neighbour exchange triangles.  Four exchange
cycles have length 10 and two have length 12.  In every triangle there are
completion witnesses for which \(R\) and three singleton matchings remain
fixed, while the remaining singleton matching satisfies

\[
Q'=Q\mathbin\triangle C,
\qquad
P'=P\mathbin\triangle C,
\qquad
(\chi_{Q'}-\chi_Q)+(\chi_{P'}-\chi_P)=0.
\]

The cancellation is therefore edgewise and uses the identical alternating
cycle, not merely equal aggregate loads.  The six cases have the following
form:

\[
\begin{array}{c|c|c|c|c}
\text{boundary type}&\text{exchanged class}&\text{fixed class}
&\text{changed singleton position}&\text{cycle lengths}\\\hline
(15)(24)&24&15&5&12,10,10\\
(25)(34)&25&34&4&10,10,12.
\end{array}
\]

Consequently, even in actual cubic 5-poles, changing the route from SS to A
need not leave any residual integer load: one same-boundary singleton
exchange can cancel the entire change.

## An exact abstract all-SS integer model

The labelled countermodel of Note 017 admits a strengthening that satisfies
all designated integer double-cover equations.  Take one triple-matching
vertex in each of the ten classes \(S\cup T\), duplicate class \(13\), retain
one completion edge for every one of the 25 S--T class pairs, add a second
\(13\)--\(45\) completion incident with the duplicate, and join the two
\(13\) vertices by one same-class exchange.  The resulting matching-level
graph is connected, has 26 completion edges, and has full \(K_{5,5}\)
boundary-class quotient.

Use five terminal coordinates and four internal coordinates
\(c_1,c_2,c_3,c_4\).  Give the two class-\(13\) triple vectors internal
supports \(\{c_1,c_3\}\) and \(\{c_2,c_4\}\), so their symmetric difference
is an abstract alternating 4-cycle.  For each completion, introduce four
private singleton vectors and fill on every internal coordinate exactly the
deficit left by its two triple vectors.  Boundary coordinates already have
the prescribed multiplicity two.  Hence each of the 26 designated
six-matching completions satisfies

\[
\sum_{M\text{ in the completion}}\chi_M=2\mathbf 1
\]

over the integers on all nine coordinates.  The construction uses 115
global 0/1 vectors, and all six disjoint completion edges are labelled SS.
It therefore also satisfies every modular projection of the exact load
equations.

Crucially, this abstract object is **not** the perfect-matching incidence
system of a common cubic 5-pole.  Its internal coordinates and route labels
are formal, and its singleton witnesses are private to individual
completion edges.  It neither realizes the common cubic vertex-incidence
constraints nor derives its routes from actual alternating paths.  It does
not refute the pole-level conjecture.

## Consequence and remaining interface

The exact negative conclusion is limited but definitive: integer edge-load
vectors, exact double-cover equations, deficit telescoping, and their modular
reductions do not suffice to prove S--T exchange connectivity.  A successful
argument must retain structure discarded by this layer, such as the common
cubic vertex-incidence equations for all perfect matchings of one pole,
reuse and compatibility of singleton witnesses across completions, or the
actual path decompositions that determine A, SS, and TT routes.

The finite measurements and abstract construction are verified by
`scratch/worker-kempe/integer_load_exchange_audit.py` and
`scratch/worker-kempe/verify_abstract_integer_load_all_ss.py`.  Their terminal
markers are respectively `INTEGER_LOAD_EXCHANGE_AUDIT_OK` and
`ABSTRACT_INTEGER_LOAD_ALL_SS_VERIFIED`.
