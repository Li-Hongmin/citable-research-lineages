> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The left ac row excludes IJ and forces the right ad opposite pairing

Work in the central-path exterior with a real left \((ea)(ac)\) row of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), a real right \((ea)(ad)\) row of [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md), and complete exact-Case-XII support. The two required BF types and forbidden \(T\)-states are in [Máčajová–Mazzuoccolo–Tabarelli (2026), Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Use the \(3{:}2\) near-bipartite core of [Notes 298–300](300-two-forbidden-ej-completions-trap-the-marked-edge-in-an-internal-odd-cycle.md): \(C-g\) is bipartite with \(g\subset B\), the internal mark has ends \(v\in B,w\in R\), and the shore ports are \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). [Note 299](299-two-singleton-c-masks-exclude-the-right-ad-h-side-and-one-b-port-profiles.md) leaves \(R_0=IJ,DJ\), where \(R_0\) is the pair of \(R\)-based proper ports.

**Theorem.** The placement \(R_0=IJ\) is impossible. Thus the only remaining right-row placement in this precise near-bipartite profile is \(R_0=DJ\). In that placement write the right row as \((X,Y,Z,U,V,W)\), with shore port sets
\[
       (\varnothing,ID,EAHJ,EJ,ID,AH).                         \tag{1}
\]
Let \(C_U\) be the shore-internal odd cycle through \(t_e\) in the complement of \(U\) supplied by Note 300. Then:

1. For each \(M\in\{X,Y,Z,V,W\}\), the number \(k_M\) of vertices of \(C_U\) at which the \(U\)-edge is also an \(M\)-edge is odd. Hence \(|C_U|\ge5\), and \(Y\triangle V\) contains both a \(Y\)-only edge and a \(V\)-only edge of \(C_U\).
2. In each of \(U\triangle Y\) and \(U\triangle V\), the shore alternating path starting at \(E\) contains \(g\). In \(U\triangle W\), the path starting at \(E\) avoids \(g\).
3. The shore path pairing of \(U\triangle W\) is **necessarily** \(EH\mid AJ\), the same pairing as the pure \(X\triangle Z\) paths of Note 297. The pairing \(EA\mid HJ\) would create the forbidden \(AJ,g,t_{ew}\) shore matching of [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md); the pairing \(EJ\mid AH\) violates matching balance after one path switch.
4. Switching the complete \(e\)--\(b\) component of \(U\triangle W\) produces a **second genuine \((ea)(ac)\) BF row**, now with the right singleton-\(a\) exterior \(Y_R\). In its opposite half, the new singleton-\(c\) shore matching has ports \(HJ\) and selects \(g,t_{ew}\), while the new \(ac\)-triple has ports \(EA\).
5. **Both** singleton-\(a\) occurrences of the original left \(ac\) row select \(g,t_{ew}\). Let \(L\) be either one, and let \(Q\) be either singleton-\(a\) occurrence of the new right \(ac\) row. The shore paths of \(L\triangle Q\) pair \(ID\mid HJ\); their exterior continuations make a full alternating cycle through all four ports, \(g\), and \(t_e\).
6. Every actual \(HJ\)-port shore matching selecting \(g,t_{ew}\) has complement pairing \(EI\mid AD\). This applies both to \(L\) and to the singleton-\(c\) matching created in assertion 4.

## Excluding IJ with the ac row alone

For \(R_0=IJ\), both \(HJ\) and \(ID\) are mixed-side port pairs. [Note 290's complete-fibre proof](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) excludes every \(ID\)-port matching selecting \(g,t_{ew}\). Its separate singleton-\(c\) mask
\[
 \{c_{\rm term},a:C_{\rm ext},b:D_{\rm ext},d:E_{\rm ext},
                    1A_{\rm ext},2B_{\rm ext},h_3,h_4\}       \tag{2}
\]
also excludes every \(HJ\)-port matching selecting \(g,t_{ew}\) when \(I\) is the other \(R\)-based port. Indeed, after gluing such a matching, the sole unselected same-side edge is the \(I\) cut edge, on the exterior \(d\)--\(I\) arm. All complement cycles are even. The exception-free terminal path has differently coloured ends, but cannot be the \(e\)--\(d\) path required to keep both singleton-\(c\) Tait switches in the allowed pentagon \(S=e-a-b-d-c-e\). Thus one switch would give a forbidden state. Neither fibre exclusion uses an \(ad\)-row orientation.

The real left \((ea)(ac)\) row has two \(HJ\)-port occurrences \(Y_a,V_a\) and one opposite \(ID\)-port occurrence \(W_c\), by Note 271's Table (5). For either mixed-side pair, [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) permits just \((t_{ev},g\notin M)\) or \((t_{ew},g\in M)\). The two complete-fibre exclusions therefore force **all three occurrences** \(Y_a,V_a,W_c\) to select \(t_{ev}\). A BF row loads every edge twice, whereas these three occurrences already load \(t_{ev}\) three times. This contradiction proves \(R_0\ne IJ\). It extracts the \(q=I\) part of Note 290 from the left \(ac\) row alone, so [Note 297's](297-the-right-central-ad-row-survives-the-exterior-route-check.md) correction to the \(ad\) row does not affect it.

## Odd-cycle incidence

Now \(R_0=DJ\). Note 297's right-row load gives \(U\) the ports \(EJ\) and the edge \(g\); \(X\) also selects \(g,t_{ew}\), both \(Y,V\) select \(t_{ev}\), and \(W\) selects \(t_{ew}\) without \(g\). Note 300 puts both \(t_{ev},t_{ew}\) on the odd cycle \(C_U\) of the shore complement of \(U\).

At each vertex of \(C_U\), the selected \(U\)-edge is the third incident edge. Since each edge has row load two, it has exactly one companion among \(X,Y,Z,V,W\). If companion \(M\) occurs at \(k_M\) vertices, then at every other vertex of \(C_U\), \(M\) selects a cycle edge. Those selected cycle edges cover the other \(|C_U|-k_M\) vertices in pairs. Hence
\[
          k_M\equiv |C_U|\equiv1\pmod2,
          \qquad\sum_{M\ne U}k_M=|C_U|.                \tag{3}
\]
This gives \(|C_U|\ge5\). At a vertex whose \(U\)-edge is shared with \(Y\), \(V\) must select a cycle edge that \(Y\) does not select; at a vertex whose \(U\)-edge is shared with \(V\), the analogous cycle edge belongs to \(Y\setminus V\). Equation (3) supplies both kinds of vertices, and the two edges cannot coincide. Thus the two repeated \(ID\)-port occurrences genuinely differ on \(C_U\), away from their common marked half-edge \(t_{ev}\).

## Opposite routes from the marked terminal

Take \(Q=Y\) or \(V\). The \(E\)-starting path of \(U\triangle Q\) passes through \(t_{ev}\), since \(U\) selects \(E\) and \(Q\) selects \(t_{ev}\). Suppose this path avoided \(g\), and switch it in \(U\). The resulting shore matching selects \(g,t_{ev}\). If the path ends at \(J\), the new matching has zero proper ports, contrary to the balance equation. If it ends at \(I\), its ports are \(IJ\), one \(B\)-based and one \(R\)-based, again contrary to balance for \(g,t_{ev}\). If it ends at \(D\), its ports are the two \(R\)-based ports \(DJ\), contrary to [Note 289's complete-fibre exclusion](289-the-remaining-near-bipartite-core-has-an-empty-r-r-two-port-fibre.md). Thus the path contains \(g\). The same argument applies separately to \(Y,V\); it never identifies their complete masks.

The \(E\)-starting path of \(U\triangle W\) instead passes through \(t_{ew}\). Switch it in \(U\). Its other end is \(J,A\), or \(H\), so the new matching has zero proper ports or the mixed pair \(AJ\) or \(HJ\). For each of these port sets, balance forces a matching selecting \(t_{ew}\) to select \(g\). Therefore the switched path **avoids** \(g\). The only same-side shore edges in \(U\triangle W\) are \(g,t_{ew}\); as \(t_{ew}\) lies on this \(E\)-path, \(g\) cannot lie on a closed alternating cycle. It lies on the other open path.

If the \(E\)-path ends at \(A\), switching it in \(U\) yields a real \(AJ\)-port matching selecting \(g,t_{ew}\), forbidden by Note 296, Theorem 2, whose complete-fibre proof is independent of the left \(ad\) template. If instead the \(E\)-path ends at \(J\), the other open path pairs \(A,H\) and contains \(g\). Switching that \(A\)--\(H\) path in \(U\) would retain its \(EJ\) port set and its selected terminal \(E\), but remove \(g\). Balance forbids this: an \(EJ\)-port shore matching necessarily selects \(g\), since \(J\in R\). Therefore the \(E\)-path ends at \(H\), giving exactly \(EH\mid AJ\).

In the actual right-row exterior of Note 297, the \(U\triangle W\) route from terminal \(b\) reaches shore port \(H\): it runs through \(t_b,D_{\rm ext},u_3\). Terminal \(e\) reaches \(E\). The forced shore pair \(EH\) therefore joins them into one complete \(e\)--\(b\) alternating path. Switch that path between \(U\), whose terminal boundary is \(bce\), and \(W\), whose boundary is \(d\). The resulting boundaries are \(c\) and \(bde\), respectively. Together with unchanged \(X,Y,Z,V\), the six actual matchings retain load two and have BF type \((ea)(ac)\). On the shore the switched \(U\) loses \(E\), gains \(H\), and retains \(J,g\); it acquires \(t_{ew}\). Its exterior becomes exactly mask (2): \(\{c_{\rm term},a:C,b:D,d:E,1A,2B,h_3,h_4\}\). The switched \(W\) loses \(H\), gains \(E\), and retains \(A\). This proves assertion 4.

## Comparing the two ac orientations

In the left \(ac\) row, \(Z_e,U_{ac},W_c\) avoid \(g\): their port sets are \(EAID,EA,ID\), and the last avoids \(g,t_{ew}\) by Note 290. The zero-port slot \(X_L\) also avoids \(g\). Otherwise it selects \(t_{ew}\) by balance; the pure \(X_L\triangle Z_e\) paths pair \(EI\mid AD\) by Note 271. The \(E\)--\(I\) path starts through \(t_{ew}\), has odd internal length from \(R\) to \(B\), and therefore contains the other same-side edge \(g\) as well. Switching it in \(Z_e\) gives a forbidden \(AD,g,t_{ew}\) shore matching of Note 290. Hence \(X_L\) selects \(t_{ev}\) and avoids \(g\). Since this row loads \(g\) twice, **both** its \(HJ\)-port singleton-\(a\) occurrences select \(g,t_{ew}\). Choose either as \(L\). Each right singleton-\(a\) occurrence \(Q\in\{Y,V\}\) has ports \(ID\), selects \(t_{ev}\), and avoids \(g\).

The exact exterior masks \(Y_L,Y_R\) of Note 271 have symmetric-difference routes
\[
 I-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c-A_{\rm ext}-t_b-D_{\rm ext}-u_4-J,
 \qquad D-u_2-C_{\rm ext}-u_3-H.                      \tag{4}
\]
Their terminal \(a\) semiedge is common. Inside the shore, \(L\triangle Q\) has four open ends \(I,D,H,J\), plus possible closed alternating cycles. Its only same-side internal edges are \(g,t_{ew}\). They cannot both lie on a closed component: switching that component into \(Q\) would make a forbidden \(ID\)-port matching selecting \(g,t_{ew}\) by Note 290.

There are three shore pairings. For \(IH\mid DJ\), each open path has same-side ends and endpoints selected by different matchings, so each contains zero or two same-side edges. Both \(g,t_{ew}\) therefore lie on one path. Switching that path into \(Q\) gives a \(DH\)- or \(IJ\)-port matching selecting \(g,t_{ew}\), both forbidden by Note 296, Theorem 2.

For \(IJ\mid DH\), each path has opposite-side ends and endpoints selected by different matchings, so each contains exactly one of \(g,t_{ew}\). Switch the \(I\)--\(J\) path into \(Q\). It changes its ports from \(ID\) to \(DJ\). If that path contains \(g\), the new matching selects \(g,t_{ev}\), contrary to Note 289. If it contains \(t_{ew}\), the new matching selects \(t_{ew}\) but avoids \(g\), contrary to Note 283's balance for two \(R\)-based ports. Thus this pairing is also impossible.

Only \(ID\mid HJ\) remains. In this case the path parity puts \(g,t_{ew}\) together on one open shore path. Equation (4) joins the two shore paths into one full alternating cycle through \(I,D,H,J\); that cycle contains \(g\) and the marked vertex \(t_e\). Other closed shore components may also occur. This proves assertion 5.

## The HJ complement pairing

Let \(N\) be any actual shore matching with ports \(HJ\) selecting \(g,t_{ew}\). Reuse the genuine singleton-\(c\) exterior mask (2), whose free-port complement arms are \(e\)--\(E\), \(a\)--\(A\), \(d\)--\(I\), and \(b\)--\(D\). The only same-side edge left in the complete complement is the \(D\) cut edge, which lies on the open path starting at \(b\). Every closed cycle is even. The matching therefore extends to a Tait colouring with singleton \(c\). The terminal path without \(D\) has differently coloured ends; switching it makes each end, in turn, the second singleton. Exact support allows only \(ce,cd\), so that path must join \(e\) and \(d\). Its shore part pairs \(E\) with \(I\); the other shore path pairs \(A\) with \(D\). Hence \(\sigma(N)=EI\mid AD\). The switched singleton-\(c\) matching of assertion 4 has precisely the exterior mask (2), so the rule applies to it as well. This proves assertion 6. \(\square\)

For a direct exterior check of the four arms, use
\(K=A_{\rm ext}-u_1-B_{\rm ext}-u_2-C_{\rm ext}-u_3-D_{\rm ext}-u_4-E_{\rm ext}\)
and the cross marks \(a:C\!:\!\Sigma,b:AD,c:AE,d:BE\) from Note 271.
Against mask (2), the unselected routes are
\(a-t_a-A\), \(d-t_d-B_{\rm ext}-u_1-I\), and
\[
 b-t_b-A_{\rm ext}-t_c-E_{\rm ext}-u_4-D_{\rm ext}
 -u_3-C_{\rm ext}-u_2-D,
\]
while the internal mark gives \(e-E\). The displayed
\(b\)--\(D\) arm puts the sole unselected same-side cut
edge on an open terminal path for every gluable \(HJ\) shore
matching. Thus the even-cycle argument does not depend on
which complete matching in that fibre was chosen.

These conditions concern genuine rows under complete exact support. The two \(ac\) orientations are coupled by a specific full alternating cycle, but this does not exclude their coexistence or the \(DJ\) placement. The \(4+1\) near-bipartite profile, higher-rank cores, other minimum-host profiles, and Berge–Fulkerson also remain open. The argument is symbolic and depends on the hand-derived masks and fibre proofs cited above; it has not had an independent second-source check. No local enumeration or OMEN computation was used.
