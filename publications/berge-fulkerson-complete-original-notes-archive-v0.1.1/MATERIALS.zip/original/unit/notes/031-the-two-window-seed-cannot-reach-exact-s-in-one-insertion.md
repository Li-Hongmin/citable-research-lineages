> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two-window seed cannot reach exact-S in one insertion

The seventeen-vertex two-window pole of Note 026 cannot be converted into a
full exact-S counterexample by one two-edge insertion.  Its complete labelled
one-step neighbourhood contains 378 order-nineteen children, and every child
has at least six Tait states.

All 378 children were independently enumerated through their complete perfect
matching families.  Their Tait-state counts are

\[
\begin{array}{c|rrrrr}
\text{states}&6&7&8&9&10\\\hline
\text{children}&15&101&80&178&4.
\end{array}
\]

Hence no child is exact-S and none reaches the subsequent test of whether
the two designated \(Y\)-windows remain simultaneously blocked.

Of the 378 moves, 51 are standard triangle lifts of all ten designated
matchings and preserve their exact designated \(C_{10}\).  Tait colouring
contraction and lift are bijective on this subfamily, so both extra seed
states survive and full exact-S is impossible.

For the whole neighbourhood, the same obstruction has a seed-local Kempe
form.  Starting from each of the parent's 58 Tait colourings, delete the two
selected edge objects from a suitable two-colour subgraph and switch a union
of components separating both selected endpoint pairs.  The switched
colouring extends across the inserted edge.  These explicit parent-derived
colourings alone produce at least six boundary states for every child.  For
all 378 moves, the predicted state set is contained in the independently
enumerated complete child state set.

There is one nontriangle move, using the proper edges \((5,14)\) and
\((6,7)\), for which all ten designated matchings have boundary-preserving
local extensions.  Every extension uses the new joining edge, so their
designated disjointness graph ceases to be \(C_{10}\); the complete Tait set
also remains the parent's seven-state set.  It is not a forced-path
counterexample.

This is a complete exclusion only for the frozen seed and its one-step
two-edge-insertion neighbourhood.  It does not prove that full exact-S
forbids two blocked \(Y\)-windows in general and does not classify all
order-nineteen poles.

The streaming verifier is
`scratch/worker-dual/scan_n19_two_window_exact_s_children.py`; it terminates
with `N19_TWO_WINDOW_EXACT_S_CHILD_SCAN_OK`.
