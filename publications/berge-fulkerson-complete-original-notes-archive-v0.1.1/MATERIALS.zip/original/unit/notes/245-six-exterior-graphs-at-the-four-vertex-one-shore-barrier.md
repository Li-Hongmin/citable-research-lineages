> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Six exterior graphs at the four-vertex one-shore barrier

Continue [Note 244's](244-every-shore-mark-must-neighbour-the-internal-mark.md) minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile. Let \(k=|U|\), \(|W|=k+1\), \(r=|E_F(U,C)|\), and \(K=F[U,W]\). Each \(u\in U\) meets at most one vertex of the odd shore \(C\), so \(d_K(u)\in\{2,3\}\), and \(|E(K)|=3k-r\). Every \(w\in W\) has \(1\le d_K(w)\le3\): three marked edges at a singleton are excluded by [Note 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md). The girth-five condition rules out a four-cycle in \(K\).

**Theorem.** The strict Hall inequality of [Note 233](233-minimal-barrier-forces-strict-hall-on-the-one-shore-exterior.md) forces \(K\) to be connected, with cycle rank
\[
\boxed{\operatorname{rank}(K)=k-r.}                       \tag{1}
\]
At the first barrier size left by Note 244, \(k=4\), exactly six unmarked exterior shapes remain, up to isomorphism preserving \(U\mid W\):

| \(r\) | Exterior graph \(K\) | Degrees on \(W\) |
|---:|---|---|
| 4 | each edge of a five-vertex path on \(W\) subdivided once by a vertex of \(U\) | \(2,2,2,1,1\) |
| 4 | each edge of the five-vertex fork on \(W\), of degrees \(3,2,1,1,1\), subdivided once | \(3,2,1,1,1\) |
| 3 | a four-cycle on \(U\), each edge subdivided by a vertex of \(W\), plus one \(W\)-leaf | \(2,2,2,2,1\) |
| 3 | a paw on \(U\) (triangle with pendant edge), each edge subdivided by a vertex of \(W\), plus one \(W\)-leaf attached at the paw's degree-one vertex | \(2,2,2,2,1\) |
| 3 | the graph \(K_0\) below, with its second \(W\)-leaf attached at \(u_1\) | \(3,2,2,1,1\) |
| 3 | the same \(K_0\), with its second \(W\)-leaf attached at \(u_4\) | \(3,2,2,1,1\) |

Here \(K_0\) has a degree-three \(W\)-vertex \(w_0\) adjacent to \(u_1,u_2,u_3\), two degree-two \(W\)-vertices \(w_1\sim\{u_1,u_4\}\) and \(w_2\sim\{u_2,u_4\}\), and one \(W\)-leaf at \(u_3\). The last table rows add a second \(W\)-leaf as specified. In the two \(r=4\) rows, the tree on \(W\) is the graph obtained by suppressing every degree-two vertex of \(U\).

**Proof of (1).** Each connected component of \(K\) has a nonempty \(U\)-part and \(W\)-part, since every vertex has positive degree. Applying strict Hall to the component's whole \(U\)-part gives at least one more \(W\)-vertex than \(U\)-vertex in that component. The total excess is \(|W|-|U|=1\), so \(K\) has exactly one component. Consequently
\[
\operatorname{rank}(K)=|E(K)|-(|U|+|W|)+1
=(3k-r)-(2k+1)+1=k-r.
\]

**Proof of the six-shape table.** Note 244 gives \(r\ge3\); because distinct vertices of \(U\) supply the \(r\) shore edges, \(r\le k=4\). If \(r=4\), every \(u\) has degree two in the connected tree \(K\). Suppressing \(U\) gives a tree on five vertices \(W\). Its maximum degree is three, so among the three five-vertex tree shapes the four-leaf star is excluded, leaving the path and fork.

If \(r=3\), the \(U\)-degrees are \((3,2,2,2)\), and the five positive \(W\)-degrees sum to nine. Their possible sequences are \((2,2,2,2,1)\), \((3,2,2,1,1)\), and \((3,3,1,1,1)\). The last is impossible: two degree-three vertices of \(W\) have three-element neighbourhoods in a four-element \(U\), so share at least two neighbours and make a four-cycle.

For \((2,2,2,2,1)\), replace each degree-two \(W\)-vertex by an edge between its two \(U\)-neighbours. The four edges are distinct by the four-cycle exclusion. If the remaining \(W\)-leaf meets the degree-three \(U\)-vertex, the projected degrees are \((2,2,2,2)\), giving a four-cycle. If it meets a degree-two \(U\)-vertex, the projected degrees are \((3,2,2,1)\), giving the unique paw. These are the third and fourth rows.

For \((3,2,2,1,1)\), call the degree-three vertex \(w_0\) and its neighbours \(u_1,u_2,u_3\); write \(u_4\) for the fourth \(U\)-vertex. Each degree-two \(W\)-vertex must meet \(u_4\) and one of \(u_1,u_2,u_3\), or it would share two neighbours with \(w_0\). Those other neighbours must be distinct; relabel them \(u_1,u_2\). Before adding the two leaves, \(U\)-degrees are \((2,2,1,2)\). At least one leaf must meet \(u_3\). If both meet \(u_3\), the set \(\{u_1,u_2,u_4\}\) has only \(\{w_0,w_1,w_2\}\) as neighbours, contradicting strict Hall. The remaining leaf therefore meets \(u_1\), \(u_2\), or \(u_4\); the first two are symmetric. This gives precisely the last two rows. Every listed shape satisfies strict Hall and the four-cycle exclusion, so the table is exact at the unmarked-quotient level. \(\square\)

In the \(r=3\) rows, exactly two exterior marks join \(W\) to \(C\), and Note 244 forces **both** to neighbour \(e\) in \(S\). In the \(r=4\) rows, exactly one exterior mark joins \(W\) to \(C\), and it must neighbour \(e\); the other three marks join pairs of \(W\). This is a classification of the *unmarked* exterior only. [Note 248](248-the-second-leaf-six-cycle-forces-an-overloaded-ec-row.md) subsequently excludes the last \(r=3\) row by its marked complete-matching closure. The remaining marked placements and shore matching relations still require decision. This note does not classify larger \(k\) or the other Tutte profiles. The analytic derivation has not received an independent model or implementation check.
