> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two shore marks need distinct singleton endpoints

Retain the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile of [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). Suppose exactly two exterior marks \(a,d\) join singleton vertices \(W\) to the odd shore \(C\). Note 244 forces \(ea,ed\in S\), so the other two marks \(b,c\) join pairs of singleton vertices. This note does not restrict \(|U|\) or the matching relation inside \(C\).

**Theorem.** The \(W\)-endpoints of \(a,d\) are distinct. Thus every \(r=3\) placement on any of [Note 245's](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md) four \(|U|=4\) unicyclic exterior shapes must place its two shore marks at different singleton vertices.

**Proof.** Suppose both marks meet the same singleton vertex \(w\). Choose an actual \((ea)(t)\) row with \(t\in T\), and let its \(S\)-half \(D\) be decomposed in state \(ea\):
\[
D=X_a+Y_a+Z_e,
\qquad \partial X_a=\{b,c,d\},\quad
\partial Y_a=\{a\},\quad\partial Z_e=\{e\}.           \tag{1}
\]
The opposite \(T\)-half makes \(D\) pure \(S\). By [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(X_a\) uses no proper shore port, so it selects \(a:w\). The \(a\)-terminal path of \(X_a\triangle Y_a\) must end at \(d\), the other \(S\)-neighbour of \(e\). As in Note 244, this path stays wholly exterior. At \(w\), its only way to reach terminal \(d\) is through \(Y_a\)'s half \(d:w\): if it left \(w\) through an unmarked edge, \(Y_a\) would already occupy \(w\), so the path could never use \(d:w\), and it cannot reach the shore half \(d:C\). Hence the path is exactly \(a-t_a-w-t_d-d\).

Switch that path. The resulting state-\(ed\) triple \(X_d\) has the same complete shore matching as \(X_a\), the same unmarked exterior matching of \(K-w\), and only replaces \(a:w\) by \(d:w\). The singleton-\(e\) matching \(Z_e\) is fixed. In the two possible allowed orders, \(S=e-a-b-c-d-e\) or \(S=e-a-c-b-d-e\), purity requires the \(e\)-path in \(X_a\triangle Z_e\) and \(X_d\triangle Z_e\) to end at \(b,c\) in opposite orders.

Inspect only the three edges incident with \(w\) in \(Z_e\). If \(Z_e\) selects \(a:w\) or \(d:w\), neither symmetric difference has an unmarked edge incident with \(w\) from its triple matching, and every route from \(b\) or \(c\) to a shore port is unchanged by the switch. It cannot exchange the \(e\)-path endpoint \(b\leftrightarrow c\).

Otherwise \(Z_e\) selects both \(a:C,d:C\) and matches \(w\) through one unmarked edge. The switch changes only the port at the end of the route through \(w\): it is \(a:C\) against \(X_a\) and \(d:C\) against \(X_d\). Every other terminal-to-port route is unchanged. The fixed shore pairing of the \(e\)-port cannot use \(a:C\), because \(X_d\) has terminal \(a\) joined directly to that port, giving the forbidden state \(ad\); it cannot use \(d:C\) for the symmetric reason against \(X_a\). If it uses any other port, its exterior terminal endpoint is unchanged. Again it cannot change from \(b\) to \(c\). This contradicts purity in both cyclic orders. \(\square\)

The obstruction is a one-half matching-level statement: it needs one genuine \(S\)--\(T\) row for purity, but does not need a second BF row or an assumption that distinct shore matchings agree. It rules out coincident \(W\)-endpoints when \(r=3\); it does not rule out distinct endpoints, \(r=4,5\), larger barriers, or the other Tutte profiles. The analytic proof has not received an independent model or implementation check.
