> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The one-B-port near-bipartite core profile is not exact Case XII

Continue the real central-path exterior and unmarked-core bipartization of [Note 287](287-unmarked-near-bipartite-central-cores-force-s-tait.md). Let \(g\) join two \(B\)-vertices of the bipartite graph \(C-g\), let the internal marked edge run from \(v\in B\) to \(w\in R\), and use shore ports \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\). Assume the full exact-Case-XII support and both forced real cross rows of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with allowed pentagon \(S=e-a-b-d-c-e\).

**Theorem.** In the \(3{:}2\) cut profile, the subcase where exactly one of \(A,I,D\) is based in \(B\) is **impossible**. Thus an exact-Case-XII pole in the remaining central-path geometry whose unmarked core becomes bipartite after deletion of one edge must have either [Note 282's](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md) \(4+1\) profile or the \(3{:}2\) profile with exactly **two** of \(A,I,D\) based in \(B\). Both surviving numerical profiles are \(S\)-Tait by Notes 282 and 286; their realizability and four-slot load intersection are not decided here.

## A singleton-c obstruction

In the one-\(B\)-port subcase, \(H,J\in B\) and the two \(R\)-based cut edges form
\[
R_0\in\{AI,ID,AD\}.                                      \tag{1}
\]
The full pole minus \(g,t_ew,R_0\) is bipartite. Align its exterior as in [Note 283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md): the four exterior marked subdivision vertices and \(t_e\) all lie in \(R\). Thus **all five terminal vertices lie in \(R\)**.

Suppose there is an actual full-pole singleton-\(c\) perfect matching \(M_c\) selecting \(g,t_ev\) and both cut edges of \(R_0\). Its complement avoids \(g,R_0\). The only remaining same-side edge is \(t_ew\), and it lies on the open path from terminal \(e\), because the complement at \(t_e\) uses the terminal semiedge \(e\) and \(t_ew\). All closed cycles are therefore even, so \(M_c\) extends to a Tait colouring.

The path from \(e\) joins two \(R\)-side terminal vertices and contains exactly one same-side proper edge, \(t_ew\). It has an odd number of proper edges, so its two terminal semiedges receive the **same** complementary colour. The other open path joins the remaining two \(R\)-side terminals, uses only bipartite edges, and has differently coloured ends. Switching its two colours makes each of its endpoints, in turn, the second lonely terminal alongside \(c\). Since terminal \(e\) is on the same-colour path, neither of these two Tait states is \(ce\). But the allowed pentagon has only two states incident to \(c\), namely \(cd,ce\). At least one of the two actual colourings therefore has a \(T\)-state; doubling it gives a forbidden \(T\)-loop. **No such \(M_c\) can exist in an exact-Case-XII pole.**

## All three cut pairs force that singleton

For \(R_0=AI\), take the shore restriction of the singleton-\(d\) occurrence \(W_d\) in the required \((ea)(ad)\) row. Its shore ports are \(A,I\). Both ports lie in \(R\), so [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) forces this actual shore matching to select \(t_ev,g\). Glue it to the independent singleton-\(c\) exterior mask in the first row of the table below.

For \(R_0=ID\), the singleton-\(c\) occurrence \(W_c\) in the required \((ea)(ac)\) row already has ports \(I,D\). Balance forces it to select \(t_ev,g\), so it is the forbidden \(M_c\) directly.

For \(R_0=AD\), [Note 287's pure-path switch](287-unmarked-near-bipartite-central-cores-force-s-tait.md) constructs an actual shore matching \(N_{AD}\) with ports \(A,D\) and selected edges \(t_ev,g\). Glue it to the independent singleton-\(c\) exterior mask in the third row:
\[
\begin{array}{c|l}
\text{shore ports}&\text{selected exterior edges, including the terminal }c\\\hline
AI&c_{\rm term},\ a:\Sigma,\ b:A_{\rm ext},\ d:E_{\rm ext},\
       2B_{\rm ext},\ 3C_{\rm ext},\ 4D_{\rm ext},\ h_1\\
ID&c_{\rm term},\ a:C_{\rm ext},\ b:A_{\rm ext},\ d:B_{\rm ext},\
       3D_{\rm ext},\ 4E_{\rm ext},\ h_1,\ h_2\\
AD&c_{\rm term},\ a:\Sigma,\ b:A_{\rm ext},\ d:E_{\rm ext},\
       1B_{\rm ext},\ 3C_{\rm ext},\ 4D_{\rm ext},\ h_2.
\end{array}                                                   \tag{2}
\]
Each row is an exterior perfect matching with exactly the displayed two shore interfaces. For \(AI,ID,AD\), respectively, the four vertices \(u_1,u_2,u_3,u_4\) are covered by
\[
(h_1,2B,3C,4D),\quad(h_1,h_2,3D,4E),\quad(1B,h_2,3C,4D),
\]
and the five path vertices \(A_{\rm ext},B_{\rm ext},C_{\rm ext},D_{\rm ext},E_{\rm ext}\) are covered in order by
\[
(b:A,2B,3C,4D,d:E),\quad(b:A,d:B,a:C,3D,4E),
\quad(b:A,1B,3C,4D,d:E).
\]
The marked subdivision vertices \(t_a,t_b,t_c,t_d\) are covered once in each row by the displayed \(a\)-edge, \(b\)-edge, terminal \(c\), and \(d\)-edge. Thus every mask in (2) is checked vertex by vertex. Gluing to the stated shore matching produces the forbidden complete \(M_c\) in all three cases, a contradiction. \(\square\)

The contradiction uses complete graph-induced matching closure in the \(AI,AD\) cases and an actual designated row in the \(ID\) case. It excludes a numerical profile under the forced central-path templates; it does not construct or rule out a genuine exact-Case-XII pole in the remaining \(4+1\), two-\(B\)-port, or general high-rank profiles, and it does not prove Berge–Fulkerson. No graph census or local bulk computation was used.
