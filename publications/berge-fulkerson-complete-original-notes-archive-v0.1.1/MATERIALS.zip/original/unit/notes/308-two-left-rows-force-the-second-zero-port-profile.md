> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two left rows force the second zero-port profile

Consider the complete exact-Case-XII central-path five-pole with the
left \((ea)(ac)\) row of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md)
and a **left** \((ea)(ad)\) row of [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md).
Assume the \(3{:}2\) one-edge-near-bipartite shore profile of
[Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md),
with \(q=D\) and one \(r\in\{H,J\}\) based in \(R\), and the other three proper
ports based in \(B\). The internal marked edge has halves
\(t_{ev}\) and \(t_{ew}\), where \(v\in B,w\in R\); \(g\subset B\).

**Theorem.** The complete shore matching fibre with no proper ports
contains an actual matching selecting both \(g\) and \(t_{ew}\).
This holds for either \(r=H\) or \(r=J\), without a Hall-set size
assumption. Consequently the pole has an allowed \(S\)-Tait colouring
by [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md).

**Proof.** The left \(ac\) row has a singleton-\(a\) shore matching
\(L\) with proper ports \(HJ\) and \(g,t_{ew}\) selected, by
[Note 290's row-load calculation](290-two-port-closure-separates-the-remaining-three-two-row-loads.md).
The left \(ad\) row has an opposite triple shore matching \(U\)
selecting \(E,D,g\): its proper port \(D\) is \(R\)-based, so
[Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md)
forces \(g\) when terminal \(E\) is selected. These are matchings of
the *same* six-pole, although they belong to different BF rows.

The shore symmetric difference \(L\triangle U\) has four open ends
\(E,D,H,J\). The edge \(g\) is common to both matchings and hence
absent from the difference. Since \(U\) selects \(E\) at the marked
subdivision vertex and \(L\) selects \(t_{ew}\), their
\(E\)-starting path contains \(t_{ew}\). Its other open path avoids
both \(g,t_{ew}\).

If the \(E\)-path ends at \(H\), switch the separate \(D\)--\(J\)
path into \(L\). This gives a two-proper-port shore matching with
ports \(DH\), selecting \(g,t_{ew}\). If the \(E\)-path ends at \(J\),
the separate \(D\)--\(H\) path similarly gives ports \(DJ\) and
selects \(g,t_{ew}\). Both violate [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md):
under \(q=D\), the complete two-proper-port \((g,t_{ew})\) fibre has
only port set \(HJ\). Therefore the paths pair \(ED\mid HJ\).
Switch their \(H\)--\(J\) path into \(L\). Both selected proper
ports disappear, while \(g,t_{ew}\) remain selected. This is the
claimed zero-port matching. \(\square\)

**Forced exchange with the left four-port slot.** Let \(X_1\) be
the zero-port matching just obtained and let \(Z\) be the left-row
four-port matching with ports \(EAID\), selecting \(E\) and avoiding
\(g\). Then the paths of \(X_1\triangle Z\) pair
\[
                         \boxed{ED\mid AI},                 \tag{1}
\]
with \(t_{ew}\) on the \(E\)--\(D\) path and \(g\) on the
\(A\)--\(I\) path. Indeed, \(t_{ew}\) is on the \(E\)-path, and
\(g\) cannot lie on an alternating closed cycle by bipartite
parity. For pairing \(EA\mid ID\), putting \(g\) on the \(EA\)
path gives the forbidden \(ID,g,t_{ew}\) fibre by switching the
other path into \(X_1\); putting it on \(ID\) gives an impossible
\(ID,t_{ew},g\notin M\) matching by switching the \(EA\) path
into \(Z\). The same two arguments for \(EI\mid AD\) give the
forbidden \(AD,g,t_{ew}\) fibre or the impossible
\(AD,t_{ew},g\notin M\) profile. Finally, if \(g\) lay on the
\(ED\) path of (1), switching \(AI\) into \(X_1\) would give an
\(AI,g,t_{ew}\) matching, contrary to balance because both \(A,I\)
are \(B\)-based. Thus \(g\) lies on \(AI\). Switching these two
paths separately yields actual \(ED,E,g\) and
\(AI,t_{ew},g\notin M\) shore matchings; they need not be the
specific occurrences in the left \(ad\) row.

The new witness strengthens the earlier conclusion that this
near-bipartite branch is \(S\)-Tait: it gives an exact matching in a
previously unrestricted full fibre. It does not align the two rows'
remaining complete masks, produce a right \(ad\) row, eliminate a
multivertex Hall obstruction, or settle exact Case XII. The proof is
hand-derived and uses the upstream complete-fibre exclusions, which
still await independent second-source verification.
