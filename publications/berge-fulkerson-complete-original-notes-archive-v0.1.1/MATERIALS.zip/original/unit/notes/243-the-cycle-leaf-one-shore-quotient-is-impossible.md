> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The cycle--leaf one-shore quotient is impossible

Retain the minimum-host, complete exact-Case-XII, one-internal-mark profile with \(|U|=3\) and the cycle--leaf quotient of [Notes 236](236-girth-five-leaves-four-marked-exterior-quotients-at-the-first-barrier.md) and [239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md). Its unmarked exterior is the six-cycle \(u_1-x-u_2-q-u_3-z-u_1\) with pendant edge \(pu_1\) and shore edges \(h_2=u_2C,h_3=u_3C\). The exterior marks are \(a:p-C\), \(b:p-q\), \(c:x-C\), \(d:z-C\); \(e\) is internal to \(C\). Write \(a:C,c:C,d:C\) for the shore halves of those marks, and put
\[
\alpha=\{u_1x,u_2q,u_3z\},\qquad
\beta=\{u_1z,u_2x,u_3q\}.
\]

**Theorem.** No marked cycle--leaf quotient as above has complete exact-Case-XII perfect-matching support, at any order or cycle rank of \(C\). The new obstruction excludes \(\{a,b\}\) as the two neighbours of \(e\). For \(\{b,c\}\), every hypothetical pure-\(S\) half-load would have the cyclic order
\[
\boxed{S=e-c-d-a-b-e}                                      \tag{1}
\]
and, in its state-\(ec\) decomposition \(D=X_c+Y_c+Z_e\), the following *entire exterior restrictions*:
\[
\begin{array}{c|l}
X_c&c:x,\ pu_1,\ u_2q,\ u_3z\\
Y_c&b:p,\ u_2x,\ u_3q,\ u_1z,\ a:C,\ d:C\\
Z_e&a:p,\ b:q,\ c:C,\ d:z,\ u_1x,\ h_2,\ h_3.
\end{array}                                                   \tag{2}
\]
Each proper exterior edge has load exactly one in \(D\). Reflection exchanges \(c,x,u_2,h_2\) with \(d,z,u_3,h_3\), giving the corresponding statement for \(\{b,d\}\). A whole-matching exchange in a required \((ec)(ea)\) row rules out (1)--(2) as well. Together with [Notes 237](237-the-cycle-leaf-connector-excludes-the-two-cycle-shore-e-neighbours.md) and [242](242-the-first-one-shore-barrier-needs-an-exterior-cross-mark-next-to-e.md), this eliminates every neighbour pair in the cycle--leaf quotient.

## A fixed-shore pairing test

Take the \(S\)-half \(D\) of an actual \(S\)--\(T\) row. It is pure \(S\): a \(T\)-decomposition paired with the fixed opposite \(T\)-half would give a forbidden \(T\)--\(T\) row. [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) therefore gives \(\mathcal R(D)=S\). In a state incident with \(e\), [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes the triple matching zero-port. The alternating terminal path to the other \(e\)-neighbour stays entirely exterior in this quotient: it alternates through the unmarked \(K\)-edges, while a marked half-edge at \(p,q,x,z\) ends at its triple-colour terminal. Switching this path leaves the triple's *complete* mask on \(C\cup\{t_e\}\) unchanged.

Fix the singleton-\(e\) matching \(Z_e\) during that switch. The zero-port triple and \(Z_e\) pair the shore \(e\)-port with the **same** proper shore port before and after it. If a mark \(j\) remains a triple terminal in both states and \(Z_e\) uses \(j:C\), then the external route from \(j\) reaches \(j:C\) directly in both states. Thus an \(e\)-path that must change its terminal endpoint from \(j\) to another unchanged triple terminal cannot use \(j:C\). This is a statement about the same actual half-load and the same complete shore masks; no equality between different BF rows is assumed.

## The pair \(\{a,b\}\) is impossible

Decompose \(D=X_a+Y_a+Z_e\) at \(ea\). The triple selects \(a:p\) and then either \(\alpha\) or \(\beta\) on \(K-p\). Its alternating path with \(Y_a\) must go from \(a\) to \(b\), since \(eb\) is the other allowed state incident with \(e\). The path is either \(a-p-b\), \(a-p-u_1-x-u_2-q-b\) when \(X_a\) uses \(\alpha\), or \(a-p-u_1-z-u_3-q-b\) when it uses \(\beta\). The switched state-\(eb\) triple \(X_b\) therefore has one of the three exterior masks \(b:p+\alpha\), \(b:p+\beta\), or \(b:q+\{pu_1,u_2x,u_3z\}\), and has the same complete shore mask as \(X_a\).

The two possible orders are \(e-a-c-d-b-e\) and \(e-a-d-c-b-e\). In the first, the \(e\)-path in \(X_a\triangle Z_e\) must end at \(c\), and in \(X_b\triangle Z_e\) at \(d\). In the second, these endpoints are \(d,c\). Since \(c,d\) are triple terminals in both states, the fixed-shore test rules out both \(c:C,d:C\) from \(Z_e\). Its three proper shore ports must therefore be \(a:C,h_2,h_3\). Perfect matching of the remaining exterior vertices now uniquely forces
\[
Z_e:\quad a:C,\ h_2,\ h_3,\ b:q,\ c:x,\ d:z,\ pu_1.       \tag{3}
\]
The terminal-to-port routes of the two triple--\(Z_e\) differences are:
\[
\begin{array}{c|ccc}
&\text{first terminal}&\text{second terminal}&\text{third terminal}\\\hline
X_a(\alpha)&b\mapsto h_2&c\mapsto a:C&d\mapsto h_3\\
X_a(\beta)&b\mapsto h_3&c\mapsto h_2&d\mapsto a:C\\
X_b\text{ (any of its three masks)}&a\mapsto a:C&c\mapsto h_2&d\mapsto h_3.
\end{array}                                                   \tag{4}
\]
For \(e-a-c-d-b-e\), the required common \(e\)-port would have to be both the \(c\)-route of \(X_a\) (\(a:C\) or \(h_2\)) and the \(d\)-route of \(X_b\) (\(h_3\)). For \(e-a-d-c-b-e\), it would have to be both the \(d\)-route of \(X_a\) (\(h_3\) or \(a:C\)) and the \(c\)-route of \(X_b\) (\(h_2\)). Neither is possible. Hence no pure-\(S\) half-load, and therefore no exact-Case-XII support, has the pair \(\{a,b\}\).

## The pair \(\{b,c\}\) has one phase

Decompose \(D=X_c+Y_c+Z_e\) at \(ec\). Its zero-port triple has the unique exterior \(c:x,pu_1,u_2q,u_3z\). The \(c\)--\(b\) path of \(X_c\triangle Y_c\) is one of
\[
c-x-u_1-p-b,\quad
c-x-u_2-q-b,\quad
c-x-u_2-q-u_3-z-u_1-p-b.                           \tag{5}
\]
Switching yields a state-\(eb\) triple \(X_b\) with exterior \(b:p+\alpha\), \(b:q+\{pu_1,u_2x,u_3z\}\), or \(b:p+\beta\), respectively. The unchanged triple terminals are \(a,d\). In either possible order \(e-c-a-d-b-e\) or \(e-c-d-a-b-e\), the required \(e\)-path endpoint changes between \(a\) and \(d\). The fixed-shore test rules out \(a:C,d:C\) from \(Z_e\), leaving the unique exterior matching
\[
Z_e:\quad c:C,\ h_2,\ h_3,\ a:p,\ b:q,\ d:z,\ u_1x.       \tag{6}
\]
The resulting routes are
\[
\begin{array}{c|ccc}
X_c&a\mapsto c:C&b\mapsto h_2&d\mapsto h_3\\
X_b(b:p+\alpha)&a\mapsto h_2&c\mapsto c:C&d\mapsto h_3\\
X_b(b:q+\{pu_1,u_2x,u_3z\})&a\mapsto h_2&c\mapsto c:C&d\mapsto h_3\\
X_b(b:p+\beta)&a\mapsto h_3&c\mapsto c:C&d\mapsto h_2.
\end{array}                                                   \tag{7}
\]
The first order would require \(a\)'s route from \(X_c\), namely \(c:C\), to equal \(d\)'s route from \(X_b\), which is \(h_3\) or \(h_2\). It is impossible. The second order requires \(d\)'s route \(h_3\) from \(X_c\) to equal \(a\)'s route from \(X_b\). Only the third line of (5), which gives \(X_b=b:p+\beta\), survives. Its \(Y_c\) edges along that winding path are \(u_2x,u_3q,u_1z,b:p\); its two shore ports are forced to be \(a:C,d:C\). Together with (6) and \(X_c\), these are exactly (2), and they partition every proper exterior edge.

## Complete closure excludes the last phase

In the order (1), \(ec\in S\) and \(ea\in T\). The [published Case-XII type table, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual \((ec)(ea)\) BF row. Write its two three-matching halves as
\[
D=X_c+Y_c+Z_e,\qquad E=U_{ea}+V_a+W_e,
\qquad D+E=2\mathbf1.                                    \tag{8}
\]
Because \(E\) has a \(T\)-state, exact negative support makes \(D\) pure \(S\). Equations (1)--(2) apply, so \(D\) and therefore \(E\) each have load one on every proper exterior edge, including \(a:p\). By Note 230, the state-\(ea\) triple \(U_{ea}\) is zero-port; its active mark \(a\) must select \(a:p\). Thus \(W_e\) cannot use \(a:p\).

Exchange the **complete** singleton-\(e\) matchings \(Z_e,W_e\) between the two halves. This preserves all six perfect matchings, their terminal patterns, and every edge's total load. The new opposite half \(U_{ea}+V_a+Z_e\) still has state \(ea\in T\). Exact negative support therefore forces the new half \(X_c+Y_c+W_e\) to be pure \(S\). But (2) applies to *every* pure-\(S\) half in this placement and forces its singleton-\(e\) matching \(W_e\) to use \(a:p\), a contradiction. The pair \(\{b,c\}\), and by reflection \(\{b,d\}\), is impossible. The other three neighbour-pair orbits were excluded above and in Notes 237 and 242, proving the theorem. \(\square\)

This is a full-perfect-matching-closure argument: it exchanges actual matching identities across a genuine six-matching row. It does not assume any relation between different shore masks. [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md) subsequently abstracts the unused-shore-mark exchange, subsumes this quotient exclusion, and combines with the tree-quotient results to exclude every \(|U|=3\) one-shore barrier. Larger barriers, the other [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) profiles, and the Berge--Fulkerson conjecture remain open. The analytic chain has not received an independent model or implementation check.
