> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The surviving prism row has a sharp \(K\)--\(e\) path condition

Fix the sole surviving exterior table (5) of [Note 415](415-the-adjacent-bc-cc-second-direct-root-has-one-real-exterior-boundary.md), for forbidden \(e\)-labels \(\{bc,Cc\}\) and allowed pentagon
\[
S=e-ab-bc-Cc-AC-e.
\]
Write \(P=e\,bc:c\) for its forbidden triple, \(R=e\,ab:a\) for its allowed triple, \(K\) for singleton-\(ab\), and \(E,F\) for its two singleton-\(e\) occurrences. All statements below concern **complete** perfect matchings on an arbitrary shore; only the exterior mask is fixed.

> **Exact path condition and sharp rowwise boundary.** Exact Case-XII support forces the \(e\)--\(ab\) path of \(K\triangle F\) to traverse all three of its exterior components. The \(e\)--\(ab\) path of \(K\triangle E\) cannot traverse its \(p_1p_5\) exterior component without also traversing its \(p_2p_4\) component. In fact the stronger \(F\)-condition applies to each pairing of a singleton-\(ab\) shore mask with a singleton-\(e\) shore mask in this row, after independent exterior exchanges. Two actual 21-vertex BF rows attain respectively all three and none of the proper exterior arms in \(K\triangle E\); both have the forbidden \([e\,bc]\) loop and are not exact Case XII.

**The two exterior decompositions.** Direct tracing of Note 415's table gives
\[
\begin{array}{c|ccc}
 &\text{terminal arm}&\text{first proper arm}&\text{second proper arm}\\\hline
K\triangle E&ab\,p_3&p_1p_5&p_2p_4\\
K\triangle F&ab\,p_1&p_3p_5&p_2p_4.
\end{array}                                                     \tag{1}
\]
For \(K\triangle E\), the three exterior paths are
\[
ab-t_{ab}-a-u_3-p_3,\quad
p_1-u_1-A-t_{AC}-C-t_{Cc}-c-u_5-p_5,\quad
p_2-u_2-B-u_4-p_4.                                     \tag{2}
\]
For \(K\triangle F\), they are
\[
\begin{split}
&ab-t_{ab}-b-t_{bc}-c-t_{Cc}-C-t_{AC}-A-u_1-p_1,\\
&p_3-u_3-a-u_5-p_5,\qquad p_2-u_2-B-u_4-p_4.
\end{split}                                                     \tag{3}
\]
The shore symmetric difference pairs its six ports \(e,p_1,\ldots,p_5\) into three paths, possibly with closed alternating cycles. Gluing those paths to (1) gives one complete \(e\)--\(ab\) path. We switch only this complete path, leaving all other components and the four other matching occurrences unchanged.

**Forbidden partial switches.** After switching \(K\triangle E\), the occurrence formerly called \(E\) becomes singleton-\(ab\). It always acquires the \(ab\,p_3\) arm of \(K\). Let \(x,y\in\{0,1\}\) say whether the same terminal path also traverses \(p_1p_5,p_2p_4\), respectively. If \(x=1,y=0\), its exterior now takes \(au_3,Au_1,Bu_4,bc:b\). Its \(ab\)-starting path against the unchanged \(R\) is wholly exterior:
\[
ab-t_{ab}-a-u_3-A-u_1-B-u_4-b-t_{bc}-bc.          \tag{4}
\]
Switching (4) changes \(R=e\,ab\) to forbidden \(e\,bc\), while \(P=e\,bc\) remains forbidden. The other three \((x,y)\) combinations send that \(ab\)-path to allowed \(AC\): directly through \(A-t_{AC}\) when \(x=0\), and through \(B-u_2-C-t_{AC}\) when \(x=y=1\). Thus exact support requires \(x\le y\).

After switching \(K\triangle F\), the occurrence formerly called \(F\) also becomes singleton-\(ab\) and acquires the \(ab\,p_1\) arm of \(K\). Let \(x,y\) indicate inclusion of \(p_3p_5,p_2p_4\), respectively. If \(x=0\), it retains \(au_5,Cc:c\), and the \(ab\)-starting path against \(R\) is
\[
ab-t_{ab}-a-u_5-c-t_{Cc}-Cc,                         \tag{5}
\]
giving forbidden \(e\,Cc\) alongside unchanged forbidden \(P=e\,bc\). If \(x=1,y=0\), the path instead follows (4), giving another forbidden \(e\,bc\). Only \(x=y=1\) reaches allowed \(AC\) through \(B-u_2-C-t_{AC}\). Therefore exact support forces the \(K\triangle F\) terminal path to traverse **both** proper-port arms of (1).

The row has two independent exterior exchanges. The \(K\triangle J\) exterior difference is the \(ab\)--\(bc\) path \(ab-t_{ab}-b-t_{bc}-bc\); switching it exchanges which of the two shore masks carries the singleton-\(ab\) exterior. The \(E\triangle F\) exterior difference is the six-cycle \(a-t_{ab}-b-t_{bc}-c-u_5-a\); switching it exchanges which singleton-\(e\) shore mask carries the \(F\) exterior. Both exchanges leave every edge load equal to two. Consequently, if \(U_K,U_J\) denote the shore masks of \(K,J\), and \(V_E,V_F\) those of \(E,F\), then for **each** \(U\in\{U_K,U_J\}\) and \(V\in\{V_E,V_F\}\), the shore pairing of \(U\triangle V\), glued to \(abp_1\mid p_3p_5\mid p_2p_4\), must put all three exterior arms on the \(e\)--\(ab\) path. This four-pair condition is necessary for exact support. It forbids a shore \(p_2p_4\) pair in any of the four differences. The \(K\triangle E\) bad case \(x=1,y=0\) would require just such a shore pair, so its weaker restriction follows from this four-pair condition.

The same argument applies to the entire cycle-phase fibres, not just these four endpoints. Let \(\mathcal U\) contain all shore masks obtained by independently switching the closed components of \(U_K\triangle U_J\), and let \(\mathcal V\) be defined similarly from \(V_E\triangle V_F\). Each cycle switch exchanges edges between the two matchings of its pair and preserves their combined load. The two exterior exchanges above then put the \(K\) exterior on any selected \(U\in\mathcal U\) and the \(F\) exterior on any selected \(V\in\mathcal V\), in one actual BF row. Therefore exact support requires the all-three-arm path condition for **every** \((U,V)\in\mathcal U\times\mathcal V\). The four-pair condition is its smallest visible part.

For a single pair of shore masks, the condition permits exactly eight port pairings: the \(e\)--\(ab\) path may meet the \(p_3p_5\) and \(p_2p_4\) arms in either order, and each arm may be traversed in either direction. Among these eight pairings, the corresponding \(K\triangle E\) path uses zero, one, or two proper exterior arms in respectively two, two, or four cases. This is a finite pairing classification, not an existence claim for all eight pairings on a given shore.

**The four \(e\)-mixed cells are one rectangle.** In the original table, \(P\triangle J\) contains the wholly exterior path
\[
bc-t_{bc}-c-t_{Cc}-Cc,
\]
which changes \(P=e\,bc:c\) into \(P'=e\,Cc:c\) and \(J=bc\) into singleton-\(Cc\). Independently, the wholly exterior path (4) of Note 415 in \(R\triangle K\) changes \(R=e\,ab:a\) into \(R'=e\,AC:C\) and \(K=ab\) into singleton-\(AC\). The two switches act on disjoint pairs of complete matching occurrences and leave every shore mask unchanged. Their four choices therefore realize, from any one row with the exterior table (5), all four actual mixed cells
\[
(e\,bc)(e\,ab),\quad(e\,bc)(e\,AC),\quad
(e\,Cc)(e\,ab),\quad(e\,Cc)(e\,AC).
\]
Under \(S\), the first triple state of each cell lies in \(T\), and the second lies in \(S\). Thus these other three required \(e\)-mixed cells impose no separate existence test on this exterior table. A contradiction must use their joint matching identities, a cell outside this rectangle, or a negative-support consequence.

**A real row attaining both restrictions.** Take a six-cycle shore whose cyclic port order is
\[
e,p_2,p_1,p_3,p_4,p_5.
\]
Write \(h_e,h_2,h_1,h_3,h_4,h_5\) for its vertices in that order, each incident with the indicated port. Attach its five proper ports to \(u_1,\ldots,u_5\). Use Note 415's exterior table and the following complete shore matchings:
\[
\begin{array}{c|l}
P,R&Q=\{h_2h_1,h_3h_4,h_5h_e\}\\
K,J&L=\{h_eh_2,h_1h_3\}\ \text{and ports }p_4,p_5\\
E,F&N=\{h_4h_5\}\ \text{and ports }e,p_1,p_2,p_3.
\end{array}                                                     \tag{6}
\]
Each shore edge and each port is used by exactly two occurrences, so (6) and the exterior table are six complete perfect matchings forming the required real BF row. The \(K\triangle E\) and \(K\triangle F\) shore differences both pair ports as
\[
ep_2\mid p_1p_3\mid p_4p_5.                              \tag{7}
\]
Together with (1), each \(e\)--\(ab\) path visits **all three** exterior components. In fact each complete symmetric difference consists of this single path, so either switch merely exchanges the two complete matching occurrences. The direct two-switch attack (4)–(5) gives no forbidden type here.

The pole has 21 vertices and girth five by the same edge-distance argument as in Note 415; the path \(h_1-u_1-B-u_2-h_2-h_1\) is a five-cycle. It is still not exact Case XII: the complement of \(Q\) has shore pairing (7), while the exterior complement of \(P=e\,bc:c\) pairs \(bc\,p_3\mid p_1p_5\mid p_2p_4\). These six paths concatenate to one spanning \(e\)--\(bc\) path. Alternating its edges and doubling the resulting two singleton matchings with \(P\) gives forbidden \([e\,bc]\). Thus the conditions above are necessary but cannot by themselves eliminate Note 415's surviving exterior table. \(\square\)

This first row does not meet the earlier \(R\triangle E\) selector: its shore \(e\)-path reaches \(p_3\), whereas [Note 415](415-the-adjacent-bc-cc-second-direct-root-has-one-real-exterior-boundary.md) requires \(p_1\) under \(S\). The following second row meets that selector and shows that the \(K\triangle E\) path need not traverse either proper exterior arm even after the selector is imposed. Put the shore vertices in cyclic port order
\[
e,p_1,p_2,p_4,p_5,p_3
\]
and use the same exterior table (5) of Note 415, but take
\[
\begin{array}{c|l}
P,R&Q'=\{h_eh_1,h_2h_4,h_5h_3\}\\
K,J&L'=\{h_eh_3,h_1h_2\}\ \text{and ports }p_4,p_5\\
E,F&N'=\{h_4h_5\}\ \text{and ports }e,p_1,p_2,p_3.
\end{array}                                                     \tag{8}
\]
The six shore edges are partitioned by \(Q',L',N'\); each is used by two occurrences. Every port has load two, so (8) is another complete BF row. Here \(K\triangle E\) and \(K\triangle F\) have shore pairing \(ep_3\mid p_1p_2\mid p_4p_5\). For \(K\triangle E\), the \(e\)--\(ab\) path uses only \(abp_3\), giving \(x=y=0\) in (4); for \(K\triangle F\), it traverses all three arms of (3). The shore \(e\)-path in \(R\triangle E\) and \(R\triangle F\) is \(ep_1\), as required: by Note 415's exterior table it reaches \(bc\) from \(R=e\,ab\) and \(Cc\) from its switched \(R'=e\,AC\). The same \(ep_1\) path in \(P\triangle E\) and \(P\triangle F\) reaches \(ab\), an allowed neighbour of \(bc\) in \(S\).

This second pole also has 21 vertices and girth five: the exterior and shore have girth at least six, and any mixed cycle uses two port edges, at least two exterior edges and at least one shore edge. The cycle \(h_2-u_2-B-u_4-h_4-h_2\) has length five. Its shore complement of \(Q'\) pairs \(ep_3\mid p_1p_2\mid p_4p_5\). Gluing to the exterior complement of \(P\) gives exactly the following spanning pair of components:
\[
\begin{split}
&e-h_e-h_3-u_3-a-t_{ab}-b-t_{bc}-bc,\\
&h_1-h_2-u_2-B-u_4-h_4-h_5-u_5-c-t_{Cc}-C-t_{AC}-A-u_1-h_1.
\end{split}                                                     \tag{9}
\]
The first is an eight-edge \(e\)--\(bc\) path; the second is an even fourteen-edge cycle. Alternating both components yields singleton-\(e\) and singleton-\(bc\) matchings; doubling them and \(P\) again gives the forbidden \([e\,bc]\) loop. Thus even the four-pair path gate together with these immediate \(e\)-selectors does not supply exact support.

The forbidden loop holds for **every** six-cycle shore row of this duplicated-mask form, regardless of the cyclic port order. Its unused \(Q\)-edges pair the six ports into three paths of length three, one necessarily \(p_4p_5\) because \(E,F\) both use the other four ports. In the exterior complement of \(P\), the two proper paths have even lengths eight and four and pair \(p_1p_5\) and \(p_2p_4\). Neither equals \(p_4p_5\). A closed complementary component therefore cannot use just one proper exterior path; if present, it uses both, together with two length-three shore paths. After identifying the four shared port edges its length is even. All other complementary edges form the \(e\)--\(bc\) path, so the complement of \(P\) always splits into two singleton perfect matchings and yields \([e\,bc]\). This closes the six-cycle duplicated-mask subclass, not arbitrary larger shores or distinct shore masks.

There is also a distinct-mask, all-odd version of the second row. Replace its shore vertex \(h_1\) by the Petersen three-pole \(P_{10}-v_0\) of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md), attaching the old \(h_eh_1,h_1h_2,p_1\) edges to \(v_1,v_4,u_0\), respectively. Insert the six restricted Petersen matchings
\[
(P,R,K,J,E,F)=(M_2,M_4,M_1,M_3,M_\infty,M_0).
\]
The three attachment edges then carry precisely the pairs \(\{P,R\},\{K,J\},\{E,F\}\), so all loads remain two. The replacement changes no terminal boundary type by Note 381's support-neutrality theorem. In particular, the old \([e\,bc]\) cover has its two copies of \(P\) on \(h_eh_1\), and the two doubled singleton classes split \(h_1h_2,p_1\); splice the Petersen pairs \((M_2,M_4),(M_1,M_3),(M_\infty,M_0)\) onto these three edge pairs to lift that forbidden cover explicitly. The replacement also preserves all displayed shore port pairings: for a symmetric difference between matchings using different attachments, the gadget connects those attachments by one alternating path, while any extra components are closed. Thus the four-pair gate and the \(e\to p_1\) selectors still hold. The resulting 29-vertex pole has girth five, \(Q_P\ne Q_R\), and an odd closed component in the complement of **every** zero-port shore matching. Its forbidden \([e\,bc]\) loop now necessarily uses different zero-port shore matchings. The Petersen gadget gives a cyclic three-edge cut. Therefore these strengthened local conditions still cannot replace the full closure or the cyclically-five host condition.

This obstruction has unbounded order. Keep the first inserted gadget fixed, and repeatedly substitute the same Petersen three-pole at a shore vertex outside it. Each step adds eight vertices. Note 381's argument preserves the full BF support, while the quotient of each new gadget preserves the port pairing of every symmetric-difference path in the displayed row and all of its cycle phases. The untouched first gadget keeps an odd closed five-cycle in every zero-port shore complement and keeps \(Q_P\ne Q_R\). Girth remains five: insertion creates no cycle of length less than five, and the first gadget still has a five-cycle. Thus for every \(m\ge0\) there is a \((29+8m)\)-vertex genuine five-pole satisfying the full phase-family gate, the \(e\to p_1\) selectors, and the all-odd/distinct-zero-mask conditions, yet admitting \([e\,bc]\). Every member retains a cyclic three-edge cut. In particular, no finite order threshold makes those local conditions sufficient for exact Case XII.

The [subsequent reslotting argument of Note 419](419-an-exterior-reslotting-excludes-the-last-adjacent-prism-row.md) uses another singleton pair after one \(e\)--\(bc\) switch and excludes this exterior table under exact support at every shore order. The path conditions and the real nonexact rows above remain valid sharp boundaries. This hand argument awaits independent proof review; no OMEN or local mathematical recomputation was used.
