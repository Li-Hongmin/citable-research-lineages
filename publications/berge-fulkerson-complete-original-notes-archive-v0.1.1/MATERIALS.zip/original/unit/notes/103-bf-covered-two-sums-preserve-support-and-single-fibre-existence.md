> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BF-covered two-sums preserve boundary support and single-fibre existence

The three-edge-colourability hypothesis in
[Note 099](099-three-edge-colourable-two-sums-preserve-dependent-splice-fibres.md)
is unnecessary for two properties needed by the Case-XII reduction.  An
arbitrary closed cubic factor which has a Berge--Fulkerson cover preserves
the complete boundary support, and it preserves the existence of each
single occurrence-position fibre classified in
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).
The stronger canonical identity map of Note 099 still requires additional
structure.

## Two-sum and distinguished profiles

Let \(H_0\) be a cubic pole, let \(e=xy\) be a non-loop proper edge of
\(H_0\), and let \(J\) be a closed cubic graph with a non-loop edge
\(f=uv\).  Delete \(e\) and \(f\), and reconnect their four ends crosswise
to form

\[
H=H_0\oplus_{e,f}J.
\tag{1}
\]

Edges and matching occurrences are distinguished as objects, so parallel
edges and repeated occurrences cause no ambiguity.  For the closed factor
put

\[
\Pi(J,f)=\left\{
 I\in {[6]\choose2}:
 \begin{array}{l}
 (N_1,\ldots,N_6)\text{ is an ordered BF cover of }J,\\
 I=\{i:f\in N_i\}
 \end{array}
 \right\}.
\tag{2}
\]

This apparently fifteen-valued interface has only two possibilities:

\[
\boxed{
\Pi(J,f)=\varnothing
\quad\text{or}\quad
\Pi(J,f)={[6]\choose2}.}
\tag{3}
\]

Indeed, a BF cover has load two on \(f\), so exactly two of its six
occurrences use \(f\).  Permuting the occurrences moves those two to any
prescribed pair of slots.  This remains valid if two slots contain the same
perfect matching, since they are still distinct occurrences.

## Exact preservation of BF boundary support

The two new edges of (1) form the cut \(\delta_H(V(J))\).  Since a closed
cubic graph has even order, every perfect matching of \(H\) uses zero or two
edges of this cut.  Restoring \(e\) and \(f\) when both cut edges are used
gives the usual unique factorisation

\[
(M_0,M_J)\in\mathcal M(H_0)\times\mathcal M(J),
\qquad
\mathbf1_{e\in M_0}=\mathbf1_{f\in M_J}.
\tag{4}
\]

Projection of a BF row of \(H\) therefore gives BF covers of both factors;
the \(H_0\) projection has the same semiedge boundary type.  Conversely,
take a BF row of \(H_0\) and a BF cover of \(J\).  Each has exactly two
occurrences using its distinguished edge.  By (3), reorder the six
\(J\)-occurrences so that these two slot sets agree, and splice the six
pairs using (4).  Internal factor edges and the two new cut edges all have
load two.

Consequently

\[
\boxed{
\operatorname{BFsupp}(H)=
\begin{cases}
\operatorname{BFsupp}(H_0),&J\text{ has a BF cover},\\
\varnothing,&J\text{ has no BF cover}.
\end{cases}}
\tag{5}
\]

No simplicity, bridgelessness or three-edge-colourability assumption is
used.  In particular, a closed factor cannot selectively remove an
all-terminal or \(T\)--\(T\) type while retaining the forty Case-XII types.
It either preserves every boundary type of \(H_0\) or removes every BF row.

## Transport of one dependent-splice fibre

Assume now that \(J\) has a BF cover, and take one concrete Note-082 fibre
in \(H_0\).  Write its initial BF row in six occurrence positions as
\((M_1,\ldots,M_6)\), and let

\[
b_i=\mathbf1_{e\in M_i}.
\tag{6}
\]

Choose a BF cover \((F_1,\ldots,F_6)\) of \(J\).  Equation (3) permits an
initial ordering with

\[
\mathbf1_{f\in F_i}=b_i
\qquad(i=1,\ldots,6).
\tag{7}
\]

One paired splice in the exterior fibre replaces two positions and obeys

\[
M_i+M_j=M_i'+M_j'.
\tag{8}
\]

Its \(e\)-coordinate gives

\[
b_i+b_j=b_i'+b_j'.
\tag{9}
\]

The four entries are binary, so the two multisets
\(\{b_i,b_j\}\) and \(\{b_i',b_j'\}\) coincide.  Keep the factor
occurrences \(F_i,F_j\) in their positions if their distinguished bits
already agree with the new exterior bits, and exchange them otherwise.
The two new exterior--factor pairs satisfy (4), while the factor-side pair
sum is unchanged because its two occurrences were only permuted.  Every
other position is unchanged, and the factor row remains the same BF-cover
multiset.

Repeating this operation transports the second splice.  The argument uses
only pair-sum conservation, so it covers both sequential orders, reuse of
the first updated companion, and the forced-intermediate branch of Note
082.  In the nondegenerate overloaded case the pointwise literal positions
\(B,X\) are not touched, exactly as in the completeness classification of
Note 082.

Projection transports every row and pair equality in the reverse direction.
Thus, for the occurrence-position property,

\[
\boxed{
\operatorname{Fib}_{082}(H)\ne\varnothing
\iff
\operatorname{Fib}_{082}(H_0)\ne\varnothing.}
\tag{10}
\]

This proves existence of a single Note-082 fibre and preserves its
pointwise occurrence path.  It does not construct one global assignment of
factor matchings to the entire perfect-matching family of \(H_0\), nor does
it simultaneously lift arbitrarily many unrelated rows with all accidental
matching identities fixed.  The endpoint-star colouring of Note 099 is a
strictly stronger conclusion: three-edge-colourability supplies precisely
that canonical identity-consistent lift.

The distinction is real.  The Petersen graph has six perfect matchings and
its unique BF cover uses each of them once.  If their multiplicities are
\(x_1,\ldots,x_6\), every edge belongs to a unique pair of these matchings,
so the edge equations give \(x_i+x_j=2\) for every \(i<j\), and hence
\(x_i=1\) for all \(i\).  An exterior row with one repeated identity, for
example \(X=P_3\), cannot be lifted by a single identity map: the two equal
exterior identities would require the same Petersen factor, whereas every
factor occurrence in the projected row is distinct.  Occurrence transport
still works by assigning the two positions different Petersen factors.
Thus (10) is sharp with respect to the global identity-consistency claimed
in Note 099.

## Consequence for exact Case XII

The proposed use of a non-three-edge-colourable closed factor as a support
filter is impossible.  If the factor is BF-coverable, both the complete
boundary support and single-fibre existence are inherited from the pole
factor.  If it is not BF-coverable, no positive Case-XII row survives.

Hence a counterexample to the exact-Case-XII dependent-fibre implication
cannot be obtained by inserting a closed factor into a carrier which already
has extra \(A\) or \(T\)--\(T\) support, and such an insertion cannot erase
an already existing Note-082 occurrence fibre.  The unresolved case remains
the indecomposable common cubic perfect-matching closure itself.

More precisely, work in any class of loopless cubic poles closed under the
factorisation (1).  If \(H\) is an exact-Case-XII counterexample and has such
a closed-factor decomposition, projection of one positive BF row shows that
\(J\) is BF-coverable.  Equations (5) and (10) then make \(H_0\) a smaller
exact-Case-XII counterexample.  A minimum counterexample in that class is
therefore indecomposable under every closed-factor two-sum, not only those
whose closed factor is three-edge-colourable.  For a simple-only class this
corollary applies whenever closing the two shores keeps the factors simple.
