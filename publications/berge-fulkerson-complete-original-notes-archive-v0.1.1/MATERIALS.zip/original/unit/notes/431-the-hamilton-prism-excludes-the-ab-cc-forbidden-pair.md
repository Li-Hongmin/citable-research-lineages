> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton prism excludes the \(AB,Cc\) forbidden pair

Use the third two-spoke prism tree of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).
\tag{1}
\]
The tree is the Hamilton path \(a-A-C-B-b-c\), and the sixth terminal \(e\) belongs to an arbitrary six-port shore. Suppose the *complete* BF boundary support is exact Case XII with forbidden \(e\)-labels \(\{eX,eY\}=\{e\,AB,e\,Cc\}\). Its allowed five-cycle is one of
\[
S_1=e-Z-X-Y-W-e,\qquad S_2=e-Z-Y-X-W-e.             \tag{2}
\]

> **Pair exclusion.** Neither orientation in (2) can be the complete exact-Case-XII BF support of a cubic five-pole with this exterior, at any shore order.

The [published Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed type \((eX)(eZ)\) and forbids every \(T\)--\(T\) type. Take an actual six-perfect-matching row of that type. Write \(P=eX\) for the forbidden triple, \(R=eZ\) for the allowed triple, \(K=Z\) and \(J=X\) for their marked singleton occurrences, and \(D_0,D_1=e\) for the singleton-\(e\) occurrences. The \(Z\)-starting path of \(R\triangle K\) must end at \(W\): ending at \(X\) or \(Y\) would change \(R\) to another forbidden triple beside unchanged \(P\). Because \(R\) uses zero proper shore ports, this path is wholly exterior by the argument of [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md).

Both roots \(A,B\) of \(P=eX\) select the half-edge \(a u_1\). Indeed the vertex \(a\) is a leaf of the tree, and neither root is \(a\). Thus \(P\) uses \(a u_1\) irrespective of its root.

**Root \(R=eZ:c\).** From \(Z-t_Z-c\), an allowed terminal route may go directly through \(c-u_5-b-t_W-W\). Its only other possible \(W\)-ending follows the rest of the Hamilton path through \(u_4,B,u_3,C,u_2,A,u_1,a,t_W\). That long route occupies both \(A,B\) in \(K\), so \(K\) cannot cover the \(X=AB\) subdivision: \(K\) has only the \(Z\) terminal and must use one of the \(X\) halves. The direct route forces \(K:W:b\), while \(K\)'s \(Z\) terminal occupies its other possible edge at \(a\). Hence \(K\) covers \(a\) via \(a u_1\). But \(R=eZ:c\) also uses \(a u_1\), as does \(P\). This is edge load three, impossible.

**Root \(R=eZ:a\).** The route from \(Z-t_Z-a\) may end directly through \(a-t_W-W\), or follow the Hamilton path through \(u_1,A,u_2,C,u_3,B,u_4,b,t_W\). The long route again occupies both endpoints of the unselected mark \(X=AB\) in \(K\), so only the direct route is possible. Switching it between the complete matchings \(R,K\) gives \(R'=eW:a\) with the **same complete shore matching** as \(R\); its tree-edge choices are also identical. The two triples differ only on the exterior \(Z-t_Z-a-t_W-W\) path.

Fix a singleton-\(e\) occurrence \(D\) that covers \(a\) by either \(Z:a\) or \(W:a\). If \(D:Z:a\), the \(Z:a\) half-edge is common to \(R,D\); changing \(R\) to \(R'\) replaces the \(W\)-terminal end of one alternating component by the \(Z\)-terminal end through \(Z-t_Z-a-t_W-W\). If \(D:W:a\), the \(W:a\) half-edge is common to \(R',D\), and the same relabelling occurs in reverse. Every component running from \(X\) or \(Y\) to a shore port is unchanged. If an \(X\)- or \(Y\)-arm instead joins another marked terminal wholly outside the shore, it cannot be the required \(e\)-switch target. The required opposite targets therefore force **both** \(X,Y\)-arms to reach ports in both comparisons. Each triple has zero exterior ports, while \(D\) has three; these two arms and the third marked arm exhaust the three ports, leaving no exterior port-to-port detour. Since \(R,R'\) have the same full shore restriction, the shore portion of the \(e\)-path against this fixed \(D\) has the same first proper exit in both comparisons. Yet (2) requires opposite targets:
\[
\begin{array}{c|cc}
&R=eZ&R'=eW\\ \hline
S_1&X&Y\\
S_2&Y&X
\end{array}.
\tag{3}
\]
The distinct port-reaching \(X,Y\)-arms have distinct exits, so (3) is impossible. Consequently **both** \(D_0,D_1\) would have to cover \(a\) by \(a u_1\). Together with \(P\) this again loads that half-edge three times. Thus this root is impossible too. \(\square\)

The exclusion uses one required real BF row, whole-matching exchanges, and edge load two. It does not assume a clean shore complement, a bound on shore size or cycle rank, or a chosen subset of perfect matchings. Five other forbidden \(e\)-pairs remain for this Hamilton exterior; the other exterior profiles and the general Berge–Fulkerson conjecture remain open. This is a hand proof without local mathematical recomputation or independent review.
