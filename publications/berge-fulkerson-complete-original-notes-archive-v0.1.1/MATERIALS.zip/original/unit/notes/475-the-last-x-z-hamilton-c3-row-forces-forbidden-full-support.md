> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last \(X,Z\)-forbidden Hamilton \(C_3\) row forces forbidden full support

Use the fixed marked Hamilton exterior, labels and twelve necessary signatures of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). [Notes 467--474](474-the-x-z-hamilton-c7-row-forces-a-forbidden-double-triple.md) exclude the other eleven signatures of a required genuine \((eX)(eY)\) row when the exact-Case-XII forbidden pair is \(\{eX,eZ\}\). We now exclude \(C_3\) at every shore order and every labelled port phase, always preserving each of the six complete shore matching restrictions separately.

In \(C_3\), \(P=eX\) roots at \(X:1\), \(R=eY\) roots at \(Y:5\), and singleton \(K=Y\) uses \(X:1,Z:2,W:6,3u_3,4u_4,5u_5,p_1,p_2\). Put \(S=\{J,a,b\}\). The old marked \(X\) pairs are \((RJ,PK,ab)\). Write \(Y:5=R\lambda\). The complete old tree-subdivision pairs, in first-half/second-half/port order, are
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(R\lambda,P\alpha,K\eta)
&(R\gamma,P\delta,K\alpha)
&(RK,PJ,ab)
&(RK,P\theta,S\setminus\{\theta\})
&(K\xi,PR,S\setminus\{\xi\}),
\end{array}                                                  \tag{1}
\]
where
\[
\{\lambda,\alpha,\eta\}=S,
\qquad \{\alpha,\gamma,\delta\}=S,
\qquad \{\lambda,\theta,\xi\}=S.                         \tag{2}
\]
To derive the shared \(\alpha\) in \(u_1,u_2\), first write \(u_1:2=P\alpha\) and \(u_2:3=P\delta\). Since \(3u_3=RK\), vertex \(3\) makes \(W:3=S\setminus\{\delta\}\); the old \(W,Z\) terminal pair \(PR\) and vertex \(6\) then make \(Z:2=K\delta\). Vertex \(2\) gives \(\{\alpha,\gamma,\delta\}=S\), so the remaining companion at \(u_2\)'s \(K\)-port is \(\alpha\). At vertex \(4\), \(X:4=ab\) and \(4u_4=RK\) force \(u_3:4=PJ\). Vertex \(5\) gives the last brace in (2). Thus the old port pairs are
\[
 (p_1,p_2,p_3,p_4,p_5)
 =(K\eta,K\alpha,ab,S\setminus\{\theta\},S\setminus\{\xi\}),
 \qquad e=ab.                                               \tag{3}
\]

## \(\theta\in\{a,b\}\): a forbidden \([eX]\) loop

Let \(\bar\theta\) be the other \(e\)-singleton. Keep the old pairs at \(u_1,u_2,u_3,u_5\), and replace those at \(u_4\) by
\[
                 u_4=(K\theta,PR,S\setminus\{\theta\}).  \tag{4}
\]
At marked subdivisions \(X,Y,Z,W\), in terminal/first-half/second-half order, put
\[
 (KJ,P\theta,R\bar\theta),\quad
 (PR,K\xi,S\setminus\{\xi\}),\quad
 (PR,K\delta,S\setminus\{\delta\}),\quad
 (PR,S\setminus\{\delta\},K\delta).                        \tag{5}
\]
The original vertices see, respectively,
\[
(P\theta,R\lambda,K\xi),\quad
(P\alpha,R\gamma,K\delta),\quad
(P\delta,RK,S\setminus\{\delta\}),\quad
(PJ,K\theta,R\bar\theta),\quad
(PR,K\xi,S\setminus\{\xi\}),\quad
(PR,S\setminus\{\delta\},K\delta).                    \tag{6}
\]
These are six-label partitions by (2) and \(\{J,\theta,\bar\theta\}=S\). The port list remains (3). The terminal pairs become \(e=ab,X=KJ,Y=Z=W=PR\), the forbidden \([eX]\) type.

## \(\theta=J,\alpha=J\): a second forbidden \([eX]\) loop

Here (2) forces \(\lambda,\eta\in\{a,b\}\) to be distinct and \(\xi=\eta\). The old ports are \((K\eta,KJ,ab,ab,S\setminus\{\eta\})\). Use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(S\setminus\{\eta\},PR,K\eta)
&(ab,PR,KJ)
&(KJ,PR,ab)
&(KJ,PR,ab)
&(K\eta,PR,S\setminus\{\eta\}),
\end{array}                                                  \tag{7}
\]
and marked pairs
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(KJ,PR,ab)&(PR,K\eta,S\setminus\{\eta\})&
(PR,KJ,ab)&(PR,ab,KJ).
\end{array}                                                  \tag{8}
\]
The six original vertices see
\[
(PR,S\setminus\{\eta\},K\eta),\quad
(PR,ab,KJ),\quad
(PR,KJ,ab),\quad
(PR,KJ,ab),\quad
(PR,K\eta,S\setminus\{\eta\}),\quad
(PR,ab,KJ).                                             \tag{9}
\]
Every triple is a partition; the terminal pairs again give forbidden \([eX]\).

## \(\theta=J,\alpha\ne J\): a forbidden double triple

The remaining equations (2) force \(\lambda,\xi\in\{a,b\}\) distinct, \(\alpha=\xi\), and \(\eta=J\). Thus the old port pairs are
\[
                   (KJ,K\xi,ab,ab,J\lambda).            \tag{10}
\]
The following recompletion assigns singleton \(K\) to \(X\) and singleton \(J\) to \(Z\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(R\lambda,P\xi,KJ)
&(J\lambda,PR,K\xi)
&(KJ,PR,ab)
&(KJ,PR,ab)
&(K\xi,PR,J\lambda),
\end{array}                                                  \tag{11}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RK,PJ,ab)&(PR,K\xi,J\lambda)&
(PJ,RK,ab)&(PR,ab,KJ).
\end{array}                                                  \tag{12}
\]
The original vertices \(1,\ldots,6\) see
\[
(PJ,R\lambda,K\xi),\quad
(P\xi,J\lambda,RK),\quad
(PR,KJ,ab),\quad
(PR,ab,KJ),\quad
(PR,J\lambda,K\xi),\quad
(PR,ab,KJ).                                             \tag{13}
\]
All pairs at each vertex partition \(\{P,R,K,J,a,b\}\). The port pairs in (11) are exactly (10), and its terminals are \(e=ab,X=RK,Z=PJ,Y=W=PR\), the forbidden \((eX)(eZ)\) type. This last phase shows why fixing in advance which singleton label appears at \(Z\) would miss a valid recompletion.

The three cases exhaust (2), preserve \(e=ab\) and all five proper-port pairs label by label, and therefore glue to the **same six complete shore matchings** at any shore order. More generally, [Notes 466--474](474-the-x-z-hamilton-c7-row-forces-a-forbidden-double-triple.md) and the present tables give this closure law without assuming exact Case XII:
\[
\boxed{\text{In this fixed marked exterior, every genuine }(eX)(eY)
\text{ BF row forces }[eX]\text{ or }[eZ]\text{ or }(eX)(eZ)
\text{ in the complete support.}}                         \tag{14}
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires such an actual \((eX)(eY)\) row and forbids all three types on the right when the forbidden pair is \(\{eX,eZ\}\). Therefore no exact-Case-XII pole with the fixed marked Hamilton exterior \((X,Y,Z,W)=(14,15,26,36)\) can have that forbidden pair. Path reflection gives the analogous closure law and exclusion for \(\{eY,eW\}\) in this marked exterior. This is a conditional hand-proof chain pending independent review; other forbidden pairs, other marked exteriors, full exact Case XII, and Berge--Fulkerson remain open. No OMEN or local mathematical recomputation was used. \(\square\)
