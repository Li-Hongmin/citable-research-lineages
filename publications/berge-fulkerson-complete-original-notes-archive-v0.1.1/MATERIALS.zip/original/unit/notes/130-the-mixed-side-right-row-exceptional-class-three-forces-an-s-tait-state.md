> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The exceptional class-three right row forces an S-Tait state

**Subsequent strengthening.** [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) shows that *every* mixed-side \((25)(34)\) row under the same negative support forces an \(S\)-Tait colouring, including the \(h(Y_3)=0\) profile left open below.

The residual mixed-side branch of [Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) has a positive all-orders consequence. If the unique \((1,1)\) singleton in a \((25)(34)\) BF row is the class-three occurrence \(Y_3\), then the pole admits an actual Tait colouring of state \(14\in S\). Hence a Tait-empty exact-Case-XII pole cannot have that row profile. Combined with Note 129, every right \((25)(34)\) row of a Tait-empty mixed-side pole belongs to a fixed-\(B_2\) pair of rows with opposite class-four exceptional-edge bits. The theorem uses actual perfect matchings and the complete negative BF support, with no order or minimum-host assumption.

## Theorem

Write \(S=\{13,14,24,25,35\}\), \(T=\{12,15,23,34,45\}\). Let \(H\) be a cubic five-pole with no \(T\)-loop and no \(T\)--\(T\) BF type. Suppose \(F=\{e,f\}\) consists of disjoint proper edges, \(H-F\) is bipartite with terminal distribution \(4+1\), terminal \(2\) alone on the minority side, \(e\) internal to the majority side and \(f\) internal to the minority side. Assume an actual BF row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.             \tag{1}
\]
If \(Y_3\) uses both \(e,f\), then \(H\) has an actual Tait state \(14\in S\). More precisely, the proof produces a triple-boundary matching missing \(14\) whose exceptional-edge profile is \((1,1)\), and that matching extends to a Tait colouring.

**Proof.** In the mixed-side profile table of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md), \(q_{25}\) has profile \((0,1)\), \(B_2\) has \((1,0)\), and the \(T\)-triple \(r_{34}\) must have \((0,0)\): profile \((1,1)\) would make its bipartite complement an actual forbidden state-\(34\) Tait colouring. Write \(h(U)\in\{0,1\}\) for the common exceptional-edge bit of a majority-side singleton or an \(XX\)-missing triple. The load-two equation gives
\[
h(D_5)+h(Y_3)+h(C_4)=1.
\]
Thus the hypothesis \(h(Y_3)=1\) forces \(h(D_5)=h(C_4)=0\). Put
\[
A=q_{25}+B_2+D_5,
\qquad R=r_{34}+Y_3+C_4.
\]
Both exceptional edges have load one in each half. In particular \(A(e)=A(f)=1\), while \(R\) has the actual \(T\)-state \(34\).

Switch the bichromatic terminal path between \(q_{25}\) and \(B_2\) in the three-edge-colouring of the edge-copy multigraph \(A\). The singleton endpoint is terminal \(2\); the triple endpoint is one of \(1,3,4\). Terminal endpoints \(1,4\) would create states \(15,45\in T\) against the unchanged \(T\)-state \(34\) of \(R\), which is forbidden. The endpoint is therefore \(3\). The switch keeps \(D_5\) literally unchanged and yields
\[
A=q_{35}+Z_3+D_5.                                        \tag{2}
\]
Because \(A(e)=A(f)=1\) and \(h(D_5)=0\), exactly one of \(q_{35},Z_3\) has profile \((1,1)\). The triple \(q_{35}\) cannot be that occurrence. If it were, exchange the same-boundary \(Z_3\), of profile \((0,0)\), with \(Y_3\), of profile \((1,1)\), across the two halves. The new \(S\)-half \(q_{35}+Y_3+D_5\) would have load two on both \(e,f\), while its complementary half \(r_{34}+Z_3+C_4\) would retain \(T\)-state \(34\). The bichromatic terminal-path switch between \(q_{35}\) and \(Y_3\) must then move singleton \(3\) to terminal \(2\), since the alternative new states \(15,45\) lie in \(T\). It retains the complete \(D_5\) mask, which avoids both exceptional edges. But any resulting state-\(25\) decomposition has triple profile \((0,1)\), minority singleton profile \((1,0)\), and that same \(D_5\) profile \((0,0)\): its load on each exceptional edge is one, contrary to the fixed load two of the half. Therefore
\[
h(q_{35})=0,\qquad h(Z_3)=1.                             \tag{2a}
\]

Switch the bichromatic terminal path between \(q_{35}\) and \(D_5\), leaving \(Z_3\) fixed. Its triple endpoint is one of \(1,2,4\). Only terminal \(1\) gives an \(S\)-state with the retained singleton \(3\); the other endpoints would give forbidden \(T\)--\(T\) BF types with \(R\). Thus
\[
A=q_{13}+A_1+Z_3.                                        \tag{3}
\]
The two switched matchings \(q_{35},D_5\) both avoided \(e,f\), so \(q_{13},A_1\) also avoid them.

Now switch the bichromatic terminal path between \(q_{13}\) and \(Z_3\), retaining \(A_1\). Among the possible new states \(12,14,15\), only \(14\in S\) is allowed against \(R\). We obtain
\[
A=q_{14}+A_1+Z_4.                                        \tag{4}
\]
Here \(h(A_1)=0\) and \(A(e)=A(f)=1\), so exactly one of \(q_{14},Z_4\) has profile \((1,1)\). If it is \(q_{14}\), its complement avoids both exceptional edges, and alternating its even cycles and even terminal path gives an actual Tait colouring of state \(14\in S\).

Suppose instead that \(h(Z_4)=1\) and \(h(q_{14})=0\). Exchange the complete same-boundary occurrences \(Z_4\) in (4) and \(C_4\) in \(R\). The two new half-loads are
\[
A'=q_{14}+A_1+C_4,
\qquad R'=r_{34}+Y_3+Z_4,
\qquad A'+R'=2\mathbf1.                              \tag{5}
\]
The first still has an actual \(S\)-state \(14\), and the second an actual \(T\)-state \(34\). But \(A'(e)=A'(f)=0\), since all three constituents of \(A'\) avoid both edges. Switch the bichromatic terminal path between \(q_{14}\) and \(A_1\) in \(A'\), leaving \(C_4\) fixed. Its triple endpoint is one of \(2,3,5\). Endpoints \(3,5\) would give the forbidden \(T\)-states \(34,45\) against \(R'\), so it must end at terminal \(2\). Yet this path uses no exceptional edge and lies in the bipartite graph \(H-F\). Its terminal vertices \(1\in X\) and \(2\in Y\) require an odd number of proper edges. The path begins with an \(A_1\)-coloured semiedge and ends with a \(q_{14}\)-coloured semiedge, so alternation requires an even number of proper edges. This contradiction rules out the second outcome, and \(q_{14}\) gives the asserted \(S\)-Tait state. Equivalently, the same contradiction follows from the all-\(S\) column saturation in [Note 055](055-half-load-column-saturation-and-case-xii-compression.md): no state-\(24\) decomposition of the zero-exceptional-edge load \(A'\) is possible. \(\square\)

## Consequences and exact boundary

The assumed absence of \(T\)-loops already excludes every \(T\)-Tait state, because doubling a Tait colouring gives its BF loop. The usual bichromatic terminal-path switches then propagate the state \(14\) around the connected \(S\)-pentagon, so **all five \(S\)-Tait states occur**; this uses no further positive BF support. In the Tait-empty branch, every right row (1) has \(h(Y_3)=0\); the involution of Note 129 then supplies two right rows with the same complete \(B_2,Y_3,r_{34}\) masks and opposite \(C_4\) exceptional-edge profiles. [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) records the corresponding exact-Case-XII Tait-state dichotomy.

The reflection \((1\ 3)(4\ 5)\), fixing the minority terminal \(2\), preserves \(S,T\). It gives the companion statement for a \((24)(15)\) BF row: if its class-one singleton uses both exceptional edges, an actual state-\(35\) Tait colouring exists. Thus, in the Tait-empty branch, neither of the two reflected right seed cells can put its unique \((1,1)\) singleton at a \(T\)-neighbour of terminal \(2\).

This is a profile-level statement and does not prove the full vector intersection \(\Lambda_L\cap\Lambda_R\ne\varnothing\). In the \(S\)-Tait branch, a class-three exceptional singleton can still occur, and in either branch the left and right rows may use different complete class-four masks even when their two exceptional-edge coordinates agree. The remaining positive task is full-mask synchronization across the two seed rows, or an exact-support contradiction for the \(S\)-Tait branch.
