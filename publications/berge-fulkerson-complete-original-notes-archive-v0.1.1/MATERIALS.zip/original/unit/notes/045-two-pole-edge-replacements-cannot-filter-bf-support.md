> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cubic two-pole edge replacements cannot filter BF boundary support

This note closes a tempting construction route for the Case-XII problem.  A
cubic two-pole can insulate a pole from Tait colourings, but it cannot
selectively remove BF boundary types from a host pole.

Let \(J\) be a cubic two-pole with two semiedges and let \(n=|V(J)|\).  The
degree equation

\[
3n=2m+2
\]

forces \(n\) to be even.  In any perfect matching of \(J\), if \(b\) of the
two semiedges are used, then

\[
n=2r+b.
\]

Thus \(b\) is even: a matching uses either both semiedges or neither.  In a
BF-colouring, applying this parity equation to each of the six colour
classes shows that the two semiedges receive the same two-element colour
label.

If \(J\) admits one BF-colouring, a global permutation of the six colour
names sends its common terminal label to any prescribed member of
\(\binom{[6]}2\).  Hence every two-element label is allowed at the two
terminals.  Conversely, any BF-colouring of a host graph in which an edge
\(e\) is replaced by \(J\) restricts to equal labels on the two new
semiedges and therefore contracts to a BF-colouring of the host.

It follows that for every cubic host pole \(H\),

\[
\mathcal C\bigl(H[e\leftarrow J]\bigr)=\mathcal C(H)
\tag{1}
\]

whenever \(J\) has a BF-colouring.  The forward inclusion extends each host
colouring through \(J\), choosing a colour permutation independently for
the inserted gadget; the reverse inclusion contracts the gadget.  If \(J\)
has no BF-colouring, the replaced pole has no BF-colouring at all.

The same argument applies independently to any finite collection of
replaced edges and to different nonempty two-poles on those edges.  Therefore
Petersen two-poles, or any other cubic two-pole used as an edge-insulating
gadget, cannot preserve the 25 \(S\)--\(T\) types while deleting only the
\(T\)-loops and \(T\)--\(T\) types.  Any selective BF-support construction
must use a gadget with at least four terminals, or a genuinely coupled
multi-edge replacement whose internal boundary labels are not independently
relabelable.

This is a route-closure statement, not a theorem about the existence or
nonexistence of a genuine Case-XII pole.
