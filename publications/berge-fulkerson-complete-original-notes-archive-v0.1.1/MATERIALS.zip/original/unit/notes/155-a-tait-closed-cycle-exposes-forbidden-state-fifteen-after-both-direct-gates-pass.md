> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A Tait closed cycle exposes state 15 after both direct gates pass

The nineteen-vertex pole in [Note 154](154-a-nineteen-vertex-diamond-has-two-open-tait-routes-through-the-chord-side-edge.md) puts one chord-side \(ZY\) edge on the open \(3\leftrightarrow5\) path of both Tait completions, but its first completion already has a forbidden \(5\to2\) Kempe path. The twenty-one-vertex **actual cubic five-pole** below repairs that direct defect: both [Note 149](149-both-singleton-phases-of-a-short-diamond-have-state-thirtyfive-tait-completions.md) completions have the allowed \(5\to1\) and \(3\to2\) terminal paths, while the same chord-side edge stays on an open \(3\leftrightarrow5\) path in each. A closed \(3/5\) cycle of the second completion then changes its \(3\)-path to \(3\to1\), producing a forbidden state-\(15\) Tait colouring. An edge-swapped version has **no closed \(3/5\) component in either completion**: its forbidden state instead appears after a closed triple/\(5\) switch. These are genuine **complete perfect-matching closure** steps missing from the selected rows and direct Tait gates. Neither graph is an exact-Case-XII counterexample. The explicit edge proofs are analytic and await independent checking; no local enumeration was used.

## A two-level gate in every exact-Case-XII pole

Let \((M_{35},A_3,F_5)\) be any actual state-\(35\) Tait colouring in a cubic five-pole with no \(T\)-state Tait colouring, where \(T=\{12,15,23,34,45\}\). For any union \(W\) of closed components of \(A\triangle F\), the complete masks
\[
(M_{35}, A^W_3, F^W_5)
 :=(M_{35},A\triangle W,F\triangle W)                 \tag{1}
\]
are another state-\(35\) Tait colouring. In **every** such phase, the open \(A^W\triangle M\) path from terminal \(3\) must end at \(2\), and the open \(F^W\triangle M\) path from terminal \(5\) must end at \(1\). Switching the former to endpoint \(1\) or \(4\) gives the forbidden Tait states \(15\) or \(45\); switching the latter to endpoint \(2\) or \(4\) gives states \(23\) or \(34\). Thus the endpoint requirements hold throughout the full cube of closed \(A/F\) phases, not just in one chosen Tait colouring.

## Complete edge certificate for the twenty-one-vertex pole

Use vertices \(v_0,\ldots,v_5,x_1,\ldots,x_4,a,b,j_1,j_2,j_3,t_1,t_2,t_3,u,v,k\). The five semiedges \(s_i\) meet \(t_i\) for \(i=1,2,3\), \(b\) for \(i=4\), and \(v_0\) for \(i=5\). Every edge is specified by its two owners among \(U,Z,D,r,Y,C\):

| Owners | Proper edges | Semiedges |
|---|---|---|
| \(UZ\) | \(v_0v_1\) | |
| \(rY\) | \(v_1v_2\) | |
| \(ZC\) | \(v_2v_3\) | |
| \(YD\) | \(v_3v_4\) | |
| \(rZ\) | \(v_4v_5\) | |
| \(YC\) | \(v_5v_0\) | |
| \(UD\) | \(v_2x_1,\ x_2x_3,\ x_4v_5\) | |
| \(rC\) | \(x_1x_2,\ x_3x_4\) | |
| \(UC\) | \(v_4a,\ t_3u,\ vk\) | \(s_4\) |
| \(Dr\) | \(ab,\ uv,\ kt_3\) | \(s_5\) |
| \(Ur\) | \(v_3j_3,\ j_1j_2\) | \(s_1,s_2\) |
| \(DC\) | \(v_1j_1,\ j_2t_1,\ j_3t_2\) | |
| \(ZY\) | \(j_1x_2,\ x_3a,\ x_1j_2,\ x_4j_3,\ t_2u,\ bv,\ t_1k\) | \(s_3\) |

At each vertex the three incident owner pairs partition all six names. Hence the graph is simple, connected and cubic; it has twenty-one vertices, twenty-nine proper edges and five semiedges. Each name denotes a **complete actual perfect matching**, with the terminal boundaries indicated by
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.       \tag{2}
\]
The six-edge core \(\Omega=v_0v_1v_2v_3v_4v_5v_0\) again has the \((2,2,1,1)\) owner sequence \((UZ,rY,ZC,YD,rZ,YC)\); its chord \(\chi=v_2x_1x_2x_3x_4v_5\) has \((UD,rC,UD,rC,UD)\). All edges outside \(\Omega\cup\chi\) are split between the two halves of (2), so this is the normalized four-junction diamond of Note 143.

There is an actual aligned carrier decomposition
\[
\begin{aligned}
q_{25}&=\{v_0v_1,v_2v_3,v_4v_5,j_1x_2,x_3a,x_1j_2,x_4j_3,t_2u,vk,s_1,s_3,s_4\},\\
B_2&=\{v_0v_1,v_2x_1,x_2x_3,x_4v_5,v_4a,t_3u,v_3j_3,j_1j_2,bv,t_1k,s_2\},
\end{aligned}                                             \tag{3}
\]
with \(q+B=U+Z\) edgewise. At every vertex of \(\Omega\) and the chord interior, \(q=Z\) and \(B=U\). The corresponding actual right row has four junctions on \(\Omega\), at \(v_1,v_2,v_3,v_5\), and its unique exterior junction at \(t_1\); hence \(J'=5\).

The canonical forced paths and the original \(r/C\) paths are
\[
\begin{aligned}
P_{54}\subset q\triangle D &: s_5,v_0,v_1,j_1,x_2,x_3,a,b,s_4,\\
P_{23}\subset q\triangle r &: s_2,t_2,u,v,k,t_3,s_3,\\
(r\triangle C)_{45} &: s_4,b,a,v_4,v_5,v_0,s_5,\\
(r\triangle C)_{12} &: s_1,t_1,j_2,j_1,v_1,v_2,v_3,j_3,t_2,s_2.
\end{aligned}                                             \tag{4}
\]
Thus the selected row has all three required endpoint gates. The chord-side edge
\[
z=j_1x_2\in P_{54}\setminus P_{23},\qquad
q(z)=\widehat C(z)=p(z)=Z(z)=Y(z)=1,                \tag{5}
\]
where \(\widehat C=D\triangle E(P_{54})\) and \(p=q\triangle E(P_{23})\). It is a real exterior edge of \(p\cap Z\), of the kind forced in Notes 150--153. The same \(P_{54}\) uses the paired chord-side exit \(x_3a\) across the internal \(UD\) edge \(x_2x_3\). No absence of a common complete \(B_2+C_4\) seed is asserted.

The displayed \(P_{54}\) and \(P_{23}\) are vertex-disjoint, so changing \(q\) to \(p\) leaves \(P_{54}\) as the \(5\leftrightarrow4\) component of \(p\triangle D\). Thus the canonical cross-half endpoint test of [Note 136](136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md) does not give a seed here, either. This says nothing about other complete rows or phases.

## Two direct Tait gates pass; one closed phase fails

Define the two core cycles \(K_o=(v_2v_1v_0v_5)\cup\chi\) and \(K_s=(v_2v_3v_4v_5)\cup\chi\). Note 149 gives the actual Tait triples
\[
\mathcal T_0=(U^{K_o}_{35},Z_3,D_5),
\qquad
\mathcal T_1=(U_{35},Z^{\Omega}_3,D^{K_s}_5).        \tag{6}
\]
Their direct terminal paths have the allowed endpoints:
\[
\begin{array}{c|c|c}
&\text{triple/singleton-5 path}&\text{triple/singleton-3 path}\\\hline
\mathcal T_0&s_5,v_0,v_5,x_4,x_3,x_2,x_1,v_2,v_1,j_1,j_2,t_1,s_1
             &s_3,t_3,u,t_2,s_2\\
\mathcal T_1&s_5,v_0,v_1,j_1,j_2,t_1,s_1
             &s_3,t_3,u,t_2,s_2.
\end{array}                                               \tag{7}
\]
So each \(5\)-path ends at \(1\), and each \(3\)-path ends at \(2\).

In \(\mathcal T_0\), the singleton difference \(Z\triangle D\) is the **spanning open** \(5\leftrightarrow3\) path
\[
s_5,v_0,v_1,j_1,x_2,x_3,a,b,v,u,t_2,j_3,x_4,v_5,v_4,v_3,v_2,x_1,j_2,t_1,k,t_3,s_3. \tag{8}
\]
In \(\mathcal T_1\), \(Z^{\Omega}\triangle D^{K_s}\) has the open path
\[
s_5,v_0,v_5,v_4,v_3,v_2,v_1,j_1,x_2,x_1,j_2,t_1,k,t_3,s_3, \tag{9}
\]
and one closed eight-cycle
\[
F=t_2,u,v,b,a,x_3,x_4,j_3,t_2.                       \tag{10}
\]
All three displayed walks alternate between their indicated singleton colours. The edge \(z=j_1x_2\) lies on the **open** path in both (8) and (9), so neither direct Tait completion can remove \(z\) by a closed \(3/5\) switch.

Now switch the two singleton colours of \(\mathcal T_1\) on the whole proper cycle \(F\), obtaining actual complete matchings \(Z'=Z^{\Omega}\triangle E(F)\) and \(D'=D^{K_s}\triangle E(F)\). The triple \(U_{35}\) is unchanged, and \((U,Z',D')\) is still a state-\(35\) Tait colouring. But its \(3\)-terminal \(U\triangle Z'\) path is
\[
s_3,t_3,u,v,k,t_1,s_1.                                \tag{11}
\]
Switching \(U,Z'\) on (11) gives an actual **state-\(15\) Tait colouring**. This is a complete perfect-matching closure witness that excludes the pole from exact Case XII, although both selected Tait colourings passed every direct endpoint gate in (7).

## An edge swap moves the obstruction to another colour pair

There is a second, equally concrete version of the same twenty-one-vertex pole. In the edge table above, replace just the two \(ZY\)-owned proper edges
\[
x_1j_2,\ x_4j_3
\quad\longmapsto\quad
x_1j_3,\ x_4j_2,                                         \tag{12}
\]
and make the identical replacement in \(q_{25}\). The four affected vertices all choose their \(Z\)-edge in \(q+B=U+Z\), so every original owner remains an actual complete perfect matching; \(B_2\) and all edges of \(U,D,r,C\) are unchanged. The graph remains simple, connected and cubic. The paths (4), \(J'=5\), the chord-side edge \(z=j_1x_2\), and both direct Tait endpoint pairings (7) are unchanged.

In this modified graph, **both** singleton differences of the Note-149 Tait completions are spanning open \(5\leftrightarrow3\) paths, with no closed components at all:
\[
\begin{aligned}
Z\triangle D:\quad
&s_5,v_0,v_1,j_1,x_2,x_3,a,b,v,u,t_2,j_3,x_1,v_2,v_3,v_4,v_5,x_4,j_2,t_1,k,t_3,s_3,\\
Z^{\Omega}\triangle D^{K_s}:\quad
&s_5,v_0,v_5,v_4,v_3,v_2,v_1,j_1,x_2,x_1,j_3,t_2,u,v,b,a,x_3,x_4,j_2,t_1,k,t_3,s_3.
\end{aligned}                                             \tag{13}
\]
In each sequence the proper edges alternate between its named \(Z\)- and \(D\)-colours, beginning with the \(D\)-owned semiedge \(s_5\) and ending with the \(Z\)-owned semiedge \(s_3\). Each visits all twenty-one vertices once and contains \(z\). Thus neither singleton difference has another component, and checking **every closed \(3/5\) phase of just these two Tait anchors** is vacuous here, even though their direct \(5\)- and \(3\)-terminal gates pass.

The first Tait colouring still has the proper \(U^{K_o}/D\)-alternating square
\[
Q=t_3,u,v,k,t_3,                                       \tag{14}
\]
whose successive edge owners are \(UC,Dr,UC,Dr\). The core switch \(K_o\) does not meet \(Q\), so these edges alternate between \(U^{K_o}\) and \(D\). Before this switch, its two \(U^{K_o}\)-edges lie on different open components of \(U^{K_o}\triangle Z\): \(t_3u\) lies on the \(3\leftrightarrow2\) path in (7), while \(vk\) lies on \(s_1,t_1,k,v,b,s_4\), the \(1\leftrightarrow4\) path. Switch the two complete colours on \(Q\), writing \(\widetilde U=U^{K_o}\triangle E(Q)\) and \(\widetilde D=D\triangle E(Q)\), and leave \(Z_3\) fixed. The resulting triple colour \(\widetilde U_{35}\) has its \(3\)-terminal \(\widetilde U\triangle Z\) path
\[
s_3,t_3,k,t_1,s_1.                                     \tag{15}
\]
Switching \(\widetilde U,Z\) on this path makes their boundaries \(15\) and \(1\), respectively, while \(\widetilde D\) retains boundary \(5\). The resulting state-\(15\) Tait colouring is forbidden in Case XII. The same square \(Q\) and the same two open \(U^{K_o}\triangle Z\) paths already occur in the original graph; the edge swap removes its displayed closed \(3/5\) cycle \(F\) while retaining this other forbidden route.

For exact Case XII, the elementary endpoint rule in (1) must be applied after closed switches of **each** bichromatic pair of every Tait colouring, and then reapplied to every resulting colouring. Restricting the check to the singleton-\(3\)/singleton-\(5\) phase cube misses the genuine complete-matching closure witness (14)--(15). This remains a boundary of the Tait-colouring subsystem; the full BF rectangle also couples rows that are not Tait colourings.

The exact Case-XII question cannot be decided by the two direct Tait endpoint gates or by the closed \(3/5\) phases of those anchors: both tests pass in the edge-swapped graph, yet a different colour-pair phase reaches a forbidden loop. Any proof through these anchors must constrain their other bichromatic phases and subsequent terminal pairings, or use another complete-mask coupling. Neither version establishes the absence of a common complete \(B_2+C_4\) seed, realizes exact Case XII, or gives a Berge--Fulkerson counterexample.
