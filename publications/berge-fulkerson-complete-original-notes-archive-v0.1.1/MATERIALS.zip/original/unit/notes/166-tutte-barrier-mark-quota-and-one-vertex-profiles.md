> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A maximum Tutte barrier has at most one marked incidence

Assume the marked-core setting of [Notes 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md) and [165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md): \(J\) is a simple 3-edge-connected cubic core with five marked edges \(M\), its five-pole has **full exact Case-XII BF support** in a minimum host, and \(F=J-M\) is connected. Suppose \(F\) has no perfect matching. Its deficiency is then two by Note 161. The cut budget below first gives \(h(U)\le2\); [Note 168's full-family flexibility theorem](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md) excludes the equality case and one \(h(U)=1\) profile, yielding \(h(U)\le1\). The \(h(U)=0\) even-component profile is also excluded by one-edge bipartization. The deficiency-two branch as a whole remains open. These analytic deductions depend on earlier structural notes that await independent checking.

## Deletions in one perfect matching

Let \(U\subseteq V(F)\) attain the Tutte deficiency, so \(F-U\) has \(q=|U|+2\) odd components, possibly also even components. For a pole perfect matching \(N\), let \(A_N\) be the set of core endpoints selected through marked half-edges, as in Note 157. Put \(k=|A_N|\), \(r=|A_N\cap U|\), and let \(t\) (respectively \(e\)) count odd (respectively even) components of \(F-U\) containing an odd number of vertices of \(A_N\).

After those vertices are deleted, each of the \(q-t\) original odd components with an even number of deletions, and each of the \(e\) original even components with an odd number, leaves at least one odd residual piece. Its matching needs a distinct edge into \(U-A_N\). A deletion may split a component further, which only strengthens this necessary count. Hence
\[
q-t+e\le |U|-r,\qquad
t-e\ge 2+r,\qquad
2+2r+2e\le k.                                      \tag{1}
\]
For a triple-boundary matching, \(k=2\). Equation (1) forces \(r=e=0,t=2\): its two selected endpoints lie in distinct odd components of \(F-U\), recovering the key assertion of Note 161. For a singleton-boundary matching, \(k=4\), so \(r+e\le1\). In particular it selects at most one endpoint in \(U\). If it does select one, its other three endpoints lie in three distinct odd components, and none lies in an even component.

## A six-slot quota on \(U\)

Let
\[
h(U)=\sum_{v\in U}d_M(v)
\]
count marked-edge incidences at \(U\), with an internal marked edge counted twice. Every BF row uses each marked half-edge twice, so its six perfect-matching slots select exactly \(2h(U)\) core endpoints in \(U\). In a Case-XII pair or loop row, the two triple slots select none by (1), while each of the four singleton slots selects at most one. Therefore
\[
\boxed{h(U)\le2\quad\text{for every maximum Tutte barrier }U.} \tag{2}
\]
If equality holds, **each** singleton slot selects one endpoint in \(U\) and three in distinct odd components of \(F-U\). The two marked incidences in \(U\) must belong to distinct marked edges. Indeed, if both ends of marked edge \(i\) lay in \(U\), choose a required positive Case-XII row whose singleton boundary includes \(i\). That singleton slot uses \(s_i\), selects neither end of edge \(i\), and therefore selects no endpoint in \(U\), contrary to equality in (2).

The six-slot argument supplies the equality-slot structure and rules out two incidences from one marked edge. The cut count below gives a second proof of the numerical bound \(h(U)\le2\) without using a BF row. Neither argument says that \(F\) has a perfect matching: a barrier disjoint from all marked endpoints remains possible.

## The four-unit cut budget

The same barrier has a sharp all-orders cut count. Let \(a\) count incidences of unmarked \(F\)-edges at \(U\) that do **not** go to an odd component of \(F-U\): an edge inside \(U\) counts twice, and an edge from \(U\) to an even component counts once. Let \(b\) count marked-edge endpoint incidences outside \(U\) that do **not** contribute to the boundary of an odd component of \(F-U\). Thus an internal marked edge of an odd component contributes two to \(b\), as do both ends of a marked edge inside an even component.

Write
\[
E=\sum_{C\text{ odd component of }F-U}(|\delta_J(C)|-3).
\]
Every summand is a nonnegative even integer: \(J\) is 3-edge-connected, and the cubic parity of odd \(C\) makes \(|\delta_J(C)|\) odd. Counting the boundary incidences once through \(U\) and once through the five marked edges gives
\[
\sum_C|\delta_J(C)|
 =(3|U|-h-a)+(10-h-b)
 =3|U|+10-2h-a-b.
\]
Because the number of odd components is \(|U|+2\), we obtain the exact identity
\[
\boxed{E+a+b=4-2h(U).}                         \tag{3}
\]

A non-singleton odd component consumes at least two units of this budget. If its cut has size at least five, it contributes at least two to \(E\). If its cut has size three, [Note 123, (5)](123-exact-case-xii-terminal-vertices-are-independent.md) forces at least two internal marked edges whenever \(J[C]\) is cyclic; a connected acyclic shore of a three-edge-cut is one vertex. Those two marks contribute at least four to \(b\). Therefore
\[
\boxed{\#\{\text{non-singleton odd components of }F-U\}\le 2-h(U).} \tag{4}
\]
In particular, if \(h(U)=2\), then \(E=a=b=0\). Every odd component is a single vertex, there are no even components (since \(F\) is connected), and there is no \(F\)-edge inside \(U\). Thus \(F\) is bipartite between \(U\) and its \(|U|+2\) isolated odd components; the two marked incidences at \(U\) belong to different marked edges by the preceding section. This is a necessary full-row shape, not a proof that such a graph realizes exact Case XII.

This equality case falls into the precise two-edge-bipartization branches of [Notes 126–127](127-two-edge-bipartization-profiles-and-tait-blockers.md). Put \(D=V(F)\setminus U\). The two marked edges incident with \(U\) join \(U\) to \(D\); the other three join vertices of \(D\). In the five-pole \(H\), each mark has a subdivision vertex \(t_i\). Delete the \(U\)-side half-edge of each \(U\)–\(D\) mark. The remaining proper-edge graph is bipartite with parts \(U\) together with all five \(t_i\), and \(D\). If the two marks shared their \(U\) endpoint, those deleted half-edges would be adjacent, contradicting Note 126. Deleting instead their \(D\)-side half-edges gives another bipartization; adjacency would likewise exclude a common \(D\) endpoint. Thus the two \(U\)–\(D\) marks are vertex-disjoint.

Call their terminal labels \(i,j\). Deleting their \(U\)-side halves yields the \(5+0\) terminal distribution of Note 127. In particular, for every actual triple matching with a \(T\) missing pair, those two exceptional half-edges must lie in **different** components of its complement, or a forbidden \(T\)-loop follows. Deleting instead their \(D\)-side halves gives the \(2+3\) distribution with both exceptional edges on the two-terminal side, whose terminal positions are exactly \(i,j\). Note 127, (3), therefore forces
\[
\boxed{\{i,j\}\in S\quad\text{and }\{i,j\}\text{ is an actual Tait state of }H.} \tag{5}
\]
By the exact-support Tait-state dichotomy in [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md), the full Tait-state set is \(S\). Thus the \(h(U)=2\) equality case lies specifically in the \(S\)-Tait branch and still obeys the \(5+0\) complement-component blocker for every \(T\)-boundary triple. More specifically, let \(t=\{i,k\}\in T\) with \(k\notin\{i,j\}\). Every actual triple matching missing \(t\) selects the \(D\) endpoint of mark \(i\), so its complement's unique terminal path starts at \(s_i\) along the \(U\)-side half of \(i\). The exceptional \(U\)-side half of mark \(j\) must therefore lie on a **closed odd cycle**, or the two halves would share the terminal-path component and the triple would extend to a forbidden \(T\)-Tait colouring. The symmetric statement holds for \(t=\{j,k\}\in T\). This anchors the required odd-cycle blocker at the *opposite* mark for all four \(T\) missing pairs incident with exactly one of \(i,j\).

For a singleton matching, if \(r\) of its four selected marked endpoints lie in \(U\), the remaining bipartition sides of \(F\) have sizes \(|U|-r\) and \(|U|-2+r\). Equality forces \(r=1\) for **every** singleton matching, including those outside a chosen BF row.

The three singleton classes whose labels lie outside \(\{i,j\}\) are all flexible across the two exceptional \(U\)-side halves. A singleton matching in class \(i\) must use the \(U\)-side half of mark \(j\): it uses \(s_i\), and every singleton selects exactly one endpoint in \(U\). Similarly, every class-\(j\) singleton uses the \(U\)-side half of mark \(i\). Each of these halves is therefore fixed in one singleton class. [Note 086](086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md) says that no proper edge can be fixed in two distinct singleton classes under complete Case-XII support. Since every singleton uses exactly one of the two halves, each of the other three singleton classes contains actual matchings of **both** profiles. Within each such class, [Note 127's one-cycle profile switch](127-two-edge-bipartization-profiles-and-tait-blockers.md) puts both exceptional halves on one alternating cycle between suitable opposite-profile matchings. This uses the complete singleton matching classes, without asserting that the switch stays in a prescribed BF-row fibre.

There is a forced two-row fork inside the genuine BF support. Since \(\{i,j\}\in S\), its endpoints have a unique common neighbour \(k\) in the complementary \(T\)-pentagon. Both positive cells \((ij)(ik)\) and \((ij)(jk)\) occur. In the first cell the four singleton boundaries are \(i,i,j,k\). The two class-\(i\) occurrences already load the \(U\)-side half of mark \(j\) twice; the class-\(j\) occurrence loads the \(U\)-side half of mark \(i\) once. Hence its class-\(k\) occurrence **must** use the \(U\)-side half of \(i\). In the second cell, with singleton boundaries \(j,j,i,k\), the class-\(k\) occurrence must instead use the \(U\)-side half of \(j\). The \(T\)-triple in each row has the opposite mark on an odd closed complement cycle by the preceding paragraph. Thus both exceptional profiles of the *same* class \(k\) occur in specified actual BF rows, though their other complete matching masks need not agree.

There is also a core matching invariant in this equality case. Since \(D\) has two more vertices than \(U\), every perfect matching of \(J\) uses exactly one of the three marked \(D\)–\(D\) edges: its \(|U|\) other edges match all of \(U\) to \(|U|\) vertices of \(D\), leaving two vertices of \(D\) to be matched together. Thus these three marks form a tight transversal of the **entire** core perfect-matching family. Here \(|V(H)|=|V(J)|+5=2|U|+7\), so [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) further requires \(|U|\ge5\). This is an intermediate description of the equality shape; the fixed singleton profiles above give a contradiction by Note 168.

When \(h(U)=1\), identity (3) has right side two and gives an equally concrete dichotomy. An even component of \(F-U\) would have an even \(J\)-cut of size at least four; every edge in that cut contributes an incidence to \(a+b\), forcing \(a+b\ge4\). Thus no even component exists. If \(E=2\), then \(a=b=0\): \(F[U]\) has no edge, no mark lies inside an odd component, exactly one odd component has a five-edge \(J\)-cut, and every other odd component has a three-edge cut and is a singleton. If \(E=0\), then \(a+b=2\), all odd components have three-edge cuts, and an internal mark in one would create a cyclic shore requiring at least two internal marks and hence \(b\ge4\). Thus \(b=0,a=2\): **all** odd components are singleton, and \(F[U]\) consists of exactly one edge.

In this latter shape, the sole mark at \(U\) joins \(U\) to a singleton odd component; the other four marks join singleton components. Deleting the one \(F[U]\) edge and the \(U\)-side half-edge of that mark makes the five-pole's proper graph bipartite, with all five terminal subdivision vertices on the \(U\) side. Note 126 therefore forces these two exceptional edges to be disjoint. This is again Note 127's same-side \(5+0\) branch: every \(T\)-boundary triple matching must leave the two exceptional edges in different complement components. The alternative \(E=2\) shape retains one nontrivial odd component and does not reduce to that two-edge bipartization by this argument.

There is a second bipartization of the same \(h(U)=1,\ E=0\) shape. Write \(g\) for the sole edge of \(F[U]\), and \(h\) for the terminal label of the mark incident with \(U\). Delete \(g\) and the **\(D\)-side** half-edge of mark \(h\). The retained \(U\)-side half-edge places \(t_h\) on the \(D\) side, while the other four terminal vertices lie on the \(U\) side. Thus \(g\) and the deleted half-edge form Note 127's disjoint mixed-side \(4+1\) configuration, with minority terminal \(h\). [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) now forces an actual \(S\)-Tait colouring under exact Case-XII support; Note 100 makes the full Tait-state set \(S\). Every class-\(h\) singleton matching uses \(g\): its four selected marked endpoints are all in \(D\), and matching the remaining \(|U|\) vertices of \(U\) to only \(|U|-2\) vertices of \(D\) requires the unique \(U\)--\(U\) edge. Note 086 then supplies, in **each** of the other four singleton classes, an actual matching avoiding \(g\); such a matching selects the \(U\) endpoint of mark \(h\). These are full-family constraints, not a BF-row synchronization.

## Fixed-profile exclusion of the two bipartite shapes

The preceding \(h(U)=2\) and \(h(U)=1,\ E=0\) shapes both have a same-side \(5+0\) bipartization and a singleton class fixed to one exceptional edge. In the first, every class-\(i\) singleton uses the \(U\)-side half of mark \(j\). In the second, every class-\(h\) singleton uses \(g\). [Note 168](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md) proves that full exact Case-XII support forbids **any** fixed singleton profile in a same-side \(5+0\) bipartization: an actual \((S)(T)\) row with a repeated singleton class has a mixed \(S\)-half, and five terminal-path switches around the \(S\)-pentagon reverse that class's exceptional-edge profile while keeping the complementary \(T\)-half fixed. Both shapes are therefore impossible. The surviving deficiency-two barriers satisfy
\[
\boxed{h(U)\le1;\quad h(U)=1\Longrightarrow E=2,\ a=b=0
\text{ and one five-cut odd component}.} \tag{7}
\]
The earlier double-bipartization and tight-transversal observations describe the now-excluded \(h(U)=2\) shape and should not be read as an additional open branch.

If \(h(U)=0\) and \(F-U\) has an even component \(K\), that component also has an exact form. The even cut \(\delta_J(K)\) has size at least four. Every edge of it consumes one unit of \(a+b\), whereas (3) gives \(a+b\le4\). Hence \(K\) is the **unique** even component, \(|\delta_J(K)|=4\), \(E=0\), and all odd components have three-edge cuts. Equality in the budget leaves no internal marked edge in \(K\) or in an odd component, and no \(F\)-edge inside \(U\). The odd components are therefore all singleton. The marked-cut inequality of Note 123 prohibits a cycle in \(J[K]\), since its cut has four edges and no internal mark. The cubic tree identity gives \(|K|=4-2=2\). Thus the only possible even component of any maximum barrier is one unmarked \(K_2\), with \(h(U)=0\) and every odd component singleton.

The apparent \(K_2\) profile is in fact impossible under exact Case XII. Put both vertices of \(K\) and all singleton odd components on the \(D\) side, and put \(U\) and all five marked subdivision vertices \(t_i\) on the other side. Every unmarked \(F\)-edge except the single edge of \(K\) crosses this bipartition: there is no \(F[U]\) edge and each odd component is singleton. Every marked edge has both endpoints outside \(U\), joins distinct \(F-U\) components, and is represented by two crossing half-edges through its subdivision vertex. Therefore deleting the unmarked edge of \(K\) makes the **entire proper graph of the five-pole bipartite**. This contradicts [Note 125's one-edge theorem](125-no-single-edge-bipartization-in-exact-case-xii.md). Hence no maximum Tutte barrier has an even component.

If \(h(U)=0\) and all odd components are singleton, (3) gives \(E=b=0,a=4\). Thus \(F[U]\) has exactly two edges, and deleting them makes the five-pole bipartite with all terminals on the \(U\) side. [Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md) forces these two edges to be disjoint. This is a surviving same-side \(5+0\) shape; Note 168 requires **all five** singleton classes to have both exceptional-edge profiles. The other \(h(U)=0\) possibilities have at least one non-singleton odd component and remain open.

## If \(U\) consists of one vertex

Let \(U=\{v\}\). Since \(F\) is connected and \(F-v\) has three odd components \(C_1,C_2,C_3\), the three edges of \(F\) at \(v\) go one to each component. Thus \(d_M(v)=0\) and there are no even components. Let \(d_i\) be the number of marked edges from \(C_i\) to the other two components, and \(m_i\) the number of marked edges internal to \(C_i\). The cubic parity of the odd set \(C_i\) makes \(1+d_i\) odd. Three-edge-connectivity gives \(1+d_i\ge3\), while five marked edges give \(d_i\le5\). Therefore \(d_i\in\{2,4\}\). If \(m_\times\) marks join distinct components, then
\[
(d_1,d_2,d_3)=
\begin{cases}
(2,2,2),&m_\times=3,\\
(4,2,2),&m_\times=4,\\
(4,4,2),&m_\times=5,
\end{cases}                                                   \tag{6}
\]
up to component order.

The first line is impossible. It leaves two internal marks. Any component with one internal mark is cyclic in \(J\), and the marked-cut inequality [Note 123, (5)](123-exact-case-xii-terminal-vertices-are-independent.md) would require \(3+m_i\ge5\), so the two internal marks must lie in one component. The other two components have no internal mark and three-edge boundary; the same inequality makes them acyclic, hence each is one vertex. The three crossing marks form a triangle on the contracted components. Its edge between the two singleton components, together with their two unmarked edges to \(v\), is a triangle in \(J\) containing just one marked edge, again violating Note 123.

In the second line, the unique internal mark lies in the degree-four component: a degree-two component with one internal mark would violate the same \(3+m_i\ge5\) inequality. Both degree-two components are singleton vertices. The four crossing marks consist of two edges from each singleton component to the degree-four component. If that last component is a tree in \(F\), the cubic degree count with one internal mark gives it five vertices, so \(|V(J)|=8\) and the five-pole has thirteen vertices. [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) excludes this. Thus, in an exact-Case-XII minimum host, its degree-four component must contain an unmarked cycle.

In the third line no mark is internal to a component. The degree-two component is one vertex. Three marked edges join the two degree-four components, and one joins each of them to the singleton component. If both degree-four components are trees in \(F\), each has three vertices, again giving a thirteen-vertex pole excluded by Note 100. At least one must therefore contain an unmarked cycle.

Consequently a one-vertex maximum Tutte barrier has only two surviving quotient profiles: \(4,2,2\) with two singleton odd components and one cyclic component containing the sole internal mark, or \(4,4,2\) with one singleton odd component and at least one cyclic component. These are necessary profiles, not constructions of exact Case XII. [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) normalizes an arbitrary minimum-cardinality maximum barrier and reduces its non-singleton shores to three all-orders profiles. The complete six-slot BF closure across those shores is still unresolved.
