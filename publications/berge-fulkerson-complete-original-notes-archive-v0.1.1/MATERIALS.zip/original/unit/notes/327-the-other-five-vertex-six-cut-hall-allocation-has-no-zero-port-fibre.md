> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other five-vertex six-cut Hall allocation has no zero-port fibre

Work in the noncollision, complete exact-Case-XII,
\(R_0=DJ\) near-bipartite branch of a completed minimum
host with girth at least five and a genuine right
\((ea)(ad)\) row. Suppose a tight six-cut Hall witness
has \(|S|=5\) and \((\alpha,\eta)=(1,2)\).
[Note 311](311-a-six-cut-hall-block-with-one-b-port-needs-five-b-vertices.md)
forces, up to names, the incidence graph
\[
\begin{array}{c|ccccc}
T&o&p&x&y&z\\\hline
N_S&uab&ucf&ac&af&bc
\end{array}                                                   \tag{1}
\]
with the sole proper \(B\)-port \(H\) based at \(u\),
both edges \(bd_D,fd_D\) present, and the \(J\)-port
based at \(j\in\{x,y,z\}\). The other proper \(B\)
ports lie outside \(S\). The two edges into \(d_D\)
are allowed because \(b,f\) have no common neighbour in
\(T\). Let \(r\in\{x,y,z\}\) be the vertex whose third
edge is selected by a zero-proper-port shore matching;
necessarily \(r\ne j\).

**Theorem.** The full zero-port shore fibre selecting
\(g,t_{ew}\) is empty in this placement. Since the genuine
right row requires such a matching, no five-vertex
\((\alpha,\eta)=(1,2)\) six-cut Hall block occurs.

**Proof.** A zero-port matching covers \(d_D\) by exactly
one of \(bd_D,fd_D\), and it must match \(o,p\) from
\(S\). Exactly one of \(x,y,z\) uses its third edge.
For \(r=x\), direct matching of these vertices gives
exactly the four block phases below, with the selected
third edge at \(x\) omitted:
\[
\begin{array}{c|l}
P_1&bd_D,uo,fp,ay,cz\\
P_2&bd_D,up,fy,ao,cz\\
P_3&fd_D,uo,ay,bz,cp\\
P_4&fd_D,up,ay,bo,cz.
\end{array}                                                   \tag{2}
\]
The pairs \(P_1,P_2\), \(P_1,P_3\), and
\(P_3,P_4\) differ, respectively, on the complete
alternating six-cycles
\[
 u-o-a-y-f-p-u,\qquad b-d_D-f-p-c-z-b,\qquad
 u-o-b-z-c-p-u.                                           \tag{3}
\]
Thus if one phase is an actual shore matching, all four
are actual with exactly the same edges outside this block,
including \(g,t_{ew}\). Since \(r=x\), the unselected
\(J\)-port is at \(y\) or \(z\). If \(j=y\), the
complement of \(P_1\) contains the complete path
\(D-d_D-f-y-J\). If \(j=z\), the complement of
\(P_4\) contains \(D-d_D-b-z-J\). Both pair \(D\)
with \(J\).

For \(r=y\), the four phases, with the selected third
edge at \(y\) omitted, are
\[
\begin{array}{c|l}
Q_1&bd_D,uo,fp,ax,cz\\
Q_2&fd_D,uo,ax,bz,cp\\
Q_3&fd_D,up,ax,bo,cz\\
Q_4&fd_D,up,ao,bz,cx.
\end{array}                                                   \tag{4}
\]
The pairs \(Q_1,Q_2\), \(Q_2,Q_3\), and
\(Q_3,Q_4\) differ on the complete alternating
six-cycles
\[
 b-d_D-f-p-c-z-b,\qquad u-o-b-z-c-p-u,\qquad
 a-x-c-z-b-o-a.                                          \tag{5}
\]
Hence every occupied \(r=y\) fibre contains \(Q_4\).
The complement of \(Q_4\) has the complete path
\[
                         H-u-o-b-d_D-D,                    \tag{6}
\]
regardless of whether \(j=x\) or \(z\). Reflection
\((a,b,o,y)\leftrightarrow(c,f,p,z)\) gives the
same conclusion for \(r=z\), with the reflected
\(H\)--\(D\) path.

For \(R_0=DJ\), [Note 285's full-fibre gate](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
allows a zero-port \((g,t_{ew})\) matching only the
complement pairings \(EA\mid ID\mid HJ\) and
\(EJ\mid AD\mid IH\). Neither pairs \(D\) with
\(J\) or \(H\). The actual matchings supplied by
the block-internal switches above contradict this gate
for each possible \(r\), completing the proof.
\(\square\)

Together with [Notes 311](311-a-six-cut-hall-block-with-one-b-port-needs-five-b-vertices.md),
[319](319-no-four-vertex-six-cut-hall-block-in-the-right-dj-branch.md),
and [326](326-cross-row-hj-switch-excludes-the-last-five-vertex-hall-block.md),
this gives the bound \(\lvert S\rvert\ge6\) for every
six-cut Hall witness in the stated noncollision branch.
It does not exclude six-cut Hall witnesses of that size,
Hall cuts of size eight or ten, incidence collisions, other shore
profiles, or the full Berge–Fulkerson conjecture. The
derivation is symbolic and awaits independent second-source
checking of its upstream complete-fibre gate. No local
computation or OMEN run was used.
