> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Carrier entry is residual parity and is not forced by global class flexibility

[Note 086](086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md)
shows that exact forty-type support prevents one proper edge from being
fixed in two singleton classes.  The resulting global avoiding matching
need not belong to the fixed half-load carrier in which an overload occurs.
Entry into that carrier has an exact residual degree-two criterion, and the
common-binary system of
[Note 085](085-common-binary-incidence-does-not-force-a-two-step-carrier-section.md)
strictly separates global class flexibility from carrier-restricted
flexibility.

## The carrier-entry criterion

Let \(H\) be a loopless cubic five-pole and fix a half-load

\[
 A=\chi_{Q_s}+\chi_{P_i}+\chi_{P_a},\qquad s=ia,                 \tag{1}
\]

where \(Q_s\) has triple boundary \([5]\setminus\{i,a\}\), while
\(P_i,P_a\) have singleton boundaries \(i,a\).  Thus \(A\) has incident
degree three at every internal vertex and load one on every semiedge.

For another \(P_i'\in\mathcal P_i\), put

\[
 D=A-\chi_{P_i'}.                                                \tag{2}
\]

There exist perfect matchings \(Q_s'\) and \(P_a'\) with

\[
 A=\chi_{P_i'}+\chi_{Q_s'}+\chi_{P_a'}                          \tag{3}
\]

if and only if all three conditions hold:

1. \(D\ge0\), equivalently \(P_i'\) uses no edge outside the support of
   \(A\);
2. every closed component of the residual degree-two multigraph \(D\) is
   even;
3. among its two terminal paths, the path from \(a\) to one member of
   \([5]\setminus\{i,a\}\) has even proper-edge length, while the path
   joining the remaining two members has odd proper-edge length.

Indeed, colour the residual copies contributed by \(Q_s'\) red and those
contributed by \(P_a'\) blue.  Every internal vertex has residual degree
two, so the colours must alternate on each component.  The semiedge at
\(a\) is blue, the three residual semiedges outside \(\{i,a\}\) are red,
and there is no residual copy at \(i\).  Alternation gives exactly the
parities above.  Conversely those parities allow every component to be
alternately coloured with its prescribed endpoint colours, producing the
two required perfect matchings.  Distinct residual components have no
further compatibility condition.

Define the oriented carrier fibre

\[
 \mathcal F_i(A;a)=
 \{P\in\mathcal P_i:A-P\text{ satisfies the three conditions above}\}.
                                                                    \tag{4}
\]

This is precisely the set of class-\(i\) singleton matchings occurring in
state-\(ia\) decompositions of the fixed half-load \(A\).

## What column saturation does not say

Under the absence of \(T\)-loops and \(T\)--\(T\) types,
[Note 055](055-half-load-column-saturation-and-case-xii-compression.md)
forces the state set of \(A\) to be all of \(S\).  It does not enlarge a
fixed oriented fibre (4) to the whole singleton class.  Likewise the row
transport of
[Note 057](057-overlap-cells-transport-singleton-fibres-into-d5.md)
preserves three displayed matching identities while changing the carrier;
it does not insert an arbitrary class matching into the original \(A\).

Consequently the global conclusion

\[
 e\notin\bigcap_{P\in\mathcal P_i}P                              \tag{5}
\]

does not formally imply the carrier-local conclusion

\[
 \mathcal F_i(A;a)\not\subseteq\{P:e\in P\}.                    \tag{6}
\]

The following countermodel shows that this is a genuine distinction at the
common-binary incidence level.

## A carrier-fixed coordinate with a globally flexible class

Use the frozen 125-token, 48-coordinate common-binary exact-forty system of
Note 085.  All five global singleton-class fixed sets are empty on its 43
proper coordinates.  Consider the canonical \((14,23)\) row and its left
half

\[
 L=\chi_{q_{14}}+\chi_A+\chi_C.                                 \tag{7}
\]

Coordinate \(e=29\), named `overload:ACXY`, is the unique coordinate at
which \(L\) has load two.  It is used by \(A\), of singleton class 1, and
\(C\), of singleton class 4.

Within the fixed token pool, the state-14 decompositions of this same
binary half-load are exactly

\[
\begin{aligned}
 L={}&\chi_{q_{14}}+\chi_A+\chi_C,\\
   ={}&\chi_{q_0}+\chi_{b_0}+\chi_{p_4},                         \tag{8}
\end{aligned}
\]

where the second row abbreviates the three frozen transport tokens from
the \((24,23)\) construction.  Hence the class-1 projection of the fixed
carrier fibre is \(\{A,b_0\}\), and both tokens use coordinate 29.  In
contrast, the global class 1 contains eleven tokens avoiding coordinate
29, including the frozen token \(b_1\).  Therefore

\[
 e\notin F_1,qquad
 e\in\bigcap_{P\in\pi_1\mathcal D_{14}(L)}P.                    \tag{9}
\]

Across the four canonical pivot rows, the same fixed-data calculation has
75 singleton/overload cases satisfying the global avoidance hypothesis;
41 of them are carrier-fixed.  One explicit instance (7)--(9) already
proves the non-implication.

The read-only calculation is frozen in the
[verification bundle](../computations/bundles/global-flexibility-does-not-force-carrier-entry/README.md).

## Consequence

The example is not a cubic pole: its coordinates have no common trivalent
vertex partition and its token pool is not a graph-induced full
perfect-matching closure.  It therefore does not refute carrier entry in a
real exact-Case-XII pole.  It does prove that exact forty support, the known
column saturation and row transports, common binary edge loads, and even
empty global fixed sets do not force (6).

The next positive statement must use a property of a common cubic
perfect-matching closure to force at least one of the three residual tests
for an avoiding matching inside the *same* carrier.  Until such
carrier-restricted flexibility is obtained, companion-phase intersection
is a strictly later obstruction and need not be attacked.
