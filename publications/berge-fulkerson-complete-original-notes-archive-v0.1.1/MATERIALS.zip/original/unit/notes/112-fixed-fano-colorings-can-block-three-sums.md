> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 112 — 非平凡三和也阻断给定五线着色的自同构拼接（2026-09-13，脉冲 3/5）

有限命题：两个给定五线着色的闭三正则图，删除一个顶点后任意配对三端口，总能仅用自同构得到五线三和。

**裁决：假。** 使用 Note 111 的同一个十顶点 H 及给定五线着色；左份删除顶点 0，右份删除顶点 1。按左边有序端口色 (1,6,7) 与右边 (2,4,6) 配对，即左外端点 (5,6,3) 依次连向右份外端点 (2,3,9)。

原来的每条线各出现两次，所以每侧删除一个顶点后仍恰有 S={167,246,257,347,356} 五条线。若并集至多五，则相对自同构须稳定 S，却又须把右边颜色 2 映至左边 1；Note 110 的点轨道排除此事。独立枚举得到在指定三端口约束下最小线并集恰为 6。

所得图有 18 个顶点，为 simple connected bridgeless cubic graph。连接两侧的三边是非平凡割：每侧九顶点十二内部边，连通且有环。每侧原有 Tait 着色的端口是三种不同颜色，经一个三色置换可匹配。因此整个图仍有一线 Fano 着色；这仍不是 F5 反例，也没有达到 R1 NOGO。

独立证据：`computations/fano-r1-20260913/check_graph.py` 逐点验证保留线集合，穷举 incidence 自同构并直接构造、核验该十八顶点图的一线着色；生成源及输入见 Note 111。复现：`python3 computations/fano-r1-20260913/check_graph.py`。

最薄弱一步：一般图全部重着色是否提供匹配状态仍未决。
下一命题：有限调色板接口是否保证“一侧一线、另一侧至多五线”的二和与三和保持？
