> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The opposite direct mixed prism root pair is impossible

In the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\), let an actual BF row have the forbidden \(e\,Cc\)-triple \(P\) rooted at \(c\) and the allowed \(e\,bc\)-triple \(R\) rooted at \(b\). Assume complete exact Case-XII support with forbidden \(e\)-labels \(Cc,ab\). [Note 400](400-the-opposite-mixed-prism-row-has-two-direct-escape-roots.md) forces the singleton-\(bc\) matching \(K\) to escape along a wholly exterior \(bc\)--\(AC\) path, through \(C\) or through \(A\). [Note 401](401-the-opposite-prism-c-route-is-impossible-at-all-shore-orders.md) excludes the \(C\)-route. The shore is arbitrary throughout.

> **All-order opposite-root exclusion.** The \(A\)-route is impossible as well. Hence no exact-Case-XII row contains this specified \(e\,Cc:c\) and \(e\,bc:b\) root pair, for either allowed pentagon orientation. This remains a root-pair exclusion, not a proof against the whole two-spoke-prism profile.

**Proof.** Suppose the \(A\)-route occurs:
\[
bc-t_{bc}-b-u_4-B-u_1-A-t_{AC}-AC.                    \tag{1}
\]
The zero-port triple masks of [Note 400, equation (1)](400-the-opposite-mixed-prism-row-has-two-direct-escape-roots.md) put both \(P,R\) on \(Cu_2\). Consequently the singleton-\(bc\) matching \(K\), which uses \(Bu_1,bu_4,AC:A\) on (1), cannot use \(Cu_2\) in a load-two row and must cover \(C\) through \(Cc:C\). It takes the terminal \(bc\), so it cannot use \(bc:c\) at the same subdivision; its vertex \(c\) is therefore covered by \(cu_5\). By [Note 230's singleton quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), a singleton-\(bc\) matching takes exactly two proper ports. The three tree halves \(Bu_1,bu_4,cu_5\) are already selected, so \(u_2,u_3\) are ports and \(a\) is covered by \(ab:a\). Thus the complete exterior mask of \(K\) is
\[
(u_1,u_2,u_3,u_4,u_5)=(B,p_2,p_3,b,c),\qquad
(AC,Cc,bc,ab)=(A,C,s,a).                                 \tag{2}
\]

Let \(J\) be the singleton-\(Cc\) matching and \(D_0,D_1\) the singleton-\(e\) occurrences. At \(C\), the two triples saturate \(Cu_2\); \(K\) uses \(Cc:C\), while \(J\) uses the \(Cc\) terminal, so \(J\) must use \(AC:C\). At \(c\), \(R,K\) saturate \(cu_5\), and \(J\) cannot use a half-edge of its own \(Cc\) terminal; therefore \(J\) uses \(bc:c\). At \(b\), \(P,K\) saturate \(bu_4\), and \(J\) already uses \(bc:c\); hence \(J\) uses \(ab:b\). The four marked subdivisions now force one of \(D_0,D_1\), call it \(D\), to use exactly
\[
AC:C,\qquad Cc:c,\qquad bc:b,\qquad ab:a.              \tag{3}
\]
Indeed, one singleton-\(e\) must take \(bc:b\); that same matching cannot take \(ab:b\), so it takes \(ab:a\). It cannot take \(bc:c\), and \(cu_5\) is saturated, so it takes \(Cc:c\). It then takes \(AC:C\), since the other half of \(Cc\) is unavailable within that matching. Since \(a,c\) are already matched at marks, \(D\) uses proper port \(p_5\).

Switch \(R,K\) along (1), producing an allowed \(e\,AC\)-triple \(R'\) rooted at \(A\). The switch never enters the shore, so \(R|_Z=R'|_Z\). Both triples retain the terminal \(Cc\) and the edge \(cu_5\), while \(D\) retains \(Cc:c\) and port \(p_5\). Thus **in both** \(R\triangle D\) and \(R'\triangle D\), the unique exterior arm from \(Cc\) ends at \(p_5\):
\[
Cc-t_{Cc}-c-u_5-p_5.                                   \tag{4}
\]
The shore \(e\)-path against \(D\) is identical for \(R,R'\); call its proper endpoint \(q\). Each full symmetric difference has three distinct exterior terminal arms, so \(q=p_5\) means its \(e\)-path ends at \(Cc\), while \(q\ne p_5\) means it does not.

For completeness, \(P,K\) saturate \(Bu_1\), so \(D\) covers \(B\) by \(Bu_2\) or \(Bu_4\); it covers \(A\) by \(Au_1\) or \(Au_3\). Following the other two exterior arms gives the complete check below. An entry is the proper port at the named terminal; the \(Cc\)-arm is \(p_5\) in every row.

| \(D\) at \(A\) | \(D\) at \(B\) | \(R\): \(AC\) | \(R\): \(ab\) | \(R'\): \(bc\) | \(R'\): \(ab\) |
|---|---|---|---|---|---|
| \(Au_1\) | \(Bu_2\) | \(p_4\) | \(p_3\) | \(p_4\) | \(p_3\) |
| \(Au_1\) | \(Bu_4\) | \(p_2\) | \(p_3\) | \(p_2\) | \(p_3\) |
| \(Au_3\) | \(Bu_2\) | \(p_4\) | \(p_1\) | \(p_4\) | \(p_1\) |
| \(Au_3\) | \(Bu_4\) | \(p_2\) | \(p_1\) | \(p_1\) | \(p_2\) |

In particular, neither of the other two arms meets \(p_5\), and no exterior arm joins two proper ports. Thus the shore \(e\)-path cannot leave and re-enter the shore before reaching a terminal.

The two possible Case-XII pentagons are
\[
S_{ab}=e-AC-ab-Cc-bc-e,\qquad S_{Cc}=e-AC-Cc-ab-bc-e. \tag{5}
\]
In \(S_{ab}\), keeping the forbidden \(P:e\,Cc\in T\) requires the \(e\)-path of \(R':e\,AC\) to end at \(ab\), the other \(S\)-neighbour of \(AC\). Hence \(q\ne p_5\). But the other \(S\)-neighbour of \(bc\) is \(Cc\), so the \(e\)-path of the original \(R:e\,bc\) must end at \(Cc\), requiring \(q=p_5\). Contradiction. In \(S_{Cc}\), the two requirements reverse: \(R'\) must reach \(Cc\), requiring \(q=p_5\), whereas \(R\) must reach \(ab\), requiring \(q\ne p_5\). Contradiction again. Every endpoint requirement follows by switching two complete matching occurrences while leaving the forbidden \(P\) unchanged; a wrong endpoint creates a genuine double-\(T\) BF row. Together with Note 401 this excludes both routes. \(\square\)

The core mechanism is one fixed terminal-to-port arm (4) shared by two allowed triple states whose exact-support selectors demand opposite shore endpoints. The theorem does not cover the other roots of \(e\,Cc,e\,bc\), other mixed labels, or full exact Case XII. The argument is hand-derived and awaits independent review.
