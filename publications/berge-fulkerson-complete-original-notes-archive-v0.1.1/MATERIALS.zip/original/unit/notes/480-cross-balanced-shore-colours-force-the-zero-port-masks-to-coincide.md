> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cross-balanced shore colours force the zero-port masks to coincide

[Note 479](479-ten-d2-hamilton-phases-force-forbidden-rows-and-six-need-cross-port-closure.md) leaves a precise multiplicity question in its \(D_2\) class IV. The old six-port signatures admit \(t=0,2\) in Note 479(16c), so port loads alone allow those candidate multiplicities; they do not establish a BF row. Here the **complete shore matching identities** and the exact-Case-XII zero-port condition close the route that reuses only the old complete shore matchings. They do not decide rows with a new complete shore matching.

## A shore matching lemma

Let a cubic six-port shore have a genuine six-colour BF row. Call two colours \(P,R\) zero-port and partition the other four colours into two pairs \(A=\{A_1,A_2\}\), \(B=\{B_1,B_2\}\). Suppose every shore port carries one \(A\)-colour and one \(B\)-colour. Write \(Q_c\) for the **complete** shore matching of colour \(c\). Then
\[
\boxed{\ \mathbf1_{Q_{A_1}}+\mathbf1_{Q_{A_2}}
       =\mathbf1_{Q_{B_1}}+\mathbf1_{Q_{B_2}}
       \quad\Longrightarrow\quad Q_P=Q_R.\ }                \tag{1}
\]
The equality is edgewise on the whole shore, not just on its ports.

To prove (1), inspect any shore edge. Its old BF label is one unordered pair of the six colours. Equality of the two sides gives that edge the same number of \(A\)- and \(B\)-colours. Since it has exactly two colours, its pair is either \(PR\) or one colour from each of \(A,B\). In particular, no edge carries \(P\) without \(R\), or \(R\) without \(P\). At every shore vertex the unique \(P\)-edge and unique \(R\)-edge therefore coincide. The same is true on the ports (both are absent), so the complete matchings \(Q_P,Q_R\) coincide. \(\square\)

This lemma only uses the actual common cubic incidence of the old row. A balance of the *numbers* of \(A\)- and \(B\)-port hits would not imply (1).

## Application to the two \(D_2\) class-IV multiplicities

In Note 479's class IV, put \(A=\{\sigma,K\}\) and \(B=\{\bar\sigma,J\}\). Its old port pairs are
\[
e=\sigma\bar\sigma,\quad
(p_1,p_2,p_3,p_4,p_5)
=(J\sigma,\sigma\bar\sigma,K\bar\sigma,
  \sigma\bar\sigma,KJ),                                      \tag{2}
\]
so every port indeed crosses \(A\mid B\). Let
\[
\mathcal A=\mathbf1_{Q_\sigma}+\mathbf1_{Q_K},\qquad
\mathcal B=\mathbf1_{Q_{\bar\sigma}}+\mathbf1_{Q_J}.
\]
For the old genuine BF row, with \(\mathbf2_E\) denoting load two on every shore edge, we have
\[
\mathbf1_{Q_P}+\mathbf1_{Q_R}+\mathcal A+\mathcal B
=\mathbf2_E.                                                 \tag{3}
\]
At \(t=0\) in Note 479(16c), the four singleton shore restrictions are \(Q_{\bar\sigma},Q_{\bar\sigma},Q_J,Q_J\), giving \(2\mathcal B\). At \(t=2\), they are \(Q_\sigma,Q_\sigma,Q_K,Q_K\), giving \(2\mathcal A\).

If the two zero-port shore restrictions in either proposed row are the **distinct** old masks \(Q_P,Q_R\), subtracting its load-two equation from (3) forces \(\mathcal A=\mathcal B\). Lemma (1) then forces \(Q_P=Q_R\), a contradiction. The only other way to use two zero-port masks from the old pair is to repeat \(Q_P\) or \(Q_R\).

Assume now that **every** zero-port shore matching leaves an odd closed complementary component. This is a necessary condition for exact Case XII in the fixed marked Hamilton exterior by [Note 359's prism-path consequence](359-two-root-parity-gate-and-k33-sharpness.md). [Note 230's shore completion criterion](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) then forbids two occurrences of one complete zero-port mask in any BF row. It also ensures that the old required row itself has \(Q_P\ne Q_R\). Under this condition, neither \(t=0\) nor \(t=2\) can be realized using only the six complete shore matchings selected by the old class-IV row, even with repetitions. At \(t=1\), the port pairs are the original labelled ones, and Note 479's root classification rules out all three forbidden \(e\)-sector types. We obtain the exact necessary boundary:
\[
\boxed{\begin{gathered}
\text{Any forbidden }[eX],\ [eY],\text{ or }(eX)(eY)\text{ row in the complete}\\
\text{support of a class-IV }D_2\text{ pole satisfying the odd-cycle}\\
\text{condition on every zero-port shore matching must use}\\
\text{at least one complete shore matching outside the old six-mask family.}
\end{gathered}}                                               \tag{4}
\]
The new matching in (4) could have an **old port signature**; the conclusion is about a complete shore mask. By contrast, Note 479(16a) requires at least two **new-signature occurrences** in class V.

The port-multiplicity alternative is genuine at shore level. In Note 479's six-cycle class-IV witness with \(\sigma=a\), the three old shore matchings \(Q_R,Q_b,Q_J\) partition all six shore edges and all six ports once; doubling them gives a shore BF row with \(t=0\) and \(Q_R\) repeated. Similarly \(Q_P,Q_a,Q_K\) partition the shore and give \(t=2\) with \(Q_P\) repeated. The witness has a forbidden \([eX]\) in its full support and is not exact Case XII. Thus (4) uses the **joint** exact-support condition on the same complete matching family; port incidence and a genuine old BF row alone do not supply it.

There is also a genuine pole satisfying the odd-cycle premise of (4) while retaining the forbidden loop. At the class-IV six-cycle vertex \(q_2\), whose incident pairs in Note 479(19) are \(PJ,RK,ab\), perform the support-preserving Petersen three-pole substitution of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md). The resulting 29-vertex cubic five-pole retains the old \(D_2\) row and the forbidden \([eX]\) boundary type, while every zero-port shore matching leaves an odd internal five-cycle in its complement. Its forbidden row therefore necessarily uses a complete shore matching outside the six selected by the old row, by (4). The substitution creates a cyclic three-edge cut, and the pole is not exact Case XII.

This closes one old-mask multiplicity mechanism in the residual \(D_2\) branch. It does not exclude class IV with new masks, class V with new signatures, the other \(D_i\), the \(P:X:1\) branch, other marked exteriors, exact Case XII overall, or Berge--Fulkerson. The proof is hand-derived, without OMEN or local mathematical recomputation, and awaits independent review. \(\square\)

Later boundary: [Note 481](481-the-two-old-signature-class-iv-loops-have-unique-exteriors-and-one-mask-switch-gates.md) shows that \(t=0\) has only the forbidden \([eY]\) exterior and \(t=2\) only \([eX]\), each uniquely doubled by role. It gives four edge-label switch gates that are necessary and sufficient for a forbidden row using exactly one new complete shore mask under the odd-complement premise.

Correction of the last sentence: [Note 485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md) proves that each of those one-new constructions repeats a complete singleton pole matching and therefore produces a Tait loop with a clean zero-port shore mask. Under the odd-complement premise the four gates are automatically false. The actual lower bound for a forbidden old-signature row is **two** new complete shore masks.
