> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case I

This note gives a boundary-action obstruction for one of the exact
five-cut cases of Mácajová--Mazzuoccolo--Tabarelli (MMT). It is conditional
only on the published Appendix transcription and its ordered semiedge
convention. It does not use graph generation or a higher-order census.

## Statement

Let (H_{mathrm I}) be the 25 boundary types listed for MMT Case I. No
real cubic 5-pole has complete Berge--Fulkerson support exactly
(H_{mathrm I}).

Consequently, conditional on the MMT 13-case enumeration and the previously
verified simultaneous-routing exclusions of Cases III, VI and XIII
(Note 046), the exact-connectivity-five candidate list loses Case I.

## Routing signatures and the transition lemma

Fix a labelled BF-colouring (arphi) of a cubic 5-pole. For each colour
pair (ab) whose boundary symmetric difference is nonempty, the
(ab)-subgraph has alternating boundary paths; let
(ho_arphi(ab)) be their endpoint pairing. The tuple of all these
pairings is the routing signature of (arphi).

If (P) is one (ab)-component and
(arphi'=arphi	riangle P), then:

1. the complete (ab)-component decomposition, hence its route, is
   unchanged;
2. every route for a colour pair disjoint from (ab) is unchanged;
3. the target boundary labels are obtained by the literal switch on the
   endpoints of (P).

No persistence rule is imposed on colour pairs overlapping (ab). Internal
alternating cycles are also omitted from the finite state system, which only
weakens the closure requirement.

For a type (	auin H_{mathrm I}), let (mathscr S_0(	au)) consist of
all route signatures satisfying the necessary one-switch conditions and all
commuting-switch conditions for disjoint colour pairs. A source switch is
allowed to target a signature only when the switched-pair route and all
disjoint-pair routes required by the three observations above persist.
Define (mathscr S_{r+1}) by deleting every state having a switch with no
target in (mathscr S_r). Any actual family of BF-colourings is a
post-fixed point of this operator, so it must lie in

[
mathscr S_infty(	au)=igcap_{rge0}mathscr S_r(	au).
	ag{1}
]

When a switched boundary labelling has several colour relabellings to the
fixed representative of its target type, all such relabellings are included
in the target relation. This stabilizer-complete canonicalisation is
necessary for (1) to be a genuine over-approximation of the actual action.

## Case-I fixed-point certificate

The 25 types of (H_{mathrm I}) yield 151 locally coherent signatures.
The greatest-fixed-point deletion is:

| round | type | deleted signatures |
|---|---|---:|
| 1 | ((13)(35)) | 4 |
| 1 | ((15)(35)) | 4 |
| 1 | ((23)(35)) | 4 |
| 1 | ((25)(35)) | 4 |
| 1 | ([35]) | 34 |
| 2 | ([35]) | 1 |

Thus

[
mathscr S_infty([35])=arnothing,
	ag{2}
]

although ([35]in H_{mathrm I}). The final round has a short certificate.
The sole ([35]) state surviving round one has, in the canonical boundary
labelling, routes

[
egin{array}{c|c}
02,03,12,13&14mid23\
04,05,14,15&15mid24\
24,25,34,35&35.
end{array}
	ag{3}
]

Switching (02) on path (14) can target only four states of type
((25)(35)), numbered (4,5,6,7), after all admissible canonical
relabellings are included. Each of those four states has a (13)-switch on
the same path (14) whose target is ([25]), but no target signature with
the required persistent routes. Hence the state (3) has no live successor,
proving (2).

By (1), an actual exact-(H_{mathrm I}) pole would have to supply a
nonempty (mathscr S_infty([35])), contradicting (2). Case I is therefore
impossible at the boundary-action level.

## Scope

This result removes only Case I. It does not address Cases II, IV, V, VII,
VIII, IX, X, XI or XII, and it does not touch the cyclically-6-connected
branch. It is not a proof of the Berge--Fulkerson conjecture. The exact
Appendix transcription remains an external input; the finite certificate is

`scratch/worker-mmtt-case-i-global-action/verify_case_i_global_kempe_action.py`

and ends with `CASE_I_GLOBAL_KEMPE_ACTION_EXCLUDED`.
