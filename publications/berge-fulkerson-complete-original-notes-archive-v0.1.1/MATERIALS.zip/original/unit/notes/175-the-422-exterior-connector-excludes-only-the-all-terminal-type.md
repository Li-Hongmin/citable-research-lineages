> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \((4,2,2)\) exterior connector excludes only the all-terminal boundary type

One of [Note 166's](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) one-vertex smallest-barrier profiles has a cyclic component \(C\), two singleton components \(w_1,w_2\), and \(U=\{u\}\). The unmarked edges join \(u\) once to each component. Four marked edges join \(C\) to the singletons: \(a,b\) meet \(w_1\), and \(c,d\) meet \(w_2\). The fifth marked edge \(e\) lies inside \(C\). This note gives the **exact six-slot gate for the seven exterior vertices** of the marked five-pole. It does not replace the graph-induced perfect-matching relation inside \(C\). [Note 178](178-the-two-five-cut-barrier-exclusion-confuses-the-core-with-the-minimum-host.md) explains why the other one-vertex profile remains open.

Subdivide \(a,b,c,d\) at their marked terminal vertices \(t_a,t_b,t_c,t_d\). The exterior consists of \(u,w_1,w_2,t_a,t_b,t_c,t_d\). Cut its five edges toward the shore: the unmarked edge \(h\) from \(u\) to \(C\), and the four \(C\)-side halves at \(t_a,\ldots,t_d\). The internal marked edge \(e\), its subdivision vertex, and terminal \(s_e\) stay on the \(C\) side.

## Exact gate for a fixed actual shore row

In six labelled matching slots \([6]\), write \(S_i\) for the two-slot label of terminal semiedge \(s_i\), and \(X_h,X_a,X_b,X_c,X_d\) for the two-slot labels on the five cut edges. For \(i\in\{a,b,c,d\}\), define
\[
W_i=[6]\setminus(S_i\cup X_i),\quad
F_1=[6]\setminus(W_a\cup W_b),\quad
F_2=[6]\setminus(W_c\cup W_d).
\]
The fixed shore row extends across all seven exterior vertices **if and only if**
\[
\boxed{\begin{aligned}
S_i\cap X_i&=\varnothing &&(i=a,b,c,d),\\
W_a\cap W_b&=\varnothing,\qquad W_c\cap W_d=\varnothing,\\
F_1\cap F_2&=\varnothing,\qquad
X_h=[6]\setminus(F_1\cup F_2).
\end{aligned}}                                                   \tag{1}
\]
Under (1), every displayed \(W_i,F_j\) is a two-set. The labels \(W_a,W_b,F_1\) partition the slots at \(w_1\), \(W_c,W_d,F_2\) do so at \(w_2\), and \(F_1,F_2,X_h\) do so at \(u\). At \(t_i\), the labels \(S_i,X_i,W_i\) partition \([6]\). Thus, slot by slot, the given **actual** shore perfect matchings and these forced exterior edges form actual perfect matchings of the whole marked pole; every edge has load two. Necessity follows from the same vertex partitions.

## Eliminate free port labels, without assuming a shore realization

Now prescribe only the five terminal two-sets \(S_a,S_b,S_c,S_d,S_e\), leaving all five shore port labels free. There exist two-set labels satisfying the exterior incidence equations (1) **if and only if**
\[
\boxed{S_a\cap S_b\cap S_c\cap S_d=\varnothing.}             \tag{2}
\]
Indeed, a slot in \(S_a\cap S_b\) uses both terminal semiedges at the \(w_1\) fork, so it must use the edge \(uw_1\): it belongs to \(F_1\). Likewise \(S_c\cap S_d\subseteq F_2\). Since \(F_1,F_2\) are disjoint at \(u\), (2) is necessary.

Conversely put \(L_1=S_a\cap S_b\) and \(L_2=S_c\cap S_d\). Under (2) they are disjoint and each has size at most two. Extend them to disjoint two-sets \(F_1,F_2\subset[6]\); there are six slots and four required positions, so this is always possible. Partition the four slots outside \(F_1\) into two two-sets \(W_a,W_b\), avoiding \(S_a,S_b\), respectively. This is possible because the only slots forbidden to **both** choices lie in \(S_a\cap S_b\subseteq F_1\): slots of \(S_a\setminus S_b\) are forced to \(W_b\), slots of \(S_b\setminus S_a\) to \(W_a\), and each forced group has size at most two. Fill the remaining capacities arbitrarily. Do the same at \(w_2\) with \(F_2,S_c,S_d\). Set \(X_i=[6]\setminus(S_i\cup W_i)\) for the four marks and \(X_h=[6]\setminus(F_1\cup F_2)\). These are two-sets and satisfy (1). This proves sufficiency **at the exterior-incidence level**; no perfect matching inside \(C\) has been asserted.

In a BF pair or loop type, each slot has one or three terminal semiedges, so (2) holds automatically. In the all-terminal type, its five-boundary slot lies in all four displayed terminal sets, so (2) fails. Therefore the free-port exterior gate admits all \(55\) pair/loop boundary types and excludes exactly the all-terminal type. It makes no distinction between the \(40\) allowed and \(15\) forbidden pair/loop types of exact Case XII. Any such distinction must come from **the complete actual six-matching relation of the cyclic shore with its internal marked terminal \(e\)**, coupled to the fixed-port gate (1). An abstract choice of the free labels in (2) is not a graph realization or a counterexample to exact Case XII.
