> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two B-side core ports force an S-Tait state

Continue the central-path profile of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) and the unmarked near-bipartite core of [Notes 282–285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md). Write its six shore ports as
\[
E=e,\quad A=a:\Sigma,\quad I=h_1,\quad D=h_2,\quad H=h_3,\quad J=h_4.
\]
Suppose deleting the unmarked core edge \(g\) makes the core bipartite, with \(g\) internal to side \(B\), \(|B|-|R|=1\), and the internal marked edge running from \(v\in B\) to \(w\in R\). Exactly three proper shore ports are based in \(B\). Assume complete exact-Case-XII support, including its absent \(T\)-loops, and either one of the forced real \((ea)(ad)\) or \((ea)(ac)\) rows.

**Theorem.** If exactly two of \(A,I,D\) are based in \(B\), then the five-pole has a genuine three-edge-colouring. Its Tait-state set is precisely the allowed pentagon \(S\). Consequently, in the whole unmarked-one-edge-near-bipartite branch, a Tait-empty exact-Case-XII pole can only have the \(3{:}2\) cut profile with **exactly one** of \(A,I,D\) based in \(B\); both \(H,J\) are then based in \(B\), and every zero-port shore matching selects \(t_ev\) and avoids \(g\).

## A marked singleton with \(g\) gives a colouring

Let \(M\) be either singleton-\(a\) occurrence \(Y_a,V_a\) in the forced row. Both use the same exterior mask \(Y_L\) and the proper shore ports \(H,J\). When two of \(A,I,D\) are in \(B\), exactly one of \(H,J\) is in \(B\) and the other is in \(R\). Put \(h(M)=1\) when \(M\) selects \(t_ew\), and \(z(M)=\mathbf1_{g\in M}\). [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) becomes \(z(M)=h(M)\).

Suppose \(h(M)=1\). The whole five-pole is bipartite after deletion of \(g,t_ew\) and the two proper shore cut edges based in \(R\). The matching \(M\) uses \(g,t_ew\) and the one \(R\)-based cut edge among \(H,J\). Only the other exceptional cut edge, at a port \(q\in\{A,I,D\}\), remains in its complement.

The exterior complement of the displayed \(Y_L\) mask has four terminal-to-shore arms
\[
e\longleftrightarrow E,\qquad
b\longleftrightarrow I,\qquad
c\longleftrightarrow A,\qquad
d\longleftrightarrow D.                                  \tag{1}
\]
Here the \(b\)-arm uses \(1A\) and \(h_1\), the \(d\)-arm uses \(2B\) and \(h_2\), while the \(c\)-arm runs through \(4E,4D,3D,3C,a:C,a:\Sigma\). Thus these are all exterior complement components, rather than merely four selected routes.
The shore complement of \(M\) pairs \(E,A,I,D\) in two paths. Therefore its remaining exceptional cut edge \(q\) lies on a terminal path, irrespective of that shore pairing. Every closed component of the complete complement avoids all four bipartition exceptions and is even. Alternating the two other colours along its paths and cycles extends \(M\) to a genuine Tait colouring. Exact support has no \(T\)-loop, so its state lies in \(S\); terminal-path Kempe switches give every state of \(S\), as in [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md).

In fact the same complete singleton matching \(M\) has a **forced shore-complement pairing**
\[
\boxed{EI\mid AD.}                                         \tag{2}
\]
In every three-edge-colouring extending the singleton-\(a\) matching, one of the other two colours occurs once at the terminals and the other three times. Of the two terminal paths in the complement, exactly one has differently coloured endpoints. Flipping those two colours along this path changes which endpoint carries the second singleton colour, so both its endpoints give Tait states incident to \(a\). The only allowed such states are \(ae,ab\); hence that path must join \(e\) to \(b\). The four arms (1) give (2). Moreover, all five terminal vertices lie on the \(R\) side of the displayed bipartition. A terminal path contains an odd number of proper edges precisely when it traverses the sole remaining \(R\)--\(R\) exception \(q\), and then its terminal colours agree. Thus \(q\) must lie on the \(c\)--\(d\) path, so \(q\in\{A,D\}\). In particular, when the sole \(R\)-based port among \(A,I,D\) is \(I\), no singleton-\(a\) occurrence can select \(t_ew\).

## The row cannot avoid both colouring mechanisms

If either \(Y_a\) or \(V_a\) selects \(t_ew\), the preceding argument finishes the proof. Otherwise both select \(t_ev\). The two triple occurrences \(Z_e,U_t\) select the terminal port \(E\), hence neither uses a half of the internal mark. Since the six-matchings row loads each half \(t_ev,t_ew\) exactly twice, its remaining slots \(X_a,W_t\) must **both** select \(t_ew\). In particular the zero-port shore matching \(X_a\) has the second profile \((t_ew,g\in X_a)\) by [Note 282's zero-port balance](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md). [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md) then gives an actual \(ea\)-Tait colouring. This proves the first assertion.

For the consequence, [Note 282](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md) already forces \(S\)-Tait in its \(4+1\) cut profile. In the \(3{:}2\) profile, the four-port slot \(Z_e\) forces the number of \(B\)-based ports among \(A,I,D\) to be one or two by Note 283. The theorem eliminates two when Tait is empty. The remaining port sides and zero-port fibre follow from the same balance equation and Note 285. \(\square\)

## Independent check of Note 285's six-port table

The two forbidden \(eb\) exterior masks in Note 285 add respectively \(ID\mid AH\) with terminal arms at \(E,J\), and \(AD\mid HJ\) with terminal arms at \(E,I\). Pair the six shore port *positions* in all fifteen ways. The twelve discarded pairings are
\[
\begin{gathered}
EA\mid IH\mid DJ,\ EA\mid IJ\mid DH,\quad
EI\mid AD\mid HJ,\ EI\mid AJ\mid DH,\\
ED\mid AI\mid HJ,\ ED\mid AH\mid IJ,\ ED\mid AJ\mid IH,\\
EH\mid AI\mid DJ,\ EH\mid AD\mid IJ,\ EH\mid AJ\mid ID,\\
EJ\mid AI\mid DH,\ EJ\mid AH\mid ID.
\end{gathered}
\]
Each puts all five proper ports in one complement component under at least one of the masks, so it cannot separate the two \(R\)-based exceptions under both. The other three have the following component partitions on the proper ports:
\[
\begin{array}{c|c|c|c}
\sigma&eb\text{ mask }P_0&eb\text{ mask }P_1
  &\text{exception pairs separated by both}\\\hline
EA\mid ID\mid HJ&\{I,D\}\mid\{A,H,J\}&\{H,J\}\mid\{A,D,I\}
  &IH,IJ,DH,DJ\\
EI\mid AH\mid DJ&\{A,H\}\mid\{I,D,J\}&\{I\}\mid\{A,D,H,J\}
  &AI,IH\\
EJ\mid AD\mid IH&\{J\}\mid\{A,D,H,I\}&\{A,D\}\mid\{H,J,I\}
  &AJ,DJ.
\end{array}                                                   \tag{3}
\]
This reproduces every entry of Note 285's table without graph enumeration. Its \(ea\) completion joins the four ports \(I,J,D,H\) into one closed component in the first line of (3), which contains both exceptional edges; in the other two lines all six ports lie on the \(e\)--\(a\) terminal path. Thus the closed-cycle parity conclusion used above is valid for every surviving pairing.

## The surviving Tait-empty profile traps \(g\) in every singleton complement

Suppose instead that exactly one of \(A,I,D\) is in \(B\), so \(H,J\in B\) and both \(R\)-based exceptional cut edges are among \(A,I,D\). The same balance equation forces **every** shore matching with port set \(\{H,J\}\) to select \(t_ew\) and avoid \(g\). Glue any such matching to the actual \(Y_L\) exterior mask. In its complement, \(t_ew\) is absent, both exceptional cut edges belong to terminal paths by (1), and \(g\) is the only possible bipartition exception on a closed component. Consequently
\[
\boxed{\text{this singleton-}a\text{ matching extends to a Tait colouring}
\iff g\text{ lies on a terminal path of its complement}.}       \tag{4}
\]
Indeed, if \(g\) lies on a terminal path, all closed components are even; if \(g\) lies on a closed component, that cycle is odd. Every closed component lies wholly in the shore because the exterior complement consists of the four arms (1). Complete matching closure allows every \(\{H,J\}\)-port shore matching to be glued to the fixed \(Y_L\) exterior. Thus a Tait-empty pole in the remaining profile must trap \(g\) in a **closed odd shore cycle** of the complement of *every* such matching, including both distinct singleton-\(a\) occurrences in each required row.

There is a further rowwise consequence. In any six-matching BF row, let \(Y,V\) be two occurrences of the same singleton class, and let \(C_Y\) be an odd closed cycle in the complement of \(Y\). The alternating-cycle system \(Y\triangle V\) must use an edge of \(C_Y\). Otherwise \(Y,V\) choose the same third edge at every vertex of \(C_Y\); those edges are already loaded twice, so each of the other four matching occurrences would have to perfectly match the odd cycle using only its own edges, which is impossible. At a vertex where \(Y,V\) differ, \(V\) selects a cycle edge of \(C_Y\), proving the asserted edge intersection.

Apply this to \(Y_a,V_a\) in either required row. Their respective complements each contain exactly one odd closed cycle, say \(C_Y,C_V\), and both cycles contain \(g\). The preceding argument makes \(Y_a\triangle V_a\) use an edge of each cycle. Because both singleton matchings avoid \(g\), these intersection edges differ from \(g\). Moreover \(V_a\) selects an edge of \(C_Y\), so \(C_Y\ne C_V\). Hence the unmarked core has **at least two distinct odd cycles through \(g\)**, or equivalently at least two distinct paths between the ends of \(g\) after deleting it. In particular a core with a unique cycle through \(g\) cannot realize the Tait-empty profile. This condition is independent of the rowwise intersections with both pure paths already forced by [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md).

The theorem and (4) alone do not exclude the remaining one-\(B\)-port Tait-empty profile; [Note 287](287-unmarked-near-bipartite-central-cores-force-s-tait.md) closes it by a different singleton-complement argument. Neither result excludes the \(S\)-Tait profile, higher-rank cores, or failure of the required four-slot load intersection. The forced central-path row templates remain hand proofs requiring independent verification against the complete graph-induced matching family. No graph or perfect-matching census was run here.
