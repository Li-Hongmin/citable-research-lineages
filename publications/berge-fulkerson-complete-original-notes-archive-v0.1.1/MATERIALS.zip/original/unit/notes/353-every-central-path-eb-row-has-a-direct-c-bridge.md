> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every central-path \((ea)(eb)\) row has a direct \(e\to c\) bridge

> **Later consequence:** [Note 354](354-the-right-eb-row-forces-a-forbidden-double-t-completion.md) excludes the right \(Y_R,U_A\) row; [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) excludes the remaining left \(Y_L,U_D\) row under the classifications used here. The right-row shore-fibre calculations below retain their conditional meaning.

Work in the central-path exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact-Case-XII perfect-matching support. Write the allowed and forbidden state pentagons as
\[
 S=e-a-b-d-c-e,\qquad T=\{eb,ed,ac,ad,bc\}.
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) has no BF type joining two states of \(T\). In every required \((ea)(eb)\) row, the state-\(eb\) triple has one of [Note 340's](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md) two zero-port exterior masks \(U_A,U_D\).

**Switching-trap lemma.** Suppose an actual \((ea)(eb)\) row uses \(U_A\), and one of its singleton-\(e\) matchings \(E_e\) has exterior entries \(a:\Sigma,b:D,3C\). Assume its \(e\)-path in \(U_A\triangle E_e\) ends at \(a\), and the \(b\)-path in \(U_A\triangle W_b\) ends at \(q\in\{c,d\}\) wholly outside the shore. Then the complete matching closure contains a forbidden \(T\)--\(T\) BF row.

**Proof of the lemma.** Exchange the two complete singleton-\(e\) occurrences if necessary so the row is
\[
 X_{ea}+Y_a+F_e+U_{A,eb}+E_e+W_b=2\mathbf1 .       \tag{1}
\]
The fixed zero-port state-\(ea\) triple is
\[
\begin{aligned}
 X|_{\rm ext}&=\{a:C,1A,2B,3D,4E;\ b,c,d\},\\
 U_A|_{\rm ext}&=\{b:A,1B,2C,3D,4E;\ a,c,d\}.
\end{aligned}                                               \tag{2}
\]
Switch the complete exterior \(b\)--\(q\) component of \(U_A\triangle W\). The new singleton is \(q\); the new triple \(U'\) still selects terminal \(a\) and has exactly the same shore restriction as \(U_A\). Since the \(a\)-arm of \(U_A\triangle E\) uses \(a:\Sigma\), its \(e\)--\(a\) path has shore segment \(E\)--\(A\). The first switch changes neither this shore segment nor its \(a\)-arm. Switching the surviving \(e\)--\(a\) path of \(U'\triangle E\) therefore produces an actual singleton-\(a\) matching \(A'_a\). The other half now has state \(ac\) when \(q=c\), or \(ad\) when \(q=d\); both are in \(T\). On the exterior, the second switch replaces only \(e_{\rm term},a:\Sigma\) in \(E_e\) by \(a_{\rm term}\), so \(A'_a\) retains \(b:D,3C\).

Exchange the complete singleton-\(a\) occurrences \(Y_a,A'_a\) across the two halves. This preserves every edge load and leaves a real \((ea)(ac)\) or \((ea)(ad)\) row whose first half contains \(X_{ea}+A'_a+F_e\). But the following is one complete alternating component of \(X\triangle A'\), entirely outside the shore:
\[
 a_{\rm term}(A'),\ a:C(X),\ 3C(A'),\ 3D(X),\
 b:D(A'),\ b_{\rm term}(X).                           \tag{3}
\]
The edges meet successively at \(t_a,C_{\rm ext},u_3,D_{\rm ext},t_b\). Switching (3) changes the first-half state from \(ea\) to \(eb\), without changing the opposite state. It yields forbidden \((eb)(ac)\) or \((eb)(ad)\), respectively. \(\square\)

**Direct-bridge theorem.** Conditional on the hand-derived exterior and phase classifications of [Notes 271 and 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md), every genuine central-path \((ea)(eb)\) row has, **before any singleton-cycle switch**, an \(e\to c\) path in \(U\triangle Z_e\) or \(U\triangle V_e\). The assertion holds in every one of its zero-port phases.

**Proof.** [Note 346's endpoint table](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md) already gives a direct \(e\to c\) path in every left \(Y_L,U_D\) row. It remains to exclude an \(e\to a\) mask in a \(U_A\) row.

The needed \(e\to a\) endpoint for any \(U_A\) mask containing \(a:\Sigma,b:D,3C\) can be checked without the rest of that table. Exchange the two complete singleton-\(e\) occurrences so this mask is in the pure \(ea\) half. The exterior \(b\)-arm of \(X\triangle E\) is
\[
 b_{\rm term}(X),\ b:D(E),\ 3D(X),\ 3C(E),\
 a:C(X),\ a:\Sigma(E),                                  \tag{4}
\]
ending at shore port \(A\). Purity forces the \(e\)-path of \(X\triangle E\) to end at \(b\), since switching it must keep the other singleton \(a\) in the allowed pentagon. Hence the shore path from \(E=e\) pairs with \(A\). Independently switching all shore-internal alternating cycles of \(X_\Sigma\triangle U_\Sigma\) exchanges their complete shore restrictions while leaving their exterior masks and the BF row intact. Applying the same purity argument to this switched row gives the same \(E\)--\(A\) pairing for the original \(U_\Sigma\). The \(a\)-arm of \(U\triangle E\) runs from \(A\) through \(a:\Sigma\) to terminal \(a\), so its \(e\)-path indeed ends at \(a\). This also verifies the endpoint in every zero-port phase.

For a left \(Y_L,U_A\) row, \(X,W_b\) use the \(b\) terminal semiedge, while \(U_A\) uses \(b:A\) and \(Y_L\) uses \(b:D\). The two singleton-\(e\) occurrences must therefore split \(b:A,b:D\). Among [Note 271's pure-left masks](271-the-central-path-row-requires-two-distinct-shore-masks.md), the \(b:D\) mask is either II \(a:\Sigma,3C,4E\) or IV \(a:\Sigma,1A,3C\). The II mask would overload \(4E\), already used by \(X,U_A\), so the IV mask is forced and the other occurrence has orientation I. Equation (4) and the zero-port phase exchange above give the IV matching an \(e\to a\) path in \(U_A\triangle E_e\). At the marked \(c\)-vertex, \(X,U_A\) use its terminal semiedge, the two singleton-\(e\) masks use \(c:E\), and \(Y_L\) uses \(c:A\). Load two therefore forces \(c:A\in W_b\). Since \(b:A\in U_A\), the complete wholly exterior \(b\)--\(c\) component is
\[
 b_{\rm term}(W),\ b:A(U_A),\ c:A(W),\ c_{\rm term}(U_A). \tag{5}
\]
The lemma with \(q=c\) excludes every such left row.

For a right \(Y_R,U_A\) row, each \(e\to a\) singleton-\(e\) mask in Note 346 is III with \(a:\Sigma,3C,b:D,c:A,d:E\). Because \(Y_R\) also uses \(3C\), the other singleton-\(e\) mask cannot use \(3C\). It is either a III mask with \(c:A,d:E\), or the IV mask with \(c:E,d:B\). In the III case the two singleton-\(e\) occurrences saturate \(c:A,d:E\); edge load two then forces \(1A,d:B\in W_b\). Together with \(b:A,1B\in U_A\), these edges give the wholly exterior \(b\)--\(d\) component
\[
 b_{\rm term}(W),\ b:A(U_A),\ 1A(W),\ 1B(U_A),\
 d:B(W),\ d_{\rm term}(U_A).                              \tag{6}
\]
In the IV case \(Y_R\) and that IV mask saturate \(c:E\), forcing \(c:A\in W_b\), so (5) applies. Thus the lemma excludes every right row containing an \(e\to a\) mask.

The remaining right masks have endpoint \(c\) or \(d\). The latter is the unique IV type; two copies would overload \(c:E\), already selected by \(Y_R\). Hence at least one of the two singleton-\(e\) occurrences has endpoint \(c\). [Note 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md) proves that each endpoint is invariant under all zero-port cycle-phase switches. This proves the theorem. \(\square\)

**Right-row normalization.** In fact every surviving right row contains the same singleton-\(e\) exterior mask
\[
             E_0=\mathrm{III}:a:C,2B.                       \tag{7}
\]
The other singleton-\(e\) mask is either \(\mathrm{III}:a:\Sigma,1B,2C\) or \(\mathrm{IV}:a:\Sigma,1A,2C\). If the former occurs, one wholly exterior closed six-cycle switch with \(W_b\) gives the latter while preserving \(E_0\), both zero-port shore matchings and the BF load. Thus **every** actual right row has, in its complete matching closure, a right row with the canonical unordered pair \(\{E_0,\mathrm{IV}:a:\Sigma,1A,2C\}\). This is a normalization of the right row's exterior, not an existence theorem for its shore.

To see exhaustiveness, the three remaining right \(e\to c\) masks in Note 346 are III \(a:C,1B\), III \(a:C,2B\), and III \(a:\Sigma,1B,2C\); the only \(e\to d\) mask is IV \(a:\Sigma,1A,2C\). With two III \(e\to c\) masks, they cannot both use \(a:C\), already used by \(X\), nor both use the \(a:\Sigma,1B,2C\) mask, because \(U_A\) uses \(1B\). That mask cannot pair with III \(a:C,1B\) for the same \(1B\) reason. Hence the pair contains \(E_0\). With an IV partner, III \(a:\Sigma,1B,2C\) would overload \(2C\) together with \(U_A\) and IV. The remaining III \(a:C,1B\) differs from IV on the wholly exterior alternating six-cycle
\[
 c:A(\mathrm{III}),\ 1A(\mathrm{IV}),\ 1B(\mathrm{III}),\
 d:B(\mathrm{IV}),\ d:E(\mathrm{III}),\ c:E(\mathrm{IV}). \tag{8}
\]
Switching it turns that III matching into IV \(a:C,1A\), which [Note 271's pure-side table](271-the-central-path-row-requires-two-distinct-shore-masks.md) allows on neither side. Exchanging the complete singleton-\(e\) occurrences if necessary puts this forbidden mask in the \(ea\) half opposite an \(eb\in T\) half, a contradiction. Thus the III partner is \(E_0\).

For the two remaining pairs, edge load two forces respectively
\[
\begin{array}{c|l}
\text{other }e\text{-mask}& W_b|_{\rm ext}\\\hline
\mathrm{III}:a:\Sigma,1B,2C&\{a:\Sigma,c:E,d:B,1A,3C,4D,h_2;\ b\}\\
\mathrm{IV}:a:\Sigma,1A,2C&\{a:\Sigma,c:A,d:E,1B,3C,4D,h_2;\ b\}.
\end{array}                                                \tag{9}
\]
In the first line, the III matching and \(W_b\) use alternating edges of the same exterior cycle as (8), with \(c:A,1B,d:E\) in III and \(1A,d:B,c:E\) in \(W_b\). Switching this complete component produces exactly the second line and the IV mask, without touching \(E_0\) or the shore. \(\square\)

**The surviving right third-identity fibre.** Normalize the right row to the IV line of (9), and put \(E_0\) in the \(eb\)-half by exchanging the two complete singleton-\(e\) occurrences if needed. The exterior difference \(U_A\triangle E_0\) has four terminal-to-shore arms: \(e\to E\), \(c\to H\) through
\[
 c_{\rm term}(U_A),\ c:A(E_0),\ b:A(U_A),\ b:D(E_0),\
 3D(U_A),\ h_3(E_0),                                  \tag{10}
\]
and \(a\to I,d\to J\). The phase-invariant \(e\to c\) endpoint pairs \(E,H\) in the shore. Switching that complete path in \(E_0\), with any additional shore-internal closed components, gives singleton-\(c\) candidates with the common exterior mask
\[
 C_c|_{\rm ext}=\{a:C,b:A,d:E,2B,3D,h_1,h_4;\ c\},\qquad
 \partial_\Sigma C_c=\{I,J\}.                         \tag{11}
\]
No optional closed switch changes this mask, since the other exterior arms end at \(I,J\) and every closed difference component is inside the shore.

The swapped pure half-load \(P^0=X+Y_R+E_0\) has an actual \(ea\)-decomposition. Whenever a candidate (11) is contained edgewise in \(P^0\), the exterior part of \(P^0-C_c\) has no closed component and has exactly the terminal arms
\[
\begin{array}{c|c|l}
e&E&\text{none}\\
a&H&a:C,3C,h_3\\
b&I&b:D,4D,4E,c:E,c:A,1A,h_1\\
d&D&d:B,2B,h_2.
\end{array}                                                \tag{12}
\]
Exterior containment is automatic from (11); only shore edges can fail it. By [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md), this candidate synchronizes the third singleton identity precisely when every closed component of its shore residual is even. Success then forces the residual shore pairing \(ED\mid HI\). Thus the right direct-bridge question now concerns a genuine \(IJ\)-port singleton-\(c\) fibre, replacing the \(AJ\)-port fibre of [Note 350](350-the-right-bridge-third-identity-is-an-aj-shore-fibre.md), which came from the excluded no-\(c\) branch.

**A forced identity-level overload if this fibre synchronizes.** Suppose (11) passes the shore containment and even-residual tests, and let \(D_d\) be the singleton-\(d\) matching in any resulting \(cd\)-decomposition of \(P^0\) retaining this same complete \(C_c\). Along the \(b\to I\) arm in (12), terminal \(b\) has the triple colour, so \(b:D\) and \(h_1\) have the singleton-\(d\) colour. Alternating along the other arms gives the phase-independent exterior mask
\[
 D_d|_{\rm ext}=\{a:C,b:D,c:A,2B,4E,h_1,h_3;\ d\}. \tag{13}
\]
The retained IV singleton-\(e\) matching \(F_e\) uses \(b:D\), while (11) gives \(h_1\in C_c\). Hence
\[
 b:D\in D_d\cap F_e,\qquad h_1\in D_d\cap C_c.          \tag{14}
\]
The exterior hitting lemma of [Note 352](352-every-singleton-a-matching-hits-the-right-bridge-d-e-pair.md) says every complete singleton-\(a\) matching uses \(b:D\) or \(h_1\). Therefore **no** five-singleton tuple retaining these complete \(C_c,D_d,F_e\) identities can have load at most two, irrespective of its singleton-\(a\) and singleton-\(b\) choices. The displayed \(Y_R\) gives the \(\{a,c,d\}\) three-hit signature at \(h_1\); changing only the \(a\)-matching moves or preserves a three-hit rather than repairing the tuple. This statement is conditional on a successful third identity and does not exclude the row or the full pole.

**Odd complement required in the entire \(IJ\) fibre.** The exterior mask (11) is in fact the **unique** singleton-\(c\) exterior matching with shore ports \(I,J\), whether or not it comes from this row. Terminal \(c\) and ports \(h_1,h_4\) force, successively, \(b:A,3D,d:E,2B,a:C\) at the five central path vertices; their other incident choices are unavailable. Its full edge complement therefore contains the wholly exterior \(b\)--\(d\) path with eight proper edges
\[
 b:D,4D,4E,c:E,c:A,1A,1B,d:B,                       \tag{15}
\]
as well as the exterior port path \(D\)--\(H\) through \(h_2,2C,3C,h_3\), and terminal arms \(e\to E,a\to A\). There is no exterior closed component.

If every closed component of this complement were even, it would split into the other two colours of a genuine Tait colouring with singleton \(c\). The even-proper-length \(b\)--\(d\) path has different terminal colours at \(b,d\). Parity of the odd-order five-pole then makes the \(a\)--\(e\) terminal path odd in proper length, so its two terminal colours agree. Exchanging the two colours on the \(b\)--\(d\) path produces **both** Tait states \(bc\) and \(cd\); \(bc\in T\) is forbidden. Therefore every actual \(IJ\)-port singleton-\(c\) matching in an exact-Case-XII pole has an **odd closed component in its full complement**. That odd component is shore-internal, or uses the exterior \(D\)--\(H\) segment when the shore complement pairs \(D,H\). This is compatible with an even residual \(P^0-C_c\): the two degree-two loads differ on the \(0/2\) defect of \(P^0\), so no contradiction follows without coupling them.

That coupling has a precise necessary intersection. Let \(\Omega(P^0)=\{f:P^0(f)\ne1\}\). Since the BF row bounds every load by two, each nonunit internal vertex has incident loads \((0,1,2)\); hence \(\Omega(P^0)\) is a union of even cycles alternating load zero and two. Its forced exterior segment runs from port \(A\) to port \(I\) along
\[
 a:\Sigma\ (0),\ a:C\ (2),\ 2C\ (0),\ 2B\ (2),\
 1B\ (0),\ h_1\ (2),                               \tag{16}
\]
and closes through an alternating shore \(A\)--\(I\) path; any other defect cycles are shore-internal. If \(C_c\le P^0\), the full complement \(\mathbf1-C_c\) and residual \(P^0-C_c\) agree off \(\Omega(P^0)\). An odd closed component of the complement disjoint from this defect would persist unchanged in the residual. Therefore **successful third-identity synchronization forces every odd complement cycle to meet \(\Omega(P^0)\)**. This is an exact parity-transfer requirement on the real \(IJ\) shore fibre, not by itself an obstruction to it.

For clarity about the earlier conditional right-bridge calculation, take the no-\(c\) right pair of [Note 347](347-a-right-eb-row-forces-a-c-bridge-after-one-exterior-switch.md) and perform its exterior \(Z_e\)--\(W_b\) six-cycle switch. In that hypothetical row, (6) switches \(U_A,W'_b\) to a genuine singleton-\(d\) mask
\[
 D'_d|_{\rm ext}=\{a:C,b:A,c:E,1B,4D,h_2,h_3;\ d\}, \tag{17}
\]
which avoids \(b:D,h_1\). This is a correct conditional mask identity, but the original row is already excluded by the theorem. The direct five-tuple \(Y_R,W'_b,C_c,D'_d,V_e\) would have four exterior triple hits, \(b:A,c:E,4D,h_2\); the earlier three-edge list missed \(b:A\).

The result strengthens Note 347: an actual right row needs no preliminary exterior switch to reach the two-identity bridge of [Note 343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md). It also excludes Note 348's residual left no-bridge branch. It does **not** synchronize a singleton-\(c\) identity across two carrier pairs; the owner and residual-cycle gate of [Notes 345 and 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md) remains. This note is a hand proof conditional on Notes 271 and 346, not an independent certification of their classifications. Full exact Case XII and Berge–Fulkerson remain open.

**Scope of the triple-hit observation.** [Note 230, (1)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) already rules out *every* all-terminal perfect matching in this deficient-core profile, and hence every all-terminal BF cover. The explicit triple-hit edges in (14) distinguish matching identities locally, but do not add a Case-XII exclusion. The unresolved useful implication must produce a forbidden \(T\)-loop or \(T\)--\(T\) row from complete matching closure, or rule out a required row, without invoking an all-terminal cover.
