> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two proper common-arm exits and a neutral three-hit cubic gadget

In the two owner patterns left by [Note 152](152-reverse-class-four-gate-excludes-crossed-short-diamonds.md), a common-\(ZY\) escape of the distinguished class-four phase cycle may lie on the canonical \(q_{25}\triangle r_{34}\) path. In that branch the same arm has **two proper**, rather than merely two possibly semiedge, common-\(ZY\) contacts of the two forced terminal paths. A six-vertex cubic four-pole then shows sharply why a third contact of \(C_4\triangle\widehat C_4\) with \(r_{34}\triangle C_4\) need not change the latter's terminal pairing. The first result is conditional on the actual aligned row and Note 152's escape edge; the four-pole is an unconditional matching-level counterexample to the stronger three-hit inference. Neither is an exact-Case-XII five-pole realization. The conditional application to the short diamond awaits independent verification of the upstream normalization and phase-cycle arguments.

## The two-path arm corridor

Use the actual complete masks of Note 152:
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1,
\qquad q_{25}+B_2=U_{35}+Z_3,
\qquad q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.       \tag{1}
\]
Take one of its surviving patterns \((2,2,1,1)\) or \((1,1,2,2)\), with the aligned six-edge core and \(J'=5\). Let \(A\) be the original type-\(13\) terminal arm beginning at the core vertex \(a\) selected in Note 152, and let \(h\) be its first \(UC\) edge. Choose the forced \(5\leftrightarrow4\) path \(P_{54}\) of \(q\triangle D\), with no optional closed switch, and set \(\widehat C=D\triangle E(P_{54})\). Let \(P_{23}\) be the forced \(2\leftrightarrow3\) path of \(q\triangle r\), again with no optional closed switch, and set \(p=q\triangle E(P_{23})\). The negative Case-XII support forces these two endpoints by [Notes 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) and [131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md).

**Proposition.** Suppose the proper escape edge \(g\) of Note 152, reached by following the component of \(C\triangle\widehat C\) from \(h\) outward along \(A\), belongs to \(P_{23}\). Then another **distinct proper** \(ZY\) edge \(f\) is incident with \(A\), and
\[
\{g,f\}\subseteq E(P_{54})\cap E(P_{23})\cap E(C\triangle\widehat C),
\qquad
q=\widehat C=Z=Y=1,\quad p=C=r=D=0
\quad\text{on }g,f.                                      \tag{2}
\]
The two forced paths use the same segment of \(A\) from \(g\) to \(f\). At every arm vertex strictly between its ends, \(q\) and \(\widehat C\) use the \(UC\) edge also used by \(C\); no edge strictly inside this arm corridor belongs to \(C\triangle\widehat C\). This does **not** assert that \(f\) lies on the distinguished component \(\Gamma_h\) containing \(h\).

**Proof.** At every nonterminal vertex of the split arm the three incident original owner pairs are \((UC,Dr,ZY)\). The carrier identity \(q+B=U+Z\) makes \(q\) choose either the \(UC\) edge or the \(ZY\) edge. Both \(D\) and \(r\) choose the \(Dr\) edge. Consequently \(q\triangle D\) and \(q\triangle r\) have exactly the same two local edges wherever either path visits the arm.

The component \(\Gamma_h\) reaches \(g\) along a \(C\)-owned \(UC\) edge directed away from the core and leaves through \(g\), which is \(\widehat C\)-owned. Since \(D(g)=0\) and \(g\in P_{54}\), \(\widehat C(g)=q(g)=1\). Thus \(P_{54}\) follows the \(Dr\) edge from \(g\) farther toward the terminal. The assumption \(g\in P_{23}\) makes \(P_{23}\) follow the same edge. Thereafter the two paths cannot split at an arm vertex: each uses the local \(Dr\) edge together with the same \(q\)-edge. If that edge is \(UC\), both paths proceed outward along the arm. Their first side exit therefore uses another \(ZY\) edge \(f\ne g\).

Such an exit must occur before the arm ends. The core end is behind the chosen outward direction. The other end is terminal \(4\) or \(5\), neither an end of \(P_{23}\). A \(ZY\) semiedge could only be terminal \(3\), which is not an end of \(P_{54}\). Hence \(f\) is proper and lies on both terminal paths. At \(f\), \(q=1\), while \(C=r=D=0\); switching \(P_{54}\) gives \(\widehat C(f)=1\), and switching \(P_{23}\) gives \(p(f)=0\). The same identities hold at \(g\). At an arm vertex strictly between the two exits, both paths use \(Dr\) and \(UC\), so \(q=UC=C\), and the first switch makes \(\widehat C=q=C\). This proves (2) and the corridor statement. \(\square\)

Under the additional no-common-seed hypothesis, [Notes 150](150-short-diamond-tait-anchors-force-an-external-critical-phase-edge.md) and [151](151-five-right-row-junctions-leave-only-common-singleton-critical-edges.md) force at least one proper exterior \(ZY\) edge in \(p\cap Z\). It is distinct from both \(g\) and \(f\), because \(p(g)=p(f)=0\). Thus the \(g\in P_{23}\) branch requires **at least three distinct proper \(ZY\) edges**. If \(P_{23}\) bypasses \(\Omega\), Note 150's two-external-edge corollary applies to each of the two surviving patterns and forces two distinct such \(p\cap Z\) edges on one critical cycle; in this subbranch the lower bound is **four**. These counts are necessary full-mask incidence conditions, not contradictions.

## The exact three-hit pairing criterion

**Lemma.** Let \(C,C'\) be same-boundary perfect matchings of a cubic pole, and let \(r\triangle C\) contain two open paths \(A,B\) with four distinct ends. Suppose one component \(\Gamma\) of \(C\triangle C'\) meets \(r\triangle C\) in exactly three edges \(h,j,k\), all owned by \(C\), with \(h,j\) on \(A\) and \(k\) on \(B\). On \(A\), call the endpoints of \(h,j\) adjacent to the two terminal tails their *outer ends* \(h_o,j_o\); call their other endpoints *inner ends*. Then switching \(C\) on \(\Gamma\) preserves the pairing of the four terminal ends **if and only if** one of the three arcs of \(\Gamma-\{h,j,k\}\) joins \(h_o\) directly to \(j_o\). In that case its other two arcs join the two inner ends separately to the two ends of \(k\).

**Proof.** At a vertex of a cubic graph, two degree-two subgraphs cannot meet without sharing an edge. Hence the three listed edges are all contacts, including vertex contacts. In \((r\triangle C)\triangle\Gamma\), remove \(h,j,k\) from the old paths and insert the three complementary arcs of \(\Gamma\). These arcs each join endpoints of *different* removed edges: an arc joining the two endpoints of one edge would make a proper subcycle of the single simple cycle \(\Gamma\).

The two external tails of \(A\) now end at \(h_o,j_o\). If their terminal ends remain paired, they must connect without entering either external tail of \(B\), since that would end at a terminal of \(B\). Their only possible route is a direct new arc from \(h_o\) to \(j_o\): every alternative route through \(A\)'s middle segment would require a new arc joining the two ends of \(k\) to pair \(B\)'s external tails, which is impossible by the preceding paragraph. Conversely, the direct outer arc pairs the old terminal ends of \(A\), and the two remaining arcs connect the ends of \(k\) through \(A\)'s middle segment, pairing the old terminal ends of \(B\). \(\square\)

**Short-diamond consequence.** In pattern \((1,1,2,2)\), [Note 152](152-reverse-class-four-gate-excludes-crossed-short-diamonds.md) traces \(\Gamma_h\) from the **core end** of \(h\) through \(e_6=ZD\) to the \(C\)-edge \(e_5=YC\) on the other \(r\triangle C\) open path. In pattern \((2,2,1,1)\), when \(P_{54}\) avoids \(v_4\), the analogous arc runs from the core end of \(h\) through \(e_4=YD\) to \(e_3=ZC\) on the other path. Neither \(e_6\) nor \(e_4\) is an \(r\triangle C\) edge, so each is a direct arc between the two designated hits.

In either branch, suppose \(\Gamma_h\) has exactly three contacts with \(r\triangle C\), all \(C\)-owned, and its third contact \(j\) lies **farther from the core than \(h\) on the same terminal arm**. Then the core end of \(h\) is an outer end of the two contacts on the \(4\leftrightarrow5\) path. The displayed core arc joins that outer end to the other open path, violating the lemma's necessary neutral-pairing condition. Switching \(\Gamma_h\) changes the terminal pairing and, by Note 152's reverse endpoint gate, yields a common complete \(B_2,C_4\) seed. Consequently this exact three-contact, outward-third-hit configuration is impossible under no seed. The conclusion does not cover a third hit on the other side of \(h\), an \(r\)-owned hit, or four or more contacts.

More exactly, if there are just three all-\(C\) contacts and no seed, the third contact must lie either on the \(4\leftrightarrow5\) path **toward the core from \(h\)**, or on the \(1\leftrightarrow2\) path **on the side of \(e_5\) or \(e_3\) reached by the displayed core arc**. In either case the endpoint already joined to the other path is an *inner* endpoint of the two contacts on its own path; otherwise the required outer-to-outer arc cannot exist. This locates the only possible neutral three-hit orientations without asserting that either can be completed by the actual owner masks.

**Chord-side escape forced by three all-\(C\) hits.** Under the same two pattern-specific hypotheses, if \(\Gamma_h\) has exactly three contacts with \(r\triangle C\), all owned by \(C\), then \(\Gamma_h\) uses a proper \(ZY\) edge incident with an **interior vertex of the chord**. This edge is also on \(P_{54}\), and \(\widehat C=q=Z=Y=1\) there.

To see this, use the owner sequences in [Note 146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md). In pattern \((1,1,2,2)\), after the forced \(h,e_6,e_5\) segment, \(\Gamma_h\) reaches \(v_4\). If \(\widehat C\) takes the \(q\)-edge \(e_4=rZ\), it acquires an \(r\)-owned contact, contrary to the three all-\(C\)-hit assumption. It must take the \(D\)-owned chord. If it traverses the whole chord to \(v_1\), its next \(C\)-edge is \(e_2=ZC\) on the \(4\leftrightarrow5\) path. At the opposite end \(v_2\), \(q\) uses this same \(e_2\), so \(\widehat C\), which avoided \(e_2\) at \(v_1\), must use the \(Dr\) terminal-arm edge. That gives an additional \(r\)-owned contact.

In pattern \((2,2,1,1)\) with \(P_{54}\) avoiding \(v_4\), the forced \(h,e_4,e_3\) segment reaches \(v_2\). There \(q\) uses \(e_3=ZC\), so \(\widehat C\) must enter the \(D\)-owned chord. If it traverses the whole chord to \(v_5\), it next takes \(e_6=YC\) on the \(4\leftrightarrow5\) path. At \(v_0\), \(\widehat C\) then either takes the \(Dr\) terminal-arm edge, adding an \(r\)-contact, or takes \(e_1=UZ\), after which the \(DC\) edge at \(v_1\) adds a fourth \(C\)-contact on the \(1\leftrightarrow2\) path. Thus neither pattern can traverse the whole chord with only three all-\(C\) contacts. At some interior chord vertex, \(\widehat C\) must leave its \(D\)-edge for the third edge, whose original owners are \(Z,Y\). The identity \(\widehat C=D\triangle E(P_{54})\) puts that edge on \(P_{54}\). It cannot be the terminal-\(3\) semiedge because \(\widehat C_4\) avoids terminal \(3\), so it is proper. This proves the claim.

**Paired chord-side exit and the first length bound.** Number the edges of the odd chord from its entry endpoint to its opposite endpoint. Its \(UD\) edges are in positions \(1,3,5,\ldots\), separated by \(rC\) edges. At an interior vertex \(q\) uses its \(ZY\) side edge and \(D\) uses the adjacent \(UD\) edge. Hence every local passage of \(P_{54}\) through an **internal** \(UD\) edge has the form
\[
ZY\ \text{side edge}\;--\;UD\ \text{chord edge}\;--\;ZY\ \text{side edge}. \tag{5}
\]
Both side edges are proper: \(P_{54}\) has ends \(5,4\), whereas a \(ZY\) semiedge would be terminal \(3\). They are distinct, and \(\widehat C=q=Z=Y=1\) on both. Passage through an endpoint \(UD\) edge has only one chord-side \(ZY\) edge and one \(q\)-owned \(\Omega\) edge.

In pattern \((2,2,1,1)\), under the preceding \(P_{54}\cap\{v_4\}=\varnothing\) and exactly-three-all-\(C\)-contacts hypotheses, \(P_{54}\) avoids **both chord endpoints**. It avoids the entry endpoint \(v_2\), because \(q=C\) on \(e_3\) there but \(\Gamma_h\) contains \(e_3\), forcing \(\widehat C=D\) at \(v_2\). It avoids the opposite endpoint \(v_5\): a \(q\triangle D\) path through \(v_5\) uses the \(q\)-edge \(e_5=rZ\), which leads to \(v_4\), contrary to the branch assumption. Therefore the chord-side escape just proved must use an internal \(UD\) edge and has **two proper \(ZY\) side edges on the same \(P_{54}\)**. In particular the chord has at least five edges. A three-edge chord cannot support this exactly-three-all-\(C\)-contacts configuration. This is an exclusion of one sharply stated phase shape, not of the whole \((2,2,1,1)\) pattern.

In pattern \((1,1,2,2)\), the three-all-\(C\)-contact assumption makes \(P_{54}\) avoid the entry endpoint \(v_4\). Its chord-side escape is paired as in (5) if it uses an internal \(UD\) edge. It may instead use the endpoint \(UD\) edge at \(v_1\); in that case \(P_{54}\) traverses the \(q\)-owned \(e_2=ZC\) edge at \(v_1\). The negative support and the current core trace alone do not exclude that latter continuation.

Combining the length bound with Note 152's two-hit exclusion gives a compact remaining case statement: when \((2,2,1,1)\) has a three-edge chord and \(P_{54}\) avoids \(v_4\), no-seed forces \(\Gamma_h\) either to have **at least four** contacts with \(r\triangle C\), or to have exactly three with an \(r\)-owned contact. This is a necessary boundary for that shortest-chord branch, not a proof that either alternative is realizable.

**Chord-side cross-half dichotomy.** Let \(z\) be any proper \(ZY\) chord-side edge supplied above, so \(z\in P_{54}\) and \(\widehat C(z)=q(z)=Z(z)=Y(z)=1\). If \(z\notin P_{23}\), then \(p(z)=1\), giving a concrete edge of \((p\cap Z)\setminus\Theta\) of exactly the owner type isolated in Note 151. If \(z\in P_{23}\), then \(p(z)=0\), and \(P_{23}\) must use a second, distinct \(ZY\) side edge \(z'\) at the other end of the adjacent \(rC\) chord edge. Indeed at every interior chord vertex \(q\triangle r\) uses its \(ZY\) side edge and its \(rC\) chord edge, while \(q\triangle D\) uses that side edge and a different \(UD\) chord edge. The second \(z'\) may be the terminal-\(3\) semiedge; membership in \(P_{54}\) or \(C\triangle\widehat C\) is not forced. Thus a chord-side exit either supplies the needed **kind** of external \(p\cap Z\) edge or moves the cross-half path to a distinct side port. The first alternative alone does not prove that the edge is pairing-critical.

There is also a direct closure boundary at \(z\). The edge is common to both \(Z_3,Y_3\), so every complete singleton-\(3\) matching obtained by switching any closed components of \(Z_3\triangle Y_3\), including both \(\Omega\) phases in [Note 149](149-both-singleton-phases-of-a-short-diamond-have-state-thirtyfive-tait-completions.md), still owns \(z\). Since \(\widehat C_4\) owns it too, these existing singleton phases cannot form a disjoint state-\(34\) Tait triple with \(\widehat C_4\). A Tait contradiction using \(\widehat C_4\) therefore needs a singleton-\(3\) matching outside that paired-switch family; no existence claim for one is made here.

The two state-\(35\) Tait completions of Note 149 give a precise next test of this obstruction. In either completion, let \(A_3\) be its singleton-\(3\) colour and \(F_5\) its singleton-\(5\) colour; \(A\) owns \(z\) and \(F\) avoids it. If \(z\) is on a **closed** component of \(A\triangle F\), switching that whole component produces an actual state-\(35\) Tait completion whose singleton-\(3\) colour avoids \(z\). If it is on the open \(3\leftrightarrow5\) component, switching that component only exchanges the terminal labels of the two colours, and the resulting singleton-\(3\) colour still owns \(z\). The chord owner pattern alone does not decide which component contains \(z\), since its continuation runs through exterior edges. This is the exact full-matching observation needed before claiming that either known Tait completion repairs the chord-side collision.

## Three hits can preserve the pairing in a genuine cubic pole

Take the simple cubic four-pole \(K\) with vertices \(a,b,c,d,e,f\), six-cycle
\[
ab,bc,cd,de,ef,fa,
\]
one chord \(be\), and semiedges \(s_a,s_c,s_d,s_f\) at the indicated vertices. Its seven proper edges and four semiedges give degree three at every vertex. The following are three actual complete perfect matchings of \(K\):
\[
C=\{ab,cd,ef\},\qquad
C'=\{bc,de,fa\},\qquad
r=\{be,s_a,s_c,s_d,s_f\}.                              \tag{3}
\]
Both \(C,C'\) have empty boundary, and \(r\) uses all four ports. Their symmetric difference \(\Gamma=C\triangle C'\) is the entire six-cycle. It meets \(r\triangle C\) in **exactly three edges**, all owned by \(C\): \(ab,cd,ef\). The first and third lie on one open component, while \(cd\) lies on the other:
\[
\begin{array}{c|cc}
&\text{first open path}&\text{second open path}\\\hline
r\triangle C&s_a,a,b,e,f,s_f&s_c,c,d,s_d\\
r\triangle C'&s_a,a,f,s_f&s_c,c,b,e,d,s_d.
\end{array}                                               \tag{4}
\]
Thus both pairings are \((s_a\,s_f)(s_c\,s_d)\). This is a directly checkable cubic-pole counterexample to the proposed rule that a phase cycle with the two cross-path \(C\)-hits of Note 152 and exactly one further \(C\)-hit must change the terminal pairing. The six-cycle is the smallest possible alternating cycle with three \(C\)-phase hits. The example does not satisfy (1), does not have five terminals, and says nothing about exact-Case-XII complete perfect-matching closure.

For the short-diamond problem, the two-hit corollary of Note 152 is therefore sharp as a **contact-count** argument. A third hit may restore the old pairing, but the fixed core arc excludes one of the neutral orientations in the two specified branches. Excluding the remaining configurations requires further owner and complete-family information.
