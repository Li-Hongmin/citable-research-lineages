> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Case-XII poles cannot be made bipartite by deleting one edge

The complete Case-XII support forces a second odd cycle away from every
specified proper edge. More precisely, if a cubic five-pole has all
twenty-five \(S\)--\(T\) BF types and no \(T\)-loop, then deleting any one
proper edge leaves a non-bipartite proper-edge graph. Neither the absent
all-terminal type nor absence of \(T\)--\(T\) types is used. This is an
all-orders restriction on actual perfect matchings, strengthening the
bipartite exclusion in
[Note 124](124-bipartite-five-pole-boundary-parity-and-note-075-correction.md).

## The theorem

Let \(S=\{13,14,24,25,35\}\) and
\(T=\{12,15,23,34,45\}\). Suppose
\[
S\times T\subseteq\operatorname{BFsupp}(H),
\qquad [t]\notin\operatorname{BFsupp}(H)
\quad(t\in T).                                         \tag{1}
\]
Then for every proper edge \(e\) of \(H\), the proper-edge graph of
\(H-e\) contains an odd cycle. In particular every exact-Case-XII pole
has odd-cycle edge transversal number at least two.

**Proof.** The positive BF support excludes proper loops: every edge must
be covered twice, while a loop belongs to no perfect matching. If \(H\)
itself is bipartite, [Note 124](124-bipartite-five-pole-boundary-parity-and-note-075-correction.md)
shows that every BF missing-pair label avoids one fixed terminal, contrary
to the positive types in (1). Suppose instead that \(H-e\) is bipartite
but \(H\) is not. Choose a bipartition \(X,Y\) of \(H-e\) in which both
ends of \(e\) lie in \(X\). Let \(t_X,t_Y\) count terminal semiedges on
the two sides, with multiplicity. Counting ends of proper edges gives
\[
3|X|-t_X-2=3|Y|-t_Y,
\qquad t_X+t_Y=5.                                     \tag{2}
\]
Thus \(t_X-t_Y=3(|X|-|Y|)-2\). The only possible odd differences in
\([-5,5]\) congruent to \(-2\) modulo three are \(-5\) and \(1\). Hence
\[
(t_X,t_Y,|X|-|Y|)=(0,5,-1)
\quad\text{or}\quad(3,2,1).                            \tag{3}
\]

For a perfect matching \(P\), put \(z=\mathbf1_{e\in P}\), and let
\(a_X,a_Y\) be its semiedge counts on the two sides. Equating vertices
matched across the bipartition yields
\[
a_X-a_Y=|X|-|Y|-2z.                               \tag{4}
\]

If \((t_X,t_Y)=(3,2)\), every triple-boundary matching has split
\((a_X,a_Y)=(2,1)\) when it avoids \(e\), or \((1,2)\) when it uses
\(e\). A triple using all three \(X\)-side semiedges is impossible.
Therefore the pair consisting of the two \(Y\)-side terminal labels is
absent from **every** BF missing-pair label. But each of the ten terminal
pairs is a label in one of the twenty-five required \(S\)--\(T\) types.
This contradicts (1).

If \((t_X,t_Y)=(0,5)\), equation (4) gives \(a_Y=1+2z\). Every singleton
matching avoids \(e\), and every triple matching uses \(e\). Choose from
(1) a BF cover with a triple matching \(Q\) whose missing-pair label
\(t\) lies in \(T\). Then \(e\in Q\), so the proper edges of the
complement \(H-Q\) lie in the bipartite graph \(H-e\). This complement
has degree two at every internal vertex. Its closed components are even
cycles. Its two unused semiedges lie on \(Y\), so the unique component
joining them has an even number of proper edges and is an even path when
the two semiedges are included. Every component can therefore be
alternately two-coloured. The two colour classes are actual perfect
matchings \(Q_1,Q_2\), and
\[
Q+Q_1+Q_2=\mathbf1
\quad\text{with Tait state }t.                           \tag{5}
\]
Doubling (5) gives a BF cover of forbidden loop type \([t]\), again
contradicting (1). Both cases in (3) are impossible. \(\square\)

The parity step has a useful general form. A cubic five-pole has odd
order. For any triple-boundary perfect matching \(Q\), the complement
\(H-Q\) consists of closed proper cycles and one path joining its two
unused semiedges. If every closed cycle is even, the path has an even
number of proper edges by counting the odd total number of vertices.
Thus the complement is two-colourable and \(Q\) extends to a Tait
colouring with state equal to its missing pair. In particular, absence
of a \(T\)-loop requires **every** triple-boundary matching with a
\(T\) missing pair to leave at least one odd proper cycle. This is a
necessary condition, not a converse to the loop-to-Tait implication
discussed in [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md).

The \((0,5)\) argument proves a reusable local fact without any Case-XII
assumption: **when \(H-e\) is bipartite, all five semiedges lie opposite
\(e\), and a triple-boundary perfect matching uses \(e\), that matching
extends to a Tait colouring whose state is its missing pair.** The
two-colouring uses the complete matching complement, including semiedges;
it does not rely on a boundary signature or a selected BF row.

For the minimum-host marked core of
[Note 123](123-exact-case-xii-terminal-vertices-are-independent.md), the
theorem says that the proper odd cycles of the exact-Case-XII side have no
edge common to all of them. This excludes every one-edge-near-bipartite
candidate, but does not establish the common-\(B,C\) pair-load
intersection \(\Lambda_L\cap\Lambda_R\) of
[Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md).
