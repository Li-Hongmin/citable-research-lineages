> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A common class-three residual transfers between anchored carriers

The four projection tests of
[Note 093](093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)
do not share a residual in general.  When the two class-(3) tests do share
the same physical residual copy-multigraph, however, the absence of
(T)-loops and (T)--(T) rows forces an exact oriented transfer.

Use the two anchored carriers

\[
K_{23}=2\mathbf1-r_{23}-B-X,
\qquad
K_{34}=2\mathbf1-r_{34}-Y-C.
\tag{1}
\]

Let (P) be an actual singleton-boundary perfect matching in class (3),
and suppose

\[
D_{23}(P)=K_{23}-P=K_{34}-P=D_{34}(P)=:D.          \tag{2}
\]

Assume first that (P\in\mathcal F_3(K_{23};5)), so that

\[
D=Q_{35}+P_5                                             \tag{3}
\]

for actual perfect matchings (Q_{35}) and (P_5).

## Oriented transfer criterion

The residual copy-multigraph of (D) has internal degree two, one semiedge
copy at each of terminals (1,2,4,5), and no copy at terminal (3).
It is therefore a union of closed copy-cycles and two terminal paths.
Equation (3) alternately colours every component.  Give (Q_{35}) colour
(0) and (P_5) colour (1).  The terminal bits are

\[
\begin{array}{c|cccc}
t&1&2&4&5\\ \hline
\beta_{35,5}(t)&0&0&0&1.
\end{array}                                                   \tag{4}
\]

A decomposition (D=Q_{13}+P_1) instead requires

\[
\begin{array}{c|cccc}
t&1&2&4&5\\ \hline
\beta_{13,1}(t)&1&0&0&0.
\end{array}                                                   \tag{5}
\]

For a terminal path with (m) proper-edge copies and endpoint bits
(c_0,c_1), alternation is possible exactly when

\[
c_0\mathbin\oplus c_1\equiv m+1\pmod2.             \tag{6}
\]

The two prescriptions (4) and (5) differ only at terminals (1) and (5).
If these terminals lie on the same residual path, both endpoint bits of that
path are toggled and the two XOR values in (6) are unchanged.  If they lie
on different paths, exactly one endpoint bit of each path is toggled, so both
previously valid parity equations fail.  All closed components are already
even by (3).  Consequently

\[
\boxed{
P\in\mathcal F_3(K_{34};1)
\iff
\text{terminals (1) and (5) lie on the same terminal path of (D)}.
}                                                               \tag{7}
\]

When the path condition holds, switching the two colours on the (1)--(5)
path turns (P_5) into (P_1) and (Q_{35}) into (Q_{13}), while leaving
the class-(3) occurrence (P) pointwise fixed.

## Exact negative support forces the path condition

Let the terminal-(5) path in (3) end at
(t\in\{1,2,4\}).  Switching (Q_{35}) and (P_5) on this path gives
another actual decomposition of (K_{23}), now with singleton state (3t),
and still retains the same class-(3) matching (P).  The complementary
half (r_{23}+B+X) has state (23\in T).  Hence

- (t=2) produces the forbidden (T)-loop ([23]);
- (t=4) produces the forbidden (T)--(T) row ((34)(23)); and
- (t=1) produces the allowed (S)-state (13).

Thus, in exact Case XII, (t=1).  Combining this with (7) proves the
conditional positive transfer

\[
D_{23}(P)=D_{34}(P),\quad
P\in\mathcal F_3(K_{23};5)
\quad\Longrightarrow\quad
P\in\mathcal F_3(K_{34};1).                       \tag{8}
\]

The reflected implication follows by interchanging the two orientations.

## Why equal degrees are insufficient

If (D_{23}(P)) and (D_{34}(P)) are merely nonnegative, they still have
the same internal degrees and terminal loads.  After common copies are
cancelled, their signed difference decomposes into proper closed circuits
alternating between removed and inserted copies: pair opposite signs at
each vertex and follow the resulting circuits.

This is only an uncoloured multiplicity transport.  Once the source residual
is coloured, an inserted copy must inherit at each endpoint the colour of
the deleted incidence there; the two endpoints may force opposite colours.
Even a colour-preserving closed-circuit transport retains the terminal bits
and cannot itself change the singleton role from (5) to (1).  The target
residual must still satisfy the path criterion (7).

Therefore (8) is a genuine common-residual theorem, not a consequence of
equal degree sequences, an unlabelled parity obstruction, or the signed
load identities among the four literal pivot rows.  The unresolved general
case is to force a physical, colour-preserving residual relation between
the two carrier projections without assuming equality (2).
