> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real mixed prism row satisfies both singleton-\(e\) port selectors

[Note 396](396-the-mixed-prism-root-pair-has-one-pentagon-and-two-exterior-masks.md) leaves two exterior masks for a putative exact-Case-XII \((e\,ab)(e\,AC)\) row with the direct roots \(a,C\), and requires the two singleton-\(e\) shore paths against \(R\) to end at \(p_4,p_2\), respectively. The following **actual cubic five-pole and complete six-matching BF row** attain both selectors simultaneously. This disproves a contradiction based on the two selectors and row incidence alone; it is not an exact-Case-XII pole.

Use the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\), with marks \(AC,Cc,bc,ab\). The shore has ten vertices \(h_0,\ldots,h_9\). Attach its ports \((e,p_1,p_2,p_3,p_4,p_5)\) at \((h_0,h_2,h_3,h_4,h_5,h_6)\), respectively. Give it the following twelve internal edges. A pair in the right column names **exactly** the two matching occurrences using that edge:

| shore edge | slots | shore edge | slots | shore edge | slots |
|---|---|---|---|---|---|
| \(h_0h_1\) | \(RJ\) | \(h_0h_2\) | \(PK\) | \(h_1h_3\) | \(PE\) |
| \(h_1h_5\) | \(FK\) | \(h_3h_7\) | \(RK\) | \(h_5h_8\) | \(PR\) |
| \(h_7h_8\) | \(EF\) | \(h_7h_4\) | \(PJ\) | \(h_8h_9\) | \(JK\) |
| \(h_2h_6\) | \(RJ\) | \(h_6h_9\) | \(PF\) | \(h_4h_9\) | \(RE\) |

The six shore port labels are
\[
 e:EF,\qquad p_1:EF,\qquad p_2:FJ,\qquad
 p_3:FK,\qquad p_4:EJ,\qquad p_5:EK.                 \tag{1}
\]
At each shore vertex its three incident slot pairs partition \(\{P,R,E,F,J,K\}\). Thus each slot is a genuine perfect matching of the shore with precisely the displayed ports, and each shore edge has load two. The internal graph is simple and connected; its visible four-cycle \(h_7h_4h_9h_8h_7\) makes the girth four.

Complete the six matchings in the exterior by the table below. At a tree subdivision \(u_i\), the entry is the prism endpoint matched to \(u_i\), or the proper port \(p_i\). At a marked subdivision, \(s\) is its terminal semiedge and a letter is the matched prism endpoint.

| slot | terminal semiedges | \((u_1,u_2,u_3,u_4,u_5)\) | \((AC,Cc,bc,ab)\) | shore ports |
|---|---|---|---|---|
| \(P\) | \(AC,Cc,bc\) | \((B,C,A,b,c)\) | \((s,s,s,a)\) | none |
| \(R\) | \(ab,Cc,bc\) | \((A,B,a,b,c)\) | \((C,s,s,s)\) | none |
| \(E\) | \(e\) | \((p_1,B,a,p_4,p_5)\) | \((A,C,c,b)\) | \(e,p_1,p_4,p_5\) |
| \(F\) | \(e\) | \((p_1,p_2,p_3,B,a)\) | \((A,C,c,b)\) | \(e,p_1,p_2,p_3\) |
| \(J\) | \(ab\) | \((B,p_2,A,p_4,a)\) | \((C,c,b,s)\) | \(p_2,p_4\) |
| \(K\) | \(AC\) | \((A,C,p_3,B,p_5)\) | \((s,c,b,a)\) | \(p_3,p_5\) |

Each row covers every prism, subdivision and shore vertex once. At every tree subdivision the three incident edges have two slots each; the same holds at every marked subdivision by reading its column. Equation (1) agrees with the port entries, and the twelve-edge table gives load two on the shore. Hence the six **complete** matchings form an actual BF row of type \((e\,ab)(e\,AC)\) on a 25-vertex simple connected cubic five-pole.

Both selectors of Note 396 hold, with no ambiguity about the shore paths:
\[
\begin{aligned}
R\triangle E:&\quad e-h_0-h_1-h_3-h_7-h_8-h_5-p_4,
                  &&p_4\longrightarrow ab,\\
R\triangle F:&\quad e-h_0-h_1-h_5-h_8-h_7-h_3-p_2,
                  &&p_2\longrightarrow ab.
\end{aligned}                                                    \tag{2}
\]
The arrows use Note 395's wholly exterior routes. Also \(R\triangle K\) has the exterior \(AC\)--\(bc\) path and \(P\triangle J\) the exterior \(ab\)--\(Cc\) path. Thus the first two individual terminal switches stay within the orientation \(S_{ab}=e-AC-ab-Cc-bc-e\), and both singleton-\(e\) selections demanded by Note 396 occur in the same genuine row.

The **complete matching closure is not exact Case XII**. For the zero-port shore matching \(Q=P|_Z\), its complement has no closed component and has signed port paths
\[
e-h_0-h_1-h_5-p_4\ (4),\qquad
p_1-h_2-h_6-p_5\ (3),\qquad
p_2-h_3-h_7-h_8-h_9-h_4-p_3\ (6).                  \tag{3}
\]
For the \(e\,ab\)-triple rooted at \(a\), the three exterior complement arms are
\[
ab-t_{ab}-b-t_{bc}-c-t_{Cc}-C-t_{AC}-A-u_1-p_1,\qquad
p_2-u_2-B-u_4-p_4,\qquad p_3-u_3-a-u_5-p_5.
\]
These are the \(ab\,p_1\mid p_2p_4\mid p_3p_5\) pairing of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Gluing them to (3), counting each shared proper port edge once, gives a single \(e\)--\(ab\) path and no closed component. The complement of that rooted triple therefore splits into two perfect matchings, yielding a genuine forbidden \(e\,ab\) Tait colouring and hence the forbidden BF loop \([e\,ab]\). This failure uses a matching in the **full** closure, not a formal boundary assignment.

There is also a girth-five, Tait-empty version of this row. Replace the port-\(p_3\) shore vertex \(h_4\), which is on neither path in (2), by the Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md), matching its three attachment pairs to \(FK,PJ,RE\). This gives a 33-vertex five-pole. To check its girth, suppress the six degree-two port vertices in the original shore: the resulting \(K_4\) on \(h_1,h_7,h_8,h_9\) has edge lengths \(2,2,4,1,2,1\). Its only four-cycle before substitution is \(h_7h_4h_9h_8h_7\), which the gadget breaks, while \(h_1h_3h_7h_8h_5h_1\) remains a five-cycle. The Petersen gadget has girth five and every cycle traversing two of its attachments uses at least three gadget edges, so the new pole has girth five. The substitution preserves every BF boundary type and extends the displayed row; both paths in (2) avoid the gadget. Since \(h_4\) has exactly one proper port, Note 381 also forces an odd shore-complement cycle for every zero-port matching and precludes a Tait colouring. The forbidden **BF** loop \([e\,ab]\) nevertheless persists by the same support-preservation theorem. Thus girth five and Tait-emptiness do not repair the missing exact-support condition.

The correct boundary is now explicit: simultaneous \(p_4,p_2\) selectors are attainable by complete graph matchings, even at girth five without a Tait colouring. Exact Case XII additionally has to exclude the forbidden **BF** loop and every forbidden double-\(T\) completion in the complete perfect-matching closure. The construction and checks are hand-derived; no local mathematical recomputation or independent review has been performed.
