> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The mixed fork row has a forbidden \((ec)(ab)\) shore splice

Use the complete exact-Case-XII, one-internal-mark five-cut setting and the marked \(|U|=4,r=4\) fork of [Note 259](259-the-fork-triangle-exterior-has-one-mixed-cross-row.md):
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\quad
a:L\!:\!\Sigma,\quad b:PQ,\quad c:PR,\quad d:QR,
\]
with \(h_i=u_i\Sigma\), internal shore mark \(e\), and allowed neighbours \(ea,eb\in S\). The odd shore has arbitrary order and cycle rank.

**Theorem.** No rooted cubic five-pole with this marked exterior has complete exact-Case-XII BF support. The required real \((ea)(ab)\) row forces, after exchanging its two complete singleton-\(a\) occurrences if necessary, the exterior table of Note 259. Its pure \(ea\) half admits a different, **same-port and same-total-load** exterior decomposition of state \(ec\). Gluing the three original complete shore restrictions to that decomposition produces a forbidden real \((ec)(ab)\in T\)--\(T\) row. The argument applies at every shore order, including the mixed \(0/2\) exterior-load case left by the unit-load splices of [Notes 256–258](258-the-paw-exterior-forces-a-forbidden-eb-ad-row.md).

## Equal-load exterior halves

By Note 259, write the pure half of the required \((ea)(ab)\) row in the following canonical exterior orientation:

| Shore ports | Pure \(ea\) slot and exterior mask | Replacement \(ec\) slot and exterior mask |
|---|---|---|
| \(\varnothing\) | \(X_a:\ \{a:L,1P,2Q,3O,4R\}\) | \(U_{ec}:\ \{c:P,1O,2Q,3L,4R\}\) |
| \(\{h_2,h_4\}\) | \(Y_a:\ \{b:P,c:R,d:Q,1O,3L,h_2,h_4\}\) | \(V_c:\ \{a:L,b:Q,d:R,1P,3O,h_2,h_4\}\) |
| \(\{e,a:\Sigma,h_2,h_3\}\) | \(Z_e:\ \{a:\Sigma,b:Q,c:P,d:R,1O,4L,h_2,h_3\}\) | \(W_e:\ \{a:\Sigma,b:P,c:R,d:Q,1O,4L,h_2,h_3\}\) |

Every displayed exterior mask is an actual matching on its side of the shore cut. The two columns have the same shore ports in each slot, including the internal \(e\)-terminal in the third slot. Both use every half of each exterior mark exactly once. Their \(K\)-loads, in the order \(1O,1P,2O,2Q,3O,3L,4L,4R\), are identically
\[
(2,1,0,1,1,1,1,1),                                     \tag{1}
\]
and both have \((h_1,h_2,h_3,h_4)\)-load \((0,2,1,1)\). Thus their **aggregate load agrees on every proper exterior edge**, despite being nonunit on \(1O,h_2\).

Let \(Q_0,Q_{24},Q_{e a23}\) be the complete actual shore restrictions of \(X_a,Y_a,Z_e\) in the supposed row. Glue them, respectively, to \(U_{ec},V_c,W_e\). Slotwise port equality makes each glued occurrence a genuine full-pole perfect matching. The new \(ec\) half has exactly the old shore load because the shore restrictions are reused, and exactly the old exterior load by (1). Keeping the original opposite \(ab\) half therefore preserves load two on every proper edge and terminal semiedge. It is a real BF row of type
\[
\boxed{(ec)(ab).}
\]
Here \(ec\in T\), since the only allowed neighbours of \(e\) are \(a,b\); also \(ab\in T\), since \(a,e,b\) are consecutive on the allowed pentagon. Exact Case XII forbids this \(T\)--\(T\) pair, proving the theorem. \(\square\)

[Note 259's](259-the-fork-triangle-exterior-has-one-mixed-cross-row.md) nineteen-vertex real \((ea)(ab)\) row remains valid and now necessarily carries this additional forbidden \((ec)(ab)\) row. It witnesses that a real mixed row and even its required shore \(e\)-pairing are compatible with the exterior; complete negative support is what excludes the marking. The other \(e\)-neighbour choices and marked fork placements, the path tree, larger barriers, other Tutte profiles, and Berge--Fulkerson remain open. This analytic proof has not received an independent check.

[Note 261](261-the-fork-triangle-marking-is-impossible-for-the-long-leaf-neighbour.md) subsequently excludes the other \(e\)-neighbour choice for this same shore-at-\(L\) triangle marking; other fork markings remain open.
