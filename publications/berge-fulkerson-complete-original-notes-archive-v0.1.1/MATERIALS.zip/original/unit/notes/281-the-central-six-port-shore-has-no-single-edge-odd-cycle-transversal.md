> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central six-port shore has no single-edge odd-cycle transversal

> **Scope correction (2026-10-01):** Placement I in this proof uses the
> left \((ea)(ad)\) row with \(U_{ad}(ED)\). The genuine right row of
> [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> has \(U_{ad}(EJ)\), so this proof does not establish the theorem for
> the right-row branch. [Note 330](330-marked-end-collision-gives-a-conditional-shore-transversal.md)
> records the resulting collision boundary.

Work in the actual one-internal-mark central-path profile of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with complete exact-Case-XII support and the required real \((ea)(ad)\) and \((ea)(ac)\) rows. Use the six shore ports
\[
E=e,\quad A=a:\Sigma,\quad I=h_1,\quad D=h_2,
\quad H=h_3,\quad J=h_4,
\]
and fixed allowed pentagon \(S=e-a-b-d-c-e\), so \(ad,ac,bc\in T\).

**Theorem.** Deleting any one internal edge \(g\) of the six-port shore leaves a nonbipartite shore. Equivalently, the shore's odd cycles have no common edge. This is stronger than [Note 276's](276-the-two-central-path-rows-force-an-odd-shore-cycle.md) existence of a shore odd cycle. It does **not** imply that the unmarked core \(F[\Sigma]\) has odd-cycle edge transversal number at least two, because subdividing the internal mark may create another shore odd cycle after deletion of a core edge.

## Proof: the two remaining port placements

Suppose instead that the shore minus \(g\) is bipartite. [Notes 278–280](280-fixed-carrier-orientation-excludes-the-central-e-minority-placement.md) reduce all possible port-side placements to exactly two balanced ones:
\[
\begin{array}{c|cc}
&B\cap\{E,A,I,D\}&B\cap\{H,J\}\\\hline
\text{I}&\{A\}&\{H\}\\
\text{II}&\{D\}&\{J\}.
\end{array}                                                     \tag{1}
\]
Here both ends of \(g\) lie in \(B\), the other shore side is \(R\), and the common exterior endpoints of all five proper shore interfaces are coloured \(B\). The full five-pole becomes bipartite after deleting \(g\) and the two \(B\)--\(B\) proper shore interfaces in either line of (1).

For any triple matching \(Q\), if its complement has only even closed cycles, the triple-complement lemma of [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md) extends \(Q\) to a Tait colouring at its missing-pair state. Thus an actual triple with missing pair in \(T\) must leave an odd closed cycle.

**Placement I: \(A,H\in B\).** The required \(U_{ad}\) uses shore ports \(E,D\), both in \(R\). Note 278's balance equation forces it to use \(g\); it avoids the two exceptional cut edges \(A,H\). In its exterior complement, the three endpoint connections are
\[
a\longleftrightarrow A,
\qquad I\longleftrightarrow H,
\qquad d\longleftrightarrow J.                          \tag{2}
\]
In particular \(A\) lies on the unique \(a\)--\(d\) terminal path. If \(H\) belonged to that same component, every closed cycle would avoid all three exceptional edges \(g,A,H\) and be even, giving forbidden \(ad\). Exact support therefore forces \(H\) onto an odd closed component. The exterior \(I\)--\(H\) path in (2) can close only if the **complement of the shore restriction** of \(U_{ad}\) pairs \(I\)--\(H\). Its other two free shore ports consequently pair \(A\)--\(J\):
\[
\overline{U_{ad}}\big|_{\rm shore}:\quad IH\mid AJ.       \tag{3}
\]

Keep this same complete shore matching, including its use of \(g\), and replace only its exterior matching. Select the terminal semiedges \(a,d\), the halves \(b:D_{\rm ext},c:A_{\rm ext}\), the cut edge \(h_2\), and path edges
\[
1B_{\rm ext},\quad 3C_{\rm ext},\quad 4E_{\rm ext}.      \tag{4}
\]
The shore already selects terminal \(e\). Formula (4) covers each exterior vertex exactly once and uses the same sole proper shore cut edge \(h_2\) as \(U_{ad}\). It therefore gives a **complete actual** triple matching \(Q_{bc}\), with boundary \(a,d,e\) and forbidden missing pair \(bc\). The exterior complement of (4) has connections
\[
c\longleftrightarrow A,
\qquad H\longleftrightarrow J,
\qquad b\longleftrightarrow I.                          \tag{5}
\]
Using the *unchanged* shore complement (3), its unique terminal path runs
\(c-A-J-H-I-b\), where each consecutive pair is alternately an exterior or shore path. Both exceptional cut edges \(A,H\) lie on this terminal path, and \(g\in Q_{bc}\). Every closed complement cycle avoids all three exceptional edges and is even. Hence \(Q_{bc}\) extends to a forbidden \(bc\) Tait colouring, a contradiction.

**Placement II: \(D,J\in B\).** The required \(U_{ac}\) uses shore ports \(E,A\), both in \(R\), so it uses \(g\) and avoids the two exceptional cut edges \(D,J\). Its exterior complement has connections
\[
a\longleftrightarrow D,
\qquad I\longleftrightarrow J,
\qquad c\longleftrightarrow H.                          \tag{6}
\]
The edge \(D\) is on the unique \(a\)--\(c\) terminal path. To avoid a forbidden \(ac\) Tait colouring, \(J\) must instead lie on an odd closed component. Thus the unchanged shore complement must pair
\[
\overline{U_{ac}}\big|_{\rm shore}:\quad IJ\mid DH.       \tag{7}
\]

Now keep the complete shore matching of \(U_{ac}\) but replace its exterior by the terminal semiedges \(b,c\), the halves \(a:\Sigma,d:B_{\rm ext}\), and path edges
\[
1A_{\rm ext},\quad 2C_{\rm ext},\quad
3D_{\rm ext},\quad 4E_{\rm ext}.                        \tag{8}
\]
Together with the shore terminal \(e\), this is a complete actual triple matching \(Q_{ad}\), with forbidden missing pair \(ad\). Its exterior complement connects
\[
a\longleftrightarrow H,
\qquad I\longleftrightarrow D,
\qquad d\longleftrightarrow J.                          \tag{9}
\]
Equation (7) joins these pieces into the unique terminal path \(a-H-D-I-J-d\). It contains both exceptional cut edges \(D,J\); \(g\) is used by \(Q_{ad}\). Again all closed complement cycles are even, producing forbidden \(ad\). Both placements in (1) are impossible. \(\square\)

The decisive closure step is **reuse of one actual shore matching** with a second, independently valid exterior matching of the same port boundary. The new triples need not belong to either designated six-matching BF row; complete graph-induced perfect-matching closure makes them unavoidable. The argument excludes all one-edge-near-bipartite **six-port shores** in this central-path profile. It leaves the distinct case where the unmarked core \(F[\Sigma]-g\) is bipartite but the marked-edge subdivision keeps the six-port shore minus \(g\) nonbipartite, as well as general high-rank shores and the four-slot load intersection. The forced-row inputs and these hand-traced exterior paths await independent verification.
