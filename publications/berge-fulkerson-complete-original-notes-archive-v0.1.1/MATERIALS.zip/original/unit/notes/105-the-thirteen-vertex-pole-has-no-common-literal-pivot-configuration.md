> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The thirteen-vertex pole has no common literal pivot configuration

For the labelled pole of [Note 007](007-independent-certificate-for-the-thirteen-vertex-pole.md),
the four literal-row equations of
[Note 085](085-common-binary-incidence-does-not-force-a-two-step-carrier-section.md)
have no simultaneous solution in its complete perfect-matching family.
Already the cells \((14,23)\) and \((24,15)\) have disjoint projections onto
their common actual singleton identities \((B,C)\).
This holds both for distinct class-3 identities \(X\ne Y\) and for \(X=Y\).
Consequently this pole supplies no configuration on which to test the
[Note-093 first-splice projections](093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)
and the dependent second splice of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).

## The quantified configuration

Retain the vertices, edge order and terminal labels of
[Note 005](005-pentagon-selection-is-false-and-a-weaker-transversal-survives.md).
Let \(M_i\), with zero-based index \(i\), be the numerically sorted list of
the 22-bit masks of all 31 actual perfect matchings. Proper edges occupy
bits \(0,\ldots,16\), and semiedges \(s_1,\ldots,s_5\) occupy bits
\(17,\ldots,21\). Let \(\mathcal P_i\) be the singleton boundary class
\(\{i\}\), and \(\mathcal Q_{ij}\) the triple boundary class
\([5]\setminus\{i,j\}\).

Choose

\[
(A,B,C,D,X,Y)\in
\mathcal P_1\times\mathcal P_2\times\mathcal P_4\times
\mathcal P_5\times\mathcal P_3\times\mathcal P_3
\]

and eight triple identities in their indicated \(\mathcal Q_{ij}\) classes.
The required equations are

\[
\begin{aligned}
q_{13}+A+X+r_{45}+C+D&=2\mathbf1,\\
q_{14}+A+C+r_{23}+B+X&=2\mathbf1,\\
q_{24}+B+C+r_{15}+A+D&=2\mathbf1,\\
q_{25}+B+D+r_{34}+Y+C&=2\mathbf1.
\end{aligned} \tag{1}
\]

All 22 edge coordinates, including semiedges, occur in these equations.
Repeated letters denote the same actual matching. No target-overload,
failed-pivot, saturation or negative-support assumption is imposed.

## The common anchor is already impossible

Let \(\mathcal L_{14,23}\) and \(\mathcal L_{24,15}\) be the full actual
row relations in the second and third equations of (1). Their complete
ordered rows are as follows; table entries are the indices of \(M_i\).

| Cell | Ordered slots | Complete rows |
|---|---|---|
| \((14,23)\) | \((q_{14},A,C,r_{23},B,X)\) | \((25,0,9,26,4,6)\), \((25,1,9,26,4,5)\) |
| \((24,15)\) | \((q_{24},B,C,r_{15},A,D)\) | \((21,2,8,16,1,18)\), \((21,3,8,16,0,18)\), \((22,2,8,16,1,17)\), \((22,3,8,16,0,17)\) |

In particular,

\[
\begin{aligned}
\pi_{B,C}\mathcal L_{14,23}&=\{(M_4,M_9)\},\\
\pi_{B,C}\mathcal L_{24,15}&=\{(M_2,M_8),(M_3,M_8)\}.
\end{aligned} \tag{2}
\]

These sets are disjoint. For example, the two forced class-4 identities are

\[
\begin{aligned}
M_8&=\{e_0,e_3,e_7,e_{11},e_{13},e_{15},s_4\},\\
M_9&=\{e_0,e_3,e_8,e_{11},e_{12},e_{16},s_4\}.
\end{aligned} \tag{3}
\]

Thus even their \(C\)-projections do not meet. This proves that (1) has
no solution, independently of \(X,Y\) or the other two rows.

For completeness, the four individual row relations in the order (1) have
sizes \(4,2,4,4\). Their successive natural joins on identically named
matching slots have sizes \(4,2,0,0\).

## Completeness of the finite certificate

The initial calculation reused Note 007's complete 31-PM and 177-BF data.
An independent verifier constructs PMs recursively by choosing the unique
matching incidence at the first uncovered vertex. Every PM follows exactly
one branch, and every completed branch covers each vertex once. It obtains
the same 31 masks, then scans the complete Cartesian product of the six
boundary classes for each row in (1), retaining exactly those with load two
on every edge. It does not call the BF enumerator or infer a reference row
from a splice output. This independently yields the complete rows in the
table and verifies (2).

The frozen [specification](../computations/bundles/empty-literal-pivot-join/SPEC.md),
[standalone verifier](../computations/bundles/empty-literal-pivot-join/verify_literal_row_join.py)
and [exact output](../computations/bundles/empty-literal-pivot-join/literal_join_certificate.json)
give the full slot maps and relation tables. Reproduce from the project root:

```bash
uv run --no-project --python 3.12 units/berge-fulkerson/computations/bundles/empty-literal-pivot-join/verify_literal_row_join.py
```

The local environment is Python 3.12.11 with uv 0.12.3; only the Python
standard library is used. The independent computation takes
less than one second and uses less than 32 MiB resident memory on the local
run. The graph remains fixed; there is no order search.

## Boundary of the result

The intended splice experiment is **UNKNOWN because its configuration domain
is empty**. It gives no legal counterexample to the transport implication
and no nonempty finite go. Alternating-component IDs, the four first-splice
projections and cross-cell splice residuals have no legal configuration in
which to be instantiated; their absence is not a certificate of phase failure.

The pole's six all-terminal BF covers remain present. It is not a genuine
exact-Case-XII sample. This result neither changes the through-fifteen
nonexistence boundary of [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md)
nor decides the general dependent-splice interface.
