> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact negative support reduces first-splice failures to four cross-carrier leakages

The four carrier-projection tests of
[Note 093](093-all-carrier-colourings-reduce-first-splice-to-four-projection-tests.md)
can be sharpened under exact Case-XII negative support. Once the
all-terminal type and all \(T\)--\(T\) types are absent, a nonnegative
residual with only even closed components can no longer fail merely because
of an unspecified terminal-path parity. It must enter one unique alternate
\(S\)-projection. Thus all four projection failures reduce to negative
residuals, odd residual cycles, or four explicit cross-carrier leakages.

## The sixteen restricted families

Work in one loopless cubic five-pole \(G\) with its complete graph-induced
perfect-matching family. Retain the two anchored carrier loads of Note 093,

\[
 K_{23}=2\mathbf1-r_{23}-B-X,
 \qquad
 K_{34}=2\mathbf1-r_{34}-Y-C,
 \tag{1}
\]

and the four endpoint data

\[
\begin{array}{c|c|c|c}
K&H&\widehat P_i&(i,j)\text{ intended}\\ \hline
K_{23}&(r_{23},B,X)&Y&(3,5)\\
K_{23}&(r_{23},B,X)&D&(5,3)\\
K_{34}&(r_{34},Y,C)&A&(1,3)\\
K_{34}&(r_{34},Y,C)&X&(3,1).
\end{array}
\tag{2}
\]

Here \(i\) is the singleton boundary class being replaced and \(j\) is the
other singleton colour in the intended carrier decomposition. For one row
of (2), write \(H=(L_0,L_1,L_2)\). For \(a=0,1,2\), let

\[
 U_a=V_{\mathrm{pr}=}(L_a,\widehat P_i)
\]

be the agreement region of Note 093 and define

\[
 \mathcal C_a(\widehat P_i)=
 \left\{
 P\in\mathcal P_i(G):
 \begin{array}{l}
 P=\widehat P_i\text{ outside }U_a,\\
 P\triangle\widehat P_i\text{ is a union of proper alternating cycles in }
 G[U_a]
 \end{array}
 \right\}.
 \tag{3}
\]

Also put

\[
 \mathcal C_{\mathrm{ent}}(\widehat P_i)=\{\widehat P_i\}.
 \tag{4}
\]

The agreement-region characterization in Note 093 gives

\[
 \mathcal G_H(\widehat P_i)=
 \bigcup_{a\in\{\mathrm{ent},0,1,2\}}
 \mathcal C_a(\widehat P_i).
 \tag{5}
\]

Consequently the four projection tests are exactly sixteen restricted
families: four choices of \(a\) for each row of (2). For a candidate
\(P\in\mathcal C_a(\widehat P_i)\), put

\[
 D_P=K-P.
 \tag{6}
\]

By the residual criterion of
[Note 078](078-residual-degree-two-criterion-for-two-triple-completion.md),
the intended projection succeeds precisely when \(D_P\ge0\), every closed
component of the degree-two residual copy-multigraph is even, and its
terminal paths have the prescribed intended colouring.

Assume from now on that the complete BF support has no all-terminal type and
no \(T\)--\(T\) type, and that all four intersections in Note 093(12) are
empty.

## A class-wide consequence of no all-terminal cover

For the four rows of (2), define the corresponding singleton quartets by

\[
\begin{array}{c|c}
\widehat P_i&W_i\\ \hline
Y&A+B+C+D\\
D&A+B+X+C\\
A&B+Y+C+D\\
X&A+B+C+D.
\end{array}
\tag{7}
\]

Each \(W_i\) uses the four singleton boundary classes other than \(i\), and
each is the singleton quartet of a literal BF row. Hence

\[
 W_i\le2\mathbf1.
 \tag{8}
\]

Let

\[
 D_2(W_i)=\{e:W_i(e)=2\}.
\]

Then every actual class-\(i\) perfect matching satisfies

\[
 \boxed{P\cap D_2(W_i)\ne\varnothing.}
 \tag{9}
\]

Indeed, if \(P\) avoided \(D_2(W_i)\), then \(W_i+P\le2\mathbf1\). At every
internal cubic vertex these five matching occurrences have total incident
load five, so the three edge loads are \((2,2,1)\). At each terminal vertex
the semiedge has load one and the two proper-edge loads are both two. Thus

\[
 Z=2\mathbf1-W_i-P
 \tag{10}
\]

is a perfect matching containing all five semiedges. The six occurrences
in \(W_i,P,Z\) form a forbidden all-terminal BF cover. This proves (9) for
the complete class-\(i\) perfect-matching family, not merely for the partial
flip families in (3).

## Nonnegative even residuals have no free parity obstruction

Both anchored carrier loads have semiedge multiplicity one at every
terminal:

\[
 K(s_k)=1
 \qquad(k=1,\ldots,5).
 \tag{11}
\]

If \(P\) has singleton boundary \(i\), then \(D_P=K-P\) has semiedge load
zero at \(i\) and load one at each of the other four terminals. Suppose
\(D_P\ge0\) and every closed residual component is even. Alternately colour
each path and each even closed component. The two colour classes meet every
internal vertex once and therefore give two actual perfect matchings.

No terminal-path parity condition remains to be checked because neither of
the two residual boundary colours has been fixed in advance. Every perfect
matching of a cubic five-pole has odd boundary size: from

\[
 3|V(G)|=2|E_{\mathrm{proper}}(G)|+5
\]

the order of \(G\) is odd, and the boundary size of a perfect matching has
the same parity as \(|V(G)|\). The two residual boundary sizes are odd and
sum to four, so they are one and three. Hence for some \(j\ne i\),

\[
 D_P=q_{ij}+P_j,
 \tag{12}
\]

where \(P_j\) has singleton boundary \(j\) and \(q_{ij}\) has the
complementary triple boundary.

Adding (12) to the fixed half produces an actual BF row of type
\((ij)(t)\), with \(t=23\) or \(34\). Both fixed states lie in

\[
 T=\{12,15,23,34,45\}.
\]

The absence of \(T\)--\(T\) support therefore forces \(ij\) into

\[
 S=\{13,14,24,25,35\}.
\]

For each endpoint class in (2), exactly two choices of \(j\) give an
\(S\)-state. The intended choice is impossible because it would place the
same \(P\in\mathcal C_a(\widehat P_i)\) in the intended projection,
contradicting the corresponding empty intersection in Note 093(12). The
other two choices give forbidden \(T\)-states. Exactly one alternate
\(S\)-projection remains:

\[
\begin{array}{c|c|c|c|c}
\widehat P_i&K&t&j\text{ intended}&j'\text{ forced leakage}\\ \hline
Y&K_{23}&23&5&1\quad(q_{13}+P_1)\\
D&K_{23}&23&3&2\quad(q_{25}+P_2)\\
A&K_{34}&34&3&4\quad(q_{14}+P_4)\\
X&K_{34}&34&1&5\quad(q_{35}+P_5).
\end{array}
\tag{13}
\]

Different alternating choices on even residual cycles may give different
decompositions, but every decomposition is subject to the same two support
exclusions. The leakage state in each row is therefore unique even when
its witnesses are not.

## The sharpened failure classification

Every candidate in every one of the sixteen restricted families satisfies
the global blocker (9) and lies in exactly one of the following three
classes:

1. \(P(e)=1>K(e)\) on some edge;
2. \(K-P\ge0\), but \(K-P\) has an odd closed component;
3. \(P\in\mathcal F_i(K;j')\), where \(j'\) is the unique leakage in (13).

Thus the generic wrong-terminal-parity obstruction from Note 078 has
disappeared. The four surviving states are also cross-carrier states:

- the \(Y\)-leak \(13\) is the intended state of the \(X\)-endpoint on
  \(K_{34}\);
- the \(X\)-leak \(35\) is the intended state of the \(Y\)-endpoint on
  \(K_{23}\);
- the \(D\)-leak \(25\) occurs in the literal decomposition
  \(K_{34}=q_{25}+B+D\);
- the \(A\)-leak \(14\) occurs in the literal decomposition
  \(K_{23}=q_{14}+A+C\).

Therefore a positive proof through the four Note-093 tests now has only two
possible mechanisms. It must either rule out negative and odd-cycle
residuals in at least one restricted family, or force one leakage matching
to coincide as an actual perfect-matching identity, with the required
agreement-core phase, with the corresponding operative fibre on the
opposite carrier. Exact support supplies the opposite boundary states but
does not identify their witnesses.

This is a cross-carrier identity problem in the complete graph-induced
perfect-matching family, not a remaining boundary-state or terminal-path
parity problem. The four-projection claim, the dependent second splice,
and the existence of an exact-Case-XII pole remain undecided.
