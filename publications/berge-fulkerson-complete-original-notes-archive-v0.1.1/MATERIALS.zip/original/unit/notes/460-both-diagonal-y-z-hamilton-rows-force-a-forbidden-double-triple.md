> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both diagonal \(Y,Z\) Hamilton rows force a forbidden double-triple

Continue the Hamilton three-spoke exterior and matching labels \(P=eY,R=eX,K=X,J=Y,a=e,b=e\) of [Note 458](458-the-y-z-forbidden-hamilton-pair-has-five-tree-signatures.md). Its first tree signature \(A\) was recompleted to \([eY]\) whenever \(\lambda_2\ne\lambda_1\). The remaining two diagonal labelled port profiles in Note 458(9) are both genuine rows by [Note 459](459-two-diagonal-y-z-hamilton-rows-are-real-but-have-forbidden-loops.md). We now show that **each** forces a \((eY)(eZ)\) BF row while keeping the six original complete shore matchings separately. Thus the entire \(A\) signature is impossible when \([eY]\) and \((eY)(eZ)\) are absent, independently of shore order or topology.

At a tree subdivision list first-end half, second-end half, proper port. At a marked subdivision list terminal and the two marked halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposition denotes an unordered pair of occurrence labels.

For the first diagonal form
\[
(p_1,p_2,p_3,p_4,p_5)=(ab,ab,KJ,Ja,Kb),\qquad e=ab,
\tag{1}
\]
use this new exterior restriction:
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RJ,PK,ab)&(RJ,PK,ab)&(Rb,Pa,KJ)
 &(RK,Pb,Ja)&(RJ,Pa,Kb)
\end{array}
\tag{2}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(PR,Ka,Jb)&(RJ,Pb,Ka)&(PK,ab,RJ)&(PR,Ja,Kb).
\end{array}
\tag{3}
\]
The original vertices \(1,\ldots,6\) see
\[
(RJ,Ka,Pb),\quad(PK,RJ,ab),\quad
(PK,Rb,Ja),\quad(Pa,RK,Jb),\quad
(Pb,RJ,Ka),\quad(Pa,RJ,Kb).
\tag{4}
\]
Every triple in (2)--(4) partitions \(\{P,R,K,J,a,b\}\), and the port column is (1).

For the second diagonal form
\[
(p_1,p_2,p_3,p_4,p_5)=(Ja,Ja,Kb,ab,Kb),\qquad e=ab,
\tag{5}
\]
use
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(Rb,PK,Ja)&(Rb,PK,Ja)&(RJ,Pa,Kb)
 &(RJ,PK,ab)&(RJ,Pa,Kb)
\end{array}
\tag{6}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(PR,Ja,Kb)&(RJ,PK,ab)&(PK,Ja,Rb)&(PR,ab,KJ).
\end{array}
\tag{7}
\]
At the six original vertices the pairs are
\[
(Rb,Ja,PK),\quad(PK,Rb,Ja),\quad
(PK,RJ,ab),\quad(Pa,RJ,Kb),\quad
(PK,RJ,ab),\quad(Pa,Rb,KJ),
\tag{8}
\]
again six partitions. Every exterior edge in either template has load two, and every labelled occurrence is a matching. The port pairs in (1) or (5), together with terminal \(e=ab\), are unchanged label by label. Gluing to each occurrence's **entire original shore restriction** therefore gives a genuine full BF row in the same five-pole, without equating different shore matchings.

Both templates have marked terminal pairs
\[
X=PR,\qquad Y=RJ,\qquad Z=PK,\qquad W=PR.
\]
Hence the new boundary states are \(P=eY,R=eZ,K=Z,J=Y\), with \(a,b\) singleton \(e\), and the row type is \((eY)(eZ)\). Published exact Case XII with forbidden \(\{eY,eZ\}\) omits this type under either pentagon orientation. In Note 458's signature \(A\), the non-diagonal phases force \([eY]\) and the two diagonal phases force \((eY)(eZ)\). Thus \(A\) is wholly excluded; \(B_1,B_2,C_1,C_2\) and the other forbidden-pair orbits remain. These certificates are hand-derived and await independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 461](461-the-y-z-forbidden-hamilton-pair-forces-a-forbidden-recompletion.md) rules out \(C_1\) directly and recompletes every \(B_1,B_2,C_2\) phase, conditionally excluding the whole \(\{eY,eZ\}\) forbidden pair on this exterior.
