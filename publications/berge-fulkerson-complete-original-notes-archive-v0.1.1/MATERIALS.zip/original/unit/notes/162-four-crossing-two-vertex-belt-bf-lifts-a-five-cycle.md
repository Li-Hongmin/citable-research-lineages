> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-crossing two-vertex belt BF-lifts a five-cycle

[Note 161](161-disconnected-unmarked-core-has-a-five-cut-or-a-two-vertex-four-cut.md) leaves two shapes when the unmarked core \(F=J-M\) is disconnected. This note excludes its four-edge-cut shape in a genuine minimum-host Case XII. The relevant eleven-vertex five-pole BF-lifts an ordinary 5-cycle for every cyclic placement of its four spokes. Consequently, the **only** disconnected \(F\) branch is a marked five-edge cut separating two odd components. The proof is analytic and awaits independent checking; that remaining branch and connected \(F\) are not resolved.

## The two-vertex belt

Let \(x,y\) be joined by an unmarked edge. Two marked edges incident with \(x\) are subdivided at \(t_a,t_b\); two incident with \(y\) are subdivided at \(t_c,t_d\). Their terminal edges go to four distinct vertices of the opposite pentagon \(R\). Call its fifth vertex \(r_s\). The belt \(B\) consists of \(x,y,t_a,t_b,t_c,t_d\) and all five vertices of \(R\). Its five exterior semiedges are \(h_a,h_b,h_c,h_d\) at the four \(t\)-vertices, and \(h_s\) at \(r_s\). The cyclic order of the five outer vertices \(a,b,c,d,s\) is arbitrary, while the partition \(\{a,b\}\mid\{c,d\}\) records which two spokes meet \(x\) and \(y\).

**Belt lifting lemma.** For every outer cyclic order, there is a 5-cycle \(Q\) on the port positions \(a,b,c,d,s\) such that every labelled six-matching BF boundary colouring of \(Q\) extends to \(B\) with exactly the same exterior labels.

We use the published boundary relation of an ordinary 5-cycle: its five adjacent-pair Tait states generate all fifteen BF pair and loop types by pairing or doubling three-edge-colourings, and it has one all-terminal type. Once these types occur in \(B\), any literal six-slot boundary assignment lifts by permuting the six matching labels.

## Tait states available for an arbitrary outer order

Write \(q_i\) for the colour on \(x t_i\) or \(y t_i\), \(r_i\) for the colour on \(t_iR\), and \(z\) for the colour on \(xy\). At each terminal vertex \(t_i\), its port colour, \(q_i\), and \(r_i\) are distinct. At both \(x\) and \(y\), the two incident \(q\)-colours are the two colours other than \(z\). An outer 5-cycle with dangling colours \(A,B,C,C,C\) extends to a three-edge-colouring whenever the two lonely positions are adjacent.

The following sufficient support rules follow by assigning those three colours at the six inner vertices:

1. \(\{a,b\}\) is a Tait state if \(c,d\) are adjacent on \(R\); symmetrically \(\{c,d\}\) is a Tait state if \(a,b\) are adjacent. For \(\{a,b\}\), take port colours \(A,B,C,C,C\), let \(z=C\), and give \(x t_a,x t_b\) colours \(B,A\). Give \(y t_c,y t_d\) colours \(A,B\); the lonely outer spoke colours occur at \(c,d\).
2. \(\{s,a\}\) is a Tait state if \(a\) is adjacent on \(R\) to \(c\) or \(d\); the other \(s\)-pairs follow by swapping \(a,b\) or \(c,d\). For \(\{s,a\}\), take port colours \(B\) at \(a\), \(A\) at \(s\), \(C\) elsewhere; let \(z=C\), \((q_a,q_b)=(A,B)\), and choose \((q_c,q_d)=(A,B)\) or \((B,A)\). The lonely outer colours then occur at \(a,c\) or \(a,d\).
3. For a cross pair \(\{a,c\}\), three inner assignments have the following outer lonely pairs:

   | \(z\) | \((q_a,q_b)\) | \((q_c,q_d)\) | outer lonely pair |
   |---|---|---|---|
   | \(C\) | \((B,A)\) | \((A,B)\) | \(\{b,d\}\) |
   | \(A\) | \((C,B)\) | \((C,B)\) | \(\{a,s\}\) |
   | \(B\) | \((C,A)\) | \((C,A)\) | \(\{c,s\}\) |

   Here the port colours are \(A\) at \(a\), \(B\) at \(c\), and \(C\) at \(b,d,s\). Thus \(\{a,c\}\) is supported if any of \(b d\), \(a s\), or \(c s\) is an outer edge. Swapping within the two groups gives the analogous rule for the other three cross pairs.

Up to swapping \(a,b\), swapping \(c,d\), interchanging the two groups, and reversing/rotating \(R\), every cyclic order is one of the following. The right column lists five supported Tait states in cyclic sequence:

| outer cyclic order | supported 5-cycle on the ports |
|---|---|
| \(s,a,b,c,d\) | \(s,b,a,d,c,s\) |
| \(s,a,c,b,d\) | \(s,c,a,d,b,s\) |
| \(s,a,c,d,b\) | \(s,c,a,b,d,s\) |

For example, in the first row \(sb\) and \(sc\) use rule 2, \(ba\) and \(dc\) use rule 1, and \(ad\) uses rule 3 because \(bc\) is an outer edge. The same three rules verify each edge in the other two rows. Choose the displayed supported 5-cycle as \(Q\). All its adjacent-pair states have actual three-edge-colourings of \(B\).

## An all-terminal six-matching cover

Let \(W\) use all five exterior semiedges, \(xy\), and the unique two-edge matching of \(R-r_s\). Let \(N_s\) use \(h_s\), \(xy\), and all four spokes \(t_iR\). For each \(i\in\{a,b,c,d\}\), let \(N_i\) use \(h_i\), the two \(x/y\)-to-\(t\) edges shown below, the spoke at the remaining \(t\)-vertex, and the unique two-edge matching of \(R\) after deleting that spoke's outer endpoint:

| matching | edge at \(x\) | edge at \(y\) | remaining spoke |
|---|---|---|---|
| \(N_a\) | \(xt_b\) | \(yt_c\) | \(t_dR\) |
| \(N_b\) | \(xt_a\) | \(yt_d\) | \(t_cR\) |
| \(N_c\) | \(xt_a\) | \(yt_d\) | \(t_bR\) |
| \(N_d\) | \(xt_b\) | \(yt_c\) | \(t_aR\) |

These six objects are perfect matchings of the five-pole. Each exterior semiedge is used by \(W\) and its singleton matching; \(xy\) by \(W,N_s\); each \(x/y\)-to-\(t\) edge by two of \(N_a,N_b,N_c,N_d\); and each spoke by \(N_s\) and exactly one of those four matchings. The five matchings \(W,N_a,N_b,N_c,N_d\) delete each outer vertex exactly once, so every edge of \(R\) occurs twice. This gives the all-terminal BF type and completes the labelled belt lifting lemma.

## Excluding the four-edge-cut branch

In the second case of Note 161, the two-vertex component of \(F\) is exactly \(xy\), and its four incident marked edges have the form above. The fifth marked edge lies on the other side, so its subdivision vertex is outside \(B\); the edge from that vertex to \(r_s\) is the fifth exterior edge of \(B\). Replace \(B\) by the chosen 5-cycle \(Q\), keeping all five exterior edges. This removes six vertices and leaves a cubic bridgeless graph: both gadgets connect all ports, and deleting an internal edge of \(Q\) leaves it connected. By minimality the smaller graph has a BF cover. Lift its literal six boundary labels through \(B\) and glue to obtain a BF cover of the original graph, contradiction. Combined with Note 161,
\[
\boxed{F\text{ disconnected}\quad\Longrightarrow\quad
M=\delta_J(A)\text{ is a five-edge cut separating two odd components of }F.} \tag{1}
\]
This conclusion is restricted to a minimum BF counterexample with genuine Case-XII support. The remaining five-cut branch has at least three single-crossing perfect matchings of \(J\) by Note 161, but its synchronized BF closure has not been settled. The same 5-cycle lifting method has a precise stopping point there: if one odd shore \(A\), all five subdivision vertices, and the opposite pentagon are made into a five-pole with ports at those subdivision vertices, an all-terminal matching would occupy every subdivision vertex through its port. The odd shore \(A\) and odd pentagon would then be disconnected unmatched remnants, so that belt has **no** all-terminal perfect matching. It cannot BF-lift an ordinary 5-cycle's all-terminal boundary type.
