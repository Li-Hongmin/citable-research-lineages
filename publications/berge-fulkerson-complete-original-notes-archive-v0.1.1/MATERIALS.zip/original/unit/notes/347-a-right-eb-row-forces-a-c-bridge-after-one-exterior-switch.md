> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A right \((ea)(eb)\) row forces a \(c\)-bridge after one exterior switch

> **Later strengthening:** [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) excludes the no-bridge right pair considered in this proof. Every actual right row already has a direct \(e\to c\) path. The six-cycle switch and the \(3\cdot2^k\) count below are conditional calculations for the excluded pair.

Work in the actual central-path six-port profile of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact Case-XII perfect-matching closure as specified by the published [Proposition 4.4 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Let
\[
 X_{ea}+Y_R+Z_e+U_{eb}+V_e+W_b=2\mathbf 1                 \tag{1}
\]
be any right-oriented required row, and let \(k\ge1\) be the number of components of \(X|_\Sigma\triangle U|_\Sigma\), as in [Notes 341–342](342-the-eb-row-creates-two-exterior-pure-load-fibres.md). An \(e\to c\) *bridge* means a row of form (1) in which the \(e\)-path of \(U\triangle D_e\), for at least one \(D_e\in\{Z,V\}\), ends at \(c\). By [Note 344](344-a-fixed-singleton-load-has-an-exact-two-state-fibre.md), that path supplies a second, \(bc\)-state decomposition of its \(eb\)-half while retaining its complete singleton-\(b\) matching.

**Right-row bridge theorem.** The complete matching closure of every row (1) contains an \(e\to c\) bridge. More precisely, one row obtained from (1) by at most one wholly exterior closed alternating-cycle switch of a singleton-\(e\) matching with \(W_b\) has the bridge in all \(2^k\) zero-port phases. These phases give at least \(2^k\) distinct complementary carrier pairs with the same complete singleton-\(b\) matching and the two-identity cross-carrier bridge of [Note 343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md).

**Proof.** If either \(U\triangle Z\) or \(U\triangle V\) already has its \(e\)-path ending at \(c\), [Note 346's phase-invariant endpoint theorem](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md) proves the assertion, with the original \(W\).

Otherwise Note 346's complete right-side table and load-two check leave only the unordered pair
\[
 \{\mathrm{III}:a:\Sigma,2B,3C,\quad
   \mathrm{IV}:a:\Sigma,1A,2C\}.                         \tag{2}
\]
Exchange the names \(Z,V\) if necessary so that \(Z\) is IV and \(V\) is III. The exterior load and singleton-\(b\) boundary force exactly the exterior \(W\)-mask of [Note 340, (5)](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md):
\[
 W|_{\rm ext}=\{a:C,c:A,d:E,1B,4D,h_2,h_3;\ b\}.        \tag{3}
\]
This uses no equality of the two zero-port shore matchings. Indeed, (2), \(X\), \(Y_R\), and \(U_A\) already account for two uses of every exterior edge except those of (3).

The six wholly exterior edges
\[
 c:A,\ 1A,\ 1B,\ d:B,\ d:E,\ c:E                         \tag{4}
\]
form the closed cycle \(t_c-A_{\rm ext}-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c\). Along it, \(Z\) uses \(1A,d:B,c:E\) and \(W\) uses \(c:A,1B,d:E\), so (4) is one complete alternating component of \(Z\triangle W\), regardless of the shore. Switch \(Z,W\) only on this cycle. The resulting actual perfect matchings \(Z',W'\) retain their singleton boundaries and every edge load; their exteriors are
\[
\begin{aligned}
 Z'|_{\rm ext}&=\mathrm{III}:a:\Sigma,1B,2C,\\
 W'|_{\rm ext}&=\{a:C,c:E,d:B,1A,4D,h_2,h_3;\ b\}.
\end{aligned}                                                \tag{5}
\]
All shore restrictions, in particular \(X|_\Sigma,U|_\Sigma,Z|_\Sigma\), are unchanged. The new row \(X+Y_R+Z'+U+V+W'=2\mathbf1\) is therefore genuine. Note 346's right table gives \(p(Z')=c\), and the same table applies to every one of the \(2^k\) zero-port phases. Their pure half-loads \(X_C+Y_R+V\) differ on the \(k\) independent shore cycles, so their complementary carrier pairs are distinct. Note 343 gives the claimed two-identity bridge in each pair. \(\square\)

There is also an exact exterior-fibre gain in the no-bridge case (2). The original pure loads \(X_C+Y_R+Z\) and \(X_C+Y_R+V\) have different nonunit exterior vectors: the first has load two on \(1A\), while the second has load two on \(2B\). The switched pure load \(X_C+Y_R+Z'\) has the unit exterior vector, as can be checked on the eight \(K\)-edges, four marked vertices and all six shore ports. Thus these three exterior fibres supply at least \(3\cdot2^k\) distinct complete pure \(ea\) half-loads. The cycle (4) and this count are valid with \(X|_\Sigma\ne U|_\Sigma\); the contradiction in Note 340 used the additional equality, which is unavailable here.

Together with Note 346's direct \(e\to c\) conclusion for every left \(Y_L,U_D\) row, this leaves only left \(Y_L,U_A\) rows as a possible *global absence* of an \(e\to c\) bridge. A left row can still have such a bridge through a different closed switch; none is asserted here. Even where the bridge is forced, [Notes 345 and 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md) still require a shore-owner check and even residual closed cycles before the third singleton identity joins. For the specific right bridge produced above, [Note 351](351-the-right-aj-bridge-forces-an-a-d-e-triple-hit-at-i.md) subsequently shows that a successful third identity forces a threefold singleton hit at \(I\), so this tuple cannot itself give an all-terminal BF cover. None of these results excludes exact Case XII. Their inputs include the hand-derived exterior classifications of Notes 271 and 346, which still require independent proof review.
