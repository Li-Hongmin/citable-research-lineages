> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Triple states of the two-vertex five-cut connector are shore deletions

Use the genuine two-vertex connector of [Note 204](204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md). Its unmarked exterior edges form the path
\[
w_1-u_1-w_0-u_2-w_2,
\]
with two edges \(u_iv_i\) into the odd unmarked shore \(F_C=F[C]\). Name the marks \(a=w_0x_a\), \(b=w_1x_b\), \(c=w_2x_c\), \(f=w_1w_2\), and \(e=x_e^-x_e^+\subset C\), where the \(x\)'s lie in \(C\). Each mark is subdivided and given its terminal semiedge. Endpoints of different marks may coincide unless a displayed perfect matching selects them simultaneously.

For an exposed vertex \(x\in C\), write \(I_x=1\) when \(F_C-x\) has a perfect matching. In particular put
\[
H_i=I_{v_i},\qquad I_a=I_{x_a},\ I_b=I_{x_b},\ I_c=I_{x_c},
\qquad E=I_{x_e^-}\lor I_{x_e^+}.                    \tag{1}
\]
Here a triple state \(ij\) means that its terminal boundary is the other three labels.

**Exact triple-matching criterion.** Every triple-boundary perfect matching selects **exactly one** vertex of \(C\) through a marked half-edge or one of \(u_1v_1,u_2v_2\). Its restriction to \(F_C\) is a perfect matching after deleting that vertex. The possible deleted vertices, and hence the exact support, are
\[
\begin{array}{c|c|c}
\text{missing pair}&\text{possible deleted vertices in }C&\text{state exists iff}\\\hline
ex\ (x\in\{a,b,c,f\})&x_e^-,x_e^+&E\\
ab&v_1,x_a,x_b&H_1\lor I_a\lor I_b\\
ac&v_2,x_a,x_c&H_2\lor I_a\lor I_c\\
af&v_1,v_2,x_a&H_1\lor H_2\lor I_a\\
bc&v_1,v_2,x_b,x_c&H_1\lor H_2\lor I_b\lor I_c\\
bf&v_1,v_2,x_b&H_1\lor H_2\lor I_b\\
cf&v_1,v_2,x_c&H_1\lor H_2\lor I_c.
\end{array}                                                     \tag{2}
\]
Each listed shore-deletion matching extends through at least one explicit exterior route; there are no other routes. Formula (2) classifies **single** full perfect matchings, not six-matching BF rows.

**Proof.** A triple matching uses precisely the two marked half-edges at its missing pair; at the other three marked subdivision vertices it uses terminal semiedges. If one missing mark is \(e\), its active half-edge selects one of \(x_e^-,x_e^+\). The other missing mark must select its exterior endpoint: otherwise the exterior path has odd order and deleting either \(u_i\) through its shore edge leaves an unmatched leaf. After removing the selected exterior endpoint, the four remaining path vertices have their unique perfect matching. For \(f\), either endpoint \(w_1,w_2\) can be selected. This proves the first line of (2).

Now neither missing mark is \(e\). The two active marks are among \(a,b,c,f\). If one of \(a,b,c\) selects its \(C\)-endpoint, the other active mark must select an exterior vertex; deleting that exterior vertex leaves a four-vertex path or two disjoint edges, matched entirely outside \(C\). Thus the sole exposed shore vertex is the \(C\)-endpoint of the first mark. Selecting both active marks into \(C\) leaves all five exterior path vertices. Neither shore edge can repair this: using \(u_1v_1\) strands \(w_1\), while using \(u_2v_2\) strands \(w_2\), whose relevant marked halves are already unavailable. Selecting both shore edges leaves three unmatched exterior vertices. Hence there is no two-mark-to-\(C\) route.

If both active marks select exterior vertices, remove those two vertices from the five-vertex path. The remaining three vertices can be matched only by using exactly one of \(u_1v_1,u_2v_2\). Checking the two ends and the middle vertex gives:
\[
\begin{array}{c|c}
\text{two exterior selections}&\text{usable shore edge}\\\hline
a:w_0,\ b:w_1&u_1v_1\\
a:w_0,\ c:w_2&u_2v_2\\
a:w_0,\ f:w_1&u_1v_1\\
a:w_0,\ f:w_2&u_2v_2\\
b:w_1,\ c:w_2&u_1v_1\text{ or }u_2v_2\\
b:w_1,\ f:w_2&u_1v_1\text{ or }u_2v_2\\
c:w_2,\ f:w_1&u_1v_1\text{ or }u_2v_2.
\end{array}                                                     \tag{3}
\]
All other proposed two-exterior selections either choose the same vertex twice or leave isolated vertices. In each line, the unused exterior vertices are covered by path edges after the stated shore edge is chosen. Adjoin any perfect matching of \(F_C\) after deleting the listed \(C\)-vertex. This gives every route in (2) and proves both necessity and sufficiency. \(\square\)

Complete exact Case XII requires all ten triple states, so (2) gives \(E=1\) and every displayed non-\(e\) clause. A useful sharp implication is
\[
H_1=H_2=0\quad\Longrightarrow\quad I_a=I_b=I_c=1.       \tag{4}
\]
The converse of (4) supplies all ten **triple states**, but it does not supply even one BF row. The next closure question is whether the same shore deletion matchings can be coupled across the six slots while the forbidden \(T\)--\(T\) types remain absent.
