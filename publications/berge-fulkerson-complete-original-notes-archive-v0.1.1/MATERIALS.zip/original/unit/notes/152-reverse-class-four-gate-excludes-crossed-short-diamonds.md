> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A reverse class-four gate excludes the crossed short diamonds

The complete-matching transport of [Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) has a reverse consequence: a terminal pairing of the **original** class-four occurrence tests the common pair-load seed of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md). Applied to the aligned six-edge diamond of [Notes 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) and [146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md), it excludes two of the four owner patterns under the no-seed hypothesis. All matchings and equalities below are complete edge masks. The result assumes actual rows; it does not assert that an exact-Case-XII pole exists. The two-hit corollary and the residual-pattern deductions are new analytic arguments awaiting independent verification.

Put \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Assume a cubic five-pole has no BF cover with an all-terminal matching and no BF type with both states in \(T\), including loops. Write \(\operatorname{Seed}(H)\) for the two-row common-\(B_2,C_4\) statement in Note 118(1).

## The reverse endpoint gate

**Theorem 1.** In every actual right row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1,             \tag{1}
\]
if the open component of \(r_{34}\triangle C_4\) starting at terminal \(4\) ends at \(1\) or \(2\), then \(\operatorname{Seed}(H)\) holds. Consequently, in the absence of a seed, **every** such right row has
\[
\operatorname{pairing}(r_{34}\triangle C_4)=(1\,2)(4\,5).\tag{2}
\]

**Proof.** First prove the forward endpoint gate for any right row with class-four occurrence \(C\). Switch the forced \(q_{25}\triangle D_5\) terminal path from \(5\) to \(4\), obtaining \(q_{25}+D_5=q_{24}+\widehat C_4\). The other possible endpoints give a forbidden \(T\)--\(T\) row against the unchanged state-\(34\) half. Exchange the two class-four occurrences to get the actual row
\[
(q_{24}+B_2+C_4)+(r_{34}+Y_3+\widehat C_4)=2\mathbf1. \tag{3}
\]
If \(r_{34}\triangle\widehat C_4\) connects \(4\) to \(2\), switching that path yields \(r_{23}+\widehat B_2\). Regroup the complete occurrences as
\[
(q_{24}+\widehat B_2+C_4)+(r_{23}+B_2+Y_3)=2\mathbf1.
\]
The \(q_{24}\triangle\widehat B_2\) path from \(2\) must end at \(1\): endpoints \(3,5\) would give states \(34,45\in T\) against the fixed state \(23\in T\). Its switch gives a left \((14)(23)\) row sharing the original complete \(B_2,C_4,Y_3\) with (1).

If \(r_{34}\triangle\widehat C_4\) instead connects \(4\) to \(1\), switch it to get \(r_{13}+A_1\). The \(q_{24}\triangle r_{13}\) path from \(2\) cannot end at \(3\): the resulting triples have states \(34,12\), and regrouping them with \((Y_3,C_4)\) and \((A_1,B_2)\), respectively, gives a forbidden \(T\)--\(T\) row. It cannot end at \(4\), which would give an all-terminal matching. It therefore ends at \(1\). Switch the two triples to get \(q_{14}+r_{23}\), then exchange the complete singleton occurrences \(A_1,B_2\) between the halves. The resulting left row is \(q_{14}+A_1+C_4+r_{23}+B_2+Y_3=2\mathbf1\), sharing the complete \(B_2,C_4,Y_3\) with (1). This proves the forward gate for \(r_{34}\triangle\widehat C_4\).

Now apply Note 129's two-switch transport to (1). Its first switch is the one just used. After exchanging \(\widehat C_4,C_4\), the forced \(q_{24}\triangle C_4\) path returns the first half to state \(25\). The resulting **partner right row** has the same complete \(B_2,Y_3,r_{34}\) and has \(\widehat C_4\) as its class-four occurrence. The first \(q_{25}\triangle D_5\) path switch of this partner reverses the last switch and produces the *original complete* \(C_4\). Apply the forward gate to the partner. If \(r_{34}\triangle C_4\) joins \(4\) to \(1\) or \(2\), it gives a left row sharing \(B_2,\widehat C_4,Y_3\) with that partner right row. In particular their complete \(B_2+C_4\) loads agree, proving the seed. If there is no seed, the only remaining endpoint for the \(4\)-path is \(5\); the other ends are \(1,2\), proving (2). \(\square\)

There is a nontrivial phase consequence. The intermediate row (3) has two class-four occurrences \(C_4\ne\widehat C_4\), by [Note 139](139-overlap-bf-rows-force-distinct-common-singleton-matchings.md): equality would give a forbidden state-\(34\) Tait colouring. On every proper even component of \(C_4\triangle\widehat C_4\), the two class-four occurrences may be exchanged independently. The forced return switch of Note 129 turns each resulting phase into a right row retaining \(B_2,Y_3,r_{34}\). Thus (2) says that, under no seed, **every subphase** of this nonempty difference keeps the \(4\leftrightarrow5\) pairing with \(r_{34}\). This is a necessary condition, not a contradiction.

**Two-hit corollary.** Under no seed, no component \(\Gamma\) of \(C_4\triangle\widehat C_4\) can have exactly two edges in \(r_{34}\triangle C_4\), both owned by \(C_4\), with one on the open \(4\leftrightarrow5\) path and the other on the open \(1\leftrightarrow2\) path. Indeed, switching \(C_4\) on \(\Gamma\) is one permitted subphase. The identity
\[
r_{34}\triangle(C_4\triangle E(\Gamma))
=(r_{34}\triangle C_4)\triangle E(\Gamma)                \tag{4}
\]
deletes the two indicated \(C_4\)-edges and inserts the two complementary arcs of \(\Gamma\). Each arc joins a free end from one old open path to a free end from the other, so the two terminal pairings are crossed. The new pairing sends \(4\) to \(1\) or \(2\), contrary to Theorem 1 and the subphase consequence. The corollary does not say that every nontrivial class-four phase cycle has exactly two hits; further hits or a phase confined to one open path can preserve the pairing.

## Exact trace through a six-edge aligned diamond

Assume in addition a normalized original overlap row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1             \tag{5}
\]
with four junctions as in Note 143, a six-edge \(Z_3\triangle Y_3\) component \(\Omega\), and an aligned right row (1) satisfying \(q_{25}+B_2=U_{35}+Z_3\) and \(B_2=U_{35}\) at every vertex of \(\Omega\). Pair the right occurrences as \((q,Y),(B,C),(D,r)\), and assume its total junction count is \(J'=5\). The four junctions on \(\Omega\) leave one exterior junction \(w\). The exact Case-XII negative support supplies the hypotheses of Theorem 1 and forbids state-\(34\) Tait colourings, so Note 146's four owner patterns apply. Write \(e_i=v_{i-1}v_i\) cyclically, with \(v_6=v_0\).

**Strand trace.** Outside the diamond theta core, the normalized original row has split active strands. The complete carrier identity \(q+B=U+Z\) gives the following nonjunction right type-\(23\) vertices:

| Original incident owner pairs | Carrier phase | Right type-\(23\) passage of \(r\triangle C\) |
|---|---|---|
| \((Ur,ZY,DC)\) | \(q=Z,\ B=U\) | \(Ur,DC\) |
| \((UY,Zr,DC)\) | \(q=U,\ B=Z\) | \(Zr,DC\) |

These are the only nonjunction possibilities: a split original type-\(13\) vertex becomes right type \(12\) or inactive, and a split original type-\(23\) vertex becomes right type \(13\) or a junction. The other phase at a split original type-\(12\) vertex would make its entire closed \(U\triangle Z\) component a set of right junctions; the other phase at a split original type-\(23\) vertex would make both ends of a \(ZC\) edge right junctions. Both violate the one-exterior-junction count. Consequently \(w\) is an original inactive \((Ur,ZY,DC)\) vertex with \(q=U\). Its right type-\(23\) edge is \(DC\), and its right type-\(13\) edge is \(Ur\). The right type-\(13\) strand from \(w\) ends at terminal \(1\); its interior vertices have original pairs \((Ur,ZC,YD)\) and \(q=U\).

Switch the complete \(U,r\) pair on every exterior closed original type-\(12\) component, obtaining \(\widetilde U,\widetilde r\) in an actual original row. This switch changes no edge of \(\Omega\) or its terminal arms. At either nonjunction vertex in the table, \(\widetilde U\triangle D\) follows the same right type-\(23\) passage as \(r\triangle C\); at \(w\), \(\widetilde U\triangle D\) joins that passage to the right type-\(13\) strand ending at \(1\). At terminal \(2\), both \(r\) and \(\widetilde U\) use the semiedge. Therefore a right type-\(23\) strand joining \(w\) to terminal \(2\) would make \(\widetilde U\triangle D\) join \(1\) to \(2\). Switching this open path yields the forbidden \((34)(34)\) BF type. The \(w2\) strand is excluded.

The remaining two right type-\(23\) pairings join exactly one core port to terminal \(2\). At every interior vertex of that strand \(r,C\) follow its two edges as in the table; its terminal semiedge is \(r\)-owned. Thus a core \(r/C\) passage entering this port continues all the way to terminal \(2\). The forced \(\widetilde U\triangle D\) terminal pairing is \((1\,5)(2\,4)\): switching its \(5\)-path to either \(2\) or \(4\) would give a forbidden \(T\)--\(T\) row. Hence the original terminal arm whose \(\widetilde U/D\) core passage uses the \(2\)-port is the terminal-\(4\) arm.

**Theorem 2.** Of Note 146's four possible six-edge owner patterns, the crossed patterns \((2,1,2,1)\) and \((1,2,1,2)\) force \(\operatorname{Seed}(H)\). In particular,
\[
\boxed{\text{aligned six-edge diamond},\ J'=5,\ \neg\operatorname{Seed}(H)
\quad\Longrightarrow\quad
(\alpha,\beta,\gamma,\delta)\in\{(2,2,1,1),(1,1,2,2)\}.} \tag{6}
\]

**Proof.** Let \(\tau_0,\tau_b\) be the terminals of the two original type-\(13\) arms, where \(\{\tau_0,\tau_b\}=\{4,5\}\). Read each core passage from the owner pairs in Note 146; a terminal arm alternates \(r,C\) on its \(Dr,UC\) edges. The two crossed patterns give:

| Pattern | Original arms | Exterior right type-\(23\) ports | \(\widetilde U/D\) arm-to-port map | \(r/C\) arm-to-port map |
|---|---|---|---|---|
| \((2,1,2,1)\) | \(v_0,v_3\) | \(v_1,v_4\) | \(\tau_0\to v_1,\ \tau_3\to v_4\) | \(\tau_0\to v_4,\ \tau_3\to v_1\) |
| \((1,2,1,2)\) | \(v_0,v_3\) | \(v_2,v_5\) | \(\tau_0\to v_5,\ \tau_3\to v_2\) | \(\tau_0\to v_2,\ \tau_3\to v_5\) |

For the first pattern the owner sequence is \((UZ,rY,ZC,UY,rZ,YC)\). From \(\tau_0\), the \(r/C\) path uses \(e_6,e_5\) and exits at the \(DC\) port of \(v_4\); from \(\tau_3\), it uses \(e_3,e_2\) and exits at the \(DC\) port of \(v_1\). The \(\widetilde U/D\) passages use \(e_1\) and \(e_4\), respectively. For the second pattern the owner sequence is \((rY,ZC,YD,rZ,YC,ZD)\). Its \(r/C\) passages use \(e_1,e_2\) from \(\tau_0\) to the \(Ur\) port of \(v_2\), and \(e_4,e_5\) from \(\tau_3\) to the \(Ur\) port of \(v_5\); its \(\widetilde U/D\) passages use \(e_6\) and \(e_3\). These traces prove the table.

At the core port paired to terminal \(2\), the \(\widetilde U/D\) arm is terminal \(4\). The table shows that the \(r/C\) arm on the **same port** is the other arm, terminal \(5\). The complete \(r_{34}\triangle C_4\) therefore has a \(5\leftrightarrow2\) open path. Its remaining ends pair \(4\leftrightarrow1\), so Theorem 1 supplies a common complete seed.

For comparison, in the \((2,2,1,1)\) pattern the \(r/C\) core joins its two original terminal arms through \(e_6,e_5\); in the \((1,1,2,2)\) pattern it does so through \(e_1,e_2\). Those two patterns already have \(r/C\) pairing \((1\,2)(4\,5)\), and this gate does not exclude them. \(\square\)

**Core-exit corollary.** In each of the four Note-146 owner patterns, no simple cycle wholly contained in the theta core \(\Theta=\Omega\cup\chi\) alternates with \(C_4\). The three possibilities are \(\Omega\) and the two cycles using the chord \(\chi\). On \(\Omega\), \(C_4\) owns only \(e_3,e_6\) in the first two patterns and only \(e_2,e_5\) in the last two; an alternating six-cycle requires three \(C_4\)-edges. At both chord endpoints the chord edge has owner pair \(UD\), so \(C_4\) uses an \(\Omega\)-edge. In the first two patterns its endpoint choices are \(e_3\) at \(v_2\) and \(e_6\) at \(v_5\); in the last two they are \(e_2\) at \(v_1\) and \(e_5\) at \(v_4\). In each case these two choices lie on opposite arcs of \(\Omega\) between the chord endpoints. Thus neither chord cycle contains the \(C_4\)-edge at both endpoints. Every component of \(C_4\triangle\widehat C_4\) that meets \(\Theta\) must therefore also use an edge outside \(\Theta\). This applies in particular to the two patterns surviving (6).

**Forced common-singleton escape in the two surviving patterns.** Choose the first Note-129 switch with no additional closed phase, and let \(P_{54}\) be its forced \(5\leftrightarrow4\) component of \(q_{25}\triangle D_5\), so \(\widehat C_4=D_5\triangle E(P_{54})\). In pattern \((2,2,1,1)\) take \(a=v_4\); in pattern \((1,1,2,2)\) take \(a=v_0\). The original type-\(13\) terminal arm leaving \(a\) begins with an edge \(h\) owned by \(U,C\). Then
\[
\boxed{h\in E(C_4\triangle\widehat C_4)\cap E(r_{34}\triangle C_4),
\quad \exists g\in E(P_{54})\cap E(C_4\triangle\widehat C_4)
\text{ leaving a vertex of that arm, with original owners }\{Z_3,Y_3\}.} \tag{7}
\]
In particular \(q_{25}(g)=\widehat C_4(g)=Z_3(g)=Y_3(g)=1\), while \(r_{34}(g)=C_4(g)=0\). The edge \(g\) is outside the theta core and lies on the **same** class-four difference component as \(h\).

**Proof.** At \(v_4\) in the first pattern the three incident owner pairs are \(YD,rZ,UC\). Alignment makes \(q\) use the \(rZ\) edge and \(D\) use the \(YD\) edge; neither uses \(h=UC\). At \(v_0\) in the second pattern the pairs are \(rY,ZD,UC\), and \(q=D\) on \(ZD\), again avoiding \(h\). Since \(\widehat C\) is obtained by choosing the \(q\)- or \(D\)-edge at each vertex, it cannot use \(h\), while \(C\) does. The edge \(h\) must be proper: if it were the terminal-\(4\) semiedge, both class-four matchings would use it, and the terminal-\(5\) semiedge has owner pair \(Dr\). The core \(r/C\) trace of the preceding proof puts \(h\) on its open terminal-\(4\)--terminal-\(5\) path.

Follow the \(C\triangle\widehat C\) component through \(h\) away from \(a\). Every nonterminal vertex of this original split type-\(13\) arm has the owner triple \((UC,Dr,ZY)\). There \(C\) follows the \(UC\) edge. If \(\widehat C\ne C\), its other edge is either \(Dr=D\), continuing along the arm, or \(ZY=q\), leaving the arm. The component cannot end at terminal \(4\), where both class-four matchings use the same semiedge. If it reaches terminal \(5\), then \(\widehat C\) cannot use its \(Dr\) semiedge and must leave by a \(ZY\) edge. Thus it leaves the arm on a \(ZY\) edge \(g\). This edge is proper: a \(ZY\) semiedge would be terminal \(3\), which the class-four matching \(\widehat C\) avoids. Since \(D(g)=0\) and \(\widehat C(g)=1\), the chosen first-switch identity \(\widehat C=D\triangle E(P_{54})\) forces \(g\in P_{54}\) and \(\widehat C(g)=q(g)=1\). The original owner pair gives \(Z(g)=Y(g)=1\); the row load excludes \(r,C\) there. \(\square\)

**A forced cross-path contact.** Let \(\Gamma_h\) be the component of \(C_4\triangle\widehat C_4\) containing \(h\) in (7). In pattern \((1,1,2,2)\), \(q=D\) on \(e_6\) at both ends, so \(\widehat C=D\) there. Starting at \(h\) through \(v_0\), the same phase cycle necessarily uses \(e_6\) as its \(\widehat C\)-edge and then \(e_5=YC\) as its \(C\)-edge. The edge \(e_5\) lies on the **other**, \(1\leftrightarrow2\), open path of \(r_{34}\triangle C_4\). Thus \(\Gamma_h\) has at least one \(C\)-edge on each open path. If no seed exists, the two-hit corollary forces \(\Gamma_h\) to have at least one further edge in \(r_{34}\triangle C_4\); the common-\(ZY\) escape edge \(g\) of (7) cannot be this further hit.

In pattern \((2,2,1,1)\), the same conclusion holds **if \(P_{54}\) avoids \(v_4\)**. Then \(\widehat C=D\) on \(e_4=YD\), so \(\Gamma_h\) continues from \(h\) through \(e_4\) and the \(C\)-edge \(e_3=ZC\) on the open \(1\leftrightarrow2\) path. Under no seed it again requires a further \(r\triangle C\) hit. If \(P_{54}\) visits \(v_4\), then \(\widehat C=q\) on \(e_5=rZ\), and the phase cycle first reaches \(e_6=YC\), another edge of the \(4\leftrightarrow5\) path; this argument does not force a cross-path contact in that branch.

**Exit dichotomy for the canonical cross-half triple.** Let \(P_{23}\) be the forced \(2\leftrightarrow3\) path of \(q_{25}\triangle r_{34}\) from [Note 131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md), and put \(p_{35}=q_{25}\triangle E(P_{23})\). At the edge \(g\) of (7), \(q=1\) and \(r=D=0\), so \(g\) belongs to both \(q\triangle r\) and \(P_{54}\). Exactly one of the following holds:

* \(g\notin P_{23}\). Then \(p(g)=q(g)=Z(g)=Y(g)=1\), giving an actual common-singleton edge in \((p_{35}\cap Z_3)\setminus\Theta\).
* \(g\in P_{23}\). Then \(p(g)=0\), and the same open \(P_{23}\) must use a **second, distinct \(ZY\) edge incident with the same original type-\(13\) terminal arm**.

For the second assertion, \(q\triangle r\) follows \(UC/Dr\) along such an arm whenever it stays on it, and enters or leaves it only by a \(ZY\) third edge. It cannot enter through the core end: at \(v_4\) in the first pattern \(q=r\) on \(e_5\), while at \(v_0\) in the second pattern neither \(q\) nor \(r\) uses the \(UC\) arm edge. It cannot end at terminal \(4\) or \(5\), since \(P_{23}\) has terminal ends \(2,3\). Thus a visit through \(g\) needs another side exit. This dichotomy uses actual full paths but does not identify the component of \(p\triangle Z\) containing the first alternative's edge.

In both surviving patterns the \(q_{25}\triangle D_5\) terminal path used by Note 129 cannot follow both original terminal arms all the way through the core. Equation (7) identifies its forced exit through a common \(ZY\) edge. Pattern \((1,1,2,2)\), and pattern \((2,2,1,1)\) when \(P_{54}\) avoids \(v_4\), already have a cross-path contact inside the core; under no seed their distinguished phase cycle must acquire an additional \(r\triangle C\) contact. The remaining question is whether the actual external connections can supply a pairing-neutral return while complete exact-Case-XII support holds. Neither pattern is asserted realizable.

The theorem uses the **negative** Case-XII support and an aligned, minimal-junction actual row. It says nothing about higher-junction rows or whether either remaining pattern survives complete perfect-matching closure. The support used here agrees with the Case-XII entries of [Máčajová–Mazzuoccolo–Tabarelli (2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Proposition 4.4 and Appendix XII; their boundary classification does not establish a common complete-mask seed.
