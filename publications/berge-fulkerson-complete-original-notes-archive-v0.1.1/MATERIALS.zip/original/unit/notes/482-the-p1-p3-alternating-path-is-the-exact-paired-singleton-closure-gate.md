> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(p_1\)--\(p_3\) alternating path is the exact paired-singleton closure gate

Continue the genuine \(D_2\) class-IV row of [Notes 479--481](481-the-two-old-signature-class-iv-loops-have-unique-exteriors-and-one-mask-switch-gates.md), with \(\sigma=a,\bar\sigma=b\). Its six **complete** shore matchings \(Q_P,Q_R,Q_a,Q_b,Q_J,Q_K\) have port signatures
\[
\partial Q_P=\partial Q_R=\varnothing,\quad
\partial Q_a=\{e,p_1,p_2,p_4\},\quad
\partial Q_K=\{p_3,p_5\},\quad
\partial Q_b=\{e,p_2,p_3,p_4\},\quad
\partial Q_J=\{p_1,p_5\}.                              \tag{1}
\]
The pairs \((Q_a,Q_K)\) and \((Q_b,Q_J)\) each use all six shore ports once. In either pair, the symmetric difference therefore consists of three alternating port-to-port paths and possibly even closed alternating cycles. Let \(\pi_{aK}\) and \(\pi_{bJ}\) be the respective pairings of the six ports by those paths. Shared internal edges of the two source matchings play no role in the path pairing; both matchings must keep them in any decomposition of their vector sum.

## Exact paired-singleton exchange

The following two implications are equivalences about **actual shore perfect matchings**, not merely port loads:
\[
\begin{aligned}
 \pi_{aK}(p_1)=p_3
 &\ \Longleftrightarrow\
 \exists\,Q_b',Q_J':
 \quad \partial Q_b'=\partial Q_b,\quad
 \partial Q_J'=\partial Q_J,\quad
 \mathbf1_{Q_b'}+\mathbf1_{Q_J'}
   =\mathbf1_{Q_a}+\mathbf1_{Q_K};                    \tag{2}\\
 \pi_{bJ}(p_1)=p_3
 &\ \Longleftrightarrow\
 \exists\,Q_a',Q_K':
 \quad \partial Q_a'=\partial Q_a,\quad
 \partial Q_K'=\partial Q_K,\quad
 \mathbf1_{Q_a'}+\mathbf1_{Q_K'}
   =\mathbf1_{Q_b}+\mathbf1_{Q_J}.                    \tag{3}
\end{aligned}
\]
Every matching in (2)--(3) is complete on the whole shore. In (2), the old zero masks \(Q_P,Q_R\), the old \(Q_b,Q_J\), and the two constructed masks \(Q_b',Q_J'\) form a load-two shore row; gluing the unique \(t=0\) exterior of Note 481(2) gives a genuine forbidden \([eY]\) BF row. Equation (3) and the unique \(t=2\) exterior of Note 481(3) similarly give a forbidden \([eX]\) BF row. Thus **either** alternating-path pairing forces forbidden complete support.

To prove (2), a decomposition of \(\mathbf1_{Q_a}+\mathbf1_{Q_K}\) must put every shared edge in both new matchings. On each component of \(Q_a\triangle Q_K\), the two new matchings can only take the two old alternating phases, possibly swapped on that whole component. The only \(Q_a\)-port assigned to the target \(Q_J'\) is \(p_1\), and the only \(Q_K\)-port **not** assigned to \(Q_J'\) is \(p_3\); its other \(Q_K\)-port is \(p_5\). A path starting at \(p_1\) cannot end at another \(Q_a\)-port, which would give \(Q_J'\) a second unwanted \(Q_a\)-port. It cannot end at \(p_5\), since the \(Q_a\)-phase selected at \(p_1\) omits the \(Q_K\)-port at the other end, while \(Q_J'\) must use \(p_5\). Hence its other end is \(p_3\). Conversely, if \(p_1p_3\) is a path, give \(Q_J'\) the \(Q_a\)-phase on it. The path ending at \(p_5\) then meets one of \(e,p_2,p_4\); give \(Q_J'\) its \(Q_K\)-phase. The remaining two \(Q_a\)-ports share a path; give \(Q_J'\) its \(Q_K\)-phase there as well. Choose either phase independently on each closed alternating cycle. The complementary phases define \(Q_b'\). Both are perfect matchings and have exactly the prescribed port sets. The same argument with source pair \(Q_b,Q_J\), target \(Q_a',Q_K'\), and distinguished \(Q_b\)-port \(p_3\) proves (3): the \(p_3\)-path must end at the \(Q_J\)-port \(p_1\).

Conversely, suppose a \(t=0\) forbidden row keeps the two old zero masks and includes one old \(Q_b\) and one old \(Q_J\) among its four singleton shore restrictions. Subtracting its shore load-two equation from the old row gives exactly the vector identity in (2); hence \(\pi_{aK}(p_1)=p_3\). The analogous \(t=2\) row with old \(Q_a,Q_K\) gives (3). This is the **exact** boundary of the paired-singleton exchange while both old zero masks are retained. It does not classify rows that change a zero mask or replace both masks in one singleton role.

If \(Q_P\ne Q_R\), neither pair of newly constructed masks in (2) or (3) can *both* equal its two old target masks: otherwise the two old singleton pair sums agree, forcing \(Q_P=Q_R\) by Note 480. If in addition all four one-mask gates of Note 481(4) fail, **both** constructed masks in the applicable equation are new. Thus in that regime (2)--(3) give a forbidden full row with exactly two new complete shore masks. A genuine exact-Case-XII pole in this fixed exterior and class-IV phase must therefore satisfy the further necessary conditions
\[
                 \pi_{aK}(p_1)\ne p_3,\qquad
                 \pi_{bJ}(p_1)\ne p_3.                 \tag{4}
\]
These conditions use the full old shore matchings, not just their port sets.

The 29-vertex Petersen-substituted pole of Note 481 shows that (4) is a real boundary, not a formal port restriction. In its old lifted row, the untouched six-cycle segment \(p_1-q_1-q_e-e\) is a \(Q_a\triangle Q_K\) path, so \(\pi_{aK}(p_1)=e\). The untouched segment \(p_1-q_1-q_5-p_5\) is a \(Q_b\triangle Q_J\) path, so \(\pi_{bJ}(p_1)=p_5\). It nevertheless has both forbidden loops, each requiring exactly three new complete shore masks among old-signature rows, by Note 481. Hence (4) cannot exclude the remaining two-or-more-mask closure mechanisms, even with the odd-zero condition.

This result isolates one complete-matching closure mechanism in an arbitrary-order shore and supplies two more necessary restrictions for genuine exact Case XII. It does not prove either restriction follows from the other positive Case-XII rows, nor does it exclude rows changing a zero mask or using new port signatures. The proof is hand-derived without OMEN or local mathematical recomputation and awaits independent review. \(\square\)

Later boundary: [Note 483](483-fixed-zero-class-iv-two-mask-closure-is-path-or-disjointness.md) adds the other two-new-mask allocation. If both new occurrences lie in one singleton role and the old zero masks remain fixed, the doubled old singleton must be edge-disjoint from both zero masks; that condition is also sufficient. Together with (2)--(3), this classifies all fixed-zero, old-signature rows using exactly two new complete shore masks once the one-mask gates fail.

Odd-zero correction: [Note 485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md) proves that every allocation with a repeated complete singleton mask is automatically impossible under Note 359's odd-zero premise. In that regime, (2)--(3) are the **only** old-signature forbidden-row mechanisms using at most two new complete shore masks; the other algebraic gates of Notes 481, 483, and 484 do not add independent restrictions.
