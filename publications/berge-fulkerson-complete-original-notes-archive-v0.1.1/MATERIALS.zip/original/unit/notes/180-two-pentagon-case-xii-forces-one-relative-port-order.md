> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two pentagon shores force one relative port order in exact Case XII

Assume the \(|U|=1\) two-five-cut quotient of [Notes 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) and [173](173-two-pentagon-shores-make-the-one-vertex-host-tait-colourable.md), with **both** shores \(A,B\) ordinary pentagons. Let \(p\) and \(q\) be the \(A\)-ports toward \(u,w\), and \(r,s,t\) its three ports on the marked \(A\)--\(B\) edges. Write \(\delta=A w\), \(\epsilon=B w\) for the other two terminal marks. The port toward \(u\) on \(B\) is identified with \(p\) only when comparing its boundary types; it is a distinct edge of the core. Every core colouring restricts to a common Tait state of the \(A\)-pentagon and the ear shore \(E(B)\) of Note 173.

If the opened five-pole \(H\) has exact Case-XII support, then, up to rotation and reversal of the two pentagons and relabelling the three shared marks, the only port topology **not excluded by the arguments below** is
\[
\boxed{
 B:\ p,\epsilon,r,s,t\quad\text{and}\quad
 A:\ p,q,r,t,s
 }                                                          \tag{1}
\]
in cyclic port order. Its allowed Tait five-cycle \(S\) must be one of
\[
\boxed{r-t-s-\delta-\epsilon-r,\qquad
       r-t-s-\epsilon-\delta-r.}                            \tag{2}
\]
This is a necessary structural reduction, not an assertion that either arrangement has exact BF support. [Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md) subsequently excludes both remaining cycles by genuine six-matching BF rows.

## A mixed common Tait state is impossible

By [Note 179, (4)](179-a-colourable-two-shore-core-opens-to-a-tait-colourable-five-pole.md), if a core colouring has its \(A\)-shore lonely pair consisting of one of \(p,q\) and one of \(r,s,t\), opening the marks produces three Tait states forming a triangle. Exact Case XII permits only the Tait-state set \(S\), a five-cycle, because Note 173 makes the core colourable and Note 179 opens that colouring. Thus **no mixed pair can be common** to the \(A\)-pentagon and \(E(B)\).

In Note 173, the attachments of \(u,w\) to \(B\) are adjacent (its \(v_2\) case) or at distance two (its \(v_3\) case). Its displayed actual ear colourings give respectively
\[
\begin{aligned}
\mathcal T(E(B))&\supseteq\{rt,st,rs,pr,qt,pq\} &&(v_2),\\
\mathcal T(E(B))&=\{rt,rs,ps,qt,pr,qr\} &&(v_3).
\end{aligned}                                                \tag{3}
\]
The \(A\)-pentagon Tait states are its five adjacent port pairs. Hence in the \(v_2\) case its cyclic port order must avoid the edges \(pr,qt\); in the \(v_3\) case it must avoid \(ps,qt,pr,qr\). This uses only actual colourings in (3), even if the \(v_2\) list has further states.

## The distance-two attachment is impossible

In the \(v_3\) case, avoidance of the four mixed edges forces \(p\)'s neighbours on the \(A\)-cycle to be \(q,t\), and \(q\)'s neighbours to be \(p,s\). The remaining port \(r\) joins \(s,t\), so \(A\) has the unique order \(p,q,s,r,t\). It shares the states \(rs,rt\) with the two displayed \(E(B)\) colourings. The explicit edge-colour rows of Note 173, opened by Note 179, yield the following states of \(H\):
\[
\begin{array}{c|cc}
\text{ear attachment}&\text{common core state}&\text{opened }H\text{ state}\\\hline
v_3&rs&rt\\
v_3&rt&rs
\end{array}                                                 \tag{4}
\]
For example, Note 173's \(v_3\) row \((x_2,x_3,x_4;y_2)=(2,1,3;1)\) has port colours \((p,q,r,s,t)=(2,2,3,2,1)\), the \(B\)-to-\(u\) colour \(3\), and opens to state \(rs\); its row with \(y_2=2\) opens to \(rt\). Thus \(rs,rt\in S\). The five-cycle \(S\) must then join \(s\) to \(t\) through \(\delta,\epsilon\), so \(\delta\epsilon\in S\).

But the \(A\)-cycle \(p,q,s,r,t\) has loop \([pt]\), and the \(B\)-cycle \(p,r,\epsilon,s,t\) has the same loop at its \(u\)-port. [Note 172, (4)](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) turns these actual shore loops into the outer loops \([t\delta]\), \([t\epsilon]\). When \(\delta\epsilon\in S\), the vertices \(\delta,\epsilon\) are at distance two in the forbidden complementary five-cycle \(T\), and at least one of \(t\delta,t\epsilon\) lies in \(T\). Exact Case XII forbids that \(T\)-loop. Therefore \(v_3\) is impossible.

## The adjacent attachment leaves one order

In the \(v_2\) case, avoidance of \(pr,qt\) leaves exactly four \(A\)-cycles, up to reversal. If \(pq\) is an edge, \(p\)'s other neighbour is \(s\) or \(t\), while \(q\)'s other neighbour is \(r\) or \(s\); the choice \(p-s,q-s\) closes a triangle before visiting all five ports. The other three choices give the first three rows below. If \(pq\) is absent, \(p\) must meet \(s,t\) and \(q\) must meet \(r,s\), giving the fourth row.

| \(A\) cyclic order | states shared with displayed \(E(B)\) rows | common shore loop at \(u\) | verdict |
|---|---|---|---|
| \(p,q,r,t,s\) | \(rt,st,pq\) | none | retained |
| \(p,q,r,s,t\) | \(rs,st,pq\) | \([pt]\) | excluded |
| \(p,q,s,r,t\) | \(rs,rt,pq\) | \([pt]\) | excluded |
| \(p,s,q,r,t\) | \(rt\) | \([pt]\) | excluded |

In each of the middle two rows, the common core state \(pq\) is the swapped monochromatic case of Note 179. Its opening has Tait state \(\delta\epsilon\), so \(\delta\epsilon\in S\); the common \([pt]\) loop is forbidden as above. In the last row, Note 173's \(v_2\) row \((x_2,x_3,x_4;y_2)=(2,3,1;1)\), with core state \(rt\), opens to state \(st\) of \(H\). If \(\delta\epsilon\in S\), the common loop again contradicts Note 172. If \(\delta\epsilon\in T\), the only way both loops \([t\delta],[t\epsilon]\) can be allowed is for \(t\) to be the common \(S\)-neighbour of \(\delta,\epsilon\); then the already required edge \(st\in S\) gives \(t\) three neighbours in \(S\), impossible. This excludes the last row.

In the retained first row, Note 173's displayed \(v_2\) colourings at common states \(rt,st,pq\) open via Note 179 to \(st,rt,\delta\epsilon\), respectively. These three edges force exactly the two possible five-cycles in (2). Here the two pentagon shores have no common loop \([0b]\) with \(b\in\{r,s,t\}\): the \(A\) neighbours of \(p\) are \(q,s\), while the \(B\) neighbours of its \(u\)-port are \(\epsilon,t\). Their unique disjoint pair types on the four shared ports also differ, namely \((rt)(ps)\) for \(A\) and \((rs)(pt)\) for \(B\). Thus the immediate negative-support gates of Note 172 do not settle this last arrangement. [Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md) uses two explicit matching exchanges to produce a forbidden BF pair for each of the two cycles in (2).
