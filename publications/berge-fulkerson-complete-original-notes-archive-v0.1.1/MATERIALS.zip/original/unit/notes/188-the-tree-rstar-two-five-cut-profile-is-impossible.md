> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The tree--R-star two-five-cut profile is impossible

In the minimum-host \(|U|=1\) two-five-cut profile of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md), let \(A^\circ\) be a three-vertex tree with centre port \(0\) and end groups \(\{\delta,x\}\mid\{y,z\}\). Let \(B^\circ\) have the published Case-XIII \(R^*\) relation. **No relative port placement gives exact Case-XII boundary support.** [Notes 185--187](187-the-tree-rstar-adjacent-special-ports-are-impossible.md) already exclude \(\delta\epsilon\in T\); the proof below excludes every placement with \(\delta\epsilon\notin T\). Thus, in this \(|U|=1\) profile, an exact-Case-XII pole cannot have a tree shore: tree--tree and tree--pentagon have order at most fifteen [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md), and tree--\(L^*\) is excluded by [Note 183](183-a-shared-pair-tait-shore-and-a-loop-universal-shore-force-seven-loops.md).

Write \(c(p)\in\{P,Q\}\) for the block containing a local missing-pair state \(p\) of \(B^\circ\), where the Figure-7 blocks are
\[
P=\{13,14,24,35,45\},\qquad Q=\{12,15,23,25,34\}.
\]
Every pair of states in opposite blocks is an **actual** \(B^\circ\) BF type. Consequently, if a displayed connector row would produce two forbidden \(T\)-states from a \(B^\circ\) input \((p)(q)\), exact Case XII forces \(c(p)=c(q)\). The argument uses the complete \(R^*\) relation, not selected matching rows. The block \(P\) is a four-cycle \(4-1-3-5-4\) with leaf \(2\) attached at \(4\); \(Q\) is the triangle \(1-2-5-1\) with tail \(2-3-4\). Each block has exactly one vertex of degree three, and only \(Q\) has a triangle.

## Actual six-slot transports

We give all new transports needed below. In a slot-boundary column, \(0xz\) abbreviates \(\{0,x,z\}\), while a lone port denotes its singleton boundary. Entries are indexed by slots \(1,\ldots,6\). In every row the common-port labels at \(0,x,y,z\) are disjoint. The indicated \(D_\delta,D_\epsilon\) are two-sets on the two edges from \(w\) to the special terminal subdivision vertices; together with \(R=[6]\setminus(X_0\cup Y_0)\), they partition \([6]\) at \(w\). They avoid \(X_\delta,Y_\epsilon\), respectively, so [Note 172, (1)--(3)](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) makes every line a row of **six genuine outer perfect matchings** with edge load two. The last column records its two outer triple slots and their missing pairs.

First double the tree's \(\delta y\) Tait state, with \(A^\circ\) boundaries \((0xz,0xz,\delta,\delta,y,y)\). Here \(X_0=\{1,2\}\) and \(X_\delta=\{3,4\}\).

| input \(B^\circ\) type | \(B^\circ\) slot boundaries | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((x\epsilon)(yz)\) | \(\epsilon,y,x,0yz,z,0x\epsilon\) | \(46;16\) | \(16;24\) | \(3:\delta x,\ 5:yz\) |
| \((z\epsilon)(xy)\) | \(\epsilon,y,x,0xy,z,0z\epsilon\) | \(46;16\) | \(16;24\) | \(3:\delta x,\ 5:yz\) |
| \((yz)(y\epsilon)\) | \(\epsilon,y,y,0xz,z,0x\epsilon\) | \(46;16\) | \(16;24\) | \(3:\delta y,\ 5:yz\) |
| \((0y)(y\epsilon)\) | \(\epsilon,y,y,0xz,0,xz\epsilon\) | \(45;16\) | \(12;45\) | \(3:\delta y,\ 5:y\epsilon\) |
| \((xy)(y\epsilon)\) | \(\epsilon,y,x,y,0z\epsilon,0xz\) | \(56;15\) | \(15;26\) | \(3:\delta x,\ 4:\delta y\) |
| \((yz)(y\epsilon)\) | \(\epsilon,y,z,y,0xz,0x\epsilon\) | \(56;16\) | \(16;25\) | \(3:\delta z,\ 4:\delta y\) |

For instance, in the fourth line \(R=\{3,6\}\), \(X_\delta\cap Y_\epsilon=\varnothing\), and \(D_\delta=\{1,2\},D_\epsilon=\{4,5\}\). Slot \(3\) uses the \(\delta\)-half and the \(y\)-half and therefore misses \(\delta y\); slot \(5\) uses the \(y\)-half and \(B^\circ\)'s \(0\)-port, forcing \(w\epsilon\), and therefore misses \(y\epsilon\). The other lines obey the same connector criterion.

Next double the tree's \(xz\) Tait state, with \(A^\circ\) boundaries \((0y\delta,0y\delta,z,z,x,x)\). Now \(X_0=X_\delta=\{1,2\}\).

| input \(B^\circ\) type | \(B^\circ\) slot boundaries | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((xz)(x0)\) | \(x,z,x,0y\epsilon,0,yz\epsilon\) | \(45;46\) | \(45;12\) | \(3:xz,\ 5:x\delta\) |
| \((xz)(z0)\) | \(x,z,0,xy\epsilon,z,0y\epsilon\) | \(36;46\) | \(36;12\) | \(3:z\delta,\ 5:xz\) |

Finally, use a *non-doubled* actual BF row of the tree: its two triple boundaries are \(0xz\) and \(0\delta y\), and its four singleton boundaries are \(\delta,x,y,z\). In slot order the \(A^\circ\) boundaries are \((0xz,0\delta y,\delta,x,y,z)\). The tree's left--centre edge occurs in the \(y,z\) singleton slots, and its centre--right edge in the \(\delta,x\) singleton slots; both therefore have load two. Here \(X_0=\{1,2\}\), \(X_\delta=\{2,3\}\).

| input \(B^\circ\) type | \(B^\circ\) slot boundaries | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((y\epsilon)(xz)\) | \(\epsilon,x,y,z,0xz,0y\epsilon\) | \(56;16\) | \(16;25\) | \(3:\delta y,\ 4:xz\) |

In the tables, \(46\) means the slot pair \(\{4,6\}\), and similarly for the other two-digit entries. Each local input row can be permuted to the displayed slot order because a BF type determines its boundary subsets up to slot permutation. No matching identity is assumed to persist between separate rows.

## Three nonadjacent placements

If \(\delta,\epsilon\) are nonadjacent in \(T\), their shorter path has one of the shared ports as midpoint. Swapping \(y,z\) within their tree end group leaves precisely the following three placements.

1. **Midpoint \(x\):** \(T=\delta-x-\epsilon-z-y-\delta\). [Note 184, (1)--(2)](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md), applied to the genuine \(xz\) tree colouring, sends \((xy)(x\epsilon)\) to \((yz)(z\epsilon)\); hence \(c(xy)=c(x\epsilon)\). The first three lines of the first table also have forbidden outputs and give
   \[
   c(x\epsilon)=c(yz),\qquad c(z\epsilon)=c(xy),\qquad c(yz)=c(y\epsilon).
   \]
   Thus \(xy,x\epsilon,yz,z\epsilon,y\epsilon\) all lie in one block. Its triangle \(y-z-\epsilon-y\) forces that block to be \(Q\) and \(\{y,z,\epsilon\}=\{1,2,5\}\). The remaining port \(x\) is \(3\) or \(4\); neither has two neighbours in this \(Q\)-triangle. This contradicts \(xy,x\epsilon\in Q\).

2. **Midpoint \(y\), with \(x\) next to \(\delta\):** \(T=\delta-y-\epsilon-z-x-\delta\). Rows four and five of the first table, row one of the second, and the mixed tree row have forbidden outputs. They force
   \[
   c(0y)=c(y\epsilon)=c(xy)=c(xz)=c(x0).
   \]
   The three states \(0y,xy,y\epsilon\) incident with \(y\), and the three states \(xy,xz,x0\) incident with \(x\), would lie in the same block. Each of \(P,Q\) has only one degree-three vertex, whereas \(x\ne y\).

3. **Midpoint \(y\), with \(x\) next to \(\epsilon\):** \(T=\delta-y-\epsilon-x-z-\delta\). Rows four and six of the first table, row two of the second, and the mixed tree row have forbidden outputs. They force
   \[
   c(0y)=c(y\epsilon)=c(yz)=c(xz)=c(z0).
   \]
   Now \(0y,y\epsilon,yz\) are three same-block states at \(y\), while \(yz,xz,z0\) are three at the distinct port \(z\), the same impossibility.

Together with [Notes 185--187](187-the-tree-rstar-adjacent-special-ports-are-impossible.md), this exhausts every tree--\(R^*\) port placement in the stated \(|U|=1\) two-five-cut profile. It does not resolve pentagon--\(R^*\), \(L^*\)--\(R^*\), \(R^*\)--\(R^*\), other Tutte-barrier profiles, or exact Case XII in general. \(\square\)
