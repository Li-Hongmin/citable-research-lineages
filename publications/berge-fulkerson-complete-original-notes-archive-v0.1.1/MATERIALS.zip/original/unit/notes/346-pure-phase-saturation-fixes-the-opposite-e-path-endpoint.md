> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pure zero-port phases fix the opposite \(e\)-path endpoint

> **Later consequence:** [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) excludes every \(U_A\) row containing an \(e\to a\) mask; [Note 354](354-the-right-eb-row-forces-a-forbidden-double-t-completion.md) and [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) then exclude the remaining right and left \((ea)(eb)\) rows in this central-path exterior. The mask and path classifications below remain conditional calculations.

Continue the actual central-path exact-Case-XII \((ea)(eb)\) row of [Notes 341–345](345-the-two-identity-bridge-has-an-exact-third-matching-gate.md):
\[
 X_{ea}+Y_a+Z_e+U_{eb}+V_e+W_b=2\mathbf1,
 \qquad S=e-a-b-d-c-e.                                      \tag{1}
\]
Write \(Q_X=X|_\Sigma,Q_U=U|_\Sigma\) for the distinct zero-port shore matchings. Their symmetric difference has \(k\ge1\) closed alternating components. For every subset \(C\) of those components, [Note 342](342-the-eb-row-creates-two-exterior-pure-load-fibres.md) gives a real row with zero-port slots \(X_C,U_C\) and the same four complete singleton matchings \(Y,Z,V,W\). The exterior masks of \(X_C,U_C\) remain those of \(X,U\).

**Phase-invariant endpoint theorem.** Fix either complete singleton-\(e\) matching \(D_e\in\{Z_e,V_e\}\). In the full two-colour graph \(U_C\triangle D_e\), let \(p_C(D_e)\in\{a,c,d\}\) be the terminal joined to \(e\). Then \(p_C(D_e)\) is **independent of \(C\)**. More precisely, let \(\beta_X(D_e)\) be the shore port reached by the exterior arm from terminal \(b\) in \(X_C\triangle D_e\), as listed in [Note 271's sixteen-mask table](271-the-central-path-row-requires-two-distinct-shore-masks.md). Every shore path from \(E=e\) in \(U_C|_\Sigma\triangle D_e|_\Sigma\) ends at this same port \(\beta_X(D_e)\). The exterior \(U\triangle D_e\) arm from that port determines \(p_C(D_e)\).

**Proof.** In each phase row, exchange \(Z,V\) if needed so that \(X_C+Y+D_e\) is one half and the opposite \(eb\)-state half uses the other singleton-\(e\) matching. Exact Case XII has no \(T\)-loop or \(T\)--\(T\) type. [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) therefore makes every three-matching decomposition of \(X_C+Y+D_e\) an \(S\)-state. Switching the complete \(e\)-starting path of \(X_C\triangle D_e\) keeps singleton \(a\); among the three possible new states \(ab,ac,ad\), only \(ab\) lies in \(S\). Thus this path ends at \(b\). Both \(X_C\) and \(D_e\) have the fixed exterior masks, and their shore difference has four open ports. The exterior \(b\)-arm ends at the fixed port \(\beta_X(D_e)\), so their shore \(E\)-path must end there.

As \(C\) ranges over all subsets, the restrictions \(X_C|_\Sigma\) and \(U_C|_\Sigma\) range over the **same** family: \(U_C|_\Sigma=X_{\bar C}|_\Sigma\), where \(\bar C\) is the complementary subset of the \(k\) cycles. Hence the preceding shore pairing applies to \(U_C|_\Sigma\triangle D_e|_\Sigma\) for every \(C\). Note 271's exterior table sends the \(b,d\) terminal arms to distinct proper shore ports; direct tracing sends \(c\) to the third, so the full \(e\)-path uses exactly one of the two shore paths. The exterior \(U\triangle D_e\) arms are unchanged by phase switches, so the terminal reached from \(\beta_X(D_e)\) is fixed. \(\square\)

The endpoint is now read entirely from the real row's exterior. The table uses Note 271's orientation names and lists only pure singleton-\(e\) masks not already excluded by the doubly occupied \(4E\in X\cap U\). A dash between masks denotes alternatives, not an assertion that every pair of alternatives completes a BF row.

| \(Y_a,U_{eb}\) exterior | \(D_e\) mask | \(\beta_X(D_e)\) | Forced \(p(D_e)\) |
|---|---|---|---|
| \(Y_L,U_A\) | any orientation I | \(I\) | \(d\) |
| \(Y_L,U_A\) | IV: \(a:\Sigma,1A,3C\) | \(A\) | \(a\) |
| \(Y_L,U_D\) | I: \(a:C,3D\) | \(I\) | \(a\) |
| \(Y_L,U_D\) | I: \(a:\Sigma,2C,3D\) | \(I\) | \(d\) |
| \(Y_L,U_D\) | I: \(a:C,4D\), or \(a:\Sigma,2C,4D\), or \(a:\Sigma,3C,4D\) | \(I\) | \(c\) |
| \(Y_R,U_A\) | III: \(a:C,1B\), or \(a:C,2B\), or \(a:\Sigma,1B,2C\) | \(H\) | \(c\) |
| \(Y_R,U_A\) | III: \(a:\Sigma,1B,3C\), or \(a:\Sigma,2B,3C\) | \(A\) | \(a\) |
| \(Y_R,U_A\) | IV: \(a:\Sigma,1A,2C\) | \(H\) | \(d\) |

For the table, the \(U\triangle D_e\) arm from \(c\) reaches \(J,H\), or \(D\) in the \(Y_L,U_A\) case, never \(I\); the IV mask has its \(a\)-arm at \(A\). In the \(Y_L,U_D\) case, a mask using \(4D\) sends the \(c\)-arm to \(I\); among masks omitting \(4D\), \(a:C,3D\) sends the \(a\)-arm to \(I\), while \(a:\Sigma,2C,3D\) leaves \(I\) for \(d\). In the \(Y_R,U_A\) case, the three III masks without \(3C\) send the \(c\)-arm to \(H\). The two III masks with \(3C\) have \(\beta_X=A\), where their \(a\)-arm lands; the IV mask sends its \(c\)-arm to \(J\) and hence \(H\) belongs to \(d\). These are direct exterior alternating routes, not shore-pairing assumptions.

**Uniform bridge-or-two-loops consequence.** In a left \(Y_L,U_D\) row, both \(Z,V\) have orientation I. The only two masks in that group without \(4D\) both use \(3D\), already used by \(X\); they cannot coexist in a load-two row. Thus at least one of \(Z,V\) has \(p=c\). In a right \(Y_R,U_A\) row, if neither has \(p=c\), one must be an orientation-III mask with \(3C\) (hence \(p=a\)) and the other the orientation-IV mask (hence \(p=d\)): two III masks with \(3C\) would overload \(3C\), which \(Y_R\) already uses, while two IV masks would overload \(c:E\), also used by \(Y_R\). In a left \(Y_L,U_A\) row, one singleton-\(e\) mask is orientation I and the other orientation IV, so their endpoints are likewise \(d,a\).

Consequently every actual row (1) has exactly one of these outcomes:

1. At least one of \(Z,V\) has \(p=c\) for **all** \(2^k\) zero-port phases. Each phase supplies the two-identity cross-carrier bridge of Note 343; the \(2^k\) associated carrier pairs are distinct by Note 342.
2. Neither has \(p=c\). Their endpoints are \(a,d\) in some order for **all** phases. By [Note 344](344-a-fixed-singleton-load-has-an-exact-two-state-fibre.md), the same complete \(W_b\) then occurs in at least \(2^k\) distinct carrier pairs witnessing \([ab]\) and in another \(2^k\) distinct carrier pairs witnessing \([bd]\).

In the first outcome, the exterior \(c\)-arm of every \(p=c\) mask is owner-safe by [Note 345's classification](345-the-two-identity-bridge-has-an-exact-third-matching-gate.md). The two owner-bad right masks in that note have \(p=a\) here, so its earlier conditional owner failure cannot arise on an actual \(e\to c\) phase. Only the shore part of the owner path, even residual closed cycles, and the possible triple-hit edge remain in the third-identity gate; [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md) makes terminal-path parity automatic. The theorem neither excludes the second outcome nor synchronizes singleton \(c\) in the first; it does not prove an \(A\)-cover or settle exact Case XII.

## Two no-bridge exterior branches after full singleton-cycle closure

The no-\(c\) alternative can be pruned further without inspecting the shore. In the left \(Y_L,U_A\) row, \(1B,2C\) are already used by \(Y_L,U_A\), and \(3D,4E\) by \(X,U_A\). Its orientation-I singleton-\(e\) mask can therefore be only \(a:C,4D\) or \(a:\Sigma,3C,4D\), paired with the obligatory IV mask \(a:\Sigma,1A,3C\).

If the I mask is \(a:C,4D\), its symmetric difference with the IV mask has two exterior paths, with shore endpoints \(A,H\) and \(I,J\), respectively. They **must belong to the same complete alternating cycle**. Otherwise switching just the \(A\)--\(H\) component between the two complete singleton-\(e\) matchings leaves a real \((ea)(eb)\) BF row whose newly produced IV mask is \(a:C,1A\). Note 271 marks that mask as pure on neither side; the unchanged \(Y_L\) and opposite \(eb\)-half require it to be pure \(S\), a contradiction. Thus the shore part of \(Z\triangle V\) must join the two exterior paths crosswise, pairing \(A\) to \(I\) and \(H\) to \(J\), or \(A\) to \(J\) and \(H\) to \(I\). The other left I mask \(a:\Sigma,3C,4D\) differs from IV on only one exterior path \(I\)--\(J\), so this two-path test gives no restriction there.

In the right \(Y_R,U_A\) no-\(c\) row, pair the obligatory IV mask \(a:\Sigma,1A,2C\) with one of the two III masks using \(3C\). The III mask \(a:\Sigma,1B,3C\) is impossible: these two singleton-\(e\) matchings differ on the **wholly exterior alternating six-cycle**
\[
 t_c-A_{\rm ext}-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c,
\]
whose alternating edges are \(c:A,1A,1B,d:B,d:E,c:E\). Switching this complete cycle between the two actual matchings preserves every edge load, boundary class, and the opposite \(eb\)-half. It changes the III mask to IV \(a:\Sigma,1A,3C\), which Note 271 allows only on the left, not with the unchanged right \(Y_R\). The resulting pure-half contradiction excludes the pair. Therefore a right no-\(c\) row, if real, has the unique possible singleton-\(e\) mask pair
\[
             \{\mathrm{III}:a:\Sigma,2B,3C,
               \quad \mathrm{IV}:a:\Sigma,1A,2C\}.       \tag{2}
\]
The pair has one exterior \(I\)--\(H\) difference path and no separate exterior cycle; it is the signature displayed conditionally in [Note 340, (5)](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md). That earlier note excluded it only under the extra assumption \(Q_X=Q_U\), which Note 341 now rules out for every actual row. The remaining mask pair is **not** an exact-Case-XII realization or a counterexample.

[Note 347](347-a-right-eb-row-forces-a-c-bridge-after-one-exterior-switch.md) adds a different full-closure consequence: this pair has a wholly exterior \(Z_e\triangle W_b\) six-cycle, and switching it gives an actual right row with an \(e\to c\) endpoint. Thus the pair may remain as an individual row but cannot witness a global absence of the two-identity bridge.
