> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four mixed fibres reduce the one-port Hall tree to two orientations

> **Scope correction:** [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> leaves a right \((ea)(ad)\) row open under exact support. The
> four \(qp\)-fibre exclusions below use the stated side placement
> and complete negative support. The subsequent Hall-tree
> consequences depend on the additional left \(ad\) template.

Continue the complete exact-Case-XII central-path setting of [Notes 290–294](294-a-singleton-b-mask-excludes-the-last-non-i-one-port-hall-tree.md), conditional on the forced exterior rows of Notes 271–272. The unmarked shore core is bipartite after deleting \(g\subset B\); the internal mark has ends \(v\in B,w\in R\). Among the proper shore ports, \(q\in\{A,D\}\) and \(r\in\{H,J\}\) are based in \(R\), while \(I\) and \(p=\{H,J\}\setminus\{r\}\) are based in \(B\). The allowed Tait-state pentagon is \(S=e-a-b-d-c-e\), so \(eb\) is forbidden.

**Theorem.** All four shore fibres
\[
\boxed{S(N)=\{q,p\},\qquad g,t_ew\in N,\qquad
        (q,r)\in\{A,D\}\times\{H,J\}}                 \tag{1}
\]
are empty. Consequently, the local-incidence collision \(\hat q=\hat r\) of Note 290 is impossible. If Note 290's minimal four-edge Hall tree has \(\alpha=\eta=1,\ s\ne s_B,\ p_{s}=I\), then \(q=D\). In its remaining orientations \((q,r)=(D,H),(D,J)\), complete PM closure forces an actual **zero-port** shore matching \(N\) selecting \(g,t_ew\), whose shore complement pairs
\[
\boxed{D I\mid E A\mid H J.}                          \tag{2}
\]
The theorem does not claim either remaining orientation is realizable.

## Four genuine singleton-\(b\) exterior masks

The following table displays one exterior matching for each port pair \(qp\). Every row selects terminal \(b\), uses precisely the two stated shore ports, and uses the displayed edges at the other three marked subdivision vertices and at the remaining path vertices. The final column is an exterior-complement path from terminal \(a\) or \(d\) through the unselected same-side port \(r\).

| \(q,r;p\) | Selected exterior edges besides \(b_{\rm term}\) | Complement terminal arm through \(r\) |
|---|---|---|
| \(A,H;J\) | \(a:\Sigma,c:E,d:B,1A,2C,3D,h_4\) | \(a-t_a-C_{\rm ext}-u_3-H\) |
| \(A,J;H\) | \(a:\Sigma,c:E,d:B,1A,2C,4D,h_3\) | \(d-t_d-E_{\rm ext}-u_4-J\) |
| \(D,H;J\) | \(a:C,c:A,d:E,1B,3D,h_2,h_4\) | \(d-t_d-B_{\rm ext}-u_2-C_{\rm ext}-u_3-H\) |
| \(D,J;H\) | \(a:C,c:E,d:B,1A,4D,h_2,h_3\) | \(d-t_d-E_{\rm ext}-u_4-J\) |

The five branch vertices \(A_{\rm ext},\ldots,E_{\rm ext}\) are covered, in table order, by
\[
(1A,dB,2C,3D,cE),\quad
(1A,dB,2C,4D,cE),\quad
(cA,1B,aC,3D,dE),\quad
(1A,dB,aC,4D,cE).                                    \tag{3}
\]
The displayed shore ports cover the other two path or subdivision vertices in each row; the remaining path vertices are covered by the numbered edges. Thus each row is an actual exterior perfect matching.

Suppose an \(N\) in (1) existed and glue it to the corresponding row. The resulting complete matching selects \(g,t_ew,q\), leaving \(r\) as its **sole unselected same-side proper edge**. The displayed terminal arm puts \(r\) on an open path, so every closed complement cycle is even. Hence the matching extends to a Tait colouring with singleton terminal \(b\). The terminal path through \(r\) has same-coloured ends, while the other terminal path has differently coloured ends: every terminal vertex is on side \(R\), and only the former path contains the one same-side edge. Switching the latter path realizes both its endpoints in turn as the second singleton terminal. If the former arm starts at \(a\), the latter has endpoints among \(c,d,e\), where only \(d\) is adjacent to \(b\) in \(S\). If it starts at \(d\), the latter has endpoints among \(a,c,e\), where only \(a\) is adjacent to \(b\). Either way at least one Tait state is forbidden. This proves (1), extending [Note 294's \(DH\) case](294-a-singleton-b-mask-excludes-the-last-non-i-one-port-hall-tree.md).

There is a direct consequence for Note 290's local-incidence alternative. [Note 291, (7)](291-cross-slot-singleton-switches-prune-two-vertex-hall-barriers.md) leaves only \((q,r)=(D,J)\) if \(\hat q=\hat r\). In the required double-\(HJ\) \(ac\) row, choose a singleton-\(a\) shore matching \(Y\) with ports \(HJ\) and \(g,t_ew\), and the opposite singleton \(W_c\) with ports \(ID\). At their common base, \(Y\) selects \(J\) and \(W_c\) selects \(D\), so \(J-\hat q-D\) is an entire component of \(Y\triangle W_c\). Switching this component in \(Y\) gives an actual \(DH\)-port shore matching that still selects \(g,t_ew\), contrary to the fourth row of (1). Hence \(\hat q=\hat r\) is impossible in all placements.

## The \(I\)-port Hall tree forces a zero-port cycle switch

Let the one-port Hall vertex \(s\ne s_B\) carry \(I\), and let its other edges go to the vertices \(\hat q,\hat r\) carrying \(q,r\). Use the required row with **both** singleton-\(a\) occurrences \(Y,V\) selecting \(g,t_ew\): it is \(ad\) for \(q=A\) and \(ac\) for \(q=D\). Let \(W\) be its opposite singleton. [Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) gives
\[
S(Y)=HJ,\quad g,t_ew\in Y,\qquad
S(W)=qI,\quad g\notin W,\ t_ev\in W.                \tag{4}
\]
At \(s\), \(Y\) selects \(s\hat q\), whereas \(W\) selects the \(I\) port. Thus \(q-\hat q-s-I\) is an entire component of \(Y\triangle W\). The other open component joins \(H,J\). The only same-side edges in this symmetric difference are \(g,t_ew\). Every alternating cycle has an even number of them. The \(H\)--\(J\) path also has an even number: its ends lie on opposite sides, and both ports belong to \(Y\), so its internal length is odd. Hence \(g,t_ew\) lie together on that path or on one cycle. A cycle switch would give a \(qI\)-port matching selecting \(g,t_ew\), forbidden by Note 290. Switching the \(H\)--\(J\) path instead gives an actual four-proper-port matching
\[
F:\qquad S(F)=\{q,I,H,J\},\qquad g,t_ew\in F.        \tag{5}
\]

In the same row, the required zero-port slot \(X\) avoids \(g\) and selects \(t_ev\). At \(s\), the edge \(s\hat q\) is used twice by \(Y,V\), the \(I\)-port edge is used twice by \(Z,W\), so the remaining edge \(s\hat r\) is used by \(X\). The switch producing \(F\) did not meet \(s\), hence \(F\) still uses the \(I\) port and selects \(r\). Therefore \(I-s-\hat r-r\) is an entire component of \(F\triangle X\). The other open component pairs \(q\) with \(p\), both selected by \(F\). Its internal length is odd and its ends lie on opposite sides; thus \(g,t_ew\) lie together on this path or one closed alternating cycle.

If they lie on the \(q\)--\(p\) path, switching it gives an actual \(qp\)-port shore matching selecting \(g,t_ew\), contrary to (1). Hence they lie on one cycle. Switching that cycle into \(X\) produces an actual zero-port matching \(N\) selecting \(g,t_ew\). It retains \(s\hat r\), and its complement has the immediate shore path
\[
q-\hat q-s-I.                                        \tag{6}
\]

For \((q,r)=(A,H)\), [Note 283, (2)](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) already forbids every zero-port matching selecting \(g,t_ew\). For \((q,r)=(A,J)\), such an \(N\) is also impossible with the specific pairing (6). Glue \(N\) to the first state-\(eb\) zero-port exterior mask of Note 283, whose complement pairs \(ID\mid AH\) and sends terminal \(b\) to \(J\). In view of the shore \(A\)--\(I\) path, its two exterior pairings join into an \(H\)--\(D\) component containing the exceptional edge \(A\), while \(J\) lies on the \(b\)-terminal path. Unless the shore complement pairs \(H\) with \(D\), every closed cycle is even and a forbidden \(eb\)-Tait colouring results. Thus the only possible remaining shore pairing is \(HD\mid EJ\).

Now glue the **same** \(N\) to Note 283's second state-\(eb\) exterior mask, whose complement pairs \(AD\mid HJ\) and sends \(b\) to \(I\). The shore pairings \(AI\mid HD\mid EJ\) join the \(e\)--\(b\) terminal path through **both** exceptional edges \(A,J\). Every closed complement cycle is even, again giving the forbidden \(eb\)-Tait state. This excludes \((A,J)\), so \(q=D\).

Finally, if \(q=D\), the second state-\(eb\) exterior mask and (6) force the other two shore complement paths to be \(EA\mid HJ\). Otherwise its two exceptional edges \(D,r\) lie on one terminal path, all closed cycles are even, and the forbidden \(eb\)-Tait state follows. This proves (2) and the theorem. \(\square\)

## The surviving signature supplies only allowed tests at \(ea,ec\)

There is no immediate forbidden-Tait conclusion from the two zero-port triples already used in the required central rows. With (2), glue \(N\) to the state-\(ea\) exterior zero-port triple
\[
X_a=\{b_{\rm term},c_{\rm term},d_{\rm term},a:C_{\rm ext},
                 1A_{\rm ext},2B_{\rm ext},3D_{\rm ext},4E_{\rm ext}\}.
\]
Its exterior complement pairs \(D H\mid I J\), and joins terminal \(a\) to port \(A\). The shore path \(EA\) becomes the \(e\)--\(a\) terminal path; \(DI\mid HJ\) joins the two exterior paths into one closed cycle containing both exceptional cut edges \(D,r\). All complement cycles are even, so this actual triple extends to an **allowed** \(ea\)-Tait colouring.

Likewise the state-\(ec\) zero-port triple
\[
X_c=\{a_{\rm term},b_{\rm term},d_{\rm term},c:A_{\rm ext},
                 1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},4E_{\rm ext}\}
\]
has exterior-complement routes \(c\)--\(D\), \(A\)--\(H\), and \(I\)--\(J\). The shore pairing (2) joins them into the \(e\)--\(c\) terminal path containing **both** exceptional cut edges. Again every closed component is even, yielding the allowed \(ec\)-Tait state. Thus the surviving signature passes these two direct complete-matching tests; the remaining exact-support cells must supply any further exclusion.

In fact these outcomes exhaust the **zero-port exterior triples with missing pair \(ej\)**. Such a triple selects the other three exterior terminal semiedges; all four \(u_i\) must be matched to distinct branch vertices, while the missing mark \(j\) matches the fifth branch vertex. Its possible marked halves and the complement outcome after gluing the *same* \(N\) with (2) are:

| Missing pair | Missing mark half | Exterior-complement routes | Result |
|---|---|---|---|
| \(ea\) | \(a:C\) | \(a-A,\ DH\mid IJ\) | even cycles; allowed \(ea\)-Tait |
| \(eb\) | \(b:A\) | \(b-J,\ ID\mid AH\) | odd cycle through \(D\) |
| \(eb\) | \(b:D\) | \(b-I,\ AD\mid HJ\) | odd cycle through \(r\) |
| \(ec\) | \(c:A\) | \(c-D,\ AH\mid IJ\) | even cycles; allowed \(ec\)-Tait |
| \(ec\) | \(c:E\) | \(c-H,\ AD\mid IJ\) | even cycles; allowed \(ec\)-Tait |
| \(ed\) | \(d:B\) | \(d-J,\ ID\mid AH\) | odd cycle through \(D\) |
| \(ed\) | \(d:E\) | \(d-I,\ AD\mid HJ\) | odd cycle through \(r\) |

For \(eb,ed\), an odd closed cycle blocks Tait extension; for \(ea,ec\), the only same-side cut edges \(D,r\) share one component. Thus every zero-port \(ej\) completion of this \(N\) has the stated allowed-or-blocked outcome. This is an exact boundary of the zero-port Tait test, not a realization of the full exact-Case-XII BF relation.

The two remaining \(p_s=I,q=D\) orientations, the incidence collision \(v\in\{x,y\}\), larger Hall barriers, the \(4+1\) and high-rank cores, other rectangle contexts, and Berge–Fulkerson remain unresolved. The proof uses no graph enumeration, local recomputation, OMEN run, or release.
