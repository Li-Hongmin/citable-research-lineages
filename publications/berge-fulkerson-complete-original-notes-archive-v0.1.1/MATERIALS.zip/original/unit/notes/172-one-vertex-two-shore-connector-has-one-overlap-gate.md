> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The one-vertex two-shore connector has one overlap gate

Take [Note 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) smallest deficiency-two barrier with \(U=\{u\}\) and the [two five-cut profile of Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md). Write its odd components as non-singleton shores \(A,B\) and the singleton \(\{w\}\). This note factors **every actual six-matching BF row** of the outer pole through complete BF rows on the two shore five-poles. It is a conditional exact composition theorem, not a construction of an exact-Case-XII pole.

The three unmarked edges at \(u\) go one each to \(A,B,w\). If \(x\) marked edges join \(A\) to \(B\), \(y\) join \(A\) to \(w\), and \(z\) join \(B\) to \(w\), their cut sizes give
\[
x+y=4,\qquad x+z=4,\qquad y+z=2.
\]
Hence \((x,y,z)=(3,1,1)\). Name the three \(A\)--\(B\) marks \(\alpha,\beta,\gamma\), the \(A\)--\(w\) mark \(\delta\), and the \(B\)--\(w\) mark \(\epsilon\). These are the five original terminal labels, merely renamed here for the connector; any test against \(S,T\) retains their original terminal permutation.

Let \(A^\circ,B^\circ\) be the shore five-poles obtained by cutting their five incident edges. Consider **actual** labelled six-matching BF rows on them, using the same slot set \([6]\). Each port has a two-element slot label. On \(A^\circ\), write these as
\[
X_0,X_\alpha,X_\beta,X_\gamma,X_\delta\subset[6],
\]
where \(X_0\) is the port toward \(u\); on \(B^\circ\), write
\[
Y_0,Y_\alpha,Y_\beta,Y_\gamma,Y_\epsilon\subset[6].
\]
Internal shore edges already have load two. Put \(R=[6]\setminus(X_0\cup Y_0)\).

## Exact six-slot composition criterion

The two shore rows extend to a six-matching BF row of the outer five-pole **if and only if**
\[
\boxed{\begin{aligned}
X_0\cap Y_0&=\varnothing,\\
X_i\cap Y_i&=\varnothing\qquad(i=\alpha,\beta,\gamma),\\
X_\delta\cap Y_\epsilon&\subseteq R.
\end{aligned}}                                                   \tag{1}
\]
When (1) holds, \(R\) is the two-slot label on \(uw\). Choose a two-set \(D_\delta\) with
\[
Y_\epsilon\cap(X_0\cup Y_0)
\subseteq D_\delta
\subseteq (X_0\cup Y_0)\setminus X_\delta,
\qquad
D_\epsilon=(X_0\cup Y_0)\setminus D_\delta.              \tag{2}
\]
Then \(D_\delta,D_\epsilon\) are the labels on \(wt_\delta,wt_\epsilon\). The five terminal semiedge labels of the completed outer row are forced:
\[
\begin{aligned}
T_i&=[6]\setminus(X_i\cup Y_i)&& (i=\alpha,\beta,\gamma),\\
T_\delta&=[6]\setminus(X_\delta\cup D_\delta),\\
T_\epsilon&=[6]\setminus(Y_\epsilon\cup D_\epsilon).
\end{aligned}                                                   \tag{3}
\]
Each displayed terminal label has two slots. Conversely, every completed BF row has exactly this form for its two restricted shore rows and its actual choice of \(D_\delta\).

**Proof.** In a global BF row, the three two-slot labels at \(u\) partition \([6]\). Thus \(X_0\cap Y_0=\varnothing\), the label on \(uw\) is \(R\), and \(X_0\cup Y_0\) has four slots. At \(w\), the labels on \(wt_\delta,wt_\epsilon\) partition that four-set. At each subdivision vertex \(t_i\) for \(i=\alpha,\beta,\gamma\), its two shore halves are disjoint; the remaining pair is the terminal label \(T_i\). At \(t_\delta,t_\epsilon\), the shore half and the \(w\)-half are disjoint. A slot in \(X_\delta\cap Y_\epsilon\) can use neither \(w\)-half, so it must lie on \(uw\), proving the last condition of (1).

For sufficiency, let \(W=X_0\cup Y_0\), so \(|W|=4\). We need a two-set \(D_\delta\subseteq W\) that contains \(Y_\epsilon\cap W\) and avoids \(X_\delta\cap W\). The last condition of (1) makes these required and forbidden sets disjoint. Each has size at most two; therefore fill the required set from \(W\setminus X_\delta\) to size two. This gives (2), with \(D_\epsilon=W\setminus D_\delta\). Now all three incident edge labels at each of \(u,w,t_\alpha,\ldots,t_\epsilon\) partition \([6]\), and (3) labels the five terminal semiedges. In each slot, each shore row supplies a genuine matching of all its vertices, and the chosen connector edges match every remaining connector vertex exactly once. Thus each slot is a genuine perfect matching of the outer pole, and every proper edge and semiedge has load two. \(\square\)

Condition (1) is the complete graph-induced closure gate for this connector. The three \(A\)--\(B\) positions obey ordinary disjointness as in [Note 163](163-five-cut-perfect-matching-closure-composes-shore-bf-relations.md); the two marks through \(w\) add exactly the overlap condition \(X_\delta\cap Y_\epsilon\subseteq R\). A shore BF type fixes its five port two-slot labels up to permutation of the six occurrence slots. Since every supported type has an actual shore row and either shore row can be relabelled freely, the **complete shore type relations, their relative port placements, and (1)--(3) determine the complete outer BF support** in this \(|U|=1\) profile. No further internal shore matching-mask alignment is required for this composition. The remaining Case-XII question is whether those complete relations force a forbidden outer type or fail a required positive type.

An all-terminal shore BF type cannot participate. If one slot uses all five \(A\)-ports, the first two lines of (1) make it avoid \(Y_0,Y_\alpha,Y_\beta,Y_\gamma\); the last line makes it avoid \(Y_\epsilon\) as well, since it lies in \(X_0\cap X_\delta\) and hence outside \(R\). It would have empty boundary on the odd shore \(B\), impossible for a perfect matching. Thus only the pair and loop portions of the **actual** shore relations enter this connector.

## A common shore loop forces two outer loops

Let \(b\in\{\alpha,\beta,\gamma\}\). If both actual shore relations contain the loop \([0b]\), then
\[
\boxed{[b\delta],\ [b\epsilon]\in\operatorname{BFsupp}(H).} \tag{4}
\]
To obtain \([b\epsilon]\), put the two \(A^\circ\) triple occurrences in slots \(1,2\) and the two \(B^\circ\) triple occurrences in slots \(3,4\). Give \(A^\circ\) singleton boundaries \(0,0,b,b\) in slots \(3,4,5,6\), and give \(B^\circ\) singleton boundaries \(b,b,0,0\) in slots \(1,2,5,6\). The shore triples use every port except \(0,b\). Hence the four common-port labels are disjoint across shores, \(X_\delta=\{1,2\}\), \(Y_\epsilon=\{3,4\}\), and \(R=\{1,2\}\). In (2) take \(D_\delta=\{3,4\}\), \(D_\epsilon=\{5,6\}\). Formula (3) gives terminal labels \(T_b=\{3,4\}\), \(T_\epsilon=\{1,2\}\), and \(T_c=T_d=T_\delta=\{5,6\}\), where \(\{c,d\}=\{\alpha,\beta,\gamma\}\setminus\{b\}\). Slots \(5,6\) are then both triple matchings missing \(b\epsilon\). For \([b\delta]\), instead give the \(A^\circ\) singleton boundaries \(b,b,0,0\) in slots \(3,4,5,6\), and the \(B^\circ\) singleton boundaries \(0,0,b,b\) in slots \(1,2,5,6\); (2) forces \(D_\delta=\{5,6\}\), \(D_\epsilon=\{1,2\}\), and the outer triple slots both miss \(b\delta\). All six local slots are actual matchings, so both are genuine outer BF loops.

More generally, exact Case XII forbids a common shore loop \([0b]\) whenever \(b\delta\) or \(b\epsilon\) is an edge of the forbidden \(T\)-pentagon. If \(\delta,\epsilon\) have distance two in \(T\), this excludes a common \([0b]\) for **every** shared mark \(b\). If they are adjacent, the only possible shared mark in such a common loop is the middle vertex of the three-edge \(T\)-path between them.

The Case-XIII \(L^*\) relation has **all ten** local loops, so two \(L^*\) shores share \([0b]\) for each \(b\in\{\alpha,\beta,\gamma\}\). At least one such \(b\) is adjacent to \(\delta\) or \(\epsilon\) in \(T\); (4) then gives a forbidden \(T\)-loop. Thus
\[
\boxed{|U|=1\text{ and two five-cut shores}\quad\Longrightarrow\quad
\text{the shore pair is not }L^*\text{--}L^*.}                 \tag{5}
\]
If one shore is \(L^*\) and the other an ordinary pentagon, the pentagon has at least one loop \([0b]\) with \(b\) a shared mark: its port \(0\) has two pentagon neighbours, at most one of which is its unique \(\delta\)- or \(\epsilon\)-port. If \(\delta,\epsilon\) have distance two in \(T\), **every** shared mark is adjacent to one of them, so this shore pair is also impossible. If they are adjacent in \(T\), the pentagon's only possible shared neighbour of \(0\) is the middle vertex of the three-edge \(T\)-path between \(\delta,\epsilon\); its other neighbour must be its unique port. This is a necessary port placement, not an existence claim.

## A common disjoint shore type forces an outer pair

Write the four shared shore ports as \(\{0,b,c,d\}\), where \(0\) is the edge toward \(u\) and \(\{b,c,d\}=\{\alpha,\beta,\gamma\}\). If **both** actual shore relations contain the type \((0b)(cd)\), then the outer relation contains all four types
\[
\boxed{(c\delta)(c\epsilon),\quad(d\delta)(d\epsilon),\quad
(c\delta)(d\epsilon),\quad(c\epsilon)(d\delta).} \tag{6}
\]
For the first type, relabel the two actual shore rows to have these six boundary sets, in slot order:

| slot | \(A^\circ\) boundary | \(B^\circ\) boundary |
|---|---|---|
| 1 | \(\{c,d,\delta\}\) | \(\{b\}\) |
| 2 | \(\{0,b,\delta\}\) | \(\{d\}\) |
| 3 | \(\{b\}\) | \(\{c,d,\epsilon\}\) |
| 4 | \(\{d\}\) | \(\{0,b,\epsilon\}\) |
| 5 | \(\{0\}\) | \(\{c\}\) |
| 6 | \(\{c\}\) | \(\{0\}\) |

The four common-port pairs are disjoint. They give \(R=\{1,3\}\), \(X_\delta=\{1,2\}\), and \(Y_\epsilon=\{3,4\}\), so the overlap gate (1) holds. Choose \(D_\delta=\{4,5\}\) and \(D_\epsilon=\{2,6\}\). Formula (3) yields
\[
T_b=T_d=\{5,6\},\quad T_c=\{2,4\},\quad
T_\delta=\{3,6\},\quad T_\epsilon=\{1,5\}.
\]
Slots 5 and 6 are the outer triple matchings, missing \(c\delta\) and \(c\epsilon\), respectively. Interchanging \(c,d\) proves the second type in (6). To obtain the two cross types, keep the \(A^\circ\) column and the two \(B^\circ\) triple slots fixed, but change the \(B^\circ\) singleton boundaries in slots \(1,2,5,6\) to \(b,c,d,0\). The four common-port pairs remain disjoint, and \(R,X_\delta,Y_\epsilon\) remain \(\{1,3\},\{1,2\},\{3,4\}\). With \(D_\delta=\{4,5\}\), (3) gives
\[
T_b=\{5,6\},\quad T_c=\{4,5\},\quad T_d=\{2,6\},\quad
T_\delta=\{3,6\},\quad T_\epsilon=\{1,5\},
\]
and hence \((d\delta)(c\epsilon)\). With \(D_\delta=\{4,6\}\), the same formula gives \((d\epsilon)(c\delta)\). This proves all of (6) using actual relabelled shore rows.

In exact Case XII, the four types in (6) give a sharp negative-support restriction. If \(\delta,\epsilon\) have **distance two** in the forbidden \(T\)-pentagon, write its two routes between them as \(\delta-c-\epsilon\) and \(\delta-a-b-\epsilon\), with \(\{a,b,c\}=\{\alpha,\beta,\gamma\}\). A common disjoint shore type whose pair opposite \(0\) contains \(c\) gives the forbidden \(T\)--\(T\) wedge \((c\delta)(c\epsilon)\). The third common disjoint type has opposite pair \(\{a,b\}\) and gives the forbidden cross type \((a\delta)(b\epsilon)\). Thus the two complete shore relations share **none of the three disjoint pair types** on \(\{0,\alpha,\beta,\gamma\}\).

If \(\delta,\epsilon\) are **adjacent** in \(T\), write the remaining path of that pentagon as \(\delta-a-c-b-\epsilon\). The common type \((0c)(ab)\) gives the forbidden cross type \((a\delta)(b\epsilon)\), so at least this one type is absent from the intersection. These exclusions use actual shore BF rows and explicit six-slot gluing; they do not assert that the other common types necessarily occur.

For an ordinary pentagon shore, its five Tait states are the five adjacent port pairs. Removing its unique port \(\delta\) (or \(\epsilon\)) leaves a four-port path, whose two end edges are its **unique** supported disjoint pair type on \(\{0,\alpha,\beta,\gamma\}\). Therefore, if both shores are pentagons and \(\delta,\epsilon\) have distance two in \(T\), their unique common-four-port disjoint types **must differ**. If \(\delta,\epsilon\) are adjacent in \(T\), they cannot both equal \((0c)(ab)\) in the notation above. If one shore is a three-vertex tree, [Note 170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md) puts its centre port at \(0\), and none of its Tait states contains \(0\); the common-disjoint-type test does not apply to that tree shore.

For the minimum-host setting, an acyclic shore is a three-vertex tree by cubic degree counting. A cyclic shore is an ordinary pentagon or has Case-XIII \(L^*,R^*\) support by [Proposition 4.4](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), as in Note 170. [Note 169's order identity](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) gives \(1+r(A)+r(B)\ge3\), so the tree--tree and tree--pentagon pairs are already excluded by the existing order-fifteen bound. Equation (5) also excludes \(L^*\)--\(L^*\) in this connected-core profile. The remaining shore-type pairs have explicit published or elementary BF relations. Their relative port labellings and the gate (1), including (4) and (6), give a finite boundary-relation problem for this \(|U|=1\) branch. No local computation or selected-row approximation is used in the reduction above.

[Note 183](183-a-shared-pair-tait-shore-and-a-loop-universal-shore-force-seven-loops.md) subsequently uses the same gate to exclude every tree--\(L^*\) and pentagon--\(L^*\) placement. Its seven outer BF loops come from actual \(L^*\) rows; they do not require a Tait colouring of the \(L^*\) shore.

[Note 184](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) gives three explicit pair-type transports from a fixed shared-pair Tait row. Against an \(R^*\) shore these become equal-block conditions on its full \(P/Q\) relation; the tree--\(R^*\) branch is narrowed but remains open.

[Notes 185--187](187-the-tree-rstar-adjacent-special-ports-are-impossible.md) use additional actual pair rows to exclude every tree--\(R^*\) placement with \(\delta\epsilon\in T\). The nonadjacent-\(\delta\epsilon\) placements still require the full connector relation.

[Notes 188--193](193-two-rstar-shores-force-a-forbidden-loop-in-the-one-vertex-connector.md) subsequently use this exact relation to exclude every remaining shore-type pair in the minimum-host \(|U|=1\) two-five-cut profile. In particular, Note 193 closes the final \(R^*\)--\(R^*\) case by an actual pair-to-loop star rectangle.
