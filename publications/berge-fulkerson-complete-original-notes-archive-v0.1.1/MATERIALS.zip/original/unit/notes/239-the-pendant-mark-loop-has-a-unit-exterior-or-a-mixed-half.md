> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The pendant-mark loop has a unit exterior or a mixed half

Use the \(|U|=3,r=2\) marked cycle--leaf quotient of [Notes 236](236-girth-five-leaves-four-marked-exterior-quotients-at-the-first-barrier.md) and [237](237-the-cycle-leaf-connector-excludes-the-two-cycle-shore-e-neighbours.md). Write \(x=w_{12}\), \(q=w_{23}\), \(z=w_{31}\). The unmarked exterior edges are
\[
u_1p,u_1x,u_1z,u_2x,u_2q,u_3q,u_3z,
\qquad h_2=u_2C,\quad h_3=u_3C,
\]
and the exterior marks are \(a:p-C\), \(b:p-q\), \(c:x-C\), \(d:z-C\); \(e\) lies in the odd shore \(C\). Suppose the allowed missing-pair pentagon \(S\) has \(ea,ec\in S\). The reflection \(x\leftrightarrow z\), \(u_2\leftrightarrow u_3\), \(c\leftrightarrow d\) gives the corresponding statements for \(ea,ed\in S\).

**Half-load dichotomy.** Let \(D\) be any actual three-perfect-matching load with one copy of each terminal and \(\varnothing\ne\mathcal R(D)\subseteq S\). By [Note 055](055-half-load-column-saturation-and-case-xii-compression.md), \(\mathcal R(D)=S\). In its \(ea\)-decomposition
\[
D=X+Y_a+Z_e,
\qquad \partial X=\{b,c,d\},\quad
\partial Y_a=\{a\},\quad \partial Z_e=\{e\},                  \tag{1}
\]
the exterior of the triple \(X\) is **forced** to be
\[
a:p,\quad u_1x,\quad u_2q,\quad u_3z.                   \tag{2}
\]
The singleton \(Y_a\) has exactly one of the following two exterior restrictions:
\[
\begin{array}{c|l|l}
 &\text{exterior edges of }Y_a&\text{proper shore ports of }Y_a\\\hline
F&p u_1,\ c:x,\ b:q,\ d:z,\ h_2,\ h_3&h_2,h_3\\
G&p u_1,\ c:x,\ b:q,\ u_3z,\ h_2,\ d:C&h_2,d:C.
\end{array}                                                       \tag{3}
\]
The row \(G\) doubles the exterior edge \(u_3z\) inside \(D\); the row \(F\) does not. Switching the wholly exterior \(a\)--\(c\) path in \(X\triangle Y_a\) produces the \(ec\)-decomposition of the *same complete load*, retaining both shore masks.

**Proof.** [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes the state-\(ea\) triple zero-port. It selects \(a:p\), while \(K-p\) is a six-cycle with exactly two perfect matchings:
\[
\alpha=\{u_1x,u_2q,u_3z\},\qquad
\beta=\{u_1z,u_2x,u_3q\}.                                 \tag{4}
\]
The component of \(X\triangle Y_a\) starting at terminal \(a\) must end at \(c\), since \(ec\) is the only other allowed pair incident with \(e\). At \(p\), \(Y_a\) cannot use \(b:p\), which would end this component at \(b\); it uses \(pu_1\). If \(X\) used \(\beta\), the required path would continue through \(u_1z,u_3z,u_3q,u_2q,u_2x,c:x\), alternating between \(X\) and \(Y_a\). It would occupy both \(p\) and \(q\) in \(Y_a\), leaving no endpoint for the nonterminal mark \(b\). Thus \(X\) uses \(\alpha\). The path then reaches \(x\) through \(u_1x\). Choosing \(xu_2\) instead of \(c:x\) would continue through \(u_2q,u_3q,u_3z\); it could end at \(b\) or \(d\), or return to the already occupied \(u_1\), but could not end at \(c\). Hence the path is \(a-p-u_1-x-c\).

Now \(Y_a\) occupies \(p\) through \(u_1\) and \(x\) through \(c\). Its nonterminal mark \(b\) must select \(q\), forcing \(h_2\). If \(d\) selects \(z\), then \(h_3\) is forced; this is \(F\). If \(d\) selects its shore endpoint, then \(u_3z\) is forced; this is \(G\). There are no further exterior choices. The path switch changes only the displayed exterior path, so the restrictions of the switched triple and singleton to \(C\cup\{t_e\}\) remain identical to those in (1). \(\square\)

**Six-matching loop rigidity.** Suppose an actual \([ea]\) BF loop row has two complementary half-loads \(D_1,D_2\) and **both** satisfy \(\mathcal R(D_i)\subseteq S\). Then each half-load has load exactly one on *every proper exterior edge*: all seven edges of \(K\), both \(h_2,h_3\), and both halves of each of \(a,b,c,d\).

Indeed, the two triples \(X_1,X_2\) both use \(u_3z\) by (2). The complete row loads this edge twice, so neither \(Y_{a,i}\) may have type \(G\); both have type \(F\). These two singletons already load \(h_2,h_3\) twice. Each \(Z_{e,i}\) must use three of the five proper shore ports by Note 230, hence it uses precisely \(a:C,c:C,d:C\), avoiding \(h_2,h_3\). As the two \(Y_{a,i}\) load \(b:q\) twice, both \(Z_{e,i}\) use \(b:p\). Their remaining exterior vertices are matched by \(K-p\), and they cannot use any \(\alpha\)-edge already loaded twice by \(X_1,X_2\). Both therefore use \(\beta\). In each half-load, (2), row \(F\) of (3), and this \(Z_e\) restriction partition every proper exterior edge exactly once. No identity between the two shore matchings is assumed.

In particular, this branch synchronizes the **individual exterior matching masks** across the two halves: \(X_1|_{\mathrm{ext}}=X_2|_{\mathrm{ext}}\), \(Y_{a,1}|_{\mathrm{ext}}=Y_{a,2}|_{\mathrm{ext}}\), and \(Z_{e,1}|_{\mathrm{ext}}=Z_{e,2}|_{\mathrm{ext}}\). All remaining freedom is in the six-port shore matching restrictions, where equality of the two triple masks has not been proved.

In complete exact Case XII, a genuine \([ea]\) loop exists by the [published type table, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), and its two halves cannot **both** admit a \(T\)-decomposition, since those decompositions would give a forbidden \(T\)--\(T\) row. Thus every such loop has exactly one mixed half and one pure-\(S\) half, or has two pure-\(S\) halves with unit exterior load as above. The theorem does not exclude the asymmetric mixed case, nor does a unit exterior load determine the shore matching relation. It therefore leaves the \(\{a,c\}\) and \(\{a,d\}\) neighbour placements open for complete exact Case XII.

## A genuine loop showing why the mixed alternative is needed

The assertion that *every* real \([ea]\) loop has unit exterior load is false, even for a simple cubic five-pole of girth five. Let \(C\) be the path \(v_1v_2v_3v_4v_5\), take \(h_2=u_2v_5\), \(h_3=u_3v_3\), and realize the five marks as subdivided edges
\[
a=pv_1,\quad b=pq,\quad c=xv_2,\quad d=zv_4,\quad e=v_1v_5.
\]
Keep the seven exterior \(K\)-edges displayed at the start of the note. The subdivision vertices are \(t_a,t_b,t_c,t_d,t_e\), each with its terminal semiedge. The following table assigns a two-element subset of \(\{1,\ldots,6\}\) to every edge; an entry such as \(13\) means \(\{1,3\}\).

| Edges | BF labels |
|---|---|
| \(u_1p,u_1x,u_1z,u_2x,u_2q,u_3q,u_3z\) | \(25,13,46,45,13,46,12\) |
| \(h_2,h_3\) | \(26,35\) |
| \(v_1v_2,v_2v_3,v_3v_4,v_4v_5\) | \(14,26,14,35\) |
| \(pt_a,t_av_1,s_a\) | \(14,36,25\) |
| \(pt_b,qt_b,s_b\) | \(36,25,14\) |
| \(xt_c,t_cv_2,s_c\) | \(26,35,14\) |
| \(zt_d,t_dv_4,s_d\) | \(35,26,14\) |
| \(v_1t_e,v_5t_e,s_e\) | \(25,14,36\) |

At each of the 17 vertices the three incident labels are disjoint and partition \(\{1,\ldots,6\}\); the table is therefore an actual six-perfect-matching BF row, not a selected-matching relation. Colors \(1,2,3\) have terminal boundaries \(\{b,c,d\},\{a\},\{e\}\), and colors \(4,5,6\) have the same pattern. Thus the row has type \([ea]\). The edge \(u_3z\) has label \(12\), so its two half-loads are \(2\) and \(0\), respectively. Deleting the five marked subdivision vertices leaves an unmarked graph whose shortest cycles have length six. The endpoints of every mark have unmarked distance at least three, and no two marks have the same endpoint pair, so subdivision creates no cycle of length below five. The cycle \(u_3-z-t_d-v_4-v_3-u_3\) has length five.

The mixed half can be checked without enumerating the pole's complete matching family. Choose \(S=e-a-d-b-c-e\), so \(cd\in T\). The load of colors \(1,2,3\) in the table has the following second decomposition, where each row is one actual perfect matching:
\[
\begin{array}{c|l|c}
 &\text{proper edges}&\text{terminal semiedges}\\\hline
N_1&u_1x,\ h_2,\ u_3z,\ pt_a,\ qt_b,\ t_cv_2,\ t_ev_1,\ v_3v_4&s_d\\
N_2&u_1x,\ u_2q,\ u_3z,\ pt_b,\ t_av_1,\ v_2v_3,\ t_ev_5,\ t_dv_4&s_c\\
N_3&u_1p,\ u_2q,\ h_3,\ xt_c,\ zt_d,\ v_1v_2,\ v_4v_5&s_a,s_b,s_e.
\end{array}                                                       \tag{5}
\]
Each proper edge in the first table has the same multiplicity in \(N_1+N_2+N_3\) as it has among colors \(1,2,3\). The new terminal pattern is \(1+1+3\), with singleton terminals \(d,c\); hence \(cd\in\mathcal R(D_1)\cap T\). This is a real mixed \([ea]\) loop, so it realizes precisely the alternative left open by the loop-rigidity theorem.

The complementary half is mixed as well: in the symmetric difference of colors \(4\) and \(6\), the terminal-\(e\) component is the entirely exterior path
\[
e-t_e-v_5-u_2-x-t_c-c.
\]
Switching those two colors along it changes the complementary half's state from \(ea\) to \(ac\in T\). Pairing that decomposition with (5) yields a **genuine forbidden** \((cd)(ac)\) BF row. Thus the same explicit graph both refutes unconditional loop rigidity and demonstrates exactly why it is not an exact-Case-XII pole. It does not refute the pure-\(S\) loop-rigidity theorem or the unresolved exact-support case.

The proof and the explicit BF labels have been checked edge by edge by hand; this note has not received an independent verification of the upstream saturation and minimum-host chain.
