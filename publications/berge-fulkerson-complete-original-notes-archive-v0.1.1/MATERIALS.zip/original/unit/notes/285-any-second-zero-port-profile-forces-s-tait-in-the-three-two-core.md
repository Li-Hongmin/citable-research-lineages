> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Any second zero-port profile forces S-Tait in the three-two core

Continue the \(3{:}2\) unmarked near-bipartite central-core profile of [Notes 282–284](284-a-surviving-zero-port-mask-forces-an-s-tait-state.md). Let \(g\) be the edge whose deletion makes the unmarked core bipartite, with both ends in \(B\); the internal marked edge has ends \(v\in B,w\in R\). The five proper shore ports are \(A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\), exactly two of them based in \(R\). Both required \(ad/ac\) rows and complete exact-Case-XII negative support are assumed.

**Theorem.** If the complete zero-port shore matching fibre contains a matching \(X'\) selecting \(t_ew\) and \(g\), then the five-pole has an actual \(ea\)-Tait colouring and its Tait-state set is all of the allowed pentagon \(S\). In particular, a **Tait-empty** exact-Case-XII pole in this \(3{:}2\) profile has only zero-port matchings selecting \(t_ev\) and avoiding \(g\). The conclusion concerns the complete fibre, not just the zero-port occurrences of the two required rows.

Together with [Note 282's](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md) mixed-side \(4+1\) result, this gives a boundary for the **entire** unmarked-one-edge-near-bipartite branch: if its exact pole is Tait-empty, it must lie in the \(3{:}2\) cut profile and have only the \((t_ev,g\notin X)\) zero-port profile.

## Two forbidden completions leave three port pairings

As in [Note 283](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md), colour \(t_e\) and the five exterior interface endpoints by \(R\). The full pole minus \(g,t_ew\) and the two \(R\)-based proper cut edges is bipartite. Write \(R_0\) for those two cut-edge port names. Since \(X'\) uses \(g,t_ew\), these are the only odd-cycle exceptions in the complement of every triple formed by gluing \(X'\) to a zero-interface exterior matching.

Use the two **actual** exterior masks of forbidden missing-pair state \(eb\) from Note 283. Their exterior complement connections are
\[
P_0:\quad ID\mid AH,\ b\to J,
\qquad
P_1:\quad AD\mid HJ,\ b\to I.                       \tag{1}
\]
Both glue to the same \(X'\). If the two edges of \(R_0\) lie in the same component of either complete triple complement, all closed cycles are even and [Note 125's triple-complement lemma](125-no-single-edge-bipartization-in-exact-case-xii.md) gives a forbidden \(eb\)-Tait state. Thus they must be **separated** in both completions.

Note 283 already excludes \(R_0=ID,AH,AD\) by direct exterior paths. Its row balance also leaves no \(R_0=HJ\). The six remaining pairs and all shore-complement port pairings \(\sigma(X')\) that separate them under both masks in (1) are exactly:
\[
\begin{array}{c|c}
R_0&\sigma(X')\\\hline
AI&EI\mid AH\mid DJ\\
AJ&EJ\mid AD\mid IH\\
IH&EA\mid ID\mid HJ\quad\text{or}\quad EI\mid AH\mid DJ\\
IJ&EA\mid ID\mid HJ\\
DH&EA\mid ID\mid HJ\\
DJ&EA\mid ID\mid HJ\quad\text{or}\quad EJ\mid AD\mid IH.
\end{array}                                                     \tag{2}
\]
Here \(EA\), for example, denotes a path in the complement of \(X'\) joining shore ports \(E,A\); closed shore components, if any, do not affect the table.

The table follows from two small separation tests. In \(P_0\), if the two exceptional cut edges lie on the distinct exterior paths \(ID,AH\), separating them requires one of those paths to close directly through the same shore pair. If one exception is at the terminal arm \(bJ\), the other exterior path must close; this happens either by its own shore pair or by the shore pair \(EJ\), which closes the terminal path immediately. In \(P_1\), the analogous direct pairs are \(AD,HJ\), the terminal arm is \(bI\), and \(EI\) can close that terminal path immediately. Applying these tests to the six pairs gives (2). This is a hand pairing check on six ports, with no assumption that matchings from different BF rows agree.

## Every surviving pairing gives the allowed colouring

Glue the same \(X'\) to the actual zero-interface exterior matching of missing-pair state \(ea\): select \(a:C_{\rm ext}\), path edges \(1A,2B,3D,4E\), and terminal semiedges \(b,c,d\). Its complement connects
\[
a\to A,\qquad I\leftrightarrow J,\qquad D\leftrightarrow H. \tag{3}
\]
For \(\sigma=EA\mid ID\mid HJ\), the terminal path is \(e-E-A-a\); the other four ports form one closed component \(I-D-H-J-I\). In (2), this pairing occurs only for \(R_0=IH,IJ,DH,DJ\), so that closed component contains **both** exceptional cut edges and is even.

For \(\sigma=EI\mid AH\mid DJ\), the terminal path is \(e-E-I-J-D-H-A-a\); this pairing occurs only for \(R_0=AI,IH\), and both exceptional edges lie on the path. For \(\sigma=EJ\mid AD\mid IH\), the terminal path is \(e-E-J-I-H-D-A-a\); this pairing occurs only for \(R_0=AJ,DJ\), again with both exceptional edges on the path. Any additional closed shore cycles are even because \(X'\) uses \(g,t_ew\). Thus **every** closed component of the full \(ea\) triple complement is even in every line of (2). Alternating the complement gives an actual Tait colouring of state \(ea\in S\).

The absence of \(T\)-loops excludes every \(T\)-Tait state, while ordinary bichromatic terminal-path switches carry one \(S\)-Tait state around the entire allowed pentagon. Hence the Tait-state set is exactly \(S\). \(\square\)

This strengthens [Note 284](284-a-surviving-zero-port-mask-forces-an-s-tait-state.md) from one \(R_0\) placement to every placement left by Note 283. It does not exclude the S-Tait branch, the mixed-side \(4+1\) profile of Note 282, general high-rank cores, or the unresolved four-slot load intersection. [Note 286](286-two-b-side-ports-in-the-three-two-core-force-s-tait.md) independently checks the fifteen shore-port pairings and the resulting \(ea\) complement parity; the exterior masks and upstream forced-row templates remain hand-derived.
