> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Canonical Kempe transport does not detect Pentagon selection

This note corrects an over-strong interpretation in the first version of [Note 002](002-kempe-transport-and-the-order-eleven-bound.md). The relational formulation in [Note 001](001-pentagon-selection-as-matching-holonomy.md) remains valid.

For each edge relation `E_t=R_{v_t v_{t+1}}`, the Kempe switch constructed in Note 002 gives a canonical bijection `f_t:E_t -> E_{t+1}`. Its composite `h=f_4...f_0` is a permutation of `E_0`. A fixed point of `h` yields a compatible pentagon, but a compatible pentagon need not follow the edges selected by the five canonical maps. Therefore the converse implication fails.

The complete eleven-vertex dataset gives concrete matching-derived counterexamples. Across its 41 Case-XII branches the cycle types of `h` are

\[
(1)^{15},\quad (1,1)^7,\quad (2)^{12},\quad
(2,2)^4,\quad (3)^2,\quad (4)^1.
\]

Nineteen branches have fixed-point-free canonical transport, although every one of the 41 branches has at least one compatible pentagon. In particular, canonical transport need not be an involution and neither its sign nor its cycle length forces Pentagon-selection.

For the earlier complete datasets, the canonical cycle-type distributions are `(1)` once at order five, `(1)` ten times at order seven, and `(1)` 600 times, `(1,1)` 60 times, `(2)` 120 times at order nine. Thus eleven internal vertices is the first order in the enumerated structural class at which canonical transport is not an involution.

A smallest nontrivial branch in this dataset has common relation size two, augmented graph6 string

```text
K?AB?pas?YV_
```

and boundary map

\[
1\mapsto0,\quad2\mapsto3,\quad3\mapsto5,
\quad4\mapsto2,\quad5\mapsto4.
\]

Its canonical `h` exchanges the two elements of `E_0` and has no fixed point, while the full five relations contain two compatible pentagons. This closes all proof routes based only on a fixed point, involutivity, sign, or cycle type of the selected canonical transport.

The unresolved object is the full multivalued composition

\[
(R_{31}\circ R_{53}\circ R_{25}\circ R_{42}\circ R_{14})
\cap\Delta_{\mathcal P_1}.
\]

The next structural distinction must therefore constrain all compatible relation edges, not merely the canonical Kempe successor of each Tait colouring.
