> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two exterior switches exclude the diagonal double-star Case XII

Consider the one-internal-mark, six-port shore of [Notes 358–360](360-k33-double-star-exact-case-xii-forces-distinct-zero-port-shore-matchings.md). Its exterior tree is the double star with centres \(x,y\), leaves \(r_1,r_2,l_1,l_2\), and subdivided edges
\[
 x-u_0-y,\qquad x-u_1-r_1,\quad x-u_2-r_2,\quad
 y-u_3-l_1,\quad y-u_4-l_2.
\]
The four exterior marked edges are \(a=r_1l_1\), \(b=r_1l_2\), \(c=r_2l_1\), and \(d=r_2l_2\), with terminal subdivision vertices \(t_a,t_b,t_c,t_d\). The sixth mark \(e\) lies in the shore. Assume that the two allowed states incident with \(e\) in the Case-XII pentagon \(S\) are the diagonal pair \(ea,ed\). Thus \(eb,ec,ad\in T=\binom{\{e,a,b,c,d\}}2\setminus S\), independently of the order of \(b,c\) around \(S\).

**Theorem.** No cubic five-pole with this exterior has complete exact-Case-XII BF boundary support. This holds for every size and cycle rank of the six-port shore. More precisely, a genuine row \((ea)(ad)\) together with the absence of \(T\)--\(T\) rows is impossible.

The Appendix XII support in [Máčajová–Mazzuoccolo–Tabarelli, Proposition 4.4](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires \((ea)(ad)\). Let its two triple occurrences be \(P\) of state \(ea\) and \(R\) of state \(ad\). Denote the four singleton occurrences by \(E\) at \(e\), \(D\) at \(d\), and \(A_1,A_2\) at \(a\). We freely exchange two **complete** matching occurrences on one alternating component of their symmetric difference. Such an exchange preserves every edge load and gives another genuine BF row.

By the root-tree and opposite-side locks of [Note 362](362-diagonal-case-xii-cross-row-locks-root-singletons-to-tree-edges.md), both \(A_i\) use the tree edge at the root of \(P\); \(R\) uses the same \(a\)-half as \(P\), and its \(d\)-half lies on the opposite \(r/l\) side. For clarity, the root-tree lock follows directly here: an \(A_i\) on the other marked half at the root would switch \(P\) from \(ea\) to \(eb\) or \(ec\), leaving \(R\) at \(ad\) and producing a forbidden \(T\)--\(T\) row.

Suppose first that \(P\) is rooted at \(r_1\). Then both triples use \(t_ar_1\), while \(R\) uses \(t_dl_2\). The rooted-tree matching of \(P\) uses \(xu_1,yu_0,r_2u_2,l_1u_3,l_2u_4\). At \(r_2\), both triples use \(r_2u_2\), so its other two incident edges carry the singleton pairs
\[
  r_2t_d:\{A_1,A_2\},\qquad r_2t_c:\{E,D\}.             \tag{1}
\]
Indeed, \(D\) uses terminal \(d\) and cannot use a \(d\)-half; at \(l_2\), where \(t_bl_2\) carries \(A_1,A_2\), the remaining singleton on \(t_dl_2\) must be \(E\). The marked-vertex load then gives (1). Likewise \(l_1t_c\) and \(l_2t_b\) carry \(A_1,A_2\).

For either \(A_i\), the \(P\triangle A_i\) terminal path starts
\[
              a-t_a-r_1-u_1-x.
\]
The \(A_i\)-edge leaving \(x\) is \(xu_0\) or \(xu_2\). In the first case the path continues through \(u_0-y\) and ends at \(c\) via \(u_3,l_1,t_c\), or at \(b\) via \(u_4,l_2,t_b\). Switching it changes \(P\) to forbidden state \(ec\) or \(eb\), while \(R\) stays at \(ad\). Therefore \(A_i\) uses \(xu_2\). Now the entire terminal path is outside the shore:
\[
              a-t_a-r_1-u_1-x-u_2-r_2-t_d-d.              \tag{2}
\]
Exchange \(P\) and \(A_i\) on (2). The new triple \(P'\) has state \(ed\) and uses \(t_dr_2\). The untouched singleton \(D\) uses \(r_2t_c\) by (1). Consequently \(P'\triangle D\) contains the exterior terminal path
\[
                          d-t_d-r_2-t_c-c.                 \tag{3}
\]
Switching (3) changes \(P'\) to state \(ec\). The unchanged \(R\) has state \(ad\), yielding a forbidden \((ec)(ad)\) row.

If \(P\) is rooted at \(l_1\), both triples use \(t_al_1\), and \(R\) uses \(t_dr_2\). The rooted-tree matching of \(P\) uses \(yu_3,xu_0,r_1u_1,r_2u_2,l_2u_4\). At \(l_2\), both triples use \(l_2u_4\); the remaining singleton pairs are
\[
           l_2t_d:\{A_1,A_2\},\qquad l_2t_b:\{E,D\}.     \tag{4}
\]
Here \(D\) cannot use a \(d\)-half, and \(r_2t_d\) carries \(R\) and \(E\). Also \(r_1t_b\) and \(r_2t_c\) carry \(A_1,A_2\). For either \(A_i\), its \(P\)-alternating path starts \(a-t_a-l_1-u_3-y\). If \(A_i\) leaves \(y\) through \(yu_0\), the path passes through \(u_0-x\) and ends at \(b\) through \(u_1,r_1,t_b\) or at \(c\) through \(u_2,r_2,t_c\). Both give a forbidden \(T\)--\(T\) row. Hence \(A_i\) uses \(yu_4\), and the path is
\[
              a-t_a-l_1-u_3-y-u_4-l_2-t_d-d.              \tag{5}
\]
Switching (5) gives an \(ed\)-triple \(P'\) using \(t_dl_2\). Equation (4) leaves the untouched \(D\) on \(l_2t_b\), so \(P'\triangle D\) contains \(d-t_d-l_2-t_b-b\). Its switch gives the forbidden \((eb)(ad)\) row. Both possible roots are impossible. \(\square\)

The square symmetries send the other diagonal pair \(eb,ec\) to \(ea,ed\), so the theorem excludes **either diagonal placement** of the two \(e\)-incident allowed states. It does not address the four adjacent placements, other marked trees, the triangular-prism exterior, or the Berge–Fulkerson conjecture. The proof is an analytic full-matching switch argument; its only prior orientation input is Note 362, and it has not received an independent review. No local mathematical recomputation was used.
