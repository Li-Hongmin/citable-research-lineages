> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right zero-port matching forces both left ad opposite fibres

Assume the genuine left \((ea)(ac)\) row and right \((ea)(ad)\) row of [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md) in its sole surviving \(3{:}2\) near-bipartite placement \(R_0=DJ\). The unmarked core minus \(g\subset B\) is bipartite, the marked edge has \(v\in B,w\in R\), and among proper shore ports \(A,I,H\in B\), \(D,J\in R\). Use \(E\) for the marked terminal port. Let \(X_R\) be the right row's zero-port shore matching and \(Z_L\) the left \(ac\) row's \(EAID\)-port matching. Their profiles are
\[
 X_R:\ (\varnothing,g,t_{ew}),
 \qquad Z_L:\ (EAID,E,g\notin Z_L).                       \tag{1}
\]

**Theorem.** The two shore paths of \(X_R\triangle Z_L\) pair
\[
                       \boxed{ED\mid AI}.                    \tag{2}
\]
The \(E\)--\(D\) path contains \(t_{ew}\) and avoids \(g\); the \(A\)--\(I\) path contains \(g\) and avoids \(t_e\). Switching these paths separately in \(Z_L\) gives actual shore perfect matchings
\[
 M_{AI}:\quad S(M_{AI})=AI,\quad t_{ew}\in M_{AI},\quad g\notin M_{AI},
 \qquad
 M_{ED}:\quad S(M_{ED})=ED,\quad E,g\in M_{ED}.       \tag{3}
\]
They glue, respectively, to the genuine \(W_d\) and \(U_{ad}\) exterior masks of [Note 272's left \(ad\) template](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). Thus that template's two *individual opposite matching fibres* are forced to be nonempty, even though a complete left \(ad\) BF row is not forced.

**Proof.** The \(E\)-starting path of \(X_R\triangle Z_L\) goes through \(t_{ew}\), because \(Z_L\) selects \(E\) and \(X_R\) selects \(t_{ew}\). If it also contained \(g\), switching it in \(Z_L\) would yield a shore matching selecting \(g,t_{ew}\) with one of the proper two-port sets \(AI,AD,ID\). All three are forbidden by [Note 290's complete-fibre theorem](290-two-port-closure-separates-the-remaining-three-two-row-loads.md). Hence the path avoids \(g\). After the switch, the resulting matching selects \(t_{ew}\) but not \(g\). [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) requires both remaining proper ports to be based in \(B\). They must be \(A,I\), so the removed ports were \(E,D\). This proves the first path of (2) and gives \(M_{AI}\).

The other open path pairs \(A,I\). It contains \(g\): a closed alternating component cannot contain \(g\) alone, since its only other possible same-side edge \(t_{ew}\) lies on the \(E\)--\(D\) path. Switching the \(A\)--\(I\) path in \(Z_L\) retains \(E,D\) and transfers \(g\), giving \(M_{ED}\). The two exterior masks in Note 272, Table (3), have exactly the respective shore port sets \(AI\) and \(ED\), including selected terminal \(E\) for the latter. Gluing therefore yields real full-pole matchings. \(\square\)

This does **not** give the left \((ea)(ad)\) row. If its other four slots were taken unchanged from the left \(ac\) row, their \(g\)-load would be two already: [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md) forces both left singleton-\(a\) occurrences to select \(g,t_{ew}\), while its zero-port \(X_L\) and singleton-\(e\) \(Z_L\) avoid \(g\). Adding \(M_{ED}\) raises the load of \(g\) to three. A genuine left \(ad\) row would need a different selection of complete matchings, including an \(HJ\)-port occurrence avoiding \(g\); the existence of that fibre is not proved here. The right \(ad\) row, exact Case XII in other core profiles, and Berge–Fulkerson remain unresolved. The proof uses only symbolic switching and the cited hand-derived fibre restrictions; no local recomputation or OMEN was used.
