> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact no-$TT$ terminal pairings do not break the $K_{3,3}$ owner rectangle

The owner-phase obstruction of [Note 097](097-a-k33-owner-phase-rectangle-blocks-local-fibre-avoidance.md) is compatible with the terminal-path pairings forced by exact Case-XII negative support.  Moreover, the four repeated-star row equations, even when imposed on common cubic coordinates, force neither an all-terminal row, a $T$--$T$ row, nor a boundary-changing two-occurrence equality.  Thus a minimum bad owner trace cannot be converted into a forbidden boundary type using only local carrier incidence and terminal pairing data.

This is an information boundary, not an exact-Case-XII pole.

## The forced terminal pairings

Use the two literal pivot rows

\[
\begin{aligned}
R_3&=(q_{24},r_{15},A,B,C,D),\\
R_1&=(q_{13},r_{45},A,X,C,D),
\end{aligned}
\tag{1}
\]

where $\partial(A,B,C,D,X)=(1,2,4,5,3)$ and

\[
K=2\mathbf1-A-C-D
 =q_{24}+r_{15}+B
 =q_{13}+r_{45}+X.
\tag{2}
\]

The four terminal ends of $q_{13}\mathbin\triangle X$ are $\{2,3,4,5\}$.  Switching the path from terminal $3$ to its other endpoint produces, according as that endpoint is $2,4,$ or $5$, a completion of type

\[
(12)(45),\qquad (14)(45),\qquad (15)(45).
\tag{3}
\]

The first and third are $T$--$T$ types.  Hence their absence forces

\[
\pi_X(3)=4,qquad \pi_X(2)=5.
\tag{4}
\]

Likewise the four ends of $q_{24}\mathbin\triangle B$ are $\{1,2,3,5\}$.  Switching the path from terminal $2$ gives types

\[
(14)(15),\qquad (34)(15),\qquad (45)(15)
\tag{5}
\]

for endpoints $1,3,5$ respectively.  Exact no-$TT$ therefore forces

\[
\pi_B(2)=1,qquad \pi_B(3)=5.
\tag{6}
\]

These constraints concern terminal path components.  By contrast, the bad set

\[
J(B,X)=B\cap X\cap(A\mathbin\triangle C)
\tag{7}
\]

sees only the internal traces of the two singleton colours on the owner support.

## A compatible bad rectangle

Index the two shores of $K_{3,3}$ by $\{0,1,2\}$, and write a perfect matching as the image word of its permutation.  Take

\[
A=012,quad C=120,quad D=201,
\tag{8}
\]

\[
B_0=012,quad B_1=120,qquad
X_0=021,quad X_1=102.
\tag{9}
\]

As in Note 097, every one of the four intersections $B_i\cap X_j$ consists of one edge owned by $A$ or $C$.  Hence all four choices have $J\ne\varnothing$, while the two row matchings and the two column matchings have no common fixed edge.

Put $Y=210$ and choose the local carrier triples

\[
(q_{24},r_{15},B)
=(C,D,B_0),\ (A,D,B_1),
\tag{10}
\]

\[
(q_{13},r_{45},X)
=(X_1,Y,X_0),\ (X_0,Y,X_1).
\tag{11}
\]

Each triple partitions $E(K_{3,3})$.  Furthermore,

\[
q_{24}\mathbin\triangle B_i=A\mathbin\triangle C
\tag{12}
\]

is a closed six-cycle, whereas

\[
q_{13}\mathbin\triangle X_j=X_0\mathbin\triangle X_1
\tag{13}
\]

is a closed four-cycle.  Both avoid the attachment edge $(0,2)$.  The block therefore contributes no terminal endpoint to either bichromatic pair.  An ambient attachment can realize (4) and (6) independently of the four internal bad phases.  Thus exact-allowed terminal pairing does not break the owner rectangle.

## The four row equations force no forbidden balance

There is no universal forbidden two-sum hidden in the four common row equations.  To test their complete cubic-coordinate consequences, add one $K_4$ coordinate.  Every actual perfect matching chooses one of the three one-factors of $K_4$, and a six-matching row covers that component twice precisely when each symbol occurs twice.

The four rows use fifteen matching identities and share only $A,C,D$.  There are exactly $9{,}234$ ternary assignments satisfying all four row balances.  Across this entire solution set:

- none of the four available all-terminal singleton tuples is always capacity-valid;
- none of the ten available $15/45$ $T$--$T$ tuples is always balanced;
- no two distinct matching pairs have the same incidence sum in every assignment.

Hence the common row and cubic equations do not imply a boundary-changing equality such as

\[
q_{13}+X=q_{12}+B'_2.
\tag{14}
\]

The finite classification is frozen in the [verification bundle](../computations/bundles/k33-owner-rectangle-terminal-pairing-boundary/README.md).

## Consequence for the extremal route

For a legal replacement $B'$ in the same carrier, put $R=B\mathbin\triangle B'$.  Minimality of $|J|$ gives only

\[
|J(B,X)\cap R|
\le
|(B'\setminus B)\cap X\cap(A\mathbin\triangle C)|.
\tag{15}
\]

This inequality contains no terminal-component datum.  Equations (4), (6), and the construction above show that adding the exact-allowed path pairings does not supply one.  The one-step $TT$ exits found in the non-exact pole of Note 024 use precisely a terminal pairing forbidden by (4), so they cannot be promoted to an exact-Case-XII extremal lemma.

The remaining positive statement must couple the complete graph-induced perfect-matching family to one fixed carrier fibre.  It must either force a genuine decreasing entry in that fibre or force a boundary-labelled equal-sum relation by an identity not contained in the four local rows.  Existence of all forty boundary types alone does not identify such an occurrence.  The present construction does not realize a connected cubic five-pole with complete exact-Case-XII support, so that real statement remains open.
