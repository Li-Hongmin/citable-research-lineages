> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five-vertex six-cut Hall design and zero-port phase gate

Continue the noncollision, complete exact-Case-XII \(R_0=DJ\)
near-bipartite branch of
[Note 319](319-no-four-vertex-six-cut-hall-block-in-the-right-dj-branch.md).
Let \(S\subset B\) be a tight six-cut Hall witness with
\(|S|=5\) and \((\alpha,\eta)=(2,1)\). Put
\(T=N_K(S)\setminus\{d_D\}\), where \(d_D\) is the
\(D\)-port base. The completed minimum host has girth at
least five. Let the two proper \(B\)-port incidences in
\(S\) be \(H\) and \(Q\in\{A,I\}\).

**Theorem.** Up to names, the entire \(S\)--\(T\)
incidence graph is
\[
\begin{array}{c|ccccc}
T\text{-vertex}&o&p&x&y&z\\\hline
N_S&\{u,a,b\}&\{u,c,f\}&\{a,c\}&\{a,f\}&\{b,c\}.
\end{array}                                                   \tag{1}
\]
The three incidences leaving \(S\), namely \(H,Q\) and
the unique edge \(\ell d_D\), are based at the three
distinct vertices \(u,b,f\), in some order. The only
pair of \(S\)-vertices without a common \(T\)-neighbour
is \(\{b,f\}\). The \(J\)-port base is one of \(x,y,z\).

If an actual zero-proper-port shore matching \(X\)
selects \(g,t_{ew}\) and avoids \(\ell d_D\), then
\(H\) and \(\ell\) must be the missing pair \(b,f\)
in either order; equivalently, \(Q\) must be based at
\(u\). Hence if \(H\) or \(\ell\) is based at \(u\),
**every** zero-port \((g,t_{ew})\) matching uses
\(\ell d_D\). This is a necessary phase gate, not a
realization of the remaining placement.

**Incidence proof.** The Hall equality gives \(|T|=5\).
Cubic degree counting yields
\[
             e_K(S,T)=3|S|-\alpha-\eta=12.                 \tag{2}
\]
Write \(k_t=|N_S(t)|\le3\). Girth at least five
implies that each pair in \(S\) has at most one common
\(T\)-neighbour, so
\(\sum_{t\in T}\binom{k_t}{2}\le\binom52=10\).
With \(\sum k_t=12\), the only possible degree
multisets are \((3,3,2,2,2)\) and \((3,3,3,2,1)\).
The latter is impossible: any two 3-neighbourhoods on a
five-set meet in exactly one vertex, and after two such
neighbourhoods have used their six distinct pairs, a third
3-neighbourhood would repeat a pair. Thus the degrees are
\((3,3,2,2,2)\) and exactly nine of the ten \(S\)-pairs
have a common neighbour.

The two 3-neighbourhoods meet in a unique vertex \(u\);
name them \(\{u,a,b\}\) and \(\{u,c,f\}\).
The three remaining 2-neighbourhoods must use three of
the four cross pairs between \(\{a,b\}\) and
\(\{c,f\}\). Relabel so that \(bf\) is missing.
This gives (1). The degrees from \(S\) into \(T\)
are two at \(u,b,f\) and three at \(a,c\), so cubicity
puts precisely one outward incidence at each of
\(u,b,f\). The degree-three \(T\)-vertices \(o,p\)
cannot carry the \(J\) port, proving the remaining
incidence statements.

**Phase proof.** If \(X\) avoids \(\ell d_D\), it
selects neither of the two proper \(B\) ports, and
therefore matches the five \(S\)-vertices bijectively
to \(T\). The incidence graph (1) has exactly four
perfect matchings:
\[
\begin{aligned}
M_1&=\{uo,bz,ax,cp,fy\},&
M_2&=\{uo,bz,ay,fp,cx\},\\
M_3&=\{up,fy,ao,bz,cx\},&
M_4&=\{up,fy,ax,bo,cz\}.
\end{aligned}                                                   \tag{3}
\]
The successive differences \(M_1\triangle M_2\),
\(M_2\triangle M_3\), and \(M_3\triangle M_4\)
are respectively the alternating six-cycles
\(a-x-c-p-f-y-a\), \(u-o-a-y-f-p-u\), and
\(a-o-b-z-c-x-a\). Switching them in the *actual*
matching \(X\) realizes every phase (3), with the
matching unchanged outside \(S\cup T\), including
\(g,t_{ew}\).

If \(H\) is at \(u\) and \(\ell=f\), phase \(M_1\)
leaves the complete complementary path
\(H-u-p-f-d_D-D\); the same path works in reverse
if \(H=f,\ell=u\). If \(H\) is at \(u\) and
\(\ell=b\), phase \(M_3\) leaves
\(H-u-o-b-d_D-D\), again valid in reverse.
Because \(X\) avoids \(\ell d_D\) and its \(D\)
port is unselected, \(d_D\) is matched by its third
edge; these are complete shore port paths.
[Note 285's forbidden-\(eb\) completion](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
excludes every \(HD\) complement path for a zero-port
\((g,t_{ew})\) matching. Thus none of these four
placements is possible. Only \(H,\ell=\{b,f\}\)
can accompany a zero-port matching that avoids
\(\ell d_D\), as claimed. \(\square\)

The theorem leaves the zero-port phase when it uses
\(\ell d_D\), and the missing-pair \(H,\ell\)
placement when it does not. The \((1,2)\) allocation,
larger Hall blocks, collisions, other shore profiles,
and Berge–Fulkerson remain open. This is a hand
classification and matching-closure proof; no local
recomputation or OMEN run was used.
