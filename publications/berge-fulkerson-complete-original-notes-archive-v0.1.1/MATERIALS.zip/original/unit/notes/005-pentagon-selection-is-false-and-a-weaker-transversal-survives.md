> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Pentagon selection is false; a weaker transversal survives

## A thirteen-vertex counterexample

There is a simple connected cubic 5-pole on internal vertices `0,...,12`, with semiedge `s_i` incident with vertex `i-1`, and proper edges

\[
\begin{split}
&(0,2),(0,11),(1,11),(1,12),(2,12),(3,9),(3,10),\\
&(4,8),(4,9),(5,7),(5,8),(5,11),(6,7),(6,10),\\
&(6,12),(7,9),(8,10).
\end{split}
\]

An independent recursive enumeration gives 31 perfect matchings and singleton-boundary class sizes

\[
(2,3,2,3,3).
\]

Its Tait lonely-pair states are exactly

\[
S=\{13,14,24,25,35\}.
\]

Each of the five consecutive singleton-matching compatibility relations has two edges and distinct endpoints. Their layered union is a connected ten-vertex 2-regular graph, hence `C_10`, and contains no lifted 5-cycle. Thus this pole is a real counterexample to unrestricted Pentagon-selection.

This does not realize the published Case-XII exact BF set. Exhaustive enumeration of the `31 multichoose 6 = 1,947,792` six-matching multisets finds 177 double covers and 40 boundary types, including `(12345)`. Relative to the 40-type Case-XII transcription, the two sets differ in eight types in each direction.

## Capacity-two transversal characterization

For each boundary position choose a singleton-boundary perfect matching `P_i`. Suppose

\[
m(e)=|\{i:e\in P_i\}|\le2
\]

for every edge and semiedge. At each internal cubic vertex the three incident multiplicities sum to five and are at most two, so they are `2,2,1`. The multiplicity-one edges therefore form a perfect matching `P_0`. Each semiedge lies only in its selected `P_i`, so all five semiedges belong to `P_0`. Consequently `P_0,P_1,...,P_5` cover every edge twice and give boundary type `(12345)`.

Conversely, every `(12345)` BF cover has one colour matching containing all five semiedges and five colour matchings containing one semiedge each. Removing the all-terminal matching leaves a capacity-two transversal: an edge in the removed matching occurs once among the other five, and every other edge occurs twice. Thus `(12345)` exists if and only if a capacity-two singleton transversal exists.

This condition is strictly weaker than the compatible-pentagon condition: pairwise disjointness along the complementary pentagon implies the capacity bound, but the thirteen-vertex pole has no compatible pentagon and nevertheless has a capacity-two transversal.

## Complete finite audit through thirteen vertices

At eleven vertices, every retained Case-XII Tait-state branch has a compatible pentagon and hence a capacity-two transversal. At thirteen vertices, complete unlabelled generation gives

\[
59338\to6690\to6374\to318\to318,
\]

where the stages are all connected degree-bounded augmented graphs, exact degree sequence `(5,3^13)`, connected apex deletion, exact `C_5` Tait-state skeleton, and capacity-two success. Thus every simple connected distinct-terminal pole with at most thirteen internal vertices and Tait state set `S` has an `(12345)` BF cover, although the strongest previously proposed selection mechanism first fails at order thirteen.

## New exact frontier

The remaining conjectural bridge needed to exclude Case XII is:

> If a connected cubic 5-pole has Tait lonely-pair state set exactly `S`, then its five singleton-boundary perfect-matching classes admit a capacity-two transversal.

If true, the lemma forces `(12345)` and excludes the published Case-XII exact set. If false, the correct next object is a pole in which every five-class transversal uses some edge at least three times.
