> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right row excludes the two-point six-cut Hall block

Continue the complete exact-Case-XII central-path branch with a real left
\((ea)(ac)\) row and a real right \((ea)(ad)\) row, in the
\(R_0=DJ\), \(3{:}2\) one-edge-near-bipartite profile of
[Notes 301–304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md).
The proper ports \(A,I,H\) have bases in \(B\), while \(D,J\) have
bases \(d,j\) in \(R\). Let \(g=xy\subset B\), let the internal
marked edge meet \(v\in B,w\in R\), and put
\[
 K=(C-\{g,e\})-\{x,y\}.
\]
Work in the noncollision branch \(v\notin\{x,y\}\) and \(d\ne j\).
Assume the completed minimum host has girth at least five. Let
\(S\subseteq B\setminus\{x,y,v\}\) be any tight \(DJ\) Hall witness,
so \(|N_K(S)|=|S|+1\) and \(d,j\in N_K(S)\). Write \(\alpha\) for
the number of proper \(B\)-side port incidences based in \(S\) and
\(\eta=e_K(S,d)\), as in [Note 290](290-two-port-closure-separates-the-remaining-three-two-row-loads.md).

**Theorem.** There is no such witness with
\[
                    |S|=2,\qquad (\alpha,\eta)=(2,1).       \tag{1}
\]
Consequently a six-edge Hall block of this allocation has at least
three \(B\)-vertices. Together with [Note 311](311-a-six-cut-hall-block-with-one-b-port-needs-five-b-vertices.md), every six-edge Hall block in this branch has at least three \(B\)-vertices. This is a conditional exclusion within the stated central-path and near-bipartite branch, not an exclusion of Case XII in general.

**Proof.** By [Note 309, Theorem 2](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md), the \(H\)-port base \(h\) belongs to \(S\). Name the other vertex \(k\), and write
\(N_K(S)=\{d,j,r\}\). The vertex \(d\) has exactly one neighbour
in \(S\), and the two proper port incidences in \(S\) are \(H\)
and one of \(A,I\).

These two ports cannot have the same base. If \(H,A\) share \(h\),
their two cut edges and the exterior path
\(t_a-C_{\rm ext}-u_3\) make a four-cycle in the completed host,
as in Note 290. If \(H,I\) share \(h\), then \(H-h-I\) is a whole
component of the left-row shore difference \(L(HJ)\triangle W(ID)\),
contrary to the valid \(DI\mid HJ\) pairing in the first section of
[Note 306](306-both-i-and-h-bases-belong-to-every-dj-hall-witness.md).
Thus \(h\) carries only \(H\) and \(k\) carries a port
\(P\in\{A,I\}\). Each has two internal neighbours in \(\{d,j,r\}\).

Suppose first that \(P=I\). In the real right row, \(U\) has ports
\(EJ\), while either \(Q\in\{Y,V\}\) has ports \(ID\).
Because \(U\) selects \(J\) and neither \(H\) nor \(I\), it
matches \(S\) to \(\{d,r\}\). If \(k\) is the neighbour of \(d\),
then \(D-d-k-I\) is a whole path of \(U\triangle Q\). If \(h\)
is the neighbour of \(d\), then \(U\) uses \(hd,kr\). The matching
\(Q\) selects \(D,I\), so at \(h\) it uses either \(hj\) or
\(hr\). The latter choice creates the whole path
\(D-d-h-r-k-I\). Both paths contradict the forced \(EI\mid DJ\)
pairing of [Note 309, Theorem 1](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md).
Hence \(Q\) must use \(hj\), which makes \(N_K(\{h\})=\{d,j\}\).
This is the singleton witness excluded by
[Note 310](310-the-right-row-excludes-the-h-based-singleton-hall-block.md).
Therefore \(P\ne I\).

Now \(P=A\). A vertex of \(S\) adjacent to both \(d,j\) would
itself be a tight singleton witness. Note 309 puts \(h\) in every
such witness and Note 310 excludes \(\{h\}\), so this cannot occur.
There are only two possible local trees:
\[
\begin{array}{c|c|c}
 &N_K(h)&N_K(k)\\\hline
\mathrm{I}&\{d,r\}&\{j,r\}\\
\mathrm{II}&\{j,r\}&\{d,r\}.
\end{array}                                                    \tag{2}
\]
Here the port \(H\) is based at \(h\) and \(A\) at \(k\).

In the right row the shore port sets in slot order are
\((\varnothing,ID,EAHJ,EJ,ID,AH)\). Thus \(Z,W\) select both
\(H,A\), saturating these two port edges at row load two.
For shape I, \(U\) uses \(hd,kr\), while each of \(Y,V\) uses
\(hr,kj\); the edge-load-two equation at \(h,k\) forces the
zero-port matching \(X_R\) to use \(hd,kr\). For shape II, the
corresponding choices are \(U:hr,kd\),
\(Y,V:hj,kr\), and \(X_R:hr,kd\). By the real right-row load
[Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md),
\(X_R\) selects \(g,t_{ew}\).

The left \(ac\) row has an actual four-port shore matching
\(Z_L\) with ports \(EAID\) by
[Note 271, Table (5)](271-the-central-path-row-requires-two-distinct-shore-masks.md).
It selects \(A\) at \(k\) and \(D\) at \(d\). In shape I, it
must use \(hr\), so \(X_R\triangle Z_L\) has the complete local
component
\[
                         D-d-h-r-k-A.                         \tag{3}
\]
In shape II, it has the complete component
\[
                         D-d-k-A.                             \tag{4}
\]
Both components use only proper ports and edges of \(K\), so they
avoid \(g,t_{ew}\). Switching (3) or (4) into the actual matching
\(X_R\) gives an actual shore perfect matching with exactly the
proper ports \(AD\), still selecting \(g,t_{ew}\). This contradicts
[Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md),
which allows only \(HJ\) for that complete two-port fibre. Thus
\(P\ne A\), finishing the proof. \(\square\)

The argument uses genuine matchings from two different BF rows and
their common full shore matching closure. It does not identify their
other slots. It leaves \(|S|\ge3\) in the \((2,1)\) six-cut allocation,
\(|S|\ge5\) in the \((1,2)\) allocation, larger Hall cuts, the local
incidence collision, and the full Berge–Fulkerson conjecture open.
The proof is hand-derived and depends on the upstream complete-fibre
exclusion; no local enumeration or OMEN run was used.
