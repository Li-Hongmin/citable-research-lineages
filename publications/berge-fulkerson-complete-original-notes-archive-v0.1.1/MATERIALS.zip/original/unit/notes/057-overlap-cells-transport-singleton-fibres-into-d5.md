> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Overlapping \(S\)--\(T\) cells transport singleton fibres into \(D_5\)

This note records a matching-level consequence of the five overlapping
\(S\)--\(T\) cells.  It does not prove the four-cell join needed to exclude
Case XII.

Let

\[
 S=\{13,14,24,25,35\},\qquad
 T=\{12,15,23,34,45\}.
\]

Assume that a cubic five-pole \(H\) has no \(T\)-loop and no \(T\)--\(T\)
Berge--Fulkerson type.  Consider the cyclic family

\[
 \mathcal A_5=\{(13,12),(24,23),(35,34),(14,45),(25,15)\}.
\tag{1}
\]

For a row write its two pairs as \(s=ia\in S\) and \(t=ij\in T\).  There
is a unique \(b\) for which \(ab\in S\) is disjoint from \(ij\).  The
corresponding disjoint \(S\)--\(T\) cell is \((ab,ij)\).

## Row transport theorem

Suppose an actual cover of the overlapping cell \((ia,ij)\) is

\[
 \chi_{Q_{ia}}+\chi_{R_{ij}}+
 \chi_{P_i^0}+\chi_{P_i^1}+\chi_{P_a}+\chi_{P_j}=2\mathbf 1,
\tag{2}
\]

where \(Q_{ia}\) and \(R_{ij}\) are triple-boundary perfect matchings and
the \(P\)'s are singleton-boundary perfect matchings.  The two occurrences
at \(i\) are not assumed to use the same matching.  Then there are actual
matchings \(Q'_{ab}\), \(Q''_{ab}\), \(P_b^0\), and \(P_b^1\) such that

\[
 \chi_{Q'_{ab}}+\chi_{R_{ij}}+
 \chi_{P_a}+\chi_{P_b^0}+\chi_{P_i^1}+\chi_{P_j}=2\mathbf 1,
\tag{3}
\]

and

\[
 \chi_{Q''_{ab}}+\chi_{R_{ij}}+
 \chi_{P_a}+\chi_{P_b^1}+\chi_{P_i^0}+\chi_{P_j}=2\mathbf 1.
\tag{4}
\]

Thus one overlap witness transports three singleton matchings literally
into the associated disjoint cell; only one singleton coordinate is newly
introduced in each transported witness.  In particular, if

\[
 \Theta_i\subseteq\mathcal P_i\times\mathcal P_b
\]

denotes the actual relation of transported pairs, then

\[
 (P_i^1,P_b^0),(P_i^0,P_b^1)\in\Theta_i.
\tag{5}
\]

## Proof

Group (2) into the two load decompositions

\[
 A=Q_{ia}+P_i^0+P_a,\qquad
 B=R_{ij}+P_i^1+P_j.
\tag{6}
\]

Both have one unit on every boundary semiedge.  The displayed decomposition
of \(A\) has state \(ia\).  If a decomposition of \(A\) had a \(T\)-state,
combining it with the fixed \(T\)-state \(ij\) decomposition of \(B\) would
produce either a \(T\)-loop or a \(T\)--\(T\) cover, contrary to the
hypothesis.  Hence the nonempty state set of \(A\) is contained in \(S\).

The standard bichromatic-path switch in a three-edge-colouring of the
load multigraph preserves the load and closes every nonempty state subset
of \(S\) to all of \(S\).  Apply the switch to the component containing the
singleton colour of \(P_i^0\) and the triple colour of \(Q_{ia}\).  Its other
boundary endpoint must be the unique \(b\) for which \(ab\in S\); otherwise
the new state would be a forbidden \(T\)-state.  The resulting decomposition
therefore has the form

\[
 A=Q'_{ab}+P_a+P_b^0.
\tag{7}
\]

Combining (7) with \(B\) gives (3).  Interchanging the two \(i\)-occurrences
in (6) gives the same argument with \(P_i^1\) and \(P_i^0\) exchanged,
which yields (4).  All matchings produced by the switches are actual
perfect matchings of the same pole.

If the symmetric difference of \(P_i^0\) and \(P_i^1\) has several proper
alternating-cycle components, simultaneous toggling of both matchings on
any chosen subset of those components preserves their incidence sum.  This
gives the corresponding local cube of transported pairs, but it does not
identify bases chosen in different rows.

## Exact remaining boundary

Applying the theorem to all five rows of (1) gives five nonempty, genuine
relations \(\Theta_i\), one for each disjoint \(D_5\) cell.  It does **not**
give a common section of four such relations.  The witnesses from distinct
rows may use different matchings in every shared singleton class and may
come from different half-loads.  Consequently the missing implication is
still

\[
\text{five row transports}\quad\Longrightarrow\quad
\text{a four-cell common singleton tuple},
\tag{8}
\]

which would yield the forbidden \(A=(12345)\) cover by the four-cell
intersection lemma.  Relations (5) and alternating-cycle closure alone do
not prove (8), and no real exact-Case-XII pole violating (8) is known.

The exploratory derivation is preserved in
scratch/worker-bf-d5-analytic-proof/a5-overlap-to-d5-three-coordinate-transport.md.
