> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two path quotients exclude their shore-mark pair at \(e\)

Use the two \(|U|=3,r=3\) marked path quotients P and Q of [Note 236](236-girth-five-leaves-four-marked-exterior-quotients-at-the-first-barrier.md). Their common unmarked exterior is
\[
w_0-u_1-w_1-u_2-w_2-u_3-w_3,
\qquad h_i=u_iC\quad(i=1,2,3),
\]
and the internal mark \(e\) lies in the odd shore \(C\). Each quotient has exactly two exterior \(W\)--\(C\) marks. Name them \(a,d\).

**Theorem.** Neither path quotient can have complete exact Case-XII support if \(a,d\) are the two neighbours of \(e\) in the allowed missing-pair pentagon. Both cyclic orders of the other two labels are excluded, independently of the size and matching relation of \(C\).

**Proof.** In a required actual \(S\)--\(T\) row let \(D\) be the \(S\)-half. It has no \(T\)-decomposition, since any such decomposition paired with the fixed \(T\)-half would be forbidden. [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) therefore saturates \(\mathcal R(D)\) to all of \(S\). Decompose it at state \(ea\):
\[
D=X+Y_a+Z_e,\qquad
\partial X=\{b,c,d\},\quad\partial Y_a=\{a\},\quad\partial Z_e=\{e\}.             \tag{1}
\]
By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the \(ea\)-triple \(X\) has no proper shore hit. The exterior matching of \(K\) after its \(a\)-endpoint is deleted is unique, since \(K\) is a tree. In \(X\triangle Y_a\), the path from terminal \(a\) must end at \(d\): \(ed\) is the only other allowed pair at \(e\).

**Type P.** Its marks are
\[
a:w_1-C,\quad d:w_3-C,\quad b:w_0-w_2,\quad c:w_0-w_3.
\]
The unique exterior of \(X\) is \(a:w_1,u_1w_0,u_2w_2,u_3w_3\). Starting at \(w_1\), \(Y_a\) cannot go to \(u_1\): following \(X\) reaches \(w_0\), where the path ends at \(b\) or \(c\). It therefore goes through \(u_2,w_2,u_3,w_3\) and ends at \(d:w_3\), since choosing \(b:w_2\) or \(c:w_3\) would end at a forbidden \(e\)-neighbour. Thus \(Y_a\) occupies \(w_2\) via \(u_3\) and \(w_3\) via \(d\). Its nonterminal marks \(b,c\) must consequently both select \(w_0\), impossible for one perfect matching.

**Type Q.** Its marks are
\[
a:w_0-C,\quad d:w_3-C,\quad b:w_0-w_2,\quad c:w_1-w_3.
\]
The unique exterior of \(X\) is \(a:w_0,u_1w_1,u_2w_2,u_3w_3\). Starting at \(w_0\), \(Y_a\) cannot take \(b:w_0\). It must follow the entire unmarked path through \(u_1,w_1,u_2,w_2,u_3,w_3\): at \(w_1\) choosing \(c\), at \(w_2\) choosing \(b\), or at \(w_3\) choosing \(c\) would end at a label other than \(d\). It ends through \(d:w_3\). But now both endpoints \(w_0,w_2\) of the nonterminal mark \(b\) are already occupied by that same singleton matching \(Y_a\), so \(t_b\) cannot be matched. This is again impossible.

Each case contradicts the existence of \(Y_a\), proving the theorem. \(\square\)

Together with [Note 235](235-the-claw-connector-excludes-the-two-endpoint-e-neighbours.md), this excludes the pair of exterior \(W\)--\(C\) marks as the two allowed neighbours of the internal mark \(e\) in **every** \(|U|=3,r=3\) tree exterior. It does not exclude other \(e\)-neighbour pairs, the \(r=2\) cycle--leaf exterior, or larger barriers.
