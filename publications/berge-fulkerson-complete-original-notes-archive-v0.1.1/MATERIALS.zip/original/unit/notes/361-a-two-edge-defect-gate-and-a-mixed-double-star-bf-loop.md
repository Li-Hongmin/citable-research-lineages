> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A two-edge defect gate for different shore matchings

Use the six-port shore and the \(K_{3,3}\) double-star notation of [Notes 358–360](360-k33-double-star-exact-case-xii-forces-distinct-zero-port-shore-matchings.md). The claims about a BF row below concern **two different complete zero-port shore matchings** \(Q_1,Q_2\). They require no bound on the order or cycle rank of the shore. The final construction is a real five-pole, but does not have exact Case-XII support.

## Four-colour distance along a complement component

Let \(Q_1,Q_2\) be the restrictions of the two zero-port triple occurrences in any genuine BF row of type \((ej)(ek)\). Name its four singleton occurrences by a set \(I\) of four colours. For every shore port \(p\), let \(A_p\in\binom I2\) be the two singleton colours using that port. Put
\[
 d(A,B)=|A\setminus B|\in\{0,1,2\},\qquad \bar A=I\setminus A.
\]

**Defect-distance lemma.** Let \(P\) be a port-to-port path of \(Z-Q_1\), of length \(\ell\) including both port semiedges, and put \(m=|Q_2\cap E(P)|\). Then
\[
                 d\bigl(A_q,\operatorname{comp}^{\ell-1}(A_p)\bigr)\le m,       \tag{1}
\]
where \(\operatorname{comp}(A)=I\setminus A\). The reference set is \(A_p\) when \(\ell\) is odd and \(\bar A_p\) when \(\ell\) is even. If \(C\) is an odd closed component of \(Z-Q_1\), then
\[
                            |Q_2\cap E(C)|\ge2.                            \tag{2}
\]
In particular, a complementary pair of port colour sets on an odd path requires at least **two** \(Q_2\)-edges on that path. A triangle component of \(Z-Q_1\) cannot occur when \(Q_1\) is used in such a row.

**Proof.** An edge of \(Z-Q_1\) outside \(Q_2\) has load two from the four singletons and thus carries a two-set of colours. At a vertex where \(Q_1=Q_2\), the two incident complement edges carry complementary two-sets. Every \(Q_2\)-edge on \(P\) joins two consecutive path vertices, and these selected edges are disjoint because \(Q_2\) is a matching. Such an edge has one singleton colour \(c\). At its endpoints, the neighbouring two-loaded path edges have colour sets
\[
                   I\setminus\{c,d_v\},\qquad I\setminus\{c,d_w\},
\]
where \(d_v,d_w\) are the singleton colours on the incident \(Q_1\)-edges. Their distance is at most one. Traversing a selected \(Q_2\)-edge therefore replaces the two ordinary complement operations at its endpoints, whose net effect would be the identity, by a change of distance at most one. Complementation is an isometry for \(d\). The triangle inequality along \(P\) proves (1).

For an odd closed component, start on an edge outside \(Q_2\), which exists because \(Q_2\) is a matching. Without defects, one circuit would send its two-set \(A\) to \(\bar A\), at distance two from \(A\). Each selected \(Q_2\)-edge changes this by distance at most one. Returning to \(A\) consequently requires at least two such edges. A triangle has room for at most one. \(\square\)

**Double-star consequence under exact Case XII.** Suppose \(Q_1\) has no odd closed complement component. [Note 360](360-k33-double-star-exact-case-xii-forces-distinct-zero-port-shore-matchings.md) then forces its three shore paths \(ep_0,p_1p_2,p_3p_4\) all to be odd. Let \(x,y\) be the roots of the two triple occurrences. The following lower bounds are necessary for their row:

| roots \(x,y\) | \(Q_2\)-edges on the \(Q_1\) path \(p_1p_2\) | \(Q_2\)-edges on the \(Q_1\) path \(p_3p_4\) |
|---|---:|---:|
| both on the \(r\)-side | — | at least 2 |
| both on the \(l\)-side | at least 2 | — |
| one on each side | at least 1 | at least 1 |

For both roots on the \(r\)-side, the two triple matchings saturate \(bu_0\), \(u_3l_1\), and \(u_4l_2\). The singleton colour sets on \(bu_3\) and \(bu_4\) partition \(I\), so \(A_3=\bar A_4\); (1) on the odd \(p_3p_4\) path gives the first bound. The \(l\)-side is symmetric. For opposite roots, take the on-path branch port \(p_i\) and off-path branch port \(p_{i'}\) at \(a\). The singleton colour on \(au_i\) belongs to \(A_{i'}\setminus A_i\): it must avoid the two port colours at \(u_i\), while at \(a\) it complements the two colours on \(au_{i'}\). Thus \(A_i\ne A_{i'}\), and (1) requires at least one \(Q_2\)-edge on the odd \(p_1p_2\) path. The same argument at \(b\) gives the other bound. If \(Q_2\) also has no odd closed complement, the table applies again with \(Q_1,Q_2\) interchanged. If either matching has odd closed complement components, (2) applies to **each** such component.

This strengthens the mere intersection requirement: a local alternating-cycle change that touches a required same-side leaf path in only one \(Q_2\)-edge still cannot synchronize that row.
Because the selected \(Q_2\)-edges on a shore path are disjoint and avoid its port semiedges, a same-side row also requires the relevant odd leaf-pair path to have length at least five. In particular, a length-three leaf-pair path excludes that same-side root placement, regardless of the shore's other cycles.

**Tait-empty consequence.** A genuine exact-Case-XII pole with this double-star exterior has no 3-edge-colouring. Indeed, a Tait colouring at any state \(q\) doubles to the BF loop \([q]\), so \(q\) lies on the allowed pentagon \(S\). The Kempe switches in the **proof** of [Máčajová–Mazzuoccolo–Tabarelli, Lemma 4.3](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) produce Tait colourings at the two \(S\)-edges neighbouring \(q\): each is the only allowed state sharing one of \(q\)'s two terminal labels. Iterating around \(S\) yields a Tait colouring at one of its two \(e\)-incident states \(ej\). Doubling that colouring gives a \([ej]\) row with two identical zero-port shore matchings, contradicting Note 360. This conclusion uses complete exact support and the published Kempe lemma; it does not rely on the defect-distance bound.

For a **loop** \([ej]\) whose two triples have the *same* root \(r_i\), the marked-square exterior strengthens the bound. Name its singleton colours \(A,B\) at terminal \(e\) and \(C,D\) at terminal \(j\), so \(A_e=\{A,B\}\). The two triple occurrences saturate \(t_jr_i\), while both \(C,D\) saturate \(s_j\); hence \(t_jl_h\) carries the pair \(\{A,B\}\). Along the other three marked edges, the successive residual two-sets complement at each marked subdivision vertex and opposite leaf, forcing \(r_it_{j_r}\) also to carry \(\{A,B\}\). Thus \(r_iu_i\) carries \(\{C,D\}\), and the port at \(u_i\) has \(A_i=A_e\). At the centre \(a\), the residual pairs on \(au_0,au_{i'}\) are complementary; hence \(A_0=\bar A_{i'}\). Put \(m_0,m_a,m_b\) for the numbers of \(Q_2\)-edges on the three \(Q_1\)-paths \(ep_0,p_1p_2,p_3p_4\). Equation (1) gives
\[
 m_0+m_a\ge d(A_e,A_0)+d(A_i,A_{i'})
            =d(A_e,A_0)+d(A_e,\bar A_0)=2,
 \qquad m_b\ge2.                                                  \tag{3}
\]
Thus \(Q_2\) uses at least **four** edges of the three odd \(Q_1\)-paths, and \(|Q_1\triangle Q_2|\ge8\). For a same-root \(l_h\) loop the symmetric inequalities are \(m_0+m_b\ge2\) and \(m_a\ge2\). This four-edge conclusion is conditional on \(Q_1\)'s no-odd-cycle signature from Note 360; an odd closed component instead obeys (2).

## Opposite-root loops force a neighbouring row

**Exterior-switch theorem.** In the double-star, every genuine BF loop \([ej]\) whose two triple occurrences are rooted at opposite ends of \(j=r_i l_h\) also produces a genuine row
\[
                              (ej_r)(ej_l),                             \tag{4}
\]
where \(j_r=r_i l_{h'}\) and \(j_l=r_{i'}l_h\) are the two marks adjacent to \(j\) in the marked \(K_{2,2}\) square. Both complete shore matchings of the triples remain unchanged. This holds at every shore order and rank, with no assumption on their complement cycles.

**Proof.** Label the two singleton-\(e\) occurrences \(A,B\) and the two singleton-\(j\) occurrences \(C,D\), so \(I=\{A,B,C,D\}\). At \(t_j\), the two triples use opposite marked halves while \(C,D\) use the terminal semiedge. The remaining singleton colours on those halves are therefore \(A,B\); take \(A\) on \(t_jr_i\) and \(B\) on \(t_jl_h\). Let \(y\) be the singleton colour on the tree edge \(r_iu_i\), and \(z\) the singleton colour on \(l_hu_{2+h}\). The two-set on \(r_it_{j_r}\) is \(I\setminus\{A,y\}\), while that on \(t_{j_l}l_h\) is \(I\setminus\{B,z\}\).

Follow the six marked half-edges along
\[
          r_i-t_{j_r}-l_{h'}-t_{j_o}-r_{i'}-t_{j_l}-l_h,
          \qquad j_o=r_{i'}l_{h'}.                                      \tag{5}
\]
At its three marked subdivision vertices both triples use terminal semiedges. At its two middle leaves both triples use the tree edge. Consequently, the singleton two-sets on consecutive half-edges are complementary at all five intermediate vertices. The last two-set in (5) is therefore the complement of the first:
\[
                 I\setminus\{B,z\}=\{A,y\}.                           \tag{6}
\]
Because \(A\ne B\), equation (6) forces \(\{y,z\}=\{C,D\}\), with \(y\ne z\). At \(r_i\), the singleton-\(j\) colour other than \(y\) uses \(r_it_{j_r}\); at \(l_h\), the singleton-\(j\) colour other than \(z\) uses \(l_ht_{j_l}\). These are **different** occurrences. Pair the first with the triple rooted at \(r_i\), and the second with the triple rooted at \(l_h\). Their respective alternating terminal paths are
\[
 s_j,\ t_jr_i,\ r_it_{j_r},\ s_{j_r}
 \qquad\text{and}\qquad
 s_j,\ t_jl_h,\ l_ht_{j_l},\ s_{j_l}.                       \tag{7}
\]
Switch them successively. They change the triple states to \(ej_r,ej_l\), and the singleton boundaries to \(j_r,j_l\); all six edge loads and both triple shore restrictions stay fixed. This proves (4). \(\square\)

For exact Case XII, if \(ej_r,ej_l\in T\), the resulting \(T\)--\(T\) row is forbidden. Thus the required \([ej]\) loop cannot use opposite roots. In particular, when the two \(e\)-incident states of \(T\) are a **diagonal pair** of the marked square, each of the two required \(e\)-incident \(S\)-loops must use same-side roots. Note 360 still requires their two shore matchings to differ; if one has the odd-path signature, (3) strengthens this to \(|Q_1\triangle Q_2|\ge8\) for that loop.

## A real mixed row attaining the opposite-root bound

Use exactly the 21-vertex girth-five five-pole of [Note 359, “A genuine \(K_{3,3}\) boundary”](359-two-root-parity-gate-and-k33-sharpness.md). Thus the shore is the cycle \(t_ez_0z_1z_2z_3z_4t_e\), the tree edges \(ab,ar_1,ar_2,bl_1,bl_2\) have subdivision vertices \(u_0,\ldots,u_4\), and the four marks \(r_i l_h\) have subdivision vertices \(t_{ih}\). Write \(s_e,s_{ih}\) for terminal semiedges and set
\[
 Q=\{z_0z_1,z_2z_3,z_4t_e\},\qquad
 Q'=\{t_ez_0,z_1z_2,z_3z_4\}.
\]
The following table specifies six **complete actual perfect matchings**. Each entry lists its shore edges, its remaining proper edges, and its terminal semiedges; \(u_iz_i\) are the five shore ports.

| matching | shore edges | exterior edges | terminals |
|---|---|---|---|
| \(P_{11,r_1,Q}\) | \(z_0z_1,z_2z_3,z_4t_e\) | \(r_1t_{11},au_1,bu_0,r_2u_2,l_1u_3,l_2u_4\) | \(s_{12},s_{21},s_{22}\) |
| \(P_{11,l_1,Q'}\) | \(t_ez_0,z_1z_2,z_3z_4\) | \(l_1t_{11},au_0,bu_3,r_1u_1,r_2u_2,l_2u_4\) | \(s_{12},s_{21},s_{22}\) |
| \(A_e\) | \(u_2z_2,u_3z_3,u_4z_4,z_0z_1\) | \(au_1,bu_0,r_1t_{11},r_2t_{22},l_1t_{21},l_2t_{12}\) | \(s_e\) |
| \(B_e\) | \(u_0z_0,u_1z_1,u_4z_4,z_2z_3\) | \(au_2,bu_3,r_1t_{12},r_2t_{21},l_1t_{11},l_2t_{22}\) | \(s_e\) |
| \(C_{11}\) | \(u_1z_1,u_2z_2,t_ez_0,z_3z_4\) | \(au_0,bu_4,r_1t_{12},r_2t_{21},l_1u_3,l_2t_{22}\) | \(s_{11}\) |
| \(D_{11}\) | \(u_0z_0,u_3z_3,z_1z_2,z_4t_e\) | \(au_2,bu_4,r_1u_1,r_2t_{22},l_1t_{21},l_2t_{12}\) | \(s_{11}\) |

Each row of the table meets every internal vertex exactly once. Each proper edge and each terminal semiedge occurs exactly twice across the six rows: for example the shore port colour sets are
\[
 A_{p_0}=\{B,D\},\quad A_{p_1}=\{B,C\},\quad
 A_{p_2}=\{A,C\},\quad A_{p_3}=\{A,D\},\quad
 A_{p_4}=\{A,B\},\quad A_e=\{A,B\}.
\]
Hence their sum is \(2\mathbf1\), a genuine BF loop \([e,11]\) whose two triple occurrences have **different** complete shore matchings and opposite roots.

The same certificate also gives a genuine **two-state** row. In \(P_{11,r_1,Q}\triangle C_{11}\), the terminal path
\[
                  s_{11},\ t_{11}r_1,\ r_1t_{12},\ s_{12}                 \tag{8}
\]
is an alternating component entirely outside the shore. Exchange the two matching colours along (8), leaving the other four occurrences untouched. The first triple now uses \(s_{11}\) and \(r_1t_{12}\) in place of \(r_1t_{11}\) and \(s_{12}\), so its state is \(e12\); the switched singleton has boundary \(12\). The other triple retains state \(e11\) and shore restriction \(Q'\). The result is a real \((e12)(e11)\) row with shore restrictions \(Q,Q'\). If terminal labels are placed so that \(e11\in S\) and \(e12\in T\), this row has one of the required Case-XII \(S\)--\(T\) **boundary types**, although the pole's full support is not exact Case XII.

In the displayed 21-vertex row, \(C_{11}\) uses \(r_1t_{12}\) and \(D_{11}\) uses \(l_1t_{21}\). Switching both paths gives an actual \((e12)(e21)\) row. For the pentagon \(S=e-11-12-21-22-e\), the original \([e11]\) loop and the first \((e12)(e11)\) row have allowed Case-XII types, but \(e12,e21\in T\), so this last row is forbidden by Appendix XII. The pole therefore fails exact support by a visible complete-matching closure, independently of its order bound.

The \(Q\)-triple has the odd complementary five-cycle \(b-u_3-z_3-z_4-u_4-b\); by Note 359 its zero-port shore mask blocks all eight rooted \(ej\)-Tait completions. The \(Q'\)-triple is Tait-compatible by the explicit complement path in Note 359. Thus even a Tait-blocked triple can participate in a genuine BF loop or two-state row by synchronizing with a different shore matching. On each of the odd \(Q\)-complement paths \(p_1p_2,p_3p_4\), \(Q'\) has exactly one edge, attaining the opposite-root bound above. The construction is not exact Case XII: its order is 21, below [Note 226's order-33 lower bound](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md).

The remaining exact-Case-XII question is whether a Tait-empty shore can realize **all** required rows while meeting the defect bounds and the opposite-root switch restriction. No existence or exclusion of a full exact-Case-XII pole follows from this note. The derivation and displayed certificate were checked by hand, without a separate independent proof review.
