> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A tree--\(R^*\) shore in \(I_m\) forces one minority-port placement

Work in the genuine \(I_m\) quotient of
[Note 210](210-two-star-rectangles-restrict-the-rstar-im-connector.md).
Let \(A^\circ\) be a three-vertex tree with centre port \(u_1\)
and end-port groups
\[
                 \{u_2,z\}\mid\{x,p\}.                      \tag{1}
\]
Let \(B^\circ\) have the complete actual Figure-7 Case-XIII
\(R^*\) relation, with ports \(\{u_1,u_2,z,y,q\}\).
If the resulting outer five-pole has exact Case-XII BF support,
then its \(R^*\) port-state colours satisfy
\[
\boxed{c_B(yu_2)=c_B(yz)=c_B(yq)\ne c_B(yu_1).}         \tag{2}
\]
In the published port labels this means, respectively,
\[
       (y,u_1)=(2,4)\quad\text{or}\quad(y,u_1)=(4,3).        \tag{3}
\]
The conclusion is a necessary relative-port placement.  It does
not assert that either placement extends to an exact-Case-XII graph.

Every pair of the four cross states
\(u_2x,u_2p,zx,zp\) is an actual BF type of the tree pole:
the two relevant three-edge-colouring halves of the path may be
combined into a six-matching row.  Put \(R_i=u_iw_i\), and let
\(D_x,D_y,D_p,D_q\) denote the singleton-side halves of the
four marked edges.  As usual, two-digit strings denote matching
slot sets.

## Three genuine rows

First suppose \((yz)(yq)\) is an actual BF type of \(B^\circ\).
Use the tree type \((zx)(zp)\).  Put its triple boundaries
missing \(zx,zp\) in slots \(1,2\), its singleton \(x,p\)
in \(3,4\), and \(z,z\) in \(5,6\).  Put \(B\)'s singleton
\(z,q\) in \(1,2\), its triples missing \(yz,yq\) in
\(3,4\), and \(y,y\) in \(5,6\).  The shore-half labels are
\[
\begin{array}{c|cccc}
 &u_1&u_2&z&x/p\text{ or }y/q\\\hline
A&12&12&56&23/14\\
B&34&34&14&56/23
\end{array}
\]
where the last column gives \(A:x/p\) and \(B:y/q\).
The connector choice
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)
                   =(56,56;14,23,23,14)                     \tag{4}
\]
partitions the six slots at both \(u_i,w_i\) and every mark.
Its outer terminal labels are
\((T_z,T_x,T_y,T_p,T_q)=(23,56,14,56,56)\).
Thus slots \(5,6\) give the actual loop \([zy]\).

Next suppose \((yu_2)(yq)\) is actual on \(B^\circ\).
Use the tree type \((u_2x)(u_2p)\), placing its two triples
in \(1,2\), singleton \(x,p\) in \(3,4\), and \(u_2,u_2\)
in \(5,6\).  Two independent relabellings of the same actual
\(B\)-type give the following connector rows:
\[
\begin{array}{c|cc|cccc|ccccc|c}
B_{12}&R_1&R_2&D_x&D_y&D_p&D_q&T_z&T_x&T_y&T_p&T_q
 &\text{outer loop}\\\hline
(u_2,q)&56&23&14&23&56&14&56&56&14&23&56&[py]\\
(q,u_2)&56&14&14&23&23&56&56&56&14&56&23&[yq]
\end{array}.                                                   \tag{5}
\]
In the first row put \(B\)'s triples missing \(yu_2,yq\)
in slots \(3,4\); in the second row reverse that order.
Both rows use \(y,y\) in slots \(5,6\).  The \(A/B\) labels
at the direct \(z\)-mark are \(12/34\), so \(T_z=56\).
At \(u_1\) they are also \(12/34\), giving \(R_1=56\);
at \(u_2\) they are \(56/14\) or \(56/23\), giving the
displayed \(R_2\).  The four \(D\)-labels then partition
\([6]\) at \(w_1,w_2\) and with each shore-half label at
its mark.  Each input is a genuine six-matching BF row, so
the glued rows have load two on every proper edge.  This proves
both loops in (5).

## The five-cycle degree bound

Write \(a=c_B(yu_2)\), \(b=c_B(yz)\),
\(d=c_B(yq)\).  A cross-colour pair is an actual \(R^*\)
BF type.  If \(a\ne b\), the star rectangle
[Note 212, (2)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
applied separately at tree ports \(x,p\) forces both
\([xy]\) and \([py]\): each tree port has the two leaves
\(u_2,z\).  Since \(a,b,d\) are binary, either
\(b\ne d\) or \(a\ne d\).  In the first case (4) also
forces \([zy]\), and in the second (5) forces \([yq]\).
Either way \(y\) has at least three distinct BF-loop neighbours,
impossible in the allowed Case-XII five-cycle.  Hence \(a=b\).

If \(a=b\ne d\), both (4) and (5) apply and force
\([zy],[py],[yq]\), again three edges at \(y\).  Thus
\(a=b=d\).  Every Figure-7 \(R^*\) port sees both
\(P/Q\) blocks among its four incident states; therefore
\(c_B(yu_1)\) has the opposite colour.  The only \(1+3\)
ports in Figure 7 are \(2\), whose minority \(P\)-edge is
\(24\), and \(4\), whose minority \(Q\)-edge is \(43\).
This proves (2)--(3).

The opposite tree end partition \(\{u_2,x\}\mid\{z,p\}\),
the mirror centre \(u_2\), other possible \(R^*\) port orders,
and the full exact-Case-XII closure remain open.  This is an
all-orders necessary condition on genuine shore relations, not a
realization.  The analytic proof awaits an independent check.

[Note 217](217-the-first-tree-rstar-im-end-partition-is-impossible.md)
subsequently excludes both placements in (3) by further genuine
six-slot transports, closing this end partition.  The necessary
colour statement (2) remains part of that proof.
