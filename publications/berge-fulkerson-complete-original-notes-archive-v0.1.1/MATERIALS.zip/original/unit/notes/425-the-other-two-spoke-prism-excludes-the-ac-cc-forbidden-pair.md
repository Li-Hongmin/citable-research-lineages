> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other two-spoke prism excludes the \(AC,Cc\) forbidden pair

Keep the marked prism tree of [Note 424](424-the-other-two-spoke-prism-excludes-the-ac-ab-forbidden-pair.md):
\[
(u_1,\ldots,u_5)=(AB,BC,Aa,Bb,bc),\qquad
(X,Y,Z,W)=(AC,Cc,ac,ab).
\]
The shore has ports \(e,p_1,\ldots,p_5\) and arbitrary size. Suppose exact Case-XII support has forbidden \(e\)-labels \(\{X,Y\}\). The possible allowed pentagons are
\[
S_1=e-Z-X-Y-W-e,\qquad S_2=e-Z-Y-X-W-e.               \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eY)(eW)\) and excludes all \(T\)--\(T\) cells.

> **Pair exclusion.** Neither pentagon in (1) can be the complete BF boundary support of a pole with this marked tree and any shore.

Suppose a required row exists. Let its forbidden triple be \(P=eY\), allowed triple \(R=eW\), singleton occurrences \(K=W,J=Y\), and two singleton-\(e\) occurrences \(D_0,D_1\). Since \(P\in T\) stays unchanged, the \(W\)-starting path of \(R\triangle K\) must end at \(Z\): its other possible terminal endpoints \(X,Y\) would change \(R\) to a second forbidden triple. Both roots \(C,c\) of \(P=eY\) take \(au_3\).

Each such triple has zero exterior ports, whereas a singleton-\(e\) matching has exactly three. Whenever two marked terminal arms of their symmetric difference end at distinct ports, the third arm ends at the remaining port; there is no exterior port-to-port detour. The shore \(e\)-path therefore selects a fixed port when the triple's complete shore matching is unchanged.

The \(W\)-starting path of \(R\triangle K\) is wholly exterior: it leaves the \(W\) subdivision on \(R\)'s rooted half-edge, then arrives at every tree subdivision on a \(K\)-edge and leaves on \(R\)'s other prism-vertex half-edge. Since \(R\) has no exterior port, this path cannot enter the shore before ending at another marked terminal.

**The \(a\)-root of \(R=eW\) is impossible.** Its tree slots are \((B,C,A,b,c)\). From \(W-t_W-a\), \(K\) may take \(Z:a\) directly. Otherwise it follows \(au_3,A,Au_1,B\); \(X:A\) is forbidden. The \(Bu_2\) branch reaches forbidden \(X\) or \(Y\). The \(Bu_4\) branch reaches \(b\); \(W:b\) is unavailable to the singleton-\(W\) matching, so it follows \(bu_5,c\) and could end at allowed \(Z:c\). But then \(K\) occupies \(A\) through \(Au_1\) and \(c\) through \(Z:c\), forcing both the \(X=AC\) and \(Y=Cc\) subdivisions to use their common endpoint \(C\). Thus only the direct \(W-t_W-a-t_Z-Z\) path is possible.

Both \(P\) and \(R\) take \(au_3\). On that direct path \(K:Z:a\), so \(P,R,K\) use the three edges \(au_3,W:a,Z:a\) at \(a\) once each. Among \(J,D_0,D_1\), some singleton-\(e\) occurrence \(D\) uses \(W:a\) or \(Z:a\). Switch the direct path to \(R'=eZ:a\), retaining the complete shore mask of \(R\). In \(R\triangle D\) and \(R'\triangle D\), the exterior \(X,Y\) terminal components remain unchanged; only the \(W/Z\) arm is relabelled. If \(X,Y\) join wholly outside the shore, the prescribed \(e\)-switch is already impossible. Otherwise they exit at distinct ports, but the shore \(e\)-path first reaches the same port against \(R,R'\). Under \(S_1\) it must select \(Y\) then \(X\); under \(S_2\), \(X\) then \(Y\). Both contradict the fixed exit. Hence \(R\) is rooted at \(b\).

**The \(b\)-root has one \(W\to Z\) route.** Its tree slots are \((A,C,a,B,c)\). If \(K\) takes \(bu_5\), the path reaches \(c\), where \(Z:c\) is the only allowed endpoint. Then \(K\) cannot take \(Z:a\) or the \(W\) half at \(a\), so it must take \(au_3\); but \(P,R\) already saturate that edge. Thus \(K:bu_4\) and reaches \(B\). The \(Bu_2\) branch reaches forbidden \(X,Y\). The \(Bu_1\) branch reaches \(A\); \(X:A\) is forbidden, so it follows \(Au_3,a\) and ends at \(Z:a\). Its remaining marked and tree slots are forced:
\[
K:\quad W\text{ terminal},\quad X:C,\quad Y:c,\quad Z:a,
\quad Bu_1,\ Au_3,\ bu_4,\quad p_2,p_5.               \tag{2}
\]
Switching this wholly exterior path gives \(R'=eZ:a\), rooted at \(a\), with the same complete shore mask as \(R\). Its tree slots are \((B,C,A,b,c)\); both \(R,R'\) take \(cu_5\).

**Root \(P=eY:C\).** Here \(P:Y:C\), while \(R,J\) take the \(Y\) terminal and \(K:Y:c\). Thus one \(e\)-singleton \(D\) takes \(Y:c\). The \(Z\) subdivision has its terminal occupied by \(P,R\) and its \(a\)-half by \(K\), so \(D:Z:a\). It then takes \(W:b\). Both ends of the tree edge \(bc\) are already covered in \(D\), so \(D\) has port \(p_5\). Against both \(R=eW\) and \(R'=eZ\), the exterior \(Y\)-terminal arm is
\[
Y-t_Y-c-u_5-p_5.                                      \tag{3}
\]
The same shore \(e\)-path would have to use \(p_5\) in one comparison and another port in the other: \(S_1\) requires \(eW\to YW\) and \(eZ\to XZ\); \(S_2\) reverses the \(X/Y\) targets. Contradiction.

**Root \(P=eY:c\).** Now \(P,R\) both take \(Cu_2,Au_1,Bu_4,au_3\). They take the \(X\) terminal, while \(K:X:C\). Also \(P,K\) saturate \(Y:c\) and \(R,J\) take the \(Y\) terminal. The loads at \(C,X,Y\) give
\[
J:X:C,\qquad D_0,D_1:X:A,\ Y:C.                       \tag{4}
\]
Every \(D_i\) covers \(B\) by \(Bu_1\) or \(Bu_2\), because \(P,R\) saturate \(Bu_4\). As \(P,R\) also saturate \(au_3\), every \(D_i\) has port \(p_3\).

Under \(S_1\), choose a \(D=D_i\) that does not take \(bu_4\); such a choice exists because \(K\) already uses \(bu_4\), leaving at most one further slot for the two \(D_i\). The \(X\)-terminal arm of \(R'\triangle D\) is \(X-t_X-A-u_3-p_3\). The \(Y\)-arm of \(R\triangle D\) exits at \(p_2\) if \(D:Bu_1\), and at \(p_4\) if \(D:Bu_2\): in the latter case \(D\) cannot use either half of \(u_4\), so it takes port \(p_4\). But \(S_1\) requires the same shore \(e\)-path to end at \(Y\) against \(R=eW\) and at \(X\) against \(R'=eZ\). It cannot first exit at both \(p_2/p_4\) and \(p_3\).

Under \(S_2\), the \(X\)-arm of \(R\triangle D_i\) and the \(Y\)-arm of \(R'\triangle D_i\) must have the same shore exit for **each** \(i\). If \(D_i:Bu_1\), the latter arm exits at \(p_2\), whereas the former exits at \(p_4\) or, if \(D_i:bu_4\), continues through \(b,W,a,u_3\) to \(p_3\). Hence neither exit is \(p_2\). Therefore both \(D_i\) take \(Bu_2\). For either \(D=D_i\), the \(Y\)-terminal arm of \(R'\triangle D\) is then
\[
Y-t_Y-C-u_2-B-u_1-p_1.                               \tag{5}
\]
The exact-support \(e\)-path of \(R'=eZ\) must end at \(Y\); switch this complete path with \(D\), producing \(H=YZ\in S_2\). It has \(Y:C\), while the unchanged singleton \(J=Y\) has \(X:C\) and the \(Y\) terminal by (4). Consequently \(Y-t_Y-C-t_X-X\) is a wholly exterior path of \(H\triangle J\). Switching it gives \(XZ\in T_2\) beside unchanged \(P=eY\in T_2\), a forbidden double-\(T\) row.

All roots and both pentagons have been excluded. Together with Note 424, two forbidden \(e\)-pairs are now excluded for this **second** two-spoke tree. Four pairs remain here; other exterior profiles and the Berge–Fulkerson conjecture remain open. The proof is hand-derived with complete matching occurrences and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
