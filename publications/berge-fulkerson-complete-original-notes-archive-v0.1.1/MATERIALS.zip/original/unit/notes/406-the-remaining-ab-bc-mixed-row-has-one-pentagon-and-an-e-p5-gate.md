> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The remaining \((e\,ab)(e\,bc)\) prism row has one pentagon and an \(e\)--\(p_5\) gate

Use the two-spoke prism tree \((p_1,\ldots,p_5)=(AB,BC,Aa,Bb,ac)\) with marks \(AC,Cc,bc,ab\). Assume complete exact Case-XII BF support with forbidden \(e\)-labels \(ab,Cc\). Consider an actual required mixed row of type \((e\,ab)(e\,bc)\). [Note 404](404-a-direct-forbidden-prism-root-cannot-enter-any-mixed-e-row.md) excludes the direct \(e\,ab:a\) root, and [Note 405](405-the-indirect-ab-and-bc-b-prism-root-pair-is-impossible.md) excludes \(e\,bc:b\) when \(e\,ab\) has its remaining root \(b\). Hence the only possible triple roots are \(P:e\,ab:b\) and \(R:e\,bc:c\).

> **One-orientation necessary form.** If this remaining rooted row exists, its allowed pentagon is necessarily
> \[
> S_{Cc}=e-AC-Cc-ab-bc-e.                            \tag{1}
> \]
> The singleton-\(bc\) occurrence \(K\) has marked mask \((AC,Cc,bc,ab)=(A,C,s,b)\), the singleton-\(ab\) occurrence \(J\) takes \(bu_4,bc:c,Cc:C,AC:A,au_5\), and both singleton-\(e\) occurrences have marked mask \((C,c,b,a)\) and proper port \(p_5\). Each of their complete \(e\)-starting symmetric-difference paths against \(R\) must pair \(e\) with \(p_5\) on the shore. These are necessary conditions on a genuine BF row, not an existence certificate.

**Proof.** The rooted-tree masks of \(P,R\) are respectively \((A,C,a,B,c)\) and \((B,C,A,b,a)\). Let \(K\) be the singleton-\(bc\) occurrence. Its \(bc\)-starting path against \(R\) cannot end at \(ab\), which would give the forbidden \([e\,ab]\) loop, or at \(Cc\), which would give a double-\(T\) row. It must end at \(AC\). Tracing from \(bc\) forces \(K\) successively through \(cu_5,au_3\) to \(A\). If it passes through \(Au_1,Bu_2\) and reaches \(AC:C\), then \(K\) covers \(C\) and \(c\) at \(AC:C,cu_5\), leaving no way to cover the marked subdivision \(t_{Cc}\). The other branches off this route end at forbidden \(ab,Cc\). Thus the terminal path is wholly exterior and ends via \(AC:A\). Since \(P,R\) both use \(Cu_2\), \(K\) covers \(C\) through \(Cc:C\). It covers \(ab\)'s subdivision through \(ab:b\), because \(a\) is already covered by \(au_3\); this also covers \(b\). Therefore
\[
K: (AC,Cc,bc,ab)=(A,C,s,b),\quad
cu_5,au_3\in K,\quad
K\text{ covers }B\text{ by one of }Bu_1,Bu_2,Bu_4.       \tag{2}
\]
Switching \(R,K\) gives \(R':e\,AC:A\) with exactly the same complete shore matching as \(R\).

Let \(J\) be singleton-\(ab\), and \(D_0,D_1\) singleton-\(e\). The edges \(au_3\) in \(P,K\) are saturated, while \(R\) uses \(au_5\), so \(J\) must use \(au_5\). Since \(P,K\) saturate \(ab:b\), \(J\) covers \(b\) by \(bc:b\) or \(bu_4\).

If \(J\) takes \(bc:b\), it must also take \(Cc:c,AC:C\). The marked load equations then force one singleton-\(e\) occurrence \(E\) to have mask \((AC,Cc,bc,ab)=(A,C,c,a)\). It takes \(bu_4\) at \(b\), and its three proper ports are \(p_3,p_5\) and one of \(p_1,p_2\). Trace its exterior arms against \(R\) and the switched \(R'\). The \(Cc\)-arm in both comparisons ends at \(x=p_2\) if \(E\) uses \(Bu_1\), or \(x=p_1\) if it uses \(Bu_2\). The \(ab\)-arm against \(R\) ends at \(p_5\), and the \(ab\)-arm against \(R'\) ends at \(p_3\). In \(S_{ab}=e-AC-ab-Cc-bc-e\), the forbidden \(P\) requires the same shore \(e\)-path to end at \(x\) against \(R:e\,bc\) and at \(p_3\) against \(R':e\,AC\). In \(S_{Cc}\), it requires \(p_5\) against \(R\) and \(x\) against \(R'\). Since \(x\notin\{p_3,p_5\}\), both orientations are impossible. Thus \(J\) takes \(bu_4\).

Now \(J\) covers \(bc\)'s subdivision via \(bc:c\), \(C\) via \(Cc:C\), and \(A\) via \(AC:A\). The remaining marked loads force both \(D_0,D_1\) to use
\[
AC:C,\qquad Cc:c,\qquad bc:b,\qquad ab:a.           \tag{3}
\]
At \(u_5\), \(P,K\) take the \(c\)-half and \(R,J\) the \(a\)-half, so \(D_0,D_1\) both take port \(p_5\). At \(A\), the \(Au_1\) and \(Au_3\) slots left by \(P,R,K,J\) force one of \(D_0,D_1\) to take \(Au_3\). Call it \(D\). The table gives its two other relevant exterior arms, with the only possible \(B\)-choices:

| \(D\) at \(B\) | \(Cc\)-arm against \(R\) | \(ab\)-arm against \(R'\) |
|---|---|---|
| \(Bu_1\) | \(p_4\) | \(p_2\) |
| \(Bu_2\) | \(p_4\) | \(p_1\) |
| \(Bu_4\) | \(p_1\) | \(p_2\) |

For \(S_{ab}\), the \(e\)-path of \(R\triangle D\) must reach \(Cc\) and that of \(R'\triangle D\) must reach \(ab\). The table assigns them different proper ports, although the two shore paths coincide because \(R|_Z=R'|_Z\). Hence \(S_{ab}\) is impossible. In \(S_{Cc}\), the only allowed endpoint against \(R\) is \(ab\), and against \(R'\) it is \(Cc\). Both exterior arms are the same fixed \(p_5\)-arm in their respective comparisons: \(ab-t_{ab}-a-u_5-p_5\) for \(R\), and \(Cc-t_{Cc}-c-u_5-p_5\) for \(R'\). Thus each singleton-\(e\) occurrence must have shore \(e\)-path ending at \(p_5\). This proves all stated necessary conditions. \(\square\)

There is a further path-activity consequence. Let \(Q=P|_Z\), \(Q'=R|_Z\), and suppose \(Z-Q\) has an even complementary path from \(e\) to \(p_5\). If \(Q,Q'\) agreed at every vertex of that path, both zero-port triples would occupy the same matching edge there. [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) would then require the two singleton label sets at its ends to be complementary. Both ends instead carry \(\{D_0,D_1\}\) by (3), a contradiction. Thus \(Q\triangle Q'\) must touch that specific \(e\)--\(p_5\) path. This strengthens [Note 390's](390-mixed-prism-e-rows-require-a-port-active-zero-port-cycle.md) either-path activity gate for the sole surviving root and pentagon template.

There is a dual constraint on the other shore matching. If \(Z-Q'\) has an odd complementary path \(P_o\) from \(p_2\) to \(p_4\), then \(H-R\) contains the odd cycle \(B-u_2-P_o-u_4-B\). The other triple \(P:e\,ab:b\) occupies exactly one exterior edge of this cycle, \(Bu_4\); it occupies no port edge. The odd-cycle two-hit lemma of [Note 361, equation (2)](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md), applied with the two triples interchanged, therefore gives
\[
|Q\cap E(P_o)|+1\ge2.                                      \tag{4}
\]
Hence \(Q\) uses an internal edge of \(P_o\), and \(Q\triangle Q'\) touches this odd path too. In particular, when both zero-port shore matchings are clean and have [Note 387's exceptional signature](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md), their difference must affect the even \(e\)--\(p_5\) path of \(Z-Q\) and the odd \(p_2\)--\(p_4\) path of \(Z-Q'\). Neither activity condition by itself asserts a forbidden completion.

The remaining cell is sharply localized to two **indirect** triple roots and one pentagon orientation. This argument does not show that the required shore pairing is impossible; shore matchings with internal odd complementary cycles are not excluded here. The complete prism profile and Berge–Fulkerson conjecture remain open. The result is hand-derived and awaits independent review.
