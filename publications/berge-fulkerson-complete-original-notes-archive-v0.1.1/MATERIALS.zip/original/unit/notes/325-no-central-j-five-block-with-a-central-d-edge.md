> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No central-J five-block with a central D edge

Continue the genuine left and right exact-Case-XII rows in
the five-vertex Hall design of
[Note 321](321-five-vertex-zero-port-closure-forces-the-d-edge-and-hj-pair.md).
Take \(\ell=u\), \(j=x\), \(H\) based at \(f\), and
\(Q\in\{A,I\}\) based at \(b\). Reflection of the
incidence design exchanges this with the \(H=b\)
placement. Note 321's full zero-port phase closure supplies
both actual \((g,t_{ew})\) matchings
\[
\begin{aligned}
X_1&:\quad ud_D,bo,fp,ax,cz,
                    \quad y\text{ uses its third edge},\\
X_2&:\quad ud_D,bz,ao,fp,cx,
                    \quad y\text{ uses its third edge}.
\end{aligned}                                                   \tag{1}
\]
Their complement pairing is \(EA\mid ID\mid HJ\).
Every actual \(HJ,g,t_{ew}\) shore matching has complement
pairing \(EI\mid AD\) by [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md).

**Theorem.** No \(HJ,g,t_{ew}\) matching exists in this
placement, for either value of \(Q\). Hence the genuine
left row excludes all five-vertex \((\alpha,\eta)=(2,1)\)
Hall designs with \(\ell=u\). Combined with
[Note 322](322-the-remaining-f-based-five-block-fixes-the-left-hj-phase.md),
[Note 323](323-no-u-based-five-block-in-the-right-dj-branch.md), and
[Note 324](324-no-side-j-five-block-with-a-central-d-edge.md),
and reflection, the only placement of this five-vertex
design not yet excluded is
\[
       \ell=b,\quad j=z,\quad H=f,\quad Q=I,
       \qquad\text{or its reflection}.                       \tag{2}
\]
This is a necessary incidence placement, not an exact-Case-XII
realization.

**Proof.** A purported \(HJ\) matching \(L\) selects
\(H\) at \(f\) and \(J\) at \(x\). In particular it
cannot select \(ax\) or \(cx\). If it avoids \(ud_D\),
the four remaining vertices \(u,a,b,c\) match
\(o,p,y,z\) in exactly two ways:
\[
\begin{aligned}
L_0&:\quad Hf,Jx,uo,ay,bz,cp,\\
L_1&:\quad Hf,Jx,up,ay,bo,cz.
\end{aligned}                                                   \tag{3}
\]
Their difference is the complete alternating six-cycle
\(u-o-b-z-c-p-u\), so actual matching closure realizes
\(L_0\) from either phase. The complete \(H\)--\(J\)
component of \(L_0\triangle X_2\) is
\[
                         H-f-p-c-x-J.                         \tag{4}
\]
Switching (4) in \(L_0\) yields an actual zero-port
\((g,t_{ew})\) matching with selected block edges
\(\{uo,ay,bz,fp,cx\}\), avoiding \(ud_D\).
Note 321 forbids every such zero-port matching. Thus neither
phase in (3) occurs.

If \(L\) selects \(ud_D\), the mandatory \(o,p\)
matches leave precisely two local phases:
\[
\begin{aligned}
L_2&:\quad Hf,Jx,ud_D,ay,bo,cp,
                    \quad z\text{ uses its third edge},\\
L_3&:\quad Hf,Jx,ud_D,ao,bz,cp,
                    \quad y\text{ uses its third edge}.
\end{aligned}                                                   \tag{5}
\]
For \(L_2\), the complete \(H\)--\(J\) component of
\(L_2\triangle X_2\) is again (4). Switching it in
\(L_2\) yields a zero-port matching with local phase
\(ud_D,bo,fp,ay,cx\) and third edge at \(z\).
But Note 321 requires the third-edge position \(y\)
when \((\ell,j,H)=(u,x,f)\). Thus \(L_2\) is impossible.

For \(L_3\), the complete \(H\)--\(J\) component of
\(L_3\triangle X_1\) is
\[
                       H-f-p-c-z-b-o-a-x-J.                \tag{6}
\]
Switching it in \(L_3\) produces an actual zero-port
matching \(N\) with local phase \(X_1\), leaving every
shore edge outside (6) unchanged, including
\(ud_D\), the third edge at \(y\), and \(g,t_{ew}\).
In the complement of \(L_3\), the \(Q\)-path reaches
the unselected third edge at \(z\) through
\[
                    Q-b-o-u-p-f-y-a-x-c-z.                  \tag{7}
\]
In the complement of \(N\), it reaches that same
edge through \(Q-b-z\). Its remaining shore continuation
is identical in both matchings. If \(Q=A\), Note 301
requires that continuation to end at \(D\) for \(L_3\),
while Note 321 requires \(E\) for \(N\). If \(Q=I\),
the required ends are \(E,D\), respectively. This
excludes \(L_3\) and completes the proof. \(\square\)

The surviving placement (2), the other six-cut allocation
\((\alpha,\eta)=(1,2)\), larger Hall blocks, incidence
collisions, other shore profiles, and Berge–Fulkerson remain
open. The proof uses hand-derived matching phases and
complete-fibre complement restrictions; it has not had an
independent second-source check. No local computation or
OMEN run was used.
