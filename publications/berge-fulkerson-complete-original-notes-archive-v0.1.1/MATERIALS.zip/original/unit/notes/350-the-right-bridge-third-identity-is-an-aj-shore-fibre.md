> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right bridge's third identity is an \(AJ\) shore fibre

> **Scope correction:** [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) excludes the right no-bridge row from which this particular six-cycle-switched fibre was constructed. The fibre calculation below is conditional; it is not an open exact-Case-XII realization branch.

Use the genuine right \((ea)(eb)\) row obtained by the exterior six-cycle switch in [Note 347](347-a-right-eb-row-forces-a-c-bridge-after-one-exterior-switch.md). Before the switch, its two singleton-\(e\) exterior masks were IV \(a:\Sigma,1A,2C\) and III \(a:\Sigma,2B,3C\); after the switch, write
\[
             X_{ea}+Y_R+Z'_e+U_A+V_e+W'_b=2\mathbf1,      \tag{1}
\]
where \(Z'\) has III \(a:\Sigma,1B,2C\), \(V\) has III \(a:\Sigma,2B,3C\), and \(W'\) is given by Note 347, (5). Keep an arbitrary zero-port phase \(X_C,U_C\) of (1). By [Note 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md), the \(e\)-path \(L_C\) of \(U_C\triangle Z'\) ends at \(c\).

For each phase, let \(\mathscr A_C\) consist of the complete singleton-\(c\) matchings obtained by switching \(L_C\) from \(Z'\), optionally together with closed components of \(U_C\triangle Z'\). These are exactly the fixed-\(W'_b\) \(bc\)-state candidates of [Note 344](344-a-fixed-singleton-load-has-an-exact-two-state-fibre.md). Put \(P_C=X_C+Y_R+Z'\), a pure \(S\) half-load with unit exterior vector.

**Fixed-fibre theorem.** Every \(C_c\in\mathscr A_C\) has shore port set \(\{A,J\}\) and the same exterior mask
\[
 C_c|_{\rm ext}=\{a:\Sigma,b:A,d:E,1B,2C,3D,h_4;\ c\}. \tag{2}
\]
Whenever \(C_c\le P_C\), the residual \(P_C-C_c\) has no exterior closed component. Its four exterior terminal arms end at the shore ports as follows:
\[
\begin{array}{c|c|l}
\text{terminal}&\text{shore port}&\text{exterior proper edges}\hline
e&E&\text{none}\\
a&H&a:C,3C,h_3\\
b&I&b:D,4D,4E,c:E,c:A,1A,h_1\\
d&D&d:B,2B,h_2.
\end{array}                                                  \tag{3}
\]
Consequently this right-bridge phase synchronizes the third singleton identity across the \((ea)(bc)\) and \((dc)(eb)\) rows **if and only if** some \(C_c\in\mathscr A_C\) is contained edgewise in \(P_C\) and every *shore-internal* closed component of \(P_C-C_c\) is even. In that event the two shore residual terminal paths necessarily pair \(E\) with \(D\) and \(H\) with \(I\); the complete residual has the even \(e\)--\(d\) and odd \(a\)--\(b\) paths of [Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md).

**Proof.** The complete exterior difference \(U_A\triangle Z'\) has three terminal-to-shore arms: \(a\to A\), \(d\to J\), and
\[
 c\to t_c\xrightarrow{c:A}A_{\rm ext}
 \xrightarrow{b:A}t_b\xrightarrow{b:D}D_{\rm ext}
 \xrightarrow{3D}u_3\xrightarrow{h_3}H .                \tag{4}
\]
The fourth arm is \(e\to E\). Note 346 forces the shore part of \(L_C\) to join \(E,H\); the other shore path joins \(A,J\). Switching \(L_C\) removes the \(E,H\) ports of \(Z'\) and keeps \(A,J\). On (4) it replaces the \(Z'\)-edges \(c:A,b:D,h_3\) with the \(U\)-edges \(c,b:A,3D\); every other exterior edge of \(Z'\) remains. This gives (2). All closed components of \(U_C\triangle Z'\) are shore-internal because (4) and the other three arms exhaust the exterior difference, so optional switches cannot change (2).

The pure load \(P_C\) is unit on every exterior edge and shore port, by Note 347. Subtracting (2) therefore leaves exactly the four exterior paths in (3), with no exterior closed component. The same four arms persist for every closed-component phase of \(C_c\). By the corrected [third-identity criterion in Note 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md), a candidate works exactly when it is contained in \(P_C\) and its residual has only even closed components; here all such components are inside the shore. If it works, Note 349 pairs \(d,e\) and \(a,b\), which, by (3), means shore pairings \(D,E\) and \(H,I\). \(\square\)

The theorem identifies one concrete \(AJ\) perfect-matching fibre in the *actual* six-port shore. It does not assert that the fibre contains an owner-safe candidate with even residual cycles, nor that a successful third identity avoids [Note 344's triple-hit obstruction](344-a-fixed-singleton-load-has-an-exact-two-state-fibre.md). No exact-Case-XII pole or BF cover follows from this conditional reduction.

The exterior mask (2) already appeared as an independently glueable singleton-\(c\) mask in [Note 298, (4)](298-the-right-central-ad-row-forces-s-tait-in-the-three-two-near-bipartite-core.md), under a separate near-bipartite side analysis. The new assertion here is its **forced production from every right no-bridge \((ea)(eb)\) row after the six-cycle switch**, together with the exact pure-load residual arms (3); Note 298's near-bipartite exclusion cannot be applied to an arbitrary high-rank shore.

[Note 351](351-the-right-aj-bridge-forces-an-a-d-e-triple-hit-at-i.md) shows that even a successful third-identity candidate in this specified two-carrier bridge forces the \(a,d,e\) singleton matchings to triple-hit the proper port edge \(I=h_1\); the direct five-singleton \(A\)-cover cannot come from this tuple.
[Note 352](352-every-singleton-a-matching-hits-the-right-bridge-d-e-pair.md) further proves that every singleton-\(a\) matching hits \(b:D\) or \(I\), both shared by the resulting \(D_d,V_e\). Thus changing only the \(a\)-matching cannot repair this tuple.
