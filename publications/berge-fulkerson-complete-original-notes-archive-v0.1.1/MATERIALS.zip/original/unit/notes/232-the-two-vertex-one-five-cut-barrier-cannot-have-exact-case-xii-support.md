> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two-vertex one-five-cut barrier cannot have exact Case-XII support

Use the minimum-host, deficient-core setting of [Note 204](204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md), with its two-vertex barrier, one five-cut odd shore \(C\), internal mark \(e\), private marks \(b,c\), central mark \(a\), and rim mark \(f\). [Notes 206--208](208-only-a-private-rim-e-neighbour-pair-remains-in-the-two-vertex-connector.md) and [Note 231](231-the-first-private-rim-order-is-impossible-in-the-two-vertex-connector.md) leave one allowed missing-pair order. The result below excludes it using actual six-perfect-matching rows, without restricting the order or cycle rank of \(C\).

**Theorem.** A genuine five-pole with this connector cannot have complete exact Case-XII support. In particular, the one-five-cut profile of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) is impossible when a smallest maximum Tutte barrier has two vertices.

**Proof of the remaining order.** Suppose
\[
S=e-b-c-a-f-e,\qquad T=\{ea,ec,ab,bf,cf\}.              \tag{1}
\]
As in Note 231, \(\mathcal R(D)\) denotes the missing-pair states of all three-matching decompositions of a half-load \(D\) with terminal load one at each terminal. We first establish
\[
\varnothing\ne\mathcal R(D)\subseteq S
\quad\Longrightarrow\quad
D(g)=1\quad\text{on every proper exterior connector edge and each of }a:C,b:C,c:C,h_1,h_2,                 \tag{2}
\]
where \(h_i=u_iv_i\). The proof is independent of the complementary half-load.

[Note 055](055-half-load-column-saturation-and-case-xii-compression.md) gives \(\mathcal R(D)=S\). Choose its \(eb\)-decomposition \(D=X+Y_b+Z_e\), with boundaries \(\{a,c,f\},\{b\},\{e\}\). By [Note 205](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md), \(X\) uses \(b:w_1,u_1w_0,u_2w_2\) outside \(C\), with its sole shore hit through \(e\). The terminal-\(b\) path in \(X\triangle Y_b\) must end at \(f\), since \(ea,ec\in T\). As in Note 231, it stays outside \(C\). Switching it gives an \(ef\)-triple \(X'\) with \(X'|_C=X|_C\), either in exterior route \(L=(f:w_1,u_1w_0,u_2w_2)\) or \(R=(f:w_2,u_1w_1,u_2w_0)\).

In \(X\triangle Z_e\), the \(e\)-terminal must pair with \(c\), since \(bc\in S\) while \(ba,bf\in T\). In \(X'\triangle Z_e\), it must pair with \(a\), since \(fa\in S\) while \(fb,fc\in T\). The restrictions of these differences to \(C\) are identical; hence the shore port reached from \(c\) outside \(C\) in the first difference must equal the port reached from \(a\) outside \(C\) in the second. The following columns follow by tracing the ten exhaustive \(Z_e\) routes of [Note 206, (3)](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md). Each entry is a *port edge*, even if two ports share a shore endpoint.
\[
\begin{array}{c|c|c|c}
Z_e\text{ route}&c_b\text{ in }X\triangle Z_e&a_L\text{ in }X'_L\triangle Z_e&a_R\text{ in }X'_R\triangle Z_e\\\hline
L0&c&a&a\\
L1&h_1&a&a\\
L2&h_2&a&a\\
L3&c&h_1&h_1\\
L4&h_2&h_1&h_2\\
R0&c&a&a\\
R1&c&a&a\\
R2&c&a&a\\
R3&c&h_2&h_2\\
R4&c&h_1&h_2.
\end{array}                                                       \tag{3}
\]
For example, in \(L1\) the \(c\)-path of \(X\triangle Z_e\) follows \(c-w_2-u_2-w_0-u_1-h_1\), whereas the \(a\)-path of either \(X'_L\triangle Z_e\) or \(X'_R\triangle Z_e\) ends directly at port \(a:C\). Table (3) has only one equality \(c_b=a_L\) or \(c_b=a_R\): \(Z_e=L4\) and \(X'=R\). Therefore \(X,Y_b,Z_e\) have precisely the exterior slots in [Note 231, (5)](231-the-first-private-rim-order-is-impossible-in-the-two-vertex-connector.md). Each edge in (2) occurs in exactly one slot, proving (2).

Take the required genuine \((eb)(cf)\) row from [the published Case-XII relation, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). A \(T\)-decomposition of its \(S\)-half would pair with the fixed \(cf\)-half to form a forbidden \(T\)--\(T\) row, so (2) applies. Write its \(S\)-half as \(X+Y_b+Z_e\) and its \(cf\)-half as \(U+V_c+W_f\), where \(U\) is the triple. In particular \(Z_e=L4\) uses both \(f:w_1\) and \(c:w_2\). The complete list of \(U\)'s exterior routes is
\[
\begin{array}{c|l}
\text{shore hit of }U&\text{other exterior edges of }U\\\hline
h_1&c:w_2,\ f:w_1,\ u_2w_0\\
h_2&c:w_2,\ f:w_1,\ u_1w_0\\
c:C&f:w_1,\ u_1w_0,\ u_2w_2\\
c:C&f:w_2,\ u_1w_1,\ u_2w_0.
\end{array}                                                       \tag{4}
\]
For the first three routes, \(X\triangle U\) contains the exterior terminal \(b\)--\(f\) path \(b-w_1-t_f-f\). Switching the two triples along this path gives an \(ef\)-triple \(X''\) and a \(bc\)-triple \(U''\). Regroup the same six matching occurrences as
\[
D_{ef}=X''+Z_e+W_f,\qquad
D_{bc}=U''+Y_b+V_c,\qquad
D_{ef}+D_{bc}=2\mathbf1.                                      \tag{5}
\]
Both \(ef,bc\) belong to \(S\). Since \(X''\) and \(Z_e\) both use \(f:w_1\), their half-load has \(D_{ef}(f:w_1)=2\), while \(D_{bc}(f:w_1)=0\).

In the last route of (4), \(U\) uses \(c:C\). At the subdivision vertex \(t_c\), the complementary half has \(V_c\) on terminal \(c\), so its remaining singleton \(W_f\) must use \(c:w_2\). Now \(X\triangle U\) contains the exterior \(b\)--\(f\) path
\[
b-w_1-u_1-w_0-u_2-w_2-t_f-f.
\]
Switch it and regroup exactly as in (5). This time \(Z_e\) and \(W_f\) both use \(c:w_2\), giving \(D_{ef}(c:w_2)=2\) and \(D_{bc}(c:w_2)=0\).

Thus in every route, both complementary half-loads in (5) have an \(S\)-state and violate (2) on the same exterior edge. Each must also have a \(T\)-state. Taking those decompositions together gives a genuine forbidden \(T\)--\(T\) BF row, including a \(T\)-loop if the states coincide. This contradiction excludes (1). The other orders were excluded in Notes 206--208 and 231, proving the theorem. \(\square\)

For this one-five-cut profile a smallest maximum barrier must therefore have at least three vertices: the empty barrier would leave one exterior singleton incident with all four marks outside \(e\), exceeding its cubic degree; the one-vertex case is excluded by [Note 203](203-a-cross-triple-switch-excludes-the-422-case-xii-profile.md) together with its stated barrier corollary; and the two-vertex case is the theorem above. This lower bound does not exclude larger barriers, the other profiles of Note 169, or the perfectly matchable unmarked-core branch.
