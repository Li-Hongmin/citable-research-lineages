> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The global Kempe-action gate does not distinguish MMT Case IV

This note records a strict route closure. It applies the
stabilizer-complete global component-switch system of Notes 048--049 to the
32-type exact boundary support (H_{\\mathrm{IV}}) in the
Mácajová--Mazzuoccolo--Tabarelli (MMT) Appendix. The statement is conditional
on that transcription and ordered semiedge convention.

## Exact finite result

A state is the simultaneous endpoint-route signature of one labelled
BF-colouring. A component switch preserves the route of the switched colour
pair and every route for a disjoint colour pair; no persistence is imposed
for overlapping pairs. Internal alternating cycles are omitted, making the
finite system an over-approximation of any actual colouring action.
All colour relabellings to a target representative are unioned, including
nontrivial target stabilizers.

For (H_{\\mathrm{IV}}), the system has
[
|H_{\\mathrm{IV}}|=32,qquad
|\\mathscr S_0|=294,qquad
N_{\\mathrm{switch}}=5880.
]
Every one of the 5880 source switches has at least one target state. Hence
the greatest-fixed-point deletion has zero rounds:
[
\\mathscr S_\\infty(\\tau)=\\mathscr S_0(\\tau)\\ne\\varnothing
\\quad\\text{for every }\\tau\\in H_{\\mathrm{IV}}.
]

Therefore the global Kempe-action necessary condition cannot exclude Case IV.
This is not a realization theorem: the 294 signatures need not arise from a
single cubic 5-pole, and common perfect-matching incidence is absent.

## Consequence for the research route

Repeated or deeper application of this same action closure cannot remove
Case IV, because the initial over-approximation is already transition
closed. Any Case-IV exclusion must use an additional genuine constraint,
such as common perfect-matching incidence, whole-graph minimality, or another
independently justified invariant. No Case-V or higher-order computation is
included here.

The stabilizer-complete certificate is

../scratch/worker-mmtt-case-iv-global-action/verify_case_iv_global_kempe_action.py

and ends with
CASE_IV_GLOBAL_KEMPE_ACTION_UNDISTINGUISHED.
