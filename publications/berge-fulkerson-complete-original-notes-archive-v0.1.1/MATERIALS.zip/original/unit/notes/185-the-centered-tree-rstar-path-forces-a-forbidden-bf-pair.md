> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The centred tree--R-star path forces a forbidden BF pair

In the minimum-host \(|U|=1\) two-five-cut profile, let \(A^\circ\) be a three-vertex tree with centre port \(0\) and end groups
\[
\{\delta,x\}\mid\{y,z\}.
\]
Let \(B^\circ\) have the published Case-XIII \(R^*\) BF relation. Suppose the forbidden exact-Case-XII five-cycle \(T\) has \(\delta,\epsilon\) adjacent and its three shared labels form a path **centred at the tree's special shared port \(x\)**. Relabel \(y,z\) within their tree end group so that
\[
\boxed{T=\delta-\epsilon-y-x-z-\delta.}                 \tag{1}
\]
Then this configuration is impossible. The contradiction uses an actual BF row of \(B^\circ\) and a genuine Tait row of the tree, glued through [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) exact six-slot connector.

[Note 184, (3)](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) first forces \(xy,xz,yz\) to lie in one \(R^*\) block. The Figure-7 partition has exactly one monochromatic triangle: \(Q=\{12,15,23,25,34\}\) has the triangle on \(\{1,2,5\}\), while \(P=\{13,14,24,35,45\}\) has none. Hence
\[
xy,xz,yz\in Q,\qquad \{x,y,z\}=\{1,2,5\}
\]
up to relabelling of the \(R^*\) ports. The two remaining \(B^\circ\) ports \(0,\epsilon\) are \(3,4\). Of the six edges from \(\{1,2,5\}\) to \(\{3,4\}\), five lie in \(P\); the sole \(Q\)-edge is \(23\). Since \(x\ne z\), **at least one of \(x\epsilon,z\epsilon\) lies in \(P\)**. If \(z\epsilon\in P\), \(R^*\) supplies the pair type \((xy)(z\epsilon)\). Otherwise \(x\epsilon\in P\), and it supplies \((yz)(x\epsilon)\). The \(xy\) and \(yz\) states used here are in \(Q\).

Use the tree's genuine Tait state \(\delta y\), whose port macrocolours in the order \((0,x,y,z,\delta)\) may be fixed as \((1,1,2,1,3)\). Double it: tree boundary slots \(1,2\) are \(\{0,x,z\}\), slots \(3,4\) are \(\{y\}\), and slots \(5,6\) are \(\{\delta\}\). The chosen actual \(R^*\) row can be slot-permuted to the corresponding line below. Each entry in the \(B^\circ\) column is its boundary subset in slots \(1,\ldots,6\).

| supported \(B^\circ\) type | \(B^\circ\) slot boundaries | \(uw;\ D_\delta;\ D_\epsilon\) | outer terminal slot labels at \((x,y,z,\delta,\epsilon)\) |
|---|---|---|---|
| \((xy)(z\epsilon)\) | \(\epsilon,y,x,\{0,z,\epsilon\},z,\{0,x,y\}\) | \(\{3,5\};\{1,4\};\{2,6\}\) | \(\{4,5\},\{1,5\},\{3,6\},\{2,3\},\{3,5\}\) |
| \((yz)(x\epsilon)\) | \(\epsilon,y,x,\{0,x,\epsilon\},z,\{0,y,z\}\) | \(\{3,5\};\{1,4\};\{2,6\}\) | \(\{5,6\},\{1,5\},\{3,4\},\{2,3\},\{3,5\}\) |

In either line \(X_0=\{1,2\}\), \(Y_0=\{4,6\}\), \(X_\delta=\{5,6\}\), and \(Y_\epsilon=\{1,4\}\). Thus the common-port labels are disjoint, \(X_\delta\cap Y_\epsilon=\varnothing\), and the connector labels in the table obey Note 172's full gate. Every shore edge retains load two and every one of the six completed slots is a genuine perfect matching. In both lines outer slot \(3\) has triple terminal boundary \(\{z,\delta,\epsilon\}\), missing \(xy\); outer slot \(5\) has boundary \(\{x,y,\epsilon\}\), missing \(\delta z\). Therefore
\[
\boxed{(xy)(\delta z)\in\operatorname{BFsupp}(H).}       \tag{2}
\]
Both \(xy\) and \(\delta z\) are edges of \(T\) in (1), contradicting exact Case XII. \(\square\)

This excludes the \(T\)-path centre \(x\) for tree--\(R^*\) shores at every order. It does not decide a \(T\)-path centred at \(y\) or \(z\), or the case where \(\delta,\epsilon\) are nonadjacent in \(T\). The \(R^*\) block relation is used as a complete **actual** BF support, not as a selected-row approximation.

[Notes 186](186-the-opposite-end-centered-tree-rstar-path-is-impossible.md) and [187](187-the-tree-rstar-adjacent-special-ports-are-impossible.md) subsequently exclude both orientations centred at \(y\) or \(z\), leaving only \(\delta\epsilon\notin T\) in this tree--\(R^*\) profile.
