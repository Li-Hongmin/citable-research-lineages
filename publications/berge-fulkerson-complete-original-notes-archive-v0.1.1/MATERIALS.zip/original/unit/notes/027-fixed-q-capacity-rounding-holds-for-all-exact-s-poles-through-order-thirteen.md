> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-Q capacity rounding holds through order thirteen

The fixed-\(Q\) rounding mechanism isolated in Note 023 holds for every
simple connected cubic exact-S 5-pole through order thirteen and every
edge-covering choice of the five third matchings \(Q_t\).

Fix one Tait colouring \((L_t,R_t,Q_t)\) in each state of

\[
S=\{13,14,24,25,35\}.
\]

Assume that the five \(Q_t\) cover every edge.  In \(E\setminus Q_t\),
switching on any internal \((0,1)\)-alternating cycle preserves \(Q_t\)
and the boundary state while changing the two endpoint matchings.  The
fixed-\(Q\) rounding question asks whether such switches can produce one
endpoint matching from each state so that all five selected singleton
matchings cover every edge and their multiplicity-one set

\[
P_0=\{e:m(e)=1\}
\]

is a perfect matching.  By Note 023, these two conditions are equivalent to
the capacity-two bound.

## Complete census result

The complete numbers of exact-S poles at orders \(5,7,9,11,13\) are

\[
1,\quad1,\quad7,\quad41,\quad318.
\]

Across these 368 poles there are 46,553 distinct \(Q\)-five-tuples, of
which 17,035 cover every edge.  Every one of the 17,035 covering tuples has
a fixed-\(Q\) rounding.  The order-by-order counts are

\[
\begin{array}{c|rrrrr}
n&5&7&9&11&13\\\hline
\text{all }Q\text{-tuples}&1&1&56&1632&44863\\
\text{edge-covering}&1&1&34&763&16236\\
\text{fixed-}Q\text{ successes}&1&1&34&763&16236.
\end{array}
\]

The enumeration is complete at the level of initial Tait-colouring choices:
for a fixed \(Q_t\), the number of ordered \((L_t,R_t)\) pairs is exactly
\(2^k\), where \(k\) is the number of internal \((0,1)\)-alternating
cycles in \(E\setminus Q_t\).  Hence enumerating the distinct \(Q\)-tuples
and all cycle switches covers every endpoint choice without quotienting away
a possible failure.

The half-support profiles of the 17,035 covering tuples are

\[
\begin{array}{c|rrrrr}
\text{profile}&\varnothing&C_4&C_6&C_8&C_4\sqcup C_4\\\hline
\text{count}&5872&5559&3198&1593&813.
\end{array}
\]

Thus every half-support component in this census is even.  The paired odd
defect-exit mechanism of the order-fifteen pole in Note 023 is therefore not
tested by the order-thirteen census, although that independent odd-support
example also has fixed-\(Q\) roundings.

The resulting general candidate is:

> For every connected cubic exact-S 5-pole and every edge-covering
> \(Q\)-five-tuple, internal cycle switches preserving all \(Q_t\) produce
> a covered endpoint split whose multiplicity-one set is a perfect matching.

The present note proves this only through order thirteen.  It supplies no
general proof and, because odd support first occurs at order fifteen, it does
not establish the proposed paired-defect rule for arbitrary odd components.
Any counterexample within the stated simple connected distinct-terminal
class has order at least fifteen.

The complete deterministic census is
`scratch/worker-proof/audit_fixed_q_defect_rounding_through13.py`; it ends
with `FIXED_Q_ROUNDING_SUPPORTED_THROUGH_13`.
