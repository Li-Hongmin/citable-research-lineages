> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Y\)-forbidden Hamilton \(K_{3,3}\) pair fails an \(X\)-arm transfer

Use the one-shore, \(|U|=r=5\) Hamilton \(K_{3,3}\) exterior of [Notes 358 and 495](495-the-x-y-forbidden-k33-hamilton-row-has-eleven-necessary-z-w-route-signatures.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,16,25,36).
\tag{1}
\]
The shore has terminal \(e\) and ports \(p_i\) at \(u_i\). Assume complete exact Case-XII support with forbidden \(e\)-states \(eX,eY\). The two possible allowed pentagons are
\[
S_+=e-Z-X-Y-W-e,
\qquad S_-=e-Z-Y-X-W-e.
\tag{2}
\]
The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an **actual** \((eX)(eZ)\) BF row. Name its six complete matching occurrences
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad A=e,\quad B=e.
\tag{3}
\]

**Theorem.** No row (3) can occur with the assumed complete support, for either pentagon (2), at any shore order or cycle rank. Consequently the forbidden pair \(\{eX,eY\}\) is excluded in this Hamilton \(K_{3,3}\) exterior. Path reversal also excludes \(\{eY,eW\}\). This is an independent route to the part of the older [Note 374](374-hamilton-k33-separated-d-pairs-have-no-case-xii-row.md) conclusion concerning the reflected \(\{Z,W\}\) allowed pair; it uses a different mandatory BF row and no shore-path hypothesis.

**Transfer criterion.** By [Note 495](495-the-x-y-forbidden-k33-hamilton-row-has-eleven-necessary-z-w-route-signatures.md), the \(Z\)-starting component of \(R\triangle K\) ends at \(W\). Switch it to obtain \(R'=eW,K'=W\). The complete shore restriction of \(R'\) is exactly that of \(R\). Fix either \(D\in\{A,B\}\), and let \(E\) be the other. The complementary three-matching loads are
\[
R+K+D=R'+K'+D,
\qquad P+J+E,\qquad
(R+K+D)+(P+J+E)=2\mathbf1.
\tag{4}
\]
The second half has state \(eX\in T\). In \(Q_R\triangle Q_D\), the shore \(e\)-path ends at one of \(D\)'s three proper ports, say \(p\). This **same** shore path occurs with \(R'\), since \(Q_R=Q_{R'}\). Outside the shore, the \(R\triangle D\) arm from \(p\) ends at \(t\in\{X,Y,W\}\), and the \(R'\triangle D\) arm ends at \(t'\in\{X,Y,Z\}\). Switching the complete \(e\)-paths gives genuine pair states \(Zt\) and \(Wt'\) for the first half of (4). To avoid a forbidden \(T\)--\(T\) BF row, **every** \(D\in\{A,B\}\) must satisfy
\[
\begin{array}{c|c}
\text{pentagon}&(t,t')\text{ required}\\\hline
S_+&(X,Y)\\
S_-&(Y,X).
\end{array}
\tag{5}
\]
In particular, if one proper port has an \(X\)-arm both before and after the \(R,K\) switch, neither pentagon survives: the port paired with \(X\) is unchanged, so \(X\to Y\) and \(Y\to X\) are both impossible. We call this a *fixed \(X\)-arm* below. This argument uses whole-pole matching switches; no formal port pairing is promoted to a new shore matching.

**Route \(Z:5\to W:6\).** Here \(R\) is rooted at \(Z:5\), while \(R'\) is rooted at \(W:6\); both take \(1u_1\) and \(2u_2\). If \(P\) is rooted at \(X:1\), the \(X\)-marked-half load gives a singleton-\(e\) occurrence \(D\) using \(X:1\). In the first two of Note 495's four signatures for this route, \(P,K\) saturate \(2u_1\), so \(D\) takes \(p_1\). Its \(X\)-arm is \(X-t_X-1-u_1-p_1\) for both \(R\) and \(R'\). In the third signature \(K:2u_2\), either \(D\) again takes \(p_1\), or it takes \(2u_1\). In the latter case its marks are forced to be \(X:1,Y:6,Z:5,W:3\), hence \(D:p_2\); its unchanged \(X\)-arm is \(X-t_X-1-u_1-2-u_2-p_2\). If \(P\) is rooted at \(X:4\), then \(P,K\) saturate \(X:4\), so both \(A,B\) use \(X:1\). Original vertices 1 and 6 force both to use \(Y:6,W:3\). At least one, say \(D\), uses \(Z:2\). Its remaining tree halves cover vertices 4 and 5, so it takes \(p_1\), and the \(X\)-arm through \(1u_1\) is fixed. Thus all four signatures fail (5).

**Route \(Z:2\to W:3\).** Here \(R\) is rooted at \(Z:2\), \(R'\) at \(W:3\); both take \(1u_1,4u_3,5u_4,6u_5\). If \(P:X:4\), the two singleton-\(e\) occurrences split \(X:1,X:4\); take \(D:X:1\). When \(D:Z:2\), it takes \(p_1\) and has a fixed \(X\)-arm. Otherwise \(D:Z:5\), and matching the original vertices forces
\[
D:X:1,Y:6,Z:5,W:3,2u_1,
\quad\text{with }4u_3\text{ or }4u_4.
\tag{6}
\]
For \(4u_3\) the old \(X\)-arm exits at \(p_4\), whereas the new \(p_4\)-arm ends at \(Z\); for \(4u_4\) replace \(p_4\) by \(p_3\). In both choices the old \(Y\)-arm exits at \(p_5\) and the new \(X\)-arm at \(p_2\). Thus neither ordered pair in (5) occurs. This handles Note 495's second and third signatures.

If \(P:X:1,K:X:4\), take the singleton-\(e\) occurrence \(D:X:1\). It necessarily uses \(Y:6,W:3\). If \(D:Z:2\), it takes \(p_1\) and has a fixed \(X\)-arm. If \(D:Z:5\), then it covers vertex 2 by \(2u_1\) or \(2u_2\); \(2u_2\) again gives the fixed \(X\)-arm at \(p_1\). The only remaining choice is \(D:2u_1,4u_4\). Its old \(X\)-arm exits at \(p_3\), the new \(p_3\)-arm ends at \(Z\), the old \(Y\)-arm exits at \(p_5\), and the new \(X\)-arm exits at \(p_2\). This excludes Note 495's fourth signature.

In the first signature, \(P,K\) both take \(X:1\), so both \(A,B\) take \(X:4\). The original-vertex load forces \(J:4u_4\), and both \(A,B\) take \(p_4\). If either singleton-\(e\) occurrence takes \(p_3\), its \(X\)-arm through \(4u_3\) is fixed. Otherwise both take \(3u_3\), forcing \(J:W:3,Y:6,Z:2\). The alternative \(J:Z:5\) would overload \(5u_5\) with \(K,A,B\). Now both \(A,B\) take \(X:4,Y:1,Z:5,W:6,3u_3\) and split \(2u_1,2u_2\). Choose \(D:2u_2\). Its old \(X\)-arm exits at \(p_4\) but the new \(p_4\)-arm ends at \(Z\); its old \(Y\)-arm exits at \(p_1\) while the new \(X\)-arm exits at \(p_5\). This also fails (5).

**Route \(Z:5\to W:3\), root \(P:X:4\).** This is Note 495's seventh signature. The \(X\)-half load gives a singleton-\(e\) occurrence \(D:X:1\). Original vertices 1 and 6 force \(D:Y:6,W:3\). At \(u_1\), \(D\) takes \(p_1\) or \(2u_1\). The first choice fixes its \(X\)-arm. In the second, \(D\) must take \(p_2\), since \(W:3\) already covers vertex 3. Both \(R\) and \(R'\) take \(1u_1,2u_2\), so the arm \(X-t_X-1-u_1-2-u_2-p_2\) is fixed.

**Route \(Z:5\to W:3\), root \(P:X:1\).** These are Note 495's fifth and sixth signatures. Both \(A,B\) take \(X:4\) and \(p_4\). For either \(D\in\{A,B\}\), the old \(X\)-arm ends at \(p_4\). Every possible marking and pair of tree halves of \(D\) gives the following exterior transfers. A dash in the first column means either of the two \(K:2u_i\) choices is possible; an impossible extra choice is harmless because the table is used only as a necessary superset.

| \(K\) choice | \(D\)'s \((Y,Z,W)\) halves | \(D\)'s tree halves | new \(p_4\) endpoint | old \(Y\) port | new \(X\) port |
|---|---|---|---|---|---|
| either | \((6,2,3)\) | \(1u_1,5u_5\) | \(Y\) | \(p_2\) | \(p_3\) |
| \(2u_1\) | \((6,5,3)\) | \(1u_1,2u_2\) | \(Z\) | \(p_5\) | \(p_3\) |
| either | \((1,2,6)\) | \(3u_2,5u_5\) | \(Z\) | \(p_1\) | \(p_3\) |
| either | \((1,2,6)\) | \(3u_3,5u_5\) | \(X\) | \(p_1\) | \(p_4\) |
| \(2u_1\) | \((1,5,6)\) | \(2u_2,3u_3\) | \(Z\) | \(p_1\) | \(p_5\) |
| \(2u_2\) | \((1,5,6)\) | \(2u_1,3u_2\) | \(Z\) | \(p_3\) | \(p_3\) |
| \(2u_2\) | \((1,5,6)\) | \(2u_1,3u_3\) | \(Z\) | \(p_2\) | \(p_5\) |

The list is exhaustive: vertex 6 cannot use \(6u_5\), so \(Y:6\) forces \(W:3\), while \(Y:1\) forces \(W:6\); then the remaining original vertices and the two tree-half slots give exactly the displayed possibilities. For example, in the first line \(R'\triangle D\) takes \(p_4-u_4-5-u_5-6-t_Y-Y\), while \(R\triangle D\) takes \(Y-t_Y-6-u_5-5-t_Z-2-u_2-p_2\). In the sixth line the old \(Y\)-arm and new \(X\)-arm both end at \(p_3\): they follow \(Y-t_Y-1-u_1-2-u_2-3-u_3-p_3\) and \(X-t_X-4-u_3-p_3\), respectively. The other lines follow by the same alternating-arm tracing. For \(S_+\), (5) requires **both** \(A,B\) to be on the first line, but then \(R,A,B\) would all use \(1u_1\). For \(S_-\), (5) requires both to be on the sixth line, but then \(P,A,B\) would all use \(2u_1\). Both violate the BF load-two rule. This eliminates the last two signatures and proves the theorem. \(\square\)

The \(R,K\) switch leaves their complete shore restrictions unchanged, which is why the shore \(e\)-path is the same in the two comparisons. The later \(e\)-path switches can change shore restrictions, but each switches a component of two **complete actual matchings**, so it still produces complete actual matchings and a genuine BF row. The exclusion is conditional on the upstream tree-profile reduction and on [Note 495's](495-the-x-y-forbidden-k33-hamilton-row-has-eleven-necessary-z-w-route-signatures.md) hand-derived exhaustive route list. It makes no assertion about the one-spoke prism or other five-pole profiles and does not prove Berge--Fulkerson. The argument is hand-derived without OMEN or local mathematical recomputation and awaits independent review.
