> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A no-seed right row requires a pairing-changing carrier cycle

The endpoint-\(4\) return in [Note 135](135-a-hot-class-four-right-row-forces-the-bad-cross-half-terminal-pairing.md) does not use its mixed-side bipartization: it is a full-mask operation for every right row with the exact negative support. Together with [Notes 131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md) and [136](136-the-cross-half-five-to-two-path-also-gives-a-common-bc-seed.md), it identifies a necessary even cycle in the *same three-matching carrier* whenever the common \(B_2,C_4\) seed is absent. Neither assertion establishes that such a pole exists.

## Theorem

Let \(H\) be a cubic five-pole with no all-terminal BF cover and no \(T\)--\(T\) BF cover, including loops, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Fix an actual complete right row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.             \tag{1}
\]
Switch the forced \(2\)--\(3\) terminal path of \(q_{25}+r_{34}\), with any subsequent closed-component phase, to obtain
\[
q_{25}+r_{34}=p_{35}+t_{24}.                            \tag{2}
\]

If the \(5\)-terminal path of \(p_{35}+D_5\) ends at \(4\), there is another actual right row
\[
q'_{25}+B_2+D'_5+r'_{34}+Y_3+C_4=2\mathbf1             \tag{3}
\]
with **the same complete** \(B_2,C_4,Y_3\) masks and the same three-matching load
\[
q'_{25}+D'_5+r'_{34}=q_{25}+D_5+r_{34}.                 \tag{4}
\]
No two-edge bipartization, Tait colouring, or positive support beyond (1) is needed.

Suppose further that \(\Lambda_L(H)\cap\Lambda_R(H)=\varnothing\). Switch the forced \(2\)--\(3\) path of \(q_{25}+B_2\), with **any** closed-component phase, obtaining an actual triple matching \(u_{35}\). Then \(u_{35}+D_5\) pairs \(5\) with \(1\) for every such phase, whereas \(p_{35}+D_5\) pairs \(5\) with \(4\) for every phase in (2). In particular, these two full-mask phase cubes are disjoint, and for every choice of \(u_{35},p_{35}\),
\[
u_{35}\ne p_{35},\qquad
u_{35}\triangle p_{35}=C_1\sqcup\cdots\sqcup C_k,quad k\ge1,     \tag{5}
\]
where the \(C_i\) are proper even alternating cycles contained in the edge support of \(q_{25}+B_2+r_{34}\). For some matching \(v_{35}\) obtained by toggling a subset of these cycles and some remaining \(C_i\), switching \(C_i\) changes the \(5\)-terminal partner in \(v_{35}+D_5\). This \(C_i\) meets **both** open terminal paths of \(v_{35}+D_5\).

## Proof

For the first claim, the assumed \(5\)--\(4\) switch gives actual complete matchings \(r'_{34},Z_4\) with
\[
p_{35}+D_5=r'_{34}+Z_4.                               \tag{6}
\]
Using (1)--(2), then exchanging the two complete class-four occurrences \(Z_4,C_4\) between the half-loads, gives
\[
(t_{24}+B_2+Z_4)+(r'_{34}+Y_3+C_4)=2\mathbf1.        \tag{7}
\]
The second half has state \(34\in T\). In the first half the bichromatic terminal path beginning at \(4\) in \(t_{24}+Z_4\) can end at \(1,3,5\). The first two choices give states \(12,23\in T\) against the unchanged state \(34\), contrary to the support assumption. It therefore ends at \(5\), producing \(q'_{25}+D'_5=t_{24}+Z_4\). Equation (3) follows from (7), and cancelling the three fixed singleton occurrences in (1) and (3) gives (4). This is the algebra of Note 135(9)--(10), now without its exceptional-edge hypotheses.

For the second claim, the \(q_{25},B_2\) terminal path from \(2\) can end at \(1,3,4\). Endpoints \(1,4\) give states \(15,45\in T\) against the unchanged \(T\)-state \(34\) of \(r_{34}+Y_3+C_4\). Thus it ends at \(3\), and
\[
q_{25}+B_2=u_{35}+Z_3.                                \tag{8}
\]
The same unchanged \(T\)-half rules out endpoints \(2,4\) for the \(5\)-path of \(u_{35}+D_5\), since they give states \(23,34\in T\). Its endpoint is \(1\) independently of closed-component switches, which preserve the complete \(q_{25}+B_2\) load. By Note 136, absence of the seed makes the \(5\)-path of every \(p_{35}+D_5\) from (2) end at \(4\). Both \(u_{35},p_{35}\) are actual perfect matchings with the same boundary, so their symmetric difference consists of disjoint proper even alternating cycles. They differ because their pairings with the fixed \(D_5\) differ. Each lies in the union of the three actual masks \(q_{25},B_2,r_{34}\), proving (5).

More precisely, the two matchings occur in different three-colour decompositions of **one complete carrier load**:
\[
q_{25}+B_2+r_{34}
 =u_{35}+Z_3+r_{34}
 =p_{35}+t_{24}+B_2.                                   \tag{9}
\]

Toggle \(C_1,\ldots,C_k\) one at a time, starting at \(u_{35}\). Every intermediate mask is an actual triple matching with boundary \(35\), because the cycles are disjoint and alternating. The \(5\)-partner starts at \(1\) and ends at \(4\), so one single-cycle toggle changes it. If that cycle missed one of the two open terminal paths of the current matching plus \(D_5\), the missed path would remain an untouched component after the toggle. With four terminal ends, its unchanged pairing forces the other pairing to remain unchanged too. Hence the critical cycle meets both open paths. \(\square\)

The intermediate matchings in this last argument need not extend to three-colour decompositions of the load in (9). The theorem locates the critical cycle in its edge support; it does not assert a carrier-preserving Kempe sequence between the two displayed decompositions.

## Same-side \(5+0\) consequence

Assume additionally that disjoint proper edges \(e,f\subset X\) make \(H-\{e,f\}\) bipartite and all five terminals lie in \(X\). The profile equation of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) says that every triple matching avoids \(e,f\), while \(D_5\) uses exactly one of them. Therefore every cycle in (5), including the critical cycle, lies in \(H-\{e,f\}\).

For each intermediate \(v_{35}\), the unique exceptional edge of \(v_{35}+D_5\) lies on its path joining the **two triple-colour terminal ends**. The path from \(5\) to a triple-colour end has an even number of proper edges, as do closed alternating cycles; with both ends in \(X\), either component would require an even number of same-side exceptional edges. A single exceptional edge cannot lie there. Thus a no-seed pole in this branch requires an even cycle *away from both exceptional edges* that reconnects the two terminal paths while the exceptional edge stays on the other open path. This is a necessary full-matching obstruction, not a contradiction with exact Case XII.

## Closed-factor localization

Let \(H=H_0\oplus_{e,f}J\) be a two-edge sum with a closed cubic factor \(J\) having no terminals. For **any** actual triple matching \(Q_{35}\) and singleton matching \(D_5\), toggling a \(Q_{35}\)-alternating cycle wholly inside \(J\) leaves the terminal pairing of \(Q_{35}+D_5\) unchanged. Consequently a critical cycle in (5) cannot be wholly inside a closed two-sum factor.

Indeed, each perfect matching uses either both connector edges or neither, by parity of \(|V(J)|\). The two connectors therefore have the same load \(0,1,\) or \(2\) in \(Q+D\). At load \(0\), no component enters \(J\). At load \(2\), each connector is doubled and forms an isolated two-colour component at its endpoints, so again no open terminal path enters. At load \(1\), exactly one two-colour component can use both connectors; hence at most one of the two open terminal paths visits \(J\). An internal cycle misses the other open path in all three cases. The untouched path fixes its terminal pairing, and with four terminal ends the other pairing is fixed as well. A critical cycle therefore lies in the exterior or crosses both connectors. In the latter case its exterior segment together with the restored edge \(e\) is an alternating cycle after projection to \(H_0\). This agrees with the existential two-sum seed transfer of [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md), but gives a location statement for the particular pairing-changing cycle.

The exact Case-XII support used here is the one in Máčajová--Mazzuoccolo--Tabarelli, *Ars Mathematica Contemporanea* 26 (2026), Proposition 4.4 and Appendix XII, DOI 10.26493/1855-3974.3409.c13. That source specifies boundary types; the complete-mask assertions above are additional conditional deductions.
