> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short odd prism path forces an opposite root and a common singleton

Use the two-spoke prism exterior of [Notes 386–390](390-mixed-prism-e-rows-require-a-port-active-zero-port-cycle.md):
\[
T=\{AB,BC,Aa,Bb,ac\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac),
\]
with marked edges \(AC,Cc,bc,ab\). Let \(Q\) be a zero-port perfect matching of the complete six-port shore \(Z\), with one of [Note 387's two exceptional signed signatures](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). In both signatures, the complementary shore path \(P_o\) from \(p_2\) to \(p_4\) has odd length, counting its two port edges. Let \(P\) be a zero-port \(ej\)-triple with shore restriction \(Q\) and one of the direct roots in the table. Let \(R\) be the other zero-port \(ek\)-triple in an **actual** six-perfect-matching BF row, with shore restriction \(Q'\). The row has four singleton occurrences.

For \(F=\{ab,Cc\}\), the other two shore paths are even \(ep_5\) and \(p_1p_3\). For \(F=\{AC,bc\}\), they are even \(ep_3\) and \(p_1p_5\). The designation of allowed and forbidden states follows the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

| doubly blocked pair \(F\) | direct forbidden triple \(P\) | if \(R\) is allowed and \(|P_o|=3\), its required root |
|---|---|---|
| \(\{ab,Cc\}\) | \(e\,ab\) rooted at \(a\), or \(e\,Cc\) rooted at \(c\) | \(e\,AC\) rooted at \(C\), or \(e\,bc\) rooted at \(b\) |
| \(\{AC,bc\}\) | \(e\,AC\) rooted at \(A\), or \(e\,bc\) rooted at \(c\) | \(e\,Cc\) rooted at \(C\), or \(e\,ab\) rooted at \(b\) |

> **Odd-cycle hit gate.** For either direct root and any second triple \(R\) in such a row,
> \[
> |Q'\cap E(P_o)|+\mathbf 1_{\{\operatorname{root}(R)\in\{C,b\}\}}\ge 2.       \tag{1}
> \]
> If \(|P_o|=3\), then \(R\) is rooted at \(C\) or \(b\), and \(Q'\) contains the unique internal edge of \(P_o\). Moreover, if \(L_i\) denotes the two singleton occurrences using port \(p_i\), then
> \[
> L_2\cap L_4=\{s\},                                      \tag{2}
> \]
> where \(s\) is the unique singleton occurrence on the tree half-edge \(B u_1\).
> In particular, \(Q\triangle Q'\) also meets the \(e\)-path or the third, even proper-port path of \(Z-Q\). A change confined to \(P_o\) and closed shore components cannot support this BF row.

**Proof.** Rooting the tree at any of \(A,a,c\) makes the zero-port triple use \(B u_1\) at the prism vertex \(B\). At the subdivisions \(u_2,u_4\), that triple uses the halves toward \(C,b\), respectively. Hence the complementary full-pole graph \(H-P\) contains the cycle
\[
C_B=B-u_2-P_o-u_4-B.                                      \tag{3}
\]
It is odd because \(P_o\) is odd. In particular, (3) is a cycle of the **full five-pole**, even though it includes the shore path; no shore-internal odd cycle is assumed.

The odd-cycle two-hit argument of [Note 361, (2)](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md) applies to this full-pole cycle. Here is its local proof. Name the four singleton occurrences by \(I\). A cycle edge outside \(R\) has load two from singleton occurrences and thus carries a two-subset of \(I\). At a vertex where \(R\) shares the outgoing \(P\)-edge, the two incident cycle-edge sets are complementary. At an \(R\)-edge of the cycle, the singleton colour on that edge is the same at both ends; the two neighbouring two-sets differ by distance at most one, where \(d(A,B)=|A\setminus B|\). With no \(R\)-edge, alternation of complementary two-sets cannot close an odd cycle. With one \(R\)-edge, the required distance-two reversal around that odd cycle cannot be supplied by a distance-at-most-one defect. Hence \(R\) uses at least two edges of \(C_B\). This argument allows \(P\)-edges that join two vertices of a longer cycle, and has no shore order or cycle-rank bound.

A zero-port triple never uses a port edge. Its shore edges on (3) are exactly \(Q'\cap E(P_o)\). At \(B\) it uses precisely one of \(B u_1,B u_2,B u_4\): the edge is \(B u_2\) when its root is \(C\), \(B u_4\) when its root is \(b\), and \(B u_1\) for every other possible marked root. Thus the number of \(R\)-edges on (3) is the left side of (1), proving the inequality.

If \(P_o\) has three edges, its two port edges cannot belong to \(Q'\), leaving only its one internal edge \(f\). Hence (1) forces both \(f\in Q'\) and root \(C\) or \(b\). Intersecting those roots with the two allowed marks gives the last column of the table. In this case \(C_B\) is a five-cycle, and \(R\) hits it in exactly the two disjoint edges \(f\) and either \(B u_2\) or \(B u_4\).

For (2), write \(P_o=p_2-x-y-p_4\) and first take root \(C\), so \(R\) uses \(B u_2\) and \(xy\). **For this three-edge path**, all five \(P\)-edges incident with \(C_B\) leave that cycle: the only two shore vertices on it are \(x,y\), and their mutual edge \(xy\) is not in \(Q\). Its four singleton matchings therefore each leave the odd cycle once: their four exiting edges are the \(P\)-edges at \(B,u_2,x,y\), while the \(P\)-edge at \(u_4\) is saturated by \(P,R\). Name their distinct singleton colours \(s,t,v,w\) in that vertex order. Partitioning the four colours at the five cycle vertices gives
\[
L_2=\{s,w\},\qquad L_4=\{s,v\}.
\]
The root-\(b\) case reverses the cycle and gives the same intersection. This proves (2).

For the last assertion, suppose \(Q,Q'\) agree at every vertex of both even port paths. Name the singleton occurrences \(E_0,E_1,J,K\), with \(E_i\) at terminal \(e\). The unchanged even \(e\)-path forces its other port to carry \(\{J,K\}\), and the unchanged third even path makes its endpoint two-sets complementary, by [Note 230, (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). Consequently each \(E_i\) uses neither the other end of the \(e\)-path nor more than one end of the third path. Each singleton-\(e\) must use three proper ports by Note 230's quota, so both \(E_0,E_1\) must use **both** \(p_2,p_4\). This gives \(L_2=L_4=\{E_0,E_1\}\), contradicting (2). Hence at least one even path changes. Together with \(xy\in Q'\), the symmetric difference meets two distinct port paths. \(\square\)

The gate sharpens [Note 390](390-mixed-prism-e-rows-require-a-port-active-zero-port-cycle.md) for the stated **direct forbidden roots**: a three-edge odd port path forces one exact shore edge of \(Q'\), one of two opposite exterior roots, a specified shared singleton colour, and a change on another port path. It does not cover the other forbidden root of each label, prove that such a row exists, or exclude a complete exact-Case-XII pole. The deduction is by hand and awaits independent proof review.
