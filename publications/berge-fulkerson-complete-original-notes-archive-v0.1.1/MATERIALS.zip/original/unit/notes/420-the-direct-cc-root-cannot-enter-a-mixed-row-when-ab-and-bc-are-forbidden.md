> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct \(e\,Cc:c\) root cannot enter a mixed row when \(e\,ab,e\,bc\) are forbidden

Use the marked two-spoke prism of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md), with tree \(AB,BC,Aa,Bb,ac\), marks \(AC,Cc,bc,ab\), and arbitrary six-port shore. Suppose the exact Case-XII support has forbidden \(e\)-labels \(\{ab,bc\}\). Its allowed pentagon is one of
\[
S_1=e-AC-ab-bc-Cc-e,\qquad
S_2=e-AC-bc-ab-Cc-e.                                \tag{1}
\]
In both, \(e\,Cc\in S_i\), while \(e\,ab,e\,bc\notin S_i\).

> **Direct-root exclusion.** An actual mixed \(S\)--\(T\) BF row under this exact support cannot contain an allowed zero-port triple \(R=e\,Cc:c\), regardless of the other forbidden triple, its root, the shore order or its complementary cycles. Consequently every required mixed cell involving \(e\,Cc\) must use the other root \(C\) on its allowed triple.

**Proof.** Let \(K\) be the row's singleton-\(Cc\) occurrence. Since \(R\) is rooted at \(c\), its tree slots on \((u_1,\ldots,u_5)\) are \((B,C,A,b,a)\), and it uses \(Cc:c\) at the marked subdivision. The path of \(R\triangle K\) starting at terminal \(Cc\) enters \(c\) through \(t_{Cc}\). Because \(K\) uses the \(Cc\) terminal, it cannot also use the \(Cc:c\) half-edge. It must cover \(c\) by either \(bc:c\) or \(cu_5\).

If \(K:bc:c\), the path is wholly exterior:
\[
Cc-t_{Cc}-c-t_{bc}-bc.                             \tag{2}
\]
Switching it changes \(R=e\,Cc\) to forbidden \(e\,bc\). The row's other triple remains in \(T\), a contradiction.

Suppose \(K:cu_5\). The path continues through \(u_5-a\), which belongs to \(R\). At \(a\), the matching \(K\) must take \(ab:a\) or \(au_3\). If it takes \(ab:a\), the path ends at terminal \(ab\), giving forbidden \(e\,ab\) alongside the unchanged \(T\)-triple. If it takes \(au_3\), then the \(bc\) subdivision must be matched by \(bc:b\): \(c\) is already covered by \(cu_5\), and \(K\)'s only terminal is \(Cc\). This covers \(b\). The \(ab\) subdivision then requires \(ab:a\), because \(K\) cannot use the \(ab\) terminal or its \(b\)-half. But \(a\) is already covered by \(au_3\), impossible. Thus every feasible \(Cc\)-starting path ends at \(ab\) or \(bc\), and either switch creates a forbidden \(T\)--\(T\) BF type. \(\square\)

The required cells \((e\,ab)(e\,Cc)\) and \((e\,bc)(e\,Cc)\) therefore, if realized, use \(e\,Cc:C\). This is a root restriction at every shore order, not an exclusion of the forbidden pair \(\{ab,bc\}\): both roots of the forbidden triple and the remaining root \(C\) of the allowed triple still require joint analysis. Other forbidden pairs, exterior profiles and the Berge–Fulkerson conjecture remain open. This hand proof awaits independent review; no OMEN or local mathematical recomputation was used.

For the surviving root \(R=e\,Cc:C\), the singleton-\(Cc\) terminal path has a two-route necessary form. At \(C\), taking \(AC:C\) reaches allowed \(AC\) directly. Otherwise it takes \(Cu_2\) and follows the rooted tree through \(B\). The \(Bu_4\) branch reaches \(b\), where it ends at forbidden \(ab\) or \(bc\); hence it takes \(Bu_1\) and reaches \(A\). There \(Au_3\) continues through \(a,u_5,c\) and again ends at forbidden \(ab\) or \(bc\), so the path takes \(AC:A\). Thus the only possible allowed terminal paths are the wholly exterior
\[
Cc-t_{Cc}-C-t_{AC}-AC,\qquad
Cc-t_{Cc}-C-u_2-B-u_1-A-t_{AC}-AC.                    \tag{3}
\]
Switching either path gives a real allowed \(e\,AC\) triple with the **same complete zero-port shore mask** as \(R\), rooted at \(C\) or \(A\), respectively. Hence any surviving mixed \(e\,Cc\) row automatically supplies its corresponding \(e\,AC\) mixed row; the two cells' mere nonemptiness is not an independent next test.
