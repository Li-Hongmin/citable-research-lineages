> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A thirteen-vertex (4,2,2) pole has all triples and a BF row without the h-deletion

[Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md) leaves open, at the level of an actual graph, whether all ten triple terminal states can coexist with the failure of \(F[C]-v_h\) to have a perfect matching. The following simple, 3-edge-connected cubic marked core realizes this alternative. Its opened five-pole has girth five and even admits an actual six-matching BF row. The example is **not** an exact-Case-XII realization: below, three explicit Tait states form a triangle, forcing a forbidden loop for every choice of the Case-XII pentagon. It tests the inference from matching-level support, one genuine BF row, core connectivity, and girth; it does not test the simultaneous forty positive and fifteen negative Case-XII types.

## The marked cubic core

Take vertices \(x_1,\ldots,x_5,u,w_1,w_2\). The unmarked edges of \(F=J-M\) are
\[
x_1x_2,\ x_2x_3,\ x_3x_4,\ x_4x_5,\ ux_2,\ uw_1,\ uw_2,
\]
and the five marked edges are
\[
a=w_1x_1,\qquad b=w_1x_3,\qquad
c=w_2x_5,\qquad d=w_2x_4,\qquad e=x_1x_5.       \tag{1}
\]
Every vertex has degree three in \(J\), and no two vertices have more than one edge between them. Let \(H\) be the five-pole obtained by subdividing each mark at \(t_i\) and attaching semiedge \(s_i\). Then \(|V(H)|=13\).

This is the minimum possible order for a \(|U|=1\), \((4,2,2)\) core: if \(\rho=|E(F[C])|-|C|+1\) is the unmarked cycle rank, cubic degree counting across the five-edge cut and the one internal mark gives \(|C|=5+2\rho\), hence \(|V(H)|=|C|+3+5=13+2\rho\). The example has \(\rho=0\).

The set \(U=\{u\}\) is a smallest maximum Tutte barrier of \(F\): its deletion leaves \(C=F[\{x_1,\ldots,x_5\}]=P_5\) and the isolated vertices \(w_1,w_2\), giving deficiency two. The matching \(\{uw_1,x_1x_2,x_3x_4\}\) shows that the deficiency is exactly two. The component \(C\) has the five-edge cut \(\{ux_2,a,b,c,d\}\), and its sole internal mark is \(e\), exactly the \((4,2,2)\) profile.

The cycle \(x_1x_2x_3x_4x_5x_1\) has one attachment at each vertex to the connected tree on \(u,w_1,w_2\). Any edge cut splitting the cycle already has at least two cycle edges; a cut of size at most two would also have to include either all or none of that tree, leaving an attachment across the cut. A cut wholly on the tree side has at least three edges (the singleton cuts at \(u,w_1,w_2\) are all of size three). Hence \(J\) is 3-edge-connected. The only triangle of \(J\) is \(w_2x_4x_5w_2\), and both of its incident marked edges are subdivided in \(H\). Every four-cycle of \(J\) contains a marked edge. The five-cycle on \(x_1,\ldots,x_5\) contains \(e\). Thus the proper graph of \(H\) has girth five.

## All ten actual triple states, but no h-deletion

The three exposable vertices of the unmarked path \(C\) are exactly \(x_1,x_3,x_5\), with explicit deletion matchings
\[
\begin{array}{c|c}
\text{deleted vertex}&\text{matching of }C-\text{vertex}\\\hline
x_1&\{x_2x_3,x_4x_5\}\\
x_3&\{x_1x_2,x_4x_5\}\\
x_5&\{x_1x_2,x_3x_4\}.
\end{array}                                                 \tag{2}
\]
Deleting \(v_h=x_2\) leaves \(x_1\) isolated, so \(F[C]-v_h\) has **no** perfect matching. In Note 194's notation,
\[
H=0,\qquad E=1,\qquad (I_a,I_b,I_c,I_d)=(1,1,1,0).     \tag{3}
\]
For each missing pair \(ej\), select \(x_1\) through \(e\), the singleton at \(j\)'s fork through \(j\), and match \(u\) to the opposite singleton; complete inside \(C-x_1\) using (2). For \(ab\), select \(x_1\) through \(a\), \(w_1\) through \(b\), and match \(u\) to \(w_2\). For \(cd\), select \(x_5\) through \(c\), \(w_2\) through \(d\), and match \(u\) to \(w_1\). For each opposite-fork pair \(ij\), \(i\in\{a,b\}\), \(j\in\{c,d\}\), select \(x_1\) or \(x_3\) through \(i\), select \(w_2\) through \(j\), and match \(u\) to \(w_1\). In every case (2) completes the remaining vertices and all other subdivision vertices use their terminal semiedges. These are actual perfect matchings for all ten missing-pair states.

## One complete six-matching row

The following table is a proper three-edge-colouring of \(H\); a number beside a marked edge is the colour on its named endpoint's half-edge. The terminal colour is forced to be the third one.

| edge(s) | colours |
|---|---|
| \(x_1x_2,x_2x_3,x_3x_4,x_4x_5\) | \(2,3,2,1\) |
| \(ux_2,uw_1,uw_2\) | \(1,2,3\) |

| mark | first endpoint half | second endpoint half | terminal \(s_i\) |
|---|---:|---:|---:|
| \(a=w_1x_1\) | 1 | 3 | 2 |
| \(b=w_1x_3\) | 3 | 1 | 2 |
| \(c=w_2x_5\) | 1 | 2 | 3 |
| \(d=w_2x_4\) | 2 | 3 | 1 |
| \(e=x_1x_5\) | 1 | 3 | 2 |

At each core vertex and each subdivision vertex the three incident colours are \(1,2,3\). Each colour class is therefore a perfect matching of the pole. Take each of the three colour classes **twice**: this is a genuine six-matching BF row that loads every proper edge and semiedge exactly twice. Its boundary sets are \(\{d\},\{a,b,e\},\{c\}\), so its BF type is the loop \([cd]\). In this row the \(h=ux_2\) edge has colour 1 and occurs precisely in the two singleton-\(d\) slots.

The extra BF support excluding exact Case XII is visible without an order census. In the displayed colouring, the \(2,3\)-Kempe path from terminal \(c\) to terminal \(e\) is
\[
s_c,t_c,x_5,t_e,s_e.
\]
Switch its two colours. The lonely terminal colours are now at \(d,e\), giving Tait state \(de\). In this new colouring, the \(1,2\)-Kempe path from terminal \(d\) to terminal \(c\) is
\[
s_d,t_d,w_2,t_c,s_c.
\]
Switch again, giving Tait state \(ce\). The original state \(cd\) and these two states form the triangle \(\{cd,de,ce\}\). Every Tait state yields its BF loop by doubling its three colour matchings. Since a Case-XII allowed loop set is a five-cycle, which contains no triangle, at least one of these three actual loops is forbidden for every possible Case-XII labelling. This proves the failure of exact support directly; it agrees with [Note 100's](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) general order bound.

More generally, in *any* BF row of a \((4,2,2)\) pole with \(F[C]-v_h\) unmatchable, the two slots using \(h\) must be among the four singleton-boundary slots. Indeed, Note 194 shows that a triple slot can use \(h\) only for an opposite-fork missing pair, and then its residual matching is exactly a matching of \(F[C]-v_h\). The example satisfies this genuine six-slot restriction but still has all ten triple states.

This h-slot restriction also excludes **no pair or loop type at the exterior-incidence level**. To see this, start with the two triple slots \(T\) and four singleton slots of any prescribed pair or loop boundary type, and use [Note 175's](175-the-422-exterior-connector-excludes-only-the-all-terminal-type.md) notation \(S_i,F_1,F_2,X_h\). The forced sets
\[
L_1=S_a\cap S_b,\qquad L_2=S_c\cap S_d
\]
are disjoint subsets of \(T\): a singleton slot has only one terminal, and a triple slot cannot contain all four exterior terminals. Assign each triple slot in \(L_i\) to \(F_i\), assign any remaining triple slot to either set with room, then fill the two disjoint \(F_i\)'s to size two using singleton slots. This is always possible because each \(L_i\) has size at most two and there are only two triple slots. Now \(T\subseteq F_1\cup F_2\), so \(X_h=[6]\setminus(F_1\cup F_2)\) consists of two singleton slots. The rest of Note 175's constructive proof partitions the outer marked half-edge slots and gives a full exterior six-slot row. Conversely an all-terminal type still fails Note 175's fourfold-intersection gate. Hence the exact **formal exterior** support with h confined to singleton slots is the same 55 pair/loop types as without that restriction. This is a statement about vertex-incidence labels only, not about a perfect-matching row inside \(C\).

The remaining exact-Case-XII question must therefore use the **actual cyclic-shore matching masks coupled across all six slots and across required types**. The single-matching condition (3), core 3-edge-connectivity, girth five, one complete BF row, and the formal h-avoiding exterior gate do not imply the h-deletion.
