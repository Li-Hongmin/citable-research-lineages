> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two marked return cycles leave a tight Hall corridor

Continue the genuine central-path, \(R_0=DJ\), \(3{:}2\) near-bipartite profile of [Notes 301–303](303-two-forbidden-ed-completions-trap-the-marked-edge-in-an-internal-odd-cycle.md). The proper ports \(A,I,H\) have bases in \(B\), while \(D,J\) have bases \(d,j\) in \(R\). The unmarked core \(C-g\) is bipartite, \(|B|=|R|+1\), \(g=xy\) has both ends in \(B\), and the marked edge \(e=vw\) has \(v\in B,w\in R\). Its subdivision vertex is \(t_e\), with terminal port \(E\). Assume that \(x,y,v,d,j\) are distinct where their sides permit. A collision \(v\in\{x,y\}\) or \(d=j\) already makes the target fibre empty by incidence.

The real right \(ad\) row supplies an \(EJ,E,g\) shore matching, and [Note 302](302-the-right-zero-port-matching-forces-both-left-ad-opposite-fibres.md) supplies an \(ED,E,g\) shore matching. [Notes 300 and 303](300-two-forbidden-ej-completions-trap-the-marked-edge-in-an-internal-odd-cycle.md) put the marked edge on a closed odd shore-internal complement cycle for **every** matching in these two fibres. The remaining question is whether their coexistence forces the forbidden \(DJ,g,t_{ev}\) fibre of [Note 289](289-the-remaining-near-bipartite-core-has-an-empty-r-r-two-port-fibre.md).

**Theorem (exact Hall boundary).** Set
\[
 K=(C-\{g,e\})-\{x,y\},\qquad B'=B\setminus\{x,y\}.
\]
Suppose both \(EJ,E,g\) and \(ED,E,g\) fibres are nonempty. Then the \(DJ,g,t_{ev}\) shore fibre is empty **if and only if** there is a nonempty \(S\subseteq B'\setminus\{v\}\) such that
\[
       |N_K(S)|=|S|+1,\qquad d,j\in N_K(S).             \tag{1}
\]
For every pair \(P_D,P_J\) chosen from the two \(E,g\) fibres, their unique \(D\)--\(J\) open symmetric-difference path is contained in \(S\cup N_K(S)\); in particular it avoids \(v\). Their other difference components are closed even alternating cycles. Thus the two marked return cycles, even if identical, do not remove the Hall obstruction (1).

**Proof.** Selecting \(E,g\) covers \(t_e,x,y\). After selecting a proper port \(r\in\{D,J\}\), the remaining vertices are matched precisely by a perfect matching of \(K-\{r\}\). Selecting \(DJ,g,t_{ev}\) instead covers \(d,j,x,y,v,t_e\), so that fibre is precisely the set of perfect matchings of \(K-\{v,d,j\}\). The two assumed fibres therefore make both \(K-d\) and \(K-j\) perfectly matchable.

If \(K-v-d-j\) has no perfect matching, Hall's theorem gives a nonempty \(S\subseteq B'\setminus\{v\}\) with \(|N_K(S)\setminus\{d,j\}|<|S|\). Each of \(K-d,K-j\) has a perfect matching, so deleting either one of \(d,j\) alone leaves at least \(|S|\) neighbours. These two inequalities force both \(d,j\in N_K(S)\) and \(|N_K(S)|=|S|+1\). Conversely, (1) leaves only \(|S|-1\) neighbours after removing \(d,j\), so Hall excludes the target matching.

In any matching of \(K-d\), the \(|S|\) vertices of \(S\) saturate the exactly \(|S|\) available vertices \(N_K(S)\setminus\{d\}\). Likewise a matching of \(K-j\) saturates \(N_K(S)\setminus\{j\}\). Their symmetric-difference path starts at \(d\) along an edge into \(S\), remains within \(S\cup N_K(S)\) by this saturation, and ends at \(j\). Since \(v\notin S\), it cannot touch \(v\). \(\square\)

## A connected cubic shore with the same marked cycle in both fibres

Here is a graph-induced counterexample to the proposed *two-cycle implication*, independent of any selected-matching relaxation. Begin with vertices \(z_0,\ldots,z_{13}\) (indices modulo 14), cycle edges \(z_i z_{i+1}\), and the seven disjoint chords
\[
             F=\{z_{2k}z_{2k+5}:0\leq k<7\}.
\]
Delete chord \(z_0z_5\). Add vertices \(p,d,h,j,q\), path edges \(pd,dh,hj,jq\), and cross edges \(pz_5,qz_0\). Call \(qz_0=g\). Subdivide the cycle edge \(z_2z_3=e\) by \(t_e\), and attach terminal port \(E\) there. Attach the other five ports \(A,I,H,D,J\) at \(p,q,h,d,j\), respectively. The resulting connected cubic six-pole has 20 vertices. In the preceding theorem's notation, the endpoints of \(g\) here are \(q,z_0\). The bipartition of its unmarked core minus \(g\) is
\[
 B=\{p,q,h,z_0,z_2,\ldots,z_{12}\},\qquad
 R=\{d,j,z_1,z_3,\ldots,z_{13}\};
\]
thus it has exactly the \(R_0=DJ\) side profile, and \(v=z_2\) is disjoint from \(g\). Its internal girth is at least six. The chord set is a matching, each chord spans five cycle edges, and chord mates of adjacent cycle vertices are at cyclic distance three or five, never one; hence the 14-vertex cycle-chord graph has no 4-cycle. Any cycle newly using the corridor must traverse its four-edge path, both cross edges, and an alternative \(z_0\)--\(z_5\) path of length at least five.

Write \(F'=F\setminus\{z_0z_5\}\). Two actual shore perfect matchings are
\[
 P_D=\{E,D,g,pz_5,hj\}\cup F',\qquad
 P_J=\{E,J,g,pz_5,dh\}\cup F'.                    \tag{2}
\]
Each covers every vertex once. For **both**, the complement contains the same closed 15-cycle
\[
 z_0z_1z_2t_ez_3z_4\cdots z_{13}z_0,             \tag{3}
\]
which uses both marked half-edges and no port. Nevertheless there is no shore matching with the proper ports \(DJ\) at all: selecting both ports covers \(d,j\), while \(h\) has only neighbours \(d,j\) and its unselected port \(H\). In (1), the obstruction is already \(S=\{h\}\), with \(N_K(S)=\{d,j\}\).

This shore also has actual \(HJ,g,t_{ew}\) and zero-port \(g,t_{ew}\) matchings. Let
\[
 T=\{z_1z_2,z_4z_5,z_6z_7,z_8z_9,z_{10}z_{11},z_{12}z_{13}\}.
\]
They are respectively \(\{H,J,g,t_{ew},pd\}\cup T\) and \(\{g,t_{ew},pd,hj\}\cup T\). Thus the additional \(HJ\) fibre forced in Note 301 does not, by itself, break the Hall corridor.

The construction is **not** an exact-Case-XII counterexample. For instance, it has the actual \(EAID,E,g\notin M\) matching
\[
 Z=\{E,A,I,D,hj,z_{13}z_0,z_1z_2,z_3z_4,z_5z_6,
             z_7z_8,z_9z_{10},z_{11}z_{12}\}.
\]
The \(E\)-starting path of \(Z\) against the displayed zero-port matching ends at \(I\) and contains \(g\); switching it in \(Z\) yields a real \(AD,g,t_{ew}\) matching. [Note 290's complete-fibre exclusion](290-two-port-closure-separates-the-remaining-three-two-row-loads.md) forbids that fibre under exact Case XII. This explicitly locates the hypothesis missing from the counterexample. No enumeration is used.

For a genuine exact-Case-XII pole, (1) is a required **tight \(D,J\) Hall corridor**. To rule out the surviving \(DJ\) placement, one must exclude every such set using additional complete-support or cross-row information; the existence of the two marked return cycles alone cannot do it. This note does not settle the \(DJ\) placement, the other core profiles, or Berge–Fulkerson. The construction and Hall argument are hand-derived and have not had an independent second-source check.
