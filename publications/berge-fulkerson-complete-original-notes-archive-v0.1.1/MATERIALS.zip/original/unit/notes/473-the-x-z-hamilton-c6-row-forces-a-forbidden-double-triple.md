> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(C_6\) row forces a forbidden double triple

Use the marked Hamilton exterior and six matching names of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In signature \(C_6\), the old genuine \((eX)(eY)\) row has \(P=eX\) rooted at \(X:1\), \(R=eY\) rooted at \(Y:5\), and \(K=Y\) on \(X:4,Z:2,W:6,1u_1,3u_2,5u_5,p_3,p_4\). We retain each old complete shore matching and give one forbidden recompletion for every labelled phase.

Let \(S=\{J,a,b\}\), and write the old marked \(X\) pairs as \((RJ,P\bar\lambda,K\lambda)\), where \(\{\lambda,\bar\lambda\}=\{a,b\}\). At original vertex \(1\), the old \(1u_1=RK\) forces \(Y:1=S\setminus\{\bar\lambda\}\), hence \(Y:5=R\bar\lambda\). The old tree pairs at \(u_1,u_2,u_5\), in first-half/second-half/port order, can be written
\[
u_1=(RK,P\nu,S\setminus\{\nu\}),\qquad
u_2=(R\gamma,PK,S\setminus\{\gamma\}),\qquad
u_5=(K\xi,PR,S\setminus\{\xi\}).                         \tag{1}
\]
Writing \(Z:2=K\rho\), original vertex \(2\) gives \(\{\nu,\gamma,\rho\}=S\). The old \(Z,W\) terminal pair \(PR\), followed through vertex \(6\), gives \(W:3=S\setminus\{\rho\}\); vertex \(3\), with \(u_2:3=PK\), then gives \(u_3:3=R\rho\). At vertex \(5\), write the old \(u_4:5=P\theta\). It contains neither \(R\) nor \(K\) in \(C_6\), and the old \(Y:5=R\bar\lambda\), \(u_5:5=K\xi\) give \(\{\bar\lambda,\theta,\xi\}=S\). Thus the only identities needed are
\[
       \{\nu,\gamma,\rho\}=S,
       \qquad \{\bar\lambda,\theta,\xi\}=S.               \tag{2}
\]

Leave the old pairs at \(u_1,u_3,u_4,X\) untouched. Replace the other exterior pairs by
\[
\begin{array}{c|cc}
&u_2&u_5\\ \hline
&(RK,P\gamma,S\setminus\{\gamma\})
&(R\xi,PK,S\setminus\{\xi\})
\end{array}                                                   \tag{3}
\]
and, in terminal/first-half/second-half order at the marked subdivisions,
\[
\begin{array}{c|ccc}
&Y&Z&W\\ \hline
&(PR,S\setminus\{\bar\lambda\},K\bar\lambda)&
(PK,S\setminus\{\nu\},R\nu)&
(PR,K\nu,S\setminus\{\nu\}).
\end{array}                                                   \tag{4}
\]
Every changed subdivision triple in (3)--(4) partitions \(\{P,R,K,J,a,b\}\). At original vertices \(1,\ldots,6\) the new incident pairs are
\[
(P\bar\lambda,RK,S\setminus\{\bar\lambda\}),\quad
(P\nu,RK,S\setminus\{\nu\}),\quad
(P\gamma,R\rho,K\nu),\quad
\text{old pairs},\quad
(P\theta,K\bar\lambda,R\xi),\quad
(PK,R\nu,S\setminus\{\nu\}).                            \tag{5}
\]
The vertex-3 and vertex-5 partitions follow from (2); the others are immediate or unchanged. The proper-port pairs and \(e=ab\) are exactly those of the old row, so the new exterior glues to the same six complete shore restrictions one occurrence each. Its terminal pairs are
\[
            e=ab,\qquad X=RJ,\qquad Z=PK,\qquad Y=W=PR,    \tag{6}
\]
the forbidden \((eX)(eZ)\) type. Thus an exact-Case-XII pole with this fixed marked exterior cannot have a \(C_6\) row, at any shore order. With [Notes 470--472](472-the-x-z-hamilton-c5-row-forces-forbidden-full-support.md), only \(C_3,C_7\) remain for forbidden \(\{eX,eZ\}\); the path reflection gives the corresponding result for \(\{eY,eW\}\). This is a conditional hand proof pending independent review; other exteriors, full exact Case XII and Berge--Fulkerson remain open. \(\square\)
