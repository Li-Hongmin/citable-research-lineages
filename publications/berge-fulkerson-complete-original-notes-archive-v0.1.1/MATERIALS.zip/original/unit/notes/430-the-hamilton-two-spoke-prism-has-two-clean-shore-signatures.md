> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton two-spoke prism has two clean-shore signatures

Continue the one-shore, five-vertex-tree profile of [Notes 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md)–[359](359-two-root-parity-gate-and-k33-sharpness.md). The two branched two-spoke prism trees treated in [Notes 423](423-no-exact-case-xii-pole-has-the-marked-two-spoke-prism-exterior.md) and [429](429-no-exact-case-xii-pole-has-the-other-marked-two-spoke-prism-exterior.md) do not exhaust the two-spoke trees. The remaining orbit is a Hamilton path. Put
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).
\tag{1}
\]
The tree is the path \(a-A-C-B-b-c\); its four omitted edges carry the marked terminals \(X,Y,Z,W\). The sixth terminal \(e\) lies on an arbitrary six-port shore \(Z_0\). A *zero-port* shore perfect matching \(Q\) uses none of its six ports, and *clean* means that \(Z_0-Q\) has no odd closed component.

> **Clean-shore theorem.** Suppose \(Q\) is a clean zero-port shore perfect matching and the complete BF support omits two distinct loops of the form \([ej]\). The omitted pair can only be \(\{[eY],[eW]\}\), in which case the shore complement pairs \(e p_5,p_1p_3,p_2p_4\), with **only** \(p_1p_3\) odd; or \(\{[eZ],[eW]\}\), in which case it has the **same three pairs, all three odd**. In particular these are the only clean possibilities for the two forbidden \(e\)-labels of exact Case XII.

Here path parity counts the two port semiedges. These two signatures are sharp at the level of an actual single shore matching; neither asserts exact Case-XII support of the complete pole.

## The third two-spoke orbit

Up to a prism automorphism and exchange of its two triangular layers, a spanning tree with exactly two spokes has two edges in the top triangle and one in the bottom triangle. Its bottom edge joins one of the two spoke vertices to the unspoked vertex; the other spoke vertex is isolated in the bottom tree. The centre of the top two-edge path can be (i) the spoke over that isolated bottom vertex, (ii) the spoke over an endpoint of the bottom tree edge, or (iii) the unspoked vertex. These are inequivalent. Case (i) is the tree of Note 423, case (ii) that of Note 429, and case (iii) is (1). In (i) and (ii) the tree has a degree-three vertex, distinguished by whether its spoke-neighbour has tree degree one or two. In (iii) every non-leaf has degree two, so the tree is a Hamilton path. This proves that there are exactly three two-spoke prism-tree orbits.

## Root pairings and blockers

For each mark \(j\), [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) gives precisely two zero-port triple completions of state \(ej\) with the **same actual shore matching** \(Q\). Root the tree at the endpoint of the omitted mark selected by the triple. In the complement, \(p_i\) attaches to the parent vertex of tree edge \(i\); each other marked edge joins its two ends. The following table gives the resulting exterior pairing of \(j,p_1,\ldots,p_5\). The entry \(j\ell\mid rs\mid tu\) pairs \(j\) with \(p_\ell\) and the other ports in the displayed pairs. For instance, root \(X\) at \(A\): \(p_1,p_2\) meet at \(A\), \(X\) meets \(p_4\) at \(B\), and \(p_3\) reaches \(p_5\) through the unselected marks \(Cc,ac,ab\). This gives \(X4\mid12\mid35\).

| mark | first root | second root | both roots blocked: one odd shore path | both roots blocked: three odd shore paths |
|---|---|---|---|---|
| \(X=AB\) | \(A:X4\mid12\mid35\) | \(B:X1\mid25\mid34\) | \((4;25),(1;35)\) | \((5;12\mid34)\) |
| \(Y=Cc\) | \(C:Y5\mid14\mid23\) | \(c:Y2\mid13\mid45\) | \((5;13),(2;14)\) | \((1;23\mid45)\) |
| \(Z=ac\) | \(a:Z3\mid15\mid24\) | \(c:Z4\mid13\mid25\) | \((3;25),(4;15)\) | \((5;13\mid24)\) |
| \(W=ab\) | \(a:W5\mid13\mid24\) | \(b:W2\mid13\mid45\) | \((5;13),(2;13),(4;13)\) | \((5;13\mid24),(2;13\mid45),(4;13\mid25)\) |

In the one-odd column, \((k;q)\) means that the shore pairs \(e\) with \(p_k\), and \(q\) is its unique odd proper-port path; its other proper path is even, as is its \(e\)-path. In the three-odd column, \((k;rs\mid tu)\) means all three shore paths are odd. A clean shore complement has either one or three odd paths by [Note 359's parity lemma](359-two-root-parity-gate-and-k33-sharpness.md). If its only odd path is the \(e\)-path, neither root can be blocked, so that case contributes no entry.

For completeness, the table can be checked without enumerating shore graphs. For an exterior root pairing \(j\ell\mid rs\mid tu\) and a shore \(e p_k\) path with one odd proper path \(q\): when \(k=\ell\), the root is blocked for either choice of \(q\); when \(k\ne\ell\), it is blocked exactly when \(q\) is the one exterior pair \(rs\) or \(tu\) disjoint from \(p_k\). For three odd shore paths: when \(k=\ell\), the root is blocked exactly when the shore's two proper pairs are \(rs\mid tu\); when \(k\ne\ell\), it is blocked exactly when those pairs include the exterior pair disjoint from \(p_k\). Applying these two rules to each root pair yields the final columns. For example, the two \(W\)-roots have \(W5\mid13\mid24\) and \(W2\mid13\mid45\). With \(ep_5\), both are blocked by one odd \(p_1p_3\) path; with three odd paths, both are blocked precisely for \(p_1p_3\mid p_2p_4\).

The one-odd columns of different marks intersect only at \((5;13)\), shared by \(Y,W\). The three-odd columns intersect only at \((5;13\mid24)\), shared by \(Z,W\). Thus a clean \(Q\) can doubly block two marks only in the two stated signatures. If \([ej]\) is absent from the complete support, both rooted \(ej\)-triples using **every** zero-port \(Q\) must have an odd closed complement component: otherwise that triple extends to a Tait colouring and doubling gives \([ej]\). The two forbidden \(e\)-loops in the [published Case-XII relation, Proposition 4.4 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) meet this premise. This proves the theorem. \(\square\)

Both exceptional signatures are realized by ordinary cubic six-port shores. For \((5;13)\), relabel the eight-vertex theta shore in [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md): exchange its old \(p_1,p_2\) names and its old \(p_3,p_4\) names, leaving \(e,p_5\) fixed. Its displayed zero-port matching then has even \(ep_5\), odd \(p_1p_3\), and even \(p_2p_4\). For \((5;13\mid24)\), take a six-cycle with one port on each vertex and a zero-port alternating perfect matching. The three unused cycle edges, each extended by its two port semiedges, are odd paths; assign their ends to \(e,p_5\), to \(p_1,p_3\), and to \(p_2,p_4\). These constructions establish only sharpness of the single-\(Q\) gate.

For any other forbidden \(e\)-pair, every zero-port \(Q\) has an odd closed shore-complement component. [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) then makes the two zero-port triples of every actual mixed or loop BF row use **different complete shore matchings**. For the two exceptional pairs, clean matchings are restricted as above, while actual six-matching rows and complete perfect-matching closure remain to be analysed. This note is a hand proof without local mathematical recomputation or independent review; it neither excludes the Hamilton two-spoke exterior nor settles general exact Case XII.
