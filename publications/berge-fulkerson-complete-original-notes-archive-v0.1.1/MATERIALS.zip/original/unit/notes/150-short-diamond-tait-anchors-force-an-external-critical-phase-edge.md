> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-diamond Tait anchors force an external critical phase edge

The two actual Tait completions in [Note 149](149-both-singleton-phases-of-a-short-diamond-have-state-thirtyfive-tait-completions.md) sharpen the external-cycle conclusion of [Note 148](148-short-diamond-core-cycles-cannot-change-the-five-terminal-pairing.md). In the aligned six-edge branch, absence of a common \(B_2+C_4\) seed requires a **phase edge** outside the theta core on a terminal-pairing-critical cycle. The external edge has a specified matching-incidence defect. This is conditional on the branch and does not establish a genuine exact-Case-XII pole or exclude one.

## Setting and statement

Let \(H\) be a simple cubic five-pole with no all-terminal BF cover and no \(T\)--\(T\) BF cover, including loops, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Fix a normalized actual row and its aligned right row as in [Notes 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) and [146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md):
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1,
\qquad q_{25}+B_2=U_{35}+Z_3.                         \tag{1}
\]
Assume that \(Z\triangle Y\) has the six-edge four-junction component \(\Omega\), the right-row junction count is \(J'=5\), and \(B=U\), \(q=Z\) at every vertex of \(\Omega\). The \(J'=5\) conclusion of Note 146 extends these equalities over the interior of the overloaded chord \(\chi\). Write \(\Theta=\Omega\cup\chi\) and \(K_s=\beta\cup\gamma\cup\chi\). The four-junction normalization makes every row edge outside \(\Theta\) split between the \(U,Z,D\) and \(r,Y,C\) halves.

Take the **canonical** forced \(2\leftrightarrow3\) path \(P\) of \(q\triangle r\), with no optional closed-component switches, and put \(p=q\triangle E(P)\). Suppose the complete left and right \(B_2+C_4\) pair-load spectra are disjoint. Then \(U\triangle D\) pairs terminal \(5\) with \(1\), while \(p\triangle D\) pairs it with \(4\), by [Note 137](137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md).

**External phase-edge theorem.** Exactly one of the following two alternatives applies.

1. If \(P\) uses the three-edge arc of \(\Omega\) in \(q\triangle r\), some pairing-critical component of \(U\triangle p\) has a \(p\)-phase edge \(a\notin\Theta\) with \(q(a)=1\), \(B(a)=r(a)=0\). Its original owner pair is \(\{Z,Y\}\) or \(\{Z,C\}\). It lies in \(q\triangle U\); when \(U\) is taken with no optional closed phase in \(q+B=U+Z\), it lies on the forced \(2\leftrightarrow3\) path of \(q\triangle B\).
2. If \(P\) avoids \(\Omega\), one of the following stronger descriptions holds:
   - In owner patterns \((2,2,1,1)\) and \((1,2,1,2)\), some pairing-critical component of \(U\triangle p\) has a \(p\)-phase edge \(a\notin\Theta\) with \(D(a)=0\).
   - In owner patterns \((2,1,2,1)\) and \((1,1,2,2)\), put \(U'=U\triangle E(K_s)\). This is an actual state-\(35\) Tait colour of Note 149. Some pairing-critical component of \(U'\triangle p\) has a \(p\)-phase edge \(a\notin\Theta\) with \(D(a)=0\).

Here *pairing-critical* means that toggling the component after some other disjoint components changes the \(5\)-terminal partner of the current class-\(35\) matching plus the fixed \(D\). Such a component meets both open terminal paths at that stage. The edge \(a\) is proper because the symmetric difference of same-boundary matchings has no semiedges.

In every alternative, the exterior witness is an actual collision of the canonical cross-half triple and the original singleton:
\[
\boxed{a\in E(p)\cap E(Z),\qquad a\notin E(\Theta),\qquad
L(a)\in\{\{Z,r\},\{Z,Y\},\{Z,C\}\}.}
\]
Indeed the reference class-\(35\) matching is \(U\) or a core flip of \(U\), so it avoids this \(p\)-phase edge outside \(\Theta\). There the normalized row has one owner from each half; its S-half owner cannot be \(U\), and it cannot be \(D\) in alternative 2. In alternative 1 it is explicitly \(Z\). No weaker selected-row edge identity is substituted for the complete masks here.

## A neutral companion-flip lemma

Let \(U,D\) be perfect matchings and let \(K\) be a proper \(D\)-alternating cycle such that
\[
(U\triangle D)\cap E(K)=\{h\}.                    \tag{2}
\]
Set \(D'=D\triangle E(K)\). If \(V\) is obtained from \(U\) by toggling any collection of closed components of \(U\triangle D'\), then \(V\triangle D\) and \(U\triangle D\) have the same terminal pairing.

Indeed, \((U\triangle D')\cap K=K-h\), a path belonging to one component of \(U\triangle D'\). The closed-component toggles either leave that whole path unchanged or toggle it whole. In the first case, \(V=U\) on \(K\), and changing \(D'\) back to \(D\) replaces the path \(K-h\) by the edge \(h\) with the same endpoints. In the second case \(V=D'\) on \(K\), and changing \(D'\) back to \(D\) adds the closed cycle \(K\) to \(V\triangle D'\). Both operations preserve the open terminal pairing. Toggling closed components of \(U\triangle D'\) alone also leaves its open paths untouched, and the first replacement shows that \(U\triangle D'\) has the same pairing as \(U\triangle D\). This proves the lemma.

## Proof of the external phase-edge theorem

Number the successive edges of \(\Omega\) by \(e_1,\ldots,e_6\) as in [Note 147](147-short-diamond-phase-switch-preserves-the-first-terminal-pairing.md). Its four owner sequences give the following complete local facts. If \(P\) uses \(\Omega\), the \(p\)-edges there are precisely the two \(r\)-owned edges; otherwise \(p=q=Z\) on \(\Omega\). On \(\chi\), \(q+r\) has no \(UD\) edge, so \(p\) may use \(rC\)-edges but never a \(UD\)-edge. Note 149 gives the stated actual \(K_s\) flips.

| Owner pattern | \(r\)-owned \(p\)-edges when \(P\) uses \(\Omega\) | Core anchor when \(P\) avoids \(\Omega\) |
|---|---|---|
| \((2,2,1,1)\) | \(e_2,e_5\) | \(D'=D^{K_s}\) owns \(e_3,e_5\) and every \(rC\)-edge of \(\chi\) |
| \((2,1,2,1)\) | \(e_2,e_5\) | \(U'=U^{K_s}\) agrees with \(p\) on every \(\Omega\)-edge and owns every \(rC\)-edge of \(\chi\) |
| \((1,2,1,2)\) | \(e_1,e_4\) | \(D'=D^{K_s}\) owns \(e_2,e_4,e_6\) and every \(rC\)-edge of \(\chi\) |
| \((1,1,2,2)\) | \(e_1,e_4\) | \(U'=U^{K_s}\) owns \(e_2,e_4\) and every \(rC\)-edge of \(\chi\); \(p\) may also own \(e_6\) |

Suppose first that \(P\) uses \(\Omega\). Every \(p\)-phase edge of \(U\triangle p\) inside \(\Theta\) is owned by \(r\): on \(\Omega\) this follows from the second column, and on \(\chi\) it follows from the \(rC\) owner. [Note 138](138-pairing-change-forces-an-unalignable-cycle-with-a-three-edge-owner-certificate.md) supplies a pairing-critical, unalignable component of \(U\triangle p\). Its carrier classification requires a \(q\)-only \(p\)-phase edge, with owner pair \(\{Z,x\}\) for some \(x\in\{D,Y,C\}\). Such an edge cannot lie in \(\Theta\), where every relevant \(p\)-phase edge has owner \(r\). The split status outside \(\Theta\) excludes the overloaded S-half pair \(\{Z,D\}\), leaving \(x=Y\) or \(C\). Since \(q(a)=1\) and \(U(a)=0\), it belongs to \(q\triangle U\). If the \(q+B\) switch to \(U+Z\) has no optional closed-component switches, that difference is exactly its forced \(2\leftrightarrow3\) path. This proves alternative 1.

Now suppose that \(P\) avoids \(\Omega\). In patterns \((2,2,1,1)\) and \((1,2,1,2)\), the table gives
\[
\bigl(E(p)\setminus E(U)\bigr)\cap E(\Theta)\subseteq E(D'),
\qquad D'=D^{K_s}.                                    \tag{3}
\]
By Note 148, \(K_s\) is \(D\)-alternating and satisfies (2). Call a component of \(U\triangle p\) *aligned* if all its \(p\)-phase edges belong to \(D'\). Such a component is a closed component of \(U\triangle D'\). Toggle all aligned components first; the neutral companion-flip lemma keeps the \(5\)-partner equal to \(1\). Then toggle the remaining components one at a time. Since the final partner is \(4\), one remaining component is pairing-critical. It has a \(p\)-phase edge outside \(D'\); (3) places that edge outside \(\Theta\). There \(D'=D\), so the edge also avoids \(D\).

In patterns \((2,1,2,1)\) and \((1,1,2,2)\), the table and Note 148 give an actual \(U'=U^{K_s}\) with the same \(D\)-pairing as \(U\). They also give
\[
\left|\bigl(E(p)\setminus E(U')\bigr)\cap E(\Theta)\right|
\le1:                                                    \tag{4}
\]
the set is empty in the first pattern, and is \(\{e_6\}\) in the second. Toggle the components of \(U'\triangle p\) one at a time. Some component is pairing-critical. A pairing-critical alternating cycle must have at least two \(p\)-phase edges avoided by \(D\): if all but at most one were owned by \(D\), the \(D\)-owned edges would connect all of its \(U'\)-phase edges into one component of the current matching plus \(D\), so it could not meet both open terminal paths. Equation (4) puts at least one of these two \(D\)-free \(p\)-phase edges outside \(\Theta\). This proves alternative 2. \(\square\)

The conclusion is stronger than the mere exit of a critical cycle from \(\Theta\): it locates an edge of its **new matching phase** outside the core. In the first alternative it is a specific \(q\)-only carrier edge; in the other alternatives it avoids the fixed class-five matching. It does not constrain how the rest of the exterior path reconnects, and the complete exact-Case-XII matching closure has not been shown to forbid either external witness.

## Both right-row phases in the bypass branch

The fixed-\(B_2\) switch of [Notes 144](144-fixed-singleton-phase-cube-has-two-terminal-pairing-gates.md) and [147](147-short-diamond-phase-switch-preserves-the-first-terminal-pairing.md) gives a second actual right row. When \(P\) avoids \(\Omega\), its canonical cross-half matching is \(p^1=p^0\triangle E(\Omega)\), and absence of a common seed forces **both** \(p^\epsilon\triangle D\) pairings to have \(5\leftrightarrow4\).

**Two-external-edge corollary.** In each of the patterns \((2,2,1,1)\), \((2,1,2,1)\), and \((1,1,2,2)\), one of these two right-row phases has an actual Tait class-\(35\) anchor \(A\) such that a single pairing-critical component of \(A\triangle p^\epsilon\) contains **at least two distinct \(p^\epsilon\)-phase edges outside \(\Theta\) avoided by \(D\)**. The choices are
\[
\begin{array}{c|c|c|c}
\text{pattern}&\epsilon&A&(E(p^\epsilon)\setminus E(A))\cap E(\Theta)\\\hline
(2,2,1,1)&1&U^{K_o}&\{e_4=YD\}\\
(2,1,2,1)&0&U^{K_s}&\varnothing\\
(1,1,2,2)&0&U^{K_s}&\{e_6=ZD\}.
\end{array}                                                   \tag{5}
\]
Every anchor in (5) has the same \(5\leftrightarrow1\) pairing with \(D\) as \(U\), by Note 148, and belongs to a Tait completion in Note 149. Each core edge left in the last column is owned by \(D\). A critical cycle needs at least two \(D\)-free new-phase edges by the argument following (4), so both are exterior. On each of them the anchor equals \(U\) and is absent; the split row therefore gives \(Z\) as their S-half owner. In \((2,1,2,1)\) the symmetric phase \(\epsilon=1,A=U^{K_o}\) gives the same conclusion; indeed \(U^{K_o}\triangle p^1=U^{K_s}\triangle p^0\).

In the fourth pattern \((1,2,1,2)\), both phases still have the one-external-edge conclusion of the theorem: \(D^{K_s}\) covers the core \(p^0\)-phase, and \(D^{K_o}\) covers the core \(p^1\)-phase. These two class-five flips agree with \(D\) outside \(\Theta\). The present Tait-anchor argument does not force two exterior \(D\)-free edges on one critical cycle in that pattern.

Equivalently, under the hypotheses of this note, a directly checkable **sufficient seed criterion** is
\[
E(p)\cap E(Z)\subseteq E(\Theta)
\quad\Longrightarrow\quad
\Lambda_L(H)\cap\Lambda_R(H)\ne\varnothing.
\]
In the bypass branch of any of the three patterns in (5), it even suffices that the selected phase \(p^\epsilon\) have at most one edge of \(p^\epsilon\cap Z\) outside \(\Theta\). These are contrapositives of the preceding theorems, with the same negative-support and alignment hypotheses; they assert a common complete \(B_2+C_4\) pair-load seed, not merely a boundary type.

The primary Case-XII boundary classification is Máčajová--Mazzuoccolo--Tabarelli (2026), [Proposition 4.4 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). It supplies the allowed boundary support, not the complete-mask conclusions proved here.
