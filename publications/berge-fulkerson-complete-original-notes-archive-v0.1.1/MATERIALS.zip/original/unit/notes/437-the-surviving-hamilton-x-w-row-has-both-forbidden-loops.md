> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The surviving Hamilton \(AB,ab\) row is real but has both forbidden loops

The necessary \(S_2\) boundary of [Note 436](436-the-hamilton-prism-excludes-one-x-w-forbidden-pentagon.md), including its two immediate \(e\)-path tests, is attained by an actual six-perfect-matching row. This gives a sharp boundary for the rowwise argument while keeping complete exact-Case-XII support out of reach of the example.

> **Real row and full-closure obstruction.** There is a connected simple cubic girth-five 21-vertex five-pole with the Hamilton two-spoke prism exterior
> \[
> (p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
> (X,Y,Z,W)=(AB,Cc,ac,ab)                         \tag{1}
> \]
> and a genuine BF row of type \((eX)(eY)\) satisfying Note 436's surviving \(S_2=e-Y-W-X-Z-e\) marked boundary **and** the required \(e\)-path exits against both singleton-\(e\) occurrences. Its **complete** BF support nevertheless contains both forbidden loops \([eW]\) and \([eX]\). Thus this is not an exact-Case-XII pole or a counterexample to [Note 436](436-the-hamilton-prism-excludes-one-x-w-forbidden-pentagon.md).

Subdivide the path \(a-A-C-B-b-c\) at \(u_1,\ldots,u_5\), and subdivide the four omitted prism edges \(AB,Cc,ac,ab\) at \(t_X,t_Y,t_Z,t_W\), each with its indicated terminal semiedge. For the shore take a six-cycle
\[
q_e-q_5-q_3-q_2-q_1-q_4-q_e.                       \tag{2}
\]
Attach the terminal \(e\) to \(q_e\), and join \(u_i\) to \(q_i\) for \(i=1,\ldots,5\). These are all edges. The pole has six prism vertices, five tree subdivisions, four marked subdivisions and six shore vertices, hence 21 vertices; every vertex has degree three when semiedges are counted. A cycle entirely in the subdivided prism has length at least six, as does the shore cycle; a mixed cycle uses at least two proper ports, one shore edge and two exterior edges, so has length at least five. The adjacent-port route \(q_1-u_1-A-u_2-q_2-q_1\) attains five.

Name the six matching occurrences \(P,R,K,J,E,F\). An entry \(X:A\), for example, means the half-edge \(t_XA\); \(p_i\) means \(u_iq_i\). Their complete exterior masks are:
\[
\begin{array}{c|c|l|l|l}
&\text{selected terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P&Y,Z,W&X:A&au_1,Cu_2,Bu_3,bu_4,cu_5&\varnothing\\
R&X,Z,W&Y:C&au_1,Au_2,Bu_3,bu_4,cu_5&\varnothing\\
K&Y&X:A,Z:c,W:a&Cu_3,Bu_4,bu_5&p_1,p_2\\
J&X&Y:C,Z:c,W:a&Au_1,Bu_4,bu_5&p_2,p_3\\
E&e&X:B,Y:c,Z:a,W:b&Au_1,Cu_2&p_3,p_4,p_5\\
F&e&X:B,Y:c,Z:a,W:b&Au_2,Cu_3&p_1,p_4,p_5.
\end{array}                                                  \tag{3}
\]
In the last two rows, \(e\) is a shore terminal; their selected shore edges are specified next. The shore cycle edges, with their two occurrence labels, are
\[
\begin{array}{c|cccccc}
\text{edge}&q_eq_5&q_5q_3&q_3q_2&q_2q_1&q_1q_4&q_4q_e\\ \hline
\text{labels}&P,J&R,K&P,F&R,E&P,J&R,K.
\end{array}                                                  \tag{4}
\]
The port-label sets, including the terminal \(e\), are
\[
\begin{array}{c|cccccc}
\text{port}&e&p_1&p_2&p_3&p_4&p_5\\ \hline
\text{labels}&E,F&K,F&K,J&J,E&E,F&E,F.
\end{array}                                                  \tag{5}
\]
Tables (3)–(5) define six **complete** perfect matchings. At each shore vertex, the two incident cycle-edge label pairs and its port label pair partition \(\{P,R,K,J,E,F\}\). On every tree subdivision, marked subdivision and prism vertex, the entries of (3) likewise select exactly one incident edge per label. Every edge occurs in exactly two labels: for example, at \(u_2\) the three pairs are \(\{P,E\}\) on \(Cu_2\), \(\{R,F\}\) on \(Au_2\), and \(\{K,J\}\) on \(p_2\). The same local partition is explicit at the other \(u_i\) and all four marks. Thus (3)–(5) are a genuine BF row with triple states \(eX,eY\), singleton states \(X,Y,e,e\), and precisely the \(P:A,M=J,J:Au_1\) branch of Note 436, equation (8). Switching the wholly exterior \(Y\to Z\) path between \(R,K\) gives \(R'=eZ:c\) with the same complete shore restriction as \(R\). Against either \(E\) or \(F\), the shore part of both \(R\triangle D\) and \(R'\triangle D\) runs \(e-q_e-q_4-p_4\). The exterior \(W\)-arm under \(R\) and \(X\)-arm under \(R'\) both exit at \(p_4\). Thus both immediate \(S_2\) endpoint demands are genuinely met.

The full perfect-matching family also supplies both forbidden loops. Keep the zero-port shore matching
\[
Q=\{q_eq_5,q_3q_2,q_1q_4\},                       \tag{6}
\]
which is the shore restriction of \(P\). Glue it first to the zero-port exterior matching \(T=eW:a\) from [Note 358's rooted-tree factorization](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). This \(T\) selects \(W:a\), terminals \(X,Y,Z\), and rooted tree halves \((A,C,B,b,c)\). The complement of \(T\) in the **whole pole** is the single spanning 22-edge path
\[
e-q_e-q_4-u_4-B-t_X-A-u_2-q_2-q_1-u_1-a-t_Z-c-t_Y-C-u_3-q_3-q_5-u_5-b-t_W-W. \tag{7}
\]
The listed vertices are exactly all 21 pole vertices, each once. Alternately colouring this even path together with \(T\) gives a genuine three-edge-colouring with singleton terminal colours at \(e,W\). Doubling its three colour matchings gives a BF loop of forbidden type \([eW]\).

The same \(Q\) also glues to the rooted exterior matching \(T'=eX:B\), which selects \(X:B\), terminals \(Y,Z,W\), and tree halves \((a,A,C,b,c)\). Its complement is another single spanning 22-edge path,
\[
e-q_e-q_4-u_4-B-u_3-q_3-q_5-u_5-b-t_W-a-t_Z-c-t_Y-C-u_2-q_2-q_1-u_1-A-t_X-X. \tag{8}
\]
Alternating it gives an actual BF loop \([eX]\). These are **complete perfect-matching closure** consequences of the same pole and even the same zero-port shore matching; they are not extra selected-row assumptions.

The odd-shore condition alone does not remove this real row. Replace \(q_4\) by the Petersen three-pole \(P-v_0\) of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md), attaching its three former neighbours \(q_e,q_1,u_4\) at \(v_1,v_4,u_0\), respectively. At \(q_4\), the original label pairs are \(\{R,K\},\{P,J\},\{E,F\}\); match them to Note 381's Petersen pairs \(\{M_2,M_4\},\{M_1,M_3\},\{M_\infty,M_0\}\). The six-row cover lifts to a 29-vertex pole. In both \(R\triangle E\) and \(R\triangle F\), the gadget has exactly the two boundary differences \(q_e,p_4\), so the \(e\)-path still exits at \(p_4\) after substitution; its exterior target and the same-shore comparison with \(R'\) remain unchanged. Note 381's support-neutral substitution proves that the **complete** BF support is unchanged, so both forbidden loops persist; every zero-port shore matching now has an odd closed complementary five-cycle. The inserted gadget has a cyclic three-edge cut, so this remains a sharpness example for rowwise and shore-parity gates, not an exact-Case-XII candidate.

The example proves that Note 436's surviving row and its fixed \(e\)-path exit can occur in a real pole, while **complete** matching closure restores both forbidden loops. [Note 440](440-the-surviving-hamilton-x-w-rows-all-recomplete-to-forbidden-support.md) later excludes exact Case XII for \(S_2\) at every shore order by recompleting the six original shore matchings. The construction and complement argument are hand-derived and await independent review; no OMEN or local mathematical recomputation was used.
