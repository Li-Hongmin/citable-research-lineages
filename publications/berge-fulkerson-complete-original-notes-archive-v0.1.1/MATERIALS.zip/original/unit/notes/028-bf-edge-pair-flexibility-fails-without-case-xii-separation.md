> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# BF edge-pair flexibility fails without Case-XII separation

The unrestricted flexibility statement suggested by Note 022 is false: a
simple connected bridgeless cubic graph with a BF cover need not admit, for a
specified pair of nonadjacent edges, any BF cover in which their two labels
are disjoint.

The smallest counterexample is \(K_4\).  Its three perfect matchings are

\[
M_1=\{01,23\},\qquad M_2=\{02,13\},\qquad
M_3=\{03,12\}.
\]

Every edge belongs to exactly one \(M_i\).  If a six-matching double cover
uses \(M_i\) with multiplicity \(x_i\), either edge of \(M_i\) has cover
multiplicity \(x_i\); hence

\[
x_1=x_2=x_3=2.
\]

Thus the unique unordered BF-cover multiset is

\[
\{M_1,M_1,M_2,M_2,M_3,M_3\}.
\]

For each of the three nonadjacent edge pairs, both edges lie in the same
\(M_i\) and receive the same two-element label.  Their label intersection
therefore has size two in every BF cover.  All three pairs are
BF-forced-intersecting.

This example is order-minimal among simple connected bridgeless cubic graphs:
a simple cubic graph has at least four vertices and the order-four census
contains only \(K_4\).

It does not settle the smoothing subclass in Note 022.  Reversing a forced
pair of \(K_4\) into the two-vertex terminal tree uses existing edges between
the two ports on each side and creates triangles.  Hence \(K_4\) cannot be
the smoothing image of a girth-five Case-XII whole graph.  A useful
flexibility theorem must exploit that extra port separation or another
property of the terminal-tree smoothing; it cannot hold for arbitrary
nonadjacent edge pairs.

The streaming verifier is
`scratch/worker-verify/bf_edge_pair_flexibility_scan.py`; it terminates with
`BF_EDGE_PAIR_FLEXIBILITY_COUNTEREXAMPLE_OK`.
