> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-Q capacity rounding fails at order seventeen

The general fixed-\(Q\) rounding candidate of Notes 023 and 027 is false.
There is a simple connected cubic exact-S 5-pole on 17 internal vertices and
an edge-covering \(Q\)-five-tuple for which no choice of the corresponding
endpoint matchings, including all internal cycle switches that preserve the
five \(Q_t\), is capacity-two.  The same pole nevertheless has an ordinary
capacity-two transversal.

The pole is obtained from the order-fifteen pole of Note 020 by subdividing
the proper edges

\[
e_8=(5,9),\qquad e_{17}=(11,12)
\]

and joining the two new subdivision vertices.  Its proper edges are

\[
\begin{split}
&(0,2),(0,3),(1,5),(1,7),(2,4),(3,14),(4,11),(5,6),\\
&(5,15),(6,7),(6,10),(7,8),(8,9),(8,13),(9,12),(9,15),\\
&(10,11),(10,14),(11,16),(12,13),(12,16),(13,14),(15,16).
\end{split}
\]

Semiedge \(s_i\) is incident with vertex \(i-1\).  Complete recursive
enumeration gives 89 perfect matchings, singleton class sizes

\[
(9,7,9,9,9),
\]

and complete Tait state set exactly

\[
S=\{13,14,24,25,35\}.
\]

## A fixed-Q obstruction

For the displayed edge order, take

\[
\begin{aligned}
Q_0&=e_1e_8e_{10}e_{11}e_{14}e_{18}e_{21}s_2s_3s_5,\\
Q_1&=e_2e_5e_{10}e_{11}e_{15}e_{18}e_{19}s_1s_3s_5,\\
Q_2&=e_3e_6e_8e_{10}e_{12}e_{20}e_{21}s_1s_3s_4,\\
Q_3&=e_4e_7e_{11}e_{14}e_{16}e_{21}e_{22}s_1s_2s_4,\\
Q_4&=e_0e_8e_9e_{13}e_{14}e_{17}e_{18}s_2s_4s_5.
\end{aligned}
\]

These are perfect matchings and cover every edge.  Their edge multiplicities
are 1 on 17 edges and 3 on 11 edges; no edge has multiplicity 2, so the
half-support in the sense of Note 012 is empty.

The complete fixed-\(Q\) endpoint variant counts in the five states are

\[
(4,1,1,1,1).
\]

They yield \(4\cdot2^5=128\) raw endpoint representations and 88 distinct
singleton transversals.  Exhaustive evaluation gives:

\[
\begin{array}{c|r}
\text{outcome}&\text{representations}\\\hline
\text{not covering, maximum multiplicity }3&99\\
\text{not covering, maximum multiplicity }4&19\\
\text{covering, maximum multiplicity }3&10.
\end{array}
\]

Thus no fixed-\(Q\) representation has capacity at most two.  In
particular, failure is not caused by odd half-support components: it occurs
with empty half-support and is intrinsic to the requirement that all five
third matchings remain fixed.

## The main capacity conjecture survives

The same pole has an independently verified singleton-boundary transversal
covering every edge with maximum multiplicity two.  Therefore this example
does not refute the capacity-two conjecture; it separates that conjecture
from the strictly stronger fixed-\(Q\) rounding statement.

This is the first failure encountered in the complete labelled one-step
neighbourhood scan of the Note 020 seed, at move 173 of 300.  Before it,
19,651 edge-covering \(Q\)-tuples rounded successfully, including tuples
with half-support \(C_5\sqcup C_5\) and \(C_5\sqcup C_7\).  Because the
scan stopped at the first counterexample, those preceding counts are not a
complete classification of the neighbourhood and are not used for a
minimality claim.  Together with Note 027, the example shows only that the
first possible counterexample order is between fifteen and seventeen; it
does not prove order-minimality at seventeen.

The frozen pure-standard-library certificate is
`scratch/worker-proof/verify_n17_fixed_q_rounding_counterexample.py`; it
checks the graph, all 89 perfect matchings, exact-S, the complete fixed-\(Q\)
endpoint family, its failure, and an ordinary capacity-two witness, ending
with `N17_FIXED_Q_ROUNDING_COUNTEREXAMPLE_VERIFIED`.
