> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other two-spoke prism excludes the bottom-edge forbidden pair

Keep the marked prism tree of [Notes 424](424-the-other-two-spoke-prism-excludes-the-ac-ab-forbidden-pair.md) and [425](425-the-other-two-spoke-prism-excludes-the-ac-cc-forbidden-pair.md):
\[
(u_1,\ldots,u_5)=(AB,BC,Aa,Bb,bc),\qquad
(X,Y,Z,W)=(AC,Cc,ac,ab).
\]
The shore, with ports \(e,p_1,\ldots,p_5\), has arbitrary size. Suppose its **complete** BF boundary support is exact Case XII with forbidden \(e\)-labels \(\{Z,W\}\). The two possible allowed pentagons are
\[
S_1=e-X-Z-W-Y-e,\qquad S_2=e-X-W-Z-Y-e.                 \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eZ)(eY)\) and excludes every double-\(T\) cell.

> **Pair exclusion.** Neither pentagon in (1) can be the complete BF boundary support of a pole with this marked tree and any shore.

Suppose a required row exists. Name its forbidden triple \(P=eZ\), allowed triple \(R=eY\), singleton occurrences \(K=Y,J=Z\), and two singleton-\(e\) occurrences \(D_0,D_1\). The \(Y\)-starting path of \(R\triangle K\) must end at \(X\): an ending at \(Z\) or \(W\) would change \(R\) to another forbidden triple while \(P\) stays fixed.

Every \(e\)-missing triple uses zero exterior ports: its three marked terminal edges and one marked half cover the four marked subdivisions and one prism vertex, leaving exactly five prism vertices for the five tree subdivisions. Every singleton-\(e\) matching uses exactly three exterior ports. On the shore, the symmetric difference of such a triple and singleton has one \(e\)-to-port path; its port endpoint depends only on their complete shore matchings. If two distinct marked terminal arms also end at exterior ports, the third does too: there is no exterior port-to-port component through which the shore path could detour.

The \(Y\)-starting \(R\triangle K\) path is wholly exterior. It leaves the \(Y\) subdivision on \(R\)'s rooted half-edge. At every tree subdivision it thereafter arrives on a \(K\)-edge and departs on \(R\)'s other prism-vertex half-edge, since \(R\) uses no port. It can terminate only on one of \(R\)'s other three marked terminal edges.

Whenever this path is switched, \(K\) changes as well as \(R\), but \(P,J,D_0,D_1\) remain the same complete matching occurrences. Thus the later comparisons of \(R'\) with a \(D_i\) belong to an actual BF row.

**The root of \(R\) is \(C\).** If \(R=eY:c\), the path starts through \(c,u_5,b,u_4,B\): exiting at \(Z:c\) or \(W:b\) is forbidden. Its only possible \(X\) endings go through \(Bu_2,C,X:C\) or \(Bu_1,A,X:A\). In either case \(K\) covers \(c\) by \(cu_5\) and \(b\) by \(bu_4\), leaving only \(a\) to cover **both** the \(Z=ac\) and \(W=ab\) subdivisions. Hence \(R=eY:C\). Its tree slots are \((A,B,a,b,c)\).

From \(Y\), the \(R\triangle K\) path can now reach the allowed \(X\) either directly through \(Y-t_Y-C-t_X-X\), or through
\[
Y-t_Y-C-u_2-B-u_1-A-t_X-X.                              \tag{2}
\]
The \(Bu_4,b\) branch can end at forbidden \(W:b\); if it continues through \(u_5,c\), it ends at forbidden \(Z:c\) or has no valid terminal exit. The \(Au_3,a\) branch ends at forbidden \(Z\) or \(W\).

The direct path is impossible. Switch it to \(R'=eX:C\), which has exactly the same shore matching as \(R\). Both roots of \(P=eZ\) use \(Cu_2\). At \(C\), the occurrences \(P,R,K\) use \(Cu_2,Y:C,X:C\), respectively. Among \(J,D_0,D_1\), at least one singleton-\(e\) occurrence \(D\) uses \(X:C\) or \(Y:C\). If \(D:Y:C\), then \(D:X:A\), and the switch merely relabels the exterior arm from \(A\) from terminal \(X\) to terminal \(Y\). If \(D:X:C\), then \(D:Y:c\), and the same relabelling occurs for the arm from \(c\). In particular the \(Z\)- and \(W\)-terminal arms, including their shore exits if separate, are unchanged. If they pair with each other, the prescribed \(e\)-switch is already impossible. Otherwise they have distinct shore exits, and the fixed shore \(e\)-path cannot select different ones. But \(S_1\) requires \(R=eY\) to select \(W\) and \(R'=eX\) to select \(Z\); \(S_2\) reverses these targets. Contradiction.

Thus \(K\) uses the long path (2). Switching it gives \(R'=eX:A\) with the same complete shore matching as \(R\). Its tree slots are \((B,C,a,b,c)\), so \(R,R'\) agree at \(au_3,bu_4,cu_5\). At \(X\), \(P,R\) use the terminal and \(K:X:A\). At \(C\), \(P,K\) saturate \(Cu_2\), while \(R:Y:C\). The edge loads force exactly one of \(J,D_0,D_1\), call it \(M_A\), to have
\[
M_A:X:A,\ Y:C;                                         \tag{3}
\]
the other two take \(X:C\).

**\(M_A\) cannot be a singleton-\(e\) occurrence.** Suppose \(D=M_A\). The only ways it can cover the \(Z,W\) subdivisions are the three rows below. Each entry gives the first shore exit of the indicated terminal arm in \(R\triangle D\), followed by its exit in \(R'\triangle D\):

| \(D\)'s marked halves | \(Z\)-arm exits \((R,R')\) | \(W\)-arm exits \((R,R')\) |
|---|---|---|
| \(Z:a,W:b\) | \((p_3,p_3)\) | \((p_4,p_4)\) or \((p_2,p_1)\) |
| \(Z:c,W:a\) | \((p_5,p_5)\), \((p_4,p_4)\), or \((p_2,p_1)\) | \((p_3,p_3)\) |
| \(Z:c,W:b\) | \((p_5,p_5)\) | \((p_4,p_4)\) or \((p_2,p_1)\) |

For example, \(Z:a\) or \(W:a\) gives the fixed \(a-u_3-p_3\) arm because (3) covers \(A\). A \(b-u_4-B\) arm exits through \(u_2,p_2\) against \(R\) and through \(u_1,p_1\) against \(R'\); otherwise it exits at \(p_4\). If \(D\) takes \(Z:c,W:b\), its \(Z\)-arm exits at \(p_5\). The remaining \(Z:c,W:a\) option reaches \(p_5\) directly or follows \(c-u_5-b-u_4\). These are all exterior routes because \(D:X:A,Y:C\).

The shore \(e\)-path is the same in the two comparisons. Under \(S_1\), it would have to exit through the \(W\)-arm of \(R\) and the \(Z\)-arm of \(R'\); under \(S_2\), through the \(Z\)-arm of \(R\) and the \(W\)-arm of \(R'\). Every row of the table assigns distinct ports to these demanded exits. Hence (3) belongs to \(J\), not to either \(D_i\).

Now \(J:X:A,Y:C\) and \(J\) takes the \(Z\) terminal. Therefore \(J:cu_5\). If \(P=eZ:a\), then \(P\) and \(R\) already saturate \(cu_5\), impossible. Consequently \(P=eZ:c\); its tree slots are \((A,C,a,B,b)\). Both \(P,R\) take \(au_3\), so \(J\) covers \(a\) by \(W:a\). The same saturation forces \(K\) to cover \(a\) by \(Z:a\) or \(W:a\). The first choice would make \(K:cu_5\), already saturated by \(R,J\), so \(K:W:a,Z:c\). As \(J:cu_5\), it cannot also take \(bu_5\); it must take \(bu_4\). Then \(R,J\) saturate \(bu_4\), forcing \(K:bu_5\).

The marked-edge loads now give, for **both** \(D_i\),
\[
D_i:X:C,\ Y:c,\ Z:a,\ W:b,\ Au_3.                  \tag{4}
\]
At \(B\), \(P,R,K\) take \(Bu_4,Bu_2,Bu_1\), respectively. The matching \(J\) cannot take \(Bu_4\) because it already takes \(bu_4\); hence one \(D_i\) takes \(Bu_4\) and the other, say \(D\), takes \(Bu_1\) or \(Bu_2\). The \(W\)-terminal arm against either \(R\) or \(R'\) is then \(W-t_W-b-u_4-p_4\). If \(D:Bu_1\), its \(Z\)-arm exits at \(p_2\) against both \(R,R'\); if \(D:Bu_2\), it exits at \(p_1\) against both. Thus the same shore \(e\)-path would have to select \(p_4\) in one comparison and \(p_2\) or \(p_1\) in the other, under either orientation of (1). This is impossible.

Therefore the required \((eZ)(eY)\) cell cannot exist. Together with Notes 424 and 425, three forbidden \(e\)-pairs are excluded for this **second** two-spoke tree. The other three pairs, other marked exteriors, and Berge–Fulkerson remain open. This is a hand-derived complete-matching argument and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
