> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last clean Hamilton-prism pair has one allowed root and two marked masks

Use the Hamilton two-spoke prism exterior of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                              \tag{1}
\]
Assume the complete BF support is exact Case XII with forbidden \(e\)-labels \(\{eZ,eW\}\). The two allowed pentagons are \(e-X-Z-W-Y-e\) and \(e-X-W-Z-Y-e\). Both require the genuine mixed type \((eW)(eY)\), while every \(T\)--\(T\) type is absent by the [published relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

> **Root and marked-mask gate.** In every actual row of type \((eW)(eY)\), the allowed triple \(R=eY\) is rooted at \(C\). Its singleton-\(Y\) partner can switch \(R\) to the other allowed triple \(eX\) only along \(Y-C-u_2-A-X\) or \(Y-C-u_3-B-X\), both wholly exterior. If the forbidden triple \(P=eW\) is rooted at \(b\), then the singleton-\(W\) occurrence has \(Y:c,Z:a\), and the two singleton-\(e\) occurrences have, in some order, exactly the marked-half masks
> \[
> (Y:C,Z:c,W:a),\qquad (Y:c,Z:a,W:b).                 \tag{2}
> \]
> No restriction on their \(X\) halves or full shore matchings follows here.

Name the two triples \(P=eW\) and \(R=eY\), their corresponding singleton occurrences \(J=W\) and \(K=Y\), and the two singleton-\(e\) occurrences \(D_0,D_1\). As in [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md), an \(e\)-missing triple uses zero exterior ports. The \(Y\)-starting component of \(R\triangle K\) is therefore wholly exterior. Its endpoint must be \(X\): endpoints \(Z,W\) would replace \(R\) by a forbidden triple beside unchanged \(P\).

If \(R=eY:c\), the path starts \(Y-c-u_5-b\). An immediate ending at \(W:b\) is forbidden. The possible allowed \(X:B\) ending follows \(b-u_4-B-X\); the only longer allowed \(X:A\) ending continues through \(B-u_3-C-u_2-A-X\). Both routes occupy \(b,c\) in \(K\), so the unselected \(Z=ac\) and \(W=ab\) subdivisions would both have to use their \(a\) half-edge. One matching cannot do that. Thus \(R\) cannot be rooted at \(c\).

Root \(R=eY:C\). Its tree halves are \((a,A,B,b,c)\) at \((u_1,\ldots,u_5)\). The \(Y\)-path first takes \(C u_2\) or \(C u_3\). In the former branch it reaches \(A\), where \(X:A\) is the only allowed terminal ending; continuation through \(u_1,a\) reaches only forbidden \(Z,W\). In the latter branch it reaches \(B\), where \(X:B\) is the only allowed ending; continuation through \(u_4,b,u_5,c\) reaches only forbidden \(W,Z\). This proves the two routes in the statement. Switching either between the *complete* matchings \(R,K\) produces \(eX\) with the same complete shore restriction as \(R\).

Finally suppose \(P=eW:b\). Rooting the tree at \(b\) gives its tree halves \((a,A,C,B,c)\). Thus \(P,R\) saturate both \(a u_1\) and \(c u_5\). The singleton \(K=Y\) uses the \(Y\) terminal. At \(c\), it can use neither \(c u_5\) nor the \(Y:c\) half-edge, so it takes \(Z:c\). At \(a\), it can use neither \(a u_1\) nor \(Z:a\), and therefore takes \(W:a\), independently of which \(Y\to X\) route occurred.

The singleton \(J=W\) takes the \(W\) terminal, so at \(a\) it must use \(Z:a\), because \(a u_1\) is saturated. At \(c\), it must use \(Y:c\), because \(c u_5\) is saturated and \(J\) already uses \(Z:a\). Both triples take the \(Z\) terminal, while \(K:Z:c\) and \(J:Z:a\); hence the two \(D_i\) split the remaining \(Z:c,Z:a\) slots. The \(W\)-terminal occurrences are \(R,J\); with \(P:W:b\) and \(K:W:a\), the \(D_i\) split the remaining \(W:a,W:b\) slots. Since \(a u_1\) is saturated, a single \(D_i\) cannot take \(Z:a\) and \(W:a\). Therefore one \(D_i\) takes \(Z:c,W:a\) and the other \(Z:a,W:b\). At \(c\), the former must take \(Y:C\), and the latter \(Y:c\), proving (2). \(\square\)

This is a necessary condition on actual complete BF rows, not an exclusion of the \(\{eZ,eW\}\) pair. In particular the two branches and their still-unfixed shore matchings need further closure analysis. Its scope is arbitrary shore order, cycle rank and complement parity. The argument is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used.
