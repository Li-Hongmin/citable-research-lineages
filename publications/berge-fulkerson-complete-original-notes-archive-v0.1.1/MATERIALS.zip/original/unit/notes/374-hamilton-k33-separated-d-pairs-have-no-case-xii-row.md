> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two separated-\(d\) pairs fail on the Hamilton-path \(K_{3,3}\) exterior

Continue the Hamilton-path \(K_{3,3}\) exterior of [Note 373](373-the-hamilton-k33-end-pair-row-cannot-root-at-x.md): the tree is \(x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t\), with ports \(p_0,\ldots,p_4\), and the four exterior marks are \(a=xs,b=xt,c=yt,d=zr\). For the two exact-Case-XII pentagons
\[
S_5=e-a-b-c-d-e,\qquad S_6=e-a-c-b-d-e,             \tag{1}
\]
the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ad)\) BF row and forbids every double-\(T_i\) row, where
\[
T_5=\{ac,ad,eb,ec,bd\},\qquad
T_6=\{ab,ad,eb,ec,cd\}.                              \tag{2}
\]

**Theorem.** No cubic five-pole with this Hamilton-path exterior has complete exact-Case-XII support for either pentagon in (1), at any shore order or cycle rank. The path-reversal automorphism exchanges \(a,c\) and fixes \(b,d\), so it also excludes the two reflected pentagons whose \(e\)-neighbour pair is \(\{c,d\}\). Thus four of the twelve labelled pentagons on this exterior are excluded.

**Proof.** In the required \((ea)(ad)\) row use the names \(P,R,E,D,A_1,A_2\) of Note 373: \(P\) is the zero-port state-\(ea\) triple, \(R\) the state-\(ad\) triple, \(E,D\) are singleton at \(e,d\), and \(A_1,A_2\) are singleton at \(a\). Note 373 excludes root \(x\), so \(P\) is rooted at \(s\) and uses
\[
t_as,\quad xu_0,ru_1,yu_2,zu_3,tu_4,
\qquad\text{terminals }b,c,d.                       \tag{3}
\]
Since \(R=ad\in T_i\), each \(a\)--\(d\) path of \(P\triangle A_j\) must switch \(P\) to \(ed\in S_i\). The path stays wholly outside the shore by [Note 244's zero-port argument](244-every-shore-mark-must-neighbour-the-internal-mark.md). It is either
\[
J:a-t_a-s-u_3-z-t_d-d
\quad\text{or}\quad
K:a-t_a-s-u_2-y-u_1-r-t_d-d.                    \tag{4}
\]
Throughout the proof \(R\) selects \(tu_4\), because its terminal set includes both \(b,c\); hence \(P,R\) saturate \(tu_4\).

On \(J\), the singleton \(A_j\) matches \(s,z\) along the path. Covering \(b,c\) through \(t_b,t_c\) leaves three apparent choices of marked halves. The choice \(t_bx,t_cy\) would make \(A_j\) use \(tu_4\) at \(t\), already saturated by \(P,R\), so it is impossible. The two remaining kinds are
\[
J_0:\ t_bx,t_ct;
\qquad J_1:\ t_bt,t_cy,\ xu_0,ru_1.               \tag{5}
\]
Both use \(t_dz,su_3\). On \(K\), a singleton has already matched \(s,y,r\), so it must use \(t_bx,t_ct,t_dr,su_2,yu_1\). Its last unmatched tree vertex \(z\) gives two kinds:
\[
K_0:\ zu_3;
\qquad K_1:\ zu_4.                              \tag{6}
\]
The two \(K\)-kinds also both use \(t_bx,t_ct,t_dr,su_2,yu_1\).

Two exchange gates remove most pairs immediately. First, after a \(J\)-switch the state-\(ed\) triple \(P_J\) uses \(t_dz\). To avoid \(eb,ec\in T_i\) when switching \(P_J\) with \(D\), the \(d\)-terminal path must end at \(a\). If \(D\) used \(zu_4\), this path would follow \(d-t_d-z-u_4-t\) and end at \(b\) or \(c\), since \(D\) matches \(t\) through one of those marks. Therefore
\[
\boxed{J\text{ in the row }\Longrightarrow D\text{ uses }zu_3.}       \tag{7}
\]
Second, after a \(K\)-switch the state-\(ed\) triple \(P_K\) uses \(t_dr\). When both \(A_j\) use \(K\), their \(t_bx,t_ct\) halves force \(D\) onto \(t_bt,t_cy\). A \(d\)-path through \(ru_1\) then ends at \(c\); to end at \(a\), \(D\) must use \(ru_0,t_ax\). These conclusions use complete matching exchanges, not formal boundary paths.

If both \(A_j\) use \(J\), they saturate \(t_dz\), forcing \(R\) to use \(t_dr\). Since \(R\) also uses \(tu_4\), it must cover \(z\) through \(zu_3\). Together with \(P\), this saturates \(zu_3\), contradicting (7). The pair \(J+K_0\) also contradicts (7), because \(P,K_0\) already saturate \(zu_3\). Two \(K_0\) occurrences overload \(zu_3\) with \(P\).

Two \(K_1\) occurrences cannot occur either. They saturate \(zu_4\) and \(su_2\), while \(P\) uses \(zu_3\); hence \(D\) must use \(zu_3\). The second gate forces \(D\) onto \(t_ax,ru_0\), so it cannot match \(s\) through \(a\), and \(su_2\) is already saturated. It must use \(su_3\), but \(D\) already uses \(zu_3\), a matching conflict at \(u_3\). Only \(K_0+K_1\) and \(J+K_1\) remain.

**One \(K_0\), one \(K_1\).** Both \(A_j\) use \(t_bx,t_ct,t_dr\), forcing \(E,D\) onto \(t_bt,t_cy\) and \(R,E\) onto \(t_dz\). At \(z\), \(P,K_0\) saturate \(zu_3\), and \(K_1,D\) use \(zu_4\). The second gate gives \(D\) the edges \(t_ax,ru_0\). At \(x\), either \(E\) uses \(t_ax\) and \(R\) uses \(xu_0\), or \(E\) uses \(t_as,xu_0\) and \(R\) uses \(t_ax\). In the first case the remaining row loads give \(E\) the tree edges \(ru_0,su_3\); in the second, \(E\) uses \(ru_1\). Follow the exterior legs before and after either \(K\)-switch. Both switches produce the same state-\(ed\) triple \(P_K\) with the same complete shore matching as \(P\):

| \(E\)'s \(a\)-half and tree edges | \(P\triangle E\): \(b,c,d\) | \(P_K\triangle E\): \(a,b,c\) |
|---|---|---|
| \(t_ax,ru_0,su_3\) | \(p_4,p_2,p_1\) | \(p_2,p_4,p_1\) |
| \(t_as,xu_0,ru_1\) | \(p_4,p_2,p_3\) | \(p_2,p_4,p_3\) |

For \(S_5\), the old \(e\)-path must end at \(b\); after the \(K\)-switch it still ends at \(b\), giving \(bd\in T_5\) beside \(R=ad\in T_5\). For \(S_6\), the old \(e\)-path must end at \(c\); it then ends at \(a\), giving \(ad\in T_6\) beside \(R\). Thus \(K_0+K_1\) is excluded.

**One \(J\), one \(K_1\).** By (7), \(P,D\) saturate \(zu_3\). Since \(R\) uses \(tu_4\), it cannot use \(zu_4\), so the remaining mark and vertex loads force \(R\) onto \(t_dz\) and \(E\) onto \(t_dr,zu_4\). In either \(J_0\) or \(J_1\) row, \(D\) must use \(t_as\). For \(J_0\), both \(A_j\) use \(t_bx,t_ct\), so \(D\) uses \(t_bt,t_cy\); if it used \(t_ax\), it would have to leave \(s\) through \(su_2\), and the \(d\)-path after \(J\) would end at \(c\). For \(J_1\), assuming \(D\) uses \(t_ax\) forces it onto \(t_bt,t_cy\) as well, with the same forbidden \(d\)--\(c\) path. Thus \(D\) uses \(t_as\), and the loads give the same exterior restriction of \(E\) in both cases:
\[
E:\quad t_ax,t_bt,t_cy,t_dr,zu_4,
\qquad\text{and either }su_2\text{ or }su_3.             \tag{8}
\]
Write \(P_J,P_K\) for the triples obtained by switching along the two available routes; both retain \(P|_Z\). The relevant endpoint legs are:

| \(E\)'s edge at \(s\) | \(P\triangle E\): \(b,c,d\) | \(P_J\triangle E\): \(a,b,c\) | Needed \(P_K\triangle E\) leg |
|---|---|---|---|
| \(su_2\) | \(p_3,p_0,p_1\) | \(p_0,p_1,p_3\) | \(b\mapsto p_3\) |
| \(su_3\) | \(p_0,p_2,p_1\) | \(p_0,p_1,p_2\) | — |

For \(S_6\), the old \(e\)-path ends at \(c\). With \(E\) on \(su_2\), the \(J\)-switch sends it to \(a\), giving \(ad\in T_6\); with \(E\) on \(su_3\), it stays at \(c\), giving \(cd\in T_6\). For \(S_5\), the old \(e\)-path ends at \(b\). With \(E\) on \(su_3\), the \(J\)-switch sends it to \(a\), giving \(ad\in T_5\). With \(E\) on \(su_2\), the \(K_1\)-switch leaves it at \(b\) by the last table column, giving \(bd\in T_5\). This excludes the last combination. \(\square\)

The tree-path reversal \((x,r,y,s,z,t)\mapsto(t,z,s,y,r,x)\) fixes the unmarked tree, sends \((a,b,c,d)\mapsto(c,b,a,d)\), and preserves complete BF rows. It carries the excluded \(e\)-neighbour pair \(\{a,d\}\) to \(\{c,d\}\). The remaining eight labelled pentagons, other exterior trees, general exact Case XII and the Berge--Fulkerson conjecture are not decided here. The proof is analytic and awaits independent review; no local mathematical recomputation was used.
