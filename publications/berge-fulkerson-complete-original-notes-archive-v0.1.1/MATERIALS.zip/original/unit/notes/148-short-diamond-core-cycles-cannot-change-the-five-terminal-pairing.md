> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short diamond's internal alternating cycles preserve the five-terminal pairing

The six-edge diamond in [Notes 146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md) and [147](147-short-diamond-phase-switch-preserves-the-first-terminal-pairing.md) contains owner-obstructed alternating cycles. None of its cycles can be the terminal-pairing-critical component required by the no-seed theorem of [Note 137](137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md). This locates that obstruction outside the short theta core in the complete actual matching family; it does not prove a common seed or rule out an exact-Case-XII pole.

Let
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1                     \tag{1}
\]
be an actual normalized four-junction row with no state-\(34\) Tait colouring. Suppose its four-junction \(Z_3\triangle Y_3\) cycle \(\Omega\) has six edges, so its owners have one of the four patterns in Note 146. Let \(\chi\) be the overloaded type-\(13\) chord, and let \(\Theta=\Omega\cup\chi\) be their theta graph. Write
\[
K_o=\alpha\cup\delta\cup\chi,\qquad
K_s=\beta\cup\gamma\cup\chi,                         \tag{2}
\]
where the strands are ordered as in Note 146. The three simple cycles of \(\Theta\) are \(\Omega,K_o,K_s\).

**Theorem.** The cycles of \(\Theta\) alternating for the complete matching \(U_{35}\) are exactly:

| Strand lengths \((\alpha,\beta,\gamma,\delta)\) | \(U_{35}\)-alternating cycles in \(\Theta\) |
|---|---|
| \((2,2,1,1)\) | \(K_o\) |
| \((2,1,2,1)\) | \(K_o,K_s\) |
| \((1,2,1,2)\) | none |
| \((1,1,2,2)\) | \(K_s\) |

For every cycle \(K\) in this table, \(U^K=U_{35}\triangle E(K)\) is another actual complete class-\(35\) perfect matching, and the four terminal ends of \(U^K\triangle D_5\) have **the same pairing** as those of \(U_{35}\triangle D_5\). More precisely, there is exactly one edge \(h\) of \(K\cap\Omega\) in \(U_{35}\triangle D_5\), and the switch replaces this one-edge path by the complementary path \(K-h\) between the same two vertices. These assertions use only the actual row and owner classification, with no full-support or no-seed hypothesis.

**Proof.** The chord owners alternate \(UD,rC\), with \(UD\) at both ends. At each chord endpoint \(U\) therefore uses the chord, so \(\Omega\) is never \(U\)-alternating. From Note 146's four owner sequences the \(U\)-owned edges of \(\Omega\) are, in order, the first \(UZ\) edge of \(\alpha\); that edge and the \(UY\) edge of \(\gamma\); no edge; and the \(UY\) edge of \(\gamma\). Each arc \(\alpha\cup\delta\) or \(\beta\cup\gamma\) has length three. It alternates with the chord's \(UD,rC\) sequence exactly when it has one \(U\)-owned edge in its middle position. This gives the table, and exhausts the three simple cycles of \(\Theta\).

For a listed cycle \(K\), its chord \(UD\) edges belong to both \(U\) and \(D\). Its three-edge \(\Omega\) arc has exactly one \(U\)-owned edge \(h\), and \(D\) owns no edge of this arc: the possible \(YD\) or \(ZD\) edges in the four owner sequences occur on the *other* arc whenever that arc is \(U\)-alternating. Thus \((U\triangle D)\cap E(K)=\{h\}\). Alternating-cycle switching gives the actual matching \(U^K\). On \(K\), its difference with \(D\) is \(E(K)\setminus\{h\}\); outside \(K\), that difference is unchanged. Both local edge sets are paths between the endpoints of \(h\), so every global terminal pairing is unchanged. \(\square\)

**Dual class-five classification.** The cycles of \(\Theta\) alternating for \(D_5\) are exactly:

| Strand lengths \((\alpha,\beta,\gamma,\delta)\) | \(D_5\)-alternating cycles in \(\Theta\) |
|---|---|
| \((2,2,1,1)\) | \(K_s\) |
| \((2,1,2,1)\) | none |
| \((1,2,1,2)\) | \(K_o,K_s\) |
| \((1,1,2,2)\) | \(K_o\) |

Indeed the \(D\)-owned \(\Omega\) edges in the four rows are respectively \(YD\) on \(\beta\), none, \(YD\) on \(\beta\) together with \(ZD\) on \(\delta\), and \(ZD\) on \(\delta\). The three-edge arc of a listed cycle has one \(D\)-owned middle edge \(h\) and no \(U\)-owned edge; both matchings own its \(UD\) chord edges. Thus \((U\triangle D)\cap E(K)=\{h\}\) for every listed \(D\)-alternating cycle as well. Replacing \(D\) by \(D^K=D\triangle E(K)\) reroutes that one edge along \(K-h\) and leaves the terminal pairing unchanged. In particular, the Tait-complement switch on \(K_o\), which changes \(U\) in the first two patterns and \(D\) in the last two, is pairing-neutral without exact negative support. This strengthens the comparison at the end of Note 146.

**Critical-cycle consequence.** Let \(P_{35}\) be any actual class-\(35\) matching whose \(5\)-terminal partner with the fixed \(D_5\) differs from that of \(U_{35}\). Every component of \(U_{35}\triangle P_{35}\) is an even \(U\)-alternating proper cycle. Toggle these components one at a time. A component contained entirely in \(\Theta\) is one of the listed cycles and cannot change the pairing, even after other disjoint components have been toggled: they leave its local \(U,D\) masks unchanged, and the same one-edge-to-complementary-path argument applies. Hence every pairing-critical component of \(U_{35}\triangle P_{35}\) uses an edge outside \(\Theta\).

In particular, for an exact-Case-XII row with no common \(B_2+C_4\) seed, Note 137 supplies \(P_{35}=p_{35}\) with \(5\leftrightarrow4\), while negative support forces \(U_{35}+D_5\) to pair \(5\leftrightarrow1\). Its required critical cycle therefore cannot be confined to the aligned short theta core. In the \((2,1,2,1)\) pattern, the actual matchings \(U,U^{K_o},U^{K_s}\) are pairwise distinct and all have the same \(D\)-pairing; the no-seed \(p\) would be a **fourth** distinct class-\(35\) matching. In the \((2,2,1,1)\) and \((1,1,2,2)\) patterns, the analogous lower bound is three.

The dual \((1,2,1,2)\) pattern supplies three pairwise distinct class-five matchings \(D,D^{K_o},D^{K_s}\), all with the same pairing against the fixed \(U\). These counts concern complete actual masks, not merely three occurrence names in one BF row.

The \((2,1,2,1)\) pattern has an additional exact full-family relation:
\[
U^{K_o}\triangle U^{K_s}=E(\Omega),\qquad
U^{K_o}|_{E(\Omega)}=Y_3|_{E(\Omega)},\qquad
U^{K_s}|_{E(\Omega)}=Z_3|_{E(\Omega)}.             \tag{3}
\]
The chord cancels from the symmetric difference of \(K_o\) and \(K_s\), while their two three-edge \(\Omega\) arcs partition the hexagon. Here \(D_5\) uses no \(\Omega\) edge, yet this actual phase switch between two class-\(35\) matchings preserves its terminal pairing, because each endpoint matching already has the pairing of \(U\). Thus the six-port \(D\)-pattern of Note 147 is compatible with a pairing-neutral phase switch inside the complete matching family of every actual row of this owner type. This does not identify either endpoint with the canonical cross-half \(p_{35}\).

If the pole has girth at least five, the chord has at least three edges. The non-\(U\) phase of \(K_o\), when it is alternating, then contains all three owner pairs \(\{r,Y\},\{r,C\},\{Y,C\}\). The non-\(U\) phase of \(K_s\), when it is alternating, contains \(\{Z,C\},\{r,Z\},\{r,C\}\). Each triple has empty total owner intersection, yet each cycle is terminal-pairing-neutral for \(D_5\). Thus a three-owner certificate on the short theta core does not supply the pairing change needed by Note 137. The remaining obstruction must use external matching incidence and the full Case-XII closure.
