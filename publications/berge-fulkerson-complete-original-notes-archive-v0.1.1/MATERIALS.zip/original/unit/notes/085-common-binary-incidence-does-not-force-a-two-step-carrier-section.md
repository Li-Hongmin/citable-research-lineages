> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Common binary incidence does not force a two-step carrier section

The component-alignment obstruction isolated in
[Notes 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md)
and
[084](084-minimal-empty-companion-intersections-and-the-no-a-double-hit-criterion.md)
persists after all currently available Case-XII row relations are imposed
on one common binary incidence space.  In particular, exact forty-type
support, the literal pivot rows, the row transports, the target overloads,
formal partial-flip cubes, and the no-\(A\) double-hit condition do not force
a sequential two-splice section.

This is a strict abstract non-implication.  The first missing axiom is that
the binary vectors be the complete perfect-matching family of one common
cubic five-pole.

## Common-binary BF systems

A common-binary BF system consists of a finite set \(\mathcal M\) of
matching tokens, a common coordinate set \(E\), and vectors

\[
 \chi_M\in\{0,1\}^{E}\qquad(M\in\mathcal M).       \tag{1}
\]

Every token has a singleton or triple boundary class.  A designated BF row
is a six-multiset \(R\) of tokens satisfying both the required boundary
loads and

\[
 \sum_{M\in R}\chi_M=2\mathbf1.                  \tag{2}
\]

Unlike a real pole, the coordinates in this abstraction are not partitioned
into triples incident with cubic vertices, and \(\mathcal M\) is not required
to contain every perfect matching induced by such a partition.

## The countermodel

There is a common-binary BF system with

\[
 |\mathcal M|=125,qquad |E|=48,                  \tag{3}
\]

and fifty designated rows.  They comprise all 25 \(S\)--\(T\) cells, all
15 unordered \(S\)--\(S\) cells including the five loops, and the ten
two-branch transport rows of Note 057.  The five rows sharing a fixed
\(T\)-state reuse one literal right half, and every transport reuses the
three actual token identities specified by its source row.

The four canonical pivot rows occur literally:

\[
\begin{array}{c|c}
(13)(45)&(q_{13},A,X; r_{45},C,D)\\
(14)(23)&(q_{14},A,C; r_{23},B,X)\\
(24)(15)&(q_{24},B,C; r_{15},A,D)\\
(25)(34)&(q_{25},B,D; r_{34},Y,C).
\end{array}                                      \tag{4}
\]

There is no all-terminal token.  Exhaustive integer decomposition over the
common token pool finds no row of any unordered \(T\)--\(T\) type, including
the five \(T\)-loops.  Hence the support is exactly the forty Case-XII pair
types and excludes \(A=(12345)\), all \(T\)-loops, and all \(T\)--\(T\)
types.

## Six formal cubes and three failed targets

The three targets are

\[
\begin{array}{c|c|c|c}
 &\text{source cell}&\text{desired pair}&\text{overloaded quartet}\\ \hline
BDXY&(35)(23)&(Y,D)&BDXY\\
ACXY&(13)(34)&(A,X)&ACXY\\
ABDY&(35)(12)&(Y,D)&ABDY.
\end{array}                                      \tag{5}
\]

For the last target the model deliberately fixes the \((12)\)-half to
\((r_{12},A,B)\).  This strengthens the abstract countermodel; it is not a
claim that column saturation forces that literal half in a real pole.

Each target has two source-to-desired singleton replacements.  For each of
these six relations \(P\rightsquigarrow\widehat P\), the system contains
two more same-boundary tokens \(Z_0,Z_1\) with

\[
 \chi_{Z_0}+\chi_{Z_1}=\chi_P+\chi_{\widehat P}.  \tag{6}
\]

All four nonconstant two-component signatures occur in the common
coordinate system, so (6) supplies the full formal partial-flip square.
For every one of its four members there is a coordinate at which that token
is present and the corresponding four-anchor load is exactly two.  Thus
every cube member satisfies the \(D_2\)-hitting consequence of no
all-terminal cover from Note 084.

Nevertheless all three target quartets in (5) are overloaded.  Moreover,
for each source occurrence \(P\), each desired occurrence
\(\widehat P\), and each of the five possible current-row companions
\(N\), the forced vector

\[
 \chi_N+\chi_P-\chi_{\widehat P}                 \tag{7}
\]

is unequal to every compatible token vector.  This excludes all 30
first-step endpoint memberships.  The six forced-intermediate vectors from
Note 082 are also unequal to every compatible token.  Therefore every
sequential and preparatory two-splice fibre for all three targets is empty.

## Consequence

The construction proves

\[
\begin{split}
&\text{exact 40 support + literal pivots + Note 055/057 reuse}\\
&\quad+\text{three overloads + formal flip cubes + }D_2\text{-hitting}
\end{split}
\not\Longrightarrow
\text{a Note-082 two-step carrier section}        \tag{8}
\]

for common binary incidence vectors.  Adding further support labels,
edge-load equalities, or component signatures at this level cannot prove
the desired section, because the displayed system already satisfies all of
them simultaneously.

The system is not a graph and therefore is not an exact-Case-XII pole or a
counterexample to the Berge--Fulkerson conjecture.  A positive proof must
now use the shared trivalent vertex partition of one cubic five-pole and the
complete perfect-matching closure induced by that partition.  Equivalently,
it must derive a dependent pair-sum membership from a property that cannot
be expressed solely by common binary edge loads and the designated rows.

The deterministic construction, complete token vectors, and Omen output are
frozen in the
[verification bundle](../computations/bundles/joint-carrier-common-binary-countermodel/README.md).
