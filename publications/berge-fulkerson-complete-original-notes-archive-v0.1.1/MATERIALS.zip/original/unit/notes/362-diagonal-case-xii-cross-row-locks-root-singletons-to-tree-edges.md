> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A diagonal Case-XII cross row locks its root singletons to tree edges

Work in the complete exact-Case-XII \(K_{3,3}\) double-star of [Notes 358–361](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md). Name its exterior marked edges
\[
 a=r_1l_1,\qquad b=r_1l_2,\qquad c=r_2l_1,\qquad d=r_2l_2,
\]
with subdivision vertices \(t_a,t_b,t_c,t_d\). Suppose the two \(e\)-incident allowed states are the **diagonal pair** \(ea,ed\in S\), so \(eb,ec\in T\). The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ed)\) row and forbids both \((eb)(ec)\) and the loops \([eb],[ec]\).

**Theorem (root-tree lock).** In **every** actual \((ea)(ed)\) row, the singleton-\(a\) occurrence uses the tree edge incident with the root of its \(ea\)-triple, and the singleton-\(d\) occurrence uses the tree edge incident with the root of its \(ed\)-triple. The assertion holds for arbitrary complete shore matchings, shore order, and cycle rank. If the root of the \(ea\)-triple is \(r_1\), for example, singleton-\(a\) uses \(r_1u_1\); if its root is \(l_1\), it uses \(l_1u_3\).

**Proof.** Write the two singleton-\(e\) colours as \(E,F\), singleton-\(a\) as \(A\), singleton-\(d\) as \(D\), and \(I=\{E,F,A,D\}\). At every exterior vertex, the residual singleton colours on its edges partition \(I\). At \(t_b,t_c\) both triples use the terminal semiedge, so the two marked halves carry complementary two-sets. Symmetry of the marked square preserving the diagonal pairs \(\{a,d\}\) and \(\{b,c\}\) leaves two root placements to check.

**Both roots on the \(r\)-side.** Let the \(ea\)-triple root at \(r_1\) and the \(ed\)-triple at \(r_2\). Denote by \(\alpha,\beta\) the singleton colours on \(t_ar_1,r_1u_1\), and by \(\gamma,\delta\) those on \(t_dr_2,r_2u_2\). Thus \(\alpha\ne A\), \(\gamma\ne D\). At \(r_1\), the edge \(r_1t_b\) carries the other pair \(I\setminus\{\alpha,\beta\}\). Complementation at \(t_b\) and at \(l_2\), whose tree edge is occupied by both triples, makes the pair on \(t_dl_2\) again \(I\setminus\{\alpha,\beta\}\). At \(t_d\), that pair is \(I\setminus\{D,\gamma\}\). The symmetric path \(r_2-t_c-l_1-t_a\) gives the second equality:
\[
             \{\alpha,\beta\}=\{D,\gamma\},\qquad
             \{\gamma,\delta\}=\{A,\alpha\}.             \tag{1}
\]
The only solutions are
\[
\begin{array}{c|cccc}
&\alpha&\beta&\gamma&\delta\\\hline
\text{tree--tree}&D&A&A&D\\
\text{mark--mark}&H&D&H&A\quad(H\in\{E,F\}).
\end{array}                                                \tag{2}
\]
In the second line, singleton-\(a\) uses \(r_1t_b\) and singleton-\(d\) uses \(r_2t_c\). Switch the exterior alternating terminal paths
\[
 s_a,\ t_ar_1,\ r_1t_b,\ s_b
 \qquad\text{and}\qquad
 s_d,\ t_dr_2,\ r_2t_c,\ s_c.                              \tag{3}
\]
The two triples acquire states \(eb,ec\), while the singleton boundaries become \(b,c\). This is an actual forbidden \((eb)(ec)\) row, so only the first line of (2) remains: \(\beta=A,\delta=D\).

**Roots on opposite sides.** Let the \(ea\)-triple root at \(r_1\) and the \(ed\)-triple at \(l_2\). Use \(\alpha,\beta\) for the singleton colours on \(t_ar_1,r_1u_1\), and \(\gamma,\delta\) for those on \(t_dl_2,l_2u_4\). The chain \(t_a-l_1-t_c-r_2-t_d\), with complementary two-sets at its intermediate marked vertices and leaves, and the two halves of \(t_b\) give
\[
       \{A,\alpha\}=I\setminus\{D,\gamma\},\qquad
       \{\alpha,\beta\}=I\setminus\{\gamma,\delta\}.     \tag{4}
\]
The first equality forces \(\{\alpha,\gamma\}=\{E,F\}\); the second then forces \(\{\beta,\delta\}=\{A,D\}\). If \(\beta=D,\delta=A\), singleton-\(a\) uses \(r_1t_b\) and singleton-\(d\) uses \(l_2t_b\). Switching the two paths
\[
 s_a,\ t_ar_1,\ r_1t_b,\ s_b
 \qquad\text{and}\qquad
 s_d,\ t_dl_2,\ l_2t_b,\ s_b                              \tag{5}
\]
turns **both** triples into state \(eb\), producing the forbidden loop \([eb]\). Hence \(\beta=A,\delta=D\). The other root placements follow by the indicated square symmetries. Every switch uses complete actual matching occurrences but changes only exterior edges, so the shore is unrestricted. \(\square\)

**All \(S\)--\(T\) rows incident with \(ea\) or \(ed\).** The same root-tree lock holds in a wider class of required rows. In any genuine \((ea)(q)\) row with \(q\in T\), **every** singleton-\(a\) occurrence uses the tree edge at the root of its \(ea\)-triple. At that root \(x\), the other marked edge is \(b\) or \(c\), and its \(e\)-state belongs to \(T\). If a singleton-\(a\) matching used that marked half-edge, its four-edge alternating path with the \(ea\)-triple would switch the latter to state \(eb\) or \(ec\), leaving the opposite \(q\in T\) triple untouched. The resulting \(T\)--\(T\) row is forbidden. The singleton cannot use the \(a\)-half at \(x\), since it already uses terminal \(a\), so it must use the root tree edge. The symmetric assertion holds for every \((ed)(q)\) row with \(q\in T\).

If \(q\) also contains \(a\), both singleton-\(a\) occurrences use that same root tree edge, loading it twice. The \(q\)-triple must then match the root through a marked half-edge. In particular, in a required \((ea)(ad)\) row it must choose the **same \(a\)-half** as the \(ea\)-triple: the other marked edge at the root is \(b\) or \(c\), neither selected by a state-\(ad\) triple. This is a full-matching incidence conclusion, independent of the shore masks. If \(ac\in T\), the same-half conclusion for \((ea)(ac)\) holds when the \(ea\)-root is \(r_1\); when it is \(l_1\), the \(ac\)-triple may instead use the \(c\)-half at \(l_1\).

The \((ea)(ad)\) row has a second orientation lock: its \(ad\)-triple chooses the \(d\)-half **opposite the side** of the \(ea\)-root. Suppose the \(ea\)-root is \(r_1\), and assume for contradiction that the \(ad\)-triple chooses \(t_dr_2\). Both triples then match \(l_2\) through \(u_4l_2\): neither selects a marked half at \(l_2\). At \(r_1\), the two triples saturate \(r_1t_a\), and the two singleton-\(a\) occurrences saturate \(r_1u_1\); hence \(r_1t_b\) carries the singleton-\(e\) and singleton-\(d\) colours. Since both triples select terminal \(b\), the other half \(t_bl_2\) carries the two singleton-\(a\) colours. At \(l_2\), the already doubled tree edge and this doubled \(b\)-half leave \(t_dl_2\) to the singleton-\(e\) and singleton-\(d\) occurrences. But singleton-\(d\) selects terminal \(d\) and cannot use a \(d\)-half. This contradiction forces \(t_dl_2\). Interchanging the \(r\)- and \(l\)-sides shows that an \(ea\)-root at \(l_1\) forces \(t_dr_2\). No shore information is used.

**Shore-load consequence for same-side roots.** In the first case of the proof, exact support forces the tree--tree line of (2). Let \(Q_1,Q_2\) be the two zero-port shore matchings. If \(Z-Q_1\) has no odd closed component, [Note 360](360-k33-double-star-exact-case-xii-forces-distinct-zero-port-shore-matchings.md) gives three odd paths \(ep_0,p_1p_2,p_3p_4\). The locked exterior colours give \(A_e=\{E,F\}\) and \(A_3=\bar A_4\). If \(\xi,\eta\) are the singleton colours on \(au_1,au_2\), then \(\xi\ne\eta\),
\[
 A_0=\{\xi,\eta\},\quad
 A_1=I\setminus\{A,\xi\},\quad
 A_2=I\setminus\{D,\eta\}.                               \tag{6}
\]
Here \(\xi\ne A\) and \(\eta\ne D\) by matching incidence at \(u_1,u_2\). With \(L=\{E,F\}\), the four-colour distance satisfies the exact identity
\[
 d(L,A_0)+d(A_1,A_2)
 =d(L,\{\xi,\eta\})+d(\{A,\xi\},\{D,\eta\})=2.           \tag{7}
\]
To verify it, note that \(\xi\) belongs to exactly one of \(L,\{D\}\), and \(\eta\) to exactly one of \(L,\{A\}\); expanding both two-set distances gives (7). The [Note 361 defect-distance lemma](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md) therefore requires at least two \(Q_2\)-edges **across** the odd paths \(ep_0,p_1p_2\). It also requires at least two on \(p_3p_4\), since \(A_3=\bar A_4\). Thus \(Q_2\) uses at least four edges of the three \(Q_1\)-paths and \(|Q_1\triangle Q_2|\ge8\). The symmetric claim holds when both roots are on the \(l\)-side. This remains a necessary bound, not an exclusion of the required row.

Combined with Note 361, the diagonal \(T\) orientation now has compulsory root constraints across its \(S\)-loops, the \((ea)(ed)\) row, and every \(S\)--\(T\) row incident with \(ea\) or \(ed\). The \((ea)(ad)\) row additionally fixes both selected marked halves up to reflection. Whether distinct zero-port shore matchings and the two-port \(ad\)-triple shore fibre can realize these rows together with all other required states remains open. This proof is hand-derived and has not received an independent review; no local mathematical recomputation was used.
