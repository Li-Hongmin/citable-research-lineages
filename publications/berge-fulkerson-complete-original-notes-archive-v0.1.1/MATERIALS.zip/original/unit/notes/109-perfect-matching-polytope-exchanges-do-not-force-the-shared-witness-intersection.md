> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Perfect-matching polytope exchanges do not force the shared-witness intersection

The complete perfect-matching family of a rooted cubic five-pole, regarded as
the vertex set of its perfect-matching incidence polytope, supplies no further
automatic exchange capable of forcing the sixteen-context shared-witness
intersection left by Notes 104--108.  Single-component exchange is conditional
on two already existing perfect matchings.  In the same-$K$, fixed-leakage
section, its entire effect is to exchange the two colours of an already fixed
degree-two residual component.  The missing target-phase matching is therefore
an antecedent of the exchange rule, not a consequence of it.

This is an order-independent closure of the alternating-cycle/exchange-graph
route under the currently frozen closure axioms.  It is not a cubic-pole
counterexample and does not assert that an exact-Case-XII pole exists.

## Exchange graph of the complete family

Let $G$ be a rooted cubic five-pole and let ${\cal P}(G)$ be its complete set
of $0/1$ perfect-matching masks on proper edges and semiedges.  For
$M,M'\in{\cal P}(G)$, every internal vertex has degree zero or two in
$M\triangle M'$.  Its nontrivial components are therefore even alternating
cycles and alternating terminal-to-terminal paths.  Flipping any union of
components gives another member of ${\cal P}(G)$.  If $M$ and $M'$ have the
same boundary mask, only closed even components occur.

Thus the boundary-fixed part of the usual exchange graph has an edge for a
single alternating-cycle flip.  More generally, the vertices between a fixed
pair sum $R=M+M'$ are exactly the two-colourings of the nondoubled components
of the degree-two residual multigraph $R$.  Its exchange graph is a cube, one
coordinate for each such component.  This description uses the complete PM
family and is valid at every order.

## The decisive same-$K$, fixed-$W$ section

Fix one of the twelve non-entry contexts of Note 104.  Use $T$ for its target,
$P\in{\cal C}_a(T)$ for an agreement-core matching, and $W$ for the leakage
matching required to equal the opposite operative witness as a complete mask.
Suppose Note 106 supplies

\[
                    K=P+N+W.                              \tag{1}
\]

Inside the section with $K$ and $W$ fixed, every allowed exchange preserves

\[
                    P+N=K-W.                              \tag{2}
\]

It can only swap the two colours $P,N$ on components of the fixed residual
$K-W$.  In particular, a vertex of this section whose first coordinate is
$T$ exists if and only if

\[
                    N'=N+P-T                              \tag{3}
\]

is a $0/1$ perfect-matching mask.  On every component of $P\triangle T$ this
is equivalent to $N$ using the target phase, exactly the Align/Sep criterion
of Note 082.  No cycle flip can make (3) a vertex when it is not already
binary: all exchanges available in the section merely enumerate the
two-colourings of (2).

The other automatic exchange has the complementary defect.  The agreement
row gives $(L,P)\mapsto(L+P-T,T)$, but changes the anchored load to
$K-P+T$.  Hence it leaves the same-$K$ section only when $P=T$.  Exchanging
the two residual colours in (1) preserves $K$ but changes the designated full
mask $W$ whenever $W$ participates.  Paired exchanges do not repair this:
preserving both $K$ and $W$ reduces them again to the colour swaps of (2), so
their endpoint condition is still (3).

The four entry contexts have $P=T$ and no nontrivial phase component.  The
calculation above applies verbatim to the other twelve contexts.

## Exact missing graph-theoretic proposition

Consequently the complete-family exchange axiom, boundary projections,
same-$K$ completion, agreement-core closure, and fixed leakage identity do not
form a Helly or rectangle-completion principle.  The required new proposition
is the following cross-context statement.

> **Exact-Case-XII synchronized rectangle lemma.**  In every rooted cubic
> five-pole whose complete PM closure has exact Case-XII support and carries
> the fixed Note-101 rows, at least one of the sixteen Note-104 contexts admits
> complete masks $(P,N,W)$ such that $K=P+N+W$, $P$ belongs to the prescribed
> agreement core, $W$ is literally the prescribed opposite-carrier operative
> witness on every proper edge and semiedge, and, in a non-entry context,
> $N+P-T$ is an actual perfect matching (equivalently $N$ has the target phase
> on every component of $P\triangle T$).

This lemma is not an alternating-cycle exchange identity.  Its conclusion
asserts the existence of a vertex $N+P-T$ in a cross-carrier fibre; the
ordinary exchange rule can be invoked for that rectangle only after this
vertex, or equivalently its target-phase condition, is known.  Notes 101 and
108 show that the fixed row identities do not supply the condition, while the
cube description above shows that taking the complete exchange closure adds
no operation beyond recolouring already present residual components.

## Consequence

Therefore the currently frozen graph-induced closure axioms are insufficient
to prove the common intersection by a single or paired alternating-cycle
exchange.  Outcome C holds for R2 at this scope: the route is closed exactly
at the synchronized rectangle lemma above.  Proving that lemma would be new
graph theory beyond the frozen exchange identities and would reconnect to the
shared-witness proposition immediately.  Refuting it still requires a real
rooted cubic pole with an independently replayable complete PM-closure
certificate; the present result is not such a counterexample.
