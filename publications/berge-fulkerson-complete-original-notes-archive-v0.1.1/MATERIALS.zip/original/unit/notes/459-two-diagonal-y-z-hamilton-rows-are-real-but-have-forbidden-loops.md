> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two diagonal \(Y,Z\)-forbidden Hamilton rows are real but have forbidden loops

The two diagonal port forms left by [Note 458(9)](458-the-y-z-forbidden-hamilton-pair-has-five-tree-signatures.md) are attained by genuine \((eY)(eX)\) BF rows on 21-vertex simple connected cubic five-poles. Thus their exclusion from exact Case XII cannot rest on row feasibility. Both examples have a direct \([eY]\) Tait loop in the **complete** support, so neither is an exact-Case-XII pole.

Use the exterior of Note 458(1): tree \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\), marks \((X,Y,Z,W)=(14,15,26,36)\), and complete matching occurrences \(P=eY,R=eX,K=X,J=Y,a=e,b=e\). Add shore vertices \(q_e,q_1,\ldots,q_5\), join \(q_i\) to \(u_i\), attach terminal \(e\) to \(q_e\), and join the shore vertices in the respective six-cycle below. All original prism edges are subdivided, so each pole has girth at least five.

For the first diagonal form
\[
(p_1,p_2,p_3,p_4,p_5)=(ab,ab,KJ,Ja,Kb),\qquad e=ab,
\tag{1}
\]
take the following exterior pairs. At \(u_i\) the slots are first-end half, second-end half, port; at marked subdivisions they are terminal and the halves ordered \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(KJ,PR,ab)&(KJ,PR,ab)&(ab,PR,KJ)
 &(Kb,PR,Ja)&(Ja,PR,Kb)
\end{array}
\tag{2}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(PK,Rb,Ja)&(RJ,Pa,Kb)&(PR,ab,KJ)&(PR,KJ,ab).
\end{array}
\tag{3}
\]
Choose shore cycle \(q_1,q_4,q_3,q_5,q_2,q_e,q_1\) and place, in that cyclic edge order, the label pairs
\[
PK,\quad Rb,\quad Pa,\quad RJ,\quad PK,\quad RJ.
\tag{4}
\]
At each shore vertex, its two incident cycle-edge pairs and port pair (1) partition \(\{P,R,K,J,a,b\}\).

For the second diagonal form
\[
(p_1,p_2,p_3,p_4,p_5)=(Ja,Ja,Kb,ab,Kb),\qquad e=ab,
\tag{5}
\]
take
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(Kb,PR,Ja)&(Kb,PR,Ja)&(Ja,PR,Kb)
 &(KJ,PR,ab)&(Ja,PR,Kb)
\end{array}
\tag{6}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(PK,RJ,ab)&(RJ,Pa,Kb)&(PR,Ja,Kb)&(PR,Kb,Ja).
\end{array}
\tag{7}
\]
Choose shore cycle \(q_1,q_2,q_e,q_3,q_5,q_4,q_1\) with successive edge pairs
\[
Pb,\quad RK,\quad PJ,\quad Ra,\quad PJ,\quad RK.
\tag{8}
\]
Again every shore vertex has a six-label partition. In both constructions every subdivision triple is a partition, and at original prism vertices \(1,\ldots,6\) the incident pairs are, respectively,
\[
\begin{array}{c|cccccc}
 &(1)&(2)&(3)&(4)&(5)&(6)\\ \hline
\text{first}
 &(KJ,Rb,Pa)&(PR,KJ,ab)&(PR,ab,KJ)
 &(PR,Kb,Ja)&(PR,Ja,Kb)&(PR,KJ,ab)\\
\text{second}
 &(Kb,RJ,Pa)&(PR,Kb,Ja)&(PR,Ja,Kb)
 &(PR,KJ,ab)&(PR,Ja,Kb)&(PR,Kb,Ja)
\end{array}
\tag{9}
\]
which are partitions as well. Hence (1)--(9) give six **complete** perfect matchings covering every edge twice. Their terminal pairs are \(e=ab,X=PK,Y=RJ,Z=W=PR\), giving the claimed old \((eY)(eX)\) BF type.

Let \(Q_P\) be the complete zero-port shore matching of \(P\), the first, third, and fifth edges of either six-cycle. Its complement contains three three-edge shore paths and no closed component. Their port pairings are
\[
\begin{array}{c|c|c}
 &\text{shore complement}&\text{\(eY\)-triple root}\\ \hline
\text{first}&ep_1\mid p_4p_3\mid p_5p_2&1\\
\text{second}&ep_2\mid p_3p_5\mid p_4p_1&5.
\end{array}
\tag{10}
\]
By [Note 359's exterior table](359-two-root-parity-gate-and-k33-sharpness.md), the \(eY\)-triple rooted at \(1\) has complementary pairing \(Yp_5\mid p_1p_4\mid p_2p_3\), and the triple rooted at \(5\) has \(Yp_3\mid p_1p_2\mid p_4p_5\). Each row of (10) glues with its indicated exterior pairing to a **single** open \(e\)--\(Y\) route. The exterior complement's possible pure cycles are even by Note 359. Thus the whole triple complement is even and alternates into two singleton matchings, yielding a Tait colouring and, by doubling, a genuine forbidden BF loop \([eY]\).

These real rows sharpen Note 458: the diagonal phases are actual full-row possibilities, while their displayed small shores have forbidden complete support. Whether an irreducible larger shore can realize either diagonal row without forbidden support, and whether the other four tree signatures survive exact Case XII, remain open. The certificates are hand-derived and await independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 460](460-both-diagonal-y-z-hamilton-rows-force-a-forbidden-double-triple.md) closes the first question for these port forms at every shore order: every genuine row of either form forces forbidden \((eY)(eZ)\) while preserving its six complete shore restrictions.
