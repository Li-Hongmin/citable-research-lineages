> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Petersen two-sums: an exact multirow identity gate

[Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md) lifts two BF rows with any shared complete matchings that occur once in each row through every BF-covered closed factor. Three or more rows have a further compatibility condition. For the Petersen factor, that condition is an exact small graph-colouring test, and it fails for three actual BF rows of a cubic five-pole even though each pair of rows lifts.

## Exact Petersen-factor criterion

Let \(H_0\) be a cubic five-pole with a non-loop proper edge \(e\). Let \(\mathscr R\) be a finite family of **specified ordered BF rows** of \(H_0\). Mark any desired equalities between their matching occurrences; each equivalence class of marked occurrences must be the same actual matching of \(H_0\). Treat every unmarked occurrence as its own class. Thus every class \(u\) has an unambiguous bit \(b(u)=\mathbf1_{e\in u}\).

For \(b=0,1\), form a graph \(G_b\) whose vertices are the occurrence classes with bit \(b\), joining two classes whenever they occur in the same row. If one class occurs twice in a row, retain the resulting loop. Let \(P\) be a Petersen graph with distinguished edge \(f\), and put \(H=H_0\oplus_{e,f}P\).

**Theorem.** The specified rows admit simultaneous BF lifts to \(H\) preserving all marked complete-matching equalities if and only if

\[
G_1\text{ is 2-colourable and }G_0\text{ is 4-colourable}.       \tag{1}
\]

The condition concerns these marked rows, not the existence of some other BF rows or of a different assignment of the marked matchings.

**Proof.** The Petersen graph has exactly six perfect matchings, two containing \(f\) and four avoiding it. Its unique six-occurrence BF cover uses each once; the uniqueness and edge incidences are established in [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md). Every lifted row therefore assigns its two \(e\)-containing occurrences bijectively to the two \(f\)-containing Petersen matchings, and its four other occurrences bijectively to the remaining four. Literal equality across rows gives one assignment per occurrence class. Cooccurring classes must receive different factor matchings, which is exactly (1). This proves necessity, including the obstruction from a loop.

Conversely, use the two colours of \(G_1\) as the two \(f\)-containing Petersen matchings and the four colours of \(G_0\) as the four avoiding matchings. Every exterior BF row contains exactly two \(e\)-occurrences and four avoiding occurrences, so proper colouring makes its factor projections the six Petersen matchings, each once. Splicing with equal distinguished-edge bits gives a BF row of \(H\). A class receives one fixed factor matching throughout, so all marked identities lift literally. \(\square\)

## Three genuine rows that fail together

Let \(C\) be the five-cycle pole with vertices \(v_1,\ldots,v_5\), cycle edges \(v_iv_{i+1}\) (indices modulo five), and terminal semiedge \(s_i\) at \(v_i\). Colour its successive cycle edges \(0,1,0,1,2\), and give each semiedge the missing colour at its vertex. This yields three actual perfect matchings \(N_0,N_1,N_2\) with boundaries \(\{5\},\{1\},\{2,3,4\}\). In particular \(h=v_1v_2\) belongs to \(N_0\), while \(N_1,N_2\) avoid \(h\); duplicating the three matchings is a BF row.

Let \(Q\) be the cube on binary vertices \(xyz\). Write \(M_0\) for its four edges in the \(x\)-direction. Obtain \(M_1\) from \(M_0\) by flipping the square face \(z=1\), and \(M_2\) by flipping the square face \(y=1\). Explicitly,

\[
\begin{aligned}
M_0={}&\{000\!:\!100,001\!:\!101,010\!:\!110,011\!:\!111\},\\
M_1={}&\{000\!:\!100,010\!:\!110,001\!:\!011,101\!:\!111\},\\
M_2={}&\{000\!:\!100,001\!:\!101,010\!:\!011,110\!:\!111\}.
\end{aligned}                                                   \tag{2}
\]

All three contain \(e=000\!:\!100\) and avoid \(g=000\!:\!010\). Form the thirteen-vertex genuine five-pole \(H_0=C\oplus_{h,g}Q\). The three full matchings \(U_i=N_1\oplus M_i\) of \(H_0\) contain the surviving proper edge \(e\).

For every pair \(i<j\), the multigraph \(2E(Q)-M_i-M_j\) is bipartite and 4-regular. Repeated application of Hall's theorem decomposes it into four perfect matchings. These four together with \(M_i,M_j\) form a BF cover of \(Q\). At \(g\), the selected pair avoids the edge and exactly two of the other four matchings use it. Pair \(M_i,M_j\) with the two copies of \(N_1\), the two \(g\)-using matchings with the copies of \(N_0\), and the remaining two with the copies of \(N_2\). The result is an actual BF row \(R_{ij}\) of \(H_0\) containing \(U_i,U_j\) as literal complete matchings. Relabelling terminal \(s_5\) as terminal 4 and the other terminals bijectively makes each row an allowed Case-XII \([14]\) boundary type; no exact-support claim is made.

Mark \(U_i\) as one identity across the two rows in which it occurs. The three rows \(R_{01},R_{02},R_{12}\) have an \(e\)-bit cooccurrence triangle \(U_0U_1U_2U_0\). Thus \(G_1\) is not 2-colourable. After a Petersen insertion at \(e\), no simultaneous lift of these three specified rows can preserve all three identities. Any two of the rows do lift: they share only one marked identity, so [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md)'s two-row slot argument applies. This is a real-graph obstruction to marked-row simultaneous lifting even when all actual perfect matchings are allowed. The example is not exact Case XII: the five singleton matchings of \(C\), together with the matching containing all five semiedges, double-cover every edge of \(C\), giving an all-terminal BF type. The BF-covered cube factor preserves that complete-support type by [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md).

There is no conflict with Note 118's six-row *existence* equivalence under negative Case-XII support. That theorem lifts the two-row seed and then chooses new saturated decompositions; it does not preserve every occurrence of a previously marked six-row assignment.

## Case-XII rectangle interface

For a target-\(Y\) full-projection rectangle as in [Note 117](117-existential-case-xii-rectangle-transfers-through-colourable-two-sums.md), three BF rows include the state-\(14\) seed row containing \(B,C\), the source row containing \(B,W\), and the opposite-carrier row containing \(C,W\). If one proper edge belongs to all three distinct complete matchings \(B,C,W\), their marked-row cooccurrence graph contains the same triangle. A Petersen factor inserted there cannot carry this *particular* literal rectangle certificate through its three rows. No exact-Case-XII pole with such a rectangle is asserted here, and the result does not exclude a different certificate after insertion. It identifies the precise additional identity gate between the two-row seed theorem and a multirow rectangle transfer through an arbitrary BF-covered factor.
