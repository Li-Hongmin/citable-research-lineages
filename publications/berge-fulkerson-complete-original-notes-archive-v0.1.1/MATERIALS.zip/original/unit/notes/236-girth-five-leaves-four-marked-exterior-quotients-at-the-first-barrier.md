> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth five leaves four marked exterior quotients at the first barrier

Keep the minimum-host one-five-cut profile with \(|U|=3\), one odd shore \(C\) carrying the internal mark \(e\), and four singleton exterior vertices \(W\). [Note 234](234-three-exterior-graphs-for-the-first-surviving-one-shore-barrier.md) classifies the unmarked graph \(K=F[U,W]\) into a six-cycle with a pendant \(W\)-leaf, a subdivided three-leaf claw, or a seven-vertex path. This note places the two or one exterior \(W\)--\(W\) marks. The \(W\)--\(C\) marks occupy the other available incidences at \(W\).

**Four marked quotients.** Up to reflection of the exterior and exchange of its equally situated vertices, the necessary marked exterior shapes are exactly:

| Unmarked \(K\) | Exterior \(W\)--\(W\) marks | Exterior \(W\)--\(C\) marks |
|---|---|---|
| \(C_6\) plus pendant \(W\)-leaf \(p\) | \(p q\), where \(q\) is the unique cycle \(W\)-vertex **not** sharing \(p\)'s \(U\)-neighbour | one at \(p\), one at each of the other two cycle \(W\)-vertices |
| subdivided claw, centre \(w_0\), leaves \(w_1,w_2,w_3\) | \(w_1w_2,\ w_2w_3\) | one at each endpoint leaf \(w_1,w_3\) |
| path \(w_0-u_1-w_1-u_2-w_2-u_3-w_3\), type P | \(w_0w_2,\ w_0w_3\) | one at \(w_1\), one at \(w_3\) |
| same path, type Q | \(w_0w_2,\ w_1w_3\) | one at \(w_0\), one at \(w_3\) |

The reflection of type P has \(W\)--\(W\) marks \(w_0w_3,w_1w_3\), with \(W\)--\(C\) marks at \(w_0,w_2\). The four rows are necessary quotient types, not exact-Case-XII realizations; mark endpoints inside \(C\) and the full shore matching relation remain unrestricted here.

**Proof.** If two vertices \(w,w'\in W\) share a neighbour \(u\in U\), a marked edge \(ww'\), subdivided at its terminal vertex \(t\), would make the proper four-cycle
\[
w-u-w'-t-w
\]
in the opened five-pole, contrary to its girth at least five from [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md). Hence a \(W\)--\(W\) mark can join only a pair at distance at least four in \(K\). The number of such marks is \(r-1\), while \(5-r\) marks join \(W\) to \(C\), by [Note 234](234-three-exterior-graphs-for-the-first-surviving-one-shore-barrier.md).

In the \(r=2\) six-cycle shape there is one \(W\)--\(W\) mark. Every two cycle \(W\)-vertices share a \(U\)-neighbour. The pendant leaf \(p\) shares its \(U\)-neighbour with two of the three cycle \(W\)-vertices. Thus its only allowed partner is the third cycle vertex \(q\). The marked degree of \(p\) is two, so its other mark joins \(C\); the two cycle \(W\)-vertices outside \(q\) each need one \(C\)-mark.

In the \(r=3\) claw shape there are two \(W\)--\(W\) marks. The centre \(w_0\) has unmarked degree three and no marked incidence. The three leaves each need two marked incidences. Core simplicity makes the two \(W\)--\(W\) marks distinct edges among the three leaves, so they form a path; its end leaves each require one \(C\)-mark.

Finally, in the \(r=3\) seven-vertex path the end vertices \(w_0,w_3\) have marked degree two, while \(w_1,w_2\) have marked degree one. Among the six pairs of \(W\), exactly
\[
w_0w_2,\quad w_0w_3,\quad w_1w_3
\]
do **not** share a \(U\)-neighbour. Choose two of these three possible \(W\)--\(W\) marks. The choices containing \(w_0w_3\) are reflections of one another and give type P; the other choice gives type Q. The remaining two marked incidences attach to \(C\) exactly as in the table. This exhausts the possibilities. \(\square\)

The classification fixes the marked exterior before any cyclic-shore analysis. [Note 235](235-the-claw-connector-excludes-the-two-endpoint-e-neighbours.md) already excludes one complete \(e\)-neighbour-pair orbit in the claw row. For the other rows and neighbour pairs, complete exact Case XII still requires actual six-matching closure; neither the four quotient types nor their triple fibres certify existence.
