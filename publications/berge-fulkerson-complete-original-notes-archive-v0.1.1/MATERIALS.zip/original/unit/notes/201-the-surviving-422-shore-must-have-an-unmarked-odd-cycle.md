> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The surviving \((4,2,2)\) shore must have an unmarked odd cycle

Assume a genuine marked \((4,2,2)\) five-pole has complete exact Case-XII BF support. By [Note 200](200-two-kempe-switches-balance-the-422-exterior-connector.md), after relabelling its allowed cycle is
\[
S=p-c-q-d-e-p,
\quad H=I_q=I_c=E=1,                                      \tag{1}
\]
and every \(S\)--\(T\) half-load is one on the full exterior connector. Here \(F_C=F[C]\) is the **unmarked** odd component of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md); the internal mark \(e\) is *not* an edge of \(F_C\).

**Theorem.** \(F_C\) is non-bipartite. Hence a putative exact-Case-XII pole in this quotient has an odd cycle wholly within the unmarked cyclic shore, without using the internal mark \(e\) or any exterior connector edge.

**Proof.** Suppose \(F_C\) is bipartite, with parts \(L,R\). Because \(H=1\), deleting \(v_h\) leaves a perfect matching. Choose the names so that \(|L|=|R|+1\). Then \(v_h\in L\). The deletion matchings \(I_q=I_c=1\) also put the \(C\)-endpoints \(v_q,v_c\) in \(L\).

Take any actual required \((de)(pq)\) BF row, and saturate its \(S\)-half to state \(de\) as in Note 200. Name its triple, singleton-\(d\), and singleton-\(e\) matchings \(X,Y,Z\). Their selected \(C\)-endpoints, including endpoints reached through halves of the subdivided internal mark, are exactly
\[
\begin{array}{c|c}
X&\{e_X\}\\
Y&\{q,c,e_Y\}\\
Z&\{p,d,h\}.
\end{array}                                                       \tag{2}
\]
Indeed, \(X\) selects the internal \(e\)-half, \(dw_2\), and \(uw_1\); Note 200 forces \(Y\) to use \(uw_2,pw_1\) and \(Z\) to use \(h,qw_1,cw_2\). The remaining marked subdivisions use their \(C\)-halves exactly as displayed.

For any perfect matching whose selected \(C\)-ports are \(D\), the residual matching inside bipartite \(F_C-D\) requires
\[
|D\cap L|-|D\cap R|=|L|-|R|=1.                         \tag{3}
\]
Apply (3) to the three actual matchings in (2). The one-port matching \(X\) puts the selected endpoint \(e_X\) in \(L\). Since \(q,c\in L\), the three-port matching \(Y\) puts its selected endpoint \(e_Y\) in \(R\). Thus the two endpoints of the internal mark \(e\) lie in opposite parts. The matching \(Z\) selects \(h\in L\), so exactly one of \(p,d\) lies in \(R\) and the other lies in \(L\).

Extend the bipartition from \(C\) to the proper-edge graph of the opened five-pole. Put \(u\) and all five marked subdivision vertices \(t_p,t_q,t_c,t_d,t_e\) in \(R\), and put \(w_1,w_2\) in \(L\). All unmarked edges of \(F_C\), the edges at \(u,w_1,w_2\), and the four fork-side marked halves cross the partition. Of the four outer shore-side marked halves, exactly the one whose \(C\)-endpoint is the \(R\)-vertex among \(p,d\) lies within \(R\). Of the two halves of \(e\), exactly \(t_e e_Y\) lies within \(R\). Every other proper edge crosses. Therefore deleting these **two** proper edges makes the entire proper-edge graph bipartite, with all five terminal vertices in \(R\).

If the two exceptional edges share their \(C\)-endpoint, they are adjacent, contradicting [Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md). Otherwise they are disjoint and form [Note 127's same-side \(5+0\) branch](127-two-edge-bipartization-profiles-and-tait-blockers.md). Its balance equation makes every singleton-boundary perfect matching use exactly one exceptional edge. A singleton-\(e\) matching uses the terminal semiedge at \(t_e\), so it can never use the exceptional half-edge \(t_e e_Y\). Thus **every** singleton-\(e\) matching is fixed to the other exceptional edge. [Note 168's full-family flexibility theorem](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md) forbids a fixed singleton class in the exact same-side \(5+0\) branch. This contradiction proves the theorem. \(\square\)

The argument excludes the entire bipartite \(F_C\) branch at every order. It does not exclude the surviving placement when \(F_C\) itself contains an odd cycle, nor does it identify a common full matching mask across the \((de)(pq)\) and \((ep)(cd)\) rows. The latter remains the complete-PM closure question.
