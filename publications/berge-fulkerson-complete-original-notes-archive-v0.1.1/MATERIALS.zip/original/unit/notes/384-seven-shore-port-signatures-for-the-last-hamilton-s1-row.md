> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Seven shore-port signatures for the last Hamilton \(S_1\) row

Continue [Note 383](383-the-remaining-hamilton-s1-row-forces-a-long-route-and-two-p4-e-matches.md): the required genuine \((ea)(eb)\) row of a putative exact-Case-XII Hamilton \(K_{3,3}\) five-pole has roots \((s,x)\), the long \(a\)--\(c\) route, and two singleton-\(e\) occurrences using \(t_bt,t_cy,t_dz,p_4\). This note classifies their remaining **exterior** load-two masks by the pairs of singleton colours seen at the six shore ports. No shore matching or exact support is asserted by this classification.

Name the four singleton occurrences \(A\) at \(a\), \(B\) at \(b\), and \(E_0,E_1\) at \(e\). Distinguish the latter by \(E_0\) using \(ru_0\) and \(E_1\) using \(ru_1\). This distinction is forced: \(A,B\) both use the \(d\)-half at \(r\), while the two triples already use \(ru_1,ru_0\) once each. Write \(L_i\) for the two singleton occurrences using proper shore port \(p_i\). The terminal \(e\) and port \(p_4\) both have pair \(\{E_0,E_1\}\).

> **Seven-signature theorem.** The complete list of possible singleton port-pair sequences \((L_0,L_1,L_2,L_3;L_4)\) of the row is as follows. Every entry in the table is forced by load two and perfect-matching incidence on the exterior. The list is necessary, not a claim that each sequence extends through an arbitrary shore.

| class | \(B\) at \(x\) | \(A\) at \(y\) | \(L_0\) | \(L_1\) | \(L_2\) | \(L_3\) | \(L_4\) |
|---|---|---|---|---|---|---|---|
| I | \(t_ax\) | \(yu_1\) | \(AB\) | \(BE_0\) | \(AE_1\) | \(E_0E_1\) | \(E_0E_1\) |
| II | \(t_ax\) | \(yu_2\) | \(AB\) | \(AE_0\) | \(BE_1\) | \(E_0E_1\) | \(E_0E_1\) |
| III | \(t_ax\) | \(yu_2\) | \(AB\) | \(AE_0\) | \(E_0E_1\) | \(BE_1\) | \(E_0E_1\) |
| IV | \(xu_0\) | \(yu_1\) | \(AE_1\) | \(BE_0\) | \(AE_0\) | \(BE_1\) | \(E_0E_1\) |
| V | \(xu_0\) | \(yu_1\) | \(AE_1\) | \(BE_0\) | \(AE_1\) | \(BE_0\) | \(E_0E_1\) |
| VI | \(xu_0\) | \(yu_2\) | \(AE_1\) | \(AE_0\) | \(BE_0\) | \(BE_1\) | \(E_0E_1\) |
| VII | \(xu_0\) | \(yu_2\) | \(AE_1\) | \(AE_0\) | \(BE_1\) | \(BE_0\) | \(E_0E_1\) |

Here \(AB\) abbreviates \(\{A,B\}\), and similarly for the other pair entries. In every row the terminal-\(e\) pair is also \(E_0E_1\). Class I is exactly the exterior port signature of the 21-vertex real row in [Note 380](380-a-real-hamilton-ea-eb-row-survives-the-two-immediate-switches.md).

**Proof.** The forced spine from Note 383 gives \(A:t_bx,t_ct,t_dr,su_3,zu_4\), \(B:t_ct,t_dr,zu_4\), and \(E_0,E_1:t_bt,t_cy,t_dz,p_4\). At \(y\), the triples use \(yu_2,yu_1\) once each, and \(E_0,E_1\) saturate \(t_cy\); hence \(A,B\) split \(yu_1,yu_2\). At \(r\), \(A,B\) saturate \(t_dr\), so \(E_0,E_1\) split \(ru_0,ru_1\). Since \(E_0\) uses \(ru_0\), it cannot take either \(r\) or \(y\) at \(u_1\); it must use \(p_1\). Thus \(E_0\in L_1\) in every class.

At \(x\), \(R,A\) saturate \(t_bx\), leaving \(B\) the choice \(t_ax\) or \(xu_0\). If \(B\) chooses \(t_ax\), it uses \(p_0\), the matching \(E_1\) uses \(xu_0\), and \(E_0,E_1\) use respectively \(t_ax,t_as\). Consequently \(E_1\) cannot use \(p_0,p_1\) and must use \(p_2,p_3\) alongside \(p_4\). If \(A\) chooses \(yu_1\), then \(B\) chooses \(yu_2\); the vertex \(s\) forces \(E_0\) onto \(su_2\) and \(B\) onto \(su_3\), yielding class I. If \(A\) chooses \(yu_2\), then \(B\) chooses \(yu_1\) and \(E_0,B\) may split \(su_2,su_3\) in either order. These are precisely classes II and III.

If \(B\) instead chooses \(xu_0\), it uses \(t_as\) at \(s\). Now \(E_0,E_1\) both use \(t_ax\), and \(E_1\) uses \(p_0\). The two \(E\) occurrences must split \(su_2,su_3\), so they also split their remaining ports \(p_2,p_3\). The choice of \(A\)'s \(y\)-edge (\(yu_1\) or \(yu_2\)) and the choice of which \(E\) uses \(p_2\) are independent binary choices, giving classes IV–VII. These choices determine every remaining singleton exterior edge at \(u_0,\ldots,u_4\). Reading the two owners at each port gives the displayed table. No other choice remains at any exterior vertex or marked subdivision. \(\square\)

In a putative exact-support five-pole, the shore must simultaneously carry two **different** complete zero-port matchings \(Q_P,Q_R\), the four complete singleton shore restrictions with one of these seven port signatures, and the load-two row; every zero-port shore matching has an odd complementary closed component by Note 378. By [Note 361's defect lemma](361-a-two-edge-defect-gate-and-a-mixed-double-star-bf-loop.md), every such odd component for \(Q_P\) must contain at least two \(Q_R\)-edges, and conversely. Classes I–VII convert the exterior side of this remaining coupling into seven explicit boundary signatures. They do not by themselves force a forbidden \([eb]\) BF loop or solve exact Case XII. The classification is hand-derived and awaits independent verification; no local mathematical recomputation was used.
