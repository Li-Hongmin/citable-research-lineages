> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three star rectangles exclude two \(R^*\) shores in \(II_B\)

Consider the genuine two-vertex, two-five-cut quotient \(II_B\) of
[Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md)
and the [quotient classification](../scratch/two-vertex-two-five-cut-quotients-draft.md).
Its odd shore port sets are
\[
 A^\circ=\{u_1,u_2,z_1,z_2,x\},\qquad
 B^\circ=\{u_1,z_1,z_2,y,q\}.
\]
The two \(z_i\) marks join the shores directly.  The unmarked
edges are \(u_1A,u_1B,u_1w_1,u_2A,u_2w_1,u_2w_2\);
\(y\) joins \(B\) to \(w_1\), while \(x,q\) join
\(A,B\), respectively, to \(w_2\).  If **both** shores have the
complete actual Case-XIII \(R^*\) relation of
[Máčajová--Mazzuoccolo--Tabarelli, Figure 7 and Appendix XIII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf),
then the outer five-pole has all three genuine BF loops
\[
                         \boxed{[xy],\ [xq],\ [yq].}            \tag{1}
\]
Their triangle cannot be contained in the five-cycle of allowed
exact-Case-XII loops.  Thus the \(R^*\)--\(R^*\) combination is
impossible in \(II_B\), at every shore order.

## Six-slot connector

Let \(K=\{u_1,z_1,z_2\}\).  In the tables below, a two-digit
string is the set of matching slots using the named edge.  Write
\(R_1=u_1w_1\), \(R_{21}=u_2w_1\),
\(R_{22}=u_2w_2\), and \(D_x,D_y,D_q\) for the singleton-side
halves of the three corresponding marks.  At each direct \(z_i\)
mark the shore-half slot sets must be disjoint.  At \(u_1,u_2,w_1,w_2\)
the three incident two-slot sets must partition \([6]\).

First fix \(b\in\{y,q\}\), and let \(b'\) be the other one.
For distinct \(r,s\in K\), suppose the local BF relations contain
\((xr)(xs)\) on \(A\) and \((br)(bs)\) on \(B\).  Relabel
the six occurrences so that \(A\)'s two triples missing
\(xr,xs\) occupy slots \(1,2\), its singletons \(r,s\)
occupy \(3,4\), and its two \(x\)-singletons occupy \(5,6\).
Put \(B\)'s singletons \(r,s\) in \(1,2\), its triples missing
\(br,bs\) in \(3,4\), and its two \(b\)-singletons in \(5,6\).
At \(r,s\) the \(A/B\) shore-half labels are \(23/14\) and
\(14/23\); at the remaining member of \(K\) they are \(12/34\).
Hence \(R_1=T_{z_1}=T_{z_2}=56\).  The other shore-half labels are
\(A:u_2=12,x=56\) and \(B:b=56,b'=34\).
The first row of (2) below completes the connector and gives \([xb]\).

The fourth pair of leaves is \(u_2\) on \(A\) aligned with
\(b'\) on \(B\).  For \(r\in K\), suppose instead that the
actual local types are \((xu_2)(xr)\) and \((bb')(br)\).
The boundary slots are
\[
\begin{array}{c|c|c}
\text{slot}&A^\circ&B^\circ\\\hline
1&K&\{b'\}\\
2&(K\setminus\{r\})\cup\{u_2\}&\{r\}\\
3&\{u_2\}&K\\
4&\{r\}&(K\setminus\{r\})\cup\{b'\}\\
5,6&\{x\}&\{b\}
\end{array}.                                                   \tag{2a}
\]
Now \(A:u_2=23,x=56\), \(B:b'=14,b=56\), and again
\(R_1=T_{z_1}=T_{z_2}=56\).  The second row of (2) gives
\([xb]\).  Both choices of \(b\) use the same connector rows:
\[
\begin{array}{c|ccc|ccc|ccc}
\text{leaves}&R_1&R_{21}&R_{22}&D_x&D_y&D_q&T_x&T_b&T_{b'}\\\hline
r,s\in K&56&34&56&34&12&12&12&34&56\\
u_2/b',r&56&14&56&14&23&23&23&14&56
\end{array}.                                                   \tag{2}
\]
In each row, \(5,6\) are identical outer triple slots missing
\(x,b\); the other three terminal labels are \(56\).

For \([yq]\), use a star centred at \(u_2\) on \(A\) and a
star centred at \(y\) on \(B\).  If both shores support
\((u_2r)(u_2s)\), \((yr)(ys)\) for distinct \(r,s\in K\),
put their boundary occurrences in exactly the first slot pattern
above, with the repeated \(A\)-singleton now \(u_2\) and the
repeated \(B\)-singleton \(y\).  The shore-half labels are
\(A:u_2=56,x=12\), \(B:y=56,q=34\), and the first row of (3)
gives \([yq]\).

For the fourth leaf, suppose the actual types are
\((u_2x)(u_2r)\) and \((yq)(yr)\), where \(r\in K\).
Use (2a) with its repeated \(A\)-singleton replaced by \(u_2\),
its \(A\)-leaf \(u_2\) replaced by \(x\), its repeated
\(B\)-singleton replaced by \(y\), and its \(B\)-leaf \(b'\)
replaced by \(q\).  Then \(A:u_2=56,x=23\) and
\(B:y=56,q=14\).  The second row of (3) gives \([yq]\):
\[
\begin{array}{c|ccc|ccc|ccc}
\text{leaves}&R_1&R_{21}&R_{22}&D_x&D_y&D_q&T_x&T_y&T_q\\\hline
r,s\in K&56&34&12&34&12&56&56&34&12\\
x/q,r&56&14&23&14&23&56&56&14&23
\end{array}.                                                   \tag{3}
\]
In every row of (2)--(3), the two shore-half labels at each direct
mark are disjoint; \(R_1,R_{21},D_y\) partition \([6]\) at
\(w_1\); \(R_{22},D_x,D_q\) partition it at \(w_2\); and
the displayed \(R\)-labels partition it with the shore labels at
\(u_1,u_2\).  Each marked subdivision vertex also partitions
\([6]\) between its two halves and terminal.  Since the input
BF rows are actual, all proper shore edges retain load two.
Thus the six glued slots are genuine outer perfect matchings,
with load two on every edge.

## The complete \(R^*\) relation supplies the stars

Figure 7 partitions the ten local missing-pair states into
\[
P=\{13,14,24,35,45\},\qquad
Q=\{12,15,23,25,34\},
\]
and every pair crossing \(P/Q\) is an actual \(R^*\) BF type.
At each port the four incident states have both colours: their
\(P\)-degrees are \(2,1,2,3,2\).  Any two nonconstant binary
colourings of the same four leaves separate a common pair.
For \([xb]\), colour the leaves \(K\cup\{\star\}\) by the
states incident with \(x\) on \(A\) and \(b\) on \(B\),
identifying \(\star=u_2\) on \(A\) with \(\star=b'\) on
\(B\).  Their common separated pair activates one of (2).
For \([yq]\), identify \(\star=x\) on \(A\) with
\(\star=q\) on \(B\), and use the states incident with
\(u_2\) and \(y\); (3) applies.  This proves all three loops
in (1).

The theorem concerns only two cyclic nonpentagonal \(R^*\) shores
in \(II_B\).  Tree and ordinary-pentagon shores,
larger Tutte barriers, the matchable-core branch, and the full
Berge--Fulkerson conjecture remain open.  The analytic proof awaits
an independent check.

Together with [Note 209](209-a-five-cut-barrier-shore-cannot-have-lstar-support.md)
(no \(L^*\) five-cut shore), [Notes 212--213](213-three-star-rectangles-exclude-two-rstar-shores-in-ir.md)
(the \(I_m,I_r\) double-\(R^*\) cases), the
[\(I_s\) alternative-cut argument](../scratch/two-vertex-two-five-cut-quotients-draft.md)
and Note 209's \(II_A\) restriction, this yields the following
conditional structural corollary for the normalized two-vertex
barrier: **its two five-cut shores cannot both be cyclic and
nonpentagonal.**  At least one is a three-vertex tree or an ordinary
pentagon.  This corollary inherits the minimum-host, exact-support
and upstream-barrier hypotheses of those sources.

[Note 215](215-an-alternative-five-cut-excludes-the-iia-two-shore-quotient.md)
subsequently excludes the entire \(II_A\) quotient by opening a
different cycle-separating five-cut in the whole host.
