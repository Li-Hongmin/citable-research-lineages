> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Alternating-cycle closure reduces bad C10 windows to one forced path

Let \(N_0,\ldots,N_9\) be singleton-boundary perfect matchings whose induced
disjointness graph is C10, with boundary layers periodic modulo five.  Fix
\(k\), and put

\[
T_k=N_k\cap N_{k+2}\cap N_{k+4}.
\]

Under exact \(S\), the complement of \(N_{k+1}\) consists of two forced
boundary paths \(X_k,Y_k\) and alternating cycles.  The matchings
\(N_k,N_{k+2}\) choose opposite halves of \(X_k\), the same forced half of
\(Y_k\), and independent halves on the cycles.  Flip \(N_k\) simultaneously
on every cycle component meeting \(T_k\), obtaining \(Q_k\).  Then

\[
\boxed{Q_k\cap N_{k+2}\cap N_{k+4}=T_k\cap Y_k}.
\]

The new matching remains in the same singleton class and disjoint from
\(N_{k+1}\).  Hence if \(T_k\cap Y_k=\varnothing\), then
\(Q_k,N_{k+1},\ldots,N_{k+4}\) is capacity two.  Four consecutive pairs are
disjoint, and the unique independent three-set of the five-position path is
\(\{0,2,4\}\); the displayed identity excludes precisely that possible
triple occurrence.  Distribution over multiple cycles is therefore harmless:
all relevant cycles can be flipped simultaneously.  Only the second forced
boundary path is unswitchable.

For the 49-matching pole of Note 009, the designated bad window is repaired
minimally by one new matching and one alternating 4-cycle flip.  The flip
removes the two common blocker edges and makes the displayed triple
intersection empty.  No repair using zero new matchings exists.

Complete finite testing through thirteen internal vertices gives retained
exact-\(S\) skeleton counts

\[
1,1,7,41,318\quad(n=5,7,9,11,13).
\]

Only order thirteen contains induced C10 subsystems: 62 in total.  Fifty-two
already contain a capacity-two transversal.  The remaining ten are all
capacity-bad inside the subsystem, all have a two-edge Farkas blocker, and all
admit a path-preserving single-cycle repair.  Repairing cycle lengths are
four in three cases, six in four, and eight in three.

The complete 231-move order-15 neighbourhood of the Note-009 pole contains
141 exact-\(S\) children and 1,472 induced C10 subsystems.  Of these, 896 are
internally capacity-good and 576 are bad.  Every bad subsystem has a two-edge
blocker and every one has a path-preserving repair.  This is not a complete
order-15 census.

For a two-edge blocker, the ten states contain the two blocker edges
alternately.  The relevant blocker edge cannot lie on \(X_k\); it lies on
\(Y_k\) or a same-half cycle.  The remaining conjectural bridge is therefore
the precise forced-path statement

\[
\boxed{\text{for some }k,\quad
N_k\cap N_{k+2}\cap N_{k+4}\cap Y_k=\varnothing.}
\]

A counterexample must place a same-parity triple-common edge on \(Y_k\) in
every directed window.  The multi-cycle identity is proved; this path
statement is not.

The explicit and finite programs are
`scratch/worker-dual/analyze_single_cycle_closure.py` and
`scratch/worker-dual/audit_bad_c10_single_cycle_repair.py`, with the order-15
diagnostic in `scratch/worker-dual/scan_n15_blocker_completion_expansions.py`.
