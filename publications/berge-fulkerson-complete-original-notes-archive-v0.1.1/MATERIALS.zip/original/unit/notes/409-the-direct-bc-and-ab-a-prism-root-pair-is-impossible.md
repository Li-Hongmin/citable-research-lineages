> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(e\,bc:c\), \(e\,ab:a\) prism root pair is impossible

Keep the two-spoke prism tree and marks of [Note 408](408-the-swapped-bc-ab-prism-root-pair-is-impossible.md), with forbidden \(e\)-labels \(AC,bc\). Suppose an actual six-perfect-matching BF row has forbidden triple \(P=e\,bc:c\) and allowed triple \(R=e\,ab:a\). The shore is arbitrary.

> **Root-pair exclusion.** This root pair cannot occur under complete exact Case-XII support for either allowed pentagon
> \[
> S_1=e-ab-AC-bc-Cc-e,\qquad
> S_2=e-ab-bc-AC-Cc-e.                                      \tag{1}
> \]
> Other root pairs and other forbidden-label placements are not covered.

**Proof.** Let \(K\) be singleton-\(ab\), \(J\) singleton-\(bc\), and \(D_0,D_1\) singleton-\(e\). The rooted zero-port tree masks of \(P,R\) on \((u_1,\ldots,u_5)\) are \((B,C,A,b,a)\) and \((B,C,A,b,c)\). In \(R\triangle K\), the \(ab\)-starting terminal path must end at \(Cc\), the only other allowed \(e\)-label in (1). At \(a\), if \(K\) takes \(au_3\), reaching \(Cc\) requires the route through \(Au_1,Bu_2,Cc:C\); the alternative through \(Bu_4\) ends at forbidden \(bc\). But \(Au_1,Cc:C\) already cover both ends of the \(AC\) mark, so \(K\) could not cover its subdivision. Consequently \(K\) takes \(au_5,Cc:c\), giving the wholly exterior path
\[
ab-t_{ab}-a-u_5-c-t_{Cc}-Cc.                              \tag{2}
\]
Switching (2) gives an allowed triple \(R'=e\,Cc:c\) with the same complete shore matching as \(R\).
The rest of its marked mask is forced: \(bc:b,AC:C\). Since \(P,R\) saturate \(Au_3,Cu_2,Bu_1,bu_4\), the matching \(K\) covers \(A\) by \(Au_1\), covers \(B\) by \(Bu_2\) or \(Bu_4\), and uses \(p_3\).

The singleton-\(bc\) matching \(J\) uses \(ab:b\): \(P,R\) saturate \(bu_4\), while \(K\) uses \(bc:b\). At the \(ab\) subdivision, \(P,K\) take the terminal and \(R\) takes \(ab:a\), so exactly one singleton-\(e\) occurrence, call it \(F\), takes \(ab:b\). It cannot also take \(bc:b\); the \(bc\) subdivision therefore gives it \(bc:c\). At \(a\), \(P,K\) saturate \(au_5\), and \(F\) takes \(au_3\). Covering the other prism vertices and marked subdivisions forces
\[
F:\quad AC:A,\quad Cc:C,\quad bc:c,\quad ab:b,
       \quad au_3,\quad p_5.                                  \tag{3}
\]
The \(B\)-edge of \(F\) is \(Bu_2\) or \(Bu_4\), since \(P,R\) saturate \(Bu_1\). Let \(q\) be the proper endpoint of the shore \(e\)-path in \(R\triangle F\). The same \(q\) occurs in \(R'\triangle F\), because (2) is wholly exterior.

For \(S_1\), the \(e\)-path against \(R=e\,ab\) must end at \(AC\), while that against \(R'=e\,Cc\) must end at \(bc\). If \(F:Bu_2\), the first terminal arm exits at \(p_4\), whereas the second exits at \(p_1\). If \(F:Bu_4\), they exit at \(p_1\) and \(p_2\), respectively. The first arm follows \(AC-t_{AC}-A-u_3-a-t_{ab}-b-u_4\); the second follows \(bc-t_{bc}-c-t_{Cc}-C-u_2\), and each continues through \(B-u_1-p_1\) exactly when the chosen \(B\)-edge of \(F\) lies on that arm. Thus both \(B\)-choices require two different values of the same \(q\). This excludes \(S_1\).

For \(S_2\), the \(p_5\)-arm of \(R\triangle F\) reaches \(bc\) along \(p_5-u_5-c-t_{bc}-bc\). Since \(R=e\,ab\) can exchange \(e\) only for \(bc\) while \(P=e\,bc\) stays forbidden, its shore \(e\)-path must end at \(p_5\). Switch this complete \(e\)--\(bc\) path. The resulting triple is the allowed \(T=ab\,bc\); the switched singleton \(F'\) has label \(bc\) and retains \(AC:A,Cc:C,ab:b,au_3\), while gaining \(cu_5\).

The \(ab\)-starting path of \(T\triangle K\) must end at \(AC\): ending at \(e\) or \(Cc\) would create \(e\,bc\) or \(Cc\,bc\), both forbidden alongside \(P\). Switch the complete \(ab\)--\(AC\) path to obtain the allowed triple \(U=AC\,bc\) and singleton-\(AC\) matching \(K'\). The two possible \(B\)-choices of \(K\) give these exterior slots:
\[
\begin{array}{c|ccccc|ccc}
K\text{ at }B&U:u_1&U:u_2&U:u_3&U:u_4&U:u_5
 &U:AC&U:bc&K':ab\\\hline
Bu_4&B&p_2&A&b&a&C&c&a\\
Bu_2&A&B&p_3&b&a&C&c&a
\end{array}                                                     \tag{4}
\]
In both rows \(U\) has the \(Cc\) and \(ab\) terminal semiedges, and \(K'\) has the \(AC\) terminal and retains \(bc:b\). For the first row, \(T\triangle K\) joins its \(ab\)-arm at \(p_5\) to the \(AC\)-arm at \(p_2\); for the second it joins \(p_5\) to \(p_3\). The entries in (4) follow by exchanging those entire paths, without fixing their internal shore routes.

If \(K\) uses \(Bu_4\), the fixed mask (3) makes \(U\triangle F'\) contain the wholly exterior alternating terminal path
\[
bc-t_{bc}-c-u_5-a-u_3-A-t_{AC}-C-t_{Cc}-Cc.          \tag{5}
\]
It switches \(U=AC\,bc\) to the allowed \(V=AC\,Cc\). In the resulting row, \(V\triangle K'\) has the wholly exterior path
\[
AC-t_{AC}-A-u_1-B-u_4-b-t_{bc}-bc.                    \tag{6}
\]
Switching (6) gives \(Cc\,bc\notin S_2\), together with the unchanged \(P=e\,bc\notin S_2\).

If \(K\) uses \(Bu_2\), the \(bc\)-arm of \(U\triangle F'\) exits at \(p_3\), while its \(Cc\)-arm exits at \(p_1\). To avoid a double-forbidden row, these shore arms must join, giving the allowed \(V=AC\,Cc\). That switch makes \(V\) use \(AC:A,Cc:C,au_3\) and keeps its \(ab\) terminal. The unchanged \(K'\) then supplies a wholly exterior alternating path
\[
AC-t_{AC}-A-u_3-a-t_{ab}-ab.                         \tag{7}
\]
Switching (7) gives \(Cc\,ab\notin S_2\) alongside the unchanged \(P=e\,bc\notin S_2\). Both possible \(B\)-choices contradict exact Case XII. Every switch uses complete perfect matchings and preserves the edge load two. \(\square\)

Other root pairs, other forbidden-label placements, and the full Berge–Fulkerson conjecture remain open. The derivation is by hand and awaits independent proof review.
