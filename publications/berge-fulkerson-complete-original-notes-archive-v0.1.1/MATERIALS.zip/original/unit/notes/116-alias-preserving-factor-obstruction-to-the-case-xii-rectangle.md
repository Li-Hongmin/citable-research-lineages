> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Alias-preserving factor obstruction to the Case-XII rectangle

The six rows of [Note 101](101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md) have three additional equalities in its concrete nineteen-matching model:
\(p^1_{13}=A\), \(p^3_{13}=P_3\), and \(p^5_{25}=P_5\). The four-\(K_4\) construction recorded in the [earlier conditional argument](../scratch/pro-case-xii-factor-2026-09-24.md) preserves repeated *names* but does not preserve all three equalities. The construction below does. Thus even these literal identities do not make the universal synchronized-rectangle assertion stable under support-preserving two-edge sums.

All statements concern actual perfect matchings of a loopless cubic five-pole, represented by complete edge masks including its five semiedges. They do not assume that an exact-Case-XII pole exists.

## The marked six-row class

Write \(r=r_{23}\), \(s=r_{34}\), \(q'=q'_{25}\), and let the following six ordered multisets each have edge load \(2\mathbf1\):

\[
\begin{aligned}
 &(r,B,X,q_{13},p^1_{13},p^3_{13}),\\
 &(r,B,X,q_{14},A,C),\\
 &(r,B,X,q_{24},p^2_{24},p^4_{24}),\\
 &(r,B,X,q_{25},p^2_{25},p^5_{25}),\\
 &(r,B,X,q_{35},P_3,P_5),\\
 &(q',s,B,Y,C,D).                                      \tag{1}
\end{aligned}
\]

Repeated names are the same matching throughout. In the strengthened class considered here, also require

\[
p^1_{13}=A,\qquad p^3_{13}=P_3,\qquad p^5_{25}=P_5.       \tag{2}
\]

The two occurrences \(q_{25},q'\) are kept distinct. Put

\[
K_{23}=2\mathbf1-r-B-X,\qquad K_{34}=2\mathbf1-s-Y-C,
\]
and define the four literal residuals

\[
R_Y=K_{23}-Y,\quad R_D=K_{23}-D,\quad
R_A=K_{34}-A,\quad R_X=K_{34}-X.                       \tag{3}
\]

**Theorem.** From any actual marked pole satisfying (1)--(2), and any proper edge of it, four successive insertions of \(K_4\) along proper edges construct a pole with sixteen additional vertices such that:

1. its **complete** Berge--Fulkerson boundary support is exactly that of the original pole;
2. all six rows and all three complete-mask equalities in (2) survive, and \(q_{25}\ne q'\);
3. one proper edge has \(R_Y=R_D=-1\), and another has \(R_A=R_X=-1\).

If the starting pole is simple, connected, proper-bridge-free and has five distinct terminals, so is the output. The construction may introduce triangles and nonterminal proper two-edge cuts.

### One insertion and complete closure

Delete a proper edge \(uv\) and an edge \(01\) of a fresh \(K_4\) on \(0,1,2,3\), then add \(u0,v1\). The three local patterns for a perfect matching are

\[
C_0=\{u0,v1,23\},\qquad
C_1=\{02,13\},\qquad C_2=\{03,12\}.                    \tag{4}
\]

The first pattern occurs exactly when the old matching contains \(uv\); either of the other two occurs exactly when it avoids \(uv\). Indeed, a matching crosses the two-edge cut in zero or two edges, and in either case its internal continuation is forced up to the displayed two choices. Contracting (4) therefore maps the **entire** new perfect-matching family onto the old one without changing any terminal mask.

Every new BF row contracts to an old BF row: the two connector edges have load two, so the restored \(uv\) has load two. Conversely, an old BF row has exactly two occurrences using \(uv\). Give them \(C_0\), and give two of the remaining four \(C_1\) and the other two \(C_2\). Each new edge then has load two. Thus the complete BF boundary support is equal in both directions. The same argument works at each of the four insertions. The fresh vertices and the cycles in \(K_4-01\) also give the asserted topological preservation.

### Occurrence sets with the aliases enforced

Let \(\Lambda\) be the 22 displayed names in (1), treating the equalities (2) as constraints on their masks. For a proper edge \(e\), let \(I(e)\subseteq\Lambda\) record the names whose matching uses \(e\). Call a set *balanced* if it contains exactly two names from each of the six rows. Every \(I(e)\) is balanced; it is also *alias-consistent*: membership agrees within each pair in (2).

The following three balanced, alias-consistent sets will be used as local colours:

\[
\begin{aligned}
U={}&\{r,X,Y,D\},\\
Z_*={}&\{B,C,p^3_{13},p^2_{24},p^2_{25},P_3\},\\
V={}&\{X,A,p^1_{13},Y,s,q_{24},q_{25},q_{35}\}.          \tag{5}
\end{aligned}
\]

Here \(U\cap Z_*=Z_*\cap V=\varnothing\). The aliases \(p^3_{13},P_3\) occur together in \(Z_*\), and \(p^1_{13},A\) occur together in \(V\); the third alias pair is absent from both. In particular, replacing the earlier argument's \(q_{13}\) in its second target by \(p^1_{13}\), and replacing its intermediate \(p^1_{13}\) by \(p^3_{13}\), repairs its loss of identity.

If a port edge has occurrence set \(\sigma\), and \(\tau\) is balanced, alias-consistent and disjoint from \(\sigma\), assign \(C_0\) to the names in \(\sigma\), \(C_1\) to those in \(\tau\), and \(C_2\) to the remaining names. The complement is balanced and alias-consistent. Each row then uses each local pattern twice; hence (1)--(2) survive. The two internal edges \(02,13\) both have occurrence set \(\tau\). One can be the next port while the other remains protected.

### An alias-consistent bridge from every input edge

For every balanced, alias-consistent \(\sigma\), there is a balanced, alias-consistent \(Z\) disjoint from both \(\sigma\) and \(U\). Here is a direct construction. Put \(H=\{r,B,X\}\), and denote the five complementary triples of the first five rows by \(E_{13},E_{14},E_{24},E_{25},E_{35}\). If \(c=|\sigma\cap H|\), then every \(E_{ij}\) meets \(\sigma\) in exactly \(d=2-c\) names. In particular \(c\le2\). The links between these triples are precisely the aliases \(p^1_{13}\leftrightarrow A\), \(p^3_{13}\leftrightarrow P_3\), and \(p^5_{25}\leftrightarrow P_5\).

If \(B\in\sigma\), put \(B,r,X,Y,D\notin Z\). For \(d=1\), take the two names of every \(E_{ij}\setminus\sigma\). This respects all aliases. If \(C\) is among these chosen names, add one of \(q',s\) outside \(\sigma\); otherwise add both \(q',s\). These additions make the last row balanced. They are available because \(\sigma\) already uses \(B\) and only one other last-row name. For \(d=0\), choose respectively

\[
\begin{array}{c|ccccc}
E_{ij}&E_{13}&E_{14}&E_{24}&E_{25}&E_{35}\\ \hline
Z\cap E_{ij}&\{q_{13},p^1_{13}\}&\{A,C\}&
\{q_{24},p^2_{24}\}&\{q_{25},p^5_{25}\}&\{q_{35},P_5\}.
\end{array}                                                   \tag{6}
\]

These choices respect (2), contain \(C\), and avoid \(\sigma\); add one of \(q',s\) outside \(\sigma\). The last-row quota again holds.

If \(B\notin\sigma\), put \(B\in Z\) and \(r,X,Y,D\notin Z\), so one name from each \(E_{ij}\) and one of \(q',s,C\) must be selected. For \(d=2\), take the unique name of each \(E_{ij}\setminus\sigma\). The aliases remain paired. If the selected \(E_{14}\) name is \(C\), it fills the last-row quota with \(B\); otherwise \(C\in\sigma\), so at least one of \(q',s\) is free and can fill it.

For \(d\le1\), first fill the last row. If both \(q',s\) are in \(\sigma\), choose \(C\) from \(E_{14}\); it is free because the last row of \(\sigma\) is already full. Otherwise choose a free member of \(\{q',s\}\), and choose a free member of \(\{q_{14},A\}\) from \(E_{14}\). The latter exists because \(d\le1\). Complete the remaining triples without hitting \(\sigma\) as follows. If \(E_{14}\) chose \(A\), choose its alias \(p^1_{13}\) in \(E_{13}\); otherwise choose \(q_{13}\) if free, or \(p^3_{13}\) if \(q_{13}\in\sigma\). If \(E_{13}\) chose \(p^3_{13}\), choose \(P_3\) in \(E_{35}\) and a free member of \(\{q_{25},p^2_{25}\}\) in \(E_{25}\). Otherwise choose \(q_{35}\) in \(E_{35}\) if free and a free member of \(\{q_{25},p^2_{25}\}\) in \(E_{25}\); if \(q_{35}\in\sigma\), choose the linked pair \(P_5,p^5_{25}\) instead. Finally choose any free name of \(E_{24}\). Every specified free choice exists because \(d\le1\), and linked aliases have the same membership in \(\sigma\). This proves the bridge claim.

### Four steps and the residual obstruction

Choose any proper input edge with occurrence set \(\sigma\), construct \(Z\) as above, and perform the four transitions

\[
\sigma\longrightarrow Z\longrightarrow U\longrightarrow Z_*
\longrightarrow V.                                         \tag{7}
\]

Each transition is one actual insertion (4). After the second transition protect one of the two edges of colour \(U\); after the fourth protect an edge of colour \(V\). At the first protected edge, \(r=X=Y=D=1\) and \(B=0\), so

\[
R_Y=2-r-B-X-Y=-1,\qquad R_D=2-r-B-X-D=-1.       \tag{8}
\]

At the second, \(s=Y=A=X=1\) and \(C=0\), giving

\[
R_A=2-s-Y-C-A=-1,\qquad R_X=2-s-Y-C-X=-1.       \tag{9}
\]

The second edge belongs to \(q_{25}\) and not to \(q'\), so those complete masks are distinct in the output. Equations (8)--(9) prove the theorem without enumerating graphs or matching families.

## A concrete thirty-three-vertex pole

The [seventeen-vertex pole](../scratch/r2-shared-witness-pole-20260928/actual-shared-witness-phase-obstruction.md) provides an actual input to the theorem. Its graph and marked matchings are included here so that the resulting thirty-three-vertex pole is specified without an existence assumption.

Start with vertices \(0,\ldots,12\), with semiedge \(s_i\) at vertex \(i-1\) for \(i=1,\ldots,5\). Number its proper edges as follows:

\[
\begin{array}{c|rrrrrrrrr}
e&0&1&2&3&4&5&6&7&8\\ \hline
\text{ends}&08&0\,11&17&19&29&2\,12&3\,10&3\,12&4\,10\\[2pt]
e&9&10&11&12&13&14&15&16&\\ \hline
\text{ends}&4\,11&57&58&59&68&6\,11&6\,12&7\,10&
\end{array}                                                   \tag{12}
\]

Here \(08\) denotes the edge \(\{0,8\}\), not the number eight. Replace \(e_1=\{0,11\}\) by a \(K_4\) on vertices \(13,14,15,16\), deleting \(\{13,14\}\) and adding \(\{0,13\},\{11,14\}\). Write

\[
\alpha=\{13\,15,14\,16\},\quad
\beta=\{13\,16,14\,15\},\quad
\gamma=\{0\,13,11\,14,15\,16\}.                     \tag{13}
\]

The following table specifies the nineteen distinct marked perfect matchings. The middle column gives proper-edge indices in the original thirteen-vertex graph; the indicated mode replaces \(e_1\) when it occurs and adds the displayed local edges. Singleton or triple semiedges are determined by the names in (1); they can also be checked from the vertex incidences.

| Matching | Old proper-edge indices | Mode |
|---|---|---|
| \(r\) | 3,5,11,14,16 | \(\alpha\) |
| \(B\) | 1,4,7,8,10,13 | \(\gamma\) |
| \(X\) | 0,2,6,9,12,15 | \(\beta\) |
| \(q'\) | 3,9,11,15,16 | \(\beta\) |
| \(D\) | 0,2,5,6,12,14 | \(\beta\) |
| \(q_{14}\) | 0,7,12,14,16 | \(\beta\) |
| \(A=p^1_{13}\) | 2,4,6,9,11,15 | \(\alpha\) |
| \(C\) | 1,3,5,8,10,13 | \(\gamma\) |
| \(s\) | 4,7,11,14,16 | \(\alpha\) |
| \(Y\) | 0,2,6,9,12,15 | \(\alpha\) |
| \(q_{13}\) | 1,5,12,13,16 | \(\gamma\) |
| \(P_3=p^3_{13}\) | 0,3,7,8,10,14 | \(\beta\) |
| \(q_{35}\) | 4,9,11,15,16 | \(\alpha\) |
| \(P_5=p^5_{25}\) | 1,2,5,6,12,13 | \(\gamma\) |
| \(q_{25}\) | 3,9,11,15,16 | \(\alpha\) |
| \(p^2_{25}\) | 0,4,7,8,10,14 | \(\beta\) |
| \(q_{24}\) | 3,7,11,14,16 | \(\alpha\) |
| \(p^2_{24}\) | 0,4,6,9,10,15 | \(\beta\) |
| \(p^4_{24}\) | 1,2,5,8,12,13 | \(\gamma\) |

At the surviving edge \(e_0=\{0,8\}\), these masks give

\[
\begin{aligned}
\sigma={}&\{X,D,q_{14},Y,p^3_{13},P_3,p^2_{25},p^2_{24}\},\\
Z={}&\{B,q',A,p^1_{13},q_{24},q_{25},q_{35}\}.          \tag{14}
\end{aligned}
\]

The displayed \(Z\) is balanced, alias-consistent and disjoint from \(\sigma,U\), so no choice remains in the first transition. Use (7), always taking the local \(02\) edge as the next port and ordering the ends of each port increasingly as \(u<v\) in (4). The four insertion ports are respectively \(\{0,8\},\{17,19\},\{21,23\},\{25,27\}\), with fresh vertex sets \(\{17,18,19,20\}\), \(\{21,22,23,24\}\), \(\{25,26,27,28\}\), and \(\{29,30,31,32\}\). This specifies a fully labelled 33-vertex graph. The two protected edges are \(\{22,24\}\) of colour \(U\) and \(\{30,32\}\) of colour \(V\); (8)--(9) give their four \(-1\) coordinates. The graph is simple, connected and proper-bridge-free, and all its perfect matchings are covered by the four successive projection descriptions (4). It is an unconditional real-graph counterexample to the implication from (1)--(2) and complete PM closure alone to a sixteen-context rectangle. Moreover, [Note 024](024-common-cubic-incidence-does-not-force-an-unsafe-route-without-exact-s.md) gives all twenty-five actual \(S\)--\(T\) BF types and no all-terminal BF type in the thirteen-vertex base; the five insertions from that base to this graph preserve both properties of its **complete** support.

This graph is **not** an exact-Case-XII counterexample. In the seventeen-vertex input, \(r+B+X=\mathbf1\), so doubling those three actual matchings gives a forbidden \(T\)-loop of type \([23]\). Complete BF-support preservation carries that boundary type to the 33-vertex output, possibly using different lifts of the three matchings.

## Exact Case-XII consequence and boundary

Put \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). Let \(\mathfrak X_{\rm aliased}\) be the class of marked poles satisfying (1)--(2) and whose **complete** BF support is exactly the forty Case-XII types in the [2026 Case-XII appendix](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Its positive types are the five \(S\)-loops, ten \(S\)--\(S\) pairs and twenty-five \(S\)--\(T\) pairs; the all-terminal type and all \(T\)--\(T\) types are absent. Theorem (1)--(9) preserves this exact support if an input member exists.

For the sixteen contexts of [Note 104](104-exact-negative-support-reduces-first-splice-failures-to-four-cross-carrier-leakages.md), any proposed same-\(K\), target-phase rectangle has some \(K_\tau=P+N+W\) and \(N+P-\tau\) an actual perfect matching. Consequently

\[
K_\tau-\tau=W+(N+P-\tau)\ge0.                      \tag{10}
\]

The output of (7) violates (10) for all four targets \(\tau=Y,D,A,X\), independently of how the admissible opposite witness is defined. Therefore, for the marked class just defined,

\[
\bigl[\text{every member has a Note-104 synchronized rectangle}\bigr]
\quad\Longleftrightarrow\quad
\mathfrak X_{\rm aliased}=\varnothing.                  \tag{11}
\]

This is a conditional all-orders separation, not a realized exact-Case-XII counterexample. It says that the universal rectangle, even with the three Note-101 identities retained, could hold on this two-sum-closed class only through nonexistence of the class. It does not establish that every exact-Case-XII pole admits the marked rows (1)--(2). It also does not apply to the narrower girth-five, nonterminal-two-cut-free side inherited from a minimum BF counterexample: the attachment in (7) leaves that narrower class. The latter inherited restrictions and the remaining cyclically-six-connected branch are separated in [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) and in the primary papers of Máčajová--Mazzuoccolo (2020, Theorem 1.2, DOI 10.1090/proc/15057) and Máčajová--Mazzuoccolo--Tabarelli (2026, Proposition 4.4 and Case-XII Appendix, DOI 10.26493/1855-3974.3409.c13), checked from the local primary PDFs on 2026-09-29.

The construction controls the displayed row assignment, not all possible assignments on its output graph. [Note 117](117-existential-case-xii-rectangle-transfers-through-colourable-two-sums.md) proves that, for a precise full-projection witness predicate, the existence of *some* successful assignment transfers both ways through these colourable two-sums when the row constraints are equalities only.
