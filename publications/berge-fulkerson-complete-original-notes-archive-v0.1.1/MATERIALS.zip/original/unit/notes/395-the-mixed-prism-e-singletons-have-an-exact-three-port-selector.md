> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The mixed prism \(e\)-singletons have an exact three-port selector

Use the all-order \((e\,ab)(e\,AC)\) root pair of [Note 394](394-a-mixed-prism-row-forces-an-ac-bc-escape-and-attains-it.md): the forbidden triple \(P\) is rooted at \(a\), the allowed triple \(R\) at \(C\), and the other four occurrences are singleton-\(e\) matchings \(E,F\), singleton-\(ab\) matching \(J\), and singleton-\(AC\) matching \(K\). Assume complete exact Case-XII support with forbidden \(e\)-labels \(ab,Cc\). No shore order, cycle-rank, complement-parity or port-path-length restriction is imposed here.

> **Three-port selector.** Each \(D\in\{E,F\}\) uses all four marked halves
> \[
> AC:A,\qquad Cc:C,\qquad bc:c,\qquad ab:b.                 \tag{1}
> \]
> It matches \(B\) through exactly one of \(Bu_1,Bu_2,Bu_4\), and matches \(a\) through exactly one of \(au_3,au_5\). The three proper ports used by \(D\) have the following **exterior** alternating destinations against \(R\):
>
> | \(D\)'s edge at \(B\) | port leading to \(Cc\) | port leading to \(ab\) |
> |---|---|---|
> | \(Bu_1\) | \(p_2\) | \(p_4\) |
> | \(Bu_2\) | \(p_1\) | \(p_4\) |
> | \(Bu_4\) | \(p_1\) | \(p_2\) |
>
> If \(D\) uses \(au_3\), its third port is \(p_5\) and leads to \(bc\); if it uses \(au_5\), its third port is \(p_3\) and leads to \(bc\). For **both** singleton-\(e\) occurrences, the shore path of \(R\triangle D\) starting at \(e\) must pair \(e\) with the port in the table leading to the unique \(m\in\{Cc,ab\}\) for which \(ACm\) belongs to the allowed pentagon \(S\). Neither may select its \(bc\)-port, and both must select the same terminal destination \(m\).

**Proof.** [Note 394's load propagation](394-a-mixed-prism-row-forces-an-ac-bc-escape-and-attains-it.md) forces \(K\) onto \(Cu_2,ab:a,bc:b,Cc:c\), and forces \(J\) onto \(AC:C\). At each of the four marked subdivision vertices, the remaining two identical half-edge slots are occupied by \(E,F\), giving (1). Thus every \(D\) already covers \(A,C,b,c\) at the marks, so its only uncovered prism vertices are \(B,a\). The tree forces one choice at each. If \(D\) takes \(Bu_1\), it must use ports \(p_2,p_4\); if it takes \(Bu_2\), ports \(p_1,p_4\); if it takes \(Bu_4\), ports \(p_1,p_2\). Independently, \(au_3\) forces port \(p_5\), while \(au_5\) forces port \(p_3\). These are exactly three proper ports, as required by the shore-hit quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md).

Trace \(R\triangle D\) in the exterior. The \(Cc\)-route from \(p_1\) runs through \(u_1,A,t_{AC},C,t_{Cc}\); when \(D\) uses \(Bu_1\), the \(Cc\)-route instead begins at \(p_2,u_2,B,u_1\) and then follows the same \(A,t_{AC},C,t_{Cc}\) tail. The \(ab\)-route from \(p_4\) is \(p_4,u_4,b,t_{ab},ab\); when \(D\) uses \(Bu_4\), it instead begins \(p_2,u_2,B,u_4\) and follows the same \(b,t_{ab},ab\) tail. The remaining route runs from \(p_5,u_5,c,t_{bc}\) if \(D\) uses \(au_3\), or from \(p_3,u_3,a,u_5,c,t_{bc}\) if it uses \(au_5\). These three paths are pairwise disjoint outside the shore and end at \(Cc,ab,bc\), proving the table.

The shore part of \(R\triangle D\) has ends \(e\) and \(D\)'s three proper ports, so it pairs \(e\) with exactly one of them. The exterior table identifies its full terminal endpoint \(j\in\{Cc,ab,bc\}\). Switching the two complete occurrences \(R,D\) along that \(e\)--\(j\) path changes \(R\)'s state from \(e\,AC\) to \(ACj\) while the other triple remains \(e\,ab\in T\). Exact Case XII forbids a double-\(T\) row, so \(ACj\) must lie in \(S\). Because \(e\,AC,e\,bc\in S\), the edge \(AC\,bc\) is a chord of the pentagon and lies in \(T\); exactly one of \(AC\,Cc,AC\,ab\) is the other \(S\)-edge at \(AC\). This proves the unique selector for each \(D\). \(\square\)

The real allowed-escape row of [Note 394](394-a-mixed-prism-row-forces-an-ac-bc-escape-and-attains-it.md) shows why this second gate matters. Its \(E^*\) uses \(Bu_1,au_5\), hence ports \(p_2,p_4,p_3\). Against \(R(Q')\), the shore \(e\)-path is
\[
e-h_0-h_1-h_2-h_5-h_6-h_7-p_3,
\]
so the full alternating path continues \(p_3-u_3-a-u_5-c-t_{bc}-bc\). Switching \(R,E^*\) gives the forbidden \((e\,ab)(AC\,bc)\) double-\(T\) row using only matchings already present in that genuine six-matching certificate. Thus Note 394's \(AC\)--\(bc\) and \(ab\)--\(bc\) exchanges are safe, but its displayed row still fails the next negative-support test without invoking another zero-port matching. This result does not rule out rows in which **both** singleton-\(e\) shore paths obey the selector, nor does it settle complete exact Case XII. The routing and edge checks are hand-derived and await independent review.
