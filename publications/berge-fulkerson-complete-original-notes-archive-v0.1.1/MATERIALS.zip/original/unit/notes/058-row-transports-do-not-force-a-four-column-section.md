> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Row transports do not force a four-column section

This note gives a strict relation-level boundary for the Case-XII
singleton-fibre problem. It shows that the row-transport theorem of
[Note 057](057-overlap-cells-transport-singleton-fibres-into-d5.md) cannot
be upgraded to a four-column join without an additional cross-row incidence
axiom. The construction below is not the perfect-matching relation of a
cubic five-pole.

For each singleton class i modulo 5, take two tokens 0_i and 1_i. For the
five cyclic rows of the A5 family, impose

    Theta_i = {(0_i,0_(i-1)), (1_i,1_(i-1))}.

Thus every row has a genuine two-point alternating-cycle transport. Add the
fixed-coordinate requirements

    row 1: x2=x3=0
    row 2: x3=1, x4=0
    row 3: x4=1, x5=0
    row 4: x5=1, x1=0
    row 5: x1=1, x2=1.

Rows 1,2 conflict at x3, rows 2,3 at x4, rows 3,4 at x5, rows 4,5 at x1,
and rows 5,1 at x2. After deleting any one row, one conflicting adjacent
pair remains. Therefore every four-row join is empty, although every Theta_i
is nonempty and nondegenerate.

This is the exact abstract failure mode of

    five row transports => a four-column common singleton tuple.

The obstruction uses independent row bases and fixed coordinates; it does
not satisfy the common edge universe and common cubic vertex equations of a
single pole. It is therefore not a Case-XII pole and not a
Berge--Fulkerson counterexample. It proves only that local transport
relations supplied by alternating-cycle/Kempe closure do not provide the
missing cross-row compatibility.

Any proof of the Case-XII join must add a genuinely global condition, such
as a common perfect-matching incidence theorem, a witness-reuse/Helly
property verified on one pole, or an equivalent cross-column exchange
statement. Conversely, a real counterexample must realize this
incompatibility inside one common cubic incidence system.
