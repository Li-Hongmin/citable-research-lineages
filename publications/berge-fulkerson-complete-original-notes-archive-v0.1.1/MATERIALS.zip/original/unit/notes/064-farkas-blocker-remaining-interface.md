> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Farkas blocker interface for the exact-\( S \) capacity question

For the singleton families \(\mathcal P_i\), failure of a capacity-two transversal has the exact dual form
\[
\exists y_e\ge0:
\qquad \sum_i\min_{P\in\mathcal P_i}y(P)>2\sum_e y_e.
\]

In the D5-supported exact-\( S \) setting, an (A)-free witness yields a literal proper-edge blocker (F) meeting every singleton class. A minimum-intersection singleton (P) satisfies
\[
\varnothing\ne P\cap F\subseteq L(P,Q)\cap L(P,Q'),
\]
where (L(P,Q)) denotes the alternating carrier determined by the corresponding triple matching. The blocker has terminal degrees (2,1,1,1,1) and internal degrees in \(\{1,2\}\). A rigid two-edge blocker cannot be simultaneously compatible with all five D5 cells.

These facts do not yet force a contradiction: the remaining interface is synchronization of the five carrier systems, or a proof that an unsynchronized blocker creates a forbidden T-loop/TT support. No real exact-40/no-\( A \) pole is known.
