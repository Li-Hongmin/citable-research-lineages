> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Petersen shore replacement preserves full BF support while forcing odd shore cycles

The odd-closed-component condition of [Note 378](378-hamilton-k33-forbidden-eb-ed-states-force-an-odd-shore-cycle.md) and the real row of [Note 380](380-a-real-hamilton-ea-eb-row-survives-the-two-immediate-switches.md) have an exact common boundary. Inserting a Petersen three-pole at one shore vertex forces **every** zero-port shore matching to have an odd closed complementary component, without changing **any** admissible BF boundary type. Applied to Note 380, this gives a 29-vertex girth-five pole with the same surviving \((ea)(eb)\) row, the same forbidden \([eb]\) type, and no three-edge-colouring. [Note 044](044-girth-five-tait-empty-boundary-is-not-enough.md) used a support-neutral Petersen **two-pole** to make a different boundary example; the three-pole insertion here targets the six-port shore's zero-port matching complements.

## Support-neutral three-pole substitution

More generally, let \(J\) be any cubic three-pole admitting a BF cover and substitute it for an internal vertex \(v\) of any cubic five-pole \(H\). Then the resulting pole has **exactly** \(C(H)\). The proof below only uses odd matching parity across the three attachments and one BF cover of \(J\): in that cover each of the six matching labels uses exactly one attachment, so its three attachment edges partition the labels into pairs. Colour relabelling matches any prescribed partition at \(v\). If \(J\) admits no BF cover, the substituted pole admits no BF cover either, by restriction. Thus BF boundary support cannot detect any BF-coverable three-pole factor inserted at a vertex.

Let \(H\) be a cubic five-pole and \(v\) an internal vertex whose three incident edges are distinct. Write \(P\) for the Petersen graph with outer cycle \(v_0v_1v_2v_3v_4v_0\), spokes \(v_i u_i\), and inner edges \(u_i u_{i+2}\), indices modulo five. Replace \(v\) by \(P-v_0\), attaching the three former neighbours of \(v\) to \(v_1,v_4,u_0\), respectively. Denote the resulting pole by \(H^\sharp\). Then

\[
                         C(H^\sharp)=C(H),                 \tag{1}
\]

where \(C\) is the **complete** BF boundary support of Definition 4.1 in the cited [original paper](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

For the forward inclusion, take any six-perfect-matching BF cover of \(H^\sharp\). Each matching meets the three-edge boundary of the nine-vertex gadget an odd number of times, hence once or three times. The six matchings collectively use those three edges six times, twice each. Thus all six use exactly one; contracting the gadget to \(v\) gives six genuine perfect matchings of \(H\) with every edge loaded twice and the same five terminal boundaries.

For the reverse inclusion, the Petersen graph has a BF cover \(M_\infty,M_0,\ldots,M_4\). Here \(M_\infty\) consists of the five spokes, while \(M_i\) consists of spoke \(v_i u_i\), the unique two-edge matching of the outer five-cycle after deleting \(v_i\), and the unique two-edge matching of the inner five-cycle after deleting \(u_i\). Each Petersen edge occurs twice: this is immediate for spokes and follows by cyclic symmetry and the ten total occurrences for either five-cycle. At \(v_0\), the three incident edges have matching pairs

\[
 v_0v_1:\{M_2,M_4\},\qquad
 v_0v_4:\{M_1,M_3\},\qquad
 v_0u_0:\{M_\infty,M_0\}.                             \tag{2}
\]

Any BF cover of \(H\) gives a partition of its six matching labels into three pairs at \(v\). Relabel (2) to agree with that partition and splice the six restricted Petersen matchings into the six matchings of \(H\). Every resulting matching is complete, every edge has load two, and the terminal boundaries are unchanged. This proves (1), including loops and all other BF types; it is stronger than preserving one displayed row.

## An odd cycle in every zero-port shore complement

Use the shore notation of Note 380. Replace its vertex \(w_0\), attaching \(w_1,w_2,u_0\) to \(v_1,v_4,u_0\) of \(P-v_0\), respectively. The shore now has fourteen vertices. Let \(Q\) be **any** complete zero-port matching of this shore; in particular it uses neither the proper port at the exterior \(u_0\) nor terminal \(e\). Its restriction to the nine-vertex Petersen gadget must use exactly one of the two attachments to \(w_1,w_2\), by odd parity. Restoring \(v_0\) along this attachment extends the restriction to a perfect matching of \(P\).

The complement of every Petersen perfect matching is two disjoint five-cycles. One contains \(v_0\); the other lies wholly in the inserted gadget and survives as an odd closed component of the **shore** complement of \(Q\). For completeness, every Petersen matching has either five spokes or one spoke. Three spokes would leave two indices adjacent on both the outer five-cycle and the inner five-cycle, which is impossible. The five-spoke matching leaves the two defining five-cycles; the one-spoke case is rotationally equivalent to \(M_0\), whose complement has cycles

\[
v_0v_1u_1u_4v_4v_0,\qquad v_2v_3u_3u_0u_2v_2.
\]

The pole \(H^\sharp\) is also non-three-edge-colourable. A three-edge-colouring would give each colour exactly one of the gadget's three cut edges, by the same parity argument. Restoring \(v_0\) would three-edge-colour the Petersen graph, contradicting its displayed odd complementary five-cycles.

The argument is not special to the six-cycle shore of Note 380. In **any** six-port shore containing a vertex incident with exactly one proper port and two shore edges, the same substitution makes every zero-port shore matching leave an odd internal five-cycle, while (1) keeps the entire BF support fixed. Thus this odd-cycle condition alone cannot distinguish BF support classes unless an irreducibility condition excludes the inserted cyclic three-edge cut.

## Explicit 29-vertex row and forbidden loop

For the six occurrences \(P,R,A,B,E_1,E_2\) of Note 380, splice in the following restricted Petersen matchings, in that order:

\[
                    M_2,\ M_1,\ M_\infty,\ M_0,\ M_4,\ M_3.       \tag{3}
\]

The pairs at \(w_0\) in the original row are \(w_0w_1:P,E_1\), \(w_0w_2:R,E_2\), and the proper port \(p_0:A,B\), exactly matching (2). Hence (3) is a six-complete-matching \((ea)(eb)\) row on the new 29-vertex pole. The \(a\)--\(c\) switch is entirely exterior. For both \(j=1,2\), the \(e\)-path of \(P\triangle E_j\) uses the shore segment \(e,w_e,w_4,p_4\), which avoids the inserted gadget. The later \(e\)-path after that exterior switch uses the same segment. Thus both endpoint tests of Note 380 survive; the gadget may only add closed alternating components or replace other passages through \(w_0\).

The forbidden \([eb]\) type also has a direct six-matching certificate. In Note 380, let \(R'\) be the extra state-\(eb\) triple rooted at \(x\) with shore matching \(Q_1\). Its complement is the displayed spanning \(e\)--\(b\) path. Alternately colour that path from its \(e\) terminal to obtain singleton matchings \(D_e,D_b\). The six occurrences \(R',R',D_e,D_e,D_b,D_b\) load each old edge twice. At \(w_0\), their three pairs use, respectively, \(w_0w_1,p_0,w_0w_2\): the latter two are edges 15 and 16 of the path when counted from \(e\). Replace these six occurrences at the gadget by

\[
                       M_2,M_4,M_\infty,M_0,M_1,M_3.     \tag{4}
\]

Equations (2) and (4) check the attachments and every Petersen edge; the old complement path checks all other edges. Thus \([eb]\in C(H^\sharp)\), even though every zero-port shore matching has an odd closed complementary cycle and the pole has no Tait colouring. The order is \(21-1+9=29\). Petersen girth is five, and any cycle crossing its three attachments has at least three internal gadget edges and at least two attachment edges, so the new pole has girth five.

This closes the implication “odd shore complement plus a real row and its immediate switches excludes forbidden BF loops.” It does **not** close exact Case XII: (1) transports the forbidden \([eb]\) from Note 380. The inserted Petersen gadget creates a cyclic three-edge cut, so the example also does not model the cyclically five-edge-connected minimum host in Proposition 4.4. A positive proof must use more than these Tait and rowwise conditions, in particular a restriction that rules out such support-neutral factors or controls the full BF closure across them. The construction and proof are analytic and await an independent proof check.
