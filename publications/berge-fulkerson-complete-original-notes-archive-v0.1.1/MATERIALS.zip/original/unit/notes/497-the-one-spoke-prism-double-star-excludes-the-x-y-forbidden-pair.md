> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The one-spoke prism double star excludes the \(X,Y\)-forbidden pair

Continue the one-internal-mark, one-shore \(|U|=r=5\) profile of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). Let the suppressed exterior be the triangular prism with top triangle \(A,B,C\), bottom triangle \(a,b,c\), and spokes \(Aa,Bb,Cc\). Choose its **one-spoke double-star tree**
\[
(u_1,u_2,u_3,u_4,u_5)=(AB,AC,Aa,ab,ac),
\qquad (X,Y,Z,W)=(BC,bc,Bb,Cc).
\tag{1}
\]
Each \(u_i\) is the subdivision vertex on the named tree edge and has proper shore port \(p_i\). The mark \(e\) lies in the arbitrary six-port shore. Assume complete exact Case-XII support with forbidden \(e\)-states \(eX,eY\), so the two allowed pentagons are
\[
S_+=e-Z-X-Y-W-e,
\qquad S_-=e-Z-Y-X-W-e.
\tag{2}
\]

**Theorem.** No such pole exists, at any shore order or cycle rank. This excludes one forbidden-pair orbit of one previously untreated one-spoke prism-tree orbit. It does not exclude the other forbidden pairs or the other one-spoke prism trees.

**The mandatory row and transfer test.** The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eX)(eZ)\) BF row. Name its six **complete** matching occurrences
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad A_0=e,\quad A_1=e.
\tag{3}
\]
The \(Z\)-starting component of \(R\triangle K\) cannot end at \(X\), which would give forbidden \([eX]\) beside \(P\), or at \(Y\), which would give forbidden \((eX)(eY)\). It therefore ends at \(W\). Switch this whole-pole component to \(R'=eW,K'=W\). The complete shore restriction of \(R'\) equals that of \(R\).

For either singleton-\(e\) occurrence \(D\in\{A_0,A_1\}\), compare the \(e\)-starting paths of \(R\triangle D\) and \(R'\triangle D\). They exit the shore through the **same** proper port, since the shore restrictions of \(R,R'\) coincide. The complementary three-matching half \(P+J+E\), where \(E\) is the other singleton-\(e\) occurrence, has state \(eX\in T\). Exactly as in [Note 496's complete-matching transfer argument](496-the-x-y-forbidden-hamilton-k33-pair-fails-an-x-arm-transfer.md), avoiding a forbidden \(T\)--\(T\) row requires the exterior endpoint transfer
\[
S_+:X\longrightarrow Y,
\qquad S_-:Y\longrightarrow X
\tag{4}
\]
for **each** of \(A_0,A_1\). The test is about actual alternating paths of complete matchings; it imposes no assumed shore pairing.

**Only two long \(Z\)--\(W\) routes.** If \(R=eZ\) is rooted at \(Z:B\), the route to \(W:C\) uses \(B-u_1-A-u_2-C\), so \(K\) covers both endpoints of mark \(X=BC\) before it can choose an \(X\)-half. This is impossible. The route to \(W:c\) uses three tree edges and forces
\[
R:Z:B,\quad K:X:C,Y:b,W:c; B u_1,A u_3,a u_5; p_2,p_4.
\tag{5}
\]
If \(R\) is rooted at \(Z:b\), the route to \(W:c\) similarly covers both ends of \(Y=bc\) and is impossible. The route to \(W:C\) forces
\[
R:Z:b,\quad K:X:B,Y:c,W:C; b u_4,a u_3,A u_2; p_1,p_5.
\tag{6}
\]
Semicolons in (5)--(6) separate marked halves, tree halves and proper ports. The zero-port \(P=eX\) roots at \(X:B\) or \(X:C\). We treat the four resulting cases.

**Route (5), root \(P:X:C\).** The \(X\)-mark load makes both singleton-\(e\) occurrences take \(X:B\). Loads at \(B,b,c,C\) then force each of them to take \(Y:c,Z:b,W:C\). Each \(D\) has one tree half \(A u_i\), \(i\in\{1,2,3\}\), and one \(a u_j\), \(j\in\{4,5\}\). Following its three exterior terminal arms with \(R\) and \(R'\) gives these **necessary** possibilities for (4):
\[
\begin{array}{c|c}
\text{transfer}&(i,j)\text{ that can realize it}\\\hline
X\to Y&(2,4)\\
Y\to X&(1,5),(3,5).
\end{array}
\tag{7}
\]
For direct checking, the old \(X\)-arm exits at \(p_4\) if \(j=5\), at \(p_1\) if \((i,j)=(3,4)\), and at \(p_3\) otherwise; the new \(Y\)-arm exits at \(p_3\) for \(i=2\) and at \(p_2\) otherwise. The old \(Y\)-arm exits at \(p_5\) if \(j=4\), at \(p_1\) if \((i,j)=(3,5)\), and at \(p_3\) otherwise; the new \(X\)-arm exits at \(p_3\) for \(i=1\) and at \(p_1\) otherwise. Equality of the appropriate old and new ports gives (7). Both \(A_0,A_1\) cannot use \(A u_2\), since \(P\) already uses it; both cannot use \(a u_5\), since \(K\) already uses it. Thus neither pentagon survives.

**Route (6), root \(P:X:B\).** Now both singleton-\(e\) occurrences take \(X:C,Y:b,Z:B,W:c\). Write their two tree halves as \(A u_i,a u_j\), with the same \(i,j\) ranges. The analogous arm trace yields
\[
\begin{array}{c|c}
\text{transfer}&(i,j)\text{ that can realize it}\\\hline
X\to Y&(2,4),(3,4)\\
Y\to X&(1,5).
\end{array}
\tag{8}
\]
Here the old \(X\)-arm exits at \(p_3\) for \(i=2\) and \(p_2\) otherwise. The new \(Y\)-arm exits at \(p_4\) for \(j=5\), at \(p_2\) for \((i,j)=(3,4)\), and at \(p_3\) otherwise. The old \(Y\)-arm exits at \(p_3\) for \(i=1\) and \(p_1\) otherwise; the new \(X\)-arm exits at \(p_5\) for \(j=4\), at \(p_2\) for \((i,j)=(3,5)\), and at \(p_3\) otherwise. For \(S_+\), both singleton-\(e\) occurrences would take \(a u_4\), overloading it with \(R\). For \(S_-\), both would take \(A u_1\), overloading it with \(P\). Hence this case is impossible.

**Route (5), root \(P:X:B\).** The two singleton-\(e\) occurrences split \(X:B,X:C\); call them \(D_B,D_C\) according to that half. Both \(R,R'\) take \(C u_2\). If \(D_C\) uses \(p_2\), its \(X\)-arm is fixed at \(p_2\), contradicting (4). Thus \(D_C\) uses \(A u_2\). Its mark \(Z\) must then be at \(B\): otherwise its \(B u_1\) half would occupy \(B\), while \(Z:b,Y:c\) would occupy \(b,c\), leaving neither end of \(W=Cc\) available. The remaining marks of \(D_C\) are forced to \(Y:b,W:c\); its last tree half is \(a u_4\) or \(a u_5\).

For \(D_C\), the old \(X\)-arm exits at \(p_1\), while the new \(p_1\)-arm ends at \(Z\). Therefore \(S_+\) is impossible. Its new \(X\)-arm exits at \(p_3\); the old \(Y\)-arm reaches \(p_3\) only when \(D_C:a u_4\). Thus \(S_-\) forces that half. The \(X:B\) occurrence \(D_B\) must have marks \(Y:c,Z:b,W:C\). Its new \(X\)-arm exits at \(p_1\), and its old \(Y\)-arm reaches \(p_1\) only when \(D_B:A u_3,a u_5\). The remaining original-vertex loads then force
\[
J:Y:c,Z:b,W:C; B u_1,A u_2,a u_4; p_3,p_5.
\tag{9}
\]
The old row's proper shore sets are now exactly
\[
\begin{array}{c|cccccc}
&P&R&K&J&D_C&D_B\\\hline
\partial Q&\varnothing&\varnothing&p_2p_4&p_3p_5&ep_1p_3p_5&ep_1p_2p_4.
\end{array}
\tag{10}
\]
Keep **each of these six complete shore matchings one for one**. Give both zero-port occurrences new \(eX\)-triple exteriors rooted at \(X:B\), and replace only the other four exteriors by

| occurrence | new role | marked halves | tree halves |
|---|---|---|---|
| \(K\) | \(X\) | \(Y:c,Z:b,W:C\) | \(B u_1,A u_3,a u_5\) |
| \(J\) | \(X\) | \(Y:c,Z:b,W:C\) | \(B u_1,A u_2,a u_4\) |
| \(D_C\) | \(e\) | \(X:C,Y:b,Z:B,W:c\) | \(A u_2,a u_4\) |
| \(D_B\) | \(e\) | \(X:C,Y:b,Z:B,W:c\) | \(A u_3,a u_5\) |

Their unused tree subdivisions are precisely their old proper ports in (10). At \(u_1,\ldots,u_5\), the colour pairs on the two tree halves and proper port are respectively
\[
(PR,KJ,D_CD_B),\ (PR,JD_C,KD_B),\ (PR,KD_B,JD_C),
(PR,JD_C,KD_B),\ (PR,KD_B,JD_C).
\tag{11}
\]
At the original vertices \(B,C,A,a,b,c\), the three incident pairs are, respectively,
\[
(PR,KJ,D_CD_B),\ (PR,KJ,D_CD_B),\ (PR,JD_C,KD_B),
(PR,JD_C,KD_B),\ (PR,KJ,D_CD_B),\ (PR,KJ,D_CD_B).
\tag{12}
\]
The three edge identities at each original vertex are specified by the new masks above; in particular, at \(B\) the pairs \(PR,KJ,D_CD_B\) occupy \(X:B,Bu_1,Z:B\). At \(t_X\), the terminal, \(B\)-half and \(C\)-half pairs are \(KJ,PR,D_CD_B\); at \(t_Y,t_Z,t_W\), the terminal pair is \(PR\) and the two marked-half pairs are \(KJ,D_CD_B\). Terminal \(e\) has \(D_C,D_B\). This certifies load two on every exterior edge and a genuine \([eX]\) BF row using the unchanged complete shore matchings. Since \(eX\in T\), it is forbidden.

**Route (6), root \(P:X:C\).** The two singleton-\(e\) occurrences split \(X:B,X:C\); write \(D_B:X:B\), \(D_C:X:C\). Both \(R,R'\) take \(B u_1\). If \(D_B:p_1\), its \(X\)-arm is fixed; otherwise it uses \(A u_1\) and its other marks are forced to \(Y:c,Z:b,W:C\). Its old \(Y\)-arm exits at \(p_4\) or \(p_5\), whereas its new \(X\)-arm exits at \(p_2\), so \(S_-\) is impossible. For \(S_+\), the old \(X\)-arm exits at \(p_3\), and the new \(p_3\)-arm reaches \(Y\) only if \(D_B:a u_5\). This forces \(D_C\) to take \(Y:b,Z:B,W:c\). Its old \(X\)-arm exits at \(p_2\), and the new \(p_2\)-arm reaches \(Y\) only if \(D_C:A u_3,a u_4\). Loads at \(A,a\) then force \(J:C u_2,A u_1,a u_5\), with marks \(Y:b,Z:B,W:c\). The old proper shore sets are
\[
\begin{array}{c|cccccc}
&P&R&K&J&D_C&D_B\\\hline
\partial Q&\varnothing&\varnothing&p_1p_5&p_3p_4&ep_1p_2p_5&ep_2p_3p_4.
\end{array}
\tag{13}
\]
Keep these same six complete shore matchings. Give both zero-port occurrences new \(eX\)-triple exteriors rooted at \(X:C\), and use these new singleton exteriors:

| occurrence | new role | marked halves | tree halves |
|---|---|---|---|
| \(K\) | \(X\) | \(Y:b,Z:B,W:c\) | \(C u_2,A u_3,a u_4\) |
| \(J\) | \(X\) | \(Y:b,Z:B,W:c\) | \(A u_1,C u_2,a u_5\) |
| \(D_C\) | \(e\) | \(X:B,Y:c,Z:b,W:C\) | \(A u_3,a u_4\) |
| \(D_B\) | \(e\) | \(X:B,Y:c,Z:b,W:C\) | \(A u_1,a u_5\) |

At \(u_1,\ldots,u_5\), the pairs on its two tree halves and port are
\[
(PR,JD_B,KD_C),\ (PR,KJ,D_CD_B),\ (PR,KD_C,JD_B),
(PR,KD_C,JD_B),\ (PR,JD_B,KD_C).
\tag{14}
\]
At \(B,C,A,a,b,c\), the three incident pairs are, respectively,
\[
(PR,KJ,D_CD_B),\ (PR,KJ,D_CD_B),\ (PR,JD_B,KD_C),
(PR,KD_C,JD_B),\ (PR,KJ,D_CD_B),\ (PR,KJ,D_CD_B).
\tag{15}
\]
At \(t_X\), the terminal, \(C\)-half and \(B\)-half pairs are \(KJ,PR,D_CD_B\); at each of \(t_Y,t_Z,t_W\), the terminal pair is \(PR\), with its two marked halves carrying \(KJ,D_CD_B\). Terminal \(e\) has \(D_C,D_B\). The port sets in (13) are unchanged, every complete exterior matching meets every original and subdivision vertex once, and (14)--(15) prove load two. Thus this is another genuine forbidden \([eX]\) BF row. All four cases fail, proving the theorem. \(\square\)

The proof uses the complete actual matching row mandated by Appendix XII. The transfer stage may change complete shore masks by switching an \(e\)-starting path; the final two recompletions instead preserve all six old complete shore masks exactly. This result is conditional on the upstream Note-358 tree-profile reduction and on the hand-derived local certificates above; it does not settle other one-spoke trees, the full exact Case-XII obstruction or Berge--Fulkerson. No OMEN or local mathematical recomputation was used; an independent proof check remains necessary.
