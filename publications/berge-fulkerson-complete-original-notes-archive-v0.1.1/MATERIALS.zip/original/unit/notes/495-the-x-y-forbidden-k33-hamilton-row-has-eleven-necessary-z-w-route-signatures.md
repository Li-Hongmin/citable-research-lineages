> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Eleven necessary \(Z\)--\(W\) routes for the \(X,Y\)-forbidden Hamilton \(K_{3,3}\) row

Work in the \(|U|=r=5\), one-internal-mark, one-shore profile of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), with Hamilton exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,16,25,36).                             \tag{1}
\]
Assume complete exact Case-XII support with forbidden \(e\)-states \(\{eX,eY\}\); the two allowed \(e\)-states are \(eZ,eW\). The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eX)(eZ)\) BF row. Name its six **complete** matching occurrences
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad A=e,\quad B=e.
\tag{2}
\]
Boundary names here describe roles, not equality of full matching masks. The fixed half containing \(P\) has state \(eX\in T\).

**Necessary-route theorem.** The \(Z\)-starting component of \(R\triangle K\) must end at \(W\) and lie wholly in the tree exterior. The four potential endpoint routes have lengths \(1,4,2,1\), from \(Z:2\) to \(W:3/6\) and \(Z:5\) to \(W:3/6\), respectively. The length-four \(2\to6\) route is impossible because singleton \(K\) has only three tree halves. Under the old BF load-two rule, the other three routes have at most the following eleven marked/tree/port signatures. In the table \(X:1\) in the \(P\)-column means that the zero-port triple \(P=eX\) is rooted there.

| route of \(R\triangle K\) | root of \(P\) | marked halves of \(K\) | tree halves of \(K\) | proper ports of \(K\) |
|---|---|---|---|---|
| \(Z:2\to W:3\) | \(X:1\) | \(X:1,Y:6,W:3\) | \(2u_2,4u_4,5u_5\) | \(p_1,p_3\) |
| \(Z:2\to W:3\) | \(X:4\) | \(X:1,Y:6,W:3\) | \(2u_2,4u_3,5u_5\) | \(p_1,p_4\) |
| \(Z:2\to W:3\) | \(X:4\) | \(X:1,Y:6,W:3\) | \(2u_2,4u_4,5u_5\) | \(p_1,p_3\) |
| \(Z:2\to W:3\) | \(X:1\) | \(X:4,Y:6,W:3\) | \(1u_1,2u_2,5u_5\) | \(p_3,p_4\) |
| \(Z:5\to W:3\) | \(X:1\) | \(X:1,Y:6,W:3\) | \(2u_1,4u_3,5u_4\) | \(p_2,p_5\) |
| \(Z:5\to W:3\) | \(X:1\) | \(X:1,Y:6,W:3\) | \(2u_2,4u_3,5u_4\) | \(p_1,p_5\) |
| \(Z:5\to W:3\) | \(X:4\) | \(X:1,Y:6,W:3\) | \(2u_1,4u_3,5u_4\) | \(p_2,p_5\) |
| \(Z:5\to W:6\) | \(X:1\) | \(X:4,Y:1,W:6\) | \(2u_1,3u_2,5u_5\) | \(p_3,p_4\) |
| \(Z:5\to W:6\) | \(X:1\) | \(X:4,Y:1,W:6\) | \(2u_1,3u_3,5u_5\) | \(p_2,p_4\) |
| \(Z:5\to W:6\) | \(X:1\) | \(X:4,Y:1,W:6\) | \(2u_2,3u_3,5u_5\) | \(p_1,p_4\) |
| \(Z:5\to W:6\) | \(X:4\) | \(X:4,Y:1,W:6\) | \(2u_1,3u_2,5u_5\) | \(p_3,p_4\) |

These are **necessary** exterior restrictions of \(P,R,K\), not full BF rows or claims that their other three complete matchings can be supplied by an arbitrary shore. The table uses no bound on shore order, rank or complement parity.

**Proof.** If the \(Z\)-starting component of \(R\triangle K\) ended at \(X\), switching these two complete matchings would change \(R=eZ\) to forbidden \(eX\), giving \([eX]\) beside unchanged \(P=eX\). Ending at \(Y\) would give forbidden \((eX)(eY)\). Hence it ends at \(W\). The zero-port triple \(R\) uses the rooted tree matching of Note 358. On the \(Z\)-starting alternating component, a \(K\)-tree half at an original vertex is followed at its subdivision by the opposite \(R\)-tree half; the component cannot enter the shore and moves away from the root. Each crossed tree edge consumes one of \(K\)'s three tree halves. Thus \(2\to6\), of length four, is impossible.

For \(Z:2\to W:3\), the route fixes \(R\)'s root \(Z:2\), \(K:2u_2\) and \(K:W:3\). Both zero-port triples \(P,R\), regardless of \(P\)'s root, use \(5u_4,6u_5\), so \(K\) must take \(5u_5\) and \(Y:6\). If \(K\) uses \(X:1\), its remaining tree half at vertex 4 is \(4u_3\) or \(4u_4\); with \(P:X:1\), the first is overloaded because \(P,R\) already use \(4u_3\). If \(K\) uses \(X:4\), it must take \(1u_1\); then \(P:X:4\) is overloaded at \(1u_1\), leaving only \(P:X:1\). This gives the first four rows.

For \(Z:5\to W:3\), the route fixes \(R:Z:5\), \(K:5u_4,4u_3,W:3\). Original vertices 4 and 5 are covered by its tree halves, so \(K\) must take \(X:1,Y:6\) and one further tree half at vertex 2, namely \(2u_1\) or \(2u_2\). If \(P:X:4\) and \(K:2u_2\), then \(P,R,K\) all use \(2u_2\), which is forbidden by load two. The middle three rows remain.

For \(Z:5\to W:6\), the route fixes \(R:Z:5\), \(K:5u_5,W:6\). Then \(K\) must take \(Y:1,X:4\) and cover vertices 2 and 3 by distinct tree subdivisions. The three possibilities are \((2u_1,3u_2),(2u_1,3u_3),(2u_2,3u_3)\). If \(P:X:4\), both \(P,R\) already use \(2u_2\) and \(3u_3\), so only the first possibility survives. This gives the last four rows. Each port set is the complement of \(K\)'s three used tree subdivisions. \(\square\)

The reflected forbidden pair \(\{eY,eW\}\) has a corresponding list under the path reversal \(i\mapsto7-i\), which interchanges \(X\) and \(W\) and fixes \(Y,Z\). [Note 496](496-the-x-y-forbidden-hamilton-k33-pair-fails-an-x-arm-transfer.md) subsequently uses complete matching switches and the two singleton-\(e\) load to exclude all eleven signatures under exact support. This route does not address the other forbidden-pair orbits of this tree, the one-spoke prism, other profiles or Berge--Fulkerson. The classification and subsequent exclusion are hand-derived and await independent review; no OMEN or local mathematical recomputation was used.
