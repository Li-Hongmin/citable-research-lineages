> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A five-cut shore of a deficient barrier cannot have Case-XIII \(L^*\) support

Assume the connected, deficient-core, minimum-host, full exact-Case-XII
setting of [Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md).
Let \(J\) be the simple marked cubic core, \(M\) its five marked
edges, and \(F=J-M\).  Choose a normalized maximum Tutte barrier
\(U\) as in Note 169: \(F[U]\) is edgeless, no mark meets \(U\),
and \(F-U\) has \(|U|+2\) odd components and no even component.
Suppose two of those odd components, \(A,B\), each have a five-edge
\(J\)-cut, with no mark internal to a component.  The remaining
odd components are singletons.  This note allows **any** \(|U|\);
it does not assume the two-vertex quotients used in a separate draft.

## The complementary shore has no all-terminal perfect matching

Let \(C\in\{A,B\}\), and let \(r_C\) be the number of unmarked
\(U\)--\(C\) edges.  The five-edge cut of \(C\) has exactly
\(r_C\) such edges and \(5-r_C\) marked edges.  Open this cut in
the **whole** minimum counterexample \(G\), including the original
opposite pentagon, and call the complementary five-pole \(E(C)\).

\[
\boxed{E(C)\text{ has no perfect matching using all five cut
semiedges}.}                                                   \tag{1}
\]

**Proof.**  Put \(k=|U|\) and suppose such a matching \(P\) existed.
By [Note 169, (1)](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md),
the \(r_C\) unmarked edges from \(U\) to \(C\) have distinct
\(U\)-endpoints.  Their cut semiedges in \(E(C)\) match those
\(r_C\) vertices, leaving at most \(k-r_C\) vertices of \(U\)
available to match any other odd component of \(F-U\).

Every marked edge meeting \(C\) runs to another component of
\(F-U\).  Its subdivision vertex in \(E(C)\) is matched by its
cut semiedge, so it cannot match a vertex of that other component.
There are \(5-r_C\) such marks, leaving exactly \(r_C\) of the
five marks.  Each remaining marked subdivision vertex can match
at most one vertex of an odd component of \(F-U\).  Thus the
available barrier vertices and marks can give an external matching
edge to at most
\[
             (k-r_C)+r_C=k
\]
odd components besides \(C\).  But there are
\((k+2)-1=k+1\) such components.  Each is odd and needs at least
one external matching edge.  Edges of the original pentagon enter
the core only through those same marked subdivision vertices, so
they cannot supply another route.  This contradiction proves (1).
\(\square\)

This argument concerns a **single actual perfect matching** on the
opposite whole-host shore.  It neither assumes a BF row on \(E(C)\)
nor identifies matching masks across different rows.

## Exact boundary profile of the complementary shore

The same count determines more than (1).  Let \(D\) be the other
five-cut component.  In a matching of \(E(C)\), let \(b\) be its
number of cut semiedges, \(a\) the number of those semiedges at
\(U\)-neighbours, and \(h\) the number of edges used between the
five marked subdivision vertices and the original pentagon.
The pentagon has odd order, so \(h\) is odd and positive.  The
\(k-a\) unsaturated barrier vertices and the
\(5-(b-a)-h\) marked subdivision vertices matched into the core
give exactly
\[
             k+5-b-h                                      \tag{2}
\]
external matching hits on components of \(F-U\) other than \(C\).
The \(k\) singleton components each take one hit, while odd \(D\)
takes an odd positive number \(\lambda_D\).  Thus
\[
\boxed{\lambda_D=5-b-h.}                                  \tag{3}
\]
For a triple-boundary matching, \(b=3\), forcing
\((h,\lambda_D)=(1,1)\).  For a singleton-boundary matching,
\(b=1\), the only possibilities are \((h,\lambda_D)=(1,3)\)
and \((3,1)\).  The all-terminal case \(b=5\) is impossible again.

In any actual six-matching BF row of \(E(C)\), its two triple
occurrences each have \(h=1\).  The five links from marked
subdivision vertices to the original pentagon each have load two,
so the four singleton occurrences have total \(h\)-load eight.
Each has \(h=1\) or \(3\); consequently **exactly two singleton
occurrences have \(\lambda_D=3\), and two have \(\lambda_D=1\)**.
This is a rowwise quota on genuine matchings of the alternative
whole-host shore.  It does not identify their masks across rows.

## Consequence of the published complete BF relation

If \(C\) is cyclic and is not an ordinary pentagon, its cut is
cycle-separating in \(G\); its complement contains the original
pentagon and is itself larger than a pentagon.  [Proposition 4.4 and
Figure 7 of Máčajová--Mazzuoccolo--Tabarelli
(2026)](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf)
therefore require \(C,E(C)\) to have the two Case-XIII complete BF
relations \(L^*,R^*\), in some order.  The \(R^*\) relation contains
the all-terminal BF type and hence an all-terminal perfect matching.
Equation (1) excludes \(E(C)=R^*\).  Therefore
\[
\boxed{\text{Every cyclic nonpentagonal five-cut component of this
barrier profile has }R^*\text{ support, and }E(C)\text{ has }L^*.}
                                                               \tag{4}
\]
In particular **neither of the two five-cut components can have
\(L^*\) support**.  This is an all-orders restriction on the *actual
complete* shore BF relation, not an existence claim for a surviving
\(R^*\) pairing or a proof of the Berge--Fulkerson conjecture.

## A two-vertex quotient consequence

For the two-vertex quotient \(II_A\), the unmarked exterior edges
are \(u_1A,u_1B,u_1w_1,u_2A,u_2w_1,u_2w_2\); the five marks
are two \(A\)--\(B\) edges \(z_1,z_2\), one \(A\)--\(w_1\)
edge \(x\), and two \(B\)--\(w_2\) edges.  Thus shore \(A\)
has unmarked cut ports at \(u_1,u_2\) and marked cut ports at
\(t_{z_1},t_{z_2},t_x\).  In \(E(A)\), the singleton \(w_1\) has precisely
the three neighbours \(u_1,u_2,t_x\), all cut-port vertices.
A triple-boundary matching using these three ports would leave
\(w_1\) unmatched.  Hence the BF loop on the other two ports
\([z_1z_2]\) is absent from \(E(A)\).  Figure 7's \(L^*\)
relation contains every loop (using the figure rather than the
[Appendix XIII transcription error noted in Note 165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md)).
Consequently \(E(A)\) has neither \(R^*\) support by (1) nor
\(L^*\) support by this missing loop.  If \(A\) were cyclic and
nonpentagonal, Proposition 4.4 would require one of those two
relations for \(E(A)\), a contradiction.  Thus
\[
\boxed{II_A\text{ in the stated exact-Case-XII setting }
\Longrightarrow A\text{ is a three-vertex tree or an ordinary pentagon}.}
                                                               \tag{5}
\]

Equation (5) does not restrict the other shore \(B\) to a small
type.  The remaining two-vertex quotient types and the branch where
\(F\) itself has a perfect matching still require separate full
matching-closure arguments.  The proof is analytic and uses the
upstream minimum-host and normalized-barrier results cited above;
those upstream results have not received an independent proof review.
