> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real \(D_4\) adjacent Hamilton row has a forbidden cross-mask loop

[Note 476](476-the-adjacent-forbidden-hamilton-x4-root-has-four-k-signatures.md) leaves four necessary \(K=Z\) signatures for the fixed Hamilton exterior when the exact-Case-XII forbidden pair is \(\{eX,eY\}\) and the required \((eX)(eZ)\) row has \(P=eX\) rooted at \(X:4\). It also shows that a \(D_4\) row cannot be recompleted to forbidden \([eX]\) while keeping its six complete shore restrictions label by label. Here is a genuine \(D_4\) row whose **full** perfect-matching closure nevertheless contains \([eX]\). The example makes that fixed-mask boundary non-vacuous; it is not an exact-Case-XII pole.

Use the exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36),
\tag{1}
\]
with six distinct matching occurrences \(P=eX,R=eZ,K=Z,J=X,a=e,b=e\). At each \(u_i\), list first tree half, second tree half, proper port; at each marked subdivision, list terminal and then the halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Assign the following edge pairs:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,KJ,ab)&(PR,Ka,Jb)&(PR,Jb,Ka)&
(Ra,PJ,Kb)&(RK,Pb,Ja),
\end{array}                                                    \tag{2}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PR,KJ,ab)&(PK,ab,RJ)&(PR,Jb,Ka).
\end{array}                                                    \tag{3}
\]
The original vertices \(1,\ldots,6\) see
\[
(PR,ab,KJ),\quad (KJ,PR,ab),\quad (Ka,PR,Jb),\quad
(Jb,Ra,PK),\quad (PJ,RK,ab),\quad (Pb,RJ,Ka).           \tag{4}
\]
Every triple in (2)--(4) partitions \(\{P,R,K,J,a,b\}\). The terminal pairs are \(e=ab,X=RJ,Y=W=PR,Z=PK\), so this is the required \((eX)(eZ)\) type. The \(K\)-edges are \(X:4,Y:1,W:6,2u_1,3u_2,5u_5,p_3,p_4\), exactly signature \(D_4\) of Note 476. The proper-port pairs are \((ab,Jb,Ka,Kb,Ja)\), a phase of Note 476(3) with \((\alpha,\delta,\nu,\theta,\eta)=(J,a,b,a,b)\).

For the shore take vertices \(q_e,q_1,\ldots,q_5\), connect \(q_i\) to \(u_i\), put terminal \(e\) at \(q_e\), and form the six-cycle
\[
q_e-q_2-q_4-q_3-q_5-q_1-q_e
\]
with successive edge pairs
\[
                   PK,\quad Ra,\quad PJ,\quad Rb,\quad PK,\quad RJ. \tag{5}
\]
At \(q_e,q_2,q_4,q_3,q_5,q_1\), the two cycle-edge pairs and the port pair are, respectively,
\[
(RJ,PK,ab),\quad(PK,Ra,Jb),\quad(Ra,PJ,Kb),\quad
(PJ,Rb,Ka),\quad(Rb,PK,Ja),\quad(PK,RJ,ab).            \tag{6}
\]
Again every triple partitions the six labels. Thus (2)--(6) specify six **complete actual perfect matchings** of a simple connected 21-vertex cubic five-pole, with each edge covered twice. The outer prism edges are all subdivided; a mixed cycle needs two shore connectors, a shore edge, and at least two exterior edges, so the girth is at least five.

The zero-port shore restriction \(Q_P\) consists of the first, third, and fifth cycle edges in (5). Its shore complement consists of three port paths and no closed component, with pairing
\[
                         ep_1\mid p_2p_4\mid p_3p_5.     \tag{7}
\]
For the \(eX\)-triple \(P\) rooted at \(X:4\), [Note 359's exterior pairing table](359-two-root-parity-gate-and-k33-sharpness.md) gives
\[
                         Xp_5\mid p_1p_2\mid p_3p_4.     \tag{8}
\]
Gluing (7) and (8) gives the single open route \(e,p_1,p_2,p_4,p_3,p_5,X\) through all six shore ports. More explicitly, with \(t_j\) the subdivision vertex of marked edge \(j\), the entire complement of the **complete** matching \(P\) is
\[
e,q_e,q_1,u_1,2,t_Z,6,t_W,3,u_2,q_2,q_4,u_4,4,u_3,
q_3,q_5,u_5,5,t_Y,1,t_X,X.                                   \tag{9}
\]
Consecutive entries are joined by complementary edges from (2)--(6). The route visits all 21 internal vertices exactly once, so no other component remains. Alternating its edges from the \(e\) end gives a singleton-\(e\) matching whose shore restriction is exactly the old \(Q_a\): it uses \(e,p_1,p_3,p_5\) and internal edge \(q_2q_4\). The other colour gives a singleton-\(X\) shore matching \(Q_{X}^{\mathrm{new}}\) using \(p_2,p_4\) and internal edges \(q_eq_1,q_3q_5\). The port signature \(\{p_2,p_4\}\) is absent from the six old shore restrictions. Thus the explicit forbidden BF loop has shore-mask multiset
\[
                     Q_P,Q_P,Q_a,Q_a,Q_{X}^{\mathrm{new}},Q_{X}^{\mathrm{new}}. \tag{10}
\]
Doubling the Tait colouring gives a genuine forbidden \([eX]\) loop in the complete support.

Note 476 proves that this \([eX]\) is inaccessible by a recompletion retaining the displayed six shore restrictions label by label; (10) exhibits both repeated old masks and a new shore mask in one forbidden full-closure escape. This does not rule out a different forbidden loop using only old masks with new multiplicities. Thus both the old \(D_4\) row and its forbidden full-closure escape are real. This example does not prove that **every** \(D_4\) row forces forbidden support, and it does not settle the other three \(P:X:4\) signatures, the \(P:X:1\) branch, other marked exteriors, exact Case XII, or Berge--Fulkerson. The certificates are hand-derived, without OMEN or local mathematical recomputation, and await independent review. \(\square\)
