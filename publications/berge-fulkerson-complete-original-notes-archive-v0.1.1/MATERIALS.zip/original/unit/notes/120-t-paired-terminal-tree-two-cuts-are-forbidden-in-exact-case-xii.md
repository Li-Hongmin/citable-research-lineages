> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Case XII forbids a two-terminal tree cut on a \(T\)-pair

**Stronger subsequent result.** [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) also excludes every \(S\)-paired terminal edge, so the terminal vertices of an exact-Case-XII pole are independent. The local \(T\)-pair closure lemma and contraction calculation below retain their stated scope.

In a minimum Berge--Fulkerson counterexample with a Case-XII five-cut, [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) leaves two kinds of proper 2-edge-cut on the non-cycle five-pole: a one-vertex tree carrying one terminal, or a two-vertex tree carrying two terminals. The complete Case-XII BF support of Máčajová--Mazzuoccolo--Tabarelli (2026, Proposition 4.4 and Figure 7, DOI 10.26493/1855-3974.3409.c13) rules out the second kind whenever its two terminals form a pair in \(T=\{12,15,23,34,45\}\). This support argument applies to an arbitrary exact-support pole, without a girth or Tait-colourability hypothesis. In the minimum-host setting specifically, the same \(T\)-pair exclusion already follows from girth five: \(T\) is the set of adjacent pairs on the opposite \(C_5\), and a terminal-terminal edge on that pair would make a 4-cycle in the closed host.

## A local BF-support closure lemma

Let \(H\) be a cubic five-pole. Suppose adjacent vertices \(a,b\) are joined by a proper edge \(h\), each has one terminal semiedge (at positions \(i,j\), respectively), and each has one further proper edge to the rest of \(H\). Put \(p=ij\). Let \(q\) be a pair disjoint from \(p\), and let \(q_1,q_2\) be the other two pairs among the three positions outside \(p\). Then

\[
(p)(q)\in\operatorname{BFsupp}(H)
\quad\Longrightarrow\quad
(12345)\in\operatorname{BFsupp}(H)
\quad\text{or}\quad
\{(p)(q_1),(p)(q_2)\}\subseteq\operatorname{BFsupp}(H).
                                                               \tag{1}
\]

Here \((12345)\) is the BF type with one colour on all five terminals. The two alternatives in (1) need not be exclusive.

**Proof.** Name the other three terminal positions \(k,\ell,m\), with \(q=\ell m\). In a BF colouring of type \((p)(q)\), let colour \(u\) be absent at \(i,j\) and present at \(k,\ell,m\); let colour \(v\) be absent at \(\ell,m\) and present at \(i,j,k\). The four remaining colours \(a_i,a_j,a_\ell,a_m\) occur once, at their subscripted terminals. The two terminal labels at the tree vertices are therefore

\[
\phi(s_i)=\{v,a_i\},\qquad \phi(s_j)=\{v,a_j\}.       \tag{2}
\]

The internal edge label \(D=\phi(h)\) is a two-subset of \(\{u,a_\ell,a_m\}\). Write \(\alpha\) for the one colour of this triple outside \(D\). Since the three incident two-colour labels partition all six colours at each cubic vertex, the two edges from the tree to the rest have labels

\[
\phi(c_i)=\{a_j,\alpha\},\qquad
\phi(c_j)=\{a_i,\alpha\}.                              \tag{3}
\]

Keep every edge outside the two-vertex tree, including \(c_i,c_j\), unchanged. For **any** \(t\in\{v\}\cup D\), replace the three internal labels by

\[
\phi_t(s_i)=\{t,a_i\},\qquad
\phi_t(s_j)=\{t,a_j\},\qquad
\phi_t(h)=(\{v\}\cup D)\setminus\{t\}.                 \tag{4}
\]

Equations (3)--(4) again partition all six colours at both vertices. They therefore give an actual BF colouring of the same five-pole. If \(u\in D\), choose \(t=u\). Colour \(u\), already present at \(k,\ell,m\), now appears at all five terminals, yielding \((12345)\).

If \(u\notin D\), then \(D=\{a_\ell,a_m\}\). Choosing \(t=a_\ell\) makes \(a_\ell\) a triple colour present at \(i,j,\ell\), hence absent at \(k,m\); colour \(u\) remains absent at \(i,j\). This gives type \((p)(km)\). Choosing \(t=a_m\) similarly gives \((p)(k\ell)\). These are exactly \(q_1,q_2\), proving (1). \(\square\)

## Case-XII consequence

Fix \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\). For each \(p\in T\), the three pairs on the complementary terminal triple consist of exactly one \(S\)-pair \(q\) and two \(T\)-pairs:

| \(p\in T\) | unique disjoint \(q\in S\) |
|---|---|
| \(12\) | \(35\) |
| \(15\) | \(24\) |
| \(23\) | \(14\) |
| \(34\) | \(25\) |
| \(45\) | \(13\) |

Exact Case-XII support contains each \((p)(q)\) in the table, while excluding \((12345)\) and every \(T\)--\(T\) type. If the two-vertex terminal tree had terminals \(p\in T\), the alternatives in (1) would both contradict these exclusions. Therefore **no such cut exists**.

In particular, in any exact-Case-XII pole with five distinct terminal vertices, a proper edge joining two terminal vertices can join only an \(S\)-pair. Thus the graph induced by the five terminal vertices is a subgraph of the \(S\)-pentagon. For the side of a minimum counterexample, it is in fact a **matching** in that pentagon: two adjacent terminal-terminal edges would make a three-vertex terminal path separated from the rest by two proper edges. [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md) forces the opposite shore of that cut to be a two-vertex tree, leaving a five-vertex pole, contrary to the direct order bound of [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md). Consequently no such three-vertex path exists. A terminal triangle is also impossible because the minimum host has girth five. Hence at most two terminal-terminal edges remain, and if there are two, they are disjoint \(S\)-edges.

In the minimum-host setting of [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md), a proper 2-edge-cut of an exact Case-XII side can isolate a two-vertex terminal tree only when its terminal pair lies in \(S\). The cut isolating a single terminal vertex is intrinsic to every five-pole with distinct terminal vertices and is outside this exclusion. For \(p\in S\), all three disjoint pair types \((p)(q)\) are permitted by Case XII, so the particular closure (1) gives no contradiction; this note does not claim that such an \(S\)-pair cut is realizable or that it preserves the common-\(B,C\) seed. The matching bound on terminal-terminal edges in a minimum host likewise follows from Note 019's cut classification and girth; it is recorded above only to state the resulting structural scope precisely.

There is nevertheless a precise contraction boundary for the surviving \(S\)-pair case. Let \(p\in S\), and let \(q\in T\) be its unique disjoint \(T\)-pair. Choose any actual \((p)(q)\) BF colouring of \(H\). In the proof above, \(u\in D\) would create the forbidden all-terminal type, so necessarily \(D=\{a_\ell,a_m\}\) and \(\alpha=u\). Delete the two tree vertices and regard \(c_i,c_j\) as terminal semiedges of the remaining five-pole \(K\). By (3), colour \(u\) occurs on both new semiedges; it already occurs on all three original terminals of \(K\). The restricted colouring is therefore an **all-terminal BF cover of \(K\)**. Consequently this contraction cannot preserve exact Case-XII negative support, even though it preserves a real BF witness. It does not by itself give a BF cover of the original closed host, because extending the projected all-terminal colouring through the tree changes its five-terminal boundary type.

[Note 122](122-disjoint-s-terminal-edges-force-forbidden-all-terminal-bf-cover.md) strengthens the minimum-host terminal-vertex matching bound above from at most two edges to at most one by excluding two disjoint \(S\)-terminal edges. [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) subsequently excludes even one \(S\)-terminal edge.
