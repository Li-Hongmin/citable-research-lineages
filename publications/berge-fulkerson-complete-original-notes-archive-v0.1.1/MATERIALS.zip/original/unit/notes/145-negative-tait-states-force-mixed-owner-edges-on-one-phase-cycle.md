> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Forbidden Tait states force mixed owner edges on a singleton phase cycle

The four-junction concentration of [Notes 142](142-overlap-rows-force-four-singleton-phase-junctions.md) and [143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) has a direct componentwise proof. It also gives a sharper conclusion when the total junction count is six: all forbidden-Tait intersection witnesses then lie on **one** class-three phase cycle. This is a statement about actual complete matching masks in one BF row; it does not assume or establish an exact-Case-XII pole.

Fix an actual cubic-five-pole row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1,           \tag{1}
\]
and let \(\mathcal O\) be the proper even-cycle components of \(Z_3\triangle Y_3\). Pair the six occurrences as
\(E_1=(U_{35},r_{34})\), \(E_2=(Z_3,Y_3)\), \(E_3=(D_5,C_4)\), with junction count \(J\) as in Note 142. For \(I\subseteq\mathcal O\), write \(Z^I_3,Y^I_3\) for the actual pair obtained by switching precisely those components.

**Phase-blocker lemma.** If \(X\) is any one of \(U_{35},D_5,r_{34},C_4\), then
\[
\boxed{\quad X\cap Z^I_3\ne\varnothing\quad\hbox{for every }I
\quad\Longleftrightarrow\quad
\exists\Omega\in\mathcal O:
 X\cap Z_3\cap E(\Omega)\ne\varnothing
 \text{ and }X\cap Y_3\cap E(\Omega)\ne\varnothing.\quad}    \tag{2}
\]
Here intersections are of complete edge masks, including semiedges, while \(E(\Omega)\) contains only proper edges.

**Proof.** On a common edge of \(Z_3,Y_3\), row (1) already has load two, so \(X\) cannot use it. On each component \(\Omega\), the mask \(Z^I_3\) chooses either the original \(Z_3\)-phase or the original \(Y_3\)-phase, independently of the other components. If \(X\) meets both phases on one component, every global phase meets \(X\). If no component has both intersections, choose on each component a phase avoided by \(X\). The resulting actual \(Z^I_3\) is disjoint from \(X\). \(\square\)

**Concentration theorem.** If state \(34\) has no Tait colouring, one component \(\Omega_r\in\mathcal O\) contains both an \(r_{34}Z_3\)-owned edge and an \(r_{34}Y_3\)-owned edge; one component \(\Omega_C\in\mathcal O\) contains both a \(C_4Z_3\)-owned edge and a \(C_4Y_3\)-owned edge. Each of these components has an even number \(n\ge4\) of junctions and at least \(n+2\) proper edges. Consequently \(J\ge4\), and if \(J\le6\) then \(\Omega_r=\Omega_C\). In particular, a four-junction phase cycle forced by this argument has at least six edges, even when state \(35\) is Tait-colourable.

If state \(35\) also has no Tait colouring, the full difference \(Z_3\triangle Y_3\) contains all eight distinct owner-pair types
\[
\boxed{rZ,\ rY,\ CZ,\ CY,\ UZ,\ UY,\ DZ,\ DY.}       \tag{3}
\]
Hence \(|E(Z_3\triangle Y_3)|\ge8\) at every junction count. If \(J\le6\), **one component** contains all eight types and has at least eight proper edges. This extends the eight-edge phase-cycle conclusion of Note 143 from the four-junction diamond to every row with \(J=4\) or \(6\), without normalizing any junction-free components.

**Proof.** If \(r_{34}\) were disjoint from a phase \(Z^I_3\), the cubic complement of these two actual matchings would be a singleton-\(4\) matching: together they would be a forbidden state-\(34\) Tait colouring. The same argument with \(C_4\) gives a complementary triple-\(34\) matching. Thus both \(r_{34}\) and \(C_4\) meet **every** phase \(Z^I_3\), and (2) gives \(\Omega_r,\Omega_C\).

On \(Z_3\triangle Y_3\), the owner pairs \(rZ\) and \(rY\) are both type-\(12\) in the three paired differences, but the former is split between the BF halves and the latter overloaded. The split/overloaded status is constant along each maximal type-\(12\) strand. Hence \(\Omega_r\) contains at least two type-\(12\) strands. At each junction of a \(Z_3\triangle Y_3\) component its strand type changes between \(12\) and \(23\), so a cycle with two type-\(12\) strands has at least four junctions. Likewise \(CZ\) and \(CY\) are respectively split and overloaded type-\(23\) edges, proving the claim for \(\Omega_C\).

If every strand on one of these mixed components had length one, its \(12\) and \(23\) edge types would alternate in step with its \(Z\) and \(Y\) edge phases. Every type-\(12\) edge would then have the **same** singleton phase, contrary to the simultaneous \(rZ,rY\) edges on \(\Omega_r\); the same argument using type \(23\) contradicts the simultaneous \(CZ,CY\) edges on \(\Omega_C\). Thus \(L>n\). Both \(L\) and \(n\) are even, so \(L\ge n+2\). Two distinct mixed components would contribute at least eight junctions; therefore \(J\le6\) forces them to coincide.

If state \(35\) is also absent, disjointness of \(U_{35}\) from any \(Z^I_3\) would give a Tait colouring with singleton \(5\), and disjointness of \(D_5\) from any \(Z^I_3\) would give a Tait colouring with triple state \(35\). Applying (2) again produces mixed \(U\)- and \(D\)-cycles, each with at least four junctions by the same strand argument: \(UZ,UY\) occupy overloaded and split type-\(12\) edges, while \(DZ,DY\) occupy overloaded and split type-\(23\) edges. The eight owner pairs in (3) name eight different edges because every edge of (1) has exactly two occurrence owners. Thus the whole \(Z\triangle Y\) difference has at least eight edges. With \(J\le6\), all four mixed cycles are the same component, so that one component has at least eight edges. \(\square\)

In Note 143's normalized four-junction diamond, each of the four phase-cycle strands has one fixed type and overload status. The pairs \(UZ,rY\), \(UY,rZ\), \(DZ,CY\), and \(DY,CZ\) therefore supply two different edges on its respective overloaded-\(12\), split-\(12\), overloaded-\(23\), and split-\(23\) strand. This gives the four individual two-edge bounds of Note 143 directly. The overloaded type-\(13\) chord has two edges as well: absence of state \(35\) forces \(U\cap D\ne\varnothing\), and absence of state \(34\) forces \(r\cap C\ne\varnothing\); after Note 143's normalization both intersections lie on that chord.

There is a further exact consequence for Note 143's aligned fixed-\(B_2\) transfer. Its formula \(J'_\Omega=L-2\), with odd total \(J'\ge L-1\), now combines with \(L\ge6\) under absence of state \(34\) to give \(J'\ge5\). Thus **the aligned \(J'=3\) branch is impossible even when state \(35\) is Tait-colourable**. If \(J'=5\), necessarily \(L=6\), and state \(35\) must be Tait-colourable by the eight-edge conclusion above. In the Tait-empty branch \(J'\ge7\), as before.

For a real exact-Case-XII pole, absence of the BF loop \([34]\) supplies the first hypothesis. The extra state-\(35\) absence holds in its Tait-empty branch, but need not hold in its \(S\)-Tait branch, as [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) explains. The primary boundary classification is Máčajová--Mazzuoccolo--Tabarelli (2026), Proposition 4.4 and Appendix XII. The mixed-owner conclusion does not by itself make the two pairings of [Note 144](144-fixed-singleton-phase-cube-has-two-terminal-pairing-gates.md) incompatible; it identifies four specific blocker edges on the phase cycle where that compatibility must be decided.
