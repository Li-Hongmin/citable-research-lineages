> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case X

This note records a boundary-action exclusion for one of the exact
five-cut cases of Mácajová--Mazzuoccolo--Tabarelli.  It is conditional on the
published Appendix transcription and its ordered semiedge convention.  It
does not address the cyclically-6-connected branch and is not a proof of the
Berge--Fulkerson conjecture.

Let \(H_{\mathrm X}\) be the 38-type Case-X boundary set.  For a labelled
BF-colouring of a cubic 5-pole, record the endpoint pairing of every nonempty
two-colour boundary path system.  Switching one component preserves the
route of the switched colour pair and every route for a disjoint colour pair.
We impose no persistence condition for overlapping pairs, omit internal
alternating cycles, and retain every colour relabelling that maps a switched
boundary labelling to the fixed target representative.  These choices make
the resulting finite transition system an over-approximation of the action on
any actual pole.

Let \(\mathscr S_0(\tau)\) be the locally unary- and disjoint-binary-coherent
signatures over a supported type \(\tau\), and let
\(\mathscr S_{r+1}\) delete states having no transition into
\(\mathscr S_r\).  Every actual exact-support family is a post-fixed family,
so a supported type must have a nonempty fibre in
\(\mathscr S_\infty=\bigcap_r\mathscr S_r\).

For Case X the state system contains 780 local signatures and 15,600
component-switch transitions.  The greatest-fixed-point deletion has six
rounds, removing respectively 220, 3, 13, 34, 60 and 156 states.  Its final
survivor set has 294 signatures, while the following six supported fibres are
empty:

\[
(13)(34),\quad (14)(34),\quad (24)(34),\quad
(24)(35),\quad (25)(34),\quad (34)(35).
\]

Since each of these types belongs to \(H_{\mathrm X}\), no real cubic
5-pole can have complete BF support exactly \(H_{\mathrm X}\).  Combined with
the corresponding exclusions in Notes 046, 048--049 and 051--053, this
conditionally removes Case X from the exact-connectivity-five list.  The
same action layer does not distinguish Cases IV and IX, and the Case-XII
common perfect-matching incidence gate remains open.

The proof certificate is the file
units/berge-fulkerson/scratch/worker-mmtt-case-x-global-action/verify_case_x_global_kempe_action.py,
which terminates with CASE_X_GLOBAL_KEMPE_ACTION_EXCLUDED.
