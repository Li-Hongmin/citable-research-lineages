> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(b,d\) neighbours fail by a second exterior switch

Continue the Hamilton-path \(K_{3,3}\) exterior of [Notes 373](373-the-hamilton-k33-end-pair-row-cannot-root-at-x.md)–[374](374-hamilton-k33-separated-d-pairs-have-no-case-xii-row.md): the tree is \(x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t\), with shore ports \(p_0,\ldots,p_4\), and exterior marks \(a=xs,b=xt,c=yt,d=zr\). Consider the two pentagons with \(e\)-neighbour pair \(\{b,d\}\):
\[
\begin{array}{c|c}
S_7=e-b-a-c-d-e&T_7=\{ea,ec,bc,bd,ad\},\\
S_8=e-b-c-a-d-e&T_8=\{ea,ec,ab,bd,cd\}.
\end{array}                                                   \tag{1}
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eb)(bd)\) row for either placement and forbids every double-\(T_i\) row. In particular \(eb,ed\in S_i\) and \(ea,ec,bd\in T_i\).

**Theorem.** Neither pentagon in (1) can be the complete exact-Case-XII support of a cubic five-pole with this exterior, at any shore order or cycle rank. Together with Note 374, six of the twelve labelled pentagons on this Hamilton-path exterior are excluded.

**Proof.** In a required \((eb)(bd)\) BF row name the state-\(eb\) triple \(P\), state-\(bd\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(d\) matching \(D\), and two singleton-\(b\) occurrences \(B_1,B_2\). By [Note 230's shore quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [Note 358's rooted-tree rule](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), \(P\) is zero-port and rooted at \(x\) or \(t\). As \(R=bd\in T_i\), switching \(P\) with either \(B_j\) must give \(ed\in S_i\); the alternatives \(ea,ec\) would be double-\(T_i\) rows. The \(b\)--\(d\) terminal path is wholly exterior by [Note 244's argument](244-every-shore-mark-must-neighbour-the-internal-mark.md).

**Root \(x\).** The triple \(P\) uses \(t_bx\), terminals \(a,c,d\), and tree edges \(ru_0,yu_1,su_2,zu_3,tu_4\). A \(b\)--\(d\) path either goes directly through \(x,u_0,r\), or continues from \(r\) through \(u_1,y,u_2,s,u_3,z\). On the latter, a singleton-\(b\) matching has already matched both \(x,s\), the endpoints of mark \(a\), so it cannot cover \(t_a\). Both \(B_j\) therefore use
\[
H_x:b-t_b-x-u_0-r-t_d-d.                         \tag{2}
\]
Each selects \(t_as,t_dr,xu_0\). At \(t_a\), the two \(B_j\) saturate \(t_as\), while \(P,R\) select terminal \(a\), forcing \(E,D\) onto \(t_ax\). At \(x\), the six matchings then occupy \(xu_0\) twice with \(B_1,B_2\), \(t_ax\) twice with \(E,D\), and \(t_bx\) twice with \(P,R\). Because \(P,R\) have terminal \(c\) and use the \(x\)-half of \(b\), both must match \(t\) through \(tu_4\). If a \(B_j\) covered \(c=yt\) through \(y\), it too would need the already saturated edge \(tu_4\) at \(t\). Hence both select \(t_ct\). Mark loads now force \(D\) onto \(t_ax,t_bt,t_cy\) and \(R,E\) onto \(t_dz\).

Switch \(P,B_1\) along (2), obtaining a state-\(ed\) triple \(P'\) with the same complete shore matching as \(P\). In \(P'\triangle D\), the \(d\)-terminal path begins \(d-t_d-r\). The singleton \(D\) must leave \(r\) through \(ru_0\) or \(ru_1\). In the first case the path continues through \(x\) to mark \(a\), because \(D\) uses \(t_ax\); in the second it continues through \(y\) to mark \(c\), because \(D\) uses \(t_cy\). It cannot end at \(b\). Switching this component gives \(ea\in T_i\) or \(ec\in T_i\) beside \(R=bd\in T_i\), a contradiction.

**Root \(t\).** Now \(P\) uses \(t_bt\), terminals \(a,c,d\), and tree edges \(xu_0,ru_1,yu_2,su_3,zu_4\). The possible \(b\)--\(d\) routes start along \(b-t_b-t-u_4-z\). The route continuing through \(u_3,s,u_2,y,u_1,r\) already matches both \(t,y\), the endpoints of mark \(c\), and cannot be used by a singleton-\(b\) matching. Hence both \(B_j\) use
\[
H_t:b-t_b-t-u_4-z-t_d-d.                         \tag{3}
\]
Each uses \(t_dz,tu_4\). It must cover \(c\) through \(t_cy\), because \(t\) is already matched on (3). Thus \(E,D\) use \(t_ct\). At \(t\), the two \(B_j\) saturate \(tu_4\) and \(E,D\) saturate \(t_ct\); therefore \(R\) joins \(P\) on \(t_bt\). At \(x\), \(P,R\) then saturate \(xu_0\), so each \(B_j\) must cover \(a=xs\) through \(t_ax\). Consequently \(D\) uses \(t_as,t_bx,t_ct\).

Switch \(P,B_1\) along (3), obtaining a zero-port state-\(ed\) triple \(P'\) rooted at \(z\). In \(P'\triangle D\), the \(d\)-terminal path begins \(d-t_d-z\). If \(D\) leaves \(z\) through \(zu_4\), the path reaches \(t\) and ends at \(c\), because \(D\) uses \(t_ct\). If it leaves through \(zu_3\), it reaches \(s\) and ends at \(a\), because \(D\) uses \(t_as\). It cannot end at \(b\). The resulting \(ec\) or \(ea\) state lies in \(T_i\) beside \(R=bd\in T_i\), the final contradiction. \(\square\)

The proof uses only the positive \((eb)(bd)\) row, negative double-\(T_i\) support, and switches of actual complete perfect matchings. It does not couple shore matchings across distinct rows. The other six labelled pentagons on this tree, the triangular prism, general Case XII and the Berge--Fulkerson conjecture remain unresolved. The analytic argument awaits independent review; no local mathematical recomputation was used.
