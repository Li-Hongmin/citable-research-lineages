> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An endpoint path marking with an end-to-end cross mark is impossible

Continue the minimum-host, complete exact-Case-XII, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md), now with its \(|U|=r=4\) path-tree exterior. Write the five singleton components in order as \(A,B,C,D,E\) and
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad h_i=u_i\Sigma.
\]
Put the shore mark at the endvertex \(A\) and take
\[
a:A\!:\!\Sigma,\qquad b:AE,\quad c:CE,\quad d:BD.     \tag{1}
\]
These cross marks respect girth five. The reflected marking with \(a\) at \(E\) is equivalent.

**Theorem.** No pole with (1) has complete exact-Case-XII perfect-matching support, at any shore order or unmarked cycle rank. Every possible second neighbour \(b,c,d\) of the internal mark \(e\) is excluded. This closes one marked path-tree placement, not the whole path-tree exterior.

For any proposed second neighbour \(s\), the [published Case-XII support](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(as)\) row. Since \(ea,es\in S\) and \(as\in T\), its \(ea\) half is pure \(S\). Write the six complete matching occurrences as
\[
X_a+Y_a+Z_e+U_{as}+V_a+W_s=2\mathbf1.              \tag{2}
\]
The zero-port quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) fixes the state-\(ea\) triple exterior:
\[
X_a=\{a:A,1B,2C,3D,4E\}.                           \tag{3}
\]
Purity forces the \(a\)-terminal path of \(X_a\triangle Y_a\) to end at \(s\), and [Note 244's argument](244-every-shore-mark-must-neighbour-the-internal-mark.md) keeps it exterior. Exchanging the two **complete** singleton-\(a\) occurrences \(Y_a,V_a\) in (2) preserves a real row and its opposite \(T\)-state; hence both must meet the same pure-\(S\) path condition.

## The neighbour \(d=BD\)

The path from \(A\) to \(d:D\) would use \(1A,2B,3C,d:D\). Then \(b:AE\) must use \(E\), while \(c:CE\) has neither \(C\) nor \(E\) free. Thus the path ends at \(d:B\), forcing the unique singleton exterior
\[
Y_a|_{\rm ext}=V_a|_{\rm ext}
=\{d:B,b:E,c:C,1A,4D,h_2,h_3\}.                   \tag{4}
\]
Switching the \(A\)--\(B\) path gives the zero-port triple \(X_d=\{d:B,1A,2C,3D,4E\}\), with exactly the same complete shore matching as \(X_a\). Since both singleton-\(a\) occurrences use every edge in (4), \(Z_e\) avoids them all. Its exterior is consequently forced to be
\[
Z_e|_{\rm ext}=\{a:\Sigma,b:A,c:E,d:D,2B,3C,h_1,h_4\}. \tag{5}
\]
The three proper shore ports of \(Z_e\) have the following exterior terminal endpoints against \((X_a,X_d)\):
\[
a:\Sigma:(b,a),\qquad h_1:(d,b),\qquad h_4:(c,c).    \tag{6}
\]
For example, the \(h_1\)-route against \(X_a\) runs through \(u_1-B-u_2-C-u_3-D-t_d\); against \(X_d\) it reaches \(b\) through \(u_1-A-t_b\). The shore \(e\)-path pairs with one fixed port because \(X_a,X_d\) have the same shore matching. Purity would require endpoints \(b,c\) in opposite order, which (6) does not provide. This excludes \(ed\in S\).

## The neighbour \(b=AE\)

An \(a\)--\(b\) path ending at \(E\) would occupy the entire tree path from \(A\) to \(E\); the remaining marks \(c:CE,d:BD\) then cannot both take free endpoints. Hence the switch must use the common endpoint \(A\), producing the zero-port triple
\[
X_b=\{b:A,1B,2C,3D,4E\}                         \tag{7}
\]
with the same shore matching as \(X_a\). A singleton-\(e\) exterior using \(b:A\) cannot exchange the \(c,d\) terminal routes: the changed component at \(A\) involves only \(a,b\). If it uses \(b:E\), then \(c:C\) is forced. The four possible exteriors of \(Z_e\), indexed by its \(a\)-half and \(d\)-half, have these port routes against \((X_a,X_b)\):

| \(a\)-half, \(d\)-half | Remaining exterior edges of \(Z_e\) | Proper shore port: endpoint pair |
|---|---|---|
| \(a:A,d:B\) | \(4D,h_1,h_2,h_3\) | \(h_1:(d,d),\ h_2:(c,c),\ h_3:(b,a)\) |
| \(a:A,d:D\) | \(1B,h_2,h_3,h_4\) | \(h_2:(c,c),\ h_3:(d,d),\ h_4:(b,a)\) |
| \(a:\Sigma,d:B\) | \(1A,4D,h_2,h_3\) | \(a:\Sigma:(d,a),\ h_2:(c,c),\ h_3:(b,d)\) |
| \(a:\Sigma,d:D\) | \(1A,2B,h_3,h_4\) | \(a:\Sigma:(c,a),\ h_3:(d,d),\ h_4:(b,c)\) |

Every row also contains \(b:E,c:C\), and \(Z_e\) uses its terminal \(e\). The table is exhaustive because \(a\) and \(d\) each have two halves and the remaining \(K\)-edges are then fixed by the path. In no row does one port have endpoint pair \((c,d)\) or \((d,c)\), as purity would require. This excludes \(eb\in S\).

## The neighbour \(c=CE\)

The \(a\)--\(c\) path ending at \(E\) leaves \(b:AE\) without an endpoint, so it must end at \(C\). Its singleton exterior is unique:
\[
Y_a|_{\rm ext}=V_a|_{\rm ext}
=\{c:C,b:E,d:D,1A,2B,h_3,h_4\}.                   \tag{8}
\]
The edge-load-two rule fixes the singleton-\(e\) exterior as \(\{a:\Sigma,b:A,c:E,d:B,3C,4D,h_1,h_2\}\). This configuration can be pure: the shore \(e\)-path may pair with \(h_1\), whose endpoints against \(X_a\) and the switched state-\(ec\) triple are \(d,b\). A second obstruction is therefore needed.

The pure \(ea\) half in (2) has **unit load on every proper exterior edge**. The following table repartitions exactly that load into a state-\(eb\) half, with the *same shore port set in each slot*:

| Shore ports | Original \(ea\) exterior | Replacement \(eb\) exterior |
|---|---|---|
| \(\varnothing\) | \(X_a:\{a:A,1B,2C,3D,4E\}\) | \(X'_b:\{b:E,1A,2B,3C,4D\}\) |
| \(\{h_3,h_4\}\) | \(Y_a:\{c:C,b:E,d:D,1A,2B,h_3,h_4\}\) | \(Y'_b:\{a:A,c:E,d:D,1B,2C,h_3,h_4\}\) |
| \(\{e,a:\Sigma,h_1,h_2\}\) | \(Z_e:\{a:\Sigma,b:A,c:E,d:B,3C,4D,h_1,h_2\}\) | \(Z'_e:\{a:\Sigma,b:A,c:C,d:B,3D,4E,h_1,h_2\}\) |

Each column consists of three genuine exterior matchings. Across its three slots, every \(K\)-edge, every mark half, and every \(h_i\) occurs exactly once. Reuse the three **complete shore restrictions** of the original \(X_a,Y_a,Z_e\) with the replacement exteriors. Slotwise port equality makes three actual full-pole perfect matchings; equality of aggregate exterior and shore loads lets them replace the original half in (2). The opposite \(ac\in T\) half is retained. This creates a real \((eb)(ac)\) row, forbidden because \(eb\in T\) when \(ea,ec\in S\). Thus \(ec\in S\) is impossible too. \(\square\)

This proof uses complete perfect-matching closure through the exchange of singleton occurrences and the final same-port shore splice. It does not restrict \(\Sigma\)'s order or cycle rank. At \(|U|=r=4\), exactly three path-tree markings now remain up to reflection, before choosing the second \(e\)-neighbour:
\[
\begin{array}{c|c}
\text{shore mark}&\text{three cross marks}\\ \hline
A&AD,BE,CE\\
B&AD,AE,CE\\
C&AD,AE,BE.
\end{array}
\]
Indeed, an exterior mark cannot join consecutive path vertices: its two-edge subdivision together with their two-edge \(K\)-path would make a four-cycle. The only possible cross pairs are \(AC,AD,AE,BD,BE,CE\). Solving the residual degree requirements \((2,1,1,1,2)\) after placing the shore mark gives, up to reflection, the four markings listed here and in (1). The remaining three markings, larger barriers, other Tutte profiles, and Berge–Fulkerson remain open.
