> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The short \(Y\)-to-\(Z\) Hamilton signatures force forbidden completions

Continue [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md) for the Hamilton three-spoke exterior with tree \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) and marks \((X,Y,Z,W)=(14,15,26,36)\). In a genuine \((eX)(eY)\) BF row, name the six **complete** matching occurrences \(P=eX,R=eY,K=Y,J=X,E=e,F=e\), and put \(\Lambda=\{J,E,F\}\). This note treats the third line of Note 446(3): \(R=eY:5\), the \(Y\)-path ends at \(Z:2\), and \(K\) takes \(X:1,Z:2,W:6\), tree halves \(3u_2,4u_3,5u_4\), and ports \(p_1,p_5\).

**Claim.** For either root \(P=eX:1\) or \(P=eX:4\), every such BF row can be recompleted to a genuine forbidden \((eX)(eW)\) row, retaining each labelled occurrence's entire original shore matching. No equality between different shore matchings is assumed. Thus the two labelled signatures in this third line are impossible when \((eX)(eW)\) is absent.

An \(u_i\) triple below lists the pair on its first-end half, second-end half, and proper port. A marked triple lists its terminal pair and then the halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposition denotes an unordered pair of occurrence labels.

## Original root \(P=eX:1\)

Write \(p_1=KB\) and \(p_5=KL\), where \(B,L\in\Lambda\). At \(X:1\) the old pair is \(PK\), so the partitions at \(1,u_1\) make \(B\ne L\). Let \(C\) be the third element of \(\Lambda\). The partitions at \(2,u_2\), followed by the marked \(Z/W\) subdivisions, give \(p_2=\Lambda\setminus\{N\}\) and \(p_3=\Lambda\setminus\{M\}\), where \(\{N,M\}=\{B,L\}\). At \(4\), the old \(X:4=EF\), so \(p_4=EF\). Thus the old port pairs are exactly
\[
(KB,\ \Lambda\setminus\{N\},\ \Lambda\setminus\{M\},\ EF,\ KL),
\qquad \{B,L,C\}=\{N,M,C\}=\Lambda.
\tag{1}
\]
Recomplete with \(P=eX:1,R=eW:3,K=W,J=X,E=F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RL,PC,KB)&(RK,PN,\Lambda\setminus\{N\})
 &(KM,PR,\Lambda\setminus\{M\})
 &(KJ,PR,EF)&(\Lambda\setminus\{L\},PR,KL)
\end{array}                                                   \tag{2}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,PK,EF)&(PR,\Lambda\setminus\{L\},KL)
 &(PR,\Lambda\setminus\{C\},KC)
 &(PK,RC,\Lambda\setminus\{C\}).
\end{array}                                                   \tag{3}
\]
At original vertices \(1,\ldots,6\), the triples of incident pairs are
\[
(PK,RL,\Lambda\setminus\{L\}),\quad
(PC,RK,\Lambda\setminus\{C\}),\quad
(PN,KM,RC),\quad
(PR,KJ,EF),\quad
(PR,\Lambda\setminus\{L\},KL),\quad
(PR,KC,\Lambda\setminus\{C\}).
\tag{4}
\]
These partition all six labels since \(B,L,C\) and \(N,M,C\) each permute \(\Lambda\). The port column of (2) is (1), and (3) has terminal type \((eX)(eW)\).

## Original root \(P=eX:4\)

Relabel \(E,F\) so that the original \(X:4=PD\) and \(X:1=KH\), where \(\{H,D\}=\{E,F\}\). At \(u_1\) write \(p_1=KB\), where \(B\in\Lambda\) is arbitrary. At vertex \(4\), let \(A\) accompany \(R\) on \(4u_4\), and \(C\) accompany \(K\) on \(4u_3\). Then \(\{A,C\}=\{J,H\}\). The partitions at \(u_1,u_2,u_3,u_4,u_5\) make the old port pairs exactly
\[
(KB,\ \Lambda\setminus\{B\},\ \Lambda\setminus\{C\},\
\Lambda\setminus\{A\},\ KH),
\qquad \{A,C,D\}=\Lambda.
\tag{5}
\]
Choose \(a,b\in\Lambda\) such that \(\{a,b,B\}=\Lambda\) and \(a\ne H\); this is always possible, including \(B=H\). Let \(q\) be the unique element of \(\Lambda\setminus\{a,H\}\), so \(\{a,H,q\}=\Lambda\). Recomplete with \(P=eX:1,R=eW:6,K=W,J=X,E=F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(Ra,Pb,KB)&(RK,PB,\Lambda\setminus\{B\})
 &(RK,PC,\Lambda\setminus\{C\})
 &(RA,PK,\Lambda\setminus\{A\})
 &(Rq,Pa,KH)
\end{array}                                                   \tag{6}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,PH,KD)&(PR,Kq,\Lambda\setminus\{q\})
 &(PR,\Lambda\setminus\{b\},Kb)
 &(PK,\Lambda\setminus\{B\},RB).
\end{array}                                                   \tag{7}
\]
At vertices \(1,\ldots,6\), the incident pairs are
\[
(PH,Ra,Kq),\quad
(Pb,RK,\Lambda\setminus\{b\}),\quad
(PB,RK,\Lambda\setminus\{B\}),\quad
(PC,RA,KD),\quad
(PK,Rq,\Lambda\setminus\{q\}),\quad
(Pa,RB,Kb).
\tag{8}
\]
They partition the six labels by \(\{a,b,B\}=\{a,H,q\}=\{A,C,D\}=\Lambda\). In particular the choice \(B=H\), which makes the two end-port pairs equal, causes no failure: choose either ordering of the other two \(\Lambda\)-labels as \(a,b\). The port column of (6) is (5), and the terminal pairs in (7) give \((eX)(eW)\).

Every subdivision triple in (2)–(3) and (6)–(7) partitions the labels, as do the original-vertex triples (4) and (8). Thus these are exterior perfect-matching rows of load two. Their five proper-port pairs agree label by label with the original row; the shore terminal \(e\) remains selected by \(E,F\). Glue each new exterior restriction to its **own unchanged complete shore matching** to obtain the forbidden row in the same actual pole. The two signatures of the third line are therefore impossible under exact Case XII with forbidden \(\{eX,eW\}\). Along with Notes 447–448, this eliminates the first five of the twelve signatures in Note 446(3). The other seven signatures, the remaining forbidden pairs of this exterior, and Berge–Fulkerson are not decided by this note. This is a hand-derived certificate awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)
