> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Eight \(D_4\) phases force \([eY]\); the other four resist fixed-mask recompletion

Use the fixed Hamilton exterior and the six labels of [Note 476](476-the-adjacent-forbidden-hamilton-x4-root-has-four-k-signatures.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36),
\]
\[
P=eX,\quad R=eZ,\quad K=Z,\quad J=X,\quad a=e,\quad b=e.
\]
For a genuine \(D_4\) row, put \(S=\{J,a,b\}\). Its labelled shore-port pairs are
\[
e=ab,\qquad
(p_1,p_2,p_3,p_4,p_5)
=\bigl(S\setminus\{\alpha\},S\setminus\{\delta\},
K\theta,K\eta,S\setminus\{\nu\}\bigr),
\quad \{\alpha,\delta,\nu\}=S,
\quad \{\theta,\eta\}=\{a,b\}.                 \tag{1}
\]
There are twelve labelled phases. In the orientation of [published Appendix XII](https://amc-journal.eu/index.php/amc/article/view/3409/2156) (Máčajová--Mazzuoccolo--Tabarelli, *Ars Math. Contemp.* 26 (2026), DOI 10.26493/1855-3974.3409.c13), exact Case XII with forbidden \(\{eX,eY\}\) excludes precisely \([eX],[eY],(eX)(eY)\) among the ten types whose two triples both miss \(e\); its required genuine row is \((eX)(eZ)\). We retain each of the old row's six **complete** shore matching restrictions label by label when recompleting the exterior.

## Eight phases: a forbidden \([eY]\) on the same six shore matchings

If \(\nu\ne\theta\), define \(\bar\sigma\) as the other member of \(\{a,b\}\) and choose
\[
\begin{array}{c|cccc}
&\sigma&\tau&\epsilon&\phi\\ \hline
\nu=\eta&\eta&J&\theta&J\\
\nu=J&\theta&\eta&J&\theta
\end{array}.                                                   \tag{2}
\]
At \(u_i\), list the halves toward \(i,i+1\) and then the proper port. At each marked subdivision, list the terminal and then the halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Replace the old exterior edge pairs by
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RK,P\alpha,S\setminus\{\alpha\})&
(RK,P\delta,S\setminus\{\delta\})&
(R\nu,P\tau,K\theta)&
(R\epsilon,P\phi,K\eta)&
(K\nu,PR,S\setminus\{\nu\})
\end{array},                                                   \tag{3}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,S\setminus\{\sigma\},K\sigma)&
(KJ,P\sigma,R\bar\sigma)&
(PR,S\setminus\{\alpha\},K\alpha)&
(PR,K\alpha,S\setminus\{\alpha\})
\end{array}.                                                   \tag{4}
\]
The five proper-port pairs in (3) are exactly (1), and \(e=ab\) is unchanged. For a direct original-vertex check, vertices \(1,\ldots,6\) see
\[
\begin{split}
&(RK,S\setminus\{\sigma\},P\sigma),\quad
(P\alpha,RK,S\setminus\{\alpha\}),\quad
(P\delta,R\nu,K\alpha),\\
&(P\tau,R\epsilon,K\sigma),\quad
(P\phi,R\bar\sigma,K\nu),\quad
(PR,K\alpha,S\setminus\{\alpha\}).
\end{split}                                                     \tag{5}
\]
For \(\nu=\eta\), \(\{\alpha,\delta\}=\{J,\theta\}\), and for \(\nu=J\), \(\{\alpha,\delta\}=\{a,b\}\). Substituting (2) shows that every triple in (3)--(5) partitions \(\{P,R,K,J,a,b\}\). The terminals are \(e=ab,Y=KJ,X=Z=W=PR\), hence the new row has forbidden type \([eY]\). There are four phases in each line of (2), so eight of the twelve \(D_4\) phases are excluded at **every shore order**, provided the old row is genuine.

## Four phases: all fixed-port forbidden types fail

It remains \(\nu=\theta\). Interchange \(a,b\) if necessary and put \(\theta=a,\eta=b\). Then \(\nu=a\), \(\{\alpha,\delta\}=\{J,b\}\), and (1) becomes one of
\[
\begin{array}{c|ccccc}
&p_1&p_2&p_3&p_4&p_5\\ \hline
A&ab&Ja&Ka&Kb&Jb\\
B&Ja&ab&Ka&Kb&Jb.
\end{array}                                                     \tag{6}
\]
By [Note 230's six-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), these fixed port pairs keep \(P,R\) as the zero-port triples, \(a,b\) as singleton-\(e\), and \(K,J\) as the other singletons. The following obstruction uses only the labelled port pairs, so it also applies if shore matchings with the same port pairs are changed internally. As in Note 476, \(K\) uses \(p_3,p_4\); it cannot use either tree half incident with original vertex \(4\). If it were a singleton at \(X\), it could not use \(X:4\) either, leaving that vertex unmatched. Thus \([eX]\) is impossible, and any \((eX)(eY)\) recompletion must put \(K\) at \(Y\), \(J\) at \(X\).

Suppose first that a \([eY]\) row exists. Its terminal pairs must be \(e=ab,Y=KJ,X=Z=W=PR\). Both zero-port triples \(P,R\) root at \(Y:1\) or \(Y:5\); either root puts both on the second half of \(u_5\). Hence \(u_5=(Ka,PR,Jb)\). If both root at \(Y:1\), then \(u_4\)'s second half is \(PR\), its first half is \(Ja\), and \(Y:5=ab\). Original vertex \(5\) repeats \(a\) on \(u_5:5\) and \(Y:5\). If both root at \(Y:5\), then \(u_4\)'s first half is \(PR\), its second is \(Ja\); vertex \(5\) repeats \(a\) on \(u_4:5\) and \(u_5:5\). If the roots split, vertex \(5\) forces \(Y:5\) to pair one triple with \(b\) and \(u_4:5\) to pair the other triple with \(J\). The fixed \(p_4=Kb\) then forces \(u_4:4\) to contain \(a\), while \(Y:1\) also contains \(a\). Since \(X=PR\), its half \(X:1\) cannot contain \(a\), so its other half \(X:4\) does. Vertex \(4\) repeats \(a\). Thus \([eY]\) is impossible.

For \((eX)(eY)\), the zero-port labels \(P,R\) can be interchanged in the **exterior pair search** because neither appears in (6); this does not exchange their complete shore matchings. Take \(P=eX,R=eY\). The terminal pairs are \(e=ab,X=RJ,Y=PK,Z=W=PR\). In every root choice, \(u_5=(Ka,PR,Jb)\). The remaining four root choices give the following direct contradictions:

| \(R\) root | \(P\) root | Forced pairs and repeated label |
|---|---|---|
| \(Y:1\) | \(X:1\) | \(u_4:4=Ja,\ Y:1=Ra,\ X:4=Kb,\ X:1=Pa\); vertex \(1\) repeats \(a\). |
| \(Y:1\) | \(X:4\) | \(u_4:4=Ja,\ Y:1=Ra\); vertex \(1\) forces \(X:1=Kb\), hence \(X:4=Pa\); vertex \(4\) repeats \(a\). |
| \(Y:5\) | \(X:1\) | \(u_4:4=Ra,\ Y:1=Ja\); vertex \(4\) forces \(X:4=Kb\), hence \(X:1=Pa\); vertex \(1\) repeats \(a\). |
| \(Y:5\) | \(X:4\) | \(u_4:4=Ra,\ Y:1=Ja,\ u_3:4=Jb\); vertex \(4\) forces \(X:4=PK\), hence \(X:1=ab\); vertex \(1\) repeats \(a\). |

The first two rows use \(u_4=(Ja,PR,Kb)\). The last two use \(u_4=(Ra,PJ,Kb)\); in the last row \(P,R\) share \(u_3\)'s first half, so \(p_3=Ka\) forces \(u_3:4=Jb\). Consequently no row with the port pairs (6) has any of the three forbidden \(e\)-sector types. In particular, no recompletion preserving the six old complete shore matchings can exclude these four phases.

There is a stronger full-closure boundary. The old six complete shore matchings have only five different six-port signatures: two have the empty signature, and the other four have signatures
\[
Q_a:\{e,p_s,p_t,p_3\},\qquad
Q_b:\{e,p_s,p_4,p_5\},\qquad
Q_K:\{p_3,p_4\},\qquad Q_J:\{p_t,p_5\},             \tag{6a}
\]
where \(\{s,t\}=\{1,2\}\), \(p_s=ab\), and \(p_t=Ja\). Suppose a different six-matching BF row uses only these five shore-port signatures, with repetitions allowed and arbitrary complete shore matchings behind them. If their multiplicities are \(m_a,m_b,m_K,m_J\), load two at \(e,p_t,p_3,p_4,p_5\) gives
\[
m_a+m_b=m_a+m_J=m_a+m_K=m_b+m_K=m_b+m_J=2.          \tag{6b}
\]
Hence \(m_a=m_b=m_K=m_J=1\); the remaining two occurrences have the empty signature. Relabel the six occurrences by these signatures. Their port pairs are exactly (6), already shown unable to realize any of the three forbidden types. In fact **at least two occurrences must have new shore-port signatures**. If exactly one new occurrence is an \(e\)-singleton, the other \(e\)-singleton is \(Q_a\) or \(Q_b\). Two copies of \(Q_K\) or \(Q_J\) would overload, respectively, \(p_3\) or \(p_t\) beside \(Q_a\), and \(p_4\) or \(p_5\) beside \(Q_b\). Hence \(Q_K,Q_J\) each occur once, and the remaining signature is the other old \(e\)-signature. If exactly one new occurrence is a non-\(e\) singleton, two copies of either old \(e\)-signature overload a port beside either old non-\(e\) signature. Thus \(Q_a,Q_b\) each occur once, and the missing non-\(e\) signature is whichever of \(Q_K,Q_J\) was not selected. A new zero-port *matching* still has the old empty port signature and is covered by (6b). Therefore a forbidden row must introduce at least two new-signature matching occurrences, though they need not have distinct signatures. This is a necessary condition, not an assertion that such a forbidden row always exists.

## Both residual port profiles occur in genuine rows

For either line of (6), retain \((\alpha,\delta)=(J,b)\) in line \(A\) or \((b,J)\) in line \(B\). The old \((eX)(eZ)\) exterior row is given by
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\alpha,S\setminus\{\alpha\})&
(PR,K\delta,S\setminus\{\delta\})&
(PR,Jb,Ka)&(Ra,PJ,Kb)&(RK,Pa,Jb)
\end{array},                                                   \tag{7}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PR,KJ,ab)&
(PK,S\setminus\{\alpha\},R\alpha)&
(PR,S\setminus\{\delta\},K\delta).
\end{array}                                                   \tag{8}
\]
At the six original vertices, the three incident pairs are, in order,
\[
(PR,ab,KJ),\quad(K\alpha,PR,S\setminus\{\alpha\}),\quad
(K\delta,PR,S\setminus\{\delta\}),\quad
(Jb,Ra,PK),\quad(PJ,RK,ab),\quad(Pa,R\alpha,K\delta).
\tag{9}
\]
Each is a six-label partition; the marked and tree subdivisions are partitions by (7)--(8). The terminal pairs are \(e=ab,X=RJ,Y=W=PR,Z=PK\), and \(K\) has exactly signature \(D_4\).

For the shore, take \(q_e,q_1,\ldots,q_5\), connect \(q_i\) to \(u_i\), and put terminal \(e\) at \(q_e\). Let \(s\in\{1,2\}\) be the index with \(p_s=ab\), and \(t\) the other index, so \(p_t=Ja\). Use the six-cycle
\[
q_e-q_3-q_t-q_5-q_4-q_s-q_e
\tag{10}
\]
with successive edge pairs \(RJ,Pb,RK,Pa,RJ,PK\). At its vertices in this order, the cycle-edge and port pairs are respectively
\[
(PK,RJ,ab),\ (RJ,Pb,Ka),\ (Pb,RK,Ja),\
(RK,Pa,Jb),\ (Pa,RJ,Kb),\ (RJ,PK,ab),
\tag{11}
\]
all six-label partitions. Equations (7)--(11) therefore give six complete actual perfect matchings on a simple connected 21-vertex cubic five-pole of girth at least five for each port profile. Exchanging \(a,b\) realizes the other two labelled \(\nu=\theta\) phases.

For either shore, the zero-port matching \(Q_P\) takes the \(Pb,Pa,PK\) cycle edges. Its complement has no closed shore component and pairs
\[
e p_3\mid p_s p_4\mid p_t p_5.                         \tag{12}
\]
The complement of the exterior \(P=eX\), rooted at \(X:4\), pairs
\[
X p_5\mid p_1p_2\mid p_3p_4.                            \tag{13}
\]
The three exterior pieces are explicitly \(X-t_X-1-t_Y-5-u_5-p_5\), \(p_1-u_1-2-t_Z-6-t_W-3-u_2-p_2\), and \(p_3-u_3-4-u_4-p_4\); together they visit all 15 exterior vertices. Gluing (12)--(13) gives the single route \(e,p_3,p_4,p_s,p_t,p_5,X\), whose shore pieces visit all six shore vertices. Alternating the complement of \(P\) along this path gives a Tait colouring and hence a genuine forbidden \([eX]\) BF loop in the **complete** support. Starting the singleton-\(e\) colour at \(e\), the two new singleton shore signatures are
\[
\{e,p_3,p_t,p_5\}\quad\hbox{and}\quad\{p_s,p_4\}.
\tag{13a}
\]
Both lie outside (6a), as required by the no-go theorem. These real poles are therefore not exact Case XII.

Thus the \(D_4\) signature has an all-order fixed-mask exclusion for eight labelled phases and a real, sharp fixed-mask obstruction for the other four. The result is confined to \(D_4\) with \(P\) rooted at \(X:4\); it does not exclude those four phases under arbitrary complete closure, the other \(D_i\), the \(P:X:1\) branch, other exteriors, exact Case XII, or Berge--Fulkerson. The derivation and certificates are by hand, without OMEN or local mathematical recomputation, and await independent review. \(\square\)
