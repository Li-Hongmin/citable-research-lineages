> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct \(e\,bc:c\) prism root cannot enter any mixed \(e\)-row

Keep the two-spoke prism exterior of [Notes 408–409](409-the-direct-bc-and-ab-a-prism-root-pair-is-impossible.md), with forbidden \(e\)-labels \(AC,bc\) and allowed \(e\)-labels \(ab,Cc\). Assume complete exact Case-XII BF support. The shore order and all its complementary cycles are unrestricted.

> **Direct-root exclusion.** No actual six-perfect-matching BF row can contain a forbidden zero-port triple \(P=e\,bc:c\) together with an allowed \(e\,ab\) or \(e\,Cc\) triple, regardless of the allowed triple's root or the allowed pentagon orientation.

**Proof.** If the other triple has state \(e\,ab\), its root is \(a\) or \(b\). [Note 409](409-the-direct-bc-and-ab-a-prism-root-pair-is-impossible.md) excludes root \(a\) for both pentagons, and [Note 408](408-the-swapped-bc-ab-prism-root-pair-is-impossible.md) excludes root \(b\) for both.

Now let the other triple \(R\) have state \(e\,Cc\), with either possible root \(C\) or \(c\), and let \(K\) be the row's singleton-\(Cc\) occurrence. The terminal path of \(R\triangle K\) starting at \(Cc\) ends at one of \(ab,AC,bc\), the three terminal semiedges of \(R\). Switching a path ending at \(AC\) or \(bc\) would replace \(R=e\,Cc\) by the forbidden \(e\,AC\) or \(e\,bc\), alongside the unchanged forbidden \(P=e\,bc\). Exact support therefore forces the endpoint \(ab\). Switch that complete alternating terminal path. It gives an actual \(e\,ab\) triple, rooted at \(a\) or \(b\), while \(P\) stays unchanged and the six matching occurrences still load every edge twice. Both roots were excluded above. \(\square\)

This theorem excludes the direct \(bc:c\) root from all required mixed \(e\)-rows in this precise forbidden-label placement. It does not exclude the indirect \(bc:b\) root, the direct forbidden \(AC:A\) root, or the full exact Case-XII relation. Its proof inherits the hand-derived, not independently reviewed, root-pair exclusions of Notes 408–409.
