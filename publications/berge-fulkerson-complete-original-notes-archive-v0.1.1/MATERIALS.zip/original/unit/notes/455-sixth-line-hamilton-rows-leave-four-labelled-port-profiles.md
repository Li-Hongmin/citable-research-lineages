> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sixth-line Hamilton rows leave four labelled port profiles

Continue the Hamilton three-spoke tree and labels of [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md). In its sixth line, a genuine \((eX)(eY)\) BF row has complete occurrences
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad a=e,\quad b=e,
\qquad \Lambda=\{J,a,b\},
\]
with \(P\) rooted at \(4\), \(R\) at \(5\), and \(K\) taking \(X:1,Z:6,W:3,2u_1,5u_5\). Put \(\alpha\in\{a,b\}\) for the old second label on \(X:1=K\alpha\), and let \(\bar\alpha\) denote the other singleton-\(e\) occurrence. Thus \(X:4=P\bar\alpha\) and \(Y:5=R\alpha\). At tree subdivisions, each triple lists first-end half, second-end half, port; at marked subdivisions it lists terminal and both marked halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\).

**Sixth-line closure gate.** Every such row admits a forbidden \([eX]\) recompletion, using all six original complete shore matchings separately, except possibly the four labelled port profiles in (12). Together with [Note 454](454-fifth-line-hamilton-rows-leave-two-labelled-port-phases.md), the twelve necessary signatures of Note 446 have now been reduced to two fifth-line port phases and four sixth-line port profiles. These are necessary boundaries, not claimed exact-Case-XII realizations.

The common old first slots at \(u_1,u_2,u_3\) are \(PR\), because both zero-port triples root to the right; at vertex \(6\), the old \(K\)-halves \(Z:6,W:3\) have the same second label \(\beta\). Thus
\[
u_1=(PR,K\beta,\Lambda\setminus\{\beta\}),\qquad
u_2=(PR,\Lambda\setminus\{\beta\},K\beta),\qquad
Z=(PR,\Lambda\setminus\{\beta\},K\beta),\quad
W=(PR,K\beta,\Lambda\setminus\{\beta\}).
\tag{1}
\]
The remaining old slots are fixed by the two choices below.

## \(K:4u_3\)

Write \(u_3=(PR,K\gamma,\Lambda\setminus\{\gamma\})\),
\(u_4=(R\delta,P\varepsilon,K\lambda)\), and
\(u_5=(K\eta,PR,\Lambda\setminus\{\eta\})\).
Vertex \(4\), vertex \(5\), and \(u_4\) give
\[
\{\gamma,\delta\}=\{J,\alpha\},\qquad
\{\varepsilon,\eta\}=\{J,\bar\alpha\},\qquad
\{\delta,\varepsilon,\lambda\}=\Lambda.
\tag{2}
\]
Consequently the old port profile is
\[
(p_1,\ldots,p_5)
=(\Lambda\setminus\{\beta\},K\beta,
\Lambda\setminus\{\gamma\},K\lambda,
\Lambda\setminus\{\eta\}),\qquad e=ab.
\tag{3}
\]

If \(\eta=J\), (2) forces \(\gamma=\lambda\). Use the following \([eX]\) exterior row, which retains (3):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(PR,K\beta,\Lambda\setminus\{\beta\})
 &(PR,\Lambda\setminus\{\beta\},K\beta)
 &(PR,K\gamma,\Lambda\setminus\{\gamma\})
 &(\Lambda\setminus\{\gamma\},PR,K\gamma)
 &(KJ,PR,ab)
\end{array}
\tag{4}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,ab,PR)&(PR,KJ,ab)
 &(PR,\Lambda\setminus\{\beta\},K\beta)
 &(PR,K\beta,\Lambda\setminus\{\beta\}).
\end{array}
\tag{5}
\]
The original prism vertices have the pairs
\[
(PR,ab,KJ),\
(K\beta,PR,\Lambda\setminus\{\beta\}),\
(\Lambda\setminus\{\beta\},PR,K\beta),\
(K\gamma,\Lambda\setminus\{\gamma\},PR),\
(PR,KJ,ab),\
(PR,K\beta,\Lambda\setminus\{\beta\}),
\tag{6}
\]
each a partition of the six labels.

If \(\eta=\bar\alpha\), (2) gives
\(\gamma=J,\delta=\alpha,\varepsilon=J,\lambda=\bar\alpha\). The old ports are
\[
(\Lambda\setminus\{\beta\},K\beta,ab,
K\bar\alpha,J\alpha).
\tag{7}
\]
When \(\beta=J\), rename \(\alpha=a,\bar\alpha=b\). The following \([eX]\) row retains (7):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RJ,PK,ab)&(Ra,Pb,KJ)&(RJ,PK,ab)
 &(Ja,PR,Kb)&(Kb,PR,Ja)
\end{array}
\tag{8}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,Pa,Rb)&(PR,Kb,Ja)&(PR,Jb,Ka)&(PR,Ka,Jb).
\end{array}
\tag{9}
\]
At vertices \(1,\ldots,6\) the pairs are
\((RJ,Pa,Kb),(PK,Ra,Jb),(Pb,RJ,Ka),
(PK,Ja,Rb),(PR,Kb,Ja),(PR,Ka,Jb)\).
If \(\beta\in\{a,b\}\), equations (2)--(3) leave the first two rows of (12).

## \(K:4u_4\)

Here vertex \(4\) forces \(u_3=(PR,J\alpha,K\bar\alpha)\), while
\(u_4=(RK,P\varepsilon,\Lambda\setminus\{\varepsilon\})\),
\(u_5=(K\eta,PR,\Lambda\setminus\{\eta\})\), and
\[
\{\varepsilon,\eta\}=\{J,\bar\alpha\}.
\tag{10}
\]
The old ports are
\[
(p_1,\ldots,p_5)
=(\Lambda\setminus\{\beta\},K\beta,K\bar\alpha,
\Lambda\setminus\{\varepsilon\},\Lambda\setminus\{\eta\}),
\qquad e=ab.
\tag{11}
\]
If \(\eta=J\), then \(\varepsilon=\bar\alpha\). A forbidden \([eX]\) row is given by (4)--(5) with \(u_3=(PR,J\alpha,K\bar\alpha)\) and \(u_4=(K\bar\alpha,PR,J\alpha)\), retaining all the other entries. Its six original vertices again partition the labels: the fourth sees \((J\alpha,K\bar\alpha,PR)\), while the other five are those of (6) with \(u_5=(KJ,PR,ab)\).

If \(\eta=\bar\alpha\) and \(\beta=J\), put \(\alpha=a,\bar\alpha=b\). A different \([eX]\) row retains (11):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RJ,PK,ab)&(Rb,Pa,KJ)&(RJ,Pa,Kb)
 &(KJ,PR,ab)&(Kb,PR,Ja)
\end{array}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,Pa,Rb)&(PR,Kb,Ja)&(PR,Ja,Kb)&(PR,Kb,Ja).
\end{array}
\]
The original vertices see
\((RJ,Pa,Kb),(PK,Rb,Ja),(Pa,RJ,Kb),
(Pa,KJ,Rb),(PR,Kb,Ja),(PR,Kb,Ja)\);
each is a partition. If instead \(\beta\in\{a,b\}\), the last two rows of (12) remain.

The four labelled residual port profiles, after the harmless renaming \(\alpha=a,\bar\alpha=b\), are
\[
\begin{array}{c|ccccc}
 &p_1&p_2&p_3&p_4&p_5\\ \hline
4u_3,\ \beta=a&Jb&Ka&ab&Kb&Ja\\
4u_3,\ \beta=b&Ja&Kb&ab&Kb&Ja\\
4u_4,\ \beta=a&Jb&Ka&Kb&ab&Ja\\
4u_4,\ \beta=b&Ja&Kb&Kb&ab&Ja
\end{array},
\qquad e=ab.
\tag{12}
\]
In every displayed recompletion, the port pairs and terminal \(e=ab\) remain labelwise unchanged, every subdivision triple partitions the six labels, and the original-vertex triples do likewise. Each new exterior matching therefore glues to its *own original complete shore restriction*. The marked terminal pairs are \(KJ,PR,PR,PR\), giving \([eX]\). The third row of (12) is also the first residual profile in [Note 454(22)](454-fifth-line-hamilton-rows-leave-two-labelled-port-phases.md), but the two rows have different old exterior restrictions. No conclusion about complete exact Case XII, the other forbidden pairs, or Berge--Fulkerson follows from the residual list alone. These hand-derived certificates await independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 457](457-the-last-five-hamilton-port-profiles-force-a-forbidden-double-triple.md) excludes all four profiles (12) by shore-preserving \((eX)(eW)\) recompletion.
