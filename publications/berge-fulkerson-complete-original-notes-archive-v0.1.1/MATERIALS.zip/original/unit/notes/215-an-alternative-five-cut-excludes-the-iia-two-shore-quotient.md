> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An alternative five-cut excludes the \(II_A\) two-shore quotient

Work in the connected, deficient-core, minimum-host setting of
[Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md),
with the two-vertex, two-five-cut exterior classified in the
[quotient draft](../scratch/two-vertex-two-five-cut-quotients-draft.md).
The type \(II_A\) has unmarked edges
\[
u_1A,u_1B,u_1w_1,\quad u_2A,u_2w_1,u_2w_2,
\]
and five marked edges \(z_1,z_2:A\!-\!B\),
\(x:A\!-\!w_1\), \(y,q:B\!-\!w_2\).
Subdivide the marks at \(t_{z_1},t_{z_2},t_x,t_y,t_q\) and
join each subdivision vertex to the opposite pentagon to form the
whole minimum host \(G\).  Then
\[
                \boxed{\text{The quotient }II_A\text{ is impossible.}} \tag{1}
\]
This conclusion is independent of whether either original five-cut
shore is a tree, a pentagon, or has a Case-XIII relation.

The underlying obstruction has a form independent of this quotient.
Let \(\delta_G(Y)\) be any cycle-separating five-edge cut of a
cyclically five-edge-connected minimum BF counterexample such that
neither shore is a five-cycle.  Then **no vertex \(v\in Y\) has all
three neighbours in \(Y\), each incident with a cut edge**.
Indeed, choose one cut edge at each of the three distinct neighbours.
Any perfect matching of the opened five-pole \(Y^\circ\) using
those three ports leaves \(v\) unmatched.  It therefore has
neither the BF loop missing the other two cut ports nor an
all-terminal perfect matching.  Proposition 4.4 requires
\(Y^\circ\) to be either Case-XIII \(L^*\), with every loop,
or \(R^*\), with an all-terminal BF row.  Both are impossible.
We apply this three-neighbour cut obstruction to \(Y=X\) below.

Set
\[
                X=V(A)\cup\{u_1,u_2,w_1,t_x\}\subset V(G).
\]
The complete list of edges in \(\delta_G(X)\) is
\[
u_1B,\quad u_2w_2,\quad A t_{z_1},\quad A t_{z_2},
\quad t_xP,                                                \tag{2}
\]
where \(P\) denotes the opposite pentagon and \(A t_{z_i}\)
is the \(A\)-side half of mark \(z_i\).  Thus the cut has
size five.  Both sides are connected: \(A\) connects
\(u_1,u_2,t_x\), and these three connect to \(w_1\);
the complement contains the connected set consisting of
\(B,w_2,t_{z_1},t_{z_2},t_y,t_q,P\).

The \(X\)-side has a cycle.  Indeed, join the two endpoints of
\(u_1A,u_2A\) by a path inside connected \(A\); together with
\(u_1w_1,u_2w_1\) and those two shore edges it closes a cycle.
The complement contains the opposite pentagon.  Since every
non-singleton odd component \(A\) has at least three vertices,
\(|X|\ge7\); the complement is also larger than a pentagon.
Hence (2) is a nontrivial cycle-separating five-edge cut of
the **whole** minimum counterexample, eligible for
[Máčajová--Mazzuoccolo--Tabarelli, Proposition 4.4 and Figure 7](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).
Neither side of this cut is an ordinary five-cycle.  The published
classification therefore requires \(X^\circ\), the five-pole
opened on \(X\), to have one of the two complete Case-XIII
relations \(L^*,R^*\).

But the three neighbours of \(w_1\) in \(X^\circ\) are exactly
\(u_1,u_2,t_x\).  Each carries one of the five cut ports in (2).
A perfect matching using those **three** ports matches all three
neighbours through the boundary and leaves \(w_1\) unmatched.
Therefore \(X^\circ\) has no triple-boundary perfect matching
using precisely those ports.  In particular, its complete BF
relation lacks the loop on the *other* two cut ports,
\([z_1z_2]\).  The same observation excludes an all-terminal
perfect matching of \(X^\circ\).

Figure 7's \(L^*\) relation contains every BF loop, including
\([z_1z_2]\); Figure 7's \(R^*\) relation contains the
all-terminal BF type and therefore an all-terminal perfect
matching.  Both possibilities contradict the two missing
single-matching boundaries just proved.  This establishes (1).

The exclusion uses an alternative cut in \(G\), including the
opposite pentagon.  A BF cover of the smaller marked core \(J\)
would not supply the required classification.  Combining this
exclusion with the \(I_s\) argument in the quotient draft and
[Notes 212--214](214-three-star-rectangles-exclude-two-rstar-shores-in-iib.md),
the normalized two-vertex, two-five-cut barrier can only have
quotient \(I_m,I_r\), or \(II_B\), and at least one shore must
be a three-vertex tree or ordinary pentagon.  Those remaining
shore combinations and the full Berge--Fulkerson conjecture are
open.
The upstream minimum-host and barrier reductions, as well as this
analytic proof, await independent verification.
