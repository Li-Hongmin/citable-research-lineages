> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two shared colour transitions are impossible for an opposite tree--\(R^*\) shore

Continue the genuine \(I_m\) connector of
[Note 218](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md).
The tree shore \(A^\circ\) is centred at \(u_1\), with end groups
\(\{u_2,x\}\mid\{z,p\}\); the cyclic shore \(B^\circ\)
has the complete actual Case-XIII \(R^*\) relation. Let
\(c(rs)\in\{P,Q\}\) denote the Figure-7 colour of a local pair
state. If both private ports separate the two shared ports
\(u_2,z\), namely if
\[
       \boxed{c(yu_2)\ne c(yz),\qquad
              c(qu_2)\ne c(qz),}                           \tag{1}
\]
then the outer five-pole cannot have exact Case-XII support.
For example, the published port placement
\[
                       (y,q,u_2,z,u_1)=(1,3,5,4,2)         \tag{2}
\]
is impossible. The two possible relative block patterns lead to
either a four-loop contradiction or one of two genuine outer
\(T\)--\(T\) BF pairs.

## The two possible loop paths

The two actual transports of [Note 218](218-a-four-loop-rectangle-excludes-an-opposite-tree-rstar-colour-pattern.md)
send the cross-block types \((yu_2)(yz)\) and
\((qu_2)(qz)\) to outer loops \([yz]\) and \([zq]\).
If \(c(yz)=c(qz)\), condition (1) is precisely the colour
rectangle excluded by Note 218. Thus assume
\(a=c(yz)\ne c(qz)=b\). Since there are only two blocks,
\(c(yu_2)=b\) and \(c(qu_2)=a\).

Let \(d=c(yq)\). The tree supports the actual star types
\((pu_2)(px)\) and \((xz)(xp)\). The genuine star transport
[Note 212, (3)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
gives two cases:

* If \(d=a\), then \((yu_2)(yq)\) and \((qz)(qy)\)
  are cross-block types. They force \([py],[xq]\), so the
  allowed loop five-cycle is uniquely
  \(S=p-y-z-q-x-p\). Both \(yq,xz\) lie in its complement.
* If \(d=b\), then \((yz)(yq)\) and \((qu_2)(qy)\)
  are cross-block types. They force \([xy],[pq]\), so the
  allowed loop five-cycle is uniquely
  \(S=x-y-z-q-p-x\). Both \(yq,pz\) lie in its complement.

In both cases \([yz],[zq]\) supply the middle two edges of
the stated five-cycle path. It remains to construct the two
outer pair types forbidden in the respective cases.

## Two actual BF pair transports

Since \(a\ne b\), \(B^\circ\) has the actual type
\((yz)(qz)\). First combine it with the tree's actual type
\((u_2z)(xz)\). Relabel their
six matching occurrences as follows; a three-letter entry is a
triple boundary, while a one-letter entry is a singleton boundary.

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(q\) |
| 2 | \(u_1u_2p\) (missing \(xz\)) | \(z\) |
| 3 | \(z\) | \(u_1u_2q\) (missing \(yz\)) |
| 4 | \(z\) | \(u_1u_2y\) (missing \(qz\)) |
| 5 | \(u_2\) | \(y\) |
| 6 | \(x\) | \(z\) |

The shore-half labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&25&34&16/12&-\\
B&34&34&26&-&45/13
\end{array}.
\]
They are disjoint at the three shared connector ports. Set
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)
                    =(56,16;24,13,34,25).                  \tag{4}
\]
The incident labels partition \([6]\) at \(u_1,u_2,w_1,w_2\)
and every marked subdivision vertex. At the direct \(z\)-mark,
\(A_z=34\), \(B_z=26\), and the terminal residual is \(15\).
Consequently the five outer terminal labels are
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(15,35,26,56,46).                \tag{5}
\]
Slot \(5\) has boundary \(\{z,x,p\}\), missing \(yq\),
and slot \(6\) has \(\{y,p,q\}\), missing \(xz\).
The remaining four slots are the required singletons at
\(z,y,x,q\). Both local inputs are genuine six-perfect-matching
rows and every connector edge has load two, so this is an actual
outer BF type \((yq)(xz)\). This contradicts the \(d=a\)
case above.

Next combine the **same** \(B^\circ\) type \((yz)(qz)\)
with the tree's actual type \((u_2z)(xp)\):

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(z\) |
| 2 | \(u_1u_2z\) (missing \(xp\)) | \(q\) |
| 3 | \(x\) | \(u_1u_2q\) (missing \(yz\)) |
| 4 | \(z\) | \(u_1u_2y\) (missing \(qz\)) |
| 5 | \(u_2\) | \(y\) |
| 6 | \(p\) | \(z\) |

Here
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&25&24&13/16&-\\
B&34&34&16&-&45/23
\end{array},
\qquad
(R_1,R_2;D_x,D_y,D_p,D_q)=(56,16;24,13,23,45).       \tag{6}
\]
At each connector vertex and marked subdivision vertex these
labels partition \([6]\), and the outer terminal labels are
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(35,56,26,45,16).                \tag{7}
\]
Slot \(5\) has \(\{z,x,p\}\), missing \(yq\); slot \(6\)
has \(\{x,y,q\}\), missing \(pz\). The other four slots
are the required singletons. This is the actual outer BF type
\((yq)(pz)\), contradicting the \(d=b\) case. No identity
of a shore matching is reused across the two separate rows.

The two pair transports themselves have a wider scope: whenever
\(c(yz)\ne c(qz)\), both \((yq)(xz)\) and \((yq)(pz)\)
belong to the complete outer BF support. Thus, if \(yq\) is
outside a putative allowed Case-XII loop cycle, that cycle must
contain **both** \(xz\) and \(pz\). But a five-cycle with
\(z\)'s neighbours \(x,p\) must join the remaining two vertices
\(y,q\) by an edge. This is \(yq\), a contradiction. Therefore
\[
              \boxed{c(yz)\ne c(qz)
                         \quad\Longrightarrow\quad yq\in S.}   \tag{8}
\]
This necessary loop-cycle edge follows from the two actual rows
alone, independently of (1).

For (2), the [published Figure-7 blocks](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf)
give \(yz=14,qu_2=35,yq=13\in P\) and
\(yu_2=15,qz=34\in Q\), verifying (1) in the \(d=a\) case.

Thus exact Case XII requires
\[
              c(yu_2)=c(yz)\quad\text{or}\quad
              c(qu_2)=c(qz).                               \tag{9}
\]
This necessary condition does not classify every placement of
the tree--\(R^*\) end partition. Other relative port orders,
other shore pairs, and the full exact-Case-XII closure remain open.
The analytic proof awaits an independent check.
