> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The pentagon--R-star two-five-cut profile is impossible

In the minimum-host \(|U|=1\) two-five-cut connector of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md), an ordinary pentagon shore \(A^\circ\) cannot face a published Case-XIII \(R^*\) shore \(B^\circ\) if the outer five-pole has exact Case-XII boundary support. [Note 189](189-a-pentagon-rstar-two-five-cut-requires-adjacent-special-ports.md) already forces the two special outer terminals \(\delta,\epsilon\) to be adjacent in the forbidden missing-pair pentagon \(T\). This note excludes all adjacent placements by actual six-perfect-matching connector rows, hence closes the whole pentagon--\(R^*\) shore combination in this connector. It does not classify the other cyclic shore combinations.

Use Note 189's port names: the pentagon supports the actual BF loops \([\delta y],[xz]\) and the actual pair \((\delta y)(xz)\). The doubled-\(\delta y\), doubled-\(xz\), and mixed \(A^\circ\) boundary rows can respectively be ordered as
\[
\begin{aligned}
A_1&=(0xz,0xz,\delta,\delta,y,y),\\
A_2&=(0y\delta,0y\delta,z,z,x,x),\\
A_3&=(0xz,0\delta y,\delta,x,y,z).
\end{aligned}                                                   \tag{1}
\]
Here a string such as \(0xz\) means the boundary subset \(\{0,x,z\}\). A supported local \(B^\circ\) type permits any permutation of its six boundary occurrences. For each line below, the common-port slot labels at \(0,x,y,z\) are disjoint, and the displayed \(D_\delta,D_\epsilon\), together with \(R=[6]\setminus(X_0\cup Y_0)\), satisfy [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) complete overlap gate. Thus every line yields six **actual** outer perfect matchings with load two. Two-digit labels in the tables denote slot pairs.

With \(A_1\), the following three \(B^\circ\) inputs all have \(Y_0=\{4,6\}\), \(Y_\epsilon=\{1,6\}\), and \(D_\delta=\{1,6\},D_\epsilon=\{2,4\}\). Their two outer triple slots are \(3,5\).

| input \(B^\circ\) type | \(B^\circ\) boundaries in slots \(1,\ldots,6\) | outer missing pairs at slots \(3,5\) |
|---|---|---|
| \((z\epsilon)(yz)\) | \(\epsilon,y,z,0xy,z,0x\epsilon\) | \(\delta z,\ yz\) |
| \((z\epsilon)(xy)\) | \(\epsilon,y,z,0xy,x,0z\epsilon\) | \(\delta z,\ xy\) |
| \((x\epsilon)(yz)\) | \(\epsilon,y,z,0yz,x,0x\epsilon\) | \(\delta z,\ xy\) |

With \(A_2\), three further rows have \(X_0=X_\delta=\{1,2\}\). Their connector labels and outer triple slots are:

| input \(B^\circ\) type | \(B^\circ\) boundaries in slots \(1,\ldots,6\) | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((z0)(x\epsilon)\) | \(x,z,0,xy\epsilon,\epsilon,0yz\) | \(36;45\) | \(36;12\) | \(3:z\delta,\ 5:x\epsilon\) |
| \((z\epsilon)(x0)\) | \(x,z,0,0xy,\epsilon,yz\epsilon\) | \(34;56\) | \(34;12\) | \(3:z\delta,\ 5:x\epsilon\) |
| \((xy)(xz)\) | \(x,z,x,0y\epsilon,y,0z\epsilon\) | \(46;46\) | \(46;12\) | \(3:xz,\ 5:xy\) |

With the mixed \(A_3\) row, \(X_0=\{1,2\}\), \(X_\delta=\{2,3\}\), and the final two transports are:

| input \(B^\circ\) type | \(B^\circ\) boundaries in slots \(1,\ldots,6\) | \(Y_0;Y_\epsilon\) | \(D_\delta;D_\epsilon\) | outer triple slots |
|---|---|---|---|---|
| \((0y)(yz)\) | \(y,z,y,0,xz\epsilon,0x\epsilon\) | \(46;56\) | \(16;24\) | \(3:\delta y,\ 4:x\epsilon\) |
| \((yz)(xz)\) | \(y,x,z,z,0x\epsilon,0y\epsilon\) | \(56;56\) | \(56;12\) | \(3:\delta z,\ 4:xz\) |

For example, the last line has \(R=\{3,4\}\), \(X_\delta\cap Y_\epsilon=\varnothing\), and \(D_\delta,D_\epsilon,R\) partition the six slots at \(w\). Its outer triple slots use \((\delta,z)\) and \((x,z)\) as the two shore singleton boundaries, so they miss \(\delta z\) and \(xz\). The other lines can be read by the same rule or by Note 172, (3). An input \((p)(q)\) is present in \(R^*\) exactly when its two states lie in opposite Figure-7 blocks \(P,Q\); a forbidden outer \(T\)--\(T\) output therefore forces \(c(p)=c(q)\).

Interchanging \(x,z\) preserves all three actual \(A^\circ\) types in (1). Up to that interchange, an adjacent \(\delta\epsilon\) edge in \(T\) has exactly three orders for the remaining three ports.

1. **\(T=\delta-\epsilon-x-y-z-\delta\).** The first three \(A_1\) rows have forbidden outputs and force
   \[
   c(z\epsilon)=c(yz)=c(xy)=c(x\epsilon).
   \]
   Thus \(xy,yz,z\epsilon,\epsilon x\) form a monochromatic four-cycle. The block \(Q=\{12,15,23,25,34\}\) has no four-cycle, while \(P=\{13,14,24,35,45\}\) is precisely a four-cycle with one leaf at its remaining port \(0\). The first two \(A_2\) rows also have forbidden outputs \((z\delta)(x\epsilon)\), forcing \(c(z0)=c(x\epsilon)\) and \(c(x0)=c(z\epsilon)\). Both \(z0\) and \(x0\) would be in \(P\), although the leaf port has only one \(P\)-edge. Contradiction.

2. **\(T=\delta-\epsilon-x-z-y-\delta\).** [Note 188's](188-the-tree-rstar-two-five-cut-profile-is-impossible.md) doubled-\(\delta y\) row \((yz)(y\epsilon)\mapsto(\delta y)(yz)\), its mixed row \((y\epsilon)(xz)\mapsto(\delta y)(xz)\), and [Note 184's](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) doubled-\(xz\) row \((xy)(xz)\mapsto(yz)(xz)\) all have forbidden outputs. They yield
   \[
   c(yz)=c(y\epsilon)=c(xz)=c(xy).
   \]
   The first \(A_3\) row above also has forbidden output \((\delta y)(x\epsilon)\), so \(c(0y)=c(yz)\). All four states \(y0,yx,yz,y\epsilon\) would belong to one block, but each \(R^*\) block has maximum degree three.

3. **\(T=\delta-\epsilon-y-x-z-\delta\).** The third \(A_2\) row and second \(A_3\) row have forbidden outputs and give \(c(xy)=c(xz)=c(yz)\). The second \(A_1\) row gives \(c(z\epsilon)=c(xy)\), while [Note 189's](189-a-pentagon-rstar-two-five-cut-requires-adjacent-special-ports.md) actual \((z\epsilon)(y\epsilon)\mapsto(\delta z)(y\epsilon)\) row gives \(c(z\epsilon)=c(y\epsilon)\). Hence \(xy,xz,yz,z\epsilon,y\epsilon\) all lie in one block. The triangle on \(x,y,z\) forces that block to be \(Q\), but either port outside its unique triangle \(\{1,2,5\}\) has at most one \(Q\)-neighbour inside it. The distinct port \(\epsilon\) would have two, namely \(y,z\). Contradiction.

All adjacent placements are impossible. Together with Note 189, this proves that the pentagon--\(R^*\) pair cannot occur in the stated \(|U|=1\) profile. \(\square\)

Consequently, the only **shore-type pairs** still possible in this particular \(|U|=1\) two-five-cut profile are \(L^*\)--\(R^*\) and \(R^*\)--\(R^*\), up to shore exchange. Indeed, [Note 100](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md) excludes tree--tree and tree--pentagon; [Note 181](181-two-pentagon-shores-force-a-forbidden-case-xii-bf-pair.md) excludes pentagon--pentagon; [Note 183](183-a-shared-pair-tait-shore-and-a-loop-universal-shore-force-seven-loops.md) excludes tree--\(L^*\) and pentagon--\(L^*\); [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) excludes \(L^*\)--\(L^*\); and [Note 188](188-the-tree-rstar-two-five-cut-profile-is-impossible.md) excludes tree--\(R^*\). This is a classification of the remaining *types*, not a realization of either pair or a resolution of exact Case XII.
