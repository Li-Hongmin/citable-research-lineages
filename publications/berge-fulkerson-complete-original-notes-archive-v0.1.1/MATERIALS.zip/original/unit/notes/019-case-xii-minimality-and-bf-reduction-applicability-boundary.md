> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Case-XII minimality and the applicability boundary of local BF reductions

Let $G$ be a minimum-order counterexample to the Berge--Fulkerson
conjecture, and suppose that a cycle-separating 5-edge-cut realizes Case
XII.  Write $L$ for the side not equal to a 5-cycle and $R=C_5$ for the
other side.  The purpose of this note is to distinguish properties inherited
by $L$ from $G$ from properties proved for a minimum exact-$S$,
capacity-bad 5-pole.

The graph-theoretic input is Máčajová and Mazzuoccolo, *Proc. Amer. Math.
Soc.* **148** (2020), 4643--4652, doi:10.1090/proc/15057, together with
Definition 4.1, Section 4.3 and Proposition 4.4 of Máčajová, Mazzuoccolo and
Tabarelli, *Ars Math. Contemp.* **26** (2026), P2.03,
doi:10.26493/1855-3974.3409.c13.  In particular, $G$ is bridgeless,
cubic and cyclically 5-edge-connected.  In Cases I--XII one may choose
$R=C_5$, and Proposition 4.4 gives $g(G)=5$.

## Structure actually inherited by the Case-XII side

The pole $L$ is connected and nonacyclic by the definition of a
cycle-separating cut.  It is also bridge-free.  Indeed, suppose that a
proper edge separates $L$ into nonempty vertex sets $A$ and $B$, and
let $t$ be the number of the five original cut edges incident with $A$.
Then

\[
 |\delta_G(A)|=t+1,
 \qquad
 |\delta_G(B)|=6-t.
\]

The complement of either set contains the cycle $R$.  Cyclic
5-edge-connectivity therefore forces any side whose boundary has size less
than five to be acyclic.  A connected acyclic vertex set $Y$ in a cubic
graph, with $d=|\delta_G(Y)|$, satisfies

\[
 3|Y|=2(|Y|-1)+d,
 \qquad |Y|=d-2.
\]

For $t=0$ or $5$, the separating edge would be a bridge of $G$.  For
$t=1$ or $4$, the side with boundary two would have no vertices.  For
$t=2$ or $3$, both sides are forced to be trees, contrary to the choice
of $L$.  Hence $L$ has no bridge.

The five terminal vertices of $L$ are consequently distinct.  A vertex
incident with two original cut edges would have a unique proper edge in
$L$, which would be a bridge; a vertex incident with three cut edges would
be isolated from the nonacyclic part of $L$.

Proper 2-edge-cuts are not excluded.  If two proper edges separate $L$
into $A$ and $B$, with $t$ original cut edges incident with $A$,
then

\[
 |\delta_G(A)|=t+2,
 \qquad
 |\delta_G(B)|=7-t.
\]

The cases $t=0,5$ are impossible because a nonempty cubic tree with
boundary two would have order zero.  For $t=1,4$, cyclic
5-edge-connectivity forces the side with boundary three to be the unique
one-vertex cubic tree.  For $t=2,3$, it forces the side with boundary four
to be the unique two-vertex cubic tree; distinctness of the terminals puts
one original terminal at each vertex.  Thus every possible proper
2-edge-cut of $L$ cuts off precisely one of these terminal trees.

Since $g(G)=5$, the pole $L$ has no proper triangle or square, and hence
no domino, $K_{2,3}$ square fan, or square ladder.  For a genuine Case-XII
side, these particular conclusions of Notes 010, 014 and 016 are therefore
already consequences of the published girth theorem.

## Local reductions at the six-matching BF level

Call a local reduction *BF-lifting* if every BF-colouring of the reduced
graph extends across the replaced gadget without changing its port labels.
If $G'$ is obtained from $G$ by such a reduction, then

\[
 \mathcal C(G')\subseteq \mathcal C(G).
\]

Consequently, if $G'$ is smaller, cubic and bridgeless, it is again a
counterexample.  This minimality argument requires only the displayed
one-way inclusion, not equality of exact admissible sets.

### Triangle and $K_{2,3}$ contraction

Triangle contraction preserves the complete local BF boundary relation.  A
perfect matching locally uses either one exterior edge and the opposite
triangle edge, or all three exterior edges.  If $x$ of the six colour
matchings use the latter pattern, their total number of local edge
occurrences is

\[
 2(6-x)+3x=12+x.
\]

A BF-colouring covers the six local edges twice and therefore has exactly
twelve occurrences.  Hence $x=0$: every BF-colouring contracts, and every
contracted colouring has its standard expansion.  Contracting this connected
subgraph also preserves bridgelessness.

The analogous $K_{2,3}$-fan contraction also preserves the complete local
BF boundary relation.  Every local perfect matching uses exactly one port,
so the three port labels form an ordered partition of the six colours into
pairs.  Conversely, for each pair at a port, the two opposite orientations
extend it while covering every internal edge twice.  Both the fan and the
contracted cubic vertex admit exactly 90 labelled boundary assignments.
This contraction preserves bridgelessness as well.

### Square smoothing

Each natural smoothing of a square is BF-lifting, but neither preserves the
complete local relation in the reverse direction.  Let the replacement
edges have two-element labels $F,G$, and put $q=|F\cap G|$.  For the
smoothing $12|34$, exactly $q$ colours use both replacement edges,
$2-q$ use each one alone, and $2+q$ use neither.  Route $q$ of the
last group through square edges $12,34$, and the remaining two through
$23,41$.  Every square edge then has multiplicity two.  The other natural
smoothing is symmetric, so both lift for $q=0,1,2$.

The converse fails.  Among the 795 labelled BF assignments on the four
ports, 210 contract only through each natural smoothing, 15 through both,
and 360 through neither.  For example, the port labels

\[
 p_1=\{0,4\},\quad p_2=\{3,4\},\quad
 p_3=\{3,5\},\quad p_4=\{0,5\}
\]

extend over the square with

\[
 q_{12}=\{1,5\},\quad q_{23}=\{0,2\},\quad
 q_{34}=\{1,4\},\quad q_{41}=\{2,3\},
\]

but contract through neither natural smoothing.  Thus exact-set equality
cannot be inferred from square smoothing.  Moreover, connectedness of the
smoothed pole does not by itself ensure that the smoothed full graph is
bridgeless; this must be checked before invoking minimality of $G$.

### Dominoes and straight ladders

For a domino with ports in outer cyclic order, the end pairing $14|23$
and cross pairing $13|24$ are BF-lifting for $q=0,1,2$; the rail pairing
$12|34$ lifts only for $q=2$.  Again the converse fails: of the 795
local BF assignments, 360 are compatible with no pairing, 210 only with the
end pairing, 210 only with the cross pairing, and 15 with all three.

The six-matching cut transfer gives the following exact table for every
straight ladder $L_k$, $k\geq1$:

\[
\begin{array}{c|cc}
 & k\text{ odd} & k\text{ even}\\ \hline
14|23\text{ (end)}  & q=0,1,2 & q=0,1,2\\
12|34\text{ (rail)} & q=0,1,2 & q=2\\
13|24\text{ (cross)}& q=2     & q=0,1,2.
\end{array}
\]

Here a cut state is an ordered pair of two-subsets of the six colours.  The
finite transfer system has $15^2=225$ states and 540 transitions; its
reachable sets enter a period-one or period-two orbit after at most two
columns.  This proves the table for all $k$, rather than extrapolating
from bounded ladder lengths.  As above, the good pairings give one-way BF
lifts but not equality of local exact admissible sets.

## Why these reductions do not exclude Case XII

The Case-XII set on the $L$-side contains the five loop types

\[
 [13],[14],[24],[25],[35]
\]

and excludes $\left(12345\right)$.  If $L$ is 3-edge-colourable, its lonely-pair
Tait states are therefore exactly

\[
 S=\{13,14,24,25,35\},
\]

and the absence of $\left(12345\right)$ makes it capacity-bad.  Proposition 4.4 does
not, however, say that a Case-XII side is 3-edge-colourable.  It says only
that Case XII is not among the cases where 3-edge-colourability of $L$ is
ruled out.  A genuine Case-XII side can consequently lie outside the
exact-$S$ Tait class.

Even in the 3-edge-colourable branch, minimum order of the whole graph $G$
does not make $L$ a minimum-order exact-$S$, capacity-bad pole.
Replacing $L$ by an arbitrary smaller pole with the same Tait states can
introduce other BF boundary types compatible with the fixed opposite side.
The resulting cubic graph need not remain a counterexample.  Notes 010, 014
and 016 therefore concern a minimum object in the weaker abstract capacity
problem, not automatically the actual cut side $L$.

The local reductions above re-enter the genuine minimum-counterexample
argument only when they are BF-lifting and the reduced full graph is cubic
and bridgeless.  In Case XII, however, every triangle and square-cluster
configuration treated by those notes is already absent because $g(G)=5$.
The additional inherited information obtained here is that $L$ is
bridge-free with five distinct terminals and that its proper 2-edge-cuts,
if present, cut off only the one- or two-vertex terminal trees classified
above.

It follows that Notes 010, 014 and 016 do not presently exclude a genuine
Case XII.  Such an exclusion still requires either a matching-level theorem
that also applies when $L$ is not 3-edge-colourable, or a proof that every
Case-XII exact BF set is realized by a 3-edge-colourable pole together with
a global capacity argument.  Triangle and square reductions do not supply
this missing interface.

The finite local relations and the all-length ladder transfer are verified
by `scratch/worker-verify/local_bf_reduction_lifts.py`.
