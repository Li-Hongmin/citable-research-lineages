> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A three-spoke prism parity gate and a two-spoke counterexample

Continue the rooted-tree factorization of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) and the signed-pairing test of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md). Let the suppressed exterior be the triangular prism with top triangle \(A,B,C\), bottom triangle \(a,b,c\), and spokes \(Aa,Bb,Cc\). Each edge of an unmarked spanning tree is subdivided by a degree-three vertex carrying a proper shore port; each of the other four edges is marked and subdivided by a vertex carrying its terminal. A zero-port shore matching \(Q\) glues to both rooted \(ej\)-triple exterior matchings for every exterior mark \(j\).

## The remaining three-spoke tree

Take
\[
T_3=\{AB,BC,Aa,Bb,Cc\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,Cc).
\]
Its marks are \(AC,ab,bc,ca\). The notation \(j\ell\mid uv\mid wz\) means that the complement of a rooted \(ej\)-triple pairs terminal \(j\) with \(p_\ell\), and pairs \(p_u\) with \(p_v\) and \(p_w\) with \(p_z\).

> **Three-spoke parity theorem.** If \(Z-Q\) has no odd closed component, at most one of the four marks \(j\) has both rooted \(ej\)-triple complements containing an odd cycle. Consequently, in a putative exact-Case-XII pole with this exterior, every zero-port shore matching \(Q\) has an odd closed component in \(Z-Q\).

The complete exterior pairing and blocker table is below. In the one-odd column, \((k;q)\) means the shore pairs \(e\) with \(p_k\), has exactly one odd path among its other two port paths, and that odd path has endpoints \(q\). The unlisted other pair is then forced. In the three-odd column, \((k;uv\mid wz)\) gives the complete shore pairing, with all three paths odd.

| mark | first root and pairing | second root and pairing | one-odd signatures blocking both | three-odd signature blocking both |
|---|---|---|---|---|
| \(AC\) | \(A:j5\mid13\mid24\) | \(C:j3\mid14\mid25\) | \((5;14),(3;24)\) | \((4;13\mid25)\) |
| \(ab\) | \(a:j3\mid15\mid24\) | \(b:j4\mid12\mid35\) | \((3;12),(4;15)\) | \((1;24\mid35)\) |
| \(bc\) | \(b:j4\mid12\mid35\) | \(c:j5\mid14\mid23\) | \((4;23),(5;12)\) | \((2;14\mid35)\) |
| \(ca\) | \(c:j5\mid14\mid23\) | \(a:j3\mid15\mid24\) | \((5;24),(3;14)\) | \((4;15\mid23)\) |

**Proof.** Root the tree at the selected endpoint of \(j\). At each tree subdivision, the zero-port triple matches the child endpoint, leaving the parent endpoint connected to that port in the complement. Each unselected mark joins its endpoints in the complement; the selected mark leaves its other endpoint connected to terminal \(j\). Following these degree-two paths gives the first two pairing columns. For example, for \(j=ab\), root \(a\) gives \(jp_3,p_1p_5,p_2p_4\), whereas root \(b\) gives \(jp_4,p_1p_2,p_3p_5\).

By [Note 359's parity lemma](359-two-root-parity-gate-and-k33-sharpness.md), the three shore port paths have an odd number of odd lengths. For an exterior pairing \(j\ell\mid uv\mid wz\) and a shore pair \(ep_k\), the blocker rule is as follows. If \(\ell=k\), a single odd shore path among the other two **always** blocks this root; with all three paths odd, this root is blocked exactly when the shore's other two pairs equal \(uv\mid wz\). If \(\ell\ne k\), the root is blocked exactly when the shore contains the exterior pair disjoint from \(p_k\) as an odd path. Applying these rules gives the last two columns. Their eight one-odd signatures are pairwise distinct, as are their four three-odd signatures. Thus one shore signature blocks both roots for at most one mark.

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Proposition 4.4 and Appendix XII, forbids \(ej\)-Tait loops for two of the four exterior marks. If \(Z-Q\) had no odd closed component, the theorem would make at least one of those two labels Tait-colourable at a rooted triple, giving a forbidden loop. Therefore every zero-port \(Q\) has an odd closed component. By [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), two zero-port triples using the same \(Q\) cannot occur in one actual BF row. The three-spoke prism trees are now both covered by this parity consequence: the other orbit has one chosen triangle edge in each layer, is a Hamilton path, and is handled in Note 359. \(\square\)

## A real two-spoke boundary

The same one-label bound fails for the two-spoke tree
\[
T_2=\{AB,BC,Aa,Bb,ac\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac),
\]
whose marks are \(AC,ab,bc,Cc\). The two roots of \(ab\) have pairings
\[
a:j1\mid24\mid35,\qquad b:j5\mid12\mid34,
\]
and the two roots of \(Cc\) have pairings
\[
C:j5\mid14\mid23,\qquad c:j1\mid24\mid35.
\]
Take a shore signature with \(ep_5\), odd \(p_2p_4\), and even \(p_1p_3\). The blocker rule shows that **both** roots of \(ab\) and **both** roots of \(Cc\) are blocked. At roots \(a,c\), the odd \(p_2p_4\) path closes directly with the exterior \(p_2p_4\) pair. At roots \(b,C\), the exterior and shore pairings form one closed component through both shore paths, and exactly one of those paths is odd.

This signed signature is realized by an eight-vertex, simple connected cubic six-port shore, not just by a formal parity assignment. Give it vertices \(h_0,\ldots,h_7\) and these internal edges:
\[
h_0h_1,\ h_1h_2,\ h_3h_4,\ h_5h_6,\ h_6h_7,
\qquad
Q=\{h_0h_4,\ h_1h_7,\ h_2h_5,\ h_3h_6\}.
\]
Attach the six shore ports \(e,p_5,p_2,p_4,p_1,p_3\) at \(h_0,h_2,h_3,h_4,h_5,h_7\), respectively. Then the complement of the displayed **actual** perfect matching \(Q\) consists exactly of
\[
e-h_0-h_1-h_2-p_5,\qquad
p_2-h_3-h_4-p_4,\qquad
p_1-h_5-h_6-h_7-p_3.
\]
These paths have lengths \(4,3,4\), counting the port semiedges, and there is no closed shore component. For the \(a\)-root of \(ab\) and the \(c\)-root of \(Cc\), the exterior \(p_2p_4\) path has length four and closes with the three-edge shore path to give a **five-cycle**: the two shared proper port edges are counted once after gluing. For the other two roots, the exterior pairs \(12\mid34\) or \(14\mid23\) join the shore pairs \(24\mid13\) into one closed component. Its two exterior paths are even, while the two shore paths have lengths three and four, so this component is odd.

Gluing this shore to \(T_2\) gives a 23-vertex connected simple cubic five-pole of girth five with no proper bridge. The shore's internal graph is a theta graph with three internally disjoint \(h_1\)--\(h_6\) paths of lengths \(2,3,4\), so its girth is five; every exterior-only cycle has length at least six, and a cycle crossing the shore twice has at least two port edges, one shore edge and two exterior edges, hence length at least five. Every shore edge lies on a theta cycle, every exterior tree or marked edge lies on a subdivided prism cycle, and every proper port edge lies on a cycle using another port.

**A one-cycle full-closure escape.** The same shore has a second zero-port perfect matching
\[
Q'=\{h_0h_1,\ h_2h_5,\ h_3h_4,\ h_6h_7\}.
\]
The symmetric difference \(Q\triangle Q'\) is the alternating six-cycle
\[
h_0,h_1,h_7,h_6,h_3,h_4,h_0.
\]
Its complement has no closed component and has precisely the paths
\[
e-h_0-h_4-p_4\quad(\text{odd}),\qquad
p_5-h_2-h_1-h_7-p_3\quad(\text{even}),\qquad
p_2-h_3-h_6-h_5-p_1\quad(\text{even}).
\]
For **every** exterior mark \(j\) and either rooted \(ej\)-triple glued to \(Q'\), every closed component of its complement uses only even shore paths and even exterior paths. The complement therefore splits into two singleton perfect matchings, giving a genuine \(ej\)-Tait colouring and, by doubling, the BF loop \([ej]\). This explicitly certifies that the 23-vertex pole fails exact Case XII for every choice of its allowed pentagon: two of the four \(ej\) loops must be absent in that relation. It also identifies why the single-\(Q\) parity obstruction cannot be promoted to an exact-support pole without controlling the **entire** zero-port matching fibre.

The positive theorem is a necessary condition on the three-spoke prism profile, not an exclusion of exact Case XII. The two-spoke example prevents carrying that **single-mask** parity argument over to all prism trees, while its second mask proves a full-closure failure. Other two-spoke and one-spoke markings, coupling between distinct complete shore matchings in a putative exact-support pole, other deficient-core profiles, and the Berge–Fulkerson conjecture remain open. The pairing and blocker checks are hand-derived and have not received an independent proof check; no OMEN or local mathematical recomputation was used.
