> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Crossed shore \(e\)-paths occur in a real Hamilton \(K_{3,3}\) row

The first residual signature of [Note 490](490-the-k33-long-row-forces-one-pentagon-and-shore-e-paths.md) has \(P=eZ\) rooted at \(Z:2\) and \(J=Z\) using \(2u_1\). Exact Case XII would require, for its two singleton-\(e\) occurrences,
\[
\sigma(D_0)=p_2,\qquad \sigma(D_1)=p_1,                 \tag{1}
\]
where \(\sigma(D)\) is the port reached by the \(e\)-path of the **complete shore** symmetric difference \(Q_R\triangle Q_D\). The two different ports might appear incompatible with one shore load-two row. The following genuine pole shows that they are compatible. It also gives the precise failure of using (1), even with odd zero-port complements and girth five, as a sufficient exact-support test.

Use the Hamilton exterior and mark names of Notes 489--490:
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,16,25,36).                            \tag{2}
\]
Its six complete matching occurrences have the following exterior restrictions. As before, a marked edge omitted from the marked-half column uses its terminal semiedge.

| occurrence | marked halves | tree halves | proper ports |
|---|---|---|---|
| \(P=eZ\) | \(Z:2\) | \(1u_1,3u_2,4u_3,5u_4,6u_5\) | none |
| \(R=eX\) | \(X:4\) | \(1u_1,2u_2,3u_3,5u_4,6u_5\) | none |
| \(K=X\) | \(Y:1,Z:5,W:6\) | \(2u_1,3u_2,4u_3\) | \(p_4,p_5\) |
| \(J=Z\) | \(X:4,Y:1,W:6\) | \(2u_1,3u_3,5u_5\) | \(p_2,p_4\) |
| \(D_0=e\) | \(X:1,Y:6,Z:2,W:3\) | \(4u_4,5u_5\) | \(p_1,p_2,p_3\) |
| \(D_1=e\) | \(X:1,Y:6,Z:5,W:3\) | \(2u_2,4u_4\) | \(p_1,p_3,p_5\) |

## A twelve-vertex colour network

Take shore vertices \(v_0,v_1,v_2,v_3,w_2,w_3,x,y,a,b,c,d\). Its six boundary semiedges attach \(e,p_4\) to \(v_0\), \(p_2\) to \(v_3\), \(p_1\) to \(w_3\), \(p_5\) to \(x\), and \(p_3\) to \(y\). Give every shore edge the displayed pair of matching labels; this pair is exactly the two occurrences that use the edge.

| boundary or internal edges | pair of occurrences |
|---|---|
| \(ev_0,p_1w_3,p_3y\) | \(D_0D_1\) |
| \(p_4v_0,w_3y\) | \(KJ\) |
| \(p_2v_3,v_1v_2,w_2x,a d,b c\) | \(JD_0\) |
| \(p_5x,v_1w_2,v_2a,v_3b,c d\) | \(KD_1\) |
| \(v_0v_1,v_2v_3,w_2w_3,xy,a c,b d\) | \(PR\) |

Juxtaposition such as \(a d\) denotes the edge between those two shore vertices. At each of the twelve vertices, its three edge pairs partition \(\{P,R,K,J,D_0,D_1\}\). The shore is simple and cubic after its six boundary semiedges are included. Therefore the table gives six actual complete shore matchings, and their union with the six exterior restrictions gives an **actual BF row**: every internal edge and boundary semiedge has load two. Here \(v_0\) carries both \(e\) and \(p_4\); this small pole is a valid cubic five-pole, but the \(e\)-vertex is not yet the subdivision of a shore-internal marked edge. The replacement below restores that specific Note-358 geometry.

The two relevant complete shore alternating paths are visible without a port-only relaxation:
\[
\begin{aligned}
Q_R\triangle Q_{D_0}:&\quad e-v_0-v_1-v_2-v_3-p_2,\\
Q_R\triangle Q_{D_1}:&\quad e-v_0-v_1-w_2-w_3-p_1.
\end{aligned}                                                \tag{3}
\]
Their edge colours alternate \(D_i,R,D_i,R,D_i\). Thus (1) holds. The full exterior arms in Note 490 then turn these into the required terminal changes \(Z\to W\) for **both** singleton-\(e\) occurrences under \(S_1=e-X-Z-W-Y-e\). This 27-internal-vertex pole is a direct counterexample to any claim that the two crossed shore paths alone contradict a genuine six-matching BF row.

Its complete support is not exact Case XII. The zero-port shore matchings \(Q_P,Q_R\) are the same six \(PR\)-labelled edges in the table. Their complement pairs
\[
                     ep_4\mid p_1p_3\mid p_2p_5,
\]
with no closed component. The exterior complement of \(P:Z:2\) pairs
\[
                     Zp_5\mid p_1p_2\mid p_3p_4.
\]
These six paths glue into a single spanning terminal path \(e-p_4-p_3-p_1-p_2-p_5-Z\). Indeed, the three shore paths cover respectively \(1,2,9\) shore vertices, and the three exterior paths cover respectively \(3,3,9\) exterior vertices. Hence the complement of \(P\) has no closed component and alternates into two complete perfect matchings. This gives a genuine forbidden \(eZ\)-Tait colouring and BF loop \([eZ]\).

## A true one-internal-mark, girth-five, odd-complement version

Replace \(v_0\) by the Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md), attaching its three dangling edges to the terminal \(e\), the proper port \(p_4\), and \(v_1\). The respective matching pairs are \(D_0D_1,KJ,PR\), so the six Petersen matchings relabel to extend the row. The new vertex incident with terminal \(e\) has its other two edges **inside** the shore; designate it \(t_e\). Suppressing \(t_e\) gives an edge internal to the odd shore, exactly as required in the Note-358 one-internal-mark profile.

The 27-vertex pole also has two shore triangles through \(c\), a diamond four-cycle through \(c\), and the four-cycle \(w_2-w_3-y-x-w_2\). Replace the shore vertices \(c\) and \(x\) by the same Petersen three-pole. At both vertices the three incident pairs are \(PR,JD_0,KD_1\), so the same six Petersen matchings can be relabelled at each vertex to extend the complete cover. By Note 381, all three substitutions preserve **all** BF boundary support, including \([eZ]\).

The resulting pole has \(27+8+8+8=51\) internal vertices and girth five. The only cycles of length below five in the original shore are the two triangles and diamond four-cycle through \(c\), and the four-cycle through \(x\). Distinct attachment vertices in the Petersen three-pole have distance three, so a cycle crossing any replacement has length at least five; cycles inside each gadget have length at least five. Exterior-only cycles have length at least eight, and a mixed cycle crosses at least two proper edges, a shore edge and an exterior path of length at least two.

The paths (3) avoid \(c,x\). At the \(v_0\) gadget, \(R\triangle D_i\) has just two dangling ends: \(e\), carrying \(D_i\), and the edge to \(v_1\), carrying \(R\). Its unique terminal path therefore joins those ends and continues along the unchanged part of (3). Hence the crossed \(e\)-path endpoints persist in the **complete** 51-vertex matchings. The inserted Petersen matchings for \(P,R\) are distinct, so the final zero-port shore masks \(Q_P,Q_R\) are distinct. The \(x\) gadget meets the proper port \(p_5\); [Note 381's parity argument](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) makes **every** zero-port shore matching leave an internal odd five-cycle in its complement and makes the pole Tait-empty. Yet its complete BF support still contains \([eZ]\). The inserted gadgets create cyclic three-edge cuts, so this is a sharp boundary for rowwise path, girth and odd-complement tests, not an exact-Case-XII pole or a minimum-host counterexample.

[Note 492](492-the-first-k33-long-signature-recompletes-to-a-forbidden-ew-loop.md) subsequently closes this first residual signature by a stronger observation: the six **old complete shore matchings** themselves recomplete to forbidden \([eW]\), so neither cyclic connectivity nor new shore masks are needed to exclude it from exact Case XII. The example here remains a real boundary for the *path-only* and odd-complement tests; it has both the displayed \([eZ]\) and Note 492's \([eW]\). [Notes 493--494](494-the-last-two-k33-long-signatures-also-force-forbidden-ew-loops.md) close the other three residual signatures under the same exact-support hypothesis. Other forbidden-pair orbits, exteriors and the Berge--Fulkerson conjecture remain open. All certificates above are hand-derived; no OMEN or local mathematical recomputation was used, and the argument awaits independent review.
