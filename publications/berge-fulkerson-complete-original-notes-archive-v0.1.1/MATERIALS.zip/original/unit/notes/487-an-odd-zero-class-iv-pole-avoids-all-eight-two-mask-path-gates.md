> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An odd-zero class-IV pole avoids all eight two-mask path gates

The eight path equalities of [Note 486](486-cross-signature-two-mask-switches-in-the-hamilton-class-iv-row.md) are necessary obstructions for a genuine exact-Case-XII pole carrying the fixed Hamilton \(D_2\) class-IV row. They are not sufficient, even together with a genuine old row, the odd-zero condition of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md), and Tait-emptiness. The following connected cubic five-pole of order 29 gives a full-BF-support counterexample to that stronger inference. It has a cyclic three-edge cut and is not an exact-Case-XII pole.

## A six-cycle shore with two surviving path pairings

Take the fixed exterior \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\), with \((X,Y,Z,W)=(14,15,26,36)\), and the class-IV old exterior row of [Note 479, equations (2)--(5)](479-ten-d2-hamilton-phases-force-forbidden-rows-and-six-need-cross-port-closure.md) with
\[
\sigma=a,\quad\bar\sigma=b,\quad
(\mu,\gamma,\lambda,\rho,\alpha,\delta)=(J,J,a,b,b,J).       \tag{1}
\]
Its shore port pairs are \((e,p_1,p_2,p_3,p_4,p_5)=(ab,Ja,ab,Kb,ab,KJ)\). Attach these six ports in the order
\[
             q_e-q_4-q_3-q_5-q_1-q_2-q_e                 \tag{2}
\]
around a shore six-cycle. In that same order give the six cycle edges the BF-label pairs
\[
                    PK,\quad RJ,\quad Pa,\quad Rb,\quad PK,\quad RJ. \tag{3}
\]
At \(q_e,q_4,q_3,q_5,q_1,q_2\), respectively, the incident label triples are
\[
(RJ,PK,ab),\quad(PK,RJ,ab),\quad(RJ,Pa,Kb),\quad
(Pa,Rb,KJ),\quad(Rb,PK,Ja),\quad(PK,RJ,ab).               \tag{4}
\]
Each partitions \(\{P,R,a,b,J,K\}\), so every label is a complete shore matching and every shore edge has load two. Note 479(2)--(5) checks the fixed exterior row with exactly these six port pairs. Gluing therefore gives a genuine \((eX)(eZ)\) six-matching BF row on a 21-vertex cubic five-pole. The graph is connected and simple; the subdivided prism and the shore cycle make every proper edge lie on a cycle, and every cycle has length at least five.

The source singleton pairs \((Q_a,Q_K)\) and \((Q_b,Q_J)\) have port-path pairings
\[
\boxed{\pi_{aK}=ep_4\mid p_1p_2\mid p_3p_5,\qquad
       \pi_{bJ}=ep_2\mid p_1p_5\mid p_3p_4.}                \tag{5}
\]
Indeed, each pair's paths use its own three alternatingly positioned cycle edges in (3), together with their endpoint ports. Both pairings occur in Note 486(6)--(7), respectively. Consequently **all eight** two-pair path gates of Note 486 fail on this old row.

Yet the pole has a forbidden BF loop. The zero-port shore matching \(Q_P\) uses the three \(P\)-edges in (3). Its complement has the three odd port paths
\[
                 ep_2\mid p_4p_3\mid p_5p_1.              \tag{6}
\]
By [Note 230's Cartesian factorization](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), glue \(Q_P\) to the state-\(eY\) triple exterior rooted at \(Y:1\). [Note 359's exterior pairing table](359-two-root-parity-gate-and-k33-sharpness.md) gives that complement pairing as
\[
                 Yp_5\mid p_1p_4\mid p_2p_3.              \tag{7}
\]
Equations (6)--(7) concatenate to the single open route
\[
                  e,p_2,p_3,p_4,p_1,p_5,Y.                \tag{8}
\]
The three shore pieces have lengths \(3,3,3\), the exterior pieces of (7) have lengths \(4,6,8\), and together they visit all \(6+15=21\) internal vertices. Identifying the five proper ports gives the actual open route length \(9+18-5=22\). Hence (8) is the **entire** triple complement, a spanning even-length path; its terminal colours can be different, as required for singleton-\(e\) and singleton-\(Y\). Alternating along it gives an actual state-\(eY\) Tait colouring. Doubling its three complete matchings gives a forbidden \([eY]\) BF loop. This is a direct full-matching certificate, not an inference from port counts.

## Petersen replacement: odd zero complements without changing the support

Replace the shore vertex \(q_2\) by the deleted-vertex Petersen three-pole of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md). Attach the old edges \(q_1q_2,q_2q_e,p_2\), whose pairs in (3)--(4) are \(PK,RJ,ab\), to the gadget ports \(v_1,v_4,u_0\), respectively. In Note 381's six Petersen matchings assign
\[
           (P,K)=(M_2,M_4),\qquad
           (R,J)=(M_1,M_3),\qquad
           (a,b)=(M_\infty,M_0).                           \tag{9}
\]
The three attachment pairs are exactly Note 381(2), so (9) lifts the **same old row** to a 29-vertex five-pole. The Petersen gadget has girth five and every internal path between two attachments has at least three edges, so the substituted pole retains girth at least five. Note 381 proves two facts about this precise substitution: the entire BF boundary support is unchanged, and every zero-port shore matching has an odd internal five-cycle in its complement. Hence the new pole still has the forbidden \([eY]\) BF loop of (8), although it has no Tait colouring.

There is also a direct six-slot certificate for that forbidden loop. In the doubled Tait colouring obtained from (8), write \(T,E,N\) for the triple, singleton-\(e\), and singleton-\(Y\) matchings. At \(q_2\), the attachment edges \(q_1q_2,q_2q_e,p_2\) carry the pairs \(TT,NN,EE\), respectively: \(Q_P\) takes \(q_1q_2\), and the three-edge shore path \(e-q_e-q_2-p_2\) gives its first and last edges the same singleton-\(e\) colour. Replace the two occurrences of \(T,N,E\), in that order, by the gadget restrictions \((M_2,M_4),(M_1,M_3),(M_\infty,M_0)\). Each lifted occurrence is a complete perfect matching; every Petersen edge has load two by Note 381(2), and every edge outside the gadget keeps its doubled Tait load. The terminal type is still \([eY]\).

The two pairings (5) also survive. In the old row, \(a,K\) use distinct gadget attachments \(p_2,q_1q_2\), and \(b,J\) use distinct attachments \(p_2,q_2q_e\). Each corresponding symmetric difference inside the three-pole has one open path between its two used attachments, possibly with closed cycles. Contracting that path to \(q_2\) preserves the endpoints of the old shore port paths. The other port paths avoid the gadget. Thus the lifted row still satisfies (5) and still avoids **all eight** gates.

This is a real boundary for the complete-closure question: odd zero complements, no Tait colouring, a genuine required \((eX)(eZ)\) row, and avoidance of all eight fixed-carrier two-mask path gates can coexist with forbidden \([eY]\) support. The cyclic three-edge cut created by the Petersen gadget prevents this example from modelling a cyclically five-edge-connected minimum counterexample. The construction does not decide whether the forbidden row in the new pole uses two, three, or more new shore masks relative to (9), nor whether other required positive Case-XII rows force a contradiction. The argument is analytic, uses no OMEN or local mathematical recomputation, and awaits independent proof review. \(\square\)
