> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth five does not force a failed-pivot residual selector

The girth-five strengthening of the failed-pivot implication from
[Note 070](070-four-pivot-rows-and-cubicity-do-not-force-a-residual-selector.md)
is false.  There is a simple connected bridge-free cubic 5-pole of order
\(39\) and girth \(5\) containing four actual \(D_5\) six-perfect-matching
double covers that form a failed UE2 pivot star, while none of the \(79\)
forbidden-boundary five-occurrence selectors has every edge load in
\(\{1,2\}\).

Let \(H_0\) be the order-thirteen pole of Note 070.  Orient each proper edge
\(uv\), with \(u<v\), from \(u\) to \(v\), and give it voltage in
\(\mathbb Z_3\) by

\[
 \omega(5,7)=\omega(9,11)=1,
 \qquad \omega(e)=0\quad\text{otherwise}.                 \tag{1}
\]

The lifted vertices are \((v,a)\), where \(v\in V(H_0)\) and
\(a\in\mathbb Z_3\).  A proper base edge \(uv\) gives the three edges

\[
 (u,a)(v,a+\omega(uv)),\qquad a\in\mathbb Z_3.             \tag{2}
\]

For each terminal base vertex \(v\in\{0,1,2,3,4\}\), retain a semiedge at
\((v,0)\) and add the proper edge \((v,1)(v,2)\).  The result, denoted
\(H\), has \(39\) vertices, \(56\) proper edges, and five semiedges.  Every
vertex has total degree three, and the five terminal vertices are distinct.

For any one of the fifteen designated perfect matchings \(M\) of \(H_0\),
define \(\widehat M\) by taking all three lifts of every proper edge of
\(M\).  Whenever \(M\) uses the semiedge at \(v\), also take the semiedge at
\((v,0)\) and the edge \((v,1)(v,2)\).  Each \(\widehat M\) is a perfect
matching of \(H\).  Moreover, every lifted proper edge has the same incidence
column on these fifteen matchings as its base edge, and the two new objects
associated with a terminal have the incidence column of the corresponding
base semiedge.  Hence the four \(D_5\) rows remain exact double covers, and
the three anchor-compatible extensions remain the three distinct matchings
labelled \(2,12,10\).

The forbidden-boundary selectors depend only on the four occurrence rows and
their boundary classes, so the same \(79\) selectors occur after lifting.  In
Note 070 every such selector is blocked by a proper base edge of load zero or
at least three.  Each of the three lifts of that edge has the same load.
Thus all \(79\) selectors remain blocked in \(H\).

It remains to check the graph restrictions.  The proper core of \(H_0\) is
triangle-free and has exactly the two four-cycles

\[
 (1,8,11,9),\qquad (4,6,5,7).
\]

Their oriented voltage sums are respectively \(-1\) and \(1\), so neither
has a closed four-cycle lift.  Any cycle of length at most four using only
lifted base edges would project to a non-backtracking closed walk of the same
length and is therefore excluded.  A short cycle using one new
\((v,1)(v,2)\) edge would require a lifted proper path of length at most three
between two layers of the same base vertex; its projection is either a
length-two backtrack, which returns to the same layer, or a base triangle.
A four-cycle using two new terminal-pair edges would require a proper base
edge between two terminal vertices, but the five base terminal vertices are
independent.  Therefore \(H\) has girth at least five.  For example,

\[
 (1,1),(9,1),(11,2),(8,2),(1,2)
\]

is a five-cycle, so its girth is exactly five.

The nonzero voltage on either base four-cycle generates \(\mathbb Z_3\),
and hence the proper voltage lift is connected.  Every lifted base edge lies
on a lifted repetition of a base cycle because the proper core of \(H_0\) is
bridge-free.  Each new terminal-pair edge also lies on a cycle, since its two
ends are joined through the connected proper lift.  Thus \(H\) is connected
and bridge-free.  Simplicity follows directly from (2) and from simplicity of
the base pole.

Consequently, girth five does not repair the implication refuted in Note 070.
Any Case-XII proof through a failed pivot star must genuinely use information
not present here, such as the remaining positive cells, the global absence of
\(T\)-loops and \(T\)--\(T\) support, or their common perfect-matching
incidence consequences.  This example is not asserted to have exact
Case-XII support.

The construction and deterministic verification are frozen in
[`computations/bundles/girth-five-failed-pivot-residual-selector-counterexample`](../computations/bundles/girth-five-failed-pivot-residual-selector-counterexample/README.md).
