> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The other two-spoke prism excludes the top–bottom diagonal forbidden pair

Keep the marked prism tree of [Notes 424](424-the-other-two-spoke-prism-excludes-the-ac-ab-forbidden-pair.md), [425](425-the-other-two-spoke-prism-excludes-the-ac-cc-forbidden-pair.md), and [426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md):
\[
(u_1,\ldots,u_5)=(AB,BC,Aa,Bb,bc),\qquad
(X,Y,Z,W)=(AC,Cc,ac,ab).
\]
The shore has ports \(e,p_1,\ldots,p_5\) and arbitrary size. Suppose its **complete** BF boundary support is exact Case XII with forbidden \(e\)-labels \(\{X,Z\}\). The possible allowed pentagons are
\[
S_1=e-Y-X-Z-W-e,\qquad S_2=e-Y-Z-X-W-e.                \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eX)(eY)\) and forbids every double-\(T\) cell.

> **Pair exclusion.** Neither pentagon in (1) is the complete BF boundary support of a pole with this marked tree and any shore.

Take a required six-matching row. Let \(P=eX\) be its forbidden triple, \(R=eY\) its allowed triple, \(K=Y,J=X\) its marked singleton occurrences, and \(D_0,D_1=e\) its singleton-\(e\) occurrences. The \(Y\)-starting path of \(R\triangle K\) must end at \(W\), the only other allowed \(e\)-label; endings at \(X,Z\) would leave \(P\in T\) beside another \(T\)-triple. As in [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md), this path is wholly exterior: \(R\) has zero exterior ports, so from the \(K\)-terminal it enters every tree subdivision on a \(K\)-edge and leaves on \(R\)'s other prism-vertex half-edge.

**Only one \(Y\to W\) route survives.** Both roots \(A,C\) of \(P=eX\) take \(au_3,cu_5\). If \(R=eY:C\), its tree slots are \((A,B,a,b,c)\). The route through \(C,u_2,B,u_4,b\) can end at \(W:b\), but then \(K:X:A\). Covering \(Z\) by \(Z:a\) forces \(K:cu_5\), already saturated by \(P,R\); covering it by \(Z:c\) forces \(K:au_3\), likewise saturated. The other possible \(W\)-route goes through \(B,u_1,A,u_3,a,W:a\); it occupies both endpoints \(A,C\) of the \(X\) subdivision in \(K\). Thus \(R\) cannot be rooted at \(C\).

For \(R=eY:c\), with tree slots \((A,C,a,B,b)\), the long route through \(c,u_5,b,u_4,B,u_1,A,u_3,a,W:a\) occupies \(a,c\), leaving no endpoint for the \(Z=ac\) subdivision in \(K\). The branch through \(B,u_2,C\) ends at forbidden \(X\). Therefore the unique possible route is
\[
Y-t_Y-c-u_5-b-t_W-W,\qquad K:cu_5,W:b,Z:a.          \tag{2}
\]
Switching (2) produces the allowed triple \(R'=eW:b\), with tree slots \((A,C,a,B,c)\) and the **same complete shore matching** as \(R\). The switch also changes \(K\), but leaves \(P,J,D_0,D_1\) untouched. Against any unchanged \(D_i\), the shore \(e\)-to-port path is therefore identical for \(R\) and \(R'\). Both triples use zero exterior ports and each \(D_i\) uses three; once two marked terminal arms end at distinct ports, no exterior port-to-port detour remains.

The pentagons demand opposite targets for that fixed shore path:
\[
\begin{array}{c|cc}
 &R=eY&R'=eW\\ \hline
S_1&X&Z\\
S_2&Z&X
\end{array}.                                                \tag{3}
\]

**A forced singleton-\(e\) mask.** Both roots of \(P=eX\) take \(bu_4,au_3,cu_5\). By (2), \(P,K\) saturate \(cu_5\), while \(P,R\) saturate \(au_3\). At the \(Y,Z,W\) subdivisions and the vertices \(a,c\), the occurrences \(J,D_0,D_1\) have exactly one occurrence \(M\) with
\[
M:Y:c,\ Z:a,\ W:b;                                    \tag{4}
\]
the other two have \(Y:C,Z:c,W:a\). Indeed, the unique remaining \(Y:c\) slot covers \(c\), so that occurrence must cover \(Z\) from \(a\), and hence \(W\) from \(b\); all other slots are then forced.

There are three root/\(K\)-half possibilities:

* If \(P=eX:A\), then \(P,R\) saturate \(Cu_2\), forcing \(K:X:C\).
* If \(P=eX:C\), either \(K:X:A\) or \(K:X:C\) is initially possible.

In the first two possibilities, the \(X,C\) loads give one singleton-\(e\) occurrence \(E\) and the other \(F\) with
\[
\begin{array}{c|cccc}
 &X&Y&Z&W\\ \hline
J&\text{terminal}&C&c&a\\
E&A&C&c&a\\
F&C&c&a&b
\end{array}.                                                \tag{5}
\]
Here the entries \(A,C,a,b,c\) specify marked half-edges. In particular \(E:X:A,Y:C,Z:c,W:a\) and \(F:X:C,Y:c,Z:a,W:b\). In the third possibility, \(P=eX:C,K:X:C\), the \(X:C\) slot is already saturated by \(P,K\). Then both \(D_i:X:A\), and the unique occurrence \(M\) of (4) also takes \(Cu_2\); the other two take \(Y:C,Z:c,W:a\).

**The \(S_2\) orientation fails in every possibility.** In the first two, use \(E\). In the third, at least one of the two \(D_i\) is again of the form \(E:X:A,Y:C,Z:c,W:a\), whether \(M=J\) or \(M=D_i\). For such an \(E\), the complete exterior arms have the following shore exits. The two entries under each terminal give the exit against \(R\), then \(R'\):

| \(E\)'s \(b\)-slot, \(B\)-slot | \(X\) under \(R\) | \(Z\) under \(R'\) | \(Z\) under \(R\) | \(X\) under \(R'\) |
|---|---|---|---|---|
| \(bu_4,Bu_1\) | \(p_5\) | \(p_5\) | \(p_2\) | \(p_3\) |
| \(bu_4,Bu_2\) | \(p_1\) | \(p_5\) | \(p_5\) | \(p_1\) |
| \(bu_5,Bu_1\) | \(p_4\) | \(p_3\) | \(p_2\) | \(p_4\) |
| \(bu_5,Bu_2\) | \(p_1\) | \(p_3\) | \(p_4\) | \(p_1\) |
| \(bu_5,Bu_4\) | \(p_1\) | \(p_3\) | \(p_2\) | \(p_1\) |

For instance, in the first row the \(R\triangle E\) \(X\)-arm follows \(X-t_X-A-u_1-B-u_4-b-u_5-p_5\), while the \(R'\triangle E\) \(Z\)-arm follows \(Z-t_Z-c-u_5-p_5\). The \(R\triangle E\) \(Z\)-arm ends at \(p_2\), whereas the \(R'\triangle E\) \(X\)-arm follows \(X-t_X-A-u_1-B-u_4-b-t_W-a-u_3-p_3\). The other rows follow by choosing the indicated \(B,b\) slots. Every row has distinct exits in its last two columns, contradicting the \(S_2\) demand \(R\to Z\), \(R'\to X\) in (3). The table also shows that under \(S_1\) any such \(E\) must take \(bu_4,Bu_1\).

**The \(S_1\) orientation also fails.** In the first two possibilities, use the \(F\) of (5). It covers \(A\) by \(Au_1\) or \(Au_3\). If \(F:Au_1\), its \(Z\)-arm against \(R'\) exits at \(p_3\), while its \(X\)-arm against \(R\) exits at \(p_2\) or \(p_4\). If \(F:Au_3\), the two demanded exits are
\[
\begin{array}{c|ccc}
F\text{ at }B&Bu_1&Bu_2&Bu_4\\ \hline
X\text{ under }R&p_2&p_4&p_2\\
Z\text{ under }R'&p_4&p_1&p_1
\end{array}.                                                \tag{6}
\]
They differ in every column, contrary to the \(S_1\) demand in (3).

Finally take \(P=eX:C,K:X:C\). If \(M=J\), both \(D_i\) have the \(E\) mask, so (3) and the preceding table force both to use \(bu_4\). Together with \(P:bu_4\), this overloads that edge. If \(M=D_i\), the other singleton-\(e\) is an \(E\), while \(M:X:A,Cu_2,Y:c,Z:a,W:b\). The \(Z\)-arm of \(R'\triangle M\) exits at \(p_3\): \(M\) covers \(A\) by \(X:A\), so \(u_3\) uses its port. Its \(X\)-arm against \(R\) exits at \(p_4\) if \(M:Bu_1\), and at \(p_1\) if \(M:Bu_4\); \(M\) cannot take \(Bu_2\) because it already takes \(Cu_2\). Neither exit is \(p_3\). This finishes \(S_1\).

The required \((eX)(eY)\) cell is impossible under both pentagons. Together with Notes 424–426, this excludes **four of the six** forbidden \(e\)-pairs for the second two-spoke tree. The remaining pairs are \(\{Cc,ac\}\) and \(\{Cc,ab\}\); other marked exteriors and the Berge–Fulkerson conjecture remain open. This complete-matching proof is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
