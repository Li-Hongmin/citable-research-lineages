> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first-leaf D marking forces a doubled cross half

Work in the complete exact-Case-XII one-internal-mark profile and use the first-leaf six-cycle notation of [Note 249](249-the-first-leaf-six-cycle-has-three-surviving-markings.md). Consider its type D:
\[
K=\{1O,1L,1Q,2O,2R,3O,3P,4L,4R\},\qquad
a:L-C,\ d:Q-C,\ b:R-P,\ c:P-Q,
\]
with shore edges \(h_i=u_iC\), \(i=2,3,4\), and the internal shore mark \(e\). Here \(iw=u_iw\); \(a:L\) and \(a:C\) denote the two halves of the subdivided mark \(a\), and similarly for the other marks. The odd shore has unrestricted order and matching relation.

**Theorem.** Type D cannot have complete exact-Case-XII support. In every hypothetical pure-\(S\) half-load \(D=X_a+Y_a+Z_e\), the singleton-\(e\) matching would have the unique exterior mask
\[
Z_e|_{\rm ext}=\{a:C,d:C,b:R,c:Q,1O,3P,4L,h_2\}.       \tag{1}
\]
The shore pairing must join \(e\) to \(h_2\), and the allowed pentagon must have order \(S=e-a-c-b-d-e\). A required \((ea)(ec)\) row then contradicts edge load two on \(b:R\).

## The singleton-\(e\) mask

By [Notes 230 and 249](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the zero-port triple in state \(ea\) has exterior mask
\[
X_a=\{a:L,1Q,2O,3P,4R\}.                            \tag{2}
\]
The exterior \(a\)--\(d\) switch against \(Y_a\) gives a state-\(ed\) triple with the *same complete shore mask* and exterior
\[
X_d=\{d:Q,1L,2O,3P,4R\}.                            \tag{3}
\]
If \(D\) is pure \(S\), the alternating path from \(e\) in \(X_a\triangle Z_e\) must end at \(b\) and that in \(X_d\triangle Z_e\) at \(c\), or the reverse. These are the only two orders of a pentagon with \(ea,ed\in S\).

For clarity, the following is the complete small exterior check. A singleton-\(e\) matching chooses one half of each of \(a,b,c,d\) and exactly three ports among \(a:C,d:C,h_2,h_3,h_4\). Let \(m\) be the number of chosen mark-side ports among \(a:C,d:C\). The remaining \(U\)--\(W\) edges are forced by the uncovered vertices. There are \(1,8,8\) masks for \(m=0,1,2\), respectively, listed below. Each used proper shore port has an exterior alternating path to one triple terminal against either (2) or (3). In the last column \(h_i:x/y\) means that the path from \(h_i\) ends at \(x\) against \(X_a\) and at \(y\) against \(X_d\).

| \(m\) | Mark halves in \(Z_e\) | \(U\)--\(W\) edges | Used \(h\)-ports and terminal pairs |
|---:|---|---|---|
| 0 | \(a:L,d:Q,b:R,c:P\) | \(1O\) | \(h_2:d/a,\ h_3:c/c,\ h_4:b/b\) |
| 1 | \(a:C,d:Q,b:R,c:P\) | \(1L,2O\) | \(h_3:c/c,\ h_4:b/b\) |
| 1 | same | \(1L,3O\) | \(h_2:c/c,\ h_4:b/b\) |
| 1 | same | \(1O,4L\) | \(h_2:d/b,\ h_3:c/c\) |
| 1 | \(a:L,d:C,b:R,c:P\) | \(1Q,2O\) | \(h_3:c/c,\ h_4:b/b\) |
| 1 | same | \(1Q,3O\) | \(h_2:c/c,\ h_4:b/b\) |
| 1 | \(a:L,d:C,b:R,c:Q\) | \(1O,3P\) | \(h_2:c/a,\ h_4:b/b\) |
| 1 | \(a:L,d:C,b:P,c:Q\) | \(1O,2R\) | \(h_3:b/b,\ h_4:c/a\) |
| 1 | same | \(1O,4R\) | \(h_2:c/a,\ h_3:b/b\) |
| 2 | \(a:C,d:C,b:R,c:P\) | \(1Q,2O,4L\) | \(h_3:c/c\) |
| 2 | same | \(1Q,3O,4L\) | \(h_2:c/c\) |
| 2 | \(a:C,d:C,b:R,c:Q\) | \(1O,3P,4L\) | \(h_2:c/b\) |
| 2 | same | \(1L,2O,3P\) | \(h_4:b/b\) |
| 2 | \(a:C,d:C,b:P,c:Q\) | \(1L,3O,4R\) | \(h_2:b/b\) |
| 2 | same | \(1O,2R,4L\) | \(h_3:b/b\) |
| 2 | same | \(1L,2O,4R\) | \(h_3:b/b\) |
| 2 | same | \(1L,2R,3O\) | \(h_4:b/b\) |

The completeness of the table follows by first choosing the marked halves: \(b:P,c:P\) cannot both be chosen, nor can \(d:Q,c:Q\). After those occupied \(W\)-vertices are removed, \(u_1\) must be matched into \(\{O,L,Q\}\), while each of \(u_2,u_3,u_4\) either takes its shore edge or one remaining \(W\)-vertex. This gives the listed \(1+8+8\) possibilities without any condition on the shore interior.

The shore path from \(e\) cannot end at \(a:C\): against \(X_d\), that port goes directly to terminal \(a\). It cannot end at \(d:C\): against \(X_a\), that port goes directly to terminal \(d\). Therefore it must enter the exterior at one of the displayed \(h_i\). Only one table entry has the required \(b/c\) exchange. It is (1), with \(h_2:c/b\), forcing \(S=e-a-c-b-d-e\). For example, its two exterior routes are
\[
h_2-u_2-O-u_1-Q-c,\qquad
h_2-u_2-O-u_1-L-u_4-R-b.                            \tag{4}
\]
The table asserts only a necessary exterior mask and shore pairing, not that (1) extends to a matching of any specified shore.

## The required cross row

Since \(ec\in T\) for this order, the [published Case-XII support](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains a real \((ea)(ec)\) six-perfect-matching row. Write it as
\[
D=X_a+Y_a+Z_e,\qquad E=U_{ec}+V_c+W_e,\qquad D+E=2\mathbf1.
\]
The negative support makes \(D\) pure \(S\). Both singleton-\(a\) exterior masks in [Note 249](249-the-first-leaf-six-cycle-has-three-surviving-markings.md) use \(b:R\), and (1) shows that \(Z_e\) does too. Hence \(D(b:R)=2\) and \(E(b:R)=0\).

Exchange the **complete** singleton-\(e\) matchings \(Z_e,W_e\) between the two halves. The new opposite half still has state \(ec\in T\), so the new \(ea\) half is pure \(S\). The mask theorem just proved forces \(W_e\) to use \(b:R\), contradicting \(E(b:R)=0\). Thus type D is impossible at every shore order and rank. \(\square\)

This excludes one of Note 249's three surviving marked quotients. Types B and C, the other four-vertex exterior shapes, larger barriers, the other Tutte profiles and the full Berge--Fulkerson conjecture remain undecided. The mask table is hand-derived and has not received an independent check.
