> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 110 — 五线调色板的带根轨道（2026-09-13，脉冲 1/5）

有限命题：PG(2,2) 的五线集合只有一个自同构轨道，但保留五线集合时点及有序顶点星是否仍分别传递？

**裁决：集合传递；带根不传递。** 以非零三位向量 1,…,7 为点，取
S={167,246,257,347,356}，删去的两线为 123、145。
168 个线性自同构在 21 个五线集合上传递；S 的稳定子阶数为 8。
其点轨道是 {1}、{2,3,4,5}、{6,7}；它们分别为删去两线的交点、仅在其中一线上的点、在两线外的点。
S 上的 30 个有序共线三元组分成六个轨道，大小为 2,8,8,2,8,2（轨道成员见 JSON）。
因此允许同时搬动调色板时任意单点或有序共线三元组都可规范化；固定调色板时不能任意指定。

证明：两条不同二维子空间之交为一维，选交点向量及两侧补向量即得基，故任意有序不同线对互相可映；无序线对共 21 个，轨道稳定子定理给 168/21=8。带根结论由以下完整有限校验给出。

证据：`computations/fano-r1-20260913/explore.py` 按基枚举 GL(3,2)；独立的 `verify_geometry.py` 不调用前者，穷举 7! 点置换，用显式七线表保留 incidence，再核对所有轨道及覆盖。
复现：在本 unit 下运行 `python3 computations/fano-r1-20260913/explore.py` 与 `python3 computations/fano-r1-20260913/verify_geometry.py`。

最薄弱一步：轨道有限分类没有描述真实图的可重新着色集合。R1 尚无 GO 或 NOGO，不能据此切换 R2/R3。
下一命题：两个真实五线着色图的指定边，是否总能仅靠自同构作五线二和？
