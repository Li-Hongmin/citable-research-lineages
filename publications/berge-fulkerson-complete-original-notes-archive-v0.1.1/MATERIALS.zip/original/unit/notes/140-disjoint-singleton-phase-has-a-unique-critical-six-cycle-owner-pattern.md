> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A disjoint singleton phase has one possible critical six-cycle pattern

[Note 139](139-overlap-bf-rows-force-distinct-common-singleton-matchings.md) forces the two class-three singleton masks \(Z_3,Y_3\) in the row of [Note 138](138-pairing-change-forces-an-unalignable-cycle-with-a-three-edge-owner-certificate.md) to differ. Their alternating-cycle difference need not meet an unalignable cycle merely because both phenomena occur in one actual cubic BF row: a concrete two-sum followed by a three-vertex deletion gives a real five-pole separating them. For a **pairing-changing** cycle in an exact-negative-support five-pole, disjointness has a much narrower six-cycle form. The latter remains conditional; the constructed pole is not an exact-Case-XII pole.

## The disjoint-phase normal form

Use the actual row and carrier identities
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1,
\qquad q_{25}+B_2=U_{35}+Z_3,
\qquad q_{25}+r_{34}=P_{35}+t_{24}.                 \tag{1}
\]
Let \(\Gamma\) be a component of \(U_{35}\triangle P_{35}\), and suppose that it has no edge in \(Z_3\triangle Y_3\). The two singleton matchings agree at **every vertex** of \(\Gamma\): if they used different incident edges at one such vertex, at least one of those edges would belong to \(\Gamma\), since the vertex has only one edge outside the cycle. Denote \(\{Z_3,Y_3\}\) by \(A\), \(\{r_{34},D_5\}\) by \(B\), and \(\{r_{34},C_4\}\) by \(C\). The complete owner pair on each \(P_{35}\)-phase edge of \(\Gamma\) must be one of
\[
\boxed{A,\ B,\ C.}                                      \tag{2}
\]
Indeed, Note 138(8) says every such pair contains \(Z_3\) or \(r_{34}\). If it contains \(Z_3\), then it also contains \(Y_3\), and row load two makes it exactly \(A\). Otherwise it contains \(r_{34}\), and the other owner can only be \(D_5\) or \(C_4\).

For two successive \(P\)-phase edges, the intervening \(U\)-phase edge is owned by \(U\) and one other occurrence. The latter must avoid the owner pairs at **both** ends. Also it cannot be \(Z\) or \(Y\), since these agree at its endpoints and would together overload an edge already owned by \(U\). The locally allowed second-owner names are therefore contained in
\[
\begin{array}{c|cccccc}
\text{successive }P\text{-labels}&AA&AB&AC&BB&BC&CC\\\hline
\text{second owner of the intervening }U\text{-edge}
 &r,D,C&C&D&C&\varnothing&D.
\end{array}                                                \tag{3}
\]
Here the letters in the second line mean the individual occurrences \(r_{34},D_5,C_4\). In particular a \(B\)-labelled edge and a \(C\)-labelled edge cannot be consecutive on the cycle.

Suppose now that \(\Gamma\) has length six, is unalignable in the sense of Note 138, and toggling it changes the terminal pairing of an intermediate class-\(35\) matching with \(D_5\). Then, up to cyclic order, its three \(P\)-phase owner pairs are **necessarily**
\[
\boxed{A,A,B=\{Z_3,Y_3\},\{Z_3,Y_3\},\{r_{34},D_5\}.} \tag{4}
\]
The two \(U\)-phase edges between \(A\) and \(B\) have second owner \(C_4\); the remaining \(U\)-phase edge between the two \(A\)'s has second owner \(C_4\) or \(r_{34}\).

To prove the classification, unalignability requires an \(A\) and at least one of \(B,C\). Three \(P\)-phase edges cannot contain both \(B\) and \(C\), because every two of them are successive and (3) forbids their adjacency. If two edges are \(B\), then \(D_5\) owns two \(P\)-phase edges, impossible for a critical six-cycle by Note 138's two-open-path bound. If any edge is \(C\), its two adjacent \(U\)-phase edges have second owner \(D_5\) by (3), hence are doubled edges of the current matching plus \(D_5\) and meet neither open path. At most one \(U\)-phase edge remains for the two open paths to meet, again impossible. Thus the only choice is (4). Its two \(A\)--\(B\) transitions force \(C_4\) on their intervening \(U\)-edges. If \(D_5\) owned the third \(U\)-edge, only the first two, connected through the \(D_5\)-owned \(B\)-edge, could meet an open path; hence the third owner is \(C_4\) or \(r_{34}\). \(\square\)

The pattern (4) is a *necessary* local reconnection template. Before the toggle, its \(D_5\)-owned \(B\)-edge joins the two adjacent \(U\)-edges into one component, while the third \(U\)-edge can lie on another. Toggling the six-cycle changes the pairing of their four external \(D_5\)-connections. Whether those are the two terminal paths with the Case-XII labels is a global matching question.

## Real boundary for the weaker intersection claim

Let \(G_A\) be the explicit eighteen-vertex cubic graph of [Note 083](083-cyclic-five-connectivity-does-not-force-one-row-companion-alignment.md), with row \(P+N_0+N_1+N_2+N_3+N_4=2\mathbf1\) and target matching obtained by toggling one of its three alternating six-cycles \(\Gamma\). On every such cycle the target-phase owner pairs are
\[
\{N_1,N_2\},\quad\{N_1,N_2\},\quad\{N_3,N_4\},        \tag{5}
\]
and \(N_1=N_2\) as complete masks in \(G_A\). Let \(G_B\) be the separate explicit eighteen-vertex graph of [Note 084](084-minimal-empty-companion-intersections-and-the-no-a-double-hit-criterion.md), with the same six occurrence names and row form, where \(N_1\ne N_2\).

Choose \(\Gamma\) in the \(c=0\) block of \(G_A\), choose its deleted edge to be \(p_{1,0}\), and choose the deleted edge of \(G_B\) to be \(p_{2,2}\). Both deleted edges have owners \(\{P,N_0\}\), and the first is outside \(\Gamma\). Join their ends by two connector edges. Lift each of the six named perfect matchings through the two-edge sum: \(P,N_0\) use both connectors, and the other four use neither. Each remains a perfect matching, and their complete six-row load is two on every edge. The target is obtained by toggling \(\Gamma\) in the lifted \(P\).

In this **real connected cubic graph**, \(N_1\triangle N_2\) is nonempty and wholly on the \(G_B\) side, while the unalignable \(P\)-to-target six-cycle \(\Gamma\) lies on the \(G_A\) side. To turn it into a five-pole with \(N_1,N_2\) in one actual singleton class, delete the three vertices
\[
a=(0,0,1),\qquad b=(1,1,0),\qquad c=(1,0,1)             \tag{6}
\]
of \(G_B\), retaining their five external edges as semiedges. The path \(a-b-c\) has edge owner pairs \(\{N_3,N_4\}\), \(\{N_1,N_2\}\). The matchings \(N_1,N_2\) both use the internal \(b-c\) edge and the same remaining external edge at \(a\), so each restricts to a singleton matching on the **same semiedge**. The three \(P\)-owned semiedges occur at \(a,b,c\); label them \(1,2,4\), label the common \(N_1,N_2\) semiedge \(3\), and label the remaining \(N_3,N_4\) semiedge \(5\). The restricted row has allowed loop type \([35]\). The symmetric difference \(N_1\triangle N_2\) stays nonempty, since their different \(y_{d,1}\) and \(y_{d,2}\) edges for \(d\in\mathbb Z_3\) in \(G_B\) avoid the three deleted vertices. Restriction of every original matching to the remaining five-pole is still a perfect matching; the double-cover identity persists on all proper and terminal edges. The proper graph remains connected: Note 084(10) gives edge connectivity three for \(G_B\), whereas the deleted three-vertex path has only five external edges, so two distinct remaining components would each require at least three of them. Replacing the chosen \(G_B\) edge by the connected \(G_A\) factor cannot disconnect that remainder.

In this **real connected cubic five-pole**, the two class-three singleton masks are distinct but their difference misses the unalignable six-cycle:
\[
N_1\ne N_2,\qquad
(N_1\triangle N_2)\cap\Gamma=\varnothing,\qquad
\bigcap_{e\in\Gamma\cap\text{target}}L(e)=\varnothing.       \tag{7}
\]
This uses two frozen real-graph constructions, a direct two-edge-sum lift and a three-vertex deletion, with no new enumeration. It refutes the inference from *one actual cubic BF row plus distinct same-boundary singleton masks* to cycle intersection, even when the target matching belongs to the pole's complete perfect-matching family. It does **not** refute intersection for a pairing-changing cycle under exact Case-XII negative support: the displayed row is an \(S\)-loop rather than an overlapping \(S\)--\(T\) row, and the graph has a terminal-free two-edge factor containing \(\Gamma\). By Note 137, a cycle wholly in that factor cannot change a terminal pairing. The constructed pole also fails exact Case-XII support: the terminal vertices \((0,0,0)\) and \((1,0,0)\), exposed by deleting \(a\) and \(c\), are adjacent by the first edge of Note 084(7), contrary to [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md). A positive Case-XII argument must use the terminal pairing and complete negative support together with any restrictions on the pattern (4).
