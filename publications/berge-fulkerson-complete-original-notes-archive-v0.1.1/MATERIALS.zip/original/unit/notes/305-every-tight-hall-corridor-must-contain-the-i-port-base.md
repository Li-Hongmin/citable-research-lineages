> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right ad row pairs EJ with ID and pins every Hall corridor at I

> **Retracted (2026-10-01):** [Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md)
> corrects the Case-XII terminal relabelling. The type \((ea)(cd)\)
> is allowed, so the \(E\)--\(I\) path is not excluded. The boxed
> pairing, the \(I\)-base Hall conclusion, and the corridor route
> below are invalid. The exterior route trace and exclusion of the
> \(E\)--\(D\) pairing remain usable.

Continue the genuine exact-Case-XII \(R_0=DJ\), \(3{:}2\) central-path setting of [Notes 301–304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md). There is a real **right** \((ea)(ad)\) BF row \((X,Y,Z,U,V,W)\) from [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md), with shore port sets
\[
        (\varnothing,ID,EAHJ,EJ,ID,AH).
\]
The allowed Tait pentagon is \(S=e-a-b-d-c-e\). Let \(i,d,j\) be the bases of the proper ports \(I,D,J\), and let \(K=(C-\{g,e\})-\{x,y\}\), as in [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md). In the noncollision branch, the forbidden \(DJ,g,t_{ev}\) fibre is equivalent to a tight Hall set \(S_H\subseteq B\setminus\{x,y,v\}\) with \(|N_K(S_H)|=|S_H|+1\) and \(d,j\in N_K(S_H)\).

**Theorem.** For **each** \(Q\in\{Y,V\}\), the two shore paths of \(U\triangle Q\) pair
\[
                              \boxed{EJ\mid ID}.       \tag{1}
\]
The \(E\)--\(J\) path contains both \(t_{ev}\) and \(g\). Moreover, **every** tight Hall witness \(S_H\) of Note 304 contains the \(I\)-port base \(i\), regardless of its size or the shore's cycle rank. Consequently this exact branch requires \(i\notin\{x,y,v\}\). If the shore is simple and \(|S_H|=1\), then \(S_H=\{i\}\), whose vertex has exactly the incidences \(I,id,ij\).

**Proof.** Both \(Y,V\) have the same exterior mask and the same shore port and marked-edge profile. [Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md) proves that the \(E\)-starting shore path of \(U\triangle Q\) contains \(t_{ev}\) and \(g\). Its other end is \(I,D\), or \(J\). If it ended at \(D\), switching this path in \(U\) would produce a shore matching with ports \(DJ\), selecting \(t_{ev}\) and avoiding \(g\). [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) rules this out: the two \(R\)-based ports contribute \(-2\), \(t_{ev}\) contributes \(+1\), while avoiding \(g\) requires total \(+1\).

The **actual exterior masks** of \(U,Q\) give these routes:
\[
              a\longleftrightarrow J,\qquad
              b\longleftrightarrow I,\qquad
              c\longleftrightarrow D,\qquad
              e\longleftrightarrow E.                 \tag{2}
\]
The first runs from terminal \(a\) through its marked vertex, \(C_{\rm ext},u_3,D_{\rm ext},u_4\), then to \(J\); the second runs from \(b\) through \(A_{\rm ext},u_1\) to \(I\); the third runs from \(c\) through \(E_{\rm ext},t_d,B_{\rm ext},u_2\) to \(D\). If the shore \(E\)-path ended at \(I\), the remaining shore path would pair \(D\)--\(J\). Equation (2) would then make a full \(e\)--\(b\) alternating path. Switch that component between the actual row matchings \(U,Q\). Edge load two is preserved. The terminal boundaries \(U:bce\) and \(Q:a\) become \(c\) and \(abe\), while \(X:bcd\) stays fixed. The new BF type is \((ea)(cd)\). Under \((e,a,b,d,c)=(1,2,3,4,5)\), this is \((12)(45)\), explicitly listed for the opposite five-cycle pole in the published [Case-XII table, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). It is forbidden on this shore. Hence the \(E\)-path cannot end at \(I\) either, proving (1).

Now suppose a tight Hall witness \(S_H\) omits \(i\). The row matching \(U\) selects \(E,J,g\), so it matches all \(|S_H|\) vertices of \(S_H\) by edges of \(K\), saturating its exactly \(|S_H|\) available neighbours \(N_K(S_H)\setminus\{j\}\). The row matching \(Y\) selects \(I,D,t_{ev}\) and avoids \(g\). Since \(S_H\) avoids \(x,y,v,i\), it too matches all of \(S_H\) by \(K\)-edges, saturating \(N_K(S_H)\setminus\{d\}\). Their \(D\)--\(J\) shore difference path is confined to \(S_H\cup N_K(S_H)\), so their other path must pair \(E\)--\(I\), contradicting (1). Thus \(i\in S_H\). The noncollisions follow from \(S_H\subseteq B\setminus\{x,y,v\}\). If \(S_H=\{i\}\), then \(N_K(S_H)=\{d,j\}\); cubicity and simplicity leave its \(I\) port as third incidence. \(\square\)

**Corridor route.** The forced \(D\)--\(I\) path of \(U\triangle Q\) lies in \(S_H\cup N_K(S_H)\) for **every** tight Hall witness \(S_H\), and ends at the \(I\) port of \(i\). Start at the \(Q\)-selected \(D\) port. The next \(U\)-edge enters \(S_H\); thereafter a \(Q\)-edge from any vertex of \(S_H\setminus\{i\}\) enters \(N_K(S_H)\), and a \(U\)-edge from that neighbourhood returns to \(S_H\) except at the \(J\) port. Pairing (1) excludes ending at \(J\), so the path reaches \(i\) without leaving the corridor. This also applies when \(S_H\) has more than one vertex.

The port-\(I\) base escapes the preceding saturation contradiction because \(Y,V\) select \(I\) itself. [Note 304's](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md) 20-vertex counterexample has \(S_H=\{h\}\), with \(h\) carrying \(H\), so it does not test this remaining exact branch. The theorem does not exclude Hall witnesses containing \(i\), the \(DJ\) placement, or Berge–Fulkerson. The route trace and proof are hand-derived and await an independent second-source check.
