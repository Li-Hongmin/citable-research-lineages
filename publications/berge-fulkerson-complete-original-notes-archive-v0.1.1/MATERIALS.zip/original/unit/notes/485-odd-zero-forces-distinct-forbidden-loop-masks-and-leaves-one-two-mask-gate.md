> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Odd zero-port complements force distinct forbidden-loop masks and leave one two-mask gate

The algebraic closure gates in [Notes 481--484](484-a-doubled-singleton-and-two-retained-masks-complete-the-changed-zero-row.md) need one further comparison with the **existing** odd-zero theorem of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md). For the fixed three-spoke Hamilton exterior, exact Case XII would make every zero-port shore perfect matching leave an odd closed complementary component. This condition already forbids every forbidden loop that repeats a complete shore mask in any of its three equal-signature pairs. Consequently most of the radius-two algebraic gates are redundant in the exact-Case-XII regime; only the paired-singleton path gate of [Note 482](482-the-p1-p3-alternating-path-is-the-exact-paired-singleton-closure-gate.md) remains.

## Repetition in a BF loop produces a Tait state

Let a cubic five-pole have a genuine BF row of loop type \([ej]\), with two triple occurrences, two singleton-\(e\) occurrences, and two singleton-\(j\) occurrences. Suppose one complete singleton matching \(M\) occurs twice. Remove its edges. At each internal vertex, the other two incident edges carry complementary two-subsets of the remaining four BF labels. Their two-subsets therefore alternate along every component of the degree-two complement. Every closed component is even.

The four terminal semiedges left in the complement consist of the other singleton terminal, carrying one two-subset, and the three triple terminals, all carrying its complementary two-subset. One open path joins the singleton terminal to a triple terminal; the other joins the two remaining triple terminals. Alternation of the BF two-subsets makes the first path even in edge length and the second odd. Two-colour each path alternately, choosing its phase so that the singleton terminal has one colour and **all three** triple terminals have the other. Two-colour the even closed components arbitrarily. Together with \(M\), this is a genuine Tait three-edge-colouring of state \(ej\). Thus
\[
 \boxed{\text{a repeated complete singleton occurrence in a BF loop }[ej]
        \Longrightarrow \text{an actual \(ej\)-Tait colouring}.}       \tag{1}
\]
This is the loop analogue of the overlapping-row repetition argument in [Note 343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md); it does not use the marked exterior.

For the one-shore barrier profile here, the triple colour of an \(ej\)-Tait colouring has no shore ports by [Note 230's six-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). Its shore restriction is a zero-port matching \(Q\), and the other two Tait colours two-colour every closed component of the shore complement of \(Q\). Hence \(Q\) has **no** odd closed complementary component. Under Note 359's odd-zero premise, no loop \([ej]\) can repeat a complete singleton matching. Repeating a zero-port triple mask is also impossible by Note 230(5), because that same odd component prevents the four singleton occurrences from completing load two. Therefore every complete shore mask in a forbidden loop \([eX]\) or \([eY]\) must be distinct **within each of its three equal-port-signature pairs**, provided that repeated shore masks give repeated complete matchings.

That proviso holds for the class-IV old-signature candidates: [Note 481](481-the-two-old-signature-class-iv-loops-have-unique-exteriors-and-one-mask-switch-gates.md) proves that each surviving forbidden exterior is uniquely doubled by role. Two occurrences with the same shore mask and role therefore have identical exterior restrictions and are the **same complete pole matching**. Consequently all six complete shore masks of such a forbidden row are pairwise distinct: masks from different roles have different port signatures.

## The actual radius-two boundary

In a class-IV \(t=0\) old-signature row, the old family contains just one mask of the \(e\)-singleton signature \(Q_b\) and one of the other singleton signature \(Q_J\); at \(t=2\) it contains just \(Q_a,Q_K\). The old zero masks are \(Q_P,Q_R\). Because each singleton pair must be distinct, every forbidden old-signature row under the odd-zero premise needs at least one new mask in **each** singleton role. If it uses at most two new complete shore-matching occurrences, these are exactly those two singleton replacements and the zero pair remains \(Q_P,Q_R\). The row equation is then exactly Note 482(2) or (3). We obtain the sharper complete statement:
\[
\boxed{\begin{gathered}
\text{Under the odd-zero premise, a forbidden old-signature class-IV row}\\
\text{using at most two new complete shore masks exists if and only if}\\
\pi_{aK}(p_1)=p_3\quad\text{or}\quad\pi_{bJ}(p_1)=p_3.
\end{gathered}}                                                       \tag{2}
\]
If the first equality holds, Note 482 constructs a genuine \([eY]\) row; if the second holds, it constructs \([eX]\). Under the odd-zero premise neither construction can repeat a mask, so both new singleton occurrences really are new. If both equalities fail, every forbidden row retaining only old port signatures needs **at least three** new complete shore masks. The 29-vertex Petersen-substituted pole of Note 481 satisfies the odd-zero premise, avoids both pairings, and has old-signature forbidden rows with exactly three new masks. The bound is sharp among genuine poles but that pole has a cyclic three-edge cut and is not exact Case XII.

The one-mask switch gates of Note 481 and the disjointness gates of Notes 483--484 remain correct **algebraic existence criteria** when the odd-zero premise is absent. Each constructs a forbidden loop with a repeated singleton mask, so (1) proves that none can hold in the present odd-zero regime. Their failure is not an independent exact-Case-XII restriction. The decision-bearing fixed-row condition at two new masks is precisely the two alternating-path avoidances in (2); full closure with three or more new masks, new port signatures, other row phases, and the general Berge--Fulkerson conjecture remain open.

The argument is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review. \(\square\)

Later boundary: [Note 486](486-cross-signature-two-mask-switches-in-the-hamilton-class-iv-row.md) shows that allowing **new shore-port signatures** restores a two-new-mask forbidden loop even when both old-signature \(p_1p_3\) gates fail. On the 29-vertex pole above, \(\pi_{aK}(e)=p_1\) supplies such a \([eY]\) loop. The three-mask lower bound in (2) is strictly an old-signature statement.
