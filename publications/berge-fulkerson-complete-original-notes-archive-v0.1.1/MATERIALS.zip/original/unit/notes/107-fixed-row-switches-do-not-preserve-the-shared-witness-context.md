> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-row switches do not preserve the shared-witness context

The sixteen full-mask contexts left by Notes 104 and 106 do not admit a
nontrivial switching-closure argument using only the alternating-cycle switches
directly certified by the six fixed rows of Note 101.  A fixed-half agreement
switch preserves the six-occurrence total but changes the anchored carrier load;
a carrier-colour switch preserves that load but changes the designated leakage
matching identity.  Thus neither switch preserves the shared-witness context.

This is an order-independent closure of the fixed-row switching shortcut.  It
does not decide whether complete exact-Case-XII support forces some additional
cross-carrier synchronized switch.

## The sixteen contexts

For each of the four endpoint rows of Note 104, the agreement context is one of
the entry context or the three displayed fixed-half occurrences:

\[
\begin{array}{c|c|c|c|c}
K&\widehat P_i&ij\text{ intended}&ij'\text{ leakage}&a\\ \hline
K_{23}&Y&35&13&\mathrm{ent},r_{23},B,X\\
K_{23}&D&53&25&\mathrm{ent},r_{23},B,X\\
K_{34}&A&13&14&\mathrm{ent},r_{34},Y,C\\
K_{34}&X&31&35&\mathrm{ent},r_{34},Y,C.
\end{array}
\]

These are exactly the sixteen restricted families in Note 104.  Matching names
in this note always denote complete masks on the common proper-edge and
semiedge universe.

## The switch supplied by an agreement core changes \(K\)

Write

\[
H=L_0+L_1+L_2,\qquad K=2\mathbf1-H.
\]

Fix one of the twelve non-entry contexts, choose its fixed occurrence
\(L=L_a\), put \(T=\widehat P_i\), and let
\(P\in\mathcal C_a(T)\).  By Note 093, the proper symmetric difference
\(P\mathbin\triangle T\) is a union of alternating cycles contained in the
agreement region of \(L,T\).  Equivalently,

\[
L'=L+P-T
\]

is an actual perfect matching, and the paired replacement

\[
(L,P)\longmapsto(L',T)                                      \tag{1}
\]

preserves the sum of those two occurrences.

However (1) changes the occurrence-labelled fixed half and its complementary
load to

\[
H'=H-L+L'=H+P-T,
\qquad
K'=2\mathbf1-H'=K-P+T.                                     \tag{2}
\]

Therefore \(K'=K\) exactly when \(P=T\), in which case (1) is trivial.  If
the original shared data contained

\[
K=P+U+V,
\]

then the switched row contains \(K'=T+U+V\), not a second decomposition of
the same anchored \(K\).  Equation (2) applies verbatim in every one of the
twelve non-entry contexts.  In each entry context \(P=T\) by definition, so
there is no nontrivial agreement-core switch.

## The switch preserving \(K\) changes the leakage identity

Suppose instead that

\[
K=P+U+V                                                   \tag{3}
\]

is a Note-106 completion, and that one of \(U,V\), say \(W\), is the
designated Note-104 leakage occurrence.  Exchanging \(U,V\) on a nonempty
closed component of \(U\mathbin\triangle V\) preserves (3) and leaves the
agreement-core matching \(P\) fixed.  But both occurrence masks change on
that component.  In particular the new leakage occurrence is not the same
full matching \(W\).

Literal equality with the operative occurrence on the opposite carrier can be
retained only by an additional synchronized switch on the same edge set and
with the prescribed Note-082 phase.  None of the six fixed rows supplies that
cross-carrier synchronization.  Equality of boundary class cannot substitute
for this missing full-mask equality.

There is one potentially successful shape not ruled out by these calculations:
switch \(P\) against the non-leakage member \(N\) of \(\{U,V\}\), leaving
\(W\) fixed.  Such a switch exists exactly when

\[
N'=N+P-T
\]

is an actual perfect matching, equivalently when \(N\) has the required
Note-082 alignment on every component of \(P\mathbin\triangle T\).  The fixed
row certifies this condition for \(L_a\in H\), not for \(N\in\{U,V\}\).
Forcing such an \(N\) is precisely a new shared-witness switching lemma; it
cannot be read off from the existing fixed row.

The only cross-row cancellation directly available from Note 101 is the
quartic trade

\[
q_{14}+A+r_{23}+X=q'_{25}+r_{34}+Y+D.
\]

It is not a two-occurrence alternating-cycle switch, and Note 101 proves that
none of its six relevant anchored quadratic factors is forced.

## Consequence

Every nontrivial alternating-cycle switch directly supplied by an existing
fixed agreement row breaks same-\(K\) anchoring.  Every nontrivial residual
colour switch that preserves same \(K\) breaks the designated leakage full-mask
identity unless one assumes the missing synchronized opposite-carrier switch.
Hence the fixed-row switching shortcut is closed.

The universal shared-witness proposition remains unknown.  Its next minimum
positive form is to force, in at least one of the sixteen contexts, the
non-leakage residual companion \(N\) with the exact component alignment above,
while the leakage occurrence \(W\) remains literally equal to the opposite
operative witness and satisfies all prescribed phases.  A negative result still
requires a real rooted cubic pole with independently reconstructed complete PM
closure and all sixteen contexts replayed.
