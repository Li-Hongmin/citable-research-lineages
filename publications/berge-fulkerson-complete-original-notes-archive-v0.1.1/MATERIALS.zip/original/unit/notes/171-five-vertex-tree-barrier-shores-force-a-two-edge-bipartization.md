> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Five-vertex tree barrier shores force a two-edge bipartization

Assume the minimum-host, connected-\(F\), deficiency-two setting and take the smallest maximum barrier \(U\) of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md). This note treats either of its **one non-singleton component** profiles: an odd component \(C\) with a seven-edge \(J\)-cut and no internal mark, or one with a five-edge cut and exactly one internal mark. Assume \(F[C]\) is a tree. Every other component of \(F-U\) is a singleton, \(h(U)=0\), and \(F[U]\) is edgeless. The conclusions are necessary conditions under full exact Case-XII support, not realizations of that support.

## The only tree shape

Write \(m\in\{0,1\}\) for the number of marks internal to \(C\), and \(k=7-2m\) for its \(J\)-cut size. If \(n=|C|\), cubic degree counting with \(|E(F[C])|=n-1\) gives
\[
3n=2(n-1)+2m+k,
\qquad n=k+2m-2=5.                                      \tag{1}
\]
A five-vertex tree of maximum degree three is either a path or has one degree-three vertex \(z\), one degree-two vertex, and three leaves.

Put \(U\) and all five marked subdivision vertices of the pole \(H\) in a part \(X\), and every singleton component of \(F-U\) in the other part \(Y\). All proper edges not incident with \(C\) cross these parts: unmarked ones join \(U\) to singleton components, while marked ones pass through subdivision vertices. Every edge incident with \(C\) but outside \(F[C]\) goes to \(X\): an unmarked edge goes to \(U\), and a marked edge, including a possible internal mark of \(C\), meets its subdivision vertex. Each vertex of \(C\) with \(F[C]\)-degree below three has at least one such edge and must lie in \(Y\).

In the branched tree, only \(z\) has degree three in \(F[C]\). Put \(z\in X\) and the other four vertices in \(Y\). Exactly one tree edge, from the degree-two vertex to its leaf, then lies within \(Y\); every other proper edge crosses. Deleting that one edge makes \(H\) bipartite, contradicting [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md). Therefore
\[
\boxed{F[C]\cong P_5.}                                    \tag{2}
\]

## The two exceptional ports are unmarked

Number the path \(v_1v_2v_3v_4v_5\). Put \(v_2,v_4\) in \(X\) and \(v_1,v_3,v_5\) in \(Y\). All four path edges cross. Each of \(v_2,v_4\) has exactly one edge outside \(F[C]\); call these proper edges \(p_2,p_4\). All remaining proper edges cross, so
\[
H-\{p_2,p_4\}\text{ is bipartite, with all five terminals on }X.
                                                               \tag{3}
\]
By [Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md), \(p_2,p_4\) are disjoint. If \(p_j\) were a half of marked edge \(c\), every class-\(c\) singleton matching would use \(s_c\) and avoid \(p_j\). The same-side \(5+0\) balance of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) makes every singleton use exactly one of \(p_2,p_4\); class \(c\) would therefore be fixed to the other edge. [Note 168](168-fixed-singleton-profiles-exclude-two-tutte-barrier-shapes.md) forbids a fixed class. Hence both \(p_2,p_4\) are **unmarked \(F\)-edges from \(C\) to distinct vertices of \(U\)**.

If \(m=1\), its internal marked edge cannot meet \(v_2\) or \(v_4\), so its ends lie among \(v_1,v_3,v_5\). Joining \(v_1\) to \(v_3\) or \(v_3\) to \(v_5\) would make a triangle in \(J\) with only one internal mark, contrary to [Note 123's marked-cut inequality](123-exact-case-xii-terminal-vertices-are-independent.md). Thus the mark joins \(v_1\) to \(v_5\), and \(J[C]\) is an ordinary pentagon whose sole marked edge closes the unmarked path.

For completeness, every triple-boundary perfect matching \(Q\) has exactly **one** hit at \(C\). Indeed, there are \(|U|+2\) odd components of \(F-U\), each needs an odd positive number of matching edges from \(U\) or marked half-edges, and the total number of such hits is \(|U|+2\): one for each vertex of \(U\) and two selected marked endpoints. Thus \(Q\) matches four of the five path vertices internally and its unique hit lies at \(v_1,v_3\), or \(v_5\). If it hits \(v_3\), then \(Q\) uses \(v_1v_2,v_4v_5\), so its complement contains the path
\[
p_2,\ v_2v_3,\ v_3v_4,\ p_4.
\]
The two exceptional edges therefore lie in the same component of \(H-Q\). [Note 127's complement criterion](127-two-edge-bipartization-profiles-and-tait-blockers.md) extends \(Q\) to a Tait colouring of its missing-pair state. Exact Case XII forbids such a state in \(T\). Hence **every actual \(T\)-boundary triple hits this path shore at an end \(v_1\) or \(v_5\)**, including when the hit uses an internal marked half-edge in the five-cut profile. If the exact pole is Tait-empty, the same conclusion holds for every triple state.

Consequently **both tree profiles** reduce to the same-side \(5+0\) full-matching interface, with two distinct unmarked ports into \(U\). In the seven-cut profile the component remains an unmarked \(P_5\); in the five-cut profile its unique internal mark closes that path to a pentagon. The flexibility theorem supplies both exceptional-edge profiles in every complete singleton class, but does not align their complete masks in a prescribed BF row. This reduction leaves the cyclic-shore alternatives and the full perfect-matching closure open.

Together with [Note 170's two-tree reduction](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md), this gives a dichotomy across all three normalized barrier profiles: **if every non-singleton component of \(F-U\) is acyclic in \(F\), the exact Case-XII pole has a same-side \(5+0\) two-edge bipartization; otherwise at least one non-singleton component contains an unmarked cycle.** In the first branch both exceptional edges are unmarked and run to distinct vertices of \(U\). Neither branch is excluded by this dichotomy.

In the cyclic branch, the seven-cut shore gives a seven-edge host cut, and a five-cut shore with one internal mark gives a six-edge host cut after including that mark's subdivision vertex. Proposition 4.4's five-cut classification applies directly only to the unmarked five-cut shores of Note 170. The two larger-cut relations must still be treated with their outer Case-XII matching masks.
