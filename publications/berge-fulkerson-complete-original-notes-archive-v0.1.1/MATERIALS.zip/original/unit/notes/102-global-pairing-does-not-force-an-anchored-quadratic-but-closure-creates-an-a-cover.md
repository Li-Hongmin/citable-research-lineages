> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global pairing does not force an anchored quadratic, but closure creates an (A) cover

The local trivalent signatures of [Note 101](101-pointwise-bc-reuse-and-local-trivalence-do-not-force-an-anchored-quadratic.md)
can be paired into one connected cubic five-pole multigraph without creating
any of the missing selected-family relations.  They can also be lifted to a
simple cubic five-pole by the transparent two-sums of
[Note 099](099-three-edge-colourable-two-sums-preserve-dependent-splice-fibres.md).
Thus neither global proper-edge pairing nor simplicity forces the anchored
quadratic at the level of finitely selected perfect matchings.

The complete perfect-matching closure behaves differently.  In the paired
multigraph the two state-(35) endpoint projections remain empty, but five
additional singleton matchings have load at most two and their load-one
complement is an all-terminal perfect matching.  They form a genuine
Berge--Fulkerson (A=(12345)) cover.  Consequently this realization is not
exact Case XII and does not refute the dependent-fibre statement of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md).

## Pairing the selected incidence columns

Retain the twenty-two named occurrences of Note 101 and identify the three
repeated perfect-matching identities

\[
 A=p^1_{13},\qquad P_3=p^3_{13},\qquad P_5=p^5_{25}.
\tag{1}
\]

A legal incidence block is a subset of the twenty-two occurrence positions
which is constant on the nineteen identities and occurs twice in each of the
six displayed BF rows.  A legal trivalent star is a partition of all
positions into three legal blocks.  There are (719) legal blocks and
(4194) unordered legal stars.

Write (e_b) for the binary coordinate of a legal block (b), and let

\[
 W=\operatorname{span}_{\mathbf F_2}
 \{e_b+e_c+e_d:\{b,c,d\}\text{ is a legal star}\}.
\tag{2}
\]

If (b_1,\ldots,b_5) are the five terminal blocks, all remaining proper
stubs can be paired by equal occurrence columns exactly when

\[
 e_{b_1}+\cdots+e_{b_5}\in W.
\tag{3}
\]

Necessity follows because every internal star contributes its three-block
vector, while at a terminal star the two proper blocks differ from the
three-block vector by its terminal block.  Conversely, a representation of
the left side of (3) makes every nonterminal block multiplicity even, so
equal-column proper stubs can be paired.  The finite elimination has rank
(706) and gives a (59)-star representation of (3).  After cancelling
duplicate stars, the explicit certificate has sixty-two internal vertices
and the five terminal vertices.

Let (H_0) denote the resulting five-pole multigraph.  Its parameters are

\[
 |V(H_0)|=67,\qquad |E_{\rm proper}(H_0)|=98,
\tag{4}
\]

with five labelled semiedges.  It is connected, loopless and cubic.  Its
only parallel endpoint pairs are

\[
 (0,5),\qquad (1,62).
\tag{5}
\]

The nineteen selected identities are actual perfect matchings of this one
multigraph.  Each of the six selected rows double-covers all (103) edge
objects.  Exhaustion within the selected family gives no all-terminal
matching and no (T)--(T) BF row, and the two anchored quadratics of
Note 101 remain absent.  The last assertion can also be read off at the five
original terminal vertices: a global pair equality would restrict to one of
the local equalities already excluded there.

This proves that common trivalence plus global equality-column pairing into
one connected cubic five-pole does not force the selected anchored
quadratic.

## Simplicity does not repair the selected implication

Choose one edge from each parallel pair in (5), and perform a two-sum with a
fresh copy of (K_{3,3}) along each chosen edge.  The two applications of
Note 099 produce a simple connected cubic five-pole (H_2) with

\[
 |V(H_2)|=79,\qquad |E_{\rm proper}(H_2)|=116.
\tag{6}
\]

The factors are vertex-disjoint, each splice edge joins an old vertex to a
fresh factor vertex, and one edge of each original parallel pair remains;
hence no loop or parallel edge is introduced.  The canonical endpoint-star
lift of Note 099 preserves every selected matching identity, every BF row
and every pair-sum equality simultaneously.  It also gives

\[
 \operatorname{BFsupp}(H_2)=\operatorname{BFsupp}(H_0)
\tag{7}
\]

and preserves every literal dependent-splice fibre in both directions.
Thus simplicity alone cannot force the selected anchored quadratic.  The
two sums do introduce proper two-edge cuts, so this construction makes no
indecomposability claim.

## What the complete matching closure adds

Fix the selected occurrences (r_{23},B,X,Y,D) in (H_0).  First quantify
over every graph-induced triple ((q_{35},P_3,P_5)) satisfying

\[
 q_{35}+P_3+P_5=2\mathbf1-(r_{23}+B+X).
\tag{8}
\]

The exact finite query asks whether (P_3=Y), whether one of
(r_{23},B,X) satisfies
(operatorname{Align}(L;P_3\to Y)), or whether the analogous entry or
alignment exists for (P_5\to D).  It is unsatisfiable.  Hence complete
closure does not repair either of these two endpoint projections in this
fixed state-(35) carrier.

Nevertheless, complete closure supplies five perfect matchings
(M_0,\ldots,M_4), with (M_i) having singleton boundary (i), whose
proper-edge loads are at most two.  Let (m(e)) be their total load and put

\[
 M_*=\{e:m(e)=1\}.
\tag{9}
\]

At every nonterminal cubic vertex, five matching incidences of positive
load at most two have multiplicities ((2,2,1)).  At terminal (i), its
semiedge has load one and the two proper incidences have load two.  It
follows that (M_*) meets every vertex exactly once and contains all five
semiedges.  Therefore

\[
 M_0+M_1+M_2+M_3+M_4+M_*=2\mathbf1
\tag{10}
\]

is an (A=(12345)) BF cover.  The explicit certificate gives

\[
\begin{split}
M_*={}&\{2,21,23,24,26,37,39,40,41,44,45,46,47,48,51,53,56,65,\\
&68,70,72,73,74,75,77,81,89,93,95,96,97,98,99,100,101,102\},
\end{split}
\tag{11}
\]

where (98,\ldots,102) are the five semiedge objects.  The five singleton
matchings are recorded in the proof bundle, and direct incidence checking
verifies (10) on all (103) edge objects.

By (7), the simple pole (H_2) has the same (A) support.  Thus neither
(H_0) nor its simpleification is exact Case XII.  No (T)--(T) query or
full positive-support census is needed once (10) is found.

## Consequence

The Note 101 implication fails after global proper-stub pairing and after
simpleification if one controls only the selected matching family.  For the
specific global pairing above, however, the complete graph-induced closure
escapes through forbidden (A) support rather than through either anchored
endpoint projection.

This closes the strategy of promoting this selected countermodel to an
exact-Case-XII counterexample by merely pairing its stubs or removing its
parallel edges.  It does not prove that every pairing of the Note 101
signatures creates forbidden support, and it does not decide whether an
indecomposable exact-Case-XII pole must contain a Note 082 dependent
two-splice fibre.  Any further counterexample construction must enforce the
negative (A/T\!T) support in the complete perfect-matching family from the
start, rather than only in designated rows.

The construction, certificates and reproduction commands are frozen in the
[proof bundle](../computations/bundles/global-pairing-and-full-closure-boundary/README.md).
