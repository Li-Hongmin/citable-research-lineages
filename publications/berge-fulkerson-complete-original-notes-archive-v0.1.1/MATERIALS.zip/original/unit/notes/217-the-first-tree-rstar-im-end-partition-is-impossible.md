> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first tree--\(R^*\) end partition is impossible in \(I_m\)

Continue the genuine \(I_m\) quotient of
[Note 216](216-a-tree-rstar-im-shore-forces-a-single-minority-port-placement.md).
Let \(A^\circ\) be a three-vertex tree centred at its \(u_1\)
port with end groups \(\{u_2,z\}\mid\{x,p\}\), and let
\(B^\circ\) have the complete Figure-7 \(R^*\) BF relation.
Then the outer five-pole **cannot** have exact Case-XII support,
at any order of \(B\).

Note 216 proves that exact Case XII would force the \(R^*\)
port placement
\[
                 (y,u_1)=(2,4)\quad\text{or}\quad(4,3),       \tag{1}
\]
in the published local labels.  The four further actual row
transports below contradict both possibilities.  This does not
exclude the other tree end partition
\(\{u_2,x\}\mid\{z,p\}\).

## Four slotwise transports

Write \(R_i=u_iw_i\) and let \(D_x,D_y,D_p,D_q\) be the
singleton-side labels of the four marks.  For every row of (2),
put \(A\)'s two triples missing the displayed pair states in
slots \(1,2\), its singleton leaves in \(3,4\) in the same
order, and its repeated centre singleton in \(5,6\).
Put \(B\)'s displayed singleton leaves in \(1,2\), its two
triples missing the displayed pair states in \(3,4\) in that
order, and its repeated centre singleton in \(5,6\).
The tree admits every displayed local pair type because all four
cross states \(u_2x,u_2p,zx,zp\) have compatible
three-edge-colouring halves.  The displayed \(B\)-type is actual
whenever its two missing-pair states have opposite \(P/Q\)
colours in Figure 7.

\[
\begin{array}{c|c|c|cc|cccc|c}
 &A\text{ type}&B\text{ type};B_{12}&R_1&R_2
 &D_x&D_y&D_p&D_q&\text{outer loop}\\\hline
1&(u_2x)(u_2p)&(qy)(qu_2);(y,u_2)&56&14&14&23&56&23&[pq]\\
2&(zx)(zp)&(qy)(qz);(y,z)&56&56&14&23&23&14&[zq]\\
3x&(xu_2)(xz)&(zu_2)(zq);(u_2,q)&56&56&34&12&34&14&[xz]\\
3p&(pu_2)(pz)&(zu_2)(zq);(u_2,q)&56&56&34&12&34&14&[pz]\\
4&(zx)(zp)&(u_2y)(u_2z);(y,z)&56&34&14&23&56&12&[zp]
\end{array}.                                                   \tag{2}
\]

Here \(B_{12}\) lists the singletons in slots \(1,2\).
For example, row 1 gives the shore-half labels
\(A:(u_1,u_2,z,x,p)=(12,56,12,23,14)\) and
\(B:(u_1,u_2,z,y,q)=(34,23,34,14,56)\).
At \(u_1,u_2\), these labels are complemented by
\(R_1=56,R_2=14\); at \(w_1,w_2\), the three incident labels
are respectively \((56,14,23)\) and \((14,56,23)\).
The outer terminal labels are
\((T_z,T_x,T_y,T_p,T_q)=(56,56,56,23,14)\), proving \([pq]\).

The same direct check for rows 2--4 gives
\[
\begin{array}{c|ccccc}
\text{row}&T_z&T_x&T_y&T_p&T_q\\\hline
2&14&56&56&56&23\\
3x&23&12&56&56&56\\
3p&23&56&56&12&56\\
4&14&56&56&23&56
\end{array}.                                                   \tag{3}
\]
At the direct \(z\)-mark, the two shore-half labels are
disjoint; at each \(u_i,w_i\) and marked subdivision vertex,
the three incident two-slot labels partition \([6]\).
Consequently every row glues six genuine perfect matchings with
load two on every edge.  Slots \(5,6\) are identical triple
boundaries with the missing pair shown in (2).

## The two Figure-7 placements

Use
\(P=\{13,14,24,35,45\}\) and
\(Q=\{12,15,23,25,34\}\), as in
[Figure 7](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).
If \((y,u_1)=(4,3)\), the remaining \(B\)-ports
\(u_2,z,q\) occupy \(\{1,2,5\}\).  All three pair states
among them are in \(Q\), while every state joining them to
\(y=4\) is in \(P\).  Thus row 1 is active with centre
\(q\), row 2 with centre \(q\), and row 4 with centre
\(u_2\).  Their loops \([pq],[zq],[zp]\) form the forbidden
triangle \(p-q-z-p\).

If \((y,u_1)=(2,4)\), the remaining ports
\(u_2,z,q\) occupy \(\{1,3,5\}\), with
\(13,35\in P\) and \(15\in Q\); all their states toward
\(y=2\) lie in \(Q\).

* If \(q=3\), both \(qu_2,qz\) lie in \(P\), so rows 1--2
  force \([pq],[zq]\).  The other two ports are \(1,5\),
  making \(zu_2=15\in Q\) and \(zq\in P\).  Row 3p
  forces \([pz]\), again a triangle.
* If \(q\in\{1,5\}\) and \(z=3\), then
  \(qu_2=15\in Q\) and \(qz\in P\).  The existing
  [four-leaf rectangle](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
  forces \([xq],[pq]\) from the tree stars at \(x,p\),
  and row 2 forces \([zq]\).  This gives three loop
  neighbours at \(q\), impossible in a five-cycle.
* If \(q\in\{1,5\}\) and \(u_2=3\), then
  \(qu_2\in P\), \(qz\in Q\), and the same tree stars
  force \([xq],[pq]\).  Also \(zu_2\in P\) and
  \(zq\in Q\), so rows 3x and 3p force \([xz],[pz]\).
  These four loops form the forbidden four-cycle
  \(x-q-p-z-x\).

This exhausts (1), proving the theorem.  The result uses the
complete actual \(R^*\) relation and exact six-slot gluing;
the apparent placements left by Note 216 are no longer open.
The other tree partition and all other shore combinations,
larger barriers, and the full Berge--Fulkerson conjecture remain
open.  The analytic chain awaits independent verification.
