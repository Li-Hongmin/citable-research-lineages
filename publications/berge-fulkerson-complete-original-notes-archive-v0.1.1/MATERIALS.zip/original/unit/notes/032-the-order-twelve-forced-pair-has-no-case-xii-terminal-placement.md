> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The order-twelve forced pair has no Case-XII terminal placement

The girth-five BF-forced pair of Note 029 does not occur in a genuine
Case-XII whole-graph placement.  Its two inverse terminal-tree expansions
pass cyclic 5-edge-connectivity, but every cycle-separating 5-cut splits the
two terminal-tree vertices.

Let \(e=05\) and \(f=69\) be the designated edges in Note 029.  Delete
them, introduce \(u=12,v=13\) joined by \(uv\), and attach their four ports
using either cross grouping.  Both resulting 14-vertex graphs are simple,
cubic, bridgeless, of girth five, and cyclically 5-edge-connected.

Up to complementation, each graph has exactly five cycle-separating
5-edge-cuts:

\[
4\text{ of side orders }5+9,
\qquad1\text{ of side orders }7+7.
\]

Every one contains \(uv\), hence separates \(u\) from \(v\).  For the
grouping

\[
u:\{0,6\},\qquad v:\{5,9\},
\]

the four order-five sides are the cycles

\[
0167u,qquad0268u,qquad359\,10v,qquad459\,11v.
\]

For the grouping

\[
u:\{0,9\},\qquad v:\{5,6\},
\]

they are

\[
0379u,qquad0489u,qquad156\,11v,qquad256\,10v.
\]

Thus every possible \(R=C_5\) contains exactly one of \(u,v\).  The
remaining \(7+7\) cut also separates them.  There is no cycle-separating
5-cut with \(R=C_5\) disjoint from the complete terminal tree \(uv\) and
that tree contained in the opposite side \(L\).

Consequently the explicit forced-pair mechanism in Note 029 cannot occur as
the two-vertex terminal tree of a genuine Case-XII cut.  This does not prove
general edge-pair flexibility: another forced pair may have an inverse
expansion with a correctly placed 5-cycle.  BF boundary compatibility is not
tested here because the required structural placement already fails.

The complete finite structural verifier is
`scratch/worker-verify/n12_forced_pair_whole_graph.py`; it terminates with
`N12_FORCED_PAIR_WHOLE_GRAPH_OK`.
