> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first six-cut Hall cycle restricts the J-port

> **Subsequent refinement:** [Note 314](314-zero-port-hexagon-flip-excludes-the-a-v0-j-placement.md)
> also excludes \((P,j)=(A,v_0)\), leaving three positions in this
> three-vertex allocation; [Note 315](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md)
> excludes those three as well. The theorem below is unchanged.

Continue the noncollision, complete exact-Case-XII central-path branch
of [Note 312](312-the-right-row-excludes-the-two-point-six-cut-hall-block.md):
there is a real left \((ea)(ac)\) row and a real right
\((ea)(ad)\) row, the near-bipartite shore has \(R_0=DJ\), and the
completed minimum host has girth at least five. Use the tight
\(DJ\) Hall witness \(S\subseteq B\setminus\{x,y,v\}\) and the
parameters \(\alpha,\eta\) defined there.

**Theorem.** Suppose
\[
                  |S|=3,\qquad(\alpha,\eta)=(2,1).           \tag{1}
\]
Then \(S=\{h,k,\ell\}\), where \(h\) carries \(H\), \(k\)
carries exactly one port \(P\in\{A,I\}\), and \(\ell\) is the
unique neighbour of the \(D\)-port base \(d\) in \(S\). Put
\(T=N_K(S)\setminus\{d\}\). Its three vertices are uniquely
labelled
\[
 \{u\}=N_K(h)\cap N_K(k)\cap T,\quad
 \{v_0\}=N_K(h)\cap N_K(\ell)\cap T,\quad
 \{z\}=N_K(k)\cap N_K(\ell)\cap T.                         \tag{2}
\]
The six edges between \(S,T\) form the cycle
\(h-u-k-z-\ell-v_0-h\). If \(j\) is the base of port \(J\), the
following two positions are impossible:
\[
             (P,j)=(A,u),\qquad(P,j)=(I,v_0).                \tag{3}
\]
Thus the only positions **not excluded by this theorem** are
\((A,v_0),(A,z),(I,u),(I,z)\). Their listing is not an existence
certificate for a full Case-XII pole.

**Proof.** Since \(|N_K(S)|=4\), \(|T|=3\). Cubicity and the three
incidences leaving \(S\) through two proper ports and \(d\) give
\[
                         e_K(S,T)=3|S|-\alpha-\eta=6.       \tag{4}
\]
Write \(c_t=e_K(S,t)\le3\) for \(t\in T\). Girth at least five
forbids two vertices of \(S\) from sharing two neighbours in \(T\),
so \(\sum_{t\in T}\binom{c_t}{2}\le\binom32=3\). Because
\(\sum c_t=6\), convexity gives the opposite inequality, with
equality only for \((c_t:t\in T)=(2,2,2)\). Every pair in \(S\)
therefore shares exactly one member of \(T\), proving (2) and the
six-cycle. Each vertex of \(S\) has two edges into \(T\) and
exactly one other incidence. The latter three incidences are the
ports \(H,P\) and the edge to \(d\), at distinct vertices. This
proves the claimed placement.

Write the real right row as \((X,Y,Z,U,V,W)\), with shore port sets
\((\varnothing,ID,EAHJ,EJ,ID,AH)\), as in
[Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md).
The matching \(U\) selects \(J\), but neither \(H\) nor \(P\),
so it uses \(\ell d\) and matches \(h,k\) to the two vertices of
\(T\setminus\{j\}\).

First suppose \(P=A,j=u\). Then \(U\) uses
\(hv_0,kz,\ell d\). Each of \(Y,V\) selects \(D\) and neither
\(H\) nor \(A\), so on the six-cycle it uses one of its two
perfect matchings:
\[
 M_1=\{hu,kz,\ell v_0\},\qquad
 M_2=\{hv_0,ku,\ell z\}.                                   \tag{5}
\]
If both use \(M_1\), the edge \(kz\) has row load three; if both
use \(M_2\), the edge \(hv_0\) has row load three. They must use
different choices. The \(H,A\) ports are already selected twice,
by \(Z,W\), so the row load at \(h\) forces \(X\) to use \(hu\),
while that at \(k\) forces \(X\) to use \(ku\). These two edges
meet at \(u\) and cannot both belong to a matching. This excludes
\((A,u)\).

Now suppose \(P=I,j=v_0\). The \(U\) matching uses
\(hu,kz,\ell d\). For either \(Q\in\{Y,V\}\), port \(I\)
covers \(k\) and port \(D\) covers \(d\). If \(Q\) uses
\(\ell z\), the complete path
\(D-d-\ell-z-k-I\) occurs in \(U\triangle Q\), contrary to
the required \(EI\mid DJ\) pairing of
[Note 309, Theorem 1](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md).
Thus \(Q\) uses \(\ell v_0\) and must use \(hu\) to cover \(h\).
Both \(Y\) and \(V\) therefore use \(hu\), as does \(U\), giving
row load three. This excludes \((I,v_0)\). \(\square\)

The theorem classifies a necessary smallest surviving six-cut
incidence pattern and removes two \(J\)-port positions by actual
right-row load and complete matching paths. It does not eliminate the
four listed positions, the \((1,2)\) allocation beginning at
\(|S|=5\), larger Hall blocks or cuts, local incidence collisions,
other shore profiles, or the Berge–Fulkerson conjecture. The proof is
hand-derived; no local enumeration or OMEN run was used.
