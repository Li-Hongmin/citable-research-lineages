> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The one-spoke prism double star excludes the \(Z,W\)-forbidden pair

Use the one-internal-mark, one-shore \(|U|=r=5\) double-star exterior of [Note 497](497-the-one-spoke-prism-double-star-excludes-the-x-y-forbidden-pair.md):
\[
(u_1,u_2,u_3,u_4,u_5)=(AB,AC,Aa,ab,ac),\qquad
(X,Y,Z,W)=(BC,bc,Bb,Cc).
\tag{1}
\]
Assume complete exact Case-XII support with forbidden \(eZ,eW\). The two possible allowed pentagons are
\[
S_1=e-X-Z-W-Y-e,\qquad S_2=e-X-W-Z-Y-e.
\tag{2}
\]

**Theorem.** No such pole exists, regardless of the order, cycle rank or complete perfect-matching family of the six-port shore. Together with Note 497, this excludes both opposite forbidden-pair orbits for this one-spoke double-star tree. The tree automorphisms exchanging its triangular layers and exchanging \(B,C\) simultaneously with \(b,c\) act as independent swaps \(X\leftrightarrow Y\) and \(Z\leftrightarrow W\); hence its four mixed forbidden pairs form one remaining orbit, represented by \(\{eX,eZ\}\). The other one-spoke trees are not treated here.

The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual \((eZ)(eX)\) BF row. Name its six **complete** matching occurrences
\[
P=eZ,\quad R=eX,\quad K=X,\quad J=Z,\quad D_0=e,\quad D_1=e.
\tag{3}
\]
The \(X\)-starting component of \(R\triangle K\) cannot end at \(Z\), which would give forbidden \([eZ]\) beside \(P\), or at \(W\), which would give forbidden \((eZ)(eW)\). It must end at \(Y\). Switching that component gives \(R'=eY,K'=Y\) while **retaining the full shore restriction** \(Q_R=Q_{R'}\). The component stays outside the shore: from the zero-port root it enters each tree subdivision by a \(K\)-half and exits by the \(R\)-half, so it never traverses a proper port.

For either \(D\in\{D_0,D_1\}\), the \(e\)-starting paths in \(R\triangle D\) and \(R'\triangle D\) exit the shore through the same port. The complementary three-matching half \(P+J+E\), with \(E\) the other singleton-\(e\) occurrence, has state \(eZ\in T\). Switching those complete paths makes the first half have states \(Xt\) and \(Yt'\). Avoiding a genuine forbidden \(T\)--\(T\) row therefore requires, for **each** \(D\),
\[
S_1:\ Z\longrightarrow W,
\qquad S_2:\ W\longrightarrow Z,
\tag{4}
\]
where the arrow compares exterior terminal arms at the **same** shore port. This is [Note 496's transfer principle](496-the-x-y-forbidden-hamilton-k33-pair-fails-an-x-arm-transfer.md) with the labels permuted; it uses no selected-row inference about new shore matchings.

**Two crossed routes.** Rooting \(R=eX\) at \(X:B\) or \(X:C\), the four potential \(X\)-to-\(Y\) tree routes join those roots to \(Y:b\) or \(Y:c\). The \(B\to b\) route covers both ends of mark \(Z=Bb\) in \(K\), and the \(C\to c\) route covers both ends of \(W=Cc\); neither gives a matching. The remaining routes each use three tree halves and force
\[
\begin{array}{c|c|c|c}
R\text{ root};\ R'\text{ root}&K\text{ marked halves}&K\text{ tree halves}&K\text{ ports}\\\hline
X:B;\ Y:c&Y:c,Z:b,W:C&B u_1,A u_3,a u_5&p_2,p_4\\
X:C;\ Y:b&Y:b,Z:B,W:c&C u_2,A u_3,a u_4&p_1,p_5.
\end{array}
\tag{5}
\]
The two zero-port choices for \(P=eZ\) are \(Z:B\) and \(Z:b\). We check these four root pairs below. For a singleton-\(e\) matching \(D\), write \(A u_i,a u_j\) for its two remaining tree halves whenever its four marked halves cover \(B,C,b,c\). Every port statement below follows by alternating \(R,D\) or \(R',D\) along the indicated tree; the shore part is unchanged between comparisons.

**First route, \(P:Z:B\).** The marked and original-vertex loads force the two singleton-\(e\) occurrences to have opposite patterns
\[
D_B:X:C,Y:b,Z:B,W:c,
\qquad D_b:X:B,Y:c,Z:b,W:C.
\tag{6}
\]
Both have \(i\in\{2,3\}\), \(j\in\{4,5\}\). For \(D_B\), the old \(Z\)-arm exits at \(p_1\) if \(i=2\) and at \(p_2\) if \(i=3\); the new \(W\)-arm exits at \(p_5\) if \(j=4\) and at \(p_4\) if \(j=5\). Thus \(S_1\)'s transfer in (4) is impossible. Its new \(Z\)-arm always exits at \(p_1\). Its old \(W\)-arm exits there only for \((i,j)=(3,5)\), so \(S_2\) forces
\[
D_B:A u_3,a u_5,\qquad D_b:A u_2,a u_4.
\tag{7}
\]
For the resulting \(D_b\), the old \(W\)-arm exits at \(p_1\), while its new \(Z\)-arm exits at \(p_5\). This violates \(S_2\)'s transfer and excludes the first root pair.

**First route, \(P:Z:b\).** Both singleton-\(e\) occurrences are forced to use \(X:C,Y:b,Z:B,W:c\), one \(A u_i\) with \(i\in\{1,2\}\), and one \(a u_j\) with \(j\in\{3,4,5\}\). Their old \(Z\)-arms exit at \(p_1\) for \(i=2\) and at \(p_2\) for \(i=1\). Their new \(W\)-arms exit at \(p_5\) for \(j=4\) and at \(p_4\) otherwise. So \(S_1\) is impossible for either occurrence. For \(S_2\), the old \(W\)-arm and new \(Z\)-arm can share a port only when
\[
(i,j)=(1,3)\quad\text{or}\quad(1,5).
\tag{8}
Indeed the old \(W\)-arm exits at \(p_5\) for \(j=3,4\) and at \(p_3\) for \(j=5\); the new \(Z\)-arm exits at \(p_1\) for \(i=2\), at \(p_5\) for \((i,j)=(1,3)\), and at \(p_3\) for \(i=1,j=4,5\). Both singleton-\(e\) occurrences would therefore use \(A u_1\), already used by \(R\), giving load three. This excludes the second root pair.

**Second route, \(P:Z:B\).** Both singleton-\(e\) occurrences now use \(X:B,Y:c,Z:b,W:C\), with \(i\in\{1,2,3\}\), \(j\in\{4,5\}\). Their old \(W\)-arms exit at \(p_2\) for \(i=1\) and at \(p_1\) otherwise; their new \(Z\)-arms exit at \(p_4\) for \(j=5\) and at \(p_5\) for \(j=4\). Hence \(S_2\) is impossible. The old \(Z\)-arm and new \(W\)-arm can share a port only for
\[
(i,j)=(2,4)\quad\text{or}\quad(3,4).
\tag{9}
\]
For checking, the old \(Z\)-arm exits at \(p_4\) for \(j=5\), at \(p_2\) for \((i,j)=(3,4)\), and at \(p_3\) otherwise. The new \(W\)-arm exits at \(p_3\) for \(i=2\) and at \(p_2\) otherwise. Thus \(S_1\) would make **both** singleton-\(e\) occurrences use \(a u_4\), already used by \(K\), giving load three. This excludes the third root pair.

**Second route, \(P:Z:b\).** The two singleton-\(e\) occurrences split the \(Z:B,Z:b\) halves. Call them \(D_B,D_b\). The loads force
\[
D_B:X:C,Y:b,Z:B,W:c,
\qquad D_b:X:B,Y:c,Z:b,W:C.
\tag{10}
\]
The \(A\)-half of \(D_B\) is \(A u_1\) or \(A u_2\), and its \(a\)-half is \(a u_3\) or \(a u_5\). Its old \(Z\)-arm exits at \(p_2\) or \(p_1\), respectively, while its new \(W\)-arm exits at \(p_5\) or \(p_4\) according as its \(a\)-half is \(a u_3\) or \(a u_5\). Thus \(S_1\) is impossible. The other occurrence \(D_b\) also has \(A u_1\) or \(A u_2\) and \(a u_3\) or \(a u_5\). Its old \(W\)-arm exits at \(p_2\) or \(p_1\) according as its \(A\)-half is \(A u_1\) or \(A u_2\); its new \(Z\)-arm exits at \(p_5\) or \(p_4\) according as its \(a\)-half is \(a u_3\) or \(a u_5\). So \(S_2\) is impossible. All four root pairs have failed. \(\square\)

The argument switches only components of complete actual matchings. It leaves the shore unrestricted and does not invoke a selected subset in place of full closure. The theorem is conditional on [Note 358's](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) tree-profile reduction and on the hand-derived arm table above; the adjacent forbidden-pair orbit, other one-spoke trees, other five-pole profiles and Berge--Fulkerson remain open. No OMEN or local mathematical recomputation was used; the proof awaits independent review.
