> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(ea\)--\(eb\) row creates two exterior pure-load fibres

Continue the central-path six-port shore and the allowed pentagon \(S=e-a-b-d-c-e\) of [Note 341](341-the-eb-row-forces-distinct-zero-port-shore-matchings.md). Work with complete exact-Case-XII support and an actual required row
\[
R=X_{ea}+Y_a+Z_e+U_{eb}+V_e+W_b=2\mathbf1.             \tag{1}
\]
The two state-\(ea\) halves obtained by exchanging the complete singleton-\(e\) occurrences \(Z,V\) are both pure \(S\), because their opposite state is the forbidden-Tait state \(eb\in T\). Write \(M|_{\rm ext}\) for the exterior mask, including the proper shore ports.

**Theorem.** Every row (1) satisfies
\[
                         Z_e|_{\rm ext}\ne V_e|_{\rm ext}. \tag{2}
\]
If \(k\) is the number of alternating-cycle components of \(X_\Sigma\triangle U_\Sigma\), then \(k\ge1\) by Note 341. Row (1) generates at least \(2^{k+1}\) distinct complete pure state-\(ea\) half-load vectors: \(2^k\) over each of two distinct exterior vectors. In particular at least two of these half-loads have a nonunit exterior vector.

**Proof of (2).** Suppose \(Z,V\) have the same exterior mask \(N\). At the marked vertex \(t_b\), the two terminal-\(b\) uses belong to \(X,W\), while \(Z,V\) double one of the two marked halves. Thus \(U,Y\) must both use the other half. [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md) gives exactly two pure singleton-\(a\) exterior masks: \(Y_L\) uses \(b:D\) and has proper shore ports \(HJ\); \(Y_R\) uses \(b:A\) and has ports \(ID\). The two state-\(eb\) zero-port exterior masks of [Note 340, (3)](340-the-eb-cell-needs-a-port-defect-or-a-second-zero-port-matching.md) therefore force
\[
\begin{array}{c|c|c}
Y&U&N\text{ uses}\;b:\\\hline
Y_L&U_D&A\\
Y_R&U_A&D.
\end{array}                                                \tag{3}
\]
At \(t_a\), \(X\) uses \(a:C\), while \(Y,U\) use the terminal semiedge \(a\). If both \(Z,V\) used \(a:C\), that edge would have load at least three. Therefore \(N\) uses \(a:\Sigma\), and \(W\) uses \(a:C\).

The complete sixteen-mask route table of Note 271 now leaves only the following masks \(N\) that are pure for the specified side. Each row shows an exterior edge already used by \(X\), \(U\), or \(Y\); its two uses in \(Z,V\) would overload that edge:
\[
\begin{array}{c|c|c}
Y&N\text{ beyond }a:\Sigma\text{ and the marked halves}&
\text{edge already used}\;\\\hline
Y_L&2C,3D&2C\in Y_L\\
Y_L&2C,4D&2C\in Y_L\\
Y_L&3C,4D&3C\in U_D\\\hline
Y_R&2C,4E&4E\in X,U_A\\
Y_R&1B,2C&1B\in U_A\\
Y_R&1B,3C&1B\in U_A\\
Y_R&2B,3C&2B\in X\\
Y_R&1A,2C&1A\in X.
\end{array}                                                \tag{4}
\]
The left entries are precisely the pure-left orientation-I masks with \(a:\Sigma,b:A\); the right entries are the pure-right orientation-II, III and IV masks with \(a:\Sigma,b:D\). Since every possibility overloads an edge, (2) follows.

**Zero-port phase switches.** By Note 341 the shore restrictions \(Q_X=X_\Sigma\), \(Q_U=U_\Sigma\) are different zero-port perfect matchings. Their symmetric difference is the disjoint union of \(k\ge1\) even alternating cycles. On any subset of these cycles, exchange the \(X,U\) labels. The two resulting shore masks remain perfect matchings, and [Note 230's Cartesian factorization](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) glues them to the *unchanged* state-\(ea\) and state-\(eb\) exteriors. Their sum, hence every edge load of (1), is unchanged. Different subsets give distinct pure-half loads \(X+Y+Z\) on the shore, all with the same exterior vector \((X+Y+Z)|_{\rm ext}\). There are \(2^k\) of them.

Now exchange the complete \(Z,V\) occurrences in each such row. This again preserves all six edge loads and the row type, and creates another \(2^k\) distinct pure-half loads with exterior vector \((X+Y+V)|_{\rm ext}\). The two exterior vectors differ by (2), so none of these two sets overlap. Every pure state-\(ea\) exterior unit vector is the same all-ones vector; hence at least one of the two exterior vectors is nonunit. This proves the remaining assertions. \(\square\)

**Cross-row consequence.** Suppose, in addition, that a genuine left \((ea)(ac)\) row and a genuine right \((ea)(ad)\) row coexist. By [Note 339](339-the-genuine-right-row-forces-an-internal-pure-load-circulation.md), their pure half-load sets are disjoint, have sizes at least \(2^{c_L},2^{c_R}\) with \(c_L,c_R\ge1\), and all lie above the same unit exterior vector. At least one of the two \((ea)(eb)\) exterior vectors is nonunit and contributes \(2^k\) further loads. Thus the three required row types together supply at least
\[
                   2^{c_L}+2^{c_R}+2^k\ge6               \tag{5}
\]
distinct complete pure state-\(ea\) half-load vectors. If both \((ea)(eb)\) exterior vectors are nonunit, the bound becomes \(2^{c_L}+2^{c_R}+2^{k+1}\ge8\). These are necessary matching-closure multiplicities, not a construction of full exact Case XII. The right \((ea)(ad)\) orientation is an explicit hypothesis of (5); exact support alone has not been shown to force it.

There is a corresponding **orientation separation** at the unit exterior vector. If \(Y=Y_L\) in the \((ea)(eb)\) row, none of its pure-half loads can equal a pure-half load from the genuine right \((ea)(ad)\) row; if \(Y=Y_R\), none can equal one from the left \((ea)(ac)\) row. For equality would allow the three actual pure-half matchings of the \((ea)(eb)\) row to replace the equal-load pure half of the opposite-orientation row, leaving its other three matchings and the load-two equation intact. The resulting \(ac\) or \(ad\) row would have one singleton-\(a\) exterior mask \(Y_L\) and the other \(Y_R\), contrary to the no-mixed-sides route theorem of Notes 271 and 297. Thus, if one \((ea)(eb)\) exterior vector is unit, its \(2^k\) shore phases can overlap only the same-orientation anchor row's pure-load family.

The central-path profile with different zero-port shore masks remains possible under these bounds. A contradiction would have to couple the two new exterior fibres to other required cells or to the forbidden \(T\)-state completions; counting the pure half-loads alone does not do so.
