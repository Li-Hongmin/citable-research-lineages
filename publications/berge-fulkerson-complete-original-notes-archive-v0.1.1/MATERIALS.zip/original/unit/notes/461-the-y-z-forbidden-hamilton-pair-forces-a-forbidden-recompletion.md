> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(Y,Z\)-forbidden Hamilton pair forces a forbidden recompletion

Use the Hamilton three-spoke exterior and six **complete** matching occurrences of [Note 458](458-the-y-z-forbidden-hamilton-pair-has-five-tree-signatures.md):
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36),
\qquad (P,R,K,J,a,b)=(eY,eX,X,Y,e,e).
\tag{1}
\]
The required old row has terminal pairs
\[
e=ab,\qquad X=PK,\qquad Y=RJ,\qquad Z=W=PR.
\tag{2}
\]
Here \(P=eY\) means that the triple occurrence \(P\) **misses** the terminals \(e,Y\). The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires this row and forbids both \([eY]\) and \((eY)(eZ)\), under either pentagon orientation specified in Note 458. We prove that any genuine row (2), in this fixed marked exterior and at **any shore order**, gives one of those forbidden types in the complete support.

Write \(S=\{J,a,b\}\) and \(S_x=S\setminus\{x\}\), viewed as the two-label edge pair. At a tree subdivision \(u_i\), a triple lists the first-end half, second-end half, and proper port. At \(X,Y,Z,W\), it lists the terminal and then the halves in the orders \((1,4),(1,5),(2,6),(3,6)\). Thus each displayed triple must partition \(\{P,R,K,J,a,b\}\). Every certificate below keeps the old pair on **each** of the six shore ports \(e,p_1,\ldots,p_5\) label by label. Consequently it glues to each original occurrence's entire shore restriction, without identifying two different shore matchings.

## Corrected short-route gate

The \(X\)-starting component of \(R\triangle K\) must end at \(W\): endpoints \(Y,Z\) would give the forbidden \([eY]\) or \((eY)(eZ)\). It moves monotonically away from \(R\)'s tree root and traverses at most three tree edges, because \(K\) has exactly three tree halves. The four endpoint routes are \(1\to3,1\to6,4\to3,4\to6\); the five-edge route \(1\to6\) is too long.

The three possible short \(X\)-to-\(W\) tree routes in Note 458 are \(1\to3\), \(4\to3\), and \(4\to6\). Its signature \(C_1\) is actually impossible. There \(K\) uses the proper ports at \(u_2,u_3\), so it uses neither tree half incident with original vertex \(3\); it uses \(W:6\), so it also misses \(W:3\). These are all three edges at vertex \(3\), contradicting that \(K\) is a perfect matching. The necessary gate therefore has only \(A,B_1,B_2,C_2\). Note 458 and [Note 460](460-both-diagonal-y-z-hamilton-rows-force-a-forbidden-double-triple.md) already exclude all phases of \(A\): its non-diagonal phases give \([eY]\), and its diagonal phases give \((eY)(eZ)\).

## \(B_1\): one template for every port phase

In \(B_1\), the old roots are \(P:Y:1\) and \(R:X:4\), while \(K\) takes \(1u_1,2u_2,4u_3\) and the ports \(p_4,p_5\). At vertex \(1\), write \(Y:1=P\nu\), where \(\nu\in\{a,b\}\), and call the other \(e\)-singleton \(\bar\nu\). The old marked and tree partitions force \(Y:5=K\bar\nu\), \(X:4=R\nu\). If the companions on \(u_1:2,u_2:3,u_3:3\) are respectively \(\alpha,\beta,\gamma\), vertex \(3\) forces \(\{\alpha,\beta,\gamma\}=S\). Propagating the pairs through \(Z,W\) gives exactly
\[
(p_1,p_2,p_3,p_4,p_5)
=(S_\alpha,S_\beta,S_\gamma,K\nu,K\bar\nu),
\qquad \{\alpha,\beta,\gamma\}=S.
\tag{3}
\]
For every choice in (3), use the following new exterior row:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
& (RK,P\alpha,S_\alpha)&(K\beta,PR,S_\beta)&
(K\gamma,PR,S_\gamma)&(J\bar\nu,PR,K\nu)&
(J\nu,PR,K\bar\nu)
\end{array}
\tag{4}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(PR,J\bar\nu,K\nu)&(RJ,P\nu,K\bar\nu)&
(PK,R\gamma,S_\gamma)&(PR,S_\gamma,K\gamma).
\end{array}
\tag{5}
\]
At vertices \(1,\ldots,6\), the three incident pairs are respectively
\[
(RK,J\bar\nu,P\nu),\quad
(P\alpha,K\beta,R\gamma),\quad
(PR,K\gamma,S_\gamma),\quad
(PR,J\bar\nu,K\nu),\quad
(PR,J\nu,K\bar\nu),\quad
(PR,S_\gamma,K\gamma).
\tag{6}
\]
Every triple in (4)--(6) is a partition; the proper-port column of (4) is (3).

## \(B_2\): three old phases and four recompletions

Interchange \(a,b\) if necessary so that the old \(Y:1=Ka\) and \(Y:5=Pb\). In \(B_2\), the old roots are \(P:Y:5,R:X:4\); \(K\) takes \(2u_1,4u_3,5u_5\) and ports \(p_2,p_4\). Reading the old tree subdivisions gives
\[
(p_1,p_2,p_3,p_4,p_5)
=(S_\sigma,K\sigma,S_\xi,K\delta,S_\eta),
\qquad \sigma\in S.
\tag{7}
\]
For completeness, if the old \(u_4:4\) pair is \(P\rho\) and its \(u_4:5\) pair is \(R\chi\), the three remaining old original-vertex and subdivision partitions are
\[
\{\xi,\rho,a\}=S,\qquad
\{\rho,\chi,\delta\}=S,\qquad
\{\chi,\eta,b\}=S.
\tag{8}
\]
They have precisely the following solutions; \(\sigma\) remains arbitrary in every row:
\[
\begin{array}{c|ccc|ccc}
&\xi&\delta&\eta&p_3&p_4&p_5\\ \hline
I&b&b&J&Ja&Kb&ab\\
II&J&a&a&ab&Ka&Jb\\
III&J&J&J&ab&KJ&ab
\end{array}
\tag{9}
\]
The following four templates cover (9). Each row gives \((u_1,\ldots,u_5)\) and then \((X,Y,Z,W)\) in the slot order above.

For phase \(I\), \(\sigma=b\), use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(Rb,PK,Ja)&(Ja,PR,Kb)&(Kb,PR,Ja)&(Ja,PR,Kb)&(KJ,PR,ab)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,Ja,Kb),(RJ,PK,ab),(PK,Rb,Ja),(PR,Ja,Kb)).
\tag{10}
\]
For phase \(I\), \(\sigma=J\), use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RJ,PK,ab)&(Ra,Pb,KJ)&(RK,Pb,Ja)&(Ra,PJ,Kb)&(RK,PJ,ab)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,ab,KJ),(RJ,PK,ab),(PK,Jb,Ra),(PR,Ja,Kb)).
\tag{11}
\]
For phase \(I\), \(\sigma=a\), use a different singleton-terminal assignment:
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RK,Pa,Jb)&(RJ,Pb,Ka)&(RK,Pb,Ja)&(RJ,Pa,Kb)&(RK,PJ,ab)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,Jb,Ka),(RK,Pa,Jb),(PJ,Kb,Ra),(PR,Ja,Kb)).
\tag{12}
\]
For both phases \(II,III\), put \(\eta=a\) or \(J\), respectively, and use, for **every** \(\sigma\in S\),
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\sigma,S_\sigma)&(PR,S_\sigma,K\sigma)&
(PR,KJ,ab)&(PR,S_\eta,K\eta)&(R\eta,PK,S_\eta)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,KJ,ab),(RJ,ab,PK),(PK,S_\sigma,R\sigma),
(PR,K\sigma,S_\sigma)).
\tag{13}
\]
In (10)--(13), the proper-port columns are exactly (7)--(9). Their original vertices read as follows; each parenthesis is one six-label partition:
\[
\begin{array}{c|llllll}
&1&2&3&4&5&6\\ \hline
(10)&(Rb,Ja,PK)&(PK,Ja,Rb)&(PR,Kb,Ja)&(PR,Ja,Kb)&(PR,KJ,ab)&(PR,Ja,Kb)\\
(11)&(RJ,ab,PK)&(PK,Ra,Jb)&(Pb,RK,Ja)&(Pb,Ra,KJ)&(PJ,RK,ab)&(PJ,Ra,Kb)\\
(12)&(RK,Jb,Pa)&(Pa,RJ,Kb)&(Pb,RK,Ja)&(Pb,RJ,Ka)&(Pa,RK,Jb)&(PJ,Ra,Kb)\\
(13)&(PR,KJ,ab)&(K\sigma,PR,S_\sigma)&(S_\sigma,PR,K\sigma)&
(KJ,PR,ab)&(S_\eta,R\eta,PK)&(PK,R\sigma,S_\sigma)
\end{array}
\tag{14}
\]

## \(C_2\): two templates for every port phase

Again take the old \(Y:1=Ka,Y:5=Pb\) by swapping \(a,b\) if needed. The old \(C_2\) roots are \(P:Y:5,R:X:4\); \(K\) takes \(3u_2,4u_4,5u_5\), ports \(p_1,p_3\), and marked halves \(Y:1,Z:2,W:6\). The old vertex partitions force
\[
(p_1,p_2,p_3,p_4,p_5)
=(K\alpha,S_\alpha,Ka,S_\lambda,S_\mu),
\qquad \alpha\in S,\quad \{\lambda,\mu\}=\{J,a\}.
\tag{15}
\]
If \(\alpha=b\), use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,Ja,Kb)&(Pb,RK,Ja)&(PJ,Rb,Ka)&
(PK,R\lambda,S_\lambda)&(K\mu,PR,S_\mu)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,Kb,Ja),(RK,Ja,Pb),(PJ,RK,ab),(PR,ab,KJ)).
\tag{16}
\]
If \(\alpha\in\{J,a\}\), let \(\gamma\) be the other element of \(\{J,a\}\), and use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(Rb,P\gamma,K\alpha)&(K\alpha,PR,S_\alpha)&
(Jb,PR,Ka)&(K\lambda,PR,S_\lambda)&(K\mu,PR,S_\mu)
\end{array}
\]
\[
(X,Y,Z,W)=
((PR,K\lambda,S_\lambda),(RK,P\mu,S_\mu),
(PJ,Rb,Ka),(PR,Ka,Jb)).
\tag{17}
\]
The port columns in (16)--(17) equal (15). The original vertices of (16) see
\[
(PR,Kb,Ja),\ (Ja,Pb,RK),\ (RK,PJ,ab),\
(Rb,PK,Ja),\ (R\lambda,K\mu,Pb),\ (PR,ab,KJ),
\tag{18}
\]
and those of (17) see
\[
(Rb,K\lambda,P\mu),\ (P\gamma,K\alpha,Rb),\
(PR,Jb,Ka),\ (PR,K\lambda,S_\lambda),\
(PR,K\mu,S_\mu),\ (PR,Ka,Jb).
\tag{19}
\]
All are six-label partitions using \(\{\lambda,\mu\}=\{J,a\}\) and, in (17), \(\{\gamma,\alpha\}=\{J,a\}\).

## Boundary and conclusion

Every subdivision triple in (4)--(5), (10)--(13), and (16)--(17) is a six-label partition; (6), (14), and (18)--(19) check the six original vertices. Every edge has one two-label pair, and the six labelled pairs at \(e,p_1,\ldots,p_5\) agree with the old genuine row. Hence each template yields six complete perfect matchings of the **same** five-pole, covering every edge twice. In (4)--(5), (10)--(11), and (13), their terminal pairs are
\[
e=ab,\quad X=W=PR,\quad Y=RJ,\quad Z=PK;
\tag{20}
\]
in (12) and (16)--(17), they are
\[
e=ab,\quad X=W=PR,\quad Y=RK,\quad Z=PJ.
\tag{21}
\]
Both (20) and (21) have the forbidden BF type \((eY)(eZ)\). Together with Notes 458 and 460, this proves the **conditional all-order closure law**
\[
\boxed{\text{genuine }(eY)(eX)\text{ row}
\quad\Longrightarrow\quad
[eY]\text{ or }(eY)(eZ)\text{ occurs in complete support}}
\tag{22}
\]
for this fixed labelled Hamilton three-spoke exterior. Thus no exact-Case-XII five-pole with this exterior has forbidden pair \(\{eY,eZ\}\), for either allowed pentagon orientation. The other forbidden-pair orbits, other exteriors, the full exact Case XII obstruction, and Berge--Fulkerson remain open. This is a hand-derived proof, without OMEN or local mathematical recomputation, and awaits independent-source review. \(\square\)
