> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The near-end path \(CE\) neighbour overloads the \((ea)(eb)\) row

Continue the minimum-host, complete exact-Case-XII, one-internal-mark five-cut setting of [Note 267](267-the-near-end-path-marking-excludes-the-ad-neighbour.md), with the same \(|U|=r=4\) path exterior
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad h_i=u_i\Sigma,
\]
and marks
\[
a:B\!:\!\Sigma,\qquad b:AD,\quad c:AE,\quad d:CE. \tag{1}
\]
Here \(\Sigma\) has arbitrary odd order and unmarked cycle rank. Suppose this time that \(ea,ed\in S\); the other two pairs \(eb,ec\) incident with \(e\) lie in \(T\).

**Theorem.** No pole with (1) and \(ea,ed\in S\) has complete exact-Case-XII perfect-matching support. Every pure-\(S\) state-\(ea\) half forces its singleton-\(e\) exterior to contain \(1B\). In a required real \((ea)(eb)\) row, exchanging the two complete singleton-\(e\) matchings forces two uses of \(1B\), while the opposite state-\(eb\) zero-port triple forces a third.

## The pure-half singleton-\(e\) mask

The state-\(ea\) triple has the unique zero-port exterior
\[
X_a=\{a:B,1A,2C,3D,4E\}.                           \tag{2}
\]
In any pure-\(S\) state-\(ea\) half, the \(a\)-terminal path of \(X_a\triangle Y_a\) must end at \(d\), the other allowed neighbour of \(e\). By [Note 244's exterior-path argument](244-every-shore-mark-must-neighbour-the-internal-mark.md), it stays outside \(\Sigma\). Ending at \(d:E\) would force \(2B,3C,4D,d:E\) along that path; the remaining marks \(b:AD,c:AE\) would both need \(A\). Thus it ends at \(d:C\). Switching that path gives the state-\(ed\) zero-port triple
\[
X_d=\{d:C,1A,2B,3D,4E\},                           \tag{3}
\]
with exactly the same complete shore matching as \(X_a\).

Let \(Z_e\) be the singleton-\(e\) occurrence of the pure half. Purity requires the *same* shore \(e\)-port in \(X_a\triangle Z_e\) and \(X_d\triangle Z_e\) to have external terminal endpoints \((b,c)\) or \((c,b)\). We show this forces a unique exterior mask.

First suppose \(Z_e\) uses \(d:C\). If it uses \(2B\), then its \(a\)-half is \(a:\Sigma\); the switch from (2) to (3) changes the external \(d\)-route into the \(a\)-route, leaving the \(b,c\) routes unchanged. Otherwise \(u_2\) uses \(h_2\). If \(Z_e\) uses \(a:B\), the same switch again replaces the \(d\)-route at \(h_2\) by the \(a\)-route. In the remaining case, \(Z_e\) uses \(a:\Sigma\) and \(1B\): one of the \(b,c\) routes may move from \(a:\Sigma\) to \(h_2\), but the other remains fixed, while \(a:\Sigma\) now reaches terminal \(a\). None of these three route patterns gives \((b,c)\) or \((c,b)\) at one port.

Thus \(Z_e\) uses \(d:E\). Since the nonterminal marks must choose distinct singleton endpoints, this forces \(b:D,c:A\). The following table lists **every** compatible way to cover the remaining path vertices. For each mask it shows only the proper shore ports that reach \(b\) or \(c\) against (2), together with their endpoint against \((X_a,X_d)\):

| \(a\)-half | Other \(K\)-edges of \(Z_e\) | Relevant port endpoint pairs |
|---|---|---|
| \(B\) | \(2C\) | \(h_1:(c,c),\ h_3:(b,b)\) |
| \(B\) | \(3C\) | \(h_1:(c,c),\ h_2:(b,a)\) |
| \(\Sigma\) | \(1B,2C\) | \(a:\Sigma:(c,a),\ h_3:(b,b)\) |
| \(\Sigma\) | \(1B,3C\) | \(a:\Sigma:(c,a),\ h_2:(b,c)\) |
| \(\Sigma\) | \(2B,3C\) | \(a:\Sigma:(b,a),\ h_1:(c,c)\) |

Only the fourth row has the required opposite endpoints. Its full exterior is
\[
\boxed{Z_e|_{\rm ext}=\{a:\Sigma,b:D,c:A,d:E,1B,3C,h_2,h_4\}.} \tag{4}
\]
For the decisive \(h_2\)-route, (2) sends \(h_2\) through \(u_2-C-u_3-D-t_b\), while (3) sends it through \(u_2-B-u_1-A-t_c\). This checks \((b,c)\) directly. The derivation uses no shore matching uniqueness and no upper bound on \(|\Sigma|\).

## The required cross-row overload

The [published Case-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains a real \((ea)(eb)\) row, since \(ea\in S\) and \(eb\in T\). Its \(ea\) half is pure \(S\), so its singleton-\(e\) matching \(Z_e\) has exterior (4). The opposite state-\(eb\) half also has a singleton-\(e\) matching \(W_e\). Exchange these **complete** matching occurrences. The total six-matching edge load and opposite \(T\)-state remain unchanged, so the new \(ea\) half is still pure \(S\). The preceding mask theorem forces \(W_e\) to have exterior (4) as well. Thus \(Z_e,W_e\) already use edge \(1B\) twice.

The opposite state-\(eb\) triple has boundary \(\{a,c,d\}\) and no terminal \(e\). It must therefore select one half of the nonterminal mark \(b=AD\). Its \(b:D\) half is unavailable: \(Z_e,W_e\) already load that proper edge twice. Hence the triple selects \(b:A\). By [Note 230's zero-port quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), its exterior then contains the unique matching of \(K-A\), namely \(\{1B,2C,3D,4E\}\). The real row would load \(1B\) at least three times, contradicting edge load two. \(\square\)

With [Note 267](267-the-near-end-path-marking-excludes-the-ad-neighbour.md), only the \(ec\in S\) choice remains for the near-end path marking (1). The central path-tree marking, larger barriers, other Tutte profiles, and Berge–Fulkerson remain open. The route analysis is hand-derived and has not received an independent check.
