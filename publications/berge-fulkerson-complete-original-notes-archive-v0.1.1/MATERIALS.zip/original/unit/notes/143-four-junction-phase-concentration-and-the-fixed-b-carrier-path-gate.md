> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four junctions concentrate on one singleton phase cycle

Let \(H\) be a cubic five-pole with an actual six-perfect-matching double-cover row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1.                  \tag{1}
\]
Pair the occurrences as \(E_1=(U_{35},r_{34})\), \(E_2=(Z_3,Y_3)\), and \(E_3=(D_5,C_4)\). As in [Note 142](142-overlap-rows-force-four-singleton-phase-junctions.md), an active edge belongs to exactly two of the pair differences \(F_i=E_i^0\triangle E_i^1\), and has their type \(12\), \(13\), or \(23\). A *junction* has one incident edge of each type. A maximal constant-type path between junctions or active terminals is a *strand*. An edge is *overloaded* if its two owners in (1) lie in the same three-matching half, and *split* otherwise.

## Phase concentration

**Theorem 1.** If \(H\) has no Tait colouring of state \(34\), an individual closed component of \(Z_3\triangle Y_3\) contains at least four junctions. If, moreover, the BF type \([34]\) is absent and the total number of junctions is four, closed pair switches put the active network in the following normal form: the four junctions lie on one \(Z_3\triangle Y_3\) cycle; its strands alternate between types \(12\) and \(23\); the active terminal arms from \(4\) and \(5\) attach at opposite junctions; and a type-\(13\) chord joins the other two junctions. Precisely three strands are overloaded: the chord and the two cycle strands incident to one terminal-arm junction. They form an even proper cycle in \(H\). All other active strands are split.

If \(H\) also has no Tait colouring of state \(35\), each of the three overloaded strands **and both remaining phase-cycle strands** contains at least two proper edges. In particular, the four-junction \(Z_3\triangle Y_3\) cycle has length at least eight. These assertions concern the normalized actual row and do not assert that an exact-Case-XII five-pole exists.

**Proof.** Switching the two occurrences of \(E_i\) on a closed component of \(F_i\) preserves their boundaries, their sum, and (1). It toggles the split/overloaded status on that component. An inactive edge is split. At an active degree-two vertex the status is constant along the strand; at a junction either zero or two incident strands are overloaded. Both terminal arms are split. We first make every junction-free active cycle split by a closed pair switch.

Suppose every component of \(F_2=Z_3\triangle Y_3\) has zero or two junctions. Each two-junction component consists of a type-\(12\) and a type-\(23\) strand between its junctions. Contract it to one vertex. The remaining type-\(13\) strands give a disjoint union of cycles and one path from terminal \(4\) to terminal \(5\). At a contracted vertex let \(x,y\) be the overload bits of its \(12,23\) strands. The bits on its two incident type-\(13\) strands are both \(z=x\oplus y\). Therefore \(z\) is constant on each contracted component, and it is zero on the terminal path. On a closed contracted cycle with \(z=1\), its type-\(13\) strands together with the type-\(12\) strand at each contracted vertex form one closed \(F_1\) component. Switching \(E_1\) there makes \(z=0\). Now \(x=y\) at every contracted vertex. Switching \(E_2\) on each two-junction component with \(x=y=1\) makes every active edge split. The \(r_{34}+Y_3+C_4\) half of the resulting actual row is a state-\(34\) Tait colouring, a contradiction. Every \(F_2\) component has an even number of junctions, because its edge types alternate between \(12\) and \(23\) at each junction. Thus one component has at least four.

If there are exactly four junctions, all belong to that one \(F_2\) component. A terminal component with no junction would be a split type-\(13\) path from \(4\) to \(5\). Along it the owners alternate between \(\{U_{35},C_4\}\) and \(\{r_{34},D_5\}\), and every inactive third edge has owners \(\{Z_3,Y_3\}\). The path is therefore the entire open \(U_{35}\triangle D_5\) component from \(4\) to \(5\). Switching \(U_{35},D_5\) there gives a BF row of forbidden type \([34]\). Hence the four junctions and both terminal arms lie in one component.

The \(F_2\) component is a four-cycle of alternating \(12,23\) strands. Each junction has one type-\(13\) port. The two terminal arms attach at distinct junctions; the other two ports form a chord. If the arms attach at adjacent junctions, their split status makes three consecutive four-cycle strands have one overload bit \(x\). Switch the entire closed \(F_2\) component to set \(x=0\). The fourth strand and the parallel type-\(13\) chord then have the same bit and form a closed \(F_1\) or \(F_3\) component. Switching it if necessary makes all edges split, again giving a state-\(34\) Tait colouring. Thus the arms are opposite. The two cycle strands at one arm junction share a bit \(x\), those at the other share a bit \(z\), and the chord has bit \(x\oplus z\). If \(x=z\), an \(F_2\) switch again makes everything split. Hence \(x\ne z\); an \(F_2\) switch locates the two overloaded cycle strands at either chosen arm junction. They and the overloaded chord make a cycle. At every vertex on this cycle its two overloaded incident edges belong to opposite halves of (1), so its length is even.

For the final assertion, edge-disjointness of any two among \(r_{34},Y_3,C_4\) would make their cubic complement a third perfect matching and yield a state-\(34\) Tait colouring. The only overloaded strand where each respective pair can intersect has type \(12,23,13\), respectively. Similarly, absence of a state-\(35\) Tait colouring forces each of \(U_{35}\cap Z_3\), \(Z_3\cap D_5\), and \(U_{35}\cap D_5\) to be nonempty on its respective strand. Along an overloaded strand the owner pair alternates between the two halves at consecutive edges, since its third edge at an internal vertex is inactive and split. Each of the three strands must therefore have at least one edge owned by each half, and has length at least two.

Switch \(E_2=(Z_3,Y_3)\) on the closed four-junction phase cycle \(\Omega\), obtaining \(Z^\Omega_3,Y^\Omega_3\). This keeps the junction-free components split and the chord overloaded, but moves the two overloaded phase-cycle strands to the opposite terminal-arm junction. Apply the same no-Tait intersection argument to this new actual row. Its overloaded type-\(12\) strand contains both \(U_{35}\cap Z^\Omega_3\) and \(r_{34}\cap Y^\Omega_3\); its overloaded type-\(23\) strand contains both \(Z^\Omega_3\cap D_5\) and \(Y^\Omega_3\cap C_4\). On \(\Omega\), these are exactly \(U\cap Y,r\cap Z\) on the formerly split type-\(12\) strand and \(Y\cap D,Z\cap C\) on the formerly split type-\(23\) strand. The two owner pairs alternate along each strand, so both formerly split strands also have at least two edges. Thus \(|E(\Omega)|\ge8\). \(\square\)

Under the disjoint pairing-critical-hexagon hypotheses of [Note 141](141-a-disjoint-critical-hexagon-is-a-five-edge-carrier-detour.md), that note shows \(Z_3\triangle Y_3\) avoids every edge incident with the hexagon. Hence all four or more junctions lie outside it. Theorem 1 does not force the phase cycle to meet either carrier path through the hexagon.

## Literal \(B_2\) transfer is a path-avoidance question

Retain the complete carrier identity from [Notes 137--138](137-no-seed-requires-a-pairing-changing-cycle-and-has-a-closed-right-fibre.md):
\[
q_{25}+B_2=U_{35}+Z_3.                                    \tag{2}
\]
Let \(\Omega\) be one closed component of \(Z_3\triangle Y_3\), and switch \(Z_3,Y_3\) on \(\Omega\), obtaining \(Z^\Omega_3,Y^\Omega_3\).

**Theorem 2.** A right-row transfer that keeps the *complete* \(B_2,D_5,r_{34},C_4\) masks, replaces \(Y_3\) by \(Y^\Omega_3\), and keeps the carrier equality with \(U_{35},Z^\Omega_3\) exists exactly when
\[
B_2(e)=U_{35}(e)\quad\text{for every }e\in E(\Omega).       \tag{3}
\]
For the fixed row (2), let \(P_{14}\) be the open \(1\leftrightarrow4\) component of \(U_{35}\triangle Z_3\), and let \(\mathcal C_U\) be the closed components on which \(q_{25}=U_{35}\). Then (3) is equivalent to
\[
E(\Omega)\cap\left(E(P_{14})\cup\bigcup_{C\in\mathcal C_U}E(C)\right)=\varnothing. \tag{4}
\]
If the closed phases of the decomposition (2) may be chosen anew, while \(U_{35},Z_3,D_5,r_{34},Y_3,C_4\) stay fixed, **some** right row permits this literal transfer exactly when \(E(\Omega)\cap E(P_{14})=\varnothing\). Choosing a new phase may change the complete \(B_2\) mask; the subsequent transfer retains that newly chosen mask.

**Proof.** The desired new triple matching is forced edgewise by the two row identities:
\[
q^\Omega_{25}=q_{25}+Y_3-Y^\Omega_3
             =q_{25}+Z^\Omega_3-Z_3.                    \tag{5}
\]
On a \(Z_3\)-edge of \(\Omega\), (5) subtracts one, so it is a matching coordinate only if \(q_{25}=1\). On a \(Y_3\)-edge, it adds one, so it is a matching coordinate only if \(q_{25}=0\). Thus \(q_{25}=Z_3\) on \(\Omega\), equivalent by (2) to (3). In that case \(q^\Omega_{25}=q_{25}\triangle\Omega\) is an actual perfect matching of the same boundary, and substitution gives both required double-cover and carrier identities. If the condition fails, (5) has a negative or a double coordinate, so no such transfer exists.

The symmetric difference \(U_{35}\triangle Z_3\) has two open components. Equality (2) fixes their pairings: the \(1,4\) terminal ends belong to \(q_{25}\) and use the \(U_{35}\) phase, while the \(2,3\) ends use the \(Z_3\) phase in \(q_{25}\). Every other component is a closed alternating cycle, on which \(q_{25}\) uses either the \(U_{35}\) or \(Z_3\) phase. Outside the difference, all four masks in (2) agree. Consequently
\[
q_{25}\triangle Z_3=B_2\triangle U_{35}
=P_{14}\sqcup\bigsqcup_{C\in\mathcal C_U}C.               \tag{6}
\]
Equations (3)--(4) follow. Each closed component of \(U_{35}\triangle Z_3\) can independently exchange the \(q_{25},B_2\) phases without changing their boundaries or sum. Choosing the \(Z_3\) phase on every such component meeting \(\Omega\) proves the last assertion. \(\square\)

## An aligned phase forces junctions in the right row

Pair the occurrences of the corresponding right row \(q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1\) as
\[
E'_1=(q_{25},Y_3),\qquad E'_2=(B_2,C_4),\qquad E'_3=(D_5,r_{34}),
\]
and let \(J'\) be the total number of junctions of its three paired differences, as in [Note 141](141-a-disjoint-critical-hexagon-is-a-five-edge-carrier-detour.md).

**Theorem 3.** Suppose (3) holds on a component \(\Omega\) of \(Z_3\triangle Y_3\). Let \(L=|E(\Omega)|\), let \(n\) be the number of junctions of the pairing \(E_1,E_2,E_3\) on \(\Omega\), and let \(k\) count those \(n\) junctions whose type-\(13\) edge is overloaded. Then the exact number of \(E'_1,E'_2,E'_3\) junctions on \(\Omega\) is
\[
J'_\Omega=L-n+k.                                         \tag{7}
\]
For the four-junction diamond of Theorem 1, \(n=4\) and \(k=2\), so \(J'_\Omega=L-2\) and \(J'\ge L-1\). If \(J'=3\), then \(L=4\) and \(H\) has an actual Tait colouring of state \(35\). If \(J'\le5\), the same Tait conclusion follows from Theorem 1's length bound. In the Tait-empty branch \(L\ge8\), hence
\[
\boxed{B_2=U_{35}\text{ on }\Omega,\quad J=4,\quad
 \text{no state-}35\text{ Tait colouring}
 \quad\Longrightarrow\quad J'\ge7.}                     \tag{8}
\]
Thus a right row with \(J'=3\) or \(5\) cannot meet the fixed-\(B_2\) phase gate (3) in this normalized Tait-empty diamond. This does not exclude a different closed \(q_{25},B_2\) phase with a different complete \(B_2\) mask and a larger \(J'\).

**Proof.** At every vertex of \(\Omega\), (3) and (2) make \(q_{25}=Z_3\) and \(B_2=U_{35}\) on all three incident edges: the first equality holds on the two \(\Omega\) edges by Theorem 2 and then on the third edge because both are perfect matchings; the second follows from (2). An internal vertex of a type-\(12\) strand has its third edge owned by \(\{D_5,C_4\}\); an internal vertex of a type-\(23\) strand has its third edge owned by \(\{U_{35},r_{34}\}\). In either case the two members of each \(E'_i\) use different incident edges. Every one of the \(L-n\) nonjunction vertices of \(\Omega\) is therefore an \(E'\)-junction.

At an \(E\)-junction, \(q_{25},Y_3\) use different \(\Omega\) edges. If its type-\(13\) edge is split, its owners are either \(\{U_{35},C_4\}\) or \(\{r_{34},D_5\}\), so \(E'_2\) or \(E'_3\), respectively, has both members on that edge; this is not an \(E'\)-junction. If its type-\(13\) edge is overloaded, its owners are \(\{U_{35},D_5\}\) or \(\{r_{34},C_4\}\), and neither \(E'_2\) nor \(E'_3\) has a common edge there. It is then an \(E'\)-junction. This proves (7).

In the diamond the two terminal-arm junctions have split type-\(13\) arms and the two chord endpoints have an overloaded type-\(13\) chord, giving \(k=2\). The \(E'\) network has exactly three active terminal semiedges, at \(1,2,4\), so its total junction count \(J'\) is odd. Because \(L\) is even, \(J'_\Omega=L-2\) is even; at least one further \(E'\)-junction lies outside \(\Omega\), proving \(J'\ge L-1\). The four phase-cycle strands give \(L\ge4\). If \(J'=3\), equality forces \(L=4\), so an overloaded triangle strand has one edge. The contrapositive of Theorem 1's final assertion gives a state-\(35\) Tait colouring. If \(J'\le5\) and there were no state-\(35\) Tait colouring, Theorem 1 would give \(L\ge8\), contradicting \(J'\ge L-1\). This proves (8) as well. \(\square\)

When (3) holds, the transfer of Theorem 2 switches the complete pair \((q_{25},Y_3)\) on \(\Omega\). Hence all three \(E'\)-difference edge sets, their junctions, and \(J'\) are identical in the two right rows; only the owner phases along \(\Omega\) change. The lower bound (8) does not itself force a new terminal pairing or a common \(B_2+C_4\) seed.

[Note 145](145-negative-tait-states-force-mixed-owner-edges-on-one-phase-cycle.md) strengthens the aligned diamond's numerical boundary without assuming Tait-emptiness: absence of state \(34\) alone forces \(L\ge6\), hence \(J'\ge5\). The conditional \(J'=3\) case above is therefore excluded under this note's hypotheses. Equality \(J'=5\) requires \(L=6\) and an actual state-\(35\) Tait colouring; the Tait-empty branch retains \(J'\ge7\).

## A real aligned diamond without exact negative support

The four-junction diamond's geometry alone does **not** force \(P_{14}\) to meet \(\Omega\). Here is an actual eleven-vertex, simple connected cubic five-pole with one semiedge \(s_i\) at terminal \(i\). Its vertices are \(a,b,c,d,x_1,x_2,x_3,y_4,v_1,v_2,v_3\); the following table specifies all fourteen proper edges and all five semiedges by their two owners in (1):
\[
\begin{array}{c|l@{\qquad}c|l}
\text{owners}&\text{edges}&\text{owners}&\text{edges}\\\hline
\{U,Z\}&ax_1&\{r,Y\}&x_1b\\
\{Z,C\}&bc&\{U,Y\}&cd\\
\{Z,D\}&dx_2&\{Y,C\}&x_2a\\
\{U,D\}&bx_3&\{r,C\}&x_3d\\
\{r,D\}&ay_4,\ s_5&\{U,C\}&s_4\\
\{D,C\}&x_1v_1,\ v_2v_3&\{U,r\}&x_2v_3,\ s_1,\ s_2\\
\{Z,Y\}&x_3v_2,\ y_4v_1,\ s_3&&
\end{array}                                                \tag{9}
\]
At every vertex the three incident owner pairs partition \(\{U,Z,D,r,Y,C\}\), so each label is an actual perfect matching and (1) holds edgewise. The four junctions are \(a,b,c,d\), with
\[
\Omega=ax_1bcdx_2a,\qquad
\text{overloaded even cycle } ax_1bx_3dx_2a.             \tag{10}
\]
The terminal arms attach at opposite junctions \(a,c\), and all three overloaded strands have two edges.

The two open components of \(U\triangle Z\) are
\[
P_{14}=s_4,\ y_4v_1,\ s_1,\qquad
Q_{23}=s_2,\ v_2x_3,\ x_3b,\ bc,\ cd,\ dx_2,\ x_2v_3,\ s_3. \tag{11}
\]
Switch \(U,Z\) along \(Q_{23}\) to obtain actual \(q_{25},B_2\) satisfying (2). Since \(P_{14}\) avoids \(\Omega\) and there is no further \(U\triangle Z\) component, \(B_2=U\) on every edge of \(\Omega\). The right-row paired network has exactly five junctions: \(x_1,b,d,x_2\) on \(\Omega\) and \(v_1\) outside it. Thus \(L=6\) and equality holds in \(J'\ge L-1=5\).

This pole is outside exact Case XII: the following three disjoint matching colour classes give an actual state-\(34\) Tait colouring, hence a forbidden \([34]\) BF loop:
\[
\begin{array}{c|l}
\text{triple colour}&s_1,s_2,s_5,\ ay_4,\ x_1b,\ x_2v_3,\ x_3d\\
\text{singleton }3&s_3,\ y_4v_1,\ ax_1,\ bc,\ dx_2,\ v_2x_3\\
\text{singleton }4&s_4,\ x_1v_1,\ ax_2,\ cd,\ bx_3,\ v_2v_3
\end{array}                                                \tag{12}
\]
There is a second explicit forbidden exit. In the original right row, the \(q_{25}\triangle r_{34}\) terminal path from \(2\) ends at \(3\):
\[
s_2,\ v_2x_3,\ x_3d,\ dx_2,\ x_2v_3,\ s_3.
\]
For a direct mask check, the two class-\(25\) matchings before and after the transfer are
\[
q_{25}=\{s_1,s_3,s_4,ax_1,bc,dx_2,v_2x_3\},\qquad
q^\Omega_{25}=\{s_1,s_3,s_4,x_1b,cd,x_2a,v_2x_3\}.
\]
Perform the fixed-\(B_2\) transfer on \(\Omega\), giving \(q^\Omega_{25}=q_{25}\triangle\Omega\) and \(Y^\Omega_3=Y_3\triangle\Omega\). The \(q^\Omega_{25}\triangle r_{34}\) path from \(2\) now ends at \(5\):
\[
s_2,\ v_2x_3,\ x_3d,\ dc,\ s_5.
\]
Switching that path produces the actual all-terminal perfect matching
\[
A_{\{1,2,3,4,5\}}=\{s_1,s_2,s_3,s_4,s_5,x_1b,x_2a,x_3d\},
\]
while the companion becomes \(r'_1=\{s_1,x_1b,ay_4,x_2v_3,v_2x_3,cd\}\). The identity \(q^\Omega_{25}+r_{34}=A_{\{1,2,3,4,5\}}+r'_1\) leaves the other four row masks fixed, giving a forbidden BF cover of type \((12345)\). Thus a literal fixed-\(B_2\) phase transfer can change the cross-half triple pairing in a real cubic pole. Exact Case-XII negative support rules out this \(2\leftrightarrow5\) outcome, but the example does not decide whether that exclusion forces \(P_{14}\) to meet \(\Omega\) or yields a common \(B_2+C_4\) seed.

The example proves sharpness for the selected-row incidence and shows that any rule forcing \(P_{14}\cap\Omega\ne\varnothing\) must use additional global hypotheses.

For a row in the four-junction diamond normal form of Theorem 1, \(\Omega\) can be chosen as its unique four-junction phase cycle. Theorems 1--3 do not give a common complete \(B_2+C_4\) seed or establish the existence of a genuine exact-Case-XII pole. They identify the additional carrier-path incidence that a fixed-mask phase argument must settle.

The [Máčajová--Mazzuoccolo--Tabarelli source](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Appendix XII, excludes \([34]\) from Case XII. Its Proposition 4.4 does not require the corresponding five-pole to be Tait colourable, so the state-\(35\) assumption in the strand-length conclusion is an explicit additional branch assumption.
