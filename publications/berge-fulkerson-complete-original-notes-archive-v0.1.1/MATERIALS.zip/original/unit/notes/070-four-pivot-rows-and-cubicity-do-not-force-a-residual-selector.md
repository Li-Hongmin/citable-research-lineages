> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four pivot rows and cubicity do not force a residual selector

Let four actual (D_5) completions form an anchored pivot star, and let
(mathcal F_T) be the five-occurrence submultisets of their matching
occurrences whose boundary residual would complete a (T)-loop or (T)--(T)
cover.  The hoped-for implication

\[
 \text{failed UE2 pivot star in a cubic 5-pole}
 \Longrightarrow
 \exists F\in\mathcal F_T:\ 1\le \ell_F(e)\le2\quad(e\in E(H))
 \tag{1}
\]

is false, even for a simple connected bridge-free cubic 5-pole.

Take semiedges at vertices (0,1,2,3,4), and proper edges

\[
\begin{split}
 &(0,10),(0,11),(1,8),(1,9),(2,9),(2,10),(3,7),(3,12),\\
 &(4,6),(4,7),(5,6),(5,7),(5,8),(6,12),(8,11),(9,11),(10,12).
\end{split}
\tag{2}
\]

This pole has (36) perfect matchings.  Fifteen of them form four genuine
six-matching double covers in the cells

\[
 (24,15),\quad(13,45),\quad(25,34),\quad(35,12).
\]

Using ((24,15)) as anchor, the three extensions in singleton class (3)
are three different actual perfect matchings.  Thus the equality graph has
no edge and UE2 fails.  There are exactly (79) members of
(mathcal F_T).  For every one, a proper edge of (2) has load (0) or at
least (3); hence no member satisfies (1).

The example is not a Case-XII pole.  Its girth is (4), its complete BF
pair-type support has profile

\[
 15\ S\text{--}S,qquad21\ S\text{--}T,qquad12\ T\text{--}T,
\]

and it has no (A)-cover.  Therefore it proves precisely that common actual
perfect matchings, the four row equations, cubic vertex incidence, and
bridgelessness do not imply the five-PM residual-coverage condition.  A
Case-XII proof must additionally use the girth-five condition, the other
positive cells, or the absence of all (T)-loop/(T)--(T) covers.

The explicit matchings and exhaustive verification are frozen in
[`computations/bundles/failed-pivot-residual-selector-counterexample`](../computations/bundles/failed-pivot-residual-selector-counterexample/README.md).
The same order-thirteen synthesis with girth at least five returned
`unknown` at the fixed (300)-second solver limit; this is not evidence for
infeasibility and is not part of the theorem.
