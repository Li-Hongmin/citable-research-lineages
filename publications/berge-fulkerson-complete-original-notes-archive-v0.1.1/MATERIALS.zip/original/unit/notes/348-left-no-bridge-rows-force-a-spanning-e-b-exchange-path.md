> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Left no-bridge rows force a spanning \(e\)--\(b\) exchange path

> **Later exclusion:** [Note 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md) derives a forbidden \(T\)--\(T\) row from either left pattern below. The path classification is valid conditionally, but neither pattern occurs under complete exact-Case-XII support.

Assume the actual central-path, complete exact-Case-XII setting of [Notes 271 and 346](346-pure-phase-saturation-fixes-the-opposite-e-path-endpoint.md). By [Note 347](347-a-right-eb-row-forces-a-c-bridge-after-one-exterior-switch.md), a full closure with no \(e\to c\) bridge can have only left \(Y_L,U_A\) rows of type
\[
 X_{ea}+Y_L+F_e+U_A+G_e+W_b=2\mathbf1,                   \tag{1}
\]
where \(G_e\) is IV \(a:\Sigma,1A,3C\), and \(F_e\) is one of the two remaining orientation-I masks. Interchanging \(F,G\) between the two halves is allowed; the notation in (1) only fixes their exterior masks for the following path statements.

**Left exchange-path gate.** The full alternating \(e\)--\(b\) path of \(G_e\triangle W_b\) traverses the exterior \(I\)--\(D\) path in both cases below:

| \(F_e\) exterior | Forced \(W_b\) exterior, omitting its terminal \(b\) | Further path conclusion |
|---|---|---|
| I: \(a:C,4D\) | \(a:\Sigma,c:A,d:E,2B,3C,4D,h_1\) | The \(e\)--\(b\) path visits \(E,I,D,J\). |
| I: \(a:\Sigma,3C,4D\) | \(a:C,c:A,d:E,2B,4D,h_1,h_3\) | The \(e\)--\(b\) path visits **all six** \(E,A,I,D,H,J\) shore ports. |

In the first case, the two shore paths of \(G\triangle W\) pair \(E,I\mid D,J\) or \(E,D\mid I,J\); the third possible pairing \(E,J\mid I,D\) is forbidden. In the second case, both exterior paths \(A\)--\(H\) and \(I\)--\(D\) lie on the unique \(e\)--\(b\) component of \(G\triangle W\); every other component of this symmetric difference is wholly inside the shore. Equivalently, the three shore paths have one of the eight pairings obtained by placing the two exterior pairs \(A\)--\(H\), \(I\)--\(D\) in either order along one \(E\)-to-\(J\) chain.

**Proof.** The exterior \(W\)-masks in the table follow from the load-two equation at the four marked vertices, eight \(K\)-edges and six shore ports; no shore matching is assumed equal to another. For either row, \(G\triangle W\) contains the alternating exterior path
\[
 I\xrightarrow{h_1,1A,c:A,c:E,d:E,d:B,2B,h_2}D.       \tag{2}
\]
If the shore part of \(G\triangle W\) joined \(I\) directly to \(D\), (2) would be one complete closed alternating cycle. Switching \(G,W\) on that cycle would change \(G\)'s exterior mask to III \(a:\Sigma,2B,3C\), leaving all boundaries and every load unchanged. Now exchange the two **complete** singleton-\(e\) occurrences \(F,G'\) between halves. The new pure half is \(X+Y_L+G'\), while the opposite half still has state \(eb\). [Note 271's complete route table](271-the-central-path-row-requires-two-distinct-shore-masks.md) permits \(G'\)'s mask only with \(Y_R\), contradicting the required purity of the new left half under exact Case XII. Thus (2) must lie on the unique \(e\)--\(b\) path.

For \(F=\mathrm I:a:C,4D\), the only other exterior parts of \(G\triangle W\) are the terminal arm \(e\to E\) and the arm \(J\to b\) through \(h_4,4D,b:D,b\). Its shore XOR therefore has exactly the four open ports \(E,I,D,J\). Since (2) cannot close, it belongs to the \(e\)--\(b\) path, which necessarily uses all four. The asserted two pairings are the two ways to connect them without closing (2).

For \(F=\mathrm I:a:\Sigma,3C,4D\), \(G\triangle W\) additionally has the alternating exterior path
\[
 A\xrightarrow{a:\Sigma,a:C,3C,h_3}H.                   \tag{3}
\]
If (3) closed alone through the shore, switching it would change \(G\) to IV \(a:C,1A\), pure on neither side in Note 271. If (3) and (2) belonged to one closed cycle, switching that cycle would change \(G\) to III \(a:C,2B\), pure only on the right. In each case, exchanging the resulting complete singleton-\(e\) matching with \(F\) puts this forbidden mask in the pure half while retaining an opposite \(eb\)-state half. The unchanged \(Y_L\) then contradicts exact Case XII. The only other exterior pieces are \(e\to E\) and \(J\to b\), so a closed component containing (3) would have to contain either (3) alone or both (3) and (2). Neither is possible. Consequently (3), like (2), lies on the unique \(e\)--\(b\) path. That path must visit all six shore ports; no other exterior difference remains for a closed component. \(\square\)

There is a further closure choice in the first case. The exterior \(A\)--\(H\) path of \(F\triangle W\) uses \(a:\Sigma,a:C,3C,h_3\) with opposite colours to (3). If that path closes by itself through the shore, switching it changes \(F\)'s exterior from I \(a:C,4D\) to I \(a:\Sigma,3C,4D\), and simultaneously changes \(W\) to the second table mask. Thus the first case either generates the second case in the complete matching family or has its \(F\triangle W\) \(e\)--\(b\) path traverse \(E,A,H,D\). This does not assert that the second case occurs in every closure.

These are necessary full-path restrictions, not an exclusion of the left branch. The shore can have extra alternating cycles and arbitrary allowed rank; the actual existence of either complete exact-Case-XII row, and the owner/even-cycle third-identity gate of [Notes 345 and 349](349-pure-pentagon-load-makes-the-third-identity-parity-automatic.md), remain open. The route-table inputs of Note 271 still require independent proof review.
