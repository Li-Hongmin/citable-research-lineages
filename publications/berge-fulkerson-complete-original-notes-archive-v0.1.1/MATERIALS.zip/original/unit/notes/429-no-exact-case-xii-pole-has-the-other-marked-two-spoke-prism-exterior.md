> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No exact Case-XII pole has the other marked two-spoke prism exterior

Use the second marked two-spoke prism tree of [Notes 424](424-the-other-two-spoke-prism-excludes-the-ac-ab-forbidden-pair.md)–[428](428-the-other-two-spoke-prism-excludes-the-cc-bottom-ac-pair.md):
\[
(u_1,\ldots,u_5)=(AB,BC,Aa,Bb,bc),\qquad
(X,Y,Z,W)=(AC,Cc,ac,ab).
\]
The shore has ports \(e,p_1,\ldots,p_5\) and arbitrary size. The previous five notes exclude five forbidden \(e\)-pairs, conditional on their hand proofs. This note handles the last pair \(\{Y,W\}=\{Cc,ab\}\). Its two possible allowed Case-XII pentagons are
\[
S_1=e-X-Y-W-Z-e,\qquad S_2=e-X-W-Y-Z-e.                \tag{1}
\]
The [original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed cell \((eY)(eX)\) and excludes every double-\(T\) cell.

> **Exterior exclusion, conditional on Notes 424–428.** No cubic five-pole with this marked prism exterior and an arbitrary shore has complete exact Case-XII BF boundary support. In particular the required \((eY)(eX)\) cell cannot be realized under either pentagon in (1).

Suppose the required row exists. Let its forbidden triple be \(P=eY\), allowed triple \(R=eX\), singleton occurrences \(K=X,J=Y\), and two singleton-\(e\) occurrences \(D_0,D_1\). The \(X\)-starting path of \(R\triangle K\) must end at \(Z\), the only other allowed \(e\)-label; an ending at \(Y\) or \(W\) would leave unchanged \(P\in T\) beside another \(T\)-triple. This path is wholly exterior by the zero-port-triple argument in [Note 426](426-the-other-two-spoke-prism-excludes-the-bottom-edge-forbidden-pair.md). Switching it gives \(R'=eZ\) with the **same complete shore matching** as \(R\), while \(P,J,D_0,D_1\) remain unchanged.

The only possible exterior \(X\to Z\) paths, before checking the other four subdivisions in \(K\), are
\[
\begin{array}{c|l|l}
 &R\text{ root}&\text{path}\ \\ \hline
\alpha&A&X-t_X-A-u_3-a-t_Z-Z\\
\beta&A&X-t_X-A-u_1-B-u_4-b-u_5-c-t_Z-Z\\
\gamma&C&X-t_X-C-u_2-B-u_1-A-u_3-a-t_Z-Z.
\end{array}                                                \tag{2}
\]
The other route from \(X:C\) through \(B,u_4,b,u_5,c,Z:c\) occupies both \(C,c\) in \(K\), leaving neither endpoint for \(Y=Cc\). Other branches end at forbidden \(Y,W\).

For any unchanged singleton-\(e\) occurrence \(D\), the shore \(e\)-to-port path is the same against \(R,R'\). The allowed targets are
\[
\begin{array}{c|cc}
 &R=eX&R'=eZ\\ \hline
S_1&Y&W\\
S_2&W&Y
\end{array}.                                                \tag{3}
\]
Both triples use zero exterior ports, while \(D\) uses three. Two distinct marked terminal arms ending at ports leave no exterior port-to-port component, so their port exits must agree if (3) asks the same shore path to select them.

**A fixed \(Y\)-arm excludes route \(\alpha\).** The direct path forces
\[
K:X\text{ terminal},Z:a,W:b,Au_3,\quad
\begin{cases}Y:c,&P=eY:C,\\Y:C,&P=eY:c.\end{cases}        \tag{4}
\]
Indeed both roots of \(P\) use \(au_3\); in the \(C\)-root \(P,R\) also saturate \(cu_5\), and in the \(c\)-root they saturate \(Cu_2\). In either root case the \(Y,Z,W\) loads force at least one \(D_i:Y:c,Z:a,W:b\). Such a \(D\) covers both \(b,c\) at marks and therefore takes port \(p_5\). Both \(R=eX:A\) and \(R'=eZ:a\) take \(cu_5\), so the \(Y\)-terminal arm in each comparison is the same path \(Y-t_Y-c-u_5-p_5\). Equation (3) requires the fixed shore path to select \(Y\) once and \(W\) once. If the distinct \(W\)-arm does not reach a port, selecting it is already impossible; if it does, its port cannot be \(p_5\). Thus \(\alpha\) fails under both orientations.

**Route \(\beta\), root \(P=eY:C\).** This route forces \(K:X\) terminal, \(Y:C,Z:c,W:a\). Since \(P,K\) saturate \(Y:C\) and \(P,R\) saturate \(cu_5\), both \(D_i:Y:c,Z:a,W:b,p_5\); the unchanged \(J=Y\) takes \(Z:c\). Here \(R=eX:A\) and \(R'=eZ:c\), with \(R\) taking \(cu_5\) and \(R'\) taking \(bu_5\).

Under \(S_1\), switch the complete required \(e\to Y\) path of \(R\triangle D_i\) for either \(D_i\), obtaining \(H=XY\in S_1\). The path uses the exterior suffix \(Y-t_Y-c-u_5-p_5\), so \(H:Y:c\); it leaves \(H\)'s \(Z\) terminal unchanged. The unchanged singleton \(J=Y\) takes the \(Y\) terminal and \(Z:c\). Hence \(Y-t_Y-c-t_Z-Z\) is a wholly exterior path of \(H\triangle J\). Switching it gives \(XZ\in T_1\) beside unchanged \(P=eY\in T_1\), impossible.

Under \(S_2\), first consider a \(D_i:X:A\). Its \(R\triangle D_i\) \(W\)-arm exits at \(p_4\) or \(p_1\), while its \(R'\triangle D_i\) \(Y\)-arm exits at \(p_3\): at \(a\), \(D_i:Z:a\) and \(X:A\) force port \(p_3\). These exits cannot agree as (3) requires. Thus the unique \(X:A\) slot among \(J,D_0,D_1\) belongs to \(J\); both \(D_i:X:C\). Each \(D_i\) covers \(A\) by \(Au_3\). The \(S_2\) target exits for such a \(D_i\) are
\[
\begin{array}{c|ccc}
D_i\text{ at }B&Bu_1&Bu_2&Bu_4\\ \hline
W\text{ under }R&p_4&p_4&p_1\\
Y\text{ under }R'&p_4&p_1&p_1
\end{array}.                                                \tag{5}
\]
Thus neither \(D_i\) may take \(Bu_2\). But \(P,R,K\) use \(Bu_2,Bu_1,Bu_4\) once each, so one of \(J,D_0,D_1\) must take \(Bu_2\). This would be \(J\), impossible because \(J:X:A\) already forces \(J:Cu_2\) at \(C\). Hence \(S_2\) also fails.

**Route \(\beta\), root \(P=eY:c\).** Edge loads give a unique singleton-\(e\) occurrence \(D_A\) with
\[
D_A:X:A,Y:C,Z:a,W:b,cu_5,p_3,
\]
the other \(D_C:X:C,Y:c,Z:a,W:b,Au_3,p_5\), and unchanged \(J=Y\) takes \(X:C,Z:c,W:a,bu_4\). At \(B\), \(J,D_A,D_C\) use \(Bu_2,Bu_2,Bu_1\) in some order; \(Bu_4\) is saturated by \(P,K\).

Under \(S_1\), the \(W\)-arm of \(R'\triangle D_A\) exits at \(p_3\), whereas the \(Y\)-arm of \(R\triangle D_A\) exits at \(p_2\) if \(D_A:Bu_1\), or \(p_1\) if \(D_A:Bu_2\). This contradicts (3). Under \(S_2\), the \(W\)-arm of \(R\triangle D_A\) exits at \(p_4\); the \(Y\)-arm of \(R'\triangle D_A\) reaches \(p_4\) only if \(D_A:Bu_2\). Applying the same demand to \(D_C\) forces \(D_C:Bu_1\), leaving \(J:Bu_2\).

Now switch the complete \(e\to Y\) path of \(R'=eZ:c\) against \(D_A\). Its exterior suffix is \(Y-t_Y-C-u_2-B-u_4-p_4\), so the resulting allowed triple \(H=YZ\) takes \(Y:C\) and retains the \(X\) terminal. The unchanged \(J=Y\) takes \(X:C\) and the \(Y\) terminal. Thus \(Y-t_Y-C-t_X-X\) is a wholly exterior path of \(H\triangle J\). Switching it yields \(XZ\in T_2\) beside unchanged \(P=eY\in T_2\). Therefore route \(\beta\) is impossible.

**Route \(\gamma\).** Here \(K:X\) terminal, \(Y:c,Z:a,W:b\), with tree slots \(Cu_2,Bu_1,Au_3\). Switching gives \(R'=eZ:a\); both \(R=eX:C\) and \(R'\) take \(cu_5\). If \(P=eY:C\), the \(Y\)-edge loads again force an \(e\)-singleton \(D:Y:c,Z:a,W:b,p_5\). The same fixed \(Y-t_Y-c-u_5-p_5\) arm excludes both orientations by (3).

Finally let \(P=eY:c\). The loads at \(C,X,Y\) give \(J:X:C\) and \(D_0,D_1:X:A,Y:C,p_3\). Among \(J,D_0,D_1\), exactly one occurrence \(M\) takes \(Z:a,W:b,cu_5\); the other two take \(Z:c,W:a\). If \(M=D_i\), its demanded exits are:
\[
\begin{array}{c|ccc}
M\text{ at }B&Bu_1&Bu_2&Bu_4\\ \hline
(Y\text{ under }R,\ W\text{ under }R')&(p_2,p_4)&(p_1,p_4)&(p_1,p_1)\\
(W\text{ under }R,\ Y\text{ under }R')&(p_4,p_2)&(p_4,p_1)&(p_2,p_2)
\end{array}.                                                \tag{6}
\]
Thus either orientation requires \(M:Bu_4\). Every other \(e\)-singleton \(E:X:A,Y:C,Z:c,W:a\) has its \(W\)-arm under \(R\) fixed at \(p_3\), while its \(Y\)-arm under \(R'\) exits at \(p_1\) or \(p_2\); hence \(S_2\) is impossible. For \(S_1\), \(E\)'s \(Y\)-arm under \(R\) exits at \(p_2\) if \(E:Bu_1\) and at \(p_1\) otherwise. Its \(W\)-arm under \(R'\) exits at \(p_5\) if \(E:bu_4\), at \(p_4\) if \(E:bu_5\) and \(E\) does not take \(Bu_4\), and at \(p_1\) if \(E:bu_5,Bu_4\). Thus the required exits agree only with \(E:Bu_4,bu_5\). If \(M=J\), both \(D_i\) are such \(E\)'s; if \(M=D_i\), the other \(D\) is an \(E\) and \(M:Bu_4\) is also required. Either way \(P:Bu_4\) plus two singleton-\(e\) occurrences overload that edge. This excludes \(S_1\) and finishes \(\gamma\).

All roots and both pentagons for the last forbidden pair \(\{Cc,ab\}\) have been excluded. Combining this pair exclusion with Notes 424–428 conditionally excludes **all six forbidden \(e\)-pairs** for the specified second two-spoke-prism exterior, at arbitrary shore order and without girth, cycle-rank, or connectivity assumptions. It does not exclude other marked exteriors or prove Berge–Fulkerson. The full hand-derived chain awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
