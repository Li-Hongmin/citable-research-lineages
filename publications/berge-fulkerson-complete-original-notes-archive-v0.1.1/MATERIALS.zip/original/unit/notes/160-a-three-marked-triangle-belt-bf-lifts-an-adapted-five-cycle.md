> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A three-marked triangle belt BF-lifts an adapted five-cycle

The remaining cyclic marked component after [Notes 157--159](159-a-four-marked-square-belt-bf-lifts-an-adapted-five-cycle.md) is a marked triangle. It too is excluded in a minimum-host exact-Case-XII pole. The argument constructs an eleven-vertex belt and an adapted five-cycle whose **entire six-matching boundary relation lifts**, for every placement of the other two cut edges on the opposite pentagon. This is an analytic proof awaiting independent checking. It reduces the marked-edge subgraph to a disjoint union of paths; it does not resolve the path configurations or the common \(B_2+C_4\) seed.

## The five-port triangle belt

Index the marked triangle edges \(v_it_iv_{i+1}\) modulo 3. Their subdivision vertices attach by spokes to three distinct vertices \(r_{\pi(i)}\) of the opposite 5-cycle. Call the other two outer vertices \(x,y\). The belt \(B\) on the three \(v_i\), three \(t_i\), and five outer vertices has exterior semiedges \(h_i\) at \(v_i\), and \(h_x,h_y\) at \(x,y\). We show that some ordinary 5-cycle \(Q\) on these five port positions has every labelled BF boundary colouring lift to \(B\).

The published BF boundary relation of a five-cycle consists of all loops and pairs on its five adjacent-pair Tait states, and the all-terminal type. As in Notes 158--159, it is enough to make the five edges of one Hamilton cycle in the **Tait-state support graph** of \(B\) and construct one all-terminal BF colouring. Pairing or doubling three-edge-colourings then supplies all fifteen pair and loop types; a six-slot permutation matches each literal boundary label assignment.

## Inner-pair and cross-pair Tait colourings

Write \(b_i=\operatorname{col}(v_it_{i-1})\), \(a_i=\operatorname{col}(v_it_i)\), and \(c_i=\operatorname{col}(t_ir_{\pi(i)})\). For the inner pair \(\{v_0,v_1\}\), prescribe \(A,B,C\) at \(h_0,h_1,h_2\), and \(C,C\) at \(h_x,h_y\). Each row below satisfies all three-colour vertex incidences on the inner six-cycle:

| \((c_0,c_1,c_2)\) | \((b_0,a_0)\) | \((b_1,a_1)\) | \((b_2,a_2)\) |
|---|---|---|---|
| \((A,C,B)\) | \((C,B)\) | \((C,A)\) | \((B,A)\) |
| \((C,A,B)\) | \((C,B)\) | \((A,C)\) | \((B,A)\) |
| \((B,A,C)\) | \((B,C)\) | \((A,C)\) | \((B,A)\) |

The lonely spoke colours therefore occupy any desired pair among the three spoke vertices. Every three vertices of an outer 5-cycle contain an adjacent pair. Choose the corresponding row and extend over the outer cycle. Rotating inner indices shows that **all three pairs among \(v_0,v_1,v_2\)** are Tait states of \(B\), regardless of where \(x,y\) lie.

For a cross pair \(\{v_0,x\}\), prescribe \(A\) at \(h_0\), \(B\) at \(h_x\), and \(C\) at the other three ports. These two rows give the spoke colours:

| \((c_0,c_1,c_2)\) | \((b_0,a_0)\) | \((b_1,a_1)=(b_2,a_2)\) |
|---|---|---|
| \((A,C,C)\) | \((B,C)\) | \((B,A)\) |
| \((C,C,A)\) | \((C,B)\) | \((A,B)\) |

Consequently \(\{v_0,x\}\) is a Tait state whenever \(x\) is adjacent on the outer 5-cycle to the spoke at \(t_0\) or \(t_2\). By rotation, \(\{v_i,x\}\) is supported whenever an outer neighbour of \(x\) corresponds to one of the two marked triangle edges incident with \(v_i\). The same holds with \(y\) in place of \(x\). The outer extension uses the cyclic edge colours \(C,A,B,A,B\) for consecutive dangling colours \(A,B,C,C,C\).

Finally, if \(x,y\) are adjacent on the outer 5-cycle, \(\{x,y\}\) is a Tait state: give every inner port colour \(C\), every forward inner edge colour \(A\), every backward inner edge colour \(B\), and every spoke colour \(C\). Prescribe \(A,B\) at \(h_x,h_y\) and extend over the outer 5-cycle.

These states contain a Hamilton cycle on the five port positions. If \(x,y\) are nonadjacent on the outer 5-cycle, each has two distinct spoke neighbours. Any two edges of the inner triangle meet all three inner vertices, so both \(x\) and \(y\) have cross-pair Tait states with **all three** \(v_i\); for example \(x,v_0,y,v_1,v_2,x\) is a supported 5-cycle. If \(x,y\) are adjacent, each has one spoke neighbour and hence cross states with the two endpoints of that marked triangle edge. Their spoke neighbours are distinct. Choose distinct inner vertices \(v_i,v_j\) supported by \(x,y\), and let \(v_k\) be the remaining vertex. Then \(x,y,v_j,v_k,v_i,x\) is a supported 5-cycle. Use either supported cycle as the port order of \(Q\).

## All-terminal BF colouring

Let \(W\) use all five exterior semiedges and all three spokes. Let \(N_x\) use \(h_x\), all three forward inner edges \(v_it_i\), and the unique matching of the outer 5-cycle after deleting \(x\). Let \(N_y\) use \(h_y\), all three backward inner edges \(v_it_{i-1}\), and the unique outer matching after deleting \(y\). Let \(N_0\) use
\[
h_0,\quad v_1t_0,\ v_2t_2,\quad t_1r_{\pi(1)},           \tag{1}
\]
and the unique outer matching after deleting \(r_{\pi(1)}\). Define \(N_1,N_2\) by rotating the inner indices in (1), with their outer matchings deleting the corresponding spoke vertices.

Each \(N\) is a perfect matching of the five-pole with the named singleton boundary. The six matchings \(W,N_x,N_y,N_0,N_1,N_2\) cover each exterior semiedge by \(W\) and its singleton matching, each spoke by \(W\) and one inner-singleton matching, each forward half-edge by \(N_x\) and one rotated inner-singleton matching, and each backward half-edge by \(N_y\) and one rotated inner-singleton matching. The five singleton matchings delete each outer vertex once, so each outer 5-cycle edge occurs exactly twice. This gives the all-terminal BF type and completes the full labelled lifting of \(Q\) through \(B\).

## Consequence for a minimum counterexample

Suppose the five marked edges in the core \(J\) of a genuine minimum-host Case XII contain a triangle. Note 157 gives marked maximum degree two, so the other two marked edges lie outside it. Its three vertices each have one unmarked core edge to the rest; simplicity leaves no internal chord. The corresponding part of the full graph is precisely the eleven-vertex belt \(B\) above, with exterior edges at \(v_0,v_1,v_2,x,y\). Replace \(B\) by the adapted five-cycle \(Q\), keeping those five exterior edges. The new cubic graph has six fewer vertices and is bridgeless because both gadgets connect all five ports, and deleting an internal edge of \(Q\) leaves it connected.

By minimality the smaller graph has a BF cover. Lift its six labelled boundary matchings through \(B\) and glue them to the unchanged exterior matchings, producing a BF cover of the original graph. This contradicts the assumed minimum counterexample. Therefore
\[
\boxed{\text{The marked-edge subgraph of a minimum-host exact-Case-XII core is a forest of paths.}} \tag{2}
\]
The exclusion of 3-cycles here, 4-cycles in Note 159, and 5-cycles in Note 158 uses minimum-host BF lifting. It does not assert that an arbitrary exact-support five-pole, detached from a minimum whole graph, has no marked cycle.
