> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Zero-port hexagon closure excludes the A-v0 J placement

> **Subsequent refinement:** [Note 315](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md)
> excludes the three other positions left below, hence the entire
> three-vertex \((2,1)\) six-cut allocation. The theorem below is
> unchanged.

Continue the genuine left \((ea)(ac)\) and right \((ea)(ad)\) rows in
the noncollision, complete exact-Case-XII \(R_0=DJ\) near-bipartite
branch of [Notes 312–313](313-the-first-six-cut-hall-cycle-restricts-the-j-port.md).
Use [Note 313's](313-the-first-six-cut-hall-cycle-restricts-the-j-port.md)
first surviving three-vertex Hall cycle
\[
                 h-u-k-z-\ell-v_0-h,                       \tag{1}
\]
where \(h\) carries \(H\), \(k\) carries \(A\), \(\ell d\)
leaves the cycle, and \(j=v_0\) carries \(J\). The edge \(g\)
and the marked vertex \(t_e\) lie outside this cycle.

**Theorem.** The placement \((P,j)=(A,v_0)\) cannot occur in a
complete exact-Case-XII pole under these hypotheses. In particular,
of Note 313's four listed \(J\)-port placements, only
\((A,z),(I,u),(I,z)\) remain unexcluded by this chain.

**Proof.** In the right row write \((X,Y,Z,U,V,W)\), with proper
shore ports \((\varnothing,ID,EAHJ,EJ,ID,AH)\). The matching
\(U\) selects \(J\), so on the Hall cycle and its \(d\)-edge it
uses \(hu,kz,\ell d\). Each of \(Y,V\) selects \(D\) and none
of \(H,A,J\), so its edges on the six-cycle are one of the two
alternating perfect matchings
\[
 M_0=\{hu,kz,\ell v_0\},\qquad
 M_1=\{hv_0,ku,\ell z\}.                                \tag{2}
\]
Both cannot use \(M_0\), since \(hu\) and \(kz\) would then
have row load three with \(U\).

If both use \(M_1\), the \(H,A\) ports are already loaded twice
by \(Z,W\). Edge load two at \(h,k\) therefore makes the right
zero-port matching \(X\) use \(hu,kz\). At \(v_0\), port \(J\)
is used by \(U,Z\), the edge \(hv_0\) by \(Y,V\), and hence
\(\ell v_0\) by \(X,W\). Thus \(X\) uses the full cycle
matching \(M_0\).

If \(Y,V\) use different matchings in (2), the same load count at
\(h,k\) makes \(X\) use \(hv_0,ku\). The remaining vertex
\(\ell\) is matched by \(X\) either to \(d\) or to \(z\), so
its local edges are respectively
\[
               \{hv_0,ku,\ell d\}
       \quad\text{or}\quad M_1.                            \tag{3}
\]
These are all right-row possibilities. Note 297 fixes \(X\) as
an actual zero-proper-port shore matching selecting \(g,t_{ew}\).

If \(X\) uses the first set in (3), then its shore complement has
the **complete local proper-port path**
\[
                         A-k-z-\ell-v_0-J.                 \tag{4}
\]
If \(X\) uses \(M_1\), it does not select \(\ell d\). Since it
also does not select proper port \(D\), the base \(d\) is matched
by its third edge. Its shore complement consequently has the
complete path
\[
                         J-v_0-\ell-d-D.                   \tag{5}
\]
Finally, if \(X\) uses \(M_0\), the entire six-cycle (1) is an
alternating cycle for \(X\). Switch it to obtain another **actual**
zero-port shore perfect matching \(X'\), identical to \(X\)
outside the cycle and using \(M_1\) on it. In particular \(X'\)
still selects \(g,t_{ew}\), while \(d\) retains its outside
matching edge. Thus its complement has (5).

[Note 285, equation (1)](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
gives two actual forbidden-\(eb\) exterior completions for *every*
zero-port \((g,t_{ew})\) matching. In the first, \(P_0\), the
exterior complement joins \(I\)--\(D\) and has a terminal arm at
\(J\); in the second, \(P_1\), it joins \(A\)--\(D\) and
\(H\)--\(J\). The two unselected same-side cut edges \(D,J\)
must lie in different components under both completions, or every
closed complement cycle is even and the triple extends to a
forbidden \(eb\)-Tait state. But shore path (5) directly joins
\(D,J\) under \(P_0\), while shore path (4) joins the exterior
\(AD\) and \(HJ\) paths into one component under \(P_1\).
Equivalently, [Note 285, equation (2)](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
allows only the shore-complement pairings
\[
              EA\mid ID\mid HJ
       \quad\text{or}\quad EJ\mid AD\mid IH.               \tag{6}
\]
Neither permits an \(AJ\) component as in (4) nor a \(JD\)
component as in (5). All possibilities contradict complete exact
support, proving the theorem. \(\square\)

The switch in the third case uses the whole graph-induced perfect
matching fibre, not a selected-row identity or an abstract shore
signature. It also does not assume that the two right singleton
occurrences are identical as complete matchings. Three three-vertex
placements, larger six-cut Hall blocks, the other cut allocations,
incidence collisions, other core profiles, and Berge–Fulkerson remain
open. The proof is hand-derived and depends on the two actual
forbidden-\(eb\) exterior masks; no local recomputation or OMEN run
was used.
