> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The tree--R-star adjacent-special-port case is impossible

Let the minimum-host \(|U|=1\) two-five-cut profile have a three-vertex tree shore \(A^\circ\) with centre port \(0\) and end groups \(\{\delta,x\}\mid\{y,z\}\), opposite a Case-XIII \(R^*\) shore \(B^\circ\). [Notes 185](185-the-centered-tree-rstar-path-forces-a-forbidden-bf-pair.md) and [186](186-the-opposite-end-centered-tree-rstar-path-is-impossible.md) exclude the two placements where \(\delta,\epsilon\) are adjacent in the forbidden Case-XII pentagon \(T\) and either \(x\) is the centre of the shared \(T\)-path or \(x\) is its endpoint attached to \(\epsilon\). The remaining placement, up to swapping the two ports \(y,z\), is
\[
\boxed{T=\delta-\epsilon-z-y-x-\delta.}                 \tag{1}
\]
Here \(y\) is the centre of the shared path and \(x\) attaches to \(\delta\). It too is impossible. Consequently
\[
\boxed{\text{tree--\(R^*\) in this \(|U|=1\) profile}
\quad\Longrightarrow\quad \delta\epsilon\notin T.}     \tag{2}
\]
This is a necessary condition under exact Case XII, not an existence claim for the nonadjacent case.

Write \(c(p)\in\{P,Q\}\) for the Figure-7 block of an \(R^*\) missing-pair state. As \(xy,yz\in T\), the fixed shared-pair transport in [Note 184](184-a-fixed-shared-tait-pair-transports-three-rstar-pairs.md) applied to the tree state \(xy\) gives
\[
c(xy)=c(xz).                                            \tag{3}
\]
The genuine six-slot row in [Note 186](186-the-opposite-end-centered-tree-rstar-path-is-impossible.md) sends the \(B^\circ\) type \((yz)(z\epsilon)\) to the outer type \((yz)(\delta\epsilon)\). Both outer states are in \(T\) of (1), so exact Case XII requires
\[
c(yz)=c(z\epsilon).                                    \tag{4}
\]
These transport statements are independent of the particular \(T\)-orientation used in their source notes; here only the \(T\)-membership of their outputs is re-evaluated.

Two more actual pair rows give the remaining equalities. Fix the tree's real Tait state \(xz\) with port macrocolours \((0,x,y,z,\delta)=(1,3,1,2,1)\). Its doubled BF row has boundary \(\{0,y,\delta\}\) in slots \(1,2\), singleton \(z\) in slots \(3,4\), and singleton \(x\) in slots \(5,6\). The following choices use an actual \(B^\circ\) BF row of the stated type and list its boundary subsets in slots \(1,\ldots,6\).

| \(B^\circ\) type | \(B^\circ\) slot boundaries | \(uw;\ D_\delta;\ D_\epsilon\) | outer triple slots and missing pairs |
|---|---|---|---|
| \((yz)(x\epsilon)\) | \(z,x,\epsilon,\{0,x,\epsilon\},y,\{0,y,z\}\) | \(\{3,5\};\{4,6\};\{1,2\}\) | \(3:z\epsilon,\ 5:xy\) |
| \((xy)(z\epsilon)\) | \(z,x,\epsilon,\{0,x,y\},y,\{0,z,\epsilon\}\) | \(\{3,5\};\{4,6\};\{1,2\}\) | \(3:z\epsilon,\ 5:xy\) |

In both rows the \(A^\circ\) and \(B^\circ\) labels at \(0,x,y,z\) are disjoint. They have \(X_\delta=\{1,2\}\) and \(Y_\epsilon\subseteq\{3,4,5,6\}\), so [Note 172's](172-one-vertex-two-shore-connector-has-one-overlap-gate.md) overlap gate holds. The displayed connector labels partition all six slots at \(w\) and avoid the corresponding shore halves at \(t_\delta,t_\epsilon\). Filling the five terminal labels gives actual perfect matchings with edge load two; in both lines the outer BF type is
\[
(xy)(z\epsilon).                                       \tag{5}
\]
Both missing-pair states in (5) are edges of \(T\) in (1). Thus neither \(B^\circ\) type in the table may be supported. Since \(R^*\) contains every cross-block type, this requires
\[
c(yz)=c(x\epsilon),\qquad c(xy)=c(z\epsilon).           \tag{6}
\]

Equations (3), (4), and (6) give
\[
c(xy)=c(xz)=c(yz)=c(x\epsilon)=c(z\epsilon).            \tag{7}
\]
The first three states are a monochromatic triangle on the shared ports. The Figure-7 \(R^*\) block \(P=\{13,14,24,35,45\}\) has no triangle, and \(Q=\{12,15,23,25,34\}\) has the unique triangle on \(\{1,2,5\}\). Therefore the shared ports are \(\{1,2,5\}\), the special \(B^\circ\) ports \(0,\epsilon\) are \(\{3,4\}\), and the common block in (7) is \(Q\). Only one of the six triangle-to-special edges belongs to \(Q\), namely \(23\). Distinct edges \(x\epsilon,z\epsilon\) cannot both belong to \(Q\). This contradicts (7) and proves (2). \(\square\)

The nonadjacent-\(\delta\epsilon\) tree--\(R^*\) case, pentagon--\(R^*\), \(L^*\)--\(R^*\), and \(R^*\)--\(R^*\) still require the complete connector relation. No local computation or selected-row inference enters the adjacent-case exclusion.
