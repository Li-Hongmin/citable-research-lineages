> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Forbidden triples restrict one-edge-near-bipartite central shores

Continue the actual central-path exterior of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), with allowed pentagon
\(S=e-a-b-d-c-e\), forbidden pentagon
\(T=\{eb,ed,ac,ad,bc\}\), and the shore notation
\(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\).
Write \(\mathcal H\) for the full five-pole.
The published [Case-XII table](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Appendix XII, supplies both required rows; throughout, *exact support* also excludes the \(T\)-loops.

Suppose the six-port shore becomes bipartite after deletion of one internal edge \(g\), and both required rows have the forced pure pairing \(EI\mid AD\). Name the side containing both ends of \(g\) by \(B\). [Note 278](278-one-edge-near-bipartite-central-shores-have-a-fixed-slot-profile.md) leaves two slot profiles: the balanced profile \(X(g)=0,Z(g)=1\), or the unbalanced profile \(X(g)=1,Z(g)=0\). Here \(X\) is a zero-port shore matching and \(Z\) is the four-port shore matching.

**Theorem.** Complete exact-Case-XII support excludes the entire unbalanced profile. In the balanced profile the unique \(B\)-side port among \(E,A,I,D\) cannot be \(I\). If it is \(A\), then \(H\in B,J\notin B\); if it is \(D\), then \(J\in B,H\notin B\). Thus the only port-side placements not excluded by these arguments are
\[
\begin{array}{c|c}
B\cap\{E,A,I,D\}&B\cap\{H,J\}\\\hline
\{E\}&\{H\}\text{ or }\{J\}\\
\{A\}&\{H\}\\
\{D\}&\{J\}.
\end{array}                                                     \tag{1}
\]
This is a necessary placement classification, not an existence assertion or a proof of four-slot load intersection.

## A zero-port \(eb\) triple excludes the unbalanced profile

Note 278 first reduces \(X(g)=1\) to the placement in which \(I\) is the unique minority-side port among \(E,A,I,D\), while \(H,J\in B\). In that placement the *whole five-pole* minus \(\{g,h_1\}\) is bipartite; \(g\) and the proper cut edge \(h_1\) lie inside opposite sides.

Take **any** actual zero-port shore matching \(X\); one exists in either required row and, by Note 278's balance equation, every such \(X\) uses \(g\). The central-path exterior has the following ordinary matching, independent of \(X\): select the terminal semiedges \(a,c,d\), the half-edge \(b:D_{\rm ext}\), and the four path edges
\[
1A_{\rm ext},\quad 2B_{\rm ext},\quad
3C_{\rm ext},\quad 4E_{\rm ext}.                         \tag{2}
\]
All thirteen exterior vertices are covered exactly once. Since (2) uses no shore cut edge, gluing it to \(X\) gives a **complete actual perfect matching** \(Q_{eb}\) of the five-pole, with missing terminal pair \(eb\in T\). This uses graph-induced matching closure; \(Q_{eb}\) need not be one of the six occurrences in a previously chosen BF row.

In the complement of \(Q_{eb}\), the unused terminal semiedge \(b\) has the exterior path
\[
b-t_b-A_{\rm ext}-t_c-E_{\rm ext}-t_d-B_{\rm ext}-u_1-h_1.  \tag{3}
\]
Its final edge is the proper cut edge \(h_1\). The complement has exactly one terminal path, from \(b\) to \(e\), so \(h_1\) lies on that path. Also \(g\in Q_{eb}\). Every closed component of the complement therefore avoids **both** edges whose deletion makes the whole pole bipartite. All its closed cycles are even. The triple-complement parity lemma of [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md) alternately colours the complement and extends \(Q_{eb}\) to a Tait colouring with forbidden state \(eb\). Doubling it gives a forbidden \([eb]\) BF loop. This contradiction removes the last placement of the unbalanced profile and hence the entire profile. \(\square\)

## The balanced minority-\(I\) placement is impossible

Now \(X(g)=0\). Note 278 gives \(|B|=|R|\), exactly one \(B\)-side port among \(E,A,I,D\), and opposite sides for \(H,J\). All five exterior endpoints of the proper shore interfaces lie on one bipartition side of the central-path exterior; colour that side \(B\). Every proper shore interface based at a \(B\)-side port is then an exceptional \(B\)--\(B\) edge, while the other interfaces cross sides.

Suppose \(I\in B\), and let \(f\) be whichever of \(H,J\) also lies in \(B\). The whole pole minus \(\{g,h_1,f\}\) is bipartite, with these three edges internal to \(B\). For both required triples \(U_{ad}\) and \(U_{ac}\), the two shore ports are respectively \(ED\) and \(EA\), both on the other side; Note 278's balance equation forces **both** triples to use \(g\). They avoid \(h_1,f\).

The forced exterior masks give the following paths in the corresponding triple complements:
\[
\mathcal H-U_{ad}:\quad
h_1-u_1-B_{\rm ext}-u_2-C_{\rm ext}-u_3-h_3,
\qquad
\mathcal H-U_{ac}:\quad
h_1-u_1-B_{\rm ext}-t_d-E_{\rm ext}-u_4-h_4.       \tag{4}
\]
These are exterior paths, including the two indicated shore cut edges. If \(f=h_3\), then the two exceptional edges left in \(\mathcal H-U_{ad}\), namely \(h_1,f\), belong to the **same** component by (4). Every closed cycle of that complement contains zero or two exceptional \(B\)--\(B\) edges and is even, so \(U_{ad}\) extends to the forbidden \(ad\) Tait state. If \(f=h_4\), the same argument with \(U_{ac}\) yields the forbidden \(ac\) Tait state. Both choices contradict exact support. \(\square\)

For completeness, the same exterior paths sharpen the other two placements in (1). If \(A\in B\) and \(J\in B\), the required \(U_{ad}\) uses \(g\), while its complement contains the two exceptional cut edges \(A,J\). The exterior complement connects \(A\) to unused terminal \(a\) and \(J\) to unused terminal \(d\); the two edges therefore lie on its single terminal path. All closed cycles are even, giving forbidden \(ad\). Hence \(A\in B\) requires \(H\in B\). Similarly, if \(D\in B\) and \(H\in B\), the complement of \(U_{ac}\) connects \(D\) to unused terminal \(a\) and \(H\) to unused terminal \(c\), producing forbidden \(ac\); hence \(D\in B\) requires \(J\in B\).

The proof uses only actual perfect matchings, the forced exterior masks, and the negative \(T\)-loop support. It does not rule out the four placements in (1), nor six-port shores whose **unmarked** core becomes bipartite after deleting \(g\) while the marked subdivision does not. The exterior path traces and their upstream forced-row tables are hand-derived and await independent checking.
