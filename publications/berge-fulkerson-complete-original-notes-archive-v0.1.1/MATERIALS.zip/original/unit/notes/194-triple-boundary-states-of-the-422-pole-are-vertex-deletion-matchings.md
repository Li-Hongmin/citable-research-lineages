> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Triple-boundary states of the (4,2,2) pole are vertex-deletion matchings

Use the genuine \((4,2,2)\) marked-core quotient of [Notes 166](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) and [175](175-the-422-exterior-connector-excludes-only-the-all-terminal-type.md). Its unmarked graph \(F=J-M\) has an odd component \(C\) whose marked-core shore \(J[C]\) contains a cycle, singleton components \(w_1,w_2\), and the barrier vertex \(u\). The graph \(F[C]\) itself may be a tree. The three unmarked edges at \(u\) go to \(C,w_1,w_2\); name the endpoint in \(C\) of the first edge \(v_h\). The four crossing marked edges are \(a,b\) between \(C,w_1\) and \(c,d\) between \(C,w_2\), while the fifth mark \(e\) has both endpoints in \(C\). This note classifies **single perfect matchings with triple terminal boundary** in the opened five-pole. It does not classify six-matching BF rows.

Let \(F_C=F[C]\). For \(i\in\{a,b,c,d\}\), let \(v_i\) be the endpoint in \(C\) of marked edge \(i\), and let \(v_e^-,v_e^+\) be the two endpoints of \(e\). Endpoints of different marks are allowed to coincide; the statements below use only one selected \(C\)-endpoint at a time. Define Boolean deletion-matching indicators
\[
H=\mathbf1\{F_C-v_h\text{ has a perfect matching}\},\quad
E=\max_{v\in\{v_e^-,v_e^+\}}\mathbf1\{F_C-v\text{ has a perfect matching}\},
\quad I_i=\mathbf1\{F_C-v_i\text{ has a perfect matching}\}.
\tag{1}
\]
Here a terminal *state* \(ij\) means that a perfect matching uses the three terminal semiedges other than \(i,j\). The complete triple-state support is exactly
\[
\boxed{\begin{array}{rcl}
ej\text{ occurs }(j\in\{a,b,c,d\})&\Longleftrightarrow&E=1,\\
ab\text{ occurs}&\Longleftrightarrow&I_a\lor I_b,\\
cd\text{ occurs}&\Longleftrightarrow&I_c\lor I_d,\\
ij\text{ occurs }(i\in\{a,b\},\ j\in\{c,d\})
&\Longleftrightarrow&H\lor I_i\lor I_j.
\end{array}}                                                   \tag{2}
\]

**Proof.** By [Note 157's core matching bijection](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md), a triple matching selects one endpoint through each of the two marked halves indexed by its missing pair; all other marked subdivision vertices use their terminal semiedges. The residual vertices must be matched by \(F\). Since \(w_1,w_2\) are singletons and \(u\) has just one matching edge, the exterior choices are forced up to the alternatives below.

If the missing pair is \(ej\), the \(e\)-half selects one endpoint \(v\in\{v_e^-,v_e^+\}\) in \(C\). The \(j\)-half must select the singleton \(w_k\) at its fork; otherwise that singleton and the opposite singleton could not both be matched by \(u\). Then \(u\) matches the *other* singleton, the edge \(uv_h\) is unused, and the residual matching inside \(C\) is precisely a perfect matching of \(F_C-v\). Any such deletion matching conversely extends through those forced exterior edges. This proves the first line of (2), independently of which fork contains \(j\).

If the missing pair is \(ab\), the singleton \(w_2\) has no selected marked half-edge and must match \(u\). Exactly one of \(a,b\) selects \(w_1\); the other selects its endpoint \(v_a\) or \(v_b\) in \(C\). The residual \(C\)-matching is therefore a perfect matching after deleting that endpoint. Conversely either deletion matching supplies the indicated choices at \(t_a,t_b,w_1,w_2,u\). The argument for \(cd\) swaps the forks.

Finally let the missing marks \(i,j\) lie at opposite forks. Either their halves select both singletons and \(u\) matches \(v_h\), leaving \(F_C-v_h\); or the \(i\)-half selects \(v_i\in C\), the \(j\)-half selects its singleton, and \(u\) matches the other singleton; or the roles of \(i,j\) reverse. These are the only possibilities because one vertex \(u\) cannot match two unmatched singletons. Each of the three deletion matchings conversely gives a valid pole perfect matching of state \(ij\). This proves the last line and (2). \(\square\)

Every one of the ten missing-pair states occurs in some actual BF type under complete exact Case XII, so all ten triple states occur as single perfect matchings. Formula (2) then gives the sharp **matching-level** requirement
\[
\boxed{E\ \land\ (I_a\lor I_b)\ \land\ (I_c\lor I_d)\ \land\
\bigl(H\lor(I_a\land I_b)\lor(I_c\land I_d)\bigr).}       \tag{3}
\]
Indeed, if \(H=0\), the four opposite-fork clauses \(I_i\lor I_j\) hold exactly when **one entire fork** has both its \(C\)-endpoints exposable. The other fork must still have at least one exposable endpoint by the \(ab,cd\) clauses. Conversely (3) supplies all ten triple states by the explicit constructions above.

Thus full triple-state support alone does **not** logically force \(F_C-v_h\) to have a perfect matching; its exact alternative is a fully exposable fork. To infer the all-terminal matching of [Note 177, (7)](177-tree-five-cut-bf-disjointness-locks-opposite-tait-triangles.md), an exact-Case-XII proof must additionally exclude that alternative or use a six-row/full-closure constraint. Formula (3) is not an existence claim for an exact-Case-XII pole, nor a BF-row support criterion: the six matching masks still must load every edge twice in one common row.
