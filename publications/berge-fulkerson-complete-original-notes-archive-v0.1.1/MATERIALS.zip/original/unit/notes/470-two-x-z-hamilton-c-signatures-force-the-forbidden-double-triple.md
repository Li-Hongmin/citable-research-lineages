> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two \(X,Z\)-forbidden Hamilton \(C\) signatures force a forbidden double triple

Use the marked Hamilton exterior, colour names and necessary signatures of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). Suppose a genuine \((eX)(eY)\) BF row has signature \(C_1\) or \(C_2\). Both have \(P=eX\) rooted at \(X:1\), \(R=eY\) rooted at \(Y:5\), and the singleton \(K=Y\) on \(X:1,Z:2,W:6,3u_2,5u_5,p_1\). Its remaining tree half and port are \((4u_3,p_4)\) in \(C_1\) and \((4u_4,p_3)\) in \(C_2\). The shore is arbitrary. We show that **both signatures, in every labelled port phase, force the forbidden \((eX)(eZ)\) type while each of the six complete shore matching restrictions is kept separately unchanged**.

Put \(S=\{J,a,b\}\). At \(X\), the old terminal and the two marked halves are \((RJ,PK,ab)\). Write the old \(Y:5\) pair as \(R\lambda\). Since \(K\) uses \(p_1\), the old pairs at \(u_1\), in first-half/second-half/port order, are
\[
                 u_1=(R\lambda,P\beta,K\alpha),
                 \qquad \{\lambda,\beta,\alpha\}=S.       \tag{1}
\]
The common \(K\)-half at \(3u_2\) gives
\[
                 u_2=(R\gamma,PK,S\setminus\{\gamma\}).   \tag{2}
\]
Write \(Z:2=K\rho\). Original vertex \(2\) then gives
\[
                         \{\beta,\gamma,\rho\}=S.          \tag{3}
\]
Since \(Z\) and \(W\) have old terminal pair \(PR\), the pairs at \(Z:6,W:6,W:3\) are respectively \(S\setminus\{\rho\},K\rho,S\setminus\{\rho\}\). Original vertex \(3\), with \(u_2:3=PK\), consequently has \(u_3:3=R\rho\).

Both signatures also have \(K\) on \(5u_5\), so, for some \(\delta\in S\),
\[
                 u_5=(K\delta,PR,S\setminus\{\delta\}).   \tag{4}
\]
At original vertex \(5\), the old half \(u_4:5\) contains \(P\), because the \(P\)-triple roots at \(X:1\); it contains neither \(R\) nor \(K\) in either signature. Write it \(P\theta\). The old \(Y:5=R\lambda\) and \(u_5:5=K\delta\) yield
\[
                         \{\theta,\lambda,\delta\}=S.      \tag{5}
\]
Equations (1)--(5) follow from the old genuine row alone. In particular, they impose no choice of the old pairs elsewhere on \(u_3,u_4\); leave those pairs unchanged in the following recompletion.

Replace the old exterior pairs by
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
& (R\lambda,P\beta,K\alpha)
& (RK,P\gamma,S\setminus\{\gamma\})
& \text{old pairs}
& \text{old pairs}
& (R\delta,PK,S\setminus\{\delta\}).
\end{array}                                                 \tag{6}
\]
At the marked subdivisions, list terminal, first half, second half in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\):
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,PK,ab)&(PR,S\setminus\{\lambda\},K\lambda)
&(PK,S\setminus\{\beta\},R\beta)
&(PR,K\beta,S\setminus\{\beta\}).
\end{array}                                                 \tag{7}
\]
Every new marked and tree-subdivision triple partitions \(\{P,R,K,J,a,b\}\). At original vertices \(1,\ldots,6\), the incident pairs are
\[
\begin{array}{c|cccccc}
&1&2&3&4&5&6\\ \hline
&(PK,R\lambda,S\setminus\{\lambda\})
&(P\beta,RK,S\setminus\{\beta\})
&(P\gamma,R\rho,K\beta)
&\text{old pairs}
&(P\theta,K\lambda,R\delta)
&(PK,R\beta,S\setminus\{\beta\}).
\end{array}                                                 \tag{8}
\]
The vertex-3 and vertex-5 partitions use (3) and (5); the others are immediate or inherited unchanged. The \(p_1,\ldots,p_5\) pairs in (6) equal their old pairs, and \(e=ab\) is unchanged. Thus the new exterior glues to the **same six complete shore matchings**, each exactly once, for an arbitrary actual shore. The terminal pairs are
\[
                e=ab,\qquad X=RJ,\qquad Z=PK,\qquad Y=W=PR, \tag{9}
\]
the forbidden \((eX)(eZ)\) type under either Case-XII pentagon orientation of Note 466. Therefore a genuine exact-Case-XII pole with this fixed marked exterior has neither \(C_1\) nor \(C_2\) as its required \((eX)(eY)\) row. With [Notes 467--469](469-the-x-z-hamilton-b3-row-also-forces-forbidden-full-support.md), only \(C_3,\ldots,C_7\) remain among the twelve signatures of Note 466. The path reflection gives the corresponding exclusions for forbidden \(\{eY,eW\}\).

This is a conditional hand proof for the fixed marked exterior, pending independent review. It does not resolve the other five signatures, the other marked exteriors, exact Case XII in general, or the Berge--Fulkerson conjecture. No OMEN or local mathematical recomputation was used. \(\square\)
