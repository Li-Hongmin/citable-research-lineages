> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A seven-vertex theta excludes the last two-port Hall tree

Continue the genuine minimum-host exact-Case-XII central-path setting of [Notes 290–291](291-cross-slot-singleton-switches-prune-two-vertex-hall-barriers.md). Assume the residual Hall barrier of Note 290 has a four-edge host cut with \(\alpha=2,\eta=0\). [Note 291](291-cross-slot-singleton-switches-prune-two-vertex-hall-barriers.md) leaves only
\[
q=A,\qquad r=H,\qquad
s=s_B\text{ carries the two proper shore ports }D=h_2,\ J=h_4,
\tag{1}
\]
where the other vertex \(\hat H=\hat r\) of the Hall tree carries \(H=h_3\). All statements below are conditional on the forced exterior templates of Notes 271–272 and the matching-closure exclusions of Notes 289–291.

**Theorem.** Placement (1) cannot occur in the non-cycle side of a minimum Berge–Fulkerson counterexample. Consequently, under the same hypotheses, **no four-edge Hall obstruction of type \(\alpha=2,\eta=0\) survives**. The same theta argument also excludes the \(\alpha=\eta=1,\ s\ne s_B\) placement \((q,p,r)=(A,D,H)\). Other \(\alpha=\eta=1\) placements, the local-incidence alternatives, and larger Hall cuts remain open.

## A genuine second five-cut

Because \(s\) carries \(D,J\), its third edge is \(s\hat H\). The port \(H\) joins \(\hat H\) to \(u_3\). Define
\[
W=\{s,\hat H,u_2,u_3,u_4,C_{\rm ext},D_{\rm ext}\}.
\]
Its eight internal edges are
\[
s\hat H,\ su_2,\ su_4,\ \hat H u_3,\
u_2C_{\rm ext},\ u_3C_{\rm ext},\
u_3D_{\rm ext},\ u_4D_{\rm ext}.                         \tag{2}
\]
Here \(su_2=D\), \(su_4=J\), and \(\hat H u_3=H\). Thus \(G[W]\) is the seven-vertex theta with branch vertices \(s,u_3\) and internally disjoint path lengths \(2,3,3\):
\[
s-\hat H-u_3,\qquad
s-u_2-C_{\rm ext}-u_3,\qquad
s-u_4-D_{\rm ext}-u_3.                                  \tag{3}
\]
Its five outward edges are exactly
\[
\hat H z,\quad u_2B_{\rm ext},\quad
C_{\rm ext}t_a,\quad u_4E_{\rm ext},\quad D_{\rm ext}t_b, \tag{4}
\]
where \(z\) is the third neighbour of \(\hat H\). The required \(HJ\) matching selects both \(H\) and \(t_ew\), so \(\hat H\ne w\); hence \(\hat H z\) is an ordinary core edge. No additional edge can join two vertices of \(W\): all seven vertices have the three displayed incident edges, counting (4).

The theta contains two proper 5-cycles. Its complement contains the original cap pentagon and the distinct marked vertex \(t_a\), so it is not a pentagon and contains a cycle. The five edges (4) therefore form a cycle-separating five-cut of the *whole minimum host*. The graph on \(W\) is not itself a pentagon. [Máčajová–Mazzuoccolo–Tabarelli (2026), Proposition 4.4](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) consequently leaves only Case XIII for this cut: in Cases I–XII an actual shore is an ordinary pentagon.

## Two independent missing matching types

Regard \(W\) as a five-pole whose ports lie at
\[
c=\hat H,\qquad x_1=u_2,\quad y_1=C_{\rm ext},
\qquad x_2=u_4,\quad y_2=D_{\rm ext}.                    \tag{5}
\]
An all-terminal perfect matching would use all five port edges to cover these five vertices, leaving branch vertices \(s,u_3\) uncovered. They are nonadjacent, so no such matching exists. In particular the complete BF support of \(W\) has no all-terminal type, whereas Figure 7's Case-XIII \(R^*\) has that type.

There are also **two distinct absent triple-boundary fibres**. If a shore matching selected the three ports \(c,y_1,y_2\), leaving \(x_1,x_2\) unselected, then \(u_3\) would have no available neighbour: each of \(\hat H,C_{\rm ext},D_{\rm ext}\) is already covered by its port. Thus the missing-pair state \(\{x_1,x_2\}\) has no triple-boundary perfect matching. Similarly, selecting \(c,x_1,x_2\) leaves \(s\) with no available neighbour, so state \(\{y_1,y_2\}\) has no triple-boundary perfect matching. A BF loop at either state would require two such triple-boundary matchings and is therefore absent.

The two states in the preceding paragraph are different under every relabelling. Figure 7's Case-XIII \(L^*\) has all ten BF loops and so cannot be \(W\). Even the literal Appendix XIII list, which repeats \([45]\) where Figure 7 has \([25]\), displays nine distinct loops; a relation missing *two* loops cannot equal that list either. Thus neither Case-XIII shore relation is possible. This contradicts Proposition 4.4 and excludes (1).

## A one-port Hall tree gives the same theta

Now take \(\alpha=\eta=1,\ s\ne s_B\), with the surviving port placement
\[
(q,p,r)=(A,D,H).
\]
The tight Hall tree is \(s\hat H\), while \(s\hat A\) is its extra edge to the \(R\)-based \(A\)-port vertex \(\hat A\). The sole port at \(s\) is \(D=h_2\). Hence the seven vertices
\[
W'=\{s,\hat A,\hat H,t_a,u_2,u_3,C_{\rm ext}\}
\]
have exactly the eight internal edges
\[
s\hat A,\ s\hat H,\ su_2,\ \hat A t_a,\
\hat H u_3,\ t_a C_{\rm ext},\
u_2C_{\rm ext},\ u_3C_{\rm ext}.                        \tag{6}
\]
The three internally disjoint \(s\)--\(C_{\rm ext}\) paths have lengths \(3,3,2\). Their five outward edges are the third edges of \(\hat A,\hat H\), the cap edge at \(t_a\), \(u_2B_{\rm ext}\), and \(u_3D_{\rm ext}\). Note 291 gives \(\hat A,\hat H\ne w\), so their third edges are proper core edges. The complement again contains the original cap pentagon and other vertices. The seven-vertex theta proof above applies verbatim: no all-terminal matching exists, and the triple-boundary fibres missing respectively \(\{\hat A,\hat H\}\) and \(\{t_a,u_3\}\) are empty. Proposition 4.4 gives the same contradiction. This excludes \((A,D,H)\) and completes the theorem. \(\square\)

The contradictions use actual seven-vertex theta cuts in the minimum host, not merely selected BF rows. They are independent of the relative terminal order at the new five-cut and robust to the Figure-7/Appendix-XIII transcription discrepancy identified in [Note 165](165-case-xiii-shore-compositions-exclude-the-disconnected-core.md). A related seven-vertex theta exclusion appears in [Note 182](182-a-seven-vertex-theta-cannot-be-a-case-xiii-shore.md); the present proof identifies both theta subgraphs in Note 291's Hall trees and supplies two missing loop states instead of one. No graph enumeration, local recomputation, OMEN run, or release was used.
