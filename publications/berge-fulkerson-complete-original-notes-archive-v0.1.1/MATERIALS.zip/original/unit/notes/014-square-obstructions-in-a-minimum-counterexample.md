> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Square obstructions in a minimum counterexample

Let a minimum exact-\(S\), capacity-bad simple connected cubic 5-pole contain
an induced proper square \(Q\).  Each natural smoothing must fail for a
visible reason.  Structural admissibility is equivalent to five tests: no
semiedge--semiedge block; no loop or existing-edge collision; no coincidence
of the two new proper edges; no terminal collision after moving a semiedge;
and connectedness after adding the replacement edges.

The failures have exact graph meanings.  Boundary failures impose adjacent
square terminals, distance-two terminals, or two moved terminals at one
outside vertex.  A loop produces a triangle; unless that triangle contracts,
its remaining incidence forces a bridge.  Coincident new edges or a
disconnected smoothing forces a proper cut of size at most two.  An
existing-edge collision is exactly another 4-cycle sharing an edge with
\(Q\); it need not force a triangle or small cut.

Tait compatibility is binary.  For either smoothing, if even one state in
\(S\) is compatible, Kempe closure forces all five states to be compatible.
At most one natural smoothing can be Tait-incompatible.  Such incompatibility
is genuinely global: a 14-vertex triangle-free, 3-edge-connected graph
obtained from a Petersen smoothing has all Tait colourings compatible with
only one smoothing.

Consequently, if a minimum counterexample has no proper cut of size at most
two, every terminal-free induced square must share an edge with another
4-cycle.  More generally every square is accounted for by a small proper
cut, a noncontractible-triangle/bridge configuration, a square cluster, one
of the stated terminal placements, or one globally Tait-incompatible
smoothing while the other still has a structural obstruction.

The derivation and boundary example are checked in
`scratch/worker-verify/square_obstruction_classification_draft.md` and
`scratch/worker-verify/find_tait_rigid_square_example.py`.

