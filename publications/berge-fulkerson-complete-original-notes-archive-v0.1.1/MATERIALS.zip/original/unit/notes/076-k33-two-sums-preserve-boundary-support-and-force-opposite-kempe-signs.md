> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# \(K_{3,3}\) two-sums preserve boundary support and force opposite Kempe signs

The negative support assumptions of exact Case XII cannot eliminate the
Kempe-class obstruction from the *bipartite path--\(K_{3,3}\) construction*
in [Note 075](075-fixed-row-paired-switch-connectivity-fails.md); its
explicit nine-vertex graph (3) is non-bipartite, as corrected there. For every
cubic 5-pole \(H_0\), inserting \(K_{3,3}\) by a two-edge sum preserves its
complete BF boundary support and its complete Tait state set.  At the same
time, every nonempty BF cell in the resulting pole contains witnesses in two
different paired-switch classes, separated by a local permutation-sign
invariant.

Consequently, if the exact-Case-XII class is nonempty, it contains poles with
disconnected witness graphs in every supported cell.  A Case-XII proof cannot
derive companion alignment from exact support, absence of \(T\)-loops and
\(T\)--\(T\) types, or fixed-cell connectivity.

## The two-sum and its perfect matchings

Let \(e=xy\) be a proper edge of \(H_0\).  In
\(K=K_{3,3}\), with parts

\[
 U=\{u_0,u_1,u_2\},\qquad V=\{v_0,v_1,v_2\},
\]

distinguish \(f=u_0v_0\).  Delete \(e,f\) from the disjoint union and add

\[
 xv_0,\qquad u_0y.                                  \tag{1}
\]

Write the resulting cubic 5-pole as
\(H=H_0\oplus_{e,f}K_{3,3}\).  Its semiedges are exactly those of \(H_0\).

The two edges in (1) form the cut \(\delta(V(K))\).  Every perfect matching
\(M\) of \(H\) uses zero or two of them, because

\[
 6=2|M\cap E(K-f)|+|M\cap\delta(V(K))|.             \tag{2}
\]

It therefore projects uniquely to perfect matchings \((M_0,M_K)\) of the
two factors: if both cut edges are used, replace them by \(e,f\); if neither
is used, restrict directly.  Conversely, \((M_0,M_K)\) splices uniquely
precisely when

\[
 \mathbf1_{e\in M_0}=\mathbf1_{f\in M_K}.           \tag{3}
\]

The boundary set of the splice is the boundary set of \(M_0\).

## Exact preservation of BF and Tait support

In an ordered BF witness of \(H\), both cut edges have load two.  Since each
matching uses both or neither, the same two slots traverse the cut.
Projection restores \(e,f\) in those slots and produces BF witnesses of
\(H_0\) and \(K_{3,3}\).  Conversely, in a BF witness of each factor,
exactly two slots use the distinguished edge.  Permute the closed-gadget
slots so that these two slot sets agree, then splice by (3).  Hence, for
every BF boundary type \(b\),

\[
 b\in\operatorname{BFsupp}(H)
 \quad\Longleftrightarrow\quad
 b\in\operatorname{BFsupp}(H_0).                    \tag{4}
\]

The same argument with three colour classes shows that the two cut edges in
a Tait colouring have the same colour.  Projection and colour-aligned
splicing give

\[
 \operatorname{TaitStates}(H)
 =\operatorname{TaitStates}(H_0).                   \tag{5}
\]

Thus the operation creates no \(A\), \(T\)-loop, or \(T\)--\(T\) type and
preserves exact Tait set \(S\) whenever those assertions hold for \(H_0\).

## Opposite gadget signs in every supported cell

Represent a perfect matching of \(K_{3,3}\) by the permutation
\(\pi\in S_3\) with edges \(u_iv_{\pi(i)}\).  Consider the two ordered BF
covers

\[
 C_+=(012,012,120,120,201,201)                     \tag{6}
\]

and

\[
 C_-=(012,021,102,210,120,201).                    \tag{7}
\]

The first is the cyclic one-factorization doubled; the second uses all six
permutations once.  Both cover every edge exactly twice, and precisely their
first two slots use \(f=u_0v_0\).  Define

\[
 \kappa_K(C)=\prod_{i=1}^{6}\operatorname{sgn}(\pi_i).
\]

Then

\[
 \kappa_K(C_+)=+1,
 \qquad
 \kappa_K(C_-)=-1.                                 \tag{8}
\]

Given any witness \(W_0\) of any nonempty cell of \(H_0\), reorder (6) and
(7) in parallel so that their \(f\)-slots are the two slots of \(W_0\) that
use \(e\).  Splicing produces witnesses \(W_+,W_-\) of the same ordered
boundary cell in \(H\).

For an arbitrary witness of \(H\), define \(\kappa_K\) from its projection
to the gadget.  A synchronous proper-cycle switch either misses the two-edge
cut or crosses it twice.  In the latter case its gadget portion is an
alternating path from \(u_0\) to \(v_0\); restoring \(f\) closes this path to
an alternating cycle in \(K_{3,3}\).  On a cycle of length \(2k\), the two
switched permutation signs are both multiplied by \((-1)^{k-1}\), so their
product is unchanged.  Therefore

\[
 \kappa_K(W')=\kappa_K(W)                           \tag{9}
\]

under every allowed paired switch in \(H\).  By (8)--(9), \(W_+\) and
\(W_-\) lie in different Kempe classes.  This argument does not require
\(H_0\) to be bipartite.

If \(H_0\) is bipartite and the splice respects its bipartition, the global
boundary-fixed sign from Note 075 factorizes as

\[
 \kappa_H(W)
 =\kappa_{H_0}(W_0)\kappa_K(W_K).                  \tag{10}
\]

The extra splice sign occurs in exactly two through slots and cancels in the
sixfold product.

## Consequence for Case XII

Suppose a real pole \(H_0\) has exact Tait state set \(S\), no BF
\(T\)-loop or \(T\)--\(T\) type, and a witness in a target cell \(b\).
Equations (4)--(5) give the same properties for \(H\), while (8)--(9) give
opposite Kempe classes in \(\Omega_b(H)\).  Hence either no such pole exists,
or negative support does not make its fixed-cell witness graph connected or
its sign constant.

For a prescribed singleton tuple \(\tau\), companion alignment still means

\[
 [W]_K\cap\Omega_b(\tau)\ne\varnothing,             \tag{11}
\]

where \([W]_K\) is the paired-switch class of a transported witness.
Opposite signs obstruct (11), but equal signs do not imply it; nor does exact
support imply that \(\Omega_b(\tau)\) is nonempty.  The remaining problem is
therefore target-fibre intersection inside a specified Kempe class, not
fixed-cell connectivity or sign homogeneity.
