> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last clean Hamilton-prism forbidden pair has no exact-Case-XII row

Use the Hamilton two-spoke prism exterior of [Notes 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md)–[434](434-the-last-clean-hamilton-prism-row-cannot-root-its-forbidden-ab-triple-at-b.md):
\[
(p_1,p_2,p_3,p_4,p_5)=(Aa,AC,CB,Bb,bc),\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab).                         \tag{1}
\]
The six-port shore has arbitrary order and complete perfect-matching family. Assume that the full BF support is exact Case XII with forbidden \(e\)-labels \(\{eZ,eW\}\). Its two possible five-cycles are
\[
S_1=e-X-Z-W-Y-e,\qquad S_2=e-X-W-Z-Y-e.          \tag{2}
\]
The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires every mixed \(S\)--\(T\) type and forbids every \(T\)--\(T\) type.

> **Pair exclusion.** No cubic five-pole with exterior (1) has complete exact-Case-XII support with forbidden pair \(\{eZ,eW\}\), at any shore order or complement cycle rank. Consequently the two clean zero-port shore signatures in Note 430 are both incompatible with exact Case XII: the \(\{eY,eW\}\) pair was excluded in [Note 432](432-the-hamilton-prism-excludes-the-cc-ab-forbidden-pair.md), and the present theorem excludes \(\{eZ,eW\}\).

Take a genuine six-perfect-matching BF row of required type \((eW)(eY)\). Write \(P=eW\) for its forbidden triple, \(R=eY\) for its allowed triple, \(J=W,K=Y\) for the corresponding singleton occurrences, and \(D_0,D_1=e\) for the singleton-\(e\) occurrences. [Note 433](433-the-last-clean-hamilton-prism-pair-has-one-allowed-root-and-two-marked-masks.md) proves that \(R\) is rooted at \(C\) and that the \(Y\)-starting path of \(R\triangle K\) is exactly one of
\[
\begin{array}{c|c|c}
\text{route}&\text{exterior path}&R'=eX\text{ root}\\ \hline
A&Y-C-u_2-A-X&A\\
B&Y-C-u_3-B-X&B.
\end{array}                                                  \tag{3}
\]
Switching both matchings on this wholly exterior component replaces \(R,K\) by an actual \(R'=eX\) triple and an \(X\)-singleton, preserving every edge load. In particular \(R,R'\) have the same **complete shore matching**. [Note 434](434-the-last-clean-hamilton-prism-row-cannot-root-its-forbidden-ab-triple-at-b.md) excludes \(P=eW:b\). Suppose henceforth \(P=eW:a\).

The tree halves of \(P\) and \(R\), on \((u_1,\ldots,u_5)\), are respectively
\[
(A,C,B,b,c),\qquad (a,A,B,b,c).                   \tag{4}
\]
Thus they saturate \(Bu_3,bu_4,cu_5\). Since \(K\) selects the \(Y\) terminal, its \(c\) vertex must take \(Z:c\). The route in (3) and saturated \(Bu_3\) leave exactly these four forms for \(K\):
\[
\begin{array}{c|c|l}
\text{route}&K\text{ at }W&\text{other forced edges of }K\\ \hline
A&b&X:A,\ Cu_2,\ Bu_4,\ au_1,\ Z:c\\
A&a&X:A,\ Cu_2,\ Bu_4,\ bu_5,\ Z:c\\
B&b&X:B,\ Cu_3,\ Au_2,\ au_1,\ Z:c\\
B&a&X:B,\ Cu_3,\ bu_5,\ Z:c,\ A u_1\text{ or }A u_2.
\end{array}                                                  \tag{5}
\]
Unlisted \(u_i\) are matched through their proper shore ports. Each form in (5) separately obeys the local matching condition; no other form is discarded by assumption.

**Marked-mask quota.** If \(K:W:b\), then \(R,K\) saturate \(au_1\), while \(P,R\) saturate \(cu_5,bu_4\). Edge loads force
\[
J:(Y:c,Z:a,b u_5),\quad
D^C:(Y:C,Z:c,W:a,b u_5),\quad
D^c:(Y:c,Z:a,W:b).                                  \tag{6}
\]
The \(X\) half of \(D^C\) remains \(A\) or \(B\). In route \(B\), \(R,K\) also saturate \(Au_2\), forcing \(D^C:X:B\) to take \(Au_1\). In route \(A\), \(D^C:X:B\) may take either \(Au_1\) or \(Au_2\).

If \(K:W:a\), then \(P,K\) saturate \(W:a\). The singleton \(J\), which selects the \(W\) terminal, must take \(bu_5\); \(K\) takes the other \(bu_5\) slot, so both \(D_i\) take \(W:b\). Among \(J,D_0,D_1\) there is exactly one occurrence \(M\) with
\[
M:(a u_1,Z:c,Y:C),                                  \tag{7}
\]
and the other two have \((Z:a,Y:c)\). Indeed, these three occurrences must take the remaining one \(au_1\) slot and two \(Z:a\) slots at \(a\), and the remaining one \(Z:c\) slot and two \(Y:c\) slots at \(c\); the same occurrence must take \(au_1,Z:c\). If \(M=D_i\), compare with that \(D_i\). If \(M=J\), both \(D_i\) have \((Y:c,Z:a,W:b)\); choose one with \(X:B\) in route \(A\), or one with \(X:A\) in route \(B\). Such a choice exists because \(X\) has exactly two slots at each marked half and \(K\) already uses \(X:A\) or \(X:B\), respectively.

For any selected singleton-\(e\) occurrence \(D\), let \(W_R,Z_R\) denote the proper shore ports reached by the \(W,Z\) terminal arms of \(R\triangle D\), and define \(W_{R'},Z_{R'}\) similarly. The fixed shore \(e\)-path against \(D\) must exit at \(W_R\) for \(R\) and \(Z_{R'}\) for \(R'\) under \(S_1\); under \(S_2\) it must exit at \(Z_R\) and \(W_{R'}\). All exits in the following table are obtained by following the alternating exterior edges. A number \(i\) denotes \(p_i\), and braces are bounds that include every allowed exit in that entry.
\[
\begin{array}{c|c|l|c|c}
\text{route}&K:W&\text{witness }D& S_1:(W_R,Z_{R'})&S_2:(Z_R,W_{R'})\\ \hline
A&b&D^C:X:A &(1,3)&(3,1)\\
A&b&D^C:X:B,\ Au_1 &(2,4)&(4,3)\\
A&b&D^C:X:B,\ Au_2 &(1,4)&(4,1)\\
B&b&D^C:X:A &(1,2)&(3,1)\\
B&b&D^C:X:B &(2,4)&(4,2)\\ \hline
A&a&M=D &(\{3,4\},5)&(5,\{3,4\})\\
A&a&M=J,\ D:X:B &(4,\{1,2,3\})&(\{1,2,5\},4)\\
B&a&M=D &(\{3,4\},5)&(5,\{2,4\})\\
B&a&M=J,\ D:X:A &(\{3,5\},1)&(1,\{2,3\}).
\end{array}                                                  \tag{8}
\]
Here are the port traces needed to check the less immediate rows. In the first five rows, (6) gives \(D^C:b u_5\). If \(D^C:X:A\), saturated \(Bu_3\) forces \(Bu_4\); its \(Z\)-arm against \(R\) is \(Z-c-u_5-b-u_4-B-u_3-p_3\). Against route \(B\)'s \(R'\), the last segment instead follows \(B-X-A-u_2-p_2\). If \(D^C:X:B\), its \(Z\)-arm exits at \(p_4\); its \(W\)-arm starts \(W-a-u_1\) and exits at the \(p_1,p_2,p_3\) entries shown, according to the selected \(A\)-edge and the root of \(R'\).

When \(K:W:a\) and \(M=D\), this witness has \(Z:c,W:b\), so its \(Z\)-arm exits at \(p_5\) against both \(R,R'\). Its \(W\)-arm goes through \(b-u_4\), exiting at \(p_3\) or \(p_4\) against \(R\), and at \(p_3/p_4\) in route \(A\) or \(p_2/p_4\) in route \(B\) against \(R'\). When \(M=J\) in route \(A\), the chosen \(D:X:B\) has \(W_R=W_{R'}=p_4\), while tracing \(Z-a-u_1\) gives \(Z_R\in\{p_1,p_2,p_5\}\) and \(Z_{R'}\in\{p_1,p_2,p_3\}\). When \(M=J\) in route \(B\), the chosen \(D:X:A\) has \(Z_R=Z_{R'}=p_1\); its \(W\)-arm exits at \(p_3/p_5\) against \(R\) and \(p_2/p_3\) against \(R'\).

For every row in (8), the \(W,Z\) arms of each of \(R\triangle D\) and \(R'\triangle D\) reach distinct proper ports. Each symmetric difference has three marked terminal ends and three proper exterior port ends; its third marked arm therefore reaches the remaining port, with no port-to-port exterior detour. Since \(R,R'\) have the same complete shore matching, their \(e\)-path against unchanged \(D\) has the same first proper shore exit. The two demanded entries in either column of (8) are disjoint, contradicting exact-Case-XII support. This rules out \(P=eW:a\); Note 434 ruled out \(P=eW:b\). \(\square\)

By Note 430, a clean zero-port shore perfect matching could coexist with exact Case XII in this Hamilton tree only for the forbidden pair \(\{eY,eW\}\) or \(\{eZ,eW\}\). Notes 432 and 435 exclude both. Thus **every** zero-port shore matching in any still-hypothetical exact-Case-XII Hamilton-prism pole has an odd closed component in its shore complement; the two zero-port triples of one BF row must then use different complete shore matchings by [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md).

The other three forbidden pairs for this Hamilton exterior, other exterior profiles, the full exact-Case-XII obstruction and Berge–Fulkerson conjecture remain open. This is an analytic hand proof, checked only within this derivation and awaiting independent review; no OMEN or local mathematical recomputation was used.
