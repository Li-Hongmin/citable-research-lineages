> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A fixed singleton profile is impossible in the exact same-side \(5+0\) branch

Let \(H\) be a cubic five-pole with all twenty-five \(S\)--\(T\) BF types and no \(T\)-loop or \(T\)--\(T\) type, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Suppose disjoint proper edges \(e,f\) make \(H-\{e,f\}\) bipartite, both edges lie inside one part, and all five terminal semiedges lie in that part. This is [Note 127's same-side \(5+0\) branch](127-two-edge-bipartization-profiles-and-tait-blockers.md). Its balance equation says that **every** triple-boundary perfect matching avoids \(e,f\), whereas **every** singleton-boundary perfect matching uses exactly one of them.

## Full-family flexibility theorem

Let \(\mathcal P_c\) be the complete family of singleton-boundary perfect matchings in class \(c\). Then
\[
\boxed{\forall c\in[5]\quad\exists P_e,P_f\in\mathcal P_c:
e\in P_e,\ f\in P_f.} \tag{1}
\]

**Proof.** Suppose instead that all singleton matchings in class \(c\) use \(e\); the case with \(f\) is symmetric. Choose any \(S\)-edge \(cx\) and any \(T\)-edge \(cy\). Their positive BF type \((cx)(cy)\) has four singleton occurrences with boundaries \(c,c,x,y\). The two class-\(c\) occurrences already load \(e\) twice. Both triple occurrences avoid \(e,f\), and each singleton occurrence uses exactly one of them, so the class-\(x\) and class-\(y\) occurrences must both use \(f\).

Split the actual row into its complete half-loads
\[
A=Q_{cx}+P_c+P_x,\qquad R=Q_{cy}+P'_c+P_y,\qquad A+R=2\mathbf1.
\]
The \(S\)-half \(A\) has \((A(e),A(f))=(1,1)\), with \(P_c\) using \(e\) and \(P_x\) using \(f\). Keep all three complete matchings of the \(T\)-half \(R\) fixed. In the edge-copy cubic multigraph of \(A\), switch the terminal path between its triple matching and one singleton matching. The new triple still avoids \(e,f\), so this path avoids both exceptional edges and the moving singleton keeps its profile. The new missing-pair state cannot lie in \(T\): together with the fixed \(T\)-half it would give a forbidden \(T\)-loop or \(T\)--\(T\) BF type.

Consequently each move takes the moving singleton to the *other* neighbour of the fixed singleton in the \(S\)-pentagon. Five successive moves traverse its five edges and return to state \(cx\) with the two singleton profiles exchanged. For example, after a relabelling preserving \(S,T\), the boundary states and ordered singleton positions follow
\[
(1,3)\to(5,3)\to(5,2)\to(4,2)\to(4,1)\to(3,1).
\]
Every intermediate row is an actual six-perfect-matching double cover with the same complete half-loads \(A,R\). The final class-\(c\) singleton therefore uses \(f\), contrary to the assumption. This is the [fixed-carrier orientation argument of Note 133](133-same-side-five-zero-carrier-orientations-balance-bc-projections.md), written here for the class-fixed consequence. \(\square\)

The theorem concerns the **complete singleton matching classes**, not only one chosen BF row. It does not claim that both profiles of a class occur in one prescribed cell or share other matching masks.

## Tutte-barrier consequence

Apply (1) to [Note 166's](166-tutte-barrier-mark-quota-and-one-vertex-profiles.md) connected \(F=J-M\) with matching deficiency two. If a maximum Tutte barrier \(U\) has \(h(U)=2\), its two \(U\)-side marked half-edges form the \(5+0\) exceptional pair. Every class-\(i\) singleton uses the \(U\)-side half of the *other* mark \(j\), since its four deleted marked endpoints must include exactly one vertex of \(U\). Thus class \(i\) is fixed to one exceptional edge, contradicting (1). **The \(h(U)=2\) equality shape is impossible.**

If \(h(U)=1\) and Note 166's cut budget has \(E=0\), all odd components of \(F-U\) are singleton and \(F[U]\) is one edge \(g\). The exceptional \(5+0\) pair is \(g\) and the \(U\)-side half of the unique mark \(h\) incident with \(U\). Every class-\(h\) singleton selects four vertices in \(D=V(F)\setminus U\); the residual bipartition sizes force it to use \(g\). This class is fixed to \(g\), again contradicting (1). **The \(h(U)=1,\ E=0\) shape is impossible.**

Combining these exclusions with Note 166's identity \(E+a+b=4-2h(U)\) yields the sharper all-orders necessary condition
\[
\boxed{h(U)\le1\quad\text{for every maximum Tutte barrier }U.} \tag{2}
\]
If equality \(h(U)=1\) holds, necessarily \(E=2\): there is one non-singleton odd component with a five-edge \(J\)-cut, all other odd components are singleton, and \(a=b=0\). The \(h(U)=0\) branch without even components, the remaining \(h(U)=1\) five-cut shape, and the perfectly matchable \(F\) branch are not excluded here. Note 166 separately rules out an even component when \(h(U)=0\) by one-edge bipartization. The derivation uses genuine BF rows and their Kempe closure, with no finite-order enumeration.
