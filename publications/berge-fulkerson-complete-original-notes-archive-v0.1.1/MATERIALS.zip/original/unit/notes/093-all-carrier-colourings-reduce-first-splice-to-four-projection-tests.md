> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All carrier colourings reduce the first splice to four projection tests

For the two literal-anchored repeated-extension columns, the contribution of
every actual three-edge-colouring of the complementary half-load carriers can
be computed exactly.  The complete colouring families, including all their
Kempe moves, reduce to four intersections between an oriented carrier
projection and a fixed-half sign set.  Exact Case-XII negative support does
not presently force any of these intersections to be nonempty.

This refines the dependent sign gate of
[Note 091](091-dependent-two-splice-gate-splits-into-sign-feasibility-and-four-row-sections.md)
after [Note 092](092-one-pivot-quadratic-factorization-does-not-force-an-anchored-two-splice-fibre.md)
shows that ordinary quadratic connectivity is insufficient at the
common-binary level.

## The two complete carrier families

Consider all actual rows of the forms

\[
\begin{aligned}
\mathcal A_{23}:&\quad
 q+r_{23}+B+X+P_3+P_5=2\mathbf1,\\
\mathcal A_{34}:&\quad
 q'+r_{34}+Y+C+P_1+P'_3=2\mathbf1.               \tag{1}
\end{aligned}
\]

Put

\[
\begin{aligned}
H_{23}&=r_{23}+B+X,&K_{23}&=2\mathbf1-H_{23},\\
H_{34}&=r_{34}+Y+C,&K_{34}&=2\mathbf1-H_{34}.    \tag{2}
\end{aligned}
\]

Each \(K\) is an integral degree-three load multigraph.  For an oriented
state \(ij\), let

\[
\mathcal D_{ij}(K)=
 \{(Q,P_i,P_j):Q+P_i+P_j=K\}                    \tag{3}
\]

be its complete family of actual decompositions, or equivalently all proper
three-edge-colourings with the displayed terminal colours.  Define its
class-\(i\) projection by

\[
\mathcal F_i(K;j)=
 \{P_i:(Q,P_i,P_j)\in\mathcal D_{ij}(K)\}.       \tag{4}
\]

Thus \(\mathcal F_i(K;j)\) already includes every carrier colouring and
every boundary-preserving Kempe orbit.

For same-boundary perfect matchings \(P,\widehat P\), write

\[
\operatorname{Sep}(N;P,\widehat P)
\iff
\widehat P\setminus P\subseteq N
\quad\text{and}\quad
N\cap(P\setminus\widehat P)=\varnothing.         \tag{5}
\]

If \(H=(L_0,L_1,L_2)\) is the occurrence-labelled fixed half, put

\[
\mathcal G_H(\widehat P)=
 \{\widehat P\}\cup
 \bigcup_{a=0}^{2}
 \{P:\operatorname{Sep}(L_a;P,\widehat P)\}.    \tag{6}
\]

## Projection criterion

Fix an endpoint role \(P_i\to\widehat P_i\) in a carrier state \(ij\).
Among all actual rows with fixed half \(H\) and complementary carrier \(K\),
a first Note-082 companion exists if and only if

\[
\boxed{
\mathcal F_i(K;j)\cap\mathcal G_H(\widehat P_i)\ne\varnothing.
}                                                               \tag{7}
\]

To prove this, first suppose that a companion internal to the carrier,
namely \(Q\) or \(P_j\), satisfies (5).  Then

\[
N'=N+P_i-\widehat P_i                           \tag{8}
\]

is a perfect matching, and replacing \((N,P_i)\) by
\((N',\widehat P_i)\) gives another decomposition of the same \(K\).
Hence \(\widehat P_i\in\mathcal F_i(K;j)\).  Conversely, if the literal
\(\widehat P_i\) already lies in that projection, choose the corresponding
row; the replacement is the degenerate case explicitly included in Note
082.  Therefore all internal companions are represented by the first set in
(6).

The remaining companions are exactly the three fixed occurrences
\(L_0,L_1,L_2\).  Such an occurrence works precisely when (5) holds for
some \(P_i\) in the projection (4), which is the second part of (6).  This
exhausts all five companion positions and proves (7).

## Fixed-half preimages are agreement-region cycle flips

The sets in (6) have an intrinsic graph description in the underlying pole
\(G\).  Incidences and parallel edges are distinguished as edge objects.
For a fixed-half matching \(L\) and the desired matching \(\widehat P\), let

\[
V_{\mathrm{pr}=}(L,\widehat P)=
\{v:\text{\(L\) and \(\widehat P\) choose the same proper-edge
incidence at \(v\)}\}.
                                                               \tag{9}
\]

Then

\[
\operatorname{Sep}(L;P,\widehat P)
\iff
P\triangle\widehat P
\text{ is a union of proper alternating cycles contained in }
G[V_{\mathrm{pr}=}(L,\widehat P)].               \tag{10}
\]

Indeed, suppose that \(L\) and \(\widehat P\) choose different incidences
at \(v\).  If \(P\) chose the \(L\)-incidence, then
\(P\setminus\widehat P\) would meet \(L\), contrary to (5).  If \(P\)
chose the third incidence, then the \(\widehat P\)-incidence would belong to
\(\widehat P\setminus P\) but not to \(L\), again contrary to (5).
If \(L\) and \(\widehat P\) agree on a semiedge, then \(P\) uses the same
semiedge because it has the same boundary as \(\widehat P\).  Therefore
\(P\) is forced to equal \(\widehat P\) at every vertex outside
\(V_{\mathrm{pr}=}\).

At a vertex in \(V_{\mathrm{pr}=}\), either \(P=\widehat P\), or the common
\(L=\widehat P\) incidence is precisely the deleted phase and the
\(P\)-incidence is the inserted phase, so (5) holds locally.  Since
\(P\) and \(\widehat P\) have the same boundary, their difference is a
union of proper alternating cycles.  Conversely, flipping any union of
\(\widehat P\)-alternating cycles in the displayed induced subgraph deletes
only proper incidences shared by \(L,\widehat P\) and inserts incidences
avoided by \(L\), so (5) holds.  This proves both directions of (10).

Equivalently, \(P\) is fixed to \(\widehat P\) outside
\(V_{\mathrm{pr}=}\), while its restriction to the proper-edge graph
induced by \(V_{\mathrm{pr}=}\) may be any perfect matching of that induced
graph.  The restriction of \(\widehat P\) is one such matching.  This form
allows ordinary Tutte barriers in the agreement core to be used without
forgetting the occurrence identities outside it.

Consequently \(\mathcal G_H(\widehat P)\) is exactly the union, over the
three fixed occurrences \(L_a\), of the perfect matchings obtained from
\(\widehat P\) by alternating-cycle flips confined to the corresponding
agreement region (9).  The first-splice question is therefore not general
Kempe connectivity: it asks whether one of three geometrically restricted
flip families enters the oriented carrier projection.

## The four exact failure tests

For the replacements

\[
P_3\to Y,\qquad P_5\to D,\qquad
P_1\to A,\qquad P'_3\to X,                       \tag{11}
\]

all first splices fail across all actual carrier colourings if and only if

\[
\begin{aligned}
\mathcal F_3(K_{23};5)&\cap
 \mathcal G_{(r_{23},B,X)}(Y)=\varnothing,\\
\mathcal F_5(K_{23};3)&\cap
 \mathcal G_{(r_{23},B,X)}(D)=\varnothing,\\
\mathcal F_1(K_{34};3)&\cap
 \mathcal G_{(r_{34},Y,C)}(A)=\varnothing,\\
\mathcal F_3(K_{34};1)&\cap
 \mathcal G_{(r_{34},Y,C)}(X)=\varnothing.       \tag{12}
\end{aligned}
\]

Equivalently, the prescribed literal never enters the relevant oriented
carrier projection, and every projected source matching fails the three
fixed-half \(\operatorname{Sep}\) tests.  In the edge-label formulation,
every row then contains an inclusion-minimal empty-intersection core of one
of the two forms classified in Note 084:

\[
\{\{a,b\},\{c,d\}\},
\qquad
\{\{a,b\},\{a,c\},\{b,c\}\}.                   \tag{13}
\]

The criterion is stronger than checking one displayed source row: (12)
quantifies over the complete graph-induced perfect-matching family and every
three-edge-colouring of both fixed carriers.

## Exact negative support leaves a cube-to-row gap

For one endpoint occurrence, let \(\mathcal C\) be the full partial-flip
cube of \(P\triangle\widehat P\), let \(D_2\) be the load-two set of its
four target singleton anchors, and retain its fixed \(T\)-half.  There are
three possible exits:

\[
\begin{aligned}
\mathcal J&=\{N\text{ in the current row}:
              \operatorname{Sep}(N;P,\widehat P)\},\\
\mathcal A&=\{P^I\in\mathcal C:P^I\cap D_2=\varnothing\},\\
\mathcal T&=\{P^I\in\mathcal C:P^I
              \text{ enters the fixed carrier in a }T\text{-state}\}.
                                                               \tag{14}
\end{aligned}
\]

Nonempty \(\mathcal J\) gives the first paired splice.  Nonempty
\(\mathcal A\) gives the forced complement

\[
2\mathbf1-W-P^I                                  \tag{15}
\]

and hence a forbidden all-terminal cover.  Nonempty \(\mathcal T\),
combined with the fixed \(T\)-half, gives a forbidden \(T\)--\(T\) row.
Exact negative support therefore excludes the last two exits, but it does
not force the first.  Its known consequences have the quantifier forms

\[
\forall I\ \exists e_I\in P^I\cap D_2
\quad\text{and}\quad
P^I\text{ enters a carrier}\Longrightarrow
\text{its partner state is allowed},             \tag{16}
\]

neither of which identifies one current-row companion occurrence.

Nor can the four local failures simply be added.  For an endpoint
occurrence \(h=(R,P,\widehat P)\), let \(\operatorname{Out}(h)\) contain
the actual perfect matchings

\[
N+P-P^I
\]

obtained from current companions \(N\) and binary partial flips \(P^I\).
Let \(\operatorname{Act}(g)\) be the actual identities occupying operative
positions in another endpoint family \(g\).  Any derivation made from
occurrence-preserving row substitutions has a first cross-carrier step, and
therefore must establish

\[
\operatorname{Out}(h)\cap\operatorname{Act}(g)\ne\varnothing
                                                               \tag{17}
\]

for families on opposite carriers.  Their only common singleton boundary
class is \(3\), while their triple boundary classes are disjoint.  Hence a
rank-one crossing in (17) must be a class-\(3\) actual matching identity.
The only algebraic bypass is an explicit higher-rank cross-fibre relation
\(\sum\chi_{M_a}=\sum\chi_{N_b}\) after all literal cancellations.  The
four empty-intersection certificates supply neither datum, and even a
crossing must still reach the all-terminal or \(T\)--\(T\) forbidden sink.

The missing positive statement is consequently a cube-to-row occurrence
dichotomy: for at least one occurrence in the four families (12), one of
\(\mathcal J,\mathcal A,\mathcal T\) must be nonempty.  Under exact
Case-XII support only \(\mathcal J\) can survive.  No current theorem proves
this dichotomy, and no real exact-Case-XII pole is known which satisfies all
four failures in (12).

This note is an exact carrier-level reduction, not a proof or counterexample
for real Case XII.  It shows that adding further carrier colourings or Kempe
connectivity cannot settle the first splice unless it forces one of the four
literal projection incidences in (12).  The dependent second splice remains
an additional condition after this first gate.
