> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last \((e\,ab)(e\,bc)\) prism row forces a double-forbidden completion

Use the two-spoke triangular-prism tree and four marks of [Note 406](406-the-remaining-ab-bc-mixed-row-has-one-pentagon-and-an-e-p5-gate.md). Assume complete exact Case-XII BF support with forbidden \(e\)-labels \(ab,Cc\). No restriction is placed on shore order, cycle rank, complementary cycles, or port-path lengths.

> **Row exclusion.** No actual six-perfect-matching BF row of type \((e\,ab)(e\,bc)\) exists in this placement. Consequently, a five-pole with this marked two-spoke-prism exterior cannot have the specified [Appendix-XII relation](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), which requires this mixed row.

**Proof.** By Note 406, the only remaining roots are a forbidden triple \(P=e\,ab:b\) and an allowed triple \(R=e\,bc:c\). The allowed pentagon must be
\[
S=e-AC-Cc-ab-bc-e.                                             \tag{1}
\]
Write \(J\) for the singleton-\(ab\) occurrence and \(K\) for the singleton-\(bc\) occurrence. Note 406 fixes
\[
\begin{array}{c|c}
J&ab\text{ terminal},\quad au_5,\quad bc:c\\
K&bc\text{ terminal},\quad cu_5,\quad Cc:C
\end{array}                                                     \tag{2}
\]
and gives either singleton-\(e\) occurrence \(D\) an \(e\)--\(p_5\) shore path against \(R\). The complete \(e\)-starting path in \(R\triangle D\) ends at \(ab\) through the exterior tail \(p_5-u_5-a-t_{ab}-ab\). Switch this path. The unchanged \(P\) is still forbidden, and the new triple \(T\) has the allowed state \(ab\,bc\). In the exterior, \(T\) takes \(u_5p_5,ab:a,bc:c,Cu_2,Bu_1\), and it takes terminal semiedges \(e,AC,Cc\). In particular, its \(bc\)-starting comparison with \(K\) begins
\[
bc-t_{bc}-c-u_5-p_5,                                         \tag{3}
\]
alternating between \(K\) and \(T\).

The path in \(T\triangle K\) starting at \(bc\) must end at one of \(e,AC,Cc\). Ending at \(e\) would change \(T\) to \(e\,ab\), and ending at \(AC\) would change it to \(AC\,ab\); both lie outside (1), alongside the unchanged forbidden \(P\). Therefore exact support forces its endpoint to be \(Cc\). Switch this complete \(bc\)--\(Cc\) path, obtaining an allowed triple \(U=ab\,Cc\).

This second switch gives \(U\) the \(bc\) terminal semiedge and the edge \(cu_5\), while leaving its edge \(ab:a\) intact. To see the last assertion without assuming any shore pairing, trace the \(Cc\)-arm of \(T\triangle K\): it follows \(Cc-t_{Cc}-C-u_2\), then exits at \(p_2\) if \(K\) uses that port, or follows \(u_2-B-u_1-p_1\) if \(K\) uses \(Bu_2\). Thus this arm never enters \(a\) or \(t_{ab}\); the other arm in (3) reaches the shore through \(p_5\).

Now (2) and the indicated edges of \(U\) give a **wholly exterior** alternating terminal path in \(U\triangle J\):
\[
ab-t_{ab}-a-u_5-c-t_{bc}-bc.                                  \tag{4}
\]
Its six edges belong successively to \(J,U,J,U,J,U\). Switching (4) replaces the triple state \(ab\,Cc\) by \(bc\,Cc\), which is outside (1). The original triple \(P=e\,ab\) has not changed during any switch and is also outside (1). This is a genuine double-forbidden BF row, contradicting exact Case XII. Every switch uses a whole alternating terminal path between complete perfect matchings, so the six matching occurrences remain a load-two cover throughout. \(\square\)

The proof excludes the specified marked-prism placement and its required \((e\,ab)(e\,bc)\) row at every shore order. It does not exclude other exterior profiles or settle the Berge–Fulkerson conjecture. The derivation is by hand and has not received an independent proof review.
