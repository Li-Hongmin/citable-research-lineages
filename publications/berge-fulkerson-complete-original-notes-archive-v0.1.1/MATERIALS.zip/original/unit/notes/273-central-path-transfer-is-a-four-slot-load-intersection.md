> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Central-path transfer is a four-slot load intersection

> **Scope correction:** [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> adds a genuine right \((ea)(ad)\) exterior template. The
> equivalence and load sets below concern the **left \(ad\)
> template** of Note 272; they are not an all-template exact-Case-XII
> criterion until the right branch is handled. [Note 339](339-the-genuine-right-row-forces-an-internal-pure-load-circulation.md)
> gives the precise right-branch boundary: its four-slot exterior
> load differs from the left \(ac\) row, while their pure-three
> exterior loads agree but their full loads cannot agree.

Continue the central marked path and fixed allowed pentagon \(S=e-a-b-d-c-e\) of [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). The two required exact-Case-XII rows have the forced exterior masks in Note 271's \((ea)(ac)\) table and Note 272's \((ea)(ad)\) table. Write either row as
\[
R_t=X_a+Y_a+Z_e+U_t+V_a+W_t=2\mathbf1,
\qquad t\in\{ac,ad\},                                   \tag{1}
\]
with \(W_{ac}=W_c\) and \(W_{ad}=W_d\). Every symbol denotes a **complete actual perfect matching occurrence**. Define its four-slot load vector
\[
B(R_t)=\mathbf1_{X_a}+\mathbf1_{Y_a}+\mathbf1_{Z_e}+\mathbf1_{V_a}. \tag{2}
\]
The forced exterior tables make \(B(R_{ac})\) and \(B(R_{ad})\) identical on every exterior edge and terminal semiedge, for any choices of the shore matchings. Thus equality in (2) across two rows is only a condition on their six-port shore loads. It does not require any of their four matching identities to agree.

Let \(\mathcal F_t\) be the set of shore restrictions of \(B(R_t)\) over all real rows with the prescribed exterior template of type \(t\).

**Theorem (exact overlap criterion).** The following are equivalent:

**(i)** \(\mathcal F_{ad}\cap\mathcal F_{ac}\ne\varnothing\).

**(ii)** Some real \((ea)(ad)\) row with Note 272's exterior template has, in \(U_{ad}\triangle W_d\), a shore path joining \(a:\Sigma\) to \(h_2\).

**(iii)** Some real \((ea)(ac)\) row with Note 271's exterior template has the corresponding \(a:\Sigma\)--\(h_2\) path in \(U_{ac}\triangle W_c\).

In particular, a common four-slot **load** is sufficient to synchronize the two required row types by one alternating-path exchange. Complete exact-Case-XII support makes each set \(\mathcal F_t\) nonempty; it does not itself establish their intersection.

## Proof

Assume (i), and choose rows \(R_{ad},R_{ac}\) with the same shore four-slot load. Their four-slot exterior loads agree by the forced templates, so their full vectors \(B\) agree. Subtracting (2) from their edge-load-two equations gives
\[
\mathbf1_{U_{ad}}+\mathbf1_{W_d}
=2\mathbf1-B
=\mathbf1_{U_{ac}}+\mathbf1_{W_c}.                 \tag{3}
\]
Delete from the common two-matching load the edges of multiplicity two. At each remaining internal vertex the two multiplicity-one edges form an alternating passage. Hence the remaining support consists of alternating cycles and two terminal paths whose four ends are \(b,c,d,e\). Each path has exactly two choices of the \(U/W\) colouring, exchanged globally along that path.

In the \(ad\) decomposition of (3), terminals \(b,c,e\) have colour \(U\) and \(d\) has colour \(W\). In the \(ac\) decomposition, \(b,d,e\) have colour \(U\) and \(c\) has colour \(W\). Exactly the terminal colours at \(c,d\) change. They must therefore be the ends of the same terminal path. Note 272's exterior route table takes \(c\) to \(a:\Sigma\) and \(d\) to \(h_2\), proving (ii).

Conversely assume (ii). Switching the complete \(c\)--\(d\) component of \(U_{ad}\triangle W_d\) gives actual matchings with boundaries \(\{b,d,e\}\) and \(\{c\}\) and with Note 271's forced \(U_{ac},W_c\) exterior masks. The other four occurrences and the total load remain unchanged, so the resulting row is of type \((ea)(ac)\) and has the same vector (2). This proves (i). The same argument starting from the \(ac\) row proves (iii)\(\Rightarrow\)(i), completing the equivalence. \(\square\)

The result isolates the remaining cross-row question to intersection of two sets of integer shore-load vectors. The real 25-vertex pole of [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) has an \(ad\) row and all six individual full matchings required by the \(ac\) template, but no row of that template, so its \(\mathcal F_{ac}\) is empty. It does not decide whether two **nonempty** sets \(\mathcal F_{ad},\mathcal F_{ac}\) can be disjoint under complete exact-Case-XII negative support. Neither that implication nor Berge--Fulkerson is proved here. The path and load argument is hand-derived and awaits independent verification.

There is a concrete sufficient condition for overlap. Let \(\mathcal P_0,\mathcal P_4,\mathcal P_{HJ}\) be the complete shore perfect-matching fibres with port sets \(\varnothing,\{e,a:\Sigma,h_1,h_2\},\{h_3,h_4\}\), respectively. If \(|\mathcal P_0|=|\mathcal P_4|=1\) and \(|\mathcal P_{HJ}|=2\), then any two required rows have the same \(X_a,Z_e\) shore matchings and the same unordered pair \(\{Y_a,V_a\}\): [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) force \(Y_a\ne V_a\). Their four-slot loads therefore agree, so the theorem supplies the \(a:\Sigma\)--\(h_2\) transfer. Consequently a putative exact pole in which **every** such one-path transfer fails must have at least two zero-port shore matchings, at least two four-port shore matchings, or at least three \(\{h_3,h_4\}\)-port shore matchings.

The one-row counterexample can be made arbitrarily large without changing its local conclusion. Choose an unmarked internal edge of Note 272's modified 12-vertex shore, for example \(c_0=s_0s_1\), and perform the three-edge-colourable two-sum of [Note 099](099-three-edge-colourable-two-sums-preserve-dependent-splice-fibres.md) with \(K_4\) along that edge. Repeat inside the enlarged shore. Each insertion adds four vertices, leaves the central marked exterior and six shore ports unchanged, and preserves the complete BF boundary support by Note 099. Every perfect matching and real \(ad\) row projects to the original pole; conversely the original matching identities and row lift consistently. A proposed \(ac\) row with Note 271's exterior template would project to the absent original template row. The two forbidden shore Tait signatures still cannot occur, since a colouring would project to one on the original shore. Hence there are connected simple cubic poles of orders \(25+4m\), \(m\ge0\), with \(\mathcal F_{ad}\ne\varnothing\), \(\mathcal F_{ac}=\varnothing\), all six prescribed individual \(ac\) matchings, and neither forbidden signature in Note 272's (9). They have a proper two-edge decomposition and the same non-exact BF support as the 25-vertex base. This family shows that an order threshold alone cannot force the local four-slot intersection.
