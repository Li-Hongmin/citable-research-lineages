> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every surviving Hamilton \(AB,ab\) row recompletes to forbidden support

Keep the Hamilton two-spoke exterior of [Note 430](430-the-hamilton-two-spoke-prism-has-two-clean-shore-signatures.md):
\[
a-u_1-A-u_2-C-u_3-B-u_4-b-u_5-c,\qquad
(X,Y,Z,W)=(AB,Cc,ac,ab),
\]
with proper shore ports \(p_i\) at \(u_i\). Assume complete exact-Case-XII support with forbidden labels \(eX,eW\). [Note 436](436-the-hamilton-prism-excludes-one-x-w-forbidden-pentagon.md) excludes \(S_1=e-Y-X-W-Z-e\) and reduces every required \((eX)(eY)\) row under \(S_2=e-Y-W-X-Z-e\) to its equation (8). This note closes the remaining \(S_2\) row by recompleting its actual six shore matchings.

> **Full-closure exclusion.** Neither pentagon orientation can support complete exact Case XII on this Hamilton exterior with forbidden pair \(\{eX,eW\}\), at any shore order. For every row allowed by Note 436, equation (8), a new BF row of forbidden type \([eW]\) or \((eX)(eW)\) uses exactly the six original complete shore matchings, one in each labelled occurrence.

Write the old row as \(P=eX\), \(R=eY:C\), \(K=Y\), \(J=X\), \(E=F=e\), where \(E=F=e\) denotes only their terminal boundaries. Note 436 fixes
\[
K:Y;\ X:A,Z:c,W:a,Cu_3,Bu_4,bu_5;\ p_1,p_2,
\]
and \(J:X;\ Y:C,Z:c,W:a,bu_5\). Both \(E,F\) take \(Y:c,Z:a,W:b\); the triple \(P=eX\) has root \(A\) or \(B\). Edge load two at \(X,A,B,C\) leaves four labelled possibilities, but only three distinct shore-port profiles. Relabel the two singleton-\(e\) occurrences so that \(E\) uses \(p_3,p_4,p_5\):
\[
\begin{array}{c|c|c|c|c|c}
\text{case}&P\text{ root}&K&J&E&F\\ \hline
A_1&A&12&23&345&145\\
A_2&A&12&13&345&245\\
B_1&B&12&23&345&145\\
B_2&B&12&24&345&135.
\end{array}                                                    \tag{1}
\]
Here \(12\) means ports \(p_1,p_2\); \(P,R\) use no proper port, and \(E,F\) both select shore terminal \(e\). To check exhaustiveness directly: when \(P:A\), both \(E,F\) must take \(X:B\), while one takes \(Cu_2,Au_1\) and the other takes \(Cu_3\) with either \(Au_2\) or \(Au_1\); \(J\) takes the remaining \(A\)-half. These are \(A_1,A_2\). When \(P:B\), one of \(E,F\) takes \(X:B,Au_1,Cu_2\), while the other takes \(X:A,Cu_2\) and either \(Bu_3\) or \(Bu_4\); \(J\) takes the other \(B\)-half. These are \(B_1,B_2\). All other marked and tree halves are fixed by Note 436, equation (8), and cubicity.

For cases \(A_1,B_1\), keep each matching's shore restriction and use these new exterior masks:
\[
\begin{array}{c|c|l|l|l}
&\text{marked terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P,R&X,Y,Z&W:a&Au_1,Cu_2,Bu_3,bu_4,cu_5&\varnothing\\
K&W&X:A,Y:c,Z:a&Cu_3,Bu_4,bu_5&p_1,p_2\\
J&W&X:A,Y:C,Z:c&au_1,Bu_4,bu_5&p_2,p_3\\
E&\varnothing&X:B,Y:C,Z:c,W:b&au_1,Au_2&p_3,p_4,p_5\\
F&\varnothing&X:B,Y:c,Z:a,W:b&Au_2,Cu_3&p_1,p_4,p_5.
\end{array}                                                    \tag{2}
\]
Both zero-port triples now have type \(eW:a\), while \(K,J\) have singleton type \(W\), so (2) is a forbidden \([eW]\) loop.

For case \(A_2\), use
\[
\begin{array}{c|c|l|l|l}
&\text{marked terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P&Y,Z,W&X:A&au_1,Cu_2,Bu_3,bu_4,cu_5&\varnothing\\
R&X,Y,Z&W:a&Au_1,Cu_2,Bu_3,bu_4,cu_5&\varnothing\\
K&W&X:A,Y:c,Z:a&Cu_3,Bu_4,bu_5&p_1,p_2\\
J&X&Y:C,Z:c,W:a&Au_2,Bu_4,bu_5&p_1,p_3\\
E&\varnothing&X:B,Y:C,Z:c,W:b&au_1,Au_2&p_3,p_4,p_5\\
F&\varnothing&X:B,Y:c,Z:a,W:b&Au_1,Cu_3&p_2,p_4,p_5.
\end{array}                                                    \tag{3}
\]
The triples are now the two forbidden types \(eX,eW\); the singleton boundaries are \(W,X,e,e\). Thus (3) is a forbidden double-\(T\) row \((eX)(eW)\).

For case \(B_2\), use
\[
\begin{array}{c|c|l|l|l}
&\text{marked terminals}&\text{marked halves}&\text{tree halves}&\text{proper ports}\\ \hline
P&X,Y,Z&W:a&Au_1,Cu_2,Bu_3,bu_4,cu_5&\varnothing\\
R&X,Y,Z&W:b&au_1,Au_2,Cu_3,Bu_4,cu_5&\varnothing\\
K&W&X:A,Y:c,Z:a&Cu_3,Bu_4,bu_5&p_1,p_2\\
J&W&X:A,Y:C,Z:c&au_1,Bu_3,bu_5&p_2,p_4\\
E&\varnothing&X:B,Y:c,Z:a,W:b&Au_1,Cu_2&p_3,p_4,p_5\\
F&\varnothing&X:B,Y:C,Z:c,W:a&Au_2,bu_4&p_1,p_3,p_5.
\end{array}                                                    \tag{4}
\]
Here the two zero-port triples are \(eW:a,eW:b\), and (4) is again a forbidden \([eW]\) loop.

The port columns of (2), (3), and (4) agree **label by label** with their respective columns of (1); hence every displayed exterior matching glues to its original complete shore matching. For a compact edge-load check, at \(u_1,\ldots,u_5\) the three incident edge-label pairs \((\text{left half},\text{right half},p_i)\) are respectively
\[
\begin{array}{c|ccccc}
A_1,B_1&(JE,PR,KF)&(EF,PR,KJ)&(KF,PR,JE)&(KJ,PR,EF)&(KJ,PR,EF)\\
A_2&(PE,RF,KJ)&(JE,PR,KF)&(KF,PR,JE)&(KJ,PR,EF)&(KJ,PR,EF)\\
B_2&(RJ,PE,KF)&(RF,PE,KJ)&(RK,PJ,EF)&(RK,PF,JE)&(KJ,PR,EF).
\end{array}                                                    \tag{5}
\]
The marked terminal pairs in (2)–(4), together with the two marked half-edge pairs in each column, partition the six labels at every marked subdivision. The same holds at all six original prism vertices; for example, case \(B_2\) gives \(PE,RF,KJ\) at \(A\), \(PE,RK,JF\) at \(C\), and \(PJ,RK,EF\) at \(B\). Thus every exterior edge has load two, and each label chooses exactly one incident edge at every exterior vertex. The retained shore edges already have load two in the original genuine row. The resulting six **complete** perfect matchings realize the stated forbidden BF types.

The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) has neither \([eW]\) nor a double-\(T\) row. Therefore the \(S_2\) mixed row required by exact Case XII cannot exist. Together with Note 436's \(S_1\) exclusion, this closes \(\{eX,eW\}\) for the Hamilton two-spoke exterior. [Note 437](437-the-surviving-hamilton-x-w-row-has-both-forbidden-loops.md) remains a real example showing that the earlier first-exit gate is sharp; its port profile is \(A_1\), and the recompletion (2) gives a shorter forbidden-loop witness even with its six shore restrictions held fixed. [Note 441](441-the-last-hamilton-prism-forbidden-pair-has-no-exact-case-xii-support.md) subsequently closes the remaining \(\{eX,eZ\}\) pair for this same exterior. Other exteriors and Berge–Fulkerson remain open. This is a hand proof awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)
