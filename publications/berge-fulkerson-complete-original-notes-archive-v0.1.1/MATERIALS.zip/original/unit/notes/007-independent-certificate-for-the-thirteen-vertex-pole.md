> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Independent certificate for the thirteen-vertex pole

The explicit pole in Note 005 has now been checked by a second implementation
that does not call the earlier enumeration code.

The independent program scans proper-edge subsets and forces semiedges to
enumerate perfect matchings; uses a capacity-pruned nondecreasing search for
six-matching double covers; quotients boundary labels by brute-force
\(S_6\) colour permutations; and constructs both directions of the
capacity-two/A-type correspondence as explicit finite sets.

It reproduces:

\[
31\text{ perfect matchings},\qquad
177\text{ BF covers},\qquad
40\text{ boundary types},\qquad
6\text{ covers of type }(12345).
\]

The singleton class sizes are \((2,3,2,3,3)\).  Among their 108
transversals, exactly six have edge capacity at most two.  The six BF covers
constructed from those transversals are equal, witness by witness, to the
complete set of six \((12345)\) covers found in the double-cover search.
The full type-multiplicity census agrees with the original program and has
SHA256

`d44ddcc00c7368140aab2ca5f4f9133f0c037e3604a5b2a25eeae45b77c3e051`.

The verifier is
`scratch/worker-verify/independent_n13_bf_certificate.py` and runs with

```text
uv run --python 3.12 units/berge-fulkerson/scratch/worker-verify/independent_n13_bf_certificate.py
```

This certifies only the fixed thirteen-vertex pole.  It does not prove the
general capacity-two conjecture.

