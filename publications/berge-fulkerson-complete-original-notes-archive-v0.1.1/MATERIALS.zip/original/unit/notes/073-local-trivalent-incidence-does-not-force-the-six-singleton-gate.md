> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local trivalent incidence does not force the six-singleton gate

The six-singleton obstruction isolated in
[Note 072](072-uniform-perfect-matching-order-does-not-force-the-six-singleton-covering-design.md)
cannot be proved from the two endpoints of a triple-hit edge.  For the
canonical failed \(D_5\) pivot star, every singleton triple that can occur on
one proper edge is compatible with the local trivalent equations at both
endpoints.  Pairwise symmetric-difference switches among the three hitting
matchings also avoid those endpoints and do not create a missing BF row.

The first genuinely stronger interface is global: a boundary-preserving
matching replacement must be aligned, component by component, with a
companion matching from another BF row.

## The eight surviving hit patterns

Use the singleton identities and four singleton quadruples of Note 072:

\[
 U=\{a_1,a_2,a_4,a_5,x,y\},
\]

\[
\begin{aligned}
A_s&=\{a_1,x,a_4,a_5\},&
B_s&=\{a_1,a_2,x,a_4\},\\
C_s&=\{a_1,a_2,a_4,a_5\},&
D_s&=\{a_2,y,a_4,a_5\}.
\end{aligned}                                      \tag{1}
\]

Every set in (1) has load at most two on every proper edge, because it is
the singleton part of a six-matching double-cover row.  Hence a three-subset
of \(U\) can be the complete \(U\)-hit set of an edge only if it is contained
in none of the four sets in (1).  The possibilities are exactly

\[
\begin{array}{c|c}
\text{one extension and two anchors}
 &a_1a_2y, a_1a_4y, a_1a_5y, a_2a_5x\\
\text{two extensions and one anchor}
 &a_1xy, a_2xy, a_4xy, a_5xy.
\end{array}                                        \tag{2}
\]

No four-subset of \(U\) has all its triples in (2), so every proper edge has
\(U\)-load at most three.

Let the fourteen local identities be the six elements of \(U\) and the
eight triple tokens from the four pivot rows.  A legal proper-edge signature
is a subset meeting each complete six-token row in exactly two occurrences.
There are \(147\) such signatures.  For every hit set \(H\) in (2), there
are three pairwise disjoint legal signatures \(e,f,g\) that partition all
fourteen identities and satisfy \(e\cap U=H\).  For example,

\[
\begin{array}{c|l|l|l}
H&e&f&g\\ \hline
a_1a_2y
 &a_1,a_2,r_{45},y
 &q_A,q_C,q_D,r_{15},r_{23},r_{34},x
 &a_4,a_5,q_B\\
a_1xy
 &a_1,r_{15},r_{34},x,y
 &a_5,q_B,q_C,q_D,r_{23},r_{45}
 &a_2,a_4,q_A.
\end{array}                                        \tag{3}
\]

Using the same partition at each endpoint of \(e\), with separate copies of
the \(f\)- and \(g\)-halfedges, makes every matching identity choose exactly
one incident edge while every pivot row has local load \((2,2,2)\).
Therefore the endpoint equations do not exclude any of the eight possible
triple hits.  The complete finite check is frozen in the
[local-incidence bundle](../computations/bundles/canonical-triple-hit-local-incidence-boundary/README.md).

## Why the immediate exchange does not move the hit

Suppose \(M_1,M_2,M_3\in U\) all contain \(e=uv\).  For every pair,
\(M_i\triangle M_j\) omits \(e\) and has no edge incident with \(u\) or
\(v\), because both matchings already use \(e\) there.  Its alternating
components are proper cycles disjoint from the endpoints.  Switching only
among the three hitting matchings therefore preserves the triple hit and
cannot supply the missing row by a local endpoint argument.

The needed replacement condition is componentwise.  Suppose a transported
BF row contains a singleton matching \(P'\), while the desired member of
\(U\) is a same-boundary matching \(P\).  Replacing \(P'\) by \(P\) keeps
the row sum if a companion matching \(N\) can be replaced by

\[
 \chi_{N'}=\chi_N+\chi_{P'}-\chi_P.                 \tag{4}
\]

Since \(P\triangle P'\) is a union of proper alternating cycles, (4) is a
perfect matching precisely when, on every component,

\[
 N\cap(P\triangle P')=P\cap(P\triangle P').        \tag{5}
\]

This is a cross-row, all-component companion-alignment condition.  The
column saturation and row transports of
[Notes 055](055-half-load-column-saturation-and-case-xii-compression.md)
and
[057](057-overlap-cells-transport-singleton-fibres-into-d5.md)
do not provide (5).

## Exact sufficient reuse target

For the canonical \(U\), it is enough to realize the following three
singleton quadruples using these exact perfect-matching identities:

\[
\begin{array}{c|c}
(35,23)&\{a_2,a_5,x,y\},\\
(13,34)&\{a_1,a_4,x,y\},\\
(35,12)&\{a_1,a_2,a_5,y\}.
\end{array}                                        \tag{6}
\]

They add the three unique minimum missing pairs from Note 072 and force
\(\alpha(G_U)\le2\), after which the six-singleton counting contradiction
applies.  All three boundary cells in (6) belong to Case XII; exact support
supplies some witnesses in them, but not literal reuse of the identities in
\(U\).

Hence local cubic incidence does not decide the real Case-XII statement.
The remaining positive problem is to prove the component-aligned splice (5),
or an equivalent cross-half-load witness-reuse theorem, from the complete
perfect-matching family of one cubic 5-pole.
