> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The allowed ea-cd switch forces the opposite right-row route

> **Subsequent refinement:** [Note 310](310-the-right-row-excludes-the-h-based-singleton-hall-block.md)
> uses both real rows' local edge loads to exclude the singleton
> \(H\)-based Hall block left open below. The corrected route and
> \(H\)-base theorem here are unchanged.

**Correction of [Notes 305 and 307](305-every-tight-hall-corridor-must-contain-the-i-port-base.md).**
The symbolic pentagon used throughout the central-path analysis is
\(S=e-a-b-d-c-e\). Both \(ea\) and \(cd\) belong to \(S\). The published
[Case-XII appendix](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf)
contains every \(S\)--\(S\) type, including \((ea)(cd)\). For example,
the consistent relabelling
\[
                 (e,a,b,d,c)=(1,3,5,2,4)                    \tag{1}
\]
sends \(S\) to \(\{13,14,24,25,35\}\) and sends \((ea)(cd)\) to
\((13)(24)\), explicitly present in the Case-XII \(L^*\) table.
Note 305 instead used \((1,2,3,4,5)\), which sends the symbolic
pentagon to the *opposite* five-cycle. Its exclusion of the
\(E\)--\(I\) route, and the ensuing \(I\)-base Hall conclusion,
are invalid. Note 307 depended on that exclusion and does not
exclude the right \(ad\) row.

Work in the same complete exact-Case-XII central-path, \(R_0=DJ\),
\(3{:}2\) one-edge-near-bipartite setting as [Notes 301–304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md).
There are real left \((ea)(ac)\) and right \((ea)(ad)\) rows. In the
right row let \(X\), \(U\), and \(Q\in\{Y,V\}\) have shore profiles
\[
\begin{array}{c|c|c}
 &\text{ports}&\text{mark and }g\\\hline
X&\varnothing&t_{ew},g\\
U&EJ&E,g\\
Q&ID&t_{ev},g\notin Q.
\end{array}                                                     \tag{2}
\]

**Theorem 1 (corrected route).** For each \(Q=Y,V\), the two shore
paths of \(U\triangle Q\) pair
\[
                         \boxed{EI\mid DJ}.                   \tag{3}
\]
The \(E\)--\(I\) path contains \(t_{ev},g\). Switching its complete
\(e\)--\(b\) continuation between the two full-pole row matchings
gives a genuine BF row of the **allowed** type \((ea)(cd)\), and
produces actual shore matchings with profiles
\[
          (IJ,t_{ev},g\notin M),\qquad (ED,E,g).              \tag{4}
\]

**Proof.** [Note 301's matching-balance argument](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
places both \(t_{ev}\) and \(g\) on the \(E\)-starting path of
\(U\triangle Q\). If this path ended at \(D\), switching it into
\(U\) would give a \(DJ,t_{ev},g\notin M\) matching, contrary to
[Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md).

Suppose it ended at \(J\). The other shore path would pair \(D,I\)
and avoid \(g,t_e\). Switch that path into \(U\), obtaining an
actual matching \(F\) with ports \(E,I,D,J\) and selected \(E,g\).
Compare \(F\) with the actual zero-port \(X\). The \(E\)-starting
path of \(F\triangle X\) contains \(t_{ew}\); the other path avoids
\(g,t_{ew}\), since \(g\) is common. Switching the latter into
\(X\) produces a two-proper-port \((g,t_{ew})\) matching with its
ports among \(I,D,J\). [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md)
allows only \(HJ\) in that complete fibre, a contradiction. Thus the
\(E\)-path ends at \(I\), proving (3).

The right-row exterior sends \(e\) to \(E\) and \(b\) to \(I\), as
traced in Note 305. Switching the resulting complete \(e\)--\(b\)
component preserves the six-matching load-two equation. The old
boundaries \(U:bce\), \(Q:a\) become \(c\), \(abe\), while
\(X:bcd\) stays fixed. The two triple missing pairs are \(ea\)
and \(cd\), so the new type is \((ea)(cd)\). On the shore, switching
the \(EI\) path in \(U\) replaces \(E,g\) by \(I,t_{ev}\), leaving
\(J\); switching it in \(Q\) does the reverse and leaves \(D\).
This proves (4). \(\square\)

**Theorem 2 (corrected Hall anchor).** In the noncollision branch
of [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md),
every tight \(DJ\) Hall witness
\(S_H\subseteq B\setminus\{x,y,v\}\) contains the base \(h\) of
port \(H\). The base \(i\) of port \(I\) need not be forced by the
current argument. If the shore is simple and \(|S_H|=1\), then
\(S_H=\{h\}\) and \(h\) has incidences \(H,hd,hj\).

**Proof.** Let \(T=N_K(S_H)\), so \(|T|=|S_H|+1\) and \(d,j\in T\).
The first, independent part of [Note 306](306-both-i-and-h-bases-belong-to-every-dj-hall-witness.md)
shows that a left-row \(HJ,g,t_{ew}\) matching \(L\) and its
opposite \(ID,t_{ev},g\notin M\) matching \(W\) have shore paths
\(DI\mid HJ\), with both \(g,t_{ew}\) on the \(D\)--\(I\) path.

Assume \(h\notin S_H\). Then \(L\) matches every vertex of \(S_H\)
through \(K\), saturating \(T\setminus\{j\}\). If \(i\notin S_H\),
\(W\) likewise saturates \(T\setminus\{d\}\). The alternating
path starting at \(D\) is then trapped in \(S_H\cup T\) until it
ends at \(J\), contradicting the \(DI\mid HJ\) pairing. If instead
\(i\in S_H\), follow the path from \(D\): \(L\)-edges from
\(T\setminus\{j\}\) return to \(S_H\), and \(W\)-edges from
\(S_H\setminus\{i\}\) return to \(T\). The path can end at \(I\)
or \(J\), but cannot leave the corridor before then. Its actual
\(D\)--\(I\) route contains \(g,t_{ew}\), which are outside
\(K\), another contradiction. Hence \(h\in S_H\). For a singleton
witness, \(T=\{d,j\}\); cubicity gives the stated incidences.
\(\square\)

In particular \(h\notin\{x,y,v\}\). In the minimum-host setting,
[Note 290's cut identity](290-two-port-closure-separates-the-remaining-three-two-row-loads.md)
still makes every inclusion-minimal non-singleton Hall witness a
six-, eight-, or ten-edge-cut block. The four-edge case is now
precisely the possible one-vertex \(H\)-based block, not an
\(I\)-based block.

The right \(ad\) orientation and a one-vertex \(H\)-based Hall
barrier remain possible under these deductions. [Note 304's](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md)
actual 20-vertex six-pole has precisely that Hall shape, though it
fails other exact-support fibres. Its existence does not certify
the full Case-XII relation. No local enumeration or OMEN run was
used; the corrected route and Hall argument remain hand proofs
dependent on the cited complete-fibre exclusions.
