> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Z\)-forbidden Hamilton \(C_7\) row forces a forbidden double triple

Continue the fixed marked Hamilton exterior, six matching labels and necessary signatures of [Note 466](466-the-x-z-forbidden-hamilton-row-must-root-at-y5.md). In \(C_7\), the old genuine \((eX)(eY)\) row has \(P=eX\) rooted at \(X:1\), \(R=eY\) rooted at \(Y:5\), and singleton \(K=Y\) on \(X:4,Z:2,W:6,1u_1,3u_3,5u_5,p_2,p_4\). We keep each complete shore matching restriction and exclude every labelled port phase with two exterior recompletions.

Put \(S=\{J,a,b\}\). The old \(X\) pairs are \((RJ,P\bar\lambda,K\lambda)\), where \(\{\lambda,\bar\lambda\}=\{a,b\}\). At vertex \(1\), \(1u_1=RK\) gives old \(Y:1=S\setminus\{\bar\lambda\}\), hence \(Y:5=R\bar\lambda\). Write the old pairs on \(u_1,u_2\) as
\[
u_1=(RK,P\beta,S\setminus\{\beta\}),\qquad
u_2=(R\gamma,P\rho,K\alpha),
\quad \{\gamma,\rho,\alpha\}=S.                        \tag{1}
\]
Write \(Z:2=K\rho'\). Vertex \(2\) gives \(\{\beta,\gamma,\rho'\}=S\). Since the old \(Z,W\) terminal pairs are \(PR\), vertex \(6\) gives \(W:3=S\setminus\{\rho'\}\). Vertex \(3\) has \(u_3:3=RK\), so its old partition forces \(\rho=\rho'\). Comparing the two braces then forces \(\beta=\alpha\). Thus the old proper-port pairs begin
\[
                   (p_1,p_2)=(S\setminus\{\alpha\},K\alpha). \tag{2}
\]
Write the remaining old tree pairs as
\[
u_3=(RK,P\theta,S\setminus\{\theta\}),\quad
u_4=(R\epsilon,P\phi,K\eta),\quad
u_5=(K\xi,PR,S\setminus\{\xi\}).                       \tag{3}
\]
The old vertex-4, \(u_4\), and vertex-5 partitions say precisely
\[
\{\lambda,\theta,\epsilon\}=S,
\qquad \{\epsilon,\phi,\eta\}=S,
\qquad \{\bar\lambda,\phi,\xi\}=S.                       \tag{4}
\]
Consequently
\[
(p_1,p_2,p_3,p_4,p_5)=
(S\setminus\{\alpha\},K\alpha,S\setminus\{\theta\},K\eta,S\setminus\{\xi\}),
\quad e=ab.                                               \tag{5}
\]
If \(\xi=J\), equations (4) force \(\phi=\lambda\) and \(\theta=\eta\). If \(\xi\ne J\), they force \(\xi=\lambda,\phi=J,\theta=J,\eta=\lambda\). These are all old phases; \(\alpha\) remains arbitrary in \(S\).

## \(\xi=J\): a forbidden double-triple recompletion

In this case (5) is \((S\setminus\{\alpha\},K\alpha,S\setminus\{\eta\},K\eta,ab)\). Let \(\{\alpha,\beta,\gamma\}=S\); either order of \(\beta,\gamma\) will do. Put, in first-half/second-half/port order,
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\alpha,S\setminus\{\alpha\})
&(P\beta,R\gamma,K\alpha)
&(PK,R\eta,S\setminus\{\eta\})
&(S\setminus\{\eta\},PR,K\eta)
&(KJ,PR,ab),
\end{array}                                                \tag{6}
\]
and, in terminal/first-half/second-half order,
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,ab,PK)&(PR,KJ,ab)&
(PK,R\gamma,S\setminus\{\gamma\})&
(PR,S\setminus\{\gamma\},K\gamma).
\end{array}                                                \tag{7}
\]
The original vertices \(1,\ldots,6\) see
\[
(PR,ab,KJ),\quad
(K\alpha,P\beta,R\gamma),\quad
(R\gamma,PK,S\setminus\{\gamma\}),\quad
(R\eta,PK,S\setminus\{\eta\}),\quad
(PR,ab,KJ),\quad
(PR,S\setminus\{\gamma\},K\gamma).                   \tag{8}
\]
All triples in (6)--(8) partition the six labels. The port pairs are (5) and the terminals are \(e=ab,X=RJ,Z=PK,Y=W=PR\), the forbidden \((eX)(eZ)\) type.

## \(\xi=\lambda\): the other double-triple template

Here (5) is \((S\setminus\{\alpha\},K\alpha,ab,K\lambda,S\setminus\{\lambda\})\). Use
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,K\alpha,S\setminus\{\alpha\})
&(PR,S\setminus\{\alpha\},K\alpha)
&(PR,KJ,ab)
&(R\bar\lambda,PJ,K\lambda)
&(R\lambda,PK,S\setminus\{\lambda\}),
\end{array}                                                \tag{9}
\]
\[
\begin{array}{c|cccc}
&X&Y&Z&W\\ \hline
&(RJ,K\bar\lambda,P\lambda)&
(PR,S\setminus\{\bar\lambda\},K\bar\lambda)&
(PK,S\setminus\{\alpha\},R\alpha)&
(PR,K\alpha,S\setminus\{\alpha\}).
\end{array}                                                \tag{10}
\]
At vertices \(1,\ldots,6\) the incident pairs are
\[
(PR,K\bar\lambda,S\setminus\{\bar\lambda\}),\quad
(K\alpha,PR,S\setminus\{\alpha\}),\quad
(S\setminus\{\alpha\},PR,K\alpha),\quad
(KJ,R\bar\lambda,P\lambda),\quad
(PJ,R\lambda,K\bar\lambda),\quad
(PK,R\alpha,S\setminus\{\alpha\}).                    \tag{11}
\]
Again every triple partitions the labels, the port column in (9) equals (5), and the terminals give forbidden \((eX)(eZ)\).

Both recompletions therefore glue to the **same six complete shore matchings**, one occurrence each, for any shore. No exact-Case-XII pole with this fixed marked exterior can have a genuine \(C_7\) row. Together with [Notes 467--473](473-the-x-z-hamilton-c6-row-forces-a-forbidden-double-triple.md), only \(C_3\) remains among the twelve necessary signatures for forbidden \(\{eX,eZ\}\). The path reflection gives the corresponding result for \(\{eY,eW\}\). This conditional hand proof awaits independent review and does not settle \(C_3\), other marked exteriors, full exact Case XII, or Berge--Fulkerson. \(\square\)
