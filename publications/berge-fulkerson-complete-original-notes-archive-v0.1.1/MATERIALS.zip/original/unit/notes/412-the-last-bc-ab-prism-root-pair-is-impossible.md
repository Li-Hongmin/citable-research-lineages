> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The last \((e\,bc)(e\,ab)\) prism root pair is impossible

Use the two-spoke prism exterior with forbidden \(e\)-labels \(AC,bc\), as in [Notes 408–411](411-the-indirect-bc-and-ab-b-prism-root-pair-is-impossible.md). Let an actual six-perfect-matching BF row have forbidden triple \(P=e\,bc:b\) and allowed triple \(R=e\,ab:a\). Their zero-port rooted tree masks on \((u_1,\ldots,u_5)\) are \((A,C,a,B,c)\) and \((B,C,A,b,c)\), respectively. No shore order, cycle, or path-length condition is imposed.

> **Last-root exclusion.** This row is impossible for either exact-Case-XII allowed pentagon
> \[
> S_1=e-ab-AC-bc-Cc-e,\qquad S_2=e-ab-bc-AC-Cc-e.           \tag{1}
> \]

**The forced exterior switch.** Name singleton-\(ab\) by \(K\), singleton-\(bc\) by \(J\), and singleton-\(e\) by \(D_0,D_1\). Because \(P=e\,bc\) is forbidden, the \(ab\)-starting path of \(R\triangle K\) must end at \(Cc\), the only other allowed \(e\)-label. If \(K\) takes \(au_3\), the route through \(Bu_2,Cc:C\) uses both endpoints of the \(AC\) mark and cannot cover its subdivision; the route through \(Bu_4\) ends at forbidden \(bc\). Hence \(K\) takes \(au_5,Cc:c\), and the allowed path is wholly exterior:
\[
ab-t_{ab}-a-u_5-c-t_{Cc}-Cc.                              \tag{2}
\]
The remaining mark and vertex slots force \(K:bc:b,AC:C\). It covers \(A\) through \(Au_1\) or \(Au_3\), and \(B\) through one of \(Bu_1,Bu_2,Bu_4\), with \(Au_1\) and \(Bu_1\) incompatible in one matching. Thus there are five possible \((A,B)\) choices. Switching (2) gives an allowed triple \(R'=e\,Cc:c\) with exactly the same complete shore matching as \(R\).

At the \(bc\) subdivision, \(P,K\) saturate \(bc:b\) and \(R,J\) saturate the terminal, so **both** singleton-\(e\) occurrences take \(bc:c\). At \(c\), \(P,R\) saturate \(cu_5\) and \(K\) takes \(Cc:c\), forcing \(J:Cc:c\). Since \(P,R\) saturate \(Cu_2\) and \(K\) takes \(AC:C\), the matching \(J\) takes \(AC:C\). Consequently both singleton-\(e\) occurrences take the marked halves \(AC:A,Cc:C,bc:c\).

There are two possibilities at \(b\). If \(J\) takes \(bu_4\), it takes \(ab:a\), and both singleton-\(e\) occurrences take \(ab:b\). Name the one using \(au_3,p_5\) by \(F\); then
\[
F:\quad AC:A,\ Cc:C,\ bc:c,\ ab:b,\ au_3,\ p_5.          \tag{3}
\]
If \(J\) takes \(ab:b\), the singleton-\(e\) occurrence using \(ab:a\), call it \(E\), must cover \(b\) by \(bu_4\) and use \(p_5\); it has
\[
E:\quad AC:A,\ Cc:C,\ bc:c,\ ab:a,\ bu_4,\ p_5.          \tag{4}
\]
The assertions about \(p_5\) follow directly: \(P,R\) saturate \(cu_5\), while \(K\) occupies one \(au_5\) slot. In the first case the two \(D_i\) split the remaining \(au_3,au_5\) slots; the one on \(au_3\) uses \(p_5\). In the second case \(E\) already covers \(a,c\) at marks, so it uses \(p_5\).

**Exclude \(S_1\).** The \(e\)-starting path against \(R=e\,ab\) must end at \(AC\), while that against \(R'=e\,Cc\) must end at \(bc\); both comparisons have the same shore path by (2). Let \(q\) be its proper endpoint. For the first case (3), the two required exterior arms exit as follows:
\[
\begin{array}{c|ccc}
F\text{ at }B&Bu_1&Bu_2&Bu_4\\\hline
R\text{ to }AC&p_4&p_4&p_1\\
R'\text{ to }bc&p_2&p_1&p_2
\end{array}                                                     \tag{5}
\]
The first arm follows \(AC-t_{AC}-A-u_3-a-t_{ab}-b-u_4\); the second follows \(bc-t_{bc}-c-t_{Cc}-C-u_2\). Both continue through \(B-u_1-p_1\) only when their displayed \(B\)-choice requires it. No column has equal endpoints. In the second case (4), \(E\) takes \(Bu_1\) or \(Bu_2\) because it already uses \(bu_4\). The \(AC\)-arm of \(R\triangle E\) exits at \(p_3\), whereas the \(bc\)-arm of \(R'\triangle E\) exits at \(p_2\) or \(p_1\), respectively. Again the same \(q\) would have to take two values. Thus \(S_1\) is impossible.

**Exclude \(S_2\).** In both cases (3)–(4), the displayed singleton-\(e\) occurrence takes \(bc:c,p_5\). Against \(R=e\,ab\), its \(p_5\)-arm is \(p_5-u_5-c-t_{bc}-bc\). Under \(S_2\), \(bc\) is the only allowed replacement for \(e\), so the shore \(e\)-path must end at \(p_5\). Switch this complete \(e\)--\(bc\) path. In both cases the new allowed triple \(T=ab\,bc\) has tree mask \((B,C,A,b,p_5)\), marked halves \(ab:a,bc:c\), and terminals \(e,AC,Cc\). The switched singleton \(D'\) has terminal \(bc\) and takes \(cu_5\).

The \(ab\)-starting path of \(T\triangle K\) must end at \(AC\), since endings at \(e,Cc\) would give forbidden \(e\,bc,Cc\,bc\) alongside \(P\). Switch it, obtaining allowed \(U=AC\,bc\) and singleton-\(AC\) \(K'\). Independently of \(K\)'s five \((A,B)\) choices, \(U\) has \(ab\) and \(Cc\) terminals, takes \(AC:C,bc:c,au_5\), and \(K'\) takes \(ab:a\).

For a direct audit of all five choices, the \(ab\)-arm exits at \(p_5\), and the \(AC\)-arm exits at \(p_3,p_2,p_2,p_1,p_2\), respectively, in the following order. The table records the slots after that path is switched:
\[
\begin{array}{c|cccc|c}
K:(A,B)&U:u_1&U:u_2&U:u_3&U:u_4&K':A\\\hline
(Au_1,Bu_2)&A&B&p_3&b&Au_3\\
(Au_1,Bu_4)&B&p_2&A&b&Au_1\\
(Au_3,Bu_1)&B&p_2&A&b&Au_3\\
(Au_3,Bu_2)&p_1&B&A&b&Au_3\\
(Au_3,Bu_4)&B&p_2&A&b&Au_3
\end{array}                                                     \tag{6}
\]

If \(J:ab:b\), the switched singleton \(D'=E'\) retains \(ab:a\) from (4). Thus \(U\triangle E'\) contains the wholly exterior path
\[
bc-t_{bc}-c-u_5-a-t_{ab}-ab,                             \tag{7}
\]
which changes \(U=AC\,bc\) to forbidden \(AC\,ab\) alongside \(P=e\,bc\).

If \(J:bu_4\), the switched singleton \(D'=F'\) retains \(AC:A,Cc:C,ab:b,au_3\) from (3). If \(U\) uses \(Au_3\), then \(U\triangle F'\) has the wholly exterior \(bc\)--\(Cc\) path
\[
bc-t_{bc}-c-u_5-a-u_3-A-t_{AC}-C-t_{Cc}-Cc.          \tag{8}
\]
If \(U\) instead uses port \(p_3\), this occurs only when \(K\) uses \(Au_1,Bu_2\). Then the \(bc\)-arm of \(U\triangle F'\) exits at \(p_3\), and its \(Cc\)-arm exits at \(p_1\) or \(p_2\), according to \(F'\)'s \(B\)-choice. Exact support forces those arms to join. In either case, switching the complete \(bc\)--\(Cc\) path gives allowed \(V=AC\,Cc\) with
\[
V:\quad AC:A,\ Cc:C,\ au_3,\ cu_5,
       \quad ab\text{ and }bc\text{ terminals}.                \tag{9}
\]
Except when \(K\) initially uses \(Au_1,Bu_4\), its switched matching \(K'\) uses \(Au_3\). Then (9) gives the wholly exterior alternating path
\[
AC-t_{AC}-A-u_3-a-t_{ab}-ab,                            \tag{10}
\]
which replaces \(V=AC\,Cc\) by forbidden \(ab\,Cc\). In the exceptional \(Au_1,Bu_4\) case, the preceding switches leave \(V\) on \(Bu_1,bu_4\) and \(K'\) on \(Au_1,Bu_4,bc:b\); their wholly exterior path is
\[
AC-t_{AC}-A-u_1-B-u_4-b-t_{bc}-bc.                     \tag{11}
\]
It replaces \(V\) by forbidden \(bc\,Cc\). Throughout, the unchanged \(P=e\,bc\) is forbidden too. All switches use complete perfect matchings and preserve load two. This excludes \(S_2\) and proves the theorem. \(\square\)

This is a row exclusion for the specified marked-prism placement, not a proof of the full Berge–Fulkerson conjecture. The hand derivation awaits independent proof review.
