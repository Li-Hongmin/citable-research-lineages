> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Bridge peeling and the unique smallest cap incompatible with Case XII

Fix the complementary pentagons of missing-pair states
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
For a cubic five-pole \(H\), let \(\mathcal B(H)\) denote its **complete actual** six-perfect-matching BF boundary support. The following statements use whole rows, not a selection of matching masks. They refine the pentagon completion in [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md); they do not exclude a bridge-free exact-Case-XII pole.

## A one-terminal bridge is an exact support-preserving factor

**Bridge theorem.** Let \(H\) be a connected cubic five-pole with an actual BF row. If \(\mathcal B(H)\) contains all twenty-five \(S\)--\(T\) pair types, then every proper bridge of \(H\) separates the terminals \(1+4\). If \(e\) is such a bridge and \(C\) is its one-terminal side, remove \(C\) and replace \(e\) at its other endpoint by the same terminal semiedge, obtaining \(H'\). Then
\[
                         \boxed{\mathcal B(H')=\mathcal B(H).}       \tag{1}
\]

**Proof.** A bridge with no terminals on one side is impossible in any BF-covered pole. Cubic degree parity makes that side odd, so each perfect matching must use the bridge, giving load six instead of two.

Suppose a side \(C\) of a bridge has exactly two terminals \(a,b\). It has odd order because its three boundary edges are \(e,s_a,s_b\). In every perfect matching, an odd number of these three edges is used. A BF row uses each of the three boundary edges twice, for six occurrences altogether. Every one of its six matching slots must therefore use **exactly one** of the three edges. In particular no slot can contain both \(s_a,s_b\). The other three terminal labels contain an \(S\)-pair \(p\) and a \(T\)-pair \(q\), because neither five-cycle has a triangle. The required actual type \((p)(q)\) has two triple-boundary matchings containing both \(a,b\), a contradiction. Reversing the sides handles a \(3+2\) split. The zero-terminal argument handles \(0+5\); only \(1+4\) remains.

On a side \(C\) with the sole terminal \(s_i\), cubic parity makes \(|C|\) even. Every perfect matching therefore uses \(e\) and \(s_i\) together or neither. Restrict any BF row of \(H\) to the other side, replacing its use of \(e\) by \(s_i\): this is a BF row of \(H'\), so \(\mathcal B(H)\subseteq\mathcal B(H')\).

For the reverse inclusion, restrict one fixed actual BF row of \(H\) to \(C\). It is a six-matching BF row of a two-pole whose two boundary edges have the same two occurrence labels. Any permutation of the six labels makes those common labels an arbitrary prescribed two-set. Given an actual BF row of \(H'\), permute this fixed two-pole row so that its bridge labels equal the labels on \(s_i\) in the \(H'\) row, and glue slot by slot. Every internal edge and the restored bridge have load two. This yields an actual BF row of \(H\) with exactly the prescribed five-terminal boundary type, proving (1). \(\square\)

**Consequences.** Every minimum-order simple connected exact-Case-XII five-pole is proper-bridge-free: otherwise (1) gives a smaller pole with the same exact support. More quantitatively, if such a pole has a bridge, its one-terminal side has at least four vertices. Indeed, its order is even and two vertices would require two proper internal edges, impossible in a simple graph. Its bridge peel is again exact Case XII and has at least 33 vertices by Note 226, so
\[
\boxed{\text{a simple connected exact-Case-XII five-pole with a bridge has at least 37 vertices.}} \tag{2}
\]
This concerns arbitrary exact-support poles. The non-pentagonal side of a *minimum BF counterexample* is already bridge-free for the separate cyclic-connectivity reason in [Note 019](019-case-xii-minimality-and-bf-reduction-applicability-boundary.md).

## The five-cycle is the unique smallest incompatible cap

Call a connected simple cubic five-pole \(R\) a *cap* when its five semiedges are identified with those of \(H\) and glued to form a cubic graph. A shared BF boundary type is necessary and sufficient for the glued graph to have a BF cover: align the six occurrence slots and glue the two actual shore rows. The complete ordinary-pentagon relation is recalled in Note 226.

**Small-cap theorem.** Suppose \(\mathcal B(H)\) is exact Case XII. For every connected simple cap \(R\) on at most five vertices, the glued graph is BF-covered **unless** \(R\) is an ordinary five-cycle whose adjacent-terminal-pair states are exactly \(T\). In that exceptional case it is BF-uncovered. Thus the five-cycle in Note 226 is, up to its terminal order, the unique smallest connected simple cap incompatible with the exact relation.

**Proof.** Cubic degree counting makes the order of a five-pole odd, and a connected simple one on at most five vertices has order three or five. At order three its proper graph is a path. Its two end vertices carry two semiedges each, and its middle vertex one. The four Tait states are exactly the \(K_{2,2}\) cross pairs between the two end-port groups: colour the two path edges differently and independently exchange the two end colours. Since the forbidden state set \(T\) is a five-cycle and contains no four-cycle, at least one of these four states lies in \(S\). Double that Tait colouring to obtain an actual BF loop shared with \(H\).

At order five the connected proper graph has five edges and is unicyclic. If it contains a triangle, contract that triangle. Proper three-edge-colourings correspond in both directions: the three exterior edges of a coloured triangle have distinct colours, and any three distinct exterior colours extend uniquely across it. The contracted pole is the preceding three-vertex path, with the same five terminal colour patterns. Its Tait-state set contains a \(K_{2,2}\), so it shares an \(S\)-loop with \(H\).

If the proper graph has a four-cycle, the fifth vertex is a leaf. Let \(a,b\) be the two ports at the leaf and \(c\) a port at either cycle vertex adjacent to the leaf attachment. One colouring gives the four exterior colours of the square equal, with its edge colours alternating; the lonely pair is \(ab\). Another gives the attachment port and \(c\) one colour, and the two remaining square ports a second colour; colour the square edges in cyclic order by the second, third, first, third colours. The leaf ports receive the second and third colours in either order, giving lonely pairs \(ac\) and \(bc\). Hence the Tait-state set contains the triangle \(ab,ac,bc\). Since \(T\) has no triangle, one of these states lies in \(S\), again giving a common BF loop.

The remaining proper graph is a five-cycle. Its five Tait states are precisely its five adjacent-terminal pairs. If this state cycle is not \(T\), it has an edge in \(S\) and the same loop argument applies. If it is \(T\), the cap's complete BF relation consists of the all-terminal type and every loop/pair with both states in \(T\). Exact Case XII has none of those types. The gluing criterion proves BF noncoverage in this final case. \(\square\)

The bridge theorem uses the full positive \(S\)--\(T\) support; the cap theorem uses the five positive \(S\)-loops and the exact negative support. Neither gives an all-orders perfect-matching closure theorem for a bridge-free five-pole. A finite-order improvement beyond Note 226 therefore cannot come merely from replacing its five-cycle by a smaller connected simple cap.
