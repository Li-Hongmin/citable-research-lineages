> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Half-integral selector and the Petersen parity boundary

Choose one Tait colouring \((L_t,R_t,Q_t)\) for each edge of the boundary
pentagon, where \(Q_t\) is the third perfect matching.  If the five \(Q_t\)
cover every edge, define

\[
q(e)=|\{t:e\in Q_t\}|,\qquad x_0(e)=\frac{q(e)-1}{2}.
\]

At an internal cubic vertex, the positive incident \(q\)-values sum to five,
so they are \((3,1,1)\) or \((2,2,1)\).  Therefore the incident \(x_0\)-values
are \((1,0,0)\) or \((1/2,1/2,0)\).  Every semiedge has value one.  Thus
\(x_0\) is a nonnegative half-integral all-terminal 1-factor, and its
half-support is a disjoint union of internal cycles.  Giving the two selected
singleton matchings in each boundary class weight one half yields a genuine
fractional capacity-two selector.

For a half-support edge put

\[
A(e)=\{t:e\in Q_t\}\in\binom{[5]}2.
\]

The two half-support edges at a vertex have disjoint labels, so every support
cycle maps to a closed walk in \(KG(5,2)\), the Petersen graph.  Hence an odd
support cycle has length at least five.  This is the sharp local conclusion:
the Petersen graph itself has 5-cycles, so cubic matching equations alone do
not force even support.

Complete unlabelled order-13 enumeration gives

\[
59338\to6690\to6374\to318.
\]

Across the 318 exact-\(S\) skeletons, all 44,863 distinct third-matching
five-tuples were tested.  Of 16,236 tuples covering every edge, every one has
even half-support.  Moreover every skeleton admits a tuple with

\[
Q_0\triangle\cdots\triangle Q_4=E(H),
\]

so the half-support is empty, and an endpoint split yields a capacity-two
transversal.

This is a finite order-13 fact, not a general parity theorem.  Even support
also leaves a separate integer orientation problem: alternating-cycle
choices across the five singleton classes must balance edgewise, whereas
mod-two cancellation alone does not provide signs.

The exact programs are
`scratch/worker-proof/audit_n13_half_support_parity.py` and
`scratch/worker-proof/audit_n13_third_matching_cover.py`.

