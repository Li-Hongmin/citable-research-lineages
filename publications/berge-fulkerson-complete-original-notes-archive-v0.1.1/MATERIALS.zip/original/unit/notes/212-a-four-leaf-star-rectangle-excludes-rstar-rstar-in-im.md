> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-leaf star rectangle excludes two R-star shores in \(I_m\)

Use the genuine \(I_m\) two-five-cut connector of
[Note 210](210-two-star-rectangles-restrict-the-rstar-im-connector.md):
the odd shores have port sets
\[
 A^\circ:\{u_1,u_2,z,x,p\},\qquad
 B^\circ:\{u_1,u_2,z,y,q\}.
\]
The direct mark \(z\) joins \(A\) to \(B\); marks \(x,y\)
meet singleton \(w_1\), marks \(p,q\) meet singleton \(w_2\),
and \(u_i\) joins both shores and \(w_i\).  All BF types below
are types of **actual six-perfect-matching rows** of the complete
shore relations.  In particular, the claim is not about a
selected collection of boundary words.

\[
\boxed{\begin{gathered}
\text{If both }A^\circ,B^\circ\text{ have the complete Figure-7
Case-XIII }R^*\text{ relation,}\\
\text{the outer five-pole has all four BF loops }
[xy],[xq],[py],[pq].
\end{gathered}}                                               \tag{1}
\]
Consequently this shore pair is impossible in genuine exact
Case XII: its allowed BF loops form a five-cycle, which contains
no four-cycle on \(x,p,y,q\).

## A second star rectangle

Fix any private ports \(a\in\{x,p\}\) and
\(b\in\{y,q\}\).  Write \(a'\) and \(b'\) for their
respective *other* private ports, and put
\(K=\{u_1,u_2,z\}\).  [Note 210, (1)](210-two-star-rectangles-restrict-the-rstar-im-connector.md)
already proves
\[
 (ra)(sa)\in\mathcal B(A^\circ),\quad
 (rb)(sb)\in\mathcal B(B^\circ)
 \quad\Longrightarrow\quad[ab]\in\mathcal B(H)
 \qquad(r,s\in K, r\ne s).                                  \tag{2}
\]
The missing case is a star whose leaves are the other private
port and one shared port.  For every \(r\in K\),
\[
 \boxed{(aa')(ar)\in\mathcal B(A^\circ),\quad
 (bb')(br)\in\mathcal B(B^\circ)
 \quad\Longrightarrow\quad[ab]\in\mathcal B(H).}           \tag{3}
\]
Here \(\mathcal B\) denotes complete actual BF boundary support.

To prove (3), independently relabel the six occurrences of its
two genuine local rows as follows.  Each triple boundary is the
complement of its displayed missing pair in the relevant shore
port set.
\[
\begin{array}{c|c|c}
\text{slot}&A^\circ\text{ boundary}&B^\circ\text{ boundary}\\\hline
1&K&\{b'\}\\
2&(K\setminus\{r\})\cup\{a'\}&\{r\}\\
3&\{a'\}&K\\
4&\{r\}&(K\setminus\{r\})\cup\{b'\}\\
5,6&\{a\}&\{b\}
\end{array}.                                                   \tag{4}
\]
At a shared port \(r\), the \(A\)- and \(B\)-half labels
are \(14,23\); at either other shared port they are \(12,34\).
They are disjoint, so the residual label on both \(u_iw_i\)
is \(56\), while the terminal label at the direct \(z\)-mark
is also \(56\).  The private shore-half labels are
\[
 A:a=56,\ a'=23;\qquad B:b=56,\ b'=14.
\]
Give the singleton-side halves of both \(A\)-marks \(x,p\)
label \(14\), and those of both \(B\)-marks \(y,q\) label
\(23\).  At each \(w_i\), these two labels and \(u_iw_i=56\)
partition \([6]\).  They avoid their respective shore-half
labels at each subdivided mark.  Thus every connector vertex and
every mark subdivision vertex has exactly one incident edge in
each slot, and all six actual shore matchings glue with proper
edge load two.  The outer terminal labels are
\[
 T_a=23,\qquad T_b=14,\qquad T_{a'}=T_{b'}=T_z=56.
\]
Slots \(5,6\) are identical triple-boundary matchings missing
\(a,b\).  This proves the genuine BF loop \([ab]\) in (3).

## Every private-port pair has a common star

The Figure-7 \(R^*\) relation consists of all pairs across
\[
 P=\{13,14,24,35,45\},\qquad
 Q=\{12,15,23,25,34\},
\]
as well as its all-terminal type
[Máčajová--Mazzuoccolo--Tabarelli, Figure 7 and Appendix XIII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).
For a fixed private port \(a\), colour the four states
\(ar\), \(r\in K\cup\{a'\}\), by their \(P/Q\) block.
Do the same for \(b\), identifying \(a'\) and \(b'\) as one
formal fourth leaf.  These are two binary colourings of the
same four-leaf set.  **Both are nonconstant:** the numbers of
\(P\)-edges incident with local labels \(1,2,3,4,5\) are
\(2,1,2,3,2\), respectively; the other incident edges are
\(Q\)-edges.

Any two nonconstant binary colourings of one set separate some
common pair of elements.  Indeed, if the second colouring
separated no pair crossing the first colouring's two nonempty
classes, it would have the same value on every cross pair and
therefore be constant on their union.  Choose a pair of leaves
separated by both shore colourings.  If both leaves lie in
\(K\), (2) forces \([ab]\); if one is the formal fourth leaf,
(3) forces \([ab]\).  This works independently for all four
choices \((a,b)\in\{x,p\}\times\{y,q\}\), proving (1).

The conclusion is an all-orders exclusion of the **two cyclic
nonpentagonal \(R^*\) shores in quotient \(I_m\)**.  It uses
the published complete Case-XIII relation and actual slotwise
closure; it does not eliminate tree or ordinary-pentagon shore
combinations in \(I_m\), the other two-vertex quotients, larger
Tutte barriers, the perfectly matchable-core branch, or the full
Berge--Fulkerson conjecture.  The analytic proof awaits an
independent check.
