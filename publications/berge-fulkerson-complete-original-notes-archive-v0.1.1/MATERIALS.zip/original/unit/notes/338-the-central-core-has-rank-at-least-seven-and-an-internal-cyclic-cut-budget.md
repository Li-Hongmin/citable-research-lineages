> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The central core has rank at least seven and an internal cyclic-cut budget

Consider the central-path exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md). It has thirteen vertices outside the six-port shore: five path vertices, four side vertices, and the four subdivision vertices of the exterior marks. Let \(C\) be its connected unmarked core. The shore consists of \(C\) and the subdivision vertex \(t_e\) of its one internal marked edge \(e=vw\). The core has five proper interfaces \(A,I,D,H,J\) to the exterior; deleting the marked edge leaves its two ends as two further incidences. Write \(\rho(C)=|E(C)|-|V(C)|+1\).

**Rank-seven floor.** If this five-pole \(H\) is simple, connected, and has complete exact Case-XII BF support, then

\[
                  |V(C)|=5+2\rho(C),\qquad
                  |V(H)|=19+2\rho(C),\qquad
                  \rho(C)\ge7.                         \tag{1}
\]

Indeed, cubic degree counting in \(C\) gives \(3|V(C)|=2|E(C)|+7\), and the thirteen exterior vertices plus \(t_e\) give the second identity. [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) proves \(|V(H)|\ge33\) from the published order-36 Berge--Fulkerson verification of [Brinkmann--Goedgebeur--Hägglund--Markström, Corollary 8.5](../../../../ResearchLibrary/lib/unknownarxiv1206a/unknownarxiv1206a.pdf), by completing \(H\) with the forbidden port pentagon. Substitution gives \(\rho(C)\ge7\). This deduction does **not** use the hand-derived rows or the no-odd-edge-transversal claim of [Notes 331--335](335-the-genuine-two-rows-force-an-odd-unmarked-core.md), nor cyclic-five connectivity. In particular the rank-three \(K_4\) and doubled-edge kernels of [Note 337](337-rank-three-core-kernels-and-the-two-port-cyclic-five-gate.md) cannot occur in a genuine exact-Case-XII central-path pole. Their conditional topology is not the next eligible matching-closure case.

There is also an all-rank cut rule independent of the finite verification. Suppose \(H\) is completed by the forbidden port pentagon to a cyclically 5-edge-connected cubic host \(G\). The secondary-cut conclusion below additionally assumes that \(G\) is a *minimum* BF counterexample, as required by [Máčajová--Mazzuoccolo--Tabarelli, Proposition 4.4](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). For \(W\subseteq V(C)\), let \(p(W)\) count the five proper interfaces based in \(W\), with multiplicity, and put

\[
 k(W)=|\delta_C(W)|,\qquad
 m(W)=\mathbf1_{W\cap\{v,w\}\ne\varnothing}.
\]

**Internal cyclic-cut inequality.** If \(C[W]\) is connected and contains a cycle, then

\[
                         k(W)+p(W)+m(W)\ge5.       \tag{2}
\]

To see this, take the host side \(W'=W\cup\{t_e\}\) if both \(v,w\) lie in \(W\), and \(W'=W\) otherwise. Its cut has exactly \(k(W)\) core edges and \(p(W)\) proper-interface edges. The marked subdivision contributes one cut edge when \(W\) meets \(\{v,w\}\), and none otherwise: if both ends lie in \(W\), the sole cut edge is \(t_e\)'s attachment to the port pentagon; if just one does, it is that end's half of \(e\). Thus \(|\delta_G(W')|=k(W)+p(W)+m(W)\). The side \(W'\) contains the cycle in \(C[W]\); its complement contains the added pentagon. Cyclic-five connectivity proves (2).

The inequality also locates the entire rank. If a bridge of \(C\) separated two cyclic components \(W_1,W_2\), then \(k(W_i)=1\) and (2) would require \(p(W_i)+m(W_i)\ge4\) for both. But \(p(W_1)+p(W_2)=5\) and \(m(W_1)+m(W_2)\le2\), a contradiction. Distinct cyclic blocks cannot meet at a vertex in a subcubic graph. Thus all cycles lie in one 2-connected block \(K\), as in [Note 336](336-the-unmarked-core-has-cycle-rank-at-least-three-in-a-cyclic-five-host.md). Its degree-three vertex count is
\[
 n_3(K)=2\rho(K)-2=2\rho(C)-2\ge12,\qquad
 |V(C)|-n_3(K)=7.                                      \tag{3}
\]
The cyclic kernel therefore has at least twelve branch vertices; all its degree-two subdivision vertices and every tree vertex attached to it together number at most seven. This does not bound \(\rho(C)\) from above.

**Two-edge separation.** Suppose deleting two core edges separates \(C\) into two connected components \(W_1,W_2\), each containing a cycle. Applying (2) to both sides and using \(p(W_1)+p(W_2)=5\) shows that their interface counts are exactly \(2\) and \(3\). The two-interface side meets at least one end of \(e\), and its corresponding host cut has size exactly five. This extends Note 337's two-port conclusion from its special doubled-edge kernel to *every* cyclic two-edge separation of \(C\), regardless of rank.

If \(G\) is a minimum BF counterexample, the five-cut classification gives a further precise fork. Let \(W\) be the two-interface side and \(W'\) its host side as above. The other side contains both the added pentagon and the cycle in \(C-W\), so it is not an ordinary five-cycle. Proposition 4.4 therefore says: **either \(G[W']\) is an ordinary five-cycle, or this secondary cut has Case-XIII boundary relations.** If both ends \(v,w\) lie in \(W\), then \(W'\) contains the cycle of \(C[W]\) and an additional cycle through \(v,t_e,w\), so the five-cycle alternative is impossible; the secondary cut must be Case XIII. If the marked ends are split, the non-Case-XIII alternative requires \(C[W]\) itself to be an ordinary five-cycle. This is a necessary condition, not an exclusion of Case XIII or a proof that a matching fibre intersects.

The rank-seven floor is a direct consequence of an existing published finite theorem and [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md). Equation (2) and the two-edge/secondary-cut consequences are symbolic, all-rank constraints; this hand proof has not had an independent second-source review. They leave cyclically 5-connected rank-at-least-seven cores and their complete perfect-matching closure unresolved. No local graph enumeration or OMEN run was used.
