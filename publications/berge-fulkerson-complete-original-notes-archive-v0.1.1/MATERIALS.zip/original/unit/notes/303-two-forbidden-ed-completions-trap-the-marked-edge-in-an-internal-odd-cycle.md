> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two forbidden ED completions trap the marked edge in an internal odd cycle

Continue the genuine \(R_0=DJ\), \(3{:}2\) near-bipartite central-path setting of [Notes 301–302](302-the-right-zero-port-matching-forces-both-left-ad-opposite-fibres.md). The unmarked core minus \(g\subset B\) is bipartite; the marked edge joins \(v\in B\) to \(w\in R\) through \(t_e\). The two \(R\)-based proper shore ports are \(D=h_2,J=h_4\), and \(A=a:\Sigma,I=h_1,H=h_3\) are \(B\)-based. Complete exact-Case-XII support forbids Tait states \(ad,bc\). [Note 302](302-the-right-zero-port-matching-forces-both-left-ad-opposite-fibres.md) forces an actual shore matching with ports \(ED\) that selects \(E=e\) and \(g\).

**Theorem (complete-fibre form).** Every actual \(ED\)-port shore perfect matching \(N\) selecting \(g\) leaves \(t_{ev},t_{ew}\) on one **closed odd shore-internal cycle** of its complement. Consequently the matching forced by Note 302 has such a marked-edge return cycle. This is a second required fibre alongside [Note 300's](300-two-forbidden-ej-completions-trap-the-marked-edge-in-an-internal-odd-cycle.md) \(EJ,g\) fibre; the two cycles need not be identical.

## Two actual forbidden-state completions

The following exterior perfect matchings both select the shore ports \(E,D\). The boundary column lists the three selected terminal semiedges; the displayed selected edges cover the other marked vertices, all four \(u_i\), and all five exterior branch vertices exactly once.

| Mask | Boundary | Selected exterior edges besides terminal semiedges | Complete exterior-complement routes |
|---|---|---|---|
| \(M_{ad}\) | \(b,c,e\) | \(a:C,d:B,1A,3D,4E,h_2\) | \(a\)--\(A\), \(d\)--\(J\), \(I\)--\(H\) |
| \(M_{bc}\) | \(a,d,e\) | \(b:D,c:A,1B,3C,4E,h_2\) | \(b\)--\(I\), \(c\)--\(A\), \(H\)--\(J\) |

For \(M_{ad}\), the branch covers are \((1A,d:B,a:C,3D,4E)\), and \(u_1,u_2,u_3,u_4\) are covered by \((1A,h_2,3D,4E)\). Taking the other two edges at each exterior vertex traces the \(I\)--\(H\) route through \(u_1,B_{\rm ext},u_2,C_{\rm ext},u_3\), while the remaining route from \(J\) reaches terminal \(d\). For \(M_{bc}\), the branch covers are \((c:A,1B,3C,b:D,4E)\), and the path vertices are covered by \((1B,h_2,3C,4E)\). Its \(H\)--\(J\) route passes through \(u_3,D_{\rm ext},u_4\); the other two routes reach \(b\) from \(I\) and \(c\) from \(A\). Thus both are graph-induced masks, independent of a designated BF row.

## The two-completion contradiction

Glue an arbitrary \(N\) in the stated fibre to \(M_{ad}\). The only unselected same-side proper edges are \(t_{ew}\) and the \(J\) cut edge: \(g,D\) are selected. The exterior \(d\)--\(J\) arm puts \(J\) on an open terminal path. Since \(ad\in T\), the complement must contain an odd closed cycle, so \(t_{ew}\) lies on a closed odd component. If that component is not entirely shore-internal, it must use the sole exterior connection between two free shore ports, \(I\)--\(H\). The shore complement of \(N\) must then pair \(I\)--\(H\), leaving \(A\)--\(J\).

Glue the *same* \(N\) to \(M_{bc}\). With shore pairing \(IH\mid AJ\), its \(b\)--\(I\) arm, shore \(I\)--\(H\) path, exterior \(H\)--\(J\) path, shore \(J\)--\(A\) path, and \(A\)--\(c\) arm form one open \(b\)--\(c\) path. It contains **both** remaining same-side edges \(t_{ew},J\). Every closed complement component is even, so this actual \(bc\)-triple extends to a forbidden \(bc\)-Tait colouring. Contradiction. Hence \(t_{ew}\) lies on a closed shore-internal cycle under \(N\). At \(t_e\), \(N\) selects \(E\), so the same cycle also contains \(t_{ev}\); it is odd because \(t_{ew}\) is its sole same-side edge. \(\square\)

The theorem supplies a necessary cycle in each \(ED,g\) matching, not an incompatibility between the \(ED,g\) and \(EJ,g\) fibres. Their simultaneous existence, the remaining \(DJ\) placement, other core profiles, and Berge–Fulkerson remain open. The proof is a hand route trace, with no local recomputation or OMEN run.
