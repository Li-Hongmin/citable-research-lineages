> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The five same-side near-bipartite placements fail

Continue [Note 333](333-the-mark-cannot-lie-opposite-the-exceptional-edge-in-a-near-bipartite-core.md): \(C-g\) is bipartite with \(g\subset B\), both ends of the marked edge \(e\) lie in \(B\), \(|B|-|R|=1\), and precisely two of the proper shore ports \(A,I,D,H,J\) are \(B\)-based. The subdivision vertex \(t_e\) lies in \(R\), so the shore minus \(g\) is bipartite and balanced. Assume the genuine left \((ea)(ac)\) and right \((ea)(ad)\) rows of [Notes 271 and 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md) and complete exact-Case-XII support, with \(S=e-a-b-d-c-e\). Note 333 leaves exactly the five \(B\)-port pairs \(AI,HI,HD,JI,JD\).

**Theorem.** None of those five placements exists. Thus a nonbipartite unmarked core in this central-path, two-row profile cannot be made bipartite by deleting a same-side edge \(g\), regardless of whether the marked edge has ends on opposite sides or together in either side.

**Proof.** In every case colour the common exterior interface endpoints in \(B\). The four exterior terminal vertices lie in \(B\), while the marked terminal \(e=t_e\) lies in \(R\). The only same-side proper edges of the full pole are \(g\) and the two cut edges at the displayed \(B\)-based ports. For a T-boundary triple whose matching selects \(g\), if the two remaining exceptional cut edges lie on one complement component, every closed complement cycle is even; the triple extends to a forbidden Tait colouring. The same holds if both edges lie on open terminal paths.

The right \(ad\)-triple \(U_{ad}\) has shore ports \(E,J\). When \(J\in R\), matching balance makes it select \(g\). Its exterior mask in Note 297 has complementary connections
\[
                 a\longleftrightarrow A,qquad
                 d\longleftrightarrow I,qquad
                 H\longleftrightarrow D.                     \tag{1}
\]
For \(AI\), both exceptional cut edges lie on the open arms from \(a,d\). For \(HD\), both lie on the single \(H\)--\(D\) exterior path. In either case all closed complement cycles are even, contradicting \(ad\in T\). This excludes \(AI,HD\).

For \(HI\), use the right pure \(X_R\triangle Z_R\) pairing \(EH\mid AJ\). Its zero-port \(X_R\) avoids \(g\), whereas the four-port \(Z_R(EAHJ)\) selects \(g\): among those four ports only \(H\) lies in \(B\). The \(A\)--\(J\) path has odd internal length with both ends in \(R\), and the only same-side shore edge is \(g\); thus it contains \(g\). Switching this path into \(X_R\) gives an actual shore matching \(N\) with ports \(AJ\) and \(g\in N\). Glue \(N\) to the singleton-\(c\) exterior mask [Note 332, (2)](332-the-right-pure-aj-switch-excludes-the-four-one-core-profile.md). Its complement has four terminal arms
\[
                    e-E,qquad a-H,qquad b-I,qquad d-D.        \tag{2}
\]
The two unselected exceptions \(H,I\) are on open arms, so all closed cycles are even and the singleton-\(c\) matching extends to a Tait colouring. The three possible shore-complement pairings \(EH\mid ID,EI\mid HD,ED\mid HI\) put the differently coloured terminal path, respectively, at \(e-a,e-b,a-b\). In the first two, it has one same-side exception and joins opposite terminal sides; in the third, it has both exceptions and joins two \(B\)-side terminals. Switching its two colours produces respectively \(ca,cb\), or both \(ca,cb\). All are forbidden because \(c\) is adjacent in \(S\) only to \(e,d\). This excludes \(HI\).

For \(JI\) and \(JD\), the left \(ac\)-triple \(U_{ac}\) has shore ports \(E,A\), both \(R\)-based, and therefore selects \(g\). Its exterior complement has connections
\[
                  a\longleftrightarrow D,qquad
                  c\longleftrightarrow H,qquad
                  I\longleftrightarrow J.                    \tag{3}
\]
In \(JI\), the two exceptional cut edges \(I,J\) lie on the same exterior path, so every closed complement cycle is even, contradicting \(ac\in T\).

In \(JD\), the exception \(D\) lies on the open \(a\)-terminal arm. Avoiding a forbidden \(ac\)-Tait colouring requires the other exception \(J\) to lie on an odd closed component. Equation (3) therefore forces the complement of the *same complete shore matching* \(U_{ac}|_{\rm shore}\) to pair
\[
                              IJ\mid DH.                    \tag{4}
\]
Now replace only its exterior by the actual triple mask of [Note 281, equation (8)](281-the-central-six-port-shore-has-no-single-edge-odd-cycle-transversal.md): select terminal semiedges \(b,c\), the halves \(a:\Sigma,d:B_{\rm ext}\), and path edges \(1A_{\rm ext},2C_{\rm ext},3D_{\rm ext},4E_{\rm ext}\), retaining the same selected shore ports \(E,A\). Its exterior complement connects \(a-H,I-D,d-J\). Together with (4), both exceptions \(D,J\) lie on the unique \(a\)--\(d\) terminal path. Every closed complement cycle is even, producing forbidden \(ad\)-Tait. This is precisely the placement-II argument of Note 281; it uses the left \(ac\) row and does not use the invalid left-\(ad\) assumption in that note's placement-I argument. Hence \(JD\) is impossible. \(\square\)

Together with [Notes 331–333](333-the-mark-cannot-lie-opposite-the-exceptional-edge-in-a-near-bipartite-core.md), this excludes all marked-edge side placements **under the explicit hypothesis that \(C-g\) is bipartite and \(g\) is a same-side edge**. It does not establish that an arbitrary bipartizing \(g\) must have same-side ends, nor does it by itself exclude a bipartite unmarked core. Those are separate logical interfaces; the proof is symbolic and awaits independent verification. No local computation or OMEN run was used.
