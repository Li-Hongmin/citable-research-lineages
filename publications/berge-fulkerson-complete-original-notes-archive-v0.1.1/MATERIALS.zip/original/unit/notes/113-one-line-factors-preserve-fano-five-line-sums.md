> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# 113 — 一线因子的割拼接保持（2026-09-13，脉冲 4/5）

有限命题：一条源线上的指定点或有序三点，能否在自同构下送到任意至多五线调色板中的点或有序星，同时使源线落入该调色板？

**裁决：是。** 所有非空、大小至多五的调色板共 119 个；合法指定点接口 728 个，有序星接口 2394 个，全部通过。

证明：任意两个不同非零向量构成独立对。把源独立对送到目标独立对，再补第三个基向量，即得可逆线性映射。指定单点 x 时，任选目标调色板内经过 x 的线；指定星时目标线已经确定。

**不限阶推论。** 若闭三正则图 A 有三边着色，B 有至多五线 Fano 着色，则任意指定边二和、任意指定顶点和端口配对的三和都有至多五线着色。

二和：A 的三边着色标成同一 Fano 线，选 B 指定边两端之一所用的线 M；将 A 的指定边色送到 B 的边色，并将 A 的整条线送入 M。割开两条边后连接半边，所有顶点仍满足原星，线集包含在 B 原调色板内。
三和：将 A 被删顶点的有序星送到 B 被删顶点按配对排序的星。删除顶点、连接对应半边后，每个保留顶点仍满足原星；A 的唯一线已属于 B 的原调色板，线并集仍至多五。B 被删顶点的线即使在剩余 B 中消失，重新加入它也不超出原来的五线。

证据：`computations/fano-r1-20260913/interface.py` 枚举所有线子集并搜索线性群；独立 `verify_interface.py` 用显式 incidence 表定义加法，直接基扩张构造映射，不调用群枚举器，并核对 728/2394 全部接口。命令分别为 `python3 computations/fano-r1-20260913/interface.py`、`python3 computations/fano-r1-20260913/verify_interface.py`。

最薄弱一步：两侧都必须使用多条线时，上述源单线包含关系不再成立。一般 R1 保持性仍未证；不能归约到全部循环四边连通图。
下一命题：把实际两极/三极的全部五线着色纳入后，R1 能否精确表达为有限边界轨道支持相交？
