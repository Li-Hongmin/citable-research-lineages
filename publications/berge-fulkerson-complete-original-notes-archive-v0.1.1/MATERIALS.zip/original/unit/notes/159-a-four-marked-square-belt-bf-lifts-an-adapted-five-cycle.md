> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-marked square belt BF-lifts an adapted five-cycle

The five-edge marked core of [Note 157](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md) cannot contain a marked 4-cycle in a genuine minimum-host Case XII. The fifth marked edge can have arbitrary placement outside the 4-cycle, and its attachment to the opposite pentagon can have arbitrary cyclic order. The proof constructs a five-cycle replacement whose port order is chosen from that attachment, then lifts **every** six-matching boundary colouring of the replacement. This analytic proof awaits independent checking. Marked triangles and paths are not covered.

## Four-spoke belt

Write the four marked edges as \(v_it_iv_{i+1}\), with \(i\in\mathbb Z_4\). Let \(r_0,\ldots,r_4\) be the opposite 5-cycle. Each \(t_i\) has a spoke to a distinct \(r_{\pi(i)}\); call the remaining outer vertex \(r_*\). The belt \(B\) on these thirteen vertices has four exterior semiedges \(h_i\) at the \(v_i\), and a fifth \(h_*\) at \(r_*\). The cyclic order of the four spoke vertices on the outer pentagon is unrestricted.

**Adapted belt lifting lemma.** There is an edge \(v_iv_{i+1}\) of the abstract inner 4-cycle such that, if \(Q\) is the ordinary 5-cycle obtained by inserting a new port vertex \(*\) between \(v_i,v_{i+1}\), every labelled BF colouring of \(Q\) extends to \(B\) with the same six colour labels on \(h_0,\ldots,h_3,h_*\).

As in [Note 158](158-a-permuted-pentagonal-belt-bf-lifts-a-five-cycle.md), the five-cycle BF boundary list consists of all loops and pairs on its five adjacent-pair Tait states, plus the all-terminal type. We establish those five Tait states and that all-terminal type for \(B\). A boundary type determines its six semiedge subsets up to permutation of the matching labels, so this suffices for literal labelled lifting.

## The three inner-adjacent Tait states

First prescribe \(A,B,C,C\) on \(h_0,h_1,h_2,h_3\), and \(C\) on \(h_*\). Put \(b_i=\operatorname{col}(v_it_{i-1})\), \(a_i=\operatorname{col}(v_it_i)\), and \(c_i=\operatorname{col}(t_ir_{\pi(i)})\). The following three rows satisfy the three distinct-colour incidences at every \(v_i,t_i\):

| \((c_0,c_1,c_2,c_3)\) | \((b_0,a_0)\) | \((b_1,a_1)\) | \((b_2,a_2)=(b_3,a_3)\) |
|---|---|---|---|
| \((A,C,C,B)\) | \((C,B)\) | \((C,A)\) | \((B,A)\) |
| \((C,A,C,B)\) | \((C,B)\) | \((A,C)\) | \((B,A)\) |
| \((B,A,C,C)\) | \((B,C)\) | \((A,C)\) | \((B,A)\) |

The two lonely spoke colours occupy one of the pairs \(\{0,3\},\{1,3\},\{0,1\}\), namely all three pairs of the spoke vertices \(\{0,1,3\}\). Among any three vertices of an outer 5-cycle, some two are adjacent. Choose that row and extend over the outer cycle, whose five dangling colours then have two adjacent lonely positions. Rotating the inner indices proves the Tait state for **every** inner-adjacent pair \(\{i,i+1\}\), regardless of the four-spoke permutation.

## The two states involving the outer port

Now prescribe \(A\) at \(h_0\), \(B\) at \(h_*\), and \(C\) at the other three inner ports. Two valid inner-ring assignments are

| \((c_0,c_1,c_2,c_3)\) | \((b_0,a_0)\) | \((b_i,a_i),\ i=1,2,3\) |
|---|---|---|
| \((A,C,C,C)\) | \((B,C)\) | \((B,A)\) |
| \((C,C,C,A)\) | \((C,B)\) | \((A,B)\) |

Thus the boundary state \(\{0,*\}\) extends if \(r_*\) is adjacent on the outer cycle to either \(r_{\pi(0)}\) or \(r_{\pi(3)}\). In general, \(\{i,*\}\) extends whenever an outer neighbour of \(r_*\) is the spoke vertex for one of the two marked edges incident with \(v_i\). The two neighbours of \(r_*\) correspond to two distinct edges of the inner 4-cycle. Their endpoints cover at least three of its four vertices. At least two of those covered vertices are adjacent on the inner 4-cycle. Choose such an adjacent pair \(v_i,v_{i+1}\) and insert \(*\) into that edge to define \(Q\). Both of its adjacent-pair states involving \(*\) extend, while its other three adjacent-pair states were handled above. For each chosen outer lonely pair, the outer 5-cycle edge colours are obtained from the consecutive-port pattern \(A,B,C,C,C\mapsto C,A,B,A,B\).

## The all-terminal BF colouring

Let \(W\) use all five exterior semiedges and all four spokes. Let \(N_*\) use \(h_*\), all four forward edges \(v_it_i\), and the unique two-edge matching of the outer 5-cycle after deleting \(r_*\). Let \(N_0\) use
\[
h_0,\quad v_1t_0,\ v_2t_1,\ v_3t_3,\quad
t_2r_{\pi(2)},                                             \tag{1}
\]
and the unique two-edge matching of the outer 5-cycle after deleting \(r_{\pi(2)}\). Define \(N_i\), \(i=1,2,3\), by rotating the **inner** indices of (1); choose the outer matching after deleting its rotated spoke vertex. These are five singleton-boundary perfect matchings, one for each port.

The six matchings \(W,N_*,N_0,N_1,N_2,N_3\) have load two on every edge. Each exterior semiedge is used by \(W\) and its singleton matching. Each spoke is used by \(W\) and one of the four \(N_i\). Each forward inner half-edge is used by \(N_*\) and once among the \(N_i\), while each backward half-edge is used twice among the \(N_i\). The five singleton matchings delete each outer vertex once; across the five unique matchings of a 5-cycle after one vertex deletion, every outer edge occurs twice. This proves the all-terminal type and the adapted belt lifting lemma.

## Minimum-host exclusion

Suppose the marked-edge subgraph of a genuine minimum-host Case-XII core \(J\) contains a 4-cycle. Note 157 gives marked maximum degree two, so the fifth mark lies wholly outside it. The cycle has no unmarked chord: one chord would leave a 2-edge-cut in the 3-edge-connected core \(J\). Hence its four vertices have exactly one unmarked edge each to the rest of \(J\), and the corresponding part of the full graph is exactly the belt \(B\) above. Its fifth exterior edge is the edge from \(r_*\) to the subdivision vertex of the remaining marked core edge.

Replace the 13-vertex belt by the adapted five-cycle \(Q\), keeping the same five exterior edges. The resulting graph is cubic, has eight fewer vertices, and is bridgeless: both gadgets connect all five ports, and deleting an edge within \(Q\) leaves it connected. A BF cover of the smaller graph exists by minimality. The adapted belt lifting lemma extends its six complete boundary labels across \(B\), giving a BF cover of the original graph, a contradiction. Therefore
\[
\boxed{\text{A minimum-host exact-Case-XII marked core has no marked 4-cycle.}} \tag{2}
\]
Together with Notes 157--158, its five marked edges form paths and possibly a marked triangle; no marked cycle of length four or five remains. This does not settle the remaining complete perfect-matching closure or the common \(B_2+C_4\) seed.
