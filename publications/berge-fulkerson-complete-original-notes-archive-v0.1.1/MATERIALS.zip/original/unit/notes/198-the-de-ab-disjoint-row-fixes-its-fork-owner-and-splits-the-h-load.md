> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The de--ab disjoint row fixes its fork owner and splits the h load

Assume a genuine \((4,2,2)\) five-pole has complete exact Case-XII BF support with \(de\in S\) and \(ab\in T\). No hypothesis on \(F[C]-v_h\) or on deletion matchability at \(a,b,c,d\) is needed. With labels \(a,b\) fixed, the forbidden five-cycle is one of two forms, interchanged by swapping \(a,b\):
\[
T=a-b-d-c-e-a\quad\text{or}\quad T=a-b-e-c-d-a.             \tag{1}
\]
Let \(r\in\{a,b\}\) be the unique neighbour of \(e\) in \(T\) from that fork, and let \(q\) be the other element of \(\{a,b\}\). In **every actual** BF row of the required positive type \((de)(ab)\):

1. the \(ab\)-triple selects the \(C\)-endpoint through \(r\), selects \(w_1\) through \(q\), and matches \(u\) to \(w_2\);
2. the \(S\)-half and \(T\)-half each use \(h\) exactly once, and both have \(u\)-load \((h,uw_1,uw_2)=(1,1,1)\);
3. in the \(T\)-half, the singleton-\(q\) occurrence uses \(h\), while the singleton-\(r\) occurrence uses \(uw_1\). At \(w_1\), its three occurrences use \(q w_1,uw_1,rw_1\), respectively.

These are full six-row necessities, not a construction of an exact-Case-XII pole. They apply at every order and survive even when the centre deletion is matchable.

**Proof.** The \(de\)-triple always selects a \(C\)-endpoint through \(e\), selects \(w_2\) through \(d\), and matches \(u\) to \(w_1\). The \(ab\)-triple selects one of the two \(C\)-endpoints \(v_a,v_b\) through its mark, selects \(w_1\) through the other mark, and matches \(u\) to \(w_2\). If it selected the \(C\)-endpoint through \(q\), then \(r w_1\) would occur. The symmetric difference of the two triples would contain the forced exterior terminal path \(d-w_2-u-w_1-r\). Switching along it changes the missing pairs \((de)(ab)\) into \((er)(dq)\). Both \(er\) and \(dq\) are edges of \(T\) in either cycle (1), contrary to exact negative support. Thus the \(ab\)-triple must select the \(C\)-endpoint through \(r\) and use \(q w_1\), proving 1.

Let \(A\) be the three-matching \(S\)-half of this row and \(B=2\mathbf1-A\) its \(T\)-half. By [Note 197](197-a-saturated-s-carrier-cannot-double-the-h-edge-in-the-422-profile.md), \(A(h)\le1\). Suppose \(A(h)=0\). Then \(B(h)=2\). Since the \(ab\)-triple uses \(uw_2\), both singleton occurrences in \(B\), of classes \(r,q\), must use \(h\). In the singleton-\(r\) occurrence, \(r\) uses its terminal semiedge, so \(w_1\) must be matched through \(q w_1\). The \(ab\)-triple already uses \(q w_1\), giving \(B(qw_1)=2\) and hence \(A(qw_1)=0\). But \(eq\in S\) in both cycles (1). [Note 055's saturation theorem](055-half-load-column-saturation-and-case-xii-compression.md) gives a decomposition of the *same load* \(A\) at state \(eq\); its triple must use \(q w_1\), contradiction. Therefore \(A(h)=B(h)=1\). Equation (1) of Note 197 now makes both \(u\)-loads \((1,1,1)\), proving 2.

If the singleton-\(r\) occurrence in \(B\) used \(h\), it would again use \(q w_1\), saturating that edge in \(B\) and contradicting the required \(eq\) decomposition of \(A\). Thus singleton-\(q\) uses \(h\). The remaining singleton-\(r\) must use \(uw_1\), because the \(ab\)-triple already uses \(uw_2\) and each of the three \(u\)-edges has load one in \(B\). In singleton-\(q\), the only active marked half-edge at \(w_1\) is \(r w_1\), which it uses because \(u\) uses \(h\). This gives the three stated \(w_1\) edges and proves 3. \(\square\)

Under \(H=I_d=0\), [Note 196](196-an-unexposable-fork-mark-forces-its-e-pair-into-the-case-xii-allowed-cycle.md) already forces \(de\in S\); the present result handles its \(ab\in T\) branch. It eliminates the \(A(h)=0\) option for this specific disjoint seed row. It does not synchronize the \(A\)-load with the other four \(T\) columns. When \(de\in S\) but \(ab\in S\), this row is not an \(S\)--\(T\) seed and the argument does not apply.
