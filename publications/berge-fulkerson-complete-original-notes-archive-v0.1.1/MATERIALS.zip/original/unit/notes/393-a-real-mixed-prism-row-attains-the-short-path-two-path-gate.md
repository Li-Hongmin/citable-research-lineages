> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real mixed prism row attains the short-path two-path gate

Use the 23-vertex girth-five two-spoke prism five-pole of [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md), with tree edges \((p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac)\), marks \(AC,Cc,bc,ab\), and eight-vertex shore \(h_0,\ldots,h_7\). Its two zero-port shore perfect matchings are
\[
Q=\{h_0h_4,h_1h_7,h_2h_5,h_3h_6\},\qquad
Q'=\{h_0h_1,h_2h_5,h_3h_4,h_6h_7\}.                    \tag{1}
\]
The shore ports \((e,p_5,p_2,p_4,p_1,p_3)\) meet \((h_0,h_2,h_3,h_4,h_5,h_7)\), respectively. Write \(u_i\) for the subdivision vertex of tree edge \(p_i\), and \(s\) in a mark column for that mark's terminal semiedge. A port entry \(p_i\) in the \(u_i\) column means the proper edge from \(u_i\) into the shore. In every other tree or mark entry, select the half-edge toward the named prism vertex.

> **Actual mixed-row certificate.** The following six **complete** perfect matchings have edge load two and boundary type \((e\,ab)(e\,AC)\). In the exceptional signature \(F=\{ab,Cc\}\), the first triple is forbidden and rooted directly at \(a\); the second is allowed and rooted at \(C\).

| slot | terminal semiedges | \((u_1,u_2,u_3,u_4,u_5)\) | \((AC,Cc,bc,ab)\) | shore ports | shore internal edges |
|---|---|---|---|---|---|
| \(P\) | \(AC,Cc,bc\) | \((B,C,A,b,c)\) | \((s,s,s,a)\) | none | \(Q\) |
| \(R\) | \(ab,Cc,bc\) | \((A,B,a,b,c)\) | \((C,s,s,s)\) | none | \(Q'\) |
| \(E\) | \(e\) | \((B,p_2,A,p_4,p_5)\) | \((C,c,b,a)\) | \(e,p_2,p_4,p_5\) | \(h_1h_7,h_5h_6\) |
| \(F\) | \(e\) | \((p_1,B,p_3,p_4,a)\) | \((A,C,c,b)\) | \(e,p_1,p_3,p_4\) | \(h_1h_2,h_3h_6\) |
| \(J\) | \(ab\) | \((p_1,C,a,B,p_5)\) | \((A,c,b,s)\) | \(p_1,p_5\) | \(h_0h_1,h_3h_4,h_6h_7\) |
| \(K\) | \(AC\) | \((A,p_2,p_3,B,a)\) | \((s,C,c,b)\) | \(p_2,p_3\) | \(h_0h_4,h_1h_2,h_5h_6\) |

**Verification.** Each row of the table matches every prism vertex, tree subdivision, mark subdivision and shore vertex exactly once. For example, \(E\) covers \((A,B,C,a,b,c)\) by \((Au_3,Bu_1,Ct_{AC},at_{ab},bt_{bc},ct_{Cc})\), and its four shore ports together with \(h_1h_7,h_5h_6\) cover all eight shore vertices. The other rows are checked from the same columns.

Every external edge has load two. At the five tree subdivisions, the three choices occur in these slot pairs:
\[
\begin{array}{c|ccc}
&\text{first tree half}&\text{second tree half}&\text{shore port}\\\hline
u_1&(P,E)&(R,K)&(F,J)\\
u_2&(P,J)&(R,F)&(E,K)\\
u_3&(P,E)&(R,J)&(F,K)\\
u_4&(J,K)&(P,R)&(E,F)\\
u_5&(F,K)&(P,R)&(E,J).
\end{array}                                                     \tag{2}
\]
The four mark columns likewise put two occurrences on each terminal and each half-edge; the terminal \(e\) has \((E,F)\). In the shore, the nine internal edges have occurrence pairs
\[
\begin{array}{c|ccccccccc}
\text{edge}&04&17&25&36&01&34&67&12&56\\\hline
\text{slots}&PK&PE&PR&PF&RJ&RJ&RJ&FK&EK,
\end{array}                                                     \tag{3}
\]
where \(ij\) abbreviates \(h_ih_j\). Thus every full-pole edge is used exactly twice. The terminal list gives the claimed two missing-pair states. \(\square\)

For [Note 391's short-path gate](391-short-odd-prism-path-forces-an-opposite-root-and-a-common-singleton.md), \(P_o=p_2-h_3-h_4-p_4\) has three edges and \(h_3h_4\in Q'\). The port colour sets are \(L_2=\{E,K\}\) and \(L_4=\{E,F\}\), so their unique common singleton is \(E\), which also uses \(Bu_1\). The alternating six-cycle \(Q\triangle Q'=h_0h_1h_7h_6h_3h_4h_0\) touches \(P_o\), the even \(e\)-path, and the other even port path. Hence every short-path conclusion of Note 391 is attained by an actual mixed BF row, not merely by a pair of compatible shore masks.

This pole is **not** exact Case XII: the same \(Q'\) extends to forbidden \(ej\)-Tait loops for all four exterior marks by [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md). In this displayed row, \(K\) also uses \(Cc:C\), so the completely exterior \(AC\)--\(Cc\) switch of [Note 394](394-a-mixed-prism-row-forces-an-ac-bc-escape-and-attains-it.md) already produces a forbidden double-\(T\) row. The certificate therefore rules out an attempted contradiction from the two-path gate and the existence of one mixed row alone. The unresolved full-closure question is whether all required positive rows can coexist while every forbidden loop and double-forbidden row is absent. The certificate and edge checks are hand-derived and await independent proof review.
