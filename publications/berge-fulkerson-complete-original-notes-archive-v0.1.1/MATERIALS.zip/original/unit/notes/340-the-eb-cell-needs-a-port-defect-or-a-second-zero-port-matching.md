> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(ea\)--\(eb\) cell needs a port defect or a second zero-port shore matching

Work in the central-path five-pole of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with its six-port shore \(\Sigma\), complete exact Case-XII BF support, and \(S=e-a-b-d-c-e\). The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(eb)\) row. Write any such row as
\[
R=X_{ea}+Y_a+Z_e+U_{eb}+V_e+W_b=2\mathbf1.       \tag{1}
\]
Both triple-boundary matchings omit terminal \(e\). By [Note 230's shore quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), their restrictions \(X_\Sigma,U_\Sigma\) are zero-port perfect matchings of the same six-port shore.

**Theorem.** If the pure state-\(ea\) half-load
\[
                        A=X_{ea}+Y_a+Z_e
\]
has load one on every edge outside the shore interior, including all six shore ports, then
\[
                            X_\Sigma\ne U_\Sigma.       \tag{2}
\]
Consequently the shore has at least two zero-port perfect matchings. The theorem concerns complete actual matching occurrences and does not require the two triples to have the same exterior mask.

**Proof.** Suppose \(X_\Sigma=U_\Sigma=Q\). Both occurrences load every \(Q\)-edge twice, so the four singleton matchings avoid \(Q\). In the shore complement \(\Gamma=E(\Sigma)\setminus Q\), every internal vertex has degree two. Every remaining edge has exactly two labels from \(Y,Z,V,W\), and at each internal vertex the labels of the two incident \(\Gamma\)-edges are complementary two-subsets of \(\{Y,Z,V,W\}\). Thus \(\Gamma\) consists of three port paths and closed even cycles; odd closed cycles are already impossible because the actual row supplies alternating labels.

Call a two-slot label *cross* if it contains one member of \(\{Y,Z\}\) and one of \(\{V,W\}\). At each shore port, \(A\) has load one by hypothesis and neither zero-port triple uses it, so its label is cross. The complement of a cross label is cross. Moving along a port path of \(\Gamma\), its edge labels alternate between a two-set and its complement; therefore every edge of every open path is cross.

For each closed component of \(\Gamma\), independently replace its two-slot labels by alternating cross complements, for example \(\{Y,V\}\) and \(\{Z,W\}\). Its even length makes this consistent. Each of the four singleton slots still uses exactly one edge at every vertex of that cycle, no terminal or shore-port choice changes, and every edge retains load two. These labels therefore define four **actual** new perfect matchings of the same pole. After this replacement every non-\(Q\) shore edge has one colour in each half; each \(Q\)-edge has \(X\) in the first half and \(U\) in the second. Hence both half-loads are unit on the entire shore. They were already unit outside its interior, so the three matchings of each half now partition every edge of the five-pole. The opposite half has Tait state \(eb\in T\), contradicting the forbidden loop \([eb]\) in exact Case XII. This proves (2). \(\square\)

The same recolouring argument applies to a BF row on any cubic shore cut whenever two slots in opposite halves use the same zero-port shore matching, the first half-load is unit on all shore ports, and a Tait colouring of the opposite boundary state is forbidden. It uses the complete matching closure on closed components of \(\Gamma\); [Note 230, (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) gives the corresponding complementary-label rule.

**Sharper central-path port gate.** If \(X_\Sigma=U_\Sigma\) in an exact-Case-XII row (1), then the pure \(ea\) half has load zero or two at **some proper shore port** among \(A,I,D,H,J\). The terminal-\(e\) port \(E\) always has load one. This is stronger than merely requiring a nonunit exterior edge.

To prove it, first note that the two possible zero-port exterior masks for \(U_{eb}\) are
\[
\begin{array}{c|l}
U_A& b:A,\ 1B,2C,3D,4E\\
U_D& b:D,\ 1A,2B,3C,4E .
\end{array}                                                   \tag{3}
\]
The displayed entries omit its selected terminals \(a,c,d\). They follow by matching the exterior path after \(b\) takes \(A\) or \(D\). In particular both \(X_{ea}\) and \(U_{eb}\) select \(4E\), so neither singleton-\(e\) slot can select that edge.

Suppose all six shore ports have pure-half load one. Since \(eb\in T\), the \(ea\) half must be \(S\)-pure; the half-level exterior route argument of Note 271 makes \(Y_a\) use the left mask \(Y_L\) or right mask \(Y_R\), with proper shore ports \(HJ\) or \(ID\). The pure singleton-\(e\) mask \(Z_e\) must therefore have ports \(EAID\) or \(EAHJ\), respectively. Reading just those port sets from Note 271's complete 16-mask table, and retaining only masks pure for the specified side, gives
\[
\begin{array}{c|c|c}
Y_a&Z_e\text{ with complementary ports}&\text{status}\\\hline
Y_L&\mathrm{I}:\ a:\Sigma,3C,4D=Z_L&\text{unit exterior}\\
Y_L&\mathrm{II}:\ a:\Sigma,3C,4E&4E\text{ overloaded}\\
Y_R&\mathrm{III}:\ a:\Sigma,1B,2C=Z_R&\text{unit exterior}\\
Y_R&\mathrm{IV}:\ a:\Sigma,1A,2C&\text{six-cycle below}.
\end{array}                                                   \tag{4}
\]
The \(Z_L,Z_R\) rows contradict (2). The second row contradicts the already doubled load on \(4E\).

It remains to handle the last row of (4). Its \(Y_R\) mask uses \(b:A,c:E,d:B,3C,4D,h_1,h_2\). Every pure-right singleton-\(e\) mask uses \(b:D\) by Note 271's route table. Since \(Z_e,V_e\) can be exchanged while the opposite \(eb\) state stays fixed, both are pure-right masks. Hence \(U_{eb}\) cannot use \(b:D\), which would load that edge three times; it is \(U_A\) in (3). Edge load two and the matching condition now force
\[
\begin{aligned}
Z_e&=\{a:\Sigma,b:D,c:E,d:B,1A,2C,h_3,h_4;\ e\},\\
V_e&=\{a:\Sigma,b:D,c:A,d:E,2B,3C,h_1,h_4;\ e\},\\
W_b&=\{a:C,c:A,d:E,1B,4D,h_2,h_3;\ b\}.          \tag{5}
\end{aligned}
\]
For instance \(X,U_A\) already saturate \(4E,3D\), while \(X,Z_e\) saturate \(1A\), \(U_A,Z_e\) saturate \(2C\), and \(Y_R,Z_e\) saturate \(c:E,d:B\). The remaining exterior vertices and loads give \(W_b\)'s \(1B,4D,a:C\), then \(V_e\)'s \(2B,3C,a:\Sigma\); the ports in (5) follow at \(u_1,\ldots,u_4,t_a\). Thus (5) is forced, not a selected completion.

The pure half-load \(X+Y_R+Z_e\) has load two precisely on \(1A,d:B,c:E\) and zero precisely on \(1B,d:E,c:A\) outside the shore. These six edges form the wholly exterior cycle
\[
 A_{\rm ext}-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c-A_{\rm ext}.
\]
Its edge-label pairs, in that cyclic order, can be changed as follows:
\[
\begin{array}{c|cccccc}
 &1A&1B&d:B&d:E&c:E&c:A\\\hline
\text{old}&XZ&UW&YZ&VW&YZ&VW\\
\text{new}&XW&ZU&YW&ZV&YW&ZV .
\end{array}                                                   \tag{6}
\]
At each of the six vertices the two new pairs are complementary among the four slots not using its unchanged third edge. Hence the replacement preserves all six perfect matchings, their terminal boundaries and the load-two equation. Every new pair in (6) has one slot in each half, so the new pure \(ea\) half is unit on the *entire* exterior. The shore restrictions of \(X,U\) are still the same \(Q\); applying (2) to this new actual row yields the forbidden \(eb\) Tait colouring. This excludes the last row of (4) and proves the port gate. \(\square\)
Equivalently, (6) is the ordinary closed alternating six-cycle switch between \(Z_e\) and \(W_b\). It changes \(Z_e\)'s exterior mask to the unit-exterior \(Z_R\) while leaving all shore restrictions untouched.

If the shore has a unique zero-port perfect matching, **every** required \((ea)(eb)\) row must use a nonunit pure-\(ea\) shore-port vector by the sharper gate. If, in addition, a genuine left \((ea)(ac)\) row and a genuine right \((ea)(ad)\) row coexist as in [Note 339](339-the-genuine-right-row-forces-an-internal-pure-load-circulation.md), they supply at least four distinct pure state-\(ea\) half-loads over the common unit exterior vector. The \((ea)(eb)\) cell then requires at least one more pure state-\(ea\) half-load with a different exterior and shore-port vector.

The nonunit-port alternative is a real logical boundary of the argument: a pure \(S\) half-load need not be unit on the exterior, and its nonunit shore-port labels can force open components of \(\Gamma\) to retain \(0/2\) defects. Neither the port gate nor the resulting five-load lower bound excludes a rank-at-least-seven exact Case-XII pole. Other required \(S\)--\(T\) cells must be used to remove this alternative or to derive a genuine counterexample. The proof is symbolic and has not had independent second-source review; no local graph enumeration or OMEN run was used.

[Note 341](341-the-eb-row-forces-distinct-zero-port-shore-matchings.md) subsequently removes this alternative for the same required cell by gluing the common shore matching to both forbidden-state \(eb\) exterior triples.
