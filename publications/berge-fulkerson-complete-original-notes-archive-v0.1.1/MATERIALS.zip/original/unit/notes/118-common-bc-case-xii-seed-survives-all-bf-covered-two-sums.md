> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The common-\(B,C\) Case-XII seed survives every BF-covered two-sum

The two positive Case-XII cells \((14)(23)\) and \((25)(34)\) can each have a Berge--Fulkerson witness while their singleton matchings \(B,C\) fail to agree as complete masks. Their common-\(B,C\) occurrence is the two-row seed below. Unlike a full prescribed six-row rectangle, **existence of this seed transfers through an arbitrary closed BF-covered factor**, without a three-edge-colouring or a canonical matching-identity map for the factor.

## Seed and pair-load intersection

All matchings below are actual complete masks of one cubic five-pole, including its five semiedges. A name \(P_i\) has singleton boundary \(i\), while \(q_{ij},r_{ij}\) have triple boundary \([5]\setminus\{i,j\}\). Define \(\operatorname{Seed}(G)\) by the existence of actual matchings satisfying

\[
\begin{aligned}
A+B+X+C+q_{14}+r_{23}&=2\mathbf1,\\
B+Y+C+D+q'_{25}+r_{34}&=2\mathbf1,              \tag{1}
\end{aligned}
\]

where \(A,B,X,Y,C,D\) have singleton boundaries \(1,2,3,3,4,5\), respectively. The two occurrences of \(B\) are one complete matching, and likewise for \(C\). No equality between \(X,Y\) or between differently named triple matchings is required.

Let \(\Lambda_L(G)\) and \(\Lambda_R(G)\) be the complete \(B+C\) edge-load vectors realized by the left and right rows of (1) separately. Then

\[
\operatorname{Seed}(G)
\iff \Lambda_L(G)\cap\Lambda_R(G)\ne\varnothing.        \tag{2}
\]

The forward implication is immediate. For the reverse implication, choose one row on each side with equal complete pair load. Replace the right row's \(B,C\) by the two actual matchings in the left row; the right total load and both boundary classes stay fixed. This gives the literal common identities. No support assumption is needed for (2).

## Two-row transfer theorem

Let \(H_0\) be a cubic five-pole with non-loop proper edge \(e\), and let \(J\) be a closed cubic graph with non-loop edge \(f\). Form their two-edge sum \(H=H_0\oplus_{e,f}J\). Write \(\operatorname{BF}(J)\) when \(J\) has a six-perfect-matching double cover. Then

\[
\boxed{
\operatorname{Seed}(H)
\iff \operatorname{Seed}(H_0)\land\operatorname{BF}(J).
}                                                         \tag{3}
\]

In particular, if \(J\) is BF-covered, the common-\(B,C\) pair-load intersection is nonempty on one side of the two-sum exactly when it is nonempty on the other. This is an existence equivalence; individual pair-load vectors need not be preserved.

### Proof

Each perfect matching of \(H\) uses zero or two of the two edges separating \(J\) from \(H_0\), because \(|V(J)|\) is even. Restoring \(e,f\) gives unique factor matchings with equal distinguished-edge bits. Projection of either BF row in (1) gives a BF row of \(H_0\) and a BF cover of \(J\). The common complete \(B,C\) matchings project to common complete matchings in \(H_0\). This proves the forward implication of (3).

For the converse, take the two rows (1) in \(H_0\), and one ordered BF cover \((F_1,\ldots,F_6)\) of \(J\). Exactly two factor occurrences contain \(f\), and four avoid it. Put

\[
b=\mathbf1_{e\in B},\qquad c=\mathbf1_{e\in C}.
\]

Choose two **different occurrence slots** of the factor cover whose \(f\)-bits are \(b,c\), and assign their factor matchings to \(B,C\) in *both* rows. Such slots always exist: if \(b=c=1\), use the two \(f\)-containing slots; if \(b=c=0\), use two of the four avoiding slots; otherwise use one of each. The two factor matchings themselves may be equal, which causes no difficulty because occurrences remain distinct.

Each exterior BF row has precisely two occurrences containing \(e\). After fixing the factor slots for \(B,C\), the remaining four exterior occurrences in **each row separately** have exactly the same multiset of distinguished-edge bits as the four unused factor slots. Match these bits by a permutation of the unused slots. Splice every exterior occurrence with its assigned factor occurrence. Each of the two new rows double-covers every factor edge and both connector edges. Since the selected factor matchings for \(B,C\) are identical in the two rows, their lifts are literally the same complete perfect matchings across rows. Thus (1) holds in \(H\), proving the reverse implication. \(\square\)

The proof coordinates only the two identities needed by (1). The other four factor slots may be permuted independently in the two rows. Hence it does not claim a canonical lift of every exterior matching or every dependency among a larger family of rows. That stronger property is available for three-edge-colourable factors in [Note 099](099-three-edge-colourable-two-sums-preserve-dependent-splice-fibres.md); [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md) supplies the complete-support projection used below.

The same slot argument preserves **all** shared identities of any two BF rows when each shared matching occurs once in each row. Among those identities, at most two use \(e\) and at most four avoid it, exactly the capacities of the two factor-slot classes. Assign distinct slots to the shared identities first, by their \(e\)-bits, and fill the unshared slots independently in each row. This two-row statement requires no restriction on how many distinct matchings the rows share; repeated occurrences of one matching within a row require a separate condition and are not asserted here.

## Consequence under the negative Case-XII exclusions

If \(J\) has a BF cover, [Note 103](103-bf-covered-two-sums-preserve-support-and-single-fibre-existence.md) gives

\[
\operatorname{BFsupp}(H)=\operatorname{BFsupp}(H_0).  \tag{4}
\]

Hence both exact Case-XII support and the weaker condition of having no \(T\)-loop or \(T\)--\(T\) type are inherited in both directions. Let \(\operatorname{Rows}_6(G)\) mean that the six Note-101 row equations admit actual matching assignments with the same repeated *names*, but without further aliases or prescribed disequalities. Under only these two negative support exclusions,

\[
\operatorname{Rows}_6(G)\iff\operatorname{Seed}(G).     \tag{5}
\]

Indeed, the state-\(14\) and cross-column rows of a six-row assignment are (1). Conversely, start with (1) and keep the actual \(r_{23},B,X\) half. The state-\(14\) complementary half \(q_{14},A,C\) is present. The absence of every \(T\)-loop and \(T\)--\(T\) type allows the column-saturation theorem of [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) to decompose the same complementary load at all five states \(13,14,24,25,35\), retaining the original state-\(14\) row and the independent cross-column row. Name the new matchings by their states. This produces all six rows with every repeated name used consistently; no extra cross-row identity is asserted.

Combining (3)--(5), for a BF-covered factor and a pole with no \(T\)-loop or \(T\)--\(T\) support,

\[
\boxed{
\operatorname{Rows}_6(H)\iff\operatorname{Rows}_6(H_0).
}                                                         \tag{6}
\]

Thus no BF-covered closed factor can create the two-row common-identity seed needed to start the six-row Case-XII argument, or destroy one already present, while preserving exact boundary support. Contracting such a factor preserves support and seed at the level of cubic poles; any additional simplicity, bridgelessness or minimum-host hypothesis on the reduced pole must be checked separately. The theorem does not cover the three optional aliases of [Note 116](116-alias-preserving-factor-obstruction-to-the-case-xii-rectangle.md), nor does it force \(\Lambda_L\cap\Lambda_R\ne\varnothing\) in an indecomposable pole. That complete-PM intersection remains the first unresolved positive step; a [seven-vertex genuine pole](../scratch/case_xii_rectangle_20260923/common_bc_seed_obstruction_20260926.md) shows that two positive cells and no all-terminal cover alone do not force it because that pole has forbidden \(T\)-support.

Taking \(J\) to be the Petersen graph gives a sharper logical boundary. Its BF cover preserves exact support and the truth value of \(\operatorname{Seed}\) by (3)--(4), while the resulting two-sum is Tait-empty: a three-edge-colouring would restrict across the two-edge cut to a three-edge-colouring of the Petersen factor. Thus, if an exact-Case-XII pole exists, both its support and its seed status can occur in a Tait-empty pole of larger order. This construction has a nonterminal two-edge cut and is not automatically eligible as the side of a minimum BF counterexample.

## Exact factorization of the pair-load spectra

The existential transfer (3) has a set-level form. For \(d\in\{0,1,2\}\), let \(\Gamma_d(J,f)\) consist of complete vectors \(U+V\) where \(U,V\) occupy **two distinct occurrence slots** of one BF cover of \(J\) and \(U(f)+V(f)=d\). The two occurrences may contain the same perfect matching. For compatible vectors \(x\) on \(H_0\) and \(y\) on \(J\), with \(x(e)=y(f)=d\), write \(x\star y\) for the load on \(H\) which equals \(x\) off \(e\), equals \(y\) off \(f\), and has load \(d\) on each connector edge. The connector coordinates make \(\star\) injective in the pair \((x,y)\).

Put \(\Lambda_{Z,d}(H_0)=\{x\in\Lambda_Z(H_0):x(e)=d\}\), for \(Z=L,R\). Then

\[
\Lambda_Z(H)=
\bigcup_{d=0}^{2}\Lambda_{Z,d}(H_0)\star\Gamma_d(J,f),
\qquad Z=L,R.                                            \tag{7}
\]

Indeed, projection of a BF row of \(H\) gives the exterior row and a factor BF cover; its \(B,C\) factor occurrences give the required member of \(\Gamma_d\). Conversely, take a row realizing \(x\) and a factor cover containing the two occurrences realizing \(y\). Assign those factor occurrences to \(B,C\) according to their distinguished-edge bits. When \(d=1\), exactly one occurrence on each side contains the distinguished edge, so the assignment can be swapped into the required order. The four remaining factor slots have exactly the bit multiset of the four remaining exterior occurrences. A bit-preserving permutation splices them to a BF row realizing \(x\star y\). This proves both inclusions of (7).

Since \(\star\) is injective and the same \(\Gamma_d\) appears on both sides,

\[
\Lambda_L(H)\cap\Lambda_R(H)=
\bigcup_{d=0}^{2}
\bigl(\Lambda_{L,d}(H_0)\cap\Lambda_{R,d}(H_0)\bigr)
\star\Gamma_d(J,f).                                    \tag{8}
\]

Every BF cover of \(J\) has two \(f\)-containing and four \(f\)-avoiding slots, so \(\Gamma_0,\Gamma_1,\Gamma_2\) are all nonempty whenever \(J\) is BF-covered; when it is not, all three are empty. Equation (8) therefore recovers (3) and specifies the entire common pair-load spectrum, including multiplicity-two and repeated-factor occurrences. The formula holds without any Case-XII support assumption and separates the indecomposable exterior obstruction from every closed two-sum factor.

For the Petersen factor, the six perfect matchings occur exactly once in its BF cover, and each unordered pair shares a different single edge. Thus \((|\Gamma_0|,|\Gamma_1|,|\Gamma_2|)=(6,8,1)\). Writing \(I_d=\Lambda_{L,d}(H_0)\cap\Lambda_{R,d}(H_0)\), injectivity in (8) gives the explicit count
\[
|\Lambda_L(H)\cap\Lambda_R(H)|
=6|I_0|+8|I_1|+|I_2|.                           \tag{9}
\]
This counts distinct complete pair-load vectors, not BF rows or matching occurrences.
