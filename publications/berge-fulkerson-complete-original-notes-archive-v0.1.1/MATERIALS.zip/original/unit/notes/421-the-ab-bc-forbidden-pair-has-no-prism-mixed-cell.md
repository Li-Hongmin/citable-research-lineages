> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(ab,bc\) forbidden pair has no required mixed row on the marked prism

Use the marked two-spoke prism of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md), with tree
\[
(u_1,u_2,u_3,u_4,u_5)=(AB,BC,Aa,Bb,ac)
\]
and marked terminals \(X=AC,\ Y=Cc,\ Z=bc,\ W=ab\); the sixth shore terminal is \(e\). The shore is an arbitrary cubic six-pole. Suppose the complete BF support is exact Case XII with forbidden \(e\)-labels \(\{W,Z\}\). The two possible allowed pentagons are
\[
S_1=e-X-W-Z-Y-e,\qquad S_2=e-X-Z-W-Y-e.                \tag{1}
\]
Both have \(eY,eX\in S_i\), \(eW,eZ\in T_i\), and require the mixed type \((eW)(eY)\) by [the original Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

> **Mixed-cell exclusion.** No six complete perfect matchings of this marked exterior and any shore form an exact-Case-XII row of type \((eW)(eY)\). Consequently neither pentagon in (1) is the complete BF boundary support of a pole with this exterior, at any shore order.

Suppose such a row exists. Let \(P=eW\) be its forbidden triple, \(R=eY\) its allowed triple, \(K=Y\), \(J=W\) its named singleton occurrences, and \(D_0,D_1=e\) the two singleton-\(e\) occurrences. The root \(c\) of \(R=eY\) is excluded by [Note 420](420-the-direct-cc-root-cannot-enter-a-mixed-row-when-ab-and-bc-are-forbidden.md); hence \(R\) is rooted at \(C\). Its tree slots are \((A,B,a,b,c)\). Switching the \(Y\)-starting path of \(R\triangle K\) must produce \(eX\), since both other possible new \(e\)-pairs lie in \(T_i\), alongside unchanged \(P\in T_i\). Note 420 traces the only two possible \(Y\to X\) routes:
\[
Y-t_Y-C-t_X-X,\qquad
Y-t_Y-C-u_2-B-u_1-A-t_X-X.                            \tag{2}
\]

**The short route is impossible for either root of \(P\).** Both \(eW:a\) and \(eW:b\) take \(Cu_2\). If \(K\) uses the short route, it takes \(X:C\), whereas \(R\) takes \(Y:C\). At \(C\), each of \(Cu_2,X:C,Y:C\) needs load two, so among \(J,D_0,D_1\) one takes each. In particular some singleton-\(e\) occurrence \(D\) takes \(X:C\) or \(Y:C\). Switching the short path between \(R,K\) gives \(R'=eX:C\) with exactly the same shore mask as \(R\).

For this \(D\), the exterior \(W\)- and \(Z\)-terminal components in \(R\triangle D\) and \(R'\triangle D\) are unchanged. Indeed, if \(D\) takes \(Y:C\), the \(X\)-arm of \(R\triangle D\) is extended through \(Y-C-X\) to become the \(Y\)-arm of \(R'\triangle D\); if \(D\) takes \(X:C\), its \(X\)-arm is shortened to become the \(Y\)-arm. If \(W,Z\) join each other wholly outside the shore, neither prescribed \(e\)-switch is possible. Otherwise their unchanged arms exit at distinct ports. The shore \(e\)-path has the same first proper exit in the two comparisons. Under \(S_1\), switching \(e\) in \(R=eY\) must reach \(Z\), while in \(R'=eX\) it must reach \(W\); under \(S_2\) the targets are \(W,Z\), respectively. One shore exit cannot select these two unchanged distinct arms. Thus \(K\) uses the long route in (2), and its switch gives \(R'=eX:A\) with the same complete shore mask as \(R\). In particular
\[
K:\quad Y\text{ terminal},\quad X:A,\quad Cu_2,\quad Bu_1. \tag{3}
\]

**First root \(P=eW:a\).** Its tree slots are \((B,C,A,b,c)\). Thus \(P,R\) saturate \(bu_4,cu_5\). Since \(K\) takes the \(Y\) terminal, it cannot take \(Y:c\), so \(K:Z:c\); at \(b\), it then cannot take \(Z:b\), and \(bu_4\) is saturated, so \(K:W:b\).

At \(t_W\), \(P\) takes \(W:a\), \(K\) takes \(W:b\), and \(R,J\) take the terminal. Hence one \(e\)-singleton \(D\) takes \(W:b\) and the other \(D'\) takes \(W:a\). At \(b\), \(J,D'\) must take \(Z:b\); at \(c\), neither can take \(Z:c\), so both take \(Y:c\). The remaining \(c\)-slot gives \(D:Z:c\), and therefore \(D:Y:C,\ X:A\). Since \(P,K\) saturate \(Bu_1\), this \(D\) covers \(B\) by \(Bu_2\) or \(Bu_4\). It covers \(a\) by \(au_3\) or \(au_5\); its \(u_1\)-slot is \(p_1\).

The \(W,Z\) exterior arms against this same \(D\) have the following exits:
\[
\begin{array}{c|cc|c}
D\text{ at }B &W\text{ against }R&W\text{ against }R'&
                  Z\text{ against both}\\\hline
Bu_2&p_4&p_4& p_3\text{ or }p_5\\
Bu_4&p_2&p_1& p_3\text{ or }p_5
\end{array}                                                   \tag{4}
\]
The \(Z\)-exit is \(p_5\) when \(D:au_3\), and \(p_3\) when \(D:au_5\). For example, the \(W\)-arm follows \(W-t_W-b-u_4\); when \(D:Bu_4\), it continues through \(B-u_2-p_2\) against \(R\), but through \(B-u_1-p_1\) against \(R'\). The \(Z\)-arm follows \(Z-t_Z-c-u_5\) and is unchanged by (2). Under \(S_1\) the common shore \(e\)-exit would have to lie in \(\{p_3,p_5\}\) against \(R\) and in \(\{p_1,p_4\}\) against \(R'\). Under \(S_2\) it would have to lie in \(\{p_2,p_4\}\) and \(\{p_3,p_5\}\), respectively. Both are impossible.

**Second root \(P=eW:b\).** Its tree slots are \((A,C,a,B,c)\). Now \(P,R\) saturate \(au_3,cu_5\). Again \(K:Z:c\). At \(b\), \(K\) cannot take \(Z:b\), so it takes \(bu_4\) or \(W:b\).

If \(K:bu_4\), then \(K:W:a\). Now \(P:W:b\), \(R,J\) take the \(W\) terminal, so the two \(e\)-singletons split \(W:a,W:b\). Let \(D\) take \(W:b\). The edge \(bu_4\) is saturated by \(R,K\), forcing \(J\) and the other \(e\)-singleton to take \(Z:b\). Since \(P,R\) saturate \(cu_5\) and \(K:Z:c\), those two must take \(Y:c\); hence \(D:Z:c,\ Y:C,\ X:A\). Also \(P,R\) saturate \(au_3\), so \(D:au_5\), and its \(Z\)-arm against both \(R,R'\) exits at \(p_3\). Its \(W\)-arm exits at \(p_2\) against \(R\) and \(p_1\) against \(R'\) if \(D:Bu_4\); otherwise it exits at \(p_4\) in both. Thus \(S_1\) demands the same shore exit be \(p_3\) and one of \(p_1,p_4\), while \(S_2\) demands one of \(p_2,p_4\) and \(p_3\). Both contradict the fixed shore mask.

If \(K:W:b\), the edge \(W:b\) is saturated by \(P,K\), so both \(D_0,D_1\) take \(W:a\). Should either \(D_i\) leave \(u_3\) through \(p_3\), its \(W\)-terminal arm would exit at \(p_3\) against both \(R\) and \(R'\). The \(Z\)-arm has a distinct exit in each comparison, contradicting the opposite \(W/Z\) targets prescribed by either pentagon in (1). Hence both \(D_i\) take \(Au_3\). These two saturate \(Au_3\), while \(P,R\) saturate \(Au_1\); since \(K:X:A\), the other \(X:A\) slot belongs to \(J\), and both \(D_i\) take \(X:C\). At \(C\), \(P,K\) saturate \(Cu_2\) and \(R\) takes \(Y:C\), so \(J:Y:C\) and both \(D_i:Y:c\). Then \(J:Z:c\), \(J:bu_4\), and both \(D_i:Z:b\). Finally \(P,R,K\) use \(Bu_4,Bu_2,Bu_1\), respectively; \(J\) uses \(Bu_1\) or \(Bu_2\), so one of the two \(D_i\) covers \(B\) by \(Bu_1\) or \(Bu_2\), not by \(Bu_4\). Choose this \(D\). Direct tracing gives
\[
\begin{array}{c|cccc}
D\text{ at }B&W\text{ against }R&W\text{ against }R'&
Z\text{ against }R&Z\text{ against }R'\\\hline
Bu_1&p_2&p_2&p_4&p_4\\
Bu_2&p_1&p_1&p_4&p_4
\end{array}                                                   \tag{5}
\]
For the \(W\)-arm against \(R'\), the route is
\(W-t_W-a-u_3-A-t_X-C-u_2\), then directly to \(p_2\) if \(D:Bu_1\), or through \(B-u_1-p_1\) if \(D:Bu_2\). The \(Z\)-arm exits through \(Z-t_Z-b-u_4-p_4\) in both comparisons. Again the common shore \(e\)-exit would have to select distinct, unchanged \(W,Z\) arms. This contradiction exhausts both roots of \(P\), proves the mixed-cell exclusion, and therefore rules out the forbidden pair \(\{ab,bc\}\) for this marked prism. \(\square\)

Combined with [Notes 413](413-two-spoke-prism-exact-case-xii-requires-odd-zero-port-complements.md) and [419](419-an-exterior-reslotting-excludes-the-last-adjacent-prism-row.md), four of the six forbidden \(e\)-pairs for this marked exterior are excluded. The two pairs still open here are \(\{AC,Cc\}\) and \(\{AC,ab\}\). This does not exclude other exterior profiles or settle Berge–Fulkerson. The proof is a hand derivation using full matching occurrences and remains to be checked independently; no local mathematical recomputation or OMEN was used.
