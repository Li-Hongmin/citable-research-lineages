> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-loop rectangle excludes an opposite tree--\(R^*\) colour pattern in \(I_m\)

Work in the genuine \(I_m\) quotient of
[Note 210](210-two-star-rectangles-restrict-the-rstar-im-connector.md).
Let \(A^\circ\) be the three-vertex tree centred at its \(u_1\)
port, with end groups
\[
                         \{u_2,x\}\mid\{z,p\}.             \tag{1}
\]
Let \(B^\circ\) have the complete Figure-7 Case-XIII \(R^*\)
BF relation on \(\{u_1,u_2,z,y,q\}\). Write \(c(rs)\) for
the Figure-7 block of a pair state. If
\[
          \boxed{c(yz)=c(qz)\ne c(yu_2)=c(qu_2),}           \tag{2}
\]
then the outer five-pole does **not** have exact Case-XII support.
The proof composes genuine six-perfect-matching shore rows and does
not assume that either shore is a formal boundary relation detached
from its internal edges.

The [published Figure 7 and Appendix XIII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf)
give the blocks
\[
P=\{13,14,24,35,45\},\qquad
Q=\{12,15,23,25,34\}.                                    \tag{3}
\]
Every cross-block pair is an actual \(B^\circ\) BF type. We first
give two port-independent transports. As usual, a digit pair is a
two-slot edge label. The exact connector is the gate (G) in the
[two-vertex quotient draft](../scratch/two-vertex-two-five-cut-quotients-draft.md).

## Two actual loop transports

If \(B^\circ\) supports \((yu_2)(yz)\), then the outer relation
contains \([yz]\). Use the tree's actual type \((u_2z)(xz)\)
and assign the six shore boundaries as follows. A triple boundary is
written as its three ports.

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) | \(u_2\) |
| 2 | \(u_1u_2p\) | \(z\) |
| 3 | \(x\) | \(u_1u_2q\) (missing \(yz\)) |
| 4 | \(u_2\) | \(u_1zq\) (missing \(yu_2\)) |
| 5, 6 | \(z\) | \(y\) |

The shore-half labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&24&56&13/12&-\\
B&34&13&24&-&56/34
\end{array}.
\]
Thus \(R_1=R_2=56\). Set
\[
 (D_x,D_y,D_p,D_q)=(24,13,34,12).
\]
The direct \(z\)-mark and the four marked subdivision vertices
then have outer labels
\[
       (T_z,T_x,T_y,T_p,T_q)=(13,56,24,56,56).
\]
Slots \(5,6\) have exactly \(x,p,q\), hence the actual outer
loop \([yz]\).

If \(B^\circ\) supports \((qu_2)(qz)\), then the outer relation
contains \([zq]\). Double the tree's actual \(u_2z\) Tait row,
whose triple boundary is \(u_1xp\), and use this six-slot pairing:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) | \(u_2\) |
| 2 | \(u_1xp\) | \(q\) |
| 3 | \(u_2\) | \(u_1zy\) (missing \(qu_2\)) |
| 4 | \(u_2\) | \(z\) |
| 5 | \(z\) | \(u_1u_2y\) (missing \(qz\)) |
| 6 | \(z\) | \(q\) |

Here the shared-port and private-port labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&34&56&12/12&-\\
B&35&15&34&-&35/26
\end{array}.
\]
Set
\[
 (R_1,R_2;D_x,D_y,D_p,D_q)
                 =(46,26;35,12,35,14).                     \tag{4}
\]
At \(u_1,u_2,w_1,w_2\) and every marked subdivision vertex,
the incident two-slot labels partition \([6]\). The outer terminal
labels are
\[
       (T_z,T_x,T_y,T_p,T_q)=(12,46,46,46,35).             \tag{5}
\]
Slots \(4,6\) both have exactly \(x,y,p\), proving the actual
outer loop \([zq]\). In both constructions the input shore rows
already cover each internal edge twice; the connector partitions
therefore give six genuine outer perfect matchings, not merely
compatible boundary words.

## The colour rectangle

Condition (2) makes \((yu_2)(yz)\) and \((qu_2)(qz)\) actual
\(B^\circ\) rows. The two transports force \([yz],[zq]\).
Let \(d=c(yq)=c(qy)\). Because the blocks are binary, exactly
one of the following holds:

* If \(d\ne c(yz)=c(qz)\), the tree's actual star
  \((xz)(xp)\) and [Note 212, (3)](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)
  force \([xy],[xq]\) from the \(B\)-stars
  \((yz)(yq),(qz)(qy)\). Together with \([yz],[zq]\),
  these form the four-cycle \(x-y-z-q-x\).
* If \(d=c(yz)=c(qz)\), the tree's actual star
  \((pu_2)(px)\) and the same transport force \([py],[pq]\)
  from the \(B\)-stars \((yu_2)(yq),(qu_2)(qy)\).
  Together with \([yz],[zq]\), these form the four-cycle
  \(p-y-z-q-p\).

The loop support of exact Case XII is one five-cycle and contains
neither four-cycle. This proves the claim.

For example, both published placements
\[
       (y,q,u_2,z,u_1)=(1,5,2,3,4)
       \quad\text{and}\quad(1,5,3,2,4)                      \tag{6}
\]
satisfy (2). In the first, \(yz=qz=P\) and
\(yu_2=qu_2=Q\); in the second, the two colours reverse.

In fact, **no placement with \(\{y,q\}=\{1,5\}\) survives**.
These two labels are colour twins: \(yq=15\in Q\), both edges
to port \(2\) lie in \(Q\), and both edges to ports \(3,4\)
lie in \(P\). If \(u_2,z\) occupy one of \(2\) and one of
\(3,4\), condition (2) applies. If they occupy \(3,4\),
both \(y,q\) stars have \(P\)-edges toward both \(u_2,z\)
and a \(Q\)-edge toward the other private port. The tree stars
\((xz)(xp)\) and \((pu_2)(px)\) with Note 212, (3) force
all four loops \([xy],[xq],[py],[pq]\), another four-cycle.
This covers all twelve labelled placements with
\(\{y,q\}=\{1,5\}\).

The pure star argument also excludes
\(\{y,q\}=\{3,4\}\), \(\{u_2,z\}=\{1,5\}\).
Here \(yq=34\in Q\), while all four states from \(y,q\)
to \(u_2,z\) lie in \(P\). The two tree stars therefore
force \([xy],[xq],[py],[pq]\), a four-cycle. This covers
four further labelled placements, regardless of which of
\(1,5\) is \(u_2\).

The Figure-7 placements satisfying (2) can be read off without
checking all \(5!\) port orders. The only unordered private-port
pairs having both a common \(P\)-neighbour and a common
\(Q\)-neighbour are
\[
\begin{array}{c|c|c}
\{y,q\}&\text{common }P\text{ neighbours}
                 &\text{common }Q\text{ neighbours}\\\hline
\{1,2\}&\{4\}&\{5\}\\
\{1,5\}&\{3,4\}&\{2\}\\
\{2,5\}&\{4\}&\{1\}
\end{array}.                                                  \tag{7}
\]
Indeed the \(P\)-neighbour sets at local ports \(1,\ldots,5\)
are respectively \(\{3,4\},\{4\},\{1,5\},\{1,2,5\},\{3,4\}\);
the \(Q\)-neighbour sets are their complements among the other
four ports. Consequently (2) additionally excludes the four
labelled placements with \(\{y,q\}=\{1,2\}\) and
\(\{u_2,z\}=\{4,5\}\), and the four with
\(\{y,q\}=\{2,5\}\) and \(\{u_2,z\}=\{1,4\}\).
Together with the twelve \(\{1,5\}\) placements, this gives
twenty excluded labelled relative orders in the end partition (1).

The theorem does not classify the other private-port pairs for
(1), the mirror tree centre \(u_2\), other shore pairings, or the
full exact-Case-XII closure. The analytic argument awaits an
independent check.
