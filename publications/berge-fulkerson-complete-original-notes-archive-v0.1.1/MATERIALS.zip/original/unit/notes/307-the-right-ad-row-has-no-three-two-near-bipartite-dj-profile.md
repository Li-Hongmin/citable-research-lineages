> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right ad row has no three-two near-bipartite DJ profile

> **Retracted (2026-10-01):** The zero-port/four-port exchange lemma
> below is valid, but the theorem relies on Note 305's false
> exclusion of the \(E\)--\(I\) pairing. [Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md)
> proves that this pairing is forced and produces an **allowed**
> \((ea)(cd)\) BF row. The claimed exclusion of the right \(ad\)
> branch is withdrawn.

Work in the actual central-path exterior with complete exact-Case-XII
perfect-matching support and the required left \((ea)(ac)\) and right
\((ea)(ad)\) BF rows of [Notes 271 and 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md).
Suppose the unmarked shore core becomes bipartite on deleting an edge
\(g\subset B\), with \(|B|-|R|=1\), and the internal marked edge has
ends \(v\in B,w\in R\). As in [Notes 299–301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md),
the only unresolved placement of the two \(R\)-based proper ports is
\(R_0=DJ\); the \(B\)-based proper ports are \(A,I,H\).

**Theorem.** The \(R_0=DJ\) placement is impossible. Consequently no
exact-Case-XII pole has these two row orientations and this \(3{:}2\)
near-bipartite core profile. This assertion does not assume that the
Hall witness of [Note 304](304-the-two-marked-return-cycles-leave-a-tight-hall-corridor.md)
is small or has no local collision.

The decisive closure observation is elementary. Let \(X\) be any
zero-proper-port shore matching selecting \(g,t_{ew}\), and let \(F\)
be a shore matching selecting terminal port \(E\) and \(g\), with
exactly three proper ports \(P\). In \(F\triangle X\) the four open
ends are \(E\cup P\). The path beginning at \(E\) contains \(t_{ew}\),
because \(F\) selects \(E\) at the subdivision vertex and \(X\)
selects \(t_{ew}\). The other open path avoids both \(t_{ew}\) and
\(g\), the latter being common to the two matchings. Switching this
other path into \(X\) therefore makes an actual two-proper-port shore
matching selecting \(g,t_{ew}\), with its two ports in \(P\). In the
\(DJ\) profile, [Note 296, Theorem 2](296-four-port-zero-port-switch-excludes-the-last-four-edge-hall-tree.md)
allows only the pair \(HJ\) in that complete fibre. Thus \(P\) must
contain both \(H,J\). In particular, \(P=\{I,D,J\}\) is impossible.

Now take three *actual* right-row shore matchings from
[Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md):
\[
\begin{array}{c|c|c}
&\text{selected shore ports}&\text{selected exceptional edges}\\\hline
X&\varnothing&g,t_{ew}\\
U&EJ&g\\
Y&ID&t_{ev}.
\end{array}                                                    \tag{1}
\]
The matching \(U\) selects terminal \(E\), and \(Y\) avoids \(g\).
Their shore symmetric difference has two open paths on
\(E,J,I,D\). [Note 305](305-every-tight-hall-corridor-must-contain-the-i-port-base.md)
proves that these paths pair \(EJ\mid ID\): an \(E\)--\(D\)
pairing contradicts the bipartite matching balance, while an
\(E\)--\(I\) pairing permits a complete \(e\)--\(b\) switch to the
forbidden BF type \((ea)(cd)=(12)(45)\), listed on the opposite pole
in [Máčajová–Mazzuoccolo–Tabarelli, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf).

For completeness, the \(E\)--\(J\) path contains \(g\). It starts
through \(t_{ev}\) because \(U\) selects \(E\) and \(Y\) selects
\(t_{ev}\). If it avoided \(g\), switching it into \(U\) would give
a zero-proper-port matching selecting \(g,t_{ev}\), contrary to
[Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md).
Hence the separate \(D\)--\(I\) path avoids \(g\), \(t_{ev}\), and
the subdivision vertex. Switch just this shore path into \(U\).
The result is a real shore matching
\[
       F:\qquad S(F)=\{E,I,D,J\},\qquad E,g\in F.       \tag{2}
\]
Its three proper ports are \(P=\{I,D,J\}\), contradicting the
zero-port closure observation. \(\square\)

The contradiction uses the *complete* two-port fibre exclusions,
the actual zero-port slot of the right row, and one genuine cross-row
orientation. It bypasses the tight Hall corridor: Notes 304–306 remain
valid necessary statements for their stated hypotheses, and Note 304's
graph remains a counterexample to the weaker two-cycle implication,
but no such corridor can rescue this exact right-row branch. The left
\((ea)(ad)\) orientation, other near-bipartite profiles, other shore
cores, and Berge–Fulkerson remain open. This is a hand proof; its
upstream exterior-mask and complete-fibre arguments have not had an
independent second-source verification.
