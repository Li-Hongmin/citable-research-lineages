> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The crossed marked path in \(K_{3,3}\) has no exact-Case-XII row

Continue the five-vertex tree exterior of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). Take the \(K_{3,3}\) bipartition \(\{x,y,z\}\sqcup\{r,s,t\}\), with unmarked tree edges
\[
 xr,\ xs,\ xt,\ yr,\ zs
\]
subdivided by \(u_0,u_1,u_2,u_3,u_4\), respectively. Their shore ports are \(p_0,\ldots,p_4\). The four marked edges form the path
\[
 a=ys,\qquad b=yt,\qquad c=zt,\qquad d=zr,
 \qquad s-a-y-b-t-c-z-d-r.                              \tag{1}
\]
The fifth mark \(e\) lies in the arbitrary six-port shore \(Z\). Fix the crossed pentagon
\[
 S=e-a-d-c-b-e,\qquad T=\{ec,ed,ab,ac,bd\}.          \tag{2}
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ab)\) BF row and excludes every row whose two states lie in \(T\), including \([ab]\). In the published labels \((e,a,d,c,b)=(3,1,4,2,5)\), the required row is \((13)(15)\).

**Theorem.** No cubic five-pole with exterior (1) has complete exact-Case-XII support (2), at any shore order or cycle rank. The reversal of the marked path excludes the reflected placement with \(e\)-neighbours \(c,d\) as well. The argument uses only complete perfect-matching exchanges and does not identify shore matchings belonging to different rows.

**Proof.** Suppose a required \((ea)(ab)\) row exists. Name its state-\(ea\) triple \(P\), state-\(ab\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(b\) matching \(B\), and singleton-\(a\) occurrences \(A_1,A_2\). By [Note 230's shore quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(P\) has no proper shore port, and [Note 358's rooted-tree rule](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) gives only the roots \(y,s\). Since \(R=ab\in T\), switching \(P\) with either \(A_i\) must change state \(ea\) to \(eb\in S\); an endpoint \(c\) or \(d\) would produce \(ec,ed\in T\). The \(a\)--\(b\) alternating path stays wholly exterior by the argument of [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md). Following the rooted tree gives exactly these possibilities:

| root of \(P\) | route for each \(P\triangle A_i\) terminal path |
|---|---|
| \(y\) | \(D:a-t_a-y-t_b-b\) or \(L:a-t_a-y-u_3-r-u_0-x-u_2-t-t_b-b\) |
| \(s\) | \(K:a-t_a-s-u_1-x-u_2-t-t_b-b\) or \(J:a-t_a-s-u_1-x-u_0-r-u_3-y-t_b-b\) |

For example, at root \(y\), the tree branch from \(r\) toward mark \(d\) would end at \(d\), and the branch from \(x\) through \(s,z\) would end at \(c\) or \(d\); these are forbidden. The other cases follow the same forced-tree tracing. At \(t_c,t_d\), both triples \(P,R\) select the terminal semiedges, so **each** \(A_i\) must choose one half of both marks \(c,d\).

**Root \(y\).** Route \(L\) is impossible for even one \(A_i\). It matches \(r\) through \(ru_0\) and \(t\) through \(t_bt\). Thus that same \(A_i\) would have to choose the \(z\)-half of both \(c=zt\) and \(d=zr\), matching \(z\) twice. Both \(A_i\) therefore use direct route \(D\), so they saturate \(t_by\). The other half \(t_bt\) is used by \(R,E\), and in particular \(E\) uses \(t_bt\).

If \(E\) uses \(t_ay\), its selected marked halves at \(c,d\) are forced to \(t_cz,t_dr\): it already matches \(y,t\), so it must use \(z\) at \(c\) and \(r\) at \(d\). Neither half of \(u_3\) can then belong to \(E\), which uses port \(p_3\). The \(d\)-terminal component of \(P\triangle E\) is the exterior route \(d-t_d-r-u_3-p_3\). Exact support forces the \(e\)-terminal path to end at \(d\), so the shore restriction \(Q=P|_Z\) and \(E|_Z\) pair \(e\) with \(p_3\). Switch \(P\) with one \(A_i\) on \(D\). The new triple has state \(eb\), unchanged shore restriction \(Q\), and the same exterior \(d\)--\(p_3\) component with \(E\). Its \(e\)-path still ends at \(d\), giving \(bd\in T\) beside \(R=ab\in T\), a forbidden genuine row.

If \(E\) instead uses \(t_as\), then it uses \(yu_3\): at \(y\), its \(a\)-half is unavailable and its \(b\)-half lies at \(t\). In \(P\triangle E\), the \(d\)-terminal path reaches \(s\) along
\[
 d-t_d-r-u_3-y-t_a-s,
\]
then continues to a shore port. After switching \(P,A_i\) on the exterior route \(D\), the new state-\(eb\) triple's \(a\)-terminal path reaches \(s\) as \(a-t_a-s\) and follows precisely the **same remaining \(P\triangle E\) tail** to that port. The forced old \(e\)--\(d\) shore pairing now joins \(e\) to \(a\). Switching the new triple with \(E\) gives the forbidden \([ab]\) loop. This rules out root \(y\).

**Root \(s\).** A singleton-\(a\) matching using route \(K\) has the full exterior choices
\[
 A_K:\quad s_a,\ t_bt,\ t_cz,\ t_dr,\ su_1,\ xu_2,\ yu_3;
 \qquad\text{ports }p_0,p_4.                           \tag{3}
\]
Indeed, its selected \(b\)-half occupies \(t\), forcing \(c\) at \(z\), then \(d\) at \(r\); the remaining tree vertex \(y\) uses \(u_3\). A matching using route \(J\) has
\[
 A_J:\quad s_a,\ t_by,\ t_ct,\ t_dz,\ su_1,\ xu_0,\ ru_3;
 \qquad\text{ports }p_2,p_4.                           \tag{4}
\]
Here the route occupies \(r\), forcing \(d\) at \(z\) and then \(c\) at \(t\). These are complete exterior restrictions, independent of the shore-internal matching.

If both \(A_i\) use \(K\), they saturate \(t_bt\), so \(R,E\) use \(t_by\). Since \(R\) already uses \(y\) at mark \(b\), it selects \(t_as\). The \(a\)-half \(t_as\) is now loaded by \(P,R\), forcing \(E,B\) to use \(t_ay\). But \(E\) cannot choose both \(t_by\) and \(t_ay\), which meet at \(y\).

Suppose one occurrence uses \(K\) and the other uses \(J\). At \(z\), the triples \(P,R\) both use \(zu_4\): \(P\) by its root orientation, and \(R\) because it has terminal semiedges at both \(c,d\). At \(s\), both \(A\)'s use \(su_1\), so \(R\) cannot use \(su_4\), as that would match \(u_4\) twice. Hence \(R\) selects \(t_as\). At \(y\), the edge \(yu_3\) is saturated by \(P,A_K\), and \(R\) cannot select \(t_ay\); therefore \(R\) selects \(t_by\). At \(t_b\), \(R,A_J\) saturate \(t_by\), leaving \(E,A_K\) on \(t_bt\). At \(t\), the tree edge \(tu_2\) is selected by \(P,R\), while \(A_J\) selects \(t_ct\) by (4). Thus \(B\) must select \(t_ct\). Switch \(P,A_K\) on \(K\). The resulting \(eb\)-triple uses \(t_bt\); with the untouched singleton \(B\) on \(t_ct\), its complete symmetric difference contains \(b-t_b-t-t_c-c\). Switching this exterior component gives \(ec\in T\) beside \(R=ab\in T\), impossible.

Finally suppose both \(A_i\) use \(J\). If \(R\) chose \(t_ay\), then at \(s\) it would have to use \(su_4\): the two \(A\)'s saturate \(su_1\), while \(P\) uses \(t_as\). But \(R\) must also match \(z\) through \(zu_4\), because \(c,d\) are its terminals. That would match \(u_4\) twice. Hence \(R\) selects \(t_as\). At \(t_b\) the two \(A\)'s use \(t_by\), so \(R,E\) use \(t_bt\). At \(t_a\), \(P,R\) use \(t_as\), so \(E\) uses \(t_ay\); its other marked choices are forced to \(t_cz,t_dr\).

Both \(A_i\) use \(ru_3\), leaving \(R\) at \(r\) only \(ru_0\), since \(d\) is its terminal. Thus \(P,R\) use \(ru_0\). At \(t\), the two \(A\)'s use \(t_ct\) and \(R,E\) use \(t_bt\), so \(B\) joins \(P\) on \(tu_2\). At \(x\), the two \(A\)'s use \(xu_0\) and \(P\) uses \(xu_1\). If \(R\) used \(xu_1\), both \(E,B\) would have to use \(xu_2\), although \(B\) already uses \(tu_2\). Therefore \(R\) uses \(xu_2\), and \(E\) also uses \(xu_2\). At \(u_0\), \(P,R\) use \(ru_0\) and the two \(A\)'s use \(xu_0\), so \(E\) uses port \(p_0\).

In the original \(P\triangle E\), the \(d\)-terminal exterior route is \(d-t_d-r-u_0-p_0\); exact support forces the shore pairing \(ep_0\). Switch \(P\) with either \(A_J\) along \(J\). The new state-\(eb\) triple keeps the same shore matching, while its \(a\)-terminal exterior route with \(E\) is
\[
 a-t_a-y-t_b-t-u_2-x-u_0-p_0.                         \tag{5}
\]
The unchanged shore pairing \(ep_0\) now joins \(e\) to \(a\). A second complete-matching exchange yields the forbidden \([ab]\) loop. All root choices and routes are exhausted. \(\square\)

The argument proves an exclusion for the crossed path placement (2), and its marked-path reversal, without any bound on \(|Z|\) or its cycle rank. It does not cover the other pentagon placements on this marked path, the Hamilton-path marking of \(K_{3,3}\), the triangular prism, or Case XII in general. Every displayed switch acts on a component of two **actual complete matchings**, so it preserves the BF edge load. The proof is analytic and has not received an independent review; no local mathematical recomputation was used.
