> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The complementary whole-host seven-pole has only one- and three-port matchings

Assume the connected deficient-core, minimum-host, full exact-Case-XII
setting of [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md).
Write \(F=J-M\) for the core after deleting the five marked edges.
Let \(U\) be a normalized maximum Tutte barrier of size \(k\), and
take its profile with one odd component \(C\) whose cut in the
simple marked core \(J\) has seven edges and contains no internal
mark.  The other \(k+1\) components of \(F-U\) are singletons.
All five marks join different components, and the complete minimum
host \(G\) contains the opposite pentagon attached through their
subdivision vertices.  Open the seven-edge cut of \(C\) in \(G\)
and call the complementary seven-pole \(E(C)\).

For a perfect matching \(N\) of \(E(C)\), let \(b\) be the number
of selected cut semiedges, \(a\) the number of those semiedges at
vertices of \(U\), and \(h\) the number of edges from the five
marked subdivision vertices to the opposite pentagon.  Then
\[
                    \boxed{b+h=4.}                            \tag{1}
\]
Indeed, the \(k-a\) barrier vertices not matched through the cut
must match singleton components.  Of the five marked subdivision
vertices, \(b-a\) are matched through the cut and \(h\) to the
pentagon.  Each of the remaining \(5-(b-a)-h\) matches one
singleton.  These edges match all \(k+1\) singleton vertices,
exactly once, so
\[
        (k-a)+5-(b-a)-h=k+1,
\]
which is (1).  The parity of the odd seven-pole makes \(b\) odd;
the odd pentagon makes \(h\) positive and odd.  Hence
\[
 \boxed{(b,h)=(1,3)\text{ or }(3,1).}                         \tag{2}
\]
In particular \(E(C)\) has no matching with five or seven cut
ports, regardless of the order or interior of \(C\).

If \(E(C)\) has an actual six-matching BF row, let \(n_1,n_3\)
count its one- and three-port matching occurrences.  Its seven
cut semiedges each have load two, while (2) excludes every other
boundary size.  Thus \(n_1+n_3=6\) and \(n_1+3n_3=14\), giving
\[
                    \boxed{(n_1,n_3)=(2,4).}                  \tag{3}
\]
These are single-matching and rowwise quotas for the *alternative*
whole-host shore.  They neither assert that this seven-pole has a
BF row nor classify its complete boundary relation.  In
particular they do not exclude the seven-cut barrier profile when
\(k\ge3\).  The two-vertex connector and its separate full-closure
arguments remain in the
[working draft](../scratch/two-vertex-seven-cut-connector-and-triple-deletions-draft.md).
The analytic proof has not received an independent check.
