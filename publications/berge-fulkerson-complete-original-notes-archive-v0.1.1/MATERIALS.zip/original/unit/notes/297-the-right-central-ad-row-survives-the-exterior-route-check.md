> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right central ad row survives the exterior route check

Use the central-path exterior of
[Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md).
For the conditional exact-support discussion, take the branch in which a
genuine \((ea)(ac)\) row has singleton-\(a\) mask \(Y_L\) **and** its
shore \(e\)-path reaches \(h_1\), so that
\(S=e-a-b-d-c-e\). [Note 357](357-a-left-central-ac-row-does-not-fix-the-pentagon-order.md)
shows why the path condition is separate from the left orientation.
Write the six shore ports as
\[
 E=e,\quad A=a:\Sigma,\quad I=h_1,\quad D=h_2,\quad H=h_3,\quad J=h_4.
\]

**Correction and rowwise exterior boundary.** Note 272's proof that every
\((ea)(ad)\) row has the left exterior is invalid. Its equation (5)
gives a *right* singleton-\(e\) mask whose \(h_3\) route ends at \(d\)
against \(X_{c,R}\), not at \(c\). The incidence, load-two, and
**necessary pure-path tests used in that proof** leave two
exterior templates: Note 272's left table and the right table
below. The right table is realizable by a genuine cubic five-pole
BF row. This does not prove that its half-load is \(S\)-pure in
every decomposition, or that a pole with complete exact-Case-XII
support realizes it. Excluding it there requires a new argument
using additional complete-matching information.

## The overlooked right row

Let \(Y_R=\{c:E,b:A,d:B,3C,4D,h_1,h_2\}\) be the right
singleton-\(a\) exterior of Note 271. The six slots are:

| Slot | Boundary | Selected exterior edges besides its terminal semiedges | Proper shore ports |
|---|---|---|---|
| \(X_a\) | \(b,c,d\) | \(a:C,1A,2B,3D,4E\) | \(\varnothing\) |
| \(Y_a\) | \(a\) | \(Y_R\) | \(I,D\) |
| \(Z_e\) | \(e\) | \(a:\Sigma,b:D,c:A,d:E,1B,2C,h_3,h_4\) | \(A,H,J\) |
| \(U_{ad}\) | \(b,c,e\) | \(a:C,d:E,1A,2B,3D,h_4\) | \(J\) |
| \(V_a\) | \(a\) | \(Y_R\) | \(I,D\) |
| \(W_d\) | \(d\) | \(a:\Sigma,b:D,c:A,1B,2C,4E,h_3\) | \(A,H\) |

The shore port \(E\) is selected in \(Z_e,U_{ad}\), in addition to
the proper ports in the last column. Every displayed exterior mask
covers each of its vertices once: the branch covers in
\((X,Y,Z,U,W)\) are
\((1A,2B,aC,3D,4E)\),
\((bA,dB,3C,4D,cE)\),
\((cA,1B,2C,bD,dE)\),
\((1A,2B,aC,3D,dE)\), and
\((cA,1B,2C,bD,4E)\), respectively.
The ordered \(K\)-edges
\((1A,1B,2B,2C,3C,3D,4D,4E)\) carry slot pairs
\[
       (XU,\ ZW,\ XU,\ ZW,\ YV,\ XU,\ YV,\ XW).       \tag{1}
\]
The proper shore ports \(A,I,D,H,J\) carry, respectively,
\((ZW,YV,YV,ZW,ZU)\). At the marked vertices, the two uses of each
terminal semiedge and each marked half are immediate from the table.
Thus the exterior has exactly load two on every edge.

For \(Z_e\), the inverse exterior routes of Note 271's expanded
16-mask table are
\[
\begin{array}{c|ccc}
&X_a&X_{c,L}&X_{c,R}\\ \hline
\text{port reached from }b&H&H&J\\
\text{port reached from }d&J&J&H\\
\text{port reached from }c&A&\text{--}&\text{--}
\end{array}                                                   \tag{2}
\]
where the last row is relevant only to \(X_a\): the two
state-\(ec\) triples select the \(c\)-mark half and do not select
terminal \(c\). Equivalently, \(H\) reaches \(b\) against \(X_a\)
and \(d\) against \(X_{c,R}\), while \(J\) reaches \(d\) then \(b\).
The shore pairing required by the \(S\)-pure path test is therefore
\[
                    EH\mid AJ.                       \tag{3}
\]
It gives the permitted \(ab,cd\) terminal-path switches in the
state-\(ea\) and state-\(ec\) halves, respectively: the
\(e\)-path ends at \(b\) before, and at \(d\) after, the right
\(a\)--\(c\) exchange. In particular, the route
\(H=u_3-C_{\rm ext}-u_2-B_{\rm ext}-u_1-A_{\rm ext}
-t_c-E_{\rm ext}-t_d-d\) against \(X_{c,R}\) ends at \(d\).
Note 272's stated endpoint \(c\) is impossible because neither
\(X_{c,R}\) nor \(Z_e\) selects the terminal semiedge at \(c\).

The rowwise classification follows directly. Note 271's verified
route table prohibits mixing \(Y_L,Y_R\) in one row. If both
singleton-\(a\) masks are \(Y_L\), Note 272's left load calculation
applies. If both are \(Y_R\), their edges are saturated; the
state-\(ad\) triple must select \(d:E\), then \(a:C\), and its
remaining exterior is \(1A,2B,3D,h_4\). Edge load two uniquely
forces \(Z_e,W_d\) as displayed above. Equation (2) shows that
the pure-path test used by Note 272 does not eliminate this
second case.

## The different near-bipartite load

The right template also changes the later \(3{:}2\) analysis.
Suppose \(C-g\) is bipartite with \(g\subset B\), the internal
mark has ends \(v\in B,w\in R\), and the two \(R\)-based proper
ports are \(D\) and \(r\in\{H,J\}\). The other ports \(A,I,p\)
are \(B\)-based. Assuming the full-family \(ID\)-fibre exclusion
proved independently of row choice in Note 290, Note 283's
balance equation gives the right row's complete marked-edge
profile:

| \(r\) | \(X_a\) | \(Y_a,V_a\) | \(Z_e\) | \(U_{ad}\) | \(W_d\) |
|---|---|---|---|---|---|
| \(H\) | \(g,t_ew\) | \(t_ev\) | \(E\), no \(g\) | \(E\), no \(g\) | \(g,t_ew\) |
| \(J\) | \(g,t_ew\) | \(t_ev\) | \(E\), no \(g\) | \(E,g\) | \(t_ew\), no \(g\) |

Indeed, \(Y_a,V_a\) have mixed-side ports \(ID\), so they cannot
select \(g,t_ew\), and hence both use \(t_ev\) while avoiding \(g\).
The row must load \(t_ew\) twice in \(X_a,W_d\); the zero-port
balance then puts \(g\) in \(X_a\). The \(Z_e\) ports \(A,H,J\)
have side sum \(+1\), so \(Z_e\) avoids \(g\). The one port \(J\)
of \(U_{ad}\) is \(B\)-based for \(r=H\) and \(R\)-based for
\(r=J\), fixing its \(g\) bit. The \(A,H\) ports of \(W_d\)
fix its bit in turn. Thus this right row forces a second-profile
zero-port matching, whereas Note 290's left-row load calculation
made every required zero-port occurrence avoid \(g\). Those
left-row conclusions do not transfer to the right branch.

The same zero-port \(X_a\) is subject to the independently checked
complete-family \(eb\)-mask gate of
[Notes 285–286](286-two-b-side-ports-in-the-three-two-core-force-s-tait.md).
If \(r=H\), its shore **complement** must pair
\(EA\mid ID\mid HJ\). If \(r=J\), that pairing or
\(EJ\mid AD\mid IH\) is possible under that gate. These are
necessary pairings of the full complement of \(X_a\); they are
not the \(EH\mid AJ\) pairing of \(X_a\triangle Z_e\) in (3).
Their compatibility in one actual shore row, together with the
complete exact support, is the next distinct closure question.

## An actual row, with the correct scope

Take the twelve-vertex six-pole and its six explicit shore matchings
in [Note 254](254-the-b-cross-rows-require-shore-cycle-intersections.md).
Relabel its ports by
\[
 (H_0,E_0,I_0,J_0,D_0,A_0)
       \longmapsto (I,E,H,D,J,A).                    \tag{4}
\]
Its matching port sets
\(\varnothing,\ H_0J_0,\ E_0A_0D_0I_0,\ E_0D_0,\
H_0J_0,\ A_0I_0\) become exactly
\(\varnothing,\ ID,\ EAHJ,\ EJ,\ ID,\ AH\).
The six shore matchings still cover every shore edge twice.
Their \(X\triangle Z\) paths \(E_0I_0\mid A_0D_0\) become \(EH\mid AJ\),
as required by (3). Gluing them slot by slot to the right exterior
table gives a connected cubic 25-vertex five-pole with a real
\((ea)(ad)\) BF row and the right singleton-\(a\) mask \(Y_R\).
This rowwise witness is not asserted to have the companion
\((ea)(ac)\) row. It has no claim to exact Case XII:
[Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md)
already excludes exact support at order 25.

The exact central-path problem must now retain both row templates
until complete negative support or cross-row closure removes one.
Claims in Notes 272–296 that require every \((ea)(ad)\) row to use
the left template are conditional on that additional, currently
unproved exclusion. The earlier left-template calculations remain
valid as statements under their explicit port and exterior masks.
