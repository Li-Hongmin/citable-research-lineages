> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The one-spoke prism double star excludes the mixed forbidden pair

Use the one-shore, \(|U|=r=5\) tree exterior of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) and [Note 497](497-the-one-spoke-prism-double-star-excludes-the-x-y-forbidden-pair.md):
\[
(u_1,u_2,u_3,u_4,u_5)=(AB,AC,Aa,ab,ac),\qquad
(X,Y,Z,W)=(BC,bc,Bb,Cc).
\tag{1}
\]
Assume complete exact Case-XII support with forbidden \(eX,eZ\). Its two allowed pentagons are
\[
S_+=e-Y-X-Z-W-e,\qquad S_-=e-Y-Z-X-W-e.
\tag{2}
\]

**Theorem.** Neither pentagon occurs for this tree, at any order or cycle rank of the six-port shore. The tree automorphisms independently exchange \(X,Y\) and \(Z,W\), so all four mixed forbidden pairs are excluded. Together with [Note 497](497-the-one-spoke-prism-double-star-excludes-the-x-y-forbidden-pair.md) and [Note 498](498-the-one-spoke-prism-double-star-excludes-the-z-w-forbidden-pair.md), this conditionally excludes all six forbidden pairs for this *one* marked tree. With the chosen spoke normalized to \(Aa\), the centers of the top and bottom two-edge paths give four tree orbits: \((A,a),(A,b),(B,b),(B,c)\) after simultaneous leaf swap and layer exchange. The present theorem closes the first orbit; the other three and the full Case-XII five-pole profile remain open.

The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) contains both \((13)(15)\) and \((12)(13)\). For \(S_+\), relabel \((e,Y,X,Z,W)=(1,3,5,2,4)\), so \((eX)(eY)=(15)(13)\). For \(S_-\), relabel \((e,Y,Z,X,W)=(1,3,5,2,4)\), so \((eX)(eY)=(12)(13)\). In both, \(eX,eZ\) belong to the forbidden complementary pentagon \(T=\{12,15,23,34,45\}\), and an actual BF row of type \((eX)(eY)\) is mandatory. Name its six **complete** matching occurrences
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad D_0=e,\quad D_1=e.
\tag{3}
\]
The \(Y\)-starting component of \(R\triangle K\) cannot end at \(X\): switching it would make a forbidden \([eX]\) row with unchanged \(P\). It cannot end at \(Z\): that would make forbidden \((eX)(eZ)\). Hence it ends at \(W\). This component stays in the exterior. Starting at the root of the zero-port tree matching \(R\), it enters each tree subdivision along a \(K\)-half and exits along the \(R\)-half; it never uses a shore port. Switching it gives \(R'=eW,K'=W\) with the same **complete** shore restrictions \(Q_{R'}=Q_R\) and \(Q_{K'}=Q_K\).

For either \(D\in\{D_0,D_1\}\), compare the \(e\)-starting paths of \(R\triangle D\) and \(R'\triangle D\). They leave the shore at the same proper port, because \(Q_R=Q_{R'}\). The complementary three-matching half \(P+J+E\), with \(E\) the other singleton-\(e\) occurrence, retains state \(eX\in T\). As in [Note 496](496-the-x-y-forbidden-hamilton-k33-pair-fails-an-x-arm-transfer.md), switching the two complete \(e\)-paths gives genuine states \(Yt\) and \(Wt'\). To avoid a \(T\)--\(T\) row, **each** \(D\) must transport exterior terminal arms at one and the same port as follows:
\[
S_+: X\longrightarrow Z,\qquad S_-:Z\longrightarrow X.
\tag{4}
\]
Here “old” refers to \(R\) and “new” to \(R'\). A listed arm that does not reach a proper port cannot satisfy (4).

There are four root pairs for the \(Y\)-to-\(W\) component. The pair \(Y:b\to W:C\) is impossible: its tree path uses \(b,a,A,C\), leaving only \(B,c\) for the \(X,Z\) marked halves of \(K\), while \(X=BC\) and \(Z=Bb\) cannot cover them disjointly. The other three pairs are treated next.

**Direct route \(Y:c\to W:c\).** Now \(R\) and \(R'\) have the same tree halves and differ only on the two marks at \(c\): \(R\triangle R'=t_Y-c-t_W\). Every zero-port \(P=eX\) uses \(c u_5\), so at most one of \(D_0,D_1\) can use this same half. Choose \(D\) that covers \(c\) by \(Y:c\) or \(W:c\). Inspecting the three-edge switch shows that the old \(W\)-terminal arm becomes the new \(Y\)-terminal arm; the \(X\)- and \(Z\)-arms keep their proper-port endpoints. If both reach ports, those ports are distinct components of \(R\triangle D\). Thus neither \(X\to Z\) nor \(Z\to X\) can hold at the same port. If either arm does not reach a port, (4) already fails. The direct route is excluded without fixing any shore matching.

**Route \(Y:b\to W:c\).** The path fixes
\[
K:X:C,Z:B,W:c;\quad b u_4,a u_5,A u_h\ (h\in\{1,2,3\}).
\tag{5}
\]
Its proper ports are the two indices outside \(\{4,5,h\}\). Both \(P=eX\) roots use \(c u_5\), as does \(R=eY\) rooted at \(b\); hence no singleton-\(e\) occurrence can use \(c u_5\).

If \(P\) roots at \(X:B\), the \(X\)-half loads make the two \(D\)'s split \(X:B,X:C\). The one taking \(X:C\), call it \(D_C\), must take
\[
D_C:X:C,Y:b,Z:B,W:c;\quad A u_i,a u_j,
\quad i\in\{1,2,3\},\ j\in\{3,4,5\}.
\tag{6}
\]
The ranges are deliberately supersets of the load-feasible choices. Direct alternating-arm tracing gives

| arm | proper port |
|---|---|
| old \(X\) | \(p_2\) for \(i=1,3\); \(p_4\) for \((i,j)=(2,3)\); \(p_3\) otherwise |
| new \(Z\) | \(p_5\) for \((i,j)=(1,3)\); \(p_3\) for \(i=1,j=4,5\); \(p_1\) otherwise |
| old \(Z\) | \(p_4\) for \((i,j)=(1,3)\); \(p_3\) for \(i=1,j=4,5\); \(p_1\) otherwise |
| new \(X\) | \(p_2\) for \(i=1,3\); \(p_5\) for \((i,j)=(2,3)\); \(p_3\) otherwise |

The old \(X\) and new \(Z\) ports never agree: the only common *value* in the table, \(p_3\), requires \(i=2\) and \(i=1\), respectively. Likewise old \(Z\) and new \(X\) never agree. Both orientations of (4) fail.

If \(P\) roots at \(X:C\), the \(X\)-half load makes both \(D\)'s take \(X:B\), and matching \(B,b,c,C\) forces both to take
\[
D:X:B,Y:c,Z:b,W:C;\quad A u_i,a u_j,
\quad i\in\{1,2,3\},\ j\in\{3,4,5\}.
\tag{7}
\]
For this pattern the old \(X\)-arm exits at \(p_4\) for \((i,j)=(1,3)\), at \(p_3\) for \(i=1,j=4,5\), and at \(p_1\) otherwise; the new \(Z\)-arm exits at \(p_5\) for \(j=4\) and \(p_4\) otherwise. The old \(Z\)-arm exits at \(p_4\) for \(j=5\) and \(p_5\) otherwise; the new \(X\)-arm exits at \(p_5\) for \((i,j)=(1,3)\), at \(p_3\) for \(i=1,j=4,5\), and at \(p_1\) otherwise. Either equality in (4) requires \((i,j)=(1,3)\) for **both** \(D_0,D_1\). But \(P\), rooted at \(X:C\), already uses \(a u_3\); this would load that edge three times. Thus (5) is excluded for every \(h\).

**Route \(Y:c\to W:C\).** Here \(K\) is fixed:
\[
K:X:B,Z:b,W:C;\quad c u_5,a u_3,A u_2;\quad p_1,p_4.
\tag{8}
\]
Both \(P\) roots use \(c u_5\), so the singleton-\(e\) occurrences cover \(c\) through a mark.

If \(P\) roots at \(X:B\), both \(D\)'s must have
\[
D:X:C,Y:b,Z:B,W:c;\quad A u_i,a u_j,
\quad i\in\{1,2,3\},\ j\in\{4,5\}.
\tag{9}
\]
The old \(X\) port is \(p_3\) for \(i=2\) and \(p_2\) otherwise; the new \(Z\) port is \(p_2\) for \(i=1\) and \(p_1\) otherwise. Thus \(S_+\) requires \(i=1\) for both \(D\)'s. The old \(Z\) port is \(p_3\) for \(i=1\) and \(p_1\) otherwise; the new \(X\) port is \(p_5\) for \(j=4\), \(p_2\) for \((i,j)=(3,5)\), and \(p_3\) otherwise. Thus \(S_-\) requires \((i,j)=(1,5)\) for both \(D\)'s. Either way \(P,D_0,D_1\) would all use \(A u_1\), contrary to load two.

It remains that \(P\) roots at \(X:C\). The \(X\)-half loads split the \(D\)'s; label them by their \(X\)-half. Their marked halves are forced:
\[
D_B:X:B,Y:c,Z:b,W:C,\qquad
D_C:X:C,Y:b,Z:B,W:c.
\tag{10}
\]
Each uses \(A u_i,a u_j\) with \(i\in\{1,3\}\), \(j\in\{4,5\}\). For \(D_B\), the old \(Z\)-arm exits at \(p_5\) if \(j=4\) and at \(p_4\) if \(j=5\), whereas the new \(X\)-arm exits at \(p_2\) if \(i=1\) and at \(p_1\) if \(i=3\). Hence \(S_-\) is impossible. For \(S_+\), the old \(X\)-arm of \(D_B\) exits at \(p_3\) for \(i=1\) and at \(p_1\) for \(i=3\); its new \(Z\)-arm exits at \(p_3\) only for \((i,j)=(1,4)\), at \(p_2\) for \((3,4)\), and at \(p_4\) for \(j=5\). Thus \(D_B\) uses \(A u_1,a u_4\). The old \(X\)-arm of \(D_C\) exits at \(p_2\), while its new \(Z\)-arm exits there only if \(D_C\) uses \(A u_1\). Its \(a\)-half may be \(a u_4\) or \(a u_5\).

The loads now force \(J\) to have marks \(Y:b,Z:B,W:c\) and tree halves \(C u_2,A u_3\), plus \(a u_5\) if \(D_C:a u_4\), or \(a u_4\) if \(D_C:a u_5\). The **old** complete shore restrictions have these boundary sets:

| \(D_C\)'s \(a\)-half | \(P,R\) | \(K\) | \(J\) | \(D_B\) | \(D_C\) |
|---|---|---|---|---|---|
| \(a u_4\) | \(\varnothing,\varnothing\) | \(p_1p_4\) | \(p_1p_4\) | \(ep_2p_3p_5\) | \(ep_2p_3p_5\) |
| \(a u_5\) | \(\varnothing,\varnothing\) | \(p_1p_4\) | \(p_1p_5\) | \(ep_2p_3p_5\) | \(ep_2p_3p_4\) |

We can recomplete **either** row to forbidden \([eX]\) while keeping all six complete shore matchings one for one. Give \(P,R\) the zero-port \(eX\) exterior rooted at \(X:C\). For an \(X\)-singleton shore boundary \(p_1p_4\) or \(p_1p_5\), respectively use the exterior
\[
F_5:\ Y:b,Z:B,W:c;\ C u_2,A u_3,a u_5,
\qquad
F_4:\ Y:b,Z:B,W:c;\ C u_2,A u_3,a u_4.
\tag{11}
\]
For an \(e\)-singleton shore boundary \(ep_2p_3p_5\) or \(ep_2p_3p_4\), respectively use
\[
E_4:\ X:B,Y:c,Z:b,W:C;\ A u_1,a u_4,
\qquad
E_5:\ X:B,Y:c,Z:b,W:C;\ A u_1,a u_5.
\tag{12}
\]
Thus \((K,J,D_B,D_C)=(F_5,F_5,E_4,E_4)\) in the first row and \((F_5,F_4,E_4,E_5)\) in the second.

Every displayed exterior is a matching with exactly its old shore-port set. For the new six exteriors, the two \(eX\) triples occupy \(B u_1,A u_2,a u_3,b u_4,c u_5,X:C\). At \(B,C,A,b,c\), respectively, the other two pairs of incident edges are
\[
(Z:B,X:B),\ (C u_2,W:C),\ (A u_3,A u_1),
(Y:b,Z:b),\ (W:c,Y:c).
\tag{13}
\]
At \(a\), the triple pair uses \(a u_3\). The remaining loads at \(u_4,u_5\) are explicit; \(P,R\) take \(b u_4,c u_5\) in both rows:

| new four singleton exteriors | \(a u_4\) | \(p_4\) | \(a u_5\) | \(p_5\) |
|---|---|---|---|---|
| \(K=F_5,J=F_5,D_B=E_4,D_C=E_4\) | \(D_BD_C\) | \(KJ\) | \(KJ\) | \(D_BD_C\) |
| \(K=F_5,J=F_4,D_B=E_4,D_C=E_5\) | \(JD_B\) | \(KD_C\) | \(KD_C\) | \(JD_B\) |

At \(u_1,u_2,u_3\), the three edge pairs are respectively \((B u_1,A u_1,p_1)\), \((A u_2,C u_2,p_2)\), and \((a u_3,A u_3,p_3)\). At \(t_X\), the terminal pair is \(KJ\), the \(C\)-half pair is \(PR\), and the \(B\)-half pair is \(D_BD_C\). At \(t_Y,t_Z,t_W\), the terminal pair is \(PR\), and the two marked halves are taken twice by the \(F\)'s and twice by the \(E\)'s. The shore itself retains its old load-two sum because no complete shore matching changed. Hence this is a genuine \([eX]\) BF row, contradicting exact Case XII. This excludes the last route and proves the theorem. \(\square\)

The argument uses only actual complete matching occurrences and the published mandatory BF row. The transfer step may change shore matchings by a complete alternating-path switch; the final recompletion keeps each old complete shore matching. The conclusion is conditional on the upstream [Note-358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) profile reduction and this hand-derived arm certificate. It awaits independent proof review. No OMEN or local mathematical recomputation was used.
