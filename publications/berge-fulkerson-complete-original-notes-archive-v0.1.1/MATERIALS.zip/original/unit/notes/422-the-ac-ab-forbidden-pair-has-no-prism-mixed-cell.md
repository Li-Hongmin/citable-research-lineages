> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(AC,ab\) forbidden pair has no required mixed row on the marked prism

Use the marked two-spoke prism of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md), with tree subdivisions \(u_1,\ldots,u_5\) on \(AB,BC,Aa,Bb,ac\), respectively, and marked terminals \(X=AC,\ Y=Cc,\ Z=bc,\ W=ab\). The shore has ports \(e,p_1,\ldots,p_5\) and arbitrary order. Suppose the complete BF support is exact Case XII with forbidden \(e\)-labels \(\{X,W\}\). Its two allowed pentagons are
\[
S_1=e-Y-X-W-Z-e,\qquad S_2=e-Y-W-X-Z-e.               \tag{1}
\]
The [published Case-XII relation, Definition 4.1 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires the mixed BF type \((eX)(eY)\) and excludes every \(T\)--\(T\) type.

> **Mixed-cell exclusion.** No row of six complete perfect matchings on this exterior and any shore has type \((eX)(eY)\) under exact support (1). Consequently the forbidden pair \(\{AC,ab\}\) cannot occur for this marked exterior.

Suppose a row exists. Write \(P=eX\) for its forbidden triple, \(R=eY\) for its allowed triple, \(K=Y\), \(J=X\) for the corresponding singleton occurrences, and \(D_0,D_1=e\) for the two singleton-\(e\) occurrences. The \(Y\)-starting path of \(R\triangle K\) must end at \(Z\). An endpoint \(X\) or \(W\) would switch \(R\) to another forbidden \(e\)-pair while leaving \(P\in T\) unchanged. Both roots of \(P=eX\), namely \(A,C\), take the tree edge \(cu_5\).

**The \(C\)-root of \(R\) is impossible.** For \(R=eY:C\), the rooted tree slots are \((A,B,a,b,c)\). Starting at \(Y\), the \(R\triangle K\) path follows \(Y-t_Y-C\). Taking \(X:C\) ends at forbidden \(X\), so \(K:Cu_2\) and the path reaches \(B\). If \(K:Bu_4\), the path reaches \(b\), where only \(Z:b\) is an allowed endpoint. But \(P,R\) both take \(cu_5\); at \(c\), \(K\) cannot take \(Y:c\) because it has the \(Y\) terminal, so it must take \(Z:c\). One matching cannot take both halves of the \(Z\) subdivision.

If \(K:Bu_1\), the path reaches \(A\). Taking \(X:A\) ends at forbidden \(X\), so \(K:Au_3\); it then reaches \(a\). Taking \(W:a\) ends at forbidden \(W\), so \(K:au_5\), and the path reaches \(c\), where only \(Z:c\) can be allowed. Yet \(K\) now occupies both \(C\) by \(Cu_2\) and \(A\) by \(Au_3\). It cannot cover the \(X=AC\) subdivision, since its only terminal is \(Y\). Thus no \(Y\to Z\) path exists for this root.

**The \(c\)-root forces a short exterior switch and then contradicts the shore.** For \(R=eY:c\), the tree slots are \((B,C,A,b,a)\). The \(Y\)-starting path enters \(c\). It can take \(Z:c\), giving the wholly exterior path
\[
Y-t_Y-c-t_Z-Z.                                        \tag{2}
\]
Otherwise it takes \(cu_5\) and reaches \(a\). The branch \(W:a\) ends at forbidden \(W\), so it takes \(au_3\) and reaches \(A\). The branch \(X:A\) ends at forbidden \(X\), so it takes \(Au_1\) and reaches \(B\). The \(Bu_2\) branch reaches \(C\), where \(Y:C\) is unavailable to \(K\) and \(X:C\) ends at forbidden \(X\). The \(Bu_4\) branch reaches \(b\); \(W:b\) ends at forbidden \(W\), while \(Z:b\) would cover both \(a\) and \(b\) in \(K\), leaving neither endpoint to cover the \(W=ab\) subdivision. Thus (2) is the only possible allowed path.

Switch (2) between \(R,K\), obtaining \(R'=eZ:c\) with exactly the same complete shore mask as \(R\). At \(c\), the matchings \(P,R,K\) use \(cu_5,Y:c,Z:c\), one occurrence on each edge. These three edges each need a second occurrence among \(J,D_0,D_1\). Therefore some singleton-\(e\) occurrence \(D\) takes \(Y:c\) or \(Z:c\).

In \(R\triangle D\) and \(R'\triangle D\), the exterior \(X\)- and \(W\)-terminal components are unchanged. If \(D:Y:c\), the \(Z\)-arm of the first comparison is extended through \(Y-c-Z\) to become the \(Y\)-arm of the second; if \(D:Z:c\), it is shortened in the reverse way. If \(X,W\) join wholly outside the shore, the prescribed \(e\)-switch is already impossible. Otherwise their unchanged arms exit at distinct shore ports. The shore \(e\)-path has the same first proper exit against \(R,R'\), since their shore masks agree. Under \(S_1\), that exit must select \(X\) against \(R=eY\) and \(W\) against \(R'=eZ\). Under \(S_2\) the required targets are \(W,X\). Either way one fixed exit would have to select two distinct unchanged arms. This contradiction excludes the \(c\)-root, completes the required-cell exclusion, and proves the claim. \(\square\)

Together with [Notes 413](413-two-spoke-prism-exact-case-xii-requires-odd-zero-port-complements.md), [419](419-an-exterior-reslotting-excludes-the-last-adjacent-prism-row.md), and [421](421-the-ab-bc-forbidden-pair-has-no-prism-mixed-cell.md), five of the six forbidden \(e\)-pairs for this marked exterior are excluded. Only \(\{AC,Cc\}\) remains open here. Other exterior profiles and the Berge–Fulkerson conjecture remain open. This hand proof uses complete matching occurrences but awaits independent review; no local mathematical recomputation or OMEN was used.
