> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three distinct extensions require four witness-reuse rows

The six-singleton counting gate from
[Note 072](072-uniform-perfect-matching-order-does-not-force-the-six-singleton-covering-design.md)
has a sharp form when a failed \(D_5\) pivot star has three distinct
extension matchings.  Among its seven singleton identities, a usable
six-set must omit one extension, never an anchor; after that omission,
exactly four additional BF rows are necessary and sufficient to make the
missing-pair graph have independence number at most two.

This is a finite classification of the witness identities and allowed
Case-XII boundary cells.  It does not assert that the required rows occur in
one real pole.

## Initial star

Write the four anchors as \(a_1,a_2,a_4,a_5\), and the three distinct
singleton-class-3 extensions as \(x,y,z\).  The four pivot rows have
singleton parts and cells

\[
\begin{array}{c|c|c}
 &\text{singleton quadruple}&\text{cell}\\ \hline
C&\{a_1,a_2,a_4,a_5\}&(15,24)\\
A&\{a_1,a_4,a_5,x\}&(13,45)\\
D&\{a_2,a_4,a_5,y\}&(25,34)\\
E&\{a_1,a_2,a_5,z\}&(12,35).
\end{array}                                        \tag{1}
\]

These are the actual identities \(a_1=33,a_2=16,a_4=24,a_5=0\) and
\(x=2,y=12,z=10\) in the Note 070 certificate.

For a chosen six-set \(U\), each available row with singleton part
\(R\subset U\) contributes the missing-pair edge \(U\setminus R\).  By
Note 072, \(\alpha(G_U)\le2\) forces the six-singleton capacity
contradiction.

## Which identity can be omitted

If an anchor is omitted, all three of \(x,y,z\) remain.  No Case-XII BF row
can contain three singleton identities of boundary class 3: its four
singleton occurrences split into two boundary pairs, and each pair has
distinct endpoints.  Thus \(\{x,y,z\}\) is permanently independent and
\(\alpha(G_U)\ge3\).

If one of \(x,y,z\) is omitted, the three surviving initial rows in (1)
give a missing-pair graph \(P_4\sqcup2K_1\).  Three additional rows would
leave only six edges.  A six-vertex graph with \(\alpha\le2\) and six edges
must be \(2K_3\), by equality in Mantel's theorem applied to the complement;
it cannot contain a four-vertex path.  Hence at least four new rows are
necessary.

Four rows are sufficient.  Up to the explicit asymmetry of the initial star,
all optimal gates are the following eight families.  A slash indicates that
either listed Case-XII cell realizes the same singleton quadruple.

### Omit \(x\)

\[
\begin{array}{c|l}
1&
\{a_1,a_2,y,z\}:(13,23),\ 
\{a_1,a_4,y,z\}:(13,34),\ 
\{a_1,a_5,y,z\}:(13,35),\ 
\{a_2,a_4,a_5,z\}:(24,35)/(25,34)\\
2&
\{a_1,a_2,a_5,y\}:(12,35)/(13,25),\ 
\{a_1,a_4,y,z\}:(13,34),\ 
\{a_2,a_4,a_5,z\}:(24,35)/(25,34),\ 
\{a_2,a_5,y,z\}:(23,35)\\
3&
\{a_1,a_2,a_4,z\}:(13,24)/(14,23),\ 
\{a_1,a_2,y,z\}:(13,23),\ 
\{a_1,a_4,a_5,y\}:(13,45)/(14,35),\ 
\{a_4,a_5,y,z\}:(34,35).
\end{array}                                        \tag{2}
\]

### Omit \(y\)

\[
\begin{array}{c|l}
1&
\{a_1,a_2,a_4,x\}:(13,24)/(14,23),\ 
\{a_1,a_4,x,z\}:(13,34),\ 
\{a_2,a_4,a_5,z\}:(24,35)/(25,34),\ 
\{a_2,a_5,x,z\}:(23,35)\\
2&
\{a_1,a_2,a_4,z\}:(13,24)/(14,23),\ 
\{a_1,a_2,x,z\}:(13,23),\ 
\{a_2,a_4,a_5,x\}:(24,35)/(25,34),\ 
\{a_4,a_5,x,z\}:(34,35).
\end{array}                                        \tag{3}
\]

### Omit \(z\)

\[
\begin{array}{c|l}
1&
\{a_1,a_2,x,y\}:(13,23),\ 
\{a_1,a_4,x,y\}:(13,34),\ 
\{a_1,a_5,x,y\}:(13,35),\ 
\{a_2,a_4,a_5,x\}:(24,35)/(25,34)\\
2&
\{a_1,a_2,a_4,x\}:(13,24)/(14,23),\ 
\{a_1,a_2,a_5,y\}:(12,35)/(13,25),\ 
\{a_1,a_4,x,y\}:(13,34),\ 
\{a_2,a_5,x,y\}:(23,35)\\
3&
\{a_1,a_2,x,y\}:(13,23),\ 
\{a_1,a_4,a_5,y\}:(13,45)/(14,35),\ 
\{a_2,a_4,a_5,x\}:(24,35)/(25,34),\ 
\{a_4,a_5,x,y\}:(34,35).
\end{array}                                        \tag{4}
\]

Thus there are eight optimal row-pattern gates and, after choosing among the
cells separated by slashes, twenty-eight concrete gates.  The complete
inclusion-minimal size distributions are

\[
\begin{array}{c|c}
\text{omitted extension}&\text{number of gates by added-row count}\\ \hline
x&4:3,\ 5:14,\ 6:8,\ 7:1\\
y&4:2,\ 5:10,\ 6:10,\ 7:2\\
z&4:3,\ 5:14,\ 6:8,\ 7:1.
\end{array}
\]

The exhaustive standard-library verification is frozen in the
[classification bundle](../computations/bundles/three-distinct-extension-six-singleton-gate/README.md).

Consequently, the three-distinct-extension branch is strictly harder than
the repeated-extension branch of Notes 072--073: no choice of six identities
can close the counting argument with only three new witness-reuse rows.  A
general Case-XII proof must force one of the eight four-row gates above, or
replace the six-singleton counting argument by a stronger mechanism.
