> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Mixed \(e\)-rows need two zero-port shore matchings in the two-spoke prism

Use the two-spoke prism exterior
\[
T=\{AB,BC,Aa,Bb,ac\},\qquad
(p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac)
\]
of [Notes 386–388](388-two-exceptional-prism-fibres-have-a-marked-half-recompletion-obstruction.md), with marks \(AC,Cc,bc,ab\). Let \(Z\) be an arbitrary complete six-port shore. Its zero-port perfect matchings factor independently with both roots of each \(ej\)-triple by Note 358. Write \(F\) for the two exterior labels whose \(ej\)-Tait loops are forbidden by exact Case XII.

> **Full-row two-mask theorem.** In an actual BF row of type \((ej)(ek)\) on a putative exact-Case-XII pole with this exterior, if \(j\in F\) or \(k\in F\), the two complete zero-port shore restrictions of its triple occurrences are **different**. In particular, every required mixed allowed–forbidden \(ej\)-row uses two distinct complete shore matchings.
>
> More precisely, if \(F\) is not one of \(\{AC,bc\},\{Cc,ab\}\), **no** \((ej)(ek)\) BF row can have equal triple shore restrictions. If \(F\) is one of those two pairs, any equal-shore row has both triple labels in the complementary allowed pair.

This is a statement about actual six-perfect-matching rows, including all singleton occurrences and their full edge load. It does not assume Tait decompositions or fix a preselected row.

**Proof.** Suppose the two zero-port triples in a BF row share a complete shore matching \(Q\). If \(Z-Q\) contains an odd closed component, [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes four-singleton load-two completion impossible. Thus \(Q\) is clean: its complement has no odd closed component. By [Note 387's sharp full-fibre condition](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md), exact Case XII then forces \(F\) to be one of the two exceptional pairs, and \(Q\) has that pair's exact signed port signature.

Name the four singleton occurrences \(E_0,E_1,X,Y\), where \(E_0,E_1\) carry terminal \(e\). Let \(I=\{E_0,E_1,X,Y\}\), and let \(L_i\subset I\) be the two singleton colours using proper port \(p_i\). Along a complement path of \(Z-Q\), equation (5) of Note 230 makes the endpoint two-sets equal when the path length is odd and complementary when it is even. Every singleton-\(e\) matching uses three proper ports, and every other singleton matching uses two, by Note 230's quota.

First suppose \(F=\{ab,Cc\}\). Its signed signature is \(ep_5\) even, \(p_2p_4\) odd and \(p_1p_3\) even. Therefore
\[
L_5=\{X,Y\},\qquad L_2=L_4,\qquad L_1=I\setminus L_3.           \tag{1}
\]
Each \(E_i\) is absent from \(p_5\) and belongs to exactly one of \(L_1,L_3\). To use three proper ports, it must belong to both \(L_2,L_4\), so
\[
L_2=L_4=\{E_0,E_1\}.                                             \tag{2}
\]
At the exterior vertex \(B\), an \(E_i\) using ports \(p_2,p_4\) cannot match \(B\) through those two tree edges. There is no marked edge at \(B\), so it must use the \(B\)-half of \(AB=p_1\), and therefore cannot use port \(p_1\). Hence
\[
L_1=\{X,Y\},\quad L_3=\{E_0,E_1\},\quad
\operatorname{ports}(E_i)=\{p_2,p_3,p_4\},\quad
\operatorname{ports}(X)=\operatorname{ports}(Y)=\{p_1,p_5\}.       \tag{3}
\]
These are exactly the port sets in Note 388's first marked-half obstruction. Its proof uses only the two triple masks \(Q,Q\), the four port sets (3), and exterior edge load two; it excludes **even one** triple state \(e\,ab\) or \(e\,Cc\). Thus both triple labels lie in \(\{AC,bc\}\).

If \(F=\{AC,bc\}\), the signed signature instead has \(ep_3\) even, \(p_2p_4\) odd and \(p_1p_5\) even. The same quota count gives
\[
L_3=\{X,Y\},\quad L_2=L_4=\{E_0,E_1\},\quad L_1=I\setminus L_5.
\]
The same vertex \(B\) forces each \(E_i\) to use the \(B\)-half of \(AB\), so \(L_1=\{X,Y\}\), \(L_5=\{E_0,E_1\}\). Consequently
\[
\operatorname{ports}(E_i)=\{p_2,p_4,p_5\},\qquad
\operatorname{ports}(X)=\operatorname{ports}(Y)=\{p_1,p_3\}.       \tag{4}
\]
Note 388's second marked-half obstruction excludes even one triple state \(e\,AC\) or \(e\,bc\) with these masks. Thus both triple labels lie in \(\{Cc,ab\}\). The two cases prove the theorem. \(\square\)

The theorem upgrades a single-\(Q\) Tait parity classification to a restriction on **every actual BF row** whose two triples have states \(ej,ek\). It does not assert that a required mixed row fails to exist: such a row may use two different complete zero-port shore matchings, and that cross-fibre possibility remains the exact-Case-XII obstruction. No OMEN or local mathematical recomputation was used; the hand proof depends on the still unreviewed pairing tables in Notes 386–388.
