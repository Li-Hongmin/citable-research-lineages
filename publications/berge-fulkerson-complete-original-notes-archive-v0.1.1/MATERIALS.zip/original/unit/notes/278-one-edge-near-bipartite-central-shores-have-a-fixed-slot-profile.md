> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-edge-near-bipartite central shores have a fixed slot profile

Continue the two actual central-path row templates of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). Write \(E=e,A=a:\Sigma,I=h_1,D=h_2\), and let \(H=h_3,J=h_4\). The pure \(X_a\triangle Z_e\) paths pair \(E\)--\(I\) and \(A\)--\(D\); the opposite two-port slots are \(U_{ad}:ED,W_d:AI\) and \(U_{ac}:EA,W_c:ID\).

Suppose deleting one internal edge \(g\) makes the **six-port shore** bipartite, with sides \(B,R\), and both row types exist. The shore itself cannot be bipartite by [Note 276](276-the-two-central-path-rows-force-an-odd-shore-cycle.md), so both ends of \(g\) lie in one side; name it \(B\). For a shore matching \(M\), put \(z(M)=\mathbf1_{g\in M}\) and let \(\nu_B(M),\nu_R(M)\) count its selected ports on the two sides.

**Theorem (fixed exceptional-edge profile).** Exactly one of the following two patterns holds in **every** required row:
\[
\begin{array}{c|c|c|c|c}
|B|-|R| & z(X_a)&z(Z_e)&z(Y_a)=z(V_a)&
 \#(B\cap\{E,A,I,D\}),\quad H,J\\\hline
0&0&1&0&1,\quad H,J\text{ on opposite sides}\\
2&1&0&0&3,\quad H,J\text{ both on }B
\end{array}.                                                    \tag{1}
\]
In either pattern exactly one of \(U_t,W_t\) uses \(g\). Thus \(g\) belongs to both \(P=X_a\triangle Z_e\) and \(Q=U_t\triangle W_t\), while the singleton-difference cycles \(Y_a\triangle V_a\) avoid \(g\). The four-slot load \(X_a+Y_a+Z_e+V_a\) has coordinate **one** at \(g\) in every required row.

Under **complete exact-Case-XII support**, the second pattern has exactly one surviving placement: its unique \(R\)-side member of \(\{E,A,I,D\}\) is \(I=h_1\). Placement at \(E\) makes the full five-pole minus \(g\) bipartite, contrary to [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md). Placement at \(A\) or \(D\) makes one required \(T\)-state triple matching extend to a forbidden Tait colouring.

## Proof

All shore matching edges other than \(g\) cross the bipartition. Counting matched vertices on both sides gives the identity
\[
\nu_B(M)-\nu_R(M)=|B|-|R|-2z(M).                         \tag{2}
\]
The zero-port matching \(X_a\) makes \(|B|-|R|=2z(X_a)\in\{0,2\}\), so **all** zero-port matchings have the same \(g\)-bit.

Suppose \(z(Z_e)=z(X_a)\). Then \(P=X_a\triangle Z_e\) avoids \(g\); each of its two pure paths has odd internal length in a bipartite graph, so \(E,I\) lie on opposite sides, as do \(A,D\). Consequently two of \(E,A,I,D\) lie on each side. If \(|B|-|R|=0\), the pair of \(B\)-side ports is one of \(EA,ED,AI,ID\); (2) forbids any two-port matching using that pair, because it would require \(z=-1\). If \(|B|-|R|=2\), the same four pairs contain the pair of \(R\)-side ports; (2) would require \(z=2\). But \(EA,ED,AI,ID\) are exactly the four required \(U/W\) port sets across the two real rows. Both cases contradict their existence. Hence \(z(Z_e)\ne z(X_a)\).

Apply (2) to the four ports of \(Z_e\). For \(|B|-|R|=0\), \(z(Z_e)=1\) gives \(\nu_B-\nu_R=-2\), namely one \(B\) and three \(R\) ports. For \(|B|-|R|=2\), \(z(Z_e)=0\) gives \(\nu_B-\nu_R=2\), namely three \(B\) and one \(R\) port. Since \(Y_a,V_a\) use the same port set \(HJ\), (2) makes their \(g\)-bits equal. The occurrences \(X_a,Z_e\) already use \(g\) once in the BF row, so \(Y_a,V_a\) cannot both use it. They both avoid it. Applying (2) to \(HJ\) yields the last column of (1), and load two forces \(z(U_t)+z(W_t)=1\). All other statements in the first part follow.

Finally suppose the second pattern has \(E\in R\), its unique \(R\)-side port among \(E,A,I,D\). Then \(A,I,D,H,J\), the five proper interfaces from the shore to the central-path exterior, all lie on \(B\). The exterior graph itself is bipartite: its path \(A_{\rm ext}-u_1-B_{\rm ext}-u_2-C_{\rm ext}-u_3-D_{\rm ext}-u_4-E_{\rm ext}\) has all five named branch vertices on one side, and each subdivision vertex of the exterior marks \(a,b,c,d\) lies on the other side. In particular the five exterior endpoints of those proper interfaces are all on that other side. Align this bipartition with \(B,R\). Every proper edge of the full pole except \(g\) now crosses sides, so deleting \(g\) makes the whole pole bipartite. Note 125 excludes this under exact support.

If the unique \(R\)-side port is \(A\) or \(D\), all proper shore interfaces except that one lie on \(B\). Let \(f\) be its cut edge, namely \(a:\Sigma\) when the minority port is \(A\), or \(h_2\) when it is \(D\). The same exterior bipartition makes the full pole minus \(\{g,f\}\) bipartite. In the \(A\) placement, \(U_{ac}\) uses \(f\), and its pair \(EA\) has one port on each side; (2) forces \(U_{ac}\) to use \(g\) as well. In the \(D\) placement, \(U_{ad}\) analogously uses both \(f\) and \(g\). Call the resulting triple matching \(U\). Its missing-pair state is respectively \(ac\) or \(ad\), both in the forbidden pentagon \(T\). The complement of \(U\) lies entirely in the bipartite graph obtained by deleting \(g,f\); all its closed cycles are even. The triple-complement parity lemma in Note 125 then alternately colours that complement, extending \(U\) to a Tait colouring of its forbidden \(T\)-state. Doubling the three colour classes would give a forbidden \(T\)-loop BF row. Hence neither placement is compatible with exact support, leaving only \(I\). \(\square\)

In that sole surviving second-pattern placement, \(f=h_1\) and the full pole minus \(\{g,f\}\) is bipartite, with the two exceptional edges internal to opposite sides. Both required \(T\)-state triples \(U_{ad},U_{ac}\) avoid \(g,f\). [Note 127's mixed-side criterion](127-two-edge-bipartization-profiles-and-tait-blockers.md) therefore makes their complements a precise next gate: \(g\) and \(f\) must lie in **different components of the full pole minus \(U_{ad}\)** and also in **different components of the full pole minus \(U_{ac}\)**, or the corresponding triple extends to a forbidden Tait state. The present slot profile does not decide whether both separations can occur.

This is a **shore** near-bipartite classification, not an exclusion of all such shores. It does not cover the distinct possibility that the unmarked core \(F[\Sigma]-g\) is bipartite while the marked-edge subdivision still makes the six-port shore minus \(g\) nonbipartite. The surviving port placements in (1) require the complete BF negative support, beyond individual row equations, to be resolved. No local enumeration is used; the forced exterior and pure-pairing inputs remain subject to independent verification.
