> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The published order-36 BF bound raises exact-Case-XII poles to order 33

Brinkmann, Goedgebeur, Hägglund and Markström, *Generation and properties
of snarks*, Journal of Combinatorial Theory, Series B (2013),
doi:10.1016/j.jctb.2013.05.001, state in **Corollary 8.5** that no
bridgeless cubic graph on at most 36 vertices is a counterexample to
the Berge--Fulkerson conjecture. Their [author manuscript,
arXiv:1206.6690v3](../../../../ResearchLibrary/lib/unknownarxiv1206a/unknownarxiv1206a.pdf)
has the statement on page 26. This is a published finite theorem,
not a new enumeration here.

It has a direct consequence for the *complete* Case-XII pole relation:

\[
\boxed{\begin{gathered}
H\text{ is a simple connected cubic five-pole whose full BF
boundary support is exact Case XII}
\end{gathered}
\quad\Longrightarrow\quad |V(H)|\ge33.}                 \tag{1}
\]

## The completion argument

Write the ten two-terminal missing-pair states as the edges of
\(K_5\). Exact Case XII has an allowed pentagon \(S\), its
complementary pentagon \(T\), every \(S\)--\(S\) and
\(S\)--\(T\) BF pair, and **no** all-terminal type, \(T\)-loop,
or \(T\)--\(T\) pair. Attach an ordinary five-cycle to the five
semiedges of \(H\) in the cyclic order \(T\); call the resulting
cubic graph \(G_T\).

The graph \(G_T\) is simple. To see that it is bridgeless, first
take any proper bridge \(e\) of \(H\). If one side \(C\) of
\(H-e\) had no terminal semiedge, then
\(3|C|=2|E(H[C])|+1\), so \(|C|\) is odd and **every**
perfect matching of \(H\) would use \(e\). An actual BF row
exists under exact Case XII, and its six occurrences would load
\(e\) six times instead of two. Thus both sides of every proper
bridge contain terminal semiedges. Their joining edges to the new
pentagon give an alternate route around that bridge. Every other
proper edge of \(H\) already lies on a cycle. The new pentagon
edges lie on its cycle, and every joining edge lies on a cycle
formed with a second joining edge, a path in connected \(H\)
(possibly of length zero), and a path on the pentagon. Hence
\(G_T\) is bridgeless. Also
\[
                         |V(G_T)|=|V(H)|+5.                 \tag{2}
\]

Suppose \(G_T\) had a BF cover. Restrict its six perfect matchings
to the two shores of the five-edge cut. The two local six-matching
rows have **identical labelled boundary subsets in every slot**;
thus they have the same BF boundary type. In an ordinary pentagon
five-pole, a triple-boundary matching uses one internal cycle edge,
so its missing pair is an edge of the port pentagon \(T\). Hence
every pentagon BF type is either all-terminal or a loop/pair with
both missing-pair states in \(T\). Exact Case XII permits none of
these types on \(H\), contradiction. Thus \(G_T\) is a bridgeless
cubic BF counterexample.

Corollary 8.5 gives \(|V(G_T)|>36\), so \(|V(H)|>31\).
The cubic five-pole degree equation \(3|V(H)|=2|E(H)|+5\)
makes \(|V(H)|\) odd, proving (1). \(\square\)

## Consequence for the normalized deficient-core branch

[Note 169, (3)](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md)
gives \(|V(H)|=2|U|+11+2\rho\), where \(\rho\) is the total
unmarked cycle rank of the non-singleton odd shores. Therefore any
putative minimum-host exact-Case-XII pole in that branch satisfies
\[
                  \boxed{|U|+\rho\ge11.}                    \tag{3}
\]
For a two-vertex barrier, \(\rho\ge9\); for a one-vertex barrier,
\(\rho\ge10\). In particular the tree--ordinary-pentagon
\(I_m\) profile has \(|V(H)|=17\), and **cannot occur in a
minimum BF counterexample**, regardless of its relative port
order. The conditional six-slot exclusion in
[Note 225](225-a-tree-pentagon-im-shore-cannot-have-the-two-shared-u1-neighbours.md)
remains a direct closure calculation but is unnecessary for this
minimum-host order range.

This improves [Note 100's order-17 lower bound](100-no-exact-case-xii-five-pole-has-order-at-most-fifteen.md)
even without its proper-bridgeless and distinct-terminal
assumptions. It does **not** eliminate exact Case XII at order 33
or above, prove that the remaining high-rank barrier profiles exist,
or settle Berge--Fulkerson at unbounded order. No local graph
enumeration or OMEN run was used.

## Stronger finite pentagon-hit formulation

The completion argument applies to any simple connected cubic
five-pole \(H\) with at least one actual BF row. The bridge argument
uses only that row's load two. For **every** port pentagon \(T\),
the completed \(G_T\) is therefore bridgeless. Moreover, the
ordinary pentagon five-pole supports the all-terminal BF type
(one all-terminal matching and five singleton-boundary matchings)
and every loop/pair on its five cycle-edge states (double or
overlay its Tait colourings). Aligning the six occurrence slots
across the cut gives the exact criterion
\[
\boxed{G_T\text{ is BF-covered}\quad\Longleftrightarrow\quad
\mathcal B(H)\text{ contains the all-terminal type or a loop/pair
whose two states lie in }T.}                                \tag{4}
\]
Here \(\mathcal B(H)\) is the complete **actual** six-matching
boundary relation; the two states in a loop coincide. The forward
direction is the restriction argument above, and the reverse
direction glues two genuine shore rows of the same type.

Consequently the published order-36 theorem also implies the
following finite selection property:
\[
\boxed{|V(H)|\le31\quad\Longrightarrow\quad
\text{every terminal pentagon }T\text{ is hit by the all-terminal
type or by an actual BF loop/pair inside }T.}                \tag{5}
\]
The argument does not assume exact Case XII for this statement.
If \(H\) has no all-terminal type, it supplies a genuine
\(T\)--\(T\) row for each \(T\). Exact Case XII violates (5)
at its complementary pentagon, recovering (1).
