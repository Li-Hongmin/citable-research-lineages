> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(K_{3,3}\) double-star forces distinct zero-port shore matchings

Work in the \(|U|=r=5\), one-internal-mark, one-shore setting of [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) and [Note 359](359-two-root-parity-gate-and-k33-sharpness.md), with the complete exact Case-XII BF support of Máčajová--Mazzuoccolo--Tabarelli (2026, Proposition 4.4 and Appendix XII, DOI 10.26493/1855-3974.3409.c13). Suppose the suppressed six-vertex exterior is \(K_{3,3}\) and its unmarked spanning tree is the double-star
\[
 ab,\quad ar_1,ar_2,\quad bl_1,bl_2,                         \tag{1}
\]
while the four exterior marked edges are \(r_i l_h\), \(i,h\in\{1,2\}\). Let \(p_0\) be the shore port on \(ab\), \(p_1,p_2\) those on the two \(a\)-branches, and \(p_3,p_4\) those on the two \(b\)-branches. The shore \(Z=C\cup\{t_e\}\) has sixth port \(e\). This is one concrete marked shape inside the \(K_{3,3}\) alternative of Note 358, with arbitrary shore order and rank.

**Theorem.** Every genuine BF row of type \((ej)(ek)\), including \(j=k\), uses **different complete zero-port shore matchings** in its two triple occurrences. More precisely, if a zero-port shore matching \(Q\) has no odd closed component in its complement, then its three port paths necessarily have the unique signed pairing
\[
              (e,p_0)_{\rm odd},\qquad
              (p_1,p_2)_{\rm odd},\qquad
              (p_3,p_4)_{\rm odd}.                         \tag{2}
\]
The conclusion uses the two forbidden \(ej\)-Tait loops of exact Case XII, the full two-root perfect-matching fibre of Note 358, and the actual BF-row colour constraint of Note 359. It does not assert that an exact-Case-XII pole of shape (1) exists.

**Proof.** Fix \(Q\) with no odd closed shore-complement cycle. By [Note 359's parity lemma](359-two-root-parity-gate-and-k33-sharpness.md), the shore has either one or three odd port paths. For mark \(j=r_i l_h\), write \(i'\) and \(h'\) for the other indices. Its two rooted triple complements have exterior pairings
\[
\begin{aligned}
\pi_{j,r_i}&=jp_i\mid p_0p_{i'}\mid p_3p_4,\\
\pi_{j,l_h}&=jp_{2+h}\mid p_0p_{2+h'}\mid p_1p_2.        \tag{3}
\end{aligned}
\]
This follows by orienting the five tree edges away from the chosen root: the three unselected exterior marks form the path between the two ends of \(j\), while each centre joins its two unused port stubs. Every exterior path is even, so a rooted triple is blocked from an \(ej\)-Tait colouring exactly when the union of its pairing (3) with the shore pairing has a closed component containing an odd number of odd shore paths.

Write the shore pairing as \(ep_k\mid\tau\), where \(\tau\) pairs the remaining four proper ports. If its only odd path is \(ep_k\), every rooted triple gives a Tait colouring. If the only odd path is \(q\in\tau\), both roots of a fixed mark can be blocked only in the following cases:

| mark | possible \((k,q)\) when both roots are blocked |
|---|---|
| \(r_1l_1\) | \((p_1,p_0p_4),\ (p_3,p_0p_2)\) |
| \(r_1l_2\) | \((p_1,p_0p_3),\ (p_4,p_0p_2)\) |
| \(r_2l_1\) | \((p_2,p_0p_4),\ (p_3,p_0p_1)\) |
| \(r_2l_2\) | \((p_2,p_0p_3),\ (p_4,p_0p_1)\) |

Indeed, if \(p_k\) is neither root's \(j\)-partner in (3), the single odd pair \(q\) would have to be common to both exterior pairings, but they share no port pair. If \(p_k\) is one root's \(j\)-partner, that root has its other two shore paths in closed components, while the other root can be blocked only when \(q\) equals its exterior pair disjoint from \(p_k\). This gives the first table row; the other rows follow by independently swapping the two \(r\)-leaves and the two \(l\)-leaves. Its eight ordered pairs are distinct, so at most one marked label \(j\) has both roots blocked.

Now suppose all three shore paths are odd. If \(p_k\) equals one root's \(j\)-partner, that root is blocked only when \(\tau\) equals its two exterior port pairs; the other root would require a port pair absent from this \(\tau\), so both cannot be blocked. If \(p_k\) is one of the two leaf ports **other than** the roots' \(j\)-partners, the two exterior pairs disjoint from \(p_k\) intersect, and cannot both lie in the matching \(\tau\). The only remaining choice is \(p_k=p_0\). Then the two roots are both blocked exactly when \(\tau=p_1p_2\mid p_3p_4\). This is (2); it blocks both roots for **all four** marked labels.

Exact Case XII forbids the \(ej\)-Tait loop for two of these four labels. If \(Q\) lacked signature (2), the preceding cases would leave at most one label with both rooted triples blocked. One of the two forbidden labels would therefore admit a genuine Tait colouring, and doubling it would give the forbidden loop. Hence every \(Q\) with no odd closed shore cycle has (2).

Finally, take any genuine \((ej)(ek)\) row. Both triple occurrences are zero-port by [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). If their common shore mask were \(Q\) with an odd closed complement cycle, [Note 230, equation (5)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) would prohibit the required four-singleton shore load. Otherwise \(Q\) has (2), whose two odd leaf-pair paths trigger [Note 359's complete-row no-reuse theorem](359-two-root-parity-gate-and-k33-sharpness.md) for **every** pair of zero-port triple states and roots. Both cases contradict the common-mask assumption. \(\square\)

This theorem narrows the true five-vertex BF-row obstruction to simultaneous completion with **two different** shore matchings. It does not by itself exclude the double-star profile, other \(K_{3,3}\) spanning trees, or Berge--Fulkerson. The proof is hand-derived and has not received an independent proof check.
