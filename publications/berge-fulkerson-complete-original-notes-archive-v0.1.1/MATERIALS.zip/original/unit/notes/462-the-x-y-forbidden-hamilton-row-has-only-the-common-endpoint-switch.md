> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(X,Y\)-forbidden Hamilton row has only the common-endpoint switch

Continue the fixed Hamilton three-spoke exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36)
\tag{1}
\]
of [Note 461](461-the-y-z-forbidden-hamilton-pair-forces-a-forbidden-recompletion.md). Now suppose the **complete** BF support is exact Case XII with forbidden \(e\)-labels \(\{eX,eY\}\). The two pentagons are \(e-Z-X-Y-W-e\) and \(e-Z-Y-X-W-e\). Under the respective maps \((e,Z,X,Y,W)=(1,3,5,2,4)\) and \((e,Z,Y,X,W)=(1,3,5,2,4)\), published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eX)(eZ)\) row and excludes \([eX]\) and \((eX)(eY)\).

Name the six **complete** matching occurrences of that required row
\[
P=eX,\qquad R=eZ,\qquad K=Z,\qquad J=X,\qquad a=e,\qquad b=e.
\tag{2}
\]
Thus the old terminal pairs are
\[
e=ab,\qquad X=RJ,\qquad Y=W=PR,\qquad Z=PK.
\tag{3}
\]
The \(Z\)-starting component of \(R\triangle K\) cannot end at \(X\), for that would switch \(R\) to state \(eX\) and give \([eX]\) with \(P\). It cannot end at \(Y\), which would give \((eX)(eY)\). Hence it ends at \(W\). It starts with the \(K\)-coloured terminal \(Z\) and then the \(R\)-coloured marked half. At each original vertex it leaves by \(K\); on entering a tree subdivision by a \(K\) tree half, it must leave by \(R\)'s tree half, since \(R\) uses no proper shore port. Thus this component cannot enter the shore and moves monotonically away from \(R\)'s tree root until it enters the \(W\)-mark. Since \(K\) uses only three tree halves, the route crosses at most three tree edges.

There are four endpoint routes:
\[
\begin{array}{c|c|c}
Z\text{ root}&W\text{ endpoint}&\text{tree length}\\ \hline
2&3&1\\
2&6&4\\
6&3&3\\
6&6&0
\end{array}
\tag{4}
\]
The length-four route is excluded by the three-tree-half quota. The length-one route \(2\to3\) is also impossible: \(R\), rooted at \(2\), uses \(6u_5\); \(P\), rooted at either endpoint \(1\) or \(4\) of \(X\), also uses \(6u_5\). Thus \(6u_5=PR\). The occurrence \(K\) uses the terminal \(Z\), so it cannot use \(Z:6\); if its \(Z\)-to-\(W\) path ends at \(W:3\), it cannot use \(W:6\) either. All three edges at original vertex \(6\) then miss \(K\).

For the length-three route \(6\to3\), \(K\) uses the tree halves \(6u_5,5u_4,4u_3\) and \(W:3\). Its remaining two proper-port slots are \(p_1,p_2\), so it uses neither tree half incident with original vertex \(2\). Since \(K\) selects the terminal \(Z\), it also misses \(Z:2\). Original vertex \(2\) would be unmatched by \(K\).


Therefore every required genuine row under these support absences has the **unique switch route**
\[
\boxed{R:eZ\text{ rooted at }Z:6,\qquad
K:Z\text{ on the terminal,}\qquad K:W:6,\qquad
R\triangle K\text{ goes }Z-t_Z-6-t_W-W.}
\tag{5}
\]
The root of \(P=eX\), the other marked and tree halves, the labelled shore-port pairs, and the full matching closure are not determined by (5). In particular this note does **not** exclude \(\{eX,eY\}\); it isolates the same-vertex \(Z,W\) switch as the only remaining required-row configuration. The argument is hand-derived, uses no OMEN or local mathematical recomputation, and awaits independent review. \(\square\)

Later boundary: [Note 463](463-a-real-common-endpoint-x-y-hamilton-row-has-a-forbidden-loop.md) realizes (5) in a genuine 21-vertex BF row; that pole's complete support also has the forbidden \([eX]\) loop.
