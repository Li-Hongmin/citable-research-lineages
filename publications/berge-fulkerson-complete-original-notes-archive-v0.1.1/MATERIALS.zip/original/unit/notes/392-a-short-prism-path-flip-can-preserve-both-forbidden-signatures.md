> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short prism-path flip can preserve both forbidden signatures

[Note 391](391-short-odd-prism-path-forces-an-opposite-root-and-a-common-singleton.md) forces the other zero-port shore matching to use the internal edge of a three-edge \(p_2p_4\) path in a mixed row with a direct forbidden root. The following real shore shows that this edge change alone need not create a forbidden \(ej\)-Tait colouring: two distinct zero-port matchings can have the **same** clean exceptional signed pairing, even when the second uses that internal edge. This is a counterexample to a single-flip Tait inference, not to exact Case XII.

Construct a six-port cubic shore \(Z\) on the sixteen vertices
\[
 x,y,d_0,\ldots,d_7,X_0,X_1,X_2,Y_0,Y_1,Y_2.
\]
Its six port edges meet \(x,y,X_0,X_2,Y_0,Y_2\) at \(p_2,p_4,e,p_5,p_1,p_3\), respectively. Give it the following internal edges:
\[
\begin{aligned}
&xy,\qquad d_0d_1d_2d_3d_4d_5d_6d_7d_0,\\
&X_0X_1,\ X_1X_2,\ Y_0Y_1,\ Y_1Y_2,\\
&xd_0,\ yd_4,\ d_1d_5,\ d_2X_0,\ d_3Y_0,\ d_6X_2,\ d_7Y_2,\ X_1Y_1.
\end{aligned}                                                   \tag{1}
\]
The last line is the zero-port perfect matching
\[
Q=\{xd_0,yd_4,d_1d_5,d_2X_0,d_3Y_0,d_6X_2,d_7Y_2,X_1Y_1\}. \tag{2}
\]
The internal graph is connected and simple. Each vertex has degree three after its listed port edge, when applicable. Its girth is five: the chord \(d_1d_5\) cuts the eight-cycle into two five-cycles; the shortest cycle through \(xy\) uses the three-edge \(d_0d_1d_5d_4\) route and has length six; and cycles through the \(X,Y\) paths and their attachments have length at least six. Thus this is a genuine girth-five six-port shore, with \(X_0\) available as the internal-mark subdivision \(t_e\); deleting \(X_0\) leaves a connected odd core.

The complement \(Z-Q\) has the three port paths and one closed cycle
\[
\begin{array}{c|c}
\text{endports}&\text{path and length}\\\hline
e,p_5&e-X_0-X_1-X_2-p_5\quad(4)\\
p_2,p_4&p_2-x-y-p_4\quad(3)\\
p_1,p_3&p_1-Y_0-Y_1-Y_2-p_3\quad(4)
\end{array}
\qquad D=d_0d_1d_2d_3d_4d_5d_6d_7d_0\quad(8).             \tag{3}
\]
Hence \(Q\) has the clean \(\{ab,Cc\}\) signature of [Note 387](387-two-spoke-prism-zero-port-signatures-force-an-alternating-forbidden-pair.md). Exchange along the alternating six-cycle
\[
K=x-d_0-d_1-d_5-d_4-y-x.
\]
The resulting second zero-port perfect matching is
\[
Q'=\{xy,d_0d_1,d_4d_5,d_2X_0,d_3Y_0,d_6X_2,d_7Y_2,X_1Y_1\}. \tag{4}
\]
It contains \(xy\), the **only** shore-internal edge of the short odd \(p_2p_4\) path. Directly deleting the eight edges of (4) from (1) gives no closed component and gives
\[
\begin{array}{c|c}
e,p_5&e-X_0-X_1-X_2-p_5\quad(4)\\
p_2,p_4&p_2-x-d_0-d_7-d_6-d_5-d_1-d_2-d_3-d_4-y-p_4\quad(11)\\
p_1,p_3&p_1-Y_0-Y_1-Y_2-p_3\quad(4).
\end{array}                                                     \tag{5}
\]
Thus \(Q'\) has exactly the same signed port pairing as \(Q\): even \(ep_5\), odd \(p_2p_4\), even \(p_1p_3\), with no odd closed component. By Note 387, both roots of \(e\,ab\) and both roots of \(e\,Cc\) remain Tait-blocked at **both** masks. The flip required by Note 391 therefore does not, by itself, generate a forbidden \(e\)-Tait loop.

The flip \(K\) meets the short odd path and the formerly closed eight-cycle, but neither even port path. Thus [Note 391's two-path gate](391-short-odd-prism-path-forces-an-opposite-root-and-a-common-singleton.md) also proves that these two masks **cannot** be the triple shore restrictions of a mixed BF row whose forbidden triple has one of the direct roots listed there. This is a row obstruction supplied by singleton loads, whereas the signed Tait pairing is unchanged.

Attaching the two-spoke prism exterior of [Note 386](386-three-spoke-prism-parity-gate-and-two-spoke-counterexample.md) produces a connected simple cubic five-pole of order \(16+15=31\) with these two actual complete zero-port matchings. Exterior-only cycles have length at least six; a cycle crossing the shore uses two proper port edges, a shore edge and at least two exterior edges. The shore has a five-cycle, so the resulting pole has girth five. Its full matching closure is **not** certified to have Case-XII support; indeed [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) excludes exact Case XII below order 33. The boundary established here is the failure of the proposed implication from a short-path alternating flip to a forbidden \(ej\)-Tait state, even for two clean masks in a genuine girth-five pole. All edge and complement checks above are hand-derived and await independent proof review.
