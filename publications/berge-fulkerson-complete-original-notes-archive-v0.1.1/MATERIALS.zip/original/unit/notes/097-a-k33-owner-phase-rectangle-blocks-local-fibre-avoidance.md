> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A K3,3 owner-phase rectangle blocks local fibre avoidance

The fixed-owner version of the repeated-star nonoverload gate in
[Note 095](095-repeated-star-mixed-quartet-nonoverload-is-a-fibre-avoidance-condition.md)
does not follow from alternating path-and-cycle structure, paired switches
and common cubic incidence.  A \(K_{3,3}\) block supports a genuine
\(2\times2\) rectangle of carrier matchings in which every row-column pair
has exactly one common edge, every such edge has bad \(A/C\) owner phase,
and neither fibre has a fixed edge.

This is a local structural countermodel, not a full exact-Case-XII pole.
It makes the remaining positive statement a fixed-carrier fibre-entry
theorem.

## Trace form of the gate

Fix singleton perfect matchings \(A,C,D\), put

\[
K=2\mathbf1-A-C-D,
\qquad
P=A\mathbin\triangle C,                           \tag{1}
\]

and let \(\mathcal B(K),\mathcal X(K)\) be the two singleton projections
of Note 095.  Define their traces on the bad owner support by

\[
\mathscr B_P(K)=\{B\cap P:B\in\mathcal B(K)\},
\qquad
\mathscr X_P(K)=\{X\cap P:X\in\mathcal X(K)\}.    \tag{2}
\]

The target nonoverload condition is exactly the existence of a disjoint
trace pair.  Its failure is

\[
S\cap T\ne\varnothing
\quad
\text{for every }S\in\mathscr B_P(K),
T\in\mathscr X_P(K).                              \tag{3}
\]

Paired exchanges of \(B,X\) on components of \(B\triangle X\) preserve
their common edge set.  Exchanges of \(A,C\) on components of
\(A\triangle C\) preserve \(P\).  Neither operation changes (3).

For an external same-carrier replacement \(B'\in\mathcal B(K)\), put
\(R=B\triangle B'\).  The bad intersection changes by the exact formula

\[
\begin{aligned}
B'\cap X\cap P
={}&\bigl((B\cap X\cap P)\setminus R\bigr)\\
 &\mathbin{\dot\cup}
   \bigl((B'\setminus B)\cap X\cap P\bigr).       \tag{4}
\end{aligned}
\]

Thus \(B'\) clears the bad phase if and only if

\[
B\cap X\cap P\subseteq R,
\qquad
(B'\setminus B)\cap X\cap P=\varnothing.         \tag{5}
\]

The symmetric criterion holds for replacing \(X\).

## The owner-realized rectangle

Index both vertex classes of \(K_{3,3}\) by \(\{0,1,2\}\).  For
\(p\in S_3\), let

\[
M_p=\{(i,p(i)):i=0,1,2\}.
\]

Choose

\[
A=M_{012},
\qquad
C=M_{120},
\qquad
D=M_{201}.                                       \tag{6}
\]

These three one-factors partition \(E(K_{3,3})\), so on this block

\[
K=2\mathbf1-A-C-D=\mathbf1.                       \tag{7}
\]

Take

\[
B_0=M_{012},
\quad B_1=M_{120},
\qquad
X_0=M_{021},
\quad X_1=M_{102}.                                \tag{8}
\]

Their four intersections are

\[
\begin{array}{c|cc}
 &X_0&X_1\\ \hline
B_0&\{(0,0)\}\subseteq A&\{(2,2)\}\subseteq A\\
B_1&\{(1,2)\}\subseteq C&\{(0,1)\}\subseteq C.
\end{array}                                                     \tag{9}
\]

Every cell therefore has exactly one bad-phase edge, while

\[
B_0\cap B_1=\varnothing,
\qquad
X_0\cap X_1=\varnothing.                         \tag{10}
\]

The row differences and column differences in (8) are alternating
six-cycles, and every \(B_i\triangle X_j\) is an alternating four-cycle.
All switches are genuine in the same cubic graph, yet all four resulting
cells remain bad.

The block can be attached to an ambient carrier: cut the \(D\)-edge
\((0,2)\) into two ports.  The matchings \(A,C,B_0,B_1,X_0,X_1\) avoid
both ports and \(D\) uses both, while (9) remains unchanged.  Hence the
obstruction does not rely on an isolated \(K_{3,3}\) component.

## Remaining global interface

The rectangle already has no fixed row or column edge, so the global
class-fixed-edge exclusivity of
[Note 086](086-exact-forty-makes-class-fixed-edges-exclusive-but-does-not-remove-them.md)
does not break it.  The forty positive boundary cells provide global
same-class matchings, but their complementary loads may be different
carriers.  They do not place an avoider in \(\mathcal B(K)\) or
\(\mathcal X(K)\).

Consequently a positive proof must establish fixed-carrier fibre entry:
some global witness must enter the same carrier and satisfy both clauses of
(5), or the symmetric \(X\)-replacement condition.  Merely adding more
global avoiders, local alternating cycles or paired switches leaves the
rectangle (9) intact.

The construction does not assert an extension whose complete BF support is
exact Case XII.  It proves that the remaining contradiction must couple the
full forty-cell witness family to one fixed carrier fibre; local owner phase
and common cubic incidence alone are insufficient.
