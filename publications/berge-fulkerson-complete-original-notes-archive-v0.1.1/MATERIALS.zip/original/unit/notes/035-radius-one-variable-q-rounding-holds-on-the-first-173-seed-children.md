> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Radius-one variable-Q rounding holds on the first 173 seed children

The radius-one candidate left by Note 033 holds for every edge-covering
$Q$-five-tuple in the first 173 labelled one-step children of the exact-S
order-fifteen pole from Note 020.  This is a complete finite statement on
that prefix, not a general variable-$Q$ rounding theorem.

For an edge-covering tuple $Q=(Q_0,\ldots,Q_4)$, call $Q'$ a radius-one
neighbour if there is one state $t$ such that

\[
Q'_j=Q_j\quad(j\ne t),
\]

the two third matchings $Q_t,Q'_t$ have the same boundary, and
$Q_t\mathbin\triangle Q'_t$ is one internal alternating cycle.  A successful
radius-one repair additionally requires that $Q'$ still cover every edge
and that its fixed-$Q'$ endpoint fibre contain a capacity-two split.

## Complete finite result

Across the specified prefix there are

\[
\boxed{22{,}543=22{,}488+55}
\]

edge-covering $Q$-five-tuples.  Exactly $22{,}488$ already have a
fixed-$Q$ rounding.  The remaining 55 are fixed-$Q$ failures, and all

\[
\boxed{55/55}
\]

have a successful radius-one repair.

Complete neighbour evaluation finds 354 directed successful repairs from
the 55 failed tuples to 224 distinct roundable $Q'$-tuples.  Every failed
tuple has between two and nine successful radius-one neighbours.  More
precisely,

\[
\begin{array}{c|rrrrrrr}
\text{successful neighbours}&2&4&5&6&7&8&9\\\hline
\text{failed tuples}&3&2&6&20&10&6&8.
\end{array}
\]

The alternating cycles occurring among the successful directed repairs
have lengths

\[
4,\ 6,\ 8,\ 10,\ 12.
\]

Thus the finite support is not confined to the single $C_6$ mechanism of
Note 033.

## Half-support range of the failures

The half-support profiles of the 55 fixed-$Q$ failures are

\[
\begin{array}{c|rrrrr}
\text{profile}&\varnothing&C_4&C_6&C_8&C_{10}\\\hline
\text{count}&19&4&14&10&8.
\end{array}
\]

Hence radius-one repair succeeds throughout this prefix both for empty
half-support and for each even single-cycle profile realized by a failure.
This does not imply that half-support alone determines repairability.

## Enumeration boundary

The first 172 labelled moves were not recomputed.  The existing neighbourhood
cache contains their complete fixed-$Q$ audit: all 19,651 edge-covering
tuples round with $Q$ fixed.  The cached scan originally stopped at the
first fixed-$Q$ failure in move 173, obtained by subdividing

\[
e_8=(5,9),\qquad e_{17}=(11,12).
\]

For the present result that last child was reconstructed and completely
rescanned.  Its five state fibres contain

\[
7\cdot9\cdot9\cdot7\cdot7=27{,}783
\]

distinct $Q$-tuples.  Of these, 2,892 cover every edge; 2,837 have a
fixed-$Q$ rounding and 55 do not.  Every one of those 55 failures was tested
against every available one-state, one-cycle neighbour, giving the 55/55
result above.

No move from 174 through 300 was examined.  The result therefore supplies
complete finite support for the Note 033 candidate only on the stated
173-move prefix.  It proves neither the candidate for the full one-step
neighbourhood nor a universal radius-one theorem for exact-S poles.

## Computation

The finite audit is
`scratch/worker-proof/audit_radius_one_q_repair_first173.py`, with complete
output in `scratch/worker-proof/radius_one_q_repair_first173.json`.  It reuses
the prefix cache
`scratch/worker-proof/n17_seed_neighbourhood_result.json` and terminates with

```text
RADIUS_ONE_Q_REPAIR_SUPPORTED_ON_FIRST_173
```
