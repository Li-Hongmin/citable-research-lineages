> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A real Hamilton \((ea)(eb)\) row survives the immediate switches but exposes \([eb]\)

The root restrictions of [Note 379](379-a-hamilton-ea-eb-row-excludes-two-root-pairs.md) leave the state-\(ea\) triple rooted at \(s\) and the state-\(eb\) triple rooted at \(x\) for \(S_1=e-a-b-d-c-e\). The following **actual** cubic five-pole has a full six-perfect-matching row of this root pair. Both singleton-\(e\) occurrences send the mandatory \(ea\to ec\) switch from \(ab\) to \(cd\), as \(S_1\) requires. Its complete support nevertheless contains the forbidden loop \([eb]\), so it is not an exact-Case-XII counterexample.

Take the Hamilton \(K_{3,3}\) exterior with tree
\[
x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t
\]
and marked edges \(a=xs,b=xt,c=yt,d=zr\), each subdivided at \(t_a,t_b,t_c,t_d\) with its terminal semiedge. Let the six shore vertices be \(w_0,w_1,w_e,w_4,w_3,w_2\), in this cyclic order on a six-cycle. Join \(u_i\) to \(w_i\) by the proper port \(p_i\), and put terminal \(e\) at \(w_e\). This specifies a connected simple cubic five-pole on \(6+5+4+6=21\) vertices. Every exterior core edge is subdivided, so an exterior-only cycle has length at least eight; the shore cycle has length six, and a cycle crossing the shore has at least two port edges, a shore edge, and two exterior edges. Hence its girth is five, attained by \(r-u_0-w_0-w_1-u_1-r\).

The shore matchings in the following six complete perfect matchings are listed explicitly; a displayed port means that its shore vertex is matched to the corresponding \(u_i\), while terminal \(e\) means \(w_e\) is matched to its dangling semiedge. Abbreviate \(w_iw_j\) by \(ij\), and \(w_ew_i\) by \(ei\). Put
\[
Q_1=\{01,e4,32\},\qquad Q_2=\{1e,43,20\}.
\]

| matching | exterior edges and terminal semiedges | shore edges and ports |
|---|---|---|
| \(P\), state \(ea\) triple | \(t_as;\ b,c,d;\ xu_0,ru_1,yu_2,zu_3,tu_4\) | \(Q_1\) |
| \(R\), state \(eb\) triple | \(t_bx;\ a,c,d;\ ru_0,yu_1,su_2,zu_3,tu_4\) | \(Q_2\) |
| \(A\), singleton \(a\) | \(a;\ t_bx,t_ct,t_dr;\ yu_1,su_3,zu_4\) | \(p_0,p_2;\ 1e,43\) |
| \(B\), singleton \(b\) | \(b;\ t_ax,t_ct,t_dr;\ yu_2,su_3,zu_4\) | \(p_0,p_1;\ e4,32\) |
| \(E_1\), singleton \(e\) | \(e;\ t_as,t_bt,t_cy,t_dz;\ xu_0,ru_1\) | \(p_2,p_3,p_4;\ 01\) |
| \(E_2\), singleton \(e\) | \(e;\ t_ax,t_bt,t_cy,t_dz;\ ru_0,su_2\) | \(p_1,p_3,p_4;\ 20\) |

Here each \(E_j\)'s shore column also includes its displayed terminal \(e\). Every table row matches every internal vertex once. Their total load is two on each edge: at the five tree subdivisions the three respective owner pairs are
\[
\begin{array}{c|ccc}
u_0 &xu_0:P,E_1&ru_0:R,E_2&p_0:A,B\\
u_1 &ru_1:P,E_1&yu_1:R,A&p_1:B,E_2\\
u_2 &yu_2:P,B&su_2:R,E_2&p_2:A,E_1\\
u_3 &zu_3:P,R&su_3:A,B&p_3:E_1,E_2\\
u_4 &tu_4:P,R&zu_4:A,B&p_4:E_1,E_2.
\end{array}
\]
At the shore, \(Q_1+Q_2\) loads each six-cycle edge once, and \(A+B+E_1+E_2\) loads each once more; every shore port and terminal \(e\) also has two owners. At the six unsplit exterior vertices and four marked subdivisions, the displayed matching table gives the same load-two check. Thus this is a **genuine** \((ea)(eb)\) BF row, not a selection of merely compatible boundary masks.

In \(P\triangle A\), the \(a\)--\(c\) path is the wholly exterior long route
\[
a-t_a-s-u_3-z-u_4-t-t_c-c.
\]
Switching it makes a zero-port state-\(ec\) triple \(P'\) rooted at \(t\) with the same complete shore matching \(Q_1\). For each \(E_j\), the \(e\)-path inside \(Q_1\triangle E_j\) connects \(e\) to \(p_4\). In \(P\triangle E_j\), the exterior \(b\)-leg reaches \(p_4\); in \(P'\triangle E_j\), the \(d\)-leg reaches \(p_4\). Hence the successive real switches give \(ab\) and \(cd\), both in \(S_1\), beside the unchanged \(eb\in T_1\). The original singleton-\(b\) also switches the rooted \(eb\) triple to \(ea\), so the immediate two-terminal tests do not exclude this row.

The complete perfect-matching closure does exclude exact Case XII. For \(Q_1\), the complement of the shore matching pairs \(ep_1\mid p_0p_2\mid p_3p_4\), with three odd paths and no closed component. The state-\(eb\) triple rooted at \(x\) with shore mask \(Q_1\) is an **additional actual perfect matching** by [Note 358's Cartesian gluing](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). Its exterior complement pairs \(bp_2\mid p_0p_3\mid p_1p_4\), as in [Note 378](378-hamilton-k33-forbidden-eb-ed-states-force-an-odd-shore-cycle.md). Gluing these pairings gives the single open route
\[
e-p_1-p_4-p_3-p_0-p_2-b
\]
and no closed component. In the original graph this is the spanning path
\[
e,w_e,w_1,u_1,r,t_d,z,u_4,w_4,w_3,u_3,s,t_a,x,u_0,w_0,w_2,u_2,y,t_c,t,t_b,b.
\]
It visits all 21 internal vertices once and has 22 edges, counting its two terminal semiedges. Alternating its edges gives two complete singleton-\(e\) and singleton-\(b\) perfect matchings complementary to the extra \(eb\) triple; doubling these three matchings yields the forbidden BF loop \([eb]\). This is an explicit full-closure escape, independent of an order bound.

The example disproves a proposed **one-row** exclusion of the \((s,x)\) root pair based only on the \(a\)--\(c\) route, load two, and its immediate \(e\)-path exchanges. It does **not** refute the exact-Case-XII conjectural obstruction: the very same real pole has \([eb]\in C(H)\), while \([eb]\notin L^*_{\rm XII}\). Any exclusion of this surviving root pair must use the absence of that loop or a further consequence of the complete perfect-matching family. The graph and matching certificate were derived by hand; no local mathematical recomputation or independent review was used.
