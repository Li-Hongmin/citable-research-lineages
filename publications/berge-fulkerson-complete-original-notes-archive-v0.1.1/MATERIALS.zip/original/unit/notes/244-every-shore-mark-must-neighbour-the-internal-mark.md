> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every exterior shore mark must neighbour the internal mark

Work in [Note 169's](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) minimum-host, connected deficient-core profile with one non-singleton odd component \(C\), its unique internal marked edge \(e\), and all other odd components singleton vertices \(W\). Let \(U\) be a minimum-cardinality maximum Tutte barrier. The proper cut around \(C\) has five edges. Every exterior mark joins either a singleton \(W\) to \(C\), or two singleton vertices; no mark meets \(U\). The opened five-pole has complete exact-Case-XII perfect-matching support, with allowed missing-pair pentagon \(S\) and complementary forbidden pentagon \(T\).

**Theorem (unused shore-mark obstruction).** Every exterior \(W\)--\(C\) mark is a neighbour of \(e\) in \(S\). Equivalently, if \(d\) is such a mark and \(ed\in T\), then complete exact Case XII is impossible, independently of \(|U|\), \(|C|\), or the cycle rank of \(C\).

Let \(r=|E_F(U,C)|\) count unmarked edges from \(U\) to \(C\). Exactly \(5-r\) exterior marks join \(W\) to \(C\), so the theorem gives
\[
\boxed{5-r\le2,\qquad r\ge3.}                          \tag{1}
\]
At the first surviving barrier size \(|U|=3\), [Note 234](234-three-exterior-graphs-for-the-first-surviving-one-shore-barrier.md) allows only \(r=2,3\). Equation (1) excludes the entire \(r=2\) cycle--leaf quotient, including all its shore orders. For \(r=3\), the two exterior \(W\)--\(C\) marks must be *both* neighbours of \(e\); [Notes 235](235-the-claw-connector-excludes-the-two-endpoint-e-neighbours.md) and [238](238-the-two-path-quotients-exclude-their-shore-mark-pair-at-e.md) exclude that pair in each of the three tree quotients. With [Note 232](232-the-two-vertex-one-five-cut-barrier-cannot-have-exact-case-xii-support.md), this yields the all-orders structural boundary
\[
\boxed{|U|\ge4\quad\text{in the one-internal-mark five-cut profile}.} \tag{2}
\]

## Proof

Suppose \(d\) joins \(W\) to \(C\) and \(ed\in T\). Name the two neighbours of \(e\) in \(S\) by \(j,k\), and write the remaining exterior mark as \(\ell\). Up to reversal, the allowed cycle is
\[
S=e-j-r-s-k-e,\qquad \{r,s\}=\{d,\ell\}.             \tag{3}
\]
The [published Case-XII table, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires an actual \((ej)(ed)\) six-perfect-matching row. Write it as
\[
D=X_{ej}+Y_j+Z_e,\qquad E=U_{ed}+V_d+W_e,
\qquad D+E=2\mathbf1,                                    \tag{4}
\]
where each displayed summand is a **complete actual perfect matching** and the subscripts indicate singleton terminals or missing-pair states. Because \(E\) has state \(ed\in T\), exact negative support makes \(D\) pure \(S\). The proof needs only this one-row purity, not column saturation.

By [Note 230's rank-free quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the state-\(ej\) triple \(X_{ej}\) uses no proper edge across the cut around \(C\), and its selected half of mark \(j\) lies at a singleton vertex of \(W\). In \(X_{ej}\triangle Y_j\), the terminal path starting at \(j\) must end at \(k\): switching to any other endpoint would create a \(T\)-state incident with \(e\). This path is **wholly exterior**. Starting at the selected singleton endpoint of \(j\), it alternates between \(Y_j\) and \(X_{ej}\) along \(U\)--\(W\) edges; whenever it enters \(U\) through a \(Y_j\)-edge, its next \(X_{ej}\)-edge returns to \(W\), because \(X_{ej}\) has no cut edge. A \(Y_j\)-marked half-edge from \(W\) reaches some other mark subdivision vertex, whose \(X_{ej}\)-edge is its terminal semiedge, so it ends the path. It cannot enter \(C\).

Switch this exterior path. The resulting state-\(ek\) triple \(X_{ek}\) has *exactly the same complete matching mask* on \(C\cup\{t_e\}\) as \(X_{ej}\); \(Z_e\) is unchanged. Hence the alternating pairing inside the shore between \(e\)'s terminal port and one of \(Z_e\)'s three proper cut ports is identical in \(X_{ej}\triangle Z_e\) and \(X_{ek}\triangle Z_e\).

In state \(ej\), purity forces the \(e\)-path of \(X_{ej}\triangle Z_e\) to end at \(r\), the other \(S\)-neighbour of \(j\). In state \(ek\), it must end at \(s\), the other \(S\)-neighbour of \(k\). The mark \(d\) is one of \(r,s\), and is a triple terminal in *both* states. If \(Z_e\) selected its shore half \(d:C\), the exterior route from terminal \(d\) would reach \(d:C\) directly in both symmetric differences. Since the shore pairing is unchanged, the \(e\)-path would end at \(d\) in both states or neither, contrary to (3). Thus \(Z_e\) must use the other half, \(d:W\).

The state-\(ed\) triple \(U_{ed}\) is also zero-port by Note 230. It therefore selects \(d:W\), the only half of \(d\) outside \(C\). The two occurrences \(Z_e\) and \(U_{ed}\) already load \(d:W\) twice in the actual row (4), so \(W_e\) cannot use it. Since \(W_e\) has singleton terminal \(e\), it must match the nonterminal subdivision vertex \(t_d\) through the other half \(d:C\).

Now exchange the **whole** singleton-\(e\) matchings \(Z_e,W_e\) between the two halves of (4). The six matching occurrences and their total edge load are unchanged. The new opposite half \(U_{ed}+V_d+Z_e\) still has state \(ed\in T\), so its complement \(X_{ej}+Y_j+W_e\) must again be pure \(S\). The preceding fixed-shore argument forbids \(W_e\)'s selected half \(d:C\), the contradiction. \(\square\)

The proof uses complete perfect-matching closure at precisely the last exchange; a formal shore port pairing or a chosen set of matchings does not supply the second row. [Note 243](243-the-cycle-leaf-one-shore-quotient-is-impossible.md) gives a more explicit route-by-route exclusion of the \(r=2,|U|=3\) quotient; the theorem here subsumes its final exclusion and extends it to every barrier size. It does **not** eliminate \(r=3,4,5\) at larger \(|U|\), the other [Note 169](169-minimal-tutte-barrier-has-three-odd-shore-profiles.md) Tutte profiles, or the Berge--Fulkerson conjecture. This analytic deduction has not received an independent model or implementation check.
