> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A unique exceptional-edge companion need not align on the full cycle

The mixed-side profile calculation in [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) singles out one \((1,1)\) singleton occurrence as the only possible companion for a \((0,0)\)-to-\((1,1)\) switch in certain BF rows. The uniqueness is only a test at the two exceptional edges. The complete perfect-matching family of the seven-vertex pole in [Note 118's underlying certificate](../scratch/case_xii_rectangle_20260923/common_bc_seed_obstruction_20260926.md) gives an actual target matching for which this unique companion fails the full alternating-cycle phase test. The pole has a forbidden \(T\)-loop, so the exact Case-XII implication remains open.

## Exact cycle-or-terminal-path criterion

Let \(F=\{e,f\}\) be disjoint proper edges such that \(H-F\) is bipartite, with \(e\) internal to one part and \(f\) internal to the other. Let \(P,N\) be actual singleton-boundary perfect matchings at terminals in the four-terminal part, with exceptional-edge profiles \((0,0)\) and \((1,1)\), respectively. Their singleton boundaries may be equal or different.

Both \(e,f\) belong to \(P\triangle N\). They lie in the same component \(C\): a proper alternating cycle containing exactly one of them would be odd, while \(P\triangle N\) has at most one terminal path. Then
\[
\boxed{\begin{aligned}
&\text{there are matchings }P',N'\text{ with the same respective singleton}\[-2pt]
&\text{boundaries as }P,N,\quad P+N=P'+N',\quad
  (\mathbf1_{e\in P'},\mathbf1_{f\in P'})=(1,1)\\
&\hspace{38mm}\Longleftrightarrow\quad C\text{ is a closed alternating cycle.}
\end{aligned}}                                                     \tag{1}
\]
Indeed, if \(C\) is closed, toggle it between \(P,N\). Conversely, every two-colouring of the degree-two edge-copy graph \(P+N\) with those fixed singleton boundaries has its colours fixed on the unique terminal path. Only closed alternating cycles may be flipped. If \(C\) is the terminal path, \(P\) cannot acquire either exceptional edge while the pair load and both boundary classes stay fixed. In particular, equal singleton boundaries always give the positive case; different boundaries allow either case.

Equation (1) concerns the complete **pair-load fibre** of \(P+N\), not merely one selected target. It does not assert that another BF row cannot supply a different companion or pair load.

## A full-PM-closure counterexample to phase alignment

Take the proper graph with three internally disjoint \(u\)-\(v\) paths
\[
u-a-v,\qquad u-b-c-v,\qquad u-d-z-v,
\]
and semiedges \(s_1,s_2,s_3,s_4,s_5\) at \(b,d,c,a,z\), respectively. Number the proper edges
\[
g_0=ua,\quad g_1=av,\quad g_2=ub,\quad g_3=bc,\quad
g_4=cv,\quad g_5=ud,\quad g_6=dz,\quad g_7=zv.                 \tag{2}
\]
Set \(e=g_3\) and \(f=g_5\). Removing them leaves a connected bipartite proper graph with parts
\[
X=\{a,b,c,z\},\qquad Y=\{u,v,d\}.
\]
Thus the terminal distribution is \(4+1\), the sole \(Y\)-terminal is \(y=2\), and \(e\subset X\), \(f\subset Y\). The edges of \(F\) are disjoint.

The following are actual complete matching masks; the subscript agrees with the complete fourteen-matching table and its elementary completeness proof in the linked certificate.

| Matching | Proper edges | Semiedges | Role in the \((25)(34)\) row |
|---|---|---|---|
| \(M_1\) | \(g_0,g_3,g_7\) | \(s_2\) | singleton \(y\), profile \((1,0)\) |
| \(M_4\) | \(g_1,g_2,g_6\) | \(s_3\) | singleton, profile \((0,0)\) |
| \(M_2=P\) | \(g_2,g_4,g_6\) | \(s_4\) | singleton, profile \((0,0)\) |
| \(M_8=N\) | \(g_1,g_3,g_5\) | \(s_5\) | unique singleton, profile \((1,1)\) |
| \(M_6\) | \(g_5,g_7\) | \(s_1,s_3,s_4\) | triple missing \(25\in S\), profile \((0,1)\) |
| \(M_9\) | \(g_0,g_4\) | \(s_1,s_2,s_5\) | triple missing \(34\in T\), profile \((0,0)\) |
| \(M_3=P'\) | \(g_3,g_5,g_7\) | \(s_4\) | actual target, profile \((1,1)\) |

The first six masks form the BF row
\[
M_1+M_4+P+N+M_6+M_9=2\mathbf1,\qquad[(25)(34)].             \tag{3}
\]
Every edge and semiedge in (2) has load two. At \(e\), the two occurrences are \(M_1,N\); at \(f\), they are \(M_6,N\). Thus \(N\) is the **only** possible companion in (3) for a switch of \(P\) to the actual same-boundary \(P'\): an aligned companion must occupy the \(P'\)-phase at both \(e,f\).

But \(P\triangle P'\) is the single alternating six-cycle
\[
C'=u-b-c-v-z-d-u,
\]
whose \(P'\)-phase edges are \(g_3,g_7,g_5\). The candidate \(N\) contains \(g_3,g_5\) but **not** \(g_7\). Hence
\[
\operatorname{Align}(N;P\to P')\text{ fails},
\qquad N+P-P'\text{ is not a perfect matching}.                 \tag{4}
\]
In fact, \(P\triangle N\) is the terminal path
\[
s_4-a-v-c-b-u-d-z-s_5,                                      \tag{5}
\]
and it contains both \(e,f\). Equation (1) proves the stronger statement that **no** same-boundary profile transfer is possible anywhere in the pair-load fibre \(P+N\), despite the existence of \(P'\) in the complete PM family.

The pole is simple, connected, proper-bridgeless and has girth five. Its fourteen perfect matchings are the **entire** family: the linked certificate classifies them by the proper-edge choices at \(u,v\) and gives all masks. Thus (3)--(5) are statements inside genuine graph-induced full PM closure, not a selected-matching model. The same certificate shows that the two positive rows \((14)(23)\) and \((25)(34)\) exist, no all-terminal BF cover exists, and \(\Lambda_L\cap\Lambda_R=\varnothing\).

## Exact Case-XII boundary

This graph has a forbidden \(T\)-loop. Its complete matchings include \(M_{10}=\{g_4,g_5,s_1,s_4,s_5\}\), and
\[
M_1+M_4+M_{10}=\mathbf1
\]
is a Tait colouring of missing-pair state \(23\in T\). Doubling gives the forbidden BF type \([23]\). The linked certificate also gives a forbidden \(T\)--\(T\) row. Moreover, \(g_3\) joins the terminal vertices labelled \(1,3\), which exact Case XII forbids by [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md), and deleting \(g_0\) makes the proper graph bipartite, contrary to [Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md).

There is also a rejection tied directly to the obstructed companion pair: \(P=M_2\) and \(N=M_8\) are edge-disjoint, and the actual matching \(M_5=\{g_0,g_7,s_1,s_2,s_3\}\) completes
\[
P+N+M_5=\mathbf1.
\]
This is a second forbidden Tait state, \(45\in T\), hence a forbidden \([45]\) BF loop. In any exact-Case-XII pole, **every** singleton matching in class \(i\) must meet **every** singleton matching in class \(j\) when \(ij\in T\): if two were disjoint, their cubic complement would be a triple matching and would complete a forbidden state-\(ij\) Tait colouring. Therefore an exact-support version of this particular open-terminal-path obstruction with classes \(4,5\) would additionally need a shared edge of \(P,N\). This intersection requirement alone does not decide whether their exceptional edges lie on a path or cycle.

Therefore complete PM closure, the two Note-118 positive cells, absence of the all-terminal type, an actual profile-changing target, and a unique exceptional-edge companion together do **not** force phase alignment or the common \(B+C\) seed. The unresolved exact-support step is to use the missing negative exclusions and the other positive cells to obtain a *different* compatible row or to rule out the terminal-path branch of (1) in a relevant pair-load fibre. Neither conclusion follows from the two-edge profile count alone.

[Note 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md) supplies one precise use of the missing negative exclusions: if the right row's class-three singleton avoids both exceptional edges, two forced Kempe paths and one same-boundary occurrence exchange produce a second right \((25)(34)\) row with the same complete \(B_2\) and the opposite class-four exceptional-edge profile. This removes the two-coordinate separation of the present example under exact negative support, while leaving complete pair-load equality open.
