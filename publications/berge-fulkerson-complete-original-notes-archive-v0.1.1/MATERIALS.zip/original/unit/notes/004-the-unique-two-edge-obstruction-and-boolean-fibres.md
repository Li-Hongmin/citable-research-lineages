> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The unique two-edge obstruction and Boolean matching fibres

This note continues the full relational problem isolated in [Note 003](003-canonical-kempe-transport-does-not-detect-pentagon-selection.md).

## Complete abstract classification at relation size two

Assume each of the five consecutive compatibility relations has exactly two edges. At one layer an edge pair has one of three endpoint types:

- `D`: the two edges have distinct left and distinct right endpoints;
- `R`: they share their right endpoint;
- `L`: they share their left endpoint.

Canonical Kempe transport preserves the intermediate matching, so `R` at layer `t` occurs exactly when `L` occurs at layer `t+1`. Shared intermediate layers form an independent set of the base pentagon. Up to its dihedral symmetry, the only endpoint skeletons are

\[
DDDDD,\qquad RLDDD,\qquad RLRLD.
\]

Direct composition gives the complete lifted-5-cycle count:

- `DDDDD` has either two lifted 5-cycles (the trivial double cover) or none (the connected double cover `C_10 -> C_5`);
- `RLDDD` always has two;
- `RLRLD` always has four.

Thus the unique abstract obstruction at common relation size two is the ten-vertex, ten-edge connected double cover. It satisfies all previously proved local transport axioms.

## Exact fibre structure over a shared perfect matching

Fix `B in \mathcal P_{v_{t+1}}`. Deleting the edges of `B` leaves alternating even cycles together with two paths carrying the four boundary semiedges not used by `B`. Under the Case-XII exact-state hypothesis their endpoint pairing is forced to be

\[
(v_t,v_{t+2})\quad\text{and}\quad(v_{t+3},v_{t+4}).
\]

If `r(B)` is the number of alternating cycle components, the left and right compatibility fibres

\[
L_B=\{A\in\mathcal P_{v_t}:A\cap B=\varnothing\},\qquad
R_B=\{D\in\mathcal P_{v_{t+2}}:D\cap B=\varnothing\}
\]

are both torsors for `{0,1}^{r(B)}`: on each cycle one independently chooses one of its two alternating perfect matchings. Hence

\[
|L_B|=|R_B|=2^{r(B)}.
\]

All two-step choices through `B` form the full Cartesian product `L_B times R_B`; cycle flips commute, but no nondegenerate square is forced when `r(B)=0`.

## Consequence

The connected `C_10` obstruction takes every relevant fibre to have `r(B)=0` and singleton left and right sides. It therefore satisfies the universal local Boolean-fibre law. Local arc consistency, canonical transport, switching back, and all commuting flips inside one shared matching cannot exclude it.

The arbitrary-order problem has now been reduced to a global realizability question: can five singleton Boolean fibres arising from one cubic 5-pole glue with odd monodromy to realize `C_10 -> C_5`? Any proof must couple different intermediate matchings; any real realization refutes unrestricted Pentagon-selection.

