> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A six-cycle cross-switch forces four pure carriers in the pendant loop

Use the marked \(|U|=3,r=2\) cycle--leaf quotient and notation of [Note 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md): \(K-p\) is the six-cycle on \(u_1,x,u_2,q,u_3,z\), with its two perfect matchings
\[
\alpha=\{u_1x,u_2q,u_3z\},\qquad
\beta=\{u_1z,u_2x,u_3q\}.                              \tag{1}
\]
Assume complete exact Case-XII support with \(e\)'s two allowed neighbours \(a,c\). This note analyzes a genuine \([ea]\) loop in which one half-load is pure \(S\) and its singleton-\(a\) has Note 239's type \(G\). It does not assume any equality of shore matching masks.

**Cross-switch theorem.** Write the row as
\[
X_\alpha+Y_G+Z\; +\; U+V+W=2\mathbf1,                 \tag{2}
\]
where \(X,U\) are the state-\(ea\) triples, \(Y_G,V\) are singleton-\(a\), and \(Z,W\) are singleton-\(e\). The first half \(X_\alpha+Y_G+Z\) is pure \(S\). Then:

1. \(U\) uses \(\beta\) on \(K-p\), while \(V\) has Note 239's type \(F\).
2. Up to exchanging \(Z,W\), their **complete exterior restrictions** are exactly
   \[
   \begin{array}{c|l|c}
   &\text{exterior matching edges}&\text{proper shore ports}\\\hline
   R_d&b:p,\ u_1z,\ u_2x,\ u_3q,\ a:C,\ c:C,\ d:C&a:C,c:C,d:C\\
   R_h&b:p,\ u_1x,\ u_2q,\ d:z,\ h_3,\ a:C,\ c:C&a:C,c:C,h_3.
   \end{array}                                                   \tag{3}
   \]
3. All four actual half-loads
   \[
   X_\alpha+Y_G+R_d,\quad X_\alpha+Y_G+R_h,
   \quad U_\alpha+V_F+R_d,\quad U_\alpha+V_F+R_h              \tag{4}
   \]
   are pure \(S\). Here \(U_\alpha\) is obtained from \(U_\beta\) by exchanging the \(K-p\) cycle with \(X_\alpha\); the notation \(R_d,R_h\) in (4) denotes the two original full singleton-\(e\) matchings, not just their exterior restrictions. The four loads occur in different valid BF rows obtained by exchanging matching occurrences and the external six-cycle.

**Proof.** [Note 239](239-the-pendant-mark-loop-has-a-unit-exterior-or-a-mixed-half.md) forces \(X\) to use \(\alpha\) and \(Y\) to have one of its two displayed masks. Type \(G\) uses \(u_3z\), already used by \(X\), so the complete row loads \(u_3z\) twice. The other state-\(ea\) triple \(U\) has zero proper shore ports by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), and must use one of the two perfect matchings of \(K-p\). It cannot use \(\alpha\), since that contains \(u_3z\); hence it uses \(\beta\).

The six-cycle \(K-p\) is an entire connected component of \(X\triangle U\): the triples use opposite alternating phases there and have no proper shore hit. Exchange this component between \(X\) and \(U\), leaving their complete shore restrictions fixed. In the resulting actual BF row, the half containing \(X_\beta+Y_G+Z\) has a \(T\)-decomposition: it has state \(ea\in S\), but Note 239 shows that a pure-\(S\) load cannot have a state-\(ea\) triple using \(\beta\). Exact negative support forces the complementary half \(U_\alpha+V+W\) to be pure \(S\). Note 239 then makes \(V\) type \(F\) or \(G\). The original row already loads \(u_3z\) twice in \(X+Y_G\), so \(V\) cannot use that edge and cannot have type \(G\). Thus \(V=V_F\).

Now both triples use \(a:p\), saturating that marked half-edge, so \(Z,W\) both use \(a:C\). Likewise \(Y_G,V_F\) both use \(b:q,c:x,h_2\), forcing \(Z,W\) to use \(b:p,c:C\) and to avoid \(h_2\). One of \(Y_G,V_F\) uses \(d:C\), the other \(d:z\); also \(V_F\) uses \(h_3\) while \(Y_G\) does not. Since every proper edge has row load two, \(Z,W\) split \(d:C,d:z\), and exactly one uses \(h_3\). Each singleton-\(e\) uses exactly three proper shore ports by Note 230. The one selecting \(d:C\) already has ports \(a:C,c:C,d:C\); its exterior vertices are then forced onto \(\beta\). The other selects \(d:z,h_3\), with ports \(a:C,c:C,h_3\); its remaining exterior edges are \(u_1x,u_2q\). This is (3).

For either assignment of the two singleton-\(e\) occurrences to the two halves of (2), the half with triple \(U_\beta\) has a \(T\)-decomposition by the same Note 239 argument. The complementary \(X_\alpha+Y_G+R_d\) and \(X_\alpha+Y_G+R_h\) must therefore each be pure \(S\). Repeat after the six-cycle exchange: the half with triple \(X_\beta\) is mixed for either assignment, so both complementary \(U_\alpha+V_F+R_d\) and \(U_\alpha+V_F+R_h\) are pure \(S\). Exchanging complete matching occurrences preserves every edge load and terminal state, so each of these is an actual rowwise conclusion. This proves (4). \(\square\)

## The remaining shore pairing has two different forms

Let \(Q_X\) and \(Q_U\) be the complete zero-port shore matchings of \(X\) and \(U\). Exchanging \(K-p\) does not change either shore mask. For \(Q\in\{Q_X,Q_U\}\) and \(R\in\{R_d,R_h\}\), the symmetric difference of their shore restrictions pairs the \(e\)-port with one of the three other shore ports used by \(R\). In the exterior part of the corresponding triple--singleton difference, the terminal routes are exactly
\[
\begin{array}{c|ccc}
 &b&c&d\\\hline
R_d&a:C&c:C&d:C\\
R_h&a:C&c:C&h_3.
\end{array}                                                       \tag{5}
\]
For example, the \(b\)-route is \(b-t_b-p-t_a-a:C\), while the \(d\)-route for \(R_h\) is \(d-t_d-z-u_3-h_3\).

There are two cyclic orders with \(ea,ec\in S\), up to reversal. If
\[
S=e-a-b-d-c-e,                                             \tag{6}
\]
then \(ab\in S\), and purity of all four carriers in (4) requires the \(e\)-port to pair with \(a:C\) for **both** \(R_d,R_h\) and **both** \(Q_X,Q_U\). If instead
\[
S=e-a-d-b-c-e,                                             \tag{7}
\]
then \(ad\in S\), and purity requires, for each of \(Q_X,Q_U\), the \(e\)-port to pair with \(d:C\) against \(R_d\) but with \(h_3\) against \(R_h\). This is a simultaneous pairing change for two possibly different zero-port shore matchings. Equation (5) and these pairings are necessary conditions on the **complete actual shore matching family**, not a formal port-colour assignment and not an exact-Case-XII existence certificate.

The six-cycle switch has therefore converted the asymmetric mixed-loop branch into two concrete six-port shore gates. Neither gate is ruled out here. The unit-exterior branch of Note 239, the other \(e\)-neighbour placements, and the full Berge--Fulkerson conjecture remain open. The argument is analytic and has not received independent verification of its upstream assumptions.
