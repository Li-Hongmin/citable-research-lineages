> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two root pairs fail in a required Hamilton \((ea)(eb)\) row

Use the Hamilton \(K_{3,3}\) five-pole exterior of [Notes 377–378](378-hamilton-k33-forbidden-eb-ed-states-force-an-odd-shore-cycle.md): the tree is \(x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t\), the marks are \(a=xs,b=xt,c=yt,d=zr\), and \(e\) lies in the arbitrary six-port shore. The two remaining Case-XII pentagons are
\[
S_1=e-a-b-d-c-e,\qquad S_2=e-a-d-b-c-e.
\]
Both have \(ea,ec\in S_i\) and \(eb,ed,ac\in T_i\). In addition, \(ab,cd\in S_1\) and \(ad,bc\in S_2\). [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(eb)\) row for either pentagon.

**Root-pair theorem.** In any such row compatible with complete exact-Case-XII support, the zero-port state-\(ea\) triple and the zero-port state-\(eb\) triple cannot both root at \(x\). For \(S_1\), they also cannot root at \((x,t)\), respectively. These exclusions hold at every shore order and cycle rank. They do not assert that any remaining root pair supports a complete row.

**Proof.** Name the state-\(ea\) triple \(P\), the state-\(eb\) triple \(R\), singleton-\(a\) \(A\), singleton-\(b\) \(B\), and the two singleton-\(e\) occurrences \(E_1,E_2\). The shore quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) makes both triples zero-port, and [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) gives roots \(x,s\) for \(P\) and \(x,t\) for \(R\). Because \(R=eb\in T_i\), the alternating terminal path of \(P\triangle A\) starting at \(a\) must end at \(c\). An endpoint \(b\) or \(d\) would change \(P\) to \(eb\) or \(ed\), making a forbidden double-\(T_i\) row. The path is exterior: on each visited \(u_i\), it arrives via \(A\) and leaves via the zero-port \(P\).

Assume \(P\) roots at \(x\). Its exterior restriction selects \(t_ax\), terminals \(b,c,d\), and \(ru_0,yu_1,su_2,zu_3,tu_4\). An \(a\)--\(c\) route continuing from \(y\) through \(s,z,t\) would match both endpoints \(x,t\) of mark \(b\) in \(A\), leaving its subdivision vertex unmatched. Hence \(A\) must use
\[
H:a-t_a-x-u_0-r-u_1-y-t_c-c.                     \tag{1}
\]
In particular \(A\) selects terminal \(a\), \(xu_0,ru_1,t_cy,t_bt,t_dz\), and one of \(su_2,su_3\). Switch \(P,A\) along \(H\), producing a zero-port state-\(ec\) triple \(P'\) rooted at \(y\), with the **same complete shore matching** as \(P\). Outside the shore \(P'\) selects \(t_cy\), terminals \(a,b,d\), and \(xu_0,ru_1,su_2,zu_3,tu_4\).

The unchanged \(R=eb\in T_i\) restricts the \(e\)-terminal path of \(P\triangle E_j\) and, after (1), of \(P'\triangle E_j\), for each \(j=1,2\):
\[
\begin{array}{c|cc}
 &P\triangle E_j&P'\triangle E_j\\ \hline
S_1 & e\longrightarrow b & e\longrightarrow d\\
S_2 & e\longrightarrow d & e\longrightarrow b
\end{array}.                                             \tag{2}
\]
For example, in \(S_1\) the first switch must give \(ab\in S_1\), while the second must give \(cd\in S_1\); every other reachable state would lie in \(T_1\) beside \(R\). The analogous allowed states for \(S_2\) are \(ad,bc\). Because \(P,P'\) have the same complete shore mask and \(E_j\) is unchanged, the \(e\)-path enters the exterior at the same proper shore port before and after (1).

**Both roots \(x\).** Then \(P,R\) both select \(tu_4\), so \(A\)'s \(t_bt\) forces \(B\) onto \(t_ct\) and the two \(E_j\) to split \(t_bt,t_ct\). The \(E_j\) using \(t_bt\) must use \(t_cy\): the two triples use terminal \(c\), while \(A\) and \(B\) occupy one \(c\)-half each. Call this occurrence \(E_y\). In both \(P\triangle E_y\) and \(P'\triangle E_y\), the leg from terminal \(b\) begins \(b-t_b-t-u_4\). It either ends at \(p_4\), continues through \(z,u_3\) to \(p_3\), or continues through \(s,u_2\) to \(p_2\). The latter route must end there because \(E_y\) matches \(y\) through \(t_cy\). All edges of this leg belong to both \(P\) and \(P'\) in the same way, so it reaches the **same port** in both symmetric differences. For \(S_1\), (2) requires that port to change from the \(b\)-leg to the \(d\)-leg, impossible. For \(S_2\), the old \(d\)-leg reaches the \(e\)-path's port, distinct from the unchanged \(b\)-leg's port, so (2) is impossible as well.

**Roots \((x,t)\), pentagon \(S_1\).** The triple \(R\) now selects \(t_bt,xu_0,ru_1,yu_2,su_3,zu_4\). It and \(A\) saturate \(t_bt,xu_0\), forcing both \(E_1,E_2\) onto \(t_bx\). At \(x\), \(P\) occupies \(t_ax\), so the remaining mark and vertex loads force both \(E_j\) onto \(t_as\). A singleton-\(e\) exterior matching with these two forced halves can satisfy the \(S_1\) endpoint change \(b\to d\) in (2) only in the last line of the following exhaustive leg table. Here \(t_cy/t_ct\) and \(t_dr/t_dz\) specify its other marked halves; \(yu_1/yu_2\) is its tree edge when \(t_ct\) leaves \(y\) free. The choice of its remaining \(z\)-tree edge does not change these legs.

| \(E_j\)'s \(c,d\) halves and \(y\)-edge | old \(b\)-leg | new leg at that port |
|---|---|---|
| \(t_cy\), either \(d\)-half | \(p_2\) | \(a\) |
| \(t_ct,t_dz,yu_1\) | \(p_2\) | \(a\) |
| \(t_ct,t_dz,yu_2\) | \(p_1\) | \(b\) |
| \(t_ct,t_dr,yu_1\) | \(p_2\) | \(a\) |
| \(t_ct,t_dr,yu_2\) | \(p_1\) | \(d\) |

Thus both \(E_1,E_2\) would have to use \(yu_2\). But \(R\) already uses \(yu_2\), violating edge load two. This excludes \((x,t)\) for \(S_1\) and completes the stated root-pair exclusions. \(\square\)

The surviving root pairs are only necessary possibilities. For \(S_1\), a required \((ea)(eb)\) row must have \(P\) rooted at \(s\). For \(S_2\), this proof leaves \((x,t),(s,x),(s,t)\). The theorem uses one actual six-perfect-matching row and two successive real matching exchanges; it makes no assumption that different rows share a shore matching. It neither certifies an exact-Case-XII pole nor settles the full Berge–Fulkerson conjecture. The proof is hand-derived and awaits independent review; no local mathematical recomputation was used.
