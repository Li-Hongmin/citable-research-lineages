> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case V

This note applies the stabilizer-complete global component-switch closure of
Notes 048--050 to the 33-type exact five-cut support (H_{\\mathrm V}) in
the Mácajová--Mazzuoccolo--Tabarelli (MMT) Appendix. The statement is
conditional on that transcription and ordered semiedge convention.

## Statement

The greatest fixed point of the necessary global Kempe-action system has
[
\\mathscr S_\\infty([14])=\\varnothing.
]
Because ([14]in H_{\\mathrm V}), no real cubic 5-pole has complete BF
support exactly (H_{\\mathrm V}).

Together with Notes 046, 048 and 049, this conditionally excludes Cases I,
II, III, V, VI and XIII from the MMT 13-case list. Case IV is not excluded by
this action (Note 050). The cyclically-6-connected branch remains untouched.

## Fixed-point certificate

A state records all nonempty two-colour boundary path pairings of one
labelled BF-colouring. Switching one component preserves the route of the
switched pair and every route for a disjoint colour pair; overlapping routes
are not assumed to persist. Internal alternating cycles are omitted, so the
finite system over-approximates the actual colouring action. All colour
relabellings to the target representative are included, including target
stabilizers.

For (H_{\\mathrm V}), the state system has
[
|H_{\\mathrm V}|=33,qquad
|\\mathscr S_0|=510,qquad
N_{\\mathrm{switch}}=10200.
]
The greatest-fixed-point deletion has three rounds with totals (209,2,5).
The ([14]) fibre is reduced from 81 states to zero.

After round one, the sole surviving ([14]) state is number 24. It has the
transition
[
[14]#24
\\xrightarrow[\\text{path }25]{04}
(13)(14)#\\{2,5,8,11\\}.
]
Each of the four target states has a (15)-switch on path (25) landing in
([13]); all eight canonical target maps have no state preserving the
required routes. Hence state ([14]#24) dies in round two, proving the
empty fibre.

An actual exact-support pole would give a nonempty post-fixed family and
therefore a surviving state over every supported type, contradicting the
empty ([14]) fibre.

## Scope and certificate

This result is a boundary-action exclusion only. It does not address Cases
IV, VII, VIII, IX, X, XI or XII, and it is not a Berge--Fulkerson proof.
The stabilizer-complete certificate is

../scratch/worker-mmtt-case-v-global-action/verify_case_v_global_kempe_action.py

and ends with
CASE_V_GLOBAL_KEMPE_ACTION_EXCLUDED.
