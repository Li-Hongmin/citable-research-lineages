> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A mixed prism row forces an \(AC\)--\(bc\) escape, and attains it

Continue [Note 393's real mixed-row profile](393-a-real-mixed-prism-row-attains-the-short-path-two-path-gate.md). The two-spoke prism tree has \((p_1,p_2,p_3,p_4,p_5)=(AB,BC,Aa,Bb,ac)\). Take an actual BF row of type \((e\,ab)(e\,AC)\) whose forbidden triple \(P\) is \(e\,ab\) rooted at \(a\), and whose allowed triple \(R\) is \(e\,AC\) rooted at \(C\). Name the four singleton occurrences \(E,F,J,K\), at terminals \(e,e,ab,AC\). Suppose the full boundary support is exact Case XII with forbidden \(e\)-labels \(ab,Cc\); thus \((e\,ab)(e\,Cc)\) is absent and \(e\,bc\) is allowed. The first assertion below places **no** bound on the shore order, cycle rank or port-path lengths.

> **Exterior escape gate.** In any such exact-support row, the terminal path of \(R\triangle K\) starting at \(AC\) must end at \(bc\). The singleton-\(AC\) matching \(K\) must use \(Cu_2,at_{ab},bt_{bc},ct_{Cc}\) and the proper port \(p_5\). If, in addition, \(P\)'s shore matching is clean with the exceptional signature and has the three-edge path \(P_o=p_2-x-y-p_4\), then [Note 391](391-short-odd-prism-path-forces-an-opposite-root-and-a-common-singleton.md) forces the other triple's shore matching to contain \(xy\), and \(K\) also uses \(Bu_4\). In this short-path case, \(R\triangle K\) has the entirely exterior alternating terminal path
> \[
> AC-t_{AC}-C-u_2-B-u_4-b-t_{bc}-bc.                    \tag{1}
> \]
> Switching \(R,K\) along (1) changes the row to the allowed type \((e\,ab)(e\,bc)\). Thus the first forbidden closure test forces a shore-independent partial singleton mask; the short odd path closes its remaining \(B\)-route.

**Proof.** The four terminal ends of \(R\triangle K\) are \(AC,ab,Cc,bc\). If its \(AC\)-path ends at \(ab\), switching \(R,K\) gives the forbidden \([e\,ab]\) loop; if it ends at \(Cc\), the switch gives the forbidden \((e\,ab)(e\,Cc)\) double-\(T\) row. Exact support therefore forces the endpoint \(bc\). At mark \(AC\), \(K\) uses its terminal edge while \(R\) uses the \(C\)-half. Their symmetric difference starts at \(AC\), follows \(R\) to \(C\), then follows either \(K\)'s \(Cc\)-half or its \(Cu_2\)-edge. In the first case it reaches terminal \(Cc\) immediately, since both triples use that terminal edge. Hence \(Cu_2\in K\).

Here is the resulting load propagation, using the four singleton colours \(I=\{E,F,J,K\}\). Let \(q\) be the singleton on the \(C\)-half of \(AC\), and \(p\) the singleton on the \(a\)-half of \(ab\). At \(C\), the two colours on \(Cc:C\) are \(I\setminus\{K,q\}\). Both triples use terminal \(Cc\), so \(Cc:c\) has pair \(\{K,q\}\). Since both triples use \(cu_5\), the pair on \(bc:c\) is \(I\setminus\{K,q\}\), and since both use terminal \(bc\), the pair on \(bc:b\) is \(\{K,q\}\). Both triples use \(bu_4\), so \(ab:b\) has pair \(I\setminus\{K,q\}\). At mark \(ab\), its terminal is used by \(R,J\), and its \(a\)-half by \(P,p\); hence \(ab:b\) also has pair \(I\setminus\{J,p\}\). Thus
\[
\{K,q\}=\{J,p\}.
\]
As \(J\ne K\), this forces \(q=J,p=K\). Consequently \(K\) uses \(at_{ab},bt_{bc},ct_{Cc}\). It covers \(a,c\) by the first and third of these marked halves and therefore matches \(u_5\) through port \(p_5\).

Now impose the stated short-path hypothesis. By [Note 391, (2)](391-short-odd-prism-path-forces-an-opposite-root-and-a-common-singleton.md), the singleton on \(Cu_2\) differs from the singleton on \(Bu_1\) and from that on \(Bu_2\); at \(B\) the remaining singleton pair uses \(Bu_4\). Hence \(Bu_4\in K\). Following \(R\triangle K\) gives (1): \(R\) uses \(Cu_2\)'s opposite half \(Bu_2\) and uses \(bu_4\), while \(K\) uses \(Cu_2,Bu_4,bt_{bc}\). The path ends at \(bc\), whose terminal edge belongs to \(R\). The exchange is an exchange of two **complete** perfect matchings along one alternating path, so all edge loads remain two. \(\square\)

The gate is **attained by a real row** on the same 23-vertex pole as Note 393. Keep its triples \(P(Q),R(Q')\), and use the following four singleton matchings in place of that note's \(E,F,J,K\). The table uses the same tree, mark and shore notation; \(s\) again means the mark terminal.

| slot | terminal | \((u_1,u_2,u_3,u_4,u_5)\) | \((AC,Cc,bc,ab)\) | shore ports | shore internal edges |
|---|---|---|---|---|---|
| \(E^*\) | \(e\) | \((B,p_2,p_3,p_4,a)\) | \((A,C,c,b)\) | \(e,p_2,p_3,p_4\) | \(h_1h_2,h_5h_6\) |
| \(F\) | \(e\) | \((p_1,B,p_3,p_4,a)\) | \((A,C,c,b)\) | \(e,p_1,p_3,p_4\) | \(h_1h_2,h_3h_6\) |
| \(J^*\) | \(ab\) | \((A,p_2,a,B,p_5)\) | \((C,c,b,s)\) | \(p_2,p_5\) | \(h_0h_4,h_1h_7,h_5h_6\) |
| \(K^*\) | \(AC\) | \((p_1,C,A,B,p_5)\) | \((s,c,b,a)\) | \(p_1,p_5\) | \(h_0h_1,h_3h_4,h_6h_7\) |

Each row is a complete perfect matching. Together with \(P,R\), the tree subdivisions and four mark subdivisions have each of their three incident edges in exactly two slots. In the shore, the nine internal edges \(04,17,25,36,01,34,67,12,56\) have slot pairs
\[
PJ^*,\ PJ^*,\ PR,\ PF,\ RK^*,\ RK^*,\ RK^*,\ E^*F,\ E^*J^*,          \tag{2}
\]
respectively; the ports and five terminal edges also have load two. Thus this is another actual \((e\,ab)(e\,AC)\) BF row with the same two triple matchings and the required \(K^*\)-escape mask.

Here \(R\triangle K^*\) has exactly the exterior \(AC\)--\(bc\) path (1). Also \(P\triangle J^*\) has the exterior \(ab\)--\(bc\) path
\[
ab-t_{ab}-a-u_3-A-u_1-B-u_4-b-t_{bc}-bc.               \tag{3}
\]
Switching the two disjoint **pairs of occurrences** along (1) and (3) gives the allowed \([e\,bc]\) loop. These two particular exchanges are safe, but the displayed row is still excluded by the singleton-\(e\) exchange of [Note 395](395-the-mixed-prism-e-singletons-have-an-exact-three-port-selector.md): \(R\triangle E^*\) has an \(e\)--\(bc\) path and produces a forbidden double-\(T\) row using the same six matchings. Independently, \(Q'\) extends to forbidden \(ej\)-Tait loops by Note 386. Thus the real row establishes sharpness of the \(K\)-escape gate; an exact-support row must also satisfy the two singleton-\(e\) port selectors. The derivation and displayed certificates are hand checks awaiting independent proof review.
