> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimal counterexamples have no reducible triangle or square

Consider a minimum-order connected cubic 5-pole whose Tait lonely-pair state
set is exactly \(S=\{13,14,24,25,35\}\) and which has no capacity-two
singleton transversal.

## Triangles

Contract a proper triangle to one cubic vertex, provided the result stays in
the chosen pole category.  Tait colourings lift and contract bijectively: the
three exterior colours are distinct and each triangle edge receives the
colour of the opposite exterior edge.  Thus the complete boundary-state set
is unchanged.

Every perfect matching of the contraction has a unique standard lift: if it
uses one exterior edge, add the opposite triangle edge.  Lifting a
capacity-two transversal this way permutes the three incident-edge
multiplicities onto the three triangle edges, preserving the bound two.  This
is only a one-way lift; the expanded pole may have additional matchings using
all three exterior edges.

Therefore a minimum counterexample has no admissibly contractible triangle.
For simple connected poles with distinct terminal vertices, admissibility
requires distinct outside neighbours for the proper exterior edges and at
most one exterior semiedge.  Connectedness is automatic under contraction.

## Squares

For an induced square with exterior ports \(1,2,3,4\), the two natural
smoothings are \(12|34\) and \(23|41\).  Symbolic enumeration gives seven
local perfect-matching patterns.  The 18 local Tait colourings have only
three exterior signatures: all four colours equal; \(c_1=c_2\ne c_3=c_4\);
or \(c_2=c_3\ne c_4=c_1\).  Hence every square colouring contracts through
at least one natural smoothing.

For any 5-pole, the Kempe argument implies

\[
\varnothing\ne T(H)\subseteq S\quad\Longrightarrow\quad T(H)=S.
\]

Consequently, if a smoothing is structurally admissible and Tait-colourable,
its state set is again exactly \(S\).

Capacity also lifts.  If the two replacement edges have multiplicities
\(a,b\in\{1,2\}\), classify the five selected matchings by whether they use
neither, one, or both replacement edges.  Among the \(n_{00}\) matchings
using neither, route

\[
x=\max(0,n_{00}-2)
\]

through one opposite square-edge pair and the rest through the other.  Direct
substitution in the nine possible local profiles shows all four square-edge
multiplicities are at most two.  Thus every capacity-two transversal of the
smoothed pole lifts to the square pole.

A minimum counterexample therefore has no natural square smoothing that is
both structurally admissible and Tait-colourable.  If both natural smoothings
are structurally admissible, at least one is compatible with any given square
colouring, so the square is reducible.  Unlike triangle contraction, square
smoothing may create loops, parallel/existing-edge collisions, terminal
collisions, or disconnection; these are genuine admissibility boundaries.

The symbolic verifier is
`scratch/worker-verify/local_triangle_square_states.py`.

