> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two forced-path windows are realizable before full exact-S closure

For an induced matching cycle \(N_0,\ldots,N_9\), put

\[
T_k=N_k\cap N_{k+2}\cap N_{k+4}.
\]

Note 013 reduces capacity-two rounding to the forced boundary path \(Y_k\):
after flipping all cycle components of \(H-N_{k+1}\) that meet \(T_k\),
the remaining triple intersection is exactly \(T_k\cap Y_k\).  Thus one
index with \(T_k\cap Y_k=\varnothing\) gives a capacity-two transversal.

A tempting route to such an index is false.  Cubic incidence, two common
blocker edges, and exact \(C_{10}\) disjointness of ten designated matchings
do not prevent one blocker from lying on two same-parity forced paths.

## A seventeen-vertex counterexample

There is a simple connected cubic 5-pole on 17 internal vertices with ten
designated singleton-boundary perfect matchings whose disjointness graph is
exactly \(C_{10}\).  It has proper edges

\[
a=(5,6)\in\bigcap_{k\text{ even}}N_k,
\qquad
b=(5,7)\in\bigcap_{k\text{ odd}}N_k,
\]

but the even blocker satisfies

\[
a\in Y_0(H-N_1)\cap Y_2(H-N_3).
\]

The two relevant paths are

\[
Y_0=3-16-8-7-6-5-14-11-10-13-9-4,
\]

\[
Y_2=0-12-8-7-6-5-14-11-15-1.
\]

Hence both \(T_0\cap Y_0\) and \(T_2\cap Y_2\) are nonempty.  This
strictly disproves the proposed two-window lemma at the level of the ten
designated matching vectors.

## Why this does not refute the full forced-path conjecture

The complete singleton matching classes of the pole have sizes

\[
(8,8,6,7,4),
\]

and their complete disjoint boundary-pair set is

\[
\{01,02,04,12,13,23,34\},
\]

which is strictly larger than the required five-cycle \(S\).  A second
independent 17-vertex construction likewise gains extra Tait states and has
a capacity-two witness outside the ten designated matchings.  Therefore the
example is not an exact-S counterexample.

The correct remaining boundary is now precise: any general theorem forcing
some \(T_k\cap Y_k\) to be empty must use the complete perfect-matching
closure together with full exact-S, not merely cubic vertex incidence,
endpoint parity, two blocker edges, exact designated \(C_{10}\), or a local
same-parity window restriction.

At orders 13 and 15, incidence models exclude two prescribed same-parity
windows, but this counterexample shows that those are only small-order
facts.  An all-ten 17-vertex synthesis with exact designated \(C_{10}\)
remained unknown after a bounded search and is not used as evidence either
way.

The pure-standard-library verifier is
`scratch/worker-dual/agent-proof/verify_two_window_counterexample.py`.  It
recursively enumerates the complete matching closure, checks the designated
\(C_{10}\), prints both forced paths and terminates with
`TWO_WINDOW_COUNTEREXAMPLE_VERIFIED`.
