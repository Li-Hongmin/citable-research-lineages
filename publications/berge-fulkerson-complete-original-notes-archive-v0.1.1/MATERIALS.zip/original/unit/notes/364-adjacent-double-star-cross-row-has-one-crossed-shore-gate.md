> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The adjacent double-star cross row has one crossed shore gate

Retain the double-star exterior and marks of [Note 363](363-diagonal-double-star-exact-case-xii-fails-by-two-exterior-switches.md): centres \(x,y\), tree subdivisions \(u_0,\ldots,u_4\), ports \(p_0,\ldots,p_4\), and square marks \(a=r_1l_1,b=r_1l_2,c=r_2l_1,d=r_2l_2\). Suppose the allowed Case-XII states incident with shore mark \(e\) are the **adjacent** pair \(ea,eb\). There are two pentagon orders up to the square symmetries preserving this pair:
\[
 S_{\parallel}=e-a-c-d-b-e,\qquad
 S_{\times}=e-a-d-c-b-e.                              \tag{1}
\]
In either order \(ec,ed,ab\in T\). The complete Appendix-XII support requires a row \((ea)(ab)\) and forbids every \(T\)--\(T\) row.

**Theorem.** No exact-Case-XII five-pole with this exterior has the parallel order \(S_{\parallel}\). For the crossed order \(S_{\times}\), every required \((ea)(ab)\) row has the single exterior pattern described below. Its shore matchings obey two necessary alternating-path pairings, (4) and (5). The theorem does not assert that these shore conditions can or cannot be realized together with the remaining required rows.

Let \(P\) be the state-\(ea\) triple, \(R\) the state-\(ab\) triple, \(E\) the singleton at \(e\), \(B\) the singleton at \(b\), and \(A_1,A_2\) the two singleton occurrences at \(a\). Write \(q=c\) for \(S_{\parallel}\) and \(q=d\) for \(S_{\times}\). Two immediate consequences of exact support will be used throughout:

* The \(a\)-terminal path in \(P\triangle A_i\) must end at \(b\). An end at \(c\) or \(d\) would replace \(ea\) by forbidden \(ec\) or \(ed\), leaving \(R=ab\in T\).
* The \(e\)-terminal path in \(P\triangle E\) must end at \(q\). An end at \(b\) would replace \(ea\) by \(ab\in T\); an end at the other mark of \(\{c,d\}\) would replace it by \(ar\in T\), where \(r\) is that other mark. Its allowed replacement is \(aq\in S\).

All switches below exchange **complete** perfect-matching occurrences along one alternating component. Hence each resulting row still loads every edge twice, whatever happens inside the shore.

## The \(r_1\)-root is impossible

Suppose \(P\) uses \(t_ar_1\). Any \(A_i\) using the root tree edge \(r_1u_1\) must have its \(a\)--\(b\) path entirely outside the shore:
\[
              a-t_a-r_1-u_1-x-u_0-y-u_4-l_2-t_b-b.       \tag{2}
\]
Indeed, from \(x\), the \(u_2\)-branch ends at \(c\) or \(d\); from \(y\), the \(u_3\)-branch ends at \(c\). The allowed end \(b\) therefore forces both displayed branches and \(A_i\) on \(t_bl_2\). Switching (2) changes \(P\) to an \(eb\)-triple rooted at \(l_2\). If the original \(B\) uses \(l_2t_d\), the further exterior path \(b-t_b-l_2-t_d-d\) changes that triple to \(ed\in T\), while \(R\) remains at \(ab\in T\). We may consequently assume \(B\) uses \(l_2u_4\) whenever a root-tree \(A_i\) exists.

The \(ab\)-triple \(R\) selects one of the \(a\)-halves and one of the \(b\)-halves, at different leaves. If it selects \(t_br_1\), that edge has room for at most one \(A_i\); a root-tree \(A_i\) therefore exists. Both triples then use \(l_2u_4\), so \(B\), which already uses terminal \(b\), must use \(l_2t_d\). This contradicts the preceding switch. If instead \(R\) selects \(t_ar_1,t_bl_2\), load propagation at \(l_1,r_2,l_2,t_b\) gives exactly one \(A_i\) on \(r_1u_1\), the other on \(r_1t_b\), and \(B\) on \(l_2t_d\). Again (2) and the second switch contradict exact support.

It remains that \(R\) selects \(t_al_1,t_bl_2\). If one \(A_i\) uses \(r_1u_1\), the other uses \(r_1t_b\): at \(r_1\) the edge \(t_br_1\) then carries that other \(A_i\) and \(E\), while \(t_ar_1\) carries \(P\) and \(B\). The \(b\)-terminal path in \(P\triangle E\) passes through \(r_1\). Its distinct \(e\)--\(q\) path therefore leaves \(t_ar_1\), \(t_br_1\), and terminal \(b\) untouched when switched. The remaining \(A_i\) on \(r_1t_b\) then has the direct path \(a-t_a-r_1-t_b-b\) with the new \(aq\)-triple. Switching it produces \(bq\in T\) beside \(R=ab\in T\).

If neither \(A_i\) uses \(r_1u_1\), both use \(r_1t_b\). When \(B\) uses \(r_1u_1\), \(E\) uses the same \(t_ar_1\) edge as \(P\). Their \(e\)--\(q\) switch cannot change this shared edge or terminal \(b\); either \(A_i\) then switches the resulting \(aq\)-triple to forbidden \(bq\). When \(B\) instead uses \(t_ar_1\), \(E\) uses \(r_1u_1\). At \(t_a\), \(E\) must also use \(t_al_1\); at \(t_b\), it must use \(t_bl_2\). Thus \(E\) is absent from both \(l_1t_c\) and \(l_2t_d\). Since both triples use terminals \(c,d\) and both use \(r_2u_2\), the complementary marked halves \(r_2t_c,r_2t_d\) would **both** need \(E\), impossible in one matching. This exhausts the \(r_1\)-root.

## The \(l_1\)-root fixes the exterior

Suppose \(P\) uses \(t_al_1\). Since \(ec\in T\), each \(A_i\) must use \(l_1u_3\); otherwise \(a-t_a-l_1-t_c-c\) gives a forbidden \((ec)(ab)\) row. Both \(a\) singleton occurrences saturate that root tree edge, so \(R\) also uses \(t_al_1\). If \(R\) selects \(t_br_1\), load at \(r_1\) puts one \(A_i\) on \(r_1u_1\). Starting from \(a-t_a-l_1-u_3-y\), that occurrence cannot reach \(b\): the \(u_4\)-branch ends at \(d\), the \(u_0,u_2\)-branch ends at \(c\), and the \(u_0,u_1\)-branch is unavailable because it already uses \(r_1u_1\). Hence \(R\) selects \(t_bl_2\).

Now both \(A_i\) use \(r_1t_b,r_2t_c,l_2t_d\). Their only permitted \(a\)--\(b\) paths run through \(yu_0,xu_1\). At the tree subdivisions, load two then forces the following **complete exterior restrictions**; a port set records the proper ports used on the shore, and the \(e\)-port is shown separately:

| occurrence | marked halves or terminal | tree edges beyond leaves | shore ports |
|---|---|---|---|
| \(P_{ea}\) | \(t_al_1;\ s_b,s_c,s_d\) | \(yu_3,xu_0,r_1u_1,r_2u_2,l_2u_4\) | none |
| \(R_{ab}\) | \(t_al_1,t_bl_2;\ s_c,s_d\) | \(xu_0,yu_4,r_1u_1,r_2u_2\) | \(e,p_3\) |
| \(E_e\) | \(t_ar_1,t_bl_2,t_cl_1,t_dr_2\) | \(xu_2,yu_4\) | \(e,p_0,p_1,p_3\) |
| \(B_b\) | \(s_b;\ t_ar_1,t_cl_1,t_dr_2\) | \(l_2u_4,xu_2,yu_3\) | \(p_0,p_1\) |
| each \(A_i\) | \(s_a;\ t_br_1,t_cr_2,t_dl_2\) | \(l_1u_3,yu_0,xu_1\) | \(p_2,p_4\) |

For example, \(R\) must use \(yu_4\): if it also used \(yu_3\), then \(yu_4\) would need two singleton occurrences even though the two \(A_i\) already use \(yu_0\) and \(B\) uses \(l_2u_4\). The remaining \(E\) alone cannot fill both copies. The table follows by the same degree-three incidence at each subdivision and leaf.

Let \(Q=P|_Z\) and \(L=E|_Z\) be the complete shore matchings. In \(P\triangle E\), the exterior paths from \(b,c,d\) end at \(p_3,p_1,p_0\), respectively. For \(S_{\parallel}\) the required \(e\)--\(q\) route is \(e\)--\(c\), hence its exterior piece is \(c\)--\(p_1\). It switches \(P\) to an \(ac\)-triple using \(t_ar_1\), while leaving terminal \(b\) untouched. Either \(A_i\) then has the direct path \(a-t_a-r_1-t_b-b\), producing forbidden \((bc)(ab)\). Thus \(S_{\parallel}\) is impossible.

For \(S_{\times}\), the required \(e\)--\(d\) route instead forces the shore pairing
\[
             Q\triangle L:\qquad e p_0\mid p_1p_3
             \quad\text{(plus any closed components)}.       \tag{4}
\]
Switch this complete route. The resulting triple \(P'\) has state \(ad\), exterior port \(p_0\), and shore ports \(e,p_0\). The exterior paths of \(P'\triangle A_i\) run \(a\)--\(p_0\), \(b\)--\(p_2\), and \(c\)--\(p_4\). Since \(R=ab\in T\), switching the \(a\)-path may not lead to \(e\) or \(b\), which would give \(ed\) or \(bd\) in \(T\); it must end at \(c\), giving \(cd\in S_{\times}\). Therefore, for each \(i=1,2\), the complete shore restrictions \(P'|_Z\) and \(A_i|_Z\) must have alternating pairing
\[
             P'|_Z\triangle A_i|_Z:\qquad
                         p_0p_4\mid e p_2
             \quad\text{(plus any closed components)}.       \tag{5}
\]
The square symmetries cover every adjacent placement. Together with [Note 363's diagonal exclusion](363-diagonal-double-star-exact-case-xii-fails-by-two-exterior-switches.md), this leaves just the four symmetry-equivalent crossed-adjacent pentagons among the twelve labelled pentagons on the five marks. Conditions (4)–(5) constrain **actual complete shore matchings in one BF row**, not merely their port sets. Whether the crossed placement can satisfy them together with the other Case-XII rows remains open. The argument is analytic and has not received an independent proof review; no local mathematical recomputation was used.

There is one further complete-mask consequence. The two \(A_i\) have identical exterior restrictions in the table, but their full matchings must be different: the general overlapping \(S\)--\(T\) row lemma of [Note 343](343-a-shared-pure-load-reuses-one-singleton-across-two-disjoint-cells.md) would turn a repeated singleton-\(a\) matching into a forbidden \(ab\)-Tait colouring. Hence \(A_1|_Z\ne A_2|_Z\), and their symmetric difference contains a nonempty union of even alternating cycles entirely in the shore. Both distinct phases must satisfy (5).

Equations (4)–(5) also force a literal intersection in the shore. Let \(H\) be the \(e\)--\(p_0\) path of \(Q\triangle L\), and let \(K_i\) be the \(p_2\)--\(p_4\) path of \(Q\triangle A_i|_Z\). Since \(P'|_Z=Q\triangle E(H)\), disjointness of \(H\) and \(K_i\) would leave \(p_2,p_4\) paired in \(P'|_Z\triangle A_i|_Z\), contrary to (5). At every common shore vertex both alternating paths use its unique \(Q\)-edge. Thus \(H\) and each \(K_i\) share at least one **actual edge of \(Q\)**. The two intersections need not use the same \(Q\)-edge; no global synchronization follows from this observation alone.

The other required row \((eb)(ab)\) is the image under \(a\leftrightarrow b\), \(c\leftrightarrow d\), \(p_3\leftrightarrow p_4\). Calling its zero-port triple shore matching \(\widetilde Q\), its singleton-\(e\) shore matching \(\widetilde L\), and the post-switch \(bc\)-triple \(\widetilde P'\), it necessarily satisfies
\[
 \widetilde Q\triangle\widetilde L:\ ep_0\mid p_1p_4,
 \qquad
 \widetilde P'|_Z\triangle B_i|_Z:\ p_0p_3\mid ep_2.
\]
Each of its two distinct singleton-\(b\) shore matchings meets the \(ep_0\) path of \(\widetilde Q\triangle\widetilde L\) on a \(\widetilde Q\)-edge. The two required rows need not use the same zero-port shore matching; identifying their crossing edges would require an additional full-family argument.
