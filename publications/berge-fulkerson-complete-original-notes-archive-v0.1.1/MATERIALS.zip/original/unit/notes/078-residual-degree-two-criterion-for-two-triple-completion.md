> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Residual degree two exactly characterizes two-triple completion

The singleton-reuse gates in
[Notes 073--074](073-local-trivalent-incidence-does-not-force-the-six-singleton-gate.md)
ask whether four specified singleton-boundary perfect matchings can occur in a
BF cover of a prescribed boundary cell.  This question has an exact graph
criterion: after subtracting the four singleton occurrences from load two,
the residual object is a degree-two multigraph, and its decomposition into
the two required triple-boundary perfect matchings is governed only by cycle
and terminal-path parity.

## Residual multigraph

Let \(H\) be a loopless cubic 5-pole with terminal semiedges indexed by \([5]\).
Let \(P_1,\ldots,P_4\) be singleton-boundary perfect-matching occurrences
whose boundary multiset is the multiset union of two terminal pairs \(s,t\).
Repeated occurrences are allowed.  For every proper edge or semiedge \(e\),
put

\[
 D(e)=2-\sum_{i=1}^4\chi_{P_i}(e).                 \tag{1}
\]

When \(D\ge0\), replace \(e\) by \(D(e)\) labelled copies and denote the
resulting residual multigraph by \(\mathcal D\).  Every internal vertex has
residual degree two, because

\[
 \sum_{e\ni v}D(e)
 =6-\sum_{i=1}^4\sum_{e\ni v}\chi_{P_i}(e)
 =2.                                               \tag{2}
\]

Thus each component of \(\mathcal D\) is a closed cycle or a path ending in
two residual semiedge copies.  Copies are counted separately.  In
particular, two copies of one proper edge form a 2-cycle, while two copies of
one semiedge form a path containing no proper edge.

## Completion criterion

Write \(Q_s\) and \(R_t\) for desired perfect matchings with respective
boundaries \([5]\setminus s\) and \([5]\setminus t\).  Such matchings satisfy

\[
 D=\chi_{Q_s}+\chi_{R_t}                           \tag{3}
\]

if and only if all three conditions hold:

1. \(D(e)\in\{0,1,2\}\) for every proper edge and semiedge;
2. every closed-cycle component of \(\mathcal D\) has even length, with
   copies counted with multiplicity;
3. every terminal path has the parity forced by its two boundary colours.

For the third condition, colour copies belonging to \(Q_s\) red and copies
belonging to \(R_t\) blue.  At terminal \(j\),

\[
 D(j)=2-\mathbf 1_{j\in s}-\mathbf 1_{j\in t}.     \tag{4}
\]

Hence a unique copy at \(j\in s\setminus t\) must be blue, a unique copy at
\(j\in t\setminus s\) must be red, and two copies at
\(j\notin s\cup t\) must receive opposite colours.  If a terminal path has
\(k\) proper-edge copies and endpoint colour bits \(c_0,c_1\), with red
equal to zero and blue equal to one, then its exact compatibility condition
is

\[
 c_0\mathbin\oplus c_1\equiv k+1\pmod 2.          \tag{5}
\]

Equivalently, equally coloured ends require odd proper length, while
oppositely coloured ends require even proper length.

## Proof

If (3) holds, colour each residual copy by the matching that contributes it.
At every internal vertex, \(Q_s\) and \(R_t\) each use one incidence, so the
two residual incidences have opposite colours.  Colours therefore alternate
along every component.  Closed components are even, and a terminal path
with \(k\) proper edges makes \(k+1\) colour changes between its semiedge
ends, giving (5).  Formula (4) gives the asserted endpoint colours.

Conversely, alternately colour every even closed component, choosing either
initial colour independently.  On each terminal path, start with its forced
first colour and alternate; (5) gives the forced colour at the other end.
Every internal vertex is now incident with one red and one blue copy.  The
original edges carrying red copies and blue copies therefore form two
perfect matchings.  Two copies of the same original edge receive opposite
colours, since they already exhaust the residual degree at their common
endpoint, so neither matching uses an edge twice.  The terminal prescription
gives exactly the boundaries \([5]\setminus s\) and \([5]\setminus t\),
which proves (3).

There is no further compatibility condition between distinct components.

## Cell specializations and remaining Case-XII gate

The criterion becomes particularly simple for the three possible
intersections of the pair states:

- if \(s=t\), all terminal paths are automatic doubled-semiedge paths, so
  only edge nonnegativity and closed-cycle parity remain;
- if \(|s\cap t|=1\), the unique nontrivial terminal path joins the two
  exclusive terminals and must have even proper length;
- if \(s\cap t=\varnothing\), the four exclusive terminals form two paths;
  a same-side pair requires odd proper length and a cross \(s\)--\(t\) pair
  requires even proper length.

Consequently the exact singleton-tuple fibre required by Notes 073--074 is
nonempty precisely when its four selected singleton occurrences pass these
three tests.  This replaces the vague global simultaneous-completion
obstruction left by [Note 077](077-one-k33-factor-cannot-block-all-three-repeated-star-targets.md)
with three explicit failure modes: an edge used at least three times, an odd
closed residual cycle, or a terminal path of the wrong parity.  It does not
show that an exact Case-XII pole must contain a successful target tuple; the
remaining problem is to use the other positive cells and the absence of
\(T\)-loop and \(T\)--\(T\) support to force at least one target residual
multigraph through these tests.
