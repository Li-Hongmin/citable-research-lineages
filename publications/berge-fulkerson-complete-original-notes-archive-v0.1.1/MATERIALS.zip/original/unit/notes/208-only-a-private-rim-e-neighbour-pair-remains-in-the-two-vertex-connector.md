> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Only a private--rim \(e\)-neighbour pair remains in the two-vertex connector

Use the genuine two-vertex, one-five-cut connector of [Note 204](204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md), with internal mark \(e\), central mark \(a\) at \(w_0\), private marks \(b,c\) at \(w_1,w_2\), and rim mark \(f=w_1w_2\). [Notes 206](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md) and [207](207-the-central-private-e-neighbour-placements-are-impossible-in-the-two-vertex-connector.md) exclude every allowed pentagon in which \(e\) neighbours \(a\). This note excludes the only remaining neighbour pair not containing \(f\).

**Theorem.** If a pole with this connector has complete exact Case-XII support, then, up to exchanging \(w_1,w_2\), the two neighbours of \(e\) in its allowed missing-pair pentagon \(S\) must be \(b,f\). This is a necessary placement, not an existence assertion.

**Proof of the remaining exclusion.** Suppose instead that \(eb,ec\in S\). The other two pairs incident with \(e\), namely \(ea,ef\), lie in \(T\). Take a required actual \(S\)--\(T\) row and saturate its \(S\)-half \(A\) to state \(eb\) using [Note 055](055-half-load-column-saturation-and-case-xii-compression.md). Write
\[
A=X+Y+Z,qquad
\partial X=\{a,c,f\},\quad\partial Y=\{b\},\quad\partial Z=\{e\}.
\]
By [Note 205's exact triple criterion](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md), \(X\) uses the \(b\)-half at \(w_1\), plus \(u_1w_0,u_2w_2\). The alternating component of \(X\triangle Y\) starting at terminal \(b\) must end at \(c\): switching it changes the missing pair \(eb\) to an edge incident with \(e\), and \(ec\) is the only other such edge of \(S\).

At \(w_1\), \(Y\) cannot use the \(b\)-half because it has terminal \(b\). If it used the \(f\)-half, the component would end at terminal \(f\), giving forbidden \(ef\). Hence \(Y\) uses \(u_1w_1\). The component then traverses \(u_1w_0\) of \(X\). At \(w_0\), using the \(a\)-half would end at terminal \(a\), giving forbidden \(ea\); thus \(Y\) uses \(u_2w_0\). The component next traverses \(u_2w_2\) of \(X\). At \(w_2\), using the \(f\)-half again gives forbidden \(ef\), so \(Y\) must use the \(c\)-half and end at \(c\).

This exhausts the two possible endpoints of mark \(f\): \(Y\) already matches \(w_1\) through \(u_1w_1\) and \(w_2\) through the \(c\)-half. But \(Y\) is singleton-\(b\), so it does **not** use terminal \(f\); its subdivision vertex \(t_f\) must be matched to \(w_1\) or \(w_2\). Neither is free. Thus \(Y\) cannot be a perfect matching. The assumed \(S\)-half does not exist, contradicting the required row. \(\square\)

The four possible neighbour-pair orbits under the exterior reflection are \(\{a,f\}\), \(\{a,b\}\), \(\{b,c\}\), and \(\{b,f\}\). Notes 206--207 and the proof above eliminate the first three. The two cyclic orders with \(e\)-neighbour pair \(\{b,f\}\) still require the six-matching closure; triple-state support alone cannot decide them.
