> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The left \((ea)(eb)\) row also forces a forbidden \(U_A\) completion

Work in the central-path six-port exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact-Case-XII perfect-matching support. By [Note 270](270-the-central-path-side-neighbours-overload-cross-rows.md), \(ea,ec\in S\). The exterior reflection interchanges \(b,d\), so reflect if needed and write \(S=e-a-b-d-c-e\). The required \((ea)(eb)\) cell after reflection is the original \((ea)(ed)\) cell when the names swap; both belong to the complete \(S\)--\(T\) support. This does not prescribe the orientation of any \((ea)(ac)\) row. The shore \(\Sigma\) has even order.

**Fixed-pentagon route refinement.** Every genuine \((ea)(eb)\) row has the left singleton-\(a\) exterior \(Y_L\) and the zero-port \(eb\)-triple exterior \(U_D\). In particular, no genuine row uses \(U_A\). This follows directly from the route columns of Note 271, without the endpoint classification of Note 346 or the later switching arguments of Notes 353–354.

Indeed, exchange the two complete singleton-\(e\) occurrences to put either one, \(D_e\), in the pure \(ea\) half. The opposite half has state \(eb\in T\), so the \(e\)-path of \(X_{ea}\triangle D_e\) must end at \(b\): the other endpoints would make forbidden states \(ac,ad\). Switch the wholly exterior \(a\)--\(c\) component of \(X_{ea}\triangle Y_a\), as in Note 271. The zero-port triple now has state \(ec\), with **the same complete shore matching** as \(X_{ea}\), and the unchanged \(D_e\) must have its \(e\)-path end at \(d\): the other endpoints would make forbidden states \(ac,bc\). Hence the fixed shore \(e\)-path must use a port which leads to \(b\) against \(X_{ea}\) and to \(d\) against the switched triple. In Note 271's notation, the necessary equality is specifically
\[
             P_b^0(D_e)=P_d^L(D_e)\quad\text{or}\quad
             P_b^0(D_e)=P_d^R(D_e),
\]
according to the side of \(Y_a\). Note 271's broad “possible pure side” column also accepts masks through the reverse equality \(P_d^0=P_b^{L/R}\), which certifies purity only when the shore \(e\)-path uses the reflected cyclic order \(e-a-d-b-c-e\). A mask may satisfy both equalities, but for the fixed \(S\) here its \(e\)-path must use the first. Reading the two route columns, rather than that broad column, leaves exactly
\[
\begin{array}{c|c|c}
Y_a&\text{possible }D_e\text{ exteriors}&\text{edges common to all}\;D_e\\\hline
Y_L&\text{the five orientation-I masks}&b:A\\
Y_R&\mathrm{II}:a:\Sigma,2C,4E;\quad
     \mathrm{III}:a:\Sigma,1B,2C;\quad
     \mathrm{IV}:a:\Sigma,1A,2C&b:D,\ 2C.
\end{array}                                                     \tag{0}
\]
For \(Y_L\), the two singleton-\(e\) occurrences load \(b:A\) twice, so \(U_A\), which also uses \(b:A\), is impossible; the \(eb\)-triple must be \(U_D\). For \(Y_R\), the two singleton-\(e\) occurrences load \(b:D\) twice, forcing \(U_A\) rather than \(U_D\); but both also use \(2C\), which \(U_A\) selects. This is a threefold edge load. Thus the right row is impossible and the only candidate is \(Y_L,U_D\).

**BF-inactivity consequence.** Under the same hypotheses, no actual zero-port matching with the \(U_A\) exterior can belong to *any* BF cover. If one did, the ten terminal uses of the six matching occurrences would force one other triple and four singletons: after the \(U_A\) triple uses three terminals, the other five odd-size boundaries sum to seven. Regroup the four singletons by the two triples' missing terminal pairs. The \(U_A\) half has state \(eb\). A \(T\)-state opposite half is forbidden outright; an \(S\)-state opposite half saturates by [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) to a forbidden \((ea)(eb)\) row retaining this same \(U_A\) matching. Nevertheless every zero-port shore matching glues to the \(U_A\) exterior as an **actual perfect matching** by [Note 230, (3)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). The remaining question is whether full closure forces one into a BF cover; the theorem answers this for the left row.

**Theorem.** No genuine \((ea)(eb)\) row can have the remaining left \(Y_L,U_D\) exterior either. Consequently the central-path marked five-pole of Note 271 cannot have complete exact-Case-XII support, at arbitrary six-port shore order and cycle rank. The result uses Note 271's exterior route table and Note 230's zero-port gluing; the only fixed-load state changes needed below are written explicitly. The needed left \(e\to c\) bridge is verified directly below.

**Proof.** Suppose a real left row exists. Note 271 fixes \(X,Y_L\), and matching the eight-edge exterior path with \(b:D\) fixes the zero-port \(eb\)-triple \(U_D\). Their masks are
\[
\begin{aligned}
X_{ea}&=\{a:C,1A,2B,3D,4E;\ b,c,d\},\\
Y_{L,a}&=\{c:A,b:D,d:E,1B,2C,H,J;\ a\},\\
U_{D,eb}&=\{b:D,1A,2B,3C,4E;\ a,c,d\}.
\end{aligned}                                               \tag{1}
\]
Both singleton-\(e\) occurrences must use \(b:A\), since \(Y_L,U_D\) saturate \(b:D\); [Note 271's pure-side table](271-the-central-path-row-requires-two-distinct-shore-masks.md) then makes both orientation I. Its only two pure-left orientation-I masks omitting \(4D\) both use \(3D\), already used by \(X\), so they cannot coexist in a load-two row. Choose a singleton-\(e\) matching \(M_e\) using \(4D\), and exchange the two complete singleton-\(e\) occurrences if needed so that \(M_e\) lies in the pure \(ea\) half; call the other \(F_e\).

The \(b\)-starting exterior arm of \(X\triangle M_e\) is \(b_{\rm term}(X),b:A(M_e),1A(X),I(M_e)\). Its complete \(e\)-starting path must end at \(b\): switching it keeps singleton \(a\) and must leave the pure half in \(S\), whose other neighbour of \(a\) is \(b\). Hence the shore \(E\)-path of \(X|_\Sigma\triangle M_e|_\Sigma\) ends at \(I\). Now exchange all shore-internal alternating cycles of the two zero-port matchings \(X|_\Sigma,U_D|_\Sigma\), preserving the row load and every exterior mask. In this actual phase row, the pure \(ea\) half still contains \(M_e\) and its zero-port triple has the old \(U_D\) shore restriction. The same purity argument forces the \(E\)--\(I\) pairing for \(U_D|_\Sigma\triangle M_e|_\Sigma\) in the original row. Because \(M_e\) uses \(4D\), its \(I\)-starting exterior arm now follows
\[
 I(M_e),\ 1A(U_D),\ b:A(M_e),\ b:D(U_D),\
 4D(M_e),\ 4E(U_D),\ c:E(M_e),\ c_{\rm term}(U_D),
\]
to terminal \(c\). Thus the complete \(e\)-path of \(U_D\triangle M_e\) ends at \(c\). Return to the original zero-port phase and exchange the complete singleton-\(e\) occurrences so that \(M_e\) is in the \(eb\) half and \(F_e\) in the pure half.

Switch this complete \(e\)--\(c\) component. It yields an actual triple \(U'_{ade}\) and singleton \(C_c\), with
\[
U'|_{\rm ext}=\{b:A,c:E,2B,3C,4D,I;\ a,d,e\},
\qquad \partial_\Sigma U'=\{E,I\}.                    \tag{2}
\]
The six original edge loads remain two and now give a genuine \((ea)(bc)\) row
\[
                    X+Y_L+F_e+U'+C_c+W_b=2\mathbf1.       \tag{3}
\]

Put \(R=X+Y_L+U'\). Independently of its shore path pairing, define a *different* actual zero-port \(eb\)-triple \(\widetilde U_A\): use the other exterior path matching, obtained when \(b\) selects \(A\),
\[
       \widetilde U_A|_{\rm ext}
          =\{b:A,1B,2C,3D,4E;\ a,c,d\},               \tag{4}
\]
and glue it to the **same complete zero-port shore matching** \(X|_\Sigma\). This is a genuine full-pole perfect matching by the Cartesian gluing of [Note 230, (3)](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). Moreover \(\widetilde U_A\le R\) edgewise: its edges \(b:A\) come from \(U'\); \(1B,2C\) from \(Y_L\); \(3D,4E\) from \(X\); its three terminal semiedges occur in \(Y_L+U'\), \(X\), and \(X+U'\), respectively; and its shore restriction is exactly \(X|_\Sigma\).

On the shore, the edge-copy residual is therefore
\[
                 (R-\widetilde U_A)|_\Sigma
                       =Y_L|_\Sigma+U'|_\Sigma.       \tag{5}
\]
It is the union of two actual shore matchings. Its closed components are even alternating cycles, including possible doubled edges. Outside the shore the residual has exactly four terminal arms
\[
\begin{array}{c|l}
a\to H&a_{\rm term},\ a:C,\ 3C,\ H\\
b\to J&b_{\rm term},\ b:D,\ 4D,\ J\\
d\to I&d_{\rm term},\ d:E,\ c:E,\ c:A,\ 1A,\ I\\
e\to E&\text{no exterior edge; }E\text{ is the terminal semiedge inside }\Sigma
\end{array}                                               \tag{6}
\]
and one doubled \(2B\) edge, an even two-cycle. There is no other exterior component. Any pairing of the four shore ports \(E,I,H,J\) joins the four arms into two terminal-to-terminal paths; it cannot make another closed component. Thus **every** closed component of \(R-\widetilde U_A\) is even, without using the pairing lock of Note 355. Alternate two colours on the paths and cycles to obtain actual full-pole perfect matchings \(L_1,L_2\) such that
\[
                        R=\widetilde U_A+L_1+L_2.      \tag{7}
\]

The residual terminals are exactly \(a,b,d,e\), once each. A cubic five-pole has odd internal order, so every perfect matching has an odd number of terminal semiedges. Consequently one of \(L_1,L_2\) is a singleton-\(p\) matching for some \(p\in\{a,b,d,e\}\), and the other is a triple. Retain the complete \(F_e,C_c,W_b\) from (3) and regroup (7) into
\[
       (\widetilde U_A+F_e+W_b)\mid(L_1+L_2+C_c).       \tag{8}
\]
The first half has state \(eb\in T\); the second has state \(cp\). If \(p=a\) or \(p=b\), then \(cp\in T\), so (8) is directly a forbidden \(T\)--\(T\) type. If \(p=d\) or \(p=e\), then \(cp\in S\). Keep the **same three complete matchings** \(\widetilde U_A,F_e,W_b\) in the \(eb\) half. Starting at \(cd\), switch the complete two-colour path from singleton \(d\) to a triple terminal; since every alternative would make a forbidden \(T\)--\(T\) row, it must end at \(e\), giving \(ce\). Starting at \(ce\), the analogous path from singleton \(c\) must end at \(a\), giving \(ea\). Thus either \(cd\) or \(ce\) reaches \(ea\) in at most two load-preserving switches of the opposite half. The resulting genuine \((ea)(eb)\) row retains the \(U_A\) exterior, already excluded by the fixed-pentagon route refinement above. Either way we have a contradiction. \(\square\)

The decisive closure is the zero-port gluing in (4) and the even residual in (5)–(6); no all-terminal perfect matching, local enumeration, shore-size bound, or assumption about the \(EI\mid HJ\) path pairing is used. Combined with [Note 270's marked-placement reduction](270-the-central-path-side-neighbours-overload-cross-rows.md), it closes the last \(r=4\) exterior at the four-vertex one-shore barrier. [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md) lists six exteriors at \(|U|=4\); [Note 258](258-the-paw-exterior-forces-a-forbidden-eb-ad-row.md) closes the four \(r=3\) exteriors, and [Note 264](264-the-four-vertex-fork-exterior-is-impossible.md) closes the other \(r=4\) tree. Thus, conditional on those hand-derived classification chains, **no \(|U|=4\) one-internal-mark, one-shore barrier profile supports exact Case XII**. Together with [Note 244's \(|U|\ge4\) bound](244-every-shore-mark-must-neighbour-the-internal-mark.md), every surviving profile of this kind has \(|U|\ge5\). Larger barriers, the other Tutte profiles, and Berge–Fulkerson remain open; the cited upstream hand proofs still require independent verification.
