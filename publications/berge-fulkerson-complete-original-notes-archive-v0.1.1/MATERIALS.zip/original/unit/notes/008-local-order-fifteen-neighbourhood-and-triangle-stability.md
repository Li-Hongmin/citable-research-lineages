> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local order-fifteen neighbourhood and triangle stability

Starting from the explicit thirteen-vertex pole of Note 005, choose two
distinct edge objects among its 17 proper edges and five labelled semiedges,
subdivide each once, and join the two new vertices.  This is the minimal
terminal-preserving cubic move that raises the odd internal order from 13 to
15.  All \(\binom{22}{2}=231\) labelled moves were checked exactly.

For every child, the program enumerates all perfect matchings, retains only
children whose Tait lonely-pair state set is exactly

\[
S=\{13,14,24,25,35\},
\]

and then runs a capacity-two transversal CSP with early termination.  The
result is

\[
231\longrightarrow45\longrightarrow45:
\]

45 children retain exact \(S\), and every one has a capacity-two witness.
Among the 192 moves on disjoint edge objects only six retain exact \(S\), and
all six succeed.  The complete retained-record digest is

`0216411cd8f8e8678e3b1a8fa23a8433cd24ae8969112cbf49069510ddc3fd45`.

The other 39 moves select two edge objects sharing a vertex.  They are exactly
vertex-to-triangle expansions.  Their success is structural rather than a
finite accident.  Given a capacity-two transversal in the parent, lift each
selected perfect matching as follows: if it uses an exterior edge incident
with the expanded vertex, add the opposite edge of the new triangle.  At the
triangle, the three new-edge multiplicities are a permutation of the three
old incident-edge multiplicities, so they remain at most two.  This only
asserts a unique standard lift for every parent matching; it is not a
bijection on all child perfect matchings, because a child matching may use all
three exterior edges and no triangle edge.  The local lifting/contraction *is*
a bijection for Tait colourings, so the exact boundary state set is preserved.

Thus vertex-to-triangle expansion can never destroy an existing capacity-two
witness and cannot produce a counterexample from this seed.  The finite scan
closes the entire one-move two-edge-insertion neighbourhood, not all
fifteen-vertex 5-poles.

The verifier is
`scratch/worker-verify/scan_n15_local_expansions.py`.
