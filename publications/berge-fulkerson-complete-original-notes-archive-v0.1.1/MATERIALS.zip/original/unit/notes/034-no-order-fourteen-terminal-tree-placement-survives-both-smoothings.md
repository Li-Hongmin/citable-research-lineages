> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# No order-fourteen terminal-tree placement survives both smoothings

The complete order-fourteen cubic girth-five census excludes the
terminal-tree forced-pair mechanism of Note 022 from a minimum Case-XII
counterexample at that order.

There are nine simple connected cubic graphs of order fourteen and girth at
least five.  All nine are bridgeless and cyclically 5-edge-connected.  Three
have no cycle-separating 5-cut with a \(C_5\) side and a two-vertex terminal
tree on the other side.  The remaining six contain 36 such placements.

For every placement, both cross smoothings are simple cubic bridgeless
graphs.  Complete BF-cover evaluation gives

\[
\begin{array}{c|r}
\text{statuses of the two smoothings}&\text{placements}\\\hline
\text{flexible} + \text{flexible}&30\\
\text{forced-intersecting} + \text{flexible}&6\\
\text{forced-intersecting} + \text{forced-intersecting}&0.
\end{array}
\]

Thus 66 of the 72 individual smoothings admit a BF cover with disjoint new
edge labels, while six are forced-intersecting.  The paired quantifier is
decisive: in a minimum BF counterexample, every bridgeless cross smoothing
must be forced-intersecting, because one flexible smoothing lifts to a BF
cover of the original graph.  Each of the six forced halves has a flexible
alternative and therefore cannot occur in a minimum counterexample.

The six near-misses also fail the published Case-XII exact-set condition.
Their \(R=C_5\) side has the standard 16 BF boundary types.  Their \(L\)
side has 38 types and contains \((12345)\), which Case XII forbids.  Under
all dihedral relabellings of the cut, the largest overlap with the published
40-type Case-XII \(L\)-set is 26 or 28; none gives equality.

Consequently no order-fourteen placement simultaneously has the genuine
Case-XII cut structure and both bridgeless terminal-tree smoothings
BF-forced-intersecting.  This is a complete order-fourteen result only; no
general flexibility theorem or order-sixteen exclusion is asserted.

The streaming verifier is
`scratch/worker-verify/order14_whole_graph_forced_pair_scan.py`; it terminates
with `ORDER14_WHOLE_GRAPH_FORCED_PAIR_SCAN_OK`.
