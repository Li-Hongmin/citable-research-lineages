> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A \((yq)(u_1y)\) shore row forces the outer \((yq)(xz)\) pair

Continue the genuine \(I_m\) tree--\(R^*\) connector of
[Note 222](222-a-yq-u2z-row-forces-the-forbidden-yq-pz-pair.md).
The tree shore is centred at \(u_1\), with end groups
\(\{u_2,x\}\mid\{z,p\}\). If the cyclic shore supports
the actual BF type \((yq)(u_1y)\), then the outer five-pole
supports the actual type
\[
                              \boxed{(yq)(xz).}             \tag{1}
\]

Use the tree's actual type \((u_2z)(xp)\) and independently
relabel the shore rows in the following six slots:

| slot | \(A^\circ\) | \(B^\circ\) |
|---|---|---|
| 1 | \(u_1xp\) (missing \(u_2z\)) | \(q\) |
| 2 | \(u_1u_2z\) (missing \(xp\)) | \(y\) |
| 3 | \(p\) | \(u_1u_2z\) (missing \(yq\)) |
| 4 | \(x\) | \(u_2zq\) (missing \(u_1y\)) |
| 5 | \(u_2\) | \(y\) |
| 6 | \(z\) | \(u_1\) |

The shore-half and connector labels are
\[
\begin{array}{c|ccccc}
 &u_1&u_2&z&x/p&y/q\\\hline
A&12&25&26&14/13&-\\
B&36&34&34&-&25/14
\end{array},
\qquad
(R_1,R_2;D_x,D_y,D_p,D_q)=(45,16;26,13,24,35).       \tag{2}
\]
They partition \([6]\) at \(u_1,u_2,w_1,w_2\) and each
marked subdivision vertex. The direct \(z\)-mark has residual
\(15\), giving outer terminal labels
\[
                  (T_z,T_x,T_y,T_p,T_q)
                         =(15,35,46,56,26).                \tag{3}
\]
Slot \(5\) has \(\{z,x,p\}\), missing \(yq\), and
slot \(6\) has \(\{y,p,q\}\), missing \(xz\); the other
four slots are singleton boundaries. The actual input rows
cover all internal shore edges twice, proving (1).

For every order in [Note 221, (5)](221-a-shared-z-star-forces-an-outer-xz-loop-in-im.md)
the already forced loops form a spanning path. Its unique
Case-XII five-cycle is either \(p-y-x-q-z-p\) or
\(z-y-x-q-p-z\). Both omit \(yq,xz\). Hence an actual
\((yq)(u_1y)\) shore type contradicts exact Case XII.

Figure 7 makes that type actual for all four labelled orders
with \(\{y,q\}=\{3,4\}\), \(\{z,u_2\}=\{1,5\}\)
or its symmetric order, because \(yq=34\in Q\) while
\(u_1y\in\{35,45,13,14\}\subset P\). It is also actual
for the two orders with \(\{y,q\}=\{2,4\}\), \(z=3\),
and \(y=2,q=4\): here \(yq=24\in P\), while
\(u_1y\) is \(12\) or \(25\), both in \(Q\).
These six orders are excluded.

The two remaining labelled orders have \(y=4,q=2,z=3\)
and \(\{u_2,u_1\}=\{1,5\}\). For them
\(c(yq)=c(u_1y)=P\), so (1) does not apply; their
actual \((yq)(u_1q)\) type requires a separate transport.
This is a precise remaining boundary, not an exact-Case-XII
realization. The analytic argument awaits an independent check.
