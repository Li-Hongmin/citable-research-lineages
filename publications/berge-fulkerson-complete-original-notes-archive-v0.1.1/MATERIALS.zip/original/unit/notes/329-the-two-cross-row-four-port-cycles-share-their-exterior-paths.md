> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two cross-row four-port cycles share their exterior paths

Assume the genuine left \((ea)(ac)\) row of
[Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md)
and the genuine right \((ea)(ad)\) row of
[Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
in the complete exact-Case-XII, \(R_0=DJ\),
\(3{:}2\) one-edge-near-bipartite profile of
[Note 301](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md).
The proper shore ports \(A,I,H\) are \(B\)-based and
\(D,J\) are \(R\)-based. Denote the two *actual
complete* singleton-\(e\) matchings by \(Z_L,Z_R\).
Their shore port sets are \(EAID\) and \(EAHJ\),
respectively. Both select \(E\), avoid \(g\), and
have the same selected terminal semiedge \(e\).

**Theorem.** The two shore paths of \(Z_L\triangle Z_R\)
pair
\[
                              IH\mid DJ.                    \tag{1}
\]
Their exterior paths pair \(IJ\mid DH\). Hence the
full-pole symmetric difference has one alternating cycle
passing through all four proper ports \(I,J,D,H\),
with possible additional closed components. This
four-port cycle avoids \(g\) and the marked vertex
\(t_e\). It shares both of its exterior path segments
with the distinct four-port cycle through \(g,t_e\)
in Note 301, assertion 5, formed from the two
cross-row singleton-\(a\) matchings. The symmetric
difference of these two cycles is therefore an
even-degree subgraph wholly inside the shore and
contains \(g\) and both marked half-edges. It is not
asserted to be alternating for any one matching.

**Proof.** The common selected \(E\) edge covers
\(t_e\) in both matchings, so neither marked half-edge
is in their symmetric difference. The edge \(g\) is
also absent from both. By [Note 283's bipartite
placement](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md),
the only same-side shore edges that can lie on
\(Z_L\triangle Z_R\) are the \(D,J\) port edges.
Each open shore path joins a port selected by \(Z_L\)
to one selected by \(Z_R\); its alternating edge count
is even. Both exterior ends of the path lie in the
\(R\) bipartition class, so an even path uses an even
number of same-side edges. Consequently its two
port ends contain either both of \(D,J\) or neither.
This gives exactly (1).

The two singleton-\(e\) exterior masks share
\(a:\Sigma\) and the selected terminal \(e\).
Tracing their remaining differing edges gives the
complete exterior paths
\[
\begin{aligned}
 I&-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c-A_{\rm ext}
       -t_b-D_{\rm ext}-u_4-J,\\
 D&-u_2-C_{\rm ext}-u_3-H.
\end{aligned}                                                 \tag{2}
\]
For example, the first path alternates between the
left edges \(I,b\!:\!A,c\!:\!E,d\!:\!B,4D\)
and the right edges \(1B,d\!:\!E,c\!:\!A,b\!:\!D,J\);
the second alternates between \(D,3C\) on the left
and \(2C,H\) on the right. Thus (2) pairs \(IJ\mid DH\).
Joining it to the shore paths \(IH\mid DJ\)
produces one four-port alternating cycle. Since \(g\)
and \(t_e\) are common or absent as noted, it avoids
both.

[Note 301, equation (4)](301-the-left-ac-row-excludes-ij-and-separates-two-ej-exchange-routes.md)
gives exactly the two exterior edge paths (2) for the
cross-row singleton-\(a\) pair, while its assertion 5
gives shore pairing \(ID\mid HJ\) and a full cycle
through \(g,t_e\). Hence the two full cycles share
both exterior segments, as claimed. \(\square\)

The theorem does not equate any complete matchings from
different rows, nor does it make the two cycles
independently switchable in one BF row. It supplies a
fixed cross-row overlap for analyzing larger Hall cuts
and the marked-edge collision. Their compatibility
under the full matching family, other shore profiles,
and Berge–Fulkerson remain open. The exterior masks
and upstream route arguments are hand-derived and await
independent second-source checking; no local computation
or OMEN run was used.
