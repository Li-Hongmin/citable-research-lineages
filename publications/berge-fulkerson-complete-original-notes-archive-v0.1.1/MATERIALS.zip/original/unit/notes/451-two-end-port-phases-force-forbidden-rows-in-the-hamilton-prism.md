> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two end-port phases force forbidden rows in the Hamilton prism

Continue [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md) with the Hamilton three-spoke tree \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) and marks \((X,Y,Z,W)=(14,15,26,36)\). Name a genuine \((eX)(eY)\) row's six **complete** matching occurrences \(P=eX,R=eY,K=Y,J=X,E=e,F=e\), and put \(\Lambda=\{J,E,F\}\). In the fifth line of Note 446(3), take the one tree-half choice
\[
P=eX:1,\quad R=eY:5,\quad
K:X:1,Z:6,W:3,\quad K:2u_1,4u_3,5u_5.
\tag{1}
\]
Thus \(K\) uses ports \(p_2,p_4\).

**Conditional closure.** If the old \(R\)-half \(Y:5\) is paired with \(J\), the row recompletes to a \([eW]\) loop. If \(Y:5\) is paired with an \(e\)-singleton and \(K:p_2\) is paired with \(J\), the row recompletes to \((eX)(eW)\). In both cases every labelled occurrence retains its entire original shore matching. The only old port form not covered by these two constructions is the crossed form (7) below; this note makes no claim that it occurs in an exact-Case-XII pole or that some other closure operation cannot exclude it.

To derive the old port forms, the old \(t_X\) pairs are \((RJ,PK,EF)\), and \(t_Y\) has terminal pair \(PK\). Let \(Y:5=Rb\), \(5u_4=Pa\), and \(5u_5=Kc\). Then \(\{a,b,c\}=\Lambda\). The pair \(X:4=EF\) and the old \(4u_3=PK\) force \(4u_4=RJ\); hence \(a\in\{E,F\}\), and the old \(p_4=Kg\), where \(\{a,g\}=\{E,F\}\). Let \(p_2=KL\). Partitioning at \(u_1,u_2,u_3\), then at \(t_Z,t_W\), gives
\[
(p_1,p_2,p_3,p_4,p_5)
=(\Lambda\setminus\{b\},\ KL,\ \Lambda\setminus\{L\},\ Kg,\ \Lambda\setminus\{c\}),
\qquad L\in\Lambda\setminus\{b\}.
\tag{2}
\]
An \(u_i\) triple below lists first-end half, second-end half, and port. A marked triple lists terminal and then halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposition denotes an unordered occurrence pair.

## Phase \(b=J\): a forbidden \([eW]\) loop

Now \(c=g\in\{E,F\}\), so (2) reads \((EF,KL,\Lambda\setminus\{L\},Kc,\Lambda\setminus\{c\})\). Recomplete with both triples \(P,R=eW:3\), both \(K,J=W\), and \(E,F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,KJ,EF)&(PR,\Lambda\setminus\{L\},KL)
 &(KL,PR,\Lambda\setminus\{L\})
 &(\Lambda\setminus\{c\},PR,Kc)
 &(Kc,PR,\Lambda\setminus\{c\})
\end{array}                                                   \tag{3}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(PR,\Lambda\setminus\{c\},Kc)
 &(PR,Kc,\Lambda\setminus\{c\})
 &(PR,EF,KJ)&(KJ,PR,EF).
\end{array}                                                   \tag{4}
\]
At vertices \(1,\ldots,6\), the incident pairs are
\[
(PR,\Lambda\setminus\{c\},Kc),\quad(KJ,PR,EF),\quad
(\Lambda\setminus\{L\},PR,KL),\quad
(PR,Kc,\Lambda\setminus\{c\}),\quad
(PR,\Lambda\setminus\{c\},Kc),\quad(PR,KJ,EF).
\tag{5}
\]
Each triple partitions the six labels; the port column is exactly the old one, and the terminal pairs in (4) give \([eW]\).

## Phase \(b=g\), \(L=J\): a forbidden \((eX)(eW)\) row

Now \(b\in\{E,F\}\), \(a\) is the other \(e\)-singleton, and \(c=J\). The old port pairs reduce to \((Ja,KJ,EF,Kb,EF)\). Choose either ordering \((A,B)\) of \((a,b)\). The following new row has \(P=eX:1,R=eW:6,K=W,J=X,E=F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(Rb,PK,Ja)&(RA,PB,KJ)&(RK,PJ,EF)
 &(Ra,PJ,Kb)&(RK,PJ,EF)
\end{array}                                                   \tag{6a}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,Pa,Kb)&(PR,KJ,EF)
 &(PR,\Lambda\setminus\{A\},KA)
 &(PK,\Lambda\setminus\{B\},RB).
\end{array}                                                   \tag{6b}
\]
At vertices \(1,\ldots,6\), the pairs are
\[
(Pa,Rb,KJ),\quad
(PK,RA,\Lambda\setminus\{A\}),\quad
(PB,RK,\Lambda\setminus\{B\}),\quad
(PJ,Ra,Kb),\quad
(PJ,RK,EF),\quad
(PJ,KA,RB).
\tag{6c}
\]
They partition the six labels because \(\{A,B\}=\{a,b\}=\{E,F\}\). The port column of (6a) is \((Ja,KJ,EF,Kb,EF)\), and (6b) has terminal type \((eX)(eW)\).

For both recompletions, every subdivision triple and original-vertex triple is a six-label partition. Every exterior edge has load two; the five proper-port pairs and the shore terminal pair \(EF\) are unchanged label by label. Gluing each new exterior restriction to its own original complete shore matching therefore gives a genuine forbidden row. Under exact Case XII with forbidden \(\{eX,eW\}\), neither phase can occur.

If \(b=g\) and \(L=a\), (2) instead has the **crossed** port form
\[
(p_1,p_2,p_3,p_4,p_5)=(Ja,Ka,Jb,Kb,EF),
\qquad \{a,b\}=\{E,F\}.
\tag{7}
\]
The two explicit constructions above do not preserve (7). Whether (7) is excluded by another actual matching closure, by constraints on the complete six-port shore relation, or by a different required Case-XII row is open here. The other three tree-half choices in the fifth line and both choices in the sixth line of Note 446(3) are also open. This is a hand-derived conditional certificate awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later results: [Note 453](453-the-crossed-hamilton-port-row-forces-a-forbidden-loop.md) excludes (7) by a labelwise shore-preserving \([eX]\) recompletion. [Notes 454](454-fifth-line-hamilton-rows-leave-two-labelled-port-phases.md) and [455](455-sixth-line-hamilton-rows-leave-four-labelled-port-profiles.md) reduce the other tree-half choices to five distinct labelled port profiles.
