> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Double-role cycle rounding needs endpoint routing

The finite radius-one result of
[Note 035](035-radius-one-variable-q-rounding-holds-on-the-first-173-seed-children.md)
does not have a uniform explanation using only the changed third-matching
cycle and its local defect exits.  There is a general local criterion when
the endpoint split uses both endpoint matchings of the changed state, but an
explicit one-role repair changes multiplicities outside that cycle.

## The double-role update

Fix an edge-covering five-tuple $Q=(Q_0,\ldots,Q_4)$, an endpoint split,
and one state $t$.  Replace $Q_t$ by a perfect matching $Q'_t$ with the
same boundary such that

\[
C=Q_t\mathbin\triangle Q'_t
\]

is one internal alternating cycle.  Put

\[
A=Q_t\setminus Q'_t,
\qquad
B=Q'_t\setminus Q_t,
\]

so that $C=A\mathbin{\dot\cup}B$.  Suppose that the endpoint split uses
both endpoint matchings belonging to state $t$.  The two endpoint
matchings together are the complement of the corresponding third matching.
Consequently, if $m(e)$ and $m'(e)$ are the multiplicities of $e$ in
the old and new five selected endpoint matchings, then

\[
\boxed{
m'=m+\mathbf 1_A-\mathbf 1_B.
} \tag{1}
\]

Let

\[
P_0=\{e:m(e)=1\},
\qquad
P'_0=\{e:m'(e)=1\}.
\]

Equation (1), considered separately on $A$, $B$, and the complement of
$C$, gives the exact identity

\[
\boxed{
P'_0=(P_0\setminus C)
\cup\{e\in A:m(e)=0\}
\cup\{e\in B:m(e)=2\}.
} \tag{2}
\]

## A general sufficient condition

Assume

\[
\begin{aligned}
m(e)&\in\{1,2\} &&(e\notin C),\\
m(e)&\in\{0,1\} &&(e\in A),\\
m(e)&\in\{2,3\} &&(e\in B).
\end{aligned} \tag{3}
\]

Then (1) implies

\[
m'(e)\in\{1,2\}
\qquad\text{for every edge }e.
\]

At every cubic vertex the three incident multiplicities sum to five, so
they are $(1,2,2)$ in some order.  Hence $P'_0$ contains exactly one edge
at every vertex and is a perfect matching.  Equivalently, the covered-split
criterion of [Note 023](023-fixed-q-paired-defect-capacity-rounding.md)
shows that the new endpoint split is a capacity-two transversal.

Equations (1)--(3) are general: they apply to any cubic graph or cubic pole
and any such double-role endpoint split.  They do not use the finite
enumeration from Note 035.

## The first finite failure of the double-role explanation

The 55 fixed-$Q$ failures in Note 035 were considered in the deterministic
order used by the accompanying computation.  The first 37 have radius-one
repairs with a double-role endpoint split satisfying (3).  The thirty-eighth
has no double-role repair among its radius-one neighbours; its repair must
instead use only one endpoint matching from the changed state.

This is a stopping-prefix classification inside the 55 failures.  It proves
that the double-role mechanism is not universal, but it does not classify
the double-role status of the remaining 17 failures and does not enlarge the
173-move range of Note 035.

## One-role changes depend on the endpoint route

In a one-role repair, let $P$ be the selected endpoint matching before the
exchange and $P'$ the selected endpoint matching afterwards.  Define

\[
D^-=P\setminus P',
\qquad
D^+=P'\setminus P,
\qquad
D=P\mathbin\triangle P'.
\]

Only this selected endpoint exchange determines the multiplicity update:

\[
m'=m-\mathbf 1_{D^-}+\mathbf 1_{D^+}, \tag{4}
\]

and therefore

\[
P'_0=(P_0\setminus D)
\cup\{e\in D^-:m(e)=2\}
\cup\{e\in D^+:m(e)=0\}. \tag{5}
\]

In general $D$ is not the third-matching cycle
$C=Q_t\mathbin\triangle Q'_t$.  An explicit example among the Note 035
failures has group index

\[
(6,0,2,1,2),
\]

changed state $t=4$, and

\[
C=\{e_7,e_8,e_9,e_{11},e_{12},e_{15}\},
\]

whereas its one-role endpoint exchange is

\[
D=\{e_2,e_3,e_8,e_{11},e_{12},e_{15}\}.
\]

Thus

\[
\boxed{D\setminus C=\{e_2,e_3\}.} \tag{6}
\]

The multiplicity and $P_0$ changes in (4)--(5) therefore involve edges
that are invisible to $C$ and to defect/exit data confined to $C$.
Consequently $C$ together with its local defect vertices and connector
exits does not determine a one-role repair.  Any uniform endpoint-rounding
interface covering this example must additionally retain $D$, or
equivalently the external completion routing that determines $D$.

This closes only the proposed $C$-local description.  It neither refutes
the finite 55/55 radius-one result of Note 035 nor decides a general
variable-$Q$ radius-one conjecture.

The supporting exploration is
[the double-role defect-cycle analysis](../scratch/worker-proof/audit_double_role_defect_cycle_criterion.py).
