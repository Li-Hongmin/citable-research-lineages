> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The \(Y,Z\)-forbidden Hamilton pair has five tree signatures

Use the Hamilton three-spoke exterior
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,\qquad
(X,Y,Z,W)=(14,15,26,36).
\tag{1}
\]
Assume its complete BF support is exact Case XII with forbidden \(e\)-labels \(\{eY,eZ\}\). The two possible pentagons are \(e-X-Y-Z-W-e\) and \(e-X-Z-Y-W-e\). Under \((e,X,Y,Z,W)=(1,3,5,2,4)\) and \((e,X,Z,Y,W)=(1,3,5,2,4)\), respectively, the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((eY)(eX)\) row and excludes \([eY]\) and \((eY)(eZ)\).

Name this row's six **complete** matching occurrences
\[
P=eY,\qquad R=eX,\qquad K=X,\qquad J=Y,\qquad
a=e,\qquad b=e,\qquad \Lambda=\{J,a,b\}.
\tag{2}
\]
The two triples \(P,R\) use no proper shore port, \(K,J\) use two each, and \(a,b\) use three each, by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). The \(X\)-starting component of \(R\triangle K\) cannot end at \(Y\), which would give \([eY]\), or at \(Z\), which would give \((eY)(eZ)\). It therefore ends at \(W\). Starting at \(R\)'s root endpoint of \(X\), the path follows tree edges away from the root without entering a proper shore port, as in [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md). Because \(K\) takes tree halves at exactly three of the five \(u_i\), it cannot traverse the five-edge route from \(1\) to \(W:6\).

**Five-signature gate.** Every required \((eY)(eX)\) row under these support absences has exactly one of the following necessary marked/tree/port signatures. In the tree-half column \(iu_j\) denotes the half of \(u_j\) incident with original vertex \(i\):
\[
\begin{array}{c|c|c|l|c}
 &P=eY\text{ root}&R=eX\text{ root};\ W\text{ end}
 &K\text{ tree halves}&K\text{ proper ports}\\ \hline
A&1&1;\ 3&1u_1,\ 2u_2,\ 4u_4&3,5\\
B_1&1&4;\ 3&1u_1,\ 2u_2,\ 4u_3&4,5\\
B_2&5&4;\ 3&2u_1,\ 4u_3,\ 5u_5&2,4\\
C_1&1&4;\ 6&1u_1,\ 4u_4,\ 5u_5&2,3\\
C_2&5&4;\ 6&3u_2,\ 4u_4,\ 5u_5&1,3
\end{array}
\tag{3}
\]
In \(A,B_1,B_2\), \(K\) uses the marked halves \(Y:5,Z:6,W:3\) when \(P\) roots at \(1\), and \(Y:1,Z:6,W:3\) when \(P\) roots at \(5\). In \(C_1,C_2\), replace \(Z:6,W:3\) by \(Z:2,W:6\). In every case \(K\) selects terminal \(X\).

Here is a direct completeness check of (3). The only tree routes from an endpoint of \(X\) to an endpoint of \(W\) of length at most three are \(1\to3\), \(4\to3\), and \(4\to6\). On \(1\to3\), \(K\) must take \(1u_1,2u_2\). If \(P\) rooted at \(5\), both \(P,K\) would occupy \(1u_1\), while \(K\) also occupies \(Y:1\), duplicating \(K\) at original vertex \(1\); hence \(P\) roots at \(1\). The pairs \(P,R\) on \(u_3:4\), \(K\) on \(W:3\), and \(K\) on \(Y:5\) then force \(K\) onto \(4u_4\) and ports \(p_3,p_5\), giving \(A\).

On \(4\to3\), \(K\) uses \(4u_3\). If \(P\) roots at \(1\), the slots at vertices \(1\) and \(5\) force \(K:1u_1\) and \(p_5\); vertex \(4\) forces \(p_4\), leaving \(K:2u_2\), giving \(B_1\). If \(P\) roots at \(5\), vertex \(5\) forces \(K:5u_5\), vertex \(3\) forces \(p_2\), and vertex \(4\) forces \(p_4\), leaving \(K:2u_1\), giving \(B_2\). On \(4\to6\), \(K\) uses \(4u_4,5u_5\). If \(P\) roots at \(1\), vertex \(1\) forces \(K:1u_1\), giving \(C_1\); if \(P\) roots at \(5\), vertex \(3\) forces \(K:3u_2\), giving \(C_2\). The remaining two proper ports follow from the two-port quota. Finally, at vertex \(6\) the two zero-port triples both use \(6u_5\), so \(K:W:3\) forces \(K:Z:6\), while \(K:W:6\) forces \(K:Z:2\). At \(t_Y\), \(K\) uses the half opposite \(P\)'s root. This proves the table as a necessary all-order classification, without asserting shore realizability of each row.

## The first signature: two phases force \([eY]\)

For row \(A\), set \(\nu\in\{a,b\}\) by the old \(Y:1=P\nu\), and write \(\bar\nu\) for the other \(e\)-singleton, so \(Y:5=K\bar\nu\). Let \(X:1=R\mu\) and \(u_1:1=K\lambda_1\). Partitioning original vertex \(1\) gives
\[
\{\lambda_1,\mu,\nu\}=\Lambda.
\tag{4}
\]
Write \(u_2:2=K\lambda_2\), where \(\lambda_2\in\Lambda\). The old row's complete labelled shore-port pairs are then forced to be
\[
(p_1,p_2,p_3,p_4,p_5)
=(\Lambda\setminus\{\lambda_1\},
\Lambda\setminus\{\lambda_2\},K\lambda_2,
\Lambda\setminus\{\mu\},K\bar\nu),\qquad e=ab.
\tag{5}
\]
For example, the \(K\lambda_2\) pair propagates from \(u_2:2\) through \(Z:6,6,W:3\) to \(p_3\), while \(X:4=\Lambda\setminus\{\mu\}\) forces \(u_4:4=K\mu\). The slots at \(Y:5\) and original vertex \(5\) give \(p_5=K\bar\nu\).

If \(\lambda_2\ne\lambda_1\), put \(h=\Lambda\setminus\{\lambda_1,\lambda_2\}\). The following new exterior row keeps the six original complete shore matchings separately and has forbidden type \([eY]\). At a tree subdivision list first-end half, second-end half, port; at a marked subdivision list terminal and the two halves in the orders of (1):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(RK,P\lambda_1,\Lambda\setminus\{\lambda_1\})
 &(RK,P\lambda_2,\Lambda\setminus\{\lambda_2\})
 &(Rh,P\lambda_1,K\lambda_2)
 &(R\mu,PK,\Lambda\setminus\{\mu\})
 &(J\nu,PR,K\bar\nu)
\end{array}
\tag{6}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(PR,\Lambda\setminus\{\nu\},K\nu)
 &(KJ,P\nu,R\bar\nu)
 &(PR,\Lambda\setminus\{\lambda_1\},K\lambda_1)
 &(PR,K\lambda_1,\Lambda\setminus\{\lambda_1\}).
\end{array}
\tag{7}
\]
The original vertices \(1,\ldots,6\) see
\[
(RK,\Lambda\setminus\{\nu\},P\nu),\quad
(P\lambda_1,RK,\Lambda\setminus\{\lambda_1\}),\quad
(P\lambda_2,Rh,K\lambda_1),\quad
(P\lambda_1,R\mu,K\nu),\quad
(PK,J\nu,R\bar\nu),\quad
(PR,K\lambda_1,\Lambda\setminus\{\lambda_1\}).
\tag{8}
\]
Equations (4) and \(\{\lambda_1,\lambda_2,h\}=\Lambda\) make every triple in (6)--(8) a partition of \(\{P,R,K,J,a,b\}\). The port column of (6) is exactly (5), and \(e=ab\) is unchanged. Gluing each new exterior restriction to its own original complete shore restriction gives a genuine \([eY]\) BF loop. Thus exact Case XII excludes the two non-diagonal phases of \(A\).

If \(\lambda_2=\lambda_1\), (4)--(5) leave only two labelled port forms, after renaming \(\nu=a,\bar\nu=b\):
\[
(ab,ab,KJ,Ja,Kb)
\qquad\text{or}\qquad
(Ja,Ja,Kb,ab,Kb),\qquad e=ab.
\tag{9}
\]
This note does not exclude (9), nor the \(B_1,B_2,C_1,C_2\) signatures, from exact Case XII. It gives the next finite shore-independent boundary for the forbidden pair \(\{eY,eZ\}\); the other forbidden pairs, other exteriors, the complete Case-XII problem, and Berge--Fulkerson remain open. The classification and recompletion are hand-derived and await independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later results: [Note 459](459-two-diagonal-y-z-hamilton-rows-are-real-but-have-forbidden-loops.md) realizes both diagonal rows in genuine 21-vertex poles. [Note 460](460-both-diagonal-y-z-hamilton-rows-force-a-forbidden-double-triple.md) gives a shore-preserving forbidden \((eY)(eZ)\) recompletion for each, so signature \(A\) is now wholly excluded.

Further correction and result: [Note 461](461-the-y-z-forbidden-hamilton-pair-forces-a-forbidden-recompletion.md) shows that candidate \(C_1\) misses original vertex \(3\) in the \(K\) matching, and recompletes every \(B_1,B_2,C_2\) phase to forbidden \((eY)(eZ)\). Thus this entire forbidden pair is conditionally excluded on the fixed marked exterior.
