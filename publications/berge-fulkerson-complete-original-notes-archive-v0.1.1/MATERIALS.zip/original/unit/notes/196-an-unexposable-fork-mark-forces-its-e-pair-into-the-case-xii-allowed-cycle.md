> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An unexposable fork mark forces its e-pair into the Case-XII allowed cycle

Assume a genuine \((4,2,2)\) marked five-pole has **complete exact Case-XII BF support** as in [Máčajová--Mazzuoccolo--Tabarelli (2026), Figure 7 and Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), with allowed five-cycle \(S\) and forbidden complementary five-cycle \(T\) on terminal names \(\{a,b,c,d,e\}\). Use the deletion indicators of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md). If \(H=0\) and one outer mark is unexposable, say \(I_d=0\), then
\[
\boxed{de\in S.}                                                   \tag{1}
\]
The same holds with \(d\) replaced by any of \(a,b,c\). This is a necessary condition for a full-support pole, not an existence statement. In particular, a putative exact-Case-XII \((4,2,2)\) pole with \(H=0\) and \(de\in T\) must have \(I_d=1\). The argument uses an actual prescribed BF row in each case, not isolated triple matchings or free exterior labels.

## Forced triple-slot routes

By Note 194, all ten triple states occur under exact support. With \(H=I_d=0\), its formula (3) forces \(I_a=I_b=I_c=E=1\). A triple matching missing \(dc\) must select \(v_c\) through mark \(c\), select singleton \(w_2\) through \(d\), and match \(u\) to \(w_1\). A triple missing \(dq\), where \(q\in\{a,b\}\), must select \(v_q\) through \(q\), select \(w_2\) through \(d\), and again match \(u\) to \(w_1\); the option matching \(u\) through \(h\) is excluded by \(H=0\). A triple missing \(ej\) selects a \(C\)-endpoint through \(e\), selects the singleton at \(j\)'s fork through \(j\), and matches \(u\) to the opposite singleton. These routes hold for *every* actual triple matching in the indicated state, regardless of its matching inside \(C\).

Suppose for contradiction that \(de\in T\). Every such five-cycle is one of the following three forms, with \(p,q\) the two names \(a,b\) in either order. Each table row names a required positive \(S\)--\(T\) BF type and the terminal path forced in the symmetric difference of its two actual triple occurrences.

| forbidden cycle \(T\) | required positive BF type | forced exterior alternating path | type after switching that path |
|---|---|---|---|
| \(d-c-p-q-e-d\) | \((dc)(ep)\) | \(d-w_2-u-w_1-p\) | \((cp)(de)\) |
| \(d-p-q-c-e-d\) | \((dq)(ce)\) | \(d-w_2-c\) | \((qc)(de)\) |
| \(d-p-c-q-e-d\) | \((dc)(eq)\) | \(d-w_2-u-w_1-q\) | \((cq)(de)\) |

The path notation suppresses the marked subdivision vertices and terminal semiedges at its ends. For example, in the first row the \(dc\)-triple uses \(d w_2\) and \(uw_1\), while the \(ep\)-triple uses \(p w_1\) and \(uw_2\). Their symmetric difference therefore contains the displayed \(d\)--\(p\) path entirely outside \(C\). In the second row both triples match \(u\) to \(w_1\), and \(w_2\) connects the \(d\) and \(c\) terminal ends. The third row is analogous to the first. These paths cannot join another component of the symmetric difference: all their interior vertices already have degree two in it.

Switching the two triple perfect matchings along the displayed alternating path keeps both matchings perfect and preserves the total load of every edge in the six-matching BF row; the other four occurrences are unchanged. The final column follows by exchanging the two terminal memberships along that path. In each row both resulting missing pairs are edges of \(T\): \(de\in T\), and the other edge is visibly on the displayed cycle. Exact Case XII has no \(T\)--\(T\) BF type. This contradiction proves (1). \(\square\)

The conclusion does not force \(H=1\): the case \(H=0\) with both fork endpoints exposable has no unexposable outer mark to which (1) applies, and the case with one unexposable mark remains possible at this level when its \(e\)-pair belongs to \(S\). The limitation of this one-row route is exact. Among the triple states whose exterior owner is forced by \(H=I_d=0\), every disjoint pair has one state containing \(d\) and the other containing \(e\); its forced cross-path switch produces \(de\) as one of the two new missing pairs. When \(de\in S\), that switch cannot yield a forbidden \(T\)--\(T\) type. A further exclusion must control an actual row containing a flexible triple state such as \(ab,ac,bc\), or couple complete matching identities across rows. [Note 197](197-a-saturated-s-carrier-cannot-double-the-h-edge-in-the-422-profile.md) gives one such half-load restriction without resolving the coupling.
