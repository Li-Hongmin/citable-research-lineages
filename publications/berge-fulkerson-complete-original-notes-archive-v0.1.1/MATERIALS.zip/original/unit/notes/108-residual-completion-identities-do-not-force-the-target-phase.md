> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Residual completion identities do not force the target phase

The residual-companion shortcut left by
[Note 107](107-fixed-row-switches-do-not-preserve-the-shared-witness-context.md)
also stops at the component level.  Combining the fixed carrier identity,
the full completion of [Note 106](106-common-k-domination-forces-a-full-perfect-matching-completion.md),
and the exact phase criterion of
[Note 082](082-two-paired-splices-have-an-exact-phase-intersection-criterion.md)
does not force the non-leakage companion to carry the target phase.  The same
equations admit the opposite phase on an alternating component of arbitrary
even length while preserving the carrier load and the literal leakage mask.

This is an unlimited-order symbolic separation of the frozen identities from
the required phase conclusion.  It is not a cubic-pole realization and does
not decide whether complete exact-Case-XII graph-induced closure supplies an
additional cross-context constraint.

## The combined equations

Fix a non-entry Note-104 context.  Write $T$ for the target,
$P\in\mathcal C_a(T)$, and $L=L_a$ for its fixed agreement occurrence.
On every component $C$ of $P\triangle T$, Note 093 gives

\[
 L=T\quad\hbox{on }C.                                      \tag{1}
\]

Let the fixed half be $H=L+F+G$, and suppose the leakage decomposition is

\[
 K=2\mathbf1-H=P+N+W,                                    \tag{2}
\]

where $W$ is kept literally equal to the opposite operative leakage
witness and $N$ is the other residual companion.  Keeping $K,W$ fixed
while replacing $P$ by $T$ forces

\[
 N'=N+P-T.                                                \tag{3}
\]

By Note 082, (3) is a perfect matching exactly when $N$ uses the $T$-phase
on every component of $P\triangle T$.  Equations (1)--(2) do not imply that
phase.

## A component assignment with the opposite phase

On an arbitrary even alternating component $C$, split its edges into the
$P$- and $T$-phases.  At every vertex let $x$ be the third incidence.
Use the following local matching incidences:

\[
 P=N=P\text{-phase},\qquad T=L=F=T\text{-phase},\qquad
 G=W=x.                                                   \tag{4}
\]

Every named occurrence selects exactly one incidence at each vertex.  Also

\[
 H=2T\text{-phase}+x,qquad
 K=2P\text{-phase}+x=P+N+W.                               \tag{5}
\]

Thus (1), both definitions of $K$, local trivalence, and literal preservation
of $W$ all hold.  Nevertheless $N=P$ on $C$, the phase opposite to the
one required by Note 082.  Formula (3) then has coordinates $2$ on the
$P$-phase and $-1$ on the $T$-phase, so it is not a matching.

The construction works for every even length.  It applies verbatim to all
twelve non-entry contexts: the four endpoint roles and the three choices of
fixed agreement occurrence only rename $T,L,F,G$.  In each of the four entry
contexts $P=T$, so the symmetric difference is empty and no nontrivial
switch exists.  Note 104's leakage table fixes boundary states, not component
phases, and its no-all-terminal hitting condition does not add an equation on
$N\cap C$.  The shared Note-101 quartic trade contains no residual companion
and likewise cannot select the phase.

## Boundary of the result

The frozen identities therefore permit both phase assignments and cannot by
themselves force the proposed nontrivial same-$K$, fixed-$W$ switch.  This
closes the residual-companion phase-forcing submechanism, not R2 and not the
existence question for real exact-Case-XII poles.

The single surviving graph-induced requirement is a cross-context full-PM
phase coupling: complete exact-Case-XII closure would have to prevent
opposite-phase choices in all twelve non-entry contexts and force one common
full-mask point in the same-$K$, agreement-core, leakage/opposite, and phase
fibres.  No current frozen identity supplies this coupling.  A negative answer
at graph level still requires an actual rooted cubic pole and independent
reconstruction of its complete perfect-matching closure.

The expanded audit is retained in
[`RESIDUAL_COMPANION_PHASE_AUDIT_20260911.md`](../../../scratch/r2-rooted-cubic-pm-closure-20260910/RESIDUAL_COMPANION_PHASE_AUDIT_20260911.md).
