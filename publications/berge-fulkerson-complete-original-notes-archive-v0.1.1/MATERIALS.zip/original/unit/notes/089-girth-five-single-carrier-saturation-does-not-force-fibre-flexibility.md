> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Girth-five single-carrier saturation does not imply fibre flexibility

[Note 087](087-carrier-entry-is-residual-parity-and-is-not-forced-by-global-class-flexibility.md)
isolates the three residual tests required for a same-class matching to enter
a fixed carrier.  [Note 088](088-full-perfect-matching-closure-does-not-force-global-avoider-carrier-entry.md)
shows that common cubic incidence and full perfect-matching closure do not by
themselves force this entry.  The construction below strengthens the local
boundary: even girth five, complete \(S\)-saturation of the half-load, and an
actual complementary BF half do not force carrier-fibre flexibility.

Let \(K\) be the 5-cycle pole whose terminal labels occur in cyclic order

\[
  1,3,5,2,4.
\]

Its complete proper-colouring state set is

\[
  \mathcal R(K)=S=\{13,35,25,24,14\}.                 \tag{1}
\]

Indeed, in a proper 3-edge-colouring of an odd 5-cycle the cycle-edge
colour multiplicities are \(2,2,1\).  The endpoints of the uniquely
coloured cycle edge are precisely the two singleton terminals.  Conversely,
every cycle edge can be chosen as the uniquely coloured edge.  Thus the five
states are exactly the five adjacent terminal pairs in the displayed cyclic
order.

Fix the state \(13\), orient its two singleton colours as \(1\) and \(3\),
and denote the remaining, triple colour by \(q\).  If \(r=xy\) is the cycle
edge joining the terminal vertices labelled \(1\) and \(3\), then \(r\) has
colour \(q\) in every oriented state-\(13\) colouring.  We replace this
forced triple-colour edge by an alternating chain.

## Alternating-chain replacement

Let \(z_0,z_1,\ldots,z_{2m-1}\) be the vertices of a path, and partition its
edges into

\[
 \begin{aligned}
 M_A&=\{z_{2j}z_{2j+1}:0\le j<m\},\\
 M_C&=\{z_{2j-1}z_{2j}:1\le j<m\}.
 \end{aligned}                                      \tag{2}
\]

Let \(M_B\) be a perfect matching of the \(2m\) path vertices, disjoint from
the path edges.  The underlying cubic 2-pole \(P\) has edge set

\[
 E(P)=M_A\mathbin{\dot\cup}M_C\mathbin{\dot\cup}M_B. \tag{3}
\]

Its ports are \(z_0,z_{2m-1}\), which have internal degree two; every other
vertex has degree three.  Delete \(r\) from \(K\), attach \(x\) to \(z_0\)
and \(z_{2m-1}\) to \(y\), and call the resulting 5-pole \(H\).

Choose any oriented state-\(13\) colouring of \(K\), with perfect matchings
\(Q,L_1,L_3\) of colours \(q,1,3\), respectively.  Since \(Q\) contains
\(r\) and \(L_1,L_3\) avoid it, the following are actual perfect matchings of
\(H\):

\[
 \begin{aligned}
 Q^*&=(Q-\{r\})\cup\{xz_0,z_{2m-1}y\}\cup M_C,\\
 L_i^A&=L_i\cup M_A,\\
 L_i^B&=L_i\cup M_B \qquad (i\in\{1,3\}).
 \end{aligned}                                      \tag{4}
\]

Define the two three-matching half-loads

\[
 A=\chi_{Q^*}+\chi_{L_1^A}+\chi_{L_3^A},\qquad
 B=\chi_{Q^*}+\chi_{L_1^B}+\chi_{L_3^B}.             \tag{5}
\]

Every unchanged edge and semiedge has load one in each half.  The two
attachment edges and the edges of \(M_C\) also have load one in each half,
whereas

\[
 \begin{array}{c|cc}
       &A&B\\ \hline
 M_A   &2&0\\
 M_B   &0&2.
 \end{array}                                        \tag{6}
\]

Consequently

\[
 A+B=2\mathbf 1,                                    \tag{7}
\]

so the six matchings in (4) form a genuine BF cover of loop type
\((13)(13)\).

## Compression and the complete state set

In the load multigraph \(H_A\), every edge of \(M_A\) occurs twice, every
edge of \(M_C\) and both attachment edges occur once, and every edge of
\(M_B\) is absent.  At a doubled edge \(z_{2j}z_{2j+1}\), its two copies
receive distinct colours in every proper 3-edge-colouring.  The single edge
incident with \(z_{2j}\) and the single edge incident with \(z_{2j+1}\)
therefore receive their common third colour.  Induction along the chain
shows that

\[
 xz_0, M_C, z_{2m-1}y
\]

are all coloured alike.  Compressing this chain to \(r=xy\) gives a proper
colouring of \(K\).

Conversely, a colouring of \(K\) lifts after assigning the two colours other
than the colour of \(r\) to the copies of each doubled \(M_A\)-edge.  These
choices are independent, so every colouring has exactly \(2^m\) lifts.
Compression and lifting preserve the terminal colours, and hence

\[
 \mathcal R(A)=\mathcal R(K)=S.                     \tag{8}
\]

This is an equality for the complete decomposition family of \(A\), not
only for the three displayed matchings.

In an oriented state-\(13\) decomposition, the compressed edge \(r\) has
colour \(q\).  Every doubled edge of \(M_A\) consequently has one copy of
colour \(1\) and one of colour \(3\).  Therefore, for every chosen

\[
 e\in M_A,                                          \tag{9}
\]

all class-\(1\) members of the oriented state-\(13\) carrier fibre of \(A\)
use the physical edge \(e\).  On the other hand, the actual class-\(1\)
matching \(L_1^B\) has the same boundary class and avoids every edge of
\(M_A\).  It is a global avoider in the complementary half, but it cannot
enter the carrier \(A\) because \(A\) has zero load on \(M_B\).  Thus
complete \(S\)-saturation and global same-class flexibility do not imply
carrier-fibre flexibility.

## Exact short-cycle criterion for the underlying 2-pole

Encode \(M_B\) by the fixed-point-free involution

\[
 \beta(i)=j\quad\Longleftrightarrow\quad z_i z_j\in M_B.
\]

The path-plus-matching 2-pole \(P\) is simple and has no triangle or
4-cycle if and only if

\[
 \begin{aligned}
 |\beta(i)-i|&\ge4 &&(0\le i<2m),                 \tag{10}\\
 |\beta(i+1)-\beta(i)|&\ne1 &&(0\le i<2m-1).     \tag{11}
 \end{aligned}
\]

To prove necessity and sufficiency, observe first that a chord joining
positions at distance one duplicates a path edge, one at distance two
forms a triangle, and one at distance three forms a 4-cycle.  These are
exactly the failures excluded by (10).  A triangle cannot contain two
matching chords because two such chords would be adjacent.  A 4-cycle not
already covered by a single distance-three chord must contain exactly two
matching chords and two path edges.  It exists precisely when some adjacent
path pair \(i,i+1\) is matched to another adjacent path pair, which is
exactly the failure of (11).  This exhausts all cycles of length at most
four.

Moreover, if a chord has length four, it closes a four-edge path segment
and gives a 5-cycle.  Thus (10)--(11), together with the existence of a
length-four chord, imply that \(P\) has girth exactly five.

## A minimum girth-five alternating chain

Take \(2m=12\) and

\[
 \begin{split}
 M_B=\{&z_0z_4,z_1z_6,z_2z_8,z_3z_{10},\\
       &z_5z_9,z_7z_{11}\}.                         \tag{12}
 \end{split}
\]

The chord lengths are \(4,5,6,7,4,4\), so (10) holds.  In index order,

\[
 (\beta(0),\ldots,\beta(11))
   =(4,6,8,10,0,9,1,11,2,5,3,7),                  \tag{13}
\]

and the successive absolute differences are

\[
 2,2,2,10,9,8,10,9,3,2,4.                         \tag{14}
\]

None is one, so (11) holds.  The chord \(z_0z_4\) exhibits the 5-cycle
\(z_0z_1z_2z_3z_4z_0\); hence \(P\) has girth exactly five.

The full pole \(H\) is also simple, connected, cubic, and of girth exactly
five.  A cycle contained in the replacement has length at least five.  A
cycle meeting both the replacement and \(K-r\) must use both attachment
edges, a \(z_0\)--\(z_{11}\) path in \(P\), and the four-edge \(x\)--\(y\)
path in \(K-r\), so it has length at least seven.  There is no other kind of
cycle.  The construction therefore gives a simple girth-five 5-pole of
order \(5+12=17\) satisfying (7)--(9).

The value \(m=6\) is minimum within this path-plus-perfect-matching class.
This follows directly from (10)--(11).  For
\(2m\le6\), a central path vertex has no possible partner at distance at
least four.  For \(2m=8\), condition (10) successively forces

\[
 \beta(3)=7,\quad\beta(2)=6,\quad\beta(1)=5,\quad\beta(0)=4,
\]

which violates (11).

It remains to exclude \(2m=10\).  Condition (10) gives

\[
 \beta(4)\in\{0,8,9\},\qquad
 \beta(5)\in\{0,1,9\}.
\]

After deleting impossible repeated choices and the two choices
\((\beta(4),\beta(5))=(0,1),(8,9)\), whose remaining vertices cannot be
paired across distance four, the following table lists every residual
bijection.  A word records the images of the positions in the second
column; the parenthesized adjacent positions have adjacent images and hence
violate (11).

\[
\begin{array}{c|c|c|c}
(\beta(4),\beta(5))&\text{positions}&\text{images}&
   \text{possible words and witnesses}\\ \hline
(0,9),(9,0)&123&678&678(12),687(23),768(12),867(23)\\
(8,0)&123&679&679(12),697(34),769(12),967(23)\\
(8,1)&023&679&679(34),697(34),769(34),967(23)\\
(9,1)&023&678&678(23),687(23),768(34),867(23)
\end{array}                                        \tag{15}
\]

Thus no shorter alternating chain satisfies the short-cycle criterion.
This minimum is only for the stated path-plus-perfect-matching replacement;
it is not a minimum over all cubic 2-poles.

## The diamond as the minimum simple local replacement

The earlier diamond is the case \(2m=4\) with

\[
 M_A=\{z_0z_1,z_2z_3\},\quad M_C=\{z_1z_2\},\quad
 M_B=\{z_0z_2,z_1z_3\}.                           \tag{16}
\]

It is \(K_4-z_0z_3\), with \(z_0,z_3\) as ports.  It has triangles, as
predicted by the length-two chords, but it is the minimum simple cubic
2-pole with one attachment at each end.  Two internal vertices cannot give
both ports internal degree two.  With three vertices, the nonport vertex
would need internal degree three in a three-vertex simple graph.  With four
vertices the required degree sequence \((2,2,3,3)\) has the unique simple
realization \(K_4\) minus the port-to-port edge.

Both the order-nine diamond pole and the order-seventeen girth-five pole
therefore realize the same obstruction.  The stronger example proves

\[
 \mathcal R(A)=S+\text{global same-class flexibility}
 \ \not\Longrightarrow\ 
 \text{carrier-fibre flexibility}                 \tag{17}
\]

even for a simple connected cubic girth-five 5-pole and an actual
complementary BF half.  Neither example is asserted to have exact-40 full
BF support.  Any positive exact-Case-XII theorem must use relations between
distinct carriers or the negative full-support assumptions, rather than
saturation of one carrier alone.

The finite check of the minimum chain length and the complete matching
certificate for the order-seventeen pole are frozen in the
[verification bundle](../computations/bundles/minimum-girth-five-alternating-chain-carrier-obstruction/README.md).
