> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Iterated and doubled-Tait routing still do not exclude Case XII

Two natural strengthenings of coherent Kempe routing have been checked
exactly against the 40-type Case-XII transcription.  Neither excludes it.

First, enumerate for every boundary type all routing signatures satisfying
the unary component-switch and disjoint-pair coherence conditions.  There
are 1,860 signatures.  After every component switch, require the complete
routing of the switched colour pair and every colour-disjoint pair to persist,
and iteratively delete any signature lacking a surviving successor.  The
greatest-fixed-point computation performs zero deletion rounds: all 1,860
signatures survive.  Recursive reversibility adds nothing at this abstraction
level.

Second, a BF colouring obtained by doubling a Tait colouring has colour
matchings \(A,A,B,B,C,C\).  The four symmetric differences between any two
duplicated classes are the same graph, so their endpoint routings must agree.
For each loop type

\[
[13],[14],[24],[25],[35],
\]

these cross-copy equalities reduce 177 locally coherent signatures to exactly
one.  This is genuine rigidity, but every single-copy component switch lands
in an adjacent S--S pair type, and the identical switch in the disjoint copy
lands in the adjacent loop.  All outcomes remain in Case XII.

Thus iterated persistent routing and duplicated-colour equality are both
strict route boundaries, not pole-realizability results.  Any further Kempe
attack must couple different BF-colouring orbits, use the 25 S--T pair types
required by Case XII, or retain integer edge multiplicities.

The exact programs are
`scratch/worker-kempe/iterated_routing_audit.py` and
`scratch/worker-kempe/duplicated_tait_routing_audit.py`.

