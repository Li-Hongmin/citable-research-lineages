> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A saturated S carrier cannot double the h edge in the (4,2,2) profile

Let a genuine \((4,2,2)\) marked five-pole have the quotient and notation of [Note 194](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md). Fix complementary terminal five-cycles \(S,T\), assume no \(T\)-loop or \(T\)--\(T\) BF type occurs, and take **any actual** BF row of positive type \((s)(t)\) with \(s\in S,t\in T\). Partition its six matching occurrences into the three-matching \(S\)-half \(A\) and \(T\)-half \(B\). Then the multiplicities of the three edges at the barrier vertex \(u\) in \(A\) satisfy
\[
\boxed{\bigl(A(h),A(uw_1),A(uw_2)\bigr)
\in\{(1,1,1),(0,2,1),(0,1,2)\}.}                  \tag{1}
\]
In particular, the \(S\)-half never uses \(h\) twice, and the \(T\)-half uses it at least once. This is an all-order necessary constraint on actual half-loads. It does not assume that \(F[C]-v_h\) is unmatchable, nor a chosen row family.

**Proof.** [Note 055's column saturation theorem](055-half-load-column-saturation-and-case-xii-compression.md) applies to the actual \(S\)--\(T\) row and negative support: the fixed half-load \(A\) has a three-matching decomposition for **every** state of \(S\), while its three proper-edge loads remain unchanged.

Every five-cycle \(S\) contains at least one edge of each of
\[
P_2=\{ab,ea,eb\},\qquad P_1=\{cd,ec,ed\}.              \tag{2}
\]
Indeed, if \(S\) avoids \(ea,eb\), then \(e\)'s two neighbours on \(S\) are \(c,d\); the path from \(c\) to \(d\) through the remaining vertices \(a,b\) contains \(ab\). The other claim follows by swapping the two forks. By Note 194's forced exterior choices, a triple in any state of \(P_2\) uses \(uw_2\), while a triple in any state of \(P_1\) uses \(uw_1\). Since the fixed half-load \(A\) has decompositions in both kinds of states, \(A(uw_1),A(uw_2)\ge1\).

Each of the three matching occurrences in \(A\) covers \(u\) once, so
\(A(h)+A(uw_1)+A(uw_2)=3\). The nonnegative integer solutions with both fork-edge loads positive are precisely the three vectors in (1). The full BF row loads \(h\) twice, so \(B(h)=2-A(h)\ge1\). \(\square\)

The surviving profiles have a direct reading. If \(A(h)=1\), each of \(h,uw_1,uw_2\) occurs once in the \(S\)-half. If \(A(h)=0\), the complementary \(T\)-half uses \(h\) twice and has only one fork edge available at \(u\); when \(F[C]-v_h\) is unmatchable, its triple matching must use that edge. Determining whether complete exact-Case-XII closure can sustain these profiles across the five required \(T\) columns requires the matching identities inside \(C\); equation (1) alone does not identify them.

More specifically, when \(A(h)=0\), the prescribed \(T\)-state \(t\) of that row fixes the profile whenever \(t\) belongs to one of the forced sets (2):
\[
t\in P_1\Longrightarrow (A(h),A(uw_1),A(uw_2))=(0,1,2),\qquad
t\in P_2\Longrightarrow (A(h),A(uw_1),A(uw_2))=(0,2,1).       \tag{3}
\]
Indeed, the complementary load has \(B(h)=2\), so its only remaining edge at \(u\) must be the edge forced by the triple state \(t\). Opposite-fork states outside \(P_1\cup P_2\) can choose either fork direction when their internal deletion matchings allow it.

There is a cross-column consequence for a **single common complementary carrier pair**. Suppose the fixed loads \(A\) and \(B=2\mathbf1-A\) admit decompositions in all five \(S\) states and all five \(T\) states, respectively. The same five-cycle argument applied to \(T\) gives \(B(uw_1),B(uw_2)\ge1\), hence \(B(h)\le1\). Equation (1) gives \(A(h)\le1\), while \(A(h)+B(h)=2\). Therefore
\[
\boxed{A(h)=B(h)=1,\qquad
(A(h),A(uw_1),A(uw_2))=(B(h),B(uw_1),B(uw_2))=(1,1,1).}       \tag{4}
\]
The conclusion uses actual decompositions of the same **full edge-load masks**, not merely support of the ten boundary states in unrelated rows. A carrier with \(A(h)=0\) cannot serve all five \(T\) columns: its complementary load has \(B(h)=2\) and only one fork edge with positive load, whereas \(T\) contains states forcing both fork directions regardless of whether the \(h\)-deletion is matchable. Equation (4) is necessary for a common carrier; it does not construct one or give the required cross-column singleton identities.

## A balanced column when both e-neighbours lie at one fork

Let \(\{x,y\}\) be either fork pair \(\{a,b\}\) or \(\{c,d\}\), and assume **both** \(ex,ey\in S\). Then \(xy\in T\), since \(S\) is a five-cycle. In every actual \(S\)--\(T\) BF row with \(T\)-state \(xy\), the two half-loads satisfy
\[
\boxed{A(h)=B(h)=1,\qquad
(A(uw_1),A(uw_2))=(B(uw_1),B(uw_2))=(1,1).}                       \tag{5}
\]
More precisely, suppose its \(xy\)-triple selects \(x\)'s endpoint in \(C\) and selects the fork singleton through \(y\). In the \(T\)-half, singleton-\(x\) uses the edge from \(u\) to that fork, singleton-\(y\) uses \(h\), and all three edges at the fork singleton have load one in each half. The assertion is symmetric in the two forks, requires no deletion-matching hypothesis, and applies at every order.

To prove it, suppose \(A(h)=0\). Then \(B(h)=2\). The \(xy\)-triple always matches \(u\) to the **opposite** fork singleton, so both singleton occurrences of \(B\) use \(h\). The triple uses the \(y\)-half at its own fork. Singleton-\(x\) has terminal semiedge \(x\) and cannot use that mark to match the fork; because its \(u\)-edge is \(h\), it must use the \(y\)-half again. Thus \(B(yw)=2\), leaving \(A(yw)=0\), where \(w\) is the fork singleton. But saturation of the same full load \(A\) to the allowed state \(ey\) requires its triple to use \(yw\). This contradiction and (1) prove (5). Now \(B\) has one use of each edge at \(u\). Its \(xy\)-triple uses the edge to the opposite fork; the two singleton occurrences must split \(h\) and the edge to their own fork. If singleton-\(x\) used \(h\), it would again double \(yw\) in \(B\). Therefore singleton-\(x\) uses the own-fork \(u\)-edge, singleton-\(y\) uses \(h\), and the latter matches the fork through \(xw\). The three fork edges occur once each in \(B\), and hence also in \(A=2\mathbf1-B\). \(\square\)

For the shape-II placement \(S=p-q-c-e-d-p\) of [Note 199](199-two-formal-zero-h-loads-for-the-de-pc-seed.md), this applies to the required \(cd\) column because \(ec,ed\in S\). It supplies an actual balanced-\(h\) carrier even if the separate \(pc\) column has one of Note 199's zero-\(h\) profiles. Equation (5) does not identify a singleton matching shared by those two carriers.

There is a further **full-row route constraint** in this placement. The only allowed pair of \(C\)-endpoint owners for the two triples in a required \((pq)(cd)\) row is
\[
\boxed{(pq\text{-owner},cd\text{-owner})=(p,c)\quad\text{or}\quad(q,d).}       \tag{6}
\]
Indeed, the \(pq\)-triple chooses one of \(p,q\) in \(C\), uses the other mark at \(w_1\), and matches \(u\) to \(w_2\). The \(cd\)-triple chooses one of \(c,d\) in \(C\), uses the other mark at \(w_2\), and matches \(u\) to \(w_1\). The two triples have a forced exterior alternating path from the mark selected at \(w_1\) through \(w_1,u,w_2\) to the mark selected at \(w_2\). For owner pair \((p,d)\), switching this path changes the missing pairs to \((pc)(qd)\); for owner pair \((q,c)\), it gives \((qd)(pc)\). Both are forbidden \(T\)--\(T\) types. The other two owner pairs yield allowed \(S\)--\(S\) types. Thus (6) holds for **every actual row**, irrespective of \(H\) and of the choice of matchings inside \(C\). Fixing one \(cd\)-decomposition of its \(T\)-half and applying Note 055 shows more: **every** \(pq\)-decomposition of the same saturated \(S\)-half has the owner paired with that fixed \(cd\) owner in (6), since each such decomposition can be combined with the unchanged complementary full load. Conversely, fixing one \(pq\)-decomposition and varying the \(cd\)-decomposition of the same \(T\)-half shows that its owner is fixed as well. Thus each complementary carrier pair has one aligned owner choice for all such decompositions. \(\square\)

In particular, [Note 194's](194-triple-boundary-states-of-the-422-pole-are-vertex-deletion-matchings.md) deletion indicators obey the necessary condition
\[
\boxed{(I_p\land I_c)\lor(I_q\land I_d).}                         \tag{7}
\]
It follows from the two actual triple matchings in (6). When \(H=1\), this strengthens the separate single-state requirements \(I_p\lor I_q\) and \(I_c\lor I_d\): two individually present same-fork triple states are insufficient if their only exposable endpoints have crossed owners.
