> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The paw exterior forces a forbidden \((eb)(ad)\) row

Retain the complete exact-Case-XII, minimum-host, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md). This note treats its \(r=3,|U|=4\) paw exterior: the triangle with one pendant edge on \(U\), every edge subdivided by a singleton \(W\)-vertex, and one additional singleton leaf. No order or cycle-rank restriction is imposed on the odd shore \(\Sigma\).

Let the triangle be \(u_1u_2u_3u_1\), its pendant edge \(u_1u_4\), and put \(A,B,C,D\) on \(u_1u_2,u_2u_3,u_3u_1,u_1u_4\), respectively. The leaf \(P\) meets \(u_4\). Thus
\[
K=\{1A,2A,2B,3B,3C,1C,1D,4D,4P\},\qquad
h_i=u_i\Sigma\quad(i=2,3,4).                              \tag{1}
\]
The internal shore mark is \(e\). Name the two marks from \(W\) to \(\Sigma\) by \(a,d\); [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md) makes \(ea,ed\) the allowed neighbours of \(e\). The other two marks are \(b,c\).

**Theorem.** This paw exterior has no marking with complete exact-Case-XII BF support. Up to reflection of the triangle, only the three placements in (2) satisfy the degree, girth-five, and [Note 246](246-the-two-shore-marks-need-distinct-singleton-endpoints.md) conditions. Two fail before a full six-matching row can exist. In the third, every required \((ea)(ad)\) row yields a forbidden \((eb)(ad)\) row by one exterior six-cycle phase change and a shore-preserving splice. Therefore all four \(r=3,|U|=4\) unmarked exteriors of Note 245 are excluded, using this note and [Notes 248](248-the-second-leaf-six-cycle-forces-an-overloaded-ec-row.md), [256](256-the-first-leaf-b-exterior-forces-a-forbidden-eb-ad-row.md), and [257](257-the-four-cycle-leaf-exterior-forces-a-forbidden-eb-ad-row.md).

## The marked placements

The marked capacities of \(A,B,C,D,P\) are \(1,1,1,1,2\). Two singleton vertices sharing a neighbour in \(U\) cannot be joined by a mark, since subdivision would create a four-cycle. Among \(A,B,C,D\) only \(BD\) is allowed; \(P\) can meet \(A,B,C\) but not \(D\). By Note 246, \(P\) meets at most one shore mark. If it meets none, its two cross marks are \(PA,PC\) or, up to reflection, \(PA,PB\). If it meets one shore mark, the other cross mark must be \(BD\), so the mark at \(P\) joins \(A\) or \(C\); reflect to \(A\). The resulting placements are
\[
\begin{array}{c|cc|cc}
 &a&d&b&c\\ \hline
\mathrm I&B\!:\!\Sigma&D\!:\!\Sigma&PA&PC\\
\mathrm{II}&C\!:\!\Sigma&D\!:\!\Sigma&PA&PB\\
\mathrm{III}&P\!:\!\Sigma&C\!:\!\Sigma&PA&BD.
\end{array}                                                   \tag{2}
\]
Interchanging the two shore-mark names reverses the allowed pentagon at \(e\), and the labels \(b,c\) can be interchanged without changing the argument.

In every placement the [published Case-XII table](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a real \((ea)(ad)\) row. Since \(ad\in T\), its \(ea\) half \(X_a+Y_a+Z_e\) must be pure \(S\). The state-\(ea\) triple \(X_a\) is zero-port by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), and [Note 244's argument](244-every-shore-mark-must-neighbour-the-internal-mark.md) forces the \(a\)--\(d\) path in \(X_a\triangle Y_a\) to stay wholly exterior.

**Placement I.** Deleting \(B\) from \(K\) gives the unique triple exterior
\[
X_a=\{a:B,1D,2A,3C,4P\}.                             \tag{3}
\]
The exterior \(a\)--\(d\) path must run through \(B-u_2-A-u_1-D\) or \(B-u_3-C-u_1-D\). In \(Y_a\), the terminal \(d\) uses \(d:D\), so \(u_4\) must use \(4P\). Both cross marks \(PA,PC\) therefore have to select their non-\(P\) endpoints, but the path to \(d\) occupies one of those endpoints. No pure \(S\) half exists.

**Placement II.** Deleting \(C\) gives
\[
X_a=\{a:C,1D,2A,3B,4P\}.                             \tag{4}
\]
The long route \(C-u_3-B-u_2-A-u_1-D\) occupies both non-\(P\) endpoints of the cross marks. The short \(C-u_1-D\) route is the only possible one, and it uniquely forces
\[
Y_a=\{d:D,b:A,c:B,1C,4P,h_2,h_3\}.                    \tag{5}
\]
Write the required row as \(X_a+Y_a+Z_e\) opposite \(U_{ad}+V_a+W_d\). Exchange the **complete** singleton-\(a\) matchings \(Y_a,V_a\). The row remains valid; the new \(ea\) half is again pure because its opposite state is \(ad\in T\). By uniqueness (5), \(V_a\) has the same exterior mask as \(Y_a\). The two occurrences already load \(b:A,c:B\) twice. Therefore the singleton-\(e\) matching \(Z_e\) would have to select both \(b:P\) and \(c:P\), covering the same vertex \(P\) twice. No required row exists.

## Placement III: the forced unit half

Write its required row as
\[
\mathcal D=X_a+Y_a+Z_e,\qquad
\mathcal E=U_{ad}+V_a+W_d,\qquad
\mathcal D+\mathcal E=2\mathbf1.                         \tag{6}
\]
The triple \(X_a\) uses \(a:P\). The two \(K-P\) phases are
\[
M_0=\{4D,1A,2B,3C\},\qquad
M_1=\{4D,1C,2A,3B\}.                                    \tag{7}
\]
The \(M_0\) phase sends the \(a\)--\(d\) path along \(P-u_4-D-u_1-A-u_2-B-u_3-C\); in \(Y_a\), this occupies both endpoints of \(b=PA\). Hence \(X_a=\{a:P\}\cup M_1\). Its short \(P-u_4-D-u_1-C\) path forces the unique singleton-\(a\) exterior
\[
Y=\{b:A,c:B,d:C,1D,4P,h_2,h_3\}.                    \tag{8}
\]
As in Placement II, exchanging the two complete singleton-\(a\) occurrences and using purity forces \(V_a\) to have exterior (8) as well.

Both occurrences in (8) already load \(b:A,c:B,d:C,1D,4P,h_2,h_3\) twice. The triple \(U_{ad}\) has terminal \(e\) and exactly one proper shore port. It must select \(d:\Sigma\), and hence \(a:P\); its \(K\)-part is \(M_0\) or \(M_1\). Consequently \(Z_e,W_d\) both select \(a:\Sigma,b:P,c:D,h_4\); \(Z_e\) also selects \(d:\Sigma\), while \(W_d\) has terminal \(d\). The six-cycle
\[
u_1-A-u_2-B-u_3-C-u_1                                \tag{9}
\]
is the only place their exterior masks can vary: each uses one of its two alternating phases, \(N_0=\{1A,2B,3C\}\) or \(N_1=\{1C,2A,3B\}\).

If \(U_{ad}\) uses \(M_1\), then \(X_a,U_{ad}\) already load every \(N_1\)-edge twice, so both \(Z_e,W_d\) use \(N_0\). If \(U_{ad}\) uses \(M_0\), then \(X_a,U_{ad}\) load each edge of (9) once, so \(Z_e,W_d\) use opposite phases. When \(Z_e\) is on \(N_1\), flip the complete cycle (9) in **both** \(Z_e,W_d\). Both remain actual perfect matchings with unchanged terminal boundaries and shore masks, and their sum is unchanged; now \(Z_e\) uses \(N_0\). Thus the pure half can always be arranged with exterior
\[
\begin{aligned}
X_a&=\{a:P,4D,1C,2A,3B\},\\
Y  &=\{b:A,c:B,d:C,1D,4P,h_2,h_3\},\\
Z_e&=\{a:\Sigma,d:\Sigma,b:P,c:D,1A,2B,3C,h_4\}.
\end{aligned}                                                   \tag{10}
\]
These three masks partition all nine \(K\)-edges, both halves of each exterior mark, and \(h_2,h_3,h_4\) exactly once.

## The forbidden shore-preserving splice

There is a second unit-load exterior triple, with the **same shore ports in the same slots** as (10):

| Shore ports | Exterior mask | Full-pole boundary |
|---|---|---|
| \(\varnothing\) | \(U_{eb}=\{b:A,1D,2B,3C,4P\}\) | \(a,c,d\) |
| \(\{h_2,h_3\}\) | \(V_b=\{a:P,c:B,d:C,1A,4D,h_2,h_3\}\) | \(b\) |
| \(\{e,a:\Sigma,d:\Sigma,h_4\}\) | \(W_e=\{a:\Sigma,d:\Sigma,b:P,c:D,1C,2A,3B,h_4\}\) | \(e\) |

Each row is a genuine exterior matching, and the column partitions the same proper exterior edges as (10). Glue to it, slot by slot, the **complete actual shore restrictions** of \(X_a,Y,Z_e\) from (10). The new \(eb\) half has identical edge load on the shore and on every exterior proper edge. Retain \(\mathcal E\) in (6); the resulting six complete perfect matchings form a real \((eb)(ad)\) BF row. The allowed pentagon has precisely \(ea,ed\) at \(e\), so \(eb,ad\in T\), in contradiction with exact Case XII. \(\square\)

The two \(r=4\) tree exteriors, larger barriers, the other Tutte profiles, and Berge--Fulkerson remain open. This analytic argument has not received an independent check.
