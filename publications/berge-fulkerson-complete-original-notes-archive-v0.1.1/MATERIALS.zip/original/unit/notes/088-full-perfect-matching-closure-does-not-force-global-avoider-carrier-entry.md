> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full perfect-matching closure does not force global avoider carrier entry

The carrier-entry criterion of
[Note 087](087-carrier-entry-is-residual-parity-and-is-not-forced-by-global-class-flexibility.md)
cannot be obtained from cubic incidence and complete perfect-matching
closure alone.  The fixed simple connected thirteen-vertex five-pole of
[Note 007](007-independent-certificate-for-the-thirteen-vertex-pole.md)
contains an actual BF row for which a singleton class has a global matching
avoiding an overloaded proper edge, while the corresponding oriented
carrier fibre fixes that edge.

## The fixed pole and row

The pole has vertices \(0,\ldots,12\), one semiedge at each of
\(0,\ldots,4\), and proper edges

\[
\begin{aligned}
 &(0,2),(0,11),(1,11),(1,12),(2,12),(3,9),(3,10),\\
 &(4,8),(4,9),(5,7),(5,8),(5,11),(6,7),(6,10),\\
 &(6,12),(7,9),(8,10).
\end{aligned}                                                     \tag{1}
\]

Its complete perfect-matching family has 31 members.  Number the proper
edges in the order (1), and let \(M_j\) be the sorted matching list of the
independent Note 007 enumeration.  The six matchings

\[
 R=(M_0,M_1,M_4,M_9,M_{25},M_{29})                              \tag{2}
\]

form a BF cover.  Their respective boundary classes are

\[
 1,1,2,4,235,345.                                                \tag{3}
\]

Use instead the state-14 half-load

\[
 A=M_{25}+M_0+M_9                                                   \tag{4}
\]

and its complementary state-12 half

\[
 2\mathbf1-A=M_{29}+M_1+M_4.                                    \tag{5}
\]

Thus the carrier under study is an \(S\)-state half and its complement is
a \(T\)-state half, exactly as in the Case-XII \(S\)--\(T\) columns.

For the 17 proper edges followed by the five semiedges, the load vector of
\(A\) is

\[
 (1,1,1,1,1,1,1,0,2,1,1,1,2,0,1,0,2;1,1,1,1,1).                \tag{6}
\]

In particular, the proper edge

\[
 e=e_6=(3,10)                                                     \tag{7}
\]

is used by \(M_0\in\mathcal P_1\) in the \(S\)-half and by
\(M_4\in\mathcal P_2\) in the complementary \(T\)-half.  It is therefore
used by two distinct singleton classes of the same actual BF row.

## The carrier fibre is fixed but the global class is not

For this fixed half-load define

\[
 \mathcal F_1(A;4)=
 \{P_1:\exists Q_{14},P_4,
      \ \chi_{Q_{14}}+\chi_{P_1}+\chi_{P_4}=A\}.                 \tag{8}
\]

Exhausting the complete 31-matching family gives exactly one state-14
decomposition of \(A\):

\[
 (Q_{14},P_1,P_4)=(M_{25},M_0,M_9).                              \tag{9}
\]

Thus

\[
 \mathcal F_1(A;4)=\{M_0\},\qquad e_6\in M_0.                  \tag{10}
\]

The complete singleton class \(\mathcal P_1\), however, has the two
members

\[
\begin{aligned}
 M_0&=\{e_2,e_4,e_6,e_8,e_{10},e_{12};s_1\},\\
 M_1&=\{e_2,e_4,e_5,e_7,e_9,e_{13};s_1\}.
\end{aligned}                                                     \tag{11}
\]

Hence \(M_1\) avoids \(e_6\).  It is not merely present elsewhere in the
full closure: it already occurs in the complementary half (5) of the same
BF row.  Therefore

\[
 e_6\notin\bigcap_{P\in\mathcal P_1}P,qquad
 e_6\in\bigcap_{P\in\mathcal F_1(A;2)}P.                         \tag{12}
\]

Equation (12) is a real cubic-pole, full-perfect-matching separation of
global class flexibility from fixed oriented-carrier flexibility.  The
fixed graph, the complete PM enumeration, the literal BF cover and the
unique carrier decomposition are independently checked in the
[verification bundle](../computations/bundles/actual-full-closure-carrier-fixed-fibre/README.md).

## Exact remaining hypothesis

This pole is not an exact-Case-XII pole.  Its complete BF support contains
an all-terminal cover and seven \(T\)--\(T\) types, while only 17 of the 25
\(S\)--\(T\) types occur.  It therefore does not refute carrier entry under
the simultaneous exact-Case-XII assumptions.

It does prove that the following data are insufficient:

\[
 \text{simple common cubic incidence}
 +\text{complete PM closure}
 +\text{an actual BF row}
 +\text{a global same-class avoider}.                            \tag{13}
\]

Any positive argument must now use the exact negative support itself: the
absence of the all-terminal and all \(T\)--\(T\) types, together with all
25 positive \(S\)--\(T\) cells, must force an avoiding matching through the
support, closed-cycle parity and terminal-path parity tests of Note 087.
Until that carrier-restricted statement is proved, companion-phase
intersection remains a later gate.
