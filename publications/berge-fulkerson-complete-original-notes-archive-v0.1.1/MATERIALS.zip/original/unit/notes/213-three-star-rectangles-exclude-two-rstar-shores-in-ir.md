> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three star rectangles exclude two R-star shores in \(I_r\)

Use the genuine \(I_r\) two-five-cut quotient of
[Notes 169--170](170-two-five-cut-barrier-shores-have-flexible-three-hit-singletons.md).
Its two odd shores have port sets
\[
 A^\circ=\{u_1,u_2,z_1,z_2,x\},\qquad
 B^\circ=\{u_1,u_2,z_1,z_2,y\}.
\]
The marks \(z_1,z_2\) join \(A\) directly to \(B\);
\(x\) joins \(A\) to singleton \(w_1\), \(y\) joins
\(B\) to singleton \(w_2\), and \(f\) joins \(w_1,w_2\).
Each \(u_i\) joins both shores and \(w_i\).  If both shores
have the complete actual Figure-7 Case-XIII \(R^*\) relation,
then the outer relation contains
\[
                   \boxed{[xy],\ [xf],\ [yf].}                \tag{1}
\]
These three BF loops form a triangle.  The allowed loop set of
exact Case XII is a five-cycle, so two \(R^*\) shores are
impossible in \(I_r\), at every order.

The proof uses only genuine local six-matching BF rows.  In a
six-slot table, a two-digit string labels the two matching slots
using an edge.  Let \(D_x,D_y\) label the \(w_i\)-side halves
of the \(x,y\) marks, \(F_1,F_2\) the two \(w_i\)-side halves
of \(f\), and \(R_i\) the edge \(u_iw_i\).  Disjoint local
shore-half labels at each direct mark and a partition of \([6]\)
at every connector vertex suffice to glue the local rows into an
actual outer BF row.

## The loop \([xy]\)

Put \(K=\{u_1,u_2,z_1,z_2\}\), and fix distinct
\(r,s\in K\).  Suppose \(A^\circ\) supports
\((xr)(xs)\) and \(B^\circ\) supports \((yr)(ys)\).
Place the \(A\)-triples missing \(xr,xs\) in slots \(1,2\),
its singleton \(r,s,x,x\) in \(3,4,5,6\); place the
\(B\)-singleton \(r,s\) in \(1,2\), its triples missing
\(yr,ys\) in \(3,4\), and \(y,y\) in \(5,6\).
At shared port \(r\), the two shore labels are \(23,14\);
at \(s\), they are \(14,23\); at either other shared port
they are \(12,34\).  Hence every direct \(z_i\)-mark has
disjoint halves and both \(R_i=56\).  Choose
\[
 (D_x,F_1,D_y,F_2)=(12,34,34,12).                     \tag{2}
\]
The labels at both \(w_i\) and at the subdivision vertex of
\(f\) partition \([6]\).  The outer terminal labels are
\(T_x=34,T_y=12,T_{z_1}=T_{z_2}=T_f=56\), so slots
\(5,6\) give the actual loop \([xy]\).

For the Figure-7 \(R^*\) relation, colour a local state by its
block \(P\) or \(Q\).  Every port has both colours among its
four incident states: the \(P\)-degrees at labels
\(1,2,3,4,5\) are \(2,1,2,3,2\).  Thus the colourings
\(r\mapsto c_A(xr)\) and \(r\mapsto c_B(yr)\) of the
same four-element set \(K\) are both nonconstant.  Two
nonconstant binary colourings have a common separated pair
(the elementary cut-intersection argument in
[Note 212](212-a-four-leaf-star-rectangle-excludes-rstar-rstar-in-im.md)).
For that pair \(r,s\), both required local rows are actual,
proving \([xy]\) unconditionally.

## The loop \([xf]\)

Put \(K'=\{u_2,z_1,z_2\}\).  First let distinct
\(r,s\in K'\), and suppose the actual shore rows have types
\((xr)(xs)\) and \((u_1r)(u_1s)\).  Place the \(A\)-triples
in slots \(1,2\), its singleton \(r,s,x,x\) in
\(3,4,5,6\); place the \(B\)-singleton \(r,s\) in
\(1,2\), its triples in \(3,4\), and \(u_1,u_1\) in
\(5,6\).  The shared-port labels at \(r,s\) are the same
disjoint pairs \(23/14\) and \(14/23\) as above.  At
\(u_1\), they are \(12/56\), giving \(R_1=34\);
the other shared ports give \(R_2=56\) and
\(T_{z_1}=T_{z_2}=56\).  With
\[
 (D_x,F_1,D_y,F_2)=(12,56,12,34),                     \tag{3}
\]
the connector partitions all slots and gives
\(T_x=34,T_f=12,T_y=56\).  Slots \(5,6\) yield \([xf]\).

There is one more aligned leaf, represented by \(u_1\) on
\(A\) and by \(y\) on \(B\).  For \(r\in K'\), suppose
\(A^\circ\) supports \((xu_1)(xr)\) and
\(B^\circ\) supports \((u_1y)(u_1r)\).  Use the following
six-slot boundary assignment; a triple entry is written as the
set of its three selected shore ports.
\[
\begin{array}{c|c|c}
\text{slot}&A^\circ&B^\circ\\\hline
1&K'&\{y\}\\
2&(K'\setminus\{r\})\cup\{u_1\}&\{r\}\\
3&\{u_1\}&K'\\
4&\{r\}&(K'\setminus\{r\})\cup\{y\}\\
5,6&\{x\}&\{u_1\}
\end{array}.                                                   \tag{4}
\]
At \(u_1\), the shore labels are \(23/56\), so
\(R_1=14\).  At \(r\) they are \(14/23\), and at the
other ports of \(K'\) they are \(12/34\); hence
\(R_2=56\) and the direct marks have disjoint halves.
Choose
\[
 (D_x,F_1,D_y,F_2)=(23,56,23,14).                     \tag{5}
\]
At \(w_1\) the labels \(R_1,D_x,F_1=14,23,56\)
partition \([6]\); at \(w_2\), the labels
\(R_2,D_y,F_2=56,23,14\) do too.  The marked
subdivision vertices give
\(T_x=14,T_f=23,T_y=T_{z_1}=T_{z_2}=56\).
Thus slots \(5,6\) again give \([xf]\).

The colourings of four formal leaves
\(K'\cup\{\star\}\) are now
\[
\begin{array}{c|cc}
&r\in K'&\star\\\hline
A&c_A(xr)&c_A(xu_1)\\
B&c_B(u_1r)&c_B(u_1y)
\end{array}.
\]
Both are nonconstant because every \(R^*\) port sees both
blocks.  A common separated pair exists.  If it lies within
\(K'\), the first construction (3) applies; if it contains
\(\star\), construction (4)--(5) applies.  Therefore
\([xf]\) is forced by the two complete shore relations.

The quotient symmetry exchanging
\((A,u_1,w_1,x)\leftrightarrow(B,u_2,w_2,y)\)
fixes \(f\) and interchanges its two halves.  Applying the
same argument after this relabelling forces \([yf]\).
This proves (1).  The exclusion concerns only two cyclic
nonpentagonal \(R^*\) shores in \(I_r\).  A tree or ordinary
pentagon shore, the other two-vertex quotients, larger barriers,
and the full Berge--Fulkerson conjecture remain open.  The
analytic proof awaits an independent check.
