> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct \(Y\)-to-\(Z\) Hamilton signature forces a forbidden row

Use the Hamilton three-spoke exterior of [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md), with tree \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) and marks \((X,Y,Z,W)=(14,15,26,36)\). In a genuine \((eX)(eY)\) BF row write \(P=eX,R=eY,K=Y,J=X,E=e,F=e\) for its six **complete** matching occurrences, and put \(\Lambda=\{J,E,F\}\). This note treats the fourth line of Note 446(3): \(P=eX:1,R=eY:5\); \(K\) uses \(X:4,Z:6,W:3\), tree halves \(1u_1,2u_2,5u_5\), and ports \(p_3,p_4\).

**Claim.** Every genuine row of this exterior signature can be recompleted into a \((eX)(eW)\) BF row, preserving each labelled occurrence's five proper-port choices and entire original shore matching. Thus this signature is impossible whenever \((eX)(eW)\) is absent, independently of shore order or topology.

Relabel \(E,F\) so that the old \(X:1=PE\) and \(X:4=KF\). At \(u_1:2\) let \(A\in\Lambda\) accompany \(P\); at \(u_2:3\) let \(B\in\Lambda\) accompany \(P\); and at \(W:3\) let \(C\in\Lambda\) accompany \(K\). The partitions at vertex \(3\), the marked \(Z/W\) subdivisions, and vertex \(6\) imply \(\{A,B,C\}=\Lambda\), \(p_1=\Lambda\setminus\{A\}\), and \(p_2=\Lambda\setminus\{B\}\). Write \(p_3=KG\). At vertex \(5\), the old \(Y:5=RE\), so the companion of \(K\) on \(5u_5\) is either \(J\) or \(F\). These are the only two branches needed below.

An \(u_i\) triple lists its first-end half, second-end half, and proper port. A marked triple lists its terminal and then its halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposed letters are unordered occurrence pairs.

## Old \(5u_5=KJ\)

Here \(p_5=EF\), and the old \(5u_4=PF\). At vertex \(4\), the remaining singleton partners force the old \(4u_3=PV\) and \(p_4=KV\), where \(V\in\{J,E\}\). The \(u_3\) partition gives \(\{G,V\}=\{A,B\}\). Thus the old port pairs are
\[
(\Lambda\setminus\{A\},\ \Lambda\setminus\{B\},\ KG,\ KV,\ EF),
\qquad \{A,B,C\}=\{C,G,V\}=\Lambda.
\tag{1}
\]
The following new row has \(P=eX:4,R=eW:3,K=W,J=X,E=F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(PR,KA,\Lambda\setminus\{A\})
 &(PR,KB,\Lambda\setminus\{B\})
 &(PC,RV,KG)
 &(\Lambda\setminus\{V\},PR,KV)
 &(KJ,PR,EF)
\end{array}                                                   \tag{2}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,EF,PK)&(PR,KJ,EF)
 &(PR,\Lambda\setminus\{A\},KA)
 &(PK,RA,\Lambda\setminus\{A\}).
\end{array}                                                   \tag{3}
\]
The original-vertex partitions in order \(1,\ldots,6\) are
\[
(PR,EF,KJ),\ (KA,PR,\Lambda\setminus\{A\}),\
(KB,PC,RA),\ (RV,\Lambda\setminus\{V\},PK),\
(PR,KJ,EF),\ (PR,KA,\Lambda\setminus\{A\}).
\tag{4}
\]
Each partitions all six labels; the only variable middle vertex uses \(\{A,B,C\}=\Lambda\). The port column of (2) is (1), and (3) has terminal type \((eX)(eW)\).

## Old \(5u_5=KF\)

Here \(p_5=JE\) and \(5u_4=PJ\). At vertex \(4\), the old \(4u_3=PJ\), \(4u_4=RE\), and \(p_4=KF\). At \(u_3\), \(\{C,G\}=\{E,F\}\). The old five port pairs are exactly
\[
(\Lambda\setminus\{A\},\ \Lambda\setminus\{B\},\ KG,\ KF,\ JE),
\qquad \{A,B,C\}=\Lambda,\quad \{C,G\}=\{E,F\}.
\tag{5}
\]
Recomplete with \(P=eX:1,R=eW:6,K=W,J=X,E=F=e\):
\[
\begin{array}{c|ccccc}
&u_1&u_2&u_3&u_4&u_5\\ \hline
&(RK,PA,\Lambda\setminus\{A\})
 &(RB,PK,\Lambda\setminus\{B\})
 &(RC,PJ,KG)
 &(RE,PJ,KF)
 &(RF,PK,JE)
\end{array}                                                   \tag{6}
\]
\[
\begin{array}{c|cccc}
&t_X&t_Y&t_Z&t_W\\ \hline
&(RJ,PE,KF)&(PR,JF,KE)
 &(PR,KC,\Lambda\setminus\{C\})
 &(PK,\Lambda\setminus\{C\},RC).
\end{array}                                                   \tag{7}
\]
At vertices \(1,\ldots,6\) the pairs are
\[
(PE,RK,JF),\ (PA,RB,KC),\ (PK,RC,\Lambda\setminus\{C\}),\
(PJ,RE,KF),\ (PJ,RF,KE),\ (PK,RC,\Lambda\setminus\{C\}).
\tag{8}
\]
These are partitions by \(\{A,B,C\}=\Lambda\) and \(\{C,G\}=\{E,F\}\). The port column of (6) is (5), and the terminal pairs in (7) give \((eX)(eW)\).

In both branches, every subdivision triple and every original-vertex triple partitions the six occurrence labels. Consequently every new exterior restriction is a matching and each exterior edge has load two. The five proper-port pairs agree label by label with the old row; the shore terminal \(e\) remains selected by \(E,F\). Gluing each new exterior restriction to its **own original complete shore matching** yields a genuine forbidden BF row. Under exact Case XII with forbidden \(\{eX,eW\}\), the fourth signature is therefore impossible. With Notes 447–449, the first six of Note 446's twelve labelled signatures are excluded. The remaining six signatures, other forbidden pairs of this exterior, and Berge–Fulkerson are not settled here. This certificate is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
