> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first Hamilton three-spoke signature forces a forbidden loop

Use the Hamilton three-spoke exterior and notation of [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md): the tree is
\[
1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6,
\qquad (X,Y,Z,W)=(14,15,26,36).
\]
In a BF row of type \((eX)(eY)\), name the six **complete** matching occurrences
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad E=e,\quad F=e.
\tag{1}
\]
Suppose that its exterior has the first signature of Note 446(3): \(P=eX:1\), \(R=eY:1\), and \(K\) uses \(X:4,Z:2,W:6\), the tree halves \(1u_1,3u_3,5u_5\), and ports \(p_2,p_4\).

**Claim.** Every such genuine BF row can be recompleted to a \([eX]\) BF loop while retaining, for each of its six labelled occurrences, its **entire original shore matching**. Thus this first signature cannot occur if \([eX]\) is absent. The claim holds for every shore order and topology and does not assume exact Case XII.

Relabel \(E,F\) so that the original \(X:1=PE\) and \(X:4=KF\). Put \(\Lambda=\{J,E,F\}\). At vertex \(1\), the original \(K\)-half \(1u_1\) has companion \(L\in\{J,F\}\); the other member of \(\{J,F\}\) accompanies \(R\) on \(Y:1\). Write the companion of \(K\) on \(Z:2\) as \(A\in\Lambda\), and write \(\{B,C\}=\Lambda\setminus\{A\}\), in either order. Load two at \(t_Z,t_W\) and vertices \(3,6\) makes \(A\) also the companion of \(K\) on \(W:6\) and \(3u_3\). The five old proper-port pairs are therefore precisely
\[
\begin{array}{c|ccccc}
L&p_1&p_2&p_3&p_4&p_5\\ \hline
F&JE&KA&BC&KF&EF\\
J&EF&KA&BC&KF&JE.
\end{array}                                                   \tag{2}
\]
For example, \(p_4=KF\) because \(P,R\) both take \(5u_4\), whereas \(4u_4=JE\). The \(p_1,p_5\) entries follow by partitioning at \(t_Y,1,5,u_1,u_5\).

For each line of (2), the following is a new exterior BF row. An \(u_i\) triple lists the pair on its first endpoint half, second endpoint half, and port; a marked triple lists its terminal pair and then the halves in the displayed mark order \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\):
\[
\begin{array}{c|ccccc}
L&u_1&u_2&u_3&u_4&u_5\\ \hline
F&(RF,PK,JE)&(RB,PC,KA)&(RA,PK,BC)&(JE,PR,KF)&(KJ,PR,EF)\\
J&(PJ,RK,EF)&(PB,RC,KA)&(PA,RK,BC)&(JE,PR,KF)&(KF,PR,JE)
\end{array}                                                   \tag{3}
\]
and
\[
\begin{array}{c|cccc}
L&t_X&t_Y&t_Z&t_W\\ \hline
F&(KJ,PE,RF)&(PR,KJ,EF)&(PR,AC,KB)&(PR,KB,AC)\\
J&(KJ,RE,PF)&(PR,KF,JE)&(PR,AC,KB)&(PR,KB,AC).
\end{array}                                                   \tag{4}
\]
In the first line the new triples are \(P=eX:1\) and \(R=eX:4\); in the second they are \(P=eX:4\) and \(R=eX:1\). In both lines \(K,J\) become singleton \(X\), and \(E,F\) remain singleton \(e\). Thus the terminal pairs in (4) give type \([eX]\).

Every triple of pairs in (3)–(4) partitions the six occurrence labels. The pairs at each original vertex do too. To see the only variable middle checks, in the first line the three pairs at vertex \(2\) are \(PK,RB,AC\), and at vertex \(3\) they are \(PC,RA,KB\); in the second line they are \(RK,PB,AC\) and \(RC,PA,KB\). Each is a partition because \(A,B,C\) permute \(J,E,F\). At vertices \(1,4,5,6\), the respective first-line partitions are \((PE,KJ,RF)\), \((PK,JE,RF)\), \((PR,KJ,EF)\), \((PR,KB,AC)\); the second-line partitions are \((RE,KF,PJ)\), \((RK,JE,PF)\), \((PR,KF,JE)\), \((PR,KB,AC)\). Hence every new exterior restriction is a matching and every exterior edge has load two.

The port pairs in (3) agree label by label with (2), and the shore terminal \(e\) remains selected by \(E,F\). Glue occurrence \(P,R,K,J,E,F\) to its own original, possibly different, complete shore restriction. This gives a genuine \([eX]\) row in the same pole. In exact Case XII with forbidden \(\{eX,eW\}\), Appendix XII omits \([eX]\), so the first signature is impossible. The other eleven signatures of Note 446(3), the other forbidden pairs of this Hamilton three-spoke exterior, and the general Case-XII closure problem remain undecided by this argument. The certificate is hand-derived and awaits independent review; no OMEN or local mathematical recomputation was used. \(\square\)
