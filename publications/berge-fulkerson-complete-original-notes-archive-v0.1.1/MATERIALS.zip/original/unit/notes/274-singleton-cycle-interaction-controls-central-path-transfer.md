> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Singleton-cycle interaction controls central-path transfer

Continue the actual central-path rows of [Notes 271–273](273-central-path-transfer-is-a-four-slot-load-intersection.md), with fixed allowed pentagon \(S=e-a-b-d-c-e\). The following test uses the **complete six matchings in one row**; it does not identify matchings from two different rows.

Write either required row as
\[
X_a+Y_a+Z_e+U_t+V_a+W_t=2\mathbf1,
\qquad t\in\{ad,ac\}.
\]
Restrict symmetric differences to the six-port shore and put
\[
P=X_a\triangle Z_e,\qquad
L=Y_a\triangle V_a,\qquad
Q=U_t\triangle W_t.                                      \tag{1}
\]
The four ports of \(P\) are \(e,a:\Sigma,h_1,h_2\). Purity fixes its two terminal paths as \(P_e:e\!\longleftrightarrow\!h_1\) and \(P_a:a:\Sigma\!\longleftrightarrow\!h_2\); \(P\) may also have closed cycles. Since \(Y_a,V_a\) have the same ports, \(L\) is a disjoint union of shore-internal alternating cycles. Edge load two gives the exact mod-two identity
\[
Q=P\triangle L.                                             \tag{2}
\]
Let \(I=P\cup L\), retaining all closed components of \(P\), and regard the four ports as degree-one ends. Two assertions follow.

**Separated-path transfer.** If \(P_e\) and \(P_a\) lie in different connected components of \(I\), then \(Q\) pairs \(e\) with \(h_1\) and \(a:\Sigma\) with \(h_2\). Switching the complete \(c\)--\(d\) component of \(U_t\triangle W_t\) therefore makes a real row of the other type, with the same four-slot load \(X_a+Y_a+Z_e+V_a\). In particular the two sets \(\mathcal F_{ad},\mathcal F_{ac}\) of Note 273 intersect as soon as **one** required row has separated pure paths in \(I\).

**One-cycle crossing.** Suppose \(P_e,P_a\) lie in the same connected component \(I_0\) of \(I\), and \(I_0\) has cycle rank one. Then \(Q\) pairs the four ports *across* the two pure paths. Thus this row cannot be transferred to the other required type by one \(c\)--\(d\) switch, and its four-slot load is absent from the other type's load set.

## Proof

Every edge has even total incidence across the six occurrences, proving (2). A symmetric difference of two perfect matchings has degree zero or two at every internal vertex. Thus \(Q\) consists of closed cycles and two paths on the same four ports as \(P\).

If the pure paths are in different components of \(I\), each of those components contains only its own two terminal ports. Since \(Q\subseteq I\), its two terminal paths must keep the original pairings. Note 272's exterior route table takes \(a:\Sigma\) to \(c\) and \(h_2\) to \(d\) in the \(ad\) row, with the reverse correspondence in the \(ac\) row. Therefore the \(a:\Sigma\)--\(h_2\) shore path is exactly the switch used in Note 273, proving the first assertion.

Now suppose \(I_0\) is unicyclic and contains both pure paths. Some cycle of \(L\) is needed to connect the disjoint components of \(P\). Since \(I_0\) has only one cycle, it contains no closed component of \(P\) and exactly one cycle \(C\) of \(L\). The cycles of \(L\) are vertex-disjoint, so this \(C\) meets both pure paths. When two degree-two subgraphs meet at a vertex of a cubic shore they share an edge, so these meetings are edge intersections. A simple path in a unicyclic graph meets its unique cycle in one contiguous segment: leaving and later re-entering the cycle would create a second cycle. Hence \(P_e\cap C\) and \(P_a\cap C\) are two disjoint nonempty segments of \(C\). In \(P\triangle C\), these segments are removed and the two complementary arcs of \(C\) are inserted. Each complementary arc joins an end of the \(P_e\) segment to an end of the \(P_a\) segment. Both terminal paths of \(Q\) consequently connect ports from different pure paths. No other component of \(L\) changes these four ports. This proves the crossing assertion. \(\square\)

The dichotomy gives a necessary all-orders boundary for an empty four-slot intersection: **every** real \(ad\) and \(ac\) row must have its two pure paths in one component of \(P\cup L\). In the special case where \(P\) has no closed shore cycle, this means that at least one singleton-difference cycle meets *both* pure paths. Conversely, a common-load row whose pure paths are connected inside \(P\cup L\) must have cycle rank at least two in that component. Cycle rank at least two is only a necessary condition in the connected case, not a transfer certificate.

The one-cycle case occurs in a genuine row. In [Note 272's first 25-vertex \(ad\) pole](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), the shore matchings from Note 254 have \(L\) equal to the central six-cycle \(c_0\cdots c_5\). The two pure paths meet it only at \(c_1\) and \(c_4\), respectively; their union with \(L\) is unicyclic. The opposite paths indeed pair \(e\)--\(a:\Sigma\) and \(h_2\)--\(h_1\), giving the allowed \(ab\) switch rather than \(ac\). This pole has no \(ac\) template row and is not exact Case XII. The theorem does not decide whether two nonempty load sets can be disjoint under complete exact-Case-XII support, nor does it settle Berge--Fulkerson. The argument is analytic and has not had independent verification.
