> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fifth-line Hamilton rows leave two labelled port phases

Use the Hamilton three-spoke exterior of [Note 446](446-the-hamilton-three-spoke-forbidden-pair-has-twelve-marked-switch-signatures.md), with tree \(1-u_1-2-u_2-3-u_3-4-u_4-5-u_5-6\) and marks \((X,Y,Z,W)=(14,15,26,36)\). A genuine required row has complete matching occurrences
\[
P=eX,\quad R=eY,\quad K=Y,\quad J=X,\quad a=e,\quad b=e,
\qquad \Lambda=\{J,a,b\}.
\tag{1}
\]
Here \(P\) is rooted at \(1\), \(R\) at \(5\), and \(K\) takes marked halves \(X:1,Z:6,W:3\), as in the fifth line of Note 446(3). The choice \(K:2u_1,4u_3,5u_5\) is already excluded by [Notes 451](451-two-end-port-phases-force-forbidden-rows-in-the-hamilton-prism.md) and [453](453-the-crossed-hamilton-port-row-forces-a-forbidden-loop.md). This note treats the other three choices. At a tree subdivision the slots below are first-end half, second-end half, port; at a marked subdivision they are terminal and the two marked halves in the orders \(X:(1,4),Y:(1,5),Z:(2,6),W:(3,6)\). Juxtaposition means an unordered pair of occurrences.

## Choice \(K:2u_2,4u_3,5u_5\): always \([eX]\)

The original row's port pairs necessarily have the form
\[
(p_1,p_2,p_3,p_4,p_5)
=(K\sigma,\Lambda\setminus\{\beta\},\Lambda\setminus\{\gamma\},
K\upsilon,\Lambda\setminus\{\eta\}),\qquad e=ab,
\tag{2}
\]
where
\[
\{\lambda,\beta,\gamma\}
=\{\delta,\lambda,\sigma\}
=\{\delta,\tau,\eta\}=\Lambda,
\qquad \{\tau,\upsilon\}=\{a,b\}.
\tag{3}
\]
To see the only nonlocal equality in (3), the old \(K\)-half at \(W:3\) and the old one at \(Z:6\) carry the same second label \(\lambda\): vertex \(6\) makes the complementary \(W:6,Z:2\) pairs equal. The old halves at vertices \(1,3,5\) then give the three displayed partitions. In particular (2)--(3) are necessary for *every* full row with this tree-half choice, regardless of its shore.

Keeping each occurrence's complete shore restriction, replace its exterior restriction by
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(R\delta,P\lambda,K\sigma)
 &(RK,P\beta,\Lambda\setminus\{\beta\})
 &(R\gamma,PK,\Lambda\setminus\{\gamma\})
 &(J\tau,PR,K\upsilon)
 &(K\eta,PR,\Lambda\setminus\{\eta\})
\end{array}                                                     \tag{4}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,P\tau,R\upsilon)
 &(PR,K\eta,\Lambda\setminus\{\eta\})
 &(PR,\Lambda\setminus\{\lambda\},K\lambda)
 &(PR,K\lambda,\Lambda\setminus\{\lambda\}).
\end{array}                                                     \tag{5}
\]
The original prism vertices see, respectively,
\[
(R\delta,P\tau,K\eta),\ (P\lambda,RK,\Lambda\setminus\{\lambda\}),\ 
(P\beta,R\gamma,K\lambda),\ (PK,J\tau,R\upsilon),\
(PR,K\eta,\Lambda\setminus\{\eta\}),\
(PR,K\lambda,\Lambda\setminus\{\lambda\}).
\tag{6}
\]
Equations (3) make every triple in (4)--(6) a partition of the six labels. The port column remains (2), whereas the marked terminal pairs are \(KJ,PR,PR,PR\). Thus the new genuine BF row has forbidden type \([eX]\).

## Choice \(K:2u_2,4u_4,5u_5\): always forbidden

For the original row write
\[
(p_1,p_2,p_3,p_4,p_5)
=(K\sigma,\Lambda\setminus\{\beta\},K\lambda,
\Lambda\setminus\{\tau\},\Lambda\setminus\{\eta\}),\qquad e=ab.
\tag{7}
\]
The old exterior partitions force
\[
\{\gamma,\lambda\}=\{a,b\},\qquad
\{\beta,\mu,\gamma\}
=\{\delta,\mu,\sigma\}
=\{\delta,\tau,\eta\}=\Lambda.
\tag{8}
\]
Here \(K\mu\) occurs on both \(W:3\) and \(Z:6\). At vertex \(4\), the old \(X:4=ab\) and \(u_4:4=RK\) force \(u_3:4=PJ\), so the other labels at \(u_3\) are \(\gamma,\lambda=a,b\). The other equalities follow at vertices \(1,2,3,5\).

If \(\tau\in\{a,b\}\), put \(\upsilon=\{a,b\}\setminus\{\tau\}\). An \([eX]\) recompletion is
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(R\delta,P\mu,K\sigma)
 &(RK,P\beta,\Lambda\setminus\{\beta\})
 &(R\gamma,PJ,K\lambda)
 &(K\tau,PR,\Lambda\setminus\{\tau\})
 &(K\eta,PR,\Lambda\setminus\{\eta\})
\end{array}                                                     \tag{9}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,P\tau,R\upsilon)
 &(PR,K\eta,\Lambda\setminus\{\eta\})
 &(PR,\Lambda\setminus\{\mu\},K\mu)
 &(PR,K\mu,\Lambda\setminus\{\mu\}).
\end{array}                                                     \tag{10}
\]
At vertices \(1,\ldots,6\), the incident triples are
\[
(R\delta,P\tau,K\eta),\ (P\mu,RK,\Lambda\setminus\{\mu\}),\
(P\beta,R\gamma,K\mu),\ (PJ,K\tau,R\upsilon),\
(PR,K\eta,\Lambda\setminus\{\eta\}),\
(PR,K\mu,\Lambda\setminus\{\mu\}).
\tag{11}
\]
They partition the labels by (8), as do (9)--(10).

If \(\tau=J\), then \(\delta,\eta\) are the two \(e\)-singleton occurrences. If \(\beta=\lambda\), (8) gives \(\mu=J\) and \(\sigma=\eta\). In this case another \([eX]\) recompletion is
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(J\delta,PR,K\eta)&(K\lambda,PR,J\gamma)
 &(J\gamma,PR,K\lambda)&(KJ,PR,ab)&(K\eta,PR,J\delta)
\end{array}                                                     \tag{12}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,PR,ab)&(PR,K\eta,J\delta)
 &(PR,J\gamma,K\lambda)&(PR,K\lambda,J\gamma).
\end{array}                                                     \tag{13}
\]
The original vertices see \((J\delta,PR,K\eta),(PR,K\lambda,J\gamma),
(PR,J\gamma,K\lambda),(PR,KJ,ab),(PR,K\eta,J\delta),
(PR,K\lambda,J\gamma)\), each a partition.

The only remaining possibility in this tree-half choice is \(\tau=\beta=J\). Now (8) forces \(\delta=\gamma\), \(\mu=\eta=\lambda\), and \(\sigma=J\). Rename \(\gamma=a,\lambda=b\). Its port pairs reduce to
\[
(p_1,p_2,p_3,p_4,p_5)=(KJ,ab,Kb,ab,Ja),\qquad e=ab.
\tag{14}
\]
This time the following exterior row has forbidden type \((eX)(eW)\):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(PR,ab,KJ)&(PR,KJ,ab)&(PR,Ja,Kb)
 &(RK,PJ,ab)&(Rb,PK,Ja)
\end{array}                                                     \tag{15}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(RJ,Ka,Pb)&(PR,Jb,Ka)&(PR,KJ,ab)&(PK,ab,RJ).
\end{array}                                                     \tag{16}
\]
At vertices \(1,\ldots,6\), the triples are
\[
(PR,Ka,Jb),\ (ab,PR,KJ),\ (KJ,PR,ab),\
(Ja,RK,Pb),\ (PJ,Rb,Ka),\ (PK,ab,RJ).
\tag{17}
\]
Again every subdivision and original-vertex triple partitions the labels. The terminal pairs are \(RJ,PR,PR,PK\), so \(P=eX,R=eW,K=W,J=X,a=b=e\), as required.

## Choice \(K:2u_1,4u_4,5u_5\): one sharply specified remainder

The old port pairs have the form
\[
(p_1,p_2,p_3,p_4,p_5)
=(\Lambda\setminus\{\delta\},K\gamma,K\lambda,
\Lambda\setminus\{\tau\},\Lambda\setminus\{\eta\}),\qquad e=ab,
\tag{18}
\]
where \(\{\gamma,\lambda\}=\{a,b\}\) and
\(\{\delta,\tau,\eta\}=\Lambda\). Indeed the old \(X:4=ab\) forces \(u_3:4=PJ\); the equal second labels at \(W:3,Z:6\) then force \(p_2=K\gamma\).

If \(\tau\in\{a,b\}\), let \(\upsilon\) be the other \(e\)-singleton. The following \([eX]\) row retains (18):
\[
\begin{array}{c|ccccc}
 &u_1&u_2&u_3&u_4&u_5\\ \hline
 &(R\delta,PK,\Lambda\setminus\{\delta\})
 &(RJ,P\lambda,K\gamma)
 &(R\gamma,PJ,K\lambda)
 &(K\tau,PR,\Lambda\setminus\{\tau\})
 &(K\eta,PR,\Lambda\setminus\{\eta\})
\end{array}                                                     \tag{19}
\]
\[
\begin{array}{c|cccc}
 &t_X&t_Y&t_Z&t_W\\ \hline
 &(KJ,P\tau,R\upsilon)
 &(PR,K\eta,\Lambda\setminus\{\eta\})
 &(PR,ab,KJ)&(PR,KJ,ab).
\end{array}                                                     \tag{20}
\]
The six original-vertex triples are
\[
(R\delta,P\tau,K\eta),\ (PK,RJ,ab),\
(P\lambda,R\gamma,KJ),\ (PJ,K\tau,R\upsilon),\
(PR,K\eta,\Lambda\setminus\{\eta\}),\ (PR,KJ,ab).
\tag{21}
\]
All partition by the two equalities following (18).

For \(\tau=J\), rename \(\gamma=a,\lambda=b\). Equation (18) then leaves precisely two labelled port forms:
\[
(Jb,Ka,Kb,ab,Ja)
\quad\text{or}\quad
(Ja,Ka,Kb,ab,Jb),\qquad e=ab.
\tag{22}
\]
This note does not exclude (22) under exact Case XII. It proves that the other three fifth-line tree-half choices, and every \(\tau\ne J\) phase of the fourth, force forbidden full rows. Each recompletion above retains **each of the six possibly different complete shore matchings**, because its five proper-port pairs and its terminal \(e=ab\) are unchanged label by label. Consequently the conclusion is independent of shore order and topology. The two sixth-line signatures of Note 446(3), (22), other forbidden pairs, and the full Berge--Fulkerson conjecture remain open. These are hand-derived certificates awaiting independent review; no OMEN or local mathematical recomputation was used. \(\square\)

Later result: [Note 457](457-the-last-five-hamilton-port-profiles-force-a-forbidden-double-triple.md) excludes both profiles (22) by shore-preserving \((eX)(eW)\) recompletion.
