> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-carrier orientation excludes the central \(e\)-minority placement

Continue [Note 279](279-forbidden-triples-restrict-one-edge-near-bipartite-central-shores.md) in the actual central-path exterior and fixed allowed pentagon \(S=e-a-b-d-c-e\). Let \(E=e,A=a:\Sigma,I=h_1,D=h_2,H=h_3,J=h_4\) be the six shore ports. Assume deleting one shore-internal edge \(g\) makes the six-port shore bipartite, and both required exact-Case-XII rows exist with their forced exterior masks.

**Theorem.** The balanced placement with \(E\) as the unique \(B\)-side port among \(E,A,I,D\) is impossible. Combined with Notes 278–279, a surviving one-edge-near-bipartite six-port shore must have one of only two port-side placements:
\[
\begin{array}{c|c}
B\cap\{E,A,I,D\}&B\cap\{H,J\}\\\hline
\{A\}&\{H\}\\
\{D\}&\{J\}.
\end{array}                                                     \tag{1}
\]
Here \(B\) contains both ends of \(g\). The theorem does not assert that either remaining placement is realizable or that the four-slot load spectra intersect.

## Proof

Suppose \(E\in B\), while \(A,I,D\) lie in the opposite shore side \(R\). The two singleton-\(a\) shore ports \(H,J\) are on opposite sides by Note 278. Let \(f\in\{h_3,h_4\}\) be the proper cut edge based at the \(B\)-side one. Colour the common exterior endpoints of the five proper shore interfaces by \(B\). Then the full five-pole minus \(\{g,f\}\) is bipartite, both exceptional edges lie inside \(B\), and **all five terminal vertices lie in \(B\)**: \(t_e=E\) is in the shore, while \(t_a,t_b,t_c,t_d\) lie on the exterior side of the proper interfaces.

If \(g,f\) share a vertex, [Note 126](126-adjacent-two-edge-bipartization-is-impossible-in-case-xii.md) already contradicts exact support. Otherwise they are disjoint, so the same-side \(5+0\) fixed-carrier orientation theorem of [Note 133](133-same-side-five-zero-carrier-orientations-balance-bc-projections.md) applies.

Take the required real \((ea)(ad)\) row in [Note 272's forced table](272-the-two-central-path-cross-rows-share-one-pure-exterior.md), and fix its complete half-loads
\[
\mathcal A=X_a+Y_a+Z_e,
\qquad \mathcal R=U_{ad}+V_a+W_d,
\qquad \mathcal A+\mathcal R=2\mathbf1.                  \tag{2}
\]
The \(ea\) state is in \(S\), and the \(ad\) state is in \(T\). By Note 278's balanced balance equation, the zero-port triple \(X_a\) avoids \(g\), the singleton-\(a\) \(Y_a\) with ports \(HJ\) avoids \(g\), and the singleton-\(e\) \(Z_e\) with ports \(EAID\) uses \(g\). The proper edge \(f\) is selected by \(Y_a\) and avoided by \(X_a,Z_e\). Thus
\[
\mathcal A(g)=\mathcal A(f)=1,
\qquad
(Y_a(g),Y_a(f))=(0,1),
\qquad
(Z_e(g),Z_e(f))=(1,0).                              \tag{3}
\]

Note 133 now gives a second decomposition of **the same complete** \(\mathcal A\), at the **same** state \(ea\), with the complete three matchings of \(\mathcal R\) fixed and the singleton profiles in (3) reversed. It would be another real \((ea)(ad)\) BF row whose singleton-\(a\) matching uses \(g\).

But Note 272 proves that *every* real \((ea)(ad)\) row in this central-path profile has the same singleton-\(a\) exterior mask \(Y_L\), hence shore ports \(H,J\). Those ports lie on opposite sides of the balanced shore. The shore balance equation
\[
\nu_B(M)-\nu_R(M)=|B|-|R|-2\mathbf1_{g\in M}
\]
therefore gives \(\mathbf1_{g\in M}=0\) for **every** such singleton-\(a\) matching. The reversed row is impossible. This excludes both choices \(f=h_3,h_4\) and proves (1). \(\square\)

The contradiction uses a full matching carrier: Note 133 changes complete matching masks while retaining the half-load \(\mathcal A\), the opposite half \(\mathcal R\), and their BF cover. Mere flexibility of the complete singleton-\(a\) class, without that fixed carrier, would not contradict Note 272's prescribed row mask.

The two remaining placements in (1) each make the full pole bipartite after deleting three proper edges: \(\{g,a:\Sigma,h_3\}\) in the \(A,H\) case, or \(\{g,h_2,h_4\}\) in the \(D,J\) case. The deletion statement is only an odd-cycle transversal bound. It neither excludes these cases nor supplies the central four-slot load intersection. This hand proof depends on the upstream forced exterior tables and fixed-carrier theorem, both of which still need independent verification.
