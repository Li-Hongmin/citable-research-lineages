> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A mixed-side right BF cell forces an S-Tait colouring

The Tait-empty branch left by [Notes 129](129-exact-negative-support-transfers-a-class-four-matching-inside-the-right-seed-row.md), [130](130-the-mixed-side-right-row-exceptional-class-three-forces-an-s-tait-state.md), and the cross-half reduction in [Note 131](131-cross-half-triple-switch-reduces-the-common-bc-seed-to-a-terminal-path.md) is impossible. The proof uses the *complete* negative BF support, but only one positive cell. It works at every order and makes no minimum-host or all-terminal exclusion.

## Theorem

Let \(H\) be a cubic five-pole with no \(T\)-loop and no \(T\)--\(T\) BF type, where
\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]
Suppose two disjoint proper edges \(e,f\) make \(H-\{e,f\}\) bipartite, with four terminal positions in \(X\), terminal \(2\) alone in \(Y\), \(e\subset X\), and \(f\subset Y\). If actual complete perfect matchings give even one BF row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1,                 \tag{1}
\]
then \(H\) has an actual \(S\)-Tait colouring. Consequently its Tait-state set is all of \(S\).

**Proof.** The absence of \(T\)-loops excludes every \(T\)-Tait state. The mixed-side profile table of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md) gives
\[
q_{25}|_{e,f}=(0,1),\quad B_2|_{e,f}=(1,0),\quad
r_{34}|_{e,f}=(0,0).
\]
The last equality follows because a \(T\)-triple missing \(34\) with profile \((1,1)\) would extend to a forbidden \(T\)-Tait colouring. For an \(X\)-singleton \(U\), write \(h(U)\) for its common \(e,f\)-bit. The load-two equation is
\[
h(D_5)+h(Y_3)+h(C_4)=1.                                   \tag{2}
\]
If \(h(Y_3)=1\), Note 130 already gives an \(S\)-Tait state. Hence assume \(h(Y_3)=0\). The fixed-\(B_2,Y_3,r_{34}\) involution of Note 129 now supplies a row of the same form as (1) with
\[
h(C_4)=0,\qquad h(D_5)=1,\qquad h(Y_3)=0.                 \tag{3}
\]
Rename its matching occurrences as in (1). Its complementary half-loads
\[
A=q_{25}+B_2+D_5,\qquad R=r_{34}+Y_3+C_4
\]
have exceptional-edge loads
\[
A(e)=A(f)=2,\qquad R(e)=R(f)=0.                            \tag{4}
\]
The fixed \(R\) has state \(34\in T\), while \(A\) has state \(25\in S\). If \(A\) admitted any \(T\)-state, combining that decomposition with the fixed \(R\) would give a forbidden \(T\)-loop or \(T\)--\(T\) row. The half-load saturation theorem of [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) therefore gives a state-\(35\) decomposition
\[
A=Q_{35}+P_3+P_5.                                          \tag{5}
\]
The triple \(Q_{35}\) has an \(XX\)-missing boundary. If its profile is \((1,1)\), then \(H-Q_{35}\) is bipartite with an even terminal path and already gives an \(S\)-Tait colouring. In the remaining case it has profile \((0,0)\). Equation (4) then forces **both complete singleton matchings** \(P_3,P_5\) in (5) to have profile \((1,1)\).

The class-three occurrence \(Y_3\) in \(R\) has profile \((0,0)\). Exchange the actual complete occurrences \(P_3\) and \(Y_3\) between the two halves. This leaves the full BF load unchanged and gives
\[
A'=Q_{35}+Y_3+P_5,\qquad R'=r_{34}+P_3+C_4,\qquad
A'+R'=2\mathbf1.                                         \tag{6}
\]
Here \(A'\) has an \(S\)-state \(35\), \(R'\) has the \(T\)-state \(34\), and the *class-three singleton in \(R'\)* uses both \(e,f\). Again the negative BF support forces \(\mathcal R(A')=S\). Decompose \(A'\) at state \(25\) while retaining the three complete matchings of \(R'\). The resulting row has exactly the hypotheses of Note 130, with its class-three occurrence equal to the complete mask \(P_3\). Note 130 yields an actual state-\(14\) Tait colouring. \(\square\)

In the final branch, the resulting state-\(25\) row can be written explicitly as
\[
q'_{25}+B'_2+D'_5+r_{34}+P_3+C_4=2\mathbf1,
\quad
(q'_{25},B'_2,D'_5,r_{34},P_3,C_4)|_{e,f}
=((0,1),(1,0),(0,0),(0,0),(1,1),(0,0)).          \tag{7}
\]
The unchanged \(r_{34},P_3,C_4\) are complete matching masks from (6), not boundary-type substitutes. Finally, no \(T\)-Tait state can occur because its doubled colouring would be a forbidden \(T\)-loop; the usual bichromatic terminal-path switches carry any one \(S\)-Tait state around the \(S\)-pentagon. This proves that the Tait-state set is exactly \(S\).

## Exact-Case-XII consequence and boundary

The original Case-XII support in Máčajová--Mazzuoccolo--Tabarelli, *Ars Mathematica Contemporanea* 26 (2026), DOI 10.26493/1855-3974.3409.c13, contains the \((25)(34)\) cell. An \(S/T\)-preserving dihedral relabelling sends any mixed-side minority terminal to position 2. Thus **a genuine exact-Case-XII pole with a mixed-side two-edge bipartization cannot be Tait-empty**; if such a pole exists, its Tait-state set is all of \(S\). Together with [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md), the same conclusion holds for the same-side \(2+3\) branch. Among the two-edge-bipartizable cases classified there, a Tait-empty exact-Case-XII pole can only lie in the same-side \(5+0\) branch.

This theorem also rules out the \(5\leftrightarrow4\) mixed-side Tait-empty alternative in Note 131. It does **not** show that an \(S\)-Tait mixed-side pole has the common complete \(B_2,C_4\) seed, and it does not exclude the same-side \(5+0\) Tait-empty branch. No exact-Case-XII realization, Berge--Fulkerson proof, or counterexample follows from this conditional classification alone.
