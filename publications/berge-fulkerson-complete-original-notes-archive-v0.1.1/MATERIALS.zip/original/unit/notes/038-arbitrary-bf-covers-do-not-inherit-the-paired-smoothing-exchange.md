> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Arbitrary BF covers do not inherit the paired-smoothing exchange

The bichromatic-path argument of
[Note 037](037-bichromatic-path-exchange-repairs-doubled-tait-paired-smoothings.md)
does not extend cover by cover from doubled-Tait colourings to arbitrary BF
covers.  A single exchange between two matching occurrences is always
insufficient, and the minimum two-exchange repair requires additional
route conditions that are not consequences of the BF double-cover
equations.

Let

\[
H_0=K+ac+bd,
\qquad
H_1=K+ad+bc,
\]

and let \(M_1,\ldots,M_6\) be a BF cover of \(H_0\).  Write

\[
F=\{i:ac\in M_i\},
\qquad
G=\{i:bd\in M_i\}.
\]

Both \(F\) and \(G\) have size two.  If \(P_i=M_i\cap E(K)\), let
\(S_i\subseteq\{a,b,c,d\}\) be the set of ports uncovered by \(P_i\).
Then

\[
S_i=
\begin{cases}
\{a,b,c,d\},&i\in F\cap G,\\
\{a,c\},&i\in F\setminus G,\\
\{b,d\},&i\in G\setminus F,\\
\varnothing,&i\notin F\cup G.
\end{cases}
\]

If a path component of \(P_i\mathbin{\triangle}P_j\) has endpoint set
\(X\), exchanging the two matching occurrences along that path replaces
their exposure sets by

\[
S_i\mathbin{\triangle}X,
\qquad
S_j\mathbin{\triangle}X.
\]

All edge multiplicities in \(K\) remain unchanged.  A BF cover of \(H_1\)
whose new-edge labels are disjoint must have exactly two exposure sets
\(ad\), two exposure sets \(bc\), and two empty exposure sets.

## At least four occurrences must change

Put \(q=|F\cap G|\).  If \(q=2\), the initial exposure multiset is

\[
2(abcd)+4(\varnothing).
\]

The two \(abcd\) occurrences must change, while two initially empty
occurrences must become nonempty.  If \(q=1\), the initial multiset is

\[
abcd+ac+bd+3(\varnothing).
\]

The first three occurrences are incompatible with \(H_1\), and at least
one empty occurrence must become nonempty.  Thus in either case every
disjoint-label repair changes at least four matching occurrences.  In
particular, exchanging a single pair of occurrences can never generalize
the Note 037 construction.

## Exact route conditions for a minimum repair

First suppose \(q=2\).  Put

\[
C=F=G,
\qquad
N=[6]\setminus C.
\]

Form a bipartite route graph on \(C\sqcup N\), joining \(i\in C\) to
\(j\in N\) when the port paths of
\(P_i\mathbin{\triangle}P_j\) are routed as

\[
ad\mid bc.
\]

There is a repair by two occurrence-disjoint path-component exchanges if
and only if this route graph has a matching saturating the two elements of
\(C\).  For each matched pair, switching either cross path converts its
\((abcd,\varnothing)\) exposure pair into one \(ad\) exposure and one
\(bc\) exposure.  Conversely, a minimum repair must pair each of the two
\(abcd\) occurrences with a distinct empty occurrence, and the displayed
cross routing is then necessary.

Now suppose \(q=1\), and write

\[
F\cap G=\{\alpha\},
\qquad
F\setminus G=\{x\},
\qquad
G\setminus F=\{y\},
\qquad
N=[6]\setminus(F\cup G).
\]

Let \(\rho_{ij}\) denote the pairing of the four port endpoints in
\(P_i\mathbin{\triangle}P_j\).  A repair by two occurrence-disjoint
path-component exchanges exists if and only if

\[
\rho_{xy}=ab\mid cd
\]

and there is some \(n\in N\) such that

\[
\rho_{\alpha n}=ad\mid bc.
\]

Indeed, switching an \(ad\)-path for \((\alpha,n)\) changes
\((abcd,\varnothing)\) into \((bc,ad)\).  Switching an \(ab\)-path for
\((x,y)\) changes \((ac,bd)\) into \((bc,ad)\).  These two exchanges
therefore leave two occurrences exposed at \(ad\), two at \(bc\), and two
at no port.  Conversely, in a two-exchange repair the \(abcd\) occurrence
must pair with an empty occurrence, while the \(ac\) and \(bd\)
occurrences must pair with one another; the two displayed routes are
forced.

These are exact conditions for the minimum two-component-exchange repair.
They are sufficient for arbitrary BF covers but are not automatic.

## A minimum six-vertex countermodel

Take

\[
H_0=K_{3,3}
\]

with bipartition

\[
\{0,1,2\}\sqcup\{3,4,5\},
\]

and use each of its six distinct perfect matchings once:

\[
\begin{aligned}
M_0&=\{03,14,25\},&
M_1&=\{03,15,24\},\\
M_2&=\{04,13,25\},&
M_3&=\{04,15,23\},\\
M_4&=\{05,13,24\},&
M_5&=\{05,14,23\}.
\end{aligned}
\]

Every edge of \(K_{3,3}\) occurs in exactly two of these matchings, so they
form a BF cover.  Set

\[
a=0,\qquad b=4,\qquad c=3,\qquad d=1.
\]

Then

\[
ac=03,
\qquad
bd=14,
\qquad
ad=01,
\qquad
bc=34.
\]

The two alternative edges are absent from \(K_{3,3}\), and replacing
\(03,14\) by \(01,34\) gives the triangular prism \(H_1\).  For the
displayed BF cover,

\[
F(ac)=\{0,1\},
\qquad
G(bd)=\{0,5\}.
\]

Thus \(\alpha=0\), \(x=1\), \(y=5\), and \(N=\{2,3,4\}\).  Removing
\(ac,bd\) from the relevant symmetric differences gives

\[
\rho_{xy}=ad\mid bc,
\qquad
\rho_{\alpha n}=ab\mid cd
\quad\text{for every }n\in N.
\]

Both necessary \(q=1\) route conditions fail simultaneously.

The failure cannot be repaired by choosing another BF cover of \(H_1\).
The triangular prism has precisely the four perfect matchings

\[
\begin{aligned}
Q_0&=\{01,25,34\},&
Q_1&=\{04,13,25\},\\
Q_2&=\{04,15,23\},&
Q_3&=\{05,13,24\}.
\end{aligned}
\]

The edges \(01\), \(15\), and \(05\) force the multiplicities of
\(Q_0,Q_2,Q_3\), respectively, to equal two in any BF cover.  All other
edge equations then force the multiplicity of \(Q_1\) to be zero.
Consequently the unique unordered BF-cover multiset is

\[
\{Q_0,Q_0,Q_2,Q_2,Q_3,Q_3\}.
\]

Both new edges \(01,34\) lie in the two occurrences of \(Q_0\), so their
labels are identical and \(q=2\).  No BF cover of \(H_1\) gives them
disjoint labels.

This is the first possible order for a simple cubic paired-smoothing
example.  At order four the only simple cubic graph is \(K_4\), in which
both alternative cross edges already exist.  Hence a simple alternative
smoothing cannot occur before order six.

## Scope

The countermodel refutes only the per-cover transport claim:

> an arbitrary specified BF cover of \(H_0\) with intersecting labels on
> \(ac,bd\) must yield a disjoint-label BF cover of \(H_1\).

It does not refute the paired-smoothing assertion that at least one of
\(H_0,H_1\) is flexible.  The same \(K_{3,3}\) has another BF cover with
\(q=0\) on \(ac,bd\), as well as covers with \(q=1\) and \(q=2\).
Therefore the example closes the direct cover-by-cover extension of
Note 037, not the general paired-smoothing route.

The fixed-object verifier is
[general_bf_paired_smoothing_boundary.py](../scratch/worker-verify/general_bf_paired_smoothing_boundary.py).
It terminates with
\(\texttt{GENERAL\_BF\_PAIRED\_SMOOTHING\_BOUNDARY\_OK}\).
