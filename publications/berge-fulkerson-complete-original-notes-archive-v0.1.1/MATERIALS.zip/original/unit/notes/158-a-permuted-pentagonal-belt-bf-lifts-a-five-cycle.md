> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A permuted pentagonal belt BF-lifts a five-cycle

This note gives a local reduction for a minimum Berge--Fulkerson counterexample. It applies to **every** permutation between the two pentagons. In particular, the five marked edges of the core in [Note 123](123-exact-case-xii-terminal-vertices-are-independent.md) cannot form a 5-cycle in genuine minimum-host Case XII. The argument uses full six-matching boundary colourings, not selected matching identities. It is an analytic proof awaiting independent checking; it does not exclude marked triangles or 4-cycles, and it does not settle the remaining exact-Case-XII closure problem.

## The belt and its replacement

Index the inner vertices and edges modulo 5. Let \(B_\pi\) be a cubic five-pole with vertices \(v_i,t_i,r_j\), proper edges
\[
v_it_i,\quad t_iv_{i+1},\quad t_ir_{\pi(i)},\quad r_jr_{j+1}
\qquad(i,j\in\mathbb Z_5),                                      \tag{1}
\]
and one exterior semiedge \(h_i\) at each \(v_i\). Here \(\pi\) is an arbitrary permutation of \(\mathbb Z_5\). Let \(Q\) be the ordinary 5-cycle on \(v_0,\ldots,v_4\), with the same exterior semiedges \(h_i\).

**Belt lifting lemma.** Every labelled six-perfect-matching BF colouring of \(Q\) extends, with exactly the same six labels on all \(h_i\), to a BF colouring of \(B_\pi\), for every \(\pi\).

The published five-cycle boundary list is the five loops and ten pairs of missing-pair states on its adjacent-pair pentagon, together with the all-terminal type [Máčajová--Mazzuoccolo--Tabarelli (2026), Case I--XII \(R^*\) appendix](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). A boundary type fixes the multiset of the six complete semiedge subsets, up to a permutation of the six matching labels. Thus it suffices to construct all adjacent-pair Tait states of \(B_\pi\), whose doubled or paired colourings give those fifteen types, and one all-terminal BF colouring.

## Every inner adjacent-pair Tait state lifts

Prescribe colours \(A,B,C,C,C\) on \(h_0,h_1,h_2,h_3,h_4\). At \(v_i\), write \(b_i\) for the colour of \(v_it_{i-1}\) and \(a_i\) for that of \(v_it_i\). The following three assignments give the displayed colours \(c_i\) on the spokes \(t_ir_{\pi(i)}\):

| \((c_0,c_1,c_2,c_3,c_4)\) | \((b_0,a_0)\) | \((b_1,a_1)\) | \((b_i,a_i),\ i=2,3,4\) |
|---|---|---|---|
| \((B,A,C,C,C)\) | \((B,C)\) | \((A,C)\) | \((B,A)\) |
| \((A,C,C,C,B)\) | \((C,B)\) | \((C,A)\) | \((B,A)\) |
| \((C,A,C,C,B)\) | \((C,B)\) | \((A,C)\) | \((B,A)\) |

At each \(v_i\), the two table entries and its prescribed exterior colour are distinct. At each \(t_i\), \(a_i,b_{i+1},c_i\) are distinct. The three available lonely-colour pairs on the spokes are therefore \(\{0,1\},\{0,4\},\{1,4\}\). Any three vertices of the outer 5-cycle contain two adjacent vertices, since its independence number is two. Hence at least one of these three pairs is adjacent among \(r_{\pi(0)},r_{\pi(1)},r_{\pi(4)}\). Choose its table row. A 5-cycle with consecutive dangling colours \(A,B,C,C,C\) has cyclic edge colours \(C,A,B,A,B\), so the chosen spoke colours extend over all outer edges \(r_jr_{j+1}\).

Rotating the inner indices gives a three-edge-colouring of \(B_\pi\) for each of the five adjacent-pair states of \(Q\). Combining the three perfect matchings from any two such colourings gives a BF colouring for each adjacent-pair pair type; combining a colouring with itself gives its loop type. The two colourings may be chosen independently because their three matching labels are disjoint occurrence slots.

## The all-terminal colouring

Let \(W\) use all five \(h_i\) and all five spokes \(t_ir_{\pi(i)}\). Let \(N_0\) use
\[
h_0,\quad v_1t_0,\ v_2t_1,\ v_3t_3,\ v_4t_4,\quad
t_2r_{\pi(2)},                                                    \tag{2}
\]
and the unique two-edge perfect matching of the outer 5-cycle after deleting \(r_{\pi(2)}\). Define \(N_i\) by rotating only the **inner** indices in (2) by \(i\); its spoke is \(t_{i+2}r_{\pi(i+2)}\), and its two outer edges are the unique matching after deleting that outer vertex. Each \(N_i\) is a perfect matching of the five-pole with singleton boundary \(\{i\}\).

The six matchings \(W,N_0,\ldots,N_4\) cover every edge exactly twice. Each \(h_i\) belongs to \(W,N_i\); each spoke belongs to \(W\) and one \(N_i\). The five rotations use each forward inner half-edge \(v_it_i\) twice and each backward half-edge \(v_it_{i-1}\) twice. Finally, each outer 5-cycle edge belongs to exactly two of the five unique matchings obtained by deleting one outer vertex: cyclic symmetry and the ten total edge occurrences prove this. This constructs the all-terminal type without any assumption on \(\pi\), and completes the belt lifting lemma.

## Excluding a fully marked pentagon in minimum-host Case XII

Let \(G\) be a minimum counterexample with a genuine Case-XII 5-cut, and let \(J\) be its simple 3-edge-connected cubic marked core from Note 123. Suppose all five marked edges form a 5-cycle \(C=v_0v_1v_2v_3v_4v_0\).

First, \(C\) is induced. Two chords would use the sole remaining degree at four cycle vertices and leave a cut of size one, contrary to 3-edge-connectivity. If there is one chord, it uses the sole remaining degree at its endpoints, so \(|\delta_J(V(C))|=3\). By 3-edge-connectivity, the complementary vertices form one connected component. If it contains a cycle, the complementary marked-cut inequality (5) of Note 123 says \(3+0\ge5\), a contradiction. If it is acyclic, the cubic tree identity \(|V|=|\delta|-2\) makes it a single vertex \(w\). Rotate indices so the chord is \(v_0v_2\); then the unmarked subgraph \(F\) consists of this chord and the three spokes from \(v_1,v_3,v_4\) to \(w\). A triple-boundary matching with missing pair \(\{e_0,e_1\}\), where \(e_i=v_iv_{i+1}\), selects endpoints only from \(\{v_0,v_1,v_2\}\). Both \(v_3\) and \(v_4\) remain in \(F-A_\alpha\), each adjacent only to \(w\), so no deletion matching exists by [Note 157, (2)](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md). Exact Case XII realizes this missing-pair state, contradiction.

Since \(C\) is induced, its five vertices, the five subdivision vertices of its marked edges, and the opposite 5-cycle of the Case-XII cut form exactly \(B_\pi\) for some permutation \(\pi\). Their only edges to the rest of \(G\) are the five unmarked edges at the \(v_i\). Replace this 15-vertex belt by \(Q\), attaching those five edges at the corresponding \(v_i\). The resulting graph \(G'\) is cubic and has ten fewer vertices. It is bridgeless: deleting an edge outside the replacement separates \(G'\) only if it separated \(G\), since both the old belt and new 5-cycle connect all five ports; deleting an edge inside the new 5-cycle leaves that cycle connected.

Minimality gives a BF cover of \(G'\). Restrict its six labelled matchings to \(Q\), lift their complete boundary labels through the belt lifting lemma, and glue them to the unchanged matchings outside \(Q\). This produces a BF cover of \(G\), contradiction. Therefore
\[
\boxed{\text{The five marked core edges of a minimum-host exact-Case-XII pole cannot form a 5-cycle.}} \tag{3}
\]
Together with Note 157, the marked-edge subgraph has maximum degree two and **no five-edge cycle**. Shorter marked cycles and marked paths remain possible. The reduction does not establish the common \(B_2+C_4\) seed or exclude Case XII as a whole.
