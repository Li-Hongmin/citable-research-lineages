> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The adjacent \(a,b\) pair fails on the Hamilton-path \(K_{3,3}\) exterior

Use the five-point tree exterior of [Note 376](376-hamilton-k33-adjacent-ab-row-cannot-root-at-x.md):
\[
x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t,
\qquad a=xs,\quad b=xt,\quad c=yt,\quad d=zr,
\]
with proper shore ports \(p_0,\ldots,p_4\) at \(u_0,\ldots,u_4\). The mark \(e\) is internal to the arbitrary six-port shore. The two Case-XII pentagons with \(e\)-neighbour pair \(\{a,b\}\) are
\[
S_A=e-a-c-d-b-e,\qquad S_B=e-a-d-c-b-e.
\]
Both have \(ea,eb\in S\) and \(ab,ec,ed\in T\). By [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), a full exact-Case-XII pole must have a genuine \((ea)(ab)\) six-perfect-matching row and cannot have a double-\(T\) row.

**Theorem.** Neither pentagon can be the complete exact-Case-XII support of this exterior, at any shore order or cycle rank. By path reversal, the two pentagons with \(e\)-neighbour pair \(\{b,c\}\) are also excluded.

**Proof.** In a required \((ea)(ab)\) row, write \(P\) for its state-\(ea\) triple, \(R\) for its state-\(ab\) triple, \(E\) for singleton \(e\), \(B\) for singleton \(b\), and \(A_1,A_2\) for the two singleton-\(a\) occurrences. By [Notes 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), \(P\) has no proper shore port and is rooted at \(x\) or \(s\). [Note 376](376-hamilton-k33-adjacent-ab-row-cannot-root-at-x.md) excludes root \(x\). Thus \(P\) uses \(t_as\), terminals \(b,c,d\), and the tree edges
\[
xu_0,\quad ru_1,\quad yu_2,\quad zu_3,\quad tu_4.             \tag{1}
\]

Since \(R=ab\in T\), switching \(P\) with either \(A_j\) cannot produce an \(ec\) or \(ed\) triple: that would give a double-\(T\) row. Hence the alternating path starting at terminal \(a\) must end at \(b\), producing an \(eb\) triple. This path lies wholly outside the shore. Indeed, on a path starting with the singleton terminal edge, every visit to a tree subdivision vertex \(u_i\) arrives through the singleton edge and leaves through the zero-port triple edge; the triple never takes a shore port.

There are just two \(a\)--\(b\) paths from the root \(s\):
\[
L:a-t_a-s-u_2-y-u_1-r-u_0-x-t_b-b,
\qquad
J:a-t_a-s-u_3-z-u_4-t-t_b-b.                              \tag{2}
\]
A singleton \(A_j\) using \(L\) must select \(t_bx,t_ct,t_dz,ru_0,yu_1,su_2\) and ports \(p_3,p_4\). One using \(J\) must select \(t_bt,t_cy,t_dr,xu_0,su_3,zu_4\) and ports \(p_1,p_2\). These exterior restrictions follow by matching the remaining marked subdivision vertices and the six tree vertices; their shore restrictions remain arbitrary complete matchings.

If both \(A_j\) use \(J\), the edge \(xu_0\) belongs to \(P,A_1,A_2\), contradicting load two.

Suppose one \(A_j\) uses \(L\) and the other uses \(J\). At \(x\), \(P\) and \(A_J\) saturate \(xu_0\). The terminal edge \(b\) belongs to \(P,B\), while \(A_L\) uses \(t_bx\) and \(A_J\) uses \(t_bt\); thus \(R,E\) split the two remaining \(b\)-half slots. The remaining edge load at \(x\) forces \(B\) to use \(t_ax\). Switch \(P,A_J\) along \(J\). The new zero-port triple \(P_J\) has state \(eb\), is rooted at \(t\), and uses \(t_bt\) and \(zu_4,su_3,yu_2,ru_1,xu_0\). In \(P_J\triangle B\), start at terminal \(b\). If \(B\) uses \(t_ct\) at \(t\), the path ends at \(c\). Otherwise \(B\) uses \(tu_4\), so \(t_c\) is covered through \(y\). At \(z\), \(B\) cannot use \(zu_4\), since its edge \(tu_4\) already covers \(u_4\). If it uses \(t_dz\), the path ends at \(d\). Otherwise it uses \(zu_3\); because \(B\) uses \(t_ax\), it must then use \(su_2\) at \(s\), and the path reaches \(y\) and ends at \(c\). A second genuine matching switch therefore gives \(ec\) or \(ed\) beside the unchanged \(ab\) triple \(R\), a forbidden double-\(T\) row.

Finally suppose both \(A_j\) use \(L\). The terminal and mark-half loads force \(R,E\) onto \(t_bt\), \(E,B\) onto \(t_cy,t_dr\), and \(B\) onto \(tu_4\). At \(u_4\), \(P,B\) use \(tu_4\) and \(A_1,A_2\) use \(p_4\), so \(R,E\) use \(zu_4\). Then \(B\) must use \(zu_3\). At \(u_3\), \(P,B\) use \(zu_3\) and \(A_1,A_2\) use \(p_3\), so \(R,E\) use \(su_3\). At \(s\), this forces \(B\) onto \(t_as\); the \(a\)-half and \(x\)-edge loads then force \(B\) onto \(xu_0\). Switch \(P,A_1\) along \(L\), obtaining a zero-port \(eb\) triple \(P_L\) rooted at \(x\). Its alternating path with the original \(B\) is entirely exterior and follows
\[
b-t_b-x-u_0-r-t_d-d,
\]
since \(P_L\) uses \(t_bx,ru_0\) and \(B\) uses terminal \(b\), \(xu_0,t_dr\). The second switch produces \(ed\in T\) beside \(R=ab\in T\), again impossible. Every root-\(s\) row is excluded, completing the theorem with Note 376. \(\square\)

The path reversal \((x,r,y,s,z,t)\mapsto(t,z,s,y,r,x)\) exchanges \(a,c\) and fixes \(b,d\), so it carries \(\{a,b\}\) to \(\{b,c\}\). Together with Notes 374–375, ten of the twelve labelled pentagons on this Hamilton-path exterior are excluded; the two with \(e\)-neighbour pair \(\{a,c\}\) remain. This is a conditional classification inside the five-point tree exterior, not a proof of general exact Case XII or Berge–Fulkerson. The argument is hand-derived and awaits independent review; it uses no local mathematical recomputation.
