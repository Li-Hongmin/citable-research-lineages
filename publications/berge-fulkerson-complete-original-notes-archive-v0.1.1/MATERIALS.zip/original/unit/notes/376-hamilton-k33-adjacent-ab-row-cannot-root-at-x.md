> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An adjacent \(a,b\) Case-XII row cannot root at \(x\)

Retain the Hamilton-path \(K_{3,3}\) exterior of [Note 375](375-hamilton-k33-bd-neighbours-fail-by-a-second-exterior-switch.md): tree \(x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t\), shore ports \(p_0,\ldots,p_4\), and marks \(a=xs,b=xt,c=yt,d=zr\). The two pentagons whose \(e\)-neighbour pair is \(\{a,b\}\) are
\[
\begin{array}{c|c}
S_A=e-a-c-d-b-e&T_A=\{ec,ed,ab,ad,bc\},\\
S_B=e-a-d-c-b-e&T_B=\{ec,ed,ab,ac,bd\}.
\end{array}                                                   \tag{1}
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ab)\) row and forbids every double-\(T_i\) row for either pentagon.

**Root-exclusion theorem.** In any \((ea)(ab)\) row compatible with complete exact-Case-XII support (1), the zero-port state-\(ea\) triple must be rooted at \(s\). Root \(x\) is impossible for both pentagons, at every shore order and cycle rank.

**Proof.** Name the state-\(ea\) triple \(P\), state-\(ab\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(b\) matching \(B\), and singleton-\(a\) occurrences \(A_1,A_2\). [Note 230's shore quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [Note 358's rooted-tree rule](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md) give roots \(x,s\). Since \(R=ab\in T_i\), each \(a\)--\(b\) terminal path of \(P\triangle A_j\) must switch \(P\) from \(ea\) to \(eb\); alternatives \(ec,ed\) would give double-\(T_i\) rows. The path is wholly exterior by [Note 244's zero-port argument](244-every-shore-mark-must-neighbour-the-internal-mark.md).

Suppose \(P\) is rooted at \(x\). It selects \(t_ax\), terminals \(b,c,d\), and tree edges \(ru_0,yu_1,su_2,zu_3,tu_4\). Apart from the direct route
\[
D:a-t_a-x-t_b-b,                                  \tag{2}
\]
the only \(a\)--\(b\) route follows the whole tree path from \(x\) to \(t\). A singleton-\(a\) matching using that route has already matched both \(y,t\), the endpoints of mark \(c\), and cannot cover \(t_c\). Therefore both \(A_j\) use (2), saturating \(t_bx\). As \(P,B\) select terminal \(b\), the other \(b\)-half \(t_bt\) belongs to \(R,E\).

Switch \(P,A_1\) along (2), making a state-\(eb\) triple \(P'\) with the same complete shore matching \(Q=P|_Z\). The unchanged triple \(R=ab\) lies in \(T_i\). For \(S_A\), the original \(e\)-terminal path of \(P\triangle E\) must end at \(c\), while that of \(P'\triangle E\) must end at \(d\): these yield the only allowable states \(ac,bd\), respectively. For \(S_B\), the required endpoint change is \(d\) to \(c\), yielding \(ad,bc\).

We first show \(E\) uses the \(s\)-half \(t_as\) of mark \(a\). If \(E\) shared \(t_ax\) with \(P\), that edge would not belong to \(P\triangle E\). The exchange (2) changes \(P\) only at \(a,t_a,x,t_b,b\); the original \(c\)- and \(d\)-terminal components avoid these vertices, so their exterior legs and their shore pairings with \(E\) remain unchanged in \(P'\triangle E\). The \(e\)-path cannot change from \(c\) to \(d\) or from \(d\) to \(c\), a contradiction. Thus \(E\) selects \(t_as\).

Because \(R,E\) use \(t_bt\), \(E\) matches \(t\) through \(b\) and must select \(t_cy\). At \(x\) it can use neither mark \(a\) nor mark \(b\), so it selects \(xu_0\). Its remaining marked half at \(d\) and its tree edge at the opposite endpoint have exactly three possibilities: \((t_dz,ru_1)\), \((t_dr,zu_3)\), or \((t_dr,zu_4)\). The combination \((t_dz,ru_0)\) is impossible because \(E\) already uses \(xu_0\). Following the exterior terminal legs gives:

| \(E\)'s \(d\)-half and remaining tree edge | \(P\triangle E\): \(b,c,d\) | \(P'\triangle E\): \(a,c,d\) |
|---|---|---|
| \(t_dz,ru_1\) | \(p_4,p_2,p_3\) | \(p_2,p_4,p_3\) |
| \(t_dr,zu_3\) | \(p_4,p_1,p_2\) | \(p_2,p_1,p_4\) |
| \(t_dr,zu_4\) | \(p_3,p_1,p_2\) | \(p_2,p_1,p_3\) |

For \(S_A\), the old \(e\)-path ends at \(c\). The table makes the new path end at \(a\) in the first case, giving \(ab\in T_A\), or still at \(c\) in the other two cases, giving \(bc\in T_A\). For \(S_B\), the old \(e\)-path ends at \(d\). The first case leaves it at \(d\), giving \(bd\in T_B\); the other two move it to \(a\), giving \(ab\in T_B\). Each is forbidden beside \(R=ab\in T_i\). Thus root \(x\) is impossible. \(\square\)

The path-reversal automorphism exchanges \(a,c\) and fixes \(b,d\); it transports this necessary root restriction to the reflected \(\{b,c\}\) placements. Root \(s\) of the displayed \((ea)(ab)\) row, the six remaining Hamilton-path pentagons and general Case XII are not settled by this theorem. All exchanges are on actual complete matchings; the proof has not received independent review, and no local mathematical recomputation was used.
