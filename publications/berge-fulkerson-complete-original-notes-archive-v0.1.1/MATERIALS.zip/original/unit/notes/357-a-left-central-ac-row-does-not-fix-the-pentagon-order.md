> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A left central \((ea)(ac)\) row does not fix the pentagon order

In the central-path exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), take its left \((ea)(ac)\) row with singleton-\(a\) mask \(Y_L\). Its unique singleton-\(e\) exterior is orientation I, \(a:\Sigma,3C,4D\). The route table gives **both**
\[
 P_b^0=P_d^L=I=h_1,
 \qquad P_d^0=P_b^L=D=h_2.                         \tag{1}
\]
If the shore \(e\)-path pairs \(E\) with \(I\), the two pure switches have endpoints \(b,d\), compatible with \(S_1=e-a-b-d-c-e\). If it pairs \(E\) with \(D\), their endpoints are \(d,b\), compatible with \(S_2=e-a-d-b-c-e\). Note 271 permits either pairing. Thus the orientation \(Y_L\) of this one required row does not by itself determine whether \(S=S_1\) or \(S=S_2\).

There is a real row for the second alternative. Start with the connected cubic 25-vertex five-pole constructed for Note 271's \((ea)(ac)\) template in the “Real rows” section of [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). Its twelve-vertex shore and all six actual matchings \(X,Y,Z,U,V,W\) are given explicitly in [Note 254](254-the-b-cross-rows-require-shore-cycle-intersections.md). Under Note 272's port identification, their proper shore-port sets are
\[
 \varnothing,\quad HJ,\quad EAID,\quad EA,\quad HJ,\quad ID.       \tag{2}
\]
Their \(X\triangle Z\) shore paths pair \(E\)--\(I\) and \(A\)--\(D\). Now **interchange only the two shore attachments labelled \(I=h_1\) and \(D=h_2\)**, leaving the exterior graph and the six shore edge sets unchanged. Equivalently, map Note 254's ordered ports \((H_0,E_0,I_0,J_0,D_0,A_0)\) to \((H,E,D,J,A,I)\) instead of Note 272's \((H,E,I,J,A,D)\). Every port set in (2) is invariant under \(I\leftrightarrow D\): \(Z,W\) use both ports and the other four slots use neither. Therefore the same six edge sets still glue slot by slot to actual complete perfect matchings and cover every edge exactly twice. The shore remains connected, the exterior remains connected, and the two distinct attachments preserve a simple connected cubic 25-vertex five-pole.

The new shore paths pair \(E\)--\(D\) and \(A\)--\(I\). By (1), the \(e\)-path of \(X\triangle Z\) now ends at \(d\), while after the wholly exterior \(a\)--\(c\) switch it ends at \(b\). These are precisely the two allowed state changes \(ea\to ad\) and \(ec\to bc\) for \(S_2\). Thus a **genuine left \((ea)(ac)\) BF row** realizes the opposite pure-route order. The construction is a rowwise counterexample to inferring \(S_1\) from \(Y_L\); it is not an exact-Case-XII pole, as the published order bound used in [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) already excludes exact support at order 25.

The correct normalization for an exact-Case-XII central-path pole is to reflect the exterior, if needed, so that its **allowed pentagon** is \(S_1\), without also prescribing the orientation of its \((ea)(ac)\) row. [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) now uses this normalization and does not depend on the rowwise orientation inference of Note 272. In the older chain, the step from “the \((ea)(ac)\) row is left” to “\(S=S_1\)” requires the explicit \(E\)--\(I\) pairing or an independent argument. Once \(S_1\) is fixed independently, Note 272's conditional left \((ea)(ad)\) calculations retain their stated scope.
