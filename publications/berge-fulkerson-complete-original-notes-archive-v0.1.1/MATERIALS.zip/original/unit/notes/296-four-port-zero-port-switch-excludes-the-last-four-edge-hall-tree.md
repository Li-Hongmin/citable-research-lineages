> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four-port/zero-port switching excludes the last four-edge Hall tree

> **Scope after [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md):**
> Theorem 1 assumes that the required \((ea)(ad)\) row uses Note 272's
> left exterior template. That orientation is not yet forced by
> complete exact-Case-XII support. Theorem 2 is a separate implication
> from the stated \(q=D\) side placement, matching balance, and the
> complete-family exterior masks; it does not use the left \(ad\) row.

Continue the complete exact-Case-XII central-path profile of
[Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md)
and the near-bipartite \(3{:}2\) shore profile of
[Notes 283, 289–295](295-four-mixed-fibres-reduce-the-one-port-hall-tree-to-two-orientations.md).
Write \(E=e,\ A=a:\Sigma,\ I=h_1,\ D=h_2,\ H=h_3,\ J=h_4\).
The unmarked core minus \(g\subset B\) is bipartite with sides \(B,R\);
\(t_e w\) is the \(R\)-side half of the internal mark. By Note 295, the
only still-listed four-edge Hall trees have \(q=D\in R\), one of
\(r=H,J\) in \(R\), and their one-port \(B\)-vertex \(s\) carries \(I\).
Let \(p\) denote the other port in \(\{H,J\}\setminus\{r\}\); its
base lies in \(B\).

**Theorem 1.** Neither remaining four-edge Hall tree exists. Consequently,
conditional on the forced rows of Notes 271–272, *all* minimal four-edge
Hall barriers of Note 290 are excluded.

**Proof.** In the double-\(HJ\) row, let \(Y\) be either singleton-\(a\)
shore matching with ports \(HJ\), and let \(W\) be the opposite
singleton-\(c\) shore matching with ports \(DI\). Note 290 gives
\(g,t_ew\in Y\), while \(W\) avoids \(g\) and selects \(t_ev\).
At \(s\), the path \(D-\hat D-s-I\) is an entire component of
\(Y\triangle W\). The other open component joins \(H,J\). As shown in
Note 295, the two same-side edges \(g,t_ew\) lie together on that
\(H\)--\(J\) path or on an alternating cycle. The cycle switch would
make a forbidden \(DI\)-port \((g,t_ew)\) matching (Note 290). Switching
the \(H\)--\(J\) path into \(W\) therefore gives an actual shore matching
\[
 S(F)=\{D,I,H,J\},\qquad g,t_ew\in F.                 \tag{1}
\]

Let \(X\) be the zero-proper-port matching in the same required row.
At \(s\), its selected edge is \(s\hat r\), since the other two edges
there are each loaded twice by the row. Hence \(I-s-\hat r-r\) is an
entire component of \(F\triangle X\); the other open component joins
\(D\) to \(p\). Again the two same-side edges \(g,t_ew\) lie together
on that latter path or on an alternating cycle. Switching the path
into \(X\) would make the forbidden \(Dp\)-port
\((g,t_ew)\) matching of Note 295. Switching the cycle into \(X\)
instead gives an actual shore matching
\[
 S(N)=\varnothing,\qquad g,t_ew\in N.                \tag{2}
\]
Only the existence of \(F,N\) is needed; their complement pairing is
irrelevant here.

Now take \(F\triangle N\). Since both matchings select \(g,t_ew\),
neither edge belongs to the difference. Its four open ends are the
ports \(D,I,H,J\), all selected by \(F\); thus two alternating paths
pair these ports. Switch into \(N\) the path beginning at \(D\).
The resulting shore matching still selects \(g,t_ew\) and has exactly
the two ports \(D,P\), where \(P\in\{I,H,J\}\).
If \(P=I\), Note 290 forbids this fibre. If \(P=p\), Note 295 forbids it.
If \(P=r\), both ports are based in \(R\), contradicting Note 283's
matching-balance equation: a two-port matching selecting \(g,t_ew\)
must have one \(B\)-port and one \(R\)-port. There is no possible
partner \(P\). \(\square\)

Together with Note 295's exclusion of \(\hat q=\hat r\), Note 290's
Hall reduction now has a precise residual boundary: if
\(v\notin\{x,y\}\), the empty \(D,r,g,t_ev\) fibre requires a tight
Hall set whose cut in the completed host has size \(6\), \(8\), or
\(10\). The alternative \(v\in\{x,y\}\) is a local incidence collision.

The same profile has a separate complete-matching restriction.

**Theorem 2.** For \(q=D\), every actual two-proper-port shore matching
selecting \(g,t_ew\) has port set \(HJ\). In particular, **every complete
singleton-\(b\) perfect matching avoids \(g\)**.

**Proof.** Note 283's balance requires one selected proper port on each
side. The \(R\)-ports are \(D,r\), and the \(B\)-ports are \(A,I,p\).
The \(DA,DI\) fibres are empty by Note 290; the \(Dp\) fibre is empty
by Note 295. The next three genuine singleton-\(b\) exterior masks
exclude \(rA\), and \(rI\) when \(r=H\). The notation \(kX\) means
\(u_kX_{\rm ext}\); every row also selects \(b_{\rm term}\).

| \(r;\) selected shore ports | Selected exterior edges besides \(b_{\rm term}\) | Complement arm containing unselected \(D\) |
|---|---|---|
| \(H;AH\) | \(a:\Sigma,c:A,d:E,1B,2C,4D,h_3\) | \(D-u_2-B_{\rm ext}-t_d-d\) |
| \(J;AJ\) | \(a:\Sigma,c:A,d:E,1B,2C,3D,h_4\) | \(D-u_2-B_{\rm ext}-t_d-d\) |
| \(H;IH\) | \(a:C,c:A,d:E,2B,4D,h_1,h_3\) | \(D-u_2-C_{\rm ext}-u_3-D_{\rm ext}-t_b-A_{\rm ext}-u_1-B_{\rm ext}-t_d-d\) |

The displayed edges cover \(t_a,t_b,t_c,t_d\) and \(u_1,\ldots,u_4\)
once. The five branch vertices \(A_{\rm ext},\ldots,E_{\rm ext}\)
are covered, respectively, by
\((c:A,1B,2C,4D,d:E)\),
\((c:A,1B,2C,3D,d:E)\), and
\((c:A,2B,a:C,4D,d:E)\).
Gluing a purported shore matching gives a singleton-\(b\) matching
whose only unselected same-side proper edge is \(D\). The displayed
arm puts \(D\) on the \(d\)-terminal path. Every closed complement
cycle is even. The other terminal path has both ends among
\(\{a,c,e\}\), and switching its two colours makes either end the
second lonely terminal. At most \(a\) is an allowed partner of \(b\)
in \(S=e-a-b-d-c-e\); at least one resulting Tait state is forbidden.

It remains to exclude \(r=J\) with ports \(IJ\). Reuse one purported
shore matching \(M\) with the following two exterior masks:
\[
\begin{aligned}
 M_b&=\{b_{\rm term},a:C,c:A,d:E,2B,3D,h_1,h_4\},\\
 M_a&=\{a_{\rm term},b:A,c:E,d:B,2C,3D,h_1,h_4\}.
\end{aligned}                                                   \tag{3}
\]
For \(M_b\), the branch vertices are covered by
\((c:A,2B,a:C,3D,d:E)\). Its exterior complement has an
\(a\)--\(A\) terminal arm, a \(D\)--\(H\) path, and a
\(c\)--\(d\) terminal path. The only unselected same-side edge \(D\)
lies on an odd closed cycle exactly when the shore complement pairs
\(D\) with \(H\). Otherwise every closed cycle is even, and switching
the exception-free \(c\)--\(d\) path gives the forbidden \(bc\)
Tait state. Therefore the shore complement of \(M\) must pair
\[
             DH\mid EA.                              \tag{4}
\]
For \(M_a\), the branches are covered by
\((b:A,d:B,2C,3D,c:E)\). Its exterior complement has a
\(b\)--\(d\) terminal path and routes \(c\)--\(D\) and
\(A\)--\(H\). With the *same* shore pairing (4), the
\(e\)--\(c\) terminal path contains \(D\), all closed cycles are
even, and the \(b\)--\(d\) path is exception-free. Switching that
path gives the forbidden \(ad\) Tait state. This excludes \(IJ\).
The only mixed-side pair left is \(rp=HJ\).

Finally, every full singleton-\(b\) matching selects exactly two
proper shore ports: the three nonterminal marked vertices \(t_a,t_c,t_d\)
and the four \(u_i\) must cover the five exterior branch vertices, so
exactly two of their seven choices use shore ports. If it selected
\(g,t_ev\), balance would force the two \(R\)-ports \(D,r\),
contrary to Note 289. If it selected \(g,t_ew\), the first part of
this theorem forces ports \(HJ\). But then \(u_3,u_4,t_b\) are matched
through \(H,J,b_{\rm term}\), leaving \(D_{\rm ext}\), whose only
neighbours are those three vertices, uncovered. Thus \(g\) is absent
from every complete singleton-\(b\) matching. \(\square\)

Theorem 1 closes the *four-edge Hall-tree* alternative only. The
collision \(v\in\{x,y\}\), Hall cuts of size six or more, the \(4+1\)
and higher-rank shore profiles, other rectangle contexts, and
Berge–Fulkerson remain open. The forced exterior rows of Notes
271–272 and the earlier fibre exclusions are hand proofs awaiting
independent verification. The five masks above were checked by
vertex incidence and complement-path tracing, without enumeration.
