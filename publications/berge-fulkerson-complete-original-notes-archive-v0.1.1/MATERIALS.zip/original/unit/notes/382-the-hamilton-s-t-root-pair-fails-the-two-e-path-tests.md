> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The Hamilton \((s,t)\) root pair fails the two \(e\)-path tests

In the Hamilton \(K_{3,3}\) exterior of [Notes 378–380](380-a-real-hamilton-ea-eb-row-survives-the-two-immediate-switches.md), consider the two remaining Case-XII pentagons
\[
                S_1=e-a-b-d-c-e,\qquad S_2=e-a-d-b-c-e.
\]
For any actual \((ea)(eb)\) BF row, let \(P\) be its zero-port state-\(ea\) triple, \(R\) its zero-port state-\(eb\) triple, \(A,B\) its singleton-\(a,b\) occurrences, and \(E_1,E_2\) its singleton-\(e\) occurrences. The two zero-port triples have roots \(x\) or \(s\), and \(x\) or \(t\), respectively, by [Note 358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md). [Note 379](379-a-hamilton-ea-eb-row-excludes-two-root-pairs.md) excluded \((x,x)\) for both pentagons and \((x,t)\) for \(S_1\). The present theorem excludes another pair:

> **Theorem.** If the complete BF support is exact Case XII with either allowed pentagon \(S_1\) or \(S_2\), a required \((ea)(eb)\) row cannot have roots \((s,t)\). Consequently the only remaining root pair for \(S_1\) is \((s,x)\); for \(S_2\), only \((x,t)\) and \((s,x)\) remain. The exclusion holds at every shore order and cycle rank.

**Proof.** Write the exterior tree as
\[
x-u_0-r-u_1-y-u_2-s-u_3-z-u_4-t,
\quad a=xs,\ b=xt,\ c=yt,\ d=zr.
\]
The assumed roots give
\[
\begin{array}{c|l}
P &t_as;\ b,c,d;\ xu_0,ru_1,yu_2,zu_3,tu_4\\
R &t_bt;\ a,c,d;\ xu_0,ru_1,yu_2,su_3,zu_4.
\end{array}                                                     \tag{1}
\]
As in Note 379, the \(a\)-terminal path of \(P\triangle A\) must end at \(c\): ending at \(b\) or \(d\) would replace \(P\) by a forbidden \(T_i\) state beside the unchanged \(R=eb\in T_i\), for either \(i=1,2\). Starting at \(a,t_a,s\), this entirely exterior path has exactly two possibilities,
\[
H_2:a,t_a,s,u_2,y,t_c,c,
\qquad H_3:a,t_a,s,u_3,z,u_4,t,t_c,c.             \tag{2}
\]
Indeed, departure from \(s\) through \(u_2\) reaches \(y\), where any continuation through \(u_1,r\) ends at \(d\) or \(b\); departure through \(u_3\) reaches \(z\), where the \(d\)-half ends at \(d\), so continuation through \(u_4,t\) must take the \(c\)-half. Switch \(P,A\) along the chosen path, obtaining a zero-port state-\(ec\) triple \(P'\) with the **same complete shore matching** as \(P\).

For \(S_1\), the \(e\)-path of \(P\triangle E_j\) must end at \(b\), and that of \(P'\triangle E_j\) must end at \(d\). For \(S_2\), the required endpoints are reversed: old \(d\), new \(b\). Every other resulting state lies in the forbidden pentagon \(T_i\) beside the unchanged \(R=eb\in T_i\). Since \(P,P'\) have the same entire shore matching and \(E_j\) is unchanged, their \(e\)-paths leave the shore at the **same proper port**. We show that both requested endpoint changes fail for one forced singleton-\(e\) occurrence.

The common edges \(xu_0\) of \(P,R\) load that edge twice. At \(x\), \(A\) must use \(t_bx\) because it uses terminal \(a\), and \(B\) must use \(t_ax\) because it uses terminal \(b\). The remaining two singleton-\(e\) occurrences split these two halves. At marks \(a,b\), their loads force the occurrence \(F\) using \(t_bx\) to use \(t_as\), while the other occurrence uses \(t_ax,t_bt\). Thus \(F\) matches \(x\) through \(b\) and \(s\) through \(a\). In both cases of (2), \(P\) and \(R\) both use \(yu_2\); the route of \(A\), together with the vertex loads at \(s,u_2\), forces \(F\) onto shore port \(p_2\). More explicitly, for \(H_2\), \(A\) uses \(su_2\) and \(B\) plus the other \(E\) use the remaining \(su_2\) slot; for \(H_3\), \(R,A\) saturate \(su_3\), so \(B\) and the other \(E\) use both \(su_2\) slots. Since \(yu_2\) is already saturated, \(F\) uses \(p_2\) in either case.

First assume \(S_1\). Suppose \(H_2\) is chosen. The mark/vertex loads at \(t\) force \(A\) onto \(tu_4\) and \(B,F\) onto the \(c\)-half \(t_ct\). At \(y\), this forces \(B,F\) onto \(yu_1\). The \(b\)-leg of \(P\triangle F\) begins \(b,t_b,x,u_0\). If \(F\) uses \(p_0\), that leg ends at \(p_0\) before meeting any edge changed by (2), so the \(e\)-path would still end at \(b\) after the switch. Therefore \(F\) uses \(ru_0\), and, at \(r\), its \(d\)-half must be \(t_dz\). The old \(b\)-leg now runs
\[
 b,t_b,x,u_0,r,u_1,y,u_2,p_2.                         \tag{3}
\]
After the \(H_2\) switch, \(P'\) still uses \(zu_3\). Since \(F\) uses \(t_dz\) and \(t_as\), it uses \(p_3\) at \(u_3\). The new \(d\)-leg is
\[
 d,t_d,z,u_3,p_3.                                      \tag{4}
\]
The ports \(p_2,p_3\) differ, contradicting the required common shore exit.

Suppose instead that \(H_3\) is chosen. Besides its edges on \(H_3\), \(A\) uses \(t_bx,t_dr,yu_1,p_0,p_2\). The first two triples saturate \(yu_2\), while \(R,A\) saturate \(su_3,zu_4\). At \(t\), the three row occurrences \(P,R,A\) use \(tu_4,t_bt,t_ct\), respectively. The same \(b\)-leg argument forces \(F\) to use \(ru_0\), hence \(t_dz\). Since \(F\) also uses \(t_as\), it uses \(p_3\) at \(u_3\), in addition to its already forced \(p_2\).

There are exactly two possibilities for \(F\)'s \(c\)-half. If \(F\) uses \(t_ct\), it uses \(yu_1,p_4\). Its old \(b\)-leg again ends at \(p_2\) by (3), whereas after the \(H_3\) switch \(P'\) uses \(zu_4\), so the new \(d\)-leg is \(d,t_d,z,u_4,p_4\). If \(F\) instead uses \(t_cy\), it uses \(p_1,tu_4\). Its old \(b\)-leg ends at \(p_1\) through \(b,t_b,x,u_0,r,u_1,p_1\); after the switch the new \(d\)-leg runs
\[
 d,t_d,z,u_4,t,t_c,y,u_2,p_2.                         \tag{5}
\]
The ports are respectively \(p_2\ne p_4\) and \(p_1\ne p_2\), again impossible. This proves the \(S_1\) assertion.

Now assume \(S_2\), so the old \(d\)-leg and new \(b\)-leg must reach the same proper port. For \(H_2\), we still have \(F:t_bx,t_as,t_ct,yu_1,p_2\) by the load calculation above, before choosing its \(d\)-half. If \(F\) uses \(t_dr\), it uses \(p_0\) at \(u_0\). The old \(d\)-leg ends at \(p_2\) along \(d,t_d,r,u_1,y,u_2,p_2\), whereas the new \(b\)-leg ends immediately at \(p_0\) along \(b,t_b,x,u_0,p_0\). If \(F\) uses \(t_dz\), it uses \(ru_0\) and \(p_3\). The old \(d\)-leg ends at \(p_3\) along \(d,t_d,z,u_3,p_3\), whereas the new \(b\)-leg runs through \(x,u_0,r,u_1,y,t_c,t,u_4\) and ends at \(p_4\). Both choices fail.

For \(H_3\), \(F\) still uses \(t_bx,t_as,p_2\). If it uses \(t_dr\), it must use \(p_0\) at \(u_0\). Its old \(d\)-leg ends at \(p_2\) when its \(c\)-half is \(t_ct\), and at \(p_1\) when that half is \(t_cy\); its new \(b\)-leg ends at \(p_0\) in either case. If instead \(F\) uses \(t_dz\), it uses \(ru_0,p_3\). Its old \(d\)-leg ends at \(p_3\); its new \(b\)-leg ends at \(p_2\) when its \(c\)-half is \(t_ct\), and at \(p_1\) when that half is \(t_cy\), following \(x,u_0,r,u_1\). Again the ports differ. Thus \((s,t)\) also fails for \(S_2\). \(\square\)

This theorem uses one genuine row, complete matching identities and two actual alternating terminal paths. It does not exclude the surviving \((s,x)\) pair: [Note 380](380-a-real-hamilton-ea-eb-row-survives-the-two-immediate-switches.md) realizes it for \(S_1\) before full exact-support closure is imposed. Nor does it decide the \((x,t)\) pair for \(S_2\), other exteriors, exact Case XII as a whole, or Berge–Fulkerson. The hand proof awaits an independent check; no local mathematical recomputation was used.

There is a useful first gate for that remaining \(S_2\) root pair \((x,t)\). Note 379 fixes the \(a\)--\(c\) route at \(a,t_a,x,u_0,r,u_1,y,t_c,c\). In this root pair both singleton-\(e\) occurrences use \(t_bx,t_as\). If one such occurrence \(E\) used \(t_dz\), its old \(d\)-leg from \(P\) would end at \(p_3\): \(d,t_d,z,u_3,p_3\), because \(P\) uses \(zu_3\) and \(E\) matches \(s,z\) through the \(a,d\) halves. At \(r\), the same \(E\) must use \(ru_0\). After the \(a\)--\(c\) switch, the new \(b\)-leg runs from \(b,t_b,x,u_0,r,u_1\). If \(E\) uses \(p_1\) at \(u_1\), that leg ends there. Otherwise \(E\) uses \(yu_1,t_ct\), and the leg continues through \(y,t_c,t,u_4\) to \(p_4\). Neither \(p_1\) nor \(p_4\) equals \(p_3\), whereas \(S_2\) requires the same shore exit for old \(e\to d\) and new \(e\to b\). Hence **both** singleton-\(e\) occurrences must use \(t_dr\). This saturates that half, forces singleton-\(b\) onto \(t_dz\), and forces both singleton-\(e\) occurrences onto \(p_0\). Their old \(d\)-legs and new \(b\)-legs both end at \(p_0\), so this gate alone leaves \((x,t)\) genuinely unresolved.
