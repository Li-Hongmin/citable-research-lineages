> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fork-triangle exterior has one mixed \((ea)(ab)\) row template

Retain the complete exact-Case-XII, minimum-host, one-internal-mark five-cut profile of [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md). This note treats one marking of its \(|U|=4,r=4\) fork tree. Let \(O\) be the degree-three exterior singleton, \(L\) the degree-two singleton, and \(P,Q,R\) the leaves. Write
\[
K=\{1O,1P,2O,2Q,3O,3L,4L,4R\},\qquad
h_i=u_i\Sigma\quad(1\le i\le4),                         \tag{1}
\]
where the odd shore \(\Sigma\) has unrestricted order and unmarked cycle rank. The four exterior marks are
\[
a:L\!:\!\Sigma,\qquad b:PQ,\qquad c:PR,\qquad d:QR.  \tag{2}
\]
Assume \(ea,eb\) are the two allowed neighbours of the internal shore mark \(e\). This is the fork placement whose three cross marks make a triangle on the leaves, with \(b\) opposite \(L\). The alternative choice of an \(e\)-neighbour among \(c,d\), and the other fork markings, are not covered.

**Theorem.** Every real \((ea)(ab)\) BF row compatible with complete exact Case XII has, up to interchanging \(P,Q\) and exchanging its two complete singleton-\(a\) occurrences, exactly the exterior masks in Table (9) below. In particular, the two singleton-\(a\) exteriors must be *different*. In the displayed orientation, the pure \(ea\) half has exterior load two on \(h_2\) and zero on \(h_1\); the opposite \(ab\) half has the reversed load. The full shore must realize the six port sets in (10), with its \(e\)-terminal alternating path paired to \(h_3\). This is a necessary full-row gate, not an existence claim or an exclusion of the fork.

The [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires \((ea)(ab)\): \(ea\in S\), whereas \(ab\in T\) because \(a,b\) are both neighbours of \(e\). Write its real six matching occurrences as
\[
\mathcal D=X_a+Y_a+Z_e,\qquad
\mathcal E=U_{ab}+V_a+W_b,\qquad
\mathcal D+\mathcal E=2\mathbf1.                         \tag{3}
\]
The negative support makes \(\mathcal D\) pure \(S\), even after exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\).

## The two singleton-\(a\) exteriors

By [Note 230's quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), the state-\(ea\) triple is zero-port. The matching of \(K-L\) is unique, so
\[
X_a=\{a:L,1P,2Q,3O,4R\}.                              \tag{4}
\]
The \(a\)--\(b\) terminal path in \(X_a\triangle Y_a\) is wholly exterior by [Note 244's path argument](244-every-shore-mark-must-neighbour-the-internal-mark.md). It passes through \(L-u_3-O-u_1-P\) or \(L-u_3-O-u_2-Q\). Matching the remaining leaf marks and the \(U\)-vertices gives precisely
\[
\begin{aligned}
Y_P&=\{b:P,c:R,d:Q,1O,3L,h_2,h_4\},\\
Y_Q&=\{b:Q,c:P,d:R,2O,3L,h_1,h_4\}.
\end{aligned}                                                   \tag{5}
\]
Exchanging \(Y_a,V_a\) in (3) and applying purity again shows that **both** have one of these two exterior masks. Switching the displayed exterior terminal paths produces state-\(eb\) triples, with the *same complete shore mask* as \(X_a\):
\[
X_P=\{b:P,1O,2Q,3L,4R\},\qquad
X_Q=\{b:Q,1P,2O,3L,4R\}.                              \tag{6}
\]
For purity, the \(e\)-terminal path against \(X_a\) and against the applicable \(X_P\) or \(X_Q\) must end at \(c,d\) in opposite order: these are the only remaining allowed neighbours of \(a,b\) in the pentagon.

The two singleton-\(a\) masks both use \(3L,h_4\), so neither \(Z_e\) nor any other occurrence may use those edges. If \(Z_e\) selected \(a:L\), then \(u_4\) would have to use \(4R\); the three nonterminal cross marks \(b,c,d\) would then need three distinct endpoints among only \(P,Q\), an impossibility. Thus \(Z_e\) selects \(a:\Sigma\), uses \(4L\), and selects two of \(h_1,h_2,h_3\). Its three cross marks cover \(P,Q,R\) in one of two cyclic orientations,
\[
B_P=\{b:P,c:R,d:Q\},\qquad
B_Q=\{b:Q,c:P,d:R\},                                \tag{7}
\]
and its only other \(K\)-edge is one of \(1O,2O,3O\).

The shore \(e\)-path cannot pair with \(a:\Sigma\): against either state-\(eb\) triple in (6), that port leads directly to terminal \(a\) and would make the forbidden state \(ab\). For orientation \(B_Q\), the other ports have these exterior terminal endpoints against \(X_a,X_P,X_Q\), respectively:

| \(Z_e\)'s \(O\)-edge | Selected \(h\)-ports and endpoint triples |
|---|---|
| \(1O\) | \(h_2:(b,c,c),\quad h_3:(c,d,d)\) |
| \(2O\) | \(h_1:(c,c,c),\quad h_3:(b,d,d)\) |
| \(3O\) | \(h_1:(c,d,c),\quad h_2:(b,c,d)\) |

The table follows by tracing each alternating path through (1); it uses no shore-internal matching. In every displayed case, the third proper port \(a:\Sigma\) also reaches a triple terminal, so no exterior path joins two shore ports. The table for \(B_P\) is obtained by interchanging \(P,Q\), \(u_1,u_2\), \(c,d\), and \(h_1,h_2\).

If \(Y_a,V_a\) were both \(Y_P\), their two occurrences would already load \(b:P,c:R,d:Q,1O,h_2\) twice. Then (7) forces \(Z_e\) to have \(B_Q\), and avoiding \(1O,h_2\) forces its \(O\)-edge to be \(2O\). The table shows that neither \(h_1\) nor \(h_3\) has the required opposite \(c,d\) endpoints. The case \(Y_a=V_a=Y_Q\) is symmetric. Therefore the two singleton-\(a\) exteriors are different.

## The sole mixed exterior row

Assume \(Y_a,V_a\) are \(Y_P,Y_Q\), in either order. The state-\(ab\) triple \(U_{ab}\) has terminal \(e\) and exactly one proper shore port. It cannot select \(a:\Sigma\): \(3L\) is already loaded twice by \(Y_a,V_a\), so \(u_4\) would have to use \(4L\), leaving \(R\) uncovered because \(c,d\) are triple terminals. Hence \(U_{ab}\) selects \(a:L\) and \(4R\), and its only port is one of \(h_1,h_2,h_3\). The opposite singleton \(W_b\) consequently selects \(a:\Sigma\) and \(4L\).

The two mixed singleton-\(a\) occurrences use each of \(b:P,b:Q\) once. Since \(W_b\) has terminal \(b\), \(U_{ab}\) and \(Z_e\) must use opposite \(b\)-halves. By symmetry take \(U_{ab}\) to use \(b:P\). Then \(Z_e\) uses orientation \(B_Q\). Exchanging \(Y_a,V_a\) makes *both* state-\(eb\) triples \(X_P,X_Q\) relevant while keeping (3) a real row with a pure \(ea\) half. In the endpoint table, only \(Z_e\)'s \(1O\) choice has a port whose endpoint is \(c\) against \(X_a\) and \(d\) against **both** \(X_P,X_Q\). The \(e\)-path is therefore paired with \(h_3\). The remaining edge-load-two constraints force the following exterior table.

**Table (9). Forced exterior row**

| Slot | Full-pole boundary | Proper exterior mask | Shore ports |
|---|---|---|---|
| \(X_a\) | \(b,c,d\) | \(a:L,1P,2Q,3O,4R\) | \(\varnothing\) |
| \(Y_P\) | \(a\) | \(b:P,c:R,d:Q,1O,3L,h_2,h_4\) | \(\{h_2,h_4\}\) |
| \(Z_e\) | \(e\) | \(a:\Sigma,b:Q,c:P,d:R,1O,4L,h_2,h_3\) | \(\{e,a:\Sigma,h_2,h_3\}\) |
| \(U_{ab}\) | \(c,d,e\) | \(a:L,b:P,2Q,3O,4R,h_1\) | \(\{e,h_1\}\) |
| \(V_a=Y_Q\) | \(a\) | \(b:Q,c:P,d:R,2O,3L,h_1,h_4\) | \(\{h_1,h_4\}\) |
| \(W_b\) | \(b\) | \(a:\Sigma,c:R,d:Q,1P,2O,4L,h_3\) | \(\{a:\Sigma,h_3\}\) |

Indeed, \(Z_e\) has \(1O\), so \(U_{ab}\) cannot use \(1O\). With \(a:L,b:P,4R\), its only remaining matching is \(2Q,3O,h_1\); the remaining exterior edges then force \(W_b\). The masks in (9) load every proper exterior edge twice. Their port sets, displayed in the last column, are the required shore gate:
\[
\boxed{\varnothing,\quad\{h_2,h_4\},\quad\{e,a:\Sigma,h_2,h_3\},
\quad\{e,h_1\},\quad\{h_1,h_4\},\quad\{a:\Sigma,h_3\}.} \tag{10}
\]
The swapped row exchanges the two **complete** singleton-\(a\) occurrences, placing \(Y_Q\) in the pure half while leaving \(Z_e\) fixed. It must still pair \(e\) with \(h_3\) against the appropriate triple. Table (9) alone does not give complete exact-Case-XII support. The remaining fork markings, the path tree, larger barriers, other Tutte profiles, and Berge--Fulkerson remain open. The derivation is analytic and has not received an independent check.

## A real row meets the port and \(e\)-pairing conditions

The port sets in (10) are jointly realizable by a single shore. Take the six-cycle
\[
v_0v_1v_2v_3v_4v_5v_0,
\]
with \(v_3=t_e\), and attach \(h_1,h_4,h_2,h_3,a:\Sigma\) at \(v_0,v_1,v_2,v_4,v_5\), respectively. The five vertices other than \(t_e\) form the odd shore after deleting the internal marked edge \(e=v_2v_4\). For the six exterior slots of Table (9), use these *complete* shore restrictions:

| Slot | Shore-cycle edges |
|---|---|
| \(X_a\) | \(v_1v_2,v_3v_4,v_5v_0\) |
| \(Y_P\) | \(v_3v_4,v_5v_0\) |
| \(Z_e\) | \(v_0v_1\) |
| \(U_{ab}\) | \(v_1v_2,v_4v_5\) |
| \(V_a\) | \(v_2v_3,v_4v_5\) |
| \(W_b\) | \(v_0v_1,v_2v_3\) |

The corresponding port sets are exactly (10). Every shore-cycle edge appears twice: the six edge pairs are \(ZW,XU,VW,XY,UV,XY\) in cyclic order \(01,12,23,34,45,50\). The shore \(e\)-path in \(X_a\triangle Z_e\) is the single edge \(v_3v_4\), so it pairs \(e\) with the required \(h_3\); the state-\(eb\) triples have the same shore mask. Gluing these restrictions to Table (9) gives a **real** \((ea)(ab)\) six-perfect-matching row in a connected simple cubic five-pole of order 19. Its girth is five: \(K\) is a tree; every cross mark is a two-edge path between singleton vertices at distance at least four in \(K\); a cycle using the shore needs two attachments and has length at least five; and \(u_3Lv_5v_4u_3\), with the marked edge \(Lv_5\) subdivided at \(t_a\), is a five-cycle. By [Note 226's order bound](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md), this pole is not exact Case XII. Thus the mixed port sets and prescribed \(e\)-pairing are jointly realizable in a real row; the complete negative support remains the separate obstruction.

[Note 260](260-the-mixed-fork-row-has-a-forbidden-ec-ab-shore-splice.md) subsequently closes that obstruction for this marking: the same mixed half-load admits a portwise compatible \(ec\) exterior decomposition with identical aggregate edge loads, forcing a forbidden \((ec)(ab)\) row in any purported exact-Case-XII pole.
