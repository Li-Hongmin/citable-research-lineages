> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two central-path rows force an odd shore cycle

> **Scope correction (2026-10-01):** The proof below uses a left
> \((ea)(ad)\) row with \(U_{ad}\) at ports \(ED\). The genuine right
> row of [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> has \(U_{ad}\) at \(EJ\). This note alone does not exclude a bipartite
> six-port shore in that right-row branch.

Use the fixed central-path exterior and pure pairing of [Notes 271–272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md). Write the four relevant shore ports as
\[
E=e,\qquad A=a:\Sigma,\qquad I=h_1,\qquad D=h_2.
\]
In every required real \((ea)(ad)\) or \((ea)(ac)\) row, the zero-port matching is \(X_a\), the four-port matching \(Z_e\) uses \(E,A,I,D\), and the two paths of \(X_a\triangle Z_e\) pair \(E\)--\(I\) and \(A\)--\(D\). The opposite port pairs are
\[
\begin{array}{c|cc}
\text{row}&U&W\\\hline
ad&ED&AI\\
ac&EA&ID
\end{array}.                                                   \tag{1}
\]

**Theorem.** A bipartite six-port shore cannot have both required real row types with these pure paths. Consequently the remaining exact-Case-XII central-path marking, which requires both types, has a nonbipartite shore: an odd shore-internal cycle is necessary, independent of its order and cycle rank.

## Proof

Suppose the shore interior is bipartite, with sides coloured \(0,1\). The zero-port perfect matching \(X_a\) makes the two sides equal in size. Any actual shore matching with exactly two ports must therefore use one port vertex on each side: deleting its two port-covered vertices leaves equal sides for its internal matching.

The \(E\)--\(I\) and \(A\)--\(D\) paths of \(X_a\triangle Z_e\) start and end with \(Z_e\)-edges. Each has odd length **including its two port semiedges**, so its internal path has odd length. Thus
\[
\operatorname{side}(E)\ne\operatorname{side}(I),
\qquad
\operatorname{side}(A)\ne\operatorname{side}(D).       \tag{2}
\]
Normalize \(\operatorname{side}(E)=0\). Equation (2) gives \(\operatorname{side}(I)=1\). In an \(ad\) row, the two-port matching \(U_{ad}\) uses \(E,D\), so \(\operatorname{side}(D)=1\), and then \(\operatorname{side}(A)=0\). In an \(ac\) row, \(U_{ac}\) uses \(E,A\), so \(\operatorname{side}(A)=1\), and then \(\operatorname{side}(D)=0\). The same four port vertices cannot have both assignments:
\[
\begin{array}{c|cccc}
&E&A&I&D\\\hline
ad&0&0&1&1\\
ac&0&1&1&0
\end{array}.                                                   \tag{3}
\]
This proves the theorem. \(\square\)

The odd cycle has a certificate directly from any chosen pair of real rows; the rows need not share a complete matching. In an \(ad\) row, the shore symmetric difference \(X_{ad}\triangle U_{ad}\) has one \(E\)--\(D\) path, and the pure \(X_{ad}\triangle Z_{ad}\) has an \(A\)--\(D\) path. In an \(ac\) row, \(X_{ac}\triangle U_{ac}\) has one \(E\)--\(A\) path. After deleting the two port semiedges from each path, all three internal paths have odd length: their end semiedges belong to the same matching, so alternation gives odd total length, and removing two preserves parity. Concatenate them in the order \(E\to D\to A\to E\). This is an odd closed walk in the shore interior, hence contains an odd cycle. It localizes the nonbipartiteness to the union of three actual alternating paths.

The conclusion is sharp as a simultaneous-row obstruction. [Note 254's twelve-vertex shore](254-the-b-cross-rows-require-shore-cycle-intersections.md) has a central six-cycle \(s_0\ldots s_5\), spokes \(s_ir_i\), and outer edges \(r_0r_3,r_1r_4,r_2r_5\). Colour \(s_i\) by \(i\bmod2\) and \(r_i\) by \(1-i\bmod2\); every shore edge joins opposite colours. [Note 272](272-the-two-central-path-cross-rows-share-one-pure-exterior.md) glues this same bipartite shore in two different port identifications to obtain an actual \(ad\) row in one 25-vertex pole and an actual \(ac\) row in another. Neither row type is individually excluded by bipartiteness. In [Note 255's modified shore](255-seven-shore-port-states-do-not-supply-the-second-b-cross-row.md), the replacement edges \(r_1r_5,r_2r_4\) create the pentagons \(r_1s_1s_0s_5r_5r_1\) and \(r_2s_2s_3s_4r_4r_2\), yet the prescribed \(ac\) row still fails by triple load on those edges. Thus nonbipartiteness alone does not supply the second row.

There is a stronger necessary condition for **common four-slot load**. In a row that transfers as in [Note 273](273-central-path-transfer-is-a-four-slot-load-intersection.md), put \(P=X_a\triangle Z_e\), \(L=Y_a\triangle V_a\), and \(Q=U_t\triangle W_t=P\triangle L\) on the shore. Each pure path of \(P\) has odd length. The transferred \(Q\) paths have the same respective port pairs, but each starts with a \(U\)-edge and ends with a \(W\)-edge (or conversely), so each has even length. Two paths of opposite length parity with the same endpoints cannot lie in a bipartite graph. Therefore the component of \(P\cup L\) containing **each** pure path contains an odd cycle. If the two pure paths are in distinct components, both components must contain odd cycles. This strengthens Note 274's one-cycle crossing test: an odd cycle elsewhere in the shore is insufficient for transfer.

The theorem concerns the forced central-path templates and their actual matchings. It does not show that a nonbipartite shore supplies both rows, that two nonempty four-slot load sets intersect, or that Berge--Fulkerson holds. The port-parity proof is analytic and awaits independent verification of the upstream forced templates.
