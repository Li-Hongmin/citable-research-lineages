> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first private--rim order is impossible in the two-vertex connector

Use the genuine two-vertex, one-five-cut connector of [Notes 204--205](204-the-two-vertex-one-five-cut-barrier-has-a-unique-exterior-connector.md). Its unmarked exterior path is \(w_1-u_1-w_0-u_2-w_2\). The marks \(a,b,c\) join \(w_0,w_1,w_2\), respectively, to the odd shore \(C\); \(f=w_1w_2\); and \(e\) is internal to \(C\). Write \(h_i=u_iv_i\) for the other two shore ports. Marks are subdivided, so \(a:w_0\) and \(a:C\), for example, are different half-edges of the same mark.

**Theorem.** No pole with this connector has complete exact Case-XII BF support with allowed missing-pair pentagon
\[
S=e-b-a-c-f-e,\qquad T=\{ea,ec,bc,bf,af\}.                 \tag{1}
\]
The assertion holds at every shore order and uses actual full perfect matchings. The other private--rim order \(S=e-b-c-a-f-e\) is not covered.

Let \(\mathcal R(D)\) denote the missing-pair states of all three-perfect-matching decompositions of a half-load \(D\) with terminal load one at each terminal. We first prove the unit-load implication
\[
\varnothing\ne\mathcal R(D)\subseteq S
\quad\Longrightarrow\quad
D(g)=1\quad\text{for every proper edge }g\text{ of the exterior connector and every shore port }a:C,b:C,c:C,h_1,h_2.             \tag{2}
\]
This includes both half-edges of \(f\) and the exterior halves of \(a,b,c\), but does not constrain edges wholly inside \(C\).

By [Note 055](055-half-load-column-saturation-and-case-xii-compression.md), the hypothesis gives \(\mathcal R(D)=S\). Decompose the *same* full load at state \(eb\):
\[
D=X+Y_b+Z_e,\qquad
\partial X=\{a,c,f\},\quad\partial Y_b=\{b\},\quad\partial Z_e=\{e\}.               \tag{3}
\]
[Note 205](205-triple-states-of-the-two-vertex-five-cut-connector-are-shore-deletions.md) fixes \(X\) outside \(C\) to \(b:w_1,u_1w_0,u_2w_2\); its sole shore hit is through \(e\). In \(X\triangle Y_b\), the alternating path beginning at terminal \(b\) must end at \(f\). An end at \(a\) or \(c\) would switch (3) to the forbidden states \(ea\) or \(ec\). From \(w_1\), this \(b\)--\(f\) path either uses \(f:w_1\) directly or follows
\[
w_1-u_1-w_0-u_2-w_2-t_f.
\]
Both paths stay outside \(C\). Switching \(X,Y_b\) along the path produces an \(ef\)-triple \(X'\) whose *entire shore restriction* equals that of \(X\), while \(Z_e\) stays fixed. The exterior of \(X'\) is respectively \(L=(f:w_1,u_1w_0,u_2w_2)\) or \(R=(f:w_2,u_1w_1,u_2w_0)\).

The ten exhaustive exterior routes of \(Z_e\) are [Note 206, (3)](206-the-central-rim-e-neighbour-placement-is-impossible-in-the-two-vertex-connector.md). For each route below, \(a_b\) is the shore port reached from terminal \(a\) outside \(C\) in \(X\triangle Z_e\); \(c_L,c_R\) are the ports reached from terminal \(c\) outside \(C\) in \(X'_L\triangle Z_e\) and \(X'_R\triangle Z_e\). The last two columns are those of Note 206; the first is obtained by following \(a\) through \(w_0\) when \(Z_e\) uses \(a:w_0\).
\[
\begin{array}{c|c|c|c|c}
Z_e\text{ route}&Z_e\text{ shore ports}&a_b&c_L&c_R\\\hline
L0&a,b,c&a&c&c\\
L1&a,b,h_1&a&h_1&h_1\\
L2&a,b,h_2&a&h_2&h_2\\
L3&b,c,h_1&h_1&c&c\\
L4&b,h_1,h_2&h_1&h_2&h_1\\
R0&a,b,c&a&c&c\\
R1&a,c,h_1&a&c&c\\
R2&a,c,h_2&a&c&c\\
R3&b,c,h_2&b&c&c\\
R4&c,h_1,h_2&h_1&c&c.
\end{array}                                                       \tag{4}
\]
For example, in \(R3\) the \(a\)-path runs \(a-w_0-u_1-w_1-b:C\), giving \(a_b=b\); in \(L4\) it runs \(a-w_0-u_1-h_1\), giving \(a_b=h_1\). Port names in (4) denote distinct *edges*, even if their shore endpoints coincide.

In \(X\triangle Z_e\), the path from terminal \(e\) must end at \(a\): the other possible ends \(c,f\) produce \(bc,bf\in T\). In \(X'\triangle Z_e\), it must end at \(c\): ends \(a,b\) produce \(af,bf\in T\). Since \(X|_C=X'|_C\) and \(Z_e\) is unchanged, the shore restriction of both symmetric differences pairs the \(e\)-port with the *same* shore port. Thus \(a_b=c_L\) or \(a_b=c_R\). Table (4) has exactly one equality: \(Z_e=L4\) and \(X'=R\).

The forced exterior matching slots are consequently
\[
\begin{array}{c|l}
X&b:w_1,\ u_1w_0,\ u_2w_2\\
Y_b&a:C,\ c:C,\ f:w_2,\ u_1w_1,\ u_2w_0\\
Z_e&a:w_0,\ b:C,\ c:w_2,\ f:w_1,\ h_1,\ h_2.
\end{array}                                                       \tag{5}
\]
Every edge named in (2) occurs exactly once in (5), proving (2). This deduction used one arbitrary \(S\)-only half-load; it did not identify shore matchings belonging to different BF rows.

Now take the required actual \((eb)(af)\) row; this positive \(S\)--\(T\) type is part of [the published Case-XII relation, Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). A \(T\)-decomposition of its \(S\)-half would pair with the fixed \(af\)-half to form a forbidden \(T\)--\(T\) row, so (2) applies and its \(S\)-half has decomposition (3)--(5). Write its complementary \(af\)-half as \(U+V_a+W_f\), where \(U\) is the \(af\)-triple. The row has load two on every edge, so the complementary half is unit-loaded on the same exterior edges and shore ports. The four possible exterior routes of \(U\), directly from the path in Note 205, are
\[
\begin{array}{c|l}
\text{shore hit of }U&\text{other exterior edges of }U\\\hline
h_1&a:w_0,\ f:w_1,\ u_2w_2\\
h_2&a:w_0,\ f:w_2,\ u_1w_1\\
a:C&f:w_1,\ u_1w_0,\ u_2w_2\\
a:C&f:w_2,\ u_1w_1,\ u_2w_0.
\end{array}                                                       \tag{6}
\]
In the \(h_2\) route, \(X\triangle U\) has a wholly exterior terminal \(b\)--\(a\) path \(b-w_1-u_1-w_0-a\). Switching the two triples on that path and regrouping with \(Z_e,V_a,Y_b,W_f\) gives a genuine \((ea)(bf)\) row. Both states are in \(T\), so this route is impossible.

Each of the other three routes has a wholly exterior \(b\)--\(f\) path in \(X\triangle U\). Switch on it, producing an \(ef\)-triple \(X''\) and an \(ab\)-triple \(U''\). Regroup the six unchanged matching occurrences into complementary half-loads
\[
D_{ef}=X''+Z_e+W_f,\qquad D_{ab}=U''+Y_b+V_a,\qquad D_{ef}+D_{ab}=2\mathbf1.          \tag{7}
\]
Both displayed states belong to \(S\). In the first and third rows of (6), \(X''\) and \(Z_e=L4\) both use \(f:w_1\), so \(D_{ef}(f:w_1)=2\). In the last row, \(U\) uses \(a:C\), forcing \(W_f\) to use \(a:w_0\): \(V_a\) uses terminal \(a\), while the complementary half has unit load at \(a:w_0\). With \(w_0\) occupied by \(a\) and \(U\) using \(u_1w_1\), \(W_f\) must use \(h_1\) at \(u_1\). Since \(Z_e=L4\) also uses \(h_1\), here \(D_{ef}(h_1)=2\).

In every surviving route, therefore, \(D_{ef}\) has load two and \(D_{ab}=2\mathbf1-D_{ef}\) has load zero on the *same* edge covered by (2). Each half has an \(S\)-state, so (2) says that neither state set can be contained in \(S\). Each has a \(T\)-state. Taking those two decompositions in (7) yields a forbidden actual \(T\)--\(T\) row, including a \(T\)-loop if the states coincide. This contradiction proves the theorem. \(\square\)

Together with [Notes 206--208](208-only-a-private-rim-e-neighbour-pair-remains-in-the-two-vertex-connector.md), this eliminates all but the other order \(e-b-c-a-f-e\) of the private--rim placement in the two-vertex, one-five-cut barrier profile. It does not exclude the other deficient-core profiles or settle Berge--Fulkerson.
