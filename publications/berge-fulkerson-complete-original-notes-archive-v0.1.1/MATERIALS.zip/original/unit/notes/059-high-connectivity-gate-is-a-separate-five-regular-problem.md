> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The cyclically-six gate is a separate five-regular factorization problem

Let G be a bridgeless cubic graph with cyclic edge-connectivity at least
six, let F be a 2-factor, and let H_F be obtained by adding a parallel copy
of every edge of F. Then H_F is 5-regular and 5-edge-connected; every
5-edge-cut is the star of one vertex.

If H_F has five pairwise edge-disjoint perfect matchings, they exhaust its
edges. Projecting them to G and adjoining M_0=E(G) minus E(F) gives six
perfect matchings of G covering every edge twice. Hence

    not BF(G), lambda_c(G) >= 6  =>  every H_F is class-2.

The converse assertion that every H_F is class-1 is not known.  The broader
implication (m(5)=5\Rightarrow\) Berge--Fulkerson is already recorded as
Observation 5.11 in Ma--Mattiolo--Steffen--Wolf, SIAM J. Discrete Math.
37 (2023), DOI 10.1137/22M1500654.  Thus this reduction is a positioning
boundary, not by itself a new theorem; the subclass (H_F=G+E(F)) remains a
more focused factorization gate.

The connectivity hypothesis is essential. If G is the triangular prism and
F is its two triangular cycles, then H_F has a 3-edge-cut separating one
triangle. Any decomposition of a k-regular graph into k edge-disjoint
perfect matchings forces every odd vertex set to have cut size at least k,
because each perfect matching crosses an odd cut at least once. Thus this
H_F is class-2. The example lies outside the cyclically-six subclass and
only identifies the sharp low-connectivity obstruction.

The high-connectivity branch is therefore independent: a Case-XII
five-pole theorem would not settle it, and a solution of the general
m(5)=5 problem would be sufficient but stronger than needed.
