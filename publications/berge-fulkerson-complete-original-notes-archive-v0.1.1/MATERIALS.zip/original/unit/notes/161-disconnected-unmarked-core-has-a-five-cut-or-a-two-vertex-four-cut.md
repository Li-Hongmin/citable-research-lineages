> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A disconnected unmarked core has a marked five-cut or a two-vertex four-cut

Let \(J\) be the simple 3-edge-connected cubic marked core of a genuine **minimum-host** exact-Case-XII pole. Its five marked edges \(M\) form a forest of paths by [Notes 157--160](160-a-three-marked-triangle-belt-bf-lifts-an-adapted-five-cycle.md). Put \(F=J-M\). This note classifies the case in which \(F\) is disconnected, and records the direct Tutte-barrier consequence of the ten required triple-boundary perfect matchings. The proof is analytic and awaits independent checking. It does not turn an all-terminal perfect matching into an all-terminal BF cover.

## Every component boundary has at least four edges

For any proper connected component \(C\) of \(F\), every edge of \(\delta_J(C)\) belongs to \(M\). Since \(J\) is 3-edge-connected, \(|\delta_J(C)|\ge3\). Equality is impossible. If the cut isolates one vertex on either shore, all three incident edges of that vertex would be marked, contradicting [Note 157, (7)](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md). Otherwise it is a nontrivial 3-edge-cut, and [Note 123, (5)](123-exact-case-xii-terminal-vertices-are-independent.md) allows at most one marked edge across it. Here all three crossing edges are marked. Hence
\[
\boxed{|\delta_J(C)|\ge4\quad\text{for every component }C\text{ of }F.} \tag{1}
\]

If \(F\) has \(c\ge2\) components, summing (1) over them gives at least \(4c\) crossing-edge incidences. Each of the five marked edges contributes at most two, so \(4c\le10\) and \(c=2\). Write the components as \(A,B\), and let \(k=|\delta_J(A)|=|\delta_J(B)|\). All crossing edges are marked, so \(4\le k\le5\).

If \(k=5\), all five marks cross between \(A\) and \(B\): \(M=\delta_J(A)\). The cubic degree identity \(3|A|=2|E(J[A])|+5\) makes \(|A|\), and likewise \(|B|\), odd. Thus \(F\) consists of exactly two odd components separated by a five-edge marked cut.

If \(k=4\), exactly four marks cross between \(A,B\), while the fifth lies within one component, say \(B\). There is no internal marked edge in \(A\), so \(J[A]=F[A]\). Were \(A\) cyclic, the marked-cut inequality (5) of Note 123 would give \(4+0\ge5\), impossible. Hence \(A\) is a connected tree. The cubic tree identity \(|A|=|\delta_J(A)|-2\) gives \(|A|=2\). Its one edge is unmarked, and each of its two vertices is incident with two of the four crossing marked edges. We have the exact dichotomy
\[
\boxed{F\text{ disconnected}\quad\Longrightarrow\quad
\bigl(k=5,\ M=\delta_J(A),\ |A|,|B|\text{ odd}\bigr)
\ \lor\
\bigl(k=4,\ J[A]\cong K_2,\ M\setminus\delta_J(A)\subseteq E(J[B])\bigr).} \tag{2}
\]
In particular, there is no third disconnected shape compatible with the minimum-host cut inequalities and all ten triple states. The second shape is not excluded by these structural inequalities; (2) does not assert its existence with exact BF support.

In the five-cut branch, let \(a_i\in A\) and \(b_i\in B\) be the endpoints of marked edge \(e_i\), and put
\[
I_A=\{i:F[A]-a_i\text{ has a perfect matching}\},\qquad
I_B=\{i:F[B]-b_i\text{ has a perfect matching}\}.
\]
A triple-boundary matching of missing-pair state \(\{i,j\}\) must delete one endpoint in each odd shore. Hence that state exists only if \(i\in I_A,j\in I_B\) or \(j\in I_A,i\in I_B\). All ten states occur in exact Case XII. Every label therefore belongs to \(I_A\cup I_B\); moreover, two labels cannot both lie exclusively in \(I_A\), or both exclusively in \(I_B\). Thus
\[
\boxed{|I_A\setminus I_B|\le1,\qquad
       |I_B\setminus I_A|\le1,\qquad
       |I_A\cap I_B|\ge3.}                              \tag{3}
\]
At least three cut-edge endpoints admit a one-vertex deletion matching on **both** shores. For each \(i\in I_A\cap I_B\), adjoining \(e_i\) to those two shore matchings gives an actual perfect matching of \(J\) that crosses the marked cut in exactly \(e_i\). Thus at least three of the five marked edges have a single-crossing core matching. This uses the complete ten-state positive support, but not the six-row coupling.

## Exact-support constraints on a Tutte barrier

Every missing-pair state \(p=\{i,j\}\subset[5]\) occurs as a triple-boundary matching in the forty Case-XII BF types. By [Note 157, (2)](157-marked-core-perfect-matchings-are-deletion-matchings-and-exclude-marked-stars.md), for each such pair there are distinct endpoints \(a_i\in e_i\), \(a_j\in e_j\) for which \(F-\{a_i,a_j\}\) has a perfect matching. Consequently, if \(F\) itself has no perfect matching, its matching deficiency is exactly two.

Let \(U\subseteq V(F)\) be any Tutte set attaining this deficiency, so that the number \(q\) of odd components of \(F-U\) equals \(|U|+2\). For every pair of marked edges \(i,j\), every deletion pair \(a_i,a_j\) with \(F-\{a_i,a_j\}\) perfectly matched must put \(a_i,a_j\) in **two distinct odd components** of \(F-U\). Indeed, each odd component left untouched by the two deletions needs an edge of that matching into \(U\), and these edges use distinct vertices of \(U\). Unless the two deletions hit distinct odd components, at least \(q-1=|U|+1\) odd components remain untouched, too many for \(U\) to serve. Thus each of the ten marked-edge pairs must admit endpoints in different odd components of every maximum Tutte barrier:
\[
\boxed{\forall\,i\ne j\quad\exists\,a_i\in e_i,\ a_j\in e_j:
\operatorname{comp}_{F-U}(a_i)\ne
\operatorname{comp}_{F-U}(a_j),\qquad
a_i,a_j\text{ lie in odd components}.}                    \tag{4}
\]

For \(U=\varnothing\), (2)--(3) sharpen (4): the two odd components are the shores of the marked five-cut, every marked edge crosses between them, and at least three labels work on both shores. For \(U\ne\varnothing\), (4) is a necessary test for the ten triple states, not a six-matching BF-row completion. If \(F\) has a perfect matching, an all-terminal perfect matching of the five-pole exists, but exact Case XII rules out only its completion into an all-terminal **BF cover**. Those are the remaining two matching-level branches.
