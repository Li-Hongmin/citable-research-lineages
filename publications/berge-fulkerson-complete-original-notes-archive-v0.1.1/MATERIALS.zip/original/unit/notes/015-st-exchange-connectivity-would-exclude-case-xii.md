> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# S--T exchange connectivity would exclude Case XII

Let

\[
S=\{13,14,24,25,35\},\qquad T=\{12,15,23,34,45\}.
\]

For a BF cover of type \((s)(t)\), write \(Q_s,Q_t\) for its two
triple-boundary perfect matchings.  When \(s,t\) are disjoint, their four-end
Kempe routing has three classes: an A route produces \((12345)\); an SS route
produces another S--S type; and a TT route produces a T--T type.  A Case-XII
pole must realize all 25 S--T types while every actual disjoint completion is
SS, because A and TT outcomes are forbidden.

Define the matching-level graph \(W(H)\).  Its vertices are all actual
triple-boundary perfect matchings in the ten classes indexed by \(S\cup T\).
Join two different classes when their matchings extend with four singleton
matchings to an S--T BF cover.  Within one class, join matchings whose
symmetric difference is a single alternating cycle.  Each within-class graph
is connected, since any same-boundary symmetric difference is a disjoint
union of proper alternating cycles that can be flipped one at a time.

Complete unlabelled enumeration through thirteen internal vertices covers
368 exact-\(S\) poles.  Through order eleven every BF support is exactly the
15 S--S types plus A.  At order thirteen, only six of 318 poles have any S--T
type; their S--T support sizes are 10,13,13,13,16,17.  Across the six, every
individual S--T type occurs, but no pole has more than 17.

The unique 17-type pole is the 31-matching pole of Notes 005 and 007.  Its
S--T support graph is

\[
K_{1,1}\sqcup K_{4,4},
\]

with small block \(13\)--\(45\); the missing eight types are exactly the
remaining row and column.  It contains all five disjoint S--T types, and all
seven actual disjoint completion edges are SS.  Thus even the five required
types with safe routing are insufficient.  Its active \(W(H)\) is
disconnected, with component sizes 3 and 14.

For the other five S--T-active poles, \(W(H)\) is connected and every one has
an A-route completion.  This isolates the conjecture:

> In an exact-\(S\) cubic 5-pole, connectedness of \(W(H)\) forces at least
> one disjoint S--T completion of class A or TT.

If true, it excludes Case XII.  All 25 S--T types make the quotient on the
ten boundary classes \(K_{5,5}\); within-class exchange connectivity then
makes \(W(H)\) connected.  But Case XII forbids A and TT, contradicting the
conjecture.

This is a pole-level joint-closure target, not a theorem yet.  It combines
actual perfect matchings, BF completion, alternating-cycle exchange and route
orientation; type-level closure alone cannot express it.

The complete audit and data are
`scratch/worker-kempe/exact_st_joint_audit.py` and
`scratch/worker-kempe/exact_st_joint_through13.json`.

