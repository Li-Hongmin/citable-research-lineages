> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact negative support transfers a class-four singleton within the right seed cell

**Subsequent consequence.** [Note 132](132-mixed-side-right-cell-forces-an-s-tait-colouring.md) combines the involution below with half-load saturation and Note 130 to show that, in the mixed-side \(4+1\) setting, the existence of this right cell already forces an \(S\)-Tait colouring. Statements below about its Tait-empty profiles remain valid conditional implications, but that branch has no realization under the stated negative support.

The right \((25)(34)\) row in [Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md) has a concrete internal transport that is unavailable in its seven-vertex counterexample. The transport keeps the complete matching masks \(B_2,Y_3,r_{34}\) fixed, replaces only the class-four singleton in the \(T\)-half, and returns to the **same** \((25)(34)\) BF cell. It uses the absence of every \(T\)-loop and \(T\)--\(T\) BF type; it does not require all forty positive Case-XII cells.

## Fixed-identity two-switch transport

Write \(S=\{13,14,24,25,35\}\) and \(T=\{12,15,23,34,45\}\).

Let \(H\) be any cubic five-pole whose complete BF support has no \(T\)-loop and no \(T\)--\(T\) type. Suppose actual complete perfect matchings give a BF row
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1.              \tag{1}
\]
The subscript of a singleton is its terminal; a triple subscript is its missing pair. Then there exist actual matchings \(Z_4,q^{\mathrm{new}}_{25},D^{\mathrm{new}}_5\) with
\[
\boxed{q^{\mathrm{new}}_{25}+B_2+D^{\mathrm{new}}_5
       +r_{34}+Y_3+Z_4=2\mathbf1.}                         \tag{2}
\]
Moreover, the two class-four matchings satisfy the exact half-load identities
\[
q_{25}+B_2+D_5=q_{24}+B_2+Z_4,
\qquad
q_{24}+B_2+C_4=q^{\mathrm{new}}_{25}+B_2+D^{\mathrm{new}}_5. \tag{3}
\]
The \(q_{24}\) in both equations is the same complete matching.

**Proof.** Put \(A=q_{25}+B_2+D_5\) and \(R=r_{34}+Y_3+C_4\). They are degree-three integral half-loads with unit load on every terminal, and \(A+R=2\mathbf1\). The state of \(A\) is \(25\in S\), while the fixed state of \(R\) is \(34\in T\).

Switch the bichromatic terminal path between the \(q_{25}\) and \(D_5\) colours in a three-edge-colouring of the edge-copy multigraph \(A\). The path begins at terminal \(5\) and ends at one of the triple-colour terminals \(1,3,4\). Its new state is consequently \(21\), \(23\), or \(24\). The first two lie in \(T\) and, combined with the unchanged \(R\), would give a forbidden \(T\)--\(T\) BF row (or a forbidden \(T\)-loop). Therefore the endpoint is \(4\). The third colour \(B_2\) is untouched, giving the first identity in (3) with an actual \(Z_4\).

Now exchange the two class-four occurrences \(Z_4\) and \(C_4\) between the halves. This is a literal occurrence exchange, so
\[
(q_{24}+B_2+C_4)+(r_{34}+Y_3+Z_4)=2\mathbf1.         \tag{4}
\]
The second half retains the \(T\)-state \(34\). Switch the bichromatic terminal path between \(q_{24}\) and \(C_4\) in the first half of (4). Its endpoint is one of the triple-colour terminals \(1,3,5\), giving state \(21\), \(23\), or \(25\). The first two would again produce forbidden \(T\)--\(T\) support with the second half fixed. Thus the endpoint is \(5\); the switch leaves \(B_2\) unchanged and gives the second identity in (3). Combining it with the fixed second half of (4) proves (2). \(\square\)

This argument uses actual matching masks at every step. In particular, it preserves the literal \(B_2,Y_3,r_{34}\) identities, not only their boundary classes. It is a more specific use of the half-load Kempe closure in [Note 055](055-half-load-column-saturation-and-case-xii-compression.md); [Note 057](057-overlap-cells-transport-singleton-fibres-into-d5.md) transports witnesses from overlapping to disjoint cells, whereas (2) returns to the original cell.

For ordered rows with fixed \(B_2,Y_3,r_{34}\), the construction is an involution. Applying it to (2), the first terminal-path switch reverses the last switch above, the class-four exchange reverses itself, and the final switch reverses the first one. The terminal paths are unique in their respective bichromatic edge-copy subgraphs. When \(h(Y_3)=0\), this involution has no fixed row because it reverses the exceptional-edge bit of \(C_4\).

## Consequence for a mixed-side two-edge bipartization

Assume additionally the mixed-side \(4+1\) setting of [Note 127](127-two-edge-bipartization-profiles-and-tait-blockers.md), with the sole minority-side terminal \(y=2\). Let \(e\) lie inside the four-terminal part and \(f\) inside the one-terminal part. For an \(X\)-singleton \(U\), write \(h(U)\in\{0,1\}\) for its common \((e,f)\)-bit; a singleton at \(2\) has profile \((1,0)\). In (1), the triple \(q_{25}\) has profile \((0,1)\), and the \(T\)-triple \(r_{34}\) has profile \((0,0)\) because a \((1,1)\) profile would extend to a forbidden state-\(34\) Tait colouring. Edge load two therefore gives
\[
h(D_5)+h(Y_3)+h(C_4)=1.                              \tag{5}
\]
The first identity in (3), with \(q_{24}\) also missing a cross \(Xy\) pair, gives
\[
h(Z_4)=h(D_5).                                      \tag{6}
\]
Thus if \(h(Y_3)=0\), equations (5)--(6) give
\[
\boxed{h(Z_4)=1-h(C_4),}                             \tag{7}
\]
and the two right-cell BF rows (1)--(2) realize **both** class-four exceptional-edge profiles while keeping the *same complete* \(B_2\) mask. Equivalently, the projection of \(\Lambda_R\) to the two exceptional-edge coordinates contains both \((1,0)\) and \((2,1)\) within one fixed-\(B_2\) fibre. If \(h(Y_3)=1\), then \(h(D_5)=h(C_4)=h(Z_4)=0\); this transport does not change the class-four profile.

In the genuine seven-vertex pole of [Note 128](128-mixed-side-unique-companion-can-fail-the-full-cycle-phase.md), the displayed right row has \(h(Y_3)=0\), \(h(C_4)=0\), and \(h(D_5)=1\), yet its right spectrum contains no class-four \((1,1)\) occurrence. Equations (2)--(7) identify exactly where that example fails the proof: its complete BF support includes forbidden \(T\)-loops and \(T\)--\(T\) types, so the Kempe endpoint need not be forced to the \(S\)-state \(24\).

## Left-cell companion transport

The same operation changes the complete class-two mask in the left seed cell while retaining its class-four mask. From any row
\[
q_{14}+A_1+C_4+r_{23}+B_2+X_3=2\mathbf1,                \tag{8}
\]
one obtains an actual row
\[
q^{\mathrm{new}}_{14}+A^{\mathrm{new}}_1+C_4
       +r_{23}+B^{\mathrm{new}}_2+X_3=2\mathbf1.          \tag{9}
\]
Indeed, in the \(S\)-half switch the \(q_{14},A_1\) terminal path from state \(14\) to \(24\), leaving \(C_4\) untouched; its other possible endpoints would give \(T\)-states against the fixed state \(23\). Exchange the new class-two singleton with \(B_2\) in the \(T\)-half. Finally switch the resulting \(q_{24},B_2\) path back to state \(14\), again retaining \(C_4\). Thus (9) fixes the literal \(C_4,r_{23},X_3\) masks. The right operation (2) instead fixes \(B_2,r_{34},Y_3\). Neither operation identifies the complete masks selected independently in the two cells.

Equation (7) removes the simple two-coordinate separation exhibited by that counterexample under the exact negative support. It does **not** prove \(\Lambda_L\cap\Lambda_R\ne\varnothing\): the new \(Z_4\) need not be the left row's class-four matching as a complete mask, and the left and right class-three matchings and complementary loads may still differ. The surviving mixed-side right-row case for this transport is \(h(Y_3)=1\), and the full pair-load intersection remains the main open statement.

That residual case has a sharper form. Equation (5) makes \(h(C_4)=h(D_5)=0\). Apply the cycle-or-terminal-path criterion of Note 128 to \(C_4,Y_3\). If their exceptional edges lie on a closed component of \(C_4\triangle Y_3\), a paired switch in the **original** right row changes \(C_4\) to profile \((1,1)\) while keeping \(B_2\) and the row load fixed. Apply the same criterion to \(D_5,Y_3\). If their exceptional edges lie on a closed component, switch that pair instead: the row then has \(h(Y_3)=0\), \(h(D_5)=1\), and (7) changes the class-four profile with the same \(B_2\). Therefore a fixed-right-row profile obstruction requires the two edges to lie on the terminal paths of **both** \(C_4\triangle Y_3\) and \(D_5\triangle Y_3\).

Exact absence of \(T\)-loops adds two intersections in this residual branch: \(C_4\cap Y_3\ne\varnothing\) because \(34\in T\), and \(C_4\cap D_5\ne\varnothing\) because \(45\in T\). Disjoint singleton matchings in either \(T\)-pair would have a complementary triple matching and give a forbidden Tait state. The two shared edges must be distinct in the BF row, since every edge has load two. Thus the remaining local configuration has two specified shared edges and two open alternating terminal paths carrying \(e,f\), alongside the independent full-mask synchronization across left and right rows.

[Note 130](130-the-mixed-side-right-row-exceptional-class-three-forces-an-s-tait-state.md) resolves the **Tait-empty** part of this residual profile: the same \(h(Y_3)=1\) row forces an actual \(S\)-Tait state by following the \(S\)-carrier through states \(35,13,14\) and ruling out a zero-exceptional-edge half-load. Hence the shared-edge terminal-path configuration above can survive only in the branch whose Tait-state set is all of \(S\). Full-mask synchronization remains open in both branches.
