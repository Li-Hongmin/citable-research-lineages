> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adjacent two-edge bipartization is impossible in exact Case XII

[Note 125](125-no-single-edge-bipartization-in-exact-case-xii.md)
excludes deletion of one proper edge as a way to make an exact-Case-XII
five-pole bipartite. Even two *adjacent* proper edges cannot do so. Thus any
minimum odd-cycle edge transversal of size two, if one exists, consists of
disjoint edges. The proof uses only all twenty-five \(S\)--\(T\) BF types
and the absence of \(T\)-loops.

Let \(e_1,e_2\) be proper edges sharing a vertex \(v\). Suppose the
proper-edge graph \(H-\{e_1,e_2\}\) is bipartite with parts \(X,Y\). By
Note 125, neither \(H-e_1\) nor \(H-e_2\) is bipartite. Hence each
deleted edge joins two vertices in the same part; otherwise restoring
that edge alone would keep a bipartition. Because the edges share \(v\),
both lie inside one part, say \(X\). Put \(t_X+t_Y=5\) for the semiedge
counts. Counting the proper-edge ends gives
\[
3|X|-t_X-4=3|Y|-t_Y,
\quad t_X-t_Y=3(|X|-|Y|)-4.                         \tag{1}
\]
The only possible values of \(t_X-t_Y\) are \(-1\) and \(5\), so
\[
(t_X,t_Y,|X|-|Y|)=(2,3,1)
\quad\text{or}\quad(5,0,3).                         \tag{2}
\]

For any perfect matching \(P\), let \(z=|P\cap\{e_1,e_2\}|\). Since
\(e_1,e_2\) are adjacent, \(z\in\{0,1\}\). If \(a_X,a_Y\) are the
numbers of semiedges used on the two sides, matching the remaining
vertices across the bipartition gives
\[
a_X-a_Y=|X|-|Y|-2z.                            \tag{3}
\]

In the \((2,3)\) case, a triple matching uses \((a_X,a_Y)=(2,1)\) when
\(z=0\), or \((1,2)\) when \(z=1\). A triple containing all three
\(Y\)-side semiedges would need \(z=2\), which is impossible. Thus the
pair of \(X\)-side terminal labels is absent from every BF missing-pair
label, contrary to the twenty-five \(S\)--\(T\) types.

In the \((5,0)\) case, (3) gives \(a_X=3-2z\). Every triple matching
avoids both \(e_1,e_2\). Choose one whose missing-pair label \(t\in T\),
as required by Case XII. Call it \(Q\). The complement \(H-Q\) contains
both deleted edges, and at their shared vertex it uses both; therefore
any component using one of them also uses the other. Every closed
component contains either zero or two edges internal to \(X\), and all
other proper edges cross the bipartition. It is therefore an even cycle.
The one component with the two semiedges has endpoints in \(X\), uses
zero or two internal \(X\)-edges, and has an even number of cross edges;
including the two semiedges, it is an even path. Alternately colouring
these components extends \(Q\) to a Tait colouring of state \(t\).
Doubling it yields the forbidden BF loop \([t]\).

Both distributions contradict the Case-XII support. Hence
\[
\boxed{H-\{e_1,e_2\}\text{ is non-bipartite for every adjacent
proper-edge pair }e_1,e_2.}                         \tag{4}
\]
This theorem does not exclude a **disjoint** two-edge odd-cycle
transversal, and it does not force the common-\(B,C\) pair-load
intersection of
[Note 118](118-common-bc-case-xii-seed-survives-all-bf-covered-two-sums.md).

## No one-vertex odd-cycle transversal

The same support hypotheses also imply that \(H-v\) is non-bipartite for
every vertex \(v\). If \(H-v\) were bipartite, colour \(v\) opposite one
of its proper-edge neighbours and delete the other proper edges incident
with \(v\). The resulting proper-edge graph is bipartite: its retained
edge at \(v\) crosses the chosen bipartition. At most two deleted edges
are adjacent at \(v\). Zero, one, and two deletions contradict Note 124,
Note 125, and (4), respectively. If \(v\) has no proper-edge neighbour,
adjoin it as an isolated vertex to the bipartition and use Note 124.
Therefore
\[
\boxed{H-v\text{ is non-bipartite for every vertex }v.} \tag{5}
\]
Equations (4) and (5) say that the odd cycles of an exact-Case-XII pole
have neither a common edge nor a common vertex. They do not assert that
two vertex-disjoint odd cycles exist.
