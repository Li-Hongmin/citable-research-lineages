> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two central-path cross rows share one pure exterior in the left branch

> **Correction (2026-10-01):** [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md)
> finds that the \(h_3\) route in equation (5) ends at \(d\), not
> \(c\), against \(X_{c,R}\). The proof below therefore does not
> exclude the right \((ea)(ad)\) exterior. Its left table and
> subsequent left-template calculations remain valid **under that
> additional orientation assumption**; uniqueness and the shared
> pure exterior have not been established from exact support.
>
> **Further correction:** [Note 357](357-a-left-central-ac-row-does-not-fix-the-pentagon-order.md)
> gives a real left \((ea)(ac)\) row with the opposite shore \(e\)-path
> pairing. The left-row exterior alone does not fix the allowed pentagon;
> deriving \(S=e-a-b-d-c-e\) from that row requires its \(E\)--\(h_1\)
> pairing. The calculations below using that \(S\) remain conditional on
> the pentagon being fixed by this pairing or independently.

Continue the minimum-host, complete exact-Case-XII, one-internal-mark profile of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md). Write
\[
K=\{1A,1B,2B,2C,3C,3D,4D,4E\},\qquad
a:C\!:\!\Sigma,\quad b:AD,\quad c:AE,\quad d:BE,
\]
and let \(h_i=u_i\Sigma\). The published [Case-XII support table](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), Appendix XII, requires real rows of types \((ea)(ac)\) and \((ea)(ad)\). Reflect the path so that Note 271's \((ea)(ac)\) row uses its left mask
\[
Y_L=\{c:A,b:D,d:E,1B,2C,h_3,h_4\}.                \tag{1}
\]
The forced singleton-\(e\) mask in that row sends the shore port \(h_1\) to \(b\) against its state-\(ea\) triple and to \(d\) against the switched state-\(ec\) triple. **If** its shore \(e\)-path reaches \(h_1\), the allowed pentagon is
\[
S=e-a-b-d-c-e.                                         \tag{2}
\]
In particular \(ad\in T\), so the \(ea\) half of every \((ea)(ad)\) row is pure \(S\).

**Conditional theorem (left branch).** If a real \((ea)(ad)\)
row uses \(Y_L\) for its two singleton-\(a\) occurrences, then
its exterior masks are those of Table (3). In this branch the
\((ea)(ac)\) and \((ea)(ad)\) rows have *identical exterior masks
in their pure \(ea\) halves*, although the complete shore
matchings need not agree across rows. In either left-template row,
the two singleton-\(a\) shore matchings differ on alternating
cycles whose union meets both the \(e\)--\(h_1\) and
\(a:\Sigma\)--\(h_2\) shore paths of the pure half.

| Slot | Boundary | Exterior mask | Shore ports |
|---|---|---|---|
| \(X_a\) | \(b,c,d\) | \(\{a:C,1A,2B,3D,4E\}\) | \(\varnothing\) |
| \(Y_a\) | \(a\) | \(Y_L\) | \(\{h_3,h_4\}\) |
| \(Z_e\) | \(e\) | \(\{a:\Sigma,b:A,c:E,d:B,3C,4D,h_1,h_2\}\) | \(\{e,a:\Sigma,h_1,h_2\}\) |
| \(U_{ad}\) | \(b,c,e\) | \(\{a:C,d:B,1A,3D,4E,h_2\}\) | \(\{e,h_2\}\) |
| \(V_a\) | \(a\) | \(Y_L\) | \(\{h_3,h_4\}\) |
| \(W_d\) | \(d\) | \(\{a:\Sigma,b:A,c:E,2B,3C,4D,h_1\}\) | \(\{a:\Sigma,h_1\}\) |

**Table (3).** The forced exterior \((ea)(ad)\) row. Each proper exterior edge and terminal semiedge has load two. The pure \(X_a+Y_a+Z_e\) exterior is exactly the pure half of Note 271's Table (5), with load one on each exterior edge.

## The left-row load calculation

Write a required real row as
\[
X_a+Y_a+Z_e+U_{ad}+V_a+W_d=2\mathbf1.             \tag{4}
\]
The zero-port quota of [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) fixes \(X_a\). Since \(ad\in T\), exchanging the **complete** singleton-\(a\) occurrences \(Y_a,V_a\) leaves the opposite state \(ad\) and total load unchanged, so both resulting \(ea\) halves are pure \(S\). Each singleton-\(a\) exterior is therefore \(Y_L\) or Note 271's reflected \(Y_R\). Note 271's 16-mask route table shows that a fixed \(Z_e\) cannot support both sides; hence \(Y_a,V_a\) use the same side.

Suppose both use \(Y_R=\{c:E,b:A,d:B,3C,4D,h_1,h_2\}\). Its edges are saturated. The state-\(ad\) triple \(U_{ad}\) must select \(d:E\). If it selected \(a:\Sigma\), its unique exterior completion would contain the already saturated \(3C,4D\). Thus it selects \(a:C\), and the matching quota fixes its other edges to \(1A,2B,3D,h_4\). These choices force
\[
Z_e=\{a:\Sigma,b:D,c:A,d:E,1B,2C,h_3,h_4\}.       \tag{5}
\]
Against \((X_a,X_{c,R})\), where
\(X_{c,R}=\{c:E,1A,2B,3C,4D\}\) is obtained by the exterior
\(a\)--\(c\) switch, the routes from \((h_3,h_4,a:\Sigma)\)
actually end at \((b,d),(d,b),(c,a)\), respectively. Thus \(h_3\)
**does** give the required \(b\to d\) exchange. The original
right-side exclusion at this point was false; the full right row
and its actual realization are in [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md).

**Conditional left branch.** If both singleton-\(a\) occurrences
use \(Y_L\), they saturate \(c:A,b:D,d:E,1B,2C,h_3,h_4\).
The state-\(ad\) triple must select \(d:B\). Selecting
\(a:\Sigma\) would force its unique \(K\)-completion
\(1A,2C,3D,4E\), using saturated \(2C\). It therefore selects
\(a:C\), and its remaining exterior is \(1A,3D,4E,h_2\).
All other entries of Table (3) now follow edge by edge from
load two and their terminal boundaries: \(Z_e\) must use
\(a:\Sigma,b:A,c:E,d:B,3C,4D,h_1,h_2\), and \(W_d\)
must use \(a:\Sigma,b:A,c:E,2B,3C,4D,h_1\). This verifies
the displayed loads for the left branch. \(\square\)

## The two left-row shore intersections

For the shared pure exterior, the routes from \((h_1,h_2,a:\Sigma)\) end at \((b,d),(d,c),(c,a)\) against \((X_a,X_{c,L})\), where \(X_{c,L}=\{c:A,1B,2C,3D,4E\}\). Since \(ab,cd\in S\) but \(ac,ad\in T\), purity pairs the shore ports as
\[
e\longleftrightarrow h_1,\qquad a:\Sigma\longleftrightarrow h_2. \tag{6}
\]
In the \((ea)(ac)\) row, the opposite slots split these four ports as \(\{e,a:\Sigma\}\mid\{h_1,h_2\}\); in Table (3), they split them as \(\{e,h_2\}\mid\{a:\Sigma,h_1\}\). Both paths in (6) cross either partition. Applying the edge-label argument of [Note 254](254-the-b-cross-rows-require-shore-cycle-intersections.md) separately to each row, each path must share an internal edge with the symmetric difference of its two complete singleton-\(a\) shore matchings. In particular those two matchings cannot be equal in either row. This conclusion is rowwise; it does not identify any complete matching across the two rows.

## Left-branch one-path transfer criterion

The opposite two slots of Table (3) have a precise alternating-path test. In \(U_{ad}\triangle W_d\), the exterior continuations send \((h_2,a:\Sigma,h_1)\) to \((d,c,b)\), while the port \(e\) is terminal \(e\) itself. If its shore part pairs \(h_2\) with \(a:\Sigma\), the complete \(d\)--\(c\) alternating path can be switched. The resulting full-pole matchings have boundaries \(\{b,d,e\}\) and \(\{c\}\), with exactly the \(U_{ac},W_c\) exterior masks in Note 271's Table (5). Replacing \(U_{ad},W_d\) by them turns the same six-occurrence load-two row into a real \((ea)(ac)\) row with its pure \(ea\) half unchanged.

There are only two other shore pairings of these four ports. Pairing \(e\) with \(a:\Sigma\) and \(h_2\) with \(h_1\) makes the switch at \(d\) end at \(b\), yielding an \((ea)(ab)\) row. Pairing \(e\) with \(h_2\) and \(a:\Sigma\) with \(h_1\) makes it end at \(e\), yielding an \([ea]\) row. Thus a **single component switch involving the singleton terminal \(d\)** reaches the required \(ac\) state exactly in the first pairing. Conversely, in Note 271's \((ea)(ac)\) row the exterior continuations of \(U_{ac}\triangle W_c\) send \((a:\Sigma,h_1,h_2)\) to \((c,b,d)\), while \(e\) is terminal \(e\); switching its singleton-\(c\) path reaches \(ad\) exactly when the shore pairs \(a:\Sigma\) with \(h_2\). These are tests for a fixed row, not a claim that different rows share the same pure shore masks. All three outputs are allowed Case-XII types, so boundary support alone does not select the transfer pairing.

The six-slot load-two equation gives the shore identity
\[
\bigl(X_a\triangle Z_e\bigr)\triangle
\bigl(U_{ad}\triangle W_d\bigr)=Y_a\triangle V_a.   \tag{7}
\]
It holds edge by edge, including the four shore ports, because every edge belongs to exactly two slots. The left side compares two four-port path systems: the pure pairing (6) and the opposite pairing tested above. Thus the singleton-\(a\) alternating cycles are exactly the mod-two change between them. Their existence and intersection with both pure paths do not by themselves fix how the four ports are reconnected; that reconnection is the remaining one-row phase datum.

## The fixed pure port partition has only allowed Tait states

There is no forbidden-Tait shortcut through the shared pure half's three shore port sets
\[
\varnothing\mid\{h_3,h_4\}\mid\{e,a:\Sigma,h_1,h_2\}.       \tag{8}
\]
If three exterior perfect matchings with these respective port sets partition every proper exterior edge and terminal semiedge once, their zero-port slot is a state-\(ej\) triple, the middle slot is singleton \(j\), and the four-port slot is singleton \(e\). The only possibilities are \(j=a,c\), with exactly the two exterior unit partitions obtained from \(X_a+Y_L+Z_e\) by its exterior \(a\)--\(c\) switch. Thus a shore three-edge colouring with the port partition (8) glues only to allowed \(ea\) or \(ec\) Tait states.

Here is the complete exterior check. For \(j=b\), a singleton-\(b\) mask with ports \(h_3,h_4\) cannot cover the singleton vertex \(D\): its only incident mark half is \(b:D\), while \(u_3,u_4\) are already at ports. For \(j=d\), the sole middle-slot mask is \(\{a:C,b:D,c:E,1A,2B,h_3,h_4\}\); either zero-port state-\(ed\) triple uses \(1A\), so exterior unit load is impossible. For \(j=a\), the only middle-slot mask disjoint from the forced \(X_a\) is \(Y_L\), and the four-port complement is \(Z_e\) in Table (3). For \(j=c\), the sole middle-slot mask is \(\{a:C,b:D,d:E,1A,2B,h_3,h_4\}\); among the two zero-port state-\(ec\) triples only \(\{c:A,1B,2C,3D,4E\}\) is disjoint from it, and the four-port complement is again the displayed \(Z_e\). This proves the classification without assumptions on the shore interior. It excludes only this fixed-port route to a forbidden Tait state, not other port partitions or nonunit BF rows.

The opposite halves of the two forced rows give two explicit forbidden shore Tait signatures. An exact-Case-XII shore cannot have a three-edge colouring with respective port sets
\[
\{e,h_2\}\mid\{h_3,h_4\}\mid\{a:\Sigma,h_1\},
\qquad
\{e,a:\Sigma\}\mid\{h_3,h_4\}\mid\{h_1,h_2\}.  \tag{9}
\]
Indeed, the corresponding three exterior masks in Table (3) or Note 271's Table (5) also partition every exterior edge once. Gluing would give a Tait colouring in the forbidden state \(ad\) or \(ac\), respectively, and doubling it would give a forbidden BF loop. Thus any real required row of either type has a nonunit shore load in its opposite half.

## Real rows and the matching-closure boundary

Each template is individually realizable by an actual pole. Take the 12-vertex shore and its six explicit perfect matchings from [Note 254](254-the-b-cross-rows-require-shore-cycle-intersections.md). For Table (3), identify its ports \((H,E,I,J,D,A)\) with \((h_3,e,h_1,h_4,h_2,a:\Sigma)\). Its slots \((X,Y,Z,U,V,W)\) then have exactly the six required shore port sets, and every shore edge has load two. Gluing Table (3) gives a connected cubic 25-vertex five-pole with a real \((ea)(ad)\) BF row. Its \(U\triangle W\) shore paths have edge sequences \(E,p_1,c_0,c_5,p_5,A\) and \(D,p_4,c_3,c_2,p_2,I\). They pair \(E\)--\(A\) and \(D\)--\(I\), so the one-path switch above reaches \(ab\). This shore has no matching with port set \(\{E,A\}=\{e,a:\Sigma\}\), so it cannot also realize Note 271's displayed \((ea)(ac)\) row.

For Note 271's \((ea)(ac)\) template, instead identify \((H,E,I,J,D,A)\) with \((h_3,e,h_1,h_4,a:\Sigma,h_2)\). The same six shore matchings now have Note 271's port sets, giving a real \((ea)(ac)\) row in another connected cubic 25-vertex five-pole. Its shore has no \(\{E,A\}=\{e,h_2\}\) matching, so it cannot realize Table (3). These two gluing certificates establish individual rowwise feasibility. Neither pole has exact Case-XII support: independently, [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md) puts every simple connected exact-Case-XII pole at order at least 33.

**Real counterexample to the local completion shortcut.** Use [Note 255's modified 12-vertex shore](255-seven-shore-port-states-do-not-supply-the-second-b-cross-row.md), with the first identification above. Its explicit six shore matchings give the real \((ea)(ad)\) row of Table (3), and its two extra shore matchings provide the \(\{e,a:\Sigma\}\) and \(\{h_1,h_2\}\) states required by Note 271's \((ea)(ac)\) template. Every one of that template's six individual full-pole matchings therefore exists. Nevertheless, both \(\{h_3,h_4\}\)-port matchings contain the shore edges \(q_{15},q_{24}\), every \(\{e,a:\Sigma\}\)-port matching contains \(q_{24}\), and every \(\{h_1,h_2\}\)-port matching contains \(q_{15}\). Any such \((ea)(ac)\) row would load these two edges at least three times. The resulting connected simple cubic 25-vertex five-pole is a counterexample only to individual-matching sufficiency for these fixed exterior templates; it is not an exact-Case-XII pole.

This modified shore also avoids **both** forbidden Tait signatures (9). The \(ac\) signature is impossible by the same \(q_{15},q_{24}\) overload. For the \(ad\) signature, the \(\{e,h_2\}\) shore matching is uniquely \(\{c_0,c_3,p_2,p_5,q_{03};e,h_2\}\): ports at \(r_1,r_4\) force \(p_2,p_5\), and omitting \(q_{03}\) would leave the nonadjacent central vertices \(s_1,s_4\). Similarly, the unique \(\{a:\Sigma,h_1\}\) matching is \(\{c_2,c_5,p_1,p_4,q_{03};a:\Sigma,h_1\}\): omitting \(q_{03}\) would leave \(s_2,s_5\). These two matchings share \(q_{03}\), so no unit shore colouring has the \(ad\) port partition. Thus one real \(ad\) row, every individual matching needed for the \(ac\) template, and the absence of both forbidden Tait partitions **still do not force** the second row. The conclusion concerns the fixed templates in this actual 25-vertex pole; complete exact-Case-XII support is absent by [Note 226](226-published-order-thirty-six-bf-bound-raises-exact-case-xii-poles-to-thirty-three.md).

The two required exterior rows are compatible at the level of individual masks and load two. Their simultaneous realization in one six-port shore, with complete exact-Case-XII negative support, remains the unresolved condition. The route classification and two-row derivation are hand proofs awaiting independent verification; they do not exclude the marked exterior or settle Berge--Fulkerson.
