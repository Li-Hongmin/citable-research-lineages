> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A right \((ea)(eb)\) row forces a forbidden \((eb)(bc)\) completion

> **Later consequence:** [Note 356](356-the-left-eb-row-also-forces-a-forbidden-u-a-completion.md) excludes the remaining left \((ea)(eb)\) row. Together they exclude the central-path marked exterior under the cited classifications.

Work in the central-path six-port exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact-Case-XII perfect-matching support. Put \(S=e-a-b-d-c-e\), so \(eb,bc\in T\). The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) forbids every \(T\)--\(T\) BF type. The right-row normalization and direct \(e\to c\) endpoint below depend on the hand-derived classifications of [Notes 346 and 353](353-every-central-path-eb-row-has-a-direct-c-bridge.md).

For the appendix's numeric labels, take \((e,a,b,d,c)=(1,3,5,2,4)\). Then the required input type is \((13)(15)\), which is listed in Case XII, while the output \((15)(45)\) is absent.

**Theorem.** No genuine central-path \((ea)(eb)\) row has the right singleton-\(a\) exterior mask \(Y_R\). Consequently, under the cited classifications, every such row must use the left orientation. The theorem holds for an arbitrary six-port shore order and cycle rank; it does not exclude the left orientation or the full exact Case XII.

**Proof.** By Note 353's right-row normalization, one wholly exterior closed-cycle switch if necessary gives a real row
\[
                 X_{ea}+Y_{R,a}+F_e+U_{A,eb}+M_e+W_b=2\mathbf1,       \tag{1}
\]
where \(M_e\) is III \(a:C,2B\) and \(F_e\) is IV \(a:\Sigma,1A,2C\). In particular the relevant exterior masks are
\[
\begin{array}{c|l|c}
 &\text{selected exterior edges besides terminal semiedges}&\text{shore ports}\\\hline
X& a:C,1A,2B,3D,4E&\varnothing\\
Y_R& b:A,c:E,d:B,3C,4D&I,D\\
U_A& b:A,1B,2C,3D,4E&\varnothing\\
M& a:C,b:D,c:A,d:E,2B&I,H,J\\
F& a:\Sigma,b:D,c:E,d:B,1A,2C&A,H,J\\
W& a:\Sigma,c:A,d:E,1B,3C,4D&A,D.
\end{array}                                                        \tag{2}
\]
The selected terminal semiedges are \(bcd,a,acd,e,e,b\), respectively; the shore port \(E=e\) is selected by \(M,F\). Note 353 proves that the \(e\)-starting component of \(U_A\triangle M\) ends at \(c\), with shore segment joining \(E,H\). Switch this complete component between \(U_A,M\). Write \(U'\) for the resulting triple matching with terminal set \(ade\), and \(C_c\) for the resulting singleton. Their exterior masks and shore ports are
\[
\begin{aligned}
U'|_{\rm ext}&=\{b:D,c:A,1B,2C,4E,H;\ a,d,e\},
 &\partial_\Sigma U'&=\{E,H\},\\
C_c|_{\rm ext}&=\{a:C,b:A,d:E,2B,3D,I,J;\ c\},
 &\partial_\Sigma C_c&=\{I,J\}.                           \tag{3}
\end{aligned}
\]
The switch preserves the row load, giving an actual \((ea)(bc)\) row
\[
                    X+Y_R+F+U'+C_c+W=2\mathbf1.             \tag{4}
\]

Remove the three complete matchings \(F,C_c,W\) from (4), and write
\[
                         R=X+Y_R+U'=2\mathbf1-F-C_c-W.       \tag{5}
\]
The exterior admits a singleton-\(b\) matching mask
\[
             B_b|_{\rm ext}=\{a:C,c:A,d:B,3D,4E,I,D;\ b\}.  \tag{6}
\]
It covers every exterior vertex once: its central-path choices are \(c:A,d:B,a:C,3D,4E\), its path-subdivision choices are \(I,D,3D,4E\), and its marked \(b\)-vertex uses the terminal semiedge. Its proper shore ports \(I,D\) are exactly those of the **complete** \(Y_R\) matching. Glue (6) to the unchanged shore restriction of \(Y_R\), obtaining a complete actual perfect matching \(B_b\). It is contained edgewise in \(R\): on the exterior, \(b,a:C,3D\) come from \(X\), \(c:A\) from \(U'\), \(d:B,I,D\) from \(Y_R\), and \(4E\) from \(X\) or \(U'\); on the shore, \(B_b|_\Sigma=Y_R|_\Sigma\).

The edge-copy residual \(R-B_b\) has degree two at every internal vertex. On the shore it is exactly \(X|_\Sigma+U'|_\Sigma\). Because \(X\) is zero-port and \(U'\) has just \(E,H\), this sum has one \(E\)--\(H\) open path and only even closed alternating cycles, including possible two-edge parallel cycles. Outside the shore there is one path from terminal \(c\) to \(H\), with the following **twelve edge copies in order**, including its terminal and port semiedges:
\[
 c_{\rm term},\ c:E,\ 4E,\ 4D,\ b:D,\ b:A,\
 1A,\ 1B,\ 2B,\ 2C,\ 3C,\ H .                         \tag{7}
\]
These are all exterior residual edges apart from two copies of each of the \(a,d\) terminal semiedges; in particular there is no exterior closed component. The shore \(E\)--\(H\) alternating path has odd length \(2m+1\) including its two port semiedges, because both belong to \(U'\). Gluing it to (7) replaces the two \(H\) semiedges by one proper edge, so the complete \(e\)--\(c\) path has length \(12+(2m+1)-1=2m+12\), which is even. Give one copy of each doubled \(a,d\) terminal semiedge to each colour. Alternating two colours along the \(e\)--\(c\) path and every even closed component then splits \(R-B_b\) into actual perfect matchings \(Q_{acd},Q_{ade}\), each using \(a,d\) and exactly one of \(c,e\):
\[
                           R= B_b+Q_{acd}+Q_{ade}.           \tag{8}
\]

Replace the three matchings \(X,Y_R,U'\) in (4) by (8), retaining the **complete** \(F_e,C_c,W_b\). The six matching occurrences still cover every edge twice. Group them as
\[
       (Q_{acd}+F_e+W_b)\quad\mid\quad(Q_{ade}+B_b+C_c).
\]
The first triple state misses \(e,b\), and the second misses \(b,c\). This is an actual forbidden \((eb)(bc)\) row, a contradiction. \(\square\)

The obstruction uses a complete matching glued to the *same* shore restriction as \(Y_R\), then checks the full residual components. It neither assumes an all-terminal perfect matching nor asks whether the \(IJ\) singleton-\(c\) candidate passes Note 345's cross-carrier owner/even-cycle gate. [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) already forbids all-terminal matchings in this deficient-core profile; that route is irrelevant to this contradiction. The left \((ea)(eb)\) row and the other Case-XII profiles remain open. The upstream mask and endpoint classifications are hand proofs pending independent verification.
