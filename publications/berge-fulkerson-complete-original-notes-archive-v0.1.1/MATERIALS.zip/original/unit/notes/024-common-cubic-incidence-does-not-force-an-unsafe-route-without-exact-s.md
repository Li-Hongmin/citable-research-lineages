> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Without exact-S, common cubic incidence does not force an unsafe route

The exact-\(S\) hypothesis in the exchange-connectivity conjecture of
Note 015 cannot be deleted.  There is a minimum-order simple connected cubic
5-pole whose active matching-level graph is connected and whose complete
perfect-matching closure realizes every \(S\)--\(T\) completion type, but all
of its disjoint \(S\)--\(T\) completions have route SS.  The example is not
exact-\(S\), so it is not a Case-XII pole and does not refute Note 015.

Fix the standard boundary partition

\[
S=\{13,14,24,25,35\},\qquad
T=\{12,15,23,34,45\}.
\]

## The order-thirteen pole

Take thirteen vertices \(0,\ldots,12\), with one semiedge incident with each
of \(0,1,2,3,4\), and proper edges

\[
\begin{aligned}
 &(0,8),(0,11),(1,7),(1,9),(2,9),(2,12),\\
 &(3,10),(3,12),(4,10),(4,11),(5,7),(5,8),\\
 &(5,9),(6,8),(6,11),(6,12),(7,10).
\end{aligned}
\]

This is a simple connected cubic 5-pole with distinct terminal vertices.  It
has 37 perfect matchings.  A designated family contains one
triple-boundary matching in each of the ten classes indexed by \(S\cup T\),
together with a second matching in class \(13\).  The two class-\(13\)
matchings differ on one proper alternating cycle of length eight.  The ten
base matchings have genuine four-singleton completions for all 25
\(S\)--\(T\) class pairs, and the extra class-\(13\) matching has another
completion with the chosen class-\(45\) matching.  Thus the designated
certificate has 26 six-perfect-matching double covers, using 32 distinct
perfect matchings; all six designated disjoint completions have route SS.

## Complete closure and active \(W(H)\)

The conclusion is not an artefact of the designated witnesses.  Closing over
all 37 perfect matchings gives all 25 actual \(S\)--\(T\) boundary-class
types and 45 actual matching-pair completion edges.  There are nine disjoint
completion edges, with exact route profile

\[
\mathrm{SS}:9,\qquad \mathrm A:0,\qquad \mathrm{TT}:0.
\]

An independent search for a capacity witness, equivalently a BF cover of
boundary type \((12345)\), returns none.  Under the definition of Note 015,
the completion subgraph has 14 matching vertices and 45 edges and is
connected.  Adding all five actual same-class single-cycle exchange edges
gives an active graph \(W(H)\) with 14 vertices and 50 edges, still connected.
Consequently the 25 cells are not merely quotient labels: every cell is
witnessed by a real completion in one common cubic pole, and the connectivity
is connectivity of the actual matching-level graph.

## Why Note 015 survives

The pole fails exactly the hypothesis that remains available after
Notes 017 and 021.  Its Tait lonely-pair state set is all ten pairs,

\[
H_{\mathrm{Tait}}(H)=K_5,
\]

rather than the five states in \(S\).  Its complete BF support independently
contains all ten distinct T--T pair types and all five T-loop types.  These
TT types do not occur as routes of the nine disjoint \(S\)--\(T\)
completions, but their presence proves that the pole is not exact-\(S\).

Therefore this example is not a Case-XII pole and is not a counterexample to
the conjecture of Note 015.  It strictly refutes only the stronger statement
obtained by deleting exact-\(S\): common simple connected cubic 5-pole
incidence, genuine perfect matchings, complete perfect-matching closure,
reuse of completion witnesses, a genuine single-cycle exchange, full actual
\(S\)--\(T\) support, and connected active \(W(H)\) still do not force an A
or TT disjoint route.  Any proof of Note 015 must use exact-\(S\), or an
equivalent mechanism that excludes the additional Tait and TT states.

## Minimum order within the stated class

The lower-order search is exhaustive for simple connected cubic 5-poles with
five distinct terminal vertices.  Such a pole is encoded by adjoining one
degree-five apex to its five semiedges and streaming unlabelled augmented
graphs with one degree-five and \(n\) degree-three vertices.  The scan gives

\[
\begin{array}{c|r|r|r|r}
n&\text{generated}&\text{right degree sequence}&\text{connected poles}
&\text{all singleton/triple classes}\\\hline
5&4&1&1&0\\
7&35&7&6&0\\
9&357&59&52&1\\
11&4291&581&536&41.
\end{array}
\]

The one order-nine survivor and all 41 order-eleven survivors were tested
under all 60 essential choices of pentagon partition and distinguished
disjoint class pair; none realizes the required family.  Orders below five
cannot have five distinct terminal vertices.  Hence the displayed
order-thirteen pole is minimum within this explicitly enumerated class.

The deterministic certificates are
`scratch/worker-kempe/cubic_incidence_realizability_scan.py` and
`scratch/worker-kempe/verify_cubic_all_ss_realization.py`.  The former streams
the lower-order enumeration and rediscovers the order-thirteen example; the
latter reconstructs all 37 perfect matchings, verifies the designated covers,
complete closure, active \(W(H)\), Tait states, and BF support, and terminates
with `CUBIC_ALL_SS_REALIZATION_VERIFIED`.
