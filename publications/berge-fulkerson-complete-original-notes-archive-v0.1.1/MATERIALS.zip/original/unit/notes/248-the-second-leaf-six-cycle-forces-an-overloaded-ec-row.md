> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The second-leaf six-cycle forces an overloaded \(ec\) row

Retain [Note 247's](247-the-second-leaf-six-cycle-has-one-marking-and-one-triple-switch.md) unique marked \(|U|=4,r=3\) exterior. Write \(O=w_0,L=w_1,R=w_2,P=p,Q=q\), and abbreviate \(u_iw\) by \(iw\). Thus
\[
K=\{1O,1L,2O,2R,3O,3P,4L,4R,4Q\},
\quad a:R-C,\ d:Q-C,\ b:L-P,\ c:P-Q,
\]
with shore edges \(h_i=u_iC\), \(i=1,2,3\), and internal mark \(e\). The allowed pentagon has \(ea,ed\in S\). The odd shore \(C\) has unrestricted order and matching relation.

**Theorem.** This marked exterior cannot have complete exact-Case-XII support. More precisely, a hypothetical pure-\(S\) half-load has only the order \(S=e-a-c-b-d-e\), and its singleton-\(e\) matching has the unique exterior mask
\[
Z_e|_{\rm ext}=
\{a:C,d:C,h_1,b:P,c:Q,4L,2R,3O\}.                     \tag{1}
\]
The required actual \((ea)(ec)\) BF row then violates edge load two after exchanging its two **complete** singleton-\(e\) matchings.

## The unique port-changing mask

Take a pure-\(S\) half \(D=X_a+Y_a+Z_e\) in state \(ea\). By Note 247, the exterior of \(X_a\) is \(a:R,1L,2O,3P,4Q\); switching the exterior \(a-R-u_4-Q-d\) path against \(Y_a\) gives a state-\(ed\) triple \(X_d\) with exterior \(d:Q,1L,2O,3P,4R\) and the **same complete shore mask**. In the two possible orders \(e-a-b-c-d-e\) and \(e-a-c-b-d-e\), purity requires the shore \(e\)-port paired against \(Z_e\) to be reached by terminal \(b\) then \(c\), or \(c\) then \(b\), respectively, in \(X_a\triangle Z_e\) and \(X_d\triangle Z_e\).

The singleton-\(e\) matching uses exactly three of \(a:C,d:C,h_1,h_2,h_3\) by [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md). It cannot use no mark-side shore half: if it used \(h_1,h_2,h_3\), then \(a:R,d:Q,c:P,b:L\) would occupy all four marked singleton endpoints, leaving \(u_4\) unmatched. If it uses exactly one of \(a:C,d:C\), direct matching of the remaining exterior gives only these forms, where \(i\in\{1,2,3\}\) and the two \(h_j\) with \(j\ne i\) are also used:
\[
\begin{array}{c|l}
a:C&d:Q,b:L,c:P,4R,iO\\
d:C&a:R,b:L,c:P,4Q,iO\\
d:C&a:R,b:P,c:Q,4L,iO.
\end{array}                                                   \tag{2}
\]
In the first line, the routes of \(b,c\) to the two \(h\)-ports are unchanged by \(X_a\to X_d\); the \(a:C\)-port is directly joined to terminal \(a\) against \(X_d\) and cannot serve the pure \(S\) \(e\)-path. In the second line the analogous statements hold with \(d:C\). In the third line, \(b\)'s \(h\)-route is unchanged and \(c\)'s changed route ends at \(d:C\); the two \(h\)-routes cannot exchange \(b,c\). Thus no line of (2) meets the required endpoint swap.

If \(Z_e\) uses both \(a:C,d:C\), it uses exactly one \(h_i\). The \(a:C\)-port cannot pair with \(e\): against \(X_d\), terminal \(a\) reaches it directly, giving the forbidden state \(ad\). Likewise \(d:C\) is forbidden against \(X_a\). The \(e\)-port must pair with the selected \(h_i\). Exhausting the two choices for each \(b,c\) half-edge and the matching of \(u_4\) leaves the following eight actual exterior masks. The last column gives the terminal reached from that \(h_i\) against \(X_a\), then against \(X_d\); \(iw\) means edge \(u_iw\).

| \(b,c\) halves | \(h_i\) | Other exterior edges of \(Z_e\) | Terminal pair |
|---|---|---|---|
| \(b:L,c:P\) | \(h_3\) | \(4Q,2R,1O\) | \(c,c\) |
| \(b:L,c:P\) | \(h_1\) | \(4Q,2R,3O\) | \(b,b\) |
| \(b:L,c:Q\) | \(h_2\) | \(4R,3P,1O\) | \(b,b\) |
| \(b:L,c:Q\) | \(h_1\) | \(4R,3P,2O\) | \(b,b\) |
| \(b:P,c:Q\) | \(h_3\) | \(4L,2R,1O\) | \(b,b\) |
| \(b:P,c:Q\) | \(h_1\) | \(4L,2R,3O\) | \(c,b\) |
| \(b:P,c:Q\) | \(h_3\) | \(4R,1L,2O\) | \(b,b\) |
| \(b:P,c:Q\) | \(h_2\) | \(4R,1L,3O\) | \(b,b\) |

The sole endpoint change is the sixth row, forcing both the order \(e-a-c-b-d-e\) and mask (1). For example, in that row the \(c\)-route against \(X_a\) is \(c-Q-u_4-L-u_1-h_1\); against \(X_d\), the \(b\)-route is \(b-P-u_3-O-u_2-R-u_4-L-u_1-h_1\). The shore pairing of \(e\) with \(h_1\) is unchanged because the two triples have the same shore mask.

## Full closure closes the row

In the forced order, \(ea\in S\) and \(ec\in T\). Take the required actual \((ea)(ec)\) row and decompose its \(S\)-half as above:
\[
D=X_a+Y_a+Z_e,
\qquad E=U_{ec}+V_c+W_e,
\qquad D+E=2\mathbf1.                                    \tag{3}
\]
Because \(E\) has a \(T\)-state, \(D\) is pure \(S\), so (1) applies. Exchange the **whole** singleton-\(e\) matchings \(Z_e,W_e\). The opposite half still has state \(ec\in T\); hence the new \(S\)-half is pure and (1) forces \(W_e\) to have the *same exterior mask* as \(Z_e\).

Note 247 leaves three possible singleton-\(a\) masks:
\[
Y_a|_{\rm ext}=\{4R,d:Q,b:L,c:P,iO\}
\cup\{h_j:j\ne i\},\qquad i=1,2,3.                \tag{4}
\]
For \(i=2\) or \(3\), both \(Y_a\) and \(Z_e\) use \(h_1\), so \(D(h_1)=2\) and \(E(h_1)=0\). But \(W_e\) has mask (1) and uses \(h_1\), impossible. For \(i=1\), the three masks \(X_a,Y_a,Z_e\) partition **every proper exterior edge exactly once**. Thus \(E\) has unit load on each such edge. Its zero-port state-\(ec\) triple \(U_{ec}\) must select one of \(c:P,c:Q\). Since \(W_e\) uses \(c:Q\), it selects \(c:P\). The graph \(K-P\) has the unique perfect matching \(1L,2R,3O,4Q\). Hence \(U_{ec}\) and \(W_e\) both use \(2R\) and \(3O\), contradicting the unit load of \(E\). This excludes every \(i\) and proves the theorem. \(\square\)

The conclusion excludes this one marked quotient at every shore order and rank. It uses a true \((ea)(ec)\) row and complete matching identity exchange, not selected external masks alone. The other three \(r=3\) and two \(r=4\) shapes of Note 245, larger barriers, other Tutte profiles, and the Berge--Fulkerson conjecture remain open. The hand-derived mask table and upstream chain await an independent model or implementation check.
