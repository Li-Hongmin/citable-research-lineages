> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The right central ad row forces S-Tait in the three-two near-bipartite core

Continue the actual central-path exterior of [Notes 271 and 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md). Assume complete exact-Case-XII support, a real left \((ea)(ac)\) row of Note 271, and a real **right** \((ea)(ad)\) row of Note 297. The allowed states form \(S=e-a-b-d-c-e\); in particular no state in \(T\) has a Tait colouring. Write the six shore ports as
\[
 E=e,\qquad A=a:\Sigma,\qquad I=h_1,\quad D=h_2,\quad H=h_3,\quad J=h_4.
\]
Suppose the unmarked core \(C\) becomes bipartite after deleting an edge \(g\) with both ends in a side \(B\), while the internal marked edge has ends \(v\in B,w\in R\). Assume the \(3{:}2\) profile of [Note 282](282-unmarked-near-bipartite-central-cores-have-only-two-cut-profiles.md): \(|B|-|R|=1\), exactly three proper shore ports are based in \(B\), and two in \(R\). Let \(R_0\) be the latter pair.

**Theorem.** In this profile the right \((ea)(ad)\) row forces its **own zero-port occurrence** \(X\) to select \(g,t_ew\), and thereby forces a genuine \(S\)-Tait colouring. More precisely, \(R_0=ID,AD,AH,AJ\) is impossible under the two stated rows and exact negative support; the surviving pairs are \(AI,IH,IJ,DH,DJ\), and in each the right-row \(X\) has this second profile. Thus the Tait-empty conclusion of [Note 287](287-unmarked-near-bipartite-central-cores-force-s-tait.md) survives the correction of Note 272 **in this \(3{:}2\), oppositely marked near-bipartite profile**. No left \((ea)(ad)\) orientation is assumed here.

## Two reusable closure facts

The right row has shore port sets
\[
 (X,Y,Z,U,V,W)=(\varnothing,ID,EAHJ,EJ,ID,AH),       \tag{1}
\]
where \(E\) is selected by \(Z,U\). Its pure \(X\triangle Z\) paths pair \(EH\mid AJ\), by Note 297. For any shore matching \(M\), let \(c=1\) if it selects \(E\), let \(h=1\) if it selects \(t_ew\) when \(c=0\), and let \(z=\mathbf1_{g\in M}\). [Note 283's balance equation](283-three-two-core-profile-fixes-row-slots-and-blocks-some-zero-port-masks.md) is
\[
 \sum_{p\in S(M)}\operatorname{side}(p)+(1-c)(1-2h)=1-2z,
 \qquad \operatorname{side}(B)=1,\ \operatorname{side}(R)=-1. \tag{2}
\]
In particular a zero-port matching uses either \((t_ev,z=0)\) or \((t_ew,z=1)\). The latter *complete-fibre* profile gives an actual \(S\)-Tait colouring by [Note 285](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md); its proof uses the two forbidden \(eb\) exterior completions and does not use the left \(ad\) template.

Colour \(t_e\) and the five exterior interface endpoints by \(R\), as in Note 283. Every terminal vertex is then in \(R\), and the only proper edges internal to a colour class are \(g,t_ew\), and the two cut edges at \(R_0\). Consequently, **any complete singleton matching other than singleton-\(e\) that selects \(g,t_ev\) and both \(R_0\) cut edges extends to a Tait colouring**: only \(t_ew\) remains exceptional in its complement, and it lies on the open path starting at terminal \(e\). Every closed complement cycle is even. Exact negative support makes the resulting state an element of \(S\).

There is a sharper consequence for singleton \(c\): **no such matching can exist**. Its complementary terminal path containing \(e\) has two \(R\)-side ends and the one same-side edge \(t_ew\), so its ends receive the same complementary colour. The other terminal path has differently coloured ends; exchanging its two colours gives Tait states joining \(c\) to each endpoint. The only two allowed states incident to \(c\) are \(ce,cd\), which would require that differently coloured path to have ends \(e,d\). It cannot contain \(e\), a contradiction. This is the parity mechanism of [Note 288](288-the-one-b-port-near-bipartite-core-profile-is-not-exact-case-xii.md), and it applies to either numerical placement of the two \(R\)-ports.

## One R-port among A,I,D

First suppose \(R_0=qr\), where \(q\in\{A,I,D\}\) and \(r\in\{H,J\}\). If \(q=I\) or \(q=D\), the two \(ID\)-port occurrences \(Y,V\) are mixed-side. [Note 290's complete-fibre exclusion](290-two-port-closure-separates-the-remaining-three-two-row-loads.md), assertion 1, forbids their \((t_ew,g)\) profile under exactly this side placement. Equation (2) therefore makes both select \(t_ev\). Since \(Z,U\) select terminal \(E\), the load-two equation on the two marked half-edges makes \(X,W\) select \(t_ew\). Thus \(X\) has the second zero-port profile, and Note 285 gives \(S\)-Tait.

If \(q=A,r=H\), the \(AH\)-port singleton \(W_d\) has both ports in \(R\). Equation (2) forces its shore restriction to select \(t_ev,g\). Reuse that **same actual shore matching** with the independent singleton-\(c\) exterior mask
\[
 \{c_{\rm term},a:\Sigma,b:A_{\rm ext},d:E_{\rm ext},
       1B_{\rm ext},2C_{\rm ext},4D_{\rm ext},h_3\}.       \tag{3}
\]
Its marks are covered by \(a:\Sigma,b:A,c_{\rm term},d:E\); its path vertices by \(b:A,1B,2C,4D,d:E\); and \(u_1,u_2,u_3,u_4\) by \(1B,2C,h_3,4D\). Its only shore ports are \(A,H\). The completed singleton-\(c\) matching selects \(g,t_ev\) and both \(R_0\) cut edges, contrary to the closure fact. Hence \(R_0=AH\) is impossible.

If \(q=A,r=J\), both \(ID\)-port occurrences have both ports in \(B\), so (2) makes them select \(t_ew\) and avoid \(g\). Hence \(X,W\) select \(t_ev\), and \(X\) avoids \(g\). The \(EAHJ\)-port matching \(Z\) has two \(R\)-based proper ports \(A,J\), so it selects \(g\). In \(X\triangle Z\), each shore terminal path has an odd number of internal edges because both its port edges belong to \(Z\). The \(E\)--\(H\) path joins an \(R\)-vertex to a \(B\)-vertex and contains the crossing edge \(t_ev\); it cannot contain the sole possible same-side edge \(g\). Nor can an alternating closed cycle contain exactly one same-side edge. Thus \(g\) lies on the \(A\)--\(J\) path. Switch that complete shore path. The resulting shore matching \(N_{AJ}\) has ports \(A,J\) and selects \(g,t_ev\). Glue it to the actual singleton-\(c\) exterior mask
\[
 \{c_{\rm term},a:\Sigma,b:A_{\rm ext},d:E_{\rm ext},
       1B_{\rm ext},2C_{\rm ext},3D_{\rm ext},h_4\}.       \tag{4}
\]
The four marks are covered by \(a:\Sigma,b:A,c_{\rm term},d:E\); the path vertices by \(b:A,1B,2C,3D,d:E\); and \(u_1,u_2,u_3,u_4\) by \(1B,2C,3D,h_4\). Its only shore ports are \(A,J\). This produces the forbidden singleton-\(c\) matching of the closure fact, so \(R_0=AJ\) is impossible.

## Two R-ports among A,I,D

Now \(H,J\in B\) and \(R_0\in\{AI,ID,AD\}\). If \(R_0=ID\), all three proper ports \(A,H,J\) of \(Z\) are in \(B\); their side sum is \(3\), impossible in (2) for a matching selecting terminal \(E\). Thus this placement has no right row.

For \(R_0=AD\), use the left \((ea)(ac)\) row. Its \(HJ\)-port occurrences select \(t_ew\), so its zero-port \(X_L\) selects \(t_ev\) and avoids \(g\); its \(EAID\)-port \(Z_L\) selects \(g\), by (2). Its pure paths pair \(EI\mid AD\). The \(E\)--\(I\) path joins \(R\) to \(B\) and contains \(t_ev\), so the same parity argument puts \(g\) on the \(A\)--\(D\) path. Switching that path produces a shore matching \(N_{AD}\) with ports \(A,D\), selecting \(g,t_ev\). Glue it to the genuine singleton-\(c\) exterior mask in [Note 288, (2)](288-the-one-b-port-near-bipartite-core-profile-is-not-exact-case-xii.md), whose only proper shore ports are \(A,D\). The forbidden singleton-\(c\) closure fact excludes \(R_0=AD\). This argument uses the \(ac\) row but no left \(ad\) row.

Finally let \(R_0=AI\). We first exclude any \(ID\)-port shore matching \(N\) selecting \(g,t_ew\). The cut edge at \(I\) is selected and \(A\) is the sole same-side edge left in the complement. Glue \(N\) to the actual singleton-\(c\) and singleton-\(b\) exterior masks with ports \(ID\) in [Note 290's table](290-two-port-closure-separates-the-remaining-three-two-row-loads.md). The former complement has arms \(E-e,A-a,H-d,J-b\), so \(A\) lies on an open path and all closed cycles are even. Exact support allows only \(ce,cd\) Tait states, forcing the differently coloured terminal path to be \(e\)--\(d\), hence forcing the shore-complement pairing \(EH\mid AJ\). Under the singleton-\(b\) mask the exterior complement connects \(A-a,H-J,c-d,E-e\). The same shore pairing now gives an \(e\)--\(a\) path containing exception \(A\) and a differently coloured \(c\)--\(d\) path. Switching its colours produces forbidden state \(bc\in T\). Therefore no such \(N\) exists.

In the right row, both \(Y,V\) use the mixed ports \(ID\), so this exclusion makes them select \(t_ev\) and avoid \(g\). The \(E\)-port slots \(Z,U\) use neither marked half-edge. Load two forces \(X,W\) to select \(t_ew\), and (2) makes the zero-port \(X\) select \(g\). Note 285 again gives \(S\)-Tait. This exhausts all nine placements. \(\square\)

**Surviving path constraint.** In each of the five possible port placements \(AI,IH,IJ,DH,DJ\), take either of the two complete \(ID\)-port occurrences \(Y,V\). The unique shore terminal path of \(X\triangle Y\) (or \(X\triangle V\)) joins \(I\) to \(D\) and contains **both** \(g\) and the marked vertex \(t_e\). Indeed, \(X\) selects \(g,t_ew\), whereas each \(ID\)-port occurrence selects \(t_ev\) and avoids \(g\). The ports \(I,D\) lie on opposite bipartition sides. Their alternating path has an odd number of internal edges, so it contains either zero or both of the only same-side edges \(g,t_ew\). An alternating closed cycle likewise contains zero or both. If those two edges were on a closed cycle, switching that complete cycle would give an actual \(ID\)-port matching selecting \(g,t_ew\), contrary to Note 290 for \(IH,IJ,DH,DJ\) or the direct \(AI\) exclusion above. They therefore lie on the \(I\)--\(D\) path, which passes through \(t_e\) via \(t_ew\). This is a full-matching routing restriction on **each** repeated singleton, not an identification of their complete masks.

The theorem repairs a conditional near-bipartite conclusion under the actual right-row template; it does not exclude an \(S\)-Tait exact pole, a higher-rank unmarked core, or the other minimum-host profiles. The row and exterior-mask arguments are hand proofs; no local enumeration or remote computation was used.

[Note 299](299-two-singleton-c-masks-exclude-the-right-ad-h-side-and-one-b-port-profiles.md) subsequently excludes the \(AI,IH,DH\) placements by reusing one \(AH\)-port shore matching with two singleton-\(c\) exterior masks. The theorem above remains a necessary classification; its surviving list is narrowed there to \(IJ,DJ\).
