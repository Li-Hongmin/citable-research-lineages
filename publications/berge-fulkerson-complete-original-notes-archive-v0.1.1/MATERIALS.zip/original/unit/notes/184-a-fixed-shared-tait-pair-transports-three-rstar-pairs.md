> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A fixed shared Tait pair transports three opposite-shore BF pairs

Use the genuine \(|U|=1\) connector and notation of [Note 183](183-a-shared-pair-tait-shore-and-a-loop-universal-shore-force-seven-loops.md). Suppose \(A^\circ\) has a real Tait colouring with port macrocolours \((0,x,y,z,\delta)=(1,3,1,2,1)\), so \(xz\) is its lonely pair. The following three implications concern **actual complete BF rows** of the opposite shore:
\[
\begin{aligned}
(xy)(xz)\in\operatorname{BFsupp}(B^\circ)
&\Longrightarrow (yz)(xz)\in\operatorname{BFsupp}(H),\\
(xy)(0x)\in\operatorname{BFsupp}(B^\circ)
&\Longrightarrow (yz)(z\delta)\in\operatorname{BFsupp}(H),\\
(xy)(\epsilon x)\in\operatorname{BFsupp}(B^\circ)
&\Longrightarrow (yz)(z\epsilon)\in\operatorname{BFsupp}(H).
\end{aligned}                                                   \tag{1}
\]
The pairs in (1) are BF missing-pair types, not Tait states. A three-edge-colouring of \(B^\circ\) is not assumed.

Double the fixed \(A^\circ\) colouring into six matching slots: slots \(1,2\) have \(A^\circ\)-boundary \(\{0,y,\delta\}\), slots \(3,4\) boundary \(\{z\}\), and slots \(5,6\) boundary \(\{x\}\). In the table, \(B^\circ\)'s two indicated triple-boundary occurrences and its four singleton occurrences may be assigned to the six slots because its stated BF type is actually supported. Here \(D_\delta,D_\epsilon\) are the slot labels on \(wt_\delta,wt_\epsilon\) from [Note 172, (2)](172-one-vertex-two-shore-connector-has-one-overlap-gate.md).

| \(B^\circ\) type | \(B^\circ\) boundaries in slots \(1,\ldots,6\) | \(uw;\ D_\delta;\ D_\epsilon\) | outer triple slots and missing pairs |
|---|---|---|---|
| \((xy)(xz)\) | \(x,x,\{0,y,\epsilon\},y,\{0,z,\epsilon\},z\) | \(\{4,6\};\{3,5\};\{1,2\}\) | \(4:yz,\ 6:xz\) |
| \((xy)(0x)\) | \(x,x,y,0,\{0,z,\epsilon\},\{y,z,\epsilon\}\) | \(\{3,6\};\{4,5\};\{1,2\}\) | \(3:yz,\ 4:z\delta\) |
| \((xy)(\epsilon x)\) | \(x,x,y,\epsilon,\{0,z,\epsilon\},\{0,y,z\}\) | \(\{3,4\};\{5,6\};\{1,2\}\) | \(3:yz,\ 4:z\epsilon\) |

In every row, the \(A^\circ\) and \(B^\circ\) boundary slot sets are disjoint at \(0,x,y,z\); \(X_\delta=\{1,2\}\) and \(Y_\epsilon\cap X_\delta=\varnothing\), so the exact overlap gate holds. The two shore labels and \(uw\) partition the slots at \(u\); \(uw,D_\delta,D_\epsilon\) partition them at \(w\), and the displayed connector labels avoid the shore halves at \(t_\delta,t_\epsilon\). Filling each terminal with its two remaining slots therefore gives six genuine perfect matchings with edge load two. For example, in the middle row the outer terminal labels at \(x,y,z,\delta,\epsilon\) are \(\{3,4\},\{4,5\},\{1,2\},\{3,6\},\{3,4\}\). Slots \(3,4\) have triple boundaries \(\{x,\delta,\epsilon\}\) and \(\{x,y,\epsilon\}\), missing \(yz\) and \(z\delta\), respectively. The other rows follow by the displayed slot partitions. This proves (1). \(\square\)

Let \(T\) be the forbidden five-cycle of an exact-Case-XII pole. If \(yz\in T\) and \(z\xi\in T\), with \(\xi\in\{x,\delta,\epsilon\}\), set
\[
a(\xi)=
\begin{cases}
z,&\xi=x,\\
0,&\xi=\delta,\\
\epsilon,&\xi=\epsilon.
\end{cases}
\]
Equation (1) forbids the opposite-shore type \((xy)(x\,a(\xi))\), since it would produce a \(T\)--\(T\) outer type. If \(B^\circ\) has the published Case-XIII \(R^*\) relation, let \(c(p)\in\{P,Q\}\) denote the block of a local missing-pair state \(p\). Every cross-block pair is supported, so the necessary condition is the concrete equality
\[
\boxed{c(xy)=c\bigl(x\,a(\xi)\bigr).}                 \tag{2}
\]
This holds under any relative labelling of the \(R^*\) shore; its block partition must be relabelled along with its ports.

For a three-vertex tree \(A^\circ\) whose centre port is \(0\), write its end groups as \(\{\delta,x\}\mid\{y,z\}\). Both shared-pair states \(xy,xz\) are genuine Tait states. If \(\delta,\epsilon\) are adjacent in \(T\), the three shared labels form a two-edge \(T\)-path. When its centre is \(x\), apply (2) to both tree colourings, orienting the lonely pair so that the common centre \(x\) plays the role of \(z\) in (1). The two resulting equalities give
\[
\boxed{c(xy)=c(xz)=c(yz).}                           \tag{3}
\]
For the Figure-7 \(R^*\) partition, one block \(P=\{13,14,24,35,45\}\) has no triangle as an edge set on the five port labels, while \(Q=\{12,15,23,25,34\}\) has the unique triangle on \(\{1,2,5\}\). Thus (3) forces the three shared ports to be that unique \(Q\)-triangle, up to the relative port permutation. The gate itself is satisfiable as a *formal port placement*: take \(x=2,y=1,z=5,0=3,\epsilon=4\) and \(T=\delta-\epsilon-y-x-z-\delta\). Then \(xy=12,xz=25,yz=15\) all lie in \(Q\). [Note 185](185-the-centered-tree-rstar-path-forces-a-forbidden-bf-pair.md) subsequently excludes this entire centred-path case using another actual \(R^*\) pair row. The other \(T\)-path centres, the case where \(\delta,\epsilon\) are nonadjacent in \(T\), and the remaining \(R^*\) shore pairings require further complete-support arguments.
