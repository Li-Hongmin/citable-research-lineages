> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A disjoint shore pair excludes R-star except at one L-star centre port

Use the genuine \(|U|=1\) two-five-cut connector of [Note 172](172-one-vertex-two-shore-connector-has-one-overlap-gate.md). Let the opposite shore \(B^\circ\) have the published Case-XIII \(R^*\) relation. Suppose that, for some labelling of the three common marked ports as \(x,y,z\), the shore \(A^\circ\) supports all three actual BF types
\[
\boxed{[\delta y],\qquad [xz],\qquad (\delta y)(xz).}  \tag{1}
\]
Then the outer five-pole cannot have exact Case-XII boundary support, at any relative placement of the \(R^*\) ports or the forbidden pentagon \(T\).

This is a boundary-support theorem, independent of the internal shape of \(A^\circ\). The three types in (1) have, up to slot permutation, the three six-slot boundary rows displayed in [Note 190, (1)](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md). All transports in [Notes 188--190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) apply to any *actual* rows of those types. [Note 189](189-a-pentagon-rstar-two-five-cut-requires-adjacent-special-ports.md) excludes all \(\delta\epsilon\notin T\) orders; [Note 190](190-the-pentagon-rstar-two-five-cut-profile-is-impossible.md) excludes all \(\delta\epsilon\in T\) orders. Both arguments use the full connector gate, genuine shore rows, and the actual cross-block support of \(R^*\). Thus (1) gives a reusable exclusion. \(\square\)

Now let \(A^\circ\) have the Figure-7 Case-XIII \(L^*\) relation. It supports all ten loops; it supports a pair type precisely when its two missing-pair states lie in the same block
\[
P=\{13,14,24,35,45\},\qquad Q=\{12,15,23,25,34\}.
\]
The four marked \(A^\circ\) ports are \(\{\delta,x,y,z\}\), the complement of its unmarked centre port \(0_A\). For each possible Figure-7 label of \(0_A\), inspect the three perfect matchings of those four marked ports. The table lists exactly the pair types supported by \(L^*\) among them.

| \(0_A\) | marked ports | supported disjoint pair types |
|---|---|---|
| \(1\) | \(2,3,4,5\) | \((24)(35),\ (25)(34)\) |
| \(2\) | \(1,3,4,5\) | \((13)(45),\ (14)(35),\ (15)(34)\) |
| \(3\) | \(1,2,4,5\) | none |
| \(4\) | \(1,2,3,5\) | \((15)(23)\) |
| \(5\) | \(1,2,3,4\) | \((12)(34),\ (13)(24)\) |

Each supported disjoint type in the table can be named \((\delta y)(xz)\), since \(\delta\) lies in one of its two edges. Both corresponding loops are also supported by \(L^*\), so (1) excludes every row except \(0_A=3\). Therefore
\[
\boxed{L^*\text{--}R^*\text{ in an exact-Case-XII }|U|=1
\text{ two-five-cut profile}\quad\Longrightarrow\quad 0_A=3}.
\tag{2}
\]
The label \(3\) here is intrinsic to the Figure-7 \(L^*\) partition: it is the unique port whose deletion leaves no same-block perfect matching of the other four port labels. Equation (2) does not assert that this remaining port placement is realizable, nor does it settle \(R^*\)--\(R^*\) or the other Tutte-barrier profiles.

[Note 192](192-a-loop-universal-shore-excludes-rstar-in-the-one-vertex-connector.md) subsequently excludes even this exceptional placement using only two actual \(L^*\) BF loops. Thus (2) remains a necessary-condition calculation but is no longer the sharp surviving boundary.
