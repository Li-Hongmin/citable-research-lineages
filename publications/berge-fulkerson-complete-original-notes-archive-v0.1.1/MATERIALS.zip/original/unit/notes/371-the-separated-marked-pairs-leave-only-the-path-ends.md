> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Separated marked pairs leave only the two path-end pentagons

Retain the \(K_{3,3}\) tree exterior and notation of [Note 370](370-the-middle-marked-pair-excludes-both-case-xii-pentagons.md): tree edges \(xr,xs,xt,yr,zs\) carry \(u_0,\ldots,u_4\), and the four exterior marks form \(a=ys,b=yt,c=zt,d=zr\). Consider the two pentagons with \(e\)-neighbour pair \(\{a,c\}\):
\[
S_3=e-a-b-d-c-e,\qquad
S_4=e-a-d-b-c-e.                                    \tag{1}
\]
Both have \(ea,ec\in S_i\) and \(eb,ed,ac\in T_i\). In the published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf), both relabel to \((e,a,b,d,c)=(3,1,4,2,5)\) or \((e,a,d,b,c)=(3,1,4,2,5)\), respectively, so the real \((ea)(ac)=(13)(15)\) row is required and every double-\(T_i\) row is forbidden.

**Theorem.** Neither pentagon in (1) can be the complete exact-Case-XII support of a cubic five-pole with this exterior, at any shore order or cycle rank. Reversing the marked path also excludes the two pentagons with \(e\)-neighbour pair \(\{b,d\}\). Together with Notes [368](368-the-crossed-k33-marked-path-has-no-case-xii-row.md)–[370](370-the-middle-marked-pair-excludes-both-case-xii-pentagons.md), ten of the twelve labelled pentagons on this marked tree are excluded; only the pair \(\{a,d\}\) remains.

**Proof.** In a required \((ea)(ac)\) BF row name the state-\(ea\) triple \(P\), state-\(ac\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(c\) matching \(C\), and singleton-\(a\) occurrences \(A_1,A_2\). Their terminal sets are \(bcd,bde,e,c,a,a\). By [Notes 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md) and [358](358-the-five-vertex-tree-exterior-has-two-root-zero-port-fibres.md), \(P\) has no proper shore port and its \(a\)-half is rooted at \(y\) or \(s\). Since \(R=ac\in T_i\), switching \(P\) with either \(A_j\) must give the other allowed \(e\)-state, \(ec\); the alternatives \(eb,ed\) are in \(T_i\). Its \(a\)--\(c\) terminal path stays wholly exterior by [Note 244's zero-port argument](244-every-shore-mark-must-neighbour-the-internal-mark.md).

**Root \(y\).** The rooted triple uses \(t_ay,ru_3,xu_0,su_1,tu_2,zu_4\). Starting at \(a\), the \(a\)--\(c\) path must follow \(a-t_a-y-u_3-r-u_0-x\), then one of
\[
x-u_1-s-u_4-z-t_c-c
\quad\text{or}\quad
x-u_2-t-t_c-c.                                      \tag{2}
\]
The first route occupies both \(r,z\), so the same singleton-\(a\) matching cannot match \(t_d\). The second occupies both \(y,t\), so it cannot match \(t_b\). Thus neither \(A_j\) exists at this root.

**Root \(s\).** Now \(P\) uses \(t_as,xu_1,zu_4,ru_0,tu_2,yu_3\). The only possible \(a\)--\(c\) paths are
\[
K:a-t_a-s-u_4-z-t_c-c,
\qquad
J:a-t_a-s-u_1-x-u_2-t-t_c-c.                    \tag{3}
\]
Any \(A_j\) on \(K\) uses \(t_cz,t_dr,su_4\), and covers \(t_b\) through either \(t_by\) or \(t_bt\); call these subtypes \(K_y,K_t\). A matching on \(J\) uses \(t_ct,t_by,su_1,xu_2\). If both \(A_j\) use \(J\), they saturate \(t_by\), forcing \(E,C\) onto \(t_bt\). Switch \(P\) with one \(A_j\) along \(J\). The new state-\(ec\) triple uses \(t_ct\) and still has terminal \(b\); \(C\) has terminal \(c\) and uses \(t_bt\). Their entirely exterior \(c-t_c-t-t_b-b\) path switches the triple to \(eb\in T_i\) beside \(R=ac\in T_i\), impossible. This same contradiction applies whenever a \(J\)-matching occurs and \(C\) uses \(t_bt\).

Suppose one occurrence uses \(J\) and the other uses \(K\). The \(J\)-matching uses \(t_by\). If the \(K\)-matching is subtype \(K_y\), they saturate \(t_by\) and force \(C\) onto \(t_bt\), already impossible. Hence it is \(K_t\). To avoid the same \(J\)-switch contradiction, \(C\) must use \(t_by\) and \(E\) must use \(t_bt\). The mark and vertex loads now force
\[
E:\quad t_ay,t_bt,t_cz,t_dr,su_4,
\qquad C:\quad t_as,t_by,t_dz,
\qquad R:\quad t_ay,t_ct,zu_4.                 \tag{4}
\]
Indeed \(E\), already matched at \(t\) through \(b\), must take \(c\) at \(z\), leaving \(R\) on \(t_ct\). At \(y\), \(P,K_t\) occupy \(yu_3\) and \(J,C\) occupy \(t_by\), so \(R,E\) take \(t_ay\). The remaining \(a\)-half belongs to \(P,C\). Since \(R\) has terminal \(d\) and uses \(c\) at \(t\), it matches \(z\) through \(zu_4\), saturating that edge with \(P\). The \(d\)-halves and \(u_4\) then give \(E\) the edges \(t_dr,su_4\), as displayed.

In this row \(P\triangle E\) has its \(c\)-terminal exterior leg through \(z,u_4,s,t_a,y\); its \(b\)- and \(d\)-terminal legs avoid the short path \(K\). Switch \(P,K_t\) along \(K\). The resulting state-\(ec\) triple retains the same complete shore matching as \(P\), and its \(b\)- and \(d\)-legs with \(E\) are unchanged. For \(S_3\), the old \(e\)-path of \(P\triangle E\) must end at \(b\), because \(ab\in S_3\) whereas \(ac,ad\in T_3\). It still ends at \(b\), giving \(bc\in T_3\) beside \(R\). For \(S_4\), the old \(e\)-path must end at \(d\); it still ends at \(d\), giving \(cd\in T_4\) beside \(R\). Both are forbidden genuine rows.

Finally suppose both occurrences use \(K\). They both select \(t_cz,t_dr,su_4\). Thus \(R,E\) select \(t_ct\), forcing \(E\) to select \(t_by\), and \(E,C\) select \(t_dz\). Both \(K_y\) would overload \(t_by\) with \(E\); both \(K_t\) would overload \(yu_3\) with \(P\). One occurrence is therefore \(K_y\), the other \(K_t\). The \(b\)-load puts \(C\) on \(t_bt\); then the \(y\)- and \(a\)-loads give \(R,C\) on \(t_ay\) and \(P,E\) on \(t_as\). At \(z\), the two \(A_j\) use \(t_cz\) and \(E,C\) use \(t_dz\), so \(P,R\) use \(zu_4\). Consequently \(E,C\) use port \(p_4\). In particular, the \(d\)-terminal leg of \(P\triangle E\) is \(d-t_d-z-u_4-p_4\), and \(P,E\) share \(t_as\).

Switch \(P\) with either \(A_j\) along \(K\). The old \(b\)-terminal leg is unchanged; the old \(d\)-leg to \(p_4\) becomes the new \(a\)-terminal leg \(a-t_a-s-u_4-p_4\). Under \(S_3\), the original \(e\)-path must end at \(b\), so it still does and produces \(bc\in T_3\) beside \(R\). Under \(S_4\), the original \(e\)-path must end at \(d\), so the same shore pairing now joins \(e\) to \(a\) and produces \(ac\in T_4\) beside \(R\). This exhausts all rows. \(\square\)

The marked-path reversal \((a,b,c,d)\mapsto(d,c,b,a)\) is an automorphism of the exterior and carries \(\{a,c\}\) to \(\{b,d\}\), giving the reflected exclusions. The argument uses actual full matchings in a required row and complete exterior exchanges; no matching identities from distinct rows are assumed equal. The two pentagons with \(e\)-neighbour pair \(\{a,d\}\), other exterior trees and general exact Case XII remain open. This is an analytic proof awaiting independent review; no local mathematical recomputation was used.
