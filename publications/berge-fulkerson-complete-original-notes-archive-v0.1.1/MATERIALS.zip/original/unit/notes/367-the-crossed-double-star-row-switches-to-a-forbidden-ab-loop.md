> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The crossed double-star row switches to a forbidden \([ab]\) loop

Use the double-star exterior and marks of [Note 364](364-adjacent-double-star-cross-row-has-one-crossed-shore-gate.md):
\(a=r_1l_1,b=r_1l_2,c=r_2l_1,d=r_2l_2\), with \(e\) in the six-port shore \(Z\). In the only adjacent pentagon left by Notes 363–364,
\[
 S=e-a-d-c-b-e,\qquad T=\{ec,ed,ab,ac,bd\}.
\]
The published [Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf) requires a genuine \((ea)(ab)\) BF row and forbids the loop \([ab]\): in its labels, \((e,a,d,c,b)=(3,1,4,2,5)\), so these are the listed \((13)(15)\) row and absent \([15]\) loop.

**Theorem.** Subject to Note 364's exterior classification of every genuine \((ea)(ab)\) row, no cubic five-pole with this double-star exterior has complete exact-Case-XII support, at any shore order or cycle rank. Together with Notes 363–364, this excludes all twelve labelled Case-XII pentagons for this marked double-star exterior.

**Proof.** Suppose that the required row exists. Name its state-\(ea\) triple \(P\), state-\(ab\) triple \(R\), singleton-\(e\) matching \(E\), singleton-\(b\) matching \(B\), and two singleton-\(a\) occurrences \(A_1,A_2\). Note 364 proves that \(P\) is rooted at \(l_1\) and gives the following exterior restrictions, where \(p_i\) is the port at \(u_i\):

| matching | relevant selected exterior edges | shore ports |
|---|---|---|
| \(P\) | \(s_b,s_c,s_d,\ t_al_1,\ yu_3,\ xu_0,\ r_1u_1,\ r_2u_2,\ l_2u_4\) | none |
| \(E\) | \(s_e,\ t_ar_1,\ t_bl_2,\ t_cl_1,\ t_dr_2,\ xu_2,\ yu_4\) | \(e,p_0,p_1,p_3\) |
| either \(A_i\) | \(s_a,\ t_br_1,\ t_cr_2,\ t_dl_2,\ l_1u_3,\ yu_0,\ xu_1\) | \(p_2,p_4\) |

The alternating terminal path in \(P\triangle A_i\) is exactly
\[
 H_i:\quad a-t_a-l_1-u_3-y-u_0-x-u_1-r_1-t_b-b.       \tag{1}
\]
This path is wholly outside the shore. Exchanging \(P,A_i\) on \(H_i\) yields complete matchings \(P^{(b)},A_i^{(b)}\), with \(P^{(b)}\) of state \(eb\), \(A_i^{(b)}\) singleton at \(b\), and \(P^{(b)}|_Z=P|_Z=:Q\).

Put \(L=E|_Z\). In the original \(P\triangle E\), the exterior paths from \(b,c,d\) terminate at \(p_3,p_1,p_0\), respectively. Since \(R\) remains in the forbidden set \(T\), exchanging \(P,E\) on the \(e\)-terminal path may not turn \(ea\) into \(ab\) or \(ac\), both in \(T\). It must turn \(ea\) into \(ad\in S\). Thus its shore segment is the \(e\)--\(p_0\) path of \(Q\triangle L\), as already recorded in Note 364 (4).

After (1), the exterior portion of \(P^{(b)}\triangle E\) from \(a\) to \(p_0\) is
\[
 a-t_a-r_1-t_b-l_2-u_4-y-u_0-p_0.                       \tag{2}
\]
The edges in (2) alternate between \(P^{(b)}\) and \(E\), starting with \(P^{(b)}\) at \(a\). Because the shore restrictions of \(P^{(b)},E\) are still \(Q,L\), their \(e\)--\(p_0\) shore path joins (2) into a complete \(e\)--\(a\) alternating component. Exchanging \(P^{(b)},E\) on that component turns \(P^{(b)}\) into an \(ab\)-triple. The other triple \(R\) remains \(ab\), so the six complete matchings now form a genuine \([ab]\) BF loop. Appendix XII forbids this type. Every exchange preserves the six-matchings' edge load \(2\mathbf1\), and no shore closed component matters. \(\square\)

There is a second check against Note 364's root theorem: after only (1), the \((eb)(ab)\) row has its \(eb\)-triple rooted at \(r_1\). The reflection \(a\leftrightarrow b,\ c\leftrightarrow d\) preserves this undirected pentagon and turns it into an \((ea)(ab)\) row rooted at \(r_1\), which Note 364 excludes. The same reflection preserves the parallel pentagon \(e-a-c-d-b-e\), and its \((ea)(ab)\) row has the same exterior path (1). Thus Note 364's root exclusion and exterior table alone close **both adjacent orders**; the explicit second exchange above identifies the forbidden \([ab]\) type for the crossed order without invoking the reflected root classification again.

Only the first shore gate \(ep_0\) of Note 364 is needed. The conditional phase restrictions of Notes 365–366 are no longer a live obstacle for this crossed placement: the two-switch argument eliminates it before any cross-row phase comparison. The proof is hand-derived and depends on the still unreviewed Note 364 exterior classification; no local mathematical recomputation was used.
