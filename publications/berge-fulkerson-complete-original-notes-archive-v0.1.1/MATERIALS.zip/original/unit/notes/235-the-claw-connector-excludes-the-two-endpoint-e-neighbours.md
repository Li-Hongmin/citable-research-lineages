> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The claw connector excludes the two endpoint \(e\)-neighbours

Use the \(|U|=3,r=3\) subdivided-claw exterior of [Note 234](234-three-exterior-graphs-for-the-first-surviving-one-shore-barrier.md). Name its central singleton \(w_0\), its leaves \(w_1,w_2,w_3\), and the barrier vertices \(u_1,u_2,u_3\). The unmarked edges are \(u_iw_0,u_iw_i,h_i=u_iv_i\), where \(v_i\in C\). The four exterior marks form a path through the leaves:
\[
a:w_1-C,\qquad b:w_1-w_2,\qquad c:w_2-w_3,\qquad d:w_3-C,
\]
and the fifth mark \(e\) lies inside the odd shore \(C\). Each mark is subdivided and has a terminal semiedge.

**Theorem.** In a genuine pole with this connector and arbitrary shore \(C\), complete exact Case-XII BF support is impossible if \(a,d\) are the two neighbours of \(e\) in the allowed missing-pair pentagon \(S\). Both orders \(e-a-b-c-d-e\) and \(e-a-c-b-d-e\), and their reflections, are excluded. The proof uses one actual half-load and does not assume any uniqueness inside \(C\).

**Proof.** Take a required actual \(S\)--\(T\) row and its \(S\)-half \(D\). Any \(T\)-decomposition of \(D\) would pair with the fixed \(T\)-half to make a forbidden \(T\)--\(T\) row. Hence \(\varnothing\ne\mathcal R(D)\subseteq S\), and [Note 055](055-half-load-column-saturation-and-case-xii-compression.md) gives \(\mathcal R(D)=S\). Choose its state-\(ea\) decomposition
\[
D=X+Y_a+Z_e,\qquad
\partial X=\{b,c,d\},\quad \partial Y_a=\{a\},\quad\partial Z_e=\{e\}.              \tag{1}
\]
By [Note 230's shore-hit quota](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(X\) uses no proper shore port. Its active mark \(a\) must select \(w_1\); the unique exterior unmarked matching then uses
\[
a:w_1,\qquad u_1w_0,\qquad u_2w_2,\qquad u_3w_3.          \tag{2}
\]

In \(X\triangle Y_a\), the alternating path from terminal \(a\) must end at \(d\), since \(ed\) is the only other \(S\)-edge incident with \(e\). At \(w_1\), if \(Y_a\) used \(b:w_1\), the path would end at \(b\). Thus it uses \(w_1u_1\), then (2) takes it to \(w_0\). Here \(Y_a\) must choose \(w_0u_2\) or \(w_0u_3\). The first choice follows (2) to \(w_2\), where \(Y_a\) can only use the half of \(b\) or \(c\) and end at \(b\) or \(c\). Hence the path takes \(w_0u_3\), follows (2) to \(w_3\), and ends via \(d:w_3\). In particular the **same** singleton matching \(Y_a\) uses
\[
w_1u_1,\qquad w_0u_3,\qquad d:w_3.                      \tag{3}
\]

But \(Y_a\) uses terminal \(a\) and therefore must match both subdivision vertices \(t_b,t_c\) through proper half-edges. At \(t_b\), its \(w_1\)-half is unavailable because \(w_1\) is already matched by \(w_1u_1\); so \(Y_a\) must use \(b:w_2\). At \(t_c\), its \(w_3\)-half is unavailable because \(w_3\) is already matched by \(d:w_3\); so \(Y_a\) must use \(c:w_2\). A perfect matching cannot use both edges at \(w_2\). This contradiction proves the theorem. \(\square\)

The obstruction is entirely exterior and applies at every shore order. It leaves neighbour pairs of \(e\) other than \(\{a,d\}\), as well as the other two unmarked exterior shapes of Note 234, for full six-matching closure.
