> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first-leaf six-cycle has three surviving markings

Retain the minimum-host, complete exact-Case-XII, one-internal-mark profile with \(|U|=4,r=3\). Take the fifth unmarked shape in [Note 245](245-six-exterior-graphs-at-the-four-vertex-one-shore-barrier.md), and write its exterior as
\[
K=\{1O,1L,1Q,2O,2R,3O,3P,4L,4R\},
\qquad h_i=u_iC\ (i=2,3,4),                         \tag{1}
\]
where \(O=w_0,L=w_1,R=w_2,P=p,Q=q\), and \(iw\) denotes \(u_iw\). The marked capacities of \(O,L,R,P,Q\) are \(0,1,1,2,2\), respectively. [Note 244](244-every-shore-mark-must-neighbour-the-internal-mark.md) requires the two \(W\)--\(C\) marks to be the two allowed neighbours of \(e\); [Note 246](246-the-two-shore-marks-need-distinct-singleton-endpoints.md) requires distinct \(W\)-endpoints.

**Theorem.** Exactly four marked exterior placements satisfy these necessary degree, girth, and distinct-endpoint conditions. One has no pure-\(S\) half-load and is impossible for complete exact Case XII. In each of the other three, the exterior path switching the two zero-port triples is unique; their full shore masks coincide, and the singleton-\(a\) exterior masks are fixed as in the table below. No existence of an exact-Case-XII shore matching relation is asserted for those three.

| Type | Shore marks \(a,d\) | Cross marks \(b,c\) | State-\(ea\) triple \(X_a\), exterior | Singleton-\(a\) \(Y_a\), exterior |
|---|---|---|---|---|
| B | \(a:P-C,d:Q-C\) | \(b:L-P,c:R-Q\) | \(a:P,1Q,2R,3O,4L\) | \(3P,1O,d:Q,b:L,c:R,h_2,h_4\) |
| C | \(a:R-C,d:Q-C\) | \(b:L-P,c:P-Q\) | \(a:R,1Q,2O,3P,4L\) | \(2R,1O,d:Q,b:L,c:P,h_3,h_4\) |
| D | \(a:L-C,d:Q-C\) | \(b:R-P,c:P-Q\) | \(a:L,1Q,2O,3P,4R\) | \(1L,d:Q,b:R,c:P,h_4\), plus \(2O,h_3\) or \(3O,h_2\) |
| E | \(a:L-C,d:P-C\) | \(b:R-Q,c:P-Q\) | \(a:L,1Q,2O,3P,4R\) | impossible |

For types B and C, switching the \(a\)--\(d\) path gives the same state-\(ed\) triple exterior \(d:Q,1O,2R,3P,4L\). For D it gives \(d:Q,1L,2O,3P,4R\). In all three, the switched triple retains the original triple's **complete matching mask** on \(C\cup\{t_e\}\).

**Proof of the marked placements.** A \(W\)--\(W\) mark cannot join singleton vertices sharing a neighbour in \(U\), since subdivision would make a four-cycle. Among vertices with positive marked capacity in (1), the only allowed pairs are \(LP,RP,RQ,PQ\). Choose two distinct such edges under the capacities of \(L,R,P,Q\). The choice \(LP,RP\) puts both remaining \(W\)--\(C\) marks at \(Q\), contrary to Note 246; the choice \(RP,RQ\) overloads \(R\). The four remaining choices are exactly types B--E in the table. They are distinct under automorphisms of (1), because \(u_1\) is the unique degree-three barrier vertex, \(Q\) is its leaf, and \(L,R\) occupy different positions relative to it.

**Proof of the half-load restrictions.** Take the pure \(S\)-half of a required \(S\)--\(T\) row and decompose it at \(ea\) as \(D=X_a+Y_a+Z_e\). By [Note 230](230-one-internal-mark-barrier-shore-has-a-rank-free-six-port-quota.md), \(X_a\) is zero-port. Its active mark \(a\) selects the displayed \(W\)-endpoint, and the matching of \(K\) after deleting that endpoint is unique; this gives the \(X_a\) column. The \(a\)-terminal path of \(X_a\triangle Y_a\) must end at \(d\), the other allowed neighbour of \(e\), and is wholly exterior by Note 244.

In type B, a path from \(P\) to \(Q\) can use \(P-u_3-O-u_1-Q\) or \(P-u_3-O-u_2-R-u_4-L-u_1-Q\). The longer path occupies both endpoints \(L,P\) of the nonterminal mark \(b\) within \(Y_a\), so only the shorter one is possible. It forces \(d:Q,c:R,b:L\); the remaining \(u_2,u_4\) take \(h_2,h_4\).

In type C, the path through \(R-u_4-L-u_1-Q\) occupies \(L\) while \(d:Q\) occupies \(Q\); then \(b\) must select \(P\), leaving neither endpoint for \(c=P-Q\). The path through \(R-u_2-O-u_1-Q\) is forced and gives the table's \(Y_a\) mask.

In type D, the longer path \(L-u_4-R-u_2-O-u_1-Q\) forces \(b:P\) and then blocks both endpoints of \(c=P-Q\). The short path \(L-u_1-Q\) forces \(d:Q,c:P,b:R\) and \(h_4\). Exactly one of \(u_2,u_3\) meets \(O\); the other uses its shore edge, giving the two table masks.

Finally, type E has only the path \(L-u_4-R-u_2-O-u_3-P\) from \(a\) to \(d\). It forces \(Y_a\) to use \(b:Q\), but then the nonterminal mark \(c=P-Q\) has neither endpoint available. Thus type E admits no pure-\(S\) half-load. Switching each surviving path changes only exterior edges and yields the stated state-\(ed\) triples. \(\square\)

Types B, C and D still require their singleton-\(e\) port pairings and real complementary BF rows. [Note 250](250-the-first-leaf-d-marking-forces-a-doubled-cross-half.md) and [Note 251](251-the-first-leaf-c-marking-has-a-forbidden-six-cycle-switch.md) subsequently exclude D and C using real cross rows; only B remains from this marked shape. [Note 252](252-the-first-leaf-b-marking-has-a-real-cross-row.md) gives B a real cross row but also a forbidden loop, so exact support remains undecided. The other four-vertex exterior shapes, larger barriers, the other Tutte profiles and Berge--Fulkerson remain open. The argument is hand-derived and has not received an independent model or implementation check.
