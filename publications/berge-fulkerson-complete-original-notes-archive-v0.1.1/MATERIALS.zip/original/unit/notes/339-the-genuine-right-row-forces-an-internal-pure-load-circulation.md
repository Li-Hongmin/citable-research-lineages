> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The genuine right row forces an internal pure-load circulation

Work in the central-path exterior of [Note 271](271-the-central-path-row-requires-two-distinct-shore-masks.md), with complete exact-Case-XII support and allowed pentagon \(S=e-a-b-d-c-e\). Let \(R_L\) be an actual left \((ea)(ac)\) row with the exterior masks of Note 271's Table (5), and \(R_R\) an actual **right** \((ea)(ad)\) row with those of [Note 297](297-the-right-central-ad-row-survives-the-exterior-route-check.md). Write their six complete matching occurrences as
\[
R_L=(X_L,Y_L,Z_L,U_L,V_L,W_L),\qquad
R_R=(X_R,Y_R,Z_R,U_R,V_R,W_R),
\]
where each \(X\) is the zero-proper-port state-\(ea\) triple, each \(Y,V\) is singleton \(a\), and each \(Z\) is singleton \(e\). Subscripts on matchings designate rows, while \(Y_L,Y_R\) also name their distinct exterior masks.

**Theorem (pure-load separation).** The two pairs and the two state-\(ea\) pure triples have equal *exterior* loads but unequal *full* loads:
\[
\begin{aligned}
(Y_L+Z_L)|_{\rm ext}&=(Y_R+Z_R)|_{\rm ext},&
Y_L+Z_L&\ne Y_R+Z_R,\\
(X_L+Y_L+Z_L)|_{\rm ext}&=(X_R+Y_R+Z_R)|_{\rm ext},&
X_L+Y_L+Z_L&\ne X_R+Y_R+Z_R.                    \tag{1}
\end{aligned}
\]
Here \(+\) is the integer edge-load sum, including terminal semiedges. Consequently the two row families have disjoint complete pure-three-load sets in this fixed left/right orientation. Moreover the four-slot loads \(X+Y+Z+V\) already differ on the exterior, so the fixed-exterior four-slot intersection criterion of [Note 273](273-central-path-transfer-is-a-four-slot-load-intersection.md) cannot be applied to these two rows.

**Proof.** On the exterior, the left singleton-\(e\) mask \(Z_L\), after removing its selected terminal \(e\) and its selected \(a:\Sigma\) edge, is exactly the right singleton-\(a\) mask \(Y_R\) after removing its terminal \(a\). Likewise \(Z_R-\{e,a:\Sigma\}=Y_L-\{a\}\) on exterior edges. These are the explicit masks in Notes 271 and 297: the two cross-mark route collections are
\[
\begin{aligned}
Y_L-\{a\}&=\{c:A,b:D,d:E,1B,2C,h_3,h_4\},\\
Y_R-\{a\}&=\{c:E,b:A,d:B,3C,4D,h_1,h_2\}.
\end{aligned}
\]
Thus the first exterior identity in (1) holds edge by edge, including \(a:\Sigma\) and the terminals \(a,e\). The \(X\) exterior masks coincide, proving the second exterior identity.

Suppose the *full* two-slot loads were equal. Replace the actual \(Y_L,Z_L\) occurrences in \(R_L\) by the actual \(Y_R,Z_R\) occurrences from \(R_R\). This preserves load two on every edge, and preserves the singleton boundaries \(a,e\). It therefore produces a real \((ea)(ac)\) BF row whose first singleton-\(a\) occurrence has the right exterior \(Y_R\), while its unchanged second occurrence \(V_L\) has the left exterior \(Y_L\). [Note 271's route table](271-the-central-path-row-requires-two-distinct-shore-masks.md) forbids such a mixed row: \(Z_R\) is precisely its orientation-III, \(a:\Sigma,1B,2C\) mask, labelled **R only**. Exchanging the two complete singleton-\(a\) occurrences would leave \(Z_R\) fixed but require its one shore \(e\)-path to make the pure endpoint exchange for the left exterior too. More directly, [Note 297, (2)](297-the-right-central-ad-row-survives-the-exterior-route-check.md) shows that \(Z_R\)'s \(b,d\) routes do not exchange endpoints between \(X_a\) and the left-switched \(X_{c,L}\). This contradicts the required pure \(ea\) half with \(Y_L\). Hence the two-slot full loads differ.

Suppose instead the *full* pure-three loads were equal. Replace \(X_L,Y_L,Z_L\) in \(R_L\) by the actual \(X_R,Y_R,Z_R\). Their boundaries remain \(bcd,a,e\), and equality again preserves the six-slot load two. The resulting \((ea)(ac)\) row has the same forbidden mixed \(Y_R,V_L\) exteriors, giving the same contradiction. This proves (1).

The conclusion is independent of which singleton-\(a\) occurrence is called \(Y\). Exchanging \(Y\) and \(V\) within either real row preserves its six-slot load and type, while both occurrences have that row's same exterior mask. Therefore, for every \(L\in\{Y_L,V_L\}\) and \(R\in\{Y_R,V_R\}\), both \(L+Z_L\ne R+Z_R\) and \(X_L+L+Z_L\ne X_R+R+Z_R\). The separation concerns the complete two fibres, not just one selected witness from each.

Finally, the four-slot exterior loads are
\[
(X_L+Y_L+Z_L+V_L)|_{\rm ext}
-
(X_R+Y_R+Z_R+V_R)|_{\rm ext}
=(Y_L-Y_R)|_{\rm ext}\ne0,                       \tag{2}
\]
because \(V_L,V_R\) repeat their row's \(Y_L,Y_R\) exterior masks, and these differ, for example, at \(h_3\). Thus Note 273's left-template full-load exchange has no identical-exterior premise in the genuine right branch. \(\square\)

**Theorem (two-path threading, one row at a time).** In *every* actual left \((ea)(ac)\) row under the stated exact support, the unique full \(a\)--\(e\) terminal path of \(Y_L\triangle Z_L\) traverses **both** exterior alternating paths
\[
\begin{aligned}
P:\;&I-u_1-B_{\rm ext}-t_d-E_{\rm ext}-t_c-A_{\rm ext}
       -t_b-D_{\rm ext}-u_4-J,\\
Q:\;&D-u_2-C_{\rm ext}-u_3-H.                         \tag{3}
\end{aligned}
\]
The same holds for \(Y_R\triangle Z_R\) in *every* actual right \((ea)(ad)\) row. This conclusion needs only the one row being discussed, its complete perfect matchings, and the exact-support pure-route rule; it does not assume the opposite row exists.

**Proof.** The masks in Notes 271 and 297 show directly that \(P,Q\) are vertex-disjoint exterior paths, alternating between the row's singleton-\(a\) and singleton-\(e\) matchings. The remaining exterior difference has an arm from terminal \(a\) to shore port \(A\) and an arm from terminal \(e\) to shore port \(E\). All full \(Y\triangle Z\) components are alternating cycles except one \(a\)--\(e\) path \(T\).

Switch \(T\) between \(Y,Z\), then relabel the resulting singleton-\(a\) matching as \(Y^*=Z\triangle T\) and the singleton-\(e\) matching as \(Z^*=Y\triangle T\). Their sum, the six-slot load, and the row type are unchanged; \(V\) is untouched. In the left row, \(Z_L\) uses the right singleton-\(a\) edges on both \(P,Q\). Switching the terminal arms gives \(Y^*\) boundary \(a\). If \(T\) contains neither \(P\) nor \(Q\), its exterior is \(Y_R\); if it contains exactly one, the exterior is a hybrid of \(Y_L,Y_R\); if it contains both, the exterior is \(Y_L\). Note 271's route table and no-mixed-sides result require the last case because the unchanged \(V_L\) has exterior \(Y_L\). The right row has the reversed roles: \(Z_R\) starts with the left edges on \(P,Q\), while \(V_R\) has exterior \(Y_R\). Note 297's rowwise classification again requires \(T\) to contain both paths. \(\square\)

Equivalently, the three open shore paths of \(Y\triangle Z\) must pair all six ports into a single full terminal route through both exterior edges \(IJ\) and \(DH\). Its shore pairing has one of the eight forms
\[
 A p\mid p' q\mid q'E
 \quad\text{or}\quad
 A q\mid q' p\mid p'E,
 \qquad
 \{p,p'\}=\{I,J\},\quad \{q,q'\}=\{D,H\}.           \tag{4}
\]
In particular the shore \(Y\triangle Z\) path cannot pair \(A\) directly with \(E\). The eight forms are necessary, not a construction of a forbidden BF row.

**Singleton-fibre consequence.** The two complete singleton-\(a\) occurrences \(Y_R,V_R\) in any genuine right row are distinct, just as \(Y_L,V_L\) are in Note 271's left row. Indeed, if \(Y_R=V_R\), delete their common shore edges. The remaining shore graph has degree two at every internal vertex, and each edge carries a two-slot label from \(\{X_R,Z_R,U_R,W_R\}\). At each internal vertex the labels on its two incident edges are complementary. The four open-port label sets are \(\{Z_R,U_R\}\) at \(E,J\) and \(\{Z_R,W_R\}\) at \(A,H\). A complementary or equal label can meet \(\{Z_R,U_R\}\) only at \(J\), so the \(X_R\triangle Z_R\) shore \(e\)-path pairs \(E\) with \(J\). This contradicts the pure right-row pairing \(EH\mid AJ\) in Note 297, (3).

Let \(k\) be the number of closed components of \(Y\triangle Z\) in either row. Since the terminal path contains all exterior difference paths, every such component is wholly shore-internal. Switching any subset of these \(k\) components between \(Y,Z\) yields \(2^k\) distinct complete singleton-\(a\) matchings with the original exterior mask. None equals the unchanged \(V\): otherwise the switched six-slot row would have duplicate singleton-\(a\) occurrences, contrary to Note 271 on the left or the preceding right-row argument. Therefore the shore matching fibre with ports \(HJ\) on the left, respectively \(ID\) on the right, has size at least \(2^k+1\). In particular a two-element fibre forces \(Y\triangle Z\) to have no closed component.

**Forced internal binary circulation.** Define
\[
\Delta=(Y_L+Z_L)-(Y_R+Z_R).
\]
Equation (1) makes \(\Delta\ne0\). In fact some coefficient of \(\Delta\) is **odd**. If all coefficients were even, the two edge sets
\[
 F_L=Y_L\triangle Z_L,\qquad F_R=Y_R\triangle Z_R
\]
would be identical, because an edge has odd pair load exactly when it lies in the corresponding symmetric difference. The unique \(a\)--\(e\) terminal path would then be the same path in \(F_L=F_R\). Its alternating colouring is fixed by the \(Y\)-edge at terminal \(a\), so \(Y_L\) and \(Y_R\) would choose the same edges along that path. This contradicts their opposite choices on \(P\) (and on \(Q\)), which the two-path theorem places on the terminal path.

The coefficient of \(\Delta\) is zero on every exterior edge and on each of the six shore ports: both pairs select \(E,A,I,D,H,J\) once in total. At every internal shore vertex the sum of the three incident coefficients is zero, since each pair consists of two complete perfect matchings. Reducing modulo two, the odd-coefficient edges therefore form a nonempty even-degree subgraph wholly inside the shore. Since the shore is cubic, this subgraph is a disjoint union of cycles. A cycle may use the subdivision vertex \(t_e\). This is a binary discrepancy of **pair loads**, stronger than mere nonzero integer circulation or the row-internal \(Y\triangle V\) cycle of Note 271; its cycles need not be alternating for a matching pair from one BF row.

The total length of this binary cycle union is even. Each \(F_L,F_R\) consists of even alternating cycles and one \(a\)--\(e\) alternating path, which also has even length because its first edge belongs to \(Y\) and its last to \(Z\). Hence \(|F_L\triangle F_R|\equiv |F_L|+|F_R|\equiv0\pmod2\). In particular the binary discrepancy cannot consist of just one odd cycle; it has either an even cycle or at least two odd cycles.

There is a cycle-space separation from the row-internal singleton switches. Let \(D\) be the odd-coefficient edge set of \(\Delta\), and let \(\mathcal C_L,\mathcal C_R\) be the sets of alternating-cycle components of \(Y_L\triangle V_L\) and \(Y_R\triangle V_R\), respectively. All these cycles are shore-internal. Then
\[
 D\notin
 \operatorname{span}_{\mathbb F_2}(\mathcal C_L)
 +\operatorname{span}_{\mathbb F_2}(\mathcal C_R).       \tag{5}
\]
For if \(D\) were the symmetric difference of selected cycles from the two sets, switch those \(Y/V\) components in their respective rows. The switches preserve each six-slot load and each row type, while toggling precisely the selected cycles in the parity of its \(Y+Z\) load. The new left and right pair loads would have identical parity, contradicting the preceding terminal-path argument, which applies to every genuine row of these two orientations. Thus no sequence of switches confined to the repeated singleton-\(a\) pairs can remove the binary discrepancy; another matching fibre must enter any cross-row alignment.

**The pure-half defect supplies the missing cycle class.** Put
\[
 A_i=X_i+Y_i+Z_i,\qquad
 \Omega_i=\{f:A_i(f)\in\{0,2\}\}\quad(i=L,R).
\]
Each displayed pure half has load one on every exterior edge and on every shore port. At a cubic shore vertex the three incident \(A_i\)-loads sum to three and each lies in \(\{0,1,2\}\). Thus they are either \((1,1,1)\) or a permutation of \((0,1,2)\). Consequently \(\Omega_i\) is a shore-internal disjoint union of even cycles, alternating between load-zero and load-two edges. It is nonempty: if \(A_i=\mathbf1\), the opposite \(ac\) or \(ad\) half \(2\mathbf1-A_i\) is also unit and supplies a forbidden \(T\)-state Tait colouring.

The defect has the stronger rowwise separation
\[
 \Omega_i\notin \operatorname{span}_{\mathbb F_2}(\mathcal C_i)
 \qquad(i=L,R).                                      \tag{6}
\]
Indeed, membership would make \(\Omega_i\) a union of whole, mutually disjoint components of \(Y_i\triangle V_i\). Switch those components between \(Y_i,V_i\). On every selected \(Y_i\)-only edge the old pure-half load is two, and on every selected \(V_i\)-only edge it is zero: the reverse values would violate the row load two. The switch changes both values to one. Every other edge already has pure-half load one, so the switched row gives a forbidden \(T\)-state Tait colouring. This proves (6), extending the full-difference observation of [Note 254](254-the-b-cross-rows-require-shore-cycle-intersections.md) to *every subset* of singleton-difference components. The same argument applies to any cubic-pole BF row with a repeated singleton boundary across its halves whenever the opposite half's Tait state is forbidden; the central-path masks are used only to confine \(\Omega_i\) to the shore and to obtain (7).

More precisely, switching a component \(C\) of \(Y_i\triangle V_i\) gives \(\Omega_i'=\Omega_i\triangle C\): on a \(Y_i\)-only edge the half-load changes \(1\leftrightarrow0\) or \(2\leftrightarrow1\), and on a \(V_i\)-only edge it changes \(0\leftrightarrow1\) or \(1\leftrightarrow2\). Thus these rowwise switches generate the affine cube
\(\Omega_i+\operatorname{span}_{\mathbb F_2}(\mathcal C_i)\), and (6) says this cube avoids zero. If \(c_i=|\mathcal C_i|\), these switches give \(2^{c_i}\) distinct state-\(ea\) pure-half load vectors with the same unit exterior load. Both \(c_L,c_R\ge1\), and the two orientations' load sets are disjoint by (1). Thus a pole carrying both genuine rows has at least
\[
                         2^{c_L}+2^{c_R}\ge4
\]
different complete pure state-\(ea\) half-load vectors above that one exterior load.

Modulo two, \(A_i\bmod2=\mathbf1+\mathbf1_{\Omega_i}\) edgewise. Writing \(C_X=X_L\triangle X_R\), whose edges are shore-internal because the zero-port exterior masks coincide, gives the exact cycle-space identity
\[
 \boxed{D=C_X\triangle\Omega_L\triangle\Omega_R.}     \tag{7}
\]
Thus the cross-row binary discrepancy is supplied by the zero-port matching difference and the two pure-half defect systems. By (5), their combined class cannot lie in the span of the two row-internal singleton switch families. In particular, if the two rows use the same complete \(X\), their pure-half defect sets must differ.

The result is rank-free and uses actual matchings from both genuine rows. It does not exclude their coexistence: a rank-at-least-seven core has room for a nonzero internal binary circulation. The unresolved complete-closure step is to constrain or eliminate this circulation using other positive Case-XII cells and the forbidden \(T\)-loops/\(T\)--\(T\) rows. The proof relies on the hand-derived exterior masks and pure-route theorem of Notes 271 and 297 and has not had independent second-source review. No local graph enumeration or OMEN run was used.
