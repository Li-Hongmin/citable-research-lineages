> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Global Kempe action excludes MMT Case VIII

This note applies the stabilizer-complete global component-switch closure of
Notes 048--052 to the 36-type exact five-cut support
(H_{\\mathrm{VIII}}) in the Mácajová--Mazzuoccolo--Tabarelli (MMT)
Appendix. The statement is conditional on that transcription and ordered
semiedge convention.

## Statement

The greatest fixed point of the necessary global Kempe-action system has
empty fibres over the twelve supported types
[
egin{gathered}
(13)(34),(13)(45),(14)(34),(14)(35),(14)(45),(24)(34),\\
(24)(35),(24)(45),(25)(34),(25)(45),(34)(35),(35)(45).
end{gathered}
]
Hence no real cubic 5-pole has complete BF support exactly
(H_{\\mathrm{VIII}}).

Together with Notes 046, 048, 049, 051 and 052, this conditionally excludes
Cases I, II, III, V, VI, VII, VIII and XIII from the MMT 13-case list.
Case IV is a strict closure of this action method (Note 050); Cases IX--XII
and the cyclically-6-connected branch remain open.

## Fixed-point certificate

A state records all nonempty two-colour boundary path pairings of one
labelled BF-colouring. A component switch preserves the switched pair's
route and every route for a disjoint colour pair. No persistence is imposed
for overlapping pairs, and internal alternating cycles are omitted, so the
finite system over-approximates the actual colouring action. All colour
relabellings to a target representative are retained, including target
stabilizers.

For (H_{\\mathrm{VIII}}), the system has
[
|H_{\\mathrm{VIII}}|=36,qquad
|\\mathscr S_0|=427,qquad
N_{\\mathrm{switch}}=8540.
]
Six greatest-fixed-point rounds delete (177,2,4,32,96,16) states. One
short certificate uses the supported type ((13)(45)): its two initial
states, after a (01)-switch on path (14), can target only the 17 states
((14)(35)#0,ldots,16). Sixteen die in round one; the sole survivor
((14)(35)#10) has a (04)-switch on path (25) whose ten possible
((13)(35)) targets (over both stabilizer maps) all die in round one.
Thus the ((13)(45)) fibre is empty.

An actual exact-support pole would give a nonempty post-fixed family and
therefore a surviving state over every supported type, contradicting this
empty fibre.

## Scope and certificate

This is a boundary-action exclusion only. It does not address Cases IV, IX,
X, XI or XII, and it does not address cyclically-6-connected graphs. The
stabilizer-complete certificate is

../scratch/worker-mmtt-case-viii-global-action/verify_case_viii_global_kempe_action.py

and ends with
CASE_VIII_GLOBAL_KEMPE_ACTION_EXCLUDED.
