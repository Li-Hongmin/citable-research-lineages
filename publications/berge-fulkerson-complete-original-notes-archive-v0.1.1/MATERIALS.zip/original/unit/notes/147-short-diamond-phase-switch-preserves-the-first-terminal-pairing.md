> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short aligned diamond preserves the first terminal pairing

The six-edge owner classification in [Note 146](146-short-aligned-diamond-forces-a-three-owner-tait-defect-cycle.md) has a further consequence for the actual fixed-\(B_2\) phase transfer of [Notes 143](143-four-junction-phase-concentration-and-the-fixed-b-carrier-path-gate.md) and [144](144-fixed-singleton-phase-cube-has-two-terminal-pairing-gates.md). In this branch the first terminal-pairing gate is automatic. The second gate is also automatic for one of the four owner patterns. These are conditional full-mask statements; they do not construct an exact-Case-XII pole or a common \(B_2+C_4\) seed.

Fix a normalized four-junction row
\[
U_{35}+Z_3+D_5+r_{34}+Y_3+C_4=2\mathbf1
\]
with no state-\(34\) Tait colouring and a six-edge component \(\Omega\) of \(Z_3\triangle Y_3\). Fix an actual right row and literal carrier equality
\[
q_{25}+B_2+D_5+r_{34}+Y_3+C_4=2\mathbf1,
\qquad q_{25}+B_2=U_{35}+Z_3,
\]
where \(B_2=U_{35}\) on every edge of \(\Omega\). Thus \(q_{25}=Z_3\) at every vertex of \(\Omega\). Put \(q^0=q_{25}\), \(q^1=q_{25}\triangle E(\Omega)\), and switch \(Y_3\) with \(q_{25}\) on \(\Omega\) to obtain the second actual right row. When the open component of \(q^\epsilon\triangle r_{34}\) beginning at terminal \(2\) ends at \(3\), denote it by \(P^\epsilon\) and set \(p^\epsilon=q^\epsilon\triangle E(P^\epsilon)\).

**Theorem.** The terminal pairing of \(q^0\triangle r_{34}\) equals that of \(q^1\triangle r_{34}\), without assuming the absence of all-terminal or \(T\)--\(T\) BF types. More precisely, the two differences have the same edges outside \(\Omega\). Inside \(\Omega\) each has one three-edge path between the same two off-cycle \(r_{34}\)-edges, and these paths are the complementary arcs of \(\Omega\). For the following two formulas assume the common terminal pairing includes \(2\leftrightarrow3\), as exact Case XII requires. If the first path belongs to \(P^0\), then
\[
E(P^0)\triangle E(P^1)=E(\Omega),\qquad p^0=p^1.       \tag{1}
\]
If it belongs to the other open component or to a closed component, then
\[
P^0=P^1,\qquad p^1=p^0\triangle E(\Omega).               \tag{2}
\]
In particular the first gate of Note 144 excludes none of these four short aligned patterns. In the \((1,2,1,2)\) pattern of Note 146, switching \(p^0\) to \(p^1\) also preserves the terminal pairing of \(p^\epsilon\triangle D_5\). Thus both gates are automatic for this particular phase switch in that pattern.

**Proof.** Number the six successive edges of \(\Omega\) as \(e_1,\ldots,e_6\), beginning at the overloaded-arm junction and traversing the four strands \(\alpha,\beta,\gamma,\delta\) in Note 146. Its four allowable owner sequences put the two \(r_{34}\)-owned cycle edges at positions \((2,5)\) or \((1,4)\). One is an \(rY\) edge and the other an \(rZ\) edge. They are opposite edges of the hexagon. Since \(r_{34}\) is a perfect matching, at the two remaining cycle vertices it uses off-cycle edges; on the other four vertices it uses its two opposite cycle edges. Since \(q^0=Z_3\) and \(q^1=Y_3\) at the cycle vertices, each \(q^\epsilon\) uses one of the two alternating three-edge perfect matchings of the hexagon. Directly from the four owner sequences, the cycle portions \(A^\epsilon=(q^\epsilon\triangle r_{34})\cap E(\Omega)\) are

| Strand lengths | \(A^0\) | \(A^1\) |
|---|---|---|
| \((2,2,1,1),(2,1,2,1)\) | \(e_1,e_2,e_3\) | \(e_4,e_5,e_6\) |
| \((1,2,1,2),(1,1,2,2)\) | \(e_6,e_1,e_2\) | \(e_3,e_4,e_5\) |

Thus each phase has one three-edge arc between the same two off-cycle \(r\)-edges, and the arcs partition \(E(\Omega)\). All difference edges outside \(\Omega\) are unchanged. Replacing a path segment by another with the same endpoints preserves every global component and its terminal ends. If that component is \(P^0\), its two routes differ by exactly \(E(\Omega)\), giving (1). Otherwise \(P^0\) is untouched, giving (2).

For the \((1,2,1,2)\) row, the \(D_5\)-owned edges of \(\Omega\) are \(e_3=YD\) and \(e_6=ZD\). They too are opposite and have different singleton phases. If (1) holds, the complete \(p\) mask is unchanged. If (2) holds, \(p^0=Z_3\) and \(p^1=Y_3\) at every vertex of \(\Omega\), while the two masks agree outside it. The same opposite-edge argument, now with \(D_5\) in place of \(r_{34}\), replaces one three-edge \(p\triangle D\) arc by the complementary arc between the two unchanged off-cycle \(D\)-edges. Thus its terminal pairing is unchanged. \(\square\)

For comparison, the complete \(D_5\)-port profile of the four patterns is as follows. The positions refer to the cyclic \(e_1,\ldots,e_6\) used in the proof.

| Strand lengths | \(D_5\)-owned cycle edges | Off-cycle \(D_5\) ports | Local effect when (2) holds |
|---|---|---:|---|
| \((2,2,1,1)\) | \(e_4=YD\) | 4 | Two-pair reconnection |
| \((2,1,2,1)\) | none | 6 | Three-pair reconnection |
| \((1,2,1,2)\) | \(e_3=YD,\ e_6=ZD\) | 2 | One path reroutes; pairing fixed |
| \((1,1,2,2)\) | \(e_6=ZD\) | 4 | Two-pair reconnection |

To see the four-port reconnections explicitly, write \(e_i=v_{i-1}v_i\) with \(v_6=v_0\). In the \((2,2,1,1)\) row the local pairings are \((v_0v_1)(v_2v_5)\) and \((v_0v_5)(v_1v_2)\). In the \((1,1,2,2)\) row they are \((v_1v_2)(v_3v_4)\) and \((v_1v_4)(v_2v_3)\). Here \((v_iv_j)\) denotes a path between two off-cycle \(D\)-ports, not necessarily an edge. Therefore the terminal pairing of \(p^\epsilon\triangle D_5\) changes **if and only if** both of its open terminal paths meet \(\Omega\): each then uses one local port-to-port path, and the switch reconnects the two paths across ports. If only one open path meets \(\Omega\), the other remains untouched and fixes the pairing of all four terminal ends. In the six-port pattern the local pairings are the two alternating perfect matchings of the six ports; the exterior connections decide whether the terminal pairing changes. The exact Case-XII negative support and a missing common seed require the second pairing to remain \(5\leftrightarrow4\) in all four patterns, by Note 144. Thus the two four-port patterns require one open \(p+D\) path to avoid \(\Omega\) in branch (2); the two-port pattern imposes no such requirement.

There is also an exact description of Note 146's Tait-defect cycle in this six-edge branch. In the first two patterns its disjoint S pair is \((D_5,Z_3)\), and in the last two it is \((U_{35},Z_3)\). Let \(X\) be the third S matching and \(X^*\) the Tait complement of the disjoint pair. Off the three overloaded diamond strands the S half-load is one, so \(X=X^*\). On every S-overloaded edge of these strands \(X=1,X^*=0\), and on every T-overloaded edge \(X=0,X^*=1\). Hence \(X\triangle X^*\) is **exactly** the single overloaded cycle consisting of the \(\alpha\) and \(\delta\) strands and the type-\(13\) chord. Its length is \(3+|\text{chord}|\ge6\) in a girth-five pole. This identifies the certificate cycle but does not turn it into a forbidden BF type.

The Case-XII boundary support used to interpret the two gates is from Máčajová--Mazzuoccolo--Tabarelli (2026), Proposition 4.4 and Appendix XII; that source does not assert a full-mask phase intersection.
