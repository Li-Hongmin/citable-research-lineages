> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Coherent Kempe routing excludes three MMT five-cut cases

This note gives a necessary-condition reduction for the 13 five-cut pairs
listed by Máčajová--Mazzuoccolo--Tabarelli (MMT). It is conditional only on
the Appendix transcription of their 13 pairs; it does not use graph
generation and does not claim to eliminate any of the remaining ten cases.

## Kempe routing as an actual simultaneous constraint

Let \(H\) be a cubic 5-pole with a BF-colouring \(\varphi\). For two colours
\(a,b\), the subgraph formed by the edges whose labels meet
\(\{a,b\}\) has boundary endpoints at the semiedges where exactly one of
\(a,b\) occurs. Each component starting at a semiedge is an alternating
\(a\)--\(b\) path. If there are four endpoints, its two path components
induce one of the three pairings of those endpoints.

Switching \(a\) and \(b\) on either path is a BF-colouring of the same
5-pole. If \(\{a,b\}\) and \(\{c,d\}\) are disjoint colour pairs, the two
switches commute: exchanging \(a,b\) does not change the edge set induced by
\(\{c,d\}\), and conversely. Therefore the actual routing chosen by one
pair must remain compatible with the actual routing chosen by every disjoint
pair. This is stronger than the type-level condition that merely asks for
some one- and two-switch outcomes.

## Case XIII

The \(R^*\)-side of Case XIII contains the type \((12345)\). Use the
representative boundary labels

\[
 \{0,1\},\ \{0,2\},\ \{0,3\},\ \{0,4\},\ \{0,5\}.
\]

For colours \(0,2\), the four endpoints are positions \(1,3,4,5\). The
three possible path pairings give, after switching on one component,

\[
 (13)(45),\qquad (14)(35),\qquad (15)(34).
\]

None of these three types occurs in the MMT Appendix set \(R^*\) for Case
XIII. Whichever pairing is realised in \(H\), a forbidden BF type is
obtained. Hence no cubic 5-pole can have that exact admissible type set.

## Cases III and VI

Both \(L^*\)-sets contain the type \((25)(34)\). Relabel colours so that
the boundary labels are

\[
 \{0,1\},\ \{0,2\},\ \{1,3\},\ \{1,4\},\ \{0,5\}.
\tag{1}
\]

For the three disjoint colour pairs below, the possible endpoint routings
and the resulting boundary types are:

\[
\begin{array}{c|c|c}
\text{pair}&\text{routing}&\text{type after one switch}\\ \hline
0,3&12|35&(25)(45)\\
    &13|25&(14)(25)\\
    &15|23&(24)(25)\\[1mm]
1,2&12|34&(15)(34)\\
    &13|24&(34)(45)\\
    &14|23&(34)(35)\\[1mm]
1,5&13|45&(24)(34)\\
    &14|35&(23)(34)\\
    &15|34&(12)(34)
\end{array}
\tag{2}
\]

In both Cases III and VI, the first row of the \(0,3\) block is absent,
so its actual routing is either

\[
 A=13|25\quad\text{or}\quad B=15|23.
\]

The \(1,2\) block has only \(14|23\) available, and the \(1,5\) block has
only \(13|45\) available. Since the colour pairs are disjoint, the actual
switches commute. A direct boundary calculation gives

\[
 A+(1,2)\longmapsto (14)(35),
 \qquad
 B+(1,5)\longmapsto [24].
\tag{3}
\]

The type \((14)(35)\) is absent from both \(L^*\)-sets in Cases III and VI,
and \([24]\) is also absent from both. Thus \(A\) is impossible by the
forced \(1,2\) routing, while \(B\) is impossible by the forced \(1,5\)
routing. The type \((25)(34)\) therefore cannot occur in either exact
admissible set.

Consequently Cases III and VI are impossible as exact type sets.

## Resulting conditional reduction

MMT's Appendix lists exactly 13 candidate pairs after its own necessary
conditions. The simultaneous routing argument above removes III, VI and
XIII, leaving

\[
 \mathrm{I},\mathrm{II},\mathrm{IV},\mathrm{V},\mathrm{VII},
 \mathrm{VIII},\mathrm{IX},\mathrm{X},\mathrm{XI},\mathrm{XII}.
\]

This is a reduction of the exact-connectivity-five branch only. It does
not address the cyclically-\(\ge 6\) branch, and it does not by itself
exclude any of the ten remaining cases.

## Verification and scope

The Appendix transcription was checked against the locally cached MMT PDF
(read 2026-08-29). The deterministic certificates are:

    python3 units/berge-fulkerson/scratch/stage2-import/bf_5cut_certificate.py
    python3 units/berge-fulkerson/scratch/stage2-import/kempe_routing_audit.py

They report eliminated: III,VI,XIII and remaining:
I,II,IV,V,VII,VIII,IX,X,XI,XII. The computation only checks the finite
boundary consequences of actual Kempe path pairings; the mathematical
content is the commuting-switch argument above. A formal publication
claim should still state explicitly that the reduction is conditional on
MMT's exhaustive 13-pair enumeration and its semiedge-order convention.
