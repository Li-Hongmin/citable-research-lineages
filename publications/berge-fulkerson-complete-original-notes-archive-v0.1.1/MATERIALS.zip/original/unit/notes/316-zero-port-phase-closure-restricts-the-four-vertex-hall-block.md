> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Zero-port phase closure restricts the four-vertex Hall block

Continue the genuine left \((ea)(ac)\) and right \((ea)(ad)\)
rows of the noncollision, complete exact-Case-XII \(R_0=DJ\)
near-bipartite branch. By
[Note 315](315-no-three-vertex-six-cut-hall-block-in-the-right-dj-branch.md),
the first possible \((\alpha,\eta)=(2,1)\) six-cut Hall witness has
\(|S|=4\). Its necessary incidence graph has
\[
 S=\{h,k,\ell,m\},\quad
 T=\{o,r,s,t\},
\]
with edges
\[
 o\{h,k,\ell\},\qquad r\{h,m\},\qquad
 s\{k,m\},\qquad t\{\ell,m\}.                         \tag{1}
\]
Here \(H\) is based at \(h\), another proper \(B\)-port
\(P\in\{A,I\}\) at \(k\), and \(\ell d\) leaves the block.
The remaining vertex \(m\) has no outward incidence. Since \(o\)
already has cubic degree in (1), the \(J\)-port base lies in
\(\{r,s,t\}\).

**Theorem.** If \(j=s\) or \(j=t\), every actual zero-proper-port
shore matching selecting \(g,t_{ew}\) must use \(\ell d\).
Moreover, \(j=s\) with \(P=I\) is impossible. Thus the four-vertex
Hall incidence shape, if realized at all, cannot use that port
placement.

**Proof of the phase restriction.** A zero-port matching \(X\)
selects neither \(H,P,D,J\). It covers the four \(S\)-vertices
through \(T\) and possibly \(\ell d\). If it avoids \(\ell d\),
its restriction to \(S\cup T\) is one of exactly three perfect
matchings:
\[
\begin{aligned}
 M_h&=\{ho,ks,\ell t,mr\},\\
 M_k&=\{hr,ko,\ell t,ms\},\\
 M_\ell&=\{hr,ks,\ell o,mt\}.
\end{aligned}                                                   \tag{2}
\]
Any two differ on one alternating six-cycle. Switching that cycle
in the actual \(X\) reaches either of the other restrictions and
does not change \(X\) outside \(S\cup T\), including its selected
\(g,t_{ew}\).

If \(j=s\), switch to \(M_k\). Its shore complement contains the
complete local path \(P-k-s-J\), because \(ko,ms\) are selected.
If \(j=t\), switch to \(M_\ell\). Its complement contains
\(J-t-\ell-d-D\): \(\ell o,mt\) are selected, \(\ell d\)
and \(D\) are unselected, and the zero-port matching covers \(d\)
by its third edge. Both path pairings are forbidden under complete
exact support. Indeed, [Note 285's two actual forbidden-\(eb\)
completions](285-any-second-zero-port-profile-forces-s-tait-in-the-three-two-core.md)
allow only \(EA\mid ID\mid HJ\) or \(EJ\mid AD\mid IH\) for
the complement of any zero-port \((g,t_{ew})\) matching with
\(R_0=DJ\); neither contains \(PJ\) for \(P=A,I\) or
\(JD\). Therefore \(X\) must use \(\ell d\).

**Proof for \(P=I,j=s\).** In the real right row, the \(U(EJ)\)
matching uses
\[
                       ko,hr,mt,\ell d.                       \tag{3}
\]
Take either \(Q\in\{Y,V\}\), which selects \(I\) at \(k\)
and \(D\) at \(d\). If \(Q\) used \(\ell o\), then
\(D-d-\ell-o-k-I\) would be a complete path of
\(U\triangle Q\), contrary to the forced \(EI\mid DJ\)
pairing of [Note 309](309-the-allowed-ea-cd-switch-forces-the-opposite-right-row-route.md).
Thus \(Q\) uses \(\ell t\). If it used \(mr\), the same
difference would contain the complete path
\(D-d-\ell-t-m-r-h-o-k-I\), again forbidden. Since \(k\)
is covered by \(I\) and \(\ell\) by \(\ell t\), the only
remaining choice is \(ms,ho\). Hence both \(Y,V\) use
\(\ell t,ms,ho\).

At \(h\), ports \(H\) are selected by \(Z,W\), edge \(ho\)
by \(Y,V\), and therefore edge \(hr\) by \(U,X\).
At \(s=j\), port \(J\) is selected by \(U,Z\), edge \(ms\)
by \(Y,V\), and hence edge \(ks\) by \(X,W\). Since \(o\)
has no outward edge and \(h,k\) are already matched by \(X\)
to \(r,s\), respectively, \(X\) must use \(\ell o\). It then
uses \(mt\) at \(m\). Thus \(X\) has the full block matching
\(M_\ell\), contrary to the phase restriction just proved for
\(j=s\). \(\square\)

**Subsequent correction.** [Note 319](319-no-four-vertex-six-cut-hall-block-in-the-right-dj-branch.md)
observes that, for \(j=r\), the internal phase \(M_k\) has a
forbidden \(H\)--\(D\) complementary path. Thus the earlier
claim that \(j=r\) has no direct forbidden local pair was false.
Notes 317–319 exclude all four-vertex positions. The theorem proved
above for \(j=s,t\) and its exclusion of \((I,s)\) are unchanged.
Larger Hall blocks, the \((1,2)\) allocation, incidence collisions,
other shore profiles, and Berge–Fulkerson remain open. This is a
hand-derived complete-matching closure argument; no local
recomputation or OMEN run was used.
