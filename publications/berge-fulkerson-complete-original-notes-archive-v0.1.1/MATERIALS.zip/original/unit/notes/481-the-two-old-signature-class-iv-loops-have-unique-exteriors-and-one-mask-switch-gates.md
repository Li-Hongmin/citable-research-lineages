> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The two old-signature class-IV loops have unique exteriors and one-mask switch gates

Continue the fixed marked Hamilton exterior of [Notes 476 and 479](479-ten-d2-hamilton-phases-force-forbidden-rows-and-six-need-cross-port-closure.md). In the \(D_2\) class-IV phase take \(\sigma=a,\bar\sigma=b\); interchanging \(a,b\) gives the other phase. The old genuine row has two zero-port complete shore matchings \(Q_P,Q_R\) and four singleton shore matchings with signatures
\[
 Q_a:\{e,p_1,p_2,p_4\},\quad Q_b:\{e,p_2,p_3,p_4\},\quad
 Q_J:\{p_1,p_5\},\quad Q_K:\{p_3,p_5\}.                 \tag{1}
\]
Here \(P=eX,R=eZ\), and \(J=X,K=Z\) in the **old** exterior row. A new row may give a singleton occurrence another terminal while retaining its complete shore matching. The forbidden types for this orientation are \([eX],[eY],(eX)(eY)\), as in the [published Appendix XII](../../../../ResearchLibrary/lib/editamacajova2026cycle/editamacajova2026cycle.pdf). Note 479 excludes these types when each of the four singleton signatures in (1) occurs once. [Note 480](480-cross-balanced-shore-colours-force-the-zero-port-masks-to-coincide.md) excludes the two other old-signature multiplicities if only the six old **complete** shore masks are used and every zero-port shore matching has an odd closed complementary component. The point here is to classify their exterior completions and the first possible new-mask step.

## Exterior classification at \(t=0,2\)

At \(t=0\), the two \(e\)-singleton slots both have ports \(\{e,p_2,p_3,p_4\}\), and the two other singleton slots both have ports \(\{p_1,p_5\}\). At \(t=2\), these port sets are \(\{e,p_1,p_2,p_4\}\) and \(\{p_3,p_5\}\). Write \(E\) for an \(e\)-singleton, \(N_j\) for a singleton with terminal \(j\in\{X,Y\}\), and \(T_j\) for a zero-port triple of state \(ej\). In the following table, \(X4\) means the half of the marked edge \(X=14\) incident with original vertex \(4\), and \(X*\) means the terminal semiedge. These are **all** exterior restrictions with the stated port and terminal sets. Each row's unlisted tree halves are forced by matching the six original vertices.

| Ports | Restriction | \(X\) | \(Y\) | \(Z\) | \(W\) | Selected tree halves \(u_i:v\) |
|---|---|---|---|---|---|---|
| either | \(T_X^1\) | \(X1\) | \(Y*\) | \(Z*\) | \(W*\) | \(u_1:2,u_2:3,u_3:4,u_4:5,u_5:6\) |
| either | \(T_X^4\) | \(X4\) | \(Y*\) | \(Z*\) | \(W*\) | \(u_1:1,u_2:2,u_3:3,u_4:5,u_5:6\) |
| either | \(T_Y^1\) | \(X*\) | \(Y1\) | \(Z*\) | \(W*\) | \(u_1:2,u_2:3,u_3:4,u_4:5,u_5:6\) |
| either | \(T_Y^5\) | \(X*\) | \(Y5\) | \(Z*\) | \(W*\) | \(u_1:1,u_2:2,u_3:3,u_4:4,u_5:6\) |
| \(t=0\) | \(E_0\) | \(X4\) | \(Y5\) | \(Z2\) | \(W3\) | \(u_1:1,u_5:6\) |
| \(t=0\) | \(E_1\) | \(X4\) | \(Y1\) | \(Z6\) | \(W3\) | \(u_1:2,u_5:5\) |
| \(t=0\) | \(N_X^0\) | \(X*\) | \(Y1\) | \(Z2\) | \(W6\) | \(u_2:3,u_3:4,u_4:5\) |
| \(t=0\) | \(N_X^1\) | \(X*\) | \(Y1\) | \(Z6\) | \(W3\) | \(u_2:2,u_3:4,u_4:5\) |
| \(t=0\) | \(N_Y^0\) | \(X1\) | \(Y*\) | \(Z6\) | \(W3\) | \(u_2:2,u_3:4,u_4:5\) |
| \(t=0\) | \(N_Y^1\) | \(X1\) | \(Y*\) | \(Z2\) | \(W6\) | \(u_2:3,u_3:4,u_4:5\) |
| \(t=2\) | \(E_0\) | \(X1\) | \(Y5\) | \(Z2\) | \(W3\) | \(u_3:4,u_5:6\) |
| \(t=2\) | \(E_1\) | \(X4\) | \(Y1\) | \(Z2\) | \(W6\) | \(u_3:3,u_5:5\) |
| \(t=2\) | \(N_X^0\) | \(X*\) | \(Y5\) | \(Z6\) | \(W3\) | \(u_1:1,u_2:2,u_4:4\) |
| \(t=2\) | \(N_X^1\) | \(X*\) | \(Y5\) | \(Z2\) | \(W6\) | \(u_1:1,u_2:3,u_4:4\) |
| \(t=2\) | \(N_Y^0\) | \(X4\) | \(Y*\) | \(Z6\) | \(W3\) | \(u_1:1,u_2:2,u_4:5\) |
| \(t=2\) | \(N_Y^1\) | \(X4\) | \(Y*\) | \(Z2\) | \(W6\) | \(u_1:1,u_2:3,u_4:5\) |

For example, at \(t=0\), an \(E\)-matching uses ports \(p_2,p_3,p_4\). Original vertices \(3,4\) force \(W3,X4\); the remaining four original vertices admit precisely \(E_0,E_1\). An \(N_X\)-matching uses \(p_1,p_5\); vertices \(1,5,4\) successively force \(Y1,u_4:5,u_3:4\), leaving the two \(u_2,Z,W\) assignments in the table. The other rows follow by the same forced-vertex argument. For a zero-port triple, orienting the Hamilton tree from the selected half of its missing mark gives the two listed roots.

Impose load two on the marked halves. The following implications use only one or two entries of the table at a time:

| Ports | Proposed type | Forced choices, or contradiction |
|---|---|---|
| \(t=0\) | \([eX]\) | Both \(E\)'s take \(X4\), forcing both \(T_X^1\); both \(N_X\)'s take \(Y1\), forcing both \(E_0\); their \(W3\) load forces both \(N_X^0\); then \(Z2\) has load four. |
| \(t=0\) | \([eY]\) | Both \(E\)'s take \(W3\), forcing both \(N_Y^1\); their \(Z2\) load forces both \(E_1\); their \(Y1\) load forces both \(T_Y^5\). |
| \(t=0\) | \((eX)(eY)\) | \(W3\) forces \(N_X^0,N_Y^1\); their common \(Z2\) forces both \(E_1\); then \(Y1\) has load at least three. |
| \(t=2\) | \([eX]\) | Both \(N_X\)'s take \(Y5\), forcing both \(E_1\); their \(X4\) load forces both \(T_X^1\); their \(W6\) load forces both \(N_X^0\). |
| \(t=2\) | \([eY]\) | Both \(N_Y\)'s take \(X4\), forcing both \(E_0\); their \(W3\) load forces both \(N_Y^1\); then \(Z2\) has load four. |
| \(t=2\) | \((eX)(eY)\) | Both \(E\)'s take \(Z2\), forcing \(N_X^0,N_Y^0\); their \(W3\) load forces both \(E_1\); then \(X4\) has load at least three. |

In the two surviving rows, every matching restriction of the same role is identical **on the exterior**. The three restrictions are, respectively,
\[
t=0,\ [eY]:\qquad (T_Y^5,E_1,N_Y^1),                 \tag{2}
\]
\[
t=2,\ [eX]:\qquad (T_X^1,E_1,N_X^0).                 \tag{3}
\]
In each displayed triple, the three restrictions partition every exterior edge and put one occurrence on each proper port; doubling the triple therefore gives load two. This checks sufficiency of the exterior templates, not existence of their shore restrictions. Hence a forbidden row using only the four old singleton **port signatures** exists precisely when the shore has a load-two six-matching completion with the \(t=0\) signatures for (2) or the \(t=2\) signatures for (3). The \(t=1\) multiplicity is excluded by Note 479, and both \(t=0,2\) candidates of double-triple type \((eX)(eY)\) are excluded above, before considering complete shore masks.

## Exactly one new complete shore mask

Assume \(Q_P\ne Q_R\), as the exact-Case-XII odd-complement condition of [Note 359](359-two-root-parity-gate-and-k33-sharpness.md) requires by Note 230(5). Relative to the six complete shore masks of the old row, a forbidden old-signature row with **exactly one** new mask must keep \(Q_P,Q_R\) as its two zero-port restrictions and change one singleton restriction. Indeed, if the new mask were zero-port, the other four restrictions would be two copies of one old \(e\)-singleton mask and two copies of one old non-\(e\) mask. At every shore vertex those two masks would have to use different edges, leaving the same third edge to both zero-port occurrences. They would coincide, contrary to the odd-complement condition.

There are exactly four possible one-new equations, written edgewise on the **entire** shore:

| Forbidden loop | Repeated old singleton | Required new complete mask |
|---|---|---|
| \(t=0,\ [eY]\) | \(Q_J\) | \(Q_b^*=Q_a+Q_K-Q_J\) |
| \(t=0,\ [eY]\) | \(Q_b\) | \(Q_J^*=Q_a+Q_K-Q_b\) |
| \(t=2,\ [eX]\) | \(Q_K\) | \(Q_a^*=Q_b+Q_J-Q_K\) |
| \(t=2,\ [eX]\) | \(Q_a\) | \(Q_K^*=Q_b+Q_J-Q_a\) |

The subtraction notation is a test, not an assumption that its result is a matching. For a source pair \(U,V\) and repeated mask \(W\) in any line, it is a genuine shore perfect matching **if and only if**
\[
             U\cap V=\varnothing,\qquad W\subseteq U\cup V. \tag{4}
\]
For sufficiency, \(U,V\) choose two different incident edges at every shore vertex, and \(W\) chooses one of them. The other edge gives the perfect matching \(U+V-W\), with the required complementary port signature. Conversely, a source-overlap edge already has both old BF labels \(U,V\), so it cannot also carry \(W\); there \(U+V-W=2\). A \(W\)-edge outside their union gives value \(-1\). Both violate a matching vector. Equivalently, on each alternating path or cycle of \(U\triangle V\), the repeated \(W\) chooses one of its two alternating phases and the new matching chooses the other.

If any one of the four gates (4) holds, substitute its new shore mask and use exterior template (2) or (3). The old row equation then gives load two on every shore edge, while the template gives load two on every exterior edge. Thus the corresponding **forbidden full BF loop is real**. The constructed mask cannot equal the omitted old singleton mask: that equality would balance the two old singleton pairs edgewise and force \(Q_P=Q_R\) by Note 480. If the odd-complement premise holds, Note 480 rules out a zero-new-mask row, so a one-new-mask forbidden row exists **if and only if** one of these four gates holds. Under exact Case XII all four gates must fail. If they fail, any forbidden row retaining only old port signatures requires at least two new complete shore masks. This remains a condition on one fixed old row and one fixed exterior, not an exclusion of class IV.

In Note 479's six-cycle shore, \(Q_R,Q_b,Q_J\) partition the shore, as do \(Q_P,Q_a,Q_K\) (Note 480). Gluing their doubled triples to (2) and (3) gives both forbidden loops \([eY]\) and \([eX]\) on that genuine 21-vertex pole. Its zero-port complements have no odd closed component, so this does not meet the exact-Case-XII premise.

The support-preserving Petersen substitution of [Note 381](381-petersen-shore-replacement-preserves-full-bf-support-and-forces-odd-cycles.md) gives a sharper real boundary. Insert its three-pole at the class-IV cycle vertex \(q_2\), attaching the old edges \(PJ,RK,ab\) to \(v_1,v_4,u_0\), respectively. In the old lifted row assign
\[
(P,J)=(M_2,M_4),\qquad (R,K)=(M_1,M_3),\qquad
(a,b)=(M_\infty,M_0),                                  \tag{5}
\]
using the six Petersen matchings of Note 381(2). Every zero-port shore complement has an odd internal five-cycle. The unchanged old shore edges labelled \(PJ,Pb,RK,Ra\) respectively violate the four containment gates in the table.

In fact the **exact** old-signature new-mask count of either forbidden loop on this pole is three. After deleting the gadget, the remaining shore vertices form the path \(q_3-q_5-q_1-q_e-q_4\). At \(t=0\), each \(e\)-singleton uses the ports at \(q_e,q_3,q_4\), so its sole edge on that path is \(q_5q_1\); each other singleton uses the ports at \(q_5,q_1\), so it takes \(q_eq_4\) and the attachment at \(q_3\). To load \(q_3q_5\) and \(q_1q_e\) twice, **both** zero-port matchings must take the attachment at \(q_4\) and follow the old \(Q_R\) outside the gadget. At \(t=2\), the two \(e\)-singletons take \(q_3q_5\), the two other singletons take \(q_1q_e\) and the attachment at \(q_4\), and both zero-port matchings must take the attachment at \(q_3\) and follow old \(Q_P\) outside the gadget. All four singleton restrictions outside the gadget are likewise fixed by these path edges and their port sets.

In any six-matching BF row across the Petersen gadget, every occurrence uses exactly one of its three attachments: odd cut parity gives at least one, and the three attachment edges have total load six. Restoring the deleted vertex gives six Petersen perfect matchings. They are all distinct, since repeating one would require a load-two completion of its complement's two odd five-cycles. Note 381 lists all six Petersen matchings, and their attachment pairs are exactly (5). Thus at \(t=0\), the two zero slots use \(M_1,M_3\), the two \(e\) slots use \(M_\infty,M_0\), and the two \(Y\) slots use \(M_2,M_4\), in some order. At \(t=2\), the zero, \(e\), and \(X\) slot pairs use \(M_2,M_4\), \(M_\infty,M_0\), and \(M_1,M_3\). In each role pair exactly one complete shore matching equals an old mask; the other is new. Hence every old-signature forbidden row on this particular 29-vertex pole uses **exactly three** new complete shore masks.

Both forbidden loops have **old-signature full-row certificates**. Lift the doubled \(t=0\) base row \((Q_R,Q_b,Q_J)\) through the same Petersen six-matching cover, assigning \(M_1,M_3\) to its two zero slots, \(M_\infty,M_0\) to its two \(e\)-singleton slots, and \(M_2,M_4\) to its two \(Y\)-singleton slots. Lift the doubled \(t=2\) base row \((Q_P,Q_a,Q_K)\) similarly, assigning \(M_2,M_4\) to the zero slots, \(M_\infty,M_0\) to the \(e\) slots, and \(M_1,M_3\) to the \(X\) slots. At the three gadget attachments each lifted row has the required paired labels; Note 381's Petersen cover loads every internal gadget edge twice. All exterior and other shore edges retain their doubled base templates (2) or (3). Thus the 29-vertex pole has genuine forbidden \([eY]\) and \([eX]\) rows with **no new port signature**, despite the odd-zero condition and failure of all four one-mask gates. It has a cyclic three-edge cut and is not exact Case XII.

The full old-signature interface has therefore been reduced to two explicit shore load-two completions and four first-switch gates. It does not determine whether an arbitrary exact-Case-XII shore admits a forbidden row through two or more new complete masks or through new port signatures. The exterior classification and switching argument are hand-derived, with no OMEN or local mathematical recomputation, and await independent proof review. \(\square\)

Later boundary: [Note 482](482-the-p1-p3-alternating-path-is-the-exact-paired-singleton-closure-gate.md) characterizes the next paired-singleton exchange. Keeping \(Q_P,Q_R\), replacing one \(e\)-singleton and one non-\(e\) singleton produces \([eY]\) or \([eX]\) exactly when \(p_1,p_3\) are paired by \(Q_a\triangle Q_K\) or \(Q_b\triangle Q_J\), respectively.

Odd-zero correction: [Note 485](485-odd-zero-forces-distinct-forbidden-loop-masks-and-leaves-one-two-mask-gate.md) shows that the four one-new-mask gates (4), though algebraically exact, are **automatically false** under Note 359's odd-zero premise. Each constructed row repeats a complete singleton pole matching and hence yields a forbidden Tait state with a clean zero-port shore mask. With at most two new masks, only Note 482's paired-singleton path gate remains decision-bearing.
