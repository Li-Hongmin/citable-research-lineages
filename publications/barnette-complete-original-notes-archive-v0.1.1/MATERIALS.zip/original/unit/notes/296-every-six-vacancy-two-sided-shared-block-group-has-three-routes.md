> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every six-vacancy two-sided shared-block group has three routes

Notes 294 and 295 settle the five-vacancy minimum and the six-vacancy
case in which the extra vacancy enlarges the component through the
shared block. The remaining six-vacancy case puts the extra vacancy
in a port component. Splitting that vacant block's ordinary vertices
on the two sides of its alternating detour gives the three spanning
four-port routes. Thus every two-sided shared-block group with at most
six vacancies has the same \(S/K/X\) signature.

Use the compressed, gapless, tight-target all-square opening of
Notes 275 and 278, with every vacancy in a distinct target-free
internal face-chord block. Fix a free group with retained ordinary
end links. Up to reflection, the port-extended six-vacancy pattern
has indices
\[
 i<j<k\le s-1<m=s+1,\qquad m+2\le u<w,             \tag{1}
\]
and interval \(Q=B_i,\ldots,B_w\). The blocks
\(B_i,B_j,B_k,B_m,B_u,B_w\) are vacant, \(B_s\) is short,
and the only missing ordinary links of this group are
\(P_s=e_so_m\) and \(P_m=e_mo_{m+1}\). The three distinguished
atom components are
\[
 \{V_i,V_m,V_w\},\qquad \{V_j,V_k,P_s\},\qquad
 \{P_m,V_u\}.                                           \tag{2}
\]
Their eight complementary-matching edges are
\[
\begin{array}{lll}
 H_iI_w,&I_iH_m,&I_mH_w,\\
 H_jo_m,&I_jH_k,&I_ke_s,\\
 e_mI_u,&o_{m+1}H_u.&
\end{array}                                              \tag{3}
\]
All other ordinary links in \(Q\) are retained. The proper
block gaps are
\[
 G_1=B_{i+1},\ldots,B_{j-1},\quad
 G_2=B_{j+1},\ldots,B_{k-1},\quad
 G_3=B_{k+1},\ldots,B_{s-1},
\]
\[
 G_4=B_{m+1},\ldots,B_{u-1},\qquad
 G_5=B_{u+1},\ldots,B_{w-1}.                            \tag{4}
\]
Only \(G_4\) must be nonempty. Every additional component
meeting \(Q\) is vacancy-only and lies wholly in one of these
gaps by noncrossing. Hence each nonempty gap is closed under
its matching. Let Note 275's spanning straight path be \(S(G_h)\),
and let its disjoint crossed rails be
\[
 T_h:a_{\min G_h}\longleftrightarrow b_{\max G_h},
 \qquad
 D_h:o_{\min G_h}\longleftrightarrow e_{\max G_h}.
                                                               \tag{5}
\]

**Port-extended routing theorem.** The interval \(Q\) has
vertex-spanning states
\[
\begin{array}{ll}
 S(Q):&o_i\longleftrightarrow e_w,\\
 K(Q):&a_i\longleftrightarrow o_i,\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_i\longleftrightarrow b_w,\quad
       o_i\longleftrightarrow e_w.
\end{array}                                              \tag{6}
\]
The five gaps may have arbitrary lengths and arbitrary nested
vacancy-only components. The theorem also holds with a three-atom
right port component by reflection. Other vacancy-only components
may surround the whole interval.

**Proof.** First define three local traversals. The first
\(A:b_i\leadsto e_i\) covers \(G_1\), if nonempty:
\[
 A=\begin{cases}
 b_i,e_i,&G_1=\varnothing,\\
 b_i,a_{i+1}\xrightarrow{T_1}b_{j-1},e_{j-1}
 \xrightarrow{D_1^{-1}}o_{i+1},e_i,&G_1\ne\varnothing.
 \end{cases}                                             \tag{7}
\]
The second, \(B:b_j\leadsto e_j\), covers \(G_2\) and
the first two ordinary vertices of \(B_k\):
\[
 B=\begin{cases}
 b_j,a_k,o_k,e_j,&G_2=\varnothing,\\
 b_j,a_{j+1}\xrightarrow{T_2}b_{k-1},a_k,o_k,
 e_{k-1}\xrightarrow{D_2^{-1}}o_{j+1},e_j,&G_2\ne\varnothing.
 \end{cases}                                             \tag{8}
\]
The third, \(D:o_s\leadsto a_s\), covers \(G_3\) and
the remaining ordinary vertices of \(B_k\):
\[
 D=\begin{cases}
 o_s,e_k,b_k,a_s,&G_3=\varnothing,\\
 o_s,e_{s-1}\xrightarrow{D_3^{-1}}o_{k+1},e_k,b_k,
 a_{k+1}\xrightarrow{T_3}b_{s-1},a_s,&G_3\ne\varnothing.
 \end{cases}                                             \tag{9}
\]
All joins in (7)--(9) are old-cycle edges, face chords,
or retained ordinary links. The crossed rails in each
nonempty gap are disjoint and span that gap. The two pieces
\(B,D\) use, respectively, \(a_k,o_k\) and \(e_k,b_k\);
the vacancy slots \(H_k,I_k\) remain available for the
port-component matching path
\[
 I_j,H_k,I_k,e_s.                                     \tag{10}
\]

The **straight route** begins with
\[
 o_i,a_i,A,I_i,H_i,I_w,H_w,I_m,H_m,o_m,H_j,o_j,
 a_j,B,I_j,H_k,I_k,e_s,D,b_s,a_m,b_m,e_m,
 I_u,H_u,o_{m+1}.                                     \tag{11}
\]
In (11), \(A\) starts at \(b_i\) after \(a_ib_i\),
\(B\) starts at \(b_j\) after \(a_jb_j\), and \(D\)
starts at \(o_s\) after \(e_so_s\). Continue from
\(o_{m+1}\) across \(S(G_4)\) to \(e_{u-1}\), use the
retained link to \(o_u\), then \(o_u,a_u,b_u,e_u\).
If \(G_5\) is empty, finish through \(e_u,o_w,a_w,b_w,e_w\).
Otherwise finish through
\[
 e_u,o_{u+1}\xrightarrow{S(G_5)}e_{w-1},o_w,a_w,b_w,e_w.
                                                               \tag{12}
\]
The outer-component detour \(I_i,H_i,I_w,H_w,I_m,H_m\)
visits its six vacancy slots. The left port detour visits
\(H_j,I_j,H_k,I_k\); the right visits \(I_u,H_u\).
The block and gap traversals cover every other vertex once.
Thus (11)--(12) give \(S(Q)\).

For the **cap route**, keep the edge \(e_wb_w\) as its
right path. The other path starts
\[
 a_i,b_i
 \xrightarrow{\ G_1\text{ top}\ }a_j,B,I_j,H_k,I_k,e_s,D,
 b_s,a_m,o_m,H_j,o_j
 \xrightarrow{\ G_1\text{ bottom}^{-1}\ }e_i,I_i,H_m
 \xrightarrow{C\text{ forward}}I_w,H_i,o_i.          \tag{13}
\]
The two \(G_1\) passages mean, for a nonempty gap,
\[
 b_i,a_{i+1}\xrightarrow{T_1}b_{j-1},a_j,
 \qquad
 o_j,e_{j-1}\xrightarrow{D_1^{-1}}o_{i+1},e_i;    \tag{14}
\]
for an empty gap they are \(b_i a_j\) and \(o_j e_i\).
The segment \(B\) covers \(G_2,a_k,o_k\), while \(D\)
covers \(G_3,e_k,b_k\). The long old-cycle arc from
\(H_m\) to \(I_w\) covers every vertex on its right,
independent of the two missing ordinary links. It omits
exactly \(e_w,b_w\), so (13)--(14) give \(K(Q)\).

For the **crossed route**, take the bottom path
\[
 o_i,H_i,I_w,e_w.                                    \tag{15}
\]
The top path starts
\[
 a_i,A,I_i,H_m,o_m,H_j,o_j,a_j,B,I_j,H_k,I_k,
 e_s,D,b_s,a_m,b_m.                                   \tag{16}
\]
From \(b_m\), use both crossed rails of the nonempty
\(G_4\):
\[
 b_m,a_{m+1}\xrightarrow{T_4}b_{u-1},e_{u-1}
 \xrightarrow{D_4^{-1}}o_{m+1},H_u,o_u,a_u,b_u,
 e_u,I_u,e_m,I_m,H_w,o_w.                              \tag{17}
\]
If \(G_5\) is empty, finish \(o_w,a_w,b_w\). Otherwise
finish
\[
 o_w,e_{w-1}\xrightarrow{D_5^{-1}}o_{u+1},
 a_{u+1}\xrightarrow{T_5}b_{w-1},a_w,b_w.             \tag{18}
\]
The two paths in (15)--(18) have the endpoint pairing in
(6). The top uses every block vertex except
\(o_i,H_i,I_w,e_w\), which the bottom uses. Every gap
is covered by its two disjoint rails. This proves \(X(Q)\).

The argument uses the proper gaps only through their
\(S,X\) signatures; other pre-established closed gap
signatures may be substituted with the displayed boundary
links retained. Vacancy-only components outside \(Q\)
are serial or surrounding and compose by Note 275. Note 273
joins the free groups, while Notes 001 and 178 lift the
marked Hamilton parent cycle to the legal child and restore
the original lobe lengths. \(\square\)

**Complete six-vacancy corollary.** Suppose one free group
has exactly two consecutive missing ordinary links, their
shared block is vacant, its vacancy-only component extends
to both sides of that block, and the group has at most six
vacancies. Then the full group has \(S,K,X\). If every other
free group has its ordinary spanning route, the parent has
a Hamilton cycle through both site edges and its legal
expanded child is Hamiltonian.

Note 292 gives a lower bound of five vacancies in this
two-sided situation. At five, Note 294 settles the unique
component-size pattern. At six, Note 278 and the same lower
bounds leave one extra vacancy. It either joins the shared-block
vacancy-only component, giving Note 295 and its reflection,
or joins one of the two port components, giving (1)--(18)
and its reflection. A new vacancy-only component needs at
least two atoms, so there is no fourth case. \(\square\)

**Analytic sharp-port family.** For arbitrary
\(d_1,\ldots,d_5\ge0\), take
\[
 i=1,\quad j=2+d_1,\quad k=j+1+d_2,
 \quad s=k+1+d_3,\quad m=s+1,
 \quad u=m+2+d_4,\quad w=u+1+d_5,\quad r=w.           \tag{19}
\]
Use the old cycle and the unchanged site, face, escape, and
residual-square edges of Note 281(8)--(9). Make precisely
\(B_i,B_j,B_k,B_m,B_u,B_w\) vacant, use (3), and retain
every other ordinary link. The matching is perfect, joins
opposite old-cycle colours, and is noncrossing in the disk
opposite the site face: \(H_iI_w\) is outermost,
\(I_iH_m\) encloses the left port part, and \(I_mH_w\)
encloses the right port part; the two internal left-port
edges and retained links are nested or disjoint.

Retained links connect the face chords along the left and
right standard-chain pieces. The special edges \(H_iI_w\)
and \(I_iH_m\) attach the shared-block face chord and the
right chain to the left one. Every other special edge
interlaces an endpoint face chord. The unchanged site and
residual-square edges give Note 281's closing interlacement
chain, so the full matching-chord interlacement graph is
connected. Notes 217 and 182 give three-vertex-connectivity.
The parent and legal expanded child have, respectively,
\[
 56+4\sum_{h=1}^{5}d_h,\qquad 60+4\sum_{h=1}^{5}d_h
                                                               \tag{20}
\]
vertices and the asserted Hamilton cycles.

The six-vacancy corollary exhausts this sharp two-sided
shared-block branch under the stated opening hypotheses.
Seven or more vacancies, repeated or target-bearing vacancies,
positive gaps, nonsquare residual cycles, and Barnette's
general conjecture remain open.
