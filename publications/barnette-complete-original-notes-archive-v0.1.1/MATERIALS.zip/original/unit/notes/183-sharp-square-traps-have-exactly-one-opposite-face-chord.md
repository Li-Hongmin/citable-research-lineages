> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Sharp square traps have exactly one opposite-face matching chord

[Note 182](182-two-long-facial-gaps-require-six-free-main-vertices.md)
proves the sharp main-segment bound \(|V(S_0)|\ge2\ell+10\)
for an all-square-trap facial opening with two long site gaps.
At equality, the other site-face arc uses exactly one
matching chord. This constrains the face boundary without
assuming that the arc alternates between matching and cycle
edges.

Use the reduced one-square-per-lobe form of Notes
[178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)--[179](179-saturated-square-trap-main-segments-create-two-edge-cuts.md).
The old-vertex main segment \(S_0\) runs from \(x\) to \(v\),
with site ports in the order \(x<y<u<v\). The residual
squares have escape targets in the order
\(R_\ell,L_\ell,\ldots,R_1,L_1\), where \(R_i\) has odd
\(S_0\)-index and \(L_i\) even index. The matching chords
\(q=xy,p=uv\) lie on the common-face side of the parent
Hamilton cycle \(C\).

**Theorem.** Suppose both facial arcs between the site edges
have length at least three, every trapped segment of the
chosen opening is a square, and
\[
|V(S_0)|=2\ell+10.
\tag{1}
\]
Then the other facial arc from \(y\) to \(u\) contains exactly
one edge of the complementary perfect matching
\(M=E(G)\setminus E(C)\). If this arc is alternating, it has
length exactly three. That conditional length conclusion is
sharp for every \(\ell\ge1\), by Note 182. Moreover, both
\(y\) and \(u\) lie strictly inside escape-pair gaps
\((R_i,L_i)\), possibly the same gap.

**Proof.** By (1), precisely six vertices of \(S_0\) are
neither site ports nor escape targets. Call them free. Their
matching edges form three internal \(S_0\) chords. Suppose
the face arc from \(y\) to \(u\) contains \(r\ge2\) matching
edges. The facial boundary order lemma of Note 176 places
all vertices of this arc strictly inside the \(C\)-interval
from \(y\) to \(u\), apart from its two ends. Every matching
edge on the arc therefore uses two distinct free vertices
in \((y,u)\): the site ports are already matched to each
other side, and the escape targets are matched to residual
squares on the side of \(C\) opposite this face. Thus
\(2r\ge4\) free vertices lie in \((y,u)\).

The \(C\)-edges immediately after \(y\) and immediately
before \(u\) start at odd indices of \(S_0\). None of the
\(r\) face-arc matching chords crosses either edge, since
both endpoints of each chord lie strictly between \(y,u\).
At most \(3-r\le1\) other internal matching chord remains.
By Note 179's even-cut bridge lemma, each of these two
\(C\)-edges must therefore be straddled by an escape pair.
Hence \(y\) lies strictly inside a pair gap \((R_i,L_i)\),
and \(u\) strictly inside a pair gap \((R_j,L_j)\).
Parity requires at least one free vertex \(s\) in the
\(y\)-gap before \(y\), and at least one free vertex \(t\)
in the \(u\)-gap after \(u\). Thus at least two of the six
free vertices lie outside \((y,u)\), so \(2r\le4\) and
\(r=2\).

The four free endpoints of the two face-arc chords now
exhaust all free vertices in \((y,u)\). The remaining free
vertices are \(s<y\) and \(t>u\), which must be matched
to each other. If \(i\ne j\), the chord \(st\) interlaces
\(q=xy\), so it lies opposite the common face. It encloses
an escape target between the two distinct pair gaps; that
target's escape chord would cross \(st\), contradicting
planarity. If \(i=j\), no escape target lies between
\(y,u\). The four free vertices of \((y,u)\) are then
consecutive on \(C\). Every bipartite perfect matching of
four consecutive vertices contains an edge joining two
consecutive vertices: the two possibilities pair either the
first two or the middle two. Such a matching edge would
duplicate a \(C\)-edge, contradicting simplicity. Thus
\(r\ge2\) is impossible.

It remains to exclude an arc containing no matching chord.
In that case the face arc is the entire \(C\)-path from
\(y\) to \(u\). Every interior vertex of this path has
its matching edge on the side of \(C\) opposite the face;
otherwise that edge would interrupt the face boundary.
We use the following chord observation. A matching chord
between two *different* escape-target gaps cannot lie on
this opposite side: an intervening escape target and its
escape chord would cross it. Thus such a chord lies on the
face side and, to avoid crossing \(q=xy\) and \(p=uv\),
both its ends must lie in the same one of the three regions
\((x,y),(y,u),(u,v)\). The middle region has no vertex
available for a face-side matching edge, by the first
sentence of this paragraph.

Suppose first that \(y\) lies in a nonpair gap and \(u\)
in a different gap. The edge immediately after \(y\) is
unstraddled. Note 179's cut lemma forces two of the three
internal matching chords to cross it. Both interlace \(q\),
so they lie opposite the face and have all four endpoints
in the gap containing \(y\). That gap contains \(y\) but
not \(u\), and has even size, so it contains at least five
free vertices. The gap containing \(u\) needs at least one
free vertex by the same parity rule. Hence the distribution
is exactly five and one. The two chords crossing after
\(y\) use four of the first five; the remaining free vertex
must pair with the sole free vertex in the \(u\)-gap. This
is a cross-gap chord. If its first endpoint is before \(y\),
the chord interlaces \(q\); if its second endpoint is after
\(u\), it interlaces \(p\). In the remaining case both ends
lie in \((y,u)\), where no face-side chord is possible.
Each case contradicts the chord observation. The symmetric
argument excludes \(u\) in a nonpair gap when \(y\) lies
in a different gap.

If both ports lie in the *same* nonpair gap, the edges
immediately after \(y\) and before \(u\) are unstraddled.
The cut lemma requires two matching chords across each.
Consequently at least two free vertices lie before \(y\)
and at least two after \(u\). The long target-free \(C\)-arc
from \(y\) to \(u\) contains at least two more free
vertices. These are all six free vertices, so exactly two
occur in each of the three regions. The two vertices before
\(y\) must both match to the right, and the two after
\(u\) both to the left. The two middle vertices are
consecutive on \(C\), so they cannot match each other.
Every internal matching chord therefore crosses \(y\) or
\(u\), interlaces a site chord, and lies opposite the face.
But a noncrossing perfect matching on six linearly ordered
free vertices has a pair of consecutive free vertices.
Such a pair here has either zero or one site port between
its ends: with zero it duplicates a \(C\)-edge, and with
one its ends have the same bipartite colour. This is
impossible.

Now suppose \(y,u\) lie in *distinct pair gaps*. Each of
these gaps contains an odd number of free vertices, because
it contains one site port and has even size. At least one
matching chord must leave each gap. By the chord observation,
such a chord from the \(y\)-gap must join a free vertex
before \(y\) to an earlier gap in \((x,y)\), while a chord
from the \(u\)-gap must join a free vertex after \(u\) to a
later gap in \((u,v)\). The two further gaps are different,
contain no site port, and therefore each have at least two
free vertices. With only six free vertices in total, the
four gaps have free counts exactly \(1,1,2,2\). In the
earlier two-free gap, one vertex must match the sole free
vertex of the \(y\)-gap. Its other vertex has no possible
partner in \((x,y)\), while a cross-region face chord or a
cross-gap opposite-side chord is forbidden. This is a
contradiction.

Finally suppose \(y,u\) lie in the *same pair gap*. It
contains at least four free vertices: one before \(y\),
two between \(y,u\), and one after \(u\). If it contains
all six, it has at most three free vertices before \(y\)
and at most three after \(u\). Any two of at most three
consecutive free vertices in either outer region are
adjacent on \(C\) or have the same colour. There can be
no matching chord on the face side within either region;
there is none in the middle region, and a chord across
regions interlaces a site chord. Hence all three chords lie
opposite the face. The same consecutive-free-pair argument
as above excludes a noncrossing perfect matching: two
consecutive free vertices have at most one site port
between them, since at least two free vertices separate
\(y,u\). If this pair gap contains four free vertices,
the remaining two lie in one further gap and are consecutive
on \(C\), so they cannot match each other. Both must pair
across gaps on the face side. If the further gap is earlier,
both partners inside the pair gap must lie before \(y\),
but there is only one such vertex; if later, both must lie
after \(u\), again only one. This is impossible.

All placements with zero matching chords have been excluded.
Together with the first part, the opposite face arc has
exactly one matching chord.

Let its two endpoints be \(a,b\in(y,u)\). If \(y,u\)
were in the same nonpair gap, the cut lemma would force
both remaining internal chords to cross the edges after
\(y\) and before \(u\). Their four endpoints would lie
outside \((y,u)\), within that gap. The only two free
vertices between the ports would then be \(a,b\), adjacent
on \(C\), so their matching edge would duplicate a
\(C\)-edge. If \(y\) were in a nonpair gap different from
the \(u\)-gap, the two remaining chords would both cross
the edge after \(y\), lie opposite the face, and have
four endpoints in the \(y\)-gap. Gap parity requires exactly
one of \(a,b\) in that gap and the other as the sole free
vertex of the \(u\)-gap. Because \(a,b\in(y,u)\), that sole
free vertex is before \(u\), so the \(u\)-gap is nonpair.
The edge before \(u\) would then be unstraddled, yet neither
of the two remaining chords crosses it. This contradicts
the cut lemma. The symmetric argument excludes \(u\) in
a nonpair gap. Hence both ports lie in pair gaps.

If the opposite face arc is alternating, it starts and ends
with a \(C\)-edge because \(y,u\) are already matched by
\(q,p\). Its length is therefore \(2r+1\). The hypothesis
that it is long makes \(r\ge1\), while the proved bound
makes \(r\le1\); hence its length is three. Note 182's
equality construction has exactly this alternating arc.
Lobe compression leaves \(S_0\) and the opposite face arc
unchanged, so both conclusions hold before compression.
\(\square\)

Without an alternation hypothesis, the arc may follow
several consecutive \(C\)-edges. The proof fixes its
matching-chord count and makes no claim about its length
in that general case or about Hamiltonicity of every
equality configuration. [Note 184](184-every-sharp-square-trap-opening-has-a-hamiltonian-child.md)
uses the six free vertices to settle both questions at
the same sharp boundary.
