> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three maximal outer words have marked Hamilton cycles

[Note 421](421-maximal-chorded-seven-face-chord-failures-reduce-to-four-outer-words.md), equation (12), leaves four realizable words in the maximal chorded single-hexagon branch. [Note 422](422-all-four-maximal-outer-words-have-legal-barnette-expansions.md) proves that each belongs to a legal Barnette expansion. Here rows 1, 2, and 5 are Hamiltonian by explicit spanning paths, using respectively two, three, and two of their seven face-side main chords.

**Three-row Hamilton theorem.** Every reduced child specified by row 1, 2, or 5 of Note 421 (12) is Hamiltonian. In its 90-vertex parent the Hamilton cycle can be chosen to contain both site edges \(q=w_0y_6\) and \(p=x_7w_*\); hence it lifts directly through the standard square to the 94-vertex child.

**Row 1.** Write its word as

\[
K=F(U_6,U_7),\quad B=F(U_5,K),\quad A=F(U_3,U_4),\quad
D=F(A,B),\quad E=F(U_2,D),\quad W=F(U_1,E).
\tag{1}
\]
For each leaf let its six vertices in old-cycle order be \(L_i,h_i,x_i,y_i,j_i,R_i\), and set
\[
Y_i=(y_i,x_i,h_i,j_i,R_i,L_i),\qquad
X_i=(R_i,L_i,h_i,j_i,y_i,x_i),\qquad
O_i=(L_i,h_i,x_i,y_i,j_i,R_i).
\tag{2}
\]
All three are spanning paths of \(U_i\). For a branch \(F(P,Q)\), use opening brackets \(\lambda_0,\lambda_1,\lambda_2\) and closing brackets \(\rho_2,\rho_1,\rho_0\) in old-cycle order. Its first and last vertices are \(F_\ell=\lambda_0,F_r=\rho_0\). The three bracket-only spanning paths used below are
\[
\begin{aligned}
T^-_D&=(D_r,\lambda_0^D,\lambda_1^D,\rho_1^D,\rho_2^D,\lambda_2^D),\\
T_A&=(A_\ell,\lambda_1^A,\lambda_2^A,\rho_2^A,\rho_1^A,A_r),\\
T_B&=(B_\ell,B_r,\rho_1^B,\lambda_1^B,\lambda_2^B,\rho_2^B).
\end{aligned}
\tag{3}
\]
In each line every consecutive pair is either an old-cycle edge or one of the three matching bracket chords.

The following path runs through the entire 78-vertex word \(W\):
\[
\begin{aligned}
y_6&\xrightarrow{Y_6}L_6,
\lambda_2^K,\lambda_1^K,K_\ell,
R_5\xrightarrow{X_5}x_5,
y_4\xrightarrow{Y_4}L_4,
R_3\xrightarrow{X_3}x_3,
y_2\xrightarrow{Y_2}L_2,\\
&\lambda_2^E,\lambda_1^E,E_\ell,
R_1\xrightarrow{O_1^{-1}}L_1,
\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,
E_r,\rho_1^E,\rho_2^E,\\
&D_r\xrightarrow{T^-_D}\lambda_2^D,
A_\ell\xrightarrow{T_A}A_r,
B_\ell\xrightarrow{T_B}\rho_2^B,
K_r,\rho_1^K,\rho_2^K,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{4}
\]
The displayed jumps \(x_5y_4\) and \(x_3y_2\) are precisely two chords of row 1's matching I. Every other junction between different leaf or branch paths is an old-cycle edge: \(L_6\lambda_2^K\), \(K_\ell R_5\), \(L_4R_3\), \(L_2\lambda_2^E\), \(E_\ell R_1\), \(L_1\lambda_2^W\), \(\rho_2^WE_r\), \(\rho_2^ED_r\), \(\lambda_2^DA_\ell\), \(A_rB_\ell\), \(\rho_2^BK_r\), and \(\rho_2^KR_7\). The step \(W_\ell W_r\) is the outer ordinary chord of \(W\). Thus every step of (4) is an edge of the parent.

Equation (4) uses the six vertices of each of \(U_1,\ldots,U_7\) once. It uses all six brackets of \(W,D,A,B\), the three opening and three closing brackets of \(E,K\), also once. The count is \(7\cdot6+6\cdot6=78\), so (4) is spanning. In the full old-cycle order (1) of Note 422, it closes to the parent Hamilton cycle
\[
w_0\xrightarrow{q}y_6\xrightarrow{(4)}x_7\xrightarrow{p}w_*,
z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0.
\tag{5}
\]
Outside \(W\), the non-cycle steps are \(t_bb,\alpha\beta,t_cc\); all appear in Note 422. Both site edges occur in (5), so clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the cycle to the child. \(\square\)

**Row 2.** Write its word as
\[
K=F(U_4,U_5),\quad B=F(K,U_6),\quad A=F(U_3,B),\quad
D=F(A,U_7),\quad E=F(U_2,D),\quad W=F(U_1,E).
\tag{6}
\]
Use the leaf paths in (2), and also \(Z_i=(y_i,j_i,R_i,L_i,h_i,x_i)\). The following five bracket-only paths are spanning in their respective six bracket vertices:
\[
\begin{aligned}
T^-_E&=(E_r,E_\ell,\lambda_1^E,\rho_1^E,\rho_2^E,\lambda_2^E),\\
T_K&=(\rho_2^K,\rho_1^K,K_r,K_\ell,\lambda_1^K,\lambda_2^K),\\
T_B&=(B_\ell,\lambda_1^B,\lambda_2^B,\rho_2^B,\rho_1^B,B_r),\\
T_A^+&=(\rho_2^A,\lambda_2^A,\lambda_1^A,\rho_1^A,A_r,A_\ell),\\
T_D&=(\lambda_2^D,\lambda_1^D,D_\ell,D_r,\rho_1^D,\rho_2^D).
\end{aligned}
\tag{7}
\]
The spanning \(y_6\)--\(x_7\) path of the row-2 word is
\[
\begin{aligned}
y_6&\xrightarrow{Z_6}x_6,
y_1\xrightarrow{Y_1}L_1,
\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,
E_r\xrightarrow{T^-_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_5\xrightarrow{X_5^{-1}}R_5,
\rho_2^K\xrightarrow{T_K}\lambda_2^K,
L_4\xrightarrow{Y_4^{-1}}y_4,
x_3\xrightarrow{X_3^{-1}}R_3,
B_\ell\xrightarrow{T_B}B_r,\\
&\rho_2^A\xrightarrow{T_A^+}A_\ell,
\lambda_2^D\xrightarrow{T_D}\rho_2^D,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{8}
\]
The three face-chord jumps are \(x_6y_1,y_2x_5,y_4x_3\), all present in row 2's matching III and odd-leaf matching. The other junctions are old-cycle edges: \(L_1\lambda_2^W,\rho_2^WE_r,\lambda_2^EL_2,R_5\rho_2^K,\lambda_2^KL_4,R_3B_\ell,B_r\rho_2^A,A_\ell\lambda_2^D,\rho_2^DR_7\). The bracket-only lines in (7) use consecutive old-cycle edges or their paired bracket chords. The middle root step \(W_\ell W_r\) is the outer ordinary chord. Thus every step is an edge.

The seven leaf paths in (8) cover each leaf once. Equation (7) covers five branch wrappers once each, and the six displayed \(W\)-brackets cover the root wrapper. Hence (8) visits \(42+36=78\) distinct vertices, all of \(W\). Substituting (8) for (4) in (5) gives a parent Hamilton cycle containing \(p,q\), and Note 001 lifts it to the child. \(\square\)

**Row 5.** Write its word as
\[
K=F(U_4,U_5),\quad E=F(U_2,U_3),\quad C_0=F(U_1,E),\quad
D=F(K,U_6),\quad A=F(C_0,D),\quad W=F(A,U_7).
\tag{9}
\]
With the same leaf and bracket notation, a spanning \(y_6\)--\(x_7\) path is
\[
\begin{aligned}
y_6&\xrightarrow{Y_6}L_6,
K_r,\rho_1^K,\rho_2^K,
R_5\xrightarrow{X_5}x_5,
y_2\xrightarrow{Y_2}L_2,
\lambda_2^E,\lambda_1^E,E_\ell,
R_1\xrightarrow{O_1^{-1}}L_1,\\
&\lambda_2^{C_0},\lambda_1^{C_0},C_{0,\ell},C_{0,r},
\rho_1^{C_0},\rho_2^{C_0},
E_r,\rho_1^E,\rho_2^E,
R_3\xrightarrow{X_3}x_3,
y_4\xrightarrow{Y_4}L_4,\\
&\lambda_2^K,\lambda_1^K,K_\ell,
\lambda_2^D,\rho_2^D,\rho_1^D,\lambda_1^D,D_\ell,D_r,
\rho_2^A,\lambda_2^A,\lambda_1^A,\rho_1^A,A_r,A_\ell,\\
&\lambda_2^W,\lambda_1^W,W_\ell,W_r,\rho_1^W,\rho_2^W,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{10}
\]
The two face-chord jumps \(x_5y_2\) and \(x_3y_4\) belong to matching III. All other joins between different modules follow the old-cycle order: \(L_6K_r,\rho_2^KR_5,L_2\lambda_2^E,E_\ell R_1,L_1\lambda_2^{C_0},\rho_2^{C_0}E_r,\rho_2^ER_3,L_4\lambda_2^K,K_\ell\lambda_2^D,D_r\rho_2^A,A_\ell\lambda_2^W,\rho_2^WR_7\). The three outer jumps \(C_{0,\ell}C_{0,r},D_\ell D_r,W_\ell W_r\) and the displayed inner \(\lambda_i\rho_i\) jumps are ordinary bracket chords. Equation (10) therefore uses edges throughout.

The leaf paths in (10) visit all seven leaves once. The \(K,E,C_0,D,A,W\) bracket groups each appear as six distinct vertices, with no overlap. Thus the path has \(42+36=78\) distinct vertices and is spanning. Closing it by the outside route (5) gives a parent Hamilton cycle through \(p,q\); the child is Hamiltonian by Note 001. \(\square\)

Consequently a non-Hamiltonian child in the \(f=7,c=32\) chorded single-hexagon branch, if one exists, must belong after reflection to row 4 of Note 421 (12). This is a necessary restriction within that branch, not a conclusion about the \(c=31\) branch or all Barnette graphs.

[Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md) subsequently supplies the missing row-4 path and closes this \(c=32\) branch.
