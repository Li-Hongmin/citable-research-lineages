> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# At most one gate always lifts, and component saturation holds through twenty

[Notes 065](065-the-degree-four-reduction-has-a-realizable-locked-nae-boundary.md)
and [068](068-even-fully-alternating-two-gate-targets-need-not-lift.md) show
that neither lockedness nor full gate-arc alternation decides whether a fixed
reduced target lifts.  [Notes 066](066-existence-level-c4-lifting-survives-through-reduced-order-eighteen.md)
and [069](069-existence-level-c4-lifting-holds-through-reduced-order-twenty.md)
show finite existence-level success through reduced order (20).  This note
isolates a proof-level sufficient condition valid at every order and uses it
to state the exact remaining family- and component-level quantifiers.

## Target matchings and their exchange graph

Fix a simple plane cubic bipartite brace (F'), a legal two-gate
(C_4)-expansion at a face (C) with gate edges (g,h), and a root edge
(e\notin E(C)).  Let

\[
\mathcal T_e=\{M:e\in M,\ F'-M\text{ consists of two cycles separating
the ends of }e\}.
\tag{1}
\]

Call (M\in\mathcal T_e) liftable when its dual target colouring satisfies
some row of Note 065(3) and the rooted forest condition of Note 065(5).
Define the target-state graph (G_e) on (mathcal T_e) by

\[
M\sim N\quad\Longleftrightarrow\quad M\triangle N
\text{ is one alternating cycle}.
\tag{2}
\]

The cycle in (2) automatically avoids (e), since every target contains
(e).

## Neutral-gate lemma

**Lemma.** If

\[
|M\cap\{g,h\}|\le1,
\tag{3}
\]

then (M) is liftable.

**Proof.** Use the dual target colouring, normalize the contracted vertex
(z) to colour (0), and let (p,q) be the two gate-neighbour colours.
A gate belongs to (M) exactly when its neighbour has colour (0).

If neither gate belongs to (M), then ((p,q)=(1,1)).  Choose the valid row
((\lambda,\rho;d)=(0,0;0)).  In the three-component forest
(H(c')-e^*), the old zero-coloured star at (z) is replaced by the path
(x_1-v-x_3), with the old attachments distributed between its ends.  This
is a tree replacement: it preserves acyclicity, the component partition, and
the path joining the two root marks.

If exactly one gate belongs to (M), suppose by symmetry that
((p,q)=(0,1)).  Choose ((\lambda,\rho;d)=(0,0;1)).  The old
monochromatic edge (zx_2), together with the other zero attachments at
(z), is replaced by the tree through (x_1-x_2-x_3); the new centre (v)
is a leaf at the one-coloured neighbour (x_4).  This again preserves the
forest component partition and the rooted path.  The case ((1,0)) is
symmetric.  Thus Note 065(5) holds in all cases. \(\square\)

The lemma gives the exact family-level reduction needed for existence-level
lifting:

\[
\text{a nonempty family with no liftable target}
\Longrightarrow
g,h\in M\quad\text{for every }M\in\mathcal T_e.
\tag{4}
\]

Equivalently, a general proof only has to treat complete target families in
which both gates are forced.

There is also a stronger component-level statement

\[
\tag{CS}
\forall\Gamma\in\operatorname{comp}(G_e),\qquad
\Gamma\text{ contains a liftable target}.
\]

By the lemma, (CS) is equivalent to its restriction to components satisfying

\[
g,h\in M\qquad\text{for every }M\in\Gamma.
\tag{FC}
\]

This equivalence concerns the stronger component-saturation property; the
original existence-level statement needs only the complete-family reduction
(4).

## Complete component theorem through order twenty

The complete even-order corpus through (20) contains (912) connected
simple cubic bipartite isomorphism representatives and (10) plane braces.
Across every legal split and nonempty unchanged-root interface there are

\[
8798\text{ interfaces},\qquad
45364\text{ target instances},\qquad
9296\text{ components of }G_e.
\tag{5}
\]

Exactly (8956) components contain a target using at most one gate and are
therefore closed by the lemma.  The other (340) components force both gates
on all (620) of their targets.  Every one of these (620) targets is also
liftable.  Hence (CS), and therefore (FC), holds for every reduced brace of
order at most (20).

The finite result is stronger pointwise.  There are (184) nonliftable
target/interface instances, and every one has a liftable neighbour (N) in
(G_e) with

\[
|N\cap\{g,h\}|\le1.
\tag{6}
\]

Thus every bad target in the covered range escapes by one alternating-cycle
exchange; no non-target intermediate state is needed for a shortest escape.

At the coarser family level, (250) interfaces force both gates throughout
(mathcal T_e), comprising (452) targets.  In this finite corpus every
such target has two fully alternating gate arcs, and each of the rows
(011,101,110) lifts.  This family premise does not describe the stronger
component problem: (84) of the (340) forced-gate components lie inside
mixed-gate families.  Moreover only (304) of the (340) forced components
have the uniform two-alternating-arcs/three-row description; the other (36)
are liftable through different local states.

The proof bundle is
[target-component-saturation-through20](../computations/bundles/target-component-saturation-through20/README.md).
A fresh run reproduced its accepted JSON byte for byte.

## Boundary

**Exact conclusion.** At every order, a target using at most one gate lifts;
therefore complete-family existence reduces to the both-gates-forced case,
and component saturation reduces exactly to forced-gate components.  The
stronger component-saturation statement holds through reduced order (20).

**Weakest load-bearing step.** The general step is the forest-preserving tree
replacement in the neutral-gate lemma.  The order bound in (5)--(6) rests on
complete isomorph-free generation and planarity filtering; all later
properties are checked directly.

**Evidence level.** The lemma and both logical reductions are proof-level.
Component saturation and one-cycle domination through order (20) are exact
computer-assisted finite theorems.

**Unresolved boundary.** For ordinary existence-level lifting, one must show
that a complete family forcing both gates still contains a liftable target.
For the stronger (CS), one must rule out a forced-gate target-state component
trapped entirely in the bad rooted partitions of Note 065(5).  Neither is
proved at arbitrary order; the first unsupported reduced order is (22).
