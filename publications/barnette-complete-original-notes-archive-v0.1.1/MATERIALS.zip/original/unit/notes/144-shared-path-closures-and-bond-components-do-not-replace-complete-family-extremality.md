> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Shared paths, recombination closures, and bond components do not replace complete-family extremality

[Note 140](140-short-gap-extreme-families-reduce-to-complete-family-gate-path-sibling-selection.md)
reduces the one-edge-gap branch to a complete-family selection problem,
while [Note 143](143-local-star-extremality-does-not-force-a-gate-sibling.md)
shows that one bad bond or one locally extreme state-
\(11\) star is insufficient.  This note proves that three stronger
localizations also fail in actual plane cubic families: two bad stars may
share their full gate path, their componentwise matching closure may contain
no repair, and even an entire connected component of the rooted bond graph
may be all bad while all of its gate siblings are nonrooted.

The remaining short-gap implication must therefore couple distinct bond
components, or use equivalent global information from the common parent and
child perfect-matching families.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
shows that this conclusion is false if it is quantified over all
interface-disjoint decorations: a real complete-family-extreme parent can
have an empty child bond graph. All counterexamples and finite conclusions
below remain valid. The final alternative survives only in the historical
legal-wide stratum, where the extra gate-face geometry is now known to be
essential.

## 1. Complete-family notation

Fix the root edge \(e\), forced gate \(g_0\), surviving gate \(g_1\), and
one-edge-gap site with selected edges \(p,q\) and short edge \(h\).  Put

\[
 \mathcal P_{e,g_0}
 =\{P:P\text{ is a perfect matching and }e,g_0\in P\},
\tag{1}
\]

and let \(\mathcal R\subseteq\mathcal P_{e,g_0}\) be the rooted targets:
the complements have exactly two cycles and the endpoints of \(e\) lie on
different cycles.  In the cross-\(g_1\)-sector graph \(B(\mathcal R)\), two
targets are adjacent when their symmetric difference is one alternating
cycle.

Write

\[
 E(B(\mathcal R))=B_{\rm bad}\mathbin{\dot\cup}B_{\rm auto},
\tag{2}
\]

where \(B_{\rm bad}\) consists of the \(h\)-avoiding
\(11\)--\(00\) bonds left by Note 139, and \(B_{\rm auto}\) consists of
the bond types transferred automatically by Notes 138--139.  For
\(b=M_{11}N_{00}\in B_{\rm bad}\), let \(P_g(b)\) be the component of

\[
 (M\mathbin\triangle N)-\{p,q\}
\tag{3}
\]

containing \(g_1\), and let \(S_g(b)\) be the gate-path child sibling from
Note 140.  If \(S_g(b)\) is rooted, its single-cycle bond to the canonical
\(C_{00}\) lift is a child supplement.

## 2. A shared gate path across two stars is insufficient

The implication

\[
\begin{aligned}
 &b_1,b_2\in B_{\rm bad}\text{ have distinct state-}11\text{ endpoints},
 \quad P_g(b_1)=P_g(b_2)\\
 &\hspace{35mm}\Longrightarrow
 S_g(b_1)\text{ or }S_g(b_2)\text{ is rooted}
\end{aligned}
\tag{4}
\]

is false.  A real order-\(24\) counterexample has graph6 string

~~~text
W???????????w?s?P_BC?I_?L??J??Ao?QO??F??`G??D_?
~~~

and decoration

\[
 e=4\!-\!17,\qquad g_0=5\!-\!14,\qquad g_1=3\!-\!22,
\tag{5}
\]

with

\[
 p=11\!-\!21,\qquad q=9\!-\!20,\qquad h=9\!-\!21.
\tag{6}
\]

In the lexicographically ordered rooted fibre, bonds
\((M_2,N_0)\) and \((M_{11},N_9)\) have distinct state-\(11\) endpoints
and the identical gate path

\[
 P_g=11-23-8-22-3-20.
\tag{7}
\]

Both child siblings lie in \(X_{uy}\).  Their complements have the same
three components

\[
\begin{aligned}
 &\{9,21,24,25,26,27\},\\
 &\{5,7,8,10,11,17,18,19,22,23\},\\
 &\{0,1,2,3,4,6,12,13,14,15,16,20\}.
\end{aligned}
\tag{8}
\]

The root endpoints are separated, but the third root-free cycle makes both
siblings nonrooted.  The complete parent profile is

\[
 (11\!-!00/h\text{-avoiding})^6,
 \quad(11\!-!00/h\text{-present})^3,
 \quad(11\!-!10)^3,
\tag{9}
\]

and the child has twelve supplements.  Thus the example refutes (4), not
ChildSupplement.

In the frozen through-order-\(26\) stratum, thirteen short-gap records have
bad bonds at distinct state-\(11\) stars.  There are twenty-five pairs with
literally equal \(P_g\): twenty-four pairs in eight order-\(24\) families
have two nonrooted siblings, and the remaining pair is the positive
complete-family-extreme record of Note 140.  Equality only of the ordered
boundary transition is weaker still: among 125 such pairs, 124 fail.

## 3. Pair-local componentwise recombination is insufficient

For four perfect matchings \(M_1,N_1,M_2,N_2\), let
\(C(M_1,N_1,M_2,N_2)\) be the smallest subset of
\(\mathcal P_{e,g_0}\) containing them and closed under flipping any
connected component of the symmetric difference of two current members.
This is the full matching closure forced by the four endpoints; it does not
assign formal matchings independently.

For each of the twenty-four shared-path double failures above, this closure
has size four or eight:

\[
 \#C=4\quad(16\text{ pairs}),
 \qquad
 \#C=8\quad(8\text{ pairs}).
\tag{10}
\]

In every case,

\[
 \#(C\cap\mathcal R)=4,
 \qquad
 B_{\rm auto}[C\cap\mathcal R]=\varnothing.
\tag{11}
\]

Thus the original four endpoints are the only rooted members of the entire
pair-local recombination closure, and no automatic bond is internal to it.
The repairs lie outside: twelve closures meet four automatic boundary
bonds and twelve meet six.  Consequently neither a shared transition nor
the complete componentwise closure generated by two bad stars proves the
desired selection.

The four rooted targets of the unique extreme order-\(26\) family do not
form an exchange rectangle.  Their symmetric-difference component matrix is

\[
 \begin{pmatrix}
 0&2&1&2\\
 2&0&2&1\\
 1&2&0&2\\
 2&1&2&0
 \end{pmatrix},
\tag{12}
\]

with component-length profiles

\[
 (4,4),(14),(4,12),(4,12),(14),(6,6).
\tag{13}
\]

The two bond cycles are distinct and the four-corner symmetric difference
is nonempty.  Hence an exchange-rectangle identity cannot explain the two
successful siblings in that family.

## 4. One whole all-bad bond component is insufficient

Even the componentwise statement

\[
 K\text{ is a nonempty component of }B(\mathcal R),\quad
 E(K)\subseteq B_{\rm bad}
 \Longrightarrow
 \exists b\in E(K):S_g(b)\text{ is rooted}
\tag{14}
\]

is false.  Use the order-\(26\) graph

~~~text
Y?????????????w?B_?F??FAOACCC?Oo?D_?W@??I_?H@??CG_?G`???
~~~

with

\[
 e=2\!-\!21,\qquad g_0=1\!-\!13,\qquad g_1=3\!-\!14,
\tag{15}
\]

and

\[
 p=7\!-\!22,\qquad q=6\!-\!15,\qquad h=7\!-\!15.
\tag{16}
\]

Its rooted parent fibre has twelve targets and three nonempty bond
components.  One component is a single isolated bad edge.  Its unique
gate-path sibling has three complement cycles of orders \(6,6,18\), so
the component contains no successful sibling.  The other two components
contain ten automatic bonds, and the child has eleven supplements.

Across the 262 frozen short-gap records there are 352 nonempty bond
components.  Exactly six, all at order \(26\), have only bad edges; every
one is a \(K_2\).  Four have a nonrooted sibling, while the two positive
components are precisely the two bad edges in the unique
complete-family-extreme record.  This finite classification does not test
a multi-edge all-bad component.

The same counterexample also refutes a stronger global-closure claim.  It
has only one bad bond \(MN\), so the componentwise closure generated by all
bad endpoints is \(\{M,N\}\).  Since this set is already an isolated
component of \(B(\mathcal R)\), no automatic bond crosses its boundary;
all ten automatic bonds lie in other components.

## 5. Exact remaining complete-family alternative

The actual counterexamples establish the strict tested hierarchy

\[
 \text{one bond}
 <\text{one state-}11\text{ star}
 <\text{shared-path double star and its local closure}
 <\text{one all-bad bond component}
 <\text{complete-family extremality}.
\tag{17}
\]

Every condition before the last admits a real failure of all associated
gate siblings.  The unique frozen complete-family-extreme family remains
positive: its two isolated bad components both have rooted siblings, which
are exactly its two nondirect child supplements.

Within legal-wide, the unresolved implication can be stated without a false
localization.
If every \(S_g(b)\), \(b\in B_{\rm bad}\), is nonrooted, then
ChildSupplement would follow from either

\[
 B_{\rm auto}\ne\varnothing
\tag{18}
\]

or an unrelated new-cell rooted bond in the complete child family.  Thus
the exact remaining alternative is

\[
\boxed{
 \bigl(\forall b\in B_{\rm bad},\ S_g(b)\text{ nonrooted}\bigr)
 \Longrightarrow
 \bigl(B_{\rm auto}\ne\varnothing\bigr)
 \ \lor\
 \bigl(\text{an unrelated child supplement exists}\bigr).}
\tag{19}
\]

Equation (19), with the legal-wide hypothesis, is still unproved. Note 145
disproves it without that hypothesis. The present results show that a proof
inside legal-wide cannot be confined to any of the tested localizations or
to unrestricted common perfect-matching incidence. It must use the
gate-face geometry while coupling distinct bond components, or an equivalent
global mechanism. They do not establish that this is the only conceivable
proof mechanism.

The real counterexamples and finite counts are verified by the
[short-gap complete-family nonlocality bundle](../computations/bundles/short-gap-complete-family-nonlocality/README.md).
