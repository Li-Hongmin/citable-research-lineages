> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A double-delayed endpoint has a forced rainbow Hamilton route

[Note 211](211-endpoint-defects-at-first-surplus-have-marked-hamilton-cycles.md)
classifies a first target delayed by one vacant eligible position.
At the second surplus, a first target may pass two vacant positions
in its own block. The prefix matching then has two nested long
links, and those links provide separate repairs of the target and
free Hamilton paths.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
disjoint cofacial matching site edges \(xy,uv\). Take a compressed
all-square opening with \(\ell,r\ge1\), empty interblock gaps and
\(s=2\), hence \(f=4r+6\). Assume
\[
d_L=1,\qquad b=d_R=0,                          \tag{1}
\]
and that the first escape target \(R_\ell\) is the fifth interior
slot of a block \(B_h\). Both vacant eligible positions then occur
before \(R_\ell\) in \(B_h\), and every earlier block is short.
Write the first five interiors of \(B_h\) as
\[
o_h,h_1,i_1,h_2,R_\ell,                   \tag{2}
\]
with the final free interior \(e_h\) when \(h\le r\).

**Double-delay theorem.** Such a parent has \(h\ge2\) and, for one
index \(t\in\{0,\ldots,h-2\}\), its complete free-slot matching is
\[
M_{\rm free}=\{o_0h_2,e_ti_1,o_{t+1}h_1\}
\cup\{e_j o_{j+1}:0\le j\le r,\ j\ne t\}.
\tag{3}
\]
Here \(B_0,\ldots,B_{h-1}\) have free interiors \(o_j,e_j\);
the notation \(e_j,o_{j+1}\) after \(B_h\) is the ordinary
standard chain, and \(o_{r+1}\) is the first free interior of the
right site block. The parent has a Hamilton cycle containing
\(xy,uv\), so its legal site-expanded child is Hamiltonian.
The same conclusion holds for the reflected configuration in which
\(L_1\) is followed by four free interior slots in its own block.
Original lobes may have arbitrary positive lengths.

**Proof.** There is no escape target before \(R_\ell\). The two
eligible positions before it in \(B_h\) are the two vacancies,
so all preceding blocks are short. The free slots before the target
are
\[
o_0,e_0,o_1,e_1,\ldots,o_{h-1},e_{h-1},
o_h,h_1,i_1,h_2.                              \tag{4}
\]
The initial list through \(e_{h-1}\) is empty when \(h=0\).
Their number is \(2h+4\). No cross-block free chord can straddle
\(R_\ell\) by Note 203. At most one same-block chord can cross:
all later eligible positions are occupied, so its only possible
later free endpoint is \(e_h\), absent when \(h=r+1\).
Matching parity excludes that single chord. Hence (4) is closed
under the complementary matching.

If \(h=0\), the four slots in (4) lie consecutively in \(B_0\).
Their only possible non-cycle opposite-colour pair is \(o_0h_2\),
leaving the adjacent pair \(h_1,i_1\) unmatched. Thus \(h\ge1\).

For \(h\ge1\), all matching chords between different blocks in
(4) lie on the side of \(C\) opposite the designated site face
by Note 193 and are noncrossing. The first slot \(o_0\) cannot
match \(e_j\) with \(j<h\): \(o_0e_0\) is an old-cycle edge,
and for \(j\ge1\) noncrossing would match all intervening
short-block slots internally. The main prefix through the right
endpoint of \(B_j\) would then be matching-closed, with only two
departing old-cycle edges. Nor can \(o_0\) match \(h_1\): its
opposite-side chord would leave \(i_1\) after it, unable to
match any earlier slot without crossing that chord; the only
same-block opposite-colour candidate \(h_2\) is adjacent to
\(i_1\) on \(C\), and no chord crosses \(R_\ell\).
Therefore
\[
o_0h_2\in M.                              \tag{5}
\]
In particular the possible same-block chord \(o_hh_2\) is absent.
All remaining matching chords in (4) join different blocks and
are noncrossing inside (5).

Scan the enclosed slots from \(e_0\) rightward. An even slot
\(e_j\) must match \(o_{j+1}\) or \(i_1\): matching a later
\(o_k\) would enclose complete short blocks. One skipped block
would have its adjacent interiors matched, and two or more would
give a matching-closed two-edge-cut interval, as in Note 196.
The scan must eventually reach an \(e_ti_1\), since otherwise
\(h_1,i_1\) would remain adjacent and unmatched. The choice
\(t=h-1\) would leave the adjacent pair \(o_h,h_1\) inside
\(e_{h-1}i_1\). Thus \(0\le t\le h-2\), proving \(h\ge2\).

Inside \(e_ti_1\), the first odd slot \(o_{t+1}\) must match
\(h_1\). Matching an \(e_j\) with \(t+1\le j<h\) either uses an
old-cycle edge when \(j=t+1\), or closes the complete short-block
interval \(B_{t+1},\ldots,B_j\) under the matching, again giving
a two-edge cut. The other enclosed slots follow the standard
links \(e_j o_{j+1}\). The same holds before \(e_t\), and every
free group after \(R_\ell\) follows Note 211's even-prefix
barriers and Note 196's skipping rule. This proves (3).

The first \(x\)-to-\(v\) path begins
\[
x,o_0,h_2,R_\ell,\delta_\ell,\beta_\ell,
\alpha_\ell,\gamma_\ell,L_\ell,\ldots,L_1,v,
\tag{6}
\]
using \(xo_0,h_2R_\ell\in E(C)\), \(o_0h_2\in M\), and the
tight transitions and square passages of Note 196 thereafter.
The second is Note 196's ordinary \(x\)-to-\(v\) path, with the
one link \(e_t o_{t+1}\) replaced by
\[
e_t,i_1,h_1,o_{t+1}.                       \tag{7}
\]
The outer edges of (7) lie in \(M\) by (3), and \(i_1h_1\in E(C)\).
These paths share only \(x,v\), cover all vertices, and form a
Hamilton cycle through the site edges \(xy,uv\). Reflection proves
the final-target version. Notes 001 and 178 give the legal child
and restore original lobe lengths. \(\square\)

**A 20-vertex realization.** Take \(r=1,\ell=1,h=2,t=0\).
The old 20-cycle is
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,h_1,i_1,h_2,R_1,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                      \tag{8}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,a_1b_1,uv,\alpha\beta,R_1\delta,L_1\gamma\}\\
&\cup\{o_0h_2,e_0i_1,o_1h_1,e_1o_2\}.
\end{split}                                      \tag{9}
\]
Every matching edge joins opposite old-cycle parities.
The four fixed site, face and square chords are disjoint on one
side of \(C\). On the other, the free chords form the nest
\(o_0h_2\supset e_0i_1\supset o_1h_1\supset e_1o_2\),
and the escape chords satisfy \(R_1\delta\supset L_1\gamma\)
after that nest. This is a simple cubic bipartite plane graph
with cofacial sites. Its matching-chord interlacement graph is
connected: \(xy\) interlaces \(o_0h_2,e_0i_1\); \(uv\)
interlaces all four free chords and both escape chords;
\(a_1b_1\) interlaces \(o_1h_1,e_1o_2\); and
\(\alpha\beta\) interlaces both escape chords. Note 217's
interval criterion proves three-connectivity, and its cut
projection makes the 24-vertex site expansion Barnette.

The two paths of the marked parent Hamilton cycle are
\[
\begin{split}
&x,o_0,h_2,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,i_1,h_1,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                      \tag{10}
\]
They share only \(x,v\) and cover all 20 vertices.

The theorem addresses the two vacancies immediately before a
delayed first target in one block, and its reflection. It does
not cover a vacancy in an earlier block, one after the target,
transition defects, gaps, nonsquare residual cycles, or arbitrary
Barnette graphs.
