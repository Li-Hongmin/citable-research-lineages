> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-point one-rank violations reduce to a binary paid-exit deficit

[Note 046](046-actual-brace-rotation-does-not-make-one-rank-relaxations-integral.md)
shows that a two-point rank violation at an actual brace site need not expose
independent primal edges: the offending labels may be absorbed by a restored
cubic star.  This note proves that the graphic part of the two-point repair
is nevertheless automatic.  Every excess unit can be moved from the omitted
shore to its boundary without making another rank row infeasible.  The only
remaining obstruction is an exact binary-cost deficit.

## The one-hole slice

Fix an actual legal site in a simple plane cubic bipartite brace.  Let
\(D_x\) be its \(X\)-partition blocks in the contracted rank multigraph
\(Q\), and let \(W\subsetneq V(Q)\) have two vertices.  Put

\[
 I=E_Q(W).
\]

Suppose that \(x\ge0\) satisfies all block equations and every proper
graphic-rank inequality except possibly that of \(W\), with

\[
 x(I)=1+\delta,\qquad \delta>0.
\tag{1}
\]

For \(A\subseteq Y\setminus\{a\}\), let

\[
 c_A(e)=\mathbf 1_{\{y(e)\in A\}}.
\tag{2}
\]

The cost-qualified problem additionally assumes

\[
 c_Ax\le |A|.
\tag{3}
\]

## Actual two-point block geometry

If \(W\) avoids the contracted root, the simplicity of the uncontracted
dual gives \(|I|\le1\), so (1) is impossible.  Hence a violated two-point
shore contains the root.  Its internal labels lift to edges from the other
rank vertex to the three dual vertices identified at the root, and therefore

\[
 |I|\le3.
\tag{4}
\]

Every actual \(X\)-block is a triangle, a two-edge path, or the unique
root-parallel block.  A triangle or path which contains a label of \(I\)
but is not wholly internal has another label in the boundary
\(\delta_Q(W)\).  A wholly internal block can only be the designated
parallel block, so there is at most one; its block equation contributes at
most one to \(x(I)\).  Consequently the entire excess \(\delta\) in (1) is
carried by internal coordinates whose blocks have boundary exits.

## Boundary-shift lemma

Let \(e\in I\) lie in a block \(B\), and suppose
\(g\in B\cap\delta_Q(W)\).  For

\[
 0\le\theta\le\min\{x_e,\delta\},
\]

define

\[
 x'_e=x_e-\theta,\qquad x'_g=x_g+\theta,
\tag{5}
\]

leaving the other coordinates unchanged.

> **Boundary-shift lemma.**  The segment (5) remains feasible for every
> graphic-rank inequality other than that of \(W\).  It can be continued
> until \(e\) is exhausted or \(x'(I)=1\).

The block equations, total equation, and nonnegativity are preserved.  Let
\(U\ne W\) be a proper shore.  If \(U\supseteq W\), replacing the internal
label \(e\) by the boundary label \(g\) cannot increase \(x(E_Q(U))\).  If
\(U\cap W=\varnothing\), neither label is internal to \(U\).  A nonempty
proper subset of \(W\) is a singleton and contains no retained loop.
Therefore only a shore partially crossing \(W\) can gain weight.

Suppose such a shore first became tight before \(e\) was exhausted and
while \(x'(I)>1\).  The no-partial-crossing identity of
[Note 045](045-one-omitted-small-rank-inequality-can-create-a-fractional-local-block-extreme-point.md)
forbids a tight proper rank set from partially crossing a strictly violated
omitted shore.  Thus no other rank row can stop (5).  Applying the lemma
successively to removable internal coordinates lowers \(x(I)\) to one and
produces a point in the full partition--graphic common-base polytope.  No
integrality of \(x\) is used.

## Exact paid-exit cost

For a removable internal label \(e\), define

\[
 \gamma_e=\min\{c_A(g):g\in B(e)\cap\delta_Q(W)\},
 \qquad
 \kappa_e=\gamma_e-c_A(e)\in\{-1,0,1\}.
\tag{6}
\]

The minimum cost increment of removing exactly the excess \(\delta\) is the
fractional knapsack value

\[
\begin{aligned}
 \rho_A(x,W)=\min\;&\sum_e\theta_e\kappa_e\\
 \text{subject to }&0\le\theta_e\le x_e,
 \qquad \sum_e\theta_e=\delta,
\end{aligned}
\tag{7}
\]

where \(e\) ranges over the internal labels whose blocks have boundary
exits.  The block classification above guarantees enough capacity.
Choosing a cheapest exit in every application of (5) proves

\[
 \boxed{
 \rho_A(x,W)\le |A|-c_Ax
 \Longrightarrow
 \exists y\text{ in the full common-base polytope with }c_Ay\le|A|.}
\tag{8}
\]

Since the costs are binary, a positive increment occurs exactly when the
internal label has its \(Y\)-endpoint outside \(A\), while every boundary
exit in the same \(X\)-block has its \(Y\)-endpoint in \(A\).  Call this
**paid-exit mass**.  Any two-point counterexample to the cost-qualified
statement must therefore satisfy the sharp inequality

\[
 \boxed{\rho_A(x,W)>|A|-c_Ax.}
\tag{9}
\]

All graphic-rank obstructions have disappeared from the first repair; (9)
is the only remaining direct-repair failure.

## Tightness and the remaining rotation problem

At the cube site of Note 046, take

\[
 R=\{23,35,47\},\qquad W=\{1,2\},\qquad A=\{4,6\}.
\]

Then

\[
 \delta=1,\qquad c_A(R)=1,\qquad
 |A|-c_A(R)=1,\qquad \rho_A(R,W)=1.
\tag{10}
\]

Thus (8) is tight even in the smallest brace: the \(W\)-cycle is repaired
at total cost two, but there is no strict defect.

What remains open is whether an actual joint rotation can realize (9).
Perfect-matching extendability can route a \(Y\)-collision to a \(Y\)-hole
in the assignment graph, but it does not ensure that later block changes
remain a tree in \(Q\).  The precise residual statement is:

> **Paid-exit discharge problem.**  Can every two-point paid-exit deficit at
> an actual brace site be discharged by an alternating block route which
> starts with a boundary shift, ends at a \(Y\)-hole of the same
> \(A\)-status, and preserves the graphic-base condition after the omitted
> \(W\)-cycle is broken?

A positive answer, together with (8), proves cost-qualified unrestricted
deletion for \(|W|=2\).  A negative answer must supply a finite alternating
route and tight-shore pattern realizing (9).  No assertion is made here for
\(|W|=3\) or \(4\).
