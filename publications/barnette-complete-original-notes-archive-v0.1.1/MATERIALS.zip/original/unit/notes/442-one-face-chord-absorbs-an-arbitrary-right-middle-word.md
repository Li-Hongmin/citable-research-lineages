> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One face chord absorbs an arbitrary right middle word

[Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) includes a row-IV word with sites \((1,7)\), short leaf \(4\), and depths \((1,2,4,5,6,6,3)\). A one-face-chord spine path closes it. The path works for an arbitrary middle ordinary word in place of its short-leaf subtree.

Let \(V\) be any nonempty consecutive ordinary word, with first and last vertices \(V_\ell,V_r\), and let \(\overrightarrow V\) be its complete forward old-cycle path. Put
\[
C=F(U_3,V),\qquad D=F(C,U_7),\qquad
E=F(U_2,D),\qquad W=F(U_1,E),
\tag{1}
\]
where the four displayed \(F\)-branches and \(U_1,U_2,U_3,U_7\) are full. Suppose the matching contains the face edge \(y_2x_3\), and the two site edges have inner endpoints \(y_1,x_7\).

**One-chord spine lemma.** The old-cycle edges, ordinary chords and \(y_2x_3\) contain the spanning \(y_1\)--\(x_7\) path
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,\quad
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{X_3^{-1}}R_3,\quad
V_\ell\xrightarrow{\overrightarrow V}V_r,\quad
\rho_2^C\xrightarrow{R_C}C_\ell,\quad
\lambda_2^D\xrightarrow{P_D}\rho_2^D,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{2}
\]
The leaf and bracket paths are from [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). The jump \(y_2x_3\) is the assumed face edge. All other joins,
\[
L_1\lambda_2^W,\quad \rho_2^W\rho_0^E,\quad
\lambda_2^EL_2,\quad R_3V_\ell,\quad
V_r\rho_2^C,\quad C_\ell\lambda_2^D,\quad
\rho_2^DR_7,
\tag{3}
\]
are consecutive old-cycle edges. Each piece in (2) spans a disjoint leaf, wrapper or the whole word \(V\), so it visits every one of \(|V|+48\) vertices exactly once. This proves the lemma without using any matching chord internal to \(V\). \(\square\)

**Row-IV application.** Take
\[
B=F(U_5,U_6),\qquad S_4=(x_4y_4),\qquad V=F(S_4,B).
\tag{4}
\]
Then \(|V|=4+18+6=28\), and (1) has short leaf \(4\) and depths \((1,2,4,5,6,6,3)\). Row IV supplies \(y_2x_3\), so (2) spans all \(76\) vertices of this word. The fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), closes it through both site edges; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, lifts that Hamilton cycle to every legal expanded child. Reflection gives the row-V result.

Combining Notes 437--442 leaves seven structurally necessary short-leaf words in row IV/V. Row VI, other kernels and Barnette's conjecture remain open.
