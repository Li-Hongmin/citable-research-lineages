> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Arbitrary one-sided short flanks preserve forward four-double Hamilton routes

[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
settles the consecutive \(J_3,J_1,J_3,J_1\) four-double group
without short blocks. An arbitrary one-sided short flank has
the same spanning-route conclusion. Nonstandard outer chords
introduce one movable cut position, but their routes admit
one common path splice.

Work in the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group, with even left and odd
right endports \(L,R\), have block order
\[
S_1,\ldots,S_a,D_1,D_2,D_3,D_4,\qquad a\ge0,               \tag{1}
\]
where
\[
S_u=(c_u,r_u,s_u,d_u),\qquad
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t).                    \tag{2}
\]
The common-face internal matching chords of the four
double blocks are
\[
                 i_1e_1,\quad o_2k_2,\quad
                 i_3e_3,\quad o_4k_4,                   \tag{3}
\]
and every block also has its common-face closing chord.
Write \(F_u=(r_u,c_u,d_u,s_u)\) for a path through \(S_u\).

**One-sided-flank theorem.** Every complementary matching
that occurs in a Barnette parent under (1)--(3) gives a
vertex-spanning \(L\)--\(R\) path through the group, for
every \(a\ge0\). Old-cycle reflection gives the same
conclusion for any number of short blocks only after \(D_4\).
If all vacancies outside this group occupy distinct internal
blocks, the parent has a Hamilton cycle through both site
edges and its legal child is Hamiltonian.

For \(a\ge1\), an actual matching either contains the
standard boundary edge \(Lr_1\), or it has one of the
nonstandard words (5)--(8) below. There is one \(Lj_2\)
word, two \(Lj_4\) outer wirings, one \(Lj_4\) local-square
word, and \(a-1\) \(Lj_4\) delayed-return words.
This is an exhaustive conditional classification;
no assertion that every formal word is realizable is needed.

**Matching exhaustion.** By [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
(3) excludes every other same-block free chord;
by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
the remaining free chords form a noncrossing matching on
the opposite page. The free slots occur in the order
\[
L,(r_u,s_u)_{u=1}^{a},
o_1,h_1,k_1,j_1,h_2,i_2,j_2,e_2,
o_3,h_3,k_3,j_3,h_4,i_4,j_4,e_4,R.                      \tag{4}
\]
Every opposite-page chord encloses an even number of
free slots. A nonempty proper interval of complete
blocks closed under the complementary matching would
have only two old-cycle edges leaving it, contrary to
three-connectivity.

For \(a=0\), use Note 347. Suppose \(a\ge1\).
The endport \(L\) cannot meet \(r_t\) with \(t>1\),
\(o_1\), \(o_3\), or \(R\): the corresponding chords
would close respectively the complete-block intervals
\(S_1,\ldots,S_{t-1}\),
\(S_1,\ldots,S_a\),
\(S_1,\ldots,S_a,D_1,D_2\), or the whole group.
Every other odd candidate except \(r_1,j_2,j_4\)
encloses an odd number of free slots.
Thus \(Lr_1,Lj_2,Lj_4\) are the only possibilities.

If \(Lr_1\), reserve the segment
\((L,r_1,c_1,d_1,s_1)\) and regard \(s_1\)
as the new even left endport. The remaining
matching has the same ordered free slots as (4)
with \(a\) decreased by one. This is a
path construction, not a graph contraction:
every cut used below is a proper interval of
original complete blocks and stays forbidden.
The local-square route uses only its explicit
path signature, and Note 336's path peeling
applies to such virtual endports.
Induction reaches \(a=0\). Join the reserved
segments at their common endports to lift
Note 347's spanning route.

Suppose \(Lj_2\). The first inner odd slot \(r_1\)
must meet \(h_1\): its edge to \(s_1\) is old;
one to a later \(s_t\) closes \(S_1,\ldots,S_t\);
the other inner even candidates enclose odd
numbers of free slots. Inside \(r_1h_1\),
the cut rule forces the standard links
\(s_ur_{u+1}\) for \(1\le u<a\) and
\(s_ao_1\). The remaining inner slots force
\(k_1i_2,j_1h_2\).
On the right, the no-flank \(J_3,J_1\)
argument of [Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md)
forces \(e_2o_3,h_3j_4,k_3i_4,j_3h_4,e_4R\).
Thus the complete free-chord word is
\[
\begin{split}
M_J=\{Lj_2,r_1h_1,s_ao_1,k_1i_2,j_1h_2,
e_2o_3,h_3j_4,k_3i_4,j_3h_4,e_4R\}\\
\hspace{20mm}\cup
\{s_ur_{u+1}:1\le u<a\}.
\end{split}                                                \tag{5}
\]

Suppose \(Lj_4\). The exterior pair is \(e_4R\).
Inside \(Lj_4\), the first odd slot \(r_1\)
can meet only \(h_1,e_2,h_3\):
a later \(s_t\) closes \(S_1,\ldots,S_t\),
and the other even candidates violate parity.
The choice \(r_1e_2\) closes the proper
complete-block interval \(S_1,\ldots,S_a,D_1,D_2\).

If \(r_1h_1\), the short flank is forced into
the links \(s_ur_{u+1}\ (1\le u<a)\)
and \(s_ao_1\). The unmatched core slots
from \(k_1\) to \(i_4\) are exactly the
interior slots of Note 347's \(h_1j_4\)
branch. Its same noncrossing and cut
argument leaves the two outer wirings
\[
\begin{split}
M_A={}&\{Lj_4,r_1h_1,s_ao_1,k_1i_2,j_1h_2,
        j_2h_3,e_2o_3,k_3i_4,j_3h_4,e_4R\}
        \cup E_a,\\
M_B={}&\{Lj_4,r_1h_1,s_ao_1,k_1i_4,j_1h_2,
        i_2k_3,j_2h_3,e_2o_3,j_3h_4,e_4R\}
        \cup E_a,
\end{split}                                                \tag{6}
\]
where \(E_a=\{s_ur_{u+1}:1\le u<a\}\).

Suppose \(r_1h_3\). After each initial
standard link \(s_ur_{u+1}\), the first
unmatched even slot \(s_t\) can meet only
\(r_{t+1},o_1,j_2,o_3\). A later
\(r_v\) would close the intervening
short blocks. For \(t<a\), an edge
\(s_to_1\) closes \(S_{t+1},\ldots,S_a\).
For every \(t\), an edge \(s_to_3\)
closes \(S_{t+1},\ldots,S_a,D_1,D_2\).
If \(t=a\), an edge \(s_aj_2\) leaves
\(o_1\) without a mate. Therefore either
all links are standard and \(s_ao_1\),
or the first deviation is \(s_tj_2\)
with \(1\le t<a\).

In the first case, the remaining core
forces \(h_1j_2,k_1i_2,j_1h_2,e_2o_3\)
and the right tail forces \(k_3i_4,j_3h_4\).
This is
\[
M_{\mathrm{loc}}=
\{Lj_4,r_1h_3,s_ao_1,h_1j_2,k_1i_2,j_1h_2,
e_2o_3,k_3i_4,j_3h_4,e_4R\}\cup E_a.                   \tag{7}
\]
In the second case, the first inner odd slot
\(r_{t+1}\) of \(s_tj_2\) can meet only
\(h_1\): its adjacent \(s_{t+1}\) is
an old edge, a later \(s_v\) would
close \(S_{t+1},\ldots,S_v\), and
the other even candidates have odd
interior slot counts. Inside \(r_{t+1}h_1\),
the links \(s_ur_{u+1}\ (t+1\le u<a)\)
and \(s_ao_1\) are forced. The remaining
core and right tail force
\(k_1i_2,j_1h_2,e_2o_3,k_3i_4,j_3h_4\).
For \(1\le t<a\), the word is
\[
\begin{split}
M_t={}&\{Lj_4,r_1h_3,s_tj_2,r_{t+1}h_1,
s_ao_1,k_1i_2,j_1h_2,e_2o_3,
k_3i_4,j_3h_4,e_4R\}\\
&\cup\{s_ur_{u+1}:1\le u<a,\ u\ne t\}.
\end{split}                                                \tag{8}
\]
This exhausts the nonstandard branches. \(\square\)

**Spanning routes.** In every formula below,
\(F_u=(r_u,c_u,d_u,s_u)\) expands to its
four distinct short-block vertices.
For \(M_J,M_{\mathrm{loc}},M_A,M_B\),
respectively, take
\[
\begin{split}
P_J={}&(L,j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,
F_1,\ldots,F_a,o_1,a_1,b_1,a_2,b_2,e_2,o_3,a_3,b_3,
e_3,i_3,h_3,j_4,k_4,i_4,k_3,j_3,h_4,o_4,a_4,b_4,e_4,R),\\
P_{\mathrm{loc}}={}&
(L,j_4,k_4,i_4,k_3,i_3,h_3,F_1,\ldots,F_a,
o_1,a_1,b_1,e_1,i_1,h_1,j_2,k_2,i_2,k_1,j_1,h_2,o_2,
a_2,b_2,e_2,o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4,R),\\
P_A={}&
(L,j_4,k_4,i_4,k_3,i_3,h_3,j_2,k_2,i_2,k_1,i_1,h_1,
F_1,\ldots,F_a,o_1,a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,
e_2,o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4,R),\\
P_B={}&
(L,j_4,k_4,i_4,k_1,i_1,h_1,F_1,\ldots,F_a,
o_1,a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,e_2,o_3,
a_3,b_3,e_3,i_3,h_3,j_2,k_2,i_2,k_3,j_3,
h_4,o_4,a_4,b_4,e_4,R).
\end{split}                                                \tag{9}
\]
For \(M_t\), \(1\le t<a\), use
\[
\begin{split}
P_t={}&(L,j_4,k_4,i_4,k_3,i_3,h_3,
F_1,\ldots,F_t,j_2,k_2,i_2,k_1,i_1,h_1,
F_{t+1},\ldots,F_a,o_1,a_1,b_1,e_1,j_1,
h_2,o_2,a_2,b_2,e_2,o_3,a_3,b_3,e_3,j_3,
h_4,o_4,a_4,b_4,e_4,R).
\end{split}                                                \tag{10}
\]
Every row lists each of the \(32+4a\)
block vertices exactly once. Its
non-old joins are precisely its word's
matching chords, the block-closing
chords, and the four internal chords (3).
For \(P_A,P_B,P_t\), the crucial splice
replaces the edge \(k_1j_1\) of the
remaining route by a detour through
\(i_1,h_1\), the required short-block
chain and \(o_1,a_1,b_1,e_1\), returning
along the old edge \(e_1j_1\).
This explains the same route mechanism
for every flank length and cut position.

Each group route replaces only the group's
standard segment in Note 324's two-path
construction. Its other groups compose
under the stated outside-vacancy hypothesis.
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives a Hamilton cycle in the legal
child. Old-cycle reflection exchanges
left and right flanks and preserves the
even \(J_3,J_1,J_3,J_1\) word.
\(\square\)

The theorem covers arbitrary short blocks
on one outer side and no central corridor
in the specified opening. Two-sided outer
flanks, a positive central corridor,
other internal chord words and other
opening types remain outside its scope;
the general Barnette conjecture is not
settled. This is a project-internal
analytic proof without an external
priority claim.
