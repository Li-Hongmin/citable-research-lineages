> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed third operation has a complete joint-row interface GO

**状态：接口 GO 经异源核验 REJECT（round 8），保留原子表与边集分解原理，接口命题回到 UNDETERMINED。** 详见
[`advisor/gpt6pro-2026-09-12-round8.md`](../advisor/gpt6pro-2026-09-12-round8.md)。
本文件保留为 pulse 1 的历史记录；其中完整接口 GO 的主张及相应实现认证已被撤回。

For the fixed role operation

\[
(u,v,x,y;r_0,r_1)\longmapsto (u,a,r_0,r_1),
\]

which deletes \(uv,xy\), creates the standard eight-edge \(C_4\) patch, and
retains \(r_0r_1\), the candidate summary \(\sigma_0=(\eta,R)\) of GPT-6 Pro
round 7 is a congruence on the full real legal domain \(D_{o^*}\).

Here \(\eta\) is the frozen finite fourteen-slot equality, incidence,
target-location, ledger and face-role record.  \(R\) is the set of all jointly
realized rows \((d,\pi,z,\beta_e,\beta_f)\) of spanning exterior generators
after deleting \(uv,xy,r_0r_1\): it records all active-role degrees, their full
connectivity partition, the number of interface-free components saturated at
two, and simultaneous target-edge use.  The precise definition, including
the output rename/forget table, is in `scratch/r3_pulse1/DEFS.md`.

The complete local alphabet consists of the eight born edges and the retained
edge.  Hence it has exactly \(2^9=512\) selections.  Restricting any child
generator to the unchanged old exterior and these nine local edges is unique;
conversely, a realized exterior row and a degree-compatible local selection
have a unique union.  Component partitions join at the named roles, closed
components add with saturation, and the two target bits OR only within that
same witness.  This gives a restriction--gluing bijection, not merely a lift
of selected witnesses.  Cutting the successor edges \(ua,r_0r_1\) gives the
complete transition \(T_0\); retaining them and testing degree two, exactly
one component, and bits \((1,0)\) gives the complete semantic output \(j_0\).
Therefore, for all real \(X,Y\in D_{o^*}\),

\[
\sigma_0(X)=\sigma_0(Y)\Rightarrow
J^*(X)=J^*(Y),\qquad
\sigma_0(\Phi_{o^*}X)=\sigma_0(\Phi_{o^*}Y).
\]

Acceptance is exact: a finite spanning 2-regular subgraph with one connected
component is a Hamilton cycle, and the joint bits \((1,0)\) say that this same
cycle contains \(e\) and avoids \(f\).  Arbitrarily long face arcs do not enter
the edge-set decomposition; their finite marked incidence is used only to
certify that the input lies in \(D_{o^*}\).  Thus the argument covers every
allowed real history, including histories revisiting older vertices.

The 512-row tables and generators are `scratch/r3_pulse1/T0.tsv`,
`scratch/r3_pulse1/j0.tsv`, `generate_tables.py`, and `row_engine.py`.
`validate_real_contexts.py` independently checks complete successor supports
and joint Hamilton truth in two genuine small legal-history contexts.  These
computations check the implementation; universality rests on the bijection.

This is only **\(o^*\)'s interface GO**.  It proves neither (T), acceptance of
every state, closure for any other allowed operation, nor the induction and
coverage chain for all of \(\mathcal C_{4A}\).  It does not touch R1 or Note
167 and gives no result about the general Barnette conjecture.
