> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Peelable multi-vacancy corridors have three spanning states

[Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md)
settles a corridor with one vacancy by recognizing the port-owned case
as a cube expansion. The same fold can remove several consecutive
port-owned vacancies without inspecting the matching elsewhere.

Let \(G\) be a Barnette parent with the compressed, gapless,
tight-target all-square opening of Notes 300--315. In a free group
\(D=B_a,\ldots,B_b\) with retained ordinary end links, exactly two
internal ordinary links \(P_s,P_t\), \(a\le s<t<b\), are missing.
All blocks of the corridor \(B_{s+1},\ldots,B_t\) are short or
vacant, with at most one vacancy in each block. List its vacancy
atoms in boundary order as \(V_1<\cdots<V_m\). Mark each \(V_j\)
by \(L\) if it belongs to the rainbow component of \(P_s\), by
\(R\) if it belongs to that of \(P_t\), and by \(F\) otherwise.
Note 278 makes \(L\) and \(R\) mutually exclusive.

**At-most-one-port-free corridor theorem.** Suppose at most one
corridor vacancy has label \(F\). Then its ownership word must be
\[
                 L^p F^\varepsilon R^q,\qquad
                 p,q\ge0,\quad \varepsilon\in\{0,1\}.       \tag{1}
\]
All other group vacancies and matching chords may be arbitrary
subject to the opening. Then \(D\) has vertex-spanning \(S,K,X\)
states. If the other free groups have their ordinary spanning
routes, the parent has a Hamilton cycle through both site edges
and its legal site-expanded child is Hamiltonian. In particular,
the number of corridor vacancies in either port component has
no fixed bound.

**Proof of the forced order.** An \(R\) cannot precede an \(L\):
their port components would have atoms in the interlacing order
\(P_s<R<L<P_t\), contrary to noncrossing. If the sole \(F\)
preceded an \(L\), its vacancy-only component would have another
atom outside the corridor. An atom before \(P_s\) would give
\(F_{\rm out}<P_s<F<L\), and an atom after \(P_t\) would give
\(P_s<F<L<F_{\rm out}\); either order interlaces that component
with the left port component. Thus \(F\) follows every \(L\).
Likewise, if an \(R\) preceded \(F\), an atom of the latter's
component before \(P_s\) would give
\(F_{\rm out}<R<F<P_t\), while one after \(P_t\)
would give \(R<F<P_t<F_{\rm out}\). Each interlaces
the right port component. Hence \(F\) precedes
every \(R\). This proves (1).

**Proof of the routes.** We induct on \(m\). For \(m=0\), every corridor block
is short and Note 312 gives the states. For \(m=1\), Note 315
does so regardless of the ownership letter.

Suppose \(p>0\), and take the first corridor vacancy \(V_1\).
There must be a nonempty short run between \(P_s\) and \(V_1\):
otherwise \(V_1=B_{s+1}\), and membership in the \(P_s\)
component would force the matching edge \(o_{s+1}H_{s+1}\),
which is an old-cycle edge. Every ordinary link within this
short run and from its final block to \(V_1\) is retained.
Compress the run to one square by Note 312's exact four-pole
replacement. Its first ordinary slot is still the later end
of \(P_s\), and its last ordinary slot retains its link to
\(o_{V_1}\). Since \(P_s,V_1\) are consecutive atoms, their
common rainbow component forces the other edge of the
ten-vertex cube patch in Note 315. Fold that patch to one
short block.

The fold deletes only \(V_1\) from the atom diagram. Its
surviving right vacancy slot \(I_{V_1}\) becomes the later
ordinary end of the new left port. If that slot is matched
to the earlier end \(e_s\), the left ordinary link has become
retained, leaving only \(P_t\) missing; Note 288 settles
the whole group. Otherwise the left port remains missing.
Its component is exactly the old \(P_s\) component with
\(V_1\) removed: the matching edge incident with
\(I_{V_1}\) now leaves the new port, while every other
rainbow edge and every other atom is unchanged. Thus the
remaining corridor word is \(L^{p-1}F^\varepsilon R^q\).
The new graph is Barnette with the same kind of opening by
Note 315. Apply the induction hypothesis, lift its three
states through the exact cube signature, and reverse the
short-run compression by Note 312.

If \(p=0\) and \(q>0\), reflect this argument at the last
corridor vacancy \(V_m\) and the short run between it and
\(P_t\). The fold either restores \(P_t\), leaving one
missing link, or changes the ownership word to
\(F^\varepsilon R^{q-1}\). When \(p=q=0\), (1) has at most
one vacancy and the base cases apply. This proves the
three states. Notes 273, 001, and 182 give the marked
parent and legal child conclusions. \(\square\)

**Unbounded realized family.** In Note 291's 46-vertex Barnette
parent, \(P_3,P_4\) are missing and share the short block
\(B_4\); its left port component is
\(V_1<P_3<V_7\), with matching edge \(o_4H_7\).
Replace \(B_4\) by the inverse of Note 315's cube fold:
one short block followed by one vacant block. Do this \(p\)
times, always expanding the first short block after \(P_3\).
In the two-page embedding, the new face chords occupy the
old common-face strip. The new opposite-side edges \(Oh,Eo\)
are nested and have no surviving endpoint between them;
the old two matching attachments move, without changing
their outside endpoints, to the new vacancy's \(i,e\) slots.
The site edges and all other blocks are untouched. The
operation is the known cube expansion of
Holton--Manvel--McKay (1985, Theorem 4). Its Barnette
preservation is stated by Gorsky--Steiner--Wiederrecht
(2023, Section 5), and the facial placement here follows
from the displayed two-page local drawing.

After each expansion, the new vacancy lies immediately
after \(P_3\) in its component, and every previously
inserted corridor vacancy follows it in that same component.
The right missing link moves one block to the right. Hence
the corridor word is \(L^p\), the parent has \(46+6p\)
vertices, and its legal child has \(50+6p\), for every
\(p\ge0\). The theorem gives all three states and marked
Hamilton cycles. Reflection gives an unbounded right-owned
family as well.

The at-most-one-port-free condition is sufficient. Corridors with
multiple port-free vacancies remain outside this proof, as do openings
with target-bearing or repeated same-block vacancies,
positive gaps, defective target order, and nonsquare
residual cycles. The general Barnette conjecture remains
unresolved.
