> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A rooted final cap shields arbitrarily many prefix ports

[Note 306](306-a-final-gap-cap-is-exactly-a-rooted-crossed-linkage.md)
identifies the rooted two-path interface of a final-gap cap.
[Note 307](307-a-backward-port-before-the-last-vacancy-has-a-rooted-cap.md)
resolves a backward-facing port between the last two vacancies
of an inner component. There is a complementary simplification:
when the inner component's last two fixed chords are available,
everything before its penultimate vacancy can be traversed
on the old Hamilton cycle. Its complementary matching need not
have any prescribed port pattern.

Work in the compressed, gapless, tight-target all-square opening
of Notes 275--307. Let \(B_v,B_h,B_t,B_u\) be distinct vacant
blocks with
\[
                 v<h<t<u.                              \tag{1}
\]
In an actual Barnette parent, suppose the complementary
matching contains
\[
 I_vH_u,\qquad e_{u-1}o_u,\qquad
 e_vI_t,\qquad I_hH_t,                                \tag{2}
\]
and retains every ordinary link
\[
                P_k=e_ko_{k+1}\quad(h\le k\le u-2).
                                                               \tag{3}
\]
There is no restriction on the complementary matching
in \(B_{v+1},\ldots,B_h\), beyond (2), the Barnette
conditions, and the specified retained links. In particular,
any number of ordinary links \(P_v,\ldots,P_{h-1}\) may be
missing. Put \(F=B_{h+1},\ldots,B_{t-1}\) and
\(J=B_{t+1},\ldots,B_{u-1}\), either of which may be empty.

**Prefix-shielded cap theorem.** Under (1)--(3), there is
a path
\[
 D:e_{u-1}\leadsto b_{u-1},\qquad
 V(D)=\{e_v,b_v\}\cup
       \bigcup_{k=v+1}^{u-1}V(B_k).                    \tag{4}
\]
Consequently the final-gap cap interface of Note 305 holds
without any bound on the number of missing links before
\(B_h\). Whenever Note 305's other hypotheses hold, its
spanning \(S,K,X\) states, marked Hamilton parent cycle,
and legal Hamiltonian site-expanded child follow.

**Proof.** First build \(U:b_v\leadsto b_t\), spanning
\(B_{v+1},\ldots,B_t\) except \(I_t,e_t\).
If \(F\ne\varnothing\), take its elementary upper and
lower crossed rails and set
\[
\begin{split}
 U:\quad b_v&\xrightarrow{C\ {\rm forward}}I_h,H_t,o_t,
 e_{t-1}
 \xrightarrow{X_{\rm bottom}(F)^{-1}}o_{h+1},
 e_h,b_h,a_{h+1}\\
 &\xrightarrow{X_{\rm top}(F)}b_{t-1},a_t,b_t .
\end{split}                                                   \tag{5}
\]
The forward \(C\)-arc visits every vertex of
\(B_{v+1},\ldots,B_{h-1}\), and exactly
\(a_h,o_h,H_h,I_h\) in \(B_h\). The edge \(I_hH_t\)
is fixed by (2). The joins \(o_te_{t-1}\) and
\(o_{h+1}e_h\) are the retained links \(P_{t-1}\)
and \(P_h\), respectively, by (3). The two rails of \(F\)
partition all its vertices. The remaining vertices
\(e_h,b_h\) of \(B_h\) occur after the lower rail;
\(H_t,o_t,a_t,b_t\) occur at the right end. Thus (5)
is simple and has the stated inventory.

If \(F=\varnothing\), then \(t=h+1\), and instead take
\[
 U:\quad b_v\xrightarrow{C\ {\rm forward}}I_h,
 H_t,o_t,e_h,b_h,a_t,b_t.                            \tag{6}
\]
Here \(o_te_h=P_h\) is retained. The same inventory
check applies.

In either case put
\[
 A:\quad e_t,I_t,e_v,b_v\xrightarrow{U}b_t.          \tag{7}
\]
Its new edges are the old-cycle \(e_tI_t,e_vb_v\)
and the fixed matching edge \(I_te_v\). It spans
\(\{e_v,b_v\}\) and every block through \(B_t\).
If \(J=\varnothing\), let \(D=A\). Otherwise take
\[
 D:\quad e_{u-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}o_{t+1},
 e_t\xrightarrow{A}b_t,a_{t+1}
 \xrightarrow{X_{\rm top}(J)}b_{u-1}.                \tag{8}
\]
The joins use retained \(P_t=e_to_{t+1}\) and
the old-cycle edge \(b_ta_{t+1}\). The two rails
partition \(J\) and are disjoint from \(A\), proving
(4). None of (5)--(8) uses a matching edge in the
prefix before \(B_h\). \(\square\)

**Unbounded planar Barnette realization.** For each
integer \(d\ge1\), use Note 281(8)'s old cycle with
\(\ell=1\), and put
\[
 v=3,\quad h=3d+5,\quad t=h+1,\quad
 u=t+1,\quad z=u+1=r=3d+8,\quad
 s_i=4+3i\quad(0\le i<d).                          \tag{9}
\]
Make exactly
\[
 B_1,B_3,B_h,B_t,B_u,B_z,\quad
 B_{s_i+2}\ (0\le i<d)                              \tag{10}
\]
vacant; all other internal blocks are short.
Retain every ordinary link except \(P_1,P_3\),
and \(P_{s_i}\) for \(0\le i<d\). Besides the
unchanged site, face, escape, and residual-square
matching edges of Note 281, take
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\{V_1,V_z\},\\
e_1I_u,\ o_2H_3,\ I_3H_u;&\{P_1,V_3,V_u\},\\
e_3I_t,\ o_4H_h,\ I_hH_t;&\{P_3,V_h,V_t\},\\
e_{s_i}I_{s_i+2},\ o_{s_i+1}H_{s_i+2}
  \quad(0\le i<d);&\{P_{s_i},V_{s_i+2}\}.
\end{array}                                                   \tag{11}
\]
The \(d+6\) vacant blocks contribute \(2d+12\)
vacancy slots, and the \(d+2\) missing links contribute
\(2d+4\) ordinary slots. The \(2d+8\) displayed
edges pair these \(4d+16\) slots exactly once and
join opposite old-cycle colours.

The two outer vacancy chords are nested as in Note 281.
The chord \(e_1I_u\) encloses the other port
chords in (11); \(e_3I_t\) encloses the disjoint
regions of \(o_4H_h\) and \(I_hH_t\).
Each inner pair lies inside \(o_4H_h\), with
\(e_{s_i}I_{s_i+2}\) enclosing
\(o_{s_i+1}H_{s_i+2}\). Distinct inner pairs
have disjoint intervals. Retained ordinary links
are nested or disjoint from these chords, giving
a plane cubic bipartite drawing with cofacial site
edges.

For \(F_k=a_kb_k\), every retained \(P_k\)
interlaces \(F_k,F_{k+1}\). At each missing
\(P_{s_i}\), its two replacement edges in (11)
give the interlacement path
\[
             F_{s_i}-F_{s_i+2}-F_{s_i+1}.          \tag{12}
\]
At \(P_3\), the path is
\(F_3-F_t-F_h-F_4\), using \(e_3I_t\),
\(I_hH_t\), and \(o_4H_h\). At \(P_1\), it is
\(F_1-F_u-F_3-F_2\), using \(e_1I_u\),
\(I_3H_u\), and \(o_2H_3\). Thus all face chords
belong to one interlacement component. Every
remaining special chord interlaces its endpoint
face chord; Note 281's end links attach the site
and residual-square closing chain. The entire
interlacement graph is connected. Notes 217 and
182 give three-vertex connectivity of the parent;
Note 182 gives a legal site expansion, and Note
001 supplies the Hamilton lift.

The outer component \(\{P_1,V_3,V_u\}\) has
Note 305's two anchors \(e_1I_u,I_3H_u\).
Its last gap \(B_4,\ldots,B_{u-1}\) satisfies
(1)--(3), with the \(d\) additional missing links
all before \(B_h\). The first gap \(B_2\) is
traversed on the old cycle. Hence Note 305 gives
a parent Hamilton cycle through both site edges and
a Hamilton cycle in the legal child.
There are \(r=3d+8\) internal blocks and
\(d+6\) vacancies, so their orders are
\[
 12+4r+2(d+6)=56+14d,\qquad 60+14d.               \tag{13}
\]
The family begins at 70 and 74 vertices.

**Two-\(X\)-interface extension.** The same cap conclusion
holds if (3) is replaced by the following path conditions.
When \(F\ne\varnothing\), retain \(P_h,P_{t-1}\)
and assume \(F\) has two disjoint spanning paths with
endpoint pairs \((a_{h+1},b_{t-1})\) and
\((o_{h+1},e_{t-1})\). When \(F=\varnothing\), retain
\(P_h\). When \(J\ne\varnothing\), retain \(P_t\)
and assume \(J\) has two disjoint spanning paths with
endpoint pairs \((a_{t+1},b_{u-1})\) and
\((o_{t+1},e_{u-1})\). The fixed \(P_{u-1}\) is
already in (2). Substitute these paths for the two
elementary crossed rails in (5) and (8); their endpoint
and disjointness checks are unchanged. Thus internal
missing links of \(F\) or \(J\) are permitted whenever
the corresponding \(X\) state exists. In particular,
Note 288 supplies it when that interval satisfies
its free-group hypotheses and has at most one internal
missing link.

There is a direct sufficient condition for the two
\(X\) states in this setting. Suppose the boundary
links just specified are retained, and each nonempty
interval \(F,J\) has at most one missing ordinary link
strictly inside it. Then both intervals satisfy the
boundary-locality hypothesis of Note 288. Indeed,
every free slot of \(F\) is between the endpoints of
the fixed chord \(I_hH_t\); a matching edge from an
interior slot to the exterior would cross that chord.
The only free slots at its two boundary blocks that
could serve as mates are \(e_h,o_t\), already used by
\(P_h,P_{t-1}\). Likewise a free slot of \(J\) cannot
match an earlier slot before \(I_t\) without crossing
\(e_vI_t\) or \(I_vH_u\): there is no free slot
between the consecutive vertices \(I_v,e_v\).
A mate after \(H_u\) would cross \(I_vH_u\).
The boundary slots \(e_t,o_u\) are
already used by \(P_t,P_{u-1}\). Thus all
nonboundary matching slots of either interval are
matched internally. Note 288's boundary-local
\(X\) theorem applies. In particular, the number
of missing links before \(B_h\) is still unbounded
when either later interval has its allowed defect.

This theorem leaves matching freedom in the prefix
and permits further defects where the two \(X\)
interfaces are available.
It does not decide the general rooted cap problem
or Barnette's conjecture.
