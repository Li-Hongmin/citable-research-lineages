> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's short leaf has thirteen necessary depth words

[Note 436](436-the-fourth-matching-three-odd-leaf-short-branch-has-a-marked-cycle.md) shows that a hypothetical non-Hamiltonian row-IV child in the two-eligible, chorded single-hexagon \(f=7,c=31\) kernel of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) must have a short leaf. This note classifies the remaining ordered ordinary trees without assuming their face matchings have a legal Barnette completion. Reflection gives the row-V classification.

Let \(d_i\) be the depth of leaf \(i\) in the seven-leaf full binary tree, and let \(r\) be the unique short leaf. Write \(O,E\) for odd and even depth. By [Notes 425](425-short-wrapper-parity-and-terminal-spine-paths.md) and [433--434](434-the-fourth-face-matching-six-odd-leaf-word-has-a-marked-cycle.md), \(r\) is odd-depth, the two site leaves are the other odd-depth leaves, and all remaining leaves are even-depth. By [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), a non-Hamiltonian legal row-IV child must have an ineligible sibling pair, and its boundary can only be \(b\mid c\) or \(d\mid e\). A sibling pair consisting of both sites is Hamiltonian by [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md). A sibling pair containing the short leaf must contain a site: its full sibling has the opposite eligibility at the same depth.

**Thirteen-word necessary theorem.** The complete necessary list of ordered depth vectors and short leaves is

| Sites | Short leaf \(r\) | \((d_1,d_2,d_3,d_4,d_5,d_6,d_7)\) |
| --- | ---: | --- |
| \((1,2)\) | 3 | \((1,3,5,6,6,4,2)\) |
| \((1,2)\) | 3 | \((1,3,3,4,4,4,4)\) |
| \((1,2)\) | 3 | \((3,5,5,4,2,2,2)\) |
| \((1,2)\) | 6 | \((1,3,4,6,6,5,2)\) |
| \((1,7)\) | 2 | \((1,3,4,4,4,4,3)\) |
| \((1,7)\) | 2 | \((3,3,2,2,4,4,3)\) |
| \((1,7)\) | 2 | \((3,3,4,4,4,4,1)\) |
| \((1,7)\) | 2 | \((3,5,6,6,4,2,1)\) |
| \((1,7)\) | 3 | \((1,2,3,4,6,6,5)\) |
| \((1,7)\) | 4 | \((1,2,4,5,6,6,3)\) |
| \((1,7)\) | 5 | \((1,2,6,6,5,4,3)\) |
| \((1,7)\) | 5 | \((3,4,6,6,5,2,1)\) |
| \((1,7)\) | 6 | \((1,2,4,4,4,5,5)\) |

Each ordered depth vector uniquely determines its full binary tree. The table is necessary only; it neither asserts thirteen distinct legal Barnette graphs nor asserts that any listed child is non-Hamiltonian.

**Proof.** First suppose the sites are \(1,2\). The five ineligible leaves are \(a,\ldots,e=3,\ldots,7\), so the only permitted ineligible cherries are \((4,5)\) and \((6,7)\). The short leaf \(r\) is among \(3,\ldots,7\). If \(r\ne3\), it cannot be paired with a site, and every cherry must be one of those two ineligible pairs. For \(r=4,5\), only \((6,7)\) remains; for \(r=6,7\), only \((4,5)\) remains. A full binary tree with exactly one cherry is a comb. With cherry \((6,7)\), its five preceding singleton depths are \(1,2,3,4,5\), making site 2 even-depth. With cherry \((4,5)\), the two odd site depths force singleton depths \(d_1,d_2=(1,3)\); the remaining singleton depths give \(r=6\) and the fourth table row, or \(r=3\) and the first row. Thus \(r=4,5,7\) are impossible, and the only \(r\ne3\) survivor is the displayed \(r=6\) comb.

For \(r=3\) the depth-parity word is \(OOOEEEE\). Use the root-split recurrence of [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md): a proposed child block, read in the parent's parity word, has signed sum \(-1\pmod3\), with \(E=+1,O=-1\); then complement the block's letters and recurse. The root splits are \(1\mid6\) and \(5\mid2\). In the \(1\mid6\) split the six-leaf child has word \(EEOOOO\), with splits \(2\mid4\) and \(5\mid1\). The first gives the second table row: sibling pairs \((2,3),(4,5),(6,7)\). In the \(5\mid1\) split, the five-leaf child has word \(OOEEE\), with splits \(1\mid4\) and \(3\mid2\). The former gives the first-row comb; the latter makes \((5,6)\) siblings, forbidden by Note 426. In the root \(5\mid2\) split, the five-leaf child has word \(EEEOO\), with splits \(2\mid3\) and \(4\mid1\). The former makes sites \((1,2)\) siblings; the latter gives the third table row, with sibling pairs \((2,3),(6,7)\). This exhausts sites \((1,2)\).

Now let the sites be \(1,7\), so the ineligible block is \(2,\ldots,6\) and the permitted full-leaf cherries are \((3,4)\) and \((5,6)\). If \(r=3,4\), only \((5,6)\) can be a cherry; if \(r=5\), only \((3,4)\) can be a cherry. None of these short leaves is adjacent to a site, so the tree has exactly one cherry and is a comb. In a seven-leaf comb the singleton depths are \(1,\ldots,5\), increasing before the cherry and decreasing after it. Requiring sites \(1,7\) and the short leaf to occupy precisely the three odd singleton depths gives the two \(r=3,4\) rows and the two \(r=5\) rows of the table.

For \(r=2\), the parity word \(OOEEEEO\) permits root splits \(1\mid6,3\mid4,6\mid1\). The \(1\mid6\) split leaves \(EOOOOE\), whose sole split is \(3\mid3\), giving the fifth table row with cherries \((3,4),(5,6)\). The \(3\mid4\) split gives child words \(EEO\) and \(OOOE\), hence the sixth row with cherries \((1,2),(5,6)\). The \(6\mid1\) split leaves \(EEOOOO\), whose \(2\mid4\) split gives the seventh row with cherries \((1,2),(3,4),(5,6)\). Its \(5\mid1\) split leaves \(OOEEE\): the \(1\mid4\) split gives the eighth-row comb, while the \(3\mid2\) split makes forbidden siblings \((4,5)\). No other splits pass the recurrence.

For \(r=6\), the parity word \(OEEEEOO\) permits root splits \(1\mid6,4\mid3,6\mid1\). The \(1\mid6\) split leaves \(OOOOEE\), with splits \(1\mid5,4\mid2\). In the first, the remaining \(EEEOO\) splits \(2\mid3\) to give the last table row, or \(4\mid1\) to force forbidden siblings \((4,5)\). In the second, the four-leaf child is balanced and forces forbidden siblings \((2,3)\) and \((4,5)\). At root split \(4\mid3\), the left child has word \(EOOO\) and forces \((2,3)\). At root split \(6\mid1\), the left child has word \(EOOOOE\), whose sole \(3\mid3\) split forces \((2,3)\) and \((4,5)\). These are forbidden, leaving exactly the last row. Together with the comb cases, this exhausts the thirteen depth vectors. \(\square\)

**Shared-chord corollary.** The row with sites \((1,7)\), short leaf \(5\), and depths \((1,2,6,6,5,4,3)\) is Hamiltonian in every legal row-IV completion. Its ordinary word is exactly the first comb of [Note 429](429-two-short-fifth-leaf-combs-have-marked-hamilton-cycles.md), equation (3). The path in that note's equation (4) uses only the face chords \(y_2x_3,y_4x_5\); both also occur in row IV. All ordinary edges and the outside closing route are identical. Thus this one row is excluded from a hypothetical non-Hamiltonian child without a new path construction.

The structural table leaves twelve words after this shared-chord corollary. Their legal realizability and Hamiltonicity require separate analysis. Row VI, the other eligibility spectra, and Barnette's conjecture are not settled here.
