> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact opposite-face chord packing for every square-trap lobe count

[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
proved the exact free-vertex minimum for at most three lobes and
established the prefix-cut rule for a nonfinal escape target.
The missing observation is that an escape target cannot lie in a
gap between the site and face-chord blocks. A prefix colour
balance then charges each nonfinal lobe to two extra vertices
inside a block, regardless of the number of lobes or the lengths
of the gaps.

Use the legal all-square Barnette opening and one-square-per-lobe
compression of Notes 176--179. Let the parent Hamilton cycle
avoid the cofacial matching site edges \(q=xy,p=uv\), and orient
its main segment \(S_0\) as \(x<y<u<v\). Let \(\ell\ge1\) be the
number of square-trap lobes, and let \(r\ge1\) be the number of
matching edges \(a_i b_i\) on the other \(y\)-to-\(u\) site-face
arc. Use the blocks \(B_0=[x,y]_C\),
\(B_i=[a_i,b_i]_C\) for \(1\le i\le r\), and
\(B_{r+1}=[u,v]_C\), with their intervening open gaps
\(G_0,\ldots,G_r\), exactly as in Note 193. Write
\(2+2k_i\) for the number of interior *slots* of \(B_i\);
this number is even by bipartiteness of its closing matching
edge. Write \(t_i\) for the number of slots of \(G_i\). Thus

\[
 |V(S_0)|=4r+8+2\sum_{i=0}^{r+1}k_i+
                  \sum_{i=0}^{r}t_i.                 \tag{1}
\]

The escape targets are \(R_\ell,L_\ell,\ldots,R_1,L_1\)
in this order on \(S_0\), where each \(R_j\) has odd
\(S_0\)-index and each \(L_j\) even index. Call slots of
odd and even index \(O\) and \(E\), respectively, and let
\(H\) be the number of \(E\) slots minus the number of
\(O\) slots in a prefix. Every slot other than an escape
target is matched to another slot of \(S_0\), since all
matching incidences on the residual squares and the block
endpoints are already fixed.

**Gap-exclusion lemma.** No escape target lies in any \(G_i\).
Moreover, if the first interior slot of a block is \(E\),
that slot cannot be an \(L_j\).

**Proof.** Consider an escape target \(T\) in a gap. Every
free-slot matching chord with one endpoint before \(T\) and
the other after \(T\) lies opposite the designated common
face. For endpoints in different atoms this is Note 193's
cross-atom observation: a block-interior endpoint forces
interlacing with its closing face chord, while two face-boundary
gap endpoints would split the designated face if joined on
that side. A matching edge within the same gap also cannot
lie on the face side: it would split that face or be an
additional listed face-boundary matching edge. An
opposite-side chord straddling \(T\) crosses the escape edge
from \(T\) to the complementary \(C\)-arc. Therefore every
free slot before \(T\) is matched to another free slot before
\(T\). Their \(O,E\) counts balance. The earlier escape
targets contribute zero to \(H\) if \(T=R_j\), since they
form complete \(R,L\) pairs, and contribute \(-1\) if
\(T=L_j\), since the current \(R_j\) has already occurred.
Consequently

\[
 H(T^-)=0\quad(T=R_j),\qquad
 H(T^-)=-1\quad(T=L_j).                         \tag{2}
\]

Every completed block has equally many \(O\) and \(E\)
interior slots, irrespective of its length. Across all gaps,
the gap slots alternate \(E,O,E,O,\ldots\), starting with
the first slot after \(y\): each intervening whole block has
an even number of vertices. Thus at a gap slot \(H\) is
zero immediately before an \(E\) slot and one immediately
before an \(O\) slot. An \(R_j\) must be \(O\) and an
\(L_j\) must be \(E\), contradicting (2) in either case.

Now suppose the first interior slot \(T\) of a block is
\(E\) and is an \(L_j\). A free matching chord straddling
\(T\) cannot have both endpoints in that block, because
there is no earlier interior slot there; the block endpoints
are already matched by its site or face chord. Every such
chord is cross-atom, hence opposite the common face and
crosses \(T\)'s escape edge. Thus the same prefix balance
gives \(H(T^-)=-1\). But the completed blocks contribute
zero, and the preceding gap slots form an odd-length
prefix of \(E,O,E,O,\ldots\), because this block begins
with an \(E\) interior slot: a whole block has even order,
so only gap slots change the first-slot parity of the next
block. Hence \(H(T^-)=1\), a
contradiction. \(\square\)

**All-lobe exact packing theorem.** For every
\(\ell,r\ge1\),

\[
 |V(S_0)|\ge4r+2\ell+6,
 \qquad f:=|V(S_0)|-2\ell-4\ge4r+2.             \tag{3}
\]

Both bounds are sharp in the Barnette class, with a
Hamiltonian parent and site-expanded child, for every pair
\((\ell,r)\). Every equality opening has empty interblock
gaps. More precisely, at equality every block starts with
an \(O\) interior slot and every even slot of that block
except its final slot is a nonfinal escape target \(L_j\).

**Proof.** Note 193's prefix-cut rule says that a nonfinal
\(L_j\), \(j\ge2\), cannot be the last slot of its block or
gap: the main prefix through that atom together with the
appropriate square suffix would have exactly two departing
old-cycle edges and no departing matching edge. By the
gap-exclusion lemma each \(L_j\) lies in a block.

A block with \(2+2k_i\) interior slots has at most \(k_i\)
positions for nonfinal \(L_j\). If its first slot is \(O\),
the even slots have positions \(2,4,\ldots,2k_i+2\),
and the final one is excluded by the prefix-cut rule.
If its first slot is \(E\), the even slots have positions
\(1,3,\ldots,2k_i+1\), and the first one is excluded by
the gap-exclusion lemma. There are exactly \(\ell-1\)
nonfinal targets, so

\[
 \ell-1\le\sum_{i=0}^{r+1}k_i.               \tag{4}
\]

Substituting (4) and \(t_i\ge0\) into (1) proves (3).
Note 190 constructs, for every \(\ell,r\ge1\), a legal
all-square opening with \(f=4r+2\), a Hamiltonian parent,
and a Hamiltonian site-expanded child. Note 178 permits
arbitrary positive original lobe lengths. Hence the lower
bound is the exact minimum for every pair.

Equality in (3) forces \(t_i=0\) for every gap and
\(\sum k_i=\ell-1\). With no gap slots, every block
starts with an \(O\) interior slot. Its \(k_i\) eligible
even positions must all be occupied by nonfinal \(L_j\),
because the total number of eligible positions equals
their total number. \(\square\)

**Equality endpoint corollary.** At equality, \(R_\ell\)
is the first vertex after \(x\) on \(S_0\), and \(L_1\)
is the last vertex before \(v\). If either outer block
\(B_0\) or \(B_{r+1}\) has more than two interior slots,
Note 186's simple boundary peeling removes one lobe,
preserves the equality and the child Hamilton decision,
and leaves the same site and face-chord count \(r\).
Consequently any boundary-irreducible equality opening has
exactly two interior slots in each outer block; all its
\(2\ell-2\) block-extra vertices lie in the \(r\) face-chord
blocks.

**Proof.** Consider the first target \(R_\ell\).
No block before it can have extra slots: at equality the
second interior slot of every such block would be a
nonfinal \(L_j\) preceding the first target. The first
target itself must be the first interior slot of its block
for the same reason. Suppose that block were later than
\(B_0\). All earlier blocks then have two free interior
slots, no gaps, and no internal free-slot matching chord
on the common-face side. The first slot of \(B_0\)
cannot match its adjacent second slot. Its mate must
precede \(R_\ell\), since a cross-atom opposite-side chord
straddling \(R_\ell\) would cross its escape edge.
Thus its mate is the second slot of some earlier block.
Noncrossing of opposite-side chords pairs all slots
strictly between these two endpoints internally. The
main \(C\)-prefix through the mate's block is then
closed under the whole complementary matching: site
and face chords are complete there, and no escape target
has yet occurred. Its cut has only its two boundary
\(C\)-edges, contrary to three-edge-connectivity.
Therefore \(R_\ell\) is the first slot of \(B_0\),
immediately after \(x\).

For the right endpoint, suppose \(L_1\) is in a block
\(B_i\) with \(i<r+1\). It must be that block's final
interior slot, because every earlier even slot of a
block is already occupied by a nonfinal \(L_j\).
Every later block is a two-slot block: extra slots
would force a nonfinal \(L_j\) after \(L_1\). In
particular the final slot \(z\) of \(B_{r+1}\) is
free. Its matching mate cannot precede \(L_1\):
such a cross-atom chord would lie opposite the common
face and straddle \(L_1\), crossing its escape edge.
The mate is therefore the first, odd slot \(w\)
of some later two-slot block \(B_h\). It cannot be
the first slot of \(B_{r+1}\), since that vertex is
adjacent to \(z\) on \(C\). Hence \(i<h<r+1\).
The chord \(wz\) lies opposite the common face.
Noncrossing forces every free slot strictly between
\(w,z\) to match another slot in that interval:
all these later blocks are two-slot blocks, so
there is no internal matching chord on the face
side. The consecutive \(C\)-interval formed by
\(B_h,\ldots,B_{r+1}\) is now closed under \(M\):
its block-closing chords and all its slot chords
are internal, and it contains no escape target.
Only two \(C\)-edges leave this proper vertex set,
contradicting three-edge-connectivity. Thus \(L_1\)
is the final slot of \(B_{r+1}\), immediately before
\(v\).

If \(B_0\) has extra slots, its second slot is an
eligible even position and hence \(L_\ell\); the
initial triple is \(x,R_\ell,L_\ell\). The following
vertex is another interior slot, so it is not \(y\);
Note 186 gives a simple peel. If \(B_{r+1}\) has
extra slots, its final two interior slots are
\(R_1,L_1\). Indeed, its last eligible even slot is a
nonfinal \(L_j\), and the only later odd and even slots
are the final two, which must hold the next pair
\(R_1,L_1\). The preceding vertex is another interior
slot, so it is not \(u\); the reflected simple peel
applies. Note 186 preserves \(r\) and
\(|V(S_0)|-2\ell\), hence equality in (3), and the
Hamilton decision. Repeating these peels removes all
outer-block extras unless the process reaches the
one-lobe case, where Note 191 already supplies a
Hamilton child. \(\square\)

For example, the four-lobe candidate \(r=3,f=12\)
would have \(|V(S_0)|=24\), whereas (3) requires at
least \(26\). Thus it cannot occur. The theorem concerns
the packing of a chosen all-square facial opening. It
does not assert that every equality child is Hamiltonian,
that every Barnette graph has such an opening, or that
Barnette's conjecture follows.
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
subsequently proves the Hamilton decision for every
equality opening.
