> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Jointly marked cross openings and nested Hall shores

Let \(G\) be a finite simple plane cubic bipartite 3-connected graph that is
2-extendable. Let \(C\) be a Hamilton cycle and let
\(M=E(G)\setminus E(C)\) be its complementary perfect matching. Select
three distinct edges \(p=uv,q=xy,f\in M\), where \(p,q\) form a legal
ordered \(C_4\)-expansion site. Use the usual child square
\(Q=abcda\) and spokes \(ua,bv,xc,yd\). In the child, put
\[
M_0=(M\setminus\{p,q\})\cup\{ua,bv,xc,yd\}.
\tag{1}
\]
Its complementary 2-factor is \(C\dot\cup Q\).

**Theorem.** There are simple \(M_0\)-alternating cycles \(A_{ad}\)
and \(A_{bc}\) such that \(A_{ad}\) uses \(ad\) as its only square
edge, \(A_{bc}\) uses \(bc\) as its only square edge, and neither cycle
uses \(f\). Consequently both cross-sector openings of \(Q\) preserve
the absence of \(f\) from the complementary 2-factor.

The result requires neither a global \(H^{+-}\) assumption nor
planarity in its matching argument. The legal site guarantees that the
two resulting cycles have the usual Barnette expansion interpretation.

**Marked-opening theorem.** For every retained edge \(e\in C\), at least
one cross-sector opening can be chosen to avoid both \(e\) and \(f\).
Thus its complementary 2-factor contains \(e\) and avoids \(f\).
This assertion concerns a 2-factor, not necessarily a Hamilton cycle.
Its proof follows the crossed-shore argument below.

The proof yields an independent graph theorem. **Structural theorem.**
Let \(G\) be any finite simple cubic bipartite 2-extendable graph,
\(M\) any perfect matching, \(f\in M\), and \(e\notin M\) disjoint
from \(f\). In \(G-V(f)\), contract \(M\setminus\{f\}\) and orient
each remaining edge from its first-class matched pair to its
second-class matched pair. If \(\alpha_e\) is the arc of \(e\), then
the strong-component condensation after deleting \(\alpha_e\) is
totally ordered by directed reachability. If it has more than one
component, its proper successor-closed shores form a nested chain;
each shore corresponds to a 4- or 6-edge cut of \(G\) and to a set
\(A_S\) with \(|N_G(A_S)|=|A_S|+2\). In particular, this conclusion
uses neither a Hamilton cycle nor planarity. The matching, Hall, and
cut arguments below prove it.

## Matching-covered digraph lemma

Let \(B\) be a connected bipartite graph in which every edge belongs to
some perfect matching, and fix a perfect matching \(N\). Contract its
edges. For each edge outside \(N\), direct the resulting arc from the
pair containing its endpoint in the first bipartition class to the pair
containing its endpoint in the second class. The directed graph
\(D_N\) is strongly connected.

For otherwise choose a proper sink strongly connected component and let
\(S\) be its set of matched pairs. No edge goes from the first-class
vertices of \(S\) to the second-class vertices outside \(S\). Every
perfect matching must therefore match all first-class vertices of
\(S\) within the equally large second-class set of \(S\). An edge from
the first class outside \(S\) into the second class of \(S\) could lie
in no perfect matching. Connectedness supplies such a crossing edge,
contrary to the hypothesis. \(\square\)

## Proof of the theorem

Delete the two endpoints of \(f\) and call the resulting graph \(G_f\).
It is connected because \(G\) is 3-connected. Every edge \(h\) of
\(G_f\) is disjoint from \(f\); by 2-extendability, \(\{f,h\}\) extends
to a perfect matching of \(G\). Removing \(f\) from that matching
shows that every edge of \(G_f\) lies in a perfect matching of \(G_f\).
The lemma applied to \(N=M\setminus\{f\}\) proves that its matching
digraph \(D_f\) is strongly connected.

The vertices of \(D_f\) corresponding to \(p,q\) are distinct. Take
simple directed paths \(p\leadsto q\) and \(q\leadsto p\) in \(D_f\).
Choose the first bipartition class to contain \(u,x\).
The first leaves the pair \(p=uv\) through \(u\) and enters the pair
\(q=xy\) through \(y\). Splitting the two site matching pairs as in
the child turns it into a directed return from \(u\) to \(d\). Close
that return with the square arc \(d\to u\), corresponding to \(ad\).
The second path similarly becomes a return from \(x\) to \(b\), closed
by \(b\to x\), corresponding to \(bc\). Expanding the contractions
gives the two claimed simple alternating cycles. Neither path visits
the deleted pair \(f\), so neither cycle uses \(f\). \(\square\)

## Where a second protected edge can intervene

Suppose also that a retained edge \(e\in C\) must stay in the opened
2-factor. If \(e\) meets \(f\), neither edge occurs in \(G_f\), so both
cross openings constructed above avoid \(e\) as well as \(f\). Thus
only the case \(e\cap f=\varnothing\) needs another test.

In that case \(e\) is an arc \(\alpha_e\) of \(D_f\). If
\(D_f-\alpha_e\) remains strongly connected, the proof above yields
both cross openings while avoiding \(e\) as well as \(f\). Thus if no
cross opening preserves both marks, \(\alpha_e\) must be a **strong
bridge** of \(D_f\). Strong bridges can occur, but the two-mark failure
will be ruled out below.

There is a matching interpretation. For a connected bipartite graph with
fixed perfect matching \(N\), the proof of the lemma also works in
reverse: \(D_N\) is strongly connected if and only if every edge of the
graph belongs to a perfect matching. The reverse direction follows by
placing any nonmatching arc on a directed cycle and toggling that cycle
against \(N\). Here \(e\notin N\), and matching-coveredness puts
\(e\) on an \(N\)-alternating cycle, so \(G_f-e\) remains connected.
Consequently \(\alpha_e\) is a strong bridge precisely when some
edge of \(G_f-e\) belongs to no perfect matching of \(G_f-e\). No
assertion that every such \(e\) is removable is made here. Equivalently,
there is an edge \(h\ne e\) which appears in a perfect matching of
\(G_f\), but every perfect matching of \(G_f\) containing \(h\) also
contains \(e\). This is the exact matching-incidence certificate of a
strong bridge at \(e\).

If \(G\) also has global \(H^{+-}\), this certificate forces a
Hamilton-witness incidence: every Hamilton cycle of \(G\) containing
\(e\) and avoiding \(h\) must contain \(f\). Otherwise its
complementary perfect matching would contain \(f,h\), avoid \(e\),
and after deleting \(f\) contradict the defining property of \(h\).
Such a cycle exists by global \(H^{+-}\); this consequence does not
itself transfer the original \(e\)-positive, \(f\)-negative witness.

The pair-specific condition is sharper than strong-bridge status. Put
\(D'=D_f-\alpha_e\). A simple cross opening through \(ad\) avoiding
both marks is equivalent to a directed \(p\leadsto q\) path in \(D'\);
one through \(bc\) is equivalent to a directed \(q\leadsto p\) path.
The reverse implication is the construction above. For the forward
implication, contract the matching edges of the alternating cycle and
delete its unique square arc; the remaining simple directed path has
the stated endpoints and avoids \(z_f,\alpha_e\).

If \(\alpha_e\) is a strong bridge, the strongly connected components
of \(D'\) form a directed acyclic graph with a unique source containing
the head of \(\alpha_e\) and a unique sink containing its tail. Indeed,
any other source or sink would remain such after putting back just
\(\alpha_e\), contrary to strong connectivity of \(D_f\). Hence **both**
marked cross openings fail exactly when the components containing
\(p,q\) are incomparable in the reachability order of this acyclic
graph. If they are comparable, the reachable direction gives a marked
cross opening. This is an exact incidence test; it still does not test
whether the opened complementary 2-factor is connected.

## Hall-tight shores exclude a double failure

Continue to assume \(e\cap f=\varnothing\). Let \(z_f\) be the vertex
of the full matching digraph \(D_M\) corresponding to \(f\). Call a
nonempty proper set \(S\subset V(D_f)\) an **\(e\)-shore** if
\(\alpha_e\) is its only outgoing arc in \(D_f\). For an \(e\)-shore,
let \(A_S,B_S\) be the two equally sized sets of endpoints of its
matching pairs. Write \(b_f\) and \(b_e\) for the second-class
endpoints of \(f\) and \(e\), respectively.

**Crossed-shore theorem.** Both cross openings avoiding \(e,f\) fail
if and only if there are two \(e\)-shores \(S,T\) with
\[
 p\in S\setminus T,\qquad q\in T\setminus S.
\tag{2}
\]
Every \(e\)-shore is Hall-tight in the original graph:
\[
 N_G(A_S)=B_S\cup\{b_e,b_f\},
 \qquad |N_G(A_S)|=|A_S|+2.
\tag{3}
\]
The intersection and union of the shores in (2) are also \(e\)-shores.
Moreover, every arc entering any \(e\)-shore represents an old cycle
edge \(h\) such that each perfect matching of \(G\) containing \(f,h\)
also contains \(e\).

**No-crossing theorem.** In a cubic bipartite 2-extendable graph, all
\(e\)-shores are nested. Equivalently, every pair of vertices of
\(D_f-\alpha_e\) is comparable by directed reachability, even if
\(\alpha_e\) is a strong bridge.

To prove the equivalence, if there is no directed \(p\leadsto q\) path
in \(D'\), let \(S\) be the vertices reachable from \(p\). It excludes
\(q\) and has no outgoing arc in \(D'\). Since \(D_f\) is strong,
\(\alpha_e\) must leave \(S\), making it an \(e\)-shore. Apply the
same argument from \(q\) to obtain \(T\) and (2). Conversely, (2)
prohibits paths in both directions. Each \(e\)-shore contains the tail
and excludes the head of \(\alpha_e\), and is successor-closed in
\(D'\). Its intersection and union with another \(e\)-shore have the
same properties.

For (3), let \(s\) be the number of arcs from \(S\) to \(z_f\) and
\(r\) the number from \(z_f\) to \(S\). The full digraph \(D_M\) has
indegree and outdegree two at every vertex. Balance across \(S\)
therefore gives
\[
 d^-_{D_f}(S)=1+s-r,
 \qquad |\delta_G(A_S\cup B_S)|=2+2s.
\tag{4}
\]
No matching edge crosses this vertex cut. Since a cubic 3-connected
graph is 3-edge-connected, the even cut in (4) has size at least four;
thus \(s\geq1\). The only edges from \(A_S\) to vertices outside
\(B_S\) are \(e\) and these \(s\) edges to \(b_f\). This proves (3),
where \(b_e\ne b_f\) because \(e\cap f=\varnothing\).

Finally, strong connectivity of \(D_f\) supplies an entering arc
\(h\) for every \(e\)-shore. In \(G_f-e\), all neighbors of \(A_S\)
lie in \(B_S\), so a perfect matching cannot use an edge from outside
\(A_S\) into \(B_S\). Every perfect matching of \(G_f\) containing
\(h\) must therefore contain \(e\). Such a matching exists because
\(G_f\) is matching-covered. Adding \(f\) proves the last assertion
and explicitly locates the incidence-certificate edges above.
\(\square\)

To prove the no-crossing theorem, suppose two \(e\)-shores \(S,T\)
are incomparable and split
the matching-pair vertices into
\[
 I=S\cap T,\quad X=S\setminus T,\quad Y=T\setminus S,
 \quad O=V(D_f)\setminus(S\cup T).
\tag{5}
\]
All four sets are nonempty: the tail of \(\alpha_e\) lies in \(I\),
its head lies in \(O\), and incomparability makes \(X,Y\) nonempty.
The intersection
\(I\) is an \(e\)-shore, so (4) gives \(s_I\geq1\), where \(s_W\)
counts arcs from \(W\) to \(z_f\). Since \(z_f\) has indegree two,
\[
 s_I+s_X+s_Y\leq2.
\tag{6}
\]
Let \(c_X\) count arcs from \(X\) to \(I\), and define \(c_Y\)
analogously. No arc from \(X\) in \(D'\) leaves \(S\), and
\(\alpha_e\) starts in \(I\). Therefore the neighbors of the
first-class vertices \(A_X\) lie in \(B_X\cup B_I\cup\{b_f\}\).
The strict Hall inequality for 2-extendable bipartite graphs applies
to \(X,Y\), since the three nonempty matching-pair sets
\(I,O,\{z_f\}\) lie outside each one. It gives
\(|N_G(A_X)|\geq|A_X|+2\) and the analogous inequality for \(Y\).
The matching already supplies exactly \(|A_X|\) vertices of \(B_X\),
so at least two distinct neighbors lie in \(B_I\cup\{b_f\}\). Hence
\(c_X\geq2-s_X\), and similarly \(c_Y\geq2-s_Y\). By (6),
\[
 c_X+c_Y\geq4-s_X-s_Y\geq2+s_I.
\tag{7}
\]
But both collections of arcs enter \(I\), whereas (4) applied to
\(I\) gives
\[
 c_X+c_Y\leq d^-_{D_f}(I)=1+s_I-r_I\leq1+s_I,
\tag{8}
\]
a contradiction. Here the strict Hall inequality follows, for example,
from the vertex-deletion characterization of bipartite 2-extendability
in Gorsky--Steiner--Wiederrecht (2023, Theorem 2.6): deleting any two
vertices of each colour leaves a perfect matching. Indeed, if a
nonempty first-class set of size at most \(|A|-2\) had at most one
more neighbor than its size, delete two of its neighbors and two
first-class vertices outside it, contradicting Hall's theorem.
There are always two neighbors to delete because \(G\) is simple and
cubic.

Thus (2) is impossible. The exact reachability criterion above proves
the marked-opening theorem for \(e\cap f=\varnothing\); the adjacent
case was handled directly. \(\square\)

The proof used no choice of \(p,q\). If \(\alpha_e\) is a strong
bridge, write the strong components of \(D'\) in their uniquely forced
reachability order \(V_1,\ldots,V_k\). The condensation has an arc
from \(V_i\) to \(V_{i+1}\) for each \(i\), and its nonempty proper
successor-closed sets are exactly the suffixes
\(V_i\cup\cdots\cup V_k\) for \(2\leq i\leq k\). These are precisely
the \(e\)-shores. In particular, every such shore is the matched-pair
side of a 4- or 6-edge cut of \(G\), by (4) and \(1\leq s\leq2\).
This canonical nested cut chain is the full strong-bridge obstruction;
it can remove one direction of a marked opening but never both.

Strong bridges are genuine here. In the cube \(C_4\square K_2\), label
the rims \(T_i,B_i\) cyclically and take
\(M=\{T_1T_2,T_3T_0,B_0B_1,B_2B_3\}\),
\(f=B_0B_1\), and \(e=T_0T_1\). The complement of \(M\) is one
Hamilton cycle. Naming the three surviving matched pairs
\(P=T_1T_2,Q=T_3T_0,R=B_2B_3\), the arcs of \(D_f\) are
\(P\to Q\) (the edge \(e\)), \(Q\to P\), \(Q\to R\), and
\(R\to P\). Thus \(\alpha_e\) is a strong bridge, while the
remaining reachability order is total.

The remaining connectivity test has a direct quotient form, parallel to
[Note 017](017-cross-traversals-are-exactly-quotient-tree-connectors.md).
In the disjoint-edge case, take a simple path \(P\) in \(D'\) from
\(p\) to \(q\); in the adjacent-edge case, use \(D_f\) instead. Let
\(E_C(P)\) be its \(t\) nonmatching edges in \(C\), and let
\(E_M(P)\) be its \(t-1\) internal matching edges. Cut \(C\) at
\(E_C(P)\), contract each of the resulting \(t\) path components,
and retain the edges \(E_M(P)\), allowing loops and parallel edges.
Call the resulting multigraph \(K(P)\). The opened child 2-factor has
exactly \(c(K(P))\) components: one includes the new square and the
other \(c(K(P))-1\) are old cycles. Indeed, the old part after the flip
is \((C-E_C(P))\cup E_M(P)\), and contraction preserves its component
partition. Its only degree-one vertices are the two ports joined by the
new square path. Since \(|E(K(P))|=|V(K(P))|-1\), the child is
Hamiltonian exactly when \(K(P)\) is a tree. The same construction
applies to a path from \(q\) to \(p\).

Even when an opening avoids both \(e\) and \(f\), its complementary
2-factor may have extra cycles. A direction with a marked path is now
guaranteed; the remaining single-flip task is to choose such a path
whose \(K(P)\) is a tree.
Other Hamilton witnesses can still arise through four-spoke linkages or
multiple alternating exchanges; their existence is not decided here.

There is a direct tree selection when one residual facial arc is a
single edge. Suppose, for instance, that the edge \(h=vx\) joins the
two site edges along their common face. Since \(p,q\in M\), both
endpoints use \(h\) on \(C\). Thus \(C-h\) is a spanning
\(v\)-to-\(x\) path in \(G-\{p,q\}\). Replacing \(h\) with the child
path \(v-b-a-d-c-x\) gives a Hamilton cycle in the cross sector; it
is exactly the alternating-square flip on \(b,v,x,c,b\) from
\(C\dot\cup Q\). For every \(e\in C\setminus\{h\}\) and
\(f\in M\setminus\{p,q\}\), this cycle contains \(e\) and avoids
\(f\). The symmetric assertion holds when the other facial arc is
the edge \(uy\). If both arcs have length one, choosing the other
flip covers also the case \(e=h\). Hence a planar cofacial site
without either cross Hamilton path must have both residual facial
arcs of length at least three.

More generally, [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md)
proves that a literal alternating facial arc of length \(2k+1\)
creates exactly \(k\) old residual cycles. Thus every such facial
return longer than one edge has a non-tree quotient; any successful
single opening must leave that literal facial arc.
