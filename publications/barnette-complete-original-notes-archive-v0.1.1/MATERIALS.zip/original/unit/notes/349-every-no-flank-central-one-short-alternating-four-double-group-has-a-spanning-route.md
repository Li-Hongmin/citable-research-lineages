> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every no-flank central-one-short alternating four-double group has a spanning route

[Note 348](348-a-central-short-block-supports-another-square-equivalent-four-double-core.md)
settles the \(h_1j_2\) and \(h_1o_3\) branches and excludes
\(h_1r\) for four double blocks with one central short block.
The remaining mates \(j_4,R\) of \(h_1\) also admit spanning
routes. This closes the Hamilton decision for every matching
of this specified no-flank group.

Use the compressed, gapless, tight-target all-square Barnette
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
An ordinary target-free free group consists exactly of
\[
D_1,D_2,S,D_3,D_4,\qquad
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t),\quad
S=(c,r,s,d),                                             \tag{1}
\]
with no other complete block in the group. Its double-block
internal chords are \(i_1e_1,o_2k_2,i_3e_3,o_4k_4\),
so the orientation word is \(J_3,J_1,J_3,J_1\).
Let \(L,R\) be the ordinary even and odd endports.
By [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
these are the only same-block free chords; by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
cross-block free matching edges are noncrossing on the
opposite side of the old Hamilton cycle. The residual slot
order is Note 348 (11).

**Complete central-one-short route theorem.** Every matching
of this group that occurs in a Barnette parent has a
vertex-spanning \(L\)--\(R\) path. If all vacancies outside
this group occupy distinct internal blocks, the parent
has a Hamilton cycle through both site edges and its
legal site-expanded child is Hamiltonian. More precisely,
\(h_1r\) is impossible; \(h_1j_2\) forces a local
square patch on \(D_1,D_2\); \(h_1o_3\) is settled
by Note 348; \(h_1j_4\) has exactly the two matching
words (2) below; and \(h_1R\) either forces a local
square patch on \(D_3,D_4\) or has the matching word
(5) below. The two words in (2) and the word (5)
are realized by three-connected cubic bipartite
plane parents.

**The \(h_1j_4\) branch.** Noncrossing and the forbidden
two-edge cut force \(Lo_1,e_4R\). Apart from these
edges, the only two possible matching words are
\[
\begin{array}{c|l}
A&h_1j_4,\ k_1i_2,\ j_1h_2,\ j_2h_3,\
  e_2r,\ so_3,\ k_3i_4,\ j_3h_4,\\
B&h_1j_4,\ k_1i_4,\ j_1h_2,\ i_2k_3,\
  j_2h_3,\ e_2r,\ so_3,\ j_3h_4 .
\end{array}                                                \tag{2}
\]
Indeed \(k_1\) can meet only \(i_2,j_3,i_4\)
inside \(h_1j_4\). The chord \(k_1j_3\) would
trap the old edge pair \(h_4i_4\).
If \(k_1i_2\), then \(j_1h_2\) is forced and
\(j_2\) can meet only \(s\) or \(h_3\).
The first choice forces \(e_2r\) and leaves
\(o_3\) with no available mate; the second
forces \(e_2r,so_3,k_3i_4,j_3h_4\), giving \(A\).

If \(k_1i_4\), then \(j_1\) can meet only
\(h_2,k_3,h_4\). The choice \(j_1k_3\)
leaves \(h_2\) unmatched. The choice \(j_1h_4\)
forces \(h_2j_3,i_2k_3,j_2h_3,e_2r,so_3\).
All matching edges of the proper complete-block
interval \(D_2,S,D_3\) then stay inside it,
giving a forbidden two-edge cut. Thus \(j_1h_2\).
The slot \(i_2\) can then meet only \(k_3\) or
\(h_4\). The latter choice leaves either \(o_3\)
unmatched or the old pair \(k_3j_3\); the former
forces \(j_2h_3,e_2r,so_3,j_3h_4\), giving \(B\).

For \(A\), take [Note 345](345-an-unbounded-alternating-double-block-chain-has-a-marked-hamilton-route.md)
(15)'s 32-vertex
\(o_1\)--\(e_4\) path. For \(B\), take
[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
(4)'s path with the same endpoints.
In either path the consecutive vertices
\(e_2,o_3\) use the matching chord \(e_2o_3\).
Replace that single edge by the path
\[
                  e_2,r,c,d,s,o_3.                       \tag{3}
\]
Its joins are \(e_2r,rc,cd,ds,so_3\).
This inserts all four vertices of \(S\) exactly
once and gives a spanning \(o_1\)--\(e_4\)
path for the matching word in (2). Prepending
\(Lo_1\) and appending \(e_4R\) gives the group
route.

Both words in (2) occur. Start with the 44-vertex
Barnette parent of Note 345 at \(m=2\), respectively
Note 347 (7)--(8). Insert \(S\) in the old-cycle
order between \(D_2,D_3\), add its face chord
\(cd\), and replace the opposite chord \(e_2o_3\)
by \(e_2r,so_3\). The two chord pages remain
noncrossing; all matching chords still pair
opposite old-cycle colours. In either parent's
connected chord-interlacement certificate,
replace the edges incident with \(e_2o_3\)
by the connected chain
\[
             a_2b_2-e_2r-cd-so_3-a_3b_3.                 \tag{4}
\]
All other certificate chords stay connected through
the \(j_th_{t+1}\) chain. Thus the new graph has
no one- or two-edge cut and is a 48-vertex Barnette
graph. Its site chords remain cofacial, with
facial arcs of lengths eleven and three.
The route (3) in the old marked Hamilton cycle
gives a marked Hamilton cycle after insertion.

**The \(h_1R\) branch.** Here \(Lo_1\) is forced.
The even slot \(k_1\) can meet only \(i_2,j_3,i_4\).
The second leaves \(h_4\) unmatched in the right
tail; the third leaves the forbidden old pair
\(j_4e_4\). Thus \(k_1i_2,j_1h_2\).
Now \(j_2\) can meet only \(s,h_3,e_4\).
If \(j_2s\), noncrossing forces \(e_2r,o_3e_4,
h_3j_4,k_3i_4,j_3h_4\), closing the proper
interval \(D_3,D_4\) under the matching.
If \(j_2h_3\), it forces \(e_2r,so_3\)
and leaves \(j_4e_4\) as an old edge pair.
Hence \(j_2e_4\).

The remaining even slot \(e_2\) can meet only
\(r,o_3,j_4\). The chord \(e_2o_3\) traps the
old pair \(rs\). If \(e_2r\), the remaining
slots force \(so_3,h_3j_4,k_3i_4,j_3h_4\);
this contains Note 335's local square patch on
\(D_3,D_4\). Compress it. The reduced group
has just two adjacent oppositely oriented double
blocks and short blocks, so [Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
supplies a spanning route, which lifts back.

Otherwise \(e_2j_4\) occurs and the remaining
slots force \(rh_3,so_3,k_3i_4,j_3h_4\).
Thus the only nonlocal word in this branch is
\[
 Lo_1,\ h_1R,\ k_1i_2,\ j_1h_2,\ j_2e_4,\
 e_2j_4,\ rh_3,\ so_3,\ k_3i_4,\ j_3h_4.               \tag{5}
\]
It has the explicit spanning route
\[
\begin{split}
L,o_1,a_1,b_1,&a_2,b_2,e_2,j_4,k_4,i_4,k_3,i_3,h_3,
 r,c,d,s,o_3,a_3,b_3,e_3,j_3,h_4,\\
&o_4,a_4,b_4,e_4,j_2,k_2,o_2,h_2,i_2,
 k_1,j_1,e_1,i_1,h_1,R .
\end{split}                                                \tag{6}
\]
The non-old joins along (6) are \(Lo_1\), the
block-closing and internal face chords,
\(e_2j_4,k_3i_4,rh_3,cd,so_3,j_3h_4,
e_4j_2,o_2k_2,i_2k_1,i_1e_1,h_1R\);
all other joins are old-cycle edges.
The route visits every vertex of the five blocks
once. This settles \(h_1R\).

The word (5) is genuine as well. On the old cycle
\[
x,R_1,w,y,D_1,D_2,S,D_3,D_4,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x,                           \tag{7}
\]
use the common-face chords \(xy,uv,\alpha\beta\),
all five block-closing chords, and
\(i_1e_1,o_2k_2,i_3e_3,o_4k_4\). Put
\(\delta R_1,wo_1,h_1z,\gamma L_1\) and
the remaining eight chords of (5) on the
opposite side. They are disjoint or nested
there: \(h_1z\) surrounds the internal chords,
\(j_2e_4\) surrounds \(e_2j_4\), \(e_2j_4\)
surrounds \(rh_3,so_3,k_3i_4,j_3h_4\),
and \(rh_3\) surrounds \(so_3\).
The two pages give a simple cubic bipartite
plane graph. Its chord-interlacement graph
has the connected spanning system
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1z-uv-\gamma L_1-\alpha\beta-\delta R_1,\\
a_1b_1-k_1i_2-a_2b_2-j_2e_4-a_4b_4-j_3h_4
-a_3b_3-so_3-cd-rh_3,\\
a_1b_1-j_1h_2-o_2k_2,\qquad
a_2b_2-e_2j_4-a_4b_4,\qquad
k_1i_2-i_1e_1,\\
a_3b_3-k_3i_4-i_3e_3,\qquad k_3i_4-o_4k_4.
\end{gathered}                                           \tag{8}
\]
Each dash is endpoint alternation in (7).
The old Hamilton cycle excludes bridges,
and connected interlacement excludes
matching-closed intervals and two-edge cuts.
The cubic graph is therefore three-connected.
The site chords \(xy,uv\) remain cofacial,
with facial arcs of lengths eleven and three.
The route (6), with \(L=w,R=z\), joins the
same exterior square path as in Note 348 (10);
their union is a Hamilton cycle containing
both site edges. The legal expanded child
is Hamiltonian by Note 001.

Note 348 already proves that \(h_1r\) is
impossible and that the \(h_1j_2,h_1o_3\)
branches have spanning routes. These five
possible mates exhaust \(h_1\), proving the
theorem. Substitute the resulting group route
in Note 324's marked two-path construction;
Note 001 transfers it to the legal child.
\(\square\)

The theorem concerns precisely four consecutive
\(J_3,J_1,J_3,J_1\) double blocks, one central
short block, no outer flank and no singly vacant
block in the group. It does not assert the same
claim for the opposite orientation word
\(J_1,J_3,J_1,J_3\): old-cycle reflection
preserves the displayed even alternating word.
Longer central corridors, outer short flanks,
other internal chord types, target defects,
positive gaps, nonsquare residual cycles and
the general Barnette conjecture remain open.
This is a project-internal analytic proof,
without independent external review or
external priority claim.
