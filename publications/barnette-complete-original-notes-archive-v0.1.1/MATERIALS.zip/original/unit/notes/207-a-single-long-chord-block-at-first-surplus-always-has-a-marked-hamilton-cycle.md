> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A single long chord block at first surplus has a marked Hamilton cycle

[Note 204](204-two-chord-detours-realize-gapless-near-equality-for-all-lobe-counts.md)
constructs a Hamiltonian detour when the first-surplus
vacancy is at the start of the final long face-chord block.
The matching there is not an isolated choice. Planarity
and three-connectivity classify every matching for the
same block-length profile and force a marked Hamilton
cycle, regardless of the long block's position among the
opposite-face chords.

Use the compressed all-square opening and notation of
[Notes 195--197](197-gapless-square-trap-defect-budget.md).
Let \(G\) be a Barnette parent with a Hamilton cycle \(C\)
avoiding the cofacial site matching edges \(q=xy,p=uv\).
There are \(\ell\ge2\) square-trap lobes and \(r\ge2\)
opposite-face matching chords. Assume all interblock gaps
are empty, \(f=4r+4\), both endpoint targets are tight,
and all consecutive-lobe transitions \(L_jR_{j-1}\)
are old-cycle edges. Suppose all blocks except one
face-chord block \(B_k=[a_k,b_k]_C\) have exactly two
interior slots, whereas \(B_k\) has \(2\ell+2\)
interior slots and its unique vacant eligible even slot
is its second interior slot. Necessarily \(2\le k\le r\)
by [Note 205](205-an-internal-near-equality-vacancy-must-touch-a-short-block.md).

Write \(e_0\) for the free final even slot of \(B_0\),
\(o_j,e_j\) for the free first odd and final even slots
of each face block \(B_j\), and \(o_{r+1}\) for the
free first odd slot of \(B_{r+1}\). In \(B_k\), let
\(h\) be the vacant second slot and \(i\) its free
following odd slot. The free-slot order on \(C\) is
\[
e_0,o_1,e_1,\ldots,o_k,h,i,e_k,
o_{k+1},e_{k+1},\ldots,o_r,e_r,o_{r+1}.
\tag{1}
\]
All escape targets except \(R_\ell\in B_0\) and
\(L_1\in B_{r+1}\) lie after \(i\) and before \(e_k\)
inside \(B_k\).

**Single-long-block Hamilton theorem.** Under these
assumptions there is an integer \(s\),
\(1\le s\le k-1\), such that the complete free-slot
part of the complementary matching \(M=E(G)\setminus E(C)\)
is
\[
\begin{aligned}
M_{\rm free}={}&
\{e_j o_{j+1}:0\le j\le s-2\}\\
&\cup\{e_{s-1}i,\ o_s h\}\\
&\cup\{e_j o_{j+1}:s\le j\le r\}.
\end{aligned}                                                   \tag{2}
\]
Empty ranges are omitted. In particular \(G\) has a
Hamilton cycle containing both \(p,q\), and every legal
site-expanded child admitting this opening is Hamiltonian.
The statement also holds when the original lobes are
arbitrary positive-length even four-terminal ladders.

**Proof: matching classification.** All block endpoints
are already matched by the site or face chords, and all
square vertices by their fixed square and escape edges.
Thus only the vertices in (1) need matching. The first
target after \(i\) is \(L_\ell\). By Note 203, no
cross-block free chord can straddle it. Its only free
same-block vertex after it is \(e_k\). The free set
\[
F_-:=\{e_0,o_1,e_1,\ldots,o_k,h,i\}
\tag{3}
\]
has \(2k+2\) vertices. If one of them were paired to
\(e_k\), it would leave an odd number of \(F_-\)
vertices to match internally, with no other matching
edge leaving \(F_-\). That is impossible. Therefore
\(F_-\) is matched internally, and \(e_k\) belongs to
the independently matched set
\(F_+:=\{e_k,o_{k+1},e_{k+1},\ldots,o_{r+1}\}\).

Within \(F_-\), every matching edge joins different
blocks. Each short block's two free slots are adjacent
on \(C\); in \(B_k\), the only opposite-colour free
pairs that could lie wholly in the block are \(o_kh\)
and \(hi\), and both are adjacent cycle edges. Hence
Note 193 puts all these matching chords on the side
opposite the common site face, where they are noncrossing.
The same holds in \(F_+\).

We use a short-block skipping rule. If a noncrossing
matching chord \(e_{a-1}o_b\) skips one or more short
face blocks \(B_a,\ldots,B_{b-1}\), then their free
slots lie inside that chord and must match among
themselves. For one skipped block its two slots are
adjacent on \(C\), which cannot be an \(M\)-edge. For
two or more, the union of those complete short blocks
is a proper consecutive \(C\)-interval closed under
\(M\), giving a two-edge cut. Both are impossible.
The same argument applies to a collection of short
blocks immediately before a chord \(o_bh\).

Start at \(e_0\). Its available odd mates in \(F_-\)
are \(o_1,\ldots,o_k,i\). The skipping rule says it
must match \(o_1\) or \(i\). If it matches \(o_1\),
apply the same argument to \(e_1\), and continue.
Eventually some \(e_{s-1}\) must match \(i\), since
otherwise \(h,i\) would be left as adjacent unmatched
vertices. Here \(s\le k-1\): the alternative
\(e_{k-1}o_k\) would leave \(hi\), while
\(e_{k-1}i\) would leave \(o_kh\), both forbidden.
All earlier edges are \(e_j o_{j+1}\) for
\(0\le j\le s-2\).

Inside the chord \(e_{s-1}i\), the free even vertex
\(h\) must match an \(o_j\), \(s\le j\le k-1\).
If \(j>s\), the complete short blocks
\(B_s,\ldots,B_{j-1}\) would match internally by
noncrossing, contradicting the same skipping rule.
Thus \(o_sh\in M\), and applying the skipping rule
successively inside this chord forces
\(e_j o_{j+1}\) for \(s\le j\le k-1\).
In \(F_+\), the identical rule forces
\(e_j o_{j+1}\) for \(k\le j\le r\).
This is exactly (2).

**Proof: marked Hamilton cycle.** As in Note 196,
the target and square vertices form the
\(x\)-to-\(v\) path
\[
x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,R_{\ell-1},\ldots,
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v
\tag{4}
\]
in \(M\cup A\), where \(A\) is the even-starting
matching of \(C\) indexed from \(x\). The other
\(x\)-to-\(v\) path is Note 196's chain
\[
x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,
\ldots,o_r,a_r,b_r,e_r,o_{r+1},u,v,
\tag{5}
\]
with its segment \(e_{s-1},o_s\) replaced by
\(e_{s-1},i,h,o_s\). Indeed, (2) supplies the
two new matching edges, and \(ih\in A\).
Every displayed edge in (4)--(5) belongs to
\(M\cup A\). The paths meet only at \(x,v\) and
cover all vertices, so their union is a Hamilton
cycle through \(q,p\). Note 001 lifts it through
the legal site expansion. Note 178 restores the
positive-length original lobes without changing
the marked site edges. \(\square\)

**Single-long-block corollary.** Keep the gapless,
tight-target and block-length assumptions above with
\(\ell\ge2\), but do not specify which eligible
position of \(B_k\) is vacant. The parent still has
a Hamilton cycle through both site edges, and its
legal expanded child is Hamiltonian. Indeed, the
\(\ell-1\) other eligible positions are occupied;
Note 205 excludes a vacancy with occupied positions
on both sides. Therefore the vacancy is either the
first or the last eligible position. The first case
is the theorem above. Reverse the main-segment
orientation, exchange the two site labels, and
reverse the lobe order for the last case. The free
odd slot immediately following the old vacancy
becomes the first eligible vacant even slot in
the reversed long block, just as in Note 205's
reflected construction. All other assumptions
are preserved, so the theorem applies there.
\(\square\)

The theorem is universal for its block-length and
target-position profile. The corollary covers every
vacancy location in a single long face block when
\(\ell\ge2\). It does not cover a vacancy in an
outer block, multiple long face blocks, target
order defects, gap slots, or openings with nonsquare
residual cycles. It therefore does not settle the
first-surplus boundary as a whole or Barnette's
conjecture.

[Note 208](208-one-sided-internal-vacancies-have-marked-hamilton-cycles-at-first-surplus.md)
subsequently removes the single-long-block assumption:
additional occupied target runs create parity barriers,
and the same matching classification applies within
the group containing the vacancy.
