> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cubic parity forbids a two-clean-row annular isolator

[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md)
leaves open whether its remote two-crossing component can be removed by a
four-port annular splice while its isolated mixed \(K_2\) is retained.  A
transparent sufficient construction would use a cubic factor having exactly
two clean boundary rows.  This note proves that no finite cubic factor can
have that signature.  The obstruction is Hamilton-cycle parity and does not
require planarity, bipartiteness or the brace axiom.

## 1. The proposed factor signature

Let \(B\) be a finite simple cubic graph with a square

\[
 b_0b_1b_2b_3b_0,
\]

write \(q_i=b_ib_{i+1}\) with indices modulo four, and delete the opposite
edges \(q_0,q_2\).  A boundary row is a matching of the resulting four-port
graph which covers every nonport vertex; its state is the set of uncovered
ports.  A row is **clean** when its complement in the four-port graph has no
closed cycle component.

The transparent isolating signature consists of rows \(N_0,N_1\) satisfying

\[
\begin{array}{ll}
\mathrm{(T0)}&N_0\text{ has state }\varnothing,
 \text{ is clean, and pairs }01\mid23;\\
\mathrm{(T1)}&N_1\text{ has state }A_0=\{0,1\},
 \text{ and its complement is one spanning }b_2b_3\text{-path};\\
\mathrm{(TB)}&N_0\triangle N_1\text{ is one }b_0b_1\text{-path};\\
\mathrm{(TU)}&N_0,N_1\text{ are the only clean boundary rows.}
\end{array}
\tag{1}
\]

The first three clauses retain the selected mixed pair and its exchange
edge.  The last clause prevents every other factor row from entering the
spliced rooted family.

## 2. Translation to perfect matchings and Hamilton cycles

Put

\[
 P_0=N_0,
 \qquad P_1=N_1\cup\{q_0\}.
\tag{2}
\]

Both are perfect matchings of \(B\).  Since \(B\) is cubic, \(B-P_i\) is a
spanning \(2\)-factor.  Clause (T0) says exactly that

\[
 B-P_0=C_0\mathbin{\dot\cup}C_2,
\tag{3}
\]

where \(q_0\in C_0\) and \(q_2\in C_2\).  Clause (T1) says exactly that

\[
 H_1=B-P_1
\tag{4}
\]

is a Hamilton cycle containing \(q_2\) and avoiding \(q_0\).  Indeed,
deleting \(q_2\) from (4) is precisely the clean spanning \(b_2b_3\)-path.
Clause (TB) is equivalent to \(P_0\triangle P_1\) being one alternating
cycle, but it will not be needed for the obstruction.

## 3. The parity obstruction

We use the Smith--Thomason parity lemma: every edge of a finite cubic graph
lies in an even number of Hamilton cycles.  One standard proof fixes an
orientation of the edge and applies the lollipop involution to Hamilton
paths beginning with it.  Such a path has two lollipop continuations unless
its unused terminal edge closes the path to its initial vertex, in which
case it has one.  The odd-degree vertices of the finite lollipop graph are
therefore in bijection with Hamilton cycles through the fixed edge, and
their number is even.

Apply the lemma to \(q_2\in H_1\).  There is a second Hamilton cycle
\(H_2\ne H_1\) containing \(q_2\), and

\[
 P_2=E(B)-E(H_2)
\]

is a perfect matching.  There are two cases.

If \(q_0\in H_2\), then \(P_2\) avoids both deleted edges.  Its
state-\(\varnothing\) boundary row is clean because
\(H_2-\{q_0,q_2\}\) has no closed component.  It is not \(N_0\), since
\(B-P_0\) has two cycles by (3), whereas \(H_2\) is Hamiltonian.

If \(q_0\notin H_2\), then \(q_0\in P_2\).  The row

\[
 P_2-\{q_0\}
\]

has state \(A_0\), and its complement is the spanning Hamilton path
\(H_2-q_2\).  It is clean and differs from \(N_1\), because
\(H_2\ne H_1\).

In both cases (T0) and (T1) force a third clean row.  Hence

\[
 \boxed{\text{No finite cubic graph satisfies \(\mathrm{(T0)}\)--\(\mathrm{(TU)}\).}}
\tag{5}
\]

The conclusion is stronger than a brace obstruction: (TB), planarity,
bipartiteness, \(2\)-extendability and simplicity are not used in the parity
argument, apart from the harmless uniqueness of edge notation.

## 4. Exact surviving boundary

Equation (5) closes only the transparent uniqueness construction.  It does
not rule out an annular counterexample using extra clean rows.  A
parity-forced row can fail to join any carrier row into the prescribed
rooted complement, or every such join can have a multi-component symmetric
difference from both retained endpoints.

Thus the remaining counterexample interface is pair-relational.  A viable
factor must satisfy (T0), (T1) and (TB), admit the extra rows forced by
cubic parity, and make every additional rooted join fail the one-cycle bond
test against both members of the retained mixed pair.  Row counts and
Hamiltonicity alone cannot decide this condition; the complement partition
and the two pairwise bond atoms of every extra row are carrying.
