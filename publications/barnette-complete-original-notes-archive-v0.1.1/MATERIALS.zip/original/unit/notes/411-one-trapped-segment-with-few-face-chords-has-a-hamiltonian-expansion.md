> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One trapped segment with few face chords has a Hamiltonian expansion

The two ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) give a finite kernel for a selected facial opening with one trapped residual cycle. The published finite Hamilton theorem then applies to an infinite class, with no restriction on the original graph order.

Let \(G\) be a Barnette graph with Hamilton cycle \(C\) and a legal cofacial \(C_4\)-expansion site \(p,q\in M=E(G)\setminus E(C)\). Suppose a selected three-edge alternating facial opening traps exactly one residual cycle \(S\) of even length \(\ell\ge4\), as in [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md). Let \(S_0\) be the other old-cycle segment, let \(e\) count matching edges from the interior of \(S\) into \(S_0\), and let \(f\) count the additional matching chords with both ends in \(S_0\) on the common-face side of \(C\), excluding \(p,q\). Write \(G^+\) for the legal expanded child.

**Single-trap Hamilton theorem.** If
\[
                         \ell+e+12f\le78,                 \tag{1}
\]
then \(G^+\) is Hamiltonian. If
\[
                         \ell+e+12f\le54,                 \tag{2}
\]
then all six Hamilton traversal witnesses of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) occur at the original parent site. Since \(e\le\ell-2\), the conditions
\[
 2\ell+12f\le80\quad\text{and}\quad 2\ell+12f\le56          \tag{3}
\]
respectively suffice without specifying the interior matching of \(S\). In particular, a single trapped hexagon with \(f\le5\) always has a Hamiltonian legal child, whether or not its internal matching chord is present; for \(f\le3\), all six site witnesses exist. A non-Hamiltonian child with such a selected hexagonal opening therefore requires \(f\ge6\), regardless of its order or the length of the other facial arc.

**Proof.** The four site ports, \(e\) escape targets and \(2f\) face-side chord endpoints are special positions on \(S_0\). Every other main vertex belongs to a noncrossing matching of ordinary chords on the side opposite the common face. Note 176 puts each escape edge on that same side; hence an ordinary chord cannot contain an escape target, since the two edges would cross. The two end site ports of \(S_0\) are also outside every ordinary chord. Thus at most \(2+2f\) special positions can be assigned to the ordinary-chord containment forest.

Apply both reductions of Note 410 until neither remains. The first compresses four nested ordinary matching chords; the second compresses a leaf receiving exactly two special slots and having two plain-unary ancestors, with their intervening old-cycle edge as its fourth rung. Both patches induce an even four-column ladder \(P_4\square K_2\) with four corner attachments. The first contains no site port. In the second, any site port is retained as a square corner and its site edge remains an attachment, so compression commutes with site expansion. [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md) preserves the Barnette class, Hamilton decisions, and every gadget-edge incidence pattern of child Hamilton cycles in both directions. These patterns are precisely the six parent witness types by [Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md) and [013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md). The doubly reduced child \(\bar G^+\) is therefore Barnette and has exactly the same Hamilton decision as \(G^+\), while the six witness existence clauses at its parent site agree with those at the original site.

The containment-forest count in Note 410, including the mixed leaf-ladder reduction, gives at most \(5f+2\) remaining ordinary chords. Hence
\[
 |S_0|\le(4+e+2f)+2(5f+2)=8+e+12f,
 \qquad |V(\bar G^+)|\le\ell+12+e+12f.             \tag{4}
\]
Brinkmann, Goedgebeur and McKay, *The Minimality of the Georges--Kelmans Graph*, Theorem 4.1(a), **Math. Comp.** (2022), DOI `10.1090/mcom/3701`, prove that every Barnette graph on at most 90 vertices is Hamiltonian. Inequality (1) puts \(\bar G^+\) in that range. Reversing the ladder replacements lifts its Hamilton cycle to \(G^+\).

Under (2), (4) puts the reduced child at at most 66 vertices and its reduced parent at at most 62. Theorem 4.1(c) of the same paper gives both graphs global \(H^{+-}\): for every ordered pair of distinct edges, some Hamilton cycle contains the first and avoids the second. The exact gadget-edge criterion of [Note 013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md) then forces all six parent traversal types. Their preservation through both reductions gives the assertion for \(G\). Finally, \(S\) has \(\ell-2\) interior vertices, each paired internally or escaping into \(S_0\), so \(e\le\ell-2\), proving (3) and the hexagonal corollary. \(\square\)


**First uncovered hexagon boundary.** If \(S\) is a hexagon, \(f=6\), and \(G^+\) is non-Hamiltonian, every doubly reduced representative has a single rooted full binary ordinary-chord forest with seven marked leaves and six unmarked branching nodes. Each leaf receives exactly two special positions, and all fourteen assignable positions are used. Every leaf has one plain-unary ancestor and every branch has two, except that in the chord-free hexagon case one incoming chain may be shorter by one node.

Indeed, put \(c\) for the reduced ordinary-chord count. The reduced child has exactly \(26+e+2c\) vertices, while (8) of Note 410 gives \(c\le32\). The published 90-vertex bound implies \(c=32\) if \(e=2\), and \(c\in\{31,32\}\) if \(e=4\). In Note 410's proof of (8), \(m=7\) and
\[
 c\le2(M_0+L)+4\le32.
\]
Thus \(c\ge31\) forces \(M_0=L=7\): all fourteen assignable positions are assigned, two to each marked leaf. Hence \(Q=7\) and \(c\le3A-7\); the bound \(c\ge31\) forces \(A=13\). Therefore the forest has one root, exactly six unmarked binary branches, and no other marked nodes. Its seven leaf chains have length at most one and its six branch chains at most two, for a maximum of nineteen plain-unary nodes. Since \(P=c-13\) is 18 or 19, at most one chain is short. This is a necessary shape for a counterexample in the first parameter value beyond the theorem; it does not establish that the shape has a Barnette realization. \(\square\)

The published finite theorem is the only computational input. Its Theorem 4.1(c) was established directly with `plantri` and `cubhamg` through 66 vertices; parts (a) and (b) follow by Holton--Manvel--McKay reductions. Gorsky--Steiner--Wiederrecht restate the exact bounds as Theorem 5.7 of *Matching Theory and Barnette's Conjecture* (2023), DOI `10.1016/j.disc.2022.113249`. No local graph census or recomputation is used here. The six-witness conclusion does not assert global \(H^{+-}\) for the uncompressed child. The theorem does not cover multiple trapped residual cycles or resolve Barnette's conjecture.

[Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) subsequently uses the seven-leaf necessary shape above to exclude every \(f=6\) single-hexagon failure, strengthening the hexagonal Hamilton conclusion here from \(f\le5\) to \(f\le6\).
