> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Paid-exit discharge is degree-constrained cotree fragmentation

[Note 047](047-two-point-one-rank-violations-reduce-to-a-binary-paid-exit-deficit.md)
reduces an integral two-point rank violation to the problem of paying for
one boundary exit. [Note 048](048-integral-two-point-paid-exit-deficits-discharge-through-order-eighteen.md)
shows that every such deficit in a brace through order eighteen can be
discharged, while [Notes 049--051](049-primal-cycles-are-contracted-dual-cuts-and-exclude-the-six-label-blocker.md)
separate the roles of joint plane rotation, cofacial completion, and the
brace hypothesis. This note gives an exact primal reformulation: binary
cost is the fragmentation of a degree-constrained spanning cotree after a
set of opposite-colour vertices is deleted. It also identifies the precise
extra fragmentation which ordinary \(3\)-connectivity does not control.

## The site-admissible cotree family

Let \(F\) be a simple plane cubic bipartite graph with bipartition
\(X\sqcup Y\), and let \((u,v,z,a)\) be an ordered legal cofacial site,
where \(u,z\in X\) and \(v,a\in Y\). Put

\[
p=uv,\qquad q=za.
\]

Delete \(u,a\), contract \(p^*,q^*\) in the plane dual, and let \(Q\) be the
resulting retained contracted dual, as in Notes 044--051. A full common
base is a \(Q\)-spanning tree \(B\) choosing one retained edge from every
\(X\)-block. Define

\[
T_B=E(F)\setminus\bigl(B\cup\{p,q\}\bigr).
\tag{1}
\]

> **Cotree bijection.** The map \(B\mapsto T_B\) is a bijection from full
> common bases to the family
> \[
> \mathcal T_{u,v,z,a}=
> \left\{T:
> \begin{array}{l}
> T\text{ is a spanning tree of }F,\\
> p,q\notin T,\\
> \delta_F(u)\setminus\{p\},\ \delta_F(a)\setminus\{q\}\subseteq T,\\
> \deg_T(x)=2\quad(x\in X\setminus\{z\}),\\
> \deg_T(z)=1
> \end{array}
> \right\}.
> \tag{2}
> \]

Indeed, lifting the two contractions turns
\(B^*\cup\{p^*,q^*\}\) into a spanning tree of \(F^*\). The plane
tree--cotree theorem makes (1) a primal spanning tree. At every
\(x\in X\setminus\{u,z\}\), exactly one incident edge lies in \(B\), hence
two lie in \(T_B\). At \(z\), one incident edge lies in \(B\), the edge
\(q\) is excluded, and the remaining edge lies in \(T_B\). No retained
label is incident with \(u\) or \(a\), so their two nondistinguished edges
are forced into \(T_B\). These observations give every condition in (2).

Conversely, the dual complement of a tree in (2) is a dual spanning tree
containing \(p^*,q^*\). After contracting those two edges and deleting
their labels, the degree conditions in (2) leave exactly one retained edge
from every \(X\)-block. This recovers a full common base.

No brace or \(3\)-connectivity hypothesis is used in the bijection.

## The exact fragmentation identity

Fix \(A\subseteq Y\setminus\{a\}\), and let

\[
H=(Y\setminus\{a\})\setminus A,
\qquad h=|H|,
\qquad \epsilon=\mathbf 1_{\{v\in H\}}.
\tag{3}
\]

Thus \(H\) is the set of zero-cost \(Y\)-vertices. If \(z_H(B)\) denotes
the number of labels of \(B\) whose \(Y\)-endpoint lies in \(H\), then

\[
z_H(B)=3h-\epsilon-\sum_{y\in H}\deg_{T_B}(y).
\tag{4}
\]

For \(y\ne v\), this is just
\(\deg_B(y)=3-\deg_{T_B}(y)\). At \(v\), the distinguished nonlabel \(p\)
accounts for the correction
\(\deg_B(v)=2-\deg_{T_B}(v)\).

The set \(H\subseteq Y\) is independent. Deleting independent vertices
from a tree gives

\[
\operatorname{comp}(T_B-H)
=1+\sum_{y\in H}\bigl(\deg_{T_B}(y)-1\bigr).
\tag{5}
\]

There are \(|Y|-1\) blocks, so
\(|B|=|Y|-1\), \(|A|=|Y|-1-h\), and
\(c_A(B)=|B|-z_H(B)\). Combining (4) and (5) yields the exact equivalence

\[
\boxed{
c_A(B)\le |A|
\quad\Longleftrightarrow\quad
\operatorname{comp}(T_B-H)\le h+1-\epsilon.}
\tag{6}
\]

This is not merely a sufficient condition. A paid boundary completion
\(B_0\) of cost \(|A|+1\) satisfies

\[
\operatorname{comp}(T_{B_0}-H)=h+2-\epsilon.
\tag{7}
\]

Consequently integral paid-exit discharge is exactly the task of
coalescing at least two components of \(T_{B_0}-H\) while remaining inside
the degree- and edge-constrained family (2).

A one-block common-base exchange has the same primal meaning. If
\(B'=B-e+f\), then

\[
T_{B'}=T_B+e-f,
\tag{8}
\]

where \(f\) is the retained tree edge at the relevant \(X\)-vertex on the
fundamental cycle of \(T_B+e\). A cost-decreasing pivot is therefore
exactly a degree-preserving tree pivot which lowers
\(\operatorname{comp}(T-H)\) by one.

## What \(3\)-connectivity gives

Assume \(F\) is \(3\)-connected and \(H\ne\varnothing\). Then

\[
\boxed{\operatorname{comp}(F-H)\le h.}
\tag{9}
\]

If \(F-H\) is disconnected, each of its components has at least three
distinct neighbours in \(H\); otherwise deleting at most two vertices
would disconnect \(F\). Cubicity and independence of \(H\) provide only
\(3h\) edges from \(H\) to \(F-H\), proving (9). The connected case is
immediate.

An unconstrained spanning tree attains this lower fragmentation exactly:

\[
\min_{T\text{ spanning tree of }F}
\operatorname{comp}(T-H)=\operatorname{comp}(F-H).
\tag{10}
\]

Choose a spanning tree inside each component of \(F-H\), contract those
components, and lift a spanning tree of the connected component--\(H\)
incidence graph.

The unresolved quantity is therefore not ordinary connectivity but the
overhead imposed by (2):

\[
\eta_H(F;u,v,z,a)=
\min_{T\in\mathcal T_{u,v,z,a}}
\left[
\operatorname{comp}(T-H)-\operatorname{comp}(F-H)
\right].
\tag{11}
\]

For a fixed \(H\), binary support at the site is equivalent to

\[
\boxed{
\eta_H(F;u,v,z,a)
\le h+1-\epsilon-\operatorname{comp}(F-H).}
\tag{12}
\]

The right side is nonnegative by (9), but \(3\)-connectivity alone has not
yet been shown to control \(\eta_H\). In the non-brace obstruction of
Note 051, \(H=\{1,7\}\), \(v=1\), and \(F-H\) is connected. Every
site-admissible cotree has three components after deleting \(H\), so
\(\eta_H=2\), while (12) permits only one.

## Why a nonextendable pair is not enough

The \(14\)-vertex \(3\)-connected non-brace in Note 044 has bipartition

\[
X=\{0,1,2,3,4,5,6\},\qquad
Y=\{7,8,9,10,11,12,13\}.
\]

Put

\[
U=\{0,2,4,5,8,9,13\}.
\]

Its displayed incidence table gives

\[
\delta_F(U)=\{07,4\,11,5\,12\}.
\tag{13}
\]

Writing \(S=U\cap X\) and \(R=U\cap Y\), one has
\(|S|-|R|=1\) and \(N(R)\subseteq S\). In every perfect matching, the
number of edges directed from \(S\) to \(Y\setminus R\), minus the number
directed from \(X\setminus S\) to \(R\), equals one. The second number is
zero, so every perfect matching uses exactly one edge of (13). Thus (13)
is a nontrivial tight \(3\)-edge cut.

In particular, two distinct edges of (13), such as \(07\) and \(4\,11\),
cannot extend to one perfect matching even though the graph is
\(3\)-connected. A paid-exit argument which only extracts a
nonextendable independent pair therefore cannot prove (12): the pair may
occupy two ports of a tight \(3\)-cut. This is the structural alternative
excluded by a brace but retained by \(3\)-connectivity.

## The complete order-twenty-two non-brace boundary

At order \(22\), every simple plane cubic bipartite \(3\)-connected
non-brace satisfies

\[
\boxed{
\mu_F(A)=\min_B c_A(B)\le |A|}
\tag{14}
\]

for every ordered legal site and every
\(A\subseteq Y\setminus\{a\}\). Hence none has even the strict binary
layer required for an integral paid-exit obstruction.

The tight-cut decomposition explains the finite family. A tight cut in a
cubic bipartite matching-covered graph has three equally oriented edges:
if its shore has colour-class imbalance one, every perfect matching uses
one outward and no inward edge, and the cubic degree sum makes the entire
cut have size three. Repeated contraction decomposes an order-\(22\)
non-brace into plane cubic bipartite braces. If their orders are \(n_i\),
then

\[
22=\sum_i n_i-2(k-1).
\tag{15}
\]

The smaller plane cubic brace list from Note 046 leaves only a cube spliced
with one of the two order-\(16\) braces, or the order-\(12\) brace spliced
with itself. The \(2400\) rooted port gluings reduce to five unlabelled
graphs. A separate streaming generation of all \(4132\) connected cubic
bipartite graphs of order \(22\) finds eight planar \(3\)-connected graphs,
three braces and exactly the same five non-braces. This independently
checks completeness of the splice description.

The five graphs have \(1176\) ordered sites, or \(756\) site orbits. Exact
enumeration at the orbit representatives examines

\[
16{,}979{,}868\text{ block transversals},\qquad
1{,}529{,}304\text{ full common bases},
\]

and all \(2^{10}\) binary layers at every representative. No strict layer
occurs. At one site of each graph, the fast tree test and load multiset are
checked against the established common-base implementation, and the
cotree identity (6) is checked for every full base and binary layer.

The permanent verifier is

    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_order22_three_connected_nonbrace_binary_support.py

with terminal marker
ORDER22_THREE_CONNECTED_NONBRACE_BINARY_SUPPORT_VERIFIED.

## Remaining boundary

The universal \(3\)-connected statement remains open; (14) is a finite
classification, not an induction. The decisive interface is now the
following cap-conditioned tight-splice question:

> When two plane cubic bipartite factors are joined across a tight
> \(3\)-edge cut, how do the three port states constrain the minimum
> fragmentation of the site-admissible cotree family (2)?

A positive splice theorem would reduce the \(3\)-connected problem to its
brace factors. A negative result must exhibit factor load profiles whose
port compatibility forces the overhead in (11) above the budget in (12).
Further adjacent-order scans without such a profile would only raise a
finite lower bound and do not address this structural question.
