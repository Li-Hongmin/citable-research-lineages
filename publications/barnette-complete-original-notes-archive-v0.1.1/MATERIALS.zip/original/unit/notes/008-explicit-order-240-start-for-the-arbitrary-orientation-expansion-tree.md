> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An explicit order-240 start for the arbitrary-orientation expansion tree

> Note 009 proves that all \(2^k\) histories at depth \(k\) are mutually
> isomorphic as unlabelled graphs.  The result below certifies every history,
> not exponentially many isomorphism types.

The stored 240-vertex Barnette graph satisfies the robust support hypothesis
of Note 007 at its existing central expansion site.  Consequently it starts
an explicit full binary tree of edge-Hamiltonian Barnette graphs, rather than
only the single oriented chain of Note 004.

The graph6 SHA256 is

`1a45291660df221ace79b053604bae1256f74cb6e413ab76ba2b8c2d50ce308b`.

Use move 739 on the facial boundary

\[
(48,51,50,115,112,97)
\]

with

\[
(u,v,x,y)=(48,51,112,97),\qquad p=48\,51,
\quad q=97\,112.
\]

This is a legal parity-preserving Barnette \(C_4\)-expansion site.

## Eight explicit witnesses

In the stored 37-cycle library, choose

\[
\mathcal A=\{3,31,32,35\},\qquad
\mathcal B=\{7\},\qquad
\mathcal C=\{4\},
\]

in roles \(A=C_{11},B=C_{10},C=C_{01}\), and take the stored spanning
paths

\[
\mathcal D=\{X_{vx}:51\leadsto112\},\qquad
\mathcal E=\{X_{uy}:48\leadsto97\}.
\]

For each retained edge \(g\), let \(S(g)\) be the roles among
\(A,B,C,D,E\) having a selected witness that contains \(g\).  All 358
retained edges satisfy

\[
A\in S(g)\quad\text{or}\quad BC\subseteq S(g)
\quad\text{or}\quad DE\subseteq S(g).
\tag{1}
\]

Under the priority \(A,BC,DE\), 356 edges are covered by the first clause.
Only

\[
205\,206\quad(S=BCDE),\qquad
224\,225\quad(S=BCE)
\]

need the second clause.  The roles \(D,E\) are nonempty and participate in
the five-role transfer, although no retained edge needs the third clause in
this initial certificate.

Within the stored library, the site contains 6 eligible A-cycles, 2
B-cycles, 8 C-cycles and 21 state-00 cycles.  Exhaustion of all subsets of
the 16 eligible cycles, with the two stored paths fixed, proves that no five
cycles can satisfy (1) while keeping \(A,B,C\) nonempty.  Six cycles suffice,
and exactly twelve minimum subsets exist.  Thus the displayed eight-witness
certificate is minimum relative to the stored 37 cycles and the two fixed
paths; no global minimum over all Hamilton witnesses is asserted.

## Binary-tree consequence

At every generation, expand the newly installed central pair and choose
either reflected orientation independently.  By Note 007, every
positive-depth construction node is edge-Hamiltonian and again satisfies
the robust support hypothesis.  The root is edge-Hamiltonian by its stored
37-cycle edge cover.  Therefore every node at depth \(k\) is an
edge-Hamiltonian Barnette graph of order

\[
240+4k.
\]

There are \(2^k\) orientation histories at depth \(k\), but Note 009 proves
that their resulting unlabelled graphs are all isomorphic.

The full vertex sequences and the five-role support of every retained edge
are stored in
`scratch/worker-barnette/n240-note007-explicit-start-certificate.json`.
The lightweight verifier
`scratch/worker-barnette/verify_n240_note007_start.py` checks the graph hash,
all eight witnesses, all 358 robust support states and the stored-library
minimum; it terminates with `N240_NOTE007_START_VERIFIED`.
