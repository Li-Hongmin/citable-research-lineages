> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An interior three-atom port component has three spanning routes

[Note 282](282-end-ports-with-arbitrarily-many-vacancies-have-three-spanning-routes.md)
constructs the three four-port states when a missing-link
port lies at an end of its alternating atom component.
The smallest interior-port component has two vacancies,
one on each side. It also has all three states: its
outer matching edge supplies the crossed bottom path,
while the two inner matching edges steer the top and
cap paths through the left and right gap rails.

Work in the compressed, gapless, tight-target all-square
opening of Notes 196 and 278. All vacancies lie in
distinct target-free internal face-chord blocks. In one
free group suppose exactly one ordinary link
\(P_s=e_so_{s+1}\) is missing, the component containing
it has precisely the atoms
\[
 V_i<P_s<V_j,\qquad i\le s-1,\quad j\ge s+2,       \tag{1}
\]
and every other part of the noncrossing atom partition
is vacancy-only. The inequalities follow from the
prohibition on matching an old-cycle neighbour. Assume
the two ordinary links attaching the group's full
target-free internal block interval are retained.

**Interior-port theorem.** That full interval has the
same vertex-spanning three-state signature
\[
\begin{array}{ll}
X:&a_a\longleftrightarrow b_b,\quad
   o_a\longleftrightarrow e_b;\\
K:&a_a\longleftrightarrow o_a,\quad
   e_b\longleftrightarrow b_b;\\
S:&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{2}
\]
The number and nesting depth of the other vacancy-only
cycles are unrestricted. The port-adjacent blocks
\(B_s,B_{s+1}\) need not be short: they may contain
vacancies belonging to closed parts in the respective
gaps. If all other free groups have ordinary-endport
spanning routes, the parent has a Hamilton cycle through
both site edges and its legal expanded child is Hamiltonian.

**Proof.** The rainbow rule of Note 278 makes the three
matching edges of the component exactly
\[
 H_iI_j,\qquad I_ie_s,\qquad o_{s+1}H_j.              \tag{3}
\]
Its two proper block gaps are
\[
 L=B_{i+1},\ldots,B_s,\qquad
 R=B_{s+1},\ldots,B_{j-1}.                            \tag{4}
\]
They are nonempty by (1). Noncrossing prevents any other
atom part from having one atom inside one of these gaps
and another outside it. The unique missing link is between
them, so each gap has all ordinary links retained and its
vacancies paired internally. Note 275 therefore gives
\(S,K,X\) for both gaps. Write their crossed paths as
\(X_{\rm top}(L),X_{\rm bottom}(L)\), and similarly for
\(R\). The ordinary boundary links \(e_io_{i+1}\)
and \(e_{j-1}o_j\) are retained, since \(P_s\) is
the only missing link.

First let \(Q=B_i,\ldots,B_j\). Its straight route is
Note 196's ordinary path through these blocks, with the
single missing link replaced by
\[
 e_s,I_i,H_i,I_j,H_j,o_{s+1}.                      \tag{5}
\]
Use \(S(L)\) and \(S(R)\) in place of their ordinary
gap segments. Formula (5) visits the four prime vacancy
slots once and every join is an edge by (3) or the two
old-cycle edges \(H_iI_i,H_jI_j\). Thus it gives \(S(Q)\).

For the cap state, leave \(e_jb_j\) as its right path.
The left path is
\[
\begin{split}
a_i,b_i,e_i,I_i,e_s
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{i+1},a_{i+1}
 \xrightarrow{X_{\rm top}(L)}b_s,a_{s+1}\\
 &\xrightarrow{X_{\rm top}(R)}b_{j-1},a_j,o_j,e_{j-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1},H_j,I_j,H_i,o_i.
\end{split}                                             \tag{6}
\]
Here \(I_ie_s,o_{s+1}H_j,I_jH_i\) are (3),
\(o_je_{j-1}\) is a retained link, and all other
displayed joins outside the gap routes are old-cycle
edges or face chords. The two \(X\) paths of each gap
are disjoint and spanning. Formula (6) uses
\(a_i,b_i,e_i,I_i,H_i,o_i\) in the first vacant block
and \(a_j,o_j,H_j,I_j\) in the last; the right cap
uses the remaining \(e_j,b_j\). Hence these are
disjoint spanning paths with the \(K(Q)\) pairing.

For the crossed state, the bottom path is simply
\[
 o_i,H_i,I_j,e_j.                                   \tag{7}
\]
The top path is
\[
\begin{split}
a_i,b_i,e_i,I_i,e_s
 &\xrightarrow{X_{\rm bottom}(L)^{-1}}o_{i+1},a_{i+1}
 \xrightarrow{X_{\rm top}(L)}b_s,a_{s+1}\\
 &\xrightarrow{X_{\rm top}(R)}b_{j-1},e_{j-1}
 \xrightarrow{X_{\rm bottom}(R)^{-1}}o_{s+1},H_j,o_j,a_j,b_j.
\end{split}                                             \tag{8}
\]
The outer matching edge \(H_iI_j\) is used in (7).
The two inner edges of (3) are used in (8); its
other joins are old-cycle edges, face chords, and the
gap routes. In \(B_i\), (7) uses \(o_i,H_i\) and
(8) uses its other four vertices; in \(B_j\), (7)
uses \(I_j,e_j\) and (8) its other four vertices.
Both gaps are covered by their two \(X\) paths. Thus
(7)--(8) are disjoint spanning paths with the \(X(Q)\)
pairing.

Every remaining vacancy-only part either lies in one
of the gaps already treated, lies in a serial flank,
or surrounds \(Q\). A surrounding part has vacant
endpoint blocks strictly before \(B_i\) and after
\(B_j\), so \(Q\) lies wholly in a proper block gap.
Note 275's prime recursion uses a gap only through its
\(S,K,X\) states, as detailed in Notes 280--281;
its old-cycle arcs remain present when they cross the
one missing matching link. Applying that recursion
from inside out and joining the serial flanks across
retained links gives (2) for the full group interval.
Attach its \(S\) route to Note 196's free path.
Note 273 composes the other groups; Notes 001 and 178
give the legal child and arbitrary original lobe lengths.
\(\square\)

The theorem handles the first port component with the
port strictly inside its atom order. It does not cover
three or more vacancies in such a component, more than
one missing link in the group, or the other excluded
opening shapes of Note 281. It does not settle
Barnette's conjecture.
