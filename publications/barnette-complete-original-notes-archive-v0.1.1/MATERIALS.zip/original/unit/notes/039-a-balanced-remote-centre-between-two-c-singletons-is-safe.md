> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A balanced remote centre between two \(c\)-singletons is safe

[Notes 035--038](035-one-two-and-three-vertex-regions-do-not-obstruct-single-layer-fec-support.md)
reduce the rooted four-vertex single-region problem to a finite list of
plane incidence profiles.  This note settles the first profile not covered
by those reductions.  Its abstract perfect-matching projection admits a
three-state obstruction, but that projection is incompatible with the
orientation of a four-edge cut in the parent cubic bipartite graph.

Use the same setting.  Thus \(F\) is a plane cubic bipartite brace,
\(p=uv\) and \(h=z\alpha\) are an ordered legal cofacial site with \(u,z\)
in the same bipartition class, and

\[
 K=F-\{u,\alpha\}.
\]

In \(F^*\), write \(p^*=cc_p\) and \(h^*=cc_h\).  Let \(s,t,q\) be
three nonroot dual vertices satisfying

\[
 A(s)=A(q)=\{c\},\qquad
 A(t)=\{c_p,c_h\},\qquad
 F^*[\{s,t,q\}]=s-t-q.                              \tag{1}
\]

Write \(d_p,d_h\) for the two retained primal labels dual to
\(c_pt,c_ht\), write \(r,z_0\) for the singleton labels dual to \(cs,cq\),
and write \(x,y\) for the labels dual to \(st,tq\).  Assume that the
remote centre pair is balanced.  Hence every perfect matching \(M\) of
\(K\) has

\[
 \mathbf 1_{d_p\in M}=\mathbf 1_{d_h\in M}
 =:\sigma(M)\in\{0,1\},                                  \tag{2}
\]

and both values of \(\sigma\) occur.

> **Balanced-centre path theorem.**  There is a perfect matching \(M\)
> of \(K\) such that
> \[
>  2\sigma(M)+\mathbf 1_{r\in M}+\mathbf 1_{z_0\in M}
>  +\mathbf 1_{x\in M}+\mathbf 1_{y\in M}\le3.           \tag{3}
> \]

## The only possible obstruction has an exact-two residual cut

The four simple dual cycles

\[
 c-c_p-t-s-c,\quad c-c_h-t-s-c,\quad
 c-c_p-t-q-c,\quad c-c_h-t-q-c                         \tag{4}
\]

give residual three-edge cuts of \(K\).  Since the two centre indicators
in (2) agree, their perfect-matching cut parities have the form

\[
 r+x+\sigma\equiv\varepsilon_s,\qquad
 z_0+y+\sigma\equiv\varepsilon_q\pmod2                 \tag{5}
\]

for fixed \(\varepsilon_s,\varepsilon_q\in\{0,1\}\).  Take a
centre-zero matching.  If either parity in (5) is odd, its corresponding
pair contributes exactly one and the other pair contributes at most two,
which proves (3).  It remains to consider

\[
 \varepsilon_s=\varepsilon_q=0.                          \tag{6}
\]

Suppose for a contradiction that every perfect matching has cost at
least four in (3).  In a centre-zero matching, each of \(r+x\) and
\(z_0+y\) is zero or two.  Their total is at least four, so all four
labels are selected.  In a centre-one matching, (5)--(6) give
\(r+x=z_0+y=1\).  Therefore every perfect matching satisfies

\[
 |M\cap C|=2,
 \qquad C:=\{r,x,d_p\}.                                  \tag{7}
\]

The cycle \(c-c_p-t-s-c\) is dual to the four-edge cut

\[
 \widehat C=\{p,r,x,d_p\}                                \tag{8}
\]

of \(F\).  Choose one of its shores \(R\) and remove from it whichever
of \(u,\alpha\) it contains.  Because \(r,x,d_p\) are retained edges of
\(K\), while \(p\) is the only deleted member of (8), the resulting set
\(S\subseteq V(K)\) satisfies

\[
 \delta_K(S)=C.                                           \tag{9}
\]

## Exact-two intersection forces the residual cut to be directed

The graph \(K\) is 1-extendable and has minimum degree at least two.  In
particular, every edge is both usable and avoidable: to avoid an edge,
extend a different edge at one of its endpoints to a perfect matching.

Orient \(K\) from its \(X\)-colour class to its \(Y\)-colour class.  For
a perfect matching \(M\), let \(o(M)\) and \(i(M)\) be the numbers of
members of \(M\cap C\) leaving and entering \(S\).  Matching balance on
\(S\) gives

\[
 o(M)-i(M)=|S\cap X|-|S\cap Y|,                           \tag{10}
\]

whereas (7) gives \(o(M)+i(M)=2\).  Thus the ordered pair
\((o(M),i(M))\) is independent of \(M\).

It cannot be \((1,1)\).  Indeed, the three cut edges then split into
orientation classes of sizes one and two, and the unique member of the
singleton class would belong to every perfect matching, contrary to
avoidability.  If the pair is \((2,0)\), usability forbids any inward cut
edge; if it is \((0,2)\), usability forbids any outward cut edge.  Hence

\[
 \boxed{\text{all three members of }C\text{ have the same orientation
 relative to }S.}                                        \tag{11}
\]

## A cubic bipartite four-cut cannot contain three parallel edges

For any shore \(T\) of a cut in a cubic bipartite graph, orienting all
edges from \(X\) to \(Y\) gives

\[
 3\bigl(|T\cap X|-|T\cap Y|\bigr)=o_T-i_T,                \tag{12}
\]

because internal edges cancel in the difference of the two degree sums.
For a four-edge cut, \(o_T+i_T=4\), so the right-hand side of (12) lies
in

\[
 \{-4,-2,0,2,4\}.
\]

Divisibility by three forces \(o_T-i_T=0\).  Thus every four-edge cut in
a cubic bipartite graph has orientation split exactly \(2{:}2\).

The three retained members of the parent cut (8) have the same
orientation by (11); restoring \(p\) can only produce a \(4{:}0\) or
\(3{:}1\) split.  This contradicts the \(2{:}2\) conclusion from (12).
Therefore the assumed cost-at-least-four family does not exist, proving
(3).

The same argument gives a reusable form of the mechanism.

> **Residual-three-cut zero lemma.**  Let \(F\) be cubic and bipartite,
> and let \(K\) be a bipartite graph obtained from \(F\) by deleting
> vertices.  Suppose
> \[
>  C=\delta_K(S),\qquad |C|=3,
> \]
> has an even shore, and restoring one deleted parent edge \(e\) gives
> a four-edge cut
> \[
>  C\mathbin{\dot\cup}\{e\}=\delta_F(R),
> \]
> with the three members of \(C\) retained.  If \(K\) is 1-extendable
> and has minimum degree at least two, then some perfect matching of
> \(K\) avoids every edge of \(C\).

Indeed, even cut parity makes every perfect matching meet \(C\) in zero
or two edges.  If no zero state existed, the usability--avoidability
argument above would make all three edges of \(C\) parallel across the
shore, contradicting the \(2{:}2\) orientation of the parent four-cut.

## Consequence and scope

The obstruction is eliminated by the common parent incidence, not by an
alternating-cycle exchange within the centre-zero fibre.  Cut parity
alone admits the projected states

\[
 (00;1111),\qquad(11;0011),\qquad(11;1100),               \tag{13}
\]

all of cost four.  In an actual cubic bipartite parent, however, these
states would make one residual three-cut directed, contradicting the
orientation of its parent four-cut.

The theorem settles exactly profile (1).  It does not yet classify every
path with a larger centre class, and it does not by itself prove the
complete rooted four-vertex region theorem.
