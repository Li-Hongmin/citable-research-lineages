> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A k-block corridor before an alternating triple has exactly k matching types

[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md)
settles three consecutive alternating doubly vacant blocks.
[Note 338](338-standard-short-corridors-before-an-alternating-triple-have-the-square-signature.md)
constructs a standard corridor of arbitrary length, while
[Note 339](339-two-short-blocks-before-an-alternating-triple-have-two-hamilton-matchings.md)
classifies length two. The same local constraints give an exact
classification at every positive length. Every permitted matching
has a spanning free-group route and occurs in a Barnette graph.

Work in the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with even left and odd
right endports \(L,R\). Its only nonshort complete blocks are

\[
\begin{split}
D_1&=(a,o,h,i,k_0,j,e,b),\\
D_2&=(A,O,H,I,K,J,E,B),\\
D_3&=(\hat a,\hat o,\hat h,\hat i,\hat k,\hat j,\hat e,\hat b),
\end{split}                                                     \tag{1}
\]

carrying the internal matching chords \(ok_0=J_1\),
\(IE=J_3\), and \(\hat o\hat k=J_1\). Exactly \(k\ge1\)
short blocks \(S_s=(c_s,o_s,e_s,d_s)\), \(1\le s\le k\), lie between
\(D_1,D_2\), while \(D_2,D_3\) are adjacent. Other complete
blocks, if any, are short and lie outside this core. Put
\(e_0=e\). The subscript on \(k_0\) distinguishes the vertex
of \(D_1\) from the corridor length.

**Corridor classification theorem.** In every Barnette parent
with the stated selected opening, the complementary matching
has the three cross-block chords

\[
                 h\hat i,\qquad iK,\qquad J\hat h,             \tag{2}
\]

and exactly one of the following \(k\) inner patterns:

\[
\begin{array}{c|l}
0&jH,\quad e_{s-1}o_s\ (1\le s\le k),\quad e_kO;\\[2pt]
t\ (1\le t<k)&
je_t,\quad e_{s-1}o_s\ (1\le s\le t),\quad
o_{t+1}H,\quad e_so_{s+1}\ (t+1\le s<k),\quad e_kO.
\end{array}                                                     \tag{3}
\]

All links through the outer short flanks are ordinary and forced.
For every pattern, the entire free group has a vertex-spanning
\(L\)--\(R\) path. The induced \(24+4k\)-vertex four-pole has
exactly the labeled square's complete spanning one-path and
two-path Hamilton signature. Replacing this four-pole by the
square, or conversely, preserves Barnette membership and all
exterior-marked Hamilton decisions. Hence a vertex-minimal
non-Hamiltonian Barnette graph contains none of these four-poles.
For every \(k\ge1\) and every listed pattern,
there is a \(36+4k\)-vertex Barnette parent with a Hamilton cycle
containing both site edges. Consequently, if all other vacancies
occupy distinct internal blocks, the selected parent's legal
site-expanded child is Hamiltonian. Reflection gives the
corresponding result for the order \(J_3,J_1,J_3\), with the
corridor between the final two double blocks.

**Forcing the three enclosing chords.** By the chord-isolation
lemma of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
no other same-block free chord is available. Every cross-block
free chord lies opposite the common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
The residual free slots of the core are, in their old-cycle order,

\[
h,i,j,e,o_1,e_1,\ldots,o_k,e_k,O,H,K,J,
\hat h,\hat i,\hat j,\hat e.                                \tag{4}
\]

Their opposite-side matching is noncrossing. The even slot \(h\)
can meet only \(J\) or \(\hat i\). Its same-block alternatives
are an old-cycle edge or an isolated forbidden chord; its
other odd core candidates enclose an odd number of free slots.
A candidate in either outer short flank, or \(R\), likewise
encloses an odd number: a left short block contributes its
second slot and later pairs, while the core after \(h\)
contributes \(11+2k\) slots to a right candidate.

If \(hJ\) occurred, \(\hat h\) could not meet any slot inside
that chord without crossing it. Its same-block odd candidates
are an old-cycle neighbour and an isolated forbidden chord.
An odd slot in a left flank would enclose that block's second
slot, subsequent flank pairs and \(8+2k\) earlier core slots;
a right-flank odd slot or \(R\) would enclose
\(\hat i,\hat j,\hat e\) plus flank pairs. Both counts are odd.
Thus \(h\hat i\) is forced.

Inside \(h\hat i\), the odd slot \(i\) can meet only \(K\) or
\(\hat h\). The same-block \(ie\) is excluded, and the
candidates \(ie_s,iH\) enclose odd numbers of free slots.
Suppose \(i\hat h\) occurred. The even slot \(K\) could then
meet only \(j,o_s,O,J\) inside that chord. Each \(jK\) and
\(o_sK\) encloses an odd number of free slots, \(OK\) is a
forbidden same-block chord, and \(KJ\) is an old-cycle edge.
Hence \(K\) has no mate. This forces \(iK\); the only two
remaining slots between \(K\) and \(\hat i\) then force
\(J\hat h\). This argument is independent of the outer flanks.

**Classifying the inner matching.** The slots inside \(iK\) are

\[
       j,e,o_1,e_1,\ldots,o_k,e_k,O,H.                        \tag{5}
\]

We use one consequence of three-edge-connectivity: a nonempty
consecutive interval of complete short blocks \(S_r,\ldots,S_s\)
cannot be closed under the complementary matching. If it were,
all its face chords \(c_ud_u\) and other matching edges would
remain inside, so precisely its two boundary old-cycle edges
would leave the interval.

The odd slot \(j\) can meet only \(H\) or one of
\(e_1,\ldots,e_k\); \(je\) is an old-cycle edge. If \(jH\),
the even slot \(e=e_0\) must meet \(o_1\): meeting \(o_s\)
for \(s>1\) closes \(S_1,\ldots,S_{s-1}\), while meeting \(O\)
closes the entire corridor. Repeating the same argument
forces \(e_{s-1}o_s\) for all \(s\) and finally \(e_kO\).
This is pattern 0.

Suppose instead \(je_t\). The noncrossing matching inside
this chord must begin with \(eo_1\), since any later mate
of \(e\) closes a nonempty initial short-block interval.
Inductively it contains \(e_{s-1}o_s\) for \(1\le s\le t\).
If \(t=k\), the remaining \(O,H\) would have to use their
old-cycle edge. Hence \(t<k\). Outside \(je_t\), the first
slot \(o_{t+1}\) cannot use its old-cycle neighbour
\(e_{t+1}\); meeting a later \(e_s\) would close the
complete interval \(S_{t+1},\ldots,S_s\). It must meet \(H\).
The slots inside \(o_{t+1}H\) then force the ordinary links
\(e_so_{s+1}\) for \(t+1\le s<k\), followed by \(e_kO\),
using the same short-interval rule. Thus (3) is complete.

Only the ordinary pair \(\hat j,\hat e\) remains unmatched
inside the core. Starting from \(L\), any link that skips a
complete outer short block would enclose a nonempty interval
of such blocks closed under the matching. A link that skips
the core would enclose the entire core, whose other matching
edges are internal, and possibly some outer short blocks.
Both give a two-edge cut. Induction therefore forces the
ordinary links through the left flank to \(\hat j\), and from
\(\hat e\) through the right flank to \(R\), as in
[Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md).

**A spanning route for every turn.** Pattern 0 has the
\(\hat j\)--\(\hat e\) route of Note 338(9). For
\(1\le t<k\), define \(Q_0\) to be empty and, when \(m\ge1\),
let \(Q_m\) be the sequence

\[
c_1,d_1,c_2,d_2,\ldots,c_m,d_m,
e_m,o_m,e_{m-1},o_{m-1},\ldots,e_1,o_1.                \tag{6}
\]

For \(s\le k\), let \(T_{s,k}\) be

\[
c_s,d_s,c_{s+1},d_{s+1},\ldots,c_k,d_k,A,O,
e_k,o_k,e_{k-1},o_{k-1},\ldots,e_s,o_s.                \tag{7}
\]

The following sequence is a \(\hat j\)--\(\hat e\) path
through all \(24+4k\) vertices of the five-block core:

\[
\begin{split}
\hat j,\hat k,\hat o,\hat h,\hat i,h,i,k_0,o,a,b,
Q_{t-1},e,j,e_t,o_t,c_t,d_t,\\
T_{t+1,k},H,I,K,J,E,B,\hat a,\hat b,\hat e.
\end{split}                                                \tag{8}
\]

When \(t=1\), the join \(b,e\) is an old-cycle edge.
Otherwise \(b,c_1\) is an old-cycle edge and the final
\(o_1,e\) join of \(Q_{t-1},e\) is a matching edge.
The join \(j,e_t\) and the join \(o_{t+1},H\) are exactly
the two turn chords of pattern \(t\). Every \(c_sd_s\)
is a face chord. The joins \(o_s,e_{s-1}\) in the
descending parts of \(Q,T\) are the ordinary matching
links in (3). Every other consecutive pair in (8) is
an old-cycle edge or one of the specified face or matching
chords. The three vertex sets represented by
\(Q_{t-1}\), \(S_t\) and \(T_{t+1,k}\) are disjoint and
together contain all \(k\) short blocks. Thus (8) visits
each core vertex exactly once.

Prepend the ordinary five-vertex short-block routes in the
left flank, and append those in the right flank, sharing
only the indicated endports. This gives a spanning
\(L\)--\(R\) path. Substituting it for the corresponding
free-path segment in Note 324's two-path construction gives
a Hamilton parent cycle through both site edges whenever
the other vacancies occupy distinct internal blocks.
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives the legal child's Hamilton cycle.

**All \(k\) patterns are genuine.** For pattern 0 use the
\(36+4k\)-vertex realization of Note 338. For \(t\ge1\),
start with Note 337(7)'s old Hamilton order, insert the
\(k\) short blocks between \(D_1,D_2\), add their face
chords \(c_sd_s\), and replace its two opposite-side
chords \(jH,eO\) by the pattern-\(t\) chords in (3).
Keep every other chord, including \(w\hat j,\hat e z\)
and the two site chords \(xy,uv\). Each vertex is matched
exactly once to the opposite old-cycle colour; each page
is noncrossing, and the site chords remain cofacial.

Remove the two leaf branches \(AB-jH,AB-eO\) from the
connected interlacement certificate in Note 337(10).
The remaining certificate is connected. All new chords
are attached to it by the two alternating chains

\[
ab,\ je_t,\ (c_sd_s,\ e_{s-1}o_s)_{s=t,t-1,\ldots,1},       \tag{9}
\]

and

\[
AB,\ o_{t+1}H,\
(c_sd_s,\ e_so_{s+1})_{s=t+1,\ldots,k-1},\
c_kd_k,\ e_kO.                                           \tag{10}
\]

Empty middle ranges are omitted. For example,
\(a<j<b<e_t\), \(j<c_t<e_t<d_t\),
\(e_{s-1}<c_s<o_s<d_s\), and
\(c_{s-1}<e_{s-1}<d_{s-1}<o_s\) verify the first
chain. The second follows from
\(o_{t+1}<A<H<B\),
\(c_{t+1}<o_{t+1}<d_{t+1}<H\),
\(c_s<e_s<d_s<o_{s+1}\), and
\(e_s<c_{s+1}<o_{s+1}<d_{s+1}\), ending with
\(c_k<e_k<d_k<O\). Hence the full interlacement
graph is connected. A two-edge cut in a cubic graph
with this old Hamilton cycle would close a proper
old-cycle interval under the matching and disconnect
that graph; a bridge is excluded by the old cycle.
The graph is therefore three-edge-connected and, for
a cubic graph, three-vertex-connected. It has
\(36+4k\) vertices.

Finally join (8) to the two exterior \(x\)--\(v\) paths
of Note 337(11), using \(w\hat j,\hat e z\). This is
an explicit Hamilton cycle through both site chords.
Thus every pattern in (3) is realized, not merely
combinatorially permitted. \(\square\)

**Complete square signature and replacement.** Let \(P_{k,t}\)
be the induced core for pattern \(t\), with its four degree-two
terminals \((a,\hat j,\hat e,\hat b)\) in disk-boundary order.
The two chord pages give a plane disk drawing for every \(t\).
Terminal colours permit precisely the four single-path endpoint
pairs \(a\hat b,a\hat j,\hat j\hat e,\hat e\hat b\).
The full old-cycle core path realizes \(a\hat b\);
Note 338(9) realizes \(\hat j\hat e\) for \(t=0\),
and (8) does so for \(t\ge1\). Each such
\(\hat j\)--\(\hat e\) path ends
\(\hat a,\hat b,\hat e\). Move \(\hat e\) to the start
along the old edge \(\hat e\hat j\), omitting its former
edge \(\hat b\hat e\); this gives the
\(\hat e\)--\(\hat b\) row.

The fourth row, \(a\)--\(\hat j\), is independent of
the inner matching pattern:

\[
\begin{split}
a,o,h,\hat i,\hat k,\hat o,\hat h,J,K,i,k_0,j,e,b,\\
(c_s,o_s,e_s,d_s)_{s=1}^{k},
A,O,H,I,E,B,\hat a,\hat b,\hat e,\hat j .
\end{split}                                                \tag{11}
\]

The chord joins in (11) are \(h\hat i,\hat o\hat k,
J\hat h,iK,IE,\hat a\hat b\); all its other joins
are old-cycle edges. It visits every core vertex once.
For the two-path pairing
\(\{a\hat j,\hat e\hat b\}\), take the old-cycle
path from \(a\) through \(\hat j\) and the edge
\(\hat e\hat b\). For
\(\{a\hat b,\hat j\hat e\}\), delete the edge
\(\hat b\hat e\) from (11). Its two components have
exactly those endpoint pairs and cover the core.
The third pairing interlaces the four terminals in
the disk, so it is impossible. These are exactly the
square's four single-path and two double-path states.
Replacing a spanning path or pair of paths inside the
four-attachment cut by the corresponding square state
preserves the exterior Hamilton cycle in both directions.

For Barnette membership, the labeled square is a planar
minor of \(P_{k,t}\). Contract the interiors of the two
internally disjoint paths
\[
a,b,c_1,d_1,\ldots,c_k,d_k,A,B,\hat a,\hat b
\quad\text{and}\quad
a,o,h,\hat i,\hat k,\hat j
\]
to the square edges \(a'\hat b'\) and \(a'\hat j'\);
retain \(\hat j\hat e,\hat e\hat b\) and delete surplus
edges. Conversely, the disk drawing inserts \(P_{k,t}\)
with the same terminal order and colours.

Deleting any one vertex leaves \(P_{k,t}\) connected.
For a terminal vertex this follows by deleting that
endpoint from one of the spanning single paths above.
If a nonterminal vertex \(v\) were a cut vertex, every
spanning terminal-to-terminal path would put its endpoints
in different components of \(P_{k,t}-v\). A spanning path
also shows that there are at most two such components.
The four single-path endpoint pairs then force the
partition \(\{a,\hat e\},\{\hat j,\hat b\}\).
But the two disjoint spanning paths with pairing
\(\{a\hat j,\hat e\hat b\}\) would both have to
pass through \(v\), a contradiction.

After any two patch vertices are deleted, every surviving
patch component contains a surviving terminal; otherwise
that component would disconnect the three-connected
realization constructed above from its nonempty exterior.
The exterior of a four-pole in any three-connected cubic
host is connected, since two exterior components would
each require at least three of the four attachment edges.
The four-attachment deletion comparison of
[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
now preserves three-connectivity in both replacement
directions. Simplicity, cubicity, bipartiteness and planarity
follow from the distinct terminal attachments, matching
colours and disk embedding. \(\square\)

The theorem classifies this specified corridor position
and the \(J_1,J_3,J_1\) internal-chord order, with arbitrary
outer short flanks. A positive corridor after the middle
block, even with a corridor before it, is excluded by
[Note 341](341-no-short-corridor-after-the-middle-block-of-an-alternating-triple.md).
Other internal-chord types, single vacancies in the same
group, target defects, positive
gaps, non-square residual cycles and the general Barnette
conjecture remain outside this result. The proof is
project-internal; no external priority or independent review
is claimed.
