> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Odd ladders have the single-vacancy four-pole signature

[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
compresses even-column ladders to a square. The same labeled
four-pole question for odd columns has a different parity:
its smallest representative is the three-column ladder,
which appears as a singly vacant face block with an
internal \(oe\) matching chord.

Let \(L_N=P_N\square K_2\), with columns \((t_j,b_j)\),
\(0\le j<N\), and four corner terminals
\(\lambda_t=t_0,\lambda_b=b_0,\rho_t=t_{N-1},
\rho_b=b_{N-1}\).

**Odd-ladder signature theorem.** For every odd \(N\ge3\),
the spanning one-path terminal pairs are exactly
\[
\lambda_t\lambda_b,\quad \rho_t\rho_b,\quad
\lambda_t\rho_b,\quad \lambda_b\rho_t.             \tag{1}
\]
The spanning two-path terminal pairings are exactly
\[
\{\lambda_t\lambda_b,\rho_t\rho_b\},\qquad
\{\lambda_t\rho_t,\lambda_b\rho_b\}.               \tag{2}
\]
Consequently \(L_N\) and \(L_3\) have the same complete
spanning Hamilton linkage signature. Replacing an induced
\(L_N\) with exactly four corner attachments by \(L_3\),
preserving their labels, transfers every exterior Hamilton
cycle in both directions with the same used attachment and
exterior edges. For a simple cubic host with nonempty exterior,
this replacement also preserves membership in the Barnette
class in both directions.

**Proof of the signature.** For odd \(N\), the two top
corners have one bipartite colour and the two bottom corners
the other. A path spanning the even number \(2N\) of
vertices must have opposite-colour endpoints, leaving
exactly (1). The left-rung pair is realized by going from
\(t_0\) along the top rail to \(t_{N-1}\), crossing the
last rung, and returning along the bottom rail to \(b_0\).
Reflection gives the right-rung pair. Write \(N=2k+1\).
For \(\lambda_t\rho_b\), concatenate
\[
(t_{2s},b_{2s},b_{2s+1},t_{2s+1})
\quad(0\le s<k)
\]
by the top-rail edges \(t_{2s+1}t_{2s+2}\), then append
\(t_{2k},b_{2k}\). This visits every vertex once.
Top-bottom reflection gives \(\lambda_b\rho_t\).

The corner order on the ladder disk is
\(\lambda_t,\rho_t,\rho_b,\lambda_b\).
Disjoint spanning paths cannot pair the interlacing corners
\(\lambda_t\rho_b,\lambda_b\rho_t\).
The two rails realize the second pairing in (2).
For the first, take the left rung \(\lambda_t\lambda_b\)
as one path and
\[
t_{N-1},t_{N-2},\ldots,t_1,b_1,b_2,\ldots,b_{N-1}
\]
as the other. This proves the exact signature.

In a global Hamilton cycle, the four-edge patch cut is
used twice or four times. Its intersection with the
ladder is, respectively, one spanning terminal path or
two disjoint spanning terminal paths. The signatures
(1)--(2) replace that intersection while retaining the
exterior paths and their connectivity, proving exact
Hamilton transfer.

**Proof of Barnette preservation.** The four terminal
colours of \(L_N\) and \(L_3\) agree, so bipartiteness
extends across one patch exactly when it extends across
the other. To obtain \(L_3\) as a terminal-preserving
minor of \(L_N\), contract the top vertices
\(t_1,\ldots,t_{N-2}\) to one middle top vertex and the
bottom vertices \(b_1,\ldots,b_{N-2}\) to one middle
bottom vertex, deleting surplus parallel rungs.
Conversely, in a plane drawing of the \(L_3\) replacement,
the connected exterior lies on one side of its perimeter.
Insert the extra pairs of columns in the empty disk on
the other side. Thus planarity holds on either side
exactly when it holds on the other.

If either ambient graph is three-connected, its exterior
after deleting the ladder is connected: two exterior
components would each require at least three of the four
attachments by three-edge-connectivity. In every ladder,
deleting at most one vertex leaves the patch connected,
and after deleting any two vertices each surviving patch
component contains a surviving corner. For an internal
vertex this follows from three internally disjoint routes
to three distinct corners: along its rail in both
directions, and through its rung followed by the other
rail. The deletion comparison of Note 178 applies in
both directions. With at most one patch vertex deleted,
delete the corresponding corner in the other ambient
graph if it is a corner; if it is internal, delete no
patch vertex there. Delete the same exterior vertex,
if any. Three-connectivity shows that every surviving
exterior component attaches at a surviving corner, and
the replacement patch is connected. With two patch vertices
deleted, the exterior is connected and each surviving
patch component attaches to it. Hence deletion of any
two vertices leaves the replacement connected. Simplicity
and cubicity follow from the four distinct labeled
attachments. This proves the Barnette equivalence.
\(\square\)

**Odd rainbow vacancy reduction.** Let a target-free
internal face block of a compressed, gapless, tight-target
all-square opening have \(q=2m+1\ge3\) vacancies and
old-cycle order
\[
a,o,h_1,i_1,\ldots,h_q,i_q,e,b.
\]
Suppose its complementary matching contains
\[
oe,\qquad
h_ti_{q+1-t}\ (1\le t\le m),\qquad
i_th_{q+1-t}\ (1\le t\le m).                    \tag{3}
\]
Then this block induces \(L_{q+2}\) with exactly four
attachments at \(a,b,h_{m+1},i_{m+1}\).
Its columns are
\[
(a,b),(o,e),
(h_1,i_q),(i_1,h_q),\ldots,
(h_m,i_{m+2}),(i_m,h_{m+2}),
(h_{m+1},i_{m+1}).
\]
The rails are the two halves of its old-cycle perimeter,
the first rung is the face chord, the intermediate rungs
are (3), and the last rung is the old-cycle edge
\(h_{m+1}i_{m+1}\). Compress it to \(L_3\).
The reduced old-cycle segment is
\(a',o',h',i',e',b'\), its face chord is \(a'b'\),
and \(o'e'\) is an internal matching edge. Thus the
replacement preserves the selected opening while
reducing \(q\) vacancies to one. Exact marked Hamilton
transfer follows from the theorem above. \(\square\)

If every other multiply vacant block is also a rainbow
ladder reducible by Note 325 or this odd reduction, and
all remaining vacant blocks are distinct internal blocks,
the presence of an odd rainbow block is impossible.
Indeed, compress all such blocks. The resulting Barnette
opening has only distinct-block vacancies but retains
an \(o'e'\) complementary matching chord in a target-free
singly vacant block. The local ordinary-chord exclusion
of Notes 276, 320, and 322 forbids this: its vacancy
mate either forces another such chord and a two-edge cut,
or reaches a terminal fragment where parity fails.
In particular, an odd rainbow block cannot occur as
the only multiply vacant block under these opening
hypotheses. An odd rainbow block alongside a nonrainbow
multiply vacant block is not excluded by this argument.

This is an exact four-pole reduction, not a solution of
Barnette's conjecture. It does not classify other
same-block matching patterns or openings with site-block
vacancies, positive gaps, defective target order, or
nonsquare residual cycles. No external priority claim
or independent proof review is made.
