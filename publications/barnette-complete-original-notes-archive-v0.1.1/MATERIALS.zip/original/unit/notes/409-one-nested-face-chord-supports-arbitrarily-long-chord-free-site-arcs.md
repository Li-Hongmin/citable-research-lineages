> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One nested face chord supports arbitrarily long chord-free site arcs

[Note 406](406-a-long-gap-single-hexagon-forces-a-main-face-side-chord.md) proves that a single trapped hexagon and a long opposite site gap force an additional main matching chord on the common-face side. [Note 407](407-a-nested-site-chord-keeps-a-long-opposite-face-arc-chord-free.md) places that chord inside a site cap, leaving a three-edge opposite facial arc entirely on the old Hamilton cycle. The same one-chord pattern exists for every odd opposite-arc length at least three. Thus no increasing number of face-side main chords is forced by the arc length. This improves the cube-expanded family of [Note 408](408-cube-expansions-give-unbounded-chord-free-opposite-face-arcs.md), which adds one such chord whenever it lengthens the arc by two.

Fix an integer \(m\ge1\), and put
\[
 s=4m+10,\qquad k=2m+4.
\]
Take the \(4m+16\)-vertex cycle
\[
 C_m=(w_0,w_1,\ldots,w_{s-1},\alpha,a,b,c,d,\beta,w_0)
\]
and add the perfect matching
\[
\begin{aligned}
 M_m={}&\{q=w_0w_3,\ p=w_kw_{s-1},\ h=w_{k+1}w_{s-4},\ \alpha\beta,\\
 &w_1d,\ w_2c,\ w_{s-3}b,\ w_{s-2}a\}\\
 &\cup\{w_{4+i}w_{s-5-i}:0\le i<2m\}.
\end{aligned}                                               \tag{1}
\]
The site is \(q,p\), and \(h\) is its sole additional face-side main chord.

**One-chord unbounded-gap theorem.** The graph \(G_m=C_m\cup M_m\) is Barnette. The site edges \(q,p\) share a face with residual arcs of lengths three and \(2m+1\). The shorter arc is \(w_{s-1},\alpha,\beta,w_0\) and traps exactly the chord-free residual hexagon \(\alpha a b c d\beta\alpha\); the longer arc is
\[
                    w_3,w_4,\ldots,w_k,                \tag{2}
\]
whose every edge belongs to \(C_m\). The only main matching chord on the common-face side besides \(p,q\) is \(h\), strictly nested in \(p\) and absent from (2). Moreover, \(G_m\) has a Hamilton cycle through both \(p,q\), so every legal square expansion at this site is Hamiltonian.

**Graph and embedding certificates.** The matching in (1) uses every vertex once: its main-segment endpoints are the four site ports, the two ends of \(h\), four escape targets, and the disjoint pairs
\[
 \{w_4,\ldots,w_{k-1}\}
 \longleftrightarrow
 \{w_{k+2},\ldots,w_{s-5}\}.
\]
Each of these last sets has \(2m\) vertices. The indexed pair in (1) has odd index difference \(4m+1-2i\ge3\); all other matching edges also join opposite colours and avoid edges of \(C_m\). Hence the graph is simple, cubic and bipartite.

Draw \(q,p,h,\alpha\beta\) on the common-face side of \(C_m\). They do not cross: \(h\) is nested within \(p\), while \(q\) and \(\alpha\beta\) occupy disjoint boundary intervals. On the other side, draw the four escape chords in the nested order
\[
 w_1d\supset w_2c\supset w_{s-3}b\supset w_{s-2}a.
\]
The \(2m\) chords \(w_{4+i}w_{s-5-i}\) are nested, all lie inside \(w_2c\), and have both endpoints before \(w_{s-3}\); they do not cross any escape chord. This gives a plane embedding. Its common face between \(q,p\) has exactly the two arcs stated above: \(h\) only cuts the cap within \(p\). The selected three-edge arc contains the single face-side matching edge \(\alpha\beta\), so the literal opening of [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md) traps precisely the old segment \(\alpha,a,b,c,d,\beta\), closed by \(\alpha\beta\). There is no internal hexagon matching chord \(ad\).

The matching-chord interlacement graph is connected. The chord \(q\) interlaces \(w_1d,w_2c\); \(\alpha\beta\) interlaces all four escape chords; \(p\) interlaces \(w_{s-3}b,w_{s-2}a\) and every indexed chord in (1); and \(h\) interlaces every indexed chord. All matching chords therefore belong to one interlacement component. A bridge is impossible because \(C_m\) is Hamiltonian. Any two-edge cut in a cubic graph with Hamilton cycle would delimit a proper old-cycle interval closed under the matching, splitting this interlacement graph. Thus \(G_m\) is three-edge-connected and, being cubic, three-vertex-connected. This completes the Barnette certificate.

**Marked Hamilton certificate.** Write
\[
 L_i=w_{4+i},\qquad R_i=w_{k+2+i}\quad(0\le i<2m),
\]
and abbreviate
\[
 A=w_k,\quad B=w_{k+1},\quad D=w_{s-4},\quad
 E=w_{s-3},\quad F=w_{s-2},\quad P=w_{s-1}.
\]
Define a path \(T_m\) as follows. Start at \(R_{2m-1}\). For \(j=0,1,\ldots,m-1\), append
\[
        L_{2j},\ L_{2j+1},\ R_{2m-2-2j},
\]
and, unless \(j=m-1\), append \(R_{2m-3-2j}\) before the next iteration. Thus
\[
 T_1=(R_1,L_0,L_1,R_0),\qquad
 T_2=(R_3,L_0,L_1,R_2,R_1,L_2,L_3,R_0).
\]
The indexed matching sends \(L_i\) to \(R_{2m-1-i}\). Consequently every step of \(T_m\) is either one such matching edge or an old-cycle edge joining consecutive \(L\)'s or consecutive \(R\)'s. The path lists all \(L_i,R_i\) exactly once and ends at \(R_0\). Insert its full vertex list to obtain
\[
 H_m=(w_0,w_3,w_2,w_1,d,c,b,E,D,
             T_m,B,A,P,F,a,\alpha,\beta,w_0)             \tag{3}
\]
This is a Hamilton cycle: \(D R_{2m-1}\), \(R_0B\), \(BA\), and \(PF\) are old-cycle edges, while \(bE\), \(AP=p\), \(Fa\), \(\alpha\beta\), \(w_1d\), and \(w_0w_3=q\) are matching edges. Every vertex occurs once. The site-expanded child is Hamiltonian by the direct-lift clause of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md). \(\square\)

Combining this construction with the universal lower bound of Note 406 gives the exact extremal value: among Barnette parents with the stated single trapped chord-free hexagon and an all-old-cycle opposite facial arc of any fixed odd length \(2m+1\ge3\), the minimum number of additional common-face-side main matching chords is **one**.

**Exact ladder reduction.** The \(4m\) vertices \(L_i,R_i\) induce an even four-terminal ladder. Set \(t_i=L_i\) and \(b_i=R_{2m-1-i}\) for \(0\le i<2m\). The old-cycle edges give the two rails \(t_it_{i+1},b_ib_{i+1}\), and the indexed matching edges in (1) are exactly the rungs \(t_ib_i\). Only the four end vertices meet the exterior:
\[
 w_3L_0,\qquad A L_{2m-1},\qquad B R_0,\qquad D R_{2m-1}.
\]
Compress this induced \(L_{2m}=P_{2m}\square K_2\) to its four-vertex square by [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md). Relabel the resulting old-cycle main segment as
\[
 (w_0,w_1,w_2,w_3,L_0,L_{2m-1},A,B,R_0,R_{2m-1},D,E,F,P),
\]
using the displayed symbols now for the four square corners. Under
\[
 (L_0,L_{2m-1},A,B,R_0,R_{2m-1},D,E,F,P)
 \longmapsto (w_4,w_5,w_6,w_7,w_8,w_9,w_{10},w_{11},w_{12},w_{13}),
\]
the compressed graph is exactly Note 407: its two rungs become \(w_4w_9,w_5w_8\), while \(q,p,h\), the escape edges and \(\alpha\beta\) keep their labels. Note 178 preserves Barnette membership, every exterior edge and attachment-edge Hamilton mark, and Hamiltonicity in both directions. In particular the site edges \(p,q\), both exterior to the ladder, retain their joint marked status.

The legal site expansion also leaves the ladder and its four attachments untouched. Compressing the ladder before or after that expansion gives the same labelled child of Note 407; Note 178 therefore preserves child Hamiltonicity as well. Hence every \(G_m\), and every specified site-expanded child, reduces exactly to the \(m=1\) case. Note 408 then makes the latter a cube expansion of the fourteen-vertex Note 404 graph. This explains why the unbounded one-chord extremal family creates no new irreducible candidate for a Barnette counterexample. \(\square\)

The reduction preserves more than the marked cycles used here. For any induced even four-terminal ladder whose four site endpoints lie outside it, replacing the ladder by a square preserves each of the six witness clauses of Note 001 separately. In a spanning Hamilton cycle, spanning Hamilton path, or spanning two-path linkage with all prescribed endpoints outside the ladder, the used attachment count is two or four. With two, the ladder contributes one spanning terminal path; with four, it contributes two disjoint spanning terminal paths. Note 178 gives exactly the same available terminal pairs and pairings in the ladder and square. Replacing one routing by the other leaves the exterior linkage and its site-endpoint pairing unchanged. In particular, \((G_m,p,q)\) and the decorated Note 407 graph have identical six-witness existence vectors, including the excluded pairing in clause 6. This statement does not identify individual internal ladder edges.

Together with Note 408, this gives a simultaneous normal form for a hypothetical least-order legal-site failure: its Barnette parent has neither a compatible inverse cube expansion nor an induced even four-terminal ladder disjoint from the four site endpoints whose square compression retains a legal site. Either reduction would preserve all six witness absences and produce a smaller failing parent. The statement is a necessary condition on a counterexample, not an existence or Hamiltonicity theorem for the remaining class.

For \(m=1\), (1) and (3) are exactly the graph and marked witness of Note 407. For larger \(m\), the opposite arc grows without adding another face-side main chord; the graph order is \(4m+16\), compared with \(6m+14\) in Note 408 at the same arc length. These graphs are Hamiltonian and do not refute Barnette's conjecture. No external priority claim is made.
