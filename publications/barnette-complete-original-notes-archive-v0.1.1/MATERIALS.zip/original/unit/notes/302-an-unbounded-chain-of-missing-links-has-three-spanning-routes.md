> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An unbounded chain of missing links has three spanning routes

[Note 287](287-a-surrounding-vacancy-component-and-end-port-have-three-spanning-routes.md)
routes one end port inside a vacancy-only surrounding component.
[Note 301](301-a-second-end-port-after-the-first-ports-final-vacancy-has-three-routes.md)
attaches a second end port immediately after the first component's
last vacancy. Its right covering path has exactly the same two
boundary terminals as the edge it replaces. Repeating that
replacement absorbs arbitrarily many missing ordinary links.

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent. Vacancies lie in distinct target-free internal
face-chord blocks. Fix one free group with retained ordinary end
links. Its noncrossing atom partition has a vacancy-only component
\[
 \mathcal C:\quad V_s=V_{c_1}<V_{c_2}=V_w<
 V_{c_3}<\cdots<V_{c_h}=V_z,\qquad h\ge2,             \tag{1}
\]
where the middle list is empty if \(h=2\). Inside its first
proper atom gap lie \(k\ge1\) end-port components in the order
\[
 \mathcal P_i:\quad
 P_{u_{i-1}}<V_{a_{i,1}}<\cdots<
 V_{a_{i,p_i}}=V_{u_i},
 \qquad 1\le i\le k,\quad u_0=s,\quad p_i\ge1,
                                                               \tag{2}
\]
with
\[
 a_{i,1}\ge u_{i-1}+2,\qquad
 u_i\ge u_{i-1}+2,\qquad u_k<w.                    \tag{3}
\]
The only missing ordinary links are
\(P_{u_0},\ldots,P_{u_{k-1}}\). Thus the last vacancy
\(V_{u_i}\) of one port component is immediately followed
in atom order by the next port \(P_{u_i}\). Every other
component is vacancy-only; its size and nesting depth are
unrestricted.

**Port-chain theorem.** The interval \(Q=B_s,\ldots,B_z\)
has all three vertex-spanning four-port states
\[
\begin{array}{ll}
S(Q):&o_s\longleftrightarrow e_z,\\
K(Q):&a_s\longleftrightarrow o_s,\quad
       e_z\longleftrightarrow b_z,\\
X(Q):&a_s\longleftrightarrow b_z,\quad
       o_s\longleftrightarrow e_z.
\end{array}                                                   \tag{4}
\]
The number \(k\), every \(p_i\), \(h\), all proper gap
lengths, and the number of additional nested vacancy-only
components are unbounded. Surrounding and serial vacancy-only
parts preserve the signature of the full free group. If every
other free group has a spanning ordinary-endport route, the
parent has a Hamilton cycle through both site edges and its
legal site-expanded child is Hamiltonian. Reflection gives the
opposite orientation. The cases \(k=1,2\) recover Notes 287
and 301.

**Matching and covering pieces.** By Note 278's rainbow
rule, \(\mathcal C\) has edges
\[
 H_sI_z,\quad I_sH_w,\quad
 I_{c_j}H_{c_{j+1}}\ (2\le j<h),                   \tag{5}
\]
while \(\mathcal P_i\) has edges
\[
 e_{u_{i-1}}I_{u_i},\quad
 o_{u_{i-1}+1}H_{a_{i,1}},\quad
 I_{a_{i,j}}H_{a_{i,j+1}}\ (1\le j<p_i).           \tag{6}
\]
Every other ordinary link in \(Q\) is retained. Noncrossing
confines all additional atoms in the proper gaps of the port
components and in the gaps of \(\mathcal C\) after \(V_w\)
to vacancy-only components closed in those gaps. The first
gap of \(\mathcal C\) contains the whole port chain and
will be routed explicitly. The first gap after each port
is nonempty by (3); every nonempty closed vacancy-only gap
has Note 275's \(S,K,X\) signature.

For each \(i\), use the right continuation
\[
 T_i:b_{u_{i-1}}\leadsto b_{u_i}                 \tag{7}
\]
of Note 286(6)--(8). It spans
\(B_{u_{i-1}+1},\ldots,B_{u_i}\) except
\(I_{u_i},e_{u_i}\). That construction uses the source
block only at \(b_{u_{i-1}}\), even though it is vacant
in \(\mathcal C\) for \(i=1\) and in
\(\mathcal P_{i-1}\) for \(i>1\).
Also use Note 287(5)'s first-port path
\[
 L_1:a_{s+1}\leadsto e_s,                       \tag{8}
\]
which spans \(B_{s+1},\ldots,B_{u_1}\) except
\(e_{u_1},b_{u_1}\). Its construction ends before
the second missing link and remains valid for all \(k\).

Define a two-terminal cap \(R_i:e_{u_i}\leadsto b_{u_i}\).
Its first case is the old-cycle edge
\[
                R_1=e_{u_1}b_{u_1}.             \tag{9}
\]
For \(i\ge2\), set
\[
 R_i:\quad
 e_{u_i},I_{u_i},e_{u_{i-1}}
 \xrightarrow{R_{i-1}}b_{u_{i-1}}
 \xrightarrow{T_i}b_{u_i}.                     \tag{10}
\]
The first join is an old-cycle edge; the next is the
matching edge \(I_{u_i}e_{u_{i-1}}\) from (6).
Inductively, \(R_i\) covers precisely the two vertices
\(e_{u_1},b_{u_1}\) and all vertices of
\(B_{u_1+1},\ldots,B_{u_i}\), once each.
Indeed, \(T_i\) adds the new blocks except
\(I_{u_i},e_{u_i}\), and the prefix of (10) supplies
those two vertices. The prefix meets \(R_{i-1}\) at
\(e_{u_{i-1}}\), and \(R_{i-1}\) meets \(T_i\) at
\(b_{u_{i-1}}\); their remaining vertices are disjoint.
This is the repeated cap substitution.

Let \(J=B_{u_k+1},\ldots,B_{w-1}\), possibly empty. If
nonempty, its elementary crossed rails have endpoints
\[
 X_{\rm top}(J):a_{u_k+1}\leadsto b_{w-1},
 \qquad
 X_{\rm bottom}(J):o_{u_k+1}\leadsto e_{w-1}.
                                                               \tag{11}
\]
All its internal ordinary links are retained; the rails
use only old-cycle edges, face chords, and these links.
With \(J\ne\varnothing\), define
\[
\begin{split}
 R:\quad e_{w-1}
 &\xrightarrow{X_{\rm bottom}(J)^{-1}}o_{u_k+1},
 e_{u_k}\xrightarrow{R_k}b_{u_k},a_{u_k+1}
 \xrightarrow{X_{\rm top}(J)}b_{w-1}.
\end{split}                                                   \tag{12}
\]
For \(J=\varnothing\), set \(R=R_k\).
The joins \(o_{u_k+1}e_{u_k}\) and
\(b_{u_k}a_{u_k+1}\) are respectively a retained
ordinary link and an old-cycle edge. Thus
\(R:e_{w-1}\leadsto b_{w-1}\) covers exactly the
two vertices omitted by \(L_1\) and all blocks
\(B_{u_1+1},\ldots,B_{w-1}\).

**Straight route.** Let \(\Omega_C:e_s\leadsto o_w\)
be Note 287(7)'s reverse alternating walk along (5):
\[
 e_s,I_s,H_s,(I_{c_j},H_{c_j})_{j=h,h-1,\ldots,2},o_w.
                                                               \tag{13}
\]
It covers every vacancy slot of \(\mathcal C\) once.
Then
\[
 o_s,a_s,b_s,a_{s+1}
 \xrightarrow{L_1}e_s
 \xrightarrow{\Omega_C}o_w,e_{w-1}
 \xrightarrow{R}b_{w-1},a_w
 \xrightarrow{\text{ordinary continuation}}e_z       \tag{14}
\]
is a path. The last continuation takes each displayed
\(\mathcal C\) block's face chord and \(S\) in its
later closed gaps, skipping the \(\mathcal C\) vacancy
slots in (13). More explicitly, \(L_1\) covers the first
port region except \(e_{u_1},b_{u_1}\); \(R\) covers exactly
that pair and the blocks from \(B_{u_1+1}\) through
\(B_{w-1}\). The initial segment covers \(o_s,a_s,b_s\),
its join into (13) covers \(e_s\), and (13) covers
\(H_s,I_s\) and all later \(\mathcal C\) vacancy slots.
The ordinary continuation covers the remaining vertices
of \(B_w,\ldots,B_z\). These sets are disjoint away from
their named path joins and exhaust \(Q\).
This proves \(S(Q)\).

**Cap route.** Leave \(e_zb_z\) as the right cap path.
Let \(Z_J:b_{u_k}\leadsto e_{u_k}\) traverse both
crossed rails of \(J\) and the vertices \(a_w,o_w\):
\[
\begin{split}
b_{u_k},a_{u_k+1}
 &\xrightarrow{X_{\rm top}(J)}b_{w-1},
 a_w,o_w,e_{w-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}
 o_{u_k+1},e_{u_k}                                   \tag{15}
\end{split}
\]
when \(J\ne\varnothing\), and
\(Z_J=b_{u_k},a_w,o_w,e_{u_k}\) when
\(J=\varnothing\). The two joins at the left of
\(J\) and the join \(o_we_{w-1}\) are retained
ordinary or old-cycle edges.

From \(e_{u_k}\) follow the reverse port chain
\[
 \Theta^-:\quad
 e_{u_k},I_{u_k},e_{u_{k-1}},I_{u_{k-1}},
 \ldots,e_{u_1},I_{u_1},e_s .                     \tag{16}
\]
Each \(e_{u_i}I_{u_i}\) is an old-cycle edge;
each \(I_{u_i}e_{u_{i-1}}\) is in (6).
The other cap path is
\[
 a_s,b_s
 \xrightarrow{T_1}b_{u_1}
 \xrightarrow{T_2}\cdots
 \xrightarrow{T_k}b_{u_k}
 \xrightarrow{Z_J}e_{u_k}
 \xrightarrow{\Theta^-}e_s,I_s,H_w
 \xrightarrow{C\text{ forward}}I_z,H_s,o_s .       \tag{17}
\]
The joins \(I_sH_w,I_zH_s\) are in (5).
The paths \(T_i\) span each port region except
\(I_{u_i},e_{u_i}\); (16) supplies every omitted pair.
The fold (15) spans \(J\) and \(a_w,o_w\).
The old-cycle arc from \(H_w\) to \(I_z\) spans
all later blocks and stops before \(e_z,b_z\).
The initial and final pieces cover the other four
vertices of \(B_s\). Hence (17) and \(e_zb_z\)
are disjoint and spanning, proving \(K(Q)\).

**Crossed route.** All ordinary links inside
\(W=B_{u_k+1},\ldots,B_z\) are retained.
Its elementary \(X\) rails are available regardless
of its vacancy matching. Take the top and bottom paths
\[
\begin{array}{ll}
a_s,b_s
 \xrightarrow{T_1}b_{u_1}
 \xrightarrow{T_2}\cdots
 \xrightarrow{T_k}b_{u_k}
 \xrightarrow{X_{\rm top}(W)}b_z,\\[2pt]
o_s,H_s,I_s,e_s,
 (I_{u_i},e_{u_i})_{i=1,\ldots,k}
 \xrightarrow{X_{\rm bottom}(W)}e_z .
\end{array}                                                   \tag{18}
\]
The bottom path alternates the matching edges
\(e_{u_{i-1}}I_{u_i}\) with the old-cycle
edges \(I_{u_i}e_{u_i}\); the first and final
attachments to \(W\) are also old-cycle or
retained ordinary edges. The \(T_i\) cover all
port regions except those bottom-path pairs.
The two rails span \(W\) disjointly. Thus (18)
covers \(Q\) once with the crossed endpoint pairing.

Any remaining vacancy-only component lies inside a
proper gap already used above, surrounds \(Q\) in a
proper block gap, or is serially disjoint. Note 275's
prime and serial composition gives the full free-group
signature. Note 273 joins groups; Notes 001 and 178
give the marked parent cycle, legal child cycle, and
arbitrary original lobe lengths. \(\square\)

**Analytic realization for every chain length.** Fix
\(k\ge1\), \(h\ge2\), and \(p_1,\ldots,p_k\ge1\).
Use Note 281(8)'s old cycle with \(\ell=1\) and
\[
\begin{split}
u_0&=s=1,&
a_{i,j}&=u_{i-1}+j+1\quad(1\le j\le p_i),&
u_i&=u_{i-1}+p_i+1,\\
w&=u_k+1,&z&=w+h-2,&r&=z.
\end{split}                                                   \tag{19}
\]
Make \(B_1\), all \(B_{a_{i,j}}\), and
\(B_w,\ldots,B_z\) vacant. The \(k\) blocks
\(B_{u_{i-1}+1}\) are short, and these are the
only short internal blocks. Retain every ordinary
free link except \(P_{u_0},\ldots,P_{u_{k-1}}\);
add (5)--(6) and leave the site, face, escape,
and residual-square matching edges of Note 281
unchanged.

The matching pairs every free slot exactly once
and joins opposite old-cycle colours. Draw the
outer edge \(H_1I_z\) around all free chords and
\(I_1H_w\) around the port chain. Each port's
outer edge \(e_{u_{i-1}}I_{u_i}\) surrounds its
own inner successive vacancy edges; different
port intervals are disjoint. Retained ordinary
links are nested in or disjoint from these chords.
Thus the two-page drawing is planar and the site
edges remain cofacial.

For every \(i\), retained links join the face
chords of \(B_{u_{i-1}+1},\ldots,B_{u_i}\);
the edge \(e_{u_{i-1}}I_{u_i}\) attaches this
chain to the preceding source block. Starting
at \(B_1\), these connections join all internal
face chords. Every other edge in (5)--(6)
interlaces an endpoint face chord. The retained
end links attach the unchanged site and
residual-square closing chain. Hence the full
matching-chord interlacement graph is connected;
Notes 217 and 182 give three-vertex connectivity.
With \(P=\sum_{i=1}^{k}p_i\), there are
\(r=h+P+k\) internal blocks, \(h+P\) of them vacant,
and 12 fixed outer vertices. The parent therefore has
\(12+4r+2(h+P)\) vertices; its legal Hamiltonian child
has four more. Their orders are
\[
             6(h+P)+4k+12,\qquad
             6(h+P)+4k+16.                        \tag{20}
\]
For \(k=1\) this is Note 287's family, and
\(k=2\) is Note 301's three-parameter family.

The theorem allows an unbounded number of interacting
missing links in one free group, but requires their
specific end-port chain inside a surrounding vacancy
component. It does not settle arbitrary multiport
groups, other opening shapes, or Barnette's conjecture.
