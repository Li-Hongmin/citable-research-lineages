> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The direct \(P\)-regime target is a rotation-pairing and three-matroid common-base problem

Let \(F\) be a plane cubic bipartite brace with global \(H^{+-}\). Let
\(p=uv\) and \(h=za\) be distinct disjoint cofacial edges, oriented so
that \(u,z\) are in the same bipartition class. Put

\[
J=F-\{p,h\}.
\]

The question here is only whether \(J\) has a Hamilton \(v\)-\(z\) path.
No claim about compatible bridges, the \(K\)-regime, or full
\(C_4\)-preservation is made.

## A componentwise refinement of terminal parity

Fix the endpoint \(v\). Define the augmented Pósa graph
\(\mathscr R_v(J)\) as follows.

* Its vertices are all Hamilton \(v\)-\(x\) paths in \(J\), for arbitrary
  \(x\ne v\).
* If \(xy\notin P\), where \(x\) is the moving endpoint and \(y\) is
  internal on \(P\), perform the usual Pósa rotation: add \(xy\) and delete
  the edge at \(y\) on the \(x\)-to-\(y\) segment.
* If \(xv\in E(J)\setminus E(P)\), close \(P+xv\) to a Hamilton cycle and
  delete the other cycle edge at \(v\). This is the unique
  endpoint-closing transition which still fixes \(v\).

The last operation is essential: omitting it can artificially isolate a
valid target whose endpoints are adjacent.

Every unused edge at the moving endpoint gives exactly one reversible
transition. Hence the degree of a path ending at \(x\) is

\[
\deg_{\mathscr R_v(J)}(P)=\deg_J(x)-1.
\tag{1}
\]

The degree-two vertices of \(J\) are exactly \(u,v,z,a\). Since \(v\) is
fixed and \(v,a\) have the same bipartite colour, a Hamilton path fixed at
\(v\) cannot end at \(a\). Thus the degree-one vertices of
\(\mathscr R_v(J)\) are exactly the Hamilton \(u\)-\(v\) source paths and
the Hamilton \(v\)-\(z\) target paths. All other vertices have degree two.

Every component of \(\mathscr R_v(J)\) is therefore a path or a cycle. A
path component has endpoint type

\[
UU,\qquad UZ,\qquad ZZ,
\tag{2}
\]

where \(U\) denotes a source and \(Z\) a target. If their numbers are
\(r_{UU},r_{UZ},r_{ZZ}\), then

\[
H_{uv}=2r_{UU}+r_{UZ},\qquad
H_{vz}=2r_{ZZ}+r_{UZ}.
\tag{3}
\]

This strictly refines the scalar Smith--Thomason congruence
\(H_{uv}\equiv H_{vz}\pmod2\) in Note 023.

> **Rotation-pairing obstruction.** If the direct \(P\)-regime target is
> absent, every Hamilton \(u\)-\(v\) source path is paired with a distinct
> source path at the other end of a \(UU\) component. Reversing the roles
> gives the analogous fixed-\(z\) pairing of all Hamilton \(z\)-\(a\)
> source paths.

Thus a counterexample must realise two simultaneous componentwise source
pairings; global evenness alone is not the full obstruction. Conversely,
one mixed \(UZ\) component is an explicit target certificate.

The degree argument does not prohibit a disjoint union of \(UU\) paths and
degree-two cycles. Hence abstract rotation rules plus source nonemptiness
do not prove the target theorem. The unresolved realizability question is
whether the complete Hamilton family of one plane cubic bipartite brace
with global \(H^{+-}\) can realise both source-pairing obstructions while
having no \(ZZ\) or \(UZ\) component.

## Fixed instances distinguish the mechanisms

The order-\(16\) brace

    OlCGHD@?g?_@@@A?_?k?P

already separates ordinary rotations from the augmented graph.

At the unique-target orientation

\[
(u,v,z,a)=(15,14,13,4),
\]

the path counts are

\[
(H_{uv},H_{za},H_{vz},H_{ua})=(3,3,1,3).
\tag{4}
\]

Ordinary fixed-endpoint rotations from either complete source family reach
no target. Even unrestricted ordinary rotations of both endpoints miss
the unique target. After adding the endpoint-closing transition, the
fixed-\(v\) source components have profiles

\[
(|C|,\#U,\#Z)=(6,1,1),\quad(8,2,0).
\tag{5}
\]

At the all-even orientation of Note 023,

\[
(u,v,z,a)=(0,15,4,13),
\]

the counts are

\[
(H_{uv},H_{za},H_{vz},H_{ua})=(4,2,2,4),
\tag{6}
\]

and the fixed-\(v\) profiles are

\[
(3,1,1),\quad(5,1,1),\quad(6,2,0).
\tag{7}
\]

Thus the component refinement detects targets even when global parity is
silent. Equations (5)--(7) are fixed-object diagnostics, not evidence for
a universal component theorem beyond (1)--(3).

## Exact three-matroid formulation

Let the bipartition be \(X\sqcup Y\), with \(u,z\in X\) and
\(v,a\in Y\), and write \(|X|=|Y|=m\). Set

\[
K=F-\{u,a\}.
\]

Let \(\mathsf T=F^*\). The dual edges \(p^*,h^*\) share the vertex of their
common face and form a two-edge forest. Contract them and restrict to the
duals of \(E(K)\):

\[
Q=(\mathsf T/\{p^*,h^*\})[E(K)^*].
\tag{8}
\]

This graph is connected. Before contraction the excluded primal edges are

\[
(\delta_F(u)\setminus\{p\})\cup
(\delta_F(a)\setminus\{h\}).
\tag{9}
\]

They form two two-edge stars if \(u,a\) are nonadjacent, or one path if
they are adjacent, and therefore contain no primal cycle. Planar
cycle--bond duality makes the retained dual graph connected. Since \(F\)
has \(2m\) vertices, \(Q\) has \(m\) vertices and graphic rank \(m-1\).

On ground set \(E(K)\), let

* \(\mathcal P_X\) be the partition matroid allowing at most one selected
  edge at each vertex of \(X\setminus\{u\}\);
* \(\mathcal P_Y\) be the analogous partition matroid for
  \(Y\setminus\{a\}\); and
* \(\mathcal G_Q\) be the graphic matroid of \(Q\).

All three have rank \(m-1\). A cardinality-\((m-1)\) set \(M\subseteq
E(K)\) is a common base of \(\mathcal P_X,\mathcal P_Y\) exactly when it is
a perfect matching of \(K\). It is a base of \(\mathcal G_Q\) exactly when
\((M\cup\{p,h\})^*\) is a spanning tree of \(\mathsf T\). Tree--cotree
duality and cubicity give

\[
\boxed{
J\text{ has a Hamilton }v\text{-}z\text{ path}
\iff
\mathcal B(\mathcal P_X)\cap
\mathcal B(\mathcal P_Y)\cap
\mathcal B(\mathcal G_Q)\ne\varnothing.}
\tag{10}
\]

Global \(H^{+-}\) and the brace hypothesis force every **pairwise**
intersection of these three base families to be nonempty.

In fact the first pair has substantially more than one common base.  The
global \(H^{+-}\) hypothesis excludes the four-cycle brace, and every other
brace is 2-extendable.  Equivalently, for every nonempty
\(S\subseteq X\) with \(|S|\le m-2\),

\[
|N_F(S)|\ge |S|+2.
\]

For every nonempty proper \(S\subseteq X\setminus\{u\}\), deleting \(a\)
therefore gives

\[
|N_K(S)|\ge |N_F(S)|-1\ge |S|+1.
\]

The strict Hall characterization of 1-extendable bipartite graphs shows
that \(K=F-\{u,a\}\) is itself 1-extendable.  Thus every edge of \(K\)
belongs to a common \(\mathcal P_X\)-\(\mathcal P_Y\) base; in particular,

\[
\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal P_Y)\ne\varnothing.
\tag{11}
\]

This strengthening still does not settle the triple intersection: the
four-element abstract countermodel below has underlying row--column graph
\(K_{2,2}\), which is already 1-extendable.

Because \(K\) is a plane elementary bipartite graph, its complete perfect-
matching family is connected by alternating face flips and carries the
usual distributive matching lattice after an outer face is fixed.  Hence
the remaining obstruction is not Hall feasibility, matching coverage, or
ordinary exchange connectivity.  It is exactly whether that connected
matching family intersects the graphic-base family of \(Q\).  The fixed
example in Note 024 shows that the intersection need not occur at either
lattice extreme and may require simultaneous flips on disjoint cycles.

For the other two pairs, use the source trees of Note 022. A Hamilton cycle
containing \(h\) and avoiding \(p\) has complement matching \(M_h\), and

\[
B_h=M_h\cup\{h\}
\]

is a dual spanning tree containing \(p,h\). After contracting \(p^*,h^*\),
the tree \(B_h\setminus\{p,h\}\) selects exactly one primal edge at every
vertex of \(X\setminus\{u\}\). Its only edge outside \(E(K)\) is the edge
\(ax\in M_h\) matching the deleted vertex \(a\), for some
\(x\in X\setminus\{u\}\).

The three dual edges incident with the primal cubic vertex \(x\) form a
triangle. Delete \((ax)^*\) from the tree. Of the other two sides of this
dual triangle, at least one crosses the resulting fundamental cut.
Replacing \((ax)^*\) by that side restores a spanning tree, preserves the
same \(X\)-colour \(x\), and uses only \(E(K)^*\). Therefore

\[
\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal G_Q)\ne\varnothing.
\tag{12}
\]

The Hamilton cycle containing \(p\) and avoiding \(h\) gives the reflected
argument at the unique matching edge incident with the deleted vertex
\(u\), and hence

\[
\mathcal B(\mathcal P_Y)\cap\mathcal B(\mathcal G_Q)\ne\varnothing.
\tag{13}
\]

Thus the unresolved target assertion is a genuine three-way Helly
question:

\[
\boxed{
\text{all three pairwise common-base families are nonempty;}
\quad
\text{must the triple common-base family be nonempty?}}
\tag{14}
\]

Pairwise nonemptiness has a four-element abstract countermodel even with
two partition matroids and one graphic matroid. On

\[
E=\{e_{11},e_{12},e_{21},e_{22}\},
\]

let \(\mathcal P_X\) have row classes
\(\{e_{11},e_{12}\},\{e_{21},e_{22}\}\), and let \(\mathcal P_Y\) have
column classes
\(\{e_{11},e_{21}\},\{e_{12},e_{22}\}\). Let \(Q_0\) be a three-vertex
path with \(e_{11},e_{22}\) parallel on its first link and
\(e_{12},e_{21}\) parallel on its second link.

Then \(\{e_{11},e_{21}\}\) is a common \(\mathcal P_X\)-graphic base and
\(\{e_{11},e_{12}\}\) is a common \(\mathcal P_Y\)-graphic base. The two
common bases of \(\mathcal P_X,\mathcal P_Y\) are

\[
\{e_{11},e_{22}\},\qquad \{e_{12},e_{21}\},
\]

and both are parallel pairs in \(Q_0\). Hence the triple intersection is
empty. This is not a brace/site counterexample: \(Q_0\) is not asserted to
come from the contracted dual of a common plane cubic incidence system,
and it carries no global Hamilton family. It strictly rules out invoking a
generic three-matroid Helly principle.

This is sharper than matching existence or dual-tree existence separately:
each pairwise compatibility is automatic, but the target requires one edge
set to satisfy both orthogonal vertex partitions and the graphic constraint
at once. It is a special three-matroid common-base problem. Notes 022--024
already show that generic load \(M\)-convexity, pairwise source rerouting,
lattice extrema and one-cycle descent do not supply the triple intersection.

## Decision boundary

No real graph/site counterexample to the direct \(P\)-regime target was
obtained, and the argument above is not a proof of target existence. The
strict remaining assertion is

\[
\boxed{
\begin{gathered}
F\text{ plane cubic bipartite brace with global }H^{+-},\\
p=uv,\ h=za\text{ a legal cofacial }P\text{-orientation}
\end{gathered}
\Longrightarrow
\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal P_Y)
\cap\mathcal B(\mathcal G_Q)\ne\varnothing.}
\tag{15}
\]

In rotation language, an empty intersection forces both source families
to be paired in \(UU\)- and \(AA\)-components and forbids every target leaf,
including a possible source-free \(ZZ\) component. Source pairing alone is
only a necessary failure condition, since targets could occur in a
source-free component. A positive proof of (15) must use the shared
primal/dual incidence coupling the three matroids; a real counterexample
must exhibit an empty intersection while independently retaining
exhaustive global \(H^{+-}\). The order-\(26\) critical-surgery brace has
twelve common bases at its displayed site, so it does not distinguish
(15).

The fixed-instance counts are independently reproduced by:

    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_direct_p_regime_target_boundary.py

Terminal marker:

    DIRECT_P_REGIME_FIXED_ENDPOINT_ROTATION_BOUNDARY_VERIFIED
