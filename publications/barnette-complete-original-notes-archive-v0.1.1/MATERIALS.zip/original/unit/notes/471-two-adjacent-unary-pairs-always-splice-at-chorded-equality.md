> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two adjacent unary pairs always splice at chorded equality

[Note 470](470-one-four-special-leaf-always-supplies-the-chorded-four-port-cover.md) leaves, at the chorded \(c=5f-7\) equality boundary, one ordinary root with two marked unary nodes, each assigned two special positions. The case in which both directly assigned pairs are old-cycle adjacent is Hamiltonian. Its terminal-free arc, which defeats leaf switches alone, is absorbed by the ordinary wrapper square of one marked node.

Use the one-root chorded order and exterior paths (2) of [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md). Thus the root word \(W\) has four terminals
\[
                         T=\{r_L,u,v,r_R\},\qquad r_L<u<v<r_R,
\tag{1}
\]
and either of two distinct exterior terminal pairings closes any spanning internal two-path cover to a Hamilton cycle through the site edges \(p,q\).

Suppose \(c=5f-7\) and the remaining equality profile of Note 470 holds. Every assigned position outside the two direct pairs lies in a two-special ordinary leaf. Each marked unary node receives exactly two directly assigned special positions, and within each node those positions are consecutive on the old cycle. Denote their disjoint old edges by
\[
                         d_1=s_1t_1,\qquad d_2=s_2t_2,
                         \qquad s_1<t_1<s_2<t_2 .
\tag{2}
\]
The two nodes themselves may be nested or disjoint. Let \(C_W\) be the old \(W\)-arc closed by its root chord. Deleting \(d_1,d_2\) divides \(C_W\) into the linear arc \(A=t_1\rightsquigarrow s_2\) and the complementary arc \(B=t_2\rightsquigarrow s_1\), which uses the root chord. Let \(E\) be the square-supported old edge in each two-special leaf, and let \(M\) match all special positions of \(W\) except \(T\) by their face-side chords.

The equality profile of [Note 469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md) has \(A_0=2f-3\) marked-or-branching nodes and \(Q=f-2\) two-special leaves. Thus \(c=5f-7=3A_0-Q\) is equality in the charge of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md). Every marked nonleaf node therefore has two consecutive plain-unary ancestors in its incoming chain. In particular, the immediate parent chord of either marked unary node is not the root chord of \(C_W\).

**Two-adjacent-pair theorem.** Under these equality conditions, the parent has a Hamilton cycle containing \(p,q\), and its legal expanded child is Hamiltonian. The two marked unary nodes may be nested or disjoint.

**Proof.** Put
\[
                         F=(C_W-E-\{d_1,d_2\})\cup M .
\tag{3}
\]
Every nonterminal has degree two and each terminal has degree one. Hence \(F\) consists of exactly two paths and some cycles. A leaf-square switch of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) merges any two different components joined by an edge of \(E\), without changing the terminals or any edge of \(M\). All these switches have disjoint supports.

If an \(M\)-edge joins \(A,B\), then \(F\cup E=(C_W-\{d_1,d_2\})\cup M\) is connected. Contract the components of \(F\) and represent the edges of \(E\) in the quotient. It is connected. Delete one edge on a quotient spanning-tree path between the two path components, and perform the square switches on the two resulting rooted trees. Every cycle is absorbed into one of the terminal paths, leaving a spanning internal two-path cover.

Now suppose no \(M\)-edge joins \(A,B\). Every two-special leaf lies wholly in one arc: its two special positions are consecutive, while the only arc boundaries are the two directly assigned edges \(d_1,d_2\). Thus \(A\) contains \(t_1,s_2\) and an even number of other special positions. Its nonterminal special positions are paired internally by \(M\), so the number \(k=|T\cap A|\) is even. If \(k=2\), each arc of \(F\) has one terminal path and perhaps cycles. Within either arc, restoring its edges of \(E\) gives the connected old arc plus internal \(M\)-edges. Its leaf-square switches absorb all its cycles into its path. The two resulting paths cover \(W\).

It remains to exclude \(k=4\). All terminals then lie on \(A\), and their order \(r_L<u<v<r_R\) puts \(u\) strictly between \(t_1\) and \(s_2\), even if an extreme terminal is an endpoint of \(A\). Let \(P\) be the set of special positions before \(s_1\), and \(S\) those after \(t_2\). Both consist of complete two-special leaves, so \(|P|\) and \(|S|\) are even. Since no \(M\)-edge joins \(A,B\), a mate of any position in \(P\cup\{s_1\}\) outside this set would lie at \(t_2\) or in \(S\). Such a face chord \(xy\) has \(w_0<x<u<y\) and would cross the site chord \(q=w_0u\). Hence \(P\cup\{s_1\}\) is closed under the perfect matching \(M\), although it has odd cardinality \(|P|+1\), a contradiction. Therefore \(k\ne4\).

Finally let \(k=0\). Within \(A\), \(F\) consists only of cycles; restoring its leaf edges \(E\) gives the connected old arc \(A\) together with internal \(M\)-edges. Square switches therefore merge it into one cycle \(Z\). Within \(B\), the same argument merges every cycle into one of its two terminal paths. These switches do not touch old edges between consecutive ordinary-chord endpoints.

Choose one of the two marked unary nodes whose ordinary interval contains exactly one of \(d_1,d_2\). Such a node exists because ordinary intervals are laminar: choose either node if they are disjoint, and the inner node if they are nested. Write its core chord as \(hj\) and the chord of its immediate plain-unary parent as \(HJ\). The left endpoints \(H,h\) and the right endpoints \(j,J\) are consecutive on the old cycle. Because \([h,j]\) contains one deleted edge \(d_i\) but not the other, one of \(h,j\) lies in \(A\) and the other in \(B\). The same holds for \(H,h\) together and \(j,J\) together, since the boundaries \(d_1,d_2\) have special, not ordinary, endpoints. Thus the two old rail edges \(Hh,jJ\) lie respectively in \(A\) and \(B\).

Both rail edges are still present after the leaf switches: their four ordinary endpoints belong to nonleaf chord nodes and to no leaf-square support. The chords \(HJ,hj\) are unused; \(HJ\) is not the root chord because its node has another plain-unary ancestor. Replace
\[
                              Hh,\ jJ\quad\longmapsto\quad HJ,\ hj .
\tag{4}
\]
This square switch joins the sole cycle \(Z\) of \(A\) to one of the terminal paths of \(B\), preserving its two endpoints. The other terminal path remains disjoint. Hence the result is a spanning two-path cover of \(W\).

In every case, choose one of the two exterior pairings of Note 460 different from the internal pairing. Their union is a parent Hamilton cycle containing \(p,q\), and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

Consequently, a non-Hamiltonian chorded child at \(c=5f-7\) must have at least one of its two marked unary nodes with its directly assigned pair split across the child word. This is a necessary condition within the selected single-hexagon opening, not a general Barnette decision.
