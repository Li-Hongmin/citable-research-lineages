> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both end ports of a two-sided shared-vacancy component have three routes

[Note 297](297-an-unbounded-end-port-inside-a-two-sided-shared-vacancy-component-has-three-routes.md)
allows arbitrarily many vacancies in the left port component while the
right port component has one vacancy. The right component can grow
independently. Its straight route follows the alternating component
backwards, whereas its crossed route follows the old Hamilton cycle
through all but its last vacancy and folds across just the last gap.

Use the compressed, gapless, tight-target all-square opening and block
notation of [Notes 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md),
[278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md),
and [294](294-arbitrary-closed-gaps-around-a-two-sided-shared-vacancy-have-three-routes.md).
Vacancies lie in distinct target-free internal face-chord blocks. Fix a
free group with retained ordinary end links. Let \(p,q\ge1\), and choose
\[
 i<j_1<\cdots<j_p\le s-1<m=s+1,
 \qquad m+2\le u_1<\cdots<u_q<w.                    \tag{1}
\]
Put \(Q=B_i,\ldots,B_w\). The distinguished vacant blocks are
\(B_i,B_{j_1},\ldots,B_{j_p},B_m,B_{u_1},\ldots,B_{u_q},B_w\);
\(B_s\) is short. The only missing ordinary links in the group are
\(P_s=e_so_m\) and \(P_m=e_mo_{m+1}\). The three distinguished
alternating atom components are
\[
 \{V_i,V_m,V_w\},\qquad
 \{V_{j_1},\ldots,V_{j_p},P_s\},\qquad
 \{P_m,V_{u_1},\ldots,V_{u_q}\}.                 \tag{2}
\]
Their complementary-matching edges are
\[
\begin{array}{ll}
 H_iI_w,\ I_iH_m,\ I_mH_w;&\\
 H_{j_1}o_m,\ I_{j_t}H_{j_{t+1}}\ (1\le t<p),\
 I_{j_p}e_s;&\\
 e_mI_{u_q},\ o_{m+1}H_{u_1},\
 I_{u_t}H_{u_{t+1}}\ (1\le t<q).&
\end{array}                                           \tag{3}
\]
All other ordinary links are retained. Noncrossing puts every other
component meeting \(Q\) wholly in a proper gap between consecutive
distinguished atoms. These components are vacancy-only. Each nonempty
gap is closed under its matching and has Note 275's spanning straight
path \(S(G)\) and disjoint crossed rails
\[
 T(G):a_{\min G}\longleftrightarrow b_{\max G},\qquad
 D(G):o_{\min G}\longleftrightarrow e_{\max G}.        \tag{4}
\]

**Two unbounded port components theorem.** The interval \(Q\) has
three vertex-spanning routes
\[
\begin{array}{ll}
 S(Q):&o_i\longleftrightarrow e_w,\\
 K(Q):&a_i\longleftrightarrow o_i,\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_i\longleftrightarrow b_w,\quad
       o_i\longleftrightarrow e_w.
\end{array}                                           \tag{5}
\]
Both \(p\) and \(q\), the distances between the displayed blocks,
and the nesting depths of vacancy-only components in the closed gaps
are unbounded. Surrounding or serially disjoint vacancy-only parts
compose with this signature. If every other free group has its usual
ordinary-endport spanning route, the parent has a Hamilton cycle
through both site edges and its legal expanded child is Hamiltonian.

**Proof.** We use the left folds \(F(a,b):b_a\leadsto e_a\), the
terminal fold \(T_s:o_s\leadsto a_s\), the port chain
\(\Lambda:H_{j_1}\leadsto e_s\), and its cap variant
\(\Lambda_K:a_{j_1}\leadsto e_s\) from Note 297(6)--(8).
Their explicit edge lists show that \(F(i,j_1)\) covers the first
gap; \(\Lambda\) covers each left-port vacant block and every gap
between them; and \(T_s\) covers the terminal gap before \(B_s\).
All these pieces use only old-cycle edges, face chords, edges of
(3), retained ordinary links, and the two rails in (4).

For the right straight continuation, follow the alternating component
from the left end of the missing link to its other end:
\[
 J_q:\quad e_m,(I_{u_t},H_{u_t})_{t=q,q-1,\ldots,1},
 o_{m+1}.                                           \tag{6}
\]
The parenthesized pairs are concatenated in decreasing index order.
Every consecutive pair in (6) is either a matching edge of (3) or the old-cycle edge
\(H_{u_t}I_{u_t}\). From \(o_{m+1}\), take \(S(G(m,u_1))\), then
the retained link to \(o_{u_1}\). For \(t=1,\ldots,q\), traverse
\[
 o_{u_t},a_{u_t},b_{u_t},e_{u_t},                 \tag{7}
\]
using a face chord in the middle. Between (7) for consecutive
vacancies, take the direct retained link if the gap is empty;
otherwise take the retained link into the gap, \(S\) of that gap,
and the retained link out. After \(e_{u_q}\), proceed the same way
through \(G(u_q,w)\) to \(o_w,a_w,b_w,e_w\). Call the resulting
path \(R_S:e_m\leadsto e_w\). It uses all right-component vacancy
slots in (6) and every other right-side vertex in (4) and (7),
each exactly once. The first gap \(G(m,u_1)\) is nonempty because
\(u_1\ge m+2\).

The full straight route is
\[
 o_i,a_i,F(i,j_1),I_i,H_i,I_w,H_w,I_m,H_m,o_m,
 \Lambda,T_s,b_s,a_m,b_m,R_S.                       \tag{8}
\]
Here \(a_ib_i\) enters the first fold, \(o_mH_{j_1}\) enters
\(\Lambda\), \(e_so_s\) enters \(T_s\), and \(b_me_m\) enters
\(R_S\). All are edges of the stated types. The pieces have
disjoint interiors and partition \(Q\), proving \(S(Q)\).

For \(K(Q)\), keep \(e_wb_w\) as the right cap. Use precisely the
left path of Note 297(14)--(15): start at \(a_i,b_i\), take the
top rail of \(G(i,j_1)\) to \(a_{j_1}\), then
\[
 \Lambda_K,T_s,b_s,a_m,o_m,H_{j_1},o_{j_1},       \tag{9}
\]
take the bottom rail of \(G(i,j_1)\) backwards to \(e_i\),
and finish
\[
 e_i,I_i,H_m\xrightarrow{C\text{ forward}}I_w,H_i,o_i.
                                                               \tag{10}
\]
An empty first gap uses the direct joins \(b_i a_{j_1}\) and
\(o_{j_1}e_i\). The first left-port block's \(a,b,e,I\) slots
are on \(\Lambda_K\), while its \(H,o\) slots occur after
\(o_m\); all later left-port blocks are wholly on \(\Lambda_K\).
The old-cycle arc from \(H_m\) to \(I_w\) uses every vertex on
the right, including all \(q\) right-port vacancies, and never
uses either missing ordinary link. It omits exactly \(e_w,b_w\),
which form the cap. Thus (9)--(10) span \(Q\) with the pairing
in (5), for every \(q\).

For the crossed right continuation, first let \(W=G(u_q,w)\)
and define \(W_X:o_w\leadsto b_w\) by
\[
 W_X=\begin{cases}
 o_w,a_w,b_w,&W=\varnothing,\\
 o_w,e_{w-1}\xrightarrow{D(W)^{-1}}o_{u_q+1},
 a_{u_q+1}\xrightarrow{T(W)}b_{w-1},a_w,b_w,
 &W\ne\varnothing.
 \end{cases}                                           \tag{11}
\]
The boundary links in the second row are retained. For \(q=1\),
put \(u=u_1\), \(R=G(m,u)\), and take Note 297's fold
\[
\begin{split}
 R_X^{(1)}:\quad b_m,a_{m+1}&\xrightarrow{T(R)}b_{u-1},
 e_{u-1}\xrightarrow{D(R)^{-1}}o_{m+1},H_u,o_u,a_u,b_u,\\
 &e_u,I_u,e_m,I_m,H_w,W_X.
\end{split}                                             \tag{12}
\]
The nonempty \(R\) makes both rails available.

For \(q\ge2\), put \(v=u_{q-1}\), \(u=u_q\), and
\(G=G(v,u)\). Define a final-gap fold \(Z(v,u):o_u\leadsto b_u\):
\[
 Z(v,u)=\begin{cases}
 o_u,e_v,b_v,a_u,b_u,&u=v+1,\\
 o_u,e_{u-1}\xrightarrow{D(G)^{-1}}o_{v+1},e_v,b_v,
 a_{v+1}\xrightarrow{T(G)}b_{u-1},a_u,b_u,
 &u\ge v+2.
 \end{cases}                                           \tag{13}
\]
Every join in (13) is an old-cycle edge, a face chord,
or a retained ordinary link. Its two rails cover \(G\) once.
Now set
\[
 R_X^{(q)}:\quad
 b_m\xrightarrow{C\text{ forward}}I_v,H_u,
 Z(v,u),e_u,I_u,e_m,I_m,H_w,W_X.                    \tag{14}
\]
The join \(I_vH_u\) and the join \(I_u e_m\) are the two
right-component matching edges in (3); \(I_mH_w\) is the
outer-component edge. The old-cycle arc from \(b_m\) to \(I_v\)
covers \(B_{m+1},\ldots,B_{v-1}\) completely and covers
\(a_v,o_v,H_v,I_v\) in \(B_v\). Fold (13) covers
\(e_v,b_v\), the last proper gap, and \(o_u,a_u,b_u\).
The passage \(b_u,e_u,I_u\) completes \(B_u\). Thus (14)
covers every vertex from the right of \(B_m\) through
\(B_w\), except \(I_w,e_w\); it covers \(e_m,I_m\) of
\(B_m\) and starts at its \(b_m\). The same assertion for
(12) follows from its two disjoint rails and (11).

Take the crossed bottom path
\[
 o_i,H_i,I_w,e_w,                                  \tag{15}
\]
and the top path
\[
 a_i,F(i,j_1),I_i,H_m,o_m,\Lambda,T_s,b_s,
 a_m,b_m,R_X^{(q)}.                                 \tag{16}
\]
The first fold starts at \(b_i\) after the face chord
\(a_ib_i\); \(\Lambda\) starts at \(H_{j_1}\) after the
matching edge \(o_mH_{j_1}\); \(T_s\) starts at \(o_s\)
after \(e_so_s\). The left pieces have the same disjoint
coverage as in Note 297. The right coverage just proved leaves
exactly the two rightmost bottom-path vertices \(I_w,e_w\);
the left pieces leave exactly \(o_i,H_i\). Hence (15)--(16)
are disjoint and span \(Q\), with the crossed pairing in (5).

The three constructions use a proper gap only through its
\(S,X\) signature and retained boundary links. Note 275's
prime and serial compositions therefore absorb surrounding or
serially disjoint vacancy-only parts. Note 273 joins the free
groups, and Notes 001 and 178 give the marked parent Hamilton
cycle, legal child cycle, and arbitrary original lobe lengths.
\(\square\)

**Two-parameter analytic realization.** For every \(p,q\ge1\),
take the old cycle and unchanged site, face, escape, and
residual-square edges of Note 281(8)--(9). Use exactly
\(p+q+3\) vacant internal blocks, retain all ordinary links
except \(P_s,P_m\), and add (3). A shortest choice is
\[
 i=1,\quad j_t=t+1,\quad s=p+2,\quad m=p+3,
 \quad u_t=p+4+t,\quad w=r=p+q+5.                  \tag{17}
\]
Each block has even order. The pairs in (3) join opposite
old-cycle colours and, with the unchanged edges, form a
perfect matching. On the side opposite the site face,
\(H_iI_w\) surrounds all free chords;
\(I_iH_m\) surrounds the left-port component;
\(I_mH_w\) surrounds the right-port component.
Within the left component, \(H_{j_1}o_m\) surrounds its
pairwise disjoint consecutive-vacancy edges and \(I_{j_p}e_s\).
Within the right component, \(e_mI_{u_q}\) surrounds the
pairwise disjoint edges \(o_{m+1}H_{u_1}\) and
\(I_{u_t}H_{u_{t+1}}\). All retained ordinary links are
nested in or disjoint from these intervals. This is a
crossing-free two-page drawing with cofacial site edges.

For three-connectivity, retained links connect consecutive
face chords along the left chain through \(B_s\) and the
right chain from \(B_{m+1}\) through \(B_w\).
The chord \(H_{j_1}o_m\) interlaces the face chords of
\(B_{j_1}\) and \(B_m\), joining the left chain to the
shared block. The chord \(I_mH_w\) interlaces the face
chords of \(B_m\) and \(B_w\), joining that block to the
right chain. Every other special chord interlaces a face
chord at one of its endpoint blocks. The unchanged site,
escape, and residual-square edges complete Note 281's
interlacement chain. Thus the matching-chord interlacement
graph is connected. Note 217's interval-cut argument gives
three-edge-connectivity; the cubic lemma of Note 182 gives
three-vertex-connectivity. The site expansion is legal by
the same cut projection used in Note 217.

In (17), the parent and child have, respectively,
\[
 6(p+q)+38,\qquad 6(p+q)+42                  \tag{18}
\]
vertices and are Hamiltonian by (5). Inserting \(d\)
additional short blocks into proper gaps adds \(4d\) vertices
to each order and leaves the routing and connectivity proofs
unchanged. At \(q=1\), this specializes to Note 297; at
\(p=q=1\), it specializes to Note 294's five-vacancy pattern.

The theorem settles simultaneous unbounded growth of the two
end-port components under the stated opening hypotheses. It
does not classify a longer vacancy-only component through the
shared block, additional ports, target-bearing or repeated
vacancies, positive gaps, nonsquare residual cycles, or general
Barnette graphs.
