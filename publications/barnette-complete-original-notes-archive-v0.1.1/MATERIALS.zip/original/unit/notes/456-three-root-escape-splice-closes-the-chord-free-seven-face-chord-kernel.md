> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A three-root escape splice closes the chord-free seven-face-chord kernel

[Note 455](455-chord-free-seven-face-chord-failures-have-three-roots-and-eight-leaves.md) reduces a hypothetical non-Hamiltonian chord-free single-hexagon opening with \(f=7\) to three ordinary root words, eight special leaves, and at most one short node. The four escape edges and the trap chord \(\alpha\beta\) give two useful cycle/path decompositions. The leaf switches of [Note 454](454-one-missing-leaf-switch-gives-two-four-port-pairings.md) close both possible face-chord connectivity types.

Use Note 455's order
\[
 C=(w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0),
\tag{1}
\]
where the four escape edges are \(t_dd,t_cc,t_bb,t_aa\), the trap matching chord is \(\alpha\beta\), and the site edges are \(q=w_0u,p=vw_*\) with \(u<v\) in the main order. The eight leaves across the three roots have consecutive special positions \(x_i,y_i\); their old-cycle edges are \(e_i=x_iy_i\). The site ports \(u,v\) are two of these sixteen positions and may belong to the same leaf. Let \(M\) be the seven face-side matching chords on the other fourteen special positions. Put a vertex at each root word \(W_i\), and join two vertices when a chord of \(M\) has one endpoint in each; call this the *root face graph* \(K\).

**Three-root splice theorem.** Every legal expanded child in Note 455's three-root normal form is Hamiltonian. More strongly, its reduced parent has a Hamilton cycle containing both site edges \(p,q\), whether or not \(K\) is connected.

**Connected root face graph.** Suppose \(K\) is connected. The following are three vertex-disjoint cycles:
\[
\begin{aligned}
C_1&=(W_{1,\ell}\xrightarrow{\mathrm{old}}W_{1,r},t_c,c,d,t_d,W_{1,\ell}),\\
C_2&=(W_{2,\ell}\xrightarrow{\mathrm{old}}W_{2,r},W_{2,\ell}),\\
C_3&=(W_{3,\ell}\xrightarrow{\mathrm{old}}W_{3,r},t_a,a,b,t_b,W_{3,\ell}).
\end{aligned}
\tag{2}
\]
In \(C_2\) the closing edge is the outer ordinary chord of \(W_2\); in \(C_1,C_3\) the non-old closing routes use the listed escape edges and the old trap edges \(cd,ab\). Their union covers all vertices of the parent except \(w_0,w_*,\alpha,\beta\).

Delete all eight \(e_i\) from (2), then add \(M\). The resulting spanning subgraph \(F_0\) has degree one precisely at \(u,v\) and degree two elsewhere, so it has one \(u\)--\(v\) path and some disjoint cycles. Contract its components and represent each removed \(e_i\) by an edge, allowing loops; call this multigraph \(Q\). Because \(K\) is connected, \(C_1\cup C_2\cup C_3\cup M\) is connected, hence \(Q\) is connected. Every vertex of \(Q\) has even degree: it is the image of the disjoint union of the three cycles (2) after contracting edges of \(F_0\). Thus \(Q\) has no bridge.

At every full leaf whose outer ordinary chord is not already used in (2), the switch (3) of Note 454 joins two distinct \(F_0\) components whenever its removed edge \(e_i\) joins their vertices in \(Q\). At most one leaf is short. There is one further apparent exception: if \(W_2\) itself consists of a single full leaf, its outer ordinary chord already closes \(C_2\). But then \(C_2-e_i\) connects that leaf's \(x_i,y_i\) inside \(F_0\), so \(e_i\) is a loop of \(Q\) and is never needed to connect components. Delete this loop and the possible short-leaf edge from \(Q\). The remaining switch graph is connected, since loop deletion has no effect and no nonloop edge of the connected even-degree graph \(Q\) is a bridge. Choose a spanning tree rooted at the unique path component. Perform its leaf switches outward from the root. Every step absorbs one cycle into that path, leaving a spanning \(u\)--\(v\) path over all vertices of (2).

The outside path
\[
                    (u,w_0,\beta,\alpha,w_*,v)
\tag{3}
\]
uses \(q,\alpha\beta,p\) and the two old boundary edges, and covers the four omitted vertices. Joining it to the spanning path gives a parent Hamilton cycle containing \(p,q\).

**Disconnected root face graph.** Suppose \(K\) is disconnected. Each root word has an even number of vertices. Its edge cut has the two old-cycle boundary edges, plus its incident crossing face chords and any site edges ending inside it; every ordinary chord is internal. Cubicity makes the cut even, and three-connectivity makes it at least four. An isolated vertex of \(K\) therefore contains both site ports \(u,v\). There is only one such root; the other two have no site port, so each needs at least two face chords leaving it, necessarily to the other nonisolated root.

The isolated root cannot be \(W_2\). If both site ports were in \(W_2\), every chord from \(W_1\) to \(W_3\) would interlace the site chord \(q=w_0u\) on the common-face page, contradicting planarity. Hence the isolated site root is \(W_1\) or \(W_3\). All its non-site leaf specials are matched by face chords internal to that root. If it has at least two leaves, no leaf's outer chord is the root chord: the two-terminal variant of Note 454, applied to the root cycle after cutting its leaf edges and adding its internal face chords, gives a spanning \(u\)--\(v\) path. If it is a single leaf, its two special positions are precisely \(u,v\); deleting their old edge from the root cycle directly gives such a path, whether the leaf is full or short.

If the isolated root is \(W_1\), close that path through \(q,p\) and the following spanning \(w_0\)--\(w_*\) path outside \(W_1\):
\[
 w_0,t_d,d,\beta,\alpha,a,b,c,t_c,
 W_{2,\ell}\xrightarrow{\mathrm{old}}W_{2,r},t_b,
 W_{3,\ell}\xrightarrow{\mathrm{old}}W_{3,r},t_a,w_*.
\tag{4}
\]
If the isolated root is \(W_3\), use instead
\[
 w_0,t_d,W_{1,\ell}\xrightarrow{\mathrm{old}}W_{1,r},t_c,
 W_{2,\ell}\xrightarrow{\mathrm{old}}W_{2,r},t_b,
 b,c,d,\beta,\alpha,a,t_a,w_*.
\tag{5}
\]
Each displayed transition is an old-cycle edge, one of the escape edges, or \(\alpha\beta\). The paths visit every vertex outside the isolated root once. In either case, adjoining \(w_0u\), the internal \(u\)--\(v\) path, and \(vw_*\) gives a parent Hamilton cycle containing \(p,q\). This proves the theorem. \(\square\)

**Uniform three-root form.** The proof uses neither the number eight nor the particular ordinary branch tree. For any chord-free single-hexagon parent with the order (1), if all assignable special positions occur as consecutive pairs in leaves, every leaf has the full six-vertex word except possibly one short four-vertex leaf, and the three root words have their outer ordinary chords, then the parent has a Hamilton cycle containing both site edges. The same connected/disconnected argument applies with the full face matching on the non-site leaf positions.

**Single-hexagon seven-chord corollary.** Every legal expansion with a selected single-hexagon opening and at most seven additional common-face-side main chords is Hamiltonian. [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) handles \(f\le6\); [Note 454](454-one-missing-leaf-switch-gives-two-four-port-pairings.md) handles the chorded \(f=7\) branch; Note 455 and the theorem above handle the chord-free \(f=7\) branch. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts each marked parent cycle, while [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) reverses the ladder reductions. The result does not cover \(f\ge8\), multiple trapped cycles, other selected openings, or Barnette's conjecture in general.
