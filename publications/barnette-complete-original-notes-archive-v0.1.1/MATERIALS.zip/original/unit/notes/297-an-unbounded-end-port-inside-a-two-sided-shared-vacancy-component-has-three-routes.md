> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An unbounded end port inside a two-sided shared-vacancy component has three routes

Note 296 settles six vacancies when the extra atom joins a port
component. The same folding route works for arbitrarily many
vacancies in that component: each vacancy block is traversed
from its \(H\) slot through its ordinary slots to its \(I\)
slot, while the closed gap to the next vacancy is covered by
the two crossed rails. The first port vacancy has a separate
entry in the cap state, but all later blocks use the same route.

Use the compressed, gapless, tight-target all-square opening
and block notation of Notes 275, 278, and 294. Vacancies lie
in distinct target-free internal face-chord blocks. Fix a free
group with retained ordinary end links. Let \(p\ge1\), and
choose
\[
 i<j_1<\cdots<j_p\le s-1<m=s+1,
 \qquad m+2\le u<w.                                    \tag{1}
\]
Put \(Q=B_i,\ldots,B_w\). Its distinguished vacant blocks
are \(B_i,B_{j_1},\ldots,B_{j_p},B_m,B_u,B_w\), and
\(B_s\) is short. The only missing ordinary links in the
group are \(P_s=e_so_m\) and \(P_m=e_mo_{m+1}\). The
three distinguished atom components are
\[
 \{V_i,V_m,V_w\},\qquad
 \{V_{j_1},\ldots,V_{j_p},P_s\},\qquad
 \{P_m,V_u\}.                                           \tag{2}
\]
Their matching edges are
\[
\begin{array}{ll}
 H_iI_w,\ I_iH_m,\ I_mH_w;&\\
 H_{j_1}o_m,\ I_{j_t}H_{j_{t+1}}\ (1\le t<p),\
 I_{j_p}e_s;&\\
 e_mI_u,\ o_{m+1}H_u.&
\end{array}                                              \tag{3}
\]
All other ordinary links of \(Q\) are retained. The proper
gaps between consecutive distinguished atoms are closed under
any additional vacancy-only matching by noncrossing. They may
contain arbitrarily many nested vacancy-only components. Let
\(S(G)\) denote Note 275's spanning straight path in a
nonempty closed gap \(G\); let \(T(G)\) and \(D(G)\) be its
disjoint crossed top and bottom rails, with endpoints
\[
 T(G):a_{\min G}\longleftrightarrow b_{\max G},
 \qquad D(G):o_{\min G}\longleftrightarrow e_{\max G}.
                                                               \tag{4}
\]

**Unbounded inner-end-port theorem.** The interval \(Q\)
has three vertex-spanning routes
\[
\begin{array}{ll}
 S(Q):&o_i\longleftrightarrow e_w,\\
 K(Q):&a_i\longleftrightarrow o_i,\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_i\longleftrightarrow b_w,\quad
       o_i\longleftrightarrow e_w.
\end{array}                                              \tag{5}
\]
The number \(p\), all distances between distinguished
blocks, and all nesting depths in the closed gaps are
unbounded. Reflection gives the version with an arbitrarily
long right port component and a single vacancy at the left
port. Other vacancy-only parts may surround \(Q\) or be
serially disjoint. If every other free group has an ordinary
spanning route, the parent has a Hamilton cycle through both
site edges and its legal expanded child is Hamiltonian.

**Proof.** We first define a fold across a proper block gap.
For \(a<b\), let \(G(a,b)=B_{a+1},\ldots,B_{b-1}\).
When this gap is closed and all its ordinary links are retained,
define \(F(a,b):b_a\leadsto e_a\) by
\[
 F(a,b)=\begin{cases}
 b_a,e_a,&b=a+1,\\
 b_a,a_{a+1}\xrightarrow{T(G(a,b))}b_{b-1},e_{b-1}
 \xrightarrow{D(G(a,b))^{-1}}o_{a+1},e_a,&b\ge a+2.
 \end{cases}                                             \tag{6}
\]
The middle join \(b_{b-1}e_{b-1}\) is on the old cycle;
the first and final joins are an old-cycle edge and a
retained ordinary link. Thus \(F(a,b)\) covers the gap
exactly once, ending at \(e_a\), without using \(B_b\).

The terminal fold \(T_s:o_s\leadsto a_s\) covers
\(G(j_p,s)\):
\[
 T_s=\begin{cases}
 o_s,a_s,&s=j_p+1,\\
 o_s,e_{s-1}\xrightarrow{D(G(j_p,s))^{-1}}o_{j_p+1},
 a_{j_p+1}\xrightarrow{T(G(j_p,s))}b_{s-1},a_s,
 &s\ge j_p+2.
 \end{cases}                                             \tag{7}
\]
All boundary joins in (7) are retained links or old-cycle
edges. The two rails cover the terminal gap once.

For \(t<p\), put \(F_t=F(j_t,j_{t+1})\), and put
\(F_p=(b_{j_p},e_{j_p})\), an old-cycle edge. Define the
*port chain* \(\Lambda\), from \(H_{j_1}\) to \(e_s\), by
concatenating for \(t=1,\ldots,p\) the passages
\[
 H_{j_t},o_{j_t},a_{j_t},F_t,I_{j_t},               \tag{8}
\]
with matching joins \(I_{j_t}H_{j_{t+1}}\) between
successive passages and \(I_{j_p}e_s\) at the end.
Here \(F_t\) starts at \(b_{j_t}\), joined to
\(a_{j_t}\) by the face chord. Each passage covers its
vacant block and, for \(t<p\), the following proper gap.
The last passage uses the old-cycle edge \(b_{j_p}e_{j_p}\).
Thus \(\Lambda\) covers every \(B_{j_t}\) and all gaps
between them exactly once. Let \(\Lambda_K\) be the same
path starting at \(a_{j_1}\), omitting only
\(H_{j_1},o_{j_1}\); it ends at \(e_s\).

For the right side put \(R=G(m,u)\) and \(W=G(u,w)\).
The gap \(R\) is nonempty because \(o_{m+1}H_{m+1}\)
is an old-cycle edge. The straight right continuation
\(R_S:e_m\leadsto e_w\) begins
\[
 e_m,I_u,H_u,o_{m+1}\xrightarrow{S(R)}e_{u-1},
 o_u,a_u,b_u,e_u.                                      \tag{9}
\]
If \(W\) is empty, finish \(e_u,o_w,a_w,b_w,e_w\).
Otherwise finish
\[
 e_u,o_{u+1}\xrightarrow{S(W)}e_{w-1},o_w,a_w,b_w,e_w.
                                                               \tag{10}
\]
The crossed right continuation \(R_X:b_m\leadsto b_w\)
begins
\[
 b_m,a_{m+1}\xrightarrow{T(R)}b_{u-1},e_{u-1}
 \xrightarrow{D(R)^{-1}}o_{m+1},H_u,o_u,a_u,b_u,
 e_u,I_u,e_m,I_m,H_w,o_w.                               \tag{11}
\]
If \(W\) is empty, finish \(o_w,a_w,b_w\); otherwise finish
\[
 o_w,e_{w-1}\xrightarrow{D(W)^{-1}}o_{u+1},
 a_{u+1}\xrightarrow{T(W)}b_{w-1},a_w,b_w.            \tag{12}
\]
These are the same right-side folds as in Note 294; their
edges and spanning coverage follow from (4), the retained
boundary links, and the two right-port edges in (3).

Let \(G_0=G(i,j_1)\). The straight route is
\[
 o_i,a_i,F(i,j_1),I_i,H_i,I_w,H_w,I_m,H_m,o_m,
 \Lambda,T_s,b_s,a_m,b_m,R_S.                         \tag{13}
\]
Here \(F(i,j_1)\) starts at \(b_i\) after the face chord
\(a_ib_i\); \(\Lambda\) starts at \(H_{j_1}\) after the
matching edge \(o_mH_{j_1}\); \(T_s\) starts at \(o_s\)
after the old-cycle edge \(e_so_s\); and \(R_S\) starts
at \(e_m\) after \(b_me_m\). Formula (13) traverses
all vacancy slots of the three distinguished components,
and its disjoint folds and straight gaps cover all other
vertices once. Its endpoints are \(o_i,e_w\).

For the cap state retain the disjoint edge \(e_wb_w\).
When \(G_0\) is empty, the other path is
\[
 a_i,b_i,a_{j_1},\Lambda_K,T_s,b_s,a_m,o_m,
 H_{j_1},o_{j_1},e_i,I_i,H_m
 \xrightarrow{C\text{ forward}}I_w,H_i,o_i.          \tag{14}
\]
When \(G_0\) is nonempty, replace the two joins
\(b_i a_{j_1}\) and \(o_{j_1}e_i\) in (14) by
\[
 b_i,a_{i+1}\xrightarrow{T(G_0)}b_{j_1-1},a_{j_1},
 \qquad
 o_{j_1},e_{j_1-1}\xrightarrow{D(G_0)^{-1}}o_{i+1},e_i.
                                                               \tag{15}
\]
The first port block's \(a,b,e,I\) vertices lie on
\(\Lambda_K\); its \(H,o\) vertices lie after \(o_m\).
The old-cycle arc from \(H_m\) to \(I_w\) covers the
entire right side without using either missing link, and
leaves only \(e_w,b_w\) for the cap. Thus (14)--(15)
give \(K(Q)\).

For the crossed state take the bottom path
\[
 o_i,H_i,I_w,e_w.                                    \tag{16}
\]
The top path is
\[
 a_i,F(i,j_1),I_i,H_m,o_m,\Lambda,T_s,b_s,
 a_m,b_m,R_X.                                         \tag{17}
\]
The first fold starts at \(b_i\) after \(a_ib_i\),
\(\Lambda\) starts at \(H_{j_1}\) after \(o_mH_{j_1}\),
and the terminal fold starts at \(o_s\) after \(e_so_s\).
The top path includes every vertex except the four on the
bottom path; its last vertex is \(b_w\). Equations
(16)--(17) give \(X(Q)\).

The construction uses each proper gap only through its
\(S,X\) signature, apart from old-cycle arcs. Thus any
already resolved closed gap with these states can be
substituted if the displayed boundary links remain.
Vacancy-only parts outside \(Q\) are serial or surrounding
and compose by Note 275. Note 273 joins the free groups;
Notes 001 and 178 give the marked Hamilton parent cycle,
the legal expanded-child cycle, and arbitrary original lobe
lengths. \(\square\)

**Unbounded analytic realization.** Let \(p\ge1\).
Take the old cycle and unchanged site, face, escape, and
residual-square edges of Note 281(8)--(9). Use exactly
\(p+4\) vacant internal blocks, put the \(j_t\) in
increasing order before \(B_s\), and retain all ordinary
links except \(P_s,P_m\). Add the edges (3).
For the shortest instance take
\[
 i=1,\quad j_t=t+1\ (1\le t\le p),\quad
 s=p+2,\quad m=p+3,\quad u=p+5,\quad w=p+6,\quad r=w.
                                                               \tag{18}
\]
Any proper gap may be filled with arbitrarily many additional
short blocks. These insertions add four vertices each.
The matching is perfect and joins opposite old-cycle colours.
On the opposite side of the site face,
\(H_iI_w\) surrounds the remaining free chords,
\(I_iH_m\) surrounds the left-port component,
\(I_mH_w\) surrounds the right-port component, and
the left-port edges in (3) are nested or disjoint.
The retained ordinary links are nested in or disjoint from
these intervals, so the two-page drawing is planar.

Retained links connect face chords along the left and right
standard-chain pieces. The edges \(H_iI_w,I_iH_m\)
join these pieces to the shared-block face chord; every
other special edge interlaces an endpoint face chord.
The unchanged site and residual-square links complete
Note 281's interlacement chain. Notes 217 and 182 therefore
give three-vertex-connectivity. With \(d\) inserted short
blocks, the parent and legal child have
\[
 6p+44+4d,\qquad 6p+48+4d                         \tag{19}
\]
vertices and both are Hamiltonian by (5).

At \(p=1\) this includes Note 294's five-vacancy pattern;
at \(p=2\) it includes Note 296's port-extended six-vacancy
pattern. The arbitrary \(p\) theorem settles unbounded
one-sided growth of the inner left port component, together
with its reflected right-port version. It does not address
simultaneous unbounded growth of both ports or growth of the
surrounding vacancy-only component, and it does not settle
Barnette's conjecture.
