> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Distinct sharp vacancy blocks cannot separately support the gaps

[Note 270](270-mixed-sharp-gap-supports-have-one-orientation-and-four-port-rows.md)
leaves four necessary port pairings when one of two distinct
gap-support blocks contains escape targets and the other does not.
The next escape target after the target-bearing block rules out
all four pairings by the prefix two-edge cut of
[Note 197](197-gapless-square-trap-defect-budget.md).

Let a Barnette parent have a selected compressed all-square
facial opening with \(\ell,r\ge1\) and
\[
 f=4r+8,\qquad \sigma=T=2.                         \tag{1}
\]
Suppose the two capacity vacancies lie in different blocks,
and each of the two gap slots is matched to a different
vacancy block.

**Distinct-support exclusion theorem.** No such opening exists.
The statement allows one two-slot gap or two singleton gaps.

**Proof.** If neither vacancy block contains an escape target,
[Note 259](259-two-target-free-vacancy-blocks-cannot-support-a-third-surplus-gap.md)
excludes the opening. If both contain targets,
[Note 269](269-two-target-bearing-vacancy-blocks-cannot-separately-support-sharp-gaps.md)
excludes it. It remains to exclude the mixed assignment.

Use Note 270's notation. Its target-bearing block \(P\)
precedes the target-free block \(Q\) and both gap slots
\(g<h\). The forward suffix of \(P\) consists of four
consecutive free slots \(c,H,I,e\), following its last
escape target \(L_j\). Note 258's four-slot suffix
classification makes \(j\ge2\): \(L_1\) there would
consume a second eligible vacancy of \(P\). Let
\(R_{j-1}\) be the next escape target in main-segment order.
It is outside \(P\), and it cannot lie in the target-free
block \(Q\).

In each of the four rows of Note 270(2), the three special
opposite-side matching edges force \(R_{j-1}\) to follow
both gaps and all of \(Q\):

* In the first and third rows, \(Hh\) spans from \(P\)
  through the last gap slot \(h\).
* In the second row, \(Hu_2\) and \(u_3h\) cover every
  vertex from \(H\) through \(h\): \(u_2,u_3\) are
  consecutive interior slots of \(Q\), so there is no
  vertex between their two spans.
* In the fourth row, \(Hu_3\) spans from \(P\) through
  the third free slot of \(Q\); the rest of \(Q\)
  contains no target.

An escape target strictly within any of these matching-edge
spans would contradict the no-straddling lemma of
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
The slots of \(P\) following \(L_j\) and all slots of \(Q\)
are target-free. Thus \(R_{j-1}\) lies in a block \(D\)
strictly after \(P,Q,g,h\); Note 195 forbids targets in gaps.

Both gap slots precede \(D\), so its first interior slot
has odd colour and \(D\) is forward. Since the only two
capacity vacancies lie in \(P,Q\), \(D\) is saturated.
If \(R_{j-1}\) occupied any odd interior slot after the
first, the preceding second interior slot would be an
eligible even position occupied by a nonfinal \(L\)-target.
That would put an escape target strictly between
\(L_j\) and its successor \(R_{j-1}\). Hence
\(R_{j-1}\) is the first interior slot of \(D\).

Take the main \(C\)-prefix ending just before the left
endpoint of \(D\), together with the residual-square
suffix \(S_j,\ldots,S_\ell\). This prefix contains both
vacancy blocks and both complete gaps. Every escape target
in the prefix is matched into the included square suffix;
the square matching edges and all block-closing site or
face chords are internal. If a free matching edge left
the prefix, its first endpoint would precede
\(R_{j-1}\), while its second would follow that target:
the left endpoint of \(D\) is already matched to its
right endpoint, and \(R_{j-1}\) is matched to its
square. Such an edge is cross-atom, lies opposite the
designated face by Note 193, and is forbidden by
Note 203. The displayed vertex set is therefore
matching-closed and has exactly two departing edges
of \(C\), as in Note 197's arbitrary-gap prefix-cut
argument. This contradicts three-connectivity. \(\square\)

Consequently, if the two sharp capacity vacancies lie in
different blocks, both gap slots must be matched to the
same one-vacancy block. This theorem makes no Hamilton
assertion for that remaining assignment, for gapless
third-surplus openings, or for general Barnette graphs.
