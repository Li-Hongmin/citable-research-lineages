> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-special leaf closes the three-root chord-free opening

[Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md) leaves a chord-free equality profile with three ordinary roots and one four-special leaf. The two cuts through that leaf used in [Note 470](470-one-four-special-leaf-always-supplies-the-chorded-four-port-cover.md) reduce a hypothetical failure to one sealed four-edge shore in the middle root. Parity of a noncrossing matching excludes that shore.

Let \(G\) be a finite simple three-connected cubic bipartite plane graph with a Hamilton cycle \(C\) and a legal cofacial \(C_4\)-expansion site. Use the chord-free single-hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md):
\[
 C=(w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0),
\tag{1}
\]
with escape edges \(t_dd,t_cc,t_bb,t_aa\), trap chord \(\alpha\beta\), and site edges \(q=w_0u,p=vw_*\), where \(u<v\) lie in the roots. Suppose every assigned special position belongs to a leaf, exactly one leaf has four special positions, and every other leaf has two. Write the four-special leaf's consecutive old-cycle word as
\[
                         h,x_1,x_2,x_3,x_4,j,
\tag{2}
\]
with ordinary chord \(hj\). Let \(K\) be the root face graph of Note 456. Ordinary wrappers are unrestricted.

**Three-root four-special-leaf theorem.** The legal expanded child is Hamiltonian. Unless \(u=x_2,v=x_3\), the parent has a Hamilton cycle containing both site edges \(p,q\).

**Proof.** The pair \(u=x_2,v=x_3\) gives a one-edge facial gap; [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md) then gives a Hamiltonian child. Hence at least one of \(x_2,x_3\) has a face-matching edge, and that edge leaves \(\{x_2,x_3\}\), since \(x_2x_3\) is an old-cycle edge and cannot also be a third edge of a simple cubic graph.

If \(K\) is disconnected, the cut and noncrossing proof of Note 456 puts both site ports in an isolated end root \(W\in\{W_1,W_3\}\). The other vertices lie on its explicit spanning \(w_0\)--\(w_*\) path (4) or (5). If the exceptional leaf lies outside \(W\), the two-terminal square splice of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) gives a spanning \(u\)--\(v\) path in \(W\). If the leaf lies in \(W\), close the old \(W\)-arc with its root chord to make \(C_W\). Let \(E_W\) be the old adjacent-special edges of its two-special leaves and \(M_W\) its internal face matching except at \(u,v\). The graph
\[
       (C_W-E_W-\{x_1x_2,x_3x_4\})\cup M_W
\tag{3}
\]
has one \(u\)--\(v\) path and possibly cycles. Before deleting \(E_W\), it is connected: the face-matching edge from \(x_2\) or \(x_3\) joins the central edge \(x_2x_3\) to the complementary arc of \(C_W\). The quotient by \(E_W\) is connected, so the disjoint leaf-square switches of Note 458 absorb all cycles into the path. The outside path and both site edges close a marked parent Hamilton cycle. Thus a non-Hamiltonian child requires connected \(K\).

For connected \(K\), take the three disjoint cycles \(D=C_1\cup C_2\cup C_3\) of Note 456. They cover every parent vertex except \(w_0,w_*,\alpha,\beta\). Let \(E\) contain the adjacent-special old edge of each two-special leaf, and let \(M\) match all assigned special positions except \(u,v\) on the face side. Set
\[
       F=(D-E-\{x_1x_2,x_3x_4\})\cup M.
\tag{4}
\]
It has one \(u\)--\(v\) path and possibly cycles. Contract its components and represent the deleted edges \(E\cup\{x_1x_2,x_3x_4\}\) in a multigraph \(Q\). It is connected because \(D\cup M\) is connected. In each component of \(F\), the number of deleted-edge endpoints equals twice the number of its \(M\)-edges plus its number of site terminals, which is zero or two. Thus every quotient vertex has even degree, as in [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md). If \(Q-\{x_1x_2,x_3x_4\}\) is connected, leaf-square switches along its spanning tree yield a spanning \(u\)--\(v\) path on \(D\); the exterior path \((u,w_0,\beta,\alpha,w_*,v)\) closes a marked parent Hamilton cycle.

Otherwise the two unswitchable edges form a two-edge bond of the connected even-degree graph \(Q\). Switching along leaf-edge spanning trees on the two sides leaves one spanning \(u\)--\(v\) path \(P\) and one disjoint spanning cycle \(Z\). The switches never touch the escape edges of \(D_1,D_3\). If \(Z\) contains \(t_dd\) or \(t_aa\), the corresponding exterior splice (4) or (5) of [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md) joins \(P,Z\) to a parent Hamilton cycle containing both site edges. Thus a hypothetical failure has an unmarked side containing neither end-root cycle.

Let \(I=x_2x_3\) be the central edge and let \(O\) be the complementary arc in the exceptional root cycle after deleting \(x_1x_2,x_3x_4\). Every other root cycle lies wholly on one side of the bond. The side without site ports cannot be \(I\) alone: its two vertices would need face-matching mates outside \(I\), while \(x_2x_3\) is unavailable as a matching edge. If the exceptional leaf lies in \(W_1\), the only unmarked side without an end-root escape edge is \(I\cup C_2\). Both \(x_2,x_3\) then have face chords into \(W_2\). Choose the chord from \(x_2\) to \(W_2\). A site port anywhere in the suffix of \(W_1\) beginning at \(x_4\) would cross this chord. The only available face-matching endpoints before \(x_4\) in \(W_1\) are before \(x_2\), since \(x_2,x_3\) are matched into \(W_2\); a chord from that suffix to such an earlier endpoint, or to \(W_3\), would cross the chosen chord. A chord from the suffix to \(W_2\) would cross the bond. Hence all special positions in the suffix must be matched within the suffix. But it has \(x_4\) and otherwise only whole two-special leaves, an odd number of positions, contradiction. Reflection excludes an exceptional leaf in \(W_3\).

The exceptional leaf therefore lies in \(W_2\). The only unmarked side without an end-root escape edge is \(O\) alone. By the bond, no face-matching edge leaves \(O\), and it contains no site port. All ordinary matching edges incident with \(O\) stay in the same root and avoid \(x_2,x_3\), which are special. The root endpoints lie in \(O\), so its edge cut in the parent would be exactly
\[
 x_1x_2,\quad x_3x_4,\quad t_cW_{2,\ell},\quad W_{2,r}t_b.
\tag{5}
\]

This sealed shore cannot occur. Every special position of \(O\) is an endpoint of the internal face matching. Before \(x_2\) in \(W_2\), those positions consist of \(x_1\) and complete two-special leaves, hence have odd cardinality; after \(x_3\), they consist of \(x_4\) and complete two-special leaves, also odd. Each of \(x_2,x_3\) has a third edge on the face side. It cannot end in \(O\), since no face-matching edge leaves \(O\); it cannot join the other central vertex, since \(x_2x_3\) is an old-cycle edge. Thus it is a site edge to \(w_0\) or \(w_*\), or a face chord to \(W_1\) or \(W_3\). An edge from either central vertex to the left of \(W_2\) encloses the odd set of \(O\)-positions before \(x_2\). Every matching edge from one of those positions to outside that interval would interlace the central edge on the same face page. Its endpoints would therefore have to match among themselves, impossible for an odd set. An edge to the right of \(W_2\) gives the symmetric contradiction using the odd set after \(x_3\). This excludes the final disconnected quotient. Every remaining case has the marked parent Hamilton cycle constructed above, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

**Equality consequence.** The \(m=f+1,R=3,M_0=L=f\) row of Note 477 is Hamiltonian for every \(f\ge7\), independently of wrapper lengths. With [Note 478](478-one-root-all-leaf-chord-free-equality-always-has-an-exterior-splice.md), only the two marked-unary rows remain as possible chord-free \(c=5f-8\) failure profiles. This does not decide either row or Barnette's conjecture.
