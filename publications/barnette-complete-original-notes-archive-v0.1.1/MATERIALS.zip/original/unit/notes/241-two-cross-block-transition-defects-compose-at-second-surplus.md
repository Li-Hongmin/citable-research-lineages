> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two cross-block transition defects compose at second surplus

[Note 237](237-disjoint-tight-budget-target-defects-compose-at-all-surpluses.md)
composes two target-order defects when their block
intervals are disjoint. Two distinct transition
intervals can overlap in only one block: the
destination of the earlier transition is the
source of the later one. Three-connectivity
excludes both matching chords across that
shared block's target run.

Use a compressed all-square Barnette opening
with \(\ell,r\ge1\), no interblock gaps, and
\(s=2\), so \(f=4r+6\). Assume
\[
d_L=d_R=0,\qquad b=2,                       \tag{1}
\]
and that each defective transition has its
two targets in distinct blocks.

**Cross-block double-transition theorem.**
The parent has a Hamilton cycle containing
both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian.
The conclusion holds for arbitrary positive
original lobe lengths.

**Proof.** Number the defective transitions
\(L_j,R_{j-1}\) and \(L_k,R_{k-1}\),
where \(j>k\). Write their block intervals
as \([i,h]\) and \([p,q]\).
Target order gives
\[
i<h\le p<q.                                 \tag{2}
\]
The two defects exhaust the two eligible
vacancies by Note 197. Each transition has
exactly one vacancy strictly between its
targets. If \(h<p\), the intervals are
disjoint and Note 237 applies.

Suppose \(h=p\). The sole vacancy of the
first transition lies immediately before
\(R_{j-1}\) in \(B_h\), and the sole
vacancy of the second lies immediately
before \(R_{k-1}\) in \(B_q\). The first
source \(L_j\) is the last eligible
position of \(B_i\), and the second
source \(L_k\) is the last eligible
position of \(B_h\). Note 212's
first-slot cut excludes either
destination as the first slot of
its later block; an additional
eligible position between a source
and destination would consume a
third vacancy. All blocks strictly
between the respective endpoints
are short. Thus the free slots
of the shared block have order
\[
o_h,w,\quad
R_{j-1},L_{j-1},\ldots,L_k,\quad
c,e_h,                                      \tag{3}
\]
where \(o_h,w\) precede its first
target and \(c,e_h\) follow its
last target. If \(j-1=k\), the
middle target run is simply
\(R_k,L_k\).

The free-slot prefix before
\(R_{j-1}\) has \(2h+2\) vertices and is even. Note 203
forbids every cross-block free
chord straddling that target.
The only opposite-colour
same-block chords across the
target run in (3) are
\[
o_he_h,\qquad wc.                            \tag{4}
\]
Matching parity permits zero or
both. Suppose both occur. Take
the main \(C\)-prefix from \(x\)
through the right endpoint of
\(B_{h-1}\), together with the
residual-square suffix
\(S_j,\ldots,S_\ell\). This is a
proper consecutive \(C\)-interval.
Every escape target in its main
part is matched to an included
square; all site and face chords
there are internal. A free chord
leaving it would have to enter
\(B_h\) before \(R_{j-1}\), whose
two free slots are used by (4),
or pass that target, contrary to
Note 203. Thus the interval is
matching-closed and has only
two departing old-cycle edges,
contradicting three-connectivity.
Neither chord in (4) occurs.

The first free group, between
\(L_j,R_{j-1}\), and the second,
between \(L_k,R_{k-1}\), are
therefore matching-closed and
disjoint. Note 212's noncrossing
and two-edge-cut proof fixes
each group's long matching
chord from the free odd slot
after its source to the free
even slot before its destination,
with all ordinary standard
links retained. Every other
free group also follows the
standard chain. Consequently
Note 196's target-and-square
path can replace both missing
transitions by their Note 212
three-edge routes. The
ordinary free path is unchanged.
These paths are internally
disjoint, cover every vertex,
and form a Hamilton cycle
through \(xy,uv\). Notes 001
and 178 give the legal child
and longer lobes. \(\square\)

**A realized shared-block profile.**
Let \(\ell=3,r=2,j=3,k=2\).
Take the old 36-cycle in
consecutive blocks
\[
\begin{array}{ll}
B_0:&x,R_3,L_3,c_0,e_0,y,\\
B_1:&a_1,o_1,w_1,R_2,L_2,c_1,e_1,b_1,\\
B_2:&a_2,o_2,w_2,R_1,e_2,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_t:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2,3),\text{ returning to }x.
\end{array}                                     \tag{5}
\]
Its complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2\}\\
&\cup\{\alpha_t\beta_t,R_t\delta_t,
L_t\gamma_t:t=1,2,3\}\\
&\cup\{c_0w_1,e_0o_1,c_1w_2,e_1o_2,e_2o_3\}.
\end{split}                                     \tag{6}
\]
All matching pairs have opposite
old-cycle parity. Draw the site,
face, and \(\alpha_t\beta_t\)
chords on one side. On the
other side, the escape chords
nest in target order, with
\(c_0w_1\supset e_0o_1\)
between \(L_3,R_2\),
\(c_1w_2\supset e_1o_2\)
between \(L_2,R_1\), and
\(e_2o_3\) after \(R_1\).
This gives a simple cubic
bipartite plane graph with
cofacial \(xy,uv\).

Its matching-chord interlacement
graph is connected. A spine is
\[
xy-c_0w_1-a_1b_1-c_1w_2-a_2b_2
-e_2o_3-uv-L_1\gamma_1
-\alpha_1\beta_1-R_1\delta_1-a_2b_2.
\tag{7}
\]
The second square attaches by
\(a_1b_1-L_2\gamma_2-
\alpha_2\beta_2-R_2\delta_2-a_1b_1\);
the third by
\(xy-L_3\gamma_3-
\alpha_3\beta_3-R_3\delta_3-xy\).
Finally \(e_0o_1,e_1o_2\)
interlace their neighbouring
site or face chords. Note 217's
interval criterion proves
three-connectivity; its cut map
makes the 40-vertex site
expansion Barnette.

The marked parent cycle is the
union of the internally disjoint
paths
\[
\begin{split}
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,o_3,u,v,\\
&x,R_3,\delta_3,\beta_3,\alpha_3,\gamma_3,
L_3,c_0,w_1,R_2,\delta_2,\beta_2,
\alpha_2,\gamma_2,L_2,c_1,w_2,R_1,
\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\end{split}                                     \tag{8}
\]
The paths have 14 and 24 vertices,
share only \(x,v\), and thus cover
all 36 vertices.
\(\square\)

The theorem treats both disjoint
and single-block-overlap cases
when each defective transition
crosses blocks. Same-block
defective transitions may have
different internal matching
chords and remain outside this
statement. Barnette's conjecture
is not resolved.
