> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimum directed repairs of the legal-wide defect example do not reach a brace

[Note 092](092-a-legal-wide-plane-interface-has-nonnormalized-minimum-two-switches.md)
gives a legal-wide plane cubic bipartite graph whose complete fibre contains
nonnormalized global minima.  Its two copies \(L,W\) of \(Q_3-e\) each meet
the rest of the graph in a two-edge boundary, so the graph has
vertex-connectivity two.  This note determines the minimum facial
\(C_4\)-repair class that can simultaneously break both boundaries.

No one- or two-step repair in that class is a brace.  One step always leaves
connectivity two.  At two steps, 60 labelled sequences become
3-connected and retain the legal-wide interface, but all 60 fail
2-extendability.  Hence this most direct route cannot promote the defect
counterexample into the Barnette class.

## 1. Directed repair class

Fix the labelled cellular embedding, root square and surviving gate
\(g_1=p_0p_1\) from Note 092.  A repair step chooses two nonadjacent edges
at even cyclic distance on one current face and performs the standard
bipartite facial \(C_4\)-expansion.  The four root-square edges and \(g_1\)
are fixed.

The four attachment edges are allowed to change.  If a step expands an
attachment, the new unique outer neighbour of the corresponding square
vertex becomes the residual terminal; the ordered pairing \(\pi_0\) is then
reconstructed from the labelled square.  Thus the class preserves the
mathematical interface rather than freezing an accidental terminal name.

Initially

\[
|\delta(L)|=|\delta(W)|=2.
\tag{1}
\]

Any brace repair must increase both boundaries.  Consequently two steps are
the first possible directed repair depth: one expansion can meet at most one
of the two disjoint pole boundaries.

## 2. Complete one- and two-step classification

There are exactly 87 eligible one-step expansions.  Every resulting graph
has vertex-connectivity two.

Enumerating every eligible ordered second step gives 8,879 labelled
sequences.  The successive necessary filters are

\[
\begin{array}{c|r}
\text{condition}&\text{sequences}\\ \hline
\text{both original pole boundaries increased}&1,008\\
\text{legal-wide interface retained}&816\\
\kappa=2&756\\
\kappa=3&60\\
\text{brace}&0.
\end{array}
\tag{2}
\]

The 60 3-connected sequences are 30 unordered repair pairs, each counted
in its two commuting orders.  For every one of the 60 graphs, an exhaustive
independent-edge-pair test finds a pair that does not extend to a perfect
matching.  Since these graphs are bipartite, none is a brace.

There is therefore no brace survivor on which to run the fixed-pairing fibre
classification.  The obstruction occurs strictly before the normalization
question.

## 3. Exact boundary

**Finite closure.**  Relative to the fixed labelled embedding of Note 092,
the entire one- and two-step bipartite facial \(C_4\)-repair class contains
no legal-wide plane brace.

**Consequence.**  The two-pole defect example cannot be promoted by the
minimum number of local facial repairs.  Continuing to enumerate the same
one/two-step class cannot test brace-level existential normalization.

**Scope.**  This does not cover three or more repairs, nonfacial gadgets,
other embeddings or arbitrary plane braces.  It supplies neither a proof nor
a counterexample to the remaining statement that a plane-brace fibre of
cross-sector minimum two contains at least one normalized minimum pair.

The complete labelled classification and exact 2-extendability tests are
frozen in the
[verification bundle](../computations/bundles/legal-wide-defect-counterexample/README.md).

