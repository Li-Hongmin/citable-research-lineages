> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every gapless all-square second-surplus opening is Hamiltonian

[Note 197](197-gapless-square-trap-defect-budget.md) bounds target-order
defects by the number of vacant eligible positions. At the
second surplus, [Note 235](235-every-tight-gapless-two-vacancy-square-opening-is-hamiltonian.md)
handles zero defects; [Notes 238--242](242-all-double-transition-defects-at-second-surplus-are-hamiltonian.md)
handle two; [Note 248](248-all-single-endpoint-defects-at-second-surplus-are-hamiltonian.md)
handles one endpoint defect. [Notes 249--253](253-a-source-pretarget-vacancy-composes-with-a-cross-block-transition.md)
complete the remaining one-transition branch. The block-order
classification below records why these cases exhaust the
selected opening class.

Let \(G\) be a three-connected cubic bipartite plane graph
with a Hamilton cycle \(C\) avoiding two disjoint cofacial
matching edges \(q=xy,p=uv\). Select an all-square facial
opening as in Notes 176--179. Let \(\ell,r\ge1\) be its
residual-square lobe and opposite-face-chord counts. Assume
every interblock gap is empty, and let \(f\) be the number
of free main vertices as in [Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md).

**Second-surplus Hamilton theorem.** If
\[
f=4r+6,                                           \tag{1}
\]
then \(G\) has a Hamilton cycle containing both \(q,p\).
Consequently the legal site-expanded Barnette child is
Hamiltonian. The assertion holds for all \(\ell,r\ge1\),
every placement of the two vacant eligible positions,
every target order consistent with the opening, and
arbitrary positive lengths of the original square-trap lobes.

**Proof.** Compress each lobe to one residual square by
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Empty gaps and (1) give exactly \(s=2\) vacant eligible even
positions by Note 197. Write \(d_L,d_R\in\{0,1\}\) for its
endpoint defects and \(b\) for the number of nonadjacent
consecutive-lobe transitions. Its defect budget says
\[
D:=d_L+b+d_R\le2.                              \tag{2}
\]

If \(D=0\), Note 235 gives a marked parent Hamilton cycle.
If \(D=2\), the defect pair is either both endpoints,
one endpoint and one transition, or two transitions.
Note 238 proves the first case. Notes 239--240 prove
the second, including its same-block overlap. Notes
241--242 prove the third, including both cross-block
and same-block overlaps. Every cited theorem gives a
parent cycle containing \(xy,uv\).

Suppose \(D=1\). If the sole defect is at an endpoint,
Note 248 gives the marked parent cycle, using reflection
for the right endpoint. It remains to take
\[
d_L=d_R=0,\qquad b=1.                         \tag{3}
\]
Let \(L_j,R_{j-1}\) be the unique defective transition,
and let its targets lie in blocks \(B_i,B_h\), respectively.
If \(i=h\), Note 249 settles every location of the spare
vacancy, excluding impossible placements by a matching
obstruction and giving a marked cycle in the remaining ones.

Now let \(i<h\). The target \(R_{j-1}\) cannot be the first
interior slot of \(B_h\). Otherwise the main old-cycle
prefix through \(B_{h-1}\), together with residual squares
\(S_j,\ldots,S_\ell\), would have no outgoing matching
edge: every such edge would straddle \(R_{j-1}\) and join
different blocks, contrary to
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Exactly two old-cycle edges would leave, violating
three-connectivity. No target occurs between
\(L_j,R_{j-1}\), so every eligible even position before
\(R_{j-1}\) in \(B_h\) is vacant. With only two vacancies,
\(R_{j-1}\) is therefore its third or fifth interior slot.

If it is fifth, both vacancies precede it in \(B_h\),
and Note 251 applies. If it is third, its second slot
is the vacancy charged to the transition. The other
vacancy has exactly one of these locations:

1. In a block strictly before \(B_i\) or strictly after
   \(B_h\). Note 236 handles an internal face block;
   Note 252 handles the left or right site block.
2. In a strictly intermediate block \(B_k\),
   \(i<k<h\). It is an internal face block, and
   Note 250 applies.
3. In the source block \(B_i\). If it lies before
   \(L_j\), Note 253 applies. If it lies after
   \(L_j\), it is the reflection of Note 251's
   double-destination configuration.
4. In the destination block \(B_h\). A second
   vacancy before \(R_{j-1}\) would make that target
   fifth, already handled. A vacancy after it is the
   reflection of Note 253.

These are all blocks and all positions relative to the
two defective targets. The cited results either exclude
the placement in a Barnette parent or construct a parent
Hamilton cycle containing \(xy,uv\). Thus every opening
satisfying (1) has such a cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
lifts it through the legal site expansion, and Note 178
restores every positive original lobe length. \(\square\)

**Lower-bound corollary.** Note 196 gives the
same marked conclusion at \(s=0\), and Note 212 at \(s=1\).
Consequently a non-Hamiltonian legal child admitting a
selected gapless all-square opening must satisfy
\[
s\ge3,\qquad f\ge4r+8.                         \tag{4}
\]
This is a necessary condition for a counterexample in the
selected opening class. Openings with interblock gaps or
nonsquare residual cycles, as well as Barnette's conjecture
for arbitrary graphs, are not decided by this theorem.
