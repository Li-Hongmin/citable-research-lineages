> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four all-leaf roots with an interior empty gap splice

[Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md) closes the split-unary three-root profile and leaves four all-leaf roots at the chord-free \(c=5f-7\) boundary. The augmented root graph gives a Hamilton cycle when connected. When it is disconnected, its root-only component is impossible, and the exterior routes close every configuration whose empty gap is not at an end.

## Four-root theorem and exact remaining placement

Use the chord-free hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md), now with four nonempty ordinary root words \(W_1<W_2<W_3<W_4\) between \(w_0,w_*\). The four ordered escape targets \(t_d<t_c<t_b<t_a\) lie in distinct ones of the five gaps \(g_0,\ldots,g_4\) around these roots; the remaining gap is empty. Every assigned special position belongs to a two-special ordinary leaf. The site ports \(u<v\) are among these positions, the other positions are paired by noncrossing common-face chords \(M\), and the parent is three-connected, cubic, bipartite, and planar. Leaf wrapper lengths are unrestricted.

**Theorem.** If the empty gap is \(g_1,g_2\), or \(g_3\), the parent has a Hamilton cycle containing both site edges \(q=w_0u,p=vw_*\). The same holds for any empty gap when the augmented root graph \(J\) defined below is connected. If the parent has no such marked Hamilton cycle and the empty gap is \(g_0\), then \(J\) has exactly two components: the marked component contains the target-pair cycle through \(t_aa\), and the unmarked component contains the target-pair cycle through \(t_dd\). For empty gap \(g_4\), the roles of the two target-pair cycles reverse. These last two placements are necessary conditions, not non-Hamiltonian examples.

**Proof.** Close the old main path from \(t_d\) to \(t_c\) by \(t_cc,cd,dt_d\), and the path from \(t_b\) to \(t_a\) by \(t_aa,ab,bt_b\). Close every root outside these two paths by its outer ordinary chord. This gives vertex-disjoint cycles \(D\) covering the parent except \(w_0,w_*,\alpha,\beta\). Each target-pair path contains at least one root. Let \(J\) join roots matched by an edge of \(M\), and also join consecutive roots within either target-pair path. Components of \(J\) correspond exactly to components of \(D\cup M\).

If \(J\) is connected, [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md)'s augmented-root theorem gives a spanning \(u\)--\(v\) path on \(D\); the exterior path \((u,w_0,\beta,\alpha,w_*,v)\) closes it. Suppose \(J\) is disconnected. Each root has an even number of special positions. Every \(M\)-edge stays within one \(J\)-component, so the number of site positions in each component is even. Therefore \(u,v\) lie in one component, called *marked*, and every other component is site-free.

A site-free singleton root cannot be a \(J\)-component: no face matching edge leaves it, and its only edge-cut edges in the original parent are its two old-cycle boundary edges. Three-connectivity forbids this. A partition of four roots into three or more components has at least one site-free singleton, so \(J\) has exactly two components. Apply the two-terminal and zero-terminal square-switch assertions of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) separately to the marked and unmarked components of \(D\cup M\). They give a spanning \(u\)--\(v\) path \(P\) and a disjoint spanning cycle \(Z\). The switches are wholly inside leaf words, so both escape edges \(t_dd,t_aa\), whenever present in \(Z\), are retained.

When \(t_d\) occupies the leftmost gap \(g_0\) and \(t_dd\in Z\), delete that edge and attach
\[
                    (u,w_0,t_d),\qquad(d,\beta,\alpha,w_*,v).
\tag{1}
\]
The step \(w_0t_d\) is an old-cycle edge precisely because \(t_d\in g_0\). When \(t_a\) occupies the rightmost gap \(g_4\) and \(t_aa\in Z\), delete that edge and attach
\[
                    (u,w_0,\beta,\alpha,a),\qquad(t_a,w_*,v).
\tag{2}
\]
Here \(t_aw_*\) is an old-cycle edge precisely because \(t_a\in g_4\). Either operation joins \(P\), \(Z\), and all four exterior vertices into one Hamilton cycle through \(p,q\).

If \(Z\) contains neither escape edge, the unmarked \(J\)-component consists only of roots outside both target-pair paths. There are at most two such roots; a singleton was excluded, so there must be exactly two. This requires the empty gap to be \(g_0,g_2\), or \(g_4\), giving respectively
\[
\begin{array}{c|cc}
\text{empty gap}&\text{unmarked roots}&\text{marked roots}\\\hline
g_0&W_1,W_3&W_2,W_4\\
g_2&W_2,W_3&W_1,W_4\\
g_4&W_2,W_4&W_1,W_3.
\end{array}
\tag{3}
\]
For \(g_0\) or \(g_4\), each pair in (3) consists of two separate \(D\)-cycles. Connectedness of both \(J\)-components requires one face chord joining each pair. Their four endpoints interleave in root order, so the two common-face chords cross. For \(g_2\), the unmarked roots \(W_2,W_3\) are adjacent along the old main cycle because their gap is empty. Their union has no site edge and no face chord to the other roots; every ordinary chord is internal. Its edge cut consists of only the two old-cycle edges at the ends of the union, contradicting three-connectivity. Thus \(Z\) contains at least one escape edge.

If the empty gap is interior, both \(t_d\in g_0\) and \(t_a\in g_4\), so (1) or (2) closes the cycle. If the empty gap is \(g_0\), only (2) is automatically available; failure of the marked Hamilton cycle requires \(t_aa\notin Z\), so \(Z\) contains \(t_dd\) and the marked component contains \(t_aa\). The \(g_4\) case is reflected. This proves the theorem. Each Hamilton cycle obtained contains both site edges and lifts to the legal expanded child by [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md). \(\square\)

## Consequence for the 100-vertex frontier

At \(f=8\), [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md) bounds every non-Hamiltonian doubly reduced selected single-hexagon child by 100 vertices. In the chord-free branch, equality requires \(m=9,R=4,c=33\) and nine two-special leaves. The theorem above excludes every interior empty gap and every connected \(J\). A hypothetical 100-vertex chord-free failure must therefore have an end empty gap and place the unmarked target-pair cycle on the side opposite the available exterior splice, exactly as stated in the theorem. The chorded 100-vertex branch and smaller kernels remain undecided here; Barnette's conjecture is not resolved.
