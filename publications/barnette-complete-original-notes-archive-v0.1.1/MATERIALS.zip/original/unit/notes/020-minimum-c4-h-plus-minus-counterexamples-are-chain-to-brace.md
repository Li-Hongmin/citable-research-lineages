> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimum \(C_4\)-preservation counterexamples are chain-to-brace transitions

Let \(G\) be a Barnette graph with global \(H^{+-}\), let

\[
p=uv,\qquad q=xy
\]

be a legal facial \(C_4\)-expansion site, and let \(H\) be its child.  A
**counterexample triple** is a triple \((G,p,q)\) for which \(H\) does not
have global \(H^{+-}\).  This note reduces a minimum counterexample to one
tight-cut configuration and gives the exact cross-path interface at a cut
of that configuration.

## One-sided expansion--contraction commutation

Let \(\delta_G(S)\) be a nontrivial tight cut in an inclusion-wise maximal
laminar family, put \(T=\{u,v,x,y\}\), and suppose
\(|S\cap T|\ne2\).  After replacing \(S\) by its complement, it is enough
to consider \(|S\cap T|=0\) or \(1\).  Let \(G_0\) be the contraction which
retains the shore containing at least three vertices of \(T\), and let
\(G_1\) be the other contraction.

There is a legal site in \(G_0\) whose child \(H_0\) is one tight-cut
contraction of \(H\); the other contraction is the unchanged graph \(G_1\).
For \(|S\cap T|=0\), the site is unchanged.  For \(|S\cap T|=1\), the
unique site edge crossing the cut is renamed at the contraction vertex.

The facial qualification survives.  A facial cycle meets a three-edge cut
evenly.  In the one-terminal case it meets the cut in exactly two edges, and
contraction replaces its excursion through the contracted shore by the
corresponding passage through the contraction vertex.  The image remains a
facial cycle, its four site vertices are distinct, and bipartiteness preserves
the two odd residual facial paths.  Thus

\[
\boxed{
H/\delta\text{ has contractions }H_0\text{ and }G_1.}
\tag{1}
\]

Only the contraction retaining the site is expanded; it is false and
unnecessary to say that both contractions are expanded.

## The minimum-counterexample chain theorem

Assume that \((G,p,q)\) has minimum parent order among all counterexample
triples.  Global \(H^{+-}\) is equivalent to global \(H^{+-}\) in both
tight-cut contractions by Gorsky--Steiner--Wiederrecht, Lemma 4.5(iv).
Hence \(G_0,G_1\) have global \(H^{+-}\).  Since \(G_0\) is smaller than
\(G\), minimality and (1) imply that \(H_0\) also has global \(H^{+-}\).
The reverse direction of the same tight-cut lemma would then give global
\(H^{+-}\) for \(H\), a contradiction.

Consequently every member of the chosen maximal laminar family satisfies

\[
|S\cap T|=2.
\tag{2}
\]

The assertion holds for every nontrivial tight cut: first extend any
prescribed cut to an inclusion-wise maximal laminar family and repeat the
argument.

Four of the six two-element subsets of \(T\) contain one endpoint of \(p\)
and one endpoint of \(q\).  Both site edges would then lie in the tight cut,
contrary to Gorsky--Steiner--Wiederrecht, Lemma 5.3.  Thus every nontrivial
tight cut has one of the shore patterns

\[
S\cap T=\{u,v\}
\qquad\text{or}\qquad
S\cap T=\{x,y\}.
\tag{3}
\]

Every edge of the tight-cut decomposition tree therefore separates the
brace containing \(p\) from the brace containing \(q\).  Every tree edge
lies on the unique path between those nodes, so the whole decomposition tree
is that path.  Each brace factor has global \(H^{+-}\), again by Lemma
4.5(iv).

Gorsky--Steiner--Wiederrecht, Theorem 5.4, removes after expansion precisely
the members of the maximal family having two site vertices on each shore.
By (2), none remain in \(H\).  The bad child is therefore a brace.

> **Theorem 1.**  If a counterexample triple exists, every minimum-parent
> counterexample is a linear splice of global-\(H^{+-}\) braces from the
> \(p\)-factor to the \(q\)-factor, every nontrivial tight cut separates the
> whole edge \(p\) from the whole edge \(q\), and the expanded bad child is
> one brace.  The one-node chain, in which the parent is already a brace, is
> allowed.

The sole surviving tight-cut transition is therefore

\[
\boxed{
\text{linear global-}H^{+-}\text{ brace chain}
\longrightarrow
\text{one brace after a legal }C_4\text{-expansion}.}
\tag{4}
\]

## The first discriminating order

In the gadget-edge order

\[
(ua,ab,bv,xc,cd,dy,ad,bc),
\]

the six traversal rows are

\[
\begin{array}{c|c}
A&11111100\\
B&10101011\\
C&01010111\\
D&01111010\\
E&11001101\\
L&10110111.
\end{array}
\tag{5}
\]

The ordered gadget pairs \((ad,bc),(bc,ad),(ua,cd)\) privately force
\(D=X_{vx},E=X_{uy},L\), respectively.  Since every Barnette graph of order
at most \(66\) has global \(H^{+-}\), and expansion adds four vertices,

\[
\boxed{|V(G)|\le62\Longrightarrow D,E,L
\text{ exist at every legal site of }G.}
\tag{6}
\]

Thus the first order at which a missing one of these three traversals can
distinguish preservation is

\[
\boxed{64\text{-vertex parent}\longrightarrow68\text{-vertex child}.}
\tag{7}
\]

## Exact cap signatures at one splice

Write one splice cut as

\[
\delta=\{e_1,e_2,e_3\},\qquad e_i=a_i b_i,
\]

where \(a_i\) lies on the \(p\)-shore and \(b_i\) on the \(q\)-shore.
After deleting \(p\), let \(P_i^L\) mean that the left shore has a spanning
\(v\)-\(a_i\) path.  Let \(K_i^L\) mean that it has two vertex-disjoint paths
covering all shore vertices with pairing

\[
(v,a_i)(a_j,a_k),\qquad\{i,j,k\}=\{1,2,3\}.
\]

Define \(P_i^R,K_i^R\) analogously after deleting \(q\), with special
endpoint \(x\).  A zero-edge distinguished path is allowed when a special
endpoint is itself a port.  No additional cycle component is allowed.  Put

\[
P_L=\{i:P_i^L\},\quad K_L=\{i:K_i^L\},\qquad
P_R=\{i:P_i^R\},\quad K_R=\{i:K_i^R\}.
\tag{8}
\]

A spanning \(v\)-\(x\) path crosses a three-edge cut once or three times.
In the once-crossing case the two shore paths must use the same port.  In
the three-crossing case, tracing the four local path components shows that
different distinguished indices form one path, while equal indices form a
\(v\)-\(x\) path and one disjoint cycle.

> **Theorem 2 (cap-signature criterion).**
> \[
> D=X_{vx}\text{ exists across this splice}
> \quad\Longleftrightarrow\quad
> P_L\cap P_R\ne\varnothing
> \ \text{or}\ 
> \exists i\in K_L,\ j\in K_R\text{ with }i\ne j.
> \tag{9}
> \]

Failure has the exact normal form

\[
P_L\cap P_R=\varnothing
\tag{10}
\]

together with an empty \(K\)-set on one shore, or

\[
K_L=K_R=\{i\}
\tag{11}
\]

for one common index \(i\).

The common face meets \(\delta\) in exactly two edges, say \(e_1,e_2\),
and \(e_3\) is off the face.  When the special endpoint is distinct from the
ports, planar boundary rotation rules out \(K_3\), the crossing pairing, but
both \(K_1,K_2\) remain possible.  Reversal of the boundary orientation on
the other shore does not rename the physical cut edges.  Endpoint--port
coincidences only make the local list more rigid.  Thus planarity and complete
ordinary cap-Hamilton port-pair availability do not imply (9).

An abstract obstruction may have every ordinary cap-Hamilton port pair but

\[
P_L=P_R=\varnothing,\qquad K_L=K_R=\{1\}.
\tag{12}
\]

It glues to a \(v\)-\(x\) path plus one residual cycle.  This is not a graph
counterexample: it omits the common perfect-matching incidence and
alternating-exchange closure of actual braces.

## Remaining boundary

Theorem 1 is a general reduction for the full global-\(H^{+-}\) preservation
problem.  Theorem 2 isolates only one cross traversal at one cut.  It neither
proves that a chain parent is impossible nor settles the mixed and
retained--retained blocks of child global \(H^{+-}\).

The next brace-level question is whether actual perfect-matching families
can realise the failure forms (10)--(11), or whether brace exchange forces a
common one-port state or two distinct zero-residual three-port states.  Any
positive proof must use that shared incidence; ordinary port Hamilton
completeness and planar rotation have already been factored out.
