> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Multiple-hole cap loads stop at fixed-partition barrier exchanges

[Note 054](054-brace-factors-have-off-diagonal-three-port-cap-flexibility.md)
proves the one-hole three-port load bound by a same-colour forest pivot.
For several holes, the corresponding weak bound is valid in the natural
graphic--degree relaxation, but that relaxation already loses the fixed
terminal partition in the cube.  Inside a fixed fibre, a minimum overload
reduces instead to a Hall-tight shore or a pivot that must first increase
the load.  These statements are strict reductions, not a proof or
counterexample to the multiple-hole bound itself.

## The fixed-fibre problem

Let \(F\) be a simple cubic bipartite brace with bipartition
\(X\sqcup Y\), fix \(r\in Y\), and put \(P=F-r\).  Write

\[
N_F(r)=T=\{t_1,t_2,t_3\}\subseteq X,\qquad
\pi_i=\bigl\{\{i\},[3]\setminus\{i\}\bigr\}.
\]

Let \(\mathcal F_i\) be the spanning forests \(J\) of \(P\) with two
components whose port partition is \(\pi_i\), in which every port has
degree one and every other \(X\)-vertex has degree two.  For nonempty
\(H\subseteq Y\setminus\{r\}\), put

\[
\ell_H(J)=\sum_{h\in H}\deg_J(h),\qquad
\omega_i(H)=\min_{J\in\mathcal F_i}\ell_H(J).
\tag{1}
\]

The proposed weak and strong bounds are

\[
\omega_i(H)\le 2|H|, \tag{2}
\]

and, for \(|H|\ge2\),

\[
\omega_i(H)\le 2|H|-1. \tag{3}
\]

Neither (2) nor (3) is decided here.

For \(K_J=E(P)\setminus E(J)\), every \(x\in X\) is incident with exactly
one edge of \(K_J\), and

\[
2-\deg_J(y)=\deg_{K_J}(y)-1,\qquad
\sum_{y\in Y\setminus\{r\}}\bigl(\deg_{K_J}(y)-1\bigr)=1.
\tag{4}
\]

Thus (2) asks whether the unique net complement surplus can be moved
nonnegatively into \(H\) while the fixed partition \(\pi_i\) is retained.

## A Hall-certified fractional point

For \(e\in E(P)\), define

\[
z^0_e=
\begin{cases}
\frac12,&e\text{ is incident with a port},\\[2mm]
\frac23,&\text{otherwise}.
\end{cases}
\tag{5}
\]

Then

\[
z^0(\delta_P(x))=
\begin{cases}
1,&x\in T,\\
2,&x\in X\setminus T,
\end{cases}
\tag{6}
\]

and every \(y\in Y\setminus\{r\}\) has incident \(z^0\)-load at most
two.  Hence

\[
z^0(\delta_P(H))\le2|H|. \tag{7}
\]

The point \(z^0\) belongs to the graphic forest polytope of \(P\).
Indeed, take \(W=A\sqcup B\subseteq V(P)\), where
\(A\subseteq X\), \(B\subseteq Y\setminus\{r\}\), and write
\(a=|A|\), \(b=|B|\), \(p=|A\cap T|\).  The two colour-side degree
bounds give

\[
z^0(E_P[W])\le2a-p,\qquad z^0(E_P[W])\le2b. \tag{8}
\]

If \(a\ne b\), or if \(a=b\) and \(p\ge1\), (8) gives
\(z^0(E_P[W])\le a+b-1\).  The only remaining case is
\(a=b\) and \(p=0\).  If \(E_P[W]\) contained at least \(3a-1\)
edges, at most one of the \(3a\) edges incident with \(A\) would end
outside \(B\), and hence

\[
|N_F(A)|\le a+1.
\]

Because \(A\cap T=\varnothing\), one has
\(1\le a\le |X|-3\), contradicting the brace strict Hall inequality
\(|N_F(A)|\ge |A|+2\).  Therefore

\[
z^0(E_P[W])
\le\frac23(3a-2)<2a-1=|W|-1. \tag{9}
\]

Equations (8)--(9) prove every graphic-rank inequality.

Intersect the graphic forest polytope with the partition-matroid
constraints

\[
z(\delta_P(x))\le
\begin{cases}
1,&x\in T,\\
2,&x\notin T.
\end{cases}
\tag{10}
\]

This matroid-intersection polytope is integral.  Its face of total size
\(2|X|-3\) saturates every constraint in (10), so minimizing the
\(H\)-load on that face and using (7) gives an integral forest \(J\)
with the prescribed \(X\)-degrees and

\[
\ell_H(J)\le2|H|. \tag{11}
\]

It has exactly two components.  They need not induce the specified
port partition: the forest may lie in any of the three \(1\mid2\)
fibres, or it may have port distribution \(0\mid3\).

## The cube separates a fixed fibre from the uniform point

The loss of the fixed partition in (10) is genuine at the minimum
possible order.  Let \(F\) be the cube with graph6 string

\[
\texttt{G?zTb\_},
\]

using

\[
\begin{aligned}
E(F)=\{&04,05,06,14,15,17,24,26,27,35,36,37\},\\
X&=\{4,5,6,7\},\qquad Y=\{0,1,2,3\}.
\end{aligned}
\]

Take \(r=0\), so \(T=(4,5,6)\).  Relabel these three port positions
locally as \(0,1,2\), and fix
\(\pi_0=\{0\}\mid\{1,2\}\), with port \(4\) alone.  This fibre has
exactly six forests.  All six satisfy the valid fibre inequality

\[
\begin{aligned}
&\mathbf1_J(14)+\mathbf1_J(15)+\mathbf1_J(17)\\
&\qquad+\mathbf1_J(24)+\mathbf1_J(26)+\mathbf1_J(27)\le3,
\end{aligned}
\tag{12}
\]

with left sides \(3,3,2,3,3,2\).  At the uniform point (5), the same
linear form has value

\[
4\left(\frac12\right)+2\left(\frac23\right)=\frac{10}{3}>3. \tag{13}
\]

Consequently

\[
z^0\notin
\operatorname{conv}\{\mathbf1_J:J\in\mathcal F_0\}. \tag{14}
\]

This is not caused only by the \(0\mid3\) forests.  The same \(z^0\)
is the convex combination, with coefficients
\((1/6,1/3,1/3,1/6)\), of the four legitimate forests

\[
\begin{aligned}
&\{14,15,17,27,36\},&
&\{14,17,26,35,37\},\\
&\{15,24,27,36,37\},&
&\{17,24,26,27,35\},
\end{aligned}
\tag{15}
\]

lying in the other two fibres \(\mathcal F_2,\mathcal F_2,
\mathcal F_1,\mathcal F_1\), respectively.  The six \(0\mid3\)
forests also average uniformly to \(z^0\), showing that they form a
second, separate widening of (10).

The only smaller simple cubic bipartite brace is \(K_{3,3}\).  After
deleting any root, each fixed fibre has two representatives whose
half--half average is \(z^0\).  Thus the cube is the minimum-order
counterexample to universal fixed-fibre membership of the uniform point.
It does not violate (2): it separates only this proposed convex proof.

## Minimum overload branches

Assume that (2) fails in a feasible fixed fibre and put

\[
L=\min_{J\in\mathcal F_i}\ell_H(J)>2|H|. \tag{16}
\]

Choose an \(L\)-minimizer \(J\) with as few degree-three holes as
possible.  Some \(h\in H\) has \(\deg_J(h)=3\).  Among all port-free
components \(C\) of \(J-h\), over all such \(h\), choose one of minimum
order.  Put

\[
U=X\cap C,\qquad V=Y\cap C.
\]

The branch contains no port, and the degree count in its tree gives

\[
|U|=|V|. \tag{17}
\]

Strict Hall expansion supplies an edge

\[
e=xy,\qquad x\in U,\quad y\notin V\cup\{h\}. \tag{18}
\]

This edge is absent from \(J\).  Let \(f=xy_f\) be the first edge of
the \(J\)-path from \(x\) toward \(h\).  Then

\[
J'=J-f+e \tag{19}
\]

is a forest in the same fibre: the detached part is port-free and is
reattached without changing the port partition.  Its load change is

\[
\ell_H(J')-\ell_H(J)
=\mathbf1_H(y)-\mathbf1_H(y_f). \tag{20}
\]

The two minimizations impose the following alternatives.

1. Every exit (18) ends in \(H\).  An exit to \(Y\setminus H\) either
   lowers (20), or preserves the load while leaving a smaller
   port-free branch at the same degree-three hole.
2. A zero-cost exit must have \(f=xh\).  It replaces the attachment
   \(xh\) by \(xy\).  Minimality of the number of degree-three holes
   forces \(\deg_J(y)=2\), so the overload token moves from \(h\) to
   \(y\), while \(J[C]\) is unchanged.
3. Every other exit has \(y\in H\), \(y_f\notin H\), and raises the
   load by one.

Let \(R_0\subseteq H\) be the possible attachment holes reached by the
zero-cost transfers, and let \(G\subseteq H\) be the endpoints of the
positive exits from interior vertices of \(C\).  The attachment vertex
has one edge in \(J[C]\), so cubicity gives \(|R_0|\le2\).  Moreover,

\[
N_F(U)=V\cup R_0\cup G,\qquad |R_0\cup G|\ge2. \tag{21}
\]

Thus a minimum overload branch has exactly one of two forms:

- if \(G=\varnothing\), then \(|R_0|=2\) and
  \[
  |N_F(U)|=|U|+2, \tag{22}
  \]
  a Hall-tight shore permitted in a brace;
- if \(G\ne\varnothing\), every route visible from this branch but
  absent from its nonincreasing token class first crosses a pivot of
  load \(+1\).

The no-gate shore in the first alternative is necessarily atomic.  Let
\(x_0\in U\) be the attachment vertex of \(C\) at the overload hole.
When \(G=\varnothing\), every neighbour of
\(U\setminus\{x_0\}\) lies in \(V\).  If \(|U|\ge2\), strict Hall
applied to the nonempty port-free set \(U\setminus\{x_0\}\) gives

\[
|N_F(U\setminus\{x_0\})|
\ge |U\setminus\{x_0\}|+2=|U|+1>|V|,
\tag{23}
\]

a contradiction.  Hence

\[
U=\{x_0\},\qquad V=\{v\},\qquad C=x_0v. \tag{24}
\]

The cut \(\delta_F(\{x_0,v\})\) has four edges, two in each bipartite
direction.  The two edges from \(x_0\) go to the two holes in the
zero-cost token class.

Ordinary strict Hall expansion therefore stops exactly at a Hall-tight
atomic edge-shore or a barrier-one positive gate.  It does not
contradict a putative failure of (2).

## The atomic shore is not automatically reducible

Deleting \(x_0,v\) from (24) leaves two \(X\)-side and two \(Y\)-side
boundary vertices.  There are two bipartite pairings that restore
cubicity.  The local no-gate state does not force either smoothing to
be a smaller brace.

A real example is the order-twenty brace

\[
\texttt{S???????DAICi?\_g@o?I\_F?@@O?d?B?\_?}.
\]

It has a root \(r=10\), ports \((0,2,7)\), and a forest in the fibre
\((0,2)\mid(7)\) whose omitted-edge endpoints in \(X\)-order
\((0,\ldots,9)\) are

\[
(13,11,19,11,16,14,14,15,13,17). \tag{25}
\]

For holes \(H=\{12,16\}\), the atomic no-gate branch is
\(x_0v=4\,14\), with

\[
\deg_J(12)=3,\qquad \deg_J(16)=2,\qquad \deg_J(14)=1,
\]

and cut

\[
\delta_F(\{4,14\})
=\{4\,12,4\,16,5\,14,6\,14\}. \tag{26}
\]

The smoothing \(\{5\,16,6\,12\}\) is not simple because \(5\,16\)
already exists.  The other smoothing
\(\{5\,12,6\,16\}\) is simple, connected, cubic and bipartite, but it
is not a brace: the \(X\)-set \(\{3,6,8\}\) has neighbourhood
\(\{11,13,16,18\}\), of size only \(|\{3,6,8\}|+1\).

This example is nonplanar and the displayed forest is not asserted to
minimize the \(H\)-load.  It therefore neither refutes (2) nor closes a
plane minimum-counterexample reduction.  It proves the narrower
boundary that no-gate local data and the brace hypothesis alone do not
guarantee a brace-preserving smoothing.  Any such reduction must retain
the two smoothing admissibilities and the cap states induced by the
new smoothing edges.

Even when one smoothing
\(\sigma=\{ah_j,bh_k\}\) is a brace, its ordinary weak bound is not
enough to lift a low-load forest.  For a reduced representative \(J'\),
put

\[
S(J')=J'\cap\sigma.
\]

The reverse lifts divide exactly as follows.

1. If \(|S|=1\), replace the selected smoothing edge \(ah_j\) by
   \(a-v-x_0-h_j\).  This always preserves acyclicity, the port
   partition and the prescribed \(X\)-degrees.
2. If \(|S|=0\), attach the new leaf path \(h_j-x_0-v\).  With
   \(H'=H\setminus\{v\}\) and
   \(\epsilon=\mathbf1_{\{v\in H\}}\), the load is
   \[
   \ell_H(\operatorname{lift}J')
   =\ell_{H'}(J')+1+\epsilon.
   \]
   A reduced weak-bound witness at equality therefore loses one unit
   when \(v\notin H\).
3. If \(|S|=2\), remove both smoothing edges and insert \(av,bv\).
   The vertex \(x_0\) must then use two of
   \(x_0h_0,x_0h_1,x_0v\).  Whether one of these choices preserves a
   forest with the original \(\pi_i\) depends on the component
   partition induced on \(a,b,h_0,h_1\), decorated by the three ports.

Thus a genuine contraction requires a profile

\[
(S,\rho,\lambda),
\]

where \(S\) is smoothing-edge occupancy, \(\rho\) is this decorated
boundary partition after deleting \(S\), and \(\lambda\) is its minimum
hole load.  Neither brace-admissibility of a smoothing nor this profile
is contained in the local no-gate data.

## A real barrier-one plateau

Even when the strong bound (3) is true, a decreasing or nonincreasing
same-\(X\) route need not reach it.  In the planar twelve-vertex brace

\[
\texttt{K??FEagT@WB\_},
\]

take \(r=0\), ports \((6,7,8)\), the fibre with port \(6\) alone, and
\(H=\{3,4\}\).  Two states form a sink plateau at load four.  In the
\(X\)-order \((6,7,8,9,10,11)\), their omitted-edge endpoint tuples are

\[
(1,1,2,3,4,5),\qquad(2,1,2,3,4,5), \tag{27}
\]

and their \(Y\setminus\{r\}\)-degree vectors are

\[
(1,2,2,2,2),\qquad(2,1,2,2,2). \tag{28}
\]

Every same-\(X\) pivot leaving this plateau raises the \(H\)-load to
five, while the exact fibre minimum is three.  A shortest load sequence is

\[
4\longrightarrow5\longrightarrow4\longrightarrow3. \tag{29}
\]

Hence a proof of (3) cannot be based on a nonincreasing pivot descent,
even in an actual planar brace.

## Consequence

The weak multiple-hole bound (2) is automatic before the terminal
partition is fixed, but the cube proves that the uniform fractional
certificate cannot be conditioned on an arbitrary \(\pi_i\).  Inside a
fixed fibre, any genuine failure is forced into the dichotomy
(21)--(24).  The remaining positive statement is therefore a coupled
exchange problem: cross a positive gate, or use additional plane/minimal
structure at the atomic edge-shore, and restore the same terminal
partition with a negative total load change.  The stronger equality-layer
problem must also allow a temporary increase, as (29) shows.

The exact rational cube certificate is verified by
[verify_cube_fixed_pi_uniform_counterexample.py](../scratch/review_fixed_pi_uniform_20260826/verify_cube_fixed_pi_uniform_counterexample.py).
The complete twelve-vertex fibre and the path (29) are verified by
[find_nonincreasing_pivot_trap.py](../scratch/barnette_surplus_transfer_20260826/find_nonincreasing_pivot_trap.py).
The atomic smoothing obstruction is verified by
[verify_no_gate_smoothing_counterexample.py](../scratch/barnette_no_gate_reduction_20260826/verify_no_gate_smoothing_counterexample.py).
