> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A 40-state reflected closure for the CEN/UV \(H^{+-}\) interface

This note corrects and strengthens the six-role transfer interface of
[Note 165](165-seed-signature-transfer-for-cen-uv-h-plus-minus.md).  The
original 22-state signed domain is closed under the two standard CEN/UV
maps, but it is not closed when the ordered four-terminal orientation is
changed at the next layer.

## Four local maps

Use the six roles

\[
 A=C_{11},\quad B=C_{10},\quad C=C_{01},\quad
 D=X_{vx},\quad E=X_{uy},\quad L=(uv)(xy).
\]

The reflected orientation is the ordered-terminal relabelling

\[
\sigma(u,v,x,y)=(x,y,u,v),
\]

which fixes \(A,L\) and exchanges \(B,C\) and \(D,E\).  Writing a relation
as target \(\leftarrow\) source, the four memberwise relations are

\[
\begin{array}{c|rrrrrr}
 &A&B&C&D&E&L\\ \hline
\mathrm{CEN}&BCL&E&D&A&A&A\\
\mathrm{UV}&ABL&E&D&C&A&A\\
\mathrm{CEN}_{\sigma}&BCL&D&E&A&A&A\\
\mathrm{UV}_{\sigma}&ABL&D&E&A&C&A.
\end{array}
\]

Each source role and each target role occurs in every relation.  The tables
come from an exact enumeration of the \(2^8\) local gadget-edge subsets,
with degree, connectivity, and terminal-pairing conditions imposed.

## The 22-state correction

Let \(\Sigma\) be the 22 signed states in Note 165, written \(P/N\), where
\(P\) records roles with a witness containing a retained edge and \(N\) roles
with a witness avoiding it.  The standard CEN and UV maps preserve
\(\Sigma\), but the direct reflected maps do not.  The smallest failures are

\[
 ADEL/ABCEL\longmapsto ABCDEL/ACDEL
 \quad(\mathrm{CEN}_{\sigma}),
\]

and

\[
 ABC/ADEL\longmapsto ADEL/ABCDL
 \quad(\mathrm{UV}_{\sigma}).
\]

There are respectively 10 and 21 failures among the 22 states.  Therefore
the reflected theorem cannot reuse the 22-state domain without enlarging
the invariant.

## Correct invariant and transfer checks

Define \(\Sigma^\ast\) to be the least forward closure of \(\Sigma\) under
the four maps above.  Exact closure gives

\[
 |\Sigma^\ast|=40,
 \qquad |\Sigma^\ast\setminus\Sigma|=18.
\]

For every state in \(\Sigma^\ast\), every one of the six retained positions
at every oriented site has both required local witnesses: a positive-role
witness with local bit \(0\), and a negative-role witness with local bit
\(1\).  This is \(40\times6=240\) checks for each of the four maps.

The joint-witness condition is also checked at birth.  For every ordered
pair of distinct retained gadget positions, some source-role/target-role
transition has local bits \((1,0)\); there are \(30\) ordered pairs for each
map.  The eight final gadget positions have all \(8\cdot7=56\) ordered
separations for each map.  Every birth state lies in \(\Sigma^\ast\).

Consequently the seed-signature transfer proof of Note 165 extends to any
finite sequence in

\[
\{\mathrm{CEN},\mathrm{UV},\mathrm{CEN}_{\sigma},\mathrm{UV}_{\sigma}\},
\]

provided the seed has the corresponding concrete six role families, signed
states in \(\Sigma^\ast\), all ordered joint-witness separations, and all
successor sites are legal Barnette sites.  A same-orientation reflected chain
is equivalently obtained by applying the role permutation
\((B\ C)(D\ E)\) to the seed data; the genuinely new statement is closure
under arbitrary switches between standard and reflected orientations.

This is a finite-state interface theorem.  It does not imply preservation
under arbitrary legal \(C_4\)-expansions, and it is not by itself a
Berge--Fulkerson or Barnette-conjecture resolution.

## Independent certificate

The result is reproduced by the pure-standard-library verifier:

    python3 units/barnette/scratch/worker-barnette/verify_reflection_40_state_h_plus_minus.py

The terminal marker is REFLECTION_40_STATE_H_PLUS_MINUS_VERIFIED.

The verifier uses no project module, networkx, random search, or solver.  The
certificate additionally checks the \(30\) retained-pair joint separations
per map, which are needed for the ordered \(H^{+-}\) conclusion.
