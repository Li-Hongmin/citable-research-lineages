> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four mandatory boundary rows give an exact carrier prefilter

[Note 158](158-complete-boundary-row-deletion-forces-fixed-carrier-crossing-compensation.md)
and
[Note 159](159-order24-carrier-forces-six-crossings-after-every-actual-factor-join.md)
show that the state-empty row of an annular factor cannot be used in
isolation: its two undeleted square edges produce actual deletion rows and
additional rooted crossings at the two fixed carriers considered there.
This note extracts the carrier-independent content of that argument. Four
factor rows determine ten, and only ten, possible mandatory crossing
classes. Their sum is an exact prefilter for every carrier.

The prefilter is sharp at two on an actual order-16 legal-wide carrier.
Deleting one actual compatible row from that carrier leaves a strict
one-crossing abstract system. Thus the remaining obstruction is precisely
completeness of the common perfect-matching family, not planarity, the brace
axiom, or the local boundary atoms.

## 1. The four forced factor rows

Let a cubic factor contain a square

\[
Q=b_0b_1b_2b_3b_0,\qquad q_i=b_ib_{i+1}\quad(i\bmod4),
\]

and delete the opposite edges \(q_0,q_2\). Suppose its complete boundary
family contains rows \(N_0,N_1\) with

\[
\begin{array}{c|c|c}
\text{row}&\text{state}&\text{clean complement}\\ \hline
N_0&\varnothing&01\mid23\\
N_1&A_0=\{0,1\}&23
\end{array}
\]

and

\[
d_B(N_0,N_1)=01+0\text{ closed}.
\tag{1}
\]

The pairing of \(N_0\) forces \(q_1,q_3\in N_0\). Hence

\[
R_1=N_0-\{q_1\},\qquad R_3=N_0-\{q_3\}
\tag{2}
\]

are actual boundary rows of states \(A_1=\{1,2\}\) and
\(A_3=\{3,0\}\). Since \(N_1\) leaves ports \(0,1\) uncovered, neither
\(q_1\) nor \(q_3\) belongs to \(N_1\); these edges are the terminal edges
of the path in (1). The complete pair table of the four rows is therefore

\[
\begin{array}{c|cccc}
d_B&N_0&N_1&R_1&R_3\\ \hline
N_0&0&01&12&30\\
N_1&&0&02&13\\
R_1&&&0&12\mid30\\
R_3&&&&0.
\end{array}
\tag{3}
\]

Every nonzero entry in (3) has zero closed components. No further factor
incidence is needed for this table.

## 2. Ten carrier atoms

Let \({\cal C}_Z^b,{\cal C}_0^b,{\cal C}_1^b,{\cal C}_3^b\) be the complete
carrier-row sets of surviving-gate sector \(b\) which are rooted-compatible
with \(N_0,N_1,R_1,R_3\), respectively. For two carrier rows write

\[
d_C(K,L)=\pi_C+z_C\text{ closed}.
\]

There are four same-factor-row counts

\[
s_X=\#\{\{K,L\}:K\in{\cal C}_X^0,\ L\in{\cal C}_X^1,
                    \ d_C(K,L)=1\text{ closed}\},\qquad
X\in\{Z,0,1,3\}.
\tag{4}
\]

There are five one-path counts

\[
\begin{aligned}
p_{Z0}&=\#\{K\in{\cal C}_Z^0,L\in{\cal C}_0^1\text{ or conversely}:
                d_C(K,L)=01+0\},\\
p_{Z1}&=\#\{K\in{\cal C}_Z^0,L\in{\cal C}_1^1\text{ or conversely}:
                d_C(K,L)=12+0\},\\
p_{Z3}&=\#\{K\in{\cal C}_Z^0,L\in{\cal C}_3^1\text{ or conversely}:
                d_C(K,L)=30+0\},\\
p_{01}&=\#\{K\in{\cal C}_0^0,L\in{\cal C}_1^1\text{ or conversely}:
                d_C(K,L)=02+0\},\\
p_{03}&=\#\{K\in{\cal C}_0^0,L\in{\cal C}_3^1\text{ or conversely}:
                d_C(K,L)=13+0\}.
\end{aligned}
\tag{5}
\]

Finally let \(t_{13}\) count opposite-sector pairs in
\({\cal C}_1\times{\cal C}_3\) whose carrier difference has zero closed
components and one of the two pairings

\[
01\mid23,\qquad02\mid13.
\tag{6}
\]

The third pairing \(12\mid30\) is deliberately absent: it equals the factor
pairing in (3), so the two shores close into two cycles. Either pairing in
(6) differs from the factor pairing and the union is one cycle.

## 3. Exact prefilter theorem

Let \({\cal J}_4\) be the complete joined rooted subfamily whose factor
coordinate is one of \(N_0,N_1,R_1,R_3\). Then

\[
\boxed{
|E\Gamma_{g_1}({\cal J}_4)|=
s_Z+s_0+s_1+s_3+p_{Z0}+p_{Z1}+p_{Z3}+p_{01}+p_{03}+t_{13}.}
\tag{7}
\]

Indeed, equal factor rows cancel, so a joined difference is one cycle
exactly when the carrier difference is already one closed cycle. For each
one-path entry of (3), the two shores close into one cycle exactly when the
carrier has the same open path and no closed component. For the final
two-path entry, equal pairings make two cycles and unequal pairings make one.
The ten terms use distinct unordered pairs of factor coordinates, so there
is no double counting.

Consequently, if the designated \(N_0\)--\(N_1\) bond is to survive and the
complete splice is to have exactly one crossing, the carrier must satisfy

\[
\boxed{
p_{Z0}=1,\qquad
s_Z=s_0=s_1=s_3=p_{Z1}=p_{Z3}=p_{01}=p_{03}=t_{13}=0.}
\tag{8}
\]

Equation (8) is necessary, not sufficient: additional factor rows may add
crossings. Conversely, any carrier for which the right side of (7) is at
least two rejects every actual factor satisfying (1), regardless of all
its additional rows.

## 4. Endpoint deletion does not prove the prefilter

Suppose a designated carrier slot is

\[
K_Z\in{\cal C}_Z^0,\qquad K_0\in{\cal C}_0^1,\qquad
d_C(K_Z,K_0)=01+0.
\tag{9}
\]

Restore the two cut edges as complement edges and smooth the distant root.
The \(Z\)-compatibility of \(K_Z\) gives a Hamilton cycle. If \(K_Z\)
used neither surviving square edge \(q_1,q_3\), that Hamilton cycle would
contain all four square edges and the square would be an isolated component.
Thus \(K_Z\) contains at least one of \(q_1,q_3\).

Deleting an occupied \(q_i\) gives an actual carrier row \(L_i\) in the
corresponding state \(A_i\). Its bond atom with \(K_0\) is automatically
\(02+0\) for \(i=1\), or \(13+0\) for \(i=3\). Hence rooted compatibility
of \(L_i\) would immediately contribute \(p_{01}\) or \(p_{03}\) and prove
\(M\ge2\).

That last compatibility implication is false. In the order-22 carrier
of [Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md),
both literal deletion rows of the designated \(Z\)-endpoint fail the rooted
test: one already has a closed complement component and the other is closed
by the factor path. The two compensating crossings of
[Note 158](158-complete-boundary-row-deletion-forces-fixed-carrier-crossing-compensation.md)
come from other carrier rows. Endpoint deletion, unary Hamilton parity and
pointwise brace exchange therefore do not prove (8) impossible.

## 5. A sharp actual carrier and a one-row abstract defect

Consider the order-16 graph

~~~text
O????B_sDOI_I_DO@W?M?
~~~

with

\[
\begin{aligned}
Q&=(8,2,10,0),&e&=2\!-\!8,&g_0&=0\!-\!10,&g_1&=7\!-\!13,\\
(a_0,a_1,a_2,a_3)&=(5,13,7,15).
\end{aligned}
\tag{10}
\]

It is a simple plane cubic bipartite brace, the two closed gate arcs both
have cardinality five, and the corresponding inverse split remains a brace.
The complete compatible carrier sets have sizes

\[
|{\cal C}_Z|=1,\qquad |{\cal C}_0|=1,\qquad
|{\cal C}_1|=2,\qquad |{\cal C}_3|=2.
\tag{11}
\]

Their mandatory count is exactly

\[
\boxed{M=p_{Z0}+p_{03}=2.}
\tag{12}
\]

The two literal slots are \(K_2K_{10}\) with atom \(01+0\), and
\(K_{10}K_{20}\) with atom \(13+0\). Thus no universal lower bound greater
than two is possible.

Now retain the same graph, embedding, legal-wide geometry, the other five
actual compatible rows and every literal complement and pair atom, but omit
only the actual \(A_3\)-row \(K_{20}\). The restricted row system has

\[
M=1.
\tag{13}
\]

This is not an actual carrier because \(K_{20}\) is a genuine compatible
perfect-matching row and the complete family cannot omit it. It is however
a one-defect countermodel: zero omissions give the actual system, while one
specific omission gives (13). The first missing axiom is exactly universal
completeness of the common perfect-matching family. All local boundary
atoms and all geometric carrier hypotheses survive.

## 6. Remaining boundary

The general carrier statement

\[
p_{Z0}>0\quad\Longrightarrow\quad M\ne1
\tag{14}
\]

remains unproved and unrefuted. Equations (7)--(8) show that it is the exact
carrier-side assertion needed to close every annular-factor realization of
the designated bond. The one-row countermodel shows that no proof using
only the retained pair atoms, planarity, cubicity, bipartiteness or the brace
property can establish it. A proof must force reuse or replacement of the
missing row from the complete perfect-matching incidence family; a
counterexample must realize all ten zero conditions in (8) simultaneously.

The fixed
[verification bundle](../computations/bundles/carrier-mandatory-four-row-prefilter/README.md)
reconstructs the order-16 carrier, all perfect matchings and boundary
rows, the two slots in (12), and the one-row defect (13). Its terminal
marker is
`ORDER16_CARRIER_M2_AND_NEAR_M1_STANDALONE_VERIFIED`.
