> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cofacial non-brace has a genuine integral paid-exit obstruction

[Note 050](050-cycle-cut-compatibility-does-not-force-integral-paid-exit-discharge.md)
shows abstractly that local block types and exact cycle--cut compatibility
do not force integral paid-exit discharge.  Its minimal blocker has no
legal cofacial cubic completion.  This note proves that cofacial cubic
completion is still not sufficient: a genuine simple connected plane cubic
bipartite site has a unique two-point paid-exit deficit while every full
common base is over budget.  The graph is not a brace, so the brace
hypothesis cannot be removed wholesale from the remaining conjecture.

## The plane graph and site

Let \(F_2\) have vertex set \(\mathbb Z/16\mathbb Z\), the Hamilton cycle

\[
01,12,\ldots,14\,15,15\,0,
\]

and chords

\[
03,\ 16,\ 25,\ 47,\ 8\,11,\ 9\,14,\ 10\,13,\ 12\,15.
\tag{1}
\]

It is simple, connected, cubic, and bipartite with the parity
bipartition.  The following facial walks specify a plane embedding:

\[
\begin{gathered}
0321,\quad 0\,15\,14\,9\,8\,7\,4\,3,\quad
0\,1\,6\,7\,8\,11\,12\,15,\\
1256,\quad2345,\quad4765,\quad8\,9\,10\,11,\quad
9\,14\,13\,10,\\
10\,13\,12\,11,\quad12\,13\,14\,15.
\end{gathered}
\tag{2}
\]

Every edge occurs twice in opposite directions in (2), and
\(16-24+10=2\).  On the facial \(4\)-cycle \(1\,6\,5\,2\), take

\[
(u,v,z,a)=(2,1,6,5).
\tag{3}
\]

Then \(u,z\) lie in the same bipartition class, so (3) is an ordered legal
cofacial site.

Delete \(u=2\) and \(a=5\), contract the duals of \(21\) and \(65\), and
write \(Q\) for the retained contracted dual.  Number its vertices
\(0,\ldots,7\), with contracted root \(3\).  The \(X\)-blocks and rank
endpoints are

\[
\begin{array}{c|l}
D_0&01:03,\quad03:13,\quad0\,15:01\\
D_4&34:12,\quad47:13\\
D_6&16:03,\quad67:03\\
D_8&78:01,\quad89:04,\quad8\,11:14\\
D_{10}&9\,10:45,\quad10\,11:46,\quad10\,13:56\\
D_{12}&11\,12:16,\quad12\,13:67,\quad12\,15:17\\
D_{14}&9\,14:05,\quad13\,14:57,\quad14\,15:07.
\end{array}
\tag{4}
\]

Here \(rs:ij\) means that the primal label \(rs\) has rank endpoints
\(i,j\).  Table (4) follows directly by reading the two faces incident
with each retained edge in (2), then identifying the faces incident with
the two contracted special edges.

## Every full common base is over budget

Take

\[
A=\{3,9,11,13,15\}\subseteq Y\setminus\{a\}.
\tag{5}
\]

A label has cost zero exactly when its odd endpoint is \(1\) or \(7\).
The zero-cost labels are

\[
01,\ 16,\ 47,\ 67,\ 78.
\tag{6}
\]

Let \(B\) be any \(Q\)-tree \(X\)-transversal.  Block
\(D_6=\{16,67\}\) forces one zero-cost choice, and both labels are the
rank edge \(03\).

There is no second zero-cost choice:

1. \(01:03\) would be parallel to the forced edge from \(D_6\).
2. Rank vertex \(2\) is incident only with \(34:12\), so a spanning tree
   must choose \(34\) from \(D_4\), not \(47\).
3. If \(D_8\) chose \(78:01\), then \(D_0\) could not choose \(01:03\);
   choosing \(0\,15:01\) would be parallel to \(78\), while choosing
   \(03:13\) together with the forced \(03\) edge and \(78\) would form
   the rank triangle \(0\,1\,3\,0\).

All labels in \(D_{10},D_{12},D_{14}\) have cost one.  The preceding
argument also forces cost-one choices in \(D_0,D_4,D_8\).  Every full
common base therefore has exactly one zero-cost label, and

\[
\boxed{c_A(B)=6>|A|=5\quad\text{for every full common base }B.}
\tag{7}
\]

This proves the strict cost gap without enumerating the bases.

## A one-hole transversal and its paid completions

Consider

\[
R=\{01,16,34,8\,11,9\,10,11\,12,13\,14\}.
\tag{8}
\]

It chooses one label from every \(X\)-block and satisfies

\[
c_A(R)=5=|A|.
\tag{9}
\]

Its selected rank multigraph is the disjoint union of the double edge
\(\{01,16\}\) on

\[
W=\{0,3\}
\]

and the tree with labels

\[
34:12,\quad8\,11:14,\quad9\,10:45,\quad
11\,12:16,\quad13\,14:57
\]

on \(V(Q)\setminus W\).  Hence

\[
\mathcal V(R)=\{W\},\qquad
|R\cap E_Q(W)|=2>|W|-1=1.
\tag{10}
\]

Indeed, adjoining a nonempty exterior set \(T\) to \(W\) induces at most
\(2+(|T|-1)=|W\cup T|-1\) selected edges, while a shore containing at
most one vertex of \(W\) satisfies the forest bound.  Thus \(W\) is the
unique proper rank violation.

The block \(D_6\) is wholly internal to \(W\).  The other selected internal
label \(01\in D_0\) has exactly the two boundary exits

\[
03:13,\qquad0\,15:01.
\]

Both replacements

\[
R-01+03,\qquad R-01+0\,15
\tag{11}
\]

join the single retained rank edge on \(W\) to the exterior tree and are
therefore full \(Q\)-trees.  Both exits have their odd endpoint in \(A\),
so each completion has cost six.  Equation (7) proves that no later
common-base exchange can return to the budget.

Thus (3), (5), (8), and (10)--(11) form a genuine actual-site integral
paid-exit obstruction.

## The exact role of the missing brace hypothesis

The graph has the proper two-edge cut

\[
\{0\,15,78\}.
\tag{12}
\]

It is also directly non-brace.  The independent edges \(01\) and \(78\)
cannot extend to a perfect matching: deleting their four endpoints leaves
two components on

\[
\{2,3,4,5,6\}
\quad\text{and}\quad
\{9,10,11,12,13,14,15\},
\]

both of odd order.

Consequently the proposed integral paid-exit discharge statement is false
for general connected plane cubic bipartite graphs, even at an ordered
cofacial site and even when boundary completions exist.  The brace
hypothesis is logically load-bearing in the precise sense that deleting it
makes the universal statement false.

This example does not prove that the brace hypothesis is sufficient, that
\(2\)-extendability is the weakest sufficient replacement, or that
3-connectivity alone is insufficient.  Its mechanism uses the proper
two-edge cut together with the local face rotation; it does not show that
every two-edge cut obstructs discharge.  No order-minimality claim is made.

The fixed certificate independently reconstructs the embedding and
contracted dual, checks all \(972\) block transversals and \(112\) full
bases, verifies that (5) is the unique strict binary layer at this site,
and checks (8)--(12).  It is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_fixed_two_cut_paid_exit_counterexample.py

with terminal marker
FIXED_TWO_CUT_PAID_EXIT_COUNTEREXAMPLE_VERIFIED.
