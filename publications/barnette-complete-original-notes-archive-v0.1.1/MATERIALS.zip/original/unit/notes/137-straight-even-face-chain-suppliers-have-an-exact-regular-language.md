> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Straight even-face-chain suppliers have an exact regular language

[Note 136](136-hexagon-square-octagon-surgery-preserves-rooted-labels-but-is-not-locally-forced.md)
proves that adjoining one square to the third alternating edge of a
hexagonal site gives a root-label-preserving \(R_{00}\) supplier surgery.
This note determines exactly which straight chains of even faces have the
same universal property.  The answer is a regular language with one parity
condition.

## 1. Straight face chains and complete local signatures

Use the hexagonal site

\[
 H=x_0x_1x_2x_3x_4x_5x_0,
 \qquad
 p=x_0x_1,\quad q=x_2x_3,\quad r=x_4x_5
\tag{1}
\]

from Note 136.  Across \(r\), attach a nonempty sequence of simple even
faces

\[
 Q_1,Q_2,\ldots,Q_k.
\tag{2}
\]

For every \(Q_i\), specify the exit edge opposite its entry edge.  When
\(i<k\), this exit edge is the entry edge of \(Q_{i+1}\); the exit edge of
the terminal face \(Q_k\) remains on the exterior boundary of the disk.
Assume that the union

\[
 D=H\cup Q_1\cup\cdots\cup Q_k
\tag{3}
\]

is a plane disk, consecutive faces meet only in their common edge, and
nonconsecutive faces are disjoint.  Write

\[
 W=(|Q_1|,\ldots,|Q_k|)
\tag{4}
\]

for its straight face word.

Let \(C=\partial D\), and let \(M\) be a perfect matching with
\(p,q\in M\) such that \(C\) is \(M\)-alternating.  Put

\[
 F=M\mathbin\triangle E(C),
\tag{5}
\]

perform the standard \(C_4\)-expansion at \(p,q\) into \(H\), and let
\(F^R\) be the \(R_{00}\)-extension of \(F\).

For a complementary two-factor inside the disk, define its **complete
local signature**

\[
 \Sigma=(\Pi,c),
\tag{6}
\]

where \(\Pi\) is the noncrossing pairing induced on all exterior ports of
\(D\), and \(c\) is the number of complementary cycles lying wholly
inside \(D\).  Equality of these signatures is precisely the local
condition that preserves global component incidence for every exterior
connection.  It therefore preserves the number of complement cycles and
all ordered component labels carried by marks outside \(D\).

## 2. Exact word theorem

**Theorem 1 (straight-chain supplier language).**  Under the hypotheses
above,

\[
 \boxed{
 \Sigma_M=\Sigma_{F^R}
 \quad\Longleftrightarrow\quad
 W=w4,\quad
 w\in\{4,6\}^{*},\quad
 \#_4(w)\equiv0\pmod 2.}
\tag{7}
\]

Thus the terminal face must be a square, every internal face must be a
square or a hexagon, and the number of internal squares must be even.

In particular, if \(M\) is root-admissible and its root and forced
matching edges avoid \(E(C)\), every word in (7) produces a
root-admissible \(R_{00}\) child matching with the same ordered root
labels.  If the surviving gate also avoids \(E(C)\), its gate sector is
preserved.

The one-letter corollary is sharp:

\[
 W=(2m)\text{ is universally preserving}
 \quad\Longleftrightarrow\quad
 2m=4.
\tag{8}
\]

Hence the square of Note 136 is the unique single adjacent even face with
universal component-incidence preservation; an adjacent hexagon is the
minimum failure.

## 3. Port-pairing classification

Consider an internal \(2m\)-face.  Removing its specified opposite entry
and exit edges leaves

\[
 s=m-2
\tag{9}
\]

exterior ports on each side.  The two complementary phases create no
irreversible side-port partner mismatch exactly when \(s\le1\).  The
remaining phase difference for a square is a possible closed local
component, which is accounted for separately in Section 4.  Thus there
are exactly two letters that survive the port-partner test.

1. For a square, \(s=0\).  There are no side ports; the letter only
   transports the two interface strands.
2. For a hexagon, \(s=1\).  In either phase its two side ports are joined
   to each other.  The remaining entry or exit edge transports the
   interface state.

If \(m\ge4\), each side has at least two ports.  In one phase the first
side port is paired with its next side neighbour; in the other it is
paired across a shifted boundary interval.  Its partner therefore differs,
and no later face can repair the mismatch because later faces have
disjoint port sets.

For the terminal \(2m\)-face, the two exit-edge endpoints are also ports,
so the corresponding number of ports on each side is

\[
 s=m-1.
\tag{10}
\]

The two terminal phases agree only for \(s=1\), namely \(m=2\).  Therefore

\[
 \boxed{\Pi_M=\Pi_{F^R}\iff W\in\{4,6\}^{*}4.}
\tag{11}
\]

For completeness, when the chain consists of one \(2m\)-face, label its
\(2m-2\) nonentry ports in boundary order by
\(b_1,\ldots,b_{2m-2}\).  The two pairings are

\[
\begin{aligned}
 \Pi_M|_b
   &=(b_1b_2)(b_3b_4)\cdots
     (b_{2m-3}b_{2m-2}),\\
 \Pi_{F^R}|_b
   &=(b_1b_{2m-2})(b_2b_3)(b_4b_5)\cdots
     (b_{2m-4}b_{2m-3}).
\end{aligned}
\tag{12}
\]

They agree only when \(m=2\).  For \(m\ge3\), closing the exterior by the
first pairing gives \(m-1\) local components before surgery and one after
surgery.  This witnesses the failure in (8) without assumptions on the
exterior graph.

## 4. Closed-component recurrence

Port pairings alone do not prove (7), because a straight chain can create
closed complementary components inside the disk.  Let
\(\epsilon=1\) mean that the two side edges adjacent to the current entry
edge belong to the complement.

The two internal letters have the following exact transition table:

\[
\begin{array}{c|c|c|c}
\text{face}&\text{side ports}&\epsilon\text{ transition}
  &\text{new closed component}\\ \hline
4&0&\epsilon\mapsto1-\epsilon&1\text{ iff }\epsilon=1\\
6&1+1&\epsilon\mapsto\epsilon&0.
\end{array}
\tag{13}
\]

For the square row, \(\epsilon=1\) makes all four facial edges
complementary and hence creates one isolated \(C_4\); for
\(\epsilon=0\), the entry and exit strands remain open.  For the hexagon
row, its one port on each side lies on the local complement component, so
no closed component is possible.  The terminal square also creates no
closed component because its two exit vertices are exterior ports.

The parent configuration enters the chain with phase \(\epsilon=0\).
The boundary flip together with the \(R_{00}\) patch enters with the
opposite phase \(\epsilon=1\).  Hexagons preserve these phases, while every
internal square swaps them.  If

\[
 s=\#_4(w),
\tag{14}
\]

the incoming phases at the successive internal squares are therefore

\[
0,1,0,1,\ldots
\quad\text{and}\quad
1,0,1,0,\ldots
\tag{15}
\]

on the parent and \(R_{00}\) sides, respectively.  Hence

\[
 \boxed{
 c_M=\left\lfloor\frac{s}{2}\right\rfloor,\qquad
 c_{F^R}=\left\lceil\frac{s}{2}\right\rceil.}
\tag{16}
\]

The counts agree exactly when \(s\) is even.  Combining (11) and (16)
proves Theorem 1.

## 5. Boundary for the rooted split-bond problem

Theorem 1 supplies an arbitrary-length family of local, root-label
preserving \(R_{00}\) surgeries.  Its two failure mechanisms are sharp and
independent:

1. an internal \(8^+\)-face or a nonsquare terminal face changes an
   exterior port partner;
2. an odd number of internal squares preserves every port partner but
   changes the number of local complement cycles by one.

The theorem does not select an alternating boundary \(C\) in an actual
rooted plane brace.  As in Note 136, a pure-\(11\) parent bond need not
locally force any word in (7), and unary \(R_{00}\) occupancy still does
not provide the opposite-sector child partner required for full
split-bond supplementation.  The remaining interface is therefore an
actual complete-perfect-matching-family selection problem, not a further
local word calculation.
