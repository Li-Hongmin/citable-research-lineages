> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A common-\(B\) face can have exactly one rooted crossing

[Note 150](150-root-square-incidence-is-essential-and-polyhedral-connectivity-stops-at-root-admission.md)
shows that a sufficiently high-dimensional perfect-matching face has many
crossing edges, but leaves open whether the root-square fixed-pairing fibre
must contain a second one.  The answer is negative.  A fixed
\(32\)-vertex legal-wide plane brace has \(280\) crossing edges in the
relevant common-\(B\) face, while its rooted fixed-pairing subfibre has
exactly one.

Thus rootedness is not merely nonfacial in principle.  It can delete all
but one edge of a large coordinate cut in an actual simple plane cubic
bipartite brace with the required root-opposite square.

## 1. The fixed legal-wide brace

Use the graph \(G\) of
[Note 099](099-the-minimum-support-xor-cube-is-legal-wide-in-a-plane-brace-but-not-fibre-minimum.md).
It is obtained from the explicit \(28\)-vertex residual by attaching the
facial square

\[
 Q=u-v-x-y-u
\tag{1}
\]

in terminal order \((u,v,x,y)=(t_0,t_3,t_2,t_1)\).  Put

\[
 e=uv,\qquad g_0=xy,\qquad g_1=b_4b_5.
\tag{2}
\]

The graph \(G\) is simple, plane, cubic, bipartite and \(2\)-extendable.
The latter statement follows directly because its \(811\) perfect
matchings cover all \(1032\) independent edge pairs.  Hence \(G\) is a
brace.  The edges \(e,g_0\) are opposite in the root square \(Q\).

The common gate face has cyclic boundary

\[
 xy,\ xt_2,\ t_2x_5,\ x_5b_5,\ b_5b_4,\ b_4b_3,\ b_3t_1,\ t_1y.
\tag{3}
\]

Its two closed \(g_0\)-to-\(g_1\) arcs both have five vertices, so the
decoration is legal-wide.  Fix the further common gate-face edge

\[
 f=b_3t_1.
\tag{4}
\]

## 2. The full face and its rooted subfibre

Consider the perfect-matching-polytope face

\[
 \mathcal F
 =P(G)\cap\{x_e=x_{g_0}=x_f=1\}.
\tag{5}
\]

Complete enumeration gives

\[
 |V(\mathcal F)|=77=29+48,
\tag{6}
\]

where the two summands are the two \(g_1\)-sectors.  Two vertices of
\(\mathcal F\) are adjacent exactly when their symmetric difference is
one alternating cycle.  The full coordinate cut contains

\[
 280
\tag{7}
\]

such crossing edges.

Square deletion identifies the rooted targets containing \(e,g_0\) with
the fixed-pairing two-path fibre of [Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
After also fixing \(f\), exactly seven vertices of \(\mathcal F\) remain
rooted.  Their sector split is

\[
 7=1+6,
\tag{8}
\]

and their induced polytope graph has exactly one cross-sector edge.

In residual notation the sector-zero endpoint is

\[
\begin{aligned}
M^-=\{&a_0a_1,a_2b_4,a_3x_7,b_0x_1,b_1b_2,b_{10}b_{11},
b_3t_1,\\
&b_5b_6,b_7x_8,b_8b_9,t_0x_0,t_2t_3,x_2x_3,x_5x_9\},
\end{aligned}
\tag{9}
\]

and its unique adjacent sector-one endpoint is

\[
\begin{aligned}
M^+=\{&a_0a_3,a_1a_2,b_0x_1,b_1b_2,b_{10}b_{11},b_3t_1,
b_4b_5,\\
&b_6b_7,b_8b_9,t_0x_0,t_2t_3,x_2x_3,x_5x_9,x_7x_8\}.
\end{aligned}
\tag{10}
\]

The corresponding matchings of \(G\) are obtained by adding
\(\{e,g_0\}\).  Their symmetric difference is the alternating cycle

\[
 a_0a_1a_2b_4b_5b_6b_7x_8x_7a_3a_0.
\tag{11}
\]

It contains \(g_1\), while \(e,g_0,f\) are common.  On the gate face (3),
the two lifted matchings have word

\[
 \boxed{\mathtt{B000M0B0}},
\tag{12}
\]

one of the three minimum root-square-admissible singleton-shore words from
[Note 149](149-legal-wide-face-words-do-not-determine-one-bond-rooted-selection.md).

Equations (6)--(12) prove:

> **Common-\(B\) fixed-face counterexample.**  A common-\(B\)
> perfect-matching face of a legal-wide simple plane cubic bipartite brace
> with a root-opposite square can have many full-family cross-sector edges
> but exactly one cross-sector edge whose two endpoints are rooted.

## 3. Exact failure of polyhedral escape

Among the \(280\) full-face crossing edges, classify an endpoint by whether
it is rooted.  The exact profile is

\[
 (0,0)^{242},\qquad
 (0,1)^{34},\qquad
 (1,0)^3,\qquad
 (1,1)^1.
\tag{13}
\]

Thus the additional crossing edges forced by Balinski connectivity can all
leave the rooted fibre.  Fixing \(e,g_0,f\) does not make complement
component count or terminal pairing convex, facial, or closed under
single-cycle exchange.  This strictly refutes the fixed-pairing face-escape
problem posed in Note 150.

The result does not refute the unconditioned implication

\[
 \Gamma_{g_1}(\mathcal T_e)\ne\varnothing
 \Longrightarrow
 |E\Gamma_{g_1}(\mathcal T_e)|\ne1.
\tag{14}
\]

The same complete rooted fibre before fixing \(f\) has \(41=16+25\)
vertices and \(69\) cross-sector single-cycle edges.  Hence the common
\(B\)-face route is now closed, but the original one-bond selection problem
still requires an interaction across different gate-face occupancy classes
or an equivalent global invariant.

The fixed
[verification bundle](../computations/bundles/common-b-face-unique-rooted-crossing/README.md)
reuses the permanent Note 099 graph and exhausts both the \(77\)-vertex
face and its seven rooted vertices.  Its terminal marker is
COMMON_B_UNIQUE_ROOTED_CROSSING_VERIFIED.

[Note 152](152-root-square-crossing-edges-can-be-bridges.md) shows that
crossing edges need not be nonbridges in general, but also records the
specific compensation here: the fixed-\(f\) edge has two rooted triangle
witnesses in the full fibre, and both witnesses omit \(f\).
