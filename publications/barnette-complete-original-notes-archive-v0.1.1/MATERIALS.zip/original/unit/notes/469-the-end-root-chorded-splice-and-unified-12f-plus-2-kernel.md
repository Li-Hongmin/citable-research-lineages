> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The end-root chorded splice and a unified \(12f+2\) kernel

[Notes 466–468](468-four-exterior-paths-close-the-disconnected-central-chorded-roots.md) leave only one root before \(z_L\) or, by reflection, after \(z_R\) at the chorded \(c=5f-6\) equality boundary. In the end-root placement, four exterior paths and the open root arcs form a spanning two-factor. Its leaf-square quotient is connected unless the parent has a two-edge cut.

Use the chorded all-leaf profile of [Note 466](466-the-chorded-100-vertex-frontier-has-two-leaf-roots-and-two-exterior-face-chords.md) with order
\[
 w_0,W_1,z_L,t_c,W_2,t_b,z_R,w_*,
           \alpha,a,b,c,d,\beta,w_0.
\tag{1}
\]
The site edges are \(q=w_0u,p=vw_*\), the exterior face chords are \(z_Lr_L,z_Rr_R\), the escape edges are \(t_cc,t_bb\), and the hexagon has internal chord \(ad\) and trap chord \(\alpha\beta\). Every assigned special position belongs to a two-special ordinary leaf in \(W_1\) or \(W_2\). Let \(K\) denote the face-chord graph between the two roots.

**End-root theorem.** The parent has a Hamilton cycle containing both site edges, independently of whether \(K\) is connected. Its legal expanded child is Hamiltonian. The placement with \(W_2\) after \(z_R\) follows by reflection.

**Proof.** Open each root at its outer ordinary chord, leaving the old path \(P_i=W_{i,\ell}\xrightarrow{\rm old}W_{i,r}\). Outside the two root words take the four mutually disjoint paths
\[
\begin{array}{ll}
(u,w_0,W_{1,\ell}),&(r_L,z_L,W_{1,r}),\\
(W_{2,\ell},t_c,c,d,\beta,\alpha,a,b,t_b,W_{2,r}),&
(r_R,z_R,w_*,v).
\end{array}
\tag{2}
\]
They cover every vertex outside the roots. The long path uses the two escape edges, the trap chord \(\beta\alpha\), and otherwise old-cycle edges. The other three paths use the site edges, the two exterior face chords, and old-cycle edges. In particular \(w_0W_{1,\ell}\) and \(W_{1,r}z_L\) exist because \(W_1\) precedes \(z_L\).

Let \(E\) be the square-supported old edge in every two-special leaf of the two roots, and let \(M\) match all remaining leaf special positions, excluding \(u,v,r_L,r_R\). Put
\[
             F=(P_1\cup P_2-E)\cup M\cup
                      \{\text{edges of the four paths in (2)}\}.
\tag{3}
\]
Every vertex has degree two in \(F\): each root boundary end receives one exterior edge; each of the four special terminals loses its leaf old edge and gains its designated exterior edge; every other leaf special position loses that old edge and gains its \(M\)-edge. The exterior paths cover the remaining vertices with degree two. Thus \(F\) is a spanning disjoint union of cycles containing \(p,q\).

Contract the cycles of \(F\), representing each deleted leaf edge in \(E\) by a quotient edge. For every nonloop quotient edge \(x_i y_i\), the root old edges \(h_i x_i,y_i j_i\) remain in \(F\), while its leaf-square chord \(h_i j_i\) is unused: both outer root chords were opened and no other ordinary chord appears in (3). The square switch
\[
                    h_i x_i,y_i j_i
                    \longmapsto h_i j_i,x_i y_i
\tag{4}
\]
therefore joins two cycles and leaves all exterior edges, including \(p,q\), untouched. If \(F\cup E\) is connected, switches along a spanning tree of this quotient yield the required Hamilton cycle.

Each open root arc is connected. Every exterior vertex in (2) is attached to a root, so \(F\cup E\) is connected whenever either \(K\) has a cross-root face chord or one of the exterior paths joins the two roots. If \(K\) is disconnected, the even root cuts and three-connectivity force exactly two of the four special terminals \(u,v,r_L,r_R\) into each root, as in [Note 468](468-four-exterior-paths-close-the-disconnected-central-chorded-roots.md). The first two exterior paths of (2) both stay within \(W_1\) only if \(u,r_L\in W_1\). In that event the other two terminals lie in \(W_2\), and
\[
                       S=V(W_1)\cup\{w_0,z_L\}
\]
has exactly the two outgoing edges \(w_0\beta,z_Lt_c\): its ordinary and face chords are internal, as are \(w_0u,z_Lr_L\). This contradicts three-connectivity. Thus at least one of those exterior paths joins the roots, \(F\cup E\) is connected, and (4) gives the marked Hamilton cycle. The reflection proves the other end placement. \(\square\)

## Unified single-hexagon kernel bound

At \(c=5f-6\), the chorded charge forces the two-root all-leaf profile by Note 466. The three placements with both roots between \(z_L,z_R\) are Hamiltonian by Notes 467–468; the two end placements are Hamiltonian by the theorem above. Hence every non-Hamiltonian doubly ladder-reduced chorded single-hexagon child with \(f\ge7\) satisfies
\[
             c\le5f-7,
             \qquad |V(\bar G^+)|=16+2f+2c\le12f+2.
\tag{5}
\]
[Note 465](465-two-four-port-pairings-close-the-nested-four-root-end-gap.md) gives \(c\le5f-8\) and the same order bound \(12f+2\) for the chord-free branch. Thus any non-Hamiltonian doubly reduced child with a selected single-hexagon opening has at most \(12f+2\) vertices. In particular, for \(f=8\) both branches have at most 98 vertices. The statement is a necessary kernel bound; it does not establish Hamiltonicity of the remaining kernels or Barnette's conjecture.

**Chorded equality profile.** The two-root all-leaf splice above uses no wrapper count. Hence a non-Hamiltonian chorded child with \(c=5f-7\) must have \(m=f,R=1\) and \(M_0+L=2f-2\). Indeed \(m\le f-1\), \(R\ge3\), and the non-all-leaf \(R=2\) cases have \(c\le5f-8\); the all-leaf \(R=2\) case is Hamiltonian. At \(R=1\), the sum \(M_0+L=2f\) is the Hamiltonian all-leaf profile. If \(M_0+L=2f-1\), the sole marked nonleaf must be unary whenever \(c\ge5f-7\), since a marked branching overlap in \(A\) gives \(c\le5f-8\); Notes 459–460 close that unary node. A sum at most \(2f-3\) gives \(c\le5f-9\). Thus exactly two profiles can attain this new boundary:

1. \(M_0=f,L=f-2\): two nonleaf marked nodes each receive two positions. Equality in \(c\le3A-Q\) requires both to be unary rather than branching.
2. \(M_0=L=f-1\): all marked nodes are leaves, exactly one receiving four positions and every other leaf receiving two.

The equality conclusion follows because in either case \(Q=f-2\), the binary-branch bound gives \(A\le2f-3\), and \(c=5f-7=3(2f-3)-(f-2)\) forces equality throughout. At \(f=8\), these are the only possible 98-vertex chorded equality profiles; neither is claimed to be non-Hamiltonian.
