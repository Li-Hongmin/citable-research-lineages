> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every exact square-trap chord-packing child is Hamiltonian

[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
proves the exact free-vertex minimum \(f_{\min}(\ell,r)=4r+2\)
for a chosen all-square facial opening, but leaves the Hamilton
decision for arbitrary equality graphs open. At equality its
empty interblock gaps and saturated even block slots also force
all transitions between consecutive escape lobes. The remaining
free matching chords form one chain. This gives a Hamilton cycle
through both site edges in every equality parent.

Use the one-square-per-lobe compressed setting and notation of
Notes 176--179 and 195. In particular the parent Hamilton cycle
\(C\) avoids the cofacial site matching edges
\(q=xy,p=uv\), its main segment \(S_0\) runs from \(x\) to
\(v\), there are \(\ell\ge1\) residual squares, and the other
site-face arc has \(r\ge1\) matching chords \(a_i b_i\).
Let \(M=E(G)\setminus E(C)\). The main blocks are
\(B_0=[x,y]_C\), \(B_i=[a_i,b_i]_C\)
for \(1\le i\le r\), and \(B_{r+1}=[u,v]_C\).

**Equality Hamilton theorem.** If
\[
 |V(S_0)|=4r+2\ell+6
 \quad\text{or equivalently}\quad f=4r+2,          \tag{1}
\]
then the parent has a Hamilton cycle containing both
\(q,p\). Consequently its legal site-expanded Barnette
child has a Hamilton cycle. The statement holds for every
\(\ell,r\ge1\) and for arbitrary positive lengths of the
original square-trap lobes.

More precisely, after compressing the lobes, \(M\) is fixed
by the nonnegative integers \(k_0,\ldots,k_{r+1}\) giving the
extra interior slot pairs of the blocks, subject to
\(\sum k_i=\ell-1\). It includes the free-slot chain
\[
 e_0o_1,\ e_1o_2,\ldots,e_ro_{r+1},                \tag{2}
\]
where \(e_i\) is the final interior \(E\) slot of \(B_i\),
\(0\le i\le r\), and \(o_i\) is the first interior \(O\)
slot of \(B_i\), \(1\le i\le r+1\).

**Proof.** Note 195 gives three facts at equality: every
interblock gap is empty; every block starts with an \(O\)
interior slot and has \(2+2k_i\) interior slots; and every
even slot except its final one is a nonfinal escape target
\(L_j\). It also pins \(R_\ell\) to the first slot of
\(B_0\) and \(L_1\) to the final slot of \(B_{r+1}\).

We first prove that for each \(j\ge2\), the consecutive
targets \(L_j,R_{j-1}\) are adjacent on \(C\) inside one
block. Suppose instead that \(L_j\) is in \(B_i\) and
\(R_{j-1}\) in a later block \(B_h\). No target lies
between them. Every intermediate block must therefore
have only its two minimum interior slots: a longer block
would contain one of the compulsory nonfinal \(L\)
targets. The first slot of \(B_h\) must be \(R_{j-1}\):
it has odd index, and if it occurred later in a longer
block, that block's compulsory second-slot \(L\) would
precede it.

Take the main \(C\)-prefix from \(x\) through the right
endpoint of \(B_{h-1}\), together with residual squares
\(S_j,\ldots,S_\ell\). Every escape target in the main
prefix is matched into this square suffix, and all site
and face matching chords in the prefix have both endpoints
there. A free-slot chord leaving the prefix has endpoints
in different atoms, so Note 193 puts it opposite the
common face. Its first endpoint precedes \(R_{j-1}\),
while its second endpoint follows \(R_{j-1}\), because
that target is the first slot of \(B_h\) and cannot
itself be a free endpoint. The chord would cross
\(R_{j-1}\)'s escape edge. Hence no matching edge
leaves the chosen vertex set. Exactly two \(C\)-edges
leave it, contradicting three-edge-connectivity.
Thus both targets lie in one block. If \(L_j\) occupies
position \(2m\) there, the next odd position \(2m+1\)
must hold \(R_{j-1}\): before any later odd position
the next eligible even position would already hold a
different \(L\), and after the last eligible even
position there is no later odd slot in the block.
This proves the claimed adjacency.

It follows that \(B_0\) has \(R_\ell\) first, its
eligible even positions occupied by successive \(L\)'s,
the following odd positions by the next \(R\)'s, and
its final even slot \(e_0\) free. Every intermediate
block \(B_i\), \(1\le i\le r\), has a free first odd
slot \(o_i\), followed by \(k_i\) consecutive
\(L_j,R_{j-1}\) pairs, and then its free final even
slot \(e_i\). Its first slot cannot be an \(R\):
the preceding \(L\) would lie in an earlier block,
contrary to the adjacency just proved; only
\(R_\ell\) can be a first target, and it is in \(B_0\).
Its last even slot cannot be a target because
\(L_1\) is in \(B_{r+1}\). The final block
\(B_{r+1}\) begins with a free \(o_{r+1}\), has its
\(k_{r+1}\) internal \(L,R\) pairs, and ends at \(L_1\).
Thus the only free slots are precisely the vertices
listed in (2), one \(E\) in \(B_0\), one \(O\) and
one \(E\) in each face block, and one \(O\) in the
final block.

We now force their matching. Inductively suppose that
\(e_{m-1}o_m\in M\) for every \(1\le m\le i\);
the assertion is empty when \(i=0\). The free even
slot \(e_i\), \(0\le i\le r\), has no available odd
mate at or before \(B_i\): \(B_0\) has no free odd
slot, and each previous \(o_m\) is already matched.
Its mate is therefore some \(o_h\) with \(h>i\).
This cross-block chord lies opposite the common face.
It cannot straddle an escape target, so every skipped
block \(B_{i+1},\ldots,B_{h-1}\) has \(k_m=0\) and
two free interior slots. Noncrossing of the
opposite-side matching forces all free slots strictly
inside the chord \(e_io_h\) to match among themselves.
If exactly one block is skipped, its two slots are
adjacent on \(C\) and cannot be a matching pair.
If more are skipped, their union is closed under
\(M\): the skipped face chords are internal, and
all their free slots match inside the union. This
proper consecutive \(C\)-interval has only two
departing \(C\)-edges, again contradicting
three-edge-connectivity. Therefore \(h=i+1\).
Induction proves the entire chain (2).
Together with the fixed block and square incidences,
this is the complete complementary matching:
\[
 M=\{xy,uv\}
 \cup\{a_ib_i:1\le i\le r\}
 \cup\{\alpha_j\beta_j,\gamma_jL_j,\delta_jR_j:
          1\le j\le\ell\}
 \cup\{e_io_{i+1}:0\le i\le r\}.              \tag{3}
\]

Number \(C\) from index zero at \(x\), and let
\(A\) be its even-starting-edge perfect matching:
\(A=\{w_{2m}w_{2m+1}\}\). Since each block has even
order and there are no gaps, \(A\) pairs the left
endpoint of a block with its first interior slot,
successive even/odd interior slots, and its final
interior slot with the right endpoint. Every residual
square \(S_j\) has \(C\)-order
\(\alpha_j,\gamma_j,\delta_j,\beta_j\), with matching
edges \(\alpha_j\beta_j,\gamma_jL_j,\delta_jR_j\).
As \(|V(S_0)|\) is even, \(A\) pairs
\(\alpha_j\gamma_j\) and \(\delta_j\beta_j\).
Consequently \(M\cup A\) contains the path
\[
 x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
 \gamma_\ell,L_\ell,R_{\ell-1},\ldots,
 R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,
                                                        \tag{4}
\]
using every escape target and residual-square vertex.
For \(\ell=1\), (4) means
\(x,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v\).
The edges \(L_jR_{j-1}\) in (4) belong to \(A\) by
their even/odd indices.

The remaining vertices lie on the disjoint \(x\)-to-\(v\)
path
\[
 x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,
 \ldots,o_r,a_r,b_r,e_r,o_{r+1},u,v.          \tag{5}
\]
Here \(xy,a_ib_i,uv\) and the chain (2) belong to
\(M\); the other displayed edges belong to \(A\).
Paths (4) and (5) cover every vertex, have no common
internal vertex, and have the same endpoints. Their
vertex counts are \(6\ell+2\) and \(4r+6\), with
only \(x,v\) shared; their union therefore has
\(4r+6\ell+6=|V(S_0)|+4\ell=|V(G)|\) vertices.
Their union is one Hamilton cycle \(M\cup A\), containing
both site edges \(q,p\).

Note 001 lifts this parent cycle through the legal
\(C_4\)-site expansion to a Hamilton cycle of the
compressed child. Note 178 transfers the marked
Hamilton route through the inverse lobe-ladder
replacements, proving the original statement.
\(\square\)

The theorem decides Hamiltonicity exactly on the
minimum-free-vertex boundary for the chosen all-square
facial-opening class. It gives no Hamilton conclusion
above that boundary, for openings with nonsquare
residual cycles, or for arbitrary Barnette graphs.
In particular, any non-Hamiltonian site-expanded child
admitting such an all-square opening must satisfy
\(f\ge4r+4\), because \(f\) is even.
