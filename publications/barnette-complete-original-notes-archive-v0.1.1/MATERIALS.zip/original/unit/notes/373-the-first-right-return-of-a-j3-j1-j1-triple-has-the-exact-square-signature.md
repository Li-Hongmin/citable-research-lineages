> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The first right return of a J3,J1,J1 triple has the exact square signature

[Note 343](343-a-j3-j1-j1-triple-needs-a-right-corridor-and-occurs.md)
exhibits a Barnette parent with one short block after
the \(J_3,J_1,J_1\) triple and no left short flank.
Its matching leaves the first block's \(o_1,h_1\)
to the exterior. The entire triple, required internal
corridor, and right short flank have the square's
complete four-terminal Hamilton signature.

Keep the block order and forced matching of
[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md):
\(D_1,D_2,S_1,\ldots,S_q,D_3\), where
\(q\ge1\), \(D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s)\),
and \(S_t=(c_t,r_t,s_t,d_t)\). There is no
\(h_1j_3\) and no left short flank. Append \(p\ge1\)
right short blocks
\(T_t=(\bar c_t,\bar r_t,\bar s_t,\bar d_t)\)
and take the right-only first-return matching
\[
e_3\bar r_1,\qquad
\bar s_t\bar r_{t+1}\ (1\le t<p),\qquad
j_3\bar s_p,\qquad Lo_1,\qquad h_1R .                 \tag{1}
\]
For \(p=1\), this is exactly Note 343's matching
on its right outer block. Let \(R_{p,q}\) be the
induced patch on the three double blocks, the
right corridor, and the \(p\) right short blocks.
Its four degree-two terminals, in cyclic disk order,
are
\[
                         (a_1,o_1,h_1,\bar d_p).
\tag{2}
\]

**First-right-return theorem.** For every \(p,q\ge1\),
\(R_{p,q}\) has exactly the square's four spanning
one-path terminal pairs and two spanning two-path
terminal pairings. Replacing an induced disk copy
by the labeled square, or reversing the replacement,
preserves the Barnette class and every exterior-
and attachment-marked Hamilton decision. The patch
has \(24+4(p+q)\) vertices. No condition is imposed
on vacancies elsewhere in the host.

**The two corridor reductions.** The right internal
corridor \(S_1,\ldots,S_q\) is Note 370's
\(L_{2q}\). The outer blocks \(T_1,\ldots,T_p\)
independently induce \(L_{2p}\), with columns
\((\bar c_t,\bar r_t),(\bar d_t,\bar s_t)\).
Their only four exterior edges are
\(b_3\bar c_1,e_3\bar r_1,j_3\bar s_p\),
and the old edge leaving \(\bar d_p\).
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
reduces each ladder to one square, in both directions,
preserving the Barnette class and all exterior marks.
The old-cycle route through each ladder and its
common-face top rail become the corresponding
one-block route. Thus it suffices to prove the
signature and patch deletion properties at \(p=q=1\).

**Six explicit routes.** Write the remaining outer
short block as
\(T=(\bar c,\bar r,\bar s,\bar d)\), and let
\(U_q\) be Note 370 (7)'s full old-cycle path through
the internal corridor. The \(a_1\)--\(\bar d\)
spanning path is the full old-cycle path. A spanning
\(o_1\)--\(h_1\) path is
\[
\begin{split}
(o_1,a_1,b_1,a_2,o_2,h_2,i_2,k_2,j_2,e_2,b_2,
U_q,a_3,b_3,\bar c,\bar d,\bar s,\bar r,\\
\hspace{28mm}e_3,j_3,k_3,o_3,h_3,i_3,k_1,j_1,
e_1,i_1,h_1).
\end{split}                                             \tag{3}
\]
This is Note 343 (7), with its internal corridor
expanded as in Note 343 (11). The other two spanning
single paths are
\[
\begin{split}
a_1\to o_1:\quad
&(a_1,b_1,a_2,o_2,h_2,i_2,k_2,j_2,e_2,b_2,
U_q,a_3,b_3,\bar c,\bar d,\bar s,\bar r,\\
&\hspace{28mm}e_3,j_3,k_3,o_3,h_3,i_3,k_1,j_1,
e_1,i_1,h_1,o_1),\\
h_1\to\bar d:\quad
&(h_1,o_1,a_1,b_1,a_2,o_2,h_2,j_1,e_1,i_1,
k_1,i_3,k_3,o_3,h_3,i_2,k_2,j_2,e_2,b_2,\\
&\hspace{28mm}U_q,a_3,b_3,\bar c,\bar r,e_3,
j_3,\bar s,\bar d).
\end{split}                                             \tag{4}
\]
The four paths cover each vertex exactly once.
All their joins are old-cycle edges, the face
chords, or the matching edges of Note 344 (2)
and (1).

For the pairing
\(\{a_1o_1,h_1\bar d\}\), use the edge \(a_1o_1\)
and the path
\[
\begin{split}
(h_1,i_1,e_1,b_1,a_2,o_2,h_2,j_1,k_1,
i_3,k_3,o_3,h_3,i_2,k_2,j_2,e_2,b_2,\\
\hspace{28mm}U_q,a_3,b_3,\bar c,\bar r,e_3,
j_3,\bar s,\bar d).
\end{split}                                             \tag{5}
\]
For \(\{a_1\bar d,o_1h_1\}\), use \(o_1h_1\)
and
\[
\begin{split}
(a_1,b_1,a_2,o_2,h_2,j_1,e_1,i_1,k_1,
i_3,k_3,o_3,h_3,i_2,k_2,j_2,e_2,b_2,\\
\hspace{28mm}U_q,a_3,b_3,\bar c,\bar r,e_3,
j_3,\bar s,\bar d).
\end{split}                                             \tag{6}
\]
Both pairs are disjoint and span the patch.
The terminal colours are \(a_1,h_1\) versus
\(o_1,\bar d\); opposite-colour endpoints give only
the four listed single paths. The third pairing
interlaces the disk boundary order (2), so it is
impossible. This proves the complete square signature.

**A 36-vertex Barnette cap.** At \(p=q=1\),
add a square \((t_D,t_H,t_O,t_A)\) outside the
patch, attaching
\(\bar d t_D,h_1t_H,o_1t_O,a_1t_A\).
The full old-cycle path from \(a_1\) to
\(\bar d\), followed by
\(t_D,t_H,t_O,t_A,a_1\), is a Hamilton cycle
of the capped graph. Its complementary matching
consists of the one-page chords
\[
a_sb_s\ (s=1,2,3),\quad i_1e_1,\quad
o_2k_2,\quad o_3k_3,\quad c_1d_1,\quad
\bar c\bar d,\quad t_Dt_A,
\tag{7}
\]
and the opposite-page chords
\[
j_1h_2,\quad k_1i_3,\quad i_2h_3,\quad
j_2s_1,\quad e_2r_1,\quad j_3\bar s,\quad
e_3\bar r,\quad o_1t_O,\quad h_1t_H .
\tag{8}
\]
Each page is noncrossing; each matching chord joins
opposite Hamilton-cycle parities. The following dashes
are endpoint alternations forming a connected spanning
tree of the chord interlacement graph:
\[
\begin{gathered}
t_Dt_A-o_1t_O-a_1b_1-j_1h_2-a_2b_2-i_2h_3
-a_3b_3-j_3\bar s-\bar c\bar d-e_3\bar r,\\
t_Dt_A-h_1t_H,\qquad
j_1h_2-i_1e_1,\qquad
a_1b_1-k_1i_3-o_3k_3,\qquad
j_1h_2-o_2k_2,\\
a_2b_2-j_2s_1-c_1d_1-e_2r_1 .
\end{gathered}                                           \tag{9}
\]
Thus the cap is plane and bipartite. Connected
interlacement excludes a two-edge cut; its Hamilton
cycle excludes bridges. Cubicity then implies
three-vertex-connectivity, so the cap is Barnette.
Expanding either ladder by Note 178 gives a
Barnette cap for all \(R_{p,q}\).

Deleting any one patch vertex leaves a connected
graph. Its full old-cycle path is bridged at
every internal position by one of
\(a_1b_1,k_1i_3,a_3b_3,j_3\bar s,\bar c\bar d\)
not incident with that vertex. This one-deletion
property persists under ladder expansion, by the
connected-ladder attachment argument of Note 372.
Every component surviving two patch-vertex
deletions contains a surviving terminal; otherwise
it would disconnect the corresponding Barnette cap.
The square has the same two deletion properties.
The four-attachment comparison in Note 370 gives
three-connectivity in both replacement directions.
The terminal colours, disk order and six exact
states give the remaining Barnette and Hamilton
assertions. \(\square\)

In the selected opening the replacement square is
a single short target-free block, with old-cycle
segment \((a_1,o_1,h_1,\bar d_p)\) and face chord
\(a_1\bar d_p\). Deeper right-only returns,
simultaneous outer flanks, other vacancy types,
and the general Barnette conjecture are outside
this theorem. The proof is project-internal and
has not had independent review.
