> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-lobe one-face-chord openings with eight free vertices have Hamiltonian children

[Note 198](198-one-face-chord-excludes-two-gap-near-equality.md)
eliminates the two-gap-slot branch at \(r=1,f=8\).
For one compressed residual square, the remaining gapless
branch has just six free interior slots. Planarity and
three-edge-connectivity leave three matching patterns up
to reversal; each has a direct Hamilton parent cycle through
both site edges.

Let \(G\) be a Barnette parent with Hamilton cycle \(C\)
avoiding the cofacial site matching edges \(q=xy,p=uv\).
Assume a chosen all-square facial opening has one lobe,
one matching chord \(ab\) on the other site-face arc, and
\(f=8\). Compress the lobe to one residual square by
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
The three blocks are
\[
B_0=[x,y]_C,\qquad B_1=[a,b]_C,\qquad B_2=[u,v]_C.
\tag{1}
\]
Write its residual-square vertices in \(C\)-order as
\(\alpha,\gamma,\delta,\beta\), with complementary matching
edges \(\alpha\beta,\gamma L,\delta R\), where \(R=R_1\)
precedes \(L=L_1\) on the main \(x\)-to-\(v\) segment.
Let \(M=E(G)\setminus E(C)\), and let \(A\) consist of the
even-starting edges of \(C\), indexed from \(x\).

**Single-lobe near-equality theorem.** Every such parent
has a Hamilton cycle containing both \(q,p\). Hence every
legal site-expanded child admitting this opening is
Hamiltonian. The result holds for any positive length of
the original square-trap lobe.

**Proof.** Note 198 gives empty interblock gaps. The slot
count of Note 195 is
\[
2(k_0+k_1+k_2)=2,\qquad k_0+k_1+k_2=1.
\tag{2}
\]
Exactly one block has four interior slots; the other two
have two. There are two escape targets and six free slots.
By Note 197's gapless defect budget, at most one of the
following fails: \(R\) is the first slot of \(B_0\), or
\(L\) is the last slot of \(B_2\). Its endpoint barrier
also forbids \(R\) as the first slot of \(B_1,B_2\), and
\(L\) as the last slot of \(B_0,B_1\). A delayed \(R\)
must therefore be the third slot of the unique long
block. Reversing the main cycle segment and exchanging
\(x\leftrightarrow v\), \(y\leftrightarrow u\),
\(R\leftrightarrow L\), and the two site edges reflects
a case with advanced \(L\) to one with delayed \(R\).
The residual square is reflected at the same time.
We only need the cases below.

All free-slot matching edges between different blocks
lie opposite the common face by Note 193. They are
noncrossing. A free-slot edge cannot straddle an escape
target on that side, because it would cross the target's
edge to the residual square. Interior slots consecutive
on \(C\) cannot be matched together in a simple graph.

**Case I: both targets at the outermost slots.** Suppose
\(R\) is first in \(B_0\) and \(L\) last in \(B_2\).
First let \(B_0\) be long. Give its slots the order
\(R,s,t,w\), give \(B_1\) the slots \(g,h\), and give
\(B_2\) the slots \(z,L\). The free-slot colour order is
\(s,t,w,g,h,z:E,O,E,O,E,O\). All free-slot chords are
cross-block. The first slot \(s\) cannot match \(t\),
which is adjacent on \(C\); matching \(s\) to \(g\)
would enclose the adjacent pair \(t,w\). Thus \(sz\in M\).
Inside this chord, \(t\) cannot match its adjacent \(w\),
so \(th,wg\in M\). The full free matching is therefore
\[
sz,\quad th,\quad wg.
\tag{3}
\]
It gives the explicit Hamilton cycle
\[
x,R,\delta,\beta,\alpha,\gamma,L,v,u,z,s,t,h,b,a,g,w,y,x.
\tag{4}
\]
Edges alternate between \(A\) and \(M\); in particular
\(xy,ab,uv\in M\) and all three edges (3) are used.

If \(B_1\) is long, write its four free slots as
\(g,h,i,j\), while \(B_0\)'s sole free slot is \(e\)
and \(B_2\)'s is \(z\). Their order is
\(e,g,h,i,j,z:E,O,E,O,E,O\). The only possible
same-block free chord is \(gj\), since \(gh,hi,ij\)
are cycle edges and the other pairs have equal colours.
If \(gj\in M\), the remaining opposite-side slots have
order \(e,h,i,z:E,E,O,O\), whose noncrossing matching
forces the forbidden cycle edge \(hi\). If \(gj\notin M\),
all free chords lie opposite the face. The mate of \(e\)
could be \(g,i,z\): the first leaves either \(hi\) or
\(ij\) forced, the second encloses the forbidden pair
\(gh\), and the third leaves \(g,h,i,j\), whose
noncrossing matching contains \(gh\) or \(hi\).
Thus this target placement is impossible. A long \(B_2\)
is the reflection of the long-\(B_0\) case, so it also
has a Hamilton parent cycle.

**Case II: \(R\) is delayed.** Then \(L\) is last in
\(B_2\), and \(R\) is the third slot of the long block.
If that block is \(B_0\), its first two slots are free.
The second is an \(E\) slot before \(R\); its only
possible mate before \(R\) is the adjacent first slot.
It cannot match a later block slot across \(R\), and
the fourth slot of \(B_0\) has its own \(E\) colour.
This placement is impossible.

If \(B_1\) is long, write the block slots as
\(g,h,R,j\), write the free slots of \(B_0\) as
\(s,t\), and write those of \(B_2\) as \(z,L\).
The free slots before \(R\) are \(s,t,g,h\), in
\(O,E,O,E\) order; after it they are \(j,z\), in
\(E,O\) order. A chord from an earlier block across
\(R\) is impossible. The only same-block chord that
could cross \(R\) is \(gj\); if it were used, the
three remaining pre-\(R\) free slots \(s,t,h\) could
not all be matched. Thus the pre-\(R\) matching must
be the nested pair \(sh,tg\), since \(st,gh\) are
cycle edges. The last pair is \(jz\). Hence
\[
sh,\quad tg,\quad jz\in M,
\tag{5}
\]
and the explicit Hamilton cycle is
\[
x,y,t,g,a,b,j,z,u,v,L,\gamma,\alpha,\beta,\delta,R,h,s,x.
\tag{6}
\]

If \(B_2\) is long, write its slots as \(z,w,R,L\),
and write the free slots of \(B_0,B_1\) as \(s,t\)
and \(g,h\), respectively. All six free slots
\(s,t,g,h,z,w\) precede \(R\), have alternating
colours \(O,E,O,E,O,E\), and lie on the opposite
side of the face for every possible chord. The three
within-block consecutive pairs \(st,gh,zw\) are
forbidden. Noncrossing then forces
\[
sw,\quad tg,\quad hz\in M.
\tag{7}
\]
Indeed, \(s\) cannot match adjacent \(t\); matching
it to \(h\) would enclose \(tg\) but leave the
forbidden \(zw\), so it must match \(w\). Then
\(t\) must match \(g\), since matching it to \(z\)
would enclose \(gh\). The Hamilton cycle is
\[
x,s,w,R,\delta,\beta,\alpha,\gamma,L,v,u,z,h,b,a,g,t,y,x.
\tag{8}
\]

Each displayed cycle (4), (6), (8) visits every vertex
of the compressed parent exactly once, uses only \(A\)
and \(M\), and contains both \(q=xy\) and \(p=uv\).
The three reflected cases have the reflected Hamilton
cycles. Note 001 lifts any such parent cycle through
the legal site expansion. Note 178 restores an arbitrary
even ladder in place of the compressed residual square
while preserving both marked site edges and the Hamilton
decision. \(\square\)

This proves Hamiltonicity for the single-lobe, one-face-chord,
eight-free-vertex boundary. It does not classify or settle
the corresponding opening with two or more lobes, larger
\(r\), or Barnette graphs without such an opening.
