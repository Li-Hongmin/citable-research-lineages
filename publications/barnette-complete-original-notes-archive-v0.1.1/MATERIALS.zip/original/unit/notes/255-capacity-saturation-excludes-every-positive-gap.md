> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A positive gap requires a block-internal face-side chord

[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
counts block capacity and gap slots in an all-square facial opening.
[Notes 213](213-two-slot-gaps-must-split-and-disrupt-a-transition.md)
and [214](214-all-two-slot-gaps-are-excluded-at-first-surplus.md)
exclude the first positive gap total at saturated block capacity.
The first theorem below isolates a general obstruction, without any
capacity assumption; the second applies it at saturation.

Use the one-square-per-lobe compression of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Let \(G\) be a three-connected cubic bipartite plane graph with a
Hamilton cycle \(C\) avoiding two disjoint cofacial matching edges.
Select an all-square facial opening with \(\ell,r\ge1\), main blocks
\(B_0,\ldots,B_{r+1}\), and intervening gaps \(G_0,\ldots,G_r\).
Write \(2+2k_i\) for the interior-slot count of \(B_i\), \(t_i\)
for the length of \(G_i\), and set
\[
\sigma=\sum_{i=0}^{r+1}k_i-(\ell-1),\qquad
T=\sum_{i=0}^{r}t_i.
\tag{1}
\]
Note 195 gives \(\sigma\ge0\) and
\[
f=4r+2+2\sigma+T.                         \tag{2}
\]
When \(T=0\), \(\sigma\) is Note 197's vacant-position count.
Let \(M=E(G)\setminus E(C)\) be the complementary matching.

**Gap-face-chord obstruction.** If \(T>0\), then \(M\) has a
free-slot edge with both endpoints in one block \(B_i\), drawn
on the side of \(C\) containing the designated common face.

**Proof.** Suppose otherwise. Note 193 puts every matching edge
joining free slots of different blocks or gaps on the opposite
side of \(C\); Note 195 does the same for an edge joining two
slots of one gap. By assumption any same-block free edge is on
that side too. Thus *all* free-slot matching chords lie in one
disk and do not interlace there.

Take a gap slot \(g\) and suppose its mate \(w\) is a free slot
of some block. If an escape target lies strictly between \(g,w\)
on the main segment, the no-straddling lemma of
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
already excludes \(gw\). Otherwise count vertices strictly
between \(g,w\) along the main segment. Because \(G\) is
bipartite and \(g,w\) have opposite colours, their distance on
\(C\) is odd, so this interval has an even number of vertices.
It crosses exactly one endpoint of \(w\)'s block and both
endpoints of every complete intervening block: an odd number
of fixed block endpoints. It contains no escape target.
Consequently it contains an **odd** number of free slots.
Every one of those free slots must match another one inside
\(gw\), since all their matching chords lie in the same
noncrossing disk. This is impossible. Hence no gap slot
matches a block slot.

All gap slots must therefore match other gap slots. A
noncrossing perfect matching on their linear order has a pair
of consecutive gap slots. If they lie in one gap, they are
adjacent on \(C\), so their edge cannot be in \(M\). If they
lie in different gaps \(G_a,G_b\), \(a<b\), the pair's chord
cannot straddle a target by Note 203. Hence every complete
intervening block \(B_{a+1},\ldots,B_b\) is target-free and
short. Its fixed face chord is internal. Its two free slots
cannot match a gap slot, and they cannot match block slots
outside the interval without interlacing the selected
gap-to-gap chord. The consecutive union of those complete
blocks is closed under \(M\) and has only its two boundary
\(C\)-edges leaving it, contrary to three-connectivity.
Both cases are impossible. \(\square\)

**Saturated-gap exclusion theorem.** If \(\sigma=0\), then
\(T=0\). Equivalently, every opening with a positive interblock
gap has an unoccupied eligible block position:
\[
T>0\quad\Longrightarrow\quad \sigma\ge1,
\qquad f\ge4r+4+T.                         \tag{3}
\]
The conclusion holds for arbitrary positive original lobe lengths.

**Proof.** Suppose \(\sigma=0\). Every eligible block position
is a nonfinal \(L\)-target. By
[Note 197](197-gapless-square-trap-defect-budget.md), the first
target \(R_\ell\) is the first interior slot of \(B_0\), the last
target \(L_1\) is the final interior slot of \(B_{r+1}\), and
every nonadjacent \(L_j,R_{j-1}\) transition ends at the second
slot of a reversed block. A block is *forward* when an odd-colour
slot comes first and *reversed* when an even-colour slot comes
first.

A forward block can have its first odd slot and final even slot
free. If its last \(L\)-target starts a nonadjacent transition,
the odd slot immediately following that target is free too.
A reversed block can have its first even and second odd slots
free; its second slot may instead be a transition-destination
\(R\)-target. If its last \(L\)-target starts a nonadjacent
transition, its final odd slot is free. Site-block endpoints
only remove possibilities. Thus a forward block has at most
one free slot before any target, and a reversed block has at
most one free slot after any target.

No same-block free matching edge can cross an escape target.
For a target in \(B_i\), the number of free slots preceding it
is even:
\[
\#F(T^-)=\operatorname{index}_C(T)-(2i+1)
          -\#\{\text{earlier escape targets}\}\equiv0\pmod2.
\]
Indeed, the old-cycle index is odd for an \(R\)-target and
even for an \(L\)-target, while the number of earlier targets
has the respective parities even and odd. Cross-atom chords
straddling the target are forbidden by Note 203; the block
slot list above permits at most one same-block crossing chord.
Matching parity excludes that one too. Any two free slots in
the same block that do not straddle a target are either
adjacent on \(C\) or have the same bipartition colour. They
cannot form a matching edge. Therefore \(M\) has **no**
same-block free-slot edge. The gap-face-chord obstruction
implies \(T=0\). Note 178 restores every compressed lobe
without changing the block and gap counts. \(\square\)

**Second-surplus consequence.** At \(f=4r+6\), equation (2)
reads \(2\sigma+T=4\). The compressed graph has \(4\ell\)
residual-square vertices and even total order, so \(f\) and
\(T\) are even. If \(T>0\), the theorem excludes
\((\sigma,T)=(0,4)\). The only remaining positive-gap
profile is
\[
(\sigma,T)=(1,2).                              \tag{4}
\]
[Note 254](254-every-gapless-all-square-second-surplus-opening-is-hamiltonian.md)
handles \(T=0\). Formula (4) is a reduction of the remaining
all-square second-surplus problem, not a Hamilton assertion for
two gap slots. Openings with nonsquare residual cycles and the
general Barnette conjecture remain undecided.
