> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Productivity is demand-cycle containment, and braces do not force it

[Note 128](128-good-sibling-or-nonrooted-portal-covers-the-frozen-mixed-sector-family.md)
shows that every one of the \(112\) frozen mixed-sector endpoints has either
a productive rooted sibling or a productive non-rooted portal.  The word
*productive* contains the remaining global difficulty.  It is not enough to
find an alternating cycle with the correct gate and site incidences: every
retained edge newly demanded by the child target must lie on that same
cycle.

This note gives the exact demand-containment reduction and separates it from
ordinary brace connectivity.  Even a plane cubic bipartite brace with a
root-separable two-cycle matching complement can have a genuine perfect-
matching demand that no single alternating cycle carries.  Thus
\(2\)-extendability and directed Menger theory alone cannot prove the
\(G\lor P\) candidate of Note 128.

## 1. Retained demand

Fix a sterile state-\(11\) rooted parent target \(\chi^b\), and write
\(M_\chi\) for its perfect matching and

\[
 E_{\rm ret}=E(G)\setminus\{p,q\}.
\tag{1}
\]

For a same-sector rooted child target \(\theta\) in one of the new cells
\(R_{00},X_{uy},X_{vx}\), define

\[
 D_\chi(\theta)=
 (M_\theta\cap E_{\rm ret})\setminus M_\chi .
\tag{2}
\]

Let \(T\) be the parent dual triangulation.  If \(W\) is a proper shore,
\(\eta=\chi\mathbin\triangle W\) is NAE, and \(\delta_T(W)\) is a bond,
then \(\delta_T(W)^*\) is one \(M_\chi\)-alternating cycle.  Matching status
changes precisely on this bond.  Hence

\[
\boxed{
 M_\theta\cap E_{\rm ret}
 \subseteq M_\chi\cup M_\eta
 \quad\Longleftrightarrow\quad
 D_\chi(\theta)^*\subseteq\delta_T(W).}
\tag{3}
\]

Thus productivity is exactly **single-cycle containment of the complete
retained demand**.  In the \(M_\chi\)-direction, the edges of
\(D_\chi(\theta)\) are prescribed arcs and (3) asks for one directed cycle
containing all of them.

## 2. Exact \(G/P\) shore signatures

Assume \({\cal E}_\chi=\varnothing\).  The assertion \(G\lor P\) is
equivalent to the existence of a pair \((\theta,W)\) satisfying (3), such
that \(\chi\triangle W\) is NAE, \(\delta_T(W)\) is a bond, and the root and
forced-gate dual edges avoid \(\delta_T(W)\), together with one of the
following signatures.

1. For \(G\), the surviving-gate edge belongs to \(\delta_T(W)\), at least
   one site edge belongs to it, and \(\chi\triangle W\) is root-admissible.
   By [Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md),
   the last condition is precisely

   \[
   \rho_{00}+\rho_{11}=\rho_{10}+\rho_{01}
   \tag{4}
   \]

   together with separation of the two marked root fragments in the
   opposite-colour gluing graph.

2. For \(P\), the surviving-gate edge avoids \(\delta_T(W)\), while both
   site edges belong to it.  If the flip were root-admissible, it would be
   a same-sector non-\(11\) rooted neighbour and hence a member of
   \({\cal E}_\chi\).  It is therefore automatically non-rooted.

The child target \(\theta\) independently satisfies the labelled condition

\[
 c(T^+_0(\theta))+c(T^+_1(\theta))=3
\tag{5}
\]

with its two root fragments separated.  Under root smoothing this is a
Hamilton cycle through both distinguished smoothing edges.  Equations
(3)--(5) isolate the only unused coupling: child root separation must
produce a demand set carried by a parent cycle with one of the two listed
signatures.

## 3. A brace boundary

Consider the hexagonal prism \(C_6\square K_2\), with edge set

~~~text
01 03 05 12 14 23 29 3-10 45 47 56 67 6-11 78 89 8-11 9-10 10-11.
~~~

It is a plane cubic bipartite \(3\)-connected \(2\)-extendable graph.  Take

\[
\begin{aligned}
M={}&\{01,23,45,67,8\!-!11,9\!-!10\},\\
Q={}&\{01,23,47,56,89,10\!-!11\}.
\end{aligned}
\tag{6}
\]

The complement of \(M\) is \(C_6\dot\cup C_6\), and every edge of \(M\)
joins the two complement cycles.  Thus \(M\) already has the full parent
root-separation topology: any of its edges may be chosen as the separating
root.

On the other hand,

\[
 M\mathbin\triangle Q=C_4\dot\cup C_4,
\tag{7}
\]

on vertex sets \(\{4,5,6,7\}\) and \(\{8,9,10,11\}\).  The genuine matching
demand \(Q\setminus M\) contains the two \(Q\)-edges in each square.  Any
\(M\)-alternating cycle containing both demanded edges of one square must
also use the two \(M\)-edges and closes inside that square.  It cannot also
contain the demanded edges of the other square.  Therefore

\[
\boxed{
 Q\setminus M
 \text{ is contained in no single }M\text{-alternating cycle}.}
\tag{8}
\]

This proves that plane brace structure, pair extension, strong
\(M\)-direction connectivity, and parent two-cycle root separation do not
imply the demand containment in (3).

The same example is not a legal-wide counterexample.  Its unique plane
embedding has six quadrilateral and two hexagonal faces.  A gate face uses
at least three interface vertices, whereas an interface-disjoint site needs
four further vertices, so the site cannot lie on that face.  Expanding a
different face can lengthen the gate face only along a selected edge shared
by the two faces.  Two faces of this \(3\)-connected plane graph share at
most one edge.  If no selected edge is shared, the shorter gate arc has
length at most four.  If one is shared, the only way both resulting odd arcs
could have length at least five is to start from a hexagonal gate face with
arc lengths \(3,5\) and lengthen the \(3\)-arc to \(5\).  Its only eligible
middle edge, however, joins two gate-interface vertices, contrary to the
interface-disjoint hypothesis.  Hence no legal-wide decoration exists.

## 4. Remaining statement

The actual Note-128 candidate is neither proved nor refuted.  Its unique
remaining load-bearing implication is

\[
\boxed{
\begin{gathered}
\text{actual legal-wide split, sterile }\chi^b,
\ {\cal M}_\chi\ne\varnothing,
\ {\cal E}_\chi=\varnothing
\\[1mm]\Longrightarrow\\[1mm]
\text{some new-cell root-separated }\theta
\text{ has co-cyclic }D_\chi(\theta),
\text{ with a carrying cycle of signature }G\text{ or }P.
\end{gathered}}
\tag{9}
\]

This **patch-constrained child-root-separated demand co-cyclicity** is
strictly stronger than generic Menger connectivity and strictly narrower
than the original \(G\lor P\) formulation.  It identifies the one coupling
not represented by the brace counterexample: the same legal patch must
simultaneously create the child target, its root separation, and the parent
cycle that carries all retained demand.

The fixed boundary is reproduced by the
[demand-cycle containment bundle](../computations/bundles/demand-cycle-containment-boundary/README.md).
