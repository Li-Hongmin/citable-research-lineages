> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One short block between two vacancies has three Hamilton matchings

[Note 218](218-an-isolated-adjacent-double-vacancy-forces-the-absorbable-square.md)
classifies a ten-slot free group with adjacent vacancies.
The next group has one short face block between them and twelve
free slots. Its matching is no longer unique, but each possible
matching has a marked Hamilton route.

Use a compressed all-square opening with \(\ell,r\ge1\),
empty interblock gaps, tight target order and exactly two
eligible vacancies. Suppose the vacancies are in target-free
four-slot face blocks \(B_k,B_{k+2}\), with the short
target-free face block \(B_{k+1}\) between them. Assume the
free group containing both vacancies is precisely
\[
\begin{array}{c|cccccccccccc}
\text{position}&0&1&2&3&4&5&6&7&8&9&10&11\\
\text{slot}&e_{k-1}&o_k&h_k&i_k&e_k&o_{k+1}&e_{k+1}&
o_{k+2}&h_{k+2}&i_{k+2}&e_{k+2}&o_{k+3}.
\end{array}                                               \tag{1}
\]
Here \(1\le k<k+2\le r\), and the two group endpoints
may lie in site blocks.

**Twelve-slot classification theorem.** Exactly three
free matching profiles are possible on (1):
\[
\begin{array}{ll}
\text{paired square:}&
(0,1),(2,9),(3,8),(4,5),(6,7),(10,11),\\
\text{left rainbow:}&
(0,9),(1,8),(2,7),(3,6),(4,5),(10,11),\\
\text{right rainbow:}&
(0,1),(2,11),(3,10),(4,9),(5,8),(6,7).
\end{array}                                               \tag{2}
\]
For every one of these profiles, the parent has a Hamilton
cycle containing both site edges, and its legal site-expanded
child is Hamiltonian. The conclusion persists for arbitrary
positive original lobe lengths.

**Proof of exhaustion.** The parity barrier of Note 215
makes (1) closed under the free matching. Cross-block chords
lie in one opposite-side disk and are noncrossing. The only
possible same-block free chords in the long blocks are
\((1,4)=o_ke_k\) and \((7,10)=o_{k+2}e_{k+2}\);
they may lie on the other side.

The mate of position \(0\) is one of \(1,3,5,7,9,11\).
If it is \(5\), the complete block \(B_k\) is matching-closed;
if \(7\), the union \(B_k\cup B_{k+1}\) is matching-closed;
if \(11\), all three complete face blocks are
matching-closed. Each produces a proper consecutive
old-cycle interval with only two exiting edges, forbidden
by three-connectivity. The mate cannot be \(3\):
positions \(1,2\) lie inside \(0\!-\!3\) and are adjacent
on \(C\). The possible same-block edge \(1\!-\!4\)
would still leave \(2\) unmatched inside; a cross-block
edge from \(2\) to the outside would cross \(0\!-\!3\).
Thus only \(0\!-\!1\) and \(0\!-\!9\) remain.

Suppose \(0\!-\!9\). Positions \(1,\ldots,8\) lie inside
that opposite-side chord. The sole possible same-block
edge leaving them is \(7\!-\!10\); it would leave an odd
number of vertices inside, so all eight match internally.
The mate of \(1\) cannot be \(2\), an old-cycle edge.
If it were \(4\), then \(2\) would have to match \(5\)
or \(7\); in either case the same-block edge \(1\!-\!4\)
leaves an unmatched vertex inside that opposite-side chord.
If \(1\) matched \(6\), the four vertices \(2,\ldots,5\)
would have to match internally, but \(2\!-\!3\) and
\(3\!-\!4\) are old-cycle edges, while \(2\!-\!5\)
encloses the latter pair. Hence \(1\!-\!8\) is forced.
Inside it, \(2\!-\!5\) would enclose the adjacent pair
\(3,4\), so \(2\!-\!7\) is forced. Then \(3\!-\!6\)
and \(4\!-\!5\) are forced, while \(10\!-\!11\)
matches outside. This is the left rainbow in (2).

Reflecting the argument shows that position \(11\) can
only match \(10\) or \(2\), and that \(11\!-\!2\)
forces the right rainbow. It remains to take
\(0\!-\!1,10\!-\!11\). Neither same-block free chord
is now available. Position \(2\) cannot match \(3\),
an old-cycle edge. If it matched \(5\), the adjacent
pair \(3,4\) would be enclosed. If it matched \(7\),
the only matching inside would be \(3\!-\!6,4\!-\!5\),
leaving the adjacent pair \(8,9\). Thus \(2\!-\!9\).
Inside that chord, \(3\!-\!6\) would again leave
adjacent \(7,8\), so \(3\!-\!8\); then \(4\!-\!5\)
and \(6\!-\!7\) are forced. This is the paired square.
No other cases remain.

**Hamilton routes.** In the paired-square profile,
the ordinary chain is intact and
\(h_ki_{k+2},i_kh_{k+2}\in M\); Note 217 applies
with its one short-block ladder.

For the left rainbow, let \(A\) be the even-starting
old-cycle matching from \(x\). Note 196's target-and-square
path remains intact. Its complementary free path crosses
the exceptional group in the following order, with
subscripts \(X=k,Z=k+1,Y=k+2\):
\[
\begin{split}
e_{k-1},i_Y,h_Y,o_X,a_X,b_X,e_X,o_Z,a_Z,b_Z,e_Z,\\
i_X,h_X,o_Y,a_Y,b_Y,e_Y,o_{k+3}.
\end{split}                                               \tag{3}
\]
Consecutive edges alternate between \(M\) and \(A\);
all are given by the left-rainbow row of (2), the
face chords, or the old-cycle pairs in \(A\).
This path visits every exceptional free slot and
every face-block endpoint exactly once. Outside the
group, the ordinary free chain is unchanged.

For the right rainbow the corresponding segment is
\[
\begin{split}
e_{k-1},o_X,a_X,b_X,e_X,i_Y,h_Y,o_Z,a_Z,b_Z,e_Z,\\
o_Y,a_Y,b_Y,e_Y,i_X,h_X,o_{k+3}.
\end{split}                                               \tag{4}
\]
It has the same edge and coverage properties.
In either case the free path and the disjoint
target-and-square path join at \(x,v\) into one
Hamilton cycle containing \(xy,uv\). Note 001
lifts it through the site expansion, and Note 178
restores longer lobes. \(\square\)

The paired-square row is realized by the \(r=3\) member
of Note 217's explicit Barnette family. The two rainbow
rows are also realized in the Barnette class. For the left
row, retain the cycle (7) and all nonfree matching edges
(8) of that family at \(r=3\), and replace its free
matching by the left-rainbow row of (2). The chords on
the common-face side remain disjoint; those on the
opposite side are nested or disjoint in the order shown
by (2), so the graph remains planar. Its matching-chord
interlacement graph is connected: the chain
\[
xy-e_0i_3-a_3b_3-e_3o_4-uv-\gamma_1L_1-
\alpha_1\beta_1-\delta_1R_1-xy
\]
is augmented by \(a_1b_1-o_1h_3-a_3b_3\),
\(a_1b_1-i_1e_2-a_2b_2\), and the remaining
two free chords \(h_1o_3,e_1o_2\), each of which
interlaces \(a_1b_1\). The two-edge-cut argument of
Note 217 therefore proves three-connectivity.
Reversing the old cycle and exchanging the site labels
realizes the right-rainbow row. The common face, site
colours and square-expansion cut projection of Note 217
also apply to these two profiles, so their site-expanded
children are Barnette graphs.

The theorem
does not classify longer free groups, two vacancies
in one block, defective target order, interblock
gaps, or nonsquare residual cycles.
[Note 221](221-every-isolated-two-vacancy-corridor-has-a-marked-hamilton-cycle.md)
subsequently settles the same isolated-group shape
for every number of intermediate short blocks.
