> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Defect normalization fails before the labelled inverse-square interface

[Note 089](089-two-extendability-reaches-the-square-fixed-slice-but-not-the-linkage-fibre.md)
isolated a proposed normalization step for a globally minimum atomic
two-switch.  If

\[
M\triangle N=C_1\mathbin{\dot\cup}C_2
\tag{1}
\]

is a minimum cross-sector pair in the fixed-pairing fibre, the hoped-for
profile was

\[
\bigl\{(\pi(M\triangle C_i),c(M\triangle C_i)):i=1,2\bigr\}
=\{(\pi_1,0),(\pi_0,1)\}.
\tag{2}
\]

This note shows that (2) is not a consequence of endpoint-orbit topology,
planarity of the residual graph, cubic bipartite incidence, or even the
complete fixed-pairing fibre and its global minimum.  A 20-vertex residual
graph has a complete \(4+4\) fibre with minimum cross-sector distance two,
but both proper toggles have profile \((\pi_0,1)\).

The example stops at an exact boundary.  None of its eight labelled
inverse-square attachments is simultaneously planar and bipartite.  Thus it
does not refute normalization for an actual legal plane square interface;
it proves that such a theorem must use the labelled inverse-square
realizability, and possibly the brace condition, rather than only the
residual fibre.

## 1. The residual graph

Begin with the graph on

\[
\{p_0,p_1,p_2,p_3,q_0,\ldots,q_7\}
\tag{3}
\]

having edges

\[
\begin{aligned}
&p_0p_1,p_0p_3,p_1p_2,p_1q_0,p_2p_3,p_2q_5,\\
&q_0q_1,q_1q_2,q_1q_4,q_2q_3,q_2q_7,q_3q_4,
q_3q_6,q_4q_5,q_5q_6,q_6q_7.
\end{aligned}
\tag{4}
\]

Replace \(q_3q_4\) by the plane two-pole \(Q_3-A_0B_0\), attaching
\(q_3A_0\) and \(q_4B_0\).  In the bipartition
\(A_0,A_1,A_2,A_3\mid B_0,B_1,B_2,B_3\), the pole edges are

\[
\begin{aligned}
&A_0B_1,A_0B_2,\\
&A_1B_0,A_1B_1,A_1B_3,\\
&A_2B_0,A_2B_2,A_2B_3,\\
&A_3B_1,A_3B_2,A_3B_3.
\end{aligned}
\tag{5}
\]

Call the resulting graph \(R\).  It is simple, connected, planar and
bipartite, has 20 vertices and 28 edges, and its only degree-two vertices
are

\[
T=\{p_0,p_3,q_0,q_7\}.
\tag{6}
\]

All other vertices have degree three.  Fix

\[
\pi_0=\{p_0p_3,q_0q_7\},
\qquad g=p_0p_1,
\tag{7}
\]

where the pairs in \(\pi_0\) denote the endpoint pairs of the two complement
paths.  Let \(\mathcal L\) be the complete set of perfect matchings \(P\)
of \(R\) for which \(R-P\) is exactly two spanning paths with pairing
\(\pi_0\), and split it by membership of \(g\).

## 2. A full-fibre minimum with two equal defects

The graph has 45 perfect matchings, and direct classification gives

\[
|\mathcal L|=8,
\qquad |\mathcal L^1|=|\mathcal L^0|=4.
\tag{8}
\]

Across the complete product \(\mathcal L^1\times\mathcal L^0\), the number
of alternating components of the symmetric difference has distribution

\[
2^4,\qquad3^{10},\qquad4^2.
\tag{9}
\]

In particular, the global cross-sector minimum is exactly two.

Let

\[
K=\{A_0B_1,A_1B_3,A_2B_0,A_3B_2\}
\tag{10}
\]

be a perfect matching of the inserted pole, and define

\[
\begin{aligned}
M={}&K\cup\{p_0p_1,p_2p_3,q_0q_1,q_2q_3,q_4q_5,q_6q_7\},\\
N={}&K\cup\{p_0p_3,p_1q_0,p_2q_5,q_1q_4,q_2q_7,q_3q_6\}.
\end{aligned}
\tag{11}
\]

Then \(M\in\mathcal L^1\), \(N\in\mathcal L^0\), and

\[
M\triangle N=C_8\mathbin{\dot\cup}C_4,
\tag{12}
\]

where

\[
\begin{aligned}
C_8={}&(p_0,p_1,q_0,q_1,q_4,q_5,p_2,p_3,p_0),\\
C_4={}&(q_2,q_3,q_6,q_7,q_2).
\end{aligned}
\tag{13}
\]

Both proper toggles preserve the terminal pairing and create exactly one
closed complement cycle:

\[
(\pi(M\triangle C_8),c(M\triangle C_8))
=(\pi_0,1)
=(\pi(M\triangle C_4),c(M\triangle C_4)).
\tag{14}
\]

Thus neither proper toggle belongs to \(\mathcal L\), the two-coordinate
cube is atomic, and the pair is globally minimum by (9), but the proposed
normalization (2) fails.

This is stronger than a four-state endpoint model: the quantifiers in
(8)--(9) range over the complete perfect-matching family of the residual
graph.  Consequently no proof using only the three endpoint involutions of
[Note 081](081-target-preserving-exchange-is-a-two-rooted-orbit-and-single-cycle-components-can-be-closed.md),
the scalar defects \((\pi,c)\), and global minimality inside the residual
fibre can establish (2).

## 3. The labelled inverse-square obstruction

To recover a cubic square extension, assign the two pairs in \(\pi_0\) to
the two ordered square channels \((u,y)\) and \((v,x)\), orient each pair,
attach the four terminals to \(u,v,x,y\), and add the square

\[
u-v-x-y-u.
\tag{15}
\]

There are eight labelled attachments: two choices of channel assignment and
two orientations for each pair.  Exactly four are planar and nonbipartite,
and exactly four are bipartite and nonplanar.

For a planar attachment, one orientation contains the odd cycle

\[
q_0-v-u-p_0-p_1-q_0.
\tag{16}
\]

For a bipartite attachment with channel order
\((p_0,q_7,q_0,p_3)\), a \(K_{3,3}\)-subdivision has branch bipartition

\[
\{p_0,v,y\}\mid\{p_3,u,x\}.
\tag{17}
\]

Its nine branch paths are

\[
\begin{array}{lll}
p_0-p_3,&p_0-u,&p_0-p_1-q_0-x,\\
v-u,&v-x,&v-q_7-q_6-q_5-p_2-p_3,\\
y-u,&y-x,&y-p_3.
\end{array}
\tag{18}
\]

The other attachments follow by reversing channels or exchanging their
roles.  Hence no attachment is a legal plane cubic bipartite square
interface.

## 4. Exact boundary

**Countermodel.**  A simple connected plane bipartite four-terminal graph,
with all nonterminals cubic, can have a complete fixed-pairing fibre whose
global cross-sector minimum is an atomic two-switch with defect multiset

\[
\{(\pi_0,1),(\pi_0,1)\}.
\tag{19}
\]

**Route closure.**  Defect normalization is false at the endpoint-orbit,
residual planarity, cubic bipartite incidence and complete-fibre levels.
Global minimality does not add a local equation selecting the asymmetric
profile in (2).

**Remaining interface.**  It is still unknown whether (19) can occur when
the labelled inverse-square extension is simultaneously planar and
bipartite, and a fortiori when that extension is a brace.  A positive
theorem must therefore use labelled extension realizability or a stronger
brace-level family-supplementation argument.  The proposed separator route
of Note 089 cannot begin from normalization without such a new input.

The complete enumeration and the eight attachment checks are frozen in the
[verification bundle](../computations/bundles/defect-normalization-full-fibre-countermodel/README.md).

