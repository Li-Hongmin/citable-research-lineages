> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-slot gaps at first surplus must split and disrupt a transition

[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
counts the free-vertex surplus by extra block slots and interblock
gap slots. [Note 197](197-gapless-square-trap-defect-budget.md)
pins the targets when all block capacity is saturated and the gaps
have even lengths. The first possible positive gap, two consecutive
slots in one gap, in fact cannot occur: its first slot has no
noncrossing matching mate.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
the disjoint cofacial matching site edges \(q=xy,p=uv\). Select an
all-square opening with \(\ell,r\ge1\), compress its lobes as in
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
and suppose \(f=4r+4\). Use the blocks
\(B_0=[x,y]_C\), \(B_i=[a_i,b_i]_C\) for \(1\le i\le r\), and
\(B_{r+1}=[u,v]_C\), with gaps \(G_0,\ldots,G_r\).

**Single-gap exclusion theorem.** It is impossible for one gap
\(G_k\) to have exactly two interior slots while all other gaps
are empty and the block capacity is saturated:
\(\sum_{i=0}^{r+1}k_i=\ell-1\). Consequently, at
\(f=4r+4\), any opening with gap slots must put its two
slots in distinct gaps.

**Proof.** Let the two consecutive gap slots be \(g,h\), in
main-segment order. Every block starts with an odd-index interior
slot, since the only gap has even length. By Note 197's
saturated-gap theorem, \(R_\ell\) is the first interior slot of
\(B_0\), \(L_1\) is the final slot of \(B_{r+1}\), and every
\(L_j,R_{j-1}\), \(j\ge2\), is adjacent on \(C\).
Every eligible even block slot is occupied by a nonfinal
\(L\)-target. Thus the free block slots are the final even
slot \(e_0\) of \(B_0\), the first odd and final even slots
\(o_i,e_i\) of each face block, and the first odd slot
\(o_{r+1}\) of the final site block. The gap slots have
colours \(g=E,h=O\), and \(gh\in E(C)\).

No free matching edge can cross an occupied target run.
Indeed, before a first \(L\)-target in a face block \(B_i\),
the number of preceding free main slots is \(2i\) if
\(i\le k\) and \(2i+2\) if \(i>k\); before the final
site-block target run it is \(2r+4\), and in \(B_0\) it
is zero. All counts are even. A cross-block or gap-to-block
free edge straddling the target would cross its escape edge
by [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Within its block at most one free edge \(o_ie_i\) could
cross the run, so matching parity excludes it too.
In a short block \(o_i,e_i\) are adjacent on \(C\) and
cannot match. The two gap vertices are also adjacent.
Hence every free matching edge joins distinct atoms.
By [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
and the gap observation in Note 195, all those edges lie
in the disk opposite the common site face and are noncrossing.

The even gap vertex \(g\) cannot match \(h\), because
\(gh\in E(C)\). Its only other odd free candidates are
the block slots \(o_j\). If \(j\le k\), the free slots
strictly between \(o_j\) and \(g\) are
\[
 e_j,o_{j+1},e_{j+1},\ldots,o_k,e_k,
\tag{1}
\]
an odd number. If \(j\ge k+1\), the free slots strictly
between \(g\) and \(o_j\) are
\[
 h,o_{k+1},e_{k+1},\ldots,e_{j-1},
\tag{2}
\]
also an odd number; for \(j=k+1\) this is just \(h\).
In a noncrossing matching on one disk, all free endpoints
strictly inside the chord \(go_j\) must match one another.
Either odd interior count is impossible. Thus \(g\) has
no matching mate, a contradiction. \(\square\)

There is a further restriction on the remaining gap shape.

**Split-gap transition theorem.** If the two gap slots occupy
distinct gaps \(G_a,G_b\), \(a<b\), then at least one consecutive
target transition \(L_j,R_{j-1}\) is nonadjacent on \(C\).
By Note 197, every such transition ends at the second interior
slot of a reversed block strictly between the two gaps.

**Proof.** Suppose instead that every transition is adjacent.
Note 197 pins the endpoint targets. Blocks through \(B_a\)
and after \(B_b\) are forward: their interiors begin \(O,E\).
The blocks \(B_{a+1},\ldots,B_b\) are reversed: their
interiors begin \(E,O\). Call the first gap slot \(g=E\)
and the second \(h=O\).

Capacity saturation puts a nonfinal \(L\)-target at every
eligible even block position. Tight transitions put its
successor \(R\)-target in the following odd position.
Consequently each reversed block has precisely its first
\(E,O\) pair free; a forward face block has its first
\(O\) and final \(E\) slots free, as before. Each occupied
target run is a free-matching barrier. The free-slot count
before its first target is even: it is \(2t\) in forward
blocks before \(g\), and \(2t+2\) in reversed blocks and
forward blocks after \(g\), where \(t\) is the block index.
Cross-atom edges cannot straddle an escape target, and at
most one same-block edge could cross its run, so parity
forbids any crossing. Within a reversed block the first
two free slots are adjacent on \(C\); in a forward block
the two free slots are either adjacent or separated by
a forbidden target barrier. Thus every free matching
edge joins distinct atoms and lies in the same
opposite-side disk, where the edges are noncrossing.

Consider the even vertex \(g\). If it matched a free odd
slot \(o_t\) before the first gap, the intervening free
sequence would end with \(e_a\) and have odd size, as in
(1). If it matched the second free slot of a reversed
block \(B_t\), the slots inside that chord would consist
of complete first-slot pairs of earlier reversed blocks
and the first \(E\) slot of \(B_t\), again an odd number.
If it matched a free odd slot after the second gap, the
interior would consist of complete reversed-block pairs,
the singleton \(h\), and complete forward-block pairs:
again odd. Noncrossing rules out all three possibilities.

Only \(gh\) remains. If any reversed block contains an
occupied target run, \(gh\) straddles that target and is
forbidden by Note 203. Otherwise all reversed blocks
are short and target-free. Noncrossing inside \(gh\)
would match every free slot of the consecutive block
interval \(B_{a+1},\ldots,B_b\) internally. Together with
their fixed face chords, that interval is closed under
the full complementary matching and has exactly two
departing old-cycle edges. This contradicts
three-edge-connectivity. Hence \(g\) has no mate after
all, and the assumed tight transition order is
impossible. \(\square\)

Together with [Note 212](212-every-gapless-first-surplus-opening-has-a-marked-hamilton-cycle.md),
the only all-square first-surplus shape not yet settled is
two singleton gaps with at least one nonadjacent transition
ending inside the reversed block run. No Hamilton assertion
is made for that shape or for nonsquare residual cycles.

[Note 214](214-all-two-slot-gaps-are-excluded-at-first-surplus.md)
subsequently excludes the remaining split-gap shape as well.
