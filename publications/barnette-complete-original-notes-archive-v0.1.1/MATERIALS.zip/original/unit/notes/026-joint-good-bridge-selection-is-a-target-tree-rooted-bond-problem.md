> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Joint good-bridge selection is a target-tree rooted-bond problem

> **Correction.** The exact reductions below remain valid, but the universal
> implication proposed in (19) is false. [Note 027](027-full-hamilton-family-saturation-does-not-force-a-good-bridge.md)
> gives a real order-\(26\) brace whose complete Hamilton family has global
> \(H^{+-}\), targets, and compatible bridges, but no simultaneous
> target-tree/rooted-two-bond selection.

The compatible-bridge strategy has an exact residual obstruction. Once a
state-\(00\) Hamilton-complement matching and a target near-perfect matching
are fixed, the two sides of the bridge decouple into two exchange-cycle
avoidance tests. In the planar dual these tests are rooted bonds after
contracting a forest contained in a target spanning tree. This note also
shows that global \(H^{+-}\), genuine common cubic matching incidence,
single-cycle exchange connectivity, and the complete target family do not
force the required bridge unless the Hamilton-complement family is
exhaustive.

The result is an exact reduction and a sharp route boundary. It is not a
proof that global \(H^{+-}\) is preserved by every legal \(C_4\)-expansion.

## Exact cycle-avoidance factorization

Let \(F\) be a plane cubic bipartite brace with global \(H^{+-}\), and let
\((u,v,z,a)\) be a legal cofacial \(P\)-regime orientation. Put

\[
p=uv,\qquad h=za.
\]

For a Hamilton-complement perfect matching, let \(V_{ij}\) denote its
\((p,h)\)-membership class. A compatible bridge is a triple

\[
L-W-R,\qquad L\in V_{01},\quad W\in V_{00},\quad R\in V_{10},
\tag{1}
\]

such that

\[
C_h=L\triangle W,\qquad C_p=R\triangle W
\tag{2}
\]

are single alternating cycles. Define the target family

\[
\mathcal P=\left\{T\in\operatorname{PM}(F-\{u,a\}):
F-\{p,h\}-T\text{ is a Hamilton }v\text{-}z\text{ path}\right\}.
\tag{3}
\]

Fix \(W\in V_{00}\), \(T\in\mathcal P\), and write

\[
S=S(W,T)=T\setminus W.
\tag{4}
\]

Because \(S\cap W=\varnothing\), for \(L=W\triangle C_h\) and
\(R=W\triangle C_p\) one has

\[
S\cap L=S\cap C_h,\qquad S\cap R=S\cap C_p.
\tag{5}
\]

Consequently the common-complement condition is equivalent to

\[
T\setminus W\subseteq E(F)\setminus(L\cup W\cup R)
\quad\Longleftrightarrow\quad
S\cap C_h=S\cap C_p=\varnothing.
\tag{6}
\]

Let

\[
\begin{aligned}
\mathcal C_h(W)&=\{W\triangle L:L\in V_{01},\ W\triangle L
\text{ is one cycle}\},\\
\mathcal C_p(W)&=\{W\triangle R:R\in V_{10},\ W\triangle R
\text{ is one cycle}\}.
\end{aligned}
\tag{7}
\]

For the fixed pair \((W,T)\), the choices of \(L\) and \(R\) are independent.
Thus a good bridge exists exactly when

\[
\boxed{
\exists W\in V_{00},\ \exists T\in\mathcal P:
S(W,T)\text{ is a transversal of neither }
\mathcal C_h(W)\text{ nor }\mathcal C_p(W).}
\tag{8}
\]

The exact obstruction is therefore that \(\mathcal P\) is empty, or that
every pair \((W,T)\) makes \(S(W,T)\) meet every exchange cycle on at least
one of the two rooted sides. Neither an intersection condition between
\(C_h\) and \(C_p\) nor a coupled choice after \((W,T)\) is fixed remains.

## Dual target-tree quotient

Let \(\mathsf T=F^*\), a simple 4-connected Eulerian plane triangulation,
and put

\[
B=T\cup\{p,h\}.
\tag{9}
\]

The target condition has the tree-cotree form

\[
T\in\mathcal P
\quad\Longleftrightarrow\quad
B^*\text{ is a spanning tree of }\mathsf T
\text{ and }F-B\text{ has endpoints }v,z.
\tag{10}
\]

Represent \(W\) by its normalized admissible dual 2-colouring
\(\chi_W\). If \(p^*=q\alpha\) and \(h^*=q\beta\), normalize
\(\chi_W(q)=0\). A state-\(00\) matching has rooted colour pattern

\[
(\chi_W(\alpha),\chi_W(q),\chi_W(\beta))=(1,0,1).
\tag{11}
\]

For another Hamilton-complement matching \(M\), let

\[
D(W,M)=\{x:\chi_W(x)\ne\chi_M(x)\}.
\tag{12}
\]

Bond-cycle duality gives

\[
W\triangle M=\delta_{\mathsf T}(D(W,M))^*,
\tag{13}
\]

and this symmetric difference is one alternating cycle precisely when
both induced shores are connected.

Now set

\[
\mathsf S=(T\setminus W)^*.
\tag{14}
\]

Since \(\mathsf S\subseteq B^*\), it is a forest. An exchange cycle avoids
\(S\) if and only if its disagreement shore is a union of components of
\((V(\mathsf T),\mathsf S)\). Equivalently, after contracting those
components,

\[
\overline{\mathsf T}=\mathsf T/\mathsf S,
\tag{15}
\]

the shore descends to a bond of \(\overline{\mathsf T}\). Connectivity of
both shores is preserved by this contraction.

Therefore (8) is equivalent to the existence of a target spanning tree,
a rooted admissible colouring of type \(101\), and two bonds in the
target-forest quotient: one changes the rooted pattern to \(100\), and the
other changes it to \(001\), with both resulting colourings still
admissible. This is a simultaneous target-tree/rooted-two-bond selection
problem. Ordinary bond existence is insufficient: switching across the
bond must preserve connectedness of both colour classes.

## A one-matching deletion boundary

The exhaustive-family hypothesis is genuinely load-bearing. Consider the
order-\(22\) brace with graph6 string

```text
U?????????[?s?b??[?CoI_?L??_o?`_@_G?@W??
```

and legal site

\[
(u,v,z,a)=(16,2,20,10),\qquad p=2\,16,\quad h=10\,20.
\tag{16}
\]

The graph has \(119\) perfect matchings and \(32\) Hamilton-complement
matchings. The relevant layer sizes are

\[
(|V_{00}|,|V_{01}|,|V_{10}|)=(22,2,4).
\tag{17}
\]

There are \(41\) compatible bridges and four genuine targets. Among all
\(22\cdot4=88\) pairs \((W,T)\), exactly one passes both avoidance tests in
(8), and exactly one compatible bridge succeeds.

Deleting any one of the three Hamilton-complement matchings \(L,W,R\) in
that unique bridge leaves a \(31\)-matching family such that

1. every retained vector is a genuine Hamilton-complement perfect matching
   of the same plane cubic bipartite brace;
2. global \(H^{+-}\) still holds for every ordered pair of distinct edges;
3. the single-cycle exchange graph remains connected;
4. all four genuine target near-matchings remain available; and
5. respectively \(21\), \(40\), or \(29\) compatible bridges remain, but
   none succeeds.

Thus

\[
\boxed{
\begin{gathered}
\text{global incidence + genuine common cubic incidence}\\
+\ \text{exchange connectivity + complete target family}
\end{gathered}
\not\Longrightarrow
\text{a good bridge}.}
\tag{18}
\]

This is not a graph/site counterexample: the deleted matching is admissible,
and restoring the complete \(32\)-matching Hamilton family restores the
unique good bridge. It proves that a proof cannot replace exhaustive
Hamilton-family saturation by incidence coverage or exchange connectivity,
even when only one admissible matching is omitted.

As a fixed-object boundary check, all \(840\) ordered \(P\)-regime sites in
four previously frozen order-\(18/22\) braces have at least one successful
bridge; twelve have exactly one. This is not an order census and is not
evidence sufficient for a general theorem.

## Remaining assertion

The sole unresolved implication at this interface is

\[
\boxed{
\text{global }H^{+-}
\Longrightarrow
\text{simultaneous target-tree/rooted-two-bond selection}.}
\tag{19}
\]

Full-family exhaustiveness supplies every admissible dual colouring, but it
does not presently imply that some \(S=T\setminus W\) avoids an exchange
cycle on both rooted sides. Proving (19) would already settle the open
\(P\)-regime target-existence problem. It would still have to be inserted
into the full \(C_4\)-child argument before yielding preservation of global
\(H^{+-}\), and therefore does not by itself prove Barnette's conjecture.

The fixed-object certificate is reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-barnette/analyze_joint_good_bridge_closure.py
```

with terminal marker

```text
JOINT_GOOD_BRIDGE_CLOSURE_ANALYSED
```
