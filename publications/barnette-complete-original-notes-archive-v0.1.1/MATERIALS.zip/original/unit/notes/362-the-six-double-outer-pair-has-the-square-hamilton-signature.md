> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The six-double outer pair has the square Hamilton signature

[Note 361](361-every-consecutive-forward-six-double-group-has-a-spanning-route.md)
classifies the \(h_1j_6,k_1i_6\) first-return branch of a
consecutive forward six-double ordinary free group into at most
five matching words \(A_0,\ldots,A_4\). Its proof gives one
spanning route for each word. In fact every such word has
the complete four-terminal Hamilton linkage signature of
a square.

Use Note 361's six blocks \(D_1,\ldots,D_6\), their full
old-cycle path, block-closing chords, alternating \(J_3,J_1\)
internal chords, and one of the five opposite-page matchings
in its table. Remove the two exterior matching edges
\(Lo_1,e_6R\). The resulting 48-vertex disk patch \(T_t\)
has degree-two terminals
\[
                         (a_1,o_1,e_6,b_6)                 \tag{1}
\]
in that boundary order; all other vertices have degree three.
The statement is conditional on such a patch occurring in a
plane Barnette parent. It does not assert that all five formal
words are realized.

**Exact-signature theorem.** For every \(t=0,\ldots,4\),
\(T_t\) has spanning single paths for precisely the four
terminal pairs
\[
 a_1b_6,\qquad o_1e_6,\qquad a_1o_1,\qquad e_6b_6,          \tag{2}
\]
and spanning pairs of disjoint paths for precisely the two
terminal pairings
\[
 \{a_1b_6,o_1e_6\},\qquad \{a_1o_1,e_6b_6\}.                \tag{3}
\]
The same states occur in the square with terminals in order
(1). Thus replacing \(T_t\) by that square preserves every
Hamilton-cycle decision on the exterior and four attachment
edges. For any \(t\) whose patch actually occurs in a
Barnette graph, the replacement in either direction also
preserves membership in the Barnette class. This last
assertion does not claim that every formal \(A_t\) is realized.
In particular, a vertex-minimal non-Hamiltonian Barnette
graph contains no induced disk copy of such an actual patch.

**Single paths.** The full old-cycle path through all six
blocks gives \(a_1b_6\). Note 361 (5) with \(L,R\) removed
gives \(o_1e_6\) for \(A_0,\ldots,A_3\); its reflected
route gives \(o_1e_6\) for \(A_4\).

Let \(O_{2:5}\) denote the full old-cycle path from \(a_2\)
to \(b_5\), through the four complete middle blocks.
For every \(A_t\), independently of its middle matching,
the following is a spanning \(e_6\)--\(b_6\) path:
\[
 E=(e_6,j_6,k_6,o_6,h_6,i_6,k_1,j_1,e_1,i_1,h_1,
       o_1,a_1,b_1,O_{2:5},a_6,b_6).                     \tag{4}
\]
Its non-old joins are \(k_6o_6,k_1i_6,e_1i_1,
a_1b_1,a_6b_6\); the joins \(b_1a_2,b_5a_6\)
are old-cycle edges. The path uses each vertex of
\(D_1,D_6\) once and uses \(O_{2:5}\) once.

Apply Note 346 (4) with \(N=6\) to (4), then reverse the
vertex order. This gives a spanning \(a_1\)--\(o_1\)
path in every \(T_t\): the reflection preserves all
old and prescribed internal chords and fixes \(k_1i_6\),
the only opposite-page chord used in (4).

**Two-path states.** For \(t=0,1,2,3\), let \(M_t\)
be the 32-vertex middle path in Note 361 (4). Its first
vertex is \(h_2\); its last vertex is \(j_5\) for
\(t=0,1,2\) and \(i_2\) for \(t=3\). In both cases
its last vertex is matched to \(h_6\).
For the first pairing in (3), take
\[
\begin{split}
 U_t&=(a_1,b_1,e_1,j_1,M_t,h_6,o_6,a_6,b_6),\\
 V&=(o_1,h_1,i_1,k_1,i_6,k_6,j_6,e_6).
\end{split}                                                \tag{5}
\]
The joins from \(j_1\) into \(M_t\) and from \(M_t\)
to \(h_6\) are the matching edges stated in Note 361;
\(k_1i_6\) is the only cross-block edge of \(V\).
The paths are disjoint and together use all 48 vertices.

For the second pairing, take
\[
\begin{split}
 X_t&=(a_1,b_1,e_1,j_1,M_t,h_6,i_6,k_1,i_1,h_1,o_1),\\
 Y&=(e_6,j_6,k_6,o_6,a_6,b_6).
\end{split}                                                \tag{6}
\]
Here \(h_6i_6\) is an old-cycle edge,
\(i_6k_1\) is the fixed matching chord,
and \(k_6o_6\) and \(a_6b_6\) are prescribed
internal and closing chords. Again the two paths
are disjoint and span \(T_t\).

The reflection \(\rho\) of Note 346 (4) maps \(A_3\)
to \(A_4\). It maps the first pairing in (3) to
itself and interchanges the two paths of the second
pairing. Reflecting (5)--(6) therefore supplies
both states for \(A_4\).

A spanning single path has 48 vertices and hence
opposite-colour endpoints, excluding \(a_1e_6\)
and \(o_1b_6\). The only other pairing of the four
terminals is \(\{a_1e_6,o_1b_6\}\); its two paths
would cross in the disk because the four terminals
occur in the cyclic order (1). Thus (2)--(3)
are the complete signature, exactly as for a square.
A Hamilton cycle uses two or four attachment edges
at a four-terminal patch, so replacing its internal
path or path pair by the corresponding square state,
or conversely, proves the exterior-preservation claim.

**Barnette-class preservation.** Fix one \(T_t\) that occurs
in a Barnette graph. Its actual disk embedding and the square
embedding have the same ordered terminals and colour classes,
so substitution in either direction preserves planarity,
bipartiteness, cubicity and simplicity. The exterior of either
patch in a three-connected cubic host is connected: if it had
two components, each would require at least three of the
four attachment edges, impossible.

Deleting any one vertex of \(T_t\) leaves it connected.
Indeed each block's old-cycle path plus \(a_sb_s\) is a cycle,
so each surviving block remains connected. Contract these
six connected block remnants. The five old interblock edges
form a path with at most one edge lost by the vertex deletion.
At least one of the two chords \(h_1j_6,k_1i_6\) survives
and joins the first and last remnants. The quotient is
connected. Moreover, after deleting any two vertices of
\(T_t\), every surviving component has a surviving terminal.
Otherwise that component has no edge to the exterior and
would remain disconnected in the actual three-connected
Barnette realization after those two deletions. The square
has the same two deletion properties.

These properties give the four-attachment deletion comparison.
With two patch vertices deleted, every patch component
connects through a surviving terminal to the intact connected
exterior. With one patch and one exterior vertex deleted,
the patch remains connected; each component of the surviving
exterior has an attachment at a surviving terminal. This
last condition follows in either host from its
three-connectivity and is unchanged by substitution; when
the deleted patch vertex is a terminal, compare it with the
corresponding square terminal. With two exterior vertices
deleted, the intact connected patch joins every surviving
exterior component, again because each component must retain
an attachment in the original three-connected host.
Thus deletion of any two vertices leaves the substituted
graph connected in either direction. Both replacements are
three-connected and hence remain Barnette graphs. \(\square\)

The argument establishes a Hamilton linkage signature
and a conditional class-preserving square reduction for the
specified \(k_1i_6\) branch. It does not establish realization
of all five formal matching words, classify other six-block
matchings by four-terminal signature, handle short corridors
or other opening types, or decide Barnette's conjecture.
This is a project-internal analytic proof without an external
priority claim or independent review.
