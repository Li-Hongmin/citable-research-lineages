> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every all-square second-surplus opening is Hamiltonian

[Note 254](254-every-gapless-all-square-second-surplus-opening-is-hamiltonian.md)
settles the gapless second surplus. [Notes 255--257](257-split-gaps-require-a-target-bearing-vacancy-block.md)
reduce positive gaps to two singleton gaps whose unique free
eligible vacancy shares a block with an escape target. The
remaining matching can be excluded without locating every
target transition: the two gap slots need two mates in that
block, leaving room for only one face-side chord. Matching
parity forces this chord into a four-slot run on one side of
all targets, where one gap chord necessarily straddles an
escape target.

Let \(G\) be a three-connected cubic bipartite plane graph
with a Hamilton cycle \(C\) avoiding two disjoint cofacial
matching site edges \(xy,uv\). Select an all-square facial
opening with \(\ell,r\ge1\), possibly with interblock gaps,
and compress its square-trap lobes as in Note 178. Let
\(f\) be its number of free main vertices.

**Gap-edge localization lemma (all surpluses).** No two gap
slots are joined by \(M=E(G)\setminus E(C)\). If a gap slot
\(g\) is matched to a block slot \(w\in B_i\), then \(B_i\)
contains a free-slot matching chord drawn on the designated-face
side of \(C\). More precisely, an odd number of its face-side
free chords have endpoints on opposite sides of \(w\).

**Proof.** A matching edge \(gh\) between gap slots lies on the
opposite side by Notes 193 and 195. If an escape target occurs
strictly between \(g,h\), it is forbidden by Note 203. Otherwise
take the consecutive \(C\)-interval from \(g\) through \(h\).
It contains no escape target, and every block meeting it is
complete. Every block-closing matching edge is internal. A
free-slot matching edge leaving the interval on the opposite
side would interlace \(gh\); a face-side free chord cannot
leave it, because each such chord stays within one complete
block. Thus the interval is matching-closed. If \(g,h\) are
adjacent, \(gh\) is already an edge of \(C\); otherwise the
interval has only two departing \(C\)-edges, contrary to
three-connectivity. Hence no gap-to-gap matching edge exists.

Now let \(gw\in M\), with \(w\in B_i\). Note 203 excludes an
escape target strictly between its endpoints. The interval
strictly between \(g,w\) contains an odd number of free slots:
its total vertex count is even by bipartiteness, while the
fixed block endpoints in it number one modulo two, as in
Note 255. Every opposite-side chord from an interior free
slot to an exterior free slot would interlace \(gw\).
Therefore an odd number of interior free slots must leave
through face-side chords. Only \(B_i\) is cut by this interval
at a block interior; every other block is wholly inside or
outside. Thus an odd number of face-side chords in \(B_i\)
straddle \(w\), including at least one. \(\square\)

**All-square second-surplus Hamilton theorem.** If
\[
f=4r+6,                                           \tag{1}
\]
then \(G\) has a Hamilton cycle containing both \(xy,uv\).
Consequently every legal site-expanded Barnette child
admitting this opening is Hamiltonian. The statement allows
arbitrary placements and lengths of interblock gaps and
arbitrary positive lengths of the original square-trap lobes.

**Proof.** Let \(k_i\) be the block capacities of Note 195,
\(t_i\) the gap lengths, and put
\[
\sigma=\sum_i k_i-(\ell-1),\qquad T=\sum_i t_i.
\]
Note 195 gives \(2\sigma+T=4\). When \(T=0\), Note 254
gives the marked Hamilton cycle. For \(T>0\), Note 255
excludes \((\sigma,T)=(0,4)\), Note 256 excludes a single
two-slot gap at \((1,2)\), and Note 257 excludes a
target-free vacancy block in the split-gap case. The
unique eligible position cannot be occupied by \(L_1\):
if it were, all \(K\) eligible positions of its block
would be \(L\)-targets, and all \(K-1\) nonfinal ones
would have their successor \(R\)-targets in that block
before \(L_1\). At most three interior slots would be
free. The even-prefix barrier of Note 255 excludes a
same-block chord crossing a target, and three consecutive
free slots admit no non-cycle internal chord. Thus this
block could not supply Note 255's required face-side chord;
all other blocks are saturated and cannot supply one either.
We therefore need only disprove this remaining
shape:
\[
G_a=\{g\},\quad G_b=\{h\},\quad a<b,\qquad
g=E,\ h=O,\quad \sigma=1,                         \tag{2}
\]
with a free eligible vacancy \(H\) in a block \(B_k\)
containing at least one escape target. All other eligible
positions are occupied by nonfinal \(L\)-targets.

Call a free-slot matching chord *face-side* when drawn on the side containing the
designated common face. Cross-block and gap chords are
on the other side by Notes 193 and 195. A block with all
eligible positions occupied has no same-block free chord:
the local slot list and even-prefix proof of Note 255
apply within that block, independently of vacancies in
other blocks. Hence every face-side free chord has both
endpoints in \(B_k\). At least one exists by Note 255.

By the gap-edge localization lemma, both gap slots use
distinct free vertices of \(B_k\): they cannot match each
other, and no other block can contain a face-side free chord.

Write \(K=k_k\ge1\). Exactly \(K-1\) eligible positions
of \(B_k\) are nonfinal \(L\)-targets. All but at most the
last such \(L\)-target have their next \(R\)-target inside
\(B_k\): if one next \(R\) occurs in a later block,
no later target can remain in the source block. Hence
\(B_k\), which has \(2+2K\) interior slots, has at most
five free slots (and at most four when \(K=1\)).
If it had two same-block free matching chords, their four
endpoints plus the two distinct gap mates would require
at least six free vertices. Thus there is **exactly one**
same-block free chord, say \(e\), and it is face-side.
For either gap-to-block chord, the odd parity in the
localization lemma must be supplied by this unique chord
\(e\): exactly one endpoint of \(e\) lies strictly between
the gap and its mate. Since each gap lies outside \(B_k\),
each mate lies strictly between the endpoints of \(e\)
along \(C\). Any fifth free slot of \(B_k\) is therefore
irrelevant to the two gap mates.

For any escape target \(Q\), the number of free slots
before \(Q\) is even, by the index calculation in
Note 255. No cross-atom free chord can straddle \(Q\)
by Note 203. If \(e\) straddled \(Q\), it would be the
only remaining matching chord crossing that even
free-slot prefix, which is impossible. Thus the
endpoints of \(e\) lie in one target-free run within
\(B_k\).

A run of at most three consecutive free slots admits no
non-cycle matching chord within one block: the
opposite-colour pairs are old-cycle edges. With one
vacant eligible position and at least one target in
\(B_k\), a target-free run has at most four slots.
Four slots can occur only in one of two positions:

* \(B_k\) is forward and the run follows its last
  target: its order is \(c,H,I,e_k\). The last target
  is a nonfinal \(L_j\) whose successor \(R_{j-1}\)
  lies in a later block: \(L_1\) at that position would
  consume a second eligible vacancy. The unique non-cycle
  same-block pair in the run is \(c e_k\).
* \(B_k\) is reversed and the run precedes its first
  target: its order is \(d,o,H,I\), with colours
  \(E,O,E,O\). The unique non-cycle same-block
  pair is \(dI\).

For completeness, the forward block has at most its
first odd slot before its first target and the vacancy
pair \(H,I\), so a free prefix there has at most three
slots. A run after a target has four precisely when
that target is a source \(L_j\), leaving its following
odd slot \(c\), the vacant pair \(H,I\), and the final
even slot \(e_k\). In a reversed block, its first
even and second odd slots can precede the vacancy
pair, giving the four-slot prefix. After its last
target it has at most the following odd slot of a
source and the vacant pair, three slots. An internal
four-slot run would require two unoccupied eligible
positions or a further target between consecutive
escape targets. This proves the list.

In the forward case, the face-side chord is \(ce_k\),
so \(g,h\) must match the two remaining inner slots:
by colour, \(gI,hH\in M\). The source \(L_j\) lies
before \(H\). Its next target \(R_{j-1}\) is in a
later block. Since the sole vacancy is in \(B_k\),
that destination cannot be a later odd slot of a
block: an eligible position before it would be a
second vacancy. A first-slot destination in a
forward block creates the forbidden prefix
two-edge cut: take the main prefix through every
whole gap before that destination, together with the
corresponding residual-square suffix. A matching edge
leaving it would straddle \(R_{j-1}\) on the opposite
side, as in Notes 193 and 197. A reversed block begins
with an even slot. Therefore \(R_{j-1}\) is the second
slot of a reversed block, necessarily between
\(g\) and \(h\). The chord \(hH\) straddles this
target and is forbidden by Note 203.

In the reversed case, \(B_k\) lies between the
two singleton gaps. The face-side chord is \(dI\);
the gap mates are \(go,hH\). But \(B_k\) contains
a target, and the four-slot run precedes its
first target. Thus \(H\) lies before that target,
which lies before \(h\). The chord \(hH\) again
straddles an escape target, contradicting
Note 203. Both cases are impossible.

Hence \(T=0\), and Note 254 supplies a Hamilton
parent cycle containing \(xy,uv\). Note 001
lifts it through the legal site expansion; Note 178
restores arbitrary positive lobe lengths. \(\square\)

**Counterexample-size corollary.** Notes 196 and 214
settle the all-square openings with \(f=4r+2\)
and \(f=4r+4\), respectively. Therefore a
non-Hamiltonian legal site-expanded child admitting
a selected all-square facial opening with
\(\ell,r\ge1\) must satisfy
\[
f\ge4r+8,\qquad |V(S_0)|\ge4r+2\ell+12.
\tag{3}
\]
This constrains the selected opening class. Openings
with nonsquare residual cycles, zero opposite-face
chords, or no selected opening, and the general
Barnette conjecture, are not decided here.

**One-vacancy gap corollary.** More generally, for every
all-square opening with \(\ell,r\ge1\), a positive gap total
requires at least two unoccupied eligible block positions:
\[
T>0\quad\Longrightarrow\quad \sigma\ge2,
\qquad f\ge4r+8.                              \tag{4}
\]
Indeed, Note 255 excludes \(\sigma=0\). Suppose \(\sigma=1\),
and let \(B_k\) contain the unique eligible position not
occupied by a nonfinal \(L\)-target. Every other block is
saturated and has no same-block free chord by Note 255.
The localization lemma therefore sends **every** gap slot
to \(B_k\) and requires a face-side chord there. If the
unique position is occupied by \(L_1\), all \(K=k_k\)
eligible positions are \(L\)-targets. All \(K-1\) nonfinal
ones have their successor \(R\)-targets in the same block,
before \(L_1\), so at most three interior slots are free.
The even-prefix barrier excludes a chord across a target;
within a target-free run of at most three free slots,
opposite-colour pairs are old-cycle edges. This contradicts
the required face-side chord.

Otherwise the unique vacancy is free. If \(B_k\) is
target-free, it has exactly four free slots. If it contains
a target, the count in the proof above gives at most five.
At least two of these free slots form a face-side chord,
and all \(T\) gap slots need distinct additional mates in
\(B_k\). Thus \(T\le3\). The global slot count makes \(T\)
even, so \(T=2\). Then \(f=4r+6\) and the theorem above
excludes the opening. Therefore \(\sigma=1\) also forces
\(T=0\). The bound on \(f\) follows from Note 195's
\(f=4r+2+2\sigma+T\), since a positive \(T\) is even.
In particular, at the next boundary \(f=4r+8\), every
positive-gap opening has exactly \(\sigma=2\) and \(T=2\):
either one two-slot gap or two singleton gaps. No Hamilton
claim is made at this next boundary.
