> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One end bridge closes the direct-cross profile

[Note 494](494-direct-cross-matching-has-a-rainbow-end-bridge.md) shows that a direct-cross end-middle profile with exactly one \(W_1W_3\) face chord has site ports \(u\in X_1^-\), \(v\in W_3\). The path order left by [Note 493](493-middle-root-bridge-splice-leaves-one-ordered-path-obstruction.md) can then be bypassed by choosing two independent four-terminal path pairings before joining the middle-root complement.

Use all hypotheses and notation of Notes [492](492-two-mixed-openings-reduce-end-middle-split-pairs-to-direct-cross-chords.md) and 494. In particular, the two split nodes lie in \(W_1,W_2\); their direct matching chords are \(s_1t_2,t_1s_2\); the \(k\ge2\) matching edges between \(A_1,A_2\) are even in number; and every other assigned special position lies in a two-special leaf. Suppose the unique \(W_1W_3\) matching chord is
\[
                              xy\in M,\qquad
                  x\in X_1^-,\quad y\in W_3.             \tag{1}
\]
The root chord of \(W_2\) differs from the core chord \(H_2J_2\), as in Note 492.

**Single-bridge closure theorem.** The parent has a Hamilton cycle containing both site edges \(q=w_0u,p=vw_*\). Consequently its legal \(C_4\)-expanded child is Hamiltonian. Thus a non-Hamiltonian child in the exact direct-cross end-middle profile requires at least two \(W_1W_3\) chords; by Note 494 their number must be even and both site ports must lie in \(W_3\).

**Proof.** By the retained-chord child linkage of Note 494, there is a spanning \(L_2\)--\(R_2\) path \(T\) of \(S=A_1\cup A_2\), containing all face-matching edges internal to \(S\) and the closing chord \(L_1R_1\). Replace the old \(s_1\)--\(t_1\) subpath of the end-root base cycle \(C_1\) by
\[
          s_1,\ t_2,\ R_2\ \overleftarrow{T}\ L_2,\ s_2,\ t_1.
                                                               \tag{2}
\]
The four joining edges are respectively the direct chord \(s_1t_2\), old edge \(t_2R_2\), old edge \(L_2s_2\), and direct chord \(s_2t_1\). Formula (2) visits each vertex of \(S\) once. It therefore produces a simple cycle \(C_A\) with vertex set
\[
                V(C_A)=V(C_1)\cup V(A_2)\cup\{s_2,t_2\}.
                                                               \tag{3}
\]
It contains the end escape edges \(t_dd,t_cc\) and is disjoint from \(C_3\).

Write \(\ell_2,r_2\) for the ends of \(W_2\). The middle-root complement \(B'_2\) has a perimeter cycle
\[
 Z=(\ell_2\xrightarrow{\rm old}H_2,\ J_2
          \xrightarrow{\rm old}r_2,\ \ell_2),             \tag{4}
\]
where the \(H_2\)--\(J_2\) transition is the ordinary core chord \(H_2J_2\), and the \(r_2\)--\(\ell_2\) transition is the distinct ordinary root chord \(r_2\ell_2\). The two old flank arcs in (4) cover every vertex of \(B'_2\) once, even if their internal matching chords are ignored. Deleting \(r_2\ell_2\) and adding the old edges \(t_c\ell_2,r_2t_b\) gives a spanning \(t_c\)--\(t_b\) path \(R\) through \(B'_2\).

Now delete \(e_c=t_cc\) from \(C_A\) and \(e_b=t_bb\) from \(C_3\). The resulting spanning open arcs have terminal sets
\[
                   T_A=\{c,t_c,u,x\},\qquad
                   T_B=\{b,t_b,v,y\}.                    \tag{5}
\]
For the first arc, choose as square-supported edges \(E_A\) exactly the old edges of the two-special leaves of \(W_1\setminus A_1\). Every such edge remains on \(C_A-e_c\), and its innermost ordinary leaf chord is unused. By the matching normal form of Note 494, all their special endpoints except \(u,x\) are matched to one another within \(W_1\setminus A_1\). The open-arc four-terminal square-switch theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) therefore gives at least two distinct spanning two-path covers of \(V(C_A)\), with terminal set \(T_A\). The fixed segment (2), all matching edges internal to \(S\), and \(t_dd\) are untouched.

Apply the same theorem to \(C_3-e_b\), using the two-special leaf edges of \(W_3\). Every face-matching edge at their endpoints other than \(xy\) stays in \(W_3\), and \(v,y\) are the two unmatched terminals. This gives at least two distinct spanning two-path covers of \(V(C_3)\), with terminal set \(T_B\), preserving \(t_aa\).

There are three disjoint links between the two terminal sets:
\[
                 x-y,\qquad c-b,\qquad
                 t_c\ R\ t_b .                          \tag{6}
\]
The first is the unique end-bridge matching chord, the second is the unused old edge \(bc\), and the third is the path through \(B'_2\) just constructed. Label these links \(1,2,3\). Each two-path cover on \(T_A\) pairs \(u\) with exactly one link label and pairs the other two labels together; likewise a cover on \(T_B\) pairs \(v\) with one label. If the two chosen covers use different labels at \(u\) and \(v\), their union with (6) is one spanning \(u\)--\(v\) path. Indeed, starting at \(u\), the three links are then traversed in turn, alternating between the two covers, and the path ends at \(v\). If the labels agree, the other two links form a separate cycle.

Each side offers at least two distinct pairings, hence at least two choices of its site-terminal label among the three. Choose a label on \(T_A\) different from a label available on \(T_B\). The resulting \(u\)--\(v\) path covers \(C_A,Z,C_3\), which partition the vertices of \(D=C_1\cup C_2\cup C_3\). Finally append the outside path
\[
                         (u,w_0,\beta,\alpha,w_*,v).      \tag{7}
\]
It covers the four vertices outside \(D\), uses \(q,\alpha\beta,p\), and closes a Hamilton cycle of the parent. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts this marked cycle to the legal expanded child. \(\square\)

The proof does not need to choose a favourable traversal order for \(t_cc,t_bb\). It closes exactly the \(h=1\) branch. When both site ports lie in \(W_3\), Note 494 forces an even number \(h\ge2\) of nested \(W_1W_3\) chords; those additional chords are outside the two independent four-terminal opening hypotheses used here. Same-root split-node placements and other selected openings remain undecided.
