> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nonsquare kill-cover supplementation holds through order twenty-six in the frozen root-square stratum

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
isolates the arbitrary-order rooted split-bond lemma but leaves its actual
longer-face antecedent untested. The two earlier kill-cover examples are
opposite-edge expansions of a facial square and are already covered by
[Note 105](105-opposite-edge-expansion-of-a-facial-square-preserves-every-fibre-crossing.md).

The frozen through-order-\(26\) corpus contains \(323\) nonsquare
cofacial sites satisfying the kill-cover antecedent. Every one of the
\(322\) children that remains a legal-wide plane brace has a child
crossing, and every such crossing is supplied through the three new cells.
This is the first finite test of the actual longer-face antecedent.

## 1. Frozen scope

The input consists of the \(50\) distinct graph6 plane-brace
representatives already frozen in the permanent bundles at orders

\[
8,12,16,18,20,22,24,26.
\tag{1}
\]

No new parent graph is generated. For every graph, reconstruct every direct
root-opposite-square legal-wide occurrence and its complete fixed rooted
target fibre. This gives \(541\) fibres, all with

\[
\Gamma(\mathcal L)\ne\varnothing.
\tag{2}
\]

For each fibre, consider every bipartite cofacial \(C_4\)-expansion site
whose four endpoints avoid the root square and both named gates. Exclude
selected pairs that are opposite edges of one facial square. The resulting
nonsquare site set has size

\[
11\,435.
\tag{3}
\]

## 2. Exact classification

Exactly \(323\) sites in (3) satisfy

\[
\mathcal L_{11}\ne\varnothing,
\qquad
\mathcal L_{11}\text{ is a vertex cover of }
\Gamma(\mathcal L).
\tag{4}
\]

For \(322\) of them, the child is again a legal-wide plane brace. Every one
of these \(322\) children has

\[
\Gamma(\mathcal L^+)\ne\varnothing.
\tag{5}
\]

More sharply, the canonical--canonical child crossing count is zero in
every hit, as predicted by Note 103. Hence every child crossing is incident
with at least one of

\[
R_{00},\qquad X_{uy},\qquad X_{vx}.
\tag{6}
\]

The number of distinct new-cell crossings ranges from \(2\) to \(58\).
The remaining one of the \(323\) sites still gives a brace child with four
new-cell crossings, but the two named gates cease to be cofacial; it is not
legal-wide and lies outside the lemma antecedent.

The counts by parent order are

\[
\begin{array}{c|r|r|r|r}
\text{order}&\text{fixed fibres}&\text{nonsquare sites}&
\text{kill-cover hits}&\text{eligible positive children}\\ \hline
8&0&0&0&0\\
12&0&0&0&0\\
16&16&80&0&0\\
18&0&0&0&0\\
20&58&692&22&22\\
22&17&293&2&2\\
24&252&5\,242&251&251\\
26&198&5\,128&48&47\\ \hline
\text{total}&541&11\,435&323&322.
\end{array}
\tag{7}
\]

The hit-face lengths are

\[
6^{194},\qquad8^{125},\qquad10^4,
\tag{8}
\]

so the result is not a disguised facial-square classification.

## 3. Exhaustiveness inside the frozen scope

For each input graph, the computation reconstructs its planar faces, dual
Eulerian triangulation, legal-wide splits, roots and complete rooted target
families from all NAE colourings modulo global reversal. The resulting
\(541\) fibre count agrees with the independent direct-square profiler.

For each fibre, both surviving-gate sectors and every cross-sector pair are
tested. A site enters (4) exactly when every single-cycle crossing has a
state-\(11\) endpoint. Only then is the child constructed. Its complete
perfect-matching family, fixed rooted fibre, gate sectors, crossing graph,
seven patch cells, 3-connectivity, 2-extendability, strict Hall condition
and legal-wide facial arcs are checked directly.

The complete parameterized verifier and the \(323\) hit records are frozen
in the [supporting bundle](../computations/bundles/rooted-split-bond-through26/README.md).

## 4. Boundary

The exact finite conclusion is

\[
\boxed{
\text{all eligible nonsquare kill-cover hits in the frozen through-26}
\text{ root-square stratum supplement a child crossing}.}
\tag{9}
\]

This is not an arbitrary-order proof of the rooted split-bond lemma. The
parent scope is the named frozen corpus and the direct root-opposite-square
stratum; child orders up to \(30\) occur only through deterministic one-step
tests of those parents. The absence of a finite counterexample is evidence
for the lemma, not a replacement for the labelled rank-transfer implication
of [Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md).
