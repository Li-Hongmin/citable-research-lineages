> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every one-sided left return of the J3,J1,J1 triple has a square signature

[Note 371](371-the-first-left-return-of-a-j3-j1-j1-triple-has-the-exact-square-signature.md)
settles the left-only matching parameter \(\mu=0\) of
[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md).
Every deeper return \(1\le\mu<p\) also has an exact square
signature and a two-way Barnette-class reduction.

Retain the three double blocks \(D_s\), their \(q\ge1\)
short-block right corridor \(S_t\), and Note 344's forced
chords. There is no \(h_1j_3\). Let \(p\ge2\) short blocks
\(T_t=(\bar c_t,\bar r_t,\bar s_t,\bar d_t)\) form the entire
left flank, with no right flank. Take the left-only matching
of Note 344 (7) for \(1\le\mu<p\):
\[
\bar s_{t-1}\bar r_t\ (1\le t\le\mu),\quad
\bar s_\mu j_3,\quad \bar r_{\mu+1}h_1,\quad
\bar s_t\bar r_{t+1}\ (\mu+1\le t<p),\quad
\bar s_po_1,\quad \bar s_0=L.                         \tag{1}
\]
The induced patch \(F_{p,\mu,q}\) consists of the whole left
flank and triple-and-corridor interval. Its degree-two
terminals are \((\bar c_1,\bar r_1,e_3,b_3)\), in cyclic disk
order.

**All-left-return theorem.** For every \(p\ge2\),
\(1\le\mu<p\), and \(q\ge1\), \(F_{p,\mu,q}\) has exactly
the four spanning one-path and two spanning two-path
states of a square at these labeled terminals. Replacing
it by that square, or reversing the replacement, preserves
Barnette membership and every exterior- and attachment-marked
Hamilton decision. It has \(24+4(p+q)\) vertices.
Together with Note 371 this covers every
\(0\le\mu<p\) left-only matching of Note 344 (7), without
conditions on vacancies elsewhere. Old-cycle reflection
gives the corresponding one-sided result for the reflected
\(J_3,J_3,J_1\) triple.

**Three ladder reductions.** The prefix
\(T_1,\ldots,T_\mu\) induces \(L_{2\mu}\), with four
attachments at \(\bar c_1,\bar r_1,\bar d_\mu,\bar s_\mu\):
the exterior old edge, the exterior matching edge,
\(\bar d_\mu\bar c_{\mu+1}\), and \(\bar s_\mu j_3\).
The suffix \(T_{\mu+1},\ldots,T_p\) independently induces
\(L_{2(p-\mu)}\), with attachments at
\(\bar c_{\mu+1},\bar r_{\mu+1},\bar d_p,\bar s_p\):
the preceding old edge, \(\bar r_{\mu+1}h_1\),
\(\bar d_pa_1\), and \(\bar s_po_1\).
The right corridor \(S_1,\ldots,S_q\) is the third disjoint
\(L_{2q}\), as in
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md).
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
replaces each by one square in both directions, preserving
the four labeled attachments, all exterior Hamilton decisions,
and Barnette membership. Each old-cycle route and selected
common-face top rail becomes that of one short block.
It suffices to analyze \((\mu,p,q)=(1,2,1)\).

**The 36-vertex atom.** Denote its two left squares by
\[
T_1=(c_-,r_-,s_-,d_-),\qquad
T_2=(c_0,r_0,s_0,d_0).                                \tag{2}
\]
Their nonstandard matching edges are
\(s_-j_3,r_0h_1,s_0o_1\); their face chords are
\(c_-d_-,c_0d_0\). The terminal labels are
\((c_-,r_-,e_3,b_3)\). For transparent routing formulas,
keep \(U_q\) from Note 370 (7), the full old-cycle
route through the right corridor; the formulas hold at
every \(q\ge1\).

The \(c_-\)--\(b_3\) spanning path is the full old-cycle
path. For \(r_-\)--\(e_3\), concatenate
\[
(r_-,c_-,d_-,s_-,j_3),\quad
B_q:j_3\to h_1,\quad
(h_1,r_0,c_0,d_0,s_0,o_1),\quad
A_q:o_1\to e_3,                                      \tag{3}
\]
where \(A_q,B_q\) are Note 344 (5)'s disjoint
spanning core paths and shared endpoints in (3) are identified.
The other two single paths are
\[
\begin{split}
e_3\to b_3:\quad
&(e_3,j_3,s_-,r_-,c_-,d_-,c_0,d_0,a_1,o_1,
s_0,r_0,h_1,i_1,k_1,i_3,k_3,o_3,h_3,i_2,h_2,\\
&\hspace{24mm}j_1,e_1,b_1,a_2,o_2,k_2,j_2,e_2,b_2,
U_q,a_3,b_3),\\
c_-\to r_-:\quad
&(c_-,d_-,c_0,d_0,a_1,o_1,s_0,r_0,h_1,i_1,
k_1,i_3,k_3,o_3,h_3,i_2,h_2,j_1,e_1,b_1,a_2,\\
&\hspace{24mm}o_2,k_2,j_2,e_2,b_2,U_q,a_3,b_3,
e_3,j_3,s_-,r_-).
\end{split}                                             \tag{4}
\]
Every successive pair is an old-cycle edge, one of the
specified face chords, or a forced matching edge.

For \(\{c_-r_-,e_3b_3\}\), use the edge \(c_-r_-\)
and the \(e_3\)--\(b_3\) path of (4) with the segment
\(s_-,r_-,c_-,d_-\) replaced by its single edge
\(s_-d_-\). For \(\{c_-b_3,r_-e_3\}\), use the
\(c_-\)--\(b_3\) path obtained by dropping the initial
\((e_3,j_3,s_-,r_-)\) from (4), together with
\((r_-,s_-,j_3,e_3)\). Each pair is disjoint and
spans the atom. Bipartite colour excludes the other
two single-path pairs; disk noncrossing excludes the
third two-path pairing. This is the complete square
signature.

**A three-connected cap.** Cap the atom by a square
\((t_B,t_E,t_R,t_C)\), attaching
\(b_3t_B,e_3t_E,r_-t_R,c_-t_C\).
The full old-cycle path from \(c_-\) to \(b_3\), followed
by \(t_B,t_E,t_R,t_C,c_-\), is a Hamilton cycle of the
40-vertex graph. Its complementary matching is
\[
\begin{array}{ll}
\text{one page:}&c_-d_-,\ c_0d_0,\ a_sb_s\ (s=1,2,3),
i_1e_1,\ o_2k_2,\ o_3k_3,\ c_1d_1,\ t_Bt_C;\\
\text{other page:}&s_-j_3,\ r_0h_1,\ s_0o_1,\
j_1h_2,\ k_1i_3,\ i_2h_3,\ j_2s_1,\ e_2r_1,\
r_-t_R,\ e_3t_E.
\end{array}                                              \tag{5}
\]
Each page is noncrossing and every matching edge joins
opposite old-cycle parities. A connected spanning tree
of the matching-chord interlacement graph is
\[
\begin{gathered}
t_Bt_C-r_-t_R-c_-d_--s_-j_3-a_3b_3-i_2h_3
-a_2b_2-j_1h_2-a_1b_1-r_0h_1-c_0d_0,\\
t_Bt_C-e_3t_E,\qquad
a_3b_3-k_1i_3-o_3k_3,\qquad
a_2b_2-j_2s_1-c_1d_1-e_2r_1,\\
j_1h_2-i_1e_1,\qquad j_1h_2-o_2k_2,\qquad
a_1b_1-s_0o_1 .
\end{gathered}                                           \tag{6}
\]
Every dash is endpoint alternation in the displayed
Hamilton order; for example
\(k_1<o_3<i_3<k_3\) checks the longest branch.
A two-edge cut would enclose a proper old-cycle interval
closed under the matching and disconnect (6).
Hamiltonicity excludes bridges. For cubic graphs these
facts imply three-vertex-connectivity. Thus the cap is
Barnette. Expanding the three disjoint ladders by Note 178
gives a Barnette cap for every \(F_{p,\mu,q}\).

The atom minus any one vertex is connected: its
old-cycle path has every internal position bridged by
one of \(c_-d_-,s_-j_3,a_3b_3\) not incident with
that vertex. This one-deletion property survives each
ladder expansion. A ladder minus one vertex is
connected; if the deletion is outside it, the connected
old patch and connected replacement have the same
four attachments; if it is inside, compare with deleting
the corresponding old terminal, or no old vertex when
the deleted ladder vertex is internal. The surviving
attachments join every exterior component. After any
two patch vertices are deleted, every surviving
component meets a surviving terminal, or it would
disconnect the corresponding three-connected cap.
The square has both deletion properties. The
four-attachment comparison in Note 370 therefore gives
three-connectivity in either replacement direction.
Terminal colours and disk order preserve bipartiteness
and planarity; the six routing states preserve all
exterior Hamilton decisions. \(\square\)

The square is one short target-free block in the
selected opening, with old-cycle segment
\((\bar c_1,\bar r_1,e_3,b_3)\) and common-face chord
\(\bar c_1b_3\). Arbitrary simultaneous left and right
flanks, and the right-only matching of the unreflected
\(J_3,J_1,J_1\) order, remain separate states. Other
vacancy types and the general Barnette conjecture are
unresolved. This is a project-internal analytic proof
without independent review or external priority claim.
