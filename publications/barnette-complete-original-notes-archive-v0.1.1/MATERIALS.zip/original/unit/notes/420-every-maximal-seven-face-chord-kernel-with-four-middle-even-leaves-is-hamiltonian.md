> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every maximal chorded seven-face-chord kernel with four middle even leaves is Hamiltonian

In the chorded single-hexagon normal form of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md), let \(f=7\) and let the doubly reduced ordinary forest attain \(c=32\). [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md) proves that exactly four leaves have even depth. This note settles the entire case where all four lie strictly between the two site leaves.

**Four-middle-leaf theorem.** Every legal Barnette-class \(C_4\)-expansion in the preceding setting is Hamiltonian if its four even-depth leaves lie strictly between the site leaves. In particular, any non-Hamiltonian chorded \(f=7,c=32\) reduced child must have the even-depth leaves distributed as \((4,0,0)\) with all four on an outer side, or as a permutation of \((2,2,0)\). This theorem is independent of the order of the unreduced graph: both ladder reductions of Note 410 preserve the child's Hamilton decision.

**Proof.** By reflecting the old-cycle order if necessary, the site leaves are \(j=2,k=7\), the third odd-depth leaf is 1, and the even-depth leaves are 3,4,5,6. A sibling pair joined by one face chord with its other special terminals attached outside compresses by [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md), after which [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) proves the child Hamiltonian. A sibling pair with both special cross-chords internal has a forbidden two-edge cut, as explained in Note 419. Otherwise Note 419's two-tree corollary leaves exactly two ordinary words with the same face matching. The word of [Note 418](418-the-ninety-four-vertex-seven-face-chord-kernel-is-realizable-and-hamiltonian.md) has the required Hamilton cycle. It remains to handle the other word. Write
\[
U_i=((x_i y_i)),\qquad F(P,Q)=(((P Q))),
\]
\[
\begin{aligned}
A&=F(U_3,U_4),&B&=F(U_2,A),&C'&=F(B,U_5),\\
D&=F(U_1,C'),&E&=F(D,U_6),&W&=F(E,U_7).
\end{aligned}                                                     \tag{1}
\]
The old cycle and complementary matching are exactly (2)--(3) of Note 418 with this new word \(W\):
\[
C=(w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,w_0),
\]
\[
\begin{split}
q&=w_0y_2,\quad p=x_7w_*;\\
M_{\rm face}&=\{z_Lx_1,y_1x_2,x_3y_6,y_3x_6,x_4y_5,y_4x_5,y_7z_R\};\\
M_{\rm escape/hex}&=\{t_cc,t_bb,\alpha\beta,ad\}.
\end{split}                                                       \tag{2}
\]
Parenthesis pairs supply the other 32 matching edges. The following construction uses only edges in (1)--(2) and old-cycle edges; no classification of the graph's other Hamilton cycles is needed.

For each leaf \(U_i\), write its six vertices in old-cycle order as \(L_i,h_i,x_i,y_i,j_i,R_i\). Use the spanning leaf paths
\[
Y_i=(y_i,x_i,h_i,j_i,R_i,L_i),\quad
X_i=(R_i,L_i,h_i,j_i,y_i,x_i),\quad
O_i=(L_i,h_i,x_i,y_i,j_i,R_i).                              \tag{3}
\]
For \(U_4\), another spanning path is
\[
Z_4=(x_4,h_4,L_4,R_4,j_4,y_4).                              \tag{4}
\]
Split \(U_5\) into two disjoint paths \((R_5,j_5,y_5)\) and \((x_5,h_5,L_5)\); together they contain all six vertices. In any occurrence of \(F(P,Q)\), denote its left brackets by \(\lambda_0,\lambda_1,\lambda_2\), its right brackets in old-cycle order by \(\rho_2,\rho_1,\rho_0\), and its first/last vertices by subscripts \(\ell,r\). Superscripts identify the occurrence. The six-bracket paths
\[
T^-=(\rho_0,\lambda_0,\lambda_1,\rho_1,\rho_2,\lambda_2),
\quad T^+=(\rho_2,\lambda_2,\lambda_1,\rho_1,\rho_0,\lambda_0)
                                                                    \tag{5}
\]
use only old-cycle edges and bracket chords, as checked in Note 418.

First split \(C'=F(B,U_5)\) into two disjoint covering paths. The first runs from \(y_2\) to \(C'_\ell\):
\[
P_1:\quad y_2\xrightarrow{Y_2}L_2,
\lambda_2^B,\lambda_1^B,B_\ell,
\lambda_2^{C'},\lambda_1^{C'},C'_\ell.                    \tag{6}
\]
The second runs from \(C'_r\) to \(y_3\):
\[
\begin{aligned}
P_2:quad C'_r,\rho_1^{C'},\rho_2^{C'},R_5,j_5,y_5,
x_4\xrightarrow{Z_4}y_4,
x_5,h_5,L_5,B_r,\rho_1^B,\rho_2^B,
A_r\xrightarrow{T^-_A}\lambda_2^A,
L_3\xrightarrow{Y_3^{-1}}y_3.                              \tag{7}
\end{aligned}
\]
The junctions \(y_5x_4\) and \(y_4x_5\) are face chords in (2); the others between blocks are old-cycle edges. In (6), the \(U_2\) path and the left brackets of \(B,C'\) are used. In (7), the two \(U_5\) paths, all of \(U_4\), the right brackets of \(C',B\), and all of \(A\) are used. Thus \(P_1,P_2\) are vertex-disjoint and together cover \(C'\) exactly once.

The old-cycle edge \(C'_\ell R_1\), the reversed leaf path \(O_1^{-1}:R_1\to L_1\), and the brackets of \(D=F(U_1,C')\) join these paths. Explicitly,
\[
\begin{aligned}
P_D:quad y_2\xrightarrow{P_1}C'_\ell,
R_1\xrightarrow{O_1^{-1}}L_1,
\lambda_2^D,\lambda_1^D,D_\ell,D_r,
\rho_1^D,\rho_2^D,C'_r\xrightarrow{P_2}y_3.
\end{aligned}                                                     \tag{8}
\]
Here \(D_\ell D_r=\lambda_0^D\rho_0^D\) is the outer bracket chord. Formula (8) is a spanning \(y_2\)--\(y_3\) path of \(D\): (6)--(7) cover \(C'\), and the additional terms cover \(U_1\) and all six \(D\)-brackets.

Now use the face chord \(y_3x_6\), traverse \(U_6\) backwards along \(X_6\), and traverse all six \(E\)-brackets by \(T^+\). This yields a spanning path of \(E=F(D,U_6)\) from \(y_2\) to \(E_\ell\):
\[
P_E:quad y_2\xrightarrow{P_D}y_3,
x_6\xrightarrow{X_6^{-1}}R_6,
\rho_2^E\xrightarrow{T^+_E}E_\ell.                         \tag{9}
\]
Finally, the outer bracket chord \(W_\ell W_r\) and \(U_7\) close the word into a spanning \(y_2\)--\(x_7\) path:
\[
P_W:quad y_2\xrightarrow{P_E}E_\ell,
\lambda_2^W,\lambda_1^W,W_\ell,W_r,
\rho_1^W,\rho_2^W,R_7\xrightarrow{X_7}x_7.               \tag{10}
\]
At every stage the previous path's vertex set is disjoint from the newly traversed leaf and brackets. Equation (10) therefore visits all \(78\) vertices of \(W\) exactly once. The other twelve vertices give the Hamilton cycle
\[
w_0\xrightarrow{q}y_2\xrightarrow{P_W}x_7
\xrightarrow{p}w_*,z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0. \tag{11}
\]
All steps outside \(W\) are old-cycle edges or the listed matching edges \(q,p,t_bb,\alpha\beta,t_cc\). This cycle contains both site edges. By the direct-lift clause of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), replacing those edges by the two paths through the new square gives a Hamilton cycle of the expanded child. This closes the last nonserial four-middle-leaf word and proves the theorem. \(\square\)
