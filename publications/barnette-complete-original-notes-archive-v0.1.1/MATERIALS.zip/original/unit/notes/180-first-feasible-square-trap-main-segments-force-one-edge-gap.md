> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# First feasible square-trap main segments force a one-edge gap

[Note 179](179-saturated-square-trap-main-segments-create-two-edge-cuts.md)
shows that an all-square-trap facial opening in a Barnette graph
with \(\ell\) escape lobes has at least \(2\ell+6\) old vertices
in its main \(C\)-segment. At equality, the remaining matching
edge and the opposite-side chord order force the *other*
facial gap between the site edges to have length one.

Use the legal Barnette expansion \(G\to G^+\), the Hamilton
parent cycle \(C\), and the literal facial opening \(F_P\) of
Notes 176--179. Assume every trapped segment is a square.
Compress each lobe ladder in parent and child as in Note 178,
so the residual squares are
\(S_i=\alpha_i a_i b_i\beta_i\alpha_i\),
\(1\le i\le\ell\), with escape edges
\(a_i t_i^L,b_i t_i^R\). Let \(S_0\) be the old-vertex
main segment, oriented from \(x\) to \(v\).

**Theorem.** If
\[
|V(S_0)|=2\ell+6,
\tag{1}
\]
then the expanded Barnette graph \(G^+\) has a Hamilton
cycle. More precisely, in the reduced parent there is exactly
one residual square \(S_i\) whose two escape endpoints are
not adjacent on \(S_0\). Around that square the \(S_0\)-order
is six consecutive vertices
\[
R=t_i^R,\quad s,\quad y,\quad u,\quad t,\quad
L=t_i^L,
\qquad st\in M,
\tag{2}
\]
and every other escape pair is adjacent. Here \(M\) is the
parent matching complementary to \(C\). In particular,
\(yu\in C\) is the one-edge complementary facial gap.

**Proof of the forced pattern.** By (1), the \(S_0\)-vertices
consist of the four site ports, the \(2\ell\) distinct escape
targets, and two further vertices \(s,t\). The latter must
be matched to each other in \(M\). In the order from \(x\),
the site ports \(y,u\) have odd and even indices respectively;
the targets occur in reverse lobe order as consecutive
\(R,L\) pairs in the target subsequence, with \(R\) at odd
index and \(L\) at even index, by Note 179. The two extra
vertices have opposite index parity.

The \(C\)-edges immediately after \(y\) and before \(u\)
both start at odd-index vertices. Note 179's even-cut
bridge lemma says that an edge of this kind without a
straddling escape pair needs at least two internal
\(S_0\) matching chords across it. There is only the
single edge \(st\), so both \(C\)-edges are straddled
by escape pairs.

Call these pairs \(A\) and \(B\), respectively. No escape
target lies strictly between the \(R\) and \(L\) targets of
a single pair. Since \(A\) straddles the edge after \(y\),
the only possible non-target even-index vertex immediately
before \(y\) is one endpoint of \(st\); call it \(s\).
There is no second extra even-index vertex, and \(u\) comes
after \(y\). The preceding odd vertex must therefore be
\(t_A^R\); any earlier position for it would require another
even non-target vertex. Hence the local order is
\(t_A^R,s,y\) with consecutive vertices. Symmetrically,
pair \(B\) gives the consecutive order \(u,t,t_B^L\),
where \(t\) is the odd-index endpoint of \(st\).

The edge \(st\) cannot lie on the common-face side of \(C\):
its endpoints interlace those of the site chord \(q=xy\)
in the order \(x,s,y,t\). Thus it lies on the opposite side,
with all escape chords. If \(A\ne B\), the target of \(A\)
at \(t_A^L\) lies strictly between \(s\) and \(t\): the
disjoint pair intervals in (2) place all of \(A\) before
\(B\), whose first target precedes \(u\).
The chord \(st\) then interlaces the escape chord from the
earlier source \(a_A\) to \(t_A^L\), which is impossible
in a plane drawing. Therefore \(A=B=i\). No escape target
can lie between \(t_i^R,t_i^L\), and both extra vertices
are already the neighbours \(s,t\) just found. Hence
\(y,u\) are adjacent, giving precisely (2). All other
interior positions of \(S_0\) are escape targets in their
alternating parity order, so every other \(R,L\) pair is
adjacent. \(\square\)

**Hamilton corollary.** Name the new patch vertices
\(A,B,C,D\), with edges
\(uA,AB,Bv,xC,CD,Dy,AD,BC\). In the initial child
2-factor \(C\dot\cup(ABCD)\), the square
\[
y,u,A,D,y
\tag{3}
\]
has the two factor edges \(yu,AD\) in distinct components
and the two unused spokes \(uA,Dy\). Its flip joins those
components into one Hamilton cycle. This is exactly the
one-edge-gap mechanism of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md);
the new result here is that condition (1) forces this gap.
\(\square\)

**Long-gap corollary.** If both residual facial arcs between
the site edges have length at least three, then every
all-square-trap opening has
\[
|V(S_0)|\ge2\ell+8.
\tag{4}
\]
Indeed, Note 179 excludes \(2\ell+4\), the theorem above
excludes \(2\ell+6\) under the long-gap condition, and
\(|V(S_0)|\) is even. \(\square\)

The forced pattern holds for every number and length of
square-trap lobes at the first main-segment size compatible
with 3-edge-connectivity. It does not assert that equality
is realized for each \(\ell\). Longer main segments may
contain additional matching chords, and nonsquare traps
require different arguments.
