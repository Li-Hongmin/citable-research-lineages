> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A standard-link sweep settles one one-sided target vacancy

[Note 231](231-dispersed-target-runs-between-same-block-vacancies-are-hamiltonian.md)
uses a same-square sweep when every ordinary free link is present.
Its displayed paths do not use the number of vacant pairs: each
interval between consecutive escape targets is traversed in old-cycle
order, with a retained ordinary link across every face-block boundary.
This observation closes the port-free terminal case of
[Note 320](320-one-sided-target-bearing-vacancy-reduces-to-one-terminal-component.md).

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent with \(\ell,r\ge1\). In each main face block \(B_i\),
write \(o_i\) for its first free odd interior slot and \(e_i\) for
its final free even interior slot; write \(e_0,o_{r+1}\) for the
site-block boundary slots. Vacancies may occur among the other
interior slots, subject only to the stated tight opening.

**Standard-link sweep lemma.** If every ordinary free link
\[
                         e_i o_{i+1},\qquad 0\le i\le r,
                                                               \tag{1}
\]
belongs to the complementary matching, then the parent has a
Hamilton cycle through both site edges, regardless of the number,
placement, or internal matching of its vacancies. Its legal
site-expanded child is Hamiltonian.

**Proof.** Use the two spanning paths (4)--(6) of Note 231.
The first is the exposed face-chord path
\[
             x,y,a_1,b_1,\ldots,a_r,b_r,u,v.             \tag{2}
\]
For each residual square \(S_j\), the other path reaches its
target \(R_j\), follows a path \(T_j\) to \(L_j\), then traverses
the same square as in Note 231. Construct \(T_j\) through every
free main vertex strictly between the consecutive targets
\(R_j,L_j\) in old-cycle order. Within a block, all such vertices
are consecutive and their joining edges lie on the old cycle,
whether they are ordinary slots or vacant pairs. At a face-block
boundary, the two face-chord endpoints belong to (2), and the
available link (1) joins the free slots immediately before and
after them. Tight target order places no occupied target in the
interior of \(T_j\); gaplessness supplies no other boundary
vertices. Thus every \(T_j\) is a path, the \(T_j\)'s are
internally disjoint, and together they cover every free main
vertex. Note 231's square transitions join them into a second
\(x\)--\(v\) path disjoint from (2) internally. The two paths
cover every vertex and use both site edges. No vacancy-to-vacancy
or vacancy-to-ordinary matching edge is needed in this route.
Notes 001 and 178 lift to the legal child and original lobe
lengths. \(\square\)

**One-sided target-vacancy theorem.** Assume every eligible
vacancy lies in a distinct block. Exactly one vacant block is
target-bearing, and its vacancy \(T=(h_k,i_k)\) is the first
eligible position before a nonempty occupied target run in the
internal block \(B_k\). Every other vacancy lies in a target-free
internal block. Then the parent has a Hamilton cycle through both
site edges and its legal site-expanded child is Hamiltonian.
The reflection with \(T\) last after a nonempty run also holds.
There is no bound on the number of target-free vacancies or missing
ordinary links.

**Proof.** Occupied target runs are free-matching barriers by
Note 215: every earlier vacancy adds two free slots to its even
prefix, cross-block chords cannot straddle an escape target, and
at most one same-block free chord could cross each run. In every
free-slot group other than the one ending at \(T\), all vacancies
belong to distinct complete target-free blocks. The ordinary-chord
and port-separation arguments of Notes 276, 278 apply with the
group's two ordinary boundary slots: any skipped complete block
interval would be a two-edge cut. Select a minimum-span port
component in such a group. Its gap to a neighboring owned
vacancy contains no other port; Note 317 compresses the closed
intervening target-free interval, and Note 315 folds the adjacent
vacancy. The patch is internal to complete target-free blocks,
even if the port is next to a group's boundary slot. Repeat
until every such group has all its ordinary links retained.

Apply Note 320 to the group ending at \(T\). Its reductions
likewise leave the target-bearing block and all occupied runs
untouched. If the terminal component is port-free, it leaves
no missing ordinary link. All links (1) are now present across
the opening, so the standard-link sweep lemma gives the marked
Hamilton parent cycle.

Otherwise Note 320 leaves exactly \(\{P_s,T\}\) in that group,
with matching edges \(e_si_k,o_{s+1}h_k\), and no other port
anywhere. Every other vacancy component is port-free and stays
inside a complete target-free block interval: the target barriers
keep it in one group, and noncrossing keeps it out of the gap
across \(P_s\). Compress maximal such closed intervals by
Note 317. This removes every vacancy except \(T\), preserves
Barnette membership and the marked opening, and leaves precisely
the matching pattern of Note 208's one-sided first-surplus
theorem. With exactly one eligible vacancy, the tight slot count is
\(f=4r+4\) in the reduced opening, so that theorem's surplus
hypothesis also holds. It gives a Hamilton parent cycle through both
site edges. Reverse all Note 317 compressions and Note 315 folds;
their full four-terminal signatures transfer the marked cycle
without altering the site edges. Notes 001 and 182 give the
legal child and uncompressed lobes. Reflection proves the other
one-sided placement. \(\square\)

The sweep lemma itself allows arbitrary vacancy placements when
all ordinary links are present. The second theorem needs the
distinct-block, unique target-bearing and one-sided conditions
only to eliminate missing links. Multiple target-bearing vacancies,
same-block repetitions, positive gaps, defective target order and
nonsquare residual cycles remain outside this proof. Neither
statement decides the general Barnette conjecture; no external
priority claim is made.
