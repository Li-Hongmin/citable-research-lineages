> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-feasible cycle cubes are not delta-matroids

[Note 081](081-target-preserving-exchange-is-a-two-rooted-orbit-and-single-cycle-components-can-be-closed.md)
gives the exact endpoint-orbit criterion for a union of alternating cycles
to carry one rooted target to another.  A natural next attempt is to fix a
second perfect matching, regard the alternating components of the symmetric
difference as Boolean coordinates, and use delta-matroid exchange or a
minimum-component choice to force a gate-removing feasible subset.

Both steps fail sharply.  The target-feasible subsets need not form a
delta-matroid, already with three coordinates in a simple cubic bipartite
common-incidence model.  More decisively, if the second matching is chosen
to minimize the number of alternating components, then a gate-containing
coordinate is nonloop exactly when the second matching is already a rooted
target.  The proposed selection theorem therefore becomes equivalent to
the neutral-target conclusion it was meant to prove.  The cube gives a
plane-brace counterexample at the absolute minimum \((1,1)\), and the whole
minimum two-\(C_4\) repair class exhibits the same failure.

## 1. The target-feasible component cube

Let \(G\) be cubic, let \(M\) be a rooted target with root \(e=rs\in M\),
and let \(N\) be a perfect matching sharing \(e\).  Decompose

\[
M\mathbin\triangle N
=A_1\mathbin{\dot\cup}\cdots\mathbin{\dot\cup}A_k
\tag{1}
\]

into its vertex-disjoint alternating cycles.  For \(S\subseteq[k]\), put

\[
M_S=M\mathbin\triangle\bigcup_{i\in S}E(A_i)
\tag{2}
\]

and define

\[
\mathcal F(M,N)=
\{S\subseteq[k]:M_S\text{ is a rooted target}\}.
\tag{3}
\]

The empty set belongs to \(\mathcal F(M,N)\).  By Note 081, membership of a
general \(S\) requires both

\[
u(S)+\frac12\operatorname{cyc}(p_St_S)=2
\tag{4}
\]

and separation of the two root labels in the corresponding
\(p_S\cup t_S\) endpoint graph.  Neither clause is coordinatewise.

## 2. Symmetric exchange fails at three coordinates

There is a simple cubic bipartite common-incidence realization on vertices
\(\{0,\ldots,17\}\).  Its initial complement consists of

\[
\begin{aligned}
C_0&=(0,1,6,7,2,3,4,5),\\
C_1&=(8,9,16,17,10,11,12,13,14,15),
\end{aligned}
\tag{5}
\]

and

\[
\begin{aligned}
M=\{&6\,16,7\,17,0\,3,1\,2,9\,12,8\,13,\\
    &4\,10,11\,14,5\,15\}.
\end{aligned}
\tag{6}
\]

Take root \(e=6\,16\) and the three disjoint \(M\)-alternating cycles

\[
\begin{aligned}
A_1&=(0,1,2,3),\\
A_2&=(8,9,12,13),\\
A_3&=(4,5,15,14,11,10).
\end{aligned}
\tag{7}
\]

For the eight masks in binary order, the complement-component counts and
root-separation flags are

\[
\begin{array}{c|cccccccc}
S&000&001&010&011&100&101&110&111\\ \hline
\#\operatorname{comp}(G-M_S)&2&3&3&4&2&3&1&2\\
r,s\text{ separated}&1&1&1&1&0&1&0&1.
\end{array}
\tag{8}
\]

Consequently

\[
\boxed{\mathcal F(M,N)=\{\varnothing,\{1,2,3\}\}.}
\tag{9}
\]

Take \(X=\varnothing\), \(Y=\{1,2,3\}\) and \(a=1\).  For every
\(b\in X\mathbin\triangle Y\), the set
\(X\mathbin\triangle\{a,b\}\) is infeasible.  Thus the symmetric-exchange
axiom fails.  The two feasible sets also have opposite parity, so this is
neither an even nor a ribbon-graphic delta-matroid.

Three coordinates are sharp for this abstract obstruction.  Every nonempty
set system containing \(\varnothing\) on at most two coordinates satisfies
symmetric exchange.  No minimum vertex-order claim is needed.

The table also separates the two clauses of Note 081: mask \(100\) has
exactly two complement components, but both root labels lie in the same
component.

## 3. Minimum alternating support makes the argument circular

Now fix a gate edge \(g\in M\setminus N\), and let \(A_g\) be its unique
component in (1).  Choose \(N\), among all perfect matchings sharing \(e\)
and excluding \(g\), to minimize lexicographically

\[
\left(
\#\operatorname{comp}(M\mathbin\triangle N),
\#\operatorname{comp}(G-N)
\right).
\tag{10}
\]

Suppose \(S\in\mathcal F(M,N)\) contains \(A_g\).  Then \(M_S\) shares the
root, excludes \(g\), and \(M\mathbin\triangle M_S\) has exactly \(|S|\)
alternating components.  Minimality of the first coordinate in (10) gives
\(|S|\ge k\).  Since \(S\subseteq[k]\), necessarily \(S=[k]\).  Hence

\[
\boxed{
A_g\text{ is not a loop of }\mathcal F(M,N)
\iff [k]\in\mathcal F(M,N)
\iff N\text{ is itself a rooted target}.}
\tag{11}
\]

The second coordinate in (10) cannot repair this circularity.  It favours
fewer complement cycles, whereas a rooted target needs exactly two and must
also separate the root labels.

The failure already occurs in the plane brace \(Q_3=C_4\square K_2\).
Let \(M\) be its four rungs, let the root \(e\) and gate \(g\) be opposite
rungs, and toggle a side face through \(g\) that avoids \(e\).  The resulting
matching \(N\) shares \(e\), excludes \(g\), and satisfies

\[
\#\operatorname{comp}(M\mathbin\triangle N)=1,\qquad
\#\operatorname{comp}(G-N)=1.
\tag{12}
\]

This is the absolute minimum possible for both coordinates.  But \(G-N\)
is Hamiltonian, not a rooted two-cycle complement, and therefore

\[
\mathcal F(M,N)=\{\varnothing\}.
\tag{13}
\]

Thus the gate coordinate is a loop even in a plane brace.  The
[permanent verifier](../computations/bundles/target-feasible-cycle-cube-countermodels/README.md)
checks the \(18\)-vertex table, the cube calculation and the cube's complete
\(2\)-extendability.

## 4. The complete minimum-repair class has the same obstruction

The \(32\) repaired braces of
[Note 080](080-minimum-brace-repairs-supplement-rather-than-repair-the-bad-target-cube.md)
contain \(612\) rooted targets, of which \(180\) use both fixed gates.
For every double-gate source \(M\), specified gate \(g\), and perfect
matching \(N\) sharing the root and excluding \(g\), test every component
subset in (1) that contains \(A_g\).  Across the \(360\) source-gate pairs
there are \(23{,}104\) triples:

\[
\begin{array}{c|rr}
&\text{some target-feasible subset}&\text{no target-feasible subset}\\ \hline
\text{all triples}&6{,}813&16{,}291.
\end{array}
\tag{14}
\]

For every one of the \(360\) source-gate pairs, the lexicographic minimum
in (10) is \((1,1)\).  There are \(1{,}693\) tied minimizers, and all fail:

\[
\begin{array}{c|rr}
&\text{success}&\text{failure}\\ \hline
\text{lexicographic minimizers}&0&1{,}693.
\end{array}
\tag{15}
\]

Here the mechanism is uniform.  Since \(M\mathbin\triangle N\) has one
component, the only allowed subset is the full toggle.  Since \(G-N\) is
Hamiltonian, it is not a target.

The smallest complete target families have \(11\) members; sequence \(350\)
from Note 080 is the first example.  It has \(322\) perfect matchings and
contains a double-gate target \(M\) and gate-free root-sharing matching
\(N\) whose symmetric difference is the alternating \(12\)-cycle

\[
2-12-4-16-8-19-26-27-24-21-5-13-2,
\tag{16}
\]

while \(G-N=C_{28}\).

The [bundle](../computations/bundles/target-feasible-cycle-cube-countermodels/README.md)
reconstructs the fixed \(868\)-sequence class from the Note 080 bundle and
checks every triple and subset.  It is not a census of all order-\(28\)
braces.

## 5. Exact boundary

For a fixed source-gate pair \((M,g)\), weaken the selection statement to
the existence of some root-sharing gate-excluding \(N\) and some feasible
subset containing \(A_g\).  This is equivalent to saying that the complete
rooted target family already contains a target excluding \(g\): a successful
toggle is such a target, and conversely one may choose that target as \(N\)
and toggle all components.  The existential weakening therefore adds no
exchange content.

The cycle-cube route is now closed at three levels:

1. target-feasible subsets have no general delta-matroid exchange law;
2. brace \(2\)-extendability does not prevent a gate coordinate from being
   a loop; and
3. lexicographic minimization makes gate nonloopness equivalent to the
   desired target conclusion.

**Exact conclusion.**  Component-subset exchange and minimum-support
selection do not prove neutral-target supplementation.  The load-bearing
condition remains the full two-rooted orbit of Note 081, which is not
controlled by ordinary delta-matroid axioms or brace extendability.

**Evidence level.**  The failure of symmetric exchange and equivalence
(11) are arbitrary-order analytic results with finite certificates.  The
cube is a real plane-brace counterexample to the lexicographic selection
principle.  Equations (14)--(16) are an exact classification of the fixed
minimum-repair class.

**Unresolved boundary.**  The wide complete-family neutral-target statement
remains open.  Any proof must select a target directly from common
perfect-matching incidence; choosing an arbitrary or lexicographically
minimal gate-deleting matching, then searching its component cube, cannot
supply new information.
