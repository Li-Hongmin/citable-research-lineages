> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disconnected three-root two-split failures must put both nodes in the site root

[Notes 484–485](485-two-adjacent-unary-pairs-close-three-root-chord-free-equality.md) reduce the three-root chord-free equality profile of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md) to two marked unary nodes whose direct special positions both straddle their respective child words. The disconnected root face graph has a further placement restriction.

Use the three-root order and notation of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Let \(K\) join distinct ordinary roots by their face matching chords. Every assigned special position outside the two direct split pairs belongs to a two-special leaf.

**Distinct-root theorem.** If the two split marked unary nodes lie in different roots and \(K\) is disconnected, the parent has a Hamilton cycle containing both site edges; hence its legal expanded child is Hamiltonian. Consequently a non-Hamiltonian child in this profile with disconnected \(K\) must put both split nodes in the same isolated end root that contains the two site ports.

**Proof.** The even-order root cuts, three-connectivity, and noncrossing argument in Note 456 show that a disconnected \(K\) has one isolated root \(W\), necessarily \(W_1\) or \(W_3\), containing both site ports \(u,v\). Every other assigned special position in \(W\) has its face matching mate inside \(W\). Since the two split nodes lie in different roots, \(W\) contains at most one of them.

If \(W\) contains none, all its assigned positions occur in two-special leaves. The two-terminal square-switch theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) gives a spanning \(u\)--\(v\) path in the old \(W\)-arc closed by its root chord. If \(W\) contains one split node, the root-chord path lemma of [Note 481](481-disconnected-two-root-split-unary-openings-are-hamiltonian.md) gives the same path: its proof uses only one split node, two external terminals, internal face matching at all other special positions, and three-connectivity. The other split node lies outside \(W\) and is irrelevant to this internal path.

The explicit exterior path (4) or (5) of Note 456 spans every vertex outside \(W\) from \(w_0\) to \(w_*\). Joining it to the internal path with \(q=w_0u\) and \(p=vw_*\) gives the marked parent Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

This theorem leaves connected-\(K\) arrangements and the disconnected-\(K\) placement with both split nodes in the isolated site root.
