> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every rooted path with a size-two centre is safe

[Note 039](039-a-balanced-remote-centre-between-two-c-singletons-is-safe.md)
proves a residual-three-cut zero lemma and applies it to the first
size-two-centre profile left open by Notes 035--038.  This note combines
that lemma with the facial transitions at shared root neighbours and
settles every rooted path whose centre root class has size two.

Use the setting of Notes 035--039.  Thus \(F\) is a simple plane cubic
bipartite brace, \(p=uv\) and \(h=z\alpha\) are an ordered legal
cofacial site with \(u,z\) in the same bipartition class, and

\[
 K=F-\{u,\alpha\}.
\]

In \(F^*\), write \(p^*=cc_p\), \(h^*=cc_h\), and let

\[
 W=\{r,s,t,q\},\qquad F^*[\{s,t,q\}]=s-t-q.       \tag{1}
\]

Assume that the centre class has size two.  Hence

\[
 A(t)\in
 \left\{
 V=\{c,c_p\},\quad
 Z=\{c,c_h\},\quad
 R=\{c_p,c_h\}
 \right\}.                                       \tag{2}
\]

The \(V,Z\) classes are exact-one.  The remote class \(R\) is either
exact-one or balanced zero/two.

> **Size-two-centre path theorem.**  For every legal choice of endpoint
> root classes \(A(s),A(q)\), there is a perfect matching \(M\) of \(K\)
> such that
> \[
>  |M\cap E_Q(W)|\le3.                            \tag{3}
> \]

## Shared-root transitions

Write the two centre roots as \(d_1,d_2\), with retained primal labels
\(a_1,a_2\).  Suppose an endpoint \(x\in\{s,q\}\), joined to \(t\) by
a rung with label \(g\), has a retained root label \(f_i\) at the shared
root \(d_i\).  The triangle \(d_ixt\) is facial, so every perfect
matching satisfies

\[
 a_i+f_i+g=1.                                    \tag{4}
\]

For an exact-one centre, \(a_1+a_2=1\).  If an endpoint meets the centre
only at \(d_i\), its root-class-plus-rung contribution is

\[
\begin{array}{c|cc}
\text{endpoint type}&a_i=1&a_i=0\\ \hline
\text{singleton }S_i&0&1\\
\text{exact-one pair }E_i&1&\le2\\
\text{balanced pair }B_i&0&\le2.
\end{array}                                      \tag{5}
\]

An exact-one endpoint using both centre roots has rung zero and
endpoint contribution one.  A balanced endpoint on the same two roots
is incompatible with an exact-one centre, because the two equations
(4) would force \(a_1=a_2\).  The same observation excludes a
\(T=\{c,c_p,c_h\}\) endpoint adjacent to an exact-one remote centre.

For a balanced remote centre, put \(a_1=a_2=\sigma\).  In a centre-one
matching, the possible shared endpoint contributions are

\[
\begin{array}{c|c}
\text{endpoint type}&\text{endpoint-plus-rung cost}\\ \hline
\text{singleton}&0\\
\text{local exact-one pair }V\text{ or }Z&1\\
\text{balanced remote pair }R&0\\
T&1.
\end{array}                                      \tag{6}
\]

In a centre-zero matching every type in (6) contributes at most two.
For a \(T\)-endpoint, if \(\tau\) is its remote-pair state, the two
facial equations give

\[
 \sigma+\tau+g=1,
\]

and its total endpoint-plus-rung contribution is \(1+\tau+g\), equal to
two when \(\sigma=0\) and one when \(\sigma=1\).

## Exact-one centres

Let \(d_0\) be the root not in \(A(t)\).  A singleton endpoint attached
at \(d_0\) will be called a **complement singleton**.

### No complement singleton

Suppose first that both endpoints share a centre root.  An endpoint
using both roots contributes one.  Choosing a centre label favourable
to the other endpoint and applying (5) gives total cost at most three.
If both endpoints use both roots, the total is exactly

\[
 1\text{ (centre)}+1+1=3.
\]

It remains that each endpoint meets exactly one centre root.  If both
meet the same root \(d_i\), extend \(a_i\) to a perfect matching.  Each
endpoint then contributes at most one by (5).

If the endpoints meet opposite roots, their types lie among \(S,E,B\).
The six unordered combinations are bounded as follows:

\[
\begin{array}{c|l}
S,S&\text{select either centre root: endpoint costs }0+1\\
S,E&\text{select the root shared with }E: 1+1\\
S,B&\text{select the root shared with }B: 1+0\\
E,E&\text{use one shared endpoint label: endpoint costs }1+1\\
E,B&\text{select the root shared with }B: \le2+0\\
B,B&\text{select either shared root: }\le2+0.
\end{array}                                      \tag{7}
\]

For the \(E,E\) row, extend one shared endpoint label.  Its facial
equation forces the corresponding centre label and rung to be absent.
The opposite centre label is therefore present, and the other endpoint
contributes one.  Thus every row of (7), after adding the centre cost
one, is at most three.

### One complement singleton

Let \(r_0,x_0\) be the label and rung of the complement endpoint.  For
every centre root \(d_i\) adjacent to \(d_0\) in

\[
 c_p-c-c_h,                                      \tag{8}
\]

the short dual cycle through the endpoint--centre path gives a residual
three-cut

\[
 C_i=\{r_0,x_0,a_i\},                            \tag{9}
\]

and restoring the corresponding deleted root edge gives a four-edge cut
of \(F\).

If one available \(C_i\) has even shore, the residual-three-cut zero
lemma of Note 039 supplies a perfect matching with
\(r_0=x_0=a_i=0\).  The other centre label is one, and (5) bounds the
shared endpoint contribution by two.

Assume every available short cut is odd.  Choose an available centre
root whose centre label is zero.  Odd cut parity gives
\(r_0+x_0=1\).  For a local centre, the only apparent exception is that
the other endpoint is the local exact-one pair meeting the centre at the
same zero-labelled root.  Extend its shared label.  Equation (4) again
forces the centre label and its rung to zero; the local pair contributes
one, while odd parity still gives \(r_0+x_0=1\).  The total is three.

For an exact-one remote centre, both centre roots are adjacent to the
complement root \(c\).  Choose the short root not used as the sole shared
root of the other endpoint.  A \(T\)-endpoint is incompatible with this
centre by the two shared-root equations.  Hence all one-complement
profiles are safe.

### Two complement singletons

Choose a centre root adjacent to \(d_0\) and use its short residual cut
for both endpoints.  If either cut is even, its zero matching has centre
cost one, zero cost on that endpoint, and cost at most two on the other.

If both cuts are odd, choose the centre state in which their common
centre label is zero.  Each singleton-plus-rung pair then contributes
exactly one, so the total is

\[
 1+1+1=3.
\]

This completes the exact-one \(V,Z,R\) centres.

## Balanced remote centre

Now \(A(t)=R\) and \(a_1=a_2=\sigma\).

### No complement singleton

Take a centre-one matching.  By (6), its total cost is at most three
unless both endpoints are local exact-one pairs.  The only exceptional
profile consists of one \(V\)-endpoint and one \(Z\)-endpoint: duplicate
local classes are impossible, two \(T\)-classes are impossible, and a
\(T\)-class cannot coexist with \(V\) or \(Z\).

For the \(V,Z\) profile, extend a shared label of either local pair.
Its facial equation forces \(\sigma=0\), makes that endpoint contribute
one, and leaves the other local pair plus rung with contribution at most
two.  The centre contributes zero.

### One complement singleton

Let \(r_0,x_0\) be its label and rung, and put

\[
 C=\{r_0,x_0,a_1\}.                              \tag{10}
\]

The two centre indicators agree, so the two short residual cuts have the
same shore parity.  If the parity is even, the zero lemma gives a
matching with \(\sigma=r_0=x_0=0\); the shared endpoint contributes at
most two in the centre-zero state.  If the parity is odd, any centre-zero
matching has \(r_0+x_0=1\), and the shared endpoint again contributes at
most two.  This includes a \(T\)-endpoint.

### Two complement singletons

Take a centre-zero matching.  An odd-parity side contributes exactly one,
whereas an even-parity side contributes zero or two.  If at least one
side is odd, the two sides contribute at most \(1+2=3\).

If both sides are even, apply the zero lemma to either residual cut.  It
sets that side and the centre pair to zero; the other side contributes at
most two.  This includes the balanced profile proved separately in
Note 039.

Thus every balanced remote centre is safe.

## Empty endpoint classes and exhaustion

If an endpoint root class is empty, then

\[
 |A(x)|+\deg_{F^*[\{s,t,q\}]}(x)=1.
\]

Delete that endpoint, apply the three-vertex theorem of Note 035, and
restore its single rung.  The resulting cost is at most \(2+1=3\).

Every nonempty endpoint class is a singleton, a size-two class, or the
unique \(T\)-class.  The retained common neighbour of \(c,c_p\) is
unique, as is the retained common neighbour of \(c,c_h\).  Hence among
\(s,t,q\) there is at most one member of \(\{V,T\}\) and at most one
member of \(\{Z,T\}\).  The shared-root tables, the cases with zero, one,
or two complement singletons, and these uniqueness exclusions exhaust
all legal endpoint pairs.

Consequently

\[
\boxed{
 |A(t)|=2,\quad F^*[\{s,t,q\}]=s-t-q
 \quad\Longrightarrow\quad
 \min_{M\in\operatorname{PM}(K)}|M\cap E_Q(W)|\le3.}
\]

The theorem covers only path profiles with a size-two centre.  It does
not treat a size-three centre and does not treat the case in which the
three nonroot vertices form a triangle.
