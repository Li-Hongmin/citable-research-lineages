> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every tight gapless two-vacancy square opening is Hamiltonian

[Note 234](234-all-tight-gapless-internal-double-vacancies-are-hamiltonian.md)
settles two vacancies in internal face blocks.
The remaining two-vacancy configurations have at
least one vacancy in a site block. Boundary peeling
reduces distinct-block configurations to the same
two free-group signatures as Notes 232 and 234.
For two vacancies in one site block, only one
previously unclassified free matching remains;
it has two nested rainbow detours.

Let \(G\) be a Barnette parent with a Hamilton
cycle \(C\) avoiding the disjoint cofacial
matching site edges \(q=xy,p=uv\). Select an
all-square facial opening and compress each
lobe to one residual square as in Note 178.
Assume \(\ell,r\ge1\), no interblock gaps,
tight target order, and exactly two eligible
vacancies. By Note 197 this is the boundary
\[
f=4r+6.                                          \tag{1}
\]

**Second-surplus tight-gapless theorem.** The
parent has a Hamilton cycle containing both
site edges \(xy,uv\). Consequently its legal
site-expanded child is Hamiltonian. The
conclusion holds for arbitrary positive
original square-trap lobe lengths and every
placement of the two vacancies among the
\(r+2\) main blocks.

If both vacancies are internal, Note 234 applies.
If they lie in distinct blocks with an occupied
target between them, Note 215 applies, including
vacancies in site blocks. We therefore consider
only at least one site-block vacancy and no
occupied target between the two vacancies.

**Boundary peels.** If a vacancy in \(B_0\)
has occupied target pairs before it, peel them
from the left boundary by Note 186 until that
vacancy is at the first eligible position.
If a vacancy in \(B_{r+1}\) has occupied target
pairs after it, peel them from the right boundary.
Each inverse is simple: the successor or predecessor
at the site remains a target or a free vacancy slot,
not the opposite site endpoint. The peels remove
neither vacancy and preserve the no-target-between
condition, the tight order, empty gaps and the
Barnette class. A reduced parent Hamilton cycle
through \(xy,uv\) lifts through each inverse
by Note 185's spanning incident-edge route while
retaining both site edges. Tight order keeps
\(R_\ell\) in the left site block and \(L_1\)
in the right site block. When only one square
remains, neither boundary triple of Note 186
can occur, since \(r\ge1\) separates these
blocks. Thus at least one residual square
remains. We work after these
peels and reverse them at the end.

When vacancies are in distinct blocks, a left
site-block vacancy now gives exactly the free
suffix \(h_L,i_L,e_0\) after \(R_\ell\): any
further occupied eligible position of \(B_0\)
would lie between the vacancies. A right
site-block vacancy similarly gives exactly
the free prefix \(o_{r+1},h_R,i_R\) before
\(L_1\). In an internal target-bearing block,
the vacancy must be last eligible on the left
or first eligible on the right, since a target
on the facing side would separate the vacancies.
Every complete block between the two vacancy
blocks is short and target-free.

Thus each outer end of their shared free group
has one of two types:
\[
\begin{array}{ll}
\text{full:}&o,h,i,e
\quad\text{in a target-free face block},\\
\text{one-sided left:}&h,i,e
\quad\text{in a target-bearing face block or }B_0,\\
\text{one-sided right:}&o,h,i
\quad\text{in a target-bearing face block or }B_{r+1}.
\end{array}                                           \tag{2}
\]
If both ends are full, Note 223 applies. If
both are one-sided, the group's slot order is
exactly Note 232 (1). Its proof uses only the
noncrossing opposite-side disk, old-cycle
adjacency of the six boundary slots, and
the two-edge-cut rule for complete intervening
short blocks. These properties hold unchanged
when either one-sided block is a site block:
the site chord closes that block in the same
disk as a face chord, and the free group uses
only the displayed three slots of that block.
Hence Note 232's nested pair, one-detour and
two-detour classification and marked routes apply.

If exactly one end is full, reflect the old
cycle if necessary so the full block is left.
The group then has precisely Note 234's mixed
slot order, ending in \(o,h,i\). Its proof
that the only internal free chord \(oe\) is
impossible, its noncrossing classification,
and its marked routes use no free slot after
the right one-sided prefix. They therefore
apply even when the right block is
\(B_{r+1}\), where \(L_1\) closes the group
without a further free slot. All distinct-block
cases have a marked Hamilton cycle.

**Two vacancies in one site block.** Reflect if
necessary so both lie in \(B_0\). Peel all
occupied target pairs before the first vacancy.
The reduced block starts at
\[
x,R_\ell,h_1,i_1,
\mathcal B,h_2,i_2,
\mathcal C,e_0,y,                                  \tag{3}
\]
where \(\mathcal B,\mathcal C\) are consecutive,
possibly empty runs of occupied transition
targets. Other blocks may have occupied runs.
Every run outside \(B_0\) is a free-matching
barrier by the even-prefix argument of Note 215;
if \(\mathcal C\) is nonempty, it is also a
barrier because only \(e_0\) is free after it
inside \(B_0\).

If \(\mathcal B\) is empty and
\(\mathcal C\) nonempty, the four slots
\(h_1,i_1,h_2,i_2\) are isolated between
the target \(R_\ell\) and the barrier
\(\mathcal C\). Their only non-cycle
opposite-colour pair is \(h_1i_2\), so
they have no perfect matching. This case
cannot occur.

Suppose \(\mathcal B\) is nonempty. The
two slots \(h_1,i_1\) before its first
target cannot match each other, since they
are adjacent on \(C\), or leave across a
target by a cross-block chord. Matching
parity requires exactly two same-block
chords across \(\mathcal B\). They lie on
the site-face side, since the target escape
edges lie opposite it. The even slot
\(h_1\) must match \(i_2\); the other
candidate is \(i_1h_2\), or, when
\(\mathcal C\) is empty, \(i_1e_0\).
The latter interlaces \(h_1i_2\) on the
same side and is impossible. Thus
\[
h_1i_2,\qquad i_1h_2\in M.                     \tag{4}
\]
All other free slots follow the standard
chain: occupied runs are barriers, same-block
free chords in ordinary blocks are old-cycle
edges or cross a barrier, and a skipped
complete block interval would give a two-edge
cut. Note 231's same-square sweep now gives
a Hamilton cycle through \(xy,uv\): it
traverses \(h_1i_1\) and \(h_2i_2\) in
their respective \(R_j\)-to-\(L_j\)
free intervals, without using (4).

It remains that both \(\mathcal B\) and
\(\mathcal C\) are empty. The reduced
site block has interior
\(R_\ell,h_1,i_1,h_2,i_2,e_0\).
Let \(B_1,\ldots,B_t\) be all short
face blocks before the next occupied
target run, and let \(o_{t+1}\) be the
first free odd slot of that next block
or of \(B_{r+1}\). The free group is
\[
h_1,i_1,h_2,i_2,e_0,
(o_1,e_1),\ldots,(o_t,e_t),o_{t+1}.
\tag{5}
\]
Every ordinary-to-ordinary matching edge
is a standard link \(P_j=e_jo_{j+1}\),
\(0\le j\le t\): a nonstandard cross-block
edge would close a nonempty complete
short-block interval into a two-edge cut.
The only possible non-cycle same-block
free chords are \(h_1i_2\) and
\(i_1e_0\).

First suppose \(i_1e_0\in M\). Then
\(P_0=e_0o_1\) is missing, and the odd
slot \(o_1\) must match \(h_1\) or
\(h_2\). If \(h_1o_1\) occurred, the
opposite-side chord would enclose the
unmatched adjacent pair \(h_2,i_2\),
which cannot pair or leave it. If
\(h_2o_1\) occurred, the odd slot
\(i_2\) could only match \(h_1\):
every later even port would give an
opposite-side chord interlacing
\(h_2o_1\), while \(i_2e_0\) is an
old-cycle edge. Then both internal
chords \(h_1i_2,i_1e_0\) interlace
\(h_2o_1\), forcing them onto the
site-face side, where they interlace
each other. Thus \(i_1e_0\notin M\).

Now \(e_0o_1\in M\): \(e_0\)'s other
possible odd mates are \(i_1\), just
excluded, and its old-cycle neighbour
\(i_2\); every nonstandard ordinary
mate was excluded above. If
\(h_1i_2\in M\), the remaining
\(i_1,h_2\) must meet the two ends
of one missing standard link
\(P_a=(E_a,O_a)\), \(a\ge1\).
The cross-block chords \(i_1E_a\)
and \(h_2O_a\) interlace because
\(i_1<h_2<E_a<O_a\). Hence
\(h_1i_2\notin M\) either.

All four vacancy slots therefore
match ordinary ports. Exactly two
standard links \(P_a,P_b\),
\(1\le a<b\le t\), are missing.
Noncrossing forces the unique rainbow
pairing
\[
h_1O_b,\quad i_1E_b,\quad
h_2O_a,\quad i_2E_a.                              \tag{6}
\]
Indeed, \(h_1O_a\) would leave
\(i_1,h_2,i_2,E_a\) inside its chord,
where only old-cycle pairings remain
after the retained standard links are
removed. Thus \(h_1O_b\); likewise
\(i_1E_a\) would leave the adjacent
pair \(h_2,i_2\) inside, so
\(i_1E_b\), and the last two matches
are forced. In particular \(t\ge2\).
Replace the two missing edges of
Note 196's ordinary free path by
\[
E_a,i_2,h_2,O_a
\quad\text{and}\quad
E_b,i_1,h_1,O_b.                                   \tag{7}
\]
Their outer edges are matching edges
and their middle edges are in the
even-starting old-cycle matching.
They are disjoint and insert every
vacancy slot once. Together with the
unchanged target-and-square path they
give a marked Hamilton cycle.

Reverse all boundary peels using the
marked lift described above. Note 001
lifts the resulting cycle through the
legal site expansion, and Note 178
restores the original positive lobe
lengths. This proves the theorem.
\(\square\)

**A realized outer rainbow.** Let
\(\ell=1,r=2,t=2,a=1,b=2\). The old
24-cycle has consecutive blocks
\[
\begin{array}{ll}
B_0:&x,R_1,h_1,i_1,h_2,i_2,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_1:&\alpha_1,\gamma_1,\delta_1,\beta_1,
\text{ returning to }x.
\end{array}                                           \tag{8}
\]
Add the complementary matching
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,
\alpha_1\beta_1,R_1\delta_1,L_1\gamma_1\}\\
&\cup\{e_0o_1,i_2e_1,h_2o_2,
          i_1e_2,h_1o_3\}.
\end{split}                                           \tag{9}
\]
All matching pairs have opposite
old-cycle parity. Draw the site,
face and \(\alpha_1\beta_1\) chords
on one side. On the other side,
\(R_1\delta_1\) encloses the nested
free chain
\[
h_1o_3\supset i_1e_2\supset
h_2o_2\supset i_2e_1\supset e_0o_1,
\tag{10}
\]
and \(L_1\gamma_1\) lies in a
disjoint gap. Thus the parent is
simple, cubic, bipartite, plane,
and has cofacial \(xy,uv\).

Its matching-chord interlacement
graph is connected. One chain is
\[
xy-h_1o_3-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-xy.
\tag{11}
\]
The remaining chords attach through
\(xy-e_0o_1-a_1b_1-i_2e_1\),
\(xy-h_2o_2-a_2b_2-i_1e_2\);
both \(i_2e_1\) and \(i_1e_2\)
interlace \(xy\). Note 217's
interval criterion gives
three-connectivity, and its cut
projection makes the 28-vertex
site expansion Barnette. The
marked Hamilton cycle is the union
of the internally disjoint paths
\[
\begin{split}
&x,y,e_0,o_1,a_1,b_1,e_1,i_2,h_2,o_2,
 a_2,b_2,e_2,i_1,h_1,o_3,u,v,\\
&x,R_1,\delta_1,\beta_1,\alpha_1,
 \gamma_1,L_1,v.
\end{split}                                           \tag{12}
\]
They cover all 24 vertices. \(\square\)

Thus any non-Hamiltonian legal child
admitting a tight, gapless all-square
opening has \(f\ge4r+8\), since
Notes 196, 214 and the present theorem
settle \(f=4r+2,4r+4,4r+6\).
This remains an opening-relative bound;
it does not establish such an opening
for every Barnette graph or settle
Barnette's conjecture.
