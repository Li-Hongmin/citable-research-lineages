> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A terminal-port U-turn closes facing target vacancies

[Note 322](322-facing-target-vacancies-reduce-to-one-mixed-terminal-core.md)
leaves one mixed terminal arrangement: the left facing vacancy
belongs to a missing-link component, while the right facing vacancy
belongs to a port-free component. The missing link admits a spanning
route that turns back through the complete blocks before it. The
matching of the right component is then irrelevant to the route.

Use the compressed, gapless, tight-target all-square opening and
notation of Notes 231, 321, and 322. A target-free face block
\(B_i\) has the old-cycle order
\[
 a_i,o_i,\text{all its other free interior slots},e_i,b_i,
\]
and the face chord \(a_ib_i\). All free interior slots of such a
block are consecutive on the old cycle. The ordinary link between
\(B_i,B_{i+1}\) is \(e_io_{i+1}\).

**Terminal-port U-turn lemma.** Let \(T=R_j\) and \(U=L_j\) be
consecutive occupied targets bounding one free interval. In a face
block \(B_k\), suppose the last eligible position after a nonempty
occupied run is the vacant pair \(h,i\), with old-cycle segment
\(T,h,i,e_k,b_k\). Suppose exactly one ordinary link in this free
interval is missing, namely
\[
 P_s=e_so_{s+1},\qquad s\ge k+1,
\]
and its two endpoints have complementary matching mates
\[
                         ie_s,\qquad ho_{s+1}.       \tag{1}
\]
Every block \(B_{k+1},\ldots,B_s\) is complete and target-free.
All other ordinary links in the opening are retained. The free
slots from \(o_{s+1}\) through \(U\) contain no occupied target.
They may contain any number of vacant pairs, in target-free blocks
or in a right target-bearing block immediately before \(U\), with
any complementary matching among their slots. Then the parent has
a Hamilton cycle through both site edges \(xy,uv\).

**Proof.** Put \(D=B_{k+1},\ldots,B_s\). Starting at \(e_s\),
traverse the complete free interior of each block in reverse
old-cycle order, crossing from \(o_t\) to \(e_{t-1}\) by the
retained link \(e_{t-1}o_t\), until reaching \(o_{k+1}\).
Continue through \(o_{k+1}a_{k+1}\), then follow the face chords
and old-cycle joins
\[
 a_{k+1},b_{k+1},a_{k+2},b_{k+2},\ldots,a_s,b_s.
\]
This is an \(e_s\)--\(b_s\) path \(Q_D\) spanning every vertex
of \(D\). Its reverse-interior half and forward-face half are
disjoint. The construction works for arbitrarily many free slots
per block and uses none of their complementary matching edges.

Start with the exposed-face \(x\)--\(v\) path (4) of Note 231.
Replace its segment from \(b_k\) through the face chords of
\(D\) to \(a_{s+1}\) by
\[
 b_k,e_k,i,e_s\xrightarrow{Q_D}b_s,a_{s+1}.       \tag{2}
\]
The edges \(b_ke_k,e_ki,b_sa_{s+1}\) lie on the old cycle,
and \(ie_s\) is (1). The new path still covers every face-chord
endpoint; it also covers \(i,e_k\) and all interior slots of \(D\).

In the residual-square \(x\)--\(v\) path (5)--(6) of Note 231,
replace only the \(T\)--\(U\) interval by
\[
 T,h,o_{s+1}\xrightarrow{\mathrm{straight}}U.    \tag{3}
\]
Here \(Th\) is an old-cycle edge, \(ho_{s+1}\) is (1),
and the straight suffix follows old-cycle edges within every
block and the retained links \(e_to_{t+1}\) between blocks.
It ends at \(U\) without crossing another target. In every
other target interval use the ordinary standard-link sweep of
Note 321.

The paths (2) and (3), together with their unchanged portions,
are internally disjoint. In the exceptional interval (2) covers
exactly \(i,e_k,V(D)\), while (3) covers \(h\) and all free slots
from \(o_{s+1}\) to \(U\); other target intervals are unchanged.
All residual-square vertices remain on the second path. Hence the
two \(x\)--\(v\) paths cover every vertex and form a Hamilton
cycle containing \(xy,uv\). \(\square\)

**Boundary locality.** The construction changes only the
\(T\)--\(U\) target interval and the exposed-face segment from
\(b_k\) to \(a_{s+1}\). It preserves their four exterior
attachments. Thus the same two local paths can replace the
corresponding segments when other target intervals have their own
compatible spanning routes; retained links outside this group
were used above only to choose the standard sweeps there.

**Facing-vacancy theorem at arbitrary distinct-block surplus.**
Under the hypotheses of Note 322, the parent has a Hamilton cycle
through both site edges, and its legal site-expanded child is
Hamiltonian. Thus there is no remaining mixed terminal case in
that theorem's class.

**Proof.** Perform the exact reductions of Note 322 and eliminate
ports in all other free groups as in Note 321. Outcomes 1--3 of
Note 322 already have marked Hamilton cycles. In outcome 4,
reflect the opening if needed so that the left terminal component
contains the sole port. It is exactly \(\{L,P_s\}\). The old-cycle
edge exclusions and the noncrossing rainbow pairing force its
matching edges to be \(i_Le_s,h_Lo_{s+1}\). Its right terminal
component is port-free, so every other ordinary link is retained.
The target-free blocks between \(L\) and \(P_s\) are complete;
\(s=k\) would make \(i_Le_k\) an old-cycle edge, so \(s\ge k+1\).
The two facing target runs supply the targets \(T,U\) in the lemma.
Apply (2)--(3), then reverse the exact reductions. Notes 001 and
178 transfer the marked cycle to the legal child and restore
arbitrary positive original lobe lengths. \(\square\)

This is a route theorem for the stated all-square, tight-target,
gapless opening. It does not cover same-block repeated vacancies,
vacancies in site blocks, positive gaps, defective target order,
nonsquare residual cycles, or general Barnette graphs. The direct
U-turn route is new to this project; the cube reductions used from
Notes 315 and 322 are instances of the Holton--Manvel--McKay
operation, as restated by Gorsky--Steiner--Wiederrecht (2023,
Section 5). No external priority or independent proof review is
claimed.
