> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-free near-equality vacancies exist at every lobe and chord count

[Note 205](205-an-internal-near-equality-vacancy-must-touch-a-short-block.md)
reduces a tight, gapless, first-surplus internal vacancy to
three shapes. [Note 204](204-two-chord-detours-realize-gapless-near-equality-for-all-lobe-counts.md)
realizes both one-sided target shapes. The remaining shape,
a four-interior-slot face-chord block containing no escape
target, also occurs in a Barnette graph for every lobe count.
It has a marked Hamilton cycle, and the same square amplifier
as in [Note 190](190-fixed-lobe-chord-amplification-preserves-two-hamilton-witnesses.md)
makes the opposite-face chord count arbitrary.

Fix \(\ell\ge1\). Let \(C_\ell\) be the cycle obtained by
concatenating the main segment
\[
\begin{aligned}
x,R_\ell,L_\ell,R_{\ell-1},L_{\ell-1},\ldots,L_2,R_1,e,y,
 a_1,o,h,i,e_1,b_1,\\
 a_2,o_2,e_2,b_2,u,z,L_1,v
\end{aligned}                                                   \tag{1}
\]
with the complementary segment
\[
v,\alpha_1,\gamma_1,\delta_1,\beta_1,\ldots,
\alpha_\ell,\gamma_\ell,\delta_\ell,\beta_\ell,x.
\tag{2}
\]
For \(\ell=1\), the target string between \(x,e\) in (1)
is just \(R_1\). Add the perfect matching
\[
\begin{aligned}
M_\ell={}&\{xy,a_1b_1,a_2b_2,uv,
eo,hz,ie_2,e_1o_2\}\\
&\cup\{\alpha_t\beta_t,\gamma_tL_t,
\delta_tR_t:1\le t\le\ell\}.
\end{aligned}                                                   \tag{3}
\]
Put \(G_\ell=C_\ell\cup M_\ell\), with site edges
\(q=xy,p=uv\).

**Target-free vacancy theorem.** For every \(\ell\ge1\),
\(G_\ell\) is a simple three-connected cubic bipartite
plane graph. Its two site edges are cofacial, and its
selected all-square opening has \(r=2\), \(f=12\), no
interblock gaps, tight endpoint and consecutive-lobe
target order, and a unique vacant eligible even slot
\(h\) in the four-interior-slot block \(B_1=[a_1,b_1]_C\).
There is no escape target inside \(B_1\). The parent has
a Hamilton cycle containing both site edges; its legal
site-expanded child is Hamiltonian. Both graphs have,
respectively, \(6\ell+16\) and \(6\ell+20\) vertices.

**Proof.** The pairs in (3) cover each vertex once, join
opposite colours on the even cycle (1)--(2), and do not
duplicate its edges. Thus the graph is simple, cubic and
bipartite. Draw \(C_\ell\) as a Jordan curve. On the
designated site-face side, draw \(xy,a_1b_1,a_2b_2,uv\)
and the mutually disjoint \(\alpha_t\beta_t\) chords.
These chords are noninterlacing, and \(xy,uv\) bound the
same face. On the other side, the escape chords are
nested in the order
\[
R_\ell\delta_\ell\supset L_\ell\gamma_\ell
\supset R_{\ell-1}\delta_{\ell-1}\supset\cdots
\supset R_1\delta_1\supset L_1\gamma_1.
\tag{4}
\]
The four free chords lie inside \(R_1\delta_1\).
There \(eo\) lies before the nest
\[
hz\supset ie_2\supset e_1o_2;
\tag{5}
\]
all of (5) ends before \(L_1\), so it is disjoint
from \(L_1\gamma_1\). This gives a plane drawing.
Each \(\alpha_t,\gamma_t,\delta_t,\beta_t\) is one
residual square attached to the main segment. The
blocks \(B_0,B_1,B_2,B_3\) have respectively
\(2\ell,4,2,2\) interior slots, and the only extra
eligible even position not occupied by a nonfinal
\(L_t\) is \(h\). The target order is as stated.
Since \(|V(S_0)|=2\ell+16\), the free count is
\(f=|V(S_0)|-2\ell-4=12\).

To prove three-connectivity, use the interlacement
criterion proved in Note 204: a cubic graph \(C\cup M\)
with connected matching-edge interlacement graph has
no edge cut of size at most two, hence is three-connected.
Here \(xy\) interlaces every \(R_t\delta_t\) and every
\(L_t\gamma_t\) for \(t\ge2\), and it interlaces \(eo\).
The edge \(eo\) interlaces \(a_1b_1\). The latter
interlaces \(hz,ie_2,e_1o_2\); the edge \(e_1o_2\)
interlaces \(a_2b_2\); and \(hz\) interlaces \(uv\).
Finally \(uv\) interlaces \(L_1\gamma_1\), and each
\(\alpha_t\beta_t\) interlaces \(L_t\gamma_t\).
These incidences reach every edge of (3), so the
interlacement graph is connected.

Let \(A\) be the even-starting edges of \(C_\ell\),
numbered from \(x\). The target and square vertices
form the \(M_\ell\cup A\) path
\[
x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,R_{\ell-1},\ldots,
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\tag{6}
\]
For \(\ell=1\), read (6) as
\(x,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v\).
The remaining vertices form the disjoint path
\[
x,y,e,o,a_1,b_1,e_1,o_2,a_2,b_2,e_2,i,h,z,u,v.
\tag{7}
\]
Its matching edges are \(xy,eo,a_1b_1,e_1o_2,
a_2b_2,e_2i,hz,uv\); its other edges belong to \(A\).
The paths (6)--(7) cover every vertex and meet only at
\(x,v\). They form a Hamilton cycle through both site
edges. Note 001 lifts it to the legal expanded child.
\(\square\)

**All chord counts.** For every \(\ell\ge1,r\ge2\),
there is such a parent and Hamiltonian expanded child
with \(r\) opposite-face chords, \(f=4r+4\), and the
same target-free vacancy in \(B_1\). In the base graph,
\((A,B,W,Z)=(a_2,o_2,e_2,b_2)\) is a facial square of
Note 190's type. The Hamilton cycle (6)--(7) uses
\(AZ=a_2b_2\) and avoids \(BW=o_2e_2\). Apply the
marked square amplifier \(r-2\) times, always to its
new short square. Each step splits one two-slot face
block into two two-slot blocks, increases \(r\) by one
and \(f\) by four, and leaves \(B_1\), its vacant
slot and all escape targets unchanged. Note 190 preserves
the Barnette property and the marked Hamilton cycle,
while Note 001 lifts the latter through the site
expansion. The resulting parent and child have
\(6\ell+4r+8\) and \(6\ell+4r+12\) vertices.

Together with Note 205 and the one-sided realizations
from Note 204, this shows that all three permitted
internal-vacancy shapes actually occur in Hamiltonian
Barnette parents. It does not decide arbitrary
first-surplus openings or Barnette's conjecture.

[Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)
subsequently shows that every tight, gapless opening
with a target-free internal vacancy has a marked
Hamilton cycle; the construction above realizes one
of the two forced detour directions.
