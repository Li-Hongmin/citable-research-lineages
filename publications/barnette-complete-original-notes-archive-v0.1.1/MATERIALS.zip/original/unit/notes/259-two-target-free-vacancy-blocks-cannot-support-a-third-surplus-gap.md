> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two target-free vacancy blocks cannot support a third-surplus gap

[Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
shows that a positive gap in an all-square opening requires at least
two vacant eligible block positions. At the first possible boundary
\(f=4r+8\), its count forces \(\sigma=2,T=2\). The following
parity rule and interval closure exclude the branch in which the two
vacancies lie in distinct target-free blocks.

Use the compressed opening of Notes 193 and 195 in a
three-connected cubic bipartite plane graph. Let \(C\) be its
old Hamilton cycle, \(M=E(G)\setminus E(C)\), and call a
free-slot chord *face-side* if it lies on the side of \(C\)
containing the designated common face. All cross-block and
gap-to-block free chords lie on the opposite side.

**Cross-block parity lemma.** Let \(st\in M\) join free slots
in two different complete blocks \(B_i,B_j\). Then the
number of face-side free chords in \(B_i\cup B_j\) that
straddle exactly one of \(s,t\) is even. Equivalently, the
numbers of face-side chords straddling \(s\) and \(t\)
have the same parity.

**Proof.** Note 203 forbids an escape target strictly between
\(s,t\). The open old-cycle interval between them has an even
number of vertices, since \(s,t\) have opposite bipartition
colours. It contains one fixed endpoint of each end block
and both fixed endpoints of every complete intervening block,
so its number of free slots is even. An opposite-side matching
chord with one free endpoint inside and one outside this
interval would interlace \(st\). Thus the number of free
slots inside that leave through face-side chords is even.
Only the two end blocks can have a face-side chord crossing
the interval boundary, and such a chord crosses it exactly
when it straddles \(s\) or \(t\). \(\square\)

**Target-free split-vacancy exclusion theorem.** Suppose
\[
f=4r+8,\qquad \sigma=2,\qquad T=2,\qquad \ell,r\ge1.
\]
If the two vacant eligible positions lie in distinct blocks
\(A,B\), and neither block contains an escape target, then
the opening cannot occur. This applies whether the two gap
slots occupy one gap or two distinct gaps.

**Proof.** Each of \(A,B\) contains one vacancy and no target,
so its capacity is one and its four interior slots are all
free. Write those slots in old-cycle order as \(U,D,E,V\).
Its only possible non-cycle same-block matching edge is
\(UV\). By Note 255, every other block is saturated and has
no same-block free chord. The gap-edge localization lemma of
Note 258 therefore sends both gap slots to \(A\) or \(B\).
Every block receiving a gap slot must have its face-side
edge \(UV\), and the gap mate lies in one of its inner slots
\(D,E\), again by the odd crossing parity of Note 258.

First suppose both gap slots use the same block, say \(A\).
Its outer two slots are matched by \(UV\), and its inner
two slots are matched to the gap slots. Consider the shortest
consecutive interval of \(C\) containing the whole block
\(A\) and both gap slots. The two gap-to-\(A\) chords connect
these three atoms; their spans cover every place between the
first and last atom. A target between them would be straddled
by one of these chords, contrary to Note 203. Any other free
slot in the interval lies under one of the two opposite-side
chords, so its opposite-side matching edge cannot leave the
interval without crossing that chord. Every face-side chord
lies within a complete block of the interval. The matching
edges of \(A\) and the two gap slots are internal as well.
Hence the interval is closed under \(M\). Exactly two old-cycle
edges leave it, contradicting three-connectivity.

Now suppose the gap slots use different blocks. Both \(A,B\)
have the face-side outer chord \(UV\); each gap slot takes one
inner slot. The other inner slot of each block is free and
cannot match a slot of any saturated block: such a cross-block
edge would have one face-side chord straddling its endpoint in
\(A\) or \(B\), and none straddling its other endpoint,
contrary to the cross-block parity lemma. Both gap slots are
already matched and the outer slots are used, so the two
remaining inner slots of \(A,B\) must match each other.

The three opposite-side chords now connect the four atoms
\(A,B\) and the two gap slots into a tree: one chord from
each gap slot to its block and one joining the blocks.
Take the shortest consecutive \(C\)-interval containing all
four atoms, including each complete block. Across every cut
between consecutive atoms, some tree edge passes, so its
chord spans every intervening position. No escape target can
lie in the interval, by Note 203. Every free slot other than
the four inner slots and two gap slots lies under one of these
chords, unless it is an outer slot of \(A\) or \(B\), already
matched by a face-side chord. An opposite-side edge from any
such slot to outside the interval would cross the covering
chord; every face-side edge stays within a complete block.
Thus this interval is also matching-closed and has only two
departing old-cycle edges, a contradiction. \(\square\)

Consequently, a positive-gap opening at \(f=4r+8\) must
place both vacancies in one block or put at least one vacancy
in a block containing an escape target. The theorem is a
necessary structural restriction. It does not settle the
remaining third-surplus openings, nonsquare residual cycles,
or Barnette's conjecture.
[Note 260](260-a-twenty-two-vertex-sharp-positive-gap-opening.md)
realizes the same-block, target-free alternative at the
minimum possible parent order.
