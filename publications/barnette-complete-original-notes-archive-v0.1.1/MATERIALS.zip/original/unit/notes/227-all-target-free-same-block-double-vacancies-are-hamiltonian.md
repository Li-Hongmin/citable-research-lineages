> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All target-free same-block double vacancies are Hamiltonian

[Note 225](225-one-sided-flanks-of-a-double-vacancy-block-are-hamiltonian.md)
classifies arbitrary one-sided short-block flanks, while
[Note 226](226-same-block-double-vacancies-without-internal-matching-chords-are-hamiltonian.md)
settles arbitrary two-sided flanks when the exceptional
block has no internal free matching chord. The four
possible internal chords form a small enough obstruction
to settle directly. Thus no restriction on either flank
length remains.

Use a compressed all-square Barnette opening as in
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
with \(\ell,r\ge1\), empty interblock gaps, tight target
order and precisely two eligible vacancies. Assume both
vacancies lie in one target-free face-chord block \(D\),
whose six free slots are
\[
o,h_1,i_1,h_2,i_2,e                              \tag{1}
\]
in old-cycle order. Its complete free matching group
may contain arbitrary short target-free face blocks
on either side. Write the ordinary chain of that group
as \(P_j=(E_j,O_j)\), \(0\le j<N\), ordered as in
Note 226. Let
\[
P_L=(E_L,o),\qquad P_R=(e,O_R)                   \tag{2}
\]
be the two links adjacent to \(D\).
Every other ordinary link lies wholly before \(D\)
or wholly after \(D\). The matching \(M\) is the
complement of the chosen old Hamilton cycle \(C\).

**Full target-free double-block theorem.** The parent
has a Hamilton cycle containing both site edges \(xy,uv\).
Every legal site-expanded child is Hamiltonian. This
holds for arbitrary nonnegative short-block flank
lengths and arbitrary positive original square-trap
lobe lengths.

Consequently, at \(f=4r+6\) in the tight, gapless,
all-square setting, *every* opening whose two
vacancies lie in target-free face-chord blocks has
a marked Hamilton parent cycle: Note 223 treats
distinct blocks in one free group, Note 215 treats
target-separated groups, and the present theorem
treats one block.

**Ordinary-edge rule.** Every matching edge with
two ordinary endpoints is a standard chain link
\(E_jO_j\), except possibly \(oe\).
Indeed, a forward nonstandard cross-block chord
encloses at least one complete face block. A backward
cross-block chord encloses a complete consecutive
block interval. Every free chord leaving that interval
would cross the proposed chord in the opposite-side
disk, while a same-block chord stays inside its block.
The interval would therefore be matching-closed and
have only two exiting old-cycle edges, contradicting
three-connectivity. The only same-block pair of
ordinary free slots that is not an old-cycle edge
is \(oe\). This is Note 220's skipping argument
with the internal chord exception retained.
\(\square\)

**Proof of the theorem.** If \(D\) has no internal
free matching chord, apply Note 226. Otherwise the
only possible internal free chords are
\[
J_0=oe,\qquad J_1=oh_2,\qquad
J_2=h_1i_2,\qquad J_3=i_1e.                    \tag{3}
\]
The omitted opposite-colour pairs are old-cycle
edges. Every cross-block free chord is in the
opposite-side disk by Note 193. We use the
ordinary-edge rule and the fact that two
opposite-side chords cannot interlace.

First suppose \(J_0=oe\in M\). Then \(J_1,J_3\)
are unavailable because they share its endpoints.
If \(J_2\notin M\), all four extra slots
\(h_1,i_1,h_2,i_2\) must match ordinary ports.
Exactly three standard chain links are missing:
\(P_L,P_R\) and a third \(P_s\). The first two
each lose an endpoint to \(J_0\), leaving
\(E_L,O_R\), while the third supplies \(E_s,O_s\).

The chords from \(E_L\) and \(O_R\) to the extra
slots must be \(E_Li_1\) and \(h_2O_R\).
For if \(E_L\) matched \(i_2\), its chord would
interlace either \(h_1O_R\) or \(h_2O_R\).
With \(E_Li_1,h_2O_R\) fixed, the remaining
extra slots \(h_1,i_2\) match \(O_s,E_s\).
If \(P_s\) is on the left, then
\[
E_s<O_s<E_L<h_1<i_2,
\]
so \(E_si_2\) and \(O_sh_1\) interlace. If
\(P_s\) is on the right, then
\[
h_1<i_2<O_R<E_s<O_s,
\]
so \(h_1O_s\) and \(i_2E_s\) interlace.
There is no third location for \(P_s\).
Hence \(J_2\in M\). The ordinary-edge rule now
forces precisely
\[
E_Li_1,\quad oe,\quad h_1i_2,\quad h_2O_R
\tag{4}
\]
besides all other standard chain links.
Note 224's path
\[
E_L,i_1,h_1,o,a_D,b_D,e,i_2,h_2,O_R           \tag{5}
\]
replaces the ordinary segment across \(D\).
All short-block flanks remain on their standard
paths, so (5) yields one spanning free path.

Now suppose \(J_2=h_1i_2\in M\) but
\(J_0\notin M\). The chords \(J_1,J_2,J_3\)
are pairwise interlacing in the order (1);
all three cannot coexist in a two-disk planar
drawing. If \(J_1\in M\) and \(J_3\notin M\),
the ordinary-edge rule forces \(E_Li_1\)
and retains all other standard links. Since
\(E_Li_1\) interlaces both \(J_1=oh_2\)
and \(J_2=h_1i_2\), those two internal
chords would both have to lie on the site-face
side. They interlace one another, a contradiction.
The case \(J_3\in M,J_1\notin M\) is the
old-cycle reflection: \(h_2O_R\) forces
both \(J_2,J_3\) to the site-face side,
where they interlace. Thus \(J_2\) occurs
alone. Exactly one standard link
\(P_s=(E_s,O_s)\) is missing, replaced by
\[
E_s,i_1,h_1,i_2,h_2,O_s.                     \tag{6}
\]
Its first, middle and last non-cycle edges
belong to \(M\), and the two intervening
edges \(i_1h_1,i_2h_2\) belong to the
even-starting old-cycle matching. It is a
five-edge detour in the spanning free path.

It remains to consider \(J_0,J_2\notin M\).
If \(J_1=oh_2\) occurs alone, exactly two
standard links are missing, \(P_L\) and
some \(P_s\ne P_L\). The free ordinary
endpoints \(E_L,E_s,O_s\) match the remaining
extra slots \(i_1,i_2,h_1\), so \(h_1O_s\)
and \(E_Li_j\) occur for one \(j\in\{1,2\}\).
If \(P_s\) is left of \(D\), then
\(O_s<E_L<h_1<i_j\); if it is right,
then \(E_L<h_1<i_j<O_s\). In either case
those two cross-block chords interlace.
Thus \(J_1\) cannot occur alone.
Old-cycle reflection excludes \(J_3\)
alone.

If \(J_1,J_3\in M\) together, exactly
\(P_L,P_R\) are missing and their free
ordinary endpoints must match \(i_2,h_1\).
The forced cross-block chords
\(E_Li_2,h_1O_R\) interlace because
\(E_L<h_1<i_2<O_R\). This excludes the
last possible internal-chord combination.
We have exhausted (3).

In cases (4) and (6), the displayed
spanning free path and Note 196's unchanged
target-and-square path join at \(x,v\)
to give one Hamilton cycle containing
\(xy,uv\). Note 001 lifts it through
the legal site expansion, and Note 178
restores arbitrary original lobe lengths.
\(\square\)

The theorem settles the two-vacancy branch
when both vacancies lie in target-free
face blocks. It does not cover vacancy
blocks with occupied escape targets,
vacancies in either outer site block,
defective target order, interblock gaps,
or nonsquare residual cycles.

