> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One opposite-face chord excludes a two-gap-slot near-equality opening

[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
sets the free-vertex minimum at \(f=4r+2\). At the next even
value \(f=4r+4\), either one additional pair lies inside the
site/face-chord blocks, or the blocks have exactly minimum
capacity and two slots lie in gaps. [Note 197](197-gapless-square-trap-defect-budget.md)
pins the escape endpoints in the latter case. When there is
only one opposite-face chord, the gap alternative is in fact
impossible for every lobe count.

Use the compressed one-square-per-lobe all-square facial
opening of Notes 176--179, with \(r=1\) and \(\ell\ge1\).
There are three closed blocks
\[
B_0=[x,y]_C,\qquad B_1=[a,b]_C,\qquad B_2=[u,v]_C
\tag{1}
\]
and two open gaps \(G_0=(y,a)_C\), \(G_1=(b,u)_C\).
Let \(B_i\) have \(2+2k_i\) interior slots and let
\(t_i=|G_i|\). Every edge joining free slots in different
atoms lies opposite the designated common face; such edges
are noncrossing in that disk. Two consecutive interior slots
of a short block cannot be matched to each other because
their edge already belongs to \(C\). The same holds for
two consecutive vertices in one gap.

**Two-gap exclusion theorem.** If \(r=1\), there is no legal
all-square opening satisfying
\[
f=8,\qquad k_0+k_1+k_2=\ell-1,\qquad t_0+t_1=2.
\tag{2}
\]
Consequently every \(r=1,f=8\) all-square opening has
\(t_0=t_1=0\) and \(k_0+k_1+k_2=\ell\). In particular,
Note 197's gapless defect budget applies to all such openings:
at most one boundary or consecutive-lobe target adjacency
can fail.

**Proof.** Assume (2). All eligible even block positions are
occupied by nonfinal \(L_j\) targets. By Note 197's saturated-gap
location theorem, \(R_\ell\) is the first interior slot of
\(B_0\) and \(L_1\) the final interior slot of \(B_2\).

If \(k_0>0\), the second interior slot of \(B_0\) is
\(L_\ell\), giving the boundary triple
\(x,R_\ell,L_\ell\). The following vertex is still
inside \(B_0\), so the simple, noncollision inverse of
Note 186 removes that lobe and two \(B_0\) slots. It
preserves the Barnette opening, \(r\), both gap lengths,
and the equality \(\sum k_i=\ell-1\) after \(\ell\)
decreases by one. Similarly, if \(k_2>0\), the final
eligible position of \(B_2\) is \(L_2\) and the final
three main vertices are \(R_1,L_1,v\); the reflected
simple inverse removes two \(B_2\) slots and one lobe.
Repeat until \(k_0=k_2=0\). This is possible also when
\(\ell=1\), since then all three \(k_i\) are already zero.
In the reduced opening
\[
k_1=\ell-1,
\tag{3}
\]
and it suffices to contradict the existence of its
complementary perfect matching.

Write \(e\) for the final interior slot of \(B_0\),
and \(o\) for the first interior slot of \(B_2\).
They are free, with colours \(E,O\), respectively.
All gap slots are free by Note 195. There are two possible
distributions of the two gap slots.

First suppose one gap contains both slots, call them
\(g_E,g_O\) in cycle order. They are consecutive on \(C\),
so \(g_Eg_O\notin M\). Both gaps have even length, hence
\(B_1\) starts with an \(O\) slot and ends with an \(E\)
slot. Call those slots \(a_O,a_E\). They are free:
all eligible even positions of \(B_1\) hold the
\(\ell-1\) nonfinal \(L\) targets, whose following odd
positions hold the corresponding \(R\) targets by
Note 197; \(L_1\) lies in \(B_2\). These six vertices
are the complete set of free slots. The only possible
matching edge with both ends in one block is
\(a_Oa_E\). If \(k_1=0\), even this is forbidden
because its endpoints are consecutive on \(C\).

Suppose \(a_Oa_E\in M\). The remaining four slots have
colour order \(E,E,O,O\), namely \(e,g_E,g_O,o\),
regardless of which gap contains the pair. All their
matching edges are cross-atom and lie in one disk.
Noncrossing and bipartite parity force the nested pairs
\(eo,g_Eg_O\); the latter is a cycle edge, impossible.

Suppose \(a_Oa_E\notin M\). Then all six free-slot
matching edges lie in that disk. If the pair is in
\(G_0\), the free-slot order is
\[
e,g_E,g_O,a_O,a_E,o
\quad\text{with colours }E,E,O,O,E,O.
\tag{4}
\]
The possible mates of \(e\) are \(g_O,a_O,o\).
The first leaves the single slot \(g_E\) inside its
chord; the second encloses \(g_E,g_O\), which would
have to match each other; and the third encloses four
slots whose first \(g_E\) can match only \(g_O\) or
\(a_O\), giving respectively a forbidden cycle edge
or a single unmatched slot. Each case is impossible.

If the pair is in \(G_1\), the free-slot order is
\[
e,a_O,a_E,g_E,g_O,o
\quad\text{with colours }E,O,E,E,O,O.
\tag{5}
\]
The possible mates of \(e\) are \(a_O,g_O,o\).
The first leaves the four slots \(a_E,g_E,g_O,o\)
with the forced forbidden pair \(g_Eg_O\). The second
encloses three slots with unequal colour counts.
The third leaves \(a_O,a_E,g_E,g_O\); here \(a_O\)
can match \(a_E\) only in the excluded case, while
matching it to \(g_E\) encloses the unmatched
\(a_E\). Again there is no matching.

Finally suppose \(t_0=t_1=1\). The first singleton gap
reverses \(B_1\)'s slot parity, and the second restores
the forward parity in \(B_2\). Saturation fills the
eligible positions \(3,5,\ldots,2k_1+1\) of \(B_1\)
with \(L_\ell,\ldots,L_2\). Target order then places
the corresponding \(R\) targets in positions
\(4,6,\ldots,2k_1+2\). Thus its first two slots,
call them \(a_E,a_O\), are free and consecutive on \(C\).
For \(k_1=0\), both are free directly. With gap slots
\(g_0,g_1\), the complete free-slot colour order is
\[
e,g_0,a_E,a_O,g_1,o
\quad\text{with colours }E,E,E,O,O,O.
\tag{6}
\]
Every possible free-slot matching edge lies opposite the
face, because the only same-block candidate \(a_Ea_O\)
is already a cycle edge. In a noncrossing bipartite
matching of the order \(E,E,E,O,O,O\), the first slot
must match the last, the second the fifth, and the third
the fourth: any shorter first chord encloses an unequal
number of the two colours. The forced last pair is
\(a_Ea_O\), impossible. This exhausts the gap
distributions and contradicts (2). \(\square\)

The theorem rules out one configuration at the first
non-equality boundary; it does not prove Hamiltonicity
when the surplus pair lies inside a block, when \(r>1\),
or for arbitrary Barnette graphs.
