> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Retained-edge pairs require joint decorated traversals

Let \(G\) be a Barnette graph with the global \(H^{+-}\)-property, let

\[
p=uv,\qquad q=xy
\]

be a legal \(C_4\)-expansion site, and put

\[
R=E(G)\setminus\{p,q\}.
\]

Use the six liftable traversal types

\[
\mathcal T=\{A,B,C,D,E,L\}
\]

from Notes 013--015.  For a concrete traversal witness \(W\), write
\(R(W)\subseteq R\) for its retained-edge support.  This note records an
additional joint condition that cannot be recovered from the one-edge
decorated sets in Note 015.

## Exact retained--retained condition

For distinct \(r,s\in R\), define

\[
\mathcal T^{+-}_{r,s}
=\{\tau\in\mathcal T:
\text{some concrete \(\tau\)-witness \(W\) has }
r\in R(W),\ s\notin R(W)\}.
\tag{1}
\]

Every lift of \(W\) preserves all retained-edge incidences.  Conversely,
every Hamilton cycle of the child restricts to one of the six traversal
types.  Hence the child has global \(H^{+-}\) on ordered pairs in
\(R\times R\) if and only if

\[
\boxed{
\mathcal T^{+-}_{r,s}\ne\varnothing
\quad\text{for all distinct }r,s\in R.
}
\tag{2}
\]

The parent property alone does not give (2).  Its separating Hamilton
cycle may avoid both \(p\) and \(q\).  Such a state-\(00\) cycle is a
nonliftable witness \(Z\): it separates \(r\) from \(s\) in \(G\), but it
leaves the new gadget as a disjoint component after expansion.

## One-edge decorated data are insufficient

The failure is already visible in a common-boundary incidence model on
\(p,q,r,s\).  Take the following parent Hamilton-cycle supports:

\[
\begin{array}{c|cc}
 &\text{first support}&\text{second support}\\ \hline
A&\{p,q\}&\{p,q,r,s\}\\
B&\{p\}&\{p,r,s\}\\
C&\{q\}&\{q,r,s\},
\end{array}
\tag{3}
\]

and add two nonliftable state-\(00\) supports

\[
Z_r=\{r\},\qquad Z_s=\{s\}.
\tag{4}
\]

The eight supports (3)--(4) separate every ordered pair of distinct
elements of \(\{p,q,r,s\}\).  Thus this projection has the parent
global-\(H^{+-}\) incidence property.

For each of \(D,E,L\), and likewise for the retained part of each row in
(3), take two concrete traversal witnesses whose retained supports are

\[
\varnothing\qquad\text{and}\qquad\{r,s\}.
\tag{5}
\]

Then all six traversal types are nonempty.  Moreover, for each of \(r,s\),
both its containing-role set and its avoiding-role set are the whole of
\(\mathcal T\).  Consequently every positive and negative one-edge cover
from Note 015 holds with maximal slack.  Nevertheless no liftable witness
contains \(r\) and avoids \(s\), so

\[
\mathcal T^{+-}_{r,s}=\varnothing.
\tag{6}
\]

Thus neither the six unadorned traversal types nor all one-edge decorated
marginals determine the retained--retained block.  A proof must retain the
joint incidence of two old edges in one concrete witness.  The model is an
incidence obstruction, not an actual cubic planar graph and hence not a
counterexample to preservation.

## The condition is already active in the cube

Consider the conventionally labelled cube with edge set

\[
\{01,03,04,12,17,23,26,35,45,47,56,67\}
\]

and legal site

\[
(u,v,x,y)=(0,1,7,4),\qquad p=01,\quad q=47.
\tag{7}
\]

For the ordered retained pair

\[
r=12,\qquad s=35,
\tag{8}
\]

enumeration of the cube's six Hamilton cycles gives exactly one cycle
containing \(r\) and avoiding \(s\):

\[
0-3-2-1-7-6-5-4-0.
\tag{9}
\]

It avoids both \(p,q\), so it is precisely a nonliftable \(Z\)-cycle.
The child separation is instead supplied by either of the spanning cross
paths

\[
1-2-3-0-4-5-6-7,
\qquad
0-3-2-1-7-6-5-4.
\tag{10}
\]

They have types \(D=X_{vx}\) and \(E=X_{uy}\), respectively, and both
contain \(r\) while avoiding \(s\).  Hence the new joint condition is not
merely an artificial obstruction: it is already used by the smallest
Barnette root, although the cube satisfies it.

## Corrected preservation interface

For an arbitrary legal \(C_4\)-expansion, parent global \(H^{+-}\) reduces
child global \(H^{+-}\) to three genuinely decorated requirements:

1. all six traversal types exist, equivalently the new--new block holds;
2. the one-edge positive and negative covers of Note 015 hold for every
   retained edge, equivalently the two mixed blocks hold;
3. the joint condition (2) holds for every ordered pair of retained edges.

The matching-connectivity conditions for \(D,E,L\) in Note 015 address the
first item, and its decorated cofacial rerouting normal forms address the
second.  They do not imply the third at the incidence level.  Therefore an
arbitrary \(C_4\)-preservation theorem must also prove a two-edge decorated
rerouting statement, or find a stronger common mechanism that produces all
three items simultaneously.

[Note 019](019-state-00-chord-rerouting-requires-a-nonlocal-decorated-connector.md)
classifies the direct reroutings from a state-\(00\) separator. The two
site chords and the whole ordinary perfect-matching closure can fail the
required pair incidence even in a real global-\(H^{+-}\) Barnette graph;
the first adequate rescue is a nonlocal decorated alternating terminal
connector with connected complement.

The finite calculation and the cube check are reproduced by

```text
python3 units/barnette/scratch/worker-c4-hpm/verify_mixed_decorated_separation_boundary.py
```

with terminal marker

```text
MIXED_DECORATED_SEPARATION_BOUNDARY_VERIFIED
```
