> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every isolated two-vacancy corridor has a marked Hamilton cycle

[Note 220](220-two-vacancy-free-groups-have-only-three-boundary-states.md)
shows that an isolated two-vacancy free group has no same-block
free chord, no noncanonical edge between ordinary slots, and
at most two missing edges of the ordinary chain. Those facts
allow a complete Hamilton decision for every corridor length.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), no interblock gaps, tight target order and
precisely two eligible vacancies. Suppose they lie in distinct
target-free four-slot face blocks \(B_k,B_m\),
\(1\le k<m\le r\), and their entire common free group is
\[
e_{k-1},(o_k,h_k,i_k,e_k),
(o_{k+1},e_{k+1}),\ldots,(o_{m-1},e_{m-1}),
(o_m,h_m,i_m,e_m),o_{m+1}.                    \tag{1}
\]
Thus every intermediate face block is short. Other free
groups may contain occupied target runs but no vacancy.

**Isolated-corridor Hamilton theorem.** The parent has a
Hamilton cycle containing both site edges \(q=xy,p=uv\).
Its legal site-expanded child is Hamiltonian. The conclusion
holds for every \(m-k-1\ge0\) and arbitrary positive
original square-trap lobe lengths.

**Proof.** Let \(A\) be the even-starting old-cycle
matching from \(x\). Tight target order makes the
target-and-square path (4) of Note 196. Away from (1),
every ordinary free group has the forced chain of Note 208.
Inside (1), call \(P_j=(E_j,O_j)=(e_j,o_{j+1})\),
\(k-1\le j\le m\), the ordinary chain links.
Write \(X=(H_X,I_X)=(h_k,i_k)\) and
\(Y=(H_Y,I_Y)=(h_m,i_m)\) for the two vacancy
pairs. In free-slot order \(H_X<I_X<H_Y<I_Y\).
The port pairs \(P_j\) occur in increasing \(j\);
\(P_{k-1}\) is before \(X\), \(P_m\) after \(Y\),
and all other \(P_j\) between \(X,Y\).

By Note 220 every free matching edge between ordinary
slots is a retained chain link. Let \(c\) count its
matching edges between vacancy slots. Exactly \(2-c\)
chain links are missing, by Note 220, equation (5).
The only possible vacancy-to-vacancy matching edges are
\(H_XI_Y\) and \(I_XH_Y\): the within-block pairs
\(H_XI_X,H_YI_Y\) are old-cycle edges.

If \(c=2\), both cross-block edges occur, no chain link
is missing, and Note 217's even-ladder absorption
turns the separate alternating square into one marked
Hamilton cycle.

Suppose \(c=1\), and write \(P_s=(E_s,O_s)\) for the
unique missing chain link. The edge \(I_XH_Y\) cannot
be the vacancy-to-vacancy edge. If \(P_s=P_{k-1}\),
the required edge \(H_XO_s= h_ko_k\) is an old-cycle
edge; if \(P_s=P_m\), the required
\(I_YE_s=i_me_m\) is an old-cycle edge. Otherwise
\(P_s\) lies between \(X,Y\), and the required
chords \(H_XO_s\) and \(I_XH_Y\) interlace in the
opposite-side disk. Hence the vacancy edge is
\(H_XI_Y\). The other two matching edges must be
\(E_sI_X,O_sH_Y\). Replace the ordinary free-path
edge \(E_sO_s\) by
\[
E_s,I_X,H_X,I_Y,H_Y,O_s.                       \tag{2}
\]
Its first, middle and last non-\(A\) edges belong to
\(M\), and \(I_XH_X,I_YH_Y\in A\). This visits
all four vacancy slots exactly once and leaves one
spanning free path.

Finally suppose \(c=0\). Let \(a<b\) be the two
missing chain-link indices. Their four ordinary
endpoints \(E_a,O_a,E_b,O_b\) match the four
vacancy slots. Each vacancy pair becomes an
alternating path joining one \(E\)-port to one
\(O\)-port. We claim each missing chain link is
reconnected to itself, so the two replacements are
independent. If not, there are two possible
*crossed reconnections*:
\[
\begin{array}{c|cc}
&X&Y\\
\mathrm{I}&E_a\longleftrightarrow O_b&
              E_b\longleftrightarrow O_a\\
\mathrm{II}&E_b\longleftrightarrow O_a&
               E_a\longleftrightarrow O_b .
\end{array}                                               \tag{3}
\]
Here a vacancy path joins its \(E\)-port through its
\(I\)-slot and its \(O\)-port through its \(H\)-slot.

Type I is impossible. If \(P_a\) precedes \(X\),
then \(E_a<O_a<H_X<I_X<H_Y\), so the matching
chords \(E_aI_X\) and \(O_aH_Y\) interlace.
Otherwise \(P_a\) lies between \(X,Y\). If \(P_b\)
also lies there, then
\(H_X<O_a<O_b<H_Y\), so \(H_XO_b\) and
\(O_aH_Y\) interlace. If \(P_b\) follows \(Y\),
it is \(P_m\), and its required edge
\(I_YE_b=i_me_m\) is an old-cycle edge.

Type II is impossible as well. If \(P_a\) precedes
\(X\), it is \(P_{k-1}\), and its required edge
\(H_XO_a=h_ko_k\) is an old-cycle edge.
Otherwise \(P_a\) lies between \(X,Y\); then
\(H_X<I_X<O_a<E_b\), so \(H_XO_a\) and
\(I_XE_b\) interlace. There are no other
relative positions because only \(P_{k-1}\)
precedes \(X\) and only \(P_m\) follows \(Y\).
Thus crossed reconnection is impossible.

Each vacancy pair therefore reconnects one of
\(P_a,P_b\) to itself. Replace each missing free
path edge \(E_jO_j\), using its assigned vacancy
pair \((H,I)\), by
\[
E_j,I,H,O_j.                                  \tag{4}
\]
Its two outer edges are in \(M\), and \(IH\in A\).
The replaced chain edges and the two vacancy pairs
are disjoint, so the replacements commute and give
one spanning free path.

In all three cases this free path meets the unchanged
target-and-square path only at \(x,v\); their union
is a Hamilton cycle containing \(xy,uv\). Note 001
lifts it through the legal site expansion, and
Note 178 restores the original lobe lengths.
\(\square\)

This theorem closes every tight, gapless, all-square
opening at \(f=4r+6\) whose two vacancies lie in
different target-free face blocks and form the isolated
group (1). It does not cover vacancies in the same
block, a group with additional short blocks outside
the two vacant blocks, outer-block vacancies, target
order defects, gap slots or nonsquare residual cycles.
[Note 223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
later removes the no-flank restriction for the two
distinct target-free face blocks.
