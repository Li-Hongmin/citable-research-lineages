> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every one-left-flank `tJ` single–double corridor has an exact square reduction

[Note 391](391-a-left-outer-return-of-the-single-double-corridor-has-the-square-signature.md)
settles one nonstandard left-wing return of the `tJ` single–double
corridor. The other return contains a reflected cube fold. Together
with the older fold of [Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md),
these exhaust the `tJ` branch with one left short block.

Use the compressed, gapless, tight-target all-square selected opening.
Let one ordinary target-free free group have blocks
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\qquad m\ge1,                  \tag{1}
\]
in this old-cycle order, with no short block after \(D\). Let \(t,z\)
be its even left and odd right free endports, and assume \(tJ\in M\),
where \(M\) complements the selected old Hamilton cycle. Other free
groups and their matchings are unrestricted.

**One-left-flank theorem.** Every actual matching under these
hypotheses contains an induced disk patch, strictly larger than a
square, whose complete four-terminal spanning Hamilton signature
is exactly that of a square. Replacing the patch by its labeled
square, or reversing the replacement, preserves Barnette membership
and every exterior- and attachment-marked Hamilton decision. Hence
no vertex-minimal non-Hamiltonian Barnette graph can contain one of
these patches. More precisely:

1. If \(iK\in M\), the patch is \(S_0\cup V\), the ten-vertex
   cube fold of Note 315.
2. If \(pK,qo\in M\), the patch is the entire interval (1),
   by Note 391.
3. If \(pK,qI\in M\), the patch is \(V\cup S_1\cup\cdots\cup S_r\)
   for a uniquely determined \(1\le r\le m\). Compressing the
   ordinary-link run to one square and applying the reflected
   Note 315 fold reduces it to a square.

Old-cycle reflection gives the corresponding theorem with exactly
one short block after the singly vacant block and none before the
doubly vacant block.

**The double block has no internal free chord.** The chord \(tJ\)
forces \(Ez\), since these are the only two free slots to its right.
Thus \(OE,IE,HJ\) are unavailable. Suppose \(OK=J_1\) occurs.
The chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
places \(OK\) on the common-face side. All cross-block free chords
lie on the opposite side by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
The even slot \(H\) can meet only \(p,o,i\), or some \(p_j\):
\(O,H\) and \(H,I\) are old-cycle edges, \(HJ\) is unavailable,
and any chord to \(z\) would cross \(tJ\). In the free-slot order
\[
 t,p,q,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,O,H,I,K,J,E,z,    \tag{2}
\]
the open intervals of \(pH,oH,iH,p_jH\) contain respectively
\(2m+6,2m+4,2m+2,2(m-j)+2\) free slots. Each has exactly one
endpoint of the face-side \(OK\) chord inside. The optional
face-side \(oe\) lies wholly inside the first interval, is
unavailable for \(oH\), and lies wholly outside the last.
The interval-parity rule excludes \(pH,oH,p_jH\). It excludes
\(iH\) unless \(oe\) supplies a second face-side exit through
\(e\). In that remaining case every free slot of the nonempty
complete corridor \(S_1,\ldots,S_m\) is forced to match within
that corridor: its cross-block chords cannot cross \(iH\), while
\(e,O\) are matched across the interval boundary. Its two
boundary old-cycle edges would form a forbidden two-edge cut.
Thus \(H\) has no mate, excluding \(OK\). No internal free chord
of \(D\) remains.

**The first mate of \(K\).** Inside \(tJ\), the even slot \(K\)
can meet only \(p,o,i,p_j\) or \(O\). The last is excluded above;
\(K I,K J\) are old-cycle edges. An edge \(p_jK\), \(j\ge1\),
would separate the complete interval \(S_0,V,S_1,\ldots,S_{j-1}\)
from the remaining free slots inside \(tJ\). Any opposite-page
matching edge leaving this interval would cross \(p_jK\);
its face chords remain internal. Hence it would be
matching-closed and give a
two-edge cut. The choice \(oK\) leaves \(p,q\) before it but
inside \(tJ\); they would have to match each other, yet \(pq\)
is an old-cycle edge. Thus \(K\) meets \(i\) or \(p\).

If \(iK\) occurs, the four still-free slots \(p,q,o,h\) before
\(iK\) must match among themselves. The optional \(oe\) would
give exactly one face-side exit from these four slots, violating
parity. Without it the only legal perfect matching is
\(ph,qo\): the alternatives \(pq,oh\) are old-cycle edges and
\(po,qh\) join equal colours. The edges \(da,ph,qo\) give
exactly the ten-vertex patch of Note 315,
on \(S_0\cup V\), with terminals \((c,i,e,b)\). Its reduction
does not depend on any other matching choice.

Suppose henceforth \(pK\in M\). The even slot \(q\) can meet
\(o,i,p_j,O,I\) within \(pK\). The chord \(qi\) traps the
old-cycle pair \(o,h\); if \(oe\) occurs, it gives a single
face-side exit and still violates parity. A chord \(qp_j\),
\(j\ge1\), would match-close the complete interval
\(V,S_1,\ldots,S_{j-1}\); \(qO\) would do so to
\(V,S_1,\ldots,S_m\). Both are forbidden two-edge cuts.
Consequently \(q\) meets \(o\) or \(I\). The first case is
Note 391. We classify the second case next.

**The \(qI\) return.** Assume \(pK,qI\in M\). Inside \(qI\),
the odd slot \(o\) can meet \(e,q_s\ (1\le s\le m)\), or \(H\).
If \(oe\) occurs, its chord is on the common-face side.
Every possible mate \(p_s\) or \(O\) of \(h\) then gives an
opposite-side interval containing an even number of free
slots and the single face-side exit \(e\); parity excludes it.
All other mates of \(h\) are used, old-cycle neighbours, or
outside \(qI\). Thus \(oe\) is impossible. If \(oq_s\) occurs,
all matching edges of the complete interval \(V,S_1,\ldots,S_s\)
stay within that interval: \(oq_s\) bounds its free slots on
the opposite page, while every face-side chord stays internal.
This gives a forbidden two-edge cut. Hence
\[
                              oH\in M.                    \tag{3}
\]

Now \(h\) can meet only \(O\) or a short-block slot \(p_s\).
If \(hO\) occurs, the odd slot \(i\) must meet some \(q_r\).
Were \(r<m\), the complete suffix \(S_{r+1},\ldots,S_m\)
would be matched internally between \(iq_r\) and \(hO\), a
two-edge cut. Thus \(iq_m\), and noninterlacement plus the
same cut rule force
\[
       ep_1,\quad q_jp_{j+1}\ (1\le j<m).              \tag{4}
\]
Set \(r=m\) in the theorem's third case.

Otherwise \(hp_s\) occurs. It has \(s\ge2\): \(hp_1\)
would trap the forbidden old-cycle pair \(i,e\). Inside
\(hp_s\), the odd slot \(i\) must meet \(q_k\) with \(k<s\).
If \(k<s-1\), the intervening complete short blocks are
matching-closed. Thus \(iq_{s-1}\) is forced. The leftmost
free slot inside that chord is \(e\); a mate beyond \(p_1\)
would close a complete short-block prefix. Therefore
\[
       ep_1,\quad q_jp_{j+1}\ (1\le j<s-1).            \tag{5}
\]
On the other side of \(hp_s\), the odd slot \(O\) must meet
some \(q_k\) with \(k\ge s\). Skipping a final short-block
suffix gives the same two-edge-cut contradiction, so
\(q_mO\) and \(q_jp_{j+1}\) for \(s\le j<m\) are forced.
Set \(r=s-1\). Equations (4)–(5) and the latter links
classify every \(qI\) matching; the mate of \(h\) determines
its branch and \(r\) uniquely.

**The reflected cube fold.** In either \(qI\) branch put
\(P_r=V\cup S_1\cup\cdots\cup S_r\), where \(r=m\) for
\(hO\) and \(r=s-1\) for \(hp_s\). The only matching
edges with both ends in \(P_r\) are exactly
\[
             ep_1,\quad iq_r,\quad
             q_jp_{j+1}\ (1\le j<r),                    \tag{6}
\]
besides its face-closing chords. Its four degree-two
terminals, in disk order, are \((a,o,h,d_r)\). All four
attachment edges are distinct: the old edges at \(a,d_r\)
and the matching edges \(oH,hO\) or \(oH,hp_s\). For
\(r=1\), the bridges from \(V\) to \(S_1\) are
\(bc_1,ep_1,iq_1\), exactly the old-cycle reflection of
the ten-vertex cube-fold patch of Note 315. For general
\(r\), \(S_1,\ldots,S_r\) is the induced even-column
four-terminal ladder of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Compress it to one square with its four labeled attachments,
then apply the reflected Note 315 fold. Both steps preserve
the complete Hamilton linkage signature and all exterior
decisions. Note 178 preserves Barnette membership in both
directions; the Note 315 fold preserves it in the reverse
direction, and the known cube expansion preserves it in the
forward direction, as restated in Gorsky–Steiner–Wiederrecht
(2023, Section 5, Theorem 5.1). Therefore \(P_r\) is an
exact square reduction in any Barnette host. \(\square\)

This theorem settles the `tJ` first-mate branch with one short
left flank and no right flank, at arbitrary positive internal
corridor length. It does not classify the `to` branch, more than
one nonstandard left flank, a nonstandard right flank at the
same time, other free-group shapes, or other opening types.
It does not decide the general Barnette conjecture. The proof
is project-internal and has not had independent external review
or a complete literature priority comparison.
