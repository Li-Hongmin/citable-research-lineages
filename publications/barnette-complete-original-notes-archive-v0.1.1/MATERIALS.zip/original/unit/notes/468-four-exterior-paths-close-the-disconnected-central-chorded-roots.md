> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four exterior paths close disconnected central chorded roots

[Note 467](467-a-trap-chord-cycle-closes-connected-central-chorded-roots.md) closes a chorded all-leaf profile when all ordinary roots lie between \(z_L,z_R\) and their face graph is connected. With exactly two such roots, the disconnected face graph leaves exactly two special terminals per root. Explicit exterior four-path covers and the open-root square signature close all three root placements.

Use the chorded single-hexagon order and notation of [Note 466](466-the-chorded-100-vertex-frontier-has-two-leaf-roots-and-two-exterior-face-chords.md): the outside markers are \(z_L,t_c,t_b,z_R\), with face chords \(z_Lr_L,z_Rr_R\), site edges \(q=w_0u,p=vw_*\), internal hexagon chord \(ad\), trap chord \(\alpha\beta\), and two nonempty ordinary roots \(W_1<W_2\). Every assigned special position is in a two-special leaf; the four root terminals \(T=\{r_L,u,v,r_R\}\) are distinct. Suppose both roots lie between \(z_L,z_R\), with at least one between \(t_c,t_b\).

**Central two-root theorem.** The parent has a Hamilton cycle containing both site edges, whether or not the root face graph \(K\) is connected. Therefore its legal expanded child is Hamiltonian.

**Proof.** The connected-\(K\) case is [Note 467](467-a-trap-chord-cycle-closes-connected-central-chorded-roots.md). Suppose \(K\) is disconnected. Each even root word has an edge cut consisting of its two old boundary edges and its special attachments to the site or exterior face chords. No face chord joins the roots. Cubicity makes the cut even; three-connectivity makes it at least four. There are four such special attachments in total, so each root has exactly two. All other face matching chords stay within their root.

Open each root at its outer ordinary chord, leaving the old arc from \(W_{i,\ell}\) to \(W_{i,r}\). Delete the square-supported leaf old edges and insert that root's internal face matching. The result has degree one exactly at its two boundary ends and two special terminals. Its component quotient by the deleted leaf edges is connected, and every nonloop quotient edge has its unused leaf-square chord. The spanning-tree argument of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) yields spanning two-path covers in at least two different pairings of the four terminals of each root.

There are three possible placements of the two roots. In each display below the four paths are mutually vertex-disjoint, contain both site edges between them, and cover exactly all vertices outside the two root words. Their endpoints are the eight root terminals.

If \(W_1\) lies between \(z_L,t_c\) and \(W_2\) between \(t_c,t_b\), use
\[
\begin{array}{ll}
(W_{1,\ell},z_L,r_L),&
(u,w_0,\beta,\alpha,a,d,c,b,t_b,W_{2,r}),\\
(W_{1,r},t_c,W_{2,\ell}),&
(r_R,z_R,w_*,v).
\end{array}
\tag{1}
\]
The \(ad\) step is the internal chord, \(\alpha\beta\) the trap chord, and \(bt_b\) the escape edge. The steps \(W_{1,\ell}z_L,W_{1,r}t_c,t_cW_{2,\ell},t_bW_{2,r},z_Rw_*\) are old-cycle edges.

If both roots lie between \(t_c,t_b\), use
\[
\begin{array}{ll}
(r_L,z_L,w_0,u),&(r_R,z_R,w_*,v),\\
(W_{1,\ell},t_c,c,d,\beta,\alpha,a,b,t_b,W_{2,r}),&
(W_{1,r},W_{2,\ell}).
\end{array}
\tag{2}
\]
The two escapes \(t_cc,t_bb\) and the trap chord \(\beta\alpha\) are the non-old steps of its long path. The placement with \(W_1\) between \(t_c,t_b\) and \(W_2\) between \(t_b,z_R\) is the reflection of (1), using the symmetry \((w_0,z_L,t_c,c,d,\beta,u)\leftrightarrow(w_*,z_R,t_b,b,a,\alpha,v)\) of the chorded hexagon and its chord \(ad\).

In any of these displays, two or four of the exterior paths join different roots: each root has four terminals, so the number of crossing paths is even, and the displayed boundary-to-boundary path makes it positive. If there are two crossing paths, the other two exterior paths pair the remaining two terminals within each root. Choose an available internal pairing different from that within-root exterior pair at each root; the union is one cycle. If all four exterior paths cross, use the exterior paths to identify the four terminals of one root with those of the other, and choose internal pairings that differ under this identification; their union is one cycle. The internal covers span both roots, the exterior paths span every other vertex, and all constructions retain \(p,q\). [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the cycle to the child. \(\square\)

By Note 466, a 100-vertex chorded reduced failure must have exactly two all-leaf roots. The theorem closes the three placements in which both roots lie between \(z_L,z_R\). Any surviving equality profile must put its second root before \(z_L\) or after \(z_R\); these two end placements are reflected. This is a necessary location, not a Hamiltonicity decision for the end placement or for Barnette graphs in general.
