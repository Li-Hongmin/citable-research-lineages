> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two exterior pairings close the chorded single-unary defect

[Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md) closes a marked unary node when its two directly assigned special positions are adjacent. When they straddle its unique child, there are two natural ways to open the containing ordinary cycle. The internal opening need only yield one spanning two-path cover: the internally chorded hexagon supplies two different exterior pairings.

Use the chorded single-hexagon order from [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md):
\[
                         w_0,z_L,t_c,W,t_b,z_R,w_* ,
\tag{1}
\]
followed on the old cycle by \(w_*,\alpha,a,b,c,d,\beta,w_0\). The hexagon has matching chord \(ad\), trap chord \(\alpha\beta\), and escape edges \(t_cc,t_bb\). The inner site ports \(u<v\) and exterior face-chord mates \(r_L< u<v<r_R\) lie in the one ordinary root \(W\). Every assigned special position lies either in a two-special leaf or is one of two positions \(s,t\) assigned directly to a single marked unary node \(N\). Let \(A\) be the only child word of \(N\). All ordinary wrapper lengths are allowed.

**Chorded single-unary theorem.** Under these conditions the parent has a Hamilton cycle containing both site edges. Consequently its legal \(C_4\)-expanded child is Hamiltonian.

**Two exterior pairings.** The vertices outside \(W\) have the following two spanning two-path covers, each containing \(q=w_0u\) and \(p=vw_*\):
\[
\begin{array}{lll}
\mathcal E_1:&(r_L,z_L,t_c,c,d,\beta,w_0,u),&
              (r_R,z_R,t_b,b,a,\alpha,w_*,v),\\
\mathcal E_2:&(r_L,z_L,t_c,c,d,a,b,t_b,z_R,r_R),&
              (u,w_0,\beta,\alpha,w_*,v).
\end{array}                                                   \tag{2}
\]
The \(d a\) step of \(\mathcal E_2\) is the internal hexagon chord; its \(\beta\alpha\) step is the trap chord. Every other non-old step in (2) is a stated face, escape, or site edge. The two terminal pairings are
\[
             (r_Lu)(r_Rv),\qquad (r_Lr_R)(uv).
\tag{3}
\]
Thus *any* spanning internal two-path cover of \(W\) with terminals \(r_L,u,v,r_R\) closes with at least one cover in (2) to a Hamilton cycle.

If \(s,t\) occur on the same side of \(A\), they are consecutive and the one-unsupported-edge theorem of Note 459 gives an internal two-path cover. Suppose henceforth the order in \(N\) is
\[
                              H,s,A,t,J,
\tag{4}
\]
with ordinary chord \(HJ\). Write \(L,R\) for the first and last vertices of \(A\), so \(LR\) is its ordinary root chord and \(sL,Rt\) are old-cycle edges. Let \(E\) be the old \(x_i y_i\) edge in each two-special leaf. Let \(C_W\) be the cycle consisting of the whole old \(W\)-arc and its root chord, and let \(M\) match all special positions other than the four terminals. The square supports of \(E\) are disjoint, as in [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md).

Open \(C_W\) at \(sL,Rt\), remove all \(E\), insert \(M\), and insert the child chord \(LR\):
\[
                F_{\rm in}
                 =(C_W-E-\{sL,Rt\})\cup M\cup\{LR\}.
\tag{5}
\]
Every nonterminal has degree two and the four terminals have degree one, so \(F_{\rm in}\) is two paths and some cycles. Add back the leaf edges \(E\), but not \(sL,Rt\). The result is connected precisely when some edge of \(M\) crosses from the vertex interval \(A\) to \(W\setminus A\): the old cycle with those two edges deleted consists of exactly the \(A\)-arc and its complementary arc, and \(LR\) is internal to \(A\). If it is connected, the leaf-square switches of Note 458 absorb all cycles into two paths, giving the required internal cover. If \(A\) itself is one leaf, \(LR\) may already be its square chord; then its deleted leaf edge is a quotient loop and requires no switch.

Suppose no edge of \(M\) crosses the boundary of \(A\). Let \(k\) be the number of the four terminals in \(A\). The interval \(A\) has even order; its cut in the cubic parent consists of the two old boundary edges and its \(k\) terminal attachment edges. Three-connectivity and cut parity imply \(k=2\) or \(4\).

If \(k=2\), each of the two arcs in (5) contains exactly one path component. Within each arc, its leaf edges connect every cycle component to that path component. Square switches absorb those cycles separately, leaving two spanning paths and hence the required internal cover.

If \(k=4\), then \(s,t\) are nonterminals matched by \(M\) outside \(A\). They cannot be matched to one another: the face chord \(st\) would interlace the exterior face chord \(z_Lr_L\), since \(z_L<s<r_L<t\). Consequently an \(M\)-edge from \(s\) or \(t\) leaves the interval \([s,t]\). There is no assigned special position in \(N\setminus A\) other than \(s,t\), so its mate lies outside \(N\); in particular \(N\) is not the root of \(W\), and its ordinary chord \(HJ\) is unused by \(C_W\).

Use the second opening
\[
                F_{\rm out}
                 =(C_W-E-\{Hs,tJ\})\cup M\cup\{HJ\}.
\tag{6}
\]
It again has degree one precisely at the four terminals. After the leaf edges \(E\) are restored, the \(M\)-edge just identified joins the two old arcs separated by \(Hs,tJ\), so the component quotient using only the leaf edges is connected. Apply the leaf-square switches to absorb all cycles into two paths. If a square chord coincides with the inserted \(HJ\), its leaf edge is a loop and is not needed; here \(N\) is nonleaf, so in fact no such coincidence occurs. This supplies the internal cover also when \(k=4\). Combining it with (2) proves the theorem. \(\square\)

**Improved chorded kernel bound.** Let \(f\ge7\). A non-Hamiltonian doubly ladder-reduced chorded single-hexagon child satisfies
\[
                  c\le5f-6,\qquad
                  |V(\bar G^+)|=16+2f+2c\le4+12f .
\tag{7}
\]
Indeed, [Note 415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md) gives \(m\le f\) and \(c\le2(M_0+L)+m-3R\). The cases \(m\le f-1\) and \(m=f,R\ge2\) give \(c\le5f-8\) and \(c\le5f-6\), respectively. If \(m=f,R=1\), the all-leaf case \(M_0=L=f\) is Hamiltonian by Note 458. If \(M_0+L\le2f-2\), the charge gives \(c\le5f-7\). The remaining equality \(M_0+L=2f-1\) has \(M_0=f,L=f-1\), hence one nonleaf marked node and every assigned pair at a distinct marked node. At \(c=5f-5\), equality in \(c\le3A-Q\le3(M_0+L-R)-L\) forces \(A=2f-2\). There are \(L-R=f-2\) binary branches, and none coincides with the nonleaf marked node; that node is therefore unary. The theorem above makes the child Hamiltonian. Hence \(c\le5f-6\). At \(f=8\), the chorded branch is bounded by 100 reduced child vertices; a 102-vertex single-hexagon failure kernel, if any, must be chord-free and have the split marked unary node of Note 459.

The result concerns selected chorded single-hexagon openings and their legal expansions. It does not establish Hamiltonicity of all 100-vertex kernels or of all Barnette graphs.
