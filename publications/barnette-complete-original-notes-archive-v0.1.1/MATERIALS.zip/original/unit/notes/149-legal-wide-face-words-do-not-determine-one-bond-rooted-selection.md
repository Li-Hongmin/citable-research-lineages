> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Legal-wide face words do not determine one-bond rooted selection

[Note 148](148-gate-path-sibling-rootedness-has-an-exact-circuit-partition-criterion.md)
reduces the short-gap preservation problem to a one-bond legal-wide
selection statement.  This note determines exactly what the cyclic word on
the common gate face contributes.  The answer is complete but negative:
the face word is a four-state shift of finite type and does not determine
global NAE extension, bond connectivity, or the rooted circuit partition.

The inherited root-opposite square already excludes the minimum sparse word
from every rooted target, with no brace or completeness hypothesis.  The
canonical double-wheel completion, whose dual is the octagonal prism, then
has two rather than one gate-changing bonds.  These are two distinct layers:
root separation removes the minimum word, while complete matching incidence
supplies additional compensation in the first symmetric completion.

## 1. Exact local language

Let \(z\) be the dual vertex of the common primal gate face, and write its
neighbours cyclically as

\[
v_0,v_1,\ldots,v_{n-1},\qquad n=2m.
\tag{1}
\]

Let \(\chi,\eta\) be the two NAE colourings associated with a parent bond.
After complementing either colouring if necessary, normalize

\[
\chi(z)=\eta(z)=0.
\tag{2}
\]

Put

\[
x_i=1-\chi(v_i),\qquad y_i=1-\eta(v_i).
\tag{3}
\]

The triangle \(zv_iv_{i+1}\) is NAE under \(\chi\) exactly when
\(x_i,x_{i+1}\) are not both one.  The analogous statement holds for
\(\eta\).  Hence the two rows are NAE on the whole fan at \(z\) if and only
if

\[
I_x=\{i:x_i=1\},\qquad I_y=\{i:y_i=1\}
\tag{4}
\]

are independent sets of \(C_n\).  Conversely every ordered pair of
independent sets gives two such local NAE rows.  There is no further local
constraint at the central face.

Encode position \(i\) by

\[
0=(0,0),\qquad M=(1,0),\qquad N=(0,1),\qquad B=(1,1).
\tag{5}
\]

In the order \(0,M,N,B\), consecutive symbols are governed by the exact
adjacency matrix

\[
A=
\begin{pmatrix}
1&1&1&1\\
1&0&1&0\\
1&1&0&0\\
1&0&0&0
\end{pmatrix}.
\tag{6}
\]

This proves the following classification.

> **Face-word theorem.**  The complete local data of two NAE rows around
> one gate face is precisely a cyclic word admitted by (6).  Every such
> word is realized on the same triangulated fan \(z*C_n\).

## 2. Legal-wide words and the minimum sparse shore

Place the forced gate \(g_0\) at position \(0\) and the surviving gate
\(g_1\) at position \(d\).  Orient the parent bond so that both matchings
contain \(g_0\), while only the first contains \(g_1\).  Then

\[
s_0=B,\qquad s_d=M.
\tag{7}
\]

The two closed gate arcs are odd and have at least five edges exactly when

\[
d\equiv n-d\equiv0\pmod 2,
\qquad d,n-d\ge4.
\tag{8}
\]

Consequently a legal-wide face word is exactly the gluing of two allowed
\(B\)-to-\(M\) walks of lengths \(d\) and \(n-d\) in (6).  If

\[
a_k=(A^k)_{B,M},
\tag{9}
\]

then the number for fixed \(n,d\) is \(a_da_{n-d}\), where

\[
a_0=a_1=0,\qquad a_2=1,
\qquad
a_k=2a_{k-1}+2a_{k-2}-a_{k-3}\quad(k\ge3).
\tag{10}
\]

The recurrence is the characteristic recurrence of the \(B\)-to-\(M\)
entry of (6).

The first permitted face is \(C_8\), with \(d=4\).  There are six allowed
half-words and therefore \(36\) oriented full words.  The unique word of
minimum total matching occupancy is

\[
\boxed{B000M000}.
\tag{11}
\]

For (11),

\[
I_x=\{0,4\},\qquad I_y=\{0\},
\qquad
W\cap N_T(z)=\{v_4\},
\tag{12}
\]

where \(W=\{v:\chi(v)\ne\eta(v)\}\) is the shore.  Thus legal-wide
rotation alone does not force a second shore crossing, an alternating
occupied arc, a second parent bond, or an occupied portal of the kind used
in [Notes 146--147](146-an-occupied-domino-portal-forces-short-gap-child-compensation.md).

This is a local information statement, not a graph counterexample.  A row
admitted at the fan may fail to extend through the exterior.  Even a global
NAE extension may fail to give a bond because one shore is disconnected;
and even a bond may fail the rank and labelled-root tests of
[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md).
The exact hierarchy is therefore

\[
\boxed{
\text{gate-face NAE}
<\text{global NAE extension}
<\text{bond-shore connectivity}
<\text{root admission}.}
\tag{13}
\]

The site state at \(p,q,h\) and the circuit quotient of Note 148 lie still
farther outside the face word.

## 3. The root square excludes the minimum word

Let

\[
Q=u-v-x-y-u
\tag{14}
\]

be the inherited facial root square, with opposite matching edges

\[
e=uv,\qquad g_0=xy.
\tag{15}
\]

Let \(F\ne Q\) be the other face incident with \(g_0\).

> **Root-square face-occupancy lemma.**  If \(N\) is a rooted target
> containing \(e,g_0\), then
> \[
> \boxed{N\cap\bigl(E(F)\setminus\{g_0\}\bigr)\ne\varnothing.}
> \tag{16}
> \]

Indeed, otherwise every edge of the \(x\)-to-\(y\) path \(F-g_0\) belongs
to \(G-N\).  Since \(e,g_0\in N\), the other two square edges \(uy,xv\)
also belong to \(G-N\).  Hence

\[
u-y\;(F-g_0)\;x-v
\tag{17}
\]

is a path in the complement joining the two endpoints of the root edge.
They would lie on the same complement cycle, contrary to rooted admission.

In the word \(B000M000\), the endpoint omitting \(g_1\) uses only \(g_0\)
on \(F\), so (16) gives the arbitrary-order exclusion

\[
\boxed{\text{no rooted pair has gate-face word }B000M000.}
\tag{18}
\]

Only root separation is used.  Planarity and the root-square incidence
identify the path (17); bipartiteness, 2-extendability, legal-wide arc
lengths, completeness of the target family, and uniqueness of the bond are
unnecessary.

The exclusion must not be overstated.  The shore records the XOR of the
two rows, so a shore meeting the gate face only at \(g_1\) may still have
additional common \(B\)-positions.  In fact this residual class has an
exact arbitrary-length description.

Let the gate face have length \(n\), with \(g_0\) at \(0\) and \(g_1\) at
\(d\).  Orient the singleton shore so that \(g_1\in M\setminus N\).  Then
the two incidence sets have the form

\[
I_N=S,\qquad I_M=S\cup\{d\},
\tag{19}
\]

where

\[
0\in S,\qquad S\text{ is independent in }C_n,\qquad
S\cap\{d-1,d,d+1\}=\varnothing.
\tag{20}
\]

Conversely every \(S\) satisfying (20) gives two local NAE rows with XOR
exactly \(\{d\}\).  Under the legal-wide inequalities (8), write

\[
S=\{0\}\mathbin{\dot\cup}S_A\mathbin{\dot\cup}S_B,
\quad
S_A\subseteq\{2,\ldots,d-2\},
\quad
S_B\subseteq\{d+2,\ldots,n-2\}.
\tag{21}
\]

The two displayed intervals are disjoint paths.  If \(F_0=0,F_1=1\), the
number of independent sets of a path on \(r\) vertices is \(F_{r+2}\).
Equation (16) deletes exactly the choice \(S_A=S_B=\varnothing\).
Therefore the number of locally root-square-admissible singleton-shore
words is

\[
\boxed{F_{d-1}F_{n-d-1}-1.}
\tag{22}
\]

For the minimum \(C_8\), this leaves precisely

\[
\boxed{
B0B0M000,\qquad
B000M0B0,\qquad
B0B0M0B0.}
\tag{23}
\]

For example,

\[
B0B0M000
\]

is locally admitted by (6), with incidence sets \(\{0,2,4\}\) and
\(\{0,2\}\).  Its shore intersection is still the singleton \(\{4\}\),
but the \(g_1\)-omitting endpoint now satisfies (16).  Thus the exact
consequence for a singleton shore is only

\[
\boxed{\text{singleton gate-face shore}
\Longrightarrow
\text{at least one additional common }B\text{-position}.}
\]

Excluding this residual class requires complete-family or exterior
information not present in the face word.

The information boundary here is exact.  In the two-face core \(Q\cup F\),
the only complement path which can join the root endpoints is (17).
With no extra \(B\)-position it survives intact; any extra common
\(B\)-edge deletes an edge of \(F-g_0\) and cuts it.  Whether the resulting
boundary fragments reconnect through the exterior into the prescribed two
root-separated complement cycles is precisely the fixed-pairing
two-linkage signature of [Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
It is not determined by \(Q\cup F\).

## 4. The canonical double-wheel completion supplies two bonds

The fan in (11) has a natural global Eulerian completion: add a second
apex adjacent to all eight rim vertices.  Its cubic bipartite dual is the
octagonal prism

\[
G_8=C_8\square K_2.
\tag{24}
\]

Use the notation of [Note 087](087-a-legal-wide-fibre-can-contain-a-nonminimum-atomic-two-switch.md):
top and bottom rim edges are \(T_i,B_i\), rungs are \(R_i\), and

\[
S_i=\{T_i,B_i,R_i,R_{i+1}\}.
\tag{25}
\]

By symmetry every eligible root-square legal-wide decoration is equivalent
to

\[
e=B_0,\qquad g_0=T_0,\qquad g_1=T_4.
\tag{26}
\]

The root and forced gate are opposite in \(S_0\), while the two gates have
closed arcs \((5,5)\) on the top octagon.  The complete rooted family is

\[
\mathcal T_{B_0}=\{M_2,M_3,M_4,M_5,M_6\},
\qquad
M_j=H\mathbin\triangle S_j,
\tag{27}
\]

where

\[
H=\{T_0,B_0\}\cup\{R_i:i\notin\{0,1\}\}.
\tag{28}
\]

Only \(M_4\) contains \(g_1\).  Moreover

\[
M_4\triangle M_3=C_6,
\qquad
M_4\triangle M_5=C_6,
\tag{29}
\]

whereas the differences with \(M_2,M_6\) are each two disjoint squares.
Hence the complete cross-sector bond graph has exactly two edges:

\[
\boxed{|E(\Gamma_{g_1}(\mathcal T_{B_0}))|=2.}
\tag{30}
\]

Their two face words are

\[
B00NM000,
\qquad
B000MN00.
\tag{31}
\]

Each shore uses two adjacent dual face vertices and is the dual of a
two-square domino.  In particular this canonical common completion does
not realize the singleton word (11): complete perfect-matching closure adds
the left and right neighbouring square states simultaneously.

There are two octagonal faces and eight choices of ordered \(g_0\) on each;
these \(16\) decorations are all symmetric, so (27)--(31) classify all of
them.  No graph census is used, and no order-minimality among all common
completions is asserted.

## 5. Exact boundary of the route

The face-word theorem closes every proof that tries to derive one-bond
selection from cyclic NAE or rotation data alone.  The root-square lemma
then removes the minimum local word in every actual rooted family, while
leaving singleton shores with common \(B\)-positions unresolved.  The
prism calculation shows that complete common incidence can add still more
compensation.  None of these conclusions decides the arbitrary-order
statement of Note 148.

The first unresolved implication remains

\[
\boxed{
\begin{gathered}
\text{one common plane brace, one root-square legal-wide gate face,}\\
\text{complete parent and child perfect-matching families,}\\
\text{exactly one bad }h\text{-avoiding }11\text{--}00\text{ bond, and no automatic bond}
\\[1mm]
\Longrightarrow
\text{a rooted gate sibling or an unrelated child supplement}.
\end{gathered}}
\tag{32}
\]

Any proof of (22) must couple the gate-face shore to the exterior
root-labelled circuit partition and the complete matching closure in the
same embedding.  Separate local words, separate shore connectivity, or
separate circuit-count identities cannot supply that coupling.
