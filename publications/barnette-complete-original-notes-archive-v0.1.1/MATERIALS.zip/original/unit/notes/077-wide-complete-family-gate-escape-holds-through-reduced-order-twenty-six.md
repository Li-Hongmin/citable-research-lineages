> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Wide complete-family gate escape holds through reduced order twenty-six

[Note 075](075-target-component-saturation-first-fails-at-reduced-order-twenty-four.md)
shows that component saturation first fails at reduced order \(24\), while the
ordinary complete-family lifting statement still holds.  It also proves that
a target at a site with a three-vertex gate arc lifts directly.  Hence the
first unresolved interfaces are wide sites, where both closed gate arcs have
cardinality at least five.  This note completely treats the next reduced
order.

## 1. Exact finite theorem

Let \(F'\) be a simple plane cubic bipartite brace with

\[
|V(F')|\le 26.
\]

Fix a legal two-gate \(C_4\)-expansion at a face, an unchanged root edge
\(e\) outside that face, and the nonempty complete rooted target family

\[
\mathcal T_e=
\{M:e\in M,\ F'-M\text{ consists of two cycles separating the ends of }e\}.
\]

If both closed gate arcs have cardinality at least five, then some
\(M\in\mathcal T_e\) uses at most one of the two gate edges.

Equivalently, no wide complete target family through reduced order \(26\)
forces both gates.  By the neutral-gate lemma of
[Note 071](071-at-most-one-gate-always-lifts-and-component-saturation-holds-through-twenty.md),
that target lifts.  Together with the short-arc lemma of Note 075 this gives:

**Theorem.** Ordinary existence-level prescribed-edge \(C_4\)-lifting holds
for every simple plane cubic bipartite brace of reduced order at most \(26\).

The conclusion is stronger at wide sites: liftability is witnessed before
the three-sector test of
[Note 076](076-complete-gate-forcing-reduces-to-three-rooted-sector-incidences.md)
is needed, because a neutral gate escape already exists.

## 2. Complete order-\(26\) coverage

At order \(26\), colour-preserving bipartite generation gives

\[
479741
\]

connected cubic bicoloured representatives.  Exact planarity filtering leaves
\(166\) bicoloured representatives.  After identifying the \(62\) duplicates
arising from exchanging the two bipartition classes, there are \(104\)
uncoloured planar representatives.  Of these,

\[
57\text{ are \(3\)-connected},\qquad
19\text{ are plane braces}.
\]

The complete wide-interface calculation on the nineteen braces gives

\[
\begin{array}{lr}
\text{wide nonconsecutive gate pairs}&179,\\
\text{legal wide \(4\)-connected splits}&154,\\
\text{braces supporting a legal wide split}&17,\\
\text{nonempty wide target interfaces}&4674,\\
\text{wide target instances}&58648,\\
\text{wide families containing a gate escape}&4674,\\
\text{wide families forcing both gates}&0.
\end{array}
\tag{1}
\]

Thus every nonempty wide family contains a target using at most one gate.

The use of bicoloured generation does not omit an uncoloured graph.  Every
connected bipartite graph has a unique bipartition up to exchanging its two
classes.  Therefore the \(13+13\) colour-preserving representatives cover
every uncoloured cubic bipartite graph of order \(26\), with multiplicity at
most two; the explicit uncoloured isomorphism step removes that multiplicity.

## 3. Consequence for the three-sector frontier

Note 076 reduces a hypothetical forced-family obstruction to the three rows

\[
011,\qquad101,\qquad110.
\]

Equation (1) shows that this forced-family premise never occurs through
order \(26\).  Hence any real counterexample to the remaining implication
Note 076(14) has reduced order at least \(28\).  This lower bound concerns
the complete-family gate-forcing premise itself, not merely ordinary
liftability.

The distinction from component saturation is essential.  Order \(24\)
already has a forced single-cycle component with no liftable target, but its
complete family has neutral targets.  The order-\(26\) theorem confirms that
the complete-family quantifier continues to prevent a wide obstruction one
order later.

## 4. Evidence and boundary

The proof bundle is
[wide-gate-escape-order26](../computations/bundles/wide-gate-escape-order26/README.md).
It streams the complete `genbg` corpus through an exact planarity prefilter,
deduplicates the surviving planar graphs as uncoloured graphs, checks both
brace criteria, reconstructs every legal wide split, enumerates every
unchanged-root complete target family modulo global colour complement, and
tests both gate loads in every target.

**Exact conclusion.** Wide complete-family gate escape, and therefore
ordinary existence-level \(C_4\)-lifting, holds through reduced brace order
\(26\).

**Weakest load-bearing step.** Completeness of the order-\(26\) source rests
on colour-preserving isomorph-free generation plus uniqueness of the
bipartition up to side exchange.  All mathematical filters after generation
are checked directly.

**Evidence level.** This is an exact computer-assisted finite theorem,
combined with the arbitrary-order neutral-gate and short-arc lemmas.

**Unresolved boundary.** Reduced order \(28\) and all larger orders remain
open.  No general argument is obtained for Note 076(14), and no conclusion
is drawn from targeted order-\(28\) construction families.
