> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Regional balance forces a return path in every cofacial XOR lift

[Note 095](095-the-c4-c8-xor-incidence-lifts-exactly-by-losing-cofaciality.md)
excludes a common-perfect-matching lift of the literal concentric
\(C_4+C_8\) XOR tangle by an annular colour imbalance.  The obstruction is
not specific to those cycle lengths.  There is an exact conservation law in
every Jordan region, and it excludes the entire class in which the common
complement has no same-cycle return path.

More precisely, consider a plane bipartite four-terminal graph with two
disjoint alternating cycles \(A,B\).  Suppose four perfect matchings differ
only by independently toggling \(A\) and \(B\), and suppose the complements
in all four states consist of two terminal paths and no closed component.
If the four terminals are incident with one face in their prescribed cyclic
order and the four complements have the XOR pairing table

\[
00:I,\qquad 10:E,\qquad 01:E,\qquad 11:I,
\tag{1}
\]

then the common complement must contain a path whose two toggle-cycle
endpoints lie on the same one of \(A,B\).

Thus merely lengthening the toggle cycles or adding radial channels cannot
repair the obstruction in Note 095.  A same-cycle return is the first new
combinatorial structure that any cofacial counterexample must use.

## 1. Regional colour conservation

Cut the sphere along \(A\cup B\), and let \(D\) be one of the resulting
Jordan regions.  Let \(Q_D\) be the set of cycle vertices whose third,
common-complement edge enters \(D\), and let \(T_D\) be the terminal
vertices in \(D\).  After deleting the cycle vertices, write \(U_D\) for
the remaining vertices of the graph in \(D\).  Give the two bipartition
classes signs \(+1\) and \(-1\).

Every component of the common complement in \(D\) is a path with endpoints
in \(Q_D\cup T_D\).  For one such path, the signed colour sum after
excluding its cycle-port endpoints and including its terminal endpoints is

\[
\frac12\left(
  \sum_{t\text{ an endpoint}}\operatorname{sgn}(t)
  -\sum_{q\text{ an endpoint}}\operatorname{sgn}(q)
\right).
\tag{2}
\]

Indeed, a bipartite path with oppositely coloured endpoints has zero total
colour surplus, while a path with equally coloured endpoints has surplus
one in their common colour.  Summing (2) over all common-complement paths
in \(D\) gives

\[
\boxed{
\sum_{u\in U_D}\operatorname{sgn}(u)
=\frac12\left(
  \sum_{t\in T_D}\operatorname{sgn}(t)
  -\sum_{q\in Q_D}\operatorname{sgn}(q)
\right).}
\tag{3}
\]

Outside \(A\cup B\), the four perfect matchings coincide.  Jordan
separation keeps each of their common edges inside its region, and these
edges perfectly match \(U_D\).  Hence the left side of (3) is zero.  Every
actual plane bipartite common-matching lift therefore satisfies the
regionwise law

\[
\boxed{
\sum_{q\in Q_D}\operatorname{sgn}(q)
=\sum_{t\in T_D}\operatorname{sgn}(t).}
\tag{4}
\]

In particular, the signed port sum of every terminal-free region is zero.
This is an integer conservation law; mod-two path-length equations do not
detect it.

## 2. Return-free tangles are impossible

Assume for contradiction that the common complement has neither a
terminal--terminal component nor a same-cycle return component.  A fixed
terminal--terminal component is already incompatible with (1), since
\(I\) and \(E\) have no terminal pair in common.  Thus every common path
joins \(A\) to \(B\), or joins one cycle to a terminal.

The two disjoint Jordan cycles cut the sphere into two disks and one
annulus.  The common terminal face lies either in a disk or in the annulus.

### 2.1 The terminal face lies in a disk

Interchange \(A,B\) if necessary so that \(A\) is the cycle farther from
the terminal disk.  Every port of \(A\) is then the endpoint of an
\(A\)--\(B\) path.  Put

\[
r=|V(A)|.
\tag{5}
\]

There are \(r\) cross paths and four \(B\)--terminal paths, so

\[
|V(B)|=r+4.
\tag{6}
\]

The disjoint cross paths preserve cyclic order between the two annular
boundaries.  If two cross endpoints were adjacent on \(B\), their
preimages would be adjacent on \(A\).  Choose on each cycle the smoothing
containing the corresponding boundary edge.  Those two cycle edges and
the two cross paths would be a closed complement component, contrary to
the hypothesis on the four states.  The \(r\) cross endpoints are
therefore an independent set of \(B\), and

\[
r\le \frac{|V(B)|}{2}=\frac{r+4}{2}.
\tag{7}
\]

Since an alternating cycle has length at least four, (6)--(7) force

\[
|V(A)|=4,
\qquad
|V(B)|=8.
\tag{8}
\]

The four cross endpoints on \(B\) form one bipartition class of \(C_8\),
so their signed sum is \(+4\) or \(-4\).  The four ports of \(A\) have
signed sum zero.  The annular region violates (4).  Equivalently, its
off-cycle vertices have colour surplus \(+2\) or \(-2\) by (3).

### 2.2 The terminal face lies in the annulus

Let \(r\) again be the number of cross paths.  They divide the annulus into
\(r\) disk sectors.  Cofaciality puts all four cycle--terminal paths in one
sector.  If \(a\) and \(b\) terminals attach to \(A\) and \(B\), then

\[
|V(A)|=r+a\ge4,
\qquad
|V(B)|=r+b\ge4,
\qquad
a+b=4,
\tag{9}
\]

and hence \(r\ge2\).  At least one sector contains no terminal path.  Its
two bounding cross paths have adjacent endpoints on both cycles.  Selecting
the two corresponding cycle edges in the two smoothings produces a closed
component, again a contradiction.

The two cases prove

\[
\boxed{
\text{Every ordered-cofacial bipartite common-PM XOR lift contains a
same-cycle return path.}}
\tag{10}
\]

## 3. Exact boundary

Equation (4) is necessary in every Jordan region, not merely in the
concentric \(C_4+C_8\) example.  Under the return-free hypothesis, the
cycle-free condition either collapses the tangle to that unbalanced
\(C_4+C_8\) incidence or creates a terminal-free sector that closes in one
state.

The theorem does not exclude tangles with same-cycle returns.  Such a
return is exactly what can change the number and colours of ports in one
region without adding terminal paths.  Whether noncrossing returns can
simultaneously satisfy (1), the four no-closed-component conditions and
the regional equations (4) is the next unresolved interface.  No brace,
legal-wide, inverse-square, full-fibre or \(2\)-extendability hypothesis is
used here.
