> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Root-square crossing edges can be bridges

[Note 151](151-a-common-b-face-can-have-exactly-one-rooted-crossing.md)
shows that fixing one common gate-face edge can leave a unique rooted
crossing even though the unconditioned rooted fibre has many.  A natural
strengthening would assert that every crossing exchange edge in the
complete root-square legal-wide fibre lies on an exchange cycle.  That
statement is false in the smallest fixed brace already used in Note 150.

The counterexample has exactly two crossing edges and both are bridges.
Thus it does not refute the original nonempty-implies-not-one statement;
instead it shows that the conjectured lower bound \(2\), if true, is sharp
and cannot follow from an edgewise nonbridge theorem.

## 1. A five-vertex exchange path

Use the \(12\)-vertex \(4\)-connected Eulerian plane triangulation \(T\)
from
[Note 150](150-root-square-incidence-is-essential-and-polyhedral-connectivity-stops-at-root-admission.md).
Its dual \(G=T^*\) is a \(20\)-vertex simple plane cubic bipartite brace.
This time choose the degree-four dual vertex

\[
 q=r_1
\tag{1}
\]

as the primal root-square face.  In the cyclic link of \(r_1\), the
neighbours \(A\) and \(z\) are opposite.  Hence

\[
 e^*=Ar_1,\qquad g_0^*=zr_1
\tag{2}
\]

correspond to opposite primal edges of the facial root square.  Choose

\[
 g_1^*=zr_5.
\tag{3}
\]

The cyclic link of \(z\) is \(r_0r_1\cdots r_7r_0\).  The positions
\(r_1,r_5\) have distance four in both directions, so the two closed gate
arcs have five vertices and the decoration is legal-wide.

Normalize the NAE colour of \(z\) to zero and order coordinates as
\((z,r_0,\ldots,r_7,A,B,C)\).  The complete rooted family containing
\(g_0\) is

\[
\begin{array}{c|c}
\text{row}&g_1\text{-sector}\\ \hline
010101111000&0\\
010110111000&0\\
010111011000&1\\
010111101000&0\\
010111110000&0.
\end{array}
\tag{4}
\]

Its complete single-cycle exchange graph is exactly

\[
 0-1-2-3-4.
\tag{5}
\]

The four bond shores, in path order, are

\[
 \{r_3,r_4\},\quad
 \{r_4,r_5\},\quad
 \{r_5,r_6\},\quad
 \{r_6,r_7\}.
\tag{6}
\]

Every edge of (5) is therefore a bridge.  Since the sector sequence is
\((0,0,1,0,0)\), the crossing edges are precisely

\[
 (1,2),\qquad(2,3),
\tag{7}
\]

and both are bridges.

The two gate-face words, started at \(g_0\), are

\[
 \mathtt{B00MN000},\qquad
 \mathtt{B000MN00}.
\tag{8}
\]

Neither has a common \(B\)-position beyond \(g_0\).  Thus (5)--(8) refute
the edgewise nonbridge strengthening without refuting the narrower
common-\(B\) triangle mechanism suggested by Note 151.

## 2. Two sufficient cycle witnesses

Let \(M,N\) be a cross-sector exchange edge and put

\[
 A=M\mathbin\triangle N.
\tag{9}
\]

Either of the following conditions forces a second crossing edge.

> **Rooted triangle witness.**  There is a rooted target \(P\) such that
> both \(M\triangle P\) and \(N\triangle P\) are single alternating
> cycles.

Indeed, \(M,N,P\) form a triangle in the exchange graph.  The
\(g_1\)-sector is a two-colouring of its vertices, so the triangle crosses
the sector cut an even number of times.  One of \(MP,NP\) is therefore a
second crossing edge.

> **Rooted commuting-square witness.**  There is an alternating cycle
> \(C\), edge-disjoint from \(A\), such that
> \[
> M'=M\triangle C,\qquad N'=N\triangle C
> \]
> are both rooted targets.

The two flips commute and give the exchange square

\[
 M-N-N'-M'-M.
\tag{10}
\]

Because \(A\) contains \(g_1\) and \(C\cap A=\varnothing\), the opposite
edge \(M'N'\) is also cross-sector.

Only one crossing edge needs either witness.  Conversely, a unique
crossing edge can have neither, because either witness places it on a
cycle.  These lemmas are sufficient mechanisms, not a characterization of
all possible cycle completions.

## 3. The Note 151 compensation leaves the fixed face

The complete unconditioned fibre in Note 151 has

\[
 41\text{ vertices},\qquad136\text{ exchange edges},\qquad
 69\text{ crossing edges}.
\tag{11}
\]

Its exchange graph is connected and has no bridge.  Among the \(69\)
crossing edges, \(67\) have a rooted triangle witness; the remaining two
lie on rooted four-cycles.  Only \(26\) admit the stronger edge-disjoint
commuting square, so disjoint commutation is not a universal explanation.

For the fixed common edge \(f=b_3t_1\), Note 151 leaves the unique crossing
\((36,37)\).  In the full fibre this edge has two rooted triangle witnesses,
numbered \(25,26\), and both omit \(f\).  Thus the compensation necessarily
leaves the fixed face, exactly as the counterexample in Note 151 requires.

## 4. Exact remaining boundary

The example (1)--(8) proves:

> **Crossing-bridge theorem.**  A complete rooted exchange graph of a
> legal-wide simple plane cubic bipartite brace with an actual
> root-opposite square can contain bridge crossing edges.  It can in fact
> be a path whose only two sector crossings are both bridges.

The original cardinality problem remains

\[
 \Gamma_{g_1}\ne\varnothing
 \quad\Longrightarrow\quad
 |E\Gamma_{g_1}|\ne1.
\tag{12}
\]

A proof of (12) need not eliminate crossing bridges.  It must instead
force a second crossing somewhere in the complete family.  In the
common-\(B\) residual branch, the cheapest surviving candidate is that a
fixed-face unique crossing always has a rooted triangle completion after
the common edge is released.  The path example does not test this
candidate because its crossing words have no extra common \(B\).

The permanent
[verification bundle](../computations/bundles/root-square-crossing-bridges/README.md)
checks the dual brace, root-square incidence, legal-wide arcs, all five
rooted rows, the exact exchange path, and the Note 151 cycle statistics.
