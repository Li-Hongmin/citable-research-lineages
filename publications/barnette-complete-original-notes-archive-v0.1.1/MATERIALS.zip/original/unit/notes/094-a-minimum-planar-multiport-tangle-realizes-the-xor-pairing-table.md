> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A minimum planar multi-port tangle realizes the XOR pairing table

[Note 093](093-minimum-directed-repairs-of-the-legal-wide-defect-example-do-not-reach-a-brace.md)
leaves open an existential normalization problem for globally minimum
two-component switches in legal-wide plane-brace fibres.  One proposed
ingredient was a purely topological cofacial-pairing lemma: two disjoint
proper toggles should not both change the target terminal pairing
\(\pi _0\) to the other noncrossing pairing \(\pi _1\), because their
combined toggle returns to a cycle-free \(\pi _0\) state.

That topological principle is false.  A planar four-terminal tangle with two
disjoint alternating cycles has the state table

\[
00:I,\qquad 10:E,\qquad 01:E,\qquad 11:I,
\tag{1}
\]

and none of its four states has a closed component.  Here \(I\) and \(E\)
are the two noncrossing pairings of four cyclically ordered boundary
terminals.  The construction uses twelve toggle ports, and twelve is
minimum in the reduced two-cycle port-tangle model arising from a simple
bipartite ambient graph.

This is an abstract planar tangle, not a legal-wide cubic interface.  It
therefore closes the Jordan/serial-tangle route without refuting the actual
cofacial-pairing lemma.  Any positive theorem must use information omitted
by the reduced tangle: labelled root--gate cofaciality, inverse-square
attachment incidence, or the complete perfect-matching fibre.

## 1. The concentric construction

Let

\[
A=a_0a_1a_2a_3a_0
\quad\text{and}\quad
B=b_0b_1\cdots b_7b_0
\tag{2}
\]

be concentric cycles.  Add radial edges

\[
a_i b_{2i}\qquad(i\in\mathbb Z/4\mathbb Z),
\tag{3}
\]

and attach boundary terminals \(t_i\) to \(b_{2i+1}\).  The terminals occur
in the cyclic order \(t_0,t_1,t_2,t_3\) on the outer face.  All twelve
cycle vertices have degree three; the four terminals have degree one.

For an even cycle \(v_0\ldots v_{2r-1}v_0\), define its two smoothing
states by

\[
0:(v_0v_1)(v_2v_3)\cdots(v_{2r-2}v_{2r-1}),
\tag{4}
\]

\[
1:(v_1v_2)(v_3v_4)\cdots(v_{2r-1}v_0).
\tag{5}
\]

Put

\[
I=(t_0t_1)(t_2t_3),\qquad
E=(t_0t_3)(t_1t_2).
\tag{6}
\]

Following the paths after choosing the two cycle states gives

\[
\begin{array}{c|cc|c}
\text{state}&\text{first path}&\text{second path}&\text{closed}\cr\hline
00&t_0b_1b_0a_0a_1b_2b_3t_1
  &t_2b_5b_4a_2a_3b_6b_7t_3&0\cr
10&t_0b_1b_0a_0a_3b_6b_7t_3
  &t_1b_3b_2a_1a_2b_4b_5t_2&0\cr
01&t_0b_1b_2a_1a_0b_0b_7t_3
  &t_1b_3b_4a_2a_3b_6b_5t_2&0\cr
11&t_0b_1b_2a_1a_2b_4b_3t_1
  &t_2b_5b_6a_3a_0b_0b_7t_3&0.
\end{array}
\tag{7}
\]

Thus the pairing table is exactly (1), with no closed component in any
state.  In particular, each proper toggle changes \(I\) to \(E\), while
the full toggle returns to the cycle-free state \(I\).

The four radial channels are essential: this is not a composition of two
ordinary two-port switches.  For serial two-port boxes the
Temperley--Lieb relation is \(E^2=E\dot\cup S^1\); equation (7) shows that
the relation does not survive multi-port attachments.

## 2. Minimum number of toggle ports

Consider a reduced overlay consisting of two disjoint even alternating
cycles.  Each cycle has length at least four.  After removing its selected
smoothing edges, every remaining component outside the cycles is a path.
If the base state has no closed component, contracting those path segments
leaves a perfect matching on the cycle ports and four ordered terminals.

If the total number of toggle ports is less than twelve, the only possible
cycle-length pairs are

\[
(4,4),\qquad(4,6),\qquad(6,4).
\tag{8}
\]

The verification bundle enumerates every perfect matching of the ports and
terminals for each case.  It first filters for the state table (1), then
subdivides every external matching edge and adds a subdivided rim through
the four terminals.  Every genuinely ordered-cofacial embedding extends to
such a plane rim augmentation, although the converse can fail when the
original tangle lies on both sides of the rim.  Thus this is a necessary
rim-planarity test on a superfamily, which is sufficient here because the
surviving count is zero.  It also retains parallel path occurrences.  The
exact counts are

\[
\begin{array}{c|r|r}
(|A|,|B|)&\text{abstract XOR matchings}&\text{rim-planar superfamily}\cr\hline
(4,4)&32&0\cr
(4,6)&192&0\cr
(6,4)&192&0.
\end{array}
\tag{9}
\]

Hence every ordered planar realization has at least twelve toggle ports,
and the \(C_4+C_8\) construction attains the bound.

## 3. Exact boundary

**Countermodel.**  Planarity, ordered boundary terminals and two disjoint
alternating-cycle toggles do not prohibit the cycle-free XOR table (1).

**Minimality.**  Twelve is the minimum total number of toggle ports in the
reduced strict planar two-cycle port-tangle model coming from a simple
bipartite ambient graph.

**Consequence.**  A proof of the cofacial-pairing lemma cannot reduce each
toggle to a serial two-port switch or appeal only to Jordan separation.
The missing positive input must couple the multi-port overlay to the actual
labelled inverse-square interface or to the common perfect-matching family.

**Scope.**  The reduced tangle itself is not bipartite: for example it
contains the five-cycle

\[
a_0a_1b_2b_1b_0a_0.
\tag{10}
\]

In the reduction, external matching edges stand for contracted path
segments, so bipartiteness of a possible ambient expansion is additional
parity data that the tangle deliberately forgets.  Nor do the four terminal
ends currently form perfect matchings of one common cubic graph.  The
tangle is therefore not asserted to extend to a simple cubic legal-wide
graph, a brace, or a globally minimum complete fibre.  It is a strict
abstract countermodel to the proposed topological reduction, not a
counterexample to the Barnette-class statement.

The construction and the complete smaller-port classification are frozen
in the
[verification bundle](../computations/bundles/minimum-planar-multiport-xor-tangle/README.md).
