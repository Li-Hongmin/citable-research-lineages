> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The minimum-support XOR cube is legal-wide in a plane brace but not fibre-minimum

[Note 098](098-a-minimum-support-cofacial-bipartite-xor-matching-cube.md)
constructs a minimum-sixteen-port common-matching cube with complement table

\[
00:I,\qquad 10:E,\qquad 01:E,\qquad 11:I,
\tag{1}
\]

and diagonal symmetric difference \(C_4\mathbin{\dot\cup}C_{12}\).
That construction already admits a labelled inverse-square attachment which
is legal-wide, and the resulting cubic graph is a plane brace.  Thus neither
the inverse-square geometry nor the brace axiom prohibits an actual
double-\(E\) two-switch.

The complete fixed-pairing fibre supplies the missing states.  For a natural
surviving gate it contains 41 matchings, and 69 cross-sector pairs differ on
one alternating cycle.  The displayed XOR diagonal has two components and is
therefore not a global minimum.  Consequently this example does not refute
the minimum-pair crossing candidate of
[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
It instead proves that the global selection over the complete fibre is an
essential hypothesis: no theorem about one local overlay can replace it,
even inside the full legal-wide plane-brace class.

## 1. A legal-wide inverse-square attachment

Use the 28-vertex residual \(R\) of Note 098, with ordered terminals
\(t_0,t_1,t_2,t_3\) and target pairing

\[
I=(t_0t_1)(t_2t_3).
\tag{2}
\]

Attach a square

\[
Q=u-v-x-y-u
\tag{3}
\]

in the terminal order

\[
(u,v,x,y)=(t_0,t_3,t_2,t_1).
\tag{4}
\]

The two complement channels of the deleted square are therefore

\[
(uy)(vx)=(t_0t_1)(t_3t_2)=I.
\tag{5}
\]

Choose

\[
e=uv,\qquad g_0=xy,\qquad g_1=b_4b_5.
\tag{6}
\]

The resulting graph \(G\) has 32 vertices and 48 edges.  It is simple,
connected, plane, cubic and bipartite, and \(Q\) is facial.  The forced gate
\(g_0\) and the surviving gate \(g_1\) lie on the common face

\[
b_4,b_3,t_1,y,x,t_2,x_5,b_5.
\tag{7}
\]

The root \(e\) is absent from this face.  Its two closed gate arcs both have
five vertices, equivalently the two residual gate-to-gate paths both have
odd length three.  Hence (3)--(7) form a legal-wide labelled inverse-square
interface in the project convention.

The graph is not merely 3-connected.  Its 811 perfect matchings collectively
contain every one of the

\[
\binom{48}{2}-32\binom{3}{2}=1032
\tag{8}
\]

pairs of independent edges.  Thus every two-edge matching extends to a
perfect matching, so \(G\) is 2-extendable and hence a brace.  Direct vertex
deletion also gives

\[
\kappa(G)=3.
\tag{9}
\]

## 2. An atomic double-\(E\) cube inside the brace

Let \(P_{ij}\) be the four residual matchings from Note 098 and put

\[
\widehat P_{ij}=P_{ij}\cup\{e,g_0\}.
\tag{10}
\]

All four sets in (10) are perfect matchings of \(G\).  Their complement
component counts are

\[
\begin{array}{c|cccc}
(i,j)&00&10&01&11\\ \hline
\#\operatorname{comp}(G-\widehat P_{ij})&2&1&1&2.
\end{array}
\tag{11}
\]

The states \(00,11\) are therefore rooted two-cycle targets with the fixed
pairing \(I\), whereas the two proper toggles are Hamiltonian states with
the other noncrossing pairing \(E\).  Moreover

\[
g_1\notin P_{00},\qquad g_1\in P_{11},
\tag{12}
\]

and

\[
P_{00}\mathbin\triangle P_{11}
=E(C_4)\mathbin{\dot\cup}E(C_{12}).
\tag{13}
\]

Relative to the two components in (13), the feasible masks in the fixed
\(I\)-fibre are exactly the empty and full masks: either proper toggle has
profile \((E,0)\) and therefore leaves that fibre.  Thus (13) is an actual
atomic double-\(E\) two-switch in a legal-wide plane brace.  This strengthens
the local boundary in
[Note 087](087-a-legal-wide-fibre-can-contain-a-nonminimum-atomic-two-switch.md):
the two proper defects can both be the alternative cycle-free pairing, even
at the sharp sixteen-port support bound.

## 3. Complete-fibre supplementation

Let \(\mathcal L_I\) be the complete family of perfect matchings \(P\) of
\(R\) such that \(R-P\) consists of exactly two spanning terminal paths with
pairing \(I\) and no closed component.  Split it by \(g_1\)-membership:

\[
\mathcal L_I^0=\{P\in\mathcal L_I:g_1\notin P\},\qquad
\mathcal L_I^1=\{P\in\mathcal L_I:g_1\in P\}.
\tag{14}
\]

The residual has 212 perfect matchings, and complete classification gives

\[
|\mathcal L_I|=41,\qquad
|\mathcal L_I^0|=16,\qquad
|\mathcal L_I^1|=25.
\tag{15}
\]

Across all \(16\cdot25=400\) cross-sector pairs, the distribution of the
number of alternating components in the symmetric difference is

\[
1^{69},\qquad2^{179},\qquad3^{115},\qquad
4^{29},\qquad5^6,\qquad6^2.
\tag{16}
\]

In particular,

\[
\min_{M\in\mathcal L_I^0,\,N\in\mathcal L_I^1}
\#\operatorname{comp}(M\triangle N)=1.
\tag{17}
\]

The verification bundle freezes a literal pair attaining (17); its entire
symmetric difference is the alternating 14-cycle

\[
b_0b_{11}b_{10}b_9b_8b_7b_6b_5b_4b_3b_2b_1x_0x_1b_0.
\tag{18}
\]

By contrast, \(P_{00},P_{11}\) lie in opposite sectors by (12) but have two
components by (13).  Hence

\[
\boxed{
\#\operatorname{comp}(P_{00}\triangle P_{11})=2
>1=d(\mathcal L_I^0,\mathcal L_I^1).}
\tag{19}
\]

## 4. Exact boundary

**Counterexample to local pairing exclusion.**  A legal-wide labelled
inverse-square interface in a simple plane cubic bipartite brace can contain
an atomic two-component overlay whose two proper toggles both have the other
noncrossing pairing and no closed component.  Therefore labelled gate
cofaciality, wide arcs, planarity, bipartiteness, cubic incidence and
2-extendability do not imply a cofacial-pairing prohibition for an arbitrary
chosen pair.

**Full-fibre repair.**  The same fixed-pairing fibre contains 69
cross-sector single-cycle exchanges.  The example therefore supports rather
than refutes the global crossing-edge candidate: brace-level matching
supplementation repairs the local cube outside its four displayed states.

**Remaining statement.**  It is still unknown whether a globally minimum
cross-sector pair in a legal-wide plane-brace fibre can have two components,
and in particular whether such a minimum pair can have the double-\(E\)
profile.  Any positive proof must use the complete-fibre minimum or an
equivalent global selection principle.  It cannot read only one
\(M,N,C_1,C_2\) overlay, even after all local Barnette hypotheses have been
imposed.

No minimum vertex order is asserted.  The word *minimum-support* refers only
to the sixteen toggle ports, whose optimality is Note 097.  The construction,
brace certificate and complete residual fibre are frozen in the
[verification bundle](../computations/bundles/legal-wide-plane-brace-xor-cube/README.md).
