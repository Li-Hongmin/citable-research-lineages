> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cofacial complete-family supplementation can be entirely nondirect

[Note 103](103-one-step-crossing-preservation-is-exactly-new-cell-supplementation.md)
reduces the hard case of one-step crossing preservation to the three new
child cells

\[
R_{00},\qquad X_{uy},\qquad X_{vx}.
\tag{1}
\]

[Note 106](106-cofacial-words-determine-direct-matchings-but-not-target-admission.md)
gives an exact criterion for the three *direct* lifts of a parent
state-\(11\) target: all matching edges away from the selected face are kept
fixed and one or both residual facial arcs are toggled. Such a lift need not
be a child target. The complete child family is nevertheless strictly more
flexible. A real legal-wide plane-brace site exists for which none of the
direct formulas is a target, while all three new cells contain targets and
all three meet the child crossing graph.

Moreover, merely closing the exterior connection signatures under feasible
single alternating-cycle exchange does not repair the direct argument. A
sharp hexagonal two-state support has one nontrivial exchange component and
every state in that component is direct-\(\Omega\)-bad.

## 1. The real cofacial witness

Take the labelled order-\(32\) plane brace of
[Note 099](099-the-minimum-support-xor-cube-is-legal-wide-in-a-plane-brace-but-not-fibre-minimum.md).
One of its faces is

\[
(a_0,x_2,b_{11},b_{10},b_9,x_8,x_7,a_3).
\tag{2}
\]

Expand the cofacial edges

\[
p=b_{10}b_9,\qquad q=a_3a_0.
\tag{3}
\]

The two residual facial arcs both have length three. The resulting
order-\(36\) graph is again a legal-wide plane brace, with the same root
square and surviving gate used to define the fixed-pairing fibre.

Write the parent fibre in the deterministic order
\(L_{00},L_{01},\ldots\). Its state-\(11\) slice at (3) is exactly

\[
\mathcal L_{11}=\{L_{20},L_{26},L_{27}\}.
\tag{4}
\]

There are therefore nine direct formulas, three for each member of (4).
Only five are perfect matchings:

\[
L_{20}:X_{uy},\qquad
L_{26}:R_{00},X_{uy},X_{vx},\qquad
L_{27}:X_{vx}.
\tag{5}
\]

Their complements have respectively

\[
3,4,3,3,3
\tag{6}
\]

connected components. In particular, none is a member of the child target
fibre: every direct candidate either fails to be a perfect matching or
fails the prescribed spanning-two-path condition.

The complete child family has a different profile. Its target fibre has
\(67\) members and its cross-sector single-cycle graph has \(139\) edges.
For the three new cells one obtains

\[
\begin{array}{c|ccc}
 &R_{00}&X_{uy}&X_{vx}\\ \hline
\text{targets}&15&5&9\\
\text{targets incident with a crossing}&13&5&9\\
\text{crossing-edge incidence}&41&27&38.
\end{array}
\tag{7}
\]

Exactly \(88\) distinct crossing edges have at least one endpoint in the
three new cells. Since no direct candidate is a target, every one of these
\(88\) edges is supplied by nondirect complete-family targets. Thus even
the simultaneous nonemptiness and crossing incidence of all three cells
does not select a direct lift of any member of \(\mathcal L_{11}\).

The finite verification is exhaustive rather than sampled. It reconstructs
the fixed labelled parent and the specified embedding move, enumerates every
child perfect matching, tests the two prescribed complement paths and gate
sector, constructs the whole single-cycle crossing graph, and separately
constructs the nine formulas of Note 106. The verifier is frozen in the
[supporting bundle](../computations/bundles/non-direct-cofacial-supplementation/README.md).

## 2. What the witness refutes

The example refutes the selection implication

\[
\begin{gathered}
\text{the complete child family populates a new cell and}\\
\text{that cell meets the child crossing graph}
\end{gathered}
\Longrightarrow
\begin{gathered}
\text{some parent }M\in\mathcal L_{11}\text{ has a direct}\\
\Omega\text{-good target lift in that cell}.
\end{gathered}
\tag{8}
\]

It also shows that nondirect matching-family flexibility is not a technical
convenience: it can account for the entire new-cell contribution to the
crossing graph.

This site is not a one-step kill cover. The parent crossing graph has
\(69\) edges, of which \(51\) have neither endpoint in
\(\mathcal L_{11}\). Equivalently, the child still has \(51\)
canonical--canonical crossings. Hence the example does not refute the
kill-cover supplementation implication of Note 103.

## 3. A minimum exchange-closed exterior blocker

The failure of one direct state cannot be repaired formally by invoking
single alternating-cycle exchange closure at the exterior-signature level.
Use the hexagonal ports of Note 106 and put

\[
\begin{aligned}
P&=\{a_0a_1,a_2a_3,b_0b_1\},\\
Q&=\{a_0a_3,a_1a_2,b_0b_1\}.
\end{aligned}
\tag{9}
\]

Here \(P\) is the old facial connection and \(Q\) is the connection after
switching the length-three residual arc. For the desired terminal pairing
\(\alpha\beta\mid\gamma\delta\), define

\[
\begin{aligned}
\Omega_0={}&\{\alpha a_0,a_1\beta,\gamma a_2,a_3b_0,b_1\delta\},\\
\Omega_1={}&\{\alpha\beta,a_0b_1,a_1\delta,
                 \gamma a_2,a_3b_0\}.
\end{aligned}
\tag{10}
\]

Both \(\Omega_i\cup P\) consist of exactly the prescribed two terminal
paths. After the switch, \(\Omega_0\cup Q\) instead has pairing

\[
\alpha\delta\mid\beta\gamma,
\tag{11}
\]

while \(\Omega_1\cup Q\) retains the desired terminal pairs but contains
the additional closed component

\[
a_0a_3b_0b_1a_0.
\tag{12}
\]

Thus both states are direct-\(\Omega\)-bad.

Let \(J\) have edge set \(\Omega_0\cup\Omega_1\). This support consists
of the two forced edges \(\gamma a_2,a_3b_0\) and the six-cycle

\[
\alpha a_0b_1\delta a_1\beta\alpha.
\tag{13}
\]

Consequently its complete perfect-matching family is exactly
\(\{\Omega_0,\Omega_1\}\), and the two states differ by the single
alternating six-cycle (13). The whole feasible exchange component is
therefore bad; it is not an arbitrarily selected bad subset.

This is port-minimal in the cofacial model. On a facial square both
residual arcs have one edge, so the old and switched connections agree and
no target exterior signature can become bad. The next even face is the
hexagon used above. Two states are also the minimum size of a nontrivial
exchange component.

## 4. Exact boundary

The order-\(32\to36\) example is a real simple cubic bipartite plane-brace
instance, but its state-\(11\) slice is not a vertex cover of the parent
crossing graph. The two-state model is a strict complete-support
exchange-closed obstruction, but it has not been lifted to a common cubic
plane brace. Neither construction decides whether actual plane-brace
incidence forces new-cell supplementation when the kill-cover antecedent
holds.

Together they close two weaker routes. A proof of the remaining implication
cannot select one state-\(11\) parent while fixing all off-face matching
edges, and it cannot use only abstract closure of exterior connection
signatures under single-cycle exchange. It must use the shared cubic
plane-graph incidence of the complete nondirect perfect-matching family.
[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
retains precisely that incidence by converting the remaining proposition
into a rooted bond-flip statement on the actual dual triangulation split.
