> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complete-family extremality first needs common cubic completion

[Note 140](140-short-gap-extreme-families-reduce-to-complete-family-gate-path-sibling-selection.md)
reduces the short-gap problem to a complete-family selection statement.  A
natural strengthening would try to prove the selection separately for each
bad bond by balancing its parent \(h\)-toggle against its child gate-path
sibling.  That strengthening is false in a real plane brace.  Moreover the
entire local perfect-matching algebra admits an abstract extreme-family
countermodel.  The first constraint not retained by that model is common
cubic completion of all complement-connectivity signatures.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
later shows that common cubic completion is still insufficient for an
arbitrary interface-disjoint decoration: the abstract failure pattern has a
real complete-family realization outside legal-wide. The pointwise
counterexample and local countermodel below remain valid; only the final
unresolved implication must retain legal-wide.

## 1. The pointwise toggle--sibling alternative is false

For a bad \(h\)-avoiding \(11\)--\(00\) bond \(M-N\), let \(N^h\) and
\(S_g\) be the parent toggle and child gate-path sibling of Note 140.  The
implication

\[
 \text{bad bond}
 \Longrightarrow
 \bigl(N^h\text{ rooted}\bigr)
 \lor
 \bigl(S_g\text{ rooted}\bigr)
\tag{1}
\]

is false.

Use the order-20 graph

~~~text
S???????F?Y?b?W_CW?F?AW?KO?`_?g_?
~~~

with root \(1\!-13\), forced gate \(2\!-10\), surviving gate
\(4\!-16\), and facial orientation

\[
 (u,v,x,y)=(5,12,3,19),\qquad
 p=5\!-12,quad q=3\!-19,quad h=5\!-19.
\tag{2}
\]

For the fixed bad bond, deleting \(p,q\) from its difference cycle gives

\[
 P_{uy}=E(5,17,9,19),\qquad
 P_{vx}=E(12,4,16,8,18,3),
\tag{3}
\]

and the surviving gate lies on \(P_{vx}\).  The actual parent perfect
matching

\[
 N^h=N\triangle(P_{uy}\cup\{h\})
\tag{4}
\]

has a one-component Hamilton complement.  The actual child perfect
matching

\[
 S_g=\widehat N\triangle
 \bigl(P_{vx}\cup\{bv,bc,cx\}\bigr)
\tag{5}
\]

has three complement components.  Thus

\[
 \bigl(c(G-N^h),c(G^+-S_g)\bigr)=(1,3),
\tag{6}
\]

and neither matching is rooted.  This is a genuine interface-disjoint
legal-wide short-gap plane-brace fibre.

The complete parent fibre is not extreme: its four bonds, sharing one
state-\(11\) endpoint, have types

\[
 11\text{--}00(h\text{-avoiding}),\quad
 11\text{--}00(h\text{-present}),\quad
 11\text{--}10,\quad 11\text{--}01.
\tag{7}
\]

Hence (6) refutes only the pointwise route, not the complete-family
extremality statement.  It proves that the universal hypothesis on the
whole parent bond graph is essential.

## 2. A complete local matching countermodel

The remaining local algebra can also be separated from common cubic
realizability.  Let the parent core consist of the cycle

\[
 u v r s x y w t u
\tag{8}
\]

and the short facial chord \(h=uy\), with \(p=uv\), \(q=xy\).  This is a
connected plane bipartite subcubic six-port core.  Its complete
perfect-matching family has exactly three members:

\[
\begin{aligned}
 M&=\{uv,rs,xy,tw\},& \sigma(M)&=11,\\
 N&=\{vr,sx,ut,wy\},& \sigma(N)&=00,\ h\notin N,\\
 N^h&=\{vr,sx,tw,uy\},& \sigma(N^h)&=00,\ h\in N^h.
\end{aligned}
\tag{9}
\]

Their pairwise differences are the literal \(C_8,C_4,C_6\) recombination
cycles required by Notes 139--140.  Expanding \(p,q\) gives a plane
bipartite subcubic child core with exactly eight perfect matchings,
including \(\widehat N,\Phi(M),S_U,S_V\).  The two siblings are each one
alternating-cycle flip from \(\widehat N\), while the prescribed direct
pair \(\widehat N,\Phi(M)\) has a two-cycle difference.

Assign the abstract parent complement signatures

\[
\begin{array}{c|ccc}
 &M&N&N^h\\ \hline
\text{signature}&2+\mathrm{sep}&2+\mathrm{sep}&3
\end{array}
\tag{10}
\]

and, in the child, assign \(2+\mathrm{sep}\) only to
\(\widehat N,\Phi(M)\), assigning signature \(3\) to the other six
matchings.  Then the complete abstract parent rooted fibre is
\(\{M,N\}\) and has exactly one bond, an \(h\)-avoiding
\(11\)--\(00\) bond.  The complete abstract child rooted fibre is
\(\{\widehat N,\Phi(M)\}\); its two endpoints lie in opposite sectors but
their difference has two components, so it has no bond and no supplement.

This countermodel retains literally:

1. one common plane bipartite subcubic parent core and its expanded child;
2. every perfect matching of both cores, not a selected subset;
3. the exact \(h\)-toggle and both sibling alternating-cycle exchanges;
4. the one-cycle bond and two-cycle direct-failure relations;
5. complete rooted fibres relative to the assigned signatures.

It does not retain a connected cubic plane completion whose actual
two-factor complements realize all signatures in (10) and their child
counterparts simultaneously.  Exterior-spoke matchings may also enlarge
the complete perfect-matching closure.  The countermodel is therefore a
strict route closure, not a Barnette counterexample.

## 3. Exact remaining interface

Equations (6) and (10) rule out two entire proof layers.  Planarity,
brace \(2\)-extendability, perfect-matching closure, local alternating-cycle
recombination, and per-bond complement-component balance do not prove the
desired selection.  Even the complete local PM family plus formal rooted
signatures is insufficient.

The unresolved implication remains

\[
 \boxed{
 \begin{minipage}{0.82\linewidth}
 In one legal-wide connected cubic plane short-gap completion, if the
 complete rooted parent bond graph is nonempty and every bond is an
 \(h\)-avoiding \(11\)--\(00\) bond, must the complete child rooted family
 contain a new-cell bond?
 \end{minipage}}
\tag{11}
\]

Any proof of (11) must use a compatibility constraint that couples distinct
parent bonds or all perfect matchings of the same cubic completion.  The
thinnest such missing input is a six-port common-completion theorem for the
parent and child complement-connectivity partitions.  Conversely, a real
completion realizing the abstract pattern above would be a short-gap
ChildSupplement counterexample.

The real double failure and the strict abstract countermodel are verified by
the [complete-family extremality boundary bundle](../computations/bundles/complete-family-extremality-boundary/README.md).
