> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All single endpoint defects are Hamiltonian at second surplus

At the gapless second surplus,
[Notes 244](244-a-double-delayed-endpoint-has-a-forced-rainbow-hamilton-route.md)
and [245](245-a-delayed-endpoint-composes-with-an-earlier-vacancy.md)
settle a delayed first target when the second vacancy precedes it.
[Note 236](236-an-isolated-second-vacancy-composes-with-one-target-defect.md)
handles a later face block, and [Note 247](247-a-right-site-vacancy-before-the-final-target-is-hamiltonian.md)
handles the right site block. [Note 246](246-a-vacancy-immediately-after-a-delayed-first-target-is-hamiltonian.md)
handles the same block only when the second vacancy immediately
follows the first target and no target follows that vacancy.
The remaining same-block positions have a simple obstruction:
a target after the vacancy traps its two adjacent free slots.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, \(s=2\), and
\[
d_L=1,\qquad b=d_R=0.                         \tag{1}
\]
Suppose \(R_\ell\) is the third interior slot of \(B_h\),
\(0\le h\le r\), and both vacancies lie in \(B_h\): the first
is its second interior slot \(w\), and the second is an even
slot \(H\) after \(R_\ell\). Let \(I\) be the odd slot
immediately after \(H\). Its interior has the schematic order
\[
o_h,w,R_\ell,\ \mathcal A,\ H,I,\ \mathcal C,e_h,
                                                        \tag{2}
\]
where \(\mathcal A,\mathcal C\) are possibly empty consecutive
runs of occupied \(L_j,R_{j-1}\) target pairs. The final even
slot \(e_h\) is free, and all earlier blocks are short.

**Same-block post-target theorem.** An opening satisfying (1)--(2)
cannot have \(\mathcal C\ne\varnothing\). If
\(\mathcal C=\varnothing\), let \(L_j\) be the first escape
target after \(H,I\), in block \(B_m\), \(m>h\). Then the parent
has a Hamilton cycle containing both site edges \(xy,uv\), and
its legal site-expanded child is Hamiltonian. If \(h\ge1\),
necessarily \(m\ge h+2\), and for some
\(t\in\{h+2,\ldots,m\}\) the complete free matching is
\[
M_{\rm free}=\{o_0w,Ho_t,Ie_{t-1}\}
 \cup\{e_k o_{k+1}:0\le k\le r,\ k\ne t-1\}.   \tag{3}
\]
If \(h=0\), it is instead
\[
M_{\rm free}=\{o_0e_0,wI,Ho_1\}
 \cup\{e_k o_{k+1}:1\le k\le r\}.             \tag{4}
\]
The same statements hold after reflection. Original square-trap
lobes may have arbitrary positive lengths.

**Internal block: an occupied suffix is impossible.** Suppose
\(h\ge1\). The free prefix before \(R_\ell\) has \(2h+2\)
slots. Note 203 excludes cross-block matching chords across
\(R_\ell\). Matching parity allows zero or two same-block
crossing chords, since only \(o_h,w\) precede that target.
Two would use both slots. The complete main prefix through
\(B_{h-1}\) would then be matching-closed: it contains no
escape target, its site and face chords are internal, and its
free slots can reach neither a later block across \(R_\ell\)
nor the already used \(o_h,w\). Its two old-cycle boundary
edges contradict three-connectivity. Hence zero chords cross
\(R_\ell\), and Note 211 forces \(o_0w\) and the standard
links \(e_k o_{k+1}\), \(0\le k<h\), in the closed prefix.

If \(\mathcal C\ne\varnothing\), consider its first target.
The only free slots since the preceding occupied target run
are \(H,I\). The total free prefix before this target is
even. A cross-block matching chord across it is forbidden by
Note 203. The only possible same-block crossing chord from
\(H,I\) to the final free slot \(e_h\) is \(Ie_h\), so parity
excludes it. Earlier slots are behind the \(R_\ell\) barrier;
later blocks are behind the new target barrier. Thus \(H,I\)
would have to match each other, but \(HI\in E(C)\). This
contradiction proves \(\mathcal C=\varnothing\).

Now \(\mathcal A\) consists only of tight target pairs.
The free group after its last \(R\)-target and before \(L_j\)
is precisely
\[
H,I,e_h,o_{h+1},e_{h+1},\ldots,o_m.         \tag{5}
\]
The intervening blocks are short, since both vacancies are used.
Every free matching edge in (5) joins distinct blocks, hence lies
in the noncrossing disk opposite the common site face by Note 193.
The even slot \(H\) must match some \(o_t\). The choice
\(t=h+1\) strands the adjacent pair \(I,e_h\), so
\(h+2\le t\le m\). Inside \(Ho_t\), the odd slot \(I\)
must match \(e_{t-1}\): an earlier mate would force one
complete short block to match its adjacent free pair, or two
or more complete blocks to form a matching-closed two-edge-cut
interval. Note 196's skipping rule forces the remaining links
in (5) and every later ordinary group. This proves (3).
The target-and-square path of Note 196 replaces its initial
edge by \(x,o_0,w,R_\ell\); its disjoint free path replaces
\(e_{t-1}o_t\) by \(e_{t-1},I,H,o_t\). Tight transitions
in \(\mathcal A\) remain on the target path. The two paths
meet only at \(x,v\), span the parent, and contain \(xy,uv\)
in their union.

**Left site block.** Let \(h=0\). The free slots \(o_0,w\)
before \(R_\ell\) are adjacent. They cannot be matched to
each other, and Note 203 bars a chord from either to a later
block across \(R_\ell\). Matching parity therefore requires
two same-block crossing chords. The even slot \(w\) must match
\(I\); the odd slot \(o_0\) can match \(H\) or \(e_0\).
These chords cross the escape edge from \(R_\ell\), so both
lie on the site-face side of \(C\). The pair \(o_0H,wI\)
interlaces there and is impossible. Thus
\[
o_0e_0,wI\in M.                                \tag{6}
\]
The remaining even slot \(H\) must match a free odd slot
\(o_t\) in a later block. If \(\mathcal C\ne\varnothing\),
such a cross-block chord would straddle its first escape
target, contrary to Note 203. Hence \(\mathcal C\) is empty.
If \(t>1\), Note 203 first excludes any occupied target in
\(B_1,\ldots,B_{t-1}\), since \(Ho_t\) would straddle it.
Noncrossing then encloses complete short blocks
\(B_1,\ldots,B_{t-1}\): one has an adjacent unmatched free
pair, while two or more create a forbidden two-edge cut.
Therefore \(Ho_1\in M\), and Note 196 forces all subsequent
standard links, giving (4).

Here the target-and-square path begins
\(x,o_0,w,R_\ell\). The disjoint free path begins
\(x,y,e_0,I,H,o_1,a_1,b_1\) and follows the standard
links thereafter. Because \(\mathcal C=\varnothing\),
\(Ie_0\in E(C)\); the other joins are exactly those
in (4) and Note 196. Again the paths meet only at \(x,v\),
span the parent and contain both site edges. Notes 001 and 178
give the legal child and restore longer lobes. \(\square\)

**Two profiles with an intervening target pair.** For an
internal block take \(r=2,\ell=2,h=1\) and
\(\mathcal A=(L_2,R_1)\). The old 30-cycle has blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_2,L_2,R_1,H,I,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_1,S_2:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2),\text{ returning to }x.
\end{array}                                            \tag{7}
\]
Its matching consists of
\[
\begin{split}
&xy,a_1b_1,a_2b_2,uv,
 \alpha_j\beta_j,R_j\delta_j,L_j\gamma_j\ (j=1,2),\\
&o_0w,e_0o_1,e_1o_2,Ie_2,Ho_3.
\end{split}                                            \tag{8}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,o_0,w,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,
 L_2,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,I,H,o_3,u,v.
\end{split}                                            \tag{9}
\]
Put the site, face and \(\alpha_j\beta_j\) chords on one
side of \(C\). On the other side, the matching nests are
\(o_0w\supset e_0o_1\) and
\[
R_2\delta_2\supset L_2\gamma_2\supset R_1\delta_1
\supset\bigl(Ho_3\supset Ie_2\supset e_1o_2,
L_1\gamma_1\bigr).
\tag{10}
\]
The two inner branches are disjoint. The interlacement graph
of matching chords is connected: a spine is
\[
xy-o_0w-a_1b_1-Ho_3-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-a_1b_1-
L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-a_1b_1.
\tag{11}
\]
The chord \(e_0o_1\) interlaces \(xy\); \(e_1o_2\) and
\(Ie_2\) interlace \(a_1b_1\); and \(a_2b_2\) interlaces
\(Ie_2\). Thus every chord joins the spine.
All matching pairs have opposite old-cycle parities, and
\(x,u\) have the same parity. Note 217 proves that the
30-vertex parent and its 34-vertex site-expanded child are
three-connected Barnette graphs. Formula (9) gives their
Hamilton cycles through Note 001.

For a left site block take \(r=1,\ell=2,h=0\), again with
\(\mathcal A=(L_2,R_1)\). The old 26-cycle has
\[
\begin{array}{ll}
B_0:&x,o_0,w,R_2,L_2,R_1,H,I,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_1,S_2:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2),\text{ returning to }x.
\end{array}                                            \tag{12}
\]
Its matching consists of
\[
\begin{split}
&xy,a_1b_1,uv,
 \alpha_j\beta_j,R_j\delta_j,L_j\gamma_j\ (j=1,2),\\
&o_0e_0,wI,Ho_1,e_1o_2.
\end{split}                                            \tag{13}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,o_0,w,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,
 L_2,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,I,H,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                            \tag{14}
\]
On the site-face side \(xy\supset o_0e_0\supset wI\),
while the other site, face and square chords occupy disjoint
intervals. Opposite-side chords form the nest
\[
R_2\delta_2\supset L_2\gamma_2\supset R_1\delta_1
\supset\bigl(Ho_1,e_1o_2,L_1\gamma_1\bigr),
\tag{15}
\]
with three disjoint inner branches. The interlacement spine
\[
xy-Ho_1-a_1b_1-e_1o_2-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-xy-L_2\gamma_2-
\alpha_2\beta_2-R_2\delta_2-xy
\tag{16}
\]
connects all matching chords except \(o_0e_0,wI\), both of
which interlace \(R_2\delta_2\). The same parity,
interlacement and site-expansion arguments make the parent
and child 26- and 30-vertex Barnette graphs, with cycles (14).

**One-endpoint-defect corollary.** Every gapless all-square
opening with \(s=2\) and exactly one target-order defect,
which is a delayed first target or an advanced last target,
has a parent Hamilton cycle containing \(xy,uv\) and a
Hamiltonian legal child. For a delayed first target, Note 197
puts it at interior position three or five: position five
uses both vacancies before it and is Note 244. At position
three the other vacancy is in an earlier block (Note 245),
the same block after the target (this theorem and Note 247's
right-site exclusion), a later face block (Note 236), or the
right site block (Note 247). These alternatives exhaust its
location. Reflection gives the advanced-last-target case.
The corollary is conditional on the selected all-square
opening with empty gaps; it does not decide other defect
patterns, nonsquare residual cycles, or Barnette's conjecture.

**Second-surplus reduction.** Combining the corollary with
Note 235 (zero defects), Note 238 (both endpoint defects),
Notes 239--240 (one endpoint and one transition defect), and
Notes 241--242 (two transition defects), the defect budget
of Note 197 leaves only one gapless all-square pattern in which
a legal child could be non-Hamiltonian at \(s=2\):
\[
d_L=d_R=0,\qquad b=1.                    \tag{17}
\]
Thus the sole remaining second-surplus gapless target-order
decision is one nonadjacent consecutive-lobe transition with
one additional vacant eligible position. This is a necessary
condition for a counterexample in the selected opening class,
not an assertion that such a counterexample exists.
