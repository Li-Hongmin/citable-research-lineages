> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-, two-, and three-vertex regions do not obstruct single-layer FEC support

[Note 034](034-single-region-weights-collapse-to-one-and-two-vertex-regions-do-not-obstruct.md)
reduces a single weighted face region to a perfect-matching intersection
bound and proves it for two vertices.  This note proves the next exact
boundary case.

Use the setting of Notes 028--034.  Thus \(F\) is a plane cubic bipartite
brace, \(p=uv\) and \(h=za\) are a legal cofacial site with \(u,z\) in one
bipartition class, and

\[
 K=F-\{u,a\},\qquad
 Q=(F^*/\{p^*,h^*\})[E(K)^*].
\tag{1}
\]

The graph \(K\) is 1-extendable and has minimum degree at least two.
Write \(c\) for the common-face vertex of \(F^*\), and \(c_p,c_h\) for
the other endpoints of \(p^*,h^*\).  These three vertices become the
contracted root \(r\) of \(Q\).

> **Three-vertex region theorem.** For every
> \(W\subseteq V(Q)\) with \(|W|=3\), there is a perfect matching \(M\)
> of \(K\) such that
> \[
> |M\cap E_Q(W)|\le2=|W|-1.
> \tag{2}
> \]

Together with Note 034, this implies that every strict single-region
binary FEC support certificate has \(|W|\ge4\).

## Root-free regions

Suppose first that \(r\notin W\).  The graph \(Q[W]\) is a retained
subgraph of the simple triangulation \(F^*\), so it has at most three
edges.  The result is immediate if it has at most two.  If it has three,
they form a triangle.  Four-connectivity of \(F^*\) makes every triangle
facial; the three primal labels therefore meet at one vertex of \(K\).
Every perfect matching uses exactly one of them.

We may henceforth write

\[
 W=\{r,s,t\}.
\tag{3}
\]

If \(E_Q(W)\) is empty, the result is immediate.  If
\(1\le |E_Q(W)|\le3\), choose an internal edge \(e\), choose another edge
at one endpoint of \(e\), and extend that other edge to a perfect matching.
The resulting matching avoids \(e\) and uses at most two internal edges.
Thus only regions with at least four internal labels require analysis.

## Root classes

For \(q\in\{s,t\}\), let

\[
 A(q)=
 \{d\in\{c,c_p,c_h\}:dq\text{ is retained in }E(K)^*\}.
\tag{4}
\]

Simplicity of \(F^*\) gives one retained label for each member of \(A(q)\).
A size-two class has one of three types:

\[
 V=\{c,c_p\},\qquad
 Z=\{c,c_h\},\qquad
 R=\{c_p,c_h\}.
\tag{5}
\]

The triangles on \(cc_p\) are the primal vertices \(u,v\).  Since the
edges at \(u\) were deleted, a retained \(V\)-class is exactly the two
edges of \(K\) incident with the degree-two vertex \(v\).  Every perfect
matching uses exactly one.  Similarly, a \(Z\)-class is the complete
degree-two block at \(z\), and every perfect matching again uses exactly
one.

For a remote \(R\)-class at \(q\), the uncontracted dual cycle

\[
 c-c_p-q-c_h-c
\tag{6}
\]

crosses \(p,h\) and the two retained class labels.  Deleting \(u,a\)
removes \(p,h\), so the two class labels form a two-edge cut of \(K\).
Perfect-matching cut parity gives exactly two alternatives:

1. every perfect matching uses one class edge; or
2. every perfect matching uses zero or two class edges.

In the second alternative, choose a perfect matching avoiding one class
edge.  Such a matching exists because every edge is avoidable: select an
alternative edge at one endpoint and use 1-extendability.  Cut parity then
forces the matching to avoid both class edges.

Consequently every size-two root class is either

\[
\boxed{\text{exact-one in every perfect matching}}
\quad\text{or}\quad
\boxed{\text{has a zero-edge perfect-matching witness}.}
\tag{7}
\]

A size-three root class is unique.  Its dual edges are

\[
 cs,\quad c_ps,\quad c_hs,
\]

and the facial triangles \(cc_ps,cc_hs\) show that its primal labels are

\[
 vz,\quad vx,\quad zy,
\tag{8}
\]

where \(x,y\) are the other neighbours of \(v,z\) in \(K\).  A perfect
matching uses either \(vz\), or the pair \(vx,zy\).

## No edge between the two nonroot vertices

Put \(k_s=|A(s)|\), \(k_t=|A(t)|\), and first assume \(st\notin E(Q)\).

If one class has size three and the other has size at most one, extend
\(vz\) to a perfect matching.  The two classes then contribute at most
one edge each.

If the other class has size two, it must be remote: the two faces on
\(cc_p\) and \(cc_h\) already account for the deleted and retained local
classes.  If the remote class is exact-one in (7), extend \(vz\) and use
one edge from each class.  If it has a zero-edge witness, use that witness;
the size-three class contributes at most two.

It remains that both classes have size two.  If both are exact-one, every
perfect matching uses two internal edges.  If one has a zero-edge witness,
use it; the other class has only two labels and contributes at most two.
This proves (2) whenever \(st\notin E(Q)\).

## The facial edge between the two nonroot vertices

Now suppose \(st\in E(Q)\), and let \(g\) be its primal label.  Cases with
\(k_s+k_t+1\le3\) were already settled.  Up to interchanging \(s,t\), the
remaining profiles are

\[
 (k_s,k_t)=(2,1),(2,2),(3,0),(3,1),(3,2).
\tag{9}
\]

For \((2,1)\), an exact-one size-two class contributes one in every
matching; choose a matching avoiding the singleton root label, leaving at
most that class edge and \(g\).  If the size-two class has a zero-edge
witness, use it and leave only the singleton and \(g\).

For \((2,2)\), if both classes are exact-one, choose a perfect matching
avoiding \(g\) and obtain two internal edges.  If exactly one class has a
zero-edge witness, use it; the other class and \(g\) contribute at most
two.  If both have zero-edge witnesses, both are remote \(R\)-classes.
The triangles \(c_pst,c_hst\) are facial.  Their four root labels are
the other two cubic incidences at each endpoint of \(g\).  Extend \(g\)
to a perfect matching; all four root labels are excluded.

For \((3,0)\), extend \(vz\); only \(vz\) and possibly \(g\) are used.

For \((3,1)\), the singleton root edge cannot lift to \(ct\): the dual
edge \(cs\) already has the two facial triangles \(cc_ps,cc_hs\).  Suppose
it lifts to \(c_pt\); the \(c_h\)-case is symmetric.  The triangle
\(c_pst\) is facial.  Extend the primal label \(vx\) dual to \(c_ps\).
At \(v\) this excludes \(vz\); at the other endpoint it excludes the
singleton label and \(g\).  The degree-two vertex \(z\) is then forced to
use \(zy\).  Exactly two internal labels are selected.

Finally consider \((3,2)\).  The size-two class is remote, and the
triangles \(c_pst,c_hst\) are facial.  The label \(g\) joins the other
endpoints of \(vx,zy\); the two remote labels are their remaining cubic
incidences.  Extend \(g\) to a perfect matching.  It excludes all four of
those labels, and the degree-two vertices \(v,z\) are forced to use
\(vz\).  The matching uses precisely \(g,vz\).

These profiles exhaust (9), proving the theorem.

## Consequence and boundary

For a single region, Note 034 shows that a perfect matching satisfying

\[
 |M\cap E_Q(W)|\le |W|-1
\]

implies the complete weighted charging inequality.  The one-vertex case is
vacuous because \(Q\) has no retained loops; the two-vertex case is
Note 034; and the theorem above settles three vertices.  Therefore

\[
\boxed{\text{every actual single-region obstruction has }|W|\ge4.}
\tag{10}
\]

The matching may depend on \(W\).  Nothing here supplies one simultaneous
matching for nested regions, and the result does not exclude a genuinely
laminar obstruction.

The finite profile exhaustion and the fixed order-16 cross-check are
reproduced by

    python3 \
      units/barnette/scratch/worker-barnette/verify_three_vertex_region_cases.py

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-barnette/probe_three_vertex_regions.py

with terminal markers THREE_VERTEX_REGION_CASES_VERIFIED and
THREE_VERTEX_FIXED_INSTANCE_PROBED.
