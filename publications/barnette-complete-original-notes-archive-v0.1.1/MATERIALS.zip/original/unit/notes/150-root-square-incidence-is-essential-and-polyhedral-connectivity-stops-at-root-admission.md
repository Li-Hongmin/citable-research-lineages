> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Root-square incidence is essential, while polyhedral connectivity stops at root admission

[Note 149](149-legal-wide-face-words-do-not-determine-one-bond-rooted-selection.md)
shows that the legal-wide gate-face word does not itself force a second
rooted bond.  This note identifies two further boundaries.  First, after
the root-opposite-square incidence is removed, a complete family in a
genuine plane brace dual can have exactly one cross-sector rooted bond.
Second, perfect-matching-polytope connectivity forces many full-family
crossing exchanges on any sufficiently high-dimensional face, but it does
not force those exchanges to retain the prescribed rooted two-linkage.

The combination isolates a sharp candidate statement: a root-square
fixed-pairing face-escape theorem, rather than another gate-face occupancy
or ordinary polyhedral-connectivity lemma.  Note 151 below answers that
candidate negatively.

## 1. A complete one-bond family without the root square

Let \(T\) have vertices

\[
 z,r_0,r_1,\ldots,r_7,A,B,C.
\tag{1}
\]

Its edges are the rim \(r_ir_{i+1}\), with indices modulo \(8\), all
spokes \(zr_i\), and

\[
\begin{aligned}
&Ar_0,Ar_1,Ar_2,AC,\\
&Br_0,Br_2,Br_3,\ldots,Br_7,BC,\\
&Cr_0,Cr_2.
\end{aligned}
\tag{2}
\]

The twenty facial triangles are the eight \(zr_ir_{i+1}\), the two
triangles \(Ar_0r_1,Ar_1r_2\), the six triangles \(Br_ir_{i+1}\) along
the rim arc from \(r_2\) through \(r_7\) to \(r_0\), and

\[
 ACr_0,\quad BCr_0,\quad ACr_2,\quad BCr_2.
\tag{3}
\]

Thus \(T\) is a simple \(4\)-connected Eulerian plane triangulation.  Its
plane dual is consequently a simple cubic bipartite brace.

Choose

\[
 e^*=Br_3,\qquad g_0^*=zr_5,\qquad g_1^*=zr_1.
\tag{4}
\]

Normalize the colour of \(z\) to zero.  A direct enumeration of the NAE
colourings which contain the forced gate and satisfy the labelled-root
condition gives exactly three rows.  In the vertex order

\[
 (z,r_0,\ldots,r_7,A,B,C)
\]

they are

\[
\begin{aligned}
\kappa&=010101011001,\\
\chi  &=010101011100,\\
\eta  &=011101011000.
\end{aligned}
\tag{5}
\]

Their \(g_1\)-sectors are \(1,1,0\), respectively.  The XOR shores are

\[
\begin{array}{c|c|c}
\text{pair}&\text{shore}&\text{status}\\ \hline
\kappa\chi&\{A,C\}&\text{bond, same sector},\\
\chi\eta&\{A,r_1\}&\text{bond, opposite sectors},\\
\kappa\eta&\{C,r_1\}&\text{not a bond}.
\end{array}
\tag{6}
\]

Indeed, for the middle row both the shore and its complement induce
connected subgraphs, whereas \(\{C,r_1\}\) is disconnected.  Hence the
complete rooted family has exactly one cross-sector bond, namely
\(\chi\eta\).

The gates \(zr_5,zr_1\) split the cyclic link of \(z\) into two arcs of
four steps, so this is the minimum legal-wide geometry.  Moreover, at the
cofacial split site \(A\), take

\[
 p^*=Ar_2,\qquad q^*=Ar_0,\qquad h^*=Ar_1.
\tag{7}
\]

Then \(\chi\) has state \(11\), \(\eta\) has state \(00\), and \(\eta\)
omits \(h^*\).  The unique crossing bond therefore has exactly the
\(h\)-avoiding \(11\)--\(00\) profile left by
[Note 139](139-a-one-edge-facial-gap-leaves-only-h-avoiding-11-00-bonds.md).

On the other hand, \(e^*=Br_3\) and \(g_0^*=zr_5\) are vertex-disjoint.
They cannot be the two opposite dual edges incident with the degree-four
vertex corresponding to a primal root square.  Thus the example proves:

> **Root-square necessity theorem.**  Legal-wide geometry, a complete
> rooted NAE family, genuine bond shores, and a simple plane cubic
> bipartite brace do not exclude a unique cross-sector rooted bond.  The
> root-opposite-square incidence is an essential hypothesis in the
> remaining one-bond selection problem.

This is not a counterexample to ChildSupplement.  The chosen split face
has a separate square-transfer supplement, so the example isolates only
the proposed second-parent-bond route.

The fixed certificate is
[the standard-library verifier](../computations/bundles/legal-wide-one-bond-without-root-square/verify_one_bond_without_root_square.py).
It checks the plane triangulation, Eulerian degrees, \(4\)-connectivity,
all \(97\) perfect matchings of the dual cubic graph, extension of all
\(375\) independent edge pairs, all normalized NAE rows, the complete
rooted family, the three pairwise shores, the two sectors, and the
\(h\)-avoiding profile.  From the project root, run

~~~bash
python3 units/barnette/computations/bundles/legal-wide-one-bond-without-root-square/verify_one_bond_without_root_square.py
~~~

The terminal marker is
LEGAL_WIDE_ONE_BOND_WITHOUT_ROOT_SQUARE_VERIFIED.

## 2. Polyhedral connectivity supplies full-family crossings

Let \(P(G)\) be the perfect-matching polytope of a graph \(G\).  Two
vertices of \(P(G)\) are adjacent if and only if their perfect matchings
differ on a single alternating cycle.

> **Rooted-face lemma.**  Let \(F\) be a \(d\)-dimensional face of
> \(P(G)\), where \(d\ge2\).  Suppose every vertex of \(F\) is a rooted
> target and both values of \(x_{g_1}\) occur on \(F\).  Then the rooted
> bond graph induced by \(V(F)\) has at least \(d\) edges crossing the
> \(g_1\)-sector cut.

By Balinski's theorem, the graph of \(F\) is \(d\)-vertex-connected and
hence \(d\)-edge-connected.  The coordinate \(x_{g_1}\) partitions its
vertices into two nonempty classes, so at least \(d\) face edges cross the
partition.  Every such edge is also an edge of \(P(G)\), and therefore is
a single-alternating-cycle pair.  Its two endpoints are rooted by
hypothesis, and their \(g_1\)-coordinates differ.  These are precisely
cross-sector rooted bonds.  This proves the lemma.

The threshold is sharp: a one-dimensional face is a segment, and its
endpoints may lie in opposite sectors, producing exactly one crossing
edge.

For bipartite perfect-matching polytopes, the one-dimensional obstruction
has an exact graph form.  Let \(S\) be an extendable matching, delete
\(V(S)\), and retain only those residual edges which occur in an extension
of \(S\).  If the connected components of this allowed-edge graph are
\(H_1,\ldots,H_t\), then

\[
 \dim F_S
 =\sum_{i=1}^t\bigl(|E(H_i)|-|V(H_i)|+1\bigr).
\tag{8}
\]

This is the bipartite incidence-rank formula, summed over components.
Every edge of every \(H_i\) belongs to a perfect matching.  A bridge in a
nontrivial \(H_i\) would therefore belong to every perfect matching; its
endpoints could then have no other allowed incident edge.  Hence a
component of dimension zero is a single \(K_2\), while a component of
dimension one is bridgeless and unicyclic, and therefore is an even cycle.
Consequently

\[
\boxed{
 \dim F_S=1
 \iff
 \text{the allowed residual graph is one even cycle together with forced
 }K_2\text{ components}.}
\tag{9}
\]

In this case \(F_S\) has exactly two vertices.  Thus the low-dimensional
escape from the rooted-face lemma is precisely one residual alternating
cycle with every other residual edge forced.

For a common-\(B\) edge \(f\) supplied by Note 149, consider the nonempty
face

\[
 F_{e,g_0,f}
 =P(G)\cap\{x_e=x_{g_0}=x_f=1\}.
\tag{10}
\]

If this face has dimension at least two and all its vertices are rooted,
then a unique crossing bond is impossible.  This is the strongest direct
consequence of ordinary perfect-matching-polytope connectivity.

## 3. Why the polyhedral lemma does not settle the root-square case

A brace is \(2\)-extendable, whereas (10) fixes the three-edge matching
\(\{e,g_0,f\}\).  The brace axiom therefore does not imply that (10) has
dimension at least two.  More importantly, even when its dimension is at
least two, Balinski's theorem supplies a second crossing edge in the full
perfect-matching family, not in the rooted subfamily.

After the root square is smoothed, rooted admission is the condition that
the residual complement consists of two spanning paths with one prescribed
labelled pairing.  Component number and terminal pairing are nonlinear
conditions on the vertices of \(P(G)\); they need not define a face and
need not be preserved by a second polyhedral exchange edge.  Consequently
the missing implication is exactly

\[
\boxed{
\begin{gathered}
\text{a second full-perfect-matching crossing edge in }F_{e,g_0,f}\\
\Longrightarrow\\
\text{some second crossing edge has both endpoints in the rooted}\\
\text{fixed-pairing fibre.}
\end{gathered}}
\tag{11}
\]

Ordinary Smith--Thomason parity does not prove (11).  Root smoothing turns
the rooted targets into Hamilton cycles through two prescribed edges, and
[Note 124](124-root-smoothing-does-not-turn-mixed-sector-survival-into-parity.md)
contains a legal family of odd cardinality \(5\).  In any case, the desired
quantity is the number of edges crossing a coordinate cut in a filtered
single-cycle exchange graph, not the number of Hamilton cycles through one
fixed edge.

The argument therefore poses the following sharper question:

> **Fixed-pairing face-escape problem.**  In the legal-wide root-square
> setting, can the \(g_1\)-crossing edges of a common-\(B\) face meet the
> rooted fixed-pairing fibre in exactly one edge?

[Note 151](151-a-common-b-face-can-have-exactly-one-rooted-crossing.md)
answers this question affirmatively by a real \(32\)-vertex root-square
brace: its common-\(B\) face has \(280\) crossing edges, but its rooted
subfibre has exactly one.  Hence neither the gate-face word nor filtered
polyhedral connectivity decides the original unconditioned one-bond
alternative.
