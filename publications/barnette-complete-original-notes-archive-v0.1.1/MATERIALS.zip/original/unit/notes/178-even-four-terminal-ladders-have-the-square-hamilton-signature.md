> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even four-terminal ladders have the square Hamilton signature

[Note 177](177-facial-square-traps-form-bouquet-lobes-with-disjoint-merger-squares.md)
identifies consecutive square traps in a facial opening. Their union has
a stronger description: each escape-network lobe is an exact four-terminal
ladder, and its length is invisible to Hamilton traversals at its four
attachments.

Let \(L_N=P_N\square K_2\), with columns
\((t_j,b_j)\), \(0\le j<N\), and terminals
\[
\lambda_t=t_0,\quad \lambda_b=b_0,\quad
\rho_t=t_{N-1},\quad \rho_b=b_{N-1}.
\tag{1}
\]
A *spanning one-path routing* is a Hamilton path of \(L_N\) whose
endpoints are two terminals. A *spanning two-path routing* consists of
two vertex-disjoint paths covering all vertices, with the four terminals
as their four endpoints. The routing signature records the chosen
terminal pair or pairing, not the internal edges.

**Even-ladder signature theorem.** For every even \(N\ge2\), the
one-path routings are exactly the four pairs
\[
\lambda_t\lambda_b,\quad \rho_t\rho_b,\quad
\lambda_t\rho_t,\quad \lambda_b\rho_b,
\tag{2}
\]
and the two-path routings are exactly the two pairings
\[
\{\lambda_t\lambda_b,\rho_t\rho_b\},
\qquad
\{\lambda_t\rho_t,\lambda_b\rho_b\}.
\tag{3}
\]
In particular, the full four-terminal Hamilton routing signature of
\(L_N\) equals that of the square \(L_2\).

**Proof.** The ladder is bipartite, with \(t_j\) and \(b_j\) in opposite
colour classes. Since \(N\) is even, \(t_0,b_{N-1}\) have one colour and
\(b_0,t_{N-1}\) the other. A spanning path has \(2N\) vertices, hence
opposite-colour endpoints. This leaves precisely the four pairs (2).
Each occurs. For \(\lambda_t\lambda_b\), traverse the top rail from
left to right, the last rung, and the bottom rail from right to left:
\[
t_0,t_1,\ldots,t_{N-1},b_{N-1},b_{N-2},\ldots,b_0.
\tag{4}
\]
Reflection gives \(\rho_t\rho_b\). For \(\lambda_t\rho_t\), concatenate
the blocks
\[
(t_{2s},b_{2s},b_{2s+1},t_{2s+1}),
\qquad 0\le s<N/2;
\tag{5}
\]
successive blocks meet through the edge
\(t_{2s+1}t_{2s+2}\). Interchanging top and bottom gives
\(\lambda_b\rho_b\).

In a two-path routing, the cyclic order of the terminals on the outer
boundary is \(\lambda_t,\rho_t,\rho_b,\lambda_b\).
Vertex-disjoint paths cannot connect the interlacing pairs
\(\lambda_t\rho_b\) and \(\lambda_b\rho_t\) in a disk.
Thus only (3) is possible. The two rails realize the second pairing.
For the first, use the left rung \(t_0b_0\) as one path and use
\[
t_{N-1},t_{N-2},\ldots,t_1,b_1,b_2,\ldots,b_{N-1}
\tag{6}
\]
as the other. These paths cover every vertex and are disjoint, including
when \(N=2\). This proves the exact signature. \(\square\)

**Four-pole replacement corollary.** Let a graph \(X_N\) contain an
induced copy of \(L_N\), for even \(N\), with exactly four edges to a
nonempty exterior, one at each terminal in (1). Replace the ladder by
a square \(L_2\) and reattach those four labeled edges at corresponding
corners, obtaining \(X_2\). Then \(X_N\) has a Hamilton cycle if and
only if \(X_2\) does. More precisely, the projections of their Hamilton
cycles onto the exterior edges and the four labeled attachment edges
are identical. Thus every prescribed use/avoid condition on those edges
is preserved.

To prove the corollary, a Hamilton cycle must use exactly two or four
attachment edges: their number is positive because the exterior is
nonempty and is even by cut parity. With two, its intersection with the
ladder is one spanning path. With four, the intersection is two disjoint
spanning paths; a separate internal cycle is impossible in a global
Hamilton cycle. Replace this routing by the same terminal routing in
the other ladder, using the theorem. The exterior part and its
connectivity are unchanged. The construction works in both directions.
\(\square\)

**Barnette-preserving reduction.** Suppose \(X_N\) in the replacement
corollary is simple and cubic; then \(X_2\) is also simple and cubic.
If \(N\) is even, then
\[
X_N\text{ is cubic, bipartite, planar and 3-connected}
\quad\Longleftrightarrow\quad
X_2\text{ is cubic, bipartite, planar and 3-connected}.
\tag{7}
\]
Consequently the replacement preserves both membership in the
Barnette class and every exterior-marked Hamilton decision.

**Proof.** Simplicity and cubicity are immediate from the four
labeled attachments. The terminal colour pattern of the even ladder
is the same as that of the square, so a bipartition extends across
one patch exactly when it extends across the other.

Write \(H\) for the exterior, obtained by deleting all ladder
vertices but retaining its four attachment endpoints. If either
ambient graph is 3-connected, then \(H\) is connected. Indeed,
3-connectivity implies 3-edge-connectivity; every component of
\(H\) would need at least three of the four attachment edges,
which is impossible for two components. The exterior is nonempty
by hypothesis.

Planarity is preserved from \(X_N\) to \(X_2\) because the latter
is a minor: delete all internal rungs, then contract the top and
bottom rail paths by contracting all but one edge of each,
without identifying their endpoints. Conversely, if \(X_2\)
is plane, the connected exterior
\(H\) lies on one side of the square cycle. Subdivide its two
opposite rail edges and insert the internal rungs in the empty
side, giving a plane drawing of \(X_N\).

For 3-connectivity, deleting one vertex from any ladder leaves
it connected. Also, after deleting any two vertices from \(L_N\),
every remaining component contains a surviving terminal. For an
internal top vertex \(t_j\), three internally disjoint routes lead
to the distinct terminals \(t_0,t_{N-1},b_0\): left and right
along the top rail, and through its rung then left along the
bottom rail. The bottom case is symmetric; terminals need no
argument. At most two deleted vertices cannot hit all three
routes.

Assume first that \(X_N\) is 3-connected. If at most one square
vertex is deleted in \(X_2\), match it to the corresponding old
corner of \(L_N\). The remaining patch is connected on both
sides, and 3-connectivity of \(X_N\) says that every component
of the remaining exterior has a surviving attachment. Thus
\(X_2\) stays connected. If two square vertices are deleted,
\(H\) is connected and each remaining square vertex attaches
to \(H\), so \(X_2\) again stays connected. This covers all
deletions of at most two vertices.

Conversely assume \(X_2\) is 3-connected. If at most one
ladder vertex is deleted in \(X_N\), its remaining patch is
connected, and 3-connectivity of \(X_2\) ensures that every
component of the remaining exterior has a surviving attachment.
For a deleted internal ladder vertex, compare with \(X_2\)
without deleting any square vertex. If two ladder vertices are
deleted, \(H\) is connected and every remaining ladder
component has a surviving terminal and hence an attachment
to \(H\). Therefore \(X_N\) stays connected after every
deletion of at most two vertices. This proves (7). \(\square\)

**Application to facial square traps.** For a lobe block
\(S_a,\ldots,S_b\) of Note 177, put \(n=b-a+1\). Its induced graph is
exactly \(L_{2n}\), with column order
\[
(\alpha_a,a_a),(\beta_a,b_a),
(\alpha_{a+1},a_{a+1}),(\beta_{a+1},b_{a+1}),
\ldots,(\beta_b,b_b).
\tag{8}
\]
The horizontal edges are \(m_i,h_i\) in the top rail and
\(a_i b_i,b_i a_{i+1}\) in the bottom rail; the vertical edges
are \(\alpha_i a_i,\beta_i b_i\). The four attachment edges are
\(h_{a-1}\) at \(\alpha_a\), the escape edge at \(a_a\),
\(h_b\) at \(\beta_b\), and the escape edge at \(b_b\).
There are no other edges leaving the block, so its edge boundary
has size four. Replacing this block by one square preserves every
Hamilton decision and every mark on edges outside the block or on
its four labeled attachments. This is a routing equivalence;
when the original graph is Barnette, the compressed graph is
Barnette as well by (7). Hence a vertex-minimal non-Hamiltonian
Barnette graph contains no induced even-column four-terminal
ladder of this kind with more than two columns: compression would
give a smaller Barnette graph with the same Hamilton status.

**Reduced-class corollary.** Call a Barnette graph *ladder-reduced*
if it has no induced \(L_N\) with even \(N\ge4\) and exactly the four
corner attachments above. Every Barnette graph can be compressed
in finitely many steps to a ladder-reduced Barnette graph with the
same Hamilton status. Therefore Barnette's conjecture is equivalent
to its restriction to ladder-reduced graphs. Each compression
decreases the vertex count by \(2N-4\ge4\); (7) and the four-pole
replacement corollary preserve the required class and Hamilton
status, and descent must terminate. No uniqueness of the reduced
graph is needed or claimed. \(\square\)

**Facial-opening normal form.** In the setting of Notes 176--177,
compress every lobe ladder in the parent \(G\) and in its
square-expanded child \(G^+\). The two compressions commute with
the site expansion: the reduced child is exactly the expansion
of the reduced parent at the same labeled site \(p,q\). The
parent Hamilton cycle \(C\) becomes a Hamilton cycle \(C'\)
avoiding \(p,q\), and the chosen facial alternating arc becomes
one with precisely one trapped square per former lobe. The main
segment \(S_0\), the site ports, and all marks on edges outside
the ladders are unchanged. If the original expansion is legal
within the Barnette class, the reduced expansion is legal too;
Hamiltonicity and all such exterior-marked Hamilton decisions
of both parent and child are equivalent before and after reduction.

Indeed, each ladder is disjoint from the site and its patch.
The restriction of \(C\) to a lobe is a spanning path between
its two cut-\(C\)-edge terminals \(\alpha_a,\beta_b\), using
neither escape attachment. Replace it by the square path
\(\alpha_a,a_a,b_b,\beta_b\), with the two interior labels now
denoting the corresponding new square vertices. This preserves
the outside part of \(C\) and its incidence with \(p,q\).
In the plane strip occupied by the ladder, the common-face arc
ran along its top rail, alternating between \(m_i\) and \(h_i\).
The replacement square has its top edge on that same face side,
so the arc now contains one matching edge between its two
boundary cut edges. Different lobes are disjoint, so the
replacements commute. The Barnette-preserving reduction (7)
and the four-pole Hamilton-signature equivalence apply to
both parent and child separately. \(\square\)
