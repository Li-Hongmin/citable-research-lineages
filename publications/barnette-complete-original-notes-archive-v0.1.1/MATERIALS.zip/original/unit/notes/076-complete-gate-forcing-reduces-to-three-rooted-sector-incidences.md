> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complete gate forcing reduces exactly to three rooted sector incidences

[Note 075](075-target-component-saturation-first-fails-at-reduced-order-twenty-four.md)
shows that single-cycle component saturation is false and that the correct
remaining quantifier is the complete rooted target family.  This note gives
an exact arbitrary-order reduction of that family-level problem.

[Note 079](079-sector-collision-calculus-exposes-the-essential-brace-boundary.md)
subsequently uses monochromaticity of the components of \(P\) to sharpen the
formal criteria below: the mixed-colour overlaps in the one-sector formulas
are always empty, and a successful \(I_{LR}\) is dominated by successful
\(I_L,I_R\).  Thus the three-row reduction here is correct, while its final
family implication can be stated using only the two one-sided tests.

Let \(F'\) be a simple plane cubic bipartite brace, let \(T'=F'^*\), and
fix a legal two-gate split at \(z\). Write \(x_2,x_4\) for the gate
neighbours, \(A_L,A_R\) for the two closed neighbour arcs, and \(a=e^*\)
for the unchanged root. Let \(c\) be a reduced target colouring,
normalised by \(c(z)=0\), whose matching contains both gates. Thus

\[
c(x_2)=c(x_4)=0.
\tag{1}
\]

Put \(H=H(c)\), \(R=H-a\), and \(P=R-z\). By the target condition, \(R\)
is a three-component forest and the two ends of \(a\) are joined in it.
For a boundary vertex \(y\in N(z)\), let \(B(y)\) denote its component in
\(P\), and let \(\mu,\nu\) denote the two root-marked components of \(P\).
All component vertices of \(P\), including those without a boundary or root
mark, are retained below.

## 1. The facial flip is exactly the expanded row \(111\)

Suppose both \(A_L\) and \(A_R\) alternate. Then changing only the colour
of \(z\) gives another facewise-NAE colouring

\[
c^z=c\oplus\mathbf 1_{\{z\}}.
\tag{2}
\]

Conversely, (2) is facewise NAE only if the whole neighbour word at \(z\)
alternates. Indeed, the old NAE condition forbids a consecutive \(00\)
pair in the neighbour word, whereas NAE after changing \(z\) forbids a
consecutive \(11\) pair. Together these conditions say that the word
alternates.

In \(R(c^z)\), the vertex \(z\) is joined precisely to the boundary
vertices coloured \(1\) by \(c\). In expanded row \(111\), the same
attachments on \(A_L\) and \(A_R\) are distributed to the two split
vertices, and those two vertices are joined by the two-edge path through
the new centre. Thus row \(111\) is obtained from \(R(c^z)\) by replacing
the star centre \(z\) by a tree and distributing its incident edges between
the two ends. This replacement preserves acyclicity, the component
partition away from the replacement, and connectivity of the two root
marks. Hence

\[
\boxed{
\text{expanded row }111\text{ lifts }c
\iff c^z\text{ is a reduced target}.}
\tag{3}
\]

The matching represented by \(c^z\) differs from that of \(c\) exactly on
the boundary of the split face. It still contains \(e\), but it excludes
both gate edges.

Consequently, if the **complete** rooted target family forces both gates,
then row \(111\) fails for every member of that family. This is not a
witness-level statement: it uses completeness of the target family. It
also shows that row \(111\), although locally available at a fully
alternating wide site, can never prove the forced-family case.

## 2. Three explicit reduced incidence graphs

For a set \(S\) of boundary vertices, an expression such as
\(uB(S)\) means one edge \(uB(y)\) for every occurrence \(y\in S\); repeated
component labels therefore give parallel edges. Define the following
multigraphs.

If \(A_L\) alternates, let

\[
\begin{aligned}
I_L(c):\quad
&V=\operatorname{comp}(P)\cup\{\ell,r,v\},\\
&E=\{\ell B(y):y\in A_L,\ c(y)=1\}\\
&\phantom{E={}}\cup\{rB(y):y\in A_R,\ c(y)=0\}
\cup\{\ell v\}.
\end{aligned}
\tag{4}
\]

If \(A_R\) alternates, let

\[
\begin{aligned}
I_R(c):\quad
E={}&\{\ell B(y):y\in A_L,\ c(y)=0\}\\
&\cup\{rB(y):y\in A_R,\ c(y)=1\}
\cup\{rv\}.
\end{aligned}
\tag{5}
\]

If both arcs alternate, let

\[
\begin{aligned}
I_{LR}(c):\quad
E={}&\{\ell B(y):y\in A_L,\ c(y)=1\}\\
&\cup\{rB(y):y\in A_R,\ c(y)=1\}\\
&\cup\{vB(x_2),vB(x_4)\}.
\end{aligned}
\tag{6}
\]

The graphs (4), (5), and (6) are exactly the component quotients of
expanded rows \(101,011,\) and \(110\), respectively. This follows simply
by listing their monochromatic local edges:

\[
\begin{array}{c|c}
101 & \ell\text{ attaches to the \(1\)-vertices of }A_L,
      \ r\text{ to the \(0\)-vertices of }A_R,
      \ \ell v;\\
011 & \ell\text{ attaches to the \(0\)-vertices of }A_L,
      \ r\text{ to the \(1\)-vertices of }A_R,
      \ rv;\\
110 & \ell\text{ attaches to the \(1\)-vertices of }A_L,
      \ r\text{ to the \(1\)-vertices of }A_R,
      \ v\text{ to }x_2,x_4.
\end{array}
\tag{7}
\]

Contracting the components of \(P\) neither creates nor destroys a cycle
outside the quotient. The edge count is fixed, so a quotient forest has
the required three components. Therefore

\[
\begin{aligned}
101\text{ lifts }c
&\iff I_L(c)\text{ is a forest and joins }\mu,\nu,\\
011\text{ lifts }c
&\iff I_R(c)\text{ is a forest and joins }\mu,\nu,\\
110\text{ lifts }c
&\iff I_{LR}(c)\text{ is a forest and joins }\mu,\nu.
\end{aligned}
\tag{8}
\]

The eligibility clauses in (4)--(6) are essential. They are exactly the
arc-alternation conditions from Note 065(2).

For example, write

\[
\mathcal L_1=\{B(y):y\in A_L,\ c(y)=1\},\qquad
\mathcal R_0=\{B(y):y\in A_R,\ c(y)=0\},
\tag{9}
\]

as multisets. Because \(R\) is a forest, distinct zero-coloured neighbours
of \(z\) lie in distinct components of \(P\); hence \(\mathcal R_0\) has no
repetition. From (4), \(I_L(c)\) is a forest exactly when

1. \(\mathcal L_1\) has no repeated component, and
2. the underlying sets of \(\mathcal L_1\) and \(\mathcal R_0\) meet in at
   most one component.

A repetition in condition 1 is a parallel-edge cycle, and two common
components in condition 2 form a four-cycle through \(\ell,r\); these are
the only possible cycles in (4). The symmetric statement holds for
\(I_R(c)\).

## 3. Exact complete-family reduction

The locally valid double-gate rows are \(001\), the eligible members of
\(011,101\), and, when both arcs alternate, \(110,111\). Row \(001\)
always contains the new monochromatic four-cycle and cannot be a target.
Equation (3) excludes row \(111\) under complete-family gate forcing.
Equations (4)--(8) therefore give the following arbitrary-order theorem.

**Three-sector reduction.** Assume every member of the complete rooted
target family \(\mathcal T_e\) contains both gates. Then a member
\(M\in\mathcal T_e\) lifts if and only if its normalised colouring \(c_M\)
has at least one eligible rooted incidence forest among

\[
I_L(c_M),\qquad I_R(c_M),\qquad I_{LR}(c_M).
\tag{10}
\]

In particular, the unresolved wide complete-family statement is exactly

\[
\boxed{
\text{a terminal-fixed complete target family contains a state satisfying
(10).}}
\tag{WF}
\]

No component-saturation premise occurs in (WF).

## 4. What completeness means at the remaining arrow

Fix one normalised target colouring \(c_0\). Every other target colouring
\(c\) has the form

\[
c=c_0\oplus\mathbf 1_D,\qquad z\notin D,
\tag{11}
\]

and

\[
E(H(c))=E(H(c_0))\mathbin\triangle\delta(D).
\tag{12}
\]

In the primal, \(\delta(D)^*\) is the disjoint union
\(M(c_0)\triangle M(c)\) of alternating cycles. If the complete family
forces both gates, then all its normalised colourings agree at the three
terminals \(z,x_2,x_4\), so every target-preserving set \(D\) in (11)
satisfies

\[
D\cap\{z,x_2,x_4\}=\varnothing.
\tag{13}
\]

Conversely, every \(D\) satisfying (11)--(13) for which the new colouring
is a rooted target gives another member of the complete family. Thus the
family in (WF) is the full set of rooted target states under arbitrary
target-preserving **multi-bond** toggles fixing these three terminals.
Single-bond connected components are strictly weaker data and cannot replace
this quantifier, as the order-24 counterexample to component saturation
shows.

The only unproved arrow left by the permitted inputs is therefore

\[
\boxed{
\begin{gathered}
\text{full terminal-fixed target closure under all multi-bond toggles}\\
\Longrightarrow
\text{one of the three sector incidences in (10) is a rooted forest.}
\end{gathered}}
\tag{14}
\]

Neither facewise NAE alone nor single-cycle exchange connectivity proves
(14): they do not couple different target-state components. A proof of
(14) must use a common-family incidence statement across multi-cycle
symmetric differences. A counterexample must realise a complete
terminal-fixed family in which every member fails all its eligible graphs
in (10).

## 5. A non-tautological sufficient condition

The reduction also gives a usable, strictly stronger sufficient condition.
Call \(A_L\) *clean for \(c\)* when

1. \(A_L\) alternates;
2. the components \(B(y)\), for the \(1\)-coloured \(y\in A_L\), are
   pairwise distinct;
3. at most one of those components also contains a \(0\)-coloured boundary
   vertex of \(A_R\); and
4. the two root marks already lie in the same component of \(P=R-z\).

Then \(I_L(c)\) is a forest by the exact collision criterion after (9), and
condition 4 makes the root marks joined without using any new local edge.
Thus row \(101\) lifts. The right-clean statement is symmetric.

This condition is not a renaming of liftability: condition 4 is stronger
than the exact root condition in (8), since a row can join two distinct
root blocks through its new star. Conditions 2 and 3 are independently
load-bearing: violating the former creates a parallel-edge cycle, while
violating the latter twice creates a four-cycle. It is therefore a genuine
reduced-forest sufficient condition, although the permitted inputs do not
show that every wide forced family contains a clean target.

## 6. Boundary

**Exact conclusion.** At arbitrary order, a complete target family forcing
both gates cannot lift through rows \(001\) or \(111\).  Its liftability is
equivalent to one member satisfying one of the three explicit rooted-sector
criteria \(I_L,I_R,I_{LR}\) in (10).

**Weakest load-bearing step.** Equation (3) identifies row \(111\) with the
reduced facial flip \(c\mapsto c^z\).  Completeness, not exchange
connectedness, then excludes that row: a successful facial flip would be a
reduced target with the same root and neither gate.  The three remaining
criteria are exact component quotients of the local monochromatic forests.

**Evidence level.** The result is proof-level and uses no order census.
The order-\(24\) component counterexample is used only to show why the
complete-family quantifier cannot be weakened.

**Unresolved boundary.** The arbitrary-order wide complete-family statement
is equivalent to implication (14).  A proof must couple different
single-cycle components through common multi-cycle perfect-matching
incidence; a counterexample must realize a complete terminal-fixed family
whose every member fails all eligible sector graphs.  No order-\(26\) or
larger graph is examined here.
