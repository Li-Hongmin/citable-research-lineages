> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One adjacent nonleaf pair splices; 102-vertex failures must split it

[Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) leaves exactly one marked unary ordinary node in either 102-vertex single-hexagon failure profile. The two special positions assigned directly to that node can lie before its unique child, one on each side, or after it. In the first and third positions they are consecutive on the old Hamilton cycle. One adjacent pair can be left unswitched without losing the leaf-square splice.

## One-unsupported-edge theorem

Use the square-supported edges \(E=\{x_i y_i\}\), disjoint four-vertex squares \(h_i x_i y_i j_i h_i\), and spanning union of cycles \(D\) from the square-switch theorem of Note 458. In addition choose an edge \(d=st\in E(D)\) whose endpoints are outside every square support. Let \(T\) consist of zero, two, or four endpoints of \(E\cup\{d\}\), and let \(M\) match all other endpoints of \(E\cup\{d\}\), using edges outside \(D\). Suppose \(D\cup M\) is connected.

**One-unsupported-edge theorem.** The graph \(D\cup M\cup\{h_i j_i\}\) has, respectively, a spanning cycle, a spanning path with endpoints \(T\), or spanning two-path covers with endpoints \(T\) in at least two different pairings. Every asserted cover contains \(M\) and avoids \(d\).

**Proof.** Set
\[
                         F_0=(D-E-\{d\})\cup M.
\]
Its components are cycles and, according to \(|T|=0,2,4\), zero, one, or two paths. Contract these components and represent all removed edges \(E\cup\{d\}\) in a multigraph \(Q\). It is connected because \(F_0\cup E\cup\{d\}=D\cup M\). For each component \(S\) of \(F_0\), the number of removed-edge endpoints in \(S\) is twice the number of \(M\)-edges in \(S\), plus the number of terminals in \(S\). The latter is zero or two, so every vertex of \(Q\) has even degree. A connected even-degree multigraph has no bridge. Consequently \(Q-d\) is connected, including when \(d\) is a loop.

Every nonloop edge of \(Q-d\) has the square switch (1) of Note 458. Choose a spanning tree of \(Q-d\). With zero or two terminals, its switches absorb all cycle components into one cycle or the unique path. With four terminals, remove one tree edge on the path between the two path components, absorb all cycle components into those two paths, and switch at the removed tree edge. This changes the terminal pairing. Square supports are disjoint from \(d\), so the switches remain available and never restore \(d\). \(\square\)

## Application to the two 102-vertex profiles

Let \(N\) be the unique marked unary node of either profile in Note 458, \(A\) its sole child word, and \(s<t\) its two directly assigned special positions. There are no other ordinary-chord endpoints or directly assigned special positions between \(s,t\) on the same side of \(A\). Thus if their relative order is \(s,t,A\) or \(A,s,t\), the old-cycle edge \(d=st\) exists. Every other assigned special position lies in a two-special leaf, where its old edge has the square support of Note 458. The edges and square supports are mutually disjoint.

In the chorded profile, use the root cycle \(C_W\) of [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md). Its four special terminals are the two inner site ports and the two mates of the exterior face chords. The remaining special endpoints are matched by the internal face chords \(M\), and \(C_W\cup M\) is connected. The one-unsupported-edge theorem gives two internal four-terminal pairings. One differs from the fixed pairing of the two exterior paths (4) in Note 457, so they form a parent Hamilton cycle through both site edges.

In the chord-free three-root profile, use the three disjoint root cycles \(C_1,C_2,C_3\) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). If the root face graph \(K\) is connected, their union with \(M\) is connected and the two-terminal assertion gives a spanning path between the inner site ports. The outside path (3) of Note 456 closes it through both site edges. If \(K\) is disconnected, Note 456's cut and crossing argument places both inner site ports in an isolated end root. When \(d\) lies in that root, apply the one-unsupported-edge theorem to its old arc closed by its root chord; when \(d\) lies elsewhere, apply Note 458's ordinary two-terminal square splice to the isolated root. In both cases the exterior path (4) or (5) of Note 456 visits the remaining vertices and closes the marked Hamilton cycle.

By [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), each parent cycle containing both site edges lifts to a Hamilton cycle of the reduced expanded child; the ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) reverse this conclusion for the original child. Therefore **a non-Hamiltonian 102-vertex reduced child with \(f=8\) must place the marked unary node's two directly assigned special positions on opposite sides of its unique child word**, in the order \(s,A,t\). This condition is necessary only; no failure graph is asserted to exist. \(\square\)
