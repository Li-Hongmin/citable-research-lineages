> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The alternating rainbow double chain is square-equivalent at every length

[Note 345](345-an-unbounded-alternating-double-block-chain-has-a-marked-hamilton-route.md)
constructs, for every \(m\ge1\), a \(16m\)-vertex
induced chain \(P_m\) of \(N=2m\) consecutive
\(J_3,J_1,\ldots,J_3,J_1\) doubly vacant blocks.
Its internal complementary matching is exactly
Note 345 (3)--(4), restricted to the blocks.
The four degree-two terminals of \(P_m\), in disk-boundary
order, are
\[
               (a_1,o_1,e_N,b_N).                       \tag{1}
\]
All other vertices have degree three inside the patch.
The nonlocal chord \(h_1j_N\) can span arbitrarily many
blocks, yet the entire chain has the complete Hamilton
signature of one square.

**Square-reduction theorem.** For every \(m\ge1\), the
vertex-spanning one-path and two-path linkage signatures
of \(P_m\) at (1) are exactly those of the labeled square
\((a',o',e',b')\) in the same cyclic order. Replacing an
induced disk copy of \(P_m\) with these four exterior
attachments by that square, or conversely, preserves
Barnette membership and every Hamilton-cycle decision
marked on exterior or attachment edges. It reduces
\(16m\) patch vertices to four, so a vertex-minimal
non-Hamiltonian Barnette graph contains no such induced
disk patch. In the selected compressed, gapless, tight-target
all-square opening, the replacement turns these \(2m\)
target-free double blocks into one short target-free
block. If all remaining vacancies occupy distinct
internal blocks, the parent has a Hamilton cycle through
both site edges and its legal site-expanded child is
Hamiltonian.

**Four spanning one-path states.** The terminal colours
are \(a_1,e_N\) on one side and \(o_1,b_N\) on the
other. Thus only four endpoint pairs are possible.
The full old-cycle path through \(D_1,\ldots,D_N\)
gives \(a_1b_N\). Note 345 (11)--(13) gives
\(o_1e_N\).

For \(a_1o_1\), define
\[
T_s=
\begin{cases}
(h_s,i_s,k_s,o_s,a_s,b_s,e_s,j_s),
                             &s\ge2\text{ even},\\
(h_s,o_s,a_s,b_s,e_s,i_s,k_s,j_s),
                             &s\ge3\text{ odd}.
\end{cases}                                               \tag{2}
\]
Then the route
\[
U_m=(a_1,b_1,e_1,i_1,k_1,j_1,
       T_2,T_3,\ldots,T_N,h_1,o_1)                    \tag{3}
\]
visits every patch vertex once. Its initial joins
\(a_1b_1,e_1i_1\) are face-side chords; each
\(j_sh_{s+1}\) between tuples and the final
\(j_Nh_1\) are the matching chords in Note 345 (4).
Within an even tuple, \(k_so_s\) is its \(J_1\)
face chord; within an odd tuple, \(e_si_s\) is
its \(J_3\) face chord. All other joins in (3)
are old-cycle edges.

The reflection
\[
\begin{array}{c|cccccccc}
v_s&a_s&o_s&h_s&i_s&k_s&j_s&e_s&b_s\\
\rho(v_s)&b_{N+1-s}&e_{N+1-s}&j_{N+1-s}&k_{N+1-s}&
i_{N+1-s}&h_{N+1-s}&o_{N+1-s}&a_{N+1-s}
\end{array}                                               \tag{4}
\]
reverses the old path and preserves every chord type in
Note 345 (3)--(4): \(J_3\) in an odd block becomes
\(J_1\) in an even block, the consecutive
\(j_sh_{s+1}\) chords reverse, and the outer
\(h_1j_N\) chord maps to itself. Thus \(\rho(U_m)\)
is a spanning \(e_Nb_N\) path. Equations (3)--(4),
the old path, and Note 345 (13) realize all four
colour-permitted one-path pairs.

**Two spanning two-path states.** For
\(\{a_1b_N,o_1e_N\}\), use the top path
\[
       A=(a_1,b_1,a_2,b_2,\ldots,a_N,b_N),             \tag{5}
\]
whose joins are face-closing chords and old-cycle
interblock edges. The disjoint bottom path consists
of the tuples
\[
\begin{split}
H_t={}&(o_{2t-1},h_{2t-1},i_{2t-1},e_{2t-1},
         j_{2t-1},k_{2t-1},\\
      &\quad i_{2t},h_{2t},o_{2t},k_{2t},
         j_{2t},e_{2t}),\qquad 1\le t\le m,
\end{split}                                               \tag{6}
\]
in increasing \(t\). Each tuple uses the odd-block
\(i e\), the cross \(k_{2t-1}i_{2t}\), and the
even-block \(ok\) chords; its other joins are old
edges. Consecutive tuples join by
\(e_{2t}o_{2t+1}\). Thus the bottom path runs
from \(o_1\) to \(e_N\), while (5) covers all block
corners.

For \(\{a_1o_1,e_Nb_N\}\), take the edge \(a_1o_1\)
as one path. If \(m=1\), the other path is
\[
e_2,j_2,h_1,i_1,k_1,i_2,k_2,o_2,h_2,j_1,
e_1,b_1,a_2,b_2.                                    \tag{7}
\]
Its non-old joins are \(j_2h_1,k_1i_2,o_2k_2,
h_2j_1,a_2b_2\). It covers every vertex except
\(a_1,o_1\).

For \(m\ge2\), let \(C\) be the full old-cycle path
through \(D_3,\ldots,D_{N-2}\), from \(a_3\)
to \(b_{N-2}\); it is empty when \(N=4\).
The other path is
\[
\begin{split}
Q_m={}&(e_N,j_N,h_1,i_1,e_1,b_1,\,
       a_2,o_2,h_2,j_1,k_1,i_2,k_2,j_2,e_2,b_2,\\
      &C,\,
       a_{N-1},o_{N-1},h_{N-1},i_{N-1},k_{N-1},
       i_N,k_N,o_N,h_N,j_{N-1},e_{N-1},\\
      &b_{N-1},a_N,b_N).
\end{split}                                               \tag{8}
\]
When \(C\) is empty, the join \(b_2a_3\) is an
old-cycle edge; otherwise the joins into and out
of \(C\) are old-cycle edges. The non-old joins at
the beginning are \(j_Nh_1,i_1e_1,h_2j_1,
k_1i_2\). At the final two blocks they are
\(k_{N-1}i_N,k_No_N,h_Nj_{N-1},a_Nb_N\).
All others are old-cycle edges. The first piece
uses \(h_1,i_1,e_1,b_1\), the second uses
\(k_1,j_1\) and all of \(D_2\), \(C\) uses
the intermediate blocks, and the last piece uses
all of \(D_{N-1}\) and the six as-yet-unvisited
vertices of \(D_N\). Its first two vertices
\(e_N,j_N\) complete \(D_N\). Hence (8) visits
every vertex except \(a_1,o_1\), exactly once.

The third pairing \(\{a_1e_N,o_1b_N\}\) joins
same-colour terminals and interlaces the boundary
order, so it is impossible. Equations (5)--(8)
are exactly the square's two spanning two-path
states. A global Hamilton cycle crosses the
four-attachment patch cut in two or four edges;
replacing its spanning path or path pair with the
same state on the other side keeps every exterior
edge and attachment decision. This gives the
two-way Hamilton transfer.

**Barnette preservation.** The two paths in (5)--(6)
are disjoint and spanning. Contract their interiors
to the edges \(a_1b_N\) and \(o_1e_N\), retain
the old edges \(a_1o_1,e_Nb_N\), and delete surplus
edges. This yields the labeled square as a planar
minor of \(P_m\). Conversely, the two-page disk
embedding of Note 345 inserts \(P_m\) into a square
with the same terminal order and colours.

Deleting one vertex leaves \(P_m\) connected:
each face-closed block cycle remains connected,
and every adjacent pair of blocks still has at
least one of the vertex-disjoint joins
\(b_sa_{s+1}\) and \(j_sh_{s+1}\).
After deleting any two patch vertices, every
surviving component contains a surviving terminal.
Otherwise it would disconnect from the nonempty
exterior in Note 345's explicit three-connected
realization. In any three-connected cubic host,
the exterior of a four-attachment patch is
connected, since two exterior components would
each need at least three of the four attachment
edges. The four-attachment deletion comparison
of [Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
now applies in both directions; a square has
the same connectivity properties. Hence the
replacement preserves three-connectivity.
The four distinct degree-two terminals, matching
colours and disk embedding preserve cubicity,
simple structure, bipartiteness and planarity.

For a selected opening, map the old-cycle path
through \(P_m\) to \(a',o',e',b'\) and its
block-closing common-face arc to \(a'b'\).
The two exterior matching attachments at
\(o_1,e_N\) retain their order. This creates
one short target-free block without changing
site edges, targets, gaps or other groups.
Apply Note 324 after compression under the
stated extra vacancy hypothesis, lift its
marked parent Hamilton cycle through the exact
signature above, and use
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
for the legal child. \(\square\)

The theorem covers precisely the induced matching
word in Note 345. It does not say every alternating
\(J_3/J_1\) chain has this word or that every
four-or-more-double group reduces to a square.
Other internal chord types, singly vacant blocks
in the same group, target defects, positive gaps,
nonsquare residual cycles and the general Barnette
conjecture remain open. This is a project-internal
analytic proof, without an external priority or
independent-review claim.
