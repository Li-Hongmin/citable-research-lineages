> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Vacancy squares absorb across arbitrarily long short-block ladders

[Note 216](216-adjacent-vacancy-square-is-absorbed-by-a-five-edge-detour.md)
absorbs an alternating square made by vacancies in adjacent face
blocks. The same square can be absorbed when the blocks are separated
by any number of short face blocks. Those blocks form the even
four-terminal ladder of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).

Use the compressed all-square opening and notation of
[Notes 195--197](197-gapless-square-trap-defect-budget.md).
Assume \(\ell,r\ge1\), empty interblock gaps, tight target
order, and precisely two eligible vacancies in distinct target-free
face blocks \(B_k,B_m\), \(1\le k<m\le r\). Write their free
interior slots in old-cycle order as
\[
B_k:o_k,h_k,i_k,e_k,\qquad
B_m:o_m,h_m,i_m,e_m.                                      \tag{1}
\]
Assume every intermediate block \(B_{k+1},\ldots,B_{m-1}\)
is short and that the free complementary matching is
\[
M_{\rm free}=\{e_jo_{j+1}:0\le j\le r\}
 \cup\{h_ki_m,\ i_kh_m\}.                                 \tag{2}
\]
At this surplus \(f=4r+6\), (2) lists every free matching edge.

**Ladder-bridge absorption theorem.** The parent has a Hamilton
cycle containing both site edges \(q=xy,p=uv\), and its legal
site-expanded child is Hamiltonian. The statement holds for
arbitrary positive original lobe lengths and unbounded \(m-k\).

**Proof.** Let \(A\) be the even-starting old-cycle matching
from \(x\). Tight target order gives Note 196's square-and-target
path (4). Its ordinary free path (5), using the chain in (2),
misses exactly \(h_k,i_k,h_m,i_m\). On those four vertices,
\(M\cup A\) is the separate alternating square
\[
h_k,i_k,h_m,i_m,h_k,                                     \tag{3}
\]
where \(h_ki_k,h_mi_m\in A\) and the other two edges are in (2).

Put \(t=m-k-1\). For \(t=0\), replace the free path edge
\(e_ko_m\) by
\[
e_k,i_k,h_k,i_m,h_m,o_m.                                  \tag{4}
\]
This is Note 216's five-edge detour.

For \(t\ge1\), the vertices of the short blocks
\(B_{k+1},\ldots,B_{m-1}\) induce \(L_{2t}=P_{2t}\square K_2\).
Each block \(B_j\) is the square \(a_j,o_j,e_j,b_j\);
successive blocks have rail edges \(b_ja_{j+1}\in C\) and
\(e_jo_{j+1}\in M\). Its terminals are
\(a_{k+1},o_{k+1},b_{m-1},e_{m-1}\).
Note 178, equation (3), supplies two disjoint paths covering
the ladder, with endpoint pairs
\[
P_L:a_{k+1}\longleftrightarrow o_{k+1},\qquad
P_R:e_{m-1}\longleftrightarrow b_{m-1}.                   \tag{5}
\]
In Note 196's free path, replace the segment from \(b_k\)
through these blocks to \(a_m\) by
\[
\begin{split}
b_k,&\ a_{k+1}\ \xrightarrow{P_L}\ o_{k+1},
 e_k,i_k,h_k,i_m,h_m,o_m,\\
&e_{m-1}\ \xrightarrow{P_R}\ b_{m-1},a_m.
\end{split}                                               \tag{6}
\]
The joins, in order, are
\(b_ka_{k+1}\in C,\ o_{k+1}e_k\in M,\ e_ki_k\in C,\)
\(i_kh_k\in A,\ h_ki_m\in M,\ i_mh_m\in A,\)
\(h_mo_m\in C,\ o_me_{m-1}\in M,\ b_{m-1}a_m\in C\).
The two ladder paths cover each intermediate vertex once;
the four other new internal vertices are exactly those of (3).
Thus (6) is a spanning replacement with the same endpoints.
It changes neither site edge and is disjoint from the
square-and-target path. Their union is a marked Hamilton cycle.
Note 001 lifts it through the legal site expansion; Note 178
restores longer original lobes. \(\square\)

**Realization at every bridge length.** For each \(r\ge2\)
there is a Barnette parent satisfying (1)--(2) with
\(\ell=1,k=1,m=r\), hence \(t=r-2\). Take a cycle \(C\)
in the following order, with consecutive blocks joined by
cycle edges:
\[
\begin{array}{ll}
B_0:&x,R_1,e_0,y,\\
B_1:&a_1,o_1,h_1,i_1,e_1,b_1,\\
B_j:&a_j,o_j,e_j,b_j\quad(2\le j\le r-1),\\
B_r:&a_r,o_r,h_r,i_r,e_r,b_r,\\
B_{r+1}:&u,o_{r+1},L_1,v,\\
\text{last arc}:&\alpha_1,\gamma_1,\delta_1,\beta_1,
\text{ returning to }x.
\end{array}                                               \tag{7}
\]
Add the perfect matching
\[
\begin{split}
M={}&\{xy,uv,\alpha_1\beta_1,\delta_1R_1,\gamma_1L_1\}\\
&\cup\{a_jb_j:1\le j\le r\}
\cup\{e_jo_{j+1}:0\le j\le r\}
\cup\{h_1i_r,i_1h_r\}.
\end{split}                                               \tag{8}
\]
Every matching pair has opposite parity on \(C\), so this
graph is cubic and bipartite. Draw
\(xy,a_1b_1,\ldots,a_rb_r,uv,\alpha_1\beta_1\)
on one side of \(C\); these chords occupy disjoint consecutive
intervals. Draw the other matching edges on the other side.
There, \(\delta_1R_1\) encloses the remaining chords,
\(h_1i_r\) encloses \(i_1h_r\) and the intermediate chain
edges, and all other chords are disjoint or nested. This is
a plane embedding. The face outside the consecutive first-side
chords contains \(xy,uv\); its \(v\)-to-\(x\) arc is
\(v,\alpha_1,\beta_1,x\), supplying the one-square facial opening.

To verify three-connectivity, regard matching edges as chords
of \(C\), joined in an *interlacement graph* when their
endpoints alternate around \(C\). The following is a connected
spanning subgraph of that interlacement graph:
\[
xy-e_0o_1-a_1b_1-e_1o_2-a_2b_2-\cdots-
a_rb_r-e_ro_{r+1}-uv-\gamma_1L_1-
\alpha_1\beta_1-\delta_1R_1-xy,                           \tag{9}
\]
with \(h_1i_r,i_1h_r\) both joined to \(a_1b_1\).
Every indicated alternation follows from (7). In a cubic
Hamiltonian graph, a two-edge cut would consist of two
cycle edges, bounding a proper consecutive \(C\)-interval
closed under its complementary matching. Matching chords
inside this interval cannot interlace those outside it,
contrary to (9). The Hamiltonian graph has no bridge,
so it is three-edge-connected and, being simple and cubic,
three-vertex-connected. It is therefore a Barnette graph
with \(4r+16\) vertices and \(f=4r+6\). The theorem gives
the marked parent Hamilton cycle.

The indicated site expansion is itself legal in the Barnette
class. Insert Note 001's four-vertex square inside the common
face; \(x,u\) have the same bipartition colour in (7), so its
eight gadget edges preserve bipartiteness. It is simple,
cubic and plane. To check three-edge-connectivity, suppose
the expanded graph had a cut of size at most two. If all four
patch vertices are on one shore, projecting that shore to
the old vertices gives a cut of the parent no larger than
the expanded cut: each restored site edge crossing the old
shore is witnessed by an attachment edge. If the patch is
split, at least two internal square edges cross the cut,
so no attachment can cross. Every old site endpoint then
lies on the shore of its attached patch vertex. A restored
edge \(uv\) crossing the old shore is witnessed by the
internal square edge \(ab\), and a restored \(xy\) crossing
it is witnessed by \(cd\); all other old cut edges are
unchanged. Again the parent has a cut of size at most two,
a contradiction. Thus the child is three-connected.
The theorem gives it a Hamilton cycle. \(\square\)

The specified paired-square matching is a sufficient profile.
Other same-group two-vacancy matchings, target-order defects,
gaps and nonsquare residual cycles are not classified here.
[Note 221](221-every-isolated-two-vacancy-corridor-has-a-marked-hamilton-cycle.md)
later handles every matching when the two vacant blocks
form an isolated free group.
