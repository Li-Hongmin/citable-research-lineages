> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Even fully alternating two-gate targets need not lift

[Note 065](065-the-degree-four-reduction-has-a-realizable-locked-nae-boundary.md)
shows that a reduced prescribed-edge target can fail to lift when both gate
arcs are nonalternating. [Note 066](066-existence-level-c4-lifting-survives-through-reduced-order-eighteen.md)
then replaces arbitrary-witness lifting by selection from the complete target
family. This note proves that the locked/nonlocked distinction is not the
complete witness-level boundary: a genuine plane brace has a reduced target
whose two gate arcs are both fully alternating, but none of the eight local
assignments is a target lift.

The complete target family at the same interface still has liftable members.
Thus the counterexample closes another witness-by-witness route without
refuting existence-level \(C_4\) lifting or RCA.

## Explicit reduced target

Let \(F'\) be the 20-vertex simple plane cubic bipartite brace with graph6
string

    S???????F?Y?b?W_DO?Y?DG?Oo?E_?B_?

Its dual \(T'\) has vertices \(0,\ldots,11\). At

\[
z=3
\]

use the facial rotation

\[
(0,1,6,11,10,7,5,4)
\tag{1}
\]

and gates \(0,10\). The two closed arcs are

\[
A_1=(0,1,6,11,10),\qquad
A_3=(10,7,5,4,0).
\tag{2}
\]

Splitting \(z\) along (2) and adding the degree-four centre gives a simple
4-connected Eulerian plane triangulation \(T\); its dual is the 24-vertex
brace

    WhEK?G@?i??O?BGA??WA??GC????@G?gG??K??CGO??a??P

Take the unchanged root edge

\[
a=02
\tag{3}
\]

and the reduced colouring

\[
\begin{aligned}
c'^{-1}(0)&=\{0,2,3,5,6,8,10\},\\
c'^{-1}(1)&=\{1,4,7,9,11\}.
\end{aligned}
\tag{4}
\]

Its monochromatic graph has three components, total cycle rank one, and
its unique cycle contains \(02\). Hence (4) is an exact reduced target.
Both gate neighbours have the colour of \(z\), while the two words along
(2) are

\[
01010,\qquad01010.
\tag{5}
\]

Thus both gates are used and both sectors are alternating. This is the
strongest locally flippable row, not the locked state of Note 065.

## All local assignments fail

Write \((\lambda,\rho,d)\) for the colours of the two split copies and the
new centre, normalized by \(c'(z)=0\). The complete table is

\[
\begin{array}{c|c|c|c|c}
(\lambda,\rho,d)&\mathrm{NAE}&\operatorname{comp}H(c)&
\beta(H(c))&a\text{ on a monochromatic cycle}\\ \hline
000&\text{no}&-&-&\text{no}\\
001&\text{yes}&4&2&\text{yes}\\
010&\text{no}&-&-&\text{no}\\
011&\text{yes}&2&0&\text{no}\\
100&\text{no}&-&-&\text{no}\\
101&\text{yes}&4&2&\text{yes}\\
110&\text{yes}&3&1&\text{no}\\
111&\text{yes}&4&2&\text{no}
\end{array}
\tag{6}
\]

A target needs cycle rank one and the root on that unique cycle. No row of
(6) has both properties. In particular, the three natural nonneutral rows
\(011,101,110\) respectively remove the cycle, create a second cycle, or
move the unique cycle away from the root. Full arc alternation therefore
does not determine the rooted connectivity test in Note 065(5).

## Primal matching certificate

The primal edge corresponding to \(a=02\) is \(e=0\,10\). The two gate
edges are \(1\,11\) and \(9\,18\), and the perfect matching induced by (4)
is

\[
\begin{split}
M=\{&0\,10,1\,11,2\,14,3\,17,4\,12,\\
    &5\,16,6\,13,7\,15,8\,19,9\,18\}.
\end{split}
\tag{7}
\]

The complement \(F'-M\) consists of exactly two cycles, and the ends of
\(e\) lie on different cycles. Thus the target and both-gate claims can be
checked without relying on the colouring interpretation.

The standalone verifier
[verify_nonlocked_arc11_witness_lift_counterexample.py](../computations/verify_nonlocked_arc11_witness_lift_counterexample.py)
checks the two triangulations, their exact split/reduction interface, both
dual brace conditions, the matching (7), the separated two-cycle
complement, and all eight rows of (6). It ends with

    NONLOCKED_ARC11_WITNESS_LIFT_COUNTEREXAMPLE_VERIFIED

## The complete family still escapes

For the root and split above, the complete reduced target family has nine
members modulo global colour complementation. Three are nonliftable: one
locked target and two nonlocked targets. The other six have target lifts.
The expanded triangulation itself has eleven rooted targets modulo
complementation.

Consequently this is deliberately a counterexample to a local universal
quantifier,

\[
\forall c'\text{ target},\quad
c'\text{ nonlocked}\Longrightarrow c'\text{ lifts},
\tag{8}
\]

not to the family-selection statement

\[
\mathcal T_e\ne\varnothing
\Longrightarrow
\mathcal T_e\text{ contains some liftable target}.
\tag{9}
\]

## Boundary

**Exact conclusion.** Even simultaneous alternation of both gate arcs does
not force a fixed reduced target to lift. The component partition and root
marking in Note 065(5) remain indispensable.

**Weakest load-bearing step.** The counterexample is finite; its force comes
from the exhaustive eight-row profile (6), after exact verification that
the reduced and expanded objects are duals of braces.

**Evidence level.** This is a real, independently checkable plane-brace
counterexample to (8). It is not an abstract interface model.

**Unresolved boundary.** General existence-level lifting remains open.
Any positive proof must compare the complete target family through the
decorated rooted-connectivity states; neither gate count, lockedness, nor
arc alternation alone supplies the selection rule.
