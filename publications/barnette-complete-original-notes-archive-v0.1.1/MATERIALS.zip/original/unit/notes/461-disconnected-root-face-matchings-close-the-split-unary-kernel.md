> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disconnected root face matchings close the split-unary kernel

[Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) reduces a hypothetical 102-vertex single-hexagon failure to the chord-free three-root profile of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md), with the two directly assigned positions of its unique marked unary node on opposite sides of the node's child word. Here the face matching between the three roots has a decisive connectivity role.

Use the order and notation of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Let \(W_1,W_2,W_3\) be the ordinary root words, \(u,v\) the inner site ports, \(K\) the graph joining roots by their face-side matching chords, and \(N\) the unique nonleaf marked unary node. Write its local order as
\[
                              H,s,A,t,J,
\tag{1}
\]
where \(A\) is its unique child word. Let \(L,R\) be the first and last vertices of \(A\), so \(LR\) is an ordinary chord and \(sL,Rt\) are old-cycle edges. Every other assigned special position lies in a two-special leaf and has the square-supported old edge \(x_i y_i\) of Note 458.

**Disconnected-root theorem.** If \(K\) is disconnected, the reduced parent has a Hamilton cycle containing both site edges. Thus a non-Hamiltonian 102-vertex child in this profile requires \(K\) to be connected.

**Proof.** By the cubic-cut and crossing argument of Note 456, a disconnected \(K\) has one isolated root \(W\), necessarily \(W_1\) or \(W_3\), and both \(u,v\) lie in \(W\). The other two roots, together with all vertices outside \(W\), have the explicit spanning \(w_0\)--\(w_*\) path (4) or (5) of Note 456. It suffices to find a spanning \(u\)--\(v\) path inside \(W\); adjoining the two site edges then closes a Hamilton cycle.

If \(N\) lies outside \(W\), every assigned position in \(W\) belongs to a two-special leaf, and Note 458's two-terminal square splice gives the path. If \(N\subset W\), let \(C_W\) be the cycle formed by the old \(W\)-arc and its root chord, and let \(M_W\) be the matching of all leaf and \(s,t\) special positions in \(W\) other than \(u,v\). Every face chord incident with the isolated root is internal to \(W\), so this is a full matching of those positions.

Let \(E\) be the square-supported old edge at every two-special leaf in \(W\). Open \(C_W\) at \(sL,Rt\), remove \(E\), insert \(M_W\), and insert the child chord \(LR\):
\[
              F_{\rm in}
                =(C_W-E-\{sL,Rt\})\cup M_W\cup\{LR\}.
\tag{2}
\]
It has degree one precisely at \(u,v\). If a chord of \(M_W\) crosses from the vertex interval \(A\) to \(W\setminus A\), then (2) together with the deleted leaf edges \(E\) is connected. Square switches along a spanning tree of its component quotient absorb every cycle into the \(u\)--\(v\) path. If \(LR\) is itself a leaf-square chord, that leaf's deleted edge is a quotient loop and is not used.

Suppose no \(M_W\)-chord crosses the boundary of \(A\). The cut of the even-order interval \(A\) in the cubic parent has its two old-cycle boundary edges and whichever of the two site edges end in \(A\). Three-connectivity makes the cut at least four, while its size is even. Hence both \(u,v\) lie in \(A\). In particular \(s,t\) are matched by \(M_W\) outside \(A\). They cannot be matched to one another: their face chord \(st\) would interlace \(q=w_0u\), since \(w_0<s<u<t\) in the old-cycle order. Therefore an \(M_W\)-edge from \(s\) or \(t\) has its other endpoint outside \(N\). This also shows that \(N\) is not the root of \(W\), so its chord \(HJ\) is unused by \(C_W\).

Take the alternative opening
\[
              F_{\rm out}
                =(C_W-E-\{Hs,tJ\})\cup M_W\cup\{HJ\}.
\tag{3}
\]
It again has degree one exactly at \(u,v\). After adding back the leaf edges \(E\), the \(M_W\)-edge just identified connects the two old arcs separated by \(Hs,tJ\). Its leaf-edge component quotient is therefore connected, and square switches absorb every cycle into the \(u\)--\(v\) path. The exterior path of Note 456 then completes the marked parent cycle. \(\square\)

**Remaining quotient bond when \(K\) is connected.** Take the three disjoint cycles \(D=C_1\cup C_2\cup C_3\) from Note 456, and let \(M\) match all assigned special positions except \(u,v\). Form
\[
                  F=(D-E-\{sL,Rt\})\cup M\cup\{LR\}.
\tag{4}
\]
Contract its components and represent the deleted edges \(E\cup\{sL,Rt\}\) in a multigraph \(Q\). As in [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md), \(Q\) is connected and every vertex has even degree: the removed-edge endpoints in any component are paired by its \(M\)-edges or by \(LR\), except for the zero or two site terminals. If \(Q-\{sL,Rt\}\) is connected, all its nonloop edges have leaf-square switches, yielding a spanning \(u\)--\(v\) path on \(D\), which the outside path (3) of Note 456 closes. Consequently a non-Hamiltonian 102-vertex child requires \(Q-\{sL,Rt\}\) to be disconnected. As \(Q\) is connected and bridgeless, this deletion produces exactly two components and the two unswitchable edges \(sL,Rt\) form a two-edge cut of \(Q\). This is a quotient condition; it does not assert a two-edge cut in the original Barnette graph.

Neither theorem covers the remaining connected-\(K\), split-node, two-edge-quotient-cut case, or other opening types.
