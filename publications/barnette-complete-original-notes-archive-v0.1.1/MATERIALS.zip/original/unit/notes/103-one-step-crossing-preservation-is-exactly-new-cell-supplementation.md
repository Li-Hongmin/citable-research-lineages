> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-step crossing preservation is exactly new-cell supplementation

[Note 101](101-a-c4-expansion-kills-an-inherited-fibre-crossing-exactly-at-an-11-site.md)
determines which members of a fixed-pairing fibre have target-preserving
lifts through a \(C_4\)-expansion.  [Note 102](102-the-unique-two-site-kill-cover-supplements-new-fibre-crossings.md)
shows in one finite example that the complete child fibre can replace every
killed crossing by new states.  This note isolates the exact arbitrary-order
interface between those two facts.

There are three, rather than one, genuinely new local cells in the child:
the noncanonical \(00\)-reconnection and two noncontractible cross patterns.
After all inherited crossings have been killed, a child crossing exists if
and only if an edge of the cross-sector single-cycle graph is incident with
one of these three cells.  A brace forces perfect matchings in every new
cell, but it does not force any of them into the fixed-pairing fibre.  Thus
one-step preservation is exactly a new-cell supplementation problem, not a
consequence of the inherited lift table alone.

## 1. Setup and the seven local patterns

Use the square-deletion setup of
[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
Let \(\mathcal L\) be the parent fixed-pairing spanning-two-path matching
fibre, split by a surviving gate \(g_1\) into \(\mathcal L^0\) and
\(\mathcal L^1\).  Expand two vertex-disjoint edges

\[
p=uv,\qquad q=xy
\tag{1}
\]

which are vertex-disjoint from the deleted root square and from the named
gates.  The child patch has edges

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\tag{2}
\]

The expansion then commutes with root-square deletion.  Saturating the four
new vertices \(a,b,c,d\), while using each old endpoint at most once, gives
exactly seven possible patch matchings:

\[
\begin{array}{c|c|c}
\text{cell}&\text{patch matching}&\text{parent relation}\\ \hline
C_{00}&\{ad,bc\}&\text{canonical lift of state }00\\
C_{10}&\{ua,bv,cd\}&\text{canonical lift of state }10\\
C_{01}&\{xc,dy,ab\}&\text{canonical lift of state }01\\
C_{11}&\{ua,bv,xc,dy\}&\text{canonical lift of state }11\\
R_{00}&\{ab,cd\}&\text{noncanonical }00\text{-reconnection}\\
X_{uy}&\{ua,bc,dy\}&\text{noncontractible cross pattern}\\
X_{vx}&\{ad,bv,xc\}&\text{noncontractible cross pattern}.
\end{array}
\tag{3}
\]

This list is complete by inspecting the mate of \(a\).  If \(a\) is
matched to \(b\) or \(d\), the remaining two new vertices are either
matched internally or both matched to old endpoints.  If \(a\) is matched
to \(u\), the remaining choices similarly give \(C_{10},C_{11}\), or
\(X_{uy}\).  The cases are disjoint by their patch edge sets.

The cell \(C_{11}\) is empty inside the child target fibre: its complement
contains the isolated cycle \(abcd\).  The first three cells are the
target-preserving lifts from Note 101.  A member of \(R_{00}\) contracts to
a parent perfect matching, but if it is a child target then that ancestor
does not lie in \(\mathcal L\): for a parent fibre member the reconnection
either changes the terminal pairing or cuts off a closed component.  The
patterns \(X_{uy}\) and \(X_{vx}\) do not contract to a parent perfect
matching, since contraction would leave respectively \(u,y\) or \(v,x\)
unmatched.

Put

\[
\mathcal C=C_{00}\mathbin{\dot\cup}C_{10}
             \mathbin{\dot\cup}C_{01},
\qquad
\mathcal N=R_{00}\mathbin{\dot\cup}X_{uy}
             \mathbin{\dot\cup}X_{vx}.
\tag{4}
\]

If \(\mathcal L^+\) denotes the complete child fibre, then (3) gives the
exact disjoint decomposition

\[
\boxed{\mathcal L^+=\mathcal C\mathbin{\dot\cup}\mathcal N.}
\tag{5}
\]

Some cells in (5) may of course be empty.

## 2. The canonical induced crossing graph

For a gate-split fibre \(\mathcal F=\mathcal F^0\dot\cup\mathcal F^1\),
let \(\Gamma(\mathcal F)\) be the bipartite graph with vertex set
\(\mathcal F\), where \(M\in\mathcal F^0\) and
\(N\in\mathcal F^1\) are adjacent exactly when
\(M\triangle N\) is one alternating cycle.

The canonical lift preserves the gate bit and gives a bijection

\[
\mathcal C\cong
\mathcal L\setminus\mathcal L_{11},
\qquad
\mathcal L_{11}=\{M\in\mathcal L:p,q\in M\}.
\tag{6}
\]

For two canonical lifts, their local symmetric difference merely replaces
an occurrence of \(p\) or \(q\) by a path with the same old endpoints.
Every parent component is therefore subdivided and no two components are
joined.  Hence

\[
\#\operatorname{comp}(\widehat M\triangle\widehat N)
=\#\operatorname{comp}(M\triangle N).
\tag{7}
\]

Equations (6)--(7) identify the full induced canonical crossing graph:

\[
\boxed{
\Gamma(\mathcal L^+)[\mathcal C]
\cong
\Gamma(\mathcal L)-\mathcal L_{11}.}
\tag{8}
\]

Thus the site kills every inherited cross-sector single-cycle edge exactly
when

\[
\boxed{
\mathcal L_{11}\text{ is a vertex cover of }
\Gamma(\mathcal L).}
\tag{9}
\]

This is the graph-theoretic form of the pairwise \(11\)-criterion of
Note 101.

## 3. Exact supplementation criterion

Assume (9).  By (8), no child crossing has two canonical endpoints.  It
follows immediately from (5) that

\[
\boxed{
\Gamma(\mathcal L^+)\ne\varnothing
\iff
\text{some edge of }\Gamma(\mathcal L^+)
\text{ is incident with }\mathcal N.}
\tag{10}
\]

Equivalently, there are \(X\in\mathcal N\) and one \(X\)-alternating
cycle \(A\) such that

\[
X\triangle E(A)\in\mathcal L^+,
\qquad g_1\in E(A).
\tag{11}
\]

The last condition records that the two endpoints lie in opposite gate
sectors.  Therefore (10)--(11) are not merely sufficient: once the old
crossing graph is covered by \(11\)-states, they are the necessary and
sufficient one-step crossing-preservation condition.

## 4. What the brace axiom supplies

If the child is a brace, its \(2\)-extendability forces a perfect matching
in each new patch cell.  Indeed, extend respectively the three independent
edge pairs

\[
\{ab,cd\},\qquad
\{ua,bc\},\qquad
\{ad,bv\}.
\tag{12}
\]

The first pair forces the local pattern \(R_{00}\).  In the second case,
the only possible mate of \(d\) is \(y\), forcing \(X_{uy}\); in the third,
the only possible mate of \(c\) is \(x\), forcing \(X_{vx}\).

This is strictly weaker than (11).  Two-extendability does not say that any
of these perfect matchings has a complement with no closed component and
the prescribed terminal pairing.  It also does not select the required gate
sector or a single alternating-cycle neighbour.  This is precisely the gap
between the square-fixed matching slice and the linkage fibre already
exhibited in [Note 089](089-two-extendability-reaches-the-square-fixed-slice-but-not-the-linkage-fibre.md).

## 5. Consequence and boundary

The general one-step statement

\[
\begin{gathered}
\text{parent legal-wide plane-brace fibre has a crossing},\\
\text{a disjoint legal facial }C_4\text{-expansion has a legal-wide}\\
\text{plane-brace child}
\end{gathered}
\Longrightarrow
\Gamma(\mathcal L^+)\ne\varnothing
\tag{13}
\]

is not decided by Notes 085--102.  Equations (9)--(11) identify its only
hard case exactly: when \(\mathcal L_{11}\) covers the parent crossing
graph, one must prove new-cell supplementation.  Note 102 verifies that
mechanism in one two-step graph, but its finite counts do not imply (11) in
arbitrary order.

The result also explains why tracking only contractible parent matchings
cannot settle (13): two of the three necessary new cells have no parent
perfect-matching ancestor at all.  Conversely, merely invoking the brace
axiom stops at (12), before the fixed-pairing and single-cycle requirements.

**Exact conclusion.**  For an interface-disjoint expansion, the canonical
child crossing graph is exactly the parent crossing graph with its
\(11\)-vertices deleted.  If those vertices cover all old crossings,
one-step preservation is equivalent to a crossing incident with one of
three explicit new patch cells.

**Unresolved boundary.**  It remains unknown whether planarity, the brace
axiom and the complete perfect-matching family force condition (11).  No
general preservation theorem or actual plane-brace counterexample is
claimed here.  [Note 104](104-a-facial-square-11-state-has-three-target-lifts-and-one-exceptional-crossing-profile.md)
proves target admission for opposite-edge expansions of a facial square.
[Note 105](105-opposite-edge-expansion-of-a-facial-square-preserves-every-fibre-crossing.md)
then excludes its only formal exceptional profile and proves that every
parent crossing survives in this square-face subcase.  Longer facial sites
retain the full boundary above.
[Note 107](107-cofacial-complete-family-supplementation-can-be-entirely-nondirect.md)
shows that, at a real longer-face legal-wide brace site, all new-cell
crossings can be supplied by nondirect targets even though no state-\(11\)
parent has a direct target lift.  Thus a proof of the remaining kill-cover
case must use the complete shared perfect-matching incidence rather than a
direct selection or abstract exchange-closure argument.
[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
gives an exact dual formulation of that shared incidence as a rooted
split-bond lemma for 4-connected Eulerian triangulations.
