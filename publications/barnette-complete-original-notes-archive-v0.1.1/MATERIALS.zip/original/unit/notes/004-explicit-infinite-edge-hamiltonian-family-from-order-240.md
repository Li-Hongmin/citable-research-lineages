> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An explicit infinite edge-Hamiltonian Barnette family from order 240

Let \(G_0\) be the stored 240-vertex Barnette graph with graph6 SHA256

`1a45291660df221ace79b053604bae1256f74cb6e413ab76ba2b8c2d50ce308b`.

Use the oriented expansion site

\[
(u,v,x,y)=(48,51,112,97),\qquad p=48\,51,\quad q=97\,112.
\]

Among the 37 stored Hamilton cycles, take state-11 cycles 3, 31 and 35,
state-10 cycle 7, and the stored \(X_{uy}\) Hamilton path.  These witnesses
cover all 358 retained edges.  The original unsupplemented three-role core
misses 13 edges; within the stored family, two added cycles are necessary and
31,35 suffice.  This minimality is relative to the stored 37 cycles, not all
Hamilton cycles of \(G_0\).

Define \(G_{k+1}\) by expanding the selected central pair of \(G_k\).  If the
new square is \(a_kb_kc_kd_ka_k\), choose

\[
p_{k+1}=b_kc_k,\qquad q_{k+1}=d_ka_k.
\]

These are opposite edges of the new 4-face, so every step is a legal Barnette
\(C_4\)-expansion and

\[
|V(G_k)|=240+4k.
\]

Let \(\mathcal A_k,\mathcal B_k,\mathcal E_k\) be the witness families in
roles \(C_{11},C_{10},X_{uy}\).  Transfer them by

\[
\mathcal A_{k+1}\leftarrow\mathcal B_k,qquad
\mathcal B_{k+1}\leftarrow\mathcal E_k,qquad
\mathcal E_{k+1}\leftarrow\mathcal A_k.
\]

Their sizes rotate

\[
(3,1,1)\to(1,1,3)\to(1,3,1)\to(3,1,1).
\]

By Note 003, their support covers every retained old edge and all eight edges
of every new gadget at every stage.  The base graph is edge-Hamiltonian by its
stored 37-cycle cover.  Therefore

\[
\boxed{\{G_k:k\ge0\}\text{ is an explicit infinite family of
edge-Hamiltonian Barnette graphs}.}
\]

This theorem concerns one recursively selected central chain.  It does not
cover arbitrary expansion choices and does not resolve Barnette's conjecture.

The lightweight verifier is
`scratch/worker-barnette/verify_n240_persistent_core.py`.
