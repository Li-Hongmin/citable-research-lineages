> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The `to,hJ` single–double corridor has three matching tiers and a marked route

[Note 382](382-isolated-single-double-corridors-couple-j0-and-j2-at-every-length.md)
reduces an isolated single–double corridor with no internal free chord in
the double block to the first-mate branches `to` and `tJ`.
[Notes 383–384](384-delayed-single-double-return-has-two-cutpoints-and-a-marked-route.md)
settle the latter branch. [Note 381](381-a-cross-return-single-double-corridor-has-the-square-signature-at-every-length.md)
gives one `to,hJ` word. The present theorem classifies **every** word in
the `to,hJ` subbranch and supplies a spanning route for each.

Use a compressed, gapless, tight-target all-square selected opening of a
Barnette parent. Fix an ordinary target-free free group, with no short
flanks, in old-cycle order
\[
 V=(a,o,h,i,e,b),\qquad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\qquad
 D=(A,O,H,I,K,J,E,B),\qquad m\ge1.                 \tag{1}
\]
The even left and odd right free endports are \(t,z\). Other groups are
unrestricted. Let \(M\) be the complementary matching of the selected
old Hamilton cycle. Assume that \(D\) has no internal free matching
chord and \(to,hJ\in M\).

Write \(L=\{q_jp_{j+1}:1\le j<m\}\). There are three types of internal
matching word, where `internal` excludes the two endport edges:
\[
\begin{aligned}
 T_m^0={}&\{hJ,iK,eI,p_1H,q_mO\}\cup L;\\
 T_{m;r}^1={}&\{hJ,iK,ep_1,q_rI,p_{r+1}H,q_mO\}
       \cup\bigl(L\setminus\{q_rp_{r+1}\}\bigr),
       &&1\le r<m;\\
 T_{m;r,u}^2={}&\{hJ,iq_r,ep_1,p_{r+1}K,q_uI,
                    p_{u+1}H,q_mO\}\\
       &\quad\cup\bigl(L\setminus
                    \{q_rp_{r+1},q_up_{u+1}\}\bigr),
       &&1\le r<u<m.
\end{aligned}                                                     \tag{2}
\]

**Three-tier return theorem.** Under the stated hypotheses the free-slot
matching of this group is exactly
\[
              \{to,Ez\}\cup T,
 \quad T\in\{T_m^0,T_{m;r}^1,T_{m;r,u}^2\},              \tag{3}
\]
with unique parameters. Thus there are precisely
\(1+(m-1)+\binom{m-1}{2}=1+\binom m2\) possible words.
Every word (3) occurs in a \(26+4m\)-vertex Barnette parent with a
Hamilton cycle through both site edges and a legal Hamiltonian
site-expanded child. More generally, each induced block interval (1)
has a spanning \(o\)--\(E\) path. If all vacancies outside this group
lie in distinct internal blocks, the path composes with the routes of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
to give a marked Hamilton parent cycle and Hamiltonian child.

**Classification.** In the free-slot order
\[
 t,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,O,H,I,K,J,E,z,          \tag{4}
\]
every cross-block matching chord is on the page opposite the common
face, by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
and chords on that page do not interlace. An opposite-page chord that
skips a nonempty proper run of complete short blocks and traps all its
free slots would make that run matching-closed; its two boundary
old-cycle edges would be a forbidden two-edge cut. We apply this
short-block rule below. Since \(hJ\) is fixed, the only two free slots
right of \(J\) are \(E,z\), so \(Ez\in M\). Also \(oe\notin M\) because
\(o\) is matched to \(t\).

Inside \(hJ\), \(i\) can meet \(q_r,H\), or \(K\). The choice \(iH\)
leaves \(I,K\) on its right inside \(hJ\); they cannot meet across
\(iH\) and their mutual edge is an old-cycle edge. Thus either
\(iK\) or \(iq_r\) occurs.

If \(iK\) occurs, \(e\) can meet \(p_s,O\), or \(I\). The choice
\(eO\) traps all complete short blocks. An edge \(ep_s\) with
\(s>1\) traps \(S_1,\ldots,S_{s-1}\), so the only short-slot choice
is \(ep_1\). If instead \(eI\) occurs, \(H\) must meet \(p_1\):
meeting a later \(p_s\) would trap the preceding short-block run.
The slot \(O\) must then meet \(q_m\); an earlier \(q_j\) would trap
the trailing run. All remaining short slots pair by the ordinary
links in \(L\), giving \(T_m^0\).
If \(ep_1\) occurs, \(I\) must meet some \(q_r\). The choice
\(r=m\) strands the old-cycle pair \(O,H\) inside \(q_mI\), so
\(r<m\). Noninterlacement makes \(H\) meet a \(p_s\) with \(s>r\);
the short-block rule forces \(s=r+1\). It also forces \(q_mO\)
and all links other than \(q_rp_{r+1}\), giving \(T_{m;r}^1\).

Finally suppose \(iq_r\) occurs. Its enclosed slots force
\(ep_1\) and \(q_jp_{j+1}\) for \(j<r\). The slot \(K\) cannot use
an internal double-block chord or cross \(hJ\); it must meet
\(p_s\) with \(s>r\). Skipping the intervening complete blocks
is forbidden, so \(s=r+1\). Inside \(p_{r+1}K\), \(I\) must meet
some \(q_u\) with \(u\ge r+1\). The choice \(u=m\) strands
\(O,H\), so \(u<m\). The slot \(H\) must meet \(p_{u+1}\) by the
same short-block rule. The remaining slots force \(q_mO\) and
all ordinary links except at \(r,u\). This gives \(T_{m;r,u}^2\).
The matching partners of \(i\) and \(I\) recover the tier and
parameters uniquely. The three displayed words are noncrossing,
perfect matchings of all free slots in (4).

**Spanning routes.** Put
\[
 W_{v:w}=(p_v,c_v,d_v,q_v,\ldots,p_w,c_w,d_w,q_w)
 \quad (v\le w),                                             \tag{5}
\]
where adjacent short blocks are joined by \(q_jp_{j+1}\).
For the reverse sweep of the first run put
\[
 U_{1:r}=(c_1,d_1,c_2,d_2,\ldots,c_r,d_r,
           q_r,p_r,q_{r-1},p_{r-1},\ldots,q_1,p_1).        \tag{6}
\]
Here \(d_jc_{j+1}\) is an old-cycle edge, \(c_jd_j\) a face
chord, \(d_rq_r\) and \(q_jp_j\) old-cycle edges, and
\(p_{j+1}q_j\) an ordinary matching link. Consequently
\(U_{1:r}\) covers exactly \(S_1,\ldots,S_r\).
The following are spanning paths with endpoints \(o,E\):
\[
\begin{array}{c|l}
 T_m^0 & o,a,b,e,i,h,J,K,I,H,\ W_{1:m},\ O,A,B,E\\
 T_{m;r}^1 & o,a,b,\ U_{1:r},\ e,i,h,J,K,I,H,
                   \ W_{r+1:m},\ O,A,B,E\\
 T_{m;r,u}^2 & o,a,b,\ U_{1:r},\ e,i,h,J,K,
                   \ W_{r+1:u},\ I,H,\ W_{u+1:m},\ O,A,B,E.
\end{array}                                                 \tag{7}
\]
The first row is [Note 381](381-a-cross-return-single-double-corridor-has-the-square-signature-at-every-length.md)'s
standard route. In the second row the joins from \(p_1\) to
\(e\) and from \(H\) to \(p_{r+1}\) are matching edges.
In the third they are \(p_1e,Kp_{r+1},q_uI,Hp_{u+1}\).
Every other join is displayed in (1), (2), (5), or (6).
Each row visits all \(14+4m\) vertices once. Adding
\(to,Ez\) gives a spanning \(t\)--\(z\) free-group route.

**Barnette realization and the marked cycle.** For each word, take
the old Hamilton order
\[
 x,R_1,e_0,y,\ V,S_1,\ldots,S_m,D,\
 u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x.              \tag{8}
\]
Complement it by the matching
\[
 \{xy,ab,c_jd_j\ (1\le j\le m),AB,uv,\alpha\beta,
   \delta R_1,\gamma L_1,e_0o,Eo_3\}\cup T,              \tag{9}
\]
where \(T\) is the chosen word (2). Every vertex is paired once,
and every matching edge joins opposite old-cycle parities.
Draw \(xy,ab,c_jd_j,AB,uv,\alpha\beta\) on the common-face
page. On the other page, \(\delta R_1\) encloses the other
chords, \(e_0o\) precedes the nested or disjoint word \(T\),
and \(Eo_3,\gamma L_1\) follow it. Thus the graph is simple,
cubic, bipartite and plane, with cofacial site edges \(xy,uv\).

The matching-chord interlacement graph is connected. Write
\(F_0=ab,F_j=c_jd_j,F_D=AB\). The exterior chords and
\(hJ\) contain the alternating chain
\[
 xy-e_0o-F_0-hJ-F_D-Eo_3-uv-\gamma L_1
        -\alpha\beta-\delta R_1-xy.                       \tag{10}
\]
Every free matching chord in \(T\) interlaces the face
chords of its endpoint blocks. In tier zero,
\(p_1H\) and \(q_mO\) join the first and last short-block
face chords to \(F_D\); all intermediate \(F_j\) are joined
by \(L\). In tier one, \(ep_1\) joins \(F_0,F_1\),
\(q_rI\) joins \(F_r,F_D\), \(p_{r+1}H\) joins
\(F_{r+1},F_D\), and \(q_mO\) joins \(F_m,F_D\);
all remaining adjacent \(F_j\) are joined by the surviving
links. In tier two the corresponding bridges are
\(ep_1:F_0F_1\), \(iq_r:F_0F_r\),
\(p_{r+1}K:F_{r+1}F_D\), \(q_uI:F_uF_D\),
\(p_{u+1}H:F_{u+1}F_D\), and \(q_mO:F_mF_D\).
The surviving links join all slots between these bridges.
Every free chord itself meets at least one \(F\), so this is
a connected spanning subgraph of the interlacement graph.
A two-edge cut of a cubic Hamiltonian graph would bound a
proper old-cycle interval closed under the complementary
matching, disconnecting that graph. The Hamilton cycle rules
out bridges. Hence the parent is three-edge-connected and,
in the cubic case, three-vertex-connected: it is Barnette.

For \(T=T_m^0\), [Note 381](381-a-cross-return-single-double-corridor-has-the-square-signature-at-every-length.md)
already gives a marked Hamilton cycle and legal child.
For either other tier, combine these two internally disjoint
\(x\)--\(v\) paths:
\[
\begin{split}
 &x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
 &x,y,e_0,\ [\text{the applicable }o\text{--}E
                       \text{ row of (7)}],\ o_3,u,v.
\end{split}                                                \tag{11}
\]
The second path begins with \(e_0o\), ends with \(Eo_3\),
and uses both site edges. The two paths cover all vertices.
The site expansion is legal: \(u\) is \(18+4m\) old-cycle
steps after \(x\), so they have the same bipartition colour.
The cut projection of [Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
preserves three-connectivity, and
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
lifts the marked cycle to a Hamilton child. The common-face
order and unchanged residual square give the claimed selected
opening. \(\square\)

Under the outside-vacancy hypothesis, Notes 324 and 382–384
and this theorem now leave only the no-internal-chord `to`
branch with \(h\) matched away from \(J\), up to old-cycle
reflection. Nothing here classifies those other `to` words,
proves a complete square signature for tiers one and two,
or resolves Barnette's conjecture. This is a project-internal
analytic proof, without local graph recomputation,
independent review or external priority claim.
