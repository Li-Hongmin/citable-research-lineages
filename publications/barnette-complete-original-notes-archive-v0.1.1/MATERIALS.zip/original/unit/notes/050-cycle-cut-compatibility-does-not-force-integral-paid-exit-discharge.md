> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cycle--cut compatibility does not force integral paid-exit discharge

[Note 049](049-primal-cycles-are-contracted-dual-cuts-and-exclude-the-six-label-blocker.md)
proves that every retained primal simple cycle is an exact cut of the
contracted dual rank graph.  That theorem eliminates the six-label blocker
of Note 048, whose rank endpoints contain an odd cycle.  The present note
shows that the cycle--cut axiom is not sufficient: a different six-label
system satisfies every cycle cut and every separate local block type, yet
all of its common bases exceed the binary budget.

## A cycle--cut-compatible blocker

Let the label-incidence graph have the two partitions

\[
\begin{aligned}
D_0&=\{e_0,e_1\},&
D_1&=\{e_2,e_3\},&
D_2&=\{e_4,e_5\},\\
C_0&=\{e_3,e_4\},&
C_1&=\{e_0,e_2\},&
C_2&=\{e_1,e_5\}.
\end{aligned}
\tag{1}
\]

Thus its six labels form the simple primal cycle

\[
D_0C_1D_1C_0D_2C_2D_0.
\tag{2}
\]

On rank vertices \(0,1,2,3\), assign

\[
e_0,e_1,e_2:01,\qquad
e_3,e_5:02,\qquad
e_4:23.
\tag{3}
\]

The rank graph \(Q\) is connected and loopless.  Taking \(0\) as the
possible contracted root, the \(D\)-block types are

\[
(\text{parallel},\text{path},\text{path}),
\]

and the \(C\)-block types are

\[
(\text{path},\text{parallel},\text{path}).
\]

The two parallel blocks share the possible root \(0\), and every block is
one of the actual local types.  The incidence graph has only the cycle
(2), and

\[
\{e_0,\ldots,e_5\}=\delta_Q(\{0,3\}).
\tag{4}
\]

Hence the complete cycle--cut condition of Note 049 holds exactly.

## The paid-exit trap

Activate the single \(C\)-block

\[
A=\{C_0\},\qquad c_A^{-1}(1)=\{e_3,e_4\},
\tag{5}
\]

and take the \(D\)-transversal

\[
R=\{e_0,e_2,e_4\}.
\tag{6}
\]

The labels \(e_0,e_2\) are an isolated double edge on

\[
W=\{0,1\},
\]

while \(e_4\) is the tree on the complementary vertices.  Thus \(W\) is
the unique violated proper graphic-rank shore, and

\[
c_A(R)=1=|A|.
\tag{7}
\]

The only removable internal label is \(e_2\), whose only boundary exit in
\(D_1\) is the paid label \(e_3\).  The boundary completion is

\[
B_0=R-e_2+e_3=\{e_0,e_3,e_4\},
\qquad c_A(B_0)=2.
\tag{8}
\]

All \(D\)-transversal spanning trees of \(Q\) are

\[
\mathcal B=
\bigl\{\{e_0,e_3,e_4\},\{e_1,e_3,e_4\}\bigr\}.
\tag{9}
\]

They differ in one \(D\)-block, so the full common-base graph is connected,
but both contain all of \(C_0\).  Consequently

\[
\boxed{\min_{B\in\mathcal B}c_A(B)=2>|A|=1.}
\tag{10}
\]

Cycle--cut compatibility, the separate triangle/path/root-parallel block
types, a shared possible root, and common-base connectivity therefore do
not imply integral paid-exit discharge.

## Label minimality

Consider the natural equal-cardinality class in which the two partitions
have \(r\ge2\) blocks each, every block has size two or three, their
incidence graph is simple and connected, and the connected rank graph has
\(r+1\) vertices.  A two-point rank violation with a boundary completion
requires \(r\ge2\).

For \(r=2\), both partitions must consist of two size-two blocks and the
incidence graph is \(C_4\).  Suppose one \(C\)-block is the active cost
block and an over-budget completion exists.  That active block is a
two-edge rank path and hence itself a common base.  The violating
transversal uses one active and one inactive parallel label.  If the
inactive \(C\)-block is a path, it is a zero-cost common base.  If it is
parallel, the unused inactive label is parallel to the violating pair, and
combining it with the other active label gives a cost-one common base.
Thus no four-label blocker exists.  This dichotomy is also exhausted
directly by the verifier.

A simple incidence system with \(r=2\) has at most four labels, whereas
\(r=3\) has at least six.  Five labels are therefore impossible in this
class.  Equations (1)--(10) realize the obstruction on six labels, proving
label minimality.

## Exact actual-site boundary

The countermodel is not an actual rooted plane site.  All six vertices of
its primal incidence cycle have degree two.  Restoring the two deleted
cubic vertices forces \(u\) to be adjacent to all three \(C\)-vertices and
\(a\) to all three \(D\)-vertices.  This is the unique cubic completion;
it is the cube, with
\(u\) and \(a\) antipodal.  They lie on no common face.  Since the eight
vertices are already cubic, no larger connected ambient completion can
preserve the six blocks unchanged.

Thus the next missing datum is not another binary cycle-space invariant.
It is the existence of a common connected cubic bipartite two-root
completion in which the deleted roots are cofacial with the prescribed
ordered site.  The present model is a strict abstract counterexample, not
an actual brace counterexample.  General integral paid-exit discharge at
actual sites remains open.

The explicit blocker, the four-label exclusion, the six-label incidence
shapes, and the antipodal-cube completion are checked by

    python3 \
      units/barnette/computations/verify_minimal_cycle_cut_paid_exit_blocker.py

with terminal marker
MINIMAL_CYCLE_CUT_PAID_EXIT_BLOCKER_VERIFIED.
