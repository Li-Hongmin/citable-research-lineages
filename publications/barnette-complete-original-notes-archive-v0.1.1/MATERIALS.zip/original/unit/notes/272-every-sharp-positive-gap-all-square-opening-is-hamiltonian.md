> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every sharp positive-gap all-square opening is Hamiltonian

[Note 267](267-all-same-block-sharp-positive-gaps-are-hamiltonian.md)
settles two capacity vacancies in one block and the case in
which a single support block lies between two singleton gaps.
[Note 271](271-distinct-sharp-vacancy-blocks-cannot-separately-support-gaps.md)
excludes two distinct blocks separately supporting the gaps.
The remaining assignment, both gaps entering one of two
one-vacancy blocks on the same side, creates a forbidden
two-edge cut.

Let \(G\) be a Barnette parent with an old Hamilton cycle
\(C\) avoiding disjoint cofacial matching site edges
\(p,q\). Select a legal all-square facial opening with
\(\ell,r\ge1\) and \(f=4r+8\), and compress its residual
square-trap lobes as in Note 178.

**Sharp positive-gap theorem.** If the selected opening has
a positive interblock gap total, then \(G\) has a Hamilton
cycle containing both \(p,q\). Its legal site-expanded
child is consequently Hamiltonian. The conclusion holds
for any placement of the gap slots and any positive lengths
of the original square-trap lobes.

**Proof.** The one-vacancy corollary of
[Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
and the free-vertex count force \(\sigma=T=2\). Thus there
are exactly two gap slots, \(g<h\), and exactly two capacity
vacancies. If both vacancies lie in one block, Note 267
provides the marked Hamilton cycle. Suppose they lie in
different blocks. Each gap slot must enter a vacancy block
by the gap-edge localization lemma of Note 258 and the
saturated-block theorem of Note 255. Note 271 excludes the
case in which the two gaps enter different blocks. Let
\(P\) be their common one-vacancy support block.

If the gaps are singleton gaps on opposite sides of \(P\),
the proof of Note 267's shared-middle-support corollary
excludes this distinct-vacancy placement: a target-bearing
support needs two face chords but has at most five free
slots, while a target-free support traps a matching-closed
interval. Otherwise \(P\) lies before
both gap slots or after both. Reflect the main segment
and interchange the site edges, as in Note 264, to take
\(P<g<h\). No gap precedes \(P\), so it is forward;
the gap slots have colours \(g=E,h=O\).

Note 268 gives exactly one face-side free matching chord
in \(P\). Both gap mates lie strictly between its
endpoints by Note 258's odd straddling parity. We use
the resulting four-free-slot run in two cases.

If \(P\) is target-free, it has capacity one and precisely
four interior slots \(u_1,u_2,u_3,u_4\), of colours
\(O,E,O,E\). Its only non-cycle same-block chord is
\(u_1u_4\); colour forces the other matching edges to be
\[
 u_3g,\qquad u_2h.                                  \tag{1}
\]
The latter opposite-side edge spans every complete block
between \(P\) and \(h\). It forbids an escape target
there by Note 203. Any free matching edge from an
intervening block to outside the consecutive \(C\)-interval
from \(P\)'s left endpoint through \(h\) would interlace
\(u_2h\) on the opposite side; a face-side free edge
stays within its complete block. All four slots of \(P\)
and both gap slots are already matched within the interval,
as are all block-closing chords. Hence this proper interval
is closed under the complementary matching and has only
its two boundary \(C\)-edges leaving it, contrary to
three-connectivity.

If \(P\) contains an escape target, the one-vacancy
four-run classification of Notes 258 and 269 puts its
unique face-side chord in the four consecutive free slots
\(c,H,I,e\) following its last target \(L_j\), with
colours \(O,E,O,E\). Here \(j\ge2\): if the last target
were \(L_1\), its own eligible position and the next
even position would give two vacancies in \(P\). Colour
forces
\[
 ce\quad\text{on the face side},\qquad
 Ig,\quad Hh\quad\text{on the opposite side}.   \tag{2}
\]
The edge \(Hh\) forbids every escape target between
\(H\) and \(h\). All free slots following \(L_j\) in
\(P\), and both gap slots, are matched within the
main prefix ending at \(h\) by (2). Every complete block
strictly between \(P\) and \(h\) lies inside the span of
\(Hh\). Its opposite-side free matching edges cannot
leave that span without interlacing \(Hh\), while any
face-side free chord stays within that complete block.
Thus all its free slots also match inside the prefix.

Take this main prefix from \(x\) through \(h\), together
with the residual-square suffix \(S_j,\ldots,S_\ell\).
Its earlier escape targets are exactly the targets through
\(L_j\), and all their matching edges enter the included
square suffix; all square matching edges and block-closing
chords are internal. A free matching edge from a slot
before \(L_j\) to a slot after \(h\) would straddle
\(L_j\), contrary to Note 203. The preceding paragraph
accounts for every free slot from \(L_j\) through \(h\).
Therefore this proper vertex set is matching-closed. It
has exactly two departing old-cycle edges, one after \(h\)
and one before the square suffix, precisely as in the
prefix-cut rule of Notes 193 and 197. This again
contradicts three-connectivity.

Every distinct-vacancy assignment is impossible. Note 267
handles every opening that
remains, and Notes 001 and 178 transfer its marked cycle
to the legal child and original lobe lengths. \(\square\)

This theorem closes the first positive-gap free-vertex
boundary for selected all-square facial openings. It makes
no assertion about gapless third-surplus openings,
nonsquare residual cycles, or arbitrary Barnette graphs.

**Structural reduction and size consequence.** In every
opening of the theorem, the two capacity vacancies are in
one block. Notes 262 and 264 identify the known simple
incident-edge cube inverse of Note 185 when that block
lies outside both gap slots;
Notes 266 and 267 identify an induced four-column ladder
inverse when it separates two singleton gaps. The inverse
remains in the Barnette class and reduces the opening to
\(f'=4r+2\) or \(f'=4r+4\), respectively, preserving the
two site-edge marks. Consequently a non-Hamiltonian legal
child admitting a selected all-square opening with a positive
gap total must satisfy
\[
 f\ge4r+10,\qquad |V(S_0)|\ge4r+2\ell+14.
\]
The first inequality uses Notes 258 and 272 and the evenness
of \(f\); the second uses \(|V(S_0)|=f+2\ell+4\).
