> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's short-third-leaf comb has a marked path

The row-IV word in [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,7)\), short leaf \(3\), and depths \((1,2,3,4,6,6,5)\) has a spanning marked path. Its last four leaves use the same two-face-chord splice as the corrected [Note 439](439-the-split-site-short-word-has-a-three-face-chord-marked-path.md).

Let
\[
\begin{aligned}
S_3&=(x_3y_3),&K&=F(U_5,U_6),&B&=F(K,U_7),\\
C&=F(U_4,B),&D&=F(S_3,C),&
E&=F(U_2,D),&W&=F(U_1,E),
\end{aligned}                                                     \tag{1}
\]
where all leaves other than \(S_3\) and all branches are full. The row-IV face matching contains \(y_2x_3,x_4y_5,x_5y_4\).

For a full branch \(T\), set
\[
J_T=(\lambda_0^T,\rho_0^T,\rho_1^T,\lambda_1^T,
     \lambda_2^T,\rho_2^T).
\tag{2}
\]
This is a bracket-only path from the outer left to the inner right vertex, visiting all six brackets. Let \(Z_K\) be the spanning \(y_5\)--\(x_5\) path obtained by deleting \(x_5y_5\) from the old-cycle-plus-outer-chord Hamilton cycle of \(K\), as in [Note 436](436-the-fourth-matching-three-odd-leaf-short-branch-has-a-marked-cycle.md), equation (3). Use the leaf and remaining bracket paths of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md).

**Marked-path theorem.** A spanning \(y_1\)--\(x_7\) path of the \(76\)-vertex word \(W\) is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,\quad
L_2\xrightarrow{Y_2^{-1}}y_2,\quad
x_3,y_3,R_3,L_3,\\
&\lambda_2^D\xrightarrow{P_D}\rho_2^D,\quad
C_r=\rho_0^C\xrightarrow{Q_C}\lambda_2^C,\quad
L_4,h_4,x_4,\quad
y_5\xrightarrow{Z_K}x_5,\quad
y_4,j_4,R_4,\quad
B_\ell=\lambda_0^B\xrightarrow{J_B}\rho_2^B,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{3}
\]
The three jumps \(y_2x_3,x_4y_5,x_5y_4\) are the listed face chords. Every other join between displayed pieces is an old-cycle edge:
\[
\begin{gathered}
L_1\lambda_2^W,\quad \rho_2^W\rho_0^E,\quad
\lambda_2^EL_2,\quad L_3\lambda_2^D,\quad
\rho_2^DC_r,\quad \lambda_2^CL_4,\quad
R_4B_\ell,\quad \rho_2^BR_7.
\end{gathered}                                                     \tag{4}
\]
The short-leaf piece \(x_3,y_3,R_3,L_3\) uses two old edges and its outer chord \(R_3L_3\). The two \(U_4\) portions partition that leaf, and \(Z_K\) spans all of \(K\). The other pieces are disjoint full leaves or complete bracket groups. Their counts are four full leaves \(U_1,U_2,U_4,U_7\) contributing \(24\), the short leaf contributing \(4\), \(K\) contributing \(18\), and five remaining full branch wrappers \(W,E,D,C,B\) contributing \(30\); thus (3) visits all \(76\) vertices once.

The two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), close (3) to a parent Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, gives a Hamilton cycle in every legal expanded child with word (1). Reflection gives the row-V conclusion. \(\square\)

Combining Notes 437--443 leaves six structurally necessary row-IV/V short-leaf words. Row VI, other kernels and Barnette's conjecture remain open.
