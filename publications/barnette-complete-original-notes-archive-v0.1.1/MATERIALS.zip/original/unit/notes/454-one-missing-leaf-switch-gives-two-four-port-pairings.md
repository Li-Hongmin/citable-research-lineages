> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One missing leaf switch still gives two four-port pairings

The four-eligible construction suggested by [Note 453](453-two-exterior-routes-close-every-two-eligible-chorded-hexagon-kernel.md) has a general form: the ordinary chords of full leaves let one attach every residual cycle to two open paths and then change the paths' terminal pairing. This closes the entire chorded single-hexagon \(f=7\) branch of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md), without classifying ordinary trees or face matchings.

## A two-pairing theorem

Let \(C_W\) be a cycle containing disjoint old-cycle edges \(e_i=x_iy_i\), for \(i\) in a nonempty set \(S\). For each *full* index \(i\), its six vertices occur consecutively on \(C_W\) in the order
\[
                 L_i,h_i,x_i,y_i,j_i,R_i,
\tag{1}
\]
and the graph also contains the chords \(L_iR_i,h_ij_i\). The six-vertex blocks for different full indices are vertex-disjoint. Assume that at most one index of \(S\) is not full. Let \(T\) be four distinct endpoints of the \(e_i\), and let \(M\) be a matching of all other endpoints of the \(e_i\), using chords of \(C_W\). No planarity or noncrossing assumption is made on \(M\).

**Two-pairing leaf theorem.** The graph consisting of \(C_W\), \(M\), and the stated full-leaf chords has spanning two-path covers with endpoints \(T\) in at least two distinct pairings. Consequently, any two vertex-disjoint exterior paths with endpoints \(T\), whose internal vertices are exactly those outside \(C_W\), can be joined to one of these covers to form a Hamilton cycle.

**Proof.** Begin with
\[
                        F_0=(C_W-\{e_i:i\in S\})\cup M.
\tag{2}
\]
Every vertex has degree two in \(F_0\), except the four terminals \(T\), which have degree one. Thus its components are two paths \(P_0,P_1\) and some number of cycles.

At a full leaf, suppose the left triple \((L_i,h_i,x_i)\) and right triple \((y_i,j_i,R_i)\) are in different components. Perform the *leaf switch*
\[
                 L_ih_i,\ j_iR_i
                 \quad\longmapsto\quad
                 L_iR_i,\ h_ij_i.
\tag{3}
\]
It preserves all degrees. If one component is a path and the other a cycle, (3) joins them into one path with the same two terminals; if both are cycles, it joins them into one cycle. If both are paths, it leaves two paths, each with one terminal from each original path, so their pairing changes. These statements follow by deleting one edge in each component and reconnecting the resulting pieces with the two cross edges. Switches at different leaves use disjoint vertices.

Form a multigraph \(Q\) whose vertices are the components of \(F_0\) and whose edges are the removed \(e_i\), with loops allowed. Contracting the components of \(F_0\) in the original cycle \(C_W\) shows that \(Q\) is connected and every vertex has even degree. In particular, \(Q\) has no bridge. Delete the edge corresponding to the possible nonfull leaf; the remaining full-edge graph \(Q^*\) is still connected.

Choose a spanning tree of \(Q^*\), and remove one edge \(e_*\) on its path between the vertices \(P_0,P_1\). This gives two rooted trees, one at each path component; all other vertices represent cycles. Process each tree outward from its root, using (3) at its edges. Each step attaches one as-yet-unattached cycle to the path at that root. At the end there are two spanning paths with the same terminal pairing as \(P_0,P_1\). The unused full edge \(e_*\) connects those two paths. Applying (3) at \(e_*\) yields a second spanning two-path cover with a different pairing. The exterior paths have one fixed pairing, so at least one of these two internal pairings differs from it; the union is one Hamilton cycle. The same construction works with more than one nonfull leaf whenever the remaining full-edge graph \(Q^*\) is connected. \(\square\)

**Two-terminal variant.** If \(T\) has two endpoints instead of four, the same assumptions give a spanning path between them. In (2) there is one path and some cycles. The same even-degree quotient remains connected after the possible nonfull edge is removed; switches along a spanning tree rooted at the path absorb every cycle. This variant can replace a root word with exactly two external special attachments by one spanning terminal path.

## Chorded single-hexagon consequence

In the doubly reduced \(f=7\) chorded single-hexagon normal form, the old \(W\)-arc and its outer ordinary chord \(W_\ell W_r\) form \(C_W\). Take \(S\) to be all seven leaves. The two exterior face chords have mates \(r_L<y_j\) and \(r_R>x_k\) in \(W\). Thus exactly four of the fourteen leaf special positions are external ports:
\[
                           T=\{r_L,y_j,x_k,r_R\}
\tag{4}
\]
The other ten leaf positions are paired by five face chords internal to \(W\), giving \(M\) in the theorem. The two fixed exterior routes (6) of Note 453 cover every vertex outside \(W\), have the four endpoints (4), and include both site edges \(q=w_0y_j,p=x_kw_*\). This application does not require an eligibility-parity classification of the leaves.

The \(c=32\) word has seven full leaves; the \(c=31\) word has exactly one short node and hence at most one nonfull leaf. The two-pairing theorem supplies an internal cover whose pairing differs from the exterior one, so every legal child in either reduced count has a parent Hamilton cycle containing \(p,q\). Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts this cycle to the expanded child, and the ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) lift Hamiltonicity back to the original child.

**Seven-face-chord corollary.** Every legal expansion in the chorded single-hexagon branch with \(f=7\) is Hamiltonian. Indeed, [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) reduces a hypothetical failure to \(c=31\) or \(32\); both counts are covered above. Its exclusion of \(c\le30\) uses Brinkmann--Goedgebeur--McKay's published 90-vertex theorem as stated in [Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md). This corollary concerns the selected chorded single-hexagon opening. [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) closes the chord-free \(f=7\) branch by a separate three-root splice. Other opening shapes and Barnette's conjecture remain undecided.
