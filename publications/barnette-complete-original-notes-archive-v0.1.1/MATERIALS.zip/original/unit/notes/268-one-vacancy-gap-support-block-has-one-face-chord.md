> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A one-vacancy gap-support block has exactly one face-side free chord

At the first positive-gap boundary, [Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
forces every gap slot to enter a block with a face-side
free matching chord. [Note 267](267-all-same-block-sharp-positive-gaps-are-hamiltonian.md)
settles the two-capacity-vacancy same-block branch. In the
remaining distinct-block branch, a one-vacancy support block
cannot carry a second face-side free chord.

Use the compressed all-square opening of Notes 193 and 195 in
a Barnette parent with old Hamilton cycle \(C\), complementary
matching \(M\), and \(\ell,r\ge1\). A block \(B\) has \(2K+2\)
interior slots and \(K\) eligible positions for nonfinal
\(L\)-targets. Say it has *one capacity vacancy* if exactly
\(K-1\) eligible positions are occupied by nonfinal
\(L\)-targets. The remaining eligible position may be free
or occupied by \(L_1\).

**One-vacancy gap-support theorem.** If a gap slot is matched
by \(M\) to a slot of a one-capacity-vacancy block \(B\),
then \(B\) has exactly one face-side free matching chord.

**Proof.** Note 258 supplies at least one such chord. If
\(K=1\), the block has only four interior slots, while
two face chords plus a distinct gap mate would need five.
Hence assume \(K\ge2\). A target-free block cannot have
only one capacity vacancy when \(K\ge2\), so \(B\)
contains a target.
It has \(K-1\) nonfinal \(L\)-targets and at least
\(K-2\) \(R\)-targets, hence at most five free slots.
Two face chords and the gap mate require five distinct
free slots. Equality forces exactly \(K-2\) \(R\)-targets,
excludes \(L_1\) from \(B\), and makes the target
subsequence start and end with an \(L\)-target. The sole
capacity vacancy is now a genuinely free eligible slot.
There can be exactly two face chords, and all five free
slots are used by those chords and the gap edge.

Let \(z_1,\ldots,z_{2K+2}\) list the interior slots.
Call the block *reversed* when its colours are
\(E,O,E,O,\ldots,E,O\), and *forward* when they are
\(O,E,O,E,\ldots,O,E\). According as the vacant eligible
slot is the first, an internal, or the last eligible
position, the numbers of free slots before the first
target, between targets, and after the last target are
\[
\begin{array}{c|ccc}
 &\text{first vacancy}&\text{internal vacancy}&\text{last vacancy}\\
\hline
\text{reversed}&(4,0,1)&(2,2,1)&(2,0,3)\\
\text{forward}&(3,0,2)&(1,2,2)&(1,0,4).
\end{array}                                             \tag{1}
\]
An internal vacancy makes two consecutive free slots;
whether the free neighbour precedes or follows it does
not affect (1). By Note 203, the gap mate lies before
every target if the gap is left of \(B\), and after
every target if the gap is right of \(B\). Note 258
requires an odd number of face chords to straddle that
mate. At every escape target, the even free-prefix
parity of Note 255 requires an even number of face
chords to straddle the target; cross-block chords
cannot do so by Note 203. We check the four
orientation and gap-side combinations.

If the block is reversed and the gap is on the left,
an internal or last vacancy leaves only \(z_1,z_2\)
before the first target. A mate at \(z_1\) has no
face-chord endpoint before it, contrary to gap
localization. A mate at \(z_2\) forces a face chord
from \(z_1\) across the first target, but no second
free endpoint before that target exists for the
required second crossing chord. With a first vacancy,
the sole free slot after the last target is an endpoint
of one face chord; that chord crosses the last target,
and there is no second suffix endpoint for a second
crossing chord.

If the block is reversed and the gap is on the right,
a first or internal vacancy leaves only the last
interior slot after the last target. A mate there has
no face-chord endpoint beyond it. With a last vacancy,
the free prefix is \(z_1(E),z_2(O)\), and the free
suffix is \(z_{2K}(O),z_{2K+1}(E),z_{2K+2}(O)\).
The mate cannot be the last slot. If it is
\(z_{2K+1}\), the four chord endpoints have colour
counts \(1E,3O\). If it is \(z_{2K}\), neither the
two prefix slots nor the two remaining suffix slots
can pair internally, since each pair is an old-cycle
edge. The only bipartite noncrossing face pairing is
\[
 z_1z_{2K+2},\qquad z_2z_{2K+1};
\]
both chords straddle the mate, contradicting the
required odd parity.

If the block is forward and the gap is on the left,
an internal or last vacancy leaves only \(z_1\)
before the first target. It would have to be the
gap mate, with no earlier face-chord endpoint.
With a first vacancy, the free prefix is
\(z_1(O),z_2(E),z_3(O)\), and the suffix is
\(z_{2K+1}(O),z_{2K+2}(E)\). The mate cannot be
\(z_1\). If it is \(z_2\), the four chord endpoints
have colours \(3O,1E\). If it is \(z_3\), the only
bipartite noncrossing face pairing is
\[
 z_1z_{2K+2},\qquad z_2z_{2K+1};
\]
both chords straddle \(z_3\), again even rather
than odd.

Finally, suppose the block is forward and the gap
is on the right. With an internal or last vacancy,
the first target is \(z_2\) and \(z_1\) is the sole
free slot before it. Since the gap mate is on the
right and all five free slots are consumed, \(z_1\)
is a face-chord endpoint. Its chord crosses the
first target, but a second crossing chord has no
second earlier endpoint. With a first vacancy, the
free suffix is \(z_{2K+1},z_{2K+2}\). A mate at
the last slot has no later face-chord endpoint.
A mate at the first leaves only one suffix chord
endpoint, so one chord crosses the last target
and the required second one cannot.

All four cases contradict two face chords. Exactly
one remains. \(\square\)

**Distinct-block consequence.** At
\[
 f=4r+8,\qquad \sigma=T=2,
\]
suppose the two capacity vacancies lie in different
blocks. Every block receiving a gap slot is one of
those vacancy blocks and has exactly one face-side
free chord. Indeed, a saturated block has no such
chord by Note 255, while each one-vacancy support
block has exactly one by the theorem. A block between
two singleton gaps cannot receive both gap slots,
by Note 267's shared-middle-support corollary.
The conclusion is a structural restriction, not a
Hamilton decision for the remaining distinct-block
placements.
