> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's short-third-leaf comb has a two-path signature

The row-IV word of [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,2)\), short leaf \(3\), and depths \((1,3,5,6,6,4,2)\) has a spanning marked path. The key is a two-path cover of its forty-vertex inner word. The same ordinary word occurs in row I of [Note 431](431-the-short-third-leaf-comb-has-a-marked-cycle-and-the-last-comb-has-two-port-signatures.md), but the row-I face chords used there are absent from row IV.

Use the notation and full-leaf paths of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). In particular,
\[
Y_i=(y_i,x_i,h_i,j_i,R_i,L_i),\quad
X_i=(R_i,L_i,h_i,j_i,y_i,x_i),\quad
Q_H=(\rho_0^H,\lambda_0^H,\lambda_1^H,
\rho_1^H,\rho_2^H,\lambda_2^H).
\tag{1}
\]
For a full branch \(H\), also set
\[
J_H=(\lambda_0^H,\rho_0^H,\rho_1^H,
\lambda_1^H,\lambda_2^H,\rho_2^H).
\tag{2}
\]
Define
\[
\begin{aligned}
S_3&=(L_3,x_3,y_3,R_3),& K&=F(U_4,U_5),& S&=F(S_3,K),\\
R&=F(S,U_6),& L&=F(U_2,R),& T&=F(L,U_7),& W&=F(U_1,T).
\end{aligned}
\tag{3}
\]
Here \(|R|=40\) and \(|W|=76\). Row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), with ineligible leaves \(3,\ldots,7\), supplies the four face chords \(x_5y_6,y_5x_6,y_4x_7,x_3y_7\).

For \(i=5,7\), deleting \(x_i y_i\) from the old-cycle path closed by the outer ordinary chord \(L_iR_i\) gives the spanning leaf path
\[
Z_i=(x_i,h_i,L_i,R_i,j_i,y_i).
\tag{4}
\]
The word \(R\) has two disjoint paths, whose endpoints are \((R_r,y_4)\) and \((x_3,R_\ell)\):
\[
\begin{aligned}
\mathcal R_1={}&(R_r=\rho_0^R,\rho_1^R,\rho_2^R,
 R_6,j_6,y_6,
 x_5\xrightarrow{Z_5}y_5,
 x_6,h_6,L_6,\\
&S_r=\rho_0^S,\rho_1^S,\rho_2^S,
 K_r=\rho_0^K\xrightarrow{Q_K}\lambda_2^K,
 L_4\xrightarrow{Y_4^{-1}}y_4),\\[2mm]
\mathcal R_2={}&(x_3,y_3,R_3,L_3,
 \lambda_2^S,\lambda_1^S,\lambda_0^S,
 \lambda_2^R,\lambda_1^R,\lambda_0^R=R_\ell).
\end{aligned}
\tag{5}
\]
The jumps \(y_6x_5\) and \(y_5x_6\) in \(\mathcal R_1\) are the two stated face chords. Its other joins \(\rho_2^RR_6,L_6S_r,\rho_2^SK_r,\lambda_2^KL_4\) are consecutive old-cycle edges. All edges of \(\mathcal R_2\) are old-cycle edges except the short-leaf outer chord \(R_3L_3\); its joins \(L_3\lambda_2^S\) and \(\lambda_0^S\lambda_2^R\) are old-cycle edges. The right triples of the \(R,S\) brackets occur in \(\mathcal R_1\), their left triples in \(\mathcal R_2\); \(Q_K\) covers all six \(K\)-brackets. The three full leaves \(U_4,U_5,U_6\) and the short leaf \(S_3\) occur once. Thus the paths in (5) partition all \(6+6+6+18+4=40\) vertices of \(R\).

**Marked-path theorem.** The following is a spanning \(y_1\)--\(x_2\) path of \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^T\xrightarrow{Q_T}\lambda_2^T,
L_\ell=\lambda_0^L\xrightarrow{J_L}\rho_2^L,\\
&R_r\xrightarrow{\mathcal R_1}y_4,
x_7\xrightarrow{Z_7}y_7,
x_3\xrightarrow{\mathcal R_2}R_\ell,
R_2\xrightarrow{X_2}x_2.
\end{aligned}
\tag{6}
\]
The jumps \(y_4x_7\) and \(y_7x_3\) are the other two stated face chords. The remaining joins \(L_1\lambda_2^W,\rho_2^W\rho_0^T,\lambda_2^TL_\ell,\rho_2^LR_r,R_\ell R_2\) are consecutive old-cycle edges. The pieces cover \(U_1,U_2,U_7\) (eighteen vertices), the wrappers \(W,T,L\) (eighteen), and \(R\) (forty), totalling all \(76\) vertices of \(W\).

Appending the two site edges and the fixed twelve-vertex outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), gives a parent Hamilton cycle through both site edges. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to a Hamilton cycle in every corresponding legal child. Reflection gives the row-V statement. \(\square\)

**Shared-chord corollary.** The row-IV word with sites \((1,7)\), short leaf \(2\), and depths \((3,5,6,6,4,2,1)\) is Hamiltonian in every legal completion. Its ordinary word is exactly equation (4) of [Note 430](430-one-face-chord-spine-bypass-absorbs-an-arbitrary-middle-word.md), including the site endpoints. Note 430's path (2) uses only the face chord \(y_5x_6\), which is also a row-IV chord in Note 426. The same path and the fixed outside route therefore give a parent Hamilton cycle through both site edges; Note 001 lifts it to the child. Reflection gives the row-V result.

Together with Notes 437--445, this leaves two structurally necessary row-IV/V short-leaf words. Row VI, other kernel branches, and Barnette's conjecture remain unresolved.
