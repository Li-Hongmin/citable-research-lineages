> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two split end roots close three-root single-hexagon openings

[Note 486](486-disconnected-three-root-two-split-nodes-must-share-site-root.md) closes the disconnected root face graph when two split nodes lie in distinct roots. [Note 489](489-two-end-escape-edges-absorb-both-residual-cycles.md) absorbs terminal-free components containing the two end escape edges when the root face graph is connected. If the two split nodes occupy the end roots of a three-root chord-free single-hexagon opening, a terminal-free component without either escape edge can also be removed. The argument needs no bound on the number of leaves or ordinary wrappers.

Use the cycle order, root cycles \(D=C_1\cup C_2\cup C_3\), site edges \(q=w_0u,p=vw_*\), and root face graph \(K\) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). The split nodes lie in \(W_1,W_3\), with orders
\[
 H_i,s_i,A_i,t_i,J_i,\qquad i\in\{1,3\}.
\]
The ends of \(A_i\) are \(L_i,R_i\). Let \(X_i\) be the part of \(C_i\) from its left root end through \(s_i\), and \(Y_i\) the part from \(t_i\) through its right root end. The complementary arc \(B_i=X_i\cup Y_i\) is closed by the exterior route of \(C_i\), and contains \(t_dd\) for \(i=1\), or \(t_aa\) for \(i=3\). Every special position in \(X_i\) or \(Y_i\), except the one direct position \(s_i\) or \(t_i\), belongs to a complete two-special leaf. Thus each flank has an odd number of special positions. Write \(M\) for the face matching except at \(u,v\), and \(E\) for the square-supported old leaf edges. The edges of \(M\) and the site edges \(p,q\) lie on the same side of the old Hamilton cycle, so interlacing endpoints force a crossing.

**End-root theorem.** Suppose every assigned special position outside the two direct split pairs belongs to a two-special ordinary leaf. Then the parent has a Hamilton cycle containing \(p,q\); hence its legal \(C_4\)-expanded child is Hamiltonian, whether or not \(K\) is connected. This holds for arbitrary leaf counts and ordinary wrapper lengths. In particular, a non-Hamiltonian chord-free \(12f+2\) equality child cannot have its two split nodes in \(W_1,W_3\).

**Proof.** If \(K\) is disconnected, Note 486 gives the marked parent Hamilton cycle. Hence assume \(K\) is connected. Use the double inner opening \(F_{\mathrm{ii}}\) of (1) in Note 489. Its union with \(E\) has at most three components, and leaf-square switches merge each component into one path or cycle while preserving the escape edges. If every terminal-free component has an end escape edge, Note 489 finishes the proof. Suppose that a terminal-free component \(S\) has neither.

The pieces before adding \(M\) are \(A_1,B_1,W_2,A_3,B_3\). Since \(B_1,B_3\) contain the end escape edges, \(S\) is made from a connected selection of \(A_1,W_2,A_3\). It cannot be \(A_i\) alone: with no site port or matching chord leaving \(A_i\), its two old boundary edges would be a two-edge cut. It cannot be \(W_2\) alone, since then \(K\) would be disconnected.

We next exclude any such \(S\) containing \(W_2\). If an \(M\)-edge joins \(A_1\) to \(W_2\), every special position in \(Y_1\) is trapped. A matching edge from \(Y_1\) to \(A_1\) or \(W_2\) would leave \(S\); one to \(X_1\) or any root position after \(W_2\) would cross the \(A_1\)--\(W_2\) edge. Hence all non-site positions of \(Y_1\) would have to match within \(Y_1\). No site port can lie in \(Y_1\): either \(w_0u\) or \(vw_*\) would cross that same edge. The odd number of special positions in \(Y_1\) gives a contradiction. An \(M\)-edge from \(W_2\) to \(A_3\) gives the reflected contradiction in \(X_3\).

The only remaining connected selection containing \(W_2\) is \(A_1\cup W_2\cup A_3\), with no \(A_1\)--\(W_2\) or \(W_2\)--\(A_3\) edge; but then \(W_2\) has no edge to the other two pieces and the selection is disconnected. Thus
\[
                         S=A_1\cup A_3,                 \tag{1}
\]
joined by at least one \(M\)-edge. Neither child has a site port. An edge joining \(A_1\) to \(A_3\) crosses a site edge whose port is strictly between the two child intervals. Therefore both \(u,v\) lie in the outer flanks \(X_1\cup Y_3\). Moreover \(W_2\) has no \(M\)-edge into \(S\), and connectedness of \(K\) gives it an \(M\)-edge to \(B_1\) or \(B_3\).

Choose one node \(i\in\{1,3\}\) and open it **outside**, leaving the other node \(j\) open inside:
\[
 F_{\mathrm{oi}}=
 \bigl(D-E-\{H_is_i,t_iJ_i,s_jL_j,R_jt_j\}\bigr)
       \cup M\cup\{H_iJ_i,L_jR_j\}.                 \tag{2}
\]
The ordinary chord \(H_iJ_i\) is unused by \(D\): the end-root cycles \(C_1,C_3\) of Note 456 use their old root arcs and the exterior escape routes, not an ordinary chord of either root. Equation (2) has degree one exactly at \(u,v\). After restoring \(E\), its coarse pieces are the central arc \(P_i=s_i\rightsquigarrow t_i\), the outer complement \(B_i'\), the closed child \(A_j\), the complement \(B_j\), and \(W_2\). The edge between \(A_1,A_3\) joins \(P_i\) to \(A_j\). Every nonterminal direct position of node \(i\) has its \(M\)-mate outside \(S\); [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) excludes its other direct position as mate. Thus its matching edge joins \(P_i\cup A_j\) to one of the other pieces.

We choose \(i\) so that the component containing \(P_i\cup A_j\) also contains the site ports.

* If both ports lie in \(X_1\), take \(i=3\). The direct position \(t_3\in Y_3\) is a nonterminal. Its mate lies in \(X_1\) or \(Y_3\): an edge from \(Y_3\) into the interval between \(A_1,A_3\) crosses their joining edge. If its mate is in \(X_1\), (2) joins \(P_3\) directly to the marked piece. If its mate is in \(Y_3\), the odd, terminal-free flank \(Y_3\) has another matching edge to \(X_1\); that edge remains after the opening and joins \(B_3'\) to the marked piece. The mate of \(t_3\) joins \(P_3\) to \(B_3'\). Thus \(P_3\cup A_1\) is marked.
* If both ports lie in \(Y_3\), reflect this argument and take \(i=1\), using the nonterminal \(s_1\in X_1\).
* If one port lies in each outer flank, take \(i=1\). The direct position \(t_1\in Y_1\) is a nonterminal. Its mate can lie only in \(Y_1,W_2,X_3\); the joining \(A_1\)--\(A_3\) edge excludes \(X_1,Y_3\), and the isolation of \(S\) excludes \(A_1,A_3\). A mate in \(Y_1\) or \(X_3\) joins \(P_1\) to \(B_1'\) or \(B_3\), respectively, each containing a site port. If the mate is in \(W_2\), another \(M\)-edge leaves \(W_2\): it has an even number of special positions and no site port. This second edge cannot end in \(A_1,A_3\), by (1), or at \(s_1\), because it would cross the \(A_1\)--\(A_3\) edge. It therefore joins \(W_2\) to \(B_1'\) or \(B_3\). Both site ports lie in one component because (2) has a unique \(u\)--\(v\) path. Hence \(P_1\cup A_3\) is again marked.

Every component of \(F_{\mathrm{oi}}\cup E\) outside that marked component contains an end escape edge. Indeed, the only coarse pieces outside \(P_i\cup A_j\) are \(B_i',B_j,W_2\); both \(B_i',B_j\) have their respective escape edges. The whole \(W_2\) cannot form a component alone: every one of its original \(M\)-edges to \(B_1\) or \(B_3\) persists in (2), with an endpoint now possibly moved to \(P_i\). The connected root graph ensures at least one such edge. Splitting the two roots into two pieces each increases the component count of their connected face graph by at most two, so there are at most three components in total.

Switch along a leaf-square spanning tree in each component. This leaves the marked \(u\)--\(v\) path and at most two disjoint cycles, each with a different end escape edge. The exterior paths (2)--(5) of Note 489 absorb zero, one, or two such cycles while covering \(w_0,w_*,\alpha,\beta\) and retaining \(p,q\). [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the resulting marked parent Hamilton cycle. \(\square\)

The theorem uses the placement \(W_1,W_3\), not a same-root placement or a placement involving \(W_2\). It applies beyond the equality profile but does not settle Barnette's conjecture.
