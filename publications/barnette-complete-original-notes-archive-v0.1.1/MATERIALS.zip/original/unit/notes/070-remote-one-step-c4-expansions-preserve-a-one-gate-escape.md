> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Remote one-step C4 expansions preserve a one-gate escape

[Note 068](068-even-fully-alternating-two-gate-targets-need-not-lift.md)
exhibits a reduced target that uses both gates, alternates on both gate arcs,
and nevertheless fails every local lift row.  The complete target family at
the same interface still contains six liftable members.  This note determines
whether a further (C_4)-expansion away from that interface can destroy every
such escape in one step.

The answer is no.  The conclusion is deliberately local to the complete
one-step neighbourhood of the explicit Note 068 interface; it is not an
arbitrary-order lifting theorem.

## Fixed interface and operation class

Use the reduced triangulation (T'_0), split vertex (z=3), rotation

\[
(0,1,6,11,10,7,5,4),
\]

gates (0,10), closed arcs

\[
A_1=(0,1,6,11,10),\qquad A_3=(10,7,5,4,0),
\]

and root edge (a=02) from Note 068.  Call a second inverse degree-four
operation *remote* when its split vertex (u) lies outside

\[
N_{T'_0}[z]\cup V(a).
\tag{1}
\]

At (u), choose any two nonconsecutive neighbours whose two closed rotation
arcs have odd cardinality, and retain the operation exactly when its result is
again a simple (4)-connected Eulerian plane triangulation.  The original
rotation at (z), its two gates, both arcs, and (a) are then unchanged, so
the original Note 068 expansion can be applied after the remote operation.

In (T'_0), the set in (1) leaves exactly

\[
u\in\{8,9\}.
\tag{2}
\]

Their rotations have eleven nonconsecutive gate pairs in total.  Exactly
eight satisfy the odd-arc condition, and all eight give legal remote
expansions whose primal reduced graphs are (24)-vertex braces.

## Complete target-family calculation

For each of the eight new reduced triangulations, enumerate the complete
target family for the unchanged root (02), modulo global colour
complementation, and test all eight assignments at the original split.  The
family sizes are

\[
15,17,15,11,15,15,13,17.
\tag{3}
\]

Thus the calculation contains (118) target/interface instances and (944)
local assignments.  Of the targets, (74) lift and (44) do not.  Every one
of the eight complete families contains a liftable target.

There is a sharper common description.  Normalize the contracted colour by
(c(z)=0), encode gate use by `g`, alternation of the two original arcs by
`a`, and the normalized local row ((\lambda,\rho,d)) by `r`.  In every one
of the eight operations, the complete set of successful signatures is the
singleton

\[
\boxed{\texttt{g10:a00:r001}}.
\tag{4}
\]

Hence every success removes the second original gate, uses neither original
arc as an alternating word, and lifts through the neutral row
((\lambda,\rho,d)=(0,0,1)).  The remote operation may create many new bad
targets, but it does not remove this one-gate escape.

The standalone verifier is
[verify_note068_remote_c4_expansion_boundary.py](../computations/verify_note068_remote_c4_expansion_boundary.py).
It checks all operations in (2), both brace criteria for every new primal
graph, the complete root-target families, and all local rows.  Reproduce with

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/verify_note068_remote_c4_expansion_boundary.py

The terminal marker is

    NOTE068_REMOTE_C4_ONE_STEP_ROUTE_CLOSED

## Boundary

**Exact conclusion.** No legal one-step (C_4)-expansion supported outside
the closed neighbourhood of the Note 068 split and the root endpoints turns
that fixed interface into a complete-family lifting failure.  All such
operations preserve the escape signature (4).

**Weakest load-bearing step.** Completeness is finite and specific to (1):
after identifying the only two remote vertices, every nonconsecutive gate
pair is enumerated and the parity and (4)-connectivity filters are applied
directly.

**Evidence level.** This is an exact computer-assisted closure of one local
construction route.  A fresh run reproduced the accepted aggregate JSON byte
for byte.

**Unresolved boundary.** Operations touching (N[z]) or an endpoint of the
root require a changed inherited interface and are not covered.  Neither are
other graph operations, coupled multi-step expansions, or arbitrary reduced
order (22).  The result does not prove general existence-level lifting.
