> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A single chord-free hexagon trap has a short-main Hamilton bound

[Note 403](403-a-single-chorded-hexagon-trap-needs-twelve-main-vertices.md)
handles the first nonsquare trapped cycle when its four interior
slots contain the chord \(ad\). The other possibility is a
chord-free trapped hexagon: all four interior slots escape
to the main old-cycle segment. Their planar order rules out
the first long-opposite-gap candidate.

Keep the notation and hypotheses of Note 403, except assume
\(ad\notin M\). Thus one selected facial arc is
\[
 v,\alpha,\beta,x,
 \qquad S_1=(\alpha,a,b,c,d,\beta),
 \qquad \alpha\beta\in M,                                \tag{1}
\]
and the other old-cycle segment is
\[
 S_0=(w_0=x,w_1,\ldots,w_{s-1}=v),
 \qquad q=xw_j,\quad p=w_kw_{s-1}.                       \tag{2}
\]
The four slots \(a,b,c,d\) have no available internal
matching edge: \(ab,bc,cd\) belong to the old cycle,
and \(ac,bd\) join equal colours. They therefore have
four distinct matching neighbours in \(S_0\).

**Chord-free short-main theorem.** The main segment has
\(s\ge8\). If \(s\le10\), then \(k=j+1\), so the other
facial arc between the two site edges is the single old-cycle
edge \(w_jw_{j+1}\). Every legal square-expanded child
at this site is Hamiltonian by the direct one-edge flip
of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md).
The lower bound \(s=8\) is attained by a 14-vertex Barnette
parent. Together with Note 403, this proves that *any*
selected literal opening with exactly one trapped hexagon
and \(s\le10\) has a Hamiltonian legal child; with the
internal chord, the same conclusion holds through \(s=12\).

**The four escape slots.** As in Note 403, colour \(w_0\)
with 0. The trapped vertices \(a,c\) have colour 1,
and \(b,d\) colour 0. Write \(t_a,t_b,t_c,t_d\in S_0\)
for their matching neighbours. All four escape chords
lie opposite the common face by Note 176. The four
trapped vertices occur along \(C\) in the order
\(a,b,c,d\), so noninterlacement forces the reverse
order on \(S_0\):
\[
                         t_d<t_c<t_b<t_a.                 \tag{3}
\]
Their respective main indices have parity odd,
even, odd, even. The site order and simplicity give
\(j\) odd and at least 3, \(k\) even and at most
\(s-4\), and \(s\) even. Thus \(s\ge8\).

For \(s=8\), the site positions are forced to
\((j,k)=(3,4)\). All four unused main slots
\(w_1,w_2,w_5,w_6\) must escape. The only order
consistent with (3) is
\[
                t_d=w_1,\quad t_c=w_2,
                \quad t_b=w_5,\quad t_a=w_6.              \tag{4}
\]
The opposite facial arc is \(w_3w_4\), as claimed.

For \(s=10\), the permitted site positions are
\((3,4),(3,6),(5,6)\). Only \((3,6)\) has a
non-single-edge opposite arc. In that case the six
free main slots are
\(w_1,w_2,w_4,w_5,w_7,w_8\). The ordered escape
quadruple must begin at \(t_d=w_1\) and end at
\(t_a=w_8\). The four possibilities for its
middle entries and the unused matching pair are
\[
\begin{array}{c|c|l}
t_c&t_b&\text{unused pair and obstruction}\\
w_2&w_5&w_4w_7:\text{ crosses }p\text{ on the face side,
 and }w_5b\text{ on the other};\\
w_2&w_7&w_4w_5:\text{ an old-cycle edge};\\
w_4&w_5&w_2w_7:\text{ crosses }q\text{ on the face side,
 and }w_4c\text{ on the other};\\
w_4&w_7&w_2w_5:\text{ crosses }q\text{ on the face side,
 and }w_4c\text{ on the other}.
\end{array}                                                   \tag{5}
\]
No pairing is possible, so \((j,k)=(3,6)\) is
excluded. The remaining site choices have
\(k=j+1\), completing the proof of the bound.

**Sharp Barnette realization.** Take the old Hamilton
cycle
\[
 w_0,w_1,\ldots,w_7,\alpha,a,b,c,d,\beta,w_0
\tag{6}
\]
and complementary matching
\[
 \{w_0w_3,w_4w_7,\alpha\beta,
          w_1d,w_2c,w_5b,w_6a\}.                         \tag{7}
\]
The site edges are \(q=w_0w_3,p=w_4w_7\).
Draw these and \(\alpha\beta\) as disjoint chords
on the common-face side. The four escape chords
on the other page are nested in the order
\[
                   w_1d\supset w_2c\supset
                   w_5b\supset w_6a.
\]
All edges join opposite cycle parities, so this
is a simple cubic bipartite plane graph.
Its matching-chord interlacement graph is
connected: \(q\) interlaces \(w_1d,w_2c\),
\(p\) interlaces \(w_5b,w_6a\), and
\(\alpha\beta\) interlaces all four escape
chords. A two-edge cut would disconnect this
interlacement graph, while the Hamilton cycle
excludes bridges. Hence the graph is
three-connected and is Barnette. The common face
between \(p,q\) has arcs \(w_3w_4\) and
\(w_7,\alpha,\beta,w_0\), realizing (1) with
\(s=8\). The first arc yields a Hamilton cycle
in any legal site expansion. \(\square\)

The theorem covers one chord-free trapped hexagon
and a short main segment. It does not decide the
first possible long-gap cases at larger \(s\),
multiple trapped cycles, or nonfacial openings.
The proof is analytic and project-internal, with
no local graph recomputation, independent review,
or external priority claim.
