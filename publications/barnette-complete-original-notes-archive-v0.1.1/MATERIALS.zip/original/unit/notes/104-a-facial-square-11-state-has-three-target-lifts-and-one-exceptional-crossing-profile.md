> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A facial-square \(11\) state has three target lifts and one exceptional crossing profile

**Subsequent strengthening.**
[Note 105](105-opposite-edge-expansion-of-a-facial-square-preserves-every-fibre-crossing.md)
observes that the formal \(00_{\rm ext}\) row below cannot be an endpoint in
the fixed-pairing target fibre: its complement contains the facial square
as an isolated cycle.  Consequently the exceptional profile is vacuous in
the target fibre, and every parent crossing survives a facial-square
opposite-edge expansion.

[Note 103](103-one-step-crossing-preservation-is-exactly-new-cell-supplementation.md)
reduces one-step preservation, after all canonical crossings have been
killed, to the three new child cells \(R_{00},X_{uy},X_{vx}\).  For a
general facial expansion, brace \(2\)-extendability puts perfect matchings
in these cells but does not put them in the fixed-pairing target fibre.

When the two selected edges are opposite edges of a facial square, this
first gap disappears completely.  Every parent target of state \(11\) has
one explicit child target in each new cell.  Comparing these three lifts
with a killed parent crossing gives a six-row local connector table.  Five
rows preserve a single-cycle crossing directly.  The only exceptional row
is a state-\(00\) endpoint using all four edges leaving the square; planarity
then forces the external side pairing, and the three direct child distances
are \(3,2,2\).

Thus a counterexample at a square-face expansion must concentrate every
parent crossing on one precise four-external \(11\)--\(00\) profile and
must also prevent all supplementation from the rest of the complete child
fibre.

## 1. Three face-assisted target lifts

Let the expansion site be the opposite edges

\[
p=uv,\qquad q=xy
\tag{1}
\]

of a facial square

\[
u-v-x-y-u.
\tag{2}
\]

Write

\[
r=vx,\qquad s=yu
\tag{3}
\]

for its other two edges.  Assume the square is disjoint from the deleted
root square and the named gates.  Use the child patch notation of Note 103:

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\tag{4}
\]

Let \(M\) be a parent fixed-pairing target with

\[
p,q\in M.
\tag{5}
\]

Since \(M\) is a matching, \(r,s\notin M\).  Define

\[
\begin{aligned}
M^R={}&(M-\{p,q\})\cup\{r,s,ab,cd\},\\
M^U={}&(M-\{p,q\})\cup\{r,ua,bc,dy\},\\
M^V={}&(M-\{p,q\})\cup\{s,ad,bv,xc\}.
\end{aligned}
\tag{6}
\]

These are perfect matchings in the cells \(R_{00},X_{uy},X_{vx}\),
respectively.  More strongly, all three are child targets with the same
terminal pairing and gate bit as \(M\).

Indeed, in the complement of \(M^R\), the old complement edges \(s,r\)
are replaced by the paths

\[
u-a-d-y,\qquad v-b-c-x.
\tag{7}
\]

For \(M^U\), the edge \(s\) remains and \(r\) is replaced by

\[
v-b-a-d-c-x.
\tag{8}
\]

For \(M^V\), the edge \(r\) remains and \(s\) is replaced by

\[
u-a-b-c-d-y.
\tag{9}
\]

Thus every complement component is merely subdivided.  No terminal pairing
changes and no closed component is created.  Consequently

\[
\boxed{
\mathcal L_{11}\ne\varnothing
\Longrightarrow
R_{00},X_{uy},X_{vx}\text{ are all nonempty in the child fibre}.}
\tag{10}
\]

This conclusion uses neither the brace axiom nor an extension theorem.  It
comes from the two unused sides of the facial square.

## 2. Local forms of the other endpoint

Let \(M,N\) be parent targets in opposite gate sectors such that

\[
M\triangle N=A
\tag{11}
\]

is one alternating cycle and \(M\) has state \(11\) at \(p,q\).  At the
four square vertices, a state-\(00\) matching \(N\) has exactly four
possible forms:

\[
\begin{array}{c|c}
\text{form}&\text{square and external matching edges of }N\\ \hline
00_{rs}&r,s\\
00_r&r\text{ and the external edges at }u,y\\
00_s&s\text{ and the external edges at }v,x\\
00_{\mathrm{ext}}&\text{all four external edges at }u,v,x,y.
\end{array}
\tag{12}
\]

The first form cannot occur in a cross-sector edge.  In that case the four
square edges already form the whole component \(M\triangle N\).  Since
there is only one component, \(M\triangle N\) is the facial square itself
and avoids the protected surviving gate.

In the last form, deleting \(p,q\) from \(A\) leaves two vertex-disjoint
paths outside the open square.  Their endpoints cannot be paired as
\((u,v),(x,y)\), since adding \(p,q\) would give two cycles.  They cannot
be paired as \((u,x),(v,y)\), since these are crossing boundary pairs in
the exterior disk.  Planarity therefore forces

\[
\boxed{(u,y),(v,x).}
\tag{13}
\]

This is the unique four-external planar form of a single parent crossing.

## 3. The connector table

If \(N\) has state \(10,01\), or one of the admissible state-\(00\)
forms, let \(\widehat N\) be its canonical child target.  If \(N\) has
state \(11\), compare matching lifts in the same one of the three cells.
Suppressing each external alternating path to one edge gives the complete
component table

\[
\begin{array}{c|ccc}
\text{state or form of }N
&\#\operatorname{comp}(M^R\triangle N^R)
&\#\operatorname{comp}(M^U\triangle N^U)
&\#\operatorname{comp}(M^V\triangle N^V)\\ \hline
11&1&1&1\\
10&1&1&1\\
01&1&1&1\\
00_r&2&1&2\\
00_s&2&2&1\\
00_{\mathrm{ext}}&3&2&2.
\end{array}
\tag{14}
\]

In the first row, \(N^R,N^U,N^V\) mean the three face-assisted lifts of
\(N\).  In every other row they all denote the same canonical
\(\widehat N\); the superscripts only specify which lift of \(M\) is used
in the column.

For example, in state \(10\), the parent cycle uses \(q\) and an external
path from \(x\) to \(y\).  The three local replacements close that path by

\[
x-v-b-a-u-y,\qquad
x-v-b-c-d-y,\qquad
x-c-d-a-u-y,
\tag{15}
\]

up to reversal, so all three entries are one.  In form \(00_r\), only
\(M^U\) cancels the common edge \(r\) and closes the external \(u\)--\(y\)
path without leaving a second local component.  The form \(00_s\) is the
reflection.  In the four-external form, (13) agrees with the two local side
connections; \(M^U\) and \(M^V\) therefore give two cycles, while \(M^R\)
also leaves the internal gadget \(C_4\), giving three.

The permanent symbolic verifier reconstructs every row of (14) after path
suppression.

## 4. Consequence for one-step preservation

Suppose the parent crossing graph is nonempty and
\(\mathcal L_{11}\) is a vertex cover, so all canonical child crossings
are killed in the sense of Note 103.  Equation (10) proves the entire
target-admission arrow for this facial-square subcase: all three new cells
already contain child targets.

Moreover, if even one parent crossing edge has a second endpoint of type

\[
11,\quad10,\quad01,\quad00_r,\quad\text{or}\quad00_s,
\tag{16}
\]

then (14) supplies a child cross-sector single-cycle edge.  Therefore a
failure of one-step crossing preservation at a facial-square site must
satisfy the following necessary condition:

\[
\boxed{
\text{every parent crossing edge joins an }11\text{ endpoint to a }
00_{\mathrm{ext}}\text{ endpoint with pairing }(u,y),(v,x).}
\tag{17}
\]

Condition (17) is not asserted sufficient for failure.  It says only that
the direct descendants of every parent crossing have two or three
components.  Other parent perfect matchings and the complete child fibre
may still supply a crossing.

## 5. The minimum prism mechanism is nonvacuous

For the labelled octagonal-prism interface of
[Note 100](100-a-legal-wide-fixed-pairing-fibre-need-not-be-convex-in-the-face-flip-lattice.md),
the parent crossing graph has the two edges

\[
(M_3,M_4),\qquad(M_5,M_4).
\tag{18}
\]

Among its twenty-two eligible one-step legal-wide plane-brace children,
exactly two sites have \(\mathcal L_{11}\) as a vertex cover:

\[
\{R_2,R_3\},\qquad\{R_6,R_7\}.
\tag{19}
\]

Both are opposite-edge expansions of a side square.  At the first site,
the two parent crossing types are \(11\)--\(10\) and \(11\)--\(11\).
The first three rows of (14) therefore predict exactly six direct child
crossings: one new--canonical and one new--new edge in each of
\(R_{00},X_{uy},X_{vx}\).  Complete enumeration gives precisely those six
and no canonical--canonical edge.  The reflected site has the same table.

Thus the new-cell mechanism of Note 103 is not a vacuous reformulation.  In
the minimum legal-wide prism, one step really kills every old crossing and
the three face-assisted cells replace them all.

The permanent
[verification bundle](../computations/bundles/facial-square-new-cell-supplementation/README.md)
contains the symbolic connector table, the complete twenty-two-child
classification, the two kill-cover sites and a literal six-cycle witness.

## 6. Exact boundary

**Exact conclusion.**  Opposite-edge expansion of a facial square gives
every parent \(11\)-target three explicit target lifts, one in each new
cell.  Five local crossing profiles preserve a single-cycle edge directly;
the unique exceptional profile is the planar four-external
\(11\)--\(00\) form (17).

**Boundary at this stage.**  The table alone leaves open whether an actual
legal-wide plane brace can concentrate all parent crossings in type (17).
Note 105 closes that apparent boundary: \(00_{\rm ext}\) is not a target
state at all.  Longer facial sites still retain the more general new-cell
admission problem of Note 103.
