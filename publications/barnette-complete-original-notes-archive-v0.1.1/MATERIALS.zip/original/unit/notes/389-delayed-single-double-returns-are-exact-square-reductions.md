> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Delayed single–double returns are exact square reductions

[Note 384](384-delayed-single-double-return-has-two-cutpoints-and-a-marked-route.md)
classifies the no-internal-double-chord `tJ,hp_s` branch
of an isolated single–double corridor and supplies a marked
spanning route, but leaves its four-terminal signature open.
That signature is exactly the square's for every allowed
double-cutpoint word. Thus the whole branch can be removed
from a vertex-minimal non-Hamiltonian Barnette graph without
any hypothesis on vacancies outside the corridor.

Use Note 384's blocks
\[
 V=(a,o,h,i,e,b),\quad S_j=(c_j,p_j,q_j,d_j)
   \ (1\le j\le m),\quad D=(A,O,H,I,K,J,E,B),             \tag{1}
\]
with no short flanks. Assume \(tJ,Ez\in M\), no internal
free matching chord in \(D\), and the matching word
\[
\begin{split}
 M^\circ_{m;s,r}=\{&oK,hp_s,iq_{s-1},ep_1,
 q_rI,p_{r+1}H,q_mO\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,
                   \ j\notin\{s-1,r\}\}.
\end{split}
\tag{2}
\]
Here \(2\le s\le r\le m-1\).
The induced disk patch \(P\) on (1) has degree-two terminals
\((a,J,E,B)\) in cyclic order.

**Delayed-return square theorem.** The complete spanning
one-path and two-path Hamilton signature of \(P\) equals
that of the labeled square \((a,J,E,B)\). Replacing \(P\)
by that square, or reversing the replacement, preserves
Barnette membership and every exterior- and attachment-
marked Hamilton decision. The replacement makes the whole
group one short target-free block and does not depend on
any vacancy outside the four attachments. Therefore no
vertex-minimal non-Hamiltonian Barnette graph contains
an induced copy of this pole.

**The 26-vertex core.** The three maximal standard-link
short-block runs are \(S_1,\ldots,S_{s-1}\),
\(S_s,\ldots,S_r\), and \(S_{r+1},\ldots,S_m\).
Each has positive length. Compressing each by the exact
even-ladder replacement of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
gives the single core \(P_*\) with \(m=3,s=r=2\).
Its free matching word is
\[
      \{oK,hp_2,iq_1,ep_1,q_2I,p_3H,q_3O\}.              \tag{3}
\]
The old-cycle path is the spanning \(aB\) state.
Note 384, equation (9), gives the \(JE\) state. Written
out in the core, that route is
\[
 J,K,o,a,b,e,p_1,c_1,d_1,q_1,i,h,
 p_2,c_2,d_2,q_2,I,H,p_3,c_3,d_3,q_3,O,A,B,E.          \tag{4}
\]
The other two one-path states are
\[
\begin{array}{c|l}
aJ& a,b,c_1,p_1,e,i,q_1,d_1,c_2,p_2,h,o,K,I,
       q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B,E,J\\
EB& E,J,K,o,a,b,e,p_1,c_1,d_1,q_1,i,h,
       p_2,c_2,d_2,q_2,I,H,p_3,c_3,d_3,q_3,O,A,B
\end{array}                                               \tag{5}
\]
The two spanning two-path states are
\[
\begin{array}{c|l}
\{aJ,EB\}&(E,B);\quad
 (a,b,c_1,p_1,e,i,q_1,d_1,c_2,d_2,c_3,d_3,A,O,
      q_3,p_3,H,I,q_2,p_2,h,o,K,J)\\
\{aB,JE\}&(J,E);\quad
 (a,b,c_1,p_1,e,i,q_1,d_1,c_2,p_2,h,o,K,I,
      q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B)
\end{array}                                               \tag{6}
\]
Each row in (4)–(6) uses every core vertex once. Every
consecutive pair is a path edge of (1), a face chord,
or one of (3). In particular, the two path pairs use
the actual old-cycle edges \(EB,JE\) as their short
components, while their long components cover all
other vertices. Bipartite parity excludes the
same-colour terminal pairs \(aE,JB\) as spanning
one-path endpoints. The remaining two-path pairing
interlaces the four terminals and is impossible in a
disk. Hence these are all six square states of \(P_*\).

**All lengths.** Each of the three standard-link runs
is the induced even-column ladder of Note 178 with
four distinct external attachments. Its reduction
sends the cutpoint attachments in (2) to the
corresponding attachments in (3):
\(ep_1,iq_{s-1}\) at the first run,
\(hp_s,q_rI\) at the second, and
\(p_{r+1}H,q_mO\) at the third.
The remaining old-cycle attachments also preserve
their cyclic order. The three runs are disjoint,
so replacing them one at a time transfers all six
outer routing states in both directions. There are
no further states by parity and disk order.

**Barnette-class comparison.** Cap \((a,J,E,B)\) by a
fresh square in the cyclic order
\((t_B,t_E,t_J,t_a)\), with attachments
\(Bt_B,Et_E,Jt_J,at_a\). Follow the entire old-cycle
path of \(P\) from \(a\) to \(B\), then
\(t_B,t_E,t_J,t_a,a\). This is a Hamilton cycle of
the \((18+4m)\)-vertex cap. Its complementary
matching is the face chords \(ab,c_jd_j,AB,t_Bt_a\),
the word (2), and \(Jt_J,Et_E\). The face chords
are disjoint on one page; the word and cap-attachment
chords are nested or disjoint on the other. All chords
join opposite Hamilton-cycle parities, so the cap is
simple, cubic, bipartite and plane.

The cap's matching-chord interlacement graph is
connected. Put \(F_0=ab,F_j=c_jd_j,F_D=AB,F_T=t_Bt_a\).
The incidences in Note 384, equation (12), connect
every \(F_j\), every internal word chord, and \(F_0,F_D\).
Both \(Jt_J,Et_E\) interlace \(F_D,F_T\), attaching
the final cap chord. A two-edge cut in a cubic
Hamiltonian graph would isolate a proper old-cycle
interval closed under the matching, disconnecting its
interlacement graph. The Hamilton cycle rules out a
bridge. The cap is therefore three-edge-connected and
hence three-vertex-connected.

The uncapped pole remains connected after any one
vertex deletion. Each complete block and each of the
three standard-link ladder runs remains connected
after one deletion. The last run meets \(D\) by the
disjoint edges \(p_{r+1}H,q_mO\). The middle run
meets \(D\) by \(q_rI\), and meets \(V\) by
\(hp_s\). Since \(V\) also meets \(D\) by \(oK\),
deleting one vertex cannot sever all three sides of
this triangle of joins. The first run meets \(V\)
by the three edges \(bc_1,ep_1,iq_{s-1}\), at
distinct endpoints. Finally \(D-v\) and \(V-v\)
remain connected because each is a cycle. Thus
\(P-v\) is connected for every \(v\).

After deleting two pole vertices, every surviving
component meets a surviving terminal: a component
without one would also disconnect the three-connected
cap. The square has the same one- and two-deletion
properties. The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
now proves three-connectivity in both replacement
directions. Terminal colours and disk order give
bipartiteness and planarity, while the six routing
states give exterior-marked Hamilton transfer.

In the selected opening, the replacement square's
old path is \(a,J,E,B\) and its face chord is \(aB\);
the endport matching edges become \(tJ,Ez\).
This is one short target-free block with the same
outer attachments. \(\square\)

The result strengthens Note 384's marked-route theorem:
the double-cutpoint branch is removable regardless of
outside vacancy configuration. Other corridor branches,
short flanks and other opening types remain outside this
particular exact reduction. It does not resolve
Barnette's conjecture or make an external priority claim.
This is a project-internal analytic proof, without local
graph recomputation or independent review.
