> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A boundary port and one more missing link always have a rooted cap

[Note 306](306-a-final-gap-cap-is-exactly-a-rooted-crossed-linkage.md)
reduces the last gap of Note 305's two-chord skeleton to
a rooted spanning linkage and proves it when at most one
ordinary link is missing. [Note 309](309-every-two-defect-final-cap-with-a-one-vacancy-root-port-exists.md)
proves the two-defect case when the component of the
missing left-boundary link has one vacancy. A different
fold handles the only right-boundary difficulty when
that component has several vacancies.

Work in the compressed, gapless, tight-target all-square
opening of Notes 275--309, in an actual Barnette parent.
Let \(B_v,B_u\) be vacant with \(u\ge v+3\), and assume
the complementary matching contains
\[
                I_vH_u,\qquad
                P_{u-1}=e_{u-1}o_u.                \tag{1}
\]
Assume \(P_v=e_vo_{v+1}\) is missing. Among
\(P_{v+1},\ldots,P_{u-2}\), at most one further
link \(P_s\) is missing. No restriction is imposed
on vacancy-only matching components or the number
of vacancies in the component of \(P_v\).

**Two-defect boundary-port theorem.** Under these
conditions there is a path
\[
 D:e_{u-1}\leadsto b_{u-1},\qquad
 V(D)=\{e_v,b_v\}\cup
       \bigcup_{k=v+1}^{u-1}V(B_k).                \tag{2}
\]
Hence this entire two-defect class meets the exact
rooted cap criterion of Note 306. If Note 305's
remaining outer hypotheses hold, its \(S,K,X\)
states, marked Hamilton parent cycle, and legal
Hamiltonian site-expanded child follow.

**Proof.** With no second missing link, apply
Note 306. Otherwise the chord \(I_vH_u\) rules out
any vacancy of the \(P_v\) component before \(P_v\)
or after \(V_u\): an edge joining it to the port
would cross that chord, and no free slot lies between
the consecutive vertices \(I_v,e_v\). Together
with Note 278's one-port-per-component rule, this
makes the component of \(P_v\) an end port
\[
 \mathcal Q:\quad
 P_v<V_{r_1}<\cdots<V_{r_m}=V_t,
 \qquad v+2\le r_1,\quad t\le u-1.                 \tag{3}
\]
Its outer matching edge is \(e_vI_t\).
When \(m=1\), Note 309 proves (2) at every
position of \(s\). Assume \(m\ge2\), and set
\(h=r_{m-1}\). In particular \(I_hH_t\) is
a fixed matching edge. Put
\[
 F=B_{h+1},\ldots,B_{t-1},\qquad
 J=B_{t+1},\ldots,B_{u-1}.                         \tag{4}
\]
Either interval may be empty.

For later use, inspect Note 286(6)--(8).
Truncating the component (3) at \(V_h\) gives a
path \(T_h:b_v\leadsto b_h\) spanning
\(B_{v+1},\ldots,B_h\) except \(I_h,e_h\),
provided the ordinary links \(P_{v+1},\ldots,P_{h-1}\)
are retained. If \(h=r_1\), this is Note
286(6), using \(o_{v+1}H_h\); otherwise it
is Note 286(7)--(8), using the last chord
\(I_{r_{m-2}}H_h\). Neither formula uses
the outer edge of the truncated component.
Thus it remains valid with the actual
outer edge \(e_vI_t\).

First suppose \(s<h\). The matching before
\(B_h\) may be arbitrary, but all links from
\(P_h\) through \(P_{u-2}\) are retained.
Note 308's prefix-shielded cap gives (2).

If \(h<s<t-1\), the link \(P_s\) is strictly
inside \(F\), while \(P_h,P_{t-1}\) are
retained. Its nonboundary free matching slots
are trapped inside the fixed chord \(I_hH_t\):
an edge to the exterior would cross that
chord, and the possible boundary mates
\(e_h,o_t\) are already used by
\(P_h,P_{t-1}\). Note 288's boundary-local
one-defect theorem therefore gives a spanning
\(X(F)\) state. The suffix \(J\) has its
elementary \(X\) rails. Note 308's
two-\(X\)-interface extension gives (2).

Suppose next \(s=t-1\). All links before
\(P_{t-1}\) other than \(P_v\), including
those needed for \(T_h\), are retained.
If \(F\ne\varnothing\),
its internal links and \(P_h\) are retained.
Use its elementary crossed rails to form
\[
\begin{split}
 U:\quad b_v\xrightarrow{T_h}b_h,a_{h+1}
 &\xrightarrow{X_{\rm top}(F)}b_{t-1},e_{t-1}
 \xrightarrow{X_{\rm bottom}(F)^{-1}}o_{h+1},
 e_h,I_h,H_t,o_t,a_t,b_t .
\end{split}                                                   \tag{5}
\]
The fold \(b_{t-1}e_{t-1}\) and the joins
\(e_hI_h,H_to_t,o_ta_t\) are old-cycle edges;
\(o_{h+1}e_h=P_h\) is retained, and
\(I_hH_t\) is fixed. Formula (5) never
uses the missing \(P_{t-1}\). Its pieces
are disjoint: \(T_h\) covers the prefix
except \(I_h,e_h\), the two rails partition
\(F\), and the final passage covers those
two omitted vertices and
\(H_t,o_t,a_t,b_t\). Consequently \(U\)
spans \(B_{v+1},\ldots,B_t\) except
\(I_t,e_t\), with endpoints \(b_v,b_t\).
If \(F=\varnothing\), so \(t=h+1\),
use instead
\[
 U:\quad b_v\xrightarrow{T_h}b_h,e_h,I_h,
 H_t,o_t,a_t,b_t.                                  \tag{6}
\]
This uses no \(P_h=P_{t-1}\) and has the
same inventory.

In either subcase set
\[
 A:\quad e_t,I_t,e_v,b_v\xrightarrow{U}b_t.        \tag{7}
\]
The fixed edge \(e_vI_t\) and two old-cycle
edges join the pieces. If \(J\) is empty,
take \(D=A\). Otherwise \(P_t\) and all
internal links of \(J\) are retained, and
the two-rail suffix fold of Note 306(10)
joins \(A\) to give (2).

If \(s=h\), planarity places the second
port component wholly in the final gap
between \(V_h,V_t\): a matching edge from
\(P_h\) to an earlier vacancy, or beyond
\(V_t\), would cross \(I_hH_t\).
Its first target is at least two blocks
to the right of \(B_h\). It is therefore
the end-port side branch of Note 303,
attached at the penultimate vacancy of
\(\mathcal Q\). That note's branch
continuation replaces the ordinary
\(b_v\leadsto b_t\) continuation with
the same endpoints and inventory, omitting
only \(I_t,e_t\). Capping it by (7) and
folding the retained suffix gives (2).

If \(s=t\), planarity places the second
port component entirely to the right of
\(V_t\): a chord to a vacancy before \(B_h\)
would cross \(e_vI_t\), and one from the
last gap \((h,t)\) would cross \(I_hH_t\).
This is the same separation used in Note
309(7).
Let \(V_w\) be its last vacancy. Note 286
gives right continuations \(U_1:b_v\leadsto b_t\)
and \(U_2:b_t\leadsto b_w\), each omitting
only the \(I,e\) pair of its last block.
All links required by those continuations
are retained. Define
\[
 A_1=e_t,I_t,e_v,b_v\xrightarrow{U_1}b_t,
 \qquad
 A_2=e_w,I_w,e_t\xrightarrow{A_1}b_t
                 \xrightarrow{U_2}b_w .
\]
The edges \(e_vI_t,e_tI_w\) are the outer
edges of the two port components. Their
vertex inventories show that \(A_2\)
covers \(e_v,b_v\) and all blocks through
\(B_w\). The retained suffix after \(B_w\)
is folded around \(A_2\) as in Note
303(7)--(10), giving (2).

Finally, if \(s>t\), all links needed for
the ordinary right continuation of
\(\mathcal Q\) are retained. The interval
\(J\) has the sole internal defect
\(P_s\), and its boundary links
\(P_t,P_{u-1}\) are retained. The fixed
chords \(e_vI_t,I_vH_u\) make \(J\)
matching-closed at its nonboundary slots,
exactly as in Note 309. Note 288 supplies
\(X(J)\), and Note 308's suffix interface
gives (2). These cases exhaust the position
of \(s\). \(\square\)

The families in Notes 307--308 realize
nontrivial boundary, backward, and
many-prefix-defect patterns. The theorem
allows one additional defect at any location,
regardless of the number and nesting of
vacancy-only components. It does not cover
two internal missing links when \(P_v\)
is retained, three missing links in the
rooted gap without further interfaces,
other opening shapes, or Barnette's conjecture.
