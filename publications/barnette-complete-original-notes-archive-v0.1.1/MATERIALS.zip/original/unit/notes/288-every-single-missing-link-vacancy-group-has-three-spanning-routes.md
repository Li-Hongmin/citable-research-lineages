> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every single-missing-link vacancy group has three spanning routes

Notes 282 and 285 give all three four-port routes for an end
or interior port component when its block span is separated
from the other vacancy components. Notes 286 and 287 handle
the two ways in which a vacant source block can touch or
surround an end-port component. The remaining case is a port
immediately after a later atom of its surrounding vacancy
component. Its cap follows the old cycle through the defect;
its crossed state uses the port's right continuation.

Let \(G\) be a Barnette parent with a compressed, gapless,
tight-target all-square opening and \(\ell,r\ge1\).
All vacancies lie in distinct target-free internal
face-chord blocks. Fix a free group whose ordinary
end links are retained. Let \(D=B_a,\ldots,B_b\) be its full
target-free internal block interval, and suppose exactly
one ordinary link \(P_s=e_so_{s+1}\) inside the group is
missing. The complementary matching is otherwise arbitrary
subject to the opening and planarity.

**One-defect group theorem.** The interval \(D\) has all
three vertex-spanning four-port states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b.
\end{array}                                             \tag{1}
\]
There is no restriction on the number of vacancies, their
distances, the number or nesting depth of vacancy-only
components, the position of the port in its component, or
whether either port-adjacent block is vacant. Reflection
exchanges the two sides.

Consequently, if *every* free group of the opening has at
most one missing ordinary link and retained ordinary end
links, the parent has a Hamilton cycle through both site
edges and its legal expanded child is Hamiltonian. A group
with no missing link is covered by Note 275; a group with
one is covered here. These conclusions hold at every
surplus and for arbitrary positive original lobe lengths.

**Proof.** Note 278's noncrossing atom partition contains
exactly one port atom \(P_s\). Its component has at least
one vacancy atom; every other component is vacancy-only.
If there is a vacancy on each side of \(P_s\) in its
component, Note 285 gives \(S,K,X\) of the prime block
span. Its extreme vacant blocks keep all surrounding
vacancy-only components in proper block gaps. Note 275's
prime recursion and serial composition then give (1).

Otherwise reflect if necessary and write the port
component as
\[
 P_s<V_{k_1}<\cdots<V_{k_m}=V_u,\qquad m\ge1.
                                                            \tag{2}
\]
Old-cycle adjacency forces \(k_1\ge s+2\). If \(B_s\)
is short, Note 282 gives the prime three-state route.
Any surrounding vacancy-only component is block-aligned
with its span, and Note 275 composes the rest.

Suppose \(B_s\) is vacant. Its atom \(V_s\) is not in
(2): since \(V_s,P_s\) are consecutive in the reduced
boundary order, their membership in one component would
force \(I_se_s\) into the complementary matching, but
\(I_se_s\) is an old-cycle edge. Let \(\mathcal A\)
be the vacancy-only component containing \(V_s\).

If \(V_s\) is its last atom, its closed block interval
ending at \(B_s\) has \(S,K,X\) by Note 275. Note 286
attaches the port component to that interval and gives
the three states of their combined span. Any further
surrounding vacancy-only component now contains that
span in a proper block gap.

If \(V_s\) is not the last atom of \(\mathcal A\), the
entire port component (2) lies between \(V_s\) and
the next atom of \(\mathcal A\): an atom of
\(\mathcal A\) between \(P_s\) and \(V_u\) would
interlace (2). Write
\[
 \mathcal A:
 V_{j_1}<\cdots<V_{j_c}=V_s<V_{j_{c+1}}=V_t
 <\cdots<V_{j_h}=V_w,\qquad u<t.                    \tag{3}
\]
When \(c=1\), Note 287 gives \(S,K,X\) for the
combined span \(B_s,\ldots,B_w\), with no bound on
\(h,m\) or the other vacancy-only components.

It remains to prove the same three states when
\(2\le c<h\). Consider \(Q=B_{j_1},\ldots,B_w\).
The first gap of \(\mathcal A\), between \(V_{j_1}\)
and \(V_{j_2}\), contains no port, and its ordinary
links are retained. Note 275's cap construction
uses \(X\) in this first gap, the first two and outer
matching edges of \(\mathcal A\), and then the
old-cycle arc from \(H_{j_2}\) to \(I_w\). The latter
passes through all vertices of (2) without using
\(P_s\). Thus its cap route is unchanged and gives
\(K(Q)\).

For the straight state, use Note 275's prime \(S\)
route for \(\mathcal A\). Its first gap is again
unaffected. Every later ordinary segment is retained
except the one beginning at \(e_s\). Replace the
missing link there by the port-component detour
\[
 e_s,I_u,H_u,
 (I_{k_d},H_{k_d})_{d=m-1,\ldots,1},o_{s+1}.       \tag{4}
\]
As in Note 286(4)--(5), follow the ordinary path
through the remainder of this gap, using \(S\)
for its closed vacancy-only subgaps and face chords
through the blocks \(B_{k_d}\). Formula (4) visits
exactly the vacancy slots those face-chord traversals
omit. No vacancy-only component can straddle (2)
inside the gap: there is no atom between \(V_s\)
and \(P_s\), and such a straddling component would
interlace (2). Hence the replacement is disjoint
from all other pieces of Note 275's straight route
and gives \(S(Q)\).

For the crossed state, split \(Q\) into a prefix
\(U=B_{j_1},\ldots,B_s\), the port region
\(B_{s+1},\ldots,B_u\), and a suffix
\(W=B_{u+1},\ldots,B_w\). The elementary \(X\)
rails of Note 275 exist on \(U\) and \(W\) even
though their vacancy matching is not closed: they
use only old-cycle edges, face chords, and retained
ordinary links. In particular, no missing link lies
inside either interval. Note 286(6)--(8) gives a path
\(T:b_s\longleftrightarrow b_u\) spanning the port
region except \(I_u,e_u\). The required two paths are
\[
\begin{array}{l}
a_{j_1}\xrightarrow{X_{\rm top}(U)}b_s
 \xrightarrow{T}b_u
 \xrightarrow{X_{\rm top}(W)}b_w,\\[2pt]
o_{j_1}\xrightarrow{X_{\rm bottom}(U)}e_s,
 I_u,e_u
 \xrightarrow{X_{\rm bottom}(W)}e_w.
\end{array}                                             \tag{5}
\]
The joins into \(W\) are \(b_ua_{u+1}\) and the
retained \(e_uo_{u+1}\); the middle matching join is
\(e_sI_u\). The two \(X\) rail pairs, \(T\), and
\(I_u,e_u\) partition all vertices of \(Q\), so
(5) gives \(X(Q)\).

Thus every possible position of \(V_s\) gives a
three-state span. Vacancy-only parts outside it are
either in proper block gaps or serially disjoint.
Note 275's prime recursion and serial composition
give (1). Apply \(S(D)\) in each one-defect group,
Note 275's \(S\) in every zero-defect group, and
Note 273's group splice. Notes 001 and 178 supply
the marked parent Hamilton cycle, legal child,
and original lobe lengths. \(\square\)

**Boundary locality.** The three paths in (1) are
constructed entirely inside \(D\). The retained
ordinary end links are used only to attach \(D\)
to the global free path after its signature is
proved. Consequently the same \(S,K,X\) assertion
applies to a subinterval with one internal missing
link whose right or left ordinary end link is
absent outside it, provided all nonboundary
matching slots of the subinterval are matched
inside and its four boundary vertices remain
available as ports.

The theorem classifies the one-missing-link branch of
the stated opening. Groups with two or more missing
links, target-bearing or repeated same-block vacancies,
positive gaps, defective target order, and nonsquare
residual cycles remain outside it. It does not settle
Barnette's conjecture.
