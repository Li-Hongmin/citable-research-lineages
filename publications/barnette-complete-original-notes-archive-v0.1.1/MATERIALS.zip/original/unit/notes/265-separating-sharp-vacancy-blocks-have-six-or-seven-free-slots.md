> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Separating sharp vacancy blocks have six or seven free slots

[Note 264](264-same-block-third-surplus-gaps-are-hamiltonian-unless-the-block-separates-them.md)
leaves one same-block placement at the first positive-gap
boundary: two singleton gaps \(g<h\) with the two-vacancy
block \(B\) strictly between them. Both gap slots match
\(B\), their mates enclose every target of \(B\), and at
least two face-side free chords lie in \(B\). The target
count now bounds its free slots and fixes the six-free
case completely.

Use the compressed all-square opening with \(\ell,r\ge1\),
\[
 f=4r+8,\qquad \sigma=T=2,                         \tag{1}
\]
in a Barnette parent. Assume the two vacant eligible
positions belong to one block \(B=[a,b]_C\), and the
gap slots occur as \(g<B<h\). Write \(2K+2\) for the
number of interior slots of \(B\), listed
\(z_1,\ldots,z_{2K+2}\). This block is reversed:
its colours alternate \(E,O,E,O,\ldots,E,O\), and
its \(K\) eligible positions for nonfinal \(L\)-targets
are \(z_3,z_5,\ldots,z_{2K+1}\).

**Six-or-seven-slot theorem.** The block \(B\) contains
no \(L_1\) and has either six or seven free interior
slots. It has exactly two face-side free matching chords.
In the seven-free case, its target subsequence begins and
ends with an \(L\)-target, and its remaining seventh free
slot is matched outside \(B\).

In the six-free case, \(K\ge3\). The target subsequence
of \(B\) begins with an \(R\)-target at \(z_4\), ends
with an \(L\)-target at \(z_{2K-1}\), and occupies every
slot between them. The vacancies are exactly
\(z_3,z_{2K+1}\). Up to reversing the entire opening,
the only possible matching incidences on the six free
block slots and two gap slots are
\[
 gz_2,\qquad z_{2K+1}h
 \quad\hbox{on the opposite side of \(C\)},          \tag{2}
\]
and the two nested face-side chords
\[
 z_1z_{2K+2},\qquad z_3z_{2K}.                       \tag{3}
\]
This is a necessary local normal form; it makes no
Hamilton assertion for the separating-block branch.
In a three-connected parent, the two singleton gaps are
immediately adjacent to \(B\). Moreover, if \(A\) is the
even-starting-edge perfect matching of the old Hamilton
cycle, then \(M\cup A\) has the isolated eight-cycle
\[
g,z_2,z_1,z_{2K+2},z_{2K+1},h,b,a,g.                \tag{5}
\]
Thus the canonical equality-cycle construction of
Note 196 does not itself give a Hamilton cycle here.

**Proof.** Note 264 gives two distinct gap mates in
\(B\) and at least two distinct face-side free chords
there. These four chord endpoints and the two gap mates
are six distinct free vertices. Thus \(B\) has at least
six free slots and \(K\ge2\). Because \(B\) contains a
target, \(K=2\) would leave at most five free slots;
hence \(K\ge3\).

Exactly \(K-2\) of the \(K\) eligible positions are
occupied by nonfinal \(L\)-targets. Their target sequence
inside a consecutive block of \(C\) is a contiguous
subsequence of
\(R_\ell,L_\ell,\ldots,R_1,L_1\). If \(L_1\) also lay
in \(B\), that subsequence would have \(K-1\)
\(L\)-targets and at least \(K-2\) \(R\)-targets,
leaving at most
\[
 (2K+2)-(2K-3)=5
\]
free slots, a contradiction. Thus \(L_1\notin B\).
With \(K-2\) \(L\)-targets and at least \(K-3\)
\(R\)-targets, the free-slot count is at most seven.
Three face-side free chords would need six endpoints
in addition to the two gap mates, so there are exactly
two. If there are seven free slots, their target count
is \(2K-5\), with \(K-3\) \(R\)-targets. An alternating
target subsequence with one fewer \(R\) than \(L\)
begins and ends with \(L\). The seventh free slot is
neither a gap mate nor a face-chord endpoint, hence is
matched outside \(B\).

Now suppose there are six free slots. Then there are
\(K-2\) targets of each type, so the target subsequence
either starts with \(R\) and ends with \(L\), or starts
with \(L\) and ends with \(R\). All six free slots are
used by the two gap edges and the two face-side chords;
no free matching edge leaves \(B\) except its two edges
to the gap slots.

We exclude a first \(L\)-target. In a reversed block,
it cannot occupy \(z_1\) by Note 195. It can occupy
only \(z_3,z_5\), or \(z_7\), because every preceding
eligible position is vacant and there are only two
vacancies. If it is \(z_3\), only \(z_1,z_2\) precede
it, and the left gap mate must be \(z_2\). A face-side
chord straddling \(z_2\) would have to cross the target
\(z_3\), but the even-prefix parity of Note 264 would
require a second crossing chord and there is only one
free slot before \(z_3\) besides its gap mate.

If the first target is \(z_5\), all four earlier slots
are free and one is the left gap mate. Only two of
the six free slots then lie after \(z_5\). The number
of face-side chords crossing \(z_5\) is even. If it
is zero, every face chord uses either zero or two of
the three unmatched earlier slots, leaving one uncovered.
If it is two, they use both later free slots and
two earlier ones, leaving the third unmatched earlier
slot with no matching partner. Both contradict the
complete matching of the six free slots. If the first
target is \(z_7\), all six free slots precede it and
there is no right gap mate. Thus the target sequence
must start with \(R\).

The first \(R\)-target cannot be \(z_2\), since the
left gap mate must be an earlier \(O\)-slot. It cannot
be \(z_6\) or later: \(z_3,z_5\) would already be the
two vacancies, so at least five free slots would lie
before the first target, leaving at most one after the
last target. The right gap mate would then have no
face-side chord straddling it, contrary to Note 258.
Hence the first target is \(z_4\), and \(z_3\) is the
first vacancy.

The target subsequence ends with an \(L\)-target.
Its right gap mate is an \(E\)-slot after that target,
so at least one eligible position follows it. Since
\(z_3\) is already vacant, only one other eligible
position can be free. Therefore the final target is
\(z_{2K-1}\) and \(z_{2K+1}\) is the second vacancy.
There are exactly \(2K-4\) slots from \(z_4\) through
\(z_{2K-1}\), exactly the number of targets in \(B\);
every one of those slots is a target. The free slots
are therefore
\[
 z_1,z_2,z_3,\qquad z_{2K},z_{2K+1},z_{2K+2}.       \tag{4}
\]
The left gap slot has colour \(E\), so its only free
\(O\)-mate before the targets is \(z_2\). The right
gap slot has colour \(O\), so its only free \(E\)-mate
after the targets is \(z_{2K+1}\). This proves (2).

The four remaining free vertices have colours
\(E,E,O,O\) in the order
\(z_1,z_3,z_{2K},z_{2K+2}\).
The pairing
\(z_1z_{2K},z_3z_{2K+2}\) interlaces on \(C\);
the two edges would cross on the designated-face side.
The only noncrossing pairing is the nested pair (3).

Suppose a complete block lies between \(g\) and \(B\).
The chord \(gz_2\) spans it, so Note 203 excludes every
target there. It is saturated, hence short, and its two
free interior slots cannot match each other because they
are adjacent on \(C\). Any opposite-side edge from their
union to before \(g\) or to after \(z_2\) would interlace
\(gz_2\). The only free vertex of \(B\) before \(z_2\)
is \(z_1\), already matched by (3). Face-side free chords
cannot join different blocks. The entire interval of
complete blocks between \(g\) and \(B\) is therefore
matching-closed, giving a forbidden two-edge cut.
The reflected argument with \(z_{2K+1}h\) and the already
matched \(z_{2K+2}\) excludes complete blocks between
\(B\) and \(h\). Hence both gaps touch \(B\).

Number \(C\) from \(x\) and let \(A\) pair each even-indexed
vertex with its next neighbour on \(C\), as in Note 196.
The first gap slot \(g\) is even-indexed. The consecutive
edges \(ga,z_1z_2,z_{2K+1}z_{2K+2},bh\) therefore lie
in \(A\). Alternating them with the matching edges
\(gz_2,z_1z_{2K+2},z_{2K+1}h,ab\) gives precisely
the eight-cycle (5). Every vertex of that cycle has its
two \(M\cup A\) edges within it, while \(G\) has other
vertices. Thus it is a proper component of the two-factor
\(M\cup A\).
\(\square\)

The theorem isolates the exact six-free interface.
It does not establish that this interface extends to
a three-connected plane parent, nor that any such parent
or its site-expanded child is Hamiltonian.
