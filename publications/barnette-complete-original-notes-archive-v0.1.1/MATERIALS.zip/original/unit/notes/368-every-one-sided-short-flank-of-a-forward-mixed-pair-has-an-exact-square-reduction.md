> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every one-sided short flank of a forward mixed pair has an exact square reduction

[Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md)
classifies an arbitrary one-sided short flank before a
forward adjacent \(J_3,J_1\) double-block pair. When its
local \(hJ\) chord is present, the two double blocks form
the exact 16-vertex square patch. Every remaining matching
has a whole-flank square reduction, including all values
of Note 335's return parameter \(\mu\).

Let the consecutive old-cycle blocks be
\[
 S=(c,r,s,d),\quad D=(a,o,h,i,k,j,e,b),\quad
 D'=(A,O,H,I,K,J,E,B).                              \tag{1}
\]
Besides their old-cycle paths, take the common-face chords
\[
                 cd,\quad ab,\quad ie,\quad AB,\quad OK
                                                               \tag{2}
\]
and the nonstandard opposite-page chords
\[
                        rh,\quad so,\quad kI,\quad jH.
                                                               \tag{3}
\]
The left ordinary endport matches \(J\), and the right one
matches \(E\), as in Note 335 (16), state II. Removing those
two exterior matching edges gives an induced 20-vertex disk
patch \(T\) with degree-two terminals in boundary order
\[
                              (c,J,E,B).               \tag{4}
\]

**Nonstandard-flank theorem.** The complete vertex-spanning
one-path and two-path terminal signature of \(T\) equals
that of the square with order (4). Replacing \(T\) by that
square, or conversely, preserves Barnette membership and
every exterior and attachment-edge Hamilton decision.
The patch is realized by Note 335's 32-vertex Barnette
parent, whose legal site-expanded child is Hamiltonian.
Consequently a vertex-minimal non-Hamiltonian Barnette graph
contains no induced disk copy of \(T\).

**Four single paths.** The full old-cycle path from \(c\)
to \(B\) is one state. The other three vertex lists are
\[
\begin{split}
P_{JE}={}&(J,K,O,H,I,k,j,e,i,h,r,c,d,s,o,a,b,A,B,E),\\
P_{EB}={}&(E,J,K,O,H,I,k,j,e,i,h,r,c,d,s,o,a,b,A,B),\\
P_{cJ}={}&(c,r,s,d,a,o,h,i,k,I,K,O,H,j,e,b,A,B,E,J).
\end{split}                                               \tag{5}
\]
The first is Note 335 (17) without its exterior endports.
In the second, \(EJ\) and \(AB\) replace the final
attachment choice of that route. In the third, \(kI\),
\(OK\), and \(jH\) detour through the right block before
the old suffix \(j,e,b,A,B,E,J\). Each list has all 20
vertices once. Every consecutive pair is an old-cycle
edge or a chord in (2)--(3).

**Both two-path states.** For the pairing
\(\{cB,JE\}\), use
\[
 (c,r,s,d,a,o,h,i,k,I,K,O,H,j,e,b,A,B),
                         \qquad (J,E).                  \tag{6}
\]
The long path uses \(kI,OK,jH,AB\); its 18 vertices
are exactly those outside the second edge. For
\(\{cJ,EB\}\), use
\[
 (c,r,s,d,a,o,h,i,k,j,e,b,A,O,H,I,K,J),
                         \qquad (E,B).                  \tag{7}
\]
The long path is the old-cycle prefix through \(J\).
Both pairs are disjoint and span \(T\).

The terminals \(c,E\) have one bipartition colour and
\(J,B\) the other, so the two other single-path endpoint
pairs are impossible on an even-order spanning path.
The remaining two-path pairing \(\{cE,JB\}\) crosses
the disk order (4). Thus (5)--(7) give precisely the
square signature, and the Hamilton transfer follows by
replacing the internal path or path pair with the same
terminal state.

**Barnette preservation.** Note 335 (11)--(14) gives an
explicit 32-vertex three-connected cubic bipartite plane
realization: its exterior attachments to \(T\) are at
\(c,J,E,B\), and its Hamilton cycle through both site
edges is displayed there in (15). Each block of (1) has
its old-cycle path plus closing chord as a cycle. Between
\(S,D\) the joins \(da,rh,so\) have pairwise disjoint
endpoints; between \(D,D'\) the joins \(bA,kI,jH\)
do as well. Deleting any one patch vertex leaves each
block connected and at least two joins across each
adjacent-block boundary, so \(T-v\) is connected.
After deleting two patch vertices, every surviving
component contains a surviving terminal: otherwise it
would disconnect from the exterior in Note 335's
three-connected realization. The exterior of a
four-attachment patch in any Barnette host is connected.
The four-attachment deletion comparison of Note 362
therefore preserves three-connectivity in both directions.
The ordered coloured disk attachments preserve planarity,
cubicity, bipartiteness and simplicity. \(\square\)

**One-flank consequence.** Note 335 (16) proves that state I
and state II exhaust actual matchings of the one-short-left-
flank \(J_3,J_1\) ordinary free group. State I has the
16-vertex square patch of Note 335; state II has \(T\).
Hence every actual matching in that group contains an
exact square reduction, regardless of vacancies outside the
group. Reflection gives the one-short-right-flank case.
Since \(EB\) is an edge of \(T\), Note 367 adds any number
of standard right short buffers to state II while preserving
the exact signature and Barnette class; its 32-vertex
realization extends to order \(32+4q\), \(q\ge0\).

**Arbitrary-length outer return.** Let
\(p\ge1\) short blocks
\(S_t=(c_t,o_t,e_t,d_t)\), \(1\le t\le p\), precede
the same \(D,D'\) of (1). Give them their old-cycle paths
and face-closing chords \(c_td_t\). Keep \(ie,OK\) and
the opposite-page matching
\[
LJ,\qquad o_1h,\qquad
e_to_{t+1}\ (1\le t<p),\qquad e_po,\qquad
kI,\quad jH,\quad ER.                                  \tag{8}
\]
This is exactly the \(\mu=0\) nonstandard family of
Note 335 (18). Removing \(LJ,ER\) gives an induced
\((16+4p)\)-vertex disk patch \(T_p\) with terminals
\((c_1,J,E,B)\) in cyclic boundary order.

**Chain theorem.** For every \(p\ge1\), \(T_p\) has
the exact square Hamilton signature and may be replaced
by a square in either direction while preserving Barnette
membership and all exterior Hamilton decisions. Note 335's
explicit family realizes \(T_p\) in a \((28+4p)\)-vertex
Barnette parent with a Hamilton cycle through both site
edges; its legal child is Hamiltonian.

To prove the signature, start with the six linkage states
given by (5)--(7) and the full old-cycle path at \(p=1\).
Each displayed linkage uses exactly one of the two edges
\[
                       d_1a,\qquad e_1o.               \tag{9}
\]
The old-cycle path, \(P_{cJ}\), and both long paths
in (6)--(7) use \(d_1a\); \(P_{JE}\) and \(P_{EB}\)
use \(e_1o\). This exclusive choice persists during
the following insertion.

Suppose the routes have been lifted through \(S_p\).
Insert \(S_{p+1}\) between \(S_p,D\), replacing
the old edge \(d_pa\) and matching edge \(e_po\)
by the old joins \(d_pc_{p+1},d_{p+1}a\) and matching
joins \(e_po_{p+1},e_{p+1}o\). If a route uses
\(d_pa\), replace that edge by
\[
           d_p,c_{p+1},o_{p+1},e_{p+1},d_{p+1},a.
                                                               \tag{10}
\]
If it uses \(e_po\), replace that edge by
\[
           e_p,o_{p+1},c_{p+1},d_{p+1},e_{p+1},o.
                                                               \tag{11}
\]
In (10) the four new vertices lie on the old-cycle
path; in (11) the middle join \(c_{p+1}d_{p+1}\)
is the new face chord. Both routes use the four new
vertices exactly once and preserve every old terminal
and path pairing. The lifted route again uses exactly
one of \(d_{p+1}a,e_{p+1}o\), so induction supplies
all six square states for every \(p\). Adding four
vertices preserves the terminal colours and their disk
order; bipartiteness and planarity exclude the other
two single-path pairs and the crossing two-path pairing.

For class preservation, each short block and each double
block remains connected after deleting one vertex.
Adjacent short blocks have the vertex-disjoint joins
\(d_tc_{t+1},e_to_{t+1}\), the final short block and
\(D\) have \(d_pa,e_po\), and \(D,D'\) have
\(bA,kI,jH\). Thus deleting one vertex leaves the
entire patch connected. Note 335's realization of every
\(\mu=0,p\) matching is three-connected; after two
patch vertices are deleted, a component lacking a
surviving terminal would disconnect from its exterior.
The four-attachment deletion comparison of Note 362
then proves class preservation in both directions, as
for \(p=1\). Note 335 (19) gives the marked Hamilton
route in each parent, and Note 001 gives the child.
\(\square\)

The edge \(EB\) remains at the right boundary of every
\(T_p\). Note 367 therefore adds any number \(q\ge0\)
of standard right short buffers. These patches have
\(16+4p+4q\) vertices and their Barnette parent
realizations have \(28+4p+4q\) vertices, with the same
exact signature and marked Hamilton cycle.

**The first internal return.** The case \(p=2,\mu=1\)
is the seed for every other nonstandard one-sided flank.
Put \(S_t=(c_t,o_t,e_t,d_t)\), \(t=1,2\), and use
the matching
\[
Lo_1,\quad e_1J,\quad o_2h,\quad e_2o,
              \quad kI,\quad jH,\quad ER.                \tag{12}
\]
The induced 24-vertex patch has terminals
\((c_1,o_1,E,B)\) in disk order. Its full old-cycle
path gives the \(c_1B\) single-path state, and
Note 335 (19) without its endports gives \(o_1E\).
Two further spanning single paths are
\[
\begin{split}
P_{c_1o_1}={}&(c_1,d_1,c_2,o_2,e_2,d_2,a,o,h,i,k,I,
 K,O,H,j,e,b,A,B,E,J,e_1,o_1),\\
P_{EB}={}&(E,J,e_1,o_1,c_1,d_1,c_2,o_2,e_2,d_2,
 a,o,h,i,k,I,K,O,H,j,e,b,A,B).
\end{split}                                               \tag{13}
\]
For \(\{c_1B,o_1E\}\), take
\[
\begin{split}
&(c_1,d_1,c_2,o_2,e_2,d_2,a,o,h,i,k,I,K,O,H,j,e,b,A,B),\\
&(o_1,e_1,J,E).
\end{split}                                               \tag{14}
\]
For \(\{c_1o_1,EB\}\), take \((c_1,o_1)\) and
\[
(E,J,e_1,d_1,c_2,o_2,e_2,d_2,a,o,h,i,k,I,K,O,H,
                       j,e,b,A,B).                      \tag{15}
\]
Every consecutive pair in (13)--(15) is an old edge or
one of the displayed matching and face chords. The four
single paths have 24 distinct vertices; the path pairs
have respectively 20+4 and 2+22. The same colour and
planar-order exclusion as for (4) makes their signature
exactly the square's.

Each of these six linkage states uses exactly one of
\(d_2a,e_2o\): the \(o_1E\) route uses \(e_2o\), while
the other five use \(d_2a\). The insertion (10)--(11)
therefore extends the seed to every \(p\ge2\) with
\(\mu=1\), preserving this exclusive rail choice.
The terminals \(c_1,o_1\) are adjacent. A left standard
buffer of Note 367 adds one short block, changes
\((p,\mu)\) to \((p+1,\mu+1)\), and leaves the chosen
terminal routes' use of the final rail unchanged.
Starting from \((2,1)\), insert
\(p-\mu-1\) final-rail blocks, then \(\mu-1\)
left buffers. This reaches every
\(p\ge2,1\le\mu<p\) and proves its exact square
signature.

For these \(\mu\ge1\) patches, all block cycles survive
one vertex deletion. Every adjacent-block boundary has
two vertex-disjoint joins except possibly
\(S_\mu,S_{\mu+1}\), whose old join is
\(d_\mu c_{\mu+1}\). If that join is lost, the chord
\(e_\mu J\) survives and reconnects the left prefix
to \(D'\) on the right. Thus every patch remains
connected after deleting one vertex. Note 335 realizes
every \((p,\mu)\) in a three-connected Barnette parent,
so its two-vertex terminal property follows as above.
The four-attachment deletion comparison proves
class-preserving replacement for every \(\mu\).
Note 335 (19) supplies the marked Hamilton parent route.

Together with the \(\mu=0\) chain theorem, this covers
all nonstandard matchings (18) of Note 335. If the
local \(hJ\) chord occurs instead, Note 335's exact
16-vertex square patch applies. Hence every actual
matching of a forward adjacent \(J_3,J_1\) pair with
an arbitrary one-sided short flank contains a strict
exact square reduction, independent of outside vacancies.
Old-cycle reflection gives the right-sided version.
The right standard buffers above also apply to every
nonstandard whole-flank patch because its last two
terminals are joined by \(EB\).

Inner short corridors, two nonstandard outer flanks,
other orientation words, other opening types and
general Barnette graphs remain outside this result.
This is a project-internal analytic proof without an
independent external priority check.
