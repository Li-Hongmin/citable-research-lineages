> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A three-state support core gives an edge-Hamiltonian central chain

> **Correction.**  The support hypothesis below guarantees edge-Hamiltonicity
> for the positive-depth descendants, not automatically for the starting
> graph.  The corrected theorem, a sharp six-vertex base obstruction, and the
> precise Barnette orientation are given in Note 006.

Use the five central-transfer witnesses

\[
A=C_{11},\quad B=C_{10},\quad C=C_{01},\quad
D=X_{vx},\quad E=X_{uy}.
\]

For an old edge, the canonical central expansion sends its five-role support
vector by

\[
(a,b,c,d,e)\longmapsto(b,e,d,a,a).
\]

The unique recurrent gadget-cover core is

\[
\boxed{\{A,B,E\}=\{C_{11},C_{10},X_{uy}\}}.
\]

Indeed, the roles cycle as

\[
C_{11}\longrightarrow X_{uy}\longrightarrow C_{10}
\longrightarrow C_{11}.
\]

If initially every retained old edge belongs to at least one of these three
witnesses, that property is preserved by the central expansion.  Their child
cycles also cover all eight newly installed gadget edges.  Induction gives:

> If a starting expansion site admits the five transfer witnesses and
> \(E(G)\setminus\{p,q\}\subseteq
> E(C_{11})\cup E(C_{10})\cup E(X_{uy})\), then every positive-depth graph in
> the recursively selected central expansion chain is edge-Hamiltonian.

The reflected orientation has core \(\{C_{11},C_{01},X_{vx}\}\).

The five-witness package alone is insufficient.  A six-vertex simple
connected parent has all five witnesses, but after expansion one retained
edge lies on no Hamilton cycle; graph-atlas enumeration finds no example on
four or five old vertices.  Thus the support-core hypothesis is a real
strengthening, not proof bookkeeping.

More generally, for any chosen parent witness family, induced child cycles
cover the child exactly when their old-edge union covers every retained old
edge and their traversal types contain one of the seven minimal gadget covers
from Note 002.

The finite algebra and minimal obstruction are checked by
`scratch/worker-barnette/verify_central_support_dynamics.py` and
`scratch/worker-barnette/search_minimal_p5_old_edge_obstruction.py`.
