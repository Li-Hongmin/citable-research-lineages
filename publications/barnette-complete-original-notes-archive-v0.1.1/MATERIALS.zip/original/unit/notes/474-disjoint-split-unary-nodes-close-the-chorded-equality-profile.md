> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disjoint split unary nodes close the chorded equality profile

[Note 472](472-one-adjacent-and-one-split-unary-node-always-splice-at-chorded-equality.md) leaves two marked unary nodes whose direct special positions straddle their respective child words. Their ordinary intervals may be disjoint or nested. The disjoint case has a spanning four-terminal two-path cover: two inner openings suffice except for one terminal-free component pattern, which a mixed inner/outer opening closes.

Use the one-root chorded equality profile of [Notes 469–470](470-one-four-special-leaf-always-supplies-the-chorded-four-port-cover.md). The root word \(W\) has terminals
\[
                        T=\{r_L,u,v,r_R\},\qquad r_L<u<v<r_R,
\tag{1}
\]
and the two exterior path covers of [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) realize different pairings of \(T\). Every assigned position apart from the four direct positions of two marked unary nodes lies in a two-special ordinary leaf. Suppose the nodes are disjoint and ordered as
\[
              N_i=(H_i,s_i,A_i,t_i,J_i),\qquad
              N_1<N_2,\qquad i=1,2,
\tag{2}
\]
where \(A_i\) is the sole child word, with ends \(L_i,R_i\). Let \(C_W\) be the old root cycle, \(E\) the square-supported old edges of the two-special leaves, and \(M\) the face matching of root special positions outside \(T\).

**Disjoint two-split theorem.** If the two marked unary intervals are disjoint, the parent has a Hamilton cycle through both site edges and its legal expanded child is Hamiltonian. Thus a non-Hamiltonian chorded child at \(c=5f-7\) requires its two split marked unary nodes to be nested.

**Terminal barrier.** If an ordinary child interval \(A_i\) contains a terminal \(x\in T\), no face-side matching chord can join a position before \(A_i\) to a position after \(A_i\). The third edge at \(x\) goes to one of \(w_0,z_L,z_R,w_*\), all outside \(W\). Its chord interlaces any chord spanning \(A_i\), whether the exterior endpoint lies left or right of \(W\).

**Two inner openings.** Form
\[
 F_{\rm ii}
   =\bigl(C_W-E-\{s_1L_1,R_1t_1,s_2L_2,R_2t_2\}\bigr)
       \cup M\cup\{L_1R_1,L_2R_2\}.
\tag{3}
\]
It consists of two terminal paths and perhaps cycles. Restoring \(E\) exposes four old pieces: the two child arcs \(A_i\), each closed by \(L_iR_i\), and two complementary arcs \(B_{\rm mid}=t_1\rightsquigarrow s_2\) and \(B_{\rm out}=t_2\rightsquigarrow s_1\), the latter using the root chord. At equality each marked unary node has two consecutive plain-unary ancestors, as in [Note 471](471-two-adjacent-unary-pairs-always-splice-at-chorded-equality.md). The square between the core chord \(H_1J_1\) and its immediate plain-unary parent has one old rail edge in each complementary arc. Its two ordinary chords are unused by (3), and its support is disjoint from the leaf squares. It is therefore an available switch joining different components on \(B_{\rm mid},B_{\rm out}\). The second node supplies the same option.

For connectivity, regard the complementary arcs and a selected wrapper-square link as one coarse block \(B\). Contract each \(A_i\) and \(B\), and retain the \(M\)-edges between them; call this three-vertex graph \(K\). Leaf-square switches within the three blocks and the wrapper switch across the two halves of \(B\) have exactly the component connectivity of \(K\). A leaf whose chord \(L_iR_i\) was inserted in (3) has its deleted leaf edge as a quotient loop, so its unavailable square switch is never needed. If \(K\) is connected, switch along a forest rooted at the two terminal paths to absorb every cycle. The same works componentwise if every component of \(K\) has two terminals.

It remains to analyze a component of \(K\) without terminals. An isolated \(A_i\) with no terminal is impossible: no \(M\)-edge leaves it, its ordinary third edges are internal, and its two old boundary edges would form a two-edge cut. An isolated \(A_i\) with all four terminals is also impossible. For \(i=1\), let \(P\) be the special positions before \(s_1\). They are complete two-special leaves, so \(P\cup\{s_1\}\) has odd cardinality and no terminal. Its \(M\)-edges cannot enter the isolated \(A_1\); an edge to any position after \(A_1\) would violate the terminal barrier. It cannot be perfectly matched. For \(i=2\), use the symmetric odd set \(\{t_2\}\) together with the complete two-special leaves after \(t_2\).

Nor can \(B\) be an isolated zero-terminal block. Let \(A_j\) be the first child interval containing a terminal, so \(j=1\) or \(2\). Take the special positions before \(s_j\), together with \(s_j\), as a set \(S\). It contains no terminal and has odd cardinality: all prior leaves and child words contribute even numbers of special positions, while prior direct positions come in pairs. Because \(B\) is isolated, its positions in \(S\) have no \(M\)-edge to either child; an \(M\)-edge from such a position to \(B\) after \(A_j\) violates the terminal barrier. If \(j=2\), the preceding terminal-free child \(A_1\) may send \(M\)-edges to \(A_2\), but their number is even, since \(A_1\) has an even number of special positions and no terminal or \(M\)-edge to \(B\). Hence an even number of \(M\)-edges leave the odd set \(S\), impossible.

The only remaining zero-terminal component of \(K\) is \(A_1\cup A_2\), with all four terminals in the isolated block \(B\). In that case at least one \(M\)-edge joins \(A_1,A_2\), and no \(M\)-edge joins either child to \(B\).

**Mixed opening for the last case.** Open one node \(N_i\) outside its interval and the other node \(N_j\) inside its child:
\[
 F_{\rm oi}
  =\bigl(C_W-E-\{H_is_i,t_iJ_i,s_jL_j,R_jt_j\}\bigr)
      \cup M\cup\{H_iJ_i,L_jR_j\},\qquad \{i,j\}=\{1,2\}.
\tag{4}
\]
The core chord \(H_iJ_i\) is unused by \(C_W\), because its marked node has two plain-unary ancestors. After restoring \(E\), the old pieces in (4) are the central arc \(P_i=s_i\rightsquigarrow t_i\), the closed child \(A_j\), and one complementary path \(B'\): its two outside arcs are joined by \(H_iJ_i\). The \(M\)-edge between \(A_i,A_j\) joins \(P_i\) to \(A_j\).

If at least one of the four direct positions \(s_1,t_1,s_2,t_2\) is not a terminal, choose \(i\) with such a position. Its third edge is an \(M\)-edge to \(B\), because no \(M\)-edge joins \(B\) to a child and [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) forbids pairing \(s_i\) with \(t_i\). Under (4) this edge joins \(P_i\) to \(B'\). Thus all three coarse pieces are connected, and their leaf-square quotient yields a spanning two-path cover.

If all four direct positions are terminals, choose either \(i\). Then \(P_i\) and \(B'\) each contain two terminals, while \(A_j\) contains none and is joined to \(P_i\) by the \(M\)-edge between the children. Absorb all cycles into the terminal path of their coarse component, separately from the other terminal path. Again the result is a spanning two-path cover.

In all cases one exterior pairing of Note 460 differs from the internal pairing and completes a parent Hamilton cycle through both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the expanded child. \(\square\)

The theorem closes disjoint split nodes only. Nested split nodes and other selected openings remain outside its conclusion.
