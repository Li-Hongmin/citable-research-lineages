> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# State-\(00\) chord rerouting requires a nonlocal decorated connector

Let \(G\) be a plane simple cubic bipartite 3-connected graph, let
\(p=uv,q=xy\) be a legal common-face \(C_4\)-expansion pair, and let \(Z\)
be a Hamilton cycle avoiding \(p,q\). Fix retained edges

\[
r\in E(Z),\qquad s\notin E(Z).
\tag{1}
\]

Thus \(Z\) separates the ordered pair \((r,s)\) in the parent but is a
nonliftable state-\(00\) witness. This note classifies every rerouting
supported on \(Z\cup\{p,q\}\) and identifies the first adequate nonlocal
operation.

## The two site edges are noncrossing chords

Both \(p,q\) belong to the perfect matching \(E(G)\setminus E(Z)\).
Relative to the Jordan curve \(Z\), they lie on the same side because they
occur on one common face. Their endpoints therefore do not alternate
around \(Z\).

Put

\[
J=Z\cup\{p,q\}.
\tag{2}
\]

At every vertex outside \(\{u,v,x,y\}\), a spanning traversal supported in
\(J\) must use both incident \(Z\)-edges. Hence every removed \(Z\)-edge
has both endpoints among the four terminals. It follows that:

- \(J\) supports no traversal of type \(A,B\), or \(C\). A one-chord
  Hamilton reconnection would require a parallel \(uv\)- or \(xy\)-edge,
  while a two-chord Hamilton reconnection requires alternating chord
  endpoints.
- A local \(D=X_{vx}\) exists exactly when \(vx\in E(Z)\), and is uniquely
  \[
  D_Z=Z-\{vx\}.
  \tag{3}
  \]
- A local \(E=X_{uy}\) exists exactly when \(uy\in E(Z)\), and is uniquely
  \[
  E_Z=Z-\{uy\}.
  \tag{4}
  \]
- A local \(L\) exists exactly when two terminal-gap edges of \(Z\) can be
  deleted to leave the two path components paired as \(uv\) and \(xy\).
  In the separated circular order \(u,v,x,y\), these are \(vx\) and \(yu\);
  the nested order has the analogous two gap edges.

Since \(s\notin Z\), every local witness automatically avoids \(s\). It
contains \(r\) exactly when none of its deleted edges is \(r\). Therefore:

> A decorated traversal supported in \(J\) exists if and only if one of
> (3), (4), or the two-edge \(L\)-deletion is available and its deleted
> edge set avoids \(r\).

This is an exact classification, not merely a sufficient construction.

## Exact nonlocal connector form

Let \(W\) be a spanning \(u\)-\(y\) path in \(G-\{p,q\}\). Cubicity makes

\[
\Gamma=Z\mathbin{\triangle}W
\tag{5}
\]

the disjoint union of one \(Z\)-alternating \(u\)-\(y\) path, starting and
ending with \(Z\)-edges, and zero or more alternating cycles. Under (1),

\[
r\in W,\ s\notin W
\quad\Longleftrightarrow\quad
\{r,s\}\cap E(\Gamma)=\varnothing.
\tag{6}
\]

Conversely, an alternating union \(\Gamma\) of this form gives a decorated
\(E\)-witness exactly when \(Z\triangle\Gamma\) is connected. The reflected
statement gives \(D\). Thus the first adequate positive mechanism is:

> Find a \(Z\)-alternating terminal path, optionally with alternating
> cycles, that avoids \(r,s,p,q\) and whose flip leaves one connected
> spanning path.

As in Note 017, the connectivity clause is the global burden; degree and
endpoint conditions alone are insufficient.

## A real boundary at order \(20\)

Use the fixed global-\(H^{+-}\) Barnette graph

    S???????F?Y?b??wCQ?U?DC?CoB_??R??

with legal site

\[
(u,v,x,y)=(0,12,5,16).
\tag{7}
\]

Take

\[
\begin{aligned}
Z={}&\{0\!-\!10,0\!-\!11,1\!-\!11,1\!-\!18,2\!-\!10,
2\!-\!14,3\!-\!16,3\!-\!18,4\!-\!12,4\!-\!19,\\
&5\!-\!12,5\!-\!17,6\!-\!14,6\!-\!15,7\!-\!13,
7\!-\!15,8\!-\!13,8\!-\!19,9\!-\!16,9\!-\!17\},
\end{aligned}
\tag{8}
\]

and

\[
r=5\!-\!12=vx,\qquad s=8\!-\!17.
\tag{9}
\]

Here \(vx=r\in Z\) and \(uy\notin Z\). Hence the only traversal supported
in \(J\) is \(D_Z=Z-\{r\}\), which destroys the required positive
incidence.

The complete traversal census at this site is

\[
(|A|,|B|,|C|,|D|,|E|,|L|)
=(12,4,4,4,4,4).
\tag{10}
\]

For the decorated pair \((r,s)\), however,

\[
\mathcal T^{+-}_{r,s}=\{E\}.
\tag{11}
\]

In particular, no \(A,B,C\), or \(L\) perfect-matching witness works.
Ordinary perfect-matching alternating exchange, even with arbitrarily many
cycle flips, cannot solve this decorated pair.

All four \(E\)-paths do work. A shortest one differs from \(Z\) on the
five-edge alternating connector

\[
0-10-1-11-3-16,
\tag{12}
\]

which avoids \(r,s\). Flipping (12) turns \(Z\) into a connected spanning
\(u\)-\(y\) path while preserving the required decoration.

The cube is the positive local control: for the state-\(00\) separator in
Note 016, both \(vx\) and \(uy\) belong to \(Z\), and the direct deletions
already preserve its displayed pair incidence.

## Consequence

The joint retained-edge condition of Note 016 is not recoverable from the
two site chords or from the ordinary perfect-matching closure of a
state-\(00\) separator. The exact remaining interface is a decorated
alternating terminal connector with a connected-complement requirement.
The fixed graph is a route obstruction, not a failure of preservation: its
nonlocal \(E\)-paths rescue the pair.

The certificate is

    python3 units/barnette/scratch/worker-c4-hpm/verify_state00_chord_rerouting_boundary.py

with terminal marker

    STATE00_CHORD_REROUTING_BOUNDARY_VERIFIED

