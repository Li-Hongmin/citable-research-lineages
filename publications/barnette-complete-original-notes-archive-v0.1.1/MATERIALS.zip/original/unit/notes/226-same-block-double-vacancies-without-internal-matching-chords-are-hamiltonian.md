> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Chord-free same-block double vacancies are Hamiltonian with arbitrary flanks

[Note 225](225-one-sided-flanks-of-a-double-vacancy-block-are-hamiltonian.md)
handles arbitrary short-block flanks on one side of a target-free
double-vacancy face block. With flanks on both sides, the
matching can use one vacancy pair on each side. The clean
structural boundary is whether the long face block has an
internal free matching chord.

Use the compressed all-square Barnette opening of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md):
\(\ell,r\ge1\), empty interblock gaps, tight target order,
and exactly two eligible vacancies, both in one target-free
face-chord block \(D\). Its free slots are
\[
o,h_1,i_1,h_2,i_2,e                               \tag{1}
\]
in old-cycle order. Its complete free matching group may have
arbitrary short target-free face blocks on both sides. Read
its ordinary slots from left to right and pair them in the
standard chain:
\[
P_j=(E_j,O_j),\qquad 0\le j<N,\qquad
E_0<O_0<E_1<O_1<\cdots<E_{N-1}<O_{N-1},
\quad N=t+u+2,                                      \tag{2}
\]
where \(t,u\ge0\) are the left and right flank lengths.
The first \(t+1\) ports lie before \(h_1\), and the last
\(u+1\) ports lie after \(i_2\). In particular,
\(P_t=(e_{\rm left},o)\) and
\(P_{t+1}=(e,o_{\rm right})\).

**Chord-free double-vacancy theorem.** Assume that no
matching edge joins two free slots of \(D\). Then exactly
two standard links \(P_a,P_b\), \(a<b\), are missing from
the free matching. Each is reconnected to itself through
one of the two vacancy pairs:
\[
E_j,i_s,h_s,O_j,\qquad s\in\{1,2\}.                 \tag{3}
\]
The two pairs use different indices \(j\).
Consequently the parent has a Hamilton cycle containing
both site edges \(xy,uv\), and its legal site-expanded
child is Hamiltonian. The statement allows arbitrary
flank lengths on both sides and arbitrary positive
original square-trap lobe lengths.

**Proof.** By Note 193, every free matching edge joining
different blocks lies opposite the site face. The short
blocks have only two adjacent free slots, so they have
no internal free matching edge. The hypothesis excludes
all internal free chords of \(D\). Hence every free
matching chord lies in the same opposite-side disk;
no two such chords interlace.

An ordinary-to-ordinary edge is necessarily one of the
standard chain links in (2). A forward edge skipping a
chain link encloses at least one complete face block.
A backward edge encloses a complete interval of blocks.
Every free matching edge from that interval to the
outside would interlace the proposed chord, while its
face chord is internal. The interval would therefore
be matching-closed and have only two exiting old-cycle
edges, contradicting three-connectivity. An ordinary
pair within one block is an old-cycle edge or an
excluded same-block chord. This is the skipping rule
of Note 220, now applicable because all free chords
are on one side.

The four extra slots \(h_1,i_1,h_2,i_2\) cannot match
one another: such an edge is either an old-cycle edge
or an internal free chord of \(D\). Each must therefore
match an ordinary slot. Because every ordinary-to-ordinary
edge is standard, exactly two chain links \(P_a,P_b\)
are missing. Each extra pair \(h_s,i_s\) joins one
\(E\)-port to one \(O\)-port: the even \(E\)-port
matches the odd \(i_s\), and the even \(h_s\) matches
the odd \(O\)-port.

If the two missing ports reconnect to themselves,
(3) follows. Otherwise there are two crossed
assignments:
\[
\begin{array}{c|cc}
 & (h_1,i_1)&(h_2,i_2)\\
{\rm I}&E_a\leftrightarrow O_b&E_b\leftrightarrow O_a\\
{\rm II}&E_b\leftrightarrow O_a&E_a\leftrightarrow O_b .
\end{array}                                           \tag{4}
\]
Each \(P_j\) lies wholly to the left of \(h_1\) or
wholly to the right of \(i_2\). Since \(a<b\), the
locations of \((P_a,P_b)\) are left-left, left-right,
or right-right. In each case (4) contains two
interlacing opposite-side matching chords:
\[
\begin{array}{c|ccc}
 &{\rm left\!-\!left}&{\rm left\!-\!right}&
   {\rm right\!-\!right}\\
{\rm I}
 &O_a h_2\ \text{and}\ E_b i_2
 &E_a i_1\ \text{and}\ O_a h_2
 &h_1O_b\ \text{and}\ i_2E_b\\
{\rm II}
 &O_a h_1\ \text{and}\ E_b i_1
 &E_a i_2\ \text{and}\ h_2O_b
 &h_1O_a\ \text{and}\ i_1E_b .
\end{array}                                           \tag{5}
\]
For example, the middle entry of row II has endpoint
order \(E_a<h_2<i_2<O_b\); the other five
orders follow directly from (2) and (1). Thus every
crossed assignment violates planarity. The two
reconnections are parallel, proving (3).

Let \(A\) be the even-starting old-cycle matching from
\(x\). Note 196's target-and-square \(x\)-to-\(v\)
path is unchanged. Its ordinary free \(x\)-to-\(v\)
path has chain links \(E_jO_j\). Replace the two
missing links by their disjoint paths (3). Their
outer edges are in the complementary matching and
\(i_sh_s\in A\). The resulting free path visits all
four extra slots exactly once and remains connected.
Together with the target-and-square path it is a
Hamilton cycle containing \(xy,uv\). Notes 001 and
178 give the legal child and original lobe lengths.
\(\square\)

**A two-sided realization.** For \(t=u=1\), take the
28-cycle in consecutive blocks
\[
\begin{array}{ll}
B_0:&x,R,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
D:&a_2,o,h_1,i_1,h_2,i_2,e,b_2,\\
B_3:&a_3,o_3,e_3,b_3,\\
B_4:&u,o_4,L,v,\\
\text{last arc}:&\alpha,\gamma,\delta,\beta,
\text{ returning to }x.
\end{array}                                            \tag{6}
\]
Add the complementary matching
\[
\begin{split}
&xy,uv,\ a_1b_1,a_2b_2,a_3b_3,
 \alpha\beta,\delta R,\gamma L,\\
&e_0i_1,o_1h_1,e_1o,\ eo_3,i_2e_3,h_2o_4.
\end{split}                                            \tag{7}
\]
The three left free chords are nested, as are the
three right free chords; the two groups are disjoint.
Draw them, \(\delta R,\gamma L\), opposite the site
face, and the other chords on the site-face side.
All matching edges join opposite cycle parities.
The matching-chord interlacement graph is connected:
\[
xy-e_0i_1-a_2b_2-h_2o_4-uv-\gamma L-
\alpha\beta-\delta R-xy                            \tag{8}
\]
is joined to \(a_1b_1\) by \(o_1h_1\), to
\(a_3b_3\) by \(i_2e_3\), to \(e_1o\) by
\(a_1b_1\), and to \(eo_3\) by \(a_2b_2\).
Thus the graph is simple, plane, cubic, bipartite and
three-connected by Note 217's interval criterion.
The site expansion is Barnette by Note 217's cut
projection. Its marked Hamilton route is the
two-link replacement (3). \(\square\)

This theorem leaves only matchings using an internal
free chord of \(D\) in the target-free same-block
double-vacancy group with two-sided flanks. It does
not address target-bearing vacancy blocks, outer-block
vacancies, defective target order, gaps or nonsquare
residual cycles.

