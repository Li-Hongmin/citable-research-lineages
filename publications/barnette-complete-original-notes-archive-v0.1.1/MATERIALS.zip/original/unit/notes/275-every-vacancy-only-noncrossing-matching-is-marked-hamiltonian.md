> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every vacancy-only noncrossing matching has a marked Hamilton route

[Note 274](274-rainbow-vacancy-cycles-absorb-at-every-surplus.md)
absorbs one rainbow cycle of vacancies. A noncrossing matching of
the vacancy slots may have several nested rainbow cycles. Their
nesting still admits a spanning route: the interval inside each
cycle has both a straight path and a two-path cap.

Use the compressed, gapless, tight-target all-square opening of
[Notes 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
and [215](215-separated-vacancies-compose-marked-hamilton-routes.md).
Let \(\ell,r\ge1\). Suppose every eligible vacancy is in a
different target-free internal face-chord block. In a vacant
block \(B_j\), write its old-cycle order as
\[
 a_j,o_j,H_j,I_j,e_j,b_j.                              \tag{1}
\]
Every other target-free internal block is short, with order
\(a_j,o_j,e_j,b_j\). Assume that the complementary perfect
matching \(M\) pairs all vacancy slots \(H_j,I_j\) among
themselves. No restriction is placed on the number of vacancies
or the distances between their blocks.

**Vacancy-only theorem.** The parent has a Hamilton cycle
containing both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian. This holds for every
noncrossing vacancy matching permitted by the plane embedding,
including nested collections of rainbow cycles, and for
arbitrary positive original square-trap lobe lengths.

**Matching structure.** All ordinary free slots match among
themselves. The skipping argument of Note 274, which uses only
this fact, forces
\[
 e_j o_{j+1}\in M\qquad(0\le j\le r).                \tag{2}
\]
Indeed, after the preceding links are fixed, a later mate
\(o_h\) of \(e_j\), with \(h\ge j+2\), would enclose a
complete block interval. An escape target in that interval
would make the chord cross its escape edge by Note 203.
Otherwise every matching edge leaving the interval would
cross \(e_jo_h\) in the opposite-side disk by Note 193;
the block-closing chords are internal. The interval would
have only two departing old-cycle edges, contrary to
three-connectivity. The same-block candidate was already
used, and the induction starts at \(e_0\).

The vacancy matching lies in this opposite-side disk and
is noncrossing. Put its \(2q\) vacancy endpoints on the
boundary in the order \(H_1,I_1,\ldots,H_q,I_q\), with
indices now referring only to the vacant blocks. Add the
boundary edges \(H_iI_i\), which belong to the even-starting
old-cycle matching \(A\), not to \(M\). Their union with
the vacancy edges of \(M\) is a disjoint family of simple
alternating Jordan cycles. Each bounds a disk on the same
side of every one of its boundary edges \(H_iI_i\).
Orienting its boundary accordingly traverses each such edge
from \(H_i\) to \(I_i\). Consequently, if its indices are
\(i_1<\cdots<i_m\), its matching edges are exactly
\[
 H_{i_1}I_{i_m},\qquad
 I_{i_t}H_{i_{t+1}}\quad(1\le t<m).                \tag{3}
\]
Here \(m\ge2\), since \(H_iI_i\) is already an old-cycle
edge. Distinct cycles give a noncrossing partition of the
vacant-block indices into parts of size at least two. Any
other part inside the span of (3) lies wholly between two
consecutive indices \(i_t,i_{t+1}\); otherwise its chords
would cross that cycle.

**Three routing states.** Consider a consecutive interval
\(D=[B_a,\ldots,B_b]\) of target-free internal blocks whose
vacancy matching is closed inside it. Its four external
ports are \(a_a,o_a,e_b,b_b\). We construct the following
vertex-spanning routings in the graph induced by \(D\):
\[
\begin{array}{ll}
X(D):& a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):& a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):& o_a\longleftrightarrow e_b.
\end{array}                                               \tag{4}
\]
The first two rows mean two vertex-disjoint paths; the last
means one path. In every row their union covers every vertex
of \(D\). For \(X(D)\), follow the face chords \(a_jb_j\)
and intervening cycle edges \(b_ja_{j+1}\) for the first
path. For the second, follow the old cycle through all
interior slots of each block and use the links (2) between
blocks. This proves \(X(D)\) for every such interval,
irrespective of its vacancy matching.

We prove \(K(D),S(D)\) by induction on the number of vacant
blocks. With none, \(D\) is the even four-terminal ladder
of Note 178: its two-path pairing gives \(K(D)\), while
\[
 o_a,a_a,b_a,e_a,o_{a+1},a_{a+1},b_{a+1},e_{a+1},
 \ldots,o_b,a_b,b_b,e_b                              \tag{5}
\]
gives \(S(D)\). A single short block is included.

For serial intervals \(D_1,D_2\), the joins are exactly
\(b_{D_1}a_{D_2}\in C\) and
\(e_{D_1}o_{D_2}\in M\). Joining their straight paths
across the second edge gives \(S(D_1D_2)\). Using
\(K(D_1)\) and \(X(D_2)\), then joining across both
edges, gives \(K(D_1D_2)\): the right path of \(K(D_1)\)
connects the two paths of \(X(D_2)\), while the left
path of \(K(D_1)\) remains the other cap path. Thus it
suffices to construct both states for a *prime* interval
from the first to the last block of one part (3). Other
parts inside a prime interval lie in its successive gaps;
all are shorter closed intervals.

Let the prime part occur in blocks
\(B_p=B_{i_1}<B_t=B_{i_2}<\cdots<B_u=B_{i_m}\).
For its cap state, leave \(e_ub_u\) as the right path.
The left path starts with \(a_p,b_p\), crosses the gap
from \(p\) to \(t\) by the top path of \(X\), returns
by its bottom path to \(e_p\), and then follows
\[
 e_p,I_p,H_t
 \xrightarrow{\ C\text{-arc}\ } I_u,H_p,o_p.       \tag{6}
\]
When the gap is empty, its crossing and return are simply
\(b_pa_t,o_te_p\); when it is nonempty, they are
\[
 b_p,a_{p+1}\xrightarrow{X_{\rm top}}b_{t-1},a_t,o_t,
 e_{t-1}\xrightarrow{X_{\rm bottom}^{-1}}o_{p+1},e_p.
                                                               \tag{7}
\]
The two exceptional edges in (6) are
\(I_pH_t,H_pI_u\in M\), from (3). The forward old-cycle
arc from \(H_t\) to \(I_u\) covers every vertex of
\(B_t,\ldots,B_u\) except the already used \(a_t,o_t\)
and the right path \(e_u,b_u\), including all nested
vacancies. Equations (6)--(7) therefore give
\(K(D)\) without any assumption on the matchings in the
other gaps.

For its straight state, start with the ordinary path (5)
through \(B_p,\ldots,B_u\), initially omitting all
vacancy slots. In each gap between consecutive prime
blocks after \(B_t\),
replace its ordinary subpath by the inductively obtained
\(S\)-path; this covers all nested vacancies there.
Between \(B_p\) and \(B_t\), use the inductive cap
\(K\) of that gap. If the gap is empty, replace
\(e_po_t\) by
\[
 e_p,I_p,H_p,
 (I_{i_j},H_{i_j})_{j=m,m-1,\ldots,2},o_t.          \tag{8}
\]
If the gap is nonempty, replace the ordinary segment
from \(b_p\) through that gap to \(a_t\) by
\[
\begin{split}
 b_p,a_{p+1}&\xrightarrow{K_L}o_{p+1},e_p,
 I_p,H_p,(I_{i_j},H_{i_j})_{j=m,m-1,\ldots,2},o_t,\\
 &e_{t-1}\xrightarrow{K_R}b_{t-1},a_t .
\end{split}                                             \tag{9}
\]
The middle of (8)--(9) follows the prime alternating
cycle (3), except for its edge \(I_pH_t\); its first and
last joins are old-cycle edges. Formula (9) uses each
gap vertex once because \(K_L,K_R\) are disjoint and
spanning. Every other prime vacancy slot occurs once in
the middle, while every inner vacancy occurs in its gap
route. The endpoints remain \(o_p,e_u\), proving
\(S(D)\). The parenthesized pairs in (8)--(9) are
concatenated in the displayed descending order; when
\(m=2\), there is just the pair \((I_u,H_u)\). This
completes the induction.

Apply \(S\) to every closed interval containing vacancy
blocks in the ordinary free path of Note 196. Vacancy
edges cannot straddle an occupied escape target by
Note 203, so all intervals required above stay in their
free groups. The replacements have disjoint interiors
and preserve the two endpoints of the free path. The
fixed target-and-square path of Note 196 supplies the
other \(x\)-to-\(v\) path; together they form a
Hamilton cycle using \(xy,uv\). Notes 001 and 178 give
the legal child's Hamilton cycle and restore all original
lobe lengths. \(\square\)

**All partition types occur.** For any noncrossing
partition of \(\{1,\ldots,q\}\) without singleton parts,
\(q\ge2\), take the old cycle and every non-vacancy
matching edge from Note 274(6), with \(r=q,\ell=1\).
Replace its rainbow edges by (3) for every part of the
partition. These new edges pair opposite old-cycle
colours. They draw without crossings on the side opposite
the designated face. Each standard chain chord sits
between two consecutive vacancy pairs, so it is disjoint
from or nested in every new chord. The site, face-block,
square-closing and escape chords retain Note 274's
noncrossing drawing.

The connected interlacement chain displayed in Note 274
is unchanged. Each new vacancy chord joins different
blocks and interlaces the face chord \(a_jb_j\) of its
earlier endpoint block, so it attaches to that chain.
The same two-edge-cut argument and the cubic lemma of
Note 182 give three-vertex-connectivity. Thus every
partition type has a Barnette parent of order \(6q+12\)
and a legal Hamiltonian site-expanded child. Already at
\(q=4\), the nested partition
\(\{\{1,4\},\{2,3\}\}\), with edges
\(H_1I_4,I_1H_4,H_2I_3,I_2H_3\), lies outside the
single-cycle theorem of Note 274. Its straight route
through the four long blocks, written without the
ordinary end links, is
\[
\begin{split}
o_1,a_1,b_1,a_2,b_2,a_3,o_3,e_2,I_2,H_3,I_3,H_2,o_2,\\
e_1,I_1,H_1,I_4,H_4,o_4,e_3,b_3,a_4,b_4,e_4.
\end{split}
\]

The theorem concerns only the selected tight, gapless,
all-square opening and vacancy slots paired solely with
vacancy slots in distinct target-free internal blocks.
Vacancy-to-ordinary edges, repeated vacancies in a block,
defective target order, positive gaps and nonsquare residual
cycles remain outside its scope. It does not settle
Barnette's conjecture.
[Note 276](276-distinct-target-free-vacancies-have-only-chain-defects.md)
constrains vacancy-to-ordinary edges and settles their
connected single-chain-defect profile.
