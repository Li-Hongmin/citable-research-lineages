> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A right-site vacancy before the final target is Hamiltonian

[Note 236](236-an-isolated-second-vacancy-composes-with-one-target-defect.md)
composes a delayed first target with a vacancy in a later *face*
block. [Note 246](246-a-vacancy-immediately-after-a-delayed-first-target-is-hamiltonian.md)
handles a vacancy in the first target's own block. A vacancy in the
right site block can first be moved next to the final target by the
right boundary inverse of [Note 186](186-boundary-square-traps-either-peel-or-force-a-hamiltonian-child.md).
Its remaining free group then has a forced two-chord detour.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, and \(s=2\), so
\(f=4r+6\). Assume \(d_L=1\), \(b=d_R=0\), and that
\(R_\ell\) is the third interior slot of \(B_h\) for some
\(0\le h\le r+1\). The vacancy before \(R_\ell\) is the second
interior slot of that block. Assume the *other* vacancy lies at
any eligible even interior position of the right site block
\(B_{r+1}=[u,v]_C\). No other vacancy occurs.

**Right-site vacancy theorem.** Every parent satisfying these
assumptions has a Hamilton cycle containing both site edges
\(xy,uv\), and its legal site-expanded child is Hamiltonian.
In fact \(1\le h\le r-1\). Repeated simple right boundary
inverses reduce it to a parent with the same delayed first target
and a right site block having exactly four interior slots
\[
 B_{r+1}: u,o_{r+1},H,I,L_1,v,                 \tag{1}
\]
where \(H\) is the vacant even slot and \(I\) the following
free odd slot. In this reduced parent let \(R_1\) lie in \(B_m\), so
\(h\le m\le r-1\). For some \(t\in\{m+1,\ldots,r\}\), the
complete reduced free-slot matching is
\[
M_{\rm free}=\{o_0w,e_{t-1}I,o_tH\}
 \cup\{e_j o_{j+1}:0\le j\le r,\ j\ne t-1\}.       \tag{2}
\]
Here \(o_h,w\) precede \(R_\ell\), while \(e_j\) and
\(o_{j+1}\) denote the ordinary final and initial free slots
of consecutive blocks. The original lobes may have arbitrary
positive lengths.

**Reduction to the terminal vacancy.** If an occupied eligible
position of \(B_{r+1}\) follows the vacancy, then the final
targets have the consecutive order \(R_1,L_1,v\): the transition
\(L_2R_1\) is tight and \(L_1\) is the last interior slot.
The predecessor \(A\) of \(R_1\) lies inside \(B_{r+1}\), beyond
its first free slot and the vacancy, so \(A\ne u\). Note 186's
right boundary inverse is therefore simple. It removes
\(R_1,L_1\) and their square, preserves the two site edges,
both vacancies, the first target in \(B_h\), the empty gaps,
and all remaining tight transitions. The old \(L_2\) becomes
the new final target at the last interior slot of \(B_{r+1}\).
Repeat until no occupied eligible position follows the vacancy.
Each inverse reduces the lobe count by one and cannot remove
\(R_\ell\), which precedes the vacancy and all peeled targets.
The reduced opening still has \(s=2,d_L=1,b=d_R=0\).

**The two vacancies cannot share the right site block.** Suppose
\(h=r+1\) in the reduced opening. All earlier blocks are short:
there is no target before \(R_\ell\), and both eligible vacancies
are in \(B_{r+1}\). Its first two free slots \(o_{r+1},w\)
precede \(R_\ell\); its only other free slots are the even--odd
adjacent pair \(H,I\) after \(R_\ell\). Every other eligible
position is an occupied nonfinal \(L\)-target, and the tight
transitions occupy the following odd slots. Note 203 excludes
every cross-block free chord across \(R_\ell\). Matching parity
permits zero or two same-block chords across it.

Two chords would use both \(o_{r+1},w\). Every matching edge
incident with the complete main prefix through \(B_r\) would
then stay in that prefix: it contains no escape target, its site
and face chords are internal, and its free slots cannot pass
\(R_\ell\) or reach the already used \(o_{r+1},w\). The prefix
has just two departing old-cycle edges, contrary to
three-connectivity. With zero crossing chords, \(H,I\) have
no available mate except each other, but \(HI\in E(C)\).
Both possibilities fail. Thus \(h\le r\).

**The reduced terminal block is short.** Write its interior length as
\(2k+2\). The last eligible position is \(2k\), occupied by
\(H\), and \(L_1\) is at position \(2k+2\). If \(k\ge2\),
the preceding eligible position \(2k-2\) is occupied by a
nonfinal \(L\)-target, since the only other vacancy precedes
\(R_\ell\). Target order and \(b=0\) put \(R_1\) at position
\(2k-1\). The free odd position \(I=2k+1\) cannot match an
even slot in another block before \(R_1\): such a cross-block
chord straddles the escape target, contrary to Note 203. No
earlier even slot inside \(B_{r+1}\) is free; all are occupied
targets. The only possible even mate for \(I\) before \(L_1\)
is \(H\), but \(HI\) is an old-cycle edge. This contradicts
perfect matching. Hence \(k=1\), proving (1), and \(R_1\)
lies in some face block \(B_m\), \(h\le m\le r\).

**Matching barriers and the last group.** At \(R_\ell\), a
cross-block free chord is forbidden by Note 203. Only one
opposite-colour same-block chord can cross its target run,
because the second vacancy is in \(B_{r+1}\). The free prefix
before \(R_\ell\) is even, so matching parity excludes that
chord. If \(h=0\), this leaves the adjacent pair \(o_0,w\)
unmatched. Thus \(h\ge1\), and Note 211's prefix argument
forces \(o_0w\) and \(e_j o_{j+1}\) for \(0\le j<h\).

All later target runs are matching barriers as well. Before each
run, the number of free slots is even: the delayed prefix
contributes two extra slots, ordinary completed blocks contribute
free slots in pairs, and the terminal vacancy contributes its two
extra free slots only after \(R_1\), with no target before \(L_1\).
Note 203 forbids cross-block chords across a target; in a normal
block at most one same-block free chord can cross. Matching parity
therefore excludes all crossings. Since \(R_1\) is the last target
before \(L_1\), every face block after \(B_m\) is short, and the
last free group has the order
\[
e_m,o_{m+1},e_{m+1},\ldots,e_r,o_{r+1},H,I.    \tag{3}
\]
Its free matching edges all join different blocks: \(o_{r+1}H\)
and \(HI\) are old-cycle edges, and \(H\) and the other even
slots have the same colour. Thus Note 193 puts these chords on
one side of \(C\), where they are noncrossing.

The even slot \(H\) must match an earlier odd slot \(o_t\).
It cannot match adjacent \(o_{r+1}\), so \(m+1\le t\le r\).
The odd slot \(I\) must match some \(e_j\), and noncrossing
with \(o_tH\) requires \(m\le j<t\). If \(j<t-1\), the
complete short blocks \(B_{j+1},\ldots,B_{t-1}\) must match
internally. One such block has an adjacent free pair, which
cannot be a matching edge; two or more form a proper
matching-closed old-cycle interval and a forbidden two-edge cut.
Hence \(j=t-1\). Note 196's skipping rule forces all remaining
slots in (3), and all earlier ordinary groups, to take their
standard links. This proves (2) and \(m\le r-1\), hence
\(h\le r-1\).

For the marked Hamilton cycle, take Note 196's target-and-square
\(x\)-to-\(v\) path and replace its initial edge by
\[
x,R_\ell\quad\longmapsto\quad x,o_0,w,R_\ell.
\tag{4}
\]
Take its disjoint ordinary free path and replace one link by
\[
e_{t-1},o_t\quad\longmapsto\quad e_{t-1},I,H,o_t.
\tag{5}
\]
In (4), the outer edges lie in \(C\) and \(o_0w\in M\).
In (5), the outer edges lie in \(M\) and \(IH\in C\).
All other target transitions are tight. The two resulting
paths share only \(x,v\), cover every reduced-parent vertex,
and contain \(xy,uv\) in their union.

Reverse the boundary inverses. At each step a marked reduced
parent Hamilton cycle uses \(uv\) and exactly one of the two
edges restored at \(v\). Note 185's reflected spanning one-path
routings replace that edge and cover all six reinserted vertices;
they preserve \(uv\), while \(xy\) is untouched. Thus every
inverse lifts the marked parent Hamilton cycle. Note 001 lifts
it through the legal site expansion, and Note 178 restores
arbitrary original lobe lengths. \(\square\)

**A realized 24-vertex reduced profile.** Let
\(r=2,\ell=1,h=m=1,t=2\).
The old Hamilton cycle has consecutive blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_1,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&u,o_3,H,I,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                             \tag{6}
\]
Its complementary matching consists of
\[
\{xy,a_1b_1,a_2b_2,uv,\alpha\beta,R_1\delta,L_1\gamma,
o_0w,e_0o_1,e_1I,o_2H,e_2o_3\}.                       \tag{7}
\]
The marked Hamilton cycle is the union of two paths:
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,I,H,o_2,a_2,b_2,e_2,o_3,u,v.
\end{split}                                             \tag{8}
\]
Every successive pair in (8) is an edge of the old cycle or
(7); the paths meet only at \(x,v\) and cover all 24 vertices.

For planarity, place the site, face and \(\alpha\beta\) chords
on one side of the old cycle. On the other side, the free chords
form the nests \(o_0w\supset e_0o_1\) and
\(R_1\delta\supset(e_1I\supset o_2H\supset e_2o_3,
L_1\gamma)\), with the two inner branches disjoint. Every
matching edge joins opposite old-cycle parities, so the graph
is simple, cubic, bipartite and plane, with cofacial site edges.
The vertices \(x,u\) have the same old-cycle parity, as required
for the oriented bipartite site expansion.
Its matching-chord interlacement graph is connected: the spine
\[
xy-o_0w-a_1b_1-e_1I-uv-L_1\gamma-
\alpha\beta-R_1\delta-a_1b_1
\tag{9}
\]
has \(e_0o_1\) attached to \(xy\), \(o_2H\) attached to
\(uv\) and \(a_2b_2\), and \(e_2o_3\) attached to
\(a_2b_2\). Every indicated pair of chords interlaces in
(6). Note 217's interval criterion proves three-connectivity;
its cut projection proves that the 28-vertex site expansion is
also Barnette. Formula (8) proves Hamiltonicity of both through
Note 001.

For every \(d\ge0\), reverse \(d\) simple right boundary
inverses from this 24-vertex parent. At each step insert the
six-vertex patch of Notes 185--186 into the incident edges
\(L_1v\) and \(v\alpha_1\), with target indices relabeled.
Their non-\(v\) endpoints are distinct, and both edges differ
from the retained site edge \(uv\), so the insertion is simple.
The cited incident-edge and boundary
results preserve the Barnette class, the cofacial site and the
marked Hamilton cycle. The vacancy remains in the right site
block, with exactly \(d\) occupied eligible positions after it;
the parent and legal child have \(24+6d\) and \(28+6d\)
vertices, respectively. Thus every right-site vacancy distance
in the theorem occurs in a Barnette graph.

This theorem treats every eligible vacancy of the right site
block when the first target is delayed; sharing that site block
is impossible under the stated assumptions. Other positions of
a vacancy in the delayed first-target block, transition defects
with a spare vacancy, gaps, nonsquare lobes, and arbitrary
Barnette graphs remain outside it.
