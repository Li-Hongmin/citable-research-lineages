> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Square-signature four-poles are closed under standard short buffers

[Note 313](313-square-buffers-monotonically-enlarge-six-port-hamilton-linkages.md)
shows that a square buffer lifts every spanning linkage of an
adjacent pair of degree-two terminals. At a four-terminal disk
patch already having the square's complete Hamilton signature,
planarity and bipartiteness leave no further Hamilton state for
the buffer to add. The deletion comparison of
[Note 362](362-the-six-double-outer-pair-has-the-square-hamilton-signature.md)
then makes this an exact, class-preserving operation.

Let \(T\) be a finite plane bipartite disk patch with four
distinct degree-two terminals in cyclic order
\[
                         (a,o,e,b),                       \tag{1}
\]
every other vertex having degree three. Assume \(ao,eb\) are
edges whenever a buffer is added at the corresponding terminal
pair, and assume \(T\) has the complete spanning single-path
and two-path Hamilton signature of the square in order (1).
Assume also:

1. \(T-v\) is connected for every vertex \(v\);
2. after deleting any two vertices of \(T\), each surviving
   component contains a surviving terminal from (1).

When \(ao\) is an edge, add a **left standard buffer** by
introducing a fresh square
\(A,O,E,B,A\), add \(Ba,Eo\), and move the two exterior
attachment labels \(a,o\) to \(A,O\). The old \(a,o\)
become internal. A right standard buffer is the reflected
operation when \(eb\) is an edge. Let \(T_{p,q}\)
be the patch after \(p\) left and \(q\) right buffers,
in any order, requiring \(ao\) if \(p>0\) and \(eb\)
if \(q>0\). After its first buffer either terminal pair
remains adjacent, so further buffers on that side are defined.

**Four-pole buffer theorem.** For all \(p,q\ge0\),
\(T_{p,q}\) has exactly the square's complete Hamilton
single-path and two-path signature at its four new terminals.
It has the same one-vertex and two-vertex deletion properties
as \(T\). If an induced disk copy of \(T\) occurs in a
Barnette graph, replacing it by \(T_{p,q}\), or reversing
the replacement in any Barnette host, preserves Barnette
membership and every Hamilton decision on exterior and
attachment edges. The replacement adds \(4(p+q)\) vertices.

**Signature proof.** Consider one left buffer and any spanning
path or disjoint path pair of \(T\). The old degree-two
terminals \(a,o\) have four possible endpoint statuses.
If both are endpoints, extend their two path ends by the
disjoint segments
\[
                  A,B,a\qquad\text{and}\qquad O,E,o.
                                                               \tag{2}
\]
If only \(a\) is an endpoint, extend its path by
\(A,O,E,B,a\). If only \(o\) is an endpoint, extend
its path by \(O,A,B,E,o\). If neither is an endpoint,
both have internal degree two; since \(ao\) is one of
their two patch edges, that edge is used. Replace it by
\[
                         a,B,A,O,E,o.                 \tag{3}
\]
Each operation uses every new square vertex once, leaves
all previous vertices and exterior decisions unchanged, and
preserves the number of paths and their terminal pairing.
The reflected argument handles a right buffer, so induction
lifts all six square states to \(T_{p,q}\).

Buffer insertion preserves the terminal colour classes and
their cyclic disk order: the new \(A,O\) have respectively
the colours of the old \(a,o\). The degree sum
\(3|V(T)|-4\) makes \(|V(T)|\) even. The four existing
spanning single-path states then force \(a,e\) to have
one colour and \(o,b\) the other. Thus a spanning single path
cannot join the two equal-colour terminal pairs, while the
third two-path pairing crosses the disk order. These are
all states outside the square signature. Hence the lifted
signature is exact.

**Connectivity and Barnette preservation.** It suffices to
check one left addition \(T'\). Deleting one old patch vertex
leaves \(T\) connected and at least one of the two square
attachments \(Ba,Eo\) present; deleting one square vertex
leaves the square connected and again at least one of these
attachments present. Thus \(T'-v\) is connected.

If two deleted vertices lie in \(T\), every component of
the remaining \(T\) touches a surviving old terminal.
An \(e\)- or \(b\)-terminal is still a new terminal;
an \(a\)- or \(o\)-terminal connects through the intact
square to \(A\) or \(O\). The intact square itself contains
both new terminals. If one deleted vertex lies in each
part, \(T\) minus its vertex is connected and contains a
surviving \(e\) or \(b\), while the square minus its vertex
is connected and contains a surviving \(A\) or \(O\).
If both deleted vertices lie in the square, the intact
\(T\) contains \(e,b\); every square component lacking
\(A,O\) contains \(B\) or \(E\) and attaches to the intact
\(T\). Hence every surviving component of \(T'\) touches
a surviving new terminal. Reflection and induction prove
the two deletion properties for \(T_{p,q}\).

The square can be drawn along the disk boundary between
the adjacent attachments at \(a,o\), so the terminal
order, planarity and distinct attachment edges persist.
The colouring in the signature proof makes every new edge
bipartite; degrees are three internally and two at the
four terminals. In any three-connected cubic host the
exterior of a four-attachment disk patch is connected:
two exterior components would each require at least three
of the four attachments. The four-attachment deletion
comparison of Note 362, applied to \(T\) and \(T_{p,q}\),
therefore proves three-connectivity in both replacement
directions. The same signature proves the two-way
Hamilton-decision assertion. \(\square\)

**Six-double consequence.** The full 48-vertex cores of
Notes 346 (at \(N=6\)), 362, 364 and 365 all satisfy
the hypotheses above; the \(k_1i_4\) core is the
reflection of Note 365. Adding arbitrary standard short
flanks gives exact square-equivalent
\(48+4(p+q)\)-vertex four-poles. For the explicitly
realized cores of Notes 346, 364 and 365 and their
reflections, buffering their 60-vertex parents gives
Barnette parents of order \(60+4(p+q)\). In their two-page
old-cycle drawings each left buffer is a short block before
\(D_1\), with its face-closing chord on the common-face
page and its free link to \(o_1\) on the opposite page;
the right construction is reflected. Both site edges remain
cofacial. The marked Hamilton cycle lifts with the same site
edges by (2)--(3), and Note 001 gives the legal child's
Hamilton cycle.

The theorem concerns standard buffers at the two outer
terminal pairs. Nonstandard short-flank returns and corridors
between double blocks are not covered. It does not settle
other opening types or general Barnette graphs. This is a
project-internal analytic proof without an external
priority claim or independent review.
