> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Saturated square-trap main segments create two-edge cuts

The [facial square-trap bouquet theorem](177-facial-square-traps-form-bouquet-lobes-with-disjoint-merger-squares.md)
and the [even-ladder compression theorem](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
reduce every all-square-trap facial opening to one residual square
per escape-network lobe. In this normal form, the opposite-side
escape endpoints have a rigid order. It gives a direct merger
criterion, but the smallest possible main segment creates a
forbidden two-edge cut.

Let \(G\to G^+\), \(C\), and the opened child 2-factor \(F_P\)
be as in Notes 176--178. Assume \(G\) is simple, cubic, bipartite,
plane and 3-connected, the site expansion is legal, and every
trapped segment of the chosen facial opening is a square. Let
\(\ell\ge1\) be the number of escape-network lobes. Compress each
lobe ladder in both parent and child as in Note 178. In the reduced
graphs denote the residual squares, in \(C\)-order, by
\[
S_i=\alpha_i a_i b_i\beta_i\alpha_i,
\qquad 1\le i\le\ell,
\tag{1}
\]
and write \(a_i t_i^L,b_i t_i^R\) for their two escape
matching edges to the old-vertex main segment \(S_0\).
Orient \(S_0\) from the facial port \(x\) to the port \(v\).

**Escape-order lemma.** Its \(2\ell\) escape endpoints occur on
\(S_0\) in the order
\[
t_\ell^R,t_\ell^L,
t_{\ell-1}^R,t_{\ell-1}^L,
\ldots,t_1^R,t_1^L,
\tag{2}
\]
possibly with other \(S_0\)-vertices between them. Relative to
the path order from \(x\), every \(t_i^R\) has odd index and
every \(t_i^L\) has even index.

**Proof.** The source endpoints of the escape chords occur in
the order \(a_1,b_1,\ldots,a_\ell,b_\ell\) on the complementary
\(C\)-arc. Two disjoint chords from this arc to \(S_0\) cross
if their target endpoints have the same relative order as their
sources. All escape chords lie on the same side of \(C\) and
are noncrossing; hence the target order is exactly reversed,
giving (2). Along \(C\) from \(v\) to \(x\), the vertices
\(a_i\) have the colour of \(v\), while \(b_i\) have the
colour of \(x\). Matching edges reverse colour, so \(t_i^L\)
has the colour of \(x\) and \(t_i^R\) the opposite colour.
Indices along \(S_0\) from \(x\) therefore have the stated
parities. \(\square\)

**Even-cut bridge lemma.** Let \(e=w_tw_{t+1}\) be a
\(C\)-edge on \(S_0\) between \(y\) and \(u\), where
\(w_0=x\) and \(t\) is odd. If no escape pair
\((t_i^R,t_i^L)\) has one endpoint on each side of \(e\),
then at least two matching edges internal to \(S_0\), other
than the site edges \(p,q\), cross the partition at \(e\).

To prove this, take the \(S_0\)-suffix from \(w_{t+1}\) to
\(v\), and add exactly the residual squares whose two
escape targets belong to that suffix. By (2), these are a
prefix \(S_1,\ldots,S_j\), allowing \(j=0,\ell\). Call the
union \(W\). The suffix has even order because \(t+1\)
and \(|V(S_0)|\) are even, and each square has four vertices;
thus \(|W|\) is even. Exactly two \(C\)-edges cross
\(\delta(W)\): \(e\) and the cut edge between \(S_j\)
and \(S_{j+1}\), interpreted as the first or last cut edge
when \(j=0\) or \(\ell\). No escape edge crosses by the
choice of \(e\); \(p\) lies inside \(W\) and \(q\) outside.
The remaining crossing edges are precisely the stated
internal \(S_0\) matching chords. A cubic graph has
\(|\delta(W)|\equiv|W|\pmod2\); 3-edge-connectivity
therefore makes this even cut at least four. \(\square\)

**Paired-escape merger criterion.** If \(t_i^R,t_i^L\) are
adjacent along \(S_0\) for every \(i\), the expanded child
\(G^+\) has a Hamilton cycle. More precisely, after lobe
compression the \(\ell\) squares
\[
Q_i=a_i,b_i,t_i^R,t_i^L,a_i
\tag{3}
\]
are facial, alternating for the matching complementary to
\(F_P\), and pairwise vertex-disjoint. Flipping them all
merges every residual square with the main component.

**Proof.** The edges \(a_i b_i\) and \(t_i^R t_i^L\) belong
to \(F_P\); the two escape edges belong to its complementary
matching. Thus (3) is alternating, with its two factor edges
in distinct components. Its two \(C\)-edges each join
consecutive boundary vertices, and its other two edges are
noncrossing chords on the opposite side of \(C\). As every
vertex lies on \(C\), the disk bounded by (3) has no vertices
or edges inside: it is a face. Distinct \(Q_i\) use distinct
residual squares and disjoint escape targets, so they are
vertex-disjoint. Their flips commute and each joins one
residual component to the main component. The resulting
2-factor is one Hamilton cycle in the reduced child. Note 178
transfers it back to \(G^+\). \(\square\)

**Saturation-cut theorem.** In a 3-edge-connected parent,
\[
|V(S_0)|\ge 2\ell+6.
\tag{4}
\]
The weaker counting equality \(|V(S_0)|=2\ell+4\) either is
impossible already from the site order, or exposes a two-edge
cut in the parent. Thus it cannot occur in a Barnette graph.

**Proof.** The four site ports \(x,y,u,v\) lie in \(S_0\)
and are matched by the two site edges \(q=xy,p=uv\). The
\(2\ell\) escape endpoints are distinct and cannot be site
ports, proving the counting bound \(|V(S_0)|\ge2\ell+4\).
Compression does not change \(S_0\), so assume equality and write
\[
S_0:\quad w_0=x,w_1,\ldots,w_{2\ell+3}=v.
\tag{5}
\]
The face boundary order is \(x,y,u,v\). Bipartiteness puts
\(y\) at an odd index and \(u\) at an even index in (5).
Because the site edges are in the matching rather than \(C\),
simplicity gives \(y\ne w_1\) and \(u\ne w_{2\ell+2}\).
Every other interior vertex of (5) is an escape endpoint.
By (2), these endpoints must occur as an odd-index \(R\)
followed by an even-index \(L\), repeatedly.

Suppose at least one vertex lay strictly between \(y\) and
\(u\) on \(S_0\). The first such vertex has even index,
since \(y\) has odd index. Immediately before \(y\), the
escape targets form complete \(R,L\) pairs, so the first
target after \(y\) must be an \(R\), which has odd index.
This is impossible. Thus \(u\) immediately follows \(y\).
The targets occupy all the adjacent pairs
\[
(w_1,w_2),(w_3,w_4),\ldots,
\widehat{(y,u)},\ldots,
(w_{2\ell+1},w_{2\ell+2}),
\tag{6}
\]
except the site-port pair. By site-edge nonadjacency,
\((y,u)\) is neither the first nor the last pair in (6).
Let \(r\) be the number of escape pairs preceding \((y,u)\);
then \(1\le r\le\ell-1\). In particular, equality is
impossible when \(\ell=1\).

For \(\ell\ge2\), put \(j=\ell-r\). By the reverse order (2),
the escape pairs after \((y,u)\) belong precisely to the
first \(j\) residual squares \(S_1,\ldots,S_j\). Let \(W\)
consist of these squares together with the \(S_0\)-arc from
\(u\) to \(v\), including its endpoints. Every matching edge
incident with \(W\) stays inside \(W\): the edges \(m_i\)
close the included squares, their escape edges end on the
included target pairs, and the site edge \(p=uv\) is inside.
There are no other \(S_0\) matching edges under equality.
Exactly two \(C\)-edges leave \(W\): the edge between
\(S_j\) and \(S_{j+1}\), and the edge \(yu\). Thus \(W\)
is a nonempty proper vertex set with a two-edge cut.
The same cut exists before lobe compression by replacing
each included square with its original whole ladder block.
This contradicts 3-edge-connectivity. Since \(|V(S_0)|\)
is even (the bipartite Hamilton cycle has even order, and all
trapped segments have four vertices), (4) follows. \(\square\)

The paired-escape criterion remains a sufficient Hamilton
mechanism when its adjacency hypothesis is actually realized.
The saturation-cut theorem shows that the smallest counting
case is not a legal Barnette instance; it supplies no
Hamiltonicity claim for longer main segments or nonsquare
residual components.
