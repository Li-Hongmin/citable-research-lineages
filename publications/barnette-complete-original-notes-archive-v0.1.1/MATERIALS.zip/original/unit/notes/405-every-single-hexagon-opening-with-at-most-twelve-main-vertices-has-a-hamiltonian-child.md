> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every single-hexagon opening with at most twelve main vertices has a Hamiltonian child

[Notes 403](403-a-single-chorded-hexagon-trap-needs-twelve-main-vertices.md)
and [404](404-a-single-chord-free-hexagon-trap-has-a-short-main-hamilton-bound.md)
settle a single trapped hexagon through ten main vertices, and
the chorded case at twelve. At twelve main vertices the chord-free
case has exactly one long-gap matching, up to the fixed cycle labels.
It admits a Hamilton cycle through a site edge.

Keep the notation of Note 404. Thus \(G\) is a simple
three-connected cubic bipartite plane graph with Hamilton cycle
\[
 C=(w_0,w_1,\ldots,w_{s-1},\alpha,a,b,c,d,\beta,w_0),
 \qquad M=E(G)\setminus E(C),
\]
and \(q=w_0w_j,p=w_kw_{s-1},\alpha\beta\in M\) lie on
one face in that cyclic order. Its selected alternating facial
arc is \(w_{s-1},\alpha,\beta,w_0\). Assume \(ad\notin M\).
Write \(t_z\) for the matching neighbour of
\(z\in\{a,b,c,d\}\) on the main segment. Note 404 gives
\[
             t_d<t_c<t_b<t_a,                         \tag{1}
\]
where these indices have parities odd, even, odd, even.

**Twelve-main theorem.** If \(s=12\) and \(k>j+1\), then
\((j,k)=(3,8)\) and the entire complementary matching is
\[
\begin{split}
M=\{&w_0w_3,w_8w_{11},\alpha\beta,w_4w_7,\\
    &w_1d,w_2w_5,w_6c,w_9b,w_{10}a\}.
\end{split}                                                   \tag{2}
\]
This graph has a Hamilton cycle containing \(q\), so every
legal \(C_4\)-expansion at \(p,q\) is Hamiltonian. Together
with Notes 403--404, **every selected literal facial opening
with exactly one trapped hexagon and \(s\le12\) has a
Hamiltonian legal child**, whether or not that hexagon has
its internal matching chord. In particular, if both facial
arcs between the site edges have length at least three,
then \(s\ge12\); equality is possible only in (2), up to
reversing the labelled old cycle.

**A gap rule.** All four escape chords lie opposite the common
face, by [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md).
An additional matching chord with both endpoints in \(S_0\)
and drawn opposite the face cannot straddle any \(t_z\): if
its ends are \(w_i,w_h\), with \(i<t_z<h\), it interlaces
\(w_{t_z}z\). Hence the endpoints of each such chord lie in
one of the five open gaps cut out by (1). When there is no
additional face-side chord, each gap contains an even number
of unused main vertices. If the eight free main positions are
ranked \(1,\ldots,8\), the four escapes must consequently
have ranks odd, even, odd, even.

The site parity and nonadjacency conditions leave six pairs
\[
(j,k)=(3,4),(3,6),(3,8),(5,6),(5,8),(7,8).
\tag{3}
\]
The consecutive pairs give an immediate Hamilton child by
the one-edge flip of
[Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md).
Reversing the old Hamilton cycle exchanges \((3,6)\) and
\((5,8)\), so only \((3,6)\) and \((3,8)\) remain to inspect.

For \((j,k)=(3,6)\), the eight free positions, in order, are
\(1,2,4,5,7,8,9,10\). A face-side matching chord other
than the site and \(\alpha\beta\) can only be \(w_7w_{10}\):
every other nonadjacent opposite-colour pair interlaces a
site chord. If this chord is absent, the gap rule and (1)
allow only
\[
\begin{array}{c|l}
(t_d,t_c,t_b,t_a)&\text{obstruction among unused positions}\\
(1,2,7,8),(1,2,7,10)&4,5\text{ are old-cycle neighbours in one gap}\\
(1,2,9,10)&4\!-\!7,5\!-\!8\text{ are forced and interlace}\\
(1,8,9,10)&2\!-\!5,4\!-\!7\text{ are forced and interlace}\\
(7,8,9,10)&1\!-\!4,2\!-\!5\text{ are forced and interlace}.
\end{array}                                                   \tag{4}
\]
Here a displayed pair such as \(4\!-\!7\) denotes a
matching chord between those main indices; consecutive
indices cannot be matched because their edge already belongs
to \(C\). If \(w_7w_{10}\) is present, the only possible
escape tuples are \((1,2,5,8)\) and \((1,4,5,8)\). Their
remaining pairs, respectively \(4\!-\!9\) and \(2\!-\!9\),
straddle escape endpoints. This excludes \((3,6)\), and by
reversal also \((5,8)\).

For \((j,k)=(3,8)\), the eight free positions are
\(1,2,4,5,6,7,9,10\). The only possible additional
face-side chord is \(w_4w_7\). Without it, the gap rule
allows only escape tuple \((1,2,9,10)\), leaving
\(4,5,6,7\); these four have no pairing that avoids both
old-cycle edges and a chord crossing. With \(w_4w_7\), the
remaining positions are \(1,2,5,6,9,10\), and (1) gives
precisely
\[
\begin{array}{c|c|l}
(t_d,t_c,t_b,t_a)&\text{remaining pair}&\text{obstruction}\\
(1,2,5,6)&9\!-\!10&\text{old-cycle edge}\\
(1,2,5,10)&6\!-\!9&\text{straddles }t_b=5\\
(1,2,9,10)&5\!-\!6&\text{old-cycle edge}\\
(1,6,9,10)&2\!-\!5&\text{none}\\
(5,6,9,10)&1\!-\!2&\text{old-cycle edge}.
\end{array}                                                   \tag{5}
\]
The gap rule proves both the exhaustion and the stated
obstructions. The surviving row is exactly (2).

**Realization and Hamilton witness.** Put the chords
\(w_0w_3,w_4w_7,w_8w_{11},\alpha\beta\) on one side
of \(C\). On the other side, \(w_1d\) contains the
disjoint chords \(w_2w_5\) and \(w_6c\), while \(w_6c\)
contains the nested chords \(w_9b,w_{10}a\). Thus (2) is a
plane simple cubic bipartite graph. Its matching-chord
interlacement graph is connected: the chain
\[
 q,\ w_2w_5,\ w_4w_7,\ w_6c,\ \alpha\beta,\ w_9b,\ p
\]
has consecutive interlacements, and \(w_1d\) interlaces
\(q\) while \(w_{10}a\) interlaces \(p\). Any two-edge
cut in a Hamiltonian cubic graph would bound a proper
old-cycle interval closed under the matching, disconnecting
this interlacement graph. Hence there is no two-edge cut;
there is no bridge because \(C\) is Hamiltonian. In a cubic
graph, three edge-disjoint paths are internally
vertex-disjoint, so three-edge-connectivity gives
three-vertex-connectivity.

The common face has arcs
\(w_{11},\alpha,\beta,w_0\) and
\(w_3,w_4,w_7,w_8\), both of length three. Finally,
\[
\begin{split}
 C'=(w_0,w_3,w_4,w_5,w_2,w_1,d,c,w_6,w_7,w_8,\\
 \qquad w_9,b,a,w_{10},w_{11},\alpha,\beta,w_0)
\end{split}                                                   \tag{6}
\]
is a Hamilton cycle: every consecutive pair in (6) is an
old-cycle edge or belongs to (2). It contains \(q=w_0w_3\)
and avoids \(p=w_8w_{11}\). Replacing \(q\) in \(C'\)
by the spanning path through the four new square vertices
proves the child claim, equivalently by the six-witness
criterion of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).
\(\square\)

The formal legal \(C_4\)-expansion and its place in the
Holton--Manvel--McKay generation theorem are given in
Gorsky--Steiner--Wiederrecht, *Matching Theory and Barnette's
Conjecture* (2023), Section 5, Theorem 5.1
([arXiv:2202.11641](https://arxiv.org/html/2202.11641v3)).
Schnieders, *Barnette Graphs with Faces up to Size 8 are
Hamiltonian* (2025), Theorem 5.2
([arXiv:2508.03531](https://arxiv.org/html/2508.03531v1))
proves a different face-size-bounded result, using graph
substitutions and computational lifting. Neither source is
used to infer the marked witness (6). These sources were
checked on 2026-09-30. The result here is a project-internal
theorem about one specified facial opening. It does not cover
larger main segments, multiple trapped
cycles, or nonfacial openings, and it does not resolve
Barnette's conjecture. No external priority claim or
independent review is made.
