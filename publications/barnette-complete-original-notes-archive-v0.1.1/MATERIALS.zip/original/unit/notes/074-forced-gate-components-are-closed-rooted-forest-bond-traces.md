> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Forced-gate components are closed rooted-forest bond traces

[Note 071](071-at-most-one-gate-always-lifts-and-component-saturation-holds-through-twenty.md)
reduces target-component saturation to components in which both gate edges
are forced, and [Note 073](073-target-component-saturation-holds-through-reduced-order-twenty-two.md)
proves finite success through reduced order \(22\). This note gives an exact
transition system for the arbitrary-order forced-component problem.

## 1. Exact question

Let \(F'\) be a simple plane cubic bipartite brace, let
\(T'=F'^*\), and fix a legal two-gate \(C_4\)-expansion at
\(z\in V(T')\). Write \(x_2,x_4\) for the gate neighbours, \(g,h\) for
their primal gate edges, and \(a=e^*\) for an unchanged root edge. Let

\[
\mathcal T_e=
\{M:e\in M,\ F'-M\text{ is two cycles separating the ends of }e\}.
\]

The target-state graph joins \(M,N\in\mathcal T_e\) when
\(M\triangle N\) is one alternating cycle. The question is

\[
\forall(F',e,z,x_2,x_4),\ \forall\Gamma,
\quad
\left[
\begin{array}{l}
\Gamma\text{ is a target-state connected component},\\
g,h\in M\text{ for every }M\in\Gamma
\end{array}
\right]
\Longrightarrow
\Gamma\text{ contains a Note 065(5)-liftable target}.
\tag{FC}
\]

No arbitrary-order proof or real plane-brace counterexample to (FC) is
obtained here. The result is an exact reduced-forest transition
reformulation and two sharp route closures.

## 2. A target-state edge is exactly a bond toggle

For \(M\in\mathcal T_e\), let \(c_M\) be its dual facewise-NAE colouring,
normalized by \(c_M(z)=0\), and let \(H_M\) be its monochromatic graph.
Put

\[
R_M=H_M-a.
\]

Then \(R_M\) is a three-component forest and the ends of \(a\) lie in the
same component.

**Bond-toggle lemma.** If \(M,N\in\mathcal T_e\) are adjacent in the
target-state graph, there is a unique shore \(S\subset V(T')\), chosen by
\(z\notin S\), such that

\[
c_N=c_M\oplus\mathbf1_S,
\qquad
E(R_N)=E(R_M)\triangle\delta(S).
\tag{1}
\]

Moreover, if \(g,h\in M\cap N\), then

\[
z,x_2,x_4\notin S.
\tag{2}
\]

**Proof.** For two vertex colourings, the monochromatic status of an edge
changes exactly when one endpoint, but not both, changes colour. Hence

\[
E(H_M)\triangle E(H_N)=\delta(D),
\quad
D=\{v:c_M(v)\ne c_N(v)\}.
\]

The primal edges \(M\triangle N\) form one simple alternating cycle
\(A\). In a plane dual, \(A^*\) is a bond, so its two shores are determined
up to complement. Normalization at \(z\) selects the shore \(S\) not
containing \(z\). Since \(e,g,h\) occur in both matchings, their dual edges
\(a,zx_2,zx_4\) do not belong to the bond. Thus both ends of each such edge
lie on the same shore, proving (1)--(2). \(\square\)

Conversely, if \(z\notin S\), \(\delta(S)\) is a bond (so its primal dual
is one cycle), and \(c_M\oplus\mathbf1_S\) is again a target, then it gives
exactly one target-state edge. Thus the connected component of \(M\) is its
orbit under target-preserving bond toggles. In a forced-gate component every
admissible toggle satisfies (2).

## 3. The exact boundary acceptance state

Let

\[
P_M=R_M-z,
\]

and let \(\Pi_M=\operatorname{comp}(P_M)\) be its full component set. Label
each block met by a cyclic neighbour of \(z\) or by a root endpoint. Define

\[
\Sigma(M)=
(w_M,\Pi_M,\mu_M,\nu_M),
\tag{3}
\]

where \(w_M\) is the normalized boundary colour word and
\(\mu_M,\nu_M\in\Pi_M\) are the two root-marked blocks. The attachment map
from every boundary vertex to its block in \(\Pi_M\) is part of the state.
Blocks meeting no boundary or root terminal are retained as isolated blocks
in the quotient below.

For a locally valid Note 065 row \(s=(\lambda,\rho;d)\), form the multigraph
\(K_{\Sigma,s}\) by taking every block of \(\Pi_M\) as a vertex and
attaching \(x_1,x_3,v\) to those blocks
exactly as in the component-quotient construction. Then

\[
\operatorname{Acc}(\Sigma)
\Longleftrightarrow
\exists s:\
K_{\Sigma,s}\text{ is a forest and joins }\mu_M,\nu_M.
\tag{4}
\]

Equation (4) is equivalent to Note 065(5): contracting the tree components
of \(P_M\) preserves cycles and root connectivity. Because \(K\) retains
all blocks of \(\Pi_M\), including terminal-free isolated blocks,
\(|V(K)|-|E(K)|=3\), so acyclicity already forces the required three
components.

For a double-gate target, row \(001\) always has the gate four-cycle. The
other rows are admitted only by the relevant arc alternations, and their
failure is exactly a component collision or a failure to reconnect the two
root blocks. Define

\[
\operatorname{Bad}(\Sigma)=\neg\operatorname{Acc}(\Sigma).
\tag{5}
\]

This predicate contains the complete local information; lockedness or arc
alternation alone does not.

## 4. Why the transition needs a terminal pairing

For the bond toggle \(S\) in (1), remove the old toggled forest edges and
delete \(z\):

\[
Q_{M,S}=
\bigl(R_M-(E(R_M)\cap\delta(S))\bigr)-z.
\tag{6}
\]

Contract the components of \(Q_{M,S}\), retain all boundary and root labels,
and add the new edges

\[
(\delta(S)\setminus E(R_M))-z.
\tag{7}
\]

Call the resulting labelled incidence multigraph \(J_{M,S}\). Its connected
components give exactly \(\Pi_N,\mu_N,\nu_N\). Therefore

\[
(\Sigma(M),J_{M,S})\longmapsto\Sigma(N)
\tag{8}
\]

is an exact transition rule.

The scalar data from Note 060 have a smaller role. The equality \(p=q\),
together with separated root pairings, certifies that the flipped matching
is another target. It does not determine which boundary terminals become
identified in \(P_N\), hence it does not determine (4). The full labelled
incidence \(J_{M,S}\), or an equivalent \(\alpha/\beta\) terminal pairing,
is the weakest composable transition datum identified here.

## 5. Strict equivalent reduction

For a target colouring \(c\), let \(\mathcal O(c)\) be its orbit under all
bond toggles satisfying (1) and retaining the target property. By the
bond-toggle lemma, \(\mathcal O(c)\) is exactly its target-state connected
component. Consequently (FC) is equivalent to

\[
\boxed{
\begin{aligned}
\forall c\text{ target},\quad
&\left[\forall d\in\mathcal O(c),\
       d(x_2)=d(x_4)=d(z)\right]\\
&\Longrightarrow
\exists d\in\mathcal O(c):
\operatorname{Acc}(\Sigma(d)).
\end{aligned}}
\tag{9}
\]

Equivalently, no legal plane-brace interface has a bond-toggle orbit that is
simultaneously

1. closed under every target-preserving single-cycle toggle;
2. forced to gate bits \(11\); and
3. contained entirely in the explicit bad set (5).

This removes the expanded triangulation and all eight-row recomputation from
the global selection problem. The only remaining object is a closed trace of
rooted three-forest boundary states under the labelled transitions (8).

## 6. A real route closure: forced component does not imply arc11

The implication

\[
g,h\text{ forced on a target-state component}
\Longrightarrow
\text{every target in it has two alternating arcs}
\tag{10}
\]

is false in an actual order-18 plane brace. The first increasing-order
witness frozen by `find_forced_component_non_arc11.py` is

    graph6 Q??????wE_P_W_IO@g?h?Cg?B_?

with dual data

\[
z=1,\quad
N(z)=(2,8,9,6,3,0),\quad
\text{gates }8,6,\quad
a=57.
\]

The primal gate edges are \(5\,11\) and \(3\,15\), and the primal root is
\(7\,13\). The complete target family has four members. Two of them form a
two-vertex target-state component; both use both gates and their only
target-state neighbour is each other. One has two alternating arcs and the
other does not. Both nevertheless lift in normalized row \(101\).

Thus a proof of (9) cannot first promote componentwise gate forcing to the
complete-family arc11 phenomenon from the through-20 census. One-sided local
absorption must remain available.

## 7. A weakened-axiom countermodel

The actual Note 068 bad target has normalized boundary word

\[
01010101
\]

and, in its displayed rotation order, the \(P_M\)-component identifiers

\[
(0,1,4,1,5,1,2,3),
\qquad
(\mu_M,\nu_M)=(0,2).
\tag{11}
\]

The quotient verifier gives the following complete row profile:

\[
\begin{array}{c|cc}
s&K_s\text{ forest}&\text{root marks joined}\\ \hline
001&\text{no}&\text{yes}\\
011&\text{yes}&\text{no}\\
101&\text{no}&\text{yes}\\
110&\text{no}&\text{no}\\
111&\text{no}&\text{no}
\end{array}
\tag{12}
\]

Hence (11) is a genuine brace-realizable bad vertex state. Now take two
formal copies of (11) and join them by a remote gate-avoiding transition
labelled

\[
p=q=1,
\qquad
\text{root separation preserved},
\qquad
\text{boundary partition unchanged}.
\tag{13}
\]

This two-state trace is connected, forces both gates, satisfies the scalar
single-cycle target-transition test, and contains no accepting state. It is
an abstract countermodel to the weakened axiom system consisting only of:

- individually admissible rooted component quotients;
- forced gate bits;
- target-state connectedness; and
- scalar \(p=q\) plus root separation on each transition.

The joint trace (11)--(13) is **not claimed to be realizable by one plane
brace** and is therefore not a counterexample to (FC). Its force is exactly
to show that an arbitrary-order proof must use the shared primal-dual
incidence encoded by \(J_{M,S}\); unlabelled exchange connectivity and scalar
cycle counts cannot rule out a closed bad trace.

## 8. Stopping boundary

**Exact quantifiers.** The universal statement (FC), quantified over every
simple plane cubic bipartite brace, every legal two-gate expansion, every
unchanged root with nonempty target family, and every forced-gate connected
component, remains undecided. Equation (9) is proof-level equivalent to it.

**Weakest load-bearing step.** One must prove that no *brace-realizable*
closed bond-toggle trace with gate bits \(11\) can remain inside
\(\operatorname{Bad}\). The transition must be controlled at the level of
the labelled terminal incidence \(J_{M,S}\), not only by \(p-q\), root
separation, or gate parity.

**Evidence level.** The bond-toggle lemma, the boundary acceptance criterion,
and equivalence (9) are proof-level. The order-18 failure of (10) is an exact
finite plane-brace witness. The Note 068 vertex state in (11)--(12) is an
actual plane-brace state, but the two-state transition product (13) is only
an abstract weakened-axiom countermodel. The complete through-order-22 theorem
of Note 073 finds no failure of (FC), but finite success is not an
arbitrary-order proof.

**Unresolved boundary.** A positive proof needs a plane-incidence theorem
coupling every admissible bond shore \(S\) to the terminal pairing
\(J_{M,S}\), strong enough to force an exit from (5). A negative solution
needs a single real plane-brace interface whose entire forced-gate
target-state component realizes a closed bad trace. Neither is presently
available; no further order is selected here.

## 9. Reproduction

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/verify_forced_gate_weak_transition_countermodel.py

Expected marker:

    FORCED_GATE_WEAK_TRANSITION_AXIOMS_COUNTERMODEL_VERIFIED

For the actual order-18 route closure:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/verify_forced_component_arc11_counterexample.py \
      --output [unbundled local reference]

    cmp [unbundled local reference] \
      units/barnette/computations/forced_component_non_arc11_witness.json

Expected marker:

    FORCED_COMPONENT_ARC11_IMPLICATION_COUNTEREXAMPLE_VERIFIED
