> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every three-double J1/J3 free group contains an exact square reduction

[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md)
classifies the eight orientation words of three
doubly vacant \(J_1/J_3\) blocks and proves a
spanning route through each realizable ordinary
target-free free group. Its marked Hamilton
consequence required vacancies outside that
group to occupy distinct internal blocks.
The exact four-terminal reductions of
[Note 375](375-every-j3-j1-j1-triple-with-short-flanks-has-an-exact-square-reduction.md)
remove that condition from the structural
classification.

Let a Barnette graph have the compressed,
gapless, tight-target all-square selected
opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with
exactly three doubly vacant complete blocks.
Every other complete block of this group is
short, no singly vacant block occurs in it,
and each double block has one internal
free matching chord of type \(J_1\) or \(J_3\).
All internal corridors and outer short flanks
are arbitrary.

**Three-double exact-reduction theorem.**
Every complementary matching actually
occurring under these hypotheses contains
an induced disk four-pole with exactly the
square's complete spanning single-path
and two-path Hamilton signature. Replacing
that patch by its labeled square, or
reversing the replacement, preserves
Barnette membership and every Hamilton
decision on exterior and attachment edges.
It also preserves the selected opening.
The patch may be a proper subinterval of
the group or the entire group. No
hypothesis is imposed on vacancies outside
this group. In particular a vertex-minimal
non-Hamiltonian Barnette graph contains none
of the classified induced disk patches, even
when that graph has no selected opening.

**Proof by the eight orientation words.**
For \(J_1,J_1,J_1\),
[Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md)
chooses a minimum closed interval of
special \(H/I\) slots. Its noncrossing
matching forces a canonical chain
\(R_{m,\mathbf k}\), \(m\ge2\), with
positive short corridors. Note 333
gives that induced chain the complete
square signature and two-way Barnette
replacement. Old-cycle reflection
handles \(J_3,J_3,J_3\).

For the alternating words
\(J_1,J_3,J_1\) and \(J_3,J_1,J_3\),
[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md)
supplies the exact square-equivalent
24-vertex patch when both internal
corridors are empty.
[Note 340](340-a-k-block-corridor-before-an-alternating-triple-has-exactly-k-matching-types.md)
classifies every positive allowed
corridor length and gives the resulting
induced \(24+4k\)-vertex four-pole the
same exact, class-preserving signature.
[Note 341](341-no-short-corridor-after-the-middle-block-of-an-alternating-triple.md)
excludes a positive corridor in the
other internal position. Reflection
covers the reverse alternating word.

[Note 342](342-a-j1-j1-j3-triple-is-impossible-with-arbitrary-short-corridors.md)
excludes \(J_1,J_1,J_3\) and
\(J_1,J_3,J_3\) for every pair of
internal corridor lengths. There is
therefore no actual matching in these
two cases.

For \(J_3,J_1,J_1\), Note 343 forces
the first two double blocks adjacent
and the last two separated by at least
one short block. Note 375 proves
that the *entire* group, with arbitrary
short flanks and every actual matching,
is an exact square-equivalent induced
four-pole with two-way Barnette
preservation. Old-cycle reflection
gives \(J_3,J_3,J_1\).

These are all eight words. Every
admitted reduction strictly decreases
the number of vertices. If a
vertex-minimal non-Hamiltonian Barnette
graph contained one of these induced disk patches,
its square replacement would be a
smaller non-Hamiltonian Barnette graph,
a contradiction. The replacement
preserves the old-cycle segment and
common-face arc as one short
target-free block, leaving sites,
targets, and all other groups
outside the patch unchanged.
This proves the theorem. \(\square\)

The conclusion eliminates this precise
three-double \(J_1/J_3\) group from a
minimal counterexample conditional
on the selected opening. It does
not prove that every Barnette graph
has such an opening, nor does it
handle other internal chord types,
a singly vacant block in the same
group, target-bearing terminal
vacancies, positive gaps, defective
target order, nonsquare residual
cycles, or the general conjecture.
The argument is project-internal and
has not had independent review.
