> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A four-atom surrounding vacancy component has three routes across two ports

Note 294 settles the sharp five-vacancy two-sided shared-block branch.
With one additional vacancy, it may join the vacancy-only component
through the shared block. The extra atom creates a clean first gap
in that component. A cap can follow the old Hamilton cycle past both
ports; a straight route absorbs the surrounding alternating cycle
there; a crossed route folds on the two sides of the new atom.

Use the compressed, gapless, tight-target all-square opening and block
notation of Notes 275 and 294. Vacancies lie in distinct target-free
internal face-chord blocks. Fix a free group with retained ordinary
end links. Let
\[
 i<t<j\le s-1<m=s+1,\qquad m+2\le u<w,             \tag{1}
\]
and put \(Q=B_i,\ldots,B_w\). The six displayed blocks are vacant,
\(B_s\) is short, and the two consecutive ordinary links
\(P_s=e_so_m\), \(P_m=e_mo_{m+1}\) are missing. The distinguished
atom components are
\[
 \{V_i,V_t,V_m,V_w\},\qquad \{V_j,P_s\},\qquad
 \{P_m,V_u\}.                                           \tag{2}
\]
Their matching edges are exactly
\[
\begin{array}{llll}
 H_iI_w,&I_iH_t,&I_tH_m,&I_mH_w,\\
 H_jo_m,&I_je_s,&&\\
 e_mI_u,&o_{m+1}H_u.&&
\end{array}                                              \tag{3}
\]
All other ordinary links in \(Q\) are retained. Additional
vacancy-only components may lie inside the five proper block gaps
\[
\begin{array}{lll}
 F_1=B_{i+1},\ldots,B_{t-1},&
 F_2=B_{t+1},\ldots,B_{j-1},&
 F_3=B_{j+1},\ldots,B_{s-1},\\
 F_4=B_{m+1},\ldots,B_{u-1},&
 F_5=B_{u+1},\ldots,B_{w-1}.&
\end{array}                                              \tag{4}
\]
Only \(F_4\) must be nonempty. No other port component meets
\(Q\). Noncrossing of the atom partition makes every gap closed
under its vacancy matching, so Note 275 supplies its spanning
straight path \(S(F_k)\) and disjoint crossed rails
\[
 T_k:a_{\min F_k}\longleftrightarrow b_{\max F_k},
 \qquad
 D_k:o_{\min F_k}\longleftrightarrow e_{\max F_k}
 \quad(F_k\ne\varnothing).                              \tag{5}
\]

**Four-atom surrounding-component theorem.** The interval \(Q\)
has the three vertex-spanning states
\[
\begin{array}{ll}
 S(Q):&o_i\longleftrightarrow e_w,\\
 K(Q):&a_i\longleftrightarrow o_i,\quad
       e_w\longleftrightarrow b_w,\\
 X(Q):&a_i\longleftrightarrow b_w,\quad
       o_i\longleftrightarrow e_w.
\end{array}                                              \tag{6}
\]
The reflected statement holds when the four-atom component
has one atom to the left and two to the right of its shared-block
atom. Other vacancy-only parts may nest at any depth in the
five gaps or surround the combined interval. If every other free
group has its ordinary spanning route, the parent has a Hamilton
cycle through both site edges and its legal expanded child is
Hamiltonian.

**Proof: the straight state.** Define an ordinary continuation
\(\Pi:e_t\longleftrightarrow e_w\) through the blocks to the right
of \(B_t\). For every displayed vacant block, take its
\(o,a,b,e\) passage, which omits its \(H,I\) slots. In every
proper gap \(F_2,F_3,F_4,F_5\), use \(S(F_k)\) and the retained
ordinary links at its ends; an empty gap uses its direct link.
Replace the absent \(P_s\) by
\[
 e_s,I_j,H_j,o_m,                                     \tag{7}
\]
and the absent \(P_m\) by
\[
 e_m,I_u,H_u,o_{m+1}.                                \tag{8}
\]
Every edge in (7)--(8) is in (3) or on the old cycle.
Together with the ordinary vertices \(o_t,a_t,b_t\) supplied
by (9) or (10), the continuation \(\Pi\) covers
\(B_t,\ldots,B_w\) except the six vacancy slots of
\(V_t,V_m,V_w\). The two further slots \(H_i,I_i\) lie
in the left block. The continuation starts at \(e_t\)
and ends at \(e_w\).

If \(F_1\) is empty, precede \(\Pi\) by
\[
 o_i,a_i,b_i,e_i,I_i,H_i,I_w,H_w,I_m,H_m,
 I_t,H_t,o_t,a_t,b_t,e_t.                             \tag{9}
\]
The detour from \(e_i\) to \(o_t\) follows the surrounding
component's alternating cycle, omitting only its edge
\(I_iH_t\): its joins are the old-cycle vacancy edges and
the matching edges \(H_iI_w,I_mH_w,I_tH_m\).

If \(F_1\) is nonempty, use its cap state \(K(F_1)\), with
paths \(K_L:a_{i+1}\longleftrightarrow o_{i+1}\) and
\(K_R:e_{t-1}\longleftrightarrow b_{t-1}\). Replace (9) by
\[
\begin{split}
 o_i,a_i,b_i,a_{i+1}&\xrightarrow{K_L}o_{i+1},e_i,
 I_i,H_i,I_w,H_w,I_m,H_m,I_t,H_t,o_t,e_{t-1}\\
 &\xrightarrow{K_R}b_{t-1},a_t,b_t,e_t.                \tag{10}
\end{split}
\]
The two cap paths cover \(F_1\) exactly once. Both (9)
and (10), followed by \(\Pi\), are simple paths from
\(o_i\) to \(e_w\), and the outer detour covers precisely
the vacancy slots omitted by \(\Pi\).

**Proof: the cap state.** Keep the disjoint edge \(e_wb_w\).
If \(F_1\) is empty, use
\[
 a_i,b_i,a_t,o_t,e_i,I_i,H_t
 \xrightarrow{C\text{ forward}}I_w,H_i,o_i.            \tag{11}
\]
If \(F_1\) is nonempty, replace the passage from \(b_i\)
to \(e_i\) in (11) by both crossed rails:
\[
 b_i,a_{i+1}\xrightarrow{T_1}b_{t-1},a_t,o_t,
 e_{t-1}\xrightarrow{D_1^{-1}}o_{i+1},e_i.             \tag{12}
\]
The edge \(I_iH_t\) starts the long old-cycle arc. That
arc covers all blocks from \(H_t\) to \(I_w\), including
both absent ordinary links' endpoints, without using either
link. Equations (11)--(12) cover the rest of \(B_i,F_1,B_t\).
Only \(e_w,b_w\) are omitted by this path, and they form
the right cap. This gives \(K(Q)\).

**Proof: the crossed state.** Its bottom path is
\[
 o_i,H_i,I_w,e_w.                                    \tag{13}
\]
Construct the top path using five consecutive pieces
\(L_1,\ldots,L_5\). Their endpoints and internal routes are:
\[
\begin{array}{ll}
 L_1:b_i\leadsto e_i:&
 \begin{cases}
 b_i,a_t,o_t,e_i,&F_1=\varnothing,\\
 b_i,a_{i+1}\xrightarrow{T_1}b_{t-1},a_t,o_t,
 e_{t-1}\xrightarrow{D_1^{-1}}o_{i+1},e_i,&F_1\ne\varnothing;
 \end{cases}\\[8pt]
 L_2:o_j\leadsto a_j:&
 \begin{cases}
 o_j,e_t,b_t,a_j,&F_2=\varnothing,\\
 o_j,e_{j-1}\xrightarrow{D_2^{-1}}o_{t+1},e_t,b_t,
 a_{t+1}\xrightarrow{T_2}b_{j-1},a_j,&F_2\ne\varnothing;
 \end{cases}\\[8pt]
 L_3:e_s\leadsto a_s:&
 \begin{cases}
 e_s,o_s,a_s,&F_3=\varnothing,\\
 e_s,o_s,e_{s-1}\xrightarrow{D_3^{-1}}o_{j+1},
 a_{j+1}\xrightarrow{T_3}b_{s-1},a_s,&F_3\ne\varnothing;
 \end{cases}\\[8pt]
 L_4:b_m\leadsto a_u:&
 b_m,a_{m+1}\xrightarrow{T_4}b_{u-1},e_{u-1}
 \xrightarrow{D_4^{-1}}o_{m+1},H_u,o_u,a_u;\\[5pt]
 L_5:o_w\leadsto a_w:&
 \begin{cases}
 o_w,a_w,&F_5=\varnothing,\\
 o_w,e_{w-1}\xrightarrow{D_5^{-1}}o_{u+1},
 a_{u+1}\xrightarrow{T_5}b_{w-1},a_w,&F_5\ne\varnothing.
 \end{cases}
\end{array}                                              \tag{14}
\]
The full top path is
\[
\begin{split}
 a_i,&L_1,I_i,H_t,I_t,H_m,o_m,H_j,L_2,b_j,e_j,I_j,
 L_3,b_s,a_m,L_4,b_u,e_u,I_u,e_m,I_m,H_w,L_5,b_w.
\end{split}                                             \tag{15}
\]
Here \(L_1\) starts at \(b_i\) after \(a_i b_i\);
\(L_2\) starts at \(o_j\) after \(H_jo_j\);
\(L_3\) starts at \(e_s\) after \(I_je_s\);
\(L_4\) starts at \(b_m\) after \(a_mb_m\); and
\(L_5\) starts at \(o_w\) after \(H_wo_w\).
The joins between the five pieces are edges of (3),
old-cycle edges, or face chords. Each nonempty gap is
covered exactly once by its two disjoint \(X\) rails.
Piece \(L_1\) uses only \(a_t,o_t\) in \(B_t\), while
\(L_2\) uses its remaining ordinary vertices \(e_t,b_t\);
\(H_t,I_t\) lie between them on the top path. The bottom
path uses \(o_i,H_i,I_w,e_w\), and the top path covers every
other vertex once. This proves \(X(Q)\).

Note 275's prime and serial composition now absorbs any
vacancy-only components outside \(Q\); Note 273 joins the
groups. Notes 001 and 178 lift the marked Hamilton parent
cycle to the legal child and restore arbitrary lobe lengths.
\(\square\)

**Complete six-vacancy outer-component corollary.** Suppose a
free group has exactly two consecutive missing ordinary links,
their shared block is vacant, its vacancy-only component has
atoms on both sides, and the group has exactly six vacancies.
If four of the vacancies belong to that component, the group
has \(S,K,X\). The statement includes every possible spacing
and every relative position of the four-atom component, up to
reflection.

Indeed, Note 278 separates the port components, so the two
remaining vacancies belong one to each port component.
Reflect if needed to put the extra surrounding-component
atom before the shared block. Write its atoms as
\(V_i,V_t,V_m,V_w\). Since \(P_s\) lies between
\(V_t,V_m\) and \(P_m\) between \(V_m,V_w\), noncrossing
forces their respective single vacancies \(V_j,V_u\) into
those gaps. Old-cycle adjacency gives the inequalities (1),
and no other vacancy remains. Hence (2)--(3) apply.
\(\square\)

**Unbounded realized family.** For any
\(d_1,\ldots,d_5\ge0\), set
\[
 i=1,\quad t=2+d_1,\quad j=t+1+d_2,
 \quad s=j+1+d_3,\quad m=s+1,
 \quad u=m+2+d_4,\quad w=u+1+d_5,\quad r=w.           \tag{16}
\]
Use the old cycle, site, face, escape, and residual-square
edges of Note 281(8)--(9), make precisely the six blocks in
(2) vacant, and use (3) with every other ordinary link
retained. Its matching is perfect and opposite-colour.
On the side opposite the site face, \(H_iI_w\) surrounds
all other free chords, \(I_iH_t\) lies in the clean first
gap, \(I_tH_m\) surrounds the left-port chords, and
\(I_mH_w\) surrounds the right-port chords. All intervals
are nested or disjoint, so the plane embedding is valid.

Retained ordinary links interlace the face chords in the
left and right standard-chain pieces. The special edges
\(I_iH_t,I_tH_m,H_iI_w\) attach every piece to those
chains; each remaining special edge interlaces its endpoint
face chord. The unchanged site and residual-square matching
edges close the interlacement chain of Note 281. Thus the
matching-chord interlacement graph is connected. Notes 217
and 182 give three-connectivity. The parent has
\(56+4\sum_{k=1}^5d_k\) vertices, its legal child has
\(60+4\sum_{k=1}^5d_k\), and both have the asserted
Hamilton cycles.

This settles the six-vacancy branch in which the extra
vacancy enlarges the component through the shared block.
The two other sharp six-vacancy branches put it in a port
component; they remain separate routing questions. Neither
this theorem nor Note 294 settles Barnette's conjecture.
