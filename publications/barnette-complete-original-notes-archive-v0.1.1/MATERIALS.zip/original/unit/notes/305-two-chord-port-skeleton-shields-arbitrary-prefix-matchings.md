> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A two-chord port skeleton shields arbitrary prefix matchings

[Note 304](304-cycle-traversed-port-gaps-absorb-arbitrary-internal-components.md)
allows arbitrary port components in every nonfinal gap of a
serial end-port component except the first gap of the first
component. That exception is unnecessary. Moreover, the
three-state paths never inspect the rainbow matching edges
along any component prefix. Only one outer chord, one last
vacancy chord, and a right cap are used in each serial region.

Use the old Hamilton cycle \(C\) and compressed, gapless,
tight-target all-square blocks of Notes 275--304. A short block
has old-cycle order \(a_j,o_j,e_j,b_j\); a vacant block has
order \(a_j,o_j,H_j,I_j,e_j,b_j\). The face chord
\(a_jb_j\) belongs to the complementary perfect matching.
Retain the surrounding vacancy-only component
\(\mathcal C\) of Note 302(1), with first vacancy
\(V_s\), second vacancy \(V_w\), last vacancy \(V_z\),
and its matching edges from Note 302(5). Inside its first
proper gap choose indices
\[
 s=u_0<u_1<\cdots<u_k<w,\qquad k\ge1,
 \qquad u_{i-1}<v_i<u_i,
 \qquad 1\le i\le k,                                  \tag{1}
\]
where each \(B_{v_i}\) and \(B_{u_i}\) is vacant.
Put \(a_i=u_{i-1}\). Require the two matching edges
\[
             e_{a_i}I_{u_i},\qquad I_{v_i}H_{u_i},  \tag{2}
\]
and the retained ordinary link
\(e_{u_i-1}o_{u_i}\). For each \(i\), require a path
\[
 D_i:e_{u_i-1}\leadsto b_{u_i-1}                 \tag{3}
\]
whose vertex set is exactly
\[
 \{e_{v_i},b_{v_i}\}\cup
 \bigcup_{j=v_i+1}^{u_i-1}V(B_j).                  \tag{4}
\]
When \(u_i=v_i+1\), take \(D_i=e_{v_i}b_{v_i}\).
The ordinary crossed-rail fold of Note 286, the more
general \(X\)-state fold of Note 304, and the branched
cap of Note 303 are all instances of (3)--(4).
Keep Note 302's crossed suffix \(J=B_{u_k+1},\ldots,B_{w-1}\),
its retained boundary links, and the vacancy-only
continuations from \(B_w\) through \(B_z\). In particular,
its paths \(X(J)\), \(X(B_{u_k+1},\ldots,B_z)\), and the
later \(S\) continuations remain available. Apart from
the displayed edges and these suffix interfaces, impose no
restriction on the complementary matching of the prefix
blocks \(B_{a_i+1},\ldots,B_{v_i}\), including their
ordinary links and additional vacancies. Any cross-interval
matching must still produce an actual simple cubic bipartite
plane three-connected parent with the stated fixed edges.

**Two-chord skeleton theorem.** Under (1)--(4), the span
\(Q=B_s,\ldots,B_z\) has the vertex-spanning states
\[
\begin{array}{ll}
S(Q):&o_s\longleftrightarrow e_z,\\
K(Q):&a_s\longleftrightarrow o_s,\quad
       e_z\longleftrightarrow b_z,\\
X(Q):&a_s\longleftrightarrow b_z,\quad
       o_s\longleftrightarrow e_z.
\end{array}                                                   \tag{5}
\]
In all three states, each prefix except its final
\(e_{v_i},b_{v_i}\) is traversed on \(C\); those two
vertices are covered by \(D_i\). In particular, all
matching edges with both endpoints in a prefix are avoided
simultaneously. The usual marked Hamilton parent and legal
Hamilton child follow when the other free groups have their
ordinary spanning routes.

**Proof.** The first-port path of Note 302(8) has the
following simpler replacement:
\[
 L_1^\circ:\quad
 a_{s+1}\xrightarrow{C\text{ forward}}I_{u_1},e_s.
                                                               \tag{6}
\]
The last edge is \(e_sI_{u_1}\) from (2). The old-cycle
arc contains every vertex of
\(B_{s+1},\ldots,B_{u_1-1}\), and in \(B_{u_1}\)
it contains \(a_{u_1},o_{u_1},H_{u_1},I_{u_1}\).
Consequently \(L_1^\circ\) has exactly the endpoints and
vertex set of Note 302's \(L_1\): it omits only
\(e_{u_1},b_{u_1}\). It uses \(B_s\) only at \(e_s\)
and uses no other matching edge in its interval. This holds
even if the first atom gap contains arbitrarily many ports.

For every serial region define
\[
 T_i:\quad b_{a_i}
 \xrightarrow{C\text{ forward}}I_{v_i},H_{u_i},o_{u_i},
 e_{u_i-1}\xrightarrow{D_i}b_{u_i-1},a_{u_i},b_{u_i}.
                                                               \tag{7}
\]
The joins after the old-cycle prefix are, in order, the
second matching edge in (2), an old-cycle edge, the retained
link \(e_{u_i-1}o_{u_i}\), an old-cycle edge, and the face
chord \(a_{u_i}b_{u_i}\). The prefix covers all blocks
\(B_{a_i+1},\ldots,B_{v_i}\) except
\(e_{v_i},b_{v_i}\); (4) supplies exactly those two
vertices and all intervening blocks. The last two vertices
are \(a_{u_i},b_{u_i}\), while \(H_{u_i},o_{u_i}\)
were visited before \(D_i\). Thus \(T_i\) is a simple
path from \(b_{a_i}\) to \(b_{u_i}\), uses its source
block only at \(b_{a_i}\), and spans all new blocks except
\(I_{u_i},e_{u_i}\). No unlisted prefix matching edge
is used.

These are precisely the two inventories used in
Note 302(9)--(18). Its cap recurrence \(R_i\) joins
successive \(T_i\) using the first edge in (2); its straight
route uses \(L_1^\circ\), the surrounding-component
alternating walk, and the caps; its cap and crossed states
use the same \(T_i\), the first edges in (2), and the
unchanged suffix. Replacing those local paths changes no
endpoint or overlap. The disjoint vertex inventories in
Note 302 therefore prove all three states in (5).
Note 273 splices the free groups, and Notes 001 and 178
give the marked parent and legal child conclusions.
\(\square\)

**Unbounded first-gap realization.** Fix \(d\ge1\), put
\[
 v=2d+3,\qquad u=v+1,
 \qquad z=u+1=r=2d+5,                              \tag{8}
\]
and take Note 281(8)'s old-cycle layout with \(\ell=1\).
Make exactly
\[
 B_1,\ B_4,B_6,\ldots,B_{2d+2},\ B_v,B_u,B_z  \tag{9}
\]
vacant, and every other internal block short. Retain all
ordinary links except \(P_1\) and \(P_{2j}\)
for \(1\le j\le d\). Along with the unchanged site,
face, escape, and residual-square matching edges, use
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\mathcal C=\{V_1,V_z\},\\
e_1I_u,\ o_2H_v,\ I_vH_u;&
  \mathcal P=\{P_1,V_v,V_u\},\\
e_{2j}I_{2j+2},\ o_{2j+1}H_{2j+2}
  \quad(1\le j\le d);&
  \mathcal Q_j=\{P_{2j},V_{2j+2}\}.
\end{array}                                                   \tag{10}
\]
The \(\mathcal Q_j\) form an unbounded side chain in
the *first* atom gap of \(\mathcal P\). Equation (10)
pairs the \(2(d+4)\) vacancy slots and \(2(d+1)\)
missing-link slots exactly once; every edge joins opposite
old-cycle colours. The two outer vacancy chords are nested.
The chord \(e_1I_u\) encloses \(o_2H_v\) and
\(I_vH_u\); the latter two are disjoint, and
\(o_2H_v\) encloses the pairwise disjoint
\(\mathcal Q_j\) chords. Each
\(e_{2j}I_{2j+2}\) encloses
\(o_{2j+1}H_{2j+2}\); retained ordinary links are
nested or disjoint. This gives a plane cubic bipartite
embedding with the same cofacial site edges as Note 281.

The matching-chord interlacement graph is connected.
For \(F_j=a_jb_j\), each retained ordinary link joins
\(F_j,F_{j+1}\). At a missing \(P_{2j}\), the two
replacement chords join \(F_{2j}\) to \(F_{2j+2}\)
and \(F_{2j+1}\) to \(F_{2j+2}\), respectively.
At the missing \(P_1\), \(e_1I_u\) joins \(F_1,F_u\),
and \(o_2H_v\) joins \(F_2,F_v\). The retained
\(P_{2d+2}\), \(P_v\), and \(P_u\), together with
\(I_vH_u\), attach the side chain, \(F_v,F_u,F_z\).
Every chord in (10) interlaces a face chord at an endpoint
block, and Note 281's unchanged site and residual-square
closing chain attaches the outer chords. Notes 217 and 182
therefore imply three-vertex connectivity. The parent is
Barnette, and the site-expanded child is legal.

For this family \(D=e_vb_v\) and the only required
chords from (2) are \(e_1I_u,I_vH_u\). The route (6)
traverses every side-chain block on \(C\), so the theorem
applies without any \(X\) state in the first gap. There
are \(r=2d+5\) internal blocks and \(d+4\) vacancies;
the parent and child orders are
\[
 12+4r+2(d+4)=40+10d,\qquad 44+10d.             \tag{11}
\]
All three states, and the marked Hamilton cycles they
produce, avoid the \(2d\) side-chain matching edges
simultaneously. The first member has 50 and 54 vertices.

The theorem is a sufficient two-chord-and-cap criterion
within the stated opening. It does not assert that every
Barnette graph or every matching in this opening admits
such a skeleton.
