> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every target-free group with distinct vacancies has three routes

[Note 276](276-distinct-target-free-vacancies-have-only-chain-defects.md)
reduces free-slot defects to missing ordinary links;
[Note 278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md)
turns the remaining matching into a noncrossing partition of vacancy
and port atoms, with at most one port in each component.
[Notes 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md)
and [317](317-closed-vacancy-intervals-have-the-exact-square-linkage-signature.md)
provide exact four-terminal reductions. Selecting an innermost port
component makes these reductions available regardless of how many
other ports the group contains.

Let \(G\) be a Barnette parent with the compressed, gapless,
tight-target all-square opening of Notes 273--318. Every vacancy
lies in a distinct target-free internal face-chord block. Fix a
full target-free internal free group \(D=B_a,\ldots,B_b\) with
retained ordinary end links. Let any number \(d\ge0\) of its
internal ordinary links \(P_j=e_jo_{j+1}\) be missing. Other groups
and their matchings are unrestricted subject to this opening.

**All-defect group theorem.** The interval \(D\) has all three
vertex-spanning states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b.
\end{array}                                               \tag{1}
\]
The number and locations of missing links, the number of vacancies,
and the sizes and nesting depths of rainbow components are arbitrary.
More precisely, a finite sequence of exact four-terminal
Barnette-preserving replacements removes all missing links, while
preserving the group's four labeled exterior attachments and each
state in (1) in both directions. If the other free groups have their
ordinary spanning routes, the parent has a Hamilton cycle through
both site edges and its legal site-expanded child is Hamiltonian.

**Proof.** Note 276 says every ordinary-to-ordinary matching edge
in \(D\) is a retained link \(P_j\). By Note 278, the free matching
is a noncrossing partition of its vacancy atoms and missing-link
port atoms, with no singleton component and at most one port in
each component. A component containing a port therefore contains
at least one vacancy.

Assume a port remains. Among all port-containing components, choose
one, \(\mathcal C\), whose interval from first to last atom has
minimum span. Write \(P\) for its unique port, and choose a vacancy
\(W\) immediately preceding or following \(P\) in \(\mathcal C\).
There is no other atom of \(\mathcal C\) between \(P,W\). Any other
component with an atom in this proper gap lies wholly inside it:
an atom outside would interlace the two consecutive atoms \(P,W\).
Such a component cannot contain a port, since its span would be
strictly smaller than that of \(\mathcal C\). Thus all vacancy
components meeting the gap \((P,W)\) are closed within it, and no
other missing link lies there.

Write \(P=P_j\). If \(W=B_k\) follows \(P\), the complete block
interval between them is \(J=B_{j+1},\ldots,B_{k-1}\); if \(W=B_k\)
precedes \(P\), it is \(J=B_{k+1},\ldots,B_j\). This interval is
nonempty. In the first case \(k=j+1\) would force the matching
edge \(o_{j+1}H_{j+1}\), and in the second \(k=j\) would force
\(I_je_j\). Both are old-cycle edges, forbidden in the complementary
matching. All internal ordinary links of \(J\) are retained.
Its vacancy matching is closed by the preceding noncrossing
argument, and exactly four edges leave it: the two old-cycle
edges at its ends and one matching edge at each ordinary end slot.

Note 317 replaces \(J\) by one short square with the identical
four-terminal spanning one-path and two-path signatures. The
square and \(W\) are now precisely Note 315's ten-vertex cube-fold
patch, reflected when \(W<P\). Fold them to one short block.
Both replacements preserve Barnette membership and the marked
opening. The fold either restores \(P\) as a retained ordinary link
or leaves it as a port in the same component with \(W\) removed;
it leaves every other port and atom component unchanged, apart
from the closed vacancy-only components removed with \(J\).
Each unrepaired step deletes at least one vacancy, so repeating
this choice terminates. A remaining port would again belong to a
non-singleton component and permit another step. Hence the final
graph has no missing ordinary link in \(D\).

The replacements preserve the four labeled exterior attachments
and retained end links of \(D\). If a folded patch touches \(B_a\),
the group terminals \(a_a,o_a\) are the two left labels of the
reflected patch; if it touches \(B_b\), \(e_b,b_b\) are the two
right labels of the unreflected patch. Their full one-path and
two-path signatures transfer any
spanning route with the endpoint pattern (1) in either direction.
In the final graph all ordinary links are retained; Note 275 gives
\(S,K,X\) for its internally matched vacancy-only group (or Note
317 compresses the group to a square). Lift the three routes
through the replacements in reverse order. Notes 273, 001, and 182
supply the conditional marked-parent and legal-child conclusions.
\(\square\)

**Local square-reduction corollary.** The same conclusion has an
intrinsic four-pole form. Let an arbitrary Barnette graph contain
an induced disk patch \(D=B_a,\ldots,B_b\) made of the short and
vacant blocks of Note 317, with their local spine and closing edges.
The interblock spine edges \(b_ja_{j+1}\) are present. Each internal
ordinary link \(e_jo_{j+1}\) is either present or has both ends
joined by chords to vacancy slots of \(D\); all other vacancy
slots are matched to vacancy slots of \(D\). These chords form
a noncrossing matching in the disk opposite the closing edges.
There are no other patch chords, and exactly four edges
leave \(D\), at \(a_a,o_a,e_b,b_b\) in that cyclic order. No
Hamilton cycle of the ambient graph is assumed.

This patch has exactly the square's four spanning one-path
terminal pairs and two spanning two-path terminal pairings.
Replacing it by a labeled square preserves Barnette membership
and transfers every Hamilton cycle in both directions with the
same exterior edges. Indeed, the virtual missing-link arcs and
vacancy pairs again form a noncrossing atom partition. Two ports
cannot share one component: the complete block interval between
consecutive ports of that component would have every matching
edge internal, leaving only its two end spine edges across a cut,
contrary to three-edge-connectivity. The minimum-span peeling
proof above now applies without change; after all ports are
removed, the patch is the closed interval of Note 317, whose
square signature comes from Note 275's local \(S,K,X\)
construction and requires no global Hamilton cycle. Notes 315
and 317 transfer that full signature through every reduction and
preserve the Barnette class. Consequently a vertex-minimal
non-Hamiltonian Barnette graph cannot contain such a patch with
more than four vertices. \(\square\)

For two missing links this completes the reduction of
[Note 318](318-two-port-corridors-reduce-to-port-free-vacancies.md):
no bound on corridor vacancies or matching crossings is needed.
The reduction also works for arbitrarily many ports, because the
minimum-span choice always exposes a port-vacancy gap free of
other ports. The theorem remains conditional on the selected
opening, distinct target-free vacancy blocks, and retained group
end links. It does not settle arbitrary Barnette graphs, openings
with target-bearing or repeated same-block vacancies, positive
gaps, defective target order, or nonsquare residual cycles. The
cube fold is a known reduction; no external priority claim is made.
