> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One four-special leaf always supplies the chorded four-port cover

[Note 469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md) reduces a possible 98-vertex chorded equality profile to one ordinary root with either two marked unary nodes or one leaf containing four directly assigned special positions. The latter profile has a spanning internal two-path cover for the four exterior terminals, independently of the matching arrangement elsewhere in the root.

Use the one-root chorded order
\[
                      w_0,z_L,t_c,W,t_b,z_R,w_*.
\tag{1}
\]
The hexagon has internal matching chord \(ad\), trap chord \(\alpha\beta\), and escape edges \(t_cc,t_bb\). The two exterior face chords have distinct mates \(r_L,r_R\in W\), the site ports are \(u<v\in W\), and the four root terminals \(T=\{r_L,u,v,r_R\}\) are distinct. Their order is necessarily \(r_L<u<v<r_R\): if \(u<r_L\), the common-face-side chords \(w_0u,z_Lr_L\) interlace in the order \(w_0<z_L<u<r_L\); if \(r_R<v\), the chords \(r_Rz_R,vw_*\) interlace in the order \(r_R<v<z_R<w_*\). Equality is excluded by the distinct terminal edges at a cubic vertex. Every assigned special position in \(W\) lies in a two-special ordinary leaf except that one leaf has four directly assigned special positions. There is no restriction on the ordinary wrappers or the face matching of nonterminal positions.

**Four-special leaf theorem.** The parent has a Hamilton cycle containing both site edges \(q=w_0u,p=vw_*\). Its legal expanded child is Hamiltonian.

**Proof.** Let \(C_W\) be the old \(W\)-arc closed by its outer ordinary chord. Write the special positions of the four-special leaf in their old-cycle order as \(x_1,x_2,x_3,x_4\). Because it is an ordinary leaf, they are consecutive inside the leaf chord: its local old arc is
\[
                           h,x_1,x_2,x_3,x_4,j,
\]
with ordinary chord \(hj\). Let \(E\) contain the old adjacent-special edge in every other, two-special leaf. Let \(M\) be the face matching of all special positions other than the four terminals \(T\), and set
\[
       F=(C_W-E-\{x_1x_2,x_3x_4\})\cup M.
\tag{2}
\]
Every nonterminal has degree two and each member of \(T\) has degree one. Thus \(F\) consists of two paths and perhaps cycles.

Restore the edges \(E\) temporarily. The old cycle \(C_W\) with only \(x_1x_2,x_3x_4\) deleted has two arcs: the central edge \(x_2x_3\) and the complementary outer arc from \(x_4\) to \(x_1\), containing every other root vertex. If an \(M\)-edge joins the central edge to the outer arc, \(F\cup E\) is connected. Its component quotient by \(E\) is connected, and every nonloop quotient edge has the disjoint leaf-square switch of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md). Choose a spanning tree of the quotient and delete one edge on its path between the two path components. Switching along the resulting two rooted trees absorbs every cycle while keeping the terminal paths separate. This gives a spanning two-path cover with terminals \(T\).

If no \(M\)-edge joins the two arcs, neither \(x_2\) nor \(x_3\) can be matched internally on the central edge: \(x_2x_3\) is already an old-cycle edge and cannot also be a distinct cubic matching edge. Hence both are terminals. The central edge is one complete terminal path. The outer arc contains the other two terminals; after removing its two-special leaf edges and adding its internal \(M\)-edges, it has one terminal path and perhaps cycles. Its quotient by those leaf edges is connected because the restored outer arc itself is connected. Leaf-square switches absorb every cycle into that path. Together with \(x_2x_3\) this is again a spanning two-path cover of \(W\) with terminals \(T\).

The two explicit exterior two-path covers (2) of [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) cover every vertex outside \(W\), include \(p,q\), and realize two different pairings of \(T\). One differs from the internal pairing just constructed, so their union is a Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

**Equality consequence.** At the chorded bound \(c=5f-7\), [Note 469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md) gives two and only two charging profiles. This theorem closes the profile with \(M_0=L=f-1\) and one four-special leaf. Hence any non-Hamiltonian chorded child at that bound must have \(m=f,R=1,M_0=f,L=f-2\): exactly two nonleaf marked unary nodes, each assigned two special positions, and every leaf is two-special. For \(f=8\) this is a necessary 98-vertex profile, not a counterexample.
