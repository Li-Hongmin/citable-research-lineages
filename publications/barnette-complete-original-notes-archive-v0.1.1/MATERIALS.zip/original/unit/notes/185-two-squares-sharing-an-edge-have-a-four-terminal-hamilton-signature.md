> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two squares sharing an edge have an exact four-terminal Hamilton signature

The six-vertex insertion used at the sharp square-trap boundary in
[Note 184](184-every-sharp-square-trap-opening-has-a-hamiltonian-child.md)
has a useful interface description. It preserves three-connectivity
in a cubic host under a planar bipartite insertion, but it has
Hamilton routes absent from the two edges it replaces. This
explains both the successful forward lift in Note 184 and the
exact boundary of inverse Hamilton compression.

Let \(P\) have vertices \(\alpha,\gamma,\delta,\beta,L,R\)
and edges
\[
\alpha\gamma,\gamma\delta,\delta\beta,\beta\alpha,
\qquad \gamma L,LR,R\delta.
\tag{1}
\]
It consists of the squares
\(\alpha\gamma\delta\beta\alpha\) and
\(\gamma L R\delta\gamma\), sharing \(\gamma\delta\).
Its four terminals are \(\alpha,\beta,L,R\), each of
internal degree two; \(\gamma,\delta\) have degree three.
The terminals occur on the outer boundary in cyclic order
\(\alpha,L,R,\beta\).

**Exact routing signature.** A spanning one-path routing of
\(P\) with terminal endpoints exists exactly for
\[
\{R,L\},\quad\{\alpha,\beta\},\quad
\{R,\alpha\},\quad\{L,\beta\}.
\tag{2}
\]
Spanning two-path routings with all four terminals as endpoints
exist exactly for the pairings
\[
\{\{R,L\},\{\alpha,\beta\}\},
\qquad
\{\{R,\beta\},\{L,\alpha\}\}.
\tag{3}
\]

For (2), the graph is bipartite with colour classes
\(\{\alpha,L,\delta\}\) and \(\{\beta,R,\gamma\}\).
A path covering six vertices has opposite-colour endpoints,
leaving only the four listed terminal pairs. They are
realized, respectively, by
\[
\begin{array}{ll}
R,\delta,\beta,\alpha,\gamma,L,
&\alpha,\gamma,L,R,\delta,\beta,\\
R,L,\gamma,\delta,\beta,\alpha,
&L,R,\delta,\gamma,\alpha,\beta.
\end{array}
\tag{4}
\]
For (3), terminal paths in a disk cannot have interlacing
endpoints. The cyclic terminal order rules out the pairing
\(\{\{\alpha,R\},\{L,\beta\}\}\). The two remaining
pairings are realized by
\[
\{LR,\ \alpha\gamma\delta\beta\},
\qquad
\{R\delta\beta,\ L\gamma\alpha\}.
\tag{5}
\]
This proves the signature. \(\square\)

**Exact expansion criterion.** Let \(X\) be a graph with two
vertex-disjoint edges \(e=AB\) and \(f=PQ\). Delete both
edges, add a fresh copy of (1), and
attach \(A\) to \(R\), \(B\) to \(L\), \(P\) to \(\alpha\),
and \(Q\) to \(\beta\). Call the result \(X^P\).
Then \(X^P\) has a Hamilton cycle if and only if at least
one of the following holds in \(X-\{e,f\}\):

1. a spanning path joins \(A,B\) or joins \(P,Q\);
2. a spanning path joins \(A,P\) or joins \(B,Q\);
3. two vertex-disjoint paths span all old vertices and have
   \(A,B,P,Q\) as their four endpoints, in any pairing.

The criterion follows directly from (2)--(3). A Hamilton cycle
uses an even, positive number of the four attachment edges,
namely two or four. With two, its patch portion is one of
the four paths in (2), and its old portion is the complementary
spanning path. With four, each portion is a spanning two-path
routing. Two pairings on the same four boundary vertices
join into one cycle exactly when they differ. Since (3)
offers two different patch pairings, it can join an old
two-path routing of any of the three pairings. Conversely,
each listed old routing combines with the indicated patch
routing to make one spanning cycle.

**Incident-edge criterion.** Suppose instead that the two
distinct selected edges share the endpoint \(A=Q\), with
\(A,B,P\) distinct. Then \(X^P\) has a Hamilton cycle if and
only if one of the following holds:

1. \(X-\{e,f\}\) has a spanning path from \(A\) to \(B\)
   or from \(A\) to \(P\);
2. \(X-A\) has a spanning path from \(B\) to \(P\).

With exactly two attachment edges, (2) permits only a
route between the common endpoint \(A\) and one of \(B,P\),
giving clause 1. With all four attachments, the common
vertex \(A\) uses both patch spokes and no old edge. The
old portion is therefore a spanning \(B\)--\(P\) path
in \(X-A\), giving clause 2. The first two-path pairing
in (3) connects \(A\) to \(B\) and \(A\) to \(P\), so it
closes that old path into one Hamilton cycle. The second
pairing would instead close a cycle through \(A\) alone
and leave a separate cycle through the other old vertices.
Thus the listed conditions are also sufficient. The other
incident arrangement \(B=P\), with \(A,B,Q\) distinct,
follows by reversing both edge labels and reflecting the patch
through \(R\leftrightarrow L\), \(\alpha\leftrightarrow\beta\),
\(\gamma\leftrightarrow\delta\).
In particular, every Hamilton cycle of \(X\) using at
least one selected edge lifts through the patch. \(\square\)

For a **cubic** host, the incident-edge criterion has a
stronger consequence:
\[
X^P\text{ is Hamiltonian}
\quad\Longleftrightarrow\quad
X\text{ is Hamiltonian}
\qquad(e=AB,\ f=PA),
\tag{6}
\]
Indeed, a Hamilton cycle in a cubic \(X\) must use at
least one of the two selected edges at \(A\), so the
forward lift applies. Conversely, a path in clause 1
closes with \(AB\) or \(AP\), and a path in clause 2
closes with both edges. Thus every Hamilton cycle of
\(X^P\) yields a Hamilton cycle of \(X\). \(\square\)

**Three-connectivity of the insertion.** The two selected
edges may now share one endpoint. Suppose \(X\) is simple,
cubic and three-edge-connected. Then \(X^P\) is
simple, cubic and three-edge-connected. The internal patch
has no bridge, so every nontrivial patch cut has at least
two edges. If a patch cut has exactly two edges, both shores
contain a terminal: a subset containing no terminal is a
nonempty subset of \(\{\gamma,\delta\}\), whose patch cut
has three or four edges.

Assume \(X^P\) had an edge cut of size at most two. If all
patch vertices lie on one shore, projecting that shore onto
the old vertices gives a cut of \(X\) no larger than the
cut of \(X^P\). If the old
vertices all lie on the opposite shore, the four attachment
edges already give a cut of size four. If the patch is split,
its internal cut uses at least two edges. A cut of size at
most two would therefore use exactly two internal patch
edges and no old or attachment edge. A terminal lies on
each shore, so both shores contain old vertices. Their cut
in \(X\) could use only \(e,f\), again contradicting
three-edge-connectivity. Hence \(X^P\) is three-edge-connected.
For cubic graphs, this implies three-vertex-connectivity by
the elementary two-vertex-cut argument in Note 182. \(\square\)

For incident edges there is also a reverse cut map. Given
any old-vertex shore \(W\subsetneq V(X)\), put every
patch vertex on the same shore as \(A\). The two attachments
at \(A\) then remain internal, while the attachments at
\(B,P\) cross exactly when \(AB,AP\), respectively, cross
\(\delta_X(W)\). Every other old edge has the same cut
status. Hence the resulting shore \(W'\) in \(X^P\)
satisfies
\[
|\delta_{X^P}(W')|=|\delta_X(W)|.
\tag{7}
\]
Together with forward preservation, this proves equivalence
of three-edge-connectivity, and therefore of three-vertex-
connectivity, for simple cubic incident-edge insertions.

If \(X\) is also bipartite, the insertion remains bipartite
when the labels satisfy
\(\operatorname{col}(A)=\operatorname{col}(Q)\) and
\(\operatorname{col}(B)=\operatorname{col}(P)\).
If the four attachment incidences occur on a common face in
the cyclic order \(A,B,P,Q\) or its reversal, the patch
embeds inside that face: its outer terminal order maps to
\(P,B,A,Q\), the reverse cyclic order. This includes two
incidences at one old vertex when the edges share an endpoint.
Under these explicit conditions the insertion takes a
Barnette graph to another Barnette graph. The sharp-family
insertions of Notes 182--184 satisfy them, including the
case where two attachment incidences meet at \(x\).

For incident edges at \(A=Q\), the forward face and colour
conditions are automatic in a plane bipartite cubic graph:
the two incident edges bound a face sector at \(A\), and
their other endpoints \(B,P\) have the same colour.
Barnette membership is therefore equivalent in both
directions. Conversely, deleting \(\gamma,\delta\)
and the other unused patch edges leaves the internally
disjoint paths
\(A,R,L,B\) and \(P,\alpha,\beta,A\); contracting their
attachment edges recovers \(X\) as a minor of \(X^P\),
so planarity descends. A bipartition of \(X^P\) restricts
to the old vertices and extends across the recovered
edges \(AB,AP\), because each replaces an odd-length
three-edge path. Cubicity and simplicity hold by the
definition of the insertion, and (7) handles connectivity.
Combining this with (6) gives
\[
X^P\text{ is Barnette}\quad\Longleftrightarrow\quad
X\text{ is Barnette},
\qquad
X^P\text{ is Hamiltonian}\quad\Longleftrightarrow\quad
X\text{ is Hamiltonian},
\tag{8}
\]
for every simple cubic host with two distinct incident selected
edges and a simple inverse, in either reflected orientation.

**Relation to the known cube expansion.** Let \(C\) be the
third neighbour of \(A\) in \(X\). The seven vertices
\(A,\alpha,L,\beta,R,\gamma,\delta\) in \(X^P\)
induce a cube with one vertex deleted. An explicit binary
labelling is
\[
A=100,\quad\alpha=010,\quad L=001,\quad
\beta=110,\quad R=101,\quad\gamma=011,\quad
\delta=111;
\]
the missing cube vertex is \(000\). The old neighbours
\(C,P,B\) attach to the three degree-two vertices
\(A,\alpha,L\), respectively. Thus the incident-edge
operation is exactly the cube expansion of Holton--Manvel--
McKay (1985, DOI `10.1016/0095-8956(85)90072-3`), as
restated by Gorsky--Steiner--Wiederrecht (2023, Section 5,
DOI `10.1016/j.disc.2022.113249`). The Barnette and
Hamilton preservation in (8) is a known property of this
operation; the path-routing proof above gives it directly
with the attachment labels fixed.

Consequently a vertex-minimal non-Hamiltonian
Barnette graph contains no induced copy of this six-vertex
patch with exactly the four specified attachments, two at
one exterior vertex, when the inverse recovery of \(AB,AP\)
is simple: otherwise the inverse would be a smaller
non-Hamiltonian Barnette graph.

For disjoint selected edges, the cross one-path routings
\(R\)--\(\alpha\) and \(L\)--\(\beta\) in (2), and the
second two-path pairing in (3), are not represented by
merely restoring \(AB,PQ\). The incident-edge equivalence
above uses the shared cubic vertex to absorb those extra
routes. The forward lift in Note 184 needs only the first
routing in (2).
