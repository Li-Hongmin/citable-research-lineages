> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cube expansions give unbounded chord-free opposite facial arcs beside one trapped hexagon

The twenty-vertex graph of [Note 407](407-a-nested-site-chord-keeps-a-long-opposite-face-arc-chord-free.md) is a cube expansion of the fourteen-vertex graph of [Note 404](404-a-single-chord-free-hexagon-trap-has-a-short-main-hamilton-bound.md). This identification makes the location failure of Note 407 unbounded in the length of the other facial arc. The operation is the known cube expansion of Holton--Manvel--McKay; see [Note 185](185-two-squares-sharing-an-edge-have-a-four-terminal-hamilton-signature.md) for the Barnette and Hamilton preservation statements and their proof.

In Note 407, put \(x_i=w_{i+4}\) for \(0\leq i\leq9\), and let \(P\) be the induced subgraph on these ten vertices. Its internal edges are the path \(x_0x_1\cdots x_9\) and
\[
 x_0x_5,\qquad x_1x_4,\qquad x_2x_9,\qquad x_3x_6.       \tag{1}
\]
Its four attachments are at \(x_0,x_7,x_8,x_9\), in that cyclic order. A disk embedding has outer boundary \(x_0,x_1,x_2,x_9,x_8,x_7,x_6,x_5,x_0\), with \(x_3,x_4\) inside; this gives the stated port order up to reversal. The seven vertices \(x_0,\ldots,x_6\) induce a cube with vertex \(000\) deleted: assign
\[
 x_0=001,\quad x_2=010,\quad x_6=100,\quad x_4=111,
 \qquad x_1=011,\quad x_3=110,\quad x_5=101.              \tag{2}
\]
The three degree-two vertices of this core are \(x_0,x_2,x_6\), attached respectively to \(w_3,x_9,x_7\).

**Exact square signature.** The patch \(P\) has the same spanning one-path and two-path terminal routings as a square with vertices in cyclic order \(0,7,8,9\). Its four one-path routings are
\[
\begin{array}{c|l}
0,9&0,1,2,3,4,5,6,7,8,9\\
0,7&0,1,4,5,6,3,2,9,8,7\\
8,7&8,9,2,3,4,1,0,5,6,7\\
8,9&8,7,6,5,0,1,4,3,2,9.
\end{array}                                                   \tag{3}
\]
The two spanning two-path routings are
\[
\begin{array}{c|l}
(0,7),(8,9)&(0,1,2,3,4,5,6,7),\quad(8,9)\\
(0,9),(7,8)&(0,1,4,5,6,3,2,9),\quad(7,8).
\end{array}                                                   \tag{4}
\]
Every successive pair in (3)--(4) is an edge of (1) or of the displayed path. The colour classes of \(P\) are its even- and odd-indexed vertices, each of size five. A spanning path therefore has endpoints of opposite colours, leaving exactly the four pairs in (3). In the disk embedding, the terminal order \(0,7,8,9\) excludes the interlacing two-path pairing \((0,8),(7,9)\); (4) realizes both remaining pairings. The square has precisely the same six states. Replacing \(P\) by that square therefore preserves every Hamilton cycle's exterior edges and used attachment edges: a spanning cycle crosses the patch boundary two or four times, and the corresponding internal path routing can be replaced in either direction.

Contracting the cube core to a vertex \(y_4\), and setting \(y_5=x_7,y_6=x_8,y_7=x_9\), gives exactly the fourteen-vertex graph of Note 404, with old cycle
\[
(w_0,w_1,w_2,w_3,y_4,y_5,y_6,y_7,\alpha,a,b,c,d,\beta,w_0)
\]
and matching
\[
\{w_0w_3,y_4y_7,\alpha\beta,w_1d,w_2c,y_5b,y_6a\}.   \tag{5}
\]
The site edge \(p=x_2x_9\) lies *inside* the replaced ten-vertex patch, so its status does not follow from the unmarked four-terminal signature alone. It is, however, an **attachment edge of the seven-vertex cube core**. Every Hamilton cycle through the core uses exactly two of its three attachments. The core has a spanning path between each pair, namely
\[
 (0,1,2,3,4,5,6),\quad(0,5,6,3,4,1,2),\quad
 (2,1,0,5,4,3,6).
\]
Compressing or lifting by the path with the same two attachments therefore preserves membership of \(p\), of every edge outside the core, and of the other two core attachments. Each corresponding square routing has a unique edge set, so in the six four-terminal states (3)--(4), \(p\) is absent precisely in the \((0,9)\) one-path state and the \((0,7),(8,9)\) two-path state; it is present in the other four states. The square edge \(y_4y_7\) has exactly this presence pattern. Hence the Hamilton correspondence between the Note 407 and Note 404 graphs preserves the two site-edge marks \(p,q\) jointly. This is a specific marked transfer for \(p\), not an assertion about arbitrary edges internal to \(P\).

**Unbounded facial-arc theorem.** For every integer \(n\geq0\) there is a Barnette graph \(G_n\) on \(14+6n\) vertices, with an old Hamilton cycle \(C_n\) and two disjoint cofacial matching edges \(q,p_n\), such that:

1. the selected residual facial arc through \(\alpha,\beta\) has length three, and its opening traps exactly one residual cycle, the chord-free hexagon \(\alpha a b c d\beta\alpha\);
2. the other residual facial arc from \(q\) to \(p_n\) has length \(2n+1\), and every edge on it belongs to \(C_n\);
3. exactly \(n\) further main matching chords lie on the common-face side, all strictly inside the cap bounded by \(p_n\), so none lies on the arc in item 2;
4. \(G_n\) has a Hamilton cycle containing both \(q\) and \(p_n\). Consequently its legal square expansion at \(q,p_n\) is Hamiltonian.

**Proof.** Take \(G_0\) to be (5), with \(q=w_0w_3\) and \(p_0=y_4y_7\). Note 404 proves that \(G_0\) is Barnette. Its marked Hamilton cycle is
\[
(w_0,w_3,w_2,w_1,d,c,b,y_5,y_4,y_7,y_6,a,\alpha,\beta,w_0). \tag{6}
\]
Both site edges occur in (6), and at the \(y_4\) end of \(p_0\) the other edge of (6) goes to the successor \(y_5\) on \(C_0\). The other facial arc is the single edge \(w_3y_4\). Keep the stronger induction invariant that the marked cycle uses the natural successor edge at this end of \(p_n\).

Suppose \(G_n,C_n,p_n=vs\) have these properties, with \(v\) on the main segment, predecessor \(u\) and successor \(t\) on \(C_n\). Replace \(v\) by the seven-vertex core \(K\) with path \(z_0z_1\cdots z_6\) and edges
\[
 z_0z_5,\qquad z_1z_4,\qquad z_3z_6,                  \tag{7}
\]
attaching \(u\) to \(z_0\), \(t\) to \(z_6\), and \(s\) to \(z_2\). Put \(p_{n+1}=z_2s\), and replace \(u,v,t\) on the old cycle by \(u,z_0,z_1,\ldots,z_6,t\). This is the cube expansion (2), so the new graph is Barnette by the cube-expansion theorem cited above.

Embed \(K\) in the former vertex disk with outer boundary \(z_0z_1z_2z_3z_6z_5z_0\) and interior vertex \(z_4\). The old common-face boundary portion \(u,v,s\) becomes \(u,z_0,z_1,z_2,s\). Thus the other facial arc gains two old-cycle edges, while the arc through \(\alpha,\beta\) is unchanged. In the specified opening, the main component replaces \(v\) by the spanning core path; the trapped hexagon is untouched and no new residual component appears. Relative to the new old cycle, the first two edges in (7) lie on its opposite side and \(z_3z_6\) lies on the common-face side, strictly within the new \(p_{n+1}\) cap. Previously nested face-side chords remain within that cap. This proves items 1--3 inductively.

Finally, the marked Hamilton cycle at \(v\) uses \(t,v,s\) in one orientation or the reverse. Replace this two-edge segment by
\[
 t,z_6,z_5,z_0,z_1,z_4,z_3,z_2,s.                 \tag{8}
\]
All seven new vertices occur once, every listed edge is present, and the new site edge \(z_2s\) is used. At \(z_2\) the other cycle edge is \(z_3z_2\), its successor edge on \(C_{n+1}\), so the induction repeats. The edge \(q\) is untouched. Item 4 follows, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts this marked parent cycle to the legal square-expanded child. \(\square\)

**Cube/site commutation.** The same reduction transfers the *Hamiltonicity decision of the site-expanded child* without a marked-parent hypothesis. Let \(X\) be a simple cubic graph with disjoint edges \(p=vs\) and \(q=xy\), and let \(u,t\) be the other neighbors of \(v\). Replace \(v\) by the core \(K\) of (7), attaching \(u,z_0\), \(t,z_6\), and \(s,z_2\); call the result \(X^K\) and put \(p^K=z_2s\). Write \(E_{p,q}(X)\) for the site expansion of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), with new vertices \(a,b,c,d\) and local edges
\[
 va,ab,bs,xc,cd,dy,ad,bc.                               \tag{9}
\]
Then there is a label-preserving graph isomorphism
\[
 E_{p^K,q}(X^K)\ \cong\ \bigl(E_{p,q}(X)\bigr)^K_v,       \tag{10}
\]
where the cube expansion on the right attaches \(u,z_0\), \(t,z_6\), and \(a,z_2\). Indeed, both sides replace \(v\) by the same core, delete \(vs,xy\), insert the same eight site-gadget edges except that \(va\) becomes \(z_2a\), and retain every other old edge. Thus (10) is an edge-set identity after identifying the new vertex names. The three core paths displayed above cover all port pairs \((0,6),(0,2),(2,6)\). A Hamilton cycle in either cubic host uses exactly two of the three core attachments, so compression and these three lifts prove the cube expansion's Hamilton equivalence directly. Consequently,
\[
 E_{p^K,q}(X^K)\text{ is Hamiltonian}
 \quad\Longleftrightarrow\quad E_{p,q}(X)\text{ is Hamiltonian}. \tag{11}
\]
If \(X\) is Barnette and \(p,q\) are cofacial, choose \(u\) as the other edge at \(v\) bordering their common face and place the core in that vertex disk. Both site expansions are then legal, and cube expansion preserves Barnette membership. If the cube expansion is at a vertex disjoint from \(p,q\), the two surgeries modify disjoint old edges and likewise commute; the case at a \(q\)-endpoint is the reflection of (10). Thus cube expansion at any vertex commutes with site expansion after tracking incident site edges. No residual-cycle restriction is used in this identity or its Hamilton consequence.

**Exact six-witness transfer.** More than the disjunction in (11) is preserved. For a cube expansion at **any** vertex \(r\) of a simple cubic graph with disjoint site edges \(p,q\), track each site edge incident with \(r\) as the corresponding core attachment and leave the other site edges unchanged. Each of the six witness clauses of Note 001 is separately present before the expansion if and only if its corresponding clause is present afterward, with the expanded endpoint relabelled as its core port. We prove the case \(r=v\) in the notation above; the other cases follow at the end.

For the three Hamilton-cycle clauses, a cycle crosses the core cut in exactly two of its three attachment edges. The three spanning core paths displayed above cover all choices, and the used edge \(z_2s\) records exactly whether the original cycle used \(vs\); \(q\) is outside the core. Thus the states \(11,10,01\) transfer separately, retaining every old edge not incident with \(v\).

Delete the two site edges for the remaining clauses. Only \(uz_0,tz_6\) cross the core cut. A spanning Hamilton path with endpoint \(z_2\) crosses that cut once: the cut parity is odd, and at most two cut edges are available. Its core portion is therefore a spanning path from \(z_2\) to \(z_0\) or \(z_6\), compressing to a path with endpoint \(v\). A spanning Hamilton path whose endpoints are both outside the core crosses twice, giving the \(z_0\)--\(z_6\) core path and compressing to a path with \(v\) internal. These are precisely the two cross-path clauses of Note 001, in their respective endpoint orientations.

For the spanning two-path clause, the four prescribed endpoints include exactly one vertex of the core, \(z_2\). The degree-sum parity on the core again makes the cut size odd, hence one. The path containing \(z_2\) traverses the whole core and leaves by \(z_0\) or \(z_6\); the other path stays outside. Compression gives two spanning paths with endpoint \(v\) and exactly the same pairing of the four site endpoints. Conversely, each path or two-path witness in \(X-\{p,q\}\) lifts by the appropriate one of the three displayed core paths. Thus even the forbidden-pairing distinction in clause 6 transfers exactly.

If \(r\) is incident with \(q\) instead, the same one-endpoint-inside argument applies after interchanging the site names. If \(r\) is incident with neither site edge, all prescribed path endpoints lie outside the core. Each spanning path or two-path union then crosses the three-edge core cut an even, nonzero number of times, hence twice. In the two-path case both crossings belong to one path, since each path separately has both endpoints outside. The core is one spanning segment of that path; compressing or lifting it preserves the four-terminal pairing. Hamilton cycles likewise use two attachments and preserve both site-edge states. This proves the claim for every expansion vertex. The result transfers existence and exterior-edge use, not the number of witnesses or marks on new internal core edges. \(\square\)

Consequently, an order-minimal Barnette parent with a legal site whose child is non-Hamiltonian cannot admit an inverse cube expansion that leaves a simple Barnette parent and a tracked legal cofacial site: the inverse would be a smaller parent with the same six witness absences, hence a smaller non-Hamiltonian child. By the Holton--Manvel--McKay generation theorem cited in [Note 405](405-every-single-hexagon-opening-with-at-most-twelve-main-vertices-has-a-hamiltonian-child.md), any Barnette counterexample would have a first non-Hamiltonian step in a generation from the cube; since cube expansion preserves Hamiltonicity, that first step is a legal site expansion. Thus a hypothetical minimum site failure can be sought among cube-irreducible decorated parents. This does not assert that such a failure exists.

For this family, (10) also says that the legal site-expanded children are successive cube expansions of the child at \(n=0\). Thus their Hamiltonicity follows independently from (11) and the one-edge facial flip of Note 404. At \(n=1\), the parent construction is exactly Note 407: \(z_i=w_{i+4}\), while the former \(y_5,y_6,y_7\) become \(w_{11},w_{12},w_{13}\). Hence the absence of a matching chord *on* the long opposite facial arc persists at arbitrarily large lengths, despite the face-side chord guaranteed by [Note 406](406-a-long-gap-single-hexagon-forces-a-main-face-side-chord.md). This is a reducible family of Hamiltonian Barnette graphs, not a counterexample to Barnette's conjecture. The unmarked square reduction does not by itself transfer arbitrary internal-edge constraints.
