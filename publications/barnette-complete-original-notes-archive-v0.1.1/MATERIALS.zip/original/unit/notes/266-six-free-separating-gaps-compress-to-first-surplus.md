> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Six-free separating gaps compress to the first surplus

[Note 265](265-separating-sharp-vacancy-blocks-have-six-or-seven-free-slots.md)
shows that a sharp two-vacancy block between two singleton
gaps has six or seven free interior slots. In the six-free
case its complete local matching is forced. Eight of its
vertices form a four-column ladder, whose square replacement
removes the two gaps and reaches the marked first-surplus
theorem of [Note 212](212-every-gapless-first-surplus-opening-has-a-marked-hamilton-cycle.md).

Let \(G\) be a Barnette parent with an old Hamilton cycle
\(C\) avoiding the disjoint cofacial matching site edges
\(q=xy,p=uv\), and let their expansion be legal. Select an
all-square facial opening with \(\ell,r\ge1\),
\[
 f=4r+8,\qquad \sigma=T=2.                        \tag{1}
\]
Suppose the two vacancies occupy one face-chord block
\(B=[a,b]_C\), which lies between two singleton gap slots
\(g<h\), and \(B\) has exactly six free interior slots.

**Six-free separating-gap Hamilton theorem.** The parent
\(G\) has a Hamilton cycle containing both \(p,q\).
Consequently its legal site-expanded child is Hamiltonian.
The conclusion holds for arbitrary positive original
lobe lengths.

**Proof.** Compress the residual lobe ladders as in
Note 178. By Note 265, the two singleton gaps are adjacent
to \(B\). Name its interior slots
\(z_1,\ldots,z_{2K+2}\), and put
\(t=z_{2K+1}\), \(w=z_{2K+2}\). The local old-cycle
order is
\[
g,a,z_1,z_2,z_3,\ldots,z_{2K},t,w,b,h,          \tag{2}
\]
and the complementary matching includes
\[
ab,\quad z_1w,\quad z_3z_{2K},\quad gz_2,\quad ht.
\tag{3}
\]
All escape targets lie among \(z_4,\ldots,z_{2K-1}\).
Thus the eight vertices
\[
P=\{g,z_2,a,z_1,b,w,h,t\}
\]
induce exactly the four-column ladder \(P_4\square K_2\).
Its columns, from left to right, are
\[
(g,z_2),\qquad(a,z_1),\qquad(b,w),\qquad(h,t).
\tag{4}
\]
The top rail is \(g-a-b-h\), the bottom rail is
\(z_2-z_1-w-t\), and the four rungs are
\(gz_2,az_1,bw,ht\). Cubicity and (2)--(3) show
that its only exterior edges occur at the corner
terminals \(g,z_2,h,t\): the two cut-cycle edges at
the gaps, and \(z_2z_3,tz_{2K}\). In particular,
\(P\) is disjoint from both site edges and the
residual squares.

Replace this \(L_4\) by the square \(L_2\) with the
same four labeled terminals. Its edges are
\(gz_2,z_2t,th,hg\). Note 178's four-pole theorem
makes the resulting graph \(X\) Barnette and preserves
every Hamilton decision marked on edges outside \(P\),
including the simultaneous use of \(p,q\). The old
cycle \(C\) becomes a Hamilton cycle \(C_X\) by replacing
the two subpaths
\[
g,a,z_1,z_2 \quad\hbox{and}\quad t,w,b,h
\]
with \(g,z_2\) and \(t,h\), respectively.
The complementary matching of \(C_X\) contains the
new square edges \(gh,z_2t\).

The designated common-face boundary ran through
\(g,a,b,h\), using the face matching chord \(ab\).
It now runs through the single matching edge \(gh\);
hence \(p,q\) remain cofacial and the number \(r\)
of other boundary matching chords is unchanged.
The selected alternating site-face arc and all
\(\ell\) residual squares are untouched. The former
gap slots \(g,h\) are now the endpoints of one
complete block \([g,h]_{C_X}\), whose interior
slots are \(z_2,\ldots,t\), numbering \(2K\).
All interblock gaps are empty. The compression
decreases that block's capacity from \(K\) to
\(K-1\), so \(\sigma'=1,T'=0\); equivalently it
deletes four main-segment vertices and gives
\[
 f'=f-4=4r+4.                                    \tag{5}
\]
The site expansion commutes with this disjoint
ladder replacement. Compressing the original
legal Barnette child by the same four-pole operation
therefore gives the legal site-expanded child of \(X\).
Note 212 applies to this gapless first-surplus
opening and supplies a Hamilton cycle of \(X\)
containing both \(p,q\). The four-pole routing
equivalence of Note 178 lifts that marked cycle
back to \(G\), since \(p,q\) lie outside \(P\).
Note 001 then lifts it through the original legal
site expansion. Finally Note 178 restores the
original residual-lobe lengths and the exterior
site marks. \(\square\)

Combined with Notes 264--265, a non-Hamiltonian
third-surplus positive-gap child with two vacancies
in one block can only have two singleton gaps
separated by a target-bearing vacancy block with
**seven** free interior slots. This is a necessary
restriction, not a construction of such a child.
