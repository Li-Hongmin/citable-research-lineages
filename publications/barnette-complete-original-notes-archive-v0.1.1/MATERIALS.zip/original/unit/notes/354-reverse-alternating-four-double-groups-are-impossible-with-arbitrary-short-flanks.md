> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Reverse alternating four-double groups are impossible with arbitrary short flanks

[Note 347](347-a-nested-four-double-swap-has-the-square-hamilton-signature.md)
settles the no-corridor \(J_3,J_1,J_3,J_1\) four-double word.
[Note 353](353-the-h1r-branch-closes-the-arbitrary-central-corridor-four-double-group.md)
and its upstream notes settle that word with any positive central
short-block corridor and no outer flanks.
Old-cycle reflection preserves this even orientation word, so the
reverse \(J_1,J_3,J_1,J_3\) word requires a separate argument.
The reverse word is impossible for every length of the central
corridor and both outer short flanks.

Work in the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group have even left and odd
right endports \(L,R\), and block order
\[
 S^{\mathrm L}_1,\ldots,S^{\mathrm L}_a,\;
 D_1,D_2,S_1,\ldots,S_q,D_3,D_4,\;
 S^{\mathrm R}_1,\ldots,S^{\mathrm R}_b,
 \qquad a,b,q\ge0,                                          \tag{1}
\]
where
\[
D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t),\qquad
S_u=(c_u,r_u,s_u,d_u),\quad
S^{\mathrm L/R}_u=
(c^{\mathrm L/R}_u,r^{\mathrm L/R}_u,
 s^{\mathrm L/R}_u,d^{\mathrm L/R}_u)                       \tag{2}
\]
occur in old-cycle order. Its four double blocks have
the common-face internal matching chords
\[
                  o_1k_1,\quad i_2e_2,\quad
                  o_3k_3,\quad i_4e_4,                    \tag{3}
\]
of types \(J_1,J_3,J_1,J_3\).

**Reverse-word exclusion theorem.** No three-connected
cubic bipartite plane graph has an ordinary target-free
free group satisfying (1)--(3), for any
\(a,b,q\ge0\). Consequently, among the two alternating
four-double words with no outer flanks and a central
corridor of arbitrary length, only \(J_3,J_1,J_3,J_1\)
can occur; every actual group of that orientation has
a spanning \(L\)--\(R\) route by Notes 347 and 349--353.

**Proof.** By [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
each edge of (3) is the only same-block free chord in
its block. By [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
all remaining free matching chords lie on the opposite
page and do not cross one another. Their free slots,
after removing the endpoints of (3), occur in the order
\[
\begin{split}
L;\quad (r^{\mathrm L}_u,s^{\mathrm L}_u)_{u=1}^{a};\quad
h_1,i_1,j_1,e_1;\quad
o_2,h_2,k_2,j_2;\quad
(r_u,s_u)_{u=1}^{q};\\
h_3,i_3,j_3,e_3;\quad
o_4,h_4,k_4,j_4;\quad
(r^{\mathrm R}_u,s^{\mathrm R}_u)_{u=1}^{b};\quad R.         \tag{4}
\end{split}
\]
Every opposite-page chord encloses an even number of
still-free slots: all those slots must pair with one
another inside it. A nonempty proper interval of
complete blocks closed under the complementary matching
would have only its two boundary old-cycle edges leaving,
contrary to three-connectivity.

The first even slot \(h_1\) has only three possible
mates:
\[
                         j_2,\qquad i_3,\qquad j_4.       \tag{5}
\]
The adjacent \(h_1i_1\) is an old-cycle edge and
\(h_1j_1\) is forbidden by chord isolation.
Among the remaining odd slots of (4), the chords
to \(o_2,r_u,j_3,o_4,R\), or to a right-flank
\(r^{\mathrm R}_u\), enclose odd numbers of
free slots. A chord from a left-flank
\(r^{\mathrm L}_u\) to \(h_1\) encloses
\(2(a-u)+1\) free slots and is likewise impossible.
The other slots have \(h_1\)'s colour.
Thus (5) is independent of \(a,b\).

If \(h_1j_2\), its interior contains
\(i_1,j_1,e_1,o_2,h_2,k_2\).
The odd slot \(i_1\) can meet only \(k_2\):
the candidates \(e_1,h_2\) enclose respectively
one and three free slots. Inside \(i_1k_2\),
\(j_1h_2,e_1o_2\) are forced.
Thus every matching chord of the complete-block
interval \(D_1,D_2\) stays inside it, a forbidden
two-edge cut. This excludes \(h_1j_2\) for all \(q\).

If \(h_1j_4\), every free slot of the complete-block
interval from \(D_1\) through \(D_4\), including
the short corridor, lies on or inside that chord.
No opposite-page matching edge can leave this
interval, even when outer short flanks are present.
The interval is matching-closed and gives a
two-edge cut.

Suppose \(h_1i_3\). Its first inner odd slot \(i_1\)
can meet only \(k_2\) or \(h_3\).
For any \(t\), \(i_1s_t\) encloses
\(2t+5\) free slots and is impossible;
the other candidate edges either have the wrong
colour or enclose an odd number of free slots.

We first exclude \(i_1h_3\). If \(j_1h_2\),
the pair \(e_1o_2\) is forced, leaving \(k_2\)
without an inner mate: \(k_2j_2\) is old and
each \(k_2r_t\) encloses \(2t-1\) free slots.
The only other possible mate of \(j_1\) is
some \(s_t\). Inside \(j_1s_t\), the even slot
\(e_1\) can meet \(o_2\) or an \(r_v\) with
\(v\le t\). The choice \(e_1o_2\) again
leaves \(k_2\) without an inner mate:
\(h_2j_2\) encloses \(k_2\), while any
\(h_2r_v\) leaves \(k_2\) facing only
the old edge \(k_2j_2\) or a parity-forbidden
\(k_2r_w\). The choice \(e_1r_v\)
closes the complete-block interval
\(D_2,S_1,\ldots,S_{v-1}\), a two-edge cut.
For \(q=0\) there is no \(s_t\), so the
first alternative alone applies.
Hence \(i_1h_3\) is impossible.

Therefore \(i_1k_2\), with its forced
inner pairs \(j_1h_2,e_1o_2\).
Inside \(h_1i_3\), the remaining slots
are \(j_2,(r_u,s_u)_{u=1}^{q},h_3\).
An edge \(j_2s_t\) encloses \(2t-1\)
free slots. Thus \(j_2h_3\) is forced.
If \(q\ge1\), every free slot of
\(S_1,\ldots,S_q\) lies inside \(j_2h_3\)
and must match within that proper
complete-block interval. Its two-edge
cut excludes this case.

It remains to consider \(q=0\), with
arbitrary outer flanks. All free slots
not yet used are
\[
L,\ (r^{\mathrm L}_u,s^{\mathrm L}_u)_{u=1}^{a},\
j_3,e_3,o_4,h_4,k_4,j_4,\
(r^{\mathrm R}_u,s^{\mathrm R}_u)_{u=1}^{b},\ R.          \tag{6}
\]
The right endport \(R\) has no viable mate
in the left flank: a chord to \(L\) or any
\(s^{\mathrm L}_u\) encloses a nonempty proper
interval of complete blocks containing
\(D_1,\ldots,D_4\), which would be
matching-closed. The candidate \(e_3R\)
closes \(D_4,S^{\mathrm R}_1,\ldots,
S^{\mathrm R}_b\). The candidate \(k_4R\)
encloses the odd number \(1+2b\) of free
slots. If \(h_4R\), the even slot \(k_4\)
has no inner mate: \(k_4j_4\) is old,
\(k_4r^{\mathrm R}_u\) encloses
\(2u-1\) free slots, and
\(k_4s^{\mathrm R}_u\) has the wrong colour.
Finally \(s^{\mathrm R}_uR\) with \(u<b\)
closes the complete short-block suffix
\(S^{\mathrm R}_{u+1},\ldots,
S^{\mathrm R}_b\).
Thus \(b=0\) is impossible; if \(b\ge1\),
\(s^{\mathrm R}_bR\) is forced.

After this boundary link, consider the
rightmost still-unmatched odd slot
\(r^{\mathrm R}_t\). The same exclusions
apply with the effective right boundary
at \(S^{\mathrm R}_t\):
\(e_3r^{\mathrm R}_t\) closes
\(D_4,S^{\mathrm R}_1,\ldots,
S^{\mathrm R}_{t-1}\);
\(h_4r^{\mathrm R}_t\) leaves \(k_4\)
without an inner mate; and
\(k_4r^{\mathrm R}_t\) encloses
\(2t-1\) free slots.
A chord from \(r^{\mathrm R}_t\)
to \(L\) or a left-flank
\(s^{\mathrm L}_u\) closes a
complete-block interval containing
\(D_1,\ldots,D_4\).
If it meets \(s^{\mathrm R}_u\)
for \(u<t-1\), it closes
\(S^{\mathrm R}_{u+1},\ldots,
S^{\mathrm R}_{t-1}\);
\(r^{\mathrm R}_ts^{\mathrm R}_t\)
is an old edge. Therefore for \(t>1\)
the only possible mate is
\(s^{\mathrm R}_{t-1}\), and for
\(t=1\) there is none. Starting from
\(t=b\), the forced links descend
to \(t=1\), a contradiction.
Every branch of (5) is excluded.
\(\square\)

The theorem concerns only the specified
ordinary alternating word in the selected
opening. Other internal chord words and
other opening types remain outside its
conclusion; it does not resolve
Barnette's conjecture. This is a
project-internal analytic proof, without
an external priority claim.
