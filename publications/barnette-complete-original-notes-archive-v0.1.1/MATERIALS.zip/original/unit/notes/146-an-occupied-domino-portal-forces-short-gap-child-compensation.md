> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An occupied domino portal forces short-gap child compensation

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
shows that unrestricted complete perfect-matching incidence does not force
short-gap ChildSupplement. This note identifies an exact local mechanism
which does force it. A bad \(11\)--\(00\) bond is compensated whenever its
surviving gate and the short edge form an occupied square opposite pair.
The proof is an exterior-independent equality of four-port complement
signatures.

## 1. The two-square portal

Use the interface-disjoint one-edge-gap setup of
[Note 139](139-a-one-edge-facial-gap-leaves-only-h-avoiding-11-00-bonds.md).
Let

\[
 b=M_{11}N_{00}
\tag{1}
\]

be a rooted parent bond, where the state-\(00\) endpoint \(N\) omits the
short edge

\[
 h=st.
\tag{2}
\]

Since the two endpoints lie in opposite surviving-gate sectors, write the
surviving gate as \(g_1=zw\), with \(g_1\in M\setminus N\).

Call (1) an **occupied domino portal** when

\[
 Q_g=s-z-w-t-s
\tag{3}
\]

is a facial square and

\[
 sz,wt\in N.
\tag{4}
\]

Thus \(h=st\) and \(g_1=zw\) are the opposite edges of \(Q_g\), while \(N\)
occupies its two lateral edges.

In the child, the short edge bounds the patch square

\[
 Q_h=s-\alpha-\beta-t-s,
\tag{5}
\]

where the canonical \(C_{00}\) lift \(\widehat N\) contains
\(\alpha\beta\). The two squares \(Q_g,Q_h\) share precisely \(h\); their
union is the four-port domino \(K\), with ports \(z,w,\alpha,\beta\).

## 2. Domino-neutralizer theorem

> **Theorem.** If a bad one-edge-gap parent bond has an occupied domino
> portal, then its gate-path sibling is a rooted child target. Consequently
> the complete child rooted family contains a new-cell bond.

The theorem itself does not require the separate legal-wide gate-face
hypothesis. It applies in particular inside the historical legal-wide
stratum.

### Proof

At \(z\), the matching \(N\) uses \(sz\), while \(M\) uses \(zw\); at
\(w\), the matching \(M\) again uses \(zw\), while \(N\) uses \(wt\).
The third incidences at \(z,w\) belong to neither matching. Hence the
component of

\[
 (M\mathbin\triangle N)-\{p,q\}
\tag{6}
\]

containing \(g_1\) is exactly

\[
 P_g=s-z-w-t.
\tag{7}
\]

The canonical child lift \(\widehat N\) contains

\[
 sz,\quad wt,\quad \alpha\beta
\tag{8}
\]

on the outer boundary

\[
 D=s-z-w-t-\beta-\alpha-s.
\tag{9}
\]

These three edges alternate with the other three edges of \(D\).
Therefore

\[
 S_g=\widehat N\mathbin\triangle D
\tag{10}
\]

is a child perfect matching. By (7), it is precisely the gate-path sibling:
it changes membership of \(g_1\) and changes the patch cell from
\(C_{00}\) to the corresponding cross cell.

It remains to prove rooted admission. Inside \(K\), the complement of
\(\widehat N\) is

\[
 \{h,g_1,s\alpha,t\beta\}.
\tag{11}
\]

It has no closed component and pairs the four ports as

\[
 (z,w)(\alpha,\beta):
 \qquad z-g_1-w,\qquad
 \alpha-s-h-t-\beta.
\tag{12}
\]

After the flip (10), the complement inside \(K\) is

\[
 \{h,sz,wt,\alpha\beta\}.
\tag{13}
\]

It again has no closed component and induces the same port pairing,

\[
 (z,w)(\alpha,\beta):
 \qquad z-s-h-t-w,\qquad
 \alpha-\beta.
\tag{14}
\]

Outside \(K\), the two child matchings are identical. Gluing either local
complement to that common exterior therefore produces the same number of
global complement cycles and the same partition of the exterior vertices
among those cycles. This is the boundary-pairing gluing lemma of
[Note 142](142-the-c8-plus-h-six-port-countermodel-has-no-common-completion.md),
specialized to four ports.

The canonical lift \(\widehat N\) is rooted, because its complement only
subdivides the two deleted site edges separately. Equations (12)--(14)
therefore imply that \(S_g\) is rooted with the same ordered root labels.
Finally, (9)--(10) show that \(\widehat N,S_g\) lie in opposite gate
sectors, differ by one alternating cycle, and one endpoint lies in a cross
cell. They form the required new-cell child bond. \(\square\)

The reflected statement holds when the other residual arc is the one-edge
gap.

## 3. Exact role in the legal-wide problem

The occupied portal is a sufficient condition, not a consequence of
legal-wide. The legal-wide hypothesis constrains the distinguished face
containing \(g_0,g_1\), whereas (3)--(4) constrain the second face of
\(g_1\) and the actual matching occupancy there. If either lateral edge in
(4) is absent from \(N\), the bad gate path can leave the square through a
third incidence and the signature equality (12)--(14) is no longer forced.

Thus the remaining complete-family implication has been reduced to the
following sharper alternative:

\[
\boxed{
\begin{minipage}{0.82\linewidth}
In a legal-wide complete-family-extreme decoration, must some bad bond have
an occupied domino portal, must another boundary-neutral local core replace
the domino, or must an unrelated child matching supply a new-cell bond?
\end{minipage}}
\tag{15}
\]

Note 146 proves the first alternative sufficient. It does not prove that
complete-family extremality or the odd wide-face arcs force any of the
three alternatives.

[Note 147](147-the-square-is-the-unique-boundary-neutral-occupied-face-portal.md)
shows that this exterior-independent mechanism is sharp in face length:
for a full alternating portal around any longer even face, the canonical
and sibling complement pairings are different. A longer face may still
work for a particular exterior, but it cannot replace the square in the
same local gluing argument.

[Note 148](148-gate-path-sibling-rootedness-has-an-exact-circuit-partition-criterion.md)
gives the complete exterior-dependent criterion.  The domino theorem is
its boundary-neutral special case: equality of the two local port
signatures preserves the entire complement partition, whereas the general
criterion only asks the resulting alternating quotient to have two
root-separated circuits.
