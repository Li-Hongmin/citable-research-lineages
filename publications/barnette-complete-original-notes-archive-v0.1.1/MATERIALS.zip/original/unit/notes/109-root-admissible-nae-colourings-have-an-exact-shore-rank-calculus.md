> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Root-admissible NAE colourings have an exact shore-rank calculus

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
translates the remaining preservation problem into bond-shore flips between
root-admissible NAE colourings of an actual plane triangulation. This note
gives an intrinsic description of root-admissibility and an exact formula
for its change under one shore flip.

The complement-cycle count is determined by the number of monochromatic
components. The root labels refine these components into a three-vertex
region tree. Across a shore, four colour-restricted component-gluing graphs
then give a necessary and sufficient rank-and-separation test for preserving
the rooted target condition.

## 1. Complement cycles and monochromatic components

Let \(T\) be a connected plane triangulation and let
\(\chi:V(T)\to\{0,1\}\) be NAE on every triangular face. Put

\[
V_i=\chi^{-1}(i),\qquad T_i=T[V_i],\qquad c_i=c(T_i).
\tag{1}
\]

Let \(F_\chi\) be the primal subgraph dual to the bichromatic edges of
\(T\). Every triangular face has exactly two bichromatic edges, so every
primal vertex has degree two in \(F_\chi\). Thus \(F_\chi\) is the
spanning two-factor complementary to the perfect matching encoded by
\(\chi\). Write \(k(\chi)\) for its number of cycles.

Let \(H=T_0\mathbin{\dot\cup}T_1\) be the spanning monochromatic-edge
subgraph. If \(n=|V(T)|\), then \(T\) has \(2n-4\) triangular faces.
Counting the unique monochromatic edge in every face gives

\[
|E(H)|=n-2.
\tag{2}
\]

For a possibly disconnected spanning plane graph,

\[
f(H)=|E(H)|-|V(H)|+1+c(H).
\tag{3}
\]

The components of the complementary dual
\((E(T)\setminus E(H))^*\) correspond to the faces of \(H\). This
complementary dual is exactly \(F_\chi\), while
\(c(H)=c_0+c_1\). Equations (2)--(3) therefore give

\[
\boxed{k(\chi)=c(T_0)+c(T_1)-1.}
\tag{4}
\]

No Eulerian or 4-connected hypothesis is needed for (4).

## 2. The labelled region tree

Each cycle of \(F_\chi\) has one monochromatic component on either side.
Make a bipartite multigraph \(\mathcal R_\chi\) whose vertices are the
components of \(T_0,T_1\), with one edge for each cycle of \(F_\chi\)
joining its two side components. It is connected by planarity. Equation
(4) gives

\[
|E(\mathcal R_\chi)|=|V(\mathcal R_\chi)|-1,
\]

so

\[
\boxed{\mathcal R_\chi\text{ is a tree}.}
\tag{5}
\]

Let the fixed primal root edge \(e=rs\) belong to the matching, and write
\(e^*=uv\). The dual edge \(uv\) is monochromatic; suppose its colour is
\(i\). Its incident triangles are

\[
uvx_r,\qquad uvx_s,
\tag{6}
\]

where \(x_r,x_s\) have colour \(1-i\). Let \(K\) be the component of
\(T_i\) containing \(uv\), and let \(L_r,L_s\) be the components of
\(T_{1-i}\) containing \(x_r,x_s\). The primal root endpoint \(r\) lies
on the complement cycle represented by \(KL_r\), and \(s\) lies on the
cycle represented by \(KL_s\).

Consequently

\[
\boxed{
\chi\text{ is root-admissible}
\iff
c_0+c_1=3\text{ and }L_r\ne L_s.}
\tag{7}
\]

When (7) holds, \(\mathcal R_\chi\) is the labelled three-vertex path

\[
L_r-K-L_s.
\tag{8}
\]

Thus the component total records the two complement cycles, while the two
ordered leaves retain the root separation. The scalar equation
\(c_0+c_1=3\) alone is insufficient.

## 3. Four shore-gluing graphs

Let \(\varnothing\ne W\subsetneq V(T)\), put
\(\bar W=V(T)\setminus W\), and let

\[
\chi'=\chi\mathbin\triangle W.
\tag{9}
\]

For \(a,b\in\{0,1\}\), define \(Q_{ab}=Q_{ab}(\chi,W)\) as follows.
Its left vertices are the components of \(T[V_a\cap W]\), its right
vertices are the components of \(T[V_b\cap\bar W]\), and every shore
edge with endpoint colours \(a,b\) joins the corresponding component
vertices. Retain isolated component vertices. Write

\[
\kappa_{ab}=c(Q_{ab}),\qquad
\rho_{ab}=|V(Q_{ab})|-\kappa_{ab}.
\tag{10}
\]

Contracting the monochromatic fragments on each shore gives

\[
\begin{aligned}
c(T_0)&=\kappa_{00},&c(T_1)&=\kappa_{11},\\
c(T'_0)&=\kappa_{10},&c(T'_1)&=\kappa_{01}.
\end{aligned}
\tag{11}

All fragment vertices occur once on either side of the flip. Hence (11)
is equivalent to the exact rank-transfer identity

\[
\boxed{
\bigl(c(T'_0)+c(T'_1)\bigr)-\bigl(c(T_0)+c(T_1)\bigr)
=(\rho_{00}+\rho_{11})-(\rho_{10}+\rho_{01}).}
\tag{12}
\]

By (4), the right-hand side is also the change in the number of primal
complement cycles.

## 4. Exact preservation of the root labels

Assume \(\chi\) is root-admissible, \(\chi'\) is NAE, and the root
matching edge is retained. The last condition is

\[
e^*\notin\delta_T(W).
\tag{13}
\]

The vertices \(u,v\) then lie on the same shore. NAE in the two triangles
(6), both before and after the flip, forces \(x_r,x_s\) onto that shore as
well.

After the flip, the monochromatic graph of the colour opposite to \(uv\)
is one of the two cross-colour gluing graphs \(Q_{10},Q_{01}\). Denote it
by \(Q_{\mathrm{opp}}\), with \(x_r,x_s\) marking its two root-side
fragments. Combining (7) and (12) gives the per-flip criterion

\[
\boxed{
\chi'\text{ is root-admissible}
\iff
\begin{cases}
\rho_{00}+\rho_{11}=\rho_{10}+\rho_{01},\\
x_r,x_s\text{ lie in distinct components of }Q_{\mathrm{opp}}.
\end{cases}}
\tag{14}
\]

The first line preserves the total of three monochromatic components; the
second preserves the labelled root pairing. Both are necessary.

## 5. Consequence for the split-bond lemma

If \(\delta_T(W)\) is a bond, then \(T[W]\) and \(T[\bar W]\) are
connected. This does not determine the four ranks in (12): shore
connectivity may use internal bichromatic edges, whereas \(\rho_{ab}\)
measures how colour-restricted fragments are glued across the shore. The
alternation of \(\delta_T(W)^*\) also does not determine whether the two
root fragments remain separated.

Therefore the rooted split-bond lemma of Note 108 is equivalent to finding
a new-cell colouring and a bond shore through \(g_1^*\) that satisfies
(14). The remaining implication is precisely

\[
\boxed{
\text{actual triangulation split + parent kill cover}
\Longrightarrow
\text{labelled child shore-rank transfer (14)}.}
\tag{15}
\]

Equation (15) is still unproved. The result replaces the former global
two-factor test by an exact four-rank equality and one labelled component
separation test. A proof must extract both from the common actual split
incidence; bondness alone is insufficient.
