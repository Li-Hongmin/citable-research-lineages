> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every tight gapless first-surplus opening has a Hamiltonian child

[Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)
settles the tight, gapless first-surplus branch when its
sole eligible vacancy is in a face-chord block. At an outer
site block, the initial or final target pairs can be
peeled by [Note 186](186-boundary-square-traps-either-peel-or-force-a-hamiltonian-child.md).
The reduced free matching has one forced detour of the same
kind, with the two extra free slots now at the end of the
main segment.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\)
avoiding the disjoint cofacial matching site edges
\(q=xy,p=uv\). Compress a selected all-square opening to
one residual square per lobe as in Note 178. Assume it has
\(\ell,r\ge1\), no interblock gaps, and \(f=4r+4\).
Assume all target positions are tight:
\(R_\ell\) is the first interior slot of \(B_0\),
\(L_1\) the final interior slot of \(B_{r+1}\), and
\(L_jR_{j-1}\in E(C)\) for every \(j\ge2\).

**Tight gapless Hamilton theorem.** The parent has a
Hamilton cycle containing both \(p,q\). Hence its legal
site-expanded child is Hamiltonian. The conclusion holds
for arbitrary positive lengths of the original square-trap
lobes.

**Proof.** Note 197 gives exactly one vacant eligible even
slot. If it lies in a face-chord block, Note 209 supplies
the marked parent Hamilton cycle. Reverse the main segment
and exchange the site and lobe labels if necessary, so
the vacancy instead lies in the left site block
\(B_0=[x,y]_C\), at interior position \(2m\).

Every earlier eligible slot of \(B_0\) is occupied by a
successive nonfinal \(L\)-target, followed immediately
by the next \(R\)-target. Apply Note 186's simple left
inverse \(m-1\) times to peel those boundary lobes.
Each inverse is simple: until the vacancy reaches
position 2, the vertex after the removed \(L\)-target
is still inside \(B_0\), rather than \(y\). The lobe
count decreases, while \(r,f\), gaplessness, tight
target order and the Hamilton decision of the legal
child are preserved. The resulting opening has its
vacancy at position 2 of \(B_0\).

Write the reduced \(B_0\)'s first slots as
\(R_\ell,s,t,\ldots\), where \(s\) is vacant and
\(t\) is its immediately following free odd slot.
If \(B_0\) had more than four interior slots, its
position 4 would be the occupied target \(L_\ell\).
The even slot \(s\) could not be matched: its only
free odd slot before that target is the adjacent
\(t\); all later free odd slots outside \(B_0\)
would make a cross-block chord straddling \(L_\ell\),
which Note 203 forbids. Thus the reduced block has
exactly four interior slots
\[
B_0: R_\ell,s,t,e_0.
\tag{1}
\]
If \(B_1\) had more than two interior slots, its
second slot would be \(L_\ell\). Then the free odd
slot \(t\) would have only its adjacent neighbours
\(s,e_0\) as possible free even mates before that
target; a mate after it would be a forbidden
cross-block chord. Hence \(B_1\) is short.

Every other face block \(B_j\) has free first and
last slots \(o_j,e_j\); the final site block has
the free first slot \(o_{r+1}\). A long normal
block's occupied target run is a matching barrier.
Before its first \(L\)-target the number of free
main slots is \(2j+2\) for a face block \(B_j\),
or \(2r+4\) for the final site block. These
counts are even. At most one same-block free edge
could cross the run, and a cross-block edge would
straddle an escape target, contrary to Note 203.
Matching parity excludes the one possible crossing.
Thus the free slots split into groups; every ordinary
group follows the forced short-block chain from
Note 208.

The initial exceptional group ends at the first
normal target run or at the free slot of the final
site block. It has free-slot order
\[
s,t,e_0,o_1,e_1,\ldots,e_{b-1},o_b,
\qquad 2\le b\le r+1.
\tag{2}
\]
All its free matching edges join different blocks,
because \(st,te_0\) and every short-block pair
\(o_je_j\) are old-cycle edges, while \(s,e_0\)
have the same colour. Note 193 puts the edges in
one opposite-side disk, where they are noncrossing.

The even slot \(s\) cannot match its adjacent
\(t\), so it matches some \(o_d\), \(2\le d\le b\).
Indeed, \(s o_1\) would enclose only the adjacent
free pair \(t,e_0\), which cannot be in \(M\).
Inside \(s o_d\), the odd slot \(t\) must match
\(e_{d-1}\). If it matched \(e_j\) with \(j<d-1\),
the trailing complete short blocks
\(B_{j+1},\ldots,B_{d-1}\) would have all their free
slots matched inside: one such block gives a forbidden
old-cycle edge, and two or more give a matching-closed
proper consecutive interval and a two-edge cut.
Noncrossing then forces the enclosed chain
\(e_0o_1,e_1o_2,\ldots,e_{d-2}o_{d-1}\),
and every later free-slot group also follows the
ordinary chain. Therefore the complete free matching
is
\[
M_{\rm free}=
\{e_jo_{j+1}:0\le j\le r,\ j\ne d-1\}
\cup\{e_{d-1}t,\ s o_d\}.
\tag{3}
\]

Let \(A\) be the even-starting matching of \(C\)
indexed from \(x\). Tight targets and residual
squares form the \(x\)-to-\(v\) path (4) of
Note 207 in \(M\cup A\). All other vertices
form that note's free path (5), except that
\(e_{d-1}o_d\) is replaced by
\(e_{d-1},t,s,o_d\). Formula (3) supplies the
two matching edges and \(ts\in A\). The paths
meet only at \(x,v\), cover every vertex, and
form a Hamilton cycle through \(xy,uv\).

Finally reverse the \(m-1\) simple peels. At each
left inverse, the reduced parent Hamilton cycle
uses \(q=xy\). At \(x\) it therefore uses exactly
one of the two restored incident edges \(xB,xz\).
If it uses \(xB\), replace that edge by
\(x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,B\). If it uses \(xz\), replace
that edge by \(x,\beta_\ell,\delta_\ell,R_\ell,
L_\ell,\gamma_\ell,\alpha_\ell,z\). These are
Note 185's two spanning one-path routings for the
six-vertex patch. Each retains \(q\), while \(p\) is untouched.
The restored parent cycle still contains both site
edges. The reflected argument handles a vacancy in
\(B_{r+1}\). Note 001 lifts the marked cycle through
the site expansion, and Note 178 restores the
original lobe lengths. \(\square\)

This theorem decides the no-target-order-defect,
no-gap branch at the first free-vertex surplus
\(f=4r+4\). It does not decide the endpoint or
transition-defect branches, the two-gap-slot branch,
or openings with nonsquare residual cycles.
