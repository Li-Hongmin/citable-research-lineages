> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Rainbow vacancy cycles absorb at every gapless surplus

[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
absorbs the alternating square made by two target-free
vacancy pairs. The same ladder switch absorbs one alternating
cycle through any number of distinct target-free vacancy
blocks. With three such blocks, planarity forces precisely
this cycle whenever the vacancy slots pair only among
themselves.

Let \(G\) be a Barnette parent with an old Hamilton cycle
\(C\) avoiding disjoint cofacial matching site edges
\(q_0=xy,p=uv\). Select a compressed all-square facial
opening with \(\ell,r\ge1\), no interblock gaps, and tight
target order as in Note 215. Suppose its \(s=q\ge2\)
eligible vacancies lie in distinct target-free internal
face-chord blocks
\[
 B_{k_1}<B_{k_2}<\cdots<B_{k_q},
 \qquad 1\le k_1<\cdots<k_q\le r.                 \tag{1}
\]
Write the four free interior slots of \(B_{k_t}\) as
\(o_{k_t},H_t,I_t,e_{k_t}\) in old-cycle order.
Suppose all \(2q\) slots \(H_t,I_t\) match among themselves,
and that their matching is the *rainbow cycle*
\[
 H_1I_q,\qquad I_tH_{t+1}\quad(1\le t<q).
                                                        \tag{2}
\]
Every edge in (2) is cross-block, hence on the side of \(C\)
opposite the designated common face. In particular all
vacancy blocks lie in one free group, since an edge of
(2) cannot straddle an escape target by Note 203.

**Rainbow absorption theorem.** Under (1)--(2), the parent
has a Hamilton cycle containing both site edges \(xy,uv\).
Its legal site-expanded child is Hamiltonian. This holds
for arbitrary distances between the vacancy blocks,
arbitrary \(q\ge2\), and arbitrary positive original
square-trap lobe lengths.

**Proof: ordinary chain.** Every ordinary free slot is
matched to another ordinary free slot because (2) uses all
vacancy slots. Write \(e_0\) for the final free slot of
\(B_0\), \(o_{r+1}\) for the first free slot of
\(B_{r+1}\), and \(o_i,e_i\) for the first and final
free slots of an internal block. We show inductively that
\[
 e_i o_{i+1}\in M,\qquad 0\le i\le r,
                                                        \tag{3}
\]
where \(M=E(G)\setminus E(C)\).

Assume the links before \(e_i\) are fixed. Every earlier
ordinary odd slot is already used. The possible ordinary
odd mate of \(e_i\) is therefore \(o_{i+1}\) or some
\(o_j\) with \(j\ge i+2\); the same-block \(o_i\) is
already used when \(i\ge1\). If \(e_io_j\in M\) for
\(j\ge i+2\), it encloses the nonempty complete block
interval \(B_{i+1},\ldots,B_{j-1}\). An escape target
inside would contradict Note 203. Otherwise every
free matching edge from that interval to outside it would
interlace \(e_io_j\) on the opposite side; a face-side
free chord stays within one complete block. The fixed
block-closing chords are internal as well. Thus this
proper consecutive interval would have only its two
boundary \(C\)-edges leaving it, contrary to
three-connectivity. Hence \(e_i o_{i+1}\) is forced.
The induction begins at \(e_0\), proving (3).

Let \(A\) be the even-starting matching of \(C\) used in
Note 196. Tight target order gives its fixed
target-and-square \(x\)-to-\(v\) path. Formula (3) gives
the ordinary free \(x\)-to-\(v\) path of Note 196,
which misses exactly the \(2q\) vacancy slots.
The edges of (2), together with
\(H_tI_t\in A\), form one alternating \(2q\)-cycle.

Put \(k=k_1,m=k_2\). If \(m=k+1\), replace the ordinary
free-path edge \(e_ko_m\) by
\[
 e_k,I_1,H_1,I_q,H_q,I_{q-1},H_{q-1},
       \ldots,I_2,H_2,o_m.                       \tag{4}
\]
The first and last edges of (4) are old-cycle edges.
The intervening edges alternate between \(A\) and (2);
equivalently, (4) uses every edge of the vacancy cycle
except \(I_1H_2\). It visits all \(2q\) vacancy slots
once and has the same endpoints as the removed edge.

If \(m>k+1\), the complete blocks
\(B_{k+1},\ldots,B_{m-1}\) are short and target-free,
since the two vacancies lie in one free group and
there is no third vacancy between the first two.
They form Note 217's even four-terminal ladder. Use
its disjoint spanning paths
\[
 P_L:a_{k+1}\longleftrightarrow o_{k+1},
 \qquad
 P_R:e_{m-1}\longleftrightarrow b_{m-1}.
\]
Replace the ordinary free-path segment from \(b_k\)
through that ladder to \(a_m\) by
\[
\begin{split}
 b_k,&\,a_{k+1}\xrightarrow{P_L}o_{k+1},e_k,
 I_1,H_1,I_q,H_q,\ldots,I_2,H_2,o_m,\\
 &e_{m-1}\xrightarrow{P_R}b_{m-1},a_m .
\end{split}                                             \tag{5}
\]
The joins at either end are exactly the standard
old-cycle and matching edges checked in Note 217(6);
the middle is (4). The ladder paths cover every
intermediate vertex once. Formula (5) has the same
external endpoints as the replaced segment and adds
all vacancy slots, including those in blocks after
\(B_m\), without repeating an ordinary vertex.

In either case the resulting free path is spanning and
disjoint from the target-and-square path except at
\(x,v\). Their union is a Hamilton cycle using \(xy,uv\).
Notes 001 and 178 give the legal child and longer
original lobes. \(\square\)

**Three-vacancy corollary.** Suppose \(q=3\) in (1),
and assume only that the six vacancy slots match among
themselves. All their edges join different blocks, so
they form a noncrossing matching in one disk. In the
slot order
\[
 H_1,I_1,H_2,I_2,H_3,I_3,
\]
each \(H_tI_t\) is an old-cycle edge and cannot lie in
\(M\). The mate of \(H_1\) cannot be \(I_2\): that
would leave the adjacent old-cycle pair \(H_3,I_3\).
Thus \(H_1I_3\in M\). Within it, \(I_1\) cannot
match \(H_3\), for that would leave the adjacent
\(H_2,I_2\). Noncrossing therefore forces
\(I_1H_2,I_2H_3\in M\), exactly (2). Hence every
opening in this three-vacancy profile is marked
Hamiltonian; no ordinary-chain hypothesis is needed.

**Realization at every length.** For every \(q\ge2\)
take \(r=q,\ell=1\), and let the old cycle traverse
\[
\begin{array}{ll}
B_0:&x,R_1,e_0,y,\\
B_j:&a_j,o_j,H_j,I_j,e_j,b_j\quad(1\le j\le q),\\
B_{q+1}:&u,o_{q+1},L_1,v,\\
\text{last arc}:&\alpha_1,\gamma_1,\delta_1,\beta_1,
                   \text{ returning to }x .
\end{array}                                             \tag{6}
\]
Take its complementary perfect matching to consist of
\(xy,uv,\alpha_1\beta_1,\delta_1R_1,\gamma_1L_1\),
all \(a_jb_j\), all standard links
\(e_jo_{j+1}\) for \(0\le j\le q\), and the
rainbow edges (2). Every pair has opposite old-cycle
parity, so the graph is cubic and bipartite. Draw
the site, face-block and square-closing chords on the
common-face side. On the other side,
\(\delta_1R_1\) encloses the free chords;
\(H_1I_q\) encloses the disjoint
\(I_tH_{t+1}\) and the internal standard chain
chords; the two boundary chain links are disjoint.
This is a plane embedding with cofacial site edges.

For three-connectivity, the matching-chord
interlacement graph contains the connected chain
\[
 xy-e_0o_1-a_1b_1-e_1o_2-\cdots-a_qb_q
 -e_qo_{q+1}-uv-\gamma_1L_1-\alpha_1\beta_1
 -\delta_1R_1-xy .
\]
Each rainbow edge meets this chain at a face-block
chord: \(H_1I_q\) interlaces \(a_1b_1\), and
\(I_tH_{t+1}\) interlaces \(a_tb_t\).
Thus the interlacement graph is connected. As in
Note 217, any two-edge cut of a cubic Hamiltonian
graph would bound a proper consecutive old-cycle
interval closed under the matching, contradicting
this connectedness. The graph is simple, cubic and
three-edge-connected, hence three-vertex-connected.
It is a Barnette parent of order \(6q+12\), with
\(f=6q+2=4r+2+2s\). The indicated site expansion
inside the common face is legal by the cut projection
of Note 217 and is Hamiltonian by the theorem.
This realizes every \(q\ge2\) without graph
enumeration. \(\square\)

The theorem treats the rainbow cycle matching, and the
three-vacancy corollary treats all internal vacancy
matchings for its stated profile. It does not classify
other \(q\ge4\) pairings, matchings with vacancy-to-ordinary
edges, multiple vacancies in one block, defective target
order, positive gaps, or nonsquare residual cycles.
The other vacancy-only pairings are treated in
[Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md).
