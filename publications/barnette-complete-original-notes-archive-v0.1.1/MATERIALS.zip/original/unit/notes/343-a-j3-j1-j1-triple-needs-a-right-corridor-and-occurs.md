> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A J3,J1,J1 triple needs a right corridor and occurs

[Note 342](342-a-j1-j1-j3-triple-is-impossible-with-arbitrary-short-corridors.md)
excludes one pair of nonalternating mixed orders at every
internal corridor length. The remaining order
\(J_3,J_1,J_1\) has a sharp positional restriction:
its first two double blocks are adjacent, while its
last two must be separated. A 44-vertex Barnette
graph realizes the first permitted lengths.

Use the compressed, gapless, tight-target all-square
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with exactly
three doubly vacant complete blocks
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),\qquad s=1,2,3,
                                                               \tag{1}
\]
in old-cycle order, carrying \(i_1e_1=J_3\),
\(o_2k_2=J_1\), and \(o_3k_3=J_1\).
Other complete blocks are short. There are \(p\ge0\)
short blocks between \(D_1,D_2\), \(q\ge0\) between
\(D_2,D_3\), and arbitrary outer short flanks.

**Position theorem.** In every such Barnette opening,
\(p=0\) and \(q\ge1\). The cross-block matching edge
\(j_1h_2\) is forced. These conclusions are sharp:
for every \(q\ge1\), one can take \(p=0\) and one
right outer short block in a \(40+4q\)-vertex
Barnette parent with a Hamilton cycle containing
both site edges; its legal site-expanded child is
Hamiltonian. The first parent has 44 vertices. Reflection
gives the corresponding statement for \(J_3,J_3,J_1\),
with the corridor on the opposite side.

**Forced position.** Chord isolation from
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
and the opposite-side rule of
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
give a noncrossing residual free matching. The residual
free slots of the three double blocks are
\[
(o_1,h_1,k_1,j_1),\quad
(h_2,i_2,j_2,e_2),\quad
(h_3,i_3,j_3,e_3),                                    \tag{2}
\]
with two odd/even free slots per intervening short block.

The even slot \(h_2\) can meet only \(j_1\) or \(i_3\).
Among the odd slots before it, \(o_1\) encloses
\(3+2p\) free slots and each odd short-corridor slot
encloses its block's second slot plus later corridor
pairs; \(j_1\) encloses \(2p\). Among the odd slots
after it, \(j_2\) encloses one slot, each odd slot
in the second corridor encloses \(3\) plus earlier
corridor pairs, \(i_3\) encloses \(4+2q\), and
\(j_3\) encloses \(5+2q\). An odd candidate in
a left outer flank encloses its block's second
slot, complete flank pairs, the four free slots
of \(D_1\), and \(2p\) corridor slots. A right
outer odd candidate or the endport encloses
\(7+2q\) remaining core slots plus complete pairs.
Thus only
\(j_1,i_3\) survive parity and chord isolation.

Suppose \(h_2i_3\). Its interior consists of
\(i_2,j_2,e_2\), all \(2q\) right-corridor free
slots, and \(h_3\). The odd slot \(i_2\) cannot
use the forbidden same-block \(i_2e_2\);
each possible even short-slot mate encloses
\(2t+1\) free slots for its block index \(t\).
Hence \(i_2h_3\) is
forced. If \(q=0\), the remaining \(j_2,e_2\)
would have to use their old-cycle edge. If \(q\ge1\),
the same noncrossing and two-edge-cut argument as
in [Note 332](332-two-j1-double-blocks-across-a-short-corridor-have-the-square-signature.md)
forces \(j_2\) to the final even corridor slot,
\(e_2\) to the first odd corridor slot, and all
ordinary links between. The block interval from
\(D_2\) through \(D_3\) is exactly Note 332's
induced square-equivalent \(Q_q\). Compressing it
preserves the Barnette opening and leaves exactly
one \(J_3\) double block, \(D_1\), amid short
blocks. The reflected single-double exclusion of
[Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md)
rules this out. Thus \(j_1h_2\) is forced.

Every short-block free slot between \(j_1\) and
\(h_2\) now lies inside \(j_1h_2\), so a positive
first corridor would be matching-closed and give
a two-edge cut. Therefore \(p=0\).
For \(q=0\), the three double blocks are consecutive
and the \(J_3,J_1,J_1\) order is excluded by
[Note 337](337-every-consecutive-j1-j3-three-double-group-reduces-to-a-square.md).
Hence \(q\ge1\). \(\square\)

**A sharp Barnette realization.** Put one short block
\(S=(c,r,s,d)\) between \(D_2,D_3\), and one right
outer short block \(T=(c',r',s',d')\) after \(D_3\).
Give an old Hamilton cycle the order
\[
x,R_1,w,y,D_1,D_2,S,D_3,T,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x .                         \tag{3}
\]
The face-side complementary-matching chords are
\[
xy,\ a_1b_1,\ i_1e_1,\ a_2b_2,\ o_2k_2,\ cd,\
a_3b_3,\ o_3k_3,\ c'd',\ uv,\ \alpha\beta,           \tag{4}
\]
and the opposite-side chords are
\[
\delta R_1,\ \gamma L_1,\ wo_1,\ h_1z,\
j_1h_2,\ k_1i_3,\ i_2h_3,\ j_2s,\ e_2r,\
j_3s',\ e_3r'.                                         \tag{5}
\]
Every vertex occurs in exactly one chord of (4)--(5).
All chords pair opposite old-cycle colours and avoid
old-cycle edges. Each page is noncrossing:
on the opposite page, \(\delta R_1\) surrounds
the other chords, \(h_1z\) surrounds
\(k_1i_3\supset\{j_1h_2,i_2h_3\}\) and
\(j_3s'\supset e_3r'\);
inside \(i_2h_3\), the pair \(j_2s\supset e_2r\)
is nested. The face chords are disjoint or nested
within their blocks. The site chords \(xy,uv\)
remain cofacial.

For three-connectivity, join two matching chords
when their endpoints alternate around (3). The
following dashes form a connected spanning subgraph
of this interlacement graph:
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1z-uv-\gamma L_1-\alpha\beta-\delta R_1,\\
a_1b_1-k_1i_3-i_1e_1-j_1h_2-a_2b_2-i_2h_3-
a_3b_3-j_3s'-c'd'-e_3r',\\
j_1h_2-o_2k_2,\qquad i_2h_3-o_3k_3,\qquad
a_2b_2-j_2s-cd-e_2r .
\end{gathered}                                             \tag{6}
\]
For example, \(o_2< i_2<k_2<h_3\) verifies the
\(i_2h_3-o_2k_2\) alternation, while
\(a_2<j_2<b_2<s\) and \(e_2<c<r<d\)
verify the last branch. Every other dash follows
directly from (3). A two-edge cut would close a
proper old-cycle interval under the matching and
disconnect this interlacement graph; the old Hamilton
cycle excludes bridges. Thus the 44-vertex simple
cubic bipartite plane graph is three-vertex-connected.
The residual square is \(\alpha\gamma\delta\beta\alpha\),
with escape edges \(\delta R_1,\gamma L_1\).
Together with the cofacial site edges, it gives the
stipulated compressed, gapless, tight-target opening.

The following \(o_1\)--\(h_1\) path visits every
vertex of \(D_1,D_2,S,D_3,T\) exactly once:
\[
\begin{split}
&o_1,a_1,b_1,a_2,o_2,h_2,i_2,k_2,j_2,e_2,b_2,
c,r,s,d,a_3,b_3,c',d',s',r',\\
&e_3,j_3,k_3,o_3,h_3,i_3,k_1,j_1,e_1,i_1,h_1 .
\end{split}                                                \tag{7}
\]
The non-old-cycle joins are \(a_1b_1,a_3b_3,c'd',
e_3r',o_3k_3,k_1i_3,i_1e_1\); the other joins
are consecutive old-cycle edges. Joining (7) to
\(wo_1,h_1z\) gives the second of two disjoint
spanning \(x\)--\(v\) paths,
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,w,\ (o_1\text{--}h_1\text{ path in (7)}),\
z,u,v .
\end{split}                                                \tag{8}
\]
Their union is a Hamilton cycle through \(xy,uv\).
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
therefore gives a Hamilton cycle in the legal
site-expanded child. \(\square\)

**Unbounded right corridors.** For any \(q\ge1\),
replace \(S\) in (3) by
\(S_t=(c_t,r_t,s_t,d_t)\), \(1\le t\le q\), in
old-cycle order. Keep every old exterior and
double-block chord, add all face chords \(c_td_t\),
and replace \(j_2s,e_2r\) in (5) by
\[
j_2s_q,\qquad e_2r_1,\qquad
s_tr_{t+1}\ (1\le t<q).                                 \tag{9}
\]
The opposite-side chords remain noncrossing;
all vertices are matched once to opposite colours.
In the connected interlacement certificate (6),
replace its branch \(a_2b_2-j_2s-cd-e_2r\) by
\[
a_2b_2,\ j_2s_q,\
(c_td_t,\ s_{t-1}r_t)_{t=q,q-1,\ldots,2},\
c_1d_1,\ e_2r_1 .                                      \tag{10}
\]
Consecutive entries in (10) denote endpoint
alternations. For \(q=1\), the parenthesized range
is empty and (10) is the original four-chord
branch. In particular,
\(s_{t-1}<c_t<r_t<d_t\) and
\(c_{t-1}<s_{t-1}<d_{t-1}<r_t\).
Thus the interlacement graph stays connected,
and the same Hamilton-cycle/two-edge-cut argument
proves three-connectivity for every \(q\).

In (7), replace the four-vertex old-cycle segment
\(c,r,s,d\) by
\[
  (c_t,r_t,s_t,d_t)_{t=1}^{q}.                           \tag{11}
\]
All new joins are old-cycle edges, so the resulting
path again covers every core vertex once. Formula
(8) therefore gives a Hamilton cycle through both
site edges for every \(q\), and Note 001 gives the
legal child's Hamilton cycle. The parent order is
\(40+4q\), attaining the required positive corridor
at every length. \(\square\)

This theorem determines the necessary corridor
position and gives a genuine unbounded boundary family.
It does not classify all matching types, prove that
every parent in this branch has a Hamilton cycle
through both site edges, or decide the general
Barnette conjecture. Other internal-chord types,
singly vacant blocks in the same group, target
defects, positive gaps and non-square residual cycles
remain outside its scope. The argument is project-internal;
no external priority or independent review is claimed.
