> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every isolated single–double corridor contains an exact square reduction

[Notes 382–389](389-delayed-single-double-returns-are-exact-square-reductions.md)
classify all complementary-matchings of a target-free group
consisting of one singly vacant block, one doubly vacant block,
and a positive short-block corridor with no short flanks.
Most branches already contain a four-terminal exact square
reduction. This note supplies the three remaining `to`
cutpoint poles and closes the entire isolated group.

Use the compressed, gapless, tight-target all-square selected
opening and old-cycle block order
\[
 V=(a,o,h,i,e,b),\quad S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),
 \quad D=(A,O,H,I,K,J,E,B),\qquad m\ge1.                 \tag{1}
\]
The ordinary target-free free group has exactly these
complete blocks and no short flanks. Other groups and
vacancies are unrestricted. Write \(t,z\) for its endports.

**Isolated single–double reduction theorem.** Every actual
matching of this group contains an induced disk patch,
strictly larger than a square, with precisely the square's
four spanning one-path and two spanning two-path terminal
states. Replacing that patch by its labeled square, or
reversing the replacement, preserves Barnette membership,
the selected opening outside the patch, and every exterior-
and attachment-marked Hamilton decision. If the double
block has \(J_0=OE,J_2=HJ\), the eight-vertex block \(D\)
itself is such a patch. If it has no internal free matching
chord, the entire \(14+4m\)-vertex interval (1) is such a
patch. The statement holds for either order of the vacant
blocks by old-cycle reflection.

Consequently no vertex-minimal non-Hamiltonian Barnette
graph contains any of these induced disk patches, regardless
of the rest of that graph. This intrinsic exclusion does not
assert that every Barnette graph contains a patch from this
list or admits the selected opening used to discover it.

**The remaining three pole families.** Note 382 excludes
\(J_1,J_3\) and couples \(J_0,J_2\). With no internal
double-block chord it leaves \(tJ\) or \(to\).
Notes 383 and 389 reduce the entire \(tJ\) branch.
Notes 385–386 classify the `to,hJ` and `to,hp_s`
subbranches; Note 388 reduces `to,hz`. The `to,hJ`
standard word is reduced by Note 381. It remains to
give exact signatures for these three words, with the
ordinary links \(q_jp_{j+1}\) omitted at the cutpoints
\(r\), \(\{r,u\}\), and \(\{s-1,r,u\}\), respectively:
\[
\begin{array}{c|l|l}
\text{family}&\text{internal free matching chords}
 &\text{cutpoint ranges}\\
T^1&hJ,iK,ep_1,q_rI,p_{r+1}H,q_mO
 &1\le r<m\\
T^2&hJ,iq_r,ep_1,p_{r+1}K,q_uI,p_{u+1}H,q_mO
 &1\le r<u<m\\
T^3&hp_s,iq_{s-1},ep_1,q_rJ,p_{r+1}K,q_uI,
     p_{u+1}H,q_mO
 &2\le s\le r<u<m.
\end{array}                                               \tag{2}
\]
Their complete free matching also includes \(to,Ez\).
In each family the whole interval (1) has degree-two
terminals in disk order \((a,o,E,B)\). Let \(P_1,P_2,P_3\)
be the smallest cores of the three families:
\[
\begin{array}{c|c|l}
P_1&(m,r)=(2,1)&hJ,iK,ep_1,q_1I,p_2H,q_2O\\
P_2&(m,r,u)=(3,1,2)&hJ,iq_1,ep_1,p_2K,q_2I,p_3H,q_3O\\
P_3&(m,s,r,u)=(4,2,2,3)&hp_2,iq_1,ep_1,q_2J,
                          p_3K,q_3I,p_4H,q_4O.
\end{array}                                               \tag{3}
\]

**Six-state core certificates.** In each core the full
old-cycle path from \(a\) to \(B\) is the \(aB\) state.
The \(oE\) state is the appropriate explicit spanning
route of Note 385, equation (7), for \(P_1,P_2\), and
Note 386, equation (6), for \(P_3\). The other two
one-path states are listed below. Commas denote
consecutive path vertices.

For \(P_1\):
\[
\begin{array}{c|l}
ao& a,b,e,i,K,I,q_1,p_1,c_1,d_1,c_2,p_2,H,O,
       q_2,d_2,A,B,E,J,h,o\\
EB& E,J,h,o,a,b,e,i,K,I,q_1,p_1,c_1,d_1,
       c_2,p_2,H,O,q_2,d_2,A,B
\end{array}                                               \tag{4}
\]
Its two spanning two-path states are
\[
\begin{array}{c|l}
\{ao,EB\}&(a,o);\quad
 (E,J,h,i,K,I,q_1,p_1,e,b,c_1,d_1,c_2,p_2,
                         H,O,q_2,d_2,A,B)\\
\{aB,oE\}&(o,h,J,E);\quad
 (a,b,e,i,K,I,q_1,p_1,c_1,d_1,c_2,p_2,
                         H,O,q_2,d_2,A,B)
\end{array}                                               \tag{5}
\]

For \(P_2\):
\[
\begin{array}{c|l}
ao& a,b,e,p_1,c_1,d_1,q_1,i,h,J,E,B,A,O,q_3,d_3,
       c_3,p_3,H,I,q_2,d_2,c_2,p_2,K,o\\
EB& E,J,h,o,a,b,c_1,p_1,e,i,q_1,d_1,c_2,p_2,K,I,
       q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B
\end{array}                                               \tag{6}
\]
Its two spanning two-path states are
\[
\begin{array}{c|l}
\{ao,EB\}&(a,o);\quad
 (E,J,h,i,q_1,p_1,e,b,c_1,d_1,c_2,p_2,K,I,
                         q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B)\\
\{aB,oE\}&(o,h,J,E);\quad
 (a,b,e,i,q_1,p_1,c_1,d_1,c_2,p_2,K,I,
                         q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B)
\end{array}                                               \tag{7}
\]

For \(P_3\):
\[
\begin{array}{c|l}
ao& a,b,e,i,q_1,p_1,c_1,d_1,c_2,d_2,c_3,p_3,K,I,
       q_3,d_3,c_4,p_4,H,O,q_4,d_4,A,B,E,J,q_2,p_2,h,o\\
EB& E,J,q_2,p_2,h,o,a,b,c_1,p_1,e,i,q_1,d_1,
       c_2,d_2,c_3,p_3,K,I,q_3,d_3,c_4,p_4,H,O,
       q_4,d_4,A,B
\end{array}                                               \tag{8}
\]
Its two spanning two-path states are
\[
\begin{array}{c|l}
\{ao,EB\}&(a,o);\quad
 (E,J,q_2,p_2,h,i,q_1,p_1,e,b,c_1,d_1,c_2,d_2,
   c_3,p_3,K,I,q_3,d_3,c_4,p_4,H,O,q_4,d_4,A,B)\\
\{aB,oE\}&(o,h,p_2,q_2,J,E);\quad
 (a,b,e,i,q_1,p_1,c_1,d_1,c_2,d_2,c_3,p_3,K,I,
   q_3,d_3,c_4,p_4,H,O,q_4,d_4,A,B)
\end{array}                                               \tag{9}
\]
Every row in (4)–(9) covers its core exactly once.
Every consecutive pair is an old-cycle edge, a face
chord, or one of the matching chords in (3). In the
two-path rows the semicolon separates disjoint paths.
The four one-path endpoint pairs are exactly the
opposite-colour pairs: \(a,E\) have one colour and
\(o,B\) the other. The third two-path pairing would
interlace the four disk terminals. Therefore each
core has the complete square signature.

**Lifting the cutpoints.** The ordinary-link short-block
runs are induced even-column ladders, each with exactly
four distinct attachments. Their positive-length lists are
\[
\begin{array}{c|l}
T^1&(S_1,\ldots,S_r),\ (S_{r+1},\ldots,S_m)\\
T^2&(S_1,\ldots,S_r),\ (S_{r+1},\ldots,S_u),
                         \ (S_{u+1},\ldots,S_m)\\
T^3&(S_1,\ldots,S_{s-1}),\ (S_s,\ldots,S_r),
     \ (S_{r+1},\ldots,S_u),\ (S_{u+1},\ldots,S_m).
\end{array}                                               \tag{10}
\]
Note 178 replaces each ladder by one square, preserving
all four labeled attachments and every spanning one- or
two-path terminal state in both directions. The successive
compressions send the words (2) to their cores (3), while
preserving the cyclic order of the outer terminals.
Thus the six outer states lift to every parameter word.
Parity and disk order exclude further states.

**Barnette-class comparison.** Cap \((a,o,E,B)\) by
a fresh square in cyclic order \((t_B,t_E,t_o,t_a)\),
attaching \(Bt_B,Et_E,ot_o,at_a\). The full old-cycle
path of (1), followed by \(t_B,t_E,t_o,t_a,a\), is a
Hamilton cycle of the \((18+4m)\)-vertex cap. Its
complementary matching consists of the disjoint face
chords \(ab,c_jd_j,AB,t_Bt_a\), the word (2), and
\(ot_o,Et_E\). The face chords occupy one page; the
word and cap attachments are nested or disjoint on the
other. Every chord joins opposite Hamilton-cycle parities.
The cap is simple, cubic, bipartite and plane.

Its matching-chord interlacement graph is connected.
Put \(F_0=ab,F_j=c_jd_j,F_D=AB,F_T=t_Bt_a\).
Both \(ot_o,Et_E\) interlace \(F_T\), the former
interlaces \(F_0\), and the latter interlaces \(F_D\).
For \(T^1,T^2\), \(hJ\) joins \(F_0,F_D\);
the other bridge chords and surviving ordinary links
join every \(F_j\) to them. For \(T^3\), \(hp_s\)
joins \(F_0,F_s\), the links from \(s\) to \(r\)
join \(F_s\) to \(F_r\), and \(q_rJ\) joins
\(F_r,F_D\); the remaining bridge chords and
links connect the other \(F_j\). Every matching
chord interlaces at least one \(F\), so the whole
interlacement graph is connected. A two-edge cut
in a cubic Hamiltonian graph would isolate a
proper old-cycle interval closed under its
complementary matching and disconnect this graph.
The Hamilton cycle excludes bridges. Hence the
cap is three-vertex-connected.

The uncapped pole remains connected after one vertex
deletion. Every block and every standard-link run stays
connected after such a deletion. In \(T^1\), \(V\)
meets \(D\) by the disjoint edges \(hJ,iK\); the
first run meets \(V\) by \(bc_1,ep_1\), and the
last meets \(D\) by \(p_{r+1}H,q_mO\). For \(T^2\),
\(V\) meets \(D\) by \(hJ\), and meets the first
run by \(bc_1,ep_1,iq_r\); that run meets the
middle run by \(d_rc_{r+1}\), and the middle
meets \(D\) by the disjoint edges \(p_{r+1}K,q_uI\).
One deletion cannot remove both the direct \(V\)--\(D\)
edge and the entire route through the first and middle
runs. The last run meets \(D\) by \(p_{u+1}H,q_mO\).
For \(T^3\), the first run meets \(V\) by
\(bc_1,ep_1,iq_{s-1}\); the second meets \(V\)
by \(hp_s\) and \(D\) by \(q_rJ\); the third
meets \(D\) by \(p_{r+1}K,q_uI\), and the fourth
by \(p_{u+1}H,q_mO\). The first and second runs
also meet through \(d_{s-1}c_s\), while the
second and third meet through \(d_rc_{r+1}\).
The alternative joins at each of these two boundaries
have disjoint endpoints; a single deletion leaves a
connection of every run to the rest. Finally \(V-v\)
and \(D-v\) are connected cycles, so \(P-v\) is
connected in all three families.

Since the cap is three-connected, deleting any two
pole vertices cannot leave a component with no
surviving terminal. The square has the same one-
and two-deletion properties. The four-attachment
comparison of [Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore proves that the whole-pole replacement
preserves three-connectivity in both directions.
Terminal colours and cyclic disk order preserve
bipartiteness and planarity, and the six-state
signature preserves exterior-marked Hamilton cycles.
The replacement square has old path \(a,o,E,B\),
face chord \(aB\), and free end links \(to,Ez\),
so it is one short target-free block in the
selected opening. \(\square\)

**Exhaustion.** If \(D\) has \(J_0,J_2\),
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md)
reduces \(D\) alone. Otherwise Note 382 excludes all
internal free chords. In the `tJ` branch, Note 383
reduces the \(hI\) words and Note 389 reduces the
\(hp_s\) words. In the `to` branch, Note 385's
standard word is reduced by Note 381, its other
`hJ` words by the first two families above, the
`hp_s` words by the third, and the `hz` words
by [Note 388](388-outer-return-single-double-poles-have-the-exact-square-signature.md).
Note 386 excludes the other possible mates of \(h\).
These are all actual matching branches by Notes 382–387.
Each reduction strictly decreases the number of vertices
and preserves Barnette membership and Hamilton status,
which proves the minimal-counterexample assertion.

**Standard short flanks.** In every `to,hJ` or
`to,hp_s` whole-pole reduction above, the terminal
pairs \(ao\) and \(EB\) are actual edges. The pole
also has the one- and two-deletion properties proved
above. Therefore [Note 367](367-square-signature-four-poles-are-closed-under-standard-short-buffers.md)
adds any number of standard short blocks at either
flank while preserving the exact square signature,
Barnette membership and exterior-marked Hamilton
decisions. The `to,hz` poles of Note 388 have the
adjacent left pair \(ao\), so the same argument adds
arbitrary standard left flanks. The `tJ` poles of
Notes 383 and 389 have the adjacent right pair
\(EB\), so it adds arbitrary standard right flanks.
This corollary concerns those specified standard
links; it does not classify nonstandard flank returns.

The main classification assumes the chosen compressed,
gapless, tight-target all-square opening and an isolated
single–double group with no short flanks; the buffer
corollary admits only the stated standard flanks. It does
not prove that every Barnette graph has such an opening,
cover arbitrary flank matchings or other vacancy group
shapes, or resolve the
general Barnette conjecture. It makes no external
priority claim. This is a project-internal analytic
proof without local graph recomputation or independent
review.
