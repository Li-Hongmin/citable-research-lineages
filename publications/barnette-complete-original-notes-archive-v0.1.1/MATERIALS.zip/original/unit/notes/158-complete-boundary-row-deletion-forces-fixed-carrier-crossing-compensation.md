> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Complete boundary-row deletion forces fixed-carrier crossing compensation

[Note 157](157-hamilton-parity-does-not-force-rooted-crossing-compensation.md)
leaves a strict one-crossing atom model at the annular cut of the fixed
[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md)
carrier.  The atom model respects every Hamilton-cycle parity relation and
every carrier-side join and bond atom used there.  It is nevertheless not
the boundary-row family of a graph.  The missing condition is elementary:
the distinguished state-empty row contains an undeleted square edge, and
deleting that edge produces a compulsory clean row.  At the fixed carrier
this row gives two additional mixed bonds.  Hence no annular factor,
regardless of its order, can turn the isolated pair of Note 154 into a
one-crossing complete rooted family.

## 1. The forced deletion row

Let a four-port factor contain the square

\[
 Q=b_0b_1b_2b_3b_0,
 \qquad q_i=b_ib_{i+1}
\]

with indices modulo four, and put

\[
 B^-=B-\{q_0,q_2\}.
\]

A boundary row is a matching of \(B^-\) covering every nonport vertex; its
state is the set of uncovered ports.  Suppose that the complete boundary-row
family contains a row \(N_0\) satisfying (T0): \(N_0\) has empty state and

\[
 B^- -N_0=P_{01}\mathbin{\dot\cup}P_{23},
\tag{1}
\]

where \(P_{ij}\) is a path with port endpoints \(b_i,b_j\).  In particular,
the complement is clean and the two paths in (1) contain every vertex of
\(B^-\).

Each port has complement degree one.  If \(q_1\notin N_0\), then
\(q_1=b_1b_2\) is the unique complement edge incident with each of
\(b_1,b_2\).  It is therefore an entire \(12\)-path component, contradicting
the pairing \(01\mid23\) in (1).  Thus \(q_1\in N_0\); the same argument
also gives \(q_3\in N_0\).

Define

\[
 R_1=N_0-\{q_1\}.
\tag{2}
\]

This is another actual boundary row.  Its state is
\(A_1=\{1,2\}\), and

\[
 B^- -R_1=P_{01}\cup q_1\cup P_{23}
\tag{3}
\]

is one spanning \(03\)-path.  Hence \(R_1\) is clean, while its bond atom
with \(N_0\) is exactly

\[
 d_B(N_0,R_1)=12+0\text{ closed components}.
\tag{4}
\]

This conclusion uses only (T0) and completeness of the boundary-row family.
It is not a Hamilton-parity companion and cannot be omitted from a genuine
factor incidence system.

## 2. The two fixed-carrier joins

Use the Note 154 carrier cut with cyclic ports

\[
 (a_0,a_1,a_2,a_3)=(19,10,21,9)
\]

and surviving gate \(g_1=3\!-\!21\).  In the deterministic carrier-row
ordering of the fixed verifier,
four rows have the following properties:

\[
\begin{array}{c|c|c|c}
\text{row}&\text{state}&g_1\text{-sector}&\text{compatible factor atom}\\ \hline
K_2&\varnothing&1&01\mid23\\
K_{20}&\varnothing&1&01\mid23\\
K_{31}&A_1&0&03\\
K_{41}&A_1&0&03.
\end{array}
\tag{5}
\]

Their two relevant carrier bond atoms are

\[
 d_G(K_2,K_{31})
 =d_G(K_{20},K_{41})
 =12+0\text{ closed components}.
\tag{6}
\]

The facts in (5)--(6) are literal properties of the fixed order-\(22\)
carrier.  They follow by tracing its \(54\) complete carrier rows; the
promoted verification bundle reconstructs the rows, complement marks, gate
sectors and bond components directly from the graph6 encoding.

After gluing, the factor path in (4) and either carrier path in (6), together
with the two connector edges at ports \(1,2\), form one alternating cycle.
The gate sectors in (5) are opposite.  Therefore the complete spliced rooted
family contains the two distinct mixed bonds

\[
 \boxed{
 (K_2,N_0)\sim(K_{31},R_1),
 \qquad
 (K_{20},N_0)\sim(K_{41},R_1).
 }
\tag{7}
\]

## 3. Fixed-carrier annular compensation theorem

Suppose in addition that rows \(N_0,N_1\) satisfy (T0), (T1) and (TB), so
that the intended isolated bond survives as

\[
 (K_{10},N_0)\sim(K_{29},N_1).
\tag{8}
\]

The three edges in (7)--(8) have different joined endpoints.  Thus

\[
 \boxed{|E\Gamma_{g_1}|\ge3.}
\tag{9}
\]

In particular, no complete boundary-row family attached at the Note 154
carrier cut can preserve the designated bond while having exactly one
mixed single-cycle exchange.  This is independent of the size of the
factor and, beyond the stated four-port setup, does not use its planarity,
bipartiteness, simplicity, cubic Hamilton parity or brace status.

The four-row atom model of Note 157 fails for exactly one reason: it is not
closed under the compulsory deletion

\[
 N_0\longmapsto N_0-\{q_1\}.
\tag{10}
\]

Thus common matching incidence does force nonzero
rooted-join-times-opposite-sector-bond incidence at this carrier, and the
annular-factor counterexample route is closed completely.

## 4. Scope

Equation (9) is a theorem about the fixed carrier and cut of Note 154.  It
does not prove the unrestricted implication

\[
 \Gamma_{g_1}(\mathcal T_e)\ne\varnothing
 \Longrightarrow |E\Gamma_{g_1}(\mathcal T_e)|\ne1
\]

for every legal-wide root-square plane brace.  A counterexample based on a
different carrier, a nonannular replacement, or no splice decomposition at
all is not covered.  What is now excluded is the entire proposed strategy
of filtering the remote two-crossing component of Note 154 by an arbitrary
four-port factor.

The fixed
[verification bundle](../computations/bundles/forced-boundary-row-crossing-compensation/README.md)
checks (5)--(6).  Its terminal marker is
`FORCED_BOUNDARY_ROW_CROSSING_COMPENSATION_VERIFIED`.
