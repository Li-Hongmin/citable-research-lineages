> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every consecutive J1/J3 three-double group reduces to a square

[Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md)
classifies an ordinary target-free group containing exactly one
\(J_1\) and one \(J_3\) double block. Three consecutive double
blocks with \(J_1/J_3\) internal chords and arbitrarily many
short-block flanks must alternate. They force a 24-vertex
square-equivalent patch.

Take three consecutive target-free doubly vacant blocks in old-cycle
order
\[
D_1=(a,o,h,i,k,j,e,b),\quad
D_2=(A,O,H,I,K,J,E,B),\quad
D_3=(\hat a,\hat o,\hat h,\hat i,\hat k,\hat j,\hat e,\hat b).
                                                               \tag{1}
\]
Their old-cycle joins are \(bA,B\hat a\). Add the six common-face
chords
\[
ab,\quad ok,\quad AB,\quad IE,\quad
\hat a\hat b,\quad\hat o\hat k                           \tag{2}
\]
and the five opposite-side chords
\[
h\hat i,\quad iK,\quad jH,\quad eO,\quad J\hat h.          \tag{3}
\]
The internal chords are \(J_1,J_3,J_1\), respectively. Every
nonterminal vertex now has degree three. The four degree-two
terminals, in disk-boundary order, are
\((a,\hat j,\hat e,\hat b)\). Call this four-pole \(P\).

**Three-double theorem.** Suppose an ordinary target-free
free group in a compressed, gapless, tight-target all-square
Barnette opening has exactly three doubly vacant complete
blocks, all other complete blocks short, and ordinary endports
\(L,R\). The three double blocks are consecutive, with no short
block between them, and each has exactly one internal free
chord of type \(J_1\) or \(J_3\).

Their types must be \(J_1,J_3,J_1\) or \(J_3,J_1,J_3\).
In the first case, label them as (1).
Their internal chords are \(ok,IE,\hat o\hat k\), and the
five cross-block matching edges (3) are forced regardless
of the numbers of short blocks on either flank. The patch
\(P\) is thus induced and square-equivalent. Compressing it
leaves an all-short group with the unique ordinary matching
and a vertex-spanning \(L\)--\(R\) route. Reflection gives
the same result for \(J_3,J_1,J_3\). All six other
direction orders are impossible even with arbitrary
short flanks.

If no short flank occurs, the \(J_1,J_3,J_1\)
matching specializes to
\[
L\hat j,\quad h\hat i,\quad iK,\quad jH,\quad eO,\quad
J\hat h,\quad\hat e R.                                    \tag{4}
\]
Reflection gives the second case.

The complete vertex-spanning
one-path and two-path Hamilton signature of \(P\), at these labeled
terminals, is exactly that of the square
\((a',\hat j',\hat e',\hat b')\). Replacing an induced copy of \(P\)
by this square, or conversely, preserves Barnette membership and
every Hamilton decision on exterior and attachment edges. Hence a
vertex-minimal non-Hamiltonian Barnette graph contains no induced
copy of \(P\). The patch is realized in a 36-vertex Hamiltonian
Barnette graph with a compressed, gapless, tight-target all-square
opening. In that realization the three doubly vacant blocks have
no short block between them.

**Forced core.** By the chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
no free same-block chord other than \(ok,IE,\hat o\hat k\) is available.
All free cross-block chords lie on the opposite side by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
After removing the endpoints of the internal chords, the
free slots and endports occur in the order
\[
L,h,i,j,e,O,H,K,J,\hat h,\hat i,\hat j,\hat e,R.          \tag{5}
\]
Their opposite-side matching is noncrossing. The even slot
\(h\) cannot meet its old-cycle neighbour \(i\) or the
forbidden same-block slot \(j\). Its possible odd mates
\(O,\hat j,R\) enclose respectively 3, 9 and 11 other
free slots and so are impossible. Its only possibilities
are \(J,\hat i\).

If \(hJ\) occurs, the six slots inside it are
\(i,j,e,O,H,K\). The slot \(i\) cannot use the
same-block \(e\), and \(iH\) traps three slots, so
\(iK\) is forced. The four slots inside \(iK\)
then force \(jH,eO\): the alternatives use an old-cycle
edge or leave one slot trapped. The even slot \(\hat h\)
now has no mate. Its same-block odd choices \(\hat i,\hat j\)
are respectively an old-cycle edge and a forbidden
internal chord; a chord to any remaining slot inside
\(hJ\) crosses that chord, and \(\hat hR\) traps
\(\hat i,\hat j,\hat e\). Thus \(hJ\) is impossible.

Hence \(h\hat i\) occurs. No chord from \(L\) into its
interior is noncrossing. The only odd slots outside it
available to \(L\) are \(\hat j,R\). Choosing \(LR\)
would leave \(\hat j,\hat e\) to pair by their old-cycle
edge, so \(L\hat j,\hat eR\) are forced.
Inside \(h\hat i\), the slot \(i\) can meet only
\(K\) or \(\hat h\): its same-block \(e\) is forbidden,
and \(iH\) traps three slots. If \(i\hat h\) occurred,
the six enclosed slots \(j,e,O,H,K,J\) would need
a noncrossing matching. Such a matching has a pair
consecutive in this list. The only permitted consecutive
pair is \(eO\). Removing it leaves \(j,H,K,J\),
which cannot be matched without using the old-cycle edge
\(KJ\), joining equal colours, or leaving a singleton.
Therefore \(iK\) is forced. Its interior
\(j,e,O,H\) forces \(jH,eO\), and the remaining
two slots inside \(h\hat i\) force \(J\hat h\).
This gives exactly (4) when no short flank occurs.
Reflection proves the other alternating orientation.

Now allow \(p\) short blocks before \(D_1\) and \(q\) after
\(D_3\), with no short block between the double blocks.
Every such block contributes two successive free slots.
For \(h\), a chord to the first odd slot of any left short
block encloses its second free slot and pairs of later short
slots, hence an odd number of free slots. A chord to the
first odd slot of any right short block, or to \(R\),
encloses the eleven other core free slots after \(h\),
plus an even number of short slots. All these chords are
impossible. The only core possibilities remain \(hJ\)
and \(h\hat i\), exactly as above.

If \(hJ\) occurred, its interior again forces \(iK,jH,eO\).
The even slot \(\hat h\) cannot meet a left short-block
odd slot: the interval between them contains the left
block's second free slot, pairs of later left short
slots, and all eight free slots of \(D_1,D_2\), an odd
total. A right short-block odd slot, or \(R\), is also
impossible because the interval contains
\(\hat i,\hat j,\hat e\) plus an even number of short
slots. Its core alternatives are unavailable as before.
Thus \(h\hat i\) is forced. The interior of that chord
contains no short-flank slots, so the preceding proof
forces \(iK,jH,eO,J\hat h\) unchanged. This is precisely
the induced patch \(P\) of (1)--(3).
Its square compression leaves only short blocks; the
ordinary-link argument of [Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md)
forces their matching and supplies a spanning route.
Explicitly, if the left short blocks have free slots
\((o_t,e_t)\), \(1\le t\le p\), put \(e_0=L\).
Their links are \(e_{t-1}o_t\) and \(e_p\hat j\).
If the right short blocks have free slots
\((u_t,v_t)\), \(1\le t\le q\), put \(v_0=\hat e\).
Their links are \(v_{t-1}u_t\) and \(v_qR\).
The formulas also apply when \(p=0\) or \(q=0\).

**Other directions.** The pure \(J_1,J_1,J_1\) and
\(J_3,J_3,J_3\) orders are impossible by
[Note 334](334-every-all-j1-double-vacancy-group-reduces-to-squares.md):
a pure group contains a canonical square-equivalent chain
with a positive short-block corridor, whereas these
three double blocks are consecutive. It remains to exclude
two mixed orders with arbitrary short flanks; reflection
then excludes the other two.

For \(J_1,J_1,J_3\), label the three blocks by indices
\(1,2,3\). After the internal chord endpoints are removed,
the free-slot order is
\[
L,h_1,i_1,j_1,e_1,h_2,i_2,j_2,e_2,
o_3,h_3,k_3,j_3,R.
\]
The even slot \(h_1\) can meet only \(i_2\) or \(j_3\).
The alternatives \(j_2,o_3,R\) enclose an odd number of
free slots; \(i_1\) is an old-cycle neighbour and \(j_1\)
is a forbidden same-block chord. If \(h_1i_2\) occurred,
its interior \(i_1,j_1,e_1,h_2\) would have no matching:
\(i_1e_1\) is excluded by chord isolation, while
\(i_1h_2\) traps the old-cycle pair \(j_1e_1\).
Hence \(h_1j_3\) is forced. This argument is unchanged
by short blocks on either flank: a candidate from \(h_1\)
to a left short-block odd slot encloses that block's second
free slot plus pairs of later short slots, an odd total; while
a candidate to a right short-block odd slot adds an even
number of slots to the eleven-slot parity obstruction
for \(h_1R\). The chord \(h_1j_3\) surrounds every other
free slot of the three double blocks. Noncrossing forces
their matching to remain within these blocks, so the
three-block interval has only its two old-cycle boundary
edges leaving. This is a forbidden two-edge cut, even
with short flanks. Thus this direction is impossible.

For \(J_3,J_1,J_1\), first ignore the flanks. The core
free-slot order is
\[
o_1,h_1,k_1,j_1,h_2,i_2,j_2,e_2,
h_3,i_3,j_3,e_3.
\]
The even slot \(h_2\) can meet only \(j_1\) or \(i_3\):
its other core options are old-cycle edges, forbidden
internal chords, or enclose an odd number of free slots.
A chord to a left short-block odd slot encloses that
block's second free slot, pairs of later left short
slots, and all four first-block free slots; a chord
to a right short-block odd slot or \(R\) encloses
seven core free slots plus an even number of short
slots. These counts are odd. The interior of \(h_2i_3\) is
\(i_2,j_2,e_2,h_3\). Here \(i_2e_2\) is excluded by
chord isolation, and \(i_2h_3\) would trap the old-cycle
pair \(j_2e_2\). Therefore \(j_1h_2\) is forced.
The even slot \(k_1\) must then meet \(i_2\).
Indeed, \(o_1\) is a forbidden same-block chord;
\(k_1j_2\) traps the unmatched \(i_2\);
\(k_1i_3\) leaves the impossible four slots
\(i_2,j_2,e_2,h_3\) after \(j_1h_2\);
and \(k_1j_3\) encloses an odd number of slots.
The left short-block odd slots are ruled out by the
one second slot, pairs of later left short slots, and
\(o_1,h_1\), again an odd total; the right short-block
odd slots and \(R\) enclose the nine remaining core
free slots plus an even number of short slots.

The even slot \(h_3\) now has no mate. A left short-block
odd slot would enclose its second free slot, pairs of
later short slots, and all eight free slots of the first
two double blocks, an odd total. The core odd slot
\(o_1\) encloses seven free slots before \(h_3\);
\(j_1,i_2\) are already matched; and \(j_2h_3\)
would trap the singleton \(e_2\). Its same-block
choices \(i_3,j_3\) are an old-cycle edge and a
forbidden internal chord. A right short-block odd slot
or \(R\) encloses \(i_3,j_3,e_3\) plus an even
number of short slots. Every choice is impossible,
excluding \(J_3,J_1,J_1\).
Reflection excludes \(J_1,J_3,J_3\) and
\(J_3,J_3,J_1\), completing the direction classification.

**Plane structure and Hamilton signature.** The chords in (2) are
nested or disjoint on the common-face side. After their endpoints
are removed, the free-slot order within \(P\) is
\[
h,i,j,e,O,H,K,J,\hat h,\hat i,\hat j,\hat e.
\]
The chords in (3) are nested or disjoint in the opposite-side disk:
\(h\hat i\) surrounds \(iK,jH,eO,J\hat h\);
\(iK\) surrounds \(jH,eO\); and \(jH\) surrounds \(eO\).
The old path and these two chord pages give a plane disk drawing
with the displayed terminal order. Terminal colours alternate:
\(a,\hat e\) have one colour and \(\hat j,\hat b\) the other.

Here are four spanning paths, one for each colour-permitted
terminal pair:
\[
\begin{array}{c|l}
a\hat b&
 \text{the full old-cycle path through }D_1,D_2,D_3\\
a\hat j&
 a,b,e,O,A,B,E,I,H,j,k,o,h,i,K,J,
 \hat h,\hat i,\hat k,\hat o,\hat a,\hat b,\hat e,\hat j\\
\hat j\hat e&
 \hat j,\hat k,\hat o,\hat h,\hat i,h,i,k,o,a,b,
 A,O,e,j,H,I,K,J,E,B,\hat a,\hat b,\hat e\\
\hat e\hat b&
 \hat e,\hat j,\hat k,\hat o,\hat h,\hat i,h,i,k,o,a,b,
 A,O,e,j,H,I,K,J,E,B,\hat a,\hat b .
\end{array}                                                   \tag{6}
\]
Every row lists all 24 vertices once. Each successive pair is an
old-cycle edge or an edge of (2)--(3). The last row is obtained
from the preceding one by moving the final \(\hat e\) to the start
along the old edge \(\hat e\hat j\).

The two noninterlacing spanning two-path pairings also occur.
For \(\{a\hat j,\hat e\hat b\}\), take the old-cycle path from
\(a\) through \(\hat j\) and the edge \(\hat e\hat b\).
For \(\{a\hat b,\hat j\hat e\}\), take the \(a\hat j\) row of
(6) and delete its edge \(\hat b\hat e\); its two components
end at \(a,\hat b\) and \(\hat e,\hat j\). Both constructions
cover every patch vertex once. The third pairing
\(\{a\hat e,\hat j\hat b\}\) interlaces the terminals and is
impossible in a disk. These six routings are exactly the
square's complete signature. A global Hamilton cycle meets
the four-attachment cut in two or four edges, so replacing
its one or two internal paths by the same square state
preserves the exterior cycle in either direction.
In the classified free group, \(L\hat j\), the
\(\hat j\hat e\) row of (6), and \(\hat eR\)
concatenate to a vertex-spanning \(L\)--\(R\) path.

**A real Barnette realization.** Give an old Hamilton cycle
the order
\[
x,R_1,w,y,D_1,D_2,D_3,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x.                           \tag{7}
\]
Use the face-side complementary-matching chords
\[
xy,\ ab,\ ok,\ AB,\ IE,\ \hat a\hat b,\ \hat o\hat k,\
uv,\ \alpha\beta                                         \tag{8}
\]
and the opposite-side chords
\[
\delta R_1,\ w\hat j,\ h\hat i,\ iK,\ jH,\ eO,\
J\hat h,\ \hat e z,\ \gamma L_1.                         \tag{9}
\]
These lists match every vertex once, pair opposite old-cycle
colours, and use no old-cycle edge. Each page is noncrossing.
The site chords \(xy,uv\) lie on the same face of the drawing.

For three-connectivity, join two matching chords when their
endpoints alternate around (7). The following alternations
form a connected spanning subgraph of this interlacement
graph:
\[
\begin{gathered}
xy-w\hat j-\hat a\hat b-h\hat i-ab-iK-IE,\\
h\hat i-ok,\qquad
iK-AB-jH,\qquad AB-eO,\qquad AB-J\hat h-\hat o\hat k,\\
\hat a\hat b-\hat e z-uv-\gamma L_1-\alpha\beta-\delta R_1 .
\end{gathered}                                              \tag{10}
\]
Each dash is an endpoint alternation in (7); (10) contains
all 18 matching chords. A two-edge cut of a cubic Hamiltonian
graph would consist of two old-cycle edges and bound a proper
old-cycle interval closed under the matching. Such an interval
would disconnect the interlacement graph, contradicting (10).
The old Hamilton cycle also excludes a bridge. Thus the graph
is three-edge-connected and, since it is cubic, three-vertex-
connected. It has \(3\cdot8+12=36\) vertices.

A Hamilton cycle containing both site chords is the union
of these two internally disjoint \(x\)--\(v\) paths:
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,w,\ (\hat j\hat e\text{ row of (6)}),\ z,u,v.
\end{split}                                                 \tag{11}
\]
The second line uses \(w\hat j,\hat e z\) from (9).
It visits every vertex outside the first line once.
Reflecting this realization gives the \(J_3,J_1,J_3\)
case.

**Barnette preservation.** The labeled square is a planar
minor of \(P\). Its \(a'\hat b'\) edge is obtained by
contracting the interior of
\[
a,b,A,B,\hat a,\hat b,
\]
and its \(a'\hat j'\) edge from the internally disjoint path
\[
a,o,h,\hat i,\hat k,\hat j.
\]
The other two square edges are the old edges
\(\hat j\hat e,\hat e\hat b\). Delete surplus patch edges
and vertices. Conversely, the two-page disk drawing of \(P\)
inserts it into the empty side of a four-attachment square,
with the same cyclic terminal order and colours. This
preserves simplicity, cubicity, bipartiteness and planarity.

For the vertex-connectivity check, the exterior of either
four-pole in a three-connected cubic host is connected:
two exterior components would each require at least three
of the four attachment edges. Deleting any one vertex of
\(P\) leaves it connected. Indeed, each of its three
face-closed block cycles remains connected; the four joins
\(bA,iK,jH,eO\) from \(D_1\) to \(D_2\) have distinct
endpoints, and the two joins \(B\hat a,J\hat h\) from
\(D_2\) to \(D_3\) have distinct endpoints. At least one
join of each kind survives. After deleting any two patch
vertices, each component of \(P\) contains a surviving
terminal: otherwise that component would disconnect the
three-connected realization (7)--(9) from its nonempty
exterior. The corresponding statements for a square are
immediate. The four-attachment deletion comparison of
[Note 330](330-staggered-vacancy-chains-have-the-square-hamilton-signature.md)
therefore proves three-connectivity in both replacement
directions.

In the selected opening, replacing \(P\) by the labeled
square turns the three consecutive doubly vacant blocks
into one short target-free block while retaining their
four exterior attachments. If all other vacancies occupy
distinct internal blocks, [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md)
gives a Hamilton parent cycle through both site edges
after compression. Lift its patch routing through (6), then
use [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
for the legal site-expanded child. \(\square\)

The direction classification and square reduction cover
three consecutive \(J_1/J_3\) double blocks with arbitrary
short flanks. They do not cover short blocks between the
double blocks, other internal chord types, singly vacant
blocks in the same group, target-bearing vacancies,
positive gaps, non-square residual cycles, or
Barnette's conjecture. This is a project-internal analytic
proof; no external priority or independent review is claimed.
