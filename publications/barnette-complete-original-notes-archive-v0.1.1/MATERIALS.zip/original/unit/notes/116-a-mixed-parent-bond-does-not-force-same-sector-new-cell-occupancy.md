> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A mixed parent bond does not force same-sector new-cell occupancy

[Note 115](115-state-11-new-cell-fertility-is-exact-but-a-covered-endpoint-can-be-sterile.md)
shows that the state-\(11\) endpoint of a mixed parent rooted bond can be
fixed-exterior sterile.  In its octagonal-bipyramid example, a one-vertex
change of the old exterior nevertheless produces a new-cell child target in
the same surviving-gate sector.

This note shows that such a bondwise repair is not forced, even in the actual
legal class.  A crossed double split gives a mixed rooted bond
\(\chi^1\eta^0\) whose state-\(11\) endpoint is sterile and whose entire
same-sector new-cell family is empty.  Thus no old-exterior switch, connected
or otherwise, can repair that prescribed endpoint.  The example does not
satisfy the global kill-cover antecedent and its child still has rooted bonds
through new cells in the opposite sector.  Its exact consequence is therefore
that the full rooted split-bond lemma cannot be proved one mixed parent bond at
a time.

## 1. The bondwise statement

Use the notation of Notes 108 and 115.  For a child split, put

\[
 {\cal N}^b={\cal A}_{R_{00}}^b\cup
 {\cal A}_{X_{uy}}^b\cup {\cal A}_{X_{vx}}^b,
\tag{1}
\]

where \(b\) is the surviving-gate bit.  Consider the following natural
strengthening of full occupancy:

\[
\begin{split}
(P_{\rm mix})\qquad
&\chi^b\eta^{1-b}\text{ is a parent rooted bond},\\
&\chi\in {\cal L}_{11}^b,\quad
  \eta\notin {\cal L}_{11}^{1-b},\quad
  \chi\text{ is fixed-exterior sterile}
\end{split}
\quad\Longrightarrow\quad
 {\cal N}^b\ne\varnothing.
\tag{2}
\]

Any same-sector old-exterior repair of \(\chi\) would produce an element of
\({\cal N}^b\), so (2) is weaker than requiring the repair switch to be
connected.

There is already a parity mismatch between the hypothesis and the desired
repair.  Align global representatives so that the split vertex \(z\) has the
same colour under \(\chi\) and \(\eta\), and put

\[
 S=\{v:\chi(v)\ne\eta(v)\}\subseteq V(T-z).
\tag{3}
\]

Since the parent edge is a rooted bond, both shores of \(S\) are connected.
But its endpoints have opposite gate bits, and hence

\[
 g_1^*\in\delta_T(S).
\tag{4}
\]

A same-sector exterior switch \(K\), in contrast, must satisfy

\[
 g_1^*\notin\delta_T(K).
\tag{5}
\]

Thus neither orientation of the connected parent shore supplies the desired
switch.  If the non-\(11\) endpoint has state \(10\) or \(01\), the parent
shore also contains exactly one of \(P,Q\), whereas every new-cell row has
\(P,Q\) equally coloured.  The mixed bond therefore supplies connectivity in
the wrong gate-parity class.  This observation alone does not exclude a
different gate-even switch; the example below excludes the whole target
sector.

## 2. A crossed double split

Start with the bipyramid over

\[
 r_0r_1\cdots r_7r_0
\tag{6}
\]

with apices \(z,w\).  First split \(z\) across \(r_0,r_4\), introducing
vertices \(A,B,C\).  The resulting parent triangulation \(T\) has vertex set

\[
 V(T)=\{w,r_0,\ldots,r_7,A,B,C\}
\tag{7}
\]

and edges

\[
\begin{aligned}
 &r_ir_{i+1}\quad(i\bmod 8),\qquad wr_i\quad(0\le i<8),\\
 &Ar_i\quad(0\le i\le4),\\
 &Br_i\quad(i\in\{4,5,6,7,0\}),\\
 &AC,BC,Cr_0,Cr_4.
\end{aligned}
\tag{8}
\]

Now split \(w\) across

\[
 P=r_2,\qquad Q=r_6.
\tag{9}
\]

The two closed link intervals are

\[
 I_D=r_2r_3r_4r_5r_6,\qquad
 I_E=r_6r_7r_0r_1r_2.
\tag{10}
\]

The child \(T^+\) is obtained from \(T-w\) by adding \(D,E,F\), joining
\(D\) to every vertex of \(I_D\), joining \(E\) to every vertex of
\(I_E\), and adding

\[
 DF,EF,Fr_2,Fr_6.
\tag{11}
\]

The parent and child have respectively \(12\) and \(14\) vertices.  Both
are Eulerian plane triangulations.  Deleting any set of at most three
vertices leaves either graph connected, so both are \(4\)-connected.  Take

\[
 e^*=AC,\qquad g_1^*=Ar_2.
\tag{12}
\]

No two among the primal root edge, surviving gate, and the two expanded
edges share an endpoint: equivalently, no corresponding pair among
\(AC,Ar_2,wr_2,wr_6\) co-bounds a triangular face of \(T\).  Hence this is
an interface-disjoint legal split.

## 3. A sterile mixed rooted bond

In vertex order

\[
 (w,r_0,r_1,r_2,r_3,r_4,r_5,r_6,r_7,A,B,C),
\tag{13}
\]

define

\[
 \chi=100100010111,\qquad
 \eta=100010010111.
\tag{14}
\]

Their monochromatic components are

\[
\begin{array}{c|c|c}
 &0\text{-components}&1\text{-components}\\ \hline
\chi&
 \{r_0,r_1,r_7\},\ \{r_3,r_4,r_5\}&
 \{A,B,C,r_2,r_6,w\}\\
\eta&
 \{r_0,r_1,r_2,r_7\},\ \{r_4,r_5\}&
 \{A,B,C,r_3,r_6,w\}.
\end{array}
\tag{15}
\]

The root edge \(AC\) is monochromatic, and the third vertices of its two
incident triangles are \(r_0,r_4\).  They lie in distinct zero-components
in both rows of (15).  Hence both colourings are root-admissible.

At \((w,P,Q)\), the two rows are \((1,1,1)\) and \((1,0,1)\).
Consequently \(\chi\) has state \(11\), while \(\eta\) does not.  Their
difference shore is

\[
 S(\chi,\eta)=\{r_2,r_3\}.
\tag{16}
\]

This shore induces an edge and its complement is connected.  Moreover
\(Ar_2\) is monochromatic for \(\chi\) and bichromatic for \(\eta\).
Therefore

\[
 \chi^1-\eta^0
\tag{17}
\]

is a mixed parent rooted bond.

The state-\(11\) endpoint is fixed-exterior sterile already at the NAE
level.  Indeed,

\[
 \chi(I_D)=10001,\qquad \chi(I_E)=10001.
\tag{18}
\]

In every new-cell row, at least one split-side apex has colour \(0\).
The corresponding interval in (18) contains a \(00\)-edge, making one of
its incident triangles monochromatic.  Both intervals are blocked, so none
of \(R_{00},X_{uy},X_{vx}\) admits the fixed exterior.

## 4. The whole same-sector family is empty

Fixing \(r_0=0\) quotients global reversal.  Direct enumeration of all
triangular-face NAE colourings gives \(89\) parent and \(169\) child colour
orbits.  The exact three-component and labelled-root test at \(AC\) leaves
\(14\) root-admissible child targets outside \(C_{11}\), with distribution

\[
\begin{array}{c|rrrrrr}
 &C_{00}&C_{10}&C_{01}&R_{00}&X_{uy}&X_{vx}\\ \hline
g_1=0&4&0&2&4&1&1\\
g_1=1&0&2&0&0&0&0.
\end{array}
\tag{19}
\]

In particular,

\[
 \boxed{{\cal N}^1=\varnothing.}
\tag{20}
\]

The canonical extension of \(\eta\) is one of the two
\(C_{01}^0\)-targets, but no root-admissible new-cell colouring has the
gate bit of \(\chi\).  Every old-exterior switch producing a successful
same-sector repair would give an element of \({\cal N}^1\); global reversal
only exchanges a switch with its complementary shore.  Equation (20)
therefore excludes every such switch, independently of its connectivity or
number of components.  This proves

\[
 \boxed{P_{\rm mix}\text{ is false in the actual legal class}.}
\tag{21}
\]

## 5. Exact boundary for the full problem

The selected parent rooted bond graph has nine vertices and six edges.
Four of its edges have two non-\(11\) endpoints.  Thus \({\cal L}_{11}\)
does not cover the full parent bond graph, and the example does not satisfy
the antecedent of the rooted split-bond lemma.

Nor does the child fail supplementation.  Its rooted bond graph has eight
edges, distributed as

\[
 4(C_{00},C_{10})+2(C_{10},R_{00})
 +(C_{10},X_{uy})+(C_{10},X_{vx}).
\tag{22}
\]

The four bonds incident with new cells use new targets in gate sector \(0\)
and canonical targets in sector \(1\).  Hence full opposite-gate occupancy
and the desired child rooted bond both survive.

The conclusion is therefore a strict localization boundary:

\[
\boxed{
\text{a sterile mixed parent bond cannot be repaired bondwise;
the global kill-cover must be used across the complete parent family.}}
\tag{23}
\]

The remaining occupancy statement is still the one in Note 115: under a
nonempty *globally* kill-covered parent bond graph, the complete child family
must avoid a two-sector new-target vacuum or a single-sector stranded family.
After (21), a proof cannot select an arbitrary mixed covered edge and demand a
new target in its state-\(11\) endpoint's sector.  It must instead couple
different covered bonds or prove a genuinely sector-global consequence of the
kill-cover condition.

The frozen verifier is

```text
python3 units/barnette/scratch/worker-actual-occupancy-countermodel/audit_crossed_double_split_mixed_connected_repair.py
```

and terminates with

```text
ACTUAL_P_MIX_SECTOR_VACUUM_COUNTEREXAMPLE_VERIFIED
CROSSED_DOUBLE_SPLIT_MIXED_REPAIR_AUDIT_OK
```
