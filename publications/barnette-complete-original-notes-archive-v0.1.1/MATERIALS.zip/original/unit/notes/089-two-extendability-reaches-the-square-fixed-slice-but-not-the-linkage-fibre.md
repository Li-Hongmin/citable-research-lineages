> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-extendability reaches the square-fixed slice but not the linkage fibre

[Note 088](088-a-wide-plane-nonbrace-realizes-a-minimum-atomic-two-switch.md)
shows that planarity and legal-wide geometry do not exclude a globally
minimum atomic two-switch when the brace hypothesis is removed.  It is
therefore essential to identify exactly what brace 2-extendability adds.

At the two boundary terminals adjacent to the square-forced gate,
2-extendability does force every residual incident edge into some perfect
matching containing both distinguished square edges.  This is a genuine
positive extension statement.  It stops before the fixed-pairing
two-linkage fibre: neither the terminal pairing nor the number of closed
complement components is controlled.

Consequently the proposed proof that an atomic minimum creates a forbidden
2-cut has two separate missing inputs.  One must first normalize the
defects of the two infeasible proper toggles, and then prove a full-fibre
separator lemma.  The brace axiom alone does not make either step formal.

## 1. Boundary edges enter the square-fixed slice

Use the square notation

\[
Q=u-v-x-y-u,\qquad e=uv,\qquad g_0=xy,
\tag{1}
\]

and let \(u',v',x',y'\) be the external neighbours of the four square
vertices.  Delete \(V(Q)\) to obtain the four-terminal graph \(R\).

Let \(h\) be either of the two edges of \(R\) incident with \(x'\).  The
edges \(e,h\) are independent.  In any perfect matching \(X\) containing
both, the attachment \(xx'\) is unavailable because \(x'\) is already
covered by \(h\).  The square edge \(vx\) is unavailable because \(v\) is
covered by \(e\).  The only remaining edge at \(x\) is \(g_0=xy\).
Therefore

\[
\boxed{e,h\in X\Longrightarrow g_0\in X.}
\tag{2}
\]

The same argument applies to either residual edge incident with \(y'\).
If \(G\) is a brace, every independent pair extends to a perfect matching,
so every such boundary edge occurs in the square-fixed slice

\[
\mathcal P_{e,g_0}
=\{X\in\mathcal M(G):e,g_0\in X\}.
\tag{3}
\]

This is stronger than generic 2-extendability for an internal edge.  If
\(h\) is internal to \(R\), asking that it occur in (3) is the
three-edge-extension problem for \(\{e,g_0,h\}\), which is not supplied by
the brace axiom.

## 2. The square-fixed slice is larger than the linkage fibre

For \(X\in\mathcal P_{e,g_0}\), put

\[
P=X-\{e,g_0\}.
\tag{4}
\]

The exact square-deletion criterion of
[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md)
is

\[
P\in\mathcal L
\iff c(P)=0\text{ and }\pi(P)=\pi_0,
\tag{5}
\]

where \(c(P)\) is the number of closed components of \(R-P\) and
\(\pi(P)\) is its terminal pairing.  Equation (2) controls neither
quantity.  Even if the extension happens to lie in \(\mathcal L\), it need
not differ on one alternating cycle from a target in the opposite surviving
gate sector.

There is an exact exchange formulation for an internal prospective repair
edge.  Fix \(M\in\mathcal P_{e,g_0}\) and let \(h\notin M\) be internal to
\(R\).  Then

\[
\boxed{
\{e,g_0,h\}\text{ extends to a perfect matching}
\iff
\begin{array}{l}
\text{there is an \(M\)-alternating cycle through \(h\)}\\
\text{that avoids \(e\) and \(g_0\).}
\end{array}}
\tag{6}
\]

Indeed, an extension \(X\) gives the required component of
\(M\triangle X\); conversely, toggling such a component gives an extension.
Thus internal square-fixed repair is already a three-edge problem before
the target condition (5) is imposed.

## 3. The 2-cut route splits into two missing lemmas

Let \(M,N\) be a globally minimum cross-sector pair in \(\mathcal L\), and
suppose

\[
M\triangle N=C_1\mathbin{\dot\cup}C_2.
\tag{7}
\]

By Note 086, neither proper component toggle belongs to \(\mathcal L\).
Notes 087--088 exhibit the special defect profile

\[
\begin{array}{c|cc}
&\pi&c\\ \hline
M\triangle C_1&\pi_1&0\\
M\triangle C_2&\pi_0&1,
\end{array}
\tag{8}
\]

up to interchanging the components: one toggle has the wrong pairing and
no closed component, while the other has the correct pairing plus a
distinguished closed cycle \(Z\).

The general hypotheses do not imply (8).  Equation (5) allows either wrong
pairing together with any number of closed components.  Global
cross-sector minimality quantifies only over members of \(\mathcal L\), so
it gives no direct numerical control over the two proper toggles outside
\(\mathcal L\).

Accordingly the route

\[
\text{atomic global minimum}
\Longrightarrow
\text{nontrivial 2-cut}
\tag{9}
\]

requires two additional statements.

1. **Defect normalization.**  The two failed proper toggles can be reduced
   to the profile (8), producing a distinguished repair cycle \(Z\).
2. **Full-fibre separator.**  If the complete fibre has no cross-sector
   single-cycle edge, then a nontrivial shore containing \(Z\) has
   two-edge boundary.

If both statements hold, a plane-brace counterexample is impossible,
because a brace is 3-connected.  An equivalent operational form of the
second statement is:

> If the repair shore has at least four attachments, the complete
> square-fixed family supplies a fixed-pairing target that crosses the gate
> sector by one alternating cycle.

Equations (2)--(6) explain why this is not an immediate consequence of
2-extendability.  The brace axiom supplies independent two-edge extensions
and square-fixed extensions at \(x',y'\); it does not automatically give an
internal square-fixed repair, the target condition (5), or one-cycle
adjacency.

## 4. Exact boundary

**Exact conclusion.**  Brace 2-extendability forces every residual edge at
\(x'\) or \(y'\) into the square-fixed matching slice.  For an internal
edge, entry into that slice is exactly the alternating-cycle condition
(6).  Neither statement alone reaches the fixed-pairing fibre.

**Consequence.**  A proof excluding minimum atomic two-switches cannot cite
2-extendability as a black box.  It must prove defect normalization and a
full-fibre separator or attachment lemma that also enforces (5).

**Unresolved boundary.**  Neither missing lemma is presently proved, and
no plane-brace counterexample is known.  The remaining mathematical
content is the coupling of brace-level exchange with terminal pairing,
closed-cycle elimination and global cross-sector minimality.
