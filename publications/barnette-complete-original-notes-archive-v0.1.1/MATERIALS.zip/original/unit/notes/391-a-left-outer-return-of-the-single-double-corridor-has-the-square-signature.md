> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A left outer return of the single–double corridor has the square signature

[Note 390](390-every-isolated-single-double-corridor-contains-an-exact-square-reduction.md)
reduces every no-flank single–double corridor. A first short block on the
left can reroute the matching edge from the single block to the double
block. The resulting nonstandard return still gives an exact square pole.

Work in the compressed, gapless, tight-target all-square selected opening.
Let one ordinary target-free free group have consecutive blocks
\[
 S_0=(c,p,q,d),\qquad V=(a,o,h,i,e,b),\qquad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\qquad
 D=(A,O,H,I,K,J,E,B),\quad m\ge1.                 \tag{1}
\]
There is no short block after \(D\). Let \(t,z\) be the group's even
left and odd right endports, and let \(M\) complement the selected old
Hamilton cycle. Suppose
\[
                         tJ,\quad pK,\quad qo\in M.       \tag{2}
\]
The edge \(Ez\) is forced: \(E,z\) are the only free slots to the right
of \(tJ\). In particular, no internal free chord of \(D\) occurs.

**Left-return theorem.** In every actual matching satisfying (1)–(2),
the remaining matching edges on \(h,i,e,S_1,\ldots,S_m,O,H,I\) are one
of the \(hI\) words of [Note 383](383-the-hi-return-single-double-corridor-is-an-exact-square-reduction.md)
or one of the delayed \(hp_s\) words of
[Note 389](389-delayed-single-double-returns-are-exact-square-reductions.md),
with their \(oK\) edge omitted. The whole \((18+4m)\)-vertex interval
\(S_0,V,S_1,\ldots,S_m,D\) is an induced disk four-pole with terminals
\((c,J,E,B)\) in cyclic order. Its complete spanning one-path and
two-path Hamilton signature equals that of the labeled square.
Replacing this pole by the square, or reversing the replacement,
preserves Barnette membership and every exterior- and
attachment-marked Hamilton decision. Every displayed matching word
is realized in a Barnette parent with a Hamilton cycle containing
both site edges; its legal site-expanded child is Hamiltonian.
The same conclusions hold for the reflected right-wing pattern.

**Matching classification.** All cross-block matching chords lie in
the disk opposite the common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
The chords \(tJ,pK,qo\) are nested in that order. The slots
\(h,i,e,S_1,\ldots,S_m,O,H,I\) lie inside \(pK\); every matching
edge on these slots stays inside it. Neither \(oe\) nor a free chord
of \(D\) is available. Replace \(S_0\) by nothing and replace the
two edges \(pK,qo\) by \(oK\). This gives a noncrossing matching
on the no-flank slot order
\[
             t,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,
             O,H,I,K,J,E,z.                              \tag{3}
\]
Conversely, the substitution \(oK\mapsto\{pK,qo\}\) gives (2)
from any such no-flank word.

The classification proofs of Notes 383–384 use, after \(tJ,oK,Ez\),
only noninterlacement inside \(oK\) and the prohibition on a
matching-closed nonempty run of complete corridor blocks. Those
conditions hold unchanged inside \(pK\): each \(S_j\) and its two
old-cycle boundary edges are unchanged, and \(qo\) lies outside all
these runs. Their first step leaves \(hI\) or \(hp_s\), \(s\ge2\),
and their ensuing shortest-run arguments give exactly the words
stated above. In particular, this deduction does not assume that
the shortened matching (3) occurs in the original graph.

**A four-state lifting rule.** Let \(T\) be any of the no-flank
four-poles in Notes 383 and 389. It has terminals \((a,J,E,B)\),
old-cycle edge \(ao\), face chord \(ab\), and matching edge \(oK\). Form \(T^+\)
by deleting \(oK\), placing the square \(c,p,q,d,c\) before \(a\),
and adding \(da,qo,pK\). The old terminal \(a\) becomes internal
and \(c\) becomes the new terminal. This is exactly the pole in
the theorem. Every spanning path or spanning pair of paths of \(T\)
lifts according to whether \(a\) is an endpoint and whether its
route uses \(oK\):
\[
\begin{array}{c|c|l}
 a\text{ an endpoint?}&oK\text{ used?}&\text{route change}\\
 \text{yes}&\text{no}&\text{prepend }c,p,q,d,a\text{ at }a\\
 \text{no}&\text{no}&ao\longmapsto a,d,c,p,q,o\\
 \text{yes}&\text{yes}&\text{prepend }c,d,a\text{ at }a;
                         \quad oK\longmapsto o,q,p,K\\
 \text{no}&\text{yes}&oK\longmapsto o,q,d,c,p,K.
\end{array}                                                \tag{4}
\]
When \(a\) is not an endpoint, both its internal edges \(ao,ab\)
are used, so the second row is always defined. Each row uses
\(c,p,q,d\) exactly once. Its new joins are edges of \(S_0\) or
\(da,qo,pK\); all unchanged joins remain in \(T^+\). The first
and third rows move the endpoint from \(a\) to \(c\); the other
rows make \(c\) internal. No path is split or joined, and every
other terminal and its pairing are fixed. Notes 383 and 389 give
all four spanning one-path pairs and both spanning two-path
pairings of a square for \(T\), so (4) gives them for \(T^+\).
The terminals \(c,E\) have one colour, \(J,B\) the other; parity
excludes the other two one-path pairs. The third two-path pairing
interlaces the disk terminals. Thus the signature is exact.

**Class preservation.** Cap \(T^+\) by a fresh square whose terminal
attachments are \(c,J,E,B\), as in the caps of Notes 383 and 389.
Its Hamilton order starts with \(c,p,q,d,a\), follows the old
path through \(B\), and ends with the four cap vertices. Put all
face chords \(cd,ab,c_jd_j,AB\) and the cap's closing chord on
one page. On the other, replace the old cap chord \(oK\) by the
nested chords \(pK,qo\); all remaining old chords keep their
order. Hence the cap is simple, cubic, bipartite and plane.

The cap's matching-chord interlacement graph is connected.
Write \(F_S=cd,F_0=ab,F_D=AB\). The new chord \(qo\)
interlaces \(F_S,F_0\), while \(pK\) interlaces \(F_S,F_D\).
All old face-chord incidences other than the removed \(oK\)
are unchanged. The connected face-chord incidence described in
Notes 383 and 389 is therefore retained with the old
\(F_0\)--\(F_D\) link \(oK\) replaced by the two new links
through \(F_S\). Every other matching chord meets its endpoint
block's face chord, and the cap attachments join \(F_D\) to the
cap face chord. A two-edge cut would enclose a matching-closed
proper Hamilton-cycle interval and disconnect this
interlacement graph. There is no bridge because the cap has a
Hamilton cycle. Therefore the cap is three-edge-connected and,
being cubic, three-vertex-connected.

Also \(T^+-v\) is connected for every pole vertex \(v\). If
\(v\in S_0\), the square minus \(v\) is connected and at least
two of \(da,qo,pK\) survive; the old \(T-oK\) contains the full
old-cycle path and is connected. If \(v\in T\), Notes 383 and 389
give connected \(T-v\). When \(o,K\) both survive, the path
\(o,q,p,K\) replaces their old edge; when one is deleted, that
edge has already disappeared. The intact new square has at least
two surviving attachments to \(T-v\). This proves the claim.
Since the cap is three-connected, deleting two vertices of
\(T^+\) cannot leave a component with no surviving terminal.
The labeled square has the same one- and two-deletion properties.
The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
now preserves three-connectivity in both replacement directions.
The terminal colours and disk order preserve bipartiteness and
planarity; (4) preserves every exterior Hamilton decision.

Finally, replace the no-flank pole in each marked Barnette parent
of Notes 383 and 389 by \(T^+\), using their common square
signature and the class comparison. This adds four vertices,
retains the exterior site edges, and extends the selected old
Hamilton order by \(S_0\). The marked cycle lifts by (4), and
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal Hamiltonian child. This realizes every word in
the theorem. \(\square\)

The theorem covers the specified nonstandard left return
\(tJ,pK,qo\) and its reflection, with a positive internal
short corridor. Other one-wing returns, simultaneous
nonstandard flanks, other free-group shapes and other opening
types remain outside it. The general Barnette conjecture is
not decided. This is a project-internal analytic proof; no
external priority or independent review is claimed.
