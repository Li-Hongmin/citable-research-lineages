> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two-port corridors reduce to port-free vacancies

[Note 316](316-peelable-multi-vacancy-corridors-have-three-spanning-states.md)
peels a port-owned vacancy when it is next to its port in the
atom diagram. [Note 317](317-closed-vacancy-intervals-have-the-exact-square-linkage-signature.md)
compresses any closed vacancy-only block interval with the exact
square signature. Noncrossing makes the latter reduction available
before each port-owned vacancy, without limiting the number of
intervening port-free atoms.

Let \(G\) have the Barnette parent and compressed, gapless,
tight-target all-square opening of Note 316. In one free group
\(D=B_a,\ldots,B_b\) with retained end links, exactly
\(P_s,P_t\), \(a\le s<t<b\), are missing. Every vacancy
lies in a distinct target-free internal block. In the corridor
\(B_{s+1},\ldots,B_t\), label a vacancy \(L\) if it belongs
to the \(P_s\) rainbow component, \(R\) if it belongs to the
\(P_t\) component, and \(F\) otherwise.

**Port-owner elimination theorem.** There is a finite sequence
of exact four-terminal replacements taking \(G\) to a
Barnette parent \(G_0\) of no greater order, with the same kind of marked opening
such that either:

1. one of the two missing links has become retained, in which
   case the free group of \(G\) has \(S,K,X\) by Note 288; or
2. both missing links remain, but every vacancy between them
   in \(G_0\) is \(F\).

In the second case, for each of \(S,K,X\), existence in the
original group is equivalent to existence in the reduced group,
with identical four exterior group attachments. The reduction
may remove any number of closed port-free vacancy components
as well as all corridor vacancies owned by either port.
Consequently the general two-port corridor question in this
opening reduces to the pure-\(F\) corridor. By Notes 312,
315, and 317, any unresolved reduced corridor has at least
two \(F\) vacancies and a vacancy matching edge leaving it.

**Proof.** Two port components are distinct by Note 278. An
\(R\) cannot precede an \(L\), since the two components would
interlace in the order \(P_s<R<L<P_t\).

Suppose at least one \(L\) remains, and let \(V=B_j\) be the
first \(L\) in the current corridor. All corridor vacancies
strictly between \(P_s\) and \(V\) are \(F\). They belong to
components entirely inside the atom gap \((P_s,V)\).
Indeed, \(P_s,V\) are consecutive atoms of the left port
component. If a component with an atom in this gap also
had an atom before \(P_s\), then
\(F_{\rm out}<P_s<F<V\) would interlace the left
component; if it had an atom after \(V\), then
\(P_s<F<V<F_{\rm out}\) would interlace it.
There is no other port atom in this gap. Thus every
vacancy matching edge with an endpoint in the block
interval
\[
                    J=B_{s+1},\ldots,B_{j-1}            \tag{1}
\]
has its other endpoint in \(J\). All internal ordinary
links of \(J\) are retained.

The interval \(J\) is nonempty. Otherwise \(j=s+1\),
and membership of \(P_s,V\) in one rainbow component
would force \(o_jH_j\), an old-cycle edge, into the
complementary matching. Its four exterior attachments
are the old-cycle edges at its ends, the matching edge
from its first ordinary slot \(o_{s+1}\) to \(H_j\),
and the retained ordinary link from its last \(e\)-slot
to \(o_j\). Therefore \(J\) satisfies Note 317's
closed-interval square theorem, even when \(J\) contains
arbitrarily many nested \(F\) components. Compress it to
one short square \(Q\). The atom \(V\) is now immediately
after \(P_s\), and the two matching edges at \(Q,V\) are
the forced \(O_QH_j\) and retained \(E_Qo_j\).
Note 315's cube fold replaces \(Q\cup B_j\) by one
short block. Both replacements preserve Barnette
membership, the marked opening, and every four-port
spanning-path pairing.

The cube fold either restores \(P_s\) as an ordinary
matching link or leaves it missing. In the first case,
Note 288 applies and the exact route replacements lift
its \(S,K,X\) states back to \(G\). In the second, the
left port component loses exactly \(V\): its new later
ordinary endpoint is \(I_j\), whose matching edge is
the old edge from \(I_j\). All other atoms and their
component memberships are unchanged except the
closed \(F\) components removed with \(J\). Hence the
number of \(L\) vacancies falls by one. Repeat until
no \(L\) remains.

Now take the last \(R\), if any. All corridor vacancies
between it and \(P_t\) are \(F\), and noncrossing confines
their components to this final atom gap. The reflected
versions of (1), Note 317's compression, and Note 315's
cube fold remove that \(R\), or restore \(P_t\) and
finish by Note 288. Repeat until no \(R\) remains.
At every unrepaired step at least one vacancy atom is
deleted, so the procedure terminates. If no owner atom is present
initially, the sequence may be empty; otherwise the graph order
strictly decreases. All replacements
have exact Hamilton linkage signatures; therefore
\(S,K,X\) existence is equivalent before and after
the sequence. With neither port repaired, the terminal
graph \(G_0\) has only \(F\) corridor vacancies.
The final necessary shape follows from Notes 312,
315, and 317. \(\square\)

The theorem is a reduction of the two-defect branch of
this selected opening. It does not assert that all
pure-\(F\) corridors have three states, and it does
not address target-bearing or same-block repeated
vacancies, positive gaps, defective target order,
nonsquare residual cycles, or general Barnette graphs.
The pure-\(F\) corridor is settled by the minimum-span
reduction of [Note 319](319-every-target-free-group-with-distinct-vacancies-has-three-routes.md),
which also allows arbitrarily many ports.
