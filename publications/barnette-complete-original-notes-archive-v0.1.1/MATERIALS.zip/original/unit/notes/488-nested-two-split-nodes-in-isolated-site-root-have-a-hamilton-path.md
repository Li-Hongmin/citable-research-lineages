> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nested split nodes in an isolated site root have a Hamilton path

[Note 487](487-disjoint-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md) closes the disjoint placement of two split marked unary nodes in the isolated site root of a disconnected three-root equality opening. The nested placement has a simpler final case than the four-terminal chorded analogue of [Notes 475–476](476-a-six-terminal-square-splice-closes-the-chorded-equality-boundary.md): if the inner child is sealed, its two terminals are the site ports, and the ordinary open-arc square splice already closes it.

Let \(W\) be the isolated end root containing both site ports \(u,v\), with every other face matching edge incident with \(W\) internal to it. Suppose its marked unary nodes are nested:
\[
 N_o=(H_o,s_o,A_o,t_o,J_o),\qquad
 N_i=(H_i,s_i,A_i,t_i,J_i)\subset A_o .
\tag{1}
\]
Let \(L_o,R_o,L_i,R_i\) be the respective child-word ends. Every assigned special position other than the four direct positions belongs to a two-special leaf. Equality in the charge of Notes 410 and 477 gives each marked unary node two consecutive plain-unary ancestors.

**Nested-root-path theorem.** \(W\) has a spanning \(u\)--\(v\) path. Therefore the parent has a Hamilton cycle containing both site edges, and its legal expanded child is Hamiltonian.

**Proof.** Let \(C_W\) be the old root arc closed by its root chord, \(E\) the square-supported old edges at the two-special leaves, and \(M_W\) the face matching except at \(u,v\). Open both split nodes inside their child words:
\[
 F_{\rm ii}
 =\bigl(C_W-E-\{s_oL_o,R_ot_o,s_iL_i,R_it_i\}\bigr)
       \cup M_W\cup\{L_oR_o,L_iR_i\}.
\tag{2}
\]
It has one \(u\)--\(v\) path and some cycles. Restoring \(E\) gives three connected old pieces before adding interpiece matching chords: the inner child \(A_i\), the two flanks \(D=A_o\setminus A_i\) joined through \(L_oR_o\), and the outer complement \(B=W\setminus A_o\) joined through the root chord. A leaf whose square chord was inserted in (2) gives a quotient loop and needs no switch. Let \(K_0\) be the three-vertex graph joining \(A_i,D,B\) by \(M_W\)-edges. Within each component of \(K_0\), leaf-square switches absorb every cycle into a terminal path if that component has the two site terminals.

If \(K_0\) is connected, the spanning \(u\)--\(v\) path follows. If not, each component contains either zero or both terminals. An isolated \(A_i\) with zero terminals has only its two old boundary edges leaving it, contrary to three-connectivity. An isolated \(B\) with both terminals leaves \(A_o\) terminal-free and without any \(M_W\)-edge to \(B\); its two old boundary edges are again a forbidden two-edge cut. An isolated \(B\) with zero terminals is impossible by parity: the special positions before \(s_o\), together with \(s_o\), form an odd set with no terminal. No \(M_W\)-edge joins it to \(A_o\), while a chord to the suffix after \(A_o\) would cross the site edge \(q=w_0u\) ending inside \(A_o\). That odd set cannot be internally matched.

Suppose \(D\) is an isolated component. If it has no terminal, its left and right flanks contain respectively \(s_i\) and \(t_i\), plus complete two-special leaves. Both flanks have odd special-position counts. Since no \(M_W\)-edge leaves \(D\), an odd number of matching chords join the flanks and span \(A_i\). Such a chord would cross a site edge ending in \(A_i\), so \(A_i\) has no terminal and both \(u,v\) lie in \(B\). Three-connectivity forces an \(M_W\)-edge from \(A_i\) to \(B\). If \(D\) has both terminals, \(A_i\) and \(B\) have none, and the same cut argument forces an \(M_W\)-edge from \(A_i\) to \(B\).

Both isolated-\(D\) cases are closed by opening the outer node inside and the inner node outside:
\[
 F_{\rm io}
 =\bigl(C_W-E-\{s_oL_o,R_ot_o,H_is_i,t_iJ_i\}\bigr)
       \cup M_W\cup\{L_oR_o,H_iJ_i\}.
\tag{3}
\]
The inserted inner-node chord \(H_iJ_i\) is unused by \(C_W\), since the inner node has two plain-unary ancestors. After restoring \(E\), the coarse pieces are the central arc \(P=s_i\rightsquigarrow t_i\), the rest of \(D\) closed through \(L_oR_o,H_iJ_i\), and the outer arc \(B\). The \(M_W\)-edge from \(A_i\) to \(B\) joins \(P\) to \(B\). If either \(s_i\) or \(t_i\) is a nonterminal, its matching mate lies in the rest of \(D\): \(D\) was isolated in \(K_0\), no matching edge crosses \(A_i\), and [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) forbids matching \(s_i\) to \(t_i\). Thus all three pieces are connected, and leaf-square switches give a spanning \(u\)--\(v\) path.

If both \(s_i,t_i\) are site terminals, the isolated-\(D\) case is impossible instead. Then \(A_i\) has no terminal, and the required \(M_W\)-edge from \(A_i\) to \(B\) would cross \(q=w_0s_i\) if it goes to the left of \(s_i\), or \(p=t_iw_*\) if it goes to the right of \(t_i\). There is no other location in \(B\). This excludes the last subcase of isolated \(D\).

With three coarse pieces, the only other disconnected placement not yet closed has an isolated \(A_i\) containing both \(u,v\); the disposition of \(D,B\) does not matter. All nonterminal special positions of \(A_i\) are then matched internally and occur in two-special leaves. Apply the open-arc four-terminal theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) to its old \(L_i\)--\(R_i\) arc. One of its two distinct pairings joins \(L_i\) to one site port and \(R_i\) to the other. The complementary \(L_i\)--\(R_i\) path around \(C_W\) covers every vertex of \(W\setminus A_i\). Their union is a spanning \(u\)--\(v\) path in \(W\). This proves the theorem in every case.

The explicit exterior path (4) or (5) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) covers the remaining vertices and joins the root path through \(q,p\) into a marked parent Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

Combining Notes 486–488, **every three-root two-split equality opening with disconnected root face graph is Hamiltonian**. A non-Hamiltonian chord-free child at \(c=5f-8\), if one exists, must therefore have two split marked unary nodes and a connected root face graph.
