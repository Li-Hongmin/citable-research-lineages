> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact Hamiltonian criterion for a \(C_4\)-expansion

## Setup

Let \(G\) be a finite graph and let

\[
p=uv,\qquad q=xy
\]

be vertex-disjoint edges.  Form \(H\) by deleting \(p,q\), adding four new
vertices \(a,b,c,d\), and adding

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\]

For the Barnette application, \(p,q\) lie on a common face and the endpoint
order is fixed by that face.  The local statements below do not otherwise use
planarity, bipartiteness, cubicity, or 3-connectivity.

## Six-witness criterion

The graph \(H\) is Hamiltonian if and only if \(G\) contains at least one of
the following structures:

1. a Hamilton cycle containing both \(p\) and \(q\);
2. a Hamilton cycle containing \(p\) but not \(q\);
3. a Hamilton cycle containing \(q\) but not \(p\);
4. a Hamilton path from \(v\) to \(x\) in \(G-\{p,q\}\);
5. a Hamilton path from \(u\) to \(y\) in \(G-\{p,q\}\);
6. two vertex-disjoint paths in \(G-\{p,q\}\) whose union is \(V(G)\), whose
   endpoints are \(u,v,x,y\), and whose endpoint pairing is not
   \(\{\{u,y\},\{v,x\}\}\).

To prove necessity, intersect a Hamilton cycle of \(H\) with the eight gadget
edges.  Requiring degree two at \(a,b,c,d\) leaves exactly seven local
patterns.  One is the isolated cycle \(abcda\), which cannot be part of a
Hamilton cycle containing old vertices.  Removing the gadget from the six
remaining patterns gives precisely the six structures above.  Conversely,
each of the six structures joins to its corresponding gadget path or paths;
all vertices then have degree two, and the pairing exclusion in item 6 is
exactly what prevents two disjoint cycles.

This last connectivity assertion is stronger than a degree check.  In the
four-terminal case, both the gadget part and the old-vertex part are unions
of two paths and induce perfect matchings \(\pi_J,\pi_F\) on
\(\{u,v,x,y\}\).  Contracting the four paths gives

\[
F\cup J\text{ is one cycle}\quad\Longleftrightarrow\quad
\pi_F\ne\pi_J.
\]

Equal pairings give two cycles; distinct pairings give a four-cycle after
contraction.  The linkage gadget has \(\pi_J=(uy)(vx)\), proving the
exclusion in item 6.  That exclusion is redundant only when the six clauses
are read as one disjunction: if the external linkage has pairing
\((uy)(vx)\), adding \(p=uv,q=xy\) joins distinct pairings and gives a
parent Hamilton cycle containing both edges, so clause 1 already holds.
Four terminals are the smallest interface supporting this obstruction.

Thus failure of all Hamilton cycles of \(G\) containing \(p\) or \(q\) is not
enough to prove that \(H\) is non-Hamiltonian: either cross Hamilton path or
the spanning two-path linkage can still produce a Hamilton cycle.

## Direct-lift coverage

Let \(\mathcal F\) be a family of Hamilton cycles of \(G\), and write

\[
S_{\mathcal F}(e)=\{C\in\mathcal F:e\in C\}.
\]

Directly lift every member containing \(p\) or \(q\).  The lifted family
covers every edge of \(H\) if and only if:

\[
S_{\mathcal F}(g)\cap
\bigl(S_{\mathcal F}(p)\cup S_{\mathcal F}(q)\bigr)\ne\varnothing
\]

for every \(g\in E(G)\setminus\{p,q\}\), and at least two of the three cycle
states \(11,10,01\) occur.  The first condition is exact for retained old
edges.  For the gadget edges, any two distinct states cover all eight edges,
whereas one state never does.

## Central saturation transfer

Assume \(G\) has Hamilton cycles \(C_{11},C_{10},C_{01}\) in the three cycle
states above and the two cross Hamilton paths \(X_{vx},X_{uy}\).  In \(H\),
take the opposite central edges

\[
p'=bc,\qquad q'=da.
\]

Then \(H\) has the same five kinds of witnesses for \(p',q'\):

- lifting \(C_{10}\) through \(u-a-d-c-b-v\) gives state \(11\);
- closing \(X_{uy}\) through \(u-a-b-c-d-y\) gives state \(10\);
- closing \(X_{vx}\) through \(v-b-a-d-c-x\) gives state \(01\);
- deleting \(p,q\) from \(C_{11}\) and adjoining
  \(u-a-b-v,x-c,d-y\) gives a Hamilton path from \(c\) to \(d\);
- deleting \(p,q\) from \(C_{11}\) and adjoining
  \(u-a,v-b,x-c-d-y\) gives a Hamilton path from \(b\) to \(a\).

Each construction is checked by degrees and connectivity.  Consequently the
five-witness package transfers under expansion of the new central pair and
may be iterated indefinitely.  The finite \(240\to640\) certificate retained
in `scratch/` checks the formulas on 100 iterations, but the infinite
conclusion follows from this transfer argument rather than extrapolation.

## Boundary of the result

The criterion concerns one specified expansion, and the transfer theorem only
covers the recursively selected central pair.  It proves neither Barnette's
conjecture nor closure of Hamiltonicity or lift-completeness under every legal
\(C_4\)-expansion.  No literature-novelty claim is made here.

The disposable exhaustive check of all \(2^8\) gadget-edge subsets and the
three external four-terminal pairings is
`scratch/worker-barnette/verify_local_global_interface.py`.
