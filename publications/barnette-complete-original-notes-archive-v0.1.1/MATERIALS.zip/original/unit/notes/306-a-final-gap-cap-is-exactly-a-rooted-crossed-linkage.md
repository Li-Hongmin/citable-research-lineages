> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A final-gap cap is exactly a rooted crossed linkage

[Note 305](305-two-chord-port-skeleton-shields-arbitrary-prefix-matchings.md)
reduces each serial region to two matching chords and a
two-terminal cap \(D\). The cap has an exact internal
description. Its edge through the preceding vacant block
is forced; the remaining question is a specified spanning
two-path linkage in the final gap.

Work in the compressed, gapless, tight-target all-square
opening of Notes 275--305. Let \(B_v,B_u\) be distinct
vacant target-free blocks with \(u\ge v+2\). Assume the
matching contains
\[
 I_vH_u,\qquad e_{u-1}o_u,                          \tag{1}
\]
and let \(F=B_{v+1},\ldots,B_{u-1}\). Write
\(x=m(e_v)\) for the complementary-matching mate of
\(e_v\). Put
\[
 Y=\{e_v,b_v\}\cup V(F).                           \tag{2}
\]
The cap required in Note 305 is a path from
\(e_{u-1}\) to \(b_{u-1}\) whose vertex set is
exactly \(Y\).

**Forced-edge and rooted-linkage theorem.** In an actual
Barnette parent with the stated opening, \(x\in V(F)\).
Every cap on \(Y\) must contain the three edges
\[
              xe_v,\qquad e_vb_v,\qquad b_va_{v+1}.
                                                               \tag{3}
\]
Such a cap exists if and only if \(F\) has two disjoint
paths whose union spans \(V(F)\), with endpoint pairs
\[
    x\longleftrightarrow e_{u-1},
    \qquad a_{v+1}\longleftrightarrow b_{u-1}.
                                                               \tag{4}
\]
In particular, a different fold that avoids \(e_vb_v\)
cannot meet Note 305's vertex inventory.

There are exactly two boundary types. If \(P_v=e_vo_{v+1}\)
is retained, then \(x=o_{v+1}\), and (4) is the
ordinary \(X(F)\) state. If \(P_v\) is missing,
then \(x=I_t\) for some vacant \(B_t\) in \(F\),
and (4) is a rooted crossed linkage with one bottom
terminal at that interior vacancy. In the latter case
\(t\ge v+2\); the matching edge \(e_vI_t\) is the
outer edge of the port component starting at \(P_v\).

**Proof.** In the opposite-side disk of Notes 276--278,
\(I_vH_u\) is a noncrossing matching chord. Its endpoint
\(I_v\) precedes \(e_v\), and \(H_u\) follows all of
\(F\). A chord from \(e_v\) to a vertex outside the
open old-cycle interval \((I_v,H_u)\) would interlace
\(I_vH_u\), contrary to planarity. Within that interval,
\(b_v\) and all \(a_j,b_j\) are already matched by the
face chords, while \(o_u\) is matched to \(e_{u-1}\)
by (1). The only remaining eligible matching slots lie
in \(F\). Hence \(x\in V(F)\).

The endpoints \(e_{u-1},b_{u-1}\) of a cap are distinct
from \(e_v,b_v\) because \(F\ne\varnothing\).
Within the induced vertex set \(Y\), the only neighbors
of \(e_v\) are its matching mate \(x\) and its old-cycle
neighbor \(b_v\): its other old-cycle neighbor \(I_v\)
lies outside \(Y\). Similarly, the only neighbors of
\(b_v\) in \(Y\) are \(e_v\) and \(a_{v+1}\): its face
mate \(a_v\) lies outside. Both vertices must have degree
two on any spanning path with the specified endpoints.
Thus (3) is forced.

Removing \(e_v,b_v\) and their incident forced edges
from such a cap leaves two disjoint paths in \(F\): one
from \(e_{u-1}\) to \(x\), the other from
\(a_{v+1}\) to \(b_{u-1}\). They cover \(F\) once,
giving (4). Conversely, given (4), traverse the first
path backwards from \(e_{u-1}\) to \(x\), then the
three edges (3), then the second path from
\(a_{v+1}\) to \(b_{u-1}\). This is the required cap.

If \(P_v\) is retained, its mate is
\(o_{v+1}\), so the endpoint pairs in (4) are exactly
the crossed state of Note 275. If it is missing, the
ordinary-slot pairing restriction of Note 276 forbids
\(e_v\) from pairing with another ordinary slot; the
old-cycle bipartition permits only a vacancy slot of type
\(I_t\), not \(H_t\). The pair \(o_{v+1},H_{v+1}\)
is an old-cycle edge, so a port beginning at \(P_v\)
cannot have its first and only target at \(B_{v+1}\);
the noncrossing component rule gives \(t\ge v+2\)
and makes \(e_vI_t\) its outer edge. \(\square\)

**One-block final gap.** If \(u=v+2\), then
\(B_{v+1}\) must be short, \(P_v\) is retained,
and the cap is uniquely
\[
 e_{v+1},o_{v+1},e_v,b_v,a_{v+1},b_{v+1}.
                                                               \tag{5}
\]
Indeed, the mate of \(e_v\) lies in this one block.
If the block were vacant, pairing \(e_v\) to
\(o_{v+1}\) would leave \(H_{v+1},I_{v+1}\)
as an impermissible old-cycle matching edge; pairing it
to \(I_{v+1}\) would similarly leave the old-cycle
edge \(o_{v+1}H_{v+1}\). No other slots are free.
For a short block, \(o_{v+1}\) is its only available
free slot, and (4) has the unique lower edge
\(o_{v+1}e_{v+1}\) and upper face chord
\(a_{v+1}b_{v+1}\), giving (5).

**Two-block final gap.** If \(u=v+3\), a cap always
exists. Write \(p=v+1\), \(q=v+2\). Up to the
vacancy status of \(B_p,B_q\), every compatible matching
inside the chord \(I_vH_u\) is one of the following:
\[
\begin{array}{c|c|l}
B_p&B_q&\text{free matching edges}\;\\ \hline
\text{short}&\text{short}&e_vo_p,\ e_po_q\\
\text{short}&\text{vacant}&e_vI_q,\ o_pH_q,\ e_po_q\\
\text{vacant}&\text{vacant}&e_vo_p,\ e_po_q,\
 H_pI_q,\ I_pH_q.
\end{array}                                                   \tag{6}
\]
In the first and third rows the retained \(P_v\)
and \(P_p\) give \(X(F)\), hence a cap by (4). In
the middle row the required cap is explicitly
\[
 e_q,I_q,e_v,b_v,a_p,b_p,e_p,o_p,H_q,o_q,a_q,b_q.
                                                               \tag{7}
\]

To see that (6) is exhaustive, the available ordinary
slots between \(I_v,H_u\) are
\(e_v,o_p,e_p,o_q\), since \(e_q\) is paired to
\(o_u\). Note 276 permits an ordinary-to-ordinary
pair only at \(P_v=e_vo_p\) or \(P_p=e_po_q\).
With no vacancy both are forced. With only \(B_p\)
vacant, diverting \(P_v\) forces the forbidden old-cycle
edge \(o_pH_p\), while diverting \(P_p\) forces
\(e_pI_p\); so that placement is impossible. With only
\(B_q\) vacant, diverting \(P_p\) forces the forbidden
edge \(o_qH_q\), whereas diverting \(P_v\) gives the
middle row of (6).

When both blocks are vacant, if both links are retained,
their four vacancy slots have the unique permitted
noncrossing pairing in the last row. If both links are
missing, the forced edges \(e_vI_p\) and \(o_pH_q\)
cross. If exactly \(P_v\) is missing, either
\(e_vI_q\) leaves the forbidden pair \(H_pI_p\),
or \(e_vI_p\) crosses the forced \(o_pH_q\).
If exactly \(P_p\) is missing, the forced
\(e_pI_q\) and \(o_qH_p\) cross. This proves the
classification. Every consecutive pair in (7) is an
old-cycle edge, a face chord, or a matching edge from
the middle row, so (7) spans \(Y\) once with the
required endpoints. \(\square\)

**One-defect cap theorem, with unbounded gap length.**
Assume in addition that at most one link among
\(P_v,P_{v+1},\ldots,P_{u-2}\) is missing. Then the
cap (2) exists, with no bound on \(u-v\), the number
of vacant blocks in \(F\), or the nesting of their
vacancy-only components.

If \(P_v\) is retained, the chord \(I_vH_u\) traps
the free matching of \(F\) between its retained
boundary links \(P_v,P_{u-1}\). Thus \(F\) has at
most one internal missing link and satisfies the
boundary-locality hypotheses of Note 288. Note 275
gives \(X(F)\) when none is missing; Note 288 gives
\(X(F)\) when one is missing. The first boundary type
of (4) converts either \(X(F)\) into a cap.

If \(P_v\) is missing, every internal link of \(F\)
is retained. By the noncrossing atom classification,
the component of \(P_v\) is an end port
\[
 P_v<V_{r_1}<\cdots<V_{r_h}=V_t,
 \qquad v+2\le r_1\le t\le u-1.                 \tag{8}
\]
All other components in its proper gaps are
vacancy-only. Note 286(6)--(8) supplies
\(U:b_v\leadsto b_t\) spanning
\(B_{v+1},\ldots,B_t\) except \(I_t,e_t\).
Set
\[
 A:\quad e_t,I_t,e_v,b_v\xrightarrow{U}b_t.
                                                               \tag{9}
\]
The edge \(I_te_v\) is the outer edge of (8), so
\(A\) covers exactly \(e_v,b_v\) and all blocks
\(B_{v+1},\ldots,B_t\). If \(t=u-1\), put \(D=A\).
Otherwise let \(J=B_{t+1},\ldots,B_{u-1}\). Its
ordinary links are retained, so its elementary
crossed rails give
\[
 D:\quad e_{u-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}o_{t+1},
 e_t\xrightarrow{A}b_t,a_{t+1}
 \xrightarrow{X_{\rm top}(J)}b_{u-1}.
                                                               \tag{10}
\]
The two joins through \(e_to_{t+1}\) and
\(b_ta_{t+1}\) are respectively a retained ordinary
link and an old-cycle edge. The rails cover all of
\(J\), disjoint from \(A\), while (9) covers the
earlier part. Therefore (10) has the endpoints and
vertex inventory (2), proving the theorem. \(\square\)

The theorem identifies the exact remaining local choice in
the two-chord skeleton. Three-connectivity is part of the
parent hypothesis, but the argument above does not prove
that the rooted linkage (4) always exists. Its existence
is supplied for ordinary vacancy-only gaps by Note 275,
for selected multiport \(X\) gaps by Notes 288--300,
and for the final-gap side chains by Note 303.
