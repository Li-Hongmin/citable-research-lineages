> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Outer-return single–double poles have the exact square signature

[Note 387](387-every-isolated-single-double-short-corridor-has-a-marked-hamilton-route.md)
classifies the no-internal-double-chord `to,hz` branch of an
isolated single–double corridor and gives a marked spanning route.
Its two matching families admit a stronger conclusion: the whole
induced corridor is an exact four-terminal square reduction,
independently of every vacancy outside it.

Keep Note 387's block order
\[
 V=(a,o,h,i,e,b),\qquad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\qquad
 D=(A,O,H,I,K,J,E,B),                                    \tag{1}
\]
with no short flanks. Assume \(to,hz\in M\), no internal free
matching chord in \(D\), and one of the complete words
\(Z^1_{m;r}\) or \(Z^2_{m;s,u}\) in Note 387, equations (2)–(4).
The interval (1) is an induced disk patch \(P\) with four
degree-two terminals in cyclic order
\[
                              (a,o,h,B).                 \tag{2}
\]

**Outer-return square theorem.** For every \(m\ge2\) and
every allowed cutpoint parameter, \(P\) has precisely the
square's four spanning one-path terminal states and two
spanning two-path terminal pairings. Replacing \(P\) by the
labeled square \((a,o,h,B)\), or reversing the replacement,
preserves membership in the Barnette class and every
exterior- and attachment-marked Hamilton decision.
The replacement turns the selected opening's entire group
into one short target-free block with ordinary end links.
Consequently an induced copy of \(P\) cannot occur in a
vertex-minimal non-Hamiltonian Barnette graph, regardless
of the configuration outside the four attachments.

**Two minimal poles.** Let \(P_1\) be \(Z^1_{2;1}\), with
short blocks \(S_1,S_2\), and let \(P_2\) be
\(Z^2_{3;1,2}\), with \(S_1,S_2,S_3\). In both tables below,
commas denote consecutive vertices of a path; semicolons
separate two disjoint paths. A displayed row covers every
pole vertex exactly once.

For \(P_1\), the old-cycle path is the \(aB\) state. The
other three spanning one-path states are
\[
\begin{array}{c|l}
oh& o,a,b,e,J,K,p_1,c_1,d_1,q_1,I,H,
       p_2,c_2,d_2,q_2,O,A,B,E,i,h\\
ao& a,b,e,J,K,p_1,c_1,d_1,q_1,I,H,
       p_2,c_2,d_2,q_2,O,A,B,E,i,h,o\\
hB& h,o,a,b,e,i,E,J,K,p_1,c_1,d_1,q_1,I,H,
       p_2,c_2,d_2,q_2,O,A,B
\end{array}                                                \tag{3}
\]
The two spanning two-path pairings are
\[
\begin{array}{c|l}
\{aB,oh\}&(o,h);\quad
 (a,b,e,i,E,J,K,p_1,c_1,d_1,q_1,I,H,
                  p_2,c_2,d_2,q_2,O,A,B)\\
\{ao,hB\}&(a,o);\quad
 (h,i,e,b,c_1,d_1,c_2,d_2,A,O,q_2,p_2,H,I,
                  q_1,p_1,K,J,E,B)
\end{array}                                                \tag{4}
\]

For \(P_2\), again the old-cycle path is the \(aB\)
state. The other three one-path states are
\[
\begin{array}{c|l}
oh& o,a,b,e,p_1,c_1,d_1,q_1,J,K,p_2,c_2,d_2,q_2,
       I,H,p_3,c_3,d_3,q_3,O,A,B,E,i,h\\
ao& a,b,e,p_1,c_1,d_1,q_1,J,K,p_2,c_2,d_2,q_2,
       I,H,p_3,c_3,d_3,q_3,O,A,B,E,i,h,o\\
hB& h,o,a,b,e,i,E,J,q_1,p_1,c_1,d_1,c_2,p_2,
       K,I,q_2,d_2,c_3,p_3,H,O,q_3,d_3,A,B
\end{array}                                                \tag{5}
\]
The two two-path pairings are
\[
\begin{array}{c|l}
\{aB,oh\}&(o,h);\quad
 (a,b,e,i,E,J,q_1,p_1,c_1,d_1,c_2,p_2,K,I,q_2,d_2,
                         c_3,p_3,H,O,q_3,d_3,A,B)\\
\{ao,hB\}&(a,o);\quad
 (h,i,E,J,q_1,p_1,e,b,c_1,d_1,c_2,p_2,K,I,q_2,d_2,
                         c_3,p_3,H,O,q_3,d_3,A,B)
\end{array}                                                \tag{6}
\]
Every consecutive pair in (3)–(6) is an old-cycle edge,
a face chord, or a matching edge from the corresponding
word in Note 387. For example, the two less immediate
joins in (4)'s second long path are \(Oq_2,p_1K\);
those in (6)'s second long path are
\(p_1e,q_1J\). A reader can check the six states directly
from the two minimal matching lists:
\[
\begin{aligned}
Z^1_{2;1}&=\{iE,eJ,p_1K,q_1I,p_2H,q_2O\},\\
Z^2_{3;1,2}&=\{iE,ep_1,q_1J,p_2K,q_2I,p_3H,q_3O\}.
\end{aligned}                                              \tag{7}
\]
The terminals \(a,h\) have one bipartition colour and
\(o,B\) the other, excluding the other two one-path
pairs. The remaining two-path pairing interlaces the four
terminals in (2) and is impossible in a disk. Thus the six
displayed states are the complete square signature.

**Lifting every cutpoint word.** The short blocks in each
maximal run joined by ordinary links \(q_jp_{j+1}\) form
the even four-terminal ladder of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
For \(Z^1_{m;r}\), the runs are
\(S_1,\ldots,S_r\) and \(S_{r+1},\ldots,S_m\).
Replacing each by one short square sends its four
attachments, in order, to the corresponding attachments
of \(P_1\), including \(p_1K,q_rI,p_{r+1}H,q_mO\).
For \(Z^2_{m;s,u}\), the runs are
\(S_1,\ldots,S_s\), \(S_{s+1},\ldots,S_u\), and
\(S_{u+1},\ldots,S_m\). Compressing them sends
\(ep_1,q_sJ,p_{s+1}K,q_uI,p_{u+1}H,q_mO\)
to the corresponding six attachments of \(P_2\).
All runs have positive length, and their vertex sets
are disjoint. Note 178's exact four-terminal routing
replacement therefore transfers each of the six outer
states in both directions. Conversely, its square has
no extra states to lift; the parity and disk-order
exclusions above also apply before compression.

**Barnette-class comparison.** Cap the terminals (2) by a
fresh square in the cyclic order
\((t_B,t_h,t_o,t_a)\), attaching
\(Bt_B,ht_h,ot_o,at_a\). The full old-cycle path
through (1), followed by \(t_B,t_h,t_o,t_a,a\), is a
Hamilton cycle of this \((18+4m)\)-vertex cap. Its
complementary matching consists of the face chords
\(ab,c_jd_j,AB,t_Bt_a\), the internal word \(Z\),
and \(ot_o,ht_h\). The face chords occupy one page.
On the other, \(ot_o\) encloses \(ht_h\), which encloses
the noncrossing internal word \(Z\). Every matching
edge joins opposite Hamilton-cycle parities, so the cap
is simple, cubic, bipartite and plane.

The cap's matching-chord interlacement graph is connected.
Put \(F_0=ab,F_j=c_jd_j,F_D=AB,F_T=t_Bt_a\).
The chord \(iE\) interlaces \(F_0,F_D\); the other
internal chords and \(F_j\) form the connected
incidence subgraph described in Note 387, equation (9).
Both \(ot_o,ht_h\) interlace \(F_0\) and \(F_T\).
Consequently every matching chord belongs to one
interlacement component. A two-edge cut of a cubic
Hamiltonian graph would produce a proper Hamilton-cycle
interval closed under its matching, contradicting that
connectedness. The Hamilton cycle excludes bridges.
Thus the cap is three-edge-connected and therefore
three-vertex-connected.

The uncapped pole remains connected after deleting any
one vertex. Every complete block in (1), and every
ordinary-link short-block run, remains connected after
one deletion. For \(Z^1\), \(V\) has the disjoint joins
\(iE,eJ\) to \(D\); the first short run has
\(p_1K,q_rI\) to \(D\); the second has
\(p_{r+1}H,q_mO\) to \(D\). At least one join in
each pair survives one deletion, while \(D-v\) stays
connected. For \(Z^2\), the middle run has the disjoint
joins \(p_{s+1}K,q_uI\) to \(D\), and the last run
has \(p_{u+1}H,q_mO\). The first run reaches \(D\)
through \(q_sJ\) or through the edge
\(d_sc_{s+1}\) and the middle run. The two options
have disjoint endpoints at their boundaries, so one
survives one deletion. Finally \(V\) reaches \(D\)
through \(iE\) or through \(ep_1\) and the first run;
again one survives. Hence \(P-v\) is connected.

After deleting any two pole vertices, each surviving
component meets a surviving terminal: a component
without one would also be separated after the same
deletions in the three-connected cap. The square has
the same one- and two-deletion properties. The
four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
then gives three-connectivity in both replacement
directions. Terminal colours and cyclic disk order
preserve bipartiteness and planarity; all four labeled
attachments remain distinct. The six-state signature
gives the exterior-marked Hamilton transfer.

In the selected opening, the replacement square's old
path is \(a,o,h,B\), its face chord is \(aB\), and its
ordinary free links are \(to,hz\). Thus it is one short
block, and the selected opening outside this pole is
unchanged. \(\square\)

This exact reduction strengthens Note 387's conditional
marked-route conclusion in the outer-return branch: it
works with arbitrary outside vacancy configurations.
Other matching branches of the isolated group have marked
routes but are not all known to have exact square
signatures. Short flanks and other opening types remain
outside the theorem. It does not settle Barnette's
conjecture or assert external priority. This is a
project-internal analytic proof without local graph
recomputation or independent review.
