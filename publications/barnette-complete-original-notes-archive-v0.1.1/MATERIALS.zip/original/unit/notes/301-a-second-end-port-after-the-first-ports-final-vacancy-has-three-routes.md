> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A second end port after the first port's final vacancy has three routes

[Note 287](287-a-surrounding-vacancy-component-and-end-port-have-three-spanning-routes.md)
routes one end-port component inside a surrounding vacancy-only
component. The ordinary link immediately after that port component's
final vacancy can itself be missing. A second end-port component then
starts there. Two right continuations cover the two components
successively, and the surrounding component's cap and crossed routes
remain spanning.

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent. Each vacancy lies in a distinct target-free internal
face-chord block. Fix one free group with retained ordinary end links
and exactly two missing ordinary links, \(P_s=e_so_{s+1}\) and
\(P_u=e_uo_{u+1}\). In its noncrossing atom partition suppose there
are three distinguished components
\[
\begin{array}{ll}
\mathcal C:&V_s=V_{c_1}<V_{c_2}=V_w<\cdots<V_{c_h}=V_z,
                 \quad h\ge2,\\
\mathcal A:&P_s<V_{a_1}<\cdots<V_{a_p}=V_u,
                 \quad p\ge1,\quad a_1\ge s+2,\\
\mathcal B:&P_u<V_{d_1}<\cdots<V_{d_q}=V_v,
                 \quad q\ge1,\quad d_1\ge u+2,\quad v<w.
\end{array}                                                   \tag{1}
\]
Thus \(V_s,P_s\) and \(V_u,P_u\) are adjacent atoms of different
components; \(P_u\) is the link just after the last vacancy of
\(\mathcal A\). The two ports are nonconsecutive because \(u\ge s+2\).
All other components are vacancy-only and may be arbitrarily nested
inside proper gaps or surround the displayed span.

**Two-port boundary-chain theorem.** The interval
\(Q=B_s,\ldots,B_z\) has vertex-spanning states
\[
\begin{array}{ll}
S(Q):&o_s\longleftrightarrow e_z,\\
K(Q):&a_s\longleftrightarrow o_s,\quad e_z\longleftrightarrow b_z,\\
X(Q):&a_s\longleftrightarrow b_z,\quad o_s\longleftrightarrow e_z .
\end{array}                                                   \tag{2}
\]
There is no bound on \(h,p,q\), the lengths of their proper gaps,
or the number and nesting depth of other vacancy-only components.
Surrounding and serial vacancy-only parts preserve these states, so
the full group has \(S,K,X\). If every other free group has a
spanning ordinary-endport route, the parent has a Hamilton cycle
through both site edges, and its legal site-expanded child is
Hamiltonian. Reflection gives the reverse atom order.

**Proof.** Note 278's rainbow rule gives the matching edges
\[
\begin{array}{ll}
\mathcal C:&H_sI_z,\quad I_sH_w,\quad
            I_{c_j}H_{c_{j+1}}\ (2\le j<h),\\
\mathcal A:&e_sI_u,\quad o_{s+1}H_{a_1},\quad
            I_{a_j}H_{a_{j+1}}\ (1\le j<p),\\
\mathcal B:&e_uI_v,\quad o_{u+1}H_{d_1},\quad
            I_{d_j}H_{d_{j+1}}\ (1\le j<q).
\end{array}                                                   \tag{3}
\]
Every other ordinary link in \(Q\) is retained. Noncrossing confines
every additional component meeting a proper gap of
\(\mathcal A\) or \(\mathcal B\), or a gap of \(\mathcal C\)
after \(V_w\), to that gap; all such components are vacancy-only.
The first gap of \(\mathcal C\), between \(V_s,V_w\), contains
both port components and is routed explicitly below. The first
gaps after \(P_s,P_u\) are nonempty by old-cycle adjacency.
Every nonempty closed vacancy-only gap has Note 275's \(S,K,X\)
states.

Take two paths already constructed in the one-port proofs:

* [Note 287(5)](287-a-surrounding-vacancy-component-and-end-port-have-three-spanning-routes.md)
  gives \(L_A:a_{s+1}\leadsto e_s\), spanning
  \(B_{s+1},\ldots,B_u\) except \(e_u,b_u\). Its first-gap fold
  and old-cycle continuation use no edge incident with the second
  port \(P_u\).
* [Note 286(6)--(8)](286-a-boundary-sharing-vacancy-interval-absorbs-an-unbounded-end-port-component.md)
  gives \(T_A:b_s\leadsto b_u\), spanning
  \(B_{s+1},\ldots,B_u\) except \(I_u,e_u\).
  The same construction with \(u,v\) in place of \(s,u\) gives
  \(T_B:b_u\leadsto b_v\), spanning
  \(B_{u+1},\ldots,B_v\) except \(I_v,e_v\).
  It uses the source block \(B_u\) only at \(b_u\), so \(B_u\)
  may be vacant in \(\mathcal A\).

These statements are direct vertex inventories of the cited formulas.
Their proper gaps contain only vacancy-only components; neither
construction uses a matching edge inside a gap it crosses on the
old cycle.

Put \(J=B_{v+1},\ldots,B_{w-1}\), possibly empty. If \(J\) is
nonempty, its internal ordinary links are retained and its
elementary crossed rails have endpoints
\[
 X_{\rm top}(J):a_{v+1}\leadsto b_{w-1},\qquad
 X_{\rm bottom}(J):o_{v+1}\leadsto e_{w-1}.             \tag{4}
\]
They use only face chords, old-cycle edges, and retained ordinary
links, so they span \(J\) irrespective of its vacancy matching.
Define a right covering path \(R_B:e_{w-1}\leadsto b_{w-1}\) by
\[
\begin{split}
e_{w-1}
 &\xrightarrow{X_{\rm bottom}(J)^{-1}}o_{v+1},
 e_v,I_v,e_u,b_u
 \xrightarrow{T_B}b_v,a_{v+1}
 \xrightarrow{X_{\rm top}(J)}b_{w-1}.                 \tag{5}
\end{split}
\]
When \(J\) is empty, (5) means
\[
                 R_B=e_v,I_v,e_u,b_u
                       \xrightarrow{T_B}b_v.        \tag{6}
\]
The joins \(o_{v+1}e_v\), \(I_ve_u\), \(e_ub_u\), and
\(b_va_{v+1}\) are respectively a retained link, the
\(\mathcal B\) matching edge, and two old-cycle edges.
The path covers precisely \(e_u,b_u\) and all vertices of
\(B_{u+1},\ldots,B_{w-1}\). In particular it fills the two
vertices omitted by \(L_A\).

Let \(\Omega_C:e_s\leadsto o_w\) be Note 287(7)'s reverse
alternating walk
\[
 e_s,I_s,H_s,(I_{c_j},H_{c_j})_{j=h,h-1,\ldots,2},o_w.
                                                               \tag{7}
\]
It visits all vacancy slots of \(\mathcal C\) exactly once.
The straight state is
\[
 o_s,a_s,b_s,a_{s+1}
 \xrightarrow{L_A}e_s
 \xrightarrow{\Omega_C}o_w,e_{w-1}
 \xrightarrow{R_B}b_{w-1},a_w
 \xrightarrow{\text{ordinary continuation}}e_z.     \tag{8}
\]
The last continuation takes the face chord of every displayed
\(\mathcal C\) vacancy block and \(S\) in every later closed gap.
It omits only the \(\mathcal C\) vacancy slots supplied by (7).
The inventories of \(L_A,R_B,\Omega_C\) and this continuation
partition \(Q\), proving \(S(Q)\).

For the cap route, leave \(e_zb_z\) as its second path.
Define a fold \(Z_J:b_v\leadsto e_v\) through \(J\) and
\(a_w,o_w\) by
\[
\begin{split}
b_v,a_{v+1}&\xrightarrow{X_{\rm top}(J)}b_{w-1},
 a_w,o_w,e_{w-1}
 \xrightarrow{X_{\rm bottom}(J)^{-1}}o_{v+1},e_v
                                                       \tag{9}
\end{split}
\]
when \(J\ne\varnothing\); when \(J=\varnothing\), take
\(Z_J=b_v,a_w,o_w,e_v\). All displayed joins are old-cycle
edges or retained ordinary links. The other cap path is
\[
 a_s,b_s\xrightarrow{T_A}b_u
 \xrightarrow{T_B}b_v\xrightarrow{Z_J}e_v,
 I_v,e_u,I_u,e_s,I_s,H_w
 \xrightarrow{C\text{ forward}}I_z,H_s,o_s .          \tag{10}
\]
Besides the joins checked after (5), the exceptional edges in
(10) are \(I_ue_s,I_sH_w,I_zH_s\) from (3).
The old-cycle arc from \(H_w\) to \(I_z\) spans every later block,
including all later proper gaps, stopping before \(e_z,b_z\).
The paths \(T_A,T_B,Z_J\) cover all earlier blocks except
\(I_u,e_u,I_v,e_v\), which the displayed middle covers.
The initial and final segments cover the remaining vertices of
\(B_s\). Thus (10) and the cap edge are disjoint and span \(Q\),
proving \(K(Q)\).

For the crossed state, take
\[
\begin{array}{ll}
a_s,b_s\xrightarrow{T_A}b_u
 \xrightarrow{T_B}b_v
 \xrightarrow{X_{\rm top}(B_{v+1},\ldots,B_z)}b_z,\\[2pt]
o_s,H_s,I_s,e_s,I_u,e_u,I_v,e_v
 \xrightarrow{X_{\rm bottom}(B_{v+1},\ldots,B_z)}e_z .
\end{array}                                                   \tag{11}
\]
The joins \(e_sI_u,e_uI_v\) are the two outer port-matching
edges in (3); the neighbouring pairs in (11) are old-cycle
edges. All ordinary links within the suffix
\(B_{v+1},\ldots,B_z\) are retained, so its elementary \(X\)
rails exist even if its vacancy matching is not closed.
The top path covers the two port regions except \(I_u,e_u\)
and \(I_v,e_v\); the bottom path supplies those four vertices
and the complementary suffix rail. Together they cover every
vertex once with the crossed endpoint pairing.

Vacancy-only components outside \(Q\) lie wholly in a proper
surrounding gap or a serial flank. Note 275's prime and serial
rules compose their signatures with (2). Note 273 joins free
groups, and Notes 001 and 178 supply the marked parent cycle,
legal child cycle, and original lobe lengths. \(\square\)

**Analytic realization at every component size.** For arbitrary
\(h\ge2\) and \(p,q\ge1\), use Note 281(8)'s old cycle with
\(\ell=1\). Put
\[
\begin{split}
s&=1,&a_j&=j+2\quad(1\le j\le p),&u&=p+2,\\
d_j&=u+j+1\quad(1\le j\le q),&v&=p+q+3,\\
w&=v+1,&z&=w+h-2,&r&=z.
\end{split}                                                   \tag{12}
\]
Make precisely \(B_1,B_{a_1},\ldots,B_u,
B_{d_1},\ldots,B_v,B_w,\ldots,B_z\) vacant; only
\(B_2,B_{u+1}\) are short among the internal blocks.
Retain all standard free links except \(P_1,P_u\), and
add the edges (3). They pair every free slot once and join
opposite old-cycle colours. In the disk opposite the site
face, \(H_1I_z\) surrounds the other free chords,
\(I_1H_w\) surrounds both port components, and each port's
outer edge surrounds its own successive inner edges.
The retained links occupy disjoint or nested intervals.
The old site edges therefore remain cofacial in a plane
bipartite cubic graph.

Retained ordinary links join the face chords in the chains
\(B_2,\ldots,B_u\) and \(B_{u+1},\ldots,B_z\).
The edge \(e_1I_u\) attaches \(B_1\) to the first chain,
and \(e_uI_v\) joins the two chains. Every other edge of
(3) interlaces an endpoint face chord. The retained end
links attach Note 281's unchanged site and residual-square
closing chain. Thus the full matching-chord interlacement
graph is connected; Notes 217 and 182 give three-vertex
connectivity. The Barnette parent and legal Hamiltonian
child have, respectively,
\[
           6(h+p+q)+20,\qquad 6(h+p+q)+24            \tag{13}
\]
vertices. The first case \(h=2,p=q=1\) has 44 and 48
vertices.

The theorem handles two nonconsecutive missing links in the
specified nested boundary chain. It does not classify all
two-defect free groups, other opening shapes, or the full
Barnette conjecture.
