> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All one-chord eight-free square-trap children are Hamiltonian

[Note 200](200-middle-block-near-equality-hamilton-routes-and-the-two-deep-side-obstruction.md)
classifies the six-free-slot matchings when the unique vacant eligible
position lies in the middle face-chord block and the target order is
tight. Its three patterns use cross-block chords. Such a chord cannot
straddle any escape target: both it and that target's edge to a
residual square lie on the side of the old Hamilton cycle opposite
the designated common face. This excludes all three patterns in
their respective necessary target configurations. Combined with
[Note 202](202-one-chord-eight-free-openings-reduce-to-a-deep-middle-route.md),
it closes the entire first boundary above equality for one
opposite-face chord.

Let \(G\) be a three-connected cubic bipartite plane graph with
Hamilton cycle \(C\), complementary perfect matching \(M\), and
disjoint cofacial site edges \(q=xy,p=uv\in M\) avoided by \(C\).
Assume a selected all-square facial opening has \(r=1\) matching
chord on the other site-face arc, \(f=8\) free main vertices,
and \(\ell\ge1\) residual-square lobes. Compress every lobe
as in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).

**Cross-block no-straddling lemma.** Let \(s<t\) be free slots in
different main-segment blocks or gaps. If an escape target \(T\)
lies strictly between them along the main \(x\)-to-\(v\) segment,
then \(st\notin M\).

**Proof.** Note 193 puts any cross-atom free matching edge on the
side of \(C\) opposite the designated common face. Note 177 puts
the escape edge \(Tw\), where \(w\) is on the complementary
\(C\)-arc, on that same side. The four endpoints occur in the
cyclic order \(s,T,t,w\) on \(C\). The two chords would cross in
the disk on that side. Planarity excludes \(st\). \(\square\)

**Eight-free one-chord Hamilton theorem.** The parent \(G\) has
a Hamilton cycle containing both site edges \(p,q\). Thus every
legal site-expanded child admitting the opening above is
Hamiltonian, for every \(\ell\ge1\) and every positive length
of the original square-trap lobes. Consequently a
non-Hamiltonian child with an all-square opening and one
opposite-face chord must have at least ten free main vertices.

**Proof.** Note 198 makes both interblock gaps empty. At
\(r=1,f=8\), Note 197's defect budget allows at most one
endpoint or consecutive-lobe transition defect. Note 201 gives
a parent cycle through \(p,q\) for either endpoint defect.
Note 202 handles the transition defect and every no-defect
opening whose sole vacant eligible even slot lies in an outer
block. Its outer-vacancy proof explicitly gives a reduced parent
cycle through \(p,q\); its transition-defect proof either
reaches Note 201 or rules out the last configuration. Every
boundary peel used there is the simple incident-edge inverse of
Notes 185--186. In the cubic reduced parent, every Hamilton
cycle uses at least one of the two restored incident edges, so
Note 185's forward lift applies. It leaves all other edges,
including \(p,q\), unchanged. Thus those two branches also have
parent cycles through \(p,q\). It remains to consider tight endpoints,
tight transitions, and a vacancy in the middle block \(B_1=[a,b]_C\).

Use Note 200's notation for its six free slots in \(C\)-order:
\[
e,\ g,\ h,\ i,\ j,\ z,
\tag{1}
\]
where \(e\in B_0=[x,y]_C\), \(g,h,i,j\in B_1\), and
\(z\in B_2=[u,v]_C\). The vacant even slot is \(h\), and
\(hi\in E(C)\). Note 200's exhaustive bipartite matching
classification leaves only
\[
\begin{array}{c|c}
\text{left}&ei,\ gh,\ jz\\
\text{right}&eg,\ hz,\ ij\\
\text{double inner}&ez,\ gh,\ ij.
\end{array}
\tag{2}
\]

In the left pattern, \(gh\in M\). Because \(g,h\) lie in
the same block, \(gh\) cannot duplicate a cycle edge;
there is at least one intervening adjacent target pair
\(L_t,R_{t-1}\) between them. The cross-block edge \(ei\)
straddles that pair, contradicting the no-straddling lemma.

In the right pattern, \(ij\in M\), so at least one such
target pair lies strictly between \(i,j\). The cross-block
edge \(hz\) straddles it, again impossible.

In the double inner pattern, both \(gh,ij\in M\), so either
one of their intervening target pairs lies strictly between
\(e,z\). The cross-block edge \(ez\) is impossible. Thus no
complementary perfect matching realizes the remaining
middle-vacancy configuration. All actual configurations have
parent cycles through \(p,q\) by the cited results and marked
boundary lifts. Note 001 lifts such a cycle through the site
expansion. Note 178 transfers the marked Hamilton route back
from compressed lobes of length one to the original positive
lobe lengths. The free-vertex count is even,
and Note 195 sets its one-chord minimum at six; after excluding
both six as a possible non-Hamiltonian case by Note 196 and
eight here, a non-Hamiltonian one-chord all-square opening
requires \(f\ge10\). \(\square\)

This theorem applies to children admitting the specified
all-square facial opening. It does not claim that every
Barnette graph admits one, and it does not settle Barnette's
conjecture.

For context, Schnieders (2025, arXiv:2508.03531v1,
Theorem 5.2) proves Hamiltonicity when every face has size
at most eight. The theorem above assumes no face-size bound
and supplies a Hamilton parent cycle through two specified
site edges, but requires the chosen all-square opening and
the one-chord eight-free count. The statements have different
hypotheses and conclusions; no literature-novelty claim is
made here. The cited preprint and Gorsky--Steiner--Wiederrecht
(2023, DOI 10.1016/j.disc.2022.113249) were checked on
2026-09-29 for the broader conjecture and its brace setting.
