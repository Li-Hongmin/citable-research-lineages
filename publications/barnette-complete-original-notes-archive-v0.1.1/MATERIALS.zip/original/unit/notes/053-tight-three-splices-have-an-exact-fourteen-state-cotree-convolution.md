> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Tight three-splices have an exact fourteen-state cotree convolution

[Note 052](052-paid-exit-discharge-is-degree-constrained-cotree-fragmentation.md)
identifies binary common-base support with the fragmentation of a
degree-constrained spanning cotree after deleting a set of zero-cost
vertices. This note gives the exact composition law across a tight
\(3\)-splice. Each factor contributes a fourteen-entry cap-conditioned
forest profile, and the global minimum is a finite min-plus convolution
over seventeen compatible pairs. Ordinary scalar factor minima do not
contain enough port information: an integral profile countermodel has
safe marginals but a strict one-unit splice deficit.

## Splice and local cotree data

Let \(F_1,F_2\) be simple plane cubic bipartite graphs, choose vertices
\(r_i\in V(F_i)\), and write

\[
P_i=F_i-r_i,\qquad
N_{F_i}(r_i)=\{t_{i1},t_{i2},t_{i3}\}.
\]

After fixing a port bijection, form

\[
F=P_1\cup P_2+\{e_j=t_{1j}t_{2j}:j\in[3]\}.
\tag{1}
\]

Choose the factor bipartitions so that each \(e_j\) joins the two global
colour classes \(X,Y\). Let \((u,v,z,a)\) be any ordered legal site of
\(F\), put \(p=uv\), \(q=za\), and define

\[
d(x)=2-\mathbf 1_{\{x=z\}}\qquad(x\in X).
\tag{2}
\]

By Note 052, a site-admissible cotree must contain

\[
E^+=
\bigl(\delta_F(u)\setminus\{p\}\bigr)
\cup
\bigl(\delta_F(a)\setminus\{q\}\bigr)
\tag{3}
\]

and avoid \(E^-=\{p,q\}\). This formulation allows site vertices or
distinguished edges to meet the splice: a splice edge in \(E^+\) is forced
used, while one in \(E^-\) is forced absent.

## Fourteen cap states

Let \(\varnothing\ne S\subseteq[3]\) be the indices of splice edges used
by the cotree, and let \(\pi\) be a set partition of \(S\). Define
\(\mathcal F_i(S,\pi)\) to be the spanning forests \(J_i\) of \(P_i\)
satisfying:

1. every component of \(J_i\) contains a selected port \(t_{ij}\) with
   \(j\in S\), and connectivity of those ports induces exactly \(\pi\);
2. for every \(x\in X\cap V(P_i)\),
   \[
   \deg_{J_i}(x)
   =d(x)-\mathbf 1_{\{x=t_{ij}\text{ for some }j\in S\}};
   \tag{4}
   \]
3. the internal edges in \(E^+\) are present and those in \(E^-\) are
   absent, with the corresponding inclusion or exclusion imposed on \(S\)
   for forced splice edges.

An unselected port need not be assigned a state: it cannot participate in
the quotient gluing, while the condition that every component meets \(S\)
excludes hidden components. Thus the natural exact state is

\[
(S,\pi),\qquad
\varnothing\ne S\subseteq[3],\quad \pi\in\Pi(S).
\tag{5}
\]

There are

\[
3B_1+3B_2+B_3=3+6+5=14
\tag{6}
\]

states per factor.

Fix a hole set \(H\subseteq Y\setminus\{a\}\), put
\(H_i=H\cap V(P_i)\), and define the cap profile

\[
\Omega_i(S,\pi;H_i)
=
\min_{J_i\in\mathcal F_i(S,\pi)}
\sum_{y\in H_i}\deg_{J_i}(y),
\tag{7}
\]

with value \(+\infty\) for an infeasible state.

## Seventeen compatible pairs

For partitions \(\pi_1,\pi_2\) of the same \(S\), form a bipartite
multigraph \(K(S;\pi_1,\pi_2)\). Its vertices are the blocks of
\(\pi_1\) and \(\pi_2\), and its edge labelled \(j\) joins the two blocks
containing \(j\). Call the pair compatible when \(K\) is a tree.

There are exactly seventeen compatible signatures:

- three for \(|S|=1\);
- six for \(|S|=2\), with one partition indiscrete and the other discrete;
- eight for \(|S|=3\): the two one-block/three-block orientations and the
  six ordered pairs of distinct two-block partitions.

> **Splice gluing bijection.** Restriction gives a bijection
> \[
> T\longleftrightarrow(S,J_1,J_2)
> \tag{8}
> \]
> between site-admissible cotrees of \(F\) and triples with compatible
> states \((S,\pi_1,\pi_2)\) and
> \(J_i\in\mathcal F_i(S,\pi_i)\). Under this bijection,
> \[
> T=J_1\cup J_2\cup\{e_j:j\in S\}.
> \tag{9}
> \]

Restriction of a global tree to either shore is a forest, and every
component must meet a used splice edge. Contracting the shore components
turns the used splice edges into \(K(S;\pi_1,\pi_2)\), which must be a
tree. Equations (3)--(4) are exactly the restricted degree and forced-edge
conditions. Conversely, a tree quotient joins the local forests into a
connected acyclic spanning graph with all the conditions of Note 052.

## Exact min-plus convolution

For each splice edge let \(y_j\) be its global \(Y\)-endpoint, and put

\[
D=\{j\in[3]:y_j\in H\},\qquad h=|H|.
\tag{10}
\]

The local forests contribute the two terms in (7). A used splice edge
contributes one further unit to the total hole degree exactly when its
\(Y\)-endpoint lies in \(H\). Hence

\[
\Theta_H(F_1,F_2)=
\min_{\substack{(S,\pi_1,\pi_2)\\\text{compatible}}}
\left[
\Omega_1(S,\pi_1;H_1)
+\Omega_2(S,\pi_2;H_2)
+|S\cap D|
\right].
\tag{11}
\]

Since \(H\) is independent, Note 052 gives

\[
\boxed{
\min_{T\in\mathcal T_{u,v,z,a}(F)}
\operatorname{comp}(T-H)
=1-h+\Theta_H(F_1,F_2).}
\tag{12}
\]

Equivalently, if

\[
M_i(S,\pi;H_i)
=
\min_{J_i\in\mathcal F_i(S,\pi)}
\operatorname{comp}(J_i-H_i),
\]

then compatibility implies
\(|\pi_1|+|\pi_2|=|S|+1\), and (12) becomes

\[
\min_{\mathrm{compatible}}
\left[M_1+M_2-|S\setminus D|\right].
\tag{13}
\]

Every surviving used splice edge is a bridge of \(T-H\), so the
subtraction in (13) is exact.

Let

\[
\epsilon=\mathbf 1_{\{v\in H\}}.
\]

Combining (12) with Note 052(6) yields the sharp support criterion

\[
\boxed{
\text{binary support at }(F;u,v,z,a,H)
\iff
\Theta_H(F_1,F_2)\le 2h-\epsilon.}
\tag{14}
\]

For the normalized overhead of Note 052, put
\(g_i=\operatorname{comp}(P_i-H_i)\). Partition the surviving ports on
each shore according to their connectivity in \(P_i-H_i\), and let
\(r_H\) be the graphic rank of their full-shore incidence multigraph.
Then

\[
\operatorname{comp}(F-H)=g_1+g_2-r_H
\]

and

\[
\boxed{
\eta_H(F;u,v,z,a)
=\Theta_H+1-h-g_1-g_2+r_H.}
\tag{15}
\]

The full-shore post-hole partitions are needed only for the baseline in
(15); they cancel from the support decision (14).

## Scalar factor minima are insufficient

The convolution cannot be replaced by one ordinary scalar minimum from
each factor. This already fails in an integral abstract cap profile.

Take the orientation in which \(r_1\in X\), \(r_2\in Y\), the site lies
in \(P_1\), and \(z\in P_1\). Let one nonport hole lie on each shore,
with the left hole equal to \(v\). Thus \(h=2\), \(\epsilon=1\), no port
is deleted, and the permitted component count is two.

The degree equations force \(J_1\) to have two components and
\(J_2\) to have \(|S|-1\) components. Therefore:

- for \(|S|=2\), the left partition is discrete and the right partition
  is indiscrete;
- for \(|S|=3\), both partitions have two blocks, and writing
  \(\pi_i=\{\{i\},[3]\setminus\{i\}\}\), compatibility is exactly
  \(i\ne j\).

Normalize local fragmentation by

\[
f=\operatorname{comp}(J_1-H_1)-2,
\qquad
g=\operatorname{comp}(J_2-H_2)-|S|.
\tag{16}
\]

Because all used splice edges survive,

\[
\operatorname{comp}(T-H)=2+f+g.
\tag{17}
\]

Assign the following finite profile values:

- for every two-edge state, \(f=0\) and \(g=1\);
- for the three-edge states,
  \[
  (f(\pi_1),f(\pi_2),f(\pi_3))
  =(g(\pi_1),g(\pi_2),g(\pi_3))
  =(0,1,1).
  \tag{18}
  \]

Both ordinary marginal minima are zero. In every two-edge gluing the sum
is \(0+1=1\). In a three-edge gluing the two zero states form the forbidden
diagonal pair \((\pi_1,\pi_1)\), so

\[
\min_{i\ne j}\bigl(f(\pi_i)+g(\pi_j)\bigr)=1.
\tag{19}
\]

Thus every compatible global state has at least three components after
deleting \(H\), although the budget is two. The abstract splice deficit is
one, the smallest positive integral value. Every positive finite entry in
(18), together with each positive two-edge right value, is load-bearing:
lowering it by one opens a zero-defect compatible pair.

At the scalar abstraction, a single all-one ordinary load vector can
witness every binary layer at equality, so allowing all ordinary layers
does not recover the discarded port correlation. This remains only a
logical profile countermodel. It does not assert that the displayed values
are simultaneously realized by forests in actual cubic factors.

The finite state count, all seventeen compatibility pairs, and the
abstract profile are checked by

    python3 \
      units/barnette/computations/verify_three_port_cotree_convolution_boundary.py

with terminal marker
THREE_PORT_COTREE_CONVOLUTION_BOUNDARY_VERIFIED.

## Remaining boundary

Equations (11)--(15) are an exact composition theorem, not a preservation
theorem. The scalar route is closed: separate ordinary factor support plus
tree-gluing arithmetic cannot prove tight-splice closure. The remaining
mathematical question is now precise:

> Which inequalities are forced on the fourteen values
> \(\Omega_i(S,\pi;H_i)\) by one actual simple plane cubic bipartite
> factor?

A positive result must prove enough cap flexibility to make one of the
seventeen sums in (11) meet (14). A negative result must realize an
over-budget pair of cap profiles in actual factors. No further graph-order
scan is needed until one of those profile mechanisms is identified.
