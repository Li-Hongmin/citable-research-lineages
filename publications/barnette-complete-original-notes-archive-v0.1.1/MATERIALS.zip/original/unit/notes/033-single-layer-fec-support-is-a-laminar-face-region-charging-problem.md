> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-layer FEC support is a laminar face-region charging problem

[Note 032](032-common-cubic-hamilton-incidence-does-not-force-the-fec-support-bound.md)
shows that common cubic Hamilton incidence does not force the full weighted
support inequality from
[Note 031](031-remote-h-plus-minus-and-faithful-completion-leave-a-common-realization-interface.md).
This note restricts to one \(0/1\) layer, derives its exact
matroid-intersection dual, and identifies the remaining ambient assertion.
The obstruction is a laminar family of face regions, not a primal bond.

## The single-layer minimum

Use the notation of Notes 028 and 031.  For

\[
 A\subseteq Y\setminus\{a\},
 \qquad
 c_e=\mathbf1_{\{y(e)\in A\}},
\]

put

\[
 \mu(A)=
 \min\{|S\cap\delta_K(A)|:
 S\in\mathcal B(\mathcal P_X)
       \cap\mathcal B(\mathcal G_Q)\}.
 \tag{1}
\]

The desired single-layer assertion is

\[
 \mu(A)\le |A|.
 \tag{2}
\]

It remains undecided under all plane-brace and global-\(H^{+-}\)
hypotheses.

Write \(D_x=\delta_K(x)\) for \(x\in X\setminus\{u\}\), and let
\(n=|V(Q)|\).  The common-base polytope is

\[
\begin{aligned}
 x(D_x)&=1
 &&(x\in X\setminus\{u\}),\\
 x(E_Q(W))&\le |W|-1
 &&(\varnothing\ne W\subsetneq V(Q)),\\
 x_e&\ge0.
\end{aligned}
\tag{3}
\]

The block equations already imply \(x(E(Q))=n-1\), so the full-set
graphic equation must not be added independently.  Singleton graphic
constraints are vacuous because \(Q\) has no loops.  The polytope (3) is
integral by the matroid-intersection theorem.

## Exact dual and laminarization

Give each block equation a free dual variable \(\alpha_x\) and each proper
graphic-rank inequality a nonnegative variable \(z_W\).  Linear
programming duality gives

\[
 \boxed{
 \mu(A)=
 \max_{\alpha,\,z\ge0}
 \left[
   \sum_x\alpha_x-
   \sum_W z_W(|W|-1)
 \right]}
 \tag{4}
\]

subject to

\[
 \alpha_{x(e)}-
 \sum_{W:e\in E_Q(W)}z_W
 \le c_e
 \qquad(e\in E(K)).
 \tag{5}
\]

For fixed \(z\), the optimal block potential is

\[
 \alpha_x=
 \min_{e\in D_x}
 \left(c_e+
       \sum_{W:e\in E_Q(W)}z_W\right).
\]

Hence

\[
 \boxed{
 \mu(A)=
 \max_{z\ge0}
 \left\{
 \sum_x\min_{e\in D_x}
 \left(c_e+
       \sum_{W:e\in E_Q(W)}z_W\right)
 -\sum_Wz_W(|W|-1)
 \right\}.}
 \tag{6}
\]

The usual uncrossing makes the positive support of \(z\) laminar.  For two
crossing sets, replacing equal weight on them by weight on their
intersection and union weakly relaxes (5) and preserves the rank penalty.
If the union is all of \(V(Q)\), its full-set variable is absorbed by
subtracting the same amount from all \(n-1\) block potentials.  Thus an
optimal dual exists on a laminar family of proper vertex sets.

## The exact ambient charging inequality

Each \(W\subseteq V(Q)\) lifts through the contraction of
\(p^*,h^*\) to a saturated set of faces of \(F\).  Define the depth of a
retained edge by

\[
 \ell_z(e)=
 \sum_{W:e\in E_Q(W)}z_W.
 \tag{7}
\]

Equation (6) shows that (2) is equivalent to

\[
 \boxed{
 \sum_x\min_{e\in D_x}
 \bigl(\mathbf1_A(y(e))+\ell_z(e)\bigr)
 \le
 |A|+
 \sum_Wz_W(|W|-1)}
 \tag{8}
\]

for every \(A\), every laminar family of saturated face regions, and every
nonnegative \(z\).

The boundary \(\delta_Q(W)\) is a cut in the contracted dual.  After the
special incidences are restored, its primal edges form an Eulerian cycle
or an edge-disjoint union of cycles.  They do **not** generally form a
primal bond.  Consequently, lower-bounding a bond size or invoking brace
connectivity alone cannot prove (8).  Four-connectivity controls the
lengths of these Eulerian boundaries but does not by itself charge the
cheapest side of every triangle, path, or parallel-pair block across a
nested family.

This corrects the tempting reduction

\[
 \text{strict layer defect}
 \Longrightarrow
 \text{proper }1\text{- or }2\text{-edge cut}.
\]

The dual certificate supplies a face-region cycle system, not such a cut.

## The lower-level two-cut model

The plane-cubic lower-level countermodel of Note 030 realizes one strict
single-layer certificate.  At

\[
 (u,v,z,a)=(14,15,8,9),
 \qquad
 A=\{1,3,5,7,11,13\},
\]

all 112 \(X\)-graphic bases have cost 7, and therefore

\[
 \mu(A)=7>|A|=6.
 \tag{9}
\]

Let \(W\) consist of the contracted special-face root and the dual vertex
of the face

\[
 (0,1,6,7,8,11,12,15).
\]

Setting

\[
 z_W=1,
 \qquad
 \alpha_8=2,
 \qquad
 \alpha_x=1\quad(x\ne8)
 \tag{10}
\]

satisfies (5) and has dual value

\[
 8-(|W|-1)=7.
\]

The region contains the two remote cut edges \(0\,15\) and \(7\,8\), so
this particular violation is excluded by the brace hypothesis.  Its
one-region form, however, does not imply that every laminar violation is
caused by a two-edge cut.

## Decision boundary

The single-layer question is now exactly (8).  A positive proof must use
the literal two-colour rotations of one simple 4-connected Eulerian
triangulation to charge all nested face regions.  A counterexample must
realize a strict laminar certificate while retaining the full plane-brace
and global-\(H^{+-}\) hypotheses.  Boundary length, Hall coverage,
fixed-source edge coverage, and a bond reinterpretation do not decide it.

No arbitrary-weight or all-one-fibre integrality conclusion follows from
this note.

The fixed certificate is reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-barnette/single-layer-cut-rank-boundary.py
```

with terminal marker `SINGLE_LAYER_CUT_RANK_BOUNDARY_VERIFIED`.
