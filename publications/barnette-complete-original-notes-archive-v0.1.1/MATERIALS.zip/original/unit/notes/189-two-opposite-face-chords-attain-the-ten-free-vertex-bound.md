> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two opposite-face chords attain the ten-free-vertex bound

[Note 188](188-multiple-opposite-face-chords-need-six-extra-free-vertices.md)
proves that two matching edges on the opposite site-face arc
require at least ten free vertices on the main segment of an
all-square facial opening. This bound is attained within the
Barnette class. For multiple lobes, the construction is a legal
\(C_4\)-expansion of a *different* pair of edges on an inner
face of the sharp family of
[Note 182](182-two-long-facial-gaps-require-six-free-main-vertices.md).
The single-lobe base comes from
[Note 184](184-every-sharp-square-trap-opening-has-a-hamiltonian-child.md).

**Sharpness theorem.** For every lobe count \(\ell\ge1\),
there is a Barnette parent \(G_\ell\) with a Hamilton cycle
\(C'_\ell\) avoiding disjoint cofacial site edges
\(q=xy,p=uv\), such that the legal site-expanded child is
also Barnette and its selected facial opening has exactly
\(\ell\) residual squares. The old main segment has
\[
|V(S_0)|=2\ell+14,
\qquad f=|V(S_0)|-2\ell-4=10,
\tag{1}
\]
and the other site-face arc has exactly two matching edges.
The parent has a Hamilton cycle containing both \(p,q\),
so the child is Hamiltonian. Each residual square may be
replaced by an arbitrary positive-length square-trap lobe
without changing (1) or the two-chord count.

**Construction and proof for \(\ell\ge2\).** Start with the reduced Barnette
graph \(B_\ell\) in Note 182, equations
(5)--(8). On its old Hamilton cycle \(C_\ell\), the
relevant main vertices occur in the order
\[
y,a,b,L_2,R_1,c,d,u.
\tag{2}
\]
The complementary matching includes \(ad,sb,ct\), with
\(ad\) on the common-face side of \(C_\ell\), while
\(sb,ct\) and all escape edges lie on the opposite side.
Consequently
\[
a,b,L_2,R_1,c,d,a
\tag{3}
\]
is a facial hexagon: the chord \(ad\) cuts off this
target-free-of-face-chords \(C_\ell\)-interval, and no
other matching edge enters its disk on that side. The
two disjoint edges \(ad\) and \(bL_2\) lie on this face.
Starting with \(ad\), their endpoints occur on the face
in the cyclic order \(a,d,L_2,b\); the complementary
arcs have lengths three and one. Also \(a,L_2\) have one
bipartite colour and \(d,b\) the other. Thus they form a
legal \(C_4\)-expansion site on this inner face.
Indeed, along \(S_0\) from \(x\), the indices of
\(a,b,L_2\) are \(2\ell,2\ell+1,2\ell+2\), respectively.
In particular \(bL_2\) has odd starting index.

Delete \(ad,bL_2\), add four vertices
\(\xi,\eta,\zeta,\omega\), and add exactly
\[
a\xi,\quad\xi\eta,\quad\eta d,\quad
L_2\zeta,\quad\zeta\omega,\quad\omega b,
\quad\xi\omega,\quad\eta\zeta.
\tag{4}
\]
This is Note 001's square expansion with
\((u,v,x,y)=(a,d,L_2,b)\). Embed it in the hexagonal face
with square boundary order \(\xi,\eta,\zeta,\omega\).
The old site edges \(p,q\) are untouched. Its common
face now has the \(y\)-to-\(u\) arc
\[
y,a,\xi,\eta,d,u,
\tag{5}
\]
whose edges alternate \(C'_\ell,M',C'_\ell,M',C'_\ell\),
with matching edges \(a\xi,\eta d\). The other site-face
arc from \(v\) to \(x\) is unchanged and has one matching
edge per residual square.

Replace the edge \(bL_2\) of \(C_\ell\) by
\[
b,\omega,\xi,\eta,\zeta,L_2.
\tag{6}
\]
Every transition is an edge of (4), so this gives a
Hamilton cycle \(C'_\ell\) of the new parent, still
avoiding \(p,q\). Its complementary matching differs
from the old one only by replacing \(ad\) with
\(a\xi,\eta d,\zeta\omega\). All four new vertices lie
on \(S_0\), while the \(\ell\) residual squares, their
escape targets, and the selected opening remain otherwise
unchanged. Note 182 gives \(|S_0|=2\ell+10\) before the
insertion, proving (1) and the two-chord count.

The new parent is simple, cubic, bipartite and plane by
the displayed legal face insertion. For completeness,
three-edge-connectivity follows from the square-patch cut
argument of Note 182: a cut of size at most two with all
four new vertices on one shore projects to a cut of no
larger size in \(B_\ell\), unless all old vertices are on
the other shore, when four attachment edges cross. If the
new square is split, its internal cut has at least two
edges. A cut of size at most two would therefore have
exactly two internal square edges and no attachment or
old edge crossing. Each shore then contains an old
vertex, because every square vertex has an attachment;
their cut in \(B_\ell\) could use only the two deleted
edges \(ad,bL_2\), contradicting three-edge-connectivity.
The cubic argument of Note 182 upgrades this to
three-vertex-connectivity. The untouched edges \(p,q\)
remain cofacial by (5) and the unchanged other arc, so
their square expansion is legal and Barnette by the same
patch-cut argument.

Finally, Note 182's second Hamilton cycle of \(B_\ell\)
contains every complementary-matching edge, including
\(ad,p,q\), and uses the even-indexed \(C_\ell\)-edges.
For \(\ell=2\), this is the explicit cycle (10) of that
note. Its six-vertex induction replaces the even-indexed
edge \(xR_\ell\) by route (11), alternating new matching
edges with new even-indexed cycle edges; the two new main
vertices shift all retained indices by two. Thus the stated
matching/even-edge property holds for every \(\ell\).
The odd-indexed edge \(bL_2\) is therefore avoided. Replace
the second cycle's edge \(ad\) by the
spanning gadget route
\[
a,\xi,\omega,\zeta,\eta,d.
\tag{7}
\]
This is a Hamilton cycle of the new parent containing
both original site edges \(p,q\). Note 001's direct lift
therefore gives a Hamilton cycle of the site-expanded
child. Note 178's even-ladder replacement preserves the
Barnette class, both site edges, the marked Hamilton
cycles, and the opposite face arc, giving arbitrary
positive lobe lengths.

**Single lobe.** Use Note 184's same-gap core, which is the
one-lobe sharp parent of Note 181. Its main segment is
\[
x,R,s,y,a,b,c,d,u,t,L,v,
\tag{8}
\]
with a residual square on the complementary cycle arc.
The matching is explicitly listed in Note 184, equation
(4), and includes \(ad,p,q\). The quadrilateral
\(a,b,c,d,a\) is a face: \(ab,bc,cd\) are consecutive
cycle edges and \(ad\) is the face-side matching chord.
Expand its disjoint opposite edges \(ad,bc\) exactly as
in (4), replacing \(L_2\) there by \(c\). The old cycle
replaces \(bc\) with
\(b,\omega,\xi,\eta,\zeta,c\), and the new opposite
site-face arc is again (5). The main segment grows from
12 to 16 vertices, so \(f=16-2-4=10\).

The second Hamilton cycle (5) of Note 184 uses all matching
edges and all even-indexed old cycle edges. Here \(b\) has
index five, so it avoids \(bc\) while containing \(ad,p,q\).
Replacing \(ad\) by (7) gives a second Hamilton cycle in
the expanded parent, still containing \(p,q\).
The same face insertion and square-patch cut proof above
preserve Barnette membership and legality of the original
site expansion. Its child is Hamiltonian by Note 001.
Note 178 again gives arbitrary positive lobe length.
\(\square\)

The theorem makes Note 188's bound sharp for \(r=2\) and
every \(\ell\ge1\). It does not establish sharpness for
\(r>2\), nor does it settle the Hamilton decision for
every ten-free-vertex opening.
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
subsequently settles this equality Hamilton decision and
its analogue for every opposite-face chord count.
