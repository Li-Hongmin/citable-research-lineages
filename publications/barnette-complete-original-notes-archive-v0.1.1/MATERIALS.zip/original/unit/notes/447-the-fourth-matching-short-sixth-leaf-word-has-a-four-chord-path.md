> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's short-sixth-leaf word has a four-chord path

The row-IV word in [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,7)\), short leaf \(6\), and depth vector \((1,2,4,4,4,5,5)\) has a spanning marked path. It uses four row-IV face chords. The same ordinary word appears in row I of [Notes 427--428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), but the row-I path uses a face chord absent from row IV.

Use [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md)'s full-leaf paths \(Y_i,X_i\) and bracket paths \(P_H,Q_H\). Define two additional paths by
\[
Z_i=(x_i,h_i,L_i,R_i,j_i,y_i)\quad(i=3,4),\qquad
H_A=(\rho_0^A,\rho_1^A,\rho_2^A,
\lambda_2^A,\lambda_1^A,\lambda_0^A).
\tag{1}
\]
Each \(Z_i\) spans a full leaf using its outer ordinary chord; \(H_A\) spans the six brackets of \(A\) using their inner ordinary chord. Put
\[
\begin{aligned}
S_6&=(L_6,x_6,y_6,R_6),& A&=F(U_3,U_4),& D&=F(S_6,U_7),\\
B&=F(U_5,D),& C&=F(A,B),& E&=F(U_2,C),& W&=F(U_1,E).
\end{aligned}
\tag{2}
\]
These are the depths \((1,2,4,4,4,5,5)\). With ineligible leaves \(2,\ldots,6\), row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md) supplies \(y_2x_3,y_3x_6,x_4y_5,y_4x_5\).

**Marked-path theorem.** A spanning \(y_1\)--\(x_7\) path of \(W\) is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{Z_3}y_3,
x_6,y_6,R_6,L_6,
\lambda_2^D,\lambda_1^D,\lambda_0^D,
R_5,j_5,y_5,\\
&x_4\xrightarrow{Z_4}y_4,
x_5,h_5,L_5,
\lambda_2^B,\lambda_1^B,\lambda_0^B,
A_r=\rho_0^A\xrightarrow{H_A}\lambda_0^A=A_\ell,\\
&\lambda_2^C\xrightarrow{P_C}\rho_2^C,
B_r=\rho_0^B,\rho_1^B,\rho_2^B,
D_r=\rho_0^D,\rho_1^D,\rho_2^D,
R_7\xrightarrow{X_7}x_7.
\end{aligned}
\tag{3}
\]
The four nonordinary jumps, in path order, are exactly \(y_2x_3,y_3x_6,y_5x_4,y_4x_5\). The short-leaf segment \(x_6,y_6,R_6,L_6\) uses two old-cycle edges and the outer chord \(R_6L_6\). The two portions \(R_5,j_5,y_5\) and \(x_5,h_5,L_5\) partition \(U_5\).

Every other junction between displayed pieces is a consecutive old-cycle edge:
\[
\begin{gathered}
L_1\lambda_2^W,\quad \rho_2^W\rho_0^E,\quad
\lambda_2^EL_2,\quad L_6\lambda_2^D,\quad
\lambda_0^DR_5,\quad L_5\lambda_2^B,\\
\lambda_0^BA_r,\quad A_\ell\lambda_2^C,\quad
\rho_2^CB_r,\quad \rho_2^BD_r,\quad \rho_2^DR_7.
\end{gathered}
\tag{4}
\]
The paths \(Y_1,Y_2^{-1},Z_3,Z_4,X_7\) span five full leaves, and the two displayed portions span \(U_5\); hence the six full leaves contribute \(36\) vertices. The short leaf contributes four. The complete wrappers \(W,E,A,C\) contribute \(24\), while the left and right triples of \(B,D\) contribute twelve. These disjoint pieces total \(36+4+24+12=76\), all of \(W\), proving (3). \(\square\)

The two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), close (3) to a parent Hamilton cycle containing both site edges. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to a Hamilton cycle in every corresponding legal child. Reflection gives the row-V conclusion.

**Unique residual-word theorem.** Under the two-eligible, chorded single-hexagon \(f=7,c=31\) hypotheses of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md), a non-Hamiltonian legal child in face-matching row IV or V, if one exists, must have, up to reflection, sites \((1,2)\), short leaf \(3\), and ordinary depth vector \((3,5,5,4,2,2,2)\). Indeed Notes 433--436 reduce every possible row-IV/V failure to a short leaf; Note 437 gives the complete thirteen-word necessary list. Its own shared-chord corollary and Notes 438--447 supply spanning marked paths for the other twelve words, including the shared-chord corollary in Note 446. Each path closes through both site edges and lifts to a Hamilton cycle in the child. Reflection handles row V. This is a necessary condition only: no legal realization or non-Hamiltonian child with the residual word is asserted.

The residual word is closed by [Note 450](450-the-fourth-and-fifth-face-matchings-are-hamiltonian-in-the-two-eligible-kernel.md). Row VI, other kernel branches, and Barnette's conjecture remain unresolved.
