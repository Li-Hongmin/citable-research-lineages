> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Local special-face incidence does not force the FEC triple base

This note sharpens the three-matroid formulation of
[Note 028](028-direct-p-regime-target-is-a-three-matroid-common-base-problem.md).
It identifies the exact local blocks after the dual contraction, disproves
a natural monotone-exchange proof, and gives two countermodels showing that
local incidence and elementary matching coverage do not force a triple
common base.  The direct \(P\)-regime target remains open under the full brace
and global \(H^{+-}\) hypotheses.

## The contracted blocks

Let \(F\) be a plane cubic bipartite brace with bipartition
\(X\sqcup Y\), and let

\[
p=uv,\qquad h=za,\qquad u,z\in X,\quad v,a\in Y
\]

be disjoint cofacial edges.  Put \(K=F-\{u,a\}\), let
\(\Delta=F^*\), and define

\[
Q=(\Delta/\{p^*,h^*\})[E(K)^*].
\]

If \(c\) is the dual vertex of the common face, contracting the two
nonconsecutive sides \(p^*=cc_p\) and \(h^*=cc_h\) identifies
\(c,c_p,c_h\) to one root.  Restricting to \(E(K)^*\) deletes the duals of

\[
(\delta_F(u)\setminus\{p\})\cup
(\delta_F(a)\setminus\{h\}).
\]

Consequently, the block \(D_x\) of the \(X\)-partition matroid has exactly
one of the following forms:

1. the three sides of the triangular face dual to \(x\), when
   \(x\notin N_F(a)\);
2. a two-edge path, when \(x\in N_F(a)\setminus\{z\}\);
3. a parallel pair incident with the contracted root, when \(x=z\).

The \(Y\)-blocks are the reflected family: ordinary triangles, two-edge
paths at \(N_F(u)\setminus\{v\}\), and a parallel pair at \(v\).  When
\(u\sim a\), each side has one path exception instead of two.  No retained
edge becomes a loop.  The deleted primal edges form a forest, so planar
cycle--bond duality implies that \(Q\) is connected; its rank is \(m-1\),
where \(|X|=|Y|=m\).

Thus the useful shorthand that every partition block is a dual triangle is
false precisely at these path and parallel-pair exceptions.

## One-colour fundamental descent is not monotone

For

\[
S\in\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal G_Q),
\]

let

\[
\Phi(S)=\sum_{y\in Y\setminus\{a\}}
\left|\,|S\cap\delta_K(y)|-1\,\right|.
\]

The triple common bases are exactly the states with \(\Phi=0\).  Replacing
the selected edge in one \(X\)-block by another side that crosses its
fundamental tree cut preserves both the \(X\)-partition constraint and the
graphic-base constraint.  Nevertheless, \(\Phi\) is not a descent
potential for these moves.

For the order-\(16\) global-\(H^{+-}\) brace

```text
OlCGHD@?g?_@@@A?_?k?P
```

at \((u,v,z,a)=(15,14,13,4)\), the graph \(K\) is elementary: its eleven
perfect matchings cover all eighteen edges.  There are (112)
\(X\)-partition/graphic common bases and exactly one triple common base.
The one-block exchange graph is connected, but only (88) of the (112)
bases can reach the target without increasing \(\Phi\).  The other \(24\)
must first move uphill.  Of the three bases obtained directly from the
three global-\(H^{+-}\) source cycles by the fundamental replacement of
Note 028, two lie in this monotone trap.

Hence an arbitrary global-\(H^{+-}\) source does not supply a monotone
one-colour fundamental descent.  This does not exclude a theorem selecting
one suitable source or allowing nonmonotone moves.

## The target can be strictly exposed from all non-target loads

For an \(X\)-partition/graphic base \(B\), write its \(Y\)-load vector as

\[
d(B)_y=|B\cap\delta_K(y)|,\qquad y\in Y\setminus\{a\}.
\]

In the same order-\(16\) global-\(H^{+-}\) brace, order the \(Y\)-vertices
as

\[
(0,2,6,8,10,12,14)
\]

and put

\[
w=(0,1,3,2,-1,-2,-3).
\]

The unique triple base \(T\) satisfies \(d(T)=\mathbf1\), whereas every
other \(X\)-graphic base satisfies

\[
w\cdot(d(B)-\mathbf1)\ge1.
\]

Thus \(\mathbf1\) is a strictly exposed load of the unique target.  After
removing \(T\), it is not even in the convex hull of the other \(111\)
tree-base loads.  In particular, averaging any family of non-target source
bases cannot produce a fractional all-one load; such an averaging argument
would already have to include the target it is meant to prove.

The two countermodels have the opposite strict separation.  In the
six-element model, \(w=(-1,1,-1)\) gives margin \(2\) on every
\(X\)-graphic base.  In the real two-edge-cut model, with \(Y\)-order

\[
(1,3,5,7,11,13,15),
\]

the weight \(w=(1,1,1,1,1,1,-1)\) gives margin \(2\) on all \(112\)
\(X\)-graphic bases.  Here the separation records the cut obstruction:
every such base has zero load at \(v=15\).

Consequently, a weighted or Farkas-dual proof remains possible only if the
full ambient/global hypotheses rule out every separating weight.  Pairwise
base nonemptiness and convex averaging of already constructed sources do
not do so.

## A minimal local-block countermodel

There is a rank-three, six-element model satisfying the exact local block
types and all pairwise common-base conditions but having no triple common
base.  Let the row--column incidence graph be the elementary cycle \(C_6\),
with \(X\)-blocks

\[
\{e_0,e_1\},\quad\{e_2,e_3\},\quad\{e_4,e_5\}
\]

and \(Y\)-blocks

\[
\{e_0,e_2\},\quad\{e_3,e_4\},\quad\{e_1,e_5\}.
\]

Let \(Q_0\) have vertices \(A,B,C,D\) and edges

\[
e_0,e_1,e_2:AB,\qquad e_3:AC,\qquad e_4:CD,\qquad e_5:BC.
\]

The first block on each side is a parallel pair and the other blocks are
two-edge paths.  The sets

\[
\{e_0,e_3,e_4\},\qquad \{e_0,e_4,e_5\}
\]

are respectively \(X\)-graphic and \(Y\)-graphic common bases.  The two
row--column common bases are

\[
\{e_0,e_3,e_5\},\qquad \{e_1,e_2,e_4\}.
\]

The first is a triangle with one isolated vertex; the second contains two
parallel \(AB\)-edges and the disjoint edge \(CD\).  Neither is a spanning
tree.  Thus all three pairwise intersections are nonempty while the triple
intersection is empty.

This is minimal under the local axioms.  The case \(m=2\) cannot contain
two disjoint distinguished edges.  For \(m=3\), the nonadjacent case cannot
leave a 1-extendable reduced incidence graph; in the adjacent case
elementarity forces \(C_4\), and the single parallel-plus-path pattern on
each side forces one perfect matching to be a spanning tree.

The model does not assert that all six blocks extend simultaneously to one
simple 4-connected face-bicoloured Eulerian triangulation.  It therefore
isolates ambient completion as a genuinely additional global hypothesis.

## A real plane-cubic lower-level countermodel

The same failure occurs in an actual plane cubic bipartite incidence
system once the brace/global hypotheses are removed.  Take the Hamilton
cycle on \(0,\ldots,15\) and add the chords

\[
03,16,25,47,8\,11,9\,14,10\,13,12\,15.
\]

At \((u,v,z,a)=(14,15,8,9)\), the contracted graph \(Q\) and both partition
families arise from the construction above.  The graph \(K=F-\{14,9\}\)
is elementary, with twelve perfect matchings covering all nineteen edges,
and

\[
\begin{aligned}
|\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal G_Q)|&=112,\\
|\mathcal B(\mathcal P_Y)\cap\mathcal B(\mathcal G_Q)|&=112,\\
|\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal P_Y)|&=12,\\
|\mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal P_Y)
  \cap\mathcal B(\mathcal G_Q)|&=0.
\end{aligned}
\]

Equivalently, the four Hamilton-path counts after deleting \(p=14\,15\)
and \(h=8\,9\) are

\[
(H_{uv},H_{za},H_{vz},H_{ua})=(4,4,0,4).
\]

The precise missing hypothesis is witnessed by the two-edge cut

\[
\{0\,15,7\,8\}.
\]

The dual is therefore neither simple nor 4-connected, \(F\) is not a
brace, and global \(H^{+-}\) fails.  This is not a counterexample to the
direct \(P\)-regime theorem.

## Minimal repairs of the fixed two-edge cut

The Helly hole in the preceding graph does not survive either of two
minimal connectivity repairs.  Remove the cut
\(\{0\,15,7\,8\}\), choose one internal edge from each shore without
touching \(p\) or \(h\), and consider all \(11\cdot9=99\) choices.

For the unique bipartite cross 2-switch, \(95\) children remain simple,
cubic, and bipartite; eight are planar, four are 3-connected, and two
retain the ordered legal site.  Both legal children have five triple
common bases.

For the standard four-vertex \(C_4\) replacement, twelve children are
planar and 3-connected and ten retain the legal site.  All ten have global
\(H^{+-}\), each has \(24\) Hamilton-complement matchings, and each has
four or five triple common bases.  Thus none of the \(198\) fixed minimal
repairs retains a target-free legal instance.

This finite statement is not a general completion theorem.  It shows that
the concrete two-edge-cut obstruction cannot be promoted by the cheapest
single repair: a counterexample obtained from this mechanism would require
a nonminimal four-pole completion or more than one coupled obstruction.

## Remaining boundary

The following implication is false:

\[
\boxed{
\text{real local blocks + elementary matching family + pairwise bases}
\Longrightarrow \text{triple base}.}
\]

A positive proof of the direct target must use information not present in
that premise.  The surviving candidates are the simultaneous completion
of all blocks inside one simple 4-connected Eulerian triangulation and the
remote ordered-edge consequences of global \(H^{+-}\).  Ordinary Hall
coverage, local block type, exchange connectivity, and monotone defect
descent have all been separated from the required conclusion.

The local-block and descent claims are reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-barnette/verify_special_face_incidence_descent_boundary.py
```

with terminal marker

```text
SPECIAL_FACE_INCIDENCE_DESCENT_BOUNDARY_VERIFIED
```

The fixed-repair counts are reproduced by
[repair_fixed_two_cut_helly_model.py](../scratch/worker-barnette/repair_fixed_two_cut_helly_model.py),
whose terminal marker is `FIXED_TWO_CUT_REPAIR_AUDIT_OK`.
