> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The hI return branch of a single-double corridor is square-equivalent

[Note 382](382-isolated-single-double-corridors-couple-j0-and-j2-at-every-length.md)
reduces an isolated positive corridor between one singly vacant
and one doubly vacant target-free block to a rainbow double block
or a no-internal-chord branch. In the latter branch, the left
endport meets \(o\) or \(J\). When it meets \(J\), the chords
\(oK,Ez\) are forced and \(oe\) is absent. This note closes
the subbranch in which \(hI\) is the next return.

Use the same compressed, gapless, tight-target all-square
selected opening and block order
\[
 V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\qquad m\ge1.
\tag{1}
\]
There are no short flanks or other complete blocks in this
free group. Its even left and odd right endports are \(t,z\);
other free groups are unrestricted. Let \(M\) complement
the selected old Hamilton cycle.

For \(1\le r<m\), define the internal matching word
\[
\begin{split}
 M_{m,r}^{\circ}=\{&
 oK,hI,ep_1,iq_r,p_{r+1}H,q_mO\}\\
 &{}\cup\{q_jp_{j+1}:1\le j<m,\ j\ne r\}.
\end{split}                                                \tag{2}
\]
For \(r=m\), define
\[
 M_{m,m}^{\circ}
 =\{oK,hI,iH,ep_1,q_mO\}
   \cup\{q_jp_{j+1}:1\le j<m\}.                            \tag{3}
\]
The endport edges are \(tJ,Ez\) in every case.

**Exact \(hI\)-branch theorem.** Suppose an actual Barnette
parent has the opening (1), the double block has no internal
free matching chord, and \(tJ,hI\in M\). Then its entire
free-slot matching in this group is exactly
\[
                 \{tJ,Ez\}\cup M_{m,r}^{\circ}
       \quad\text{for one unique }r\in\{1,\ldots,m\}.
\tag{4}
\]
Conversely, every word (4) occurs in a Barnette parent
with a Hamilton cycle through both site edges and a legal
Hamiltonian site-expanded child. For every \(m,r\),
the induced \(14+4m\)-vertex disk patch on the blocks
in (1) has precisely the square's four spanning
one-path states and two spanning two-path states at
the terminals \((a,J,E,B)\). Replacing this patch
by the labeled square, or reversing the replacement,
preserves Barnette membership and every exterior-
and attachment-marked Hamilton decision. Hence no
vertex-minimal non-Hamiltonian Barnette graph contains
one of these induced patches.

**Classification.** Note 382 gives \(tJ,oK,Ez\in M\)
and \(oe\notin M\). All remaining free matching chords
lie opposite the common face. No two can interlace.
If a nonempty proper consecutive run of complete
short blocks is matched wholly within that run,
its two boundary old-cycle edges form a forbidden
two-edge cut.

The chord \(hI\) encloses exactly the ordered slots
\[
 i,e,p_1,q_1,\ldots,p_m,q_m,O,H.                            \tag{5}
\]
The odd slot \(i\) can meet only \(H\) or some \(q_r\).
If \(iH\) occurs, the slots inside \(iH\) are
\(e,p_1,q_1,\ldots,p_m,q_m,O\).
The leftmost slot \(e\) cannot meet \(p_k\) for \(k>1\)
or \(O\): the skipped complete short-block run
would match wholly within itself. Thus \(ep_1\)
is forced. The same argument successively forces
\(q_jp_{j+1}\) for \(j<m\) and \(q_mO\).
This is exactly (3).

Suppose instead \(iq_r\) occurs. Its interior is
\(e,p_1,q_1,\ldots,p_r\), so the same shortest-prefix
argument forces
\[
 ep_1,\quad q_jp_{j+1}\ (1\le j<r).                         \tag{6}
\]
Outside \(iq_r\), but still inside \(hI\), the even
slot \(H\) can meet only a \(p_k\) with \(k>r\);
\(OH\) is an old-cycle edge. In particular \(r<m\).
If \(k>r+1\), the complete run
\(S_{r+1},\ldots,S_{k-1}\) lies between the two
opposite-side chords and must match internally,
a forbidden two-edge cut. Hence \(p_{r+1}H\) occurs.
Its interior is \(q_{r+1},p_{r+2},q_{r+2},
\ldots,p_m,q_m,O\). The same shortest-prefix
argument forces
\[
 q_jp_{j+1}\ (r<j<m),\qquad q_mO.                           \tag{7}
\]
Equations (6)--(7) give exactly (2). The mate
of \(i\) determines \(r\), so the word is unique.
This proves the classification.

**All six Hamilton states.** The \(r=m\) pole is
the standard corridor pole \(R_m\) of Note 382,
already obtained from Note 380's fourteen-vertex
square pole by internal even-ladder replacements.
It has the full square signature and two-way
Barnette-class comparison. It remains to give
a direct certificate for \(r<m\).

Write \(W_{u:v}\), for \(u\le v\), for the path
\[
 (p_u,c_u,d_u,q_u,\ p_{u+1},c_{u+1},d_{u+1},q_{u+1},
       \ldots,p_v,c_v,d_v,q_v).                            \tag{8}
\]
Every block uses its old-cycle edges \(p_jc_j,d_jq_j\)
and face chord \(c_jd_j\); successive blocks meet
through the matching edge \(q_jp_{j+1}\).
Both \(W_{1:r}\) and \(W_{r+1:m}\) therefore exist.

The full old-cycle path from \(a\) to \(B\) is the
\(aB\) state. The following are spanning paths,
shown in endpoint orientation:
\[
\begin{array}{c|l}
JE&
 J,K,o,a,b,e,\ W_{1:r},\ i,h,I,H,\
 W_{r+1:m},\ O,A,B,E\\
aJ&
 J,E,B,A,O,\ \operatorname{rev}(W_{r+1:m}),\
 H,I,K,o,h,i,\ \operatorname{rev}(W_{1:r}),\
 e,b,a\\
EB&
 E,J,K,o,a,b,e,\ W_{1:r},\ i,h,I,H,\
 W_{r+1:m},\ O,A,B .
\end{array}                                                 \tag{9}
\]
For example, the joins at the split are
\(q_ri,\ hI,\ p_{r+1}H\) in the first row;
the reverse row uses the same three edges.
Every row covers the six vertices of \(V\),
the eight of \(D\), and both disjoint corridor
paths exactly once. Every consecutive pair is
an old-cycle edge, face chord, or a chord in (2).

For the pairing \(\{aJ,EB\}\), use the old-cycle
path from \(a\) through \(J\) and the edge \(EB\).
For \(\{aB,JE\}\), use the edge \(JE\) and the
part of the \(aJ\) row in (9) from \(B\) through
\(a\), reversing that path if desired. These
paths are disjoint and cover all patch vertices.
The terminal colours are \(a,E\) on one side
and \(J,B\) on the other, excluding the other
two one-path pairs. The third two-path pairing
interlaces the four disk terminals. Thus (9)
and the two path pairs give the complete square
signature.

**Barnette-class comparison.** Cap
\((a,J,E,B)\) by a fresh square with vertices
\((t_B,t_E,t_J,t_a)\) in that cyclic order,
attaching \(Bt_B,Et_E,Jt_J,at_a\).
The full old-cycle path through the patch,
followed by \(t_B,t_E,t_J,t_a,a\), is a
Hamilton cycle of this \(18+4m\)-vertex cap.
Its complementary matching consists of
the face chords \(ab,c_jd_j,AB,t_Bt_a\),
the internal chords (2), and \(Jt_J,Et_E\).
The face chords occupy one page of the
Hamilton cycle; the other chords are
nested or disjoint on the other page.
Every chord joins opposite Hamilton-cycle
parities, so the cap is simple, cubic,
bipartite and plane.

Here is a connected spanning subgraph of its
chord-interlacement graph without listing all
endpoint inequalities. Put
\(F_0=ab,F_j=c_jd_j\ (1\le j\le m)\),
and \(F_D=AB\). Every internal chord
joining slots in two blocks interlaces both
of their face chords. In (2),
\(ep_1\) joins \(F_0,F_1\);
\(iq_r\) joins \(F_0,F_r\);
\(p_{r+1}H\) joins \(F_{r+1},F_D\);
\(q_mO\) joins \(F_m,F_D\);
\(q_jp_{j+1}\) joins \(F_j,F_{j+1}\)
when \(j\ne r\); and \(oK,hI\) join
\(F_0,F_D\). These incidences connect every
\(F_j\) and every internal chord.
Both \(Jt_J,Et_E\) interlace \(F_D\) and
\(t_Bt_a\). Thus all complementary-matching
chords lie in one interlacement component.
A two-edge cut in a cubic Hamiltonian graph
would isolate a proper Hamilton-cycle interval
closed under its complementary matching,
contradicting this connectedness. The Hamilton
cycle excludes bridges. In a cubic graph,
three-edge-connectivity implies
three-vertex-connectivity; the cap is Barnette.

Deleting one vertex from the uncapped pole
leaves it connected. Each complete block is
a cycle and remains connected after one
deletion. The prefix \(V,S_1,\ldots,S_r\)
has two vertex-disjoint joins across each
adjacent block boundary:
\(bc_1,ep_1\), then
\(d_jc_{j+1},q_jp_{j+1}\) for \(j<r\).
The suffix \(S_{r+1},\ldots,S_m,D\)
has the analogous two joins
for \(j>r\), ending with
\(d_mA,q_mO\). The prefix and suffix
are each connected after one deletion,
and \(V,D\) remain joined by at least
one of the disjoint chords \(oK,hI\).
After deleting any two pole vertices,
every surviving component has a
surviving terminal: otherwise the same
deletions would disconnect the
three-connected cap. The square has
the same one- and two-deletion properties.
The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore proves three-connectivity in
both replacement directions. Terminal
colours and cyclic order preserve
bipartiteness and planarity. The
six-state signature proves the
exterior-marked Hamilton transfer.

**Realization and marked cycle.** Take Note 380's
26-vertex marked Barnette parent and replace its
four-terminal pole by the \(r<m\) pole just proved,
identifying \((a,J,E,B)\). The result has
\(26+4m\) vertices and is Barnette by the
two-way comparison. Its old Hamilton order is
\[
 x,R_1,e_0,y,\ V,S_1,\ldots,S_m,D,\
 u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x,
\tag{10}
\]
with the same exterior matching as Note 380,
and with (2) and the face chords inside the pole.
All cross-block chords stay on the opposite
page, so the site edges remain cofacial and
the selected opening is still gapless,
tight-target and all-square. In addition,
the union of these two internally disjoint
\(x\)--\(v\) paths is a marked Hamilton cycle:
\[
\begin{split}
 &x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
 &x,y,e_0,\ 
 J,K,o,a,b,e,\ W_{1:r},\ i,h,I,H,\
 W_{r+1:m},\ O,A,B,E,\ o_3,u,v.
\end{split}                                                 \tag{11}
\]
The second path uses both site edges \(xy,uv\).
The four-pole comparison commutes with their
legal site expansion, so the child is Barnette;
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
makes it Hamiltonian. For \(r=m\), the same
claims follow from Note 382's standard
corridor realization. This realizes all
\(m\) words of (4). \(\square\)

The theorem closes only the \(hI\) subbranch
of the no-internal-chord \(tJ\) return.
[Note 384](384-delayed-single-double-return-has-two-cutpoints-and-a-marked-route.md)
subsequently classifies the \(hp_j\) branches
and supplies their marked Hamilton routes.
The \(to\) first-mate branch beyond Note 381's
specified word, flanks, and other opening
types remain open. It does not prove
Barnette's conjecture. This is a
project-internal analytic proof, with
no local graph recomputation, independent
review or external priority claim.
