> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Isolated single-double corridors couple J0 and J2 at every length

[Note 378](378-isolated-single-double-group-couples-j0-and-j2.md)
proves a coupling of two internal matching chords when a singly
vacant block and a doubly vacant block are adjacent.
A positive short-block corridor adds arbitrarily many free slots
and permits cross returns such as
[Note 381](381-a-cross-return-single-double-corridor-has-the-square-signature-at-every-length.md).
The coupling nevertheless holds at every corridor length.

Work in a compressed, gapless, tight-target all-square selected
opening of a Barnette parent, as in
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group whose complete blocks
are exactly one singly vacant block, one doubly vacant block,
and \(m\ge1\) short blocks strictly between them. There are no
short flanks in this group; other groups are unrestricted.
Write the double block as
\[
                 D=(A,O,H,I,K,J,E,B),
\]
and let \(M\) complement the chosen old Hamilton cycle. Put
\(J_0=OE,\ J_1=OK,\ J_2=HJ,\ J_3=IE\).

**All-length chord-coupling theorem.** For every \(m\ge1\)
and either order of the vacant blocks,
\[
                       OE\in M\quad\Longleftrightarrow\quad HJ\in M.
\tag{1}
\]
Moreover, [Note 328](328-no-short-corridor-between-a-single-vacancy-and-a-j1-double-block.md)
excludes \(J_1,J_3\) in this isolated positive corridor.
Thus an actual matching has either no internal free chord
in \(D\), or exactly \(J_0,J_2\). In the latter case,
\(D\) is the eight-vertex even ladder of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md):
replacing it by a square preserves the Barnette class,
the selected opening outside \(D\), and every exterior-marked
Hamilton decision.

**Proof.** Old-cycle reflection reverses the block order
and maps \(OE,HJ\) to themselves after relabelling \(D\).
It suffices to take the order
\[
 V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad D.
\]
The free slots, including the even left and odd right
endports \(t,z\), occur in the order
\[
 t,o,h,i,e,p_1,q_1,\ldots,p_m,q_m,O,H,I,K,J,E,z.
\tag{2}
\]
Every cross-block free matching chord lies opposite the
designated common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
so two such chords cannot interlace. The only possible
internal free chord of \(V\) is \(oe\); if present it lies
on the face side, since on the opposite side it would trap
the old-cycle pair \(h,i\). For an opposite-side chord,
the number of free slots in its open interval must be even
after removing each endpoint of a face-side chord that
leaves that interval. A proper consecutive interval of
complete blocks whose matching is entirely internal has
only its two boundary old-cycle edges leaving it, a
forbidden two-edge cut. We use these two rules repeatedly.

Before considering an internal chord of \(D\), the left
endport already has only three possible mates:
\[
                            M(t)\in\{o,I,J\}.            \tag{3}
\]
Indeed, \(ti\) traps the old-cycle pair \(o,h\); if
\(oe\) is present, its \(o\)-end exits the interval and
leaves \(h\) alone. An edge \(tp_j\) encloses every
free slot of \(V,S_1,\ldots,S_{j-1}\), while \(tO\)
encloses every free slot of \(V,S_1,\ldots,S_m\).
No opposite-side chord can leave either enclosed
complete-block interval, and all face-side chords
of those blocks remain internal. Both choices
give a two-edge cut. The edge \(tz\) closes the
whole group and gives the same contradiction.
These are all other opposite-colour candidates for \(t\).

Suppose \(OE\in M,\ HJ\notin M\). The chords \(OK,IE\)
share endpoints with \(OE\), so \(D\) has no other internal
free chord. The chord \(OE\) is on the face side: if it lay
on the other side, its enclosed slots \(H,I,K,J\) would
have to match internally, but their only eligible internal
edge is the excluded \(HJ\).

By (3), \(t\) can meet only \(o,I,J\).
The edge \(tI\) has \(2m+6\) free slots
inside and \(tJ\) has \(2m+8\); in each interval the
face-side \(OE\) has precisely its \(O\)-end inside.
The optional \(oe\) is wholly inside, so parity excludes
both edges. Therefore \(to\in M\), so
\(oe\notin M\).

Now \(H\) has no possible mate. Its only candidates
are \(i,p_j,z\): \(o\) is used, \(I\) is an old-cycle
neighbour and \(J=J_2\) is excluded. The interval of
\(iH\) has \(2m+2\) free slots, namely \(e\), all
corridor slots and \(O\); exactly \(O\) exits through
\(OE\). The interval of \(p_jH\) has
\(2(m-j)+2\) slots, namely \(q_j\), the later
corridor slots and \(O\), with the same single exit.
Finally, \(Hz\) encloses \(I,K,J,E\), with exactly
\(E\) exiting through \(OE\). In all three cases
an even interval has one face-side exit, violating
parity. This excludes \(OE\) without \(HJ\).

Conversely suppose \(HJ\in M,\ OE\notin M\).
The chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes \(OK,IE\) whenever \(HJ\) occurs.
The chord \(HJ\) lies on the face side: otherwise
its enclosed \(I,K\) would have to use their
old-cycle edge to match internally.

By (3), \(t\) can meet only \(o,I,J\), and \(J\)
is already used by \(HJ\). The edge \(tI\) encloses
\(2m+6\) free slots, with precisely \(H\) exiting
through the face-side \(HJ\); an optional \(oe\)
lies wholly inside. Parity excludes \(tI\).
Thus \(to\in M\) and \(oe\notin M\).

The slot \(K\) now has no possible mate. Its only
candidates are \(i,p_j,z\): \(o\) is used, \(O\)
is the excluded chord \(J_1\), and \(I,J\) are
old-cycle neighbours. The interval of \(iK\)
contains \(2m+4\) free slots
(\(e\), all corridor slots, \(O,H,I\));
the interval of \(p_jK\) contains \(2(m-j)+4\)
(\(q_j\), the later corridor slots, \(O,H,I\)).
Both have exactly \(H\) exiting through \(HJ\).
Finally \(Kz\) encloses \(J,E\), with exactly \(J\)
exiting through \(HJ\). Each even interval has
one face-side exit. This excludes \(HJ\) without
\(OE\) and proves (1).

Note 328 removes the \(J_1,J_3\) alternatives
when \(m\ge1\). When \(J_0,J_2\) both occur,
Note 325 identifies \(D\) with \(L_4\) and gives
the asserted exact replacement. \(\square\)

**Two remaining first-mate branches.** In the block order
\(V,S_1,\ldots,S_m,D\), if \(D\) has no internal free
matching chord, (3) sharpens to
\[
                             M(t)\in\{o,J\}.             \tag{4}
\]
Indeed, if \(tI\) belonged to the opposite-side
matching, its interval would leave precisely
\(K,J,E,z\) on the right. None can match a slot
inside \(tI\) without crossing it; \(oe\), if used,
lies wholly inside. Among these four outside slots,
\(KJ\) and \(JE\) are old-cycle edges, \(KE\) and
\(Jz\) join equal colours, while \(Kz,Ez\) cannot
simultaneously match all four. Thus \(tI\) is impossible.
If \(tJ\) occurs, the two remaining slots on its right
are \(E,z\), forcing \(Ez\in M\). Reflection gives the
corresponding two-branch restriction in the reverse
block order.

The \(tJ\) branch has a further forced outer return:
\[
             tJ,\quad oK,\quad Ez\in M,\qquad oe\notin M.
\tag{5}
\]
With \(tJ,Ez\) fixed, \(K\) can meet only \(o,i\)
or some \(p_j\). If \(p_jK\) occurred, every free
slot of the proper complete-block prefix
\(V,S_1,\ldots,S_{j-1}\) would lie outside that
opposite-side chord but inside \(tJ\). It could
match neither across \(p_jK\) nor to the used
outer endports; any \(oe\) chord stays within
\(V\). The prefix would be matching-closed and
give a two-edge cut. If \(oe\) occurred, \(o\)
would be used, and the only remaining candidate
\(iK\) would enclose \(2m+4\) free slots with
exactly \(e\) exiting through \(oe\), violating
parity. Thus \(oe\notin M\). Finally, \(iK\)
would leave \(o,h\) on the left of its
opposite-side interval. They could only match
each other, but \(oh\) is an old-cycle edge.
Therefore \(oK\in M\), proving (5).
In this branch \(h\) can meet only \(I\) or a
\(p_j\) with \(j\ge2\). The edge \(hp_1\)
traps the old-cycle pair \(i,e\). If \(hO\)
occurred, the only two slots between its
right end and \(K\) would be \(H,I\);
they cannot cross \(hO\) to match earlier
slots, and \(HI\) is an old-cycle edge.
All other candidates of \(h\) are used,
have its colour, or are old-cycle neighbours.

**A square-equivalent \(tJ\) family.** The other
first-mate branch also occurs at every corridor length.
Let \(R_m\) have the old-cycle path
\[
 a,o,h,i,e,b,\quad
 (c_j,p_j,q_j,d_j)_{j=1}^{m},\quad
 A,O,H,I,K,J,E,B
\]
and the face-closing edges \(ab,c_jd_j,AB\).
Add the free matching chords
\[
 oK,\quad hI,\quad iH,\quad ep_1,\quad
 q_jp_{j+1}\ (1\le j<m),\quad q_mO.             \tag{6}
\]
Its four terminals are \((a,J,E,B)\), and its
complete Hamilton routing signature is that of the
square. Replacing it by the labeled square preserves
Barnette membership and every exterior- and
attachment-marked Hamilton decision. The matching
occurs in a \(26+4m\)-vertex marked Barnette parent
with a Hamilton cycle through both site edges.

For the proof, start from the fourteen-vertex pole
\(P\) in [Note 380](380-every-isolated-single-double-free-group-has-a-square-reduction.md),
whose free chords are \(oK,hI,iH,eO\). Its vertices
\((e,b,A,O)\) induce a square with four distinct
attachments. Replacing it by the \(L_4\) of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
inserts \(S_1\), changes \(eO\) to \(ep_1,q_1O\),
and keeps the old-cycle and face-chord pattern.
For each further insertion, the four vertices
\((q_j,d_j,A,O)\) induce the same kind of square;
the \(L_4\) replacement changes \(q_jO\) to
\(q_jp_{j+1},q_{j+1}O\). These replacements preserve
the six outer pole routings: any spanning path or
path pair meets the internal square in one spanning
path or two disjoint spanning paths, and Note 178
replaces that routing with the same four attachment
state. They also preserve both directions of
Barnette membership. Apply the same insertions
to Note 380's marked 26-vertex realization.
The inserted ladder's old-cycle path visits all
new vertices. Both site edges and all escape targets
lie outside the replaced square; its old-cycle segment
and common-face arc extend through the ladder in the
displayed block order.
The marked Hamilton cycle and its legal Hamiltonian
site-expanded child transfer at every step.

If every vacancy outside this group lies in a distinct
internal block, the \(J_0,J_2\) branch has a parent
Hamilton cycle through both site edges: compress \(D\),
apply Note 324 to the remaining single vacancy and
other distinct vacancies, then lift the marked cycle.
Its legal site-expanded child is Hamiltonian by
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).

The remaining no-internal-chord matchings are not
classified here. Equation (4) reduces their first
matching edge to \(to,tJ\). Note 381 realizes
the \(to\) branch with a square-equivalent pole for
every \(m\); (6) realizes a distinct square-equivalent
\(tJ\) family. [Note 383](383-the-hi-return-single-double-corridor-is-an-exact-square-reduction.md)
subsequently classifies and reduces the entire \(tJ,hI\)
branch; other corridor matching words may occur.
The theorem does not
establish Hamiltonicity of all Barnette graphs.
This is a project-internal analytic proof without
independent review or an external priority claim.
