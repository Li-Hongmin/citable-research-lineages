> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A six-terminal square splice closes the chorded equality boundary

[Note 475](475-nested-split-unary-equality-reduces-to-a-sealed-four-terminal-child.md) leaves one possible chorded \(c=5f-7\) equality configuration: all four exterior terminals lie in the child \(A\) of the inner split unary node, and every nonterminal face matching edge at \(A\) stays inside \(A\). All assigned special positions in \(A\) belong to two-special ordinary leaves. A six-terminal open-arc splice supplies the missing internal four-port cover.

## Six-terminal open-arc lemma

Let \(P\) be a finite path with endpoints \(L,R\). Let \(E=\{x_i y_i\}\) be pairwise disjoint old edges in its interior, with pairwise disjoint square supports \(h_i,x_i,y_i,j_i\) in path order and available chords \(h_i j_i\). Choose four distinct vertices \(T\) among the endpoints of \(E\), and let \(M\) match all other endpoints of \(E\) using edges outside \(P\). Assume \(M\) contains no edge of \(P\).

**Lemma.** The graph \(P\cup M\cup\{h_i j_i\}\) has a spanning union of three paths whose endpoints are \(L,R\) and \(T\), with \(L,R\) on different paths.

**Proof.** Set \(F_0=(P-E)\cup M\). Every vertex outside \(\{L,R\}\cup T\) has degree two, while those six vertices have degree one. Thus \(F_0\) has three path components and perhaps cycles. Contract its components and represent each edge of \(E\) by a quotient edge, allowing loops. The quotient is connected because \(F_0\cup E=P\cup M\) contains the connected spanning path \(P\).

Choose a quotient spanning tree and remove two of its edges so that the three path vertices lie in separate rooted trees. Starting at each root and moving outward, perform the leaf-square switch of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) at every retained tree edge. Each switch joins the growing path to a new cycle; the supports are disjoint. This absorbs every cycle and leaves three spanning paths. If \(L,R\) are already on different paths, this is the required cover.

Otherwise \(L,R\) are endpoints of the same path. At least one of the two deleted tree edges joins its rooted tree to another rooted tree. It is still a nonloop quotient edge, and its square support is untouched. Switch at it. A square switch between two paths exchanges their tails: the two resulting paths have one endpoint from each original path. In particular \(L,R\) end on different paths. The third path is unchanged. \(\square\)

## Application to the sealed child

Let \(L,R\) be the ends of the inner child word \(A\) from Note 475. The old \(A\)-arc \(P_A=L\rightsquigarrow R\) is a path. Every assigned special position in \(A\) belongs to a two-special leaf; let \(E_A\) contain its adjacent-special old edge. The four terminals \(T=\{r_L,u,v,r_R\}\) are among the endpoints of \(E_A\). By the sealed-child condition, the face matching of all other endpoints of \(E_A\) stays in \(A\); call it \(M_A\). The leaf chords have the disjoint square supports required by the lemma. Hence \(A\) has a spanning three-path cover with endpoint set \(L,R,T\) and \(L,R\) on different paths.

The complementary \(R\)--\(L\) path of the root cycle \(C_W\) contains every vertex of \(W\setminus(A\setminus\{L,R\})\) and has no internal vertex in \(A\). Adjoin it to the three-path cover. It joins the two paths ending at \(L,R\), leaves the third path separate, and creates no cycle. The result is a spanning two-path cover of \(W\) with terminals \(T\). One of the two exterior pairings in [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) differs from this internal pairing and closes it to a parent Hamilton cycle containing both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the cycle to the expanded child. Thus the sealed configuration of Note 475 is Hamiltonian.

## Sharper chorded kernel

The \(c=5f-7\) chorded equality profiles of [Note 469](469-the-end-root-chorded-splice-and-unified-12f-plus-2-kernel.md) are exhausted: the four-special leaf is closed by [Note 470](470-one-four-special-leaf-always-supplies-the-chorded-four-port-cover.md); two marked unary nodes with an adjacent direct pair by [Notes 471–472](472-one-adjacent-and-one-split-unary-node-always-splice-at-chorded-equality.md); disjoint split nodes by [Note 474](474-disjoint-split-unary-nodes-close-the-chorded-equality-profile.md); and nested split nodes by Note 475 and the theorem above. Therefore every non-Hamiltonian doubly ladder-reduced chorded single-hexagon child with \(f\ge7\) satisfies
\[
                 c\le5f-8,\qquad
                 |V(\bar G^+)|=16+2f+2c\le12f .
\tag{1}
\]
For \(f=8\), the chorded branch has at most \(96\) reduced vertices. The chord-free branch remains bounded by \(12f+2\), or \(98\) vertices at \(f=8\), by [Note 465](465-two-four-port-pairings-close-the-nested-four-root-end-gap.md). These are necessary bounds for the selected single-hexagon opening, not a decision of Barnette's conjecture.
