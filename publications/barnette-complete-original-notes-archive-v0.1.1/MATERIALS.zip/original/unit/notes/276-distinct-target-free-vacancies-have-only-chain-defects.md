> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Distinct target-free vacancies have only chain defects

[Note 222](222-two-free-vacancies-with-flanks-have-at-most-two-chain-defects.md)
excludes same-block free chords and nonstandard ordinary matching
edges for two target-free vacancies. The same exclusions hold for
any number of vacancies in distinct target-free blocks. They give
a marked Hamilton route when all vacancy slots form one alternating
path attached to one missing ordinary link.

Use a compressed, gapless, tight-target all-square opening with
\(\ell,r\ge1\), as in Notes 196 and 215. Suppose every
vacancy of the opening lies in a different target-free internal
face-chord block. Fix a free group between occupied target runs,
with endports \(e_a,o_b\), containing \(q\ge1\) vacancies.
All other complete blocks of the group are short and target-free.
Write a vacant block as
\[
 B_k:\quad a_k,o_k,H_k,I_k,e_k,b_k .
\]
The ordinary chain links of the group are
\[
 P_j=e_jo_{j+1},\qquad a\le j<b.                 \tag{1}
\]
Other free groups are closed under the free matching by the
target barriers of Note 273, since no target-bearing block
has a vacancy.

**All-surplus chain-defect theorem.** Let \(c\) be the number
of complementary-matching edges whose two ends are vacancy
slots of this group. No same-block ordinary chord \(o_ke_k\)
belongs to the complementary matching \(M\). Every edge of
\(M\) joining two ordinary slots is a link (1). Exactly
\(q-c\) links (1) are missing, independent of the lengths
of the short-block flanks.

**Proof.** Free slots in a group alternate in bipartition
colour. Every cross-block free matching chord lies in the disk
opposite the designated common face by Note 193, and these
chords do not cross. The only possible face-side free chord
in a target-free vacant block is \(o_ke_k\): every other
opposite-colour interior pair is an old-cycle edge.

Suppose \(o_ke_k\in M\). The even vacancy slot \(H_k\)
cannot match its old-cycle neighbour \(I_k\). It cannot
match an ordinary odd slot \(o_j\). The cross-block chord
\(H_ko_j\) has an even number of free slots strictly
inside it. Exactly one end of \(o_ke_k\) is inside.
Every other possible same-block free chord has both ends
inside or both outside; in the endpoint block \(B_j\),
\(o_j\) is already matched. An opposite-side chord
cannot leave the interval without crossing \(H_ko_j\).
An odd number of remaining inside slots would have to
match internally, a contradiction.

Hence \(H_k\) matches an extra odd slot \(I_t\), \(t\ne k\),
in the same group; Note 203 forbids straddling an occupied
escape target.
The chord \(H_kI_t\) again encloses an even number of free
slots. Exactly one end of \(o_ke_k\) is inside. Only the
same-block chord \(o_te_t\) could contribute one further
face-side exit: intervening blocks lie wholly inside the
chord and all other blocks lie outside. Parity forces
\(o_te_t\in M\).

Let \(Z=\{j:o_je_j\in M\}\). The same argument sends each
\(j\in Z\) to a \(t\in Z\) for which \(H_jI_t\in M\).
This map is injective because matching edges have distinct
odd endpoints, hence it is a permutation of the finite set
\(Z\). Therefore every vacancy slot \(H_j,I_j\) of a block
in \(Z\) is matched to a vacancy slot of another block in
\(Z\). Add the old-cycle boundary pairs \(H_jI_j\) for
\(j\in Z\). Their union with these noncrossing matching
chords decomposes into the alternating components of
Note 275. Choose one component, and let \(B_a,B_b\) be its
first and last blocks. Its outer matching chord is
\(H_aI_b\). All ordinary slots at the two ends that lie
outside this chord are paired internally by \(o_ae_a\)
and \(o_be_b\); every other free slot of the complete
block interval \(B_a,\ldots,B_b\) lies inside the chord
or belongs to one of those endpoint blocks. A cross-block
matching edge from that interval to the outside would
interlace \(H_aI_b\) in the opposite-side disk. All
same-block chords and face-block closing chords stay
inside. Thus the full block interval is matching-closed
and has only two outgoing old-cycle edges, contrary to
three-connectivity.
The extremal component span is essential: for three
vacancy atoms with matching edges
\(H_1I_3,I_1H_2,I_2H_3\), the interval from
\(B_1\) to \(B_2\) is not closed, whereas the full
span from \(B_1\) to \(B_3\) is.
Thus \(o_ke_k\notin M\).

Consider an ordinary-to-ordinary matching edge \(e_io_j\).
If \(j=i+1\), it is standard. If \(j=i\), it is the
excluded same-block chord or an old-cycle edge of a
short block. If \(j\ge i+2\), its opposite-side chord
encloses a nonempty complete block interval. It cannot
straddle an escape target by Note 203; otherwise every
matching edge leaving that interval would cross it.
The interval would have a forbidden two-edge cut.
If \(j<i\), the chord from \(o_j\) to \(e_i\)
encloses the complete interval \(B_j,\ldots,B_i\);
the same crossing and cut argument excludes it.
Hence ordinary ends are paired only by retained links (1).

The links (1) would pair all ordinary slots. Each missing
link has both its ends matched to vacancy slots. Of the
\(2q\) vacancy slots, \(2c\) match one another, so
\(2q-2c\) ordinary ends are diverted. This is exactly
\(q-c\) complete links. \(\square\)

**Single-defect Hamilton corollary.** Assume all vacancies
of the opening lie in this group, \(c=q-1\), and the
graph on its vacancy slots formed by the \(q\) old-cycle
edges \(H_iI_i\) and the \(q-1\) vacancy-to-vacancy
edges of \(M\) is connected. Then the parent has a
Hamilton cycle containing both site edges \(xy,uv\),
and its legal expanded child is Hamiltonian.

Indeed, the connected vacancy graph has two degree-one
vertices and all other vertices of degree two. It is
one alternating path through all \(2q\) vacancy slots,
with endpoints an odd \(I\)-slot and an even \(H\)-slot.
By the theorem there is one missing ordinary link,
say \(e_so_{s+1}\); its ends match these two path
endpoints. Replace the link in Note 196's ordinary
free path by
\[
 e_s,\ I,\ \xrightarrow{A\cup M\text{ through all
 vacancy slots}}\ H,\ o_{s+1}.                 \tag{2}
\]
The outer joins are in \(M\); the inserted path visits
all vacancy slots once. The fixed target-and-square path
is disjoint except at \(x,v\), so the two paths form the
required Hamilton cycle. Notes 001 and 178 give the
legal child and arbitrary original lobe lengths. For
\(q=3\), this settles every two-vacancy-edge matching
whose alternating vacancy graph is connected.

**Realization at every \(q\).** For \(q\ge1\), take
\(\ell=1,r=q+1\) and the old-cycle order
\[
\begin{array}{ll}
B_0:&x,R_1,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_{t+1}:&a_{t+1},o_{t+1},H_t,I_t,e_{t+1},b_{t+1}
          \quad(1\le t\le q),\\
B_{q+2}:&u,o_{q+2},L_1,v,\\
\text{last arc}:&\alpha_1,\gamma_1,\delta_1,\beta_1,
                   \text{ returning to }x .
\end{array}                                               \tag{3}
\]
Its complementary perfect matching is
\[
\begin{split}
M={}&\{xy,uv,\alpha_1\beta_1,\delta_1R_1,\gamma_1L_1\}\\
 &\cup\{a_jb_j:1\le j\le q+1\}
 \cup\{e_jo_{j+1}:1\le j\le q+1\}\\
 &\cup\{e_0I_q,\ o_1H_1\}
 \cup\{I_tH_{t+1}:1\le t<q\}.                 \tag{4}
\end{split}
\]
Every pair has opposite old-cycle parity. On the side
opposite the common face, \(e_0I_q\) encloses
\(o_1H_1\), the internal vacancy links and their
standard chain links; the inner chords are disjoint
or nested. The escape chord \(\delta_1R_1\)
encloses them all. Draw \(xy,uv,\alpha_1\beta_1\)
and all \(a_jb_j\) on the common-face side, as in
Note 274. The remaining opposite-side chords are
disjoint from or nested in \(\delta_1R_1\).

The matching chords have a connected
interlacement backbone. The chord \(e_0I_q\)
interlaces both \(xy\) and \(a_{q+1}b_{q+1}\).
The standard links \(e_jo_{j+1}\), \(1\le j<q+1\),
connect consecutive face chords; the last link
connects \(a_{q+1}b_{q+1}\) to \(uv\).
The chords \(uv,\gamma_1L_1,\alpha_1\beta_1,
\delta_1R_1,xy\) form Note 274's closing chain.
The edge \(o_1H_1\) interlaces \(a_1b_1\);
each \(I_tH_{t+1}\) interlaces
\(a_{t+1}b_{t+1}\). Thus every matching chord
belongs to one connected interlacement graph.
The two-edge-cut argument of Note 274 and the
cubic lemma of Note 182 imply three-vertex-connectivity.
The parent is a Barnette graph of order \(6q+16\).

Its vacancy edges and \(H_tI_t\in A\) form one path.
The missing ordinary link \(e_0o_1\) is replaced by
\[
 e_0,I_q,H_q,I_{q-1},H_{q-1},\ldots,I_1,H_1,o_1.
\]
This gives the claimed marked parent Hamilton cycle
and legal Hamiltonian child without graph enumeration.
\(\square\)

The structural theorem does not classify two or three
missing ordinary links in a three-vacancy group, nor
vacancies in target-bearing or site blocks, repeated
vacancies in one block, positive gaps, defective target
order or nonsquare residual cycles.
[Note 277](277-every-three-block-single-defect-vacancy-group-is-hamiltonian.md)
settles the disconnected one-link case for three vacant blocks.
