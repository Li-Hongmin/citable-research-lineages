> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One face chord absorbs an arbitrary middle word along a four-branch spine

The fifth comb in [Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md) has the depth vector $(3,5,6,6,4,2,1)$ and short leaf 2. Its correct ordinary tree places the fifth leaf outside the short leaf's branch. This arrangement admits a spanning marked path using only the face chord $y_5x_6$. The path works with an arbitrary consecutive middle word in place of the short-leaf branch.

Let $B$ be any nonempty consecutive ordinary word, with first and last old-cycle vertices $B_\ell,B_r$. Assume only that its old-cycle edges contain the forward spanning path $\overrightarrow B:B_\ell\to B_r$. Put
\[
 R=F(B,U_5),\qquad S=F(U_1,R),\qquad
 T=F(S,U_6),\qquad W=F(T,U_7),                         \tag{1}
\]
where $F(P,Q)=(((P Q)))$ and the four displayed leaves are full $U_i=((x_i y_i))$. The leaf paths $Y_i,X_i$ and the bracket-only paths $P_F,Q_F,R_F$ are defined in [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equations (1)--(2). Suppose the matching contains the face edge $y_5x_6$ and the two site edges have inner endpoints $y_1,x_7$.

**One-chord spine lemma.** The old-cycle edges, ordinary chords, and $y_5x_6$ contain a spanning $y_1$--$x_7$ path of $W$, for every choice of $B$:
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^S\xrightarrow{P_S}\rho_2^S,
\rho_0^R\xrightarrow{Q_R}\lambda_2^R,
B_\ell\xrightarrow{\overrightarrow B}B_r,\\
&L_5\xrightarrow{Y_5^{-1}}y_5,
x_6\xrightarrow{X_6^{-1}}R_6,
\rho_2^T\xrightarrow{R_T}\lambda_0^T,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                    \tag{2}
\]
The jump $y_5x_6$ is the stipulated face edge. Every other join between consecutive displayed pieces is an old-cycle edge:
\[
L_1\lambda_2^S,\quad \rho_2^S\rho_0^R,\quad
\lambda_2^R B_\ell,\quad B_rL_5,\quad
R_6\rho_2^T,\quad \lambda_0^T\lambda_2^W,\quad
\rho_2^W R_7.                                             \tag{3}
\]
All paths cited in (2) span disjoint vertex sets: the four full leaves, the four six-vertex branch wrappers, and $B$. Thus (2) uses every one of the $|B|+48$ vertices of $W$ exactly once. Equations (2)--(3) check every edge, proving the lemma. \(\square\)

**Application to the short-second-leaf comb.** The word with depth vector $(3,5,6,6,4,2,1)$ is exactly (1) with
\[
 K=F(U_3,U_4),\qquad B=F(U_2^{\rm short},K),\qquad
 U_2^{\rm short}=(x_2y_2).                              \tag{4}
\]
The depths in (1)--(4) are, in order, $(3,5,6,6,4,2,1)$; $|B|=4+18+6=28$, so (2) visits all $76$ word vertices. Row I of Note 427 contains $y_5x_6$. For every legal completion in Note 416's normal form, append the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), to obtain a parent Hamilton cycle through both sites. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) then gives a Hamilton cycle in the legal expanded child.

Together with Notes 428--429, four of Note 427's six necessary words are Hamiltonian in every legal completion. Only the two comb words with sites $(1,2)$ remain under face matching I, up to reflection. This says nothing about their Hamiltonicity, other face matchings, or Barnette's conjecture.
