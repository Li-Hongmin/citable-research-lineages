> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A vacancy immediately after a delayed first target is Hamiltonian

[Note 244](244-a-double-delayed-endpoint-has-a-forced-rainbow-hamilton-route.md)
and [Note 245](245-a-delayed-endpoint-composes-with-an-earlier-vacancy.md)
settle both placements of a second vacant eligible position before
the delayed first target at the second surplus. A vacancy just after
that target has a different matching barrier. Three-connectivity
separates the two free groups in an internal block; in the left site
block, planarity instead forces two nested chords across the target.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, \(s=2\), and
\(d_L=1,b=d_R=0\). Suppose the first target \(R_\ell\) is the
third interior slot of \(B_h\), and the other vacancy is the fourth
interior slot of that same block. Assume \(B_h\) has no later target:
its six interior slots are exactly
\[
o_h,w,R_\ell,H,I,e_h,                         \tag{1}
\]
where \(H\) is the vacant even slot. Thus \(h\le r\), since the
right site block must end at \(L_1\). Write \(B_m\), \(m>h\), for
the block of the next escape target \(L_\ell\).

**Post-target vacancy theorem.** The parent has a Hamilton cycle
containing both site edges \(xy,uv\), and its legal site-expanded
child is Hamiltonian. For \(h\ge1\), necessarily \(m\ge h+2\)
and, for some \(t\in\{h+2,\ldots,m\}\), its free matching is
\[
\begin{split}
M_{\rm free}={}&\{o_0w,H o_t,I e_{t-1}\}\\
&\cup\{e_j o_{j+1}:0\le j\le r,\ j\ne t-1\}.
\end{split}                                             \tag{2}
\]
For \(h=0\), the free matching is instead
\[
M_{\rm free}=\{o_0e_0,wI,H o_1\}
\cup\{e_j o_{j+1}:1\le j\le r\}.            \tag{3}
\]
Reflection gives the corresponding last-target assertion.
The original square-trap lobes may have arbitrary positive lengths.

**Internal block.** Let \(h\ge1\). The free prefix before
\(R_\ell\) has \(2h+2\) vertices, an even number. Note 203
forbids every cross-block free chord straddling that target.
The only opposite-colour same-block possibilities across it are
\(o_hH,o_he_h,wI\). Since there are only two earlier free slots,
matching parity permits zero or two crossing chords. Two would
use both \(o_h,w\). The complete main prefix through the right
endpoint of \(B_{h-1}\) would then be matching-closed: it has no
escape target, its site and face chords are internal, and its
free slots cannot reach beyond \(R_\ell\) by Note 203 or reach
the already used \(o_h,w\). Its two departing old-cycle edges
contradict three-connectivity. Hence no free chord crosses
\(R_\ell\).

The closed group before \(R_\ell\) has exactly Note 211's
one-defect slot order. Its noncrossing and two-edge-cut argument
forces \(o_0w\) and \(e_j o_{j+1}\) for \(0\le j<h\).
The next target is \(L_\ell\). Since both vacancies are used,
its first available even position must be occupied, so it is the
second interior slot of \(B_m\). All intervening blocks are
short. The free group after \(R_\ell\) and before \(L_\ell\)
is therefore
\[
H,I,e_h,o_{h+1},e_{h+1},\ldots,o_m.          \tag{4}
\]
All its matching chords join different blocks, lie opposite the
site face by Note 193, and are noncrossing. The even slot \(H\)
must match \(o_t\) for some \(h+1\le t\le m\).
If \(t=h+1\), noncrossing strands the adjacent old-cycle
pair \(I,e_h\). Hence \(t\ge h+2\), so \(m\ge h+2\).
Inside \(H o_t\), the odd slot \(I\) must match \(e_{t-1}\):
matching an earlier even slot would leave one adjacent short
block pair or a matching-closed complete block interval.
The remaining enclosed slots take standard links by Note 196's
skipping rule. After \(L_\ell\), the usual even-prefix target
barriers and skipping rule force all other standard links.
This gives (2).

Replace \(xR_\ell\) in Note 196's target-and-square path by
\(x,o_0,w,R_\ell\). In its ordinary free path replace
\(e_{t-1}o_t\) by \(e_{t-1},I,H,o_t\).
The middle edge \(o_0w\) of the target detour lies in \(M\),
and its outer edges lie in \(C\). The free detour has matching
outer edges \(e_{t-1}I,Ho_t\) and old-cycle middle edge \(IH\).
The two paths
are internally disjoint and span the parent.

**Left site block.** Let \(h=0\). The two free slots before
\(R_\ell\) are \(o_0,w\), adjacent on \(C\); hence zero
crossing chords would leave them unmatched. At \(R_\ell\),
cross-block chords are forbidden and parity demands exactly
two same-block crossing chords. The even slot \(w\) must match
\(I\). The odd slot \(o_0\) could match \(H\) or \(e_0\).
Both crossing chords lie on the site-face side, since the
escape chord from \(R_\ell\) lies opposite. The pair
\(o_0H,wI\) interlaces there and is impossible. Thus
\[
o_0e_0,wI\in M.                              \tag{5}
\]
The remaining even slot \(H\) must match an odd free slot
\(o_t\) in a later block. All such chords lie opposite the
site face. If \(t>1\), noncrossing would match every complete
short block \(B_1,\ldots,B_{t-1}\) internally. A single such
block has adjacent free interiors; two or more give a forbidden
two-edge cut. Hence \(H o_1\in M\). The ordinary slots after
\(B_1\) follow the standard chain, proving (3).

The two paths of a marked Hamilton cycle are now the ordinary
target-and-square path with the initial edge replaced by the
three old-cycle edges
\[
x,o_0,w,R_\ell,                               \tag{6}
\]
and the free path of Note 196 with its initial segment replaced by
\[
x,y,e_0,I,H,o_1,a_1,b_1.                     \tag{7}
\]
In (7), \(xy\in M\), \(ye_0,e_0I,IH,o_1a_1\in E(C)\),
and \(Ho_1,a_1b_1\in M\). It then follows the ordinary
standard links through \(uv\). The two paths share only \(x,v\)
and cover all vertices. Notes 001 and 178 give the legal
site-expanded child and longer lobes. \(\square\)

**Realized internal and site-block profiles.** For the internal
case take \(r=2,\ell=1,h=1,m=t=3\), with old 24-cycle
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_1,H,I,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                             \tag{8}
\]
Its matching contains \(xy,a_1b_1,a_2b_2,uv,
\alpha\beta,R_1\delta,L_1\gamma\) and the free edges
\(o_0w,e_0o_1,H o_3,I e_2,e_1o_2\).
Its marked cycle is the union of
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,I,H,o_3,u,v.
\end{split}                                             \tag{9}
\]

For the site-block case take \(r=1,\ell=1,h=0\), with old
20-cycle
\[
\begin{array}{ll}
B_0:&x,o_0,w,R_1,H,I,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                             \tag{10}
\]
Its matching contains \(xy,a_1b_1,uv,\alpha\beta,
R_1\delta,L_1\gamma\) and \(o_0e_0,wI,H o_1,e_1o_2\).
Its marked cycle is the union of
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,I,H,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                             \tag{11}
\]

Both parent graphs are simple, cubic, bipartite and plane:
put the site, face and square chords on one side of the old
cycle. In the internal profile the opposite-side chords form
\(o_0w\supset e_0o_1\) and
\(R_1\delta\supset(Ho_3\supset Ie_2\supset e_1o_2,
L_1\gamma)\), with the two displayed inner branches disjoint.
In the site profile put \(o_0e_0\supset wI\) inside \(xy\)
on the site-face side; opposite-side chords are
\(R_1\delta\supset(Ho_1,e_1o_2,L_1\gamma)\), with these
three inner chords disjoint. The site edges are cofacial.

The matching-chord interlacement graph is connected in both
profiles. In the internal profile the chain of alternating
endpoints \(xy-o_0w-a_1b_1-Ho_3-uv-L_1\gamma-
\alpha\beta-R_1\delta-a_1b_1\) connects the site,
face and square chords; \(e_0o_1,e_1o_2,Ie_2,a_2b_2\)
each interlace one of these or an already attached chord.
In the site profile \(R_1\delta\) interlaces
\(xy,o_0e_0,wI\), \(xy\) interlaces \(Ho_1\),
\(Ho_1\) interlaces \(a_1b_1\), \(a_1b_1\) interlaces
\(e_1o_2\), \(e_1o_2\) interlaces \(uv\), and
\(uv-L_1\gamma-\alpha\beta-R_1\delta\) completes
a connected spine. Note 217's interval criterion proves
three-connectivity, and its cut projection makes the
28- and 24-vertex site expansions Barnette. The displayed
path pairs share only \(x,v\) and cover all parent vertices.

The theorem treats the immediate post-target vacancy with no
other target in its block. Later same-block vacancies separated
by target runs, vacancies in the right site block, transition
defects with spare vacancies, gaps, nonsquare lobes and arbitrary
Barnette graphs remain outside it.
