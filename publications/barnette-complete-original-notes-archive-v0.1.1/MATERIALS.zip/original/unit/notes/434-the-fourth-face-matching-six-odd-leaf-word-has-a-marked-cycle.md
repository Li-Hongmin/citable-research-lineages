> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth face matching's six-odd-leaf word has a marked Hamilton cycle

[Note 433](433-the-six-odd-leaf-fourth-matching-has-one-short-branch-word.md) leaves one necessary row-IV ordinary word when the seven-leaf tree has six odd-depth leaves. This note gives it a spanning $y_1$--$x_7$ path, so every legal row-IV child in that depth spectrum is Hamiltonian. The three-odd-leaf spectrum remains outside the conclusion.

Retain Note 433's word
\[
 A=F(U_3,U_4),\quad B=F(U_5,U_6),\quad V=F_0(A,B),\quad
 D=F(V,U_7),\quad E=F(U_2,D),\quad W=F(U_1,E),        \tag{1}
\]
where $F(P,Q)=(((P Q)))$, $F_0(P,Q)=((P Q))$, and all leaves are full $U_i=((x_i y_i))$. A full leaf has old-cycle order $L_i,h_i,x_i,y_i,j_i,R_i$ and the paths $X_i,Y_i$ of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equation (1). Branch bracket paths $P_T,Q_T,R_T$ are in that note's equation (2).

**Two-leaf detour lemma.** The 18 vertices of $A$ split into the following two disjoint paths:
\[
\begin{aligned}
P_A&=(x_3\xrightarrow{X_3^{-1}}R_3,L_4,h_4,x_4),\\
Q_A&=(y_4,j_4,R_4,
       \rho_2^A\xrightarrow{R_A}\lambda_0^A=A_\ell).
\end{aligned}                                                     \tag{2}
\]
The bridge $R_3L_4$ and the join $R_4\rho_2^A$ are old-cycle edges. $P_A$ uses all of $U_3$ and $L_4,h_4,x_4$; $Q_A$ uses the other three vertices of $U_4$ and all six $A$ brackets. Hence their endpoints are $(x_3,x_4)$ and $(y_4,A_\ell)$.

Inside $B$, the complete old-cycle path from $B_\ell$ to $B_r$, together with the outer ordinary chord $B_\ell B_r$, is a Hamilton cycle. Its old edge $x_5y_5$ can be deleted. Reading the resulting spanning path from $y_5$ to $x_5$ gives
\[
 Z_B=(y_5\xrightarrow{\text{old cycle forward}}B_r,
       B_\ell\xrightarrow{\text{old cycle forward}}x_5),     \tag{3}
\]
where the join $B_rB_\ell$ is the outer ordinary chord. The path uses all 18 vertices of $B$ once.

Row IV contains both face edges $x_4y_5$ and $y_4x_5$. They concatenate (2)--(3) into a spanning $x_3$--$A_\ell$ path of $A\cup B$:
\[
 x_3\xrightarrow{P_A}x_4,
 y_5\xrightarrow{Z_B}x_5,
 y_4\xrightarrow{Q_A}A_\ell.                              \tag{4}
\]
The four brackets of the short branch $V$, in old-cycle order $\lambda_0^V,\lambda_1^V,\rho_1^V,\rho_0^V$, are added by
\[
 A_\ell,\lambda_1^V,\rho_1^V,\rho_0^V,\lambda_0^V=V_\ell. \tag{5}
\]
Here $\lambda_1^V\rho_1^V$ and $\rho_0^V\lambda_0^V$ are ordinary chords; the other steps are old-cycle edges. Thus (4)--(5) span all $40$ vertices of $V$ from $x_3$ to $V_\ell$.

**Marked-cycle theorem.** The complete $76$-vertex $y_1$--$x_7$ path of $W$ is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{(4)--(5)}V_\ell,
\lambda_2^D\xrightarrow{P_D}\rho_2^D,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{6}
\]
The jump $y_2x_3$ is row IV's third used face edge. All other joins between the displayed pieces are consecutive old-cycle edges: $L_1\lambda_2^W$, $\rho_2^W\rho_0^E$, $\lambda_2^EL_2$, $V_\ell\lambda_2^D$, and $\rho_2^DR_7$. Formula (6) partitions $U_1,U_2,U_7$, the three full branch wrappers $W,E,D$, and $V$, so its vertex count is $3\cdot6+3\cdot6+40=76$ with no repetition. Every step is an actual edge.

For any legal completion of this word, the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), close (6) into a parent Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to a Hamilton cycle in the child. Together with Note 433, this proves that a hypothetical non-Hamiltonian row-IV child must have exactly three odd-depth leaves in its full binary tree. Reflection gives the same necessary restriction for row V. \(\square\)

No claim is made about the remaining three-odd-leaf row-IV/V words, row VI, other eligibility counts, or Barnette's conjecture.
