> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Minimum directed brace repairs supplement the crossing edge

[Note 088](088-a-wide-plane-nonbrace-realizes-a-minimum-atomic-two-switch.md)
constructs a 32-vertex plane nonbrace whose complete legal-wide
fixed-pairing fibre has global cross-sector minimum two.  The obstruction
is carried by two copies of the two-pole \(Q_3-e\), each attached through a
nontrivial two-edge cut.

This note determines the minimum directed brace-repair boundary of that
construction.  A modification internal to either pole cannot help while
its two attachments remain unchanged.  Among all one- and two-step facial
\(C_4\) expansions of the fixed labelled embedding that preserve the root
square and gate edges, no brace counterexample survives.  One step cannot
simultaneously produce a brace and retain the wide site.  At two steps,
three of the four brace outcomes have empty fibre; the unique outcome with
nonempty fibre supplements thirty cross-sector single-cycle edges.

This is an exact finite route closure, not a general brace-repair theorem.

## 1. Fixed repair class

Use the labelled 32-vertex plane graph \(G\), root square and gates from
Note 088.  Its two inserted copies \(P_L,P_R\) of \(Q_3-e\) each meet the
rest of \(G\) in exactly two attachment edges.

Fix the explicit plane face system of Note 088.  A repair step chooses two
nonadjacent edges at even separation on one face, deletes them, and installs
the standard bipartite \(C_4\) expansion between their four exposed ends.
The five edges of the root-square interface and the two gate labels are
never selected.  After each step, the labelled face boundaries are updated
combinatorially; the graph is not re-embedded.

This distinction is necessary because the initial graph has 2-cuts and
therefore has nonunique plane embeddings.  The classification concerns
facial repairs of the fixed labelled embedding, not repairs made facial by
an implicit intermediate re-embedding.

Any repair entirely internal to \(P_L\) or \(P_R\) while retaining its two
original attachments leaves a nontrivial two-edge cut.  Such a graph cannot
be a brace.  Consequently a successful repair must increase the boundary
of each original pole.

## 2. One-step classification

There are exactly

\[
99
\tag{1}
\]

eligible labelled one-step facial expansions.  Their vertex-connectivity
distribution is

\[
\kappa=2:\ 94,\qquad \kappa=3:\ 5.
\tag{2}
\]

Exactly one of the 99 graphs is a brace.  In that graph the two gate edges
lie on different faces, so the legal-wide site is destroyed.  Hence no
one-step repair reaches the required plane-brace interface.

## 3. Two-step classification

Enumerating both orders and every eligible second facial site gives

\[
11\,083
\tag{3}
\]

labelled two-step sequences.  The successive necessary filters are

\[
\begin{array}{c|r}
\text{condition}&\text{sequences}\\ \hline
\text{both original pole boundaries increased}&2\,376\\
\text{legal-wide site retained}&968\\
\kappa=3&128\\
\text{brace}&8.
\end{array}
\tag{4}
\]

The eight labelled sequences are four disjoint repair pairs, counted in
the two commuting orders.  Expanding the fixed gate pair in each of the
eight repaired braces again gives a plane brace, so these are genuine
legal-wide interfaces rather than merely cofacial edge pairs.
Representatives of the four repaired graphs have fixed-pairing fibre outcomes

\[
\text{empty},\quad\text{empty},\quad\text{empty},\quad\text{nonempty}.
\tag{5}
\]

For the unique nonempty outcome, the two repairs use the edge pairs

\[
\{b_3b_4,A_1^LB_1^L\},
\qquad
\{b_5b_6,A_2^RB_2^R\}.
\tag{6}
\]

The repaired gate arcs remain \(9,9\).  After deleting the root square, the
residual graph has 1,781 perfect matchings.  Its fixed-pairing fibre has

\[
|\mathcal L|=125,\qquad
|\mathcal L^1|=25,\qquad
|\mathcal L^0|=100.
\tag{7}
\]

Across all \(25\cdot100=2\,500\) ordered cross-sector pairs, the complete
component-count distribution is

\[
\begin{array}{c|rrrrrr}
\#\operatorname{comp}(M\triangle N)&1&2&3&4&5&6\\ \hline
\#\text{ pairs}&30&262&684&836&528&160.
\end{array}
\tag{8}
\]

Thus the repaired fibre contains thirty crossing single-cycle edges, and

\[
\min_{M\in\mathcal L^1,\ N\in\mathcal L^0}
\#\operatorname{comp}(M\triangle N)=1.
\tag{9}
\]

The frozen certificate also exhibits one such alternating \(C_{10}\)
containing the surviving gate \(g_1=T_4\).

## 4. Exact boundary

**Exact conclusion.**  Within the fixed labelled one/two-facial-\(C_4\)
repair class, no brace realization preserves the Note 088 minimum
two-switch.  Every one-step brace loses the wide site.  At two steps, every
brace with nonempty fixed-pairing fibre supplements a crossing edge.

**Evidence level.**  The
[verification bundle](../computations/bundles/minimum-directed-brace-repairs/README.md)
freezes the plane face system, exhausts all labelled repair sequences,
tests 2-extendability of both the repaired graphs and their fixed-gate
children, enumerates every surviving fibre and verifies an explicit
supplemented crossing cycle.

**Scope.**  This does not classify larger repair sequences, nonfacial
repairs, other brace completions of the two poles, or arbitrary
plane-brace fibres.  The counts in (1)--(8) are relative to the fixed
labelled embedding.

**Unresolved boundary.**  P3 remains open for arbitrary plane braces.
The result gives a strict positive supplementation boundary for the
minimum local repair route, consistent with the separator/attachment
interface isolated in Note 089.
