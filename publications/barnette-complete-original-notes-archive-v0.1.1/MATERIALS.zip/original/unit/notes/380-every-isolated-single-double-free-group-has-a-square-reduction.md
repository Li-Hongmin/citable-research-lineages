> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every isolated single-double free group has a square reduction

[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
gives an exact square pole for adjacent single and
double vacancies when the double block carries \(J_1\).
[Note 378](378-isolated-single-double-group-couples-j0-and-j2.md)
couples \(J_0,J_2\) in the same minimal two-block group.
A different internal matching, with no free chord
inside either block, also gives an exact square pole.
It is forced whenever the double block has no
internal free chord in the isolated two-block group.

Let \(P\) have the fourteen vertices in old-cycle path order
\[
                a,o,h,i,e,b,A,O,H,I,K,J,E,B,          \tag{1}
\]
all thirteen consecutive path edges, and the six
additional edges
\[
                ab,\quad AB,\quad oK,\quad hI,\quad
                iH,\quad eO.                          \tag{2}
\]
The first six vertices form a singly vacant face block,
the final eight a doubly vacant face block. The
four cross-block matching edges in (2) are nested
in the order \(oK\supset hI\supset iH\supset eO\)
on the side opposite the two face-closing chords
\(ab,AB\). The four degree-two terminals are
\((a,J,E,B)\) in disk-boundary order. All
other vertices have degree three.

**Four-cross-chord pole theorem.** The complete
spanning one-path and two-path Hamilton signature
of \(P\) at \((a,J,E,B)\) equals that of the square
with these labeled corners. Replacing an induced
disk copy of \(P\) by that square, or reversing
the replacement, preserves Barnette membership
and every exterior- and attachment-marked
Hamilton decision. Consequently a vertex-minimal
non-Hamiltonian Barnette graph cannot contain
an induced disk copy of \(P\).

**Six routing states.** Along (1), \(a,E\) have
one bipartition colour and \(J,B\) the other.
The four possible single-path terminal pairs
are realized by the following spanning paths:
\[
\begin{array}{c|l}
aB & a,o,h,i,e,b,A,O,H,I,K,J,E,B\\
aJ & a,b,e,i,h,o,K,I,H,O,A,B,E,J\\
JE & J,K,I,h,o,a,b,e,i,H,O,A,B,E\\
EB & E,J,K,o,a,b,e,i,h,I,H,O,A,B .
\end{array}                                             \tag{3}
\]
The two noninterlacing two-path pairings
also occur:
\[
\begin{array}{c|l}
\{aJ,EB\}
 &(a,b,A,O,e,i,H,I,h,o,K,J),\quad(E,B)\\
\{aB,JE\}
 &(a,o,K,I,h,i,H,O,e,b,A,B),\quad(J,E).
\end{array}                                             \tag{4}
\]
Every consecutive pair in (3)--(4) is an edge
of (1) or (2), and each row covers all fourteen
vertices exactly once. Bipartiteness excludes
the remaining single-path pairs \(aE,JB\);
the remaining two-path pairing
\(\{aE,JB\}\) interlaces four disk terminals.
Thus (3)--(4) are exactly the square signature.
A Hamilton cycle of a host uses two or four
attachment edges and meets \(P\) in one or two
spanning paths. Replacing those paths by the
same square state, or conversely, keeps
all exterior edges and its global connectivity.

**Barnette-class preservation.** Cap the four
terminals by a square with vertices
\((t_B,t_E,t_J,t_a)\) in that cyclic order,
attaching \(Bt_B,Et_E,Jt_J,at_a\).
The path (1) followed by
\(t_B,t_E,t_J,t_a,a\) is a Hamilton cycle
of the resulting eighteen-vertex graph.
Its complementary matching is
\[
 ab,\ AB,\ oK,\ hI,\ iH,\ eO,\
 Jt_J,\ Et_E,\ t_Bt_a.                              \tag{5}
\]
Draw \(ab,AB,t_Bt_a\) on one page of
this Hamilton cycle and
\(oK\supset hI\supset iH\supset eO\)
together with \(Jt_J\supset Et_E\)
on the other. Each page is noncrossing,
and each pair in (5) joins opposite
old-cycle parities. The cap is therefore
simple, cubic, bipartite and plane.
The chord \(ab\) interlaces each of
\(oK,hI,iH,eO\); \(AB\) interlaces
these four and both \(Jt_J,Et_E\);
and \(t_Bt_a\) interlaces \(Jt_J,Et_E\).
So the matching-chord interlacement
graph is connected. Any two-edge cut
would enclose a proper Hamilton-cycle
interval closed under the matching and
disconnect that interlacement graph.
The Hamilton cycle excludes bridges.
Hence the cap is three-edge-connected,
and therefore three-vertex-connected
in the cubic case: it is a Barnette graph.

The two subpaths \((a,o,h,i,e,b,a)\) and
\((A,O,H,I,K,J,E,B,A)\) are cycles
joined by five edges at pairwise distinct
endpoints: \(bA,oK,hI,iH,eO\).
Deleting any one patch vertex leaves
\(P\) connected. If deleting two patch
vertices left a component with no
surviving terminal, that component
would also be disconnected from the
rest of the three-connected cap after
the same deletions. The square has
the corresponding one- and two-deletion
properties. The four-attachment
deletion comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
now proves three-connectivity in
both replacement directions: in any
three-connected host the exterior
is connected, since two exterior
components would each require at least
three of the four attachment edges.
Terminal colour and disk order preserve
bipartiteness and planarity; cubicity
and simplicity are immediate.

**Forced no-chord matching.** Consider an ordinary
target-free free group whose only complete blocks
are one \(V=(a,o,h,i,e,b)\) and one
\(D=(A,O,H,I,K,J,E,B)\), with no intervening
or flank short block. Let \(t,z\) be its even
left and odd right free endports. Suppose \(D\)
has none of \(OE,OK,HJ,IE\) in the complementary
matching. If \(V\) precedes \(D\), its entire
free-slot matching is uniquely
\[
              tJ,\quad oK,\quad hI,\quad iH,\quad
              eO,\quad Ez.                            \tag{6}
\]
In particular the induced two-block patch is
precisely \(P\). If \(D\) precedes \(V\), the
old-cycle reflection of (6) is the unique
matching and gives the reflected pole.

To prove this, use free-slot order
\[
                   t,o,h,i,e,O,H,I,K,J,E,z.             \tag{7}
\]
Every cross-block free matching chord lies on
the side opposite the designated common face
by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
The sole possible same-block free chord is
\(oe\) in \(V\); if present it lies on the
common-face side, since on the opposite side
it would trap the old-cycle pair \(h,i\).
We use the elementary ear rule: a noncrossing
perfect matching of a linearly ordered set
on one page has an edge joining consecutive
remaining positions. Choose an edge with
the fewest enclosed positions; if it encloses
any, those positions match internally and
contain a shorter edge.

The possible mates of \(t\) are
\(o,i,O,I,J,z\). The chord \(ti\)
traps \(o,h\), which cannot match,
whether or not \(oe\) occurs.
The chord \(tO\) traps the four
slots of \(V\): \(oe\), if used,
leaves the old-cycle pair \(h,i\);
without \(oe\), the ordered four
slots have no eligible adjacent
matching ear. If \(tI\) occurs,
its interior is \(o,h,i,e,O,H\).
The chord \(oe\) would again leave
\(h,i\) and the old-cycle pair
\(O,H\). Without \(oe\), the only
eligible ear is \(eO\); after
removing it, the only eligible
ear is \(iH\), leaving the
old-cycle pair \(o,h\). Thus
\(tI\) is impossible. The edge
\(tz\) encloses both complete
blocks, making their union
matching-closed with a two-edge
cut. Only \(to\) and \(tJ\)
remain.

If \(to\) occurs, then \(oe\)
is unavailable. The remaining
ordered free slots are
\[
                  h,i,e,O,H,I,K,J,E,z.                  \tag{8}
\]
All their matching edges lie on
one noncrossing page. The only
eligible ears of (8) are \(eO\)
and \(Ez\). After deleting either
or both, the only new eligible
ears are successively \(iH\)
and \(hI\). Deleting all four
leaves \(K,J\), an old-cycle
edge; stopping earlier leaves
no other eligible ear. Thus
(8) has no perfect matching.

Therefore \(tJ\in M\). If \(oe\)
were present, remove its two
endpoints from the interior of
\(tJ\). The remaining positions
\(h,i,O,H,I,K\) have no eligible
adjacent matching ear. Hence
\(oe\notin M\). Within \(tJ\)
the ordered positions are now
\(o,h,i,e,O,H,I,K\).
Their only eligible adjacent
ear is \(eO\); after removing
it, the successive unique
eligible ears are \(iH,hI,oK\).
The two positions outside
\(tJ\) are \(E,z\) and must
match. This is exactly (6).
Reflection proves the other
block order.

**Complete isolated-group reduction.** Every
actual matching of this two-block free group,
in either block order, contains a square-equivalent
induced disk patch. If \(D\) carries \(J_1=OK\),
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
forces its staggered square pole; \(J_3=IE\)
is the reflection. If \(D\) carries either
\(J_0=OE\) or \(J_2=HJ\),
[Note 378](378-isolated-single-double-group-couples-j0-and-j2.md)
forces both, and Note 325 reduces \(D\)
alone. The remaining no-internal-chord
case is (6) or its reflection, reduced
by the present pole theorem.
These cases exhaust the four possible
internal free chords. The reductions
do not depend on matching choices in
other free groups. Each resulting induced
disk patch, wherever it occurs in a
Barnette host, is excluded from a
vertex-minimal non-Hamiltonian Barnette graph.
If every other vacant position lies
in a distinct internal block, the
reduced opening satisfies
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md),
so the parent has a Hamilton cycle
through both site edges and its legal
site-expanded child is Hamiltonian.

**Realization in a marked opening.** Use
the 26-vertex Barnette parent with
old Hamilton cycle (5) and matching (6)
of Note 327. Replace its two matching
edges \(oe,OK\) by \(oK,eO\), leaving
every other edge unchanged. The result
contains precisely the pole (1)--(2)
at the same four attachments.
Its new opposite-side chords
\(oK\supset hI\supset iH\supset eO\)
are nested inside the old \(e_0J\)
chord, so the selected all-square,
gapless, tight-target facial opening
and site edges are retained.
The original and new poles both have
the square signature and the deletion
properties, so the new parent is
Barnette by the theorem. Moreover,
Note 327's marked Hamilton cycle (8)
does not use either removed edge:
its two \(x\)--\(v\) paths remain
valid in the new graph. Thus this
matching pattern occurs in a genuine
Barnette parent with a Hamilton cycle
through both site edges. The patch
replacement commutes with the site
expansion, so Note 327's legal
Barnette child transfers to a legal
Barnette child here; it is Hamiltonian
by [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).
\(\square\)

In any selected opening where (1)--(2)
occurs as an induced target-free patch,
the square replacement preserves the
old-cycle path, face-chord order, site
edges and all other vacancies. The
full-group classification requires
exactly these two complete blocks and
does not cover short flanks, other
vacancy configurations, or
Barnette's conjecture. The proof is
project-internal and has not had
independent review.
