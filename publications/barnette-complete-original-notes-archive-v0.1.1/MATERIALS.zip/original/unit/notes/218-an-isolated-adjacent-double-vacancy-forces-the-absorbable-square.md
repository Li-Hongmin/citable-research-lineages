> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An isolated adjacent double vacancy forces the absorbable square

[Note 216](216-adjacent-vacancy-square-is-absorbed-by-a-five-edge-detour.md)
gives a Hamilton route for one matching profile of two adjacent
vacancies. Here that profile is forced when their free group has
no additional short face block on either side.

Use a compressed all-square opening with \(\ell,r\ge1\), empty
interblock gaps, tight target order, and exactly two eligible
vacancies. Suppose they are in adjacent target-free face blocks
\(B_k,B_{k+1}\), \(1\le k<r\), each with four interior slots.
Assume the free matching group containing these vacancies is exactly
\[
e_{k-1},\
o_k,h_k,i_k,e_k,\
o_{k+1},h_{k+1},i_{k+1},e_{k+1},\
o_{k+2}.                                                \tag{1}
\]
The endpoints \(e_{k-1},o_{k+2}\) may belong to site blocks.

**Isolated-pair classification.** The free matching on (1)
is uniquely
\[
\{e_{k-1}o_k,\ e_ko_{k+1},\ e_{k+1}o_{k+2},\
  h_ki_{k+1},\ i_kh_{k+1}\}.                            \tag{2}
\]
Every other free group follows the ordinary block chain.
Consequently the parent has a Hamilton cycle containing both
site edges and the legal site-expanded child is Hamiltonian.
The conclusion persists for arbitrary positive original lobe
lengths.

**Proof.** The target-run parity barrier of Note 215 makes
(1) closed under the free matching. All its cross-block
matching edges lie in the opposite-side disk and cannot cross
one another, by Note 193. In a four-slot vacant block, the
only possible same-block free matching chord is \(o_je_j\);
the other colour-compatible pairs are old-cycle edges.

Number the vertices of (1) from \(0\) to \(9\). The even
vertex \(0=e_{k-1}\) can only be matched to the odd vertices
at positions \(1,3,5,7,9\).

If it matches \(5=o_{k+1}\), the entire target-free block
\(B_k\) lies inside that opposite-side chord and is closed
under \(M\). Its two boundary cycle edges form a forbidden
two-edge cut. If it matches \(9=o_{k+2}\), the same argument
applies to the union \(B_k\cup B_{k+1}\).

If \(0\) matches \(3=i_k\), positions \(1=o_k\) and
\(2=h_k\) lie inside the chord. They cannot match each
other because they are adjacent on \(C\). The only
same-block edge that could leave this interval is
\(o_ke_k\) on the face side; it would leave \(h_k\)
without a possible mate inside. Every cross-block mate
outside the chord would cross \(e_{k-1}i_k\). Thus this
case is impossible.

Suppose \(0\) matches \(7=i_{k+1}\). The six positions
\(1,\ldots,6\) are inside that chord. The only same-block
edge that could leave the six-position interval is
\(o_{k+1}e_{k+1}\); using it would leave five vertices
inside, an odd number, so it cannot occur. All six
vertices must therefore match internally. The mate of
\(1=o_k\) is either \(4=e_k\) or \(6=h_{k+1}\).
The first choice leaves positions \(2,3,5,6\):
their only nonadjacent colour-compatible pairing is
\(2\!-\!5,3\!-\!6\), whose two opposite-side chords
cross. The second choice leaves positions \(2,3,4,5\)
inside \(1\!-\!6\); vertex \(2\) could match \(3\),
an old-cycle edge, or \(5\), which leaves the adjacent
pair \(3,4\). Both are impossible. Hence position \(7\)
is also excluded.

Only \(0\!-\!1=e_{k-1}o_k\) remains. Reflect the same
argument at the other end of (1) to force
\(8\!-\!9=e_{k+1}o_{k+2}\). Among the six remaining
vertices, \(h_{k+1}\) has only \(i_k\) as a legal odd
mate: \(o_{k+1},i_{k+1}\) are its old-cycle neighbours,
and \(o_k,o_{k+2}\) are already matched. The chord
\(i_kh_{k+1}\) encloses \(e_k,o_{k+1}\), so they match.
Finally \(h_k\) matches \(i_{k+1}\). This proves (2).

All other groups contain no vacancy and have the forced
chain from Note 208. Thus the complete free matching is
Note 216's profile, and its five-edge detour supplies the
marked Hamilton cycle. Notes 001 and 178 give the claimed
child and longer-lobe conclusions. \(\square\)

The \(r=2,\ell=1,k=1\) member of the explicit Barnette
family in [Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
realizes the hypotheses. The classification does not apply
when the same free group includes additional short blocks
on either side of the vacant pair, when both vacancies lie
in one block, or when target order or gaps are defective.
