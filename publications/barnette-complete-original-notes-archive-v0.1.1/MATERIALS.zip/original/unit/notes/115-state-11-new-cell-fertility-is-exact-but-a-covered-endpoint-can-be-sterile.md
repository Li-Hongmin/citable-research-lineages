> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# State-\(11\) new-cell fertility is exact, but a covered endpoint can be sterile

[Note 114](114-all-new-cell-rooted-bonds-have-four-attachment-obstruction-types.md)
classifies shore connectivity for every child pair incident with
\(R_{00},X_{uy},X_{vx}\).  The first obstruction in that classification
is an occupancy void: there may be no opposite-gate pair to which the
attachment criteria can be applied.

This note gives the exact fixed-exterior fertility criterion for a
state-\(11\) parent colouring.  It then gives a legal split of
\(4\)-connected Eulerian triangulations in which the unique kill-covered
parent bond has a completely sterile state-\(11\) endpoint.  A different
old-exterior colouring repairs the child family by a one-vertex switch.
Thus full-family occupancy cannot be proved by extending the covering
parent endpoint.

## 1. Full new-cell occupancy

Use
\[
 {\cal C}^b={\cal A}_{C_{00}}^b\cup{\cal A}_{C_{10}}^b
              \cup{\cal A}_{C_{01}}^b,\qquad
 {\cal N}^b={\cal A}_{R}^b\cup{\cal A}_{U}^b
              \cup{\cal A}_{V}^b,
\tag{1}
\]
where \(R=R_{00}\), \(U=X_{uy}\), \(V=X_{vx}\), and \(b\) is the
surviving-gate bit.  The occupancy required before any row of Note 114 can
succeed is
\[
 (\mathsf{OX}_{\rm full})\qquad
 \bigl({\cal N}^0\times({\cal C}^1\cup{\cal N}^1)\bigr)
 \cup
 \bigl({\cal N}^1\times({\cal C}^0\cup{\cal N}^0)\bigr)
 \ne\varnothing .
\tag{2}
\]
Its negation is exactly
\[
\boxed{
 ({\cal N}^0=\varnothing\ \text{or}\
       {\cal C}^1\cup{\cal N}^1=\varnothing)
 \ \land\
 ({\cal N}^1=\varnothing\ \text{or}\
       {\cal C}^0\cup{\cal N}^0=\varnothing).}
\tag{3}
\]
Hence occupancy can fail in only two ways: both new-cell sectors are empty,
or one new-cell sector is nonempty while the whole opposite child sector is
empty.  By the canonical bijection of Note 108,
\[
 {\cal C}^b\ne\varnothing
 \quad\Longleftrightarrow\quad
 {\cal L}_{\neg11}^{\,b}\ne\varnothing.
\tag{4}
\]
The second failure form therefore requires all parent targets in the
missing child sector to have state \(11\).

## 2. Fixed-exterior fertility

Let \(\chi\) be a root-admissible parent NAE colouring in state \(11\).
After global reversal, assume
\[
 \chi(z)=\chi(P)=\chi(Q)=0.
\tag{5}
\]
Let \(I_A,I_B\) be the two \(P\)--\(Q\) paths in the link cycle of \(z\),
with vertex sets \(J_A,J_B\), and put
\[
 H=T-z=T^+-\{A,B,C\},\qquad
 H_i=H[\chi^{-1}(i)].
\tag{6}
\]
Write \(\operatorname{alt}_A(\chi)\) when the colours strictly alternate
on \(I_A\), and define \(\operatorname{alt}_B(\chi)\) analogously.

The five-bit rows at \(A,B,C,P,Q\) do not by themselves test the remaining
triangles along the two intervals.  Those triangles give
\[
\boxed{
\begin{array}{c|c}
\text{fixed-exterior extension}&\text{full child NAE condition}\\ \hline
U&\operatorname{alt}_A(\chi)\\
V&\operatorname{alt}_B(\chi)\\
R&\operatorname{alt}_A(\chi)\land\operatorname{alt}_B(\chi).
\end{array}}
\tag{7}
\]
Indeed, parent NAE already excludes a \(00\)-edge in either link path.
Changing the split-side apex colour to \(1\) is NAE exactly when the same
path also has no \(11\)-edge.

Let \(Z\) be the parent \(0\)-component containing \(z\), and define
\[
\begin{aligned}
t&=\#\{K\in\pi_0(H_0):K\cap(J_A\cup J_B)\ne\varnothing\},\\
t_A&=\#\{K\in\pi_0(H_0):K\cap J_A\ne\varnothing\},\\
t_B&=\#\{K\in\pi_0(H_0):K\cap J_B\ne\varnothing\},\\
t_{PQ}&=\#\{K\in\pi_0(H_0):K\cap\{P,Q\}\ne\varnothing\},\\
a&=\#\{K\in\pi_0(H_1):K\cap J_A\ne\varnothing\},\\
b&=\#\{K\in\pi_0(H_1):K\cap J_B\ne\varnothing\}.
\end{aligned}
\tag{8}
\]
The \(t\) components in the first line are exactly the fragments of
\(Z-z\).

**Theorem 1 (fertility criterion).**  If the colour of \(z\) is the centre
colour of the labelled region tree, then the parent has one
\(0\)-component and two \(1\)-components, the latter being the labelled
root leaves.  In this case
\[
\boxed{
\begin{aligned}
U\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land t_B=t\land a=1,\\
V\text{ is root-admissible}
 &\iff \operatorname{alt}_B(\chi)\land t_A=t\land b=1,\\
R\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land\operatorname{alt}_B(\chi)
       \land t_{PQ}=t\land a=b=1.
\end{aligned}}
\tag{9}
\]
If the colour of \(z\) is a leaf colour, then the parent has two
\(0\)-components and one \(1\)-component.  The component \(Z\) is one
root leaf, and the other \(0\)-component misses the link of \(z\).  In this
case
\[
\boxed{
\begin{aligned}
U\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land t_B=t,\\
V\text{ is root-admissible}
 &\iff \operatorname{alt}_B(\chi)\land t_A=t,\\
R\text{ is root-admissible}
 &\iff \operatorname{alt}_A(\chi)\land\operatorname{alt}_B(\chi)
       \land t_{PQ}=t.
\end{aligned}}
\tag{10}
\]

*Proof.*  In the centre-colour case, deleting \(z\) splits \(Z\) into
\(t\) zero fragments and leaves the two labelled one-components unchanged.
For the \(U\)-row, the zero vertex \(B\) reassembles exactly the fragments
meeting \(J_B\), while the one-core \(AC\) joins exactly the
\(a\) one-components meeting \(J_A\).  The child again has three
monochromatic components with distinct labelled leaves exactly when
\(t_B=t\) and \(a=1\), in addition to the NAE condition in (7).  This is
the first line of (9); the second is symmetric.  For the \(R\)-row, the
zero vertex \(C\) reassembles only the fragments containing \(P\) or \(Q\),
while the separate one-vertices \(A,B\) must each attach within one
labelled leaf.  This gives the third line.

In the leaf-colour case, the unique one-component is the centre and cannot
be fused with another centre component.  The untouched zero-component
remains one root leaf.  Root-admissibility is therefore equivalent only to
reassembling all fragments of \(Z-z\), which deletes the \(a=b=1\)
conditions and gives (10). \(\square\)

Call \(\chi\) **new-cell fertile** if at least one line of (9), or of
(10), holds.  Neither interval alternation nor the scalar three-component
condition alone implies fertility.  For example, in the centre-colour case
\[
 t=t_A=t_B=t_{PQ}=1,\qquad a=b=2
\tag{11}
\]
is sterile even when both intervals alternate, because every extension
fuses the two labelled leaves.  In the leaf-colour case
\[
 t=3,\qquad t_A=t_B=2,\qquad t_{PQ}=1
\tag{12}
\]
is sterile even when both intervals alternate, because every extension
leaves a fragment of \(Z-z\) unattached.

## 3. What a covered parent bond supplies

Let \(\chi^b\eta^{1-b}\) be a parent rooted bond covered by
\({\cal L}_{11}\).  Restrict attention first to child extensions retaining
one of these two exterior colourings.

* If exactly one endpoint, say \(\chi^b\), has state \(11\), then
  \(\eta\) has a canonical target in \({\cal C}^{1-b}\).  These inherited
  extensions satisfy (2) exactly when \(\chi\) is fertile.
* If both endpoints have state \(11\), neither has a canonical target.
  The inherited extensions satisfy (2) exactly when both endpoints are
  fertile.  Fertility of only one endpoint strands all inherited new
  targets in one gate sector.

The complete child family may contain a new-cell target with a different
old exterior.  Thus one parent bond proves full occupancy only through one
of the following alternatives:
\[
\boxed{
\begin{array}{ll}
\text{(i)}&\text{a mixed \(11\)--non-\(11\) bond with fertile
\(11\)-endpoint;}\\
\text{(ii)}&\text{an \(11\)--\(11\) bond with both endpoints fertile;}\\
\text{(iii)}&\text{a different-exterior new-cell target in the missing
gate sector.}
\end{array}}
\tag{13}
\]

## 4. A legal split with a sterile covering endpoint

Let \(T\) be the bipyramid over the rim
\[
 r_0r_1\cdots r_7r_0
\tag{14}
\]
with apices \(z,w\).  Split \(z\) across \(P=r_0,Q=r_4\).  Thus
\[
 I_A=r_0r_1r_2r_3r_4,\qquad
 I_B=r_4r_5r_6r_7r_0.
\tag{15}
\]
The child has \(A\) adjacent to the vertices of \(I_A\), \(B\) adjacent
to the vertices of \(I_B\), and
\[
 AC,BC,CP,CQ.
\tag{16}
\]
Both graphs are Eulerian plane triangulations.  They are \(4\)-connected:
if \(w\) remains after at most three deletions, it joins all surviving rim
vertices and every surviving patch vertex still has a neighbour in that
core; if \(w\) is deleted, at most two further vertices are lost, and the
rim paths are joined through the surviving \(A-C-B\) patch.

Take
\[
 e^*=wr_0,\qquad g_1^*=r_2r_3.
\tag{17}
\]
After fixing \(w=0\), the complete parent root-admissible family consists
of the following five rows, in vertex order
\((z,w,r_0,r_1,\ldots,r_7)\):
\[
\begin{array}{c|c|c|c}
 &\text{row}&\text{state \(11\)}&g_1\text{-bit}\\ \hline
\theta_0&0001011111&0&0\\
\beta   &0001101111&0&0\\
\alpha  &0001110111&1&1\\
\theta_3&0001111011&0&1\\
\theta_4&0001111101&0&1.
\end{array}
\tag{18}
\]
The six opposite-gate pairs have the following difference shores; the last
two columns give the numbers of induced components on the shore and its
complement:
\[
\begin{array}{c|c|c|c}
\text{pair}&D&c(T[D])&c(T[\bar D])\\ \hline
\theta_0,\alpha&\{r_2,r_4\}&2&1\\
\theta_0,\theta_3&\{r_2,r_5\}&2&1\\
\theta_0,\theta_4&\{r_2,r_6\}&2&1\\
\beta,\alpha&\{r_3,r_4\}&1&1\\
\beta,\theta_3&\{r_3,r_5\}&2&1\\
\beta,\theta_4&\{r_3,r_6\}&2&1.
\end{array}
\tag{19}
\]
Thus \(\alpha\beta\) is the unique parent rooted bond.  It is covered by
the state-\(11\) endpoint \(\alpha\), so the full parent antecedent holds.

Both intervals in (15) contain a \(11\)-edge under \(\alpha\).  By (7),
the fixed exterior \(\alpha|_H\) has no NAE extension in any of
\(R,U,V\).  The covering endpoint is therefore sterile before
root-admissibility is even tested.

Nevertheless the complete child family repairs it.  Flip only \(r_6\) in
the old exterior of \(\alpha\) and use the \(V\)-row
\[
 (A,B,C,P,Q)=(0,1,1,0,0).
\tag{20}
\]
Call the resulting target \(\gamma\).  Its monochromatic components are
\[
\begin{array}{c|c}
0&\{A,r_0,r_4,r_6,w\}\\
1&\{r_1,r_2,r_3\},\quad\{B,C,r_5,r_7\}.
\end{array}
\tag{21}
\]
The canonical \(C_{10}\)-extension \(\beta^+\) has components
\[
\begin{array}{c|c}
0&\{A,B,r_0,r_3,w\}\\
1&\{r_1,r_2\},\quad\{C,r_4,r_5,r_6,r_7\}.
\end{array}
\tag{22}
\]
In both rows the two triangles incident with \(wr_0\) meet distinct
one-components, so both are root-admissible.  Their gate bits are opposite,
and their difference shore is
\[
 D(\gamma,\beta^+)=\{r_3,r_4,r_6,B\}.
\tag{23}
\]
Both this shore and its complement are connected.  Hence
\(\gamma\beta^+\) is itself a child rooted bond.

The example proves, within the full legal actual class,
\[
\boxed{
\text{covering state-\(11\) endpoint}
\not\Longrightarrow
\text{same-exterior new-cell target}.}
\tag{24}
\]

## 5. Remaining actual-incidence theorem

The example does not realize \(\mathsf O\); it shows why the complete child
family is essential.  The exact remaining occupancy statement is:

> In every interface-disjoint legal split pair whose nonempty parent rooted
> bond graph is covered by \({\cal L}_{11}\), either some covered bond
> satisfies (i) or (ii) in (13), or the complete child NAE family supplies
> the different-exterior target in (iii).

An actual counterexample must protect a new-target vacuum or a
single-sector stranded family and simultaneously make every
different-exterior repair root-rigid.  Parent bondness, the labelled
three-region tree, the four-rank identity of Note 109, and the attachment
calculus of Note 114 do not individually exclude that configuration.
