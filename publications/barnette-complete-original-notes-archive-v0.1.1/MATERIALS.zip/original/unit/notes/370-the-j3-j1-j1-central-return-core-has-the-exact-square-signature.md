> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The J3,J1,J1 central-return core has the exact square signature

[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md)
gives a spanning route for every matching of the realizable
\(J_3,J_1,J_1\) triple.  Its positive corridor can first be shortened
without changing any exterior Hamilton decision.  If the remaining
optional chord \(h_1j_3\) is present, the *whole* triple-and-corridor
interval has the exact four-terminal Hamilton signature of a square.
This gives a two-way Barnette-class reduction, stronger than the
marked-route conclusion in that subcase.

Work in the compressed, gapless, tight-target all-square opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Use Note 344's old-cycle block order
\[
D_1,D_2,S_1,\ldots,S_q,D_3,
\quad D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),
\quad S_t=(c_t,r_t,s_t,d_t),\quad q\ge1.                 \tag{1}
\]
The common-face chords are \(a_sb_s\), \(i_1e_1\),
\(o_2k_2\), \(o_3k_3\), and \(c_td_t\).  Note 344 forces
\[
j_1h_2,\ k_1i_3,\ i_2h_3,\ j_2s_q,\ e_2r_1,
\quad s_tr_{t+1}\ (1\le t<q)                              \tag{2}
\]
in the complementary matching.  Only \(o_1,h_1,j_3,e_3\)
remain unmatched inside this interval.

**Corridor reduction, with or without the optional chord.**
The subgraph induced by \(S_1,\ldots,S_q\) is the ladder
\(L_{2q}=P_{2q}\square K_2\), with columns
\[
(c_1,r_1),(d_1,s_1),\ldots,(c_q,r_q),(d_q,s_q).          \tag{3}
\]
Its four, and only four, exterior edges are
\(b_2c_1,e_2r_1,j_2s_q,d_qa_3\).  Thus the labeled ladder
terminals are \((c_1,r_1,d_q,s_q)\), in the left-top,
left-bottom, right-top, right-bottom order of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
That theorem replaces every \(q\ge2\) by \(q=1\), in either
direction, while preserving the Barnette class and every
Hamilton decision on exterior and attachment edges.  This does
not depend on whether \(h_1j_3\) occurs.

The replacement also preserves the *specified opening*.
The old Hamilton cycle enters the corridor through \(b_2c_1\),
traverses its vertices in the order
\((c_t,r_t,s_t,d_t)_{t=1}^q\), and leaves through
\(d_qa_3\); it uses neither matching attachment.  On the
selected common-face boundary, the same strip traverses the
top rail \(c_1,d_1,c_2,d_2,\ldots,c_q,d_q\).
The square replacement has the old-cycle segment
\(c,r,s,d\), the face chord \(cd\), and the same four
attachments.  The site edges and residual square lie outside
this strip, so their labels and the legal site expansion commute
with the replacement.

Now suppose \(h_1j_3\) is in the matching.  Let \(Q_q\) be the
induced subgraph on all vertices in (1).  Its four degree-two
terminals, in cyclic disk order, are
\[
                         (a_1,o_1,e_3,b_3).              \tag{4}
\]
Every other patch vertex has degree three.  The terminal colours
are \(a_1,e_3\) on one side and \(o_1,b_3\) on the other.

**Exact four-pole theorem.** For every \(q\ge1\), \(Q_q\)
has exactly the four spanning one-path terminal pairs
\[
a_1o_1,\quad o_1e_3,\quad e_3b_3,\quad a_1b_3,           \tag{5}
\]
and exactly the two spanning two-path pairings
\[
\{a_1o_1,e_3b_3\},\qquad\{a_1b_3,o_1e_3\}.             \tag{6}
\]
Consequently replacing an induced disk copy of \(Q_q\) by a
square with the four labeled terminals (4), or reversing this
replacement, preserves Barnette membership and every exterior-
and attachment-marked Hamilton decision.  The patch has
\(24+4q\) vertices; the replacement removes \(20+4q\).

**All six routings.** Write
\[
\begin{split}
U_q={}&(c_t,r_t,s_t,d_t)_{t=1}^q,\\
W_q={}&(c_1,d_1,c_2,d_2,\ldots,c_q,d_q,
         s_q,r_q,s_{q-1},r_{q-1},\ldots,s_1,r_1),\\
V_q={}&(s_q,r_q,s_{q-1},r_{q-1},\ldots,s_1,r_1,
         c_1,d_1,c_2,d_2,\ldots,c_q,d_q).
\end{split}                                               \tag{7}
\]
Here \(U_q\) is the old-cycle corridor path,
\(W_q\) is a \(c_1\)--\(r_1\) spanning path, and
\(V_q\) is an \(s_q\)--\(d_q\) spanning path.
Every descending join \(r_ts_{t-1}\) in \(W_q,V_q\)
is the matching edge in (2).

The \(a_1\)--\(b_3\) routing is the full old-cycle path
through (1).  Note 344, equation (6), gives the following
\(o_1\)--\(e_3\) routing:
\[
\begin{split}
&(o_1,a_1,b_1,e_1,i_1,h_1,j_3,k_3,o_3,h_3,i_3,
  k_1,j_1,h_2,i_2,k_2,o_2,a_2,b_2,e_2,j_2,\\
&\hspace{38mm}V_q,a_3,b_3,e_3).
\end{split}                                               \tag{8}
\]
The other two one-path routings are, in the indicated endpoint
orientations,
\[
\begin{split}
o_1\to a_1:\quad
&(o_1,h_1,j_3,e_3,b_3,a_3,
  \operatorname{rev}(U_q),b_2,e_2,j_2,k_2,i_2,h_3,
  o_3,k_3,i_3,k_1,i_1,e_1,j_1,h_2,o_2,a_2,b_1,a_1),\\
e_3\to b_3:\quad
&(e_3,j_3,k_3,i_3,k_1,i_1,h_1,o_1,a_1,b_1,e_1,
  j_1,h_2,o_2,a_2,b_2,W_q,e_2,j_2,k_2,i_2,h_3,
  o_3,a_3,b_3).
\end{split}                                               \tag{9}
\]
For the first pairing in (6), take the two disjoint paths
\[
\begin{split}
&(a_1,b_1,e_1,i_1,h_1,o_1),\\
&(e_3,j_3,k_3,i_3,k_1,j_1,h_2,o_2,a_2,b_2,
  W_q,e_2,j_2,k_2,i_2,h_3,o_3,a_3,b_3).
\end{split}                                               \tag{10}
\]
For the second pairing, take
\[
\begin{split}
&(a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,W_q,
  e_2,j_2,k_2,i_2,h_3,o_3,a_3,b_3),\\
&(o_1,h_1,i_1,k_1,i_3,k_3,j_3,e_3).
\end{split}                                               \tag{11}
\]
Each displayed pair visits every patch vertex exactly once;
each join is an old-cycle edge, a listed face chord, or a
matching edge in (2) together with \(h_1j_3\).  The four
single paths likewise span \(Q_q\).  Conversely, a spanning
path has opposite-colour ends, ruling out the other two
terminal pairs.  The third two-path pairing would interlace
four boundary terminals in a disk.  Equations (8)--(11)
therefore give the complete square signature.  A global
Hamilton cycle meets the four-edge patch cut in two or four
edges, and its patch part must be one of these six states;
replacing that state in either direction retains the exterior
and its marked edges.

**Barnette-class preservation.** It remains to justify the
three-connectivity comparison, rather than infer it from the
Hamilton signature.  For \(q=1\), cap the four terminals of
\(Q_1\) by a new square in the cyclic order
\((t_B,t_E,t_o,t_a)\), attaching it by
\(b_3t_B,e_3t_E,o_1t_o,a_1t_a\).  A Hamilton cycle of this
32-vertex cubic graph follows the full old-cycle path from
\(a_1\) through \(b_3\), then
\(t_B,t_E,t_o,t_a,a_1\).  Its complementary matching is:
\[
\begin{array}{ll}
\text{one page:}&a_sb_s\ (s=1,2,3),\ i_1e_1,\ o_2k_2,
 o_3k_3,\ c_1d_1,\ t_Bt_a;\\
\text{other page:}&j_1h_2,\ k_1i_3,\ i_2h_3,\ j_2s_1,
 e_2r_1,\ h_1j_3,\ o_1t_o,\ e_3t_E.
\end{array}                                                \tag{12}
\]
In the displayed Hamilton order, chords on each page are
disjoint or nested, and every chord joins opposite old-cycle
parities.  Thus the capped graph is simple, cubic, bipartite,
and plane.  Its matching-chord interlacement graph has the
following connected spanning tree; each dash means that the
two endpoint pairs alternate in the Hamilton order:
\[
\begin{gathered}
t_Bt_a-o_1t_o-a_1b_1-j_1h_2-a_2b_2-i_2h_3-a_3b_3,\\
t_Bt_a-e_3t_E,\qquad
a_1b_1-k_1i_3-o_3k_3,\qquad a_1b_1-h_1j_3,\\
j_1h_2-i_1e_1,\qquad j_1h_2-o_2k_2,\qquad
a_2b_2-j_2s_1-c_1d_1-e_2r_1 .
\end{gathered}                                             \tag{13}
\]
For example, \(k_1<o_3<i_3<k_3\) verifies one less
immediate dash; the others follow by their displayed
old-cycle positions.  A two-edge cut in a cubic Hamiltonian
graph would cut the Hamilton cycle twice, enclosing a proper
old-cycle interval closed under all matching edges.  Such an
interval disconnects the interlacement graph, contrary to
(13).  The Hamilton cycle also excludes bridges.  In a
cubic graph, absence of one- and two-edge cuts implies
three-vertex-connectivity.  Hence this cap is a Barnette
graph.  Replacing its \(S_1\) by the ladder (3), using
Note 178, gives a Barnette cap for every \(Q_q\).

The old-cycle path through \(Q_q\), together with the three
overlapping chords \(a_1b_1,h_1j_3,a_3b_3\), shows that
\(Q_q-v\) is connected for every vertex \(v\): each internal
position of the path is crossed by one of these chords that
is not incident with \(v\).  Moreover, after deleting any
two patch vertices, every surviving component meets a
surviving terminal.  Otherwise that component would also be
separated after the same deletions in the three-connected
Barnette cap, since the cap's only patch attachments are at
the four terminals.

The square has the same two deletion properties.  In any
three-connected cubic host containing either induced disk
patch, the exterior is connected: distinct exterior
components would each require at least three of the four
attachment edges.  If at most one patch vertex is deleted,
the patch remains connected; comparison with the host using
the corresponding deleted terminal, or no patch deletion for
an internal vertex, shows that each exterior component still
has a surviving attachment.  If two patch vertices are
deleted, the exterior is intact and connected and every
surviving patch component reaches a terminal.  This proves
three-connectivity in both replacement directions.  The
two-page disk embedding and terminal colour pattern preserve
planarity and bipartiteness; cubicity and simplicity follow
from the four labeled attachments.  The theorem follows.
\(\square\)

In the specified facial opening, the square replacing \(Q_q\)
is one short target-free block: the old-cycle segment becomes
\((a_1,o_1,e_3,b_3)\), and the common-face arc through the
block-closing chords becomes its chord \(a_1b_3\).  Thus
the \(h_1j_3\) branch is removable independently of all
vacancies outside this four-pole.  The \(h_1j_3\)-absent
branch still has the six-terminal core and Note 344's
spanning-route theorem; the corridor reduction above
shortens its \(q\) but does not make that core a four-pole.
The selected opening and Note 344 supply the forced matching;
the four-pole replacement itself applies to any Barnette host
containing this induced disk patch.  It does not resolve other vacancy
types, opening types, or Barnette's conjecture.  The proof is
project-internal and has not had independent review.
