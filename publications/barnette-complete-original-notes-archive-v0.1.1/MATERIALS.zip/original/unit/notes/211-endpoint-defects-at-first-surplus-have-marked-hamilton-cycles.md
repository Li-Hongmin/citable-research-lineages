> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Endpoint defects at first surplus have marked Hamilton cycles

[Note 197](197-gapless-square-trap-defect-budget.md) shows that a
gapless all-square opening with \(f=4r+4\) has at most one defect in
the escape-target order. [Note 201](201-delayed-boundary-targets-have-hamiltonian-children-at-one-chord-near-equality.md)
settled an endpoint defect when \(r=1\). The same matching argument
extends to every number of opposite-face chords: the blocks preceding
the delayed target form one forced nested matching, while all remaining
free slots follow the ordinary chain.

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\) avoiding
the disjoint cofacial matching site edges \(q=xy,p=uv\). Select an
all-square opening and compress its lobes to one square each as in
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Let \(\ell,r\ge1\) be its lobe and opposite-face-chord counts. Assume
that every interblock gap is empty and \(f=4r+4\). Use the blocks
\(B_0=[x,y]_C\), \(B_i=[a_i,b_i]_C\) for \(1\le i\le r\), and
\(B_{r+1}=[u,v]_C\).

**Endpoint-defect Hamilton theorem.** If \(R_\ell\) is not the first
interior slot of \(B_0\), or if \(L_1\) is not the final interior slot
of \(B_{r+1}\), then \(G\) has a Hamilton cycle containing both \(p,q\).
Consequently its legal site-expanded child is Hamiltonian. This holds
for all \(\ell,r\ge1\) and all positive lengths of the original lobes.

More precisely, in the first case \(R_\ell\) is the third interior
slot of a block \(B_h\) with \(1\le h\le r+1\). All preceding blocks
are short. Denote their free interiors by \(o_i,e_i\), \(0\le i<h\),
and denote the first two free interiors of \(B_h\) by \(o_h,w\).
For \(h\le r\), write \(e_h\) for the final free slot of \(B_h\),
and use \(o_i,e_i\) for the first and final free slots of the later
face blocks; write \(o_{r+1}\) for the free first slot of the final
site block. When \(h=r+1\), its \(o_h\) is this same final-block
first slot. Then the entire free-slot matching is

\[
 M_{\rm free}=\{o_0w\}\cup
                 \{e_i o_{i+1}:0\le i\le r\}.
\tag{1}
\]

**Proof.** By Note 197, a delayed first target consumes the unique
vacant eligible even position. The final target and all consecutive
transitions are therefore tight. The endpoint barrier in that note
excludes \(R_\ell\) from the first slot of a later block. Every
eligible position before this first target is vacant, so there is
exactly one: \(R_\ell\) is the third slot of some \(B_h\), and all
earlier blocks are short. If \(h=0\), the first two slots of \(B_0\)
are adjacent free vertices. The second is even and cannot match the
first; every later free odd vertex of \(B_0\) is absent, and a
cross-block mate would straddle \(R_\ell\), contrary to the planar
no-straddling lemma of [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Thus \(h\ge1\).

The free slots preceding \(R_\ell\) are exactly
\[
 o_0,e_0,o_1,e_1,\ldots,o_{h-1},e_{h-1},o_h,w,
\tag{2}
\]
an even number. A free matching edge joining different blocks
cannot cross \(R_\ell\) by Note 203. The only possible same-block
free edge across that target is \(o_he_h\) when \(h\le r\): \(w\)
and \(e_h\) have the same colour, and in the final site block no
free slot follows its target run. Thus at most one matching edge
could leave the even set (2). Matching parity says the number
leaving is even, so none leaves.

For each occupied \(L\)-target run after \(R_\ell\), the count of
free slots before its first target is also even: it is \(2h+2\)
in \(B_h\), \(2j+2\) in a later face block \(B_j\), and \(2r+4\)
in the final site block. Cross-block free edges cannot straddle
the target by Note 203, while at most one same-block free edge
can cross the run. The same parity argument forbids that edge.
Consequently the free slots split at every occupied target run.

All free matching edges among (2) join different blocks: each
\(o_i e_i\), \(i<h\), and \(o_hw\) are old-cycle edges. By
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
these matching chords lie in one disk opposite the common site face
and are noncrossing. The first free slot \(o_0\) cannot match
\(e_j\) for \(j<h\). For \(j=0\) that would duplicate an old-cycle
edge. For \(1\le j<h\), noncrossing would match all intervening
free slots inside the chord \(o_0e_j\). The consecutive old-cycle
interval from \(x\) through the right endpoint of \(B_j\) would
then be closed under the full complementary matching, including
all site and face chords, and would have only two departing
old-cycle edges. This contradicts three-edge-connectivity.
Hence \(o_0w\in M\).

Inside \(o_0w\), the remaining slots are
\(e_0,o_1,e_1,\ldots,e_{h-1},o_h\). The standard short-block
skipping rule of [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
forces \(e_i o_{i+1}\in M\) for \(0\le i<h\): skipping one
complete short block would match its adjacent interiors to one
another, and skipping at least two would close a proper
consecutive interval under \(M\), again a forbidden two-edge cut.
After \(R_\ell\), the target barriers leave only ordinary groups
\(e_a,o_{a+1},\ldots,e_{b-1},o_b\). The same skipping rule forces
\(e_i o_{i+1}\in M\) for \(h\le i\le r\). This proves (1),
including \(h=r+1\), when the latter range is empty.

Let \(A\) be the even-starting matching of \(C\), numbered from
\(x\). Since \(R_\ell\) is the third slot of \(B_h\), \(wR_\ell\in A\).
The tight transitions and residual squares make the path
\[
 x,o_0,w,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
 \gamma_\ell,L_\ell,R_{\ell-1},\ldots,
 R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v
\tag{3}
\]
in \(M\cup A\), where \(xo_0,wR_\ell\in A\) and \(o_0w\in M\).
For \(\ell=1\), omit the inter-lobe transitions. Formula (1)
makes all other vertices the second \(x\)-to-\(v\) path
\[
 x,y,e_0,o_1,a_1,b_1,e_1,\ldots,
 o_r,a_r,b_r,e_r,o_{r+1},u,v.
\tag{4}
\]
The two paths share only \(x,v\) and cover all vertices, so
their union is one Hamilton cycle containing \(q,p\). Note 001
lifts it through the legal site expansion, and Note 178 restores
the original lobe lengths. Reversing the oriented main segment,
interchanging the site labels and reversing the lobe labels proves
the reflected final-target case. \(\square\)

Together with [Note 210](210-every-tight-gapless-first-surplus-opening-has-a-hamiltonian-child.md),
this settles every gapless first-surplus opening with tight target
order or an endpoint defect. The only gapless target-order branch
still outside these theorems has one nonadjacent consecutive
transition. Openings with two gap slots or nonsquare residual
cycles also remain outside their scope. No assertion about the
full Barnette conjecture follows.

[Note 212](212-every-gapless-first-surplus-opening-has-a-marked-hamilton-cycle.md)
subsequently settles the remaining transition-defect branch.
