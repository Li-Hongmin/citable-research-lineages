> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nested split unary equality reduces to a sealed four-terminal child

[Note 474](474-disjoint-split-unary-nodes-close-the-chorded-equality-profile.md) leaves nested split marked unary nodes at the chorded \(c=5f-7\) equality boundary. Two inner openings and one alternative outer opening settle every nested terminal distribution except a specific four-terminal inner child with no face matching edge crossing its boundary.

Retain the one-root chorded setting and four terminals \(T=\{r_L,u,v,r_R\}\), ordered \(r_L<u<v<r_R\), of [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md). Let the outer and inner marked unary nodes be
\[
 N_o=(H_o,s_o,A_o,t_o,J_o),\qquad
 N_i=(H_i,s_i,A_i,t_i,J_i),\qquad N_i\subset A_o ,
\tag{1}
\]
where \(A_o,A_i\) are their respective sole child words, with ends \(L_o,R_o\) and \(L_i,R_i\). All other assigned special positions lie in two-special leaves. Write \(C_W\) for the old root cycle, \(E\) for the square-supported old leaf edges, and \(M\) for the face matching of the special positions outside \(T\).

**Nested reduction theorem.** If the parent lacks a Hamilton cycle through both site edges, then all four terminals lie in \(A_i\), no \(M\)-edge has exactly one end in \(A_i\), and at least one \(M\)-edge joins
\[
                    D=A_o\setminus A_i
                    \quad\hbox{to}\quad
                    B=W\setminus A_o .
\tag{2}
\]
The directly assigned positions \(s_i,t_i\) are nonterminals with distinct face-matching mates: the mate of \(s_i\) lies to its left, and the mate of \(t_i\) lies to its right. This is a necessary configuration, not a non-Hamiltonian example.

**Proof.** Open both nodes inside their child words:
\[
 F_{\rm ii}
  =\bigl(C_W-E-\{s_oL_o,R_ot_o,s_iL_i,R_it_i\}\bigr)
        \cup M\cup\{L_oR_o,L_iR_i\}.
\tag{3}
\]
It has degree one precisely at \(T\). Restoring \(E\) leaves three connected old pieces before the \(M\)-edges are considered: the inner child \(A_i\) closed by \(L_iR_i\); the two flanks of \(D\), joined through \(L_oR_o\); and \(B\), joined through the root chord. Every two-special leaf lies wholly in one piece. If a child chord inserted in (3) is itself a leaf chord, that leaf's deleted old edge is a quotient loop and needs no switch.

Let \(K\) have the three vertices \(A_i,D,B\), with edges given by \(M\)-chords between pieces. Within any component of \(K\), leaf-square switches of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) connect all components of \(F_{\rm ii}\). If \(K\) is connected, a forest rooted at the two terminal paths absorbs every cycle. The same holds if \(K\) has two components, each with exactly two terminals. Either outcome gives a spanning internal two-path cover and hence a parent Hamilton cycle by the two exterior pairings of Note 460.

Consider a component of \(K\) with no terminal. The following possibilities are excluded directly.

* An isolated \(A_i\) with no terminal has only the two old boundary edges \(s_iL_i,R_it_i\) in its cut, contradicting three-connectivity.
* An isolated \(B\) with no terminal leaves all four terminals in \(A_o\). The special positions before \(s_o\) consist of complete two-special leaves. Together with \(s_o\) they form an odd nonterminal set. No \(M\)-edge can run from this set into \(A_o\), while an edge to a position after \(A_o\) would span a terminal in \(A_o\) and cross its exterior attachment, by the terminal barrier of Note 474. The odd set cannot be matched.
* If \(B\) is isolated with all four terminals, then \(A_o=A_i\cup D\) has no terminal and no \(M\)-edge to \(B\). Its cut consists of the two old boundary edges \(s_oL_o,R_ot_o\), again impossible.

Suppose next that \(D\) alone is a zero-terminal component. Its left flank contains \(s_i\) and complete two-special leaves, and its right flank contains \(t_i\) and complete two-special leaves. Each flank has an odd number of special positions. Since no \(M\)-edge leaves \(D\), an odd number of its matching chords must join the flanks and span \(A_i\). The terminal barrier forbids such a chord if \(A_i\) contains a terminal. Thus \(A_i\) has no terminal and all four terminals lie in \(B\). Three-connectivity then forces an \(M\)-edge from \(A_i\) to \(B\).

If instead \(D\) is isolated with all four terminals, \(A_i\) and \(B\) contain none. Three-connectivity again forces an \(M\)-edge from \(A_i\) to \(B\).

Both isolated-\(D\) cases are closed by opening the outer node inside and the inner node outside:
\[
 F_{\rm io}
  =\bigl(C_W-E-\{s_oL_o,R_ot_o,H_is_i,t_iJ_i\}\bigr)
       \cup M\cup\{L_oR_o,H_iJ_i\}.
\tag{4}
\]
The chord \(H_iJ_i\) is unused by \(C_W\), since the inner marked node has two plain-unary ancestors at equality. After restoring \(E\), (4) has three old pieces: the central arc \(P=s_i\rightsquigarrow t_i\), the remaining \(D'=D\setminus\{s_i,t_i\}\) closed through \(L_oR_o,H_iJ_i\), and the outer path \(B\). The \(M\)-edge from \(A_i\) to \(B\) joins \(P\) to \(B\).

When \(D\) has no terminal, \(s_i,t_i\) are both nonterminals. Their \(M\)-mates lie in \(D\), because \(D\) was isolated, and they cannot be matched to one another by [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md). Thus an \(M\)-edge joins \(P\) to \(D'\); the quotient is connected and yields the internal two-path cover. When all four terminals lie in \(D\), the same argument applies if at least one of \(s_i,t_i\) is a nonterminal. If both are terminals, \(P\cup B\) has two terminals and \(D'\) has the other two; leaf switches absorb cycles in these two components separately. Hence an isolated \(D\) also gives a parent Hamilton cycle.

With three coarse vertices, any other disconnected component without terminals is \(A_i\cup D\), \(A_i\cup B\), or \(D\cup B\). The first makes \(B\) an isolated four-terminal block, already excluded. The second makes \(D\) an isolated four-terminal block, just closed. The third makes \(A_i\) an isolated four-terminal block. Therefore failure of the marked parent cycle requires exactly the configuration in the theorem: \(A_i\) contains all four terminals and no \(M\)-edge crosses it, while \(D\) and \(B\) are connected by an \(M\)-edge.

Finally \(s_i,t_i\) are outside \(A_i\), so neither is a terminal. With no \(M\)-edge crossing \(A_i\), their mates lie outside \(A_i\); [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) rules out matching them to each other. A chord from \(s_i\) to the right of \(A_i\), or from \(t_i\) to the left of \(A_i\), would span all four terminals in \(A_i\) and cross one of their exterior attachments. Hence the mate of \(s_i\) lies to its left and the mate of \(t_i\) to its right. \(\square\)

The theorem concerns only the selected chorded single-hexagon equality profile. It does not decide the sealed inner-child configuration, smaller kernels, other openings, or Barnette's conjecture.
