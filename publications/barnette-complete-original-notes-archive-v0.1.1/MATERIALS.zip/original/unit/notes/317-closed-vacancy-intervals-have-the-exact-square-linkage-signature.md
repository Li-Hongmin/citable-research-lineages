> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Closed vacancy intervals have the exact square linkage signature

[Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md)
constructs \(S,K,X\) for an interval whose vacancies match
internally. Those three states imply the full four-terminal
Hamilton linkage signature of a square. This makes the interval
an exact reduction even when it contains arbitrarily many nested
vacancy components.

Let \(G\) be any Barnette graph containing the following
induced disk patch \(D=B_a,\ldots,B_b\). Each block is
either a short square with local spine order \(a_j,o_j,e_j,b_j\)
and closing edge \(a_jb_j\), or a vacant six-cycle
with local spine order \(a_j,o_j,H_j,I_j,e_j,b_j\)
and closing edge \(a_jb_j\). Consecutive blocks are
joined by \(b_ja_{j+1}\) and \(e_jo_{j+1}\).
The vacancy slots are matched among themselves by
noncrossing edges on the side opposite the closing edges.
Exactly four edges leave \(D\), one each at
\(a_a,o_a,e_b,b_b\), in this cyclic order around its disk.
No Hamilton cycle of \(G\) is assumed. A target-free
internal block interval in the opening of Note 275,
whose vacancy matching is closed inside it and whose
internal ordinary links are retained, is one source of
such a patch. Let \(Q\) be one short square with the
same four labeled attachments and closing edge \(a'b'\).

**Closed-interval square theorem.** The spanning one-path
and two-path Hamilton linkage signatures of \(D\) and
\(Q\) are identical. Replacing \(D\) by \(Q\) gives a
Barnette graph with the same exterior graph and labeled
attachment edges. Hamilton cycles transfer in both directions with the
same exterior edges and used attachments. If \(D\) has
more than four vertices, a vertex-minimal non-Hamiltonian
Barnette graph cannot contain such an interval.

**Proof of the signature.** The terminal colours alternate:
\(a_a,e_b\) have one colour and \(o_a,b_b\) the
other. A spanning path has an even number of vertices,
so its endpoints have opposite colours. There are four
candidate pairs. The concatenated local spine through
\(D\) is an \(a_a\)--\(b_b\) spanning path. The local
construction of Note 275, whose prime-component induction uses
only the displayed noncrossing matching and retained internal
links, applies without a global Hamilton cycle and gives
an \(o_a\)--\(e_b\) spanning path \(S(D)\).
For the other two pairs, take Note 275's disjoint
\(X(D)\) paths
\[
   a_a\longleftrightarrow b_b,\qquad
   o_a\longleftrightarrow e_b.
\]
Their union plus the two boundary spine edges
\(a_ao_a\) and \(e_bb_b\) is a Hamilton cycle of
the induced interval graph. Deleting \(a_ao_a\) gives
an \(a_a\)--\(o_a\) spanning path; deleting
\(e_bb_b\) gives an \(e_b\)--\(b_b\) spanning path.
The two possible noncrossing two-path pairings are
realized by Note 275's \(K(D)\) and \(X(D)\).
The third pairing
\(\{(a_a,e_b),(o_a,b_b)\}\) interlaces around the
interval disk, so planar disjoint paths cannot realize
it. This is exactly the square's four one-path pairs
and two two-path pairings. The usual even-cut argument
then replaces the local part of any global Hamilton
cycle, or of any spanning path collection with exterior
endpoints, in either direction without changing its
exterior route.

**Proof of Barnette preservation.** The four exterior
edges are incident with the interval disk in the stated
order. Draw the square in that disk, putting \(a'b'\)
on the side of the old closing edges. The square's colours agree
with the four terminal colours. Simplicity and
cubicity follow from the distinct labeled attachments.

Let \(H=G-V(D)\). Since \(G\) is three-edge-connected
and only four edges leave \(D\), \(H\) is connected:
two components would each need at least three of the
four attachments. Delete at most two vertices of the
reduced graph. With two square vertices deleted, each
survivor attaches to the connected \(H\). With no square
vertex deleted, the remaining square is connected and
every component of the deleted exterior attaches to it,
as follows from connectivity of \(G\) after those same
deletions. With one square vertex deleted, delete instead
the corresponding terminal of \(D\), together with the
same possible exterior vertex, in \(G\). Three-connectivity
of \(G\) makes every surviving exterior component attach
at one of the other three terminals; the remaining
square is connected. Thus the reduced graph remains
connected after any two vertex deletions and is Barnette.
Exact Hamilton transfer and strict size reduction prove
the minimal-counterexample assertion. \(\square\)

**Closed two-port corridor corollary.** In the opening of
[Note 316](316-peelable-multi-vacancy-corridors-have-three-spanning-states.md),
suppose every vacancy slot in the corridor
\(B_{s+1},\ldots,B_t\) is matched to another vacancy
slot of that corridor. The only missing ordinary links
of the group are still \(P_s,P_t\). The corridor is then
a closed interval \(D\) as above: every internal ordinary
link is retained, while the four exterior attachments
are the two old-cycle edges and the matching edges at
\(o_{s+1},e_t\). Compress it to one short square.
In the opening's two-page drawing, the new closing edge
follows the old common-face side, while all opposite-side
exterior matching endpoints keep their order. Thus the
marked opening is preserved. The two missing links become
consecutive and share that
square, so [Note 291](291-every-consecutive-two-port-short-shared-block-group-has-three-routes.md)
gives \(S,K,X\) in the reduced Barnette group. The exact
signature lifts all three states to the original group.
Under the usual other-group routes, Notes 273, 001, and
182 give a marked Hamilton parent cycle and a Hamilton
legal child. The number and nesting of vacancy-only
components within the corridor are unrestricted.

The four-pole reduction requires every internal vacancy
matching edge to stay inside the interval. A corridor
vacancy component with an atom outside it creates extra
attachments and is not covered by this compression.
Combining this corollary with Note 316, any two-port
free group in the stated opening that lacks one of
\(S,K,X\) must have **at least two port-free
corridor vacancies and a vacancy matching edge crossing
the corridor boundary**. Indeed, if a corridor vacancy
belongs to a port component, its rainbow cycle connects
that vacancy to an atom outside the corridor or to the
outside end of the port, so one of its matching edges
leaves the corridor. If every corridor vacancy is
port-free, failure of the closed matching condition
directly supplies such an edge. This is a necessary residual
configuration, not an example of a missing state.
The general Barnette conjecture remains open.
