> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Adjacent-unary two-root chord-free openings are Hamiltonian

[Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md) leaves a chord-free equality profile with two ordinary roots and one marked unary node. When that node's two directly assigned special positions are adjacent on the old Hamilton cycle, the one-unsupported-edge splice of [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md) closes connected root-face arrangements. For a disconnected root face graph, an open-arc bridge dichotomy and two exterior pairings close the remaining split-site arrangement.

Use the chord-free single-hexagon setup of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md): the site edges are \(q=w_0u,p=vw_*\), the escape targets are \(t_d<t_c<t_b<t_a\), and two exposed special positions \(z_1,z_2\) lie outside the ordinary roots \(W_1,W_2\). Every special position assigned inside a root except \(s,t\) belongs to a two-special leaf. The positions \(s,t\) are assigned directly to one marked unary ordinary node and form an old-cycle edge \(d=st\), either before or after its child word. The roots may have arbitrary ordinary wrappers.

**Adjacent-unary two-root theorem.** The legal expanded child is Hamiltonian. If no two escape targets are adjacent and the exposed positions are not both site ports, the parent has a Hamilton cycle containing both site edges \(p,q\).

**Proof.** If two escape targets are adjacent, [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) merges the selected two-cycle opening. Otherwise the parity and exposed-slot argument of Note 458 leaves exactly its orders A, B, C. In A and C both \(z_i\) are face-chord endpoints. In B, both are site ports only when \(u=z_1,v=z_2\), an adjacent-site case closed by the one-edge facial-gap switch of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md).

Suppose first that the root face graph \(K\) is connected. Use the disjoint root cycles and exterior paths from the connected-\(K\) proof of Note 458. Delete the adjacent-special old edge at each two-special leaf and also \(d\), then insert all face-matching edges except at the root terminals. The edges at the two-special leaves have pairwise disjoint square supports; \(d\) is outside all those supports. The cycles and the face matching are connected because \(K\) is connected. Thus the two- or four-terminal one-unsupported-edge theorem of Note 459 gives the same internal spanning path or two distinct terminal pairings required by Note 458, without restoring \(d\). For four terminals, one pairing differs from the fixed exterior pairing; for two, the exterior path closes the internal path. In both cases the parent has a Hamilton cycle through \(p,q\). Note 458 proves \(K\) connected as well when B has exactly one outside site port. Therefore a failure requires both \(z_i\) to be face-chord endpoints and \(K\) disconnected.

When \(K\) is disconnected, each even root word has exactly two special attachments among the two site edges and the two face chords from \(z_1,z_2\). Indeed, its cut contains two old-cycle boundary edges, has even size by cubicity, and has size at least four by three-connectivity; the four attachments are exhausted by the two roots. In order A, both exposed face chords must end before \(u\), since a chord from a \(z_i\) to a position after \(u\) would cross \(q=w_0u\). If \(u\in W_1\), that root would have at least three special attachments. Hence \(u,v\in W_2\), while both \(z_i\) have mates in \(W_1\). Reflection gives \(u,v\in W_1\) in order C.

In order B, if \(u,v\) belong to the same root, that root's two attachments are precisely the site edges; the two \(z_i\)-mates lie in the other root. Thus in A, C, and this B case, let \(W\) be the root containing both site ports. Every face chord incident with \(W\) is internal to it. If \(d\subset W\), apply the two-terminal one-unsupported-edge theorem of Note 459 to the old \(W\)-arc closed by its root chord: it gives a spanning \(u\)--\(v\) path in \(W\). If \(d\) lies in the other root, all assigned positions of \(W\) are in two-special leaves, and the two-terminal theorem of Note 458 gives the same path.

For A, with \(W=W_2\), a spanning \(w_0\)--\(w_*\) path outside \(W\) is
\[
 w_0,t_d,z_1,z_2,t_c,
 W_{1,\ell}\xrightarrow{\rm old}W_{1,r},
 t_b,b,c,d,\beta,\alpha,a,t_a,w_*.
\tag{1}
\]
For B with \(W=W_2\), use
\[
 w_0,t_d,W_{1,\ell}\xrightarrow{\rm old}W_{1,r},
 t_c,z_1,z_2,t_b,b,c,d,\beta,\alpha,a,t_a,w_*.
\tag{2}
\]
Every step is an old-cycle edge, an escape edge, or the trap chord \(\alpha\beta\), and each path covers every vertex outside \(W\) once. Reflection gives the C path and the B path when \(W=W_1\). Joining either exterior path to \(q\), the internal \(u\)--\(v\) path, and \(p\) gives a marked parent Hamilton cycle.

Only order B with site ports in different roots remains. Its main order is \(w_0,t_d,W_1,t_c,z_1,z_2,t_b,W_2,t_a,w_*\). Its two \(z_i\)-mates must also split between the roots. Noncrossing forces \(z_1r_1\) with \(r_1\in W_1\) and \(z_2r_2\) with \(r_2\in W_2\): the reversed root assignment would give interlacing chords. If \(r_1<u\), \(z_1r_1\) crosses \(q=w_0u\); if \(v<r_2\), \(z_2r_2\) crosses \(p=vw_*\). Hence \(u<r_1\) and \(r_2<v\).

We need an open-arc version of the one-unsupported-edge splice. Let \(P\) be an old root arc from \(L\) to \(R\), let \(E\) be its disjoint square-supported two-special-leaf edges, let \(d=st\) be the adjacent direct-special edge outside those supports, and let \(M\) match all special positions except two terminals \(a,b\). Put
\[
                       F_0=(P-E-\{d\})\cup M,
\tag{3}
\]
and form a quotient \(Q\) by contracting the components of \(F_0\) and representing \(E\cup\{d\}\) as edges. The graph \(F_0\) has two path components with endpoints \(L,R,a,b\), and possibly cycles; \(Q\) is connected because restoring \(E,d\) restores the spanning path \(P\). If \(Q-d\) is connected, the open-arc square-switch argument of Note 458 applies with the switchable edges \(E\): choose a quotient tree, omit one edge on its route between the two path components, absorb every cycle, then switch at the omitted edge. This gives spanning two-path covers in two distinct pairings, both containing \(M\) and avoiding \(d\).

If \(Q-d\) is disconnected, no \(M\)-edge crosses \(d\): such an edge, together with the two old subarcs and the restored \(E\)-edges, would connect \(Q-d\). The old arc \(P-d\) has a left part containing \(L\) and a right part containing \(R\); each part, with its own \(E\)-edges restored, is connected. Thus \(Q-d\) has exactly these two components. In each restored part, every vertex has degree two except its ordinary endpoint of \(P\) and its special terminals; degree parity forces exactly one of \(a,b\) into each part. Square switches along a spanning tree of each component absorb its cycles into a path. The resulting cover pairs \(L\) with the left terminal and \(R\) with the right terminal. These are all the conclusions needed from the open-arc dichotomy.

Apply this dichotomy to the root containing \(d\). If its \(Q-d\) is connected, it has two internal pairings; the other root has two by Note 458, so the exterior cover (5) of that note closes one choice to a marked parent Hamilton cycle. If \(Q-d\) is disconnected and \(d\subset W_1\), the terminal order \(u<r_1\) forces its internal pairing to be \((W_{1,\ell},u)(W_{1,r},r_1)\). Use instead the following four disjoint exterior paths:
\[
\begin{aligned}
 &(u,w_0,\beta,\alpha,a,b,t_b,W_{2,\ell}),\\
 &(W_{1,\ell},t_d,d,c,t_c,W_{1,r}),\\
 &(v,w_*,t_a,W_{2,r}),\\
 &(r_1,z_1,z_2,r_2).
\end{aligned}
\tag{4}
\]
They cover every vertex outside the roots exactly once; their non-old steps are the two site edges, the trap chord, the escape edges \(bt_b,t_dd,ct_c\), and the two \(z_i\)-face chords. Combining (4) with the forced \(W_1\) pairing leaves two exterior paths at \(W_2\), paired as \((W_{2,\ell},r_2)(v,W_{2,r})\). Note 458 supplies two different spanning internal pairings for the all-leaf root \(W_2\); one differs from this exterior pairing and closes a single Hamilton cycle. If \(d\subset W_2\), reflect (4). Then its forced pairing is \((W_{2,\ell},r_2)(W_{2,r},v)\), and the all-leaf root \(W_1\) supplies the different pairing. Thus every remaining case has a parent Hamilton cycle through \(p,q\). [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal expanded child. \(\square\)

**Equality consequence.** The \(m=f,R=2,c=5f-8\) row of Note 477 is Hamiltonian whenever its single marked unary node has adjacent directly assigned special positions, regardless of ordinary wrapper lengths. A hypothetical failure in this row must split those positions around the node's child word. The three-root two-unary row remains separate; Barnette's conjecture is not decided.
