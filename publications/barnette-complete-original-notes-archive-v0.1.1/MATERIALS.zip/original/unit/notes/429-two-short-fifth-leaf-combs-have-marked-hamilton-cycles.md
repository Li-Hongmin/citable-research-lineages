> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two short-fifth-leaf combs have marked Hamilton cycles

[Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md) lists five comb words that might support a non-Hamiltonian legal child under face matching I. This note gives spanning $y_1$--$x_7$ paths for the two combs whose short leaf is leaf 5, with depth vectors
\[
 (1,2,6,6,5,4,3)\quad\text{and}\quad(3,4,6,6,5,2,1).
 \tag{1}
\]
Both paths use only the two available face chords $y_2x_3$ and, respectively, $y_4x_5$ or $y_5x_6$. Thus every legal child with either word is Hamiltonian.

Use $F(P,Q)=(((P Q)))$, full leaves $U_i=((x_i y_i))$, and the short leaf $S_5=(x_5y_5)$. A full leaf has old-cycle order $L_i,h_i,x_i,y_i,j_i,R_i$ and the spanning paths $Y_i,X_i,O_i$ of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equation (1). Its branch bracket paths $P_T,Q_T,R_T$ are those of Note 428, equation (2). We also use the bracket-only path
\[
 H_T=(\lambda_0^T,\lambda_1^T,\lambda_2^T,
        \rho_2^T,\rho_1^T,\rho_0^T),                       \tag{2}
\]
from the first to the last vertex of a branch. Every consecutive pair in (2) is an old-cycle edge except $\lambda_2^T\rho_2^T$.

**First comb.** Its full word is
\[
 K=F(U_3,U_4),\quad V=F(K,S_5),\quad B=F(V,U_6),\quad
 C=F(B,U_7),\quad E=F(U_2,C),\quad W=F(U_1,E).            \tag{3}
\]
The following path has endpoints $y_1,x_7$:
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{X_3^{-1}}R_3,
L_4\xrightarrow{Y_4^{-1}}y_4,
x_5,y_5,R_5,L_5,
\rho_0^K\xrightarrow{H_K^{-1}}\lambda_0^K,\\
&\lambda_2^V\xrightarrow{Q_V^{-1}}\rho_0^V,
L_6\xrightarrow{O_6}R_6,
\rho_2^B\xrightarrow{R_B}\lambda_0^B,
\lambda_2^C\xrightarrow{P_C}\rho_2^C,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                  \tag{4}
\]
The jumps $y_2x_3$ and $y_4x_5$ are face chords of matching I. The short-leaf segment $(x_5,y_5,R_5,L_5)$ uses old-cycle edges and $R_5L_5$. Every other join between displayed pieces is an old-cycle edge: $L_1\lambda_2^W$, $\rho_2^W\rho_0^E$, $\lambda_2^E L_2$, $R_3L_4$, $L_5\rho_0^K$, $\lambda_0^K\lambda_2^V$, $\rho_0^V L_6$, $R_6\rho_2^B$, $\lambda_0^B\lambda_2^C$, and $\rho_2^C R_7$.

**Second comb.** Its word is
\[
 K=F(U_3,U_4),\quad A=F(K,S_5),\quad R=F(U_2,A),\quad
 S=F(U_1,R),\quad T=F(S,U_6),\quad W=F(T,U_7).             \tag{5}
\]
Here a spanning path is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^S\xrightarrow{P_S}\rho_2^S,
\rho_0^R\xrightarrow{Q_R}\lambda_2^R,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{X_3^{-1}}R_3,
L_4\xrightarrow{O_4}R_4,
\rho_2^K\xrightarrow{R_K}\lambda_0^K,
\lambda_2^A\xrightarrow{P_A}\rho_2^A,\\
&R_5,L_5,x_5,y_5,
x_6\xrightarrow{X_6^{-1}}R_6,
\rho_2^T\xrightarrow{R_T}\lambda_0^T,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                  \tag{6}
\]
The jumps $y_2x_3$ and $y_5x_6$ are matching-I face chords. The short-leaf segment $(R_5,L_5,x_5,y_5)$ uses $R_5L_5$ and two old-cycle edges. The other joins are, in order, $L_1\lambda_2^S$, $\rho_2^S\rho_0^R$, $\lambda_2^R L_2$, $R_3L_4$, $R_4\rho_2^K$, $\lambda_0^K\lambda_2^A$, $\rho_2^A R_5$, $R_6\rho_2^T$, $\lambda_0^T\lambda_2^W$, and $\rho_2^W R_7$, all old-cycle edges.

Each of (4) and (6) uses the six full leaves once, the four vertices of $S_5$ once, and the six bracket vertices of each of its six named branches once. Hence each visits exactly $6\cdot6+4+6\cdot6=76$ distinct vertices, all of its word. The edge checks above prove both are spanning paths. Appending the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), gives a parent Hamilton cycle containing both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal expanded child. \(\square\)

Together with Note 428, three of the six necessary row-I words of Note 427 are Hamiltonian in every legal completion. The remaining words are the two $(1,2)$-site combs and the $(1,7)$-site comb with short leaf 2. No assertion is made about their realizability or Hamiltonicity, or about the other face matchings and Barnette's conjecture.
