> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Boundary square traps either peel or force a Hamiltonian child

The cube expansion identified in
[Note 185](185-two-squares-sharing-an-edge-have-a-four-terminal-hamilton-signature.md)
has a precise application beyond the sharp main-segment equality of
[Note 184](184-every-sharp-square-trap-opening-has-a-hamiltonian-child.md).
At either end of an all-square facial opening, a square trap with
consecutive escape targets is removable. The only obstruction to a
simple inverse is a collision with a site edge; that collision itself
gives a Hamilton cycle in the expanded child.

Use the one-square-per-lobe normal form of
[Notes 176--179](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Thus \(G\) is a Barnette graph with a Hamilton cycle \(C\) avoiding
the disjoint cofacial site edges \(q=xy,p=uv\), the legal square
expansion is \(G^+\), and the main \(C\)-segment \(S_0\) runs from
\(x\) to \(v\). Its \(\ell\ge1\) residual squares occur on the other
\(C\)-arc in the order
\[
v,\alpha_1,a_1,b_1,\beta_1,\ldots,
\alpha_\ell,a_\ell,b_\ell,\beta_\ell,x.
\tag{1}
\]
The complementary matching contains
\(\alpha_i\beta_i,a_iL_i,b_iR_i\). Along \(S_0\) the escape
targets occur as \(R_\ell,L_\ell,\ldots,R_1,L_1\), possibly
with other vertices between them.

**Boundary-peeling theorem.** Suppose either the first three
vertices of \(S_0\) are \(x,R_\ell,L_\ell\), or its last three
vertices are \(R_1,L_1,v\). In the first case let \(B\) be the
vertex following \(L_\ell\); in the second let \(A\) precede
\(R_1\).

* If \(B=y\) in the first case, \(G\) has a Hamilton cycle
  containing \(q\) and avoiding \(p\); if \(A=u\) in the
  second, it has one containing \(p\) and avoiding \(q\).
  In either case \(G^+\) has an explicit
  Hamilton cycle.
* Otherwise delete the six vertices of that boundary trap and
  restore its two interrupted \(C\)-edges. This produces a smaller
  Barnette parent \(H\) with a Hamilton cycle \(C_H\) avoiding the
  same site \(p,q\). Its legal site expansion \(H^+\) is Barnette,
  has an all-square facial opening with \(\ell-1\) residual squares,
  and satisfies
  \[
  G^+\text{ is Hamiltonian}\quad\Longleftrightarrow\quad
  H^+\text{ is Hamiltonian}.
  \tag{2}
  \]
  The main segment loses two vertices, so
  \(|S_0|-2\ell\) is unchanged.

This holds without a bound on \(|S_0|\) or an assumption that the
other site-face arc alternates.

**Proof, left boundary.** Assume \(S_0\) starts
\(x,R_\ell,L_\ell,B\). Let \(z\) be the predecessor of
\(\alpha_\ell\) on the other \(C\)-arc: \(z=v\) if
\(\ell=1\), and \(z=\beta_{\ell-1}\) otherwise. The six
vertices
\[
T=\{R_\ell,L_\ell,\alpha_\ell,a_\ell,b_\ell,
\beta_\ell\}
\tag{3}
\]
induce exactly the patch \(P\) of Note 185, under
\(R=R_\ell,L=L_\ell,\alpha=\alpha_\ell,
\gamma=a_\ell,\delta=b_\ell,\beta=\beta_\ell\).
Their four external edges are
\[
xR_\ell,\qquad L_\ell B,\qquad
z\alpha_\ell,\qquad\beta_\ell x.
\tag{4}
\]
Indeed, the displayed \(C\)-edges and matching edges exhaust
the cubic degrees of all six vertices. The inverse restores
\(xB,zx\), two edges incident at \(x\). The only surviving
old edge at \(x\) is \(q=xy\), so the inverse is simple
exactly when \(B\ne y\); \(zx\) cannot duplicate \(q\),
since \(z\) lies on the other \(C\)-arc and is not \(y\).

If \(B\ne y\), Note 185 gives Barnette membership and
Hamiltonicity equivalence for this incident-edge insertion,
applied separately to \(G\) and \(G^+\). Replacing the two
\(C\)-subpaths \(x,R_\ell,L_\ell,B\) and
\(z,\alpha_\ell,a_\ell,b_\ell,\beta_\ell,x\) by
\(xB,zx\) gives a Hamilton cycle \(C_H\). Neither site edge
lies in \(C_H\). In the inherited plane embedding, the chosen
common-face arc ending at \(x\) replaces
\(z,\alpha_\ell,\beta_\ell,x\) by \(z,x\); the other
site-face arc and both site edges remain. Hence \(p,q\) are
still cofacial and their square expansion is legal. Removing
\(T\) commutes with that expansion because \(T\) contains
no site port or site-square vertex. The chosen facial opening
loses precisely \(S_\ell\), proving (2) and the parameter
claims.

If \(B=y\), the inverse would create a second copy of
\(xy=q\), so no simple Barnette inverse is claimed. Instead
formally shortcut the two displayed \(C\)-subpaths to \(xy\)
and \(zx\), obtaining a cyclic order on \(V(G)\setminus T\).
In that order replace \(xy\) by the site-square path
\[
x,c,b,a,d,y
\tag{5}
\]
and replace \(zx\) by
\[
z,\alpha_\ell,a_\ell,L_\ell,R_\ell,
b_\ell,\beta_\ell,x.
\tag{6}
\]
Here \(a,b,c,d\) are the four *new site-square* vertices
of Note 001, distinct from the indexed old vertices
\(a_\ell,b_\ell\). Every transition in (5)--(6) is an
edge of \(G^+\). The paths are internally disjoint, cover
all four new and all six removed vertices, and replace the
two shortcuts of one cycle. Thus they give a Hamilton cycle
of \(G^+\), without using the deleted site edges. Replacing
(5) by the actual parent edge \(q=xy\) gives a Hamilton
cycle of \(G\) containing \(q\); (5) is its direct site lift.

**Right boundary.** Suppose the end of \(S_0\) is
\(A,R_1,L_1,v\), and let \(z\) follow \(\beta_1\) on
the other \(C\)-arc, so \(z=x\) when \(\ell=1\).
The same six-vertex patch has attachments
\(AR_1,L_1v,v\alpha_1,\beta_1z\). Its inverse restores
\(Av,vz\), incident at \(v\). The only possible duplicate
is \(Av=p=uv\), precisely when \(A=u\). For \(A\ne u\),
reflect Note 185's incident-edge equivalence and repeat the
left-boundary face and opening argument. For \(A=u\), shortcut
the corresponding \(C\)-subpaths to \(uv,vz\), then replace
them by
\[
u,a,d,c,b,v
\qquad\text{and}\qquad
v,\alpha_1,a_1,L_1,R_1,b_1,\beta_1,z,
\tag{7}
\]
respectively. The same edge and vertex check gives a Hamilton
cycle of \(G^+\). Replacing the first route in (7) by
\(p=uv\) gives a Hamilton cycle of \(G\) containing \(p\).
\(\square\)

**Boundary-irreducible normal form.** Start with any legal
all-square opening, compress its lobes as in Note 178, and
repeatedly apply the theorem at either available boundary.
The process ends in one of two ways: it constructs a Hamilton
cycle of the original child, or it reaches a smaller legal
Barnette opening with at least one residual square and neither
boundary triple. At each simple peeling, the child Hamilton
decision is equivalent in both directions and
\(|S_0|-2\ell\) is fixed. Indeed, each peeling decreases
\(\ell\) by one, so the process terminates. If it reaches
\(\ell=0\), the selected face arc is a single \(C\)-edge;
replacing that edge by the spanning site-square route makes
the reduced child Hamiltonian, and the equivalences lift the
cycle back. A collision already supplies the explicit cycle
above. \(\square\)

**Minimal-counterexample consequence.** Among non-Hamiltonian
Barnette children admitting an all-square facial opening,
choose one with the fewest vertices. Note 178 first removes
every nonsingleton lobe without changing the Hamilton decision.
The theorem then rules out either boundary triple
\(x,R_\ell,L_\ell\) or \(R_1,L_1,v\): a site-edge collision
would make the child Hamiltonian, while a simple inverse would
give a smaller non-Hamiltonian Barnette child with the same
kind of opening. When \(\ell=1\), even the simple-inverse
case is Hamiltonian: the reduced \(C_H\) contains the
one-edge face arc \(vx\), which can be replaced by the
site-square path \(v,b,a,d,c,x\) to obtain a Hamilton cycle
of \(H^+\), and (2) lifts it to \(G^+\).

This is a reduction for the all-square facial-opening class.
It does not establish that every Barnette graph has such an
opening or settle Hamiltonicity of boundary-irreducible cases.
