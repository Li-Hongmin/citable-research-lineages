> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Existence-level C4 lifting holds through reduced order twenty

[Note 066](066-existence-level-c4-lifting-survives-through-reduced-order-eighteen.md)
proves that complete-family selection repairs every prescribed-edge
degree-four lift through reduced brace order 18. The order-20 obstruction in
[Note 068](068-even-fully-alternating-two-gate-targets-need-not-lift.md)
shows that new witness-level failures do occur at the next order. This note
proves that none of them closes an entire target family: existence-level
lifting still succeeds for every order-20 interface.

## Exact finite theorem

Let \(F'\) be a simple plane cubic bipartite brace with
\(|V(F')|\le20\), let \(T'=F'^*\), and split a vertex of \(T'\) along two
nonconsecutive gates so that the expanded graph \(T\) is again a simple
4-connected Eulerian plane triangulation. Let \(a\) be any edge of \(T'\)
not incident with the split vertex, so it survives unchanged in \(T\).

If \(T'\) has a prescribed-edge target colouring for \(a\), then some
target colouring for \(a\) extends, with every surviving old vertex colour
fixed, to a target colouring of \(T\).

Equivalently, if the reduced rooted matching family

\[
\mathcal T_e=
\{M:e\in M,\ F'-M\text{ is two cycles separating the ends of }e\}
\tag{1}
\]

is nonempty, then it contains a member whose finite decorated lift state
satisfies the rooted-connectivity test of Note 065(5).

## Complete order-20 coverage

The command

    geng -cqb -d3 -D3 20

generates 703 connected simple cubic bipartite isomorphism representatives.
Exactly 11 are planar, 8 are planar and 3-connected, and 5 pass both the
direct independent-two-edge extension test and the strict-Hall brace test.

For these five braces, the exhaustive embedded-dual calculation gives

\[
\begin{array}{lr}
\text{nonconsecutive gate pairs}&366,\\
\text{admissible odd-arc 4-connected splits}&258,\\
\text{surviving rooted interfaces}&6108,\\
\text{NAE colourings modulo complement}&474,\\
\text{target-shape colourings modulo complement}&192,\\
\text{root--target pairs modulo complement}&894,\\
\text{target/interface instances}&35108,\\
\text{local assignments tested}&280864,\\
\text{target lifts}&40760,\\
\text{existence-level failures}&0.
\end{array}
\tag{2}
\]

Every surviving root interface has a nonempty antecedent family, and every
one of the 6108 complete families contains at least one successful local
assignment.

Combining (2) with Note 066, the complete through-20 range contains 8798
rooted split interfaces, 45364 target/interface instances, and 362912
tested local assignments, with no existence-level failure.

The proof bundle is
[locked-boundary-escape-order20](../computations/bundles/locked-boundary-escape-order20/README.md).
It streams one graph, split, and colouring at a time. A second run reproduced
the accepted JSON byte for byte.

## Why the quantifier matters at order twenty

The fully alternating target of Note 068 occurs in this same complete
corpus and fails all eight local assignments. At its fixed interface, the
complete reduced family has nine targets: three fail and six lift. Thus the
order-20 theorem is genuinely an existence-level selection result; it is not
the consequence of every witness becoming locally well behaved.

This also prevents two misleading readings of (2):

1. zero existence failures does not restore arbitrary-witness lifting;
2. the number of successful rows does not supply a general selection rule.

The surviving mathematical object is the complete family (1) together with
the component partition and two root marks in Note 065(5).

## Boundary

**Exact conclusion.** Existence-level prescribed-edge \(C_4\) lifting holds
for every reduced simple plane cubic bipartite brace through order 20.

**Weakest load-bearing step.** The arbitrary-order statement is not proved;
the order bound rests on geng's complete isomorph-free generation and exact
planarity filtering. All graph, brace, colouring, split, root, and lift
properties after generation are checked directly.

**Evidence level.** This is an exact computer-assisted finite theorem.
Note 068 separately supplies a proof-level explicit witness obstruction
inside the covered order.

**Unresolved boundary.** Reduced order 22 and all larger orders remain open.
More importantly, no general theorem yet forces the complete family
\(\mathcal T_e\) to meet the liftable rooted-connectivity states. Further
adjacent expansion is not a substitute for that selection mechanism.
