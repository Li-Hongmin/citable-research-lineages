> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A delayed central-corridor return has a forced Hamilton route

[Note 350](350-an-arbitrary-central-corridor-gives-a-square-equivalent-four-double-core.md)
settles the \(h_1o_3\) branch of an alternating four-double group
with an arbitrary central short-block corridor. The first new
mate of \(h_1\) is \(r_2\). More generally, a mate \(r_t\) forces
the matching through the earlier part of the corridor; if
\(o_1h_3\) is also present, it forces the entire no-flank group.

Use the compressed, gapless, tight-target all-square opening
of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group, with even left endport
\(L\) and odd right endport \(R\), consist exactly of
\[
D_1,D_2,S_1,\ldots,S_q,D_3,D_4,\qquad q\ge1,                 \tag{1}
\]
with no outer short flank. The blocks and their old-cycle order
are those of Note 350 (1), and the same-block complementary
matching chords are
\[
                 i_1e_1,\quad o_2k_2,\quad i_3e_3,\quad o_4k_4.
                                                                  \tag{2}
\]
These are the \(J_3,J_1,J_3,J_1\) types.

**Delayed-return theorem.** In a Barnette parent satisfying (1)--(2),
\(h_1r_1\) is impossible. If \(h_1r_t\) occurs for
\(2\le t\le q\), the following opposite-face chords are forced:
\[
k_1i_2,\quad j_1h_2,\quad e_2r_1,\quad
s_ur_{u+1}\ (1\le u<t-1),\quad j_2s_{t-1}.                 \tag{3}
\]
If \(o_1h_3\) also occurs, the *entire* complementary matching
in the group is forced. In addition to (2)--(3) and
\(h_1r_t,o_1h_3\), its chords are
\[
s_ur_{u+1}\ (t\le u<q),\quad s_qo_3,\quad
k_3i_4,\quad j_3h_4,\quad Lj_4,\quad e_4R.                 \tag{4}
\]
The group has a vertex-spanning \(L\)--\(R\) path. Every
pair \(q\ge2,\ 2\le t\le q\) is realized by a
\((44+4q)\)-vertex three-connected cubic bipartite plane
parent with a Hamilton cycle containing both edges of a
legal facial \(C_4\)-expansion site; its
\((48+4q)\)-vertex legal child is Hamiltonian. Neither
adjacent \(J_3,J_1\) pair in this family is a local
Note 335 square.

If \(h_3j_4\) occurs instead, \(D_3,D_4\) form
Note 335's local square and the whole group again has a
spanning \(L\)--\(R\) path. The mate \(h_3R\) is
impossible. Apart from \(o_1,j_4,R\), the only possible
mate of \(h_3\) is \(r_u\) with \(t<u\le q\).
For each such \(u\), the entire matching is again forced;
it has a spanning route and a three-connected marked
Hamilton realization of the same order.
Consequently **every** actual matching with \(h_1r_t\),
for any \(q\ge2,\ 2\le t\le q\), has a spanning
\(L\)--\(R\) path.
If all vacancies outside a group settled here lie in
distinct internal blocks, its parent has a Hamilton cycle
through both site edges and its legal child is Hamiltonian.

**Forced matching.** By the chord-isolation lemma of
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md),
(2) supplies the only same-block free chords. By
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md),
all cross-block free chords are noncrossing on the opposite
page. A proper interval of complete blocks closed under
the complementary matching would have only its two
boundary old-cycle edges leaving it, contradicting
three-connectivity.

Inside \(h_1r_t\), the free slots occur in the order
\[
k_1,j_1,h_2,i_2,j_2,e_2,
r_1,s_1,\ldots,r_{t-1},s_{t-1}.                            \tag{5}
\]
The even slot \(k_1\) cannot meet \(j_1\), an old-cycle
neighbour. Its other colour-compatible inner candidates
apart from \(i_2\) are \(j_2,r_1,\ldots,r_{t-1}\);
each encloses an odd number of the free slots in (5).
Hence \(k_1i_2\), then \(j_1h_2\), are forced.
For \(t=1\), the remaining inner pair would be the
old edge \(j_2e_2\), proving impossibility.

For \(t\ge2\), \(j_2\) must meet some \(s_u\) with
\(u<t\); \(j_2e_2\) is an old edge. If \(u<t-1\),
the complete suffix \(S_{u+1},\ldots,S_{t-1}\)
lies outside \(j_2s_u\) but inside \(h_1r_t\), so
noncrossing makes that suffix matching-closed. Thus
\(j_2s_{t-1}\). Its remaining inner even slot
\(e_2\) must meet some \(r_u\), and \(u>1\)
would close the complete prefix \(S_1,\ldots,S_{u-1}\).
Thus \(e_2r_1\). The same first-skipped-block
argument forces every link \(s_ur_{u+1}\) in (3).

Suppose now that \(o_1h_3\) also occurs. Between the
ends of that chord, after (3), the unmatched slots
are \(s_t,r_{t+1},s_{t+1},\ldots,r_q,s_q,o_3\).
The odd slot \(o_3\) can meet only some \(s_u\)
with \(t\le u\le q\). If \(u<q\), the entire
short-block suffix \(S_{u+1},\ldots,S_q\) is
matching-closed. Hence \(s_qo_3\). The same
first-skipped-block argument now forces the
links \(s_ur_{u+1}\) for \(t\le u<q\).
Outside \(o_1h_3\), parity and forbidden old
edges force \(k_3i_4,j_3h_4\). The remaining
slots are \(L,j_4,e_4,R\); since \(j_4e_4\)
is an old edge, they force \(Lj_4,e_4R\).
This proves (4) and uniqueness. \(\square\)

**The remaining mate of \(h_3\).** After (3), a
colour-compatible mate of \(h_3\) on the opposite page
can only be \(o_1\), some \(r_u\) with \(u>t\),
\(o_3,j_3,i_4,j_4\), or \(R\).
The edges \(h_3o_3\) and \(h_3j_3\) are respectively
an old edge and a forbidden same-block chord;
\(h_3i_4\) encloses the three unmatched free slots
\(k_3,j_3,h_4\). If \(h_3R\), the six slots
\(k_3,j_3,h_4,i_4,j_4,e_4\) inside that chord
force \(k_3i_4,j_3h_4\) and the forbidden
old edge \(j_4e_4\). If \(h_3j_4\), its
four inner slots force \(k_3i_4,j_3h_4\).
These three chords are precisely the local square of
[Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md)
on \(D_3,D_4\). Compress it to one short block.
The remaining group has just the adjacent mixed pair
\(D_1,D_2\), with short blocks only on its right;
[Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
gives a spanning route, which lifts through the exact
square signature. For \(t=q\) there is no possible
\(r_u\) with \(u>t\). The remaining
\(h_3r_u\) case is settled below. \(\square\)

**Spanning route and realization.** Write
\(F_u=(r_u,c_u,d_u,s_u)\) for the four-vertex
route through \(S_u\). In (3)--(4), put
\[
\begin{split}
W_{q,t}={}&
(j_4,k_4,i_4,k_3,i_3,h_3,o_1,a_1,b_1,a_2,b_2,e_2,\\
&F_1,\ldots,F_{t-1},\\
&j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,\\
&F_t,\ldots,F_q,\\
&o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4).
\end{split}                                                \tag{6}
\]
Here each \(F_u\) expands to its four listed vertices;
the two corridor ranges are nonempty because
\(t\ge2\) and \(t\le q\). Every consecutive pair is
an old edge, one of the block-closing or internal
chords, or a chord of (3)--(4), \(h_1r_t,o_1h_3\).
The lists cover every vertex of (1) exactly once.
Thus \((L,W_{q,t},R)\) is the spanning group route.

To realize every \(q,t\), use Note 350's old Hamilton
cycle (5). Put the site, block-closing, internal
and residual-square matching chords on its common-face
side, as in Note 350. On the opposite side put
\(\delta R_1,wj_4,e_4z,\gamma L_1\) and all
core chords in (3)--(4), \(h_1r_t,o_1h_3\),
omitting the group-endport edges \(Lj_4,e_4R\).
The chord \(o_1h_3\) surrounds \(h_1r_t\);
the links of (3) lie inside \(h_1r_t\), and
the corridor links of (4) lie after it but inside
\(o_1h_3\).
Every other chord lies in a disjoint or nested interval,
so both pages are noncrossing. Every vertex receives
exactly one matching chord of the opposite old-cycle
colour, and none is an old edge. The parent is
therefore simple, cubic, bipartite and plane.

For three-connectivity, retain the following part of
Note 348 (9)'s connected chord-interlacement system:
\[
\begin{gathered}
xy-wj_4-a_4b_4-e_4z-uv-\gamma L_1-\alpha\beta-\delta R_1,\\
a_4b_4-j_3h_4-a_3b_3-o_1h_3-a_1b_1-k_1i_2-a_2b_2,\\
a_1b_1-j_1h_2-o_2k_2,\quad
a_3b_3-k_3i_4-i_3e_3,\quad
k_1i_2-i_1e_1,\quad k_3i_4-o_4k_4.
\end{gathered}                                             \tag{7}
\]
Attach all corridor chords by
\[
\begin{gathered}
a_1b_1-h_1r_t-c_td_t,\qquad
a_2b_2-e_2r_1-c_1d_1,\qquad
a_2b_2-j_2s_{t-1}-c_{t-1}d_{t-1},\\
c_ud_u-s_ur_{u+1}-c_{u+1}d_{u+1}
\quad(1\le u<q,\ u\ne t-1),\\
c_qd_q-s_qo_3-a_3b_3 .
\end{gathered}                                             \tag{8}
\]
Each dash is endpoint alternation on the displayed old
cycle. For instance \(h_1<c_t<r_t<d_t\) and
\(c_q<s_q<d_q<o_3\); the other
alternations are those in Note 350 (6).
Equations (7)--(8) contain every matching chord
in one connected interlacement graph. A two-edge
cut in a cubic Hamiltonian graph would enclose a
matching-closed old-cycle interval and disconnect
this interlacement graph. There is no bridge
because the old cycle spans. Hence the parent is
three-edge-connected and, being cubic,
three-vertex-connected.

Its site face, residual square and tight targets are
the same as in Note 350. The paths
\[
x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
\quad\text{and}\quad
x,y,w,W_{q,t},z,u,v                                      \tag{9}
\]
are internally disjoint and together visit every
parent vertex once. Their union is a Hamilton cycle
containing both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal child.
For an arbitrary opening with either settled group
matching, replace just its standard free-group route
by \((L,W_{q,t},R)\), or by the lifted Note 336 route
in the local-square case. Note 324's other group
routes and target path remain disjoint and spanning.
\(\square\)

**Second delayed return.** Assume \(t<u\le q\) and
\(h_3r_u\) occurs. Inside this chord, \(o_3\) can
meet only \(s_v\) for \(u\le v\le q\).
A choice \(v<q\) would close the complete suffix
\(S_{v+1},\ldots,S_q\), so \(s_qo_3\) is forced.
The same first-skipped-block argument forces
\(s_vr_{v+1}\) for \(u\le v<q\).
After (3) and these chords, the unmatched slots
in the opposite-page order are
\[
L,o_1,s_t,r_{t+1},s_{t+1},\ldots,
r_{u-1},s_{u-1},k_3,j_3,h_4,i_4,j_4,e_4,R .
\]
The odd slot \(o_1\) can meet only \(L\), an
\(s_v\) with \(t\le v<u\), or \(k_3,h_4,e_4\).
An \(s_v\) with \(v\ge u\) lies inside \(h_3r_u\)
and its chord from \(o_1\) would cross \(h_3r_u\).
An edge \(o_1s_v\) would close the full-block
prefix \(D_1,D_2,S_1,\ldots,S_v\).
The edges \(o_1k_3,o_1h_4\) enclose, respectively,
the odd number \(2(u-t)-1\) and
\(2(u-t)+1\) of as-yet-unmatched slots.
If \(o_1e_4\), noncrossing forces \(LR\),
closing the entire group. Hence \(Lo_1\).

Starting at \(s_t\), suppose \(v<u-1\) and
all earlier gap links are standard.
The even slot \(s_v\) can meet only a later
\(r_w\) with \(v<w<u\), or \(j_3,i_4,j_4,R\).
A choice \(w>v+1\) closes the intervening
complete short blocks. The choices \(j_3,i_4\)
enclose odd numbers of unmatched slots.
If \(s_vj_4\), the first interior slot
\(r_{v+1}\) has no mate: its neighbour
\(s_{v+1}\) is an old edge, a later \(s_w\)
with \(w<u\) would close \(S_{v+1},\ldots,S_w\),
one with \(w\ge u\) would cross \(h_3r_u\),
and \(k_3,h_4\) each enclose an odd number
of free slots. Finally \(s_vR\) closes
the complete suffix \(S_{v+1},\ldots,D_4\).
Thus \(s_vr_{v+1}\) is forced for
\(t\le v<u-1\). At the last \(s_{u-1}\),
the same exclusions leave only \(j_4\);
its four inner slots force \(k_3i_4,j_3h_4\),
and \(e_4R\) follows. The whole matching,
besides (2), is therefore exactly
\[
\begin{gathered}
h_1r_t,\ h_3r_u,\ k_1i_2,\ j_1h_2,\ e_2r_1,\
j_2s_{t-1},\ s_{u-1}j_4,\ s_qo_3,\\
s_vr_{v+1}\quad
  (1\le v<q,\ v\notin\{t-1,u-1\}),\\
k_3i_4,\ j_3h_4,\ Lo_1,\ e_4R .
\end{gathered}                                             \tag{10}
\]
This also proves uniqueness for every \(q,t,u\).

With \(F_v=(r_v,c_v,d_v,s_v)\) as above, the
following route spans the group from \(L\) to \(R\):
\[
\begin{split}
L,\ o_1,a_1,b_1,a_2,b_2,e_2,\
F_1,\ldots,F_{t-1},\
j_2,k_2,o_2,h_2,i_2,k_1,j_1,e_1,i_1,h_1,\\
F_t,\ldots,F_{u-1},\
j_4,k_4,i_4,k_3,i_3,h_3,\
F_u,\ldots,F_q,\
o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4,\ R .
\end{split}                                                \tag{11}
\]
The six joins between its displayed pieces are
\(e_2r_1,s_{t-1}j_2,h_1r_t,
s_{u-1}j_4,h_3r_u,s_qo_3\);
the first and last edges use \(Lo_1,e_4R\).
All remaining consecutive pairs are old edges,
face chords, or chords of (10). Every block vertex
appears exactly once.

For realization, use again Note 350's old Hamilton
cycle (5) and all its common-face chords. Replace
the exterior chord \(wj_4\) by \(wo_1\), and put
the core chords in (10), except \(Lo_1,e_4R\),
on the opposite page with
\(\delta R_1,e_4z,\gamma L_1\).
The intervals of \(h_1r_t\) and \(s_{u-1}j_4\)
are disjoint; \(h_3r_u\), \(s_qo_3\) and the
right double-block chords lie inside
\(s_{u-1}j_4\), nested or disjoint as in (10).
The other intervals are inside \(h_1r_t\)
or disjoint from it. Thus this is a simple
cubic bipartite plane graph.

Its chord-interlacement graph is connected.
The following endpoint-alternation paths contain
every chord, where the block closings \(c_vd_v\)
are joined by the standard links in (10):
\[
\begin{gathered}
xy-wo_1-a_1b_1-k_1i_2-a_2b_2-e_2r_1-c_1d_1,\\
a_1b_1-h_1r_t-c_td_t,\qquad
a_2b_2-j_2s_{t-1}-c_{t-1}d_{t-1},\\
c_{u-1}d_{u-1}-s_{u-1}j_4-a_4b_4-e_4z-uv
 -\gamma L_1-\alpha\beta-\delta R_1,\\
c_ud_u-h_3r_u-a_3b_3-j_3h_4-a_4b_4,\qquad
c_qd_q-s_qo_3-a_3b_3,\\
c_vd_v-s_vr_{v+1}-c_{v+1}d_{v+1}
\quad(1\le v<q,\ v\notin\{t-1,u-1\}),\\
a_1b_1-j_1h_2-o_2k_2,\quad
k_1i_2-i_1e_1,\quad
a_3b_3-k_3i_4-i_3e_3,\quad
k_3i_4-o_4k_4 .
\end{gathered}                                             \tag{12}
\]
The new alternations follow directly from
\(c_{u-1}<s_{u-1}<d_{u-1}<j_4\),
\(s_{u-1}<a_4<j_4<b_4\), and
\(c_u<r_u<d_u<h_3\),
\(r_u<a_3<h_3<b_3\).
The other dashes are those checked in (7)--(8).
As before, connected interlacement excludes
a two-edge cut, while the old cycle excludes a
bridge. Cubicity then gives three-connectivity.

The site and residual square are unchanged. Replace
\(L,R\) in (11) by \(w,z\), respectively, and
join this \(w\)--\(z\) route to \(x,y,w\)
and \(z,u,v\). Together with
\(x,R_1,\delta,\beta,\alpha,\gamma,L_1,v\),
this gives a Hamilton cycle through both site edges;
the legal child is Hamiltonian by Note 001.
For an arbitrary selected opening, (11) replaces
only its free-group route and composes with the
other groups as in Note 324. \(\square\)

**First-slot consequence.** For any \(q\ge1\) in (1),
the possible mates of \(h_1\) are only
\[
           j_2,\ r_1,\ldots,r_q,\ o_3,\ j_4,\ R.            \tag{13}
\]
Indeed \(h_1o_1\) is an old edge, its other
same-block option is excluded by Note 327, and
each omitted opposite-colour candidate encloses
an odd number of unmatched free slots. Every
inserted short block contributes two slots, so
the parity list from Note 348's first-slot
reduction is unchanged apart from the new \(r_u\).
If \(h_1j_2\), its four inner slots force
\(k_1i_2,j_1h_2\), giving the local Note 335
square on \(D_1,D_2\). Compressing it leaves
the adjacent mixed pair \(D_3,D_4\) with short
blocks only on its left, so Note 336 supplies
the spanning group route. Note 350 settles
\(h_1o_3\), while this note excludes \(h_1r_1\)
and settles every \(h_1r_t\), \(t\ge2\).
Thus for \(q\ge2\) only the \(h_1j_4\) and
\(h_1R\) branches remain to decide for the
entire no-flank group. For \(q=1\) these
branches are covered by [Note 349](349-every-no-flank-central-one-short-alternating-four-double-group-has-a-spanning-route.md).
\(\square\)

The theorem settles the entire \(h_1r_t\) branch
without outer short flanks, for every \(q\ge2\)
and \(2\le t\le q\). It does not assert that
either nonlocal patch has the full square Hamilton
signature. The \(h_1j_4,h_1R\) branches, outer flanks,
the opposite four-double orientation, other opening
types and the general Barnette conjecture remain
open. This is a project-internal analytic proof,
without an external priority claim.
