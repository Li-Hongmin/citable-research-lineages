> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A one-sided target-bearing vacancy reduces to one terminal component

[Note 319](319-every-target-free-group-with-distinct-vacancies-has-three-routes.md)
removes every port from a complete target-free four-pole chain.
A target-bearing vacancy at the end of a free-slot group leaves only
the three-slot fragment \(o_k,h_k,i_k\) before its occupied target
run, so that final block is not a four-pole chain block. The same
peeling still removes every port component except possibly the
component containing this terminal vacancy.

Use a compressed, gapless, tight-target all-square opening of a
Barnette parent. Every eligible vacancy lies in a distinct block;
all are in target-free internal blocks except one, \(T=(h_k,i_k)\)
in an internal block \(B_k\). It is the first eligible position of
\(B_k\), and a nonempty occupied target run follows \(i_k\).
Let the free-slot group immediately before that run begin at the
ordinary even slot \(e_a\), and suppose it contains no other
occupied target run. Its complete target-free blocks are
\(B_{a+1},\ldots,B_{k-1}\), each short or singly vacant; its
free-slot order ends
\[
 e_a,\quad B_{a+1},\ldots,B_{k-1},\quad o_k,h_k,i_k.
                                                               \tag{1}
\]
The occupied target barriers of Note 215 close this group under
the free matching. Let \(P_j=(e_j,o_{j+1})\), \(a\le j<k\), denote
its possible ordinary links, and add a virtual atom for every
missing \(P_j\). Add one atom for each vacant pair, including the
rightmost distinguished atom \(T\).

**Terminal-component reduction.** The atoms of (1) form a
noncrossing partition, with no singleton component and at most
one port atom in each component. There is a finite sequence of
Note 317 closed-interval compressions and Note 315 cube folds,
all contained in the complete target-free blocks, such that:

1. every port component other than the component \(\mathcal T\)
   containing \(T\) is removed;
2. if \(\mathcal T\) contains a port, all its target-free
   vacancy atoms are removed, leaving precisely \(\{P,T\}\);
3. if \(\mathcal T\) has no port, the terminal group has no
   missing ordinary link after the reductions.

Each replacement preserves the Barnette class, the selected
opening, all exterior edges and their Hamilton linkage choices.
The target run and \(T\) are untouched. In the two-atom outcome
\(\{P_s,T\}\), the matching edges at these atoms are exactly
\[
                         e_s i_k,\qquad o_{s+1}h_k.       \tag{2}
\]
The alternative outcome has a vacancy-only terminal component.
In the two-atom outcome \(\{P,T\}\), the group has the ordinary
marked spanning route. Hence, if the other free groups have their
ordinary routes, the parent has a Hamilton cycle through both
site edges and its legal site-expanded child is Hamiltonian.
The vacancy-only terminal outcome remains outside this route claim.

**Proof of the atom structure.** Note 215's even-prefix argument
shows that no free matching edge crosses the target run after
\(i_k\); each earlier distinct vacancy contributes two free slots
and does not change that parity. The cross-block free chords lie
in one opposite-side disk by Note 193 and are noncrossing.

We adapt Note 276's ordinary-chord exclusion to the one-ended
slot list (1). Suppose a complete vacant block \(B_j\), \(j<k\),
has \(o_je_j\) in the free matching. Its slot \(h_j\) cannot use
the old-cycle edge \(h_ji_j\). If it matches an ordinary odd
slot, the resulting opposite-side chord encloses an even number
of free slots, but exactly one end of \(o_je_j\) lies inside;
no other same-block chord can supply the required second exit:
blocks strictly between the chord ends contribute both ends or
neither, and the ordinary endpoint of the chord is already used.
If it matches a vacancy slot \(i_t\), the same parity argument
leaves only the chord \(o_te_t\) in the endpoint block as a
possible second exit. It is forced when \(t<k\). Apply this
to every complete block with \(o_te_t\in M\): its \(h_t\)-mate
lies at another such block. Injectivity of the matching makes
these mates a permutation of the finite set of such blocks.
Choose one noncrossing alternating component and its first
and last blocks. The outer matching chord traps all free
matching inside their complete block interval, while the
ordinary slots outside that chord are matched by the two
endpoint \(oe\) chords. This gives a forbidden two-edge
cut, as proved in Note 276. When \(t=k\),
there is no free \(e_k\) before the target run, so the required
second exit is absent and parity already contradicts the matching.
Thus no same-block ordinary chord occurs.

An ordinary-to-ordinary matching edge \(e_i o_j\) with
\(j\ne i+1\) encloses a nonempty complete target-free block
interval, or runs backward around one. Every matching edge of
that interval would be trapped by noncrossing; the same-block
exception has just been excluded. It would give a two-edge cut.
Hence all ordinary-to-ordinary edges are retained standard links
\(P_j\). Every missing link has its two ends matched to vacancy
slots. The actual vacant-pair edges on the local old-cycle and
the virtual missing-link arcs are boundary pairs; together with
the remaining noncrossing matching they give Note 278's atom
partition. Singleton atoms are impossible because their two
ends cannot be matched by an edge already on the old cycle or
by the missing link.

If two ports belonged to one component, choose them consecutive
among that component's ports, say \(P_s<P_t\). The complete block
interval \(B_{s+1},\ldots,B_t\) lies before the target-bearing
block. The rainbow edges between the two ports and every nested
component match all its free slots internally. Its face chords
are internal, leaving only two old-cycle boundary edges across
the cut. This contradicts three-edge-connectivity, as in Note 278.
So every component has at most one port.

**Proof of the reduction.** Let \(\mathcal T\) contain the rightmost
atom \(T\). Among port components other than \(\mathcal T\),
choose one of minimum first-to-last atom span. Its port \(P\)
has a neighboring target-free vacancy \(W\) in that component.
Every component with an atom strictly between \(P,W\) is wholly
inside that proper gap by noncrossing. It cannot contain another
port: such a component would have smaller span and cannot be
\(\mathcal T\), whose rightmost atom \(T\) is outside the gap.
The complete block interval between \(P,W\) is nonempty;
otherwise their forced matching edge would be an old-cycle edge.
It contains no missing link, and all its vacancy matching is
closed inside it. Note 317 compresses it to a short square;
Note 315 then folds this square with \(W\). Both patches lie
strictly before \(B_k\). The fold repairs \(P\) or removes
\(W\) from its component, leaving all other port components
and \(\mathcal T\) unchanged. Repeat until no port outside
\(\mathcal T\) remains.

If \(\mathcal T\) has no port, this is outcome 3. Otherwise
write \(P\) for its unique port. As long as the component has
a target-free vacancy, choose one immediately next to \(P\)
in that component; one exists because \(T\) is its last atom.
There is now no other port anywhere in the proper gap between
\(P\) and the chosen vacancy. Its closed block interval compresses
and folds in the same way. The fold removes that vacancy but
cannot repair \(P\) while \(T\) remains in its component.
After finitely many steps the component is \(\{P,T\}\).
The rainbow rule then gives (2). Exact four-terminal signatures
in Notes 315 and 317 transfer exterior Hamilton linkages in
both directions; their class-preservation proofs apply without
touching the terminal target run. \(\square\)

**Route in the two-atom outcome.** Every other remaining component
is vacancy-only. Since \(P<T\) are consecutive atoms of their
component, no vacancy-only component can straddle \(P\): its
two atoms on opposite sides would interlace \(P,T\). Each such
component and its nested components therefore occupy a closed
full-block interval either before \(P\) or between \(P,T\).
Compress these intervals by Note 317. Only short full blocks and
the target-bearing terminal vacancy \(T\) remain. All ordinary
links except \(P_s\) are present; the missing link has exactly
the two replacement edges (2). Its atom cannot be immediately
before \(T\), for then \(o_kh_k\) would be an old-cycle edge
in the matching. Thus \(s\le k-2\), the one-sided placement
used in Note 208. That note's marked two-path construction
replaces the ordinary free-path link \(e_so_{s+1}\) by
\[
                       e_s,i_k,h_k,o_{s+1}.              \tag{3}
\]
The middle edge is on the old cycle and the two outer edges
are (2). The target-and-square path is unchanged. Routes in
the other groups splice disjointly as in Note 273. Reverse the
closed-interval compressions and then the port peels: their
exact four-terminal signatures retain the marked attachments.
Notes 001 and 182 give the legal child and original lobe lengths.
\(\square\)

The result isolates the first new interface beyond Note 319:
the terminal fragment cannot be replaced by a square because it
lacks the full vacant block's \(e_k,b_k\) attachments on this
side of the target run. A route theorem for the remaining
port-free terminal component would extend the target-free group
result to this one-sided target-bearing case. Other target-bearing
placements, repeated vacancies in one block, positive gaps,
defective target order and nonsquare residual cycles are not
covered. No priority claim is made.
The port-free terminal case is settled by the standard-link
sweep in [Note 321](321-standard-link-sweep-settles-one-one-sided-target-vacancy.md).
