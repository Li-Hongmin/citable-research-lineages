> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Parent-bond split lifts have an exact calculus, but supplementation can be wholly nondirect

[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md)
reduces one-step preservation to a rooted bond flip in a split Eulerian
triangulation. [Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
then gives the exact rank-and-label test for preserving the rooted target.
There are nevertheless two different mechanisms: a prescribed parent bond
has an exact split-lift calculus, while a successful child bond need not
lift any parent bond.

## 1. Exact calculus for a prescribed parent bond

Let

\[
\chi\longleftrightarrow\eta=\chi\triangle W
\tag{1}
\]

be a parent rooted bond, with \(\chi\) in state \(11\) at the split vertex
\(z\). Normalize

\[
\chi(z)=\chi(P)=\chi(Q)=0,\qquad z\notin W.
\tag{2}
\]

Let \(I_A,I_B\) be the two closed rotation intervals from \(P\) to \(Q\)
at \(z\). An interval is \(\xi\)-clean when its colours strictly alternate
under \(\xi\). Put \(H=T-z\), and let \(K_1,\ldots,K_m\) be the components
of \(H[V(H)\setminus W]\). Write

\[
\begin{aligned}
M&:\ m=1,\\
A_*&:\ K_j\cap I_A\ne\varnothing\quad\text{for every }j,\\
B_*&:\ K_j\cap I_B\ne\varnothing\quad\text{for every }j,\\
J_*&:\ \text{some }K_j\text{ meets both }I_A,I_B,\\
E_*&:\ K_j\cap\{P,Q\}\ne\varnothing\quad\text{for every }j,\\
\alpha&:\ W\cap I_A\ne\varnothing,\qquad
\beta:\ W\cap I_B\ne\varnothing.
\end{aligned}
\tag{3}
\]

If \(s=s_Ps_Q\) is the local state of \(\eta\), then

\[
s_P=1\iff P\notin W,\qquad s_Q=1\iff Q\notin W.
\tag{3a}
\]

Use \(R,U,V\) for \(R_{00},X_{uy},X_{vx}\). The noncanonical extensions
of the state-\(11\) endpoint, in coordinates \((A,B,C,P,Q)\), are

\[
R=11000,\qquad U=10100,\qquad V=01100.
\tag{4}
\]

They are NAE respectively when both intervals, \(I_A\), or \(I_B\) are
\(\chi\)-clean. Together with the canonical rows and globally reversed
new-cell rows, these exhaust all extensions that agree with the two parent
colourings away from \(z\).

For completeness, when \(s=00\), the globally reversed \(R\)-row of
\(\eta\) is always NAE, while its reversed \(U,V\)-rows require
\(I_B,I_A\) respectively to be \(\eta\)-clean. When \(s=11\), the same
three tests as above apply with \(\eta\) in place of \(\chi\).

If \(W^+=W\cup S\), where \(S\subseteq\{A,B,C\}\) is the set on which a
chosen row pair differs, the exact bond conditions are as follows. For
parent state \(10\) or \(01\), against its canonical row,

\[
\begin{array}{c|ccc}
\chi\text{-row}&R&U&V\\ \hline
\text{bond condition}&M&B_*&A_*
\end{array}.
\tag{5}
\]

For state \(00\), against \(C_{00}\),

\[
\begin{array}{c|ccc}
\chi\text{-row}&R&U&V\\ \hline
\text{bond condition}&\text{never}&B_*&A_*
\end{array}.
\tag{6}
\]

For state \(00\) with two new-cell rows,

\[
\begin{array}{c|ccc}
 &R&U&V\\ \hline
R&M&B_*&A_*\\
U&B_*&M&J_*\\
V&A_*&J_*&M
\end{array},
\tag{7}
\]

and for state \(11\),

\[
\begin{array}{c|ccc}
 &R&U&V\\ \hline
R&\text{always}&\beta\wedge A_*&\alpha\wedge B_*\\
U&\beta\wedge A_*&\text{always}&\alpha\wedge\beta\wedge E_*\\
V&\alpha\wedge B_*&\alpha\wedge\beta\wedge E_*&\text{always}.
\end{array}
\tag{8}
\]

For the proof, contract \(H[W]\), contract each \(K_j\), and retain the
path \(A-C-B\). On the complementary shore, \(A,B,C\) attach precisely to
the \(K_j\) meeting \(I_A,I_B,\{P,Q\}\). On the other shore their
attachments are given by \(\alpha,\beta\) and \(W\cap\{P,Q\}\). Both
quotient shores are connected exactly under (5)--(8).

NAE and bondness leave one final, exact filter. The row pair is a rooted
child bond if and only if both endpoints are root-admissible,

\[
\rho_{00}+\rho_{11}=\rho_{10}+\rho_{01},
\tag{9}
\]

and the two labelled root fragments remain separated in the appropriate
cross-colour quotient graph. Thus cleanliness, (5)--(8), and (9) with
root separation are necessary and sufficient for a lift of the prescribed
parent bond.

## 2. The canonical--cross two-template family

Put

\[
\mathcal C=\{C_{00},C_{10},C_{01}\},\qquad
\mathcal X=\{X_{uy},X_{vx}\}.
\tag{10}
\]

Every canonical--\(\mathcal X\) local shore has exactly one of two forms:

\[
\begin{array}{c|c|c}
\text{template}&\text{cell pair}&
W^+\cap\{A,B,C,P,Q\}\\ \hline
I&C_{10}\text{ or }C_{01}\leftrightarrow
X_{uy}\text{ or }X_{vx}&AP,AQ,BP,\text{ or }BQ\\
II&C_{00}\leftrightarrow X_{uy}\text{ or }X_{vx}&ACPQ\text{ or }BCPQ.
\end{array}
\tag{11}
\]

This is the XOR table of the five-bit representatives. For a direct
parent-bond lift, the \(X_{uy}\) alternative is equivalent to \(I_A\)
clean, \(B_*\), and (9); the \(X_{vx}\) alternative is equivalent to
\(I_B\) clean, \(A_*\), and (9).

## 3. Finite theorem through parent order twenty-six

Consider exactly the \(322\) eligible positive children in the frozen
nonsquare kill-cover stratum of
[Note 110](110-nonsquare-kill-cover-supplementation-holds-through-order-twenty-six-in-the-frozen-root-square-stratum.md).
Their complete child families contain \(4,723\) crossing witnesses, of
which \(2,094\) join \(\mathcal C\) to \(\mathcal X\). Every site has at
least one such canonical--cross witness.

Template I occurs at \(319\) sites and template II at \(139\), with union
all \(322\). The three sites lacking template I are the three choices of
two alternating edges on one hexagonal face of a single order-\(26\)
parent, and all three are rescued by template II. Hence

\[
\boxed{\text{every eligible child in this stratum has a
canonical--\(\mathcal X\) rooted bond.}}
\tag{12}
\]

The full shore-rank profiles are not uniform. The \(4,723\) witnesses give
\(487\) labelled profiles; no profile or single coordinate value is common
to all sites, and the exact minimum labelled profile cover has size \(17\).
Thus (12), not a fixed rank tuple, bond length, or named cell pair, is the
common finite mechanism. The exhaustive classification is frozen in the
[supporting bundle](../computations/bundles/through26-child-rank-profiles/README.md).

## 4. A real wholly nondirect kill-cover

The middle exceptional site has parent order \(26\), root \(1-13\), forced
gate \(0-14\), surviving gate \(7-16\), face

\[
(6,19,9,17,10,25),
\tag{13}
\]

and selected edges \(6-19,10-25\). The parent rooted fibre has four
targets, two crossing edges, and two state-\(11\) targets covering both
crossings. Its order-\(30\) child is again a legal-wide plane brace. The
child fibre has eight targets, with two in each of
\(C_{00},R_{00},X_{uy},X_{vx}\), and exactly two crossing edges.

Both child crossings have the single profile

\[
C_{00}\longleftrightarrow X_{uy},\qquad
W^+\cap\{A,B,C,P,Q\}=ACPQ,\qquad
(\rho_{00},\rho_{11},\rho_{10},\rho_{01})=(1,2,2,1),
\tag{14}
\]

with bond length \(6\) and separated root labels.

Each parent state-\(11\) target has three direct formulas, and all six are
perfect matchings. The direct \(R_{00}\) and \(X_{uy}\) formulas have three
complement components and are not targets. The two direct \(X_{vx}\)
formulas are targets but lie on no crossing. Conversely, both \(X_{uy}\)
targets in (14) have no parent state-\(11\) direct ancestor; their inverse
candidates are not perfect matchings. Every child crossing in this genuine
kill-cover instance is therefore nondirect.

Across the \(322\) sites, \(1,007\) of the \(2,094\) canonical--cross
witnesses have direct ancestry. A direct witness is selectable at \(258\)
sites; at the other \(64\), every canonical--cross witness is nondirect.

## 5. Consequence and boundary

The real site disproves

\[
\text{choose a parent state-\(11\) bond}
\Longrightarrow
\text{split that bond into the required child crossing}.
\tag{15}
\]

The exact calculus above is complete for the objects it classifies, but it
cannot prove the complete-family rooted split-bond lemma. The finite data
instead isolates the stronger candidate

\[
\boxed{\text{parent kill cover}\Longrightarrow
\Gamma(\mathcal C,\mathcal X)\ne\varnothing.}
\tag{16}
\]

Equation (16) would imply the rooted split-bond lemma of Note 108, but
(12) proves it only in the named frozen parent stratum. Any arbitrary-order
proof must use the shared incidence of the complete nondirect child NAE
family; parent ancestry, a fixed shore-rank profile, and a prescribed
parent bond are all insufficient.
