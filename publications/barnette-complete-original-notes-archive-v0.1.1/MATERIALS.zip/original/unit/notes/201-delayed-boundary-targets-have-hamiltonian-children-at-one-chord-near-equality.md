> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Delayed boundary targets have Hamiltonian children at one-chord near equality

[Note 199](199-single-lobe-one-face-chord-eight-free-vertices-have-hamiltonian-children.md)
finds two forced Hamilton routes when the first escape
target is delayed from \(x\) in a one-lobe, one-face-chord
opening. [Note 197](197-gapless-square-trap-defect-budget.md)
shows that this delay consumes the only vacant eligible
slot at \(f=8,r=1\). The same two routes therefore work
for every lobe count: additional square traps lengthen
one path but do not change the six free-slot matching.

Use the one-square-per-lobe compressed setting of
Notes 176--179. Let \(G\) be a Barnette parent with
Hamilton cycle \(C\) avoiding the cofacial site matching
edges \(q=xy,p=uv\). Assume its selected all-square
opening has \(r=1\), \(f=8\), and \(\ell\ge1\) lobes.
Write the three blocks as \(B_0=[x,y]_C\),
\(B_1=[a,b]_C\), and \(B_2=[u,v]_C\).

**Boundary-delay Hamilton theorem.** If the first
escape target \(R_\ell\) is not the first interior
slot of \(B_0\), then \(G\) has a Hamilton cycle
containing both \(q,p\). The same conclusion holds
when the last escape target \(L_1\) is not the
final interior slot of \(B_2\). Thus the legal
site-expanded child is Hamiltonian in either case,
for every \(\ell\) and every original lobe length.

**Proof.** Note 198 excludes all interblock gap slots
at \(r=1,f=8\). Note 195's count gives
\(k_0+k_1+k_2=\ell\), so exactly one of the
\(\ell\) eligible even block positions is not
occupied by a nonfinal \(L_j\). Suppose first that
\(R_\ell\) is delayed. Note 197's defect budget
then pins \(L_1\) to the final slot of \(B_2\)
and makes every consecutive \(L_j,R_{j-1}\)
adjacent on \(C\).

The endpoint barrier of Note 197 forbids \(R_\ell\)
as the first slot of a later block. Since no escape
target occurs before it, every eligible even position
before \(R_\ell\) is vacant. There is only one such
position. Thus \(R_\ell\) is the third interior slot
of one block, its second slot is the unique vacancy,
and every earlier block is short. All later eligible
positions are occupied by nonfinal \(L\) targets;
their following odd positions are the corresponding
\(R\) targets by the tight-transition condition.

If \(R_\ell\) is in \(B_0\), its second slot is an
\(E\) free slot before the target. Its first slot
is the only earlier free \(O\) slot, but the two
are adjacent on \(C\). Every later odd slot in
\(B_0\) follows an occupied eligible \(L\) and is
an escape target. A matching edge from the second
slot to a later block would lie opposite the common
face and straddle \(R_\ell\), crossing its escape
edge. Thus the second slot has no possible mate.
This case is impossible.

Let \(M=E(G)\setminus E(C)\), and let \(A\) be the
even-starting perfect matching of \(C\), indexed
from \(x\). Because all \(L_j,R_{j-1}\) transitions
are adjacent, the residual squares and escape targets
form the following \(M\cup A\) path \(P\) from
\(R_\ell\) to \(L_1\):
\[
P:\quad R_\ell,\delta_\ell,\beta_\ell,
\alpha_\ell,\gamma_\ell,L_\ell,
R_{\ell-1},\ldots,R_1,\delta_1,\beta_1,
\alpha_1,\gamma_1,L_1.
\tag{1}
\]
For \(\ell=1\) there is no inter-lobe transition;
the expression starts at \(R_1\) and ends at \(L_1\).

If \(R_\ell\) is the third slot of \(B_1\), the
earlier block \(B_0\) is short. Name its two free
slots \(s,t\) in \(O,E\) order. Name the four
slots of \(B_1\) that matter to the free matching
\(g,h,R_\ell,j\): \(g,h\) are its first two
slots and \(j\) its final slot; occupied target
pairs may lie between \(R_\ell\) and \(j\).
The first slot of \(B_2\) is free; call it \(z\).
The six free slots are \(s,t,g,h,j,z\).

No cross-block free chord can straddle \(R_\ell\).
The only possible same-block chord across it is
\(gj\). If \(gj\) were matched, the remaining
three free slots \(s,t,h\) before \(R_\ell\)
could not all be matched. Hence \(gj\notin M\).
Noncrossing of the opposite-side chords and the
forbidden consecutive cycle edges \(st,gh\)
force the pre-target pairs \(sh,tg\); the final
pair is \(jz\). The cycle
\[
x,y,t,g,a,b,j,z,u,v,
\overleftarrow{P},h,s,x
\tag{2}
\]
is therefore a Hamilton cycle. Here
\(\overleftarrow{P}\) traverses (1) from \(L_1\)
back to \(R_\ell\). All displayed transitions
outside \(P\) alternate between \(M\) and \(A\):
\(xy,ab,uv,sh,tg,jz\in M\), while
\(yt,ga,bj,zu,vL_1,R_\ell h,sx\in A\).

If \(R_\ell\) is the third slot of \(B_2\), both
preceding blocks are short. Name their free slots
\(s,t\) and \(g,h\) in \(O,E\) order, and name
the first two \(B_2\) slots \(z,w\) in \(O,E\)
order. All six free slots precede \(R_\ell\).
Every possible free chord is cross-block, since
\(st,gh,zw\) are consecutive cycle edges.
Noncrossing forces the unique matching
\[
sw,\qquad tg,\qquad hz.
\tag{3}
\]
Indeed \(s\) cannot match \(t\); matching it
to \(h\) would enclose \(tg\) and leave the
forbidden \(zw\). Thus \(sw\in M\), then
\(tg,hz\) follow. The Hamilton cycle is
\[
x,s,w,P,v,u,z,h,b,a,g,t,y,x.
\tag{4}
\]
It uses \(sw,tg,hz,uv,ab,xy\in M\), with the
other transitions outside \(P\) in \(A\).

Cycles (2) and (4) visit every main-block vertex,
escape target, and residual-square vertex exactly
once and contain both site edges. Reversing the
oriented main segment and swapping \(p,q\) gives
the reflected proof when \(L_1\) is advanced.
Note 001 lifts the parent cycle through the legal
site expansion, and Note 178 restores arbitrary
positive lengths of the original lobes. \(\square\)

The theorem resolves the endpoint-defect branch at
\(r=1,f=8\). It does not decide a gapless opening
whose single defect is between consecutive lobes,
or one with a vacant position but no target-order defect.
