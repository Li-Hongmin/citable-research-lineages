> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every single-hexagon opening with at most six face chords has a Hamiltonian child

[Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md) proves Hamiltonicity for a legal single-hexagon facial opening when the number \(f\) of additional common-face-side main matching chords is at most five. At \(f=6\), its doubly reduced non-Hamiltonian candidate would have an extremal seven-leaf ordinary-chord forest. The exposed escape targets in that forest force a Hamiltonian cycle or violate bipartiteness.

Let \(G,C,p,q,G^+\) satisfy the single trapped-hexagon setup of Note 411. Write the old cycle in the order
\[
 w_0,S_0^\circ,w_*,\alpha,a,b,c,d,\beta,w_0,
\]
where \(S_0=(w_0,S_0^\circ,w_*)\) is the main segment and \(\alpha\beta\) closes the selected trapped hexagon. Its four internal vertices either all escape to the main segment, giving \(e=4\), or \(ad\) is an internal matching chord and only \(b,c\) escape, giving \(e=2\), as in [Note 403](403-a-single-chorded-hexagon-trap-needs-twelve-main-vertices.md).

**Six-face-chord theorem.** If \(f\le6\), then the legal expanded child \(G^+\) is Hamiltonian, regardless of the order of \(G\), the length of the other facial arc, and whether \(ad\) occurs. Consequently a non-Hamiltonian child with a selected single-hexagon three-edge facial opening must have \(f\ge7\). The theorem concerns this specified opening and does not settle Barnette's conjecture.

**Extreme-kernel reduction.** The case \(f\le5\) is Note 411, so take \(f=6\). Alternate both four-column ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md). They preserve the Barnette class, the selected hexagon, \(e,f\) and child Hamiltonicity. Put \(c\) for the number of ordinary opposite-page main matching chords in the reduced parent. Note 410 gives \(c\le5f+2=32\). Its main segment has \(4+e+2f+2c=16+e+2c\) vertices, so the reduced child has
\[
                         |V(\bar G^+)|=26+e+2c.       \tag{1}
\]
The published Brinkmann--Goedgebeur--McKay 90-vertex Hamilton theorem cited in Note 411 handles \(c\le30\) when \(e=4\), and \(c\le31\) when \(e=2\). Suppose, for contradiction, that \(\bar G^+\) is non-Hamiltonian. Then \(c\ge31\) for \(e=4\) or \(c=32\) for \(e=2\).

Here is the saturation step from Note 410, made explicit. Let \(u\le2+2f=14\) be the number of special main positions inside ordinary-chord intervals and \(m=u/2\le7\). If the forest is nonempty, let \(M_0,L,A,Q\) denote its numbers of marked nodes, leaves, marked-or-branching nodes, and leaves receiving exactly two special positions. The bound proved in Note 410 is
\[
 c\le2(M_0+L)+m-3\le5m-3.                         \tag{2}
\]
Since \(c\ge31\), (2) forces \(m=7\). It also forces \(M_0+L=14\), because a sum at most thirteen would give \(c\le30\). As \(L\le M_0\le7\), we have \(M_0=L=7\). All fourteen assignable positions therefore occur at the seven marked leaves, two per leaf, so \(Q=7\). The sharper inequality \(c\le3A-Q\), together with \(c\ge31\), gives \(A\ge13\). But \(A\le M_0+L-R=14-R\), where \(R\ge1\) is the number of roots. Thus \(A=13,R=1\): one ordinary root interval contains every ordinary endpoint and every assignable special position. Outside it, the main segment has only the two end site ports \(w_0,w_*\) and the \(e\) escape targets.

**Adjacent-escape merger.** If two escape targets are consecutive vertices along \(S_0\), their matching edges go to adjacent internal vertices of the trapped hexagon. For \(e=4\), the four targets in main order meet \(d,c,b,a\), respectively: any other order would cross two escape edges on the opposite page of \(C\). For \(e=2\), their hexagonal neighbours are \(c,b\). The selected facial opening of [Note 176](176-alternating-facial-arcs-create-one-residual-cycle-per-matching-edge.md) gives a child 2-factor consisting of the main cycle through the new square and the trapped hexagon. The old-cycle edge between the adjacent targets lies in the main cycle, and the edge between their adjacent hexagonal neighbours lies in the hexagon. Delete those two edges and add the two escape edges. This joins the two cycles into one Hamilton cycle.

If \(e=4\), the four escape targets lie in the two flanks outside the unique root interval. At least two lie in the same flank, where there are no intervening vertices other than escape targets. Two targets are therefore consecutive, and the merger contradicts non-Hamiltonicity. If \(e=2\) and both targets lie in one flank, the same argument applies.

The only remaining arrangement would have \(e=2\) with one target \(t_L\) before the root and one \(t_R\) after it. Since \(c=32\), the root interval has \(2c+u=64+14=78\) vertices. The full main order is exactly
\[
                     w_0,t_L,\underbrace{W}_{78\text{ vertices}},t_R,w_*.
\]
Indexing \(w_0\) by zero gives \(t_L\) index 1, \(t_R\) index 80, and the trapped vertices \(\alpha,a,b,c,d,\beta\) indices \(82,83,84,85,86,87\). Noncrossing on the escape page requires \(t_Lc,t_Rb\), because \(t_L<t_R<b<c\) around \(C\). But \(t_L,c\) are both odd-indexed and \(t_R,b\) both even-indexed. Those edges violate bipartiteness. Hence the remaining arrangement is impossible, completing the contradiction. \(\square\)

The sharpness of the bound \(f\ge7\) as a *necessary condition* is not asserted: no non-Hamiltonian Barnette graph is known. [Note 413](413-a-seven-leaf-barnette-kernel-can-avoid-the-serial-odd-pole.md) gives a 94-vertex Hamiltonian legal child at \(f=6\) whose parent saturates the seven-leaf kernel bound without the serial pole of Note 412. It shows why the adjacent-escape and parity argument, rather than forcing that pole, is needed for the full \(f=6\) conclusion.
