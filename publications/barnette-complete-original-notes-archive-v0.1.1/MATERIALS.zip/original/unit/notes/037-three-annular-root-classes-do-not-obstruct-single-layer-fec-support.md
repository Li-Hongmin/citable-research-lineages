> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Three annular root classes do not obstruct single-layer FEC support

[Note 036](036-three-balanced-remote-root-classes-have-a-low-weight-perfect-matching-state.md)
proves a zero-state Helly theorem for three balanced remote root classes.
This note adds exact-one classes, the unique size-three class, and all
retained edges among the three nonroot vertices.  It settles every rooted
four-vertex region whose three nonroot vertices lie on the common
\(c_p,c_h\) annulus.

Use the setting of Notes 028--036.  Let

\[
 K=F-\{u,a\},
 \qquad
 p^*=cc_p,
 \qquad
 h^*=cc_h.
\]

Let \(x_1,x_2,x_3\) be three distinct dual vertices adjacent to both
\(c_p,c_h\), ordered along the annulus obtained by cutting the sphere
open along \(c_p-c-c_h\).  Write

\[
 D_i=\{e_i^p,e_i^h\}
\]

for the two retained primal labels dual to
\(c_px_i,c_hx_i\).  Every ordinary pair has one of the two types from
Note 035:

\[
 \begin{array}{ll}
 E:& |M\cap D_i|=1\text{ for every perfect matching }M;\\
 B:& |M\cap D_i|\in\{0,2\},\text{ and both states occur.}
 \end{array}
\tag{1}
\]

At most one selected vertex is also adjacent to \(c\) by a retained
label.  This is the size-three class \(T\).  Its three primal labels are

\[
 vz,\qquad vx,\qquad zy,
\tag{2}
\]

where \(D_T=\{vx,zy\}\).  The pair \(D_T\) has type \(B\): a perfect
matching either uses \(vz\), or uses both \(vx,zy\).

If \(x_ix_j\in E(\Delta)\), call its retained primal label a **rung**.
The annular order implies that rungs occur only between consecutive
selected paths.  Thus the rung graph on \(x_1,x_2,x_3\) is a subgraph of
a three-vertex path.

> **Three-class annular transfer theorem.** For
> \(W=\{r,x_1,x_2,x_3\}\), there is a perfect matching \(M\) of \(K\)
> such that
> \[
> |M\cap E_Q(W)|\le3=|W|-1.
> \tag{3}
> \]

## The exact transition at a rung

Suppose that \(g^*=x_ix_j\) is a rung.  The triangles

\[
 c_px_ix_j,qquad c_hx_ix_j
\]

are facial.  Hence the four pair labels in \(D_i\cup D_j\) are the other
two cubic incidences at the two endpoints of the primal edge \(g\).
Since \(K\) is 1-extendable, some perfect matching contains \(g\); that
matching avoids both pairs.  Consequently both endpoint pairs have type
\(B\).  In particular, a rung cannot have an \(E\)-endpoint.

For a \(B\)-pair put

\[
 \sigma_i(M)=\frac{|M\cap D_i|}{2}\in\{0,1\}.
\]

Matching incidence at the endpoints of \(g\), together with the even cut
parity of \(D_i,D_j\), gives the complete transition table

\[
 \begin{array}{c|c|c}
 \sigma_i&\sigma_j&\mathbf1_{g\in M}\\ \hline
 0&0&1\\
 1&0&0\\
 0&1&0.
 \end{array}
\tag{4}
\]

Indeed, if \(g\notin M\), its two endpoints choose one pair label each.
Even parity forces both selected labels to come from the same pair.  If
\(g\in M\), all four pair labels are excluded.

For the size-three class, (2) gives the complementary relation

\[
 \mathbf1_{vz\in M}=1-\sigma_T(M).
\tag{5}
\]

Thus an ordinary \(B\)-class costs \(2\sigma_i\), an \(E\)-class costs
one, and a \(T\)-class costs

\[
 2\sigma_T+(1-\sigma_T)=1+\sigma_T.
\tag{6}
\]

## No rung

If all three pairs have type \(B\), their four-bonds occur in annular
order and have nested shores.  The splicing proof of Note 036 applies
unchanged to the pair \(D_T\) when \(T\) is present: the additional chord
\(cx_T\) is not a member of the four-cycle
\((c_p-c-c_h)\cup(c_p-x_T-c_h)\) and does not affect the nested cut.
Hence some attained state \((\sigma_1,\sigma_2,\sigma_3)\) has Hamming
weight at most one.  Three ordinary \(B\)-classes then cost at most two;
if one is \(T\), equation (6) raises the total to at most three.

If there is one \(B\)-class, use its zero witness; it costs zero when
ordinary and one when it is \(T\), while the two \(E\)-classes cost two.
If there are two \(B\)-classes and one \(E\)-class, at least one
\(B\)-class is ordinary because \(T\) is unique.  Use a zero witness for
that ordinary class.  The other \(B\)-class costs at most two and the
\(E\)-class costs one.  Three \(E\)-classes cost exactly three.

## One rung

Let the rung join classes \(i,j\).  Both are of type \(B\) by (4).  If
neither is \(T\), extend \(g\) to a perfect matching.  The rung layer
costs one, and the third class costs at most two.

Suppose that \(i=T\).  If the third class has type \(B\), use a zero
witness for it.  In the three rows of (4), the combined cost of the
\(T\)-class, the ordinary rung endpoint, and \(g\) is respectively

\[
 2,qquad2,qquad3.
\]

If the third class has type \(E\), extend either edge of \(D_T\) to a
perfect matching.  Then \(\sigma_T=1\), so (4) forces state zero at the
other rung endpoint and excludes \(g\).  The \(T\)-class costs two and
the \(E\)-class costs one.  Finally, if \(T\) is the third class rather
than a rung endpoint, extending \(g\) gives rung-layer cost one and
\(T\)-cost at most two.

## Two rungs

Write the rungs as \(g_{12},g_{23}\).  Extend \(g_{12}\) to a perfect
matching \(M^-\) and \(g_{23}\) to a perfect matching \(M^+\).  Both
have state zero on the middle cut \(D_2\).  Splice the \(x_1\)-side of
\(M^-\) to the \(x_3\)-side of \(M^+\) across that zero-state cut.  The
resulting perfect matching contains both rungs and has

\[
 (\sigma_1,\sigma_2,\sigma_3)=(0,0,0).
\]

The rungs cost two.  The ordinary pairs cost zero, and the complementary
label of the possible \(T\)-class costs one.  The total is therefore at
most three.  This completes the proof of (3).

## Consequence and remaining boundary

The theorem settles the complete four-vertex matching inequality whenever
all three nonroot vertices contain the common pair \(\{c_p,c_h\}\),
including every mixture of balanced and exact-one types, the unique
size-three refinement, and every possible retained rung pattern.  It
uses no global \(H^{+-}\) hypothesis and no order bound.

The remaining rooted four-vertex profiles contain at least one singleton
root class, one local pair \(\{c,c_p\}\) or \(\{c,c_h\}\), or a vertex
with no root incidence.  These objects are not states of the common-
neighbour annulus and require separate facial reductions.  Accordingly,
this note does not yet claim the complete rooted four-vertex theorem.
