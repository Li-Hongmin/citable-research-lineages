> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four-rank defect is not modular on actual exterior exchange cubes

[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
expresses preservation of the complement-cycle count under a shore flip by
the defect

\[
 D(W)=\rho_{00}(W)+\rho_{11}(W)-\rho_{10}(W)-\rho_{01}(W).
\tag{1}
\]

[Note 119](119-actual-exterior-nae-strata-have-noncrossing-boolean-exchange-cubes.md)
shows that the components of an exterior monochromatic-edge difference can
be toggled independently.  A possible route to the remaining selection
lemma would be to prove that (1) is a modular set function on this Boolean
cube.  This note disproves that statement on the smallest possible
triangulated disk.  The failure persists in a simple \(4\)-connected
Eulerian sphere triangulation while a common root matching edge is retained.

## 1. Defect on an exchange cube

Fix a base exterior NAE colouring \(\sigma\), and let
\(\sigma_J\) be the corner obtained by toggling the exchange components in
\(J\).  Align the two representatives and put

\[
 W_J=\{v:\sigma_J(v)\ne\sigma(v)\}.
\tag{2}
\]

The rank-transfer identity of Note 109 gives

\[
 D(J):=D(W_J)
 =c_0(\sigma_J)+c_1(\sigma_J)
  -c_0(\sigma)-c_1(\sigma).
\tag{3}
\]

Modularity would require

\[
 D(J)+D(K)=D(J\cap K)+D(J\cup K)
\tag{4}
\]

for every two corners of every actual exchange cube.

## 2. The minimum actual failure

Let \(H\) be the wheel with boundary cycle \(abcda\), centre \(o\), and
triangular faces

\[
 oab,\quad obc,\quad ocd,\quad oda.
\tag{5}
\]

In the order \((a,b,c,d,o)\), take

\[
 \sigma=00001,
 \qquad
 \tau=01010.
\tag{6}
\]

Their monochromatic-edge sets are

\[
 \mu_\sigma=\{ab,bc,cd,da\},
 \qquad
 \mu_\tau=\{ao,co\}.
\tag{7}
\]

The split weak-dual difference has precisely the two components

\[
 A=\{ab,ao,ad\},
 \qquad
 C=\{bc,co,cd\}.
\tag{8}
\]

They are noncrossing boundary-to-boundary paths, so Note 119 supplies the
complete Boolean square.  Its four corners and monochromatic-component
totals are

\[
\begin{array}{c|c|c|c}
J&\sigma_J&W_J&c_0(\sigma_J)+c_1(\sigma_J)\\ \hline
\varnothing&00001&\varnothing&2\\
\{A\}&01110&\{b,c,d,o\}&2\\
\{C\}&00101&\{c\}&2\\
\{A,C\}&01010&\{b,d,o\}&3.
\end{array}
\tag{9}
\]

Equivalently, the four gluing-rank tuples
\((\rho_{00},\rho_{11},\rho_{10},\rho_{01})\) are

\[
\begin{array}{c|c|c}
J&(\rho_{00},\rho_{11},\rho_{10},\rho_{01})&D(J)\\ \hline
\varnothing&(0,0,0,0)&0\\
\{A\}&(1,0,1,0)&0\\
\{C\}&(1,0,0,1)&0\\
\{A,C\}&(3,0,2,0)&1.
\end{array}
\tag{10}
\]

Hence

\[
 D(\{A\})+D(\{C\})=0
 \ne 1=D(\varnothing)+D(\{A,C\}),
\tag{11}
\]

contradicting (4).

This five-vertex disk is minimum by vertex count.  A triangulated disk on
at most four vertices is a triangle, a quadrilateral with one diagonal, or
a triangle with one interior vertex.  The triangle has no two-dimensional
exchange cube; direct inspection of the two four-vertex types gives zero
mixed second difference in every Boolean square.

## 3. A root-edge-retaining Eulerian failure

The interaction in (11) is not caused by the absence of the ambient
Barnette-dual hypotheses.  Let \(T\) be the suspension of the six-cycle

\[
 v_0v_1v_2v_3v_4v_5v_0
\tag{12}
\]

with apices \(o,z\).  This is a simple \(4\)-connected Eulerian sphere
triangulation.  Delete \(z\); the exterior disk \(H=T-z\) is the six-wheel.
On \((v_0,\ldots,v_5,o,z)\), begin with

\[
 \sigma=00000011.
\tag{13}
\]

In the exterior disk, independently toggle

\[
 A=\{v_2v_3,v_3o,v_3v_4\},
 \qquad
 C=\{v_4v_5,v_5o,v_5v_0\}.
\tag{14}
\]

The four corners flip neither, one, or both of \(v_3,v_5\).  They extend
with the fixed colour of \(z\) to NAE colourings of the whole sphere.
Moreover \(v_0v_1\) is monochromatic at every corner, so the corresponding
primal root matching edge is retained.

On the full triangulation \(T\), the component totals and defects are

\[
\begin{array}{c|c|c|c}
J&W_J&c_0+c_1&D(J)\\ \hline
\varnothing&\varnothing&3&0\\
\{A\}&\{v_3\}&2&-1\\
\{C\}&\{v_5\}&2&-1\\
\{A,C\}&\{v_3,v_5\}&3&0.
\end{array}
\tag{15}
\]

Thus

\[
 D(\{A\})+D(\{C\})=-2
 \ne 0=D(\varnothing)+D(\{A,C\}).
\tag{16}
\]

Planarity, Eulerianity, \(4\)-connectivity, extension through the deleted
split vertex, and retention of a common root edge therefore do not restore
modularity.

## 4. Exact boundary

The examples close the route

\[
 \text{actual Boolean exchange cube}
 \Longrightarrow
 \text{modular four-rank defect}
 \Longrightarrow
 \text{a zero-defect gate-even corner}.
\tag{17}
\]

They do not disprove the root-labelled cubical selection lemma itself.  In
the Eulerian example the double-toggle shore \(\{v_3,v_5\}\) is disconnected,
and the four corners were not required simultaneously to be endpoints of a
single rooted bond or to satisfy the ordered root-fragment condition.  Any
positive selection theorem must use those additional hypotheses, or a
genuinely global interaction between different exchange cubes; ordinary
Boolean modularity of (1) is unavailable.
