> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every distinct internal vacancy in a tight square opening is marked Hamiltonian

[Note 319](319-every-target-free-group-with-distinct-vacancies-has-three-routes.md)
settles target-free groups, [Note 321](321-standard-link-sweep-settles-one-one-sided-target-vacancy.md)
settles a group with one target-bearing terminal vacancy, and
[Notes 322--323](323-terminal-port-u-turn-closes-facing-target-vacancies.md)
settle a group with two facing target-bearing terminal vacancies.
The target barriers make these local results composable even when
many different groups contain target-bearing vacancies.

Let \(G\) be a Barnette parent with an old Hamilton cycle \(C\)
avoiding two cofacial matching site edges \(xy,uv\). Choose the
all-square facial opening of Notes 196 and 273, compressing each
residual lobe to one square. Assume all interblock gaps are empty
and the target order is tight: \(R_\ell\) is the first interior
slot of \(B_0\), \(L_1\) is the final interior slot of
\(B_{r+1}\), and \(L_jR_{j-1}\in E(C)\) for \(j\ge2\).
Every eligible vacant position lies in a different internal face
block \(B_i\), \(1\le i\le r\). The number of vacancies, and the
number of vacant target-bearing blocks, are unrestricted.

**Distinct-internal-vacancy theorem.** The parent has a Hamilton
cycle containing both \(xy\) and \(uv\). Its legal site-expanded
child is Hamiltonian. The same holds before lobe compression for
arbitrary positive original lobe lengths.

**Proof.** Every vacancy is a pair of consecutive free slots
\((h,i)\). At an occupied target run, the number of free slots in
the preceding prefix is even: each earlier vacancy adds two.
As in Note 215, a cross-block free matching edge cannot cross
the target, and a block with at most one vacancy offers at most
one same-block free chord that could cross. The even-cut parity
excludes that single chord. Thus every occupied target run is a
barrier for the free matching.

If a target-bearing block had occupied targets on both sides of
its vacancy, the barriers would isolate exactly \(h,i\) between
them. Their only possible mutual matching edge is the old-cycle
edge \(hi\), which is absent from the complementary matching.
Hence this arrangement is impossible. A target-bearing vacancy
is therefore first before its block's nonempty occupied run, or
last after that run.

Partition the free slots into the closed groups between occupied
target runs. A group contains at most one target-bearing vacancy
at each end: the left one, if present, is last after the preceding
run; the right one, if present, is first before the following run.
Every other vacancy of the group lies in a distinct complete
target-free block. Three terminal counts exhaust the groups:

* With no target-bearing terminal vacancy, use the minimum-span
  port peeling of Note 319. Its proof also applies when an
  ordinary end link is missing, as observed in Note 321: the
  compression and cube-fold patches stay entirely in complete
  target-free blocks. All ordinary links in this group are
  eventually restored.
* With one target-bearing terminal vacancy, use the local
  reduction of Note 320, reflecting if it is at the left end.
  A port-free terminal leaves all links restored; a two-atom
  terminal component reduces to Note 208's one-sided detour.
  Other vacancy-only intervals are compressed by Note 317,
  as in Note 321.
* With two target-bearing terminal vacancies, they face one
  another across the group. The atom reduction of Note 322 is
  confined to that group and touches only complete target-free
  blocks. Its first three outcomes have the standard sweep or
  Note 232's one- and two-detour routes. Its mixed fourth
  outcome has the terminal-port U-turn of Note 323.

The statements above are local to a free group. Their reductions
preserve the exterior edges and all spanning path attachments,
and no reduction touches an occupied target run. Apply them
group by group. In the resulting opening, use Note 231's two
\(x\)--\(v\) paths as a template. A group with restored links is
traversed by the standard sweep. A one- or two-detour group
replaces only its own free-path segment; its residual-square
path is unchanged. A U-turn group replaces its own target
interval on the residual-square path and its own block segment
on the exposed-face path, with the same boundary attachments
as in Note 323. Distinct groups have disjoint free interiors;
their face-path modifications pass through only their own
complete target-free blocks and one terminal fragment.
They therefore commute and leave two internally disjoint
\(x\)--\(v\) paths covering every vertex. Their union contains
both site edges. Reverse all exact reductions, then use
Notes 001 and 178 for the legal child and original lobes.
\(\square\)

The theorem covers all numbers and placements of **distinct
internal-block** vacancies under the selected square, gapless,
tight opening. It does not address repeated vacancies in one
block, site-block vacancies, positive gaps, defective target
order, nonsquare residual cycles, or general Barnette graphs.
Its proof is project-internal and has not had independent
external review; no priority claim is made.
