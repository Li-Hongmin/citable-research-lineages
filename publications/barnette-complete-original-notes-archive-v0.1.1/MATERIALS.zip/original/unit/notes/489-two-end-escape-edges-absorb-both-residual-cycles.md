> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two end escape edges absorb both residual cycles in a three-root two-split opening

[Note 488](488-nested-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md) closes the disconnected root face graph for the three-root two-split equality profile of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md). For connected root face graph, two split nodes in distinct roots can leave two terminal-free components after the inner openings. The two end escape edges absorb both simultaneously.

Use the order and base cycles \(D=C_1\cup C_2\cup C_3\) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Thus \(C_1\) contains \(t_dd\), \(C_3\) contains \(t_aa\), and the four vertices outside \(D\) are \(w_0,w_*,\alpha,\beta\). Suppose two marked unary nodes \(N_1,N_2\) lie in distinct roots, each with split direct-special order \(H_i,s_i,A_i,t_i,J_i\). Let \(L_i,R_i\) be the ends of \(A_i\), \(E\) the two-special-leaf square edges, and \(M\) the face matching except at the site ports \(u,v\).

**Two-end absorption theorem.** Form the double inner opening
\[
 F=\bigl(D-E-\{s_1L_1,R_1t_1,s_2L_2,R_2t_2\}\bigr)
       \cup M\cup\{L_1R_1,L_2R_2\}.
\tag{1}
\]
Assume the root face graph \(K\) is connected. Then \(F\cup E\) has at most three components. If every component without \(u,v\) contains \(t_dd\) or \(t_aa\), the parent has a Hamilton cycle containing both site edges. Consequently a non-Hamiltonian child in this distinct-root, connected-\(K\) profile requires a terminal-free component of \(F\cup E\) containing neither end escape edge.

**Proof.** Every nonterminal of \(F\) has degree two, and \(u,v\) have degree one; \(F\) is one \(u\)--\(v\) path and some cycles. Restoring \(E\) reconnects each old child arc \(A_i\) and each complementary arc \(B_i\) within its base cycle. The third root cycle stays whole. The connected root face graph on three cycles becomes a coarse graph in which each of the two split-root vertices has been replaced by \(A_i,B_i\), distributing its incident \(M\)-edges between them. Splitting one vertex of a connected graph can increase its component count by at most one, so \(F\cup E\) has at most three components.

Within each component, choose a spanning tree of its leaf-square quotient and switch along it. This gives one spanning \(u\)--\(v\) path \(P\) in the marked component and one spanning cycle for each terminal-free component. All square supports lie in root words, so the end escape edges are preserved. There are at most two such cycles.

With no terminal-free cycle, the outside path
\[
                           (u,w_0,\beta,\alpha,w_*,v)
\tag{2}
\]
closes \(P\). With one cycle \(Z\), delete \(t_dd\) if present and use
\[
                    (u,w_0,t_d),\qquad(d,\beta,\alpha,w_*,v);
\tag{3}
\]
or delete \(t_aa\) and use
\[
                    (u,w_0,\beta,\alpha,a),\qquad(t_a,w_*,v).
\tag{4}
\]
These are the one-cycle splices of [Note 462](462-three-root-split-unary-splice-and-sharper-single-hexagon-kernel.md).

With two terminal-free cycles, the hypothesis assigns them different end escape edges; call them \(Z_d\ni t_dd\) and \(Z_a\ni t_aa\). Delete these edges and use the single exterior \(u\)--\(v\) path
\[
 (u,w_0,t_d)\ (Z_d-t_dd)\ (d,\beta,\alpha,a)\
 (Z_a-t_aa)\ (t_a,w_*,v),
\tag{5}
\]
where the broken cycles are oriented \(t_d\) to \(d\) and \(a\) to \(t_a\). The transitions \(d\beta,\beta\alpha,\alpha a\) are respectively old, trap-chord, and old edges. Equation (5) visits both cycles and all four vertices outside \(D\) once, and contains \(q=w_0u,p=vw_*\). Joining it to \(P\) is one Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

If the split nodes lie in \(W_1,W_3\), their complementary arcs \(B_1,B_3\) contain \(t_dd,t_aa\). An escape-free terminal-free component must therefore be supported inside \(A_1\cup W_2\cup A_3\); it cannot be a single isolated \(A_i\), which would give a two-edge cut, or the whole middle root alone, which would disconnect \(K\). For split nodes in \(W_1,W_2\) or \(W_2,W_3\), the analogous escape-free component avoids the end-root complement and the untouched opposite end root. These are necessary locations, not non-Hamiltonian examples.
