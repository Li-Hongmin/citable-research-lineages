> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The integral two-path strengthening fails while the fractional degree box survives

This note continues the fixed-port-partition problem isolated in
[Note 055](055-multiple-hole-cap-loads-stop-at-fixed-partition-barrier-exchanges.md).
It separates its natural integral and fractional strengthenings on an actual
cubic bipartite brace.

## The two strengthenings and the exact convex dual

Let \(F\) be a simple cubic bipartite brace with bipartition \(X\sqcup Y\),
fix \(r\in Y\), and put \(P=F-r\).  For one labelled port partition

\[
\pi_i=\{\{i\},[3]\setminus\{i\}\},
\]

let \(\mathcal F_i\) be the spanning two-component forests of Note 055.
For \(J\in\mathcal F_i\), write

\[
d(J)=(\deg_J(y))_{y\in Y\setminus\{r\}}.
\]

If \(m=|Y\setminus\{r\}|\), then

\[
d(J)\in\{1,2,3\}^m,
\qquad
\sum_y d(J)_y=2m-1.                                      \tag{1}
\]

Consider

\[
\tag{A}
\exists J\in\mathcal F_i:\quad d(J)\le2\mathbf1
\]

and the weaker convex condition

\[
\tag{B}
\operatorname{conv}\{d(J):J\in\mathcal F_i\}
\cap(-\infty,2]^m\ne\varnothing.
\]

The separating-hyperplane theorem gives the exact dual form

\[
\tag{2}
\text{(B)}\quad\Longleftrightarrow\quad
\forall\lambda\in\mathbb R_+^m\ \exists J\in\mathcal F_i:
\lambda\mathbin\cdot d(J)\le2\lambda\mathbin\cdot\mathbf1.
\]

Indeed, a linear functional bounded above on the downward box must have a
nonnegative normal, and its maximum there is
\(2\lambda\mathbin\cdot\mathbf1\).  If
\(K_J=E(P)\setminus E(J)\), cubicity gives

\[
d(J)_y=3-\deg_{K_J}(y),
\]

so (2) is equivalently

\[
\forall\lambda\ge0\ \exists J\in\mathcal F_i:
\lambda\mathbin\cdot\deg_{K_J}
\ge\lambda\mathbin\cdot\mathbf1.                         \tag{3}
\]

Condition (A) has a rigid graph form.  Equation (1) forces its degree vector
to have one coordinate equal to one and all others equal to two.  In the
component containing the two paired ports every vertex therefore has degree
two except the two ports; it is a path between them.  The other component is
a path from the singleton port to the unique degree-one \(Y\)-vertex.  Thus
(A) is precisely a prescribed spanning two-path cover.

## Binary hole bounds do not imply the degree box

Property (B) implies the weak bound of Note 055 for every hole set \(H\), by
taking \(\lambda=\mathbf1_H\) in (2).  The converse cannot be recovered even
from all proposed one-unit strong bounds at the abstract degree-vector level.

Put \(e=d-2\mathbf1\) and consider

\[
\begin{aligned}
&(-1,-1,0,0,0,1),&&(-1,1,-1,-1,0,1),\\
&(-1,-1,1,1,-1,0),&&(0,-1,-1,-1,1,1),\\
&(-1,-1,-1,1,1,0),&&(-1,-1,1,-1,1,0),\\
&(-1,0,-1,1,-1,1),&&(-1,0,1,-1,-1,1).
\end{aligned}                                               \tag{4}
\]

Every vector has total sum \(-1\).  For every singleton \(H\), some vector
has \(e(H)\le0\), and for every \(|H|\ge2\), some vector has

\[
e(H)\le-1.                                                   \tag{5}
\]

Nevertheless, for

\[
\lambda=(1,1,3,3,3,7),
\]

the eight scalar products \(\lambda\mathbin\cdot e\) are

\[
(5,1,1,3,1,1,3,3).                                         \tag{6}
\]

Hence every convex combination has positive weighted excess and misses the
degree box.  This six-coordinate system is not claimed to be a forest family;
it proves only that binary-\(H\) inequalities cannot replace the genuinely
weighted dual (2).  The 63 subset checks and (6) are reproduced by
[the exact verifier](../computations/verify_binary_hole_bounds_do_not_force_degree_box.py).

## An actual brace separates (A) from (B)

Let \(F\) be the Ellingham--Horton graph on 54 vertices with graph6 string

```text
uhCGGCP?GGo@?PG?_?KO@?????G?????C??@??AG??????P??@?????_???G???P??AA??OCC?C?CC???AAO???__???CC???????????@????????????_?????G?????P????????????AG?????G???????C??????@??????AG?????OOG?????__??G???__??????OQ??????CC???????__?????G??G?????O??W
```

It is simple, connected, cubic, bipartite, and nonplanar.  On both colour
sides its minimum strict-Hall surplus

\[
\min_{\varnothing\ne U,\ |U|\le26}(|N(U)|-|U|)
\]

is two, so \(F\) is a brace.  Take

\[
r=52,\qquad N_F(r)=(32,50,53),\qquad
\pi=\{53\}\mid\{32,50\}.                                  \tag{7}
\]

The fibre \(\mathcal F_\pi\) is nonempty, but it does not satisfy (A).
The latter assertion has a compact Hamilton-circuit formulation.  If a
prescribed two-path cover existed, orient the paired path from 32 to 50 and
the other path from 53 to its \(Y\)-endpoint \(y\).  After adjoining one dummy
vertex, the artificial arcs

\[
\mathrm{dummy}\to32,
\qquad 50\to53,
\qquad y\to\mathrm{dummy}                                  \tag{8}
\]

would close the two paths into a Hamilton circuit.  Conversely, deleting the
three artificial arcs from any such circuit recovers exactly the required
two-path cover.  The resulting finite circuit instance has 54 vertices and
184 directed arc variables: both orientations of the 78 edges of \(F-r\),
the first two forced arcs in (8), and the 26 possible return arcs.  Exact
integer CP-SAT returns `INFEASIBLE`.

The same fibre satisfies (B) with minimal support two.  There are forests
\(J_1,J_2\in\mathcal F_\pi\) whose exceptional \(Y\)-degrees are

\[
\begin{array}{c|c|c}
&\deg=1&\deg=3\\ \hline
J_1&\{12,16,20,38,40\}&\{10,14,22,44\}\\
J_2&\{10,14,22,44\}&\{12,16,38\}.
\end{array}                                                  \tag{9}
\]

Every unlisted coordinate has degree two.  Therefore

\[
\frac12d(J_1)+\frac12d(J_2)\le2\mathbf1,                    \tag{10}
\]

with equality except at vertices 20 and 40, where the expectation is
\(3/2\).  The complete 51-edge sets are embedded in
[the permanent verifier](../computations/verify_eh54_fixed_fibre_boundary.py),
which also recomputes both strict-Hall minima by integer minimum cuts, checks
the two forests and (10) without a solver, and rebuilds the circuit instance.

Because a support-one distribution is exactly (A), support two in (10) is
minimal.  Moreover, for every binary hole set \(H\), averaging gives

\[
\frac12\ell_H(J_1)+\frac12\ell_H(J_2)\le2|H|,
\]

so at least one of \(J_1,J_2\) satisfies the weak bound.  This fibre is not a
counterexample to any binary weak bound and has no nonnegative separator for
(B).

## The degree projection is not polymatroidal

A natural attempt to prove (2) is to regard the complement-degree vectors as
the block-count projection of the bases of one matroid.  Its support function
would then be a matroid rank function and hence submodular; greedy integration
over the nested level sets of \(\lambda\) could potentially lift binary hole
bounds to (2).  This mechanism already fails in a plane brace.

Take the 12-vertex graph with graph6 string

    K??FEagT@WB_

with root \(r=0\), ports \((6,7,8)\), and fixed split
\(\{6\}\mid\{7,8\}\).  It is a simple cubic bipartite planar brace.  Its
fixed fibre has 22 forests and 13 distinct degree vectors.  For
\(u(J)=3\mathbf1-d(J)=\deg_{K_J}\), define

\[
g(S)=\max_{J\in\mathcal F_0}\sum_{y\in S}u(J)_y.            \tag{11}
\]

The two sets

\[
A=\{1,3\},\qquad B=\{3,4\}
\]

satisfy

\[
g(A)=3,\quad g(B)=3,\quad
g(A\cup B)=5,\quad g(A\cap B)=2.                            \tag{12}
\]

Thus

\[
g(A)+g(B)=6<7=g(A\cup B)+g(A\cap B),                        \tag{13}
\]

so the support function is not submodular.  In particular, this
complement-degree polytope is neither a polymatroid base polytope nor the
coordinate-block projection of the bases of one matroid.

The stronger discrete exchange property also fails.  The fibre contains

\[
a=(1,2,3,2,1),\qquad b=(2,1,1,2,3).
\]

At the second coordinate \(a_2>b_2\), while the possible receiving
coordinates with \(a_j<b_j\) are the first and fifth.  For the first,
neither symmetric exchange lies in the degree set.  For the fifth, the
exchange from \(a\) lies in the set but the exchanged vector
\((2,2,1,2,2)\) from \(b\) does not.  Hence the \(M\)-convex symmetric
exchange axiom fails.

This instance is not a counterexample to (B): it contains the integral
degree-box vector \((1,2,2,2,2)\).  Its role is to close the reduction of
(2) to one matroid, a polymatroid greedy theorem, or ordinary \(M\)-convex
exchange.  The complete fibre enumeration and the exact checks
(12)--(13) are reproduced by
[the permanent verifier](../computations/verify_fixed_fibre_degree_projection_nonpolymatroid.py).

## Fractional feasibility alone does not force support two

The EH54 fibre raises a sharper possible strengthening of (B): perhaps every
feasible degree box already contains the midpoint of two degree vectors.  In
excess coordinates this asks for \(e_1+e_2\le0\).  Convexity and the universal
coordinate constraints alone do not imply it.

Consider

\[
\begin{aligned}
e_1&=(-1,-1,0,1),\\
e_2&=(-1,1,-1,0),\\
e_3&=(-1,0,1,-1).
\end{aligned}                                               \tag{14}
\]

Each vector lies in \(\{-1,0,1\}^4\) and has total sum \(-1\).  Their
corresponding degree vectors are

\[
(1,1,2,3),\qquad (1,3,1,2),\qquad (1,2,3,1).
\]

The equal average satisfies

\[
\frac13(e_1+e_2+e_3)=(-1,0,0,0),                            \tag{15}
\]

so the convex hull meets the degree box at \((1,2,2,2)\).  Conversely, if
\((w_1,w_2,w_3)\) is box-feasible, the last three coordinates give

\[
w_2\le w_1,\qquad w_3\le w_2,\qquad w_1\le w_3.
\]

Thus the distribution in (15) is unique.  Yet no pair, including a repeated
vector, has nonpositive sum: the three distinct pairs leave respectively the
fourth, third, and second coordinates positive.  Every feasible distribution
therefore has support exactly three.

This obstruction is coordinate-minimal.  In at most two coordinates a
sum-\(-1\) vector has no positive entry and is already a support-one
certificate.  In three coordinates every vector with a positive entry is a
permutation of \((1,-1,-1)\), and every two distinct such vectors have
nonpositive sum.  The finite check is reproduced by
[the exact verifier](../computations/verify_fractional_box_does_not_force_support_two.py).

The three vectors in (14) are not asserted to come from a real fixed fibre.
They show that a universal support-two theorem, if true, must use actual
brace incidence or exchange structure; it cannot be extracted from (B) by
Carathéodory reduction or from the coordinate and total-sum identities alone.

## Exact boundary

The universal integral strengthening (A) is false for cubic bipartite braces.
Consequently the weak multiple-hole problem of Note 055 cannot be proved by
selecting one forest that is simultaneously safe at every \(Y\)-coordinate.
The fractional degree box (B) is strictly weaker on an actual brace and
survives the first integral obstruction.  Its proof, however, cannot follow
merely by identifying the degree projection with a matroid or polymatroid
base family; the failure of that route already occurs with planarity,
cubicity, and brace expansion.

This result does not settle any of the three remaining statements:

1. whether (A) holds for **planar** cubic bipartite braces;
2. whether (B) holds for all cubic bipartite braces, or at least for all
   planar ones;
3. whether actual fixed fibres satisfying (B) always admit an equal-weight
   support-two certificate.

The negative part is a finite computer-verified assertion.  It was obtained
independently from a component-flow mixed-integer formulation and from the
Hamilton-circuit formulation (8); the permanent verifier retains the latter.
It does not contain a standalone UNSAT proof log, so the weakest evidence
interface is the trusted exact CP-SAT infeasibility determination.  The
positive fractional certificate and the brace checks are independently
recomputable from the displayed graph and stored edge sets.
