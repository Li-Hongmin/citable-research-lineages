> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A source pretarget vacancy composes with a cross-block transition

[Notes 236](236-an-isolated-second-vacancy-composes-with-one-target-defect.md)
and [250--252](252-an-outside-site-vacancy-composes-with-a-cross-block-transition.md)
handle a spare vacancy outside or between the blocks of a
unique cross-block target transition. The remaining overlap
puts that spare in the source block *before* its target.
Two apparent matching chords across the target would close
the entire earlier prefix into a two-edge cut. The free
groups therefore separate, and each has one familiar
Hamilton detour.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps and \(s=2\), so
\(f=4r+6\). Assume \(d_L=d_R=0,b=1\), and let the sole
defective transition be \(L_j\in B_i\),
\(R_{j-1}\in B_h\), \(2\le j\le\ell\), \(i<h\).
Suppose the spare vacancy lies in the source block \(B_i\)
strictly before \(L_j\); the other vacancy lies between the
defective targets.

**Source-pretarget theorem.** Necessarily \(i\ge2\).
The source block begins with the free slots \(o_i,H,I\),
where \(H\) is the spare vacant even slot; no target precedes
\(H\) in that block. The first target after \(I\) is some
\(L_s\), \(s\ge j\), and all target transitions from
\(L_s\) to \(L_j\) are tight. The destination begins
\(o_h,w,R_{j-1}\), where \(w\) is the other vacancy.
If the target \(R_s\) preceding \(L_s\) lies in \(B_a\),
then \(a\le i-2\); for some \(t\in\{a,\ldots,i-2\}\),
the complete free matching is
\[
M_{\rm free}=
\{e_tI,o_{t+1}H,c_iw\}
\cup\{e_q o_{q+1}:0\le q\le r,\ q\ne t\},
                                                        \tag{1}
\]
where \(c_i,e_i\) are the source block's final free pair.
The parent has a Hamilton cycle containing \(xy,uv\), and
its legal site-expanded child is Hamiltonian. Reflection
handles a spare vacancy after \(R_{j-1}\) in the destination
block. Original square-trap lobes may have arbitrary
positive lengths.

**The source target is a matching barrier.** The first-slot
destination is excluded by Note 212's prefix cut, unchanged
by the extra vacancy before the source target. Thus
\(R_{j-1}\) is the third slot of \(B_h\), preceded by
\(o_h,w\), and \(L_j\) is last eligible in \(B_i\), followed
by \(c_i,e_i\). No other block between them has an eligible
position. The free prefix before \(L_j\) is even. By
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md),
no cross-block free chord may straddle it. The only
possible earlier free slots in \(B_i\) are its first odd
\(o_i\), the spare even \(H\), and its following odd \(I\);
the only later free slots there are \(c_i,e_i\).
Parity permits zero or two same-block chords across \(L_j\).

In the two-chord case \(Hc_i\) is forced by colour. The
other chord is \(Ie_i\) or \(o_ie_i\). The pair
\(Hc_i,Ie_i\) interlaces on \(C\), and both chords would
have to lie on the site-face side because they cross
\(L_j\)'s escape chord on the other side. Planarity
excludes it. If \(Hc_i,o_ie_i\in M\), take the main
old-cycle prefix through \(B_i\) together with squares
\(S_j,\ldots,S_\ell\). All earlier escape targets and
fixed site/face chords are internal. No free matching
edge can leave from before \(L_j\) by Note 203; its only
possible endpoints after \(L_j\) in \(B_i\), namely
\(c_i,e_i\), are already used. Thus the set is closed
under \(M\), with only two departing \(C\)-edges. This
contradicts three-connectivity. Hence no free chord crosses
\(L_j\).

If any target preceded \(H\) in \(B_i\), the last such
occupied target would also be a free-matching barrier.
Only the single first free slot \(o_i\) could start a
same-block chord across it; the free prefix is even,
so parity excludes that chord, while Note 203 excludes
cross-block chords. The adjacent pair \(H,I\) could not
reach an earlier block across this target or a later block
across the first target following \(H\); it also cannot
reach \(c_i,e_i\) across \(L_j\). It would have to match
itself, impossible because \(HI\in E(C)\). Thus \(H\)
is the first eligible position of \(B_i\). The left site
block \(B_0\) has \(R_\ell\) as its first interior target,
so it cannot be the source here. In particular \(i\ge1\),
and \(B_i\) begins \(o_i,H,I\). The first target after
\(I\) must be \(L_s\): a first \(R\)-target would make
its preceding \(L\)-target in an earlier block a second
nonadjacent transition. Subsequent transitions through
\(L_j\) are tight.

**Two closed free groups.** Let \(R_s\) lie in \(B_a\),
\(a<i\). The group before \(L_s\) has order
\[
e_a,o_{a+1},e_{a+1},\ldots,e_{i-1},o_i,H,I.
                                                        \tag{2}
\]
All intervening blocks are short, since no target occurs
between \(R_s,L_s\) and the only spare vacancy is in
\(B_i\). No same-block free pair in (2) can be matched:
its adjacent pairs belong to \(C\), while \(o_i,I\)
have the same colour. Therefore all matching chords lie
opposite the site face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
and are noncrossing. The odd slot \(I\) must match an
earlier even final slot \(e_t\), \(a\le t\le i-1\).
The choice \(t=i-1\) strands the adjacent pair
\(o_i,H\), so \(t\le i-2\), proving \(i\ge2\).
Inside \(e_tI\), the even slot \(H\) must match
\(o_{t+1}\): a later mate would trap one adjacent
short-block pair or a matching-closed interval with a
two-edge cut, by [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
Every other slot in (2) takes its standard link.

The group after \(L_j\) and before \(R_{j-1}\) has
order \(c_i,e_i,o_{i+1},\ldots,o_h,w\). The barrier at
\(L_j\) above and the even-prefix barrier at the
destination keep it closed. The one-vacancy transition
argument of Note 212 applies within it: its first odd
slot matches \(w\), and all ordinary links remain
standard. Every other free group is ordinary. Combining
these facts proves (1).

**Marked Hamilton route.** In Note 196's target-and-square
path replace \(L_jR_{j-1}\) by
\(L_j,c_i,w,R_{j-1}\). In its ordinary free path replace
the one link \(e_t o_{t+1}\) by
\[
e_t,I,H,o_{t+1}.                              \tag{3}
\]
The two replacements use disjoint closed free groups.
Their displayed edges are in (1) or on \(C\). Thus the
paths are internally disjoint, span the parent and form
one Hamilton cycle through \(xy,uv\).
[Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
and [178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
give the legal child and longer lobes. \(\square\)

**A 30-vertex realization.** Take
\(r=2,\ell=2,i=2,h=3,j=s=2,a=t=0\). The old
cycle has blocks
\[
\begin{array}{ll}
B_0:&x,R_2,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&a_2,o_2,H,I,L_2,c_2,e_2,b_2,\\
B_3:&u,o_3,w,R_1,L_1,v,\\
S_1,S_2:&\alpha_q,\gamma_q,\delta_q,\beta_q
\quad(q=1,2),\text{ returning to }x.
\end{array}                                             \tag{4}
\]
Add the fixed matching chords \(xy,a_1b_1,a_2b_2,uv\)
and \(\alpha_q\beta_q,R_q\delta_q,L_q\gamma_q\)
for \(q=1,2\), together with
\[
e_0I,\quad o_1H,\quad e_1o_2,\quad c_2w,
\quad e_2o_3.                                      \tag{5}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,
c_2,w,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,I,H,o_1,a_1,b_1,e_1,o_2,a_2,b_2,e_2,o_3,u,v.
\end{split}                                             \tag{6}
\]
These paths share only \(x,v\), cover all 30 vertices,
and use only edges of \(C\) or the listed matching.

Every matching pair has opposite old-cycle parity, and
\(x,u\) have the same parity. On the site-face side place
the disjoint site, face and \(\alpha_q\beta_q\) chords.
On the other, \(R_2\delta_2\) contains the free nest
\(e_0I\supset o_1H\supset e_1o_2\) and the branch
\(L_2\gamma_2\); the latter contains
\(c_2w\supset e_2o_3\) and
\(R_1\delta_1\supset L_1\gamma_1\) as disjoint branches.
This gives a simple cubic bipartite plane graph with
cofacial sites. Its matching-chord interlacement graph
is connected: \(xy-e_0I-a_1b_1\),
\(e_0I-a_2b_2-c_2w-uv\),
\(uv-L_1\gamma_1-\alpha_1\beta_1-R_1\delta_1\),
and \(xy-R_2\delta_2-\alpha_2\beta_2-L_2\gamma_2-a_2b_2\)
connect the fixed chords; \(o_1H,e_1o_2\) interlace
\(a_1b_1\), while \(e_2o_3\) interlaces \(a_2b_2\).
[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
therefore proves three-connectivity of this parent and its
34-vertex legal site expansion; (6) and Note 001 give their
Hamilton cycles.

This closes a spare vacancy before the source of a cross-block
transition, and by reflection one after its destination.
All gapless all-square second-surplus target-order configurations
are now covered by Notes 235--253; the combined statement and
its dependency boundaries are recorded in Note 254.
