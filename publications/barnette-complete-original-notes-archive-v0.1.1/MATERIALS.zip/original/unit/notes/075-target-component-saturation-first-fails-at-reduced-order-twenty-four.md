> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Target-component saturation first fails at reduced order twenty-four

[Note 074](074-forced-gate-components-are-closed-rooted-forest-bond-traces.md)
formulates target-component saturation as the universal statement (FC): every
single-alternating-cycle component on which both expansion gates are forced
contains a liftable rooted target.  The statement is false.  This note gives
its first possible real plane-brace counterexample, separates it from the
ordinary complete-family existence statement, and identifies the remaining
general interface.

## 1. The first forced-component counterexample

Let \(F'\) be the plane cubic bipartite graph with graph6 string

    W???????????w?s?P_BC?IO?L??H_?BO??w?CD??cG??P_?

It is a brace of order \(24\).  In the dual Eulerian triangulation split the
vertex

\[
z=1,\qquad
N(z)=(2,8,9,11,13,6,3,0)
\]

at gate indices \((1,5)\).  Thus the gate neighbours are \(8,6\), the two
closed arcs are

\[
(8,9,11,13,6),\qquad (6,3,0,2,8),
\]

and the corresponding primal gate edges are

\[
g=5\,14,\qquad h=3\,21.
\]

Take dual root \(a=5\,7\), corresponding to primal root \(e=7\,16\).
The split triangulation is again simple and \(4\)-connected, and its plane
dual is a brace of order \(28\).

Modulo global colour complementation, the complete reduced target family
\(\mathcal T_e\) has twelve members.  Numbered in the canonical order of the
certificate, its single-alternating-cycle graph has precisely three
components,

\[
\{0,1,2,3\},\qquad
\boxed{\{4,5,10,11\}},\qquad
\{6,7,8,9\}.
\tag{1}
\]

Every target in the boxed component uses both \(g\) and \(h\).  For each of
its four targets, all eight assignments to the two split copies and the new
centre fail the rooted target condition: every assignment is either not NAE,
has the wrong cycle rank, or fails to put the root on the unique
monochromatic cycle.  Hence the boxed component contains no liftable target.

This proves the following.

**Theorem 1.** Target-component saturation (FC) is false for simple plane
cubic bipartite braces.  Its minimum reduced order is \(24\).

**Proof.** The explicit interface above is a real forced-two-gate component
with no liftable member, so it disproves (FC).  Notes
[071](071-at-most-one-gate-always-lifts-and-component-saturation-holds-through-twenty.md)
and
[073](073-target-component-saturation-holds-through-reduced-order-twenty-two.md)
prove (FC) for every reduced brace through order \(22\).  A cubic bipartite
graph has even order, so no intermediate order exists. \(\square\)

Thus the closed bad bond trace left open in Note 074 is not merely an
abstract transition model: it is realized by one plane brace.

## 2. Why ordinary existence survives

The counterexample changes the quantifier, not the underlying
complete-family conclusion.  In the same family, targets

\[
2,3,7,8
\tag{2}
\]

use exactly one gate and lift in normalized row \(001\).  The neutral-gate
lemma of Note 071 therefore closes the complete family even though one of
its exchange components is entirely bad.

More generally, the complete order-\(24\) census gives

\[
\begin{array}{lr}
\text{connected simple cubic bipartite representatives}&29579,\\
\text{plane braces}&18,\\
\text{legal splits}&1174,\\
\text{nonempty unchanged-root target interfaces}&34580,\\
\text{complete families forcing both gates}&408,\\
\text{targets in those forced families}&1864,\\
\text{complete-family failures}&0.
\end{array}
\tag{3}
\]

Every family not counted among the \(408\) forced families contains a target
using at most one gate and hence lifts by Note 071.  Every one of the
remaining \(408\) families contains a directly verified liftable target.
Combining (3) with the through-\(22\) results yields:

**Theorem 2.** Ordinary existence-level prescribed-edge \(C_4\)-lifting
holds for every simple plane cubic bipartite brace of reduced order at most
\(24\).

No statement about exchange components is needed or valid in Theorem 2.

## 3. Short arcs lift pointwise

There is also a general local reason why the order-\(24\) forced families
are easy.  Normalize a reduced target colouring by \(c(z)=0\), and suppose
both gate edges belong to its matching.  Then both gate neighbours have
colour \(0\).

**Short-arc lemma.** If either closed gate arc has three vertices, the target
lifts.  If both closed arcs have three vertices, normalized rows
\(011,101,110\) all lift.

**Proof.** A three-vertex closed arc has colour word \(010\): its two gate
ends have colour \(0\), while the intervening vertex must have colour \(1\)
by the NAE condition on the two incident triangles.  Suppose this is the
left arc.  In row \(101\), the left split copy and the new centre have colour
\(1\), while the right split copy retains colour \(0\).  In the
monochromatic graph, the old \(0\)-coloured star at \(z\) is retained at the
right split copy.  The intervening \(1\)-vertex merely acquires a two-edge
pendant path through the left split copy and the centre.  Deleting the
unchanged root therefore preserves the three-component forest and preserves
the component containing the two root ends.  This is exactly the rooted
target criterion.  The right-short case is symmetric and uses row \(011\).

If both arcs have three vertices, the same argument gives rows \(011\) and
\(101\).  In row \(110\), the old monochromatic path between the two gate
neighbours through \(z\) is replaced by the corresponding path through the
new centre, while each intervening \(1\)-vertex receives one pendant split
copy.  Again neither cycle rank nor the rooted component partition changes.
\(\square\)

The pointwise reconstruction of all \(408\) order-\(24\) forced families
shows that every one occurs at a split face of length \(4\).  All \(1864\)
targets therefore have two three-vertex arcs and all three rows in the lemma
lift.  No forced family at a wide site occurs in this census.

## 4. Correct remaining quantifier

The componentwise statement from Note 074 must be replaced by the strictly
weaker complete-family statement

\[
\boxed{
\begin{aligned}
&\forall(F',e,z,x_2,x_4),\\
&\left[g,h\in M\text{ for every }M\in\mathcal T_e\right]
\Longrightarrow
\left[\exists M\in\mathcal T_e\text{ that lifts}\right].
\end{aligned}}
\tag{CF}
\]

If the premise fails, Note 071 supplies a neutral one-gate lift.  If either
gate arc has three vertices, the short-arc lemma supplies a lift.  Therefore
the first genuinely nonlocal case of (CF) has

\[
|A_1|\ge5,\qquad |A_3|\ge5,
\qquad \deg(z)=|A_1|+|A_3|-2\ge8.
\tag{4}
\]

In other words, the remaining obstruction must be a **wide complete family**
forcing both gates.  The failed component in (1) is not such an obstruction,
because its complete family has the neutral escapes (2).

## 5. Evidence and reproduction

The standalone certificate verifier reconstructs the reduced and expanded
plane objects, checks simplicity, cubicity, bipartition and the brace
property, re-enumerates the complete target family and its one-cycle exchange
graph, and recomputes all eight local assignments for the failed component:

    uv run --with 'networkx==3.6.1' \
      units/barnette/computations/verify_order24_forced_component_counterexample.py

Expected markers:

    ORDER24_FORCED_TARGET_COMPONENT_FAILURE_INDEPENDENTLY_VERIFIED
    ORDER24_COMPLETE_TARGET_FAMILY_STILL_HAS_NEUTRAL_LIFTS

The complete order-\(24\) existence and pointwise forced-family calculations
are frozen in
[existence-lifting-order24](../computations/bundles/existence-lifting-order24/README.md).

**Exact conclusion.** Component saturation first fails at reduced order
\(24\), while ordinary complete-family existence lifting holds through that
order.

**Weakest load-bearing steps.** Minimality uses the complete through-\(22\)
theorem.  The negative result uses the explicit four-target component and
all thirty-two failed local assignments.  The positive order-\(24\) theorem
uses complete isomorph-free generation and exact filtering of every brace,
split, root family, gate condition, and required local row.

**Unresolved boundary.** Statement (CF) remains open at arbitrary order.
After the neutral-gate and short-arc lemmas, its only unresolved interfaces
are wide sites whose complete target family forces both gates.  No such
family occurs through reduced order \(24\); no claim is made for order
\(26\) or larger.

