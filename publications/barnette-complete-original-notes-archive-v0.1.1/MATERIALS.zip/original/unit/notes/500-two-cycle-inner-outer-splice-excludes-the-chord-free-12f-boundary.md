> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A two-cycle inner/outer splice excludes the chord-free \(12f\) boundary

[Note 499](499-rethreaded-one-defect-splice-leaves-one-12f-boundary-profile.md) leaves one necessary form for a doubly ladder-reduced non-Hamiltonian chord-free selected single-hexagon opening at \(c=5f-9\): four ordinary roots, an empty end gap, and one split marked unary node. The empty-gap end root must send a face chord to the other roots. The splice below works more generally: it does not require an equality charge or a specified number of ordinary wrappers.

Reflect the old Hamilton order so the empty gap lies on the left. More generally, let each \(X_i\) be a nonempty consecutive sequence of ordinary root words, with no exposed special position between them:
\[
 C=(w_0,W_1,t_d,X_1,t_c,X_2,t_b,X_3,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0).                         \tag{1}
\]
The trap chord is \(\alpha\beta\), the four escape edges are \(t_dd,t_cc,t_bb,t_aa\), and the site edges are \(q=w_0u,p=vw_*\). Let \(C_1\) be the old \(W_1\)-arc closed by its root chord, and let
\[
 D_0=(c,d,t_d,X_1,t_c,X_2,t_b,X_3,t_a,a,b,c)          \tag{2}
\]
be the rethreaded cycle of Note 496. Thus \(D=C_1\cup D_0\) covers every parent vertex except \(w_0,w_*,\alpha,\beta\). No face chord is used by \(D\), and the only ordinary chord used by \(D\) is the root chord of \(W_1\).

Let the unique marked nonleaf node be \(N=(H,s,A,t,J)\), with child word \(A=[L,R]\) and child chord \(LR\). Its direct positions \(s,t\) straddle \(A\). Every other assigned special position belongs to a two-special leaf. Write \(E\) for the square-supported old edge at each such leaf, and \(M\) for the face matching outside the site ports \(u,v\). The core chord \(HJ\) is unused by \(D\) whenever \(N\subset X_1\cup X_2\cup X_3\), or \(N\subset W_1\) but \(N\) is not the root of \(W_1\). [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) gives \(st\notin M\).

**Single-end-root one-defect theorem.** Assume order (1), allowing arbitrarily many ordinary roots in each \(X_i\), with every assignable special position in a two-special leaf except the direct positions \(s,t\) of the single split unary node \(N\). If some edge of \(M\) joins \(W_1\) to \(D_0\) and \(HJ\notin E(D)\), then the parent has a Hamilton cycle containing both site edges. Consequently its legal \(C_4\)-expanded child is Hamiltonian. No bound on \(f\), the number of target-span roots, or the lengths of ordinary wrapper chains is needed.

**Proof.** The cross-root edge makes \(D\cup M\) connected. Form the inner opening
\[
 F_{\rm in}=(D-E-\{sL,Rt\})\cup M\cup\{LR\}.       \tag{3}
\]
All vertices have degree two except the degree-one site ports \(u,v\). Restoring \(E\) gives three coarse pieces: the closed child \(A\), the complementary arc \(B\) of its base cycle, and the untouched other base cycle \(O\). Since an \(M\)-edge joins \(C_1\) to \(D_0\), the coarse graph has at most two components. Within each component, the leaf-square switches of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) merge its pieces into one spanning \(u\)--\(v\) path if marked, or one cycle if unmarked. A singleton-leaf child whose closing chord \(LR\) is its leaf-square chord contributes a quotient loop and needs no switch. All switches preserve \(t_aa\).

The four old edges removed in (3) and (5) are incident with the direct positions \(s,t\), whereas every leaf-square old edge and both its rails lie inside a different two-special leaf. Thus no opening deletes a rail needed by a leaf switch; the supports of distinct leaf switches are disjoint.

If \(F_{\rm in}\cup E\) is connected, these switches give a spanning \(u\)--\(v\) path on \(D\). Close it by \((u,w_0,\beta,\alpha,w_*,v)\). Suppose it is disconnected. The untouched cycle \(O\) belongs to a component with \(A\) or \(B\), because a cross-root \(M\)-edge exists. Thus the other component is either \(A\) alone or \(B\) alone. An isolated terminal-free \(A\) is impossible: all its ordinary third edges stay within its closing chord, no face or site edge leaves it, and only \(sL,Rt\) leave it in the cubic parent. This would be a two-edge cut.

If the terminal-free component contains \(t_aa\), its leaf switches give a cycle \(Z\) through that edge, while the other component gives the marked path \(P\). Delete \(t_aa\) from \(Z\) and use the two exterior routes
\[
              (u,w_0,\beta,\alpha,a),\qquad(t_a,w_*,v). \tag{4}
\]
Together with \(P\) and \(Z-t_aa\), they make one parent Hamilton cycle through \(q,p\). The old edge \(t_aw_*\) is available because the empty gap is on the left.

It remains to examine a terminal-free component without \(t_aa\). If \(N\subset W_1\), then \(O=D_0\) contains \(t_aa\), so the exceptional component must be \(B\) alone; \(A\cup D_0\) is marked. An \(M\)-edge joins \(A\) to \(D_0\), because \(B\) has none leaving it. Both direct positions \(s,t\in B\) are non-site and have their \(M\)-mates in \(B\). Their mates lie outside \([H,J]\): the only special positions of this node outside \(A\) are \(s,t\), and Note 473 excludes their pairing.

If \(N\subset X_1\cup X_2\cup X_3\), then the complementary arc \(B\subset D_0\) contains \(t_aa\). The exceptional component is therefore \(A\cup C_1\), while \(B\) is marked. Some \(M\)-edge \(yx\) joins \(y\in W_1\) to \(x\in A\). In the old main order \(w_0<y<s<x<t<w_*\). The direct position \(s\) cannot be a site port: \(q=w_0s\) would interlace \(yx\) in the order \(w_0<y<s<x\), while \(p=sw_*\) would interlace it in the order \(y<s<x<w_*\). Both site edges and \(yx\) lie on the common-face side of the old Hamilton cycle, so either interlacing would cross. Thus \(s\) has an \(M\)-mate. Since \(B\) is separate from \(A\cup C_1\) and \(st\notin M\), that mate lies in \(B\setminus[H,J]\).

In either exceptional case, use the outside opening
\[
 F_{\rm out}=(D-E-\{Hs,tJ\})\cup M\cup\{HJ\}.       \tag{5}
\]
It again has degree one exactly at \(u,v\). Before adding \(M\), its coarse pieces are the central arc \(P_N=s\rightsquigarrow t\) containing \(A\), the outer complement \(B'\) closed through \(HJ\), and the untouched cycle \(O\). The \(A\)--\(O\) face chord identified above joins \(P_N\) to \(O\). The face chord from a non-site direct position to \(B\setminus[H,J]\) joins \(P_N\) to \(B'\). Hence \(F_{\rm out}\cup E\) is connected. Leaf-square switches give a spanning \(u\)--\(v\) path on \(D\), and \((u,w_0,\beta,\alpha,w_*,v)\) closes it into a marked parent Hamilton cycle. This exhausts the inner-opening components. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the marked cycle to the legal child. \(\square\)

**One-end-root theorem.** Under the setup (1), with any number of roots in the three \(X_i\), the same marked Hamilton conclusion holds regardless of whether \(W_1\) sends a face chord to \(D_0\), provided either \(N\subset X_1\cup X_2\cup X_3\), or \(N\subset W_1\) and \(N\) has two consecutive plain-unary ancestors.

Indeed, a cross-root face chord invokes the theorem above: in either stated placement \(HJ\notin E(D)\). If there is no such chord, the even cut of \(W_1\) consists of its two old boundary edges and its site edges. Three-connectivity and parity put both \(u,v\) in \(W_1\). The old \(L_1\)--\(R_1\) arc of \(W_1\) has spanning two-path covers in two distinct pairings of \(L_1,R_1,u,v\): use the open-arc theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) when \(N\) lies in a target-span block, or the two-wrapper split-arc lemma of [Note 499](499-rethreaded-one-defect-splice-leaves-one-12f-boundary-profile.md) when \(N\subset W_1\). The two exterior paths
\[
 (u,w_0,L_1),\qquad
 (R_1,t_d)\,(D_0-t_dd)\,(d,\beta,\alpha,w_*,v)
\]
are disjoint and span every vertex outside \(W_1\); they pair \((u,L_1)(R_1,v)\). Choose an internal pairing different from this one. The four paths then form one Hamilton cycle through both site edges. \(\square\)

**All-leaf end-root theorem.** If order (1) has no marked nonleaf node and every assignable special position belongs to a two-special leaf, the parent has a Hamilton cycle through both site edges, for any number of target-span roots. With a cross-root face chord, \(D\cup M\) is connected and [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) gives a spanning \(u\)--\(v\) path on \(D\), closed by \((u,w_0,\beta,\alpha,w_*,v)\). Without a cross-root face chord, the cut argument puts \(u,v\) in \(W_1\), and Note 458's open-arc theorem supplies two pairings there. One differs from the exterior pairing displayed above and closes the Hamilton cycle. \(\square\)

At the next chord-free charge level \(c=5f-10\), the profile \(m=f+1,R=5\) has every slack in [Note 499](499-rethreaded-one-defect-splice-leaves-one-12f-boundary-profile.md), equation (9), equal to zero; hence all assigned positions lie in two-special leaves. If its legal child were non-Hamiltonian, no two escape targets could be adjacent by [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md), so each of the three intervals between successive targets would contain at least one root. When zero roots lie outside the target span, the single rethreaded cycle \(D_0\) and Note 458 close the opening. When exactly one root lies outside, reflect if needed and apply the all-leaf end-root theorem. Therefore this five-root equality profile can survive only with exactly two roots outside the target span and exactly one root in each of its three target intervals. This is a necessary placement, not a non-Hamiltonian realization.

**Sharper chord-free kernel.** [Note 499](499-rethreaded-one-defect-splice-leaves-one-12f-boundary-profile.md) reduces a hypothetical non-Hamiltonian chord-free selected single-hexagon opening with \(f\ge8\) and \(c=5f-9\) to the four-root specialization \(X_i=W_{i+1}\) of (1). Equality supplies two plain-unary ancestors of \(N\) when it lies in \(W_1\), so the one-end-root theorem closes the profile. Therefore every such doubly ladder-reduced non-Hamiltonian child satisfies
\[
                  c\le5f-10,\qquad
                  |V(\bar G^+)|=18+2f+2c\le12f-2.      \tag{6}
\]
At \(f=8\) its reduced order is at most \(94\). The chorded branch still has the \(12f\)-vertex bound of [Note 476](476-a-six-terminal-square-splice-closes-the-chorded-equality-boundary.md). These are necessary bounds for a selected single-hexagon opening; they do not cover other openings or prove Barnette's conjecture. The dependencies in Notes 483–499 have not had an independent external proof review.
