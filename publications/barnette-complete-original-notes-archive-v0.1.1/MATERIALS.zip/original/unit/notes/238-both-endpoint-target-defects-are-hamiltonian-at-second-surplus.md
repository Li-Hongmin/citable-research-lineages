> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Both endpoint target defects are Hamiltonian at second surplus

[Note 237](237-disjoint-tight-budget-target-defects-compose-at-all-surpluses.md)
settles two endpoint defects when their block intervals
do not overlap. When both endpoint targets lie in one
block, matching parity permits two chords across its
target run. Three-connectivity excludes them.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps and \(s=2\), so
\(f=4r+6\). Assume
\[
d_L=d_R=1,\qquad b=0.                         \tag{1}
\]
Thus both endpoint targets are defective and every
consecutive inter-lobe transition is adjacent.

**Double-endpoint theorem.** The parent has a Hamilton
cycle through both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian, for every placement
of the two endpoint targets and every positive original
lobe length.

**Proof.** Note 197 assigns one vacant eligible position
before \(R_\ell\) and the other to \(L_1\) itself.
There are no other vacancies. By its endpoint barrier,
\(R_\ell\) is the third interior slot of some block
\(B_h\); every preceding block is short. The last
target \(L_1\) lies at the last eligible even position
of some block \(B_i\); every later block is short.
Target order gives \(h\le i\).

If \(h<i\), the intervals \([0,h]\) and
\([i,r+1]\) are disjoint. Note 237 applies.
Suppose \(h=i\). All escape targets are then
inside the same block \(B_h\), whose interior
has the form
\[
o_h,w,R_\ell,L_\ell,R_{\ell-1},
\ldots,R_1,L_1,c,e_h.                         \tag{2}
\]
For \(\ell=1\), the middle sequence is simply
\(R_1,L_1\). The free slots before the target
run are \(o_h,w\), and those after it are
\(c,e_h\). All earlier and later blocks are
short.

The free-slot prefix before \(R_\ell\) is even.
Every cross-block free chord straddling
\(R_\ell\) is forbidden by Note 203.
The only opposite-colour same-block pairs
from before to after the target run are
\[
o_he_h,\qquad wc.                             \tag{3}
\]
Matching parity therefore permits either
both pairs in (3) or neither. If both occur,
the complete block interval
\(B_0,\ldots,B_{h-1}\) is closed under \(M\)
when \(h\ge1\): no free endpoint in \(B_h\)
remains available before \(R_\ell\), while
an edge to a later block would straddle
that target. Its site and face chords are
internal, so only its two boundary old-cycle
edges leave, contradicting three-connectivity.
If \(h=0\), all four free slots of \(B_0\)
are used by (3); the nonempty suffix
\(B_1,\ldots,B_{r+1}\) is then matching-closed,
again giving a two-edge cut. Hence neither
pair in (3) occurs.

The target run now separates the free matching
into a left group ending at \(o_h,w\) and a
right group beginning at \(c,e_h\). If \(h=0\),
the left group is just the adjacent pair
\(o_0,w\), which cannot be in \(M\).
If \(h=r+1\), the right group is the adjacent
pair \(c,e_{r+1}\), likewise impossible.
Thus any existing parent in this case has
\(1\le h\le r\).

The left group has exactly Note 211's delayed
first-target slot order. Its noncrossing,
two-edge-cut classification forces
\[
o_0w,\quad e_t o_{t+1}\ (0\le t<h)
\quad\text{into }M.                           \tag{4}
\]
The right group is its reflection: it forces
\[
ce_{r+1},\quad e_t o_{t+1}\ (h\le t\le r)
\quad\text{into }M.                           \tag{5}
\]
Let \(A\) be the even-starting matching of \(C\).
In Note 196's target-and-square path, replace
\[
xR_\ell\longmapsto x,o_0,w,R_\ell,
\qquad
L_1v\longmapsto L_1,c,e_{r+1},v.              \tag{6}
\]
Equations (4)--(5) make the ordinary free
chain unchanged. The repaired target path
and this free path are internally disjoint,
cover every vertex, and have endpoints \(x,v\).
Their union is a Hamilton cycle containing
\(xy,uv\). Notes 001 and 178 give the child
and original lobe lengths. \(\square\)

**A same-block realization.** Take
\(\ell=1,r=2,h=i=1\). The old 24-cycle has
consecutive blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_1,L_1,c,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&u,o_3,e_3,v,\\
S_1:&\alpha,\gamma,\delta,\beta
\quad\text{returning to }x.
\end{array}                                   \tag{7}
\]
The complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,
\alpha\beta,R_1\delta,L_1\gamma\}\\
&\cup\{o_0w,e_0o_1,e_1o_2,e_2o_3,ce_3\}.
\end{split}                                   \tag{8}
\]
All matching edges join opposite old-cycle
parities. Put the site, face, and
\(\alpha\beta\) chords on one side; on the
other, \(o_0w\supset e_0o_1\) and
\(R_1\delta\supset L_1\gamma\supset
ce_3\supset\{e_1o_2,e_2o_3\}\).
The latter two small chords are disjoint.
This gives a simple cubic bipartite plane
graph with cofacial site edges.

The matching-chord interlacement graph is
connected: the chain of alternations
\[
xy-o_0w-a_1b_1-e_1o_2-a_2b_2-e_2o_3
-uv-ce_3-a_1b_1-L_1\gamma-\alpha\beta
-R_1\delta-a_1b_1                              \tag{9}
\]
contains all chords except \(e_0o_1\),
which interlaces \(xy\). Note 217's interval
criterion gives three-connectivity, and its
cut projection makes the 28-vertex site
expansion Barnette. A marked parent cycle
is the union of
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,
L_1,c,e_3,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,
e_2,o_3,u,v.
\end{split}                                   \tag{10}
\]
These paths cover all 24 vertices and share
only \(x,v\). \(\square\)

This removes the overlap between the two
endpoint defects at \(s=2\). A transition
defect overlapping another defect, a spare
vacancy in a defect block or group, gap
slots and nonsquare residual cycles remain
outside the result. Barnette's conjecture
is still unresolved.
