> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Remote \(H^{+-}\) and faithful completion leave a common-realization interface

This note continues
[Note 028](028-direct-p-regime-target-is-a-three-matroid-common-base-problem.md)
and
[Note 030](030-local-special-face-incidence-does-not-force-the-fec-triple-base.md).
It determines exactly what the remote ordered-edge quantifiers of global
\(H^{+-}\) contribute to the three-common-base problem, and it rules out a
faithful ambient realization of the two Helly holes in Note 030.  Neither
result decides the direct \(P\)-regime target.  Together they isolate the
remaining issue as a common-realization theorem inside one simple
4-connected Eulerian triangulation.

## The fixed-source form of global \(H^{+-}\)

Let \(F\) be a cubic graph, and let \(\mathcal H\) be the family of perfect
matchings whose complements are Hamilton cycles.  For every edge \(e\),
define

\[
 \mathcal T_e=
 \{M\cup\{e\}:M\in\mathcal H,\ e\notin M\}.
 \tag{1}
\]

If \(M\in\mathcal H\) and \(e\notin M\), then

\[
 F-(M\cup\{e\})=(F-M)-e
\]

is a Hamilton path.  In a plane realization, the duals of the edges in
\(M\cup\{e\}\) therefore form a spanning tree.  Its primal vertex-load
vector is

\[
 \lambda_{M\cup\{e\}}
 =\mathbf 1+\mathbf 1_{\partial e}.
 \tag{2}
\]

For distinct edges \(e,f\), the Hamilton cycle \(F-M\) contains \(e\) and
avoids \(f\) exactly when

\[
 e\notin M,\qquad f\in M,
\]

which is equivalent to \(f\in M\cup\{e\}\in\mathcal T_e\).  Hence

\[
 \boxed{
 F\text{ has global }H^{+-}
 \iff
 \bigcup_{B\in\mathcal T_e}B=E(F)
 \quad\text{for every }e\in E(F).}
 \tag{3}
\]

Equivalently, if

\[
 I(e)=\{M\in\mathcal H:e\in M\},
\]

then

\[
 I(f)\setminus I(e)\ne\varnothing
 \qquad(e\ne f).
 \tag{4}
\]

Thus the Hamilton-complement incidence columns form a strict Sperner
family.  This is the complete fixed-source incidence content of the remote
ordered-edge quantifiers.

The quantifier in (3) remains one edge at a time.  A tree in
\(\mathcal T_p\) that covers a remote edge \(f\) need not also contain the
second distinguished edge \(h\).  Similarly, a tree in \(\mathcal T_h\)
that covers \(f\) need not contain \(p\).  Consequently, (3) contains no
joint \((p,h,f)\)-coverage assertion within the fixed \((p,h)\) common-base
system of Note 028.

## Fixed-source coverage does not imply load balance

Use the notation of Note 028: \(p=uv\), \(h=za\),
\(K=F-\{u,a\}\), and

\[
 \mathcal X=
 \mathcal B(\mathcal P_X)\cap\mathcal B(\mathcal G_Q).
\]

For \(S\in\mathcal X\), put

\[
 d_y(S)=|S\cap\delta_K(y)|,
 \qquad y\in Y\setminus\{a\}.
 \tag{5}
\]

The FEC targets are precisely the members of \(\mathcal X\) with
\(d(S)=\mathbf1\).  For a weight
\(w\in\mathbb R^{Y\setminus\{a\}}\), define

\[
 \omega_w(S)=w\cdot(d(S)-\mathbf1).
 \tag{6}
\]

The order-16 global-\(H^{+-}\) brace of Note 030 has 112 members of
\(\mathcal X\) and a unique target.  In the coordinate order

\[
 (0,2,6,8,10,12,14)
\]

the weight

\[
 w=(0,1,3,2,-1,-2,-3)
 \tag{7}
\]

gives margin zero on the target and positive margin on every other member;
the margin distribution is

\[
 0^1,1^6,2^{15},3^{22},4^{23},5^{20},6^{15},7^8,8^2.
 \tag{8}
\]

After deleting the target, the all-one load is therefore outside the convex
hull of the remaining 111 loads.  More specifically, the complete remote
\(h\)-source family covers every edge as required by (3), but the six
members admitting the relevant projection to \(\mathcal X\) have margins

\[
 4,4,4,6,6,6.
 \tag{9}
\]

Thus fixed-source edge coverage, its Sperner reformulation, and convex
averaging of source-derived non-target bases cannot establish the target.
A weighted proof would need a new inequality coupling different source
families through their common ambient realization.

This separation is already strict at the abstract level.  Put the six edge
labels of the six-element Helly model of Note 030 on the six two-subsets of
four abstract Hamilton rows.  The six column supports are distinct and have
equal size, so they satisfy (4) in both ordered directions.  The two
distinguished columns can be chosen disjoint.  Combining these rows with
the exact local partition and graphic data yields

\[
 \boxed{
 \text{local Helly data}
 +\text{complete remote Sperner data}
 \not\Longrightarrow
 \text{a triple common base}.}
 \tag{10}
\]

This is an abstract separation only.  The rows are not asserted to be the
perfect matchings of the same plane cubic graph that realizes the two
partition systems and the graphic matroid.

## The six-element Helly hole has no faithful completion

Call an ambient completion **faithful** when the six labelled elements
remain the complete blocks

\[
\begin{aligned}
X &: \{e_0,e_1\},\ \{e_2,e_3\},\ \{e_4,e_5\},\\
Y &: \{e_0,e_2\},\ \{e_3,e_4\},\ \{e_1,e_5\},
\end{aligned}
\tag{11}
\]

with their dual endpoints and rotations unchanged, while the two deleted
primal vertices are restored.

The row--column incidence graph of (11) is \(C_6\).  In the nonadjacent
\((u,a)\) regime, restoring the deleted vertices is forced: \(u\) is
adjacent to all three \(Y\)-vertices of this \(C_6\), and \(a\) is adjacent
to all three \(X\)-vertices.  The resulting cubic bipartite graph is

\[
 K_{4,4}-M,
\tag{12}
\]

namely the cube.  All eight vertices are already cubic, so every connected
cubic faithful extension is still the cube.

Every face of the cube has length four.  If the prescribed disjoint edges
\(p=uv\) and \(h=za\) were cofacial in the required order, that face would
have boundary

\[
 u,v,z,a,u,
\]

and would force \(ua\in E(F)\), contradicting the nonadjacent regime.
Therefore the six-element model cannot be faithfully completed even to a
legal cofacial plane cubic bipartite site, and a fortiori not to a brace or
a global-\(H^{+-}\) instance.

For the particular dual multigraph in Note 030, the obstruction can also
be read as a rotation collision.  The contracted root has only two possible
preimages.  With the first choice, closing the \(X\)-path block
\(\{e_2,e_3\}\) requires a second \(BC\)-edge; with the other choice,
closing the \(Y\)-path block \(\{e_1,e_5\}\) requires a second
\(AC\)-edge.  Either choice creates a parallel edge.  The defect is thus
not parity but simultaneous two-colour face closure in a simple
triangulation.

## The order-16 two-cut model also has no faithful extension

In the plane-cubic lower-level model of Note 030, the primal edges

\[
 0\,15,\qquad 7\,8
\]

form a two-edge cut.  Their duals are parallel in every plane embedding.
Any extension retaining the labelled dual endpoint pairs retains this
parallelism and therefore cannot be a simple triangulation.  Equivalently,
all old primal vertices are already cubic, so a connected cubic graph
containing the fixed graph as a literal subgraph cannot add vertices.

Hence any promotion of this model to a brace must change an old incidence,
rotation, or full partition block.  The 99 cross-switch repairs and 99
four-cycle repairs of Note 030 are non-faithful surgeries of this kind, and
every legal minimal repair restores a triple common base.  This finite
fact does not exclude a larger surgery.

## Exact remaining boundary

The direct target of Note 028 remains undecided.  The following information
is insufficient:

1. the exact triangle, path, and parallel-pair block types;
2. pairwise common-base nonemptiness and elementary matching coverage;
3. fixed-source edge coverage or strict Sperner incidence from global
   \(H^{+-}\);
4. convex averaging of non-target source projections;
5. faithful completion of either known Helly hole.

The surviving assertion must use the fact that all Hamilton rows, both
overlapping exact-one face-colour systems, and the graphic bases arise in
one common simple 4-connected Eulerian triangulation.  In weighted language
it must both establish

\[
 \min_{S\in\mathcal X}w\cdot d(S)
 \le w\cdot\mathbf1
 \qquad\text{for every }w
 \tag{13}
\]

and rule out a fractional all-one fibre with no integral target.  In
combinatorial language it must couple different fixed-source families; no
one-family spanning-tree or edge-cover statement supplies that coupling.

The only unresolved counterexample mechanism descending from Note 030 is
a **non-faithful four-pole replacement** that changes the saturated
incidence or rotation system, produces a plane cubic bipartite brace (and
ultimately global \(H^{+-}\)), and still leaves the triple intersection
empty.  Constructing such a graph would refute the direct \(P\)-regime
target; excluding it requires a genuinely ambient common-realization
theorem.

The fixed assertions are reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/scratch/worker-barnette/remote-hpm-triple-base-boundary.py
python3 \
  units/barnette/scratch/worker-barnette/ambient-completion-helly-obstruction.py
```

with terminal markers
`REMOTE_HPM_TRIPLE_BASE_BOUNDARY_VERIFIED` and
`AMBIENT_COMPLETION_HELLY_OBSTRUCTION_VERIFIED`.
