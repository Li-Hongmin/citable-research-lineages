> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A square-forced gate reduces the other gate to a two-linkage fibre

[Note 084](084-two-local-gate-coloops-are-nonplanar-but-single-gate-forcing-can-be-nonlocal.md)
shows that two root-opposite squares cannot force both gates of a legal wide
site.  The first remaining stratum has one square-forced gate and one
potentially global restricted coloop.  This note gives an exact
arbitrary-order reduction of that stratum.

Deleting the root--gate square identifies the complete rooted-target family
with perfect matchings whose complements are two spanning paths with a fixed
terminal pairing.  Equivalently, after smoothing the two actual complement
channels, one obtains a separated two-factor family in a plane cubic
bipartite multigraph.  The smoothing need not be a smaller brace, so the
obvious induction is invalid.

In all \(541\) direct-square occurrences of the frozen through-\(26\)
corpus, the two sectors of the other gate are adjacent by a single
target-preserving alternating cycle inside this two-linkage fibre.  This
gives a precise arbitrary-order candidate.  The data also refute the
stronger claims that every source can descend to the escaping sector or
that a facial flip supplies the crossing.

## 1. Square deletion and the fixed-pairing fibre

Let \(G\) be a simple plane cubic bipartite brace.  Let

\[
Q=u-v-x-y-u
\tag{1}
\]

be a \(4\)-cycle whose opposite edges are the unchanged root

\[
e=uv
\tag{2}
\]

and the first gate

\[
g_0=xy.
\tag{3}
\]

Write \(u',v',x',y'\) for the unique neighbours of \(u,v,x,y\) outside
\(Q\), and put

\[
R=G-V(Q).
\tag{4}
\]

Whenever \(\mathcal T_e\ne\varnothing\), these four boundary occurrences
are distinct.  An identification between the two complement channels would
identify vertices on the two distinct target cycles.  An identification
within one channel would close an odd cycle through one side of \(Q\), which
is impossible in a bipartite graph.

Define \(\mathcal L_{u'y'\mid v'x'}(R)\) to be the set of perfect matchings
\(L\) of \(R\) such that \(R-L\) is the disjoint union of two spanning
paths, one with endpoints \(u',y'\) and the other with endpoints \(v',x'\).

**Square-deletion theorem.**  There is a bijection

\[
\boxed{
\Phi:\mathcal T_e(G)\longrightarrow
\mathcal L_{u'y'\mid v'x'}(R),\qquad
\Phi(M)=M\setminus\{e,g_0\}.}
\tag{5}
\]

**Proof.**  The opposite-square lemma forces both \(e\) and \(g_0\) into
every \(M\in\mathcal T_e\).  All other edges incident with \(V(Q)\) are
therefore absent from \(M\), and

\[
L=M\setminus\{e,g_0\}
\tag{6}
\]

is a perfect matching of \(R\).  In \(G-M\), one target cycle traverses
the square side \(u y\), while the other traverses \(v x\), because the
root endpoints lie on different cycles.  Deleting \(Q\) opens these cycles
into spanning paths with endpoint pairs \(u',y'\) and \(v',x'\).

Conversely, let \(L\in\mathcal L_{u'y'\mid v'x'}(R)\).  Add \(e,g_0\) to
the matching.  Restore the four attachment edges and the two square sides
\(u y,v x\) to the complement.  The two prescribed spanning paths close
to two cycles, and \(u,v\) lie on different cycles.  This recovers a unique
member of \(\mathcal T_e\), inverse to (5). \(\square\)

If the other gate \(g_1\) meets \(e\), every rooted target already omits it.
Otherwise \(g_1\in E(R)\), and (5) preserves its membership:

\[
g_1\in M\iff g_1\in\Phi(M).
\tag{7}
\]

Thus the local--global statement is exactly

\[
\boxed{
\exists L\in\mathcal L_{u'y'\mid v'x'}(R):g_1\notin L.}
\tag{8}
\]

The square-forced gate has disappeared; the remaining question is whether
\(g_1\) is a coloop of a fixed-pairing spanning-two-path matching fibre.

## 2. Equivalent separated two-factor smoothing

Add two labelled channel edges

\[
p=u'y',\qquad q=v'x'
\tag{9}
\]

to \(R\), producing a plane cubic bipartite multigraph \(K\).  The edges
follow narrow neighbourhoods of the deleted paths through \(u y\) and
\(v x\).  Loops are excluded by bipartiteness, but parallel edges may
occur.

Let

\[
\mathcal S_{p\mid q}(K)=
\left\{
N:
\begin{array}{l}
N\text{ is a perfect matching of }K,\\
p,q\notin N,\\
K-N\text{ consists of exactly two cycles},\\
p,q\text{ lie on different cycles}
\end{array}
\right\}.
\tag{10}
\]

Closing the two paths in (5) gives a second exact representation:

\[
\mathcal T_e(G)\cong
\mathcal L_{u'y'\mid v'x'}(R)
\cong\mathcal S_{p\mid q}(K),
\tag{11}
\]

and both bijections preserve \(g_1\)-membership.

The labelled pairing in (9) is forced by the two actual complement
channels.  The other smoothing pairs the terminal paths differently and
does not preserve root separation.

## 3. Why smaller-brace induction fails

The multigraph \(K\) need not be a smaller simple brace.  In the even prism
\(C_n\square K_2\), take root \(B_0\) and square-forced gate \(T_0\).
The two channel edges in (9) are

\[
p=R_{n-1},\qquad q=R_2.
\tag{12}
\]

Both rungs already exist, so the smoothing creates two parallel pairs.
The original graph is a brace and has a nonempty complete rooted-target
family, but the only target-preserving smoothing immediately leaves the
class of simple braces.

Consequently

\[
\text{root--gate square in a brace}
\not\Longrightarrow
\text{a smaller brace carrying the same target family}.
\tag{13}
\]

Choosing the alternate smoothing to restore simplicity changes the terminal
pairing and invalidates (5).  Any proof of (8) must therefore use the fact
that the labelled two-channel square extension of \(K\) is a brace; ordinary
\(2\)-extendability does not simply descend to \(K\).

## 4. A uniform crossing edge in the frozen corpus

The permanent paired-coloop bundle contains \(541\) through-\(26\)
occurrences in which one gate is directly forced by a root-opposite square.
Reconstructing them uses no graph generation.  All \(7\,160\) rooted
targets satisfy the bijection (5).

For every one of the \(541\) occurrences, there are targets
\(M,N\in\mathcal T_e\) such that

\[
g_1\in M\setminus N,\qquad
M\mathbin\triangle N=A,
\tag{14}
\]

where \(A\) is one alternating cycle.  Since \(e,g_0\) are common to the
entire family, \(A\subseteq R\), it avoids \(Q\), and it contains \(g_1\).
Thus the two \(g_1\)-sectors are adjacent by a single-cycle exchange edge
inside the fixed-pairing fibre.

The minimum possible length of such a crossing cycle in each family has
distribution

\[
6^{396},\qquad10^{132},\qquad14^{13}.
\tag{15}
\]

Across all crossing edges, the length distribution is

\[
6^{1314},\qquad10^{1584},\qquad14^{1681},\qquad18^{527}.
\tag{16}
\]

This is stronger than finite gate escape: the two sectors are not only
nonempty, but touch along a target-preserving alternating cycle.

## 5. Arbitrary-source descent and facial flips both fail

The crossing edge cannot be reached from every double-gate target.  Among
the \(1\,929\) double-gate target occurrences, distance to the escaping
sector in the single-cycle exchange graph is

\[
1^{1881},\qquad2^{15},\qquad3^1,\qquad\infty^{32}.
\tag{17}
\]

Eight families contain the \(32\) unreachable sources, and the complete
target exchange graph is disconnected in \(32\) occurrences.  Hence the
correct quantifier must select a favourable crossing edge or source; an
arbitrary-source descent theorem is false.

Nor is (14) a local face flip.  None of the \(541\) families has a crossing
cycle equal to a face boundary, and only \(126\) have any induced crossing
cycle.  The observed mechanism is a nonlocal alternating cycle in \(R\).

## 6. Exact candidate and boundary

The analytic reduction and finite mechanism isolate the following
arbitrary-order statement.

**Local-square crossing-cycle candidate.**  In the setup of (1)--(3),
either every rooted target omits \(g_1\), or there exist
\(M,N\in\mathcal T_e\) satisfying (14), with
\(M\triangle N\subseteq G-V(Q)\).

This candidate implies (8) and holds for all \(541\) direct-square
occurrences in the complete frozen through-\(26\) corpus.  It is not implied
by connectivity of the whole target exchange graph, by an arbitrary-source
descent, or by a facial exchange.

Equivalently, the remaining theorem must show that the fixed-pairing
two-linkage fibre in (5) has at least one single-cycle exchange edge crossing
the \(g_1\)-coordinate.  A counterexample must give a labelled two-channel
square extension that is a simple plane brace while every member of
\(\mathcal S_{p\mid q}(K)\) contains \(g_1\).

**Exact conclusion.**  Square deletion converts the local--global paired
gate stratum exactly into a one-edge freedom problem in a fixed-pairing
spanning-two-path fibre.  Smoothing does not yield a smaller brace.

**Evidence level.**  Equations (5) and (11)--(13) are arbitrary-order
analytic results.  Equations (15)--(17) are exact finite classifications of
the named \(541\) occurrences; the
[bundle](../computations/bundles/local-square-two-linkage-fibre/README.md)
reproduces them.

**Unresolved boundary.**  The local-square crossing-cycle candidate, and
therefore the local--global gate statement, remains open at arbitrary order.
The data support only the existential crossing-edge quantifier, not
arbitrary-source or facial variants.
