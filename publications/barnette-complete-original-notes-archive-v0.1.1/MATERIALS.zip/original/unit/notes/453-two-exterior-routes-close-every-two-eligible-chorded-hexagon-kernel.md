> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two exterior routes close every two-eligible chorded-hexagon kernel

The chorded single-hexagon normal form of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) has an old Hamilton cycle
\[
C=(w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,w_0),
\tag{1}
\]
where \(W\) is one ordinary-chord root interval. [Note 425](425-short-wrapper-parity-and-terminal-spine-paths.md) proves that, when exactly two leaves are site-eligible, the exterior face chords must join the partners of the site ports: \(z_Lx_j\) and \(y_kz_R\). The following switch uses these edges directly and does not depend on the tree shape or on the other face chords.

**Two-exterior-route theorem.** Let a graph contain the Hamilton cycle (1). Suppose \(W\) has first and last vertices \(W_\ell,W_r\), with an edge \(W_\ell W_r\), and contains consecutive old-cycle pairs \(x_jy_j\) and \(x_ky_k\) in the order
\[
W_\ell <x_j<y_j<x_k<y_k<W_r.
\tag{2}
\]
Suppose the graph also has the seven edges
\[
q=w_0y_j,\quad p=x_kw_*,\quad
z_Lx_j,\quad y_kz_R,\quad
t_cc,\quad t_bb,\quad W_\ell W_r.
\tag{3}
\]
Then it has a Hamilton cycle containing \(p\) and \(q\). No planarity, bipartiteness, cubicity, or information about the other edges is needed for this conclusion.

**Proof.** Let \(\overrightarrow C[r,s]\) denote the forward subpath of the old cycle inside \(W\) from \(r\) to \(s\), including both ends. The required cycle is
\[
\begin{aligned}
w_0&\xrightarrow{q}y_j
\xrightarrow{\overrightarrow C[y_j,x_k]}x_k
\xrightarrow{p}w_*,\alpha,a,b
\xrightarrow{bt_b}t_b,z_R
\xrightarrow{z_Ry_k}y_k\\
&\xrightarrow{\overrightarrow C[y_k,W_r]}W_r
\xrightarrow{W_rW_\ell}W_\ell
\xrightarrow{\overrightarrow C[W_\ell,x_j]}x_j
\xrightarrow{x_jz_L}z_L,t_c
\xrightarrow{t_cc}c,d,\beta,w_0 .
\end{aligned}
\tag{4}
\]
The unlabeled steps in (4) are old-cycle edges. The labeled steps are precisely the seven edges (3). Cutting \(x_jy_j\) and \(x_ky_k\) divides the old \(W\)-arc into the three disjoint paths
\[
C[W_\ell,x_j],\qquad C[y_j,x_k],\qquad C[y_k,W_r].
\tag{5}
\]
They cover every vertex of \(W\) once. The other twelve vertices are exactly \(w_0,z_L,t_c,t_b,z_R,w_*,\alpha,a,b,c,d,\beta\), each occurring once in (4). Thus (4) is one spanning cycle, and it contains \(p,q\). \(\square\)

**Four-port form for other exterior mates.** Keep the old-cycle order (1), but let the exterior face chords be \(z_Lr_L,r_Rz_R\) for arbitrary \(r_L<y_j<x_k<r_R\) in \(W\). The same outside edges form two disjoint paths spanning all twelve exterior vertices:
\[
(r_L,z_L,t_c,c,d,\beta,w_0,y_j),\qquad
(r_R,z_R,t_b,b,a,\alpha,w_*,x_k).
\tag{6}
\]
Consequently a Hamilton cycle using exactly these two exterior routes exists if and only if \(W\) has a spanning two-path cover on terminals \(r_L,y_j,x_k,r_R\) whose pairing differs from \(\{\{r_L,y_j\},\{x_k,r_R\}\}\). Indeed, two distinct perfect matchings on four terminals form one alternating four-cycle when their paths are contracted, while equal pairings form two cycles. The two alternative internal pairings are \(\{\{r_L,r_R\},\{y_j,x_k\}\}\) and \(\{\{r_L,x_k\},\{y_j,r_R\}\}\). The former is the nested linkage
\[
\{\{r_L,r_R\},\{y_j,x_k\}\}.
\tag{7}
\]
When \(r_L=x_j,r_R=y_k\), the three old-cycle pieces (5) and the root chord \(W_\ell W_r\) provide (7) without using any other internal edge. The actual word can have edges on both sides of its old-cycle arc, so planarity alone does not discard the other alternative pairing. The criterion is exact for the exterior routes (6); a child may also be Hamiltonian through another exterior routing or another witness of Note 001.

**Eligibility-location corollary.** In Note 416's \(c=31\) kernel, a non-Hamiltonian legal child must have at least one site-eligible leaf strictly before \(j\) or strictly after \(k\). Indeed, if no such leaf exists, the exterior terminal \(z_L\) has only \(x_j\) as a possible eligible mate before \(y_j\), and \(z_R\) has only \(y_k\) after \(x_k\), by Note 425's rank-parity argument. The theorem then applies, regardless of how many eligible leaves lie between the sites.

When exactly four leaves are eligible, let the two eligible non-site leaves be the *extra* leaves. A hypothetical non-Hamiltonian child has, up to reflection, only two possible eligible-face-chord patterns:
\[
\begin{array}{c|c}
\text{extra-leaf positions}&\text{forced eligible face chords}\\\hline
r<s<j<k&z_Lx_r,\ y_rx_s,\ y_sx_j,\ y_kz_R\\
r<j<k<s&z_Lx_r,\ y_rx_j,\ y_kx_s,\ y_sz_R .
\end{array}
\tag{8}
\]
These are necessary patterns; the remaining ineligible-leaf chords and the ordinary tree are unrestricted by this corollary. To prove completeness, a single extra eligible leaf in the middle matching compartment would have to pair its own adjacent \(x_i,y_i\), an old-cycle edge, so the number of middle extra leaves is zero or two. If it is two, the exterior mates are \(x_j,y_k\) and the theorem applies. Otherwise both extra leaves are outside. If they split one per side, the two four-terminal noncrossing matchings are forced as in the second row of (8): pairing an extra leaf to itself is forbidden. If both lie before \(j\), the eligible terminals in order are \(z_L,x_r,y_r,x_s,y_s,x_j\). Their only noncrossing perfect matchings avoiding the two old-cycle leaf edges are
\[
\{z_Lx_r,y_rx_s,y_sx_j\},\qquad
\{z_Lx_j,x_ry_s,y_rx_s\}.
\]
The second has the adjacent exterior mate \(x_j\), while the empty right compartment forces \(y_kz_R\); the theorem makes that child Hamiltonian. This leaves the first row of (8). Reflection handles two extras after \(k\). \(\square\)

**Two residual cycles and their ordinary exits.** In either row of (8), let \(H_0\) consist only of the old \(W\)-arc, its root chord \(W_\ell W_r\), and the two eligible face chords internal to \(W\). The graph \(H_0\) has no spanning two-path cover with terminals \(r_L,y_j,x_k,r_R\). For the first row, the internal chords are \(y_rx_s,y_sx_j\); the terminal set is \(x_r,y_j,x_k,y_k\). For the second row, the chords are \(y_rx_j,y_kx_s\); the terminal set is \(x_r,y_j,x_k,y_s\).

To prove the claim, first observe that \(W_\ell W_r\) is forced: without it, the two word-end vertices have degree one in \(H_0\), although neither is a terminal. Each listed terminal has just its two old-cycle neighbors inside \(H_0\). Every leaf has at least one ordinary wrapper, so the terminal's old-cycle neighbor away from the other special position of the same leaf has no alternative incident edge in \(H_0\). That outward edge is forced, and the terminal must omit its leaf edge. The degree-two condition then forces both listed eligible face chords. In both rows the four omitted old leaf edges are
\[
x_ry_r,\quad x_sy_s,\quad x_jy_j,\quad x_ky_k;
\tag{9}
\]
Their order along \(W\) is \(r,s,j,k\) in row 1 and \(r,j,k,s\) in row 2. No other choice of edges in \(H_0\) meets the required degrees. The resulting subgraph has the required two open paths, but also two disjoint cycles closed by the internal eligible chords. Their old-cycle vertex intervals are respectively
\[
\begin{array}{c|cc}
\text{row of (8)}&I_1&I_2\\\hline
1&[y_r,x_s]&[y_s,x_j]\\
2&[y_r,x_j]&[y_k,x_s].
\end{array}
\tag{10}
\]
Hence it is not a spanning two-path cover.

Moreover, each interval in (10) has the form \([y_a,x_b]\), with \(a<b\), and has an ordinary matching chord exiting on each side. The innermost wrapper chord of leaf \(a\) joins an opening vertex before \(x_a\) to a closing vertex after \(y_a\): its first endpoint lies left of \(I_t\) and its second inside. The innermost wrapper chord of leaf \(b\) similarly joins a vertex inside \(I_t\) to one right of it. This holds for both full and short leaves and gives two distinct ordinary exits without using three-connectivity. It does not say that either exit merges a residual cycle into a spanning path. \(\square\)

This proves that the sparse old-cycle switch alone cannot close either \(s=4\) pattern. [Note 454](454-one-missing-leaf-switch-gives-two-four-port-pairings.md) uses ordinary leaf-wrapper switches to absorb every residual cycle and supplies two different four-port pairings, closing this entire \(f=7\) chorded branch.

**Entire two-eligible kernel.** In Note 416's doubly reduced \(f=7,c=31\) chorded single-hexagon setting, the ordinary forest has one seven-leaf root, whose outer ordinary chord is \(W_\ell W_r\). The two site edges are \(q=w_0y_j\) and \(p=x_kw_*\), with \(j<k\); their adjacent leaf edges give (2). The two escape edges are \(t_cc,t_bb\). If exactly two leaves are site-eligible, Note 425 forces the remaining two exterior face chords to be \(z_Lx_j,y_kz_R\). Consequently (4) supplies a Hamilton parent cycle containing both site edges for **every legal two-eligible child in this kernel**, regardless of its six possible five-leaf face matchings, its short-node location, or its ordinary tree. Clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the cycle to the \(C_4\)-expanded child. The double ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) transfer Hamiltonicity back to the original child.

This includes all of rows I--VI of Note 426 and strengthens the row-specific conclusions of [Notes 432](432-the-first-five-leaf-face-matching-and-its-reflection-are-hamiltonian.md) and [450](450-the-fourth-and-fifth-face-matchings-are-hamiltonian-in-the-two-eligible-kernel.md). Those notes give internal path certificates and structural classifications; the present cycle uses the two exterior face chords and therefore bypasses their tree analysis. The explicit seven-edge route (4) requires those exterior mates; Note 454 covers the other mates by a separate leaf-switch argument. Other selected opening shapes and Barnette's conjecture remain undecided.
