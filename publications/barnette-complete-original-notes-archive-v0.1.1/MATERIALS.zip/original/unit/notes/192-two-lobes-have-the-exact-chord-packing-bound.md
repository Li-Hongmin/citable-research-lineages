> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two lobes have the exact chord-packing bound

[Note 191](191-exact-single-lobe-chord-packing-and-hamiltonicity.md)
proves the universal facial spacing bound
\(|V(S_0)|\ge4r+8\) and describes equality as
four-vertex blocks along the other site-face arc.
With more than one square-trap lobe, that equality
creates a forbidden two-edge cut. The resulting
two-vertex surcharge is sharp when there are exactly
two lobes.

Use the legal all-square Barnette opening and the
one-square-per-lobe compression of Notes 176--179.
Let \(\ell\ge2\) be the number of lobes, let \(S_0\)
be the \(x\)-to-\(v\) old main segment, and let
\(r\ge1\) count matching edges on the other
\(y\)-to-\(u\) site-face arc.

**Multiple-lobe spacing theorem.** One has
\[
|V(S_0)|\ge4r+10,
\qquad
f=|V(S_0)|-2\ell-4\ge4r+6-2\ell.
\tag{1}
\]
For \(\ell=2\), this bound is attained at every
\(r\ge1\); hence
\[
f_{\min}(2,r)=4r+2.
\tag{2}
\]
The attainment families have Hamiltonian parents
and site-expanded children, and each lobe may have
arbitrary positive length.

**Proof.** Suppose instead that equality held in the
universal spacing bound:
\[
|V(S_0)|=4r+8.
\tag{3}
\]
Note 191 then gives the exact main order
\[
x,o_1,o_2,y,\,
a_1,g_1,h_1,b_1,\ldots,
a_r,g_r,h_r,b_r,\,
u,o_3,o_4,v.
\tag{4}
\]
The \(r\) chords \(a_i b_i\) and the site edges
\(xy,uv\) lie on the common-face side of \(C\).
All other main matching chords join the slots
\[
o_1,o_2,g_1,h_1,\ldots,g_r,h_r,o_3,o_4
\tag{5}
\]
on the opposite side: a chord incident with a
filler \(g_i,h_i\) must interlace \(a_i b_i\);
one joining the two outer slot pairs interlaces
\(xy\); matching a slot pair internally would
duplicate a \(C\)-edge.

The first two escape targets on \(S_0\) are
\(R_\ell<L_\ell\), matched to the last residual
square \(S_\ell\) on the complementary \(C\)-arc
from \(v\) to \(x\). By Note 179, \(R_\ell\)
occupies an odd-index slot and \(L_\ell\) an
even-index slot. Since the next target
\(R_{\ell-1}\) lies strictly after \(L_\ell\),
the latter cannot be the final slot \(o_4\).
Thus \(L_\ell=o_2\) or \(L_\ell=h_j\) for
some \(1\le j\le r\).

Set \(z=y\) in the first case and \(z=b_j\)
in the second. Let \(W\) be the \(C\)-prefix of
\(S_0\) from \(x\) through \(z\), together with
all four vertices of \(S_\ell\). Every matching
edge incident with \(W\) stays in \(W\).
Indeed, \(xy\) and every face chord fully in
the prefix have both endpoints there.
The only escape targets in the prefix are
\(R_\ell,L_\ell\), whose mates lie in
\(S_\ell\); its remaining matching edge also
stays in that square. Any other slot chord
with one endpoint before \(L_\ell\) cannot
end after it: both it and the escape edge
at \(L_\ell\) lie opposite the common face
and would cross. There is no free slot
between \(L_\ell\) and \(z\), since
\(L_\ell\) is the last slot of its block.

Exactly two \(C\)-edges leave \(W\): the edge
after \(z\) on \(S_0\), and the edge entering
\(S_\ell\) from \(S_{\ell-1}\). Thus
\(|\delta_G(W)|=2\), contradicting
three-edge-connectivity. Equality (3) is
impossible. Since \(|V(S_0)|\) is even,
Note 191's bound increases to (1).

For \(\ell=2\), (1) gives \(f\ge4r+2\).
Note 190 constructs \(f=4r+2\) for every
\(r\ge1\), with both Hamilton parent
witnesses and a Hamiltonian site-expanded
child. Note 178 lengthens either lobe
without changing \(S_0\) or \(r\).
This proves (2). \(\square\)

The theorem fixes the two-lobe minimum for every
opposite-face chord count. It does not classify
all two-lobe equality graphs or decide whether
every child at equality is Hamiltonian.
For \(\ell\ge3\), (1) is a lower bound whose
sharpness is not asserted.
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
excludes its equality when \(\ell\ge3\).
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
subsequently proves every equality child Hamiltonian
for all lobe counts.
