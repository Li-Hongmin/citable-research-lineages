> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-hexagon failures have at most six plus twelve f reduced vertices

The leaf-switch theorem of [Note 454](454-one-missing-leaf-switch-gives-two-four-port-pairings.md) and the uniform three-root splice of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) apply beyond the first seven-face-chord kernel. Combined with the ordinary-forest charge of [Note 415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md), they improve both single-hexagon order bounds by a common amount.

Let a legal \(C_4\)-expanded child have a selected single-hexagon opening with \(f\ge7\) additional common-face-side main matching chords. As in Note 415, \(e=2\) means the trapped hexagon has the internal matching chord \(ad\), while \(e=4\) means all four interior hexagon vertices escape. Apply both ladder reductions, and write \(c\) for the remaining ordinary-chord count, \(m=u/2\) for assigned special-position pairs, and \(R\) for the number of roots when the ordinary forest is nonempty.

**Unified single-hexagon kernel theorem.** If the reduced child is non-Hamiltonian, then
\[
\begin{array}{c|c|c}
&c&|V(\bar G^+)|=14+e+2f+2c\\\hline
e=2&c\le5f-5&|V(\bar G^+)|\le6+12f\\
e=4&c\le5f-6&|V(\bar G^+)|\le6+12f.
\end{array}
\tag{1}
\]
In particular, at \(f=8\) a non-Hamiltonian reduced child has at most 102 vertices in either branch. At \(f=7\), (1) puts it at most at 90 vertices, contrary to the published Brinkmann--Goedgebeur--McKay theorem used in [Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md).

**Chorded proof, \(e=2\).** Note 415 gives \(m\le f\) and, for a nonempty ordinary forest,
\[
              c\le2(M_0+L)+m-3R\le5m-3R,
\tag{2}
\]
where \(M_0\le m\) and \(L\le M_0\) count marked nodes and leaves. If \(m\le f-1\), then \(c\le5f-8\); if \(m=f,R\ge2\), then \(c\le5f-6\). It remains to exclude \(m=f,R=1,c\ge5f-4\). In that case (2) forces \(M_0=L=f\), because \(M_0+L\le2f-1\) would give \(c\le5f-5\). All \(2f\) assigned positions therefore occur two per leaf. The leaf/branch wrapper bound of Note 410 gives \(c\le5f-3\), so \(c\ge5f-4\) leaves at most one node short; all other leaf modules are full.

Exactly two assignable special positions lie outside the unique root word \(W\), together with the two escape targets \(t_c<t_b\). Index \(w_0\) by zero. The chorded hexagon's neighbours \(c,b\) have odd and even old-cycle indices, respectively, so bipartiteness requires \(t_c\) at even and \(t_b\) at odd index. Since \(|W|\) is even, each outside marker's index parity is its rank among the four markers. Thus the outside-marker order must be \(z_L,t_c,t_b,z_R\). If \(W\) did not lie between the two targets, they would be adjacent and the escape merger of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) would make the child Hamiltonian. Hence the main order is
\[
                         w_0,z_L,t_c,W,t_b,z_R,w_*.
\tag{3}
\]
Neither \(z_L\) nor \(z_R\) can be an inner site port: a site at either immediately adjacent outer position would duplicate an old-cycle edge, while the other site's required order excludes the opposite assignment. They cannot be matched to each other without crossing the left site chord, so their face-chord mates \(r_L,r_R\) lie in \(W\), before and after the two inner site ports \(u<v\), respectively. The other \(2f-4\) leaf specials in \(W\) are matched internally. The two exterior paths
\[
\begin{aligned}
&(r_L,z_L,t_c,c,d,\beta,w_0,u),\\
&(r_R,z_R,t_b,b,a,\alpha,w_*,v)
\end{aligned}
\tag{4}
\]
span every vertex outside \(W\), include both site edges, and have four distinct leaf-special terminals. The word cycle \(W\) (old arc plus root chord) has at most one nonfull leaf, so Note 454 supplies two different internal terminal pairings. One differs from (4), giving a parent Hamilton cycle through both site edges and hence a Hamilton child. This contradicts the assumed failure. Therefore \(c\le5f-5\).

**Chord-free proof, \(e=4\).** Now \(m\le f+1\). If \(m\le f-1\), (2) gives \(c\le5f-8\). If \(m=f,R\ge2\), it gives \(c\le5f-6\). The remaining \(m=f,R=1\) case has exactly two assignable special positions outside its unique root. Four escape targets occur in two root flanks, in order meeting \(d,c,b,a\). Two consecutive targets within one flank cannot be adjacent old-cycle vertices, by the adjacent-escape merger. They also cannot have exactly one outside special position between them: their old-cycle indices would then have the same parity, while their adjacent hexagon neighbours have opposite parity. Thus each same-flank consecutive-target gap would need at least two outside special positions. Four targets in two flanks create at least two such gaps, but only two outside special positions exist. Hence \(m=f,R=1\) is Hamiltonian.

Take \(m=f+1\). Every assignable special position lies inside an ordinary root, so the only internal main vertices between roots are the four escape targets. If \(R\le2\), four targets occupy at most three gaps, forcing an adjacent pair and a Hamilton child. If \(R\ge4\), (2) gives \(c\le5f-7\). It remains to exclude \(R=3,c\ge5f-5\). Here (2) forces \(M_0=L=m=f+1\): a sum \(M_0+L\le2m-1\) would give \(c\le5f-6\). Thus every assignable special position occurs in a two-special leaf; the full wrapper maximum is \(5m-9=5f-4\), so at most one node is short. To avoid adjacent escape targets, each of the four gaps around the three roots contains exactly one target. This is precisely the uniform three-root form of Note 456, which has a parent Hamilton cycle through both site edges. The child is therefore Hamiltonian, a contradiction. Hence \(c\le5f-6\).

The empty-forest case has \(c=0\) and satisfies (1) for \(f\ge7\). Substituting the two chord-count bounds into \(|V(\bar G^+)|=14+e+2f+2c\) completes the proof. \(\square\)

The theorem is a necessary bound on a reduced non-Hamiltonian child. It does not assert that a counterexample attains it, and it does not cover multi-cycle openings or Barnette's conjecture in general.
