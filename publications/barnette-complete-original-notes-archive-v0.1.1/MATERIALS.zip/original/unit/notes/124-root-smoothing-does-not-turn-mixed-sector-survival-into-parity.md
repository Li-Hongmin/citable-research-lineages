> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Root smoothing does not turn mixed-sector survival into parity

[Note 117](117-mixed-sector-survival-is-a-gate-even-parent-child-exchange-alternative.md)
reduces the mixed branch of the rooted split-bond lemma to a sector-survival
statement.  [Notes 120--123](120-the-mixed-pair-exchange-cube-can-have-a-sterile-surviving-sector.md)
show that neither one prescribed exchange cube, the smallest two-bond square,
four-rank modularity, nor an affine root-separation predicate proves that
statement.  This note gives an exact Hamiltonian reformulation of the root
condition and then determines the boundary of the natural parity and
endpoint-pairing approaches.

Root smoothing is lossless: root-separated two-cycle targets are precisely
Hamilton cycles through two distinguished cofacial edges of a smaller plane
cubic multigraph.  It preserves single alternating-cycle exchange, the
surviving-gate sector, and the split-site state.  Nevertheless the selected
two-edge Hamilton family can have odd cardinality.  Actual legal splits
disprove endpoint-star parity, every natural cardinal domination, and
bondwise parent--child repair.  The remaining adjacent-escape assertion is
therefore genuinely global and purely existential.

## 1. The sterile endpoint star

Fix an interface-disjoint legal split and a sterile state-\(11\) rooted
parent target \(\chi^b\).  Put

\[
\begin{aligned}
 {\cal M}_\chi={}&\{\eta^{1-b}\in{\cal L}_{\neg11}^{\,1-b}:
 M_\chi\mathbin\triangle M_\eta
 \text{ is one alternating cycle through }g_1\},\\
 {\cal E}_\chi={}&\{\zeta^b\in{\cal L}_{\neg11}^{\,b}:
 M_\chi\mathbin\triangle M_\zeta
 \text{ is one alternating cycle avoiding }g_1\},\\
 {\cal X}^b={}&{\cal A}_{R_{00}}^b\cup
 {\cal A}_{X_{uy}}^b\cup{\cal A}_{X_{vx}}^b.
\end{aligned}
\tag{1}
\]

Thus \({\cal M}_\chi\ne\varnothing\) says that \(\chi\) is incident with a
mixed rooted bond.  The adjacent-escape strengthening of sector survival is

\[
 {\cal M}_\chi\ne\varnothing
 \quad\Longrightarrow\quad
 {\cal E}_\chi\ne\varnothing\ \text{ or }\ {\cal X}^b\ne\varnothing.
\tag{2}
\]

Under \({\cal L}_{\neg11}^{\,b}=\varnothing\), the first conclusion in
(2) is impossible, so (2) implies \(P_{\rm sector}\) of Note 117.  The
converse is not formal because it does not place a parent escape next to the
specified endpoint.

## 2. Exact root smoothing

Let \(G\) be a plane cubic graph and let \(e=rs\) be the fixed root edge.
Write \(r_0,r_1\) and \(s_0,s_1\) for the other neighbours of \(r\) and
\(s\), labelled so that after deleting \(r,s\) the exposed incidences occur
around the new face in the order

\[
 r_0,r_1,s_1,s_0.
\tag{3}
\]

Add the noncrossing cross-root edges

\[
 a=r_0s_0,\qquad d=r_1s_1,
\tag{4}
\]

treating them as distinguished parallel copies when an endpoint pair was
already adjacent.  Denote the resulting plane cubic multigraph by
\(\widehat G_e\).  If \(G\) is bipartite, so is \(\widehat G_e\).

**Root-smoothing theorem.**  There is a bijection

\[
\boxed{
\begin{aligned}
 &\{M:e\in M,\ G-M=C_r\mathbin{\dot\cup}C_s,
       \ r\in C_r,\ s\in C_s\}\\
 &\hspace{30mm}\longleftrightarrow
 \{C:C\text{ is a Hamilton cycle of }\widehat G_e,
       \ a,d\in E(C)\}.
\end{aligned}}
\tag{5}
\]

Indeed, deleting \(r,s\) from the two complement cycles gives disjoint
spanning paths

\[
 P_r:r_0\leadsto r_1,
 \qquad
 P_s:s_0\leadsto s_1,
\tag{6}
\]

and \(P_r\cup P_s\cup\{a,d\}\) is Hamiltonian.  Conversely, deleting
\(a,d\) from a Hamilton cycle leaves two disjoint spanning paths.  The
alternative pairing \((r_0,s_1),(r_1,s_0)\) alternates on the boundary in
(3), and hence cannot be realized by disjoint paths in the complementary
plane disk.  The paths therefore have the pairing in (6), which restores
the two root-separated cycles.

The correspondence preserves all exchange data needed here.  If \(M,N\)
are rooted targets, then

\[
 M\mathbin\triangle N
 =E(\widehat C_M)\mathbin\triangle E(\widehat C_N),
\tag{7}
\]

because the root incidences are common and both smoothed cycles contain
\(a,d\).  Thus the number of alternating components, and in particular
single-cycle adjacency, is unchanged.  Every named gate and split-site edge
is disjoint from the root interface, and matching membership becomes
Hamilton-cycle nonmembership:

\[
 g_1\in M\Longleftrightarrow g_1\notin\widehat C_M,
 \qquad
 p,q\in M\Longleftrightarrow p,q\notin\widehat C_M.
\tag{8}
\]

Therefore gate sectors and state (11) are retained exactly.  In particular,
the ordered root separation from [Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
has not been discarded: planarity is precisely what excludes the wrong
inverse pairing.

## 3. Why ordinary Hamilton parity is too coarse

The family selected by (5) is

\[
 {\cal H}_{a,d}(\widehat G_e)
 =\{C:a,d\in E(C)\}.
\tag{9}
\]

Smith--Thomason parity counts all Hamilton cycles through one fixed edge; it
does not count the intersection in (9).  The distinction already occurs in
the actual octagonal-bipyramid split of
[Note 115](115-state-11-new-cell-fertility-is-exact-but-a-covered-endpoint-can-be-sterile.md).
Its complete rooted parent family has five targets.  By (5),

\[
 |{\cal H}_{a,d}(\widehat G_e)|=5.
\tag{10}
\]

The extra Hamilton cycles counted by single-edge parity contain exactly one
of \(a,d\); they do not invert to root-separated targets and carry no
endpoint-star classification.  State, gate sector, and one-cycle adjacency
are still finer filters, so ordinary Hamilton parity cannot imply (2).

The same Note 115 endpoint gives the exact profile

\[
 (|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^b|)=(1,1,1).
\tag{11}
\]

It rules out a fixed-point-free involution on the three sets, a bijection
\({\cal M}_\chi\leftrightarrow{\cal E}_\chi\mathbin{\dot\cup}{\cal X}^b\),
and the parity identity

\[
 |{\cal M}_\chi|\equiv
 |{\cal E}_\chi|+|{\cal X}^b|\pmod2.
\tag{12}
\]

## 4. An actual endpoint-parity counterexample

The frozen actual kill-cover family of
[Note 110](110-nonsquare-kill-cover-supplementation-holds-through-order-twenty-six-in-the-frozen-root-square-stratum.md)
contains stronger counterexamples.

The order-\(24\) hit numbered \(114\) has

\[
 (|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^b|)=(1,0,8).
\tag{13}
\]

Its exact identifiers are

```text
graph6 = W???????????w?s?P_BC?IO?L??H_?BO??w?CD??cG??P_?
root = 11-22
forced gate = 3-21
surviving gate = 5-14
site = {6-23, 7-16}
sector = 0
chi ordinal in L11 = 1
```

The parent and child are legal-wide plane bipartite braces.  The endpoint is
sterile, has one opposite-sector non-\(11\) single-cycle neighbour, and has
no same-sector parent neighbour of that kind.  Hence the actual legal class
does not satisfy

\[
 |{\cal M}_\chi|\equiv|{\cal E}_\chi|\pmod2
 \quad\text{or}\quad
 {\cal M}_\chi\hookrightarrow{\cal E}_\chi.
\tag{14}
\]

## 5. Cardinal domination and bondwise repair also fail

The same frozen family contains an order-\(24\) endpoint numbered \(29\)
with

\[
 (|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^b|)=(6,0,2).
\tag{15}
\]

Its exact identifiers are

```text
graph6 = W???????????w?s?P_BC?I_?L??J??B_?AW??F??_W?AC_?
root = 7-17
forced gate = 5-18
surviving gate = 3-13
site = {1-15, 10-22}
sector = 1
chi ordinal in L11 = 0
```

Both members of \({\cal X}^b\) have type \(X_{uy}\).  Canonically lift the
six mixed neighbours to the child and join a lift to an \(X\)-target when
their symmetric difference is one alternating cycle.  The six left degrees
are

\[
 (0,0,1,1,1,1),
\tag{16}
\]

and the maximum matching has size \(2\).  Thus this actual legal split
simultaneously disproves

\[
 |{\cal M}_\chi|\le
 |{\cal E}_\chi|+|{\cal X}^b|
\tag{17}
\]

and every repair that assigns to each mixed bond a distinct compatible
same-sector parent escape or new-cell target.  More strongly, two mixed
bonds have no compatible child target at all.  The example does not
contradict (2), because \({\cal X}^b\ne\varnothing\).

## 6. The surviving boundary

The corrected complete extraction from the already frozen Notes 110, 115,
and 116 objects still finds no counterexample to the desired nonemptiness
(2).  This is only a bounded consistency statement.  The parent and child
sets live in different Hamilton families:
\({\cal M}_\chi,{\cal E}_\chi\) are filtered neighbours of one fixed cycle
in the parent \(\widehat G_e\), whereas \({\cal X}^b\) consists of cycles
in the expanded child \(\widehat G_e^+\).  The state-\(11\) canonical lift
is inadmissible, and [Note 081](081-target-preserving-exchange-is-a-two-rooted-orbit-and-single-cycle-components-can-be-closed.md)
already permits closed components in the target-preserving single-cycle
exchange graph.  Therefore any proof that repairs each prescribed mixed
neighbour separately would have to admit non-target intermediates or
multi-cycle transitions.  [Note 125](125-a-prescribed-mixed-hamilton-overlay-need-not-contain-its-escape.md)
shows that the Boolean assertion can instead discard a bad mixed neighbour
and select a good sibling in the complete endpoint star.  Thus the present
result rules out endpoint parity, involutions, cardinal domination, and
bondwise matching, but does not force one particular replacement mechanism.

The exact status is

\[
\boxed{
\begin{gathered}
\text{root smoothing is exact;}\\
\text{endpoint parity, cardinal domination, and bondwise repair fail in
actual legal splits;}\\
\text{adjacent escape and }P_{\rm sector}\text{ remain open.}
\end{gathered}}
\tag{18}
\]

The frozen counterexamples are independently reconstructed by the
[endpoint-star counterexample bundle](../computations/bundles/endpoint-star-parity-and-pairing-counterexamples/README.md).
