> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two short flanks reduce outside one boundary branch

[Note 395](395-a-nonstandard-left-link-with-two-short-flanks-forces-a-square-reduction.md)
handles a single--double corridor with one short block on each side whenever
the first left link is nonstandard. A standard first link leaves the next
slot as a virtual left endport. Its nonstandard return can also be reduced.

Keep the block order and notation of Note 395:
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_1,\ldots,S_m,\quad D=(A,O,H,I,K,J,E,B),\quad
 T=(C,r,s,F),\qquad m\ge1.                              \tag{1}
\]
Let \(t,z\) be the even left and odd right free endports, and \(M\) the
complementary matching. All hypotheses on the selected opening and all
freedom outside this target-free group are as in Note 395.

**Two-flank boundary theorem.** Every actual matching under (1) contains
an induced disk four-pole with the exact square Hamilton signature and a
strictly smaller, two-way Barnette-preserving labeled square replacement,
unless all three boundary conditions
\[
                         tp,qo\in M,\qquad sz\notin M       \tag{2}
\]
hold. The replacement preserves all exterior- and attachment-marked
Hamilton decisions. Consequently a vertex-minimal non-Hamiltonian
Barnette graph with this selected group must satisfy (2).

**Standard links on both ends.** If \(tp,sz\in M\), use \(q\) and \(r\)
as virtual endports of the core \(V,S_1,\ldots,S_m,D\). They have the
same parity and free-slot order as the endports in
[Note 390](390-every-isolated-single-double-corridor-contains-an-exact-square-reduction.md).
A possible \(qr\) chord would match-close the proper complete interval
\(V,S_1,\ldots,S_m,D\) and give a two-edge cut. Every other complete-block
cut used by Note 390 remains a cut in the original parent. Its exhaustive
no-flank classification therefore supplies an exact square reduction.
The induced patch and its four distinct attachment edges remain
unchanged when \(S_0,T\) are present.

Suppose henceforth \(tp\in M\) but \(sz\notin M\). The virtual even
left endport \(q\) can meet only \(o,i,p_j,O,I,J,r,z\).
The chord \(qi\) traps \(o,h\): without \(oe\) they would have to
use their old-cycle edge, while with the face-side chord \(oe\)
exactly one would leave the interval, contradicting parity.
Each \(qp_j\), \(qO\), \(qr\), or \(qz\) encloses, respectively,
the complete block interval \(V,S_1,\ldots,S_{j-1}\);
\(V,S_1,\ldots,S_m\); \(V,S_1,\ldots,S_m,D\); or
\(V,S_1,\ldots,S_m,D,T\). Noninterlacement makes each
interval matching-closed, yielding a forbidden two-edge cut. Hence
\[
                           M(q)\in\{o,I,J\}.               \tag{3}
\]
If \(qJ\in M\), the four right slots \(E,r,s,z\) must
pair as \(Er,sz\): an internal mate for \(E\) would strand
three tail slots, and \(Ez\) leaves the old-cycle pair \(r,s\).
This contradicts \(sz\notin M\).

It remains to consider \(qI\in M\). The odd slot \(J\)
can meet only \(H\) via the face-side internal chord or \(s\)
through the right flank. Other cross-block chords cross \(qI\),
while \(KJ,JE\) are old-cycle edges and \(Jz\) has the wrong colour.
If \(HJ\in M\), the same tail argument as in Note 395 forces
\(OE,Kr,sz\), again contradicting \(sz\notin M\).
Thus \(Js\in M\), and noninterlacement and the forbidden
old-cycle edge \(rs\) force
\[
                              Er,Kz\in M.                  \tag{4}
\]
All internal free chords of \(D\) are now unavailable.

A chord \(oe\) would have to lie on the common-face side,
since on the opposite side it traps the old-cycle pair \(h,i\).
But every possible mate \(p_j\) or \(O\) of \(h\) gives an
opposite-side interval with exactly one face-side exit \(e\),
hence an odd number of slots still requiring internal matches.
The old-cycle neighbours \(o,i\) and parity exclude every
other mate of \(h\). Therefore \(oe\notin M\).

The odd slot \(o\) can now meet only \(q_j\) or \(H\).
Each \(oq_j\) would enclose all free slots of the complete
interval \(V,S_1,\ldots,S_j\). No chord from that interval can
cross \(oq_j\) on the opposite side, and every remaining
common-face chord stays within a block. Thus \(oq_j\) would
make this proper interval matching-closed, a two-edge cut.
Consequently
\[
                                  oH\in M.                  \tag{5}
\]
The even slot \(h\) must meet \(O\) or \(p_s\); \(hp_1\)
would trap the old-cycle pair \(i,e\), so \(s\ge2\).
If \(hO\in M\), then \(i\) must meet \(q_k\); a choice
\(k<m\) match-closes \(S_{k+1},\ldots,S_m\), forcing
\(iq_m\). The prefix cut rule and noninterlacement force
\(ep_1\) and \(q_jp_{j+1}\) for \(1\le j<m\).
If \(hp_s\in M\), the slot \(i\) must meet \(q_k\)
for \(k<s\); a choice \(k<s-1\) match-closes the
intervening short blocks, forcing \(iq_{s-1}\).
Again \(ep_1\) and \(q_jp_{j+1}\) for \(1\le j<s-1\)
are forced.

Put \(r_*=m\) in the first branch and \(r_*=s-1\)
in the second. The induced pole \(P=V\cup S_1\cup\cdots
\cup S_{r_*}\) has exactly the internal free matching
edges
\[
            ep_1,\quad iq_{r_*},\quad
            q_jp_{j+1}\ (1\le j<r_*),                       \tag{6}
\]
besides its face chords. Its four terminals
\((a,o,h,d_{r_*})\) have distinct exterior attachments:
the old-cycle edges at \(a,d_{r_*}\), \(oH\), and
\(hO\) or \(hp_s\). For \(r_*=1\), this is the
old-cycle reflection of [Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md).
For \(r_*>1\), compress the short-block ladder to one
square using [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
and apply that reflected fold. The exact signature and
two-way Barnette comparison are the same as in the final
paragraph of [Note 392](392-every-one-left-flank-tj-single-double-corridor-has-an-exact-square-reduction.md).
This completes the \(qI\) branch. Combining it with
Note 395 and the standard-link case proves the theorem.
\(\square\)

**The surviving right end.** Under (2), the odd slot \(z\)
can meet only \(h,H,K,s\). Its mates \(e,q_j\) would enclose
a nonempty suffix of complete blocks through \(T\),
giving a two-edge cut; \(Ez\) traps \(r,s\), whose edge
belongs to the old cycle. The mate \(s\) is excluded by
(2). The mate \(H\) is also impossible: \(Hz\) forces
\(Js\), since \(J\)'s other mates are used, forbidden
old-cycle neighbours or cross \(Hz\). Then \(Er\) is
forced inside \(Js\). The slot \(I\) has no remaining
mate: \(IH,IK\) are old-cycle edges, \(IE\) uses the
already matched \(E\), and any opposite-side return
to an earlier block crosses \(Hz\). Thus the still
unresolved boundary is precisely
\[
                         tp,qo\in M,\quad
                         sz\notin M,\quad M(z)\in\{h,K\}.  \tag{7}
\]
This is a necessary description, not an assertion that
both right returns occur.

**The \(zK\) return has a spanning route.** Suppose \(Kz\in M\)
under (2). The four slots inside this opposite-side chord are
\(J,E,r,s\). The chord \(HJ\) would leave one of the two slots
\(r,s\) unmatched, while \(KJ,JE,rs\) are old-cycle edges.
Thus \(Js,Er\in M\); in particular all internal free chords of
\(D\) are absent. The remaining free slots are
\[
             h,i,e,(p_j,q_j)_{j=1}^m,O,H,I.                \tag{8}
\]
The slot \(h\) cannot meet \(O\). Indeed, \(hO\) would separate
the still-free \(H,I\) from every earlier available slot on
the opposite side; \(HI\) is an old-cycle edge, and their
face-side chords \(HJ,IE\) use already matched \(J,E\).
Its other legal mates are \(I\) or \(p_s\), with \(s\ge2\);
\(hp_1\) traps the old-cycle pair \(i,e\).

The matching of (8) is therefore exactly one of the
\(hI\) words \(M_{m,r}^{\circ}\setminus\{oK\}\)
(\(1\le r\le m\)) of
[Note 383](383-the-hi-return-single-double-corridor-is-an-exact-square-reduction.md),
or one of the \(hp_s\) words
\(M_{m;s,r}^{\circ}\setminus\{oK\}\)
(\(2\le s\le r\le m-1\)) of
[Note 384](384-delayed-single-double-return-has-two-cutpoints-and-a-marked-route.md).
Their classifications use only noninterlacement and complete-block
two-edge-cut exclusions among the slots (8). No slot in (8) can
now match outside (8): \(t,p,q,o,K,J,E,r,s,z\) are already used,
and no cross-block chord lies on the common-face side. Hence
those proofs apply verbatim. The lists are upper bounds on
actual words here; this argument does not assert that every
listed word occurs with the two flanks.

For the \(hI\) words with \(r<m\), Note 383, equation (9),
gives a spanning \(J\)--\(E\) path of
\(V,S_1,\ldots,S_m,D\) that begins \(J,K,o\).
For the \(hp_s\) words, Note 384, equation (9), gives
the same endpoint and prefix. The remaining standard
\(hI\) word \(r=m\) has such a path too: for \(m=1\), it is
\[
 J,K,o,a,b,c_1,p_1,e,i,h,I,H,O,q_1,d_1,A,B,E.           \tag{9}
\]
Its restriction to \(S_1\) uses the two disjoint paths
\(c_1p_1\) and \(q_1d_1\). Note 178 lifts exactly this
four-attachment routing to the ordinary-link ladder
\(S_1\cup\cdots\cup S_m\), without changing the displayed
prefix or the final \(E\).

In all cases, delete the path's initial \(J,K\),
start instead at \(o\), and extend its final \(E\) by
\(r,C,F,s,J,K\); the new final segment is
\[
                            E,r,C,F,s,J,K.                \tag{10}
\]
Every consecutive edge in this segment is,
respectively, \(Er\), an old-cycle edge, the face chord
\(CF\), an old-cycle edge, \(sJ\), or an old-cycle edge.
The resulting path covers \(V,S_1,\ldots,S_m,D,T\)
exactly once from \(o\) to \(K\). Prepend
\(t,p,c,d,q\) and its edge \(qo\), then append \(Kz\).
The result is a spanning \(t\)--\(z\) path through the
entire group, including both outer short blocks.
If every other free group has the standard composable
route of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md),
its group template gives a parent Hamilton cycle through
both site edges, and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in the legal site-expanded child.

**Three surviving mates of \(s\) in the \(zh\) return.**
Suppose instead \(hz\in M\) under (2). Since \(tp,qo,hz\)
are used, colour and the old-cycle edge \(rs\) restrict
the even slot \(s\) to
\[
                         M(s)\in\{i,p_j,O,I,J\}.          \tag{11}
\]
The option \(sO\) is impossible. Its opposite-side chord
encloses \(H,I,K,J,E,r\). The odd slot \(J\) can meet
neither \(K,E\), its old-cycle neighbours, nor \(r\) of
the same colour; a return to an earlier block crosses
\(Os\). Thus \(HJ\) is forced on the face side.
The isolation lemma of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes \(IE\). Now \(I\) has no mate: \(IH,IK\) are
old-cycle edges, \(s\) and \(J\) are used, and every
opposite-side return before \(O\) crosses \(Os\).

If \(sI\in M\), the same argument forces the face-side
chord \(HJ\). Inside \(Is\) are \(K,J,E,r\), of which
\(J\) exits through \(HJ\). The other three slots
need one more face-side exit. The isolation lemma
excludes \(OK\), and \(IE\) uses the already matched
\(I\); hence the only possible exit is \(OE\).
Then \(Kr\) is forced. Thus \(D\) has the rainbow
pair \(OE,HJ\) and is the exact square reduction of
Note 325.

If \(sJ\in M\), its two enclosed slots \(E,r\)
must pair as \(Er\). Every internal free chord of
\(D\) is then unavailable except possibly \(OK\).
Were \(OK\) present, Note 327 places it on the
common-face side. The even slot \(H\) could meet
only \(i\) or some \(p_j\) by an opposite-side
chord: \(h,o,p,J,E,r,z\) are used and \(HO,HI\)
are old-cycle edges. Each such chord encloses
exactly one endpoint \(O\) of the face-side
\(OK\), leaving an odd number of slots to pair
internally. No other face-side free chord can
provide a second exit. Therefore \(OK\) is
impossible, and \(D\) has no internal free
matching chord in the \(sJ\) branch. In particular,
after the rainbow reduction, an unresolved \(zh\)
matching must have \(M(s)=i,p_j\), or \(J\);
the \(sJ\) branch has no internal double-block
free chord.

The last-short return \(p_ms\) also forces the
rainbow reduction. Its opposite-side chord encloses
\(q_m,O,H,I,K,J,E,r\). The even slot \(q_m\) can
meet only \(O,I,J,r\). If \(q_mr\) occurs, the
complete block \(D\) is matching-closed and gives
a two-edge cut. If \(q_mO\) occurs, \(J\) is forced
to \(H\) by the face-side chord \(HJ\), after
which \(I\)'s only remaining candidate \(IE\)
is excluded by the chord-isolation lemma. If
\(q_mJ\) occurs, the four slots \(O,H,I,K\)
inside that chord cannot pair: their old-cycle
neighbours are forbidden, \(OK\) leaves the
old-cycle pair \(H,I\), and at most one of
\(OE,IE\) can provide a face-side exit because
they share \(E\). Hence \(q_mI\) is necessary.
Its interval contains \(O,H\), whose old-cycle
edge is forbidden. Both must exit on the face
side: \(H\) by \(HJ\), and \(O\) by \(OE\) or
\(OK\). The isolation lemma excludes \(OK\)
with \(HJ\), so \(OE,HJ\in M\). Thus a
non-rainbow \(zh\) matching has \(M(s)=i,J\),
or \(p_j\) with \(j<m\).

The theorem concerns only the specified compact all-square
opening and single--double group. The \(zK\) path
does not by itself give the whole pole's six Hamilton
states; the \(zh\) return is only partly classified above.
Longer flanks, other
vacancy groups, other opening types, and Barnette's
conjecture remain outside this theorem. The proof is
project-internal and has not had independent external
review or a complete literature priority comparison.
