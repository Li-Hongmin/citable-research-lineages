> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A sole double vacancy cannot carry J2 without J0

[Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
proves marked Hamiltonicity when a free group has one
doubly vacant target-free block and otherwise only
short target-free blocks, with arbitrarily long short
flanks. Its proof lists a \(J_2\)-only matching as
a candidate and supplies a path for it. The
candidate is incompatible with the required
two-page plane embedding.

Use Note 227's compressed, gapless, tight-target
all-square selected opening with precisely two
eligible vacancies in total. Let the only vacant
block of their ordinary target-free free group be
\[
                    D=(a,o,h_1,i_1,h_2,i_2,e,b),
\]
with any number of short blocks on either side.
Write its four possible internal free chords as
\[
J_0=oe,\quad J_1=oh_2,\quad
J_2=h_1i_2,\quad J_3=i_1e.
\]

**Sole-double chord theorem.** In every actual
complementary matching of this group,
\[
                         J_2\in M\quad\Longleftrightarrow\quad J_0\in M.
\]
Whenever either occurs, \(D\) is the exact
four-terminal square pole of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md)
and can be removed independently of all matching
choices outside it. In particular, the \(J_2\)-only
branch in Note 227's proof is empty; its
Hamiltonicity theorem remains valid.

**Proof.** Note 227 already proves
\(J_0\in M\Rightarrow J_2\in M\).
Suppose conversely that \(J_2\in M\) and
\(J_0\notin M\). The local chord-isolation
lemma of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
excludes \(J_1,J_3\): either of those chords
would exclude \(J_2\) independently of other
vacancies. Thus the only internal free matching
edge of \(D\) is \(h_1i_2\), leaving \(i_1,h_2\)
to match ordinary ports outside their old-cycle
pair.

Note 227's ordinary-edge rule says that every
matching edge with two ordinary endpoints is a
standard chain link \(P_s=(E_s,O_s)\), since
the sole exception \(oe=J_0\) is absent.
Exactly one standard link is missing: its
two endpoints must match the two free extra
slots. Bipartite colours force
\[
                         E_si_1,\qquad O_sh_2.   \tag{1}
\]
The pair \(P_s\) lies wholly before or wholly
after \(i_1,h_2\) in old-cycle order. If it is
the link immediately before \(D\), then
\(O_s=o\) and \(O_sh_2=J_1\), already excluded.
If it is the link immediately after \(D\),
then \(E_s=e\) and \(E_si_1=J_3\), likewise
excluded. Therefore both edges in (1) join
different blocks and lie on the side opposite
the designated common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).

If \(P_s\) precedes \(D\), the endpoint order is
\[
                         E_s<O_s<i_1<h_2.
\]
If it follows \(D\), the order is
\[
                         i_1<h_2<E_s<O_s.
\]
In either order the two pairs in (1) alternate
around the old Hamilton cycle. Their chords
therefore cross on their common opposite-side
page, contrary to planarity. This excludes
\(J_2\in M,J_0\notin M\) and proves the
equivalence. With both chords present, the
rainbow reduction is precisely Note 325's
\(q=2\) case. \(\square\)

The result sharpens the matching classification
in Note 227 but does not broaden its Hamilton
conclusion. It does not apply when another
vacancy-bearing block shares the free group.
[Note 378](378-isolated-single-double-group-couples-j0-and-j2.md)
independently proves the same chord equivalence
when exactly one adjacent singly vacant block
joins \(D\), with no short blocks. Other opening
types and Barnette's conjecture remain unresolved.
The proof is project-internal and has not had
independent review.
