> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cross traversals are exactly quotient-tree connectors

Let \(G\) be a connected cubic bipartite graph and let

\[
p=uv,\qquad q=xy
\]

be a directed legal \(C_4\)-expansion site, so \(u,x\) lie in one
bipartition class and \(v,y\) in the other.  Put

\[
R=G-\{p,q\}.
\]

This note gives an exact alternating-exchange criterion for the cross
traversals \(D=X_{vx}\) and \(E=X_{uy}\).  It also separates the part forced
by regular bipartite connectivity from the genuine missing condition.

## The quotient-tree criterion

Let \(M_B\) be the complementary perfect matching of a state-\(B=10\)
Hamilton cycle.  Thus

\[
q\in M_B,\qquad p\notin M_B,
\qquad K_B:=G-M_B\text{ is a Hamilton cycle}.
\tag{1}
\]

A \(D=X_{vx}\) traversal is equivalent to a matching \(N\) exposing
exactly \(u,y\) for which \(R-N\) is connected.  For any such near-perfect
matching, the symmetric difference

\[
W=M_B\mathbin\triangle N
\tag{2}
\]

is the disjoint union of one \(M_B\)-alternating \(u\)-\(y\) path, starting
and ending with matching edges, and zero or more alternating cycles.  The
converse also holds: toggling on any union of this form exposes exactly
\(u,y\).

Define

\[
S=(W\cap K_B)\cup\{p\},\qquad
A=(W\cap M_B)\setminus\{q\}.
\tag{3}
\]

Cut \(K_B\) at every edge of \(S\).  Contract each resulting path component
to one vertex, and retain the edges of \(A\), including loops and parallel
edges.  Denote the resulting multigraph by \(\Gamma_B(W)\).

### Theorem 1

The following are equivalent:

1. \(N=M_B\triangle W\) is the complementary matching of a
   \(D=X_{vx}\) traversal;
2. \(R-N\) is connected;
3. \(\Gamma_B(W)\) is a tree.

Indeed,

\[
R-N=(K_B-S)\cup A.
\tag{4}
\]

Contracting the path components of \(K_B-S\) turns (4) precisely into
\(\Gamma_B(W)\), proving the connectivity equivalence.  On the open
alternating path, \(W\cap M_B\) has one more edge than \(W\cap K_B\);
every alternating cycle contributes equally many of each kind.  Removing
the terminal matching edge \(q\) from \(A\) therefore gives

\[
|A|=|W\cap K_B|,
\qquad
|V(\Gamma_B(W))|=|S|=|A|+1.
\tag{5}
\]

A connected multigraph with one fewer edge than vertices is a tree.  When
(4) is connected, its degree profile makes it a spanning \(v\)-\(x\) path.
Consequently

\[
\boxed{
D\text{ exists}
\iff
\text{some exchange union }W\text{ has }\Gamma_B(W)\text{ a tree}.}
\tag{6}
\]

Interchanging \(p,q\) and exposing \(v,x\) gives the reflected criterion
for \(E=X_{uy}\) from any state-\(C=01\) Hamilton matching \(M_C\).

## Alternating reachability is automatic

Let \(M\) be a perfect matching of a connected \(d\)-regular bipartite
graph.  Write its matched pairs as \(a_i b_i\), with \(a_i\in A\) and
\(b_i\in B\).  Form a digraph \(D_M\) on the matching pairs by adding

\[
i\longrightarrow j
\quad\text{for every nonmatching edge }b_i a_j.
\tag{7}
\]

### Theorem 2

The digraph \(D_M\) is strongly connected.

If not, take a nonempty proper sink set \(I\) in its condensation.  There
is no edge from \(B_I\) to \(A\setminus A_I\).  Let \(e_I\) count the
nonmatching edges between \(A_I\) and \(B_I\).  Degree counting on the two
sides gives

\[
d|I|=|I|+e_I,
\qquad
d|I|=|I|+e_I+|E(A_I,B\setminus B_I)|.
\tag{8}
\]

The remaining boundary is therefore empty as well, contradicting
connectedness of the original graph.

A simple directed path in \(D_{M_B}\) from the pair containing \(u\) to
the pair \(xy\) lifts to a simple \(M_B\)-alternating \(u\)-\(y\) path
starting and ending with matching edges.  The reflected construction works
for \(M_C\).  Hence a state-\(B/C\) Hamilton matching always supplies a
proper alternating connector.  Neither planarity nor 3-connectivity is
needed for this existence statement.

The missing conclusion is not reachability but the global acyclicity of
the quotient in Theorem 1.

## The tree condition is strict

Use the cube with edge set

\[
\{01,03,04,12,17,23,26,35,45,47,56,67\}
\]

and legal site

\[
(u,v,x,y)=(0,1,7,4),\qquad p=01,\quad q=47.
\tag{9}
\]

Its unique state-\(B\) Hamilton matching is

\[
M_B=\{03,12,47,56\}.
\tag{10}
\]

The proper alternating connector

\[
P=0-3-2-1-7-4
\tag{11}
\]

genuinely couples the two distinguished alternating defects.  Nevertheless

\[
N=M_B\triangle E(P)=\{17,23,56\}
\]

leaves

\[
R-N=(0-3-5-4-0)\ \dot\cup\ (1-2-6-7).
\tag{12}
\]

Thus \(\Gamma_B(E(P))\) is disconnected: the desired spanning-path
component is accompanied by a residual \(C_4\).  Another connector,

\[
0-3-5-6-2-1-7-4,
\tag{13}
\]

does have a tree quotient.  The cube therefore satisfies \(D\), but proves
that Menger, ear decomposition, or alternating reachability alone cannot
establish it.  A positive theorem must select a connector, together with
optional alternating-cycle flips, so that all cut intervals of the
Hamilton cycle are joined into one tree.

## Remaining boundary

For the global \(H^{+-}\)-preservation problem of Notes 015--016, the
cross-path part is now reduced exactly to

\[
\boxed{
\begin{gathered}
G\text{ plane, simple, cubic, bipartite and 3-connected},\\
M_B\text{ a state-}B\text{ Hamilton matching}
\end{gathered}
\Longrightarrow
\exists W:\Gamma_B(W)\text{ is a tree}?}
\tag{14}
\]

and its reflection for \(M_C\).  The cube, the hexagonal prism and a fixed
14-vertex Barnette graph all satisfy the stronger path-only form, but these
instances do not prove (14).  A counterexample to a selected connector is
also insufficient; refuting (14) requires every admissible exchange union
to leave a disconnected quotient.

The finite certificate is

```text
uv run --python 3.12 --with networkx python \
  units/barnette/scratch/worker-c4-hpm/verify_proper_alternating_connector.py
```

with terminal marker

```text
PROPER_ALTERNATING_CONNECTOR_VERIFIED
```
