> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Staggered vacancy chains have the square Hamilton signature

[Note 329](329-one-other-vacancy-forces-the-staggered-j1-square-patch.md)
forces the fourteen-vertex square patch when a free group has just
one singly vacant block besides a doubly vacant block carrying
\(J_1=OK\). More singly vacant blocks change the matching at the
other free slot of the double block. The following two results give
the part that remains forced and an unbounded reducible family.

Work in a compressed, gapless, tight-target all-square opening of
a Barnette parent as in [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix a target-free free group with ordinary even left and odd right
endports. One complete block is
\(D=(A,O,H,I,K,J,E,B)\), with two vacancies \((H,I),(K,J)\)
and \(OK=J_1\) in the complementary matching. Every other
complete block of the group is either a short block
\((a,o,e,b)\) or a singly vacant block
\((a,o,h,i,e,b)\). There may be arbitrarily many of either kind.

**Immediate-predecessor theorem.** The block immediately before
\(D\) is singly vacant. Writing it as
\(V=(a,o,h,i,e,b)\), its matching contains
\[
                         oe,\qquad iH.                 \tag{1}
\]
The slot \(I\) matches the \(h'\)-slot of some singly vacant
block \(V'=(a',o',h',i',e',b')\) in this group, and
\(o'e'\) also belongs to the matching. These conclusions are
independent of all matching choices farther left or right.
If \(Ih\) occurs at the immediate predecessor, the induced
two-block patch is already Note 327's square-equivalent patch.

**Proof.** By Note 327's chord-isolation lemma, \(OK\) is on
the common-face side and is the only internal free chord of
\(D\). In any singly vacant block the sole possible internal
free chord is \(oe\), and, if present, lies on the common-face
side. Every cross-block free chord lies on the opposite side
by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
An opposite-side chord encloses an even number of free slots
after one removes the endpoints of common-face chords leaving
its interval. A proper consecutive interval of complete blocks
closed under the matching would have only its two boundary
old-cycle edges leaving it, contrary to three-connectivity.

The even slot \(H\) has no mate in \(D\): \(I\) is its
old-cycle neighbour, \(J\) is excluded by chord isolation,
\(O,K\) are used, and \(E\) has the same colour. It cannot
match the even left endport. If it matches an ordinary odd
slot of a short block before \(D\), its chord encloses that
block's final even slot, complete blocks with even free-slot
counts, and \(O\). If the ordinary odd slot is after \(D\),
the chord encloses \(I,K,J,E\) and complete blocks. The right
endport obeys this latter count. In each case the interior
count is even, while \(OK\) has exactly one end inside;
every possible \(oe\) chord is wholly inside or outside.
Parity excludes all these mates.

For a singly vacant block \(V'=(a',o',h',i',e',b')\)
before \(D\), the chord \(o'H\) encloses \(h',i',e'\),
complete blocks, and \(O\). Its even interior has the one
exit from \(OK\); \(o'e'\) is unavailable because \(o'\)
is used. If \(V'\) follows \(D\), \(Ho'\) encloses
\(I,K,J,E\) and complete blocks, with the same single exit.
Thus \(H\) can only match an \(i'\) of a singly vacant block.

If \(V'\) precedes \(D\), the chord \(i'H\) encloses \(e'\),
an even number of slots from complete intermediate blocks,
and \(O\). Its even interior has one exit through \(OK\);
therefore \(o'e'\) must supply the second exit. Apart from
\(e',O\), whose mates lie across the interval boundary, every
free slot inside \(i'H\) must match another inside slot.
Cross-block matching edges cannot cross \(i'H\), and any
same-block \(oe\) lies wholly within an intermediate block.
Consequently all complete blocks strictly between \(V'\)
and \(D\) are matching-closed as a set. If any exist, they
form a forbidden two-edge cut. Hence \(V'\) immediately
precedes \(D\), and (1) holds.

If \(V'\) follows \(D\), the chord \(Hi'\) encloses
\(I,K,J,E\), complete intermediate blocks, and \(o',h'\).
Parity again requires \(o'e'\), this time with \(o'\) as its
inside end. The \(OK\) and \(o'e'\) chords have their mates
within the full block interval from \(D\) through \(V'\).
All other interior slots must match inside \(Hi'\), and
\(H,i'\) match one another. Thus the full interval of
complete blocks from \(D\) to \(V'\) is matching-closed,
another forbidden two-edge cut. There is no remaining mate
for \(H\).

For the assertion about \(I\), its internal candidates are
unavailable: \(H,K\) are old-cycle neighbours, \(IE\) is
excluded by chord isolation, \(O\) is used, and \(J\) has the
same colour. A left ordinary even slot, including the left
endport, gives an opposite-side chord enclosing complete blocks
and \(O,H\); a right ordinary final even slot encloses
\(K,J,E\), complete blocks, and the first odd slot of its
own block. Each interior has even size and the single exit
from \(OK\). If the candidate is the final slot \(e'\) of
a singly vacant block, its own \(o'e'\) is unavailable;
the extra \(h',i'\) make the same counts even, so parity
again excludes it. The only remaining even candidates are
\(h'\)-slots. For \(h'\) before \(D\), the interval to
\(I\) contains \(i',e'\), complete blocks, and \(O,H\);
for \(h'\) after \(D\), it contains \(K,J,E\), complete
blocks, and \(o'\). Both have even size with the one
\(OK\) exit. In either case \(o'e'\) is the only possible
second common-face exit, so it is forced. This finishes
the theorem. \(\square\)

The theorem leaves room for \(I\) to match the \(h\)-slot
of an earlier singly vacant block. An exact family realizes
that possibility. For each \(q\ge1\), take \(q\) consecutive
singly vacant blocks
\[
V_j=(a_j,o_j,h_j,i_j,e_j,b_j),\qquad 0\le j<q,
\]
followed immediately by \(D\). Define the induced patch
\(P_q\) on these \(6q+8\) vertices by the full old-cycle
path in their displayed block order, the face chords
\(a_jb_j,AB\), and the free matching edges
\[
o_je_j\ (0\le j<q),\qquad OK,\qquad
h_0I,\qquad i_jh_{j+1}\ (0\le j<q-1),\qquad
i_{q-1}H.                                               \tag{2}
\]
Its only degree-two vertices are \(a_0,J,E,B\), in that
cyclic terminal order. For \(q=1\), this is precisely the
patch of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md).

**Forced left-chain theorem.** Under the opening hypotheses
above, if \(I\) matches an \(h_0\)-slot in a singly vacant
block \(V_0\) before \(D\), then all complete blocks from
\(V_0\) through the immediate predecessor of \(D\) are
consecutive singly vacant blocks. Their free-slot matching
edges are exactly (2), in addition to the face-closing
chords. Hence their
induced union is \(P_q\) for some \(q\ge1\), irrespective
of all blocks and matching edges outside this interval.

**Proof.** The preceding theorem gives \(o_0e_0\) and
\(h_0I\). It also gives \(i_{q-1}H\) and
\(o_{q-1}e_{q-1}\) at the immediate predecessor, whose
index is only provisional at this point. The opposite-side
chord \(h_0I\) encloses every intervening block. Starting
at \(V_0\), suppose \(V_j\) and its \(o_je_j\) chord have
been reached, and \(i_j\) is not already paired with \(H\).
The slot \(i_j\) must match inside \(h_0I\): any cross-block
chord leaving it would cross that chord, while its same-block
old-cycle neighbours cannot be matching edges. All earlier
available even slots inside \(h_0I\) are used by the chords
already found. The slot \(H\) is used by the immediate
predecessor; \(O\) is used by \(OK\).

If \(i_j\) matched the final even slot of a later short
block, its chord would enclose \(e_j\), complete blocks,
and that short block's first odd slot. If it matched the
final even slot \(e_s\) of a later singly vacant block,
the chord would instead enclose \(e_j\), complete blocks,
and \(o_s,h_s,i_s\). Both interiors have even size;
\(o_je_j\) has exactly one end inside, whereas \(o_se_s\)
is unavailable in the second case. Thus parity excludes
both final-slot types. For a mate \(h_s\) of a later
singly vacant block, the interval contains \(e_j\),
complete blocks, and \(o_s\). Parity forces \(o_se_s\)
as its second common-face exit. All complete blocks
strictly between \(V_j\) and \(V_s\) would then be
matching-closed: their slots are inside \(i_jh_s\),
while \(e_j,o_s\) are already matched across its boundary.
Three-connectivity rules out a nonempty such interval.
Therefore \(V_s\) is the immediately next block,
\(i_jh_s,o_se_s\) are forced, and that block is singly
vacant. Repeating reaches the block immediately before
\(D\), where \(i_{q-1}H\) closes the chain. Every inner
vertex now has its third edge in (2); the only external
attachments are \(a_0,J,E,B\). \(\square\)

**Staggered-chain reduction theorem.** For every \(q\ge1\),
\(P_q\) and a square with corresponding labeled terminals
\((a_0,J,E,B)\) have identical complete spanning one-path
and two-path Hamilton linkage signatures. Replacing an induced
\(P_q\) in a cubic graph with nonempty exterior by this square,
or conversely, preserves every exterior-marked Hamilton
decision. It preserves membership in the Barnette class in
both directions. Every \(P_q\) occurs in an explicitly
Hamiltonian Barnette parent, so the family has unbounded size.
In particular, no vertex-minimal non-Hamiltonian Barnette graph
contains one of these induced patches.

**Proof of the signature.** The path order and (2) give a
two-page disk drawing: the face chords and \(o_je_j,OK\)
are disjoint or nested on one side, while \(h_0I\) contains
the mutually disjoint \(i_jh_{j+1}\) and \(i_{q-1}H\)
on the other. The terminal colours are \(a_0,E\) on one
side and \(J,B\) on the other. Thus the only possible
spanning one-path terminal pairs are \(a_0B,a_0J,JE,EB\).
All four occur. For \(a_0B\), take the full old-cycle
path through \(P_q\). For the other three, put
\[
F=(a_0,b_0,e_0,o_0,h_0,i_0),\quad
W=(h_0,o_0,a_0,b_0,e_0,i_0),\quad
U_j=(h_j,o_j,a_j,b_j,e_j,i_j)\quad(1\le j<q).
\]
Then the following concatenations each visit every patch
vertex exactly once:
\[
\begin{array}{c|l}
a_0J & F,U_1,\ldots,U_{q-1},H,I,K,O,A,B,E,J\\
JE   & J,K,I,W,U_1,\ldots,U_{q-1},H,O,A,B,E\\
EB   & E,J,K,I,W,U_1,\ldots,U_{q-1},H,O,A,B.
\end{array}                                                \tag{3}
\]
For example, the joins between successive \(U_j\)'s are
exactly \(i_jh_{j+1}\); the first and last joins are
\(h_0I\) or \(i_0h_1\), and \(i_{q-1}H\), respectively.

There are exactly two noninterlacing two-path terminal
pairings. For \(\{a_0J,EB\}\), use the old-cycle path
from \(a_0\) through \(J\), together with the edge \(EB\).
For \(\{a_0B,JE\}\), use the edge \(JE\) and the path
\[
\begin{split}
&a_0,o_0,e_0,b_0,\ldots,
  a_{q-2},o_{q-2},e_{q-2},b_{q-2},
  a_{q-1},o_{q-1},h_{q-1},\\
&i_{q-2},h_{q-2},i_{q-3},h_{q-3},\ldots,i_0,h_0,
  I,K,O,H,i_{q-1},e_{q-1},b_{q-1},A,B.
\end{split}                                                 \tag{4}
\]
For \(q=1\), both the first repeated segment and the reverse
zigzag in (4) are empty. The interlacing pairing
\(\{a_0E,JB\}\) is impossible in the disk. Equations
(3)--(4) are exactly the square's four single-path pairs
and two double-path pairings. Any Hamilton cycle of an
ambient graph uses two or four of the patch's four external
edges; replacing its spanning patch paths by the corresponding
square paths, or conversely, leaves the exterior unchanged.

**A Barnette realization for every \(q\).** Give an old
Hamilton cycle \(C_q\) the order
\[
x,R_1,c,y,V_0,V_1,\ldots,V_{q-1},D,
u,o_3,L_1,v,\alpha,\gamma,\delta,\beta,x,              \tag{5}
\]
where a block symbol means its displayed full vertex order.
Add the complementary perfect matching
\[
\begin{split}
M_q=\{&xy,uv,\alpha\beta,cJ,Eo_3,
\delta R_1,\gamma L_1,AB,OK,\\
&a_jb_j,o_je_j\ (0\le j<q),
h_0I,
i_jh_{j+1}\ (0\le j<q-1),i_{q-1}H\}.
\end{split}                                                 \tag{6}
\]
Every edge in (6) joins opposite parities of \(C_q\),
and none duplicates an old-cycle edge. On the common-face
side, \(xy,a_jb_j,AB,uv,\alpha\beta\) are disjoint outer
chords, each \(o_je_j\) lies inside its face-block chord,
and \(OK\) lies inside \(AB\). The other chords are
noncrossing on the opposite side: \(\delta R_1\) encloses
the others, \(cJ\) contains \(h_0I\), which contains
the disjoint \(i_jh_{j+1}\) and \(i_{q-1}H\); \(Eo_3\)
and \(\gamma L_1\) lie to the right of \(cJ\).
Thus (5)--(6) define a simple cubic bipartite plane graph.

The interlacement graph of matching chords is connected.
For \(q\ge2\), a spanning chain and its remaining branches are
\[
\begin{gathered}
xy-cJ-AB-h_0I-a_0b_0-i_0h_1-a_1b_1-\cdots-
i_{q-2}h_{q-1}-a_{q-1}b_{q-1}-i_{q-1}H-o_{q-1}e_{q-1},\\
i_jh_{j+1}-o_je_j\quad(0\le j<q-1),\qquad h_0I-OK,\\
AB-Eo_3-uv-\gamma L_1-\alpha\beta-\delta R_1.
\end{gathered}                                               \tag{7}
\]
Each dash means alternation of chord endpoints in (5).
For \(q=1\), omit the \(i_jh_{j+1}\) terms and use
\(a_0b_0-i_0H-o_0e_0\); the other branches remain.
A two-edge cut in a cubic Hamiltonian graph would isolate
a proper old-cycle interval closed under the complementary
matching, separating its interlacement graph. Hence (7)
excludes two-edge cuts. A cubic Hamiltonian graph has no
bridge, and a cubic graph with neither one- nor two-edge
cuts is three-vertex-connected. This proves the Barnette
claim. It also supplies two internally disjoint \(x\)--\(v\)
paths covering the graph:
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,c,J,K,I,
 (h_0,o_0,a_0,b_0,e_0,i_0),\ldots,
 (h_{q-1},o_{q-1},a_{q-1},b_{q-1},e_{q-1},i_{q-1}),
 H,O,A,B,E,o_3,u,v.
\end{split}                                                 \tag{8}
\]
The second path uses both site edges \(xy,uv\).

**Proof of Barnette preservation.** The terminal colours
agree with those of the square, so bipartiteness transfers.
Contract the connected old-cycle path in \(P_q\) from
\(a_0\) through \(K\) to one vertex and retain \(J,E,B\).
The edges \(KJ,JE,EB,AB\) yield the labeled square after
deleting surplus edges. Thus the square replacement is a
planar minor. Conversely, the disk drawing above inserts
\(P_q\) on the empty side of a square whose exterior is
connected, so planarity transfers back.

Deleting any one vertex leaves \(P_q\) connected. Each
individual block cycle remains connected after such a
deletion, and each consecutive pair of block cycles has
two vertex-disjoint joining edges: \(b_ja_{j+1}\) and
\(i_jh_{j+1}\), or \(b_{q-1}A\) and \(i_{q-1}H\).
For \(q=1\), these latter two joins suffice as well.
Moreover, after deleting any two vertices from \(P_q\),
each surviving component contains a surviving terminal.
Otherwise that component would be disconnected from the
rest of the three-connected realization (5)--(6), since
its only edges to the exterior are at \(a_0,J,E,B\).

In either ambient Barnette graph, the exterior of the
four-pole is connected: two exterior components would
each need at least three of the four attachment edges.
After two patch vertices are deleted, the preceding
component property connects the surviving patch through
that exterior. After one patch vertex and one exterior
vertex are deleted, the patch stays connected; compare
with deletion of the corresponding square terminal, if
the patch vertex is a terminal, and the same exterior
vertex in the other ambient graph. Three-connectivity
there ensures that each surviving exterior component
has an attachment at a surviving terminal. With only
exterior deletions, the intact connected patch similarly
joins all surviving exterior components. For the square,
the same statements follow immediately from its cycle.
Thus replacement preserves three-connectivity in both
directions. Simplicity and cubicity follow from the four
distinct degree-two terminals and their four labeled
external edges. \(\square\)

**Marked-opening consequence.** If an opening contains
an induced \(P_q\) as consecutive target-free blocks, its
old-cycle segment and the common-face block arc compress
to one short target-free square. The two external matching
edges at \(J,E\) keep their cyclic order on the opposite
side. If every vacancy outside \(P_q\) lies in a distinct
internal block, Note 324 gives a Hamilton parent cycle
through both site edges after compression. The exact
signature lifts it to the original parent, and
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives a Hamilton cycle in its legal site-expanded child.
Reflection gives the analogous chain ending in a \(J_3\)
double block with reversed block order.

Under the immediate-predecessor and forced left-chain
theorems, the only other possible orientation has \(I\)
matched to \(h'\) in a singly vacant block strictly after
\(D\), with \(o'e'\) present. At least one complete block
must lie between \(D\) and that block. Otherwise the chord
\(Ih'\) traps \(K,J,E,o'\); the first and last slots
are matched across its boundary by \(OK,o'e'\), leaving
\(J,E\) to match each other. Their edge is on the old
cycle and cannot belong to the complementary matching.

**Two-single-block corollary.** If this free group contains
at most two singly vacant blocks in total, every occurrence
of \(J_1\) contains an induced \(P_1\) or \(P_2\). In
particular, the right-oriented \(Ih'\) corridor is impossible
under this count, regardless of all short-block flanks.

**Proof.** The immediate-predecessor theorem supplies one
singly vacant block \(V_L\) to the left of \(D\). If \(I\)
also matches left, the forced left-chain theorem gives
\(P_1\) or \(P_2\). Otherwise its mate lies in the only
other singly vacant block \(V_R\) to the right of \(D\).
Write their free slots as \(o_L,h_L,i_L,e_L\) and
\(o_R,h_R,i_R,e_R\). The edges \(o_Le_L,i_LH,OK,Ih_R,o_Re_R\)
are fixed. Every slot between \(I\) and \(h_R\), except
\(K,o_R\), matches inside that opposite-side chord;
\(K,o_R\) match \(O,e_R\), respectively. Thus all free
slots in the complete block interval from \(V_L\) through
\(V_R\) are matched inside it except \(h_L,i_R\).

The even slot \(h_L\) cannot match an ordinary odd slot
of a short block before \(V_L\): its chord encloses that
block's final even slot, complete short blocks, and
\(o_L\), while \(o_Le_L\) supplies the sole face-side
exit from an even interior. It cannot match a short-block
odd slot strictly between \(D\) and \(V_R\), since that
chord would interlace \(Ih_R\) on the opposite side.
A short-block odd slot after \(V_R\), or the right odd
endport, gives an even interior containing \(i_L,e_L\),
all six free slots of \(D\), and complete intervening
blocks; again \(o_Le_L\) is its only face-side exit.
The slot \(J\) lies inside \(Ih_R\), so \(h_LJ\) would
interlace it; \(O,I,i_L,o_L,o_R\) are already used,
and the left endport has even colour. No other odd free
slot is available except \(i_R\).
If \(h_Li_R\) occurs, however, the whole proper interval
from \(V_L\) through \(V_R\) is matching-closed. Its
two old-cycle boundary edges are a forbidden two-edge
cut. Hence the right orientation is impossible. \(\square\)

The immediate-predecessor theorem does not classify the
matching in that right-oriented corridor. Site-block vacancies, positive
gaps, defective target order, nonsquare residual cycles,
and the general Barnette conjecture remain outside these
results. These are project-internal analytic proofs; no
external priority claim is made.
