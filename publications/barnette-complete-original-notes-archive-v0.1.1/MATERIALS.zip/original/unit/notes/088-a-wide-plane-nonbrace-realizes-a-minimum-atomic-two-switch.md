> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A wide plane nonbrace realizes a minimum atomic two-switch

[Note 087](087-a-legal-wide-fibre-can-contain-a-nonminimum-atomic-two-switch.md)
shows that an actual legal-wide plane brace can contain a locally atomic
two-\(C_4\) subcube, but its complete fibre supplies a crossing
one-\(C_6\) state outside that subcube.  Thus the local overlay does not
decide whether a *minimum* cross-sector pair can have two components.

This note separates planarity from the brace axiom.  A deterministic
32-vertex simple plane cubic bipartite graph has a legal-wide labelled
square interface whose complete fixed-pairing fibre has both gate sectors
nonempty and no cross-sector single-cycle exchange.  Its global minimum
cross-sector distance is exactly two and is attained by an atomic pair of
disjoint four-cycles.  The graph fails precisely at the plane-brace
boundary: it has connectivity two and an explicit independent edge pair
that does not extend to a perfect matching.

## 1. Construction

Begin with the octagonal prism \(C_8\square K_2\), using the notation

\[
T_i=t_it_{i+1},\qquad
B_i=b_ib_{i+1},\qquad
R_i=t_ib_i
\tag{1}
\]

from Note 087.  Let \(P=Q_3-A_0B_0\), where
\(A_0,A_1,A_2,A_3\) and \(B_0,B_1,B_2,B_3\) are the two bipartition
classes of a cube and \(A_0B_0\) is one cube edge.  The vertices
\(A_0,B_0\) have degree two in \(P\); all other vertices have degree
three.

Replace \(T_3=t_3t_4\) by a copy \(P_L\), attaching

\[
t_3A_0^L,\qquad t_4B_0^L,
\tag{2}
\]

and replace \(T_5=t_5t_6\) by a disjoint copy \(P_R\), attaching

\[
t_5A_0^R,\qquad t_6B_0^R.
\tag{3}
\]

Call the resulting graph \(G\).  Each copy of \(P\) is embedded in a narrow
neighbourhood of the replaced top-rim edge, with the five-edge terminal
boundary route incident with the old top face.  This gives a plane
embedding of the simple cubic bipartite graph \(G\), with

\[
|V(G)|=32,\qquad |E(G)|=48.
\tag{4}
\]

Take

\[
e=B_0,\qquad g_0=T_0,\qquad g_1=T_4.
\tag{5}
\]

The root \(e\) and \(g_0\) remain opposite in the side square
\(b_0b_1t_1t_0b_0\).  The old top octagon becomes a common facial cycle
for \(g_0,g_1\); the two closed gate arcs both have size nine.  Hence the
labelled site has the required legal-wide geometry.

## 2. Complete fibre and its global minimum

Delete the root--gate square \(Q=\{b_0,b_1,t_0,t_1\}\), obtaining the
four-terminal graph \(R\).  Use the fixed pairing

\[
\pi_0=\{\{b_7,t_7\},\{b_2,t_2\}\}
\tag{6}
\]

and let \(\mathcal L\) be the perfect matchings of \(R\) whose complements
are exactly two spanning paths with pairing \(\pi_0\).  Split the complete
fibre by the surviving gate:

\[
\mathcal L^1=\{M\in\mathcal L:g_1\in M\},
\qquad
\mathcal L^0=\{M\in\mathcal L:g_1\notin M\}.
\tag{7}
\]

Complete enumeration gives

\[
|\mathcal L|=48,\qquad
|\mathcal L^1|=16,\qquad
|\mathcal L^0|=32.
\tag{8}
\]

For every ordered pair
\((M,N)\in\mathcal L^1\times\mathcal L^0\), count the alternating-cycle
components of \(M\triangle N\).  The complete distribution is

\[
\begin{array}{c|ccccc}
\#\operatorname{comp}(M\triangle N)&2&3&4&5&6\\ \hline
\#\text{ pairs}&32&160&232&80&8.
\end{array}
\tag{9}
\]

The entries sum to \(16\cdot32=512\).  In particular,

\[
\boxed{
\min_{M\in\mathcal L^1,\ N\in\mathcal L^0}
\#\operatorname{comp}(M\triangle N)=2,}
\tag{10}
\]

so this is a full-fibre obstruction, not a selected nonminimum subcube.

An explicit minimum pair shares the same perfect matching inside both cube
poles and differs only on the two original side squares

\[
C_2=b_2b_3t_3t_2b_2,\qquad
C_4=b_4b_5t_5t_4b_4.
\tag{11}
\]

Thus

\[
M\triangle N=C_2\mathbin{\dot\cup}C_4.
\tag{12}
\]

Neither \(M\triangle C_2\) nor \(M\triangle C_4\) belongs to
\(\mathcal L\).  Relative to this minimum pair, the feasible component
masks are exactly the empty and full masks.  The minimum pair is therefore
an atomic two-switch in the precise sense of Note 086.

## 3. The exact failed hypothesis

The graph \(G\) is not a brace.  It has

\[
\kappa(G)=2,
\tag{13}
\]

and, in the left cube pole, the independent edges

\[
A_0^LB_1^L,\qquad B_0^Lt_4
\tag{14}
\]

do not extend together to a perfect matching of \(G\).  Thus \(G\) is not
2-extendable.  All geometric and local incidence hypotheses used above
remain valid: \(G\) is simple, connected, plane, cubic and bipartite; the
root square and legal-wide gate placement are genuine; and the minimum in
(10) ranges over the complete fixed-pairing fibre.

Consequently the implication

\[
\text{simple plane cubic bipartite + legal-wide}
\Longrightarrow
\text{cross-sector single-cycle adjacency}
\tag{15}
\]

is false.  Any proof in the actual Barnette class must use brace-level
global matching structure, not planarity or wide facial geometry alone.
The next exact question is whether 2-extendability forces a crossing edge
or otherwise prevents the atomic minimum (10).

## 4. Exact boundary

**Exact conclusion.**  A simple plane cubic bipartite legal-wide square
extension can have a complete fixed-pairing fibre whose globally minimum
cross-sector pairs have two alternating components and are atomic.

**Evidence level.**  The construction and its plane embedding are explicit.
The
[verification bundle](../computations/bundles/wide-plane-nonbrace-minimum-two-switch/README.md)
enumerates the complete residual matching family and all 512 cross-sector
pairs, and exhibits the nonextendible independent edge pair (14).

**Scope.**  This is a strict plane-nonbrace countermodel, not a Barnette
counterexample.  The construction uses the smallest plane cubic bipartite
two-pole available in this directed edge-replacement route, but no
order-minimality among all plane nonbraces is claimed.

**Unresolved boundary.**  It remains unknown whether a globally minimum
cross-sector pair can have two components when the labelled extension is a
plane brace.  The only remaining class hypothesis not satisfied here is
brace-level 2-extendability.
