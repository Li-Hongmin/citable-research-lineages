> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four-vertex regions do not obstruct single-layer FEC support

[Notes 034--035](034-single-region-weights-collapse-to-one-and-two-vertex-regions-do-not-obstruct.md)
reduce a single weighted FEC region to a perfect-matching intersection
bound and prove that bound through three vertices.  Notes 036--041 develop
the annular, residual-cut, and facial transitions needed at four vertices.
This note completes the four-vertex classification.

Let \(F\) be a simple plane cubic bipartite brace, let \(p=uv\) and
\(h=z\alpha\) be an ordered legal cofacial site with \(u,z\) in the same
bipartition class, and put

\[
 K=F-\{u,\alpha\},
 \qquad
 Q=(F^*/\{p^*,h^*\})[E(K)^*].
\tag{1}
\]

The graph \(K\) is \(1\)-extendable and has minimum degree at least two.
Write \(r\) for the contracted root of \(Q\).

> **Four-vertex region theorem.**  For every \(W\subseteq V(Q)\) with
> \(|W|=4\), there is a perfect matching \(M\) of \(K\) such that
> \[
> |M\cap E_Q(W)|\le3=|W|-1.
> \tag{2}
> \]

## Root-free regions

Let \(\Delta=F^*\).  It is a simple \(4\)-connected Eulerian
triangulation and is therefore properly \(3\)-colourable.  If
\(r\notin W\), the simple graph \(\Delta[W]\) has at most five edges.
Restriction to retained labels can only decrease this number.

If \(|E_Q(W)|\le4\), avoid one internal label: choose a different edge
at one of its endpoints and extend that edge to a perfect matching of
\(K\).  The resulting matching uses at most three internal labels.

If \(|E_Q(W)|=5\), then \(\Delta[W]\cong K_4-e\).  Its two triangles
share one edge and, by \(4\)-connectivity, are the two facial triangles
incident with that edge.  In the primal, the five labels lie in the
union of the two cubic stars at the endpoints of the shared label.  A
perfect matching uses either the shared label alone or at most one other
label at each endpoint.  It therefore uses at most two of the five.
This proves (2) when \(r\notin W\).

## Root classes and the automatic reduction

Suppose henceforth that

\[
 W=\{r,s,t,q\}.
\]

Write

\[
 p^*=cc_p,\qquad h^*=cc_h,
 \qquad
 A(x)=\{d\in\{c,c_p,c_h\}:dx\text{ has a retained primal label}\},
\tag{3}
\]

and let \(H=\Delta[\{s,t,q\}]\).  The root classes are

\[
 \varnothing,\quad S_c,S_p,S_h,\quad
 V=\{c,c_p\},\quad Z=\{c,c_h\},\quad
 R=\{c_p,c_h\},\quad T=\{c,c_p,c_h\}.
\tag{4}
\]

The local classes \(V,Z\) are exact-one.  A remote \(R\)-class is either
exact-one, denoted \(R_E\), or balanced zero/two, denoted \(R_B\).
The unique \(T\)-class has the two states

\[
 (vz,vx,zy)=(1,0,0),(0,1,1).
\tag{5}
\]

There is at most one class in \(\{V,T\}\) and at most one in
\(\{Z,T\}\), because each root edge has only one retained third facial
vertex.

We use repeatedly the following reduction.  If

\[
 |A(x)|+\deg_H(x)\le1,
\tag{6}
\]

delete \(x\), apply the three-vertex theorem of Note 035, and restore its
at most one internal label.  This gives \(2+1=3\).

The graph \(H\) has zero, one, two, or three edges.  With two edges it is
a path; with three it is a triangle.  We treat these four shapes in turn.

## No nonroot edge

After (6), all three root classes have size at least two.  If \(T\)
occurs, the other two classes are remote, and the no-rung case of
[Note 037](037-three-annular-root-classes-do-not-obstruct-single-layer-fec-support.md)
applies.

Without \(T\), every class is \(V,Z,R_E\), or \(R_B\).  With zero
balanced classes the total cost is three.  With one balanced class, use
its zero witness.  With two balanced classes, zero one of them; the
other costs at most two and the exact class costs one.  With three
balanced remote classes, [Note 036](036-three-balanced-remote-root-classes-have-a-low-weight-perfect-matching-state.md)
supplies a state of Hamming weight at most one.  Thus the no-edge shape
always satisfies (2).

## Exactly one nonroot edge

Let \(xy\) be the unique edge of \(H\), and let \(z_0\) be isolated.
After (6), the joined classes are nonempty and \(|A(z_0)|\ge2\).  If
\(A(z_0)\) is \(V,Z\), or \(R_E\), it contributes exactly one to every
matching.  Note 035 applied to \(\{r,x,y\}\) bounds the joined layer by
two.

It remains that the isolated class is \(R_B\) or \(T\).  Up to the local
position exclusions, the joined layer belongs to the following table,
where \(S\) is a singleton and \(L\in\{V,Z\}\):

\[
\begin{array}{c|c|l}
\text{isolated class}&\text{joined classes}&\text{mechanism}\\ \hline
R_B&S+S&\text{facial equation or a genuine three-cut}\\
R_B&R/T+R/T&\text{Note 037, one-rung case}\\
R_B&L+(S/L/R)&\text{isolated zero witness and a shared facial equation}\\
R_B&T+S&\text{(T)-facial transition and isolated zero witness}\\
R_B&R+S&\text{shared facial equation or a residual three-cut}\\
T&S+S&\text{facial equation or a genuine three-cut}\\
T&R+R&\text{Note 037, one-rung case}\\
T&R+S&\text{shared facial equation or overlapping odd cuts.}
\end{array}
\tag{7}
\]

Here is the common three-cut argument in the \(S+S\) rows.  Equal root
attachments give one facial cubic star.  For distinct attachments, the
two singleton labels and the rung form a three-edge cut \(C\) of \(K\).
If a shore of \(C\) is even, use the low-cost witness of the isolated
class and cut parity gives joined cost zero or two.  If it is odd, avoid
one member of \(C\); parity then leaves exactly one cut edge, while the
isolated class costs at most two.

All local and shared-root rows of (7) now follow directly.  We record the
only nonlocal \(R+S\) subcase.  Suppose first that the isolated class is
\(R_B\), the joined remote class is balanced, and \(S=S_c\).  A short
dual cycle gives a residual three-cut

\[
 C=\{S,g,a_p\}
\]

whose parent restoration is a four-cut of \(F\).  If its shore is even,
the residual-three-cut zero lemma of Note 039 avoids all of \(C\), and
balancedness avoids the other remote label.  If its shore is odd, take a
zero witness for the joined remote class; then \(S+g=1\).  In either case
the isolated class contributes at most two.

If instead the isolated class is \(T\), its two facial triangles force
the path from \(S_c\) to the joined remote class into the opposite root
sector.  The two residual cuts through \(c_p\) and \(c_h\) both have odd
shores.  Their parity equations have the form

\[
 S+g+f_p\equiv1,
 \qquad
 S+g+f_h\equiv1\pmod2.
\tag{8}
\]

Thus \(f_p=f_h\); the exact-one remote subtype is impossible.  A zero
witness for the balanced subtype gives \(S+g=1\), and \(T\) costs at
most two.  This completes (7) and the one-edge shape.

## The nonroot path

Write

\[
 H=s-t-q.
\tag{9}
\]

We classify by \(|A(t)|\).

### Rootless centre

If one endpoint class is empty, (6) applies.  Otherwise the unordered
endpoint sizes are

\[
 (1,1),\quad(1,2),\quad(1,T),\quad(2,2),\quad(2,T).
\tag{10}
\]

The first row has four labels, so edge avoidability suffices.  In the
second row, avoid one of the singleton and rung labels for an exact-one
pair, or use a zero witness for a balanced pair.  In the fourth row,
the exact/exact and exact/balanced cases are immediate; the
balanced/balanced case is [Note 038](038-two-balanced-remote-classes-joined-through-a-rootless-path-are-safe.md).

For \((1,T)\), extend the \(c\)-label \(vz\) of \(T\).  If the singleton
is attached at \(c\), the cycle through the two rungs gives an odd-shore
four-cut containing \(vz\); if it is attached at \(c_p\) or \(c_h\), the
corresponding four-cut has even shores and contains the excluded label
\(vx\) or \(zy\).  In either case parity permits at most two of the
remaining three labels, so the total is at most three.

For \((2,T)\), the size-two endpoint must be remote.  The rootless
joining path lies in the deletion-free strip between the \(T\)-path and
the remote path: placing it in the other disc would join alternating
boundary endpoints without crossing the root path.  The two strip cuts
are even.  If \(\sigma_T\) is the two-edge state of \(T\), \(x,y\) are
the rungs, and \(\rho_p,\rho_h\) are the remote indicators, their parity
equations are

\[
 \sigma_T+x+y+\rho_p\equiv0,
 \qquad
 \sigma_T+x+y+\rho_h\equiv0\pmod2.
\tag{11}
\]

Hence \(\rho_p=\rho_h\), excluding the exact-one subtype.  In a zero
witness for the balanced subtype, \(x+y\) is even when \(\sigma_T=0\)
and odd when \(\sigma_T=1\).  Since \(T\) costs \(1+\sigma_T\), the
total is at most three.

### Singleton centre

Again empty endpoints reduce by (6), and the five nonempty endpoint
sizes are exactly those in (10).  We record the two non-marginal rows.

For \((1,1)\), there are five labels.  If an endpoint and the centre
share a root, their three labels form a facial cubic star.  Otherwise
the two length-two rooted subpaths give three-cuts

\[
 C_s=\{r_0,x,e\},\qquad C_q=\{e,y,z_0\}.
\]

If every matching used at least four labels, a matching avoiding \(r_0\)
would use three members of \(C_q\), while one avoiding \(e\) would use
two, contradicting fixed cut parity.

For a balanced \((1,2)\) row, the only profile without an immediate
shared-root equation is, up to reflection,

\[
 A(s)=\{c_p\},\qquad A(t)=\{c\},\qquad
 A(q)=\{c_p,c_h\}.
\tag{12}
\]

Take a zero witness for the remote pair.  If the arc \(c-t-q\) lies in
the strip containing the two deleted faces, the two residual cuts are
odd and \(e+y=1\).  In the deletion-free strip they are even, so
\(e+y\equiv0\); the cycle \(c_p-s-t-c\) lies in the same strip and gives
\(r_0+x+e\equiv0\).  The four remaining indicators cannot all be one.

The other rows are local.  For \((1,T)\), the centre root is \(c_p\) or
\(c_h\), and the \(T\)-class, centre label, and adjacent rung cost exactly
two; avoid the opposite singleton label.  For \((2,2)\), classify by the
number of pairs containing the centre root and use the facial equation,
a balanced zero witness, or edge avoidability.  The sole formal case
with neither pair containing a \(c\)-centre is a literal \(K_{3,3}\) in
the plane dual.  For \((2,T)\), the size-two class is remote; a balanced
zero witness gives the bound, while in the exact-one case avoiding the
remote label opposite the centre root makes the two facial equations
give total cost exactly three.

### Centres of size two and three

Every size-two centre is settled by
[Note 040](040-every-rooted-path-with-a-size-two-centre-is-safe.md).
Every size-three centre is settled by
[Note 041](041-every-rooted-path-with-a-size-three-centre-is-safe.md).
Thus every path shape satisfies (2).

## The nonroot triangle

Suppose \(H\) is a triangle.  It is facial, so every perfect matching
uses exactly one of its three primal labels.  If there are at most three
root labels, avoid one when necessary and obtain root cost at most two.

For at least four root labels, use the following finite facial-state
lemma.

> **Facial-state lemma.**  Assign to the three nonroot vertices any root
> classes from (4), and choose the exact or balanced mode of each remote
> class.  Impose:
> 1. the class equations from (4)--(5);
> 2. uniqueness of the retained \(V/T\) and \(Z/T\) positions;
> 3. at most one shared root neighbour across each triangle edge;
> 4. the facial equation at every shared root; and
> 5. exactly one selected nonroot triangle label.
>
> If every triangle label occurs in some state, then one triangle label
> \(g\) has root cost at most two in every state containing \(g\).

The lemma is a constant-size exhaustion of eight class choices at three
positions.  After the incidence tests, remote-mode choices, and the
three extendability tests, there are \(430\) admitted modes, \(279\) of
which have at least four root labels.  Direct substitution proves the
lemma in all \(279\) modes.  It is reproduced by

```bash
python3 \
  units/barnette/computations/verify_rooted_four_triangle_profiles.py
```

with terminal marker `ROOTED_FOUR_TRIANGLE_PROFILES_VERIFIED`.

For an actual profile, every perfect-matching projection satisfies the
five displayed conditions, so the actual projections form a subset of
the symbolic states.  Every triangle label is extendable in \(K\), hence
the lemma's filter never discards an actual profile.  Extend the label
\(g\) supplied by the lemma.  The resulting actual matching has root cost
at most two and triangle cost one.  This proves (2) for the final shape.

## Consequence and boundary

The four shapes of \(H\) exhaust every rooted region, while the first
section handles root-free regions.  This proves the four-vertex region
theorem.

By Note 034, a matching satisfying (2) proves the complete weighted
charging inequality for that single region.  Combining Notes 034--035
with the present theorem gives

\[
 \boxed{\text{every strict single-region binary FEC support obstruction
 has }|W|\ge5.}
\tag{13}
\]

The matching may depend on \(W\).  Nothing here supplies one simultaneous
matching for a laminar family of regions, and the theorem does not exclude
a genuinely multi-region obstruction.
