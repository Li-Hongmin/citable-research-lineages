> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-sided internal vacancies have marked Hamilton cycles at first surplus

[Note 205](205-an-internal-near-equality-vacancy-must-touch-a-short-block.md)
shows that an internal vacancy at the first surplus cannot
have escape-target pairs on both sides inside its block.
[Note 207](207-a-single-long-chord-block-at-first-surplus-always-has-a-marked-hamilton-cycle.md)
classifies the matching when every other block is short.
The same classification survives arbitrary additional long
blocks: each occupied target run is a parity barrier that
the free matching cannot cross.

Let \(G,C,M\) be a compressed all-square Barnette opening
as in Notes 195--197. Suppose the opposite site-face arc
has \(r\ge1\) matching chords, there are \(\ell\ge1\)
lobes, every interblock gap is empty, and \(f=4r+4\).
Assume the target order is tight:
\(R_\ell\) is the first interior slot of \(B_0\),
\(L_1\) the final interior slot of \(B_{r+1}\), and
\(L_jR_{j-1}\in E(C)\) for each \(j\ge2\).
Suppose the unique vacant eligible even position lies
in a face-chord block \(B_k\), \(1\le k\le r\),
and that block contains at least one occupied eligible
position as well. Thus \(\ell,r\ge2\).

For each ordinary face block \(B_j\), write \(o_j,e_j\)
for its first odd and final even free interior slots.
Write \(e_0\) for the final free slot of \(B_0\), and
\(o_{r+1}\) for the first free slot of \(B_{r+1}\).
In \(B_k\), use \(o_k,h,i,e_k\) for its four free slots
in order, where \(h\) is the vacancy and \(i\) follows it.

**One-sided-vacancy Hamilton theorem.** The parent \(G\)
has a Hamilton cycle containing both site edges. Its
legal site-expanded child is Hamiltonian. More precisely,
after possibly reversing the opening, the vacancy \(h\)
is the first eligible position of \(B_k\), all its
occupied eligible positions follow it, and for some
\(1\le s<k\) the complete free-slot matching is
\[
\begin{aligned}
M_{\rm free}={}&
\{e_j o_{j+1}:0\le j\le s-2\}\\
&\cup\{e_{s-1}i,\ o_s h\}\\
&\cup\{e_j o_{j+1}:s\le j\le r\}.
\end{aligned}                                                   \tag{1}
\]
The original square-trap lobes may have arbitrary
positive lengths via Note 178.

**Proof.** Note 205 excludes occupied positions on both
sides of the vacancy. Since \(B_k\) has at least one,
the vacancy is first or last among its eligible positions.
Reverse the main-segment orientation, exchange site labels,
and reverse the lobe order if necessary, so it is first.
Then \(B_k\) has the free order \(o_k,h,i,e_k\), with at
least one target pair between \(i,e_k\). Note 205 gives
a short face block immediately before \(B_k\).

Consider the first occupied \(L\)-target inside any
block that has one. Count the free main slots preceding
it. In \(B_0\) this count is zero. In a normal face
block \(B_j\), it is \(2j\) when \(j<k\) and
\(2j+2\) when \(j>k\): each earlier face block has
two free slots, \(B_0\) has one, and the current block
starts with \(o_j\); passage past the exceptional
block adds two free slots. In \(B_k\), the count is
\(2k+2\), because \(o_k,h,i\) all precede its first
occupied target. If \(B_{r+1}\) has an occupied eligible
position, the count is \(2r+4\), including its free
first slot. Every count is even.

An \(M\)-edge joining free slots in different blocks
cannot straddle that target by Note 203. Within a
normal face block, the only possible free edge
straddling the target run is \(o_je_j\). Within
\(B_k\), only \(e_k\) is free after the run, so at
most one free edge can straddle it. There is no
free slot after the final target run in \(B_{r+1}\).
For any prefix of an even number of vertices in a
perfect matching, the number of matching edges leaving
the prefix is even. Here at most one can leave, so
none does. Therefore the free-slot matching crosses
no occupied target run.

The free slots consequently split into consecutive
groups between those target runs. Each ordinary group
has the form
\[
e_a,o_{a+1},e_{a+1},\ldots,e_{b-1},o_b,
\tag{2}
\]
where every intervening face block is short, with two
adjacent free interior slots. The one exceptional group,
immediately before the target run of \(B_k\), has the form
\[
e_a,o_{a+1},e_{a+1},\ldots,o_k,h,i,
\qquad a\le k-2.
\tag{3}
\]
Every free edge within either type of group joins
different blocks. The short-block free pairs are
old-cycle edges; in (3), \(o_kh\) and \(hi\) are
also old-cycle edges. All allowable free chords
therefore lie on the side of \(C\) opposite the
common site face by Note 193, and are noncrossing.

In (2), the first even slot \(e_a\) must match the
next odd slot \(o_{a+1}\). If it matched a later
\(o_j\), noncrossing would make the skipped complete
short blocks match internally. One skipped block
would have to match its two adjacent old-cycle
vertices; two or more would form a proper consecutive
\(C\)-interval closed under \(M\), a forbidden
two-edge cut. Continue inductively to force the
chain \(e_j o_{j+1}\) throughout (2).

Apply the same skipping rule in (3). The initial
even slots match successive odd slots until one
\(e_{s-1}\) matches \(i\), since otherwise the
adjacent pair \(h,i\) would remain. The mate of
\(h\) must be \(o_s\): if it were a later
\(o_j\), the intervening complete short blocks
would again match internally. Noncrossing then
forces \(e_j o_{j+1}\) between \(o_s,h\).
This is precisely the exceptional replacement
\(e_{s-1}o_s\mapsto\{e_{s-1}i,o_sh\}\).
Combining the groups proves (1).

Let \(A\) be the even-starting matching of \(C\)
indexed from \(x\). Tight target transitions make
the square and target vertices the \(x\)-to-\(v\)
path (4) of Note 207 in \(M\cup A\). Formula (1)
makes all other vertices the \(x\)-to-\(v\) path
(5) of that note, with \(e_{s-1}o_s\) replaced
by \(e_{s-1},i,h,o_s\). These paths meet only at
\(x,v\), cover the graph and contain both site
matching edges. Their union is a Hamilton cycle.
Note 001 lifts it to the legal expanded child;
Note 178 restores longer original lobes. \(\square\)

Consequently, under tight endpoints and transitions
with no gaps, an internal face-block vacancy remains
undecided only when its four-slot block has **no**
escape-target pair. Note 206 shows that target-free
shape is realizable and can be Hamiltonian, but does
not classify all of its matchings. Outer-block
vacancies, target-order defects, gap slots and
nonsquare residual cycles lie outside this theorem.

The face-size-bounded result of Schnieders (2025,
arXiv:2508.03531, Theorem 1.12) has a different scope.
In Note 204's family, the cycle arc of the long
face-chord block together with its closing matching
edge bounds a face of length \(2\ell+4\), unbounded
as \(\ell\) grows. The cited preprint was checked on
2026-09-29; no claim of priority over other work is
made here.

[Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)
subsequently handles the target-free four-slot block,
closing the entire tight, gapless internal-vacancy branch.
