> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Hamilton parity does not force rooted crossing compensation

[Note 156](156-cubic-parity-forbids-a-two-clean-row-annular-isolator.md)
proves that the transparent two-row annular factor is impossible: a target
Hamilton-path row forces another clean row by Smith--Thomason parity.  This
note determines the exact strength of that forced row against the fixed
carrier of
[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md).
The forced row need not create a second rooted crossing.  Hamilton parity,
even combined with every actual carrier-side join and bond atom, is
compatible with exactly one mixed bond.

This is a strict atom-level countermodel, not a finite cubic factor and not
a counterexample to the original legal-wide proposition.

## 1. Complete square-trace parity

Let a cubic factor \(B\) contain the square

\[
 Q=b_0b_1b_2b_3b_0,\qquad q_i=b_ib_{i+1},
\]

and let \(r_i\) be the exterior edge at \(b_i\).  A Hamilton cycle cannot
omit two adjacent square edges, because their common square vertex would
then have cycle degree at most one.  Apart from the impossible isolated
square, its trace on \(Q\) is one of

\[
\begin{aligned}
 U_i&=E(Q)-\{q_i\}\quad(i=0,1,2,3),\\
 O_{02}&=\{q_0,q_2\},\qquad
 O_{13}=\{q_1,q_3\}.
\end{aligned}
\tag{1}
\]

Write the six multiplicities as
\(h_0,h_1,h_2,h_3,h_{02},h_{13}\).  Applying cubic edge parity to the four
square edges gives

\[
\begin{array}{rcl}
h_1+h_2+h_3+h_{02}&=&0,\\
h_0+h_2+h_3+h_{13}&=&0,\\
h_0+h_1+h_3+h_{02}&=&0,\\
h_0+h_1+h_2+h_{13}&=&0
\end{array}
\qquad\pmod 2.
\tag{2}
\]

The corresponding four equations at \(r_0,\ldots,r_3\) lie in the same row
span.  The complete projected solution is

\[
\boxed{
 h_0=h_2=h_{02},\qquad
 h_1=h_3=h_{13}\pmod2.
}
\tag{3}
\]

Thus the parity kernel has generators

\[
 U_0+U_2+O_{02},
\qquad
 U_1+U_3+O_{13}.
\tag{4}
\]

The row \(N_1\) from (T1) is of type \(U_0\).  If its class has odd
multiplicity, the minimum nonzero completion is therefore one \(U_0\), one
\(U_2\) and one \(O_{02}\).  These relations concern only unary Hamilton
incidence.  They contain no symmetric-difference component count involving
the designated two-cycle row \(N_0\).

## 2. The complete fixed-carrier join table

Use the Note 154 carrier cut with ordered ports

\[
 (a_0,a_1,a_2,a_3)=(19,10,21,9)
\]

and deleted edges \(10\!-\!19,9\!-\!21\).  Complete enumeration gives
54 carrier rows containing the root and forced gate, with state counts

\[
\begin{array}{c|rrrrrr}
S&\varnothing&\Omega&A_0&A_1&A_2&A_3\\ \hline
\#&22&6&3&12&0&11.
\end{array}
\tag{5}
\]

Only the following rows join one of the parity-relevant clean factor atoms
to the prescribed rooted complement:

\[
\begin{array}{c|c|c|c}
\text{factor atom}&\text{carrier rows}&\text{old identity}&g_1\\ \hline
\varnothing:01\mid23&
 K_1,K_2,K_{10},K_{19},K_{20}&
 M_1,M_2,M_3,M_6,M_7&0,1,0,0,1\\
A_0:23&K_{29}&M_4&1\\
\varnothing:03\mid12&K_0,K_{18}&\text{new joins}&0,0\\
A_2:01&\varnothing&\text{none}&-
\end{array}
\tag{6}
\]

The retained isolated pair is

\[
 X_3=(K_{10},N_0),\qquad X_4=(K_{29},N_1).
\tag{7}
\]

Its carrier bond has one \(01\)-path and no closed component.  The other
relevant carrier atoms are

\[
\begin{aligned}
d_G(K_1,K_{29})&=d_G(K_{19},K_{29})
   =01+1\text{ closed},\\
d_G(K_0,K_{29})&=d_G(K_{18},K_{29})
   =01+1\text{ closed}.
\end{aligned}
\tag{8}
\]

Every same-state bond from \(K_0\) or \(K_{18}\) to a
\(\varnothing:01\mid23\)-compatible carrier row already has at least one
closed component.

## 3. Both Smith-companion branches

Let \(H_2\ne H_1\) be a second Hamilton cycle through \(q_2\), supplied by
Smith--Thomason parity.

If \(q_0\in H_2\), deleting \(q_0,q_2\) gives the clean empty-state pairing
\(03\mid12\).  By (6), its factor row \(N_2\) joins only through
\(K_0,K_{18}\), both in gate sector zero.  Against an \(N_0\)-target, the
factor difference has at least one cycle because the two same-state rows
are distinct, and the carrier difference has at least one more.  Against
\((K_{29},N_1)\), equation (8) already contributes one closed component in
addition to the cycle formed by joining the two \(01\)-paths.  Hence this
Smith companion has no mixed one-cycle bond at all.  Parity at \(q_0\) can
be completed by a \(U_2\) row, but the fixed carrier has no \(A_2\) row with
which it can join.

If \(q_0\notin H_2\), then \(N_2\) has state \(A_0\), complement atom
\(23\), and joins only through \(K_{29}\).  The sole possible new crossing
is

\[
\boxed{
 (K_{10},N_0)\sim(K_{29},N_2)
 \iff
 d_B(N_0,N_2)=01+0\text{ closed}.
}
\tag{9}
\]

Hamilton parity fixes the state and complement atom of \(N_2\), but does
not control the pair atom on the right side of (9).  In particular, let
\(A\) be one \(01\)-path atom and \(C\) one disjoint closed-cycle atom.
The assignments

\[
 N_0\triangle N_1=A,\qquad
 N_1\triangle N_2=C,\qquad
 N_0\triangle N_2=A\mathbin{\dot\cup}C
\tag{10}
\]

respect symmetric difference, retain (TB), and block (9).

## 4. A parity-complete one-crossing atom model

Take four clean rows

\[
 N_0,\quad N_1\in U_0,\quad R_2\in U_2,\quad R_{02}\in O_{02}.
\]

Their Hamilton traces realize the minimum parity kernel vector in (4).
Use the literal fixed-carrier compatible sets

\[
\begin{aligned}
J(N_0)&=\{K_1,K_2,K_{10},K_{19},K_{20}\},\\
J(N_1)&=\{K_{29}\},\\
J(R_2)&=\varnothing,\\
J(R_{02})&=\{K_0,K_{18}\}.
\end{aligned}
\tag{11}
\]

Set the designated factor bond \(d_B(N_0,N_1)\) to the \(01\)-path with
no closed component.  Equations (8) and the same-state component counts
then exclude every mixed bond involving \(R_{02}\), while \(R_2\) has no
join.  The complete joined atom system has exactly one mixed edge,

\[
 (K_{10},N_0)(K_{29},N_1).
\tag{12}
\]

Thus all square and exterior edge parities, the actual carrier joins, the
actual carrier bond atoms and the target bond (TB) coexist with one
crossing.  No argument using only those data can prove compensation.

## 5. Remaining realizability interface

The atom model does not assert that the four rows in Section 4 are perfect
matchings of one finite plane cubic bipartite factor.  A genuine
counterexample must realize their common incidence, the two-factor and
Hamilton complements, and the bond atoms in (9) or (10); every additional
clean row in the complete factor family must also be harmless.  Finally the
annular splice must remain a brace and retain the legal-wide root geometry.

The thinnest unresolved datum is therefore not another parity count.  It is
the **rooted-join times opposite-sector bond incidence** forced by one
common cubic perfect-matching family.  Establishing that this incidence is
always nonzero would prove compensation for the annular route; realizing
the atom model with incidence zero would produce the desired one-crossing
counterexample.

The fixed
[verification bundle](../computations/bundles/fixed-carrier-parity-atom-boundary/README.md)
reconstructs (5)--(8), computes the parity kernel (3)--(4), and verifies the
one-crossing atom model (11)--(12).

