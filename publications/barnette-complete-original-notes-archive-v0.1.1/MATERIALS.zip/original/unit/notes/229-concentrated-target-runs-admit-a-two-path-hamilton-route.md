> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Concentrated target runs admit a two-path Hamilton route

[Note 228](228-one-target-pair-between-two-vacancies-is-hamiltonian.md)
absorbs a same-block double vacancy separated by one occupied
target pair. When several consecutive target pairs intervene,
its five-edge target detour no longer spans all their residual
squares. If all occupied nonfinal targets are concentrated in
that one block, the face chords supply a second Hamilton route
whose length is independent of the number of target pairs.

Use a compressed all-square Barnette opening as in
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
with \(\ell\ge2,r\ge1\), empty interblock gaps,
tight target order and exactly two eligible vacancies.
Every occupied nonfinal eligible position lies in one
face-chord block \(D=B_k=[a_k,b_k]_C\),
\(1\le k\le r\). The two vacancies are the first
and last eligible positions of \(D\), so its
interior old-cycle order is
\[
o_k,h_1,i_1,\,
L_\ell,R_{\ell-1},L_{\ell-1},R_{\ell-2},
\ldots,L_2,R_1,\,
h_2,i_2,e_k.                                      \tag{1}
\]
There are \(\ell-1\) consecutive occupied target pairs
between the vacancies. Every other face block is short
and target-free; \(B_0\) has interior \(R_\ell,e_0\)
and \(B_{r+1}\) has interior \(o_{r+1},L_1\).

**Concentrated-run theorem.** Every such parent has a
Hamilton cycle containing the site edges \(xy,uv\).
Its legal site-expanded child is Hamiltonian.
The result holds for every \(\ell\ge2,r\ge1,k\)
and for arbitrary positive original square-trap
lobe lengths.

**Matching reduction.** All free slots before the
target run in \(D\), together with the left short
blocks and \(e_0\), are balanced between the two
bipartition colours. A cross-block free chord cannot
straddle any target by Note 203. A same-block chord
across the run must lie on the site-face side, because
the escape edge of an intervening target occupies
the opposite disk. There are therefore zero or two
free matching chords across the run. In the two-chord
case, colour balance forces \(h_1i_2\) and one other
chord. The site-face noninterlacement restriction
leaves exactly
\[
\{oe,h_1i_2\}
\quad\text{or}\quad
\{h_1i_2,i_1h_2\},                                \tag{2}
\]
where \(o=o_k,e=e_k\). This is the same chord
classification as Note 228; it does not depend
on how many target pairs lie between \(i_1,h_2\).

With zero crossing chords, the target run separates
two one-vacancy free groups. The Note 208/215
short-block skipping proof gives one independent
three-edge detour for each group. The ordinary
free path and the unchanged target-and-square path
form the marked Hamilton cycle.

For the first pair in (2), no cross-block matching
edge crosses the target run. The same skipping rule
forces the ordinary short-block chains and the
boundary edges \(e_{k-1}i_1,h_2o_{k+1}\).
Note 224's route
\[
e_{k-1},i_1,h_1,o_k,a_k,b_k,e_k,i_2,h_2,o_{k+1}
\tag{3}
\]
replaces the ordinary free segment, and the
target-and-square path is unchanged.

It remains to handle the second pair in (2).
The ordinary slots follow the full standard
free chain \(e_j o_{j+1}\), \(0\le j\le r\);
the other two free matching edges are
\(h_1i_2,i_1h_2\). Define two \(x\)-to-\(v\)
paths. The first follows the exposed face chords:
\[
P_{\rm face}=
x,y,a_1,b_1,a_2,b_2,\ldots,a_r,b_r,u,v.
\tag{4}
\]
Its edges are \(xy,uv,a_jb_j\in M\) and
the intervening old-cycle edges \(ya_1\),
\(b_ja_{j+1}\), \(b_ru\).

The second path starts through the last residual
square and the left free chain:
\[
x,\beta_\ell,\alpha_\ell,\gamma_\ell,\delta_\ell,
R_\ell,e_0,o_1,e_1,\ldots,o_k,h_1,i_1,
L_\ell,R_{\ell-1}.                               \tag{5}
\]
For each \(j=\ell-1,\ldots,2\), continue from
\(R_j\) through
\[
\delta_j,\beta_j,\alpha_j,\gamma_j,L_j,R_{j-1}.
\tag{6}
\]
After reaching \(R_1\), finish through the right
free chain and the first residual square:
\[
R_1,h_2,i_2,e_k,o_{k+1},e_{k+1},\ldots,
o_{r+1},L_1,\gamma_1,\delta_1,\beta_1,\alpha_1,v.
\tag{7}
\]
The short-block portions in (5),(7) mean
\(o_j,e_j\) inside each short block and
\(e_j o_{j+1}\) between successive blocks.
For \(\ell=2\), (6) is empty. Every displayed
transition is an old-cycle or complementary
matching edge. In particular, the end-square
routes use \(\beta_\ell\alpha_\ell\) and
\(\beta_1\alpha_1\), while (6) uses
\(R_j\delta_j,\beta_j\alpha_j,\gamma_jL_j\).

The two paths share only \(x,v\). They partition
all other vertices: (4) contains \(y,u\) and
the two face-chord endpoints of each face block;
(5)--(7) contain the interior slots of every
main block, every escape target and all four
vertices of every residual square. Their union
is one Hamilton cycle using \(xy,uv\).
Note 001 lifts it through the legal site
expansion, and Note 178 restores the original
lobe lengths. This completes the proof.
\(\square\)

**Realization for every target-run length.**
The second profile in (2) occurs in a Barnette
parent for every \(\ell\ge2\). Take \(r=k=1\)
and the old cycle in the order
\[
\begin{array}{ll}
B_0:&x,R_\ell,e_0,y,\\
D:&a,o,h_1,i_1,
L_\ell,R_{\ell-1},\ldots,L_2,R_1,
h_2,i_2,e,b,\\
B_2:&u,o_R,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(1\le j\le\ell),
\text{ returning to }x .
\end{array}                                          \tag{8}
\]
The \(S_j\) rows occur in increasing \(j\).
Add the complementary matching
\[
\begin{split}
M={}&\{xy,uv,ab,e_0o,eo_R,h_1i_2,i_1h_2\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
\delta_jR_j:1\le j\le\ell\}.                    \tag{9}
\end{split}
\]
The cycle has \(6\ell+14\) vertices and (9)
is a perfect matching between opposite cycle
parities. Put \(xy,ab,uv,\alpha_j\beta_j\)
and the nested pair \(h_1i_2,i_1h_2\)
on the site-face side. The escape chords
on the other side are nested as
\[
R_\ell\delta_\ell\supset L_\ell\gamma_\ell
\supset R_{\ell-1}\delta_{\ell-1}
\supset\cdots\supset R_1\delta_1
\supset L_1\gamma_1;
\]
\(e_0o\) and \(eo_R\) fit in disjoint
gaps of this nesting. Thus the graph
is simple, plane, cubic and bipartite,
with cofacial \(xy,uv\).

Its matching-chord interlacement graph
is connected. The chain
\[
xy-e_0o-ab-eo_R-uv-\gamma_1L_1-
\alpha_1\beta_1-\delta_1R_1-ab
\tag{10}
\]
connects the site and face chords to
the first residual square. The face
chord \(ab\) interlaces every
\(L_j\gamma_j\), \(j\ge2\), and every
\(R_j\delta_j\), \(1\le j<\ell\).
Each \(\alpha_j\beta_j\) interlaces
\(L_j\gamma_j\) and \(R_j\delta_j\).
The remaining \(R_\ell\delta_\ell\)
interlaces \(xy\), while \(h_1i_2\)
and \(i_1h_2\) interlace
\(L_\ell\gamma_\ell\).
All matching chords are therefore
in one interlacement component.
Note 217's two-edge-cut criterion
makes the parent three-connected;
its site-expansion cut projection
makes the child Barnette. The
two-path route (4)--(7) makes both
graphs Hamiltonian. \(\square\)

For \(r=1\), the parent order is
\(6\ell+14\), starting at \(26\) when
\(\ell=2\). The two-path formula
(4)--(7) uses concentration in \(D\).
The next corollary removes occupied
targets in the two site blocks by
marked boundary peels.

**Outer-site-block extension.** The same marked-Hamilton
conclusion holds when occupied nonfinal targets outside
\(D\) occur in the two site blocks \(B_0,B_{r+1}\), while
every other face block remains short and target-free.
The two vacancies are still the first and last eligible
positions of \(D\), with at least one occupied transition
pair between them.

Indeed, each occupied pair at the beginning of \(B_0\)
gives the left boundary triple \(x,R_\ell,L_\ell\)
of Note 186. Its simple inverse removes that pair
and the last residual square. The collision case
cannot occur: the vertex after \(L_\ell\) is another
target or the final free slot of \(B_0\), never \(y\).
Repeat until \(B_0\) has only \(R_\ell,e_0\).
Reflect the argument at \(v\) to remove each occupied
pair at the end of \(B_{r+1}\). The predecessor of
\(R_1\) is another target or the first free slot
of \(B_{r+1}\), never \(u\), so these inverses are
also simple. Each inverse preserves the Barnette
opening, the legal child Hamilton decision, and the
target order; \(D\), its two vacancies and all
ordinary face blocks are untouched. The reduced
opening satisfies the concentrated-run theorem.

Its marked parent cycle lifts through the inverse
sequence. At each left insertion the two restored
edges share \(x\); the cycle uses the retained site
edge \(xy\), so it uses exactly one of those two
other incident edges. Note 185's spanning one-path
routing replaces that edge, covers the inserted
six-vertex patch and retains \(xy\). The right
insertion similarly retains \(uv\). The other site
edge is outside each patch. Reversing all peels
therefore gives a parent Hamilton cycle through
both site edges, and Note 001 gives the child.
Note 178 restores original lobe lengths.
\(\square\)

Occupied targets in other face blocks remain
outside these results: the two-path routing
(4)--(7) need not cover the free intervals
between dispersed target runs. Vacancies in
outer blocks, target-order defects, gaps
and nonsquare residual cycles are also
outside their scope.
