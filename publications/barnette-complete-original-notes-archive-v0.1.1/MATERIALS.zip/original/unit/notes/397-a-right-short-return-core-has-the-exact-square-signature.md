> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A right-short-return core has the exact square signature

[Note 396](396-two-short-flanks-reduce-outside-one-boundary-branch.md)
leaves, among other cases, the right return \(hz\) with \(Js,Er\)
and no internal free chord of the doubly vacant block. At the
shortest positive corridor this matching is forced and forms an
exact square-equivalent four-pole. Its ordinary-link ladder
extension has the same signature at every length.

Let
\[
 V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1,
                                                               \tag{1}
\]
be consecutive face blocks in a cubic plane bipartite graph.
Their old-cycle edges follow the displayed vertex order,
successive blocks are joined by their old-cycle bridge edges,
and their closing face chords are \(ab,c_jd_j,AB,CF\).
Assume the complementary matching inside this interval is
\[
 \begin{split}
  M_P=\{iK,eI,p_1H,q_mO,Js,Er\}
       \cup\{q_jp_{j+1}:1\le j<m\}.
 \end{split}                                                   \tag{2}
\]
The four remaining degree-two vertices are \(a,o,h,F\), in
that disk order, with one distinct exterior attachment each.
Let \(P_m\) be this induced disk four-pole.

**Right-return square theorem.** For every \(m\ge1\),
\(P_m\) has precisely the square's four spanning one-path
and two spanning two-path Hamilton linkage states at
\((a,o,h,F)\). Replacing it by the labeled square, or
reversing the replacement, preserves Barnette membership
and every exterior- and attachment-marked Hamilton decision
in any Barnette host. The replacement strictly reduces
the vertex count. Thus no vertex-minimal non-Hamiltonian
Barnette graph contains an induced \(P_m\).

In the selected opening of Note 396, if \(m=1\) and
\(tp,qo,hz,Js\in M\), then the internal matching of
\(V,S_1,D,T\) is forced to be (2). Consequently this
entire shortest \(zh,sJ\) branch has the exact reduction.
For \(m>1\), the theorem applies to the specified
ordinary-link word (2); it does not classify every
possible matching of that branch.

**Forced shortest word.** Note 396 forces \(Er\) from
\(Js\) and excludes every internal free chord of \(D\).
For \(m=1\), the unmatched slots inside \(hz\), after
\(Js,Er\) are removed, occur as
\[
                         i,e,p_1,q_1,O,H,I,K.               \tag{3}
\]
All their matching chords lie opposite the common face.
The odd slot \(i\) can meet only \(q_1,H,K\).
If \(iq_1\) occurs, it traps \(e,p_1\) and forces
\(ep_1\), leaving \(O,H,I,K\) with no allowed
pairing. If \(iH\) occurs, \(ep_1,q_1O\) are
forced inside it, leaving the forbidden old-cycle
edge \(IK\) as the only possible last pair.
Thus \(iK\) occurs. Inside it, \(eO\) would trap
the old-cycle pair \(p_1,q_1\), while \(ep_1\)
would leave \(q_1,O,H,I\) with only the forbidden
old-cycle pairs \(OH\) or \(HI\). Hence \(eI\)
is forced, followed by \(p_1H,q_1O\).
This proves uniqueness of (2) at \(m=1\).

**Six-state certificate for \(P_1\).** In the following
lists, each consecutive pair is an old-cycle edge,
one of \(ab,c_1d_1,AB,CF\), or an edge of (2).
The four spanning one-path states are
\[
\begin{array}{c|l}
aF&
 a,o,h,i,e,b,c_1,p_1,q_1,d_1,A,O,H,I,K,J,E,B,C,r,s,F\\
oh&
 o,a,b,c_1,p_1,H,O,q_1,d_1,A,B,E,r,C,F,s,J,K,I,e,i,h\\
ao&
 a,b,c_1,p_1,H,O,q_1,d_1,A,B,E,r,C,F,s,J,K,I,e,i,h,o\\
hF&
 h,o,a,b,e,i,K,I,H,p_1,c_1,d_1,q_1,O,A,B,E,J,s,r,C,F .
\end{array}                                                   \tag{4}
\]
The two disjoint spanning path-pair states are
\[
\begin{array}{c|l}
\{ao,hF\}&
 (a,o),\quad
 (h,i,K,I,e,b,c_1,p_1,H,O,q_1,d_1,A,B,E,J,s,r,C,F)\\
\{aF,oh\}&
 (o,h),\quad
 (a,b,e,i,K,I,H,p_1,c_1,d_1,q_1,O,A,B,E,J,s,r,C,F).
\end{array}                                                   \tag{5}
\]
Every row visits all 22 vertices exactly once. The
terminal colours are \(a,h\) on one side and \(o,F\)
on the other, so (4) lists all colour-allowed one-path
pairs. The third four-terminal two-path pairing
\(\{ah,oF\}\) interlaces in the disk and is impossible.
Thus (4)--(5) give precisely the square's six states.
Replacing a global Hamilton cycle's restriction to the
pole by the corresponding square state, or conversely,
keeps all exterior edges and used attachments fixed.

**Barnette-class comparison.** Cap \(P_1\) with a
fresh square \(X=(x_a,x_o,x_h,x_F)\) in this cyclic
order, attaching \(a x_a,o x_o,h x_h,Fx_F\).
The full old-cycle path through \(P_1\), followed by
\(x_F,x_h,x_o,x_a,a\), is a Hamilton cycle of the
26-vertex cap. Its complementary matching has the
disjoint common-face chords
\[
             ab,\ c_1d_1,\ AB,\ CF,\ x_ax_F,
\]
and, on the opposite page, the nested or disjoint
chords
\[
             iK,\ eI,\ p_1H,\ q_1O,\ Js,\ Er,\
             ox_o,\ hx_h.                                  \tag{6}
\]
Every chord joins opposite Hamilton-cycle parities,
so the cap is simple, cubic, bipartite and plane.
Its matching-chord interlacement graph is connected:
\[
 x_ax_F-ox_o-ab-iK-AB-p_1H-c_1d_1,
 \qquad AB-Js-CF,                                           \tag{7}
\]
and \(hx_h,eI,q_1O,Er\) attach respectively to
\(ab,ab,c_1d_1,AB\). Every dash in (7)
denotes alternating endpoints in the displayed
Hamilton order. A two-edge cut would bound a proper
old-cycle interval closed under the complementary
matching and disconnect this interlacement graph.
The Hamilton cycle excludes bridges; in a cubic
graph the absence of one- and two-edge cuts gives
three-vertex-connectivity. Thus the cap is Barnette.

Deleting one vertex from \(P_1\) leaves each of the
four block cycles connected. The \(V\)--\(D\) edges
\(iK,eI\), the \(S_1\)--\(D\) edges
\(d_1A,p_1H,q_1O\), and the \(D\)--\(T\)
edges \(BC,Js,Er\) have distinct endpoints within
each set. At least one join of each set survives
any one deletion, so \(P_1-v\) is connected.
After deleting any two pole vertices, every
surviving component meets a surviving terminal:
otherwise that component would be separated in
the three-connected cap after the same deletions.
The square has the same one- and two-deletion
properties. The four-attachment comparison of
[Note 370](370-the-j3-j1-j1-central-return-core-has-the-exact-square-signature.md)
therefore proves three-connectivity in both
replacement directions. Terminal colours and
disk order preserve bipartiteness and planarity:
in a Barnette host the exterior is connected,
since two exterior components would each need
at least three of the four attachment edges.
The connected exterior occupies one side of
the four-pole boundary, leaving the other side
available for the disk substitution.

For \(m>1\), the short-block interval
\(S_1\cup\cdots\cup S_m\) under (2) is the induced
even-column four-terminal ladder of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Its four labeled attachments are
\(bc_1,p_1H,q_mO,d_mA\). Replacing this ladder by
one square gives precisely \(P_1\). Note 178
preserves all four-terminal Hamilton routings
and Barnette membership in both directions.
Composing that replacement with the \(P_1\)
comparison proves the theorem for every \(m\).
\(\square\)

**Shortest \(zh\)-branch corollary.** In the selected
opening of Note 396, assume \(m=1\) and
\(tp,qo,hz\in M\). Every actual matching then
contains an exact square reduction. Indeed,
Note 396 excludes \(sO\), forces the rainbow
block \(D\) for \(sI\) or \(sp_1\), and the
theorem above reduces \(sJ\). It remains to
check \(si\).

If \(si\in M\), its opposite-side chord encloses
\[
                   e,p_1,q_1,O,H,I,K,J,E,r.              \tag{8}
\]
The even slot \(e\) can meet only \(p_1,O,I,J,r\).
The edge \(eO\) traps the forbidden old-cycle
pair \(p_1,q_1\), while \(er\) match-closes the
complete blocks \(S_1,D\) and yields a two-edge cut.
If \(eI\) occurs, \(J\) is forced to \(H\) by the
face-side chord \(HJ\): its old-cycle neighbours
\(K,E\) are unavailable, \(s\) is used by \(i\),
and every opposite-side return into \(eI\) would
cross it. The chord-isolation lemma excludes
\(OK\). Inside \(eI\), the remaining \(p_1,q_1,O\)
are odd in number. Their only possible face-side
exit is \(OE\), which would leave the forbidden
old-cycle pair \(p_1,q_1\). Thus \(eI\) is impossible.

If \(eJ\) occurs, the two later slots \(E,r\)
are forced to pair. Hence \(OE,IE,HJ\) are
unavailable. If \(OK\) occurred, the only
possible mate of \(H\) would be \(p_1\), but
\(p_1H\) would enclose exactly one face-side
exit through \(OK\), contradicting parity.
Without \(OK\), \(p_1\) can meet only \(H\)
or \(K\). The first choice forces \(q_1O\)
and leaves the old-cycle pair \(I,K\);
the second leaves \(q_1,O,H,I\), which
can pair only by using \(OH\) or \(HI\),
both old-cycle edges. Thus \(eJ\) is impossible.

Therefore \(ep_1\) is forced. The remaining
slots \(q_1,O,H,I,K,J,E,r\) are exactly the
last-short interval analyzed for \(p_1s\)
in Note 396. Its four possible mates of
\(q_1\) are \(O,I,J,r\): the first and third
are impossible, the last match-closes \(D\),
and \(q_1I\) forces \(OE,HJ\). Hence
\(D\) is the exact square ladder of Note 325.
This proves the corollary. \(\square\)

If the full group also has the standard left short
flank \(S_0\) with \(tp,qo\), its \(P_m\) subpole
already supplies the reduction. Equivalently,
[Note 393](393-square-signature-poles-admit-buffers-at-nonadjacent-boundary-terminals.md)
buffers \(P_m\) at \(a,o\) to make the entire
group square-equivalent. This local theorem
does not classify longer-corridor \(zh,sJ\) words,
the longer-corridor \(si,sp_j\) returns of Note 396, other opening
types, or Barnette's conjecture. It is a
project-internal analytic proof without local
graph recomputation, independent review, or
an external priority claim.
