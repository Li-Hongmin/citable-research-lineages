> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A long-gap single hexagon forces a main face-side chord

[Notes 403--405](405-every-single-hexagon-opening-with-at-most-twelve-main-vertices-has-a-hamiltonian-child.md)
classify the first main-segment lengths for a selected
facial opening that traps one hexagon. Their planar
matching argument has an unbounded consequence: a long
opposite facial arc requires a further matching chord on
the common-face side of the main segment.

Use the setup of Note 403. A simple cubic bipartite plane
graph \(G\) has a Hamilton cycle
\[
C=(w_0,w_1,\ldots,w_{s-1},\alpha,a,b,c,d,\beta,w_0),
\qquad M=E(G)\setminus E(C).
\]
The disjoint matching edges
\(q=w_0w_j\), \(p=w_kw_{s-1}\), and
\(\alpha\beta\) lie on the same face, whose selected
alternating arc is
\(w_{s-1},\alpha,\beta,w_0\). In particular,
\(3\le j<k\le s-4\), \(j\) is odd, and \(k\) is even.
The internal chord \(ad\) may or may not belong to \(M\).

**Main face-chord theorem.** If \(k>j+1\), then \(M\)
contains an edge \(w_iw_h\) distinct from \(p,q\),
with both ends on the main segment and drawn on the
same side of \(C\) as the common face. Equivalently,
if the only main-segment matching edges on that side
are the site edges, the other facial arc between \(p,q\)
is the single old-cycle edge \(w_jw_k\).

The same conclusion holds if the six-vertex trapped
segment is replaced by any single even-vertex old-cycle
segment closed by its face-side matching edge
\(\alpha\beta\), provided at most four of its interior
vertices have matching neighbours in the main segment.
Its interior matching pattern is otherwise unrestricted.
Without the four-escape bound, the proof still shows the
exact necessary form of a face-chord-free long-gap
candidate: every main vertex other than the four site
ports must be an escape target. In particular it needs
at least six escape targets.

**Proof.** For the hexagon, since \(\alpha\beta\in M\), the four interior
hexagon vertices \(a,b,c,d\) have only two possible
matching patterns. Either \(ad\in M\) and \(b,c\)
have two distinct neighbours in the main segment, or
\(ad\notin M\) and all four have distinct main-segment
neighbours. Let \(T\) be this set of \(e\in\{2,4\}\)
escape targets. Every escape chord is on the side of
\(C\) opposite the common face: on the face side it
would interlace \(\alpha\beta\).

Suppose no further main-segment chord lies on the face
side. Remove the four site endpoints
\(w_0,w_j,w_k,w_{s-1}\) and the targets \(T\) from
the main-segment vertices; call the remaining ordered
set \(U\). Each vertex of \(U\) is matched to another
vertex of \(U\), and all those matching chords lie on
the side opposite the common face. Such a chord cannot
straddle a target \(w_t\in T\): if its endpoints have
indices \(i<t<h\), it interlaces the escape chord
from \(w_t\) to the hexagon. Hence the noncrossing
matching of \(U\) splits among the open intervals
between consecutive targets, including the two end
intervals.

If \(U\ne\varnothing\), choose a nonempty interval and
an innermost chord of its noncrossing matching. Its
endpoints are consecutive among that interval's
\(U\)-vertices. No target lies between them. The only
main vertices possibly between them are therefore the
site ports \(w_j,w_k\). With no site port between, the
chord duplicates an edge of \(C\). With exactly one,
its endpoints are separated by two old-cycle edges
and have the same bipartite colour. With both ports
between, \(k>j+1\) puts at least one vertex strictly
between \(w_j,w_k\); that vertex would belong to
\(U\) in the same interval, contradicting the choice
of consecutive endpoints. All three cases are
impossible, so \(U=\varnothing\).

It follows that \(s=4+e\le8\). If \(e=2\), then
\(s=6\), contradicting \(3\le j<k\le s-4=2\).
If \(e=4\), then \(s=8\), forcing
\((j,k)=(3,4)\), again contradicting \(k>j+1\).
Thus a further face-side main chord exists. For the
stated extension, use its number \(e\le4\) of escape
targets in exactly the same gap argument. If \(U\) is
empty, then \(s=4+e\le8\), again forcing the site
ports to be consecutive whenever they exist. With no
bound on \(e\), the same innermost-chord argument still
gives \(U=\varnothing\); long spacing requires
\(k\ge6\), hence \(s\ge10\) and \(e=s-4\ge6\).
\(\square\)

The statement needs neither three-connectivity nor a
bound on \(s\). It is sharp as a necessary condition:
the unique twelve-main long-gap graph of Note 405
has \((j,k)=(3,8)\) and precisely one further
face-side main chord, \(w_4w_7\); its two facial arcs
both have length three.

**Sharp order and equality matching.** The escape threshold
in the unrestricted version is attained in the Barnette
class. More precisely, every single-trap, long-gap parent
without a further face-side main chord has at least
twenty vertices. At order twenty its matching is forced
by the labelled old cycle and site, and it has a
Hamilton cycle through both site edges.

Indeed, let the trapped segment have \(m\) interior
vertices and \(e\) escape targets. The preceding proof
gives \(s=e+4\) and \(e\ge6\). Since the remaining
interior vertices are internally matched, \(m\ge e\)
and \(m-e\) is even; both \(m\) and \(e\) are even.
If \(e\ge8\), the total order
\(s+m+2\) is at least \(22\). If \(e=6\), then
\(s=10\) and the only long site positions are
\((j,k)=(3,6)\). The six targets are exactly
\(w_1,w_2,w_4,w_5,w_7,w_8\), whose index parities in
order are \(O,E,E,O,O,E\). Noncrossing escape chords
reverse their order on the trapped segment; the six
corresponding interior vertices, read backwards, must
therefore have parities \(E,O,O,E,E,O\).
With \(m=6\), all interior vertices escape and their
backwards parity word is \(E,O,E,O,E,O\), impossible.
Thus \(m\ge8\), giving order at least twenty.

At order twenty, write the trapped segment as
\(\alpha,z_1,\ldots,z_8,\beta\). Its backwards
interior parity word is \(E,O,E,O,E,O,E,O\).
The required six-letter word \(E,O,O,E,E,O\) is
obtained by deleting exactly \(z_6\) and \(z_3\):
if the second \(O\) came from the fourth or a later
position of the eight-letter word, reaching the next
\(O\) would already require at least three deletions.
Thus the first two letters remain; the repeated \(O\)
deletes the third letter \(z_6\), and the repeated
\(E\) deletes the sixth letter \(z_3\). These two
vertices must match each other.
The reverse target order then forces every escape
edge. This yields the following twenty-vertex cycle
\[
C=(w_0,w_1,\ldots,w_9,\alpha,z_1,z_2,z_3,z_4,
z_5,z_6,z_7,z_8,\beta,w_0)
\]
and unique complementary matching
\[
\begin{split}
M=\{&w_0w_3,w_6w_9,\alpha\beta,z_3z_6,\\
    &w_1z_8,w_2z_7,w_4z_5,w_5z_4,w_7z_2,w_8z_1\}.
\end{split}                                                   \tag{1}
\]
On the common-face side of \(C\), draw the two site
chords \(q=w_0w_3,p=w_6w_9\), \(\alpha\beta\), and
\(z_3z_6\), the last nested inside \(\alpha\beta\).
The six escape chords lie on the other side and are
nested in exactly the order written in (1). All matching
edges join opposite cycle parities, so the result is
simple, cubic, bipartite, and plane.

Its chord-interlacement graph is connected:
\(\alpha\beta\) interlaces every escape chord;
\(q\) interlaces \(w_1z_8\), \(p\) interlaces
\(w_7z_2\), and \(z_3z_6\) interlaces
\(w_4z_5\). A two-edge cut would bound a proper
old-cycle interval closed under the matching and
disconnect this interlacement graph. The Hamilton
cycle excludes bridges; in a cubic graph
three-edge-connectivity implies three-vertex-
connectivity. Hence this is a Barnette graph.
The site face has arcs
\(w_9,\alpha,\beta,w_0\) and
\(w_3,w_4,w_5,w_6\), both of length three.
There is no additional face-side chord with both
endpoints on the main segment. All six non-site
main vertices are escape targets, so \(e=s-4=6\).

This example also has the explicit Hamilton cycle
\[
\begin{split}
C'=(w_0,w_3,w_2,w_1,z_8,z_7,z_6,z_5,w_4,w_5,\\
\qquad z_4,z_3,z_2,w_7,w_6,w_9,w_8,z_1,\alpha,\beta,w_0),
\end{split}                                                   \tag{2}
\]
which contains both \(q\) and \(p\). Every consecutive
pair in (2) is either a cycle edge or listed in (1),
and each of the twenty vertices occurs once. The legal
site expansion is therefore Hamiltonian by
[Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md).

For at most four escapes, the forced face-side chord
need not by itself yield a Hamilton exchange; the
theorem does not establish Hamiltonicity for longer
main segments.
The face-chord conclusion applies to at most four
escape targets; the saturation and order statements
apply to any specified single trapped segment. None
resolves Barnette's conjecture.
[Note 407](407-a-nested-site-chord-keeps-a-long-opposite-face-arc-chord-free.md)
shows that the forced chord may be nested inside a site
chord rather than lie on the other facial arc.
