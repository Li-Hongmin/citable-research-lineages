> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An \(H^{+-}\) parent forces both \(P_2\) and \(H^-\) in a \(C_4\)-child

Let \(G\) be a cubic graph and let \(p=uv,q=xy\) be vertex-disjoint
edges at a legal \(C_4\)-expansion site.  Let \(H\) be the child obtained by
deleting \(p,q\), adding \(a,b,c,d\), and adding

\[
J=\{ua,ab,bv,xc,cd,dy,ad,bc\}.
\tag{1}
\]

Write \(R=E(G)\setminus\{p,q\}\).  The parent has the global
\(H^{+-}\)-property if, for every two distinct edges \(e,f\), it has a
Hamilton cycle containing \(e\) and avoiding \(f\).  The six traversal
types from [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
will be denoted

\[
A=D_{11},\quad B=D_{10},\quad C=D_{01},\quad
D=X_{vx},\quad E=X_{uy},\quad L.
\tag{2}
\]

## The one-step theorem

> **Theorem.** If \(G\) has the global \(H^{+-}\)-property, then every
> \(C_4\)-child \(H\) at such a site is both \(P_2\)-Hamiltonian and
> \(H^-\): every edge of \(H\) belongs to a Hamilton cycle and every edge
> is avoided by a Hamilton cycle.

The property \(H^{+-}\) supplies a Hamilton cycle of type \(B\) by taking a
cycle containing \(p\) and avoiding \(q\), and one of type \(C\) by reversing
the ordered pair.  Their gadget incidences are

\[
B:10101011,\qquad C:01010111
\tag{3}
\]

in the edge order of (1), so their direct lifts cover all eight new edges.

It remains to cover a retained edge \(g\in R\).  Choose an endpoint \(z\)
of \(g\), and choose an edge \(f\) incident with \(z\) that is different
from both \(g\) and \(p\).  The global \(H^{+-}\)-property gives a Hamilton
cycle \(K\) containing \(p\) and avoiding \(f\).  Since \(G\) is cubic,
the two edges used by \(K\) at \(z\) must include \(g\).  The cycle \(K\)
has type \(A\) if it contains \(q\), and type \(B\) otherwise.  In either
case its direct lift is a Hamilton cycle of \(H\) containing \(g\).  Thus
all edges in \(R\cup J\) are covered.

For avoidance, the same three traversal types suffice.  Among the rows

\[
A:11111100,\qquad B:10101011,\qquad C:01010111,
\tag{4}
\]

every gadget column contains a zero: \(C\) avoids \(ua,bv,cd\), \(B\)
avoids \(ab,xc,dy\), and \(A\) avoids \(ad,bc\).  Hence their lifts avoid
every new edge in turn.  For a retained edge \(g\), apply \(H^{+-}\) to
the ordered pair \((p,g)\).  The resulting parent Hamilton cycle contains
\(p\), avoids \(g\), and has type \(A\) or \(B\); its direct lift is a
Hamilton cycle of \(H\) avoiding \(g\).

The argument uses no planarity or bipartiteness beyond the hypotheses needed
to keep a chosen expansion inside the Barnette class.

## Exact new-edge separation boundary

The theorem cannot be upgraded to child \(H^{+-}\) merely by observing that
the new edges are covered.  The six gadget incidence rows are

\[
\begin{array}{c|c}
A&11111100\\
B&10101011\\
C&01010111\\
D&01111010\\
E&11001101\\
L&10110111.
\end{array}
\tag{5}
\]

The support sets of the eight columns are

\[
\begin{array}{c|c@{\qquad}c|c}
ua&ABEL&ab&ACDE\\
bv&ABDL&xc&ACDL\\
cd&ABDE&dy&ACEL\\
ad&BCDL&bc&BCEL.
\end{array}
\tag{6}
\]

They are eight distinct four-subsets of the six rows.  Hence for every
ordered pair of distinct gadget edges there is a row using the first and
avoiding the second if all six traversal types exist.  Conversely, each row
is forced by a private ordered pair:

\[
\begin{array}{c|c@{\qquad}c|c}
A&(ua,bc)&B&(ua,dy)\\
C&(ab,cd)&D&(ad,bc)\\
E&(bc,ad)&L&(ua,cd).
\end{array}
\tag{7}
\]

Therefore the child has \(H^{+-}\) on ordered pairs in \(J\times J\) if
and only if all six parent traversal types are available.

The parent \(H^{+-}\)-property automatically supplies \(A,B,C\).  The
first two were used above.  For \(A\), choose at \(x\) an edge \(r\ne q\)
and take a Hamilton cycle containing \(p\) and avoiding \(r\); cubicity
forces it to contain \(q\).  Thus, under the parent hypothesis,

\[
H\text{ has }H^{+-}\text{ on }J\times J
\quad\Longleftrightarrow\quad
X_{vx},X_{uy},L\text{ all exist in }G-\{p,q\}.
\tag{8}
\]

The linkage type \(L\) is not supplied by deleting \(p,q\) from an
\(A\)-cycle.  In the legal facial order, that deletion induces the pairing
\((uy)(vx)\), precisely the pairing excluded from \(L\).

The planarity and facial-order hypotheses in this remaining question are
substantive.  There is a 16-vertex cubic, bipartite, 3-connected graph with
global \(H^{+-}\) and a four-terminal site for which both cross Hamilton
paths \(X_{vx},X_{uy}\) are absent, although a legal \(L\)-linkage exists.
It is nonplanar, and exhaustive generation in the same relaxed class through
order 14 gives no smaller example.  Conversely, exhaustive generation of
all Barnette graphs through order 22 and all their directed legal sites
finds all three structures \(X_{vx},X_{uy},L\) at every site.  These are
finite boundary results, not a proof of (8); their frozen verifier is
`../scratch/worker-c4-hpm/verify_hpm_interface_boundary.py`.

## Full child \(H^{+-}\) interface

For a concrete parent traversal witness \(W\), write \(R(W)\subseteq R\)
for its retained-edge support and \(J_{\tau(W)}\subseteq J\) for its fixed
gadget incidence.  The full child has \(H^{+-}\) exactly when all four
conditions below hold:

1. for all distinct \(r,s\in R\), some \(W\) has
   \(r\in R(W)\) and \(s\notin R(W)\);
2. for all \(r\in R,j\in J\), some \(W\) has
   \(r\in R(W)\) and \(j\notin J_{\tau(W)}\);
3. for all \(j\in J,r\in R\), some \(W\) has
   \(j\in J_{\tau(W)}\) and \(r\notin R(W)\);
4. all six traversal types occur.

These are the four ordered-pair blocks
\(R\times R,R\times J,J\times R,J\times J\).  In particular, nonempty
traversal types cannot replace edge-decorated witnesses: the existential
witnesses for inclusion and avoidance must be the same concrete object.

## Scope and literature boundary

This note proves only the one-step implication

\[
G:H^{+-}\quad\Longrightarrow\quad H:(P_2\text{ and }H^-).
\tag{9}
\]

It does not prove that \(H\) again has \(H^{+-}\), and therefore cannot be
iterated along an arbitrary HMM expansion history.  The missing first
interface is (8), followed by the mixed and retained-edge separation
conditions above.  Possessing both \(P_2\) and \(H^-\) separately does not
by itself supply a single Hamilton cycle containing one prescribed edge and
avoiding another, so the stronger child property does not close this gap.

As checked against the accessible literature on 2026-08-25,
Gorsky--Steiner--Wiederrecht prove that cube-expansion preserves global
\(H^{+-}\) through tight-cut decomposition, whereas their general
\(C_4\)-expansion lemma preserves matching-coveredness and
2-extendability, not Hamiltonian properties.  Their finite computation gives
global \(H^{+-}\) through order 66, \(P_2\)-Hamiltonicity through order 78,
and Hamiltonicity through order 90.  No source inspected there states (9)
or the exact interface (5)--(8).  The stronger assertion that every legal
\(C_4\)-child of an \(H^{+-}\) parent again has \(H^{+-}\), if combined
with cube-expansion preservation and the HMM generation theorem, would
imply global \(H^{+-}\) for all Barnette graphs and hence Barnette's
conjecture.  It remains open here.
