> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Direct-cross matching has a rainbow end bridge

[Note 492](492-two-mixed-openings-reduce-end-middle-split-pairs-to-direct-cross-chords.md) reduces a possible failure with split nodes in the end root \(W_1\) and middle root \(W_2\) to the direct chords \(s_1t_2,t_1s_2\). The remaining inter-root matching has an exact order and parity. The two joined child words also have a spanning linkage retaining their closing chords. These statements concern this selected opening, not all Barnette graphs.

Keep all hypotheses and notation of Note 492, including connected root face graph \(K\), and assume its direct-cross conclusion
\[
                   s_1t_2,\ t_1s_2\in M.                  \tag{1}
\]
Write \(X_1^-\) for the special positions of \(W_1\) strictly before \(s_1\). Let \(h\) be the number of \(M\)-edges between \(W_1,W_3\), and let \(k\) be the number between the child words \(A_1,A_2\). By Note 491, \(k\ge2\) is even. The two site ports satisfy \(u<v\) in the main old-cycle order.

**Outer-bridge theorem.** The root face graph has exactly the support path \(W_2-W_1-W_3\). Its \(W_1W_2\) multiplicity is \(k+2\); its \(W_1W_3\) multiplicity is \(h\ge1\). All \(W_1W_3\) chords run from \(X_1^-\) to \(W_3\). If their left endpoints are \(x_1<\cdots<x_h\) and right endpoints are \(y_1<\cdots<y_h\), their pairing is exactly
\[
                  x_i y_{h+1-i}\in M\qquad(1\le i\le h). \tag{2}
\]
Moreover, \(v\in W_3\), and exactly one of the following two site patterns holds:

* \(u\in X_1^-\). Every \(x_i\) lies after \(u\), every \(y_i\) lies before \(v\), and \(h\) is odd.
* \(u\in W_3\). Every \(y_i\) lies before \(u<v\), and \(h\) is even, hence \(h\ge2\).

**Proof.** The \(A_1-A_2\) edges are the only matching edges incident with either child and leaving that child, by isolation of \(A_1\cup A_2\) in the double-inner opening. Note 492 proves that, after (1), every remaining special position of \(X_2\) and \(Y_2\) is matched within its own flank. Thus the only \(W_1W_2\) edges are the \(k\) child-to-child edges and the two edges in (1), and no \(W_2W_3\) edge exists.

An edge from \(W_1\) to \(W_3\) with its left endpoint strictly between \(s_1\) and \(t_2\) would interlace \(s_1t_2\) on the common-face side of the old Hamilton cycle. It cannot have its left endpoint in \(A_1\) by the preceding isolation. Its left endpoint is therefore in \(X_1^-\). Since \(K\) is connected and \(W_2W_3\) has no edge, at least one such \(W_1W_3\) edge exists. For \(i<j\), a pairing \(x_i y_a,x_j y_b\) with \(a<b\) has cyclic endpoint order \(x_i,x_j,y_a,y_b\) and crosses. The matching is consequently decreasing, proving (2).

Note 492 places both site ports in \(X_1^-\cup W_3\). If \(v\in X_1^-\), then \(v<s_1<t_2<w_*\), so the site edge \(p=vw_*\) crosses \(s_1t_2\). Hence \(v\in W_3\). If \(u\in X_1^-\), any \(x_i<u\) would give the crossing order \(w_0<x_i<u<y_{h+1-i}\) with \(q=w_0u\), and any \(y_i>v\) would give \(x_{h+1-i}<v<y_i<w_*\) with \(p\). Therefore \(u<x_i\) and \(y_i<v\). If \(u\in W_3\), an endpoint \(y_i>u\) would give \(w_0<x_{h+1-i}<u<y_i\) and cross \(q\); hence every \(y_i<u<v\).

Every special position of \(X_1^-\) belongs to a complete two-special leaf, so their number is even. Its matching edges have either both ends in \(X_1^-\), one end in \(W_3\), or one end at a site port: the other \(W_1W_2\) endpoints are accounted for above, while a chord from \(X_1^-\) into the remainder of \(W_1\) would meet \(s_1t_2\) or leave the isolated child component. Counting endpoints modulo two gives
\[
                   h\equiv |\{u,v\}\cap X_1^-|\pmod 2. \tag{3}
\]
Thus \(h\) is odd in the first site pattern and even in the second. The latter has \(h\ge2\) because \(h>0\). \(\square\)

**Retained-chord child linkage.** Let \(D_i\) be the old \(L_i\)--\(R_i\) arc of \(A_i\) closed by its ordinary chord \(L_iR_i\), and let \(M_A\) consist of all face-matching edges with both ends in \(A_1\cup A_2\). There is a Hamilton cycle of
\[
             D_1\cup D_2\cup M_A\cup
             \{\text{ordinary innermost leaf chords in }A_1\cup A_2\}
\]
that contains every edge of \(M_A\) and both closing chords \(L_1R_1,L_2R_2\). Deleting either closing chord gives a spanning Hamilton path between its endpoints; deleting both gives two vertex-disjoint spanning paths, each joining an endpoint of \(A_1\) to an endpoint of \(A_2\).

**Proof.** Within either \(A_i\), every special position belongs to a two-special leaf. No site port or matching edge leaves \(A_1\cup A_2\), and the \(k\ge2\) child-to-child matching edges make \(D_1\cup D_2\cup M_A\) connected. Apply the zero-terminal square-switch theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) to the two cycles \(D_1,D_2\), deleting the old edge of each two-special leaf and retaining \(M_A\). Switching along a quotient spanning tree merges all cycles and never deletes an edge of \(M_A\). A closing chord \(L_iR_i\) is outside every leaf-square support unless \(A_i\) itself is a single leaf. In that exceptional case the chord is already an edge of \(D_i\), so the corresponding deleted leaf edge is a quotient loop and is never switched. Both closing chords survive. Removing one or both edges from the resulting Hamilton cycle has the stated path consequences. \(\square\)

**Child-path normalization in the mixed openings.** In the \(F_{\mathrm{io}}\) opening (5) of Note 492, every componentwise leaf-square-spliced spanning path \(P\) meets \(S=A_1\cup A_2\) in one spanning \(L_2\)--\(R_2\) subpath. It can be replaced by the canonical path obtained above by deleting \(L_2R_2\) from the retained-chord child cycle. In the \(F_{\mathrm{oi}}\) opening (2), the analogous segment of the component containing \(S\) runs from \(L_1\) to \(R_1\) and can be replaced by deleting \(L_1R_1\). In either case the replacement preserves all vertices, all \(M_A\)-edges, the component's external attachments, and the order of the escape edges.

Indeed, in \(F_{\mathrm{io}}\) the only edges from \(S\) to its complement are \(s_2L_2,R_2t_2\): the two \(A_1\) boundary edges were deleted, and every matching edge at \(S\) stays in \(S\). A spanning path has no internal cycle, so its intersection with \(S\) is exactly one spanning path between \(L_2,R_2\). The \(F_{\mathrm{oi}}\) argument exchanges the indices. The canonical replacements have the same endpoints and vertex sets, and the escape edges lie outside \(S\). \(\square\)

The outer-bridge theorem leaves two explicit cases: parity permits \(h=1\) with split sites, whereas both sites in \(W_3\) require at least two nested bridge chords. Child-path normalization shows that the path-order obstruction of Note 493 depends on the outer shell and the rainbow bridge, rather than on how the \(k\) child-to-child chords are traversed. The results do not attach the middle-root complement to a single marked spanning path, nor establish a Barnette counterexample or a general proof.
