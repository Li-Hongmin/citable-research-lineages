> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two short blocks before an alternating triple have two Hamilton matchings

[Note 338](338-standard-short-corridors-before-an-alternating-triple-have-the-square-signature.md)
constructs a square-equivalent standard corridor of every
positive length and a different genuine matching at length
two. Here the two-block corridor is classified: those are
its only core matchings, and both have a spanning route.
Short blocks outside the core may occur on either side.

Work in the compressed, gapless, tight-target all-square
opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group with even left and
odd right endports \(L,R\). Its only nonshort complete blocks
are
\[
\begin{split}
D_1&=(a,o,h,i,k,j,e,b),\\
D_2&=(A,O,H,I,K,J,E,B),\\
D_3&=(\hat a,\hat o,\hat h,\hat i,\hat k,\hat j,\hat e,\hat b),
\end{split}                                               \tag{1}
\]
with internal chords \(ok=J_1,IE=J_3,\hat o\hat k=J_1\).
Exactly two short blocks
\(S_t=(c_t,o_t,e_t,d_t)\), \(t=1,2\), lie between
\(D_1,D_2\); \(D_2,D_3\) are adjacent. Every other
complete block is short and lies outside this
five-block core.

**Two-short-corridor theorem.** The complementary
matching inside \(D_1,S_1,S_2,D_2,D_3\) has exactly
one of these two types, in addition to the three
specified internal \(J_1/J_3\) chords:
\[
\begin{array}{c|l}
\mathrm{I}&
h\hat i,\ iK,\ jH,\ eo_1,\ e_1o_2,\ e_2O,\ J\hat h\\
\mathrm{II}&
h\hat i,\ iK,\ je_1,\ eo_1,\ o_2H,\ e_2O,\ J\hat h .
\end{array}                                               \tag{2}
\]
The ordinary matching outside the core is forced.
For either type the whole free group has a
vertex-spanning \(L\)--\(R\) path. Both types occur
in 44-vertex Barnette parents, and type II has a
marked Hamilton cycle through the two site edges.
Old-cycle reflection gives the corresponding
classification for \(J_3,J_1,J_3\) with two short
blocks between its final two double blocks.
If all other vacancies occupy distinct internal
blocks, the parent has a Hamilton cycle containing
both site edges and its legal site-expanded child
is Hamiltonian.

**Forced outer core.** Chord isolation from
[Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md)
leaves no other same-block free chord.
Every cross-block free chord lies opposite the
common face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
After the internal chord endpoints are removed,
the core free slots occur in the order
\[
h,i,j,e,o_1,e_1,o_2,e_2,O,H,K,J,
\hat h,\hat i,\hat j,\hat e.                            \tag{3}
\]
As in Note 338's one-short argument, \(h\) can
meet only \(J\) or \(\hat i\). Every candidate
ordinary odd slot outside this core encloses
an odd number of residual free slots; within it,
the candidates \(o_1,o_2,O,\hat j\) do likewise.
If \(hJ\) occurred, the even slot \(\hat h\)
could not reach any interior slot without
crossing \(hJ\); its same-block choices are an
old-cycle edge or an isolated forbidden chord,
and every outer ordinary odd candidate again
encloses an odd number of slots. Thus
\(h\hat i\) is forced.

Inside \(h\hat i\), the odd slot \(i\) can
meet only \(K\) or \(\hat h\).
The same-block \(ie\) chord is excluded,
while \(ie_1,ie_2,iH\) enclose respectively
3, 5 and 7 other free slots. If
\(i\hat h\) occurred, its interior would be
\(j,e,o_1,e_1,o_2,e_2,O,H,K,J\).
The first slot \(j\) could meet only
\(e_1,e_2,H,K\):

- If \(je_1\), its interior forces \(eo_1\).
  The remaining \(o_2,e_2,O,H,K,J\) cannot
  match: \(o_2H\) would force \(e_2O\) and
  leave the old-cycle pair \(KJ\); the other
  mates of \(o_2\) are invalid or trap a slot.
- If \(je_2\), its interior forces
  \(eo_1,e_1o_2\), leaving
  \(O,H,K,J\), which has no matching.
- If \(jH\), the remaining \(K,J\) would
  have to use their old-cycle edge.
- If \(jK\), it encloses seven other slots.

Thus \(i\hat h\) is impossible and \(iK\)
is forced. The two residual slots \(J,\hat h\)
inside \(h\hat i\) now pair with each other.

**The two inner types.** The eight free slots
inside \(iK\) are
\[
j,e,o_1,e_1,o_2,e_2,O,H.                             \tag{4}
\]
The odd slot \(j\) may meet only \(e_1,e_2,H\).
If \(je_2\), the four enclosed slots uniquely
pair as \(eo_1,e_1o_2\), leaving the forbidden
old-cycle pair \(OH\). If \(je_1\), its
interior forces \(eo_1\), and the four
remaining slots force \(o_2H,e_2O\).
This is type II.

If \(jH\), then \(e,o_1,e_1,o_2,e_2,O\)
must pair internally. Matching \(e\) to
\(o_2\) would trap the old-cycle pair
\(o_1e_1\). Matching \(e\) to \(o_1\)
forces \(e_1o_2,e_2O\), giving type I.
The remaining candidate \(eO\) would force
\(o_1e_2,e_1o_2\). Then the entire
consecutive interval \(S_1,S_2\) would be
closed under the complementary matching;
its face chords stay inside, leaving only
two old-cycle boundary edges. This violates
three-edge-connectivity. The list (2) is
therefore complete, independently of the
outer short flanks.

**Outer links and Hamilton route.** Once either
core type is fixed, the only unmatched free
slots inside the five-block core are the
ordinary odd/even pair \(\hat j,\hat e\).
The standard skipping-and-two-edge-cut
argument of [Note 275](275-every-vacancy-only-noncrossing-matching-is-marked-hamiltonian.md)
forces ordinary links through every outer
short block. In detail, a skipped complete
short-block interval would be matching-closed;
skipping the entire core would close that
five-block interval, because all its other
matching edges are internal. Thus the left
outer chain ends at \(\hat j\), and the
right outer chain begins at \(\hat e\).

For type I, use the spanning
\(\hat j\)--\(\hat e\) path of the
standard \(P_2\) patch in Note 338(9).
For type II, use the explicit
\(\hat j\)--\(\hat e\) path in
Note 338(12). Prepend the ordinary
left-flank five-vertex routes, and append
the right-flank five-vertex routes, using
each shared endport only once. The result
is a simple spanning \(L\)--\(R\) path.
These routes replace only the ordinary
free-path segment in Note 324's two-path
construction. Other free groups with
distinct internal-block vacancies compose
independently, giving the marked parent
Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
then gives the legal child's Hamilton cycle.

The standard type I has a 44-vertex
Hamiltonian Barnette realization by
Note 338's \(k=2\) construction.
The type II realization, its connected
matching-chord interlacement certificate,
and an explicit marked Hamilton cycle
are given in Note 338(11)--(13).
Both types are therefore genuine; the
classification does not rely on a
candidate matching that cannot occur
in a three-connected plane graph.
\(\square\)

This theorem covers exactly two internal
short blocks in the displayed position
and arbitrary outer short flanks. Longer
internal corridors are classified in
[Note 340](340-a-k-block-corridor-before-an-alternating-triple-has-exactly-k-matching-types.md).
The other placement,
other internal chord types, singly vacant
blocks in the same group, target defects,
positive gaps, non-square residual cycles
and the general Barnette conjecture are
not settled here. This is a project-internal
analytic argument with no external
priority or independent review claimed.
