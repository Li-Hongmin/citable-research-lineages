> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Good sibling or non-rooted portal covers the frozen mixed-sector family

[Notes 125](125-a-prescribed-mixed-hamilton-overlay-need-not-contain-its-escape.md)
and [126](126-even-the-complete-parent-rooted-support-need-not-contain-a-child-escape.md)
show that neither a prescribed mixed neighbour nor the complete parent
rooted-support union must contain a same-sector child escape.  [Note 127](127-single-cycle-portals-and-hamilton-suppliers-need-not-coincide.md)
then separates single-cycle exchange from Hamilton-complement supply.

The complete frozen family reveals a sharper two-mechanism boundary.  Every
eligible endpoint is repaired either by a mixed rooted sibling or by a
same-sector non-rooted single-cycle portal.  The two mechanisms overlap but
neither contains the other.  This is an exact finite statement on (112)
actual legal-wide brace endpoints, not yet a theorem for arbitrary splits.

## 1. Two productive one-cycle mechanisms

Fix a sterile state-(11) rooted endpoint \(\chi^b\) satisfying

\[
 {\cal M}_\chi\ne\varnothing,
 \qquad
 {\cal E}_\chi=\varnothing,
\tag{1}
\]

and let \({\cal X}^b\) be the same-sector child targets in the three new
cells.  Put (E_{\rm ret}=E(G)\setminus\{p,q\}).

A **productive good sibling** is an
\(\eta\in{\cal M}_\chi\) for which some (N\in{\cal X}^b) satisfies

\[
 N\cap E_{\rm ret}
 \subseteq(\chi\cup\eta)\cap E_{\rm ret}.
\tag{2}
\]

A **productive non-rooted portal** is a parent perfect matching (Q) such
that:

1. (Q) contains the root and forced gate, has sector (b), and is not a
   rooted target;
2. (Q\mathbin\triangle\chi) is one alternating cycle, avoids the three
   labelled root/gate edges, contains both site edges, and changes state
   (11) to (00);
3. some (N\in{\cal X}^b) satisfies

   \[
   N\cap E_{\rm ret}
   \subseteq(\chi\cup Q)\cap E_{\rm ret}.
   \tag{3}
   \]

Let (G) and (P) denote existence of the two mechanisms.  Both are
one-alternating-cycle statements in the complete parent perfect-matching
family; they differ in gate parity and in whether the neighbour remains
root-admissible before the split.

## 2. Exact finite dichotomy

The frozen Note-110 family contains (323) actual nonsquare kill-cover
splits through parent order (26).  Reconstructing every parent and child
perfect-matching family and imposing (1) leaves (112) decorated endpoints.
On this complete finite family,

\[
 |G|=18,qquad |P|=102,qquad
 |G\cap P|=8,qquad |G\cup P|=112.
\tag{4}
\]

Equivalently,

\[
\begin{array}{c|r}
\text{portal only}&94\\
\text{good sibling only}&10\\
\text{both}&8\\
\text{neither}&0.
\end{array}
\tag{5}
\]

Thus every failure of the portal mechanism is repaired by a mixed good
sibling, and every failure of good-sibling selection is repaired by a
non-rooted portal.  In particular,

\[
\boxed{G\lor P}
\tag{6}
\]

holds on all (112) actual endpoints.  Hit (8) of Note 126 is portal-only;
hit (29) of Note 125 is good-sibling-only.  These fixed examples prove
that neither branch can be deleted.

The same enumeration also closes the more restrictive two-hub explanation
suggested by Note 127.  Requiring a portal and a Hamilton-complement supplier
joined by no exchange or one (C_4/C_6) exchange succeeds on only (84)
endpoints; allowing several components of total length at most (12) reaches
only (86).  Hence (6), rather than a universal short two-hub factorization,
is the strongest surviving finite pattern.

## 3. Productive incidence has no parity explanation

Count productive sibling--target and portal--target incidences by

\[
 G_\#,qquad P_\#,qquad T=G_\#+P_\#.
\tag{7}
\]

Across the (112) endpoints,

\[
\begin{array}{c|rrrrrr}
&G_\#&P_\#&T&|{\cal X}^b|&|{\cal M}_\chi|&D_\chi\\ \hline
\text{sum}&52&458&510&732&298&404\\
\text{minimum}&0&0&1&2&1&1\\
\text{maximum}&3&14&14&15&8&9,
\end{array}
\tag{8}
\]

where (D_\chi) is the complete rooted-fibre one-cycle degree of \(\chi\).
The productive total (T) is odd at (90) endpoints and even at (22).
Its parity disagrees with the target, mixed-neighbour, and rooted-degree
counts at respectively (54,36,86) endpoints.

More strongly, exhaustive exact linear algebra on

\[
 (G_\#,P_\#,T,|{\cal X}^b|,|{\cal M}_\chi|,D_\chi,1)
\tag{9}
\]

finds only the defining relation

\[
 T=G_\#+P_\#
\tag{10}
\]

over both \(\mathbb Q\) and \(\mathbb F_2\).  There is no other affine
identity.  Consequently the positivity in (6) is not a projection of
ordinary Hamilton parity, endpoint degree, or a handshake count.

## 4. Strict local boundary

The implication (X\ne\varnothing\Rightarrow G\lor P) is not forced by
the local (C_4)-patch matching equations, a common complete
perfect-matching family, and one-cycle adjacency alone.

Take three disjoint cubes and expand two opposite edges of a facial square
in the middle cube.  The parent and child have complete families of

\[
 9^3=729,qquad 9^2\cdot20=1620
\tag{11}
\]

genuine perfect matchings.  Declare the fixed matching \(\chi\) and the
opposite-sector one-cycle neighbours in the middle cube rooted, declare the
same-sector neighbours non-rooted, and choose a child (R_{00}) matching
which also flips a remote square in the third cube.  The resulting abstract
relational model has

\[
 (|{\cal M}_\chi|,|{\cal E}_\chi|,|{\cal X}^b|)=(3,0,1),
 \qquad G=P=0,
\tag{12}
\]

because every one-cycle neighbour misses the two remote retained edges.

This is a strict abstract countermodel, not an actual legal-wide brace: it
is disconnected, and its rooted predicate is declared rather than derived
from two Hamilton-complement cycles separating the labelled root.  It proves
that (6) cannot be established from local matching algebra or single-cycle
exchange alone.  Any general proof must use the omitted global coupling,
at minimum connected-brace closure together with the topological definition
of root separation.

## 5. Remaining statement

The finite result and abstract boundary isolate the following actual-graph
candidate:

\[
\boxed{
\begin{gathered}
G\text{ a connected plane cubic bipartite brace,}\
\chi^b\text{ a sterile state-}11\text{ endpoint satisfying (1)}
\\[1mm]\Longrightarrow\\[1mm]
\text{a productive gate-odd rooted sibling or a productive}\
\text{gate-even non-rooted portal exists.}
\end{gathered}}
\tag{13}
\]

Statement (13) would imply mixed-sector survival, but it is not proved here.
The next proof must couple the full perfect-matching family to the global
root-component topology; parity, rooted-support coverage, a prescribed
overlay, one Hamilton hub, and short two-hub exchange are all insufficient.

The frozen computation and local boundary are reproduced by the
[good-sibling/portal dichotomy bundle](../computations/bundles/good-sibling-portal-dichotomy/README.md).

