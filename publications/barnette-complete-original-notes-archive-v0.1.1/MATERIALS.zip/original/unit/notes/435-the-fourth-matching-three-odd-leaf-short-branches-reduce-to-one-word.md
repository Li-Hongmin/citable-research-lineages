> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's three-odd-leaf short branches reduce to one word

[Note 434](434-the-fourth-face-matching-six-odd-leaf-word-has-a-marked-cycle.md) proves that a hypothetical non-Hamiltonian legal row-IV child in the two-eligible, chorded single-hexagon $f=7,c=31$ kernel must have three odd-depth leaves in its seven-leaf full binary tree. This note classifies its short **branch**. A short leaf remains a separate case.

Let $v$ be the unique short node, at odd depth, and let $E_v,O_v$ count even- and odd-depth leaves below it. The parity identity of [Note 425](425-short-wrapper-parity-and-terminal-spine-paths.md) becomes
\[
 E_v-O_v=-1.                                           \tag{1}
\]
Thus a short branch has either three leaves, with $(E_v,O_v)=(1,2)$, or five leaves, with $(E_v,O_v)=(2,3)$. The site leaves are the two eligible leaves. Row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md) permits ineligible sibling pairs only at $b\mid c$ and $d\mid e$; a sibling pair of site leaves is Hamiltonian by [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md).

**Short-branch theorem.** A hypothetical non-Hamiltonian legal row-IV child cannot have a five-leaf short branch. If it has a three-leaf short branch, then its sites are $(j,k)=(1,7)$ and its word is necessarily
\[
\begin{aligned}
 A&=F(U_3,U_4),& B&=F(U_5,U_6),\\
 V&=F_0(B,U_7),& D&=F(A,V),\\
 E&=F(U_2,D),& W&=F(U_1,E),
\end{aligned}                                                    \tag{2}
\]
where $F(P,Q)=(((P Q)))$, $F_0(P,Q)=((P Q))$, and all leaves are full. The leaf-depth vector is $(1,2,4,4,5,5,4)$ and $V$ is short at depth three. Its row-IV face matching is
\[
 x_2y_6,\quad y_2x_3,\quad y_3x_6,\quad x_4y_5,\quad y_4x_5. \tag{3}
\]
The theorem is a necessary classification; it does not assert that (2)--(3) is legally realizable or non-Hamiltonian.

**Proof: five-leaf short branch.** With $(E_v,O_v)=(2,3)$, $v$ has five leaves and only two leaves lie outside it. Since $v$ has odd depth, it must be a child of the root; the other root child is a two-leaf cherry at global depth two. Both outside leaves are even-depth, unflipped and therefore ineligible. For site placement $(1,7)$, either extreme two-leaf block contains a site, so this is impossible. For sites $(1,2)$, the outside cherry must be leaves $(6,7)=(d,e)$ and $v$ contains leaves $1,\ldots,5$.

Inside $v$, even global depth means odd depth relative to $v$. Hence its ordered relative leaf-parity word is $OOEEE$: the first two leaves are sites, and the last three are ineligible. Apply the root-split recurrence of [Note 419](419-depth-parity-forces-three-odd-leaves-in-the-maximal-seven-face-chord-kernel.md), as used in [Note 427](427-the-first-five-leaf-matching-reduces-to-six-short-wrapper-words.md): a possible left block has signed sum $-1\pmod3$, with $O=-1,E=+1$. For $OOEEE$, the only splits are $1\mid4$ and $3\mid2$. In the $1\mid4$ split the right four-leaf relative word is $EOOO$, whose middle leaves $(3,4)=(a,b)$ are siblings, forbidden in row IV by Note 426. In the $3\mid2$ split the left three-leaf relative word is $EEO$, whose first two leaves are the site pair $(1,2)$; Note 424 supplies a Hamilton cycle. Both splits contradict a non-Hamiltonian child.

**Proof: three-leaf short branch.** Here $(E_v,O_v)=(1,2)$. A full binary three-leaf subtree has one leaf child at relative depth one and a sibling pair at relative depth two. Since $v$ has odd global depth, the lone leaf is the unique even-depth leaf below $v$, hence a site. The sibling pair consists of two ineligible leaves and must be $b\mid c$ or $d\mid e$ by Note 426. The three leaves below $v$ form a consecutive interval with the site at one end. With sites $(1,2)$, neither permitted pair is adjacent to a site in such an interval. With sites $(1,7)$, the only possibility is the interval $(5,6,7)$: ineligible pair $(5,6)=(d,e)$ and site leaf 7. Thus $V=F_0(F(U_5,U_6),U_7)$.

Four leaves lie outside $V$. Its odd depth is therefore one or three. At depth one, the other root child is a four-leaf tree on leaves $1,2,3,4$. Its global depth parity must be odd at site 1 and even at the ineligible leaves 2,3,4, so the relative parity word is $EOOO$. That word has its middle leaves $(2,3)=(a,b)$ as siblings, excluded by Note 426.

At depth three, collapse $V$ to one leaf. The resulting five-leaf skeleton has ordered parity word $OEEEO$ on $(1,2,3,4,V)$: site 1 and $V$ have odd depth, while leaves 2,3,4 have even depth. The same root-split recurrence allows $1\mid4$ and $4\mid1$. The $4\mid1$ split places $V$ at depth one and is already excluded. In the $1\mid4$ split the right child has relative parity word $OOOE$ and its unique ordered tree has leaves $(2,3,4,V)$ at relative depths $(1,3,3,2)$. Thus the full skeleton is
\[
 F\bigl(U_1,F(U_2,F(F(U_3,U_4),V))\bigr),
\]
which is exactly (2). The depths and face chords follow directly. \(\square\)

Combining Notes 433--435, a hypothetical non-Hamiltonian row-IV/V child in this kernel must have three odd-depth leaves and either the one short three-leaf branch word (2), or a short leaf at odd depth. The Hamiltonicity and legality of (2), the short-leaf words, row VI, and Barnette's conjecture remain open.
