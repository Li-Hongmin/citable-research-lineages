> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Depth parity forces three odd leaves in the maximal chorded seven-face-chord kernel

Consider the chorded single-hexagon, \(f=7\) setting and the doubly reduced normal form of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md). At its upper ordinary-chord count \(c=32\), the seven-leaf tree cannot have arbitrary depth parity. This restriction applies to every such candidate, independently of whether its expanded child is Hamiltonian.

Number the leaves \(1,\ldots,7\) in old-cycle order, and call their two consecutive special positions \(x_i,y_i\). Write the inner site ports as \(y_j,x_k\), where \(j<k\), as in Note 416. Root depth is zero, and \(d_i\) is the depth of leaf \(i\).

**Three-odd-leaf theorem.** Exactly three leaves have odd depth, including \(j\) and \(k\). If \(r\) is the third odd-depth leaf, then either \(r<j\) or \(r>k\). The three face-side chords incident with the exterior special positions and these odd-depth leaves are forced:
\[
\begin{array}{c|ccc}
r<j&z_Lx_r&y_rx_j&y_kz_R\\
r>k&z_Lx_j&y_kx_r&y_rz_R.
\end{array}                                                       \tag{1}
\]
The four even-depth leaves belong to the three groups before \(j\), strictly between \(j,k\), and after \(k\), with group sizes, in some order, either \((4,0,0)\) or \((2,2,0)\). In particular, no one of these groups can contain exactly one even-depth leaf. The example in [Note 418](418-the-ninety-four-vertex-seven-face-chord-kernel-is-realizable-and-hamiltonian.md) attains the \((0,4,0)\) distribution and the first row of (1).

**Proof.** Equality \(c=32\) in Note 410's charge, together with Note 416's seven marked leaves and six unmarked binary branches, means that each leaf has one plain-unary wrapper and each branch has two. Thus every leaf word is \(U_i=((x_i y_i))\), every branch word is \(F(P,Q)=(((P Q)))\), and the whole ordinary forest is one ordered full binary tree. Its word begins at old-cycle index 3 in the normal order
\[
w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta.
\]
Every preceding sibling word has even length. Entering one branch contributes three opening parentheses, and \(x_i\) is two positions after the start of its leaf word. Therefore
\[
                  \operatorname{index}(x_i)\equiv3+3d_i+2
                         \equiv d_i+1\pmod2.                     \tag{2}
\]
The outer site endpoints \(w_0,w_*\) have even and odd indices respectively. Because \(w_0y_j\) and \(x_kw_*\) are edges of a bipartite graph, \(x_j,x_k\) both have even indices. Equation (2) gives \(d_j,d_k\) odd.

Let \(a,b\) count even- and odd-depth leaves. Begin with a single root leaf. Replacing a leaf at depth \(d\) by an internal binary node and two child leaves changes \(a-b=\sum_i(-1)^{d_i}\) by \(-3(-1)^d\). Hence \(a-b\equiv1\pmod3\) for every full binary tree. Since \(a+b=7\), we have \(a\equiv1\pmod3\), so \((a,b)\) is one of \((7,0),(4,3),(1,6)\). The two odd site leaves exclude \((7,0)\).

The site chords and planarity divide the face-side special terminals into three independently matched, linearly ordered groups:
\[
\begin{aligned}
L&=(z_L,x_1,y_1,\ldots,x_{j-1},y_{j-1},x_j),\\
M&=(x_{j+1},y_{j+1},\ldots,x_{k-1},y_{k-1}),\\
R&=(y_k,x_{k+1},y_{k+1},\ldots,x_7,y_7,z_R).
\end{aligned}                                                     \tag{3}
\]
In any noncrossing perfect matching of one such line, matched terminals have opposite rank parity: all terminals strictly between the ends of a chord must be matched among themselves. In each of (3), \(x\)-terminals have one rank parity and \(y\)-terminals the other. Consequently every face chord between two leaves joins an \(x\) to a \(y\). Since \(y_h\) has index parity opposite to \(x_h\), bipartiteness and (2) imply that such a chord can join only leaves of the same depth parity. The edge \(x_iy_i\) within one leaf is an old-cycle edge and cannot be a complementary matching chord.

If \((a,b)=(1,6)\), the unique even-depth leaf is neither site leaf. Both of its special terminals need face-side mates in one group of (3). They cannot pair to each other, and there is no second even-depth leaf. At most one of them could pair to the sole exterior terminal \(z_L\) or \(z_R\) in that group. Thus one remains unmatched, a contradiction. Hence \((a,b)=(4,3)\).

The third odd-depth leaf \(r\ne j,k\) cannot lie in \(M\). That group has no exterior terminal, and its other full leaves are even-depth; the same matching argument would force \(x_ry_r\). Therefore \(r<j\) or \(r>k\). In the first case the only odd-depth leaf terminals of \(L\) are \(x_r,y_r,x_j\). They must match among themselves together with \(z_L\). Pairing \(x_ry_r\) is forbidden, and the opposite-rank rule leaves exactly \(z_Lx_r,y_rx_j\). On the right, \(y_k\) is the only odd-depth leaf terminal, so it pairs to \(z_R\). This gives the first row of (1). The reflected argument gives the second row.

Each even-depth leaf contributes its pair \(x_i,y_i\) to exactly one group of (3). Its mates cannot be odd-depth leaves, and an exterior terminal is already committed by (1). Thus a group with exactly one even-depth leaf would require its forbidden self-pair. Four even-depth leaves split among three groups with no group of size one only as \((4,0,0)\) or \((2,2,0)\), up to permutation. Finally, Note 418 has odd-depth leaves \(1,2,7\), site leaves \(j=2,k=7\), and all four even-depth leaves \(3,4,5,6\) in \(M\). It realizes the claimed boundary. \(\square\)

This theorem is a necessary restriction on the \(c=32\) branch. It does not by itself give a Hamilton cycle for all admissible face matchings, nor does it constrain the \(c=31\) branch in the same form.

**Four-middle-leaf corollary.** Suppose all four even-depth leaves lie strictly between the site leaves. Then \((r,j,k)=(1,2,7)\) or its reflected case \((7,1,6)\). For the first case put \((a,b,c,d)=(3,4,5,6)\). The face matching on these four leaves has exactly the following three possibilities:
\[
\begin{array}{c|l}
\mathrm{I}&x_ay_b,\ y_ax_b,\ x_cy_d,\ y_cx_d\\
\mathrm{II}&x_ay_d,\ y_ax_b,\ y_bx_c,\ y_cx_d\\
\mathrm{III}&x_ay_d,\ y_ax_d,\ x_by_c,\ y_bx_c.
\end{array}                                                       \tag{4}
\]
In a legal hypothetically non-Hamiltonian child, a sibling pair joined by a face chord has two exclusions. If its other two special terminals attach outside the pair, Note 412 compresses the induced odd pole and Note 414 proves Hamiltonicity. If the other two terminals pair to each other, the twelve leaf vertices have only two edges to the rest of the cubic graph, contradicting three-connectivity. A full binary tree has a sibling-leaf pair. The pair \((1,2)\) cannot be siblings because its forced chord \(y_1x_2\) has the first exclusion, while the boundaries \((2,3),(6,7)\) have opposite depth parity and cannot be sibling pairs. Hence a sibling pair lies among \((3,4),(4,5),(5,6)\). If it is \((4,5)\), only matching I survives both exclusions; if it is \((3,4)\) or \((5,6)\), only matching III survives. Matching II is excluded in every case. Note 418 realizes matching III and proves its particular tree Hamiltonian.

To check (4), pair the first terminal \(x_a\) in the noncrossing matching. Its mate cannot be \(y_a\). If it is \(y_b\), the inner terminals force \(y_ax_b\) and the last two leaves pair as in I. It cannot be \(y_c\), since the remaining final leaf would have to pair to itself. If it is \(y_d\), the next terminal \(y_a\) can pair only to \(x_b\) or \(x_d\); these choices force II and III respectively. This also proves that the list is complete. \(\square\)

**Two-tree corollary.** In the four-middle-leaf case, a hypothetical non-Hamiltonian child has, up to reflection, the face matching of Note 418 and exactly one possible ordinary tree word:
\[
\begin{aligned}
A&=F(U_3,U_4),&B&=F(U_2,A),&C'&=F(B,U_5),\\
D&=F(U_1,C'),&E&=F(D,U_6),&W_{\rm alt}&=F(E,U_7).
\end{aligned}                                                     \tag{5}
\]
This is an exact necessary reduction within this one distribution. [Note 420](420-every-maximal-seven-face-chord-kernel-with-four-middle-even-leaves-is-hamiltonian.md) subsequently gives a Hamilton cycle for the child built from (5), completing the four-middle-leaf case.

To prove it, again use \(\sum(-1)^{\text{relative leaf depth}}\equiv1\pmod3\) in each full subtree. If a subtree has a prescribed \(E/O\) parity word relative to its root, the signed sum of each child block *before flipping parity* must be \(-1\pmod3\). For the words encountered in the first case of the previous corollary, the only root splits that pass this test are
\[
\begin{array}{c|l}
OOEEEEO&1|6,\ 3|4,\ 6|1\\
EOOOOE&3|3\\
EEOOOO&2|4,\ 5|1\\
OOEEE&1|4,\ 3|2\\
EOOO&3|1.
\end{array}                                                       \tag{6}
\]
The bar separates left and right leaf counts. At the top split \(3|4\), the left child has relative word \(EEO\), forcing siblings \((1,2)\); their forced chord \(y_1x_2\) is serial and the child is Hamiltonian by Notes 412 and 414. At the top split \(1|6\), the right child has relative word \(EOOOOE\) and splits \(3|3\). The two three-leaf shapes are forced, giving exactly the word of Note 418, whose child is Hamiltonian.

At the top split \(6|1\), the left child's relative word is \(EEOOOO\). Its split \(2|4\) again makes \((1,2)\) siblings. The other split is \(5|1\); the resulting five-leaf relative word \(OOEEE\) can split \(3|2\), which also makes \((1,2)\) siblings, or \(1|4\). The remaining four-leaf relative word is \(EOOO\), which splits only \(3|1\), and its three-leaf shape forces siblings \((3,4)\). These forced splits produce precisely (5). In both remaining words the pair \((3,4)\) is sibling. Matching I pairs both leaves wholly to each other, creating a two-edge cut; matching II has the compressible single joining chord \(y_3x_4\). Thus matching III is forced. Together with (1), it is exactly the seven-face-chord list of Note 418. As the trapped hexagon and outside matching are fixed in Note 416, (5) specifies the only remaining labeled graph in this four-middle-leaf branch. \(\square\)
