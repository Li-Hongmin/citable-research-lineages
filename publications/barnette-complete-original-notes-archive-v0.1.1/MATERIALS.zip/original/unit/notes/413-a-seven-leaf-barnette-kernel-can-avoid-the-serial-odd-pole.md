> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A seven-leaf Barnette kernel can avoid the serial odd pole

[Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md) reduces a hypothetical first single-hexagon failure at \(f=6\) to a seven-leaf ordinary-chord forest. [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md) makes the child Hamiltonian if a consecutive sibling pair of leaf modules is joined by its inner face-side chord. The extremal forest shape alone does not force that chord, even for a genuine Barnette parent and a legal facial opening.

Use a parenthesis word to describe a Hamilton cycle together with ordinary matching chords: every matched pair of parentheses is one chord, and the symbols \(x_i,y_i\) are distinct vertices. Define
\[
 U_i=((x_i y_i)),\qquad F(A,B)=(((A B))),
\]
and take the 78-symbol word
\[
 W=F\bigl(F(F(F(U_1,U_2),F(U_3,U_4)),U_5),F(U_6,U_7)\bigr). \tag{1}
\]
Thus each leaf has one plain-unary wrapper, each of the six branches has two, and the branch tree has sibling-leaf pairs \((1,2),(3,4),(6,7)\). The seven leaves have depths \(4,4,4,4,2,2,2\), respectively.

Let \(C\) be the 90-vertex cycle whose displayed order is
\[
 w_0,t_1,t_2,W,t_3,t_4,w_*,\alpha,a,b,c,d,\beta,w_0. \tag{2}
\]
The ordinary chords are the 32 parenthesis pairs in \(W\). Add these thirteen other matching edges:
\[
\begin{array}{c|l}
\text{site}&q=w_0x_1,\quad p=y_7w_*\\
\text{main face}&y_1x_4,\ x_2y_3,\ y_2x_3,\ y_4x_7,\ x_5y_6,\ y_5x_6\\
\text{escape}&t_1d,\ t_2c,\ t_3b,\ t_4a\\
\text{trap closure}&\alpha\beta.
\end{array}                                                        \tag{3}
\]
Call the resulting graph \(G\). Its \(C_4\)-expanded child at \(p,q\) is \(G^+\).

**Seven-leaf realization theorem.** The graph \(G\) is a 90-vertex Barnette graph; \(p,q\) form a legal cofacial expansion site, so \(G^+\) is a 94-vertex Barnette graph. The selected facial arc \(w_*,\alpha,\beta,w_0\) traps exactly the chord-free hexagon \((\alpha,a,b,c,d,\beta)\). It has \(e=4\) escape edges and \(f=6\) additional face-side main chords. Its ordinary forest is already doubly reduced under Note 410, with \(c=32\) and the seven-leaf equality shape of Note 411. None of its three consecutive sibling-leaf pairs has the joining chord required by Note 412. The expanded child is nevertheless Hamiltonian by an explicit two-edge cycle merger. Thus the existence of that particular serial odd-pole reduction cannot be deduced from the seven-leaf shape, bipartiteness, planarity, three-connectivity and legality of the selected site alone.

**Order, matching and colours.** Every \(U_i\) has six symbols and every \(F\) contributes six, so \(|W|=7\cdot6+6\cdot6=78\). Equation (2) has \(1+2+78+2+1+6=90\) distinct vertices. Equation (3), together with the parenthesis pairs, matches every vertex once: \(x_1,y_7\) are the two site ports; the other twelve \(x_i,y_i\) are the six face-chord endpoints; \(t_1,\ldots,t_4\) escape; and \(\alpha,\beta\) pair internally. No added edge is a cycle edge.

Index \(w_0\) by 0 along \(C\). The word \(W\) starts at index 3. At each branch, entering either child crosses three opening parentheses and, for the right child, an even-length left word. Since all leaf depths in (1) are even, every \(x_i\) has odd index and every \(y_i\) even index. Each parenthesis chord has endpoints of opposite parity because its interior has even length. The six face chords in (3), \(q\) and \(p\) also join opposite parities; \(w_*\) has index 83. Finally \(t_1,t_2,t_3,t_4\) have indices \(1,2,81,82\), while \(\alpha,a,b,c,d,\beta\) have indices \(84,85,86,87,88,89\). All escape edges and \(\alpha\beta\) join opposite parities. Hence \(G\) is simple, cubic and bipartite.

**Embedding and selected face.** Draw the site edges, six main-face edges and \(\alpha\beta\) on one side of \(C\). In special-vertex order the two groups of three face chords are
\[
 y_1\,x_2\,y_2\,x_3\,y_3\,x_4,
 \qquad y_4\,x_5\,y_5\,x_6\,y_6\,x_7.
\]
Within each group the three chords are nested: the first and last listed vertices are paired, then the second and fifth, then the third and fourth. The two groups are disjoint; \(q\) ends before them and \(p\) begins after them. Thus this page is noncrossing. Draw the ordinary parenthesis chords and the four escape edges on the other side of \(C\). The ordinary chords are nested or disjoint. In the linear order (2), the escape chords \(t_1d,t_2c,t_3b,t_4a\) are nested and all ordinary-chord endpoints lie between \(t_2\) and \(t_3\), so that page is noncrossing too.

The site edges border the same face, with facial arcs
\[
 w_*,\alpha,\beta,w_0
 \quad\text{and}\quad
 x_1,y_1,x_4,y_4,x_7,y_7.                              \tag{4}
\]
The two chords \(y_1x_4,y_4x_7\) lie on the second arc; the other four face chords lie inside their caps. The first arc is the selected three-edge alternating opening. Its trapped cycle is the old six-vertex segment from \(\alpha\) to \(\beta\), closed by \(\alpha\beta\); its four internal vertices escape by (3). This proves the asserted \((e,f)=(4,6)\).

**Three-connectivity.** Use interlacement in the cyclic order of \(C\): two matching chords are adjacent in the interlacement graph when their four endpoints alternate. That graph is connected here. The site chord \(q\) interlaces every ordinary chord on the branch path to \(U_1\), while \(p\) interlaces every ordinary chord on the path to \(U_7\). The chord \(y_1x_4\) meets the leaf chords of \(U_1,U_4\) and the branches above \(U_1,U_2\) and \(U_3,U_4\); \(x_2y_3\) meets the leaf chords of \(U_2,U_3\) and those same branches. The chord \(y_4x_7\) connects the \(U_4\) side to \(U_7\) and interlaces the remaining branches between them. The chord \(x_5y_6\) meets the leaf chords of \(U_5,U_6\) and their incident branches. The two unmentioned face chords \(y_2x_3,y_5x_6\) meet the same leaf chords, so all 32 ordinary chords and all six face chords belong to the component containing \(q,p\). The closure chord \(\alpha\beta\) interlaces all four escape chords; \(q\) interlaces \(t_1d,t_2c\), and \(p\) interlaces \(t_3b,t_4a\). Thus the complete matching interlacement graph is connected.

A graph consisting of a Hamilton cycle and a complementary matching has no bridge. A two-edge cut would consist of two cycle edges bounding an interval closed under the matching, disconnecting its matching interlacement graph. Hence \(G\) has no cut of size at most two. In a cubic graph a one- or two-vertex cut would induce an edge cut of size at most two, so \(G\) is three-connected.

The standard square expansion of the two disjoint edges in (3) embeds in their common face. It is simple, cubic and bipartite: the two site edges have the same colour orientation \(w_0,x_1\) and \(y_7,w_*\), and the new square vertices receive alternating colours. It is also three-connected. First, \(G-\{p,q\}\) is connected because \(G\) is three-edge-connected. After deleting two new vertices, each surviving new vertex still has its distinct spoke into that connected old graph. After deleting up to two old vertices and no new vertex, each component of the surviving old graph with \(p,q\) omitted contains a surviving site endpoint; otherwise it would already be a component of \(G\) after those old-vertex deletions. The intact square therefore reconnects all components.

It remains to delete one new vertex and at most one old vertex \(s\). The surviving three-vertex square path is connected. Suppose its remaining spokes do not reach some component \(K\) of \(G-s-\{p,q\}\). For example, if the deleted new vertex is the one attached to \(u\) on \(p=uv\), then \(K\) contains none of \(v,x,y\). If \(u\notin K\), it has no edge to the rest even in \(G-s\), contrary to three-connectivity. If \(u\in K\), its only possible edge to the rest of \(G-s\) is \(uv\); deleting \(v\) as well as \(s\) disconnects \(G\), again a contradiction. The other three new vertices are symmetric. Hence every surviving old component reaches the square path, and \(G^+\) remains connected. This proves legality.

**Hamilton certificate.** Perform the selected three-edge facial opening of Note 176 in \(G^+\). Its resulting 2-factor has one cycle through the new square and all main vertices, in their old-cycle order along \(w_0,t_1,t_2,W,t_3,t_4,w_*\), and one trapped hexagon \(\alpha,a,b,c,d,\beta,\alpha\). Delete the cycle edges \(t_1t_2\) and \(cd\), then insert the matching edges \(t_1d,t_2c\). Each inserted edge joins the two former cycles, and the two cross connections close them into one spanning cycle. Hence \(G^+\) is Hamiltonian without using a graph computation.

**Reduction boundary.** A four-rung ordinary ladder would require three consecutive plain-unary ancestors, but every branch chain in (1) has two and every leaf chain one. A mixed leaf ladder would require two consecutive plain-unary ancestors immediately above a leaf, whereas each leaf has only its one wrapper before the next branching node. Thus \(G\) is doubly reduced and \(c=7\cdot2+6\cdot3=32\), saturating Note 410's \(5f+2=32\). The only leaf modules consecutive in the full old-cycle order are the three sibling pairs named above. Their possible inner joining chords would be \(y_1x_2,y_3x_4,y_6x_7\); none belongs to (3). Note 412 therefore does not compress a consecutive-leaf pair in this graph. Other four-pole reductions are not classified here. \(\square\)
