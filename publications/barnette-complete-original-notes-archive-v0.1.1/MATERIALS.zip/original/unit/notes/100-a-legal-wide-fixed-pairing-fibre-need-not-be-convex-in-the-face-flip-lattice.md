> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A legal-wide fixed-pairing fibre need not be convex in the face-flip lattice

[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md)
reduces a root--gate square to a fixed-pairing two-linkage fibre.  A natural
way to seek the remaining cross-sector alternating cycle is to place all
perfect matchings in the standard face-flip distributive lattice and try to
prove that this fibre is order-convex, or at least that two nonempty gate
sectors are joined by a lattice cover.

Both assertions are false inside the target class.  The octagonal prism is
a legal-wide simple plane cubic bipartite brace whose five-state fibre is
not order-convex for any choice of outer face and contains no facial-cover
edge at all.  It nevertheless has a nonfacial cross-sector alternating
six-cycle.  Thus ordinary resonance-lattice convexity discards, rather than
forces, the exchange needed by the crossing-cycle candidate.

## 1. The octagonal-prism interface

Let

\[
G=C_8\square K_2
\tag{1}
\]

with vertices \(t_i,b_i\), rim edges

\[
T_i=t_it_{i+1},\qquad B_i=b_ib_{i+1},
\tag{2}
\]

and rungs \(R_i=t_ib_i\), with indices modulo eight.  Take

\[
e=B_0,\qquad g_0=T_0,\qquad g_1=T_4
\tag{3}
\]

and the root square

\[
Q=b_0b_1t_1t_0b_0.
\tag{4}
\]

The two gates \(g_0,g_1\) lie on the top octagonal face, the root does not,
and the two closed gate arcs both contain five vertices.  Hence (3)--(4)
form a legal-wide interface.  The even prism is a simple plane cubic
bipartite brace.  Directly, its 49 perfect matchings extend all 228 pairs of
independent edges.

Put

\[
H=\{T_0,B_0\}\cup\{R_i:i\notin\{0,1\}\},
\qquad
S_i=\{T_i,B_i,R_i,R_{i+1}\}.
\tag{5}
\]

Deleting \(Q\) and imposing the two channel pairs
\((b_7,t_7)\) and \((b_2,t_2)\) gives exactly

\[
\mathcal L=\{M_i=H\mathbin\triangle S_i:i=2,3,4,5,6\}.
\tag{6}
\]

Only \(M_4\) contains \(g_1\).  Thus the two gate sectors have sizes

\[
|\mathcal L^0|=4,\qquad |\mathcal L^1|=1.
\tag{7}
\]

## 2. A two-cover interval leaves the fibre

First choose the root square \(Q=S_0\) as the outer face of the standard
perfect-matching lattice.  Define

\[
D=H\mathbin\triangle S_2\mathbin\triangle S_5.
\tag{8}
\]

The two disjoint facial flips have the same lattice orientation, so

\[
M_5\ \lessdot\ D\ \lessdot\ M_2.
\tag{9}
\]

Both endpoints belong to \(\mathcal L\).  After deleting \(Q\), however,
the complement of \(D\) consists of the two required terminal paths and
one additional closed cycle.  Therefore

\[
\boxed{\mathcal L\text{ is not order-convex}.}
\tag{10}
\]

Reversing the plane orientation or interchanging the bipartition colours
only reverses (9).  The finite face system has ten possible choices of
outer face; direct reconstruction gives a missing intermediate state for
all ten.  Thus the failure is not an artefact of the height normalization.

## 3. The fibre has no facial-cover edges

For distinct \(i,j\in\{2,3,4,5,6\}\),

\[
M_i\mathbin\triangle M_j=S_i\mathbin\triangle S_j.
\tag{11}
\]

If the two side squares are adjacent, (11) is one alternating six-cycle.
Otherwise it is the disjoint union of two alternating squares.  Neither is
a face boundary of the prism.  Consequently no two distinct members of
\(\mathcal L\) form a facial flip, regardless of the outer face.  In
particular, two nonempty sectors do not force a cross-sector lattice cover.

This does not refute the crossing-cycle candidate.  For example,

\[
M_4\mathbin\triangle M_3
\tag{12}
\]

is a single nonfacial alternating six-cycle and crosses the \(g_1\)
coordinate.  The failure is therefore exact: the candidate exchange exists,
but it is invisible in the facial-cover graph.

## 4. Consequence and boundary

The following implications are false even for a legal-wide labelled
interface in a simple plane cubic bipartite brace:

\[
\begin{aligned}
&\text{fixed-pairing fibre}\Longrightarrow
  \text{order-convex subset of the face-flip lattice},\\
&\mathcal L^0,\mathcal L^1\ne\varnothing\Longrightarrow
  \text{a cross-sector facial cover}.
\end{aligned}
\tag{13}
\]

Thus standard resonance-lattice convexity and facial covers cannot prove
the arbitrary-order statement left open by Notes 085--086 and
[Note 099](099-the-minimum-support-xor-cube-is-legal-wide-in-a-plane-brace-but-not-fibre-minimum.md).
A successful proof must use nonfacial alternating-cycle exchange or a
different complete-fibre selection principle.

The result makes no claim that the crossing-cycle candidate is false and no
claim that the octagonal prism is order-minimal among all possible rooted
interfaces.  The permanent
[verification bundle](../computations/bundles/legal-wide-fibre-face-lattice-counterexample/README.md)
checks the complete fibre, the brace certificate, every outer-face
normalization, the interval (9), and the nonfacial crossing (12).

