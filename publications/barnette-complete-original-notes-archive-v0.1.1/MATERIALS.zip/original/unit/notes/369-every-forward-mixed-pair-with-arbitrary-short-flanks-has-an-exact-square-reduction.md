> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every forward mixed pair with arbitrary short flanks has an exact square reduction

[Note 336](336-every-two-double-mixed-j1-j3-free-group-has-a-spanning-route.md)
proves a spanning route when a forward adjacent \(J_3,J_1\)
double-block pair has arbitrary short flanks on both sides.
Its boundary-link lemma says the two flanks cannot both begin
with nonstandard matching returns. Combined with the exact
one-sided reductions of
[Note 368](368-every-one-sided-short-flank-of-a-forward-mixed-pair-has-an-exact-square-reduction.md)
and the standard-buffer theorem of
[Note 367](367-square-signature-four-poles-are-closed-under-standard-short-buffers.md),
this gives an exact reduction for every actual matching,
without assumptions on vacancies outside the group.

Use Note 336's compressed, gapless, tight-target all-square
opening. An ordinary target-free free group has an even left
endport \(L\), an odd right endport \(R\), \(p\ge0\) short
blocks before, and \(q\ge0\) short blocks after the only
two nonshort blocks
\[
D=(a,o,h,i,k,j,e,b),\qquad
D'=(A,O,H,I,K,J,E,B).                               \tag{1}
\]
They carry the common-face chords \(ie,OK\), and Note 335
forces the opposite-page chords \(jH,kI\). The reverse
\(J_1,J_3\) orientation is impossible by Note 335.

**Two-flank square-reduction theorem.** Every complementary
matching actually occurring in a Barnette parent under
these hypotheses contains an induced disk patch with the
complete Hamilton four-terminal signature of a square.
Replacing that patch by the square, or conversely, preserves
Barnette membership and every exterior and attachment-edge
Hamilton decision. If \(hJ\) is present, the 16-vertex
\(D,D'\) patch of Note 335 is such a patch. If \(hJ\) is
absent, the entire group of \(16+4(p+q)\) vertices is one
such four-terminal patch. In that case exactly one flank
contains a nonstandard return, while every block of the
opposite flank is a standard square buffer.

**At most one nonstandard flank.** Suppose \(hJ\) is absent.
Note 336 proves that whenever both active flanks are
nonempty, at least one active boundary matching edge is
standard: \(Lo_1\) on the left or \(v_qR\) on the right,
with the current virtual endport substituted after any
earlier standard peel. Each standard peel removes exactly
one outer short block from the active block list and leaves
its other free slot as the new virtual endport.

Peel the longest possible standard prefix from the left
and standard suffix from the right. Their matching edges
are fixed, disjoint, and lie in opposite outer block
intervals, so these peels commute. If both remaining
flanks were nonempty, neither active boundary edge would
be standard by maximality, contradicting Note 336's
boundary-link lemma for the residual virtual endports.
Therefore one flank is entirely standard. Both cannot be
entirely standard: peeling them would leave the no-flank
\(D,D'\) group, where Note 335 forces \(hJ\).
Thus the other flank is nonempty and contains the sole
nonstandard return.

**Exact reduction.** Suppose the right flank is entirely
standard. Removing its standard blocks from the boundary
exposes the actual one-sided left-flank matching, with
the right virtual endport of Note 336. The matching on
all \(p\) left short blocks and \(D,D'\) is one of
Note 335 (18): the local \(hJ\) case was excluded,
so it has a unique \(\mu\in\{0,\ldots,p-1\}\).
Note 368 proves that its induced four-terminal patch has
the exact square signature and the two deletion properties.
Its right terminal pair \(E,B\) is an edge. Reattach the
\(q\) right blocks in reverse peel order. Each is exactly
a right standard buffer: it replaces the old right
attachment at \(B\) and the matching attachment at \(E\)
by one short square and the next retained matching link.
Note 367 therefore gives the whole group the same exact
signature and preserves the Barnette class in both directions.

If the left flank is entirely standard, reflect the
old-cycle order. The reflected group has a nonstandard
left flank and standard right buffers, so the preceding
argument applies. The terminal colours and cyclic disk
order are those of the corresponding one-sided core and
are unchanged by standard buffers. The entire group has
four distinct exterior attachments: the two old-cycle
edges at its first and last block and the two ordinary
free-matching edges at \(L,R\); every other vertex has
all three incident edges inside. Hence it is the stated
induced disk four-pole. \(\square\)

The theorem strengthens Note 336's route conclusion for
this specified group: the exact substitution also works
in arbitrary Barnette hosts containing one of the listed
induced disk patches, with no condition on outside
vacancies. The explicit one-sided parents of Note 335,
followed by standard buffers, realize every nonstandard
word in the proof as a Barnette parent of order
\(28+4(p+q)\) with a marked Hamilton cycle; Note 001
gives each legal child's Hamilton cycle.

The theorem covers only groups whose nonshort blocks are
one forward adjacent \(J_3,J_1\) double pair. A third
multiply vacant block, a singly vacant block in the group,
other internal chord types, target-bearing boundaries,
positive gaps, nonsquare residual cycles and general
Barnette graphs remain outside it. The proof is
project-internal and has not had independent external review.
