> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A nonstandard left link with two short flanks forces a square reduction

[Note 394](394-every-single-double-corridor-with-one-outer-short-block-has-a-square-reduction.md)
settles a single--double vacancy corridor with one outer short block. When
one short block occurs on each side, the right block adds a genuine return
at the doubly vacant block. The following result settles the entire branch
in which the first left link is nonstandard.

Work in a compressed, gapless, tight-target all-square selected opening of a
Barnette parent. Let one ordinary target-free free group consist, in old-cycle
order, of exactly
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_j=(c_j,p_j,q_j,d_j)\ (1\le j\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1.       \tag{1}
\]
Thus there is one short block on each outside flank and a nonempty short
corridor between the singly and doubly vacant blocks. Let \(t,z\) be the
even left and odd right free endports and \(M\) the complementary matching
of the selected old Hamilton cycle. Other free groups and vacancies are
unrestricted.

**Nonstandard-left-link theorem.** If \(tp\notin M\), every actual matching
under (1) contains an induced disk four-pole, strictly larger than a square,
with exactly the square's four spanning one-path and two spanning two-path
Hamilton states. Replacing this pole by its labeled square, or reversing the
replacement, preserves Barnette membership and every exterior- and
attachment-marked Hamilton decision. In particular, no vertex-minimal
non-Hamiltonian Barnette graph contains such a matching pattern.

**The first mate.** The free slots occur in the order
\[
 t,p,q,o,h,i,e,(p_j,q_j)_{j=1}^m,O,H,I,K,J,E,r,s,z.       \tag{2}
\]
Cross-block free matching chords lie opposite the common face by
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md), and do
not interlace there. An interval of complete consecutive blocks whose
matching is internal has only its two boundary old-cycle edges leaving it,
contrary to three-connectivity. The even slot \(t\) can meet only
\(p,o,i,p_j,O,I,J,r,z\). The chord \(to\) traps \(p,q\), whose edge \(pq\)
belongs to the old cycle and is therefore unavailable to \(M\). Each
\(tp_j\), \(tO\), \(tr\), or \(tz\) match-closes, respectively, the proper
complete block interval before its right endpoint: \(S_0,V,S_1,\ldots,
S_{j-1}\); \(S_0,V,S_1,\ldots,S_m\); \(S_0,V,S_1,\ldots,S_m,D\); or the
whole group. These would be two-edge cuts. Hence
\[
                         M(t)\in\{p,i,I,J\}.                \tag{3}
\]

If \(ti\in M\), the four slots \(p,q,o,h\) lie inside that opposite-side
chord. The only possible face-side exit, \(oe\), would leave an odd number
of these slots to match internally. Without it, the old-cycle edges \(pq,oh\)
and the bipartition exclude all pairings except \(ph,qo\). Thus \(S_0\cup V\)
is exactly the ten-vertex cube-fold four-pole of
[Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md).

If \(tJ\in M\), the four right slots \(E,r,s,z\) must pair as
\(Er,sz\): an internal mate for \(E\) would leave three right slots
without an exit, while the alternative \(Ez,rs\) uses the old-cycle
edge \(rs\).
The matching on \(t,p,q,o,h,i,e,(p_j,q_j),O,H,I,K,J,E,r\) therefore has
precisely the right boundary state \(Ez\) of
[Note 392](392-every-one-left-flank-tj-single-double-corridor-has-an-exact-square-reduction.md),
with \(r\) playing its virtual right endport. Every complete-block
two-edge-cut exclusion used there still holds in the original parent, and
the remaining square reduction supplied by that note retains four distinct
attachments when \(T\) is present. Hence the \(tJ\) branch is reduced.

Suppose \(tI\in M\). The odd slot \(J\) can reach the even slot \(H\) by
the face-side internal chord \(HJ\), or the even slot \(s\) across the
right flank. Every other opposite-side candidate to the left crosses
\(tI\); \(KJ,JE\) are old-cycle edges, and \(Jz\) joins equal colours.

If \(HJ\in M\), this chord lies on the common-face side because it
interlaces \(tI\). The chord \(OK\) is unavailable by the isolation lemma
of [Note 327](327-a-staggered-fourteen-vertex-vacancy-patch-has-the-square-signature.md):
it too would have to lie on the face side and interlaces \(HJ\).
The slot \(K\) can now meet only \(r\) or \(z\), while \(E\) can meet
\(O,r,z\). If \(OE\) were absent, matching \(K,E,r,s,z\) would be
impossible: \(Kz\) leaves \(E,r,s\), whose only possible pair \(Er\)
leaves \(s\) unmatched; \(Kr\) leaves \(E,s,z\), where \(E,s\) have
equal colour and \(Ez\) again leaves \(s\) unmatched. Thus
\(OE\in M\), after which
\(Kr,sz\) are forced. The induced eight-vertex block \(D\) has the
rainbow pair \(OE,HJ\) and is the exact square-equivalent ladder of
[Note 325](325-even-rainbow-multivacancy-blocks-are-exact-square-reductions.md).

It remains to take \(Js\in M\). Noninterlacement and the old-cycle
edge \(rs\) force
\[
                              Js,Er,Kz\in M.                \tag{4}
\]
Indeed, \(K\) cannot connect through either \(tI\) or \(Js\) on the
opposite side, and \(OK\) on the face side would leave the odd endport
\(z\) without a mate. Thus \(Kz\) is necessary, leaving \(Er\).
All four internal free-chord candidates \(OE,OK,HJ,IE\) of \(D\) are now
unavailable.

Inside \(tI\), the remaining free slots are
\[
             p,q,o,h,i,e,(p_j,q_j)_{j=1}^m,O,H.             \tag{5}
\]
The chord \(oe\), if present, must lie on the common-face side: on the
opposite side it would trap \(h,i\), whose edge belongs to the old cycle.
It is in fact impossible. Every possible
opposite-side mate \(p,p_j,O\) of \(h\) would enclose exactly one endpoint
of \(oe\): the interval of \(ph\) contains \(o\), while those of
\(hp_j,hO\) contain \(e\). The other slots inside each interval cannot
cross its bounding chord on the opposite side and have no other face-side
exit. Their parity would be odd. The old-cycle edges \(oh,hi\), equal
colours, and already used slots exclude every other mate of \(h\).
Consequently \(oe\notin M\).

The chord \(pe\) is also impossible: it encloses exactly \(q,o,h,i\).
Without \(oe\) these four slots have no face-side exit, but their only
colour-compatible pairings use the forbidden old-cycle edge \(oh\) or
\(hi\). The odd slot \(p\) must therefore meet \(h\), some \(q_j\), or
\(H\). In the first case \(ph\) encloses \(q,o\) and forces \(qo\),
giving the same Note 315 cube fold \(S_0\cup V\).

Suppose instead \(pq_j\) or \(pH\) occurs. The even slot \(q\) can meet
\(o,i,p_k,O\) among the unused slots inside \(tI\). The edge \(qi\)
traps \(o,h\), whose old-cycle edge is unavailable. If \(pq_j\) occurs,
then \(qp_k\) for \(k>j\) and \(qO\) cross it. Every remaining
\(qp_k\) match-closes the complete interval \(V,S_1,\ldots,S_{k-1}\);
when \(pH\) occurs, \(qO\) match-closes \(V,S_1,\ldots,S_m\). These
closures violate the two-edge-cut rule.
Thus
\[
                                  qo\in M.                  \tag{6}
\]
The remaining even slot \(h\) must meet \(O\) or some \(p_s\). The edge
\(hp_1\) would trap the forbidden old-cycle pair \(i,e\), so \(s\ge2\).

If \(hO\in M\), the slot \(i\) must meet some \(q_k\). A choice \(k<m\)
would match-close the complete suffix \(S_{k+1},\ldots,S_m\) between
\(iq_k\) and \(hO\). Hence \(iq_m\) is forced. Noninterlacement and the
same complete-block cut rule then force
\[
                    ep_1,\qquad q_jp_{j+1}\ (1\le j<m).    \tag{7}
\]
If \(hp_s\in M\), where \(s\ge2\), the slot \(i\) must meet a \(q_k\)
with \(k<s\). For \(k<s-1\), the intervening complete blocks
\(S_{k+1},\ldots,S_{s-1}\) are match-closed, so \(iq_{s-1}\) is forced.
The same left-prefix cut rule gives
\[
               ep_1,\qquad q_jp_{j+1}\ (1\le j<s-1).       \tag{8}
\]

Put \(r_*=m\) in (7) and \(r_*=s-1\) in (8). In either case the induced
interval \(P=V\cup S_1\cup\cdots\cup S_{r_*}\) has, besides its face
chords, precisely the internal free matching edges
\[
               ep_1,\quad iq_{r_*},\quad
               q_jp_{j+1}\ (1\le j<r_*).                   \tag{9}
\]
Its four degree-two terminals are \((a,o,h,d_{r_*})\) in disk order;
their external edges are distinct. For \(r_*=1\), (9) is the old-cycle
reflection of Note 315's cube fold. For larger \(r_*\), compress the
induced even-column ladder \(S_1\cup\cdots\cup S_{r_*}\) to one square
by [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md),
then use that reflected cube fold. This is the exact four-terminal
reduction proved in Note 392; its proof depends only on the edges internal
to \(P\), so the different exterior mates \(qo\) and \(hO\) or \(hp_s\)
do not alter its signature or Barnette preservation. These cases exhaust
(3) when \(tp\notin M\). \(\square\)

The theorem does not settle the standard-left-link branch \(tp\in M\):
after peeling \(S_0\), the core has a right short flank adjacent to \(D\),
which is not the reflected hypothesis of Note 394. Nor does it address
longer outer flanks, other vacancy-bearing blocks or opening types, or the
general Barnette conjecture. The proof is project-internal and has not had
independent external review or a complete literature priority comparison.
