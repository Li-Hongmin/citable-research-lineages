> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two mixed openings reduce end-middle split pairs to direct cross chords

[Note 491](491-an-escape-free-end-middle-component-joins-only-the-two-child-arcs.md) shows that, with split nodes in \(W_1,W_2\), a terminal-free component of the double-inner opening without an end escape edge can only be \(A_1\cup A_2\). The two mixed openings close every such case except a precise pair of nested direct-special matching chords. This is a necessary configuration for failure, not a non-Hamiltonian example.

Use the three-root chord-free single-hexagon order, base cycles \(D=C_1\cup C_2\cup C_3\), site ports \(u,v\), root face graph \(K\), and notation \(H_i,s_i,A_i,t_i,J_i\), \(X_i,Y_i,B_i\), \(M,E\) of Notes [456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) and [491](491-an-escape-free-end-middle-component-joins-only-the-two-child-arcs.md). Assume \(K\) is connected. Every special position outside the four direct positions belongs to a two-special leaf. Assume also that the core chord \(H_2J_2\) is not the closing chord used by \(C_2\). This last condition holds at the \(12f+2\) equality boundary by the saturated wrapper charge of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md), which gives the marked nodes two plain-unary ancestors as used in [Note 487](487-disjoint-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md).

**Mixed-opening reduction theorem.** If the parent has no Hamilton cycle containing both site edges, then all the following hold:

1. In the double-inner opening, the terminal-free component without an end escape edge is \(A_1\cup A_2\), joined by an even number \(k\ge2\) of \(M\)-edges; the complementary coarse pieces \(B_1,B_2,W_3\) are connected.
2. The four direct positions have the matching pattern
   \[
                         s_1t_2,\qquad t_1s_2\in M.       \tag{1}
   \]
   The site ports lie in \((X_1\setminus\{s_1\})\cup W_3\), and every other special position of \(X_2\) or \(Y_2\) is matched within its own flank.
3. In the opening with node 1 inside and node 2 outside, the outer middle-root complement is a separate terminal-free component. Its only four boundary edges in the parent are the two old edges incident with \(s_2,t_2\) and the two old edges incident with the ends of \(W_2\).

The reflected conclusion holds when the nodes occupy \(W_2,W_3\).

**Proof.** If every terminal-free component of the double-inner opening has an end escape edge, [Note 489](489-two-end-escape-edges-absorb-both-residual-cycles.md) gives a marked parent Hamilton cycle. Otherwise Note 491 gives \(S=A_1\cup A_2\), with \(k\ge2\) even. Choose any joining face chord. The odd, terminal-free flanks \(Y_1\) and \(X_2\) lie between its endpoints. Neither can match outside the interval between \(A_1,A_2\) without crossing that chord, nor into \(S\). Each has an odd number of special positions, so at least one \(M\)-edge joins \(Y_1\) to \(X_2\). Thus \(B_1,B_2\) are connected. Since \(K\) is connected and \(S\) has no \(M\)-edge to another coarse piece, \(W_3\) has an \(M\)-edge to \(B_1\) or \(B_2\). The complementary pieces are connected.

Open node 1 outside and node 2 inside:
\[
 F_{\mathrm{oi}}=
 \bigl(D-E-\{H_1s_1,t_1J_1,s_2L_2,R_2t_2\}\bigr)
       \cup M\cup\{H_1J_1,L_2R_2\}.                    \tag{2}
\]
The inserted chord \(H_1J_1\) is unused by the end-root cycle \(C_1\). Equation (2) has one \(u\)--\(v\) path and cycles. After restoring \(E\), the coarse pieces are the central arc \(P_1=s_1\rightsquigarrow t_1\), its outer complement \(B_1'\) containing \(t_dd\), the closed child \(A_2\), the middle-root complement \(B_2\), and \(C_3\) containing \(t_aa\). The \(A_1\)--\(A_2\) chords join \(P_1\) to \(A_2\). Splitting two vertices of connected \(K\) gives at most three components. Each residual component with an end escape edge is absorbed by the paths of Note 489, so failure requires a terminal-free component \(T\) with neither escape edge.

The only coarse pieces that can belong to \(T\) are \(P_1,A_2,B_2\). The first two are joined. If \(B_2\) were alone, its odd, terminal-free flanks \(X_2,Y_2\) would have to match each other. Such a chord crosses the \(A_1\)--\(A_2\) chord, so \(B_2\) is not alone. The component \(P_1\cup A_2\) cannot be alone either: it has no site port, so both \(s_1,t_1\) are matched; their mates lie outside \(A_1\cup A_2\), and [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) excludes matching them to each other. Thus they join \(P_1\cup A_2\) to another piece. Consequently
\[
                              T=P_1\cup A_2\cup B_2.      \tag{3}
\]
Its lack of ports puts \(u,v\) outside \(s_1,t_1,X_2,Y_2,A_1,A_2\); the site-barrier conclusion of Note 491 then puts them in \((X_1\setminus\{s_1\})\cup W_3\).

Because \(T\) is a component, neither direct position \(s_1,t_1\) can have its \(M\)-mate in \(B_1'\) or \(W_3\). Neither can match into \(A_1,A_2\), by isolation of \(S\) in the double-inner opening, or to the other direct position, by Note 473. Thus each matches into \(B_2\). The joining \(A_1\)--\(A_2\) face chord forces the mate of \(s_1\) into \(Y_2\), for a mate in \(X_2\) would interlace it. Similarly the mate of \(t_1\) lies in \(X_2\), not \(Y_2\). Write
\[
                     s_1y,\quad t_1x\in M,
                     \qquad y\in Y_2,\ x\in X_2.       \tag{4}
\]
No other \(M\)-edge leaves \(B_2\). An \(X_2\)--\(Y_2\) edge would cross the \(A_1\)--\(A_2\) chord. Since each flank has one external mate in (4), its remaining special positions match within that flank. Also \(W_3\) has an \(M\)-edge to \(B_1'\): it cannot join \(S\) or \(T\), while \(K\) is connected.

Now open node 1 inside and node 2 outside:
\[
 F_{\mathrm{io}}=
 \bigl(D-E-\{s_1L_1,R_1t_1,H_2s_2,t_2J_2\}\bigr)
       \cup M\cup\{L_1R_1,H_2J_2\}.                    \tag{5}
\]
The hypothesis on \(H_2J_2\) makes (5) a valid two-regular opening away from \(u,v\). Its coarse pieces are the closed child \(A_1\), complement \(B_1\) with \(t_dd\), central arc \(P_2=s_2\rightsquigarrow t_2\), outer complement \(B_2'\), and \(C_3\) with \(t_aa\). The \(A_1\)--\(A_2\) chords join \(A_1\) to \(P_2\), and the previously identified edge joins \(B_1\) to \(C_3\).

If \(x\ne s_2\), the edge \(t_1x\) joins \(B_1\) to \(B_2'\), while the mate of \(s_2\) lies in \(X_2\setminus\{s_2\}\) and joins \(P_2\) to \(B_2'\). Thus all five coarse pieces are connected. The same follows from \(y\ne t_2\), using \(s_1y\) and the mate of \(t_2\). Leaf-square switches then give a spanning \(u\)--\(v\) path on \(D\), and the exterior path \((u,w_0,\beta,\alpha,w_*,v)\) closes a marked Hamilton cycle. Failure therefore forces \(x=s_2,y=t_2\), which is (1).

When both equalities hold, all special positions of \(B_2'\) are internally matched within its two flanks. No \(M\)-edge joins it to another coarse piece. Thus \(B_2'\) is a separate terminal-free component of \(F_{\mathrm{io}}\cup E\); leaf-square switches merge its cycles into one and preserve every edge outside the root words. This component contains neither end escape edge. Ordinary matching chords are laminar around the marked node, so every ordinary third edge incident with \(B_2'\) stays in it. In the parent, its only edges to the remainder are the old edges \(H_2s_2,t_2J_2\) and the two old edges at the ends of \(W_2\). This proves all three assertions. \(\square\)

The theorem is a strict route reduction for the selected opening. It does not assert that the direct-cross profile (1) exists in a Barnette graph, nor that it obstructs all Hamilton cycles of a legal expanded child.
