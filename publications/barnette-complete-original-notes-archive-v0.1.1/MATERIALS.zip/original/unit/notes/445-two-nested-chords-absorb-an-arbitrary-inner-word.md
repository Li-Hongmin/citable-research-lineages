> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two nested chords absorb an arbitrary inner word

The row-IV short-leaf word of [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,2)\), short leaf \(6\), and depth vector \((1,3,4,6,6,5,2)\) has a spanning marked path. Its central step applies to an inner word of arbitrary length.

Use the full leaf and branch notation and the paths \(Y_i,X_i,P_H,Q_H\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). For a full branch \(H\), let
\[
J_H=(\lambda_0^H,\rho_0^H,\rho_1^H,\lambda_1^H,
     \lambda_2^H,\rho_2^H).
\tag{1}
\]
Let \(C\) be any consecutive ordinary word with two nested outer matching chords \(\lambda_0^C\rho_0^C\) and \(\lambda_1^C\rho_1^C\), whose old-cycle order begins \(\lambda_0^C,\lambda_1^C,\ldots,\rho_1^C,\rho_0^C\). Suppose its inner interval contains the old-cycle edge \(x_4y_4\). The two outer endpoints are covered by the edge \(C_rC_\ell=\rho_0^C\lambda_0^C\). Deleting \(x_4y_4\) from the old-cycle path through the inner interval closed by \(\lambda_1^C\rho_1^C\) gives the disjoint spanning path
\[
Z_C=(x_4\xrightarrow{\mathrm{old\ backward}}\lambda_1^C,
     \rho_1^C\xrightarrow{\mathrm{old\ backward}}y_4).
\tag{2}
\]
Thus \(C_r,C_\ell\) and \(Z_C\) cover every vertex of \(C\) once, independently of its remaining matching chords.

Put
\[
B=F(U_3,C),\qquad A=F(U_2,B),\qquad
T=F(A,U_7),\qquad W=F(U_1,T).
\tag{3}
\]
Assume the face matching contains \(y_3x_4,y_4x_7,x_3y_7\). In a full leaf \(U_7\), the path
\[
Z_7=(x_7,h_7,L_7,R_7,j_7,y_7)
\tag{4}
\]
uses old-cycle edges and the outer ordinary chord \(L_7R_7\), and spans the leaf.

**Two-nested-chord absorption lemma.** Under these assumptions, the old-cycle edges, ordinary chords, and three stated face chords contain a spanning \(y_1\)--\(x_2\) path of \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^T\xrightarrow{Q_T}\lambda_2^T,
A_\ell=\lambda_0^A\xrightarrow{J_A}\rho_2^A,\\
&\rho_0^B,\rho_1^B,\rho_2^B,
C_r=\rho_0^C,C_\ell=\lambda_0^C,
R_3,j_3,y_3,\\
&x_4\xrightarrow{Z_C}y_4,
x_7\xrightarrow{Z_7}y_7,
x_3,h_3,L_3,
\lambda_2^B,\lambda_1^B,\lambda_0^B,
R_2\xrightarrow{X_2}x_2.
\end{aligned}
\tag{5}
\]
The three jumps \(y_3x_4,y_4x_7,y_7x_3\) are exactly the stipulated face chords. All joins between the other displayed pieces are consecutive old-cycle edges: \(L_1\lambda_2^W,\rho_2^W\rho_0^T,\lambda_2^TA_\ell,\rho_2^A\rho_0^B,\rho_2^BC_r,C_\ell R_3,L_3\lambda_2^B,\lambda_0^BR_2\). The two lines of \(B\)-brackets in (5) cover its right and left triples; the two \(U_3\) segments cover \(R_3,j_3,y_3\) and \(x_3,h_3,L_3\). Equations (2) and (4) cover \(C\) and \(U_7\). The remaining pieces cover \(U_1,U_2\) and the three full wrappers \(W,T,A\). Hence (5) visits every vertex exactly once. \(\square\)

For the row-IV application, take
\[
D=F(U_4,U_5),\qquad S_6=(L_6,x_6,y_6,R_6),
\qquad C=F(D,S_6).
\tag{6}
\]
The word \(C\) has the required two nested outer chords, and (3) has depths \((1,3,4,6,6,5,2)\). Row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md), with ineligible leaves \(3,\ldots,7\), supplies all three face chords in (5). Here \(|C|=28\), so the path has \(|C|+48=76\) vertices. The fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), closes it through both site edges in every legal parent completion. By clause 1 of [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), every corresponding legal child is Hamiltonian. Reflection gives the row-V conclusion.

Together with Notes 437--444, this leaves four structurally necessary row-IV/V short-leaf words. Row VI, other kernel branches, and Barnette's conjecture remain unresolved.
