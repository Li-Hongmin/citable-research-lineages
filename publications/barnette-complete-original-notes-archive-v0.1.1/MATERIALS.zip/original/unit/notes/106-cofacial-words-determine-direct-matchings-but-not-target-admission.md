> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cofacial words determine direct matchings but not target admission

[Note 105](105-opposite-edge-expansion-of-a-facial-square-preserves-every-fibre-crossing.md)
settles the square-face case because both residual facial arcs have one
edge.  For a longer common face, a parent state-\(11\) target need not have
the three analogous direct lifts.  The exact local obstruction is visible
in the matching word, but target admission also depends on how the two
complement paths connect the exposed face ports outside the face.

This note gives the complete criterion for direct lifts that keep every
off-face matching edge fixed.  It also gives a sharp abstract hexagonal
countermodel to any criterion using only the face-edge word.  The result
does not decide complete-family supplementation: other parent matchings or
off-face alternating exchanges may still populate a child cell.

## 1. Cofacial setup and clean words

Let \(M\) belong to a fixed-pairing spanning-two-path fibre of a residual
graph \(R\).  Thus

\[
K:=R-M
\tag{1}
\]

is the union of two spanning paths with prescribed labelled terminal pairs
\(\alpha\beta\mid\gamma\delta\).  Let \(p=uv,q=xy\in M\) be
vertex-disjoint edges on one even face, in cyclic order

\[
u,p,v,A,x,q,y,B,u.
\tag{2}
\]

The legal bipartite orientation makes both residual facial arcs \(A\) and
\(B\) odd.  For

\[
A=a_0a_1\cdots a_m,\qquad a_0=v,\quad a_m=x,
\tag{3}
\]

put

\[
w_A=(\varepsilon_1,\ldots,\varepsilon_m),\qquad
\varepsilon_i=\mathbf 1_{a_{i-1}a_i\in M}.
\tag{4}
\]

Call \(A\) **clean** if

\[
w_A=0(10)^r,\qquad m=2r+1.
\tag{5}
\]

Equivalently, every internal vertex of \(A\) is matched by a face edge;
none is matched through its third edge.  Define cleanliness for \(B\)
similarly.

## 2. Exact direct-matching criterion

Keep every off-face matching edge of \(M\) fixed.  The three possible
direct face-supported child matchings are

\[
\begin{aligned}
M^U&=\bigl((M-\{p,q\})\triangle E(A)\bigr)
       \cup\{ua,bc,dy\},\\
M^V&=\bigl((M-\{p,q\})\triangle E(B)\bigr)
       \cup\{ad,bv,xc\},\\
M^R&=\bigl((M-\{p,q\})\triangle(E(A)\cup E(B))\bigr)
       \cup\{ab,cd\}.
\end{aligned}
\tag{6}
\]

They are perfect matchings under the exact conditions

\[
\boxed{
\begin{array}{c|c}
X_{uy}&A\text{ is clean},\\
X_{vx}&B\text{ is clean},\\
R_{00}&A,B\text{ are both clean}.
\end{array}}
\tag{7}
\]

To see necessity, fix all vertices matched through their third edge and
delete them from a residual arc.  The parent word tiles every remaining
internal interval.  If an internal third-matched vertex exists, the two end
intervals each acquire one old endpoint in the child and have odd order, so
they cannot both be tiled.  If no such vertex exists, the whole odd arc has
an even number of vertices and has a unique endpoint-covering matching.
It is obtained by toggling every edge of the arc.  This proves necessity,
sufficiency and uniqueness in (6)--(7).

The word therefore decides the existence of a direct perfect matching.  It
does not decide whether its complement retains the prescribed two-path
topology.

## 3. Exterior connection signature

For a clean arc \(A=a_0\ldots a_{2r+1}\), the old complement connections
along the face are

\[
P_A=\{a_0a_1,a_2a_3,\ldots,a_{2r}a_{2r+1}\}.
\tag{8}
\]

After the switch, contract the new patch path to one connection.  The new
connections are

\[
Q_A=\{a_0a_{2r+1},a_1a_2,a_3a_4,\ldots,
       a_{2r-1}a_{2r}\}.
\tag{9}
\]

Define \(P_B,Q_B\) analogously.  For a set
\(S\subseteq\{A,B\}\) of switched arcs, delete
\(\bigcup_{C\in S}P_C\) from the two paths \(K\).  Every remaining path
component pairs two exposed face ports or labelled terminals.  Let

\[
\Omega_S(M)
\tag{10}
\]

be this finite set of pairs.  Equivalently, \(\Omega_S(M)\) records the
order of the exposed ports on the two labelled paths and discards all
exterior lengths and internal vertices.

For

\[
S_U=\{A\},\qquad S_V=\{B\},\qquad S_R=\{A,B\},
\tag{11}
\]

the corresponding direct matching in (6) belongs to the child target
fibre if and only if the required arcs are clean and

\[
\boxed{
\Omega_S(M)\cup\bigcup_{C\in S}Q_C
\text{ has no closed component and has terminal paths }
\alpha\beta,\gamma\delta.}
\tag{12}
\]

Indeed, the switch removes exactly \(P_C\), inserts exactly \(Q_C\), and
changes no other complement edge, up to subdivision by the patch.  Thus
(12) is both necessary and sufficient.  It may be tested by a finite
union--find recurrence on the exposed ports and terminals.

## 4. A sharp word-only countermodel

The first non-square legal face is a hexagon, with residual arc lengths
three and one.  Take

\[
w_A=010,\qquad w_B=0
\tag{13}
\]

and ports \(a_0,a_1,a_2,a_3,b_0,b_1\).  Then

\[
\begin{aligned}
P_A&=\{a_0a_1,a_2a_3\},&
Q_A&=\{a_0a_3,a_1a_2\},\\
P_B&=Q_B=\{b_0b_1\}.&&
\end{aligned}
\tag{14}
\]

The following two exterior signatures have the same local words and the
same parent terminal pairing \(\alpha\beta\mid\gamma\delta\):

\[
\begin{aligned}
\Omega_{\rm keep}
 &=\{\alpha a_0,a_1a_3,a_2\beta,
       \gamma b_0,b_1\delta\},\\
\Omega_{\rm swap}
 &=\{\alpha a_0,a_1\beta,\gamma a_2,
       a_3b_0,b_1\delta\}.
\end{aligned}
\tag{15}
\]

For \(\Omega_{\rm keep}\), replacing \(P_A\) by \(Q_A\) changes

\[
\alpha-a_0-a_1-a_3-a_2-\beta
\quad\text{to}\quad
\alpha-a_0-a_3-a_1-a_2-\beta,
\tag{16}
\]

so all three direct lifts retain the prescribed target pairing.  For
\(\Omega_{\rm swap}\), the old paths are

\[
\alpha-a_0-a_1-\beta,\qquad
\gamma-a_2-a_3-b_0-b_1-\delta,
\tag{17}
\]

whereas the \(A\)-switch produces

\[
\alpha-a_0-a_3-b_0-b_1-\delta,\qquad
\beta-a_1-a_2-\gamma.
\tag{18}
\]

Thus \(M^U,M^R\) change the pairing to
\(\alpha\delta\mid\beta\gamma\), while \(M^V\) remains a target because
\(P_B=Q_B\).  Identical face words can therefore yield either

\[
\{R_{00},X_{uy},X_{vx}\}
\quad\text{or}\quad
\{X_{vx}\}
\tag{19}
\]

among the direct \(M\)-supported target lifts.

This countermodel is minimal at the word level.  On a square both residual
arcs have length one, so \(P_A=Q_A\) and \(P_B=Q_B\); the next even face is
the hexagon in (13)--(18).

## 5. Exact boundary

Equations (7) and (12) are arbitrary-order necessary and sufficient
conditions for direct \(M\)-supported lifts with every off-face matching
edge fixed.  The hexagonal example is a strict abstract two-path
connection-signature countermodel to word-only determinacy.  It has not
been completed to a common simple cubic plane graph or a brace and is not a
Barnette counterexample.

Failure of a direct lift of one parent target does not make the complete
child cell empty.  A different parent matching or an off-face alternating
exchange may still supply a target.  Hence complete-family new-cell
supplementation remains the unresolved interface of Note 103; the exact
additional datum for any direct-lift argument is the exterior signature
\(\Omega_S(M)\), not the face word alone.
[Note 107](107-cofacial-complete-family-supplementation-can-be-entirely-nondirect.md)
shows on an actual legal-wide plane-brace site that all three new cells can
meet the crossing graph while every direct formula fails target admission;
it also gives a minimum abstract exchange-closed \(\Omega\)-blocker.
