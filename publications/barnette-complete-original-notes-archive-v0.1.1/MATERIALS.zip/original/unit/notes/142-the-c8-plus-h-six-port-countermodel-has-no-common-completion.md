> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The C8+h six-port countermodel has no common completion

[Note 141](141-complete-family-extremality-first-needs-common-cubic-completion.md)
gives a complete local matching countermodel whose only unrealized layer is
common cubic completion of its rooted complement signatures.  That layer is
not realizable.  The canonical \(C_{00}\) matching and its gate-changing
\(X_{uy}\) sibling have identical complementary six-port signatures, so
every common exterior makes them rooted or nonrooted together.  Whenever
the canonical matching is rooted, they form a new-cell child bond.

[Note 145](145-legal-wide-is-essential-for-short-gap-complete-family-compensation.md)
does not affect this particular-core obstruction, but it disproves the
broader inference that some common cubic completion argument must settle
the unrestricted problem. The surviving global question is legal-wide.

## 1. A boundary-pairing gluing lemma

Let \(K\) be a subcubic core whose six degree-two boundary vertices are
ports \(B\).  Complete it by an exterior \(E\), with one spoke at each
port.  Let \(L\) be a perfect matching internal to \(K\), and let \(O\)
be a compatible exterior matching.  Since \(L\) covers every core vertex,
no spoke belongs to \(L\cup O\).

Assume \(K-L\) has no closed component and is the union of three paths
pairing the ports; write this pairing as \(\pi(L)\).  Contracting those
three paths in the global complement leaves

\[
 (E-O)\cup\pi(L).
\tag{1}
\]

It follows immediately that if two internal perfect matchings \(L,L'\)
satisfy

\[
 \pi(L)=\pi(L')
\tag{2}
\]

and neither local complement has a closed component, then their extensions
by the same exterior matching have:

1. the same number of global complement cycles;
2. the same partition of every exterior vertex among those cycles.

In particular, when the root and forced edge lie in the common exterior
matching, the two extensions have identical rooted admission: their root
endpoints are separated by the complement cycles simultaneously.  This
lemma needs no planarity, bipartiteness, or cubicity beyond the stated
gluing interface.

## 2. The fixed local classification

Use the Note 141 parent core

\[
 u v r s x y w t u+uy,
\tag{3}
\]

with

\[
 p=uv,qquad q=xy,qquad h=uy,qquad g_1=ut,
\tag{4}
\]

and ports \(v,r,s,x,w,t\).  Its three internally perfect matchings
\(M,N,N^h\) have complementary port pairings

\[
\begin{aligned}
 \alpha&=(vr)(sx)(tw),\\
 \beta&=(vx)(rs)(tw),\\
 \gamma&=(vt)(rs)(wx),
\end{aligned}
\tag{5}
\]

respectively.  None has an internal closed complement cycle.

After the \(C_4\)-expansion, the child core has exactly eight internally
perfect matchings.  The carrying identity is

\[
 \boxed{
 \pi(\widehat N)=\pi(S_U)=\beta=(vx)(rs)(tw),}
\tag{6}
\]

where

\[
 \widehat N=N\cup\{ad,bc\},
\qquad
 S_U=\widehat N\triangle
 \bigl(P_{uy}\cup\{ua,ad,dy\}\bigr).
\tag{7}
\]

Both local complements consist of three paths and no closed component.
Moreover

\[
 \widehat N\triangle S_U
 =P_{uy}\cup\{ua,ad,dy\}
\tag{8}
\]

is one alternating cycle, while \(g_1=ut\) belongs to exactly one of the
two matchings.  Thus they lie in opposite surviving-gate sectors.

## 3. Common-completion obstruction

Suppose a common exterior matching \(O\) extends the rooted parent endpoint
\(N\).  Its canonical child lift \(\widehat N\cup O\) is rooted.  By
(6) and the gluing lemma,

\[
 \widehat N\cup O\text{ is rooted}
 \quad\Longleftrightarrow\quad
 S_U\cup O\text{ is rooted}.
\tag{9}
\]

Equations (8)--(9) and the gate-sector change show that

\[
 (\widehat N\cup O)-(S_U\cup O)
\tag{10}
\]

is an opposite-sector, one-cycle, new-cell rooted bond.  Extra perfect
matchings using boundary spokes can enlarge the complete child family but
cannot remove this bond.  Therefore:

> **Theorem.**  No common completion of the Note 141 \(C_8+h\) six-port
> core can realize its abstract extreme/no-supplement signature.  In
> particular, no connected cubic plane bipartite completion of that core is
> a short-gap ChildSupplement counterexample.

The theorem uses only one exterior matching slice and is stronger than a
finite nonexistence search.

## 4. Boundary-state certificate

For an independent finite check, enumerate all 15 pairings of the six
ports, rather than only plane-noncrossing pairings.  For each pairing allow
zero, one, or two port-free exterior complement cycles and every placement
of the two root endpoints on the exterior components.  This gives 750
boundary states.

There are 16 states satisfying the abstract parent extreme condition and
12 realizing the precise parent component counts \((2,2,3)\), so the CSP
does not eliminate the parent antecedent.  Nevertheless

\[
 \#\{\text{parent extreme, }\widehat N\text{ rooted, }S_U\text{ nonrooted}\}
 =0.
\tag{11}
\]

The zero is exactly the signature equality (6), not a planarity or cubicity
filter.

## 5. Exact remaining boundary

The minimal \(C_8+h\) realization route is closed.  A different real
counterexample core, if one exists, must make every gate-changing sibling
of a rooted canonical endpoint either

\[
 \pi(\widehat N)\ne\pi(S_g)
\tag{12}
\]

or introduce/remove an internal closed complement component. Note 142 does
not classify such cores. Note 145 supplies one outside the legal-wide
stratum, so an arbitrary-core complete-family statement is now false; this
note leaves only the legal-wide statement unresolved.

The complete finite signature check is frozen in the
[C8+h six-port completion-obstruction bundle](../computations/bundles/c8h-six-port-completion-obstruction/README.md).
