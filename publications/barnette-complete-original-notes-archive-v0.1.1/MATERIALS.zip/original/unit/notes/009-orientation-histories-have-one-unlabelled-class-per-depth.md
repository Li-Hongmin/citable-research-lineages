> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Orientation histories have one unlabelled class per depth

The two choices in the arbitrary-orientation construction of Notes 007 and
008 do not produce exponentially many nonisomorphic graphs.  At every depth,
all orientation histories give one unlabelled graph-isomorphism class.  This
is a general local symmetry, not an accidental automorphism of the order-240
root.

Let an ordered expansion site be

\[
s=(u,v,x,y),\qquad \sigma s=(x,y,u,v).
\]

Expanding \(s\) introduces \(a,b,c,d\) and edges

\[
ua,ab,bv,xc,cd,dy,ad,bc.
\]

Expanding \(\sigma s\) and applying

\[
\phi=(a\ c)(b\ d)
\]

gives exactly the expansion at \(s\).  The map \(\phi\) fixes every old
vertex.  If

\[
t_0=(b,c,d,a),\qquad t_1=(d,a,b,c)=\sigma t_0
\]

are the two successor-site markings, then

\[
\phi(t_0)=t_1,qquad \phi(t_1)=t_0.
\tag{1}
\]

Represent a depth-\(k\) orientation history by a word
\(b_1\cdots b_k\in\{0,1\}^k\).  Applying (1) at one expansion and
compensating at the next gives

\[
(\ldots,b_i,b_{i+1},\ldots)
\sim(\ldots,1-b_i,1-b_{i+1},\ldots)
\quad(1\le i<k).
\tag{2}
\]

The final bit changes only the marked successor site, not the unmarked graph
already constructed, so it may also be flipped after forgetting the mark.
Over \(\mathbb F_2\), the moves in (2) add \(e_i+e_{i+1}\), while the last
move adds \(e_k\).  These vectors span \(\mathbb F_2^k\).  Therefore every
two length-\(k\) histories give isomorphic unmarked graphs.  The composed
isomorphism can fix the original root pointwise.

Thus the exact unlabelled quotient is a path

\[
Q_0\longrightarrow Q_1\longrightarrow Q_2\longrightarrow\cdots,
\qquad Q_k\mathrel{\mathop{\longrightarrow}^{0,1}}Q_{k+1}.
\]

If the successor-site marking is retained, adjacent-pair flips alone leave
two word-parity orbits; this parity is not an invariant of the unmarked
graph.

For the explicit order-240 start, nauty canonicalization through depth eight
confirms one class at each depth, with class sizes

\[
1,2,4,8,16,32,64,128,256.
\]

All 255 local successor-site exchanges through depth seven were also checked
explicitly.  This computation is confirmatory; the word-quotient proof holds
for every depth and every root for which the construction is defined.

The edge-Hamiltonian conclusions of Notes 007 and 008 are unchanged.  They
provide one certified isomorphism type at every order \(240+4k\), not
\(2^k\) types at that order.  The verifier is
`scratch/worker-barnette/analyze_n240_orientation_history_isomorphism.py` and
ends with `N240_ORIENTATION_HISTORY_QUOTIENT_VERIFIED`.
