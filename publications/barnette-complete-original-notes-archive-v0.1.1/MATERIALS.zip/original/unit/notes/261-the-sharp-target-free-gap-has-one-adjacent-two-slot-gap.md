> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The sharp target-free gap has one adjacent two-slot gap

[Note 258](258-every-all-square-second-surplus-opening-is-hamiltonian.md)
places every positive-gap all-square opening above the second
surplus. [Note 259](259-two-target-free-vacancy-blocks-cannot-support-a-third-surplus-gap.md)
excludes two distinct target-free vacancy blocks at the third
surplus, while [Note 260](260-a-twenty-two-vertex-sharp-positive-gap-opening.md)
realizes two vacancies in one target-free block. The next theorem
shows that this realized gap pattern is the only local pattern
in the latter branch.

Use the compressed opening of Notes 193 and 195, and suppose
\[
\ell,r\ge1,\qquad f=4r+8,\qquad \sigma=2,\quad T=2.
\]
Assume both vacant eligible positions lie in one block \(B\)
and \(B\) contains no escape target. Write its six consecutive
interior slots in old-cycle order as \(w_1,\ldots,w_6\).

**Adjacent-gap normal-form theorem.** Up to reversing the main
segment and interchanging the two site edges, \(B\) immediately
precedes the unique positive gap, that gap consists of two
consecutive slots \(g=E,h=O\), and the complementary matching
has the following three forced edges:
\[
w_3w_6\quad\text{on the designated-face side},
\qquad w_5g,\quad w_4h\quad\text{on the opposite side}.
\tag{1}
\]
The two remaining slots \(w_1,w_2\) are adjacent on the old
Hamilton cycle and must match outside \(B\). In particular,
two singleton gaps in different positions cannot occur in
this target-free same-block branch.

**Proof.** All other blocks are capacity-saturated, so Note 255
excludes a same-block free chord in them. Note 258's gap-edge
localization sends both gap slots to \(B\) and requires a
face-side free chord there. Since \(B\) is target-free and
contains both vacancies, it has capacity two and exactly six
free slots. The complete list of non-cycle opposite-colour
pairs within \(B\) is
\[
w_1w_4,\quad w_1w_6,\quad w_2w_5,\quad w_3w_6.
\tag{2}
\]
Two disjoint face-side pairs in (2) can be noninterlacing
only when they are the nested pair \(w_1w_6,w_2w_5\).
Then the unused inner slots \(w_3,w_4\) are straddled by
two face-side chords, an even number; Note 258's odd
gap-to-block parity prevents either from receiving a gap
edge. Hence \(B\) has exactly one face-side chord \(e\).
Each gap mate lies strictly between its endpoints.

If \(e=w_2w_5\), the two mates are \(w_3,w_4\). When \(B\)
lies before both gaps or after both, it is forward:
\(g\) must meet \(w_3\) and \(h\) must meet \(w_4\), and
the opposite-side chords interlace. When \(B\) lies between
two singleton gaps, it is reversed: \(g\) meets \(w_4\)
and \(h\) meets \(w_3\), again giving interlacing chords.
Thus this pair is impossible.

If \(e=w_1w_6\), all four inner slots lie under exactly one
face-side chord. Two are gap mates. By the cross-block parity
lemma of Note 259, either unused inner slot cannot match a
slot of a saturated block, and both gap slots are already
used. The unused inner slots must match each other. Among
\(w_2,w_3,w_4,w_5\), the only nonadjacent opposite-colour
pair is \(w_2w_5\). Hence the gap mates are \(w_3,w_4\),
whose opposite-side chords interlace exactly as in the
previous paragraph. This excludes \(w_1w_6\).

The face-side chord is therefore \(w_1w_4\) or \(w_3w_6\).
If \(B\) lies between the singleton gaps, it is reversed.
For \(w_1w_4\), the gap chords use \(gw_2,w_3h\), and the
remaining adjacent pair \(w_5,w_6\) lies under \(w_3h\).
For \(w_3w_6\), the gap chords use \(gw_4,w_5h\), and the
remaining adjacent pair \(w_1,w_2\) lies under \(gw_4\).
In either case, take the old-cycle interval from \(g\)
through \(h\). The gap chords cover every intervening
atom; a target would be straddled and is excluded by
Note 203. No free-slot edge can leave the interval on
the opposite side without crossing a gap chord, while
every face-side chord lies within a complete block.
All six slots of \(B\) are matched internally or to its
gap endpoints, except the adjacent pair just identified;
that pair is itself trapped under a gap chord. Therefore
the interval is matching-closed and has a forbidden
two-edge cut. So \(B\) does not lie between split gaps.

If \(B\) precedes both gap slots, it is forward. For
\(e=w_1w_4\), the forced gap chords are \(w_3g,w_2h\),
and the remaining adjacent pair \(w_5,w_6\) lies under
the outer chord \(w_2h\). The complete interval from
\(B\) through \(h\) is matching-closed by the same
noncrossing and target-free argument, a contradiction.
Thus \(e=w_3w_6\), and colour forces \(w_5g,w_4h\).
If \(B\) follows both gaps, reflection gives this same
case, proving the orientation in the statement.

It remains to locate the gaps relative to \(B\). With
\(B\) before \(g<h\), the two chords in (1) are nested:
\(w_4h\) encloses \(w_5g\). If the gaps were distinct,
the complete blocks between them would contain no target
by Note 203 and no vacancy outside \(B\); hence they would
be short. Their free slots cannot match outside that
complete-block interval: an opposite-side chord to the
left crosses \(w_5g\) or \(w_4h\), one to the right crosses
\(w_4h\), and a face-side chord in a short block is an
old-cycle edge. This gives a forbidden two-edge cut.
Thus \(g,h\) are consecutive slots of one gap.

Finally, if a complete block lay between \(B\) and this
gap, it too would be target-free and short. Its free slots
lie under \(w_5g\); any opposite-side edge leaving the
union of such intervening blocks crosses \(w_5g\), and
there is no face-side free edge. Their union would have
only two departing old-cycle edges. Therefore the gap
immediately follows \(B\). The first two slots \(w_1,w_2\)
are adjacent on \(C\), so they cannot match each other;
all other slots of \(B\) are used in (1), proving the final
claim. \(\square\)

Note 260 realizes the normal form with \(B=[4,11]_C\),
\((w_1,\ldots,w_6)=(5,6,7,8,9,10)\), and \((g,h)=(12,13)\).
The theorem classifies this target-free local interface; it
does not classify target-bearing vacancies or decide whether
every graph with this interface has a marked Hamilton cycle.
