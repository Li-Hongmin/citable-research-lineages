> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Cycle-traversed port gaps absorb arbitrary internal components

[Note 302](302-an-unbounded-chain-of-missing-links-has-three-spanning-routes.md)
routes a serial chain of end-port components, and
[Note 303](303-final-gap-port-branches-preserve-the-three-route-signature.md)
routes an additional chain in a component's final vacancy gap.
The earlier gaps have a different, simpler property: the relevant
paths traverse them on the old Hamilton cycle and use none of their
complementary matching edges. They can therefore contain port
components of unrestricted number and nesting without new local
routes.

Work in the compressed, gapless, tight-target all-square opening
of Notes 275--303. Let an actual Barnette parent have Note 302's
surrounding vacancy component and serial outer port components
\(\mathcal P_1,\ldots,\mathcal P_k\), with their displayed
rainbow matching edges and retained group end links. Write
\[
 \mathcal P_i:\quad P_{a_i}<V_{r_{i,1}}<\cdots<
 V_{r_{i,p_i-1}}=V_{v_i}<V_{r_{i,p_i}}=V_{u_i},
 \qquad a_i=u_{i-1},\quad p_i\ge2.                 \tag{1}
\]
As in Note 302, the first proper gap of \(\mathcal P_1\)
has its crossed rails \(X\), and the ordinary link from
its last block into \(B_{r_{1,1}}\) is retained. Keeping
all ordinary links of this first gap is one sufficient
way to meet that condition. At each final gap
\((V_{v_i},V_{u_i})\), require one of these two interfaces:

1. The boundary links \(P_{v_i}=e_{v_i}o_{v_i+1}\) and
   \(P_{u_i-1}=e_{u_i-1}o_{u_i}\) are retained (the same
   link when \(u_i=v_i+1\)). If the block interval
   \(F_i=B_{v_i+1},\ldots,B_{u_i-1}\) is nonempty, it has
   two disjoint vertex-spanning crossed paths
   \(X_{\rm top}:a_{v_i+1}\leadsto b_{u_i-1}\) and
   \(X_{\rm bottom}:o_{v_i+1}\leadsto e_{u_i-1}\).
   Its internal matching and missing links are otherwise
   unrestricted.
2. The gap has the recursively branched fold of Note 303.

All attachments outside the outer port chain retain the
signatures used in Note 302.

Inside any other proper atom gap of any \(\mathcal P_i\),
allow an arbitrary noncrossing collection of additional
vacancy-only and port components, including missing ordinary
links. The collection need not itself have an \(S\), \(K\),
or \(X\) signature. The only excluded gap is the first gap
of \(\mathcal P_1\), whose \(X\) rails are used by the
first-port path. A final gap is governed by its stated fold.
The added atoms and edges must respect the fixed outer
component matching and the actual Barnette embedding; these
are hypotheses about the graph, not conclusions inferred from
an arbitrary formal atom partition.

**Cycle-traversed-gap theorem.** Every free group described
above has the three vertex-spanning \(S,K,X\) states of
Note 302(4), regardless of the number, sizes, or nesting of
the extra components in the allowed gaps. All three states
simultaneously avoid every matching edge of those extra
components. If the other free
groups have their ordinary spanning routes, the parent has a
Hamilton cycle through both site edges and its legal
site-expanded child is Hamiltonian; these cycles also avoid
the matching edges of the extra components.

**Proof.** For \(\mathcal P_i\), the path \(T_i\) of
Note 286(7)--(8), or \(\widetilde T_i\) of Note 303(11),
begins
\[
 b_{a_i}\xrightarrow{C\text{ forward}}I_{v_i},H_{u_i},o_{u_i}.
                                                               \tag{2}
\]
The arc in (2) traverses every block strictly after
\(B_{a_i}\) through \(B_{v_i}\) in old-cycle order. It
therefore covers all vertices in each gap before
\(V_{v_i}\), including every vacancy slot and both endpoints
of every new missing ordinary link. It uses no matching edge
with an endpoint in any such gap. Its only matching edge in
(2) is the fixed outer-component edge \(I_{v_i}H_{u_i}\).
For the first final-gap interface, the fold is exactly
Note 286(8), with the stated \(X\) paths in place of its
vacancy-only rails; its two end links are the only ordinary
links used outside \(F_i\). When \(F_i\) is empty, use
Note 286's direct finish. For the second interface use
Note 303(11). Either fold is disjoint from the prefix and
covers the remaining blocks through \(B_{u_i}\), except
\(I_{u_i},e_{u_i}\). Hence the
endpoints, source-block restriction, and complete vertex
inventory of every \(T_i\) are unchanged.

The straight route of Note 302 uses one further path,
\(L_1\) from Note 287(5). It crosses only the first proper
gap of \(\mathcal P_1\), then follows \(C\) from
\(H_{r_{1,1}}\) to \(I_{u_1}\). Thus every allowed gap
of \(\mathcal P_1\) is also traversed along \(C\) by
\(L_1\), independently of its new matching. The first gap
still has its required \(X\) rails. The remaining straight,
cap, and crossed paths in Note 302(10), (14), (17), and (18)
use \(L_1\) and the \(T_i\) only by their endpoints and
vertex inventories. They use no new matching edge in an
allowed gap. Their original disjointness and coverage
arguments therefore apply word for word. Note 275 composes
the surrounding vacancy-only parts, and Notes 273, 001,
and 178 give the marked parent and legal child conclusions.
\(\square\)

In particular, a final gap with retained boundary links may
contain any two-consecutive-port group whose \(X\) state is
given by Note 300. The earlier cycle-traversed gaps may at
the same time contain arbitrary additional port components.
The two insertions use disjoint vertex intervals and their
proofs require no matching classification across those
intervals.

**An unbounded nested-port family.** For every \(d\ge1\),
use the old-cycle layout of Note 281(8) with \(\ell=1\),
\[
 v=2d+4,\qquad u=v+1,
 \qquad z=u+1=r=2d+6.                              \tag{3}
\]
Make exactly the blocks
\[
 B_1,B_3,B_5,B_7,\ldots,B_{2d+3},B_v,B_u,B_z
                                                               \tag{4}
\]
vacant and all other internal blocks short. The displayed
list has \(d+5\) vacant blocks. Retain all ordinary links
except \(P_1\) and \(P_{2j+1}\), \(1\le j\le d\).
Keep Note 281's site, face, escape, and residual-square
matching edges, and add the free matching edges
\[
\begin{array}{ll}
H_1I_z,\ I_1H_z;&\mathcal C=\{V_1,V_z\},\\
e_1I_u,\ o_2H_3,\ I_3H_v,\ I_vH_u;&
  \mathcal P=\{P_1,V_3,V_v,V_u\},\\
e_{2j+1}I_{2j+3},\ o_{2j+2}H_{2j+3}
  \quad(1\le j\le d);&
  \mathcal Q_j=\{P_{2j+1},V_{2j+3}\}.
\end{array}                                                   \tag{5}
\]
The \(\mathcal Q_j\) form an arbitrarily long port chain
in the *earlier* atom gap \((V_3,V_v)\) of \(\mathcal P\),
outside the final-gap grammar of Note 303.
The two local paths used by the three-state construction are,
explicitly,
\[
\begin{split}
T:&\quad b_1\xrightarrow{C\text{ forward}}I_v,H_u,o_u,
 e_v,b_v,a_u,b_u,\\
L_1:&\quad a_2,b_2,a_3,o_3,e_2,o_2,H_3
 \xrightarrow{C\text{ forward}}I_u,e_1.
\end{split}                                                   \tag{5a}
\]
Every edge after the respective \(C\)-arcs is an old-cycle,
face-chord, retained ordinary, or displayed matching edge.
The side-chain edges in (5) are unused. The paths have exactly
the inventories required by Note 302(7)--(8), so that note's
global \(S,K,X\) splice applies.

Equation (5) pairs all \(2(d+5)\) vacancy slots and
\(2(d+1)\) missing-link slots exactly once. Each edge
joins opposite old-cycle colours. In the disk opposite the
site face, \(H_1I_z\) encloses \(I_1H_z\), \(e_1I_u\)
encloses the remaining port chords, and \(I_3H_v\)
encloses the pairwise disjoint \(\mathcal Q_j\) chords.
Each \(e_{2j+1}I_{2j+3}\) encloses its companion
\(o_{2j+2}H_{2j+3}\); the retained ordinary links are
nested or disjoint from these chords. Thus the unchanged
common site face and a plane bipartite cubic embedding exist.

For three-connectivity, let \(F_j=a_jb_j\) be the face
chord of \(B_j\). A retained \(P_j=e_jo_{j+1}\)
interlaces \(F_j,F_{j+1}\). At each missing
\(P_{2j+1}\), the replacement chord
\(e_{2j+1}I_{2j+3}\) interlaces
\(F_{2j+1},F_{2j+3}\), while
\(o_{2j+2}H_{2j+3}\) interlaces
\(F_{2j+2},F_{2j+3}\). At the missing \(P_1\),
\(e_1I_u\) joins \(F_1\) to \(F_u\), and
\(o_2H_3\) joins \(F_2\) to \(F_3\). The fixed
\(I_3H_v\) joins \(F_3,F_v\), while the retained
links and \(I_vH_u\) join \(F_v,F_u,F_z\).
Consequently all internal face chords lie in one connected
interlacement component. Every other special chord in (5)
interlaces a face chord at one of its endpoint blocks;
the unchanged site and residual-square closing chain of
Note 281 joins that component. The connected interlacement
criterion of Note 217 excludes two-edge cuts, and the cubic
lemma of Note 182 gives three-vertex connectivity.

Here \(r=2d+6\) and there are \(d+5\) vacancies, so the
parent and legal child have respectively
\[
 12+4r+2(d+5)=46+10d,
 \qquad 50+10d                                      \tag{6}
\]
vertices. The theorem supplies their Hamilton cycles
analytically for every \(d\), while simultaneously avoiding
all \(2d\) side-chain matching edges in (5). The smallest member has
56 and 60 vertices.

This theorem does not classify the unrestricted free-group
matchings, other opening shapes, or all Barnette graphs.
