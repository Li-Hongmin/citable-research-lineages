> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every two-double mixed J1/J3 free group has a spanning route

[Note 335](335-two-oppositely-oriented-double-vacancies-have-one-adjacent-mixed-core.md)
forces the orientation and adjacency of two oppositely oriented
doubly vacant blocks in an ordinary target-free free group. It
also gives a spanning endport-to-endport path when all short
blocks lie on one side. A boundary-link argument now removes
that last one-sided restriction.

Let a Barnette parent have the compressed, gapless,
tight-target all-square opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix an ordinary target-free free group whose only nonshort
complete blocks are exactly two doubly vacant blocks, one
carrying \(J_1\) and one carrying \(J_3\). All other complete
blocks of this group are short. Their numbers on the two sides
are arbitrary; no singly vacant or other multiply vacant
block occurs in this group. Write \(L,R\) for its even left
and odd right free endports.

**Mixed two-double-group theorem.** The \(J_1\)-then-\(J_3\)
order cannot occur. In the other order the double blocks are
adjacent, have the forced cross chords of Note 335, and the
entire group has a vertex-spanning \(L\)--\(R\) path. If its
remaining \(hJ\) chord is present, its double-block core is
the square-equivalent four-pole of Note 335. If \(hJ\) is
absent, repeated removal of standard short-block boundary
links exposes a one-sided chain with the explicit route of
Note 335. These removals construct a path; they do not assert
a six-terminal square replacement.

If every vacancy outside this group occupies a distinct
internal block, the parent has a Hamilton cycle containing
both site edges, and its legal site-expanded child is
Hamiltonian. The same assertion holds when several disjoint
groups satisfying this theorem occur, provided all other
vacancies occupy distinct internal blocks.

**Proof.** The first orientation is impossible by Note 335.
For the second, write the adjacent mixed blocks as
\[
D=(a,o,h,i,k,j,e,b),\qquad
D'=(A,O,H,I,K,J,E,B),                                \tag{1}
\]
with common-face chords \(ie,OK\). Note 335 forces the
opposite-side matching edges \(jH,kI\). All other free
slots of these two blocks are \(o,h,J,E\), in that order.
If \(hJ\) occurs, Note 335 compresses \(D,D'\) to a short
square without changing the four exterior attachments.
The reduced group consists only of short blocks; the
ordinary-link argument of Note 275 supplies its spanning
\(L\)--\(R\) path, and the exact square signature lifts
that path. We therefore assume \(hJ\) is absent.

Let the short blocks before \(D\) be
\(S_t=(c_t,o_t,e_t,d_t)\), \(1\le t\le p\), and the
short blocks after \(D'\) be
\(T_t=(C_t,u_t,v_t,D_t)\), \(1\le t\le q\). The old-cycle
order of the still-free slots is
\[
L,o_1,e_1,\ldots,o_p,e_p,o,h,J,E,
u_1,v_1,\ldots,u_q,v_q,R.                            \tag{2}
\]
Every matching edge joining different blocks lies opposite
the common face by Note 193. It is noncrossing there. We
also repeatedly use the following consequence of
three-edge-connectivity: a nonempty proper consecutive
interval of complete blocks cannot have all its
complementary-matching edges internal. Its only leaving
edges would be the two boundary old-cycle edges.

**Boundary-link lemma.** If \(p,q\ge1\), at least one of
\[
                         Lo_1,\qquad v_qR                 \tag{3}
\]
belongs to the complementary matching.

Suppose \(Lo_1\) is absent. A mate \(o_t\), \(t>1\), of
\(L\) would enclose the complete short blocks
\(S_1,\ldots,S_{t-1}\). They would be matching-closed by
noncrossing, contrary to the preceding cut rule. A mate
\(o\) would similarly close all \(p\) left short blocks,
and \(LR\) would close every complete block of the group.
The odd internal slots of the two double blocks other than
\(o,J\) are already used by \(ie,OK,jH,kI\). Thus \(L\)
can only meet \(J\) or a right short-block slot \(u_t\).

Suppose also that \(v_qR\) is absent. If \(R\) met
\(v_t\) for \(t<q\), the complete short-block suffix
\(T_{t+1},\ldots,T_q\) would be matching-closed. If
it met \(E\), all \(q\) right short blocks would be
matching-closed. If it met some left \(e_t\), the
complete suffix \(S_{t+1},\ldots,S_p,D,D',T_1,\ldots,T_q\)
would be matching-closed; \(LR\) was already excluded.
All other even free slots are used, except \(h\).
Consequently \(hR\) must occur. But either \(LJ\) or
\(Lu_t\) crosses \(hR\) in the opposite-side disk:
\(L<h<J,u_t<R\) in (2). This contradiction proves (3).
Each claimed closed interval includes its face-closing
chords and the forced \(ie,OK,jH,kI\) whenever the
double blocks occur; no common-face cross-block chord
can provide an extra exit.

We now peel only in the *path construction*; the Barnette
graph itself is unchanged. At every stage the active blocks
form a consecutive subinterval of the original blocks. Its
endports are either \(L,R\) or the nearest free slots of
previously peeled short blocks. All other free slots in a
peeled block have already been matched by a reserved path
segment, and only its active endport may have a matching edge
to an active block. If \(Lo_1\) occurs, reserve the
path segment
\[
                  L,o_1,c_1,d_1,e_1.                      \tag{4}
\]
Treat \(e_1\), an even free slot, as the new left endport
and remove \(S_1\) from the list of unvisited complete
blocks. If \(v_qR\) occurs, reserve instead
\[
                  u_q,C_q,D_q,v_q,R,                       \tag{5}
\]
treating \(u_q\), an odd free slot, as the new right
endport. Each segment uses the block's face chord and
two old-cycle edges as well as its specified matching
edge. The other free slot of the peeled block becomes the
only port by which the unvisited matching can enter it.

The argument for (3) still applies after a peel. The new
endport has the same parity and cyclic position relative
to the remaining complete blocks; all its possible
cross-block chords are still opposite the common face.
For example, a left endport joined to a later short block's
first free slot encloses precisely the intervening complete
blocks. No matching edge can leave that interval on the
opposite side without crossing the endport chord, and every
face-side chord of an enclosed block stays inside it. The
same statement holds for every prefix or suffix interval
used above, including the full active block interval if
the two endports are matched together. Each is a nonempty
proper consecutive interval of *original* complete blocks
with only its two old-cycle boundary edges leaving. The
face chords of peeled blocks stay outside. Thus each would
be a forbidden two-edge cut in the original graph; the
induction does not rely on the residual subgraph being
Barnette.
At each step \(p+q\) decreases. Eventually \(p=0\) or
\(q=0\). The one-sided matching proof and spanning path
of Note 335 use only the ordered even/odd endports,
noncrossing, and the same complete-block cut rule, so
they apply to these possibly virtual endports. If both
counts reach zero, Note 335 would force \(hJ\), contrary
to the present assumption. Concatenate the terminal
one-sided path with the reserved segments (4)--(5) in
reverse peeling order. Adjacent pieces share just their
designated endport; together they visit every original
group vertex once and run from the original \(L\) to
the original \(R\). This proves the spanning-route claim.

This route replaces only the group's standard free-path
segment and leaves the target-and-residual-square path
untouched. The local arguments of Note 324 supply
compatible routes in every other group when its vacancies
lie in distinct internal blocks. Groupwise composition
therefore gives two internally disjoint spanning
\(x\)--\(v\) paths whose union is a Hamilton parent
cycle containing both site edges. Multiple groups of
the present type have disjoint interiors and their path
replacements commute. Finally [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the Hamilton cycle in each legal site-expanded child.
\(\square\)

The theorem covers arbitrary short-block flanks around exactly
one \(J_3,J_1\) mixed pair in an ordinary target-free group.
It does not cover a third multiply vacant block, a singly
vacant block in the same group, other internal chord types,
target-bearing terminal vacancies, positive gaps, defective
target order, nonsquare residual cycles, or the general
Barnette conjecture. The proof is analytic and project-internal;
no external priority or independent review is claimed.
