> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every sharp square-trap opening has a Hamiltonian child

[Note 182](182-two-long-facial-gaps-require-six-free-main-vertices.md)
gives the sharp bound \(|V(S_0)|\ge2\ell+10\) for an
all-square-trap facial opening with two long site gaps.
[Note 183](183-sharp-square-traps-have-exactly-one-opposite-face-chord.md)
shows that at equality the other facial arc contains exactly
one matching chord and that both site ports lie inside
escape-pair gaps. These facts force the entire six-free-vertex
core. The resulting expanded graph has a Hamilton cycle.

Work in the one-square-per-lobe reduction of Note 178. Write
the site ports on the old main \(C\)-segment as
\(x<y<u<v\). The escape targets occur in reverse lobe
order as \(R_\ell,L_\ell,\ldots,R_1,L_1\), with each
\(R_i\) at an odd \(S_0\)-index and each \(L_i\) at an
even index. Let \(M\) be the perfect matching complementary
to the parent Hamilton cycle \(C\).

**Sharp transfer theorem.** Suppose a legal Barnette
expansion has such an all-square opening, both site-face
arcs have length at least three, and
\[
|V(S_0)|=2\ell+10.
\tag{1}
\]
Then the parent has a Hamilton cycle containing both site
edges \(q=xy\) and \(p=uv\). Consequently the expanded
child has a Hamilton cycle. This holds for arbitrary
\(\ell\ge1\) and arbitrary positive lengths of the
original square-trap lobes.

**Classification of the reduced parent.** Exactly six
vertices of \(S_0\) are neither site ports nor escape
targets; call them free. The other face arc has one matching
chord with both endpoints strictly between \(y,u\), by
Note 183. Also by that note, \(y,u\) lie inside pair gaps
\((R_i,L_i)\), possibly the same gap. A chord joining
free vertices in different target gaps cannot lie on the
escape side of \(C\): it would enclose an escape target and
cross its escape chord. Thus such a chord must lie on the
face side. To avoid crossing \(q,p\), both endpoints must
lie in the same one of \((x,y),(y,u),(u,v)\).

First suppose \(y,u\) lie in the same pair gap \((R,L)\).
It contains at least four free vertices: one before \(y\),
two between \(y,u\), and one after \(u\). If it contained
only four, the remaining two free vertices would lie in one
other target gap, where they would be consecutive on \(C\).
They cannot match each other by simplicity, so both would
have to match across gaps on the face side. A gap earlier
than \((R,L)\) would require two partners before \(y\)
inside \((R,L)\), and a later gap two partners after \(u\).
At four free vertices there is only one on each side.
Therefore all six free vertices lie in \((R,L)\).

The numbers before \(y\) and after \(u\) are odd and
positive; the number between the ports is even and at least
two. Their sum is six. If there were only two between the
ports, they would be consecutive on \(C\), so they could
not form Note 183's face-arc matching chord. Hence the
counts are \((1,4,1)\), and the exact main-path order is
\[
R,s,y,a,b,c,d,u,t,L.
\tag{2}
\]
The only bipartite matching edge among the four consecutive
vertices \(a,b,c,d\) that is not a \(C\)-edge is \(ad\).
Thus it is the face-arc chord. The remaining four free
vertices must be paired as \(sb,ct\): the only alternative
would use the forbidden \(C\)-edge \(bc\). Every other
escape-target pair is adjacent on \(S_0\), since there are
no free vertices outside \((R,L)\).

Now suppose \(y,u\) lie in distinct pair gaps, the
\(y\)-gap preceding the \(u\)-gap. Each gap contains an
odd number of free vertices, at least one. The \(y\)-gap
cannot contain only one. Its sole free vertex would lie
before \(y\); all other free vertices before \(y\) come
in even-sized target gaps. No matching chord can cross from
this odd set of free vertices to after \(y\): any such chord
interlaces \(q\), so it would have to lie on the escape side,
but the only gap straddling \(y\) contains no free vertex
after it. Thus an odd set would have to be perfectly matched
internally, a contradiction. The symmetric argument shows
that the \(u\)-gap cannot contain only one free vertex.
Each therefore contains at least three; since there are only
six free vertices, each has exactly three and every other
target gap is empty.

The \(y\)-gap must have one free vertex before \(y\) and
two after it. If all three preceded \(y\), the same odd-set
argument would apply. Symmetrically, the \(u\)-gap has two
free vertices before \(u\) and one after. The main order
through the two gaps is consequently
\[
R_i,s,y,a,b,L_i,\quad
[\text{adjacent escape-target pairs}],\quad
R_j,c,d,u,t,L_j,
\tag{3}
\]
where \(i>j\), and every escape-target pair outside these
two gaps is adjacent as well. The free vertex \(s\) cannot
match outside its pair gap: no free vertex remains in an
earlier gap, and a chord to any later gap would interlace
\(q\) and enclose an escape target. Bipartiteness then
forces \(sb\), since \(s,a\) have the same colour.
Symmetrically \(ct\) is forced. The remaining free vertices
\(a,d\) are matched; that chord lies on the face side and
is exactly Note 183's unique opposite-arc chord.

In both cases the other facial arc is therefore precisely
\(y,a,d,u\), of length three. The reduced parent is fully
specified by one of the two cores (2)--(3), with arbitrary
adjacent escape-target pairs inserted before, between, or
after the exceptional pair gaps. The residual squares and
their escape edges are forced by the escape order. Deleting
any such adjacent target pair together with its corresponding
residual square, and restoring the two interrupted \(C\)-edges,
leaves the same type of core. Reversing these deletions
therefore reaches every classified reduced parent.

**Hamilton cycles and insertion.** For the same-gap core
with just one residual square, number \(C\) from 0 at \(x\).
The main vertices have indices 0 through 11 and the square
vertices 12 through 15. Its complementary matching pairs
are
\[
(0,3),(1,14),(2,5),(4,7),(6,9),(8,11),(10,13),(12,15).
\tag{4}
\]
The matching together with the even-indexed \(C\)-edges
forms the single Hamilton cycle
\[
0,3,2,5,4,7,6,9,8,11,10,13,12,15,14,1,0.
\tag{5}
\]
For the distinct-gap core with two residual squares, the
matching pairs and the analogous 22-vertex Hamilton cycle
are explicitly displayed in Note 182, equations (9)--(10).
Both base cycles contain \(p,q\).

Every adjacent escape-target pair outside a core is obtained
by the following six-vertex insertion. Select the \(C\)-edge
\(AB\) between two successive target-pair blocks on \(S_0\),
allowing \(A=x\) or \(B=v\). Select the corresponding
\(C\)-edge \(PQ\) between residual-square blocks in the
reverse order, allowing \(P=v\) or \(Q=x\). Replace the two
edges by
\[
A,R,L,B
\qquad\text{and}\qquad
P,\alpha,\gamma,\delta,\beta,Q,
\tag{6}
\]
and add matching edges \(\alpha\beta,\gamma L,\delta R\).
The main edge \(AB\) is an even-indexed \(C\)-edge, so it
belongs to the displayed base Hamilton cycle and to every
cycle obtained by previous insertions. Replace it in that
cycle by the spanning path
\[
A,R,\delta,\beta,\alpha,\gamma,L,B.
\tag{7}
\]
All seven transitions are edges of the enlarged parent and
the six new vertices occur exactly once. The site edges
\(p,q\) are unchanged. More precisely, inserting two main
vertices and four residual-square vertices preserves the
parity of every surviving old \(C\)-edge. Path (7) uses
exactly the new even-indexed \(C\)-edges and all three new
matching edges. Thus the Hamilton cycle remains
\(M\cup E_{\rm even}(C)\) after each insertion, so the next
eligible main edge is again on it. Induction gives a parent Hamilton
cycle through both site edges for every classified reduced
graph. Note 001's direct lift replaces each site edge by
its three-edge patch route and gives a Hamilton cycle of the
expanded child.

Finally, Note 178 transfers both the Hamilton decision and
the marked use of the exterior site edges back through the
even-ladder replacements that were used to reduce each
original lobe. Thus the original parent has a Hamilton cycle
through \(p,q\), and its expanded child is Hamiltonian.
\(\square\)

The result covers the sharp all-square opening (1). It does
not assert Hamiltonicity for longer main segments, openings
with nonsquare residual cycles, or all Barnette graphs.
