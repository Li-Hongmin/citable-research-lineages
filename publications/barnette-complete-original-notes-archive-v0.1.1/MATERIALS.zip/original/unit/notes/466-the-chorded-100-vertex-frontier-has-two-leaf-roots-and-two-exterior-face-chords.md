> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The chorded 100-vertex frontier has two leaf roots and two exterior face chords

[Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) bounds a non-Hamiltonian doubly reduced chorded single-hexagon child by \(4+12f\) vertices. Equality forces a more specific two-root, all-leaf configuration; the two assignable positions outside the roots must be genuine face-chord endpoints.

Let \(f\ge7\), let \(e=2\) denote the internal hexagon matching chord \(ad\), and use the ordinary-forest notation \(m,R,c,M_0,L,A,Q\) of [Notes 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md) and [415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md). Let \(t_c<t_b\) be the two escape targets of the hexagon, and let \(z_L,z_R\) denote the other two assignable special positions outside the ordinary roots.

**Two-root equality theorem.** If the legal child is non-Hamiltonian and \(c=5f-6\), then \(m=f,R=2,M_0=L=f\): every assigned special position occurs in a distinct two-special ordinary leaf. The four outside markers have the order
\[
                         z_L<t_c<t_b<z_R.
\tag{1}
\]
At least one of the two roots lies strictly between \(t_c,t_b\). Neither \(z_L\) nor \(z_R\) is a site port, and they are not paired to one another. Thus both are endpoints of face-side chords with distinct mates in the root words; both site ports \(u<v\) lie in the roots. At \(f=8\), this is a necessary profile for a 100-vertex chorded reduced failure, not a claim that one exists.

**Proof.** The charge \(c\le5m-3R\) and \(m\le f\) of Note 415 exclude \(m\le f-1\) and \(R\ge3\). For \(m=f,R=1\), use the refined charge \(c\le2(M_0+L)+f-3\). If \(M_0+L\le2f-2\), then \(c\le5f-7\). If \(M_0=L=f\), all assigned positions are two per leaf and [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) makes the child Hamiltonian. The remaining possibility is \(M_0=f,L=f-1\). Here every marked node receives exactly two positions and every leaf is two-special, so \(Q=L=f-1\). The finer bound gives
\[
 c\le3A-Q\le3(M_0+L-R)-L=5f-6.
\]
Equality forces \(A=M_0+L-R=2f-2\), hence the one marked nonleaf is not a branching node. It is unary. If its assigned positions are adjacent, [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md) closes it; if they straddle its child, Note 460 closes it. Therefore equality requires \(m=f,R=2\). Equality in \(c\le2(M_0+L)+m-3R\le5m-3R\) then forces \(M_0=L=m=f\), proving the all-leaf assertion.

Every root word has even order. Index \(w_0\) by zero along the old cycle. The hexagon vertices \(c,b\) have odd and even old-cycle parity, respectively, so their matching targets \(t_c,t_b\) have even and odd parity. The index parity of each outside marker is its rank among the four outside markers, because all intervening root words have even order. As \(t_c<t_b\), their ranks must be two and three, proving (1). If no root lies between them, they are adjacent old-cycle vertices; the adjacent-escape merger of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) would make the child Hamiltonian.

The site port \(u\) has odd index and \(v\) even index. Thus only \(z_L=u\) or \(z_R=v\) is possible among outside markers. Suppose \(z_L=u\). If there is no root before \(z_L\), then \(w_0z_L\) is already an old-cycle edge and cannot be the distinct site edge. If a root lies before \(z_L\), it is the only such root, since another lies between \(t_c,t_b\). It contains no site port. Any face chord from it to a later root or to \(z_R\) interlaces \(q=w_0u\), and \(z_L\) is itself a site port. Hence all its face matching is internal, leaving its two old-cycle boundary edges as a forbidden two-edge cut. This excludes \(z_L=u\). Reflecting the order, if \(z_R=v\), either \(z_Rw_*\) duplicates an old edge or a unique root after \(z_R\) is site-free and cannot send a face chord across \(p=vw_*\). Thus both outside markers are face-chord endpoints and \(u,v\) lie in roots.

Finally suppose \(z_Lz_R\) is a face chord. If either site port lies strictly between them, that chord interlaces \(q=w_0u\) or \(p=vw_*\): for \(u\) use \(w_0<z_L<u<z_R\), and for \(v\) use \(z_L<v<z_R<w_*\). If neither site port lies between them, the mandatory root between \(t_c,t_b\) contains no site. The chord \(z_Lz_R\) traps that root on the common-face side; no face chord from it can reach the other root outside \([z_L,z_R]\), and \(z_L,z_R\) are already matched. Thus its only external edges are its two old-cycle boundary edges, again contradicting three-connectivity. Therefore the markers have distinct mates in roots. \(\square\)

This theorem identifies the 100-vertex chorded equality interface. It does not settle its Hamiltonicity or improve Note 460's global chorded bound.
