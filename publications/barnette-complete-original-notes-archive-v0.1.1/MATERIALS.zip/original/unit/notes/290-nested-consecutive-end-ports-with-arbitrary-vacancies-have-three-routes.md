> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nested consecutive end ports with arbitrary vacancies have three routes

Note 281 includes nested consecutive port parts when each
has one vacancy. Note 282 permits arbitrarily many vacancies
per end-port part but assumes the missing links are not
consecutive. The local prime construction of Note 282
accepts any three-state proper gap. A nested consecutive
pair has precisely such a gap, even though its two parts
share a short boundary block.

Work in a compressed, gapless, tight-target all-square
opening of a Barnette parent. All vacancies lie in distinct
target-free internal face-chord blocks. In one free group,
let the only missing ordinary links be
\(P_s=e_so_{s+1}\) and \(P_{s+1}=e_{s+1}o_{s+2}\).
Suppose their distinct noncrossing atom components have
the relative orders
\[
\begin{array}{ll}
\mathcal O:&V_{i_1}<\cdots<V_{i_p}<P_{s+1},\\
\mathcal I:&V_{j_1}<\cdots<V_{j_q}<P_s,
\end{array}
\qquad
i_p<j_1,\quad p,q\ge1.                            \tag{1}
\]
The two port atoms are consecutive in the reduced order;
other atoms may lie in proper gaps of (1). Assume
\(B_{s+1},B_{s+2}\) are short, every other component
is vacancy-only, and the group's ordinary end links
are retained. The block \(B_s\) need not be short.

**Nested consecutive-port theorem.** The group's full
target-free internal interval \(D=B_a,\ldots,B_b\)
has the three vertex-spanning states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b.
\end{array}                                             \tag{2}
\]
The counts \(p,q\), their spacings, and the number
and nesting depth of vacancy-only components are
unrestricted. If every other free group has an
ordinary-endport spanning route, the parent has a
Hamilton cycle through both site edges and its legal
expanded child is Hamiltonian. Reflection gives the
case with two consecutive ports followed by their
nested right-side vacancy components.

**Proof.** Noncrossing places \(\mathcal I\) entirely
between the last vacancy \(V_{i_p}\) and the port
\(P_{s+1}\) of \(\mathcal O\). Put
\[
 F=B_{i_p+1},\ldots,B_{s+1}.                      \tag{3}
\]
This is the proper block gap after \(V_{i_p}\) in
the reflected prime construction for \(\mathcal O\).
The inner component's span
\(B_{j_1},\ldots,B_{s+1}\) lies in \(F\), and its
target block \(B_{s+1}\) is short.

Apply the reflected *local* construction of Note 282
to \(\mathcal I\). Its port \(P_s\) is the last atom;
every gap between its atoms contains only closed
vacancy-only parts, and its short target is inside
\(F\). The construction gives \(S,K,X\) on its
block span. Serial short blocks and any serial
vacancy-only parts from \(B_{i_p+1}\) to
\(B_{j_1-1}\) attach across retained ordinary
links, so \(F\) has \(S(F),K(F),X(F)\).
These routes end at \(e_{s+1},b_{s+1}\) and use no
edge leaving \(F\); in particular, they do not
require the absent exterior link \(P_{s+1}\).

Now apply the reflected local construction of Note 282
to the outer component \(\mathcal O\). Its port
\(P_{s+1}\) is last, its target \(B_{s+2}\) is
short, and its final proper gap is exactly \(F\).
Every earlier proper gap has only vacancy-only parts
and hence \(S,K,X\) by Note 275. The formulas of
Note 282 use a gap only through these three states
and the retained links at its ends. Thus substituting
the routes of \(F\) gives \(S,K,X\) for
\(B_{i_1},\ldots,B_{s+2}\). Each substituted gap
state spans \(F\), including the shared short block
\(B_{s+1}\), exactly once. The outer formulas meet
\(F\) only at its four ports, so no vertex is
visited twice.

Any remaining vacancy-only component is in an
earlier outer gap, is serially disjoint, or surrounds
the combined span in a proper block gap. Note 275's
prime recursion and serial composition give (2).
Note 273 joins groups; Notes 001 and 178 give the
marked cycle, legal child, and original lobe lengths.
\(\square\)

Every \(p,q\ge1\) occurs in an analytic Barnette
family. Use the site blocks and residual square of
Note 281(8), set \(s=p+q+1\), \(r=s+2\), make
\(B_1,\ldots,B_p\) and
\(B_{p+1},\ldots,B_{s-1}\) vacant, and make
\(B_s,B_{s+1},B_{s+2}\) short. Keep every standard
free link except \(P_s,P_{s+1}\), and add
\[
\begin{gathered}
H_1o_{s+2},\qquad
I_jH_{j+1}\ (1\le j<p),\qquad
I_pe_{s+1},\\
H_{p+1}o_{s+1},\qquad
I_jH_{j+1}\ (p+1\le j<s-1),\qquad
I_{s-1}e_s .
\end{gathered}                                          \tag{4}
\]
The first row is \(\mathcal O\)'s rainbow
matching, and the second is \(\mathcal I\)'s.
Together with the retained links and Note 281's
unchanged site, face, escape, and residual-square
edges, they pair every free slot exactly once.
All edges join opposite old-cycle colours.
In the disk opposite the site face,
\(H_1o_{s+2}\) encloses \(I_pe_{s+1}\);
the latter encloses the inner component's chords.
The other chords and retained standard links occupy
disjoint or nested intervals. Thus the graph is plane
with cofacial site edges.

The matching-chord interlacement graph is connected.
Retained links join the face chords through \(B_s\);
\(I_pe_{s+1}\) attaches the face chord of
\(B_{s+1}\), and \(H_1o_{s+2}\) attaches that of
\(B_{s+2}\). Every other edge of (4) interlaces
an endpoint face chord, while retained end links
attach the unchanged site and residual-square
closing chain. Notes 217 and 182 then give
three-vertex-connectivity. The parent has
\(6(p+q)+24\) vertices and the legal Hamiltonian
child \(6(p+q)+28\).

The theorem settles the nested same-side pair of
consecutive end ports with short target blocks.
A vacant shared block, other relative port
positions, and three or more missing links
remain outside its scope.
