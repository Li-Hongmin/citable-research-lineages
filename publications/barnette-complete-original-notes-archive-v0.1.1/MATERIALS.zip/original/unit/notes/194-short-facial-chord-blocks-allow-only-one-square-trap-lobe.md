> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short facial-chord blocks force a Hamiltonian child

[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
uses a slot-colour balance when two extra main vertices
are placed in different gaps. The same balance works
for arbitrarily long gaps if every site and opposite-face
matching chord spans exactly three edges of the old
Hamilton cycle. Multiple square-trap lobes then cannot
occur.

Use the legal Barnette parent and the one-square-per-lobe
all-square opening of Notes 176--179. The parent Hamilton
cycle \(C\) avoids the cofacial matching site edges
\(q=xy,p=uv\), and \(S_0\) runs from \(x\) to \(v\)
through \(y,u\). Let \(a_i b_i\), \(1\le i\le r\),
be the \(r\ge1\) matching edges on the other
\(y\)-to-\(u\) site-face arc in increasing \(C\)-order.
Keep the block and gap notation (3)--(4) of Note 193.

**Short-block theorem.** Suppose every one of
\(xy,a_1b_1,\ldots,a_rb_r,uv\) has \(C\)-distance
exactly three along \(S_0\). The gaps between these
blocks may contain arbitrarily many vertices. Then
the chosen all-square facial opening has exactly one
square-trap lobe, and the site-expanded child has a
Hamilton cycle. Equivalently, an all-square opening
with \(r\ge1\) and at least two lobes has a site or
opposite-face matching chord of \(C\)-distance at least five.

**Proof.** Each of the \(r+2\) blocks has exactly
two interior vertices, consecutive on \(C\). Call
these vertices and all gap vertices *slots*. Every
slot not used as an escape target is matched to
another slot. None of these slot matching edges
lies on the common-face side of \(C\). An edge
between slots in different blocks or gaps lies
opposite that face by the cross-atom observation
of Note 193: a block-interior endpoint would
interlace its closing matching chord, while an
edge between face-boundary gap vertices on that
side would split the designated common face.
The two slots inside one block cannot match each
other because they are adjacent on \(C\).
An edge between two slots of the same gap on
the common-face side would likewise split the
face or become an additional matching edge of
its boundary, contrary to the complete list
\(a_i b_i\). Thus every free-slot chord is
opposite the common face and cannot straddle
an escape target without crossing that target's
escape edge.

Colour a slot \(O\) or \(E\) according to whether
its \(S_0\)-index from \(x\) is odd or even.
Starting before the first slot of \((x,y)\), let
\(H=\#E-\#O\) over the slots passed so far.
The first block has slot colours \(O,E\);
therefore \(H\) goes \(0,-1,0\).
At the start of any later atom, \(H\) is either
zero or one. If it is zero, the next block has
slot colours \(O,E\) and returns \(H\) to zero;
the next gap alternates \(E,O,\ldots\), keeping
\(H\) between zero and one. If \(H\) is one,
the next block has \(E,O\) and returns \(H\)
to one; the next gap alternates \(O,E,\ldots\),
again keeping \(H\) between zero and one.
An odd-length gap switches the state, while
an even-length gap retains it.

Consequently the only odd slots preceded by
\(H=0\) are first slots of \(O,E\) blocks.
The only even slots preceded by \(H=-1\) are
second slots of \(O,E\) blocks. No gap slot
has either property.

Let \(R_\ell\) be the first escape target on
\(S_0\); it has odd index. All slots before
it are free and must match among themselves,
since an opposite-side chord cannot straddle
the escape edge at \(R_\ell\). Their two
colours balance, so \(H=0\) immediately
before \(R_\ell\). Thus \(R_\ell\) is the
first slot of an \(O,E\) block. If this
were not the initial \((x,y)\) block,
the main \(C\)-prefix ending just before
that block would be closed under \(M\):
all earlier slots match internally, and
all earlier site or face matching chords
are complete. Its two departing \(C\)-edges
would contradict three-edge-connectivity.
Therefore \(R_\ell\) is the first slot of
\((x,y)\).

The next target \(L_\ell\) has even index.
All slots strictly between \(R_\ell\) and
\(L_\ell\) must again match internally, so
they have zero net colour imbalance.
Because \(R_\ell\) contributes one \(O\),
we have \(H=-1\) immediately before
\(L_\ell\). It is therefore the second
slot of an \(O,E\) block, hence the last
slot of that block. If \(\ell\ge2\),
this contradicts Note 193's prefix-cut
rule for the nonfinal escape pair.
Thus \(\ell=1\).

We also force \(L_1\) to be the second slot of
the final block \((u,v)\). If it were the second
slot of \((x,y)\) or some \((a_i,b_i)\), take the
main prefix through that block and add the sole
residual square \(S_1\). There is no later escape
target. All slot chords leaving the prefix would
straddle \(L_1\) on the opposite side, while all
known site and face chords in the prefix are
complete. Exactly two \(C\)-edges would leave
this proper vertex set, contrary to
three-edge-connectivity. No gap slot can be
\(L_1\) by the colour walk. Hence \(R_1\) is
immediately after \(x\) and \(L_1\) immediately
before \(v\) on \(S_0\).

In the compressed child, let the sole residual
square have \(C\)-order
\(\alpha,\gamma,\delta,\beta\), with escape edge
\(\gamma L_1\). The edge \(v\alpha\) was cut by
the facial opening, whereas \(\alpha\gamma\)
and \(L_1v\) belong to its opened 2-factor.
Consequently
\[
v,\alpha,\gamma,L_1,v
\tag{1}
\]
is an alternating square with one factor edge
in each of the two components. Flipping (1)
merges them into a Hamilton cycle, exactly as
in Note 177's one-lobe criterion. Note 178
transfers this Hamilton cycle through any
original longer lobe ladder. \(\square\)

For the four-lobe question, the theorem excludes
every proposed \(f=4r\) configuration whose entire
four-vertex spacing surplus lies in gaps. Any such
configuration must lengthen at least one site or
opposite-face chord block. The theorem alone does
not decide the remaining four-lobe configurations
or Hamiltonicity with a longer block.
[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
subsequently excludes every four-lobe \(f=4r\) configuration,
including those with longer blocks.
