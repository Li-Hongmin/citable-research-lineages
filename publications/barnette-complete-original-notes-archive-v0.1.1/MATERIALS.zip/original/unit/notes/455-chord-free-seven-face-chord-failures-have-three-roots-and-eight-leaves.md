> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Chord-free seven-face-chord failures have three roots and eight leaves

[Note 415](415-escape-confinement-shaves-six-vertices-from-the-single-hexagon-kernel.md) bounds a doubly ladder-reduced, chord-free single-hexagon opening with \(f=7\) by \(c\le34\) ordinary chords and child order at most 100. The alternating parity of the four escape targets eliminates the one-root boundary; the adjacent-escape merger eliminates the two-root boundary.

Use the notation of Notes 410 and 415. The trapped hexagon has four escape edges, so \(e=4\), and their main targets in order meet \(d,c,b,a\). Let \(m=u/2\le8\) be the number of pairs of assignable special positions inside ordinary-chord intervals, let \(R\) be the number of ordinary roots, and let \(c\) be the ordinary-chord count after both ladder reductions. The reduced expanded child has
\[
                         |V(\bar G^+)|=32+2c.
\tag{1}
\]

**Three-root theorem.** If the legal expanded child is non-Hamiltonian, then \(m=8\), \(R=3\), and \(c\in\{30,31\}\). All sixteen assignable special positions lie two per leaf in an eight-leaf ordinary forest with five binary branches. At \(c=31\) every leaf has two ordinary wrappers and every branch three; at \(c=30\) exactly one leaf or branch has one fewer wrapper. The four escape targets occur one per gap around the three even-length root words:
\[
                 w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*.
\tag{2}
\]
Consequently the reduced child has 92 or 94 vertices. These are necessary conditions, not a claim that either order contains a non-Hamiltonian graph.

**Proof.** The published Brinkmann--Goedgebeur--McKay 90-vertex theorem, used in [Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md), and (1) give \(c\ge30\) under the failure hypothesis. Note 415 (3) gives
\[
                              c\le5m-3R.
\tag{3}
\]
Thus \(m\ge7\). If \(m=7\), then \(R\ge2\) would give \(c\le29\); hence \(R=1\). Exactly two of the sixteen assignable special positions then lie outside the unique root word. Every other main vertex outside that root, apart from \(w_0,w_*\), is an escape target. Split the four targets between the two flanks of the root. In either flank, two consecutive targets in target order with no intervening special position are adjacent old-cycle vertices, and the adjacent-escape merger of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) makes the child Hamiltonian. If exactly one special position separates them, their old-cycle indices have the same parity, but their adjacent trapped neighbours among \(d,c,b,a\) have opposite parity; one escape edge violates bipartiteness. Hence every gap between consecutive targets in one flank needs at least two of the outside special positions. Four targets in at most two flanks create at least two such gaps, requiring at least four special positions. Only two exist. This excludes \(m=7\).

Now \(m=8\), so every assignable special position lies inside an ordinary root. The only internal main vertices outside the roots are four escape targets. If \(R\le2\), the \(R+1\le3\) gaps around the roots contain four targets, and two targets are consecutive in one gap; the adjacent-escape merger again makes the child Hamiltonian. If \(R\ge4\), (3) gives \(c\le28\), contradicting \(c\ge30\). Therefore \(R=3\). To avoid consecutive targets, each of its four gaps contains exactly one, proving (2). Equation (3) now gives \(c\le31\).

Let \(M_0,L,A,Q\) count marked nodes, leaves, marked-or-branching nodes, and leaves receiving exactly two special positions, as in [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md). The sharper inequality in Note 415 is
\[
                 c\le2(M_0+L)+m-3R=2(M_0+L)-1.
\]
Since \(c\ge30\) and \(L\le M_0\le m=8\), this forces \(M_0=L=8\). Thus all sixteen special positions occur at the eight leaves, two per leaf, and the three-root full binary forest has \(L-R=5\) branching nodes. Each reduced leaf can have at most two ordinary wrappers and each branch at most three, by the two ladder reductions of Note 410. Their total maximum is \(8\cdot2+5\cdot3=31\). Therefore \(c=31\) means every node is full, while \(c=30\) means precisely one node is short by one wrapper. Finally (1) gives 94 or 92 vertices. \(\square\)

The three-root exterior routing and its leaf-switch closure are proved in [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Thus the necessary form above does not contain a non-Hamiltonian legal child.
