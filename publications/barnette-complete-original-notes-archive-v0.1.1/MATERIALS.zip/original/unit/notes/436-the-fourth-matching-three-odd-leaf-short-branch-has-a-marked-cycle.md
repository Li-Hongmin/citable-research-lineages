> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The fourth matching's three-odd-leaf short branch has a marked cycle

[Note 435](435-the-fourth-matching-three-odd-leaf-short-branches-reduce-to-one-word.md) leaves one necessary ordinary word for a hypothetical non-Hamiltonian row-IV child with three odd-depth leaves and a short branch. This note gives that word a spanning marked path. Together with [Notes 433--434](434-the-fourth-face-matching-six-odd-leaf-word-has-a-marked-cycle.md), it excludes every short-branch word in row IV and, by reflection, row V. The conclusion is conditional on the kernel hypotheses of [Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md).

Keep the word and face matching of Note 435:
\[
\begin{aligned}
A&=F(U_3,U_4),& B&=F(U_5,U_6),& V&=F_0(B,U_7),\\
D&=F(A,V),& E&=F(U_2,D),& W&=F(U_1,E),
\end{aligned}                                                    \tag{1}
\]
where \(F(P,Q)=(((P Q)))\), \(F_0(P,Q)=((P Q))\), and each \(U_i=((x_i y_i))\). The sites are \(y_1,x_7\). The row-IV face chords used below are \(y_2x_3,x_4y_5,y_4x_5\).

Use the leaf paths \(Y_i,X_i\) and full-branch bracket paths \(P_T,Q_T,R_T\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md), equations (1)--(2). As in [Note 434](434-the-fourth-face-matching-six-odd-leaf-word-has-a-marked-cycle.md), split \(A\) into disjoint paths
\[
P_A=(x_3\xrightarrow{X_3^{-1}}R_3,L_4,h_4,x_4),\qquad
Q_A=(y_4,j_4,R_4,\rho_2^A\xrightarrow{R_A}\lambda_0^A=A_\ell).
\tag{2}
\]
The first uses all of \(U_3\) and the first three vertices of \(U_4\); the second uses the last three vertices of \(U_4\) and all six \(A\)-brackets. The joins \(R_3L_4\) and \(R_4\rho_2^A\) are old-cycle edges.

Delete the old edge \(x_5y_5\) from the Hamilton cycle formed by the full old-cycle path through \(B\) and its outer ordinary chord \(B_\ell B_r\). Read the resulting spanning path as
\[
Z_B=(y_5\xrightarrow{\mathrm{old}}B_r,
      B_\ell\xrightarrow{\mathrm{old}}x_5).
\tag{3}
\]
The implied join \(B_rB_\ell\) is the ordinary chord. Thus the two face chords \(x_4y_5\) and \(x_5y_4\) concatenate (2)--(3) into a spanning path of \(A\cup B\):
\[
T_{AB}=(x_3\xrightarrow{P_A}x_4,
          y_5\xrightarrow{Z_B}x_5,
          y_4\xrightarrow{Q_A}A_\ell).
\tag{4}
\]
The construction of (3)--(4) does not use the internal tree of \(B\). More generally, let \(B\) be any disjoint consecutive ordinary word whose first and last vertices have an ordinary matching chord and which contains the old-cycle edge \(x_5y_5\). Deleting that edge from the cycle consisting of \(B\)'s old-cycle interval and its outer chord still gives \(Z_B\). Hence the two face chords \(x_4y_5,y_4x_5\) give a spanning \(x_3\)--\(A_\ell\) path of \(A\cup B\) for arbitrary such \(B\). This crossed-block absorption lemma needs no Hamilton property of \(B\) beyond its visible outer chord.

**Marked-path theorem.** The following is a spanning \(y_1\)--\(x_7\) path of the 76-vertex word \(W\):
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
\rho_0^E\xrightarrow{Q_E}\lambda_2^E,
L_2\xrightarrow{Y_2^{-1}}y_2,\\
&x_3\xrightarrow{T_{AB}}A_\ell,
\lambda_2^D\xrightarrow{P_D}\rho_2^D,
\rho_0^V,\lambda_0^V,\lambda_1^V,\rho_1^V,
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{5}
\]
Here \(y_2x_3\) is the third used face chord. The joins \(L_1\lambda_2^W\), \(\rho_2^W\rho_0^E\), \(\lambda_2^EL_2\), \(A_\ell\lambda_2^D\), \(\rho_2^D\rho_0^V\), and \(\rho_1^VR_7\) are consecutive old-cycle edges. Within \(V\), \(\rho_0^V\lambda_0^V\) and \(\lambda_1^V\rho_1^V\) are its two ordinary chords, while \(\lambda_0^V\lambda_1^V\) is an old-cycle edge.

The pieces in (5) partition the vertices: seven full leaves contribute \(42\), the five full branches \(W,E,D,A,B\) contribute \(30\), and the short branch \(V\) contributes \(4\). Equation (4) uses all vertices of \(A\) and \(B\); the other displayed pieces use each remaining leaf and wrapper once. Hence (5) has \(42+30+4=76\) distinct vertices and every step is an edge.

In any legal completion of (1), adjoin the two site edges and the fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), with sites \(y_1,x_7\). This gives a parent Hamilton cycle containing both expansion edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, lifts it to a Hamilton cycle in the child. Note 435 exhausts the three-odd-leaf short branches; Notes 433--434 handle the other possible odd-depth spectra. Therefore a hypothetical non-Hamiltonian legal row-IV/V child in this two-eligible \(f=7,c=31\) kernel must have its unique short node at an odd-depth leaf. This does not decide those short-leaf words, row VI, or Barnette's conjecture. \(\square\)
