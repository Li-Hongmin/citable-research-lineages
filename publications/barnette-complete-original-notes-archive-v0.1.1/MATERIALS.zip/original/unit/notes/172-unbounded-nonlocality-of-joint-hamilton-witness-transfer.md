> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Unbounded nonlocality of joint Hamilton-witness transfer

This theorem promotes the analytic infinite-prism construction in the
[September 26 candidate](../advisor/gpt6pro-2026-09-26-nonlocal-joint-transfer.md).
The proof below uses no finite census. A joint witness means a single
Hamilton cycle containing a required edge and avoiding a forbidden edge.

**Theorem.** For every integer \(r\geq2\), there is a legal Barnette
\(C_4\)-expansion \(G_r\to H_r\), with both graphs admitting complete
histories from the cube in the frozen certificate class, and surviving old
edges \(e_r,f_r\), such that:

* \(G_r\) has the global \(H^{+-}\) property: for every ordered pair of
  distinct edges, one Hamilton cycle contains the first and avoids the
  second;
* exactly one Hamilton cycle \(C_r\) of \(G_r\) contains \(e_r\) and
  avoids \(f_r\), and it avoids both expanded edges;
* \(H_r\) has a Hamilton cycle containing \(e_r\) and avoiding \(f_r\);
  one such cycle is obtained from \(C_r\dot\cup Q\) by a single
  alternating-cycle flip of length \(4r\);
* every Hamilton cycle \(D\) of \(H_r\), whether or not it satisfies the
  marks, changes at least \(2r-1\) surviving old edges relative to
  \(C_r\). One changed old edge has both endpoints at distance at least
  \(r-1\) from the expansion ports in \(G_r\).

In particular, no constant number of old-edge edits and no constant
radius about the site can transfer a parent joint witness for all legal
expansions, even if the parent is globally \(H^{+-}\) and the child joint
witness exists. The assertion concerns bounded local transfer, not the
truth of the global \(H^{+-}\) property or Barnette's conjecture.

## Construction and legal history

Set \(m=4r\) and \(G_r=C_m\square K_2\). Its vertices are \(T_i,B_i\),
with indices modulo \(m\), and its edges are
\(T_iT_{i+1},B_iB_{i+1},T_iB_i\). In the face bounded by the top rim,
expand the ordered site
\[
(u,v,x,y)=(T_1,T_2,T_{2r+1},T_{2r+2}),
\qquad p=T_1T_2,\quad q=T_{2r+1}T_{2r+2}.
\tag{1}
\]
Delete \(p,q\), add \(a,b,c,d\), and add precisely
\[
ua,ab,bv,xc,cd,dy,ad,bc.
\tag{2}
\]
Call the result \(H_r\), and put
\[
e_r=T_0B_0,\quad f_r=T_3T_4,\quad
M_r=\{T_iT_{i+1}:i\text{ odd}\}
       \cup\{B_iB_{i+1}:i\text{ even}\},
\quad C_r=E(G_r)\setminus M_r.
\tag{3}
\]
The complement in (3) is a zigzag Hamilton cycle.

For completeness, start from the cube viewed as the four-column prism.
On the side square of a \(k\)-column prism expand
\((T_{k-1},T_0,B_0,B_{k-1})\). The new top columns are \(a,b\), the new
bottom columns are \(d,c\), and \(ad,bc\) are their rungs. Thus the result
is the \((k+2)\)-column prism. Repeating this \(2r-2\) times produces
\(G_r\). The final site (1) is cofacial, its two residual top-rim arcs
both have length \(2r-1\), and \(u,x\) have the same bipartition colour.
The square \((b,c,d,a)\) is a legal terminal site in \(H_r\).

Every intermediate prism is simple, cubic, bipartite, planar and
3-connected: after deleting two vertices in one rim the other rim and
the remaining rungs connect every surviving segment; after deleting one
vertex from each rim, both remaining rims are paths joined by surviving
rungs. For the final expansion, the graph remains connected after
deleting at most two vertices. If none is new, connectivity follows by
replacing the two seal edges in the connected \(G_r-W\) by the patch and
attaching its remaining vertices to the surviving ports. If exactly one
new vertex is deleted, the remaining three form a path; they simulate one
seal and attach to the connected \(G_r-w\) with the other seal deleted.
The latter is connected because \(G_r-w\) is 2-connected. If two new
vertices are deleted, \(G_r-p-q\) is connected via the bottom rim and
rungs, and each remaining patch component meets an old port. Thus every
step is legal. Reversing the recorded steps restores the two seals and
the preceding embedded prism. The edge ledger is the kernel/birth-layer/
terminal-cap assignment prescribed in the frozen SPEC.

## All Hamilton cycles of an even prism

The Hamilton cycles of \(C_m\square K_2\) are exactly the \(m\) cycles
\[
K_i=\bigl(E(T\text{-rim})\cup E(B\text{-rim})\bigr)
 \setminus\{T_iT_{i+1},B_iB_{i+1}\}
 \cup\{T_iB_i,T_{i+1}B_{i+1}\}
\tag{4}
\]
and two zigzag cycles with complementary alternating horizontal phases.
Indeed, take the complementary perfect matching. With no rung in it,
the two rims each have one of two alternating matchings: equal phases
leave several square components, and opposite phases give the two
zigzags. With a rung present, every maximal interval of columns not
matched by rungs is a path in each rim; its perfect matching, when it
exists, is unique. The two rim paths have the same endpoints, so their
horizontal matching edges occur at identical columns. No horizontal
pair leaves the two rim cycles. If there are at least two pairs, each
interval between successive omitted horizontal pairs closes separately
through the complementary rungs and gives a distinct cycle. Exactly one
pair gives (4). This proves that the list is exhaustive.

The list gives global \(H^{+-}\). For two horizontal edges in different
columns, take \(K_i\) with its gap at the forbidden column. For horizontal
edges in the same column but opposite rims, choose the zigzag that uses
the required one. For a required rung and forbidden horizontal edge,
choose the zigzag avoiding the horizontal edge. For a required rung at
column \(i\) and forbidden rung at \(j\ne i\), one of \(K_{i-1},K_i\)
avoids the forbidden rung. For a required horizontal edge in column
\(i\) and forbidden rung in column \(j\), choose
\(K_k\) with \(k\notin\{i,j-1,j\}\); such a \(k\) exists since
\(m\ge8\).

Only \(K_0,K_{m-1}\) contain the rung \(e_r\), and both contain
\(f_r\). Both zigzags contain \(e_r\), but exactly the zigzag \(C_r\)
from (3) avoids \(f_r\). Hence
\[
\{C\in\mathcal H(G_r):e_r\in C,\ f_r\notin C\}=\{C_r\}.
\tag{5}
\]
Both \(p\) and \(q\) have odd top-rim index, so they belong to
\(M_r\) and are avoided by \(C_r\).

## A child joint witness and the distance bound

A Hamilton cycle in \(H_r\) is obtained by writing the following vertex
list cyclically:
\[
\begin{gathered}
T_2,T_3,B_3,B_2,B_1,T_1,T_0,B_0,\\
(B_j,T_j,T_{j-1},B_{j-1})
\quad(j=m-1,m-3,\ldots,2r+3),\\
B_{2r+1},B_{2r},\ldots,B_4,
T_4,T_5,\ldots,T_{2r+1},c,d,a,b.
\end{gathered}
\tag{6}
\]
Each vertex occurs exactly once, consecutive vertices are adjacent,
and the final \(b\) is adjacent to the initial \(T_2=v\). The list
uses \(e_r\) and avoids \(f_r\). Its patch segment
\(x-c-d-a-b-v\) is the \(X_{vx}\) traversal of the exact six-state
criterion in [Note 006](006-theorem-level-corrections-and-positive-depth-support-theorem.md).

Now let \(D\) be *any* Hamilton cycle of \(H_r\), with complementary
matching \(N\), and write
\[
E_0=E(G_r)\setminus\{p,q\},\qquad
M'=M_r\setminus\{p,q\},\qquad N'=N\cap E_0.
\tag{7}
\]
The number of spokes in \(N\) is even. It cannot be four, since then
\(D\) leaves the patch square as a separate cycle. Thus it is zero or
two. Every nonport old vertex is matched by both \(M'\) and \(N'\),
all four ports are exposed by \(M'\), and at least two ports are covered
by \(N'\). Consequently \(M'\triangle N'\) contains an alternating
path between two ports, beginning and ending with an \(N'\) edge.

Let
\[
X=\{T_i:i\text{ even}\}\cup\{B_i:i\text{ odd}\},
\qquad Y=V(G_r)\setminus X.
\]
Orient \(M_r\) edges from \(Y\) to \(X\), all other old edges from
\(X\) to \(Y\). Every horizontal edge on either rim is then directed
in increasing column order; a rung does not change the column. The
alternating path starts at an \(X\)-port \(T_2\) or \(T_{2r+2}\) and
ends at a \(Y\)-port \(T_1\) or \(T_{2r+1}\). Its four possible positive
column displacements are \(4r-1,2r-1,2r-1,4r-1\), respectively. Hence
\[
|M'\triangle N'|\ge2r-1.
\tag{8}
\]
Because symmetric difference is unchanged by complementing both
edge sets within \(E_0\), the left side equals
\[
\bigl|(E(D)\cap E_0)\triangle E(C_r)\bigr|.
\tag{9}
\]

If the path starts at \(T_2\), it crosses a horizontal edge between
columns \(r+1,r+2\). If it starts at \(T_{2r+2}\), it crosses one between
columns \(3r+1,3r+2\). Both endpoints of either edge have cyclic column
distance at least \(r-1\) from all four port columns
\(\{1,2,2r+1,2r+2\}\). Graph distance cannot be smaller than cyclic
column distance. This gives the distance assertion and proves the theorem.

## The child witness is one long alternating opening

The cycle in (6) has a stronger construction relative to the original
Hamilton cycle \(C_r\). Define the old-vertex path
\[
\begin{split}
P_r={}&T_{2r+1},B_{2r+1},\\
& (B_{2j},T_{2j},T_{2j-1},B_{2j-1})
   \quad(j=r,r-1,\ldots,3),\\
& B_4,B_3,B_2,T_2.
\end{split}
\tag{10}
\]
The parenthesized blocks are omitted when \(r=2\). Consecutive
vertices are adjacent, and its edges alternate between \(C_r\) and
\(M_r\), beginning and ending with a \(C_r\)-edge. More explicitly,
\[
\begin{aligned}
E(P_r)\cap M_r
={}&\{B_{2j}B_{2j+1}:1\leq j\leq r\}
 \cup\{T_{2j+1}T_{2j+2}:2\leq j\leq r-1\},\\
E(P_r)\cap C_r
={}&\{T_2B_2,B_3B_4\}
 \cup\{T_iB_i:5\leq i\leq2r+1\}.
\end{aligned}
\tag{11}
\]
Thus \(|E(P_r)|=4r-3\). It runs from \(x=T_{2r+1}\) to
\(v=T_2\), avoids \(e_r=T_0B_0\) and \(f_r=T_3T_4\), and uses
neither site edge.

Let \(M_0\) be the child matching obtained from \(M_r\) by replacing
\(p,q\) with all four spokes, as in
[Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md).
Then
\[
 A_r=bv\ \cup\ P_r\ \cup\ xc\ \cup\ bc
\tag{12}
\]
is one simple \(M_0\)-alternating cycle of length \(4r\), using
\(bc\) as its only square edge. Its flip changes the patch square
into the path \(x-c-d-a-b-v\). On the old vertices it changes
exactly the edges in (11), and the resulting 2-factor is precisely
the cyclic vertex list (6); hence it is Hamiltonian. Equivalently,
the quotient \(K(P_r)\) of Note 174 is a tree. This proves that the
all-order nonlocality bound above already occurs for one alternating
exchange, while a suitable nonlocal tree connector still exists.

For \(r\geq3\), compare the more direct marked connector
\[
P_r^{\mathrm{dir}}=
T_{2r+1},T_{2r},T_{2r-1},\ldots,T_5,
B_5,B_4,B_3,B_2,T_2.
\tag{13}
\]
It has \(2r+1\) edges, alternating between \(C_r\) and \(M_r\),
beginning and ending in \(C_r\). It avoids \(e_r,f_r,p,q\), so the
same closure through \(bv,bc,xc\) gives a valid jointly marked square
opening. Its complementary 2-factor is **not** Hamiltonian. It has the
residual cycle
\[
T_4,T_5,T_6,B_6,B_5,B_4,T_4
\tag{14}
\]
and, for each \(4\leq j\leq r\), the residual square
\[
T_{2j-1},T_{2j},B_{2j},B_{2j-1},T_{2j-1}.
\tag{15}
\]
These are \(r-2\) disjoint cycles. All remaining old vertices form
the single \(v\)-to-\(x\) path
\[
\begin{gathered}
T_2,T_3,B_3,B_2,B_1,T_1,T_0,B_0,\\
(B_j,T_j,T_{j-1},B_{j-1})
\quad(j=m-1,m-3,\ldots,2r+3),\\
B_{2r+1},T_{2r+1}.
\end{gathered}
\tag{16}
\]
Equations (14)--(16) list every vertex once and every complementary
edge after the flip, proving that \(K(P_r^{\mathrm{dir}})\) has exactly
\(r-1\) components, whereas \(K(P_r)\) is a tree. Thus marked
alternating reachability can leave arbitrarily many residual cycles in
the same family where choosing one longer single-cycle exchange avoids them.
The tree connector uses exactly \(2(r-2)\) more old edges than the
direct connector.

In fact, every intermediate cycle deficit occurs along a monotone
sequence of jointly marked openings. For \(r\geq3\) and
\(0\leq s\leq r-2\), put
\(k=r-s\) and form \(P_{r,s}\) as follows. Start at \(T_{2r+1}\);
for \(j=r,r-1,\ldots,k+1\), append the four vertices
\[
B_{2j+1},B_{2j},T_{2j},T_{2j-1};
\]
then append \(T_{2k},T_{2k-1},\ldots,T_5\) if \(k\geq3\), and finally
append \(B_5,B_4,B_3,B_2,T_2\). The first loop is empty for \(s=0\).
Thus \(P_{r,0}=P_r^{\mathrm{dir}}\), \(P_{r,r-2}=P_r\), and
\[
|E(P_{r,s})|=2r+1+2s.
\tag{17}
\]
Each path is simple, alternating, and avoids \(e_r,f_r,p,q\).
Let \(F_s\) be the complementary 2-factor after closing this path
through \(bv,bc,xc\) and flipping. Then
\[
c(F_s)=r-1-s,
\qquad c(K(P_{r,s}))=r-1-s.
\tag{18}
\]
More precisely, when \(k\geq3\), the unmerged old cycles are (14)
and the squares (15) with \(4\leq j\leq k\); when \(k=2\), none
remain. For \(s=0\), this is (14)--(16). To pass from \(s\) to \(s+1\),
set \(j=r-s\). The new path replaces
\(T_{2j+1},T_{2j},T_{2j-1}\) by
\(T_{2j+1},B_{2j+1},B_{2j},T_{2j},T_{2j-1}\).
The two resulting 2-factors differ exactly on the side-face square
\[
T_{2j+1},T_{2j},B_{2j},B_{2j+1},T_{2j+1}.
\tag{19}
\]
This square is alternating for the matching complementary to \(F_s\).
Its two \(F_s\)-edges lie in different components: the edge at column
\(2j\) belongs to the unmerged residual square (15) when \(j\geq4\),
or to the residual hexagon (14) when \(j=3\); the edge at column
\(2j+1\) belongs to the main component, which already absorbed the
cycles at all larger indices. Flipping (19) therefore joins precisely
these two components and leaves the others unchanged. This proves
(18) by induction, including the final Hamilton cycle at \(s=r-2\).
The construction gives an explicit one-cycle-at-a-time repair in this
prism family; no such repair is asserted for arbitrary Barnette graphs.

## Limit of the conclusion

The child witness (6) shows that arbitrarily long old-edge changes can
coexist with successful joint Hamiltonicity. For any proposed real-valued
radius \(R\), choose an integer \(r>R+1\). The theorem excludes a
uniformly local transfer rule; it supplies neither a Barnette
counterexample nor a proof of global \(H^{+-}\) preservation.
