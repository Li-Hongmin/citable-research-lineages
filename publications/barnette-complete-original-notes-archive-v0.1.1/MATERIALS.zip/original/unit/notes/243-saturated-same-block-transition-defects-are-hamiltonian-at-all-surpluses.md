> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Saturated same-block transition defects are Hamiltonian at every surplus

[Note 237](237-disjoint-tight-budget-target-defects-compose-at-all-surpluses.md)
composes separated defects at every gapless surplus, while
[Note 242](242-all-double-transition-defects-at-second-surplus-are-hamiltonian.md)
settles two overlapping same-block transition defects at \(s=2\).
Their old-cycle detour extends to any number of same-block defects,
possibly distributed among several blocks. No classification of the
matching *within* each closed special group is needed for the
Hamilton route.

Use a compressed all-square Barnette opening with \(\ell,r\ge1\),
empty interblock gaps and \(s\ge1\) vacant eligible positions, so
\(f=4r+2+2s\). Retain Note 197's target order
\(R_\ell,L_\ell,\ldots,R_1,L_1\).

**Same-block cluster theorem.** Assume
\[
d_L=d_R=0,\qquad b=s,                         \tag{1}
\]
and that the two targets of every defective transition
\(L_j,R_{j-1}\) lie in the same block. Then the parent has a
Hamilton cycle containing both site edges \(xy,uv\), and its legal
site-expanded child is Hamiltonian. The assertion holds for any
distribution of the defects among blocks and for arbitrary positive
original lobe lengths. In an actual parent, a block cannot contain
exactly one such defect; it contains either zero or at least two.

**Proof.** By Note 197, the \(s\) defects receive distinct vacant
eligible positions. Equality in (1) exhausts all vacancies. Thus
each defective transition has precisely the local old-cycle order
\[
L_j,c_j,d_j,R_{j-1},                            \tag{2}
\]
where \(c_j,d_j\) are consecutive free slots; all other consecutive
inter-lobe transitions are adjacent. In any block with defects,
its only other possible free interior slots are the first \(o_i\)
and final \(e_i\). The first is absent in \(B_0\), where \(R_\ell\)
is first, and the second is absent in \(B_{r+1}\), where \(L_1\)
is final.

Fix a block containing at least one defect. Before the source of
its first defective transition, the number of free main slots is
even: ordinary blocks contribute their usual two-slot balance,
and every earlier defect contributes two additional free slots.
At most \(o_i\) is free earlier in the current block.
Note 203 forbids any cross-block free chord straddling that source;
matching parity then forbids the single possible same-block
crossing chord. Symmetrically, the free-slot prefix before the
destination of the block's last defective transition is even,
and at most \(e_i\) is free later in the block. No free chord
crosses that destination. Therefore all the \(c_j,d_j\) pairs
belonging to this block form a matching-closed group. A single
defect would leave just \(c_j,d_j\), which cannot be matched
because \(c_jd_j\in E(C)\). This proves the nonexistence claim.

Every ordinary free slot lies outside these closed special groups.
An ordinary chord cannot cross a target run inside a defect block:
its endpoint there would be \(o_i\) or \(e_i\), so it would cross
the block's first or last defective target barrier. In a block
without defects, an even free prefix and at most one possible
same-block chord give the usual barrier. Cross-block chords
straddling any target are excluded by Note 203. The remaining
free matching therefore consists of the standard links
\[
e_i o_{i+1}\in M\qquad(0\le i\le r),           \tag{3}
\]
by Note 196's noncrossing and two-edge-cut skipping argument:
a link cannot skip a block with a target by Note 203, while
skipping target-free short blocks either forces an old-cycle
matching edge or closes a proper consecutive block interval.
This leaves Note 196's ordinary free \(x\)-to-\(v\) path unchanged.

Start with Note 196's target-and-square \(x\)-to-\(v\) path.
For every defective transition, replace the missing edge by
\[
L_jR_{j-1}\longmapsto L_j,c_j,d_j,R_{j-1}.     \tag{4}
\]
All three edges in (4) are consecutive edges of \(C\). The
replacement interiors are disjoint, cover every special free slot,
and meet neither the ordinary path nor the residual squares.
All other target transitions, the two endpoint links, and the
square passages are those of Note 196. The two paths share only
\(x,v\) and jointly span the parent, so their union is a Hamilton
cycle through \(xy,uv\). Notes 001 and 178 give the legal child
and restore longer lobes. \(\square\)

**An infinite realized family.** For every \(s\ge2\), let
\(r=1\), \(\ell=s+1\), and take an old cycle whose main blocks are
\[
\begin{split}
B_0&=(x,R_{s+1},e_0,y),\\
B_1&=(a,o,
L_{s+1},c_1,d_1,R_s,
L_s,c_2,d_2,R_{s-1},\ldots,
L_2,c_s,d_s,R_1,e,b),\\
B_2&=(u,o_R,L_1,v),
\end{split}                                                \tag{5}
\]
followed by the square lobes
\(S_t=(\alpha_t,\gamma_t,\delta_t,\beta_t)\),
\(1\le t\le s+1\), and then returning to \(x\).
The complementary matching contains \(xy,ab,uv\), all
\(\alpha_t\beta_t,R_t\delta_t,L_t\gamma_t\), and the two
ordinary links \(e_0o,eo_R\). Match the special slots as follows:

- If \(s\) is even, for \(t=1,3,\ldots,s-1\) use
  \(c_t d_{t+1},d_t c_{t+1}\).
- If \(s\) is odd, use \(c_1d_3,d_1c_2,d_2c_3\), then for
  \(t=4,6,\ldots,s-1\) use \(c_t d_{t+1},d_t c_{t+1}\).

These are opposite-colour non-cycle pairs. Within \(ab\) on the
site-face side they form nested pairs on disjoint consecutive
groups of two or three defects. Put the site and square chords
on that same side. On the other side, the escape chords nest in
target order, and \(e_0o,eo_R\) occupy disjoint gaps. The graph
is therefore simple, cubic, bipartite and plane with cofacial
sites. Its chord-interlacement graph is connected: the spine
\(xy-e_0o-ab-eo_R-uv\) meets the first and last escape
chords; every intermediate escape chord interlaces \(ab\),
and each \(\alpha_t\beta_t\) interlaces both escape chords
of its square. Every special matching chord spans a target
and hence interlaces that target's escape chord. Note 217's
interval criterion proves three-connectivity; its cut projection
gives a Barnette site-expanded child.

The parent has \(8s+16\) vertices and its child \(8s+20\).
The marked cycle from the theorem has ordinary path
\(x,y,e_0,o,a,b,e,o_R,u,v\) and target path
\[
\begin{split}
x,R_{s+1},\delta_{s+1},\beta_{s+1},\alpha_{s+1},
\gamma_{s+1},L_{s+1},c_1,d_1,R_s,
\delta_s,\beta_s,\alpha_s,\gamma_s,L_s,\\
c_2,d_2,R_{s-1},\ldots,L_2,c_s,d_s,R_1,
\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\end{split}                                                \tag{6}
\]
For \(s=2\), this is the vertex-by-vertex 32-vertex certificate
in Note 242. Thus the theorem applies at unbounded surplus.

The hypothesis that every defect is same-block is essential to
this proof. Cross-block defects mixed with these clusters, spare
vacancies, gap slots, nonsquare residual cycles, and arbitrary
Barnette graphs are not covered.
