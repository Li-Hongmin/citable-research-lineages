> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A two-path splice closes the six-double \(k_1i_2\) global return

[Note 358](358-six-alternating-double-blocks-reduce-to-one-global-first-return-branch.md)
leaves only the \(h_1j_6\) first return in the consecutive
forward six-double group. [Note 359](359-a-six-double-global-return-has-two-reflected-spanning-halves.md)
settles its \(k_1j_3\) branch. When \(k_1i_2\), either a
middle local square appears or the remaining four-block
interior has one of the two routes of Notes 345 and 347.
A two-path traversal of \(D_1D_2\) replaces the missing
outer chord of either four-block route.

Use the compressed, gapless, tight-target all-square opening,
six consecutive \(J_3,J_1,J_3,J_1,J_3,J_1\) double blocks
\(D_1,\ldots,D_6\), and ordinary endports \(L,R\) of
Note 358 (1). The common-face internal matching chords are
its prescribed \(J_3/J_1\) chords, with no short block
in this group.

**Six-block \(k_1i_2\) theorem.** Every actual matching
containing \(h_1j_6,k_1i_2\) gives a vertex-spanning
\(L\)--\(R\) path. Its chord \(j_1h_2\) is forced.
The mate of \(j_2\) is exactly one of
\[
                         h_3,\quad e_4,\quad h_5.        \tag{1}
\]
The \(e_4,h_5\) choices force Note 335's local
square on \(D_3D_4\). In the \(h_3\) choice,
\(e_2o_3\) is forced; the matching on the
remaining four-block interior is one of the two
nonlocal wirings of Notes 345 and 347. All three
choices have spanning routes. Under the usual
outside-vacancy hypothesis, the parent has a
Hamilton cycle through both site edges and its legal
child is Hamiltonian.

**Matching exhaustion.** The noncrossing and cut
rules are those in Note 358. Outside \(h_1j_6\),
\(Lo_1,e_6R\) are forced. Inside \(k_1i_2\),
the only two slots \(j_1,h_2\) force \(j_1h_2\).
Counting the unmatched slots after \(i_2\)
shows that \(j_2\) can meet only \(h_3,e_4,h_5\);
the other even candidates enclose odd numbers of
free slots or are old edges.

If \(j_2e_4\), its first inner even slot \(e_2\)
can meet \(o_3\) or \(j_4\). The second choice
leaves \(o_3\) without an interior mate:
\(o_3h_3\) is old, \(o_3k_3\) is excluded
by chord isolation, and \(o_3h_4\) encloses
three free slots. Hence \(e_2o_3\).
The remaining six inner slots then force
\(h_3j_4,k_3i_4,j_3h_4\), exactly the
local \(D_3D_4\) square of Note 335.

If \(j_2h_5\), the first inner slot \(e_2\)
can meet \(o_3,j_4,o_5\). The chord \(e_2o_5\)
would close the complete-block interval \(D_3D_4\);
\(e_2j_4\) again leaves \(o_3\) with no
interior mate. Thus \(e_2o_3\).
The next even slot \(h_3\) can meet \(j_4\)
or \(o_5\). The latter would force
\(k_3i_4,j_3h_4\) and leave the old
pair \(j_4e_4\). Therefore \(h_3j_4\),
again forcing the local \(D_3D_4\) square.
In either of these two branches, compressing
that patch leaves the forward four-double
group \(D_1,D_2,S,D_5,D_6\), with one
central short block \(S\). Note 357 gives
its spanning route and Note 335 lifts it.

If \(j_2h_3\), its two inner free slots force
\(e_2o_3\). The free slots strictly between
\(h_3,j_6\) must pair among themselves:
every earlier free slot is already matched,
and \(e_6,R\) are matched to each other.
Their possible matchings are precisely
the interior wirings of the \(h_3j_6\)
branch in Note 347's four-block
classification, after relabeling
\(D_1,\ldots,D_4\) there as
\(D_3,\ldots,D_6\) here. The resulting
two \(o_3\)--\(e_6\) paths \(W_A,W_B\)
are Note 345 (13) at \(m=2\) and
Note 347 (4), respectively. Each
contains the edge \(h_3j_6\), which
is absent from the present matching.
\(\square\)

**Two-path splice.** The first two double blocks
have these disjoint spanning paths:
\[
\begin{split}
A={}&(o_1,a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,e_2),\\
B={}&(j_2,k_2,i_2,k_1,i_1,h_1).                         \tag{2}
\end{split}
\]
The non-old joins in \(A,B\) are their
block-closing chords and \(j_1h_2,k_1i_2\);
all other joins are old-cycle edges.
Each of the sixteen vertices of \(D_1D_2\)
appears once. In either \(W=W_A\) or \(W_B\),
remove \(h_3j_6\). This cuts \(W\) into
an \(o_3\)--\(h_3\) path \(W^-\) and a
\(j_6\)--\(e_6\) path \(W^+\), which
together cover \(D_3,\ldots,D_6\).
Now concatenate
\[
        L,\ A,\ e_2o_3,\ W^-,\
        h_3j_2,\ B,\ h_1j_6,\ W^+,\ R.                  \tag{3}
\]
Here the edge labels indicate joins, so endpoints
are not repeated. The joins \(Lo_1,e_6R\)
complete the route. Equation (3) uses only
the present matching, old-cycle edges,
block-closing chords and internal chords,
and visits every group vertex once.
It composes with the other free groups as in
Note 357; Note 001 then supplies the legal
child's Hamilton cycle. \(\square\)

This theorem closes only the \(h_1j_6,k_1i_2\)
branch. Other mates of \(k_1\), other
six-block words and openings, and general
Barnette graphs remain outside its scope.
The proof is project-internal and makes no
external priority claim.
