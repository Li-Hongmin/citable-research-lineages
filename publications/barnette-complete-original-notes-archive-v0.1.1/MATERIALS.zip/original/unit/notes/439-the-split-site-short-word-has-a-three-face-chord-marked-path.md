> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The split site-short word has a three-face-chord marked path

The row-IV word of [Note 437](437-the-fourth-matching-short-leaf-has-thirteen-necessary-depth-words.md) with sites \((1,7)\), short leaf \(2\), and depth vector \((3,3,2,2,4,4,3)\) has a spanning marked path. Its tree splits the short-site cherry from the two-leaf word \(B=F(U_5,U_6)\).

Set
\[
\begin{aligned}
S_2&=(x_2y_2),& C&=F(U_1,S_2),& L&=F(C,U_3),\\
B&=F(U_5,U_6),& T&=F(B,U_7),& R&=F(U_4,T),\\
W&=F(L,R),
\end{aligned}                                                     \tag{1}
\]
with all \(F\)-branches and \(U_i\) full. Use the leaf paths \(Y_i,X_i\) and the bracket paths \(P_T,Q_T,R_T\) of [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md). Also set \(J_T=(\lambda_0^T,\rho_0^T,\rho_1^T,\lambda_1^T,\lambda_2^T,\rho_2^T)\); it covers all six branch brackets, using three ordinary chords and two old-cycle edges. Let \(Z_B\) be the spanning \(y_5\)--\(x_5\) path through \(B\) obtained by deleting \(x_5y_5\) from the old-cycle-plus-outer-chord Hamilton cycle, as in [Note 436](436-the-fourth-matching-three-odd-leaf-short-branch-has-a-marked-cycle.md), equation (3).

**Marked-path theorem.** A spanning \(y_1\)--\(x_7\) path is
\[
\begin{aligned}
y_1&\xrightarrow{Y_1}L_1,\quad
\lambda_2^C\xrightarrow{P_C}\rho_2^C,\quad
R_2,L_2,x_2,y_2,\quad
x_3\xrightarrow{X_3^{-1}}R_3,\quad
\rho_2^L\xrightarrow{R_L}L_\ell,\\
&\lambda_2^W\xrightarrow{P_W}\rho_2^W,\quad
R_r=\rho_0^R\xrightarrow{Q_R}\lambda_2^R,\quad
L_4,h_4,x_4,\quad
y_5\xrightarrow{Z_B}x_5,\quad
y_4,j_4,R_4,\\
&\lambda_0^T\xrightarrow{J_T}\rho_2^T,\quad
R_7\xrightarrow{X_7}x_7.
\end{aligned}                                                     \tag{2}
\]
The three nonordinary transitions are exactly the row-IV face chords \(y_2x_3,x_4y_5,x_5y_4\). The remaining joins between displayed pieces,
\[
L_1\lambda_2^C,\quad \rho_2^CR_2,\quad
R_3\rho_2^L,\quad L_\ell\lambda_2^W,\quad
\rho_2^WR_r,\quad \lambda_2^RL_4,\quad
R_4\lambda_0^T,\quad \rho_2^TR_7,
\tag{3}
\]
are consecutive old-cycle edges. The short-leaf segment \(R_2,L_2,x_2,y_2\) uses its outer ordinary chord and two old-cycle edges. The two portions \(L_4,h_4,x_4\) and \(y_4,j_4,R_4\) partition \(U_4\), while \(Z_B\) spans \(B\). Thus (2) uses every vertex exactly once: \(U_1,S_2,U_3,U_4,B,U_7\) contribute \(6+4+6+6+18+6=46\), and the five other full branch wrappers \(C,L,W,R,T\) contribute \(30\), for \(76\) vertices.

The fixed outside route of [Note 424](424-a-right-cherry-path-closes-the-maximal-chorded-seven-face-chord-kernel.md), equation (6), closes (2) through both site edges in the parent. By [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md), clause 1, every legal expanded child with word (1) is Hamiltonian. \(\square\)

Combining this certificate with Note 437's shared-chord corollary and Note 438 leaves ten structurally necessary row-IV short-leaf words. Row VI and Barnette's conjecture remain open.
