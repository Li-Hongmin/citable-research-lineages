> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two target-bearing vacancy blocks cannot separately support sharp gaps

[Note 268](268-one-vacancy-gap-support-block-has-one-face-chord.md)
gives one face-side free chord in every one-vacancy block
that receives a gap matching edge. Its unused inner slot
is a parity-protected port. When two distinct target-bearing
blocks each receive one gap slot, their two ports must match,
but the required block directions contradict gap parity.

Let \(G\) be a Barnette parent with a selected compressed
all-square facial opening, \(\ell,r\ge1\), and
\[
 f=4r+8,\qquad \sigma=T=2.                    \tag{1}
\]
Assume the two capacity vacancies lie in distinct blocks
\(A<B\), both blocks contain escape targets, and each of
the two gap slots is matched to a different one of \(A,B\).

**Two target-bearing support exclusion.** No such opening
exists. This applies whether the gap slots lie in one
two-slot gap or in two singleton gaps.

**Proof.** By Notes 255 and 258, a gap slot can be matched
only into a block with a capacity vacancy and a face-side
free chord. Thus its support blocks are \(A,B\). Note 268
gives exactly one such chord in each. A single face-side
chord cannot straddle an escape target: the free-prefix
count at that target is even by Note 255, while any
opposite-side chord crossing it would cross its escape
edge by Note 203. The local four-free-run argument in
Note 258 therefore applies independently to both blocks.
A target-bearing one-vacancy support block is either

* forward, with four consecutive free suffix slots
  \(c,H,I,e\) of colours \(O,E,O,E\) and face chord
  \(ce\); or
* reversed, with four consecutive free prefix slots
  \(d,o,J,I'\) of colours \(E,O,E,O\) and face chord
  \(dI'\).

In each case the gap mate is one of the two inner slots,
by Note 258's odd straddling parity. A possible fifth
free slot lies on the other side of the target run from
this four-slot run. The sole capacity vacancy cannot be
occupied by \(L_1\), since then no such run exists.

In either support block, its *other* inner slot must
match outside the block. It cannot match the fifth free
slot within that block: a face-side edge would be a
second face chord, and an opposite-side edge would
straddle an escape target. Nor can it match a slot of
a saturated block. The inner slot is straddled by the
face chord once, while a saturated block has no face
chord, contrary to Note 259's cross-block parity lemma.
The two gap slots are already matched. The only
remaining possible mate is the other inner slot of
the other support block: its straddling parity is
also odd, whereas any fifth free slot there has even
straddling parity. Hence these two inner slots are
matched to each other.

That cross-block matching edge joins \(A<B\) on the
side of \(C\) opposite the designated common face.
It cannot straddle any escape target by Note 203.
Consequently the four-slot run of \(A\) is after all
of its targets, so \(A\) is forward; the run of \(B\)
is before all of its targets, so \(B\) is reversed.
The gap edge entering \(A\) cannot come from its left,
and the one entering \(B\) cannot come from its right,
since either would straddle the targets of that block.
A gap edge from \(A\) to after \(B\) would also
straddle \(B\)'s targets, while a gap edge from
before \(A\) to \(B\) would straddle \(A\)'s
targets. Hence both gap slots lie strictly between
\(A\) and \(B\). There are no other gap slots, so
\(B\) has two gap slots before it. Every complete
block has even order, and Note 195's global slot
parity therefore makes \(B\) forward. This
contradicts the reversed prefix forced by its
cross-block port edge. \(\square\)

The theorem excludes only the distinct-block assignment
in which both target-bearing blocks each receive one gap.
It does not exclude two gaps supported by a single
one-vacancy block, or a mixed target-bearing/target-free
pair of support blocks. It also makes no Hamilton
assertion outside the selected opening class (1).
