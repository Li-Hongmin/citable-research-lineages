> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# All forward four-double groups with arbitrary short corridors have spanning routes

[Note 353](353-the-h1r-branch-closes-the-arbitrary-central-corridor-four-double-group.md)
settles a positive central corridor without outer flanks.
[Note 356](356-two-sided-short-flanks-preserve-the-forward-four-double-hamilton-route.md)
settles arbitrary outer flanks without a central corridor.
The three corridors can occur together: the two ordinary endports
still have only three possible mates each. The only new one-sided
outer return is reduced to the interior matchings of
[Note 352](352-the-long-central-corridor-h1j4-branch-has-exactly-two-q-hamilton-matchings.md)
and the paths of Notes 350--351.

Work in the compressed, gapless, tight-target all-square opening of
[Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Let an ordinary target-free free group have even left and odd right
endports \(L,R\), and block order
\[
 S_1,\ldots,S_a,D_1,D_2,U_1,\ldots,U_q,D_3,D_4,
 T_1,\ldots,T_b,\qquad a,b,q\ge0.                       \tag{1}
\]
The short blocks are
\[
 S_i=(c_i,r_i,s_i,d_i),\quad
 U_u=(c^0_u,\xi_u,\eta_u,d^0_u),\quad
 T_j=(c'_j,r'_j,s'_j,d'_j),                              \tag{2}
\]
and \(D_t=(a_t,o_t,h_t,i_t,k_t,j_t,e_t,b_t)\).
Every block has its common-face closing chord. The four double
blocks have the common-face internal matching chords
\[
                    i_1e_1,\quad o_2k_2,\quad
                    i_3e_3,\quad o_4k_4.                 \tag{3}
\]
Write \(F_i=(r_i,c_i,d_i,s_i)\),
\(H_u=(\xi_u,c^0_u,d^0_u,\eta_u)\), and
\(G_j=(r'_j,c'_j,d'_j,s'_j)\). For \(q\ge1\), let the
*standard central chain* be
\[
 e_2\xi_1,\quad \eta_u\xi_{u+1}\ (1\le u<q),
 \quad \eta_qo_3.                                         \tag{4}
\]

**Three-corridor theorem.** For all \(a,b,q\ge0\), every
complementary matching actually occurring in a Barnette parent
under (1)--(3) gives a vertex-spanning \(L\)--\(R\) path through
the group. If all vacancies outside the group occupy distinct
internal blocks, the parent has a Hamilton cycle through both
site edges and its legal site-expanded child is Hamiltonian.
In particular, the entire forward \(J_3,J_1,J_3,J_1\) four-double
word is settled for arbitrary short corridors at all three
positions. The assertion is conditional on an actual matching;
it does not claim that every formal chord word is realizable.
Combined with the reverse-word exclusion of
[Note 354](354-reverse-alternating-four-double-groups-are-impossible-with-arbitrary-short-flanks.md),
every *actual alternating* four-double ordinary target-free group
with these three arbitrary short corridors has a spanning route.

**Port reduction.** Note 327 excludes any further same-block
free chord. Note 193 puts every cross-block free chord on the
opposite page, where the chords do not cross. Each such chord
encloses an even number of the remaining free slots. A nonempty
proper complete-block interval closed under the matching would
have only its two boundary old-cycle edges leaving it, contrary
to three-connectivity. We call this the cut rule.

For \(q=0\), use Note 356. Hence assume \(q\ge1\). If \(a,b\ge1\),
the endport possibilities are still
\[
 L:r_1,j_2,j_4,\qquad R:s'_b,h_1,h_3.                 \tag{5}
\]
Indeed, inserting \(2q\) central free slots leaves all parity
counts in Note 356 (5)--(6) unchanged. The newly possible chord
\(L\xi_u\) encloses the complete left flank, \(D_1,D_2\), and
the earlier central blocks; \(L o_3\) encloses the same prefix
through \(U_q\). The newly possible chord \(\eta_uR\) encloses
the later central blocks, \(D_3,D_4\), and the right flank.
Each closes a nonempty proper complete-block interval. Thus (5)
is exhaustive. If \(Lr_1\) or \(s'_bR\) occurs, peel the corresponding
path \(L,r_1,c_1,d_1,s_1\) or
\(r'_b,c'_b,d'_b,s'_b,R\), as in Note 356. All cuts used after
peeling remain cuts of proper complete-block intervals of the
original graph. Induction on \(a+b\) reaches a one-sided or
no-flank group.

If neither standard boundary edge occurs, three of the four
pairs in (5) cross, exactly as in Note 356. Hence
\(Lj_2,h_3R\) are forced. Inside \(Lj_2\), the left flank and
first two double blocks force
\[
 r_1h_1,\quad s_ir_{i+1}\ (i<a),\quad s_ao_1,
 \quad k_1i_2,\quad j_1h_2.                              \tag{6}
\]
Inside \(h_3R\), the right half forces
\[
 k_3i_4,\quad j_3h_4,\quad j_4s'_b,
 \quad e_4r'_1,\quad s'_jr'_{j+1}\ (j<b).               \tag{7}
\]
These are the same parity, old-edge, and suffix-cut arguments
as in Note 356; the central slots lie outside both outer chords.
The only free slots left are \(e_2,\xi_1,\eta_1,\ldots,
\xi_q,\eta_q,o_3\). The chord \(e_2o_3\) would close the
nonempty central corridor. A chord \(e_2\xi_u\) with \(u>1\)
would close its prefix. After \(e_2\xi_1\), a first skipped
link or an early \(\eta_uo_3\) would close a nonempty interval
of central short blocks. Thus (4) is forced. Replace the join
\(e_2o_3\) between the two paths in Note 356 (7) by
\[
                         e_2,H_1,\ldots,H_q,o_3.          \tag{8}
\]
This is a spanning \(L\)--\(R\) path in the fully nonstandard
two-sided case.

**One-sided reduction.** It remains to prove the base \(a\ge1,b=0\);
old-cycle reflection reverses the four block positions and exchanges
\(J_1,J_3\), so it preserves the forward word and covers
\(a=0,b\ge1\). Note 353 covers \(a=b=0\).
The left endport still has only \(r_1,j_2,j_4\) as mates: the
central candidates are excluded by the same prefix cut used
above. If \(Lr_1\), peel \(S_1\) and induct on \(a\).
For the other branches \(e_4R\) is forced. A chord \(h_1R\)
crosses either \(Lj_2\) or \(Lj_4\). With \(Lj_4\), \(h_3R\)
also crosses. With \(Lj_2\), \(h_3R\) would force
\(k_3i_4,j_3h_4\), leaving the old pair \(j_4e_4\).
All other candidates for \(R\) are excluded by parity or the
cut rule, as in Note 356.

Suppose \(Lj_2\). The left chords are (6). The slot \(h_3\)
can meet only a central \(\xi_u\) or \(j_4\): \(o_3h_3\)
is old, \(h_3j_3\) is an excluded same-block chord,
\(h_3i_4\) encloses three free slots, and its other
possible mates are already used. The right tail forces
\(k_3i_4,j_3h_4\). The remaining free slots are
\(e_2,\xi_1,\eta_1,\ldots,\xi_q,\eta_q,o_3,h_3,j_4\).
Their noncrossing matching is exactly one of the
\(C_{q,p}\), \(0\le p\le q\), in Note 353 (5), with its
central \(r_u,s_u\) renamed \(\xi_u,\eta_u\). Indeed,
Note 353's prefix and suffix cut argument applies to
these identical free slots: \(h_3\xi_{p+1}\) for
\(p<q\), or \(h_3j_4\) for \(p=q\), determines the
same unique central links.

For each \(p\), Note 353 (6)--(7) gives a path of the form
\[
       L_0,\ A_{q,p}(o_1,\ldots,e_4),\,
       B(j_2,\ldots,h_1),\ R_0,                           \tag{8a}
\]
where \(A_{q,p}\) and \(B\) are disjoint and together cover
all four double blocks and the central corridor. The join
from \(e_4\) to \(j_2\) in (8a) is the chord of Note 353;
it is not used here. Instead take
\[
              L,\ B(j_2,\ldots,h_1),\,
              F_1,\ldots,F_a,\ A_{q,p}(o_1,\ldots,e_4),\ R.
                                                               \tag{8b}
\]
Its new joins are \(Lj_2,h_1r_1,s_ao_1,e_4R\), and
the standard left links. Thus it is a spanning path for
every \(C_{q,p}\), including the delayed central returns.

Suppose \(Lj_4\). The first odd flank slot \(r_1\) can meet
only \(h_1\) or \(h_3\). A mate \(e_2\) closes
\(S_1,\ldots,S_a,D_1,D_2\); a central \(\eta_u\) closes
the same complete-block prefix through \(U_u\). The other
mates are parity-forbidden, old edges, or cross \(Lj_4\).
If \(r_1h_1\), its interior forces
\(s_ir_{i+1}\ (i<a),s_ao_1\). The free slots strictly
between \(h_1,j_4\) cannot pair with either exterior:
a chord to the left would cross \(r_1h_1\), and a chord to
the right would cross \(Lj_4\). Their possible matchings
are therefore exactly the *interior* \(A/B\times C_{q,p}\)
matchings classified in Note 352 (3)--(4), with
\(0\le p<q\); the former outer chord \(h_1j_4\) is replaced
by \(r_1h_1,Lj_4\). The \(A,p>0\) choice is impossible:
the complete-block interval
\[
                  S_1,\ldots,S_a,D_1,D_2,U_1,\ldots,U_p  \tag{9}
\]
is matching-closed. For \(p=0\), take \(P_A\) or \(P_B\)
from Note 355 (9) and replace \(e_2o_3\) by (8).
For the remaining \(B,p>0\), the following is a spanning path:
\[
\begin{split}
L,j_4,k_4,i_4,k_1,i_1,h_1,F_1,\ldots,F_a,
o_1,a_1,b_1,e_1,j_1,h_2,o_2,a_2,b_2,e_2,\\
H_1,\ldots,H_p,j_2,k_2,i_2,k_3,i_3,h_3,
H_{p+1},\ldots,H_q,o_3,a_3,b_3,e_3,j_3,h_4,
o_4,a_4,b_4,e_4,R .                                     \tag{10}
\end{split}
\]
The four joins at the central cut are \(e_2\xi_1,
\eta_pj_2,h_3\xi_{p+1},\eta_qo_3\), precisely
Note 352's \(C_{q,p}\). The splice \(k_1i_1,e_1j_1\)
uses two old-cycle edges in place of the edges
\(k_1j_1,i_1e_1\) of Note 352's \(B\)-route;
the new flank runs from \(h_1\) to \(o_1\).
Every other consecutive pair is an old edge, a closing or
internal chord, or an edge of the specified matching.

Finally suppose \(r_1h_3\). The right tail forces
\(k_3i_4,j_3h_4\). Follow the initial standard left links.
The first unmatched \(s_t\) can meet \(r_{t+1}\), \(o_1\),
or \(j_2\). A mate \(o_1\) is possible only for \(t=a\);
a later left \(r_v\) or \(s_t\xi_u,s_to_3\) would close
a nonempty complete-block interval, while the other
candidates violate parity or cross \(r_1h_3\).
If the first deviation is \(s_tj_2\), then \(t<a\):
\(t=a\) leaves \(o_1\) with no mate inside that chord.
The first odd slot \(r_{t+1}\) inside it must meet \(h_1\).
The remaining left links, \(s_ao_1,k_1i_2,j_1h_2\),
and the central chain (4) are forced exactly as in
Note 355 (8). Take its \(P_t\) in Note 355 (10) and
replace \(e_2o_3\) by (8).

If all links are standard through \(s_ao_1\), the possible
mates of \(h_1\) are \(j_2,\xi_1,\ldots,\xi_q,o_3\).
The choice \(h_1\xi_1\) leaves the old pair \(j_2e_2\)
after \(k_1i_2,j_1h_2\) are forced, as in Note 351 (5).
If \(h_1j_2\), the remaining chords are
\(k_1i_2,j_1h_2\), (4), and the forced right tail;
take \(P_{\mathrm{loc}}\) of Note 355 (9) with (8).
If \(h_1o_3\), Note 350's interior forcing applies.
Its spanning \(j_4\)--\(e_4\) path \(W\) contains
the matching edge \(h_3o_1\). Replace that edge by
\[
                       h_3,F_1,\ldots,F_a,o_1,          \tag{11}
\]
where the notation means the simple sequence
\(h_3,r_1,c_1,d_1,s_1,r_2,\ldots,s_a,o_1\).
Prepend \(L\), append \(R\), and use Note 350's
central extension of \(W\).
If \(h_1\xi_t\) with \(2\le t\le q\), the forcing inside
that chord is Note 351 (3); since \(h_3\) is already
matched to \(r_1\), the remaining suffix is forced to
the standard links and \(\eta_qo_3\). Take Note 351's
\(j_4\)--\(e_4\) path \(W_{q,t}\) (6) and make the same
replacement (11) for its edge \(h_3o_1\).
Every route in this paragraph visits the outer flank once,
keeps all other block vertices of its cited explicit path,
and uses precisely the new chords \(r_1h_3,s_ao_1\) and
the standard flank links. This finishes the one-sided
case and, by the port reduction, the theorem. \(\square\)

The theorem settles this specified ordinary forward four-double
word inside the selected all-square, gapless, tight opening.
Other internal chord words, target-bearing group boundaries,
positive gaps, nonsquare residual cycles, and general Barnette
graphs are outside its scope. The proof is project-internal;
no external priority claim is made.
