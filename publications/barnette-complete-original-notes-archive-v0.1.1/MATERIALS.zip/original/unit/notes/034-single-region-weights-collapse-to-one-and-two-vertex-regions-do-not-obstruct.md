> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Single-region weights collapse to one, and two-vertex regions do not obstruct

[Note 033](033-single-layer-fec-support-is-a-laminar-face-region-charging-problem.md)
reduces a binary FEC support defect to a laminar family of weighted face
regions.  This note settles two first boundary cases.  For a single region,
the continuous weight is completely controlled by its value at one.  In an
actual plane-brace site, a two-vertex region cannot support such a defect.

## A single region has one mixed obstruction

Fix

\[
 A\subseteq Y\setminus\{a\},
 \qquad
 W\subsetneq V(Q),
 \qquad
 I=E_Q(W),
\]

and give the single dual region weight \(z_W=t\ge0\).  Put

\[
 c_e=\mathbf1_{\{y(e)\in A\}}.
\]

For one \(X\)-block \(D_x\), label an edge by
\((c_e,\mathbf1_I(e))\in\{0,1\}^2\).  A block containing a
\(00\)-edge contributes zero to

\[
 L(t)=
 \sum_x\min_{e\in D_x}
 \bigl(c_e+t\mathbf1_I(e)\bigr).
 \tag{1}
\]

Partition the remaining blocks into four classes:

\[
\begin{array}{c|l|c}
\text{class}&\text{available types}&\text{minimum}\\ \hline
a&01\text{ and }10&\min(t,1)\\
b&01\text{ but no }10&t\\
c&10\text{ but no }01&1\\
d&11\text{ only}&1+t.
\end{array}
\]

Thus

\[
 L(t)=a\min(t,1)+bt+c+d(1+t).
 \tag{2}
\]

Two endpoint inequalities are automatic.  First,

\[
 L(0)=c+d\le |A|.
 \tag{3}
\]

Indeed, the \(c+d\) blocks contain only edges whose \(Y\)-endpoint lies
in \(A\).  Any perfect matching of \(K\) selects one edge from every
\(X\)-block and matches these blocks to distinct vertices of \(A\).

Second, for \(t\ge1\) the slope of \(L\) is

\[
 b+d\le |W|-1.
 \tag{4}
\]

The \(b+d\) blocks have every retained edge in \(I\).  Any
\(X\)-graphic base selects one internal edge from each, while its
restriction to \(W\) is a forest.

On \([0,1]\), the difference between (2) and
\(|A|+t(|W|-1)\) is affine.  On \([1,\infty)\), its slope is nonpositive
by (4).  Therefore, **given the automatic inequalities (3)--(4)**, the
whole family

\[
 L(t)\le |A|+t(|W|-1)
 \qquad(t\ge0)
 \tag{5}
\]

is equivalent to its single value at \(t=1\):

\[
 \boxed{
 a+b+c+2d\le |A|+|W|-1.}
 \tag{6}
\]

This is a genuine additional condition.  Adding (3) and (4) gives only
\(b+c+2d\le |A|+|W|-1\), missing the entire \(a\)-term.

Equivalently, let \(P\) be the \(X\)-blocks containing no edge that is
simultaneously outside \(A\) and outside \(I\), and let \(D\) be the
blocks all of whose edges are simultaneously in \(A\) and in \(I\).
Then the unique mixed obstruction is

\[
 \boxed{|P|+|D|>|A|+|W|-1.}
 \tag{7}
\]

Thus a single-region problem is discrete: no value of \(t\ne1\) carries
information beyond Hall at \(t=0\), graphic rank at infinity, and the
mixed count (7).

## A matching sufficient condition

Suppose \(K\) has a perfect matching \(M\) satisfying

\[
 |M\cap I|\le |W|-1.
 \tag{8}
\]

The \(X\)-blocks are pairwise disjoint, so blockwise comparison with the
edge selected by \(M\) gives

\[
\begin{aligned}
L(t)
&\le
\sum_{e\in M}
\bigl(c_e+t\mathbf1_I(e)\bigr)\\
&=|A|+t|M\cap I|\\
&\le |A|+t(|W|-1).
\end{aligned}
\tag{9}
\]

The first equality uses that \(M\) matches every vertex of
\(Y\setminus\{a\}\) exactly once.  The matching may depend on \(W\);
equation (9) is a single-region statement and supplies no simultaneous
witness for several nested regions.

## Exact two-vertex classification

Assume now the actual setting of Notes 028--033: \(F\) is a plane cubic
bipartite brace, \(p=uv\) and \(h=za\) form a legal cofacial site, and

\[
 Q=(F^*/\{p^*,h^*\})[E(K)^*].
\]

Let \(|W|=2\).  Note 030 proves that \(Q\) has no retained loops.  Write
\(c,c_p,c_h\) for the three dual vertices identified to the contracted
root.  If \(W\) avoids the root, simplicity of \(F^*\) gives
\(|I|\le1\).  If \(W\) contains the root and one other dual vertex \(s\),
then every edge of \(I\) lifts to one of the at most three edges from
\(s\) to \(c,c_p,c_h\).  Hence

\[
 |I|\le3.
 \tag{10}
\]

The two-edge case need not be one of the local special blocks
\(D_z,D_v\): a remote vertex may be adjacent to \(c_p,c_h\) without
being adjacent to \(c\).  This possibility is harmless.  Note 028 proves
that \(K=F-\{u,a\}\) is 1-extendable, and every vertex of \(K\) has degree
at least two.  Given two edges \(e,f\), choose another edge at one endpoint
of \(e\) and extend it to a perfect matching.  That matching avoids
\(e\), so it uses at most one of \(e,f\).  Thus every case \(|I|\le2\)
satisfies (8).

It remains only \(|I|=3\).  Then \(s\) is adjacent in \(F^*\) to all of
\(c,c_p,c_h\).  The triangles \(cc_ps\) and \(cc_hs\) are facial because
\(F^*\) is 4-connected.  The primal edge dual to \(cs\) is therefore
incident with an endpoint of each of the disjoint edges \(p=uv\) and
\(h=za\).  Since it is retained in \(K\), those endpoints cannot be the
deleted vertices \(u,a\); hence the edge is exactly \(vz\).  The other two
members of \(I\) are the remaining retained edges at \(v\) and \(z\).
Choose, by 1-extendability, a perfect matching containing \(vz\).
Matching incidence at \(v\) and \(z\) excludes those other two internal
edges, and therefore

\[
 |M\cap I|=1=|W|-1.
 \tag{11}
\]

Equation (9) now proves:

> **Two-vertex region theorem.** No strict single-region binary FEC
> support certificate in an actual plane-brace site can be supported on a
> two-vertex set \(W\).

The bound is tight: a complete special block at the degree-two vertex
\(z\) or \(v\) forces one internal matching edge.  It cannot be
strengthened to zero.

## Consequences and boundary

Every actual single-region obstruction must have \(|W|\ge3\) and must
violate the finite mixed inequality (6), equivalently (7).  A general
laminar obstruction must either contain such a region or rely on genuine
interaction among several regions.  This note does not prove the mixed
inequality for \(|W|\ge3\), and the perfect matching chosen for one region
need not work for another.

The elementary block table and piecewise reduction are checked by

```bash
python3 \
  units/barnette/scratch/worker-barnette/verify_single_region_two_vertex_boundary.py
```

with terminal marker `SINGLE_REGION_TWO_VERTEX_BOUNDARY_VERIFIED`.
