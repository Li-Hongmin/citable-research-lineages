> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A legal-wide fibre can contain a nonminimum atomic two-switch

[Note 086](086-minimum-cross-sector-pairs-are-atomic-and-the-cube-is-the-minimum-fibre-countermodel.md)
shows that a minimum pair from opposite gate sectors either differs on one
alternating cycle or generates an atomic component cube.  Its cube model is
not a plane labelled square extension.  This leaves two distinct possible
uses of planarity: one could try to exclude every atomic two-coordinate
subcube locally, or use the global minimality of the chosen cross-sector
pair to force a fibre state outside that subcube.

The first route is false in an infinite family of actual Barnette
interfaces.  Even prisms contain a legal-wide fixed-pairing fibre with a
two-\(C_4\) subcube whose only feasible masks are \(00\) and \(11\).  The
same fibre also contains a one-\(C_6\) crossing outside the subcube.  Thus
planarity, the brace axiom and legal-wide geometry do not split an arbitrary
atomic overlay; a proof must use the global absence of every crossing edge.

## 1. The even-prism interfaces

Let

\[
G_n=C_n\square K_2,
\qquad n\ge 8\text{ even},
\tag{1}
\]

with vertices \(t_i,b_i\), rim edges

\[
T_i=t_it_{i+1},\qquad B_i=b_ib_{i+1},
\tag{2}
\]

and rungs \(R_i=t_ib_i\), with indices modulo \(n\).  Take

\[
e=B_0,\qquad g_0=T_0,
\tag{3}
\]

so that \(e,g_0\) are opposite edges of the side square

\[
Q=b_0b_1t_1t_0b_0.
\tag{4}
\]

Choose an even \(s\) satisfying

\[
4\le s\le n-4
\tag{5}
\]

and let the surviving gate be

\[
g_1=T_s.
\tag{6}
\]

The two gates \(T_0,T_s\) lie on the top facial \(n\)-cycle.  Its two
residual gate-to-gate arcs have lengths \(s-1\) and \(n-s-1\), both odd and
at least three.  Hence this is a legal-wide site.  The graph \(G_n\) is a
simple plane cubic bipartite brace, as established for the same family in
[Note 083](083-a-wide-gate-can-be-a-restricted-coloop.md).

Put

\[
H=\{T_0,B_0\}\cup\{R_i:i\notin\{0,1\}\},
\qquad
S_i=\{T_i,B_i,R_i,R_{i+1}\}.
\tag{7}
\]

The complete rooted-target classification from Note 083 is

\[
\mathcal T_{B_0}
=\{M_j:j\notin\{-1,0,1\}\},
\qquad
M_j=H\mathbin\triangle S_j.
\tag{8}
\]

By the square-deletion theorem of
[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md),
removing \(Q\) identifies this complete family with the fixed-pairing
two-linkage fibre \(\mathcal L\).

## 2. A locally atomic two-switch

Take

\[
M=M_s,\qquad N=M_2.
\tag{9}
\]

Then \(g_1\in M\setminus N\), the side squares \(S_s,S_2\) are
vertex-disjoint, and

\[
M\mathbin\triangle N=S_s\mathbin{\dot\cup}S_2.
\tag{10}
\]

The two proper component toggles are

\[
M\triangle S_s=H,
\qquad
M\triangle S_2=H\triangle S_s\triangle S_2.
\tag{11}
\]

Neither belongs to the complete family (8).  The first is \(H\) itself.
The second cannot equal any \(H\triangle S_j\), because
\(S_s\triangle S_2\) consists of two vertex-disjoint four-cycles rather
than one side square.  After deleting \(Q\), the corresponding two proper
toggles are therefore absent from \(\mathcal L\).  Relative to the two
components in (10), the exact feasible mask set is

\[
\boxed{\{A\subseteq\{2,s\}:M\triangle\!\bigtriangleup_{i\in A}S_i
\text{ lies in the fibre}\}=\{\varnothing,\{2,s\}\}.}
\tag{12}
\]

For \(n=8,s=4\), the two failed masks have different explicit defects in
the four-terminal graph \(G_8-V(Q)\).  The restriction of \(H\) leaves two
rim paths with the wrong terminal pairing.  The restriction of
\(H\triangle S_4\triangle S_2\) leaves the required two terminal paths and
the additional closed square

\[
t_3t_4b_4b_3t_3.
\tag{13}
\]

Thus (12) is a genuine fixed-pairing atomic subcube, not merely a failure of
one chosen diagnostic.

## 3. Why this is not a minimum cross-sector pair

The fibre contains a supplementary state outside the two-coordinate cube.
Since \(s-1\notin\{-1,0,1\}\), \(M_{s-1}\) is another rooted target, and

\[
M_s\triangle M_{s-1}=S_s\triangle S_{s-1}
\tag{14}
\]

is the single alternating six-cycle with edge set

\[
\{T_{s-1},T_s,B_{s-1},B_s,R_{s-1},R_{s+1}\}.
\tag{15}
\]

It contains \(g_1=T_s\), so \(M_s\) and \(M_{s-1}\) lie in opposite gate
sectors.  Consequently the global minimum number of symmetric-difference
components across the two sectors is one, not two.

This distinction is essential.  Equation (12) disproves the local claim

\[
\text{plane brace + legal-wide extension}
\Longrightarrow
\text{every atomic two-switch has a feasible proper toggle}.
\tag{16}
\]

It does **not** disprove the crossing-edge candidate of Note 085 or the
minimum-pair alternative of Note 086.  Instead it identifies their next
necessary input: assuming that the entire fibre has no cross-sector
single-cycle edge, one must use that global hypothesis to force a proper
toggle or another contradiction.  No argument reading only the planar
overlay \(M,N,S_2,S_s\), even together with the brace and legal-wide
hypotheses, can do so.

## 4. Exact boundary

**Exact conclusion.**  Every even prism in (1)--(6) contains a legal-wide
fixed-pairing fibre with a locally atomic two-\(C_4\) cross-sector subcube.
The same fibre has a cross-sector one-\(C_6\) exchange outside that subcube.

**Evidence level.**  The arbitrary-order statement follows analytically
from the complete even-prism family (8).  The
[verification bundle](../computations/bundles/legal-wide-atomic-two-switch/README.md)
independently enumerates all perfect matchings of the octagonal prism and
checks its embedding, brace property, complete fibre, two failed proper
toggles and external \(C_6\) crossing.

**Unresolved boundary.**  It remains unknown whether a *globally minimum*
cross-sector pair in an actual plane-brace legal-wide square extension can
have two alternating components.  [Note 088](088-a-wide-plane-nonbrace-realizes-a-minimum-atomic-two-switch.md)
shows that the minimum can equal two when the brace hypothesis is removed.
Equivalently, the crossing-edge candidate is still open in the brace class;
any proof must use brace-level global fibre supplementation rather than a
Jordan or \(K_{3,3}\) argument on one atomic overlay.
