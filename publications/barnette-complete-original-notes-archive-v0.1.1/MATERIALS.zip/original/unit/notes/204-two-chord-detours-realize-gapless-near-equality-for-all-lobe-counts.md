> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Detours realize gapless near equality for every lobe and chord count

[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
excludes a middle-block vacancy at the first boundary above exact
packing when the other site-face arc has one matching chord. With
two such chords, a short block can carry a nested detour around the
vacancy. The following explicit family shows that the one-chord
exclusion does not extend merely by applying the same crossing rule.
The square amplifier of [Note 190](190-fixed-lobe-chord-amplification-preserves-two-hamilton-witnesses.md)
then carries the example to every larger chord count. Every member
is a Barnette graph and has a Hamilton cycle through both site edges.

Fix \(\ell\ge2\). Define a cycle \(C_\ell\) by concatenating the
main segment
\[
\begin{aligned}
x, R_\ell,e,y,
&a_1,o,e_1,b_1,
a_2,g,h,i,\\
&L_\ell,R_{\ell-1},L_{\ell-1},R_{\ell-2},
\ldots,L_2,R_1,
j,b_2,u,z,L_1,v
\end{aligned}                                                   \tag{1}
\]
with the complementary segment
\[
v,\alpha_1,\gamma_1,\delta_1,\beta_1,
\alpha_2,\gamma_2,\delta_2,\beta_2,
\ldots,
\alpha_\ell,\gamma_\ell,\delta_\ell,\beta_\ell,x.
\tag{2}
\]
For \(\ell=2\), the target string in (1) is just
\(L_2,R_1\). Add the perfect matching
\[
\begin{aligned}
M_\ell={}&\{xy,a_1b_1,a_2b_2,uv,
ei,oh,e_1g,jz\}\\
&\cup\{\alpha_t\beta_t,\gamma_tL_t,
\delta_tR_t:1\le t\le\ell\}.
\end{aligned}                                                   \tag{3}
\]
Let \(G_\ell=C_\ell\cup M_\ell\). The site edges are
\(q=xy,p=uv\).

**Two-chord detour theorem.** For every \(\ell\ge2\),
\(G_\ell\) is a simple three-connected cubic bipartite
plane graph. The two site edges are cofacial; their selected
all-square facial opening has \(r=2\), \(f=12=4r+4\),
no interblock gaps, tight first and last targets, and every
\(L_t,R_{t-1}\) transition adjacent. Its unique vacant
eligible even slot is \(h\) in the second opposite-face
chord block. Nevertheless \(G_\ell\) has a Hamilton cycle
containing both \(p,q\), so its legal site-expanded child is
Hamiltonian. The parent has \(6\ell+16\) vertices and the
child has \(6\ell+20\).

**Proof: class membership and the opening.** The edges in (3)
pair every vertex exactly once. Numbering \(C_\ell\) from
\(x\), every pair has endpoints of opposite parity. None
duplicates a cycle edge, so \(G_\ell\) is simple, cubic,
and bipartite.

Draw \(C_\ell\) as a Jordan curve. On the side of the
designated site face, draw the mutually noninterlacing
chords \(xy,a_1b_1,a_2b_2,uv\) and every
\(\alpha_t\beta_t\). The region incident with all four
of the former chords makes \(xy\) and \(uv\) cofacial;
its \(y\)-to-\(u\) arc contains precisely \(a_1b_1\)
and \(a_2b_2\). Its \(v\)-to-\(x\) arc is the
alternating facial path
\(v\alpha_1,\alpha_1\beta_1,\beta_1\alpha_2,
\ldots,\alpha_\ell\beta_\ell,\beta_\ell x\).
On the other side draw the remaining
matching edges. They are nested or disjoint: the outer
escape edge \(R_\ell\delta_\ell\) contains the free-chord
nest
\[
ei\supset oh\supset e_1g
\tag{4}
\]
and the escape nest
\[
L_\ell\gamma_\ell\supset
R_{\ell-1}\delta_{\ell-1}\supset
L_{\ell-1}\gamma_{\ell-1}\supset\cdots\supset
R_1\delta_1\supset L_1\gamma_1.
\tag{5}
\]
The chord \(jz\) lies inside \(R_1\delta_1\), disjoint
from \(L_1\gamma_1\). Thus the drawing is plane. Each
\(\alpha_t,\gamma_t,\delta_t,\beta_t\) is a residual
square for the selected facial opening. Its two escape
edges meet the main segment, so every square is one lobe.

The four main blocks have respectively
\(2,2,2+2\ell,2\) interior slots. Hence
\(|V(S_0)|=16+2\ell\) and
\(f=|V(S_0)|-2\ell-4=12\). The targets in (1)
give the stated tight order. The second face-chord block
begins with \(g,h,i\); its position 2 is the sole eligible
even slot not occupied by a nonfinal \(L_t\).

For completeness, the plane cubic graph is 3-connected.
Call two matching edges *interlaced* when their four
endpoints alternate around \(C_\ell\), regardless of which
side their plane drawings use. Their interlacement graph
is connected. Indeed, \(xy\) interlaces both \(ei\) and
\(R_\ell\delta_\ell\); \(ei\) interlaces \(a_2b_2\);
\(a_2b_2\) interlaces \(oh,e_1g,jz\), every
\(L_t\gamma_t\) with \(t\ge2\), and every
\(R_t\delta_t\) with \(t<\ell\). Also \(oh\)
interlaces \(a_1b_1\), \(jz\) interlaces \(uv\),
\(uv\) interlaces \(L_1\gamma_1\), and each
\(\alpha_t\beta_t\) interlaces \(L_t\gamma_t\).
These incidences reach every edge of (3).

If a cubic graph \(C\cup M\) with spanning cycle \(C\)
had an edge cut of size at most two, that cut would consist
of exactly two cycle edges. One shore would be a nonempty
proper consecutive \(C\)-interval closed under \(M\).
Such an interval partitions the matching edges into inside
and outside edges, and no inside edge can interlace an
outside edge. This contradicts the connected interlacement
graph. Thus \(G_\ell\) is 3-edge-connected. In a cubic
graph a cut vertex gives an edge cut of size at most two.
If \(\{u',v'\}\) were a two-vertex separator, each component
of \(G_\ell-\{u',v'\}\) would need at least three incident
edges. Degree three at \(u',v'\) allows exactly two
components, no edge \(u'v'\), and exactly three attachments
to each. One of \(u',v'\) has at least two attachments to
either chosen component. Including that vertex with the
component gives an edge cut of size at most two, a
contradiction. Therefore \(G_\ell\) is 3-connected.

**Proof: marked Hamilton cycle.** Let \(A\) consist of the
even-starting cycle edges of \(C_\ell\), indexed from \(x\).
The target and square vertices form the \(M_\ell\cup A\)
path
\[
x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,R_{\ell-1},\ldots,
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\tag{6}
\]
All other vertices form the disjoint \(x\)-to-\(v\) path
\[
x,y,e,i,h,o,a_1,b_1,e_1,g,a_2,b_2,j,z,u,v.
\tag{7}
\]
Its matching edges are exactly
\(xy,ei,ho,a_1b_1,e_1g,a_2b_2,jz,uv\);
its other edges belong to \(A\). Paths (6)--(7)
cover \(V(G_\ell)\), meeting only at \(x,v\).
Their union is a Hamilton cycle containing \(p,q\).
Note 001 lifts that cycle through the legal site expansion.
\(\square\)

This family is a positive example, not a Barnette
counterexample. Its nested detour is available because
\(a_1b_1\) supplies two free slots before the vacant
block. The one-chord case has no such buffer and is
excluded by Note 203's crossing argument. Therefore the
first-above-equality argument for arbitrary \(r\) must
allow these detours; the mere location of a middle
vacancy cannot imply nonexistence.

**Amplified detour theorem.** For every \(\ell,r\ge2\), there is
a simple three-connected cubic bipartite plane parent with a
legal all-square site opening having \(\ell\) square-trap lobes,
\(r\) opposite-face matching chords, no interblock gaps, tight
first and last targets, and adjacent consecutive-lobe
transitions, for which
\[
 f=4r+4,
 \qquad |V(S_0)|=2\ell+4r+8,
 \qquad |V(G)|=6\ell+4r+8.
 \tag{8}
\]
The unique vacant eligible even slot is in the final
opposite-face chord block \(B_r\), at its second interior
position. The parent has a Hamilton cycle containing both
site edges, and its legal site-expanded Barnette child is
Hamiltonian and has \(6\ell+4r+12\) vertices.

**Proof.** Start with \(G_\ell\) above. Its first face-chord
block is the facial square \((A,B,W,Z)=(a_1,o,e_1,b_1)\).
The old cycle uses \(AB,BW,WZ\), while \(AZ=a_1b_1\)
belongs to the complementary matching and to the common
site-face arc. The marked Hamilton cycle (6)--(7) uses
\(a_1b_1\) and avoids \(oe_1\). Thus all hypotheses of
Note 190's marked square amplifier hold.

One amplification replaces the old \(C\)-subpath
\(A,B,W,Z\) by
\(A,B,h_4,h_1,h_2,h_3,W,Z\). On the common face,
the old chord \(AZ\) is replaced by the two matching
chords \(Ah_1,h_2Z\), separated by the cycle edge
\(h_1h_2\). Consequently the old two-slot block
\([A,Z]_C\), whose interior was \(B,W\), becomes two
consecutive two-slot blocks: \([A,h_1]_{C'}\) with
interior \(B,h_4\), and \([h_2,Z]_{C'}\) with interior
\(h_3,W\). There is no new gap or escape target in either
block. Note 190 supplies a new marked amplifier square
\(A,B,h_4,h_1,A\) in the first of these blocks, so this
same subdivision can be repeated \(r-2\) times.

Afterward \(B_0\), all \(r-1\) face-chord blocks before
\(B_r\), and \(B_{r+1}\) each have two interior slots;
\(B_r\) is the unchanged block \([a_2,b_2]_C\) with
\(2\ell+2\) interior slots. The target order and every
adjacency in the base opening are unchanged. A two-slot
block has no eligible even position under Note 197's
definition. The only vacancy therefore remains \(h\),
the second interior slot of \(B_r\). Each subdivision adds
one face chord, four free main vertices and four total
vertices, giving (8). At each step Note 190 preserves the
Barnette property, the common site face, and both marked
Hamilton cycles; Note 001 lifts the one containing the site
edges to the site-expanded child. \(\square\)

[Note 207](207-a-single-long-chord-block-at-first-surplus-always-has-a-marked-hamilton-cycle.md)
subsequently proves that every Barnette parent with this
single-long-block, tight gapless target profile has a
marked Hamilton cycle; it classifies all its free-slot
matchings rather than only constructing one.
