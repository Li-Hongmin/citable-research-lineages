> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disjoint target defects compose at every saturated gapless surplus

Notes 211--212 repair each possible single target-order
defect at \(f=4r+4\). Their repairs lie in closed free-matching
groups. When several defect intervals use disjoint block sets,
the same repairs can be made simultaneously.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), no interblock gaps, and
\[
s=\frac{f-4r-2}{2}
\]
vacant eligible positions, as in Note 197. The main
blocks are \(B_0=[x,y]_C,B_1,\ldots,B_r,
B_{r+1}=[u,v]_C\), and \(M=E(G)\setminus E(C)\).
For every target-order defect, define its *block
interval*:
\[
\begin{array}{ll}
d_L=1:&[0,h],\quad R_\ell\in B_h;\\
L_jR_{j-1}\notin E(C):&
[i,h],\quad L_j\in B_i,\ R_{j-1}\in B_h;\\
d_R=1:&[i,r+1],\quad L_1\in B_i .
\end{array}
\tag{1}
\]
The intervals are closed integer intervals of block indices.

**Disjoint-defect composition theorem.** If
\[
d_L+b+d_R=s
\quad\text{and the intervals in (1) are pairwise
disjoint},                                           \tag{2}
\]
then the parent has a Hamilton cycle containing both
site edges \(xy,uv\). Its legal site-expanded child
is Hamiltonian. The conclusion holds for every
\(s\) allowed by (2) and for arbitrary positive
original lobe lengths.

**One vacancy per defect.** Note 197 assigns a
different vacant eligible position to each defect:
before \(R_\ell\), strictly between
\(L_j,R_{j-1}\), or at \(L_1\), respectively.
Equality in (2) says these assignments exhaust
all vacancies. The disjoint block intervals
therefore give each defect exactly its one
assigned vacancy, with no other vacancy in its
block interval.

For a left endpoint defect, this makes
\(R_\ell\) the third interior slot of \(B_h\);
all preceding blocks are short. Note 197's
endpoint barrier excludes a first slot in a
later block, and a fifth or later slot would
require another vacant eligible position.
The case \(h=0\) leaves an unmatched adjacent
free pair, as in Note 211, so \(h\ge1\).
Writing \(o_0,e_0,\ldots,o_{h-1},e_{h-1},o_h,w\)
for its free slots before \(R_\ell\), the local
repair will use \(o_0w\).

Reflecting this argument, a right endpoint
defect puts \(L_1\) in the last eligible even
position of a block \(B_i\), \(i\le r\).
Every later block is short. Write \(c_i,e_i\)
for the two free slots following \(L_1\);
the final site block has two free slots
\(o_{r+1},e_{r+1}\). The reflected repair
will use \(c_i e_{r+1}\).

For a defective transition \(L_j,R_{j-1}\),
Note 212's first-slot cut argument excludes
\(R_{j-1}\) as the first interior of a later
block. With exactly one vacancy between the
targets, a same-block placement would isolate
two adjacent free slots by even-prefix parity,
as in Note 212; other disjoint defects change
each such prefix count by two and do not affect
the contradiction. Consequently \(L_j\) is
the last eligible even position of \(B_i\),
with free successors \(c_i,e_i\);
\(R_{j-1}\) is the third interior slot of
\(B_h\), preceded by \(o_h,w\); and all
blocks strictly between \(B_i,B_h\) are short.
Here \(i<h\), and the repair will use \(c_iw\).

**Closed matching groups.** The free-slot prefix
at every occupied target run is even. This
holds at both ends of each defect group by
the displayed local slot forms. Between
defects, each completed defect adds two free
slots to the ordinary prefix count. A free
edge joining different blocks cannot straddle
an escape target by Note 203. Within a target
block, the local forms above and disjointness
leave at most one possible same-block free chord
across its occupied run. Since an even vertex
set has an even number of matching edges leaving
it, no free matching edge crosses any occupied
target run.

The defect free groups are therefore mutually
closed under \(M\). Note 211's noncrossing and
two-edge-cut argument fixes a left endpoint
group as \(o_0w\) plus its ordinary standard
links. Its reflection fixes a right endpoint
group as \(c_i e_{r+1}\) plus standard links.
Note 212's same argument fixes a transition
group as \(c_iw\) plus standard links. Earlier
or later defect groups are closed by the
barriers, so none of these local arguments
uses a uniqueness assumption outside its own
group. Every group without a defect follows
the standard \(e_t o_{t+1}\) chain of Note 196.

Let \(A\) be the even-starting old-cycle
matching indexed from \(x\). Start with
Note 196's target-and-square path from \(x\)
to \(v\). Make the following substitutions
for the defects present:
\[
\begin{array}{ll}
xR_\ell&\longmapsto x,o_0,w,R_\ell,\\
L_jR_{j-1}&\longmapsto L_j,c_i,w,R_{j-1},\\
L_1v&\longmapsto L_1,c_i,e_{r+1},v .
\end{array}
\tag{3}
\]
Each new middle edge is the fixed matching
edge of its defect group. The two outer
edges of each replacement belong to \(A\).
Pairwise disjoint block intervals make the
inserted vertices distinct. All ordinary
free slots remain on Note 196's second,
standard-chain \(x\)-to-\(v\) path. The two
paths share only \(x,v\), cover all vertices,
and form one Hamilton cycle containing
\(xy,uv\). Notes 001 and 178 give the
legal child and longer lobes. \(\square\)

**A realized pair of endpoint defects.** Set
\(\ell=1,r=3,s=2\). Take the old 28-cycle
in consecutive blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,w,R_1,e_1,b_1,\\
B_2:&a_2,o_2,e_2,b_2,\\
B_3:&a_3,o_3,L_1,c_3,e_3,b_3,\\
B_4:&u,o_4,e_4,v,\\
S_1:&\alpha,\gamma,\delta,\beta
\quad\text{returning to }x.
\end{array}                                           \tag{4}
\]
Add the complementary matching
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2,a_3b_3,
\alpha\beta,R_1\delta,L_1\gamma\}\\
&\cup\{o_0w,e_0o_1,e_1o_2,e_2o_3,
e_3o_4,c_3e_4\}.
\end{split}                                           \tag{5}
\]
All matching pairs have opposite old-cycle
parity. Draw the site, face, and
\(\alpha\beta\) chords on one side of \(C\).
On the other side, \(o_0w\supset e_0o_1\);
\(R_1\delta\) contains the remaining
opposite-side chords, with
\(L_1\gamma\supset c_3e_4\supset e_3o_4\).
Thus the graph is simple, cubic, bipartite,
plane, with cofacial sites.
The chord-interlacement graph is connected:
\[
xy-o_0w-a_1b_1-e_1o_2-a_2b_2-e_2o_3
-a_3b_3-e_3o_4-uv-L_1\gamma
-\alpha\beta-R_1\delta-a_1b_1,
\tag{6}
\]
while \(e_0o_1\) attaches to \(xy\) and
\(c_3e_4\) attaches to \(a_3b_3\).
Note 217's interval criterion makes the
parent three-connected; the 32-vertex legal
site expansion is Barnette by its cut map.
The two paths of a marked Hamilton cycle are
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,
L_1,c_3,e_4,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,a_2,b_2,
e_2,o_3,a_3,b_3,e_3,o_4,u,v.
\end{split}                                           \tag{7}
\]
They share only \(x,v\) and cover all
28 vertices. \(\square\)

The theorem requires the defect budget to
be saturated and the block intervals to be
disjoint. Overlapping defects, spare vacant
positions within defect groups, gap slots,
and nonsquare residual cycles remain open
under this method. It does not settle
Barnette's conjecture.
