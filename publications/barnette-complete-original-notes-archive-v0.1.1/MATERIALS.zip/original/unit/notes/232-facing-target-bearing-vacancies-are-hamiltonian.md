> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Facing target-bearing vacancies have marked Hamilton cycles

[Note 215](215-separated-vacancies-compose-marked-hamilton-routes.md)
handles distinct vacancy blocks when an occupied target
separates them. [Note 223](223-two-target-free-vacancies-in-one-group-always-have-a-marked-hamilton-cycle.md)
handles a shared free group when both vacancy blocks are
target-free. The next shared group has occupied runs on
its two outer sides. The same-square sweep of
[Note 231](231-dispersed-target-runs-between-same-block-vacancies-are-hamiltonian.md)
absorbs its only matching that leaves an alternating
vacancy square under the canonical old-cycle matching.

Work in a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, tight target order,
and exactly two eligible vacancies. They lie in distinct
face blocks \(B_k,B_m\), \(1\le k<m\le r\). The vacancy
in \(B_k\) is its last eligible position and follows
at least one occupied target pair. The vacancy in
\(B_m\) is its first eligible position and precedes
at least one occupied target pair. No occupied target
lies between the two vacancies. Hence the intervening
\(t=m-k-1\ge0\) face blocks are short and target-free.
Writing \(h_L,i_L\) and \(h_R,i_R\) for the vacant
even slot and following odd slot, the complete free
group between the two occupied runs is
\[
h_L,i_L,e_L,
(o_1,e_1),\ldots,(o_t,e_t),
o_R,h_R,i_R.                                       \tag{1}
\]
For \(t=0\), \(e_L,o_R\) are consecutive ordinary
ports from the two vacancy blocks.

**Facing-vacancy theorem.** Every such parent has a
Hamilton cycle through both site edges \(xy,uv\), and
its legal site-expanded child is Hamiltonian. The result
holds for any other occupied target runs and arbitrary
positive original lobe lengths.

**Free matching classification.** Let
\(P_j=(E_j,O_j)\), \(0\le j\le t\), be the ordinary
standard links from \(e_L\) to \(o_R\). For \(t\ge1\),
\[
P_0=(e_L,o_1),\quad
P_j=(e_j,o_{j+1})\ (1\le j<t),\quad
P_t=(e_t,o_R),                                    \tag{2}
\]
and for \(t=0\) put \(P_0=(e_L,o_R)\).
The matching on (1) is exactly one of the following:
\[
\begin{array}{ll}
\text{nested:}&
\{P_j:0\le j\le t\}\cup
\{h_Li_R,i_Lh_R\};\\[2pt]
\text{one detour }a:&
\{P_j:j\ne a\}\cup
\{h_Li_R,i_LE_a,O_ah_R\},
\quad1\le a\le t-1;\\[2pt]
\text{two detours }a<b:&
\{P_j:j\notin\{a,b\}\}\cup
\{i_LE_a,h_LO_a,i_RE_b,h_RO_b\},
\quad1\le a<b\le t-1.
\end{array}                                           \tag{3}
\]
Empty index ranges mean that the corresponding type
does not occur.

To prove (3), first close the free group. Every
free-slot prefix before an occupied target run has
even size: each earlier vacancy contributes two slots
to the ordinary even prefix. A cross-block free chord cannot straddle
the target by Note 203. In the left vacancy block,
only its first free odd slot lies before the occupied
run; in the right vacancy block, only its final free
even slot lies after the occupied run. Thus at most
one same-block free chord could cross either run.
The same bound holds in all other blocks. Matching
parity excludes every such chord, so the occupied
runs are barriers and (1) is closed under the
free matching.

No two slots of any one block in (1) can be matched:
their opposite-colour pairs are old-cycle edges.
All free matching chords in (1) therefore join
different blocks, lie opposite the site face by
Note 193, and do not interlace. An edge between
two ordinary slots other than a link \(P_j\) would
enclose a complete short-block interval, or run
backward around complete blocks. Noncrossing would
make that interval matching-closed, leaving only
two old-cycle boundary edges. Three-connectivity
excludes this, as in Note 220. Hence every
ordinary-to-ordinary edge is standard.

Let \(c\) be the number of edges among the four
extra slots \(h_L,i_L,h_R,i_R\). The pairs
\(h_Li_L,h_Ri_R\) are old-cycle edges, so
\(c\in\{0,1,2\}\). If \(c=2\), colour and
the old-cycle exclusions force the nested pair
\(h_Li_R,i_Lh_R\), with all \(P_j\) present.
If \(c=1\), the inner candidate \(i_Lh_R\)
would force the remaining \(h_L,i_R\) to the
ends of one missing link \(P_a\). The chords
\(h_LO_a,E_ai_R\) interlace, so this candidate
is impossible. The outer candidate \(h_Li_R\)
instead forces \(i_LE_a,O_ah_R\). The values
\(a=0,t\) would use the old-cycle edges
\(i_Le_L\) or \(o_Rh_R\), respectively,
giving the middle row of (3).

If \(c=0\), exactly two standard links
\(P_a,P_b\), \(a<b\), are missing. The
leftmost extra slot \(h_L\) cannot match
\(O_b\): noncrossing would leave both
ends of \(P_a\) inside that chord with
only \(i_L\) available to match them.
Thus \(h_LO_a\) occurs. The edge
\(i_LE_b\) would interlace it, so
\(i_LE_a\) is forced. The remaining
edges are \(h_RO_b,i_RE_b\). Again
\(a=0\) or \(b=t\) would use an old-cycle
edge. This is the last row of (3).

**Hamilton routes.** Other free groups follow the
standard chain. For one detour in (3), replace
the ordinary free-path link \(E_aO_a\) by
\[
E_a,i_L,h_L,i_R,h_R,O_a.                         \tag{4}
\]
For two detours, replace its links \(E_aO_a\)
and \(E_bO_b\) by, respectively,
\[
E_a,i_L,h_L,O_a
\quad\text{and}\quad
E_b,i_R,h_R,O_b.                                   \tag{5}
\]
The outer edges of each replacement belong
to the complementary matching, and
\(i_Lh_L,i_Rh_R\) are old-cycle edges.
Each route visits all free slots once.
Together with Note 196's unchanged
target-and-square path, it gives a
Hamilton cycle through \(xy,uv\).

In the nested case, all ordinary links are
standard and the two vacant pairs lie in
the same target-free interval from some
\(R_j\) to \(L_j\). Construct the paths
\(T_j\) and the same-square sweep (4)--(6)
of Note 231. Within the exceptional interval,
the sweep follows
\[
R_j,\ldots,h_L,i_L,e_L,
o_1,e_1,\ldots,o_R,h_R,i_R,
\ldots,L_j,
\tag{6}
\]
using old-cycle edges inside blocks and
standard links between them. It does
not need the two nested matching edges.
The sweep and the exposed-face path
partition all vertices and form another
Hamilton cycle containing \(xy,uv\).
Notes 001 and 178 give the legal child
and longer original lobes. \(\square\)

**A realized nested profile.** Let
\(\ell=3,r=2,k=1,m=2,t=0\). Take the
old cycle in consecutive blocks
\[
\begin{array}{ll}
B_0:&x,R_3,e_0,y,\\
B_1:&a_1,o_1,L_3,R_2,h_L,i_L,e_L,b_1,\\
B_2:&a_2,o_R,h_R,i_R,L_2,R_1,e_R,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2,3),\text{ returning to }x.
\end{array}                                           \tag{7}
\]
Add the complementary matching
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
          \delta_jR_j:1\le j\le3\}\\
&\cup\{e_0o_1,e_Lo_R,e_Ro_3,
         h_Li_R,i_Lh_R\}.
\end{split}                                           \tag{8}
\]
All pairs have opposite old-cycle parity.
Draw the site, face, and \(\alpha_j\beta_j\)
chords on one side of the old cycle.
The escape chords form the nested chain
\(R_3\delta_3\supset L_3\gamma_3
\supset R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1\)
on the other side. The three standard
free links occupy disjoint gaps, while
\(h_Li_R\supset i_Lh_R\supset e_Lo_R\)
is another nested subchain between
\(R_2\delta_2\) and \(L_2\gamma_2\).
Thus the 36-vertex parent is plane,
simple, cubic, bipartite, and has
cofacial \(xy,uv\).

Its matching-chord interlacement graph
is connected: the cycle of alternations
\[
\begin{split}
xy&-e_0o_1-a_1b_1-e_Lo_R-a_2b_2-e_Ro_3-uv
-L_1\gamma_1-\alpha_1\beta_1-R_1\delta_1-a_2b_2\\
&-L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-a_1b_1
-L_3\gamma_3-\alpha_3\beta_3-R_3\delta_3-xy
\end{split}                                           \tag{9}
\]
contains every chord except \(h_Li_R,i_Lh_R\),
which both interlace \(a_1b_1\). Note 217's
interval criterion makes the parent three-connected;
its cut projection makes the 40-vertex site
expansion Barnette. The two paths of its marked
Hamilton cycle are
\[
\begin{split}
&x,y,a_1,b_1,a_2,b_2,u,v,\\
&x,\beta_3,\delta_3,R_3,e_0,o_1,L_3,\gamma_3,\alpha_3,
\beta_2,\delta_2,R_2,h_L,i_L,e_L,o_R,h_R,i_R,
L_2,\gamma_2,\alpha_2,\beta_1,\delta_1,R_1,e_R,o_3,
L_1,\gamma_1,\alpha_1,v.
\end{split}                                           \tag{10}
\]
They cover all 36 vertices and share only \(x,v\).
\(\square\)

The theorem covers facing vacancies in two occupied
face blocks with no intervening occupied target.
It does not decide arbitrary vacancy positions in
target-bearing blocks, outer-block vacancies,
target-order defects, gaps, nonsquare residual
cycles, or Barnette's conjecture in general.
