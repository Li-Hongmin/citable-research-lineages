> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A fixed common-\(B\) unique crossing can have no rooted triangle

[Note 152](152-root-square-crossing-edges-can-be-bridges.md) left a narrow
possible explanation for the compensation seen in
[Note 151](151-a-common-b-face-can-have-exactly-one-rooted-crossing.md):
after a common gate-face edge \(f\) is released, perhaps the unique crossing
in the fixed-\(f\) rooted fibre must acquire a rooted common neighbour. This
is false, even in a simple plane cubic bipartite brace with the required
root square and legal-wide gate geometry.

## 1. The brace and its rooted fibre

Let \(G\) be the graph with graph6 encoding

~~~text
W???????????w?s?P_BC?Go?B_?B_?@o?GW?B@??_W?A__?
~~~

It has \(24\) vertices and \(36\) edges. Direct verification shows that it
is simple, plane, cubic, bipartite and \(3\)-connected. It has \(244\)
perfect matchings, and every one of its \(558\) pairs of independent edges
extends to a perfect matching. Thus \(G\) is a brace.

Use the facial square, in cyclic order,

\[
Q=(6,15,2,16)
\]

with root and forced gate

\[
e=6\!-\!15,\qquad g_0=2\!-\!16.
\]

The other gate is

\[
g_1=4\!-\!14,
\]

and \(g_0,g_1\) lie on the common facial cycle

\[
F=(0,12,2,16,7,18,9,20,4,14).
\]

The two closed \(g_0\)-to-\(g_1\) arcs of \(F\) have cardinalities \(7\)
and \(5\), so the decoration is legal-wide.

Deleting \(Q\) exposes the four attachments

\[
6\mapsto17,\quad15\mapsto1,\quad2\mapsto12,\quad16\mapsto7.
\]

Let \(\mathcal T_e\) be the complete family of perfect matchings which
contain \(e,g_0\) and whose complement after this deletion consists of two
spanning paths with endpoint pairs

\[
(17,7)\mid(1,12).
\]

Independent enumeration gives

\[
|\mathcal T_e|=15,
\]

split as \(9+6\) according to whether \(g_1\) is present.

## 2. A unique fixed-face crossing

Take the two rooted targets

\[
\begin{aligned}
M=\{&0\!-\!13,1\!-\!12,2\!-\!16,3\!-\!22,4\!-\!14,5\!-\!23,\\
    &6\!-\!15,7\!-\!17,8\!-\!19,9\!-\!18,10\!-\!20,11\!-\!21\},\\
N=\{&0\!-\!13,1\!-\!12,2\!-\!16,3\!-\!22,4\!-\!21,5\!-\!14,\\
    &6\!-\!15,7\!-\!17,8\!-\!19,9\!-\!18,10\!-\!20,11\!-\!23\}.
\end{aligned}
\]

Their symmetric difference is the alternating cycle

\[
4-14-5-23-11-21-4,
\]

and \(g_1\in M\setminus N\). On \(F\), starting at \(g_0\), their joint
incidence word is

\[
\boxed{\mathtt{B00B00M000}}.
\]

In particular, their face XOR is exactly \(\{g_1\}\), while

\[
f=9\!-\!18
\]

is a second common-\(B\) edge. Exactly three members of
\(\mathcal T_e\) contain \(f\). In the single-alternating-cycle exchange
graph induced by those three members, \(MN\) is the unique edge crossing
the \(g_1\)-coordinate cut.

## 3. No triangle appears when \(f\) is released

Build the complete single-cycle exchange graph on all fifteen members of
\(\mathcal T_e\). It has \(22\) edges, ten of which cross the
\(g_1\)-coordinate cut. Nevertheless,

\[
\Gamma(M)\cap\Gamma(N)=\varnothing.
\]

Hence there is no rooted target \(P\), even without requiring \(f\notin P\),
such that both \(M\triangle P\) and \(N\triangle P\) are single alternating
cycles. This proves the following.

> **No-triangle counterexample.** In the legal-wide root-square class of
> simple plane cubic bipartite braces, a crossing can be unique after one
> additional common gate-face edge is fixed and can still have no rooted
> common exchange neighbour after that edge is released.

Thus common-\(B\) occupancy, common perfect-matching incidence, and the
complete rooted exchange graph do not force the theta completion proposed
after Note 152. The original cardinality problem

\[
\Gamma_{g_1}(\mathcal T_e)\ne\varnothing
\quad\Longrightarrow\quad
|E\Gamma_{g_1}(\mathcal T_e)|\ne1
\]

is not contradicted: this complete fibre has ten crossings. A proof of
that implication must therefore couple different crossings or occupancy
classes globally; it cannot assign a triangle completion to each
fixed-face unique crossing.

The fixed
[verification bundle](../computations/bundles/fixed-common-b-no-rooted-triangle/README.md)
reconstructs the full perfect-matching and rooted families directly from
the graph6 string. Its terminal marker is
FIXED_COMMON_B_NO_ROOTED_TRIANGLE_VERIFIED.
