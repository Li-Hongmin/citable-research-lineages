> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An adjacent-vacancy square is absorbed by a five-edge detour

[Note 215](215-separated-vacancies-compose-marked-hamilton-routes.md)
handles vacancies separated by occupied escape targets. In one
free group, two vacancies can instead link their four new slots
into a square disjoint from the canonical \(M\cup A\) Hamilton
route. That square has a direct absorption route through the
old-cycle edges of its two blocks.

Let \(G,C,M\) be a compressed all-square Barnette opening with
gapless, tight target order and \(\ell,r\ge1\). Suppose its two
eligible vacancies lie in adjacent, target-free internal face
blocks \(B_k,B_{k+1}\), each with four free interiors in
old-cycle order
\[
 B_k:\ o_k,h_k,i_k,e_k,\qquad
 B_{k+1}:\ o_{k+1},h_{k+1},i_{k+1},e_{k+1}.
\tag{1}
\]
Assume the free part of \(M\) is the ordinary block chain
\(\{e_j o_{j+1}:0\le j\le r\}\), together with
\[
 h_k i_{k+1},\qquad i_k h_{k+1}.
\tag{2}
\]
The listed edges form a perfect matching of all free slots.

**Square-absorption theorem.** The parent \(G\) has a Hamilton
cycle containing both site edges \(p,q\); consequently its
legal site-expanded child is Hamiltonian. The conclusion
persists when the original square-trap lobes have arbitrary
positive lengths.

**Proof.** Let \(A\) be the even-starting old-cycle matching
from \(x\). Tight target order gives Note 196's square-and-target
\(x\)-to-\(v\) path (4). The ordinary block chain gives its
free \(x\)-to-\(v\) path (5) on all remaining vertices except
\(h_k,i_k,h_{k+1},i_{k+1}\). Since
\(h_ki_k,h_{k+1}i_{k+1}\in A\), the two extra matching
edges (2) make those four vertices a separate alternating
square in \(M\cup A\).

Replace the free path's edge \(e_ko_{k+1}\) by
\[
 e_k,\ i_k,\ h_k,\ i_{k+1},\ h_{k+1},\ o_{k+1}.
\tag{3}
\]
The first two and last two edges of (3) are old-cycle
edges inside the two vacant blocks; its middle edge
\(h_k i_{k+1}\) belongs to \(M\). The six vertices
of (3) are distinct, and its four internal vertices
were precisely the four missed by the ordinary free
path. Thus this replacement yields one spanning
\(x\)-to-\(v\) free path. Joined to the disjoint
square-and-target path, it forms one Hamilton cycle
through \(xy,uv\). Note 001 lifts that marked cycle
through the legal site expansion, and Note 178
restores the original lobe lengths. \(\square\)

This route covers the matching profile (2). It does not
classify all matchings when two vacancies share a free
group; in particular no universal Hamilton conclusion
at \(f=4r+6\) follows from it.
