> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A plane-brace common-cycle counterexample leaves rooted cell-restricted cyclability

[Note 134](134-a-two-row-type-support-countermodel-isolates-the-actual-matching-incidence-gap.md)
shows that finite type consistency does not force child supplementation.
The first actual-graph repair one might try is alternating-cycle closure in
a brace: start from a state-\(11\) matching, put the two site edges and the
surviving gate on one alternating cycle, and flip that cycle to create a
new-cell matching.  This note proves that even the unlabelled common-cycle
premise is false for a plane cubic brace whose standard child is again a
brace.

The result does not refute the rooted split-bond lemma of
[Note 108](108-kill-cover-supplementation-is-exactly-a-rooted-split-bond-lemma.md).
It closes the route that tries to derive that lemma from ordinary brace
cyclability.

## 1. What brace closure actually supplies

Fix a perfect matching \(M\) of a bipartite graph \(G\).  Contract every
edge of \(M\), and orient each remaining edge from its endpoint in one
bipartition class to its endpoint in the other.  Denote the resulting
matching digraph by \(D_M\).  Simple \(M\)-alternating cycles of \(G\)
are exactly directed simple cycles of \(D_M\).

If \(G\) is a brace, then \(D_M\) is strongly \(2\)-connected.  Indeed,
for \(S\) in one bipartition class, the brace Hall inequality

\[
 |N_G(S)|\ge |S|+2
 \tag{1}
\]

is equivalent to saying that the corresponding vertex set of \(D_M\)
has at least two out-neighbours outside itself.  This is equivalent to
strong connectivity after deletion of any one vertex.

Consequently any two edges of \(M\) lie on a common \(M\)-alternating
cycle.  If a state-\(11\) matching contains the two site edges \(p,q\),
flipping such a cycle produces a matching avoiding both.  In the expanded
graph this gives an unlabelled \(R_{00}\) perfect matching.

This is only unary occupancy.  The canonical \(C_{11}\) extension is
never root-admissible, because its central complement component is
isolated.  A supplementing child bond must instead join two
root-admissible cells among

\[
 \mathcal C=\{C_{00},C_{10},C_{01}\},
 \qquad
 \mathcal N=\{R_{00},X_{uy},X_{vx}\},
 \tag{2}
\]

with at least one endpoint in \(\mathcal N\), subject to the fourteen
attachment rows of [Note 114](114-all-new-cell-rooted-bonds-have-four-attachment-obstruction-types.md).
Thus a cycle through \(p,q\) alone cannot prove supplementation.

## 2. An explicit plane brace

Let indices lie in \(\mathbb Z_3\).  Define a digraph \(D_0\) on

\[
 \{a_i,b_i,c_i:i\in\mathbb Z_3\}
 \tag{3}
\]

with arcs

\[
 a_i\to a_{i+1},\qquad b_i\to b_{i+1},\qquad
 a_i\leftrightarrow c_i,\qquad b_i\leftrightarrow c_i.
 \tag{4}
\]

Every vertex has indegree and outdegree two.  Deleting any \(c_i\) leaves
the two directed triangles joined by the other two bidirected channels.
Deleting an \(a_i\) or \(b_i\) leaves the opposite directed triangle, to
which every remaining vertex is joined through a surviving channel.
Hence \(D_0\) is strongly \(2\)-connected.

Apply the inverse matching-digraph construction: replace every vertex
\(v\) by a matching edge \(x_vy_v\), and every arc \(u\to v\) by
\(x_uy_v\).  The resulting graph \(G\) has \(18\) vertices and \(27\)
edges and is cubic, bipartite and \(2\)-extendable by (1).

It is planar.  A face system consists of two hexagons

\[
\begin{aligned}
&x_{a_0}y_{a_1}x_{a_1}y_{a_2}x_{a_2}y_{a_0},\\
&x_{b_0}y_{b_0}x_{b_2}y_{b_2}x_{b_1}y_{b_1},
\end{aligned}
\tag{5}
\]

the six squares

\[
x_{a_i}y_{a_i}x_{c_i}y_{c_i},
\qquad
x_{b_i}y_{c_i}x_{c_i}y_{b_i},
\tag{6}
\]

and the three hexagons

\[
x_{a_i}y_{c_i}x_{b_i}y_{b_{i+1}}x_{c_{i+1}}y_{a_{i+1}}.
\tag{7}
\]

Every edge occurs twice with opposite orientations and
\(18-27+11=2\), so (5)--(7) give a spherical embedding.  Therefore
\(G\) is a plane cubic brace.

## 3. The three-mark obstruction

Use the perfect matching

\[
\begin{aligned}
M=\{&x_{a_i}y_{a_i}:i=0,1,2\}\cup
\{x_{b_i}y_{b_i}:i=0,1\}\cup
\{x_{c_i}y_{c_i}:i=0,1\}\\
&\cup\{x_{b_2}y_{c_2},x_{c_2}y_{b_2}\}.
\end{aligned}
\tag{8}
\]

Take the cofacial site edges and gate

\[
p=x_{a_1}y_{a_1},\qquad
q=x_{a_2}y_{a_2},\qquad
g=x_{c_2}y_{c_2}.
\tag{9}
\]

The square

\[
x_{b_2}y_{c_2}x_{c_2}y_{b_2}x_{b_2}
\tag{10}
\]

is \(M\)-alternating, contains \(g\), and avoids \(p,q\).  Flipping it
gives a second perfect matching that still contains both site edges.
Thus (10) is a genuine local \(C_{11}\)--\(C_{11}\) gate-changing bond.

Nevertheless no \(M\)-alternating simple cycle contains all three of
\(p,q,g\).  In \(D_M\), the two site edges are vertices \(A_1,A_2\),
while \(g\) is an arc \(T\to S\).  A cycle through that arc becomes a
simple \(S\)-to-\(T\) path after the arc is removed.  Any nontrivial such
path must start \(S\to B_0\) and end \(B_1\to T\).  After removing
\(S,T\), a path through both site vertices must contain

\[
A_1\to A_2\to A_0.
\tag{11}
\]

But every simple route from \(B_0\) to \(A_1\) that has not already ended
at \(B_1\) is forced to contain

\[
B_0\to C_0\to A_0\to A_1.
\tag{12}
\]

Equations (11)--(12) repeat \(A_0\), a contradiction.

The standard \(C_4\)-expansion at \(p,q\) is planar, cubic and bipartite.
Its matching digraph for the canonical extension of \(M\) remains strongly
connected after deletion of any vertex, so the child is also a brace.  The
finite checks of the face system, all independent two-edge extensions,
the sixteen fixed-\(M\) alternating cycles, and the child brace property
are frozen in the
[supporting bundle](../computations/bundles/brace-common-cycle-route-counterexample/README.md).

Hence

\[
\boxed{
\begin{gathered}
G\text{ and its standard child are plane cubic braces, and a genuine}\\
C_{11}\text{--}C_{11}\text{ gate-changing bond exists, but no single}\\
M\text{-alternating cycle contains }p,q,g.
\end{gathered}}
\tag{13}
\]

## 4. Remaining actual incidence

The counterexample has no root labels and does not assert the global
ParentKill predicate.  It therefore does not refute the rooted split-bond
lemma.  Its exact consequence is that ordinary brace closure, even with a
real cofacial site and a brace child, cannot prove the missing incidence in
Note 134.

The correct remaining condition is **rooted, cell-restricted gate
cyclability**: there must exist a root-admissible child matching \(F\) and
a directed simple cycle in \(D_F\) through the surviving-gate mark such
that the flipped matching is also root-admissible and the two local cells
form one of the fourteen allowed pairs from Note 114.  This condition
simultaneously includes new-cell occupancy and the attachment obstructions
\(\mathsf O,\mathsf F_0,\mathsf F_1,\mathsf F_2\).

Notes 132--134 can encode and transport that incidence once it occurs.
The present counterexample proves that it cannot be replaced by an
unlabelled common-cycle theorem for braces.
