> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two J1 double blocks across a short corridor have the square signature

[Note 331](331-every-j1-double-vacancy-with-single-block-neighbours-forces-a-square-chain.md)
classifies a single \(J_1\) doubly vacant block amid singly vacant
and short blocks. Here two \(J_1\) blocks supply one another's
free-slot mates. The short corridor between them has a unique
matching, and its induced four-pole is again square-equivalent.

Let a Barnette parent have the compressed, gapless, tight-target
all-square opening of [Note 324](324-every-distinct-internal-vacancy-in-a-tight-square-opening-is-marked-hamiltonian.md).
Fix a target-free free group with ordinary even left and odd
right endports. Its only multiply vacant complete blocks are
\[
D=(a,O,H,I,K,J,E,b),\qquad
D'=(A,O',H',I',K',J',E',B),                         \tag{1}
\]
in that order. Both are doubly vacant and carry their internal
\(J_1\) chords \(OK,O'K'\). Every other complete block of
this group is short, and no singly vacant block occurs. There
may be arbitrarily many short blocks before, between and after
\(D,D'\).

**Two-double-block classification.** At least one short block
lies between \(D\) and \(D'\). Write this corridor as
\(S_j=(c_j,o_j,e_j,d_j)\), \(1\le j\le k\), where
\(k\ge1\). Independently of all flank matching choices,
the complete matching inside the block interval from \(D\)
through \(D'\), apart from its four exterior attachments,
is forced to be
\[
OK,\quad O'K',\quad HI',\quad IH',\quad
Je_k,\quad Eo_1,\quad e_jo_{j+1}\ (1\le j<k),
                                                               \tag{2}
\]
together with all face-closing chords \(ab,c_jd_j,A B\).
The resulting induced \(16+4k\)-vertex four-pole \(Q_k\)
has terminals \((a,J',E',B)\). Its complete spanning
one-path and two-path Hamilton linkage signature equals
that of a square with these cyclically ordered terminals.
Replacing \(Q_k\) by that labeled square, or conversely,
preserves Barnette membership and every exterior-marked
Hamilton decision. Consequently a vertex-minimal
non-Hamiltonian Barnette graph contains no induced \(Q_k\).
If every vacancy outside this interval lies in a distinct
internal block, the parent has a Hamilton cycle through both
site edges and its legal site-expanded child is Hamiltonian.
The old-cycle reflection gives the analogous \(J_3\) result.

**Proof that the matching is forced.** Note 327's
chord-isolation lemma puts \(OK,O'K'\) on the common-face
side and excludes all other internal free chords of these
two blocks. Every cross-block free chord is on the opposite
side by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
For such a chord, remove the endpoints of common-face chords
leaving its interior; the number of remaining interior free
slots must be even. A nonempty proper consecutive interval
of complete blocks matched entirely within itself would
give a forbidden two-edge cut.

The even slot \(H\) cannot match within \(D\): \(I\) is
its old-cycle neighbour, \(J\) is excluded, \(O,K\) are
used, and \(E\) has the same colour. A chord from \(H\)
to an ordinary odd slot before \(D\) encloses that short
block's final even slot, complete short blocks, and \(O\).
A chord to an ordinary odd slot between the double blocks
encloses \(I,K,J,E\) and complete short blocks. A chord
to an ordinary odd slot after \(D'\), or to the right
endport, encloses these four slots, complete short blocks,
and all six free slots of \(D'\). Each interior has even
size and just one face-side exit, from \(OK\); \(O'K'\)
is wholly inside or outside. The same count for \(HJ'\)
encloses \(I,K,J,E\), the short corridor, and
\(O',H',I',K'\), with only the \(OK\) exit. Thus the only
possible mate of \(H\) is \(I'\), and \(HI'\) occurs.

The even slot \(H'\) has no mate within \(D'\). A chord
to an ordinary odd slot before \(D\) encloses that short
block's final even slot, all six free slots of \(D\),
the corridor, and \(O'\). A chord to a short-block odd
slot in the corridor encloses its final even slot, later
complete short blocks, and \(O'\). A chord to an ordinary
odd slot after \(D'\), or the right endport, encloses
\(I',K',J',E'\) and complete short blocks. In each case
the interior is even with exactly one exit from \(O'K'\);
\(OK\) is wholly inside or outside. The chord \(JH'\)
encloses \(E\), the corridor and \(O'\), with the same
single exit. Hence \(H'\) must match \(I\), giving
\(IH'\). These two opposite-side chords are nested:
\(H<I<H'<I'\).

The chord \(IH'\) encloses \(K,J,E\), all corridor
slots, and \(O'\). The first and last slots match
\(O,K'\) across its boundary by the two common-face
chords. Every other enclosed slot must match another
inside \(IH'\), so \(J,E,o_1,e_1,\ldots,o_k,e_k\)
form a noncrossing perfect-matching interval. For \(k=0\),
the only possible pair would be \(JE\), an old-cycle
edge, so \(k\ge1\).

The odd slot \(J\) must match some \(e_j\); \(JE\) is
an old-cycle edge. If \(j<k\), the suffix
\(S_{j+1},\ldots,S_k\) lies outside \(Je_j\) but inside
\(IH'\) and must match wholly within itself. It would
give a two-edge cut. Hence \(Je_k\) is forced. Within
this chord, the even slot \(E\) must match some \(o_j\).
If \(j>1\), the prefix \(S_1,\ldots,S_{j-1}\) is
matching-closed, again impossible. Thus \(Eo_1\) occurs.
The same noncrossing and two-edge-cut argument successively
forces \(e_jo_{j+1}\) for \(1\le j<k\). This proves (2).
All vertices of the induced interval now have degree three
except \(a,J',E',B\), which each have one exterior edge.

**Proof of the signature.** Define two vertex sequences
for the corridor:
\[
\begin{split}
C_k^+&=(o_1,c_1,d_1,e_1,o_2,c_2,d_2,e_2,
              \ldots,o_k,c_k,d_k,e_k),\\
C_k^0&=(c_1,o_1,e_1,d_1,c_2,o_2,e_2,d_2,
              \ldots,c_k,o_k,e_k,d_k).
\end{split}                                                \tag{3}
\]
Successive groups in \(C_k^+\) join by the forced
\(e_jo_{j+1}\) matching edges, while \(C_k^0\) is the
old-cycle corridor path. The terminal colours are
\(a,E'\) on one side and \(J',B\) on the other.
The four permitted spanning one-path pairs all occur:
\[
\begin{array}{c|l}
aB & \text{the full old-cycle path through }Q_k\\
aJ'& a,b,E,C_k^+,J,K,O,H,I,H',I',K',O',A,B,E',J'\\
J'E'&J',K',I',H,O,a,b,E,C_k^+,J,K,I,H',O',A,B,E'\\
E'B&E',J',K',I',H,O,a,b,E,C_k^+,J,K,I,H',O',A,B.
\end{array}                                                \tag{4}
\]
Each displayed sequence visits every patch vertex once;
successive pairs are old-cycle, face-closing, or (2) edges.

The two noninterlacing spanning two-path pairings also occur.
For \(\{aJ',E'B\}\), use the old-cycle path from \(a\)
through \(J'\) and the single edge \(E'B\). For
\(\{aB,J'E'\}\), use the edge \(J'E'\) and the path
\[
a,O,H,I',K',O',H',I,K,J,E,b,C_k^0,A,B.               \tag{5}
\]
The third pairing \(\{aE',J'B\}\) interlaces the
four boundary terminals in the disk and is impossible.
Thus the signature is exactly the square's. A global
Hamilton cycle meets the four-edge patch cut in two or
four edges; replace its spanning patch path or path pair
by the equal-signature route on the other side. This
works in both directions and retains all exterior edges.

**Barnette realizations and class preservation.** For every
\(k\ge1\), give an old Hamilton cycle the order
\[
x,R_1,w,y,D,S_1,\ldots,S_k,D',u,o_3,L_1,v,
\alpha,\gamma,\delta,\beta,x.                          \tag{6}
\]
Add the complementary perfect matching formed by the
face-side chords
\[
xy,\ ab,\ c_jd_j\ (1\le j\le k),\ A B,\ uv,\
\alpha\beta,\ OK,\ O'K',                             \tag{7}
\]
and the opposite-side chords
\[
\delta R_1,\ \gamma L_1,\ wJ',\ E'o_3,\ HI',\ IH',\
Je_k,\ Eo_1,\ e_jo_{j+1}\ (1\le j<k).                \tag{8}
\]
The two lists cover every vertex once; each edge joins
opposite old-cycle parities and is not an old-cycle edge.
The face-side chords are disjoint or nested. On the other
side, \(\delta R_1\) contains the other chords;
\(wJ'\) contains the nested \(HI'\supset IH'\),
\(IH'\) contains \(Je_k\supset Eo_1\) and the
disjoint chain \(e_jo_{j+1}\); \(E'o_3,\gamma L_1\)
lie to the right of \(wJ'\). Hence the graph is simple,
cubic, bipartite and plane. The outer common-face boundary
contains both site chords \(xy,uv\); \(R_1,L_1\) are the
tight targets of the residual square
\(\alpha\gamma\delta\beta\alpha\).

Its matching-chord interlacement graph is connected. A
spanning set of alternations is
\[
\begin{gathered}
xy-wJ'-AB-HI'-ab-IH'-OK,\qquad HI'-O'K',\\
ab-Je_k-c_kd_k-e_{k-1}o_k-c_{k-1}d_{k-1}-\cdots-
e_1o_2-c_1d_1-Eo_1,\\
AB-E'o_3-uv-\gamma L_1-\alpha\beta-\delta R_1.
\end{gathered}                                             \tag{9}
\]
When \(k=1\), the middle chain is simply
\(ab-Je_1-c_1d_1-Eo_1\). Each dash in (9) is endpoint
alternation in (6). Any two-edge cut in a cubic Hamiltonian
graph would be a proper old-cycle interval closed under the
matching, which would separate this interlacement graph.
The old Hamilton cycle excludes bridges, so the graph is
three-edge-connected and therefore three-vertex-connected
in the cubic case. It is a Barnette graph with an induced
\(Q_k\). An explicit Hamilton cycle through both site
edges is the union of the two \(x\)--\(v\) paths
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,w,J',K',I',H,O,a,b,E,C_k^+,J,K,I,H',O',A,B,E',
o_3,u,v.
\end{split}                                               \tag{10}
\]

For the two-way Barnette reduction, the terminal colours
of \(Q_k\) and the square agree. Contract the connected
old-cycle path from \(a\) through \(K'\), retaining
\(J',E',B\). The edges \(K'J',J'E',E'B,AB\) then give
the labeled square as a planar minor. Conversely, the
two-page disk drawing of \(Q_k\) inserts it on the empty
side of a square with connected exterior. Deleting one
vertex from \(Q_k\) leaves it connected: each block
cycle remains connected, the consecutive corridor cycles
retain at least one of their old-cycle and matching joins,
the first short block retains at least one of \(bc_1,Eo_1\),
and \(D,D'\) retain at least one of \(HI',IH'\).
Deleting any two patch vertices leaves no component
without a surviving terminal, because such a component
would disconnect the explicit three-connected realization
(6)--(8). The same four-attachment, connected-exterior
deletion argument as in Note 330 therefore proves
three-connectivity in both replacement directions.
Cubicity and simplicity follow from the four distinct
terminals. This proves the class equivalence. \(\square\)

For the marked-opening consequence, compress the forced
\(Q_k\) to its square. Its old-cycle segment and contiguous
common-face block arc become one short target-free block;
the \(J',E'\) attachments keep their opposite-side order.
All remaining vacancies, under the extra hypothesis, lie
in distinct internal blocks. Note 324 supplies a Hamilton
parent cycle through both site edges, (4)--(5) lift it,
and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal child's Hamilton cycle. Reflection proves
the \(J_3\) version.

The theorem concerns exactly two multiply vacant target-free
blocks, both carrying \(J_1\), with only short blocks
elsewhere in their ordinary free group. It does not classify
other internal chord types, a singly vacant block in the
same group, a third multiply vacant block, target-bearing
terminal vacancies, positive gaps, defective target order,
nonsquare residual cycles, or the general Barnette conjecture.
This is a project-internal analytic proof without an
external priority claim or independent review.
