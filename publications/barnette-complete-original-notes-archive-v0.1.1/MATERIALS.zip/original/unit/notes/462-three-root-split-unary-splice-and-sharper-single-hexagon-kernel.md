> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The split-unary three-root splice and a sharper single-hexagon kernel

[Notes 458–461](461-disconnected-root-face-matchings-close-the-split-unary-kernel.md) leave a two-edge cut in a leaf-switch quotient when the two special positions assigned to one nonleaf unary node straddle its child. The four exterior vertices of the chord-free hexagon opening absorb the cycle on the far side of that cut. The argument does not depend on the number of leaves or the lengths of their ordinary wrappers.

## Three-root split-unary theorem

Let a Barnette parent with a legal cofacial site have the chord-free single-hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md):
\[
 C=(w_0,t_d,W_1,t_c,W_2,t_b,W_3,t_a,w_*,
       \alpha,a,b,c,d,\beta,w_0),
\tag{1}
\]
with escape edges \(t_dd,t_cc,t_bb,t_aa\), trap chord \(\alpha\beta\), and site edges \(q=w_0u,p=vw_*\), where \(u<v\) are special positions in the three root words. Suppose all assigned special positions except two occur in pairs at distinct ordinary leaves. The exceptional positions \(s,t\) are assigned directly to one marked unary node \(N\), in the order
\[
                         H,s,A,t,J,
\tag{2}
\]
where \(A\) is its sole child word. There is no bound on the number of leaves or ordinary wrappers.

**Theorem.** The parent has a Hamilton cycle containing both \(p,q\). Consequently its legal \(C_4\)-expanded child is Hamiltonian.

**Proof.** Write \(L,R\) for the ends of \(A\), and let \(D=C_1\cup C_2\cup C_3\) be the three disjoint cycles in (2) of Note 456. Each two-special leaf has a square-supported old edge; denote their set by \(E\). Let \(M\) be the face-side matching of all assigned special positions other than \(u,v\). If the root face graph \(K\) is disconnected, the proof of the disconnected-root theorem in [Note 461](461-disconnected-root-face-matchings-close-the-split-unary-kernel.md) applies verbatim: its cut and crossing argument puts \(u,v\) in an isolated end root; its two openings (2) and (3) yield a spanning internal \(u\)--\(v\) path, and Note 456's exterior path closes it. That proof uses only (1)–(2), the two-special leaves, and three-connectivity, not a leaf count.

Suppose \(K\) is connected. Form
\[
 F=(D-E-\{sL,Rt\})\cup M\cup\{LR\}
\tag{3}
\]
and let \(Q\) contract its components, with edges \(E\cup\{sL,Rt\}\). As proved in Note 461, \(F\) has one \(u\)--\(v\) path and some cycles; \(Q\) is connected and even-degree. If \(Q-\{sL,Rt\}\) is connected, square switches at its leaf edges absorb every cycle into the marked path. The outside path \((u,w_0,\beta,\alpha,w_*,v)\) closes a Hamilton cycle through \(p,q\).

Otherwise \(Q-\{sL,Rt\}\) has exactly two components, because \(Q\) is connected and bridgeless. One contains the \(u\)--\(v\) path of \(F\), and the other contains only cycles. All its leaf edges are square-switchable when nonloops. Switch along a spanning tree in each component. The result is a spanning \(u\)--\(v\) path \(P\) and a disjoint spanning cycle \(Z\); the switches do not touch any escape edge of \(C_1,C_3\). Equivalently, before switching, \(F\cup E\) consists of precisely two cycles. Call the side containing \(Z\) *unmarked*.

If \(Z\) contains \(C_1\)'s edge \(t_dd\), delete that edge. The two paths
\[
                         (u,w_0,t_d),\qquad
                         (d,\beta,\alpha,w_*,v)
\tag{4}
\]
cover the four vertices outside \(D\), use \(q,p\), and join \(P\) to \(Z-t_dd\) as one Hamilton cycle. If \(Z\) contains \(C_3\)'s edge \(t_aa\), use instead \(Z-t_aa\) and
\[
                         (u,w_0,\beta,\alpha,a),\qquad
                         (t_a,w_*,v).
\tag{5}
\]
Thus only a putative unmarked side containing neither end escape edge needs exclusion.

The two end cycles \(C_1,C_3\) can be split by \(sL,Rt\) only when \(N\) lies in their respective root word. The middle cycle \(C_2\) can likewise split only when \(N\subset W_2\). In the split root, the two removed edges separate the child interval \(A=[L,R]\) from its complementary arc \(B\), and \(LR\) closes \(A\). Every other root cycle remains whole. Since \(F\cup E\) has two cycles, its unmarked cycle is assembled from \(A\) or \(B\), together with zero or more whole other root cycles, using only \(M\)-edges. The site positions \(u,v\) belong to the marked side.

If the unmarked side is \(A\) alone, no matching edge leaves \(A\), no site edge ends there, and every ordinary chord incident with \(A\) stays inside \(A\). Its only edge-cut edges in the parent are \(sL,Rt\), contrary to three-connectivity. If \(N\subset W_1\), the complementary arc \(B\) contains \(t_dd\); if \(N\subset W_3\), it contains \(t_aa\). Therefore the only additional unmarked sides without an end escape edge are
\[
  A\cup C_2\quad(N\subset W_1\text{ or }W_3),
  \qquad B\quad(N\subset W_2).
\tag{6}
\]

Take \(N\subset W_1\) and the side \(A\cup C_2\). Connectedness of this side requires a face chord \(xy\in M\) with \(x\in A\) and \(y\in W_2\). Let \(S\) be the part of \(W_1\) after \(A\), beginning at \(t\). No site position lies in \(S\): if \(u\in S\), \(w_0<x<u<y\) makes \(q\) cross \(xy\); if \(v\in S\), \(x<v<y<w_*\) makes \(p\) cross \(xy\). A face chord from \(S\) to the part of \(W_1\) before \(A\), or to \(W_3\), would also cross \(xy\). A chord to \(A\) or \(W_2\) would join the two sides of \(F\cup E\). Hence every face-matching edge incident with \(S\) stays in \(S\). But \(S\) contains \(t\) and otherwise only complete two-special leaves, so it has an odd number of matching positions and cannot be internally matched. For \(N\subset W_3\), reflect the order: a chord from \(W_2\) to \(A\) isolates the prefix of \(W_3\) ending at \(s\), which has the same odd count. Both cases are impossible.

Finally take \(N\subset W_2\) and the unmarked side \(B\) alone. Its portions before and after \(A\) each contain one of \(s,t\) and otherwise complete two-special leaves. Neither contains \(u,v\), so each has an odd number of positions to be matched by \(M\). As no \(M\)-edge leaves \(B\), some face chord \(xy\) joins its two portions and encloses \(A\). If \(u\in A\), \(q=w_0u\) crosses \(xy\); if \(v\in A\), \(p=vw_*\) crosses \(xy\). Thus neither site position lies in \(A\). A face chord from \(A\) to \(B\) would join the two sides, while a chord from \(A\) to an end root would cross the enclosing chord \(xy\). Every ordinary chord incident with \(A\) is internal. Hence \(A\) again has only \(sL,Rt\) in its edge cut, contradicting three-connectivity.

Every possible unmarked side therefore has an end escape edge, and (4) or (5) supplies the marked Hamilton cycle. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the expanded child. \(\square\)

## Augmented root connectivity with any number of roots

The connected-\(K\) part of the all-leaf argument extends beyond three roots. Suppose every assigned special position lies in a two-special leaf of some ordinary root, the four escape targets are ordered \(t_d<t_c<t_b<t_a\), and each of the two intervals \((t_d,t_c)\), \((t_b,t_a)\) contains at least one root and no other nonroot main vertex. Any further roots may lie before, between, or after these intervals. Let \(J\) be the graph on the roots obtained from the face matching graph \(K\) by also joining consecutive roots inside either target-pair interval. If \(J\) is connected, the parent has a Hamilton cycle through \(p,q\).

Indeed, close the old main path from \(t_d\) to \(t_c\) by \(t_cc,cd,dt_d\), and close the path from \(t_b\) to \(t_a\) by \(t_aa,ab,bt_b\). Close every root outside these paths with its outer ordinary chord. These vertex-disjoint cycles cover the parent except \(w_0,w_*,\alpha,\beta\). Their union with the face matching is connected exactly when \(J\) is connected. The two-terminal square-switch theorem of Note 458 yields a spanning \(u\)--\(v\) path, and \((u,w_0,\beta,\alpha,w_*,v)\) closes it. This proves the statement without restricting the number of roots or leaf wrappers.

## Kernel consequence

For a non-Hamiltonian doubly ladder-reduced single-hexagon child with \(f\ge7\) extra common-face-side chords, the chorded case already satisfies \(c\le5f-6\) by [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md). In the chord-free case, the charge and escape restrictions of [Notes 457–458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) leave \(c=5f-6\) only when \(m=f+1,R=3\). The all-leaf profile is Hamiltonian by Note 458. In the other equality profile, the refined charge forces \(M_0=m,L=m-1\), every marked node receives two positions, and equality in \(c\le3A-Q\) forces the one marked nonleaf to be unary rather than branching. If its two positions are adjacent, [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md) closes it. If they straddle its child, the theorem above closes it. Therefore
\[
 \boxed{\ c\le5f-7\quad(e=4),\qquad
          |V(\bar G^+)|=18+2f+2c\le4+12f\ }.
\tag{7}
\]
The same \(4+12f\) order bound holds for \(e=2\) by Note 460. More precisely, after the three-root theorem, \(m=f+1,R=3\) cannot give a non-Hamiltonian child with \(c>5f-8\): the all-leaf and single-unary profiles are Hamiltonian, while every remaining profile has \(M_0+L\le2m-2\) in the refined charge. Thus equality \(c=5f-7\) in the chord-free bound (7) requires \(m=f+1,R=4\) and \(M_0=L=m\): all assigned positions are paired in leaves. Their four targets occupy distinct gaps around the four roots, so the augmented-root theorem above closes the case when \(J\) is connected.

In particular, a selected single-hexagon opening with \(f=8\) cannot yield a 102-vertex reduced failure; any such failure has at most 100 reduced vertices. At the 100-vertex chord-free boundary, the only remaining profile has four all-leaf roots and disconnected augmented root graph \(J\). The chorded 100-vertex profile and all smaller kernels remain undecided here. These bounds are necessary conditions, not a Hamiltonicity decision for Barnette graphs in general.
