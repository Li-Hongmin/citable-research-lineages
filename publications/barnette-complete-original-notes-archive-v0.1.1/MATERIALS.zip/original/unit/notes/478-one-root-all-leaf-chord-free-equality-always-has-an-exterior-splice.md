> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-root all-leaf chord-free equality always has an exterior splice

[Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md) lists one root with \(m=f-1\) and every assigned special position in a two-special ordinary leaf as its first chord-free \(c=5f-8\) equality profile. The four exposed special positions and four escape targets have only three possible orders in a hypothetical failure. Each order has a spanning exterior path cover, and the leaf-square switches join it to one Hamilton cycle.

Use the chord-free single-hexagon order of [Note 457](457-single-hexagon-failures-have-at-most-six-plus-twelve-f-vertices.md), with escape targets \(t_d<t_c<t_b<t_a\) matched to \(d,c,b,a\), trap chord \(\alpha\beta\), site edges \(q=w_0u,p=vw_*\), and one ordinary root word \(W\). Exactly four assignable special positions lie outside \(W\); call them \(z_1<z_2<z_3<z_4\). Every assigned special position in \(W\) belongs to a two-special leaf, with arbitrary ordinary wrappers.

**Single-root theorem.** The legal expanded child is Hamiltonian. More precisely, the parent has a Hamilton cycle containing both \(p,q\).

**Three outside orders.** If two escape targets are adjacent on the old main arc, the adjacent-escape merger of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) already makes the child Hamiltonian. Otherwise, between any consecutive escape targets on the same side of \(W\) there must be at least two exposed special positions: zero gives adjacent escape targets, and one gives equal old-cycle colours to targets whose hexagon neighbours have opposite colours, as in Note 457. Four targets distributed between the two flanks require at least four such positions. Since exactly four are available, the target split is \(3+1,2+2\), or \(1+3\), and all exposed positions occupy the required gaps. Up to reflection, the first two orders are
\[
\begin{array}{ll}
\mathrm A:&w_0,t_d,z_1,z_2,t_c,z_3,z_4,t_b,W,t_a,w_*,\\
\mathrm B:&w_0,t_d,z_1,z_2,t_c,W,t_b,z_3,z_4,t_a,w_* .
\end{array}
\tag{1}
\]
The third order \(\mathrm C\) is the reflection of \(\mathrm A\):
\[
      w_0,t_d,W,t_c,z_1,z_2,t_b,z_3,z_4,t_a,w_* .
\tag{2}
\]

**The site ports lie in \(W\).** Index \(w_0\) by zero on the old Hamilton cycle. Bipartiteness makes \(u\) odd-indexed and \(v\) even-indexed. The exposed-position parities in A, B, C are respectively
\[
               (0,1,1,0),\qquad(0,1,0,1),\qquad(1,0,0,1)
               \pmod 2 .
\tag{3}
\]
In A, an outside \(u\) could only be \(z_2\) or \(z_3\). In either case \(z_1\) has no possible third-edge mate: \(z_1z_2\) is an old edge, \(z_1z_4\) joins equal colours, and every remaining candidate is later than \(u\), so its face chord from \(z_1\) would cross \(q=w_0u\). Hence \(u\in W\), and then \(v\in W\) because every outside position is before \(W\).

In B, the only outside candidate for \(u\) before \(W\) is \(z_2\), again leaving \(z_1\) unmatched; the only odd candidate after \(W\) is \(z_4\), after which no site position remains for \(v\). Thus \(u\in W\). The only outside candidate for \(v\) after \(W\) is \(z_3\); its successor \(z_4\) can neither use the old edge \(z_3z_4\) nor match an earlier position without crossing \(p=vw_*\). Hence \(v\in W\).

In C, an outside \(u\) could be \(z_1\) or \(z_4\). The latter leaves no later site position. If \(u=z_1\), then \(v=z_2\) or \(z_3\). The first pair is adjacent on the old facial arc, so the one-edge-gap switch of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md) makes the child Hamiltonian. For \(v=z_3\), the last exposed position \(z_4\) has no mate: a chord to \(W\) crosses \(q\), a chord to \(z_2\) crosses \(p\), and the other exposed positions are site ports. Thus a hypothetical failure has \(u\in W\). If \(v=z_2\) or \(z_3\) while \(u\in W\), the same last-position argument using \(p\) leaves \(z_4\) unmatched. Therefore \(v\in W\). It suffices to construct a marked parent Hamilton cycle with both site ports in \(W\).

**Outside matching endpoints.** All four \(z_i\) are now face-matching endpoints. In A their parities are even, odd, odd, even. The only possible internal face chord among them is \(z_1z_3\) or \(z_2z_4\): the within-gap pairs are old edges, the other noncrossing pairing joins equal colours, and both candidate chords cannot occur together because they cross. Thus either all four \(z_i\) have mates in \(W\), or exactly two do. In B, an internal \(z_i z_j\) is impossible: within-gap pairs are old edges, the two cross-gap pairs of opposite colours span \(W\) and cross \(q=w_0u\), and the remaining pairs join equal colours. Hence all four \(z_i\) have mates in \(W\). Reflection gives the analogous alternatives in C.

**Exterior paths in A.** In every A case take
\[
                   P_0=(u,w_0,\beta,\alpha,a,t_a,w_*,v).
\tag{4}
\]
It contains both site edges, the trap chord \(\beta\alpha\), and the escape edge \(at_a\). The following paths cover every other vertex outside \(W\); their listed \(z\)-endpoints are precisely the \(z_i\) whose face chords go to \(W\):
\[
\begin{array}{c|l}
\text{outside face matching}&\text{additional paths}\\\hline
\text{all four }z_i\text{ meet }W&
 (z_2,t_c,z_3),\quad
 (z_4,t_b,b,c,d,t_d,z_1)\\
z_1z_3&
 (z_2,t_c,z_3,z_1,t_d,d,c,b,t_b,z_4)\\
z_2z_4&
 (z_1,t_d,d,c,b,t_b,z_4,z_2,t_c,z_3).
\end{array}
\tag{5}
\]
Unmarked steps are old-cycle edges. The steps \(t_dd,t_bb\) in the long paths are escape edges, and the displayed \(z_1z_3,z_2z_4\) steps are the corresponding face chords. Every outside vertex occurs once.

**Exterior paths in B.** Take
\[
\begin{aligned}
 P_0&=(u,w_0,\beta,\alpha,w_*,v),\\
 P_L&=(z_1,t_d,d,c,t_c,z_2),\\
 P_R&=(z_3,t_b,b,a,t_a,z_4).
\end{aligned}
\tag{6}
\]
These three disjoint paths cover all vertices outside \(W\), include both site edges, and end at \(u,v,z_1,z_2,z_3,z_4\). Their non-old steps are the trap chord and four escape edges. Reflect (4)–(5) for C.

**Leaf-square closure.** In any row of (5) or (6), include the face chords joining the listed \(z\)-endpoints to their mates in \(W\). Let \(T_W\) be these mates together with \(u,v\), let \(E_W\) be the old adjacent-special edge in every two-special leaf of \(W\), and let \(M_W\) match every other leaf special position within \(W\). The graph
\[
 F=\bigl(C_W-E_W\bigr)\cup M_W
       \cup\{\text{listed exterior paths and their attachment chords}\}
\tag{7}
\]
is a spanning union of cycles containing \(p,q\): every \(T_W\)-vertex loses its leaf old edge and gains one exterior edge, and every other leaf special position loses that edge and gains its \(M_W\)-edge. Each exterior path, including its attachment chords, is a subdivided pairing edge between two distinct vertices of \(T_W\); its internal vertices lie outside \(W\). Restoring \(E_W\) makes \(F\cup E_W\) connected, because it contains the root cycle \(C_W\) and every exterior path attaches to it. The proof of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) applies unchanged to these subdivided pairing edges: every nonloop quotient edge from \(E_W\) has a disjoint ordinary leaf-square switch. Switch along a quotient spanning tree to merge all cycles into a Hamilton cycle without changing either site edge. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the child. \(\square\)

**Boundary consequence.** The \(m=f-1,R=1,M_0=L=f-1\) row of Note 477 is Hamiltonian for every \(f\ge7\), independently of the ordinary wrapper lengths. Hence a non-Hamiltonian chord-free child at \(c=5f-8\) can belong only to the other three rows of that note. This does not decide their realizability or Hamiltonicity.
