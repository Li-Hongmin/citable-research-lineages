> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Full Hamilton-family saturation does not force a good bridge

The simultaneous target-tree/rooted-two-bond assertion isolated in
[Note 026](026-joint-good-bridge-selection-is-a-target-tree-rooted-bond-problem.md)
is false. There is a plane cubic bipartite brace with global \(H^{+-}\)
whose complete Hamilton-complement family contains genuine targets and
compatible bridges at a legal site, but no target is compatible with a
bridge on both rooted sides.

The same example also shows that this failed selection principle is not
necessary for \(C_4\)-preservation. Expanding its obstructed site produces
another brace with global \(H^{+-}\). The child property is carried by a
distributed family of all six traversal types, and every complete type
family is essential.

## A critical square surgery

Begin with the order-\(22\) brace from Note 026,

```text
U?????????[?s?b??[?CoI_?L??_o?`_@_G?@W??
```

and expand the four-face

\[
(1,20,2,11)
\]

at the legal oriented site

\[
(20,2,11,1).
\tag{1}
\]

Thus the edges \(20\,2\) and \(11\,1\) are deleted, four new vertices
\(22,23,24,25\) are installed, and the eight new edges are

\[
\begin{gathered}
20\,22,\ 22\,23,\ 23\,2,\qquad
11\,24,\ 24\,25,\ 25\,1,\\
22\,25,\ 23\,24.
\end{gathered}
\tag{2}
\]

The resulting order-\(26\) graph \(F\) has graph6 string

```text
Y?????????S?s?b??[?CoI_?L??_o?`_@?G?@W????@C??@?@?@O??A_
```

and retains the legal site

\[
(u,v,z,a)=(16,2,20,10),\qquad p=16\,2,\quad h=20\,10.
\tag{3}
\]

One containing facial orientation is

\[
(16,2,23,22,20,10,15,6).
\tag{4}
\]

Direct checks show that \(F\) is simple, connected, cubic, bipartite,
planar, and 3-connected. It has \(253\) perfect matchings, and every pair
of vertex-disjoint edges extends to one of them. Hence \(F\) is
2-extendable and is a brace.

## The complete-family counterexample

Exactly \(44\) perfect matchings of \(F\) have connected complementary
2-factors. This is the complete Hamilton-complement family, and it realizes
global \(H^{+-}\) on all \(39\cdot38\) ordered pairs of distinct edges.

At the site (3), the four \((p,h)\)-membership layers have sizes

\[
(|V_{00}|,|V_{01}|,|V_{10}|,|V_{11}|)
=(34,2,4,4).
\tag{5}
\]

There are \(12\) near-perfect matchings \(T\) for which

\[
F-\{p,h\}-T
\]

is a Hamilton \(v\)-\(z\) path, and there are \(28\) compatible bridges

\[
L-W-R,\qquad
L\in V_{01},\quad W\in V_{00},\quad R\in V_{10},
\tag{6}
\]

whose two consecutive symmetric differences are single alternating cycles.
Nevertheless, among all \(34\cdot12=408\) pairs \((W,T)\), not one admits
an exchange cycle avoiding \(T\setminus W\) on both rooted sides.
Equivalently, the complete common-complement test of Note 026 fails for
all \(28\) bridges.

Thus this is a genuine graph/site counterexample, not a deleted-family or
abstract incidence model:

\[
\boxed{
\text{global }H^{+-}
\not\Longrightarrow
\text{simultaneous target-tree/rooted-two-bond selection}.}
\tag{7}
\]

In the dual formulation, every target forest makes at least one of the two
rooted exchange-cycle families a transversal. Exhaustiveness of the
Hamilton family does not prevent this one-sided obstruction.

## Multi-component three-witness rescue

The counterexample kills single-cycle adjacency, not the underlying
three-Hamilton-witness common-complement mechanism. Drop the requirement
that \(L\triangle W\) and \(W\triangle R\) are each one cycle, but retain

\[
L\in V_{01},\qquad W\in V_{00},\qquad R\in V_{10}
\tag{8}
\]

and the exact common-complement condition

\[
T\setminus W\subseteq E(F)\setminus(L\cup W\cup R).
\tag{9}
\]

Among all \(2\cdot34\cdot4=272\) triples in (8), exactly \(24\) admit at
least one target satisfying (9), for a total of \(30\) triple--target
incidences. If the two symmetric differences have \(i\) and \(j\)
alternating components, respectively, their incidence distribution is

\[
\begin{array}{c|rrrrrrr}
(i,j)&(1,2)&(1,3)&(2,1)&(2,2)&(2,3)&(3,2)&(3,3)\\ \hline
\text{incidences}&10&3&1&4&6&3&3.
\end{array}
\tag{10}
\]

Thus the sharp first repair is a \((1,2)\)-component bridge. The missing
\((1,1)\) entry is exactly the failed good-bridge assertion. This finite
example does not prove that a bounded multi-component bridge always exists,
but it changes the surviving proof interface: a positive argument may use
several alternating components on one side without abandoning the
three-witness common complement.

## The obstructed site still preserves global \(H^{+-}\)

Now expand \(F\) at the very site (3). The resulting order-\(30\) graph
\(H\) is again simple, cubic, bipartite, planar, 3-connected, and
2-extendable. It has

\[
552\text{ perfect matchings},\qquad
84\text{ Hamilton-complement matchings},
\tag{11}
\]

and its complete Hamilton family realizes global \(H^{+-}\) on all
\(45\cdot44\) ordered pairs of distinct edges.

Classify those \(84\) Hamilton cycles by their incidence on the eight new
gadget edges, using the six traversal types of Notes 001 and 015. Their
exact type distribution is

\[
\boxed{
(|\mathcal H_A|,|\mathcal H_B|,|\mathcal H_C|,
 |\mathcal H_D|,|\mathcal H_E|,|\mathcal H_L|)
=(34,2,4,12,8,24).}
\tag{12}
\]

Every type family in (9) is essential in the following strict sense:
after deleting all Hamilton cycles of any one of the six types, at least
one ordered pair of child edges is no longer separated. Hence the
preservation certificate cannot be compressed to the failed common-middle
bridge. It is genuinely distributed across the six concrete traversal
families.

## Consequence

Equation (7) closes the full-family neighbour-saturation route proposed in
Note 026. The exact transversal and target-tree quotient reductions in that
note remain valid, but their final universal implication does not.

The order-\(30\) child supplies the complementary boundary:

\[
\boxed{
\text{a good bridge is neither forced by global }H^{+-}
\text{ nor necessary for this }C_4\text{-child to retain }H^{+-}.}
\tag{13}
\]

The surviving general problem is therefore the distributed preservation
interface of Notes 015--016: prove the two mixed decorated covers and the
retained--retained separation condition directly from the complete actual
traversal families, or find a genuine child violating one of them. The
example does not refute preservation of global \(H^{+-}\) under arbitrary
legal \(C_4\)-expansion and does not refute Barnette's conjecture.

[Note 029](029-multicomponent-three-witnesses-reduce-to-hall-plus-tree-quotient.md)
removes the single-cycle restriction and shows exactly what survives: a
triple must first pass Hall in a restricted graph and then hit a tree state
inside the same perfect-matching fibre. In this example both failures occur,
while the first successful repair requires two simultaneous alternating-cycle
flips.

The self-contained certificate is reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/verify_full_family_good_bridge_counterexample.py
```

with terminal marker

```text
FULL_FAMILY_GOOD_BRIDGE_COUNTEREXAMPLE_VERIFIED
```
