> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Integral two-point paid-exit deficits discharge through order eighteen

[Note 047](047-two-point-one-rank-violations-reduce-to-a-binary-paid-exit-deficit.md)
shows that direct repair of a two-point rank violation can fail only when
the paid-exit cost \(\rho_A(R,W)\) exceeds the binary slack
\(|A|-c_A(R)\).  Such deficits are not hypothetical: they already occur in
the cube and become numerous at larger orders.  Nevertheless every integral
deficit in an actual brace through order eighteen can be discharged inside
the one-block common-base exchange graph, and no instance needs more than two
additional block changes after the boundary completion.

## Exchange graph and finite theorem

Fix an actual ordered legal site and let \(\mathcal B\) be its family of
\(X\)-partition/graphic common bases.  Define a graph \(\Gamma\) on
\(\mathcal B\) by joining two bases when they differ only by replacing the
selected label in one \(X\)-block.  Both endpoints of an edge of \(\Gamma\)
are spanning trees of the contracted rank graph \(Q\).

Let \(R\) be an integral \(X\)-block transversal whose unique violated
graphic-rank inequality is indexed by a two-point shore \(W\), and suppose

\[
 c_A(R)\le |A|.
\tag{1}
\]

Complete the boundary shifts of Note 047 until the \(W\)-row is satisfied;
write \(\mathcal C(R,W)\subseteq\mathcal B\) for all bases obtainable in
this way.

> **Finite discharge theorem.**  For every actual brace of order at most
> eighteen, if
> \[
> \rho_A(R,W)>|A|-c_A(R),
> \tag{2}
> \]
> then some \(B_0\in\mathcal C(R,W)\) lies in a component of \(\Gamma\)
> containing a base \(B\) with \(c_A(B)\le|A|\).  Moreover
> \[
> \min_{B_0\in\mathcal C(R,W)}
> \operatorname{dist}_{\Gamma}
> \bigl(B_0,\{B:c_A(B)\le|A|\}\bigr)\le2.
> \tag{3}
> \]

This is a complete finite theorem, not a sample of selected transversals.

## Structural normal form

An integral unique two-point violation has a particularly rigid selected
rank multigraph.  The two vertices of \(W\) form an isolated double edge,
and the selected labels on \(V(Q)\setminus W\) form a tree.  Indeed, any
selected edge from \(W\) to an exterior vertex would also violate the
three-point shore obtained by adjoining that vertex.  Three selected
internal labels would give the same contradiction.  Since a transversal
contains \(|V(Q)|-1\) labels, the exterior forest then has exactly one
component.

It follows that the excess is exactly one.  For binary costs, every direct
deficit has the forced profile

\[
 \rho_A(R,W)=1,\qquad |A|-c_A(R)=0.
\tag{4}
\]

Thus the finite problem is not obscured by larger knapsack values: it asks
whether a single paid boundary exit can subsequently be discharged inside
the correct common-base component.

## Complete coverage

The five actual braces through order eighteen have \(616\) ordered legal
sites in \(42\) automorphism orbits.  Site automorphisms biject the block
transversals, rank shores, binary layers, boundary completions, and exchange
graphs, so one representative of each orbit suffices.  The exact coverage
is

\[
\begin{array}{l|r|r}
&\text{orbit representatives}&\text{unquotiented}\\\hline
X\text{-block transversals }R&56\,136&700\,848\\
(R,W)\text{ with unique two-point violation}&338&4\,064\\
(R,W,A)\text{ satisfying (1)}&44\,160&517\,752\\
\text{paid-exit deficits satisfying (2)}&2\,470&29\,104.
\end{array}
\tag{5}
\]

For each deficit, every boundary completion was enumerated.  A multi-source
breadth-first search from all bases of cost at most \(|A|\) then computed
the exact minimum in (3).  The unquotiented distribution is

\[
\begin{array}{c|rr}
\text{distance in (3)}&1&2\\\hline
\text{instances}&28\,760&344.
\end{array}
\tag{6}
\]

The deficit counts by graph order are

\[
 48,\ 360,\ 8\,560,\ 20\,136
\tag{7}
\]

at orders \(8,12,16,18\), respectively.  No deficit lies in a component
without a low-cost base, and no through-eighteen instance has distance three.

## Smallest and sharpest routes

The smallest deficit occurs in the cube at site

\[
 (u,v,z,a)=(0,4,1,5).
\]

With

\[
 R=\{17,24,36\},\qquad W=\{1,2\},\qquad A=\{6,7\},
\]

one has \(c_A(R)=|A|=2\) and \(\rho_A(R,W)=1\).  The boundary shift
\(24\mapsto26\) gives the full base

\[
 B_0=\{17,26,36\},\qquad c_A(B_0)=3.
\]

One further exchange discharges the cost:

\[
 \{17,26,36\}\longrightarrow\{14,26,36\},
 \qquad 3\longrightarrow2=|A|.
\tag{8}
\]

Distance two first occurs in the order-sixteen brace

\[
 \texttt{O????B\_sCWKOI\_BOAW?i?}
\]

at site \((0,9,3,15)\).  Take

\[
\begin{aligned}
W&=\{1,4\},\\
R&=\{19,28,39,4\,12,5\,13,6\,12,7\,13\},\\
A&=\{8,10,11,12,13\}.
\end{aligned}
\]

Again \(c_A(R)=|A|=5\) and \(\rho=1\).  The boundary completion obtained
from \(19\mapsto18\) has cost six, and a shortest route is

\[
\begin{aligned}
&\{18,28,39,4\,12,5\,13,6\,12,7\,13\}\\
\longrightarrow{}&
\{18,28,39,4\,10,5\,13,6\,12,7\,13\}\\
\longrightarrow{}&
\{18,28,39,4\,10,5\,13,6\,12,7\,14\}.
\end{aligned}
\tag{9}
\]

All three states are \(Q\)-trees, with costs \(6,6,5\).

## Connected exchange is not sufficient abstractly

The six-label row--column countermodel of Note 044 also has a sharp
interpretation in the present language.  Let the \(X\)-blocks be

\[
\begin{aligned}
D_1&=\{e_0=12,e_1=12\},\\
D_2&=\{e_2=12,e_3=23\},\\
D_3&=\{e_4=34,e_5=13\},
\end{aligned}
\tag{10}
\]

and partition the same labels on the \(Y\)-side as

\[
 C_0=\{e_3,e_4\},\qquad
 C_1=\{e_0,e_2\},\qquad
 C_2=\{e_1,e_5\}.
\tag{11}
\]

This is the elementary \(C_6\) row--column incidence.  Give the labels in
\(C_0\) unit cost and the others zero.  Then

\[
 R=\{e_1,e_2,e_4\}
\]

has cost one and uniquely violates \(W=\{1,2\}\).  Its only removable
boundary shift is \(e_2\mapsto e_3\).  The full common bases are exactly

\[
 \{e_0,e_3,e_4\},\qquad
 \{e_1,e_3,e_4\}.
\tag{12}
\]

They are adjacent in the one-block exchange graph, so that graph is
connected, but both bases have cost two.  Thus connectivity of
\(\Gamma\), the fundamental-cut exchange criterion, the exact local block
types, and the two partition marginals do not imply discharge.  This model
is not an actual legal brace site: it fails the common planar joint rotation.
Any general proof must use that ambient completion information to rule out
the strict \(C_6\) pattern, rather than proving exchange connectivity alone.

## Remaining boundary

The finite theorem gives strong actual-incidence evidence for the integral
paid-exit discharge problem, but it does not prove a uniform distance bound
or even component reachability at arbitrary order.  It also does not treat
fractional one-hole points or shores of size three and four.  A general
proof must explain why some boundary completion cannot be trapped in
common-base components whose minimum \(A\)-cost is too large; a counterexample
must first realize such a component separation in one common primal--dual
rotation.

The complete check is reproduced by

    uv run --python 3.12 --with networkx \
      units/barnette/computations/verify_integral_paid_exit_discharge_through_order_eighteen.py

with terminal marker INTEGRAL_PAID_EXIT_DISCHARGE_VERIFIED_THROUGH_18.
