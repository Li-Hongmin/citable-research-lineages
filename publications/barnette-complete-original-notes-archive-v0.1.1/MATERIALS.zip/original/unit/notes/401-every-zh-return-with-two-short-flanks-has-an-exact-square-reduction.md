> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every \(zh\) return with two short flanks has an exact square reduction

[Note 396](396-two-short-flanks-reduce-outside-one-boundary-branch.md)
reduces the \(sI\) and last-short \(sp_m\) returns of the
\(hz\) branch to a rainbow double block and excludes \(sO\).
[Note 398](398-every-right-short-js-return-has-an-exact-square-reduction.md)
reduces \(sJ\) at every length, while
[Note 400](400-every-si-return-with-two-short-flanks-has-an-exact-square-reduction.md)
reduces \(si\). The earlier \(sp_j\) returns contain a simpler
left pole: their opening chords force the reflected cube fold
already identified in Notes 315 and 392.

Use the selected compact, gapless, tight-target all-square
opening and consecutive block order
\[
 S_0=(c,p,q,d),\quad V=(a,o,h,i,e,b),\quad
 S_k=(c_k,p_k,q_k,d_k)\ (1\le k\le m),\quad
 D=(A,O,H,I,K,J,E,B),\quad T=(C,r,s,F),\qquad m\ge1.
\tag{1}
\]
Let \(M\) be the complementary matching and suppose
\(tp,qo,hz\in M\). The two flank blocks are exactly
\(S_0,T\), while the intermediate short corridor has
positive length \(m\). All cross-block free chords lie
opposite the selected common face and do not interlace.
A nonempty proper interval of complete blocks cannot be
matching-closed, since its only boundary edges would be
the two old-cycle edges.

**Complete \(hz\)-return theorem.** Every actual matching
under (1) and \(tp,qo,hz\in M\) contains an induced disk
four-pole strictly larger than a square, with precisely
the square's four spanning one-path and two spanning
two-path Hamilton states. Replacing the pole by its
labeled square, or reversing the replacement, preserves
Barnette membership and every exterior- and
attachment-marked Hamilton decision. In particular,
no vertex-minimal non-Hamiltonian Barnette graph has
this selected \(hz\) return.

The only case not previously reduced is \(sp_j\in M\)
with \(1\le j<m\). The case \(j=1\) is impossible.
For every actual case with \(2\le j<m\), the matching
necessarily contains
\[
 ep_1,\qquad iq_{j-1},\qquad
 q_kp_{k+1}\quad(1\le k<j-1).                            \tag{2}
\]
Consequently the induced interval
\(P=V\cup S_1\cup\cdots\cup S_{j-1}\) is exactly
the square-equivalent four-pole with terminals
\((a,o,h,d_{j-1})\) proved in Notes 315 and 392.

**Forced left pole.** The chord \(p_js\) lies opposite
the common face and encloses every free slot from
\(q_j\) through \(r\). The even slot \(e\), lying
before \(p_j\), can meet only a short-block odd slot
\(p_k\) with \(k<j\). Its other possible mates
\(O,I,J,r\), as well as \(p_k\) for \(k\ge j\),
lie strictly inside \(p_js\), so any such cross-block
chord would interlace \(p_js\). The other earlier
slots are matched already, have the wrong colour, or
are old-cycle neighbours of \(e\). Thus \(j=1\)
leaves \(e\) without a mate and is impossible.

For \(j\ge2\), suppose \(ep_k\) with \(k>1\).
The chord encloses the complete short-block run
\(S_1,\ldots,S_{k-1}\); no cross-block matching
edge can leave this run without crossing \(ep_k\)
or \(p_js\). The run would be matching-closed,
a forbidden two-edge cut. Hence \(ep_1\in M\).

The odd slot \(i\) can now meet only \(q_k\) with
\(k<j\). Its other colour-compatible mates in
the group lie strictly inside \(p_js\), so an
opposite-side chord from \(i\) to any of them
would interlace \(p_js\). Write \(iq_k\in M\).
If \(k<j-1\), the complete run
\(S_{k+1},\ldots,S_{j-1}\) lies between \(iq_k\)
and \(p_js\). A chord from this run to the left
would interlace \(iq_k\), while a chord to the
right would interlace \(p_js\). The run would
be matching-closed. Therefore \(iq_{j-1}\in M\).

For \(j=2\), no short slot remains. For \(j>2\),
the remaining free slots of \(S_1,\ldots,S_{j-1}\)
are \(q_1,p_2,q_2,\ldots,q_{j-2},p_{j-1}\). Their
matching is forced successively: if the leftmost \(q_k\)
skipped \(p_{k+1}\) to meet a later \(p_v\), then
\(S_{k+1},\ldots,S_{v-1}\) would be a nonempty
matching-closed complete interval. Thus every
ordinary link in (2) occurs.

**Exact replacement.** The pole \(P\) has internal
matching edges exactly (2), besides its old-cycle
edges and the face chords \(ab,c_kd_k\). Its four
and only four exterior edges are the old-cycle
edges at \(a,d_{j-1}\) and the matching edges
\(oq,hz\), with distinct attachment vertices.
For \(j=2\), \(P=V\cup S_1\) is the old-cycle
reflection of the ten-vertex cube-fold patch of
[Note 315](315-port-owned-vacancy-folds-by-a-cube-reduction.md).
Its four one-path and two two-path states are the
square's six states; the fold and inverse cube
expansion preserve the Barnette class and all
exterior Hamilton marks. For \(j>2\), the induced
ordinary-link corridor \(S_1\cup\cdots\cup S_{j-1}\)
is the even-column four-terminal ladder of
[Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
Compress it to one square, retaining its four
labeled attachment edges, then apply the reflected
cube fold. Both steps have the exact square routing
signature and preserve Barnette membership in both
directions, as spelled out for precisely these
internal edges and terminals in
[Note 392](392-every-one-left-flank-tj-single-double-corridor-has-an-exact-square-reduction.md).
The exterior mate of \(h\) is now \(z\), but the
four-pole comparison depends only on distinct
attachments and its internal edges. This proves
the \(sp_j\) branch. The cases \(sO,sI,sJ,si,sp_m\)
are exhausted by Notes 396, 398, and 400, proving
the theorem. \(\square\)

The theorem closes the \(hz\) return only within
the specified two-short-flank selected opening.
The \(zK\) branch still has a spanning group route
but no proved full square signature; other group
shapes and openings remain outside this result.
Barnette's conjecture is not decided. This is an
internal analytic proof without local graph
recomputation, independent review, or a literature
priority claim.
