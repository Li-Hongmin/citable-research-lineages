> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Exact matching and decorated boundary for \(C_4\)-preservation of global \(H^{+-}\)

## 1. The preservation question

Let \(G\) be a Barnette graph with the global \(H^{+-}\)-property. Let

\[
p=uv,\qquad q=xy
\]

be a legal \(C_4\)-expansion site, with cyclic order
\(u,v,\ldots,x,y,\ldots\) on the common face, and let \(H\) be the child.
Write

\[
R=G-\{p,q\}.
\]

Note 013 proves that \(H\) is always \(P_2\)-Hamiltonian and has \(H^-\).
The stronger assertion that \(H\) again has global \(H^{+-}\) remains
undecided. This note gives an exact matching formulation of its first
missing structures and an exact set-cover formulation of the two mixed
ordered-edge blocks. These one-edge decorated conditions do not settle the
retained--retained block: [Note 016](016-retained-edge-pairs-require-joint-decorated-traversals.md)
gives its additional exact two-edge condition and a strict incidence
obstruction to recovering it from the marginals below.

For a perfect matching \(M\) of \(G\), the complement \(G-M\) is a
2-factor. Thus the parent global \(H^{+-}\)-property is equivalently:

> For every ordered pair of distinct edges \((e,f)\), there is a perfect
> matching \(M\) such that \(f\in M\), \(e\notin M\), and \(G-M\) is one
> Hamilton cycle.

This statement concerns ordinary perfect matchings with connected
complement. The missing \(C_4\)-interfaces require different matching
families.

## 2. Exact matching form of \(D,E,L\)

Use the traversal notation

\[
D=X_{vx},\qquad E=X_{uy},\qquad L=L_{(uv)(xy)}.
\]

The following equivalences are immediate from degrees, but their
connectivity clauses are essential.

### Proposition 2.1: the first cross path

\(X_{vx}\) exists if and only if \(G-\{u,y\}\) has a perfect matching \(M\)
such that

\[
R-M
\]

is connected. Indeed, in \(R-M\) the vertices \(v,x\) have degree one and
every other vertex has degree two. Hence connectedness makes it a spanning
\(v\)-\(x\) path. Conversely, the complement in \(R\) of such a spanning
path is a perfect matching of \(G-\{u,y\}\).

### Proposition 2.2: the second cross path

\(X_{uy}\) exists if and only if \(G-\{v,x\}\) has a perfect matching \(M\)
such that \(R-M\) is connected.

### Proposition 2.3: the legal linkage

A legal linkage \(L\) exists if and only if \(G\) has a perfect matching
\(M\), avoiding \(p,q\), such that \(G-M\) consists of exactly two cycles
and \(p,q\) belong to different cycles. Deleting \(p,q\) turns these cycles
into two spanning paths with pairing \((uv)(xy)\), and the converse follows
by adding \(p,q\) to the two paths.

There are three perfect matchings of the four terminals. The pairing
\((uy)(vx)\) is excluded by the gadget connectivity condition from Note 001.
The other alternative, \((ux)(vy)\), is crossing for four terminals in the
facial order \(u,v,x,y\), and therefore cannot be realised by two
vertex-disjoint paths in a plane embedding. Hence \((uv)(xy)\) is the only
possible legal \(L\)-pairing in the Barnette setting.

These propositions isolate the first missing arrow:

\[
\begin{split}
&\text{ordinary perfect matchings whose complements are one cycle}\\
&\quad\Longrightarrow
\begin{cases}
\text{near-perfect matchings with connected complement},\\
\text{an ordinary perfect matching with a prescribed two-cycle complement}.
\end{cases}
\end{split}
\tag{1}
\]

Global \(H^{+-}\) supplies the left side for all ordered edge pairs, but it
does not by its quantifiers alone supply either family on the right. A proof
of (1) must use an actual alternating-exchange or rerouting theorem that
preserves the required complement connectivity.

## 3. Exact mixed decorated conditions

Let the six traversal types be

\[
\mathcal T=\{A,B,C,D,E,L\}.
\]

For a retained edge \(r\in E(R)\), define

\[
T_r^+=\{\tau\in\mathcal T:
  \text{some concrete \(\tau\)-witness contains }r\},
\]

and

\[
T_r^-=\{\tau\in\mathcal T:
  \text{some concrete \(\tau\)-witness avoids }r\}.
\]

These are decorated sets: an unadorned witness of the same type does not
count. In the gadget-edge order

\[
(ua,ab,bv,xc,cd,dy,ad,bc),
\]

the incidence rows are

\[
\begin{array}{c|c}
A&11111100\\
B&10101011\\
C&01010111\\
D&01111010\\
E&11001101\\
L&10110111.
\end{array}
\tag{2}
\]

For the block retained\(\times\)gadget, the rows in \(T_r^+\) must cover
every column of (2) by a zero. The inclusion-minimal zero-covers are exactly

\[
\boxed{ABC,\qquad DEL,\qquad BCDE.}
\tag{3}
\]

For the block gadget\(\times\)retained, the rows in \(T_r^-\) must cover
every column by a one. The inclusion-minimal one-covers are exactly

\[
\boxed{AB,\ AC,\ AL,\ BC,\ DE,\ DL,\ EL.}
\tag{4}
\]

Consequently the two mixed blocks of child global \(H^{+-}\) hold if and
only if, for every retained \(r\), \(T_r^+\) contains a family in (3) and
\(T_r^-\) contains a family in (4).

Parent global \(H^{+-}\), together with cubic forcing at an endpoint of
\(r\), gives only

\[
T_r^\pm\cap\{A,B\}\ne\varnothing,
\qquad
T_r^\pm\cap\{A,C\}\ne\varnothing.
\tag{5}
\]

Both intersections in (5) may be witnessed by \(A\) alone, so (5) is
strictly weaker than (3)--(4).

Under the baseline intersections (5), the two mixed conditions have a
sharper logical normal form.  The retained\(\times\)gadget block is
equivalent, for every retained edge \(r\), to

\[
\begin{aligned}
A\in T_r^+&\Longrightarrow
 \bigl(\{B,C\}\subseteq T_r^+\bigr)
 \ \text{or}\ 
 \bigl(\{D,E,L\}\subseteq T_r^+\bigr),\\
A\notin T_r^+&\Longrightarrow \{D,E\}\subseteq T_r^+.
\end{aligned}
\tag{5a}
\]

The gadget\(\times\)retained block is equivalent to

\[
A\in T_r^-\Longrightarrow
B\in T_r^-\ \text{or}\ C\in T_r^-\ \text{or}\ L\in T_r^-
\ \text{or}\ \{D,E\}\subseteq T_r^-.
\tag{5b}
\]

When \(A\notin T_r^-\), (5) already forces \(B,C\in T_r^-\), so no
additional condition is needed.  Equivalently, a negative mixed failure
has only the two maximal forms

\[
T_r^-\subseteq\{A,D\}
\qquad\text{or}\qquad
T_r^-\subseteq\{A,E\}.
\tag{5c}
\]

Thus (5a)--(5b), not unstructured availability of more Hamilton cycles,
is the exact **decorated cofacial rerouting lemma** needed for the mixed
blocks.  Any proof must change the boundary type while retaining the
prescribed incidence of \(r\), and must remove all unwanted components of
the complementary 2-factor.

## 4. Minimal boundary-incidence obstructions

The strictness is not merely a missing manipulation. It already occurs in
the smallest projection on the three distinguished parent edges
\(p,q,r\). These are common-boundary incidence models, not actual cubic
graphs.

For retained\(\times\)gadget take the four parent cycle supports

\[
A=\{p,q,r\},\qquad B=\{p\},\qquad C=\{q\},\qquad Z=\{r\},
\tag{6}
\]

where \(Z\) is a non-liftable state-\(00\) Hamilton cycle, and take concrete
\(D,E,L\) witnesses avoiding \(r\). The four supports in (6) separate every
ordered pair among \(p,q,r\), all six traversal types are nonempty, and the
\(L\)-pairing may be chosen as the planar pairing \((uv)(xy)\). Nevertheless

\[
T_r^+=\{A\},
\]

so the ordered pair \((r,ua)\) fails in the child.

For gadget\(\times\)retained take

\[
A=\{p,q\},\qquad B=\{p,r\},\qquad C=\{q,r\},
\tag{7}
\]

and choose \(D,E,L\) all to contain \(r\). Again the parent projection has
global \(H^{+-}\), but \(T_r^-=\{A\}\), and the ordered pair \((ad,r)\)
fails.

Thus no argument using only the global \(H^{+-}\) quantifiers, six
unadorned traversal types, cubic single-vertex forcing, and the planar
four-terminal pairing rule can prove the mixed blocks. A successful proof
must use shared actual-graph incidence across perfect matchings or a genuine
Hamiltonian rerouting lemma.

## 5. Ordinary exchange stops before planarity

The ordinary perfect-matching exchange closure does not by itself produce
the two-cycle matching in Proposition 2.3.  The sharp relaxed example is

\[
G=K_{3,3}.
\]

Every perfect matching of \(K_{3,3}\) has a Hamilton six-cycle as its
complement.  These six matchings realise global \(H^{+-}\): after requiring
one edge to lie in the matching, one can choose between the two resulting
permutations so as to exclude any second distinct edge.  For any two
disjoint distinguished edges \(p,q\), three perfect matchings avoid both,
but all three again have one-cycle complements.  The symmetric difference
of every two perfect matchings is a single alternating \(C_4\) or \(C_6\),
so the full actual matching family is already closed under alternating
component flips.  Nevertheless it contains no matching with a two-cycle
complement.

This example is the unique smallest simple cubic bipartite
\(3\)-connected graph.  It is nonplanar and therefore is not a Barnette
counterexample.  It proves that a positive argument must use planarity and
the common-face order, rather than ordinary alternating exchange alone.

There is also a planar obstruction to the most direct construction of the
near-perfect matchings in Propositions 2.1--2.2.  Let \(M_B,M_C\) be
perfect matchings whose complements are Hamilton cycles of types \(10\)
and \(01\).  Then \(p\) and \(q\) lie on different cycle components of

\[
M_B\mathbin{\triangle}M_C.
\tag{8}
\]

Indeed, suppose that they lie on one alternating Jordan cycle \(K\), and
orient \(K\).  All \(M_B\)-edges of \(K\) then run in one direction
between the two bipartition classes and all \(M_C\)-edges run in the
opposite direction.  Since \(q\in M_B\) and \(p\in M_C\), the two
distinguished edges have opposite colour directions on \(K\).  The common
face lies on the same side of \(K\) at both edges, so its facial boundary
traverses them in the same direction relative to \(K\).  But the legal
order \(u,v,\ldots,x,y\), with \(u,x\) in the same bipartition class,
traverses both edges from that class to the other, a contradiction.

Thus a single alternating-component flip between a \(B\)- and a
\(C\)-matching is not merely insufficient in some examples: it is
topologically impossible as the general construction.  The two defects
occur in different alternating components and must be coupled through an
additional edge or path outside (8).  A 14-vertex Barnette graph gives a
strict witness-incidence boundary: ten actual Hamilton cycles already
separate every ordered pair of distinct edges, while their unique selected
\(B/C\) pair has no spanning cross path in its union.  The full Hamilton
cycle family of that graph does contain a compatible pair and the graph
does have \(X_{vx}\), so this is not a counterexample to the graph-level
statement.  It shows that pairwise global-\(H^{+-}\) incidence alone
cannot recover the required two-component coupling.

The forced separation in (8) gives a natural interpolation, but not the
needed connectivity.  Let \(Z_q\) be the component of
\(M_B\mathbin{\triangle}M_C\) containing \(q\).  Then

\[
M_0=M_B\mathbin{\triangle}E(Z_q)
\]

is a perfect matching avoiding both \(p,q\); moreover it preserves the
incidence of any retained edge on which \(M_B,M_C\) agree.  Nevertheless
\(G-M_0\) need not be Hamiltonian or a legal two-cycle factor.  In the
12-vertex hexagonal prism, at the legal square site

\[
(u,v,x,y)=(10,9,6,5),
\]

there are concrete \(B/C\) Hamilton-complement matchings for which this
flip produces three disjoint \(C_4\)'s, with \(p,q\) on the same one.  The
prism itself has global \(H^{+-}\) and its complete traversal family
satisfies all mixed covers, so this is a proof-route counterexample rather
than a preservation counterexample.  It proves that whole-component
perfect-matching closure cannot establish (5a)--(5b).  A positive proof
must instead provide a proper alternating-path connector between defect
components, or a cycle-coalescing exchange that preserves the required
\(r\)-coordinate.

[Note 017](017-cross-traversals-are-exactly-quotient-tree-connectors.md)
sharpens the first alternative. Proper alternating reachability is forced
in every connected regular bipartite graph. The exact remaining condition
is that one can select the connector, with optional alternating-cycle
flips, so that its contracted complement quotient is a tree; the cube shows
that an arbitrary proper connector may still leave a residual cycle.

[Note 018](018-a-z-interpolation-fixes-boundary-state-but-not-connectivity.md)
gives the analogous sharp reduction for positive decorated failures. A
missing \(B\)- or \(C\)-decoration forces a same-\(r\)-incidence \(A/Z\)
pair. Planarity then gives boundary-correct component or partial-path
flips, but the hexagonal prism shows that their complementary factors may
remain disconnected. Negative failures need not even supply such an
\(A/Z\) starting pair.

[Note 019](019-state-00-chord-rerouting-requires-a-nonlocal-decorated-connector.md)
handles the retained--retained analogue. For a state-\(00\) separator,
the two site edges are same-side noncrossing chords and all traversals
supported on the Hamilton circle plus those chords can be classified
exactly. A fixed 20-vertex site forces the successful decorated witness
to use a nonlocal alternating terminal connector.

Planarity does yield the following sufficient condition.  Let \(M\) be a
perfect matching avoiding \(p,q\), let \(K=G-M\) be a Hamilton cycle, and
suppose that a facial square \(C\), disjoint from \(p,q\), is
\(M\)-alternating.  The two edges of \(K\cap C\) are opposite.  Removing
them from \(K\) gives two paths.  Because the remaining parts of those
paths lie outside the facial disk, their endpoint pairing is the
noncrossing one; the alternative pairing would cross inside the plane.
Consequently

\[
N=M\mathbin{\triangle}E(C)
\]

is a perfect matching and \(G-N\) consists of exactly two cycles.  These
cycles contain \(p,q\) separately if and only if \(p,q\) lie on different
components of \(K-(K\cap C)\).

Thus Proposition 2.3 follows from the genuinely planar additional
condition that some Hamilton-complement matching avoiding \(p,q\) has a
separating alternating facial square.  Global \(H^{+-}\) does not force
this particular condition.  The first finite failure is a 20-vertex
Barnette graph: at one legal site it has a legal \(L\)-matching, but none
of its twelve Hamilton-complement matchings avoiding \(p,q\) has a
separating alternating facial square.  Exhaustive generation shows that
every legal site through order 18 does have one, so the boundary is sharp
for this proposed route.

The same example identifies the replacement mechanism.  In the resonance
graph restricted to matchings avoiding \(p,q\), the shortest facial-flip
route from a Hamilton complement to an \(L\)-matching is

\[
A\xrightarrow{\ C_6\ }3\text{ cycles}
 \xrightarrow{\ C_4\ }L.
\tag{9}
\]

No square-only facial-flip path joins the two families.  The endpoint
matchings in (9) differ on a single nonfacial alternating \(C_8\), obtained
because the shared edge of the hexagon and square cancels.  Thus the
remaining positive question must allow a coupled face region, or
equivalently a separating nonfacial alternating cycle; a single separating
facial square is too restrictive.

## 6. Exact dual-colouring form of the legal linkage

The legal \(L\)-condition has a second exact formulation that isolates its
planar content.  Let \(T=G^*\) be the dual triangulation, let \(z\) be the
dual vertex of the common face, and write

\[
p^*=z\alpha,\qquad q^*=z\beta.
\tag{10}
\]

For a binary vertex-colouring \(\chi\) of \(T\), let \(T_\chi\) be the
spanning subgraph of monochromatic edges.  If no triangular face of \(T\)
is monochromatic, then every triangle has exactly one monochromatic edge.
The primal edges dual to these edges form a perfect matching \(M_\chi\),
and every perfect matching arises from exactly two such colourings.  The
components of \(T_\chi\) are the regions of the sphere cut out by the
cycles of \(G-M_\chi\).  Consequently

\[
c(T_\chi)=c(G-M_\chi)+1.
\tag{11}
\]

It follows that a legal \(L\)-matching exists if and only if there is a
face-nonmonochromatic binary colouring \(\chi\) such that

\[
\chi(\alpha)=\chi(\beta)\ne\chi(z),
\tag{12}
\]

the colour class containing \(z\) induces a connected subgraph, and the
other colour class has exactly two components, containing \(\alpha\) and
\(\beta\) separately.  Equivalently, \(T_\chi\) has three components and
\(T_\chi+\{p^*,q^*\}\) is connected.  Equation (11) gives exactly two
primal factor cycles; (12) says that the two distinguished dual edges
cross the two different adjacencies between the three region-components.

There is an equivalent strict three-colouring statement.  The required
matching exists if and only if \(T\) has a colouring by \(a,b,c\) in which

1. every triangular face uses exactly two colours;
2. each colour class induces a nonempty connected subgraph; and
3. \((\alpha,z,\beta)\) receives \((a,b,c)\), up to interchanging
   \(a,c\).

Thus legal \(L\) is exactly a connected strict three-colouring extension
of a prescribed two-edge path, or a separated \(0\)-\(1\)-\(0\) Penaud
extension.  Neither clause can be discarded.  The cube has a strict
three-colouring with all colour classes connected but the wrong two-colour
wedge; the fixed 20-vertex example has the prescribed \(abc\) wedge but
one colour class is disconnected, corresponding to three factor cycles.

### Hamilton-colouring flips and pointwise merges stop short

A Hamilton-complement binary colouring has exactly two monochromatic
components, namely its two connected colour classes. Flipping just one
component makes the whole triangulation monochromatic, while flipping both
is only a global colour swap. Thus component flips provide no nontrivial
face-nonmonochromatic freedom.

There is also an exact boundary for combining state-(B/C) Hamilton
colourings. Normalize both to give (z) colour (0), and overlay their
bits. Then

\[
(\omega(\alpha),\omega(z),\omega(\beta))=(10,00,01).
\tag{13}
\]

Any pointwise map retaining the prescribed (abc) wedge must keep these
three labels distinct and merge the fourth label (11) into one of them.
For a chosen merge (11\to m), the triangular-face condition holds
exactly when no two-label face has labels ({11,m}) and every
three-label face contains both (11,m). Even then, all three merged fibres
must separately be connected.

At the fixed 20-vertex global-(H^{+-}) Barnette site, the complete four
(B)- by four (C)-colouring family gives 48 pair-and-merge choices.
Exactly one is face-valid, and its colour-class component profile is
((1,1,3)); none gives legal (L), although the same site has four actual
legal-(L) matchings. Hence component flips followed by pointwise overlay
and merge are strictly insufficient. A proof must use spatial selection,
a non-Hamilton intermediate matching, or a genuine connectivity-preserving
rerouting.

## 7. Finite boundary and remaining conjecture

A targeted literature check on 2026-08-25 found two adjacent matching
theorems, neither of which supplies the missing connectivity.  Zhang and
Liu's 2-resonance theorem says that in a 2-extendable plane bipartite graph
any two disjoint faces are simultaneously alternating for some perfect
matching; it does not control the number of components of the complementary
2-factor.  Diwan proves that every edge outside a 2-edge-cut in a planar
cubic bridgeless graph is a chord of a cycle in some 2-factor, and derives
separating perfect matchings under additional cyclic-connectivity
hypotheses.  He also proves that two prescribed edges in a planar cubic
bipartite graph can lie on the same 2-factor cycle.  These results provide
facial resonance or disconnected 2-factors separately, but not a matching
avoiding \(p,q\) whose complement has exactly two components with \(p,q\)
on different components.  The coupled-connectivity clause remains the
genuine extra requirement.

The known global \(H^{+-}\) verification through order \(66\) gives a
strong finite boundary without another census. If a parent has order at
most \(62\), every legal child has order at most \(66\), is again a Barnette
graph, and therefore has global \(H^{+-}\). The exact
gadget\(\times\)gadget criterion in Note 013 then forces
\(X_{vx},X_{uy},L\) at the parent site. Thus an actual interface failure, or
an actual failure of one-step preservation, can first have parent order
\(64\) and child order \(68\).

As an independent direct check, the verifier
scratch/worker-c4-hpm/verify_hpm_interface_boundary.py exhausts every
Barnette graph through order \(24\) and every legal directed site. At order
\(24\) it checks \(56{,}025\) cubic bipartite generated streams, \(43\)
Barnette streams, and \(11{,}192\) directed legal sites. Every site has all
three structures. The same verifier contains a \(16\)-vertex cubic,
bipartite, 3-connected nonplanar graph with global \(H^{+-}\) and a site
with neither cross path, showing that planarity is essential; it is not a
Barnette counterexample. Continuing the direct local census to order
\(26\) is dominated by the order-\(62\) consequence above and cannot change
the preservation decision.

The remaining decisive problem is now precise:

> Does planarity, cubicity, bipartiteness, 3-connectivity and global
> \(H^{+-}\) force the matching-connectivity conditions of Section 2 and
> the decorated covers (3)--(4) at every legal site, and force the joint
> retained-edge separation condition of Note 016 for every ordered pair of
> retained edges?

An affirmative answer proves global \(H^{+-}\) is preserved by every HMM
\(C_4\)-expansion and, together with cube-expansion preservation and the HMM
generation theorem, proves Barnette's conjecture. A negative answer must
fail one of the explicit matching or decorated conditions above, or the
joint two-edge condition of Note 016.

## Reproduction

The local set-cover and boundary-incidence calculation is

    python3 units/barnette/scratch/worker-c4-hpm/verify_mixed_decorated_separation_boundary.py

with marker MIXED_DECORATED_SEPARATION_BOUNDARY_VERIFIED. The finite real
and nonplanar boundary check is

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_hpm_interface_boundary.py

with marker HPM_INTERFACE_BOUNDARY_VERIFIED.

The \(K_{3,3}\) exchange boundary and the facial-square lemma are checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_k33_single_to_two_cycle_exchange_boundary.py

with marker K33_SINGLE_TO_TWO_CYCLE_EXCHANGE_BOUNDARY_VERIFIED.

The forced two-component lemma and its real Barnette incidence boundary are
checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_cross_matching_exchange_boundary.py

with marker CROSS_MATCHING_EXCHANGE_BOUNDARY_VERIFIED.

The sharp one-square failure and its coupled \(C_6,C_4\) replacement are
checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_separating_face_flip_boundary.py

with marker SEPARATING_FACE_FLIP_BOUNDARY_VERIFIED.

The decorated normal form, the planar component location, and the
hexagonal-prism whole-component obstruction are checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_planar_bc_component_flip_boundary.py

with marker PLANAR_BC_COMPONENT_FLIP_BOUNDARY_VERIFIED.

The exact dual-colouring characterization of a legal \(L\)-matching is
checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_dual_coloring_legal_l_interface.py

with marker DUAL_COLOURING_LEGAL_L_INTERFACE_VERIFIED.

The Hamilton-colouring component-flip and pointwise-overlay boundary is
checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_hamilton_colouring_overlay_merge_boundary.py

with marker HAMILTON_COLOURING_OVERLAY_MERGE_BOUNDARY_VERIFIED.

The quotient-tree connector criterion and its cube boundary are checked by

    uv run --python 3.12 --with networkx python \
      units/barnette/scratch/worker-c4-hpm/verify_proper_alternating_connector.py

with marker PROPER_ALTERNATING_CONNECTOR_VERIFIED.

The state-\(00\) chord classification and decorated nonlocal connector are
checked by

    python3 units/barnette/scratch/worker-c4-hpm/verify_state00_chord_rerouting_boundary.py

with marker STATE00_CHORD_REROUTING_BOUNDARY_VERIFIED.
