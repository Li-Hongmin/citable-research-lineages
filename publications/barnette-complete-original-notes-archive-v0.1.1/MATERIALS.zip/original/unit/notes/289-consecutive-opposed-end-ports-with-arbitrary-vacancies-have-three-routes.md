> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Consecutive opposed end ports with arbitrary vacancies have three routes

Note 281 constructs three spanning states when two consecutive
missing ordinary links belong to separate two-atom port parts.
Note 282 allows an unbounded number of vacancies in each
end-port part but excludes consecutive missing links. The
signature-only attachment of Note 286 joins these results:
the two parts may each contain arbitrarily many vacancies
while sharing their one short boundary block.

Use a compressed, gapless, tight-target all-square opening
of a Barnette parent. Vacancies lie in distinct target-free
internal face-chord blocks. In one free group let the only
missing ordinary links be \(P_s=e_so_{s+1}\) and
\(P_{s+1}=e_{s+1}o_{s+2}\). Suppose their distinct
noncrossing components have atom orders
\[
 V_{l_1}<\cdots<V_{l_p}<P_s<P_{s+1}<
 V_{r_1}<\cdots<V_{r_q},\qquad p,q\ge1,             \tag{1}
\]
with the first component ending at \(P_s\) and the
second beginning at \(P_{s+1}\). Thus
\(l_p\le s-1\) and \(r_1\ge s+3\) by old-cycle
adjacency. Assume their common block \(B_{s+1}\)
is short, all other components are vacancy-only, and
the group's two ordinary end links are retained.

**Consecutive-port theorem.** The group's full
target-free internal interval \(D=B_a,\ldots,B_b\)
has all three vertex-spanning states
\[
\begin{array}{ll}
S(D):&o_a\longleftrightarrow e_b,\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b.
\end{array}                                             \tag{2}
\]
The vacancy counts \(p,q\), their distances, and the
number and nesting depth of vacancy-only parts are
unrestricted. If every other free group has an ordinary
spanning route, the parent has a Hamilton cycle through
both site edges and its legal expanded child is Hamiltonian.

**Proof.** Let \(L=B_{l_1},\ldots,B_{s+1}\).
The reflected *prime* construction of Note 282 applies
to the first component: \(P_s\) is its last atom,
its target \(B_{s+1}\) is short, and every proper
gap has only vacancy-only parts. It gives spanning
\(S(L),K(L),X(L)\), even though the separate link
\(P_{s+1}\) is missing to the right of \(L\). The
right boundary of these routes consists of \(e_{s+1}\)
and \(b_{s+1}\); no route uses a vertex outside \(L\).

Apply Note 286's signature-only attachment with
\(s+1\) in place of its \(s\). Its right port component
is exactly \(P_{s+1},V_{r_1},\ldots,V_{r_q}\).
The edge \(e_{s+1}I_{r_q}\), the edge
\(o_{s+2}H_{r_1}\), and the intervening vacancy
edges have Note 286(3)'s form. The first gap is
nonempty because \(r_1\ge s+3\); its matching and
each later proper gap are vacancy-only and closed
by noncrossing. Note 286(5), (9), and (10) therefore
join the three left states to the right detour and
right continuation. They give \(S,K,X\) for
\(B_{l_1},\ldots,B_{r_q}\) without revisiting the
shared short block \(B_{s+1}\).

Any remaining vacancy-only component lies in a
proper gap of one of the two port parts, is serially
disjoint, or surrounds their combined span. Note 275's
prime recursion absorbs the surrounding parts and
joins serial flanks across retained links, proving (2).
Note 273 composes groups; Notes 001 and 178 give the
marked cycle, legal child, and original lobe lengths.
\(\square\)

Every pair \(p,q\ge1\) has an explicit Barnette
realization. Use the site blocks and residual square
of Note 281(8), put \(s=p+1\) and \(r=p+q+3\),
make \(B_1,\ldots,B_p\) and
\(B_{s+3},\ldots,B_r\) vacant, and make
\(B_s,B_{s+1},B_{s+2}\) short. Keep all standard
free links except \(P_s,P_{s+1}\), and add
\[
\begin{gathered}
H_1o_{s+1},\qquad
I_jH_{j+1}\ (1\le j<p),\qquad I_pe_s,\\
e_{s+1}I_r,\qquad o_{s+2}H_{s+3},\qquad
I_jH_{j+1}\ (s+3\le j<r).
\end{gathered}                                          \tag{3}
\]
Together with Note 281's unchanged site, face,
escape, and residual-square edges, these form a
perfect matching. The two outer special chords
\(H_1o_{s+1}\) and \(e_{s+1}I_r\) occupy disjoint
intervals of the opposite-side disk; each encloses
its own inner special and retained standard chords.
All matching edges join opposite old-cycle colours,
so the parent is cubic, bipartite, and plane, with
cofacial site edges.

The matching-chord interlacement graph is connected.
Retained links connect the face chords up to \(B_s\)
and from \(B_{s+2}\) to \(B_r\).
\(H_1o_{s+1}\) meets those of \(B_1,B_{s+1}\);
\(e_{s+1}I_r\) meets those of \(B_{s+1},B_r\).
Every other edge of (3) meets an endpoint face
chord, and the retained end links attach the site
and residual-square closing chain. Note 217's
cut argument and Note 182's cubic lemma give
three-vertex-connectivity. The parent has
\(6(p+q)+24\) vertices; the legal expanded child
has \(6(p+q)+28\), and both have the asserted
Hamilton cycles.

The theorem removes Note 282's separation condition
for this opposed, short shared-block pair. It does
not classify three or more missing links or two
components whose shared block is vacant.
