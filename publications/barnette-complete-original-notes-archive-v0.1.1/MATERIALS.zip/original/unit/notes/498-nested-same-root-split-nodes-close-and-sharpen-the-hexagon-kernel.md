> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Nested same-root split nodes close and sharpen the hexagon kernel

[Note 497](497-disjoint-same-root-split-nodes-close-on-the-rethreaded-cycle.md) closes two disjoint split nodes in one root. The remaining same-root arrangement is nested. On the single rethreaded cycle \(D_0\) of [Note 496](496-three-cycle-splice-closes-end-middle-split-equality.md), the outer complement contains both end escape edges. The only possible escape-free residual component is the middle layer between the two nodes; a mixed opening joins it to the inner child and outer complement.

Use the chord-free three-root single-hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Let two split marked unary nodes lie in the same root, nested as
\[
 N_o=(H_o,s_o,A_o,t_o,J_o),\qquad
 N_i=(H_i,s_i,A_i,t_i,J_i)\subset A_o .
                                                               \tag{1}
\]
Write \(L_o,R_o,L_i,R_i\) for the ends of their child words. Every assigned special position outside the four direct positions belongs to a complete two-special leaf. There is no bound on the number of leaves or ordinary wrappers, and the root face graph need not be connected.

**Nested same-root theorem.** The parent has a Hamilton cycle containing both site edges, and its legal \(C_4\)-expanded child is Hamiltonian.

**Proof.** Let \(D_0\) be the single cycle (1) of Note 496 on all vertices of the three base cycles. Let \(E\) be the old square-supported edges of the two-special leaves and \(M\) the face matching outside the two site ports \(u,v\). Open both nodes inside:
\[
 F_{\mathrm{ii}}=
 \bigl(D_0-E-\{s_oL_o,R_ot_o,s_iL_i,R_it_i\}\bigr)
       \cup M\cup\{L_oR_o,L_iR_i\}.                  \tag{2}
\]
Every nonterminal has degree two and \(u,v\) have degree one. Restoring \(E\) exposes three connected old pieces before interpiece \(M\)-edges: the inner child \(A_i\); the middle layer \(D=A_o\setminus A_i\), whose two flanks are joined by \(L_oR_o\); and the outer complement \(B=V(D_0)\setminus A_o\). Both escape edges \(t_dd,t_aa\) lie in \(B\), because \(A_o\) is contained in a single root word. A singleton-leaf child whose inserted chord is its leaf-square chord has a quotient loop, so no unavailable square switch is needed. Switch at leaf squares along a quotient forest in each coarse component. This leaves one spanning \(u\)--\(v\) path in the marked component and a cycle in each terminal-free component, preserving both escape edges.

If no terminal-free component remains, close the path through \((u,w_0,\beta,\alpha,w_*,v)\). An isolated terminal-free \(A_i\) is impossible: no matching edge leaves it, its ordinary chords are internal, and only the two old boundary edges \(s_iL_i,R_it_i\) leave it in the cubic parent, contrary to three-connectivity. A terminal-free component \(A_i\cup D=A_o\) without \(B\) is impossible for the same reason, using the outer boundary edges \(s_oL_o,R_ot_o\). Every terminal-free component containing \(B\) contains \(t_dd\); the one-cycle splice (3) of [Note 489](489-two-end-escape-edges-absorb-both-residual-cycles.md) absorbs it into the marked path. Since \(B\) is one coarse piece, there is at most one such component.

The only unabsorbed possibility is therefore an isolated, terminal-free middle layer \(D\). Its left and right flanks contain respectively \(s_i\) and \(t_i\), plus complete two-special leaves; each flank has an odd number of matching positions. No \(M\)-edge leaves \(D\), so an odd number of its matching edges join the flanks and span \(A_i\). Any site edge ending in \(A_i\) would cross such a face chord, because \(w_0\) lies before and \(w_*\) after the whole root word in the old Hamilton order. Thus \(A_i\) has no site port. Since \(D\) also has none, both \(u,v\) lie in \(B\). Three-connectivity now forces an \(M\)-edge from \(A_i\) to \(B\): without one, no third edge leaves \(A_i\), and its two old boundary edges form a forbidden two-edge cut.

Open the outer node inside and the inner node outside:
\[
 F_{\mathrm{io}}=
 \bigl(D_0-E-\{s_oL_o,R_ot_o,H_is_i,t_iJ_i\}\bigr)
       \cup M\cup\{L_oR_o,H_iJ_i\}.                 \tag{3}
\]
The core chord \(H_iJ_i\) is unused by \(D_0\), which uses only old root arcs and the listed escape edges. After restoring \(E\), the three coarse pieces are the central arc \(P_i=s_i\rightsquigarrow t_i\), the rest of the middle layer closed through \(L_oR_o,H_iJ_i\), and the outer complement \(B\). The \(A_i-B\) edge joins \(P_i\) to \(B\). Each of \(s_i,t_i\) is a non-site position in the formerly isolated \(D\), so its \(M\)-mate lies in \(D\); [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) excludes the other direct position as mate. It cannot match into \(A_i\), because \(D\) was a separate component in (2). Hence a direct-position matching edge joins \(P_i\) to the rest of the middle layer. All three coarse pieces are connected, and leaf-square switches give a spanning \(u\)--\(v\) path. The outside path above closes a marked parent Hamilton cycle; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the legal child. \(\square\)

**Unified selected-hexagon bound.** [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md) classifies every possible non-Hamiltonian chord-free \(12f+2\) equality profile for \(f\ge7\). Its one-root all-leaf row is closed by [Note 478](478-one-root-all-leaf-chord-free-equality-always-has-an-exterior-splice.md), its two-root unary row by [Note 483](483-all-two-root-chord-free-unary-openings-are-hamiltonian.md), and its four-special-leaf row by [Note 479](479-four-special-leaf-closes-three-root-chord-free-opening.md). In the remaining three-root two-unary row, [Notes 484–485](485-two-adjacent-unary-pairs-close-three-root-chord-free-equality.md) close any adjacent direct pair; [Notes 486–488](488-nested-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md) close disconnected root face graphs; [Notes 490 and 496](496-three-cycle-splice-closes-end-middle-split-equality.md) close distinct-root split placements; Note 497 closes disjoint same-root placements; and the theorem above closes nested same-root placements. Consequently no selected chord-free single-hexagon non-Hamiltonian child attains \(12f+2\) reduced vertices. Its doubly ladder-reduced ordinary-chord count satisfies \(c\le5f-9\), and its reduced child order satisfies
\[
                              |V(\bar G^+)|\le12f.        \tag{4}
\]
The chorded branch already has the same \(12f\) bound by [Note 476](476-a-six-terminal-square-splice-closes-the-chorded-equality-boundary.md). Thus (4) is a unified necessary bound for a non-Hamiltonian child with a selected single-hexagon opening and \(f\ge7\). At \(f=8\) it gives at most \(96\) reduced vertices. It does not cover other selected openings, larger non-Hamiltonian kernels below this bound, or Barnette's conjecture.
