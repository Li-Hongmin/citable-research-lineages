> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every two-root chord-free single-unary equality opening is Hamiltonian

[Note 480](480-adjacent-unary-two-root-chord-free-openings-are-hamiltonian.md) closes the adjacent direct-special pair in the two-root row of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md). [Note 481](481-disconnected-two-root-split-unary-openings-are-hamiltonian.md) closes the disconnected root face graph when the pair is split. [Note 482](482-middle-gap-two-exposed-face-chords-close-the-split-unary-profile.md) closes the connected middle-gap order with two exposed face chords. We close the remaining outer-gap orders and the middle-gap order with one exposed site port.

Throughout, use the chord-free single-hexagon setup of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md). There are two ordinary roots \(W_1,W_2\), one marked unary node \(N\) with direct-special order \(H,s,A,t,J\), and every other assigned special position occurs in a two-special leaf. Write \(L,R\) for the ends of the child word \(A\), joined by an ordinary chord \(LR\), and \(q=w_0u,p=vw_*\) for the site edges. All ordinary wrapper lengths are allowed.

## Connected outer-gap order

Consider order A of Note 458:
\[
 w_0,t_d,z_1,z_2,t_c,W_1,t_b,W_2,t_a,w_*,
\tag{1}
\]
followed by \(w_*,\alpha,a,b,c,d,\beta,w_0\). Both \(z_i\) are face-chord endpoints; let \(r_i\) be their mates in the roots. Let \(K\) be the root face graph and suppose it is connected. The four terminals are \(T=\{u,v,r_1,r_2\}\), with \(r_i<u<v\) whenever the positions are compared on the old main arc: a mate after \(u\) would make \(z_i r_i\) cross \(q=w_0u\).

**Outer-gap theorem.** The parent has a Hamilton cycle containing \(p,q\). The same holds in reflected order C.

Choose the two disjoint spanning base cycles and exterior paths according to the root containing \(N\). When \(N\subseteq W_1\), take
\[
\begin{aligned}
D_1&=(W_{1,\ell}\xrightarrow{\rm old}W_{1,r},t_b,b,c,t_c,W_{1,\ell}),\\
D_2&=(W_{2,\ell}\xrightarrow{\rm old}W_{2,r},W_{2,\ell}),
\end{aligned}
\qquad
\begin{aligned}
\mathcal E_1&=(u,w_0,t_d,d,\beta,\alpha,a,t_a,w_*,v),\\
\mathcal E_2&=(r_1,z_1,z_2,r_2).
\end{aligned}
\tag{2}
\]
The last edge of \(D_2\) is its root chord. When \(N\subseteq W_2\), instead take
\[
\begin{aligned}
D_1&=(W_{1,\ell}\xrightarrow{\rm old}W_{1,r},W_{1,\ell}),\\
D_2&=(W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_a,a,b,t_b,W_{2,\ell}),
\end{aligned}
\qquad
\begin{aligned}
\mathcal E_1&=(u,w_0,\beta,\alpha,w_*,v),\\
\mathcal E_2&=(r_1,z_1,t_d,d,c,t_c,z_2,r_2).
\end{aligned}
\tag{3}
\]
Every displayed edge is an old, ordinary-root, trap, escape, site, or exposed face-chord edge. In either row \(D=D_1\cup D_2\) covers every vertex except the two disjoint exterior paths; these pair \((u,v)(r_1,r_2)\) and contain both site edges. Also \(D\cup M\) is connected, where \(M\) consists of all face matching chords except those at \(T\), because \(K\) is connected.

Let \(E\) contain each two-special leaf's square-supported old edge and set
\[
                    F=(D-E-\{sL,Rt\})\cup M\cup\{LR\}.
\tag{4}
\]
Every vertex of \(F\) has degree two except the four degree-one terminals \(T\); hence \(F\) consists of two paths and cycles. A leaf square whose chord is already used in \(F\) gives a quotient loop and needs no switch. If \(F\cup E\) is connected, the four-terminal square-switch argument of Note 458 supplies two spanning internal pairings. One differs from the exterior pairing in (2) or (3), giving a marked Hamilton cycle.

Suppose \(F\cup E\) is disconnected. Cutting \(sL,Rt\) divides the cycle containing \(N\) into the closed child arc \(A\) and its complementary arc \(B\); the other base cycle is \(O\). Because \(K\) connects the roots, exactly one of \(A\) and \(B\) is isolated, with the other joined to \(O\). Each component has zero, two, or four terminals. An isolated \(A\) with zero terminals would have only \(sL,Rt\) leaving it in the cubic parent, contradicting three-connectivity. If both components have two terminals and the isolated one contains one site port and one exposed mate, square switches within each component give a mixed internal pairing, which differs from \((u,v)(r_1,r_2)\) and closes the cycle.

If \(B\) has no terminals, square switches make it a spanning cycle \(Z\); the component \(A\cup O\) has two distinct spanning four-terminal pairings. For \(N\subseteq W_1\), \(Z\) retains \(t_cc\). Delete that edge and use the two exterior paths
\[
 (u,w_0,\beta,\alpha,a,t_a,w_*,v),\qquad
 (r_1,z_1,t_d,d,c)\ (Z-t_cc)\ (t_c,z_2,r_2).
\tag{5}
\]
For \(N\subseteq W_2\), \(Z\) retains \(t_aa\). Delete it and use
\[
 (u,w_0,\beta,\alpha,a)\ (Z-t_aa)\ (t_a,w_*,v),\qquad
 (r_1,z_1,t_d,d,c,t_c,z_2,r_2).
\tag{6}
\]
The notation \(Z-e\) means the path through all vertices of the former cycle, oriented between the adjacent displayed endpoints. Each pair in (5) or (6) covers all vertices outside the four-terminal component, includes \(p,q\), and pairs \((u,v)(r_1,r_2)\). Choose the available internal pairing that differs.

Now suppose an isolated \(A\) has precisely the site terminals \(u,v\). Every other special position of \(A\) is matched within \(A\), and every such position belongs to a two-special leaf. The open-arc theorem of Note 458 gives two spanning four-port pairings on \(L,R,u,v\), one of which pairs \(L\) with one site port and \(R\) with the other. Join it to the complementary \(L\)--\(R\) path around the old root cycle. This gives a spanning \(u\)--\(v\) path in the root containing \(N\). If that root is \(W_2\), use the exterior \(w_0\)--\(w_*\) path (1) of Note 480. If it is \(W_1\), use
\[
 w_0,\beta,d,t_d,z_1,z_2,t_c,c,b,t_b,
 W_{2,\ell}\xrightarrow{\rm old}W_{2,r},t_a,a,\alpha,w_*.
\tag{7}
\]
Either exterior path covers every vertex outside the site root, so \(q,p\) close a marked Hamilton cycle.

An isolated \(B\) with exactly \(\{u,v\}\) or \(\{r_1,r_2\}\) is impossible. Choose a \(K\)-chord between \(A\) and \(O\). If \(N\subseteq W_1\), write it \(xy\) with \(x\in A,y\in W_2\). A site pair in \(B\) lies before \(A\), since \(p=vw_*\) forces \(v<x\). An exposed-mate pair in \(B\) also lies before \(A\), since noncrossing of \(z_i r_i\) with \(xy\) forces \(r_i<x\). The prefix before \(A\) then has one direct special position \(s\), complete two-special leaves, and exactly two terminals, so the number of its \(M\)-endpoints is odd. It cannot match to \(A\) or \(O\) by isolation; a matching chord to the suffix after \(A\) would cross \(xy\). This is impossible. If \(N\subseteq W_2\), write the chord \(yx\) with \(y\in W_1,x\in A\). The site pair must lie after \(A\) because \(q=w_0u\) forces \(x<u\); the exposed-mate pair must also lie after \(A\) because noncrossing of \(z_i r_i\) with \(yx\) forces \(x<r_i\). The suffix has \(t\), complete leaves, and two terminals, hence an odd number of \(M\)-endpoints, with no matching edge out of that suffix. This is the reflected contradiction.

An isolated \(A\) with exactly \(\{r_1,r_2\}\) is impossible as well. If \(N\subseteq W_1\), the prefix before \(A\) contains \(s\), complete leaves, and no terminal: \(r_i\in A\) and the site ports follow \(r_i\) on the old main arc. This prefix has an odd number of \(M\)-endpoints. Isolation forbids its edges to \(A\), while any face chord from the prefix to the suffix or \(W_2\) would cross \(z_i r_i\). If \(N\subseteq W_2\), \(r_i\in A\) forces both site ports into \(W_2\) after \(A\). The suffix contains \(t\), complete leaves, and two site terminals, again leaving an odd number of \(M\)-endpoints. Isolation forbids chords to \(A\), and any chord from that suffix to the prefix or \(W_1\) crosses \(z_i r_i\). Both cases contradict perfect matching.

Finally, all four terminals might lie in the root containing \(N\). They still occur with both exposed mates before both site ports. If \(A\) is isolated and contains all four, then for \(N\subseteq W_1\) the terminal-free prefix before \(A\) has an odd number of \(M\)-endpoints and cannot send a chord past \(u\) without crossing \(q\); for \(N\subseteq W_2\), the terminal-free suffix after \(A\) has an odd number and cannot send a chord before \(v\) without crossing \(p\). Isolation excludes a chord into \(A\). If \(B\) is isolated and contains all four, the chosen \(K\)-chord ends in \(A\). For \(N\subseteq W_1\), its endpoint lies after \(v\), so all four terminals lie in the prefix before \(A\); for \(N\subseteq W_2\), noncrossing with \(z_i r_i\) puts its endpoint before both \(r_i\), so all four terminals lie in the suffix after \(A\). That side has one of \(s,t\), complete leaves, and four terminals: its number of \(M\)-endpoints is odd. Isolation forbids chords to \(A\) or \(O\), and a chord across \(A\) crosses the \(K\)-chord. This excludes the last case and proves order A. Reversing the old-cycle order, with \(W_1\leftrightarrow W_2\), \(z_1\leftrightarrow z_2\), \(t_d\leftrightarrow t_a\), \(t_c\leftrightarrow t_b\), and \(a\leftrightarrow d,b\leftrightarrow c,\alpha\leftrightarrow\beta\), proves order C. \(\square\)

## One exposed site port in the middle gap

In order B, suppose \(z_1=u\) is the site port, \(z_2\) is a face-chord endpoint with mate \(r\in W_2\), and \(v\in W_2\). Three-connectivity forces a face chord between the roots, so \(K\) is connected, as proved in Note 458. Use its two base cycles (3) and let \(M\) match all special positions other than \(v,r\). With the same \(E,L,R\), form \(F\) by (4). It has one \(v\)--\(r\) path and some cycles. If \(F\cup E\) is connected, leaf-square switches give a spanning \(v\)--\(r\) path; the exterior path
\[
                         (v,w_*,\alpha,\beta,w_0,z_1,z_2,r)
\tag{8}
\]
closes it through both site edges.

If \(F\cup E\) is disconnected, its coarse pieces are again \(A,B,O\), with \(O\) joined to exactly one of the other two. An isolated \(A\) with no terminal gives the forbidden two-edge cut. In every other case the component without \(v,r\) contains either \(t_dd\) or \(t_aa\): \(B\subseteq D_1\) contains the first when \(N\subseteq W_1\), \(B\subseteq D_2\) contains the second when \(N\subseteq W_2\), and a terminal-free component containing the whole other base cycle contains its escape edge. Square-switch its cycles into one spanning cycle \(Z\), and square-switch the other component into a spanning \(v\)--\(r\) path. If \(Z\) contains \(t_dd\), delete that edge and use
\[
                  (v,w_*,\alpha,\beta,d)\ (Z-t_dd)\
                  (t_d,w_0,z_1,z_2,r).
\tag{9}
\]
If \(Z\) contains \(t_aa\), use
\[
                  (v,w_*,t_a)\ (Z-t_aa)\
                  (a,\alpha,\beta,w_0,z_1,z_2,r).
\tag{10}
\]
Either path covers the exterior and \(Z\), contains \(p,q\), and joins the marked path into a Hamilton cycle. The case \(z_2=v\), with \(z_1\) a face-chord endpoint, is obtained by the same reflection as above. When both \(z_i\) are site ports, they are adjacent and the one-edge facial-gap switch of [Note 174](174-brace-cross-openings-avoid-a-forbidden-matching-edge.md) gives a Hamiltonian child. \(\square\)

## Equality consequence

If adjacent escape targets occur, [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) closes the selected opening. Otherwise Note 458 leaves orders A, B, C. Combining the outer-gap and one-exposed-site arguments with Notes 480–482 and the adjacent-site switch of Note 174, **every legal expanded child in the chord-free two-root single-unary profile of Note 477 is Hamiltonian**. Hence a non-Hamiltonian doubly reduced chord-free selected single-hexagon child at \(c=5f-8\), if one exists, must have the three-root profile with two marked unary nodes, each assigned two direct special positions, and every other assigned position in a two-special leaf. The \(12f+2\) order bound is still a necessary bound, not a general Barnette decision.
