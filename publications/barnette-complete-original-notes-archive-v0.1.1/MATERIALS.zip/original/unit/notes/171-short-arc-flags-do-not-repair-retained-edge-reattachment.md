> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Short-arc flags do not repair retained-edge reattachment

Let \(\nu\) and \(\Sigma_{\rm next}\) have exactly the meanings of
[Note 170](170-real-retained-edge-reattachment-collision-for-the-fourteen-slot-summary.md).
For the two ordered residual arcs of the post-expansion successor face, write
their lengths as \((\ell_0,\ell_1)\), and define
\[
c_3(\ell)=\min\{\ell,3\},\qquad
\nu_{\rm short}=(\nu,c_3(\ell_0),c_3(\ell_1)).
\]
The lengths are positive and odd, so each added coordinate has precisely the
two possible values \(1,3\). This refinement has four added states. No exact
length, unmarked vertex, additional row, or additional birth flag is included.

For Note 170's pair, the lengths \((3,3)\) and \((5,1)\) give different
\(\nu_{\rm short}\). Indeed, the single bit \(\mathbf1_{\ell_1=1}\)
already separates that pair; a two-valued addition is the smallest possible
alphabet that separates two previously equal keys. This observation alone
does not imply exact reattachment.

**Theorem.** On the full real domain of two consecutive \(o^*\) operations,
there is no deterministic map
\[
U(\Sigma_+(Z),\nu_{\rm short}(Z,q))=\Sigma_{\rm next}(Z,q).
\]
The failure occurs on a common 20-vertex graph \(Z\), with a common complete
history through \(Z\) and two legal retained-edge choices. Their 24-vertex
post-expansion successors have arc-length pairs \((3,5)\) and \((5,3)\).

## A common real history

Start with the cube of the [frozen SPEC](../SPEC-2026-09-12-upgrade.md).
Use its expansion rule at the following ordered sites, with the indicated
fresh vertices:

| input | ordered site | fresh vertices | output |
|:---|:---|:---|:---|
| \(Q\) | \((0,1,2,3)\) | \((8,9,10,11)\) | \(G_1\) |
| \(G_1\) | \((4,0,3,7)\) | \((12,13,14,15)\) | \(W\) |
| \(W\) | \((0,8,9,1)\) | \((16,17,18,19)\) | \(Z\) |
| \(Z\) | \((0,16,11,3)\) | \((20,21,22,23)\) | \(H\) |

The last two operations are consecutive instances of the fixed role template
\((u,v,x,y;r_0,r_1)\mapsto(u,a,r_0,r_1)\). The first retains
\((11,3)\). For the second, choose either
\[
q_1=(19,1),\qquad q_2=(5,4).
\]
The terminal sites are respectively \((0,20,19,1)\) and \((0,20,5,4)\).
The earlier prefix is an allowed general legal-expansion history; the SPEC
does not require that prefix to use \(o^*\).

Here are the witnessing faces before the four expansions, in the same order:
\[
\begin{gathered}
(0,1,2,3),\qquad (4,0,3,7),\\
(0,8,9,1,5,4,12,13),\qquad (0,16,17,8,11,3).
\end{gathered}
\]
The corresponding residual lengths are \((1,1),(1,1),(1,5),(3,1)\).
The relevant face of \(H\) is
\[
(0,20,21,16,19,1,5,4,12,13).
\]
It gives residual lengths \((3,5)\) at \(q_1\) and \((5,3)\) at \(q_2\).
All these ordered sites have equally coloured initial endpoints. The
expansions therefore preserve simple cubic bipartite planar 3-connected
graphs by [Note 006](006-theorem-level-corrections-and-positive-depth-support-theorem.md).
Alternatively, these properties follow from the direct checks below.

These site and birth lists specify the full edge ledger: at each step delete
the two site edges, add the eight SPEC edges, and give each surviving edge to
its birth layer except for the two terminal-cap edges. The owner counts
\((Q,B_0,B_1,B_2,B_3,\mathrm{cap})\) are
\[
(8,5,8,6,7,2)\quad\hbox{and}\quad(7,5,8,7,7,2),
\]
respectively, each summing to \(|E(H)|=36\). Removing the last four birth
vertices and restoring the recorded seals successively recovers
\(Z,W,G_1,Q\).

## Equality of the enriched input keys

Keep the same ordered targets in both contexts:
\[
e=(2,6),\qquad f=(9,10).
\]
The entire previous operation, its history, the rooted graph \(Z\), and
the targets are identical. Hence the complete \(\Sigma_+(Z)\) of
[Note 169](169-corrected-fourteen-slot-fixed-operation-interface-go.md),
including its entire support, is literally the same. No comparison of hashes
or sampled rows is involved.

The fourteen ordered slots for the next operation are
\[
(U,V,X,Y,Q_0,Q_1,E_0,E_1,F_0,F_1,A,B,C,D)
=(0,16,11,3,q_0,q_1,2,6,9,10,20,21,22,23).
\]
All classes are distinct. In both contexts the normalized colour word is
\[
(0,1,0,1,0,1,0,1,0,1,1,0,1,0).
\]
The first ten classes exist in \(Z\); the final four are future classes.
Both targets are live external edges distinct from the controlled edges;
\(e\) is kernel-live and \(f\) is older-live in both histories. Their
endpoint, identity, location, and existence data therefore agree. The marked
successor-face word is in each case
\[
(\texttt{UA},(A,B,V,Q_0),\texttt{SEP},(Q_1),\texttt{SEP}).
\]
Thus all fields of the frozen \(\nu\) agree. The two added coordinates are
also equal, namely \((3,3)\). Notice that the frozen \(\nu\) does not
record the birth status of \(q\); adding such a flag would be a different
refinement.

## A separating row and the even-cut obstruction

Use the ordered active boundary
\((U,V,X,Y,Q_0,Q_1,E_0,E_1,F_0,F_1)\). Consider the complete exterior row
with degree word
\[
d=(0,0,0,0,0,0,0,2,2,0),
\]
singleton partition on the ten active classes, closed-component count
\(z=1\), and target-use bits \((0,0)\).

For \(q_1\), take the disjoint union
\[
F=C_4(4,5,6,7)\;\dot\cup\;
  C_4(8,9,18,17)\;\dot\cup\;C_4(12,13,14,15).
\]
It uses none of the three cut edges \(0\! -\!16,11\! -\!3,19\! -\!1\).
Every vertex outside the active boundary has degree two. The first two
cycles meet that boundary only at \(E_1=6\) and \(F_0=9\); the third
misses it. Every other active vertex is isolated, and neither target is used.
Consequently \(F\) has exactly the displayed row.

For \(q_2\), suppose a generator of the same row existed. Let
\(D=\{12,13,14,15\}\) be the four vertices of the inserted expansion.
All lie outside the active boundary and must have degree two. In \(Z\),
\[
\delta(D)=\{4\! -\!12,0\! -\!13,3\! -\!14,7\! -\!15\}.
\]
The asserted row sets the degrees at \(0,3,4\) to zero, so only
\(7\! -\!15\) could belong to \(F\cap\delta(D)\). But
\[
8=\sum_{v\in D}\deg_F(v)
 =2|E(F[D])|+|F\cap\delta(D)|
\]
forces that last cardinality to be even, hence zero. Vertex \(7\) is
outside the boundary and has neighbours exactly \(4,6,15\). Both its
edges to \(4\) and \(15\) are unavailable, leaving degree at most one,
a contradiction. This proves absence from the full next support, not merely
failure of a selected lift. Together with the explicit witness and equal
input keys, it proves the theorem.

## Executable verification and scope

The standard-library checker
[`verify_short_arc_collision.py`](../scratch/route3_short_arc_refinement/verify_short_arc_collision.py)
starts with an explicit cube rotation system and constructs the four embedded
expansions. It checks site legality, spherical face permutations, cubicity,
bipartiteness, connectivity after every deletion of at most two vertices,
inverse rotations, the complete final edge ownership, input-key equality,
and the complete witness row. Independently of the even-cut proof, it deletes
edges incident with prescribed zero-degree vertices and tests all \(2^{12}\)
remaining edge subsets; none satisfies the required degree word on the
\(q_2\) side. From the unit directory, run

```sh
python3 -B scratch/route3_short_arc_refinement/verify_short_arc_collision.py
```

Its terminal line is `SHORT_ARC_REFINEMENT_COLLISION_VERIFIED`.

The verdict is **NO-GO for exact reattachment from
\((\Sigma_+,\nu_{\rm short})\)**. It also excludes either single short-arc
flag, or any function of the two flags, as the only addition to \(\nu\).
The underlying mechanism is that lengthening a facial arc by a four-port
patch can preserve the exterior obstruction through cut parity.

The limitation is exact: the separating row has \(z=1\), so its closed
component cannot be joined to a Hamilton cycle by the subsequent local
patch. The theorem concerns reconstruction of the declared complete row
support and does not exclude a summary designed only for Hamilton acceptance.
It also does not exclude stronger arc encodings (for example \(c_5\), which
distinguishes this pair), extra birth flags, or other finite enrichments.
Note 169's fixed-operation one-step theorem remains intact; no all-operation
closure, nonexistence of every finite summary, or statement (T) is established.
