> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One target pair between two vacancies is Hamiltonian

[Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
settles two vacancies in a target-free face block. The
first target-bearing same-block configuration has exactly
one occupied \(L,R\) pair between the vacancies. Its
escape edges prevent cross-block chords from crossing
the pair, while parity and colour balance restrict
internal chords to two explicit routings.

Use the compressed all-square Barnette opening of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md),
with \(\ell,r\ge1\), empty interblock gaps, tight target
order and exactly two eligible vacancies. Suppose both
vacancies lie in one face-chord block \(D=[a,b]_C\),
whose interior old-cycle order is precisely
\[
o,h_1,i_1,L,R,h_2,i_2,e.                       \tag{1}
\]
Here \(h_1,h_2\) are vacant eligible even positions,
\(i_1,i_2\) are their following free odd slots, and
\(L,R\) are the occupied consecutive transition
targets \(L_j,R_{j-1}\). There are no other target
positions in \(D\). The local free matching interval
has any number \(t,u\ge0\) of short target-free face
blocks to the left and right, with exterior end slots
\(e_0,o_R\). Other occupied target runs may delimit
that interval. Note 215's even-prefix barrier at those
other runs makes the displayed free interval closed
under the matching.

**One-transition double-vacancy theorem.** The parent
has a Hamilton cycle containing both site edges \(xy,uv\).
Its legal site-expanded child is Hamiltonian. The
result holds for arbitrary \(t,u\) and arbitrary
positive original square-trap lobe lengths.

More precisely, let \(c\) be the number of free
matching chords crossing the internal target run
from \(\{o,h_1,i_1\}\) to \(\{h_2,i_2,e\}\).
Then \(c=0\) or \(c=2\). If \(c=0\), each vacancy
is absorbed by an independent three-edge detour
on its own side of \(L,R\). If \(c=2\), exactly
one of the following internal pairs occurs:
\[
\begin{array}{ll}
\text{local:}&oe,\ h_1i_2,\\
\text{target detour:}&h_1i_2,\ i_1h_2 .
\end{array}                                          \tag{2}
\]
The first has Note 224's local marked path.
The second inserts the four free vacancy slots
into the target path by replacing
\[
L,R\quad\longmapsto\quad
L,i_1,h_1,i_2,h_2,R.                              \tag{3}
\]

**Proof.** No cross-block free chord can straddle
\(L\) or \(R\), by Note 203's planar crossing
lemma. A same-block free chord straddling either
target must be drawn on the site-face side of
\(C\): in the opposite disk it would cross that
target's escape edge to a residual square.
Every internal free chord of \(D\) crosses the
run in (1), since the only possible free pairs
wholly on either side are old-cycle edges.
Thus all internal free chords are on the
site-face side and cannot interlace there.

Consider the free slots preceding \(L\) in this
local interval: \(e_0\), the \(t\) short-block
pairs, and \(o,h_1,i_1\). They contain equally
many vertices of the two bipartition colours.
No matching edge from this prefix can reach a
later block across \(L,R\), and no target vertex
is free. Thus the number of internal matching
edges across the run is even, with equally many
odd and even endpoints on its left. There are
only three left free slots, so \(c=0\) or \(2\).
When \(c=2\), the left endpoints must be
\(h_1\) and one of \(o,i_1\), while the right
endpoints must be \(i_2\) and one of \(h_2,e\).
The chord \(h_1i_2\) is therefore compulsory.
The other candidate is one of
\[
oh_2,\quad oe,\quad i_1h_2,\quad i_1e.            \tag{4}
\]
On the site-face side, \(oh_2\) interlaces
\(h_1i_2\), as does \(i_1e\). The two
noninterlacing choices are precisely (2).

Suppose first \(c=0\). The target run separates
the left and right free matching groups. The
left group is
\[
e_0,(o_1,e_1),\ldots,(o_t,e_t),o,h_1,i_1;
\tag{5}
\]
the right group is its old-cycle reflection,
starting at \(h_2,i_2,e\), passing through the
\(u\) short blocks, and ending at \(o_R\).
Within each group there is no usable same-block
free chord. All its free matching edges join
different blocks, lie in the opposite-side
disk, and do not interlace. The short-block
skipping and two-edge-cut argument of Note 208
forces its ordinary chain except for one link
\(E_sO_s\), replaced by
\[
E_s,i_k,h_k,O_s,\qquad k=1\ \text{or}\ 2.       \tag{6}
\]
The left and right replacements use disjoint
vertices and edges. They make one spanning
free \(x\)-to-\(v\) path, while Note 196's
target-and-square path keeps its edge \(LR\).
Their union is a marked Hamilton cycle.

Suppose next that the local pair in (2)
is \(oe,h_1i_2\). The remaining \(i_1\)
must match a free even slot on the left,
and \(h_2\) a free odd slot on the right;
cross-block edges cannot cross the target
run. The noncrossing skipping rule forces
all short-block links to be standard and
the two boundary matches to be
\[
e_ti_1,\qquad h_2o_{\rm first\ right},           \tag{7}
\]
with \(e_t=e_0\) if \(t=0\) and the right
slot equal to \(o_R\) if \(u=0\). The
segment
\[
e_t,i_1,h_1,o,a,b,e,i_2,h_2,
  o_{\rm first\ right}                            \tag{8}
\]
is Note 224's spanning local free path.
The target pair \(LR\) remains on the
unchanged target-and-square path.

Finally suppose the local pair is
\(h_1i_2,i_1h_2\). The ordinary slots on
each side follow their standard chain,
by the same skipping rule. The only
vertices absent from Note 196's two
\(x\)-to-\(v\) paths are
\(h_1,i_1,h_2,i_2\). The target path
contains \(LR\), because those transition
targets are consecutive on \(C\) and
belong to the even-starting old-cycle
matching. Replace that edge by (3).
Its consecutive edges are
\[
Li_1\in C,\quad i_1h_1\in C,\quad
h_1i_2\in M,\quad i_2h_2\in C,\quad
h_2R\in C.
\]
The first and last are available because
(1) has exactly one target pair between
the vacancies. The replacement visits
all four missing slots once, leaves
the path endpoints \(x,v\) unchanged,
and produces a marked Hamilton cycle
with the ordinary free path. Note 001
lifts every marked parent cycle above
through the legal site expansion;
Note 178 restores longer lobes.
\(\square\)

**A realized target detour.** The second pair
in (2) occurs in a 26-vertex Barnette
parent with \(\ell=2,r=1,t=u=0\).
Take the old cycle in the following
consecutive order:
\[
\begin{array}{ll}
B_0:&x,R_2,e_0,y,\\
D:&a,o,h_1,i_1,L_2,R_1,h_2,i_2,e,b,\\
B_2:&u,o_R,L_1,v,\\
S_1:&\alpha_1,\gamma_1,\delta_1,\beta_1,\\
S_2:&\alpha_2,\gamma_2,\delta_2,\beta_2,
\text{ returning to }x .
\end{array}                                          \tag{9}
\]
Add the complementary perfect matching
\[
\begin{split}
M={}&\{xy,uv,ab,\alpha_1\beta_1,\alpha_2\beta_2,
\delta_1R_1,\delta_2R_2,\gamma_1L_1,\gamma_2L_2\}\\
&\cup\{e_0o,eo_R,h_1i_2,i_1h_2\}.               \tag{10}
\end{split}
\]
Every pair has opposite old-cycle parity.
Draw \(xy,ab,uv,\alpha_j\beta_j,h_1i_2,i_1h_2\)
on the site-face side; the last two
are nested inside \(ab\). Draw all
other chords on the opposite side.
The escape chords are nested in the
order \(R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1\);
\(e_0o\) and \(eo_R\) fit in its two
disjoint gaps. Hence the graph is
simple, plane, cubic and bipartite,
and \(xy,uv\) are cofacial.

Its matching-chord interlacement
graph is connected. One connected
subgraph contains
\[
xy-e_0o-ab-eo_R-uv-\gamma_1L_1-
\alpha_1\beta_1-\delta_1R_1-ab-
\gamma_2L_2-\alpha_2\beta_2-\delta_2R_2-xy,
\tag{11}
\]
and both \(h_1i_2\) and \(i_1h_2\)
interlace \(L_2\gamma_2\). These are
all thirteen matching edges. As in
Note 217, a cubic Hamiltonian graph
with connected matching interlacement
has no two-edge cut, hence is
three-connected. The standard site
expansion is legal by Note 217's cut
projection, and the 30-vertex child
is Hamiltonian by (3).
\(\square\)

This theorem requires exactly one occupied
target pair between the two vacancies in
their block. Longer intervening target
runs, target runs outside the two
vacancies in their block, vacancies in
different target-bearing blocks, outer
vacancies, target-order defects, gaps,
and nonsquare residual cycles remain
outside its scope.
[Note 229](229-concentrated-target-runs-admit-a-two-path-hamilton-route.md)
subsequently handles arbitrarily long intervening runs when all
nonfinal targets lie in this vacancy block.
