> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two adjacent unary pairs close the three-root chord-free equality profile

In the three-root two-unary row of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md), suppose both marked unary nodes assign their two direct special positions consecutively on the old Hamilton cycle. The equality charge supplies a wrapper square whenever two such old edges cut the same root cycle.

Use the order, cycles \(D=C_1\cup C_2\cup C_3\), and outside path \((u,w_0,\beta,\alpha,w_*,v)\) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md). Let \(d_1,d_2\) be the two adjacent-direct-special old edges, \(E\) the square-supported old edges of all two-special leaves, and \(M\) the face matching of all special positions except the site ports \(u,v\). As in [Note 484](484-mixed-unary-three-root-chord-free-equality-profile-is-hamiltonian.md), equality gives each marked unary node two consecutive plain-unary ancestors.

**Two-adjacent-pair theorem.** The parent has a Hamilton cycle containing both site edges, and every legal expanded child in this profile is Hamiltonian. The marked nodes may be in the same or different roots, disjoint or nested.

**A replacement square.** If \(d_1,d_2\) lie in one root cycle \(C\), deleting them divides \(C\) into two old arcs \(X,Y\). The ordinary intervals of the two marked nodes are laminar. Choose a node whose interval contains exactly one of \(d_1,d_2\): either node if disjoint, the inner one if nested. Let its core chord be \(hj\) and its immediate plain-unary parent chord \(HJ\). Their old rail edges \(Hh,jJ\) lie one in \(X\) and one in \(Y\). The two ordinary chords \(HJ,hj\) are unused by \(D\), since the selected parent is not the root chord, and their four ordinary endpoints lie outside all leaf-square supports. Thus
\[
                         Hh,\ jJ\quad\longmapsto\quad HJ,\ hj
\tag{1}
\]
is a valid square switch joining the two arcs whenever they belong to different current components. It avoids both \(d_i\) and all site edges. This is the local switch of [Note 471](471-two-adjacent-unary-pairs-always-splice-at-chorded-equality.md), applied to whichever root cycle contains the two nodes; closure through escape vertices does not alter its four-vertex support.

**Proof for connected \(K\).** Put
\[
                       F=(D-E-\{d_1,d_2\})\cup M .
\tag{2}
\]
It has one \(u\)--\(v\) path and some cycles. If \(d_1,d_2\) lie in different roots, each of the three cycles \(C_i\) remains connected after deletion of at most one \(d_i\). Since the root face graph \(K\) is connected, \(F\cup E=(D-\{d_1,d_2\})\cup M\) is connected. The leaf-square switches of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) absorb every cycle into the \(u\)--\(v\) path.

If \(d_1,d_2\) lie in the same root, the two old arcs \(X,Y\) and the other whole root cycles form at most two components in \(F\cup E\): \(K\) attaches every other root to \(X\) or \(Y\) through face chords, possibly joining them already. If it joins them, use only leaf-square switches. Otherwise apply (1) to merge the two components, then use leaf-square switches to absorb all remaining cycles into the unique \(u\)--\(v\) path. All square supports are disjoint, so the chosen switches remain available. In either case the outside path \((u,w_0,\beta,\alpha,w_*,v)\) closes a parent Hamilton cycle through the site edges.

**Proof for disconnected \(K\).** By Note 456, both site ports lie in one isolated end root \(W\), and all its other special positions are matched internally. If \(W\) contains zero or one of \(d_1,d_2\), its old root cycle with those edges deleted remains connected; the two-terminal square-switch theorem of Note 458, or the one-unsupported-edge version of [Note 459](459-one-adjacent-nonleaf-pair-splices-and-102-vertex-failures-must-split.md), gives a spanning \(u\)--\(v\) path in \(W\). If \(W\) contains both \(d_i\), apply the replacement square (1) inside \(W\) if its two old arcs are not already joined by internal face matching edges. Leaf-square switches then absorb the remaining cycles into a spanning \(u\)--\(v\) path. The exterior path (4) or (5) of Note 456 covers every vertex outside \(W\) and closes that path through the site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the marked parent cycle to the legal child. \(\square\)

Together with Note 484, a non-Hamiltonian chord-free child at \(c=5f-8\), if one exists, must have the three-root profile in which **both** marked unary nodes split their direct special positions across their child words. This is a necessary structural restriction, not a Barnette counterexample.
