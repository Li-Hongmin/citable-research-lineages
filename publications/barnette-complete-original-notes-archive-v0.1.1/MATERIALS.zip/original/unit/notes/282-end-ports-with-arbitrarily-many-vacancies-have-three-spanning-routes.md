> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# End ports with arbitrarily many vacancies have three spanning routes

[Note 281](281-mixed-port-pairs-and-vacancy-cycles-have-three-spanning-routes.md)
gives three four-port states when each missing ordinary link
belongs to an alternating component with one vacancy pair.
A component may contain any number of vacancy pairs if its
port is the first or last atom. The cap route follows one
long old-cycle arc; the crossed route folds only the gap
before the final vacancy. This removes the one-vacancy
restriction for separated missing links.

Use the compressed, gapless, tight-target all-square opening
of Notes [196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
and [278](278-missing-chain-ports-separate-and-three-free-vacancies-are-hamiltonian.md).
All vacancies lie in distinct target-free internal face-chord
blocks. In one free group, let \(J\) be the indices of its
missing ordinary links \(P_s=e_so_{s+1}\). Assume:

1. every port-containing part of Note 278's noncrossing
   atom partition has its unique port at one end of the
   part's atom order; its other atoms are vacancies;
2. if \(P_s\) lies left of its part's vacancies, \(B_s\)
   is a short target-free internal block; if it lies right,
   \(B_{s+1}\) is such a short block;
3. distinct missing-link indices satisfy \(|s-t|\ge2\);
4. the ordinary links attaching the group's full internal
   target-free block interval to its endports are retained.

Port-free parts may be arbitrary noncrossing vacancy cycles.
There is no bound on the number of vacancies in one port part,
the number of parts, or their nesting depth.

**End-port routing theorem.** The full target-free internal
interval \(D=B_a,\ldots,B_b\) has the same vertex-spanning
three-state signature as Notes 275 and 281:
\[
\begin{array}{ll}
X(D):&a_a\longleftrightarrow b_b,\quad
       o_a\longleftrightarrow e_b;\\
K(D):&a_a\longleftrightarrow o_a,\quad
       e_b\longleftrightarrow b_b;\\
S(D):&o_a\longleftrightarrow e_b.
\end{array}                                               \tag{1}
\]
If all other free groups have ordinary-endport spanning
routes, the parent has a Hamilton cycle containing both
site edges and its legal expanded child is Hamiltonian.

**Proof: one prime port part.** Reflect if needed and write
its atoms as
\[
 P_s<V_{k_1}<V_{k_2}<\cdots<V_{k_m},
 \qquad m\ge1.                                        \tag{2}
\]
The source block \(B_s\) is short. The matching edges
of this part are
\[
 e_sI_{k_m},\qquad o_{s+1}H_{k_1},\qquad
 I_{k_t}H_{k_{t+1}}\ (1\le t<m).                     \tag{3}
\]
The adjacent old-cycle edges rule out \(k_1=s+1\),
so \(F=B_{s+1},\ldots,B_{k_1-1}\) is nonempty.
For each \(t<m\), let
\(G_t=B_{k_t+1},\ldots,B_{k_{t+1}-1}\), which may
be empty. Every atom in one of these gaps belongs to a
part closed in that gap by noncrossing; the gaps may
contain further port parts. Every nonempty gap inductively
has its \(S,K,X\) states; an empty gap uses its direct
retained block join. The links immediately before each
\(V_{k_t}\) and after each \(V_{k_t}\) are retained:
a missing adjacent port paired outwards would cross (3),
while a port paired inwards would require the vacant
\(B_{k_t}\) to be short. This also applies to the
last vacancy.

The ordinary straight path through \(B_s,\ldots,B_{k_m}\)
would use the absent edge \(e_so_{s+1}\) and omit the
vacancy slots of (2). Replace that edge by the alternating
detour
\[
 e_s,I_{k_m},H_{k_m},I_{k_{m-1}},H_{k_{m-1}},
 \ldots,I_{k_1},H_{k_1},o_{s+1}.                    \tag{4}
\]
Each successive pair is an edge from (3) or an old-cycle
edge \(H_{k_t}I_{k_t}\). Use the inductive \(S\) state
for every closed gap in the ordinary path. This gives
\(S\) of the prime block span.

For \(K\), leave \(e_{k_m}b_{k_m}\) as the right cap
path. The left path is
\[
\begin{split}
a_s,b_s,a_{s+1}
 &\xrightarrow{X_{\rm top}(F)}b_{k_1-1},a_{k_1},o_{k_1},
 e_{k_1-1}\\
 &\xrightarrow{X_{\rm bottom}(F)^{-1}}o_{s+1},H_{k_1}
 \xrightarrow{C\text{ forward}}I_{k_m},e_s,o_s.
\end{split}                                             \tag{5}
\]
The long \(C\)-arc from \(H_{k_1}\) to \(I_{k_m}\)
covers all later prime vacancy slots and every vertex
of every intervening gap, independent of its matching.
The first two rail traversals cover \(F\). They leave
only \(e_{k_m},b_{k_m}\), so the two paths span the
prime interval and have the cap pairing in (1).

For \(X\), the bottom path is always
\[
 o_s,e_s,I_{k_m},e_{k_m}.                            \tag{6}
\]
If \(m=1\), the other path is the explicit crossed
route (8) of Note 280, with \(X(F)\) supplying its
two rail traversals. Suppose \(m\ge2\), and put
\(p=k_{m-1}\), \(u=k_m\). Start the top path with
\[
 a_s,b_s\xrightarrow{C\text{ forward}}I_p,
 H_u,o_u,e_{u-1}.                                    \tag{7}
\]
Here \(I_pH_u\) is the final vacancy-to-vacancy edge
of (3), \(H_uo_u\) is an old-cycle edge, and
\(o_ue_{u-1}\) is a retained ordinary link.
The old-cycle arc from \(b_s\) to \(I_p\) covers
every block through \(B_p\) except the source's
\(o_s,e_s\), the penultimate block's \(e_p,b_p\),
and the blocks after \(B_p\). Thus all earlier
vacancies and all earlier nested parts are covered
without using their matching edges.

If \(u=p+1\), finish the top path from \(e_p\) by
\[
 b_p,a_u,b_u.                                       \tag{8}
\]
If \(u\ge p+2\), the last gap \(G=B_{p+1},\ldots,
B_{u-1}\) has \(X(G)\). Finish instead by
\[
\begin{split}
e_{u-1}&\xrightarrow{X_{\rm bottom}(G)^{-1}}o_{p+1},
 e_p,b_p,a_{p+1}\\
 &\xrightarrow{X_{\rm top}(G)}b_{u-1},a_u,b_u.
\end{split}                                             \tag{9}
\]
The links \(o_{p+1}e_p\) and \(o_ue_{u-1}\) are
retained, while \(e_pb_p,b_pa_{p+1},b_{u-1}a_u\)
are old-cycle edges. The two paths of \(X(G)\)
cover the gap once. Equations (6)--(9) partition the
source block, every intermediate block, and the final
vacant block exactly as required: the last block's
\(I_u,e_u\) lie on the bottom path and its
\(a_u,o_u,H_u,b_u\) on the top path. They give the
crossed pairing of (1). Reflection handles a port
right of all its vacancies.

**Proof: global composition.** The atom spans of the
noncrossing parts form a nesting forest. The short source
condition keeps every proper nested part inside a proper
block gap, as in Note 281. Two disjoint block spans could
share a short block only through consecutive ports;
condition 3 excludes that overlap. Starting with the
prime construction above, induct on the nesting forest.
Vacancy-only prime parts accept arbitrary closed gaps
with \(S,K,X\) by Note 275's explicit construction.
Finally join disjoint intervals across retained ordinary
links: \(S+S\), \(X+X\), and \(K+X\) give the three
states. This proves (1). Attach \(S(D)\) to the group
endports and use Note 273's disjoint group splice with
Note 196's fixed target-and-square path. Notes 001 and
178 lift to the legal child and restore the original
lobe lengths. \(\square\)

**Realization with an unbounded port part.** For every
\(m\ge2\), take \(\ell=1,r=m+2\), one short block
\(B_1\), one short block \(B_2\), and vacant blocks
\(B_3,\ldots,B_r\). Use the site blocks, residual square,
and old-cycle order of Note 281(8). In the complementary
matching, retain its site, face, residual-square, and
escape edges, and take the free edges
\[
\begin{split}
M_{\rm free}={}&
 \{e_jo_{j+1}:0\le j\le r,\ j\ne1\}\\
 &\cup\{e_1I_r,o_2H_3\}
 \cup\{I_jH_{j+1}:3\le j<r\}.
\end{split}                                             \tag{10}
\]
These edges form a perfect matching with the \(m\)
vacancies and the single missing link \(P_1\) in one
end-port part. They join opposite old-cycle colours.
Draw the outer edge \(e_1I_r\) around the intervening free
chords in the opposite-side disk; \(o_2H_3\) and the
successive \(I_jH_{j+1}\) edges occupy disjoint inner
intervals, each enclosing its retained standard link.
The site edges remain cofacial.

The matching-chord interlacement graph is connected:
\(e_1I_r\) meets the face chords of \(B_1,B_r\),
\(o_2H_3\) meets those of \(B_2,B_3\), every
\(I_jH_{j+1}\) meets the face chords of its endpoint
blocks, and the retained links and site/residual-square
closing chain connect these to all other matching chords.
Note 217's cut argument and Note 182's cubic lemma give
three-vertex-connectivity. Thus this is a Barnette parent
on \(6m+20\) vertices. The theorem supplies a Hamilton
cycle through both site edges and a legal Hamiltonian child
on \(6m+24\) vertices.

This theorem includes arbitrarily long mixed rainbow
components, but keeps each port at an end of its part
and requires distinct port links to be nonconsecutive.
Note 281 treats consecutive ports when their parts each
contain only one vacancy.
It does not cover a port lying between two vacancies of
its part, a vacant block at the port's required short
side, or the other excluded opening shapes of Note 281.
It does not settle Barnette's conjecture.
