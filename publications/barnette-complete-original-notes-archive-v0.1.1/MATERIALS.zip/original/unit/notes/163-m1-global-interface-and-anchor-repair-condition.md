> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The exact \(M=1\) interface and the anchor-repair condition

[Note 160](160-four-mandatory-boundary-rows-give-an-exact-carrier-prefilter.md)
gives a ten-term lower bound for an annular four-port splice.  This note
records the sharp conditional consequence and the remaining global gap.

## 1. Unique crossing forces a bridge

For the complete rooted target family \(\mathcal T_e\), let
\(\Gamma_{g_1}(\mathcal T_e)\) join two targets whose symmetric difference is
one alternating cycle.  The incidence-vector telescoping identity in
[Note 162](162-cycle-space-boundary-for-rooted-crossing-cut.md) implies that
every exchange-graph cycle crosses the \(g_1\)-sector cut an even number of
times.  Hence a nonempty crossing set of size one is necessarily a
sector-changing bridge.

## 2. Exact annular \(M=1\) certificate

Cut a root-disjoint facial square with cyclic ports \(0,1,2,3\), deleting
opposite edges \(q_0,q_2\).  Suppose the complete factor boundary family
contains a clean state-empty row \(N_0\) with complement pairing
\(01\mid23\), and a clean state-\(A_0=\{0,1\}\) row \(N_1\) whose
complement is the \(23\)-path, with

\[
d_B(N_0,N_1)=01+0\text{ closed components}.
\tag{1}
\]

For compatible carrier rows, the ten nonnegative crossing classes of
Note 160 are

\[
M_4=s_Z+s_0+s_1+s_3+p_{Z0}+p_{Z1}+p_{Z3}+p_{01}+p_{03}+t_{13}.
\tag{2}
\]

The designated pair gives \(p_{Z0}\ge1\).  Therefore the global hypothesis
\(M=|E\Gamma_{g_1}(\mathcal T_e)|=1\), whenever this convolution is present,
forces

\[
p_{Z0}=1,\qquad
s_Z=s_0=s_1=s_3=p_{Z1}=p_{Z3}=p_{01}=p_{03}=t_{13}=0.
\tag{3}
\]

This is necessary, not sufficient: \(M_4=1\) need not represent all rows of
the full rooted family.

## 3. Forced deletion and APR

Let \((K_Z,K_0)\) be the unique \(p_{Z0}\) pair.  The \(01\mid23\)
complement pairing of \(K_Z\) forces at least one of \(q_1,q_3\) into
\(K_Z\); otherwise that square edge is an entire complementary path
component.  Deleting an occupied \(q_i\) gives an actual state-\(A_i\) row
\[
D_i=K_Z-\{q_i\}
\]
with carrier atom \(02+0\) for \(i=1\), or \(13+0\) for \(i=3\).

Define **APR** (anchor-preserving rooted repair) to mean that for some
occupied \(q_i\) there is an actual carrier row \(K\), in the sector of
\(K_Z\), such that \(K\) joins rootedly with the corresponding deletion row
and
\[
d_C(K_0,K)=02+0\quad(i=1),\qquad
d_C(K_0,K)=13+0\quad(i=3).
\tag{4}
\]

Then APR creates a crossing with a different factor-coordinate pair from
the designated edge, so

\[
\boxed{\mathrm{APR}\Longrightarrow M\ge2.}
\tag{5}
\]

Thus any annular \(M=1\) realization must fail APR on every occupied
deletion branch and must satisfy all nine zero conditions in (3).

## 4. Sharpness and scope

The deletion row is an actual perfect matching, but rooted compatibility is
a complement-connectivity condition.  The legal-wide carrier of
[Note 154](154-a-crossing-bridge-can-be-an-isolated-mixed-component.md)
has both literal deletion branches nonrooted, showing that APR is not
implied by planarity, cubicity, bipartiteness, brace extendability, or
legal-wide geometry.  Conversely, deleting one compatible carrier row in the
order-\(16\) family of Note 160 leaves a one-defect \(M=1\) system; the first
lost axiom is completeness of the common perfect-matching family.

Therefore the strongest current conclusion is:

\[
\boxed{
\text{Every annular four-port realization satisfying APR has at least two
sector crossings.}}
\]

This does not prove the unrestricted legal-wide implication and does not
produce a real legal-wide \(M=1\) brace.  The missing theorem is a global
common-perfect-matching incidence/compensation statement, not another parity
or local exchange-interpolation lemma.
