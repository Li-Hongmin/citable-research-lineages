> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Split gaps require a target-bearing vacancy block

[Notes 255--256](256-a-single-two-slot-gap-is-impossible-at-second-surplus.md)
reduce the positive-gap all-square second surplus to two
singleton gaps and one unoccupied eligible block position.
A target-free vacancy block cannot support this last shape:
its only possible face-side matching chord pairs its outer
free slots, after which the two gap slots are forced to its
inner free slots and close a two-edge cut.

Use the compressed opening of Notes 195 and 255. Let
\(\ell,r\ge1\), \(f=4r+6\), and suppose the two gap slots
lie in distinct gaps \(G_a,G_b\), \(a<b\). Denote them by
\(g=E\) and \(h=O\) in main-segment order. Thus
\(\sigma=\sum k_i-(\ell-1)=1\). Let \(B_k\) contain the unique
eligible position not occupied by a nonfinal \(L\)-target.

**Target-bearing vacancy theorem.** If \(B_k\) contains no
escape target, the opening cannot occur in a three-connected
cubic bipartite plane graph. Hence every surviving split-gap
opening has an escape target in its unique vacancy block.

**Proof.** Since \(B_k\) has no target, every one of its \(k_k\)
eligible positions is vacant. Thus \(k_k=1\) and its four
interior slots are all free. Write them \(U,A,B,V\) in
old-cycle order. Their colours alternate; \(U,V\) have
opposite colours, while \(A,B\) are adjacent on \(C\).
The only possible non-cycle free matching edge within
\(B_k\) is \(UV\).

Every other block has all its eligible positions occupied
by nonfinal \(L\)-targets. In such a block, the local
free-slot list and even-prefix barrier from
[Note 255](255-capacity-saturation-excludes-every-positive-gap.md)
exclude a same-block free matching edge: the only extra
free odd slot comes after the last target of a nonadjacent
transition, so at most one free slot lies on one side
of any target; a pair not straddling a target is adjacent
on \(C\) or same-coloured. If the first target is not
in \(B_0\), that block is target-free and must be short:
any eligible position there would be a second vacancy.
The last target cannot move to an earlier block's final
slot by Note 197's endpoint barrier, and occupying
another eligible slot would likewise be a second
vacancy. Hence the same conclusion holds at the sites.
By Note 255's gap-face-chord obstruction,
\[
UV\in M                                                   \tag{1}
\]
on the designated-face side. All other free-slot matching
chords lie in the opposite disk and do not interlace.

The two gap slots cannot match each other. If a target lies
between \(g,h\), their chord is forbidden by
[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md).
Otherwise every complete block between their gaps is
target-free and short, except possibly \(B_k\). Its chord
\(UV\), if present, has both endpoints inside that complete
block. Noncrossing of the remaining opposite-side chords
would make the whole intervening block interval closed
under \(M\), with only two old-cycle edges leaving it.
This contradicts three-connectivity.

Each gap slot must therefore match a free block slot.
For any such chord, Note 255's parity count gives an odd
number of free slots strictly inside it, provided no
target is straddled. Since (1) is the sole matching edge
on the other side, exactly one endpoint of \(UV\) must
lie strictly inside that chord. A gap lies outside
\(B_k\); hence its block mate must lie strictly between
\(U,V\). The two middle slots \(A,B\) have opposite
colours, so \(g,h\) pair to them in the only
colour-compatible way. Their chords cannot straddle
targets, and every complete block between either gap
and \(B_k\) is consequently short and target-free.

There are three block orders. If \(B_k\) precedes both
gaps, the orientation is forward, and the opposite-side
chords are \(gB,hA\). The latter encloses the former
and every complete intervening block. All matching
edges of the consecutive interval from \(B_k\) through
\(h\) are internal: \(UV,gB,hA\) use the exceptional
slots, all fixed face or site chords are internal, and
an opposite-side chord from an intervening block to
outside would interlace \(hA\). The interval has only
two departing old-cycle edges. If \(B_k\) follows both
gaps, reflection gives the same contradiction.

If \(B_k\) lies between the gaps, it is reversed.
The forced opposite-side chords are \(gA,Bh\), disjoint
on that side. Blocks between \(g,B_k\) are trapped
inside \(gA\), and blocks between \(B_k,h\) inside
\(Bh\); none can send a matching edge outside.
Together with \(UV\), the consecutive interval
from \(g\) through \(h\) is matching-closed. Again
only two old-cycle boundary edges leave, a
contradiction. These orders exhaust the placements
of \(B_k\). \(\square\)

**Free-vacancy corollary.** In any surviving split-gap
opening, the unique eligible position not occupied by a
nonfinal \(L\)-target is free; it cannot be occupied by
\(L_1\). Indeed, if \(L_1\) occupied that position, every
other eligible position would be saturated. The local
slot lists of Note 255 exclude same-block free chords
outside the block of \(L_1\). In that block \(L_1\) is the
last target: in a forward block at most its first free
odd slot precedes \(L_1\), and in a reversed block at
most its final free odd slot follows \(L_1\). At each
earlier target the same one-sided bound holds; a
nonadjacent transition source in that block would put
its next \(R\)-target in a later block and hence cannot
precede \(L_1\) there. Even-prefix matching parity
therefore excludes every same-block free chord across
a target, while free slots not separated by a target
are adjacent or same-coloured. This contradicts
Note 255's gap-face-chord obstruction. \(\square\)

These are necessary conditions, not a Hamilton theorem
for all split-gap openings. The remaining all-square
second-surplus interface has a free vacant eligible
position sharing its block with an occupied escape
target. Openings with nonsquare residual cycles and
the general Barnette conjecture remain undecided.
