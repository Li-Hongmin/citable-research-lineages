> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Multi-component three-witnesses reduce to Hall plus a tree quotient

The order-\(26\) counterexample in [Note 027](027-full-hamilton-family-saturation-does-not-force-a-good-bridge.md)
rules out forcing a common-complement connector from two *single-cycle*
Hamilton exchanges. Allowing arbitrary alternating-component families does
not remove the selection problem, but it gives an exact and strictly more
general formulation. The remaining obstruction has two independent stages:
a Hall obstruction in a restricted graph and a tree-quotient obstruction
inside its perfect-matching fibre.

This note is an exact reduction, not a proof that the required three witnesses
always exist. The fixed example shows that both obstructions occur and that a
successful repair can require two simultaneous cycle flips.

## The unrestricted assertion

Let \(F\) be a plane cubic bipartite brace with global \(H^{+-}\). At a
legal ordered \(P\)-regime site write

\[
p=uv,\qquad h=za,
\]

and let \(V_{ij}\) be the complete family of Hamilton-complement perfect
matchings with \((p,h)\)-membership \(ij\). The unrestricted three-witness
assertion asks for

\[
L\in V_{01},\qquad W\in V_{00},\qquad R\in V_{10},
\tag{1}
\]

and a perfect matching \(T\) of \(F-\{u,a\}\) such that
\(F-\{p,h\}-T\) is a Hamilton \(v\)-\(z\) path and

\[
T\setminus W\subseteq E(F)\setminus(L\cup W\cup R).
\tag{2}
\]

No bound is imposed on the number of components of \(L\triangle W\) or
\(W\triangle R\).

## Fixed-target factorisation

Fix \(W\) and a genuine target \(T\), and put

\[
S=T\setminus W.
\tag{3}
\]

Because \(S\cap W=\varnothing\), condition (2) is equivalent to

\[
S\cap(L\triangle W)=S\cap(R\triangle W)=\varnothing.
\tag{4}
\]

Thus, after \((W,T)\) is fixed, the two sides remain independent even when
their symmetric differences have several alternating components. One must
choose a member of \(V_{01}\) avoiding \(S\) and, independently, a member of
\(V_{10}\) avoiding \(S\).

There is also a precise dual interpretation. Let \(\Delta=F^*\), normalize
the admissible dual two-colourings of two Hamilton-complement matchings
\(W,M\) at one root, and define

\[
D(W,M)=\{x:\chi_W(x)\ne\chi_M(x)\}.
\]

Then

\[
W\triangle M=\delta_\Delta(D(W,M))^*,
\]

and the number \(k(W,M)\) of alternating cycles is exactly

\[
\boxed{
k(W,M)=c(\Delta[D])+c(\Delta[V(\Delta)\setminus D])-1.}
\tag{5}
\]

Indeed, the dualized cut is a disjoint union of \(k(W,M)\) cycles, and its
cycle-space dimension is the displayed cographic rank difference. The
single-cycle case of Note 026 is precisely the special case in which both
cut shores are connected.

For a target, \((T\cup\{p,h\})^*\) is a spanning tree. Hence
\((T\setminus W)^*\) is a forest. Contracting this forest turns the allowed
disagreement sets into arbitrary rooted cuts of the quotient, rather than
the rooted bonds of the single-cycle theory.

## A fixed triple is a restricted matching problem

For a triple \((L,W,R)\), define

\[
K= W\cup\bigl(E(F)\setminus(L\cup R)\bigr),
\qquad K_0=K-\{u,a\}.
\tag{6}
\]

An edge of \(T\cap W\) already belongs to \(K\), while an edge of
\(T\setminus W\) belongs to \(K\) exactly when it is absent from both \(L\)
and \(R\). Therefore

\[
\boxed{\text{condition (2)}\iff T\subseteq K.}
\tag{7}
\]

The two bipartition shores of \(K_0\) have equal size, so \(K_0\) has a
perfect matching exactly when it satisfies Hall's inequalities. For any
\(T\in\operatorname{PM}(K_0)\), set

\[
Q_T=F-\{p,h\}-T.
\]

The vertices \(v,z\) have degree one in \(Q_T\), and all other vertices
have degree two. Since \(Q_T\) has \(|V(F)|-1\) edges, the following are
equivalent:

\[
Q_T\text{ is connected}
\iff Q_T\text{ is a Hamilton }v\text{-}z\text{ path}
\iff (T\cup\{p,h\})^*\text{ is a spanning tree}.
\tag{8}
\]

Consequently,

\[
\boxed{
(L,W,R)\text{ succeeds}
\iff
\exists T\in\operatorname{PM}(K_0)\text{ with }Q_T\text{ connected}.}
\tag{9}
\]

This separates the two genuine obstructions:

1. \(K_0\) can fail Hall;
2. \(K_0\) can have perfect matchings while every residual \(Q_T\) retains
   at least one cycle.

## Exact simultaneous-flip quotient

Fix \(T_0\in\operatorname{PM}(K_0)\). Every other matching in the same
fibre is obtained by flipping a vertex-disjoint family \(\mathcal C\) of
\(T_0\)-alternating cycles. Write

\[
A=E(\mathcal C)\setminus T_0,\qquad
C=E(\mathcal C)\cap T_0.
\]

Then

\[
Q_{T_0\triangle E(\mathcal C)}=(Q_{T_0}-A)+C.
\tag{10}
\]

Contract every component of \(Q_{T_0}-A\) to form a quotient multigraph
\(\Theta_{\mathcal C}\), retaining loops, and use the edges of \(C\) as its
edges. Direct contraction gives

\[
\begin{aligned}
c(Q_{T_0\triangle E(\mathcal C)})&=c(\Theta_{\mathcal C}),\\
\mu(Q_{T_0\triangle E(\mathcal C)})
&=\sum_P\mu(P)+\mu(\Theta_{\mathcal C}),
\end{aligned}
\tag{11}
\]

where \(P\) ranges over the contracted pieces and \(\mu\) is cycle rank.
The flipped matching is a target exactly when every piece and the quotient
are trees. This is an exact criterion for simultaneous flips, not a
one-cycle descent heuristic.

## The order-\(26\) example separates both obstructions

Use the graph and legal site of Note 027. Its complete Hamilton family has

\[
(|V_{01}|,|V_{00}|,|V_{10}|)=(2,34,4),
\]

so there are \(272\) unrestricted triples. They split exactly as follows:

\[
\begin{array}{c|r}
\text{restricted outcome}&\text{triples}\\ \hline
\operatorname{PM}(K_0)=\varnothing&176\\
\operatorname{PM}(K_0)\ne\varnothing,
\text{ but every }Q_T\text{ is disconnected}&72\\
\text{at least one target}&24.
\end{array}
\tag{12}
\]

The \(24\) successful triples yield \(30\) triple-target incidences. Their
alternating-component profiles are

\[
\begin{array}{c|rrrrrrr}
(k(L,W),k(W,R))&(1,2)&(1,3)&(2,1)&(2,2)&(2,3)&(3,2)&(3,3)\\ \hline
\text{incidences}&10&3&1&4&6&3&3.
\end{array}
\tag{13}
\]

Among the \(28\) single-cycle \((1,1)\) bridges, \(20\) fail Hall and the
other \(8\) pass Hall but fail the tree quotient. Only three of the twelve
genuine targets are supported by any unrestricted triple.

The sharp \((1,2)\) certificate is genuinely simultaneous. Its restricted
fibre has fifteen perfect matchings and three targets. One matching
\(T_0\) leaves residual component orders \((4,4,18)\); the selected target
differs from it on two disjoint \(C_4\)'s. Flipping either square alone
leaves \((4,22)\), while flipping both produces the Hamilton path on all
\(26\) vertices.

## Remaining assertion

The unrestricted mechanism is therefore equivalent to the following
selection statement:

\[
\boxed{
\begin{gathered}
\text{some }(L,W,R)\in V_{01}\times V_{00}\times V_{10}
\text{ makes }K_0\text{ pass Hall},\\
\text{and its restricted perfect-matching fibre contains a tree-quotient state.}
\end{gathered}}
\tag{14}
\]

The order-\(26\) object proves that neither clause holds for an arbitrary
triple, but it is not a counterexample to (14), because \(24\) triples
succeed. Mere layer nonemptiness, bounded component count, one-cycle
exchange connectivity, or target existence alone cannot decide the
selection. A positive proof must couple the Hall choice to connectivity
inside the same restricted matching fibre.

The fixed-instance certificate is reproduced by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/verify_multicomponent_three_witness_boundary.py
```

with terminal marker

```text
MULTICOMPONENT_THREE_WITNESS_REDUCTION_VERIFIED
```
