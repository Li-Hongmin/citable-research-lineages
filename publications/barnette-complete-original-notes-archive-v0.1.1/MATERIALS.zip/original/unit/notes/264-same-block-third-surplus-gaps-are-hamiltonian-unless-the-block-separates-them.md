> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Same-block sharp gaps are Hamiltonian unless the block separates them

[Note 263](263-positive-gap-bound-is-sharp-for-every-lobe-and-face-chord-count.md)
constructs sharp positive gaps with both vacancies in one
target-bearing block. When their block lies outside the two
gap slots, its last target in a suitable orientation cannot
be an \(L\)-target; if it is an \(R\)-target, the only
possible interface is the cube tail of
[Note 262](262-every-sharp-target-free-positive-gap-opening-is-hamiltonian.md).

Let \(G\) be a Barnette parent with a Hamilton cycle \(C\)
avoiding disjoint cofacial matching site edges \(q=xy,p=uv\).
Select a legal all-square facial opening with \(\ell,r\ge1\)
and
\[
 f=4r+8,\qquad \sigma=2,\qquad T=2.                 \tag{1}
\]
Assume both vacant eligible positions belong to one block
\(B=[a,b]_C\), and this block does not lie strictly
between two singleton gaps. Equivalently, it lies before
both gap slots or after both of them on the main segment.

**Same-block outside-gap theorem.** The parent \(G\) has a
Hamilton cycle containing both site edges; consequently
its legal site-expanded child is Hamiltonian. If \(B\) is
target-bearing, orient the main segment so that \(B\)
precedes both gap slots. Its last escape target is then
necessarily some \(R_j\), and the two gap slots form one
gap immediately following \(B\). If its interior slots are
\(z_1,\ldots,z_{2K+2}\), where \(K=k_B\), then
\(R_j=z_{2K-3}\) and, writing
\[
(w_2,w_3,w_4,w_5,w_6)
 =(z_{2K-2},z_{2K-1},z_{2K},z_{2K+1},z_{2K+2}),
\tag{2}
\]
the last five slots and the gap slots \(g,h\) have the
forced complementary-matching edges
\[
 w_3w_6\quad\hbox{on the designated-face side},
 \qquad w_5g,\quad w_4h\quad\hbox{on the opposite side}.
\tag{3}
\]
Deleting \(w_3,w_4,w_5,w_6,g,h\) and restoring
\(bw_2,bc\), where \(c\) begins the next block, gives a
Barnette equality opening with the same \(\ell,r\).
The target-free case has the same conclusion and patch by
Note 262.

**Proof.** Reverse the main segment and interchange the
site edges if \(B\) originally follows both gap slots;
this is the opening reflection used in Note 261 and
preserves \(\ell,r,\sigma,T\), cofaciality and the marked
Hamilton question. Hence assume \(B\) precedes both
gap slots. Compress the lobes as in Note 178. If \(B\)
is target-free, Note 262 applies. Suppose it contains an
escape target. Since both vacancies are in \(B\), all
other blocks are saturated. The gap-edge localization
lemma of Note 258 sends both gap slots to free vertices
of \(B\).

Suppose first that the last target in \(B\) is \(L_j\).
Both gap mates lie after \(L_j\), since a cross-atom
chord starting before it and ending at a later gap slot
would straddle its escape edge, contrary to Note 203.
The chord to the later gap slot \(h\) also excludes any
target between \(B\) and \(h\).

If \(j\ge2\), the next target \(R_{j-1}\) is therefore
in a block after \(h\). Every such block is forward,
because all two gap slots precede it, and saturated,
because both vacancies are in \(B\). The target
\(R_{j-1}\) must be its block's first interior slot:
if it were a later odd slot, the second eligible even
slot would already hold a nonfinal \(L\)-target between
\(L_j\) and \(R_{j-1}\). Take the main prefix ending
immediately before that destination block, together with
the residual-square suffix \(S_j,\ldots,S_\ell\).
All fixed matching edges in the set are internal, while
any free matching chord leaving it lies opposite the
designated face and would straddle \(R_{j-1}\). This is
the prefix-cut argument of Notes 193 and 197: the set
has only two departing cycle edges, a contradiction.

If \(j=1\), Note 197's endpoint barrier excludes \(L_1\)
from the final interior slot of this nonfinal block.
It occupies one of the two vacant eligible positions.
At most one eligible even position follows it, so there
are at most four free slots after \(L_1\) in \(B\).
Two are the gap mates. With only two suffix slots, no
face-side chord can straddle a gap mate, contradicting
Note 258. With four, the two remaining suffix slots
must both be used by face-side chords: a chord entirely
after \(L_1\) uses both, while a chord crossing \(L_1\)
requires a second such chord by Note 255's even-prefix
parity and again uses both. Hence no free slot after
\(L_1\) in \(B\) can match a later block. Every gap
slot is matched to \(B\). A free slot in a complete block
between \(B\) and \(h\) lies under the chord to \(h\),
so it cannot match beyond \(h\) without crossing that
chord. A free slot before \(L_1\) cannot match beyond
\(h\) without straddling \(L_1\). Therefore the nonempty
main-segment suffix after \(h\), consisting of complete
blocks through \(v\), is closed under the complementary
matching. Only its two boundary cycle edges leave it,
again contradicting three-connectivity.

Thus the last target in \(B\) is some \(R_j\). No gap
chord can start before \(R_j\): it would be a cross-atom chord
straddling that escape target, contrary to Note 203.
Thus both gap mates lie strictly after \(R_j\) in \(B\).

No target follows \(R_j\) inside \(B\), so every eligible
even slot after it is vacant. The block is forward because
no gap slot precedes it. Write \(R_j=z_{2m+1}\), with
\(0\le m\le K\). Since there are only two vacancies,
\(K-m\le2\). The free suffix after \(R_j\) has
\(2(K-m)+1\) slots, hence either one, three or five.
It contains two distinct gap mates, so its length is at
least three.

For any escape target in \(B_i\), the number of free slots
preceding it equals its main-segment index minus the
\(2i+1\) preceding fixed block endpoints and minus the
number of earlier targets. An \(R\)-target has odd index
and an even number of earlier targets; an \(L\)-target has
even index and an odd number of earlier targets. Thus this
free-slot count is even, as in Note 255.
Every matching chord crossing \(R_j\) must be a same-block
face-side free chord: a cross-atom chord lies opposite the
designated face by Note 193 and crosses the escape edge
by Note 203; the same is true of a same-block chord drawn
on that opposite side. Therefore the number of face-side
free chords crossing \(R_j\) is even. If its free suffix
had three slots, two would be occupied as gap mates and
at most one would remain for a face-side chord crossing
\(R_j\). Parity excludes that chord. No face-side chord
could then straddle either gap mate, contradicting the
gap-edge localization lemma. Hence the suffix has five
slots, so \(m=K-2\) and \(R_j=z_{2K-3}\).

All eligible even slots before \(R_j\) are now occupied
by nonfinal \(L\)-targets. Between two successive such
targets in \(B\), the intervening odd slot must be the
next \(R\)-target: otherwise the next \(L\)-target would
precede that required \(R\)-target in the global escape
order. Thus at most the first interior odd slot of \(B\)
is free before \(R_j\). At most one face-side chord could
cross \(R_j\), and the preceding even-parity rule excludes
it. All face-side free chords straddling a gap mate lie
entirely in the five-slot suffix (2).

Name these five slots \(w_2,w_3,w_4,w_5,w_6\), with colours
\(E,O,E,O,E\); the two gap slots in their main-segment
order have colours \(g=E,h=O\). The gap mates and one
face-side chord need four distinct suffix vertices.
There cannot be two face-side chords, which would require
six such vertices. The only non-cycle opposite-colour
pairs among the suffix vertices are \(w_2w_5\) and
\(w_3w_6\). The sole face-side chord must straddle both
gap mates by Note 258. If it were \(w_2w_5\), the mates
would be \(w_3,w_4\), forcing \(w_3g,w_4h\). Their
endpoints interlace on \(C\), so these two opposite-side
chords would cross. Hence the face-side chord is
\(w_3w_6\), and colour forces \(w_5g,w_4h\), proving (3).

These latter two chords are nested. A complete block
between the two gap slots would lie under \(w_4h\).
It contains no target by Note 203 and no vacancy outside
\(B\), so it has only two free interior slots. Those
slots cannot match outside the union of the intervening
blocks on the opposite side without crossing \(w_4h\)
or \(w_5g\), and a face-side matching edge in a short
block would duplicate its cycle edge. The union would
be matching-closed and have only two departing cycle
edges, contrary to three-connectivity. Thus \(g,h\)
are consecutive slots of one gap. Similarly, any complete
block between \(B\) and that gap lies under \(w_5g\),
has no target or vacancy, and yields the same forbidden
two-edge cut. The gap immediately follows \(B\).

The six vertices in the statement now induce precisely
Note 185's incident-edge cube patch, with the labeling of
Note 262. Its inverse is simple: \(b\) is matched to
\(a\), while \(w_2,c\) are distinct vertices not already
adjacent to \(b\). Note 185 preserves the Barnette class
in reverse. The old Hamilton cycle compresses across the
patch, the selected common face replaces \(a,b,g,h,c\)
by \(a,b,c\), and the residual squares and both site
edges stay fixed. The block capacity falls by two and
the gap vanishes, so the inverse has
\((\sigma',T',f')=(0,0,4r+2)\). Note 196 supplies its
Hamilton cycle through both site edges. As in Note 262,
replace that cycle's edge \(w_2b\) by
\[
w_2,w_3,w_4,h,g,w_5,w_6,b.                           \tag{4}
\]
This visits each deleted patch vertex once and retains
both site edges. Note 001 lifts the resulting marked
cycle through the legal site expansion, and Note 178
restores all original lobe lengths. \(\square\)

This theorem includes Note 263's target-bearing sharp
constructions. In particular, if the two gap slots form
one two-slot gap and both vacancies lie in one block,
the parent and legal child are Hamiltonian. The remaining
same-block case has two singleton gaps with the vacancy
block between them. Vacancies in distinct blocks, at
least one target-bearing, are also outside this theorem.

**Separating-block necessary condition.** Suppose instead
that the two singleton gap slots satisfy \(g<B<h\) and
both vacancies lie in \(B\). Then \(B\) contains a target.
If \(gs,th\in M\), with \(s,t\in B\), then
\(s<t\), every escape target of \(B\) lies strictly
between \(s,t\), and \(B\) has at least two face-side
free matching chords.

Indeed, Note 261 excludes a target-free \(B\) between
split gaps, while
Note 258 sends both gap slots to \(B\). The chord \(gs\)
cannot straddle a target, so every target follows \(s\);
the chord \(th\) gives the opposite inequality. Thus
\(s<T<t\) for each target \(T\) of \(B\). Note 258
requires an odd number of face-side chords straddling
each of \(s,t\), while the prefix parity used above
requires an even number straddling every target. One
face-side chord would have to straddle both \(s,t\) and
therefore every target between them, a contradiction.
\(\square\)
