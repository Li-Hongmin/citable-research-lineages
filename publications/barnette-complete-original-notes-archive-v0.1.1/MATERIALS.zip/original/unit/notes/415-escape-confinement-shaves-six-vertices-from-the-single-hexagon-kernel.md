> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Escape confinement shaves six vertices from the single-hexagon kernel

The proof of [Note 414](414-every-single-hexagon-opening-with-at-most-six-face-chords-has-a-hamiltonian-child.md) uses only the placement of escape targets outside one root interval. This gives a structural Hamilton criterion independent of the number of face-side chords, and a stronger kernel bound for every hypothetical non-Hamiltonian single-hexagon opening.

Use the single trapped-hexagon setup and notation of Notes 410--414. In old-cycle order the parent is
\[
 C=(w_0,S_0^\circ,w_*,\alpha,a,b,c,d,\beta,w_0),
\]
with \(w_0,w_*\) the two outer site ports. Let \(e=4\) when all of \(a,b,c,d\) escape, and \(e=2\) when \(ad\) is the internal matching chord and only \(b,c\) escape. In either case all escape edges lie on the page opposite the selected common face. Thus, in main-target order, their hexagonal ends are \(d,c,b,a\) when \(e=4\), and \(c,b\) when \(e=2\).

**Escape-confinement theorem.** Suppose the main segment has the form
\[
             S_0=(w_0,E_L,B,E_R,w_*),                \tag{1}
\]
where \(E_L,E_R\) are possibly empty runs consisting only of escape targets and the block \(B\) contains every other internal main vertex and no escape target. Then the legal expanded child is Hamiltonian. In particular, any non-Hamiltonian child must have escape targets interspersed with nonescape internal main vertices, rather than confined to the two end runs.

**Proof.** If \(e=4\), four targets occupy the two runs, so one run contains at least two. A consecutive pair of targets is adjacent on the main cycle of the selected facial opening; the reverse-order, noncrossing escape matching sends it to adjacent vertices of the trapped hexagon. Deleting these two cycle edges and inserting the two escape edges merges the cycles into one Hamilton cycle, exactly as in Note 414. If \(e=2\) and both targets are in the same run, the same switch uses the old edge \(bc\).

It remains to consider \(e=2\) with one target in each run. Write them \(t_L,t_R\), so (1) is \(w_0,t_L,B,t_R,w_*\). The main length \(N=|S_0|\) is even because the parent cycle has \(N+6\) vertices and is bipartite. Therefore \(|B|=N-4\) is even. Index \(w_0\) by 0 along \(C\). Then \(t_L\) has odd index 1, \(t_R\) has even index \(N-2\), and the hexagonal vertices \(b,c\) have indices \(N+2,N+3\), respectively. Noncrossing on the escape page forces \(t_Lc,t_Rb\). Each of these edges joins equal index parity, contradicting bipartiteness. Thus the split arrangement is impossible, proving the theorem. \(\square\)

There is a stronger parity restriction in the chorded case \(e=2\). Its first escape target in main order must meet \(c\), whose index \(N+3\) is odd, so that target has even index. If every assignable special main position lies inside an ordinary-chord interval, all main vertices before the first escape target, after \(w_0\), form complete root intervals. Each root interval has even length, because its chord joins opposite colours. The first escape target would then have odd index \(1+\sum\text{(even root lengths)}\), a contradiction. Therefore **every chorded single-hexagon opening leaves at least two of the \(2+2f\) assignable special positions outside the ordinary forest**; after either ladder reduction, its \(m=u/2\) satisfies \(m\le f\). This assertion does not assume that the child is non-Hamiltonian.

Now alternate the two four-column ladder reductions of [Note 410](410-bounded-special-slots-give-a-finite-ladder-reduced-hamilton-interface.md). They preserve the selected opening, \(e,f\), Barnette membership and child Hamiltonicity. Let \(c\) be the remaining ordinary-chord count, \(u\le2+2f\) the number of assignable special positions inside ordinary-chord intervals, \(m=u/2\), and \(R\) the number of roots in the nonempty ordinary forest.

**Sharpened kernel theorem.** If \(f\ge1\), every doubly reduced chorded opening \((e=2)\) satisfies the first row below, without a Hamiltonicity assumption. If the child is non-Hamiltonian, its doubly reduced chord-free opening \((e=4)\) satisfies the second row:
\[
\begin{array}{c|cc}
 &c&|V(\bar G^+)|\\\hline
 e=2&\le5f-3&\le10+12f\\
 e=4&\le5f-1&\le16+12f.
\end{array}                                             \tag{2}
\]
In the chord-free case \(e=4\), if all \(2+2f\) assignable special positions lie inside ordinary chords, the forest must have at least two roots, with at least one escape target between roots in the full old-cycle order.

**Proof.** First suppose \(m=f+1\) and \(R=1\). All assignable special positions and all ordinary endpoints lie inside the unique root interval. Every main vertex outside it is \(w_0,w_*\) or an escape target, so the main segment has form (1), taking \(B\) to be the root interval. The escape-confinement theorem makes the child Hamiltonian, a contradiction. Hence a non-Hamiltonian reduced child has either \(m\le f\) or \(R\ge2\). In the latter case with \(m=f+1\), an absence of escape targets between roots would again give (1), with \(B\) spanning the roots, so an interior escape is necessary.

Retain the exact root count in Note 410's charging proof. With \(M_0,L,A,Q\) as defined there, the branching count gives \(A\le M_0+L-R\) and the two-special leaf count gives \(Q\ge M_0+L-m\). Therefore
\[
 c\le3A-Q
 \le2(M_0+L)+m-3R
 \le5m-3R.                                          \tag{3}
\]
If \(m\le f\), (3) gives \(c\le5f-3\). This always applies when \(e=2\), by the parity restriction above. If \(e=4\) and \(m=f+1\), then \(R\ge2\) and (3) gives \(c\le5f-1\). The empty-forest case has \(c=0\) and also obeys the asserted bounds for \(f\ge1\). Finally, the reduced child has
\[
 |V(\bar G^+)|=14+e+2f+2c,
\]
which yields the two order bounds in (2). \(\square\)

At \(f=6\), (2) puts a hypothetical reduced child at at most 88 vertices, contradicting the published 90-vertex Hamilton theorem of [Note 411](411-one-trapped-segment-with-few-face-chords-has-a-hamiltonian-expansion.md). This gives a shorter proof of Note 414. At the first open value \(f=7\), a hypothetical non-Hamiltonian reduced child has \(c\le34\) and at most 100 vertices when \(e=4\), or \(c\le32\) and at most 94 vertices when \(e=2\). No Hamilton conclusion for those remaining kernels follows from the published 90-vertex bound. The general Barnette conjecture remains open.
