> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every tight gapless same-block double vacancy is Hamiltonian

[Note 227](227-all-target-free-same-block-double-vacancies-are-hamiltonian.md)
settles a target-free double-vacancy face block.
[Note 230](230-peripheral-double-vacancies-before-a-target-run-are-hamiltonian.md)
settles two adjacent vacancies at one end of a target run.
[Note 231](231-dispersed-target-runs-between-same-block-vacancies-are-hamiltonian.md)
settles vacancies at the first and last eligible positions
with a run between them. The remaining placements have
occupied targets on an outer side of a nonempty intervening
run, or target runs on both sides of adjacent vacancies.
Parity barriers reduce all of them to one matching or
exclude them.

Work in a compressed all-square Barnette opening as in
Note 196, with \(\ell,r\ge1\), empty interblock gaps,
tight target order and exactly two eligible vacancies.
Both lie in one face-chord block \(D=B_k\),
\(1\le k\le r\). Write its interior in old-cycle order as
\[
o,\ \mathcal A,\ h_1,i_1,\ \mathcal B,\
h_2,i_2,\ \mathcal C,\ e,                         \tag{1}
\]
where \(\mathcal A,\mathcal B,\mathcal C\) are
possibly empty consecutive runs of occupied transition
pairs \(L_j,R_{j-1}\). Every eligible position in
\(D\) other than \(h_1,h_2\) is occupied; other
main blocks may have arbitrary occupied target runs.

**Full same-block theorem.** Every such parent has a
Hamilton cycle containing both site edges \(xy,uv\),
and every legal site-expanded child is Hamiltonian.
The result holds for arbitrary positive original
lobe lengths. If both \(\mathcal A\) and
\(\mathcal C\) are nonempty but \(\mathcal B\)
is empty, no such parent exists.

The previously settled cases follow immediately
from the three notes cited above:
\[
\begin{array}{c|c}
\text{nonempty runs in (1)}&\text{source}\\
\varnothing&\text{Note 227}\\
\mathcal A\text{ alone or }\mathcal C\text{ alone}
&\text{Note 230 and reflection}\\
\mathcal B\text{ alone}&\text{Note 231}.
\end{array}                                           \tag{2}
\]
We prove all other cases.

**Outer barriers.** At the first target of
\(\mathcal A\), if present, only \(o\) is a
free slot of \(D\) before the run. At the first
target of \(\mathcal C\), if present, only
\(e\) is free in \(D\) after the run.
Every relevant free-slot prefix has even size:
one final free slot of \(B_0\), two in each
preceding face block, one first free slot of
the current face block, and two more for
each preceding vacancy. Note 203 excludes
cross-block free chords over an escape target.
At most one same-block free chord can cross
\(\mathcal A\) or \(\mathcal C\), so matching
parity excludes every crossing. Every occupied
run in any other block is likewise a barrier.

If \(\mathcal B\) is empty while
\(\mathcal A,\mathcal C\) are nonempty,
the barriers isolate the four free slots
\(h_1,i_1,h_2,i_2\) as one matching group.
Its opposite-colour pairs are the old-cycle
edges \(h_1i_1,i_1h_2,h_2i_2\) and the
single permissible non-cycle edge \(h_1i_2\).
No perfect matching exists. This proves the
nonexistence assertion.

Suppose now that \(\mathcal B\) is nonempty
and at least one of \(\mathcal A,\mathcal C\)
is nonempty. Between the outer barriers,
the free slots on the two sides of
\(\mathcal B\) are, respectively,
\[
\{h_1,i_1\}\text{ or }\{o,h_1,i_1\},
\qquad
\{h_2,i_2\}\text{ or }\{h_2,i_2,e\},
\tag{3}
\]
where \(o\) is available only if
\(\mathcal A\) is empty, and \(e\) only if
\(\mathcal C\) is empty. A cross-block
matching chord cannot cross the target run;
every same-block chord that does so lies
on the site-face side. The number of
crossing chords is even. If it were zero,
at least one of the two isolated adjacent
pairs \(h_1,i_1\) and \(h_2,i_2\)
would have no permissible mate, because
at least one outer run is present.
Thus exactly two chords cross.

The even slot \(h_1\) must match the odd
slot \(i_2\). The other crossing chord
could join \(i_1\) to \(h_2\) or \(e\),
or \(o\) to \(h_2\), according to which
outer runs are absent. The chords
\(i_1e\) and \(oh_2\) each interlace
\(h_1i_2\); all of them would have to
lie on the same site-face side. Planarity
therefore forces
\[
h_1i_2,\qquad i_1h_2.                         \tag{4}
\]
All ordinary free slots are now matched by
the standard chain \(e_j o_{j+1}\),
\(0\le j\le r\). Indeed, the outer
barriers prevent any remaining same-block
free chord in \(D\); other blocks have
only their first odd and final even
free slots, which either are adjacent
old-cycle vertices or are separated by
an occupied barrier. Every remaining
free chord joins different blocks, lies
in the noncrossing disk opposite the
site face, and cannot skip a complete
block interval without giving a
two-edge cut, as in Note 196.

Finally apply the same-square sweep of
Note 231. For each \(j\), the old main
segment between \(R_j\) and \(L_j\)
contains no other target. Traverse its
free slots by old-cycle edges inside
blocks and the standard chain between
blocks; in particular the two vacant
pairs are traversed through
\(h_1i_1,h_2i_2\). The resulting
\(R_j\)-to-\(L_j\) paths jointly span
all main interior slots. Join them in
descending \(j\) via the exposed
outer halves of the residual squares,
exactly as in Note 231 (5)--(6).
That path and the exposed-face path
\(x,y,a_1,b_1,\ldots,a_r,b_r,u,v\)
share only \(x,v\) and cover every
vertex. Their union is a Hamilton
cycle containing \(xy,uv\).
Notes 001 and 178 give the child
and restore longer lobes. \(\square\)

**A realized nonperipheral case.** Set
\(\ell=3,r=k=1\), take
\(\mathcal A=(L_3,R_2)\),
\(\mathcal B=(L_2,R_1)\), and
\(\mathcal C=\varnothing\). The old
32-cycle is
\[
\begin{array}{ll}
B_0:&x,R_3,e_0,y,\\
D:&a,o,L_3,R_2,h_1,i_1,L_2,R_1,h_2,i_2,e,b,\\
B_2:&u,o_R,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2,3),\text{ returning to }x.
\end{array}                                           \tag{5}
\]
Add the complementary matching
\[
\begin{split}
M={}&\{xy,uv,ab\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
          \delta_jR_j:1\le j\le3\}\\
&\cup\{e_0o,eo_R,h_1i_2,i_1h_2\}.
\end{split}                                           \tag{6}
\]
The matching pairs have opposite cycle
parity. On the site-face side,
\(h_1i_2,i_1h_2\) nest inside \(ab\),
while \(xy,uv,\alpha_j\beta_j\) occupy
disjoint intervals. On the other side,
the escape chords nest as
\(R_3\delta_3\supset L_3\gamma_3
\supset R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1\),
and the free chords \(e_0o,eo_R\) occupy
disjoint gaps. This is a simple cubic
bipartite plane graph with cofacial sites.

Its matching-chord interlacement graph
is connected. The alternation chain
\[
xy-e_0o-ab-eo_R-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-ab-
L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-
ab-L_3\gamma_3-\alpha_3\beta_3-R_3\delta_3-xy
\tag{7}
\]
contains all matching edges except
\(h_1i_2,i_1h_2\), both of which
interlace \(L_2\gamma_2\). Note 217's
interval criterion proves three-connectivity,
and its site-expansion cut projection gives
a 36-vertex Barnette child. A marked
Hamilton cycle is the union of
\[
\begin{split}
&x,y,a,b,u,v,\\
&x,\beta_3,\delta_3,R_3,e_0,o,L_3,\gamma_3,\alpha_3,
\beta_2,\delta_2,R_2,h_1,i_1,L_2,\gamma_2,\alpha_2,
\beta_1,\delta_1,R_1,h_2,i_2,e,o_R,L_1,
\gamma_1,\alpha_1,v.
\end{split}                                           \tag{8}
\]
The paths share only \(x,v\) and
cover all 32 vertices. \(\square\)

Thus the same-block two-vacancy branch
at \(f=4r+6\) is complete under the
all-square, tight, gapless hypotheses.
The theorem does not cover distinct
vacancy blocks, outer-block vacancies,
target-order defects, gaps, nonsquare
residual cycles, or Barnette's conjecture
without these hypotheses.
