> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disjoint split nodes in an isolated three-root site root have a Hamilton path

[Note 486](486-disconnected-three-root-two-split-nodes-must-share-site-root.md) shows that a disconnected root face graph can leave a non-Hamiltonian three-root two-split equality opening only when both marked unary nodes lie in the same isolated end root containing the site ports. This note closes the case in which their ordinary intervals are disjoint.

Let \(W\) be that isolated root and \(u,v\) its two site ports. All face matching chords incident with \(W\) have both ends in \(W\). Let its two split nodes be
\[
 N_i=(H_i,s_i,A_i,t_i,J_i),\qquad N_1<N_2,\quad i=1,2,
\tag{1}
\]
where \(A_i\) is the child word with first and last vertices \(L_i,R_i\). Every assigned special position other than \(s_1,t_1,s_2,t_2\) lies in a two-special leaf. Equality in the charge of Notes 410 and 477 gives each marked unary node two consecutive plain-unary ancestors.

**Disjoint-root-path theorem.** \(W\) has a spanning \(u\)--\(v\) path. The parent therefore has a Hamilton cycle containing both site edges, and its legal expanded child is Hamiltonian.

**Proof.** Close the old \(W\)-arc by its root chord \(e_W\) to obtain \(C_W\). Let \(E\) be the old square-supported edge of every two-special leaf in \(W\), and let \(M_W\) match every special position of \(W\) except \(u,v\). Make the two inner openings
\[
 F_{\rm ii}
 =\bigl(C_W-E-\{s_1L_1,R_1t_1,s_2L_2,R_2t_2\}\bigr)
       \cup M_W\cup\{L_1R_1,L_2R_2\}.
\tag{2}
\]
It has one \(u\)--\(v\) path and some cycles. Restoring \(E\) exposes the two closed child arcs \(A_1,A_2\) and two complementary arcs \(B_{\rm mid}=t_1\rightsquigarrow s_2\), \(B_{\rm out}=t_2\rightsquigarrow s_1\), the latter containing \(e_W\). The wrapper square between the core chord of either split node and its immediate plain-unary parent has one old rail edge in each complementary arc. Both ordinary chords of the square are unused; its support is disjoint from all leaf squares. Its switch joins the two complementary arcs whenever they are in different components. Regard them as one coarse block \(B\).

After these available square switches, connectivity is exactly that of the three coarse blocks \(A_1,A_2,B\) joined by \(M_W\)-edges. If this coarse graph is connected, switch along a spanning tree rooted at the \(u\)--\(v\) path; every cycle is absorbed and the asserted path follows. Otherwise consider a component without terminals. Each component contains zero or two terminals, since \(F_{\rm ii}\) has only one terminal path.

An isolated \(A_i\) with no terminal would have only its two old boundary edges leaving it in the cubic parent, violating three-connectivity. An isolated \(A_i\) with both \(u,v\) is also impossible. For \(i=1\), the prefix special positions before \(s_1\), together with \(s_1\), have odd cardinality: all leaves there contribute pairs. No matching edge joins this prefix to \(A_1\), while a chord to any position beyond \(A_1\) would cross \(q=w_0u\). Thus the odd prefix would have to match internally. For \(i=2\), use the symmetric odd suffix after \(t_2\) and the site chord \(p=vw_*\).

Nor can \(B\) be an isolated zero-terminal block. Let \(A_j\) be the first child interval containing a site terminal. Take all special positions before \(s_j\), together with \(s_j\). This set is odd: earlier complete leaves and, if \(j=2\), both direct positions of \(N_1\) contribute even numbers. Because \(B\) is isolated, its positions in the set have no matching edge to a child. An edge across \(A_j\) would cross the site chord ending in \(A_j\). If \(j=2\), the earlier terminal-free child \(A_1\) may send edges to \(A_2\), but their number is even because all its special positions are paired outside \(B\). An odd set cannot have an even number of matching edges leaving it. This is the terminal-barrier argument of [Note 474](474-disjoint-split-unary-nodes-close-the-chorded-equality-profile.md), with only two terminals.

The sole remaining terminal-free component is \(A_1\cup A_2\), joined by at least one \(M_W\)-edge, while both \(u,v\) lie in \(B\) and no matching edge joins either child to \(B\). Choose one node \(N_i\) with a direct special position not equal to \(u\) or \(v\); such a node exists because there are four direct positions and only two site terminals. Open \(N_i\) at its outside edges \(H_is_i,t_iJ_i\) and insert \(H_iJ_i\); open the other node \(N_j\) at its inside edges \(s_jL_j,R_jt_j\) and insert \(L_jR_j\), exactly as in (4) of Note 474. The chord \(H_iJ_i\) is unused by \(C_W\), since \(N_i\) has two plain-unary ancestors. Restoring \(E\) now leaves three coarse pieces: a central path \(P_i=s_i\rightsquigarrow t_i\), the closed child \(A_j\), and a complementary path \(B'\). The \(M_W\)-edge between \(A_i,A_j\) joins \(P_i\) to \(A_j\). A nonterminal direct position of \(N_i\) has its \(M_W\)-mate in \(B'\): no matching edge joins \(B\) to a child, and [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) forbids matching \(s_i\) to \(t_i\). Thus all three pieces are connected. Leaf-square switches absorb all cycles into the unique \(u\)--\(v\) path. In every case \(W\) has the asserted spanning path.

The exterior path (4) or (5) of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md) covers all vertices outside \(W\). The site edges join it to the root path into a marked parent Hamilton cycle; [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts that cycle to the legal child. \(\square\)

Together with Note 486, a disconnected-\(K\) non-Hamiltonian three-root equality opening, if one exists, must put its two split nodes in a nested arrangement inside the isolated site root.
