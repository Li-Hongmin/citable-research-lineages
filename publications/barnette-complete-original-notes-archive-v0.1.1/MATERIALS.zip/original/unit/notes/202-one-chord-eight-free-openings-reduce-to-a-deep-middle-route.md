> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# One-chord eight-free openings reduce to a deep middle route

[Note 198](198-one-face-chord-excludes-two-gap-near-equality.md)
removes all gap slots at the first boundary above exact chord packing.
[Note 197](197-gapless-square-trap-defect-budget.md) then allows at most
one defect in the escape-target order. [Note 201](201-delayed-boundary-targets-have-hamiltonian-children-at-one-chord-near-equality.md)
settles either endpoint defect. The remaining transition defect can be
peeled to an impossible six-slot matching; when there is no target-order
defect, a vacancy in either outer block can be peeled to a Hamilton
route. Thus a possible non-Hamiltonian child in this opening class has
only the deep middle-block configuration left by [Note 200](200-middle-block-near-equality-hamilton-routes-and-the-two-deep-side-obstruction.md).

Let \(G\) be a Barnette parent with Hamilton cycle \(C\) avoiding the
cofacial site matching edges \(q=xy,p=uv\). Assume that a selected
all-square facial opening has one opposite-face matching chord \(ab\),
\(f=8\) free main vertices, and \(\ell\ge1\) residual-square lobes.
Compress each lobe to one square as in [Note 178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md).
By Note 198 the blocks \(B_0=[x,y]_C\), \(B_1=[a,b]_C\),
\(B_2=[u,v]_C\) have no intervening gap slots. Write
\(2+2k_i\) for their interior slot counts. Then
\(k_0+k_1+k_2=\ell\), and exactly one of their \(\ell\)
eligible even slots is vacant, meaning that it is not occupied
by a nonfinal \(L_j\) target.

**One-chord near-equality reduction.** If the legal site-expanded
child is non-Hamiltonian, then the selected opening has all of the
following properties:

1. \(R_\ell\) is the first slot of \(B_0\), \(L_1\) is the final
   slot of \(B_2\), and every consecutive \(L_j,R_{j-1}\)
   (\(j\ge2\)) is adjacent on \(C\).
2. The sole vacant eligible even slot lies in \(B_1\). Its six
   free slots have Note 200's order \(e,g,h,i,j,z\), and their
   complementary matching is necessarily the double inner route
   \(ez,gh,ij\).
3. Each of \(gh\) and \(ij\) spans at least two adjacent
   \(L_t,R_{t-1}\) target pairs. In particular \(\ell\ge5\).
4. Simple boundary peels preserve the child's Hamilton decision
   and reduce this case to a core determined by two integers
   \(a,b\ge2\), the numbers of target pairs spanned by \(gh\)
   and \(ij\). The core has \(\ell=a+b+1\), and its site-expanded
   child has \(6(a+b)+22\ge46\) vertices.

The statement is conditional: it gives no non-Hamiltonian example and
does not decide the remaining double inner route.

**Proof: a transition defect is Hamiltonian.** Suppose the two
endpoint targets are tight but one transition \(L_j,R_{j-1}\)
is nonadjacent. Note 197's budget makes this the only defect and
places the unique vacant eligible position between those targets.

If \(k_0>0\), the first eligible slot of \(B_0\) cannot be vacant:
it precedes every \(L_j\), whereas the vacancy follows one.
It is therefore \(L_\ell\), immediately after \(R_\ell\).
The initial triple is \(x,R_\ell,L_\ell\), and its following
vertex is still inside \(B_0\). Thus the simple left inverse
of [Note 186](186-boundary-square-traps-either-peel-or-force-a-hamiltonian-child.md)
removes this lobe, preserves \(r=1,f=8\), and preserves the
child's Hamilton decision. Similarly, if \(k_2>0\), its final
odd interior slot must be \(R_1\): a free slot between \(R_1\)
and the final \(L_1\) would require a second vacancy or put a
nonfinal target after \(R_1\). Hence the final triple is
\(R_1,L_1,v\), with its preceding vertex inside \(B_2\),
and Note 186's simple right inverse applies.

After either inverse, if the deleted lobe met the exceptional
transition, that nonadjacency becomes a delayed first target or
an advanced last target. Note 201 makes the reduced child
Hamiltonian, and Note 186 lifts that decision back. Otherwise
the same unique transition defect remains, so repeat. Each
inverse decreases \(\ell\). It therefore suffices to rule out
the case \(k_0=k_2=0\), where \(k_1=\ell\).

In this case \(B_0\) has slots \(R_\ell,e\) and \(B_2\) has
slots \(z,L_1\). Every nonfinal \(L\) target lies in \(B_1\).
The exceptional transition cannot end at the first slot of
\(B_2\), by the cross-block endpoint argument in Note 197;
it lies wholly in \(B_1\). Name the free slots of that block
\(g,c,d,j\) in cycle order. Here \(g\) is first, \(j\)
is last, \(c\) immediately follows the exceptional \(L_j\),
and \(d\) is the unique vacant even slot immediately after
\(c\); the next odd slot is \(R_{j-1}\). In particular
\(cd\in E(C)\). These four plus \(e,z\) are all six free
slots.

The only possible free odd mates of \(e\) are \(g,c,z\).
Both \(ec\) and \(ez\) join different blocks and straddle
the escape edge at \(L_\ell\); Note 193's opposite-face
placement makes either crossing impossible. Thus \(eg\in M\).
The only possible free even mates of \(z\) are now \(d,j\).
The cross-block edge \(dz\) straddles the escape edge at
\(R_{j-1}\), so \(jz\in M\). The two remaining free
vertices \(c,d\) are adjacent on \(C\); their edge cannot
also belong to the complementary matching of a simple graph.
This contradiction rules out the boundary-irreducible case,
and proves that every transition-defect child is Hamiltonian.

**Proof: an outer vacancy is Hamiltonian.** Now assume every
endpoint and transition is tight, and the vacant eligible slot
is in \(B_0\). Let it be position \(2m\). The first \(m-1\)
eligible slots of \(B_0\) are occupied by successive nonfinal
\(L\) targets, each followed by the next \(R\) target. Peel
their \(m-1\) boundary lobes by Note 186. These are simple
inverses: until the vacancy is reached, the vertex after each
removed \(L\) is still inside \(B_0\). Tight transitions
keep the reduced first target adjacent to \(x\). The reduced
opening still has \(r=1,f=8\), and its vacancy is position 2
of \(B_0\).

Write its first four block slots as \(R_\ell,s,t,\ldots\),
where \(s\) is the vacant even slot, \(t\) is the next odd
free slot, and \(e\) is the final even free slot of \(B_0\).
If \(k_0\ge2\), position 4 is \(L_\ell\). The vertex \(s\)
has no matching mate: \(t\) is adjacent to it on \(C\),
every later odd slot of \(B_0\) is an escape target, and
every free odd slot in another block lies after \(L_\ell\),
so its cross-block chord would cross the escape edge there.
Thus \(k_0=1\), and \(B_0\)'s slots are \(R_\ell,s,t,e\).

Let \(g,h\) be the first and last slots of \(B_1\).
If \(k_1>0\), its second slot is \(L_\ell\). The free
odd vertex \(t\) again has no mate: its only free even
slots before \(L_\ell\) are its adjacent neighbours
\(s,e\), while a cross-block mate after \(L_\ell\)
would cross that escape edge. Hence \(k_1=0\) and
\(k_2=\ell-1\).

Let \(z\) be the first slot of \(B_2\). All six free
slots \(s,t,e,g,h,z\), in that order, precede every
remaining escape target except \(R_\ell\). Their colours
are \(E,O,E,O,E,O\). Every free matching edge joins
different blocks and lies opposite the common face.
Noncrossing and the forbidden consecutive pairs
\(st,te,gh\) force, exactly as in Note 199,
\[
sz,\qquad th,\qquad eg\in M.                 \tag{1}
\]
Let \(T\) be the \(M\cup A\) path through all escape
targets and residual squares, running from \(x\) to \(v\):
\[
x,R_\ell,\delta_\ell,\beta_\ell,\alpha_\ell,
\gamma_\ell,L_\ell,R_{\ell-1},\ldots,
R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v.
\tag{2}
\]
All \(L_jR_{j-1}\) edges in (2) belong to \(A\), the
even-starting matching of \(C\). The complementary route
\[
v,u,z,s,t,h,b,a,g,e,y,x                 \tag{3}
\]
uses (1), the three block-closing matching edges, and the
remaining \(A\)-edges. Routes (2)--(3) form one Hamilton
cycle of the reduced parent containing both site edges.
Note 001 makes its site-expanded child Hamiltonian;
the earlier simple inverses preserve the child decision.
Reversing the main segment and interchanging the site
edges gives the same conclusion for a vacancy in \(B_2\):
under the reversal, relabel
\(R'_i=L_{\ell+1-i}\), \(L'_i=R_{\ell+1-i}\).
The odd free slot immediately after the old vacancy becomes
the unique eligible even vacancy in the reversed outer block;
tight endpoints and transitions stay tight.

If either endpoint is not tight, Note 201 applies. With
tight endpoints, Note 197 permits either the unique
transition defect just settled, or no target-order defect.
In the latter case the outer-block vacancies are settled
above, leaving only a vacancy in \(B_1\). Note 200 classifies
its free matching into three routes: two are Hamiltonian,
and the double inner route is Hamiltonian whenever either
internal chord spans one target pair. Thus every
non-Hamiltonian child must satisfy conditions 1--3.

In that route, if \(k_0>0\), the initial triple is
\(x,R_\ell,L_\ell\); if \(k_2>0\), the final triple is
\(R_1,L_1,v\). Note 186's simple inverse applies on either
side and preserves the child Hamilton decision. It also
preserves the number of target pairs on each side of the
middle vacancy. Peel until \(k_0=k_2=0\). Then
\(k_1=\ell\), and the two numbers \(a,b\ge2\) satisfy
\(a+b=\ell-1\). The core has block slots
\[
\begin{aligned}
B_0 &: R_\ell,e,\\
B_1 &: g,
  (L_\ell,R_{\ell-1}),\ldots,
  (L_{\ell-a+1},R_{\ell-a}),
  h,i,
  (L_{\ell-a},R_{\ell-a-1}),\ldots,(L_2,R_1),j,\\
B_2 &: z,L_1.
\end{aligned}                                      \tag{4}
\]
Its complementary matching is exactly
\[
\{xy,ab,uv,ez,gh,ij\}
\cup\{\alpha_t\beta_t,\gamma_tL_t,\delta_tR_t:
1\le t\le\ell\}.                              \tag{5}
\]
Together with the old cycle, (4)--(5) determine the
abstract core graph. The compressed parent has
\(|V(S_0)|+4\ell=(12+2\ell)+4\ell=6\ell+12\)
vertices, and the site expansion adds four. This proves
condition 4 without asserting that every formal parameter
pair is realized by a legal Barnette opening.
Note 178 restores arbitrary positive original lobe
lengths. \(\square\)

[Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
subsequently excludes the remaining middle-block route by a
cross-block chord and escape-chord crossing, completing the
\(r=1,f=8\) Hamilton decision for this opening class.
