> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every cube CEN/UV word has global \(H^{+-}\)

Let \(Q\) be the cube and use the ordered site

\[
(u,v,x,y)=(0,1,2,3),\qquad p=01,\quad q=23
\tag{1}
\]

from [Note 012](012-cube-start-gives-exponentially-many-p2-hamiltonian-barnette-graphs.md).
After the first legal \(C_4\)-expansion, choose the CEN or UV successor
independently after every expansion.

> **Theorem.** Every finite cube-rooted CEN/UV word produces a Barnette
> graph with the global \(H^{+-}\)-property: for every ordered pair of
> distinct edges \((e,f)\), there is a Hamilton cycle containing \(e\) and
> avoiding \(f\).

This strengthens the \(P_2\)-Hamiltonicity statement of Note 012 for the
same construction family.  It is not a preservation theorem for arbitrary
legal \(C_4\)-expansions.

## The missing linkage role

The roles used for edge coverage in Note 010 are not complete for
\(H^{+-}\).  Use the planar interface

\[
T=\{A,B,C,D,E,L\},
\tag{2}
\]

where

\[
\begin{array}{c|c}
A&(uy)(vx)\text{ two-path pairing from a }C_{11}\text{ cycle},\\
B&C_{10},\\
C&C_{01},\\
D&X_{vx},\\
E&X_{uy},\\
L&(uv)(xy)\text{ spanning two-path linkage}.
\end{array}
\tag{3}
\]

The other pairing \((ux)(vy)\), previously denoted \(A_1\), is empty in
the cube and remains empty under both recurrent maps.  The cube has three
distinct retained supports in role \(A\) and one in every other role in
(2).  In particular, its \(L\)-linkage is a real witness, not a formal
state.  This sixth witness is essential: the ordered pair of first-gadget
edges \((ua,cd)\) can only be separated by the linkage incidence.

The standard Hamilton completions of the six roles, in gadget order

\[
(ua,ab,bv,xc,cd,dy,ad,bc),
\tag{4}
\]

are

\[
\begin{array}{c|c}
A&11111100\\
B&10101011\\
C&01010111\\
D&01111010\\
E&11001101\\
L&10110111.
\end{array}
\tag{5}
\]

By Note 013, these rows separate every ordered pair of distinct gadget
edges.

## Exact memberwise transfer

For a nonfinal CEN layer, the successor edges \(bc,ad\) disappear at the
next expansion.  In the retained order

\[
(ua,ab,bv,xc,cd,dy),
\]

the complete memberwise output table is

\[
\begin{array}{c|c}
A\to D&111101\\
A\to E&101111\\
A\to L&101101\\
B\to A&101010\\
C\to A&010101\\
D\to C&011110\\
E\to B&110011\\
L\to A&101101.
\end{array}
\tag{6}
\]

For a nonfinal UV layer, the successor edges \(ua,bv\) disappear.  In the
retained order

\[
(ab,xc,cd,dy,ad,bc),
\]

the table is

\[
\begin{array}{c|c}
A\to A&111100\\
A\to E&110111\\
A\to L&010111\\
B\to A&001011\\
C\to D&010111\\
D\to C&111010\\
E\to B&101101\\
L\to A&010111.
\end{array}
\tag{7}
\]

Equations (6)--(7) follow from the \(2^8\) subsets of one constant gadget,
with terminal degrees, connectivity and pairings checked exactly.  At the
Boolean role level they give

\[
\begin{array}{c|cccccc}
 &A&B&C&D&E&L\\ \hline
\mathrm{CEN}&DEL&A&A&C&B&A\\
\mathrm{UV}&AEL&A&D&C&B&A.
\end{array}
\tag{8}
\]

Thus the full role set \(T\) is fixed by both maps and every source role has
at least one output.

## The 22-state signed-support invariant

For a retained edge \(r\), define

\[
\begin{aligned}
P(r)&=\{\tau\in T:\text{some concrete }\tau\text{-witness contains }r\},\\
N(r)&=\{\tau\in T:\text{some concrete }\tau\text{-witness avoids }r\}.
\end{aligned}
\tag{9}
\]

Availability of a role name is insufficient: the containing and avoiding
witnesses must carry the required edge incidence.  All reachable signed
states \((P(r),N(r))\) lie in the following set \(\Sigma\), where \(X/Y\)
denotes \((P,N)=(X,Y)\):

\[
\begin{gathered}
ABC/ADEL,\ ABCD/AEL,\ ABCE/ADL,\ ACDEL/AB,\ ABDEL/AC,\\
ABCDEL/ABCDEL,\ ABCDEL/ABCEL,\ ABCDEL/ABDEL,\ ABCDEL/ABEL,\\
ABCDEL/ADEL,\ ABCDEL/AEL,\\
ABCEL/ABCDEL,\ ABCEL/ABDEL,\ ABCEL/ADEL,\\
ABDEL/ABCDEL,\ ABDEL/ABCEL,\ ABDEL/ACDEL,\ ABDEL/ACEL,\\
ACDEL/ABDEL,\ ACDEL/ABEL,\ ADEL/ABCDEL,\ ADEL/ABCEL.
\end{gathered}
\tag{10}
\]

Applying either memberwise role map in (8) to both coordinates preserves
\(\Sigma\).  The six retained edges born in a nonfinal layer have states

\[
\begin{array}{c|l}
\mathrm{CEN}&
ua,dy:ABDEL/AC;\quad ab:ABCD/AEL;\\
&bv,xc:ACDEL/AB;\quad cd:ABCE/ADL;\\[1mm]
\mathrm{UV}&
ab:ABCE/ADL;\quad xc,ad:ACDEL/AB;\\
&cd:ABC/ADEL;\quad dy,bc:ABDEL/AC,
\end{array}
\tag{11}
\]

so every birth state also belongs to \(\Sigma\).

The induction retains one more item: for every ordered pair of distinct
retained edges \((r,s)\), there is a single interface witness containing
\(r\) and avoiding \(s\).  This same-witness condition is stronger than
the two marginal states in (9).

## Closure of all ordered edge pairs

Partition the ordered edge pairs of a child into four blocks.

1. **Retained--retained.** A separating source witness has some role in
   \(T\).  Every source role has a nonempty output in (8), and memberwise
   transfer preserves both old incidences.
2. **Retained--new.** For every \(P\)-coordinate in \(\Sigma\), the rows
   in (5) contain, for each new edge \(j\), a role that contains \(r\) and
   avoids \(j\).
3. **New--retained.** The analogous assertion holds for every
   \(N\)-coordinate in \(\Sigma\): for each \(j\), some role uses \(j\)
   and has a concrete witness avoiding \(r\).
4. **New--new.** The six rows in (5) separate every ordered pair of
   distinct gadget edges.

The finer incidence tables (6)--(7) also verify the same-witness separation
for pairs involving edges born in the new retained layer.  Equations
(10)--(11) restore the signed-support invariant at the next marked site.

At the cube root, the eight concrete interface witnesses

\[
3A+1B+1C+1D+1E+1L
\]

give only the first five signed states in (10), and they separate every
ordered pair of the ten retained cube edges.  The cube itself has global
\(H^{+-}\), directly witnessed by its six Hamilton cycles.  Induction now
proves the theorem at every depth and along every CEN/UV word.

## Independent finite-state certificate

An independent formulation decorates the required and forbidden final
edges at their unique birth layers and tracks

\[
(S,\epsilon,\phi),\qquad S\subseteq
\{A_0,A_1,A_2,B,C,D,E\},quad
\epsilon,\phi\in\{0,1\}.
\]

Here \(A_2=(uv)(xy)\) is the linkage \(L\).  Equality of this state is a
complete future equivalence because processed annuli meet the future only
at the four ordered terminals.  The exhaustive reachable-state closure has

\[
55\text{ states},\qquad422\text{ nonfinal transitions},\qquad
243\text{ final closures},
\]

and every final closure succeeds.  The verifier is
`../scratch/worker-c4-hpm/fixed_width_cen_uv_h_plus_minus.py` and ends with
`CEN_UV_GLOBAL_H_PLUS_MINUS_FIXED_WIDTH_VERIFIED`.  This is an all-depth
finite-state certificate, not bounded-depth extrapolation.

As a separate check outside the finite-state proof, complete
perfect-matching enumeration for six structurally extreme order-68 words
gives between 3,100 and 32,756 Hamilton cycles, and all six graphs satisfy
global \(H^{+-}\) and \(P_4\).  This finite check is not used in the
theorem.

## Counting consequence and boundary

The rooted two-step delay and root-forgetting argument of Notes 011--012
are unchanged.  Let \(B_{H^{+-}}(n)\) count isomorphism classes of
\(n\)-vertex Barnette graphs with global \(H^{+-}\).  Then

\[
\boxed{
B_{H^{+-}}(8+4k)\ge
\left\lceil
\frac{2^{\max(k-2,0)}}{(8+4k)_8}
\right\rceil
}
\tag{12}
\]

and, along \(n=8+4k\),

\[
B_{H^{+-}}(n)\ge 2^{n/4-8\log_2n-4}
=2^{n/4-O(\log n)}.
\tag{13}
\]

Global \(H^{+-}\) implies \(P_2\)-Hamiltonicity, so (12) strictly
strengthens the earlier count.  It remains a theorem about the specific
cube CEN/UV grammar.  It neither proves that arbitrary legal
\(C_4\)-expansion preserves \(H^{+-}\) nor resolves Barnette's conjecture.
