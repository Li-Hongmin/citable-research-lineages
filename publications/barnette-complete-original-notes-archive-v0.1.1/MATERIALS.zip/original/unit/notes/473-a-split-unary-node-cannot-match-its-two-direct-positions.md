> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A split unary node cannot match its two direct positions

The inner/outer openings in [Note 460](460-two-exterior-pairings-close-the-chorded-single-unary-defect.md) distinguish whether a face matching edge crosses the child of a marked unary ordinary node. Three-connectivity gives a simpler local restriction that also applies to the two-split equality profile left by [Note 472](472-one-adjacent-and-one-split-unary-node-always-splice-at-chorded-equality.md).

Let \(G\) be a three-connected cubic plane graph with a Hamilton cycle \(C\). The third edges of \(C\) form a matching on its vertices. Consider an ordinary matching chord \(HJ\) on one side of \(C\), whose unique child word \(A\) has first and last vertices \(L,R\) joined by an ordinary chord \(LR\). Suppose the old-cycle order within \(HJ\) is
\[
                              H,s,A,t,J,
\tag{1}
\]
and the only vertices in \((H,J)\setminus A\) whose third edges are not ordinary chords are \(s,t\). Their third edges lie on the other side of \(C\).

**No self-pairing theorem.** The edge \(st\) does not belong to \(G\).

**Proof.** Suppose \(st\) is a third edge. It is drawn on the side of \(C\) opposite the ordinary chord \(LR\). Every ordinary third edge incident with a vertex of \(A=[L,R]\) has its other endpoint in \(A\): an edge with only one endpoint in \(A\) would cross \(LR\), and \(L,R\) are already matched to each other. A third edge on the \(st\) side from a vertex of \(A\) to a vertex outside \(A\) would have to end outside the interval \([s,t]\), because the only vertices of \([s,t]\setminus A\) are \(s,t\) and both are already matched to each other. Such an edge would interlace and cross \(st\). Thus no third edge leaves \(A\).

The only edges of \(G\) leaving \(A\) are its two old-cycle boundary edges \(sL,Rt\). Since \(A\) and its complement are nonempty, these form a two-edge cut, contrary to three-connectivity of a cubic graph. \(\square\)

In particular, at the chorded \(c=5f-7\) equality boundary, each of the two split marked unary nodes has distinct third-edge mates for its directly assigned positions. If no face matching edge crosses a node's child interval \(A\), then each of \(s,t\) has its third edge outside the whole node interval \([H,J]\), either as a site/exterior attachment or as a face matching edge. This is a necessary structural condition; it does not by itself supply a Hamilton cycle for the two-split profile.
