> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A double vacancy at a cross-block transition destination is Hamiltonian

[Note 250](250-an-intermediate-spare-vacancy-repairs-a-cross-block-transition.md)
handles a spare vacancy in a strictly intermediate face block
of the unique transition defect at the gapless second surplus.
If both vacant eligible positions instead precede the destination
target in its own block, the free group has the same rainbow
matching mechanism as [Note 244](244-a-double-delayed-endpoint-has-a-forced-rainbow-hamilton-route.md),
with the transition's source replacing the left endpoint.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps and \(s=2\), so
\(f=4r+6\). Assume \(d_L=d_R=0,b=1\). Let the sole defective
transition be \(L_j\in B_i\), \(R_{j-1}\in B_h\),
\(2\le j\le\ell\), \(i<h\). Suppose both vacancies lie
strictly between these targets in the destination block \(B_h\).
Write its first five interior slots as
\[
o_h,h_1,i_1,h_2,R_{j-1},                    \tag{1}
\]
where \(h_1,h_2\) are the two vacant even positions.

**Double-destination theorem.** Necessarily \(h\ge i+2\).
The source \(L_j\) is the last eligible even position of
\(B_i\), followed by the free slots \(c_i,e_i\); every block
strictly between \(B_i,B_h\) is short. For one
\(t\in\{i,\ldots,h-2\}\), the complete free matching is
\[
M_{\rm free}=
\{c_i h_2,e_t i_1,o_{t+1}h_1\}
\cup\{e_a o_{a+1}:0\le a\le r,\ a\ne t\}.
                                                        \tag{2}
\]
The parent has a Hamilton cycle containing both site edges
\(xy,uv\), and its legal site-expanded child is Hamiltonian.
Reflection gives the corresponding configuration with one
vacancy after \(L_j\) in the source block and one before
\(R_{j-1}\) in the destination block. Original square-trap
lobes may have arbitrary
positive lengths.

**Placement and matching barriers.** The target \(R_{j-1}\)
cannot be the first interior slot of a later block: the main
prefix through \(B_{h-1}\), together with squares
\(S_j,\ldots,S_\ell\), would be matching-closed by the
no-straddling lemma of [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md)
and would have a forbidden two-edge cut, as in Note 212.
By assumption both vacancies are in \(B_h\); they must
therefore be its first two eligible even positions. Every
earlier block between the targets is short, and \(L_j\)
is last eligible in \(B_i\), because an unoccupied eligible
position there would be a third vacancy. This gives (1)
and the source pair \(c_i,e_i\).

The number of free slots before \(L_j\) is even. A cross-block
free chord cannot straddle it, while at most one same-block
chord could cross, so parity excludes every crossing. The
same holds before \(R_{j-1}\): its only possible later free
slot within \(B_h\) is its final \(e_h\), absent if
\(h=r+1\). Thus the free group between these targets is
matching-closed and has order
\[
c_i,e_i,o_{i+1},e_{i+1},\ldots,
o_{h-1},e_{h-1},o_h,h_1,i_1,h_2.             \tag{3}
\]
All cross-block matching chords in (3) lie opposite the
site face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
and do not interlace there.

The first free slot \(c_i\) cannot match any final even slot
\(e_a\), \(i\le a<h\). The edge \(c_ie_i\) belongs to the
old cycle; for \(a>i\), the chord \(c_ie_a\) would trap all
intervening free slots. The main prefix through \(B_a\),
together with \(S_j,\ldots,S_\ell\), would then be closed
under \(M\) and have only two departing old-cycle edges.
It cannot match \(e_h\) across \(R_{j-1}\). Its only
remaining even mates are \(h_1,h_2\). If \(c_ih_1\in M\),
the odd slot \(i_1\) could not match an earlier even slot
without interlacing \(c_ih_1\) on the opposite side of
\(C\); its only later same-block even candidate \(h_2\)
is an old-cycle neighbour, and \(e_h\) lies beyond the
target barrier. Hence \(c_i h_2\in M\).

Inside this outer chord every remaining free matching edge
joins different blocks: \(o_hh_1,h_1i_1,i_1h_2\) are
old-cycle edges, and \(o_hh_2\) uses the already matched
\(h_2\). Thus all inner chords occupy one noncrossing disk.
Scan from \(e_i\) rightward. The short-block skipping rule
of [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
forces standard links until one even slot \(e_t\) matches
\(i_1\). Some such slot must occur, since \(h_1i_1\in E(C)\).
If \(t=h-1\), the remaining pair \(o_h,h_1\) is adjacent
on \(C\). Therefore \(i\le t\le h-2\), proving
\(h\ge i+2\). Noncrossing then forces \(o_{t+1}h_1\):
a later mate would skip one adjacent pair or close a
matching-closed short-block interval. All other inner and
outer groups take standard links. This proves (2).

**Marked Hamilton route.** Use the two paths of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
Replace their missing target transition by
\[
L_j,c_i,h_2,R_{j-1};                           \tag{4}
\]
the outer edges are on \(C\), and \(c_ih_2\in M\).
Replace the ordinary free-path link \(e_t o_{t+1}\) by
\[
e_t,i_1,h_1,o_{t+1}.                           \tag{5}
\]
The outer edges are in \(M\), and \(i_1h_1\in E(C)\).
The paths meet only at \(x,v\), cover every parent vertex,
and together form a Hamilton cycle through \(xy,uv\).
[Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
and [178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
give the legal child and longer lobes. \(\square\)

**A 26-vertex realization.** Take
\(r=1,\ell=2,i=0,h=2,j=2,t=0\). The old Hamilton
cycle has blocks
\[
\begin{array}{ll}
B_0:&x,R_2,L_2,c_0,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,h_1,i_1,h_2,R_1,L_1,v,\\
S_1,S_2:&\alpha_q,\gamma_q,\delta_q,\beta_q
\quad(q=1,2),\text{ returning to }x.
\end{array}                                             \tag{6}
\]
Its complementary matching consists of the fixed chords
\(xy,a_1b_1,uv\), \(\alpha_q\beta_q,R_q\delta_q,
L_q\gamma_q\) for \(q=1,2\), and
\[
c_0h_2,\quad e_0i_1,\quad o_1h_1,\quad e_1o_2.
                                                        \tag{7}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,R_2,\delta_2,\beta_2,\alpha_2,\gamma_2,L_2,
c_0,h_2,R_1,\delta_1,\beta_1,\alpha_1,\gamma_1,L_1,v,\\
&x,y,e_0,i_1,h_1,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                             \tag{8}
\]
Every consecutive pair in (8) is on the old cycle or in
the displayed matching; the paths share only \(x,v\) and
cover all 26 vertices.

All matching pairs have opposite old-cycle parity and
\(x,u\) have the same parity. Draw the disjoint site, face
and \(\alpha_q\beta_q\) chords on the site-face side of
\(C\). On the other side, \(R_2\delta_2\) contains
\(L_2\gamma_2\), whose disjoint branches are the nest
\(c_0h_2\supset e_0i_1\supset o_1h_1\supset e_1o_2\)
and \(R_1\delta_1\supset L_1\gamma_1\). This gives a
simple cubic bipartite plane graph with cofacial sites.
Its matching-chord interlacement graph is connected:
\(xy\) meets \(c_0h_2,e_0i_1,R_2\delta_2,L_2\gamma_2\);
\(uv\) meets all four free chords and \(R_1\delta_1,
L_1\gamma_1\); \(a_1b_1\) meets \(o_1h_1,e_1o_2\);
and each \(\alpha_q\beta_q\) meets the two escape chords
of its square. [Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
therefore proves three-connectivity of this parent and its
30-vertex legal site expansion. Formula (8) and Note 001
give their Hamilton cycles.

The theorem covers both vacancies at the destination of a
cross-block transition, and by reflection the one-source,
one-destination overlap. Under reversal, the two eligible
positions before the old destination target become one eligible
position after the new source target and the old source's
free odd slot becomes the eligible position before the new
destination target. Outside site-block
vacancies, interblock gaps, nonsquare residual cycles and
Barnette's conjecture remain undecided.
