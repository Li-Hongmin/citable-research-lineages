> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A cube start gives exponentially many (P_2)-Hamiltonian Barnette graphs

[Note 010](010-nonconjugate-cen-uv-expansion-tree.md) gives two
nonconjugate successor sites, CEN and UV, whose six-role transfer relations
preserve the state

\[
V_0=\{A_0,B,C,D,E\}.
\tag{1}
\]

[Note 011](011-rooted-two-step-delay-and-exponential-unlabelled-count.md)
classifies all rooted CEN/UV histories but uses a 240-vertex certified graph
as its stated start.  The cube already supplies the required stable state.
This removes the computational start from the existence theorem and sharpens
the marked-core divisor from ((n)_{240}) to ((n)_8).

## The cube interface

Let (Q) be the cube with vertex set ({0,1,\ldots,7\}) and edge set

\[
\{01,03,04,12,17,23,26,35,45,47,56,67\}.
\tag{2}
\]

Use the facial square (0,1,2,3) and orient its opposite edges as

\[
(u,v,x,y)=(0,1,2,3),\qquad p=01,\qquad q=23.
\tag{3}
\]

This is a legal Barnette (C_4)-expansion site: the four endpoints are
distinct, (u,x) belong to the same bipartition class, and the two residual
facial paths (1-2) and (3-0) both have odd length.

The following three Hamilton cycles and two spanning paths are written in
their traversal order:

\[
\begin{aligned}
A_0&:0-1-2-3-5-6-7-4-0,\\
B&:0-1-2-6-7-4-5-3-0,\\
C&:0-3-2-1-7-6-5-4-0,\\
D&:1-7-4-0-3-5-6-2,\\
E&:0-4-7-1-2-6-5-3.
\end{aligned}
\tag{4}
\]

The cycle (A_0) contains both (p,q).  Deleting them leaves components
with terminal pairing

\[
(03)(12)=(uy)(vx),
\]

so it has role (A_0), not (A_1).  The cycle (B) contains (p) and
avoids (q), while (C) contains (q) and avoids (p).  The paths (D)
and (E) lie in (Q-\{p,q\}), span all eight vertices, and have endpoints
(v,x) and (u,y), respectively.  Thus (4) realizes exactly the five roles
in (1).

Moreover, the three cycles (A_0,B,C) cover every edge in (2).  In
particular, the root (Q) is (P_2)-Hamiltonian, and every edge retained
after deleting (p,q) has nonempty six-role support.  No enumeration or
computer search is used in these assertions; each is an edge-by-edge check
of the five displayed sequences.

## Arbitrary CEN/UV histories

After the first expansion, choose either the CEN or UV successor site, and
repeat this choice independently after every later expansion.  The transfer
relations of Note 010 satisfy

\[
M_{\mathrm{CEN}}(V_0)=M_{\mathrm{UV}}(V_0)=V_0.
\tag{5}
\]

Every nonempty support state remains nonempty under both relations.  The
transferred interface witnesses cover all retained edges, and the canonical
(A_0,B) traversals cover the newly installed gadget.  Hence induction from
(4) gives:

> For every word in ({\mathrm{CEN},\mathrm{UV}}^*), the corresponding
> descendant of the cube is a (P_2)-Hamiltonian Barnette graph.

The graph at depth (k) has order

\[
n=8+4k.
\tag{6}
\]

This is an all-depth analytic conclusion.  The older 240-vertex certificate
remains a separate large explicit application, but it is not needed for the
existence theorem.

## Rooted types and the unlabelled count

Set

\[
R=Q-\{01,23\}.
\tag{7}
\]

The eight old vertices are fixed pointwise in the rooted construction.  The
local patch installed at the first expansion is the basic four-pole (B) of
Note 011.  Subsequent CEN and UV choices are exactly its two outer-annulus
operators (F_0,F_1).  Therefore the rooted two-step delay theorem applies
without change: the number of pointwise-rooted graph types at depth (k) is

\[
T_k=2^{\max(k-2,0)}.
\tag{8}
\]

Fix an unlabelled (n)-vertex descendant (H).  A rooted realization of
(H) determines an injection of the eight labelled old vertices into
(V(H)).  As in Note 011, rooted types over (H) inject into the
(operatorname{Aut}(H))-orbits of these injections.  Thus one unlabelled
graph supports at most

\[
(n)_8=\frac{n!}{(n-8)!}
\tag{9}
\]

rooted types.  No uniqueness or intrinsic recognizability of (R) inside
(H) is assumed.

Let (B_{\mathrm{EH}}(n)) be the number of isomorphism classes of
(n)-vertex (P_2)-Hamiltonian Barnette graphs.  Partitioning the rooted
types by their underlying unlabelled graph gives the explicit lower bound

\[
\boxed{
B_{\mathrm{EH}}(8+4k)
\ge
\left\lceil
\frac{2^{\max(k-2,0)}}{(8+4k)_8}
\right\rceil .
}
\tag{10}
\]

For (k=0), (10) follows separately from the cube itself.  For (k\ge2),
write (n=8+4k).  Then (k-2=n/4-4), and ((n)_8\le n^8), so

\[
B_{\mathrm{EH}}(n)
\ge
2^{\,n/4-8\log_2 n-4}.
\tag{11}
\]

Consequently, along (n\equiv0\pmod4), (n\ge8),

\[
\boxed{
B_{\mathrm{EH}}(n)\ge2^{\,n/4-O(\log n)}.
}
\tag{12}
\]

## Scope

Equation (10) is a lower bound, not an exact enumeration.  The construction
does not assert that arbitrary legal (C_4)-expansions preserve
(P_2)-Hamiltonicity, nor that the old cube core is uniquely recognizable
in an unlabelled descendant.  It concerns the two recursively selected CEN
and UV sites only.  It does not prove or assume Barnette's conjecture.

As of the 2026-08-25 decision search recorded in
`../scratch/worker-barnette/novelty-decision-exponentially-many-p2-barnette-graphs.md`,
no source was found that states the same-order exponential lower bound
(12).  This supports only qualified novelty language; the inaccessible full
replacement theorem of Kao--Chen 2005 remains an external comparison gate.
