> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Four-block (H^{+-}) closure and the common-incidence boundary

This note records the current exact decomposition of the arbitrary HMM
(C_4)-expansion problem.  It is a boundary result, not a proof of
Barnette's conjecture.

## Exact child criterion

Let (p=uv,q=xy) be a legal expansion site, let (R=G-{p,q}), and let

\[
 A=C_{11},\quad B=C_{10},\quad C=C_{01},\quad
 D=X_{vx},\quad E=X_{uy},\quad L=L_{(uv)(xy)}.
\]

For a concrete traversal witness (W), retain its actual edge support in
(R).  For (r,sin E(R)), write (T_r^+) (respectively (T_r^-)) for
the traversal types having a witness containing (respectively avoiding)
(r), and (T_{r,s}^{+-}) for types having a witness containing (r) and
avoiding (s).  Directly partitioning ordered child-edge pairs gives the
following equivalence:

\[
\begin{array}{ll}
\mathrm{RR}:&T_{r,s}^{+-}\ne\varnothing\quad(r\ne s);\\
\mathrm{RJ}:&T_r^+\text{ contains one of }ABC,DEL,BCDE;\\
\mathrm{JR}:&T_r^-\text{ contains one of }AB,AC,AL,BC,DE,DL,EL;\\
\mathrm{JJ}:&A,B,C,D,E,L\text{ are all nonempty}.
\end{array}
\tag{1}
\]

The four conditions are necessary and sufficient for the child to have the
global (H^{+-})-property.  The type names in (1) are not enough: every
existential statement is about one concrete matching/path witness and its
retained-edge support.

## What current hypotheses do not imply

Parent (H^{+-}) and cubic endpoint forcing give only

\[
T_r^\pm\cap\{A,B\}\ne\varnothing,
\qquad
T_r^\pm\cap\{A,C\}\ne\varnothing.
\tag{2}
\]

The six-state criterion, the seven gadget-edge covers, and the recurrent
central support maps prove neither the remaining parts of (1) nor their
joint witness conditions for an arbitrary site.  A three-point incidence
model already satisfies parent ordered-pair separation and all six type
names while violating (RJ); a dual model violates (JR).  The retained-pair
condition (RR) likewise requires one witness carrying both incidences.

## The rooted crossing interface

For a legal-wide root-square decoration, let (mathcal T_e) be the complete
rooted two-linkage family and let (Gamma_{g_1}(mathcal T_e)) join pairs
whose matching difference is one alternating cycle.  The scalar statement

\[
P_{\mathrm{wide}}:
\quad \Gamma_{g_1}(\mathcal T_e)\ne\varnothing
\Longrightarrow |E\Gamma_{g_1}(\mathcal T_e)|\ge2
\tag{3}
\]

is not sufficient for (1): it does not record the six traversal families,
retained-edge supports, or the legal root/gate decoration of the expansion
site.  An additional `FailReduction` theorem would be needed to convert a
failure of any one of (RR)--(JJ) into a legal-wide instance with at most one
rooted crossing.

The only unconditional consequence of matching incidence is the following.
If (F=P(G)\cap\{x_e=x_{g_0}=1\}), (mathcal T\subseteq V(F)) is the
rooted family, and a unique crossing (MN) exists in the induced rooted
exchange graph, then (MN) is a bridge.  If (d=\dim F\ge2), Balinski's
theorem and Menger's theorem give

\[
|V(F)\setminus\mathcal T|\ge d-1.
\tag{4}
\]

Indeed, the (d-1) detours avoiding (MN) must each pass through a distinct
non-rooted perfect matching; otherwise one detour would contain another
rooted sector-changing edge.  Thus complete perfect-matching incidence
excludes a unique crossing only under an additional root-preserving detour
condition (or a bound opposite to (4)).

## Decision boundary

The current proof and counterexample pulses establish neither (3) nor any
universal implication from (3) to (1).  The next valid targets are therefore
the concrete incidence/connected-complement statements for (JJ), (RJ),
(JR), and (RR), together with a `FailReduction` that preserves legal-wide
root data.  Further parity, type-label, or unconditioned census arguments
cannot decide the arbitrary HMM closure problem.

This note uses the exact interface analyses in Notes
[013](013-h-plus-minus-parent-forces-a-p2-hamiltonian-c4-child.md),
[015](015-exact-matching-and-decorated-boundary-for-c4-h-plus-minus-preservation.md),
[016](016-retained-edge-pairs-require-joint-decorated-traversals.md),
[162](162-cycle-space-boundary-for-rooted-crossing-cut.md), and
[163](163-m1-global-interface-and-anchor-repair-condition.md).
