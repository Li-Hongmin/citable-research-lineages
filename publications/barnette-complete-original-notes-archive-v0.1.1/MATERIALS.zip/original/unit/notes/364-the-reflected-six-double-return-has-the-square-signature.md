> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The reflected six-double return has the square Hamilton signature

[Note 359](359-a-six-double-global-return-has-two-reflected-spanning-halves.md)
determines the unique matching under \(h_1j_6,k_1j_3\)
and gives an \(o_1\)--\(e_6\) spanning route.
That matching also has the full four-terminal square
signature. The missing path state is obtained from a
second spanning route through one three-block half.

Use Note 359's six consecutive \(J_3,J_1,J_3,J_1,J_3,J_1\)
blocks, its common-face chords (1) and opposite-page
matching (2). Let \(T\) be the induced 48-vertex
disk patch, omitting the four exterior attachment
edges at terminals
\[
                         (a_1,o_1,e_6,b_6) .             \tag{1}
\]

**Reflected-return square theorem.** The Hamilton
single-path and two-path signature of \(T\) at (1)
equals that of the square with the same terminal
order. Replacing \(T\) by the square, or conversely,
preserves Barnette membership and every exterior
and attachment-edge Hamilton decision. The matching
is realized in an explicit 60-vertex Barnette parent
with a Hamilton cycle through both site edges;
its legal site-expanded child is Hamiltonian.
A vertex-minimal non-Hamiltonian Barnette graph
therefore contains no induced disk copy of \(T\).

**Two routes through the left half.** Let \(P\)
be Note 359 (4), a spanning \(o_1\)--\(h_1\)
path through \(D_1,D_2,D_3\). A second spanning
path through those blocks is
\[
\begin{split}
 B={}&(b_3,e_3,j_3,k_3,i_3,h_3,j_2,e_2,o_3,a_3,
 b_2,a_2,o_2,k_2,i_2,h_2,\\
 &j_1,k_1,i_1,e_1,b_1,a_1,o_1,h_1).                    \tag{2}
\end{split}
\]
Its non-old joins are \(h_3j_2,e_2o_3,a_2b_2,
o_2k_2,h_2j_1,i_1e_1,a_1b_1\).
They are all in the prescribed patch. Each of
\(D_1,D_2,D_3\) contributes eight vertices once,
so \(B\) spans from \(b_3\) to \(h_1\).

Let \(\rho\) be the old-cycle reflection of
Note 346 (4) with \(N=6\). It fixes \(h_1j_6\)
and exchanges the two three-block matching halves
of Note 359 (2), so it is an automorphism of \(T\).
Then \(\rho(B)\) spans the right half from \(a_4\)
to \(j_6\), and \(\rho(P)\) spans it from \(e_6\)
to \(j_6\).

Delete the final \(o_1,h_1\) of \(B\), then reverse
the remaining vertex list. Call this 22-vertex
\(a_1\)--\(b_3\) path \(X\). Explicitly,
\[
\begin{split}
X={}&(a_1,b_1,e_1,i_1,k_1,j_1,h_2,i_2,k_2,o_2,
 a_2,b_2,a_3,o_3,e_2,j_2,\\
 &h_3,i_3,k_3,j_3,e_3,b_3).                            \tag{3}
\end{split}
\]
It covers the left half except \(o_1,h_1\).
The reverse of \(\rho(X)\) is an \(a_4\)--\(b_6\)
path covering the right half except \(j_6,e_6\).

**Complete terminal routes.** The full old-cycle
path spans \(a_1b_6\), and Note 359 (6) without
\(L,R\) spans \(o_1e_6\). The path
\[
  X,\ b_3a_4,\ \rho(B),\ j_6h_1,\ o_1                \tag{4}
\]
spans \(a_1o_1\): the two joins are the old
interblock edge and the displayed matching chord,
and the last join \(h_1o_1\) is old.
It covers 22 left vertices through \(X\),
all 24 right vertices through \(\rho(B)\), and
the remaining two left vertices \(h_1,o_1\).
Reflect (4) and reverse the resulting list to
obtain a spanning \(e_6b_6\) path.

For the pairing \(\{a_1b_6,o_1e_6\}\), take
the two disjoint spanning paths
\[
 \bigl(X,\ b_3a_4,\ \operatorname{rev}(\rho(X))\bigr),
 \qquad (o_1,h_1,j_6,e_6).                              \tag{5}
\]
The first has endpoints \(a_1,b_6\) and covers
the 44 vertices outside the four-vertex second path.
For the pairing \(\{a_1o_1,e_6b_6\}\), let
\(P'\) be \(P\) with its first \(o_1\) removed
and \(o_1\) appended at the end. Since \(P\)
starts \(o_1,a_1\) and ends at \(h_1\), and
\(h_1o_1\) is old, \(P'\) spans the left half
from \(a_1\) to \(o_1\). The two paths
\[
                         P',\qquad
               \operatorname{rev}(\rho(P'))              \tag{6}
\]
span the disjoint halves and have the required
endpoints.

A spanning single path has 48 vertices and
opposite-colour endpoints, so \(a_1e_6,o_1b_6\)
are impossible. The remaining two-path pairing
\(\{a_1e_6,o_1b_6\}\) would cross the disk's
terminal order (1). Thus (4)--(6), the old
path and Note 359 (6) exhaust exactly the
square's terminal states. A Hamilton cycle
uses two or four attachments, proving that
the replacement preserves every exterior
Hamilton decision.

**Realization and class preservation.** On the
60-vertex old Hamilton cycle
\[
 x,R_1,w,y,D_1,D_2,D_3,D_4,D_5,D_6,u,z,L_1,v,
       \alpha,\gamma,\delta,\beta,x,                   \tag{7}
\]
put the common-face matching chords
\(xy,uv,\alpha\beta\), all six \(a_sb_s\),
and the six alternating internal chords
of Note 359 (1). Put on the opposite page
\(\delta R_1,wo_1,e_6z,\gamma L_1\) and
the eleven internal group chords of
Note 359 (2), omitting \(Lo_1,e_6R\)
there. These two pages are noncrossing:
\(h_1j_6\) surrounds the two disjoint
left and right three-block intervals;
the remaining chords in each interval
are nested or disjoint as in Note 359's
matching exhaustion. The matching covers
each vertex once, joins opposite old-cycle
colours and contains no old edge. Hence
the graph is simple, cubic, bipartite and
plane. The common-face arc from \(y\) to
\(u\) has length 13 through the six
\(a_sb_s\) chords, and the other site arc
from \(v\) to \(x\) has length three
through \(\alpha\beta\). The site edges
\(xy,uv\) are cofacial and legal; the
residual cycle
\(\alpha\gamma\delta\beta\alpha\)
is a square with tight escape targets
\(R_1,L_1\) and no interblock gap.

For three-connectivity, join two matching
chords when their endpoints alternate on
(7). The following endpoint alternations
form a connected spanning system:
\[
\begin{gathered}
xy-wo_1-a_1b_1-h_1j_6-a_6b_6-e_6z-uv
 -\gamma L_1-\alpha\beta-\delta R_1,\\
a_1b_1-j_1h_2-a_2b_2-j_2h_3-a_3b_3,\\
a_1b_1-k_1j_3-i_1e_1,\qquad
j_1h_2-o_2k_2,\\
a_2b_2-i_2k_3-i_3e_3,\qquad
a_2b_2-e_2o_3,\\
a_6b_6-h_4i_6-a_4b_4-j_4h_5-a_5b_5-j_5h_6,\\
h_4i_6-o_4k_4,\qquad
a_4b_4-i_4k_5-i_5e_5,\qquad
a_4b_4-e_4o_5,\qquad
h_4i_6-o_6k_6 .
\end{gathered}                                           \tag{8}
\]
Every dash alternates by direct inspection
of (7). As in Note 345, a two-edge cut
would bound a proper old-cycle interval
closed under the matching and disconnect
its chord interlacement graph. Thus no
two-edge cut exists. The old Hamilton
cycle excludes bridges; a cubic
three-edge-connected graph is
three-vertex-connected.

The two internally disjoint \(x\)--\(v\)
paths
\[
 x,R_1,\delta,\beta,\alpha,\gamma,L_1,v
 \quad\text{and}\quad
 x,y,w,P,h_1j_6,Q,z,u,v                              \tag{9}
\]
cover all vertices and give a Hamilton
cycle through both site edges. Note 001
then gives the legal child's Hamilton
cycle.

Finally, deleting one vertex of \(T\)
leaves it connected. Each block cycle
remains connected; the five old
interblock edges lose at most one edge
under the deletion, while \(h_1j_6\)
survives whenever an old interblock
edge is lost and joins the first and
last block remnants. After deleting
two patch vertices, each surviving
component contains a surviving terminal:
a component without one would disconnect
from the exterior of the three-connected
realization (7). The exterior of a
four-attachment patch in any Barnette
host is connected, since two exterior
components would each need at least
three attachment edges. The
four-attachment deletion comparison
of Note 362 therefore proves that
substitution with the square preserves
three-connectivity in both directions.
Terminal colours, planar disk order,
cubicity and simplicity also agree.
\(\square\)

This result settles the four-terminal
signature of only the \(h_1j_6,k_1j_3\)
six-block word. Other six-block words,
short corridors, other opening types
and general Barnette graphs remain
outside it. This is a project-internal
analytic proof without an external
priority claim or independent review.

