> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Disjoint same-root split nodes close on the rethreaded cycle

[Note 496](496-three-cycle-splice-closes-end-middle-split-equality.md) supplies one cycle \(D_0\) through all vertices of the three base cycles, without using any face-matching chord. For two split marked unary nodes in the same root, its inner opening has exactly the two child intervals and two complementary arcs. The wrapper square used in [Note 487](487-disjoint-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md) joins those complementary arcs. The resulting component argument works even when the root face graph is connected.

Use the three-root chord-free single-hexagon order of [Note 456](456-three-root-escape-splice-closes-the-chord-free-seven-face-chord-kernel.md), and the cycle \(D_0\) of (1) in Note 496. Let two split marked unary nodes \(N_1,N_2\) lie disjointly in the same root word \(W_i\), ordered as
\[
              N_j=(H_j,s_j,A_j,t_j,J_j),\qquad
              N_1<N_2,\quad j=1,2.
\]
Write \(L_j,R_j\) for the ends of \(A_j\). Every other assigned special position belongs to a complete two-special leaf. Assume at least one of the marked nodes has an immediate plain-unary parent whose wrapper square has one old rail edge in each of the two complementary arcs after both child intervals are opened, and whose two ordinary chords are unused by \(D_0\). This square exists for the saturated two-split equality profile of [Note 477](477-four-chord-free-profiles-remain-at-the-12f-plus-2-boundary.md), as established in Note 487. The square support is disjoint from all leaf-square supports and the end escape edges.

**Disjoint same-root theorem.** Under these hypotheses, the parent has a Hamilton cycle containing both site edges. Its legal \(C_4\)-expanded child is Hamiltonian. In particular, a failure of the chord-free \(12f+2\) three-root two-split equality profile with both nodes in one root must have the nodes nested.

**Proof.** Let \(E\) be the old square-supported edge of every two-special leaf, and \(M\) the face matching except at the two site ports \(u,v\). Open both marked nodes inside their child intervals:
\[
 F_{\mathrm{ii}}=
 \bigl(D_0-E-\{s_1L_1,R_1t_1,s_2L_2,R_2t_2\}\bigr)
       \cup M\cup\{L_1R_1,L_2R_2\}.                   \tag{1}
\]
It has one \(u\)--\(v\) path and perhaps cycles. Restoring \(E\) for the component argument exposes the two closed child arcs \(A_1,A_2\), the complementary arc from \(t_1\) to \(s_2\), and the complementary arc from \(t_2\) around the rest of \(D_0\) to \(s_1\). The last arc contains both end escape edges \(t_dd,t_aa\). If the two complementary arcs belong to different components, switch at the assumed wrapper square to join them; if they already belong to one component, no wrapper switch is needed. Call their joined coarse block \(B\). All further component connections come from \(M\)-edges between \(A_1,A_2,B\). The wrapper and leaf-square supports are disjoint, so leaf-square switches along a quotient forest reduce each coarse component to one path if it contains \(u,v\), or one cycle otherwise. If a child is itself a single leaf, its inserted closing chord is the leaf-square chord, but its deleted old leaf edge is a quotient loop and no switch at that square is needed. All switches preserve the end escape edges.

If the three coarse blocks are connected, these switches give a spanning \(u\)--\(v\) path, which closes through \((u,w_0,\beta,\alpha,w_*,v)\). Otherwise each terminal-free component is one of \(A_1,A_2,B,A_1\cup A_2,A_1\cup B,A_2\cup B\). An isolated \(A_j\) without a site port is impossible: no matching edge leaves it, all its ordinary third edges are internal, and only the two old boundary edges \(s_jL_j,R_jt_j\) leave it in the cubic parent, contrary to three-connectivity. Any terminal-free component containing \(B\) contains both end escape edges. There can be at most one such component because \(B\) is a single coarse block; the one-cycle escape splice of [Note 489](489-two-end-escape-edges-absorb-both-residual-cycles.md), using \(t_dd\), absorbs it into the marked path and covers the four vertices outside \(D_0\). Thus only a terminal-free component
\[
                              S=A_1\cup A_2             \tag{2}
\]
requires another opening. It contains no site port, is joined by at least one \(M\)-edge between the children, and has no \(M\)-edge to \(B\).

Choose a node \(N_i\) with at least one non-site direct position, and write \(N_j\) for the other. Such a node exists because there are four direct positions and only two site ports. Its direct positions lie in \(B\); every non-site one has its face-matching mate in \(B\), by (2). [Note 473](473-a-split-unary-node-cannot-match-its-two-direct-positions.md) excludes \(s_it_i\) as a matching edge. Open \(N_i\) outside and \(N_j\) inside:
\[
 F_{\mathrm{oi}}=
 \bigl(D_0-E-\{H_is_i,t_iJ_i,s_jL_j,R_jt_j\}\bigr)
       \cup M\cup\{H_iJ_i,L_jR_j\}.                   \tag{3}
\]
The chord \(H_iJ_i\) is unused by \(D_0\), which contains no ordinary chord. After restoring \(E\), the coarse pieces are the central arc \(P_i=s_i\rightsquigarrow t_i\), the closed child \(A_j\), and their complementary arc \(B'\). The \(A_i-A_j\) matching edge in (2) joins \(P_i\) to \(A_j\). The chosen non-site direct position has a matching edge joining \(P_i\) to \(B'\): its mate belongs to \(B\), cannot be the other direct position of \(N_i\), and every other position of \(B\) lies in \(B'\) after the outside opening. Thus the three pieces are connected. Leaf-square switches produce a spanning \(u\)--\(v\) path, and the same outside path closes a marked parent Hamilton cycle.

The two openings cover every case. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts the marked cycle to the legal child. \(\square\)

Together with Notes [486–488](488-nested-two-split-nodes-in-isolated-site-root-have-a-hamilton-path.md) and [496](496-three-cycle-splice-closes-end-middle-split-equality.md), a possible non-Hamiltonian child in the chord-free \(12f+2\) three-root two-split equality profile must have both nodes nested in one root and a connected root face graph. The theorem does not decide that nested profile or Barnette's conjecture.
