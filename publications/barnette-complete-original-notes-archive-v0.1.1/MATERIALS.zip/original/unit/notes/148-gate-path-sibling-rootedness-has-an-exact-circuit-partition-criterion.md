> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Gate-path sibling rootedness has an exact circuit-partition criterion

[Note 140](140-short-gap-extreme-families-reduce-to-complete-family-gate-path-sibling-selection.md)
associates a canonical child matching and one gate-path sibling with every
bad short-gap bond.  This note gives a necessary-and-sufficient primal test
for that sibling to remain rooted.  The test is a circuit-partition quotient
of the canonical complementary two-factor.  It requires no planarity or
Barnette hypothesis once the canonical matching and its alternating flip
cycle have been supplied.

The criterion is the direct two-factor specialization of the
rank-and-label filter in
[Notes 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
and
[111](111-parent-bond-split-lift-calculus-and-nondirect-canonical-x-supplementation.md).
Its role is not to add a new existence mechanism.  It closes the individual
gate-sibling problem and identifies the exact family-level selection that
remains.

## 1. Alternating quotient of the canonical two-factor

Let \(H\) be a finite loopless cubic graph, let \(\widehat N\) be a
perfect matching, and
suppose

\[
 F=H-\widehat N
\tag{1}
\]

is the union of exactly two cycles.  Let \(e=r_0r_1\in\widehat N\) be a
root edge whose endpoints lie on different cycles of \(F\).
Here ``rooted'' refers to these two complement conditions.  Any additional
prescribed matching edges in the decorated application are assumed
disjoint from the flip and are therefore inherited unchanged.

Let \(D\) be a \(\widehat N\)-alternating cycle disjoint from \(e\), and
put

\[
 S=\widehat N\mathbin\triangle D.
\tag{2}
\]

In the application, \(\widehat N\) is the canonical \(C_{00}\) lift,
\(D\) is the gate-path flip cycle of Note 140, and \(S=S_g\) is its
cross-cell sibling.  Because an alternating cycle containing a root
endpoint would contain its unique \(\widehat N\)-edge \(e\), disjointness
from \(e\) also makes \(D\) disjoint from both root endpoints.

Write

\[
 W=V(D),\qquad
 A=D\cap\widehat N,\qquad B=D\cap F.
\tag{3}
\]

Both \(A\) and \(B\) are perfect matchings of \(W\).  Every component of
\(F-B\) is either a path with two distinct endpoints in \(W\), or an
original cycle of \(F\) disjoint from \(D\).  Let

* \(\alpha\) be the fixed-point-free involution of \(W\) defined by the
  matching \(A\);
* \(\tau\) pair the two endpoints of each path component of \(F-B\);
* \(z\) be the number of cycles of \(F\) disjoint from \(D\).

Define the two-coloured 2-regular multigraph

\[
 Q=Q(F,D)=(W,A\cup\tau),
\tag{4}
\]

retaining a parallel \(\alpha\)-edge and \(\tau\)-edge when the two
involutions pair the same vertices.  Write \(q(Q)\) for its number of
components and \(c(\alpha\tau)\) for the number of cycles of the
permutation \(\alpha\circ\tau\).

For each root endpoint \(r_i\), define a marker \(\kappa(r_i)\).  If its
component in \(F-B\) is an untouched cycle, mark it by that cycle.  If it
is a path, mark it by the component of \(Q\) containing the two endpoints
of that path.  Untouched-cycle labels and \(Q\)-component labels are
regarded as disjoint label sets.

## 2. Exact component and root formulas

> **Circuit-partition theorem.** With the notation above,
> \[
> \boxed{
> c(H-S)=z+q(Q)=z+\frac{c(\alpha\tau)}2.}
> \tag{5}
> \]
> Moreover,
> \[
> \boxed{
> r_0,r_1\text{ lie on different components of }H-S
> \iff \kappa(r_0)\ne\kappa(r_1).}
> \tag{6}
> \]
> Consequently \(S\) is a rooted target if and only if
> \[
> \boxed{
> z+\frac{c(\alpha\tau)}2=2
> \quad\text{and}\quad
> \kappa(r_0)\ne\kappa(r_1).}
> \tag{7}
> \]

### Proof

Flipping the matching along \(D\) removes the \(B\)-edges from the
complement and inserts the \(A\)-edges.  Hence

\[
 H-S=(F-B)\cup A.
\tag{8}
\]

Every untouched cycle of \(F-B\) remains one component.  Contract every
path component of \(F-B\) to the corresponding \(\tau\)-edge.  The other
components of (8) are then exactly the alternating cycles of
\(A\cup\tau\).  This proves

\[
 c(H-S)=z+q(Q).
\tag{9}
\]

Walking two edges at a time around a component of \(Q\) gives two cycles
of \(\alpha\tau\).  This remains true for a two-edge parallel component,
which gives two fixed points.  Thus

\[
 q(Q)=\frac{c(\alpha\tau)}2.
\tag{10}
\]

Expanding the contracted \(\tau\)-edges does not change component
membership.  The marker \(\kappa(r_i)\) therefore records exactly the
component of \(H-S\) containing \(r_i\), proving (6).  Equations
(5)--(7) follow. \(\square\)

## 3. Two-cycle specialization

Because \(F\) has two root-separated cycles and \(D\) meets at least one
of them, there are two cases.

If \(D\) meets exactly one canonical cycle, then \(z=1\).  One root
endpoint remains on the untouched cycle and the other lies in a
\(Q\)-component, so root separation is automatic.  Therefore

\[
 \boxed{
 S\text{ is rooted}
 \iff Q\text{ is connected}
 \iff c(\alpha\tau)=2.}
\tag{11}
\]

If \(D\) meets both canonical cycles, then \(z=0\), and

\[
 \boxed{
 S\text{ is rooted}
 \iff q(Q)=2
 \text{ and the two root markers lie in different }Q\text{-components}.}
\tag{12}
\]

Equivalently, the first condition in (12) is
\(c(\alpha\tau)=4\).  Component count and root separation are genuinely
independent: two resulting circuits can put both roots on one circuit, and
separated roots can coexist with a third unmarked circuit.

## 4. The fixed failure and successes

The legal-wide order-\(20\) bond in Note 140 meets both canonical cycles.
Its quotient has three components, of vertex sizes \(4,2,2\).  Thus

\[
 z=0,\qquad q(Q)=3,
\tag{13}
\]

and the sibling has three complement circuits even though its two root
markers remain separated.

For each of the two siblings in the unique frozen order-\(26\) extreme
family, the flip meets exactly one canonical cycle and its quotient is one
alternating 6-cycle.  Hence

\[
 z=1,\qquad q(Q)=1,
\tag{14}
\]

so both siblings are rooted.  These computations illustrate (11)--(12);
they do not support an arbitrary-order selection claim.

## 5. Consequences and exact remaining boundary

The occupied domino in
[Note 146](146-an-occupied-domino-portal-forces-short-gap-child-compensation.md)
is an exterior-independent sufficient mechanism for (7): its canonical
and sibling complements induce the same boundary pairing and no local
closed component.  The longer occupied faces classified in
[Note 147](147-the-square-is-the-unique-boundary-neutral-occupied-face-portal.md)
change that pairing, but a particular exterior may still satisfy (7).
Thus the circuit criterion strictly contains the local domino test while
explaining why the latter is automatic.

### The other cross sibling supplies no parity partner

For one bad bond, Note 140 supplies two disjoint canonical cross flips,
one along each path of
\((M\mathbin\triangle N)-\{p,q\}\).  Starting from the canonical
\(C_{00}\) lift of \(N\), perform both flips.  The exterior paths together
replace \(N\) by \(M-\{p,q\}\), while the patch edges become

\[
 \{ua,bv,xc,dy\},
\]

the canonical \(C_{11}\) row.  Its complement is the original two
root-separated cycles of \(G-M\), together with the isolated gadget cycle

\[
 a-b-c-d-a.
\]

The double flip therefore always has three complement circuits and is
never rooted.  Consequently the two single-cross siblings are not paired
by a four-corner parity or conservation argument: their rootedness remains
two separate instances of (7).

For an individual gate-path sibling, no local topological condition remains
unknown.  The legal-wide short-gap question is now exactly the family-level
alternative

\[
\boxed{
\begin{minipage}{0.84\linewidth}
If the complete parent family has no automatic bond, must some bad bond
have
\(z+c(\alpha\tau)/2=2\) with separated root markers, unless an unrelated
child perfect matching already supplies a new-cell bond?
\end{minipage}}
\tag{15}
\]

Notes 109 and 111 already show that the same condition is the zero
shore-rank defect plus labelled-root separation in dual NAE coordinates.
Both formulations are pointwise and supply no selection theorem.  More
importantly, the complete parent bond graph in (15) is allowed to consist
of a single bad edge, so a relation between two distinct
\(\tau\)-pairings cannot be the first missing input.

The earliest unresolved statement is the **one-bond legal-wide selection
lemma**: if a legal-wide complete parent family has exactly one bad
\(h\)-avoiding \(11\)--\(00\) bond and no automatic bond, must that
bond satisfy (7), unless an unrelated child matching supplies a new-cell
bond?  Note 145 gives a real complete one-bond failure after legal-wide is
removed.  Note 143 also shows that a legal-wide family may have exactly one
bad bond whose local star has degree one and whose sibling fails; that
family is rescued by ten automatic bonds.  Hence legal-wide alone does not
pair each bad bond with a second bad bond.  What remains unknown is whether
the additional condition ``no automatic bond'' forbids the one-bond case.

Thus a proof must first couple the same legal-wide gate-face
embedding to the complete parent and child complement partitions, or prove
that legal-wide forbids a one-bond extreme family.  Only after that step
would a cross-bond \(\tau\)-coupling become logically available.
