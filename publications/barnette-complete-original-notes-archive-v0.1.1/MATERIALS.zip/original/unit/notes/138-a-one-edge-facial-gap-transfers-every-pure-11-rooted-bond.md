> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A one-edge facial gap transfers every pure-\(11\) rooted bond

[Note 106](106-cofacial-words-determine-direct-matchings-but-not-target-admission.md)
gives the exact direct-lift criterion for a state-\(11\) matching on an
arbitrary common face, while
[Note 111](111-parent-bond-split-lift-calculus-and-nondirect-canonical-x-supplementation.md)
gives the corresponding split-bond calculus.  This note extracts their
sharpest geometric corollary and proves it directly in the original rooted
graph: if either residual facial arc has one edge, every \(11\)--\(11\)
rooted bond survives literally inside one child cross cell.

The result closes the entire pure-\(11\) branch at such a site.  It also
explains a genuine order-\(26\) complete-family example that defeats the
octagon endpoint-selection mechanism of
[Notes 136](136-hexagon-square-octagon-surgery-preserves-rooted-labels-but-is-not-locally-forced.md)
and [137](137-straight-even-face-chain-suppliers-have-an-exact-regular-language.md):
all parent bond endpoints can be local type \(P\), yet the one-edge-gap
transfer replaces the complete parent bond graph by an \(X_{vx}\) child
bond graph.

## 1. Rooted setup

Let \(G\) be a cubic graph with an inherited root edge \(e\), forced gate
\(g_0\), and surviving gate \(g_1\).  A **rooted target** is a perfect
matching \(M\) containing \(e,g_0\) such that \(G-M\) has exactly two
prescribed labelled components and the endpoints of \(e\) lie in different
components.  Its gate sector is

\[
 b(M)=\mathbf 1_{g_1\in M}.
\tag{1}
\]

Join two rooted targets in opposite sectors when their symmetric difference
is one alternating cycle.  Denote this rooted bond graph by
\(\Gamma_{g_1}(G)\).

Let two vertex-disjoint edges on one face occur in cyclic order as

\[
 p=uv,\qquad q=xy,\qquad
 u,p,v,A,x,q,y,B,u.
\tag{2}
\]

Perform the standard \(C_4\)-expansion, deleting \(p,q\), adding vertices
\(a,b,c,d\), and inserting

\[
 ua,ab,bv,xc,cd,dy,ad,bc.
\tag{3}
\]

The decoration is **interface-disjoint** when the four site endpoints avoid
the inherited root/gate interface.  In particular \(e,g_0,g_1\) remain
old edges of the child.  This is the project-level hypothesis used below;
the matching identity itself needs only the named edges and labels to be
retained.

Write \({\cal R}_{11}\) for the rooted targets containing both \(p,q\).
The two child cross-cell patch matchings are

\[
 K_{vx}=\{ad,bv,xc\},\qquad
 K_{uy}=\{ua,bc,dy\}.
\tag{4}
\]

## 2. One-edge-gap transfer theorem

**Theorem 1.**  Suppose the residual arc \(B\) is the single retained edge

\[
 h=yu.
\tag{5}
\]

For every \(M\in{\cal R}_{11}\), define

\[
 \Phi_B(M)
  =(M-\{p,q\})\cup\{h\}\cup K_{vx}.
\tag{6}
\]

Then \(\Phi_B(M)\) is a rooted child target in \(X_{vx}\), with

\[
 b(\Phi_B(M))=b(M).
\tag{7}
\]

For every \(M_0,M_1\in{\cal R}_{11}\),

\[
 \boxed{
 \Phi_B(M_0)\mathbin\triangle\Phi_B(M_1)
 =M_0\mathbin\triangle M_1.}
\tag{8}
\]

Consequently \(\Phi_B\) induces a sector-preserving graph isomorphism from
the state-\(11\) induced parent bond graph onto its image in the same-cell
child bond graph:

\[
 \boxed{
 \Gamma_{g_1}(G)[{\cal R}_{11}]
 \cong
 \Gamma_{g_1}(G^+)[\Phi_B({\cal R}_{11})]
 \subseteq \Gamma_{g_1}(G^+)[X_{vx}].}
\tag{9}
\]

If instead \(A\) is the single retained edge \(r=vx\), the reflected map

\[
 \Phi_A(M)
  =(M-\{p,q\})\cup\{r\}\cup K_{uy}
\tag{10}
\]

has the same conclusions with \(X_{uy}\) in place of \(X_{vx}\).

### Proof

Since \(p,q\in M\), the edge \(h=yu\) is absent from \(M\).  After removing
\(p,q\), the four edges

\[
 h,\ ad,\ bv,\ xc
\tag{11}
\]

cover the eight vertices \(u,v,x,y,a,b,c,d\) exactly once, while every
other old vertex keeps its mate.  Thus \(\Phi_B(M)\) is a perfect matching,
and its patch cell is \(X_{vx}\).

The complement of \(K_{vx}\) inside the patch is the path

\[
 u-a-b-c-d-y.
\tag{12}
\]

Every other old complement edge is unchanged.  Hence

\[
 G^+-\Phi_B(M)
 =\bigl((G-M)-\{h\}\bigr)
   \cup\{ua,ab,bc,cd,dy\}.
\tag{13}
\]

Equation (13) only subdivides the complement edge \(h\).  It canonically
preserves every complement component, every ordered root label, and the
separation of the root endpoints.  Therefore \(\Phi_B(M)\) is rooted
admissible.  Interface disjointness also leaves \(g_1\)-membership
unchanged, proving (7).

For two state-\(11\) targets, the removed set \(\{p,q\}\) is common and the
inserted set \(\{h,ad,bv,xc\}\) is common.  Both cancel in symmetric
difference, giving (8).  Thus a one-cycle parent difference remains
literally the same retained cycle in the child, not merely a subdivision.
Gate sectors are preserved, so every parent rooted bond gives a same-cell
\(X_{vx}\)--\(X_{vx}\) child rooted bond.  Equality (8) also preserves
nonadjacency, proving (9).

For (10), the child complement instead replaces \(r=vx\) by

\[
 v-b-a-d-c-x.
\tag{14}
\]

The same argument applies. \(\square\)

## 3. Exact consequence for supplementation

Call a parent bond **pure-\(11\)** when both endpoints lie in
\({\cal R}_{11}\).  Theorem 1 gives the sharper implication

\[
 \boxed{
 E\bigl(\Gamma_{g_1}(G)[{\cal R}_{11}]\bigr)\ne\varnothing
 \Longrightarrow \mathrm{ChildSupplement}.}
\tag{15}
\]

Indeed, the image of any such edge is a child bond with both endpoints in
one of the new cross cells.  In particular, if the parent bond graph is
nonempty and every parent bond is pure-\(11\), then ParentKill holds and
ChildSupplement follows.

The distinction is essential.  ParentKill alone says only that every
parent bond has **at least one** state-\(11\) endpoint.  If every bond is
mixed \(11\)--non-\(11\), formula (6) does not give a common same-cell lift
of its two endpoints.  Thus at a one-edge-gap site any failure of
ParentKill \(\Rightarrow\) ChildSupplement must have no \(11\)--\(11\) bond
at all; every surviving parent bond must be mixed.

## 4. A complete all-\(P\) parent family transferred to \(X_{vx}\)

Consider the order-\(26\) plane cubic bipartite graph with graph6 string

~~~text
Y?????????????w?Y?CW??w??[?EC?T??_W?D@??AK?@_O?GK??SA???
~~~

and facial site

\[
 \{p,q\}=\{3\!-25,11\!-21\}
\tag{16}
\]

on the face

\[
 (3,21,11,17,10,25).
\tag{17}
\]

Use the orientation

\[
 (u,v,x,y)=(21,11,25,3).
\tag{18}
\]

Then \(B\) is the single edge \(h=3-21\).  The third alternating edge of
the hexagon is \(10-17\); its opposite edge on the adjacent square is
\(9-20\).  As in Note 136, classify a state-\(11\) endpoint as \(X\) when
it omits \(10-17\), as \(T\) when it contains both \(10-17\) and \(9-20\),
and as \(P\) when it contains \(10-17\) but omits \(9-20\).

The complete perfect-matching family has \(254\) members.  For the four
decorations below, the complete rooted bond graph is nonempty, every bond
is pure-\(11\), and every nonisolated endpoint is type \(P\):

\[
\begin{array}{c|c|c|c|c|c|c}
e&g_0&g_1&|{\cal R}|&(|{\cal R}^0|,|{\cal R}^1|)
&|E(\Gamma)|&|V_{\ne0}(\Gamma)|\\ \hline
0\!-13&9\!-24&7\!-22&5&(3,2)&4&5\\
1\!-14&9\!-24&7\!-22&5&(3,2)&4&5\\
4\!-15&9\!-24&7\!-22&6&(5,1)&1&2\\
5\!-23&9\!-24&7\!-22&6&(5,1)&1&2.
\end{array}
\tag{19}
\]

Thus an actual complete rooted family can have pure-\(11\) bonds but no
octagon-\(X\) endpoint.  This refutes the selection statement

\[
 \text{nonempty complete pure-}11\text{ bond graph}
 \Longrightarrow
 \text{some nonisolated endpoint is type }X.
\tag{20}
\]

It does not refute ChildSupplement.  The expansion has \(528\) perfect
matchings and is again a brace: all \(900\) independent child edge pairs
extend to a perfect matching.  Theorem 1 transfers every bond in (19)
literally to an \(X_{vx}\)--\(X_{vx}\) child bond.  In the first two rows
all five parent endpoints become five \(X_{vx}\) child targets with the
same sector sizes and the same four-edge bond graph; in the last two rows
the unique parent bond gives an \(X_{vx}\)--\(X_{vx}\) child bond.

The fixed graph, complete parent and child matching families, four
decorations, all-\(P\) classification, brace test, and every transferred
symmetric-difference identity are checked by the
[one-edge-gap certificate](../computations/bundles/one-edge-gap-pure11-transfer/README.md).

## 5. Relation to the earlier calculi and boundary

Inside the historical root--forced-gate square stratum of Note 085,
Theorem 1 is already logically contained in Notes 106 and 111.  For a
one-edge arc,

\[
 w_B=(0),\qquad P_B=Q_B=\{h\}.
\tag{21}
\]

Note 106 therefore gives the direct \(X_{vx}\) target, and the \(V,V\)
diagonal of Note 111 gives the bond.  The content of Theorem 1 is the
explicit graph-level corollary (9), together with its direct extension to
arbitrary interface-disjoint rooted decorations.  That extension must be
proved in the original graph as above: the square-deletion bijection of
Note 085 is unavailable when the root and forced gate are not opposite
edges of a facial square.

The decisive equality is \(P_B=Q_B\), equivalently the subdivision identity
(13).  If both residual facial arcs have length at least three, these
connection sets differ in general, and exterior pairing or closed-component
obstructions return.  The theorem also does not transfer a mixed bond.

**Exact boundary.**  The pure-\(11\) branch of the rooted split-bond problem
is completely settled at any interface-disjoint one-edge-gap site.  The
remaining possibilities are mixed-only parent bonds at a short gap, or a
site with two longer residual arcs.  The all-\(P\) example closes the
octagon endpoint-selection route, but its short gap simultaneously explains
why it cannot be a rooted split-bond counterexample.  No general
arbitrary-gap supplementation theorem or proof of Barnette's conjecture is
claimed.
