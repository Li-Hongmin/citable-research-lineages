> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Two target-free vacancies in one group always have a marked Hamilton cycle

[Note 222](222-two-free-vacancies-with-flanks-have-at-most-two-chain-defects.md)
proves that two distinct target-free vacancy blocks, even with
arbitrary short-block flanks, have no same-block free chord and
at most two missing ordinary chain links. A crossed
reconnection of two missing links would leave a separate
alternating cycle. Planarity and three-connectivity exclude
every such reconnection.

Use a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, tight target order,
and precisely two eligible vacancies. Suppose they lie in
distinct target-free four-slot face blocks \(B_k,B_m\),
\(1\le k<m\le r\), and belong to the same free matching
group. Let that group run from \(e_d\) to \(o_b\), with
\(0\le d<k<m<b\le r+1\). All other face blocks in
the group are short; there may be any number before
\(B_k\), between \(B_k,B_m\), and after \(B_m\).

**Two-block two-vacancy Hamilton theorem.** The parent
has a Hamilton cycle containing both site edges
\(q=xy,p=uv\), and its legal site-expanded child is
Hamiltonian. The conclusion holds for arbitrary positive
original square-trap lobe lengths.

**Proof.** Let \(A\) be the even-starting old-cycle
matching from \(x\). Tight target order gives the
target-and-square \(x\)-to-\(v\) path (4) of Note 196.
Each free group without a vacancy follows the ordinary
chain by Note 208. In the exceptional group write
\[
P_j=(E_j,O_j)=(e_j,o_{j+1}),\qquad d\le j<b,
\]
for the ordinary chain links, and write
\[
X=(H_X,I_X)=(h_k,i_k),\qquad
Y=(H_Y,I_Y)=(h_m,i_m).
\]
The port pairs \(P_j\) occur in increasing order.
Both \(H_X,I_X\) lie between \(P_{k-1},P_k\);
both \(H_Y,I_Y\) lie between \(P_{m-1},P_m\).
Call a port *left*, *middle* or *right* according
as it precedes \(X\), lies between \(X,Y\), or
follows \(Y\).

By Note 222 every ordinary-to-ordinary matching edge
is a retained chain link. Let \(c\in\{0,1,2\}\)
be the number of matching edges between the four
vacancy slots. Exactly \(2-c\) chain links are
missing.

If \(c=2\), the two extra matching edges are
\(H_XI_Y,I_XH_Y\), and every chain edge is retained.
Note 217's ladder-bridge route, valid with arbitrary
ordinary chain on either flank, absorbs their
alternating square into a marked Hamilton cycle.

If \(c=1\), let \(P_s=(E_s,O_s)\) be the one missing
chain link. The remaining two vacancy slots match
its endpoints. If \(H_XI_Y\in M\), replace
\(E_sO_s\) in the ordinary free path by
\[
E_s,I_X,H_X,I_Y,H_Y,O_s.                    \tag{1}
\]
If \(I_XH_Y\in M\), replace it by
\[
E_s,I_Y,H_Y,I_X,H_X,O_s.                    \tag{2}
\]
In either line the first, middle and last new
edges belong to \(M\), the other two to \(A\).
Thus the free path stays connected and gains
all four vacancy slots.

Suppose \(c=0\). Let \(P_a,P_t\), \(a<t\),
be the two missing chain links; their four
ordinary endpoints are matched to the four
vacancy slots. Each vacancy pair makes an
alternating connection from one \(E\)-port
through its \(I,H\) slots to one \(O\)-port.
If each port pair reconnects to itself,
replace its missing edge \(E_jO_j\) by
\(E_j,I,H,O_j\). The two replacements use
disjoint edges and vertices, so they yield
one spanning free path.

It remains to exclude crossed reconnections.
There are two assignments:
\[
\begin{array}{c|cc}
&X&Y\\
\mathrm{I}&E_a\longleftrightarrow O_t&
              E_t\longleftrightarrow O_a\\
\mathrm{II}&E_t\longleftrightarrow O_a&
               E_a\longleftrightarrow O_t .
\end{array}                                               \tag{3}
\]
For type I, the matching edges include
\(E_aI_X,H_XO_t,E_tI_Y,O_aH_Y\).
If \(P_a\) is left of \(X\), then
\(E_a<O_a<H_X<I_X<H_Y\), so
\(E_aI_X\) and \(O_aH_Y\) interlace.
If \(P_a\) is right of \(Y\), then
\(I_X<H_Y<E_a<O_a\), so
\(I_XE_a\) and \(H_YO_a\) interlace.
Hence \(P_a\) must be middle. If \(P_t\)
is also middle, then
\(H_X<O_a<O_t<H_Y\), so
\(H_XO_t\) and \(O_aH_Y\) interlace.
The only remaining position is \(P_t\)
right of \(Y\).

In that position, the complete consecutive
old-cycle interval \(B_{a+1},\ldots,B_t\)
is closed under \(M\). It contains \(Y\)
but not \(X\): its boundary slots
\(O_a=o_{a+1},E_t=e_t\) match
\(H_Y,I_Y\) inside, every intermediate
ordinary chain link is retained, and every
block-closing face chord is internal.
Only the two boundary old-cycle edges leave
this interval, contrary to three-connectivity.
Thus type I is impossible.

For type II, the matching edges include
\(E_tI_X,H_XO_a,E_aI_Y,O_tH_Y\).
If \(P_a\) is middle or right, then
\(H_X<I_X<O_a<E_t\), so
\(H_XO_a\) and \(I_XE_t\) interlace.
Hence \(P_a\) is left of \(X\).
If \(P_t\) is also left, then
\(O_a<E_t<H_X<I_X\), so
\(O_aH_X\) and \(E_tI_X\) interlace.
If \(P_t\) is right of \(Y\), then
\(E_a<H_Y<I_Y<O_t\), so
\(E_aI_Y\) and \(H_YO_t\) interlace.
The only remaining position is \(P_t\)
between \(X,Y\). Now the complete block
interval \(B_{a+1},\ldots,B_t\) contains
\(X\) but not \(Y\); its boundary slots
\(O_a,E_t\) match \(H_X,I_X\) inside
and all its other matching edges are internal.
Again it is a forbidden two-edge cut.
Thus type II is impossible.

In all three values of \(c\), the free vertices
form one \(x\)-to-\(v\) path disjoint from the
target-and-square path except at their endpoints.
Their union is a Hamilton cycle containing
\(xy,uv\). Note 001 lifts it through the legal
site expansion; Note 178 restores original
lobe lengths. \(\square\)

Together with [Note 215](215-separated-vacancies-compose-marked-hamilton-routes.md),
this settles the tight, gapless \(f=4r+6\) branch
when the two vacancies are in distinct target-free
face blocks, whether or not an occupied target
separates them. It does not cover target-bearing
vacancy blocks in one group, two vacancies in a
single block, vacancies in site blocks, defective
target order, gaps or nonsquare residual cycles.
[Note 224](224-an-isolated-double-vacancy-block-has-a-unique-hamilton-matching.md)
subsequently resolves the smallest target-free
same-block free group.
