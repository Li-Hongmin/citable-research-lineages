> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# An unbounded alternating double-block chain has a marked Hamilton route

[Note 344](344-every-three-double-j1-j3-free-group-has-a-spanning-route.md)
settles every ordinary target-free group with exactly three
\(J_1/J_3\) doubly vacant blocks. Four or more mixed blocks
can occur without any consecutive \(J_3,J_1\) pair carrying
Note 335's optional square chord: there are realizable
alternating chains with one matching chord spanning the
entire chain. Every member of the family below has a
spanning free-group route
and a Hamilton cycle through both site edges.

For \(m\ge1\), put \(N=2m\) and take \(N\) consecutive
target-free doubly vacant blocks in old-cycle order
\[
D_s=(a_s,o_s,h_s,i_s,k_s,j_s,e_s,b_s),
       \qquad 1\le s\le N.                              \tag{1}
\]
For odd \(s\), prescribe the common-face internal chord
\(i_se_s=J_3\); for even \(s\), prescribe \(o_sk_s=J_1\).
There are no short blocks in this free group.

**Alternating-chain theorem.** The following is a noncrossing
complementary perfect matching on an old Hamilton cycle
\[
x,R_1,w,y,D_1,D_2,\ldots,D_N,u,z,L_1,v,
\alpha,\gamma,\delta,\beta,x.                           \tag{2}
\]
Its common-face chords are
\[
xy,\quad uv,\quad\alpha\beta,\quad
a_sb_s\ (1\le s\le N),\quad
i_se_s\ (s\text{ odd}),\quad
o_sk_s\ (s\text{ even}),                                \tag{3}
\]
and its opposite-face chords are
\[
\begin{gathered}
\delta R_1,\quad wo_1,\quad h_1j_N,\quad
e_Nz,\quad\gamma L_1,\\
j_sh_{s+1}\ (1\le s<N),\\
k_si_{s+1}\ (s<N\text{ odd}),\qquad
e_so_{s+1}\ (s<N\text{ even}).
\end{gathered}                                           \tag{4}
\]
The resulting \(16m+12\)-vertex graph is a simple
three-connected cubic bipartite plane graph with a compressed,
gapless, tight-target all-square opening. The \(N\)-block free
group has an explicit vertex-spanning \(o_1\)--\(e_N\) path.
The parent has a Hamilton cycle containing both \(xy\) and
\(uv\); its legal site-expanded child is Hamiltonian.
For \(m=1\) this recovers the adjacent \(J_3,J_1\) mixed
square case of Note 335. For every \(m\ge2\), the chord
\(h_1j_N\) reaches across at least four double blocks;
none of the \(m\) consecutive mixed pairs has the optional
local \(h_{2t-1}j_{2t}\) chord of Note 335.

**Matching and embedding.** Each vertex of (2) occurs in exactly
one chord of (3)--(4). Every chord joins opposite parities of
the old cycle and is distinct from an old-cycle edge.
The common-face chords are disjoint or nested within their
respective blocks, with \(xy,uv,\alpha\beta\) in separate
outer intervals. On the opposite side, \(\delta R_1\)
surrounds all other chords. The chord \(wo_1\) lies before
\(h_1j_N\), and \(e_Nz,\gamma L_1\) lie after it.
Within \(h_1j_N\), the chords on each odd-to-even block
transition satisfy
\[
k_si_{s+1}\supset j_sh_{s+1}\quad(s\text{ odd}),          \tag{5}
\]
while those on each even-to-odd transition satisfy
\[
j_sh_{s+1}\supset e_so_{s+1}\quad(s\text{ even}).         \tag{6}
\]
The pairs (5)--(6) lie in disjoint successive intervals.
Thus both pages are noncrossing. The two site chords
\(xy,uv\) bound the same face of this drawing.
Along that face, the \(y\)--\(u\) arc uses each
block-closing \(a_sb_s\) chord and has odd length
\(2N+1=4m+1\); the \(v\)--\(x\) arc uses
\(\alpha\beta\) and has length \(3\).
Also \(x,u\) have the same
bipartition colour. Thus this is a legal bipartite
facial \(C_4\)-expansion site.
The residual cycle \(\alpha\gamma\delta\beta\alpha\)
is a square with tight escape targets \(R_1,L_1\);
no interblock gap occurs in (2).

For three-connectivity, join two matching chords when their
endpoints alternate along (2). The interlacement graph has the
connected spanning system
\[
xy-wo_1-a_1b_1-h_1j_N-a_Nb_N-e_Nz-uv
 -\gamma L_1-\alpha\beta-\delta R_1,                  \tag{7}
\]
and, for every \(1\le s<N\),
\[
a_sb_s-j_sh_{s+1}-a_{s+1}b_{s+1}.                      \tag{8}
\]
For odd \(s<N\), attach the further branches
\[
a_sb_s-k_si_{s+1}-i_se_s,\qquad
k_si_{s+1}-o_{s+1}k_{s+1};                             \tag{9}
\]
for even \(s<N\), attach
\[
a_sb_s-e_so_{s+1}.                                    \tag{10}
\]
Every dash in (7)--(10) is endpoint alternation. For example,
\(i_s<k_s<e_s<i_{s+1}\) verifies the first branch in
(9), and \(k_s<o_{s+1}<i_{s+1}<k_{s+1}\) verifies
the second. All matching chords appear in this connected
system. A two-edge cut of a cubic Hamiltonian graph would
bound a proper old-cycle interval closed under the matching,
and hence disconnect the chord-interlacement graph.
There is no bridge because the old Hamilton cycle spans.
The graph is therefore three-edge-connected and, in the
cubic case, three-vertex-connected.

**Spanning route.** Define the descending six-vertex tuples
\[
B_t=(k_{2t+1},i_{2t+1},h_{2t+1},
     j_{2t},k_{2t},i_{2t}),\qquad 1\le t<m,             \tag{11}
\]
and the ascending tuples
\[
\begin{split}
F_t&=(h_{2t},o_{2t},a_{2t},b_{2t},e_{2t}),
                                  &&1\le t\le m,\\
G_t&=(o_{2t+1},a_{2t+1},b_{2t+1},
      e_{2t+1},j_{2t+1}),      &&1\le t<m.
\end{split}                                             \tag{12}
\]
The required path is
\[
\begin{split}
P_m={}&(o_1,a_1,b_1,e_1,i_1,h_1,
        j_N,k_N,i_N,\\
      &B_{m-1},B_{m-2},\ldots,B_1,
        k_1,j_1,\\
      &F_1,G_1,F_2,G_2,\ldots,
        F_{m-1},G_{m-1},F_m),
\end{split}                                             \tag{13}
\]
with empty \(B\)- and \(G\)-ranges when \(m=1\).
The first jump \(h_1j_N\) is the outer chord. The
descending joins \(i_{2t}k_{2t-1}\) use the odd-to-even
chords of (4), while \(h_{2t+1}j_{2t}\) use the
even-to-odd chords. The ascending joins
\(j_{2t-1}h_{2t}\) and \(e_{2t}o_{2t+1}\)
use the other edges of (4). Apart from the stated
\(h_{2t+1}j_{2t}\) join in \(B_t\), successive
vertices within each tuple are adjacent along the old
cycle or via \(a_sb_s\); the initial \(e_1i_1\)
is a common-face internal chord. Thus every successive pair
in (13) is an edge.

The initial and final pieces together use all eight
vertices of \(D_1\). For each odd \(D_{2t+1}\),
\(B_t\) uses \(k,i,h\) and \(G_t\) uses
\(o,a,b,e,j\). For each even \(D_{2t}\),
the initial piece when \(t=m\), or \(B_t\) otherwise,
uses \(j,k,i\), and \(F_t\) uses \(h,o,a,b,e\).
These sets are disjoint and exhaust every block, so
(13) is a spanning \(o_1\)--\(e_N\) path.

The two internally disjoint \(x\)--\(v\) paths
\[
\begin{split}
&x,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,w,\ P_m,\ z,u,v
\end{split}                                             \tag{14}
\]
cover all vertices. Their union is a Hamilton cycle
containing both site edges. [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
gives the legal child's Hamilton cycle. \(\square\)

For \(m=2\), (13) is the explicit 32-vertex core route
\[
\begin{split}
o_1,a_1,b_1,e_1,i_1,h_1,j_4,k_4,i_4,k_3,i_3,h_3,
j_2,k_2,i_2,k_1,j_1,h_2,o_2,a_2,b_2,e_2,\\
o_3,a_3,b_3,e_3,j_3,h_4,o_4,a_4,b_4,e_4 .
\end{split}                                             \tag{15}
\]
The 44-vertex parent is the first chain whose outer
chord bypasses a local mixed-pair square. This theorem
exhibits an unbounded realizable matching type and its
marked Hamilton route. [Note 346](346-the-alternating-rainbow-double-chain-is-square-equivalent-at-every-length.md)
subsequently proves its complete square signature and
two-way Barnette-preserving reduction. This construction
does not classify all matchings with four or more
\(J_1/J_3\) double blocks or settle Barnette's
conjecture. The proof is analytic and project-internal;
no external priority or independent review is claimed.
