> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The unique two-site kill cover supplements new fibre crossings

[Note 101](101-a-c4-expansion-kills-an-inherited-fibre-crossing-exactly-at-an-11-site.md)
gives the exact \(11\)-state test for killing an inherited fixed-fibre
crossing and shows that no one-step move clears all 69 crossings of the
Note 099 instance.  This note solves the corresponding finite set-cover
problem exactly, checks which minimum covers are realizable as successive
facial expansions, and enumerates the complete fibre of the unique final
graph.

The minimum static kill cover has size two and has three labelled solutions,
but only one can be performed sequentially.  Its two moves kill all 69 old
crossings.  Nevertheless, the final 40-vertex graph is again a legal-wide
plane brace and its enlarged 129-state fibre contains 315 new crossing
edges.  Thus the complete-fibre minimum remains one.  Killing the inherited
family is not enough: noncanonical \(00\)-reconnections and noncontractible
child matchings supply new target states.

## 1. Exact kill-set cover

For each of the 74 legal-wide facial sites \(s=\{p,q\}\) in Note 101, let
\(K_s\) be the set of old crossing pairs having an endpoint in local state
\(11\) at \(s\).  By Note 101, \(K_s\) is exactly the set killed by the
move.

Exhausting the 74 singleton sites and all

\[
\binom{74}{2}=2701
\tag{1}
\]

unordered pairs gives

\[
\boxed{
\min\left\{|\mathcal S|:\bigcup_{s\in\mathcal S}K_s
=\text{all 69 old crossings}\right\}=2.}
\tag{2}

There are exactly three labelled minimum covers.  Put

\[
\begin{aligned}
A&=\{b_2b_3,t_0t_1\},&|K_A|&=50,\\
B&=\{b_3t_1,t_0x_0\},&|K_B|&=20,\\
C&=\{t_2t_3,x_5x_9\},&|K_C|&=48,\\
D&=\{t_2x_5,t_3x_9\},&|K_D|&=21.
\end{aligned}
\tag{3}

Then the complete list is

\[
\boxed{\{A,B\},\qquad\{A,C\},\qquad\{C,D\}.}
\tag{4}

Their kill-set intersection sizes are respectively \(1,29,0\), so every
union in (4) has size 69.  The 74 labelled sites induce 55 distinct kill
masks; the empty mask occurs at the twelve zero-kill sites.

## 2. Only one minimum cover is sequentially facial

The sites \(A,B\) are crossing choices in the same original hexagonal face,
and \(C,D\) are the two opposite-edge choices in the same original square.
In either order, the first expansion splits that common face and places the
two edges of the other site on different faces.  Hence neither
\(\{A,B\}\) nor \(\{C,D\}\) is sequentially realizable.

By contrast, \(A\) lies in

\[
(b_1,b_2,b_3,t_1,t_0,x_0),
\tag{5}

and \(C\) lies in the vertex-disjoint face

\[
(t_2,x_5,x_9,t_3).
\tag{6}

Expanding either face leaves the other unchanged.  Thus \(A,C\) can be
performed in either order, and the two orders produce the same labelled
40-vertex graph and facial-cycle system.  The four selected old edges are
mutually vertex-disjoint, so the membership bits at the second site are
unchanged by the first move.  Consequently the inherited death set is
exactly

\[
K_A\cup K_C,
\tag{7}

which is all 69 old crossings.

## 3. The complete final fibre still has minimum one

The final graph has 40 vertices and 60 edges.  Its canonical sorted-edge
hash is

```text
d25416910397fe43ab2f52d17103a9039fc35454df83f49ca1010d3d14c6b998
```

It is simple, connected, plane, cubic and bipartite, has vertex connectivity
three, and retains the original facial root square and legal-wide gate face
with closed arcs \((5,5)\).  Its 3,389 perfect matchings extend all 1,650
independent edge pairs, so it is a brace.

The complete fixed-pairing fibre and its gate sectors have sizes

\[
|\mathcal L|=129,
\qquad |\mathcal L^0|=32,
\qquad |\mathcal L^1|=97.
\tag{8}

Across all \(32\cdot97\) cross-sector pairs, the number of alternating
components has distribution

\[
1^{315},\qquad2^{1004},\qquad3^{1083},\qquad
4^{528},\qquad5^{150},\qquad6^{24}.
\tag{9}

Therefore

\[
\boxed{
\min_{M\in\mathcal L^0,\,N\in\mathcal L^1}
\#\operatorname{comp}(M\mathbin\triangle N)=1.}
\tag{10}

The unique serializable minimum kill cover is not a counterexample to the
fixed-pairing crossing-cycle candidate.

## 4. Supplementation is genuinely new

One explicit final crossing has symmetric difference

\[
C_cC_dt_2x_5b_5b_4a_2a_3x_7x_8b_9b_8x_9t_3C_c,
\tag{11}

an alternating 14-cycle.  Both endpoint matchings use the non-target-
preserving \(00\)-reconnection pattern at site \(A\).  At site \(C\), one
uses pattern \(01\), while the other again uses the \(00\)-reconnection.
Contracting both gadgets gives two parent perfect matchings outside the old
fixed-pairing fibre.  Thus (11) is not a renamed survivor from the old 69.

The complete ancestry classification is

\[
315=264+51.
\tag{12}

For 264 final crossings, at least one endpoint has a noncontractible local
matching pattern.  The remaining 51 have two parent contractions, but their
ancestral pair is not an old-fibre pair.  No final crossing has an old-fibre
single-cycle ancestral pair, in agreement with (7).

## 5. Exact boundary

Equations (2)--(7) exactly close the static and sequential minimum-cover
problem on the fixed Note 099 embedding.  Equations (8)--(12) show that its
unique final graph repairs the loss by complete-fibre supplementation.
This is a finite route closure, not an arbitrary-order theorem: it does not
classify other order-40 graphs, nonminimum two-step sequences, three-step
modifications or general brace expansions.

The mathematical boundary is sharper than an ordinary hitting problem.  A
counterexample construction must simultaneously remove inherited crossings
and suppress fibre states created by noncanonical \(00\)-reconnection and
noncontractible patch patterns.  Tracking only old matchings or old
alternating cycles cannot decide the complete-fibre minimum.

The permanent
[verification bundle](../computations/bundles/note099-two-site-kill-cover-supplementation/README.md)
contains the exact cover, sequential embedding and final complete-fibre
certificates.

