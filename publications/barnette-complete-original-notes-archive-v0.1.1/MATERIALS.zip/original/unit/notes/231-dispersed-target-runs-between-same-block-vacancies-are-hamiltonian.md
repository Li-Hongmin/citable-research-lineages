> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Dispersed target runs admit a same-square Hamilton sweep

[Note 229](229-concentrated-target-runs-admit-a-two-path-hamilton-route.md)
gives a marked Hamilton cycle when the targets between two
same-block vacancies are concentrated in their block, with
other face blocks short. Its hard matching profile has a
second route that needs no concentration. The route passes
through the free interval from \(R_j\) to \(L_j\) for each
residual square \(S_j\), in descending order of \(j\).

Use the compressed all-square Barnette opening of
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
There are \(\ell\ge2\) residual squares, \(r\ge1\)
opposite-face matching chords, empty interblock gaps,
tight target order, and exactly two eligible vacancies.
The vacancies are the first and last eligible positions
of one face block \(D=B_k\), \(1\le k\le r\), with at least
one occupied target pair between them. Thus its interior
has the order
\[
o,h_1,i_1,L_s,R_{s-1},L_{s-1},\ldots,
L_{t+1},R_t,h_2,i_2,e,
\qquad s>t\ge1.                                      \tag{1}
\]
Occupied target pairs in every other main block, including
the two site blocks, are unrestricted. Every eligible
position other than the two vacancies is occupied.

**Dispersed-target theorem.** The parent has a Hamilton
cycle containing both site edges \(xy,uv\). Consequently
its legal site-expanded child is Hamiltonian. The theorem
holds for arbitrary positive original lobe lengths.

**Matching reduction.** Before the run in (1), the free
main slots form an even prefix. Note 203 excludes every
cross-block free chord over an escape target. At each
occupied run outside \(D\), at most one same-block free
chord can cross, so even-prefix parity excludes it.
At the run in \(D\), only its three free slots on each
side can be involved in crossing chords. The number of
crossing chords is zero or two. With two, colour balance
forces \(h_1i_2\), and the other chord is one of
\(oh_2,oe,i_1h_2,i_1e\). Both crossing chords lie on
the site-face side, because the escape edges occupy
the opposite disk. The first and last choices interlace
\(h_1i_2\), leaving exactly
\[
\{oe,h_1i_2\}
\quad\text{or}\quad
\{h_1i_2,i_1h_2\}.                                \tag{2}
\]
This is Note 228's local classification; its argument
does not use the number or location of other target runs.

With zero crossing chords, the two vacancy pairs belong
to separate one-vacancy free groups. The Note 208/215
short-block argument gives one three-edge replacement
of a standard free-chain link in each group. Both
replacements are disjoint, so Note 196's two paths form
a marked Hamilton cycle. For \(oe,h_1i_2\), the
neighbouring cross-block edges are forced to the
boundary slots \(e_{k-1}i_1,h_2o_{k+1}\) by the same
noncrossing and two-edge-cut argument as Note 228.
Replace the ordinary free segment through \(D\) by
\[
e_{k-1},i_1,h_1,o,a_k,b_k,e,i_2,h_2,o_{k+1}.
\tag{3}
\]
All other free groups keep their standard chains, and
the target-and-square path is unchanged. This is again
a marked Hamilton cycle.

It remains to handle \(h_1i_2,i_1h_2\). Here the four
vacancy slots are matched to one another, while all
ordinary free slots are paired by the standard links
\(e_i o_{i+1}\), \(0\le i\le r\). To see the latter,
the occupied target runs split the ordinary slots into
groups. No ordinary same-block pair is available:
in \(D\), \(oe\) would be a third crossing chord,
contrary to even-prefix parity; in every other block,
an internal crossing chord was excluded above.
Every remaining free chord joins different blocks and
lies in one noncrossing opposite-side disk. A link
skipping any complete block interval would close that
interval under the matching and create a two-edge cut,
as in Note 196. Hence every ordinary link is standard.

For each \(j=\ell,\ell-1,\ldots,1\), make a path
\(T_j\) from \(R_j\) to \(L_j\) through precisely the
free slots between these two targets on the old main
segment. If the targets are adjacent, \(T_j\) is their
old-cycle edge. Otherwise start after \(R_j\) along
old-cycle edges in its block, traverse each available
standard link \(e_i o_{i+1}\) between blocks, and end
along old-cycle edges before \(L_j\). Every complete
intervening block is short: an occupied target there
would contradict the consecutive target order
\(R_j,L_j\). The only longer free portions are
\(o,h_1,i_1\) before the run in \(D\) and
\(h_2,i_2,e\) after it; each is traversed in
old-cycle order. Thus \(T_j\) avoids all face-chord
endpoints and covers every free slot in its interval.
The paths \(T_j\) are internally disjoint and jointly
cover every free main slot, because \(R_\ell\) and
\(L_1\) occupy the first and last target positions.

One \(x\)-to-\(v\) path follows the exposed face chords:
\[
P_{\rm face}=x,y,a_1,b_1,a_2,b_2,\ldots,a_r,b_r,u,v.
\tag{4}
\]
The other starts
\[
x,\beta_\ell,\delta_\ell,R_\ell
\xrightarrow{T_\ell}L_\ell,\gamma_\ell,\alpha_\ell.
\tag{5}
\]
For \(j=\ell-1,\ldots,1\), continue from
\(\alpha_{j+1}\) through
\[
\beta_j,\delta_j,R_j
\xrightarrow{T_j}L_j,\gamma_j,\alpha_j,
\tag{6}
\]
and finally take \(\alpha_1v\). Every transition
in (4)--(6) is an edge. In particular,
\(\alpha_{j+1}\beta_j\), \(\beta_j\delta_j\),
and \(\gamma_j\alpha_j\) are old-cycle edges,
while \(R_j\delta_j\) and \(L_j\gamma_j\) are escape
matching edges. The two paths share only \(x,v\):
(4) covers the site/face chord endpoints and \(y,u\),
while (5)--(6) cover all targets, free main slots,
and all four vertices of every residual square.
Their union is a Hamilton cycle through \(xy,uv\).
Notes 001 and 178 give the legal child and restore
arbitrary positive lobe lengths. \(\square\)

**A dispersed 36-vertex realization.** Take
\(\ell=3,r=2,k=2\), with the old cycle in blocks
\[
\begin{array}{ll}
B_0:&x,R_3,e_0,y,\\
B_1:&a_1,o_1,L_3,R_2,e_1,b_1,\\
D:&a_2,o,h_1,i_1,L_2,R_1,h_2,i_2,e,b_2,\\
B_3:&u,o_3,L_1,v,\\
S_j:&\alpha_j,\gamma_j,\delta_j,\beta_j
\quad(j=1,2,3),\text{ returning to }x.
\end{array}                                           \tag{7}
\]
The complementary matching is
\[
\begin{split}
M={}&\{xy,uv,a_1b_1,a_2b_2\}\\
&\cup\{\alpha_j\beta_j,\gamma_jL_j,
          \delta_jR_j:1\le j\le3\}\\
&\cup\{e_0o_1,e_1o,eo_3,h_1i_2,i_1h_2\}.
\end{split}                                           \tag{8}
\]
Place the site/face and \(\alpha_j\beta_j\)
chords on one side of the old cycle, together with
the nested \(h_1i_2,i_1h_2\) inside \(a_2b_2\).
On the other side, the escape chords nest as
\[
R_3\delta_3\supset L_3\gamma_3
\supset R_2\delta_2\supset L_2\gamma_2
\supset R_1\delta_1\supset L_1\gamma_1.
\tag{9}
\]
The free chords \(e_0o_1,e_1o,eo_3\) occupy disjoint
gaps in this nesting. Hence the graph is simple,
cubic, bipartite, plane, and has cofacial site edges.

Its matching-chord interlacement graph is connected:
\[
\begin{split}
xy&-e_0o_1-a_1b_1-e_1o-a_2b_2-eo_3-uv
-L_1\gamma_1-\alpha_1\beta_1-R_1\delta_1-a_2b_2\\
&-L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-a_1b_1
-L_3\gamma_3-\alpha_3\beta_3-R_3\delta_3-xy.
\end{split}                                           \tag{10}
\]
Both \(h_1i_2\) and \(i_1h_2\) interlace
\(L_2\gamma_2\). Note 217's interval criterion
therefore gives three-connectivity; its cut
projection proves that the 40-vertex site expansion
is Barnette. The marked Hamilton cycle is the union
of (4), here \(x,y,a_1,b_1,a_2,b_2,u,v\), and
\[
\begin{split}
x,\beta_3,\delta_3,R_3,e_0,o_1,L_3,
\gamma_3,\alpha_3,\beta_2,\delta_2,R_2,e_1,o,
h_1,i_1,L_2,\gamma_2,\alpha_2,\beta_1,\delta_1,
R_1,h_2,i_2,e,o_3,L_1,\gamma_1,\alpha_1,v.
\end{split}                                           \tag{11}
\]
These paths cover all 36 vertices and share only \(x,v\).
\(\square\)

The theorem removes the concentration assumption of
Note 229 for vacancies at the first and last eligible
positions of one block. Vacancies that have occupied
targets outside them within that same block, vacancies
in different target-bearing blocks, outer-block vacancies,
target-order defects, gaps, and nonsquare residual cycles
remain outside its scope. It does not settle Barnette's
conjecture or assert literature novelty.
