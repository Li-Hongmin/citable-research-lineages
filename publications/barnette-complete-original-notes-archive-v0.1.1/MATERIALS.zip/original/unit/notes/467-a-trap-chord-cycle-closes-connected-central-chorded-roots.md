> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A trap-chord cycle closes connected central chorded roots

[Note 466](466-the-chorded-100-vertex-frontier-has-two-leaf-roots-and-two-exterior-face-chords.md) shows that a 100-vertex chorded equality profile has two all-leaf ordinary roots and four outside markers in the order \(z_L,t_c,t_b,z_R\), with \(z_L,z_R\) genuine face-chord endpoints. When both outer boundary edges \(w_0z_L,z_Rw_*\) are present, the trapped hexagon and its chord \(\alpha\beta\) close the inner roots into a cycle with a simple four-terminal exterior pairing.

**Central-root theorem.** Consider a chorded single-hexagon parent with old-cycle order
\[
 w_0,z_L,\ [\text{ordinary roots}],\ t_c,\
 [\text{ordinary roots}],\ t_b,\
 [\text{ordinary roots}],\ z_R,w_*,
 \alpha,a,b,c,d,\beta,w_0,
\tag{1}
\]
where at least one root lies between \(t_c,t_b\), every assigned special position belongs to a two-special ordinary leaf, and the only main vertices outside the roots and \(w_0,w_*\) are \(z_L,t_c,t_b,z_R\). The hexagon has matching chord \(ad\), trap chord \(\alpha\beta\), and escape edges \(t_cc,t_bb\). Let \(z_Lr_L,z_Rr_R\) be two distinct face-side matching chords with mates in the roots, and let \(u<v\) be the site ports in roots. If the graph \(K\) joining roots by their other face-side matching chords is connected, the parent has a Hamilton cycle containing both site edges \(q=w_0u,p=vw_*\). The legal expanded child is therefore Hamiltonian. There is no bound on the number of roots, leaves, or ordinary wrappers.

**Proof.** Take the cycle
\[
 C_*=(t_c\xrightarrow{\rm old}t_b, b,a,\alpha,\beta,d,c,t_c).
\tag{2}
\]
Its closing edges are \(t_bb\) and \(ct_c\) (the escapes), \(ba,a\alpha,\beta d,dc\) (old-cycle edges), and \(\alpha\beta\) (the trap chord). It contains every root between \(t_c,t_b\) as an old arc. Close each root before \(t_c\) or after \(t_b\) by its outer ordinary chord. These vertex-disjoint cycles \(D\) cover every parent vertex except \(w_0,z_L,z_R,w_*\).

Let \(E\) be the square-supported old edge at each two-special leaf. Let \(T=\{r_L,u,v,r_R\}\), and let \(M\) match all remaining special positions within roots. The four positions in \(T\) are distinct. Connectedness of \(K\) makes \(D\cup M\) connected. The four-terminal square-switch theorem of [Note 458](458-leaf-square-switches-and-the-exact-102-vertex-single-hexagon-frontier.md) therefore gives spanning two-path covers of \(D\) with terminals \(T\) in at least two distinct pairings.

The two disjoint exterior paths
\[
                  (r_L,z_L,w_0,u),\qquad(r_R,z_R,w_*,v)
\tag{3}
\]
cover the four vertices outside \(D\) and contain both site edges. The steps \(z_Lw_0,z_Rw_*\) are old-cycle edges by (1). Their terminal pairing is one of the three pairings of \(T\). Choose an internal pairing different from it; the union of the two path covers is one Hamilton cycle containing \(p,q\). [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md) lifts it to the expanded child. \(\square\)

At the chorded 100-vertex boundary of Note 466, one root must lie between \(t_c,t_b\). If the other root lies between \(z_L,t_c\), also between \(t_c,t_b\), or between \(t_b,z_R\), theorem (1) closes every instance whose root face graph \(K\) is connected. Hence a hypothetical 100-vertex chorded failure in these three placements requires disconnected \(K\); the placements with a root before \(z_L\) or after \(z_R\) remain outside this theorem.
