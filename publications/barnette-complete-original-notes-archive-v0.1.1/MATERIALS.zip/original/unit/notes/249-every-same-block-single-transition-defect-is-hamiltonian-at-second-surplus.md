> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Every same-block single transition defect is Hamiltonian at second surplus

[Note 248](248-all-single-endpoint-defects-at-second-surplus-are-hamiltonian.md)
leaves one target-order defect at the gapless second surplus:
a nonadjacent transition between two consecutive lobes, with
one additional vacant eligible position. If the two targets
share a block, matching barriers force the extra vacancy into
that block. Two long nested chords then let the same-square
route of [Note 231](231-dispersed-target-runs-between-same-block-vacancies-are-hamiltonian.md)
reverse an arbitrary intervening run of tight target pairs.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps, and \(s=2\), so
\(f=4r+6\). Use the blocks \(B_0,\ldots,B_{r+1}\) and target
order of [Note 197](197-gapless-square-trap-defect-budget.md).
Assume
\[
d_L=d_R=0,\qquad b=1.                         \tag{1}
\]
Let the sole defective transition \(L_j,R_{j-1}\),
\(2\le j\le\ell\), have both targets in one block \(B_h\).
The second vacant eligible position is called the *spare*;
the first lies strictly between these targets by Note 197.

**Same-block single-transition theorem.** The spare lies in
\(B_h\), either before \(L_j\) or after \(R_{j-1}\). After
reflection assume it lies before \(L_j\). Then necessarily
\(1\le h\le r+1\), and \(B_h\) begins with the free slots
\(o_h,H,I\), where \(H\) is the spare even position. For some
\(s\) with \(j\le s\le\ell\), its next targets and free slots
have the consecutive order
\[
o_h,H,I,L_s,R_{s-1},L_{s-1},\ldots,R_j,L_j,
c,d,R_{j-1},                                      \tag{2}
\]
where the target string reduces to \(L_j\) when \(s=j\),
and \(d\) is the vacancy charged to the defect. If \(e_i\)
denotes the final free even slot of \(B_i\), and \(o_{i+1}\)
the first free odd slot of \(B_{i+1}\), then the complete free
matching is
\[
M_{\rm free}=
\{e_{h-1}I,o_hd,Hc\}
\cup\{e_i o_{i+1}:0\le i\le r,\ i\ne h-1\}.     \tag{3}
\]
The parent has a Hamilton cycle containing both site edges
\(xy,uv\), and its legal site-expanded child is Hamiltonian.
Reflection handles every spare position after \(R_{j-1}\).
Original square-trap lobes may have arbitrary positive lengths.

**Location reduction.** If the spare vacancy lies in another block,
the free slots between these two targets are exactly an adjacent
odd--even pair \(c,d\). The free prefix before each target is
even. At \(R_{j-1}\), at most the final free slot \(e_h\) of its
block lies after it, so parity and Note 203 forbid every chord
across it. At \(L_j\), at most the first free slot \(o_h\) of its
block lies before it, so the same argument forbids every chord
across it. The pair \(c,d\) would have to match itself, but
\(cd\in E(C)\).

If instead both vacancies lie strictly between \(L_j\) and
\(R_{j-1}\), their four free slots occur consecutively as
\(c_1,d_1,c_2,d_2\). The same parity barriers at the two targets
close this four-slot group. Its only non-cycle opposite-colour
pair is \(c_1d_2\); the remaining pair \(d_1c_2\) is an
old-cycle edge. It has no perfect matching. These exclusions
leave precisely the same-block placements before or after the
defective transition. Reflect the old cycle and interchange
the site and lobe labels if necessary, so the spare lies
before \(L_j\).

**Forced matching.** The two vacancies are \(H,d\); every other
eligible position is occupied by a nonfinal \(L\)-target.
Before \(R_{j-1}\), the number of free main slots is even.
By [Note 203](203-all-one-chord-eight-free-square-trap-children-are-hamiltonian.md),
a cross-block free chord cannot straddle that target. Its block
has at most one later free slot, the final \(e_h\) when \(h\le r\).
Matching parity therefore excludes every same-block chord across
\(R_{j-1}\) as well.

The free prefix before \(L_j\) is also even. A cross-block chord
cannot straddle \(L_j\), while only the slots \(c,d\) lie between
it and \(R_{j-1}\). If no same-block chord crossed \(L_j\), the
adjacent pair \(c,d\) would have to match each other, impossible
because \(cd\in E(C)\). Parity therefore requires two chords
across \(L_j\). The odd slot \(c\) has only one available earlier
even mate in its block, namely \(H\), so \(Hc\in M\). The even
slot \(d\) can match \(I\), or the first free odd slot \(o_h\)
if that slot exists. The chords \(Hc\) and \(Id\) would interlace
on \(C\). Both cross \(L_j\)'s escape chord, so both would have to
lie on the common-site-face side of \(C\); planarity rules out
their interlacement. Thus \(o_hd\in M\). In particular \(h\ne0\):
the first interior slot of \(B_0\) is the occupied target
\(R_\ell\), so it cannot supply \(o_h\).

The slot \(I\) now needs a free even mate in an earlier block.
It cannot reach the final slot \(e_h\) across \(R_{j-1}\), and
\(H\) and \(d\) are already matched. If an occupied target
preceded \(H\) in \(B_h\), every cross-block chord into \(I\)
would straddle that target, contrary to Note 203. Hence no such
target exists. As every first interior slot outside \(B_0\)
is free under (1), the block begins \(o_h,H,I\): a first-slot
\(R\)-target there would create a second nonadjacent transition,
while a first-slot \(L\)-target has the wrong parity. The first
target after \(I\) must be an \(L_s\). If it were an \(R\)-target,
its preceding \(L\)-target would be in an earlier block, creating
a second defect. Every transition from \(L_s\) through \(L_j\)
is tight, so the block has exactly the target run in (2).

Suppose \(I\) matched \(e_t\) with \(t<h-1\). Any target
in a block strictly between \(B_t\) and \(B_h\) would be
straddled by this cross-block chord. The intervening blocks
are therefore short and target-free. The chord \(e_tI\) lies
opposite the site face by [Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md).
Noncrossing forces all free slots of the complete intervening
blocks to match inside it. One intervening block has adjacent
free interiors and cannot be matched internally; two or more
form a matching-closed proper old-cycle interval with a forbidden
two-edge cut, exactly as in [Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md).
Thus \(e_{h-1}I\in M\). Every remaining free group has only its
ordinary first and final slots. The same no-straddling,
noncrossing and two-edge-cut rule forces all the standard links
in (3).

**Hamilton route.** Use Note 231's exposed-face path
\[
P_{\rm face}=x,y,a_1,b_1,\ldots,a_r,b_r,u,v.     \tag{4}
\]
Ordinarily, its complementary square-sweep path travels from
\(R_t\) to \(L_t\) through the free main slots of that lobe,
then through \(L_t,\gamma_t,\alpha_t,\beta_{t-1},
\delta_{t-1},R_{t-1}\), in descending order of \(t\).
Follow this route down to \(R_s\), then traverse the ordinary
free slots through \(e_{h-1}\). Replace the next step by
\[
e_{h-1},I,H,o_h,d,c,L_j.                       \tag{5}
\]
Its successive edges belong, in order, to \(M,C,C,M,C,C\).
Continue backward along the old-cycle target string
\[
L_j,R_j,L_{j+1},R_{j+1},\ldots,R_{s-1},L_s,    \tag{6}
\]
where (6) is just \(L_j=L_s\) if \(s=j\). This reversal
visits every intervening target exactly once. From \(L_s\)
take \(L_s,\gamma_s,\alpha_s\). For each
\(t=s-1,s-2,\ldots,j\), pass through its residual square
without an escape edge, using the consecutive old-cycle path
\[
\alpha_{t+1},\beta_t,\delta_t,\gamma_t,\alpha_t.
                                                        \tag{7}
\]
After \(\alpha_j\), resume the ordinary square sweep at
\(\beta_{j-1},\delta_{j-1},R_{j-1}\), and finish at
\(L_1,\gamma_1,\alpha_1,v\). For \(s=j\), there are no
paths (7), and this is the ordinary sweep with (5) inserted.

The square-sweep path covers every target and residual-square
vertex. Its ordinary portions cover all free main slots except
\(o_h,H,I,c,d\), which (5) covers. It meets \(P_{\rm face}\)
only at \(x,v\), and every consecutive pair is an old-cycle
or matching edge. Their union is a Hamilton cycle containing
\(xy,uv\). [Notes 001](001-exact-c4-expansion-criterion-and-central-transfer.md)
and [178](178-even-four-terminal-ladders-have-the-square-hamilton-signature.md)
give the legal child and restore longer lobes. \(\square\)

**A realized 26-vertex parent.** Take \(r=1,\ell=2,h=1,j=2\).
The old Hamilton cycle has consecutive blocks
\[
\begin{array}{ll}
B_0:&x,R_2,e_0,y,\\
B_1:&a_1,o_1,H,I,L_2,c,d,R_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_1,S_2:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2),\text{ returning to }x.
\end{array}                                             \tag{8}
\]
Add the complementary matching
\[
\begin{split}
M={}&\{xy,a_1b_1,uv,
\alpha_t\beta_t,R_t\delta_t,L_t\gamma_t\ (t=1,2)\}\\
&\cup\{e_0I,o_1d,Hc,e_1o_2\}.
\end{split}                                            \tag{9}
\]
The marked Hamilton cycle is the union of
\[
\begin{split}
&x,y,a_1,b_1,u,v,\\
&x,\beta_2,\delta_2,R_2,e_0,I,H,o_1,d,c,L_2,
\gamma_2,\alpha_2,\beta_1,\delta_1,R_1,e_1,o_2,
L_1,\gamma_1,\alpha_1,v.
\end{split}                                            \tag{10}
\]
Every consecutive pair in (10) is an edge of \(C\) or (9),
and the paths share only \(x,v\) and cover all 26 vertices.

All matching pairs have opposite old-cycle parities. Put the
site, face and \(\alpha_t\beta_t\) chords on one side of \(C\),
with \(o_1d\supset Hc\) nested inside \(a_1b_1\). On the other
side, \(R_2\delta_2\) contains the disjoint branches \(e_0I\)
and \(L_2\gamma_2\); the latter contains \(R_1\delta_1\),
which contains the disjoint branches \(e_1o_2\) and
\(L_1\gamma_1\). Thus the graph is simple, cubic, bipartite
and plane, with cofacial \(xy,uv\), and \(x,u\) have the same
parity. Its matching-chord interlacement graph is connected:
\[
\begin{split}
xy-e_0I-a_1b_1-e_1o_2-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-a_1b_1-\\
L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-xy.
\end{split}                                            \tag{11}
\]
Both \(o_1d\) and \(Hc\) interlace \(L_2\gamma_2\).
The interval criterion and cut projection of
[Note 217](217-vacancy-squares-absorb-across-arbitrarily-long-short-block-ladders.md)
make the parent and its 30-vertex site expansion
three-connected Barnette graphs. Formula (10) gives their
Hamilton cycles through Note 001.

**A nonadjacent target-run realization.** Insert a tight
\(L_3,R_2\) pair between \(I\) and \(L_2\) in the face block
of (8), and insert its square \(S_3\) after \(S_2\) on the
old cycle. Relabel the target in \(B_0\) from \(R_2\) to
\(R_3\), keeping
\(L_2,c,d,R_1\) and all four free matching edges of (9).
Thus the old cycle has blocks
\[
\begin{array}{ll}
B_0:&x,R_3,e_0,y,\\
B_1:&a_1,o_1,H,I,L_3,R_2,L_2,c,d,R_1,e_1,b_1,\\
B_2:&u,o_2,L_1,v,\\
S_1,S_2,S_3:&\alpha_t,\gamma_t,\delta_t,\beta_t
\quad(t=1,2,3),\text{ returning to }x.
\end{array}                                             \tag{12}
\]
The full complementary matching is the fixed site and face
chords \(xy,a_1b_1,uv\), the square and escape chords
\(\alpha_t\beta_t,R_t\delta_t,L_t\gamma_t\) for
\(t=1,2,3\), and \(e_0I,o_1d,Hc,e_1o_2\). Its marked
Hamilton cycle consists of (4) and
\[
\begin{split}
x,\beta_3,\delta_3,R_3,e_0,I,H,o_1,d,c,L_2,
R_2,L_3,\gamma_3,\alpha_3,\beta_2,\delta_2,
\gamma_2,\alpha_2,\beta_1,\delta_1,R_1,e_1,o_2,
L_1,\gamma_1,\alpha_1,v.
\end{split}                                            \tag{13}
\]
The two paths share only \(x,v\) and cover all 32 vertices.
For a two-page embedding, place the site, face, square and
\(o_1d\supset Hc\) chords on one side, with the latter two
inside \(a_1b_1\). On the other side the escape chords nest
in target order; \(e_0I\) branches before \(L_3\gamma_3\)
and \(e_1o_2\) branches before \(L_1\gamma_1\). Every matching
pair has opposite old-cycle parity, and \(x,u\) have the same
parity. The matching-chord interlacement graph contains the
connected spine
\[
\begin{split}
xy-e_0I-a_1b_1-e_1o_2-uv-L_1\gamma_1-
\alpha_1\beta_1-R_1\delta_1-a_1b_1-\\
L_2\gamma_2-\alpha_2\beta_2-R_2\delta_2-a_1b_1-
L_3\gamma_3-\alpha_3\beta_3-R_3\delta_3-xy,
\end{split}                                            \tag{14}
\]
and \(o_1d,Hc\) both interlace \(L_3\gamma_3\). Note 217
therefore gives a 32-vertex Barnette parent and a 36-vertex
legal Barnette child; (13) and Note 001 give their Hamilton
cycles.

This closes every same-block one-transition opening at the
gapless second surplus. Cross-block transitions with a spare
vacancy, interblock gaps, nonsquare residual cycles and
Barnette's conjecture remain undecided.
