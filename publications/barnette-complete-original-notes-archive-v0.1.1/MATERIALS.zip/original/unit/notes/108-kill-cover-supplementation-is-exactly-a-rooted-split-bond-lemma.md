> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Kill-cover supplementation is exactly a rooted split-bond lemma

[Note 103](103-one-step-crossing-preservation-is-exactly-new-cell-supplementation.md)
states the remaining one-step preservation problem in a fixed-pairing
spanning-two-path fibre. [Note 107](107-cofacial-complete-family-supplementation-can-be-entirely-nondirect.md)
shows that neither a direct lift of one state-\(11\) parent nor abstract
single-cycle closure captures the needed complete-family flexibility.

The common actual incidence can instead be retained exactly in the plane
dual. Perfect matchings become nonmonochromatic-triangle binary colourings,
and single alternating cycles become bond-shore flips. Under this dictionary
the entire kill-cover supplementation proposition is equivalent to one
rooted split-bond lemma for a pair of actual Eulerian triangulations.

## 1. The dual NAE dictionary

Use the square-deletion bijection of
[Note 085](085-a-square-forced-gate-reduces-the-other-gate-to-a-two-linkage-fibre.md).
Adding the two fixed opposite root-square matching edges identifies the
residual fixed-pairing fibre \(\mathcal L\) with its rooted target family in
the original cubic plane graph \(G\). This preserves the surviving-gate bit
and all matching symmetric differences. The expansion site is disjoint from
the root square and named gates, so the same identification applies to the
child.

Let

\[
T=G^*.
\tag{1}
\]

For a binary colouring \(\chi:V(T)\to\{0,1\}\), call an edge of \(T\)
monochromatic when its endpoints have the same colour. If no triangular
face is monochromatic, each triangle has exactly one monochromatic edge.
The primal duals of those edges therefore meet each primal cubic vertex
exactly once and form a perfect matching of \(G\).

Conversely, let \(M\) be a perfect matching of \(G\). Across a dual edge,
prescribe equal colours when its primal edge lies in \(M\), and opposite
colours otherwise. Around every triangular face there are two nonmatching
edges, so the parity constraint is consistent. Since the sphere has trivial
first mod-two cohomology, this determines a binary colouring, uniquely up to
global reversal. Thus

\[
\boxed{
\{\text{perfect matchings of }G\}
\longleftrightarrow
\{\text{NAE colourings of }T\}/(\chi\sim1-\chi).}
\tag{2}
\]

Call a colouring **root-admissible** when its matching belongs to the rooted
target family, including the prescribed root separation and labelled
complement components. This retains the complete target condition rather
than replacing it by an unlabelled component count.

Let \(\chi'\) be obtained from \(\chi\) by reversing the colours on a shore
\(W\subset V(T)\). Exactly the edges of \(\delta_T(W)\) change
monochromatic status, so

\[
M_{\chi'}\mathbin\triangle M_\chi=\delta_T(W)^*.
\tag{3}
\]

A set of dual edges is a bond if and only if its primal dual is one simple
cycle. The surviving gate changes matching membership precisely when

\[
g_1^*\in\delta_T(W).
\tag{4}
\]

Define \(\mathfrak B_{g_1}(T)\) to have the root-admissible colourings as
vertices. Join \(\chi\) to \(\chi\triangle W\) when both are
root-admissible, \(\delta_T(W)\) is a bond, and (4) holds. Equations
(2)--(4) and square deletion give an exact graph isomorphism

\[
\boxed{\mathfrak B_{g_1}(T)\cong\Gamma(\mathcal L).}
\tag{5}
\]

## 2. The dual vertex split

Let \(z\) be the dual vertex of the common face containing the expanded
edges \(p=uv\) and \(q=xy\), and write

\[
p^*=zP,\qquad q^*=zQ.
\tag{6}
\]

The two residual facial arcs are the two cyclic intervals at \(z\). After
the \(C_4\)-expansion, \(z\) is replaced by vertices \(A,B,C\): \(A\)
receives the first interval, \(B\) the second, and \(C\) represents the
central square face. The local child-dual edges are

\[
AP,BP,CP,AQ,BQ,CQ,AC,BC,
\tag{7}
\]

and its four new triangular faces are

\[
ACP,\quad BCP,\quad ACQ,\quad BCQ.
\tag{8}
\]

Solving the four NAE constraints gives exactly seven colour orbits. The
monochromatic edges, hence the primal patch matching, identify them as

\[
\begin{array}{c|c|c}
\text{cell}&(A,B,C,P,Q)&\text{monochromatic local edges}\\ \hline
C_{00}&(0,0,0,1,1)&AC,BC\\
C_{10}&(0,0,1,0,1)&AP,BP,CQ\\
C_{01}&(0,0,1,1,0)&AQ,BQ,CP\\
C_{11}&(0,0,1,0,0)&AP,BP,AQ,BQ\\
R_{00}&(1,1,0,0,0)&CP,CQ\\
X_{uy}&(1,0,1,0,0)&BP,AC,BQ\\
X_{vx}&(0,1,1,0,0)&BC,AP,AQ.
\end{array}
\tag{9}
\]

The [local verifier](../computations/bundles/rooted-split-bond-reduction/README.md)
independently enumerates the \(14\) NAE assignments and their seven global
reversal orbits.

A parent colouring has local state \(11\) exactly when

\[
\chi(z)=\chi(P)=\chi(Q).
\tag{10}
\]

Its canonical extension has class \(C_{11}\); the vertex \(C\) is then an
isolated colour component, dual to the isolated complement \(C_4\), so it
is not root-admissible. The other canonical classes are in bijection with
parent root-admissible colourings outside state \(11\). By the canonical
crossing theorem of Note 103, their induced bond graph is exactly

\[
\boxed{
\mathfrak B_{g_1}(T^+)[C_{00}\cup C_{10}\cup C_{01}]
\cong
\mathfrak B_{g_1}(T)-\mathcal L_{11}.}
\tag{11}
\]

The three remaining rows of (9) are precisely the complete nondirect child
cells \(R_{00},X_{uy},X_{vx}\); no exterior connection signature or
abstract matching is inserted.

## 3. Exact equivalence

Under the parent and child brace hypotheses, \(T,T^+\) are actual
4-connected Eulerian plane triangulations related by the split (7), with
the root and surviving-gate labels inherited. A nontrivial separating
triangle would dualize to a nontrivial tight three-edge cut, which is absent
in a brace.

The kill-cover antecedent is exactly

\[
\boxed{
\text{every edge of }\mathfrak B_{g_1}(T)
\text{ has an endpoint satisfying (10)}.}
\tag{12}
\]

By (11), this says that the child has no bond edge with two canonical
endpoints. Hence the desired child crossing exists if and only if some
root-admissible colouring in one of

\[
R_{00},X_{uy},X_{vx}
\tag{13}
\]

has a shore \(W^+\) such that \(\delta_{T^+}(W^+)\) is a bond,
\(g_1^*\in\delta_{T^+}(W^+)\), and flipping \(W^+\) produces another
root-admissible colouring.

This isolates one statement.

**Rooted split-bond lemma.** Let \(T,T^+\) be the duals of an
interface-disjoint legal cofacial parent/child plane-brace expansion, with
the inherited root and surviving-gate labels. If
\(\mathfrak B_{g_1}(T)\ne\varnothing\) and (12) holds, then a colouring and
shore as above exist with the colouring in one of the three classes (13).

Combining (5), (9), and (11) gives

\[
\boxed{
\text{kill-cover supplementation for every such expansion}
\iff
\text{the rooted split-bond lemma for every corresponding split pair}.}
\tag{14}
\]

## 4. Boundary

Equation (14) is an exact analytic reduction, not a proof of the rooted
split-bond lemma. The brace axiom supplies the actual 4-connected Eulerian
triangulations and perfect matchings in the patch cells, but it does not by
itself give root-admissibility or a bond flip through \(g_1^*\).

The abstract \(\Omega\)-blocker of Note 107 does not refute the lemma because
it is not the NAE family of one actual triangulation and its split. The real
order-\(32\to36\) direct-selection witness of that note also does not refute
it because its state-\(11\) slice leaves \(51\) parent crossing edges
uncovered.

The remaining proof obligation is therefore no longer a matching-pattern or
connection-signature selection problem. It is the rooted split-bond lemma
on one actual split pair of 4-connected Eulerian triangulations, with all
three labelled root regions retained. A counterexample must realize failure
of that lemma under (12); an abstract connection-support model is
insufficient.
[Note 109](109-root-admissible-nae-colourings-have-an-exact-shore-rank-calculus.md)
expresses root-admissibility as a labelled three-region condition and gives
an exact four-rank test for its preservation under a bond-shore flip.
[Note 110](110-nonsquare-kill-cover-supplementation-holds-through-order-twenty-six-in-the-frozen-root-square-stratum.md)
then verifies the lemma on all \(322\) eligible nonsquare kill-cover hits in
the frozen direct-root-square through-order-\(26\) stratum.
