> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# The chorded seven-face-chord normal form has a Hamiltonian 92-vertex realization

[Note 416](416-a-chorded-seven-face-chord-failure-has-one-seven-leaf-root.md) gives a necessary normal form for any non-Hamiltonian child in the chorded single-hexagon, \(f=7\) branch. That normal form is compatible with a genuine Barnette parent and a legal expansion, even when the serial odd-pole reduction of [Note 412](412-two-odd-ladder-poles-compose-to-one-odd-ladder-signature.md) is absent. The particular realization below has a direct Hamilton certificate.

As in [Note 413](413-a-seven-leaf-barnette-kernel-can-avoid-the-serial-odd-pole.md), use paired parentheses as ordinary matching chords. Put
\[
 U_i=((x_i y_i)),\quad F(A,B)=(((A B))),\quad F_0(A,B)=((A B)),
\]
\[
 D=F(F(U_1,U_2),F(U_3,U_4)),\qquad
 W=F_0\bigl(F(D,U_5),F(U_6,U_7)\bigr).              \tag{1}
\]
The branch tree has seven leaves and six binary branches. Its five nonroot branches each have two plain-unary wrappers, the root has one, and every leaf has one. Consequently \(W\) contains \(14+5\cdot3+2=31\) parenthesis pairs and \(14\) special vertices, so \(|W|=76\).

Let \(C\) be the 88-vertex cycle
\[
 C=(w_0,z_L,t_c,W,t_b,z_R,w_*,\alpha,a,b,c,d,\beta,w_0).
                                                               \tag{2}
\]
Besides the 31 parenthesis-pair edges, add the thirteen matching edges
\[
\begin{array}{c|l}
\text{site}&q=w_0y_1,\quad p=x_7w_*\\
\text{main face}&z_Lx_1,\ x_2y_3,\ y_2x_3,\ x_4y_6,\ y_4x_5,\ y_5x_6,\ y_7z_R\\
\text{escape}&t_cc,\quad t_bb\\
\text{trapped hexagon}&\alpha\beta,\quad ad.
\end{array}                                                     \tag{3}
\]
Call the parent graph \(G=C\cup M\), and expand the cofacial site \(p,q\) to obtain \(G^+\).

**Realization theorem.** The graph \(G\) is an 88-vertex Barnette graph, and \(G^+\) is a 92-vertex Barnette graph. The selected facial arc \(w_*,\alpha,\beta,w_0\) traps exactly the chorded hexagon \((\alpha,a,b,c,d,\beta)\), with escape count \(e=2\) and seven additional face-side main chords. The ordinary forest is doubly reduced with \(c=31\), one root, seven leaves and six unmarked binary branches. Its main order is precisely
\[
                        w_0,z_L,t_c,W,t_b,z_R,w_*,
\]
and its three sibling-leaf pairs \((1,2),(3,4),(6,7)\) contain no joining chord of Note 412. Both \(G\) and \(G^+\) are Hamiltonian: the proof below gives a Hamilton cycle of \(G\) containing both \(p,q\), which lifts through the square expansion by [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md). Thus this 92-vertex necessary shape is realizable, but this realization is not a counterexample.

**Matching, colours and embedding.** The 14 \(x_i,y_i\) positions in \(W\) are used exactly once: \(y_1,x_7\) are site ports; \(x_1,y_7\) meet the two exterior face endpoints; and the remaining ten positions form the five internal face chords in (3). The other six outside main vertices \(w_0,z_L,t_c,t_b,z_R,w_*\) have their listed distinct mates. The six trapped vertices are matched by \(\alpha\beta,ad,t_bb,t_cc\). Hence (3) and the ordinary chords form a perfect matching disjoint from \(C\), making \(G\) simple and cubic.

Index \(w_0\) by 0. The word \(W\) starts at index 3. In the full six-branch tree of Note 413 all seven leaves have even depth. Removing one root wrapper in (1) flips the parity of every leaf special position, so all \(x_i\) are even-indexed and all \(y_i\) odd-indexed. Parenthesis pairs always join opposite parities. The outside indices are \(z_L=1,t_c=2,t_b=79,z_R=80,w_*=81\), followed by \(\alpha,a,b,c,d,\beta\) at \(82,83,84,85,86,87\). Every edge in (3) joins opposite index parities, proving bipartiteness.

Draw the site edges, seven main-face chords, \(\alpha\beta\) and \(ad\) on one side of \(C\). The chord \(z_Lx_1\) lies inside \(q=w_0y_1\). The pairs \(x_2y_3,y_2x_3\) are nested in the first middle block, while \(x_4y_6\) encloses the disjoint pairs \(y_4x_5,y_5x_6\) in the second. The chord \(y_7z_R\) lies inside \(p=x_7w_*\). The two hexagonal chords are nested within their disjoint boundary interval. Thus this page is noncrossing. On the opposite page, the ordinary parentheses are nested or disjoint, and the two escape chords \(t_cc,t_bb\) are nested around the ordinary word: \(t_c<W<t_b<b<c\). That page is noncrossing. The site edges border the same face; one of its arcs is exactly \(w_*,\alpha,\beta,w_0\). Its literal opening traps the stated hexagon, whose only internal nonclosure matching chord is \(ad\).

**Three-connectivity and legality.** The matching-chord interlacement graph relative to \(C\) is connected. The site chord \(q\) interlaces all ordinary chords on the branch path to \(U_1\), and \(p\) interlaces those on the path to \(U_7\). The face chord \(x_2y_3\) joins the leaf chords of \(U_2,U_3\) and crosses the branches containing \((1,2)\) and \((3,4)\); \(x_4y_6\) joins \(U_4,U_6\) across the left and right branch subtrees; and \(y_4x_5\) joins \(U_4,U_5\). Thus all leaf and branch chords lie in the component of \(q,p\); the other face chords meet the same leaf components. The escape edge \(t_cc\) interlaces \(q\), the edge \(t_bb\) interlaces \(p\), and \(\alpha\beta,ad\) interlace escape edges. This accounts for every matching edge. A two-edge cut in a graph with Hamilton cycle \(C\) would bound a \(C\)-interval closed under the matching, disconnecting this interlacement graph. There is no bridge because \(C\) spans. Hence \(G\) is three-edge-connected and, being cubic, three-vertex-connected.

The square expansion is plane and bipartite with the same colour orientation at \(q=w_0y_1\) and \(p=x_7w_*\). It is also three-connected by the standard deletion comparison used in Note 413: \(G-\{p,q\}\) is connected; an intact square reconnects every component after up to two old-vertex deletions; after one square-vertex and one old-vertex deletion, an old component missing all surviving spokes would give a vertex cut of size at most two in \(G\); and after two square-vertex deletions, each remaining square vertex still attaches to \(G-\{p,q\}\). Thus the expansion is legal in the Barnette class.

**Hamilton certificate.** Write the six vertices of each leaf \(U_i\), in old-cycle order, as
\[
             L_i,h_i,x_i,y_i,j_i,R_i.
\]
The ordinary chords in the leaf are \(L_iR_i\) and \(h_ij_i\). Three spanning leaf paths, each read in the displayed order, are
\[
\begin{aligned}
Y_i&=(y_i,x_i,h_i,j_i,R_i,L_i),\\
X_i&=(R_i,L_i,h_i,j_i,y_i,x_i),\\
O_i&=(L_i,h_i,x_i,y_i,j_i,R_i).
\end{aligned}                                                   \tag{4}
\]
For an occurrence of \(F(A,B)\), denote its three left brackets by \(\lambda_0,\lambda_1,\lambda_2\), its three right brackets in old-cycle order by \(\rho_2,\rho_1,\rho_0\), and its first and last vertices by the subscripted symbols \(F_\ell,F_r\). The matching includes each \(\lambda_k\rho_k\). For \(F_0(A,B)\), use two brackets on each side, indexed \(0,1\) in the same way. Bracket names in different occurrences refer to different vertices.

For \(F_0(U_i,U_j)\), the following is a spanning \(y_i\)--\(x_j\) path:
\[
y_i\xrightarrow{Y_i}L_i,\lambda_1,\lambda_0,\rho_0,\rho_1,
R_j\xrightarrow{X_j}x_j.                                      \tag{5}
\]
The step \(\lambda_0\rho_0\) is an ordinary chord; the other four steps between leaf paths are old-cycle edges. Put \(A=F(U_1,U_2)\) and \(B=F(U_3,U_4)\). In \(A\), the outer chord \(A_\ell A_r\) and the path (5), denoted \(Q_A:y_1\to x_2\), are vertex-disjoint and together cover \(A\). In \(B\), the two disjoint covering paths are
\[
B_\ell,\lambda_1^B,\lambda_2^B,
L_3\xrightarrow{Y_3^{-1}}y_3,
\qquad
x_4\xrightarrow{X_4^{-1}}R_4,
\rho_2^B,\rho_1^B,\rho_0^B=B_r.                         \tag{6}
\]
Here \(Y_3^{-1}\) and \(X_4^{-1}\) mean the paths in (4) read backwards.

Put \(D=F(A,B)\). Its vertices split into the following disjoint paths \(P_D:D_\ell\to y_1\) and \(Q_D:x_4\to D_r\):
\[
\begin{aligned}
P_D={}&D_\ell,\lambda_1^D,\lambda_2^D,A_\ell,A_r,
 B_\ell\xrightarrow{(6)}y_3,
 x_2\xrightarrow{Q_A^{-1}}y_1,\\
Q_D={}&x_4\xrightarrow{(6)}B_r,
 \rho_2^D,\rho_1^D,\rho_0^D=D_r.
\end{aligned}                                                     \tag{7}
\]
The edge \(A_\ell A_r\) is the outer ordinary chord of \(A\), \(A_rB_\ell\) is an old-cycle edge, and \(y_3x_2\) is the face chord in (3). Thus every junction in (7) is an actual edge.

Put \(L=F(D,U_5)\) and \(R=F(U_6,U_7)\). The two covering paths in \(L\) are
\[
\begin{aligned}
P_L={}&y_1\xrightarrow{P_D^{-1}}D_\ell,
 \lambda_2^L,\lambda_1^L,\lambda_0^L=L_\ell,\\
Q_L={}&x_4\xrightarrow{Q_D}D_r,
 L_5\xrightarrow{O_5}R_5,
 \rho_2^L,\rho_1^L,\rho_0^L=L_r.
\end{aligned}                                                     \tag{8}
\]
The outer chord \(R_\ell R_r\) and the path (5) inside \(R\), denoted \(Q_R:y_6\to x_7\), are disjoint and cover \(R\). Finally, \(W=F_0(L,R)\) has the spanning path
\[
 y_1\xrightarrow{P_L}L_\ell,
 \lambda_1^W,\lambda_0^W,\rho_0^W,\rho_1^W,
 R_r,R_\ell,L_r\xrightarrow{Q_L^{-1}}x_4,
 y_6\xrightarrow{Q_R}x_7.                                      \tag{9}
\]
The junctions \(R_rR_\ell\) and \(x_4y_6\) are respectively the outer chord of \(R\) and the face chord in (3); \(R_\ell L_r\) is an old-cycle edge. Equations (4)--(9) partition all \(76\) vertices of \(W\) into paths before joining them, so (9) visits each exactly once.

Appending the twelve vertices outside \(W\) gives the Hamilton cycle
\[
w_0\xrightarrow{q}y_1\xrightarrow{(9)}x_7
\xrightarrow{p}w_*,z_R,t_b,b,a,\alpha,\beta,d,c,t_c,z_L,w_0.  \tag{10}
\]
Its non-cycle edges outside \(W\) are precisely \(q,p,t_bb,\alpha\beta,t_cc\); every other listed step is an edge of \(C\). Thus (10) contains both site edges. The direct lift in Note 001 replaces them with the corresponding paths through the new square and yields a Hamilton cycle of \(G^+\).

**Reduction boundary.** The ordinary containment forest has one plain-unary ancestor per leaf, two per nonroot branch and one at the root. It contains neither a four-rung ordinary ladder nor a mixed leaf ladder of Note 410, so it is doubly reduced. The only sibling leaves consecutive in the full old-cycle order are \((1,2),(3,4),(6,7)\). Their possible serial chords would be \(y_1x_2,y_3x_4,y_6x_7\), none of which is in (3). The explicit Hamilton cycle above settles this particular realization, not every graph in the necessary class of Note 416. \(\square\)
