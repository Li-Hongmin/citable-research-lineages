> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Edge-source completion and common deletion at a capped brace

Let \(F\) be a plane cubic bipartite brace with global \(H^{+-}\), let
\(z\in V(F)\), and write

\[
N_F(z)=\{a_1,a_2,a_3\},\qquad h_i=za_i.
\tag{1}
\]

Let \(p=uv\) lie on the face containing \(h_1,h_2\), with \(h_3\)
off that face.  The cap signatures \(P_i,K_i\) are those of
[Notes 020--021](021-cap-colour-regimes-and-near-matching-coalescence.md).
This note identifies the exact full-family condition behind their
cardinality criterion and separates it from generic discrete convexity.

## The full fixed-star tree families

Let \(\mathsf T=F^*\).  We identify a primal edge with its dual label.  For a
primal support \(B\subseteq E(F)\), put

\[
\lambda_B(w)=|B\cap\delta_F(w)|.
\tag{2}
\]

Tree--cotree duality gives

\[
B^*\text{ is a spanning tree of }\mathsf T
\quad\Longleftrightarrow\quad
F-B\text{ is a spanning tree of }F.
\tag{3}
\]

For \(r\in\{1,2,3\}\), retain the whole fixed-star family

\[
\mathcal B_r=
\{B:B^*\text{ is a spanning tree},\ p,h_r\in B\},
\qquad
\Lambda_r=\{\lambda_B:B\in\mathcal B_r\}.
\tag{4}
\]

No pair of distinguished source trees is built into (4).

## Exact edge-source completion in the \(P\)-regime

Assume that \(u\) and \(z\) have the same bipartite colour, and define

\[
\alpha=\mathbf1+e_u+e_v,\qquad
\beta_r=\mathbf1+e_z+e_{a_r},\qquad
\gamma=\mathbf1+e_v+e_z.
\tag{5}
\]

Global \(H^{+-}\) supplies both edge-source loads.  A Hamilton cycle
containing \(p\) and avoiding \(h_r\) gives

\[
B=(E(F)\setminus C)\cup\{p\}\in\mathcal B_r,
\qquad \lambda_B=\alpha.
\]

Reversing the ordered edge pair gives a Hamilton cycle containing \(h_r\)
and avoiding \(p\), and hence a member of \(\mathcal B_r\) with load
\(\beta_r\).  Thus

\[
\boxed{\alpha,\beta_r\in\Lambda_r\qquad(r=1,2,3).}
\tag{6}
\]

The target load has an exact cap interpretation.  If
\(B\in\mathcal B_r\) has load \(\gamma\), then (3) and cubicity imply that
\(F-B\) is a Hamilton \(v\)-\(z\) path avoiding \(p,h_r\).  Its edge at
\(z\) is \(h_i\) for some \(i\ne r\), and deleting \(z\) gives a \(P_i\)
path.  Conversely, a \(P_i\)-path followed by \(h_i\) is such a Hamilton
\(v\)-\(z\) path, and its cotree belongs to every \(\mathcal B_r\) with
\(r\ne i\).  Therefore

\[
\boxed{
\gamma\in\Lambda_r
\quad\Longleftrightarrow\quad
P\setminus\{r\}\ne\varnothing.}
\tag{7}
\]

It follows that

\[
\boxed{
|P|\ge2
\quad\Longleftrightarrow\quad
\gamma\in\Lambda_1\cap\Lambda_2\cap\Lambda_3.}
\tag{8}
\]

Equivalently, let

\[
\mathcal E_r=
\{\{s,t\}:F-\{p,h_r\}
\text{ has a Hamilton }s\text{-}t\text{ path}\}.
\tag{9}
\]

Global \(H^{+-}\) gives

\[
\{u,v\},\{z,a_r\}\in\mathcal E_r.
\tag{10}
\]

The remaining assertion for this label is precisely the facial
edge-source completion

\[
\boxed{
\{u,v\},\{z,a_r\}\in\mathcal E_r
\quad\Longrightarrow\quad
\{v,z\}\in\mathcal E_r.}
\tag{\mathrm{FEC}_r}
\]

Consequently the \(P\)-part of the cap-cardinality criterion is equivalent
to \(\mathrm{FEC}_r\) for all three labels.  When \(v=a_h\), the second
source in (10) already gives the target for \(r=h\), but this produces only
one member of \(P\setminus\{h\}\); the second label still requires another
\(\mathrm{FEC}_r\).

## Generic discrete convexity is too strong

If every \(\Lambda_r\) were \(M\)-convex, unit exchange from \(\alpha\)
towards \(\beta_r\) at coordinate \(u\) would give \(\gamma\).  The other
formal receiving coordinate gives
\(\mathbf1+e_v+e_{a_r}\), which cannot be the load of a Hamilton path
because \(v,a_r\) have the same bipartite colour.  Thus generic
\(M\)-convexity would prove every \(\mathrm{FEC}_r\).

It is nevertheless false in an actual admissible brace.  Consider the
order-\(16\) graph

    OlCGHD@?g?_@@@A?_?k?P

from Note 021.  It is a plane cubic bipartite global-\(H^{+-}\) brace, and
one face has boundary

\[
(13,4,3,0,15,14).
\tag{11}
\]

Fix \(p=14\,15\) and \(h_1=13\,4\).  The graph \(F-\{p,h_1\}\) has
Hamilton paths

\[
\begin{aligned}
C_A={}&(6,7,2,1,8,9,10,11,14,13,12,5,4,3,0,15),\\
C_B={}&(4,3,2,7,6,9,8,1,0,15,10,11,14,13,12,5).
\end{aligned}
\tag{12}
\]

Their cotrees lie in the full family \(\mathcal B_1\), with loads

\[
\rho_A=\mathbf1+e_6+e_{15},\qquad
\rho_B=\mathbf1+e_4+e_5.
\tag{13}
\]

Exchange of coordinate \(15\) of \(\rho_A\) towards \(\rho_B\) has only
the receiving coordinates \(4,5\).  The first candidate
\(\mathbf1+e_6+e_4\) is impossible because \(6,4\) have the same colour.
The second is also absent.  Indeed, a Hamilton \(6\)-\(5\) path would force
\(3\,4,4\,5\), since vertex \(4\) has degree two after deleting the fixed
edges.  Since \(5\) is an endpoint, \(5\,12\) is absent.  The degree-two
vertices \(13,14\) then force
\(12\,13,13\,14,14\,11\), after which vertex \(12\) forces \(12\,11\).
This creates the proper cycle

\[
11,12,13,14,11,
\]

contrary to a spanning path.  Hence neither unit exchange exists and

\[
\boxed{\Lambda_1\text{ is not }M\text{-convex}.}
\tag{14}
\]

The endpoint family \(\mathcal E_1\) is likewise neither a rank-two
matroid base family nor a delta-matroid feasible-set family.  This also
rules out obtaining the needed property automatically from Lorentzian
support after the endpoint-incidence monomial projection of the graphic
basis polynomial.

The obstruction in (13) does not refute \(\mathrm{FEC}_r\):
\(\{6,15\}\) is not the endpoint set of an edge of \(F\).  The surviving
positive statement is specifically about the two edge-source loads in
(6), not arbitrary members of \(\Lambda_r\).

The fixed graph assertion and the four endpoint pairs are independently
checked by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_capped_brace_full_family_mconvex_boundary.py

with terminal marker

    CAPPED_BRACE_FULL_FAMILY_MCONVEX_BOUNDARY_VERIFIED

## Pairwise source rerouting still does not prove \(\mathrm{FEC}_r\)

Let \(M_p,M_h\) be complementary perfect matchings of two edge-source
Hamilton cycles: the first cycle contains \(p\) and avoids \(h_r\), while
the second contains \(h_r\) and avoids \(p\).  Thus
\[
h_r\in M_p\setminus M_h,\qquad
p\in M_h\setminus M_p.
\tag{15}
\]

Their symmetric difference is a disjoint union of alternating cycles.  If
\(p,h_r\) lie on the same component, matching parity and the bipartite
colours identify an alternating \(u\)-\(z\) arc on that component avoiding
both special edges.  Switching \(M_p\cup\{p\}\) along this arc changes its
load from
\[
\mathbf1+e_u+e_v
\quad\text{to}\quad
\mathbf1+e_v+e_z.
\tag{16}
\]
The complementary degree pattern is therefore the desired \(v\)-\(z\)
path pattern, but it may consist of that path together with residual
cycles.  The switch proves \(\mathrm{FEC}_r\) only when this complement is
connected.

If \(p,h_r\) lie in different components of
\(M_p\triangle M_h\), no switch on a single alternating component of this
source pair can move the excess from \(u\) to \(z\).  This failure can
persist for every possible pair of edge-source witnesses.  In the same
order-\(16\) brace, with
\[
p=14\,15,\qquad h_1=4\,13,
\]
there are three \(p\)-source Hamilton matchings and three \(h_1\)-source
Hamilton matchings.  In all nine pairings the two special edges lie in the
distinct alternating squares
\[
(4,13,12,5,4),\qquad (14,15,10,11,14).
\tag{17}
\]
Nevertheless the target Hamilton path exists:
\[
(14,11,10,15,0,1,8,9,6,7,2,3,4,5,12,13).
\tag{18}
\]

Thus optimizing over every pair of edge-source witnesses still does not
prove facial edge-source completion.  A successful argument must introduce
at least a third compatible witness, use support outside the selected
source pair, or establish connectedness of a target-load complement
directly.  The nine-pair assertion is checked by the same verifier above,
with the additional marker

    FEC_PAIRWISE_SOURCE_REROUTING_BOUNDARY_VERIFIED

## Common deletion is indispensable in the \(K\)-regime

Assume now that \(u,z\) have opposite colours, and put

\[
\eta=\mathbf1+e_v-e_z.
\tag{19}
\]

Let \(\mathcal I_\eta\) consist of the edge sets \(A\) such that

\[
A^*\text{ is a spanning two-component forest of }\mathsf T,
\qquad p\in A,
\qquad \lambda_A=\eta.
\tag{20}
\]

Every such \(A\) avoids all three cap edges.  Define

\[
\mathcal D_r=
\{A\in\mathcal I_\eta:(A+h_r)^*
\text{ is a spanning tree of }\mathsf T\}.
\tag{21}
\]

For \(\{i,j,k\}=\{1,2,3\}\), the common-deletion characterization of
Note 021 is exactly

\[
\boxed{
K_i
\quad\Longleftrightarrow\quad
(\mathcal D_j\cap\mathcal D_k)\setminus\mathcal D_i
\ne\varnothing.}
\tag{22}
\]

The same rank-\((r(\mathsf T)-1)\) forest \(A\) must extend to trees with
\(h_j,h_k\) but not with \(h_i\).  Separate one-tree marginals do not
contain this equality of the deleted support.

There is a more geometric form of (18).  The three dual cap edges bound the
triangular face of \(\mathsf T\) corresponding to \(z\).  If
\(X_A,\overline X_A\) are the two components of \(A^*\), put

\[
\sigma(A)=
\{r:h_r^*\in\delta_{\mathsf T}(X_A)\}.
\tag{23}
\]

Then \(A\in\mathcal D_r\) exactly when \(r\in\sigma(A)\).  Moreover,

\[
\boxed{|\sigma(A)|=2\qquad(A\in\mathcal I_\eta).}
\tag{24}
\]

Indeed, \(A^*\) is acyclic, so bond--cycle duality makes \(F-A\)
connected.  Its load and edge count make it a spanning unicyclic graph
with degree three at \(z\), degree one at \(v\), and degree two elsewhere.
It is therefore a lollipop: one cap edge lies on its \(v\)-\(z\) tail and
the other two lie on its unique cycle.  A cap dual edge crosses the two
components of \(A^*\) exactly when its primal edge lies on that cycle.

Let \(t_i\) be the vertex of the dual cap triangle opposite \(h_i^*\), and
define

\[
\mathcal F_i=
\{A\in\mathcal I_\eta:
\sigma(A)=\{1,2,3\}\setminus\{i\}\}.
\tag{25}
\]

Thus \(K_i\) means precisely that \(t_i\) is the cap-triangle vertex
separated from the other two by the component cut of \(A^*\).

Planarity excludes \(K_3\).  Hence the \(K\)-part of the cardinality
criterion is equivalent to the two simultaneous assertions

\[
\boxed{
\begin{aligned}
(\mathcal D_2\cap\mathcal D_3)\setminus\mathcal D_1&\ne\varnothing,\\
(\mathcal D_1\cap\mathcal D_3)\setminus\mathcal D_2&\ne\varnothing.
\end{aligned}}
\quad\Longleftrightarrow\quad
\boxed{\mathcal F_1\ne\varnothing,\qquad\mathcal F_2\ne\varnothing.}
\tag{26}
\]

Ordinary one-edge fundamental exchange cannot move between these fibres.
More generally, if two supports \(A,A'\) in a simple graph have the same
vertex-load vector and \(A'=A-e+f\), equality of the loads forces \(e,f\)
to have the same unordered endpoint pair, hence \(e=f\).  Consequently
the one-delete/one-add exchange graph on \(\mathcal I_\eta\) has no
nontrivial edge.  Any proof of (22) by exchange must move an alternating
cycle, or several such cycles, while preserving the dual two-forest
condition.

In the fixed order-\(16\) brace above, take
\[
z=13,\qquad (u,v)=(14,15),\qquad
(h_1,h_2,h_3)=(13\,4,13\,14,13\,12).
\]
The complete fixed-load family has
\[
|\mathcal I_\eta|=7,\qquad
|\mathcal F_1|=4,\qquad
|\mathcal F_2|=3,\qquad
|\mathcal F_3|=0.
\tag{27}
\]
The closest witnesses in the two nonempty fibres differ on the alternating
square \(0-1-2-3-0\), a two-edge-for-two-edge exchange.  These assertions
are checked by

    uv run --python 3.12 --with networkx \
      units/barnette/scratch/worker-c4-hpm/verify_k_common_deletion_exchange_boundary.py

with terminal marker

    K_COMMON_DELETION_EXCHANGE_BOUNDARY_VERIFIED

## Boundary

Equations (8), \((\mathrm{FEC}_r)\), and (22)--(26) are exact equivalences,
not new existence assertions.  The capped-brace cardinality criterion
remains unresolved: no actual brace counterexample is known, and the
edge-source completions and common-deletion intersections have not been
proved in general.  Equation (14) closes the generic
\(M\)-convex/matroid/delta-matroid route, (15)--(18) close pairwise
source-component rerouting, and the load argument after (26) closes
ordinary one-edge fundamental exchange in the \(K\)-slice.

Even a proof of the cardinality criterion would settle only the cross
traversal at a tight splice.  Mixed and retained--retained ordered-edge
blocks would still remain before global \(H^{+-}\) preservation under an
arbitrary legal \(C_4\)-expansion could follow.
