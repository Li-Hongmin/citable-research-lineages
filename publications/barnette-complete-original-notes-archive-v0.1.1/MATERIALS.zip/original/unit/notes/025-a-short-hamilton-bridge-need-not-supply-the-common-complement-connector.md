> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A short Hamilton bridge need not supply the common-complement connector

The compatible-bridge mechanism of
[Note 024](024-fixed-load-lattice-extrema-and-four-edge-bond-boundary.md)
has an essential existential quantifier. Even in a plane cubic bipartite
brace with global (H^{+-}), an arbitrarily chosen compatible bridge need
not contain a facial edge-source completion in its full common complement.
This remains false when both bridge steps are alternating (6)-cycles.

## The order-(18) brace and legal site

Let (F) be the graph with graph6 string

```text
Q??????wE_P_?wGo@cAc?EG?d??
```

and edge set

\[
\begin{aligned}
E(F)=\{&09,0\,10,0\,11,19,1\,10,1\,15,29,2\,13,2\,17,
3\,10,3\,15,3\,16,\\
&4\,11,4\,14,4\,16,5\,11,5\,14,5\,17,6\,12,6\,13,
6\,15,7\,12,7\,13,7\,17,8\,12,8\,14,8\,16\}.
\end{aligned}
\tag{1}
\]

It is simple, planar, cubic, bipartite, (3)-connected and
(2)-extendable. It has (56) perfect matchings, of which (20) have
Hamiltonian complements. Those twenty matchings realize global
(H^{+-}): for every ordered pair of distinct edges (e,f), one of their
complementary Hamilton cycles contains (e) and avoids (f).

One facial boundary is

\[
(0,9,2,17,5,11).
\tag{2}
\]

Use the (P)-regime orientation

\[
(u,v,z,a)=(0,9,5,11),\qquad p=09,\quad h=5\,11.
\tag{3}
\]

Thus (u,z) are in the same bipartition class, and the two residual facial
arcs have odd lengths (3) and (1).

## A compatible short bridge whose fibre has no target

Consider the three Hamilton-complement perfect matchings

\[
\begin{aligned}
L={}&\{6\,12,4\,16,8\,14,2\,17,0\,10,5\,11,7\,13,3\,15,19\},\\
W={}&\{6\,12,2\,17,0\,10,5\,14,8\,16,7\,13,4\,11,3\,15,19\},\\
R={}&\{6\,12,2\,17,1\,15,5\,14,09,3\,10,8\,16,7\,13,4\,11\}.
\end{aligned}
\tag{4}
\]

Their ((p,h))-membership states are (01,00,10). Moreover

\[
L\triangle W=(4,16,8,14,5,11,4),\qquad
W\triangle R=(0,10,3,15,1,9,0),
\tag{5}
\]

so both bridge steps are single alternating (6)-cycle exchanges.

Put

\[
K=E(F)\setminus(L\cup W\cup R)
\tag{6}
\]

and take the complete common-complement fibre

\[
\mathcal R(L,W,R)=
\{T\in\operatorname{PM}(F-\{u,a\}):T\setminus W\subseteq K\}.
\tag{7}
\]

It has exactly three members:

\[
\begin{aligned}
T_1={}&\{6\,12,5\,17,8\,16,7\,13,29,1\,10,4\,14,3\,15\},\\
T_2={}&\{5\,17,8\,16,29,6\,13,7\,12,1\,10,4\,14,3\,15\},\\
T_3={}&\{6\,15,5\,17,7\,13,3\,16,8\,12,29,1\,10,4\,14\}.
\end{aligned}
\tag{8}
\]

For each (T_i), the graph

\[
F-\{p,h\}-T_i
\tag{9}
\]

has degree one at (v,z) and degree two elsewhere, but its component-order
profiles are respectively

\[
(6,12),\qquad(4,6,8),\qquad(6,12).
\tag{10}
\]

Thus no member of the entire fibre has a connected complement, and the
bridge supplies no Hamilton (v)-(z) path target.

## Exact boundary

The obstruction belongs to the selected bridge, not to the site. The graph
(F-\{u,a\}) has (15) perfect matchings, four of which do have connected
complements in (F-\{p,h\}). At this site the complete Hamilton family has
layer sizes

\[
(|V_{00}|,|V_{01}|,|V_{10}|,|V_{11}|)=(6,4,4,6).
\tag{11}
\]

There are (34) compatible (01-00-10) bridges and (19) have a target in
their common-complement fibre. The bridge in (4) is the unique bridge whose
two exchange orders are both (6), and it is unsuccessful. Consequently

\[
\boxed{
\text{compatible bridge, even with exchange orders }(6,6),
\not\Longrightarrow
\text{decorated common-complement tree connector}.}
\tag{12}
\]

This does not refute the existential selection statement that every legal
site in a global-(H^{+-}) brace has *some* successful bridge. It also does
not refute preservation of global (H^{+-}) under (C_4)-expansion. It
does prove that a positive argument must couple bridge selection to the
target fibre; neither common-neighbour existence nor minimizing the two
exchange-cycle lengths is sufficient.

The finite certificate is verified by

```bash
uv run --python 3.12 --with networkx \
  units/barnette/computations/verify_order18_short_bridge_fibre_failure.py
```

with terminal marker

```text
ORDER18_SHORT_BRIDGE_FIBRE_FAILURE_VERIFIED
```
