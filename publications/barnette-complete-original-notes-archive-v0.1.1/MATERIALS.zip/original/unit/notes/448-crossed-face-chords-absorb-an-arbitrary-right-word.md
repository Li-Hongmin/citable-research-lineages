> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Crossed face chords absorb an arbitrary right word

The last row-IV/V short-leaf word in [Note 447](447-the-fourth-matching-short-sixth-leaf-word-has-a-four-chord-path.md) has an outer part that can be absorbed without examining its inner forty-vertex core. The absorption works with an arbitrary right word and gives a precise smaller port problem; it does not itself decide the final word's Hamiltonicity.

Let \(C\) be any nonempty consecutive ordinary word with first and last vertices \(C_\ell,C_r\). Let \(V\) be another disjoint consecutive ordinary word, with first and last vertices \(V_\ell,V_r\). Put
\[
A=F(C,U_5),\qquad B=F(U_6,V),\qquad W=F(A,B),
\tag{1}
\]
where \(U_5,U_6\) are full leaves and all three displayed branches are full. Suppose the matching contains the crossed face chords \(y_5x_6,x_5y_6\). Write \(\overleftarrow V\) for the reverse complete old-cycle path from \(V_r\) to \(V_\ell\), and use [Note 428](428-the-two-chord-route-closes-the-noncomb-five-leaf-word.md)'s bracket path \(P_W\).

**Crossed-word absorption lemma.** There is a \(C_\ell\)--\(C_r\) path whose internal vertices are exactly \(V(W)\setminus V(C)\):
\[
\begin{aligned}
C_\ell,&\lambda_2^A,\lambda_1^A,\lambda_0^A,
\lambda_2^W\xrightarrow{P_W}\rho_2^W,
B_r=\rho_0^B,B_\ell=\lambda_0^B,\\
&A_r=\rho_0^A,\rho_1^A,\rho_2^A,
R_5,j_5,y_5,
x_6,h_6,L_6,
\lambda_2^B,\lambda_1^B,\rho_1^B,\rho_2^B,\\
&V_r\xrightarrow{\overleftarrow V}V_\ell,
R_6,j_6,y_6,
x_5,h_5,L_5,
C_r.
\end{aligned}
\tag{2}
\]
The jumps \(y_5x_6\) and \(y_6x_5\) are the two assumed face chords. The edges \(B_rB_\ell\) and \(\lambda_1^B\rho_1^B\) are ordinary chords, as are those inside \(P_W\). Every other transition between displayed pieces is a consecutive old-cycle edge:
\[
\begin{gathered}
C_\ell\lambda_2^A,\quad \lambda_0^A\lambda_2^W,\quad
\rho_2^WB_r,\quad B_\ell A_r,\quad
\rho_2^AR_5,\quad L_6\lambda_2^B,\\
\rho_2^BV_r,\quad V_\ell R_6,\quad L_5C_r.
\end{gathered}
\tag{3}
\]
The left and right triples of \(A\), all six brackets of \(W\), and the outer pair plus inner four brackets of \(B\) occur once. The two segments of \(U_5\) in (2) are \((R_5,j_5,y_5)\) and \((x_5,h_5,L_5)\); those of \(U_6\) are \((x_6,h_6,L_6)\) and \((R_6,j_6,y_6)\). The reverse old-cycle path covers every vertex of \(V\), regardless of its internal matching. Thus (2) has \(|V|+32\) distinct vertices, including its two endpoints, and covers all of \(W\setminus C\) internally. \(\square\)

Consequently, any spanning path of \(C\) between two internal terminals that uses the outer ordinary chord \(C_\ell C_r\) extends to a spanning path of \(W\) with the same terminals: replace that chord by (2). This implication preserves any site edges or other marked edges outside the replaced chord.

**Residual-word application.** The sole row-IV short-leaf depth word left by Note 447 has
\[
C=F(U_1,D),\qquad D=F(E,U_4),\qquad
E=F(U_2,S_3),\qquad S_3=(L_3,x_3,y_3,R_3),
\quad V=U_7.
\tag{4}
\]
Here \(|C|=40\), and (1) reproduces the ordinary depth vector \((3,5,5,4,2,2,2)\). Row IV of [Note 426](426-five-leaf-face-matchings-have-three-unresolved-shapes.md) supplies both crossed chords in the lemma. Hence the 36 vertices outside \(C\) admit the exact port route (2). A spanning \(y_1\)--\(x_2\) path of \(C\) using \(C_\ell C_r\) would prove the child Hamiltonian via the fixed outside route and [Note 001](001-exact-c4-expansion-criterion-and-central-transfer.md); [Note 449](449-the-residual-forty-vertex-core-has-no-internal-marked-path.md) proves that no internal \(y_1\)--\(x_2\) spanning path of \(C\) exists. [Note 450](450-the-fourth-and-fifth-face-matchings-are-hamiltonian-in-the-two-eligible-kernel.md) instead closes the residual word using \(x_3y_7\) and \(y_3x_4\).
