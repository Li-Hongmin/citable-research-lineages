> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# Fixed-lobe chord amplification preserves two Hamilton witnesses

[Note 189](189-two-opposite-face-chords-attain-the-ten-free-vertex-bound.md)
attains the two-chord lower bound in every all-square lobe
count. Its new inner square can be expanded repeatedly while
preserving both marked Hamilton witnesses. This gives an
unbounded opposite-face chord count at each fixed lobe count.

Use the notation of Notes 176--179. A Barnette parent \(G\)
has a Hamilton cycle \(C\) avoiding the disjoint cofacial
site edges \(p=uv,q=xy\). Its selected alternating
\(v\)-to-\(x\) site-face arc leaves \(\ell\ge1\) residual
square-trap lobes. Write \(S_0\) for the \(x\)-to-\(v\)
main segment, \(f=|V(S_0)|-2\ell-4\), and \(r\) for the
number of complementary-matching edges on the other
\(y\)-to-\(u\) site-face arc.

**Marked square amplifier.** Suppose \(G\) also has a
Hamilton cycle \(D\) containing both \(p,q\). Suppose a
facial square has boundary
\[
A,B,W,Z,A,
\tag{1}
\]
where \(A,B,W,Z\) are consecutive on \(S_0\), the first
three edges \(AB,BW,WZ\) belong to \(C\), and the closing
edge \(AZ\) belongs to \(M=E(G)\setminus E(C)\) and to
the \(y\)-to-\(u\) site-face arc. Assume \(D\) uses \(AZ\)
and avoids \(BW\). Then a legal \(C_4\)-expansion of the
opposite square edges \(AZ,BW\) produces a Barnette
parent \(G'\) with Hamilton cycles \(C',D'\) of the same
marked types. The original site \(p,q\) remains legal,
its expanded child is Hamiltonian, and
\[
\ell'=\ell,\qquad r'=r+1,\qquad f'=f+4.
\tag{2}
\]
The new parent has another square satisfying the same
hypotheses, so the operation may be repeated indefinitely.

**Proof.** Delete \(AZ,BW\), add \(h_1,h_2,h_3,h_4\),
and insert exactly the edges
\[
Ah_1,\ h_1h_2,\ h_2Z,\quad
Wh_3,\ h_3h_4,\ h_4B,\quad
h_1h_4,\ h_2h_3.
\tag{3}
\]
Their square \(h_1h_2h_3h_4h_1\) embeds inside (1).
Along the old face the endpoints of \(AZ,BW\) occur in
the order \(A,Z,W,B\). Bipartiteness gives \(A,W\) one
colour and \(Z,B\) the other, so (3) is a plane bipartite
cubic expansion.

Replace \(BW\) in \(C\) by
\[
B,h_4,h_1,h_2,h_3,W.
\tag{4}
\]
This visits all four new vertices once and gives \(C'\).
Its complementary matching replaces \(AZ\) by
\(Ah_1,h_2Z,h_3h_4\). Replace \(AZ\) in \(D\) by
\[
A,h_1,h_4,h_3,h_2,Z.
\tag{5}
\]
This gives \(D'\), still containing \(p,q\). The common
site face replaces its edge \(AZ\) by
\(A,h_1,h_2,Z\), whose first and last edges are in the
new matching. Thus it gains one matching edge and remains
alternating if it was alternating before. The selected
\(v\)-to-\(x\) face arc and every residual square are
unchanged. All four new vertices lie on \(S_0'\), proving
(2).

For three-edge-connectivity, consider any edge cut of
\(G'\) of size at most two. If the new square lies wholly
on one shore, assigning its four vertices to that shore
projects to an old cut of no greater size; the case where
the other shore has no old vertex has four crossing
attachments. If the square is split, at least two of its
internal edges cross. A cut of size at most two would
therefore have no crossing old or attachment edge. Each
shore contains old vertices, because every square vertex
has an attachment. In \(G\) those old shores would be
separated only by a subset of the two deleted edges
\(AZ,BW\), contradicting three-edge-connectivity.
Thus \(G'\) is three-edge-connected, and cubicity upgrades
this to three-vertex-connectivity. The same argument
applies to the still cofacial site \(p,q\), making its
expansion Barnette. Since \(D'\) contains both site edges,
Note 001 directly lifts it to a Hamilton cycle of that
child.

Finally the face next to the common site face across
\(Ah_1\) is
\[
A,B,h_4,h_1,A.
\tag{6}
\]
Its first three edges belong to \(C'\), its closing edge
\(Ah_1\) belongs to the new matching and the site face,
and \(D'\) contains \(Ah_1\) by (5). Because \(D\) avoided
\(BW\), the route (5) also makes \(D'\) avoid \(Bh_4\).
So (6) satisfies every hypothesis of the amplifier.
\(\square\)

**Two-parameter existence theorem.** For every pair of
integers \(\ell,r\ge1\), there is a Barnette parent and
legal site-expanded Barnette child with the all-square
opening above, exactly \(\ell\) residual square-trap
lobes, exactly \(r\) opposite-face matching edges, and
\[
f=4r+2,\qquad |V(S_0)|=2\ell+4r+6.
\tag{7}
\]
Both site-face arcs alternate between \(C\)-edges and
complementary-matching edges; the opposite arc has length
\(2r+1\).
Both parent and child are Hamiltonian. In the parent,
one marked Hamilton cycle avoids \(p,q\), while another
contains both. Every lobe may have arbitrary positive
length.

For \(r=1\), the \(\ell=1\) base is Note 184's
same-gap core and the \(\ell\ge2\) bases are Note 182's
family, all with \(f=6\) and the two marked Hamilton
cycles. Note 189 supplies \(r=2\) for every \(\ell\), with
\(f=10\). In its construction, the square
\[
a,b,\omega,\xi,a
\tag{8}
\]
has the form (1): the selected old-cycle edge is
\(b\omega\), the common-face matching edge is \(a\xi\),
and the second Hamilton cycle contains \(a\xi\) but
avoids \(b\omega\). Applying the amplifier \(r-2\)
times proves (7). Note 178 replaces any residual square
by a longer even ladder without changing \(S_0\), either
site-face arc, or either marked Hamilton decision.
\(\square\)

Consequently the opposite-face chord count is unbounded
even at a fixed number of square-trap lobes and with a
Hamiltonian expanded child. Let \(f_{\min}(\ell,r)\)
be the minimum free-vertex count among legal all-square
openings with the indicated lobe and opposite-face chord
counts. For \(r\ge2\), Notes 188 and (7) give
\[
2r+6\le f_{\min}(\ell,r)\le4r+2,
\tag{9}
\]
with equality at \(r=2\). Equation (7) is an existence
construction; it does not assert that its upper bound is
optimal for \(r\ge3\) or decide Hamiltonicity of arbitrary
all-square openings.
[Note 191](191-exact-single-lobe-chord-packing-and-hamiltonicity.md)
subsequently proves optimality and classifies equality
for \(\ell=1\);
[Note 192](192-two-lobes-have-the-exact-chord-packing-bound.md)
proves optimality for \(\ell=2\), and
[Note 193](193-three-lobes-have-the-exact-chord-packing-bound.md)
does so for \(\ell=3\).
[Note 195](195-exact-lobe-independent-opposite-face-chord-packing.md)
subsequently proves that the construction attains the exact
minimum \(f_{\min}(\ell,r)=4r+2\) for every
\(\ell,r\ge1\).
[Note 196](196-every-exact-square-trap-chord-packing-child-is-hamiltonian.md)
subsequently shows that every graph at this minimum
has a Hamiltonian site-expanded child.
