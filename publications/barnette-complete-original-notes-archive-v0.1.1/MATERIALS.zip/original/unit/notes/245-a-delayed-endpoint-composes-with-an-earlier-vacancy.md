> Archival source, not an accepted theorem. Complete original note body follows, with only local/coordination references projected. Historical failures, errors, claims and permission wording remain historical. Current credit: Li Hongmin; AI roles disclosed; own original text CC BY 4.0. Cited third-party quotations retain source rights. See package REVIEW, CHALLENGE and dependency ledger.

# A delayed endpoint composes with an earlier vacancy

[Note 244](244-a-double-delayed-endpoint-has-a-forced-rainbow-hamilton-route.md)
settles the second-surplus opening when both vacancies precede the
first target inside its own block. Here one vacancy lies in an
earlier block. The free matching before the target has exactly two
possible mechanisms: a direct five-edge target detour, or the
first-surplus endpoint detour surrounding a one-vacancy free group.

Let \(G,C,M\) be a compressed all-square Barnette opening with
\(\ell,r\ge1\), empty interblock gaps and \(s=2\), so \(f=4r+6\).
Assume \(d_L=1\), \(b=d_R=0\). Suppose \(R_\ell\) is the third
interior slot of \(B_h\), with first two free slots \(o_h,w\),
and the other vacant eligible position lies in an earlier block
\(B_k\), \(0\le k<h\). Write the four free interiors of \(B_k\) as
\(o_k,h_k,i_k,e_k\) in old-cycle order, with \(h_k\) the vacancy.
Every other block before \(B_h\) is short. Use \(e_j,o_{j+1}\)
for the ordinary free slots on consecutive block boundaries.

**Earlier-vacancy theorem.** The parent has a Hamilton cycle
containing both site edges \(xy,uv\), and its legal site-expanded
child is Hamiltonian. More precisely, its free-slot matching is
one of the following forms:
\[
\begin{array}{ll}
\text{direct, }k\ge1:
&\{o_0h_k,i_kw\}\cup
 \{e_j o_{j+1}:0\le j\le r\},\\[2mm]
\text{rainbow:}
&\{o_0w,e_{t-1}i_k,h_k o_t\}\cup
 \{e_j o_{j+1}:0\le j\le r,\ j\ne t-1\}.
\end{array}                                             \tag{1}
\]
In the rainbow form, the allowed indices are
\[
\begin{cases}
2\le t\le h,&k=0,\\
t\in\{1,\ldots,k-1\}\cup\{k+2,\ldots,h\},&1\le k<h.
\end{cases}                                             \tag{2}
\]
Empty index ranges give no realization of that form. The theorem
also holds after reflection, with a last-target defect and one
vacancy in a later block. Original lobes may have arbitrary
positive lengths.

**Matching barrier.** The two vacant positions before \(R_\ell\)
are its second slot in \(B_h\) and the sole eligible position of
\(B_k\); hence all other earlier blocks are short. The free prefix
before \(R_\ell\) has \(2h+4\) vertices. Note 203 forbids a
cross-block chord straddling that target. Its only possible
same-block crossing chord would end at the final free slot of
\(B_h\), if it exists, so matching parity excludes it. Thus the
entire prefix is closed under \(M\). All later target runs are
likewise barriers by the even-prefix argument of Note 211, and
their ordinary free groups take standard links by Note 196.

**First-slot dichotomy.** Consider the first free slot \(o_0\).
For \(j<h\), it cannot match the final free slot \(e_j\).
If \(j=0<k\), \(o_0e_0\in E(C)\). If \(j\ge1\), the chord
\(o_0e_j\) lies opposite the site face by Note 193;
noncrossing makes every free slot inside it match internally.
The complete main prefix through the right endpoint of \(B_j\)
is then matching-closed, since no escape target precedes
\(R_\ell\). Its two departing \(C\)-edges contradict
three-connectivity.

When \(k=0\), \(o_0e_0\) is a possible same-block chord but is
also impossible. If it occurred, the even slot \(h_0\) would have
to match some later odd slot \(o_t\): \(o_0\) is used and
\(h_0i_0\in E(C)\). All such cross-block chords lie opposite
the site face. The slot \(e_0\) inside \(h_0o_t\) is already
paired with \(o_0\). The remaining interior slots are \(i_0\)
and complete short-block pairs, an odd number.
No opposite-side chord can leave this interval without crossing
\(h_0o_t\); hence no perfect matching exists. Thus \(o_0e_0\)
is excluded for \(k=0\) as well.

The only remaining opposite-colour mates of \(o_0\) before the
target are \(h_k\) and \(w\). For \(k=0\), \(o_0h_0\) is an
old-cycle edge, so \(o_0w\in M\). For \(k\ge1\), consider
the two possibilities separately.

**Direct form.** Suppose \(o_0h_k\in M\), necessarily with
\(k\ge1\). The slots strictly inside this chord are
\(e_0,o_1,e_1,\ldots,e_{k-1},o_k\), an even set. The only
possible edge leaving this set without crossing \(o_0h_k\)
would be the same-block chord \(o_ke_k\) on the site-face side.
If it occurred, an odd number of slots would remain inside,
impossible. Thus the set matches internally. Note 196's
short-block skipping rule forces \(e_j o_{j+1}\) for \(j<k\).

The next unmatched odd slot is \(i_k\). It cannot match an
earlier even slot: that cross-block chord would interlace
\(o_0h_k\). It cannot match \(e_k\), its old-cycle neighbour,
or any free slot beyond \(R_\ell\), by Note 203. If it matched
\(e_j\) with \(k<j<h\), noncrossing would match all enclosed
short-block slots internally. Together with \(o_0h_k\) and the
links already fixed, this would close the complete main prefix
through \(B_j\), a forbidden two-edge cut. Therefore
\(i_kw\in M\). Inside this chord, and after \(R_\ell\), all
remaining ordinary links are standard. This is the direct line
of (1).

**Rainbow form.** Suppose \(o_0w\in M\). Removing its two
endpoints leaves a single free group from \(e_0\) to \(o_h\)
with exactly one target-free vacant block \(B_k\). If \(k\ge1\),
it is matching-closed: a cross-block edge leaving the outer
chord would interlace it, and an edge beyond \(R_\ell\) is
forbidden by the target barrier. In this case
it is exactly [Note 209](209-every-tight-gapless-internal-vacancy-at-first-surplus-is-hamiltonian.md)'s
group (4), with its left and right
boundaries at blocks 0 and \(h\). The local proof of that note
uses only noncrossing, old-cycle adjacency and the two-edge-cut
skipping rule; it applies here because no escape target lies in
this group. It gives the second line of (1) and the second range
of (2).

If \(k=0\), the remaining group starts
\(h_0,i_0,e_0,o_1,e_1,\ldots,o_h\). The even slot \(h_0\)
must match some \(o_t\). The choice \(t=1\) encloses only the
adjacent pair \(i_0,e_0\), so \(t\ge2\). Noncrossing and the
skipping rule force \(i_0e_{t-1}\) inside \(h_0o_t\): any
earlier mate for \(i_0\) would close one or more complete short
blocks, while \(i_0e_0\) is an old-cycle edge. Every other slot
follows the standard chain. This gives the first range of (2).

**Hamilton routes.** In the direct form, replace the first edge
\(xR_\ell\) of Note 196's target-and-square path by
\[
x,o_0,h_k,i_k,w,R_\ell.                       \tag{3}
\]
The first, middle and last edges are consecutive old-cycle edges;
the other two are matching edges in (1). The ordinary free path
is unchanged. In the rainbow form, replace \(xR_\ell\) by
\(x,o_0,w,R_\ell\), and replace one standard link of the free
path by
\[
e_{t-1},i_k,h_k,o_t.                         \tag{4}
\]
Again the outside edges of each detour belong to \(M\) and its
middle edge belongs to \(C\). All other target transitions are
tight. In both forms the two \(x\)-to-\(v\) paths are internally
disjoint, cover every vertex and contain \(xy,uv\); their union
is a Hamilton cycle. Reflection handles the right endpoint.
Notes 001 and 178 lift to the legal child and longer lobes.
\(\square\)

**Two realized 20-vertex profiles.** For the direct form take
\(r=1,\ell=1,k=1,h=2\), with old-cycle blocks
\[
\begin{array}{ll}
B_0:&x,o_0,e_0,y,\\
B_1:&a_1,o_1,h_1,i_1,e_1,b_1,\\
B_2:&u,o_2,w,R_1,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                             \tag{5}
\]
Its matching consists of \(xy,a_1b_1,uv,\alpha\beta,
R_1\delta,L_1\gamma\) and
\(o_0h_1,e_0o_1,i_1w,e_1o_2\).
The marked cycle is the union of
\[
\begin{split}
&x,o_0,h_1,i_1,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,o_2,u,v.
\end{split}                                             \tag{6}
\]

For the rainbow form take \(r=1,\ell=1,k=0,h=2,t=2\), with
\[
\begin{array}{ll}
B_0:&x,o_0,h_0,i_0,e_0,y,\\
B_1:&a_1,o_1,e_1,b_1,\\
B_2:&u,o_2,w,R_1,L_1,v,\\
S_1:&\alpha,\gamma,\delta,\beta,\text{ returning to }x.
\end{array}                                             \tag{7}
\]
Its matching has the same six fixed site, face and square edges,
and the free edges \(o_0w,e_0o_1,i_0e_1,h_0o_2\).
The marked cycle is the union of
\[
\begin{split}
&x,o_0,w,R_1,\delta,\beta,\alpha,\gamma,L_1,v,\\
&x,y,e_0,o_1,a_1,b_1,e_1,i_0,h_0,o_2,u,v.
\end{split}                                             \tag{8}
\]

Both matchings join opposite old-cycle parities. In each profile,
the site, face and \(\alpha\beta\) chords occupy disjoint intervals
on one side of \(C\); the four free chords form noncrossing nests
on the other side, followed by the nested escape chords. Their
interlacement graphs
are connected. In the direct profile, \(xy\) interlaces
\(o_0h_1,e_0o_1\), \(a_1b_1\) interlaces all four free chords,
and \(uv\) interlaces \(i_1w,e_1o_2\). In the rainbow profile,
\(xy\) interlaces all four free chords, \(a_1b_1\) interlaces
\(i_0e_1,e_0o_1\), and \(uv\) interlaces \(o_0w,h_0o_2\).
In both, \(uv\) interlaces both escape chords, and
\(\alpha\beta\) interlaces both escape chords.
Note 217's interval criterion gives three-connectivity and its
cut projection gives 24-vertex Barnette children. Each pair of
displayed paths shares only \(x,v\) and covers all 20 vertices.

Together with Note 244, this settles a left or right endpoint
defect when both vacancies lie on its defective side of the first
or last target. It does not address a second vacancy after the
first target, transition defects with spare vacancies, gaps,
nonsquare lobes, or arbitrary Barnette graphs.
